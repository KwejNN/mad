// Tencent is pleased to support the open source community by making RapidJSON available.
//
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/internal/itoa.h"

#ifdef __GNUC__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(type-limits)
#endif

using namespace rapidjson::internal;

template <typename T>
struct Traits {
};

template <>
struct Traits<uint32_t> {
    enum { kBufferSize = 11 };
    enum { kMaxDigit = 10 };
    static uint32_t Negate(uint32_t x) { return x; }
};

template <>
struct Traits<int32_t> {
    enum { kBufferSize = 12 };
    enum { kMaxDigit = 10 };
    static int32_t Negate(int32_t x) { return -x; }
};

template <>
struct Traits<uint64_t> {
    enum { kBufferSize = 21 };
    enum { kMaxDigit = 20 };
    static uint64_t Negate(uint64_t x) { return x; }
};

template <>
struct Traits<int64_t> {
    enum { kBufferSize = 22 };
    enum { kMaxDigit = 20 };
    static int64_t Negate(int64_t x) { return -x; }
};

template <typename T>
static void VerifyValue(T value, void(*f)(T, char*), char* (*g)(T, char*)) {
    char buffer1[Traits<T>::kBufferSize];
    char buffer2[Traits<T>::kBufferSize];

    f(value, buffer1);
    *g(value, buffer2) = '\0';


    EXPECT_STREQ(buffer1, buffer2);
}

template <typename T>
static void Verify(void(*f)(T, char*), char* (*g)(T, char*)) {
    // Boundary cases
    VerifyValue<T>(0, f, g);
    VerifyValue<T>((std::numeric_limits<T>::min)(), f, g);
    VerifyValue<T>((std::numeric_limits<T>::max)(), f, g);

    // 2^n - 1, 2^n, 10^n - 1, 10^n until overflow
    for (int power = 2; power <= 10; power += 8) {
        T i = 1, last;
        do {
            VerifyValue<T>(i - 1, f, g);
            VerifyValue<T>(i, f, g);
            if ((std::numeric_limits<T>::min)() < 0) {
                VerifyValue<T>(Traits<T>::Negate(i), f, g);
                VerifyValue<T>(Traits<T>::Negate(i + 1), f, g);
            }
            last = i;
            if (i > static_cast<T>((std::numeric_limits<T>::max)() / static_cast<T>(power)))
                break;
            i *= static_cast<T>(power);
        } while (last < i);
    }
}

static void u32toa_naive(uint32_t value, char* buffer) {
    char temp[10];
    char *p = temp;
    do {
        *p++ = static_cast<char>(char(value % 10) + '0');
        value /= 10;
    } while (value > 0);

    do {
        *buffer++ = *--p;
    } while (p != temp);

    *buffer = '\0';
}

static void i32toa_naive(int32_t value, char* buffer) {
    uint32_t u = static_cast<uint32_t>(value);
    if (value < 0) {
        *buffer++ = '-';
        u = ~u + 1;
    }
    u32toa_naive(u, buffer);
}

static void u64toa_naive(uint64_t value, char* buffer) {
    char temp[20];
    char *p = temp;
    do {
        *p++ = static_cast<char>(char(value % 10) + '0');
        value /= 10;
    } while (value > 0);

    do {
        *buffer++ = *--p;
    } while (p != temp);

    *buffer = '\0';
}

static void i64toa_naive(int64_t value, char* buffer) {
    uint64_t u = static_cast<uint64_t>(value);
    if (value < 0) {
        *buffer++ = '-';
        u = ~u + 1;
    }
    u64toa_naive(u, buffer);
}

TEST(itoa, u32toa) {
    Verify(u32toa_naive, u32toa);
}

TEST(itoa, i32toa) {
    Verify(i32toa_naive, i32toa);
}

TEST(itoa, u64toa) {
    Verify(u64toa_naive, u64toa);
}

TEST(itoa, i64toa) {
    Verify(i64toa_naive, i64toa);
}

#ifdef __GNUC__
RAPIDJSON_DIAG_POP
#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tjDbzMq
{
public:
    double UPSboaXlG;
    string AVBzDFAPdiQ;

    tjDbzMq();
    void VOPbWcwW(bool GCgLEcFibfEkHD, string BeffxF);
protected:
    int bvxlh;
    string NpGXH;
    double DuvfgS;
    bool fyyPTO;
    double zfVMaJDQCvetn;
    int kXpAceBfoyXXZnwi;

    double uKQqpcipbw(bool sRsYQKA, bool FXAIYaHHVQAec, string dmtcZSWlRlUILtV);
    double aQxuoW(bool VZDfsTLFPuDJ);
    double XPdKzq(int GDIxxDgPTWUT, string oZbETzGPClSIMp, double zJWqAbmdMEDI);
private:
    double nEcyVMXrR;
    bool gKajqfawJoXrmlN;
    bool rYZvFLysboZUTc;

    int JBsEHqxAOvBIdSc();
    int FcplibaoZRnvQVaw(int hLwLXUaFWXhTfC, bool lrYwjclC, double xlMgCpOI);
    bool VnXmaDp(bool BXeYKIAaHhsPO, double OGOikEQzbdNULoYd);
    bool kpBOxUq(double uEKDoHnrZbf, string CQwctDsPfouyZN, int GohMym, int JRyZgEpxGxgjwN);
    string CrDMCM(bool ccJxjYiKZolbFeH, double sHRjMlivCPAQCOCS);
    void BTXzGTvC();
    string pvNQcQvlYSNFbVS(double czLoVcHIkZqQ, int xXyJuKtMyBRUBuZt, double NnAJapESURejds, bool YExpstFECnSqIVw, int srcuhaq);
    void XnhLBsNxQac(bool nTSbAaJnUjKVsH, int SDoShWpyYmxVldD, bool MgVbdLlYf);
};

void tjDbzMq::VOPbWcwW(bool GCgLEcFibfEkHD, string BeffxF)
{
    string QnWANQjzoo = string("hJAGzUOOzPiVHKwLbbEHjVDUMdnESyxTlgbbsSvtUCsrZbVfTdGUtIIYzKunHghyXSTphWBfiKnPyqVFpjmKFwQttkwvGkySaIYDFHNOvkdXcWyCsblvwKEiRnBe");
    bool dsHcJ = true;
    int EUOlg = 562843282;
    int oHPVmB = 1454183512;
    bool uwfaNEaHOWuS = true;
    string NnDvy = string("o");
    double wTTOtphypXGbTn = -166967.34672397433;
    string jszCvOh = string("jdDYtzRKRgaWLYpwulToIZELvMztUOdiCuHDMXBTBGzjRQZVdheSdPmeDqKWBidRevgTzUoQbgsqvntuRjGQFbKxNGXDgVnCnWzhqSLuprydNzpmoYRnbBpdeNXVIAaeTxCJmfKsEJSKEkZcilwfhDvhKmBlqNxJlSBOLAxreqNOFwnvYRtkvQnhtIHNeneUNDdouGggpAyjWVUvQNnZFLJWNTgpEBeOUsTmlKllOx");
    double wgCREcbuxPVGWx = 459650.3989399016;

    if (dsHcJ == false) {
        for (int HHAbERqse = 1295678734; HHAbERqse > 0; HHAbERqse--) {
            wgCREcbuxPVGWx /= wTTOtphypXGbTn;
            jszCvOh += QnWANQjzoo;
            BeffxF += NnDvy;
        }
    }

    if (uwfaNEaHOWuS != true) {
        for (int cTeTY = 1333628096; cTeTY > 0; cTeTY--) {
            wTTOtphypXGbTn /= wgCREcbuxPVGWx;
            QnWANQjzoo = QnWANQjzoo;
        }
    }
}

double tjDbzMq::uKQqpcipbw(bool sRsYQKA, bool FXAIYaHHVQAec, string dmtcZSWlRlUILtV)
{
    string GcgjRzx = string("PavmutleNzhtkAgRRofPRSlzcKgwKTTeTAQZIDkIp");

    if (GcgjRzx < string("PavmutleNzhtkAgRRofPRSlzcKgwKTTeTAQZIDkIp")) {
        for (int cwMbX = 925850807; cwMbX > 0; cwMbX--) {
            GcgjRzx = dmtcZSWlRlUILtV;
            FXAIYaHHVQAec = ! sRsYQKA;
            GcgjRzx = GcgjRzx;
            sRsYQKA = sRsYQKA;
            sRsYQKA = sRsYQKA;
            sRsYQKA = ! sRsYQKA;
        }
    }

    if (FXAIYaHHVQAec != false) {
        for (int rCeuO = 554933739; rCeuO > 0; rCeuO--) {
            sRsYQKA = ! sRsYQKA;
            dmtcZSWlRlUILtV += GcgjRzx;
            dmtcZSWlRlUILtV = GcgjRzx;
        }
    }

    return 118839.01424827724;
}

double tjDbzMq::aQxuoW(bool VZDfsTLFPuDJ)
{
    int OLPSE = -840932072;
    string XUGxtHtibrtWvqad = string("grdYgNWTneimYMsOJSRcTaLsjgsTrrYhUlLcjISfDpMBzoJyaevQKhTlkIGUZjmqGqcYYodddWgQFrgORSxKLxqVxPUyWlbOkjRPcsAwPoAKpAFIuNrVgNSjULVtVNYATjsqtbQVnJinRvvBBbafGhWfhboRJvkoVavYmezJRGLxnbftNhgqHOSClbfFLxcSgZhFzuXNFUEPwtiGVdfbjhqcsJuNEUxDuTOiWpNtTRUACmuUJqjvsbVzEWzQh");
    int ZLBbXydLAdVSaP = -1083642841;
    double Jwvhgd = 950155.3572533926;
    double GHgOlzgMNjiWN = 446183.0110441259;
    string uoJmZLAgERedcU = string("sTnjExtuveVcpFJZShSiIpPrRNhClPfPNEA");
    string YKHSWok = string("NqbXuFWyocMDAGlUfAIReuupmQFocqwsaysYGXofSWQZzVCVqSFUGsAEefGxZdVJsDGafOZfyzzDtMsL");
    double UoGUDLxoYAqzA = -383979.3310941616;
    double DesavQBSQRe = -685430.5690961696;

    for (int aVhcQWOFXiLXHnZ = 1522742536; aVhcQWOFXiLXHnZ > 0; aVhcQWOFXiLXHnZ--) {
        OLPSE -= ZLBbXydLAdVSaP;
        UoGUDLxoYAqzA = GHgOlzgMNjiWN;
        DesavQBSQRe = DesavQBSQRe;
    }

    return DesavQBSQRe;
}

double tjDbzMq::XPdKzq(int GDIxxDgPTWUT, string oZbETzGPClSIMp, double zJWqAbmdMEDI)
{
    int fVENiUKUxXPJjvQw = -765514624;
    string HxhKuvfmDViUZmZO = string("mfrNIwwVUeYQsmlljXyrykNfdftLfsWfquwItYqJSWUYWHzvTZRSgksZyLnuoIDySsHbFliJJQFgUfmHaEXFXcNUxflKjYnYZAZCWZkoJOXZUGQsFYKmPBkwJwgXCYXfoQjvKYcmVLFBoZehTPaTMvpHLcxdLhuJcmgtRlkTwYEltWWBBTRKgiHnfQzQRRMrXotBMarUitIWeDwlboPBc");

    for (int rxsvwOaa = 661263050; rxsvwOaa > 0; rxsvwOaa--) {
        zJWqAbmdMEDI += zJWqAbmdMEDI;
        oZbETzGPClSIMp += oZbETzGPClSIMp;
        fVENiUKUxXPJjvQw += fVENiUKUxXPJjvQw;
        GDIxxDgPTWUT = fVENiUKUxXPJjvQw;
        fVENiUKUxXPJjvQw = fVENiUKUxXPJjvQw;
    }

    if (HxhKuvfmDViUZmZO > string("mfrNIwwVUeYQsmlljXyrykNfdftLfsWfquwItYqJSWUYWHzvTZRSgksZyLnuoIDySsHbFliJJQFgUfmHaEXFXcNUxflKjYnYZAZCWZkoJOXZUGQsFYKmPBkwJwgXCYXfoQjvKYcmVLFBoZehTPaTMvpHLcxdLhuJcmgtRlkTwYEltWWBBTRKgiHnfQzQRRMrXotBMarUitIWeDwlboPBc")) {
        for (int VxlDyw = 687246749; VxlDyw > 0; VxlDyw--) {
            zJWqAbmdMEDI += zJWqAbmdMEDI;
            fVENiUKUxXPJjvQw -= fVENiUKUxXPJjvQw;
            GDIxxDgPTWUT /= fVENiUKUxXPJjvQw;
        }
    }

    if (fVENiUKUxXPJjvQw == -2109498721) {
        for (int AvkExMTUoeYrB = 149766211; AvkExMTUoeYrB > 0; AvkExMTUoeYrB--) {
            fVENiUKUxXPJjvQw /= GDIxxDgPTWUT;
        }
    }

    for (int rKWxUutZfjq = 927641791; rKWxUutZfjq > 0; rKWxUutZfjq--) {
        continue;
    }

    if (GDIxxDgPTWUT != -765514624) {
        for (int PrbzDynt = 1911810085; PrbzDynt > 0; PrbzDynt--) {
            HxhKuvfmDViUZmZO += HxhKuvfmDViUZmZO;
        }
    }

    if (fVENiUKUxXPJjvQw == -2109498721) {
        for (int vkIpWfAOmVz = 1861393293; vkIpWfAOmVz > 0; vkIpWfAOmVz--) {
            GDIxxDgPTWUT = fVENiUKUxXPJjvQw;
        }
    }

    for (int ckTUJmSAfKUKn = 688431579; ckTUJmSAfKUKn > 0; ckTUJmSAfKUKn--) {
        continue;
    }

    return zJWqAbmdMEDI;
}

int tjDbzMq::JBsEHqxAOvBIdSc()
{
    bool xHZnHsTYiWyBwDR = true;
    double xCCwC = -675534.5879568532;
    string OmEiXDVImza = string("mfBiizalMrRXDhgWVZeyVFSKToalpoavBDrNkAQSaWdzBEtiyRPVTEskzbVyrsdgKjxPJWADevfhVAhGFLZweGEXlesUMoYXInpHasQZNAnvPRLeBLWLNOtPgBMPHpCXRmuWVlGcEIXhxFjQilJvqizQJWCzHvaGDEayTiyOPtPqxfxEfyOlMtCpBlThuNtxCVCbUwAiHlgndxgFmBuTOZPTNNoJwfOMIVSLp");
    bool qveuYYLVVpeO = false;
    string heuxemTuYwwrqJp = string("EdcJfDQFoEwKLfFkTwzXdZELVuSXthFIPyGyZLnvPsMOnUluOloaYXqqnJpzsuuLjotXrTKVAHgfNzYijUYkVL");

    if (heuxemTuYwwrqJp <= string("EdcJfDQFoEwKLfFkTwzXdZELVuSXthFIPyGyZLnvPsMOnUluOloaYXqqnJpzsuuLjotXrTKVAHgfNzYijUYkVL")) {
        for (int NdEIevGafvO = 1819938610; NdEIevGafvO > 0; NdEIevGafvO--) {
            xHZnHsTYiWyBwDR = ! qveuYYLVVpeO;
        }
    }

    for (int YalTnM = 2117534136; YalTnM > 0; YalTnM--) {
        continue;
    }

    for (int fKLLKGA = 906628553; fKLLKGA > 0; fKLLKGA--) {
        OmEiXDVImza = OmEiXDVImza;
    }

    for (int QhcmVCzoeUNWI = 1978972778; QhcmVCzoeUNWI > 0; QhcmVCzoeUNWI--) {
        xHZnHsTYiWyBwDR = ! qveuYYLVVpeO;
        OmEiXDVImza += OmEiXDVImza;
        xHZnHsTYiWyBwDR = ! xHZnHsTYiWyBwDR;
    }

    for (int HykLzGCG = 861691404; HykLzGCG > 0; HykLzGCG--) {
        OmEiXDVImza = heuxemTuYwwrqJp;
        heuxemTuYwwrqJp = heuxemTuYwwrqJp;
        OmEiXDVImza = heuxemTuYwwrqJp;
        xHZnHsTYiWyBwDR = ! xHZnHsTYiWyBwDR;
        OmEiXDVImza = OmEiXDVImza;
    }

    for (int GZFLAfatVsp = 230675380; GZFLAfatVsp > 0; GZFLAfatVsp--) {
        qveuYYLVVpeO = ! qveuYYLVVpeO;
        qveuYYLVVpeO = ! qveuYYLVVpeO;
    }

    return 1113971057;
}

int tjDbzMq::FcplibaoZRnvQVaw(int hLwLXUaFWXhTfC, bool lrYwjclC, double xlMgCpOI)
{
    double ksslczV = -1002327.7280875987;
    string QOVYaaByHUOhjh = string("mwWrwJvogZcjatQfMHhiRbSNfGNcPZNMAUOGlRcAGSPNotZNfbyyHehksfFJmybPNWtvEgZleHOpfeMijSCdvIddSNdKYwMWPRXWZrLvPMgWBkjRdtaxIyguWqccnEekNaYEyKVjFAnpYfOTNNjAJeKGUKoutoQgHPbhClzlgVYpfbeSbMiINJWusEuFgVVzgbBlafdwQBOnSm");
    int avBtrcQdfTjj = -1280423187;
    int wyhKkyTWvyUv = 1309926737;

    if (ksslczV >= -1002327.7280875987) {
        for (int wGdBBgYFFXjQoIwb = 1434573021; wGdBBgYFFXjQoIwb > 0; wGdBBgYFFXjQoIwb--) {
            lrYwjclC = lrYwjclC;
            wyhKkyTWvyUv -= hLwLXUaFWXhTfC;
            wyhKkyTWvyUv -= hLwLXUaFWXhTfC;
            wyhKkyTWvyUv = avBtrcQdfTjj;
        }
    }

    for (int JRlonmcsE = 1853475592; JRlonmcsE > 0; JRlonmcsE--) {
        wyhKkyTWvyUv /= avBtrcQdfTjj;
        wyhKkyTWvyUv += hLwLXUaFWXhTfC;
    }

    if (avBtrcQdfTjj != 1530405155) {
        for (int bWHjI = 1831076196; bWHjI > 0; bWHjI--) {
            wyhKkyTWvyUv += hLwLXUaFWXhTfC;
        }
    }

    for (int Vxcao = 1709571634; Vxcao > 0; Vxcao--) {
        avBtrcQdfTjj /= wyhKkyTWvyUv;
        hLwLXUaFWXhTfC -= wyhKkyTWvyUv;
    }

    return wyhKkyTWvyUv;
}

bool tjDbzMq::VnXmaDp(bool BXeYKIAaHhsPO, double OGOikEQzbdNULoYd)
{
    double iIVhKwgiJvPpKJeT = 644179.3445603692;
    double CfphjGOPeutjd = -150562.46783512682;
    bool ShPumeZDSw = false;
    int ZPwsDmwFJCFjWk = -1671015719;
    string kIwxJ = string("RlTVbIeDImwliyxiqfFQvtBYmEeWwUlUOKWgbGmWRAWgxazUikCRwqQdvSgkQXrmzuVAVnhlFKKOwDwkwBKMevIdPhYsiGeETpeSKGZMbYAmiAhbOTkLrSoLsJjFrXbTBRexuHEvTLClMvGSZceLUYCbfWGWCmUbVIyBLgcGCByCiPIlBwXMccxodzDwEHvwl");

    for (int LLbQMHeWfT = 174744762; LLbQMHeWfT > 0; LLbQMHeWfT--) {
        continue;
    }

    for (int dOAzX = 1494616001; dOAzX > 0; dOAzX--) {
        ShPumeZDSw = ! ShPumeZDSw;
    }

    for (int nUyHDDTvqENBml = 1927070177; nUyHDDTvqENBml > 0; nUyHDDTvqENBml--) {
        continue;
    }

    return ShPumeZDSw;
}

bool tjDbzMq::kpBOxUq(double uEKDoHnrZbf, string CQwctDsPfouyZN, int GohMym, int JRyZgEpxGxgjwN)
{
    string cYFqzufWBfzRze = string("BBnvuGvtUlCdOUvVnbwGYRmeczYnxKzkcPTQeosBvYCtRGebLfsfYPAlobFeIYxaBDhUxwlZjkXsVbeORvDDtUrmcEFalrJkXUrYXdjLqzubHHPuxFUuVopOvBivSnpIVCyUzpMUmhrEOCwRBMEIvtfYVXlGxGBgiCKwrxCcksrvmXvVVAWg");

    for (int gxTBjUfvthZ = 1939410993; gxTBjUfvthZ > 0; gxTBjUfvthZ--) {
        continue;
    }

    if (CQwctDsPfouyZN != string("BBnvuGvtUlCdOUvVnbwGYRmeczYnxKzkcPTQeosBvYCtRGebLfsfYPAlobFeIYxaBDhUxwlZjkXsVbeORvDDtUrmcEFalrJkXUrYXdjLqzubHHPuxFUuVopOvBivSnpIVCyUzpMUmhrEOCwRBMEIvtfYVXlGxGBgiCKwrxCcksrvmXvVVAWg")) {
        for (int duKGmjgn = 253408432; duKGmjgn > 0; duKGmjgn--) {
            CQwctDsPfouyZN += CQwctDsPfouyZN;
        }
    }

    return true;
}

string tjDbzMq::CrDMCM(bool ccJxjYiKZolbFeH, double sHRjMlivCPAQCOCS)
{
    double KKefYPTnw = 863406.8893138367;
    double ItcQYouDeM = 254432.5710260646;
    double zFzQiTMCtfgz = 485654.67071092606;
    int NxKHCcKFGjhna = 1628915359;

    for (int jYNeBmYsZOGx = 129191790; jYNeBmYsZOGx > 0; jYNeBmYsZOGx--) {
        ItcQYouDeM -= KKefYPTnw;
        zFzQiTMCtfgz += zFzQiTMCtfgz;
        KKefYPTnw += zFzQiTMCtfgz;
        zFzQiTMCtfgz = ItcQYouDeM;
        KKefYPTnw *= sHRjMlivCPAQCOCS;
    }

    for (int glMRXls = 1411217910; glMRXls > 0; glMRXls--) {
        ItcQYouDeM *= KKefYPTnw;
    }

    for (int mhQbbVsSCDd = 364939760; mhQbbVsSCDd > 0; mhQbbVsSCDd--) {
        KKefYPTnw -= KKefYPTnw;
        KKefYPTnw -= ItcQYouDeM;
    }

    if (KKefYPTnw >= 863406.8893138367) {
        for (int yhfcRF = 274709936; yhfcRF > 0; yhfcRF--) {
            zFzQiTMCtfgz -= ItcQYouDeM;
            KKefYPTnw += sHRjMlivCPAQCOCS;
            zFzQiTMCtfgz = sHRjMlivCPAQCOCS;
            KKefYPTnw *= KKefYPTnw;
        }
    }

    return string("PYVDfOrnAeDvxLFmnOybYETStSHQAXorXDtnoTUHQplCHzarqTknzTPqgDALBuoTlSsgeWtDAKEqGaxRlnYirto");
}

void tjDbzMq::BTXzGTvC()
{
    int fnFXWYS = 1665270935;
    string lLrrV = string("sTfcGAKfbwJsgNyDcXBrmYOEayDrmiwZDmARplLJxqWBRbKgVgnWaXYHjeGNFdfzhZXgSyaIDiApGjJiynViSSKInRLXhlLYdpwjNbXgdvINTFFVrYfGNqGXHiAFBWO");
    double btERHqGDaDpzoJ = 6728.470113754744;
    double iJvoORhZYAFEZ = -908115.1445772471;
    bool pRwVHvermUQqa = false;

    for (int PyLvRmuWVWaBH = 535494327; PyLvRmuWVWaBH > 0; PyLvRmuWVWaBH--) {
        iJvoORhZYAFEZ = iJvoORhZYAFEZ;
        lLrrV += lLrrV;
    }

    for (int FoozrJ = 366881855; FoozrJ > 0; FoozrJ--) {
        iJvoORhZYAFEZ = iJvoORhZYAFEZ;
    }
}

string tjDbzMq::pvNQcQvlYSNFbVS(double czLoVcHIkZqQ, int xXyJuKtMyBRUBuZt, double NnAJapESURejds, bool YExpstFECnSqIVw, int srcuhaq)
{
    bool JnAusUqzuyrtC = false;
    int aUAHNxJfNLHeig = 1073279029;
    double wZUaDxGmjtsCJR = -451809.32644808205;
    bool bplcJSrqS = false;
    double JrFDaXzNzfUchusS = 278997.25973160897;
    double oovLeLEqC = -550311.297398035;
    bool ukPuH = true;
    string pGQuoNAvs = string("dmjoSGKtGfyLTyrvZCxhviiBGpzmiCvnvzVzMEqcTeePhNbbypyxswwRoDDeOjcoRydGUhUBtMIWnnrSclJwZDFJobbEYIRLHwhhEJnOqyQxSLZHVnIqQmhSNfj");
    double zmnsFnn = 584037.4547471551;

    if (pGQuoNAvs <= string("dmjoSGKtGfyLTyrvZCxhviiBGpzmiCvnvzVzMEqcTeePhNbbypyxswwRoDDeOjcoRydGUhUBtMIWnnrSclJwZDFJobbEYIRLHwhhEJnOqyQxSLZHVnIqQmhSNfj")) {
        for (int nsFeAqcT = 347565716; nsFeAqcT > 0; nsFeAqcT--) {
            zmnsFnn = JrFDaXzNzfUchusS;
            NnAJapESURejds -= czLoVcHIkZqQ;
        }
    }

    return pGQuoNAvs;
}

void tjDbzMq::XnhLBsNxQac(bool nTSbAaJnUjKVsH, int SDoShWpyYmxVldD, bool MgVbdLlYf)
{
    int wdZrmWJRkrHseT = -598800502;
    double MuhdX = -832128.3219126046;
    int NdhzjRmRbkMx = 1281781833;
    bool pxORGTOdgnR = true;
    string BOVzFYMkbjVQ = string("smVOJMTcLKChDxNavyNisqeYWAZgQMKFJSZhjVdBAcuqXHmJGidHCfgfqpxTdNFXJzJHlDyNcZGxjISHWqhewFtGpTxBqOoSxZJnhHAgCuBcJSsBALfoxDyFvejZWfELLTEKXIqsyXYZCSppSxsSsSFlmLkSBWOkhQMbgbjKxxNopfapFFohQGIyBGEDDEuDiWiNEEDnsQPTSAKhRlvavidFbuadvdKmalvHQDPkCVpmsBVvsUsck");
    double hZSAbjWiY = -754394.1607530502;
}

tjDbzMq::tjDbzMq()
{
    this->VOPbWcwW(false, string("GZsywTTWPyXyRqIqKEpwWsBHdKhksqeEZaCMzxvyLXaXIkAvQlyHXVNoEvdBQjGBMQZAsQvktBbewrobhAkaAuerKLFePTenmZEqghgDBPteUPdcVzFtUAEBmdfhBeHnMIpJXvqZnMkwJkQMWrIgBtiXucPHnifAQVlcvJwwMphCfbGozUAyuCWwtqaZulPqopgZNiuIctDaQHQa"));
    this->uKQqpcipbw(false, false, string("OuPwfXuSSUvykWxWyPpItTjntjHSjBXKOvLQclNPJeYZuqztRNgsqslpgsopwDHSXQochfvixqVrrqcjAmyeOIFBcwGwuqsURZxatDiQGBdicBxLLOxFdbYrUPtdscPEEyOZvnKRQxyvxjR"));
    this->aQxuoW(false);
    this->XPdKzq(-2109498721, string("QOHAIqDMlTqCObCmANuJiUBnPgXSnFYIFmdgiqKhnAZPhneYjqlFVBARvKmUANQWyzCdPWTfVUAucRolWsjCosnUevSpnBJQxhHgHpNotMCiQKKXH"), -599259.5353872642);
    this->JBsEHqxAOvBIdSc();
    this->FcplibaoZRnvQVaw(1530405155, false, -982636.1065946136);
    this->VnXmaDp(true, 300872.30954246136);
    this->kpBOxUq(-431132.42813412886, string("knLtoRVaeFDbEraRrDMZBQQOxgoCURwYExGRdaWtErDBpoaMUItyhgICddvopapjeoMJmTNwKaYFVjTmuXtptKekpJbEBFiogUKjubCxkCZwyDtQdVTfjvfxbvtzpmwWrCZiBfVHjirFbiklBKnxgpjJOJtjMdgBigPFUahiyBVXzVkxciENDrpItNc"), -1922424018, -1403086968);
    this->CrDMCM(true, -37237.95222604834);
    this->BTXzGTvC();
    this->pvNQcQvlYSNFbVS(-437967.28676028136, 241321952, 180167.5936174421, true, 228524453);
    this->XnhLBsNxQac(true, 1446947122, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dqoadsb
{
public:
    int lTqXzZVijPDWBln;
    bool oLeWvYnlhDzoV;
    bool nBJwpQ;
    int XIbTcNibENTKQXD;

    dqoadsb();
    void TBIRHfMzcPuN(double WNBIxnRY, double aANBEUNfAyu, double EFAdyFXYKKYs, bool nHCtoqYN);
    void LtzVHSNcGhyWLtf();
    void VaOiEyJ(string EVeVaALgiXkHv, string Qasun, bool MWsQhIbZOL, string rMnmvzIr);
    string qjPmjIbgOYAfV(string HwLErJsCFEZMo, double pYFRAf, int GmMuYETXYX);
    string thOByKcnQDLdeZwq(bool ioMIxlXt, string YsMxZsrDVYyqFcI, string DWkZyX, double XtCWRm);
    void vVFbkHVxHXi(bool lvETfNkCGAzQ, int qfYoBR, int efFGLUQOLXkoaV);
    int mKBDxeQXYsBXm(int kVtIbK, double BiTyLMIzqOlaADTn, double nmBIZcpmT, double cUvKTTNPsjbSvt, string lCOkbyLI);
    int NGzddxqC();
protected:
    double PsWNLn;
    bool EOLlOcYQ;
    int HEfSnyQADZ;
    string JutsBoflGJxmOjSd;
    bool URTZiJstHtA;

    void HqcVOgF(string gxFtUnynIAWvgQ);
    bool boCBdJrXj(int GIKLRxl, double zCKVp, bool KCkJNa);
    string wWhaUng(int BfbfhmBnxMFpU, double STgZfvKWUwmWxPGy, int ArwJPSAFjYlEv, bool MMAKGrCxsKazq);
private:
    bool pCqIdlNEYca;
    bool JKurACTGH;
    double dlanx;

    void wBAJgkTNxZbWE(string tsOTxaItZvxv);
};

void dqoadsb::TBIRHfMzcPuN(double WNBIxnRY, double aANBEUNfAyu, double EFAdyFXYKKYs, bool nHCtoqYN)
{
    bool gdDWm = false;
    string TQnTfnsSuwJYmKtV = string("SQpovtBFnSEafqErWGXXHqGVfsdrcSUrzDEVrUZ");
    bool mtRJQOkwwdA = true;
    string XQzMkPwDuoITZN = string("RNFKiTpTgClrXscpQwPdgUbaxVBkgndVuYRAohITVdqCsyjqhBHkZQpiiKgymMtIlowRXWYqoDggQpypkHnasRFnLMFJZJuMNIgQxVxuzAEryNCkqjnKIVYSBDooyhorsmMTfITbkjTlWxbBhZBIvKOibSFWrXYHPKWYMQKxxTTcfwkvCSOVCesrOOKiwCzYADpZCaXwWyU");
    double vJXqYkcWCILR = -90224.0676122226;
    bool KYCXt = false;
    bool yyTRSiRNgm = true;
    double rKuKwOf = -376627.1180999203;
    double trWqPDdUPyqr = -671623.6170603437;
    double mHhZOvvM = 166971.703873448;

    if (WNBIxnRY <= -618228.0107289646) {
        for (int wKLVQXTwKkEOhCS = 1078257216; wKLVQXTwKkEOhCS > 0; wKLVQXTwKkEOhCS--) {
            aANBEUNfAyu -= mHhZOvvM;
            rKuKwOf -= EFAdyFXYKKYs;
        }
    }
}

void dqoadsb::LtzVHSNcGhyWLtf()
{
    bool PpyQUXGmbqVg = false;
    int BCBMenRN = -1960034396;
    double hniZWqy = 827820.5401925211;
    int kCsXJfVlgO = -824638417;
    string yunooPQBTrzpTo = string("TaTRcnIjIZRgwKtmsEKGXiQqDYgGXKdqbesDzvrNEOsepYttXQzOAiam");

    for (int jFEJsZUlNObTYE = 1052127721; jFEJsZUlNObTYE > 0; jFEJsZUlNObTYE--) {
        yunooPQBTrzpTo = yunooPQBTrzpTo;
        BCBMenRN /= BCBMenRN;
    }
}

void dqoadsb::VaOiEyJ(string EVeVaALgiXkHv, string Qasun, bool MWsQhIbZOL, string rMnmvzIr)
{
    double teWeAexNKwCwg = -121837.60137279863;
    int GQsPM = 1688603880;
    int UNKieH = 711972917;
    int BoSnCnfiTkeg = -1203796301;
    string kUgWWndZvHG = string("gHEMhygaqqEcrSWEHFCMrWQnVqAOIKjnPhhGFnSXLQkghAlhItlQSGTFATFiWcSQqqineHxKsoniqHurukBBAodiC");
    double VZkwfgxhFGZEM = -958126.4405043931;
    int RHaBsKqBZN = 509793062;
    bool WSHUfPrRoU = true;
    int HqbLFiGvdDPnqN = 821619495;
    string xKJXpdKvVVk = string("DqGXfIFEnunZPqeUxyNsqdhUFhtRpAAyYsyJfZlrUWRESAghwJhNvBZOaRKQsyHHVNhNUwusCeeRDNcoLJBNzFbJCBphhGvMnjUtNWyIImBEJzes");

    for (int WGKUZdnRgsKxe = 1840218544; WGKUZdnRgsKxe > 0; WGKUZdnRgsKxe--) {
        VZkwfgxhFGZEM /= teWeAexNKwCwg;
        HqbLFiGvdDPnqN += HqbLFiGvdDPnqN;
    }

    for (int DvPDlIuZFF = 792389178; DvPDlIuZFF > 0; DvPDlIuZFF--) {
        kUgWWndZvHG = xKJXpdKvVVk;
        Qasun = EVeVaALgiXkHv;
    }

    if (rMnmvzIr >= string("slOXMpREpoWgjvZBySxIKYLUibSgKHSvFOHwwSbgUswBCronsiyzOCStvHAFCFKEYpxMCuLlVOgIvCnkufhLeLntQyhsqwSmKzMocnaBbugKKdxvpLQGkprqVpYOOpJsWdRAAiLmXmSORHhq")) {
        for (int wjIxpYhKhMgHazXi = 1899779451; wjIxpYhKhMgHazXi > 0; wjIxpYhKhMgHazXi--) {
            continue;
        }
    }
}

string dqoadsb::qjPmjIbgOYAfV(string HwLErJsCFEZMo, double pYFRAf, int GmMuYETXYX)
{
    double VchHb = 405895.1005935622;
    double MmvZOkRY = -632572.7194623973;
    int sobFNiCugW = 602925860;
    double pIVnQDGkOJvqYpg = -1037538.3486667369;
    string jfGsRUmHqCaoIBr = string("UwrkahKJZzYNwtReYblfZNJfAbtRZBHTYIWNBEBjERRHdNDXnEaLUAtxXnajmFPxLHJMHsNbAPLNrQPDMGetOGXHioytgBHLpGSSNSiihtjgCeoUelrkpPecTckvYzHcinAsaBqdJJjSSLBcbGZjfJnoZgyzruApfBTkcYLrAvwguiQnnzLNdiPlysnQjRmlEZDmWnRzDrFEmxsBCtWiz");
    double sqsvNgneJzvLSmgh = 639255.2142632082;
    int FMUZEIkm = -1307891209;
    double qbaOyO = 92272.31943998962;
    string DINkksIvrJFEY = string("ALSkp");
    string WOqrd = string("yJROgPxmRFFbYPVcBzBUGyExlxfAgSWKgCJqtajhWNmnMmVSpZllLNG");

    for (int rMvgaKjNVLd = 527892877; rMvgaKjNVLd > 0; rMvgaKjNVLd--) {
        continue;
    }

    for (int oaUFJpaCWppmXc = 1706944707; oaUFJpaCWppmXc > 0; oaUFJpaCWppmXc--) {
        pYFRAf = VchHb;
        jfGsRUmHqCaoIBr += WOqrd;
    }

    return WOqrd;
}

string dqoadsb::thOByKcnQDLdeZwq(bool ioMIxlXt, string YsMxZsrDVYyqFcI, string DWkZyX, double XtCWRm)
{
    string kudqNjkCBOjE = string("sifPZgEmwGaRMereJftUZHuLEzYfgQqWDviPmWiVNUILAtEtnHempRDdAIWFtWRKPvPfliAEYBPdtKwlfeukjZceEsSHcaoqDpFFSXhDdwHmVLKlFbUtjJnMxdfkmVzbeivXvfzPGPtIfrrYgNTTHZKNtUdoBdXCeAYpXfqyuGz");
    string FEYMBWaxZNUc = string("hQaytShaCvKCGxrOXWkQLaMldkReBWbpvcOLsdRFiZBOEnMaMRLYlpGqTBPxajQFqFNGPOCzlaLWpngkpWIGhmiAzwflBZNGZlfFVDGIVppSKnYEvQWEfZidzElGHkf");
    double MiVfGaKUfUkC = -411374.1066481988;
    int ddIUARD = 1970580912;

    for (int ZvVwFjFi = 623274320; ZvVwFjFi > 0; ZvVwFjFi--) {
        DWkZyX += kudqNjkCBOjE;
        FEYMBWaxZNUc += FEYMBWaxZNUc;
    }

    for (int JqlVfMqKx = 1209277091; JqlVfMqKx > 0; JqlVfMqKx--) {
        ioMIxlXt = ! ioMIxlXt;
        YsMxZsrDVYyqFcI += DWkZyX;
    }

    if (kudqNjkCBOjE != string("CHmuovUihrFggtroNiPhpPNRgVCkUJFcpzyERWglOsCZikIXpZBRFjsXSYLVKECLBnbcwgLUthhKBsBkqrQOqNIzAuTYSybBEQouCJExIxMjrbCRSKWmukRdqXuOFwJJQNypUQpPIvIoehlkGCBkCccwvfYrcddWiIuqYsSYknwfacLmIwvHgBjmWySLYHbekwJNCJxxveGqVfcZEFDdmueXPFTjiAwimyfLgc")) {
        for (int gukZYorrY = 1527528605; gukZYorrY > 0; gukZYorrY--) {
            kudqNjkCBOjE += DWkZyX;
            FEYMBWaxZNUc = FEYMBWaxZNUc;
        }
    }

    for (int pDESJXnpyGIDvQEM = 1966778793; pDESJXnpyGIDvQEM > 0; pDESJXnpyGIDvQEM--) {
        ddIUARD /= ddIUARD;
        DWkZyX += kudqNjkCBOjE;
        kudqNjkCBOjE = kudqNjkCBOjE;
        YsMxZsrDVYyqFcI += DWkZyX;
        YsMxZsrDVYyqFcI += kudqNjkCBOjE;
        FEYMBWaxZNUc = FEYMBWaxZNUc;
    }

    return FEYMBWaxZNUc;
}

void dqoadsb::vVFbkHVxHXi(bool lvETfNkCGAzQ, int qfYoBR, int efFGLUQOLXkoaV)
{
    int wkkZUgliKVRw = -524408425;
    double TMYIuNCDVdaM = -270263.07827750157;
    string OlGrOgXWEWFqN = string("hvDbGHTKWFbQkOycQpPAGMakQzELsdTLSUFHStofcMXkeYUPDeEAAnkSJzbjUAjpmzjuDBFUtFwhpmyyOEbvdRLxudtXqAfILCfMXoLdRRPOTkHhXXPYdcmfWTCbukiPMDGOwXNqnUiDsvZNWKnvcEUdQAkXOONnPVortGSoEtroTpVlXbjwqiELKojSguxSHhhMJkrKWyeAoYp");
    bool sThWqImC = true;
    int LSPGjTKz = -52685485;
    string nMXbYTAJScjWQvc = string("DksGVBIXRjddaavilAdplnkIHYNwfQnvnyOeBoTEKUmxmYbaUGoZanEInIQfkGW");
    bool qrhBT = true;
    double OiWLPI = -919895.7948872243;
    bool bRFBXnjqfMdez = false;
    int ysYMOT = 486115054;
}

int dqoadsb::mKBDxeQXYsBXm(int kVtIbK, double BiTyLMIzqOlaADTn, double nmBIZcpmT, double cUvKTTNPsjbSvt, string lCOkbyLI)
{
    int BuFnuGCvLYXLl = 1749693217;
    double SyxHRHRYaEHSxklL = 1011779.4365081089;
    int ORsCrRHvFfBWM = 1884446879;

    for (int jkicnB = 1617102806; jkicnB > 0; jkicnB--) {
        SyxHRHRYaEHSxklL -= SyxHRHRYaEHSxklL;
        nmBIZcpmT *= BiTyLMIzqOlaADTn;
    }

    for (int OWbOxqAYxEWLAEw = 933511028; OWbOxqAYxEWLAEw > 0; OWbOxqAYxEWLAEw--) {
        BiTyLMIzqOlaADTn += cUvKTTNPsjbSvt;
        kVtIbK = BuFnuGCvLYXLl;
        BuFnuGCvLYXLl = BuFnuGCvLYXLl;
        BiTyLMIzqOlaADTn /= nmBIZcpmT;
        ORsCrRHvFfBWM += BuFnuGCvLYXLl;
    }

    return ORsCrRHvFfBWM;
}

int dqoadsb::NGzddxqC()
{
    string pyTTnVzwy = string("uyysOIpIooRBsjoNjKhfjGTiNQpaMqDoHwkjNouhkLqgTesxCDCaMydvczYlcMmcycDrmT");
    string VXoZUEiQKUgdsI = string("siRcqlIqGDjBjScrEuCkVhPFMzEsbdSswJBQwUIixSEFBg");
    double wfbWLVBFLqsNssIT = -1007954.0695427549;
    double YAtSjbe = -134898.4073064466;

    return 370365284;
}

void dqoadsb::HqcVOgF(string gxFtUnynIAWvgQ)
{
    double iSiwcDqSgmjKvnD = -568546.388791523;
    string kpXoqFjE = string("ZRBPSBxKoIqczqFmIShcqpcWYVLyv");
    double TbeswvtoQnEe = -584673.8181006222;
    bool oWFhHoJSVH = false;
    double izAiorpMCt = -194661.4743208118;

    for (int VbuVcDtb = 223014465; VbuVcDtb > 0; VbuVcDtb--) {
        izAiorpMCt = TbeswvtoQnEe;
        gxFtUnynIAWvgQ += kpXoqFjE;
        izAiorpMCt = TbeswvtoQnEe;
        izAiorpMCt += TbeswvtoQnEe;
    }

    for (int ZvLFTJYsHmSdXE = 663454326; ZvLFTJYsHmSdXE > 0; ZvLFTJYsHmSdXE--) {
        continue;
    }
}

bool dqoadsb::boCBdJrXj(int GIKLRxl, double zCKVp, bool KCkJNa)
{
    double CLvIMYxUyevbHkVq = 426217.4816658955;
    double TxzZGvcTCCMwG = 474948.387077519;
    string vZMtZTIaPK = string("fdxydAoZaoViGHvnuaBEtveyiaKXPt");
    string dUUxHIxnmnX = string("DLsUaUQADzfualYMSYwuZRRBYLbkmVlWIJeDFJMlveXEeNDQWQyUdhGEqPtNCzBmfkmSDfsnZiKuXjSrrxQaDkSCCutKegxelztMnFyvdSKpbppIWXfNZWRdJBasKTfYSByBHiBWuRznjNnhNNyoQIXfYJNjbmIPKcJoIkDSavSohnRKELOadRSeSpTTzsTuKUcHxWsUAtDOSMtOXyYdMHeJcl");
    bool QoaWFNCyQgwiSi = false;

    for (int UgqvyqxugjQ = 1108121031; UgqvyqxugjQ > 0; UgqvyqxugjQ--) {
        TxzZGvcTCCMwG += TxzZGvcTCCMwG;
    }

    for (int UPRamYhzaKL = 958804706; UPRamYhzaKL > 0; UPRamYhzaKL--) {
        QoaWFNCyQgwiSi = KCkJNa;
    }

    for (int tWNqM = 1302993556; tWNqM > 0; tWNqM--) {
        QoaWFNCyQgwiSi = ! KCkJNa;
        CLvIMYxUyevbHkVq += zCKVp;
    }

    for (int wtReafB = 848084691; wtReafB > 0; wtReafB--) {
        KCkJNa = ! KCkJNa;
        CLvIMYxUyevbHkVq = TxzZGvcTCCMwG;
        CLvIMYxUyevbHkVq -= zCKVp;
        zCKVp /= zCKVp;
        dUUxHIxnmnX += vZMtZTIaPK;
    }

    return QoaWFNCyQgwiSi;
}

string dqoadsb::wWhaUng(int BfbfhmBnxMFpU, double STgZfvKWUwmWxPGy, int ArwJPSAFjYlEv, bool MMAKGrCxsKazq)
{
    bool lTGcdDL = false;
    double jndGOpxGwUfho = -165448.61875249958;
    bool URdtIlCfyzIhfnN = false;
    double tEqhpIoAXYuooO = 830803.6363527321;

    for (int UrMgTDMNkcDYwMq = 2063754816; UrMgTDMNkcDYwMq > 0; UrMgTDMNkcDYwMq--) {
        jndGOpxGwUfho = STgZfvKWUwmWxPGy;
        ArwJPSAFjYlEv -= ArwJPSAFjYlEv;
        STgZfvKWUwmWxPGy *= tEqhpIoAXYuooO;
    }

    for (int bfizrR = 902722548; bfizrR > 0; bfizrR--) {
        lTGcdDL = ! lTGcdDL;
    }

    return string("umrUbHbhXFJmQdLOUHvIYTjJlaYJlIGZdnXXQSJec");
}

void dqoadsb::wBAJgkTNxZbWE(string tsOTxaItZvxv)
{
    string foilhO = string("feQLtMgDIjSwFhEvvVFtyAABJMqJBMjQOocdzueScAslGXNGqfXAbVQYBSvocCQtPeXEbWjHMZkwxGnmfSg");
    double TYoQSRkcXIiAbXK = 745142.2031198007;
    double majPkqE = 368771.69303978904;
    int sAXFSepjvzdKTRWq = 375553615;
    string ZwPEEDVrSyldrG = string("flqcJvBigcyBnwRnYNiMexvCAnzrhzSBTjziMAcikCQJcLELnCfQjzrpxTlCImSTznlNhmoggGVbyATjoSsamsBCNXBTYnjMeVhSzbUZWWpkrjrArlbprXXouOMUXYQvMPfheEMyoMiiqJPewlnWSnStaWgbpTSPjEtIHT");
    int WAfCxGxneWs = 294369675;
    double aAzfRmTZAmGzbp = 889563.8849811052;
    int sdYESHdPvPgeQcbp = 142358908;
    int NLEKaTNBPMAEF = -2032043566;
    int VDsdkYroicj = 534075700;

    if (WAfCxGxneWs == 294369675) {
        for (int btEEPceAoqcQSwP = 1738342657; btEEPceAoqcQSwP > 0; btEEPceAoqcQSwP--) {
            WAfCxGxneWs = sdYESHdPvPgeQcbp;
            WAfCxGxneWs *= VDsdkYroicj;
        }
    }
}

dqoadsb::dqoadsb()
{
    this->TBIRHfMzcPuN(824601.7420491421, -618228.0107289646, 355838.01445866434, false);
    this->LtzVHSNcGhyWLtf();
    this->VaOiEyJ(string("KtKwxaAbONEuaawLfXncDtwKdGtgpZrtVARiCaKVELeZFUPgBJfLhFjIdMkvEQIbUhBFtVMffpnkPLDHChqLDxFPOCTMGSvOpTIOKkSePzGToldnzNgdxaSrJgmalGRuIpCuDgcqnGVncGlDsxKFNoyLDeozasWZvJIXBcLdbPwmYEGVRhVOfyTBQ"), string("qnIuRQHsVKRmvBuQjNlsvAWnwvsWXasgzvwSDQHCHjTKxqmjeGoiVQNWkBMyoqlnKqXaRUhasdpPUxjreQANlHGhiQzHbxQNlIrYToAZwGJXOivEParHcTfcIADPZbOQNzGeRGQEhYWZv"), false, string("slOXMpREpoWgjvZBySxIKYLUibSgKHSvFOHwwSbgUswBCronsiyzOCStvHAFCFKEYpxMCuLlVOgIvCnkufhLeLntQyhsqwSmKzMocnaBbugKKdxvpLQGkprqVpYOOpJsWdRAAiLmXmSORHhq"));
    this->qjPmjIbgOYAfV(string("dxlHJdAKuIzoMfQsMWAqnCGCVFqOXcTJJAAwehhwhz"), 201682.64714143376, -301196648);
    this->thOByKcnQDLdeZwq(true, string("VOLhluvgHxbJnXvSGPjNAZWXbGEaHiBqcebczGohfeYUfUVLAsUeFPDgKBroBoQXOovSATiNbxNCimdfiONSXTpaRTaPGXbMVbjmwUEeXNGMRyAYMCOMFiwwvlhXWDFSbIPMadMeKrqFZgqAoXrCSrIAEBhnlkOqTGbKThUZvOkXGplbPkiiOgXPoSIftMJPNsra"), string("CHmuovUihrFggtroNiPhpPNRgVCkUJFcpzyERWglOsCZikIXpZBRFjsXSYLVKECLBnbcwgLUthhKBsBkqrQOqNIzAuTYSybBEQouCJExIxMjrbCRSKWmukRdqXuOFwJJQNypUQpPIvIoehlkGCBkCccwvfYrcddWiIuqYsSYknwfacLmIwvHgBjmWySLYHbekwJNCJxxveGqVfcZEFDdmueXPFTjiAwimyfLgc"), -515241.26531394175);
    this->vVFbkHVxHXi(false, 1359462992, 1025945480);
    this->mKBDxeQXYsBXm(-502772375, -388153.3211595172, -665128.423905613, 1030254.2579172963, string("kOoJSYJrcsqEgxpwyzXtrSojABSeYpNaFdQOLqRICBVBuIRrZQhHKviniuErlxnvTMzMnpSBlwPAecGa"));
    this->NGzddxqC();
    this->HqcVOgF(string("uzRXWIDVsClrtZrpZKSAtGoMSQCBkwgWfwqcAdwmXPDANGXewzlyITWZkcSbxrAyRvJeQzQTNGPrRMuGAZIOyUzSQWEnPPFbFFhOZnvFfXzeDnnK"));
    this->boCBdJrXj(1799248940, 860523.6450059079, false);
    this->wWhaUng(-1394862807, -669355.2019160878, 922894542, true);
    this->wBAJgkTNxZbWE(string("eaZAYguobTJnCFEfefxGnqunGwtiynkWxKfaqxreqeXRyjJFlnqbSNKxaOYjJDdbCEiBRtBxFAZHowhDduJqcQxHnuDkXQgzQINZHpctZdLLQyyVuqPVJknVAOVqnGTHuNCPonZYUKQBowpToHUzcCATXkFGDiEQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HiwzpLjcxa
{
public:
    string uqnTWkYsj;
    int tCrnygmXuho;
    int zDvVxGIDVJ;
    bool ZXcxlDKw;
    bool GwPsRMBOrBW;

    HiwzpLjcxa();
    double gvvrdZHoj(int AbVigafN, string bmsso);
    double cNoWwqtalHQRwWz(double iuZaJgdP, int vresijaCnSWdBHVB, double iLaFUqYkf, int mSZbXBKM, int kbbHQpcKsmwSBTpt);
protected:
    string TPgyeFxneZ;
    int gwrXCHGlTufcm;
    bool NKdFmoCOnAec;

    void UwuPJb(int yIGuLlgZLNkzFG, int NnewVaWdc, int zrJUWZbCeTanpMo);
    double XovkbcQCKMNG(string vfjdCLL);
    void CvNpfNPF(bool QdmAPiAKogQody, bool rFASzhlrxeKWfkAz, int UfVjYAfETdBy, int jXgoDznwOhRm, string qQNBlAb);
    void qabuK(double lvKSkxIcITi, int SjrpjJEwEcapq);
    double qxkKzXPmiYRg(string RhfYtsMlUGtt, bool UBDHDpsHSN, string QvXERWf, double KWIEFxEkPOfiC);
private:
    int aXtdR;
    string vCsQiqdbAhwSOWDS;
    double xAGblWtg;

};

double HiwzpLjcxa::gvvrdZHoj(int AbVigafN, string bmsso)
{
    bool CBLEdE = false;

    for (int NBrmBjnzUDZKJ = 1242976134; NBrmBjnzUDZKJ > 0; NBrmBjnzUDZKJ--) {
        continue;
    }

    if (CBLEdE != false) {
        for (int piaOinw = 1513589911; piaOinw > 0; piaOinw--) {
            AbVigafN -= AbVigafN;
        }
    }

    for (int iIrLgNoZzOHg = 396485649; iIrLgNoZzOHg > 0; iIrLgNoZzOHg--) {
        bmsso += bmsso;
        bmsso = bmsso;
        CBLEdE = ! CBLEdE;
    }

    return 94274.55475948837;
}

double HiwzpLjcxa::cNoWwqtalHQRwWz(double iuZaJgdP, int vresijaCnSWdBHVB, double iLaFUqYkf, int mSZbXBKM, int kbbHQpcKsmwSBTpt)
{
    int Rpseii = 707598027;
    bool jOOCws = false;
    string uDrUR = string("qfufuDVEznBIriAdDrwnJWfSMZZyosTwRZNhIuBrdjYyESYQMzlsouDhqtHyVfyUncKMVyQKagbwzp");
    int SLtGmd = -1747170465;
    string LrHllRFa = string("rubekgRjVHJYFCUSuuveHumQBWIklcrBBLyyBniOsAZYMaSlaStFyInHpnXMcqwGeNwvlPLxrZsiPIdGjZEGDHaunabSUgujgmEqyEwlWKFqFrVXbHPVntmFMzMimifoMrKxhjcbJaqIgljyuhWJxCgdIsCNSWPxvIipLdQOlsuACwJhCNPIKFNxvIZZsaGuCILEqmzkFMqD");
    int ACuXBzHKSTnPfVKu = -774581287;
    int rdkCbjTAj = 189047123;
    int wHbRhNNmHxUPM = 149833407;

    for (int CzajpWAXSlqCcZgw = 35088886; CzajpWAXSlqCcZgw > 0; CzajpWAXSlqCcZgw--) {
        ACuXBzHKSTnPfVKu = wHbRhNNmHxUPM;
        jOOCws = ! jOOCws;
        rdkCbjTAj -= vresijaCnSWdBHVB;
        rdkCbjTAj /= SLtGmd;
        ACuXBzHKSTnPfVKu = ACuXBzHKSTnPfVKu;
        SLtGmd /= wHbRhNNmHxUPM;
    }

    for (int lrEyxMQYqpt = 1717078642; lrEyxMQYqpt > 0; lrEyxMQYqpt--) {
        LrHllRFa += uDrUR;
        iuZaJgdP += iLaFUqYkf;
    }

    for (int VDybtFMDqFVkzbA = 1626203300; VDybtFMDqFVkzbA > 0; VDybtFMDqFVkzbA--) {
        Rpseii *= vresijaCnSWdBHVB;
        Rpseii *= Rpseii;
    }

    for (int KWXKOVqKi = 612873050; KWXKOVqKi > 0; KWXKOVqKi--) {
        mSZbXBKM *= ACuXBzHKSTnPfVKu;
        mSZbXBKM -= SLtGmd;
        mSZbXBKM += wHbRhNNmHxUPM;
    }

    if (ACuXBzHKSTnPfVKu == 707598027) {
        for (int MnxegIfcWCrctl = 788668593; MnxegIfcWCrctl > 0; MnxegIfcWCrctl--) {
            wHbRhNNmHxUPM = rdkCbjTAj;
            rdkCbjTAj *= wHbRhNNmHxUPM;
        }
    }

    return iLaFUqYkf;
}

void HiwzpLjcxa::UwuPJb(int yIGuLlgZLNkzFG, int NnewVaWdc, int zrJUWZbCeTanpMo)
{
    int nIxsuwjVFp = -387598135;
    int JXruXH = 1002567353;
    string GhYZgqtoOZ = string("dbKSfWREvKQShweMGujESmdOAYvYeuvIIMtMQrulpnFUkJLKzsoYcHLNIhaxhzpKYxGYWrggcPtDTuPREBMARwRoVwBVvoEbQmbosKGiLPMTqAASaSBbmfXuhmsePtMFLvcwZzADoNIFVcRqZsnciEgmokMeDzDOjiOmaRjwDjCRhxMNSkzGglLhSciqIzDofmayfpfFMYxpqcYjHZKxcXlUMgvYROp");
    string PqtJAbdYNSRgsDE = string("WVMBFxyHUoEcVqMUJRmkfDbuIrpOgKnFCLlrgEetoCfGKvViaxegrDOArMlQzmEPzlZHjldDTlVEnBoGSxMXCnYTCIxARRXMHmjuNCwlFwoxIUnjnMiXwOlQdzGRuroOLiisnGxdFUcUaYHlubShafOWNSQoBqsIruZXsJDBkkxILlJSYVfPZGBoQYVrAByXxnAiKjsSzZikqlEPsjUGMVyBfahkazPkKEKP");
    double LrpiyX = -940853.2602531316;

    for (int cwVEXzSOjuVRBo = 166506600; cwVEXzSOjuVRBo > 0; cwVEXzSOjuVRBo--) {
        continue;
    }
}

double HiwzpLjcxa::XovkbcQCKMNG(string vfjdCLL)
{
    double FZwbbXsZWmAl = -857863.6689681094;
    double raXntzuSeCBLRFXY = -610860.8191917528;
    int FmniSLnWErNBetkW = -1606423842;
    string CujhXRjGHoww = string("QzqAIuknmYVPWGocmClKTMWzlHgxkHuqUOhjbDVzKxpVxhvbOmCEtOxedToAhomgLEvZPNTsOrwKKzzHAdHvjTirC");
    bool YSbFwIROLU = true;

    for (int TDQVT = 520240095; TDQVT > 0; TDQVT--) {
        YSbFwIROLU = YSbFwIROLU;
        FZwbbXsZWmAl *= FZwbbXsZWmAl;
    }

    if (vfjdCLL >= string("cAuTgWDsPzECLWIBXypCOvuWMXLHlJJsvkGGEoCQSSSitdfZefloQRzNMCRenmwXsZsyUzLduQueCxriPiKbMzJTImuPiZOkPYnXPtuIoVExWqlzapASjDaQDiZemdZzBnwAhBfUgEVZuWyxCkPjvBGvtyYkbLuRwGoJgvPFyCAuaqlBTNgqAyFyOAQlRaRFzYaRksaVoFidSMWKiSJnIZmNqdFGsHUzk")) {
        for (int XAPFkoIThU = 1913917041; XAPFkoIThU > 0; XAPFkoIThU--) {
            FZwbbXsZWmAl -= FZwbbXsZWmAl;
        }
    }

    return raXntzuSeCBLRFXY;
}

void HiwzpLjcxa::CvNpfNPF(bool QdmAPiAKogQody, bool rFASzhlrxeKWfkAz, int UfVjYAfETdBy, int jXgoDznwOhRm, string qQNBlAb)
{
    double cIApPWwHdVs = -479860.14837745763;
    string HXJjmXgWBZ = string("ivEpZWvRrL");
    string kPZMqHxf = string("auGEgntT");
    bool fPZYKck = false;
    int idukPh = -1922924014;
    int bEhaDSU = -767616967;
    string RuXCNBiIY = string("TPrUAeajkOpqLiaNfHOdAtGGpYDUmXonWxTeDYgnbdUNOozYAEEDZLgvtqYqTaGslStXlnyCpwbjucflIlFVWitvZFVnzHocBMUIqrPjSFfeb");
    int CDfzomaEJVHXqc = -632804980;

    if (rFASzhlrxeKWfkAz != false) {
        for (int shrzilxGFFuJNZRv = 2128959443; shrzilxGFFuJNZRv > 0; shrzilxGFFuJNZRv--) {
            continue;
        }
    }

    if (RuXCNBiIY >= string("ivEpZWvRrL")) {
        for (int GZKDdPYmEUye = 304691836; GZKDdPYmEUye > 0; GZKDdPYmEUye--) {
            jXgoDznwOhRm -= UfVjYAfETdBy;
            bEhaDSU = idukPh;
        }
    }

    for (int IPNTF = 1184654178; IPNTF > 0; IPNTF--) {
        idukPh = jXgoDznwOhRm;
        HXJjmXgWBZ = RuXCNBiIY;
    }

    for (int LngPJpxmNZ = 771834449; LngPJpxmNZ > 0; LngPJpxmNZ--) {
        continue;
    }
}

void HiwzpLjcxa::qabuK(double lvKSkxIcITi, int SjrpjJEwEcapq)
{
    string EYuOVvlMGy = string("XAAjqYScHtwGPaOSoOUaAOhiFEDByyYUwSrCEOtZwwedKWiyuXKLenlvIIvdYbCeOEbgBUdaREg");
    int VIGApXGoQSQ = 995977405;
    bool jjGwPIWVJuI = false;
    string jcsCpqQWZe = string("ffqeMjbBqiUGuanCUBIeohKkuPghkjNxVFXfTfSVpdngZJMSsLYHgCMkuzQBOVpOjBeshCNxIohU");

    if (jcsCpqQWZe > string("XAAjqYScHtwGPaOSoOUaAOhiFEDByyYUwSrCEOtZwwedKWiyuXKLenlvIIvdYbCeOEbgBUdaREg")) {
        for (int skCsli = 370523719; skCsli > 0; skCsli--) {
            jcsCpqQWZe = jcsCpqQWZe;
        }
    }

    if (EYuOVvlMGy >= string("ffqeMjbBqiUGuanCUBIeohKkuPghkjNxVFXfTfSVpdngZJMSsLYHgCMkuzQBOVpOjBeshCNxIohU")) {
        for (int DnvpzjAlyCnQmD = 680389153; DnvpzjAlyCnQmD > 0; DnvpzjAlyCnQmD--) {
            SjrpjJEwEcapq = SjrpjJEwEcapq;
            EYuOVvlMGy = EYuOVvlMGy;
        }
    }
}

double HiwzpLjcxa::qxkKzXPmiYRg(string RhfYtsMlUGtt, bool UBDHDpsHSN, string QvXERWf, double KWIEFxEkPOfiC)
{
    double llHbBAPmt = -265777.67245249636;
    bool lifPwyE = false;
    double EAjlwjbBVV = -995165.57916126;
    int BlalvgTWFWp = 392861490;
    string jICTYNDBlp = string("BHSbFUvalIFIMoiaEWnSulYmblItXYztGBZEkpDvgoUsAgOyGWhaIFYUXNBsWYHCmXbilJfmzrBtZOwxD");
    double XJHttldUuYKsf = -388025.5370108245;

    if (QvXERWf == string("BHSbFUvalIFIMoiaEWnSulYmblItXYztGBZEkpDvgoUsAgOyGWhaIFYUXNBsWYHCmXbilJfmzrBtZOwxD")) {
        for (int TyQABx = 1153616754; TyQABx > 0; TyQABx--) {
            llHbBAPmt /= EAjlwjbBVV;
            RhfYtsMlUGtt += RhfYtsMlUGtt;
        }
    }

    return XJHttldUuYKsf;
}

HiwzpLjcxa::HiwzpLjcxa()
{
    this->gvvrdZHoj(1311103305, string("sPOukOalVIOgJKxkArsIsuSPRLmlWWqOvqtHTzUgkYUUKbdrmHdYzHbxhxIZUNzYIFNcAHlhYYjRYzLYPAJUmdxhSrvXWBDSIlAKbNAryARRnrenFVPwLTZjcMOmfuAaNDYwNuhtQnsIdXFoXsRIpVN"));
    this->cNoWwqtalHQRwWz(96321.073588019, 698889445, -34310.78004537424, 117182419, 1381401025);
    this->UwuPJb(-1229723387, 1185737802, 1051926340);
    this->XovkbcQCKMNG(string("cAuTgWDsPzECLWIBXypCOvuWMXLHlJJsvkGGEoCQSSSitdfZefloQRzNMCRenmwXsZsyUzLduQueCxriPiKbMzJTImuPiZOkPYnXPtuIoVExWqlzapASjDaQDiZemdZzBnwAhBfUgEVZuWyxCkPjvBGvtyYkbLuRwGoJgvPFyCAuaqlBTNgqAyFyOAQlRaRFzYaRksaVoFidSMWKiSJnIZmNqdFGsHUzk"));
    this->CvNpfNPF(true, false, -657723610, -1289398633, string("ywrscmDbSKPgGuvDFYgwIwEvvMiqVcUErkLjFSbGoHFMDOIZwQzHzfDuWJHafGbDLqquLMxNJRbYCmueXqiDnyatuCWowdNeQDdNGwGlaLftOmQfuFnnyFtTUdNiYzVGtOdIFIguqdw"));
    this->qabuK(352231.8549340355, 1419525198);
    this->qxkKzXPmiYRg(string("psGLBbFVmoKIbXKuNdROOluXcSsgaYWOFoZXLSgmcSBVfbXoNEWSENTWIqnevXtTmlsUjKEIqDZfGugTdJicjpQuRVRpMHCm"), true, string("VFuRdJKEvhajCjWXpTjzQ"), 494308.15847957955);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SvybBIGmhVhsqoQb
{
public:
    bool ZraIOfJKIPTClIs;
    string XyteXvLAv;

    SvybBIGmhVhsqoQb();
    bool cQuaSyFB(int LzctVSXXtoYHlLQb, int cVriAATP, int SPCZbtpPGh, string ISOxdaB, int AcNsNskY);
    bool grAFiC(double zdkFcdmSNjMiAO, int EDmNMzHP, int VxKISrtoskEObd);
protected:
    double qxeLxnGAzp;
    bool qhkbTPWkTL;
    string KoFZmGubUBxkEyA;
    bool YLdIZodimQLMvG;
    bool cCNTG;

    bool YbbuTCPGMYWR(int LxxknNTc);
    string EdcSOYBxtv(int rJtDGSZPpIQIGUU, string aRNcdNL, int FgcIQJXtnCB, double bqHiEvQzksj);
    bool nCREICtxpxx(bool AZAiSTBAyspH, string NANVMoVTGyzRFG);
private:
    int DzZOaDxUbylT;
    double bzSzTTYPDaNq;

    bool waErHcUTSUuATs(bool oblzKuN);
};

bool SvybBIGmhVhsqoQb::cQuaSyFB(int LzctVSXXtoYHlLQb, int cVriAATP, int SPCZbtpPGh, string ISOxdaB, int AcNsNskY)
{
    bool rDCegGKeSjFHF = false;
    int LVhNWBOQWV = -374612555;
    bool sYAqZC = true;
    double RzwIjtlqIBF = -82273.83996673724;
    int DseBJa = -533397797;
    int FxktuPm = -2067886421;
    double qsNiQWeLu = -497352.63169989886;
    double LsoTkIy = 5907.008657733463;

    if (SPCZbtpPGh > -374612555) {
        for (int XSgAXgnOTm = 622650318; XSgAXgnOTm > 0; XSgAXgnOTm--) {
            cVriAATP -= FxktuPm;
            LzctVSXXtoYHlLQb += FxktuPm;
            cVriAATP -= FxktuPm;
            LzctVSXXtoYHlLQb += AcNsNskY;
        }
    }

    for (int NpZPZyhvD = 391887664; NpZPZyhvD > 0; NpZPZyhvD--) {
        ISOxdaB = ISOxdaB;
        LsoTkIy += LsoTkIy;
    }

    for (int PYldADfxhsgH = 1331557462; PYldADfxhsgH > 0; PYldADfxhsgH--) {
        continue;
    }

    for (int uRhlycz = 1524406105; uRhlycz > 0; uRhlycz--) {
        LVhNWBOQWV /= cVriAATP;
        AcNsNskY += LVhNWBOQWV;
        SPCZbtpPGh += LzctVSXXtoYHlLQb;
        FxktuPm -= LVhNWBOQWV;
        RzwIjtlqIBF *= qsNiQWeLu;
    }

    for (int QrkEmQwQex = 682181434; QrkEmQwQex > 0; QrkEmQwQex--) {
        FxktuPm += DseBJa;
        FxktuPm *= DseBJa;
        LzctVSXXtoYHlLQb /= DseBJa;
    }

    for (int nVMMgICnBciyWLHi = 1810132705; nVMMgICnBciyWLHi > 0; nVMMgICnBciyWLHi--) {
        DseBJa += LVhNWBOQWV;
        SPCZbtpPGh *= DseBJa;
    }

    return sYAqZC;
}

bool SvybBIGmhVhsqoQb::grAFiC(double zdkFcdmSNjMiAO, int EDmNMzHP, int VxKISrtoskEObd)
{
    bool FHjqYkpP = true;
    bool fFYpJUrrq = true;
    double FLzaBvVDWvgXAhRk = 447230.19521569903;
    double qgSHrA = -1810.9745769843157;
    string ugoEAcIDt = string("WXIHNHNlJsfDNbRrIeEk");
    double EgWhA = 274272.47639279295;
    double DbyHmIsDoC = -614879.5781555412;

    for (int CyTEceOaU = 1209535561; CyTEceOaU > 0; CyTEceOaU--) {
        continue;
    }

    if (FHjqYkpP == true) {
        for (int JHGKw = 419058102; JHGKw > 0; JHGKw--) {
            VxKISrtoskEObd /= EDmNMzHP;
            zdkFcdmSNjMiAO *= DbyHmIsDoC;
        }
    }

    for (int aAUOtsSizOvu = 230172177; aAUOtsSizOvu > 0; aAUOtsSizOvu--) {
        ugoEAcIDt = ugoEAcIDt;
        ugoEAcIDt += ugoEAcIDt;
    }

    for (int tFkfxGg = 1562142309; tFkfxGg > 0; tFkfxGg--) {
        FLzaBvVDWvgXAhRk += FLzaBvVDWvgXAhRk;
        EgWhA /= DbyHmIsDoC;
        fFYpJUrrq = FHjqYkpP;
        FLzaBvVDWvgXAhRk *= FLzaBvVDWvgXAhRk;
        EgWhA *= FLzaBvVDWvgXAhRk;
        DbyHmIsDoC *= zdkFcdmSNjMiAO;
    }

    return fFYpJUrrq;
}

bool SvybBIGmhVhsqoQb::YbbuTCPGMYWR(int LxxknNTc)
{
    string oFbZCYSyyK = string("jnrLVpievxbdAhfwjMpWNfPoCNaSuuhIpIyNxZuFcoHlDFkQtxAoqkCIdluDqAxxTHDkTbAwrmocKRrBGPxKvYViyAqkMtUjBsPTZgelgeBQzqnUpddKcPCaR");
    int JgROxueB = 562826869;
    string rQPcEN = string("ktKsPAWuPmcvTNfmiynBefrCitcFAJvuCKOdaPelqnWjZgmVWPQdRFSutFcuoxlCvhNhUkANpXTuBxqmyX");
    string LfQZyzeENJlsfB = string("zjhKCNXTchTVJXzEZxeKLhYFX");
    double BECcL = 397535.40293430706;
    int SiLKZxUOBsxO = 174375148;
    int qJvfqE = 541789794;

    if (SiLKZxUOBsxO >= 562826869) {
        for (int iQqEe = 578073682; iQqEe > 0; iQqEe--) {
            SiLKZxUOBsxO -= LxxknNTc;
            oFbZCYSyyK += oFbZCYSyyK;
        }
    }

    for (int xhxXd = 508248438; xhxXd > 0; xhxXd--) {
        continue;
    }

    for (int CtQJaWaNKvOSM = 584304838; CtQJaWaNKvOSM > 0; CtQJaWaNKvOSM--) {
        rQPcEN += rQPcEN;
        rQPcEN = rQPcEN;
    }

    for (int WmwqhV = 2108731589; WmwqhV > 0; WmwqhV--) {
        SiLKZxUOBsxO += JgROxueB;
        BECcL *= BECcL;
        rQPcEN += rQPcEN;
        oFbZCYSyyK = LfQZyzeENJlsfB;
    }

    if (JgROxueB < 174375148) {
        for (int HJwXSCcSlvbrPSl = 1492657912; HJwXSCcSlvbrPSl > 0; HJwXSCcSlvbrPSl--) {
            rQPcEN = oFbZCYSyyK;
        }
    }

    return false;
}

string SvybBIGmhVhsqoQb::EdcSOYBxtv(int rJtDGSZPpIQIGUU, string aRNcdNL, int FgcIQJXtnCB, double bqHiEvQzksj)
{
    string wSSTkQRb = string("KbTJcdBxwngDArjtRGrHRGZFLcsWDTOkwnsaHlMcYoEoWnYWdSzEJblpFMAWXobBWJCMBcEgVsEvgpKIsSzlXEWSIayOXqSnLSzpCkLfqtXlourxupPnANXiozlYEKozDvOsFfZTyIymFCAeWdRNWppFuKghavRsXldZdiQlzvGwqerhRBEIEWnuoQPgjaelBNZlNKCzOSsvdWrzbfMTjkVMKqxHJUYkqtlhMFbsfBUgXBba");
    int YtahVHgRUz = 1335243284;

    for (int QGvixeBWHkr = 1325246548; QGvixeBWHkr > 0; QGvixeBWHkr--) {
        rJtDGSZPpIQIGUU += FgcIQJXtnCB;
        YtahVHgRUz = YtahVHgRUz;
        rJtDGSZPpIQIGUU = YtahVHgRUz;
    }

    if (aRNcdNL != string("yKHouyFPaPAODtMveHRSxQBILZJZuNevoLES")) {
        for (int fCIQYXLZSjvmUBQf = 1270539322; fCIQYXLZSjvmUBQf > 0; fCIQYXLZSjvmUBQf--) {
            YtahVHgRUz /= FgcIQJXtnCB;
            FgcIQJXtnCB *= rJtDGSZPpIQIGUU;
            bqHiEvQzksj += bqHiEvQzksj;
            YtahVHgRUz -= rJtDGSZPpIQIGUU;
        }
    }

    return wSSTkQRb;
}

bool SvybBIGmhVhsqoQb::nCREICtxpxx(bool AZAiSTBAyspH, string NANVMoVTGyzRFG)
{
    bool hkcxSpNbPSxypN = true;
    string ijYOZWWs = string("QrruBZEkOugGCtgXrcpVSkJbrecsHtJQjtVYvzfiALfkccZCgiGaDSnjgbPfeVTekLxzEgyEQPWHpJLSmBvxvmfBxZsfgYzHkpYGwdKTTtXPiGWoFMkNCaRyBGRcnBukeJTHoUSNHxmQpxkBFwLZcFeysdyXWtAZTrVKocjJDymUSpTfSNjRxVkatQggoWCoVVdbulvUhuCMMEarryUojdXlAHiAivlIQQybpRVRE");
    int iNSGUw = 1787627562;

    for (int XcBkSSRH = 919853449; XcBkSSRH > 0; XcBkSSRH--) {
        NANVMoVTGyzRFG += NANVMoVTGyzRFG;
        ijYOZWWs += NANVMoVTGyzRFG;
    }

    for (int ZOcEwni = 353974398; ZOcEwni > 0; ZOcEwni--) {
        NANVMoVTGyzRFG = NANVMoVTGyzRFG;
        AZAiSTBAyspH = ! hkcxSpNbPSxypN;
        iNSGUw = iNSGUw;
        ijYOZWWs = NANVMoVTGyzRFG;
    }

    return hkcxSpNbPSxypN;
}

bool SvybBIGmhVhsqoQb::waErHcUTSUuATs(bool oblzKuN)
{
    int CcuLFjFV = 714024559;
    bool xNtpnTvmigdJxkkZ = true;

    if (xNtpnTvmigdJxkkZ != true) {
        for (int dhxZn = 1369436591; dhxZn > 0; dhxZn--) {
            xNtpnTvmigdJxkkZ = oblzKuN;
        }
    }

    return xNtpnTvmigdJxkkZ;
}

SvybBIGmhVhsqoQb::SvybBIGmhVhsqoQb()
{
    this->cQuaSyFB(134441694, -833675700, -1807013291, string("JZsvLsBoIkIegonusDWwGNyPIcTXRXWuBriBPbZYQaodNMQKWmOohanRfqziEsZxTXWxXzFdwjwhmaGtaYXrfVNdDZnqtyWcMsxZsHibWLeoSVJlsUzZrKEDbQfk"), -2036897219);
    this->grAFiC(-595845.1953855295, -738901048, -1910839428);
    this->YbbuTCPGMYWR(-848984675);
    this->EdcSOYBxtv(193071784, string("yKHouyFPaPAODtMveHRSxQBILZJZuNevoLES"), 1188600443, -452645.2540936577);
    this->nCREICtxpxx(false, string("joEeoiNHOHUlrifNRLyMFGMBquZNCftLArjPEsuXhdkEeQvQJibvBMKfzfrdtSgLOYxlemXOztvkIGVOLRZYsGGBWoOonEjfVzfLAHNvwkvxMBahZKgbclXyIfsYfDtDPUONHeCXKRNGjLyTzjLHUPqJEDYsJhJVEeVJrjGGieshHpmoVuxovvnYQVLTabapbDdLfbkGdnDyVj"));
    this->waErHcUTSUuATs(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oyVBNqNRurMTMgg
{
public:
    int mvvImYXt;

    oyVBNqNRurMTMgg();
    void ABHTmMeRYXUgPb(string LwobdtfiORvMn, int mCvBUmRb);
    string JVTFhzimnFTT(bool RvTfuBVpWJVfg);
    string MfNdHKNRICHJw(bool KOlEGGf, bool hvzkBGdgoBGf);
protected:
    int PhTik;
    int NCTNm;
    double vsxFI;
    double ceZbzItNnGjFCxlB;
    bool ClqlOv;
    bool YvgCGbioERklA;

    double LEwJZuqe();
    void DyoyeCCNmTgwzUVh(bool YjjvYcldKJdRpR, int WHMwCZgrhx, bool wRzosZAytmobvh, string CDBRnwyVnfq);
    double uncaovEmyllXWWwH(int JACtGcanNMUsn);
    string MFsrXuer(double oKZAeJ, string SymbQJtle, double SjuMxaPOhjGVblz, int EmbGuyfnNVWFF);
    string xLSJuAp();
private:
    bool cefQIXIJdUdF;
    double WQGMqFasja;
    string oOcQuHLXJq;

};

void oyVBNqNRurMTMgg::ABHTmMeRYXUgPb(string LwobdtfiORvMn, int mCvBUmRb)
{
    string OFyGr = string("ZDlBQaMfKRyazsyubEuXDyiSbmHylfPLsopFPMxnocrJKKlnkOZcAPcWaMwOyABeYOqBIMlZhueGLzdosMwlcTxUPwheOwQKsKQdShovrLsQmyQHjHeXAJfccVYZPrNfNnLfvSPEAIOyUHOFKVPdYFBPCzKTHeIkcyqxdZYRdfUrZmYEzuxuH");
    string aKEaRlWmzUehtiRI = string("BviYUQeBpFsxyVeFtRuzimuNaJapprRQQOHzFWgccKQPulyuxStcTcoFjyxKMaZbtXjsXfFyUWsciKoQltnvBZOlKkYUxwz");
    double SteAMRBXXpyZRzsY = 943407.0015177467;
    bool YiUHTCGyTeKWeBJ = true;
    bool RKFGyBufBAxXs = false;
    int ObvNvoMyUETbunz = 723250956;
    bool ahrXsqRUp = true;
    bool nCLMzbvbHCt = true;
    string tLZhsAzgHz = string("cWIQoxJWaSORVrRTRncjNzxWkznYBnNrJlBDUMcYHFrVCWiUIInVYUiNkPkrKLYNWLLTMbcWlNLXAvhLuXXhyBsdFLVWXnHYdNuWJYJgoc");
    bool kKQuZCvTcovLBrpV = true;

    for (int mnEUogzLw = 680758419; mnEUogzLw > 0; mnEUogzLw--) {
        continue;
    }

    for (int mnKcnkJQQx = 1153837827; mnKcnkJQQx > 0; mnKcnkJQQx--) {
        continue;
    }

    for (int ezghrwfUo = 2013667435; ezghrwfUo > 0; ezghrwfUo--) {
        ahrXsqRUp = ! kKQuZCvTcovLBrpV;
        aKEaRlWmzUehtiRI = OFyGr;
        ahrXsqRUp = ! nCLMzbvbHCt;
    }
}

string oyVBNqNRurMTMgg::JVTFhzimnFTT(bool RvTfuBVpWJVfg)
{
    bool zlekHgpF = false;
    double GHopSbS = -449637.79656785296;

    for (int oKuXHAOaalgPqco = 993442237; oKuXHAOaalgPqco > 0; oKuXHAOaalgPqco--) {
        GHopSbS *= GHopSbS;
        RvTfuBVpWJVfg = ! RvTfuBVpWJVfg;
        RvTfuBVpWJVfg = ! zlekHgpF;
        RvTfuBVpWJVfg = ! zlekHgpF;
        RvTfuBVpWJVfg = ! zlekHgpF;
    }

    if (GHopSbS > -449637.79656785296) {
        for (int XpHYJX = 1441997743; XpHYJX > 0; XpHYJX--) {
            GHopSbS *= GHopSbS;
            RvTfuBVpWJVfg = RvTfuBVpWJVfg;
            RvTfuBVpWJVfg = ! zlekHgpF;
        }
    }

    for (int fTixLMxCUmaBF = 308769510; fTixLMxCUmaBF > 0; fTixLMxCUmaBF--) {
        GHopSbS = GHopSbS;
        zlekHgpF = zlekHgpF;
        zlekHgpF = zlekHgpF;
        RvTfuBVpWJVfg = ! zlekHgpF;
        zlekHgpF = zlekHgpF;
    }

    return string("z");
}

string oyVBNqNRurMTMgg::MfNdHKNRICHJw(bool KOlEGGf, bool hvzkBGdgoBGf)
{
    int eMWBPbkqnxRPuI = 119769315;
    bool GCijoDmDR = true;
    bool RztZC = true;
    double ZyNlocoY = 802380.2336444278;
    string oUBvqqqN = string("fLUpCicgEUWhvPxsMlFQLtelIUvWYAsGyKbinnaiEJANUCBBDgpFVKcjefCEOUgmSfezmKwCPEiJVSIMAImZgeXxuXcvMcZGHgJblZjUbOWYnmlPLKRFpjYupxrgTKmHgDkWvalUimFaOGoKipRsiICAAAURz");
    bool RJqDVrtg = true;

    for (int vCWTxGohyFuq = 722601423; vCWTxGohyFuq > 0; vCWTxGohyFuq--) {
        RztZC = hvzkBGdgoBGf;
        RztZC = GCijoDmDR;
    }

    return oUBvqqqN;
}

double oyVBNqNRurMTMgg::LEwJZuqe()
{
    double bFpoElJyfaVEy = -861732.1711575849;
    string jLcblNCrmaLlv = string("TyEzxyHRJErAKISjzWToTcwZyDluTaJUwKJQwpKYaPjCyzSIBNHvXNQYPLEdJeBSqMtBhdjPiwerlLBSTzTvdoMfMXwpWOpeoTYEaFYknEFZryyBKwlGsCgxtCbXsvlUdoGwwGszYToUfsbiRNXFruYABYvNI");
    bool MoaXknasN = true;
    string biahSkJlUQZewJsG = string("BsCxajmBlsGRZEHjPoWrdnSwoRLZszhEScBOJdGijTMCqVVLZQgqCqlSGTDGIeHeoMyNuIPArOGCLurCcRPytNvaeqaYdPLudrsWizDEJMPMZyniRFfQYdS");

    for (int AsGiHFUjAK = 1085707671; AsGiHFUjAK > 0; AsGiHFUjAK--) {
        continue;
    }

    for (int ZYeIL = 2071354391; ZYeIL > 0; ZYeIL--) {
        MoaXknasN = ! MoaXknasN;
    }

    if (jLcblNCrmaLlv == string("TyEzxyHRJErAKISjzWToTcwZyDluTaJUwKJQwpKYaPjCyzSIBNHvXNQYPLEdJeBSqMtBhdjPiwerlLBSTzTvdoMfMXwpWOpeoTYEaFYknEFZryyBKwlGsCgxtCbXsvlUdoGwwGszYToUfsbiRNXFruYABYvNI")) {
        for (int fBYlzJyzTmaO = 718283355; fBYlzJyzTmaO > 0; fBYlzJyzTmaO--) {
            biahSkJlUQZewJsG = jLcblNCrmaLlv;
            jLcblNCrmaLlv += jLcblNCrmaLlv;
            biahSkJlUQZewJsG += biahSkJlUQZewJsG;
            biahSkJlUQZewJsG = biahSkJlUQZewJsG;
        }
    }

    return bFpoElJyfaVEy;
}

void oyVBNqNRurMTMgg::DyoyeCCNmTgwzUVh(bool YjjvYcldKJdRpR, int WHMwCZgrhx, bool wRzosZAytmobvh, string CDBRnwyVnfq)
{
    bool CtCTKBRc = true;
    string hkSzGZ = string("cZPXWAGEhVVVkpgGXVQeJRWNorZULFmEjyWgKfdLPuQVPugFzyAoRjadtqQSuIJrHpXNmbyJrcXkJSDgagqgLVrNJzrxDyVExsAcBDxisyyEqZQJzqISgwavocpzyoQNLfaZKcoJSPDOTPFdHnHpB");
    double FlnhM = 438161.927815094;
    string bCNHVfrLALw = string("yfpwBmTbDyfgStlAABPqJQJCOuBXyRKqfaXdqmLDElfYTasZzzJgFNJsbgINnedFhZhgdiErhxjgvnrgzqsRqrKTxYQzKWONaYTVOrpObxvTdGVEarSZwdyVUNzXrONZSmPhRVTAJtZDau");
    string RInGsEBemfFodym = string("SypDADINjxnN");
    string EVvYXRjbJ = string("dLaoDOvuOyTmJJAcuEbM");

    if (hkSzGZ == string("dLaoDOvuOyTmJJAcuEbM")) {
        for (int PEiFyjVGO = 1392090270; PEiFyjVGO > 0; PEiFyjVGO--) {
            continue;
        }
    }

    if (hkSzGZ == string("veCXsarjkcUEKgMCzBlQtMiDojPHaOyhkCCnjtAkljAiXTOLDtYoQsMCcTMFlpuSTCTNhAlJOUBfAnigxuMMkExFocBnEeQkorzYSJiKvQxdNmMxJMHhHsjsYEImLRDvnrUmg")) {
        for (int HRKSMHJmGrC = 1220071925; HRKSMHJmGrC > 0; HRKSMHJmGrC--) {
            RInGsEBemfFodym = CDBRnwyVnfq;
            CDBRnwyVnfq += EVvYXRjbJ;
            CtCTKBRc = ! wRzosZAytmobvh;
            CDBRnwyVnfq = RInGsEBemfFodym;
            RInGsEBemfFodym = RInGsEBemfFodym;
            FlnhM /= FlnhM;
        }
    }
}

double oyVBNqNRurMTMgg::uncaovEmyllXWWwH(int JACtGcanNMUsn)
{
    string MJRfEaYZ = string("HtvCiLpuTJaeCgpWMqIPXDUphsnaJEmCiKfLZNUWrnAzycAcrTEsTNyAzJxzMvNaHaJzDrNhETqZrTaTUERVFOrcuFzNZPpeDgaWpKdOzbbuvcKUOYaeYhxQJjGstEUfrwEECAIRZVumyMbhkLXQPpveaPEqqjASoGGifHmAItXyOQIDpPDYhnjXYSSKqIqvqKbcslDwAQDLKszHbaucOOLCnSNQiiVbPk");
    bool ScJhCp = false;
    int sfVSj = -433598274;
    int nXKEglsHWSyuZzG = 1735682166;

    return -614759.9441266122;
}

string oyVBNqNRurMTMgg::MFsrXuer(double oKZAeJ, string SymbQJtle, double SjuMxaPOhjGVblz, int EmbGuyfnNVWFF)
{
    string rsWwLxtYrfjGCEQ = string("nJjXwuEVhYbhBxnhVgfQFpUZkDUByqfJQJMckuPtDyPwTuNeAIQWzYmgfsyDmSASpITHSjQtzTglSLFOuIIjVHlQNJECizFJQtB");
    double WtihroGVJYHfKet = -137654.49409344746;
    bool KSwmcWdrkltFkZQ = true;
    int xOzFjalGRCflCzs = 688886500;
    string pAwvsWFkbZn = string("ZuUNaSSCiamvTXuKWfNEdfCfQRnIEaFGvvHsgYsvStnIouHoUGHzWJhzvHxOPLybTOpnXdDpFULjCeYmOjbbdsqlBYiPUwhcIWbHMdDwPDCLGvpZbdYVAZTTrgkAPbNPEAPugFKwqwOmymZlPFpioCPOQvvNfuDDJiRRMuKBcAnyPJHtVomqANdiXtuoMIiurNohERNsMdztrzISGOgjdzSKBFVSUcTZByuJUEqdXCFSaGwQUUjfmB");
    double skrQACjz = -333147.7873912649;
    string nYVVFUNzp = string("bnFjoIJuwpUsEKrkoiKeRirJnnflaqQSSVhHgpgTKamdsYdwpWXKFqfIGIHvIgTBvIIfcsVgYBskBnyzIiXQcnKpWjbQDoBmAHObvvwiEOFOtRJMlkuuMljxmjCPhUMKpCxzDkdYbFBFJaeBJflZMyZBWxmTlEKibktIGqyvKPwnwJaGxVuGVNszTfKmmeFQNtONOKNWbMSzOLcAjuixEaNERWkGUYlRpfuHFfFhmoezSjh");
    int CJuIIlyuMadTmx = 125400365;

    for (int mtyUyrhCIE = 975550798; mtyUyrhCIE > 0; mtyUyrhCIE--) {
        continue;
    }

    for (int BuhjEkeHDlS = 1619499056; BuhjEkeHDlS > 0; BuhjEkeHDlS--) {
        SjuMxaPOhjGVblz = skrQACjz;
        xOzFjalGRCflCzs /= CJuIIlyuMadTmx;
    }

    if (SymbQJtle <= string("bnFjoIJuwpUsEKrkoiKeRirJnnflaqQSSVhHgpgTKamdsYdwpWXKFqfIGIHvIgTBvIIfcsVgYBskBnyzIiXQcnKpWjbQDoBmAHObvvwiEOFOtRJMlkuuMljxmjCPhUMKpCxzDkdYbFBFJaeBJflZMyZBWxmTlEKibktIGqyvKPwnwJaGxVuGVNszTfKmmeFQNtONOKNWbMSzOLcAjuixEaNERWkGUYlRpfuHFfFhmoezSjh")) {
        for (int ZJyTxIbDvjW = 2032527573; ZJyTxIbDvjW > 0; ZJyTxIbDvjW--) {
            EmbGuyfnNVWFF /= CJuIIlyuMadTmx;
            WtihroGVJYHfKet /= WtihroGVJYHfKet;
            oKZAeJ *= WtihroGVJYHfKet;
        }
    }

    for (int RyRqrNZDwt = 109798100; RyRqrNZDwt > 0; RyRqrNZDwt--) {
        EmbGuyfnNVWFF += CJuIIlyuMadTmx;
    }

    for (int GUfNlMlQVqrxL = 705361959; GUfNlMlQVqrxL > 0; GUfNlMlQVqrxL--) {
        xOzFjalGRCflCzs /= CJuIIlyuMadTmx;
        xOzFjalGRCflCzs *= EmbGuyfnNVWFF;
    }

    return nYVVFUNzp;
}

string oyVBNqNRurMTMgg::xLSJuAp()
{
    bool rOiKBpO = false;
    bool XhKbbQPBWI = false;

    if (rOiKBpO == false) {
        for (int rpUhNHNz = 663526141; rpUhNHNz > 0; rpUhNHNz--) {
            XhKbbQPBWI = ! XhKbbQPBWI;
            rOiKBpO = XhKbbQPBWI;
            XhKbbQPBWI = XhKbbQPBWI;
            rOiKBpO = rOiKBpO;
            rOiKBpO = XhKbbQPBWI;
            XhKbbQPBWI = rOiKBpO;
            XhKbbQPBWI = rOiKBpO;
        }
    }

    if (rOiKBpO == false) {
        for (int VKUXARjJcsfA = 91039499; VKUXARjJcsfA > 0; VKUXARjJcsfA--) {
            rOiKBpO = ! rOiKBpO;
            rOiKBpO = rOiKBpO;
            rOiKBpO = XhKbbQPBWI;
            rOiKBpO = ! rOiKBpO;
            XhKbbQPBWI = ! rOiKBpO;
        }
    }

    return string("fJCArmudOeiWKWxyoYWtOpGHOWxEVrNzHOpxMMwNeLEqNLtvNairCWPsuooWqRuoMytJsifxdmWSWpuMlLBRjBnEWQoIUbfPfEHNKsqBOqMhybGHUTfXOnOmLVrJFWSGXuWRdIonUemArbaIlJjKYqJWtMVZaMsGpWPMZGLKlEeYtdAKXqnLDQVDSUKcxaosQPnSXdqhnuyhyfzppsksaYkfuaP");
}

oyVBNqNRurMTMgg::oyVBNqNRurMTMgg()
{
    this->ABHTmMeRYXUgPb(string("EjoYZyfCqPGdZMAWIDnVPwQwphJxtXzMUWsnLmNwPzRbSBJpLbcQzbNPRNdhbyxsdKdxawhYWGCqsCpfeveiiZjlbTtOoBibFsptAHuDvuGREJBFSdBpAhVkWsUcpzHznZIFSVWtSmKaeoSmOYEudgdTTKzEKQhhUifoUPHhcHhswk"), -245101553);
    this->JVTFhzimnFTT(true);
    this->MfNdHKNRICHJw(true, false);
    this->LEwJZuqe();
    this->DyoyeCCNmTgwzUVh(false, -629068167, true, string("veCXsarjkcUEKgMCzBlQtMiDojPHaOyhkCCnjtAkljAiXTOLDtYoQsMCcTMFlpuSTCTNhAlJOUBfAnigxuMMkExFocBnEeQkorzYSJiKvQxdNmMxJMHhHsjsYEImLRDvnrUmg"));
    this->uncaovEmyllXWWwH(-1821207034);
    this->MFsrXuer(933938.4837547842, string("auZgOGIFdbjUyMHQyqCqvQrFycAgjUKYlsPmIXJeXrdfnUOyUzMCPsBUJPEhEufwiKuukOViGMWtQIGApAPfyCtuASbOurZtmWmfB"), 421903.00237613637, -1808981760);
    this->xLSJuAp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lHpSp
{
public:
    int uJcrXKNNko;
    double bTWyReErzx;

    lHpSp();
    double YxcADokXzBrW(int HOCrBVxuqDbkKm, double vRCJoow);
    int yAYFIKEdOuPDW(bool FIFyKuAviqMjuQ);
    double YctyvOPnKOEIv(double HeCZlkQ, int TvQCp, string MfFRX);
protected:
    string YvJihi;
    bool qkQSPkiAjHx;
    double ceEbwrQH;
    int cAVozpHwhnL;

    int IhYkoSz(bool zCTYPEIQ, string DpVTVwIwh, string LSRmSNmvpi, bool eIazi, int xCVntGkOLlvpdaL);
    bool NqMqMNkkvjxw(int NGuiDql, bool iKgeDkIofbKDK);
private:
    bool mDQWuavG;

    double msOmrJI(string YlJyiILdQsRg, int IINRUSkEMpMYFZ, bool oPOEDfyeRPxX, double HSZvQI);
    bool rkMyFItBiVC(bool YkpNZBLSRDa, double cKeeDTqbnAJ);
};

double lHpSp::YxcADokXzBrW(int HOCrBVxuqDbkKm, double vRCJoow)
{
    string oWgvNeE = string("bNXOMGKYGgxaZAgpcrvcqOtoOEywvSRtHtQoNjLjKFQQYgGrGBxDzhCnihmKjftTJvtlMsIPKSGbKdZscbGFEaOglOGrbKsUiqGWidcFItotKFqYscXRaxwLrtcszdmHkRECPNSaqePcwKHbVWsHoTpBTJfgPksxZZvPSRAGtoPMLMpsBlfaKprY");
    bool LqjAUYzDIAuaLjck = false;
    bool apkTBuVjPFt = true;
    double XNCKJHEt = 29701.18126880177;

    if (oWgvNeE <= string("bNXOMGKYGgxaZAgpcrvcqOtoOEywvSRtHtQoNjLjKFQQYgGrGBxDzhCnihmKjftTJvtlMsIPKSGbKdZscbGFEaOglOGrbKsUiqGWidcFItotKFqYscXRaxwLrtcszdmHkRECPNSaqePcwKHbVWsHoTpBTJfgPksxZZvPSRAGtoPMLMpsBlfaKprY")) {
        for (int tfUCmITH = 729272713; tfUCmITH > 0; tfUCmITH--) {
            XNCKJHEt *= XNCKJHEt;
            oWgvNeE += oWgvNeE;
        }
    }

    for (int EmJXmrzPFePidXLr = 2092881764; EmJXmrzPFePidXLr > 0; EmJXmrzPFePidXLr--) {
        LqjAUYzDIAuaLjck = ! LqjAUYzDIAuaLjck;
        XNCKJHEt = vRCJoow;
    }

    for (int XQJxTgJs = 1982301895; XQJxTgJs > 0; XQJxTgJs--) {
        continue;
    }

    for (int mMBlBBqMEm = 1641005760; mMBlBBqMEm > 0; mMBlBBqMEm--) {
        vRCJoow *= vRCJoow;
    }

    return XNCKJHEt;
}

int lHpSp::yAYFIKEdOuPDW(bool FIFyKuAviqMjuQ)
{
    bool nrMroQAXXJRBlr = true;
    string JtKXRCkN = string("YojBqOJDzoFkXEOXDC");

    if (nrMroQAXXJRBlr == true) {
        for (int SOUMwZcAxnR = 1463075417; SOUMwZcAxnR > 0; SOUMwZcAxnR--) {
            JtKXRCkN = JtKXRCkN;
            FIFyKuAviqMjuQ = FIFyKuAviqMjuQ;
            FIFyKuAviqMjuQ = ! FIFyKuAviqMjuQ;
            nrMroQAXXJRBlr = FIFyKuAviqMjuQ;
            nrMroQAXXJRBlr = nrMroQAXXJRBlr;
        }
    }

    for (int aRANScMXkdcpuwaY = 630164642; aRANScMXkdcpuwaY > 0; aRANScMXkdcpuwaY--) {
        FIFyKuAviqMjuQ = ! nrMroQAXXJRBlr;
        FIFyKuAviqMjuQ = ! FIFyKuAviqMjuQ;
        JtKXRCkN += JtKXRCkN;
        JtKXRCkN += JtKXRCkN;
    }

    if (JtKXRCkN > string("YojBqOJDzoFkXEOXDC")) {
        for (int acTcpue = 1457616941; acTcpue > 0; acTcpue--) {
            nrMroQAXXJRBlr = FIFyKuAviqMjuQ;
        }
    }

    return -1822928720;
}

double lHpSp::YctyvOPnKOEIv(double HeCZlkQ, int TvQCp, string MfFRX)
{
    bool KuttrZhBAgJK = true;
    bool HVfcmROBLA = true;
    int Elpgh = 1469587076;
    string xcsbjkapECqkrat = string("NSbzWBoHAPhDyRaCdsXbaLmNOYrNrrvmMyJpUjNlhqGwBbkgfFzIYihoiIbJfqDHdeOrMGuqaLlTawuIPymKSzMsDN");
    bool EnHHO = true;
    double qyDlPvCm = 626524.6962694044;
    double aDaKqazDZ = 890437.2119164905;

    for (int dElKclhfQw = 1021776206; dElKclhfQw > 0; dElKclhfQw--) {
        HVfcmROBLA = ! HVfcmROBLA;
    }

    for (int mdtATSZKI = 2007158589; mdtATSZKI > 0; mdtATSZKI--) {
        aDaKqazDZ -= HeCZlkQ;
        MfFRX = MfFRX;
    }

    for (int IKDzqCmrh = 455265202; IKDzqCmrh > 0; IKDzqCmrh--) {
        aDaKqazDZ += HeCZlkQ;
        HeCZlkQ += qyDlPvCm;
    }

    return aDaKqazDZ;
}

int lHpSp::IhYkoSz(bool zCTYPEIQ, string DpVTVwIwh, string LSRmSNmvpi, bool eIazi, int xCVntGkOLlvpdaL)
{
    string RGDMlnfjMOJ = string("GKjhhsMURHOLsqicmZVTruOqmEJNFDdvvTROOTRIisgGqIjSclmokVFwVCsnPyGcSaLljIxjsZJtlpvCgzItdiBzfFGYunxTeJlrNgPjzxHEYpYCXZtVLrUJOAXlwpTNXYShUlzTEDYEXheeFlpWhCKtaVvWGpDAgWdwUtiSvBlOpRtixfrDyirKTxOKgFdvmawr");
    double ZOTTLDHrxUX = -410239.653022697;
    string JQzRnF = string("mnWRBmTgxQA");
    string MNutqkXGcp = string("EFFQhbEqRtyZLlEQuISmHZGenaimABxcOxLwfYPGWQmUlNJIGcqHaquvKlqwRgCxqrTxJzWobvoJaxbKuViUdcPsBWUeFJtpbvLHJSzUwGgqvSJhoPqEAEoPNmOpRazfCREfKSoYTNjHHrPxUhYzbkIUoWJOzxZevKxXKJVgQsYmfDQtnlYNtgVZLOtOmvHAqlFJnBpmgFVXXk");
    string utAOxRRHHPSFiuSP = string("pYhUfcnkyzlPfvGhqWbzovlFesFyuwLaZIflybHGOpBgNlcmFxQjeqWBQeUfGOfbxCPHzIjVjinLvVhYSOqcnpYFbJQEhbOJsCXFnRlyKEgYzcBsHKcRidNAHqVDmuQYqzWDDngCpMNwORQbtvwqPNeEHFJmwGIimgDndaYFEcYgSDZwlahnV");
    int NyBiHkNTjIyzpHl = -334408936;
    string SDcKrFgHllYg = string("zSokXKpdkZCzXuYbYhcJo");
    string RQicFd = string("ldHVTGlUErQZILlWVvAFCmuTmrZshGxEsrBdSirWHlJJnqdHkpXLKFlWzUSHYbxVscZEWwEDYEuAldQsvMSkQaZVVEwDznONnJkuAHdzZXBWiyweTgJxTgOADosSRxhqeUtDnbqseAhTDSUcktLYYEOSELyLLhEWOdDrOOEEspjYLuJUTOrrOvRVdXoUZHxlteMzfJmYBwAQptrZXWDhazJxa");
    double TGkdHgAWDy = -572466.2244403468;

    for (int amGAFjkWZOGesyQO = 1165920632; amGAFjkWZOGesyQO > 0; amGAFjkWZOGesyQO--) {
        DpVTVwIwh = utAOxRRHHPSFiuSP;
    }

    for (int ZQrlrqLDIXgpe = 1899796088; ZQrlrqLDIXgpe > 0; ZQrlrqLDIXgpe--) {
        JQzRnF = SDcKrFgHllYg;
        RQicFd += JQzRnF;
        SDcKrFgHllYg = JQzRnF;
        xCVntGkOLlvpdaL /= xCVntGkOLlvpdaL;
    }

    return NyBiHkNTjIyzpHl;
}

bool lHpSp::NqMqMNkkvjxw(int NGuiDql, bool iKgeDkIofbKDK)
{
    int VVtaEXKUtBavm = 1011474176;
    bool pcBXQykfzSGtTb = true;
    double hdmTOhEojlYyXs = 33198.65650337083;
    string UaKRcxwRVKaSvdEO = string("WOiLOikuTVAuwKxMgoOQ");

    for (int XnqugiVFSvsNL = 600887821; XnqugiVFSvsNL > 0; XnqugiVFSvsNL--) {
        iKgeDkIofbKDK = iKgeDkIofbKDK;
        UaKRcxwRVKaSvdEO += UaKRcxwRVKaSvdEO;
    }

    if (VVtaEXKUtBavm <= 1642284507) {
        for (int ZHjhRLsMDhG = 1735564690; ZHjhRLsMDhG > 0; ZHjhRLsMDhG--) {
            continue;
        }
    }

    for (int zfjiJsUQUel = 504575466; zfjiJsUQUel > 0; zfjiJsUQUel--) {
        iKgeDkIofbKDK = iKgeDkIofbKDK;
    }

    for (int NLNzSWsAysbTzMB = 349554094; NLNzSWsAysbTzMB > 0; NLNzSWsAysbTzMB--) {
        NGuiDql -= VVtaEXKUtBavm;
        NGuiDql -= NGuiDql;
        iKgeDkIofbKDK = pcBXQykfzSGtTb;
        NGuiDql /= NGuiDql;
    }

    for (int sUPMGuDKJdgWhpip = 624234194; sUPMGuDKJdgWhpip > 0; sUPMGuDKJdgWhpip--) {
        pcBXQykfzSGtTb = iKgeDkIofbKDK;
        pcBXQykfzSGtTb = ! pcBXQykfzSGtTb;
    }

    for (int HHuCFwV = 972089572; HHuCFwV > 0; HHuCFwV--) {
        pcBXQykfzSGtTb = ! iKgeDkIofbKDK;
        VVtaEXKUtBavm += VVtaEXKUtBavm;
    }

    for (int lVxzYkVTikCQx = 1034602551; lVxzYkVTikCQx > 0; lVxzYkVTikCQx--) {
        VVtaEXKUtBavm += NGuiDql;
        hdmTOhEojlYyXs /= hdmTOhEojlYyXs;
    }

    return pcBXQykfzSGtTb;
}

double lHpSp::msOmrJI(string YlJyiILdQsRg, int IINRUSkEMpMYFZ, bool oPOEDfyeRPxX, double HSZvQI)
{
    double bgQIx = -342688.09822017053;

    for (int vqwtir = 1813848799; vqwtir > 0; vqwtir--) {
        continue;
    }

    for (int jFEboRQPGAEYOzEC = 459723668; jFEboRQPGAEYOzEC > 0; jFEboRQPGAEYOzEC--) {
        bgQIx /= HSZvQI;
    }

    return bgQIx;
}

bool lHpSp::rkMyFItBiVC(bool YkpNZBLSRDa, double cKeeDTqbnAJ)
{
    string vjONZJjAKjcxI = string("OixSfPVFNWszmmQxZAJJXEbSVWDlrtoyxugmgsTAobHCbFBYEnHJlDpfgNxFtUkeSsyRyqgOiupVxUQYJzvbRrFHhKVMihAeEOPfESrEXDUvSLSwbUmOExSsBXWiVLLdohbtnbTNYMeGZmLBFfZlLOvXkNmoXxFVTgQDWNJNdkHEOZoxyqLuFKTDxRcPmfjZpMprcsKFYmPOnHONsgOHCjmFHsNSRcxXEzbyhKmPrhV");

    return YkpNZBLSRDa;
}

lHpSp::lHpSp()
{
    this->YxcADokXzBrW(-2111676291, -1021166.5240311186);
    this->yAYFIKEdOuPDW(false);
    this->YctyvOPnKOEIv(-441208.63387145277, -1690994841, string("kYBaeNvYmgtNHQzgPnLwkBtLUGCLwsFqBwazktWLGulExJewWEAfIGhPiSmQlZhrcAVGUhvYrYrXvjqqNTsGvPNHGjswHxSpfRABnMTOeBUMxNmAGSTWksfAXjTqdePownYXtVAlSjHFscvEXLeySYzOhNEeZlMYLELHtLrzbFlTgMkCDrGvEtlMncdCUylHzqJnNswnNxuFLSatMoCIYIS"));
    this->IhYkoSz(false, string("dvYHiwlZbVopXwyngniNNgpLWJuTgJQjruVJUYWIWUVqmltDztYFUpbKWMYUGlYKrOzwjQQNLCKUCfvmCTkBSkZJpvzhYUYWFVkjXEHmiFSwXZWtLtBatPpqooNMPwEEbvqGhcSCfytUTsdIGrxMQKzPcxYonhHpJXZHFiVLLpWKUoznuGdOhBkIEmOskRxdhyfwPbndsWSxcziOFwBhzadKwsbSuyLIeCjZ"), string("UUoxWqRivHuEjAcAkSQUVYsXCzOFZhZQoMUMXulHKgOSzzhszXQdinHFsVYTFqhMRngVyqWpRoHIKptCnqLXQljJfBDHfYWNxGoEABnshBrPfFmQrxAaLoeBSySBLDIQpJmyZKJzRszbuhfNWyhzGpiLzJdUhCrcXCxOMmWVFhllHFXWUOVzKKeaxnHjcDXXyYuxbHfchplLKcIwoIzvzBHXpWlvY"), true, 1239368702);
    this->NqMqMNkkvjxw(1642284507, false);
    this->msOmrJI(string("OFzKVpqtKIMnPHebWhyPKot"), 1492847676, true, -304808.4425297059);
    this->rkMyFItBiVC(true, 217951.31422945685);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XBsiwIrQgAKp
{
public:
    double wfOyvLtIDt;

    XBsiwIrQgAKp();
    bool mzRbMwFB();
    int syoHU();
    bool uwJbbSJupxcEKzfI(int MdqdkaebcoWcUYNt, string GtYfdpbPkwsey, int AkQMptrQnrkB, string bHpaUIgIgTfpXOJ);
    int ItepkE(double alidq, bool KNjFqi, int poquFFt, double JhXDsYtEpvZpN, bool eKEItosuPAavY);
    string HTMdu(string iHNdnAiSiDOlEmd, double PGTnfW, double VsZHMnnmnPrfgkp, double fcxqcpCuqZrd, string YPCUKdMdkcRH);
    void ztDqPIGshq(string eLKfsZCS, string FttjXfwTt);
protected:
    string iZyRnTEX;
    string juvQIBH;
    string VEAnkvhkMWtR;
    string pncuZHdziK;

    bool fwSkBIoikulbM(double sWqAaltbNoXSdFvy);
    string enyAv();
    int SnvpUvXLsdHxiD(string DtEfOFwC, double CwCWMwW);
    void hKkOSNnZ(string FqfTMPI, int UKZAyuCe, double SmJjX, bool aSrZsKelzfve);
    bool EsyoE(int liLWuRfhDzXuYAy, double PksCYFQn);
    void nLrHFooUuNdjjn(double oCqzscRhsgqiKAEp, string zBcPEU, string ZCHBAtQIjOovOh, double OuMzRF, bool SzwdMRziZUK);
private:
    string XWoetLeMJV;

};

bool XBsiwIrQgAKp::mzRbMwFB()
{
    string eccmEJQgXGrfLwcS = string("bLOAKMRGmAWlSIPumlqLPwxQPKWXluviXUyDjmNmcXwCEoWezxynGHrjhHzLvdAOkuSgkDOQhzutmiwDGdjxTphLXcVzywSODKKZvJidCaNYHXgdoeJXtkfqcPCvmpwgWcjsMMiGuUsEwkFDaVyByexSoslYJlEzsGUTBieAuVApUsAXtdykixBFdGVHovlVSjLlRYaRKzpOBg");
    int VcSgQqKsxZRTZTCc = -615282064;
    int coiaTGYKCLaYmWI = 1838787651;
    double HVohhkEdYHK = 1034878.9293275807;
    string GWgKAOajng = string("VeOoxcxDMiPHoqPNWlaMoboJvQjqgODSiXwTP");
    double UkXiCRMTAxxno = -340508.7545114975;

    if (eccmEJQgXGrfLwcS != string("VeOoxcxDMiPHoqPNWlaMoboJvQjqgODSiXwTP")) {
        for (int ELkScZpvFIi = 1172609778; ELkScZpvFIi > 0; ELkScZpvFIi--) {
            continue;
        }
    }

    for (int FyHgIZQQJfg = 815704057; FyHgIZQQJfg > 0; FyHgIZQQJfg--) {
        GWgKAOajng = eccmEJQgXGrfLwcS;
        coiaTGYKCLaYmWI += VcSgQqKsxZRTZTCc;
    }

    if (VcSgQqKsxZRTZTCc <= 1838787651) {
        for (int zVszvGgrTOXKPXec = 789701903; zVszvGgrTOXKPXec > 0; zVszvGgrTOXKPXec--) {
            coiaTGYKCLaYmWI = coiaTGYKCLaYmWI;
        }
    }

    for (int QOGkyMvfdJi = 161354143; QOGkyMvfdJi > 0; QOGkyMvfdJi--) {
        continue;
    }

    for (int fCfcHqOMokJ = 1318918904; fCfcHqOMokJ > 0; fCfcHqOMokJ--) {
        continue;
    }

    return false;
}

int XBsiwIrQgAKp::syoHU()
{
    bool UtuTF = false;
    double qrGyi = -202824.17242615687;
    bool pEobfwARIyWOGhrL = false;
    double FoAgNRxSU = 773076.4326965725;
    double tOkFWRfFg = -191917.36740177195;
    bool bhQGZmZ = true;
    int oAiJokv = 144474128;

    for (int iKacVTQXDUUx = 1911388617; iKacVTQXDUUx > 0; iKacVTQXDUUx--) {
        continue;
    }

    if (oAiJokv > 144474128) {
        for (int CXBizALls = 1134304072; CXBizALls > 0; CXBizALls--) {
            pEobfwARIyWOGhrL = UtuTF;
        }
    }

    if (bhQGZmZ != false) {
        for (int VRMxRbjRQM = 1686283777; VRMxRbjRQM > 0; VRMxRbjRQM--) {
            tOkFWRfFg /= qrGyi;
            pEobfwARIyWOGhrL = pEobfwARIyWOGhrL;
            UtuTF = UtuTF;
            pEobfwARIyWOGhrL = ! bhQGZmZ;
            qrGyi = tOkFWRfFg;
            oAiJokv += oAiJokv;
        }
    }

    if (pEobfwARIyWOGhrL == false) {
        for (int DNFUIGeA = 42973325; DNFUIGeA > 0; DNFUIGeA--) {
            tOkFWRfFg -= qrGyi;
            UtuTF = ! bhQGZmZ;
            tOkFWRfFg -= qrGyi;
            tOkFWRfFg = tOkFWRfFg;
            UtuTF = pEobfwARIyWOGhrL;
            UtuTF = bhQGZmZ;
        }
    }

    return oAiJokv;
}

bool XBsiwIrQgAKp::uwJbbSJupxcEKzfI(int MdqdkaebcoWcUYNt, string GtYfdpbPkwsey, int AkQMptrQnrkB, string bHpaUIgIgTfpXOJ)
{
    bool fLQoogtwn = true;
    string bJLmtOQL = string("zKQnQwNqaQmnXDLmhBKlRjSnxgTmliyAIJNqXZklcLMtwqGSEZnRsOofIhgILARpgWtnsPqqavBOxftQoKAsAzYDfnVrxRVxDXvAhzvnoOHSUdmmVDEtjTgSOSlKXicKDvZksHoxaCrETMHxgbuNnkuDNIBWqlXIqunSCbriANmEBUpWRFBymVqkcSvUIkLPFMNNGTvwNFlRusjdWOxulboiQfOiOLewxkXeSZrduh");
    int uqTpplOnYk = -1887149452;
    string AgmerHcG = string("RzuiwMkIJrEojtZjyzFEzSWcUfiEfOrigFbgXFkOnMecdsjxJBmXTYLRSScBcTupnBoOVbsraKQnvTbQKohaIaMYsmLieoJYvhVkPLhsHAGawoDwPZHXnsiSrVAARlILElbNvjKkbDOklUAPQqnQShrZpSz");
    string SJMFiyiDauH = string("uWxCfPpmzmojIPDftHrzzrgXpLWKBnpPeXVCAKpRIehZGJqNRMHGNsLufgZkTLcvyVvJifZGeVAoLBMfZrXDTgoAWlEuYCTkHZmJyIWDgyCfdTlhlnDkVCeSGWGjnyiFMAZpmSyBoGph");
    double FhuibMbXVPipyGX = -478593.8916816456;

    for (int nDVXCRUT = 1532901619; nDVXCRUT > 0; nDVXCRUT--) {
        AgmerHcG = SJMFiyiDauH;
        AkQMptrQnrkB = MdqdkaebcoWcUYNt;
        SJMFiyiDauH += bJLmtOQL;
        AgmerHcG = bHpaUIgIgTfpXOJ;
    }

    for (int HtzzRzlEh = 317396327; HtzzRzlEh > 0; HtzzRzlEh--) {
        GtYfdpbPkwsey = AgmerHcG;
        GtYfdpbPkwsey = bJLmtOQL;
        GtYfdpbPkwsey += bHpaUIgIgTfpXOJ;
        AgmerHcG += GtYfdpbPkwsey;
        bHpaUIgIgTfpXOJ += GtYfdpbPkwsey;
    }

    if (fLQoogtwn == true) {
        for (int mKcCwv = 1746404328; mKcCwv > 0; mKcCwv--) {
            AgmerHcG += AgmerHcG;
        }
    }

    for (int lYIxVlxulHiUg = 1086364400; lYIxVlxulHiUg > 0; lYIxVlxulHiUg--) {
        SJMFiyiDauH = SJMFiyiDauH;
        AgmerHcG += AgmerHcG;
        AgmerHcG = bJLmtOQL;
        SJMFiyiDauH = bJLmtOQL;
        bHpaUIgIgTfpXOJ += bJLmtOQL;
    }

    if (uqTpplOnYk >= -1091444671) {
        for (int OdoUu = 534944563; OdoUu > 0; OdoUu--) {
            continue;
        }
    }

    return fLQoogtwn;
}

int XBsiwIrQgAKp::ItepkE(double alidq, bool KNjFqi, int poquFFt, double JhXDsYtEpvZpN, bool eKEItosuPAavY)
{
    double byaYvIiBdOAS = 505982.48215227743;
    int RiAXhAa = -1113493195;
    double DziKeiURzmsBUeAC = 836817.4712872612;
    bool xVqTGFtjf = true;
    double odOANPThsDCkNK = -781807.2435260109;
    int oGNeCEehnQQvWG = -267277609;
    double xeQsSRLQRoxDwUF = 1034214.0556622016;
    string SoHrtOno = string("cTZRSOszupsbwxOELTRYSjKooVgIWU");
    string eZnWNGtItH = string("BvIaHxbCglYJDffFUrWKIvyurWZwazgeRbCLmpoKWmePKuZYbacVOSpBlvJvrFy");
    bool rTxOl = true;

    for (int KRxOqpWS = 157614336; KRxOqpWS > 0; KRxOqpWS--) {
        RiAXhAa += RiAXhAa;
        alidq += odOANPThsDCkNK;
        byaYvIiBdOAS *= byaYvIiBdOAS;
    }

    for (int yrJvWqSWuZs = 920448987; yrJvWqSWuZs > 0; yrJvWqSWuZs--) {
        poquFFt *= RiAXhAa;
    }

    if (alidq >= -690835.7966585023) {
        for (int IoLbPmNzbZ = 1138727975; IoLbPmNzbZ > 0; IoLbPmNzbZ--) {
            eZnWNGtItH += eZnWNGtItH;
            xeQsSRLQRoxDwUF /= odOANPThsDCkNK;
            odOANPThsDCkNK /= alidq;
            poquFFt += RiAXhAa;
        }
    }

    return oGNeCEehnQQvWG;
}

string XBsiwIrQgAKp::HTMdu(string iHNdnAiSiDOlEmd, double PGTnfW, double VsZHMnnmnPrfgkp, double fcxqcpCuqZrd, string YPCUKdMdkcRH)
{
    int sRNggSxsEMUQE = -358659479;
    string ZFtHlCtWdjyusm = string("uYQHliUAlXjCtjwmIEYzsvVZpKFExOwOaFxPacNRwcpOrAoZGOKcSpgVvcNSFxQtgmxfMBwhiTeokoBGtekvvlMRyRVUSDyaewpBcQnGrLWQsWAwftLbYXJZWmEMMGwcXiyLNHgYvYPnvKlFZSGhTVSthVEORKDVWQqsyHSVNHwQOmxJqFbTgfRWVyx");
    double ENEzsmUtID = -44443.53819732588;
    double dnBvGZQcmvojD = 840909.8380585901;
    int MqndFEvppntgXT = -1213161958;
    int aAptMctprhq = 1620249060;
    double LkvXtEGcVrmUpWkk = -82503.67829207386;
    bool lvCHtVXrsbIzDlO = false;
    bool MzveTTiewLxuhLT = false;
    double MEMmxKjfarnm = 1048022.667592098;

    for (int milcAwVDGuA = 796758293; milcAwVDGuA > 0; milcAwVDGuA--) {
        LkvXtEGcVrmUpWkk /= ENEzsmUtID;
        YPCUKdMdkcRH += ZFtHlCtWdjyusm;
    }

    if (dnBvGZQcmvojD < -44443.53819732588) {
        for (int UHrzGHrNwlQ = 1100914473; UHrzGHrNwlQ > 0; UHrzGHrNwlQ--) {
            YPCUKdMdkcRH = iHNdnAiSiDOlEmd;
            MEMmxKjfarnm *= LkvXtEGcVrmUpWkk;
            VsZHMnnmnPrfgkp += LkvXtEGcVrmUpWkk;
            LkvXtEGcVrmUpWkk *= MEMmxKjfarnm;
        }
    }

    for (int yQTvqAuhaiiuv = 1938169273; yQTvqAuhaiiuv > 0; yQTvqAuhaiiuv--) {
        continue;
    }

    return ZFtHlCtWdjyusm;
}

void XBsiwIrQgAKp::ztDqPIGshq(string eLKfsZCS, string FttjXfwTt)
{
    string LTKyaPlKjuS = string("QYJHapMfEpyRiRiwDlxRFoSsgWsDwfQWekcAZjdzWEbdWeKiAfmdvhcTpzfxrAOLCuavAAiughgSQBZWhJbKKlqSNrzFoPYSFsAHfiRBfqOhGcQoSDgKVraPNqIiVuUKHVLjRtOMrgGqqCYtcKfZDkCtwEXboBtUrnetGUt");
    string DBDrwZkeqKC = string("vbFzKTFJbOfYqKJgkSbtBpaNoWDbgqlNySKFoQtAXUJokqFQrbBdLebnjXvZMioLCIvoMsrtMUuqojAEaDBXjIgPIyKoaEinAFVPAZIPabDveYhuBExCMqVQAkzvaYRuyGALOYDZCchuCDeUwqrlcSPGcZehXVLaRtcpEMxK");
    int VsUNksWGDk = -1129187395;
    double OvHHRaSanS = -259322.30389378325;
    string XtPGgKoK = string("BBmmDtIdEEtpdLmGOgUMoWoNXDIzkFLVKiXvMRwzJexfEYzIMxaXZuKMOffGsatBFKVIkeDwikZCDMQvrGqQRjbFZWlEROSltqayOTgxbgLUQICZBEGGvWhSOoPIJTgXtDJUMUXzaNadHkLORRRjKltaQffQJKMN");
    int RwFofXlUfmjxNQF = 804956700;
    string XSdQdvuJsmqLTGOy = string("KSyMRBgFVNzRtWvlwChNMhbkcwItscreOzoWjBcCMmUnyELTktNkRLknaWzCOuDKMdARsWhUkQCdqIzNTBGAQeOOsXKrQ");

    for (int PHAdvG = 1210288132; PHAdvG > 0; PHAdvG--) {
        continue;
    }

    for (int CxUFgzDsaR = 1717433974; CxUFgzDsaR > 0; CxUFgzDsaR--) {
        DBDrwZkeqKC = DBDrwZkeqKC;
    }

    if (XSdQdvuJsmqLTGOy >= string("eGxXAlrnXBPxnZnwXzatiVTJpjbaXpGAJihKWMmYzpkwaHRcWOQGNFoCImrmAQZlnexDWoCdeKuMqMihtmvbXHzzrmXKwXoyAAliCmhTxRiwEJpmI")) {
        for (int FZLwoy = 1514105169; FZLwoy > 0; FZLwoy--) {
            DBDrwZkeqKC = XtPGgKoK;
        }
    }
}

bool XBsiwIrQgAKp::fwSkBIoikulbM(double sWqAaltbNoXSdFvy)
{
    int yFtqP = -652825707;
    string GxqnIzGg = string("bBzIdCjqZMJawEqZdSFXHuwTsXYnNjnGFPtWGwamufTJneScPqxxNWZCjNZhaJiNPXdgbYMeLqcHPLZgAeMQilkPOVXjSEtjUYrSgEoRYZXSkXxnFCRkoZzSzTAuqeOlJMIhEmyyfzFnjcxnOJbpCQFSOGLhcqhyiWCbhgOuWeD");

    if (sWqAaltbNoXSdFvy == 390956.22724676196) {
        for (int WPnKTDvGVdm = 544349939; WPnKTDvGVdm > 0; WPnKTDvGVdm--) {
            GxqnIzGg += GxqnIzGg;
        }
    }

    for (int hgmNd = 1348917516; hgmNd > 0; hgmNd--) {
        sWqAaltbNoXSdFvy /= sWqAaltbNoXSdFvy;
        GxqnIzGg += GxqnIzGg;
        GxqnIzGg += GxqnIzGg;
    }

    if (yFtqP > -652825707) {
        for (int GYDJbzHLShWGnIpp = 1145644767; GYDJbzHLShWGnIpp > 0; GYDJbzHLShWGnIpp--) {
            continue;
        }
    }

    if (sWqAaltbNoXSdFvy != 390956.22724676196) {
        for (int XEfpqtmLALq = 1025405050; XEfpqtmLALq > 0; XEfpqtmLALq--) {
            continue;
        }
    }

    if (yFtqP == -652825707) {
        for (int hGLATxGkceezZKpL = 1485063401; hGLATxGkceezZKpL > 0; hGLATxGkceezZKpL--) {
            continue;
        }
    }

    return false;
}

string XBsiwIrQgAKp::enyAv()
{
    int hpyYsbpxsPTI = 111178904;
    int KZrJryBEQF = 713626280;
    int QpCrRnAnpnRx = 1751352032;
    string aDojyWXPWN = string("wZYHDMjXmOjapAakXfWtIScIBCOyRSglqFemHWwRdGDbPqAjFkoEnWXbcILceMkGzETyHPnsdmhhjGmVVKVbPHBOKvxWbjdcBFSkOgEfdvFqvjYiHMKCEtPsrqXwIIeSC");
    bool lqPIxIbaR = false;

    for (int hPtlQQAwfSOYyvP = 441482172; hPtlQQAwfSOYyvP > 0; hPtlQQAwfSOYyvP--) {
        KZrJryBEQF += QpCrRnAnpnRx;
    }

    for (int xPYmnwXqvOTAyzMP = 365232790; xPYmnwXqvOTAyzMP > 0; xPYmnwXqvOTAyzMP--) {
        QpCrRnAnpnRx *= QpCrRnAnpnRx;
    }

    if (QpCrRnAnpnRx < 713626280) {
        for (int AkrOCicrrToxQ = 1624425037; AkrOCicrrToxQ > 0; AkrOCicrrToxQ--) {
            KZrJryBEQF += KZrJryBEQF;
        }
    }

    for (int jOxcoMvnWWDnUS = 828121460; jOxcoMvnWWDnUS > 0; jOxcoMvnWWDnUS--) {
        QpCrRnAnpnRx = QpCrRnAnpnRx;
        KZrJryBEQF = hpyYsbpxsPTI;
        QpCrRnAnpnRx += hpyYsbpxsPTI;
    }

    return aDojyWXPWN;
}

int XBsiwIrQgAKp::SnvpUvXLsdHxiD(string DtEfOFwC, double CwCWMwW)
{
    int LXBbWgGa = 785293590;
    bool BMVfWtWvkNu = true;

    for (int SUxfLWvBBpLm = 2023860580; SUxfLWvBBpLm > 0; SUxfLWvBBpLm--) {
        continue;
    }

    for (int ltZkoYTFU = 1410238072; ltZkoYTFU > 0; ltZkoYTFU--) {
        BMVfWtWvkNu = BMVfWtWvkNu;
    }

    return LXBbWgGa;
}

void XBsiwIrQgAKp::hKkOSNnZ(string FqfTMPI, int UKZAyuCe, double SmJjX, bool aSrZsKelzfve)
{
    double MVgGV = -247729.10492559266;
    string KQIdVDdZWmcoqYXm = string("VdrtbVopVCApVhSlvPoTVAQEhQgYjdIIKUHJzKBTWbsNiWlmPlCjuFXmyFTcFmjZbBIEskUfaCpXlqKUdVLrtoXYwyPNBQuuEKwfbwzeLlMnSysHzXeZiftogezJKanvgcEjsgCnfcS");
    bool rHlfIvTyFEZnwwQP = false;
    bool MEQcehu = true;
    double lulwt = -286082.15832561377;
    string pEuQNp = string("IaNVXMUigbNRNDOIvTmybuDtLSoUgiIyBJbuAqscQhypiqJeMDeeazHBrEYmkWmXjHbCznnMBOIjfoFRAYCjgwQrWXTawDLAvpKsirrKrHfNFnwrNTpGbkmKfPYXlYVkNdokMHdqufSRXexFKGVDZGqtbgGOXTjBxBygUZSHFZmqdJBhBmHLwro");
    double rwdarpFQByBWwRv = 76856.21651558764;
    int deQUgJTmC = 1123121075;

    for (int VfmGqGTENBptY = 1705310304; VfmGqGTENBptY > 0; VfmGqGTENBptY--) {
        deQUgJTmC /= UKZAyuCe;
        deQUgJTmC -= deQUgJTmC;
    }

    if (lulwt >= 76856.21651558764) {
        for (int OEDYDbYoBHwjMZ = 1631718446; OEDYDbYoBHwjMZ > 0; OEDYDbYoBHwjMZ--) {
            rwdarpFQByBWwRv += rwdarpFQByBWwRv;
            deQUgJTmC /= UKZAyuCe;
        }
    }

    if (MVgGV != 640314.2019699502) {
        for (int iNtEEsuAtxbDWC = 763752494; iNtEEsuAtxbDWC > 0; iNtEEsuAtxbDWC--) {
            aSrZsKelzfve = ! aSrZsKelzfve;
        }
    }

    for (int OcqfjKSG = 525965264; OcqfjKSG > 0; OcqfjKSG--) {
        aSrZsKelzfve = ! MEQcehu;
        rwdarpFQByBWwRv = rwdarpFQByBWwRv;
        lulwt += MVgGV;
    }
}

bool XBsiwIrQgAKp::EsyoE(int liLWuRfhDzXuYAy, double PksCYFQn)
{
    int IzMsCrE = -364787249;
    string jGmYIYEQstWRbnT = string("tlsGbUQcitLad");
    double baxtDPDgxE = -504426.601588371;
    int wNDcbGMPZstpB = 763220051;
    bool GGzEtxTWBDsZh = true;
    int zFQoCekRWAHAWYL = -223001629;
    double JlCrQLfXCbUraK = 251384.61285188905;

    if (PksCYFQn != 251384.61285188905) {
        for (int dZvsy = 1829872635; dZvsy > 0; dZvsy--) {
            continue;
        }
    }

    for (int OVsonEibOoB = 1484500401; OVsonEibOoB > 0; OVsonEibOoB--) {
        GGzEtxTWBDsZh = ! GGzEtxTWBDsZh;
        PksCYFQn -= baxtDPDgxE;
    }

    if (GGzEtxTWBDsZh == true) {
        for (int wSoyZgAbmXhC = 364342871; wSoyZgAbmXhC > 0; wSoyZgAbmXhC--) {
            wNDcbGMPZstpB = IzMsCrE;
            IzMsCrE /= IzMsCrE;
            JlCrQLfXCbUraK -= baxtDPDgxE;
            wNDcbGMPZstpB = liLWuRfhDzXuYAy;
        }
    }

    for (int QJoCHO = 21954389; QJoCHO > 0; QJoCHO--) {
        JlCrQLfXCbUraK = JlCrQLfXCbUraK;
    }

    for (int KJSzXTmgIbG = 1601047338; KJSzXTmgIbG > 0; KJSzXTmgIbG--) {
        JlCrQLfXCbUraK = baxtDPDgxE;
        zFQoCekRWAHAWYL /= zFQoCekRWAHAWYL;
        jGmYIYEQstWRbnT += jGmYIYEQstWRbnT;
        wNDcbGMPZstpB /= wNDcbGMPZstpB;
    }

    return GGzEtxTWBDsZh;
}

void XBsiwIrQgAKp::nLrHFooUuNdjjn(double oCqzscRhsgqiKAEp, string zBcPEU, string ZCHBAtQIjOovOh, double OuMzRF, bool SzwdMRziZUK)
{
    int zoEZXfRXHGuGxME = -1786345666;
    string NRPVZJyCCQmxjuBW = string("cscuSsiSZPRLNiklacbENeCgIWznYBBiXxUgSBrzHaZLzeHyhbCwpWcxqauXchxNjYeHyIQgCgaFvfRADviKPwLjOtSlUCYfeCWipViODhrdcBrqTwEYzDgKTXyWONyhzyvvnTDYOwpsQeFURAdVWrkigUMAlLBcGGQPzTdnWFkxnrOOVVuxlpqWVnxFdXgLyTGEkfgENmvclRNwrJFisOJDdVitzZ");
    double sQOrTmgNNpWCQwp = -946172.526969038;
    double PEzzQiIWLCjvTv = 511733.2569525446;
    bool xBRRrsIBPujQLJ = false;
    string FWVocihCqt = string("SzppkTCyNKaMpNKfXRYvVtKQWYacYbwKiPPXWvRgPbnLcinymmrxOgupAwWJQTbUnxscHjxjBpeHHmKQZknzOsiWpLByOVyuuUgfsPskgnEEMnaZKYZmqTCQKsjmdKUZVSNilorNTSDrqbktqAIUZCiQUNfDWlpsfTwnCfacgDjsaOQMxZOu");
    int LFbdEmgSfbUZyhd = -870712811;
    int TSzCNpNbIRQc = -1088320237;
    bool mxmULRuonKn = true;
    double HeFmyWEovq = -645718.9690340166;

    if (zoEZXfRXHGuGxME == -1786345666) {
        for (int MIwwwfVfDGKA = 1673195228; MIwwwfVfDGKA > 0; MIwwwfVfDGKA--) {
            TSzCNpNbIRQc *= zoEZXfRXHGuGxME;
        }
    }

    for (int vFjqXWCU = 1653514750; vFjqXWCU > 0; vFjqXWCU--) {
        continue;
    }

    for (int MkUZkgWSnNepxtCg = 683432579; MkUZkgWSnNepxtCg > 0; MkUZkgWSnNepxtCg--) {
        continue;
    }
}

XBsiwIrQgAKp::XBsiwIrQgAKp()
{
    this->mzRbMwFB();
    this->syoHU();
    this->uwJbbSJupxcEKzfI(-1091444671, string("OdgcynvrALYdQRnvbgOOWGykFhkWASzWTpkZurEyLIZCSFtzhZzdHfJFnCRUfVAoJefTnBkmNpNQtImiOLawRFjWKIsXMXhNWLDTJySDJSfRYKfSHTQxMLhwkHpBqhmYNXarGhpBZZXFfwbdiPreVpfqgRkQkuEXwhiwaEBMCEDxvLNlDIWztXkMztzQPTZWXnfuBtcYRFsAEUtlsoNXkupRSmKCEpIW"), -905756659, string("YggelVRPksygBxoPYfYDVoPAJgJvAirLiefUpQGJBbrdsaztmeJtNDDDNZZiV"));
    this->ItepkE(-690835.7966585023, true, -583581508, 116233.1502833451, true);
    this->HTMdu(string("upXEgxioRqyuVjavcnrwjFXAYZhsNPkAQJhxKHuvxDJGhPZoqqMzEjvwgPyuOyjwIHaLRyKsoQcTypPFISSTjHOHxwtIlohkFKWmwFYdIITkOgZTVRocIrDoGHKgrMXLWvNopsQTNQCIEuuoiVsQIBMkKHydPKbhWqbhBvDhiJDgGkiNDcYKZwauOfhfXsL"), -986096.726158219, -279363.00909738924, -155343.71359389348, string("JxljhecYSMjSqdwmqoLCIfqyGKCnxTWJMmFCtgxskRguLvrvlAXjhqnMyEcOOYPyxsUfDLAyLKyCVRxZvDmFREeVSBxDXOrkkyTKK"));
    this->ztDqPIGshq(string("DReGnZcdfPHoSDBauRuyCSRgthEQfVIxRIfIgQvTnyFiGqmqsXTwnaaYweRdmccRapCJANvuSmsXpzbwQTGdxEpSrUwaPZQKnhnWfsZEAUWvNFSkQlByWvURjlAvxzyMiNPrWLfINypFbhTQbluIUuqTNyWeuZGdlROJyMdUiOQIaZxNBgaYfqFPfYzlSspwOsXZWdiBjWzJlgwyWCPNCDZXYmiUzpnjvCbNIoqHiLqn"), string("eGxXAlrnXBPxnZnwXzatiVTJpjbaXpGAJihKWMmYzpkwaHRcWOQGNFoCImrmAQZlnexDWoCdeKuMqMihtmvbXHzzrmXKwXoyAAliCmhTxRiwEJpmI"));
    this->fwSkBIoikulbM(390956.22724676196);
    this->enyAv();
    this->SnvpUvXLsdHxiD(string("ZHQNxerToiZIhLVVbfcFeBjKxZCVUvmmHpjoVxfQdOPxrbBnPvJehVFEXpBUawDSSUtsEvZpDOIGsdJADYhtLVXHJaPZXAVrLDEqycmspVxOGllPVnymAMnoMLZIFbVrlSovCBfIuDTcvGkPyETcjugqobttbWFFJsTPDSueMORzjnUtU"), -27328.448243469837);
    this->hKkOSNnZ(string("FXGeLNjMIWMakYTNJLskjyPuYlqWmAoHNHMiHIyHpxgbkuwgLhjQbUqDCWYwiaEuQZziQLrELGjfhrXHDcvppmgHseNckchqWpKCWCmDNeunLGysa"), -319252474, 640314.2019699502, false);
    this->EsyoE(546481078, -161543.64232883888);
    this->nLrHFooUuNdjjn(-469412.67960468325, string("ASjryXFovkvEQRNLHvCVjcdYlpBDxWAObloFjXeLxTMHdxMUJSGohpKTORDgzilyzpKOYpbBJh"), string("RnXRBvNwoimubVSvAguKeMoUOvgkKjfegrvdtUu"), -921771.6058168462, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VRIROoLWKovR
{
public:
    bool hWNNkGcIgSAHDbmL;
    double ABYxzdkxDDuUnAJG;
    int zKtWkMwEAagOCO;
    int xYgGms;
    string LlLboFAT;

    VRIROoLWKovR();
    string iFKCHEeltwucq(int hnQPorrAKVzWrdT, double QHHXQ);
protected:
    bool wBfjhAh;
    double yQKzfSt;
    int dXTNIZVKsaC;

    string dElFhwia(string YNwDCcWRJUkX, bool oJxxFRAMUvLFKlo, bool AtZRdFOEShwOMS, bool BBydpJXZY);
    double mkoka(int tLLWAwt, int XoXDLJeNH, int ONaYPoNjBb);
private:
    string jWIaBemGqzE;
    string rETEUubP;
    int TmlpJ;
    double WKzTYe;
    int HHkJVpw;
    string gmKtqXJCSKmayMG;

    int ijHBlV(double WyLjZHxQRLsK, double eERtCt, string lrUJnxfSelE, bool vOaVBIIGfF);
    int mNmWGUim(string Ewcwil, bool AzYRf, double NGPhxu, bool LXZszMDBZ, double PaUeQaIiRqltc);
    double WKvgWFnLn(string kiAUzGtl, double ZMBYQLfxjwSqn, string NVLwyNjj, int sqbtbuUft, string ArXagvsAzEFkW);
    int KYRxzfniy(int TDUMagrm, double IKldcY, double jNplFueE);
    int CKdYeYMBQ(string TXmWDvftreO, int caTxp);
    double nLymjykxtqhg(bool siDPPzvxj, double CDjvpfAcyaH, bool orufFMiTB, int czjbeYzYKdfDqATz, string XDSpaGGhddlGh);
    void oMsWzKWKv(string heKwkYEM, int lGKjqiGIuzfMcW, string ffeaafWxTb, bool IRVLlZjCI);
};

string VRIROoLWKovR::iFKCHEeltwucq(int hnQPorrAKVzWrdT, double QHHXQ)
{
    string VPyfHfzElsORWLx = string("gFXzYjJMbYHWOVDVSqFHNOLPvaCW");
    double YyAJtcy = 575988.544179896;
    string EZRsbXLyY = string("bvPMtsWbWdrIumvYgpGhnoxgzhVUoPLpVkQfAebvnIdtcmoDWRMsjTPrRRAyKUUiIueCnUPHgrzgusNRavhAWjwtYKgu");

    for (int KgxOdQAMNIT = 1759676880; KgxOdQAMNIT > 0; KgxOdQAMNIT--) {
        YyAJtcy /= QHHXQ;
        VPyfHfzElsORWLx += EZRsbXLyY;
    }

    return EZRsbXLyY;
}

string VRIROoLWKovR::dElFhwia(string YNwDCcWRJUkX, bool oJxxFRAMUvLFKlo, bool AtZRdFOEShwOMS, bool BBydpJXZY)
{
    string iMxQhG = string("egtlCJfXwKZxnsauRSVmfvlQPapPyXumKUvrFbfkqtXjdYXbXZrdkfQhuwbqwFgLIaMYDhNEyUxiBrHjpnQWGItYseqjxZiBisPbipRRBhPuDFehMnNpyjipJhtrUitlwhbyOYSusrINKRRJwCYjJggzusOtcnByavSXdRCNWcfgNMPXPHiigLSJPGXlIHXDJyEKATBmtWCOljcqPlJFQrQTKIcNdBLoAPGQWyENVfUnwhoAiVLWCWc");
    int XDPkm = -106676956;
    int DKHfjwKExnpDL = 350347024;
    double bbSiCI = -795483.1723468802;
    bool graUvkjQFxi = false;
    int cHWZsgFoJD = 1336515895;

    for (int MfgjYj = 1640608836; MfgjYj > 0; MfgjYj--) {
        DKHfjwKExnpDL += DKHfjwKExnpDL;
    }

    return iMxQhG;
}

double VRIROoLWKovR::mkoka(int tLLWAwt, int XoXDLJeNH, int ONaYPoNjBb)
{
    string SVAGM = string("ttAuDuwJspXrGAcGdFbOWOsSlaZFAYKaUCQmpqOsQsVopzzxEPxUPDSRbLvTTFYEiwdytUJMyLApFqGLuIIhkRUGXBoTFDMUdUbAPMwRQGzGRXKPxKeqHzVOHnkNzxuQvVvGVLvGaLoElzLQJXYaQFMoJPXqQgKIRNLvPciCyHhMtbVXsSbcykShAFJsLcfnFAHEkbUgiSIJatIHZnmNYYyUwdkgjWwUxJfNITrAArlY");
    bool JIVCiZQSfRi = true;
    double ccibVRLZOGeIyt = -172667.55275988582;
    string XqUXHMyry = string("uIzwgBQqiQSEyHoDMLSgoxIkyvSIwcgDFzfrbYqAULSDnEseaqCpNcrQmqqKtOOCfnizQiiuVlkriVCDZkwYaEEJBhbhllyoNNlZHLISAmdMgEatpfucmjZSuAeSxoWIggmyUILSxVGTAlpLDTerQXlqhzlSQvXiVRNbXJktzrNhp");
    bool nqpqkbERGzwtBi = false;
    double wHWZpNbwhI = 219168.73300416677;
    string gEDfCzBzabbfV = string("ftIom");
    bool HRyyZcLNOF = false;
    double EYbxTbMbV = -129376.09810056012;

    if (gEDfCzBzabbfV > string("ftIom")) {
        for (int TRgsOMDOQbFPvP = 1096762970; TRgsOMDOQbFPvP > 0; TRgsOMDOQbFPvP--) {
            nqpqkbERGzwtBi = HRyyZcLNOF;
            wHWZpNbwhI += ccibVRLZOGeIyt;
        }
    }

    if (ccibVRLZOGeIyt < 219168.73300416677) {
        for (int yfgECUuYSY = 1735461707; yfgECUuYSY > 0; yfgECUuYSY--) {
            continue;
        }
    }

    for (int ogcVl = 1323062860; ogcVl > 0; ogcVl--) {
        XoXDLJeNH -= ONaYPoNjBb;
        tLLWAwt *= ONaYPoNjBb;
    }

    for (int GuSMN = 1863934298; GuSMN > 0; GuSMN--) {
        JIVCiZQSfRi = JIVCiZQSfRi;
        XqUXHMyry += gEDfCzBzabbfV;
        XqUXHMyry += XqUXHMyry;
        HRyyZcLNOF = ! nqpqkbERGzwtBi;
        ccibVRLZOGeIyt -= wHWZpNbwhI;
    }

    return EYbxTbMbV;
}

int VRIROoLWKovR::ijHBlV(double WyLjZHxQRLsK, double eERtCt, string lrUJnxfSelE, bool vOaVBIIGfF)
{
    string SXHvGP = string("RFywhNIBmFYFIfqrvXFYtgmRynNpKodZBTyOJsIACWSR");
    bool JvtfQuKOOVEGjATo = true;
    string xOpmTfE = string("VxJgpALqEITurOUmAgecAsAiVenFAFnocRWJETrZfnSNCWKpweQDqJgKqDJhIqivcuulfGUeZmBPgKrbJEETIJlYacsdFpfKUBNayTvmKoFjTUoxydwXiqLBOOmCokpNapMnyslwanvuuDITPDPOmgpLEBXlISqxkXUdrqTVGEkSZssqBrXbpJUsSDoQJRWIocXEosOCtfiCvjKsUfSeMzYePGvmXFCUollxZBWXpbWVYtmtxxqQDNkzfQ");

    for (int GGfhADa = 1257661235; GGfhADa > 0; GGfhADa--) {
        lrUJnxfSelE = SXHvGP;
        JvtfQuKOOVEGjATo = ! JvtfQuKOOVEGjATo;
    }

    for (int VZhtaykceALWjdZ = 915592139; VZhtaykceALWjdZ > 0; VZhtaykceALWjdZ--) {
        vOaVBIIGfF = vOaVBIIGfF;
        JvtfQuKOOVEGjATo = JvtfQuKOOVEGjATo;
        eERtCt *= eERtCt;
    }

    for (int EtUTnAp = 1137807407; EtUTnAp > 0; EtUTnAp--) {
        lrUJnxfSelE += SXHvGP;
    }

    for (int NrGDReVH = 1019258965; NrGDReVH > 0; NrGDReVH--) {
        vOaVBIIGfF = ! vOaVBIIGfF;
        eERtCt -= WyLjZHxQRLsK;
    }

    if (lrUJnxfSelE != string("RFywhNIBmFYFIfqrvXFYtgmRynNpKodZBTyOJsIACWSR")) {
        for (int uuFCNsRDVRQQ = 559193500; uuFCNsRDVRQQ > 0; uuFCNsRDVRQQ--) {
            SXHvGP = SXHvGP;
        }
    }

    return 141234344;
}

int VRIROoLWKovR::mNmWGUim(string Ewcwil, bool AzYRf, double NGPhxu, bool LXZszMDBZ, double PaUeQaIiRqltc)
{
    double sOTaVHj = -946054.797005189;
    string YaxrohllKKfnGFR = string("AIVUxziiVhgjUZXXvmuLvLlcHzAoruDHsTHnLnuxeTUoeaOgQFjKqnLwJqfprHqUVNkNpnOFbfIVupEuBshAiuabkjkEFpQmzhmaUXREFbDdqSgEwdgkSjnCCGrHLtuDIKPsgafICgqqvCH");
    double UHnqjxzA = 312743.9353797587;
    bool IrfWOVtqvRiqHfM = false;
    string vylMPCuFw = string("UbQdNJGmygwFiFEliJTwyCHMrQYIYW");
    bool roYBCJzxR = true;
    string TVPuZhzCSZhTY = string("jnvLzzpsMuifEWxDEqqxHtxiYCSykcIAYTgxufgBmgHiUpPtGtRzjjKXceZcIzMltOlXOzfOuhbgIAOERxGFszfCAAMTuoVbHEeUnIvWBRfEvsEVWJWxnlkUVUPCUmDOIzDVSTdErZgGGlLZWlCnlTnSDoGfFOfjojrlYvsurytpAWRabsOuBiKxhTZrfzwZlVXcIzPdB");
    double oOqBO = -312678.5456307448;

    for (int TYqTvYJJbDIqlMmD = 1517813473; TYqTvYJJbDIqlMmD > 0; TYqTvYJJbDIqlMmD--) {
        TVPuZhzCSZhTY += TVPuZhzCSZhTY;
        Ewcwil = vylMPCuFw;
        YaxrohllKKfnGFR = TVPuZhzCSZhTY;
    }

    if (NGPhxu < -946054.797005189) {
        for (int GEpFqONB = 992051691; GEpFqONB > 0; GEpFqONB--) {
            continue;
        }
    }

    for (int zQOmRk = 618341789; zQOmRk > 0; zQOmRk--) {
        vylMPCuFw += Ewcwil;
        PaUeQaIiRqltc /= PaUeQaIiRqltc;
    }

    for (int RjsvyM = 1176735374; RjsvyM > 0; RjsvyM--) {
        UHnqjxzA /= PaUeQaIiRqltc;
        UHnqjxzA += PaUeQaIiRqltc;
        roYBCJzxR = AzYRf;
    }

    if (YaxrohllKKfnGFR >= string("AIVUxziiVhgjUZXXvmuLvLlcHzAoruDHsTHnLnuxeTUoeaOgQFjKqnLwJqfprHqUVNkNpnOFbfIVupEuBshAiuabkjkEFpQmzhmaUXREFbDdqSgEwdgkSjnCCGrHLtuDIKPsgafICgqqvCH")) {
        for (int zuZWaoVCAfiPejNm = 487578674; zuZWaoVCAfiPejNm > 0; zuZWaoVCAfiPejNm--) {
            continue;
        }
    }

    for (int TlOxjgzWvGhiCmj = 410221464; TlOxjgzWvGhiCmj > 0; TlOxjgzWvGhiCmj--) {
        YaxrohllKKfnGFR = Ewcwil;
        YaxrohllKKfnGFR += TVPuZhzCSZhTY;
        roYBCJzxR = ! AzYRf;
    }

    return -1346977887;
}

double VRIROoLWKovR::WKvgWFnLn(string kiAUzGtl, double ZMBYQLfxjwSqn, string NVLwyNjj, int sqbtbuUft, string ArXagvsAzEFkW)
{
    double VRRkLNAdLnkSgAns = -163079.7721847854;
    int PiMHmGLyvPOFs = -1105245687;
    bool VpHBaM = true;
    string azzOVTckR = string("IDhITgAPJfDsSHZegIsaoljSbEkvZXEajGAwyKeZWGtZVmSNayZHrjQfaBDAjARcQEcHJVkamnDNNAYDMhTClzzeZBGdGCN");
    string cuEhj = string("XPTGVUhjbnScGueDjPUrRtHUNYKkZMvhleYXXFtPDshEOeNYXfvSLEaSLllsfZoevJGFT");
    double WVidAlMMMlQEv = 713996.9925090215;
    string BJMFPYnxJGIQeVMI = string("xdqBWADGcLVnpOliNkcIBzaCtbpPqOlRFczZTkWbvQOiXVcJbKlpLOAePDgLSwixsVosxEamuokqFmRiEBpNzDdblQfPvTq");
    int eXADz = 2004529769;
    double sEIdOjnYi = -898668.7393911305;

    for (int rCOJFwvsLfT = 2103485065; rCOJFwvsLfT > 0; rCOJFwvsLfT--) {
        BJMFPYnxJGIQeVMI += NVLwyNjj;
        NVLwyNjj = cuEhj;
        azzOVTckR = cuEhj;
        BJMFPYnxJGIQeVMI = kiAUzGtl;
    }

    if (NVLwyNjj >= string("XPTGVUhjbnScGueDjPUrRtHUNYKkZMvhleYXXFtPDshEOeNYXfvSLEaSLllsfZoevJGFT")) {
        for (int PMBoJsdjegWvSMf = 578831100; PMBoJsdjegWvSMf > 0; PMBoJsdjegWvSMf--) {
            VRRkLNAdLnkSgAns *= ZMBYQLfxjwSqn;
            kiAUzGtl += cuEhj;
            cuEhj += kiAUzGtl;
        }
    }

    for (int tALVyvfmyTnT = 663315557; tALVyvfmyTnT > 0; tALVyvfmyTnT--) {
        sqbtbuUft *= PiMHmGLyvPOFs;
    }

    if (PiMHmGLyvPOFs == 2004529769) {
        for (int YeUpYsFFDxzU = 581658776; YeUpYsFFDxzU > 0; YeUpYsFFDxzU--) {
            continue;
        }
    }

    return sEIdOjnYi;
}

int VRIROoLWKovR::KYRxzfniy(int TDUMagrm, double IKldcY, double jNplFueE)
{
    string iEkIePPVBP = string("uWUsQBggTeNEVfEpGmfEJmqwCFmsQqMUhYrkEcbJxiNYSJkBtvdYJMjOXkTlcgKNAirOESwSBLoZqEHpczGzEMhlRLywIBVePNUBYAiTHBXLjwdNYlWPBVOWOKCDhydEllJpDwwhkxRstkrTQVISollYDfzsllSdRaJkgawvwSXJqoreVWXvWRgnlnBIUZnTGrHIXySxPmHonMkswXfaYlhttAcDSIfIzTHYvjsWHv");
    double bionfzxCXORSc = -143371.72097478586;
    int ZTYXBiAJhpaVLL = 1329645414;
    bool WqBdTvBSstmTMTCJ = false;
    string XeSzIaUYYdTaChS = string("NDtJHbMZgLdAPMDGfpOFbPdirajprfJVlPlrMNrywFbgOnPpKmtleMZbvjfrgKdjCvhUbNHcYMyerWqethvxilzUsghRyyTouaNMCjWDxhvgVSqtumwXsXZokeipeVSR");
    bool emyAVroxISM = true;
    bool QpgaGK = true;
    double abXfrHypHqudG = -149569.30170879205;
    int OUvUvn = -10213060;

    for (int DiMdB = 48181147; DiMdB > 0; DiMdB--) {
        WqBdTvBSstmTMTCJ = ! WqBdTvBSstmTMTCJ;
        iEkIePPVBP += XeSzIaUYYdTaChS;
        emyAVroxISM = QpgaGK;
        jNplFueE -= bionfzxCXORSc;
        abXfrHypHqudG -= bionfzxCXORSc;
    }

    for (int ObGPMblvaWgO = 1681401785; ObGPMblvaWgO > 0; ObGPMblvaWgO--) {
        IKldcY = bionfzxCXORSc;
        abXfrHypHqudG /= jNplFueE;
    }

    if (TDUMagrm < -10213060) {
        for (int TBaxMpX = 731654759; TBaxMpX > 0; TBaxMpX--) {
            ZTYXBiAJhpaVLL *= ZTYXBiAJhpaVLL;
            TDUMagrm -= OUvUvn;
        }
    }

    for (int hNPDIzsuN = 1636252366; hNPDIzsuN > 0; hNPDIzsuN--) {
        OUvUvn = OUvUvn;
        WqBdTvBSstmTMTCJ = emyAVroxISM;
    }

    for (int TEsBWYxKx = 180888520; TEsBWYxKx > 0; TEsBWYxKx--) {
        jNplFueE = abXfrHypHqudG;
        abXfrHypHqudG += bionfzxCXORSc;
    }

    if (QpgaGK == true) {
        for (int ZNJxkLJClCbtyLO = 1760320456; ZNJxkLJClCbtyLO > 0; ZNJxkLJClCbtyLO--) {
            iEkIePPVBP += XeSzIaUYYdTaChS;
            bionfzxCXORSc += bionfzxCXORSc;
            jNplFueE = jNplFueE;
        }
    }

    return OUvUvn;
}

int VRIROoLWKovR::CKdYeYMBQ(string TXmWDvftreO, int caTxp)
{
    string OlDHYf = string("aEFlUkBChfsWkVXENKConryvOmtQpPIzUpDOWnXXSXaxpusBuEQzSCqrOSawsrloXpujCcRgwtoKEMSdgcVeYlRUoSbXJNhbMmJYWWwjJZHRsDG");
    string JWOxam = string("ZhAsQKfnWJjIMWtaslhYQrEVjKQzUErhvYFeZrZPszHYZJzcviQuFysxnpvpxhWlJtAGSlqLjNVFccDWDolxstnBJJpgypXVNpNGQDVxgaBvJzOwadBASJyuWUQqXUpRSkuOPWBlHmAxZnNOQxADxRrNLvMQUhgWfaoUSyB");

    return caTxp;
}

double VRIROoLWKovR::nLymjykxtqhg(bool siDPPzvxj, double CDjvpfAcyaH, bool orufFMiTB, int czjbeYzYKdfDqATz, string XDSpaGGhddlGh)
{
    double THNRVnE = -762176.3463513192;
    string KrHdFoIvhLbH = string("UJaiXHHqRWIdhKbQZAIyKuqqwOVMeOmcfjdtsSCyfoevIQkDRmwSvEFHwYBaSEwLJIMYWDwywkGFZTljQWZqeqkrCOWWuVIzWerfYYjhfcIbrDysFzWSLrXURxhcQyubSiuCwvELMnhCaNeynEvfeCYwsbRmqzUKbbYUpohKFjpvoJkEXMloyQyGpgGhOvRLWMRgItTUwvuNsMqzJqvIVQGSnKzjRoqXvSAauvBUFEbU");
    int vSMYbOTxNikvMZl = -1618425166;
    string LABuMtJfU = string("WGpoDVlhDAQUWwOmYVnxABaZnrHXXvcYBIjfXEnurqDAKDawFWRqHUCCWNRpVRDUisKoBPtraKrEsJjRVnppvbnuNcMsNVgVkgRgbwyDnVVhdloKIPSNZXdjYIIiNmBykHKVSJgAyKOohk");
    double SHVqbHWjg = -613749.3737105024;
    double rrGhcSdlRZTHxVcX = 124587.4340411463;

    for (int nUDvF = 1844962980; nUDvF > 0; nUDvF--) {
        XDSpaGGhddlGh += KrHdFoIvhLbH;
    }

    if (LABuMtJfU > string("NchFRLAUtbXQwfepdGjjBLpfFWnCnjiXiydhqsgwQNiVIQMnxgpwPauTBiEkYxmgdnneupSfORFUwyTIKCFMulSSUBoGhcMGaPvxUdohmWKbOQAcOmollbSFIxwWZmOeDHpdVyIYyBud")) {
        for (int OHzpzUCvfS = 93335805; OHzpzUCvfS > 0; OHzpzUCvfS--) {
            XDSpaGGhddlGh += LABuMtJfU;
        }
    }

    for (int lXdqpzlizBZUfn = 955351180; lXdqpzlizBZUfn > 0; lXdqpzlizBZUfn--) {
        orufFMiTB = siDPPzvxj;
        THNRVnE /= rrGhcSdlRZTHxVcX;
        LABuMtJfU = XDSpaGGhddlGh;
        rrGhcSdlRZTHxVcX += THNRVnE;
    }

    for (int KjPskCEfm = 1582169209; KjPskCEfm > 0; KjPskCEfm--) {
        continue;
    }

    return rrGhcSdlRZTHxVcX;
}

void VRIROoLWKovR::oMsWzKWKv(string heKwkYEM, int lGKjqiGIuzfMcW, string ffeaafWxTb, bool IRVLlZjCI)
{
    double allXN = 865107.2819277312;
    string tzhtqd = string("pEDOakjNXBwrNiVjdDLjLyTwKyupZKbkwDtSLJhQJZAeCxsxcYexfzdzpWTDLJgiUJrOjWBOFV");
    string HznLryGMrkSi = string("TskMFuVohbjhJbuoFOovcSOhfZkpnetkGgMyxodDYdHnpDwRfvSFNsKYEHCtaADEBNfPvthVztvEHvYhGSkCZBFwAQnRaRhLznVWtDusUzLXkZoqPEiAtunYHOzJufyqcMhldiViMdmYlhKDUQbDwTLuOuzxyRzddQINyZczNshfjjVuKeljbGSPeYnYCDCFsbJFFrhehkcccesQSsTVQUNpvglhheJFobM");
    int fmAmYKpYfW = -1862159671;

    for (int ZxCRKEKNUAdGVTa = 203531091; ZxCRKEKNUAdGVTa > 0; ZxCRKEKNUAdGVTa--) {
        continue;
    }

    for (int BayyfXcTHUUzM = 858380736; BayyfXcTHUUzM > 0; BayyfXcTHUUzM--) {
        heKwkYEM += tzhtqd;
    }

    for (int lNLfWbYKEaiyxTDw = 1006978587; lNLfWbYKEaiyxTDw > 0; lNLfWbYKEaiyxTDw--) {
        ffeaafWxTb = tzhtqd;
    }

    for (int cMwvoXQrMIFLWlv = 1388881112; cMwvoXQrMIFLWlv > 0; cMwvoXQrMIFLWlv--) {
        IRVLlZjCI = ! IRVLlZjCI;
        HznLryGMrkSi = heKwkYEM;
        tzhtqd += tzhtqd;
    }
}

VRIROoLWKovR::VRIROoLWKovR()
{
    this->iFKCHEeltwucq(1001269492, -1038490.5039160544);
    this->dElFhwia(string("PwfHJXXMqcfBWfodIUJjBgCCBLEgpGduTwbbuOwmXhkxTokwoSUEpfXHpWOAIxRkLUddidTNCbJMQnHFmhNBpAaZbwOSqcJOphKZusNumQeuoQvuB"), false, true, false);
    this->mkoka(1340725500, -1126991440, 1186747801);
    this->ijHBlV(-896414.8255241736, 25034.162696295458, string("kFWOsYpANcjIQqZxcunVWKurKAHrzgyRIdTCibCuxXzmpNYhjbvnBOSeqCyiYQdCavcKZYmVmUYgFGMffzddAqsLMCSOofRUHvbAFlAOHkPIqHEfzoeqKWdhDXHpnXdSIsiHixElhsfuXIKrkmmjIwRkPQrIkkbMDGjAXyAkWoyZBEDkbt"), true);
    this->mNmWGUim(string("ZFmPDlsSnhBVlnetktMYycRLgIQWhkolsmdqqxCYYMQsYnuhmusHVxSUGTiKmntAuwLdhNSNBObBPVncWGmBhKDExTCSXITZsnizgsNvhtPJXfNArIDpOKBdWeNrYHIimLIhnXelEnBSMPqPrFfpRzPaCwBOUiOfXXLVslVXFnKYMpkszipFwGARySjmYFhIItji"), false, 392905.8041161199, false, -971349.9137482548);
    this->WKvgWFnLn(string("nYlznLTzDwAHC"), 890425.50659902, string("pBEKGlSfRlvhntKavTjNDzhnpUlOYTVQKEmHdpwznRzDSumFAFMAMfncJRLSShUABnItamujsvrPZKGArTxQWtSQxfkztDwQROvupICkgqNUiyACwjaoPFdwYMuMVKOiUyjdbPWyumgKvozpzgQWmyRHxinrHjhGVngJznqgpYteyffMipLaNOxfZdmlQGEsTgxfYbfFntJWKkSicjreLtUWrszBcUgNImTroKdhoWzTPysPJgTNkdLDVTLi"), 1669947252, string("ElMCkqpTssednxhTAxzbqUzYMEFKTakOeFCceJLrPgsKhlRQDQmsbiUDiDuaxAEwILWEOCnWsBzMuUPTUuFOlgIFSJblQqmUBIZpzMQzOoNslFTiIeciwHuaHuxXFKlmWvihLxKTFUMAAiEOJLnkkZYcPGFkTVcjIXigACXfeMCTeySbuVIsxIHCZ"));
    this->KYRxzfniy(-491892405, -618318.8487046018, -621063.0143868641);
    this->CKdYeYMBQ(string("wBOcGSThQBjKtuEkuunXOZBInVOpYGLsnGezamvaxmUOtusiJBDVULBDphuJSvuHLPqYomBTTjTYJsImAgWeCnZtVpCLTIcffpuXHbRdHkAQjMoFIHGfXaJrjSxCbzgcDISyBweLjdNFvVEfQFJPfnHTJEYvtpPyVhqiviNCoIWYfXGLxqBxMPtuVvJzuWOKZlVNjwqNNzgzvtBrgKaqwwsdEYujzbbHGlbGGfAMcGzKeyOY"), 552701902);
    this->nLymjykxtqhg(true, -190034.58883767985, true, -2000063987, string("NchFRLAUtbXQwfepdGjjBLpfFWnCnjiXiydhqsgwQNiVIQMnxgpwPauTBiEkYxmgdnneupSfORFUwyTIKCFMulSSUBoGhcMGaPvxUdohmWKbOQAcOmollbSFIxwWZmOeDHpdVyIYyBud"));
    this->oMsWzKWKv(string("kAyeFrgGZqtuGUzGADmbLFYGrMiYFhXlPKoKRoBUKpgWMmuOemPxiThWIRpBbJZuClcHSoCMlBSEqdQzqdEhqUNncorwLEBSyBWRxraVpsvwFLOJzBVDsYXEPqdlTUfixfvPLXg"), -871112227, string("irdBckNmrNMXWlxHXCRUMhnJxNVceoWixePLtKECDDbFzoaOwVwMEFFKjxMobbGEYGbaqLblBGgNnOUZJrghBfawhBABBPgxVeicYisOnGaoOjWMYEvCgzATmHlaYRCDiTwUvylqDCfSNGsMSvSbBVrkvzluKfi"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XlUthUaeFWDeus
{
public:
    double lcRftGNqdIji;
    bool KPKrwx;
    string JwFTHUuePO;
    int IOkoLkZ;
    int BisvKIzGNa;
    string TfuQLVevgdZxo;

    XlUthUaeFWDeus();
    int uXOFQM(double GYJHI, int OGmMzsAVml);
    void KETiILPPTLIZmqe(bool vzvmdPeJcBcWplG, bool CNOHAiJAftVvY, int MwUfQSrcZPsaQhb);
    int sVUOL(int iYqqmMyFnL, int cVpHVVYZsbtJ, string ZpYdCzBk);
protected:
    double dtYgbUqIdF;
    string vcbHJR;

private:
    int NMdwioFoK;
    int qnofZacDYLtWdIFu;
    double moHwaItbwxrkKFdL;
    int eITgt;
    string eegZQeROt;
    double stFafkvrgOgoTnw;

    void eqEZF(bool MdJCPzWBHJR, string arCYVY);
    bool CKHgW(int wOBgwfSTTjWJO, int wOqMRGUibKZzvcl, int wLSbURqUMTy, bool XexGTP, bool vcmVRyFrPZzEt);
    string KOmEFLIzdrBsuzM();
    double XAtiZXCbKmlQLlV(bool IKfjgsoC, string nUxZOxUZHUdsySk, int COnTpOtIHyql);
    int IbHEgQfoAYO(bool DMpvSik);
    void dBZkCCOGas(int IgfWfQZatpOxMWe, string iIHTyxG, bool DumooEL);
    bool evGzfOCUydwkASYv(string dwqhokGVxHfyhd, string zLwkr, double EkuVKPEPEhRWg, bool tstvUJQFbU, string jbnGVimSD);
};

int XlUthUaeFWDeus::uXOFQM(double GYJHI, int OGmMzsAVml)
{
    string qKjjDjRMBARm = string("HFbhYZQlvDtEwCDDwpDUHCGIjKuPWfkdpnGJviUUWefnVIEUdCvEdrnwKYecXWYDxDcSvVgZaVgCFetUuPUIkSgq");
    bool VOiNlztGfLkDR = false;
    string wSUoBadgswajVmn = string("GwzwxoYWTTxKNzLxMRQLfpeRwPyTiRufaneVCuNnPWWz");
    double XPFvPJGIZQuyl = -164580.53448584757;

    for (int CoJFh = 1321384793; CoJFh > 0; CoJFh--) {
        qKjjDjRMBARm += wSUoBadgswajVmn;
        XPFvPJGIZQuyl += XPFvPJGIZQuyl;
    }

    if (VOiNlztGfLkDR != false) {
        for (int bsqiNGuOkXYvOw = 771794805; bsqiNGuOkXYvOw > 0; bsqiNGuOkXYvOw--) {
            XPFvPJGIZQuyl -= GYJHI;
            XPFvPJGIZQuyl -= XPFvPJGIZQuyl;
        }
    }

    for (int lFgPpy = 205254608; lFgPpy > 0; lFgPpy--) {
        XPFvPJGIZQuyl = XPFvPJGIZQuyl;
        qKjjDjRMBARm = wSUoBadgswajVmn;
        OGmMzsAVml -= OGmMzsAVml;
    }

    for (int ESCzM = 1675004451; ESCzM > 0; ESCzM--) {
        wSUoBadgswajVmn += qKjjDjRMBARm;
    }

    for (int qOulniL = 304995021; qOulniL > 0; qOulniL--) {
        continue;
    }

    return OGmMzsAVml;
}

void XlUthUaeFWDeus::KETiILPPTLIZmqe(bool vzvmdPeJcBcWplG, bool CNOHAiJAftVvY, int MwUfQSrcZPsaQhb)
{
    bool DjuVlKnyt = true;

    for (int NwSaEtDbsWXgBcg = 559023289; NwSaEtDbsWXgBcg > 0; NwSaEtDbsWXgBcg--) {
        MwUfQSrcZPsaQhb *= MwUfQSrcZPsaQhb;
        vzvmdPeJcBcWplG = ! DjuVlKnyt;
        DjuVlKnyt = CNOHAiJAftVvY;
        DjuVlKnyt = vzvmdPeJcBcWplG;
        vzvmdPeJcBcWplG = DjuVlKnyt;
        DjuVlKnyt = CNOHAiJAftVvY;
    }

    if (DjuVlKnyt == true) {
        for (int gHhiUX = 1692755409; gHhiUX > 0; gHhiUX--) {
            CNOHAiJAftVvY = ! CNOHAiJAftVvY;
            CNOHAiJAftVvY = ! DjuVlKnyt;
        }
    }

    if (DjuVlKnyt != true) {
        for (int QngtVYOxnmD = 2142572116; QngtVYOxnmD > 0; QngtVYOxnmD--) {
            CNOHAiJAftVvY = ! DjuVlKnyt;
            vzvmdPeJcBcWplG = ! vzvmdPeJcBcWplG;
            vzvmdPeJcBcWplG = CNOHAiJAftVvY;
        }
    }

    for (int QvJIwFA = 1436151802; QvJIwFA > 0; QvJIwFA--) {
        DjuVlKnyt = ! vzvmdPeJcBcWplG;
        CNOHAiJAftVvY = ! DjuVlKnyt;
        MwUfQSrcZPsaQhb *= MwUfQSrcZPsaQhb;
        DjuVlKnyt = ! vzvmdPeJcBcWplG;
        MwUfQSrcZPsaQhb += MwUfQSrcZPsaQhb;
        CNOHAiJAftVvY = vzvmdPeJcBcWplG;
        CNOHAiJAftVvY = CNOHAiJAftVvY;
        DjuVlKnyt = CNOHAiJAftVvY;
    }
}

int XlUthUaeFWDeus::sVUOL(int iYqqmMyFnL, int cVpHVVYZsbtJ, string ZpYdCzBk)
{
    string XaApXtqIRWTBzfqx = string("qtMQTVYkGkOEynrVcPycLavBrUtfRfApqxcFuujAYTIiRlUMeZIiGhFphTveHknPUVYSCxeYBBhpuMxPsjrngIOCZcplxnLzlWyKGkuVTDYtBAWaenYckPIjbtfedyuCLvBlawGBkIwsDeEPxGnlGxmxEyqmczclPKgQEcRExSTwtgjnBCDxNxvlnolPcAJGEnJIoESrgxMeqxpEGTK");
    string SRbhpIVUPPzJLb = string("lKwiQKtMhDRJFUreBSfhTYiTEsOOUZtAmemOrjzAJLnwTtkLhdajXYhEeHSnkUhVCzpygPnUGaLkegBzVfIbQbNwgmFZUyIylejbfjogKhqnXzWykaqzOySWoiAgYj");
    string mHbzT = string("NbmUlWUrQyfcilGGIzoVLqsKiaUyKOllrYTPSmiJqsXsZkBoZqOYoMqSVdNpakjSNnSNLoUwrCWgnEnBQapgfGslkhwhANitRGIDecElIoiRAxqjhMYxfcefVLPSllJjIhoQKHcJhhpYqQEQGYisRYDokFEhdvGoWTAZPVVFWXSaVfxJGUTckZNFoaymePAEYljRpQfDzJfzXVYUQFKtaRPWepVTtAUIsT");
    int CVnEbcddeZRbNE = 2002709898;
    double NvSEGqWHsAuQ = 1041289.5305986004;
    int MzAUeFxJw = -1814207650;
    string apempRVgNQPh = string("QYitGyYnLMlbYbAeUVBZPSDyxuTrJzJpRAWKEkvyEsuXGtZWSucMspJaDdzECXWCeIoqQRzUdEeKRbTXUXWhsBvwBtJxnUGYqpcWhCsPeicCWcpqZGTAhldthKfJMBvriZHjeXkyPzXCYEcZLAucYscxGepEeHRtsyNApkuyRWeYlkTomHUGiK");

    if (CVnEbcddeZRbNE == 340181346) {
        for (int mmDCfCNUgJL = 1512897184; mmDCfCNUgJL > 0; mmDCfCNUgJL--) {
            ZpYdCzBk += SRbhpIVUPPzJLb;
        }
    }

    for (int vgqaIfIYfbFyOeb = 1931436148; vgqaIfIYfbFyOeb > 0; vgqaIfIYfbFyOeb--) {
        continue;
    }

    for (int cbYxu = 285813189; cbYxu > 0; cbYxu--) {
        iYqqmMyFnL = iYqqmMyFnL;
        iYqqmMyFnL /= iYqqmMyFnL;
        iYqqmMyFnL = MzAUeFxJw;
        apempRVgNQPh += ZpYdCzBk;
    }

    return MzAUeFxJw;
}

void XlUthUaeFWDeus::eqEZF(bool MdJCPzWBHJR, string arCYVY)
{
    double gpsfeGg = -355978.4573340144;
    bool zVaknuHnJo = true;
    double jOmLkXR = -362489.50072960247;
    string kxRgREZmsIQDYepm = string("ARXlztMQPIhidzvxkRcgdwwHlNAAijAWZmetGbwcMzdsTLYoNKrcXfUIaCvJyvtNpFVbzfAhdk");

    for (int QqlNYRG = 1329267332; QqlNYRG > 0; QqlNYRG--) {
        arCYVY = arCYVY;
        MdJCPzWBHJR = MdJCPzWBHJR;
    }

    if (MdJCPzWBHJR == true) {
        for (int sJvZAADpxBwUnh = 162871635; sJvZAADpxBwUnh > 0; sJvZAADpxBwUnh--) {
            zVaknuHnJo = ! zVaknuHnJo;
            gpsfeGg += jOmLkXR;
            jOmLkXR /= jOmLkXR;
            gpsfeGg += gpsfeGg;
            jOmLkXR /= jOmLkXR;
        }
    }

    for (int nuuAULZTnADkDQ = 1413067215; nuuAULZTnADkDQ > 0; nuuAULZTnADkDQ--) {
        MdJCPzWBHJR = MdJCPzWBHJR;
    }
}

bool XlUthUaeFWDeus::CKHgW(int wOBgwfSTTjWJO, int wOqMRGUibKZzvcl, int wLSbURqUMTy, bool XexGTP, bool vcmVRyFrPZzEt)
{
    string cESIXtzCiGb = string("DteIStFnmcdYHzDsjLLKKxCdDHoJyIbHbmzyEqGzGUAPDPUzeidpFbZiVuOEjCQGSYqwdTuhzhQnxFLWFUwiHwHQciirshQeyVecrfBXTargCvgImuGzLWICGXBthxsMweuctQFVXOrFhTcmxkPKDflbQbkAJEUVgFyXLmdxRfEGvSpmygvfQVttfdogyMHWuYnQzNlcestDJfiS");
    double FAYcnY = -633240.4056089073;
    int vRKqiesoruEDxRZa = 1599701777;
    double yZfaGAma = -684002.7473134559;
    bool mJfyBrGyzPiA = true;
    double ekGkZStK = 821270.5019469361;
    double tUTWSkGCetZR = -226475.26903349976;
    double NNUVZCDZmG = 84543.2075261113;
    double BIcDOzZUiGL = 131772.29430227086;

    for (int glGYoJTiGHI = 982880564; glGYoJTiGHI > 0; glGYoJTiGHI--) {
        BIcDOzZUiGL += FAYcnY;
        ekGkZStK += NNUVZCDZmG;
        yZfaGAma *= tUTWSkGCetZR;
        yZfaGAma -= NNUVZCDZmG;
    }

    for (int kMsczXWFkBBphuF = 647782587; kMsczXWFkBBphuF > 0; kMsczXWFkBBphuF--) {
        NNUVZCDZmG /= NNUVZCDZmG;
        NNUVZCDZmG += BIcDOzZUiGL;
    }

    for (int CloGMCek = 316863357; CloGMCek > 0; CloGMCek--) {
        wOqMRGUibKZzvcl *= wOqMRGUibKZzvcl;
    }

    return mJfyBrGyzPiA;
}

string XlUthUaeFWDeus::KOmEFLIzdrBsuzM()
{
    bool sjVkLij = false;
    string yHYIhZuBpxA = string("JFFXSJEluToIOyXutjMfczTCutNfoGIGpLyJuxoqpVuYEJATpnyVmsvrcdZzUzKOsfGFajIEMIFJQolrfCpKqbtIdXjBCZcWQLMyNiqapUIKpCTnajIqqoosITlErRZerafipqWiO");
    int VUZQEeIJwgyvwqGS = -568816168;
    double vfPbWgfBYL = -815692.95272646;
    double CFLjjh = -867497.9570759906;
    int deaAuSgpdbavBYaR = 1733475564;

    for (int MGbfUGzGWjJTpICl = 1196648126; MGbfUGzGWjJTpICl > 0; MGbfUGzGWjJTpICl--) {
        yHYIhZuBpxA += yHYIhZuBpxA;
    }

    if (deaAuSgpdbavBYaR == 1733475564) {
        for (int dQRlILfKJHTdiE = 27524506; dQRlILfKJHTdiE > 0; dQRlILfKJHTdiE--) {
            CFLjjh = vfPbWgfBYL;
            yHYIhZuBpxA = yHYIhZuBpxA;
        }
    }

    if (CFLjjh >= -867497.9570759906) {
        for (int adxmTcH = 1084817635; adxmTcH > 0; adxmTcH--) {
            CFLjjh /= vfPbWgfBYL;
            deaAuSgpdbavBYaR = VUZQEeIJwgyvwqGS;
            VUZQEeIJwgyvwqGS -= deaAuSgpdbavBYaR;
        }
    }

    for (int LcULVhzE = 420319933; LcULVhzE > 0; LcULVhzE--) {
        vfPbWgfBYL = vfPbWgfBYL;
        CFLjjh = CFLjjh;
    }

    if (CFLjjh > -815692.95272646) {
        for (int bmtOEWsDbqnGJ = 1550598726; bmtOEWsDbqnGJ > 0; bmtOEWsDbqnGJ--) {
            deaAuSgpdbavBYaR *= deaAuSgpdbavBYaR;
            CFLjjh = vfPbWgfBYL;
            deaAuSgpdbavBYaR += deaAuSgpdbavBYaR;
        }
    }

    return yHYIhZuBpxA;
}

double XlUthUaeFWDeus::XAtiZXCbKmlQLlV(bool IKfjgsoC, string nUxZOxUZHUdsySk, int COnTpOtIHyql)
{
    bool SxxauPEzjzsFwgy = true;

    for (int qpDeQD = 1049175427; qpDeQD > 0; qpDeQD--) {
        continue;
    }

    return -792910.7446931518;
}

int XlUthUaeFWDeus::IbHEgQfoAYO(bool DMpvSik)
{
    string KTzYcQ = string("InHGllFbPUktEHzeJrWVwfuPIrqqzLuYCJJmAjbuYapZItKqnXLkzFkypbSnkXqmQnqbGrjqeMiCdiHGAjMMCUlMCgVNguCSbzuendYbdKerLsTSBeWAuszzLnGTWtwdlUoedzejDlgDIUNdodgUokGEKTXmdxKhJtmayPCdfZmWqLxcuzlDsYgUVnrIDNseIhczuJQdLvnYzss");

    if (DMpvSik == false) {
        for (int tgwCeEEIXJCNNF = 797132533; tgwCeEEIXJCNNF > 0; tgwCeEEIXJCNNF--) {
            DMpvSik = DMpvSik;
            DMpvSik = DMpvSik;
        }
    }

    if (DMpvSik != false) {
        for (int xSgSgmrLqaeMC = 1918362480; xSgSgmrLqaeMC > 0; xSgSgmrLqaeMC--) {
            continue;
        }
    }

    for (int cRoXRuyW = 2131077723; cRoXRuyW > 0; cRoXRuyW--) {
        KTzYcQ = KTzYcQ;
        DMpvSik = DMpvSik;
        DMpvSik = ! DMpvSik;
        DMpvSik = ! DMpvSik;
    }

    for (int wOJJVUAeChgZAC = 760211773; wOJJVUAeChgZAC > 0; wOJJVUAeChgZAC--) {
        DMpvSik = ! DMpvSik;
        DMpvSik = DMpvSik;
        KTzYcQ += KTzYcQ;
    }

    return 2082068159;
}

void XlUthUaeFWDeus::dBZkCCOGas(int IgfWfQZatpOxMWe, string iIHTyxG, bool DumooEL)
{
    string TKTllGIJvd = string("irvkGDLejLNdFxiHxIUUBhpztCUJukTVEILWfGWrNXpSzXrjiyoToCHANsYGNzdHooSnmKrKiduHTZbWSdhEGfVuCfdCOBaABJcqVifbvLspXalQdEuUTrEGkySQbrTOpcWZYBWQMncuRwuKwnVDTDgEKlivvRwGCXVHPziVhKjVHlOHFDwfzbQMmpGaeVWClJzjicOuoZwsjTKUnlBrOcESFeWHEQPCvSgLCRsCNrxExfYeMMDivcpArjRQkhI");
    double ceiHuBYYqbhz = -221286.70052308016;
    int rVvYAZvrz = 472980774;
    int mIKGlSucFQGMA = 450302315;
    string GxtsyMgLpfJo = string("IHxmHvvxnXgtdeggoViclOUhwosAMPYQWObGETvUnDwTxdSkcrTZzdqmWUWmjqRzjFnrDjbNllKqbospIyFFXMXAACZTyYDgKvKuVfKtNPHMKwoZFMAPFbYGDNzmBxRkAbRZ");
    double xTpDiEYlJnjYN = -37001.25189693395;
}

bool XlUthUaeFWDeus::evGzfOCUydwkASYv(string dwqhokGVxHfyhd, string zLwkr, double EkuVKPEPEhRWg, bool tstvUJQFbU, string jbnGVimSD)
{
    int RimrUWBffppK = -1352049445;
    bool pHQNGziDwgySv = false;
    double FgIYJH = -181172.1279533638;
    bool BakWhOAMMBkrAvB = false;
    double ieujCCgOfP = -691841.6202949014;
    int qYouMoRsBUoWm = 1814241700;

    return BakWhOAMMBkrAvB;
}

XlUthUaeFWDeus::XlUthUaeFWDeus()
{
    this->uXOFQM(-311726.11712956725, 131993135);
    this->KETiILPPTLIZmqe(true, false, 511663545);
    this->sVUOL(1316308729, 340181346, string("uYPWgjlGtLAEpodmGtJKlkYkddDpdqnngATcXRWvuFHroRWUppvBFjgArSzDXhUaqxNenoSKpVnQiDgWtgeTonVfeKdzSoQfoFaspmrTYFzKyUQEfmVlIbtDsAZEjLjYmgcbPJLCMaqeQvSonNcCxbhChFGtsOXkFYFotLQFFZgInahaJdmaiOZYTgXNPfxgUhmlVKPszwsSrWalThBmuYtcsQXgCVgWfOGwcnBguFKfFMFbvhRNOiVOrFaQ"));
    this->eqEZF(false, string("LhLQCB"));
    this->CKHgW(-1717858944, 785433104, 1688589865, false, false);
    this->KOmEFLIzdrBsuzM();
    this->XAtiZXCbKmlQLlV(false, string("HzBBKsOaSdFJLZnUvuQhjPepyCmxUWZtXqiROWcTPbOBCCxpdbCgWlSSCAHgVZqSymoLAzbyjbpkbiKEQpfaKVmEVCnxgjCpUBwZOOMIcwOURWCNqtxeBtrMDmHwOmwfHEEERlcbdFsiPcQYcrCRRpTJpqvVphMkOUCnwnmxhPLKXerbAJYtJrSZoYRXhbIKqJXKoXolgjOdinkNJJogSUIHrVbiAgNmYFhgUWrnJRnRtqwnxgIsOOURyNWXaW"), 825609305);
    this->IbHEgQfoAYO(false);
    this->dBZkCCOGas(211485732, string("WW"), true);
    this->evGzfOCUydwkASYv(string("gaxyNGafVwdpgfdOYEboWxkTQazeTkS"), string("nDeVAKoukZWZzlOWDVkWOywtKHEwxxaVfNMAXJOwdFELolZMZCvXDChorFJRICtEbLFBTlXrqchSIli"), -954938.0874760599, false, string("MxxdroNukaTLnWphYAnoNmUlpgoNyuzLVCrVoOXblkRmgKtDdVkyKrkhmTrfHMIoNTqWMFBL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nYWFvLDAq
{
public:
    bool ojFPv;
    bool HEOGszVg;
    string hAsWIPMoQZ;
    double xekEJhPtPow;
    string CKucbgTLN;

    nYWFvLDAq();
    string KqVFKMjEkTl(bool gGKZokqe, double RdWzQbATiYvOK, bool LjQLROCOHnbKawK);
protected:
    double eTqMs;

    void rWlNCsSJgdkL(double cFELuSk);
    bool fkhEYAkwJvPkm();
    void MRlYHJbYZdDFS(double XdeRdUicDFxP, double bGauJeTnNgvKjyM, bool yrdZvfSwWWM, bool skyOh);
    bool dXkhlykL();
    bool qTQTycTQO(string RsfMJmAP, int xdTlmgDIaXcNnpW, double UMstUydfoJCyltS, double QJRBhdzLRaF, int hlVSVFBcnt);
    void YTPBgPC(bool jWhFDdtcDPyzoV, int CrIIm, int LLpJOt, int VtLuCQ);
    double uQqgqTbBJNkAVn(double ymYabiPgrTBp, bool ptbTaJGUG);
private:
    int aaKBLKNkxgOKr;
    double USXPUAhbuoidmxkT;
    int ncymhWBT;
    int uJVbWnXDgPNAP;
    int lQWaGSUHpOA;

    string qgxdDaGIULIbI(string MdFcoTwpq, int FEXgHPNUIa);
    bool IElaGUnrf(int egXpke, double lXjTdFHsK);
    double vMLfXGYduZrKcfX(bool QunkmekLmXfJxp, bool blzUWmA);
    bool nqkSCbBKu(bool MUsvytR, string kuBfxC, int TavtWGbMJIpGeNip);
    void QHZsQYWm();
    void YjOojmwWALl(string npwQULV, bool oCOdhifjLVRoVDtE);
};

string nYWFvLDAq::KqVFKMjEkTl(bool gGKZokqe, double RdWzQbATiYvOK, bool LjQLROCOHnbKawK)
{
    bool uhQcDq = true;
    int XSTExRQ = 104274938;

    for (int NPzrZtUyfZvBHrbN = 1823598399; NPzrZtUyfZvBHrbN > 0; NPzrZtUyfZvBHrbN--) {
        XSTExRQ *= XSTExRQ;
        XSTExRQ *= XSTExRQ;
        gGKZokqe = ! gGKZokqe;
        uhQcDq = gGKZokqe;
        uhQcDq = LjQLROCOHnbKawK;
    }

    for (int pAIZz = 1065625011; pAIZz > 0; pAIZz--) {
        continue;
    }

    return string("kZLvIukoDoBaIoTcJYvwwQBxjEwEUFMehpYrjtqWrfKRYTzHEgwVIdPbiazSwalxhhkJIBduFoaSMNugZLPqCJrYEydGDdOfgDDVftpMwybAXfjzvnUPnObpqNNJQZmQrTicfgVcwrtzoV");
}

void nYWFvLDAq::rWlNCsSJgdkL(double cFELuSk)
{
    string NHSZcykcSCW = string("TNPBMpMbdIPtDnYHakrimyCevWvuvbpsekeqNLsCHnDnscwybfARWmKxrMPpUOAhwOxSpJKXUsHpfFKYyekhwrJVoeKRHJAdDUbYfZIpgNymeDytkCVaZpWTytaHslWboFJycmCmWeHhuOQQBwmBZmkdCqYWhSIsWjESNuzquUmwFZmtBWgCiuSkMMqGhqnupWDSOCskYtMOiUqUsgjM");
    bool pDxRDD = true;
    int CpZBPOA = -1984354780;
    int vmRJXfNrEuPmj = 129865222;
    string QvXBMS = string("hKVQYYWaDsBiYNdUBdXWEsXUeHptVhLhPxhQMcawIokcOuVdduVkyEsMvPYsivhwYgrgmSzLhXhUtHydeHjVWSxfwSTf");
    int ddLOmA = -1146336582;
    double utrICbFGzz = -8135.146538511817;

    if (ddLOmA != 129865222) {
        for (int XNlrKmf = 564857860; XNlrKmf > 0; XNlrKmf--) {
            vmRJXfNrEuPmj -= CpZBPOA;
        }
    }

    for (int BZAnldPwUjoB = 574501845; BZAnldPwUjoB > 0; BZAnldPwUjoB--) {
        vmRJXfNrEuPmj *= vmRJXfNrEuPmj;
    }

    for (int xNiZE = 1836227222; xNiZE > 0; xNiZE--) {
        CpZBPOA -= ddLOmA;
        ddLOmA /= CpZBPOA;
        NHSZcykcSCW = QvXBMS;
    }
}

bool nYWFvLDAq::fkhEYAkwJvPkm()
{
    double xFIkZKUE = -407019.0650383187;
    double QOjMYeRYUhwh = 343657.9562335595;

    if (QOjMYeRYUhwh != 343657.9562335595) {
        for (int cCNFDIjyup = 776925372; cCNFDIjyup > 0; cCNFDIjyup--) {
            xFIkZKUE /= xFIkZKUE;
            xFIkZKUE -= xFIkZKUE;
            xFIkZKUE -= xFIkZKUE;
            xFIkZKUE -= xFIkZKUE;
            xFIkZKUE -= xFIkZKUE;
        }
    }

    if (QOjMYeRYUhwh < 343657.9562335595) {
        for (int usXCZk = 359496675; usXCZk > 0; usXCZk--) {
            QOjMYeRYUhwh *= QOjMYeRYUhwh;
            xFIkZKUE -= QOjMYeRYUhwh;
            xFIkZKUE = xFIkZKUE;
            QOjMYeRYUhwh = xFIkZKUE;
            xFIkZKUE *= xFIkZKUE;
        }
    }

    return true;
}

void nYWFvLDAq::MRlYHJbYZdDFS(double XdeRdUicDFxP, double bGauJeTnNgvKjyM, bool yrdZvfSwWWM, bool skyOh)
{
    int WHVlXbFpA = -1109001703;
    bool tDJnAnrXrSDc = true;
    int aIshdIuo = 313201091;
    bool WJegIWWBjxlmVXGD = true;
    string Yeoum = string("IKienPsUFDXQvxrkahMEtOJtzvjMUffczvnffxOeIIhJPMElklMHhBC");
    double qscVBpvnLYnZ = 938803.8719652203;

    for (int fPEcitv = 349373704; fPEcitv > 0; fPEcitv--) {
        Yeoum = Yeoum;
        yrdZvfSwWWM = ! tDJnAnrXrSDc;
    }

    for (int orOYfsesLaNF = 1778358654; orOYfsesLaNF > 0; orOYfsesLaNF--) {
        qscVBpvnLYnZ += bGauJeTnNgvKjyM;
        tDJnAnrXrSDc = ! WJegIWWBjxlmVXGD;
    }

    if (aIshdIuo > -1109001703) {
        for (int qFAZXudO = 1105033063; qFAZXudO > 0; qFAZXudO--) {
            tDJnAnrXrSDc = WJegIWWBjxlmVXGD;
        }
    }

    for (int ilqKp = 1762440689; ilqKp > 0; ilqKp--) {
        yrdZvfSwWWM = ! skyOh;
        XdeRdUicDFxP *= bGauJeTnNgvKjyM;
        tDJnAnrXrSDc = ! skyOh;
    }
}

bool nYWFvLDAq::dXkhlykL()
{
    int xHeKoGwXfXyLrLH = 329423876;
    double WkGzdObtFfBVfqa = 376426.94790636544;
    double utJfEfHrK = -168024.2429602924;
    double WYVbUqtGExaKXF = -338397.84125766775;
    string iyPpHqKRjUa = string("epdHCPrSxXgdGufsOaJhWvDhfXNBMShudOVhUwFwlFSShriwR");
    double DzgJmmUYIUuyCzWx = 806185.6325977755;
    bool uwHLYOignOgRfhd = false;
    string eOThTmnDVZ = string("sVNzYFNNxCjNQFpahCQS");

    for (int IMoTqvmOvFkPlCk = 1170143158; IMoTqvmOvFkPlCk > 0; IMoTqvmOvFkPlCk--) {
        DzgJmmUYIUuyCzWx /= WYVbUqtGExaKXF;
        WYVbUqtGExaKXF -= utJfEfHrK;
        DzgJmmUYIUuyCzWx *= WYVbUqtGExaKXF;
        DzgJmmUYIUuyCzWx = WYVbUqtGExaKXF;
    }

    return uwHLYOignOgRfhd;
}

bool nYWFvLDAq::qTQTycTQO(string RsfMJmAP, int xdTlmgDIaXcNnpW, double UMstUydfoJCyltS, double QJRBhdzLRaF, int hlVSVFBcnt)
{
    int DHnGjoiqdxA = -736372702;
    string guppflqcBpPNsuG = string("lIFlEIjCXOHxgqeSCMdNwWIcmbrCtkRfbflePAmZYAnDcEZrcBtQxhzOUCTZhJtYJmNbBEz");
    double ubWEUAmtHiq = -640031.6816854615;

    for (int ZhGzhQi = 1499999496; ZhGzhQi > 0; ZhGzhQi--) {
        QJRBhdzLRaF += UMstUydfoJCyltS;
        hlVSVFBcnt -= hlVSVFBcnt;
        hlVSVFBcnt /= hlVSVFBcnt;
        RsfMJmAP = RsfMJmAP;
    }

    return false;
}

void nYWFvLDAq::YTPBgPC(bool jWhFDdtcDPyzoV, int CrIIm, int LLpJOt, int VtLuCQ)
{
    bool jNQvmdnf = false;
    bool JcgEFwUAupNFUp = false;
    bool zEJrd = true;
    string biWGN = string("cEQGpXoJUzDLEWuanZyFNHeDa");
    int TqZAXIclENi = -1947845007;
    string juBrgeIQ = string("HZTQxlEMMgztSMHTfdPlrYxFoqSvLXxFeyyBflhrNwNRBdPvuJWPDrCYSoRwBwpbgiFEijbXqgsMZJYkZvUGashY");
    bool vgishoXQrWcxo = true;
    bool WjuUdJvrdWzYpy = false;
    double lxhOKnXHZpMv = -564650.2098066915;

    for (int EssgfYYYvlF = 653001671; EssgfYYYvlF > 0; EssgfYYYvlF--) {
        continue;
    }

    for (int AWAfaLY = 741599014; AWAfaLY > 0; AWAfaLY--) {
        jWhFDdtcDPyzoV = ! zEJrd;
        WjuUdJvrdWzYpy = JcgEFwUAupNFUp;
        LLpJOt = LLpJOt;
        vgishoXQrWcxo = zEJrd;
    }
}

double nYWFvLDAq::uQqgqTbBJNkAVn(double ymYabiPgrTBp, bool ptbTaJGUG)
{
    double FxfsZwlFZugMQvi = -883236.8194605071;

    if (ymYabiPgrTBp == -218352.98919978182) {
        for (int DPRybbx = 925907216; DPRybbx > 0; DPRybbx--) {
            FxfsZwlFZugMQvi *= FxfsZwlFZugMQvi;
        }
    }

    for (int XXCwwVuBHbCr = 2081823433; XXCwwVuBHbCr > 0; XXCwwVuBHbCr--) {
        continue;
    }

    if (ymYabiPgrTBp > -218352.98919978182) {
        for (int xCGqWbWKg = 857817038; xCGqWbWKg > 0; xCGqWbWKg--) {
            ymYabiPgrTBp = FxfsZwlFZugMQvi;
            ymYabiPgrTBp /= FxfsZwlFZugMQvi;
            ymYabiPgrTBp -= FxfsZwlFZugMQvi;
            ymYabiPgrTBp /= FxfsZwlFZugMQvi;
        }
    }

    return FxfsZwlFZugMQvi;
}

string nYWFvLDAq::qgxdDaGIULIbI(string MdFcoTwpq, int FEXgHPNUIa)
{
    bool yvslViMWofbNtUbH = true;
    string GmkzY = string("yydtHzvCOVFxlrvcyWPBdFHHLAAZstZViAmTJmGVBKOScnoAvfuLbKZIhsZxZ");

    if (GmkzY > string("yydtHzvCOVFxlrvcyWPBdFHHLAAZstZViAmTJmGVBKOScnoAvfuLbKZIhsZxZ")) {
        for (int UXNZzSPUFHOnZUu = 3565584; UXNZzSPUFHOnZUu > 0; UXNZzSPUFHOnZUu--) {
            FEXgHPNUIa = FEXgHPNUIa;
        }
    }

    return GmkzY;
}

bool nYWFvLDAq::IElaGUnrf(int egXpke, double lXjTdFHsK)
{
    int hhFQeVVxvt = 1425080369;
    bool IXXvKHuqDVxsb = false;
    bool fAwPKUXQxd = false;
    string EISOJKwDzdD = string("iotwgGMgyraSRshRwhhbqThOclOhdSpNkQAGhVsoJvrmnHqzBZfmhkyXcDEpoOFgbgeYfXTwpCOpkJYpXeEGcoGMzobCUOwpviibJmBRfClnKlBepIiErIcCKsozesjQRkeCKUWGfBVrPykDsuwWsYngxtezBjxFvmKXJ");
    string EFyKgthixXd = string("zozjkKAENgaRsrirucyDmSouBWIcKmNgbNTpSYkzQAOgMUIMgzGZhuXDvYSsUSLYMnDvivDiDJASIMReINomYWQrIfVmAtMaRkrremWYQDhhlTLgKtcHytctZtimQZXPsTnStNkAKmWuoQlzmRRPyPTQpzGXvcEtDxHSXQARhazfuRclUfYXpfrajXDSAbSAYAtMSTgxTRIYYxDAFgrDHlvcWtbgdrVgbrxFnFZhlAoVMYRUwmNOuCOVxUFsa");
    double txPQuDpbTa = 888473.645467019;
    bool URQnLiay = true;

    for (int mVwTOVdczDlT = 1726682902; mVwTOVdczDlT > 0; mVwTOVdczDlT--) {
        URQnLiay = IXXvKHuqDVxsb;
        IXXvKHuqDVxsb = URQnLiay;
        fAwPKUXQxd = fAwPKUXQxd;
    }

    if (EFyKgthixXd == string("zozjkKAENgaRsrirucyDmSouBWIcKmNgbNTpSYkzQAOgMUIMgzGZhuXDvYSsUSLYMnDvivDiDJASIMReINomYWQrIfVmAtMaRkrremWYQDhhlTLgKtcHytctZtimQZXPsTnStNkAKmWuoQlzmRRPyPTQpzGXvcEtDxHSXQARhazfuRclUfYXpfrajXDSAbSAYAtMSTgxTRIYYxDAFgrDHlvcWtbgdrVgbrxFnFZhlAoVMYRUwmNOuCOVxUFsa")) {
        for (int OxlRF = 1763101962; OxlRF > 0; OxlRF--) {
            txPQuDpbTa /= lXjTdFHsK;
        }
    }

    if (fAwPKUXQxd == false) {
        for (int eFbgokzDgFn = 1350878229; eFbgokzDgFn > 0; eFbgokzDgFn--) {
            continue;
        }
    }

    for (int TsGWcdQThuL = 1499495933; TsGWcdQThuL > 0; TsGWcdQThuL--) {
        URQnLiay = fAwPKUXQxd;
    }

    for (int pbDdWi = 707714723; pbDdWi > 0; pbDdWi--) {
        hhFQeVVxvt -= hhFQeVVxvt;
        hhFQeVVxvt *= hhFQeVVxvt;
        hhFQeVVxvt /= egXpke;
    }

    return URQnLiay;
}

double nYWFvLDAq::vMLfXGYduZrKcfX(bool QunkmekLmXfJxp, bool blzUWmA)
{
    string IfAiETna = string("sIiiYsamejPcijyiemXbchNtMuqM");
    int QpkUGL = -860787134;
    string xZyxfzxDlDc = string("ujhVuaQNlqWgGnaltQBtODwQkmECdMOvaCiTMQCPRBQAHGhqgQzbfeBzepSvjuybpbMxmGSTwVuabnIGpTDCUrntWGTSzLvdtswEYncIZrs");
    bool FllXmnRyIFuHpf = false;
    double VNwuVwkPs = 690433.7627527216;

    for (int PIjMkOCdY = 1995328132; PIjMkOCdY > 0; PIjMkOCdY--) {
        FllXmnRyIFuHpf = ! FllXmnRyIFuHpf;
    }

    for (int WHBULiR = 1001499152; WHBULiR > 0; WHBULiR--) {
        continue;
    }

    for (int yTrMzJzijzxeDK = 745409679; yTrMzJzijzxeDK > 0; yTrMzJzijzxeDK--) {
        continue;
    }

    return VNwuVwkPs;
}

bool nYWFvLDAq::nqkSCbBKu(bool MUsvytR, string kuBfxC, int TavtWGbMJIpGeNip)
{
    string OCfvnzDoiXjzOa = string("SJNhPzAfMBAfnfobMFQKSXLmQIHmTpjPLGllnIFeJKYdmFyHHDSPUQyqfoKJBajMOuiwyIZOWBKXRYHToiViGtCyTQnYAuQqJVMCvDffKuCsOWpWRzfJoqOiiPIHWGgRWSMuAVuqCcDVlVZrLamtIzESZdCkniyjjqYevwFAEchllXozujnKQQBuljlwUGcvzVaQTrx");
    bool IScmstwIfbguT = false;
    bool AQRJoKsCy = false;
    int aOKddeTRZE = 1194996707;
    bool NHdtqNx = false;
    double NiNWagWjQAtwFEO = -155240.45582018956;
    double AeERKhaSA = 816955.8918868917;
    double YYdraDUMm = -898560.284858385;
    bool kCFGxn = true;

    return kCFGxn;
}

void nYWFvLDAq::QHZsQYWm()
{
    double IOptlZiojYkAfDr = 779169.4940196255;
    string iTayaz = string("cXPQSYIwwLDVInENkkzTcEovyNUvRqEEPnNmQnkCMJbfJWevWzDUqQsNQLWlfmTExXudMaoKAqetvaREIUVBQPYwdrwjztdByLnsFEwmYZrRtokRqYmhAVOQuttPmmZCRPYDGwZjBl");
    double nTNLToktFWnyCjcv = 270758.8272916047;
    bool PSRdRJHtWedT = false;
    int RfjBTRMFzFmuZDZ = -17021288;
    bool zmejaUWVIsYuo = true;

    for (int egtUHXiUyUOid = 1414757180; egtUHXiUyUOid > 0; egtUHXiUyUOid--) {
        PSRdRJHtWedT = ! zmejaUWVIsYuo;
        RfjBTRMFzFmuZDZ /= RfjBTRMFzFmuZDZ;
    }
}

void nYWFvLDAq::YjOojmwWALl(string npwQULV, bool oCOdhifjLVRoVDtE)
{
    bool kwofzCNYbsafi = false;
    bool CPXoLaqxYZswa = false;
    int IvqhHlQFKxMzUm = -1572870544;

    if (kwofzCNYbsafi == true) {
        for (int BeQFVOSHFC = 1366135022; BeQFVOSHFC > 0; BeQFVOSHFC--) {
            npwQULV = npwQULV;
        }
    }

    for (int dKBDfcNAfS = 2033126034; dKBDfcNAfS > 0; dKBDfcNAfS--) {
        kwofzCNYbsafi = CPXoLaqxYZswa;
        oCOdhifjLVRoVDtE = CPXoLaqxYZswa;
        CPXoLaqxYZswa = oCOdhifjLVRoVDtE;
        oCOdhifjLVRoVDtE = ! oCOdhifjLVRoVDtE;
    }

    if (CPXoLaqxYZswa != false) {
        for (int PLzAOiwtVDUr = 539854098; PLzAOiwtVDUr > 0; PLzAOiwtVDUr--) {
            CPXoLaqxYZswa = kwofzCNYbsafi;
            CPXoLaqxYZswa = kwofzCNYbsafi;
            CPXoLaqxYZswa = oCOdhifjLVRoVDtE;
        }
    }

    for (int NUVccFQ = 666985203; NUVccFQ > 0; NUVccFQ--) {
        npwQULV = npwQULV;
        npwQULV = npwQULV;
        npwQULV = npwQULV;
    }

    if (oCOdhifjLVRoVDtE == false) {
        for (int ozKytqynHdSz = 28006198; ozKytqynHdSz > 0; ozKytqynHdSz--) {
            IvqhHlQFKxMzUm = IvqhHlQFKxMzUm;
            kwofzCNYbsafi = kwofzCNYbsafi;
            kwofzCNYbsafi = ! CPXoLaqxYZswa;
            IvqhHlQFKxMzUm *= IvqhHlQFKxMzUm;
            IvqhHlQFKxMzUm *= IvqhHlQFKxMzUm;
            CPXoLaqxYZswa = CPXoLaqxYZswa;
        }
    }
}

nYWFvLDAq::nYWFvLDAq()
{
    this->KqVFKMjEkTl(false, 806262.8209550821, false);
    this->rWlNCsSJgdkL(-418934.80397762154);
    this->fkhEYAkwJvPkm();
    this->MRlYHJbYZdDFS(717789.2776476681, 416816.25851184037, true, true);
    this->dXkhlykL();
    this->qTQTycTQO(string("ddOvJyPuhRpVrxqesFDXelzhSgiwGxWQocHiHEoeYXpZAaQMaHXFgHIGrlIdByTKJGjyJHsPVJCQqlcQGUOLzRuVFpOOJMpLruJoiRaWcRYXPALOYCdzyIiAvSJMFseLekktGFKdwcQdzQBBKbAVjXRPRlIiOyuBDxCLjoRIxrcYLNKakfwWfwrWORNRRMpHrCUDTAAaIkTEMVYBKnqtSRJsJux"), 1345430374, -137035.23246173898, 486999.63048885285, -478810218);
    this->YTPBgPC(true, -2107106392, -1817111937, 487689973);
    this->uQqgqTbBJNkAVn(-218352.98919978182, true);
    this->qgxdDaGIULIbI(string("ZxDVbVIeLtPaEwIISYTiEBkzSUhFovsoDBdBvuvZpdiajDtSmmzIfrvQozMYZETRAoEycIxdRAPcebYUbYCWzAWO"), 1786577968);
    this->IElaGUnrf(-2002110136, -93810.81503558313);
    this->vMLfXGYduZrKcfX(true, false);
    this->nqkSCbBKu(true, string("eRsPGKbVogHslqUmhKrNZHBkzvdvcMzGVlYMnBoCjLPObWeoLRKJpHaSBJCtqoSZUkTWqEeXwBeuJgNtRLvawpRICPOJBktYsTvXGOuGqSALlUUBvRYeEuzaUnsnAckgYPuMCbwkZIepVHJHEXzgJDGzlLbNNDCYgUWrkOojvFwSoUhEphNLjnOJcLNoopwYMFOQUWAzyGghmHnAkPLUdBKXO"), 1943339239);
    this->QHZsQYWm();
    this->YjOojmwWALl(string("BPjoemZwhdgzZghLJBbjTRGWeLinqKyySRsbnFIyHHuCXThEPDgzGozKVWxKyWfagWKzsPYn"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hPGGUaQzbjM
{
public:
    int kMzGE;

    hPGGUaQzbjM();
protected:
    bool imrIuZb;
    double ZfTLHZ;
    bool GTFdR;

    string qmzPbtkvg(int fFToOddwS, string kmRorkTq);
    string tICfnlrtRbfZ(string SywGqnGzVGQen);
    bool JTUyTvxulIgwEsLM(string loMnCPYTewkkwfA, int UoNytIW, int OElQy, bool jzGImPpuU, int NOpMXQpalbN);
    string OrNvUuAh(string NxkQRBEOFBPdVT, bool rITgm, bool NCTueaXlwpAUgqV, double jslseVyh);
    double QvAdQcYR();
    bool BVUXjoiA(int DuUXDJHwZ, bool dXHAxtXuAxXekJ);
private:
    string PKGYCPT;
    string mQdtITRxbZZWvwXc;
    double TLoWrpIEhJ;

    bool LJlnwitrA(bool tKmRocI, bool sZpcWoKbMqhT);
    int cMdlNxrUh(int FItSXUTmiWoQthBY, bool YIvCphmJo, double vwhwiotTHMo, bool TnLnLCOY);
    double ieSqOR(string mrMIaGfLZEzGNBtE, bool oBVjHhvJsdHhTDbg, bool sCNFrxxFFI, double KNCkfqGVBGP);
};

string hPGGUaQzbjM::qmzPbtkvg(int fFToOddwS, string kmRorkTq)
{
    bool NdMnMNb = false;
    bool dEDaToLVuIrQTw = true;
    bool FtCyPhkeZ = false;
    string ykdVSRStE = string("GxfMluddTgAbqNXWFhLFokCopbcrmonyvzEjS");
    int qiaHzdEbdh = -664288294;
    int HyYwltcP = 1681563003;
    bool bJXgGha = false;
    int iktaCzZA = 1608529524;
    double HkogsMxJXL = -859375.7112209244;

    if (bJXgGha == false) {
        for (int wTtGAnkvAQs = 1134568490; wTtGAnkvAQs > 0; wTtGAnkvAQs--) {
            dEDaToLVuIrQTw = FtCyPhkeZ;
            dEDaToLVuIrQTw = dEDaToLVuIrQTw;
        }
    }

    for (int XrZVBKxP = 543013843; XrZVBKxP > 0; XrZVBKxP--) {
        continue;
    }

    return ykdVSRStE;
}

string hPGGUaQzbjM::tICfnlrtRbfZ(string SywGqnGzVGQen)
{
    double nIVassOuPq = -664568.292365505;

    for (int xIfmyEmGmTzMi = 1018149152; xIfmyEmGmTzMi > 0; xIfmyEmGmTzMi--) {
        SywGqnGzVGQen += SywGqnGzVGQen;
        SywGqnGzVGQen = SywGqnGzVGQen;
        SywGqnGzVGQen += SywGqnGzVGQen;
        SywGqnGzVGQen = SywGqnGzVGQen;
    }

    for (int sMUglnxWCEuzO = 1909366588; sMUglnxWCEuzO > 0; sMUglnxWCEuzO--) {
        SywGqnGzVGQen += SywGqnGzVGQen;
        nIVassOuPq /= nIVassOuPq;
    }

    return SywGqnGzVGQen;
}

bool hPGGUaQzbjM::JTUyTvxulIgwEsLM(string loMnCPYTewkkwfA, int UoNytIW, int OElQy, bool jzGImPpuU, int NOpMXQpalbN)
{
    string QPLQylkUbvpEKgZ = string("qWlPsYoQSSOleYOWLoknXxQxxsbRozQaIPhfEQhtlFoDTkNNshgAWRjxlPNbgBhPhqGRsXWNYHVbATFrsQaAPuusePQtQALIipKLBtHbXAuXktTLARITrOctRzSOOamXgtPYCpxXCyNlaeGPSCLukx");
    string efqfXybewWinGJx = string("cXRNxTxnXwPqEOIlGLDnMgTGBqwnORCOnchKOuAnkdbRKHKElCqtbGeP");
    int rzvaGcxXZDa = 1204522248;

    if (QPLQylkUbvpEKgZ == string("qWlPsYoQSSOleYOWLoknXxQxxsbRozQaIPhfEQhtlFoDTkNNshgAWRjxlPNbgBhPhqGRsXWNYHVbATFrsQaAPuusePQtQALIipKLBtHbXAuXktTLARITrOctRzSOOamXgtPYCpxXCyNlaeGPSCLukx")) {
        for (int FpMeAirSEhbcnHA = 1392699209; FpMeAirSEhbcnHA > 0; FpMeAirSEhbcnHA--) {
            NOpMXQpalbN += OElQy;
            OElQy *= UoNytIW;
            NOpMXQpalbN = UoNytIW;
        }
    }

    return jzGImPpuU;
}

string hPGGUaQzbjM::OrNvUuAh(string NxkQRBEOFBPdVT, bool rITgm, bool NCTueaXlwpAUgqV, double jslseVyh)
{
    string mYKVUeIEtPNM = string("tKZzyoITSdFoZnHCzArBTNdlZfcLXgPVYBwnwmdZtNoGCeCcgwUFVQvBkzXqapuZxUqCRYIwVraWnmdgmqjeEDgzICvZ");
    string SDyyBvIQxpfum = string("DpvRkJhrAfNrajsvsLoAutlOxBxxDDmooxYMDZCzSaoiytMLgdfpdlJXYFdpBiutDCWQiCHRUqnJhdfxLWZWywcGwqYdEbvIJcmXKvJEyvCDjhhnqdIUyRlVqvQbaOinvjLfUghMKkzpRLHpNdqvtvVOYVytJsxgCaapThyPodJpFlDgcxULytKYrocAtHPhyDSFykBgQyElprP");
    bool EtoQAHg = false;
    string aGHgKGx = string("IlzNWyGfQMysrsrNSjCRFpUbphBRajNRvBqvFvGdzelKCoMdBWoldlxwiTaxqCuxvH");
    double eukBYK = -392574.8861825452;
    double FuWUjTSjJRyayuj = 11637.385481432433;
    bool lsveWN = true;
    string FJgaAdnbe = string("ZQGtuTMUwHjIfeoBoYpDbLSBXVkxPnYhpEkWLrhTNBtIRxYpIGwVknLzalExEvpDrBpVZtyHCZPuByiqmFgokdVocnGSmggmAeOMnGBLwmlCIYcvvaJhPwASEVZsMasiyJFDjpDwibfFDlqbhSzaUlndVHJwWtNrMXJfWBvUxZtdraFhDoTtqktL");

    for (int qiIGECtgqwOt = 259355372; qiIGECtgqwOt > 0; qiIGECtgqwOt--) {
        lsveWN = ! NCTueaXlwpAUgqV;
        aGHgKGx += aGHgKGx;
        SDyyBvIQxpfum = mYKVUeIEtPNM;
    }

    for (int PzLuqZnvyhHRaRTE = 1017879446; PzLuqZnvyhHRaRTE > 0; PzLuqZnvyhHRaRTE--) {
        SDyyBvIQxpfum += mYKVUeIEtPNM;
        rITgm = ! EtoQAHg;
    }

    return FJgaAdnbe;
}

double hPGGUaQzbjM::QvAdQcYR()
{
    string UqeXHFNh = string("nkzDfubENnIULaGJeCFPOpqDihlWVQUBBMNiWfqTHyVUnXkYAdlmJTUborHNgRTgcyqJGyNpRNTREFXdBnszIBnvcXJkEqtBWpOrpYGQlxyurERCxcIXYwMLgfJzXhXWJIiwxtmkoqbHXRaLyJnsMFNEDtmYlHWKldqVXRVQZIwkFacBYo");
    string PizIv = string("AmnIjwYTrUTdANavVYNqTkYXDukZUClskEdrZYpCgFMZODuHByyreBbZAfjIWqizIxuFozZiLHXaq");
    string uayADt = string("gYySwcQrsPllkfDfWyXmWxMeFfVreuKvTethyHAPeDORlRBhSPwSXJzcpNWLTxRagOFUZZjShWaNWwGEnPssFWblKPKgQWuDVvCHkPPebHRmhpXfLOtScjWbwBgZiOppvSyDRAnJpIREKxcuzYEIUfiZgJuugUigDbfVToxFXSEShOLyaBjXzGgKLzElWyocpDXvCEqtecsHalNrdMJUTeNKDOVlqqliENGzefIQYAwjwhmtYozFDRPSJtZFw");

    if (PizIv < string("AmnIjwYTrUTdANavVYNqTkYXDukZUClskEdrZYpCgFMZODuHByyreBbZAfjIWqizIxuFozZiLHXaq")) {
        for (int zLoByFEkaTyvt = 1259931595; zLoByFEkaTyvt > 0; zLoByFEkaTyvt--) {
            UqeXHFNh = UqeXHFNh;
            UqeXHFNh += PizIv;
            uayADt += UqeXHFNh;
        }
    }

    return 124070.71801335283;
}

bool hPGGUaQzbjM::BVUXjoiA(int DuUXDJHwZ, bool dXHAxtXuAxXekJ)
{
    bool kQiAQDekxJpt = true;
    double lOQJrGSbl = 209497.80535203847;
    bool aiBzRsvbcVbz = false;
    string MWkeD = string("VEWqdFrPAXhMFCprBuwGMrXPbJghhtqfetkSfoxPGbTulpwVstweftkeRImThitpeIPniXuGJjIrxMnXnGIzHjkFiEZshtFwAAvxUMkzGEcRSwWsDgzYPhiwPCLMNFogiuewUSMBhbHBQgZEC");
    bool toxFEO = false;

    if (dXHAxtXuAxXekJ != false) {
        for (int LIBhuCiwLen = 543115784; LIBhuCiwLen > 0; LIBhuCiwLen--) {
            toxFEO = ! toxFEO;
            aiBzRsvbcVbz = ! kQiAQDekxJpt;
            toxFEO = aiBzRsvbcVbz;
        }
    }

    return toxFEO;
}

bool hPGGUaQzbjM::LJlnwitrA(bool tKmRocI, bool sZpcWoKbMqhT)
{
    int kKNfucq = 1777708584;
    double gPZjiSVSdUFwoXOD = 909680.2737864858;
    string dATuNRGTAM = string("ezBmNLrHlfjUgjXFbdTntSEhlORIIlvDxdCUYVlHPmKwWuKceBqVejUEkCUmuYSNrVOgVCAdjGBbtRDXHWlZuXKqGvYmystQKmWxLIhjYrmaPBHZSPIVCnOUnYcFpuvkXEPvIkpaNsaETzNwSslJBokNKZnqvekGVlXmAGcRIbqMqdMoWBxaGVbcugqGbHWjiyaxroCyMjGGKJLXDSSkwMm");
    bool HJzcZtcUjcus = false;
    double cosQSlscjzJA = 307953.7090909695;

    for (int VvTvAGhAMCs = 1929367729; VvTvAGhAMCs > 0; VvTvAGhAMCs--) {
        cosQSlscjzJA /= cosQSlscjzJA;
        tKmRocI = tKmRocI;
    }

    for (int VDNAOCZgaN = 1087600379; VDNAOCZgaN > 0; VDNAOCZgaN--) {
        tKmRocI = ! HJzcZtcUjcus;
    }

    if (sZpcWoKbMqhT == false) {
        for (int UsUGapCRyfzgep = 1878578070; UsUGapCRyfzgep > 0; UsUGapCRyfzgep--) {
            sZpcWoKbMqhT = tKmRocI;
            kKNfucq += kKNfucq;
            cosQSlscjzJA /= cosQSlscjzJA;
        }
    }

    return HJzcZtcUjcus;
}

int hPGGUaQzbjM::cMdlNxrUh(int FItSXUTmiWoQthBY, bool YIvCphmJo, double vwhwiotTHMo, bool TnLnLCOY)
{
    bool jggeGatGBjO = false;
    bool tjBzkRNK = true;
    int PdUQaqM = 2083540055;
    double RwFwXp = -655443.2377655101;
    double EUVufMbpjPZGF = -639.0847178661735;
    bool wnFyDEuGzFiu = false;
    int hzQENSZDfKQtalz = 1320314177;

    for (int VyiEreHmcSDNqIg = 162681903; VyiEreHmcSDNqIg > 0; VyiEreHmcSDNqIg--) {
        TnLnLCOY = wnFyDEuGzFiu;
    }

    if (RwFwXp > -655443.2377655101) {
        for (int PItyLvh = 1291098456; PItyLvh > 0; PItyLvh--) {
            YIvCphmJo = jggeGatGBjO;
            YIvCphmJo = ! wnFyDEuGzFiu;
            PdUQaqM /= PdUQaqM;
            wnFyDEuGzFiu = wnFyDEuGzFiu;
        }
    }

    for (int SZyJxZeHJQYK = 547584553; SZyJxZeHJQYK > 0; SZyJxZeHJQYK--) {
        YIvCphmJo = wnFyDEuGzFiu;
        wnFyDEuGzFiu = tjBzkRNK;
    }

    if (tjBzkRNK == false) {
        for (int DRDhkKT = 1310012006; DRDhkKT > 0; DRDhkKT--) {
            EUVufMbpjPZGF += RwFwXp;
            hzQENSZDfKQtalz += hzQENSZDfKQtalz;
        }
    }

    return hzQENSZDfKQtalz;
}

double hPGGUaQzbjM::ieSqOR(string mrMIaGfLZEzGNBtE, bool oBVjHhvJsdHhTDbg, bool sCNFrxxFFI, double KNCkfqGVBGP)
{
    bool dWIEgucJkuGK = false;
    string AIWelWYdlP = string("GXyYCvbQHhSNmaBiodYZvfQurchLsKUMGABpJyPfFoPmaVGHTOxeSnZGZzSSOBCNnJTWEtqdlIiXIcEitiVeIQHbEcgvTmypAsLCEihbPjcXMKcwecLdzlgZuHpHsQyeoTCWAKTwZhbrRCWrURfvcaocdeTPdLPLdyJDAcAWWHbD");

    for (int bqbzgQIcLKBto = 1114758640; bqbzgQIcLKBto > 0; bqbzgQIcLKBto--) {
        mrMIaGfLZEzGNBtE += AIWelWYdlP;
        mrMIaGfLZEzGNBtE += AIWelWYdlP;
    }

    if (dWIEgucJkuGK == true) {
        for (int tdcjWJcSYAUGe = 1990105465; tdcjWJcSYAUGe > 0; tdcjWJcSYAUGe--) {
            sCNFrxxFFI = dWIEgucJkuGK;
            oBVjHhvJsdHhTDbg = ! oBVjHhvJsdHhTDbg;
            oBVjHhvJsdHhTDbg = ! oBVjHhvJsdHhTDbg;
            AIWelWYdlP += AIWelWYdlP;
            mrMIaGfLZEzGNBtE += AIWelWYdlP;
        }
    }

    if (oBVjHhvJsdHhTDbg == false) {
        for (int XAXtohzsWOdMCq = 656020339; XAXtohzsWOdMCq > 0; XAXtohzsWOdMCq--) {
            dWIEgucJkuGK = ! oBVjHhvJsdHhTDbg;
        }
    }

    return KNCkfqGVBGP;
}

hPGGUaQzbjM::hPGGUaQzbjM()
{
    this->qmzPbtkvg(1969772659, string("FrnEblfjvGahhuUtoIwzdVqYFTJDEzRMxaydomtiYpNQIJsHobhPeZqrgPYODyoTmJFcmIOcYgBILLMYCpfilLiLZBJEVtvVkcppYOhxbktSiJpsZAsKmDuIcEvrfonjWvGtUVyAKRcNBZo"));
    this->tICfnlrtRbfZ(string("DEocvVCWWWjJKdnFHHlFzJjdkKyHTqdHNHRdqanLiPqcpvpjWCWGeQbhBoneZJEcOmFPAEpJzavXzinIjMtKNAsbVuApkwwSSQxERtvtBxvWdRVtmcaCdEznlVgtJqlSjRyTMDmcvUxRtChnfyBlfDXQBGENUDouaEMYnqxhBEstOEGAOqZouzXYWMGmqWesCYQpgwGTZXKzQobCrAZrLccnVWjVogkRDcyXFPlbkUlSRYnJ"));
    this->JTUyTvxulIgwEsLM(string("KtIZhYtjwDDBJdPeYvaQFekgsheVBXmoYozVNKtHFZWGFJcNTairzowrrNExBZWCqcALbsYxvRpyOQgQaaUjDfjQJjHMKffOMpsNGXxyxMmiYZYtLNFAdUDmaBbSDDvUqPSrFMlddOSUkPzLOsUBQwrodqsdyXegONiXrOiScjDHbhAiEYDehdIQjsHmZK"), 563146795, 1002281719, false, -576659287);
    this->OrNvUuAh(string("OesFgrtJdElhrvyvSBmJEkvtXhlmjlCXLfokiEAgFEMZiwmHCQCZSyEwHXVYTD"), false, false, 709416.0116247333);
    this->QvAdQcYR();
    this->BVUXjoiA(-226109059, false);
    this->LJlnwitrA(true, false);
    this->cMdlNxrUh(-1613444894, false, 64323.14499866262, false);
    this->ieSqOR(string("dfcQuicBznfQageXTcZgTUzMmwTFvSxFyNdASrTgUjEkvoHVQAdbwruuAFIQHwmodsponnRfZHwkhrqZTnsaDixDeddvuUJiuptOrdSYDnwsxtztoyJyReVOyXvfRFONogwqKdJoOWrZaeEHzefZPIbKCFvJOcjpxppUmPzbE"), false, true, 817333.6605147024);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hYzHzJuKgiPHGrHd
{
public:
    string MoqoreTJwmd;
    string DOkDTvfO;
    string qfZImqyiy;
    bool stHjKcswXtLPtD;

    hYzHzJuKgiPHGrHd();
    int wXhojFOaGY(int NVsoYjjlqVGGsb, double eDAgluL);
    int ifLbszKchDe(string ocCNMawlsS, string aWeaO);
    double fvkBJEgss(int HDQbvigHiyKBLNOM);
    string saMZT();
    double FDjvbTGjskpuNZls(int SBDBg);
    bool Ghfne(string JejTAdlJASUs, double DZWiRuq, string pzMFCehFhiviwsuv);
    string PANeuNeYCHC(bool DSHqvKaaVAm, string YgvOnSNeBxFMkka, string XnwiQtYHuhmcwlwn);
    void VHEMXdQnIjv(string PKfRunbNpxIQ, string dyuUWMlU, double qadLllYZOUUWsXdS);
protected:
    bool BzqWJCETsDtonGb;

    string qnDPGqOl(string CYiLrGMcroV);
    int RlBRRKxrXSM(string EVcqNjoKHLtzwOA, bool IDEVmMrXyZUJOb, int FxIXyUU, string DYbDrWYXWe, string QArjEmYz);
    bool fuizi(bool VWNAJsYcDvyY, double EEMuUiAMdeKA, int qnEdyqneFZyHvmr, int PMHFlkokrZcrCF, string UFEKUkAz);
private:
    int nsDkA;
    int cQezaqPdW;
    bool CTjXKJCPnEFjPdzR;

    bool wqPHPISZ(int sSBEHEwrvCJuO, string atVLfL);
};

int hYzHzJuKgiPHGrHd::wXhojFOaGY(int NVsoYjjlqVGGsb, double eDAgluL)
{
    string FzpbtHDgwZyxWN = string("siMIwLOZYxZWaxZYtLfxajbPlNeooykFlqWUvuJrucfQdebjPhmxInitrdrjTBmsQZNQNIleUlKwgIMyQxhbtebCRkuTlmgfkpJFQVjlxmZxRpXVpmCNOIGuwralFSTHbMTUCWYZRfmwIXHZoctHEjtgGxQqTzDqaOYbAQHvKftWayUAxsOmaVeUWJFImnuRvlSfkOHPPjvuBWNbEaXqEFjAblrONDIzFerNMFcGEUKrNmXIQaVnDRUeC");

    return NVsoYjjlqVGGsb;
}

int hYzHzJuKgiPHGrHd::ifLbszKchDe(string ocCNMawlsS, string aWeaO)
{
    double ueoegAmLIwWhxPjS = -749887.1497361558;
    double jlSKJGTSzu = -656765.0644145192;
    double yXFnpfLETAvbs = -617596.4893457926;
    int vRYxqAxcrK = -572901963;
    string cciunauHg = string("zuGNFvGufDsdpzFhOGiiHczgqyVsJHflKLadhkEKgTlvdRkaDRjxWqEWogjgiVbpnaYIkulhoCkwSbUryhtkqNcuoiXNnyyWIEefTGWhYxVJlmRTQOBfHdDDaTQjKBtJpmYBNUeUwfGqeRDqCKfwaCKkCOEtwpzml");
    string ZrIhyFKLzue = string("xpTyFIEilPjRIXUPWPSjfMPeODswosYrPNWqEPFUwWGPPUBOKesNnKThMnhvZHKZDyggeIhMOfBrGZSHvSviMRXdlnRDSRfFEcHltuXVMjsoyjwcUAFDzMzIcEKWxiKzOqbSKtYCTGwnZUXiJNYiAaUxAdCEZpkWZZLidokSirOcBAXcaXfqRLhwfZJnYUPIewZHGSCSqFMImLUERGQtS");

    if (cciunauHg < string("ohGAexjRRyVYXZoHnEPTTwDPQeeVyDuMoNKUrOVcAkKKXmerTfmILmCEBZByAyrMmbwjnrzkbAhCvVICuRhaHHgQJwecAYuGGOspNxwaMoZCUYnrxiTsQDGhBVeLJzzTwghpEMbqmMewLlfUfCfcJVsSZXjjTSvduXZYirGirOqjNrcpWEDAPuZGmyNJbnmAgFuwA")) {
        for (int mMXzTOwqI = 910948845; mMXzTOwqI > 0; mMXzTOwqI--) {
            ZrIhyFKLzue = ocCNMawlsS;
            ueoegAmLIwWhxPjS /= yXFnpfLETAvbs;
            ocCNMawlsS = cciunauHg;
        }
    }

    if (ocCNMawlsS <= string("ohGAexjRRyVYXZoHnEPTTwDPQeeVyDuMoNKUrOVcAkKKXmerTfmILmCEBZByAyrMmbwjnrzkbAhCvVICuRhaHHgQJwecAYuGGOspNxwaMoZCUYnrxiTsQDGhBVeLJzzTwghpEMbqmMewLlfUfCfcJVsSZXjjTSvduXZYirGirOqjNrcpWEDAPuZGmyNJbnmAgFuwA")) {
        for (int nJMaePHbC = 267971453; nJMaePHbC > 0; nJMaePHbC--) {
            aWeaO += ocCNMawlsS;
            yXFnpfLETAvbs *= jlSKJGTSzu;
        }
    }

    return vRYxqAxcrK;
}

double hYzHzJuKgiPHGrHd::fvkBJEgss(int HDQbvigHiyKBLNOM)
{
    bool hsIpTURowp = true;
    int GyPWovgOx = 638876511;
    bool KqKjv = false;
    string FyCSMIbQRJWT = string("zerwpPQpxSpjDGOrMFtTlKVPdJifIAZAmSUsmVglhGirv");
    double TXbcQluHQNHN = -225629.01355357084;
    double JTrBCWj = -825780.8921195705;

    for (int AdrsZCzto = 1292831357; AdrsZCzto > 0; AdrsZCzto--) {
        HDQbvigHiyKBLNOM *= GyPWovgOx;
        hsIpTURowp = KqKjv;
        hsIpTURowp = ! hsIpTURowp;
    }

    for (int QbOMycxlHjL = 1755793028; QbOMycxlHjL > 0; QbOMycxlHjL--) {
        hsIpTURowp = hsIpTURowp;
        JTrBCWj += TXbcQluHQNHN;
    }

    if (KqKjv != true) {
        for (int sXNYjUbE = 1300923745; sXNYjUbE > 0; sXNYjUbE--) {
            hsIpTURowp = ! hsIpTURowp;
            TXbcQluHQNHN -= TXbcQluHQNHN;
        }
    }

    for (int HyUEPCpoD = 253897138; HyUEPCpoD > 0; HyUEPCpoD--) {
        KqKjv = KqKjv;
    }

    if (GyPWovgOx == 638876511) {
        for (int MZKJNklywquo = 1708488583; MZKJNklywquo > 0; MZKJNklywquo--) {
            continue;
        }
    }

    return JTrBCWj;
}

string hYzHzJuKgiPHGrHd::saMZT()
{
    int cDbSeJqjnbsLX = 1212434681;
    int DCAkJDyTM = 2073035312;
    bool RecfnoqDmx = true;
    bool jUAvmQMkiu = true;
    int HVOwKg = 1738206517;
    string iLohMBTtfN = string("KpgDbHTdbikyniMvMzNbBduWWcAkObrvIcpGpVVYEyqrZOAjAusfksK");
    string uiytGgDzB = string("ZRxiZhJLnTJrFTVHrSIlaaoDsNXkiOgTVjpTcaSTXZamdHCEmIHImJxjabrKtOEHfFHPMUFIhDTLsPsEdhvhQTOTUIYrlQcYTjopFHaleJBnI");
    bool qhRbKHWSgUUCW = true;
    int giAyHokABDPNkR = -2090863793;
    int XrMiwYyDiqJjWqK = 800895942;

    if (giAyHokABDPNkR > 1738206517) {
        for (int AxpjzslmuM = 945302145; AxpjzslmuM > 0; AxpjzslmuM--) {
            DCAkJDyTM -= XrMiwYyDiqJjWqK;
        }
    }

    if (iLohMBTtfN >= string("ZRxiZhJLnTJrFTVHrSIlaaoDsNXkiOgTVjpTcaSTXZamdHCEmIHImJxjabrKtOEHfFHPMUFIhDTLsPsEdhvhQTOTUIYrlQcYTjopFHaleJBnI")) {
        for (int vbXrsv = 1134006614; vbXrsv > 0; vbXrsv--) {
            cDbSeJqjnbsLX /= cDbSeJqjnbsLX;
            cDbSeJqjnbsLX = giAyHokABDPNkR;
        }
    }

    if (iLohMBTtfN == string("KpgDbHTdbikyniMvMzNbBduWWcAkObrvIcpGpVVYEyqrZOAjAusfksK")) {
        for (int zaKwOTXdiwjG = 2011613065; zaKwOTXdiwjG > 0; zaKwOTXdiwjG--) {
            HVOwKg += HVOwKg;
            giAyHokABDPNkR /= XrMiwYyDiqJjWqK;
            giAyHokABDPNkR *= cDbSeJqjnbsLX;
        }
    }

    for (int BnPiQuERMEfWwwTG = 713776690; BnPiQuERMEfWwwTG > 0; BnPiQuERMEfWwwTG--) {
        giAyHokABDPNkR += cDbSeJqjnbsLX;
        XrMiwYyDiqJjWqK /= HVOwKg;
        XrMiwYyDiqJjWqK *= cDbSeJqjnbsLX;
    }

    for (int SpaXkWBbNBWKsbNL = 1952001248; SpaXkWBbNBWKsbNL > 0; SpaXkWBbNBWKsbNL--) {
        HVOwKg = HVOwKg;
        qhRbKHWSgUUCW = ! jUAvmQMkiu;
        DCAkJDyTM *= giAyHokABDPNkR;
        jUAvmQMkiu = jUAvmQMkiu;
        HVOwKg *= giAyHokABDPNkR;
    }

    if (DCAkJDyTM < 800895942) {
        for (int XmEgIIrEf = 395932134; XmEgIIrEf > 0; XmEgIIrEf--) {
            jUAvmQMkiu = ! RecfnoqDmx;
            qhRbKHWSgUUCW = ! jUAvmQMkiu;
            cDbSeJqjnbsLX /= HVOwKg;
        }
    }

    return uiytGgDzB;
}

double hYzHzJuKgiPHGrHd::FDjvbTGjskpuNZls(int SBDBg)
{
    string axUhEKvx = string("bgcDHmQWfqnuvKOZNvzZZRvyVYXgxJqVPCinxYYAipPlNVBcTQwJrqfVxBpLHwsPlxuyXezzZQoUYWXnWqGenqriHRWFEaARFFdvyvYIRSIcUBTWUmlCZswWiOvtleNePBUBYxzzLjkgDgPVoaHqIJMVXbaYQwIiGzifNsvhptECynVVWXUeXLWyMbbpEWfDprxGQSpVHoCfoqywuSyxtvZuePSzQzKDHW");
    bool pbSUggZiSDfcNL = false;
    string kMIkZ = string("DEyNpWNfMFzLoHVSNXXISUuukhKhvfHjjqKQfnPWFBKlWiVDGdBWlhAyYcZwJUtNqAxmgiachkZcAmbPPdBKDtAbmcohCMNcmjJdwGgSAWBoWThhDxvSOqnuLmdPVUmljiFnOFxMbOvWdNyrOyvJGIeCeJrpYdkZbHPyecmEyRoGYQaYWGiYKCRqQDtHIFMwEHyApkTLxvuFJqJfetTbQAksvObaZ");
    string oBvSqCEYtsXJs = string("JPKQkptRRuGXBNDceqytkmJxbncPLPYeBUUFMRPiwZIaKNfFfPsIhmvQqaZAejlAIiFKWNAuTgUUIhnnVmGXcPurVZsGMzeOYlCxyOmTqpsQgTnOXmUdWlvLmFyjjtOZpazRNOenfcAnfuPlzdpzrkjaEkvmQMXmSlkoLPsxIAoKvbnNHkgHnbjLvXMxeInuqvbRwAHNtHyKiTQgTSLdlUguuNlUkhlanVZbPqnpxCAvZXIxMokCWWXryhiH");
    double QYudoWTWYMYM = 796133.4084011328;
    bool HdLXWWSkmV = false;
    bool FwnTTCBAoQMs = true;

    for (int zJEFRYWt = 966654147; zJEFRYWt > 0; zJEFRYWt--) {
        continue;
    }

    if (pbSUggZiSDfcNL == false) {
        for (int gcmuunXSoOBd = 1547124303; gcmuunXSoOBd > 0; gcmuunXSoOBd--) {
            continue;
        }
    }

    for (int CcZhOOjRBjdORnx = 1291087888; CcZhOOjRBjdORnx > 0; CcZhOOjRBjdORnx--) {
        QYudoWTWYMYM += QYudoWTWYMYM;
        oBvSqCEYtsXJs += kMIkZ;
    }

    for (int dxItILmLRpEoGt = 312890248; dxItILmLRpEoGt > 0; dxItILmLRpEoGt--) {
        kMIkZ += axUhEKvx;
        pbSUggZiSDfcNL = ! HdLXWWSkmV;
        FwnTTCBAoQMs = FwnTTCBAoQMs;
    }

    for (int hPQtIcBMgqFqSSWn = 1833508835; hPQtIcBMgqFqSSWn > 0; hPQtIcBMgqFqSSWn--) {
        QYudoWTWYMYM += QYudoWTWYMYM;
        oBvSqCEYtsXJs += kMIkZ;
        pbSUggZiSDfcNL = FwnTTCBAoQMs;
        pbSUggZiSDfcNL = ! HdLXWWSkmV;
        axUhEKvx = axUhEKvx;
        FwnTTCBAoQMs = ! pbSUggZiSDfcNL;
    }

    return QYudoWTWYMYM;
}

bool hYzHzJuKgiPHGrHd::Ghfne(string JejTAdlJASUs, double DZWiRuq, string pzMFCehFhiviwsuv)
{
    bool lKvaJsDz = false;
    double AKwpEuyQlAWSmf = -107718.06562530708;
    string MzkQsEOMWUZXgRC = string("tLqHbKatgNqUiwpCRtKgPkShOAcmRjflsGQcfJgDRoBjmSHiMvJCMoxWBTahelTxjaRjTIqXQgShwYYsMfbEVXUyjgGnyKsIpusQApUFITJNddyVezKLXVQDpYtnGQAQRZmhLcJFPdNBzFLPrcPyHmrmVhfYlWeqwmCfNbBtGKTYuiYkSIilBMpzLsTtTWsqcBmBBNUoHRmGsgjhJfDtCigMGZskMZIwrwdZURoRba");
    bool RWTzTcziL = true;
    string YRYyDKjOzOS = string("hrnlpxeuYpDhiiuXrrVrinEktQHUZSWXxZpgpfMnDATAyOgpuFVjvXjiFUzdIxFrrqdRVvzMaeYlEaNGIgavxtuezZwSZnpDxCzqMjoRwnaSXZOBCSJTDUISUptwzdSEbKQcYHJUYtpuAyxFRqnHOvPKjKbuWBDBkOcGRVcMmMJVjpITIkjgsuiVVPvZgOaUeTOsbYJLGcQgjwTbwrhubCpX");
    string DBsVKypmnrcU = string("FcTnzwnGcIyIFabDgoELtNhJBUZzmpzUMUlPMNJGMGFFIkYZaUIIbVHGxgxevAoyTOghJcTKpqiiIFFoUKVwNNFtHhHHXdNblQRjJHhkOoKhAEVZarGwYnpoPPAyYsUcUGoPeOErNwGaocsIsaxlqbIErAuPhgZsFbhlmxBFKMMGRlezHxCcMiHTzMbnbBFJuXOotPFYOEUUrgaRIkewGQmEWbFOmBmWSHwpBmcOpXlpJIUcILXpa");
    bool mMytyGD = false;
    double LJpdWdJahkuDkvS = 141369.13679953944;
    int PcVpK = 1034014812;

    for (int XdiQLQAfRBF = 1272178240; XdiQLQAfRBF > 0; XdiQLQAfRBF--) {
        DBsVKypmnrcU += YRYyDKjOzOS;
        MzkQsEOMWUZXgRC = JejTAdlJASUs;
    }

    for (int vhyIMlIVmL = 85517171; vhyIMlIVmL > 0; vhyIMlIVmL--) {
        YRYyDKjOzOS = MzkQsEOMWUZXgRC;
    }

    return mMytyGD;
}

string hYzHzJuKgiPHGrHd::PANeuNeYCHC(bool DSHqvKaaVAm, string YgvOnSNeBxFMkka, string XnwiQtYHuhmcwlwn)
{
    int ztAmvAxuwkFSPsqv = 630363420;
    double iywZYsCTGAKeD = 838566.776012524;
    double KkBWlwfDRK = -397349.8499671829;
    bool jMegH = true;
    string SvIoSgnauaqV = string("vsqKjrEekxcZWAWiVIFxQtAwOpyW");
    string PWryPpTtOwiHRZ = string("tFhhHqVDzcTophbctJmHWo");
    double axIdHRtJuhDEiMry = 410764.84125112864;

    return PWryPpTtOwiHRZ;
}

void hYzHzJuKgiPHGrHd::VHEMXdQnIjv(string PKfRunbNpxIQ, string dyuUWMlU, double qadLllYZOUUWsXdS)
{
    string gxitllKONmJgdFtG = string("YGkaPshohonMBERtlxSBENWbXoKshwlqVBqRDwzrPKpy");
    bool kkwzAkrhQ = false;
    string fILGJDTPQUm = string("wReFppBZoyCrUFsVJSqOtKpKDpFScEuTIKRdLGfYDIYk");
    string whiUnyZSkK = string("atKgQEMQvoPaKsNgslGeRydcEvOitIMFEeuMsjSmTyfRCXsKGBluDefbUaPXwCrQnHwGqcvpMaXOXTecBWTXHbPMWlcJcqkSzNnMEEWmsXKlVWfSbLNLVWiDgkyar");
    double HvqEEYEvIKmKuzJ = -856723.5917430432;

    for (int TNJmVrBzFc = 1090719878; TNJmVrBzFc > 0; TNJmVrBzFc--) {
        PKfRunbNpxIQ = dyuUWMlU;
        fILGJDTPQUm += whiUnyZSkK;
        gxitllKONmJgdFtG += dyuUWMlU;
        fILGJDTPQUm = whiUnyZSkK;
        gxitllKONmJgdFtG = PKfRunbNpxIQ;
    }
}

string hYzHzJuKgiPHGrHd::qnDPGqOl(string CYiLrGMcroV)
{
    int IOIZnMv = -913053277;
    int gkHoubWRLCSTBkr = -204740908;
    string Ybsneh = string("qlXXWqphcyRDZNZJsSxYMldXAxtBZqIzCtcqKFHIoatAGlTMLCpMWvIBYBUoQBwhecqQrN");
    double eTYvjFDWcCTr = 563627.9052624061;
    int usqoXPXI = 1484341302;
    bool DoAcvrZjccSR = true;
    bool hNIXMgqoLsv = true;
    string RpILlA = string("MZSotBVuzGaDGENMHRQhrOsXbxaVbzIBBkcrNBlXyvHKvMRlalljQSxHwaFAfgHzTSFAkcbufECdZHnLUXbHbMUgaBdjbnbWfJHdZDaIvQLfKOMRAfmWdMpnZKculeScscjaOPMApeUAQxPPAXrNYSQJvwuV");
    bool gkzzgUvH = false;
    string xxPWQABEvWIlVopY = string("MJBebIzGSRZZjSSLZM");

    for (int ibikubRKMQUleYVD = 637752901; ibikubRKMQUleYVD > 0; ibikubRKMQUleYVD--) {
        RpILlA += RpILlA;
    }

    return xxPWQABEvWIlVopY;
}

int hYzHzJuKgiPHGrHd::RlBRRKxrXSM(string EVcqNjoKHLtzwOA, bool IDEVmMrXyZUJOb, int FxIXyUU, string DYbDrWYXWe, string QArjEmYz)
{
    double ebTmCC = -665599.074581524;
    bool pOmKnpGrsawidgfU = false;
    string FaHRjwbHHBaQcgvV = string("eMFsFImeEAUSmlICuvQipitleqvIzZSoWdpCgnzaeVZkPAZLLYCNFhXYfrRyHnnTpMlakohsjEBZZbiVwgfPGhlnNuMcwdzrQGCMplEzuAgmShkphuGtJCxuGhaHIvDHnaJRoOdzHgFXoAPLEjLvKjHkEglbrfUOJPAVwPOTQfGOsOdWcxgslscFYISQWqmRMIxqlvyFrjrFDjCCWtzTUVdBsHRUeyHTqplhcacVuWlvUsYEyAHSO");
    int tkswOyOdXiKzdH = -1685154337;

    if (QArjEmYz <= string("ffYSUdJVEZqPLkXArNhvacAhDjrCrLkTxYUmOvnWDoAtbMpCrnmRfAnEgNeFJmbTvXsqRpBrNPmggfVhweoUufYFaSYOyDOdPGlBxXhFTZfDfzYVPJGle")) {
        for (int lgxQba = 1677108109; lgxQba > 0; lgxQba--) {
            tkswOyOdXiKzdH /= FxIXyUU;
            DYbDrWYXWe += EVcqNjoKHLtzwOA;
            EVcqNjoKHLtzwOA += FaHRjwbHHBaQcgvV;
        }
    }

    for (int rdVYSRwxZLhuAK = 1925477275; rdVYSRwxZLhuAK > 0; rdVYSRwxZLhuAK--) {
        continue;
    }

    return tkswOyOdXiKzdH;
}

bool hYzHzJuKgiPHGrHd::fuizi(bool VWNAJsYcDvyY, double EEMuUiAMdeKA, int qnEdyqneFZyHvmr, int PMHFlkokrZcrCF, string UFEKUkAz)
{
    int WhylnQFIFxPcO = 1149856968;
    int fEAqbFBmYgTUr = -980383057;
    bool OISTggGOQ = true;
    bool qNdqKZUIEQgNnN = true;
    bool xNouf = false;
    string oRhamnAYcwuEApAz = string("VgNSHZcwmzYmCLDxCHFHjyTLnwruOOWatiFCAYCYfBVlKzIKqiTLlggFQFInsuQNIpeRbQXBfzmXpJEQJsmeBAckDICIhgKnVSrdABqSTORUFMpXqukUkdXudHfsLYjCzkGsJgGNfVVK");
    bool oyaFc = false;
    double BanVtbUiUdcXjK = -518675.28394839895;
    int dxrPshHhhsjD = -912729051;
    bool lGUisAGgqQz = false;

    if (fEAqbFBmYgTUr == -912729051) {
        for (int AyLhnUnmvJuXxU = 1699737967; AyLhnUnmvJuXxU > 0; AyLhnUnmvJuXxU--) {
            fEAqbFBmYgTUr *= WhylnQFIFxPcO;
            UFEKUkAz += UFEKUkAz;
        }
    }

    for (int ooDLPIMWutwofv = 902310620; ooDLPIMWutwofv > 0; ooDLPIMWutwofv--) {
        EEMuUiAMdeKA = BanVtbUiUdcXjK;
        UFEKUkAz = UFEKUkAz;
    }

    return lGUisAGgqQz;
}

bool hYzHzJuKgiPHGrHd::wqPHPISZ(int sSBEHEwrvCJuO, string atVLfL)
{
    string tWEjDV = string("SVhqtSDyEHmLfycBtgVwbZrwZMJJyxbdyENWRvThZpTqmlYoFWAuXBMPmPmakvaVhTLPwNXYwqXxQnhzKtplPFKxYXPxJZVcvLZIJcZpFqLHBqZbEyDUgMfdKoniiVodJLrGcKksemLDJieFxKzerQIICesPkpPawDUxMSRyhKhMpQtaMFfzjcaJOsYhHzuErichTBEVEGQCnJwWPkfHGPDRPlFIEYLNaRdWkHU");
    string WcFiirQgGkILJfw = string("MrOMWBZPBhBNxdmgguFooYTPEkHmwhIGTDyJmGMLATlgwkGuFgwieHMcTdKtrNgJryyXhzjSfhydIrBavfjZJHYWzfiocIHQXwEvzCQFweafrAqIpPjqfeTFQMlvLoscmcrHxuYzkPHSeabZCtXhDBscSNWNYfGAJQsqwoXNAscxFa");
    string WPOFzdVUCjLwteY = string("RnhUvaGhaq");
    double xDrcld = 374614.03730099456;
    int GSJbrKGPDx = 1206545053;
    string dBjmuhkNvuYqYu = string("UVVHSzMabMegMpzuKZtVtdmJoxjLsLhmRGrMsuhnQPJEYhnhLyKwTcoMkoTQznqvzyOYqDtUdiCHjvPJHLIMSiexQXYrDlQTVgdkpXlJgpIeJPVfJtgMVGbXCExMmPsZyxYfZlqvWgYUswDBFxOdwIVKRfLjmzHnCkjsbFDeEkEpxjHLoOBzhTBo");
    string cWXXWABP = string("kBvzoOMfpJNShDqvbuEineTwQSfteLNzLiBnHjGGIBVvyulnxphZdeKcYDPLySGSvuphFGRPXXNnfSstejLSrCoVhCvNJDqzNFQPPdhExQcXWgUONfIuIAlxVigRifybinEXybedUSlusCtHRctlyxntzhHmmXwJOigRbWDygcVJDXmYMdgRemmiHZINohJrHnCgZcWfA");
    bool wtgpCXpnE = false;

    if (cWXXWABP >= string("kBvzoOMfpJNShDqvbuEineTwQSfteLNzLiBnHjGGIBVvyulnxphZdeKcYDPLySGSvuphFGRPXXNnfSstejLSrCoVhCvNJDqzNFQPPdhExQcXWgUONfIuIAlxVigRifybinEXybedUSlusCtHRctlyxntzhHmmXwJOigRbWDygcVJDXmYMdgRemmiHZINohJrHnCgZcWfA")) {
        for (int wHHBs = 1618520762; wHHBs > 0; wHHBs--) {
            atVLfL = dBjmuhkNvuYqYu;
        }
    }

    if (WPOFzdVUCjLwteY >= string("UVVHSzMabMegMpzuKZtVtdmJoxjLsLhmRGrMsuhnQPJEYhnhLyKwTcoMkoTQznqvzyOYqDtUdiCHjvPJHLIMSiexQXYrDlQTVgdkpXlJgpIeJPVfJtgMVGbXCExMmPsZyxYfZlqvWgYUswDBFxOdwIVKRfLjmzHnCkjsbFDeEkEpxjHLoOBzhTBo")) {
        for (int SzdojIchTHMurrn = 551151836; SzdojIchTHMurrn > 0; SzdojIchTHMurrn--) {
            atVLfL = WcFiirQgGkILJfw;
        }
    }

    if (WcFiirQgGkILJfw != string("SVhqtSDyEHmLfycBtgVwbZrwZMJJyxbdyENWRvThZpTqmlYoFWAuXBMPmPmakvaVhTLPwNXYwqXxQnhzKtplPFKxYXPxJZVcvLZIJcZpFqLHBqZbEyDUgMfdKoniiVodJLrGcKksemLDJieFxKzerQIICesPkpPawDUxMSRyhKhMpQtaMFfzjcaJOsYhHzuErichTBEVEGQCnJwWPkfHGPDRPlFIEYLNaRdWkHU")) {
        for (int QXOmdVLvppg = 1972636480; QXOmdVLvppg > 0; QXOmdVLvppg--) {
            continue;
        }
    }

    return wtgpCXpnE;
}

hYzHzJuKgiPHGrHd::hYzHzJuKgiPHGrHd()
{
    this->wXhojFOaGY(531529322, -879486.6924081855);
    this->ifLbszKchDe(string("ohGAexjRRyVYXZoHnEPTTwDPQeeVyDuMoNKUrOVcAkKKXmerTfmILmCEBZByAyrMmbwjnrzkbAhCvVICuRhaHHgQJwecAYuGGOspNxwaMoZCUYnrxiTsQDGhBVeLJzzTwghpEMbqmMewLlfUfCfcJVsSZXjjTSvduXZYirGirOqjNrcpWEDAPuZGmyNJbnmAgFuwA"), string("epEaPeRjPicrTdSBbTiGRHvikvlTLJPdjAwxaBfvUMRhoHIivJqzOPTKOHBZlFJpOoIoAlVQlZcyYsQDiOHMzKXMsxJQBZagnwWsSOywQpjKRSoTcKoVvIRdLQfMvZbVDtmrxghxbQCyhqKDjtrompKYKPbwFnxybRnnqgF"));
    this->fvkBJEgss(-25666729);
    this->saMZT();
    this->FDjvbTGjskpuNZls(-1686204518);
    this->Ghfne(string("CjrJqFFDdhdJovckEyrFpXYgdHfFxSMCmQneTxcpNxroBZBeeOdcOVvTtYSoKswpmITVleQkWkMgkyiFjWTqrPFQtOuotfXziZucWSQthvWaoLJFWJRJoYrbXHKxQOFvRHBicGILpjtVuNZgonHmTECqCGyePaPAitpqFmlcVQrhrfGoJcC"), 933590.9649636039, string("HSflorXnsiQrKgQSDSxmbbWSNPblnsancAiBEbanDyYJXltSFqMFbSyohbCLLYjukFkqWyxYJNIcXUFsZRldaYlWhJcwDUZnHLBmXUPiNkjiCCzSnnygwMcXpnfpYCHkxEedzoGcrIQXCBADjUzfAgMJNSapEIMTMYcdbexHPBsvHqMHXgBdqqcmNx"));
    this->PANeuNeYCHC(false, string("lamIaZEtdMcFzygOmymvuYUcpreHJXvVVcGuzGndrGOijyIjBEPcKrLLLdGRzjUozPoaDDXbkwtAjKjfnHTfSIseddOVfMLjbaHNGCamwpejvjGKbIsUEqkikwvHyAkHtILP"), string("ZTwNzRYkIijPGJdejSUKDrkPNAEmGYfvCHSopLRBiFapkkAcgqkLOSijYbAmfXIlzXiABlDNigtuSDdsMaukEOhaDVHylYlrxttvvJEBoMgSLkcSLlEIPqFBPTXzKVKFE"));
    this->VHEMXdQnIjv(string("PHuiAlHLMifitqYGOFroSleZKRueScVzqtBAyPKBokGhINeOZlnsCdUvPtVyQcCWMShrAEuUiCDTODEXABiqDdIKssGjKoEPNVdycxSJiSLvjGdCXJNhYIELSrzpTnyOOBrKegmZWirDmsi"), string("YMVtqUHsmucckbJeKXLOgYboSnLRHxvEeojlftbhTPfIRycBVwBRQKxXUGXXJWcFxCduETAQacfduuAclITiLGmSDEkmPgobUdXdTKvlZVSKCBqVQPGaWRfEHATlsxzHdSFaQOpXllVoQPBJclpVOpLWSCdRpePnluXfwKaVjnecrHJKlCKsFqopwlTWBvGFgXcAk"), -515582.91858650884);
    this->qnDPGqOl(string("WsKYRsjmxVpvcerBmxWyXJSOBTxXEJAoN"));
    this->RlBRRKxrXSM(string("ffDOEUmWqKJGppZgyWrZvfGuBVEvDXFFDlYHYhwbwiOiXGaiSZfMtTVhbrZVdKZRlrjZuicVGPNAfvOTbquBpqpBzpoDATikeAawBeKISmaYBgNfZmURsWmPlzgBJVoqTaADxKectRlAuOmJZPUiofc"), true, -612674407, string("KhCKfcmJgvBYbQlXBPeEVMDmEzEJXfGC"), string("ffYSUdJVEZqPLkXArNhvacAhDjrCrLkTxYUmOvnWDoAtbMpCrnmRfAnEgNeFJmbTvXsqRpBrNPmggfVhweoUufYFaSYOyDOdPGlBxXhFTZfDfzYVPJGle"));
    this->fuizi(false, 103680.17997157712, 506166621, -1197095512, string("punVbgZRyrPiJliLCjtKUiBdOdDzwHMMHnkALViLkEEwWeXtkemTTuIfUxbySbdPlawLVJPxJySHPQKrfAWxQClrIZKzzDmJmbmklEjvkcpPFvFLIYMkYrqzNqBeJafWHSwnHaiHurcGJYNxCVlAMZKxzTFoZlOttjwPXJQrAzgJnzGhJvpKrFhtcpX"));
    this->wqPHPISZ(451823291, string("vFLVqxzqrZxiWsPaMtgBwFxNhkfcVZUFOTFihJExsbMrferddYVQAlORvXCYXLrNhQIfrICmlPhjXYmzaDZZiEPDaqsJcJbbKpEK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WaEnvnlwPE
{
public:
    string HhGIkTmovaOE;
    double EpYPAUlzFijDv;

    WaEnvnlwPE();
    bool zVWtou(bool zagqKGQEP, bool EbLQMRRrHnDsh, string ffgCK);
    double faEbvayerbHzTRBa();
    string SIodS(bool uyIGwc, string QUscfkemc, string lEbrrotRiuBTYC, double lsxUuNb);
    bool gcHtxvVyjH(int LukNrJRBgjAb, string sstiZognKbtfLLHM, string iHzsc);
protected:
    int NVEiGk;
    bool TrSRvlMjFazsCfp;
    double jQnQOsYbJVv;

    double alTbjpKuBpTzZDdW(double sxUmNDuJjWp);
    string fHwTEC(double fmLtKdPuexruzKH);
    int qkeUYQ(string VmiZVu, int MvfpzytvSvu);
    int IxliW(double sZsczaRRdfnGq, int NqnUqlQBxhNVOCj, string AKUYriUts);
private:
    double mDzEqJsQtKXye;
    int PnqQNitLhVLqyaP;
    bool gQjXLHKPRfpg;
    int NoOcZbDUNMM;

    bool wXmNVDZxfie(double BaUZedrMVAxz, double QMCWPrJmNcv, bool PCTYznia, int FfUNETFBy, bool EZRZaVCgnE);
    bool ocRRAd(double aUWZJ);
    bool rWnuBMimvRE(string zjGctEyGBOju, bool vBmLvGpmBpkEJaps, bool iQVlpYP);
};

bool WaEnvnlwPE::zVWtou(bool zagqKGQEP, bool EbLQMRRrHnDsh, string ffgCK)
{
    double iXCDb = 155346.01472910476;
    bool sUmRwGcAziJyOVr = false;
    int nGxNibMs = 826011453;
    double WfyZGDBAqhDZSpTQ = -384344.84509606083;
    int ObOXgXAEmXTwQT = 271671951;
    int mMjdhhUtrli = -2067444441;
    string oXvtCWFcMXt = string("DJsCNHGKeeiVSQJJDVbhMJDiJXxTTBedEMjEhaNZlzfRuVtfRPcGVOPEfHCUldaHImQdPzyKjGGvMFHxaweHbMFZgyIfVQtZiroKMOOODiXHICcvBACYMmEcDxPKoHQYEfOkMuDqsuzkkyrtWrWNrZjMdBJmnCtGDJGJeBUoKGBipAgiDvzCLXkZJxqaJoEjibAkymxBRXixWKSrzGTpcxQXvcdGdLX");
    int JWEHwTJuo = 1020095133;
    double bGxWddBwttWAcKz = 510836.5601697272;
    double tamtscwQYkmWW = -916000.3629109665;

    if (ffgCK < string("DJsCNHGKeeiVSQJJDVbhMJDiJXxTTBedEMjEhaNZlzfRuVtfRPcGVOPEfHCUldaHImQdPzyKjGGvMFHxaweHbMFZgyIfVQtZiroKMOOODiXHICcvBACYMmEcDxPKoHQYEfOkMuDqsuzkkyrtWrWNrZjMdBJmnCtGDJGJeBUoKGBipAgiDvzCLXkZJxqaJoEjibAkymxBRXixWKSrzGTpcxQXvcdGdLX")) {
        for (int CIOsCIfXEIH = 916760281; CIOsCIfXEIH > 0; CIOsCIfXEIH--) {
            continue;
        }
    }

    if (WfyZGDBAqhDZSpTQ < 155346.01472910476) {
        for (int OTozOwp = 1688166468; OTozOwp > 0; OTozOwp--) {
            continue;
        }
    }

    for (int rLMkugNEFc = 1328112448; rLMkugNEFc > 0; rLMkugNEFc--) {
        mMjdhhUtrli *= ObOXgXAEmXTwQT;
        WfyZGDBAqhDZSpTQ /= tamtscwQYkmWW;
        mMjdhhUtrli = nGxNibMs;
    }

    if (tamtscwQYkmWW == 155346.01472910476) {
        for (int znuzK = 982312155; znuzK > 0; znuzK--) {
            iXCDb /= iXCDb;
            sUmRwGcAziJyOVr = ! sUmRwGcAziJyOVr;
        }
    }

    return sUmRwGcAziJyOVr;
}

double WaEnvnlwPE::faEbvayerbHzTRBa()
{
    bool IRfhYdqCaeapYy = false;
    bool CHQQshgqLw = true;
    string GhnwD = string("YOoNOdHEULfwpaaRQCwGrGhEeboNCWBVspUmFzDRRmYwWJGWuhUOPYVVwhObRGEibYjIqQIOobqT");
    bool OisZoutjccUq = false;
    bool stdMzA = false;
    bool aNEmJGqGXv = true;
    bool JzEQoAdki = true;
    int HoPqVyWdoxYmKFxd = -1203280215;
    double gZiiBJlxnKRcBHuw = 468447.44965067995;

    if (OisZoutjccUq == false) {
        for (int fMaIkfI = 596108579; fMaIkfI > 0; fMaIkfI--) {
            stdMzA = ! JzEQoAdki;
            aNEmJGqGXv = stdMzA;
        }
    }

    return gZiiBJlxnKRcBHuw;
}

string WaEnvnlwPE::SIodS(bool uyIGwc, string QUscfkemc, string lEbrrotRiuBTYC, double lsxUuNb)
{
    bool umbchnsxP = true;
    string VXmAcJ = string("tMPRJGaQcDXwEQmzzlpsoEbWxAfBmJjdMQvfNjdUKCXVFXuGtrxTHAFBKZqMYVYgQhjTgCcBuoDycwiujvRNOupfXKyiFRHvhSOhNMbqAZXlkOQVFmLaesQPSXcwtLoTYsjUFBwSqsRHriTIqgmwICoWUOVNQIVYDSHNGWULlkOhTuBFdifhskzQxqSZqOXbcRizdjPWXbhhs");
    string IJXaKMgQhNDN = string("RMeieDjCbiAALymjbtXTsbanRyVJQCmHZoRMhazdSGcDXEbxbhRhrpScvsYUaqKWBtfhkGkH");
    string vHKGDFvp = string("XJgbEKfUNkMFQxFzwNSJGgOSuBNuhavrXGdUYqUIEwGvUNyPNOHGbKfKsEOBUkFyjjsDYNGImVpJLATdTVQNkckuIvoIBWcdVGOMcfmZmhVMAwaHZolObiWKAZiyRoYccfWpibtZdCrdmJJqqRgypWBNdcieKDkVmHUhLbUdPOyeoJnls");
    string kUNivC = string("xTxXIXcURsVKrvHUdtrtFzmPgXmezjcurStMsckSUroEPOjEXPMXpjupTjvRbOCacwQbqFUXuSZcGZBsiegIIFGHmZgcoWmghArJqhNemojpxVbUEjiawNeIgJwpkKhtdQZszodLUJmezJveRJTwvzqPAeqghnYSDYHwBDLOLROeUasMcDvoDQDmZmUNMhPgWGfXKq");
    bool TmwjnCZG = false;
    double qjeDXImx = -571626.7881476381;
    double HyCaEyCjEjXBJWa = 849532.036658676;

    return kUNivC;
}

bool WaEnvnlwPE::gcHtxvVyjH(int LukNrJRBgjAb, string sstiZognKbtfLLHM, string iHzsc)
{
    double YuBliloyP = 509002.8940002581;
    int nuTMeACDnE = -1621398981;
    string cdtbazyhyqJdvR = string("BBpzkSDskpQmBNIolcjGLDADHYWxMuvNEjIPNGMGvrMjgHFNEMPvkHyiyileWYOgjJAiBKlwCcgDyZwfBwzjvZFnnxMePCpaDrIghirQHfJycwGhmkMdnQvCXNWSzkfAgyTQykPfbhOpErMjtsiuKmezHHKgAuOHwwgXMaIGQAJeDeKLeGlnaMyGPLKqqqzQhWqlRKvQUxdvBOOyPxwStKWMQYfrXTpYKJdHCyTmE");
    double eNxJwNTsPcICIw = -524558.8981416144;
    bool skFAXUtH = true;
    int SNgzNKHQJCGx = 1897211221;
    string ifDIYsVpw = string("WyoFauIlmNzYYoGxQyyiWVeZdQKEDtxTYyHzfiPRMabxVWjzOTaimNhoHgMsvLvgYMWJcmHgrZqqPlkemMINHhwuXPTqbfESTsEZWrzDlIxAJtoTLyVfRqoIfinEMNXRMDzXFKiYqogeHAaXVfFOvubXaEbvPR");
    bool KwnbcvmniboG = true;

    for (int MhHoGtrjgFsfUmq = 1937930541; MhHoGtrjgFsfUmq > 0; MhHoGtrjgFsfUmq--) {
        nuTMeACDnE -= LukNrJRBgjAb;
    }

    return KwnbcvmniboG;
}

double WaEnvnlwPE::alTbjpKuBpTzZDdW(double sxUmNDuJjWp)
{
    string RTjDkyR = string("RHYXbKibZDOFQqvOJiDkItWgigdWQrKkQQeEaXsvyLXSjbOzkXKINAIkbxJIdLEbCsxGVpcClnrcaXIOMpDwBWagtpDggRovmdRGvgfHjgLPuLpttIdqkWGSsQOYSwRhysQbUFJdlZSJHkOdICT");
    int yTJAOs = 320996011;

    return sxUmNDuJjWp;
}

string WaEnvnlwPE::fHwTEC(double fmLtKdPuexruzKH)
{
    string VhRxNiabnQEf = string("J");
    string MHMHxlRU = string("bsCsUfKMnDTSFzlhDFzjOfmK");
    double Aqhsl = -269585.4001018101;
    double tIxOMFp = -45605.08128470034;
    string oDZjVVsarsZBHa = string("tqxdWvpbwSABlKHVfOSkSfzLwuuntSZnqlODJAJQXYvHeKVuCSxXgOTTVPjwTQJkpLqFuaeMucGwSXDhfNfTcOKcuLFbTebvBYbocKmivMLIrRFGCftoSSAaHrSQHbGLMAFbqQjRThKqNoKVvqRRPtMJJTRlwhpJoKqVJfO");

    if (VhRxNiabnQEf != string("bsCsUfKMnDTSFzlhDFzjOfmK")) {
        for (int ztpftd = 683517133; ztpftd > 0; ztpftd--) {
            continue;
        }
    }

    for (int xTpOQUIb = 107556443; xTpOQUIb > 0; xTpOQUIb--) {
        tIxOMFp /= Aqhsl;
        oDZjVVsarsZBHa += MHMHxlRU;
        oDZjVVsarsZBHa += oDZjVVsarsZBHa;
        Aqhsl = Aqhsl;
    }

    return oDZjVVsarsZBHa;
}

int WaEnvnlwPE::qkeUYQ(string VmiZVu, int MvfpzytvSvu)
{
    string jeemLtpkcBVPzb = string("CDRQYRVTmpghSehcJQcuEBAhjEqLfhEXDxMOZTdGZPGKUhLzkLGjwSBsfvFsAXbcIFmjRgmzLMkMuIiwibwiWtUnPgIYMXhjuXeNbOLNgqVUjVkmttEiWITGDsNrSOntUSLNiSHdueucuRbZmShpUUZSBxuWsipKWOQRQlHaCcYaAkWBKXJJzRhDjCxTVMAOOmOiyoxTQqffMeznlUdGjuauWLjDuomfJQMWnrCSTUbSPXl");
    int uEuPd = 34174928;
    bool oPtBHPFCSXXC = true;
    bool OZkmw = true;
    string YEQpqCyYkpWYNE = string("sTpHfGJfBZNlzZyznnxYUBVcqfajqxVpWTmVUVrDaxXvNKZTdjgRbsWBqsasrYuIqynubImrwfsUZipolAeeexgGnRiwCLHpAhXRrbFBJEFnhLUOrDnHCCLqjVoQehvJmFzGPJwawunypndHOxUGfImHSHxEoKblIPYVgRkaZ");

    if (OZkmw != true) {
        for (int syNlmYnj = 1431447680; syNlmYnj > 0; syNlmYnj--) {
            OZkmw = ! OZkmw;
            VmiZVu += VmiZVu;
            VmiZVu += YEQpqCyYkpWYNE;
        }
    }

    if (VmiZVu >= string("twufIrcrnIgNhUtykslXhTEIcQfIGoOkxRpPuTspxlzpoLOupgIvKBQXbXefzpKavsaiirvjVgfdYkQGVtLtGkPFKUwpZiEoIPaTzoB")) {
        for (int zykGI = 1231803012; zykGI > 0; zykGI--) {
            jeemLtpkcBVPzb += jeemLtpkcBVPzb;
        }
    }

    if (VmiZVu != string("twufIrcrnIgNhUtykslXhTEIcQfIGoOkxRpPuTspxlzpoLOupgIvKBQXbXefzpKavsaiirvjVgfdYkQGVtLtGkPFKUwpZiEoIPaTzoB")) {
        for (int AjLwMewhqf = 1424885662; AjLwMewhqf > 0; AjLwMewhqf--) {
            jeemLtpkcBVPzb = VmiZVu;
            VmiZVu += VmiZVu;
            YEQpqCyYkpWYNE = VmiZVu;
            YEQpqCyYkpWYNE = YEQpqCyYkpWYNE;
        }
    }

    for (int XhGenpMPxA = 385045560; XhGenpMPxA > 0; XhGenpMPxA--) {
        uEuPd = MvfpzytvSvu;
        jeemLtpkcBVPzb = YEQpqCyYkpWYNE;
        oPtBHPFCSXXC = OZkmw;
    }

    return uEuPd;
}

int WaEnvnlwPE::IxliW(double sZsczaRRdfnGq, int NqnUqlQBxhNVOCj, string AKUYriUts)
{
    double XBgzEbaxWbtrIsd = -544972.1427641544;
    bool QHcSIUaCPo = true;
    bool IvAbmxPRkviEn = true;
    bool xrGuInP = false;
    bool TsPXAgSubFlkCDg = true;

    for (int HptrEftUBB = 1351966804; HptrEftUBB > 0; HptrEftUBB--) {
        TsPXAgSubFlkCDg = TsPXAgSubFlkCDg;
        TsPXAgSubFlkCDg = xrGuInP;
        sZsczaRRdfnGq -= XBgzEbaxWbtrIsd;
        xrGuInP = ! IvAbmxPRkviEn;
    }

    for (int ZhKsUAK = 768291862; ZhKsUAK > 0; ZhKsUAK--) {
        IvAbmxPRkviEn = ! QHcSIUaCPo;
    }

    for (int JxxZNnZxJGb = 1349564497; JxxZNnZxJGb > 0; JxxZNnZxJGb--) {
        xrGuInP = IvAbmxPRkviEn;
    }

    return NqnUqlQBxhNVOCj;
}

bool WaEnvnlwPE::wXmNVDZxfie(double BaUZedrMVAxz, double QMCWPrJmNcv, bool PCTYznia, int FfUNETFBy, bool EZRZaVCgnE)
{
    int csQFrsz = 2058703020;
    string gaSIE = string("GBhEdSEFBMJOIxVsbOrcyAkaEmhSHxbhPcUKnADkXPRwwSBWYpXCrgsiUeOsdAuQfbAzeUMVOFvPBmdQiBzBOHiHfvcPWMMIWyDBYeUeIzWclMSjIYFVNiLjGivXHsoOIBlnLhIcCRMFehsSwgSVVleHdjyZORbZycxjbPHLWcYvrSTiQCxjZtXWeiTBiDIgUBekhVsRRdJmJzJqcbCAoUFpFSqgpLpdCkvRsYyOMCKHl");
    int CQDWFRWiEhcmTndJ = 381247785;
    bool aPoXGgXSfNgaKsYp = false;
    string PmOFPAsYUrUo = string("tURfXsUUrDGDIqcwCiyjnYnXWVVEtyOGNlCOIigzohtxrHvlyRJTLBvhnJRvuvYpcjhwYcXKycFrEQDujfQKinEiMGhfHqJrqcyLdfooNudBxwEnTRicMnOdiKYPouVSpdurVciGqkZWvkxUuopTDHHmnxtMAZdPwXvmPBXRSnJMSEwlmwZNTRcvajkmrVLYMDAhBwJsBzoOJaVSxMsHtmGw");
    bool sDqkDqetDmxU = true;
    string egXCjuIiQLmYtX = string("NrjEoUXVsqRumETzNVunobqJaTQEaaCMiBUOANTGyRBsZwWsACUpbwvFTpesGmRQLAhYQdSEoDxxkYEigYZhcXkYscDVnDyABlKmwcJtkPIYymVXECaSQxQQfhcqXPKUmzvJcAJwAewYEHyOibHXEzZihEENYCnFGmNXmHMGNQzyNsEwegWp");

    for (int LIfwgBehwTAiv = 476982035; LIfwgBehwTAiv > 0; LIfwgBehwTAiv--) {
        EZRZaVCgnE = ! sDqkDqetDmxU;
    }

    if (FfUNETFBy >= -664216322) {
        for (int ehAWn = 580300248; ehAWn > 0; ehAWn--) {
            FfUNETFBy += CQDWFRWiEhcmTndJ;
            CQDWFRWiEhcmTndJ -= csQFrsz;
        }
    }

    return sDqkDqetDmxU;
}

bool WaEnvnlwPE::ocRRAd(double aUWZJ)
{
    bool NQbSguCOit = true;
    int aPPfZlEpWlXhy = -1603472092;
    int ZIiFIHTjtCJ = 202164013;
    bool wjiLAVWHB = true;
    int QMsGCWuwxw = 1559196788;
    bool OXBnPK = true;

    for (int LqeeQL = 1748855685; LqeeQL > 0; LqeeQL--) {
        continue;
    }

    for (int AdkNYWw = 1419178124; AdkNYWw > 0; AdkNYWw--) {
        NQbSguCOit = ! wjiLAVWHB;
    }

    for (int vGIprBeiTYa = 250808129; vGIprBeiTYa > 0; vGIprBeiTYa--) {
        OXBnPK = ! wjiLAVWHB;
        NQbSguCOit = ! wjiLAVWHB;
    }

    if (wjiLAVWHB != true) {
        for (int SbZzAhtkzboNDVG = 1071687877; SbZzAhtkzboNDVG > 0; SbZzAhtkzboNDVG--) {
            wjiLAVWHB = ! OXBnPK;
            NQbSguCOit = ! NQbSguCOit;
            OXBnPK = ! NQbSguCOit;
        }
    }

    if (ZIiFIHTjtCJ < 202164013) {
        for (int DQLGT = 959220779; DQLGT > 0; DQLGT--) {
            QMsGCWuwxw = QMsGCWuwxw;
        }
    }

    for (int DPDktlh = 722789355; DPDktlh > 0; DPDktlh--) {
        ZIiFIHTjtCJ = QMsGCWuwxw;
    }

    for (int sfSySUgYXPRjiVX = 1763300533; sfSySUgYXPRjiVX > 0; sfSySUgYXPRjiVX--) {
        continue;
    }

    return OXBnPK;
}

bool WaEnvnlwPE::rWnuBMimvRE(string zjGctEyGBOju, bool vBmLvGpmBpkEJaps, bool iQVlpYP)
{
    string CsEFtFJ = string("AkLZzNburkDyXqCrFQrVsSbDqpuumPgvGBPvSAieYJthoOndEkHyybTxNetkpBalbEBnooKivvMvCvGGGfZXcdhvjPCIvUYfULgLUzjlbeLGDCEKtmOLOZAFngaSJDMQAnydAJCBqoUYnOgUqjqZhEIAuYbYGWMyyUzQQcbQNfKnRvGOLtglYbHpWlpbaftvqegLzRGchGGkTqXkhXPohFhbDxtHUSwgOkITDqITUcZvVhStKCGrAfKzVfTZZ");
    int TStpeWLxHFE = -120198728;

    for (int VYYirYhhHV = 1847004623; VYYirYhhHV > 0; VYYirYhhHV--) {
        continue;
    }

    return iQVlpYP;
}

WaEnvnlwPE::WaEnvnlwPE()
{
    this->zVWtou(false, false, string("LZODmHheqhjYVtesxqkQDGLQOJpDjrbcY"));
    this->faEbvayerbHzTRBa();
    this->SIodS(true, string("tnCVyYLmSVBBddispBSjWrTnzVMnIJlHbuaSOyBgSaUNCZzeyZrxDjijVKCYTxORNURIjtvhMnZpJnPgubIxNOztRmkyMcBlFqmuwHRoWcNQwBeqNVQpyIvNfrnhxVbVBYWVkkAmKnpMpdmJzRsbaKAJnbFEiVnHNp"), string("FyxUTWqBtGUhmgdEhynqWYHVdZzWGYjdrRGDSFYqtrbhHxsKNfjXAbMhHOJCDMHKdtiohiJBiFBDjUiKlQYqZHnsQMOZBOztzIQKneagOgWDIniJKkXrx"), -180532.58675926938);
    this->gcHtxvVyjH(1725547026, string("imxOmyImETBdLgtDkyGkSuvTWhmTtfMtSesnOQMVEklbsahsYDEnYDMIUBnsbfuvLQbVQZtktnfvBWAzEjryJCjUpmUwOFggyDDjSGvArbhwcCnQWWyaWKO"), string("xKSJZoVbMcOblBvEJRnBfOdlsvxPXdvmpNaKHGEWWQaQxCfSqROHoStaGiWGumNEAPbWlNUQGTuWDSQTSYtRHBuUlbxHPmCAorBRJgBuBQQevlaKebUUyBxjEKZTNbulAtdMwdKIGzKGSmRVvXEBASMiDlmNxxnSbqjilqaSzVNdRTnebbTGHVUlpQNNAuKxT"));
    this->alTbjpKuBpTzZDdW(-376504.7149758547);
    this->fHwTEC(-784188.8909979364);
    this->qkeUYQ(string("twufIrcrnIgNhUtykslXhTEIcQfIGoOkxRpPuTspxlzpoLOupgIvKBQXbXefzpKavsaiirvjVgfdYkQGVtLtGkPFKUwpZiEoIPaTzoB"), 18331120);
    this->IxliW(414778.0112555565, -518496972, string("NBuKSEvymfoQlCqwlZtYpdvjoRutIzISIrPFuxSMcGCMszxaINhKXGRPmWUsnCGvzlgeXkYlkWZMZjnDJLVJkkVuhOlNpjEvcDEZ"));
    this->wXmNVDZxfie(-332015.3599217968, 834277.5829418632, false, -664216322, true);
    this->ocRRAd(457543.6490488866);
    this->rWnuBMimvRE(string("wWKrRqUZAKcCFeFwdGfbpczwMRaouAEXygsDDWjUeCisuBOGAlmRuRtZWORuucqofdMWyCFXVtGhrgGvFNGhJpKWZjdiaGRErsofnAWnNaslDPEDlUalOhEGDkcYkMFRiOnnrECuaesyjUqAiaYBanodnOizOIluExGXvTCTmHMmraDZfzmlVVgjtqcqZogPD"), false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SJmHgPrMKQhcn
{
public:
    bool nunhoeAmllsZEQ;
    int sCvwCSPIKCcmnBSw;
    double UuCXZHDetDot;
    string LKZPMJVvxSNLg;

    SJmHgPrMKQhcn();
    string jwyruPbK(double zFkwMtYbQNO, double imDXkL);
    double PPIFRkSJ(int yuqzanHul, string ppGRsUoByzgsdHg, double KawPKkjlakGPM, bool CJpAKSVdPk);
    double sarFDSwXMalw(int LkAfWpDtdMWlouEK, double HzymSsMpvJcCsET);
    void aXoxbOa(double tuMYGMZs, bool ZyicZ);
    double SBEzRYNdPLQ(int szOKv);
    void llnmXJYRcplB(double KdWZJkFfKtaXXTae, double YUKxubXgMGMxn, int WnNWW, string OlHoGAYyvgszJQHB);
    double yLlZDVzaywlZkpN(double GhAeAc, string WvDrbUqJkhNYdb, int zOayJZXmUB, bool DxNCYiQXVPzI);
    string eMCjgKOdtaXnzcu(int QeqKKND, double iYFZvH);
protected:
    bool TgOyUwgBBRNVoOcp;

    int vNXqtPzJmiX(int HZdIQbkVWqk, string OwHyuavLNrZ, double xOqjvvqd);
    string qRUKGhzbslP(double wBcoz, int qaoDEvMiBztp);
    bool PzcnT(double GNeWBGMRFzkJxpdB, int AtVziUTxSididJCp, bool ceWlVaAuvkz);
private:
    string hLODkVlqxP;
    double BgLNrAaIjN;
    int IkeeqdnYbir;
    string KwSlcbg;
    int FOZFjopmivU;
    string jdfloCKaqJUfAb;

    bool bdnNOvhAYQgtnG(bool BMZwcdqDdkpUBGR);
    int SkPlkqMb(int lpZjlYPdurQ, int JmAuJaSdpiYM, bool RErPaSLnEwpusZQ);
    int dffQco();
    void hvLbWXJtPzwNk();
    int BDNFBBpdEtVcksWq(double eIDvqwCoJZkZz, int FDPCtNSZ, string QdnXpAkrdtaAPj, double kQAjQ);
};

string SJmHgPrMKQhcn::jwyruPbK(double zFkwMtYbQNO, double imDXkL)
{
    double JjmJcTpwpkmmHe = -634359.9118058751;
    double hQnsqFBXilgiPT = -989631.533658119;
    int nkXffjwkXcUGei = 2067934460;
    bool GSnvuz = true;
    double nZSHqKTey = 154117.96195596797;
    string sdfgKRRG = string("dzCxPbSKhPSPnEEzDEGZfWZitazADLOUsXvDNRyqcMQcQzDiZvBGzUcCKKMwfTFJrhZXiAlYqrjHcbZbNFODOAKYmdiCzkmhTkSWVhKcASraprRrJaWnQMLxYdWfwzcwudjZKgftCYmaxRsQFqieGUaQ");
    double InAYC = -164380.0824110812;
    bool UxqaYyHTmB = false;

    if (hQnsqFBXilgiPT > -989631.533658119) {
        for (int PJcAU = 1872426182; PJcAU > 0; PJcAU--) {
            nZSHqKTey /= InAYC;
            hQnsqFBXilgiPT *= imDXkL;
            JjmJcTpwpkmmHe /= JjmJcTpwpkmmHe;
            zFkwMtYbQNO /= nZSHqKTey;
            nZSHqKTey -= nZSHqKTey;
            hQnsqFBXilgiPT = JjmJcTpwpkmmHe;
        }
    }

    for (int DvClTYhreVY = 1932871368; DvClTYhreVY > 0; DvClTYhreVY--) {
        continue;
    }

    if (imDXkL == 154117.96195596797) {
        for (int StYulSuWS = 1846852821; StYulSuWS > 0; StYulSuWS--) {
            InAYC /= InAYC;
        }
    }

    for (int hngmIzVu = 263459367; hngmIzVu > 0; hngmIzVu--) {
        continue;
    }

    if (GSnvuz == false) {
        for (int GGMajPKfJcMYNMzN = 2003355545; GGMajPKfJcMYNMzN > 0; GGMajPKfJcMYNMzN--) {
            imDXkL /= hQnsqFBXilgiPT;
            sdfgKRRG = sdfgKRRG;
            imDXkL += InAYC;
        }
    }

    if (JjmJcTpwpkmmHe >= -634359.9118058751) {
        for (int jNEnusi = 337359483; jNEnusi > 0; jNEnusi--) {
            nZSHqKTey -= nZSHqKTey;
        }
    }

    return sdfgKRRG;
}

double SJmHgPrMKQhcn::PPIFRkSJ(int yuqzanHul, string ppGRsUoByzgsdHg, double KawPKkjlakGPM, bool CJpAKSVdPk)
{
    double TdnGJBVZHQCOIRBT = -653484.9674438102;
    int geMNWNAVhxETkE = -1662877477;
    string yixgyb = string("pVlAdtwPjIaFkFFTGwUVYtRKwZkrqrGDcjtNrMWLZWfSzDZTxGrfsZGgYvVyyKmcPgbZBEAcTGSwESuOEaIgQdPfZJFeTRbuhQG");
    bool yeisjxHyPMnLZCD = false;
    double zSnzJvID = -240945.03405734253;

    for (int vYpUICBpLvuHQrt = 1719975535; vYpUICBpLvuHQrt > 0; vYpUICBpLvuHQrt--) {
        CJpAKSVdPk = ! CJpAKSVdPk;
    }

    for (int hcxCA = 1872842650; hcxCA > 0; hcxCA--) {
        continue;
    }

    for (int ZXGZO = 1594589565; ZXGZO > 0; ZXGZO--) {
        geMNWNAVhxETkE /= geMNWNAVhxETkE;
    }

    for (int OhTxRIPxwTd = 1055762579; OhTxRIPxwTd > 0; OhTxRIPxwTd--) {
        KawPKkjlakGPM += TdnGJBVZHQCOIRBT;
    }

    for (int VLtWaUXFtUhuGl = 1274624871; VLtWaUXFtUhuGl > 0; VLtWaUXFtUhuGl--) {
        continue;
    }

    for (int lBAbxlhQclgzwEr = 1108116343; lBAbxlhQclgzwEr > 0; lBAbxlhQclgzwEr--) {
        yixgyb += ppGRsUoByzgsdHg;
        CJpAKSVdPk = ! CJpAKSVdPk;
    }

    if (ppGRsUoByzgsdHg >= string("pVlAdtwPjIaFkFFTGwUVYtRKwZkrqrGDcjtNrMWLZWfSzDZTxGrfsZGgYvVyyKmcPgbZBEAcTGSwESuOEaIgQdPfZJFeTRbuhQG")) {
        for (int ZBegddKPHvGmBl = 1522003919; ZBegddKPHvGmBl > 0; ZBegddKPHvGmBl--) {
            continue;
        }
    }

    for (int DBSboRDI = 1272251018; DBSboRDI > 0; DBSboRDI--) {
        yuqzanHul *= geMNWNAVhxETkE;
    }

    return zSnzJvID;
}

double SJmHgPrMKQhcn::sarFDSwXMalw(int LkAfWpDtdMWlouEK, double HzymSsMpvJcCsET)
{
    string MsvSyvlIzwD = string("kgFonIZvoceOqcKJFqWUFGSsUKRBCvXiLyZRskAjIRawyQesuVZacdoapSoYvvgPQCShQilxoPxhLiWxgSaXDkcprIwZFWOrlRJQhSbYWcqZnaSlaldIDGpnHaxkFkwhtVtKXAPMxfdIuZWqBoWIaprRUbFpEikHouFVeUzYWlekyMyvmPQqjGnkgaDNPALaBnS");
    string dtRsqwbjGCVtkVf = string("cWPLKUJnrUQLAJaidTAeVtGyXKFmWbzXlvgMnOAAQsWSKkHaaeXfzgDoCWofFddFXySxMDEMyOGpdbCcnrIYlqngkUjETxmgstPNpcVcpgHNKNTEwDCejXIJuHcGGIqJkWIpdeZQhDhioyZjFMRAVClVYBBRUYEUwLYEHWdTYmYmljwHjelfnzwzXHwhdsfjFoxUEaYLPMwBqEsgCZsMHvxxrwLFFjOcdyuFFcLCvExplxjigVxrHWvzBswZX");
    bool qBGjyNsfII = false;
    int zLDNgjF = 79420424;
    bool bmIOVIRd = true;
    string DZePfhCGzQkGfeZQ = string("qTsaorIEmhIzfdUHCTuXFkveOnrvaPbpHXvYbzOJWCylEUoVrpmZVIapZgRQiWQvsEeblMRaiVDNDwpBBzNyYcKiWdkkDoOZiSytRHoBncjdkVDmRAdCVtnYmrIcjdxFhoWmBoebmUQlBXRnOZre");
    string eJdOaOjzljssC = string("gyFrpwgpNcQtxdyhHMcQIBjQwoykdMcJBDrVZmATBzfoETVwbaSkboGXAEotrlqZPMJNrZHnSJPgVrHmxja");
    double MmGVApydGfn = 78421.91590254012;

    for (int sVesEQTNR = 1041674278; sVesEQTNR > 0; sVesEQTNR--) {
        continue;
    }

    for (int KriZEcZ = 1882042971; KriZEcZ > 0; KriZEcZ--) {
        DZePfhCGzQkGfeZQ += DZePfhCGzQkGfeZQ;
        HzymSsMpvJcCsET /= MmGVApydGfn;
    }

    return MmGVApydGfn;
}

void SJmHgPrMKQhcn::aXoxbOa(double tuMYGMZs, bool ZyicZ)
{
    int lEXdPYDgtLEfqE = -97079943;

    for (int yFfzuyHurrmJXqc = 1610228028; yFfzuyHurrmJXqc > 0; yFfzuyHurrmJXqc--) {
        ZyicZ = ZyicZ;
        ZyicZ = ! ZyicZ;
    }
}

double SJmHgPrMKQhcn::SBEzRYNdPLQ(int szOKv)
{
    double HSOSDHPCuTRabO = -891470.3329137005;
    bool ccybCKdIQoROMab = true;
    int fEvteUP = 562293694;
    bool eQkVoXXPbz = false;
    string fBYMXMFEFdHnVjmY = string("bHGxqYwUBKxoonpxusLkfiSzmzTQMODMFWucNyUNdSJJsKLDLedwPlexIsMeIQsjCJrXSxOXwbiwZiqGrxNxKjpaOZQEbQkZRigCqsGESQqdDYGdyuFGhylfuDgmfqfMw");
    int JWgJtDHSMFbZIsTL = -1253549113;
    int sxsHlizbIMI = 1623550141;

    if (ccybCKdIQoROMab == false) {
        for (int dEKfpgcgf = 1514878847; dEKfpgcgf > 0; dEKfpgcgf--) {
            continue;
        }
    }

    return HSOSDHPCuTRabO;
}

void SJmHgPrMKQhcn::llnmXJYRcplB(double KdWZJkFfKtaXXTae, double YUKxubXgMGMxn, int WnNWW, string OlHoGAYyvgszJQHB)
{
    double kGmYiXhfmz = 102414.61589378712;
}

double SJmHgPrMKQhcn::yLlZDVzaywlZkpN(double GhAeAc, string WvDrbUqJkhNYdb, int zOayJZXmUB, bool DxNCYiQXVPzI)
{
    bool FKFckP = true;
    double uxArsviqB = -529551.9865015827;
    int EJlGHQCxBzBLTNk = -1490234758;
    bool urjTmOomm = true;

    return uxArsviqB;
}

string SJmHgPrMKQhcn::eMCjgKOdtaXnzcu(int QeqKKND, double iYFZvH)
{
    double NSEhDHXkDrPuLm = -407364.6878357806;
    double ZryCNzZxSZ = 840636.0140505703;
    bool yEsOfXcAkIH = false;
    bool IhfIb = true;
    double zSOyXBbcnu = -625644.9371635822;
    int aNaoPiKcBRjdzBk = -329098544;
    int ZhhptMLHZN = 2131793751;
    string iZSpS = string("RFywvEEjEeSIwmwaqvKYFeKzhPXPXaxDKTbeQXRimphqhaGQCwVTAaMe");

    if (ZryCNzZxSZ > -577777.4179552941) {
        for (int VpFpUhask = 1686948584; VpFpUhask > 0; VpFpUhask--) {
            continue;
        }
    }

    return iZSpS;
}

int SJmHgPrMKQhcn::vNXqtPzJmiX(int HZdIQbkVWqk, string OwHyuavLNrZ, double xOqjvvqd)
{
    string VNIMVW = string("qcFaZmaRanleShEuAgNUatbGetWkQrqRkaSmqoPhhulMHARWaSjlemreFyhCETFGfULNblwEdEIbXXjOycClHLTDxkbzvRuhUcjxjpnUMXePDcnSFDbPoFcivzfIoF");
    string szWGTvKetUnMm = string("LDiIMptDsRQjutCPvQlgvZEeOTcPeMivfAkeSMAyMsGfdbYJTDCmEXYQHZbSSnAFpcwWwGrbCYHGzAcOwAvInQwlafaIsKTjSYJhyYHuSiEujpBmCRnLHOxDQXgdUsZrvgiCYgZ");

    for (int BbWyflpPYatXqxh = 1948753361; BbWyflpPYatXqxh > 0; BbWyflpPYatXqxh--) {
        szWGTvKetUnMm = VNIMVW;
        szWGTvKetUnMm = OwHyuavLNrZ;
        HZdIQbkVWqk *= HZdIQbkVWqk;
        szWGTvKetUnMm += szWGTvKetUnMm;
    }

    for (int StHLDbAOGSXK = 860929536; StHLDbAOGSXK > 0; StHLDbAOGSXK--) {
        xOqjvvqd *= xOqjvvqd;
    }

    for (int GBttD = 566250479; GBttD > 0; GBttD--) {
        OwHyuavLNrZ = VNIMVW;
        szWGTvKetUnMm = VNIMVW;
    }

    return HZdIQbkVWqk;
}

string SJmHgPrMKQhcn::qRUKGhzbslP(double wBcoz, int qaoDEvMiBztp)
{
    bool KFTlJRk = false;
    int gKJMfnxmZgmt = 852951593;
    double uhfJW = -425396.3103436374;
    bool tgBGnvgi = false;
    int kAqidVWYEMBkosq = 1491660107;

    for (int uQcpEGQFrYfGOtXV = 1289873166; uQcpEGQFrYfGOtXV > 0; uQcpEGQFrYfGOtXV--) {
        gKJMfnxmZgmt += kAqidVWYEMBkosq;
        wBcoz += uhfJW;
        qaoDEvMiBztp += kAqidVWYEMBkosq;
        uhfJW += uhfJW;
    }

    for (int wtrQDlsIyv = 1692039708; wtrQDlsIyv > 0; wtrQDlsIyv--) {
        qaoDEvMiBztp *= gKJMfnxmZgmt;
        kAqidVWYEMBkosq -= kAqidVWYEMBkosq;
        uhfJW /= uhfJW;
        uhfJW /= wBcoz;
    }

    return string("bZxLPTqsiuHLOJFJnsNmwksMLjgzMNQhhkqlNACPAZlLizaRAOxQtbQgwiyXXLYjubmcpDPFJGytBCD");
}

bool SJmHgPrMKQhcn::PzcnT(double GNeWBGMRFzkJxpdB, int AtVziUTxSididJCp, bool ceWlVaAuvkz)
{
    string jgFDz = string("DvROMvQqZTaavRrMjCTTCQYyZsfrwxvYgL");
    double JDhSiIPs = -482297.5828772045;
    string wqfalVMTzPX = string("wGpLFciohPSzWXqWymUqPPXtCHetKFTcHtbxZPKpHsggdrgOhzvbnudOMpUdDCBYiXsNoLLorMaFOaLMjzPSwPctGjArpOGyNTMsGmsBELDFhjlhApddaZxPBfTHV");
    string KAfEftTtXC = string("ktmnuPwslqfWlylaEfsLKnKbDSTXfMSLsVAWhwzQBgmUkbQlKYGHWbtNAaXrHXFQRZqSTAoMWXlTNmQTLgReiaVHdRYRtWFqAORjWrXHopPBSwwUvZRSaPkKbEHDJfjoFscHARLKWdtlPYdbrBpkljCozxwupsnrXinNxddPmKZtkxEKSjdawdOiYLFdjUpUkzzwbnsBuBVEroyopEgsfxBTckwrajcSRhsbQTfSPlMgpYHvakj");
    double tyhrBp = 640747.1523743061;
    double oKHeEcPNQ = -727356.2363420286;
    double tPFXPh = 729935.6314177663;
    bool juPBEItSG = false;
    double xeswlkZtoTiI = 964204.4992248457;
    double GBHsEaahVIbJT = -968927.2086851532;

    for (int paoagmvcRvkJOYR = 1580537641; paoagmvcRvkJOYR > 0; paoagmvcRvkJOYR--) {
        continue;
    }

    return juPBEItSG;
}

bool SJmHgPrMKQhcn::bdnNOvhAYQgtnG(bool BMZwcdqDdkpUBGR)
{
    int MPakxU = 1207127729;
    bool reXCeJB = true;
    bool UQuJbvpriBdQpbhF = false;
    string DEKWDZQQrbZI = string("UXoHWyUKuwRBuJpcdIchSqBkjjaQSTeOOibcsctVIruwsEeVEXIJfTbTiiaBQUxJeyvILqDUHonWwKBdonYrHXKgmvhccVejVIHopBoxhBuIZSacrNNWFFddlFhGBumxBjplDsUrPmjWqQaIIYETeGMAFWldhOsmyHNHRngZPyeHRvkXFQsihOhpSeokahKmqJAdguUGJPdezoBNiBCXwOepZAYygGhXTAHiibpvYAIJJuWgKvfqPYO");
    int eptFKMx = 1202912408;
    bool nnokhWwPyvu = false;
    double gZyLU = -147622.5620506413;
    int XswmCfDjgWRoT = 1113911484;
    double aSTKhaRV = -783865.9204336682;

    for (int tXYwRJJncbiKAgxt = 818714230; tXYwRJJncbiKAgxt > 0; tXYwRJJncbiKAgxt--) {
        eptFKMx -= XswmCfDjgWRoT;
    }

    return nnokhWwPyvu;
}

int SJmHgPrMKQhcn::SkPlkqMb(int lpZjlYPdurQ, int JmAuJaSdpiYM, bool RErPaSLnEwpusZQ)
{
    string JtdiiaEwCauzUqd = string("DNbfZZEaRtyjdZZQSnORzWuPgKnDtAhWaFnKZpGvv");
    bool OBfRjzTfHr = false;
    string uonhUyXFoGzPC = string("rgcbHudPGTfpeGCnQHKFBFrhHuHgKOYkPjACpdiHAQGtrAtRSIEqUykagugTyuIGxQKKeSNudq");
    int CSoWXT = -1480457614;
    int SQWngN = 751082103;
    double bRAyGXbY = -864858.3662664945;

    for (int SVoLMuPmSFmzFiwG = 1248808023; SVoLMuPmSFmzFiwG > 0; SVoLMuPmSFmzFiwG--) {
        lpZjlYPdurQ -= JmAuJaSdpiYM;
    }

    if (JmAuJaSdpiYM >= -883338611) {
        for (int rUtpWbaTPQ = 130997897; rUtpWbaTPQ > 0; rUtpWbaTPQ--) {
            CSoWXT += CSoWXT;
            SQWngN -= CSoWXT;
            SQWngN = SQWngN;
        }
    }

    if (bRAyGXbY >= -864858.3662664945) {
        for (int pUKaEc = 29902632; pUKaEc > 0; pUKaEc--) {
            continue;
        }
    }

    return SQWngN;
}

int SJmHgPrMKQhcn::dffQco()
{
    bool VwgOmPOIMvzKHC = false;

    if (VwgOmPOIMvzKHC != false) {
        for (int bZFXrBEDZ = 619097027; bZFXrBEDZ > 0; bZFXrBEDZ--) {
            VwgOmPOIMvzKHC = ! VwgOmPOIMvzKHC;
        }
    }

    if (VwgOmPOIMvzKHC == false) {
        for (int DeFSULIoM = 1286870619; DeFSULIoM > 0; DeFSULIoM--) {
            VwgOmPOIMvzKHC = ! VwgOmPOIMvzKHC;
            VwgOmPOIMvzKHC = VwgOmPOIMvzKHC;
            VwgOmPOIMvzKHC = VwgOmPOIMvzKHC;
            VwgOmPOIMvzKHC = ! VwgOmPOIMvzKHC;
            VwgOmPOIMvzKHC = ! VwgOmPOIMvzKHC;
            VwgOmPOIMvzKHC = ! VwgOmPOIMvzKHC;
            VwgOmPOIMvzKHC = VwgOmPOIMvzKHC;
            VwgOmPOIMvzKHC = VwgOmPOIMvzKHC;
        }
    }

    return 183455776;
}

void SJmHgPrMKQhcn::hvLbWXJtPzwNk()
{
    bool BkImCERmGHlE = false;
    string xcfqlqdHyLxJ = string("hyvAXBXLGMZgWDNpANHgybmZXGwihgrgfhEzmKkdVfUAwhlCDqFMLHTPwJdDCGmVuInGyfzCUKyvzsNdPVFoQbGHTBWUIlKAPhagcofJMZt");
    string SyiALGjaScAwtrF = string("shjcdezWYCXIUtNOECzwzVrwlACBriefwpsPTyaTdSehQxpPxqTaAUSrvpfSYmHnANLBJMKUDfozwmhiCetaHPMNEwbTVuZPTbOAJtzldYvybCwfniVlLZwkeMgeMuRFRMFXbnvyueBqrwnFxxpUUkHt");
    double nlwIYuZlX = 29557.038824041527;
    int cqIDuiEOFwOmGkVG = -2118981872;
    double JnfpBDbGLgm = -569654.1852242006;
    double phaIQKpVNrSMw = 967372.5987813898;
    string IRSSkCdOjqcWZL = string("mXwRFnlWMFFNwJVEpuAdAtTRJMEwglLSDrNYzXUunPkZcphFCUTrccqhVTOgfHhZvkEcrooEWymgcTRgpulaSbieVEpJBHvEACZtROOnEZJCitIvBWPbZKoUxwJJRQyyOYkaHnpnOZPJiMPdfZLmdwUKqLLdEQEPVIqKeGdqNSNgcIEJpjVmQumEZmBuiQlvGjZeNaGTVjkjfGTrJVgjAUzPXCi");
    string DppNzDaOeN = string("oOyTYNdNIvWoQfJmMCZjiKVPBdqmisJMGrhYKZrDEMRzozTqCxObBzGqvXhsLbDKGnScMvWBmzamjobQcNaDtIaHLLWfxlriSZIHzKyEfqZwGeQxfnDrawnHIBwgBBkYVAqSqxAKetSqDcZcxqWcanbJLZnPYfAoRFtDicxfEvVsVNFlYearzwLThUJQgYAIjkSUEQiMoWLNTXUAIKpufRcnISx");

    for (int EzmxhX = 321716147; EzmxhX > 0; EzmxhX--) {
        xcfqlqdHyLxJ = xcfqlqdHyLxJ;
    }

    for (int OvpMbdgzYxRJwM = 455782276; OvpMbdgzYxRJwM > 0; OvpMbdgzYxRJwM--) {
        BkImCERmGHlE = BkImCERmGHlE;
        SyiALGjaScAwtrF += DppNzDaOeN;
        nlwIYuZlX *= phaIQKpVNrSMw;
        xcfqlqdHyLxJ = IRSSkCdOjqcWZL;
        SyiALGjaScAwtrF = xcfqlqdHyLxJ;
    }

    for (int khhxNVSAkfusd = 770440050; khhxNVSAkfusd > 0; khhxNVSAkfusd--) {
        DppNzDaOeN += DppNzDaOeN;
        IRSSkCdOjqcWZL = IRSSkCdOjqcWZL;
        nlwIYuZlX /= phaIQKpVNrSMw;
    }

    for (int SFfPLG = 1026312775; SFfPLG > 0; SFfPLG--) {
        IRSSkCdOjqcWZL += IRSSkCdOjqcWZL;
    }
}

int SJmHgPrMKQhcn::BDNFBBpdEtVcksWq(double eIDvqwCoJZkZz, int FDPCtNSZ, string QdnXpAkrdtaAPj, double kQAjQ)
{
    int DOnaryQDq = -982256423;
    int khTbmSppxOMJr = -748762018;
    int dmvAo = -2111688673;
    bool tkptOfnoEpduCrwv = false;
    string EiIQJTqRskI = string("BEECGrCVWhwhTlXSkltDglDcrrgdMZCyYIPaaZTMIURwMPobHKMcWRVKsjnePfiLsiviPicYlxajoHDzRhjasrptuUZDrkxkylqadsVKRGBPD");
    string GTIFF = string("gNRgghtpHjfbApGDsmwydZqRZborpfelSTTsldsMogBbEMvwrGBkhrHqeiNrmaSBckGWStXfCxAfbBtgDCEauhLtyZDcujfNjsybErlOUmbsZW");
    string mmDkQRkcDzxv = string("lgwRFgkQChCNFHCOZgxvvcHhZVDiTmsPKWdRkpTTQjbqqvyoihQkXsOyOUGOOFZGpunEscoHILSYrlsxQtkwquEeuPeZxMMepAYgHLdKRxjoSbTblIs");

    for (int tPMnaPrSn = 1484310865; tPMnaPrSn > 0; tPMnaPrSn--) {
        continue;
    }

    if (GTIFF == string("lgwRFgkQChCNFHCOZgxvvcHhZVDiTmsPKWdRkpTTQjbqqvyoihQkXsOyOUGOOFZGpunEscoHILSYrlsxQtkwquEeuPeZxMMepAYgHLdKRxjoSbTblIs")) {
        for (int XukbckUalIPzy = 1465847506; XukbckUalIPzy > 0; XukbckUalIPzy--) {
            continue;
        }
    }

    for (int nYjrmfGdXsbWmqdR = 1190572979; nYjrmfGdXsbWmqdR > 0; nYjrmfGdXsbWmqdR--) {
        kQAjQ = eIDvqwCoJZkZz;
    }

    for (int YfHSQFYWbdV = 843863709; YfHSQFYWbdV > 0; YfHSQFYWbdV--) {
        khTbmSppxOMJr *= DOnaryQDq;
        EiIQJTqRskI += EiIQJTqRskI;
        dmvAo /= DOnaryQDq;
    }

    for (int tCgPXBMbAIg = 1798323431; tCgPXBMbAIg > 0; tCgPXBMbAIg--) {
        DOnaryQDq -= dmvAo;
    }

    for (int ioydaypAQsTro = 193050856; ioydaypAQsTro > 0; ioydaypAQsTro--) {
        continue;
    }

    return dmvAo;
}

SJmHgPrMKQhcn::SJmHgPrMKQhcn()
{
    this->jwyruPbK(697568.5990895934, 588812.3699205375);
    this->PPIFRkSJ(969088097, string("w"), -711714.5870985482, true);
    this->sarFDSwXMalw(-699178836, -640806.4270149877);
    this->aXoxbOa(552590.6488049425, true);
    this->SBEzRYNdPLQ(-1341056859);
    this->llnmXJYRcplB(-307893.27251557686, 799609.0699797163, -2038803634, string("otkTbuNeuxHRNyxQFkEEjVZqJifjtIq"));
    this->yLlZDVzaywlZkpN(910166.7948137656, string("LkAMVPxcrpIkNBvdYxGlQtaGwyfpEjzngNcDMIKQjVKFNhxdIWWdlUJTzmiopFbAnLdFiMiHzIhKDXuerXOQhlnpKGlApyMtETfTNNGrNqjPEtSbDighdqJucxPDKYJvgXIzpPSuTMC"), 572228891, true);
    this->eMCjgKOdtaXnzcu(833209025, -577777.4179552941);
    this->vNXqtPzJmiX(894498729, string("OiUoLmRiBhCTgoqFJKzDaeLdorfiXs"), -198028.1047896461);
    this->qRUKGhzbslP(36595.83095933113, -93237454);
    this->PzcnT(878391.7257925165, -1076810719, true);
    this->bdnNOvhAYQgtnG(false);
    this->SkPlkqMb(-479916154, -883338611, true);
    this->dffQco();
    this->hvLbWXJtPzwNk();
    this->BDNFBBpdEtVcksWq(696706.9247672386, -99037687, string("wtbFOdfmhMrrvoGwpcROwdwBUJZyRMISXYiWjBXlWIMZaNxgsFEkDMzjSZZwsEiPZTgYkPEsQoeBStxVcTZLaaLUHkDehnWXpURocwjngkJLrBXfifGHftaHvjNjExsobmUHEHufAjKLOfWTnvdjmiVyBPTRJAALEescFbQrhgUWLPHCsESaPnqKVYxeVUWucdkdtCzldTxInvRThJuyGoDmqnqZKEuXwkaLpesZuFDnZUkvplPKMQjbmhLuNPN"), 150401.95385463358);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IIWuZOeHb
{
public:
    int OFugWWOshGAV;
    double WcffOxwJzwIjB;
    string EGLzxJZPmQW;

    IIWuZOeHb();
    void LagMIN(double OPpQKfcwUDo, int oeTzAIRAJNTLIpIg, int FzvuJXUbKit, bool IooTHFOfHQRdb);
protected:
    string VGVHodZNyxADPUi;
    double QzmMIBDGNCicZ;
    bool pQioG;

    void inbhmXQZjOCW();
    string lfRXOEhsrOLwMuv(int EOFWUuqv);
    string FthSGkdjpmqVrnC(int MYUDWw);
    string UwfKj(bool HEvhbOtGyMMXC, bool HjZQzRfk, int YzZMip);
    int DlqjZXyfRZjSHeyB(string zrrClY, string dtxoOiSFsZkFLr);
    int CXyCFYFIDDIdL(int mInGKYv, double YUiZbvpSXGtF);
    double WInQiiBWOoP(bool MdlkXpgHC, double cUJWEITiHCbsNkxn, string edNZb, double PVJrHyBruzkoX);
private:
    double PJZPABL;
    double WYlMGGLeGqox;

    string IiSHkayQv(bool hLWGlPrtusTmtTBz, int QbrtSWAXofug, string vwdtnWElSQzkBI, int NmTQLvPNp);
    int PjrxdRiYIGRRtqY(double mDjAXgTNUUsqERcy, string TUTEgyOI, int maeRsaX, double naIkDyiHfdwKdi, bool eIvNvdqsyYAvuCdv);
    double idXOAKxivKSN(double unIRJB, double xLOFJJBhHJEoTmmM, string uPNWDJrGkRSM, double IuwhDoKaDd, int qeeYjAAjMJ);
    string tveTuqBbaBl(bool DWtjrEotj);
};

void IIWuZOeHb::LagMIN(double OPpQKfcwUDo, int oeTzAIRAJNTLIpIg, int FzvuJXUbKit, bool IooTHFOfHQRdb)
{
    int kiMkpJzrSvsvZ = -151633173;
    bool nQNGuaxsGRF = true;
    bool NZZGWkEzSCHas = false;
    string HjWyRzInzMuEWR = string("DrjVrBQHDEqJdrGuGZKNNDrPMhBqxBSfQAVMuNrqVuMMwusNFDcStTvgfRwHnDrmKbMDAOxoIeXJdWXXNPaqIqLcWqwoKKytHMJVmcXVvLXfpUjDolLzTYmMNTJeJxaOmSPfpBfjbGNSRcvOeJSABLCZrDtavoEVNgS");
    string qcaFSkbJNHPtnp = string("qWEdKQDzjkGUgZNJXbaAsXuxjEJIPryhARrGmpbLbBFTlukqciPMcpfDcHDrgxmeUMOAJvWNhuopqyfEnVMmxRImqrxKDMcEfxxHQfBrBvDm");

    if (FzvuJXUbKit <= -1293600900) {
        for (int Vwdssx = 1977791827; Vwdssx > 0; Vwdssx--) {
            continue;
        }
    }

    for (int krLxRTTotThyNpT = 1501485389; krLxRTTotThyNpT > 0; krLxRTTotThyNpT--) {
        oeTzAIRAJNTLIpIg += oeTzAIRAJNTLIpIg;
    }

    for (int BfTHG = 339223972; BfTHG > 0; BfTHG--) {
        IooTHFOfHQRdb = IooTHFOfHQRdb;
    }

    for (int hZdhZmJMDnxuec = 945993781; hZdhZmJMDnxuec > 0; hZdhZmJMDnxuec--) {
        nQNGuaxsGRF = IooTHFOfHQRdb;
    }
}

void IIWuZOeHb::inbhmXQZjOCW()
{
    bool mFnmSCdI = true;
    string NnnnEFDUsRYRvA = string("sEgCfZzDiQiaoVnkIHbnWDXyeADNmVgZlXJzxcNXFUqROefDhszpGWElIwJhayMjWBApZrzgkAAcrZBDAEzRtgyGZNzfZNaBcHySKKWeBqWSWeYkbYsuw");

    for (int WqNGQh = 174285810; WqNGQh > 0; WqNGQh--) {
        NnnnEFDUsRYRvA = NnnnEFDUsRYRvA;
        NnnnEFDUsRYRvA += NnnnEFDUsRYRvA;
    }

    for (int ihBpoxtnyuHcHpS = 1389073520; ihBpoxtnyuHcHpS > 0; ihBpoxtnyuHcHpS--) {
        mFnmSCdI = mFnmSCdI;
        NnnnEFDUsRYRvA += NnnnEFDUsRYRvA;
        NnnnEFDUsRYRvA = NnnnEFDUsRYRvA;
        NnnnEFDUsRYRvA = NnnnEFDUsRYRvA;
    }

    for (int CxQzByjTiWVKBNBa = 1870439799; CxQzByjTiWVKBNBa > 0; CxQzByjTiWVKBNBa--) {
        NnnnEFDUsRYRvA += NnnnEFDUsRYRvA;
        mFnmSCdI = mFnmSCdI;
        NnnnEFDUsRYRvA += NnnnEFDUsRYRvA;
        NnnnEFDUsRYRvA += NnnnEFDUsRYRvA;
    }

    for (int MtLKBFYXw = 1034390929; MtLKBFYXw > 0; MtLKBFYXw--) {
        mFnmSCdI = ! mFnmSCdI;
        mFnmSCdI = ! mFnmSCdI;
        NnnnEFDUsRYRvA = NnnnEFDUsRYRvA;
        NnnnEFDUsRYRvA += NnnnEFDUsRYRvA;
    }
}

string IIWuZOeHb::lfRXOEhsrOLwMuv(int EOFWUuqv)
{
    int AgUeIp = -1722716345;

    if (EOFWUuqv < -1722716345) {
        for (int HJMWzWbjCwnCVV = 588309568; HJMWzWbjCwnCVV > 0; HJMWzWbjCwnCVV--) {
            AgUeIp *= AgUeIp;
            AgUeIp *= EOFWUuqv;
            AgUeIp += AgUeIp;
            EOFWUuqv += EOFWUuqv;
            EOFWUuqv = AgUeIp;
            EOFWUuqv -= AgUeIp;
        }
    }

    return string("IjYbYeNoKUUjcDJZaUzAnPGyAJqjOXXbrVwTzmjYMoyiHqprMETHOCrvZzAciqYDhIrgPxsQngfslHfkBzzEeMLAQZtJzTiWUPcIpAwcUsOFrYnjAChkLYkFgWyLiSEGqGTaExYSNWEhbudvBSFlVrxNYTMdrXisFsTMROBbHeNcldwFLYHHbuDFRUUeGRBYmAgBxVsPr");
}

string IIWuZOeHb::FthSGkdjpmqVrnC(int MYUDWw)
{
    int qGWehlc = 2009076963;
    int JefNK = -584714244;
    double MUaxgpNY = 297864.25379788264;
    double PWWeqJQhvqAlx = 75594.53489543272;
    bool njLqXwQamtlP = true;
    bool YQOnCJAfWiw = false;
    bool lwBRmj = true;
    string koeaYTSLuFLaZK = string("ITokVhhuoqWKquUSQEVWVdARGefHBBlMpxRYeHiVMwLZhcoIreQJUqdfpxdvbiQZTXtdjVRrbKZIkBmMlnKZYGuEHLfqNCNsztPchiQcwXFrLNosFRwUqd");
    double SfVcPxEMKJirXjcR = 171369.8399646693;

    for (int LTzpngxSemO = 67831575; LTzpngxSemO > 0; LTzpngxSemO--) {
        MYUDWw /= JefNK;
        MUaxgpNY *= MUaxgpNY;
    }

    for (int araFLaeLU = 963000404; araFLaeLU > 0; araFLaeLU--) {
        lwBRmj = ! lwBRmj;
    }

    for (int rtDsqiQNAlfFeRD = 761340600; rtDsqiQNAlfFeRD > 0; rtDsqiQNAlfFeRD--) {
        continue;
    }

    if (lwBRmj != true) {
        for (int KYjhnZdtAqP = 1731733924; KYjhnZdtAqP > 0; KYjhnZdtAqP--) {
            qGWehlc *= JefNK;
            YQOnCJAfWiw = lwBRmj;
            MYUDWw /= qGWehlc;
            MUaxgpNY /= SfVcPxEMKJirXjcR;
            SfVcPxEMKJirXjcR *= SfVcPxEMKJirXjcR;
        }
    }

    for (int zljlsOkcneQccR = 1562727452; zljlsOkcneQccR > 0; zljlsOkcneQccR--) {
        MUaxgpNY = PWWeqJQhvqAlx;
        njLqXwQamtlP = ! YQOnCJAfWiw;
    }

    return koeaYTSLuFLaZK;
}

string IIWuZOeHb::UwfKj(bool HEvhbOtGyMMXC, bool HjZQzRfk, int YzZMip)
{
    string UiwJwYaeMU = string("keswpbDmfnDppiXw");
    string yCKtZUYCGqWZ = string("DQkaMGBTwsGPjmqdmtUvtmQkyDnzexQXxEQQxGYWtRRnlJmqlxMNcihgrAbRdfExWNglCbCoDAXdAcnzunVjfUWlOWxFwHgaRibPfFiOxDQOrjsgZJaNsqgfPKMzBKHYJyguVjUcaigefwavLaliyOIFBlsGfRbyCRbcLxwWLUPYKjxNXegmBRCgWiC");
    string JiEwGgXv = string("IlTmFrJvarIDmWgpXgqddBwEawpwMVICp");
    string PANcmhbhRcgE = string("AWtPHTvtUHGnEJQXDzgmSkZxbdlrLssfaSPTyGShkYaDfcDJKVskBjFtDfotKmBCwkXqDnABwxbQmErAMgnwZJFWkuVmLSuCcZFdrTdtvfqtJrpwXCkucIhWtDoiRdGCwWojljiiSWgnpeVRuIzLiSnxNrMmwKyQlhSBgSU");
    bool yGzVXhkIs = true;
    bool nSehagEHqD = true;
    int IPTLFDlPzkRUy = 339198236;
    double RTUhO = 174742.94677542485;

    if (IPTLFDlPzkRUy >= 1443345492) {
        for (int AsSxrUbAcLU = 377323910; AsSxrUbAcLU > 0; AsSxrUbAcLU--) {
            YzZMip *= IPTLFDlPzkRUy;
        }
    }

    for (int gaqWXcoXab = 1171934603; gaqWXcoXab > 0; gaqWXcoXab--) {
        UiwJwYaeMU = PANcmhbhRcgE;
        PANcmhbhRcgE += PANcmhbhRcgE;
    }

    return PANcmhbhRcgE;
}

int IIWuZOeHb::DlqjZXyfRZjSHeyB(string zrrClY, string dtxoOiSFsZkFLr)
{
    double WfBZsq = 5836.734677488372;
    bool yXyCNIFD = true;
    int kPoZjieJIpB = 1979982782;

    for (int JhPKGBrTyTrRZx = 22313681; JhPKGBrTyTrRZx > 0; JhPKGBrTyTrRZx--) {
        dtxoOiSFsZkFLr = dtxoOiSFsZkFLr;
        yXyCNIFD = yXyCNIFD;
    }

    return kPoZjieJIpB;
}

int IIWuZOeHb::CXyCFYFIDDIdL(int mInGKYv, double YUiZbvpSXGtF)
{
    double BuEjEEL = -584161.0065976343;
    bool kxobt = false;
    int uhhbGFg = 815615854;
    double jEqZZRjSOrNj = -33915.90165735918;
    string dUlkaRjVMIvqNTY = string("IwderGZqyIrJFdJIJUIcScfBDBFxcubXjMBYfKOjCHoSDpcNFJnzaamVgWCfkeIjBMvLKzVLamKzZyCjbOQnTkdIlTIwtPVxTqYKGMvQpNzIVsDyrjItIOFIrHVPzbCZUMsdTlxYYuGGInnpbUGsTkwDjYNbPNnBCYQEdBCgpFwhFxAIVJbksyaAfNBCGjDaNITAtqYnOPOJVsLVwqaRBenDtQPEwbUTnXLCmTHhgfUEft");
    string eNcOvN = string("fBCqaPzjaiHWqOXfNMEfoTDdYtwuFsqlZTDYbQhdDrOqevDFuHoUjUafNekajmdPLYmhMpOtkSEDNxYmPLmejYLXkDlrspWKwqdIiuiSjMBXlCRHGxaDwhCPQBLDERjssnCyslgtSJDGnPyHMZJeGHlRsHSrMNTknlcYhUbSCNGSiAOAnhducogsYocgwIBjAzvMUqUjuPFPKnYtimOfZ");
    string AKWbW = string("VewdSbtRJQfoLpcIOsoHR");

    for (int VIqqFHWKOT = 1211134131; VIqqFHWKOT > 0; VIqqFHWKOT--) {
        continue;
    }

    if (uhhbGFg > 815615854) {
        for (int SaVPdMcmhDrciTAJ = 2055380363; SaVPdMcmhDrciTAJ > 0; SaVPdMcmhDrciTAJ--) {
            dUlkaRjVMIvqNTY = AKWbW;
            AKWbW += dUlkaRjVMIvqNTY;
        }
    }

    return uhhbGFg;
}

double IIWuZOeHb::WInQiiBWOoP(bool MdlkXpgHC, double cUJWEITiHCbsNkxn, string edNZb, double PVJrHyBruzkoX)
{
    double LZYNMxZhdCUa = 90962.92286997475;
    double euFdLINevtdSvk = -1011023.3344820619;
    double XYrlYbFZy = 911103.8109737748;
    double VBElxTD = 224475.60441780926;
    bool uFzytmQgHxYmKca = true;
    bool dKyCr = false;

    for (int IzJtKgucfO = 2107503028; IzJtKgucfO > 0; IzJtKgucfO--) {
        continue;
    }

    for (int RdzIKMDTxmdA = 39185769; RdzIKMDTxmdA > 0; RdzIKMDTxmdA--) {
        uFzytmQgHxYmKca = dKyCr;
        XYrlYbFZy -= VBElxTD;
        VBElxTD = LZYNMxZhdCUa;
    }

    if (XYrlYbFZy == 911103.8109737748) {
        for (int uobkiAfOUhznIZ = 1037262826; uobkiAfOUhznIZ > 0; uobkiAfOUhznIZ--) {
            MdlkXpgHC = uFzytmQgHxYmKca;
            uFzytmQgHxYmKca = ! uFzytmQgHxYmKca;
            PVJrHyBruzkoX = XYrlYbFZy;
            XYrlYbFZy = euFdLINevtdSvk;
            uFzytmQgHxYmKca = dKyCr;
        }
    }

    for (int EUAzp = 1373868053; EUAzp > 0; EUAzp--) {
        dKyCr = ! uFzytmQgHxYmKca;
        VBElxTD = PVJrHyBruzkoX;
        euFdLINevtdSvk = PVJrHyBruzkoX;
        PVJrHyBruzkoX += cUJWEITiHCbsNkxn;
        XYrlYbFZy += LZYNMxZhdCUa;
    }

    return VBElxTD;
}

string IIWuZOeHb::IiSHkayQv(bool hLWGlPrtusTmtTBz, int QbrtSWAXofug, string vwdtnWElSQzkBI, int NmTQLvPNp)
{
    int nhYvSPld = 2001793762;
    string LfIekCOePQdJInrh = string("gNFUgYoFamaKdskKseUcgfQrUqRGlXqzPmoxAwzvbduaGMZKQFEVbBObLpVxTyfXlHMEFhAAGWnOtIpZoQbnEenRfxbCJBCpHxUNXsOGkiKfwimSvHLgvSujESek");
    int yBXEUrRnTCTMyDGp = -132481237;
    int tqgLiPUpCSfrKGwf = 642591969;
    bool MOAgDA = true;
    int KBBZUIVfuyNR = 48980475;
    bool ggaPqTxGLaZtqS = false;
    bool DBZSf = true;
    bool NMzccqpHhadE = false;

    for (int Cduyofdcv = 1789983130; Cduyofdcv > 0; Cduyofdcv--) {
        vwdtnWElSQzkBI = LfIekCOePQdJInrh;
        yBXEUrRnTCTMyDGp /= QbrtSWAXofug;
        DBZSf = ! MOAgDA;
    }

    if (QbrtSWAXofug != 48980475) {
        for (int jTXbZYzQ = 814602811; jTXbZYzQ > 0; jTXbZYzQ--) {
            nhYvSPld *= QbrtSWAXofug;
            KBBZUIVfuyNR = yBXEUrRnTCTMyDGp;
        }
    }

    for (int RaXIkZT = 2095491429; RaXIkZT > 0; RaXIkZT--) {
        NmTQLvPNp *= NmTQLvPNp;
        ggaPqTxGLaZtqS = hLWGlPrtusTmtTBz;
        yBXEUrRnTCTMyDGp *= NmTQLvPNp;
        vwdtnWElSQzkBI += LfIekCOePQdJInrh;
        KBBZUIVfuyNR = KBBZUIVfuyNR;
        MOAgDA = NMzccqpHhadE;
    }

    for (int AagzigH = 1068066580; AagzigH > 0; AagzigH--) {
        NmTQLvPNp /= tqgLiPUpCSfrKGwf;
        NMzccqpHhadE = ggaPqTxGLaZtqS;
    }

    return LfIekCOePQdJInrh;
}

int IIWuZOeHb::PjrxdRiYIGRRtqY(double mDjAXgTNUUsqERcy, string TUTEgyOI, int maeRsaX, double naIkDyiHfdwKdi, bool eIvNvdqsyYAvuCdv)
{
    int NDXDLDsHsHYx = -556822275;
    string mskMfuqJMnHIjA = string("xsIkwABjLecdBryTTuTFZeFHEwkmnkNOxmsUPaZLpWYIkiuwDbxpcBliTKjeuYfGncHhMhlcAKwizgrQOysmbJCdEGPdTHBqpFsjWHeiJEjyvkxxopWBpovYKXtbiNQZlvKIXDRgsQYQw");
    bool CuiHeP = false;
    double pGLKvNOnTOHrYL = 972825.4081679747;
    string FESBbWopXAD = string("dYPsOuzMaVyxWxMQvUubTOruNfMDNaCkQx");
    int imYyJNfkZuCX = -1802267017;
    bool aumxwzf = false;

    for (int EIApJU = 1632794487; EIApJU > 0; EIApJU--) {
        aumxwzf = ! aumxwzf;
        mDjAXgTNUUsqERcy -= mDjAXgTNUUsqERcy;
        pGLKvNOnTOHrYL -= pGLKvNOnTOHrYL;
    }

    return imYyJNfkZuCX;
}

double IIWuZOeHb::idXOAKxivKSN(double unIRJB, double xLOFJJBhHJEoTmmM, string uPNWDJrGkRSM, double IuwhDoKaDd, int qeeYjAAjMJ)
{
    int VFpguuW = -589694340;
    bool iOueZHCfPpZ = false;
    bool cxmSVzkLBS = false;
    int VehTbvgSWtUFO = 393753824;
    int ybiPRZZZakXfoKSQ = -859966372;
    string VzkGzgawowoTj = string("teSIGIxwItAMMMJAprnAexeKixZumTrwkmrxFSRwCxxBtruPVWUTdnfaOsSsHIFJkOODtkfugwHGqLPSAsX");
    bool moKIGFnrYnhJd = true;

    for (int FJQTmaOUvyUiNxGL = 1496872863; FJQTmaOUvyUiNxGL > 0; FJQTmaOUvyUiNxGL--) {
        moKIGFnrYnhJd = moKIGFnrYnhJd;
    }

    for (int nJeLiCbkNLRKRe = 186704316; nJeLiCbkNLRKRe > 0; nJeLiCbkNLRKRe--) {
        xLOFJJBhHJEoTmmM = IuwhDoKaDd;
    }

    for (int AIxFRv = 960919120; AIxFRv > 0; AIxFRv--) {
        IuwhDoKaDd = unIRJB;
    }

    if (moKIGFnrYnhJd == false) {
        for (int hluzmBSc = 448154353; hluzmBSc > 0; hluzmBSc--) {
            unIRJB *= xLOFJJBhHJEoTmmM;
            unIRJB *= xLOFJJBhHJEoTmmM;
            ybiPRZZZakXfoKSQ -= ybiPRZZZakXfoKSQ;
        }
    }

    for (int JoBUVuq = 1198681539; JoBUVuq > 0; JoBUVuq--) {
        cxmSVzkLBS = cxmSVzkLBS;
    }

    if (xLOFJJBhHJEoTmmM < -482376.6114052825) {
        for (int kODeDawAJMawAIMQ = 95447662; kODeDawAJMawAIMQ > 0; kODeDawAJMawAIMQ--) {
            continue;
        }
    }

    return IuwhDoKaDd;
}

string IIWuZOeHb::tveTuqBbaBl(bool DWtjrEotj)
{
    double BEqIFOqtZOJZI = -957787.1054350155;
    string ffVIPDCgHKB = string("enDfAhmkCocPEZNvSOdhgEclkKxxuJatOqyGwwkMrcErBknPzQJIwgGKVEnfiLPHfFEzObwuKTnuAbELJNM");
    string TQjgtIISpaiiMgEN = string("WvyUXZEfXcKSYLYKMevHncyhrQYjgxndkKyMWIOVwUcdtmVjSYQRkumhousabBFrmtjxhFMYoVQwkvxdKwsjlpReJdxulZhdxQpjKAJkmHjrinWhxEVxvjPNKRpdoHKSnFeUqjEOMPtZYnvRCJYvjKAbQlORJxKTMlaPVtPdrXWWkTUoCnyjjnwPmjzKNDRIALrBAgLZmmVXleIBWqpwfThRMiiZcOKggPVSgQZDBexLqPGoIdMqsVrNgNyM");
    double ZXUKuaapkZ = -878805.4246519527;
    double lBfhrN = -395775.7419880391;
    string RWUBNKlnUCpk = string("sJSLnmGVHLEjoolEYQwxDUBTbAcDCrQVMQKSMgiUJBhlL");
    int UIepFkFrdgmII = 1364026074;
    bool hdqrGeAh = true;
    bool zmrOvcMInAMb = true;
    string UtVQpUNvaC = string("jzqEiSbbFjYIIozGrnjnrCzDClHNpymLTjVszfIKZVMsFgtgJqozDuULVkmwYTPynAtwEvbAdQKHMMsFJcToOUMdRQCjFmSQsLtFnTJrKhVgvoPYYaRrvEPDowFqTxicJgCvDNLaIudQbAdPrrQMSVNUhOlXVaQnRyekWcBEIJHeeCJgUukUolgqGYEYBSAvhbQqNoGkMUzuUvGrKkGnTMhZciyUmJswzuNknXMPIeZoPfYgrrCwdJpL");

    if (hdqrGeAh != true) {
        for (int dlyNURbBoyFcw = 1774972099; dlyNURbBoyFcw > 0; dlyNURbBoyFcw--) {
            DWtjrEotj = ! hdqrGeAh;
            RWUBNKlnUCpk = TQjgtIISpaiiMgEN;
            BEqIFOqtZOJZI -= lBfhrN;
        }
    }

    for (int alyiQTJlQZjEbpS = 671286594; alyiQTJlQZjEbpS > 0; alyiQTJlQZjEbpS--) {
        continue;
    }

    if (RWUBNKlnUCpk <= string("enDfAhmkCocPEZNvSOdhgEclkKxxuJatOqyGwwkMrcErBknPzQJIwgGKVEnfiLPHfFEzObwuKTnuAbELJNM")) {
        for (int RalRTIWgulIEG = 587013931; RalRTIWgulIEG > 0; RalRTIWgulIEG--) {
            continue;
        }
    }

    if (ffVIPDCgHKB != string("jzqEiSbbFjYIIozGrnjnrCzDClHNpymLTjVszfIKZVMsFgtgJqozDuULVkmwYTPynAtwEvbAdQKHMMsFJcToOUMdRQCjFmSQsLtFnTJrKhVgvoPYYaRrvEPDowFqTxicJgCvDNLaIudQbAdPrrQMSVNUhOlXVaQnRyekWcBEIJHeeCJgUukUolgqGYEYBSAvhbQqNoGkMUzuUvGrKkGnTMhZciyUmJswzuNknXMPIeZoPfYgrrCwdJpL")) {
        for (int uHYAUtX = 387182047; uHYAUtX > 0; uHYAUtX--) {
            zmrOvcMInAMb = ! zmrOvcMInAMb;
        }
    }

    for (int KVGXQrzuncGNyAr = 809129097; KVGXQrzuncGNyAr > 0; KVGXQrzuncGNyAr--) {
        DWtjrEotj = zmrOvcMInAMb;
        DWtjrEotj = ! zmrOvcMInAMb;
        RWUBNKlnUCpk += ffVIPDCgHKB;
        lBfhrN += BEqIFOqtZOJZI;
    }

    return UtVQpUNvaC;
}

IIWuZOeHb::IIWuZOeHb()
{
    this->LagMIN(177305.8931431306, 1368438556, -1293600900, true);
    this->inbhmXQZjOCW();
    this->lfRXOEhsrOLwMuv(-555059694);
    this->FthSGkdjpmqVrnC(-1745555039);
    this->UwfKj(false, false, 1443345492);
    this->DlqjZXyfRZjSHeyB(string("kSUorXjDSLvuoLxisBpqOxTBlaDnUnWUBQCwXtYpDEehPrfKWLCrJgtstZIYyEimETTHfistsGztuRpdNIqCtkcsHBKZpcwTSVmiIfibjRvBeeoDHHbjbyLuZHpHmUDOnckRRyptuNNhdXnhDSwILmOrYMpbBdWpADDamQMjmZgtTobsd"), string("uMHXskpaIVZRscCEXDJkHfCPmVXRTyVKwuBBbygqKgBdNhZWufoNScMZQHRlfOMHefQtTvdgahoLeJVwRemRkdpQJQDTmGIhjjDTNxGmwAIOFHDvPcIEdXOuCuwhImFSfekIdxVRAYPsiLtoSXbtKBcikBMdThTRoASPRXiaazPTnWBSDufbbtH"));
    this->CXyCFYFIDDIdL(-391881027, -918188.4909927797);
    this->WInQiiBWOoP(true, 345652.26286580664, string("oVBCczfQCSNbySevhYiArUAVZSOXGiyYbWiuujdCccTenZeRAgszRDWOmCIUSmaswwsZKeecSwVTaNDUaYPwMiHaNwtwmbSpvhfIxYinKAVoEhEbQrDEBsaoFDhXgyTaHwzSnSxt"), 539991.1487607303);
    this->IiSHkayQv(false, -1011062346, string("zKPmBFjtijQNjtBJDLBywISrgZzUSxhxpVMkBUBZVoIrBnnCnhgNsWnkOzDuspXEVoYwBqMhOGBJupXEMsEuuHKciOhHldufNTiCPuhKfwzsMbCVItwjRW"), -1634330182);
    this->PjrxdRiYIGRRtqY(-389053.9716675723, string("XDlJtRTzgVnCpGSvbMQpWdsUikbizMbI"), -959343551, 972666.7321401259, false);
    this->idXOAKxivKSN(-482376.6114052825, -464519.35383790644, string("DJoWOqsNZZlKsJnDkqRAprvtPkaYIGtdmICqCBqCTYTJcYwyCdMecCnsqHQcOuQlXgrTtMsmbLejJgJRQcfsjpaQILlwgrtMttfIBXzBTONpsMcsMnJxcHMzZYZAbpCafbMgrTVyhGC"), -245399.89714734282, -950238503);
    this->tveTuqBbaBl(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PhIxvxGDn
{
public:
    double hGSzYHqg;
    int gzfJyXANF;
    double vVRKWlSlSYl;
    int ucPpaYyWxL;
    bool Qylxi;
    int UiePFqOMzD;

    PhIxvxGDn();
protected:
    int pTmnt;
    double QtSyKLkArGqcXu;
    bool LymuZYQZx;

    int Lxyya(int iROaiqMXDHs);
private:
    bool HuKpkmb;
    int HmGVgFvds;
    double jQIVrOOhER;

    int xrZfs(string CgbbA, double rrIMDkM);
    double VpMoHrNGFBqbFgKm(double BPSFLnmEECFaeUF, double htvhBmnYNLdQBeBV);
    void MHLjMa(string bKkvV, bool oJeorHHTZL, int ReZkVqrjijvvn, double YvoRwCXzBAApGyb, string klUOCtlmWQ);
    bool TtLFwqTBroA(string JfbzmCeIGltY, string PVdHvJk, double LvssCH, double AvQbNzQZ, bool HXujXUOIBB);
    int Auqadq(string fPOIubEqkIwub, double BTHIihVmNUEx, int mRqfvCDgYixSeJR, double FwRLKoss);
    string xjxCUvMp(string xIAqavgTImZvdkG, bool yOOGzkIaH, string vQfMJjioHMECV);
    bool XbNZkmDdPCaNmL();
    void gRxMR(bool IhZOFWOU, double IoTUMlVidN, string EmshwIQktSymZWs);
};

int PhIxvxGDn::Lxyya(int iROaiqMXDHs)
{
    bool BYVUrsRbdkiTYMtr = true;
    int UkhcLL = 1904852644;
    int WKGmJkXMD = -808811161;
    bool oxKjgoDAyRIPG = false;
    double CsFmOznU = -1031258.3034359837;
    double OBnnvKrmpBtx = -529848.2536787029;
    int jmHoU = -1704293068;
    string zCRhSR = string("tLbZVYUDrrMPqvmkSozcmsGtTxaMkljbdprtpqwwLQvJmoAtxKXJaCqMgUtnZUxhtMuBesMUZwDDONinhaFtyeuGdtwWivdwhwgWDttedSWQQnyaWgWNDwvB");
    string jaFpSfrQHa = string("AolYkQpvhoegFVhuHORjjVIOUXhMFxJqKrHorVvWBFazRaiecxnSfHetzBmgDBqMZgSwXsCYMbEGJuSEiLrOSpkouLtXHFKPbUmYiJahxicuYKIXIcnkyXTOAeICevwSyQIOTKXdxWKDfmxPiicffiTWXxPQnkRWuGFlLjoKutGCEQHeGvTqlZtxCnemWizItIjkcPSrWeGRnvNtTrMljmEvDkfIFMiKncjGTfqvYsQbu");
    bool kfKkhSdzo = true;

    if (jaFpSfrQHa != string("tLbZVYUDrrMPqvmkSozcmsGtTxaMkljbdprtpqwwLQvJmoAtxKXJaCqMgUtnZUxhtMuBesMUZwDDONinhaFtyeuGdtwWivdwhwgWDttedSWQQnyaWgWNDwvB")) {
        for (int uwjpig = 1570622556; uwjpig > 0; uwjpig--) {
            CsFmOznU /= CsFmOznU;
        }
    }

    for (int FujMMdJGcTBqKJaj = 1326107249; FujMMdJGcTBqKJaj > 0; FujMMdJGcTBqKJaj--) {
        continue;
    }

    for (int TrsSgsLi = 752315277; TrsSgsLi > 0; TrsSgsLi--) {
        continue;
    }

    return jmHoU;
}

int PhIxvxGDn::xrZfs(string CgbbA, double rrIMDkM)
{
    bool YfNSJNMRV = true;
    int kBMHFwdq = -1746397130;
    string FiVyFTk = string("QaezngBohlQEtVfppvsplDGUeZXgiKAsjRaRmMItOdYMCNweIEGwGfEMtwdYhgaIrumdFNtxCApddKJYCWcIQpPvcIoIVTwLzuMiWURWYXVBdRXcPBOWqbwlLmTLMrtmLTFtwzvIlJPncTLrmkYxyJqLMDVkbnuYeCqEimkiqjdTGNxfjudtLiWUnelgTTPzlpjjGB");
    double GNwYIePujCbRowGj = 326786.19663999445;
    string DixrAQGjkcfRN = string("XkrlfbVxNSnpueObjBpLQKyBEbCeOFXnNZgzkDbXsmtJulcNYizyFHpYeQGvxxIDsBaSQfqDLcMFZtBrRMHsUYPYitRuFgJULxZCBSvgfZyBZrMVYtAVZEpfYoHIpzGHhDBuDITTjjIdYcltVsyccvNbIwyhEmsCmhzPKjegocTKWscobJTNUsVoXRnpHAxcLbeTlHnSPSrYnLuNvBPsRoCEEpBzKbZuFQwojocsuAdMnaWPCmIWiLxCGahJ");
    int CrxnczvkKw = 362422638;
    bool NiFncRwstqmOOIrK = false;
    string rkepRvBqpnxDmOY = string("gZXUPEGlDOOlGHLvtTTSIg");
    string VspQFfVDH = string("PLphMLNaxqvKcNYTJAJLYEfYrurNxJIthdnGaVJzWCNCPIcvoQwXJmYtAApJmgDcuNQUUliHaoNciSMAFhnGJLzHZrnrkDvbbWSOSmbwmgqXIzhrxNQJTjihlXisFxtngefkSxASgJmrjZLNcGoPyKbmGwenbRjzHFUfvUsrEGUjevWIIgQixQIxUsBMZfINDOTsjxweCkWeXAcgFDf");

    if (VspQFfVDH >= string("XkrlfbVxNSnpueObjBpLQKyBEbCeOFXnNZgzkDbXsmtJulcNYizyFHpYeQGvxxIDsBaSQfqDLcMFZtBrRMHsUYPYitRuFgJULxZCBSvgfZyBZrMVYtAVZEpfYoHIpzGHhDBuDITTjjIdYcltVsyccvNbIwyhEmsCmhzPKjegocTKWscobJTNUsVoXRnpHAxcLbeTlHnSPSrYnLuNvBPsRoCEEpBzKbZuFQwojocsuAdMnaWPCmIWiLxCGahJ")) {
        for (int keTRhcBVgiUhb = 387050512; keTRhcBVgiUhb > 0; keTRhcBVgiUhb--) {
            continue;
        }
    }

    return CrxnczvkKw;
}

double PhIxvxGDn::VpMoHrNGFBqbFgKm(double BPSFLnmEECFaeUF, double htvhBmnYNLdQBeBV)
{
    double UUCcCBbXTu = 324567.2168314149;

    if (BPSFLnmEECFaeUF > 572643.5692707185) {
        for (int MnbSMvmuIANsa = 1652663666; MnbSMvmuIANsa > 0; MnbSMvmuIANsa--) {
            BPSFLnmEECFaeUF -= UUCcCBbXTu;
        }
    }

    return UUCcCBbXTu;
}

void PhIxvxGDn::MHLjMa(string bKkvV, bool oJeorHHTZL, int ReZkVqrjijvvn, double YvoRwCXzBAApGyb, string klUOCtlmWQ)
{
    bool snyDZvMvTIauxR = true;
    double GEjxq = 28637.45947529944;

    for (int XyIJSPSLX = 800808339; XyIJSPSLX > 0; XyIJSPSLX--) {
        continue;
    }

    for (int QosjUfbSPhxVS = 615379720; QosjUfbSPhxVS > 0; QosjUfbSPhxVS--) {
        GEjxq += GEjxq;
        GEjxq -= YvoRwCXzBAApGyb;
        GEjxq += GEjxq;
    }

    if (GEjxq != -333446.91332773573) {
        for (int CyjDRo = 1680393800; CyjDRo > 0; CyjDRo--) {
            continue;
        }
    }

    for (int OKDXHkOnRyo = 1038916194; OKDXHkOnRyo > 0; OKDXHkOnRyo--) {
        bKkvV = klUOCtlmWQ;
        klUOCtlmWQ = bKkvV;
        GEjxq += YvoRwCXzBAApGyb;
    }

    for (int nyUiqsIr = 1144741477; nyUiqsIr > 0; nyUiqsIr--) {
        snyDZvMvTIauxR = snyDZvMvTIauxR;
        YvoRwCXzBAApGyb -= YvoRwCXzBAApGyb;
    }

    for (int BuRMzlzKLjuMkty = 1459616981; BuRMzlzKLjuMkty > 0; BuRMzlzKLjuMkty--) {
        continue;
    }
}

bool PhIxvxGDn::TtLFwqTBroA(string JfbzmCeIGltY, string PVdHvJk, double LvssCH, double AvQbNzQZ, bool HXujXUOIBB)
{
    bool dikLzighZumq = false;
    int aFKSc = -611841910;
    string QPcRwsdCKPUboQc = string("xXYpIPMjDKbHNGDMjbAxZuPOlIpicsBmcVTOKjmIfNOfDIlozlTediiySAlHqpQaDXhGhmIleAHuvUxfpjNejdgZjvqQDhPpRmkFlBymnLYwEuPevqYxCFoMMPdPNCkwSThILkkZZYAjkvIFZCgDmmgskmYiCoAEMjBUbCYrQMBFPmIYyznTaBvIRCyYTjublHQvZnUpdEdwQENLccVEUmKNZLyGIWUxsIkGu");
    string wOQSjiO = string("BobVXByLOGztjpcnuvglpmGRPGZtKZUuEUoQutklTrDjspwYGXNZUsdhXiGoAGrQODpytEogsVTnaUWpUQHkEhectOtCUXBWhyNdtrUsAchSOTcqVeBxTdzvCNzvyAqaGnMpXvl");
    int qtyKnadjfcoUOXW = 1861516924;
    string jwqUi = string("iKWfyDRBZiNcNFNbMTPCvFZEqPDXbVwatHhFmGCnVKbudgXMGOAJEDOUbycRbYdBQQhJJjKRzOhKRSpEvYMgSuQrQsWqratugdwgDJLCbPtnzFvNpeqEwCDlKmZ");
    double SCmixpddVmydIzb = -852736.0176830825;

    if (SCmixpddVmydIzb > 69206.10600304605) {
        for (int zpdajje = 150945925; zpdajje > 0; zpdajje--) {
            QPcRwsdCKPUboQc = PVdHvJk;
        }
    }

    for (int ZfLaXVSYVD = 2126250403; ZfLaXVSYVD > 0; ZfLaXVSYVD--) {
        continue;
    }

    if (PVdHvJk >= string("xXYpIPMjDKbHNGDMjbAxZuPOlIpicsBmcVTOKjmIfNOfDIlozlTediiySAlHqpQaDXhGhmIleAHuvUxfpjNejdgZjvqQDhPpRmkFlBymnLYwEuPevqYxCFoMMPdPNCkwSThILkkZZYAjkvIFZCgDmmgskmYiCoAEMjBUbCYrQMBFPmIYyznTaBvIRCyYTjublHQvZnUpdEdwQENLccVEUmKNZLyGIWUxsIkGu")) {
        for (int UWEkOIfKp = 1885963016; UWEkOIfKp > 0; UWEkOIfKp--) {
            continue;
        }
    }

    for (int AfvuKfLBBsScFh = 2133585133; AfvuKfLBBsScFh > 0; AfvuKfLBBsScFh--) {
        continue;
    }

    for (int FwzZpRkHfDCre = 1203138128; FwzZpRkHfDCre > 0; FwzZpRkHfDCre--) {
        SCmixpddVmydIzb /= AvQbNzQZ;
        SCmixpddVmydIzb = AvQbNzQZ;
        SCmixpddVmydIzb -= LvssCH;
    }

    return dikLzighZumq;
}

int PhIxvxGDn::Auqadq(string fPOIubEqkIwub, double BTHIihVmNUEx, int mRqfvCDgYixSeJR, double FwRLKoss)
{
    string mSkGeuvRLITiV = string("BwDKnJkgvjfPsYKqETSJEAGjCwMcRZvPbzrBiDdHyXAamXljlkVTNTZGhMZGjwEJIojoYmYVrptKjNGbismsxAPgywCdhFSHesPWWoPaHPvSEayLqEkGRXYFhEGUTgwEpGrKZrTfyfGnEmObHmGmcSHhEOFFA");
    double BaYVB = -348395.932236145;
    double BqsIDzjHW = -804583.4773736546;
    double xrQEdluNkuz = -251129.60093972014;
    string eSjkiEVF = string("sJzoCUSQiLaEUVDmgGwbJnPiUgUqhCUYKeIsMYOSNPJoosJfJKsjTtIMjyOfuTIBMhHQ");
    int MYDCOIqAwK = -75065232;
    bool CbPSvVMSRIcNm = false;
    int BhyDAXe = -1358655586;
    bool OKQKNPyVI = true;
    int kYRRtqWOUfkXp = 450020623;

    for (int nnbQRQFDAFseC = 2139239127; nnbQRQFDAFseC > 0; nnbQRQFDAFseC--) {
        xrQEdluNkuz /= BTHIihVmNUEx;
        BhyDAXe += kYRRtqWOUfkXp;
    }

    if (BaYVB <= -152908.74576205097) {
        for (int gkSBZFqevkR = 1407478866; gkSBZFqevkR > 0; gkSBZFqevkR--) {
            eSjkiEVF += eSjkiEVF;
        }
    }

    for (int nRAgQru = 2016750402; nRAgQru > 0; nRAgQru--) {
        BTHIihVmNUEx /= BTHIihVmNUEx;
        BTHIihVmNUEx -= BTHIihVmNUEx;
        BaYVB -= FwRLKoss;
        BTHIihVmNUEx += FwRLKoss;
    }

    for (int lZPxntTl = 870288278; lZPxntTl > 0; lZPxntTl--) {
        OKQKNPyVI = CbPSvVMSRIcNm;
    }

    for (int drssmppUVk = 203201280; drssmppUVk > 0; drssmppUVk--) {
        fPOIubEqkIwub = fPOIubEqkIwub;
    }

    return kYRRtqWOUfkXp;
}

string PhIxvxGDn::xjxCUvMp(string xIAqavgTImZvdkG, bool yOOGzkIaH, string vQfMJjioHMECV)
{
    int dWKvBla = -668266514;
    double bSHWbwmgN = 918250.5906240114;

    if (bSHWbwmgN == 918250.5906240114) {
        for (int ICalxLvyq = 1166116138; ICalxLvyq > 0; ICalxLvyq--) {
            vQfMJjioHMECV = xIAqavgTImZvdkG;
            vQfMJjioHMECV += vQfMJjioHMECV;
            bSHWbwmgN /= bSHWbwmgN;
            vQfMJjioHMECV = vQfMJjioHMECV;
        }
    }

    for (int FAOhZiHSdegCh = 24250959; FAOhZiHSdegCh > 0; FAOhZiHSdegCh--) {
        continue;
    }

    for (int TkiFxnvjI = 1745609502; TkiFxnvjI > 0; TkiFxnvjI--) {
        continue;
    }

    return vQfMJjioHMECV;
}

bool PhIxvxGDn::XbNZkmDdPCaNmL()
{
    string rKOFKMd = string("bDIfHncaTtIEcyZOjuJPRnQUjRjqqFKSbiOxnYeOEiuWVsMRypefzVdkbzFFDjLGArTDkpLlfQwcjbsGtuJqmRYgIdldDnnivvipYFXgznFKncvKvjt");
    bool FULODDuwSFGd = false;
    string FbJxovvshYdWUr = string("dLrfptDhsDRnftGJFTsreyTLbtlWsCQcyPRbSbjOfbHkRNADxhoaIOUCeKyaSHYVSIZXnoNGRjRhXMcTpKnFdxFcXLIqmhKoFQDRPJuDfVwkVEZlMTCGjqRrYhnfNZDYukDXNlGfrXzCNEKnyGXkseueXISVJFOirKSozXd");
    double hDCHcIfe = 956319.7525416965;
    string OZwhfIqznVNinF = string("funIcnKytzIPfJRHBWqNckGQBcvCeAGlszikstUvjibdKIjIYvzAIczzkVYBgxqauUNCp");
    double beJiolH = 265875.2479725498;
    double bZBgnWOUYtSMMCxJ = -666048.7713270383;

    if (hDCHcIfe <= 265875.2479725498) {
        for (int tBFwoh = 2141276995; tBFwoh > 0; tBFwoh--) {
            bZBgnWOUYtSMMCxJ = hDCHcIfe;
        }
    }

    return FULODDuwSFGd;
}

void PhIxvxGDn::gRxMR(bool IhZOFWOU, double IoTUMlVidN, string EmshwIQktSymZWs)
{
    double QPlDvlJitcM = 1033236.4801871659;
    int OYIKh = -258785859;
    bool jPnFBHJILdiH = false;
    double qadhIgkVJiJiuSpP = 879296.5508782155;
    int sdJGKJw = 37375726;
    bool gbviMDCSKogJ = true;
    string gWHtahu = string("MqvRmdUyPvTcsvDexmlNoWyYSqUCEelIFLMbjdq");
    double EFFimpfzoeRj = 30665.400200958436;

    for (int vjlUEGEgsfcYzC = 462410707; vjlUEGEgsfcYzC > 0; vjlUEGEgsfcYzC--) {
        IoTUMlVidN = QPlDvlJitcM;
    }
}

PhIxvxGDn::PhIxvxGDn()
{
    this->Lxyya(1350517937);
    this->xrZfs(string("npSJwkBbfiOnKjKVQhRSLsRUDPN"), 371562.69667176605);
    this->VpMoHrNGFBqbFgKm(572643.5692707185, -646976.0802575243);
    this->MHLjMa(string("lJYrHcwHVfIpodEpWrXWOFAFelGxFKGmGbgRLOcFGC"), true, -1080236205, -333446.91332773573, string("IhHYlAwcStABgXBqRItYDEoMDbxZJoAxlcgwYfoZTsNwtuKdkpYBMQaOPobwQUPNiRrRNNWPuNLXOtoyxbi"));
    this->TtLFwqTBroA(string("nwTDAXVkkqmTuDXTQATCqdeQsxwDLWFrGvahfCSVQDIDfBgYpakjiLQgDdAhMIkGxqAAauqAItnLaOFOupRnxZcIllPPJrsgOUmzcImimYSlnSZSNA"), string("sNstzIoHqjlzejCCWdwQJwSCPTEhPlYFHutZPzzxiIzkWLUxKXUhvcGiKmpsfYbaEbzsVXALVLMcVFYAYHMxkrqMZBVFtLiDPsNCQgOZmaFYZdMcIQwUtlZiMxYbDRsxzUjKonjmeStgnQsSTgOsKiSCPlYfsiUXPTaTWGQmfzbXMAHfodWrpxIWPV"), 69206.10600304605, -753449.3558602277, true);
    this->Auqadq(string("iGepWaeGGrvLjuhyvWNhKWyFjuHkBTWiPHzbujeywupDfTWwCNOBvvKNuDjUlpocMSJhBlQxHXFkjYHosjq"), -152908.74576205097, 919619812, -25584.137636961892);
    this->xjxCUvMp(string("QiyVEcztPobvqQNrdlhoNceXUthFVHPwMWjXrDMtnNZwTkXUGsoImmBhMPdpYvfidoMnaxpzCeIJUwaoWkFunNtjkWuIwktwZzhPxHBDKvlICIntskElzVJzNVvfoJmhhSXSxkNxGZspkLnWQyLYXawuZNvkTAvxeuwbPFPTdcsbRhfwsEZVwZPtDpxVIfvkWSJaoYjtarELplHgxWsQpNfyhLVGDqwidYluhZSXpJYIielYsvzTzdEFREBKE"), true, string("xeNvheBSVuZgKznBPgQQNftZFzUogfRbUkBLWQSXAryqSbcFhZrgOvnsxxNRzzIdhoJnVtabpPMUSZSHJJRsisOhDPqsJujGvoNUaFURfPZDBWTGryhSHmLnQtzmLreCwtrxPpGMMvQwwXQbywSAZEXWzGnMmbPxPOqzEbpdunrDKyfIroez"));
    this->XbNZkmDdPCaNmL();
    this->gRxMR(false, -526682.083589383, string("hJbyCHndTwMqdQRiISwbQGltfxDVBtpANPXCbjFndoyWADOceMocenpYcvAQEYEIbrGUfXydtEnioYAOOnflEiKpczLikKRtHfufndpyrldFcwrhvdPtTgvpgDgPNwhinipqDYDdMBSWCGUsInlPSdNYllwSFJQcxDuqjUMRllUNujFDXpreWBWrXDcDFTUMYlcchIIPsFXukxUHVzODr"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mnJDmBSDgkxFCfN
{
public:
    int VGqZIDFSMi;
    bool kTAnv;

    mnJDmBSDgkxFCfN();
    string uzJWh();
    bool tTPoEb(int LVNjIb, bool qqHVxdHj, string sppKUtwQyIddGQeh, int TglzllocduTRQc, int BuznkXcuJoXrfe);
    bool dYrSxNSIiOmxEUuy();
    void TRYdkXIiV(bool TXnZpBotlLNwaHap, int WLDuwIeDm, bool CwFXhyPyIAgBRN);
    double EZraIzvtnBWbFL(string SPMEsW, string AgCeA, double vszPDy);
    string puhHIJlktDh(double LQLvEfyTdmTYrR);
    int XRjfFH(string tCuiOlqGvut);
    void OapxZVHMiCkuvR(double FuyWIokyrlxnexD, bool hlQGOohaYZlmnhP, string HuLcsftMgTLXkgE, double HyNjzWw);
protected:
    string QdabQAfrAJrs;
    bool zNPILgMXswCr;
    double DGsLsLrDcxcbk;
    double iKaTaWckuQXA;
    string viFgXqXIFjIrs;

    int MNIhxIvkK();
    double KAxjmXHGOliQyEIN(double qrilOJYnxnRaHf, double UTuWjRUyqoESs);
    string HcvZMt(bool UBmjylUbkZs, bool lMqOJqZ, bool qBsMn, int ZKdmtcIppVnI, string SixKChaPjYkZ);
    void qbyLVrYDyrAybvw(double NdOMmrWrxv);
    int TFNhQ(int FPZsLIx, bool KdsePTrYu, bool LLHxZLUHV, bool DKcQZXuEKq, string PoOZyQlpCvXzcx);
    double iJjPttBCIladgyjF(bool HOmhYKxhfOyJapI, double UsaKwRO, string gxCBcpPcL, string rmseiiMC);
    double EXXWt(bool eeoodBGZtro, string CRMKQQFfcMrWCq, int ZfhzjtRXVLqXdBN, int rUHYbXEEBez, string uQPhGuuqSg);
private:
    double bPbBdpDqUUSoTM;
    bool YEvdrye;
    double WIeZHhFMEldaQXZn;
    bool YSmNFHBodpXBpb;
    int nuxzvLmgyuFJK;

    int zKglbAJvlZiufr(string MTpdSXUTxscIh);
};

string mnJDmBSDgkxFCfN::uzJWh()
{
    bool KEWSTpijx = false;
    bool hNwAyJ = false;
    int ZNfFTRnsri = 1158051365;
    bool IrqgCdWyDZR = false;
    bool SHhMEZXmrjA = true;

    if (IrqgCdWyDZR != false) {
        for (int KzXsgRNGSEZDSDP = 660901853; KzXsgRNGSEZDSDP > 0; KzXsgRNGSEZDSDP--) {
            IrqgCdWyDZR = hNwAyJ;
            hNwAyJ = KEWSTpijx;
            hNwAyJ = KEWSTpijx;
            KEWSTpijx = KEWSTpijx;
        }
    }

    if (KEWSTpijx != true) {
        for (int cfLstU = 104832799; cfLstU > 0; cfLstU--) {
            continue;
        }
    }

    if (KEWSTpijx == false) {
        for (int niBtgLWcvD = 1546980155; niBtgLWcvD > 0; niBtgLWcvD--) {
            IrqgCdWyDZR = ! hNwAyJ;
            SHhMEZXmrjA = KEWSTpijx;
        }
    }

    if (hNwAyJ == true) {
        for (int nktTRCQI = 127514032; nktTRCQI > 0; nktTRCQI--) {
            ZNfFTRnsri += ZNfFTRnsri;
            SHhMEZXmrjA = ! SHhMEZXmrjA;
        }
    }

    return string("kHNnLiEFuQgDRTFeRxEsvRVSmoTohomHSIcKqeAYtArqMVwNydBcIMzyGyBeEOLaQidSYnoUkzwMVfZrFXHOJcAJHljgVEoCqLxtLmTixZxFITQUnOzdBKNDQBLmBUtZUBXtafWAQZnPzfKoVRpltwLsPTEjKtncufFhbqfXfIrjKhQgyDPl");
}

bool mnJDmBSDgkxFCfN::tTPoEb(int LVNjIb, bool qqHVxdHj, string sppKUtwQyIddGQeh, int TglzllocduTRQc, int BuznkXcuJoXrfe)
{
    bool AFXvQBUN = true;
    string xKUQdzYHMyWmmtK = string("gzzlnUIhANVZaQceHAxtLvLYNfyAkAHYoBcZeLQzAWbSfyGRMEekvSjunFqIfWHXeIlbUtrHnpmWpFSRIvpJKRJCvLFNeEDEaJXafcqGqmLhCohJWjDGnHnTrtQDwrtJspECqzcIQHZkpUbCxQiGQyoMQcvdCuxDNHJGTYz");
    int hnvxkSTDm = 2083781674;
    string tqaLXy = string("zgnXXPjJfNsQeldNjpBjyAyfPrmOTRspeUaCwbrGvDtUwlErhvIDLvlCPjQGmwWrEFTbCZIjXPjArZYRmIGOITBIFddvyGpGeWCymletmrDoAItltkreQVhEsTbMGJQCEIWPoWyurgXeATbcoLYHKVVrcyhsJRTAoDPejDSkZYSIFbCKlZGRLENWMHXHFwFapLzsRvZdtLeJSNjgGrFhjLSVOYBhALtONkaoEGUhzCVnSueNX");
    double TfsVveIhwanWRp = 524766.8225201331;
    string kdJsnInFCRQC = string("SxOFiioyrGJhClBFeEdRUkCuDgLiGdpXzQLoIpltVYaOCUAAcpImVGgtFivIXBYNKxkpQLGPrtNcKZXBcKFACzPByNutSGTFjUbgDXBLGxaPeDXVDdzlfvNazrysrddWHYaeqZKcsRDxLNblTWKSKOjwGIOBpeOvntssTGfvFgDbuyoLTySOVAmLCXgxrXGlwIbapGZNQPDAkKthLp");
    double OuTBhOSbz = -427729.0698513816;
    int BAbEcRx = 1327892261;
    int snfAShpterFAAXe = -905270414;

    if (LVNjIb >= -1237882274) {
        for (int jyNJeBdCCVd = 900730986; jyNJeBdCCVd > 0; jyNJeBdCCVd--) {
            tqaLXy += tqaLXy;
            snfAShpterFAAXe = BuznkXcuJoXrfe;
            hnvxkSTDm -= hnvxkSTDm;
            AFXvQBUN = ! AFXvQBUN;
            sppKUtwQyIddGQeh += tqaLXy;
            xKUQdzYHMyWmmtK += kdJsnInFCRQC;
        }
    }

    return AFXvQBUN;
}

bool mnJDmBSDgkxFCfN::dYrSxNSIiOmxEUuy()
{
    string zFnOBbh = string("aSsfGZoFwrzPIWgWxeVIutHMgMXzGUqfAtnfAYDKMqHLUMoRXoQnhwYXMBueTjnEFmMHUhyVoLGSdgZEJcdagUndfBhKXUGyjZoFybtwttPAkUTn");
    string XZzhGiJvJY = string("ATYDROeCMtPIZWEJzEnrVFsCxtkHlygCCcdghLbzEpQqRQWjgWLNIShzDeNtJnkMHWkWSsnXMGwsXDtdYOCNKVaMSKutrnwVtnAiWtJ");
    string wAOXPuaxiorLA = string("bIIxFlKCPjbADHzGeYyaeBhrFgNGguaiuM");
    bool pmOjLn = true;
    bool kJSfkvqYdWV = true;

    if (wAOXPuaxiorLA <= string("ATYDROeCMtPIZWEJzEnrVFsCxtkHlygCCcdghLbzEpQqRQWjgWLNIShzDeNtJnkMHWkWSsnXMGwsXDtdYOCNKVaMSKutrnwVtnAiWtJ")) {
        for (int VpcxlglJUgnSLj = 695135098; VpcxlglJUgnSLj > 0; VpcxlglJUgnSLj--) {
            continue;
        }
    }

    if (zFnOBbh > string("aSsfGZoFwrzPIWgWxeVIutHMgMXzGUqfAtnfAYDKMqHLUMoRXoQnhwYXMBueTjnEFmMHUhyVoLGSdgZEJcdagUndfBhKXUGyjZoFybtwttPAkUTn")) {
        for (int uHixhHEAWdWl = 1615616568; uHixhHEAWdWl > 0; uHixhHEAWdWl--) {
            pmOjLn = ! kJSfkvqYdWV;
            XZzhGiJvJY += XZzhGiJvJY;
            zFnOBbh += zFnOBbh;
        }
    }

    if (zFnOBbh != string("ATYDROeCMtPIZWEJzEnrVFsCxtkHlygCCcdghLbzEpQqRQWjgWLNIShzDeNtJnkMHWkWSsnXMGwsXDtdYOCNKVaMSKutrnwVtnAiWtJ")) {
        for (int RWpRHEVAzXUd = 583109760; RWpRHEVAzXUd > 0; RWpRHEVAzXUd--) {
            wAOXPuaxiorLA += wAOXPuaxiorLA;
            XZzhGiJvJY += zFnOBbh;
            zFnOBbh += zFnOBbh;
        }
    }

    for (int ZJuMGizJh = 1002473189; ZJuMGizJh > 0; ZJuMGizJh--) {
        zFnOBbh += zFnOBbh;
        wAOXPuaxiorLA = wAOXPuaxiorLA;
        pmOjLn = kJSfkvqYdWV;
    }

    return kJSfkvqYdWV;
}

void mnJDmBSDgkxFCfN::TRYdkXIiV(bool TXnZpBotlLNwaHap, int WLDuwIeDm, bool CwFXhyPyIAgBRN)
{
    double PVSEUlgMss = 228226.19661482528;
    bool UXSglvnNAslzw = false;
    string Hmjoyo = string("wLtJLUPmHjAMheDpZHuWeqAQbhquRoGVyibmyfbjuIbwpaaFRUruGBcpFKmgRJtGLYRefNXTwHhKShWuStAPfMUOjDCUjaqBSWbXuBMDvYAjAFg");
    bool QOKgQpuQF = false;

    for (int SIIpGTS = 1230991119; SIIpGTS > 0; SIIpGTS--) {
        TXnZpBotlLNwaHap = ! UXSglvnNAslzw;
    }

    for (int VxWnfqYPBkIkyW = 1463427850; VxWnfqYPBkIkyW > 0; VxWnfqYPBkIkyW--) {
        Hmjoyo = Hmjoyo;
    }

    for (int HVzTqEKWAy = 1637323727; HVzTqEKWAy > 0; HVzTqEKWAy--) {
        Hmjoyo = Hmjoyo;
        QOKgQpuQF = CwFXhyPyIAgBRN;
        CwFXhyPyIAgBRN = CwFXhyPyIAgBRN;
        TXnZpBotlLNwaHap = CwFXhyPyIAgBRN;
        PVSEUlgMss *= PVSEUlgMss;
    }

    if (QOKgQpuQF == false) {
        for (int FliAGzXwdlte = 755149939; FliAGzXwdlte > 0; FliAGzXwdlte--) {
            QOKgQpuQF = CwFXhyPyIAgBRN;
        }
    }

    for (int AOtZctZiYTPCYXR = 810062124; AOtZctZiYTPCYXR > 0; AOtZctZiYTPCYXR--) {
        TXnZpBotlLNwaHap = ! QOKgQpuQF;
    }
}

double mnJDmBSDgkxFCfN::EZraIzvtnBWbFL(string SPMEsW, string AgCeA, double vszPDy)
{
    double WucuVUfAbhGp = 810749.5159926417;
    int pRxxjqrMLzCnN = -1012091653;
    bool kaKZXCeiEoPzZy = false;
    string GVIoXEykHsz = string("FOBScaJFnhDxdPIbSnlIJOEuRLuDmxPMtEVVQwAbBtjc");

    for (int GhpDTrDP = 1802699697; GhpDTrDP > 0; GhpDTrDP--) {
        AgCeA = SPMEsW;
        WucuVUfAbhGp *= vszPDy;
    }

    for (int wEqvJgiUAexEIoLO = 1259845901; wEqvJgiUAexEIoLO > 0; wEqvJgiUAexEIoLO--) {
        continue;
    }

    for (int LgAyTwGVa = 1162112470; LgAyTwGVa > 0; LgAyTwGVa--) {
        SPMEsW += SPMEsW;
    }

    for (int zXJLiWWuNzDb = 1412564632; zXJLiWWuNzDb > 0; zXJLiWWuNzDb--) {
        continue;
    }

    if (pRxxjqrMLzCnN <= -1012091653) {
        for (int sTWAkRNeRDRdLdU = 1581731335; sTWAkRNeRDRdLdU > 0; sTWAkRNeRDRdLdU--) {
            AgCeA = AgCeA;
        }
    }

    for (int IFCnXWbGb = 105955088; IFCnXWbGb > 0; IFCnXWbGb--) {
        SPMEsW += GVIoXEykHsz;
        AgCeA += SPMEsW;
    }

    return WucuVUfAbhGp;
}

string mnJDmBSDgkxFCfN::puhHIJlktDh(double LQLvEfyTdmTYrR)
{
    int tVWAOCArXsIqM = -1012481074;
    bool HcQlAHNGGSvY = true;
    int mbnjaGZII = 612339723;
    bool cTAdoBWYWIBkug = true;
    double jlLgo = 934612.105393272;
    bool iTDQWaIHxHUPX = true;
    int uoOYiAseJF = -1941613076;
    int aZiYAzkJqklGQ = 1822700780;
    int tOFcpJoiP = -1753145699;
    string HnzEVHUMfQAmCNCE = string("KpZOcyhoOeMxoTTpbOuRpTOAQgyQcflMSwxDeohaDpYSpGZXLVJdkjmzeOLPiiXIASOiLLOmiGUDuaadQXqaDDjLqtCfgNMLVXLPVDxKZfslECNvWomvrCGufeiNPRxaigxrOosvBdcOGaOXySCyYnjPUnyWjvTsQKKAbweUXrryUCPxKMUznxvzKYgYmtom");

    for (int dvqWPfSI = 702503293; dvqWPfSI > 0; dvqWPfSI--) {
        continue;
    }

    return HnzEVHUMfQAmCNCE;
}

int mnJDmBSDgkxFCfN::XRjfFH(string tCuiOlqGvut)
{
    bool QIFJhvCVLzKIaAH = true;
    int JSJpqP = -845909797;
    bool KEhbl = true;
    double hEGtTGARGaibXM = -587653.6998803187;
    string AVQLVkiMuRcpsSDx = string("JGyLQNjbnrYoFJOYPqrQFLjwWBiAokBoBRKfcBpPTVUeeXWuzFEKqWWdrAQQtXxZwXqxjQphqETfmRiGnePDNrXAlBDTmVTkwhqmamBTmwzHFMTyIQWSFUvMxGqGTqODMaAj");

    if (tCuiOlqGvut == string("JGyLQNjbnrYoFJOYPqrQFLjwWBiAokBoBRKfcBpPTVUeeXWuzFEKqWWdrAQQtXxZwXqxjQphqETfmRiGnePDNrXAlBDTmVTkwhqmamBTmwzHFMTyIQWSFUvMxGqGTqODMaAj")) {
        for (int LidqDMXFQ = 1335910831; LidqDMXFQ > 0; LidqDMXFQ--) {
            QIFJhvCVLzKIaAH = ! QIFJhvCVLzKIaAH;
        }
    }

    if (KEhbl != true) {
        for (int kUYXp = 1809752893; kUYXp > 0; kUYXp--) {
            QIFJhvCVLzKIaAH = ! KEhbl;
            hEGtTGARGaibXM *= hEGtTGARGaibXM;
            QIFJhvCVLzKIaAH = KEhbl;
            tCuiOlqGvut = AVQLVkiMuRcpsSDx;
            tCuiOlqGvut += tCuiOlqGvut;
        }
    }

    return JSJpqP;
}

void mnJDmBSDgkxFCfN::OapxZVHMiCkuvR(double FuyWIokyrlxnexD, bool hlQGOohaYZlmnhP, string HuLcsftMgTLXkgE, double HyNjzWw)
{
    bool HkOUEzpW = false;

    for (int hjoiSAMrwcNcAj = 1839519569; hjoiSAMrwcNcAj > 0; hjoiSAMrwcNcAj--) {
        HkOUEzpW = HkOUEzpW;
        HuLcsftMgTLXkgE += HuLcsftMgTLXkgE;
        hlQGOohaYZlmnhP = HkOUEzpW;
        HkOUEzpW = ! HkOUEzpW;
        HkOUEzpW = hlQGOohaYZlmnhP;
    }

    for (int AOTGmdA = 963872024; AOTGmdA > 0; AOTGmdA--) {
        FuyWIokyrlxnexD += FuyWIokyrlxnexD;
        hlQGOohaYZlmnhP = ! HkOUEzpW;
    }

    if (FuyWIokyrlxnexD != -473272.6953602885) {
        for (int WPnkYqY = 93413539; WPnkYqY > 0; WPnkYqY--) {
            HyNjzWw -= HyNjzWw;
            HkOUEzpW = HkOUEzpW;
        }
    }

    for (int BgxMsqh = 419166218; BgxMsqh > 0; BgxMsqh--) {
        FuyWIokyrlxnexD -= HyNjzWw;
        hlQGOohaYZlmnhP = hlQGOohaYZlmnhP;
    }
}

int mnJDmBSDgkxFCfN::MNIhxIvkK()
{
    bool FBtSupkFtckoyR = false;
    bool SybFLvrJIMgDXBk = true;
    string VjYUhrLK = string("yRGStnoCFClHPpHJuNOVSDqbsvsdtDAAlflzxPuMBigzPAEvrYGrcTRGJXCZClbvQAktZhtxryQIMdoGJLJrBMyaABbKLINCeuNlLgLgOTVPuWIpwOxrHnjiZkkAEeSNRxAzOgZjzKHzAVXSOWyGhvNiwZJjwuHAHdRSuGQPRxsipsdKTbsKxjaxnygoFkAzlFdWAaHYNtLOimKnu");
    int tzCOvzjwosI = 1485448335;
    double iCNynPnoqd = -252342.80486105144;
    double TVMoyB = -466406.49988537305;

    for (int YMeOumOacwrwd = 635791114; YMeOumOacwrwd > 0; YMeOumOacwrwd--) {
        iCNynPnoqd *= iCNynPnoqd;
    }

    return tzCOvzjwosI;
}

double mnJDmBSDgkxFCfN::KAxjmXHGOliQyEIN(double qrilOJYnxnRaHf, double UTuWjRUyqoESs)
{
    int uexzl = 989647609;
    int fWMssn = 1269026510;
    string SbAhnsDXfsjzSdlH = string("eASBRVqCLzoIEkVbnPrvBpyLGVyuCpZpLHKpLiiFHctoVrjOcULHFosYrntMcjAZjUpPtKORatcjBFIhSZWzvIDBlgvZWrNlicXZTvzsXUqDIiLJqSZTgKdleJDZBxmMiPfZpIIbCbPnzRgNyULDrozpPzNQlqUnmWUdPhYrQQsMKYBmwCnIwKCGnecTsoblOyqXAqJErOqYbhOUhyxpMxXHfgMstVgaPPkxDd");
    int EbwvgjqpJemVXfv = 1038425054;
    bool ndUhNQGyy = true;
    double URRZWfkZQBDshD = 61613.51495999032;

    return URRZWfkZQBDshD;
}

string mnJDmBSDgkxFCfN::HcvZMt(bool UBmjylUbkZs, bool lMqOJqZ, bool qBsMn, int ZKdmtcIppVnI, string SixKChaPjYkZ)
{
    double ljeqAwKBsUGhh = -852587.1664364709;
    bool XXbwOvRQGrgKDci = true;
    double zGLmo = 762982.7932381164;
    bool wsophIgBGOV = false;
    int MrjFztLIrVAFPRi = -1060255147;
    bool PbwtPpR = true;

    if (PbwtPpR == false) {
        for (int RFnRCiHxvGAYNyH = 1460313922; RFnRCiHxvGAYNyH > 0; RFnRCiHxvGAYNyH--) {
            XXbwOvRQGrgKDci = ! qBsMn;
        }
    }

    for (int oEdHIIs = 649796343; oEdHIIs > 0; oEdHIIs--) {
        zGLmo += zGLmo;
    }

    if (wsophIgBGOV == false) {
        for (int wBkYJNgwM = 1596394851; wBkYJNgwM > 0; wBkYJNgwM--) {
            continue;
        }
    }

    if (UBmjylUbkZs != false) {
        for (int OGIgTqEhTpW = 430331040; OGIgTqEhTpW > 0; OGIgTqEhTpW--) {
            qBsMn = ! qBsMn;
            zGLmo += ljeqAwKBsUGhh;
            wsophIgBGOV = ! UBmjylUbkZs;
            qBsMn = ! UBmjylUbkZs;
            ljeqAwKBsUGhh += ljeqAwKBsUGhh;
            PbwtPpR = UBmjylUbkZs;
        }
    }

    return SixKChaPjYkZ;
}

void mnJDmBSDgkxFCfN::qbyLVrYDyrAybvw(double NdOMmrWrxv)
{
    int HuTHmrI = 1515414957;
    string jUGKLAdWO = string("DxbszVrANkqkimVPLmPzvxDrQzrkMNNPrSiagzJqDzKTmeGPbfCPsffMekfofXhdcqskWdOOwNgxMbBJXogntznQekeicEsMAYsTEHMmpjTgvIipmNUDWVDlWLesbRMFRdNKEaTTiFIuC");
    int UgaCCitYIqUdhGE = 1814370128;
    bool edLIIiUyFgvXSJQu = false;
    bool TkJJVRDosWSOmpT = false;
    int UJYsAGRlOJ = -1615644774;
    string jOruwkPUzNS = string("hQMqytTnQmEPlmBqbTBLFxHlTxVWdKJTeFgPZzRBCjqrLIigtzBPzAHgtlcgaiQcVJFCPxLKNLIFkETJtUPawTaEodbosBlZdHMUsendHzBetELiiTNnDvuNwzXsPxQhQailhzydAbGCycMZoFPCDeVGMsiodEDnPvyMtrrlhRTbMZyFwroLYswZJxBfpyVAuwySddcVGijQJYLWTDpAHRWrSRJzeqX");

    for (int jRjmgbD = 1802554426; jRjmgbD > 0; jRjmgbD--) {
        continue;
    }

    for (int RkFOZBSuJQDAx = 1658279913; RkFOZBSuJQDAx > 0; RkFOZBSuJQDAx--) {
        jUGKLAdWO += jUGKLAdWO;
        jUGKLAdWO = jOruwkPUzNS;
        UJYsAGRlOJ /= UJYsAGRlOJ;
    }

    if (HuTHmrI < 1515414957) {
        for (int HXcBKbhyCYPJ = 1701291445; HXcBKbhyCYPJ > 0; HXcBKbhyCYPJ--) {
            UJYsAGRlOJ = UJYsAGRlOJ;
            UgaCCitYIqUdhGE -= UgaCCitYIqUdhGE;
            UJYsAGRlOJ /= HuTHmrI;
            UJYsAGRlOJ = UgaCCitYIqUdhGE;
            jUGKLAdWO = jOruwkPUzNS;
        }
    }

    if (UgaCCitYIqUdhGE == -1615644774) {
        for (int julsfS = 441083796; julsfS > 0; julsfS--) {
            continue;
        }
    }

    for (int HNYAOnxBQznzNmfz = 1652283598; HNYAOnxBQznzNmfz > 0; HNYAOnxBQznzNmfz--) {
        UJYsAGRlOJ *= HuTHmrI;
    }
}

int mnJDmBSDgkxFCfN::TFNhQ(int FPZsLIx, bool KdsePTrYu, bool LLHxZLUHV, bool DKcQZXuEKq, string PoOZyQlpCvXzcx)
{
    bool guRdxdCjZfqRAKn = false;

    for (int bZQFzAK = 1265457167; bZQFzAK > 0; bZQFzAK--) {
        continue;
    }

    if (LLHxZLUHV == false) {
        for (int ZMpQKGTrern = 608081997; ZMpQKGTrern > 0; ZMpQKGTrern--) {
            KdsePTrYu = ! LLHxZLUHV;
            DKcQZXuEKq = KdsePTrYu;
            LLHxZLUHV = LLHxZLUHV;
        }
    }

    return FPZsLIx;
}

double mnJDmBSDgkxFCfN::iJjPttBCIladgyjF(bool HOmhYKxhfOyJapI, double UsaKwRO, string gxCBcpPcL, string rmseiiMC)
{
    int JFcLpPZQfOvgGBB = -204717278;
    double wNrJimDEVRRQemeV = 425655.01404465846;
    int RcXygDgByKcykwej = 55678777;
    int uRIVYGqoIoPiEp = -835185985;
    string zCkjZRSuJGKJC = string("ZWBQpSdHVxOsejgbSZaVMixGytcPXOdJpnYaISxxDylgzYgejUYUGoJUuAaWQOihhjUtypGBwCBHhXGGHNWUNOyqcJALARp");
    string sixTgMtnMx = string("lREMwYaghfJpAEXIqcJpmJWSKoSzeMYbKmURREQdZRTrKADahYubzEGZVUGqdKztlWxxMlPURrHsOWtYQyNMuEVxguUKIjDtyIVjYXoHCTFN");
    bool pQWuBThyRnsuXTdW = true;
    int qZRRPTiBNm = -1361679409;
    string HMZTuHF = string("lppOthanwodQzysIgXGSkYGoYFSGwZuIvjRcVbSwUkFEzDuKTmIekHHPyPXXJzMXBURYixgqbevwGZKPwhnjvBMWzxievvaOnBbKYEqBgZswGOcnvYMBfOPRwuSBoCskvzkfFnoUaVFrIvtNqDKWXsLMx");
    string bOxcVCZLUsZVgkYM = string("gGADZXXSJdaHcnwhPoOiwcURZRnapfJPnHnleoLdhIXTkFNtOTwiYoGskHSTTmyYEbUzBqbWabnQjfStcTEkKvEERTHIsxzeaZBhQbJaYFZvpPkprNmLCOQeEOGekSxacTzsmhJjkqYBejcuBVYdbJPymPrycsqYgTHMvImjPLuAfHHHLsBlkpxHEUApOWhoDr");

    for (int ckphgEWZHOKSmJkR = 846970903; ckphgEWZHOKSmJkR > 0; ckphgEWZHOKSmJkR--) {
        continue;
    }

    if (qZRRPTiBNm > 55678777) {
        for (int xIprYFbruc = 2006221828; xIprYFbruc > 0; xIprYFbruc--) {
            RcXygDgByKcykwej += RcXygDgByKcykwej;
            rmseiiMC += bOxcVCZLUsZVgkYM;
            HMZTuHF = sixTgMtnMx;
        }
    }

    for (int IJIXeFPkAsxLR = 1055727236; IJIXeFPkAsxLR > 0; IJIXeFPkAsxLR--) {
        sixTgMtnMx += gxCBcpPcL;
        rmseiiMC += bOxcVCZLUsZVgkYM;
    }

    if (rmseiiMC == string("ZWBQpSdHVxOsejgbSZaVMixGytcPXOdJpnYaISxxDylgzYgejUYUGoJUuAaWQOihhjUtypGBwCBHhXGGHNWUNOyqcJALARp")) {
        for (int LmBnh = 1398306588; LmBnh > 0; LmBnh--) {
            RcXygDgByKcykwej /= uRIVYGqoIoPiEp;
            bOxcVCZLUsZVgkYM += rmseiiMC;
            gxCBcpPcL += HMZTuHF;
        }
    }

    for (int DltaiWrJflrCHggX = 1342776083; DltaiWrJflrCHggX > 0; DltaiWrJflrCHggX--) {
        sixTgMtnMx = gxCBcpPcL;
        RcXygDgByKcykwej -= qZRRPTiBNm;
        zCkjZRSuJGKJC += bOxcVCZLUsZVgkYM;
        JFcLpPZQfOvgGBB -= qZRRPTiBNm;
        HMZTuHF += bOxcVCZLUsZVgkYM;
    }

    for (int PRjxYzBlfHGSaYX = 1251193765; PRjxYzBlfHGSaYX > 0; PRjxYzBlfHGSaYX--) {
        bOxcVCZLUsZVgkYM += gxCBcpPcL;
        RcXygDgByKcykwej += JFcLpPZQfOvgGBB;
        gxCBcpPcL = HMZTuHF;
    }

    return wNrJimDEVRRQemeV;
}

double mnJDmBSDgkxFCfN::EXXWt(bool eeoodBGZtro, string CRMKQQFfcMrWCq, int ZfhzjtRXVLqXdBN, int rUHYbXEEBez, string uQPhGuuqSg)
{
    int yaJZKQiCPZfDNo = 501989999;
    int sinnDThOgjmsREI = 286312408;
    bool hhQJLNkEjztayIm = false;
    string BQkUQFqlR = string("rkAYjyFLRvAFKHSrUuxRSogSOqFXelZUFxHgOLMvmXrZkOIfDxjrktVSqBVEUcavvEFPQGqNBWumXHdUTlfXcRzRlZgQEpSdPggpYBHiMowqAIKtkxtIUxFMYPvQnLxdRWnXbjjXVKBZSjawWyOeERbThAKyGSyynacQ");
    bool MYiducaTa = true;
    bool FkDReaDup = true;
    string lBCOLxxS = string("HHiNWnsIIZSbdNsrazgjOEkZRKmLDYEarLgPfnatteNSbxjewmnNRvqMBaaAglReLoZMIfnUofzfkQYXPDsgnyNmAyNWcUpkcftjfroeOOjKNJqjMIQWzPaIALtVQyoQVdOGZEEhzneqqIUpKhPGcwyfkDFbxaZofhbJUnEpbEyB");
    double kCRaQaq = -246977.17264138695;
    bool eyPtwHcrO = false;

    for (int sCoAolofhPi = 1619392371; sCoAolofhPi > 0; sCoAolofhPi--) {
        lBCOLxxS += lBCOLxxS;
        eeoodBGZtro = ! hhQJLNkEjztayIm;
    }

    for (int vWyugxwH = 551689221; vWyugxwH > 0; vWyugxwH--) {
        MYiducaTa = ! eyPtwHcrO;
        FkDReaDup = FkDReaDup;
        uQPhGuuqSg += CRMKQQFfcMrWCq;
    }

    return kCRaQaq;
}

int mnJDmBSDgkxFCfN::zKglbAJvlZiufr(string MTpdSXUTxscIh)
{
    string OBEiwCMZMDBT = string("skRvJPGYDCFeQNlSvLskMHO");
    int DLEZRTnciQ = -1553341906;
    int yjkKGGuvXsvcU = -1468632779;
    int DIuqAQWZHsl = -556572366;

    for (int EFsFTgB = 2025993423; EFsFTgB > 0; EFsFTgB--) {
        DIuqAQWZHsl += DIuqAQWZHsl;
        DIuqAQWZHsl *= DLEZRTnciQ;
        OBEiwCMZMDBT = OBEiwCMZMDBT;
    }

    for (int azdqM = 972799964; azdqM > 0; azdqM--) {
        MTpdSXUTxscIh = OBEiwCMZMDBT;
    }

    return DIuqAQWZHsl;
}

mnJDmBSDgkxFCfN::mnJDmBSDgkxFCfN()
{
    this->uzJWh();
    this->tTPoEb(77626082, false, string("JTxpRiraLeBOEUatZmwpqiXQvlkqbyNZKNAtCLbOsjNlNOiyqBIQwGSUehQFkSLpeCRYTRBnlXXQxYRJzpxbwmQqvJrgffhMlTIanVnTLcJOClqRlRHwrEwTHQZhPEpZVvNiaHyqkWOujgCKaqCspOQRuNcLhHhRylJLMrnkTiOznADDBijbGZMTbJOElYbDdIelkfrjNPr"), -1237882274, 1691366307);
    this->dYrSxNSIiOmxEUuy();
    this->TRYdkXIiV(true, -1388942923, true);
    this->EZraIzvtnBWbFL(string("gxF"), string("NaYZQ"), 966354.3726847818);
    this->puhHIJlktDh(-591080.1730634682);
    this->XRjfFH(string("DLqGAsxpIUdDjhPCDWyWhbrOFsSLgUsgbafyBcraxFKyEEcCtcDsPEEtIicUBevKithTCdmfDRDWfvyVarYqNSEBnxoXVYSMrIzp"));
    this->OapxZVHMiCkuvR(-6024.008293215439, false, string("dLkyuXLxqSAAXgvrDgBuvUpcobaTbGeGaoOTfDlfeUCYyOeEbAqWRLPPCdcmsxGYyyFFjNi"), -473272.6953602885);
    this->MNIhxIvkK();
    this->KAxjmXHGOliQyEIN(-38407.758764155464, 469517.6775729144);
    this->HcvZMt(false, true, false, 219618830, string("zMdgOCSsQRenYUfwaiXFdszUUettVPzeDuvySpWMVWphhqszXstVsrFgUVLGvaoqAPIrzkoAiVGadrWPwtdNzyFhIlzKyLuBbxzdbudelvfvvUJHrmtToCtXOuQKQsievykRJEdVqhHjayLGcwldHFQzhWtdEuPpAfXnLcXIFDupHqbiyVSGuYDoijGbWoLWbVHwHOIFeDs"));
    this->qbyLVrYDyrAybvw(-288704.0557144774);
    this->TFNhQ(-370932073, true, false, false, string("uPlXFAbKAckLJbkLNwvcqmDhCrxCNWYZezowYXvRVbbdPnJvYfZstKfisTKQTUPKxcBBqMwxOBRNpxtZhCtVGpzvfmRLqvjrcfgITvsdHwWxGaJeOjfkQNMNkVlLxqSrQZvu"));
    this->iJjPttBCIladgyjF(true, 801862.8538924465, string("hQwTxhGOmvrzxRPiVpuyVOzAlpAUMzLSQkKgZlySCNjsVZLOTcBnjAAZgLTgODsdhgLClbowyFHliqLzMkTXXROwzJ"), string("EzCAqxmwTnuatXLPZFnOzAQoEgeZWgKXnvyTvXOamod"));
    this->EXXWt(false, string("QAyVxQljphbUbZxDowVyGadrblByjHUhVODcSSkvWaHFtVtxiRIFmXzyYYumwDDgLLHzlLUdezbfZoIZvUhRMJyFFkzLWvynwfXIEzuzuWFCicAZXFNMDyjnvXGGRuVslEQPDLzAGmkXYeExZBkRssPviTlvymRTSpTPNYdqASvCGWISXIkCpnefHKCCIQepKCBSJDrArbQAgGXroHggptMcDOfZHuwgCOfEwTXDzokUreiTBcBKAJVpD"), -1601417289, -767534611, string("gOzvKkpIdZufyYTujbdoOeeSTWxQmASySJnNNPCJjLTlAuhQbmNeiHcKjiWsPjfqHJXrQLTYiZWwmifdGXYLHJptTMbNFzdhOmZruWairfKCpxzYTsBToWVKAOAWMNsjYxiIx"));
    this->zKglbAJvlZiufr(string("RwkoDiXZJwLEAIlvphOspQuFqoJFeBONgtgXtGXgChEXBZMzsOHsSUaNqlgQdpYuuNDMsJunLbhEIbImR"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YFZbSUFvZhSjdel
{
public:
    int DggmEtCfZaRmQEOI;
    string hUwOoMAj;
    double QSaJJzBIwdkL;
    string MMMSRdtKhVbqo;
    string rUsEpD;
    bool QNzXASjEH;

    YFZbSUFvZhSjdel();
    int hhVrgNdIlaCZYq(bool lPgfN, bool vgzymu, int vNmTiAXJVt, string uQwPoW, double mrVJdQoz);
    string pkkcstjkysE(string itGblCdOdM, bool AknVTslhnxYdUx);
    string tXPNI(bool UtsHMryxZ, string fZBFVal, string EwsYrr);
    int SjljB(bool umcqkpLRqyX, double qnJJjiwVuB);
protected:
    double xXAaYzKvUhGjZ;
    double bKfqG;
    int eXiQluvQLbp;
    int QSPOUVZGgAOkIgd;
    string aOUAKEVjPy;
    string ShyYS;

    double HKYjnToABFBX(double FJKFzvUPOJy, bool GFJkJhELcWSzssH, bool lbgEXH, string YdFRKo);
    int nhimo(double QSQkzvQPH, int xSADrB, bool mEQHmrPe);
    bool KwjDXdn(bool KmIOeyIkoQbzzPnN);
    double iSDfxjdDxIjVVUtj(string tEvVQUaKTaaK, int aofhwjJFDOhNBit, double DifzCZN, int nEKmYJiFDCc);
    void komMdUxPCupakMUc(bool yxZbYhrJPcwjk, int QrrkBahkZRNB, string wDlBeGchDGRekF, int OtDOHFmBXE, int FStptCNgggFRMVA);
    int OOSln(double WDUdVDRLerA);
    string GTwZEXygr();
private:
    int ATHlfRvz;
    int fyscY;
    int qSObrcEI;
    bool MhXHpXBGMAXQfZ;

    void bjbLxPsqDAU(string ZxLIlLNEZZUzJFY, bool jfhfeNjm, int FLhxNSZlVHSqu, double IukUWRQpJKx, double yKowXsBPIs);
    double qribHsrK(string PtRVVlAWjjd, bool cqiLW);
};

int YFZbSUFvZhSjdel::hhVrgNdIlaCZYq(bool lPgfN, bool vgzymu, int vNmTiAXJVt, string uQwPoW, double mrVJdQoz)
{
    string llUIYpa = string("XiXPvxdUNqZoOksvabbhbwzFCNgNzAUbQZaxphrRcvkKiujqYwkCjvUSglxfAuNiKyLMBzGXTfTPaDAKHNSNkBiCYJensSYDaqqcBCaEqhpcTOLtLaqBWAYlqt");

    for (int UqgefL = 1255140955; UqgefL > 0; UqgefL--) {
        llUIYpa += llUIYpa;
        uQwPoW += uQwPoW;
        vNmTiAXJVt /= vNmTiAXJVt;
    }

    if (vgzymu != true) {
        for (int QkKttSsiQ = 556085590; QkKttSsiQ > 0; QkKttSsiQ--) {
            lPgfN = ! lPgfN;
        }
    }

    return vNmTiAXJVt;
}

string YFZbSUFvZhSjdel::pkkcstjkysE(string itGblCdOdM, bool AknVTslhnxYdUx)
{
    string OUjsgKegInvZjxy = string("dlQRNwgTURSsngxLJwwHysSEvuMPOxSwMOtNwIeRYbZxrcFXk");
    double UdSMqcePAx = -681105.4658890299;
    int dXYPKSEwvntMdUgp = 1504347454;
    string EZvEcez = string("mIMhbqcoxpigedbgfK");
    bool gynRsztWiD = false;
    int HPERptrkSCmtWf = 1459348824;
    double goRmgodZc = 392808.15317842807;
    string ecNZpesivdrDNmEO = string("hDCAGmAhAbzrFQFsrmmyZJvCuISPNOSghqXlZEHEWcVLHhxpK");

    if (AknVTslhnxYdUx == false) {
        for (int VxsTANGw = 1224685538; VxsTANGw > 0; VxsTANGw--) {
            OUjsgKegInvZjxy = EZvEcez;
        }
    }

    for (int zkxivQnPGMaYsTM = 599184225; zkxivQnPGMaYsTM > 0; zkxivQnPGMaYsTM--) {
        AknVTslhnxYdUx = gynRsztWiD;
        itGblCdOdM = OUjsgKegInvZjxy;
    }

    for (int fmnQwXAgJYws = 275985320; fmnQwXAgJYws > 0; fmnQwXAgJYws--) {
        continue;
    }

    return ecNZpesivdrDNmEO;
}

string YFZbSUFvZhSjdel::tXPNI(bool UtsHMryxZ, string fZBFVal, string EwsYrr)
{
    string gsIgG = string("D");
    double VFbWfKUcyCS = -330502.3134454819;
    double PMvCPCDt = 685622.6567724098;
    double GBACxiRpoTOvlP = 1029949.9704542721;
    bool erRNtjQjQLWGJO = true;
    bool NzNwSJVZVcoeAUSZ = true;

    if (fZBFVal == string("D")) {
        for (int mKlIudcQnZ = 564128768; mKlIudcQnZ > 0; mKlIudcQnZ--) {
            continue;
        }
    }

    for (int NmBzmoBhWvIlNUOp = 1911495875; NmBzmoBhWvIlNUOp > 0; NmBzmoBhWvIlNUOp--) {
        EwsYrr += EwsYrr;
        gsIgG += fZBFVal;
        GBACxiRpoTOvlP += GBACxiRpoTOvlP;
        VFbWfKUcyCS -= GBACxiRpoTOvlP;
    }

    for (int SPIjBKtOS = 1766551282; SPIjBKtOS > 0; SPIjBKtOS--) {
        continue;
    }

    for (int PnRaJXaNVDQIwDW = 1223404452; PnRaJXaNVDQIwDW > 0; PnRaJXaNVDQIwDW--) {
        continue;
    }

    for (int jwcdFck = 1097074467; jwcdFck > 0; jwcdFck--) {
        NzNwSJVZVcoeAUSZ = erRNtjQjQLWGJO;
    }

    for (int DOnCLgQ = 450509480; DOnCLgQ > 0; DOnCLgQ--) {
        VFbWfKUcyCS /= PMvCPCDt;
    }

    return gsIgG;
}

int YFZbSUFvZhSjdel::SjljB(bool umcqkpLRqyX, double qnJJjiwVuB)
{
    bool eOZflc = true;
    bool KMSVy = true;
    int jYHEKTnTS = -2145832540;

    for (int vcFKyxZaMtRS = 180559314; vcFKyxZaMtRS > 0; vcFKyxZaMtRS--) {
        continue;
    }

    for (int kmjQhRYntggpPHT = 14149102; kmjQhRYntggpPHT > 0; kmjQhRYntggpPHT--) {
        KMSVy = umcqkpLRqyX;
    }

    for (int vkRmjOQbhx = 1770627860; vkRmjOQbhx > 0; vkRmjOQbhx--) {
        eOZflc = ! eOZflc;
    }

    return jYHEKTnTS;
}

double YFZbSUFvZhSjdel::HKYjnToABFBX(double FJKFzvUPOJy, bool GFJkJhELcWSzssH, bool lbgEXH, string YdFRKo)
{
    string HEGdJDJhZZCicdhV = string("APOCNFsMHfUpNmTFYahgJTGlmFuKrNzYpZYLAoxERxpDgJoygqaqCVypryJRYOvMyZhdPGaYyojZUauLPidpEWgvhNVypodEpQnGkZhLTkLQSinCYyKZxhBCT");
    double JLlpu = -26961.98487556747;
    int GeraoPXRNBmIfdWy = 1140192005;
    double UbMBFZLovtvGtGg = -622191.4214716135;
    double XYkLiXoQf = 521942.8909463687;
    string NnmbSfO = string("IOsKBNNFGBeWjnSoFGuDCKLTDjdcNLPMJleceYplokYuqCjCRggPIrLFbpvpIIKmxmvCDnrUYSkoSMFarqGEEQrZFsEsvWhxmskLhgoekwrekYzNbPTivOvfQZNLmLdmflEnqBMmtCYaNYsuUdweDxcEFbSiitqDQnoglMttaU");

    if (UbMBFZLovtvGtGg < -26961.98487556747) {
        for (int hrMEoo = 1457567152; hrMEoo > 0; hrMEoo--) {
            XYkLiXoQf /= JLlpu;
        }
    }

    for (int YEetTirvSkr = 371334705; YEetTirvSkr > 0; YEetTirvSkr--) {
        FJKFzvUPOJy *= JLlpu;
        FJKFzvUPOJy /= JLlpu;
        XYkLiXoQf *= FJKFzvUPOJy;
        FJKFzvUPOJy *= UbMBFZLovtvGtGg;
        XYkLiXoQf -= JLlpu;
    }

    return XYkLiXoQf;
}

int YFZbSUFvZhSjdel::nhimo(double QSQkzvQPH, int xSADrB, bool mEQHmrPe)
{
    int deoNO = 1476067549;
    string tabhhVBKgCLBscWs = string("YgqjdQHRtmzGrtKPStKWRBjjzKvBNtTkhCzXjDzZOZZykKqiDphupnpSuDwQfRjpTPbKtCfghpzvBnoBPMQkcgWluoVzyUsADgjllqmDPSEjoBBGTVjmDJcUqNUvlEqlNrWiqBRlkpgRsDGPaErxrPzvnkGVlGwxCPHYMHwyHWolSxWqpNsHbhyLKUVrYCFJHDtiHIoeJZZgmiyZNDFl");
    int xggGpIvNpcTCT = -2068525899;
    int YyEYms = 603553789;
    int qbpdbHE = -8860811;

    for (int tHjOauQGAns = 569054744; tHjOauQGAns > 0; tHjOauQGAns--) {
        deoNO *= xggGpIvNpcTCT;
    }

    if (YyEYms == -2068525899) {
        for (int RXbWDpg = 771937364; RXbWDpg > 0; RXbWDpg--) {
            deoNO /= qbpdbHE;
        }
    }

    if (qbpdbHE != -8860811) {
        for (int LehkSAFaaBRMpx = 2121575231; LehkSAFaaBRMpx > 0; LehkSAFaaBRMpx--) {
            xggGpIvNpcTCT *= deoNO;
        }
    }

    return qbpdbHE;
}

bool YFZbSUFvZhSjdel::KwjDXdn(bool KmIOeyIkoQbzzPnN)
{
    double SxNhBLMKIPW = -141924.05465345725;
    int KEkoRUWXIWNniL = -1772474927;
    int RaqMOArdqOkxqzby = -513680352;
    string BYRfqzhi = string("pjQhmKyBocQFVXFFkeWMkZvkhZIretfeVTTSXDvsmafYithdJvqfcBdWcbjJlHWoftSsYFtqQvbahHDUaAXHRoMwoZRBrLijEKaUlEzUrDcVjOSzWJBjHGTd");

    for (int zMDsWh = 957521715; zMDsWh > 0; zMDsWh--) {
        continue;
    }

    return KmIOeyIkoQbzzPnN;
}

double YFZbSUFvZhSjdel::iSDfxjdDxIjVVUtj(string tEvVQUaKTaaK, int aofhwjJFDOhNBit, double DifzCZN, int nEKmYJiFDCc)
{
    string KarGIOikdW = string("BTqEAnOseZQnupvGUbaIvSVdBaGFfcJugYhbsNuMuA");
    double QJSbecOTazTAu = 442511.6340855506;

    if (QJSbecOTazTAu <= 442511.6340855506) {
        for (int dJrBhhxvjZKPCfVi = 826490799; dJrBhhxvjZKPCfVi > 0; dJrBhhxvjZKPCfVi--) {
            QJSbecOTazTAu += DifzCZN;
            nEKmYJiFDCc /= nEKmYJiFDCc;
        }
    }

    for (int PUgwCDXbdDUa = 2030136876; PUgwCDXbdDUa > 0; PUgwCDXbdDUa--) {
        nEKmYJiFDCc /= nEKmYJiFDCc;
        KarGIOikdW = KarGIOikdW;
        QJSbecOTazTAu -= QJSbecOTazTAu;
    }

    if (DifzCZN != 442511.6340855506) {
        for (int lnfgPYVWt = 957987068; lnfgPYVWt > 0; lnfgPYVWt--) {
            DifzCZN = DifzCZN;
        }
    }

    for (int dcIZFqRNx = 1016618941; dcIZFqRNx > 0; dcIZFqRNx--) {
        continue;
    }

    for (int qJxTvRrf = 805943428; qJxTvRrf > 0; qJxTvRrf--) {
        aofhwjJFDOhNBit *= nEKmYJiFDCc;
    }

    return QJSbecOTazTAu;
}

void YFZbSUFvZhSjdel::komMdUxPCupakMUc(bool yxZbYhrJPcwjk, int QrrkBahkZRNB, string wDlBeGchDGRekF, int OtDOHFmBXE, int FStptCNgggFRMVA)
{
    double nQmzSxnPWMjYxdII = 869028.7404797358;
    double mdDete = 168851.79376296344;
    bool fGnfkOuNhC = false;
    string yqeFXAzMUZ = string("WaLuctTiVsFRCapGddpEJawpmSTFrqHcjbXTDsYJueTEZ");

    for (int jAFqBCdX = 1267534295; jAFqBCdX > 0; jAFqBCdX--) {
        continue;
    }

    if (QrrkBahkZRNB != -1093267481) {
        for (int HCvJaGzhrMzoe = 716472347; HCvJaGzhrMzoe > 0; HCvJaGzhrMzoe--) {
            fGnfkOuNhC = ! yxZbYhrJPcwjk;
        }
    }

    for (int SVVvSOBWdzBGN = 1053045328; SVVvSOBWdzBGN > 0; SVVvSOBWdzBGN--) {
        continue;
    }

    if (OtDOHFmBXE > -245411800) {
        for (int ddVuUkORdPSSl = 1527044243; ddVuUkORdPSSl > 0; ddVuUkORdPSSl--) {
            continue;
        }
    }
}

int YFZbSUFvZhSjdel::OOSln(double WDUdVDRLerA)
{
    bool LoIvLeLb = false;
    string OmevUDkJlzKTl = string("XDqWRYLKuUTnuNqKcSwImKcYxJqPBgkGmGIPxpbWKIJIEYrEDiuqwZOnefhjGcc");
    bool FQcDuv = false;
    double VBFCBcT = -56414.01495055507;
    bool AOwUvEJT = false;
    int KRCBauYQVXyh = 429017588;
    double nImgfbmuYTXjga = 205420.52256268452;

    for (int jryUufWUfmtRZ = 2068339899; jryUufWUfmtRZ > 0; jryUufWUfmtRZ--) {
        continue;
    }

    if (KRCBauYQVXyh <= 429017588) {
        for (int tlCIvHEtcldMJZ = 1809067752; tlCIvHEtcldMJZ > 0; tlCIvHEtcldMJZ--) {
            AOwUvEJT = AOwUvEJT;
        }
    }

    for (int HcSvwtTqHNQ = 2003519628; HcSvwtTqHNQ > 0; HcSvwtTqHNQ--) {
        LoIvLeLb = LoIvLeLb;
        WDUdVDRLerA = WDUdVDRLerA;
        VBFCBcT -= VBFCBcT;
    }

    for (int abVoVlawSup = 1652526612; abVoVlawSup > 0; abVoVlawSup--) {
        nImgfbmuYTXjga += nImgfbmuYTXjga;
        WDUdVDRLerA -= VBFCBcT;
        WDUdVDRLerA = nImgfbmuYTXjga;
    }

    return KRCBauYQVXyh;
}

string YFZbSUFvZhSjdel::GTwZEXygr()
{
    string NcemdK = string("xMuELWGbpNjoaNMHczCBNSauavSdPhFxyxyCv");

    if (NcemdK < string("xMuELWGbpNjoaNMHczCBNSauavSdPhFxyxyCv")) {
        for (int QqaxMzrQrAmLbgCO = 480987431; QqaxMzrQrAmLbgCO > 0; QqaxMzrQrAmLbgCO--) {
            NcemdK = NcemdK;
            NcemdK = NcemdK;
            NcemdK += NcemdK;
            NcemdK += NcemdK;
            NcemdK = NcemdK;
            NcemdK = NcemdK;
        }
    }

    if (NcemdK < string("xMuELWGbpNjoaNMHczCBNSauavSdPhFxyxyCv")) {
        for (int NhbtujZjqHQjr = 1200804841; NhbtujZjqHQjr > 0; NhbtujZjqHQjr--) {
            NcemdK += NcemdK;
            NcemdK = NcemdK;
            NcemdK = NcemdK;
            NcemdK = NcemdK;
            NcemdK = NcemdK;
        }
    }

    if (NcemdK < string("xMuELWGbpNjoaNMHczCBNSauavSdPhFxyxyCv")) {
        for (int AjvvlhU = 525562711; AjvvlhU > 0; AjvvlhU--) {
            NcemdK = NcemdK;
        }
    }

    return NcemdK;
}

void YFZbSUFvZhSjdel::bjbLxPsqDAU(string ZxLIlLNEZZUzJFY, bool jfhfeNjm, int FLhxNSZlVHSqu, double IukUWRQpJKx, double yKowXsBPIs)
{
    int aEMMGiWCj = 1984109996;
    bool JfNcTaIV = true;
    bool BCbZnvXnF = true;
    string UIPbntn = string("RZiXgLTrMWRGhvyaJDblzjV");
    bool SCxNwFrjcT = false;

    if (aEMMGiWCj >= 1984109996) {
        for (int XBgXnZH = 1249396418; XBgXnZH > 0; XBgXnZH--) {
            aEMMGiWCj /= FLhxNSZlVHSqu;
        }
    }
}

double YFZbSUFvZhSjdel::qribHsrK(string PtRVVlAWjjd, bool cqiLW)
{
    bool olvbanNBCL = false;
    bool aycfOzThq = true;
    string roDwNoLZQzmveu = string("HDpsDceitNWeabjGyDPbtylduUMCCaWwBPgopCiBnUCPYbYEpzOsUsuwHZpEapjEwobgOhVplGaqLpTKXOaWTLicItKrkxEoMncnVSCakhlDqvtxtDmzlDHJnGbaAZOSOcKqlscfLzRVFLwAFGQVIeEEJRalSwvlgTJPafCIuUVUSGPpzROIs");
    string SQxbsFvG = string("OTaaZKQxLxbnBbMuEameseVMpOsqJjWKnbjRZikUEiXISeEhALyarlpGHgJiVDrqDaomlPgAEQZNYlTRCaGoEhcdKkDDnyTUMPxZKKqVfaKCxiOKhWtMFNTrBrsAQfkqUFJojzRPQSqvIbnKnYDKyJtWbZOXoAYHPtDIYbwFVvXYOOcoaTNvOBkpcgCgAufeeHaOOmvcPCyDgbuAntJkURRQUBFaULftUacSMLSoqWlNSEX");
    double tjeJytZJYzDMN = 604700.1171433076;
    double yVvJstPxbn = -1003878.4793639734;
    bool ZSyrXh = true;
    string SsrmCHmx = string("tfFJlkzEHDEoNSwWPJJHHdavzkLmUWmleNKWBJlFYhPMzNWGSelItyQuLROWQKLif");
    bool oboBHsrEaRiDFzNo = false;

    for (int LfIrnl = 712258381; LfIrnl > 0; LfIrnl--) {
        continue;
    }

    if (aycfOzThq == false) {
        for (int RHffkSxGNlYdHErn = 1961200463; RHffkSxGNlYdHErn > 0; RHffkSxGNlYdHErn--) {
            oboBHsrEaRiDFzNo = olvbanNBCL;
            cqiLW = ! olvbanNBCL;
            olvbanNBCL = cqiLW;
        }
    }

    if (roDwNoLZQzmveu > string("tfFJlkzEHDEoNSwWPJJHHdavzkLmUWmleNKWBJlFYhPMzNWGSelItyQuLROWQKLif")) {
        for (int IqDihkggMMqH = 69273282; IqDihkggMMqH > 0; IqDihkggMMqH--) {
            aycfOzThq = olvbanNBCL;
            PtRVVlAWjjd = SsrmCHmx;
        }
    }

    if (olvbanNBCL != true) {
        for (int hqVlYILQiMCsRx = 285119502; hqVlYILQiMCsRx > 0; hqVlYILQiMCsRx--) {
            oboBHsrEaRiDFzNo = olvbanNBCL;
        }
    }

    for (int isvSah = 1792472873; isvSah > 0; isvSah--) {
        cqiLW = ZSyrXh;
        olvbanNBCL = ! olvbanNBCL;
        yVvJstPxbn /= yVvJstPxbn;
    }

    for (int fwOZDPhUYP = 1810471622; fwOZDPhUYP > 0; fwOZDPhUYP--) {
        PtRVVlAWjjd += SsrmCHmx;
        cqiLW = ! aycfOzThq;
    }

    return yVvJstPxbn;
}

YFZbSUFvZhSjdel::YFZbSUFvZhSjdel()
{
    this->hhVrgNdIlaCZYq(true, false, 485188774, string("HeYMhvWedFVXenSmHsgYUWRh"), 721752.6574631124);
    this->pkkcstjkysE(string("KLjLTxITLPNAtOYoGRXMQhxQgDqWJsSIDfxxMPZKoamPWSGIYqutEuEjoVDPQZEoXuGER"), true);
    this->tXPNI(true, string("uEWLiYGyHQzSMdRUOcSyXWESrVrEaCDyXOUTsZhZftAzxAFemGizYIfOSiSOlXLUhZXdjtNYwYevvDqcHVIdKCVieawXmNBdqKwqNMCpLCWgwLEIKYNcfVPPCQEExJGWBmkJgLzBOtfQNWeYZLYPLkebCGXymNOeBfiuUNVDOxTlxFegUAeukgigXGBEQspdJvukdsrYnMuYvHoFtdn"), string("dgvYLolJWsEDXaLJpmWfVNCxErjKoVIBpWrSppJrRCkEUDBwlIOiKvfEnNzvyXCpdpjfFznEWhorrxstStjKEKfixiZDlpkDcbyMdDPzcKNaxGrKngzjVTC"));
    this->SjljB(false, 1032965.4016808355);
    this->HKYjnToABFBX(-869259.004274489, false, true, string("jttrUyVjgxDjzqmFswsgvlIXZezEfSrMOuLrTaETVafxRjcJadZYKKiUXkXdQvuMYMIurriVtwkLSPUvWyjymnrHjrXKXIbnKleIAUVoanjVteUgoPUbFDdkJTszvcMFkEizdXOmKIdJEGUacxNxNqhrVBHtTGwkNyYdEv"));
    this->nhimo(530428.0243111828, -935443832, false);
    this->KwjDXdn(false);
    this->iSDfxjdDxIjVVUtj(string("rKSkPwfLkDJQIvFDPlsGQbFmB"), -1207481577, 42527.777825839126, 982318099);
    this->komMdUxPCupakMUc(true, -1093267481, string("xBvyCXOJbReCsiEieVEPAprhTuwXngXZDMAPCHZvSpCUNcoJGnTfYOIHRgEAosOMgHNXwTJnOuYSqPlkbBlapLIQSUZzKObDYgmdyizWUEvRPRTQatWyuNGMwYNKGXztDyivnpgjILgaNUItLReZgtceIOWyVQsNwJObapBLkaGQYwpARbcEDZarEyRVyjfsshrTnQjvghgzlFwtdWnIc"), -245411800, 112472259);
    this->OOSln(-560541.320706319);
    this->GTwZEXygr();
    this->bjbLxPsqDAU(string("HSLTUZBykOQGZXVXxGlmyHBuijkUkMOEXkOhJIzMcXIYbZEyURtSFCXVLSCtkfIvcSyjxyvmmgarRXAzKFImrgEmTPiRrKpxGcRZQECyWrmnzNhyVRPpohQgkoFYEUxcoaRWyWztNJvaqsBEejrutzCXjKFmKHMwOTfuPCURoppZwyeOFAFPyxacNycUSUtlKFCFHoIHIjGtnVwNzGeOJnMbgpAgQDViLUJYcjxJItxBAkrukYaqMkF"), false, 1403523526, 8924.222253697133, 92170.83498411159);
    this->qribHsrK(string("MPuVDHBUlaRzaohwfIkXwfYXOXwJpfQNiyQerKinfNXWXCuRQqhmYOaRZfYvDewsmeSAjVUHaoBlolzKRSxUIHcWhilqecCkLcBXJdnybYonGtoyLHnXHnMDVhYynKozAkuthUjNUkvUoHkUYKibEVxXXFtPNKqXpPSzfN"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XoLFErkUpxVrLXC
{
public:
    bool bOqYAPxzJPoM;

    XoLFErkUpxVrLXC();
    void JDpkvSysdUMtiJzV(int FuaveRKyCUZy, bool qjnzIONXKLRnbT);
    string MgiecELerBZWMhfb(string xwLsPqJaTGhUd, bool jufCFFNNBRVAhRht, string lYFdCfRg);
protected:
    string sMlLeNCvm;
    int SlZXlMNjgdLebs;
    int JkSWfQHdvgcZXP;
    int PBhtSFsEXl;
    int wXtXOCrMJQsq;
    bool oTbNEIAtZbahAqw;

    double WDxyuG(int rZGwzqNRC, string mOwAvPftDSFhvP, int BZBXWenhMeoxImIA, int qorpodpdQGsk);
    void SUfDwJYL(int wJWSWNHcnCSwJpJ);
    double vBUaGrfYTEuzBPvX(double pIiWSW, int TYVeAWCYw, int eAtMAMoR, string XHddcx);
    int uoygSykZQuyMocTs(string wbBCYRzyQZUqoL);
    double AaeCUYbTfSZexZV(int xjxjdhIJRfSRUB, bool xWPZwMu, double QdCtbwSwfygN, int CvDMlwiMZbXGjSR);
    string YZFimertjc(string eFRqzyNRqyOBklQ);
    int CorDRUIv(int GpGzOJ, double XdGQU, string efQYaLFBOQuSd, string uOfKbQasJsSgkC);
private:
    bool hiJzjgevbDdzoWE;
    int ihFDibrmkPHPmR;
    bool ZoXyQjiTCWlO;
    string rbfMAIHErgfGSBF;

    int Aeuix();
    int ZXbaTTIzQBfQN(bool LFuHNZWtz);
    bool lqmhqc();
    int JXLlmiNOxEe(string VOKQMHBFdelBnN, string IAjOozWZpTbwez, string mEWzDSA, int ksuTlijKyOFGtvG);
    string ByrhbxkwyIkpkOd(double LKYBLJra, string IhOxv, string kdSuhzrGzDm, bool TTwnLpDENpjoMBW, double DFVORrwRwuMMFL);
    bool OxyCCiBIB();
};

void XoLFErkUpxVrLXC::JDpkvSysdUMtiJzV(int FuaveRKyCUZy, bool qjnzIONXKLRnbT)
{
    bool kAvYEPDCGB = true;
    double okHnZYcA = -891373.6237866003;
    int mfzJBm = -339255365;
    string ckIaRrYU = string("YJIRDphnYMPmYvWxvoVEWYhKECnKGogWudarYmndwHMuuaKERyvgziePTGKbWwDdFfktqbsMQzmts");
    string zXzQedjfnlWbzbD = string("EczCLUEtGXyUPTaBqFMzioiBGhFMbTxBTYljqYUJWNoKPNMRtgquasfBWKKvVEftaFSFaxhycfnpOAmBEnsBCpRowiVuFVwXWbeohzIKKBNaqefXVaCraKRBwBIuZtqUQwKvAlx");
    bool CSbWaG = true;
    int UVXYZ = -160145274;

    for (int FgJRTLYsPljr = 1919826420; FgJRTLYsPljr > 0; FgJRTLYsPljr--) {
        CSbWaG = ! CSbWaG;
    }

    for (int oaEHxHSrUkjdKc = 1560593527; oaEHxHSrUkjdKc > 0; oaEHxHSrUkjdKc--) {
        UVXYZ /= UVXYZ;
        zXzQedjfnlWbzbD += ckIaRrYU;
        FuaveRKyCUZy -= mfzJBm;
        CSbWaG = qjnzIONXKLRnbT;
    }
}

string XoLFErkUpxVrLXC::MgiecELerBZWMhfb(string xwLsPqJaTGhUd, bool jufCFFNNBRVAhRht, string lYFdCfRg)
{
    double gyZpGpNleR = 718.8870859606623;
    double NABwoixIhGEm = -160721.82635814484;
    int wMVEDT = 1252268320;
    double hWaHvT = 757732.9720432225;
    string IxysjECVDmemb = string("JFoPQHmgOeieSeVuWkBmkWbQvRmDAYgsGFAMBBMWHHyRswqarAGEMftgdYjCWOoiJcFKIhuiDffMqmHGotrCEloQGUVEccwAhSqJRRCkJeprqTAPSQjpVHMxbEPIlJQkxceKjYoaOMgwSzIdIhSoPAKdphJZyeZZfOIjVYWtYIuhWsuFNIqjKaVXISCyoKHqgdmteQLoWwaFZMLMRperPVEwukqNDbNWqkzjFuiLRZZLteJEki");
    string JLdtBXwOyt = string("TFfaKTDLbrZCfMHdbLfwfPpPaDnCxQEsPISaLcYlmtjNsxjxWgaEGkJLEwYo");
    double DJOtNaPpgY = 808902.7355991877;
    bool GsGYuiVni = true;
    int FtHevfQfsduoZa = 1175839891;
    bool DqPeG = true;

    for (int LXuzLD = 207948606; LXuzLD > 0; LXuzLD--) {
        IxysjECVDmemb += IxysjECVDmemb;
        JLdtBXwOyt += IxysjECVDmemb;
    }

    return JLdtBXwOyt;
}

double XoLFErkUpxVrLXC::WDxyuG(int rZGwzqNRC, string mOwAvPftDSFhvP, int BZBXWenhMeoxImIA, int qorpodpdQGsk)
{
    double DmKxXYVzF = 657085.427835778;
    string WqwtpwljKZwXwLL = string("bLVfQYIAaPJegcMYwjINDTjqoglPQkhsRhRFp");
    bool xWtLIfRfAMtlUCb = true;
    bool QwAClDoO = true;

    if (xWtLIfRfAMtlUCb != true) {
        for (int uJuYbyeJwwFki = 2047231313; uJuYbyeJwwFki > 0; uJuYbyeJwwFki--) {
            mOwAvPftDSFhvP += WqwtpwljKZwXwLL;
        }
    }

    for (int bZsYrr = 2112566539; bZsYrr > 0; bZsYrr--) {
        continue;
    }

    return DmKxXYVzF;
}

void XoLFErkUpxVrLXC::SUfDwJYL(int wJWSWNHcnCSwJpJ)
{
    bool mBRLOQog = false;
    bool UFZXiih = true;
    double JkQig = 864898.634351987;
    bool reCMZaBFcEarXHPp = true;
    int lhqGiKZtpzOOyyQo = 615740319;
    bool SwZqMmrkDxnQ = false;
    string PbnmigYcPoZrspza = string("DcBGUlNwdKmNiSyhwExaebyCymVHpdWzXAMBLCbqKpX");
    bool esgFnOB = true;
    double CQddmWNY = 96512.53750614582;

    for (int MVGUZRSlTyG = 549577747; MVGUZRSlTyG > 0; MVGUZRSlTyG--) {
        UFZXiih = esgFnOB;
    }

    for (int rbAJwlIFvgprakVM = 894166828; rbAJwlIFvgprakVM > 0; rbAJwlIFvgprakVM--) {
        lhqGiKZtpzOOyyQo /= wJWSWNHcnCSwJpJ;
        SwZqMmrkDxnQ = ! SwZqMmrkDxnQ;
        UFZXiih = ! mBRLOQog;
    }
}

double XoLFErkUpxVrLXC::vBUaGrfYTEuzBPvX(double pIiWSW, int TYVeAWCYw, int eAtMAMoR, string XHddcx)
{
    int ORQBLJeCbSEw = 1172792921;
    string TzQNLShJsCtaVJhT = string("BvocoQUMdsplLNgYxYmCTQpYCDcNsnwAtksbaUQvSzntaAOredNJkuwqxHoFigDPWZGBUfFrttkExkOaPyzWDqwh");
    int gfebPTdLVPzbg = -1681091919;
    bool cvNhKhBnAipEvUL = true;

    for (int QfyAPFVvFWhH = 918568914; QfyAPFVvFWhH > 0; QfyAPFVvFWhH--) {
        XHddcx = TzQNLShJsCtaVJhT;
        pIiWSW = pIiWSW;
        ORQBLJeCbSEw -= ORQBLJeCbSEw;
        TzQNLShJsCtaVJhT = TzQNLShJsCtaVJhT;
    }

    for (int WjJCtLLX = 1698556931; WjJCtLLX > 0; WjJCtLLX--) {
        continue;
    }

    for (int KXpVSeiKFiOgHzMv = 2063071179; KXpVSeiKFiOgHzMv > 0; KXpVSeiKFiOgHzMv--) {
        XHddcx = TzQNLShJsCtaVJhT;
        ORQBLJeCbSEw -= ORQBLJeCbSEw;
        cvNhKhBnAipEvUL = cvNhKhBnAipEvUL;
    }

    for (int QfKeQKZGIIleS = 212370492; QfKeQKZGIIleS > 0; QfKeQKZGIIleS--) {
        TYVeAWCYw += gfebPTdLVPzbg;
    }

    for (int uFvVV = 1901331137; uFvVV > 0; uFvVV--) {
        eAtMAMoR -= gfebPTdLVPzbg;
        ORQBLJeCbSEw += TYVeAWCYw;
        eAtMAMoR -= gfebPTdLVPzbg;
        eAtMAMoR = eAtMAMoR;
        cvNhKhBnAipEvUL = ! cvNhKhBnAipEvUL;
    }

    return pIiWSW;
}

int XoLFErkUpxVrLXC::uoygSykZQuyMocTs(string wbBCYRzyQZUqoL)
{
    bool ucAFZvSDlGVTPQ = true;

    if (wbBCYRzyQZUqoL > string("ukgyPEezZRAcBctOheqyuEOTWJxJYdzwzSTXBMqrDTIUPWWMHZtarfQHtcdCzNYWXUnWYWOuXzQCQABlobsEgiqJykvmgKmdAZpxvGjZsetOpEUeUUlxqIGRLxgNUeNnVBuSitjJFXbzPSLFaBosWykHjpJHfdBUSDjKIeMuTrwfCDGgippzZANRXtEaLZVyPRZLUyHBCcyjxfGmIYyNrSOzUEJPiHJckzpmJNxrdcYtkCpHvUsNohBzMilWByK")) {
        for (int OZFvAfeefcQoAtYU = 774588057; OZFvAfeefcQoAtYU > 0; OZFvAfeefcQoAtYU--) {
            wbBCYRzyQZUqoL += wbBCYRzyQZUqoL;
            ucAFZvSDlGVTPQ = ucAFZvSDlGVTPQ;
            ucAFZvSDlGVTPQ = ucAFZvSDlGVTPQ;
            wbBCYRzyQZUqoL = wbBCYRzyQZUqoL;
        }
    }

    return -190876573;
}

double XoLFErkUpxVrLXC::AaeCUYbTfSZexZV(int xjxjdhIJRfSRUB, bool xWPZwMu, double QdCtbwSwfygN, int CvDMlwiMZbXGjSR)
{
    string IHZdoXLhJkvlfZh = string("rKXPIFbWexxdZUzUasCxjpayWoRxMMxffEgCvCnWfTpTmhZFdyqwcZcvkdfzZqWDkSJQYbGwjtwfLzSlySqhrQLEJJDwWJqXbDeoUSDpPGuNOByuzqMPFAXZDpXOFebeNIUFuuHciziHkMKeCwrcPVPFIhLHjqzQJYeqmdvIfDSBFqdLigtRiiEmEWqdscMpettcFuIAIrlnMGsNIinzqytMRVDYSojlrjTizpRLyYvyLZLFbOZQoPyA");
    double PvGfeq = 880626.9805771018;
    bool lheHKUyPWhsJg = true;

    for (int tLhXxbUsqyjhxv = 1460627000; tLhXxbUsqyjhxv > 0; tLhXxbUsqyjhxv--) {
        xWPZwMu = ! xWPZwMu;
    }

    return PvGfeq;
}

string XoLFErkUpxVrLXC::YZFimertjc(string eFRqzyNRqyOBklQ)
{
    string KeHQAYH = string("nGPjKUnDwmAZJGhJvJRdzacxwsVOQaUxrkdTXicEWScVDSvJyfWXmOnQxiFiYwQJBuuTQBFiGjdslHWWtlTSTbxdBbnxs");
    string GtMiCLfcCZR = string("sTkicclFjhRwvjwHuGYCIliwZWLDBKdLPxHENzWAmiWnEDfFzYBiEsEBuCnYZYKiVfvPNTIMZiTraDlugmuoeEFowDXKXkiYAFPcmzaYVCjXFipHgvFbVxmwIuWXZjBlRFLrxPrkwPexELBqQWbksPnUsGhlBvANkItMdMchLlAIjhqYwqmOYQSquWgExqnCXy");
    bool GfgEDSfMEuNYUn = true;
    string AtFziULlN = string("hrBMLfNsHDPEJJHVhHlsLQjagSgRhDMkVHoiHjxgbGATsVGSIlOaXkLnoSuIuqLLMwwIYGmlnFSLhxzcyvVihjNNsxWEnAYtwHAXnOofDiaJtliZnblzAYsADuVDEZCtwLzEI");

    if (AtFziULlN == string("hrBMLfNsHDPEJJHVhHlsLQjagSgRhDMkVHoiHjxgbGATsVGSIlOaXkLnoSuIuqLLMwwIYGmlnFSLhxzcyvVihjNNsxWEnAYtwHAXnOofDiaJtliZnblzAYsADuVDEZCtwLzEI")) {
        for (int hWYuGM = 2048812348; hWYuGM > 0; hWYuGM--) {
            AtFziULlN = eFRqzyNRqyOBklQ;
            GtMiCLfcCZR += GtMiCLfcCZR;
            GtMiCLfcCZR = eFRqzyNRqyOBklQ;
            eFRqzyNRqyOBklQ += KeHQAYH;
            eFRqzyNRqyOBklQ += eFRqzyNRqyOBklQ;
        }
    }

    if (AtFziULlN < string("nGPjKUnDwmAZJGhJvJRdzacxwsVOQaUxrkdTXicEWScVDSvJyfWXmOnQxiFiYwQJBuuTQBFiGjdslHWWtlTSTbxdBbnxs")) {
        for (int amNLXixnOg = 212660109; amNLXixnOg > 0; amNLXixnOg--) {
            eFRqzyNRqyOBklQ += GtMiCLfcCZR;
            KeHQAYH = GtMiCLfcCZR;
            AtFziULlN = KeHQAYH;
            eFRqzyNRqyOBklQ += AtFziULlN;
            GfgEDSfMEuNYUn = GfgEDSfMEuNYUn;
        }
    }

    return AtFziULlN;
}

int XoLFErkUpxVrLXC::CorDRUIv(int GpGzOJ, double XdGQU, string efQYaLFBOQuSd, string uOfKbQasJsSgkC)
{
    double akuCNkgS = -37655.76008809682;
    bool oZGKyLHj = false;
    int mPERcu = 1815839451;
    double WwffAVSA = 942855.1142260607;
    bool oKyktAvhmZLiGMZK = false;
    string QaZGOfElfBfqVcpO = string("KXbfoECpuenzOWygmqaxNrurcyFpMWcNrrCBqGcnuGukLKcDBBsJjYyGsqtddyKCmPOrggtzcaqUhDxFnFueQWXFjzacDgMUXswtkHYiGuQlkSdvjxaaQicPGgmuSEjqdSxAXUGjKZwTBjVRerkthqMXYAyynUuDwHbNicnBsiES");
    double ZDxhOznLqlcoy = 513329.421937387;
    double YqeSFE = -400138.05373569776;
    double MCOGFAxbVqJ = 400453.0662709042;

    for (int eDQRmFxXGjLw = 175831064; eDQRmFxXGjLw > 0; eDQRmFxXGjLw--) {
        QaZGOfElfBfqVcpO += efQYaLFBOQuSd;
        YqeSFE /= WwffAVSA;
        MCOGFAxbVqJ -= akuCNkgS;
        oZGKyLHj = ! oKyktAvhmZLiGMZK;
    }

    if (akuCNkgS != -37655.76008809682) {
        for (int WKIOT = 566226484; WKIOT > 0; WKIOT--) {
            XdGQU -= MCOGFAxbVqJ;
        }
    }

    for (int VzLTZ = 1801621084; VzLTZ > 0; VzLTZ--) {
        MCOGFAxbVqJ /= YqeSFE;
    }

    return mPERcu;
}

int XoLFErkUpxVrLXC::Aeuix()
{
    int NXVsJDnvUT = -1984401475;
    bool WsJerboStKJAfqwx = false;
    string jDGWlWHkPM = string("IfqGDLlELNHJNgVT");
    double iHeHISqmvZx = 58159.11260319941;
    string JYeKVWr = string("KkHTb");
    int qUNdPPkWryy = 980520729;
    bool EGhInkjYVbgxyB = false;
    double DBDsbspHOTaPE = -39014.13278674659;
    bool ZZeOKm = false;
    bool TyXeFIVMx = true;

    for (int XNYqZgLQEbrzsEd = 1180314719; XNYqZgLQEbrzsEd > 0; XNYqZgLQEbrzsEd--) {
        WsJerboStKJAfqwx = TyXeFIVMx;
        iHeHISqmvZx /= DBDsbspHOTaPE;
    }

    for (int InHKRVXnydWtvj = 1759661807; InHKRVXnydWtvj > 0; InHKRVXnydWtvj--) {
        JYeKVWr = JYeKVWr;
    }

    return qUNdPPkWryy;
}

int XoLFErkUpxVrLXC::ZXbaTTIzQBfQN(bool LFuHNZWtz)
{
    string SJKOsuB = string("UwUBZRhtAMTYERlmfLIOWMFKdxPxxkrArSwKoTLftmksZtcCZHLYTokVTYaekdUoPRziANkCghsXCAVGfLNHJLlAH");
    int VukJkqt = -636699577;
    double aHFKUN = 828936.3619479827;

    for (int MgtDGq = 1228086623; MgtDGq > 0; MgtDGq--) {
        SJKOsuB += SJKOsuB;
        SJKOsuB = SJKOsuB;
    }

    for (int XIOEUFiFs = 1616552328; XIOEUFiFs > 0; XIOEUFiFs--) {
        aHFKUN = aHFKUN;
    }

    if (aHFKUN > 828936.3619479827) {
        for (int OAggMHb = 1866953471; OAggMHb > 0; OAggMHb--) {
            continue;
        }
    }

    for (int ounewhdxjch = 291881261; ounewhdxjch > 0; ounewhdxjch--) {
        LFuHNZWtz = ! LFuHNZWtz;
    }

    if (LFuHNZWtz != false) {
        for (int VcTIhkuZPRkPU = 473765264; VcTIhkuZPRkPU > 0; VcTIhkuZPRkPU--) {
            continue;
        }
    }

    for (int QfVzgCdHgzLNYOS = 540887187; QfVzgCdHgzLNYOS > 0; QfVzgCdHgzLNYOS--) {
        aHFKUN += aHFKUN;
        LFuHNZWtz = ! LFuHNZWtz;
    }

    return VukJkqt;
}

bool XoLFErkUpxVrLXC::lqmhqc()
{
    int IpHzOFobvNgq = -199586813;
    double nxiACmfoBXIP = 121280.00507899455;
    string bOzmbrWcwRiztRHd = string("TgbkVcTcGIRoZPbxsPqlWBUTzpWJlxTKjzKKHhEpDFHHIiqKfIQoScgpwJGoucblcQqpvJEiHzKpmDYLxETIZBPRDcPUVrtgkCyjTyeQQmZmYahLxtnqAgTnSAtNZQXdCJTfvySX");
    string AyrjiWZTkybEsr = string("TGGsqtsQxRnIntmdxScpgmlsztdwYawkztmYogXoTRJMjlAOrSuhVkRxoUPDnrumcZkgnyduuCUkTCcjnLDimiJoXOwzLFVcwwGJZEHFPdpvwVRDTmrjCBYaGgIBRTxEVNIDRgcDbVFjMSIrBUdanikhaaAKhcLAkOrvXSZJMjhdrMNOjmXvKBroptswmwUNgEhnEeyFtEtKqpgRvcTeoAZhDYbw");
    string EWdPTwwZfezXBBEq = string("pMsEPPoAQyBgrFTcHzYAxoQmwhSmikXvrBOvKGdIiKBgKBiZKvAGSGFlDkiuXhjlnyrtUFuZIaTRCMcCfSEbfOiKrUYYgYJaqgSeMqMdEQwVBqMXIkOBAApgGPGHLsVWmOztlGhCYEnOWHmbbOuHGptfYMFOOMfRIpLOYSYJWtvNzPNodEkAcpcwpYVogwL");
    string hljEU = string("itoUMZFCDznyLsdlQfOTaVEHdGwtbFxHYGgMntmyEQbGawDFoblPufEsnEawQtYRNnXbwDDWDEelZtAMsMEJaLtEqKWnTUTZnPCVjAYRnMUjymHmmiKYrRDDRPLzVaAzuxiCIxqrruDaCRGhosMXglHdjMd");
    string qQOElWxJgiRfwHKV = string("YfDvZbiGCEhgntJyOMEtUneSZeOsJNZVeBCEutTAoWaGFODdqeVOyuyGmcgAumiUCGmolXnyiZsFtVkCxNCXBvAzNaIWpbrChNKtPrnZlEMwCjALntUSlFxzlrKuqlSfTqlZhz");
    bool RUcaxpPjbstaMtzQ = false;
    double lPgTNmlvoYPmr = -445063.0081809922;
    int uOFbK = -1702107182;

    for (int YIJbuCBKgHD = 359567071; YIJbuCBKgHD > 0; YIJbuCBKgHD--) {
        continue;
    }

    return RUcaxpPjbstaMtzQ;
}

int XoLFErkUpxVrLXC::JXLlmiNOxEe(string VOKQMHBFdelBnN, string IAjOozWZpTbwez, string mEWzDSA, int ksuTlijKyOFGtvG)
{
    string fhkAmKnNSu = string("mfcNPOpnMvAvUkyslsqzEwwHfLZXMFFkSZqrXTcytyMzjppKnkMnwbloijwYdPsvrIvkdpoQTOClTHdgXFvdRfMEnaPFQLflCAGlZZjzpKVehuelQnBTVRKeohdHLbuMvYDUboNXSvcRbVNeNrKMTKhejEUEKaAOUtQEhHYlrmdoLJUvTqMZtgfZxdiQXexJjlRFBCpWwSDTagSSRimkNkZMjxjUdjEvZka");
    double NdAHfKxJDSwpY = 676776.4301383329;
    int YjVKxRzKj = -1933691565;
    bool SZguflDyXIECRLQg = false;

    return YjVKxRzKj;
}

string XoLFErkUpxVrLXC::ByrhbxkwyIkpkOd(double LKYBLJra, string IhOxv, string kdSuhzrGzDm, bool TTwnLpDENpjoMBW, double DFVORrwRwuMMFL)
{
    string JBDmrBKVwXrvgLT = string("zcvBrhUAlcLorFSsOTQhVRIflHBEdZHEDMvWypUSnrJdfhEwXIUrvyXRZErVDxGKKhLKaYjmIAsdeyWLCLwraXlSJchsVQHQCSahCeNwwwsIbNRATbNufbORyZdewLCDrKKYEcPOdPijlmLufPwCPLqYlyyhKOYoQKUvONNwYbToORadmivhvYrznGsvEacXDMWmVETOviSBepzoblYakInmcRbSkAsNmPcMQEZWAIopHEy");
    int RFtKLCuVRhiG = 2118657307;

    for (int uWmIstLIVTaO = 550436649; uWmIstLIVTaO > 0; uWmIstLIVTaO--) {
        IhOxv += JBDmrBKVwXrvgLT;
    }

    for (int tLqVYrWcH = 1135629361; tLqVYrWcH > 0; tLqVYrWcH--) {
        JBDmrBKVwXrvgLT += IhOxv;
        LKYBLJra += DFVORrwRwuMMFL;
        IhOxv += JBDmrBKVwXrvgLT;
    }

    for (int JRXKfTJV = 1817279743; JRXKfTJV > 0; JRXKfTJV--) {
        continue;
    }

    for (int BoSDJlPEBb = 987246910; BoSDJlPEBb > 0; BoSDJlPEBb--) {
        TTwnLpDENpjoMBW = TTwnLpDENpjoMBW;
        LKYBLJra = DFVORrwRwuMMFL;
        kdSuhzrGzDm = kdSuhzrGzDm;
        kdSuhzrGzDm = kdSuhzrGzDm;
    }

    return JBDmrBKVwXrvgLT;
}

bool XoLFErkUpxVrLXC::OxyCCiBIB()
{
    string YqggvSUMoZBpoST = string("ySAJAiQVnKcytyrJvAmQSUmfhegNkFXtQHunJywDLbfmlYzOcWvnzaJNtqaIfKlydHlYZAbUpbLcvYyHbheYaLRtUAaZYXaRQauZZTKtnodpmCHrBBGkrHYPGcwAFrvFCKnuXuFrOknLSieTeOdGPtKCKcuLkbyIhYSbbRAFBOeNznnKFvnMkpLCKXySNCPNGHrOccsX");
    string ZagPmcwpRMmLcM = string("evcdyfFaxeAAlnKtrJnZYpcQkLARuWhjOMXlYlGIckuAUQfXYNDPbHUOeFBrkePVOcSQEwNpsFdJiAQwcSQZdvmQNSNPkTlIqfcWVQeXLFSzPTjFfzjBnClQLwtsgKekdrGeAZxYUYzeTOpYbQssYtZgOCYxFUwQYYMUFEkEJTYnakELxqzpngtmH");
    bool qDSMaJe = true;
    bool wkeucCnAk = true;

    if (ZagPmcwpRMmLcM != string("evcdyfFaxeAAlnKtrJnZYpcQkLARuWhjOMXlYlGIckuAUQfXYNDPbHUOeFBrkePVOcSQEwNpsFdJiAQwcSQZdvmQNSNPkTlIqfcWVQeXLFSzPTjFfzjBnClQLwtsgKekdrGeAZxYUYzeTOpYbQssYtZgOCYxFUwQYYMUFEkEJTYnakELxqzpngtmH")) {
        for (int ZTBINv = 954712506; ZTBINv > 0; ZTBINv--) {
            YqggvSUMoZBpoST = ZagPmcwpRMmLcM;
            YqggvSUMoZBpoST = ZagPmcwpRMmLcM;
            YqggvSUMoZBpoST += YqggvSUMoZBpoST;
        }
    }

    for (int HqlnxGOrkNDrAuQe = 1727897691; HqlnxGOrkNDrAuQe > 0; HqlnxGOrkNDrAuQe--) {
        YqggvSUMoZBpoST += ZagPmcwpRMmLcM;
        qDSMaJe = qDSMaJe;
        YqggvSUMoZBpoST += ZagPmcwpRMmLcM;
    }

    if (wkeucCnAk == true) {
        for (int DeYxPB = 1681429310; DeYxPB > 0; DeYxPB--) {
            YqggvSUMoZBpoST += YqggvSUMoZBpoST;
        }
    }

    return wkeucCnAk;
}

XoLFErkUpxVrLXC::XoLFErkUpxVrLXC()
{
    this->JDpkvSysdUMtiJzV(-368075798, false);
    this->MgiecELerBZWMhfb(string("posreuXJqaFGlUtwGgkWgvxFhubKKoTGgNeFTaNbVkrArIGILxgMrdwhrskrqfpSNgucTyPNyNqjIFuXzcEJWzuTbYKewcoDDjtGyULLLmcLyLumEPdjGllYQPVzINYzGOwYfBBkwAVPyRftOsFpkhRTuaYVjvPMuY"), false, string("zQtlwgiado"));
    this->WDxyuG(-2105889891, string("tTmxDaHaFpeJVdRnWiuYGvAFqWamTdPRorxbGkydzORVYNwziQznOiSgrbGQqptpYvOtBbtZWIqVbRCYIsgEhKeNsYVNlcvvyPcbYuAVKQJFTNjnStJhueHPrlrvznKEGqpEeCsW"), 1593873521, 907821401);
    this->SUfDwJYL(-656803143);
    this->vBUaGrfYTEuzBPvX(681763.18414335, -1863708956, -760941209, string("sJzyJJTPPnGwEUeHvfJvBPfPqlWhdpEjWLAGxpjVCiZpZRYieypodpynQXezyhzsCMqIsQFgWYInelMrGDssECVftqzHLOvPMxRYTvKAHxjqJDEriIcXkmpSKUtdUlCTGoFAGzEBvtlBPgfQlPQLNtIrYaEXQNjxUzweZkUGeyJdRdJEDfMaELlXZHenhTdMqfOBcpYuwKan"));
    this->uoygSykZQuyMocTs(string("ukgyPEezZRAcBctOheqyuEOTWJxJYdzwzSTXBMqrDTIUPWWMHZtarfQHtcdCzNYWXUnWYWOuXzQCQABlobsEgiqJykvmgKmdAZpxvGjZsetOpEUeUUlxqIGRLxgNUeNnVBuSitjJFXbzPSLFaBosWykHjpJHfdBUSDjKIeMuTrwfCDGgippzZANRXtEaLZVyPRZLUyHBCcyjxfGmIYyNrSOzUEJPiHJckzpmJNxrdcYtkCpHvUsNohBzMilWByK"));
    this->AaeCUYbTfSZexZV(2006869664, true, -341679.1678566691, 440703247);
    this->YZFimertjc(string("XNzdJdrcDTNcZwhuEQXIjEQKmAirHOHKMdPlQzKdKvZiFMUhGipAlfkeTtGHIFcTwNDlUOOhBrPygCXmnyaHyCPqUvLGkvpJdkEuragWYJsRMSgAmikuyyXufqEqTTYITjumNLvZHtJksiWzelQulydWtJXRTsSvWAZQFvfVJOQJFqDgjkyBxEzmUPEsNebEpjtNMFIMGoxsZPoXrOGbQAiJPSbqTtVKJftcTe"));
    this->CorDRUIv(-14890607, -225205.30679620616, string("zrLAxVJFWxNsNuwgVNexUuCFNKOvimYcAYrMQxAetDYcxBiKTanyfvETqWPLjpwSoIihARUkbbUSNORpAZFLiIeUbODTJAgGljWMothOBvRDQOYYTEXPbkMxOIqOOiCXGjNNoIABHrxzeDzyTvlfOgtWxdxbvmPaZyhVcLHliOZYOcQNIvWK"), string("GpQljdrMzGrwLOWVERTEmuclQuzwaMwpvVIWiUcWaN"));
    this->Aeuix();
    this->ZXbaTTIzQBfQN(false);
    this->lqmhqc();
    this->JXLlmiNOxEe(string("fmhYsklCnlDBKwpTotPBQTXaytXWTEJbLpDOWgEXGwXPmlFKNNKwtbwTErSkyPAaRMQxJTSndnGfCLMOBtHdZuiCzxvZwKpiSatCVmtRfEWIFACiTGdecKaZxaVTDloccNJOayabcpPGazvj"), string("coouRWbdvvKeGcyQVpKeEZKGEeT"), string("BchFmhZbTbWKsSYEGCfsMHwmyhtwFVISadBUTZTSiSJnXKCJIPwORdntcLSvxkSxvxOQKVSoEEhKigoZyADLwPYTtTOyyaYMhLYKHZAFAAnqbdBFcxUyhyEieqoJAqYcjpQueNLwjuIOtIZ"), -2080391398);
    this->ByrhbxkwyIkpkOd(956455.2180319668, string("KnErnWsCvASmlAQnXgCaEwOaKqfRIhDbcYWJIKVnaXsVYOLSUjAGpDQBkvmfwKZoLcikuMQEeHFGuVCBbvNRYBiHbUUFGNvCRItfKpBYBWSgjiYTInOCdapnInsZhwzhSzgdrCvNAovzMUJ"), string("gJAxpgcCgYudUfqvyNrOuNFuRgAmNbAjwMPLOCQgxtcOiqqqWgBjfBWfYYoaAaQZuOTAYlWwmyoRmjbNKImetmadOXzcQrqlGbgrgxenoYpRnObvaPwoHbxlmZHAvHWrkDYpPSlnJkDSOFuMQgqzHXsEIWnanbcsIzBLCndmNXftxzMRTyHNTa"), true, -210474.37748002834);
    this->OxyCCiBIB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wEibxHQCjNcka
{
public:
    double RFjegknrmjErjE;
    double AHCFCLtNL;
    double HHKqIbbfjf;

    wEibxHQCjNcka();
protected:
    string wxgdvdokDW;
    bool pvCNHHrMTEFxeD;
    bool eFvCYIYkIfGmiag;
    bool rQNSpzDkT;
    int jKCedmPOpUawcKmg;

    void eeSreHJAy(string owWAeAqSwIdfe, double Avoga, string JLVAw);
    int lqmqhqUlTwXYQkm();
private:
    int KpEMjaEAdUvXr;
    string SmiovCMGscxcF;
    string cquQtZbX;
    string dFhxuhvbRrE;
    int TbWwOTmA;

    double tBiaxSjAFUBdux();
    string zBLegNEmoLTb(bool EwYirUkqDzOVx, string wdVywUuFoMKEDmBy);
    string bkSgosLKskrs(int NQZRkXcUFJwblb, bool EsquRZC);
    int LDjqh(bool hknVTzVduE, int KqvZLybTLwptQH, bool jfkOER);
};

void wEibxHQCjNcka::eeSreHJAy(string owWAeAqSwIdfe, double Avoga, string JLVAw)
{
    double jVgHNxBwRGYUtq = 227964.81868368972;
    int qsMEQsN = -591669715;
    bool NKsXXtyID = true;
    bool bffTUIsOeDjFGbDO = false;
    int bIcSXdNdrS = 2064520882;
    bool qZxjIAUSHDMnYW = true;
}

int wEibxHQCjNcka::lqmqhqUlTwXYQkm()
{
    double wkUldXrdKGiKhgXE = 999285.372207149;
    int QVZBd = -1082748720;
    string ifSOEFxWDqoU = string("xHKWVzrUWEBzGuMGoZBzgPPiqBoKXLbeZAssXtrgRhNtFmfElZrfxGflNPmAeKeMZiPsSYaAKXbGEmSfexhSdxDzmzQHGqsIKwNFoUTquYkGrIJEnMHiOIsfAuHlWutTusUNcmgTdNLYfxQUgifyIFANwqyEuNBFgzPbSeHBBDXdEjWDhhxFXOCerlTgpcw");
    string TQiguHmw = string("aiTXLEImSyUaZXAilpjgEmgFWlaxtYudvMszGBAfitvuqZfnUROFWEu");
    int qevisxrHjOVp = -1984888313;
    bool ijXACkteWfkTORb = false;
    string bSzJrsTzhbLAwcD = string("QiryfJwxXAEnvMeNtAVMhXHjjWWRsAAFtUMwUDGUoeAcKpGTvXExXxiOppMcCCPYRKIpcvcscWgYFIIbHUCxfieHsPxAQpYkNFOqNSuuwEMVKoudBihhmdpExaSHmizxxKATJhsBIleEdmIAUGvFbtcgzRzZK");
    double jtghiCZ = 102232.324886202;
    bool GlzzWlAHauFSh = true;

    if (ijXACkteWfkTORb == true) {
        for (int uZTacLHvWB = 1906782285; uZTacLHvWB > 0; uZTacLHvWB--) {
            jtghiCZ += wkUldXrdKGiKhgXE;
            ijXACkteWfkTORb = GlzzWlAHauFSh;
        }
    }

    for (int FKKaCehdlKXVUR = 1301295297; FKKaCehdlKXVUR > 0; FKKaCehdlKXVUR--) {
        ifSOEFxWDqoU = bSzJrsTzhbLAwcD;
    }

    for (int LhwzEgvr = 915258891; LhwzEgvr > 0; LhwzEgvr--) {
        ifSOEFxWDqoU += TQiguHmw;
        ifSOEFxWDqoU = ifSOEFxWDqoU;
        ifSOEFxWDqoU = TQiguHmw;
    }

    for (int QfQnqIJIOO = 434932953; QfQnqIJIOO > 0; QfQnqIJIOO--) {
        TQiguHmw = ifSOEFxWDqoU;
    }

    for (int qCbmukNoTbhPie = 1512673001; qCbmukNoTbhPie > 0; qCbmukNoTbhPie--) {
        continue;
    }

    return qevisxrHjOVp;
}

double wEibxHQCjNcka::tBiaxSjAFUBdux()
{
    int HghDawbA = 1292547948;
    double NYeChbTlKQ = -684103.1612504545;
    string yGrIAL = string("LsOETwEyFNflYvCGlVCKzwqcDYJeESdMbhnDhlgghOoZhuuZSdtMWYkHwbhYDYzAvSXHbSyKuTEHbeptLQMSkZO");
    double ffbUyISfN = -864239.215239182;
    double LuErGhvbxB = -831030.2536642128;
    double qkeAUpO = 386698.4329485741;
    int NhwOqjsQvWbM = -54946334;
    double IYPADHKoilwrl = 655954.5417533914;

    return IYPADHKoilwrl;
}

string wEibxHQCjNcka::zBLegNEmoLTb(bool EwYirUkqDzOVx, string wdVywUuFoMKEDmBy)
{
    int IEbNEz = -2139223521;
    bool MaOXTSYcCAHBmc = true;
    int tOJxPp = 834959890;
    string tHpCIKEN = string("EIXTLPCmMrqRshGNhGdnXvMOYrcbmOHfrjwRdeAVmIiqPeTXDPYRaUHJtfkerXTEoVuZcqOHRUqSOVkQVRlxmAbhCELUdTMUBnduHBymyjDryxrqvkmVu");

    for (int mjJqQBOjTlJNZrih = 2063025981; mjJqQBOjTlJNZrih > 0; mjJqQBOjTlJNZrih--) {
        EwYirUkqDzOVx = EwYirUkqDzOVx;
        IEbNEz -= tOJxPp;
        wdVywUuFoMKEDmBy = tHpCIKEN;
    }

    for (int hqvPzMWmuuQ = 135657120; hqvPzMWmuuQ > 0; hqvPzMWmuuQ--) {
        tHpCIKEN = wdVywUuFoMKEDmBy;
        wdVywUuFoMKEDmBy += tHpCIKEN;
    }

    for (int rmWpbFYgGebIYfy = 320892926; rmWpbFYgGebIYfy > 0; rmWpbFYgGebIYfy--) {
        MaOXTSYcCAHBmc = ! EwYirUkqDzOVx;
        tHpCIKEN = wdVywUuFoMKEDmBy;
    }

    if (tOJxPp >= 834959890) {
        for (int dfDxpuSPtRacDA = 839280892; dfDxpuSPtRacDA > 0; dfDxpuSPtRacDA--) {
            EwYirUkqDzOVx = MaOXTSYcCAHBmc;
        }
    }

    if (wdVywUuFoMKEDmBy <= string("EIXTLPCmMrqRshGNhGdnXvMOYrcbmOHfrjwRdeAVmIiqPeTXDPYRaUHJtfkerXTEoVuZcqOHRUqSOVkQVRlxmAbhCELUdTMUBnduHBymyjDryxrqvkmVu")) {
        for (int ESonW = 1058847015; ESonW > 0; ESonW--) {
            tOJxPp -= tOJxPp;
        }
    }

    return tHpCIKEN;
}

string wEibxHQCjNcka::bkSgosLKskrs(int NQZRkXcUFJwblb, bool EsquRZC)
{
    string pmDOpNyCgUIRza = string("SQlTVtUsEMxsninivmGRctwgHqNtZhBLCjsuryrcnVYMKEMABwLcuUaEmBVYTUryaxtFYYxuyqJSUudEVUuApWUGflYqUVgJsqjLeSWGVcaQIVrLFbefMDfFQwArqzIsHKlBoxXAZrFqvxEYgEreKlU");
    string DPheU = string("yWgnUfZHcItIpsFtggSywsOQMaCfrgJfEUWGYVdNeFCrwFPShsWpMMNJfiJbvTTTvYmhOpCMwzBIUPGPHMUnThXEZzbhpNsZZgczNfFqDAQkKB");
    string rSrSCNdyP = string("sZFJbnPcOFQkwyMNbyxmkkIVKLzrtu");
    string EWBIIBRUPpXbVrPC = string("Epx");

    if (EWBIIBRUPpXbVrPC < string("sZFJbnPcOFQkwyMNbyxmkkIVKLzrtu")) {
        for (int SaJFLSMu = 1280334940; SaJFLSMu > 0; SaJFLSMu--) {
            pmDOpNyCgUIRza += DPheU;
        }
    }

    if (rSrSCNdyP > string("SQlTVtUsEMxsninivmGRctwgHqNtZhBLCjsuryrcnVYMKEMABwLcuUaEmBVYTUryaxtFYYxuyqJSUudEVUuApWUGflYqUVgJsqjLeSWGVcaQIVrLFbefMDfFQwArqzIsHKlBoxXAZrFqvxEYgEreKlU")) {
        for (int XnzLmkFFRKxFVC = 90971294; XnzLmkFFRKxFVC > 0; XnzLmkFFRKxFVC--) {
            EWBIIBRUPpXbVrPC += DPheU;
            DPheU += EWBIIBRUPpXbVrPC;
        }
    }

    return EWBIIBRUPpXbVrPC;
}

int wEibxHQCjNcka::LDjqh(bool hknVTzVduE, int KqvZLybTLwptQH, bool jfkOER)
{
    bool sEoUvKeMKWJCSpc = false;
    string vWJcV = string("amZUmgtybaVMNYZFkJscnkvZQAkpcEdriOUyTRDUfJNEEsavAzqkTXsGUGZoFGODtZGxMpruJbdioSIdOIdkSljnTXFmndlwwodghPcPrBDelqMoWCnjbYVJWMrmqrUeIppMpMKzvHkqsTZXcHxYImbgjimlGeQsObnbLdWbRxsAlbOZ");
    int RxeoMhB = -1523798799;
    double bnCUVrYrmlJq = 9768.76544964073;
    string ygqGr = string("xWoLhXxGxmlbBwQWoSqZTzCyZRvLnYWHsYUKLXpXglcopgVUAjkLDCfTtAqPLNXqgGXdaSQEKmccmaaeySCfqQcNvTMZHmwAXkraKGaoRqEQXHGiDIBTNEdafjGeczxChaRTyNVUxBddptxxabhYczlPAAPZpwkBCSGnxGifZ");

    for (int PcolnUO = 652913893; PcolnUO > 0; PcolnUO--) {
        continue;
    }

    for (int icjRVGgWdYpU = 783062247; icjRVGgWdYpU > 0; icjRVGgWdYpU--) {
        KqvZLybTLwptQH *= RxeoMhB;
        ygqGr = ygqGr;
    }

    if (hknVTzVduE == true) {
        for (int ewAyNO = 1973025804; ewAyNO > 0; ewAyNO--) {
            hknVTzVduE = jfkOER;
            jfkOER = ! hknVTzVduE;
            jfkOER = hknVTzVduE;
        }
    }

    if (KqvZLybTLwptQH == -610039618) {
        for (int mSrDCocdYcJCd = 1041381860; mSrDCocdYcJCd > 0; mSrDCocdYcJCd--) {
            continue;
        }
    }

    for (int ZbzbiquZD = 415342701; ZbzbiquZD > 0; ZbzbiquZD--) {
        jfkOER = sEoUvKeMKWJCSpc;
        RxeoMhB = KqvZLybTLwptQH;
        RxeoMhB = RxeoMhB;
        ygqGr += ygqGr;
    }

    return RxeoMhB;
}

wEibxHQCjNcka::wEibxHQCjNcka()
{
    this->eeSreHJAy(string("tUjYzHHRUTwxZoKoUkHadUBikBIaiovCVYQBXawdJJkyKrcBIPqunxqHVtiMYsZjtcYdXUKDVlNImoMJqLbwTPaNfDRfMkYxqFVImBlOarHeRrWRNnRPDSJk"), 183910.0550802611, string("loVfEYAVMmHkuGuPKNsoFvtmjyLWLXhPeeZALmNSLAOQhKQtzIXKBEFikmaCTbweEyBOiOwYONbXrNNNsHjkriqROpbYJHYzJoQILvMspyRnCiRtVmzG"));
    this->lqmqhqUlTwXYQkm();
    this->tBiaxSjAFUBdux();
    this->zBLegNEmoLTb(true, string("ygLxTcRqoOKjvCxgUXGBhdalAJetALjjCWDnlCAsnaSdFwrJzCvneXaiUWJgBvSJGoinGLpVjDYMkBcUDtjybEMmZEyrIQQJEqkHOBxGqFJumEOULUhDVUgBWWtBKkQVTqNmVViqrsUwKIPGcWzswQMBCwxCgBdTAzKgDbxqPaeavsDgGREsuQiCqq"));
    this->bkSgosLKskrs(-1594412073, false);
    this->LDjqh(true, -610039618, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NfvDTGdFcP
{
public:
    string MFuxMktALwKoOt;
    double WlcRKfaDfxJfqbsH;
    int qqXTOhI;
    int qiXLQPBLuRqltZC;
    double IFWunzQODiRAR;
    double heCRoS;

    NfvDTGdFcP();
    bool QwzImjWjiLFha(int PgRKVKZjWfZayhMa, string pgqYHwugf, bool GMiEFQ);
    int MgDshxJeZR();
    bool ECHQwlCTtvu(double jzYYRfYFObV, string NBsBoVHLX, string flNDprlZcWNwDs);
    int GClCwPWZFJn(double urEwDDeREAmMkfx, int pdMEucFHnhf, string NmigtBMpwneceEHy, double eSYmGsS);
protected:
    string fSEPx;
    double zaOlbYiVIuiBK;
    string Lfxxi;
    double mxUoFSnWPKTa;
    bool bYKGsu;
    bool bJkHzqCqvH;

    string aSRfKVhgBuNaE(int FJpKFKehXndN, string iPfKjxTDXI, string wRnJAbDgkXvd);
    bool chwlncEPiDU(int WVTcgebAXiCkSA);
private:
    int DyQmlWsjVgNd;

    void PLqAFYFEM(int NeWOalogBPgGXc, double aZAbRMCbIrK, double SAogQaok, bool sMCLj, string uXAMIiyGLEMI);
    int vApcmu(double eVXNpAn, double IFIryHUFBRXM, bool wJbtV);
    string QjlAocPAlgDcDRKb(double ddWEGlrx, int HpdkvcRidd, bool YliKTgPY, int BQiDygasiqIA);
};

bool NfvDTGdFcP::QwzImjWjiLFha(int PgRKVKZjWfZayhMa, string pgqYHwugf, bool GMiEFQ)
{
    double dMtxdJgWH = 538186.3293852935;
    string LDOGlk = string("iiZKHFxnQiAJeoMbMVepurYwPtjqmqFoqAfELBqVSwVxEdHvUOvfijMXXoPmQyvbafOuaxUtjxQJhjDRhSNIrzppSxtPoMpOowgLUpZzVunBpmYRDCJAMZMzfswDVyqJIZMajphbh");

    return GMiEFQ;
}

int NfvDTGdFcP::MgDshxJeZR()
{
    int iCCRWwQMdcYBeOi = -749452933;
    string WcVmNcLDXbJaJ = string("FIYmZGfkvqNTITTSHEmZYzmidZBNGI");
    double XeSFiqFzm = -669763.5635386022;
    int NpMVxUYlPGfQI = 1188752044;
    bool TYeSUduEgI = false;
    bool pnohJnMe = false;
    double QhjudSXrCEguYq = 721575.9748787733;
    string xGWTRqbWrTlU = string("COyK");
    double QPTLDkabQmid = 120479.03815767945;

    return NpMVxUYlPGfQI;
}

bool NfvDTGdFcP::ECHQwlCTtvu(double jzYYRfYFObV, string NBsBoVHLX, string flNDprlZcWNwDs)
{
    int CuQwiDShYz = -1468090506;
    string wpBmvvjOzwev = string("sTtsbuUmNcpxCgDvhTNBRTcUllMXDANfwSsMtZrAVFpSNQXpjCeSMScaOHlwENUUhAzgAESRRazdILksaXqrHjIbGkGJqmJekqqxaBBzdoDinwkdqbfUwsBdXVDJomPEQpQXqqELklPgYHraqHNsyhooejdyauEVdOUMiLKVlrSyzUkvfFbHIcVNjEAXOBkmdHZtNYEbYZFFIYjPnDRzhVDKXmmZuSsQTcJhuBfQKmoFV");
    bool rDIzTCzdEhqBkMY = true;
    string Tsfyyojjr = string("NGlCPnoFgwccpkVxks");
    double qdvMPRcCovaRJ = 188071.9216389631;
    bool xdjRlIMjTDDTLDk = true;

    if (qdvMPRcCovaRJ >= 188071.9216389631) {
        for (int vxNpxokA = 1441208030; vxNpxokA > 0; vxNpxokA--) {
            flNDprlZcWNwDs += flNDprlZcWNwDs;
            rDIzTCzdEhqBkMY = xdjRlIMjTDDTLDk;
            qdvMPRcCovaRJ += qdvMPRcCovaRJ;
            wpBmvvjOzwev += Tsfyyojjr;
        }
    }

    for (int eFnuGM = 1721944490; eFnuGM > 0; eFnuGM--) {
        continue;
    }

    for (int PwFsGtZyy = 42974223; PwFsGtZyy > 0; PwFsGtZyy--) {
        continue;
    }

    if (flNDprlZcWNwDs == string("NGlCPnoFgwccpkVxks")) {
        for (int MXkXCyiuZv = 1108952663; MXkXCyiuZv > 0; MXkXCyiuZv--) {
            jzYYRfYFObV = qdvMPRcCovaRJ;
            flNDprlZcWNwDs += wpBmvvjOzwev;
            rDIzTCzdEhqBkMY = rDIzTCzdEhqBkMY;
            NBsBoVHLX += NBsBoVHLX;
        }
    }

    for (int OwNdi = 762263246; OwNdi > 0; OwNdi--) {
        xdjRlIMjTDDTLDk = ! xdjRlIMjTDDTLDk;
        Tsfyyojjr += flNDprlZcWNwDs;
        wpBmvvjOzwev = NBsBoVHLX;
    }

    if (Tsfyyojjr > string("NUYwlCtNzBgYMsxpQUXJaWXolXEcHeVpoQmFKLhCAxZPYKUThxflhCKFZfUbrJVkxduuJxRxGxfLpBCQwQLurUbrxWvzHJFjByMumfiitZcMhERiLwtCMVKndVbZugJgIoiwCeWgFPnYlYYWQvbywXwlMlAFeEWaEpSRNAatPPqwOFCXVyFEhFaseupeZMQFSLIfuLevAUgzLdZuVerHjD")) {
        for (int mybcGqxyzgCBP = 818175658; mybcGqxyzgCBP > 0; mybcGqxyzgCBP--) {
            continue;
        }
    }

    for (int iluzXuUsDic = 1072130979; iluzXuUsDic > 0; iluzXuUsDic--) {
        qdvMPRcCovaRJ /= qdvMPRcCovaRJ;
        rDIzTCzdEhqBkMY = rDIzTCzdEhqBkMY;
    }

    for (int OsnRJrRSMCmtYZ = 1973413582; OsnRJrRSMCmtYZ > 0; OsnRJrRSMCmtYZ--) {
        continue;
    }

    return xdjRlIMjTDDTLDk;
}

int NfvDTGdFcP::GClCwPWZFJn(double urEwDDeREAmMkfx, int pdMEucFHnhf, string NmigtBMpwneceEHy, double eSYmGsS)
{
    bool UKeDmacCJJD = false;
    int ugJytBHjzNLljBL = 374753708;
    int wYCzdIk = 2030755629;
    double OBfNHtnGFHPqTxsJ = -803160.8701157446;
    int ajSMJKsnjkqwEuEd = 217638345;

    for (int odHrYlLU = 349295379; odHrYlLU > 0; odHrYlLU--) {
        ugJytBHjzNLljBL = ugJytBHjzNLljBL;
        OBfNHtnGFHPqTxsJ = eSYmGsS;
        NmigtBMpwneceEHy = NmigtBMpwneceEHy;
        eSYmGsS = eSYmGsS;
        wYCzdIk += wYCzdIk;
    }

    if (ugJytBHjzNLljBL > 374753708) {
        for (int lwrDW = 2036020621; lwrDW > 0; lwrDW--) {
            eSYmGsS /= urEwDDeREAmMkfx;
        }
    }

    return ajSMJKsnjkqwEuEd;
}

string NfvDTGdFcP::aSRfKVhgBuNaE(int FJpKFKehXndN, string iPfKjxTDXI, string wRnJAbDgkXvd)
{
    bool LQKPrIOMGEtU = false;
    int YoSQMqK = -792700328;
    string axjxQexE = string("RbcFzFjmJmwaGrgWfNURroYrCXQMMskSuXfWfnEHrynqXdUoVRtuIGGibZCIEjFRtPejBeSAtyvPtYnwXdnrCeWSgaImWwdmtAOJqDtwDWVl");
    string EzQWJWIcjse = string("LUhpwIzjbHmsIlkkWOyAqgbIByYLHXvhfEtKVSBDIwEwrUFnuzjDawEhgpmRiGdKmkzDGdQBRVtcFrOWauYODcsDPPmkbOxdmaHBbuCDrdBaiVfSykgpGfKVtmiQNDlNMnbLsuXuXnxQRTaFtGBJVGwsqb");
    int sJcyNpPGZU = 658378464;
    bool xYSawjYJtG = true;

    for (int yVgBnaLQ = 492707361; yVgBnaLQ > 0; yVgBnaLQ--) {
        LQKPrIOMGEtU = ! xYSawjYJtG;
        axjxQexE += EzQWJWIcjse;
    }

    return EzQWJWIcjse;
}

bool NfvDTGdFcP::chwlncEPiDU(int WVTcgebAXiCkSA)
{
    double BkIwPYCc = 74406.32376032676;
    string UeTcXJZKB = string("kJyjTTmkEgMkHDPGPWeQIFNRcLWqpZ");
    bool NhhuLrOtilZIWQld = false;
    double ExMIkgLytt = -122969.42516635195;
    bool gGlJULveNReo = false;
    int JMidiwMN = 889799535;
    string xgehBehEjS = string("HNCKaqouMIRLPSZhwzlDSkBJCTYQGWpRaaisYnCywzFLpYKcxSljpsOHCUQZvmQdmxlaaKfJAZXPYcFpDPIoGsaZvrfZtwSHLBDxuIViZtVEdxPsmAXUWayoWzgLfVthThKvsDZjAx");
    double ePxRA = 875393.4330765109;
    double smMOCKVYRTHqHIpd = -972040.6803855302;

    return gGlJULveNReo;
}

void NfvDTGdFcP::PLqAFYFEM(int NeWOalogBPgGXc, double aZAbRMCbIrK, double SAogQaok, bool sMCLj, string uXAMIiyGLEMI)
{
    bool lCApO = false;
    double yHZqQCkFqaWDPU = 947589.9384273532;
    double kttjJ = -772691.8751449025;

    for (int wnmIUcHON = 137936167; wnmIUcHON > 0; wnmIUcHON--) {
        aZAbRMCbIrK += yHZqQCkFqaWDPU;
        lCApO = sMCLj;
        kttjJ -= yHZqQCkFqaWDPU;
        SAogQaok /= yHZqQCkFqaWDPU;
        aZAbRMCbIrK /= SAogQaok;
    }

    if (aZAbRMCbIrK > -772691.8751449025) {
        for (int dxDpOPMrv = 369854009; dxDpOPMrv > 0; dxDpOPMrv--) {
            lCApO = ! sMCLj;
            kttjJ += SAogQaok;
        }
    }

    for (int KZFnEuPUXhWXZy = 2009590596; KZFnEuPUXhWXZy > 0; KZFnEuPUXhWXZy--) {
        aZAbRMCbIrK *= kttjJ;
        aZAbRMCbIrK -= yHZqQCkFqaWDPU;
        aZAbRMCbIrK /= yHZqQCkFqaWDPU;
    }

    for (int BFFQFpaVnuaR = 1342315746; BFFQFpaVnuaR > 0; BFFQFpaVnuaR--) {
        yHZqQCkFqaWDPU /= yHZqQCkFqaWDPU;
        SAogQaok *= yHZqQCkFqaWDPU;
    }

    for (int XeSFBxHJEqkYU = 1826562634; XeSFBxHJEqkYU > 0; XeSFBxHJEqkYU--) {
        yHZqQCkFqaWDPU /= aZAbRMCbIrK;
        SAogQaok /= SAogQaok;
        kttjJ -= kttjJ;
        NeWOalogBPgGXc *= NeWOalogBPgGXc;
        kttjJ = kttjJ;
    }
}

int NfvDTGdFcP::vApcmu(double eVXNpAn, double IFIryHUFBRXM, bool wJbtV)
{
    double DJRyTHoCL = 140496.37611338752;
    bool EKgMAZhlmUZ = true;

    if (EKgMAZhlmUZ != true) {
        for (int UZrXgJFjkKc = 363150383; UZrXgJFjkKc > 0; UZrXgJFjkKc--) {
            eVXNpAn += DJRyTHoCL;
        }
    }

    if (IFIryHUFBRXM != 593124.7056965294) {
        for (int kdnYOiMCUKx = 985487322; kdnYOiMCUKx > 0; kdnYOiMCUKx--) {
            EKgMAZhlmUZ = EKgMAZhlmUZ;
            IFIryHUFBRXM -= IFIryHUFBRXM;
            wJbtV = ! EKgMAZhlmUZ;
            DJRyTHoCL /= DJRyTHoCL;
        }
    }

    if (IFIryHUFBRXM >= 140496.37611338752) {
        for (int PixkQdS = 1660998772; PixkQdS > 0; PixkQdS--) {
            EKgMAZhlmUZ = EKgMAZhlmUZ;
            EKgMAZhlmUZ = wJbtV;
            DJRyTHoCL = eVXNpAn;
            DJRyTHoCL /= IFIryHUFBRXM;
            EKgMAZhlmUZ = ! wJbtV;
        }
    }

    return 753515969;
}

string NfvDTGdFcP::QjlAocPAlgDcDRKb(double ddWEGlrx, int HpdkvcRidd, bool YliKTgPY, int BQiDygasiqIA)
{
    int VJhSaI = -539382552;
    string fRShJR = string("NyRXDkPRTOuoondGoksblQKhpjkEkJIHqusEyuAzZoujZqdNiLvSAfwrwfQUMxj");

    if (HpdkvcRidd == -539382552) {
        for (int KRlHApfBlYIQ = 1548532222; KRlHApfBlYIQ > 0; KRlHApfBlYIQ--) {
            continue;
        }
    }

    for (int xeOsgkDvrRSp = 1703397819; xeOsgkDvrRSp > 0; xeOsgkDvrRSp--) {
        BQiDygasiqIA -= BQiDygasiqIA;
    }

    for (int AzraT = 251599850; AzraT > 0; AzraT--) {
        HpdkvcRidd += VJhSaI;
    }

    if (BQiDygasiqIA >= -539382552) {
        for (int DnpUsGkzWmXW = 1132480907; DnpUsGkzWmXW > 0; DnpUsGkzWmXW--) {
            BQiDygasiqIA += BQiDygasiqIA;
            HpdkvcRidd /= VJhSaI;
        }
    }

    for (int Rzprg = 540892860; Rzprg > 0; Rzprg--) {
        YliKTgPY = ! YliKTgPY;
        ddWEGlrx *= ddWEGlrx;
    }

    return fRShJR;
}

NfvDTGdFcP::NfvDTGdFcP()
{
    this->QwzImjWjiLFha(-616273379, string("cqjoonBgreMmsCObckGuNaiGUMnyOybZGLWGcGtEFZspTmEsjJXiOTHyhVcnHuD"), false);
    this->MgDshxJeZR();
    this->ECHQwlCTtvu(-170979.04784389478, string("BWhTGzmPNgPrgQFcTTAnvdfhRjMZIaHnjRKULfeow"), string("NUYwlCtNzBgYMsxpQUXJaWXolXEcHeVpoQmFKLhCAxZPYKUThxflhCKFZfUbrJVkxduuJxRxGxfLpBCQwQLurUbrxWvzHJFjByMumfiitZcMhERiLwtCMVKndVbZugJgIoiwCeWgFPnYlYYWQvbywXwlMlAFeEWaEpSRNAatPPqwOFCXVyFEhFaseupeZMQFSLIfuLevAUgzLdZuVerHjD"));
    this->GClCwPWZFJn(-937023.4787818932, 1770271368, string("vesScbmqzAvsDmEPqQxDzpHrn"), -336428.04593574273);
    this->aSRfKVhgBuNaE(706060446, string("lhHHebElrgCCrimdbkfZtTrHtMxiPjdjWQdgCHsSeBaUVqLBNUaXMkJYoxTFsPDlBkcIZiuIxuwuQfIlOStxgYqwHyujLVnNmGXQgbTamyivvfNneRXXdTEoYxZtfspkyFWUlXypWDHJqQzRrZ"), string("ZbDEuutxpzmhyINDAsrNwLwZRsiOoTEoIgNbDVKcPsqpAkrHoMSGkvpfSi"));
    this->chwlncEPiDU(-789533887);
    this->PLqAFYFEM(-1142485755, -869434.108340032, -749796.085935402, false, string("juuBnQINFlWwBbMFYtmCbMwsJceafmTRVJGtzzcbAjufdFNOoNDHImyzropdbmxcmrqXemICvrMLIgzEkyBJdsuUEbJDimAMPaxKjrCtTLUVYjybsQLNhEudreSVMJwMeHrnLowWgfFKDSLgpFTSZoBtuKcUPNxkCsqejnTBvTFYTChzyLBBIyZXDJFOQvmRxTGsriJrktCSfZ"));
    this->vApcmu(593124.7056965294, -767980.1790882945, false);
    this->QjlAocPAlgDcDRKb(72450.59770278749, -838237098, true, -1397039473);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wLNksOUh
{
public:
    string QtQikMAQzgWpFH;
    int zlRQfwfTnDodZU;
    string tzrRuwHArumfoz;
    double xFkdcq;
    bool QCGYjm;

    wLNksOUh();
    double ENixWbH(string SWADLiKjMgbvfV, bool sccwmBbiyPAScEc, bool MDTBbNkP, bool XqTFRfPhYqysLaBK);
    string DcFWelJQKHc(bool ZIgionk);
    void hnuSl(bool MerCYAEqr, bool AvjjwVGON, bool msOUwkrn, double CwoqZhuUOBnhsc, double ufRaw);
    void eBlRIiNpGgM(double NJAFfF, int mubYnqBFPkxGLUsd, int OVNOtw);
    void gYUXxwdedCMjUzDH(double MToGTYHzPEVK, int zZBnUowk, double ILDDArzIonYSwN);
    int SJrWRaulvlJ(double nRMZPYnz, double oSfnbzgoxOd, string VVvsWpkZdO, bool WlgZacBLHDidQXhE);
    void eJtRvIsmsZvtFYrc(double RHzqaqbOBJuPe, bool KCCXFxusksU);
    void iStQgdhWssJSzH(bool cBKJilj, int vuYmvETijnAQQg);
protected:
    bool XdVSmv;
    int XoYNNWBpThME;
    double aYXRpvW;
    int lRlXVgvqpNQSifK;
    double jWRGMdKoiitDz;
    string ftTdPyqDjUIRObk;

    bool MkJVWbdsS(string uuYsPoPdQX);
    int eRxcHPlyyc(string rGPxumBHyP);
private:
    double JKDpuwrjYQezv;
    bool JIFqOSCWvyX;
    string ZJqgQot;

    string nwFxmmATEtuuL(bool FnfJQDtjKKSJGvd, string mYaTO, string bkgJqTpf, string gbJDrzSvLTeboj, string bHOiSJeDgFTHhuVw);
};

double wLNksOUh::ENixWbH(string SWADLiKjMgbvfV, bool sccwmBbiyPAScEc, bool MDTBbNkP, bool XqTFRfPhYqysLaBK)
{
    int JcgKfaFw = 479265374;
    double vDfwAAAejVSVmX = -664795.1361921206;
    string rCJiU = string("xAPmDHJA");
    int CSuzDay = -1337552174;
    string GgnVjRDJRSd = string("DfvhPtRaGPxHzRICvBstxoKLUuGSPmygjYQZmlRTAYtNtSflYnVwQLOMJZkbKNuwNdTWBRFrASXhmjFzNfsSBInznlSCORawdOQQqHhwkygLSmDTKHbegSemFyxChaNlrwDznJoBFsBWoYBCTBBnzPAVRDABlYIYNSeP");

    for (int lfdNcD = 206199405; lfdNcD > 0; lfdNcD--) {
        sccwmBbiyPAScEc = ! XqTFRfPhYqysLaBK;
    }

    for (int kCXBavyyCvqrAHh = 1135926098; kCXBavyyCvqrAHh > 0; kCXBavyyCvqrAHh--) {
        sccwmBbiyPAScEc = ! XqTFRfPhYqysLaBK;
    }

    if (CSuzDay <= -1337552174) {
        for (int roUbV = 155393079; roUbV > 0; roUbV--) {
            rCJiU = SWADLiKjMgbvfV;
            MDTBbNkP = MDTBbNkP;
            JcgKfaFw *= CSuzDay;
            GgnVjRDJRSd = rCJiU;
            JcgKfaFw = JcgKfaFw;
        }
    }

    for (int RQuoFfiCSjk = 1587753252; RQuoFfiCSjk > 0; RQuoFfiCSjk--) {
        JcgKfaFw += CSuzDay;
    }

    return vDfwAAAejVSVmX;
}

string wLNksOUh::DcFWelJQKHc(bool ZIgionk)
{
    double BarQwkEHV = -833731.4924663337;
    double VMhCukaX = -15647.734073430796;
    int ZptviBrcDlNM = -705595978;
    bool eiOgjWiodd = true;
    bool nwwdsfYOhDqo = true;
    int SjRmZg = 2010666929;
    int HgLQXxlwokn = 1538862100;
    string UVwNsDsSBEb = string("BbaIBQUCnqqXtKEaXIoCnzNWVqLaqWRzIIYyGJewQpIbptbgLTcsHkrPzWUInnQyQTCCmbWxqTjuNwlZAmSWIkrJKZlTuIvcCXqMxQhpSxwBJYcEJoNYIIjljXxSdIwNNxvkjKePcSOZrJPWqaONzccbQOnaEoicjlzDxJijxRfau");

    return UVwNsDsSBEb;
}

void wLNksOUh::hnuSl(bool MerCYAEqr, bool AvjjwVGON, bool msOUwkrn, double CwoqZhuUOBnhsc, double ufRaw)
{
    int tHYvzlzJQoc = -1746742095;
    double GmZzgSPwIj = 794631.1684354666;

    if (CwoqZhuUOBnhsc > 369905.3398478103) {
        for (int pnknRKHZEnOU = 77191129; pnknRKHZEnOU > 0; pnknRKHZEnOU--) {
            MerCYAEqr = ! MerCYAEqr;
            AvjjwVGON = MerCYAEqr;
            msOUwkrn = ! MerCYAEqr;
            CwoqZhuUOBnhsc /= CwoqZhuUOBnhsc;
        }
    }

    if (AvjjwVGON == true) {
        for (int bWIrAU = 1324180169; bWIrAU > 0; bWIrAU--) {
            MerCYAEqr = ! AvjjwVGON;
            GmZzgSPwIj = ufRaw;
            CwoqZhuUOBnhsc *= ufRaw;
        }
    }
}

void wLNksOUh::eBlRIiNpGgM(double NJAFfF, int mubYnqBFPkxGLUsd, int OVNOtw)
{
    double XVQkoDULOp = 240561.33482702464;
    bool EYwWTrbNajfulc = false;
    bool LHNsHUdXy = true;

    for (int HxKDyPJoR = 1223516373; HxKDyPJoR > 0; HxKDyPJoR--) {
        continue;
    }
}

void wLNksOUh::gYUXxwdedCMjUzDH(double MToGTYHzPEVK, int zZBnUowk, double ILDDArzIonYSwN)
{
    int EszFBKm = -402701855;

    for (int ZmuVOu = 1301279496; ZmuVOu > 0; ZmuVOu--) {
        zZBnUowk *= zZBnUowk;
        zZBnUowk *= EszFBKm;
        zZBnUowk *= zZBnUowk;
        MToGTYHzPEVK /= ILDDArzIonYSwN;
        MToGTYHzPEVK = MToGTYHzPEVK;
        MToGTYHzPEVK /= ILDDArzIonYSwN;
        EszFBKm /= zZBnUowk;
    }

    if (ILDDArzIonYSwN >= 255536.07341776186) {
        for (int yttCA = 430856242; yttCA > 0; yttCA--) {
            ILDDArzIonYSwN += ILDDArzIonYSwN;
            MToGTYHzPEVK -= MToGTYHzPEVK;
            ILDDArzIonYSwN = MToGTYHzPEVK;
            EszFBKm += zZBnUowk;
            EszFBKm = EszFBKm;
        }
    }
}

int wLNksOUh::SJrWRaulvlJ(double nRMZPYnz, double oSfnbzgoxOd, string VVvsWpkZdO, bool WlgZacBLHDidQXhE)
{
    int FnIHkcF = -2109351561;
    string KmEDZw = string("CpUiZuMUaWtQsJENRWKrHVlYJhJUvmyNDpIgJINcOFAehsseivTWmWJGtQLwFQUlYvAPXqEPZxqUDIyRcBTjGZrZNbSxOyioPhNnGDsFxBlaRnfuCmxNggRYqLlCjOeyYKIpxNVVmpLsJiTfxlqWFtqvRbN");
    int DsIrNgCDZpo = -2079517767;
    double HGTZHgnxPnpf = 103457.70173971886;
    double FCrxcbvvE = -424767.4801790278;
    bool kBLUfNlxwQwvD = false;
    int XSaate = 417323251;
    double mwiwKeMNfqJeHyU = 631522.4876660011;
    string SWnGaA = string("quRmmTnDvhvRkmmVwEgOuwDHmIFQYCyayhcogLdHmBWgsKvvxPfHBpucXHQApfRykpVjOdcwXHEBOjZmOrAKUjjC");

    for (int WguGXsFjbYhQWzf = 9185969; WguGXsFjbYhQWzf > 0; WguGXsFjbYhQWzf--) {
        XSaate *= FnIHkcF;
        FCrxcbvvE /= HGTZHgnxPnpf;
    }

    for (int aiFfoQikdD = 565381938; aiFfoQikdD > 0; aiFfoQikdD--) {
        oSfnbzgoxOd += oSfnbzgoxOd;
        DsIrNgCDZpo = DsIrNgCDZpo;
        FCrxcbvvE += oSfnbzgoxOd;
    }

    for (int hvJpJi = 2041619829; hvJpJi > 0; hvJpJi--) {
        oSfnbzgoxOd /= nRMZPYnz;
        KmEDZw += VVvsWpkZdO;
        KmEDZw += KmEDZw;
        mwiwKeMNfqJeHyU /= oSfnbzgoxOd;
    }

    if (FCrxcbvvE >= 103457.70173971886) {
        for (int wIQcqCVpmQ = 858895860; wIQcqCVpmQ > 0; wIQcqCVpmQ--) {
            continue;
        }
    }

    if (oSfnbzgoxOd > -424767.4801790278) {
        for (int wxoWXjNRGgYFN = 775074351; wxoWXjNRGgYFN > 0; wxoWXjNRGgYFN--) {
            VVvsWpkZdO = VVvsWpkZdO;
        }
    }

    for (int EQXelQ = 444797161; EQXelQ > 0; EQXelQ--) {
        VVvsWpkZdO += VVvsWpkZdO;
        FCrxcbvvE = oSfnbzgoxOd;
        FnIHkcF = FnIHkcF;
    }

    return XSaate;
}

void wLNksOUh::eJtRvIsmsZvtFYrc(double RHzqaqbOBJuPe, bool KCCXFxusksU)
{
    int TyGeQCeRlbXX = -1205412405;
    bool urIlmMk = true;
    bool LFmeCGxrQgMurdI = false;
    bool yTVxm = true;
    bool NNDKbYTIKLN = false;
    int dtfqlHJ = 1277085445;
    int UsJIYlLtHDrfy = -1736839941;
    string sAtNLRmE = string("pvDNiNNSwLzjxJbUJZfpYhXSAGxrsxTdHQhINykzZqHnuiaAIHgmgMyakNgElqnMRfsGLAtGKgyfFKoBtZdqctjCTyEsDGWhxYaNklvYDwkEinBpAqKmhFMwKLfbhwAEjkNJLimUWjxWsxDTEtGTFhzfaYXyHoGjdmKaapdFXtYFJBotvMGfGiysMOVqYuStZIXeDTFJpOuJvqJfRnn");

    if (UsJIYlLtHDrfy != 1277085445) {
        for (int UQnGXJokMoRSYU = 1082725133; UQnGXJokMoRSYU > 0; UQnGXJokMoRSYU--) {
            NNDKbYTIKLN = yTVxm;
        }
    }

    if (KCCXFxusksU == true) {
        for (int OGZKzVrYnYlM = 319375920; OGZKzVrYnYlM > 0; OGZKzVrYnYlM--) {
            yTVxm = ! KCCXFxusksU;
            UsJIYlLtHDrfy -= UsJIYlLtHDrfy;
            yTVxm = yTVxm;
        }
    }

    for (int fHGSTBpIZpqt = 1049177445; fHGSTBpIZpqt > 0; fHGSTBpIZpqt--) {
        continue;
    }

    for (int RQCCSLdZ = 43578282; RQCCSLdZ > 0; RQCCSLdZ--) {
        LFmeCGxrQgMurdI = yTVxm;
        NNDKbYTIKLN = KCCXFxusksU;
    }

    for (int eirpSPuDTzV = 1271247626; eirpSPuDTzV > 0; eirpSPuDTzV--) {
        continue;
    }

    for (int eMAKdhqqsWPkXBGG = 293099509; eMAKdhqqsWPkXBGG > 0; eMAKdhqqsWPkXBGG--) {
        continue;
    }
}

void wLNksOUh::iStQgdhWssJSzH(bool cBKJilj, int vuYmvETijnAQQg)
{
    bool shcHEeo = false;
    bool zQVkhsAufbKWL = true;
    bool NSMVrcpc = false;
    int cEoeTp = 1311275543;
    bool UzPkyUmDhzOlQmW = true;
    bool RpwNI = false;
    int moJUCpIIzDTjkou = 1125249971;
    string nmklh = string("gkAoRJDOFsWuuiWEjFMuHfvihLjslgwYtATHnuvklQmH");

    for (int mgGyWP = 1940145389; mgGyWP > 0; mgGyWP--) {
        UzPkyUmDhzOlQmW = shcHEeo;
    }

    if (RpwNI == true) {
        for (int xPEhVblt = 43442701; xPEhVblt > 0; xPEhVblt--) {
            cBKJilj = cBKJilj;
        }
    }
}

bool wLNksOUh::MkJVWbdsS(string uuYsPoPdQX)
{
    bool hoOsMFlzLEB = false;
    bool gdTqLqgrYhFNa = false;
    string zuyKzTjSst = string("lhuXvSVIhprllLAnGgxdrEdtvOmkOMANslVlQlPGQdoCMkugHsduloSNIcGWOGieyLTKjsgQzyVLvdLLGOgpzCXcJDJsyibLHnxYurseJRfdwJwJgtumiXzSrFQVBoDCKxRnxxJDFdvVubLgXrzHTVcsnotlNREQxIxHBYYaeic");
    int xSGEEXk = 1452769117;
    string XNGgRTNbXLfiN = string("WpqYDTiOapxFKCXLtmdOtAccsnDmidcAeKWIeIjKkHkGBopkSSOxPqzwWqrxfJVkxMuvFVYZYppQhBREcwmtYgBkAYlViEAoLbOgyewUYucAoNPGXUHytEzICuGxtYC");
    double qfWOozkwbuEKm = 485097.9460402502;
    int oRMqHkjtAmbFxej = 1260395501;
    bool NkRstUtWqEU = true;
    double WjZmItsAODC = -672835.4840478215;
    int nNxCkOdHfHYc = 477157578;

    for (int fplFXx = 433298609; fplFXx > 0; fplFXx--) {
        nNxCkOdHfHYc -= nNxCkOdHfHYc;
    }

    for (int QEzaVVCnQq = 1224430352; QEzaVVCnQq > 0; QEzaVVCnQq--) {
        continue;
    }

    if (NkRstUtWqEU != false) {
        for (int oRgJPudKtqu = 573597614; oRgJPudKtqu > 0; oRgJPudKtqu--) {
            uuYsPoPdQX += uuYsPoPdQX;
            uuYsPoPdQX += zuyKzTjSst;
        }
    }

    return NkRstUtWqEU;
}

int wLNksOUh::eRxcHPlyyc(string rGPxumBHyP)
{
    string fYyzS = string("tvMidQdBOzBlPvIVoEiNgBhBuEjZNjnvMDleHaDEMjCRNAbxIunbYKcRmzucHxJAuBuBhRvxIpFXVTtXgYwaMinUCOfIDZcFwSCnHJQtKSwPosNuOrHTUCKVaZQOLbMerjVdheThFeUmMXXglmhMeeGMcKaNAPuCbGvCIGHOmFZpiMsUtpQtBjgimFsaHhJTcYtcGRfrLlgUqhFQLvYn");
    int JtpoMKFeSdj = -884072273;
    string VuQeKheqlEVXNwPD = string("ZqSLlxpmWoEOHexmqEhmAXIKIBNAzDBFpZkmYEthzioNFNoiukggvIAtDADiKbnkskCZYFIxMLrIAqkqhPgmNFOSKPeETLycUHPSJHMoHiWXfGcMAyBEmCNZXiDCZrcEykGtwTLKscBqAFxAnHVdQwXUkjegNaeucFudfsGwFjzhOkBxuaMiWMqOAYpHBKVWRbhEdKIdwOnVzzoJqKYwISYUNXgkYLQvzZQEziOYmLkYbYsviNyI");
    string OFQwF = string("GzWiYAvFYpZYdWCucdtwzUzoChWxOcBguHCnjEZnsAzxnYDFzLUwyezWXzHShZyFCpFLuYFuiZibvGWdDZlKCXsTzXJipYed");

    if (fYyzS == string("ZqSLlxpmWoEOHexmqEhmAXIKIBNAzDBFpZkmYEthzioNFNoiukggvIAtDADiKbnkskCZYFIxMLrIAqkqhPgmNFOSKPeETLycUHPSJHMoHiWXfGcMAyBEmCNZXiDCZrcEykGtwTLKscBqAFxAnHVdQwXUkjegNaeucFudfsGwFjzhOkBxuaMiWMqOAYpHBKVWRbhEdKIdwOnVzzoJqKYwISYUNXgkYLQvzZQEziOYmLkYbYsviNyI")) {
        for (int CLACO = 1874803009; CLACO > 0; CLACO--) {
            VuQeKheqlEVXNwPD = fYyzS;
            fYyzS += fYyzS;
            fYyzS = rGPxumBHyP;
            fYyzS = fYyzS;
            rGPxumBHyP += rGPxumBHyP;
            fYyzS += fYyzS;
        }
    }

    if (rGPxumBHyP != string("ZqSLlxpmWoEOHexmqEhmAXIKIBNAzDBFpZkmYEthzioNFNoiukggvIAtDADiKbnkskCZYFIxMLrIAqkqhPgmNFOSKPeETLycUHPSJHMoHiWXfGcMAyBEmCNZXiDCZrcEykGtwTLKscBqAFxAnHVdQwXUkjegNaeucFudfsGwFjzhOkBxuaMiWMqOAYpHBKVWRbhEdKIdwOnVzzoJqKYwISYUNXgkYLQvzZQEziOYmLkYbYsviNyI")) {
        for (int qKqfN = 2057848295; qKqfN > 0; qKqfN--) {
            OFQwF = rGPxumBHyP;
            VuQeKheqlEVXNwPD += rGPxumBHyP;
            rGPxumBHyP += rGPxumBHyP;
            VuQeKheqlEVXNwPD = OFQwF;
            rGPxumBHyP = VuQeKheqlEVXNwPD;
            rGPxumBHyP = fYyzS;
        }
    }

    return JtpoMKFeSdj;
}

string wLNksOUh::nwFxmmATEtuuL(bool FnfJQDtjKKSJGvd, string mYaTO, string bkgJqTpf, string gbJDrzSvLTeboj, string bHOiSJeDgFTHhuVw)
{
    string QCOXHSUxfoPtIW = string("lGxzLDVrGHSyxuqgH");
    bool CAgSpJxLcCCeD = true;

    for (int QFOSK = 362495769; QFOSK > 0; QFOSK--) {
        bkgJqTpf += bkgJqTpf;
    }

    if (FnfJQDtjKKSJGvd == true) {
        for (int ZRbBhjdu = 690756553; ZRbBhjdu > 0; ZRbBhjdu--) {
            gbJDrzSvLTeboj += bHOiSJeDgFTHhuVw;
            gbJDrzSvLTeboj += bkgJqTpf;
            bkgJqTpf += bHOiSJeDgFTHhuVw;
            gbJDrzSvLTeboj += mYaTO;
        }
    }

    if (CAgSpJxLcCCeD != false) {
        for (int yUiZUYtXHOIn = 343837686; yUiZUYtXHOIn > 0; yUiZUYtXHOIn--) {
            gbJDrzSvLTeboj += bHOiSJeDgFTHhuVw;
        }
    }

    if (bHOiSJeDgFTHhuVw < string("gORFZBhjgNTLmuXXBrSfHXwBgJZefdzFcknLjFvbFFKGP")) {
        for (int JLghbbpWcMh = 1853749851; JLghbbpWcMh > 0; JLghbbpWcMh--) {
            bHOiSJeDgFTHhuVw = bkgJqTpf;
            CAgSpJxLcCCeD = FnfJQDtjKKSJGvd;
        }
    }

    for (int CGtIysMff = 132100397; CGtIysMff > 0; CGtIysMff--) {
        bkgJqTpf += gbJDrzSvLTeboj;
        mYaTO += bHOiSJeDgFTHhuVw;
        bHOiSJeDgFTHhuVw += bkgJqTpf;
        mYaTO = bHOiSJeDgFTHhuVw;
    }

    return QCOXHSUxfoPtIW;
}

wLNksOUh::wLNksOUh()
{
    this->ENixWbH(string("AbQtTltJHYxUoFlOqyCZJbaOImgzZsBJlYQMXUuHGxStXTYVQRJWVzMDzUWmFBBnbzwgOLQksKIzENNfcIXXvBTkKzQxQKVeLpfXcgTuHfMSLbBNTbtjTJdgBMBfSzmlBuHvdocxSJTKfNobTDzKoJENppghLMMzacEDLgxnnimadaPWnXeKmhMlpkikxAfDHtOybjUrAKdWJfIyWLcTDOZnDpMNBRecCc"), true, false, true);
    this->DcFWelJQKHc(true);
    this->hnuSl(true, true, true, -1021833.3500053185, 369905.3398478103);
    this->eBlRIiNpGgM(982730.6167780195, -907953662, 315283963);
    this->gYUXxwdedCMjUzDH(145596.57046331684, -994043308, 255536.07341776186);
    this->SJrWRaulvlJ(-227316.04054734198, -948357.9286874147, string("EvMJSxbEgEQUWFIQYqRVXjQhfHdGNpyGrTlaDUcnKZLlDOGjbWttOZiIcfqqJgEuFCMYNzcyQjensXuaLdSEJhEsKXscAmZzIAVYHQupMbOxywwAcRxFDeGXmSejPZIhKuUoGlDgxXtvQPqsVsOCyIzUbljZZVaTwKyZxPgPeUxECCokYeuHcfgTyhNkaXyTTygXARewFVhSiLizfkHvzgGwBIYGVpzUyMsQMk"), true);
    this->eJtRvIsmsZvtFYrc(291203.57561214763, true);
    this->iStQgdhWssJSzH(true, -686379205);
    this->MkJVWbdsS(string("TBH"));
    this->eRxcHPlyyc(string("qOxWYTxKOHtIMusfRPVHtMRNzcFfolhGYpylgDaoSXEPnnEACXqbBFzAZUMjcxytWnmIhqKyfFXMmrOwGwxgFePMaQMcd"));
    this->nwFxmmATEtuuL(false, string("gORFZBhjgNTLmuXXBrSfHXwBgJZefdzFcknLjFvbFFKGP"), string("quvLScT"), string("SWZmYAEqgzTUUXlsIOaVZQwFGxfhrvgvgUnTkHmDGzOnjiAohSydOkqBSCjWhPGWVRbRzRJrXPjDFSMwqoFWsDMToKGyEjbwwDQUXHAKtUEViCBfcsIyjmMFHEDxouHciQyRFVanRlPjokAVIdwhUOaXdStovmXI"), string("FNsJCvAoPhTGYCkgvkxytYrkhibCPXbmZxkayphKPntZeYurglBWVhXselOGVtDKDHDTKQZWAWJrIEAGIULAgAQlwAwqsamzGzHsxzyWuzWQmPMPArcfSuIKoNIzfUAbiUdbuocoiEXBaJjBSCaudPCymCRZxNUZXuwKGqwZpyZWCyunlezQkweFVMbnZcgkmcSOzhYOlZooDRLfhhahBprIosVYfbRmtWFNeaW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QcrVXpVicEBl
{
public:
    string vXJrxgeX;
    int BCCKpXTdarWHWdBV;

    QcrVXpVicEBl();
    double uTwCdjOJKhXVBF();
protected:
    string IaoLAz;
    int pQHnHbR;

    bool CkgAaKSgujxZiNeZ(int meEHEthHTrv, int dJKqAQEKpT, int WExuJoUtgMiOTJtn);
private:
    int dcCmKQqgBqrQbHc;
    bool iThmQkOdazEH;

    string LUkrcb();
    double LsNaoTLTnahbPWq(bool SEOuRsUntVImCCqH, int qfExMUTOLaD, int IKkaMkRvsKykwUc, int BtJIRA);
    string wDvFAzSXszzW(string KsnjtpPN, bool BkXZIKj);
    void CPPeZvRbWI(string DFeybJAmH, bool NkvBgzQA);
    void yXpxNbPQ(bool qUndSUpNmVlvrrKW, bool nThWlZ, string eWGLBpud);
};

double QcrVXpVicEBl::uTwCdjOJKhXVBF()
{
    int mstiuYNizQsn = 504930266;
    bool vbnQsjhkb = false;
    bool HAdMnkLISECeId = false;
    string vEgOBSp = string("QIYSjnhDsRizcQUEOJgUYiTOMnVWesUuMCioMKcEkyUVmquYNmiorcKnoZICCjbjWzXBthlRPbdLG");
    double MRKwiypPPNPSJT = 79343.17761602625;
    string EFfmpAKEjO = string("NEQHtaqZNQAnrAdykGLgWGDKCJFHRBnsucHDBK");

    for (int oRjGFlpQmjKJo = 892825332; oRjGFlpQmjKJo > 0; oRjGFlpQmjKJo--) {
        vbnQsjhkb = ! vbnQsjhkb;
        MRKwiypPPNPSJT -= MRKwiypPPNPSJT;
    }

    for (int bEsuDirL = 1804194941; bEsuDirL > 0; bEsuDirL--) {
        continue;
    }

    for (int yGESnpue = 1023854725; yGESnpue > 0; yGESnpue--) {
        vEgOBSp = EFfmpAKEjO;
        EFfmpAKEjO += EFfmpAKEjO;
    }

    return MRKwiypPPNPSJT;
}

bool QcrVXpVicEBl::CkgAaKSgujxZiNeZ(int meEHEthHTrv, int dJKqAQEKpT, int WExuJoUtgMiOTJtn)
{
    string Zfunrj = string("dCcMHQJBDXDfCrMAYHuiGihPrXIHQIiZjatDnLoTrGbsJbVCrUlivBrlytmfxpERMQlgabDTVqSbjEVeaxEKAMSCtFakJmnlUZUhqNZFRLjoMzTNcwgEXxxwTKtQneTnreasyfcxdeBlNStAh");
    int jfEDvTnhExwUnZ = 2062648612;
    double dToRXjYXfj = -46530.44387173031;
    string LnWXpKxevry = string("CfadCEOzGeEtZNISsLQaeilBzLDiLtyCkoCUgHBlrYUIsgaIaqnqkKLNDavPVTChIHDTHEvXInPoBxmiUXbvLpzQFSxpUMUtwPrQ");
    double zlpAp = -112880.13657937829;
    bool hsakRicP = true;
    string gJHzGtBevFKlF = string("ynSWbTHenAETXqpHeSfbIeXinaCyvZWtuAqdzjTKmgYeMKYbIalUJMVYRcvaVWfLORKuzfnIXgcgbuEOiJGuRcmtyILYcTlpHTmHlitANYMTwr");
    string marsBzuFK = string("sIWRdjhwVNYTARvPCEcBMvSsETrNzFNdrHInoryfvDTSZrBXsaWcvi");
    double gdnFYMTU = -975190.426761911;
    int nWvqjGThHCVJsRB = -2100160293;

    for (int dGdnyRShmw = 328089294; dGdnyRShmw > 0; dGdnyRShmw--) {
        dToRXjYXfj -= gdnFYMTU;
    }

    return hsakRicP;
}

string QcrVXpVicEBl::LUkrcb()
{
    double UrGxg = 534711.6122860574;
    double NmYgEgOcFpvQmOLb = 56846.38560425586;
    double BGznfiC = -52843.54967822181;
    string QTnJixJs = string("NieLoObykaHpvVBqXBHfEZEgkdGuhwOKGRJVGKDhqrxjzpdfXxwrmPezXSiKYDPIprmQYuqtbDPWFWaMjWejMjcFFVErorcmX");
    string jPRbAEpZRTNTKm = string("bbtKYgFxWEDnexVUAWOCNFxhgzZIZjsnPELOxaywkFsFeOywJvvRHNBKdTBwLojpkXsJONoliMaUctRQqPeyhDMZuKTBUSdunnZKicFfPgGHPViIfSreaLJYZdmqduCYylmNVXyoigWwcuAepTJDElnxisUQFiibgGeYmseUPkvDWrXgxrVaJijbVEizCAAGvXMEpUurWTMoiypCpmimioMHKrXlRMnYArHbx");

    for (int knRiIBlRsvVm = 575355312; knRiIBlRsvVm > 0; knRiIBlRsvVm--) {
        BGznfiC -= UrGxg;
    }

    if (jPRbAEpZRTNTKm <= string("bbtKYgFxWEDnexVUAWOCNFxhgzZIZjsnPELOxaywkFsFeOywJvvRHNBKdTBwLojpkXsJONoliMaUctRQqPeyhDMZuKTBUSdunnZKicFfPgGHPViIfSreaLJYZdmqduCYylmNVXyoigWwcuAepTJDElnxisUQFiibgGeYmseUPkvDWrXgxrVaJijbVEizCAAGvXMEpUurWTMoiypCpmimioMHKrXlRMnYArHbx")) {
        for (int lPcqjLpUbCWlQUTt = 824320393; lPcqjLpUbCWlQUTt > 0; lPcqjLpUbCWlQUTt--) {
            NmYgEgOcFpvQmOLb /= UrGxg;
            UrGxg -= BGznfiC;
            QTnJixJs = jPRbAEpZRTNTKm;
            UrGxg -= UrGxg;
            jPRbAEpZRTNTKm = jPRbAEpZRTNTKm;
            NmYgEgOcFpvQmOLb -= BGznfiC;
            BGznfiC -= BGznfiC;
        }
    }

    if (NmYgEgOcFpvQmOLb == -52843.54967822181) {
        for (int vbeHcsWpK = 1043519686; vbeHcsWpK > 0; vbeHcsWpK--) {
            NmYgEgOcFpvQmOLb = UrGxg;
            UrGxg = BGznfiC;
            BGznfiC = BGznfiC;
        }
    }

    for (int MzwrBcV = 107511888; MzwrBcV > 0; MzwrBcV--) {
        QTnJixJs += QTnJixJs;
        UrGxg /= NmYgEgOcFpvQmOLb;
        BGznfiC += NmYgEgOcFpvQmOLb;
    }

    return jPRbAEpZRTNTKm;
}

double QcrVXpVicEBl::LsNaoTLTnahbPWq(bool SEOuRsUntVImCCqH, int qfExMUTOLaD, int IKkaMkRvsKykwUc, int BtJIRA)
{
    string qxDZfAEQjVTRT = string("cybwHISBaYbTREZkDitOowFzNOysACTsyKlSRxKSqoYQUATXCFwldsuqGDBjvkpwbjFSzvngGaIhXUMIQnDLNJHJmXvaqWkjjSycYmgDYDBmVhdgTVfRPSqmkBIQjvxqLTgiWexhqFsMlEYbIMyUeNnJxYqagpWzIzfvaQEQqKinlViGAg");
    double WiJtWZ = 729656.3531909264;
    int OuCXrd = 747263383;
    int FNPFaomS = 2091168622;
    bool mCsVj = false;
    string DTblsCEYsMgVhrW = string("XUJaemdWfherOSYLfoIiiSckjRCWOEVzzYFFilckQQsBYrpeKzuSLfpknoXeXEcRfYIFiiZsrFhXazyhtXJWbniPedeFWbgtoOsdjdJtvetkhhmtRwWiGMvLpXWpzbgMhyLseetxnIRETfYfVZxqcVReotPt");
    string IbhQRjRQ = string("qLjhYmHTctcmSWyslUapvMBxWnfCzCqHFZyPfnlrmzHNvhIICVdHlitwmzUYaGsAwECMialMSdDMXxwKYQBGW");
    double mUjTyKPNpul = -231849.04708225452;

    if (qfExMUTOLaD <= 2091168622) {
        for (int FgJZWF = 1713563223; FgJZWF > 0; FgJZWF--) {
            continue;
        }
    }

    return mUjTyKPNpul;
}

string QcrVXpVicEBl::wDvFAzSXszzW(string KsnjtpPN, bool BkXZIKj)
{
    int kQKCYrkNl = -1882611348;
    double YEvQjhMMHux = 450153.06163509114;
    string HdZjnwkdJrVEPTxQ = string("NnYUQBwfzkbUWwzoKwpiYWzEHJyVvEmjXuFMMLM");

    for (int pRmSEsikzBQJ = 699659025; pRmSEsikzBQJ > 0; pRmSEsikzBQJ--) {
        HdZjnwkdJrVEPTxQ += HdZjnwkdJrVEPTxQ;
    }

    for (int pLkyqMqSDvz = 2087855389; pLkyqMqSDvz > 0; pLkyqMqSDvz--) {
        continue;
    }

    if (kQKCYrkNl != -1882611348) {
        for (int KwSZx = 1328856178; KwSZx > 0; KwSZx--) {
            KsnjtpPN = HdZjnwkdJrVEPTxQ;
            HdZjnwkdJrVEPTxQ = KsnjtpPN;
            HdZjnwkdJrVEPTxQ += HdZjnwkdJrVEPTxQ;
        }
    }

    return HdZjnwkdJrVEPTxQ;
}

void QcrVXpVicEBl::CPPeZvRbWI(string DFeybJAmH, bool NkvBgzQA)
{
    string VZGiiU = string("BHtEIPmYyuCXmhEDsPmizMNvxGdfOsKrhGGeNKoVgXdBtbKpHMntuQkytcSrYWdzZplqfKajyeRULCBexwExqGKbWtpAjZfMGPOHkqDwaplvELmmwsWDWeasSOoSxSqCTxihWuJRFubTUJnHMHiktOtxOZCTIWyIDkJZqjOvCJcnbywBPThIpUjcCwZisXNjLLDPBXWYLSkVlXtUJItVOOERmvwCw");
    string wpZutFa = string("eSvjHOOIxcasPJCZGcSxFemovJXGePehnLPXujcwoMUmaCVfYVBnCpuf");
    double AswLGiux = 113837.89916921905;

    if (VZGiiU >= string("eSvjHOOIxcasPJCZGcSxFemovJXGePehnLPXujcwoMUmaCVfYVBnCpuf")) {
        for (int WHqyhvaoJEQtgT = 1664214489; WHqyhvaoJEQtgT > 0; WHqyhvaoJEQtgT--) {
            VZGiiU += VZGiiU;
            wpZutFa = wpZutFa;
        }
    }

    if (wpZutFa <= string("BHtEIPmYyuCXmhEDsPmizMNvxGdfOsKrhGGeNKoVgXdBtbKpHMntuQkytcSrYWdzZplqfKajyeRULCBexwExqGKbWtpAjZfMGPOHkqDwaplvELmmwsWDWeasSOoSxSqCTxihWuJRFubTUJnHMHiktOtxOZCTIWyIDkJZqjOvCJcnbywBPThIpUjcCwZisXNjLLDPBXWYLSkVlXtUJItVOOERmvwCw")) {
        for (int OKuuSuVxJgJvfnO = 188315958; OKuuSuVxJgJvfnO > 0; OKuuSuVxJgJvfnO--) {
            AswLGiux += AswLGiux;
            DFeybJAmH += VZGiiU;
            VZGiiU = wpZutFa;
            DFeybJAmH += wpZutFa;
            AswLGiux += AswLGiux;
        }
    }

    for (int yvYvFWD = 2095412644; yvYvFWD > 0; yvYvFWD--) {
        VZGiiU = DFeybJAmH;
        VZGiiU += DFeybJAmH;
        wpZutFa = DFeybJAmH;
        wpZutFa += VZGiiU;
        wpZutFa += VZGiiU;
    }

    if (AswLGiux != 113837.89916921905) {
        for (int NqEgtfvWkOeQvoQ = 486018839; NqEgtfvWkOeQvoQ > 0; NqEgtfvWkOeQvoQ--) {
            continue;
        }
    }
}

void QcrVXpVicEBl::yXpxNbPQ(bool qUndSUpNmVlvrrKW, bool nThWlZ, string eWGLBpud)
{
    int thaaGaNIkYgDM = -1977052368;
    double lWgSTKNcN = -459294.5875602459;
    bool LpOKKj = true;
    int HgkIOOPqT = 1386213412;
    int tzABF = -989139634;

    if (tzABF < -1977052368) {
        for (int OqqCkZMcnaQMOoKJ = 164354914; OqqCkZMcnaQMOoKJ > 0; OqqCkZMcnaQMOoKJ--) {
            HgkIOOPqT += thaaGaNIkYgDM;
            qUndSUpNmVlvrrKW = nThWlZ;
            HgkIOOPqT /= HgkIOOPqT;
        }
    }
}

QcrVXpVicEBl::QcrVXpVicEBl()
{
    this->uTwCdjOJKhXVBF();
    this->CkgAaKSgujxZiNeZ(-1651456802, 1314193262, 1092388886);
    this->LUkrcb();
    this->LsNaoTLTnahbPWq(true, 977173623, 120583659, -964680480);
    this->wDvFAzSXszzW(string("UzoRyrSPjZkFHJvotGXnLJxhPvGxOiQfNhvyOIZrqGMYqfOyqKBbjMmAKFLcDVcvoGkwKWDmiYBndmGlbQSlpThQFeEYEZSbDQypQNTXBqijshhOisGlJnEpgDfUDnnWfXKTTkDlhqmLuruZPjkHEJHbrrjOwQFpYeGCdIprWzZztzhNvhvrTTcoWutnWeQAKnmrGJMWubOSGaEQpgvinKzVgibVGyMMRZ"), false);
    this->CPPeZvRbWI(string("CzDNTQwRVprdbrtsGQgthkWHegzbhBbtUGFNGzfSjmDftmOgjJEQUzZsPKHGlZdQGKHmlJgjLxEsOFPaUuDXMBkiPakQbIks"), true);
    this->yXpxNbPQ(true, true, string("rOwtDQQDRGquTHfyHGiTbOQHTJXRBIlyterccRixXVwcWehZomnBpOgStrspVbbIrdAsLIrYzVLvCpSDaYDbXAEYwaDyloQJieLxCziLqKsWBUrQaNviKZOBtXczHMeExMKTRohJPDng"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vtfGEBA
{
public:
    int pGBQw;
    double FFjWuHC;

    vtfGEBA();
    double Yggamg(double vInqGHgViVh, bool FNzUwarg);
protected:
    bool SWddV;
    bool dMxGoCFftbafVOuu;
    string PKGGPCwIhTwGW;
    string OECUk;

    string cYsUPxhhroEt(int QidKxzZle, string LMSvjLtYT, string jMdOWWiaiDgdW, string qWqXjGaaCYdxyOJY, int oTLndeTLSJcPdR);
    int utqOFTUSXNEhh(string npHoDAYUuoXjJN, double jWUDaRZTSkCJ);
    string UOgCZoHXlh();
    void STNRPGI();
    bool MhBOavxUFW(string iUaVqQZtXjE, string WLGEXKBlYushSm, string aVRkBBcfCQsR, int kghfuw, int XSgmLlhBQGiUoIN);
private:
    double WbakI;
    double XvaQKQ;
    string qoQbOI;

    void IhTpv(string dPiaAu, int SegErFNveHrlRL);
};

double vtfGEBA::Yggamg(double vInqGHgViVh, bool FNzUwarg)
{
    bool LEmcPlwYplpRF = true;
    int voJhDtLPVppuuyrY = -1188462897;
    bool CDRPbV = true;
    string ZnBaejLuSdI = string("KAekHUkNLzMFJxIFMivBoUgRnovaWCwcpWsvKZhLISKSkphtyWJFTXieqQRIeVQlLkEuJlsHfFjNHENmyvTfZYjytYxdteXRpRCaSrIjlisOPrifDMNadWBXiwOduaLJaOnZBqYBaPlSUSOAKRi");
    bool HqsSaRMPsqhXiDC = false;
    double PCdCGPwWT = -596661.8290411636;

    for (int aEPgwL = 228953686; aEPgwL > 0; aEPgwL--) {
        vInqGHgViVh *= vInqGHgViVh;
    }

    for (int VPJjcfpHQKwWjU = 1178445417; VPJjcfpHQKwWjU > 0; VPJjcfpHQKwWjU--) {
        CDRPbV = LEmcPlwYplpRF;
        voJhDtLPVppuuyrY = voJhDtLPVppuuyrY;
    }

    for (int mpVZHoL = 1207208100; mpVZHoL > 0; mpVZHoL--) {
        continue;
    }

    if (FNzUwarg == true) {
        for (int UyjZMln = 1810852344; UyjZMln > 0; UyjZMln--) {
            HqsSaRMPsqhXiDC = FNzUwarg;
        }
    }

    if (vInqGHgViVh <= -596661.8290411636) {
        for (int JtwAdvpWAZMLaYnz = 974428002; JtwAdvpWAZMLaYnz > 0; JtwAdvpWAZMLaYnz--) {
            CDRPbV = ! HqsSaRMPsqhXiDC;
            FNzUwarg = ! CDRPbV;
            FNzUwarg = ! LEmcPlwYplpRF;
            CDRPbV = ! CDRPbV;
            CDRPbV = ! LEmcPlwYplpRF;
        }
    }

    for (int gfewwyK = 1309660271; gfewwyK > 0; gfewwyK--) {
        PCdCGPwWT -= vInqGHgViVh;
    }

    return PCdCGPwWT;
}

string vtfGEBA::cYsUPxhhroEt(int QidKxzZle, string LMSvjLtYT, string jMdOWWiaiDgdW, string qWqXjGaaCYdxyOJY, int oTLndeTLSJcPdR)
{
    double iXgCFmQbWxbF = -340981.99814611697;
    int HgtgpbEjIcW = -1938286238;
    int LKlVwEmu = 770448572;
    string onlcW = string("klyHaPEiWtxxtcywznonUhpsrOOtAzHdAxnPgapMdOEEQYlFsEMpinpaVxSpNGfzrlhTBFxgOVyLIClPHLFUVkq");
    string uYOAxx = string("lwDpJiiYXzFcRMjDWHBloYwQLTSPUioEWhBHnLYnmLDFjUeMmrmQnhfcBYClmuLUdCEfRCqqfrpFvFSTfpcTTCrywjEorceoJIwXWQuCgMjgFEvpxvyxNUCFiQCWKPQsWNpugWfGUwLKCHVXvpdkyAVwQvgzxmPMRIIZZewFPfYkMHNaFzonWrYkuCIaz");
    double qczpPIaGAi = 654077.5071808894;
    double jEQPcC = 514511.5181980355;

    for (int pTsHFG = 441847450; pTsHFG > 0; pTsHFG--) {
        continue;
    }

    return uYOAxx;
}

int vtfGEBA::utqOFTUSXNEhh(string npHoDAYUuoXjJN, double jWUDaRZTSkCJ)
{
    double Obrpwfci = 266602.2852999248;
    double CgVAWEPU = 605371.5952399197;
    string hnnng = string("NjHfWYVqICpFKNPjbcGoBhhSNywMUEXdwHWydYZQRIaaawWPRsELlUCJvAUsAMvIzKTUKVgKktsCMlDHCSNgIrvCmSPovqYwTxEMLHmNlHITi");
    string orYvYTaUqcM = string("km");
    string GroNqkVzgsNqlILN = string("qwwZeeMoYMBsYDLPVEpCpEeUViAnXTvDarGAowmkMFlhCgsUdXhSFNBCStCvBuBkXxYmjOdipTtjKkEDFCIBuGizLnKNEtTTuvVlsQyeRibuuQKHPlkhpkCdgaisZwDMNOQjEZJBKlpCLSIKFVadBDXdLSIhXVAdavctwrXexNPmJINSJNKEAZxEOGtlwtThucrzwTnXexfCRMaXygEofnypnf");
    bool keVHp = false;

    for (int IDAnRJFJnIdjaEZl = 1692017743; IDAnRJFJnIdjaEZl > 0; IDAnRJFJnIdjaEZl--) {
        hnnng += GroNqkVzgsNqlILN;
    }

    for (int iKtJqZ = 997216883; iKtJqZ > 0; iKtJqZ--) {
        hnnng = orYvYTaUqcM;
        hnnng = GroNqkVzgsNqlILN;
    }

    for (int iHpXjEXbwLQ = 997507669; iHpXjEXbwLQ > 0; iHpXjEXbwLQ--) {
        npHoDAYUuoXjJN = GroNqkVzgsNqlILN;
    }

    return 2051949271;
}

string vtfGEBA::UOgCZoHXlh()
{
    int bPAhzCwJcXNelXjE = 745649767;
    double KurrIcHoXQrkN = -194114.85387106234;
    double RjMEoXWQo = 751616.6728616226;
    double qvtKZZUBpcYrIMYk = -489064.20653391286;
    bool gobExqozVVAuncHz = false;
    string mnEDXwlbaqhyxUhM = string("ssVcGlKjNKzQVssPPMAQbsLDqnMyjBQGdryhizFhKUNiKSHiLnTxDYVPGzopDGnfMpqXftsZarQlmhIbVQOmSvyWbVCtijSNcHSzHLjFQHaOCsDazotxNJsxJFNMYVWGFfQdqZeTBbMyRQlPJoeKbbxMWhFlPRpRNVWRftvhcNULuiEgpTUJXrGzlqbnPOXiFsbUbQOuwsCtVqVHixFAsjwKIwIvNydkDAUZKAlYipWBNluAOaVXnVHzaIUw");
    bool GPalohyk = true;
    string adxoqaEDsM = string("aeMgDSjzMvHMTyXCsnBYcOhkkjdecUbeQiRleEOVn");

    if (KurrIcHoXQrkN >= 751616.6728616226) {
        for (int EVEDDhZ = 1238721179; EVEDDhZ > 0; EVEDDhZ--) {
            adxoqaEDsM += adxoqaEDsM;
            GPalohyk = ! gobExqozVVAuncHz;
        }
    }

    return adxoqaEDsM;
}

void vtfGEBA::STNRPGI()
{
    double NSpJYPihfHAXfqmE = 937492.8075274825;
    bool SLDawvwluS = true;
    string RXVBv = string("vueaaRmxRgUWAEuBjlzPlJJJAxJEzyzuechjmRNgzAxpNixucCsMyVgYMbjSnxHaERaiSxATgQFIkVvhzHgIAkNZnNYOpQhpBivYtskcByBqzwuowZpNShmWaNAQZMxtJx");

    if (SLDawvwluS != true) {
        for (int pJgmiUIwgpRfzv = 1342055486; pJgmiUIwgpRfzv > 0; pJgmiUIwgpRfzv--) {
            NSpJYPihfHAXfqmE = NSpJYPihfHAXfqmE;
            RXVBv = RXVBv;
        }
    }

    if (NSpJYPihfHAXfqmE != 937492.8075274825) {
        for (int pujjrDaiQ = 1177976607; pujjrDaiQ > 0; pujjrDaiQ--) {
            continue;
        }
    }

    for (int NnwBLBM = 741853433; NnwBLBM > 0; NnwBLBM--) {
        NSpJYPihfHAXfqmE -= NSpJYPihfHAXfqmE;
        SLDawvwluS = ! SLDawvwluS;
    }

    for (int LkWerH = 1878759954; LkWerH > 0; LkWerH--) {
        RXVBv += RXVBv;
        SLDawvwluS = SLDawvwluS;
    }
}

bool vtfGEBA::MhBOavxUFW(string iUaVqQZtXjE, string WLGEXKBlYushSm, string aVRkBBcfCQsR, int kghfuw, int XSgmLlhBQGiUoIN)
{
    string XerdWvjHhCg = string("AzNRIiLLiMbWHswcOnhgVyVhkmtVPfrvDcEStZI");
    double kjoDEIm = 400848.93875444273;
    int zATfNP = -420800254;

    if (WLGEXKBlYushSm != string("yUAloNfTvRvuoFJncBKCXNxtdVlFjEYdiAQpHWLGtOAisCLNVNsBvmCKzqzymzVlHOaTkBFZoemmEUrQgwdWKKOLcmZUXDaaQaImvzEpRLRZsCZPwcJGeXWmWxKMyERemvIrrHJlrLBejWKQpqQgHAfqETpiFBGAIFHXmQUdsWvEJTIyxefMYfOKMyimRHoXVsYFMpjHgKWLUnkZMDcyDn")) {
        for (int MPijflpOia = 309694474; MPijflpOia > 0; MPijflpOia--) {
            XSgmLlhBQGiUoIN /= kghfuw;
            XSgmLlhBQGiUoIN = XSgmLlhBQGiUoIN;
            kghfuw += kghfuw;
            XerdWvjHhCg += WLGEXKBlYushSm;
        }
    }

    return false;
}

void vtfGEBA::IhTpv(string dPiaAu, int SegErFNveHrlRL)
{
    double QtGlyR = -28906.350800166783;

    for (int FUrxtUtysT = 1756506845; FUrxtUtysT > 0; FUrxtUtysT--) {
        continue;
    }
}

vtfGEBA::vtfGEBA()
{
    this->Yggamg(463970.4933370021, false);
    this->cYsUPxhhroEt(-1949919012, string("QYGnGlcartTFMkAFrQVvctOjwkVZMmYeJsUdBvI"), string("rkaSEbatOWvZbsbuMlLcEboOerZjqcngLYwaLCtLDhfqqDFQwUhGsACHEtgLlWrXFQWtebUfPefdLqunwOviSDJidJNKQjLkwXqBpOxWQevPUNsTJHSIaBzEzTrcAcWYVGYdMNzfCueywiRCA"), string("usHebcVNdmULQPDfncrjnTlzpluzQeYrWewnJfOwqJgzYgOMUBtcVujSTlAXOXTkpjGGJGPPSrWdbTcdgKbiAnsLGhunqjWSzngnlWCQtgfoheAFprdGSVmahffQoFRWDEbiixIgivCfCgFvzuvvHXKSxaBevgteejzGoFldtqFOQITCOnkVPHLpOOUlKdmnh"), 1978213678);
    this->utqOFTUSXNEhh(string("BPLBaxgTBqYNYCjTCoKvpyGqDXxCpFeQbogEDJWQPUVkvZAflopTJAsyLunJWXHUEWkYgwsJdkEPsaAUMBUdEzLbaRLNBOdiwnKUVnHCVxqV"), -712651.9362054919);
    this->UOgCZoHXlh();
    this->STNRPGI();
    this->MhBOavxUFW(string("miOKfDNPnseXzSzeasacgJtGMhxDtFTWrjPFpgdgVYxbLfUBSGHTtRywrTdhViLhSbeWGJlzthQlyYvZvKfmPLbxocNZyBwdUcfWzKFQLSVvthmvqrgAOKgeZdFIHshSCntijVmEdMwlUlOdwiLwmeLlcSCtAntSwTkAALbhTyVFw"), string("UfxzyoJgIXOstmCntoNHzIhyjBqOFeLlxIDbmERCjHAGEUlHZZDhbAWFNYupMNytEeAQwlXUIoogkTfbiYyKYVYecnjNyPeRlWAHfJuenBQCobFLcwZiGUGUQJLWjTynwvNlhzIIeFJqYQSvgFlpfspvRnDxkaBjkWxihCikmbKusugSDGkbJaSWxfsnYzOzQoxlLhOWWkbLCZMCNVRabTWYOHhqrAiifUBlBMbSb"), string("yUAloNfTvRvuoFJncBKCXNxtdVlFjEYdiAQpHWLGtOAisCLNVNsBvmCKzqzymzVlHOaTkBFZoemmEUrQgwdWKKOLcmZUXDaaQaImvzEpRLRZsCZPwcJGeXWmWxKMyERemvIrrHJlrLBejWKQpqQgHAfqETpiFBGAIFHXmQUdsWvEJTIyxefMYfOKMyimRHoXVsYFMpjHgKWLUnkZMDcyDn"), -2063023120, 1146426948);
    this->IhTpv(string("JeGZwpmljEKRSbCbakQnYoKMzklwmSIXxwyDBhJNFOFzSwxfJzqLsDEWPkMPuFPFZKoJkDDABDgLUiVzfQyUFLohLJqQzeYvcXXUCGpYpniftVKEyLNKvNIblGUhXkUNCNNiTnxRrFYbruIfwXtYepFbpLDaPn"), -792610134);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XAhFO
{
public:
    double juWsXKcdBEbbd;
    double LPfRyyBPxwgcCpUV;
    double iiRUyLF;

    XAhFO();
    bool ZKVisquMFLTVFpTK(string HcXRVhdtz, double dSgBfwfeTNzfv, int gzzYfaWUvHS);
    void ZrOaAlKcrtxcA(double dCcHi, string aADNPeHBSiTc, string swXuCwx, int nBjKR, double wCrvyhBCvpSh);
    double sKvJntSu();
    int mzMlDlPNebNcxTq(bool QELRKQjvGXindGe, int UJiSvLn);
    double FlOeUXVO(bool sEeUhyDjTlEv, string ahApFEwO, int sayqp);
protected:
    int BsRZazDCy;
    int BNKcPiyDFqYkJb;
    string ElbzQnpcGZZmKg;
    double pOhRG;

    string xGIulW(string UKOjqDLWuhXb, string NJlqlglOcuJZlvO, string kInqwxlMXQ);
    bool zbKvtuU();
private:
    int iwrbaBRkgMAf;
    int RSYpdvOoBKKv;
    double IlGRZMq;
    string slNfCKlFdp;
    int boEOpJbMd;

};

bool XAhFO::ZKVisquMFLTVFpTK(string HcXRVhdtz, double dSgBfwfeTNzfv, int gzzYfaWUvHS)
{
    int NpOFdHYJI = -169255177;
    double TjWqAgvVnxMCzn = -367540.7945444103;
    bool FPzzF = false;
    int rhMqSk = -1063311929;
    double ZAoekfFdbMJDygVk = -259809.86766080468;
    string LIMRFfVcYgRo = string("wvibpJkQASInecvmoLeEQkHgREXmYWWGXdMYaAzZpWfMPlbuZNmJLFxMGhlkxRRKFmTYkVQXDgbOpDacNorQWkuEhZwnzObYWVjRMqGhpjSrwTjbxuDbvotmZSyCdUxKcuBcYPx");
    string WcRKGUOyRAPFIHr = string("RxqyNftTZoIPBrbFbbXtExzlnhqkqQkapRXrRXKvzvPxMNubKwlRNjddbeweEzHVFjFAQNBGVhlVQIwnnlJIYVFXPBMXuHUPSqGDNBbQxWDqrCNNwZNpPCxYrMKPetSuXglvboibmCPqLRoxBHkXKlWxRuJItIzApiSSRnAbCiqbqpOWFrQESSucLxTZhJRmFTlmBdbHFFaIAyJpcAu");
    double kKDYFBWyTbU = -1001010.4668777754;
    double qGNnp = 995401.1653098277;

    for (int OraoIEwuxU = 220571442; OraoIEwuxU > 0; OraoIEwuxU--) {
        TjWqAgvVnxMCzn *= dSgBfwfeTNzfv;
        dSgBfwfeTNzfv += TjWqAgvVnxMCzn;
    }

    for (int XLfKGOysqwGji = 927153566; XLfKGOysqwGji > 0; XLfKGOysqwGji--) {
        continue;
    }

    for (int DyyEwff = 89401521; DyyEwff > 0; DyyEwff--) {
        gzzYfaWUvHS *= rhMqSk;
    }

    return FPzzF;
}

void XAhFO::ZrOaAlKcrtxcA(double dCcHi, string aADNPeHBSiTc, string swXuCwx, int nBjKR, double wCrvyhBCvpSh)
{
    bool tlkpeVwTpv = false;
    int NWtyOXzqlfTFRtS = -1986876811;
    double vRKGE = -1008608.4365890569;
    string FMdmlCIGemxL = string("aHutHpyHLdruAwiehHpzsNoBTQmroqgbAVCpCBWOgBuKelnZfDiSGHcRKJlCiSXJRVsPYmcBBtOGyeIRhqHMyGBCy");
    string JzfFPqfp = string("xODUezEGdibOerexKbiUOOnppBmmYiceRZXYIeEjAiHAIiTEYcDzXIqAxLGQpZPjYHQddUBNXNjpdRjVhfkyfuBcPAEXukLAZlggQfgSwoyoOmdxsFztZXjsqkqoDXKXzmzYlDBhHMxUVDCZlvtqGoENxBfjINAErUKqQHauOXRFphZfLT");

    for (int VcpsnTBbzJ = 2034026042; VcpsnTBbzJ > 0; VcpsnTBbzJ--) {
        continue;
    }

    for (int rvdwaBRzohNwk = 377171494; rvdwaBRzohNwk > 0; rvdwaBRzohNwk--) {
        vRKGE /= wCrvyhBCvpSh;
        tlkpeVwTpv = tlkpeVwTpv;
    }

    if (swXuCwx > string("pUxaxdVgFwJVWdnienCRHriKudSbMcNFWpzMhCTzkQBofUZJsobEFzkWWeFSBCxqVxfNZKsQrGcfZkYGyLiYIzYwiLojksgtifKlRlPZRmSFqbhJRXreRqRlGRmAZPpmKGvCHqbzRYLGBOYRvtxNMcAnLMhnzJdOQmbNXsGnJyDGXiZAznxyXqRWuDKzJuOMbElPYcrTvomlWczJicAZLTzfKaqjMGikPErbJkZzmgH")) {
        for (int jRrGUkYiUGphirBH = 750526022; jRrGUkYiUGphirBH > 0; jRrGUkYiUGphirBH--) {
            dCcHi /= vRKGE;
        }
    }

    for (int LIbfFf = 1667674646; LIbfFf > 0; LIbfFf--) {
        NWtyOXzqlfTFRtS /= NWtyOXzqlfTFRtS;
    }

    for (int okuXdOFHQ = 835761141; okuXdOFHQ > 0; okuXdOFHQ--) {
        continue;
    }
}

double XAhFO::sKvJntSu()
{
    bool PIPQLXxLiWcUlHZ = true;
    string HskiGegiQgDG = string("npL");
    int EwgnNBEafIN = 250120097;
    string iiOvvF = string("KdXdmfWLLdtisaQudCttcTqgjLXPUnlIdKkTeoFUfmojLlSbdZlpiIvMAKDyJjdVkYTZcrZKvOoyXbgNXQtmDrPhqn");
    double sylskJNTiKbI = -343189.42893668154;
    string XsmwEmAyH = string("UnsjrUdDQhdlxjJvqqiFAtxu");
    string ILEJImoVAJbWiw = string("fjZhrlmiFCMzvoYdWOIgxnLyMdInHoHEyVVDTmUhYwSfBQbKGTOHfpkGylrZmXNHXCVPhkIcEibtGVxyJBHknBHzMgXSAkfMaRnwFUGNSWzMMRlGJeKdrNgmAwyyvAnNkZxxxEYytUeniKuwUrYyLBQgptWltqIxATlOnxFBjLgVCer");
    string BeZLFfcKCdyu = string("livWKDWCUvTLMKNjQkAlZaxNuciSoXlyaraPAtOtdYJxGc");

    return sylskJNTiKbI;
}

int XAhFO::mzMlDlPNebNcxTq(bool QELRKQjvGXindGe, int UJiSvLn)
{
    string XEMBbFApAr = string("cNSzfYjWJLLyIJfVQZlQGuzAplPOoAPTrhhcdAMhRCQIbCOwrjbVlWxrFoFjqslRlqNuYEG");
    string gGgaMAdyWQb = string("JFFYWgQuPyKStjjQxNmALAiMKxXDPlYdAbGFFBLvODuCiGZkCqnsVzOrHnRmyqAqrJoIWFRLRueCAATQnPcjOWJOCsvSWoThoWnXMqvSBUdkdiTRYdBTZMkTDonQJmedFEnPsQmYrlRYNqwthyDNgwquFuMkYywCFNplqMRcaazOrFythmiMgecfYuiMvOXgWvWCCuWxA");
    string TCYpEBmrWg = string("dupzmlVesZvenUwAmFmB");
    string diMJFlMUoDfwHT = string("LEVaqINZOfNenXEfVuEyTIgcxXinysCEDnpRiOqonARMyOeDhqaHBPObCgVzAmWvPVCbnIxIumKbBoFbZjqCfFSWgWwSvhBgoqYggcsIRSHdqAZMMFvIFVWxSGwUMIjeJVBYSlcCKXCTCuzAxZWAbHYThgMMNioqfQOASZSWgPATszqEtABXDNnjnloaBPLkSwIRc");
    string dTTJFAVzFe = string("DXLnogUgMqiWsufMxFWUEufhLwmqzjlFKVPzXyIAPgQXBCboHqQpxrTpZxyXfrjTyDDjTOTeDcjMADbPboqmdpwAYaJCbLzgwoQOsaCiHmORrybyoygquQKhSfMQElMlSTMQWEivVswDUbIqnrdKBkyePYzdWfnuwMNtDvSPANToPZxLmZGgCwGMsWtq");
    double fdbLjPktFplYka = -109129.19056878405;

    if (gGgaMAdyWQb >= string("JFFYWgQuPyKStjjQxNmALAiMKxXDPlYdAbGFFBLvODuCiGZkCqnsVzOrHnRmyqAqrJoIWFRLRueCAATQnPcjOWJOCsvSWoThoWnXMqvSBUdkdiTRYdBTZMkTDonQJmedFEnPsQmYrlRYNqwthyDNgwquFuMkYywCFNplqMRcaazOrFythmiMgecfYuiMvOXgWvWCCuWxA")) {
        for (int lFqTZtpTzDSWrde = 527416061; lFqTZtpTzDSWrde > 0; lFqTZtpTzDSWrde--) {
            dTTJFAVzFe = TCYpEBmrWg;
            TCYpEBmrWg += TCYpEBmrWg;
            XEMBbFApAr += TCYpEBmrWg;
            gGgaMAdyWQb += XEMBbFApAr;
        }
    }

    if (XEMBbFApAr <= string("DXLnogUgMqiWsufMxFWUEufhLwmqzjlFKVPzXyIAPgQXBCboHqQpxrTpZxyXfrjTyDDjTOTeDcjMADbPboqmdpwAYaJCbLzgwoQOsaCiHmORrybyoygquQKhSfMQElMlSTMQWEivVswDUbIqnrdKBkyePYzdWfnuwMNtDvSPANToPZxLmZGgCwGMsWtq")) {
        for (int RtCrJh = 477321703; RtCrJh > 0; RtCrJh--) {
            diMJFlMUoDfwHT = XEMBbFApAr;
            TCYpEBmrWg += gGgaMAdyWQb;
        }
    }

    if (gGgaMAdyWQb != string("DXLnogUgMqiWsufMxFWUEufhLwmqzjlFKVPzXyIAPgQXBCboHqQpxrTpZxyXfrjTyDDjTOTeDcjMADbPboqmdpwAYaJCbLzgwoQOsaCiHmORrybyoygquQKhSfMQElMlSTMQWEivVswDUbIqnrdKBkyePYzdWfnuwMNtDvSPANToPZxLmZGgCwGMsWtq")) {
        for (int QSKVkjWQPfWOOp = 1344624241; QSKVkjWQPfWOOp > 0; QSKVkjWQPfWOOp--) {
            gGgaMAdyWQb = dTTJFAVzFe;
            XEMBbFApAr += dTTJFAVzFe;
            XEMBbFApAr += TCYpEBmrWg;
            XEMBbFApAr = diMJFlMUoDfwHT;
            XEMBbFApAr = TCYpEBmrWg;
        }
    }

    return UJiSvLn;
}

double XAhFO::FlOeUXVO(bool sEeUhyDjTlEv, string ahApFEwO, int sayqp)
{
    double wWXqYo = -1000084.5560843768;

    for (int cSAKMtWRnONXar = 841393267; cSAKMtWRnONXar > 0; cSAKMtWRnONXar--) {
        continue;
    }

    for (int igZmoFoi = 1178363930; igZmoFoi > 0; igZmoFoi--) {
        sayqp *= sayqp;
    }

    for (int LYOrMHCNMMLkeI = 1236529930; LYOrMHCNMMLkeI > 0; LYOrMHCNMMLkeI--) {
        wWXqYo *= wWXqYo;
    }

    for (int vuaPOOYXGdCcgWJ = 364314876; vuaPOOYXGdCcgWJ > 0; vuaPOOYXGdCcgWJ--) {
        continue;
    }

    return wWXqYo;
}

string XAhFO::xGIulW(string UKOjqDLWuhXb, string NJlqlglOcuJZlvO, string kInqwxlMXQ)
{
    int uKsTfM = 680347572;
    int ChxMfZXicMC = -652583400;
    bool GdrbhSRGmiejDbKh = true;
    string sYKKdLOVPNqIgU = string("KiffNtjIYHBtoQQQfiHsrUmyCfDstKIMswPhuCCYakGSVfuNdCHSmhwwclzKbTYEnFPuVlaLOMgJKiXaVNzrGUN");
    int qeRjsclGfTmmnli = 1283642779;

    for (int lUoDFKwLEe = 2132969065; lUoDFKwLEe > 0; lUoDFKwLEe--) {
        ChxMfZXicMC *= ChxMfZXicMC;
    }

    for (int JYFioUJiDbOLB = 1411361360; JYFioUJiDbOLB > 0; JYFioUJiDbOLB--) {
        sYKKdLOVPNqIgU += kInqwxlMXQ;
    }

    for (int UoGJF = 1537208514; UoGJF > 0; UoGJF--) {
        kInqwxlMXQ = kInqwxlMXQ;
        NJlqlglOcuJZlvO += sYKKdLOVPNqIgU;
        kInqwxlMXQ += NJlqlglOcuJZlvO;
    }

    return sYKKdLOVPNqIgU;
}

bool XAhFO::zbKvtuU()
{
    int gfRCTLJ = 1381498404;
    bool cubuvtaEmUXj = true;
    bool EOfYqJgzhe = true;
    bool JIJXCphqbzh = true;
    int aXqfA = -698550402;

    for (int qIQHzWUfBeA = 2130332674; qIQHzWUfBeA > 0; qIQHzWUfBeA--) {
        EOfYqJgzhe = cubuvtaEmUXj;
        EOfYqJgzhe = cubuvtaEmUXj;
    }

    return JIJXCphqbzh;
}

XAhFO::XAhFO()
{
    this->ZKVisquMFLTVFpTK(string("RApNysjioBOdyxuitDDCKCtRVxaplkscrJlOcEywmtwpZqIefgGMonhdEbsCrZwktdeToxTpqLZjDaTKfeBcHypQcBvwbQfvsLKanPzkARwKRnDbuo"), -11266.01807742459, -961595941);
    this->ZrOaAlKcrtxcA(-486736.0037659241, string("pUxaxdVgFwJVWdnienCRHriKudSbMcNFWpzMhCTzkQBofUZJsobEFzkWWeFSBCxqVxfNZKsQrGcfZkYGyLiYIzYwiLojksgtifKlRlPZRmSFqbhJRXreRqRlGRmAZPpmKGvCHqbzRYLGBOYRvtxNMcAnLMhnzJdOQmbNXsGnJyDGXiZAznxyXqRWuDKzJuOMbElPYcrTvomlWczJicAZLTzfKaqjMGikPErbJkZzmgH"), string("tLYyTYQgVjIIqhLHyWBtyPuTWbnrpqnVxGXzLngdJqzdFSklQhbVgNWRivlOJgPnZIgoGFGbOrOXVYvVcqFSQHZHZyCNaENUyTdfAgnnBeveFaTUZMgUoURexQGUoBsfLNkmpePKJEFsHnzHvHofvSoBWmICZBNCDroJuVFtY"), 1701913512, 596549.0587785692);
    this->sKvJntSu();
    this->mzMlDlPNebNcxTq(false, -578478716);
    this->FlOeUXVO(true, string("szRNDlCxmnIXLFnKveSDiWTrkrOGTdTJtXslMiqmfDfifEiEfZIFioOlWKAFkkcyJeDUVBNuXoCTilvelnwrEbFBhioVaukhPtSzqhjMXLxJtEkcaVxHNOlElCDBGIYCLUDDpMUprnkCJNKvzbLwFRqwXxSaaFuOxCQBNiJctFhPPrkIzslozCGevGsrXcjhUxiywqEhzARlgwVYrFNWBdYrAisgkaZfAVUhzcipSqkbJTSqBpGxSywD"), -1595155761);
    this->xGIulW(string("rjMLfWNhBYNHLYuAnFoEVORcwiJWPpxigboYblJvuYLKrcEppnUbJWwqVmbxwRGEoiFCoSGLJhJyetZvfomBodnyZfFJVhgfXnDeiGBjPXDHnaFLOXYLfJnJbIykpXEEyq"), string("JkvlwcYGDffAvMHDbbQRSCNlkUCxwWemGunDySuRqbmKdBmgRNwQUXvFcJPaYKOrYIwQTecrStLMLktRSsVmLCuckBhXBsaLAopfBphpFkiMQJJTudkoJvc"), string("xPUzfBNlRsTyJevUvpbwzFwLFrSUXntVcXUKRcJcwQcgydKfQRyOTdGVcBWupFlsggnsfifgqtPStzlvPtDNdRHSBubGnTqFSMuUOmsHxzMUlCXMfHHQZkJsYJgsJPSPYTGcciMCFOZcsoKkyRARtJlLABJotRrSmeOwNaXKaZHTQZTStSAXDEUUnsRmcdLZltsrGQlqJiSzLPwjUnKAzw"));
    this->zbKvtuU();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fadrz
{
public:
    int tiLkd;
    int xzBXNKBkhbQ;
    string rcgmF;
    bool eTBCN;
    double rCCxKMhCz;

    fadrz();
    bool qcIRRDzyQbZSye(string NCGEnmQiYzOse, int gKGnTaM, int eRlTXZJdpSACzpFY);
    string YGaitnCYkbSOlWln(int ZzvSMWKFAEMqDlO, string tggCHMPRgV, bool XfIAJnjjMTtYx);
    int rflWeDBrnvHUB(string KloGygEQ, int cKeZzfzsdVKU);
    string ILPYKrCJJZDyz(string nGrUFx, string ztqnbUgMunbKwBC, bool GnkXqLiJJEc, string oMMctZv);
    void tKnYfgHorrPNxkeZ();
    int tAvGDlSYZmFr();
    bool KcdXfyZupjzGEzy(double IHRKuREDiRB, double aGQYaElYKWn, bool HMzEzIQCQYfQ, double jMcbwn, string yGzDXnIkEntvFIl);
protected:
    int HzxwtwvUHjYGtL;

    int rRMYKNDjD(string whnHt, string kopaHfBwL);
    bool qmvQjbbxPeuubN(string qodUybfUN, string nYBgofemcXngn, bool toBaboNJpahlzGjP, double mAAhtD);
    void eHJcgcUsyJXhZ(double liYMb, string lcckUyyXVfzdcYQS, int onZUwaeFOc);
    bool hQhUKATUws(int iKyKLhPglfcoOM, string BSZZcYqi, int YwWEjNh, double IMKYgnEwKOfrLAa, double uUPMYzikjpcI);
    bool jlODNyRzbZIdhdA(bool HZDMPvgflOdSD, string aKwIeoHzd, string XkTjOOQpHAqKV);
    void WvUwCDKcyXDQU(string ReqFLYPSZspwTJ, double fvxuLNhgIPVDPVKs, double UyvmcCznfR, double CcZEmpBlJSA);
private:
    int GdyUmgwELR;
    string ZkjUfyeTAnDG;

    double FWbBT(string XeDALtDal, double MgpjnNCQZ, int ScyRV);
    double roGULYKGy(double vrwqiIrRwLCaWNF, bool qSvaIcnuwX, string AoPrU);
    double hONBeEEX();
    double ezWSMtl(bool HtLcANUQJe, double iDEwdWkaZTmXyxD, bool pgxdIxweNMePtnOV, bool fCipBlwrBasim, string sWtHk);
    string HcIiY(bool unesZgzdffPM);
};

bool fadrz::qcIRRDzyQbZSye(string NCGEnmQiYzOse, int gKGnTaM, int eRlTXZJdpSACzpFY)
{
    bool jNmPTqW = true;
    double AyYmHmaKRve = 339946.5298864385;
    string HpKlDUqdCvKM = string("RjhLVequImhekOetwyWQKAHYz");
    string CaWtwRWbiH = string("DwvKPOtkhMFbQFOzSGGgNDOOYBFjYbcsqDoSTqqKzncMaaGSjmJTpAfaSPkBShSZPeVunXVWYScacBrnhdkGYwfuJzefgw");
    bool CGQMZ = false;

    for (int EXRZrPHuIlIpx = 1510108867; EXRZrPHuIlIpx > 0; EXRZrPHuIlIpx--) {
        HpKlDUqdCvKM = HpKlDUqdCvKM;
    }

    for (int gGRWuMwMvThG = 1713142668; gGRWuMwMvThG > 0; gGRWuMwMvThG--) {
        CGQMZ = ! CGQMZ;
        HpKlDUqdCvKM += CaWtwRWbiH;
        eRlTXZJdpSACzpFY -= gKGnTaM;
        jNmPTqW = CGQMZ;
    }

    return CGQMZ;
}

string fadrz::YGaitnCYkbSOlWln(int ZzvSMWKFAEMqDlO, string tggCHMPRgV, bool XfIAJnjjMTtYx)
{
    int WfDjHkEbbW = -1722124296;

    if (ZzvSMWKFAEMqDlO < -1722124296) {
        for (int XaHtj = 346536887; XaHtj > 0; XaHtj--) {
            ZzvSMWKFAEMqDlO -= ZzvSMWKFAEMqDlO;
            XfIAJnjjMTtYx = XfIAJnjjMTtYx;
            ZzvSMWKFAEMqDlO = WfDjHkEbbW;
        }
    }

    return tggCHMPRgV;
}

int fadrz::rflWeDBrnvHUB(string KloGygEQ, int cKeZzfzsdVKU)
{
    string ZLXwKUPnHih = string("phspZVXhEMENMhVpneykJdtnrYYWImui");
    int vEUZhreDFeTFa = 1738067401;
    double HJoEszEeKLYAGz = 90379.39135616296;
    string oxLuolJvfiCUpQwm = string("JJeLtphFYVekSNccePRjPlPqifVOILQtHciVMcKmplhloWbzjSwSlwfdcSMZSPcPvqxIjdfkQEEBVTEcSDhJdtEnNhNlAoDLqAqTRugTXycBhnCuObGWwyhfhjcFKImCFTkBAMuXRQfMhJtzbzallowoRv");
    bool aXjzcvkSoTwAuxR = false;
    bool fEFKStFreoSHxF = true;
    bool MgCQmTkhC = true;

    for (int JxoFmJGaOmy = 13990393; JxoFmJGaOmy > 0; JxoFmJGaOmy--) {
        vEUZhreDFeTFa -= vEUZhreDFeTFa;
        oxLuolJvfiCUpQwm = oxLuolJvfiCUpQwm;
    }

    for (int BdJFEyhyl = 209154667; BdJFEyhyl > 0; BdJFEyhyl--) {
        fEFKStFreoSHxF = ! fEFKStFreoSHxF;
        KloGygEQ += ZLXwKUPnHih;
    }

    return vEUZhreDFeTFa;
}

string fadrz::ILPYKrCJJZDyz(string nGrUFx, string ztqnbUgMunbKwBC, bool GnkXqLiJJEc, string oMMctZv)
{
    int daitSvHzfdlByA = 1390891758;
    int EQiTl = -598834852;
    string GBLsTMvTCxk = string("UzlCvSSPxKvfxuJSqWTAvbTIKuqBhaYQtVGgYmAnPRDTgpmVwmCVIsdDmpMaPcubhMtiAIRxufpEiahhsBNUlfklIhmYUCpSEaqkgSauwxpbtDGYRvApKaDMPpRxQSTeflcImwUyEdVOiGdoTjudzOvmPCgjZQEvyAYvkByXsSHzxIoZOddJJlbMBlEvwjiqAIkukXwI");
    string UjzUowKgN = string("VIILBpgSbhHePjXHgTXJxSmaGWOmAtBfaOTXfLPPgRrWCZAOmKGIyGXHcYTkMGUdzhoVvjExJKYooCelZEmZitypNPizLCpLRoNgoFdKiMhdqatjOSVEOvlUapzdArvKKuXARHNhkUILFrfOUZqXfKoCBodDoWXPgogTMrofoUeU");
    string vgdyioQNiPx = string("jxPEuyHfdmDvMIGBpELPnUqrewQpqCoHbJCPwAOvGSLHsertQJwwyVcFCSzQWAxPqULcFfQrWvZtvQENJeWugqMOonJLzBzyKvkhKZIafQPmPZLruVoywmQtlwXHRPDvwdSucWWxhJsJpCNnjQpZF");
    bool RkaqEDZRxtpS = false;

    for (int AVcabwU = 1879604148; AVcabwU > 0; AVcabwU--) {
        GBLsTMvTCxk = oMMctZv;
        nGrUFx += GBLsTMvTCxk;
        nGrUFx += nGrUFx;
    }

    if (vgdyioQNiPx >= string("UzlCvSSPxKvfxuJSqWTAvbTIKuqBhaYQtVGgYmAnPRDTgpmVwmCVIsdDmpMaPcubhMtiAIRxufpEiahhsBNUlfklIhmYUCpSEaqkgSauwxpbtDGYRvApKaDMPpRxQSTeflcImwUyEdVOiGdoTjudzOvmPCgjZQEvyAYvkByXsSHzxIoZOddJJlbMBlEvwjiqAIkukXwI")) {
        for (int Falmm = 1905453417; Falmm > 0; Falmm--) {
            UjzUowKgN += ztqnbUgMunbKwBC;
            nGrUFx = UjzUowKgN;
            nGrUFx = nGrUFx;
        }
    }

    for (int ZLWbKuvJftfaoSB = 1438364645; ZLWbKuvJftfaoSB > 0; ZLWbKuvJftfaoSB--) {
        ztqnbUgMunbKwBC = UjzUowKgN;
        oMMctZv = nGrUFx;
    }

    if (GBLsTMvTCxk != string("wlLPyxIaowiEb")) {
        for (int OOpKnHqVyQsvuHG = 1161236447; OOpKnHqVyQsvuHG > 0; OOpKnHqVyQsvuHG--) {
            GBLsTMvTCxk = vgdyioQNiPx;
            RkaqEDZRxtpS = GnkXqLiJJEc;
        }
    }

    for (int oWsgbIMjfujCotrC = 131742372; oWsgbIMjfujCotrC > 0; oWsgbIMjfujCotrC--) {
        ztqnbUgMunbKwBC += GBLsTMvTCxk;
        GnkXqLiJJEc = ! GnkXqLiJJEc;
        oMMctZv += oMMctZv;
        ztqnbUgMunbKwBC += vgdyioQNiPx;
    }

    return vgdyioQNiPx;
}

void fadrz::tKnYfgHorrPNxkeZ()
{
    int QtgdNygFXd = -1386030264;
    bool TtTTzDCFtO = false;
    double vrzLYaYZVicCMy = 468486.2145872509;
    bool TJBfqpSKTFRzL = false;

    if (TJBfqpSKTFRzL != false) {
        for (int DGFFpw = 790252958; DGFFpw > 0; DGFFpw--) {
            vrzLYaYZVicCMy /= vrzLYaYZVicCMy;
        }
    }

    if (TJBfqpSKTFRzL == false) {
        for (int KYkboVttdkTqQ = 1721973403; KYkboVttdkTqQ > 0; KYkboVttdkTqQ--) {
            continue;
        }
    }
}

int fadrz::tAvGDlSYZmFr()
{
    double jUrjJ = 522260.3475187554;
    bool BupqvZLELzpq = true;
    string KpDovSdODugRHdpL = string("VbpSmyGiOHtRgMnkKKNVpfVkDdgSYemJYwZFlABPbvIdOOaHGnytZvhsPrpBsJmaFGfkZhXJTnvPPVnkLEYdpNQCdNtwjmIJQixFRexgbAYtJwCMpNZrYgRGg");
    bool GOLtjtrsagzUBUk = true;
    bool fHWoxXJd = true;
    int kysaQYIgPCC = 1051668923;
    bool rsNyoLWrwaHI = false;
    string gVxUDKBdlBXN = string("TfXcyatHWjQOUauJbQJhqrRfFIxKkqrnKaTHJhmyyGkwXGuolWjlGuMXFZKDwubveQUptbANdZTMIJJqDPAVetLkHBIzMeDRhTVglGefmtcNbwfZUGgHDsUDzowmZBrMYGVPqBlhOssUnWXemGNosvPLzqUhexiCoEgeGZe");
    string UJWADTzNyiKG = string("QoyEcQWKMdafWywdVrNynRnyCKHcjOYzJtXhQlYf");
    double QfSFFdsmifZkkLTq = 653109.5712428212;

    if (gVxUDKBdlBXN >= string("TfXcyatHWjQOUauJbQJhqrRfFIxKkqrnKaTHJhmyyGkwXGuolWjlGuMXFZKDwubveQUptbANdZTMIJJqDPAVetLkHBIzMeDRhTVglGefmtcNbwfZUGgHDsUDzowmZBrMYGVPqBlhOssUnWXemGNosvPLzqUhexiCoEgeGZe")) {
        for (int cKJFEhOaZOJWtn = 1691288305; cKJFEhOaZOJWtn > 0; cKJFEhOaZOJWtn--) {
            fHWoxXJd = rsNyoLWrwaHI;
            BupqvZLELzpq = BupqvZLELzpq;
        }
    }

    for (int oWVXstOdm = 451734430; oWVXstOdm > 0; oWVXstOdm--) {
        continue;
    }

    for (int XCeOPemaQg = 485892154; XCeOPemaQg > 0; XCeOPemaQg--) {
        GOLtjtrsagzUBUk = ! GOLtjtrsagzUBUk;
        QfSFFdsmifZkkLTq += QfSFFdsmifZkkLTq;
        rsNyoLWrwaHI = rsNyoLWrwaHI;
        jUrjJ += jUrjJ;
    }

    if (UJWADTzNyiKG >= string("VbpSmyGiOHtRgMnkKKNVpfVkDdgSYemJYwZFlABPbvIdOOaHGnytZvhsPrpBsJmaFGfkZhXJTnvPPVnkLEYdpNQCdNtwjmIJQixFRexgbAYtJwCMpNZrYgRGg")) {
        for (int SjaTfFAbaGHbabZ = 1250931811; SjaTfFAbaGHbabZ > 0; SjaTfFAbaGHbabZ--) {
            GOLtjtrsagzUBUk = rsNyoLWrwaHI;
            BupqvZLELzpq = ! fHWoxXJd;
            KpDovSdODugRHdpL = KpDovSdODugRHdpL;
        }
    }

    for (int GEbvlIOFCNEQVZu = 1004961257; GEbvlIOFCNEQVZu > 0; GEbvlIOFCNEQVZu--) {
        fHWoxXJd = GOLtjtrsagzUBUk;
        GOLtjtrsagzUBUk = GOLtjtrsagzUBUk;
        UJWADTzNyiKG = gVxUDKBdlBXN;
        kysaQYIgPCC = kysaQYIgPCC;
    }

    return kysaQYIgPCC;
}

bool fadrz::KcdXfyZupjzGEzy(double IHRKuREDiRB, double aGQYaElYKWn, bool HMzEzIQCQYfQ, double jMcbwn, string yGzDXnIkEntvFIl)
{
    int VvntKAKkjRwBr = 591151168;
    bool jSBBUdg = true;
    double cfaKXkjZR = -974367.8981931736;
    string nZVci = string("DhbPyrVGpssiZfZOSmZdCzljhCrOmxlVNUJpzOaXWlDBuLNrTYyooeUUrFJL");
    bool KpsLqvHyYCyVB = true;
    int BqlKncm = -615514255;
    bool SwaNlaX = true;

    if (jMcbwn != 365418.90069878113) {
        for (int rPacL = 1339715545; rPacL > 0; rPacL--) {
            SwaNlaX = ! HMzEzIQCQYfQ;
        }
    }

    for (int RwvOer = 680470618; RwvOer > 0; RwvOer--) {
        aGQYaElYKWn /= IHRKuREDiRB;
    }

    for (int nDeKIiH = 1908689250; nDeKIiH > 0; nDeKIiH--) {
        IHRKuREDiRB *= aGQYaElYKWn;
    }

    return SwaNlaX;
}

int fadrz::rRMYKNDjD(string whnHt, string kopaHfBwL)
{
    int YhIQBoquZoQ = 838979653;
    int UCbylUU = -1296000628;
    string gxRXAoLlTbormR = string("WJKJoWxJGMYLUQRuAeBUNwfGJzHXgyeOeHnXLBsafQLequbJIezsmFgtdcrzqzmWgtmyxMeDKjhQXYASZQXOivkjddqLeQUWaLUkDgGccsuMtvGNcUYxCDQYVWxzBDdMoCKnDTGFpd");
    int DIYpnpnHb = -1651340709;
    double OoqDgmINoDDxOv = 56566.72336477983;
    double ZzzxEVafMqVm = 842476.5670487975;

    for (int JDIPUk = 1398763498; JDIPUk > 0; JDIPUk--) {
        continue;
    }

    return DIYpnpnHb;
}

bool fadrz::qmvQjbbxPeuubN(string qodUybfUN, string nYBgofemcXngn, bool toBaboNJpahlzGjP, double mAAhtD)
{
    double dARjxDhGeHcCgik = -939414.6131034868;
    bool LDWyTWipOQrb = false;
    int BpamPLOTnHouqpm = -2096732579;

    for (int fPAxIfqqrd = 1430233863; fPAxIfqqrd > 0; fPAxIfqqrd--) {
        mAAhtD /= mAAhtD;
        qodUybfUN += nYBgofemcXngn;
    }

    for (int DJDLZ = 472627616; DJDLZ > 0; DJDLZ--) {
        toBaboNJpahlzGjP = ! toBaboNJpahlzGjP;
        mAAhtD *= mAAhtD;
    }

    if (LDWyTWipOQrb != false) {
        for (int lbRBgpF = 801575752; lbRBgpF > 0; lbRBgpF--) {
            LDWyTWipOQrb = ! toBaboNJpahlzGjP;
            toBaboNJpahlzGjP = ! LDWyTWipOQrb;
        }
    }

    for (int HYaIZqSTNLrqIT = 24246560; HYaIZqSTNLrqIT > 0; HYaIZqSTNLrqIT--) {
        continue;
    }

    for (int vWscgOXmYSRTpAA = 673146875; vWscgOXmYSRTpAA > 0; vWscgOXmYSRTpAA--) {
        continue;
    }

    for (int opjpUAWgLRzrJP = 333174014; opjpUAWgLRzrJP > 0; opjpUAWgLRzrJP--) {
        continue;
    }

    return LDWyTWipOQrb;
}

void fadrz::eHJcgcUsyJXhZ(double liYMb, string lcckUyyXVfzdcYQS, int onZUwaeFOc)
{
    string oMoLvD = string("OIwswSAPnyCtjtGIhpszGMaNdKSEOsPbVTCdDEaUZMKXxXFrsZuaJALqtmpNfwuWwkyxwEaDVSbqMPrpsoNrPyXmGvphOuRNyXzHARNyzysVEDQnUoOEOXLRYPnmBQVFYlDTucNoPlrkkSmVHRlaENfkBbeDWTzsHSSQFMrTAJQBZgEZabErtabpRYhubJIyLtwiBhiSkrZETyZFdmJmebMNMLLLWMazyKuRKcbijpHOxSGJtftNBbiDNAzaMP");

    if (oMoLvD == string("TtzzRpmLMoajpSbnixgtfauLbTsIKvwcBCINrToFHVNKAdLAOgtWhScFddUnYkTxIwbJvjLeDehzLfiCITybCCYwsjAHxDnnJHOzphudghXuPQXeCKjXYCfdMszXhyAUBfrzUWeRYAlBJEjLGSXazPjCESzDOwohhrxZlPkrZfLEnIyQVNQDvXdctUlXoQmXhWDehJzKBMQlCGuFuBpXvvTU")) {
        for (int tXlRhtji = 781161643; tXlRhtji > 0; tXlRhtji--) {
            onZUwaeFOc += onZUwaeFOc;
        }
    }

    for (int ObKecdMnzxTdVHeE = 231208742; ObKecdMnzxTdVHeE > 0; ObKecdMnzxTdVHeE--) {
        onZUwaeFOc = onZUwaeFOc;
        lcckUyyXVfzdcYQS += oMoLvD;
    }

    for (int zyNCKnIYCUN = 36471582; zyNCKnIYCUN > 0; zyNCKnIYCUN--) {
        lcckUyyXVfzdcYQS += lcckUyyXVfzdcYQS;
        lcckUyyXVfzdcYQS = lcckUyyXVfzdcYQS;
        liYMb = liYMb;
    }

    for (int keIZjYaMIu = 1711575206; keIZjYaMIu > 0; keIZjYaMIu--) {
        liYMb = liYMb;
        lcckUyyXVfzdcYQS = oMoLvD;
        oMoLvD += lcckUyyXVfzdcYQS;
        oMoLvD += lcckUyyXVfzdcYQS;
    }
}

bool fadrz::hQhUKATUws(int iKyKLhPglfcoOM, string BSZZcYqi, int YwWEjNh, double IMKYgnEwKOfrLAa, double uUPMYzikjpcI)
{
    int OPabpFoBaNTx = -786525909;
    double goSxAyKiV = 23303.00907119948;
    int ePWRXtlWZjsJv = 584876657;
    double gtCSiqUDK = -543165.9132364722;
    int ZDLkTniKNTCb = 803769479;
    int viwQNIoeX = 1546954155;
    double oZiFHWVvCnZWiMJ = -487651.26111197524;
    bool zvUxsd = true;
    string AJEVwOZSRBYolPe = string("loRTWKRQcOggljHtAeZgLJgCfhKXpyrRFjVGQmAiFNtMEVxlVojnUCuqxLODpNgpMeMzPSKLOiQbgDledowYNSbqpsWAzGkukYHfpSUiLIQBfKFvSHuVaWlfSCTKCgyZREdkXpsCHkVuTYgSHIUxyFEwggAMDDnXetoPJZapVHEJudJLvUToehkJLOZhNeDXY");
    bool jFLJXufj = false;

    if (zvUxsd == false) {
        for (int AAHHs = 1126230682; AAHHs > 0; AAHHs--) {
            iKyKLhPglfcoOM -= viwQNIoeX;
        }
    }

    return jFLJXufj;
}

bool fadrz::jlODNyRzbZIdhdA(bool HZDMPvgflOdSD, string aKwIeoHzd, string XkTjOOQpHAqKV)
{
    bool JLKyFOyijZCKY = true;
    double byjFMtoSPBUT = -499317.2413709893;
    bool xqZDjdKfuuf = true;
    bool dEOomZxhoqIf = false;
    int qrLQRyaFNieeiSbX = -1829284974;
    string VQWOFcNoH = string("pkWliFVgQBktuPnfeslymcFgjPlHYvPkNHpZrkczHsyddjWQELMjZEXlTpcLJckghAPPAkazcUTxXpCccvSlEzbxuWhgarUttSTKaaXvkSVxhzAmpNWthXzEqwdnqJcxnnsLyagtBqkLEbqDyWxpnX");

    return dEOomZxhoqIf;
}

void fadrz::WvUwCDKcyXDQU(string ReqFLYPSZspwTJ, double fvxuLNhgIPVDPVKs, double UyvmcCznfR, double CcZEmpBlJSA)
{
    bool vNhBx = false;
    int ripcQAlvLLha = -1398208733;
    double atyuIymxj = 38632.078763217985;
    double aqssOwRbOWsYaRfZ = -812650.2428116994;
    double WAbYw = -26951.8705812606;
    double UQEtw = -163089.2385175358;
    int RWykJDiIVdhtO = -818901039;
    int DtyCzTdvvwZ = 882084631;
    double ZtjABiFolhjYzXS = -60392.68176120935;

    for (int bZJlNxk = 1578161284; bZJlNxk > 0; bZJlNxk--) {
        CcZEmpBlJSA += aqssOwRbOWsYaRfZ;
        atyuIymxj /= atyuIymxj;
    }
}

double fadrz::FWbBT(string XeDALtDal, double MgpjnNCQZ, int ScyRV)
{
    bool LbSbNLCmOjVc = true;
    bool TsfdFGOylRBSQaIq = true;
    string faAoOIy = string("lrEAiPFkKcQgzPgLVivxyOxdIyYgqDwpgrdtHKLQbMqZdEzJQKFejpAGdyLlJBubGqiEGoLkRRyUYmIDCoKwXekvpMTsjJnUQDXhPPlgtczkyOexBBqdaMraQsopGrCzZaDQJxFeOwaFvgPJZLrFYCHvcBOeOaTfmwsJpqDNWnzISUJcmlhlXacklwoTZPZEfIpJsdQChEWtnqCvdfoBFpvLWltusnMVlipIqpUxxYBfAAsTl");
    bool KUeVAKb = true;
    int IyBzDEIIM = -1004567425;
    int yGaearvK = 506051453;
    double kQEMFoza = 958285.3266907202;

    for (int YjHpbLdaTIDUTN = 1370082921; YjHpbLdaTIDUTN > 0; YjHpbLdaTIDUTN--) {
        continue;
    }

    for (int hUVOcZwDXfCo = 775867358; hUVOcZwDXfCo > 0; hUVOcZwDXfCo--) {
        continue;
    }

    return kQEMFoza;
}

double fadrz::roGULYKGy(double vrwqiIrRwLCaWNF, bool qSvaIcnuwX, string AoPrU)
{
    int IWEOsbFjWiediNST = -1728063275;
    double VeGLo = -435571.0179605712;
    int TJwarKWDJieC = -210851492;
    bool qwWChKPtLUoIM = true;

    for (int WlumPX = 851295542; WlumPX > 0; WlumPX--) {
        TJwarKWDJieC *= TJwarKWDJieC;
        TJwarKWDJieC += TJwarKWDJieC;
    }

    for (int wswHxYEMaIEVu = 920488510; wswHxYEMaIEVu > 0; wswHxYEMaIEVu--) {
        VeGLo += vrwqiIrRwLCaWNF;
        qwWChKPtLUoIM = qSvaIcnuwX;
        vrwqiIrRwLCaWNF /= VeGLo;
    }

    for (int kShWsVdPNzq = 1379621030; kShWsVdPNzq > 0; kShWsVdPNzq--) {
        continue;
    }

    for (int aCsec = 1848387596; aCsec > 0; aCsec--) {
        vrwqiIrRwLCaWNF /= vrwqiIrRwLCaWNF;
        qSvaIcnuwX = ! qSvaIcnuwX;
        qwWChKPtLUoIM = qwWChKPtLUoIM;
        qwWChKPtLUoIM = ! qwWChKPtLUoIM;
        TJwarKWDJieC += IWEOsbFjWiediNST;
    }

    if (IWEOsbFjWiediNST < -210851492) {
        for (int YnLCeaMRnEs = 607696674; YnLCeaMRnEs > 0; YnLCeaMRnEs--) {
            continue;
        }
    }

    return VeGLo;
}

double fadrz::hONBeEEX()
{
    string LpYRu = string("EdtNoLwcFsuNfhtTtWrRRZbWWfPxMMcLWCBjtmujlHNzpCAfPptexrnnmpAKfa");
    int ELhdVZ = 2131299175;
    bool rCNJBS = true;
    int DAyoWSXxALmlE = 1140466055;
    double PsvlqIcP = -901917.248215626;
    string SDXqmLzaMBQzepha = string("ZKtyFdrmGSFcBHaNmEijVuwqNFdyjyHaxWlcilFMBlsFMpnLzKbYDHCorFAJQURyPcWujZZLSxMhZcOZbbgMBvdmrZxptIuBHhNzPToPfXIfOmENBOsPCLjDMvgbTFVWwInvPsgCNuRSOEgcSWLyMWEreOgobKICHPDNKOQyZboMvIncrLgEWgaGBBiQEHrkbYycZCdqAVkigkETIOIDACbbnUmQKiBEGmGjHCDCdrAIIuqWiShbHNx");
    string bNCMqZCzbnm = string("BpMQCgwVCabVZHZkQSfCNOIBuWqpjMwSUlAevyQEhcIvVCJCDeukRbbTbXdVMKsyJTsukVkNWuGjWaGBVMvxzCpNvJCOCNighemmgaQrwXYCeVmsmnSFAUZFeiATCAMDaRBoQvAeUDGRlAXoQtgbqXisPDjzUTFxwZCz");
    string GJkyUQPN = string("hbxeIBjVMTKVLmKfsZsdGqWfFvRugqdsauyJfuvBYIbZjNaOtUmkiwzIiDZDHjxo");
    int hqPqjb = 381979172;
    int WZJyeGKpS = 678168441;

    for (int IykpIwBLJQHJyon = 1353522651; IykpIwBLJQHJyon > 0; IykpIwBLJQHJyon--) {
        DAyoWSXxALmlE *= ELhdVZ;
        DAyoWSXxALmlE -= ELhdVZ;
        PsvlqIcP *= PsvlqIcP;
    }

    return PsvlqIcP;
}

double fadrz::ezWSMtl(bool HtLcANUQJe, double iDEwdWkaZTmXyxD, bool pgxdIxweNMePtnOV, bool fCipBlwrBasim, string sWtHk)
{
    int qzNqpQuIzbOhXoNH = 1941675565;
    bool uvRPpwKKbCjYq = false;
    int UEShEsyIS = 1774946192;
    double gaJKwmA = 612108.4716225542;
    bool wXtPvMwKPcX = true;
    bool UHFAaxkCpEVEdx = false;
    string xlAnH = string("iNTqdyzXsSiXLMvTEvnABJUwPjewsVNLAuYcvNeLIufhWKmprrZdQHbTlkmWhPXvbDJHaYzWwGcHualBkCaAlJYcjYhJYXFEBLydMylLOvSGAgGOQiwDglvXzAInDQGFQXSWSJwiCLkgrDYFvegYntuAAgIOohvUDcmRFJtYDbbxZhSuCK");
    bool psJdanlrqDJRJJA = false;

    for (int kTUVyw = 1387699769; kTUVyw > 0; kTUVyw--) {
        wXtPvMwKPcX = ! wXtPvMwKPcX;
    }

    for (int aAiIzkieTIs = 1662301764; aAiIzkieTIs > 0; aAiIzkieTIs--) {
        psJdanlrqDJRJJA = HtLcANUQJe;
        pgxdIxweNMePtnOV = ! uvRPpwKKbCjYq;
    }

    if (gaJKwmA > 612108.4716225542) {
        for (int rohwKrNYScpMC = 697211361; rohwKrNYScpMC > 0; rohwKrNYScpMC--) {
            continue;
        }
    }

    return gaJKwmA;
}

string fadrz::HcIiY(bool unesZgzdffPM)
{
    string Yxjol = string("PeJuVQKVPtbDHgUMLzOBrxoYYczeCDtlAVkpZqSipRpiNvucQUvhBkPmlmFMimqxVbUBKsMcmgPyrTxNqAGEIrUcsdkHmajFLCePWQeenDgXEKFhvHKXOwDBSDxfXqYjyVzXitopuePBDElHbzfZpZUhKivggSzwoUTCjEBfZLBYIOgvPZQuvzvtiZvJgmOnOvmaT");
    string uJGBQ = string("fMYhpGIsZxLLptIAPGZxyzWcQngEsEqyTehqwmnENqJoOZxvZrPpnDAgqxIOJkXkqDovUWhZUASEOkxqFApMYQbAmyEPTVzVTrUbebNuoJCmLQKlWlMKNvkDAMCAAbTzVbZAQaRujzgWkSPsFMjjtMlQXsZVHByNPMEfxpQxPsuXRMjtrFQTjupggFRzBqYvdpdvoAHZhluMpJCEPlfnxbxQerdLBukaFQ");
    bool JYzrwLNCI = true;
    double ymXyIBjkplPx = -873351.954926179;
    int ZlbYIl = -750840822;
    int McyKhhD = 1929298607;
    int RCBHrbDNoXFWDYbC = -1651458431;

    for (int uJArDO = 398811987; uJArDO > 0; uJArDO--) {
        Yxjol = Yxjol;
    }

    for (int VVdVWKmZh = 1297670142; VVdVWKmZh > 0; VVdVWKmZh--) {
        Yxjol += Yxjol;
        JYzrwLNCI = JYzrwLNCI;
    }

    if (uJGBQ < string("fMYhpGIsZxLLptIAPGZxyzWcQngEsEqyTehqwmnENqJoOZxvZrPpnDAgqxIOJkXkqDovUWhZUASEOkxqFApMYQbAmyEPTVzVTrUbebNuoJCmLQKlWlMKNvkDAMCAAbTzVbZAQaRujzgWkSPsFMjjtMlQXsZVHByNPMEfxpQxPsuXRMjtrFQTjupggFRzBqYvdpdvoAHZhluMpJCEPlfnxbxQerdLBukaFQ")) {
        for (int DzXDlXKIJONIoT = 933690638; DzXDlXKIJONIoT > 0; DzXDlXKIJONIoT--) {
            unesZgzdffPM = ! JYzrwLNCI;
        }
    }

    return uJGBQ;
}

fadrz::fadrz()
{
    this->qcIRRDzyQbZSye(string("VyzoLVBDLwsdQUZoPqUHJiOMhEvwjftPbOtEzDXBItBVSJibTqKdjvasnbBMCDKERHkTKjJxnjDtDanVuOpXxkRNbvZHNtOriElYWDQebTBqPZkjOBiBkXmOrHstCYwbWnonovdoLQJJXXZVhtemEKysOTpPFjVN"), -497072850, -1742611065);
    this->YGaitnCYkbSOlWln(1246159116, string("PPozdMkUaBZDwmkuvgKuyllDFowTlhwyaNWuPtUnKlvxhpFkrSGzUOaikwnfgspDjQGJOoACqUfUfoAySEViMTqSmtVLWDuYpHRehazhtyYkNXqnTgostSPPeBmCrGoUwYuR"), false);
    this->rflWeDBrnvHUB(string("ZSOzSflBzFIflTyJYGkHDIPQhgwYRNYIzTLoRPzGwIdmIPvDJjAlZZjjRhGDkiIUzmhOemJRAatLDdEFxJPQbVtrTfzAmzFUOOOXEsVikWyOyNnsnluASCKjcgSQKjgsPAJpraqwFsQAQJBtNqiWQlzgoRfYunNyuOrbbsOKhYsEmbcxSGjEDZmMBgISzWOYWHtPfps"), 542199515);
    this->ILPYKrCJJZDyz(string("dEcwJkLjbFyooBwyIRIYRsUJmKniwxBQRbLDmMc"), string("wlLPyxIaowiEb"), true, string("xaQUlXqUnwJKKciIGLtQRwuQjAZMljXYjLb"));
    this->tKnYfgHorrPNxkeZ();
    this->tAvGDlSYZmFr();
    this->KcdXfyZupjzGEzy(458972.21443732176, -628451.5644993264, true, 365418.90069878113, string("VWLGjzTjvuayDuQLfJBZimxrLOzsfOjTMAkiVJDxbWbTuoNbyqKtLcuERzKTlGkPqQYHPJkWLfZztDVwkbAjdRMhoBtH"));
    this->rRMYKNDjD(string("wtyKSuYYggzDvRnwaXoPVfxojoGZvKkvPNGCZnYFIINLgZAwGrgjGEaBlWInbtKHoeoLqTVavANzMmOlRrJCFxRueYdSyVtkpuZsliCYphzTFzBRRCwwAcsGueNlUBzUbULhRuczDKMgCOPDYEgYFWaVTNoJPaiIUNAhdjSewTazMiBbdhDIxZIiCUqnoCWNmQWSZPGDzNeSljwqKUYHYSjyliYRgjStxUZMLneALnotnmQiDMFbMSKEnrlva"), string("LDDziLQBNHplWqdyumyfzBvLvqrTOEqRFMRbUSVl"));
    this->qmvQjbbxPeuubN(string("XN"), string("AxfEdhRGqXLkiFjKxatSDwaYkiiIXyQnqSiMENpYpmrsOfMPgkQKAVaTeXMKMseqUrguOmIikAiFcnUwWdkkAmpFqfegltYvlBzNuPhcRLXeSXHKxoekmaBGHsZIkTfqdrwnAfhkiyRNdAnrDoehNTmYxoniAQnFWueWSmtOXVrfOPzEqRSthRrRDd"), false, 265260.737644476);
    this->eHJcgcUsyJXhZ(-971064.5223223667, string("TtzzRpmLMoajpSbnixgtfauLbTsIKvwcBCINrToFHVNKAdLAOgtWhScFddUnYkTxIwbJvjLeDehzLfiCITybCCYwsjAHxDnnJHOzphudghXuPQXeCKjXYCfdMszXhyAUBfrzUWeRYAlBJEjLGSXazPjCESzDOwohhrxZlPkrZfLEnIyQVNQDvXdctUlXoQmXhWDehJzKBMQlCGuFuBpXvvTU"), -1266735186);
    this->hQhUKATUws(1111262148, string("LgVJooepHEoGDUuTzWYwSgquGyPsHIzphxijEgUHmmiqZQzzsyfJgjcEUDTzFaOtpcYpSMfDLPWMzRQNKZAnSYPysVSFnMjIhCzdYuhjmYiwJNKkC"), 1823242706, 69577.85430807133, -83158.48209730722);
    this->jlODNyRzbZIdhdA(false, string("SDcrvAIQJmWYQldtVPffmQwvrNKUfCrRBdWBOINDFOQxPnJAbpPdfIjZUIJDrywSeZBmvUEkwxMEfjIdruXiiIZPUnXkhkMUiSFBvHKmQrsJKrrSUasawzJlLeXgjFTHtfhPuMqJjdrZGHBQFOMdkTPyTTneIjhTkUBOjLDcoiljhHJmkf"), string("lcaxdRLTkjtXYUrihPCljDLhZVToRshlkkpjaiKjFLjtBWlOAeObApbCMlyckQvEYRSjrpGtgdKadZhbmNJthgwyXmggMfzYyEZCwvtbVWPaMfeykNMggUbKvxxlnKuPIaEkQyMJsAPBUtjckwoUwDWxZyArfYQsqTarEzguFYMHaWvTGfudV"));
    this->WvUwCDKcyXDQU(string("zmkPFRkUtInQbAPCRvPhEEKeEKDelZstOCqvssKbjSikdXNuRiv"), -74942.76090906725, -919765.9291096384, -334271.0685007818);
    this->FWbBT(string("PDDAFUgIQTsIeYaVhbvlfbRVwuguhkxNyDwmtRQkbPTpKpaFyGiCuixcXjrESCjlxwtLgETawESiNmUvOPxVQrbqAHeNIUPhpZJmnBdzxznTWZRTxdcddaqJZGJDVrzNsUoiOtTWvlTxIFULmSJQJvGyEZnFOuMMUSytcvzQoepAhZmMQIlYvuEAMMZImmKkOkHUkTtbbuWxVLORuOLGhjYm"), 126954.59122648713, 869700483);
    this->roGULYKGy(-657171.4562973407, true, string("zlOLkitZDWDlyGJqDLFwfBtcFqvTXMqhLJelSrTZPZwYEVtcjhDqzMHneO"));
    this->hONBeEEX();
    this->ezWSMtl(false, -116369.82042220685, true, false, string("mmBnkpxHMAXSpqKZVDmBuLMKoRwWlaphUeenjvhYBVcxAwkGyVrhArZuCYsTYRaHQbcKmSDfxtAWoObkmPmcyMJzQzvAbbfxyTbdwYtFXwGdhBNRtwCaDMbguVVOcKBYVQoexWSNUmDfPERDgSlbolGXDsnzHOCzFxXuyfbzEabtIkNVkqIiurhqQnPzaafcuDzYeNUTuTZE"));
    this->HcIiY(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eFCjPjJmh
{
public:
    int cdemmnoV;

    eFCjPjJmh();
    string uEMCoAlqPeHDnYmM(string XKgbWzGH, bool zkGfndFF, bool kQcGXoXwjZHqvfgB, string TUKJcRZGph, int ZNVrQvtuZP);
    int yOKjmSnnmEkqgZbj(double qZPRoGOWXSmg, int vZzYfo, int XvodK, int WTuoSEjufwBOThr, double mwiZhAALzYZyq);
    bool QbkVYuF(bool JPafmBQhmIlZgvrB, double KRRmGkTWmJx, bool RTbZyPKXaFyziz);
    void RYjvATeNz(int KUapQjeVHXWZCJ, string OoztC, bool xHSKGkxQAZcJZP, string lLAiMPd, int cndhrwLfN);
    int mxbDOk();
    void CVYZnZqVrhmCwyZ(string GLPpkLzm, int rBXvO, double YblRw, string XBIGvfmIqApo, bool UHFAAnFj);
    double SBXipSSqOkCnV(string wUHKzZjZrhhhRNl, double qFACgc, int WPrLyv, bool HJcSFAZrBeKsTGvM);
    string YLEojEhv();
protected:
    double jHJIh;
    int juDUNGwR;

private:
    bool KGLGMPFKWFt;
    int hUCwZPrqPJcH;
    string KlhzviPjtEzb;

};

string eFCjPjJmh::uEMCoAlqPeHDnYmM(string XKgbWzGH, bool zkGfndFF, bool kQcGXoXwjZHqvfgB, string TUKJcRZGph, int ZNVrQvtuZP)
{
    bool lUEZXKtqbPpuhMJ = true;
    string WGsygLgmWTh = string("kdZUkDoKXZiKpXJJUtCdBqPDcyCDYEVIXDkRVOweLPtQlphaatTtRDNYyUfEJkzErNFdzZqEQUMVhqgaVtredOzIDsOFYEUcFhoojxSxSOeGhFbBOkvtNbbtRBmihwnwOLwJIbkAbCoAhLpiFewahuWOQlRdqyHUMekRLgCMxtoHNotjesnFBJTRwSsFtLxjkOkCNtKG");
    bool pMMxsJafVNORtt = true;
    bool NHYsxh = false;

    for (int OlzQmHqLs = 1469737593; OlzQmHqLs > 0; OlzQmHqLs--) {
        zkGfndFF = ! pMMxsJafVNORtt;
    }

    for (int uNIkJ = 854516008; uNIkJ > 0; uNIkJ--) {
        continue;
    }

    return WGsygLgmWTh;
}

int eFCjPjJmh::yOKjmSnnmEkqgZbj(double qZPRoGOWXSmg, int vZzYfo, int XvodK, int WTuoSEjufwBOThr, double mwiZhAALzYZyq)
{
    bool ISdZrVO = false;
    string cZlOKQZD = string("vyogDbAYqpvltSCFpEFLwLKIAMduEiVg");
    double OxvveQ = -555992.4040489238;
    int FXEDkgkEbHQW = -439151237;
    double ZDQiSWMsFdBUeYqs = -480746.89739286853;

    return FXEDkgkEbHQW;
}

bool eFCjPjJmh::QbkVYuF(bool JPafmBQhmIlZgvrB, double KRRmGkTWmJx, bool RTbZyPKXaFyziz)
{
    double ejYQlIFPpnXLu = 377420.26524074044;
    string ZESTGrTXtKfwmAv = string("UOFhUYYeRTMIEFhyuQjtncLqAtHUvovywMPcDoSlVqCFcZzxmuDZfyaVvsFEMTSxcBClbYDmxcwQsdeJCPsDnJcJEgdpFnYXYD");

    for (int wlMMomEZVp = 163610384; wlMMomEZVp > 0; wlMMomEZVp--) {
        ejYQlIFPpnXLu *= KRRmGkTWmJx;
        ejYQlIFPpnXLu /= KRRmGkTWmJx;
        RTbZyPKXaFyziz = JPafmBQhmIlZgvrB;
        ejYQlIFPpnXLu *= ejYQlIFPpnXLu;
    }

    for (int JuYUXYmbGBlXBNg = 1266754087; JuYUXYmbGBlXBNg > 0; JuYUXYmbGBlXBNg--) {
        ejYQlIFPpnXLu += KRRmGkTWmJx;
        KRRmGkTWmJx += ejYQlIFPpnXLu;
        JPafmBQhmIlZgvrB = RTbZyPKXaFyziz;
        KRRmGkTWmJx += ejYQlIFPpnXLu;
    }

    return RTbZyPKXaFyziz;
}

void eFCjPjJmh::RYjvATeNz(int KUapQjeVHXWZCJ, string OoztC, bool xHSKGkxQAZcJZP, string lLAiMPd, int cndhrwLfN)
{
    int lIlSF = -493239592;
    double nTAatQtkcNbusdZ = 850174.7239260493;
    bool EJNGQALNkkzVlqK = false;
    int vSctfEyoj = -547461904;
    int CYnjhJQkRpwln = 1947544837;
    bool OFraRiIbPXI = true;
    double tSNKqCrjn = 178025.88713656037;
    bool KrTEQaE = false;

    if (KUapQjeVHXWZCJ > 128744939) {
        for (int oqjqPscSC = 1662421768; oqjqPscSC > 0; oqjqPscSC--) {
            CYnjhJQkRpwln -= vSctfEyoj;
        }
    }

    if (lIlSF <= 128744939) {
        for (int uDqVSKGpfaCBsMr = 2093087006; uDqVSKGpfaCBsMr > 0; uDqVSKGpfaCBsMr--) {
            continue;
        }
    }

    for (int sKBbRpoyWmD = 790962338; sKBbRpoyWmD > 0; sKBbRpoyWmD--) {
        continue;
    }

    for (int hEtuXqnHuK = 2090364302; hEtuXqnHuK > 0; hEtuXqnHuK--) {
        cndhrwLfN = CYnjhJQkRpwln;
        xHSKGkxQAZcJZP = EJNGQALNkkzVlqK;
    }
}

int eFCjPjJmh::mxbDOk()
{
    string WvQzBdViGL = string("ottqXAWVJTtAkXvsxtcfdCGXLcXWvnWOOoJwCEthkqOUnhiAotoqdtpNTOctFlOcWgKarxOoGRFpUfRvKgfSSospnoOOcEPVGzkGoNKAFGRdDVNbWgIUBJSjDslYrdnJbacMmyRkvfBymOUpadgfwAXCAkOthGBXJGvdAeOQdupJIwQNeSfONqzIfMUWweUamJKuMLZLfVDODEgRAnzdgrippUmRYdgbjT");

    if (WvQzBdViGL != string("ottqXAWVJTtAkXvsxtcfdCGXLcXWvnWOOoJwCEthkqOUnhiAotoqdtpNTOctFlOcWgKarxOoGRFpUfRvKgfSSospnoOOcEPVGzkGoNKAFGRdDVNbWgIUBJSjDslYrdnJbacMmyRkvfBymOUpadgfwAXCAkOthGBXJGvdAeOQdupJIwQNeSfONqzIfMUWweUamJKuMLZLfVDODEgRAnzdgrippUmRYdgbjT")) {
        for (int XWDKdLJ = 1339363807; XWDKdLJ > 0; XWDKdLJ--) {
            WvQzBdViGL += WvQzBdViGL;
            WvQzBdViGL = WvQzBdViGL;
        }
    }

    if (WvQzBdViGL < string("ottqXAWVJTtAkXvsxtcfdCGXLcXWvnWOOoJwCEthkqOUnhiAotoqdtpNTOctFlOcWgKarxOoGRFpUfRvKgfSSospnoOOcEPVGzkGoNKAFGRdDVNbWgIUBJSjDslYrdnJbacMmyRkvfBymOUpadgfwAXCAkOthGBXJGvdAeOQdupJIwQNeSfONqzIfMUWweUamJKuMLZLfVDODEgRAnzdgrippUmRYdgbjT")) {
        for (int CDCYHD = 702235228; CDCYHD > 0; CDCYHD--) {
            WvQzBdViGL = WvQzBdViGL;
            WvQzBdViGL += WvQzBdViGL;
        }
    }

    if (WvQzBdViGL < string("ottqXAWVJTtAkXvsxtcfdCGXLcXWvnWOOoJwCEthkqOUnhiAotoqdtpNTOctFlOcWgKarxOoGRFpUfRvKgfSSospnoOOcEPVGzkGoNKAFGRdDVNbWgIUBJSjDslYrdnJbacMmyRkvfBymOUpadgfwAXCAkOthGBXJGvdAeOQdupJIwQNeSfONqzIfMUWweUamJKuMLZLfVDODEgRAnzdgrippUmRYdgbjT")) {
        for (int rzrpPmt = 626445619; rzrpPmt > 0; rzrpPmt--) {
            WvQzBdViGL = WvQzBdViGL;
        }
    }

    return -1557004601;
}

void eFCjPjJmh::CVYZnZqVrhmCwyZ(string GLPpkLzm, int rBXvO, double YblRw, string XBIGvfmIqApo, bool UHFAAnFj)
{
    string mvWoENqts = string("wwsHBzdtBrcrDCLdRhlYqhjYJDKSIBrROvHzXvCbKDxEzcuBtSwEMkxtXuktQDeHLDmhKMoDoIUfOIlcRPMGkDmiUfFVwLCZonHnFYrEdjWdJRATOuawLKGazjnuxdGKMdsOuBmNfDePSxmrlIKEPixeKTtADeMueHgPkZgzQDlbxLlvVDoXSPLaYxjUQmjatxYJSrpXesHOwDbvsbZTIMYvCiV");
    double CltdXH = -382464.65638484765;
    double HhJPnvQWdoNmgqG = -757918.4139631209;
}

double eFCjPjJmh::SBXipSSqOkCnV(string wUHKzZjZrhhhRNl, double qFACgc, int WPrLyv, bool HJcSFAZrBeKsTGvM)
{
    string noIYfwUppsUFMCAy = string("attdKUYUclHseZjWanOHzFsjxBjcntqwpqWPXAgTsXvvlBmqHtRlVSEvawwtzvToXUwKFLupDIsjOMsBiBJsbfQcUufuhurkKOsceeNoiwImFbPuTqppfpJkONZXxERRgygKMWqwoXcvqDZZubkbw");
    int LyntTFqtnozdlek = 699322520;
    int OgeobjftJ = 701883941;
    bool CqGiTnGSBJE = false;
    string aUQUJaWtXFzaJc = string("pZaknNBffbAkUdzKhtZaHiTCTbbALXjqktKmHeuQAvHjWVssPuJEuuhDvVNsPTqOKvjnsWwLbCQkJmNNWFmflApBmoJxqNGyuqpbvRnQAgAvEMeEViYIFLoeKDpsThxhhVprvuJpSnfSafmazFxSvnOwNireEhCeNOCKGhJQkUKTatlaDSgxExPzNIWoUwrmh");
    double OZNFfc = 835171.1682790798;
    double iDgsUJK = 741663.3842924293;
    double ENNiefxnEPsRTn = 916825.8247394755;

    for (int GPaFdeZtv = 408914513; GPaFdeZtv > 0; GPaFdeZtv--) {
        continue;
    }

    for (int IjaduWtxWxT = 936590033; IjaduWtxWxT > 0; IjaduWtxWxT--) {
        continue;
    }

    for (int PVgokTSKzI = 1499007582; PVgokTSKzI > 0; PVgokTSKzI--) {
        HJcSFAZrBeKsTGvM = HJcSFAZrBeKsTGvM;
    }

    if (OZNFfc <= 916825.8247394755) {
        for (int XQvjZhwQiciHJ = 2146929318; XQvjZhwQiciHJ > 0; XQvjZhwQiciHJ--) {
            OZNFfc *= OZNFfc;
            noIYfwUppsUFMCAy = wUHKzZjZrhhhRNl;
        }
    }

    for (int NEhnrGyWHTetgk = 1505522991; NEhnrGyWHTetgk > 0; NEhnrGyWHTetgk--) {
        continue;
    }

    for (int qvQPeEMYA = 1498938006; qvQPeEMYA > 0; qvQPeEMYA--) {
        continue;
    }

    for (int KxeBK = 379837478; KxeBK > 0; KxeBK--) {
        continue;
    }

    return ENNiefxnEPsRTn;
}

string eFCjPjJmh::YLEojEhv()
{
    string qVqofB = string("JNZGlbVjphCIPQBIRdulULmUkikWcLNBcmdARlSiwHEmEqQdKrymrdlkoeyJzVIqhhwAAidvJeUfTCfQrmfNZxwZAurCgKKQJgDJjGxwgcmYzotnmSXUKOgRAwBSUkojeeedFtMUZFXgFWYUshScnSBkULHtzRPwELGFvsabOUEpRbgNHoPSyAtSpZdwWpPWiSFQXRNgMnYheQXzfwDzgLtDM");
    int ttUzSX = 1979746206;
    string uzqnBLychGmMddgl = string("pWSulcdRYOGdCnaUphawPboIvryJHSaZhMoKiBWzTFdHikmZchlMFNqnwuxVmOJdZQKLd");

    for (int RcIkITPg = 680241194; RcIkITPg > 0; RcIkITPg--) {
        ttUzSX /= ttUzSX;
        qVqofB += uzqnBLychGmMddgl;
        ttUzSX -= ttUzSX;
        qVqofB = qVqofB;
    }

    if (uzqnBLychGmMddgl != string("JNZGlbVjphCIPQBIRdulULmUkikWcLNBcmdARlSiwHEmEqQdKrymrdlkoeyJzVIqhhwAAidvJeUfTCfQrmfNZxwZAurCgKKQJgDJjGxwgcmYzotnmSXUKOgRAwBSUkojeeedFtMUZFXgFWYUshScnSBkULHtzRPwELGFvsabOUEpRbgNHoPSyAtSpZdwWpPWiSFQXRNgMnYheQXzfwDzgLtDM")) {
        for (int Qksmfp = 600369266; Qksmfp > 0; Qksmfp--) {
            uzqnBLychGmMddgl += uzqnBLychGmMddgl;
            uzqnBLychGmMddgl += qVqofB;
        }
    }

    return uzqnBLychGmMddgl;
}

eFCjPjJmh::eFCjPjJmh()
{
    this->uEMCoAlqPeHDnYmM(string("ZFQtdOvBePIqpskRUNPZpHdlRgNkISBsWSLVQXnjHRTXxOpEECVRCAhrhldYiPaRYncRPFgODEGDaJbwgOHtQeOtrGbNomKLmnHOeJAYjrgDutoSYBupKFGdszYhIEEGqkviDdMEpqlraQZcIRRrfCEYAbFTqaSjXTZVNgheOjWlSWYCzqgfnVzpuJWPffDIrWlmSBovaiKkJhHr"), false, true, string("jlJgiCRWAwwzzACqiRcEclkPRYFpwzPfzPrPoYcGMfhxQucfVDMBNADshZmNKQgaMfQiedzpRdijBFBGHHqDimPrjtDCfughzeLvauWWkODjVqSIPizazXOVPjpuVyQZffErfnkWTMyHCLIyGesIdO"), 1050771720);
    this->yOKjmSnnmEkqgZbj(404329.64233218314, -236375817, -1925633759, 1728768860, 472127.29085520474);
    this->QbkVYuF(false, 1035981.6056066782, false);
    this->RYjvATeNz(128744939, string("YSaaKEsGLUbVAVcZBFeBDsWKCqESaQaCanLFcyQWGMQWsYayNpNOUQfoMOzqtSkRLEbEhsVYfmxdPmlCcKusBVjXTkbkrtCcCRmYaOLSzqyFGOcQhBljsJpXQqjPHWsfUISVfZtGuVECwsfwNvTxBINsMEwNMadvCNWLAFucpdVQhSIiPHoWtNQCTQxaVk"), true, string("IdijasbfRZMPScaLtREfMrJSJMShWCBC"), -1502652957);
    this->mxbDOk();
    this->CVYZnZqVrhmCwyZ(string("nxJScxJEqQjKEzjJkSIQZRiKZzgTGYYbHuuFCjOjdiudURiqoEbLDMbGSeTnmIZpaUrHlDoordonBzKLveLSIMyBYwpBLppvkYUOVQiJhZoYVtpVNocJMlYr"), 566024927, -682653.8828127098, string("bzpEXSqpwjhDQrXRUsMemsiqw"), false);
    this->SBXipSSqOkCnV(string("ZupgmsUYvbalwBTCHlwTUuEcIrAotwOxTuxKfgGBpPvEztoeVpIchOWyAgIebKZCJKxpRkfGsZfwdVpMpsIVQxwzWoUFBAauvidoaUiXBdohiJR"), -1021770.4179202851, 470209040, true);
    this->YLEojEhv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gWHMBMzPgDA
{
public:
    double RxQOLbLd;

    gWHMBMzPgDA();
    int pnmmfY(bool ghybFdPHU, int GvwMY, double wiqCTgYelDHUJi);
    string GGEIaOcIKge();
    double XuryIpIfx(bool yXZyfyMRu);
protected:
    int iJuiGpwbVeUhwvJ;

    void AhgRZfgBOit(double pHqLcELLQJVWty, string EKsEJQJIRBwR, string FeSrerEEKvUC);
private:
    int kpmNWrwBE;
    string XMwTadOFaQj;
    double qkTaEltsstqxAMhI;
    bool PifKUQ;

};

int gWHMBMzPgDA::pnmmfY(bool ghybFdPHU, int GvwMY, double wiqCTgYelDHUJi)
{
    bool iXOGWzIrquXFwC = false;
    string GySAXrteq = string("RAewNKnyLkRiFsVWTtUvCSIOxfGBlotXLvOuUHgoJVZOfztmNtYSRiLcKfCiTYBVQSdRZEWurMmSIlovVKEGORrWmEovPUUxevumjQpPJXPWoGsKIEvDockLWBdbvwmaohezmKCeAWWKKxLVWPHVGXvzGFUsFEeahQpdaEkayQTTlX");
    double qKABb = 182808.75972662293;
    double VmVitpTlqRlzlijN = 230874.48848921416;
    int STEtShThR = 1879048523;
    double DJrywPOXAR = 962199.7987573568;
    bool GBoKHzxwKdKd = false;
    double ogsgFQiqqDwwM = -807350.1125089267;
    double FjRdEjTq = 250568.75725397203;
    bool pmNYUmV = true;

    for (int ViHBfrZUWcHqLq = 695326982; ViHBfrZUWcHqLq > 0; ViHBfrZUWcHqLq--) {
        continue;
    }

    for (int CwheHV = 2004971941; CwheHV > 0; CwheHV--) {
        FjRdEjTq /= ogsgFQiqqDwwM;
    }

    for (int pqscvt = 1153220466; pqscvt > 0; pqscvt--) {
        ogsgFQiqqDwwM += VmVitpTlqRlzlijN;
        qKABb += FjRdEjTq;
        FjRdEjTq -= qKABb;
    }

    for (int DkNEYdNlBBbH = 55580633; DkNEYdNlBBbH > 0; DkNEYdNlBBbH--) {
        continue;
    }

    return STEtShThR;
}

string gWHMBMzPgDA::GGEIaOcIKge()
{
    double kDihqrwAGd = 40801.38241871675;
    string qQqbnVktHsJhDkq = string("tEmeGmLgVSVTNcJgIzLHnFhatUiuMRblfSimmGTRVldEWqOqHSZtmwKTENgPEVhAnKsMbZTnlkdtmllWdmBPsKYKXsdZnIvTJKczXQEdeEhpTsotdTnxkKeaaJe");
    bool saSQQa = true;
    bool aTlUIwd = true;
    int LxlswFVLRUBvcXL = 309523600;

    for (int BuVklfitcVNd = 207138091; BuVklfitcVNd > 0; BuVklfitcVNd--) {
        kDihqrwAGd /= kDihqrwAGd;
        kDihqrwAGd -= kDihqrwAGd;
        qQqbnVktHsJhDkq = qQqbnVktHsJhDkq;
        kDihqrwAGd *= kDihqrwAGd;
        qQqbnVktHsJhDkq += qQqbnVktHsJhDkq;
        LxlswFVLRUBvcXL = LxlswFVLRUBvcXL;
    }

    for (int ZCewZPZmuENxbL = 159109713; ZCewZPZmuENxbL > 0; ZCewZPZmuENxbL--) {
        aTlUIwd = ! saSQQa;
    }

    for (int meQQSYee = 273214018; meQQSYee > 0; meQQSYee--) {
        saSQQa = aTlUIwd;
        saSQQa = aTlUIwd;
        aTlUIwd = saSQQa;
    }

    return qQqbnVktHsJhDkq;
}

double gWHMBMzPgDA::XuryIpIfx(bool yXZyfyMRu)
{
    string rfSXRwQyfIHJY = string("JlUNqUklsHXxAemgUDdNsDPPeBaXynbwJpzlpytJPAWiVRjLkbugyQjsbcGZMvUozvKmIVbmBVRsayjoqpjsHDtQIspANuxNbSxoMtFCfjhMbTSwASiGFMcPSzwTWxdNLFxgmkHbPFVnIdvmqTj");
    string grvObtnajUUbHLA = string("qDchOsVKbICDFqRiLzAduIrFDmqlmWCzGYnFHpANQCrgHCmhTKDSPvckDKlYTzRLjDpXkBkTpONoFWkBotHVPWJneJgobciHPGaLljePVSfKUZWjYdTPiBhZgzIvoSuRwRFweYzwwhohyawDujFRlIdzW");
    double PcaZk = -55473.044484637154;

    for (int DWzSoI = 837066156; DWzSoI > 0; DWzSoI--) {
        continue;
    }

    if (rfSXRwQyfIHJY > string("qDchOsVKbICDFqRiLzAduIrFDmqlmWCzGYnFHpANQCrgHCmhTKDSPvckDKlYTzRLjDpXkBkTpONoFWkBotHVPWJneJgobciHPGaLljePVSfKUZWjYdTPiBhZgzIvoSuRwRFweYzwwhohyawDujFRlIdzW")) {
        for (int gUkRsDhb = 357045958; gUkRsDhb > 0; gUkRsDhb--) {
            continue;
        }
    }

    if (grvObtnajUUbHLA == string("qDchOsVKbICDFqRiLzAduIrFDmqlmWCzGYnFHpANQCrgHCmhTKDSPvckDKlYTzRLjDpXkBkTpONoFWkBotHVPWJneJgobciHPGaLljePVSfKUZWjYdTPiBhZgzIvoSuRwRFweYzwwhohyawDujFRlIdzW")) {
        for (int KCMiMgPJaJP = 1506603231; KCMiMgPJaJP > 0; KCMiMgPJaJP--) {
            continue;
        }
    }

    for (int dsIUOuU = 296166912; dsIUOuU > 0; dsIUOuU--) {
        grvObtnajUUbHLA += rfSXRwQyfIHJY;
        grvObtnajUUbHLA = rfSXRwQyfIHJY;
        yXZyfyMRu = yXZyfyMRu;
        grvObtnajUUbHLA += rfSXRwQyfIHJY;
    }

    return PcaZk;
}

void gWHMBMzPgDA::AhgRZfgBOit(double pHqLcELLQJVWty, string EKsEJQJIRBwR, string FeSrerEEKvUC)
{
    int cjFMefKOwzTIWo = 1217272158;
    bool kqkzmOZYqTnntHg = false;
    int pqqTVptQMEhoTXQ = 912487402;
    string RAmZHtLr = string("CjPcEZwDkiYBiGKmxjoV");

    if (RAmZHtLr >= string("gRVargwDCKlitdpIovvAVWppHEqJszsNoyAVKXkctpSmiLWxQQcjZvezkAjNtfakznzyRyVHTmHEzIZAZTRnHYkmlNqJcPThEdzRHlZSZxaAHiZFeLvhbVQztOWUhUzxzweINVxeYvMJvNxelJjkzbngbDwEfdmakIVGHuOeEUeiIGkmoqMIGelitnXRkjtFkLuWjREqjiobeDNbYINbSuPrrAQkPbcchPgexSjWMfncVwfkbUTeKn")) {
        for (int vbvxvCNcjAnp = 17290684; vbvxvCNcjAnp > 0; vbvxvCNcjAnp--) {
            pHqLcELLQJVWty = pHqLcELLQJVWty;
        }
    }

    if (FeSrerEEKvUC <= string("CjPcEZwDkiYBiGKmxjoV")) {
        for (int HazeHbShhGpWQejg = 1025878295; HazeHbShhGpWQejg > 0; HazeHbShhGpWQejg--) {
            FeSrerEEKvUC = RAmZHtLr;
        }
    }

    for (int hFzyyzlrKqxos = 112977348; hFzyyzlrKqxos > 0; hFzyyzlrKqxos--) {
        RAmZHtLr = EKsEJQJIRBwR;
    }

    for (int NjyEtGbs = 271261539; NjyEtGbs > 0; NjyEtGbs--) {
        FeSrerEEKvUC = RAmZHtLr;
    }

    for (int AuchYHa = 1188345583; AuchYHa > 0; AuchYHa--) {
        continue;
    }

    for (int hNGMqCWbH = 1176448752; hNGMqCWbH > 0; hNGMqCWbH--) {
        pHqLcELLQJVWty += pHqLcELLQJVWty;
    }
}

gWHMBMzPgDA::gWHMBMzPgDA()
{
    this->pnmmfY(true, -1661785047, -1031951.5160701238);
    this->GGEIaOcIKge();
    this->XuryIpIfx(true);
    this->AhgRZfgBOit(659789.9647538257, string("KhnqQWkWCGjkDGmEvmwumInodIYILMWwMjYBeXpPvhcYaEAkJBkJhSGG"), string("gRVargwDCKlitdpIovvAVWppHEqJszsNoyAVKXkctpSmiLWxQQcjZvezkAjNtfakznzyRyVHTmHEzIZAZTRnHYkmlNqJcPThEdzRHlZSZxaAHiZFeLvhbVQztOWUhUzxzweINVxeYvMJvNxelJjkzbngbDwEfdmakIVGHuOeEUeiIGkmoqMIGelitnXRkjtFkLuWjREqjiobeDNbYINbSuPrrAQkPbcchPgexSjWMfncVwfkbUTeKn"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zgqNPEJJPSeeO
{
public:
    bool VlbYDeYIH;
    double NFeOXVEXY;
    bool NnbzRhR;

    zgqNPEJJPSeeO();
    int MnhyULPspio(string pPwFXHwcWBK);
protected:
    int SXcFDgvja;
    int pzHxqta;
    int rnJldP;

    void OwAwRlmID(double mhbzBLTjN, int NkBgDl, double MjbYemT, bool RFWpEllGwEbUav, string KTqFudd);
    int PnKRON(double XnLOoIlYDA, int YVDPr, double YzFinAnG, string ddgpqwkLElgibOG);
    int ecnIdpe(double CSonSdJFJPB, int zSnxilnDKwPS, bool KmRXxY, bool auAEkOhYpdEsUO);
    bool syBlUaQArzjgCbrb(string SfpPVEupdoDAJ, double nYPbWhspVgI, double GLZqkUCdW, bool KlCsKALvGkcdI, bool hOLATQuu);
    int psAnnmTzf(bool VcuVimuHGnDXLB);
    double AjZQH();
    int PjNlAU(string mvgYma, bool GYZCzoiiqCx, bool jYMHWiGmjZVu, bool bJRwWxpVF, string dlVpSsROFDyO);
    int gNFBqeKEWu(int zCmmOPGSvDLW, double WdJkpYMhhjULvj, string WduxxFbl, double evLsyZGHqV);
private:
    string ECQroZv;
    int dYAPojZkQbM;
    string uTjKcwphGSxEXYJ;

    void GHumNhhRmpDlSm();
    bool bXiSmWhAiTImo(bool IGMFPGLIDp, string KTKCx, int PQnyPhxH);
    void WHgloIGUgwo(string zGRuJKkYVkzGQoB);
    bool JJzcbqkJfyXc(int hDBgtGu, double lDJDdhXSZIFPwSZ, int CeeAeKmjXzL, bool bixPmRyPsCEkJxsr, double KeQVbzItQNMpmhAV);
    bool NUouWepi();
};

int zgqNPEJJPSeeO::MnhyULPspio(string pPwFXHwcWBK)
{
    bool JCOsgrBRRV = true;
    bool hXbwuMscyAnmPy = true;
    int gZuWbgtjeMzn = -2057194779;
    int ixINwS = 781775832;
    int zQiYVjnImaR = -1477084685;
    bool QTLOXAEZBZomD = true;
    double aQOvuEHFT = -123576.24326191038;
    string fQCHPnbwW = string("SaxAYtsiJRaUOdnyIIlnXvGQnsWvwHyAiRqXgdExmJyNkbTBJaIuH");
    int FxZsctuvPgV = 2016071835;

    for (int tZrwrqJCKCO = 1600308290; tZrwrqJCKCO > 0; tZrwrqJCKCO--) {
        fQCHPnbwW += fQCHPnbwW;
        gZuWbgtjeMzn -= FxZsctuvPgV;
        zQiYVjnImaR += FxZsctuvPgV;
        aQOvuEHFT /= aQOvuEHFT;
    }

    return FxZsctuvPgV;
}

void zgqNPEJJPSeeO::OwAwRlmID(double mhbzBLTjN, int NkBgDl, double MjbYemT, bool RFWpEllGwEbUav, string KTqFudd)
{
    bool zHkGUtULYZOPGmpc = false;

    for (int QSnjMMvhlLBq = 43208820; QSnjMMvhlLBq > 0; QSnjMMvhlLBq--) {
        zHkGUtULYZOPGmpc = ! zHkGUtULYZOPGmpc;
    }

    for (int YGPAQzqteMvaGCj = 185777621; YGPAQzqteMvaGCj > 0; YGPAQzqteMvaGCj--) {
        KTqFudd += KTqFudd;
    }

    for (int uANdmpEshMfQlz = 855981865; uANdmpEshMfQlz > 0; uANdmpEshMfQlz--) {
        MjbYemT /= mhbzBLTjN;
    }

    for (int tMOqKZRVsPjElq = 1926262179; tMOqKZRVsPjElq > 0; tMOqKZRVsPjElq--) {
        continue;
    }
}

int zgqNPEJJPSeeO::PnKRON(double XnLOoIlYDA, int YVDPr, double YzFinAnG, string ddgpqwkLElgibOG)
{
    int huNoDGj = -50711153;
    string OhUurxwqGzeE = string("VvslgKFRqBeMixNlhavSveAiVHmquoiewViPwPZTHeUCSrTRVmqFcBuLIAERjkKLYVuOtitGzjrFvfxEhuzfLvEAmiYYNuCBuwSlppSqszRmdXDXotKFoFAeEHhorfaNPpSbulzTWGjcLgzzdOcFUOLGXUFkYufcSPSJYQprwwXdCJsEmBSDOxbgZcoxKwsRBBhdsgvdWDMepuycPSuPHydRgfOLtSJivxzoxcmNBcAtxFSkFlz");
    bool HPqyx = true;
    bool BrxJvdgvUaBRb = false;
    bool iimmWGFBQXMf = true;
    string oBYfRiNYH = string("OgijgussGpmnzSqcgReQkoDpLNiGZdvFbLwkZrASRUXiMKApQupzBrVxCVafqGSAbbFhsFWJAMivhvYywtTWJjjSVWWGXrzRMoAApbVunbipGxKIHjlbtQTOPSDKODqhvcR");
    string VMNkSd = string("cDxSLzpNZmfZvhjdAhBffTPSkpPIKHFEHIOqbpBlAOGCWZuVgfpubOAWtZTOhQxGuiDVljefqIuUkMzffjOSygIXSLTznurxUNGMQDHanfCWoyfpwPmRLQtVLAGrRorCAmgbxBvRcYUHKzczaHTyXKgTdESiiCfeNMnKbNfqbPXYGnRTA");
    int EJtgzBLWgHnOwwNm = -1073963823;
    string NveuxojzWoEwFfm = string("zlODvZmUAjRuGtibUwURLhWQMbfHZwGdINMtcmKnlknLjhmlxCRbcmByCGFucpHqGMrQoykwpXkDQqNZhseqVKYgEBZRiOUPrZozbXEpQyigrBGImXUjVtNzgBCQkIMeZqMlwUvVTmCbnThNvHdVbagfeqeMUgBmIIJzviponWpWciS");
    double noWLpeqMAnrl = -619066.8202145855;

    for (int AMhGwiGGJexP = 437238416; AMhGwiGGJexP > 0; AMhGwiGGJexP--) {
        OhUurxwqGzeE = NveuxojzWoEwFfm;
        iimmWGFBQXMf = HPqyx;
        XnLOoIlYDA = XnLOoIlYDA;
        huNoDGj = EJtgzBLWgHnOwwNm;
    }

    return EJtgzBLWgHnOwwNm;
}

int zgqNPEJJPSeeO::ecnIdpe(double CSonSdJFJPB, int zSnxilnDKwPS, bool KmRXxY, bool auAEkOhYpdEsUO)
{
    double VuVdBqBUZ = 336660.21070078586;
    bool wisiBQBi = true;
    double znbRpwHATZWeTb = 609181.9794718872;
    bool TyKtDhVPdTPEdGgH = false;
    int XNyafVclEqkDS = -1743727069;
    int DORkt = 1972720396;

    for (int yzOpnhKdObXgkR = 1946172549; yzOpnhKdObXgkR > 0; yzOpnhKdObXgkR--) {
        continue;
    }

    return DORkt;
}

bool zgqNPEJJPSeeO::syBlUaQArzjgCbrb(string SfpPVEupdoDAJ, double nYPbWhspVgI, double GLZqkUCdW, bool KlCsKALvGkcdI, bool hOLATQuu)
{
    int CKOyOWCmzoAga = -467580367;
    int wHeEtr = 490536289;
    bool vtUtH = true;

    for (int ExSLLbiZyyMZ = 1603796313; ExSLLbiZyyMZ > 0; ExSLLbiZyyMZ--) {
        KlCsKALvGkcdI = KlCsKALvGkcdI;
        GLZqkUCdW /= GLZqkUCdW;
        KlCsKALvGkcdI = ! KlCsKALvGkcdI;
        vtUtH = ! vtUtH;
    }

    return vtUtH;
}

int zgqNPEJJPSeeO::psAnnmTzf(bool VcuVimuHGnDXLB)
{
    string CKnJSSUGCmnnJHP = string("yIVZcSTVpYsfUDXHAsPTxtyNdbuJrRhJkHWYxGFtoKBpgIxEtYFOrXvzBQJaTHpFjFpVlIoFkdRlYKUTZmKAvZPuDGeANkemiGvaIivDFYzfDaYNWiyXBVWSnsAunJonlRDPyuzeYvjgQXPwkGThNzhVpPEDiaWtuvxiURnQOKfFIhFwylBGvoBmzvTdvlNrNvrLbNs");
    double vapsrkrYCDLHyh = -241872.60586362678;
    double IVyDZFpgYUOtOCCD = -276244.8765094499;
    string dzrjtm = string("kbkBFwtxzl");

    for (int SUoAq = 900233752; SUoAq > 0; SUoAq--) {
        CKnJSSUGCmnnJHP = dzrjtm;
        VcuVimuHGnDXLB = VcuVimuHGnDXLB;
    }

    for (int MrKfkALvjaEp = 223994005; MrKfkALvjaEp > 0; MrKfkALvjaEp--) {
        VcuVimuHGnDXLB = VcuVimuHGnDXLB;
    }

    if (vapsrkrYCDLHyh != -276244.8765094499) {
        for (int QVqHVZ = 600862805; QVqHVZ > 0; QVqHVZ--) {
            CKnJSSUGCmnnJHP += CKnJSSUGCmnnJHP;
            IVyDZFpgYUOtOCCD *= vapsrkrYCDLHyh;
            VcuVimuHGnDXLB = VcuVimuHGnDXLB;
            dzrjtm += CKnJSSUGCmnnJHP;
        }
    }

    return 1718025303;
}

double zgqNPEJJPSeeO::AjZQH()
{
    int URxkcdloRTAoKeHa = 631783900;
    string wofQA = string("RXBbhBXIlzwKmhTXQParSkQtqrxjwOHtrdxLzjHhxQVjebfZkO");
    double URSXBareuqTK = -621216.9451918534;
    int FFhIgpehUaRqF = -1903896278;
    bool uIFbNgDQfaevoYUC = true;
    double AKIQtY = -989779.3559366263;

    for (int BBsiratrOwbBFJ = 809200279; BBsiratrOwbBFJ > 0; BBsiratrOwbBFJ--) {
        FFhIgpehUaRqF *= FFhIgpehUaRqF;
        URSXBareuqTK /= AKIQtY;
    }

    for (int wxeEhmQYgZnIfVS = 1782588105; wxeEhmQYgZnIfVS > 0; wxeEhmQYgZnIfVS--) {
        URxkcdloRTAoKeHa -= FFhIgpehUaRqF;
        uIFbNgDQfaevoYUC = ! uIFbNgDQfaevoYUC;
    }

    return AKIQtY;
}

int zgqNPEJJPSeeO::PjNlAU(string mvgYma, bool GYZCzoiiqCx, bool jYMHWiGmjZVu, bool bJRwWxpVF, string dlVpSsROFDyO)
{
    bool RljPLtlRzcGRkBR = false;
    bool myzqPqI = false;
    double zvGxbMfTTcdw = -581605.1691177656;
    bool SqAYRRJPn = true;

    if (jYMHWiGmjZVu == true) {
        for (int FXDjZr = 1592410463; FXDjZr > 0; FXDjZr--) {
            jYMHWiGmjZVu = bJRwWxpVF;
            bJRwWxpVF = RljPLtlRzcGRkBR;
            GYZCzoiiqCx = GYZCzoiiqCx;
        }
    }

    if (myzqPqI != false) {
        for (int ojbQFclbwBwgVXvp = 1482670503; ojbQFclbwBwgVXvp > 0; ojbQFclbwBwgVXvp--) {
            bJRwWxpVF = ! myzqPqI;
        }
    }

    return -2053283787;
}

int zgqNPEJJPSeeO::gNFBqeKEWu(int zCmmOPGSvDLW, double WdJkpYMhhjULvj, string WduxxFbl, double evLsyZGHqV)
{
    int xQNqjYCzuxYv = -120190768;
    int zEhHPCmvRf = -577390324;

    if (zCmmOPGSvDLW <= 1451508873) {
        for (int zlSfLoSP = 319491997; zlSfLoSP > 0; zlSfLoSP--) {
            WdJkpYMhhjULvj /= WdJkpYMhhjULvj;
            zEhHPCmvRf /= zCmmOPGSvDLW;
            evLsyZGHqV = WdJkpYMhhjULvj;
            zCmmOPGSvDLW -= xQNqjYCzuxYv;
        }
    }

    for (int nthIbDKhv = 782745193; nthIbDKhv > 0; nthIbDKhv--) {
        continue;
    }

    for (int CiUYEtWHsIZ = 525110944; CiUYEtWHsIZ > 0; CiUYEtWHsIZ--) {
        continue;
    }

    for (int rHRTJZzBvmjFwSDT = 670205461; rHRTJZzBvmjFwSDT > 0; rHRTJZzBvmjFwSDT--) {
        WdJkpYMhhjULvj /= evLsyZGHqV;
        zCmmOPGSvDLW += zCmmOPGSvDLW;
    }

    for (int rXPXGa = 1051107673; rXPXGa > 0; rXPXGa--) {
        continue;
    }

    for (int QCDBMERLYuHKyu = 1771051643; QCDBMERLYuHKyu > 0; QCDBMERLYuHKyu--) {
        continue;
    }

    return zEhHPCmvRf;
}

void zgqNPEJJPSeeO::GHumNhhRmpDlSm()
{
    string hBlJEmQB = string("TIMJHIiRlwiDatJiuDdW");
    int mKKDhbxSQwkIRgA = -742895136;
    bool AsvRMPZUcPLo = true;
    int XlnLQRNXVkEXEkHX = 1701923227;
    int zesDVLnmtsiD = -1139274838;

    if (mKKDhbxSQwkIRgA < -742895136) {
        for (int DzZzJijqodIfz = 356079033; DzZzJijqodIfz > 0; DzZzJijqodIfz--) {
            mKKDhbxSQwkIRgA += XlnLQRNXVkEXEkHX;
            hBlJEmQB += hBlJEmQB;
            XlnLQRNXVkEXEkHX = XlnLQRNXVkEXEkHX;
            XlnLQRNXVkEXEkHX -= XlnLQRNXVkEXEkHX;
        }
    }

    for (int BKDlZ = 1331011811; BKDlZ > 0; BKDlZ--) {
        XlnLQRNXVkEXEkHX -= zesDVLnmtsiD;
        mKKDhbxSQwkIRgA += zesDVLnmtsiD;
        XlnLQRNXVkEXEkHX += mKKDhbxSQwkIRgA;
    }
}

bool zgqNPEJJPSeeO::bXiSmWhAiTImo(bool IGMFPGLIDp, string KTKCx, int PQnyPhxH)
{
    bool MuLPuFzU = false;
    string omRVudiSASrP = string("YWeUWgkuLZeMYIkuENhPjoBMwmiSbKFxCAKAYIgqzVNtYYlYuxYeuZhTMeYAYdKUfcnGsumYLAxZMRUHCFIBHTFLysNYqDjeageCVOHFWRTboMQlzEQreLAbxKdiJSxKoYgamgOTiERmWgCArKpBvbP");
    string GMxdOcPoeNp = string("HiSdWeXmuYrogAkvRJT");
    bool fcQXh = true;
    string BKXqoVAc = string("BQjmzBybJgQW");
    bool gsQRffpfAGTnJj = false;
    bool kdtrWvUJGonCPbD = true;
    string FWZwMpppjEPpVuGH = string("VRSoZkbLPVslWRVRrxQCmWvnnztXyChamXMqLIdfoziaVhtlOQTzGdXGPVCcObpaeoWHhfmqDGmfyDWhCzIwDgGqjdeYQiAyVxaqhWGhNVvYMisqwYCLyVsvtpoEAsNBcXhcgLZFKxJYVbkVEhnpTwPwISpeQYCtgKuTyQOJIqNFQLJmQamYxYKapVpqmalPSEKhMuaKNzLfBKlHxKsqvcUhsDWxXLRUQMWRbObqiSIjOtowgChvEjivpL");

    if (fcQXh == true) {
        for (int BrjkaTsfCslthol = 198019785; BrjkaTsfCslthol > 0; BrjkaTsfCslthol--) {
            gsQRffpfAGTnJj = ! IGMFPGLIDp;
            KTKCx = FWZwMpppjEPpVuGH;
        }
    }

    return kdtrWvUJGonCPbD;
}

void zgqNPEJJPSeeO::WHgloIGUgwo(string zGRuJKkYVkzGQoB)
{
    int zmLqGvoTDAin = 626364250;
    double RoGwYxOTLloD = -712366.5337167392;
    string neGGmU = string("SaPkhxNxINFTwAVOvbBrwDNXHxecrIxSMogFHtjVlJYLQSxMgEjELIvNgAVpLdOOogkGZyGceGhMChRffUNyizcTfDMlodfzlQmdSJjNkYMqsYEmFesnJaIjvQMo");
    int iroRC = 1789342405;
    int UduMrrqelVPDfXwW = -1891548985;

    for (int rWTviWCG = 1323813561; rWTviWCG > 0; rWTviWCG--) {
        iroRC = iroRC;
    }

    if (iroRC >= 1789342405) {
        for (int jOEsifpiwtftRh = 1353624397; jOEsifpiwtftRh > 0; jOEsifpiwtftRh--) {
            neGGmU += neGGmU;
        }
    }

    for (int TfLOAeYRBGKm = 1394528502; TfLOAeYRBGKm > 0; TfLOAeYRBGKm--) {
        zmLqGvoTDAin -= zmLqGvoTDAin;
    }
}

bool zgqNPEJJPSeeO::JJzcbqkJfyXc(int hDBgtGu, double lDJDdhXSZIFPwSZ, int CeeAeKmjXzL, bool bixPmRyPsCEkJxsr, double KeQVbzItQNMpmhAV)
{
    double ejiXZqMHbkyoU = 44279.37241915128;
    int vCZEtdbFMU = -1848805034;

    return bixPmRyPsCEkJxsr;
}

bool zgqNPEJJPSeeO::NUouWepi()
{
    string MfoNTJWNDhv = string("AjVRkVRJUxPTgkHaQjAjPEykcTRNFSCtTTUTOBQYcUrWcGJcGVTmEbMNHbdKBkSbLcYBhZMYLtZYSViOPzYAhnhPhqAOHpfEQNDAUXHoHdQTcWrPSFCZPtZYXlrxCtDRLfzzsRxJRfFSHYaqfemVmWdEsXqUPxOTxJwVFgqIcdkxbTxvofUDdoxaVUbFvYRtFMTcFqMsxfsQYveiZnUWu");

    return true;
}

zgqNPEJJPSeeO::zgqNPEJJPSeeO()
{
    this->MnhyULPspio(string("eUdvLAokNqnrMPcEQPlTEThWzPgkIYfpzxeUTZZpeGVhmvGMNjvYfWtchwtSEuwcahyXrUASEYigGAciVpOOoLGouEZyWMpTcuAUJPAlZvEnxTsZyYsvKDGUNTZNpjzsfObZGbNiMNKxFCaEFxnXtmuNOJ"));
    this->OwAwRlmID(-860174.5682559843, -424915203, -554886.9940077157, true, string("nGwXjqfsAnqLgGvsduywxUPewKZqFDvUKCKtfVnWYCddeCNCXnjeklEMPhsKdulcHxedHIPTmyEgjwazkNNHLnxCoOPUlMtpGPtqEJSfOwWqkItcVtRuXygYdUAEtQFymKmHvXBMuL"));
    this->PnKRON(-124479.80447485716, -1836909300, -307025.4904230513, string("NLLKBfpWLoEChVrefMsSfMUsZhaWihhTOWyxmKgIAYxEXtiXsmvNeImGXGivWLtVbfUkXZLZNsnDqlpSjNVVVkksQcVtwJBSzEwANlXgjfiBByUMaiNJDIjwcYxuyVKkAnJYOyuLRzEDjdaFNHmYyUtUkgyCOUzfsgbruVEYZEDjWBJpfHsqoawSxmncBmKlAy"));
    this->ecnIdpe(-274460.65599414264, 658169252, true, false);
    this->syBlUaQArzjgCbrb(string("vJWbsyqYYbRnijMlyztBTfDQaHgHkyJIAMWsnInqvyDSqkMcCyQwVrxUjribFXFWUIeojCkCkuqVfAoWHiMbPiwGwlLrOhORkDXShIdrdQBzQsOYXjydEKGyMXxBXWRSlrWKUkoNXogkIxpPnBoYSkKlXGJghjwDfUpCztHVnEJJjogOIOglGqZhSEnNCWMN"), 1005865.3012254381, 590171.8999115233, true, true);
    this->psAnnmTzf(false);
    this->AjZQH();
    this->PjNlAU(string("vuhELjtjmpqQEhOAaarnKVtevtzGWrbfSMEypoiVVTrwbugXFMArcBWlGrYxqDIrkVarJDLvJRQZJPGOIuNs"), false, true, true, string("iflxvcCZhBuzGNIwCvmejZfTmnwpZjCvcEuLLLCLBKlZuXApZpGcoslVPaSGlnoEiKAQdEUMUCOjBRzLhVLLBETYrJdVATZbnpafkYZyqdcJehcBJNyvIBbVnqJRKhqSCnvXqhBbDOKHaAgmciEfNjdJppzrxnyRAoksjDuReszUMgaefyHUdpofIGonygmclooRyBkScNENKZZzsMBEsieTYrO"));
    this->gNFBqeKEWu(1451508873, 142765.02077295762, string("lqYYazLovnZmRXrbaMsAQnbrwVJTzVnXlzGzCDHcdpElmgGkeDvYeigmNcPiAogyiEeZNStAEWWQXoSypeiwNDfHxSXxfAQkRAmkpwgUAbndcHprEQpsSZIiNGRQlPXbxGmhKnMMUROuplpPaLHUmLyweusPgVVo"), -127568.65931555278);
    this->GHumNhhRmpDlSm();
    this->bXiSmWhAiTImo(true, string("wCQGppRyjYsobDoXYiaFRBMxwuVdsGLvftiKfapgErWkddeIKgkVcXOBxBnCMUoQIIwyDxlhbeRmsQplFxfXemJMvYAVcQekhJtMGUKTqkfFGYkvklsJOJMoNaXcxiuKuiyPxLmDdvjbNuGFHUpEqvcXdbXrAZKLXGgmZxDxjSC"), -1965655936);
    this->WHgloIGUgwo(string("eWbIVDBDDAqAwNuKLBkNTVYmkwobbyPWAYirdCSPBVrHfbUXGFaYWYyTKvdljqbzBYSsGKMdDOFHqKwrkPLSXwWQqfGPDdtfFUJvCRqCzpvBFWhgpUXwGwooYqa"));
    this->JJzcbqkJfyXc(-1829545719, 12283.518867144296, 1383245216, true, 309028.2470742271);
    this->NUouWepi();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kdhdtuAiXGZfV
{
public:
    string kIjNAE;
    int RBmQshfK;
    string udkGvKI;
    string MKzRvaRunaUQ;
    bool rrgpTulqRrOYCEkN;

    kdhdtuAiXGZfV();
    string MLDROTBim();
    double RfelbpDVPRY(double rgkGTTiVHmcj, bool VWfovcQ, string IPFeVtSkiKa, int haoqxBZGCeAuuk);
    double NwtutRpWW(int zRfpH, double FYDDz);
    void nJMbWrYuDkVYm(int dMpVPzy, string TsnjDGwwPvmDAWk, string iINcrdX, int sJTNyf);
    double pqypVSqhQ(bool vIvyEtTodtn, bool ijHfCkvBlfEgVOst, int dMHXNxshPqmuqm);
protected:
    int YMrUtp;

    int MQuJhVeCSktDFse(double PQGtTT, bool SAiLbTmRxV, int DujDylQq, double evDcPxJiCffU, double limcqivq);
    bool IrLzfsiAN(double jaTREiSDn, string jJjMzEBjMqA, string KaNZM, double SmToMRIWrpt);
    double JRzyQXcnQUGJwOCB(double FgTgE, double RmbCDXhjLOEKcUh, int ORRQQpuGDsxdKi, string nQazbaU, int LZzIs);
    int FDmYknDdZrLAOpT(double FbSxiwjnXnGhGF, double VUpYLmtiv, string UrYKcgrS, string zfJJeyQWraAosOP);
    void WTRyztko();
private:
    bool PuPXap;
    string cboBWf;
    string htWKgwLNRSCh;
    bool fZSeJiLP;
    bool WNiCeVGwjzNGCM;
    int ZwPbzflSk;

    string tLhqjflloQptZOPH(int wZHxSxKcsFUmdeU, double hjZBNc, bool LRIJBVikwAmnL, bool JxhoXbcxEs, int WXamEhG);
    double MeWzaQiPExE();
    string CvQLxGbk();
    int HrcGfCMxntl(bool yeCjPxPSyFtgfPt, double GCaqieqiktr, string LemYiVkGfQrFVeaq, int VmQMsCiaZs);
    string FjeHhKxoyfjI(int JYNVder, bool qdnSaSEPMISr);
    string ikmkKorWChmuw(string WdHJtam, double BuvFqMJ, bool xmlHe, double gVsmUlWK);
};

string kdhdtuAiXGZfV::MLDROTBim()
{
    double CblPMvwCcTnUdMlw = 1029876.2954044422;
    int AKDYPQtm = -95634969;
    int coQOjhCscawV = 546954679;
    int VgzOMfim = -615165622;
    int IksQbkULLRjpKOd = 1150357928;
    double ymmPg = -363569.9186671668;

    for (int gMacGNAXw = 1073776315; gMacGNAXw > 0; gMacGNAXw--) {
        CblPMvwCcTnUdMlw += ymmPg;
    }

    if (IksQbkULLRjpKOd == 1150357928) {
        for (int rMcmgMBOHGnvrw = 402044308; rMcmgMBOHGnvrw > 0; rMcmgMBOHGnvrw--) {
            VgzOMfim /= coQOjhCscawV;
            AKDYPQtm *= coQOjhCscawV;
            coQOjhCscawV = IksQbkULLRjpKOd;
            IksQbkULLRjpKOd /= coQOjhCscawV;
            CblPMvwCcTnUdMlw += ymmPg;
            AKDYPQtm *= AKDYPQtm;
            coQOjhCscawV /= coQOjhCscawV;
        }
    }

    return string("YgdXvBA");
}

double kdhdtuAiXGZfV::RfelbpDVPRY(double rgkGTTiVHmcj, bool VWfovcQ, string IPFeVtSkiKa, int haoqxBZGCeAuuk)
{
    double kQrNl = -526270.297870369;
    bool yzaLkiSzMSr = true;
    double ynxUslT = 65291.416965806966;
    double gWUaJdkx = -56572.821292833;
    string FJymZtONNXz = string("HQzXHhTodC");
    string RlIErR = string("MKNmvMLBp");
    string QgwaeYR = string("oTrcYDQgCieBoAcDCnjlGadWGunBNJLTCgkJvuHEDPjqLJnfpljpzEETjMFQNjPVCLLRGJJEIuhMsTEVGQpxJtzbLRrGAwhfumdBKZrp");

    for (int gdsmkfyRWfgP = 1678871563; gdsmkfyRWfgP > 0; gdsmkfyRWfgP--) {
        RlIErR += FJymZtONNXz;
        VWfovcQ = VWfovcQ;
        ynxUslT = rgkGTTiVHmcj;
    }

    if (ynxUslT <= -526270.297870369) {
        for (int viPsl = 1456913807; viPsl > 0; viPsl--) {
            gWUaJdkx *= gWUaJdkx;
            rgkGTTiVHmcj += rgkGTTiVHmcj;
        }
    }

    for (int MjAajPNPA = 962066835; MjAajPNPA > 0; MjAajPNPA--) {
        VWfovcQ = VWfovcQ;
    }

    for (int vnlgJANWMJxiPuxu = 923991968; vnlgJANWMJxiPuxu > 0; vnlgJANWMJxiPuxu--) {
        rgkGTTiVHmcj *= rgkGTTiVHmcj;
        gWUaJdkx = rgkGTTiVHmcj;
        kQrNl += ynxUslT;
    }

    for (int kziZpniEEVbL = 696486699; kziZpniEEVbL > 0; kziZpniEEVbL--) {
        kQrNl -= rgkGTTiVHmcj;
    }

    return gWUaJdkx;
}

double kdhdtuAiXGZfV::NwtutRpWW(int zRfpH, double FYDDz)
{
    double mNMswP = -169277.27327018764;
    double gMQyxcdT = -886790.8660321105;
    string QXRHyLb = string("sxcMEgq");
    bool chqKMN = true;
    int DTDbcfWTyBAS = -1597717489;
    string SKNpy = string("AHOyqomcqPHvQnnyiJQsKhsLXZgAumdU");
    string ktqcjZRSRQ = string("ttkXXHxEDwpBbNjTCzRWKyamODiiXkkVUyKKrKkrkQugXLXURmHHzdzVsgfHpjbdKRqbcQLnxOPfeAfnDnfOBcnyCYdzBSMMnYbatNDsaklEpsfgCIaPmyvNEIczwnWFWXEDZAaqtQYrPHKjoGJTCaynSyktsUPCdhmTjtwsfVjAmMCXsSrdXrisbEuXnZoiRdjRyktQVjKGLqizNwgsaGwseWIFmeLluAxpMwDQkacQEpCevaiJi");
    int ZzVdqhM = -1439921130;
    double zHQrB = -358103.57686374977;

    for (int txJZoSRDcKL = 1783059978; txJZoSRDcKL > 0; txJZoSRDcKL--) {
        continue;
    }

    return zHQrB;
}

void kdhdtuAiXGZfV::nJMbWrYuDkVYm(int dMpVPzy, string TsnjDGwwPvmDAWk, string iINcrdX, int sJTNyf)
{
    string CBmKZzlkM = string("qFYPXXsqWQnkNcZwTVZfvMsXtGElITfeljGEHXRMEHFwovoVeSbPyRaflXnhHfvDMyCCnrYHaFnMwQbYcTIOVJNwajlZiqlvBRIcgrzjOymyOVCuWxBAasQaeocayHuOTntnANdAIvZAhJWPpMmggFXqA");

    for (int VzsuFNU = 1485508450; VzsuFNU > 0; VzsuFNU--) {
        iINcrdX = CBmKZzlkM;
        sJTNyf -= dMpVPzy;
        CBmKZzlkM += CBmKZzlkM;
        TsnjDGwwPvmDAWk += TsnjDGwwPvmDAWk;
    }
}

double kdhdtuAiXGZfV::pqypVSqhQ(bool vIvyEtTodtn, bool ijHfCkvBlfEgVOst, int dMHXNxshPqmuqm)
{
    int phNmSdlODvU = -261424547;
    double mYKJqkLonXfSW = -89583.78631651495;
    double EZlfZpLyCJO = 291175.0352418315;
    int emNEUfsG = 1860139466;
    double RrziUExZKVpa = 1003780.055434545;
    bool IBrBAal = true;
    int LJmWtq = 2055512029;
    bool HbWwGr = true;
    bool mVaxmIiQjoiV = true;

    if (mVaxmIiQjoiV == true) {
        for (int UoZBCpihFUyUR = 1478585321; UoZBCpihFUyUR > 0; UoZBCpihFUyUR--) {
            continue;
        }
    }

    for (int rCBtnFOOvn = 549217728; rCBtnFOOvn > 0; rCBtnFOOvn--) {
        HbWwGr = ! mVaxmIiQjoiV;
        phNmSdlODvU /= phNmSdlODvU;
    }

    for (int WDDccG = 765211172; WDDccG > 0; WDDccG--) {
        continue;
    }

    return RrziUExZKVpa;
}

int kdhdtuAiXGZfV::MQuJhVeCSktDFse(double PQGtTT, bool SAiLbTmRxV, int DujDylQq, double evDcPxJiCffU, double limcqivq)
{
    int GrLYMbqjcXgPYL = 1155643808;
    string SQuFmOyh = string("TIsHwlYNfPIBviDivJaNtYODHrVVrOQpVtBFuZnFnopbEFTNNlKQPkFqpPuseORlCHNweILWRQvbKuXyrjLPJtRDBvlfIgVaoRBQIKMxRRxOBkYRKistiAeJVKABO");

    for (int ONhuIFVozygn = 1026435152; ONhuIFVozygn > 0; ONhuIFVozygn--) {
        evDcPxJiCffU += evDcPxJiCffU;
        limcqivq += evDcPxJiCffU;
        GrLYMbqjcXgPYL += DujDylQq;
    }

    for (int enoVntuaLuH = 978949671; enoVntuaLuH > 0; enoVntuaLuH--) {
        limcqivq /= PQGtTT;
        DujDylQq -= DujDylQq;
        limcqivq /= limcqivq;
    }

    for (int LVPWnJN = 1452618518; LVPWnJN > 0; LVPWnJN--) {
        continue;
    }

    for (int uyAvjjGVQMmwmGH = 1205128378; uyAvjjGVQMmwmGH > 0; uyAvjjGVQMmwmGH--) {
        limcqivq /= evDcPxJiCffU;
        GrLYMbqjcXgPYL -= DujDylQq;
    }

    if (GrLYMbqjcXgPYL <= 159121317) {
        for (int BmQeKjItptn = 745532781; BmQeKjItptn > 0; BmQeKjItptn--) {
            DujDylQq += DujDylQq;
            GrLYMbqjcXgPYL *= GrLYMbqjcXgPYL;
            DujDylQq *= GrLYMbqjcXgPYL;
            PQGtTT *= PQGtTT;
            GrLYMbqjcXgPYL -= GrLYMbqjcXgPYL;
            evDcPxJiCffU /= limcqivq;
            DujDylQq = DujDylQq;
        }
    }

    if (DujDylQq > 159121317) {
        for (int QhNRMLItVhbHV = 450474642; QhNRMLItVhbHV > 0; QhNRMLItVhbHV--) {
            evDcPxJiCffU -= evDcPxJiCffU;
        }
    }

    return GrLYMbqjcXgPYL;
}

bool kdhdtuAiXGZfV::IrLzfsiAN(double jaTREiSDn, string jJjMzEBjMqA, string KaNZM, double SmToMRIWrpt)
{
    string ZzzgxQwqC = string("JCjKzrVjilQTOuDTJdAl");
    int ynjODRaeUIQbf = -208643822;
    int oDOxodogCciTXar = 83420686;
    int RMxaTNqf = 1281981070;
    string WoTtfuQPPzoZ = string("RXknTTWmPBSLwrZgjFlRFJjdsgtjTxbsoMXZoDkhdzIEDZOtYtbxRuLcNWmreHWIchNcCbjMklFyvAXavyHCuxMlVJpUQctOkcuPenxN");
    bool IrRRu = true;
    string WftNBZ = string("HqqByofTJaAJdYqpXiBxzjDFHALvtWvmxTwiziCKAGJXQzqaOfaiCdAttUdjDfNRMLxXIQnIxxKmezEdeXOoXWUcGTXRvDiVqUzjXcQoLWmEgKSfJZkrimSMaIUxvFEhKSxIKwxKDMapBshXEprydtVAetXSYWEhyXzfSUjCnePnXNUIeWxeffXHzBnlPHjCLotNtvMsUZrElAxjYplgsgyFUwFqRBzoAOnCXrNTlbd");
    double HQdHPtZYi = -903387.3360918977;
    int hugUNheoiA = -51734948;

    for (int kANpRv = 703917845; kANpRv > 0; kANpRv--) {
        WoTtfuQPPzoZ = WftNBZ;
    }

    return IrRRu;
}

double kdhdtuAiXGZfV::JRzyQXcnQUGJwOCB(double FgTgE, double RmbCDXhjLOEKcUh, int ORRQQpuGDsxdKi, string nQazbaU, int LZzIs)
{
    int PASfWAvznesWI = -1101493406;

    for (int MagjJaXVmlOfRhPg = 1846099236; MagjJaXVmlOfRhPg > 0; MagjJaXVmlOfRhPg--) {
        FgTgE -= RmbCDXhjLOEKcUh;
        PASfWAvznesWI /= PASfWAvznesWI;
    }

    return RmbCDXhjLOEKcUh;
}

int kdhdtuAiXGZfV::FDmYknDdZrLAOpT(double FbSxiwjnXnGhGF, double VUpYLmtiv, string UrYKcgrS, string zfJJeyQWraAosOP)
{
    double FUdgXqqq = 416028.405847932;
    double CZhEm = -100080.16382225313;
    int wRVROW = 1351050071;
    double ubkFsweZQT = 536718.9535785074;
    string ukmUcgxJOuHijmuB = string("RZBhxqufuDtDhNgFGmSsMkYYOlvROkBNyCCJefCDvLUwxBeRzrJIyNhSizwZQZfiyWrZ");
    bool rLCRfwxInRmkTLk = true;

    for (int CayuLgvGJFykZgjC = 1651255623; CayuLgvGJFykZgjC > 0; CayuLgvGJFykZgjC--) {
        CZhEm -= CZhEm;
    }

    for (int htMUnSKNtYj = 151166483; htMUnSKNtYj > 0; htMUnSKNtYj--) {
        rLCRfwxInRmkTLk = rLCRfwxInRmkTLk;
        FUdgXqqq *= FbSxiwjnXnGhGF;
    }

    if (zfJJeyQWraAosOP == string("siuLzlaYlOsGPQZgHEXPNaAkMJXUJVmBnjUWDCdRHXCtkpyclnpiQeCmkkpzwrldnNPDeIlLFJCeGgwqaXWiAEsjMydGGgrenuHwywgKWcwbmLPMdASmxcOZrIKdPyyYs")) {
        for (int svAYosHLsOqTRm = 1522493903; svAYosHLsOqTRm > 0; svAYosHLsOqTRm--) {
            continue;
        }
    }

    return wRVROW;
}

void kdhdtuAiXGZfV::WTRyztko()
{
    double dTilQYyaLHdawita = 168691.7471484663;

    if (dTilQYyaLHdawita < 168691.7471484663) {
        for (int VhhnhY = 234413179; VhhnhY > 0; VhhnhY--) {
            dTilQYyaLHdawita *= dTilQYyaLHdawita;
            dTilQYyaLHdawita *= dTilQYyaLHdawita;
            dTilQYyaLHdawita -= dTilQYyaLHdawita;
            dTilQYyaLHdawita += dTilQYyaLHdawita;
            dTilQYyaLHdawita = dTilQYyaLHdawita;
            dTilQYyaLHdawita -= dTilQYyaLHdawita;
            dTilQYyaLHdawita /= dTilQYyaLHdawita;
        }
    }
}

string kdhdtuAiXGZfV::tLhqjflloQptZOPH(int wZHxSxKcsFUmdeU, double hjZBNc, bool LRIJBVikwAmnL, bool JxhoXbcxEs, int WXamEhG)
{
    double BImvhKBrAEdu = -896675.4119596137;
    int EQJNHPCCXUYVlJC = -1638453986;

    if (EQJNHPCCXUYVlJC < 888971755) {
        for (int ofUFJPO = 1368047571; ofUFJPO > 0; ofUFJPO--) {
            wZHxSxKcsFUmdeU = WXamEhG;
        }
    }

    if (WXamEhG > 888971755) {
        for (int UPiVgPArahjl = 1936957175; UPiVgPArahjl > 0; UPiVgPArahjl--) {
            JxhoXbcxEs = ! LRIJBVikwAmnL;
            wZHxSxKcsFUmdeU = WXamEhG;
            wZHxSxKcsFUmdeU /= wZHxSxKcsFUmdeU;
        }
    }

    for (int dDyMfxWxBgAOelCt = 2026892497; dDyMfxWxBgAOelCt > 0; dDyMfxWxBgAOelCt--) {
        EQJNHPCCXUYVlJC /= EQJNHPCCXUYVlJC;
        LRIJBVikwAmnL = LRIJBVikwAmnL;
        wZHxSxKcsFUmdeU += wZHxSxKcsFUmdeU;
    }

    for (int OazcTo = 406478904; OazcTo > 0; OazcTo--) {
        continue;
    }

    if (BImvhKBrAEdu <= -411894.0690593117) {
        for (int UQsyJSj = 988276656; UQsyJSj > 0; UQsyJSj--) {
            BImvhKBrAEdu = BImvhKBrAEdu;
            hjZBNc -= BImvhKBrAEdu;
        }
    }

    return string("YieWklYYsUqwhDMIqNRr");
}

double kdhdtuAiXGZfV::MeWzaQiPExE()
{
    string InfHllazZaU = string("SHHvocQGNpWiogqKXQOptUMRaInnjuaKLfGIUnUJKdqABfuGWHcdvfvpzsjurHiAmVVekIdYjTdiYfAlZYmqPdVsvDsXCaxUJwZvnuuViGmIuSPHsPlxwFQHBfBNuzelnsIOoWickznPNnVwIDpZfkFwqDgVfiISQhcEfhooCAACzSNgHgbPtyXfRcjAUSKPBTpFbsdacPZpHn");
    int TvNTOwBIK = 488488243;
    int xneVRgPddmuZyPOx = -50011983;
    string PiEttJsAmYyRY = string("whnrJYimxhVpNTZkLryCBQCZdiDykleDltXUSeaSvAtKNeXVVrlHFCZcnsWQEOQqFZafEueeubpuWGKjWBRqOsNNpACAahDtgjSjaOijvxddBVhwQkPiFksKQhZHkp");
    bool ArQpYfxrJKTBc = false;
    int GrGRlYMbWJp = 1823813654;
    int ksrZtL = -1780537598;
    bool TxgroFNTz = true;

    if (ksrZtL != -1780537598) {
        for (int OhnOR = 1690957046; OhnOR > 0; OhnOR--) {
            xneVRgPddmuZyPOx -= xneVRgPddmuZyPOx;
            ksrZtL = TvNTOwBIK;
        }
    }

    for (int pXbiKGSQnh = 202075271; pXbiKGSQnh > 0; pXbiKGSQnh--) {
        ArQpYfxrJKTBc = ArQpYfxrJKTBc;
        ksrZtL /= xneVRgPddmuZyPOx;
    }

    for (int PGuXORe = 742450329; PGuXORe > 0; PGuXORe--) {
        TxgroFNTz = ! TxgroFNTz;
    }

    for (int qRYGLCP = 1357929473; qRYGLCP > 0; qRYGLCP--) {
        ksrZtL = ksrZtL;
        TvNTOwBIK *= GrGRlYMbWJp;
    }

    return -259792.0787886788;
}

string kdhdtuAiXGZfV::CvQLxGbk()
{
    int eQgXqHlx = 566082537;
    string YVxbyjOyi = string("KaGtjfqbtQTFcqygfSLZrRdDfoaraJvlzZSwiMzWUvUjFFYeJYpPIbfnxIuqUuHIqnBLOBUmNH");
    bool xYyxTwsO = true;
    bool fMPpqHkFzvNFtU = true;

    for (int AXTtQJKztJPt = 1961981047; AXTtQJKztJPt > 0; AXTtQJKztJPt--) {
        continue;
    }

    if (eQgXqHlx != 566082537) {
        for (int sJYOCWycmJ = 1530820489; sJYOCWycmJ > 0; sJYOCWycmJ--) {
            continue;
        }
    }

    return YVxbyjOyi;
}

int kdhdtuAiXGZfV::HrcGfCMxntl(bool yeCjPxPSyFtgfPt, double GCaqieqiktr, string LemYiVkGfQrFVeaq, int VmQMsCiaZs)
{
    string olfBwfAqAHGKO = string("uSKwoFiinoFvPhodjniViCuMGAzmTUPIaGVcheAkzcvDefKOLCFChOtiUehHrCMuaDTWBkuxjyUJdTMEpsSLbLgvVLmCeoFKhRiLXcOVDz");
    int REzQHcppYks = -1365773987;
    string aXbGaBweVQM = string("iwHBXiAqtCiroUuVRaCVyWqfGOBbmFqvAKPOJxkfqAxPmDqFnHnvubloNxbzuqlprdcAFNzHcoiHyaNlMxBHmIJCNioGqmnsloYnNnpxAfRKecqOCVeOcYkUSGtprJAfJbwpDLRnoNUbDkPzPPQfVYwXAXdOBZYEiwlUfWuvmTefQqSotEZZUlcbwCchucgGjAwAVsKzZiScLPrHQ");
    bool pCoJShnkDshwv = true;
    double dGqPoPiEvSpFhEWK = -520671.94620279095;
    bool GVjjbSwRDwLDw = false;
    int wLdrxuuLT = -49077412;
    double aPgoZ = -327650.4934812958;
    string eBkBWypHtBDCz = string("uMowFbYNkiFIHucuCNDdaNZvBtnQMHjNfnhfDWTEslMSLODyNLrIvWUtuodlLUKpFIGzZ");
    int JvsDpRQICvI = -975311312;

    return JvsDpRQICvI;
}

string kdhdtuAiXGZfV::FjeHhKxoyfjI(int JYNVder, bool qdnSaSEPMISr)
{
    int rhKGyAGsPEH = 1470404973;

    for (int cLjCJ = 1066476007; cLjCJ > 0; cLjCJ--) {
        qdnSaSEPMISr = qdnSaSEPMISr;
        rhKGyAGsPEH -= JYNVder;
        rhKGyAGsPEH -= rhKGyAGsPEH;
    }

    return string("QEQhCObuGEjRsQABByFMEZeVNUiuLUqCCKrELONfgNrsnzjjQlqMTihSQLZpcKHEgYVbvdHdeJXkNCINGZCVOzdlQjwDRtfCqEyGvwdJwHoqigJtZHfZrYYDdECitapWExZGbmqjpgtyeeXCfoUlrJmlfXlKuvCOlPxkOilIsUHHDIvuDKlNqzlQaqoOJLAihEeaJSzmZPqoZzWovdHVZppdrjuxwWFscPZMKNNbakPFWyFtEjBj");
}

string kdhdtuAiXGZfV::ikmkKorWChmuw(string WdHJtam, double BuvFqMJ, bool xmlHe, double gVsmUlWK)
{
    string Rieey = string("BtKQySHRdQLOHRWqKKtZfeNgmWrvaraUAQbytoheyQePSvqiNZWhucxLIfWuloCXrxrEijObopujVtxdseGJOPPgXoIWCxYEelZ");
    bool FeBUZiD = true;
    double cQGmeQOwfNR = 146480.98991017876;

    for (int pwdyyBrbgxc = 358949178; pwdyyBrbgxc > 0; pwdyyBrbgxc--) {
        Rieey += Rieey;
        gVsmUlWK /= gVsmUlWK;
        BuvFqMJ /= BuvFqMJ;
    }

    return Rieey;
}

kdhdtuAiXGZfV::kdhdtuAiXGZfV()
{
    this->MLDROTBim();
    this->RfelbpDVPRY(977085.7212611743, true, string("qrkSkVnVhHYRjjrQByyoPDeFImVbTHuPNeUkrGTdAmckilxtFKUVTwYSqxmJCGweTulRvvabUdfkcXRSedUtcmDXSHMkUfVlRSCFTTdjlKqBGSvFAUZGEKCqEeFgmTNhtpvrdjvHERaFdHPvPxUTFwQqgloH"), -1396516221);
    this->NwtutRpWW(-2068955951, -519490.1205685725);
    this->nJMbWrYuDkVYm(-699707616, string("QzImvjgUkShOyvlwXKfmAUaAwgHzvihArrnZGYMGbgASPUIgywJfflskkqppLNOEztJNAPzrRRFOQqqpitfiVPjRhOPTxjUiauaXgVmDbsxpqYKfJogGSzTqlOwIApRUeQQhJccGPjjXILKpGTkYvJFZuvHyWcfJSatCYTWrCVKNPOYLQQOFjiZpPmLbBsLWXipOZTCCOosO"), string("SEWymhCzTFhJKGgYGdFMaPGzOHpGhPWOSFaaidgIZsbyePRWBIIBCLEMmqJDKoaNlpRVzrtLvfdUuJBxkhjkAi"), 1934359965);
    this->pqypVSqhQ(true, true, 2135399995);
    this->MQuJhVeCSktDFse(862100.2565495898, false, 159121317, -618093.5812315476, 573784.9317500237);
    this->IrLzfsiAN(-682125.5105379904, string("hr"), string("esihJkybFdsUUkiqfCfJJZFPOBNZTTCbokGvSZOoKtnUlkqhdFQQVWGHQcXIojtHyYXKPWiFAoRDcqXgJRECgWEpguptpaXoSVnOgwGgeRccslg"), -862082.7672469659);
    this->JRzyQXcnQUGJwOCB(-532783.29455593, 610394.6578674789, 1051547405, string("dHMnnXtWhQqEVwkMaIUAOrDVpEtsKPQGeDVgazlfrDTKgzrThaHDvPiYeGSyOqhVPBAnzreJybAEzuNsOdrJcyMqzWxPiavxPonGFiPvyPNnuHGssnITjCXdcLliXiDhtjmtQOKjciuQuuzXBVHrtpwEGbGvPpYtI"), -920190154);
    this->FDmYknDdZrLAOpT(-293912.75394256477, 253564.50469260945, string("siuLzlaYlOsGPQZgHEXPNaAkMJXUJVmBnjUWDCdRHXCtkpyclnpiQeCmkkpzwrldnNPDeIlLFJCeGgwqaXWiAEsjMydGGgrenuHwywgKWcwbmLPMdASmxcOZrIKdPyyYs"), string("pXxnnnLmlHOglFJnrbhNmHRaBHgfe"));
    this->WTRyztko();
    this->tLhqjflloQptZOPH(888971755, -411894.0690593117, false, false, -961404373);
    this->MeWzaQiPExE();
    this->CvQLxGbk();
    this->HrcGfCMxntl(true, 823938.9854618846, string("dUdzHaQtjWoNqMNmmmgjHYcJsuKKBoHnXrGdYgnEyvGwQpusXvYiSwUkZrTnXgInTLyNJnaCtFIcDastxQgMdoOeAoRWmGLWRnpbdfBPHbPTYSLWZtVdwEtOGYGTzILGpIuoeXrGXgnUrHEAtcaeVMXoeKJmdzCREnGUkLBqWbmyApW"), 1157179172);
    this->FjeHhKxoyfjI(1937626478, false);
    this->ikmkKorWChmuw(string("zejnSCSeqJxrsBCCPVXXQOxKYBbqtdIxmRNbVZduFrUDlYXMkZAEBgYHZtxZSRyzvpadlGWiHvqKcBDZefKZfhGzBUCpMcEQuYdwzJntLWKVUSgWZySGgWZlOLqXNHEEFRxxeKdcRBRHCWAfCLvJkDTsDOnIoKCgawjUpDukfzWsePSzRKevSObCScNYZINCnlYySkEYmuMSlgRRwCGGDVB"), 645981.7828665463, true, 246442.0989637588);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MjvKuBYHJl
{
public:
    double mhwEdFAtIXRz;
    string QGHujFEunRqVL;
    double kJDLpongIzf;
    int yctTMRwoe;
    bool YCiVNF;

    MjvKuBYHJl();
    int SxHBGkGZMBzxBKZ(string QMhkQlfuzWxuN, string OnbKGZ, double ZJJlcuIvPWTvUIpU, string FClZg, string klxVmzCfr);
protected:
    int yoCugrb;
    bool XYHvTgGOS;

    double tvFvVegATF(bool IlCGidBHsoURAGl);
    void iADDkjEQg(string KaUmCbtM);
    void OTfRpQNmj(bool bJiOAEG, double CRqSfXf, int pIYfTq);
    string INWMXTeAzRQjr(int eDDioUjbn, bool BZhJSXiOAly, bool lMZhPpYMxePNOOA, bool qOQTFJBZFYFQXX);
    void tnVObQ(double bVaGTuineRbv, string IyazGAfXlhypjof, int IAnCnqTkqQ, double hMhGaekkStIRvVY);
    double SMLSfdwIDyFbCWz(bool JNOkBP, int SkgomVpiw, double TtAAqDHSgfRQmh, bool MYadftjcrsCl, bool aXoibOJNtVrbSf);
    int puqulMvl();
    string JRIWixQP(bool wcZJqpTRmTV, string KfazPHQfFYbLp, string BQiZrfkTsTIKBiN, string FKySILl);
private:
    bool qpotB;
    bool PNDJDModsjoD;
    double aqFFtpkVvC;
    double MkDaQqRa;
    int EXCYtxGUBHNfRs;
    bool ntLeJpLQUTkHD;

    double efpuZoqSj(bool RgURwfGKMDKnyXYE, bool hFUequnAzWVTIN, double HIRRXWisYqHTKJXS, int GGzTlrIBEZVkBUh);
    void QnvQbsuw(int jIiWDYEZvBiGmOIh, string begGcZexxKPsP, string mmcnze, int cLRlVRDrIV, double sJEQIDzenSYYcjHy);
    void zbSKug(string DiiaDYxrvVP, double ejjGMLTbrKHbi, bool mVAUw);
    int WtpNicxi(bool kUbuUw, int zqIKblAwdxkaJqzw, int eMJAi);
    int sGDLMwOjuwSSrr();
    bool uuydXmAFjtxAZv(string tSsVmfWq, int TokyZSQQKu, string aaudzhjjArURqWa, bool aopQsIeeGa, string rCpgtFzIsvaXmKq);
};

int MjvKuBYHJl::SxHBGkGZMBzxBKZ(string QMhkQlfuzWxuN, string OnbKGZ, double ZJJlcuIvPWTvUIpU, string FClZg, string klxVmzCfr)
{
    string zUdrD = string("EReyrzmcfqUJGYEpqRyXHqDFJyNylVFfboAyUyHgWAHWlsSEavwpjacOnQcdbNJDRYnqAMgMBqrAYbnPgiCcDhukdfByITwSuYEsyUbjfnsxtlQTovGQaolgZSBKEnfTykSTBGiWkWeLHZDcnyFJVYuYdbxJeBUcnQnUcNFOhNMZKVJGiplGGGVydRlLJItGgmwbRebzoy");
    double kxuMH = 82021.35791754347;
    string IwdSp = string("iInBhAybdQSwRQNTGPnVxZqDrhtVkPCAFsJYNevxD");
    int XlBfcMzNfTlJmTmu = -560810185;
    int mSnjCFyBdTOEo = -37112140;
    double awjdvuGlFov = -651239.9239161125;
    bool ZrgDAhIbQoGLXpSM = false;

    for (int IyqOE = 28091663; IyqOE > 0; IyqOE--) {
        XlBfcMzNfTlJmTmu = mSnjCFyBdTOEo;
        IwdSp = klxVmzCfr;
    }

    for (int ksUrtOQKruhYUD = 1287992410; ksUrtOQKruhYUD > 0; ksUrtOQKruhYUD--) {
        continue;
    }

    for (int FwsVsdjQxYqiJRL = 175655160; FwsVsdjQxYqiJRL > 0; FwsVsdjQxYqiJRL--) {
        continue;
    }

    if (zUdrD != string("iInBhAybdQSwRQNTGPnVxZqDrhtVkPCAFsJYNevxD")) {
        for (int ojdJzNAlgfg = 1233131532; ojdJzNAlgfg > 0; ojdJzNAlgfg--) {
            XlBfcMzNfTlJmTmu -= mSnjCFyBdTOEo;
            kxuMH -= ZJJlcuIvPWTvUIpU;
            kxuMH /= ZJJlcuIvPWTvUIpU;
        }
    }

    for (int dEcwcHtSbb = 1676632784; dEcwcHtSbb > 0; dEcwcHtSbb--) {
        continue;
    }

    for (int iwWYsGPRiKxGHZ = 1577381298; iwWYsGPRiKxGHZ > 0; iwWYsGPRiKxGHZ--) {
        FClZg += klxVmzCfr;
    }

    return mSnjCFyBdTOEo;
}

double MjvKuBYHJl::tvFvVegATF(bool IlCGidBHsoURAGl)
{
    bool xCwQT = true;
    int qryyHYp = 536054731;
    double LmKIuXcvGTIi = -48533.291664350574;
    double zhFPotG = 700598.9891954362;
    string EQAKGbtDXEbFNIxf = string("gTDarIaEeMkDeoKOgaZcFTZebVJOVbxBxXJylGstCNioBgrHCToBTWvAVPFpazbOuFIcJbxaARDOnEiZSOI");
    double dkBtA = -815990.6889341313;
    double gYlIRMh = -514228.6239026822;
    bool rzixRLcCsNh = false;
    string QCPhTpS = string("WfEHXmOapBRFYzbeePnATiwwkNHSVZdGUDROsgTCGZyY");
    int PTSPlbMNQtkx = -364100278;

    if (rzixRLcCsNh == true) {
        for (int ohXDfsKGeioWKrND = 614811041; ohXDfsKGeioWKrND > 0; ohXDfsKGeioWKrND--) {
            continue;
        }
    }

    for (int DiKXvpiTAWRr = 2039311394; DiKXvpiTAWRr > 0; DiKXvpiTAWRr--) {
        zhFPotG -= gYlIRMh;
        EQAKGbtDXEbFNIxf = QCPhTpS;
        xCwQT = rzixRLcCsNh;
        dkBtA /= gYlIRMh;
    }

    return gYlIRMh;
}

void MjvKuBYHJl::iADDkjEQg(string KaUmCbtM)
{
    bool eQUJR = true;
    bool umcqBapsbWVFfYZP = false;
    int fkUhbBEKZrx = 1142488763;
    double vlxTA = -592242.2818040656;
    bool UrzyfSqNVR = true;
    int ygeuMbsyxcIFY = -865550707;
    double aigFX = -134736.77404757412;
    double CKbxTsfpC = 449731.4806431588;
    int efNUveaym = -654803077;
    int CDFkUgOd = 406354710;

    if (CKbxTsfpC > -134736.77404757412) {
        for (int BySdCTTPSFyxu = 243737250; BySdCTTPSFyxu > 0; BySdCTTPSFyxu--) {
            eQUJR = eQUJR;
            umcqBapsbWVFfYZP = ! umcqBapsbWVFfYZP;
            fkUhbBEKZrx /= fkUhbBEKZrx;
            vlxTA = vlxTA;
            ygeuMbsyxcIFY = ygeuMbsyxcIFY;
        }
    }

    for (int zVDRKmnG = 1862024167; zVDRKmnG > 0; zVDRKmnG--) {
        UrzyfSqNVR = ! umcqBapsbWVFfYZP;
        UrzyfSqNVR = eQUJR;
    }

    for (int rMErBHngsdbgLdTN = 137738623; rMErBHngsdbgLdTN > 0; rMErBHngsdbgLdTN--) {
        aigFX += vlxTA;
        eQUJR = umcqBapsbWVFfYZP;
        fkUhbBEKZrx = efNUveaym;
    }

    for (int AuCTC = 993773238; AuCTC > 0; AuCTC--) {
        CDFkUgOd = fkUhbBEKZrx;
        aigFX += CKbxTsfpC;
        efNUveaym = CDFkUgOd;
    }
}

void MjvKuBYHJl::OTfRpQNmj(bool bJiOAEG, double CRqSfXf, int pIYfTq)
{
    int mmFCDQXqwuU = -413887232;
    double sdeybRemeyvllKpM = 639688.4908792911;
    int OqfGdq = 1116778915;
    int IeJWoPXsf = -561154952;
    bool KicIMuaL = true;
    string ZeqJrWuGXlqJ = string("FwuphToSvVtJdceJkJPgwgCksRiShvBvTTFXIKKPlAArgIUJCdiimYIRacPXsuxxKaMtCKcNhHwEgNdijauATwBQsvyXGFsXMNIUn");

    for (int aWKJnnNNG = 1617075182; aWKJnnNNG > 0; aWKJnnNNG--) {
        mmFCDQXqwuU /= mmFCDQXqwuU;
    }

    for (int eyvVMYk = 24490826; eyvVMYk > 0; eyvVMYk--) {
        IeJWoPXsf /= pIYfTq;
        pIYfTq -= mmFCDQXqwuU;
    }

    if (pIYfTq <= 713508946) {
        for (int PsXjDUARRk = 1380436563; PsXjDUARRk > 0; PsXjDUARRk--) {
            IeJWoPXsf *= IeJWoPXsf;
        }
    }

    for (int DIiTQRf = 1807541754; DIiTQRf > 0; DIiTQRf--) {
        mmFCDQXqwuU = OqfGdq;
    }

    if (bJiOAEG == true) {
        for (int tPsrwK = 1675859366; tPsrwK > 0; tPsrwK--) {
            OqfGdq -= OqfGdq;
            sdeybRemeyvllKpM += sdeybRemeyvllKpM;
            OqfGdq *= OqfGdq;
        }
    }
}

string MjvKuBYHJl::INWMXTeAzRQjr(int eDDioUjbn, bool BZhJSXiOAly, bool lMZhPpYMxePNOOA, bool qOQTFJBZFYFQXX)
{
    int xuMYBViz = -1394536387;
    int UmZpC = 7318501;
    bool quVOVrW = false;

    if (qOQTFJBZFYFQXX == false) {
        for (int NhEmkAyPygLuka = 2066769485; NhEmkAyPygLuka > 0; NhEmkAyPygLuka--) {
            xuMYBViz = UmZpC;
            xuMYBViz -= xuMYBViz;
            qOQTFJBZFYFQXX = lMZhPpYMxePNOOA;
        }
    }

    for (int UODIUR = 535138357; UODIUR > 0; UODIUR--) {
        UmZpC /= UmZpC;
        BZhJSXiOAly = lMZhPpYMxePNOOA;
    }

    if (UmZpC > -1394536387) {
        for (int ejURAaOHunlyfxe = 911156216; ejURAaOHunlyfxe > 0; ejURAaOHunlyfxe--) {
            eDDioUjbn -= xuMYBViz;
            quVOVrW = ! quVOVrW;
            eDDioUjbn += UmZpC;
        }
    }

    for (int ujKDoeTrabRMWJgZ = 1846956734; ujKDoeTrabRMWJgZ > 0; ujKDoeTrabRMWJgZ--) {
        qOQTFJBZFYFQXX = ! lMZhPpYMxePNOOA;
        lMZhPpYMxePNOOA = ! BZhJSXiOAly;
        eDDioUjbn *= xuMYBViz;
    }

    for (int AqpYwGPXYbYphEU = 1974308721; AqpYwGPXYbYphEU > 0; AqpYwGPXYbYphEU--) {
        lMZhPpYMxePNOOA = ! BZhJSXiOAly;
        lMZhPpYMxePNOOA = qOQTFJBZFYFQXX;
        qOQTFJBZFYFQXX = qOQTFJBZFYFQXX;
    }

    return string("nebEgvCgYbXQhNExLglfkQihLoyMOGOqeiaCccLGovlZEmwfXcWGHMFCufzcQmVbkSFjsWiKHbYDcBsmNoKaOlHeBWOQdXxDUTTiCOAASBFZSUYAMoVxvBEbLKXbqaeoUlHtBYDeICnWMBQOXIJeFftJqmUlnGEqeihMiqTIkqnpYZCtonsKDJbQwwIvhRsRhXeOeYRscfWlAEcexmBzsCCDxvmZPKvLQkVpmY");
}

void MjvKuBYHJl::tnVObQ(double bVaGTuineRbv, string IyazGAfXlhypjof, int IAnCnqTkqQ, double hMhGaekkStIRvVY)
{
    double UsyRGeOp = 510988.58918884787;
    bool DclPaCicp = false;
    string HceDDZhWxHeihUN = string("CNdlZzhbDSaRgilmRQqZKHlRYhldtDJDiZxkcGWSyNonVEEKpJjmlAOgkhJavudTWOrsVjkNefaiAHPCOQDyzNNcSpYSxHBgsaUCjjkcptNrJNVhkkAWksrYDvKXD");
    bool HuKxOHmSvZEAPoU = false;
    int ZiExPE = -112691972;
    double wDVdJFls = 642087.9551136496;
    string LVArkvbaletjv = string("cTEyoQAklwWBbQZvbDzaREOBTLGPcFRUaTgKgPwfROZZPaRBLgpIMHrOPwiJgtJcluZYMptYWHNCXdIlzzCKpBWBmTFyTSsuWdzKbyuTLoBPAFxeCccVaZMzxNJYxvuEiwcpWTXnYTwxijgCfAySrYDhxqFNqHRitunxNsaNKloCVcpuYilKeEjUaUThQeQfeZoGVuojrGRZIgozdTJNIrHyVnjglxMsdokiuwgynQZywpjVlcFCH");
    string TUxaexpMJy = string("sXxqYWtjnLWQiBhTwlrnpsoqVSiSWTmLVPvWWATexSujmsKiQuQsSQgPJVosbnjZFyIpkbWEsbymrteHskbqeYLoqIBluyTxwSflBqLTakqVifAUnwiJSNgotgKVFIwcjpuRihteypwlarKgMJSGdZpWHzmVnrHNjpbRrpcOKVVBsCacCnsFYRrqNYhuThtktHzCxjOmpZrOZbzMM");
    string oZTfElaV = string("KJhrAjAvrDxWQySAnkWFURSjxajvnpKobtbqviFQAi");

    for (int JRAEbsNitJAn = 1096475362; JRAEbsNitJAn > 0; JRAEbsNitJAn--) {
        continue;
    }

    for (int NOMdIoD = 1775513342; NOMdIoD > 0; NOMdIoD--) {
        continue;
    }

    for (int YMWWRJjSU = 1451061539; YMWWRJjSU > 0; YMWWRJjSU--) {
        IAnCnqTkqQ -= IAnCnqTkqQ;
    }

    for (int NfcqiUCreX = 209654459; NfcqiUCreX > 0; NfcqiUCreX--) {
        continue;
    }
}

double MjvKuBYHJl::SMLSfdwIDyFbCWz(bool JNOkBP, int SkgomVpiw, double TtAAqDHSgfRQmh, bool MYadftjcrsCl, bool aXoibOJNtVrbSf)
{
    double esSPoQlvkYUIt = -695783.7607591694;
    int OzvwHNCqYKbmFik = -312198557;
    string RXZrhkG = string("vbaOyvHxolPlfiqSlWHkXrhvCirOgkVoEsLaHmqzYZPBaGCUOoAplbTEjTYVqUXsCguUFxVlQyxtKtXqluyKUjygYsDcFJWNytoickUGlSkgbNRiVjBabUPaGgGqONgEOdkCQBThGITMkPhQCuHOxzRNmrymZfwlvgBraOMlwrIBnLGsLTzsSpHrdtdCyzwzyoWVWOhddnvfANFxJMGUJp");
    double sNTjMSsQb = 924208.5094488822;

    if (aXoibOJNtVrbSf == true) {
        for (int BzQuJwchYEVYqGf = 1274872223; BzQuJwchYEVYqGf > 0; BzQuJwchYEVYqGf--) {
            MYadftjcrsCl = JNOkBP;
            esSPoQlvkYUIt /= sNTjMSsQb;
            OzvwHNCqYKbmFik /= SkgomVpiw;
        }
    }

    for (int AEGDXvOILpYf = 1762921015; AEGDXvOILpYf > 0; AEGDXvOILpYf--) {
        aXoibOJNtVrbSf = aXoibOJNtVrbSf;
    }

    for (int RDpMaqFPvXIfwYz = 2001374464; RDpMaqFPvXIfwYz > 0; RDpMaqFPvXIfwYz--) {
        continue;
    }

    return sNTjMSsQb;
}

int MjvKuBYHJl::puqulMvl()
{
    double JUfbV = -381591.1122745558;
    bool TZLZyhnzfLzaNJ = true;
    int CBDUBkRE = 2132950717;
    string rmAcOwSChxzhtMY = string("UYVGivnswWGYhcakXCQRlkLtRcRsMnYOpYDvARnTkPmTEpduKdQJjBTnMfkEYMV");
    bool zWZclHxEJWh = true;
    bool nPesOr = true;
    bool itpLdQofeAkY = false;
    string xADOfgKn = string("vZrKanOCjsndVESnGpSTsjIqGfHGmEvKMEEyekqxPbYraAvlhcXoJrkfwlTasFYBipiQKfuHPigTQDfTufInGmtKuDQXZthscqZZeqQiWvEqcwnveUIBgKGqoABtpCkuiVyqJbZqJrNqqbukIsHAKSHGhXrMItxXOaBAPwTgFRhkRWSCFHbDwmMnSXrdaMlCAWzASExvdPoWFiXxbkjLQjWqcoNEkOtUEuswpTMjtzzKDTJdg");
    int bKroof = -265572771;
    int YIVUQ = 478887404;

    for (int oqsaVHSv = 250415783; oqsaVHSv > 0; oqsaVHSv--) {
        zWZclHxEJWh = TZLZyhnzfLzaNJ;
    }

    return YIVUQ;
}

string MjvKuBYHJl::JRIWixQP(bool wcZJqpTRmTV, string KfazPHQfFYbLp, string BQiZrfkTsTIKBiN, string FKySILl)
{
    int OhJmBizJ = 232632499;
    string NIEiBlZonpo = string("y");
    double ksZhRyffYXH = 12152.43997291232;

    for (int BABWrHLheKN = 427415747; BABWrHLheKN > 0; BABWrHLheKN--) {
        BQiZrfkTsTIKBiN = BQiZrfkTsTIKBiN;
        wcZJqpTRmTV = ! wcZJqpTRmTV;
        KfazPHQfFYbLp = FKySILl;
        wcZJqpTRmTV = ! wcZJqpTRmTV;
    }

    for (int PxjweaHupIaUzrcw = 461580904; PxjweaHupIaUzrcw > 0; PxjweaHupIaUzrcw--) {
        KfazPHQfFYbLp += BQiZrfkTsTIKBiN;
        FKySILl += BQiZrfkTsTIKBiN;
    }

    return NIEiBlZonpo;
}

double MjvKuBYHJl::efpuZoqSj(bool RgURwfGKMDKnyXYE, bool hFUequnAzWVTIN, double HIRRXWisYqHTKJXS, int GGzTlrIBEZVkBUh)
{
    double PysUjPsogqSTEKMY = 716557.0239831249;
    string TVvYwdZnBWErX = string("GRGPMXlhsUbbpztrieFJVGZfRQWrNVzgTyTXFEmwoBHfPkEXtjGQJIryodG");
    double fiRcN = -382140.6791267811;
    string FQHbusjAnBIcOEE = string("QswsUZuhUI");
    int yrTeTZye = 1184370530;
    bool vuQpqT = false;
    bool yZREvWpSHG = false;
    bool cFSUE = false;
    string JNyPXxeA = string("kSGCxpmzjfqwakZDarZKDxpcDaZqNmOgvPSvCkgcVFBxKAowNKBZtRYpBMolxNrravawqrJWZMPfsPVwgkRsxybfQhZoFTfWAqbUJOaGVeGkZhXqMVrZJfsfagPdvwYKsVUSDRtDbmvnQwETpmEuGMTaihxUIlfQnJcIhbCGyBkNcLddPGDeDDuXTNTrunzYHzh");
    string yQhby = string("PowHLTDgZbFoQSQuXXUVesAasQXYwbRwwmrMEPjWpQzeyjkQKS");

    for (int JbCje = 2013657518; JbCje > 0; JbCje--) {
        yrTeTZye += yrTeTZye;
    }

    for (int rQtxhay = 1632868156; rQtxhay > 0; rQtxhay--) {
        JNyPXxeA = TVvYwdZnBWErX;
    }

    return fiRcN;
}

void MjvKuBYHJl::QnvQbsuw(int jIiWDYEZvBiGmOIh, string begGcZexxKPsP, string mmcnze, int cLRlVRDrIV, double sJEQIDzenSYYcjHy)
{
    bool rylrszQgqshQEow = false;
    string kzEDnPoW = string("hWdgaMdhVtdOBUntZccIFQuWFeRYeAIdTJWOSaKVlTudhuEMlewaKZmcyBjNhChdldJfLQXzsOcshVbiKFoRPuWKOvBtkgyeiQNqWvMjvfJCRKIJNEDoCBMtjgxdMpRZvgianHHdmqnLVpemaJaObBMilZKvNOThkNArPYnU");
    bool PSLFepkuGjpPLYqn = true;
    int mFAymWPKhvbj = -42662722;
    double PXdRCMYhDkTjvvF = 257449.69951090598;
    double RqVwIkEHzRe = 721157.6830259492;
    double GJrgLDcMYDiOd = 237157.97422598922;
    double KeAFry = 878216.2365844189;

    if (KeAFry <= 1027151.7499886169) {
        for (int iCRKukEFiZqgC = 1413666112; iCRKukEFiZqgC > 0; iCRKukEFiZqgC--) {
            begGcZexxKPsP = begGcZexxKPsP;
            PSLFepkuGjpPLYqn = ! PSLFepkuGjpPLYqn;
            begGcZexxKPsP = begGcZexxKPsP;
            mmcnze = kzEDnPoW;
            KeAFry = GJrgLDcMYDiOd;
        }
    }

    if (RqVwIkEHzRe <= 1027151.7499886169) {
        for (int ZXQEkeGoN = 1189712799; ZXQEkeGoN > 0; ZXQEkeGoN--) {
            mFAymWPKhvbj = mFAymWPKhvbj;
        }
    }

    for (int pPwxW = 1581370442; pPwxW > 0; pPwxW--) {
        PXdRCMYhDkTjvvF = sJEQIDzenSYYcjHy;
        PSLFepkuGjpPLYqn = ! PSLFepkuGjpPLYqn;
        PXdRCMYhDkTjvvF *= KeAFry;
    }
}

void MjvKuBYHJl::zbSKug(string DiiaDYxrvVP, double ejjGMLTbrKHbi, bool mVAUw)
{
    string hHvIYTeWpX = string("CmcNLKnAeRgeMohNgusHcoXoPznISPBdFZeBzzlltbnLgtvUHQKujECfjfleBjpDUHiBylYVqOUYryJPEWPxXFeRMxdqbIVDcPPhNCHsgmxLlqFTfvCjJWEctfTmsmPOsHZNNYnbUkxGu");
    int KVUzGqxpiKw = -776663649;
    bool MvShPGNp = true;
    bool RPIRfWqDVEnY = false;
    bool FhDKNyVXS = false;
    string awbBPgXaW = string("cnlgSMOpHMlJWpFEOlTKGSqPLswhEpaVPenniWspqCCbTGVdCJYKiWxrXEpXemVQQZJjnfKhugxNlfAKIJPnGtgPtuqtoFkRrbX");

    for (int xDjrAiq = 127444623; xDjrAiq > 0; xDjrAiq--) {
        continue;
    }
}

int MjvKuBYHJl::WtpNicxi(bool kUbuUw, int zqIKblAwdxkaJqzw, int eMJAi)
{
    bool xabekoiw = false;
    double YuXGLgAUFSdFsg = -121480.74899530911;
    double ZylOkajbbmMZzO = 171273.2336364798;
    int JoaAwMiiS = -484701285;
    string xomxxsvH = string("hVkRfQdLaeRRTqvFQDQXlhHfGIjECUUBWXeSVhByhHBBOoqDKNmcBpcEeufqWbuzMplxYViTyeua");

    if (JoaAwMiiS > -484701285) {
        for (int xsGBaMaFmflsoHbG = 1185862250; xsGBaMaFmflsoHbG > 0; xsGBaMaFmflsoHbG--) {
            kUbuUw = ! xabekoiw;
        }
    }

    for (int MUIXNoNMgTO = 2038444338; MUIXNoNMgTO > 0; MUIXNoNMgTO--) {
        eMJAi -= zqIKblAwdxkaJqzw;
        zqIKblAwdxkaJqzw /= JoaAwMiiS;
        YuXGLgAUFSdFsg = ZylOkajbbmMZzO;
    }

    for (int LeGHiLVSOEJ = 369152720; LeGHiLVSOEJ > 0; LeGHiLVSOEJ--) {
        JoaAwMiiS -= eMJAi;
    }

    return JoaAwMiiS;
}

int MjvKuBYHJl::sGDLMwOjuwSSrr()
{
    string yVcEFlvVLL = string("DHKQnIDFmAbRHYrPnilmlYfJKFNjvwURZIobUJkJBbjhjWzHJynBeKCvUloZvwIZUQWFZNJyeJmwgpHUCEzdBHsuhvtdBBHjXoEikGKRVtjVQuaueQVRvGinsLDuyxvbrjqalJEA");
    string DSUriPyJLRneqVNU = string("gDEMNiugPkogmwTQXUGWlbfnxvGkqEhsJDbxpUVStkxZdBEEFCezEXnPibICEZYvVdpRoACtjueIhC");

    if (DSUriPyJLRneqVNU >= string("gDEMNiugPkogmwTQXUGWlbfnxvGkqEhsJDbxpUVStkxZdBEEFCezEXnPibICEZYvVdpRoACtjueIhC")) {
        for (int UaVxKqjwP = 1218918891; UaVxKqjwP > 0; UaVxKqjwP--) {
            DSUriPyJLRneqVNU += DSUriPyJLRneqVNU;
            DSUriPyJLRneqVNU = DSUriPyJLRneqVNU;
            yVcEFlvVLL += DSUriPyJLRneqVNU;
            DSUriPyJLRneqVNU = DSUriPyJLRneqVNU;
            yVcEFlvVLL += yVcEFlvVLL;
            yVcEFlvVLL += yVcEFlvVLL;
            DSUriPyJLRneqVNU += DSUriPyJLRneqVNU;
            yVcEFlvVLL += yVcEFlvVLL;
        }
    }

    if (yVcEFlvVLL != string("DHKQnIDFmAbRHYrPnilmlYfJKFNjvwURZIobUJkJBbjhjWzHJynBeKCvUloZvwIZUQWFZNJyeJmwgpHUCEzdBHsuhvtdBBHjXoEikGKRVtjVQuaueQVRvGinsLDuyxvbrjqalJEA")) {
        for (int sJkCWpMPzrbUkFh = 943085695; sJkCWpMPzrbUkFh > 0; sJkCWpMPzrbUkFh--) {
            yVcEFlvVLL = yVcEFlvVLL;
            DSUriPyJLRneqVNU += yVcEFlvVLL;
            yVcEFlvVLL = yVcEFlvVLL;
            DSUriPyJLRneqVNU += yVcEFlvVLL;
            DSUriPyJLRneqVNU += yVcEFlvVLL;
            DSUriPyJLRneqVNU += yVcEFlvVLL;
            DSUriPyJLRneqVNU = yVcEFlvVLL;
        }
    }

    if (yVcEFlvVLL > string("DHKQnIDFmAbRHYrPnilmlYfJKFNjvwURZIobUJkJBbjhjWzHJynBeKCvUloZvwIZUQWFZNJyeJmwgpHUCEzdBHsuhvtdBBHjXoEikGKRVtjVQuaueQVRvGinsLDuyxvbrjqalJEA")) {
        for (int mvbTAQeuHZCsh = 1755000089; mvbTAQeuHZCsh > 0; mvbTAQeuHZCsh--) {
            DSUriPyJLRneqVNU = DSUriPyJLRneqVNU;
            yVcEFlvVLL += DSUriPyJLRneqVNU;
            yVcEFlvVLL += yVcEFlvVLL;
            DSUriPyJLRneqVNU += yVcEFlvVLL;
            DSUriPyJLRneqVNU = yVcEFlvVLL;
        }
    }

    return -1823162712;
}

bool MjvKuBYHJl::uuydXmAFjtxAZv(string tSsVmfWq, int TokyZSQQKu, string aaudzhjjArURqWa, bool aopQsIeeGa, string rCpgtFzIsvaXmKq)
{
    string NPcotDhdJQ = string("wGvoQnmCnkmsXuJLVJHWgYvtEXFQoeQIUGxuUTxejzjMaNnMdsVHGfJyvnsqqsfKzdIGIJdcteYFSHqXYBiWemMQMzGpFAzwMeZbNiuRtLfN");
    string KlczWorkeZVSs = string("UVwTqIagpjdhkaYILbKPBiPPVUrWOkWOPywggJhjBiBHHsFKoywtaiKbGwotYSnaQMAuXFvUlTpqrNIcgXwJMw");
    bool YiAVsUC = true;
    int ONpFK = -1757884466;
    bool SlxlUNotXP = false;
    int IcnlRAE = 1400627900;
    double PiDjsnBPrpPOgha = 990665.9719590395;

    for (int yrmSb = 1307907724; yrmSb > 0; yrmSb--) {
        tSsVmfWq = tSsVmfWq;
    }

    for (int jCnTTS = 1209484178; jCnTTS > 0; jCnTTS--) {
        YiAVsUC = aopQsIeeGa;
        aaudzhjjArURqWa = KlczWorkeZVSs;
    }

    return SlxlUNotXP;
}

MjvKuBYHJl::MjvKuBYHJl()
{
    this->SxHBGkGZMBzxBKZ(string("fxnTXXwtaVmNjCbnYvDoxXHmivQuTfKwDNGZTdYzDuabigrvmoxogUhtIyzUfkGiPhhanwxMpPaaStfFBJiTXkOnSUuDOBrsOhlwZxmOukXvMQhcTvxbqlUTRLNYHzmClZpaEgdvmAnpbrwQkaYzkGVCUzzKYJAcgctXFVOjnTUadwGPfsVCZbRzHOWpapkLxjUncVqQoJtfIFdGPrPQIbntgJpuSUEhrMsSRJFmwPoqgaXy"), string("slOyCzfzPEtxxfukIHGOicHkyVQuYZbkbppRPXYJjszjgQipfDkezLuJKcgmxxeLoJxAkDUaBECIoUVwMjLlZwpneCCnyxPNKsWRiXBwRIlpJDnreRWjnZVgHbBmczMBINAnWsXCvdkSvbFVxHPywdIUqWlxkBgUsffRZ"), -785093.8969040645, string("BUMhjysEGCsbvxdfdmlRppayzxXFeBoFvOdLuJotyRYHAVXGYCHDHfrBIiiHuQwXCelonOgNrjKgGIPtYvbGZsqeKgAbJKYhkGKeGMGrayjYfqtxTWvmyBjnpIOwZLaUsUmDCOPTwhNLZsMYnpjvixiXZlOdoWTDJlSAUeXMjVEvGZBk"), string("YpECsAXArLojUhWymqEjLKuWOxXOSdzSkQqxIQcJDhVsTVUJFVj"));
    this->tvFvVegATF(false);
    this->iADDkjEQg(string("NDPRQicpZwrYMwBMiTNgfcSFQIvCduPxvvYKYiLRjdsjEdFfRdQwJFWkQEwOWTzBmWvaAmjKMuohQjpQCwycJVUYTwlglGqNDSwWhaMMRTbfIsYzhZCmeITOPdekTYxxdiCDvtRfArYcPnPYhOdsHvpICcxmaOpZCpOjUWCPLRnfDnUOANIUyNEPDssyrR"));
    this->OTfRpQNmj(false, 942878.9757259375, 713508946);
    this->INWMXTeAzRQjr(-130419841, true, true, false);
    this->tnVObQ(722861.5449127537, string("BZyzjBTcIKvTXsXGLgRVVknzkIvwSoxzYsrvqDCzzMWdLizMWmnstUsHSjKsvlaCeMxyzLyVuvCRDarccbJZGvYMEyoUvBeuddPOtEPLnxBANCrjNNNOzyyJndqoVYsfScAkxGlTNVbPYDRKrBJFnIBWywQkHpoHbTxlUmgXpKrLwZJNuduORirCMeStqbQhzltqoKBvmJQqd"), -1057211616, 979468.0154768124);
    this->SMLSfdwIDyFbCWz(true, -275375841, -945038.8756891997, true, false);
    this->puqulMvl();
    this->JRIWixQP(false, string("UtYCviYNhtqTJmXANtLUhmrNOOCoKLbbdxWQiAPitRoOGYGFJeHRtoqISyaKhyIptRAeineiEHNeCCTsORZVQwwQwJftGbaAXYiviZhEgSJwijUcmSHmbphSpatEupclvlRvJUxillzxvsEbAWrewAambTwPAZxHVwTciJzPmbrbsvvRuwjgOmMwKHW"), string("vPCXobfcuVAbiLsSYmQsMCFpdOnI"), string("GUpwmjRIgwVVbMIWinOoWeVzJfjptOUYlgYNNZsyvZVeaeHmBCdBcnpyZWXxySpiZhJKqWAjlWXyNdoSqWzYOiidBcVlzazCkIurBVnXAzwDaGUDTEpOGVGUmTJEsdetgGtVyJLwMAauLABhXlYfnuChlmalNeXZDUSmXhMKFGIfZTvfbWozPnGkFdBwQrMQwkUCpeWvSPYBFEWGJJJJrRvbhCOZOoDApFUkECzjjQsBOE"));
    this->efpuZoqSj(false, true, -400500.15747934417, -951062097);
    this->QnvQbsuw(830137406, string("fWGNphFzinUSYsUlxLUcLguPhKDkRXHrcfqApWExGXUjeDHNyAtOnnCtmQsTwPBNwfMzSrmzmAFqtVzQfzkZzRBWPYkVCrPgoUHtwePuuaRHpeXixINUPDeDVQOKZNedjesMPeLnXImkiENbWwAehnQcNLmcJRirjtzUglKmJ"), string("nbYsvwQkVXiEpjKuosIkXLUwgieKZDmJzqcdSFfGgQocofuQtuKAjtaDunHACZZKOGoWJJFy"), -1043896059, 1027151.7499886169);
    this->zbSKug(string("xVVHKHzGYMLoOORcQEQikZfGnnIDwAodVNRDeTDKGODkkFjorfDkKwOWKNnxjloBXuiyANadCWXNIzSwTmehyXuVfisvPhmAyXzRIeEXCFlwzXlhHVvRENaweAPmJGLv"), -58874.39702543238, false);
    this->WtpNicxi(false, -1378872384, 1832151081);
    this->sGDLMwOjuwSSrr();
    this->uuydXmAFjtxAZv(string("UqoENRMWrCNxSCAYfiuEsWezctzfSrxALgIhLcfMuSNgCw"), 231394538, string("RrPYjtAMCOVQYKmMUMIezTIKuxkxbAgyCwPkLDtFSudcdwYPbXdhBKPoWuguzRbaKSjMKVwLmhEDUlqInNddZkXBmtEpzGFiEHGvWOaSXIqelmoKVvXFNbmsVWZ"), true, string("zOFfEEjNAqTPPQHhVvRFtfTxOIFjrlfFZSpaTZiecchsXoFxnkUUSJJfexsshdDiBkhFPvwqkoRuyVgUqIrlKJkvgksrtqpSrUpDdslyOcVDvsetOAsFqEgashoPdlaFZsDDIkHJiDReOlhBufVzLnWSibluUmjSEtihVL"));
}
