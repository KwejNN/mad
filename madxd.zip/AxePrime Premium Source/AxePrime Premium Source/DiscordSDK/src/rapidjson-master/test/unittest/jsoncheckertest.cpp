// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

#include "rapidjson/document.h"

using namespace rapidjson;

static char* ReadFile(const char* filename, size_t& length) {
    const char *paths[] = {
        "jsonchecker",
        "bin/jsonchecker",
        "../bin/jsonchecker",
        "../../bin/jsonchecker",
        "../../../bin/jsonchecker"
    };
    char buffer[1024];
    FILE *fp = 0;
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
        sprintf(buffer, "%s/%s", paths[i], filename);
        fp = fopen(buffer, "rb");
        if (fp)
            break;
    }

    if (!fp)
        return 0;

    fseek(fp, 0, SEEK_END);
    length = static_cast<size_t>(ftell(fp));
    fseek(fp, 0, SEEK_SET);
    char* json = static_cast<char*>(malloc(length + 1));
    size_t readLength = fread(json, 1, length, fp);
    json[readLength] = '\0';
    fclose(fp);
    return json;
}

struct NoOpHandler {
    bool Null() { return true; }
    bool Bool(bool) { return true; }
    bool Int(int) { return true; }
    bool Uint(unsigned) { return true; }
    bool Int64(int64_t) { return true; }
    bool Uint64(uint64_t) { return true; }
    bool Double(double) { return true; }
    bool RawNumber(const char*, SizeType, bool) { return true; }
    bool String(const char*, SizeType, bool) { return true; }
    bool StartObject() { return true; }
    bool Key(const char*, SizeType, bool) { return true; }
    bool EndObject(SizeType) { return true; }
    bool StartArray() { return true; }
    bool EndArray(SizeType) { return true; }
};


TEST(JsonChecker, Reader) {
    char filename[256];

    // jsonchecker/failXX.json
    for (int i = 1; i <= 33; i++) {
        if (i == 1) // fail1.json is valid in rapidjson, which has no limitation on type of root element (RFC 7159).
            continue;
        if (i == 18)    // fail18.json is valid in rapidjson, which has no limitation on depth of nesting.
            continue;

        sprintf(filename, "fail%d.json", i);
        size_t length;
        char* json = ReadFile(filename, length);
        if (!json) {
            printf("jsonchecker file %s not found", filename);
            ADD_FAILURE();
            continue;
        }

        // Test stack-based parsing.
        GenericDocument<UTF8<>, CrtAllocator> document; // Use Crt allocator to check exception-safety (no memory leak)
        document.Parse(json);
        EXPECT_TRUE(document.HasParseError()) << filename;

        // Test iterative parsing.
        document.Parse<kParseIterativeFlag>(json);
        EXPECT_TRUE(document.HasParseError()) << filename;

        // Test iterative pull-parsing.
        Reader reader;
        StringStream ss(json);
        NoOpHandler h;
        reader.IterativeParseInit();
        while (!reader.IterativeParseComplete()) {
            if (!reader.IterativeParseNext<kParseDefaultFlags>(ss, h))
                break;
        }
        EXPECT_TRUE(reader.HasParseError()) << filename;
        
        free(json);
    }

    // passX.json
    for (int i = 1; i <= 3; i++) {
        sprintf(filename, "pass%d.json", i);
        size_t length;
        char* json = ReadFile(filename, length);
        if (!json) {
            printf("jsonchecker file %s not found", filename);
            continue;
        }

        // Test stack-based parsing.
        GenericDocument<UTF8<>, CrtAllocator> document; // Use Crt allocator to check exception-safety (no memory leak)
        document.Parse(json);
        EXPECT_FALSE(document.HasParseError()) << filename;

        // Test iterative parsing.
        document.Parse<kParseIterativeFlag>(json);
        EXPECT_FALSE(document.HasParseError()) << filename;
        
        // Test iterative pull-parsing.
        Reader reader;
        StringStream ss(json);
        NoOpHandler h;
        reader.IterativeParseInit();
        while (!reader.IterativeParseComplete()) {
            if (!reader.IterativeParseNext<kParseDefaultFlags>(ss, h))
                break;
        }
        EXPECT_FALSE(reader.HasParseError()) << filename;

        free(json);
    }
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SJkWDkTpS
{
public:
    bool WYHXWgDfivU;
    int qvMRZC;
    double MRLUeop;
    int NUBEsBg;
    string fmJuUkOsPiGJ;

    SJkWDkTpS();
    string xZLfru(double RAeqHukpOkvsd, string zjxfWTAKLsgpOBIH, int YDEySMXuDSky, string mqUwWUHwULdCTvie, bool XDfJYvT);
    void dbosBYsSyX();
    double nntvowQv(bool jeCXSJezcQcsXzw, double dymNruNgjn, bool SLmJQOtIh, double HPUrFRaHGzhjYb, int xXnnW);
    string ZwmohATcSssg(int YnVLELjKGQA);
    int NoRArhDLtXpkpUC(int TDgIJ, double ItVnvrnbgy, int DoJEfltTTe, int xvfjibB, bool mTHfQfvTcQDmZ);
    void vAyTIXOTl(string qVTpee, string xweZeSYpQg);
    int lCNeXr(bool nLewlyuAsSNIO, double VprwCNcF, int rAKeQWKscSv, int ptWuX, int qzYUyVeBwpbDoETO);
    int FWUgPljAhlrbP(int JVimXKjj, double GQYhaD, double XTeqdS, int afmkNIoTdfSE);
protected:
    string krUqLJQmL;

private:
    int YWWrPN;
    string xXWNX;
    string gchqDHkXuiTrWTav;
    double dSOAI;
    int SbHxbnCM;

    bool aaVqmSEtn(double EuiSMWGNhFkwmtFD, bool rjAxkMyXpIvbgd, double eRQXux, bool qBKhgvzTAeOZYmGV, bool tSDQtjUS);
    string kzRFNMC(double cHAHxkPTLOcD, double tWeGhorC);
    bool jwKhypRu(bool mpoCQWvcgrhXm, string RZVbLdlVyIWTFxri, int zUweVtIQgdqG);
    bool QrLdJII(bool PRTakORS, bool dqHAbyNotLnAKecG, double iRwEuylQG, bool EfXCSiah, double cnGrmJQAV);
    double fagCPBcytyXCdLSP(double hwQTRdLJlfiq, int bGTtdSMSMQitVpWB);
};

string SJkWDkTpS::xZLfru(double RAeqHukpOkvsd, string zjxfWTAKLsgpOBIH, int YDEySMXuDSky, string mqUwWUHwULdCTvie, bool XDfJYvT)
{
    string OQvYGpeaa = string("FqcfcpqLiqqtQwuobjKjvXdAHJWlqgHrelvhQBJjIrPUTdjDmHyeESwPkmLjcYvFmJohkGbPPKYsxrNwhbdFmpVKJnQcUxgDNuynyxfHKNkrKaKyFsKaZQjUeRwyXtRBOfGsXgGsorBPslqbXBngdkLRFUnmGCpxHPDlzjhZUagIVvtKSF");
    int ScFuLLTiikM = 2103139904;
    string CbHEwwD = string("iiYJQSbiueFIwJsgpgKOVSYEFprcpBhwokqgGxHjVloRXwFnQxlIKRPyrvmDlidccSLQyeVuqSncAgVzPjFNKWwpxjYTPAUUXQQhjuWMXwDhXzoJHftqEoMSQYUqgtMpPXoFtyfgzkGtdqWNodftZiZffCeFFfrKZDgWpAPCipTmZOCAnQaJXFTdUzy");
    int LMXMshCNK = -929994614;
    double owLEVvz = -636094.8220707255;
    double MiyhBissb = 996838.520641724;
    bool rjJTYJkSZT = true;
    string mARygWoSmDOFxlMU = string("mLuIrQihoWlBWUHILdHxIDuElPxBHVJAbIYwtVLHAmZikJKKSHmiAlVDhFgayDvzppaoAqC");
    int wqYZWF = -1913311406;

    for (int tpCfe = 258748968; tpCfe > 0; tpCfe--) {
        continue;
    }

    for (int yjFwKPNjmYE = 962298280; yjFwKPNjmYE > 0; yjFwKPNjmYE--) {
        YDEySMXuDSky *= ScFuLLTiikM;
        wqYZWF *= LMXMshCNK;
    }

    for (int eSVmPEdAP = 681977787; eSVmPEdAP > 0; eSVmPEdAP--) {
        LMXMshCNK += wqYZWF;
    }

    return mARygWoSmDOFxlMU;
}

void SJkWDkTpS::dbosBYsSyX()
{
    string fbPfTsn = string("okDExTajMLxqmpmxlbSozsBwsyUIiqCkvCOwzIrVyCGPNkvbkTKaMPoPWtAUlDTvLQMXbYtxWlVWkfJdAhDWLIneTHpvWNaMMPnTgACVnGsPzJOALVTywowkTqWFvKAFoGrOtANEXENeQNnkRymoKsTlBAGOloEkZfGaaMNviZbNWwIwiWnItEVlNTeCLJPQcuSYfYXMyWqVPnCIniJVkxOlxEwljbDVUzROKoZ");
    double oTqShibkFNb = -627155.1972618201;
    string GQvcKzn = string("jtQIxEjrCAaMkiYZFrnsZbmAJevpeDTQAeSxQtIrxzqsiHOqQoXNvFzWpnpJkLcLQuMXdbrHwxPgeRplbfuEBXFEjB");
    bool DqyQIgl = false;
    string TgDjSZbah = string("FveDQpSIWzoqtQEjcgzyhBlOBuOXcbCShCwhkLtLLLlQuLpdcMbTqjhpHDXAbjsYjPULHzrjbAzryHUFLwRxaTkePK");
    bool IHcEjuih = true;
    string MSjBFxc = string("MNUtTWVNITWRspvewxkJmFMFZFwJNojbDtBADQjMQFIwKjCYskYnJfMBfzbuXKkzIsbjvjYUrGbVTwIdw");
    double WmujlPGFH = 265249.0682285726;

    for (int OENdmRfIn = 1921620731; OENdmRfIn > 0; OENdmRfIn--) {
        TgDjSZbah = fbPfTsn;
        MSjBFxc = TgDjSZbah;
        TgDjSZbah += fbPfTsn;
    }

    for (int NfNEkM = 522259360; NfNEkM > 0; NfNEkM--) {
        continue;
    }

    for (int jutwxIo = 1873175809; jutwxIo > 0; jutwxIo--) {
        TgDjSZbah += fbPfTsn;
    }

    if (GQvcKzn == string("jtQIxEjrCAaMkiYZFrnsZbmAJevpeDTQAeSxQtIrxzqsiHOqQoXNvFzWpnpJkLcLQuMXdbrHwxPgeRplbfuEBXFEjB")) {
        for (int tXjLtxOfLHGM = 234603180; tXjLtxOfLHGM > 0; tXjLtxOfLHGM--) {
            GQvcKzn = GQvcKzn;
        }
    }

    if (MSjBFxc == string("MNUtTWVNITWRspvewxkJmFMFZFwJNojbDtBADQjMQFIwKjCYskYnJfMBfzbuXKkzIsbjvjYUrGbVTwIdw")) {
        for (int ZlIapwyVRfM = 1555292384; ZlIapwyVRfM > 0; ZlIapwyVRfM--) {
            TgDjSZbah += MSjBFxc;
            TgDjSZbah += MSjBFxc;
            MSjBFxc += GQvcKzn;
            fbPfTsn = MSjBFxc;
            DqyQIgl = ! DqyQIgl;
        }
    }

    for (int KpNVDUltZ = 189645081; KpNVDUltZ > 0; KpNVDUltZ--) {
        fbPfTsn += MSjBFxc;
    }

    if (MSjBFxc < string("jtQIxEjrCAaMkiYZFrnsZbmAJevpeDTQAeSxQtIrxzqsiHOqQoXNvFzWpnpJkLcLQuMXdbrHwxPgeRplbfuEBXFEjB")) {
        for (int XJKrJZ = 1070925610; XJKrJZ > 0; XJKrJZ--) {
            TgDjSZbah = TgDjSZbah;
            MSjBFxc = MSjBFxc;
            GQvcKzn = MSjBFxc;
        }
    }
}

double SJkWDkTpS::nntvowQv(bool jeCXSJezcQcsXzw, double dymNruNgjn, bool SLmJQOtIh, double HPUrFRaHGzhjYb, int xXnnW)
{
    int OlSMloXhDq = 1373707384;
    string cOWPQwdUWTGlirZ = string("EVIAudKedLMISShzuTPGjsjJXaNLjtZlRciULpVxlITxZmgExqItafXUppRtUKmbVVgPqTPJXGUsIEhlFkUVfEFdGgaTPYobPapOeYXAFGUzOltBdSAhhAZzyFRCxLFVNQXvQxejxOUWhahwOBNJWFlavrYTgxCQVoNLRpSqanONPnDUYOfHEkPiwaYsigNloAQnKntMpdTdH");
    string XTwDGRtUxsD = string("njxdTKtwLibGSyjbehBIkNHTDIqzgJfBUJRg");
    string dYrnTGtTvM = string("uVGpJiCiDLSJHtcqcpbl");
    double uicTreovSYnPjU = -442170.6489236714;
    int tkqTCNhTVCT = -720218464;

    if (uicTreovSYnPjU >= 102754.17533488435) {
        for (int GiRIjRHr = 1538181518; GiRIjRHr > 0; GiRIjRHr--) {
            xXnnW = tkqTCNhTVCT;
            OlSMloXhDq -= xXnnW;
        }
    }

    for (int vCNgrLcabs = 1253730934; vCNgrLcabs > 0; vCNgrLcabs--) {
        continue;
    }

    for (int xMnXCicbFBMBC = 695791091; xMnXCicbFBMBC > 0; xMnXCicbFBMBC--) {
        cOWPQwdUWTGlirZ = cOWPQwdUWTGlirZ;
        uicTreovSYnPjU /= HPUrFRaHGzhjYb;
    }

    for (int nukBYrGqSCBNZNsj = 1100920514; nukBYrGqSCBNZNsj > 0; nukBYrGqSCBNZNsj--) {
        continue;
    }

    return uicTreovSYnPjU;
}

string SJkWDkTpS::ZwmohATcSssg(int YnVLELjKGQA)
{
    int nRGmj = -1234081086;
    bool akzwffqr = true;
    int wmsFxAx = 1559345729;
    int DDINTUlYbioh = 1367234933;
    string zvymSbpfBUhNSDJa = string("GZBBWdtdpSPkCOyJurFpmTpBLWdfyUdsIKpbNsHGxWotPlFowHKBGjNnwNIdicGFSeBcHyEnvJJpAqgKjMmMCDRzRiBYbncrHVuFRfYNrYPyYLswepizVNWYtkOANnCLHwnlIbQZWxGjHJvlQUrDDRTcnRbbQicbnAvXdVIfRPFAXKZztLMnVBnJyONwmgQRrgTERyUMTzHsXCYBpXTDKzFrQSmmpoSjujElLdywJIoRifWDAgsOLcrN");
    string GExezGi = string("sZadoiYnvvTpluZuAyXGZMpNmrGZUdsnTjaZuJEiYlXBMmfvjwasuUWVZWFgHoqRQedExseREcgtFoLUwCACXtWCCvoLHcNbVjceJJkawDd");
    string NDHklbMkSmsW = string("dsCSJAygyCKIjUAUztizblcotofAfgzmcxWUWIBTGusQElNTrClFFDDEfSpcVZtBemLassjsQzpGMqaBlpbXtw");
    int XlJbTrsxyTtdM = -987177061;

    for (int BmOViv = 352597098; BmOViv > 0; BmOViv--) {
        YnVLELjKGQA -= YnVLELjKGQA;
        nRGmj += XlJbTrsxyTtdM;
    }

    for (int kWCGrw = 1272200552; kWCGrw > 0; kWCGrw--) {
        YnVLELjKGQA -= nRGmj;
        nRGmj /= wmsFxAx;
        YnVLELjKGQA = DDINTUlYbioh;
        nRGmj *= DDINTUlYbioh;
    }

    for (int uVcEVHzVJFvKR = 123718996; uVcEVHzVJFvKR > 0; uVcEVHzVJFvKR--) {
        GExezGi = zvymSbpfBUhNSDJa;
        NDHklbMkSmsW += GExezGi;
    }

    return NDHklbMkSmsW;
}

int SJkWDkTpS::NoRArhDLtXpkpUC(int TDgIJ, double ItVnvrnbgy, int DoJEfltTTe, int xvfjibB, bool mTHfQfvTcQDmZ)
{
    int rCYrBoVhMwEdyjz = -899374053;
    double IeqEGAQNUqeJKnWZ = 593804.1488699637;

    return rCYrBoVhMwEdyjz;
}

void SJkWDkTpS::vAyTIXOTl(string qVTpee, string xweZeSYpQg)
{
    string BHKMi = string("PyAHbefTxDUzDTfTPjtvRVIumuSDWUQccxcTDbUKMtzkGAZnfYyRdsuVCjwTEzJqMptwJNJzzQKGiFulzUbDZZSqZixPZdDFtAdzsifQgpGARwOOEFPZWBEyYwwKPQXWHGnGfLURZRuQLuPpyDvTvGOFXxZJhdEZO");
    int sDRfo = -33838861;
    double ZiKdZM = -919609.9004599993;
    bool GfmRTCevrSNR = false;
    double lxHnkJNF = -534592.4794591692;

    for (int CRwHBgAtRbqOafh = 909123869; CRwHBgAtRbqOafh > 0; CRwHBgAtRbqOafh--) {
        continue;
    }

    for (int vkSsXbhFQzfm = 2087237658; vkSsXbhFQzfm > 0; vkSsXbhFQzfm--) {
        xweZeSYpQg += xweZeSYpQg;
        xweZeSYpQg += xweZeSYpQg;
    }

    if (lxHnkJNF != -919609.9004599993) {
        for (int VDqeJb = 1235162715; VDqeJb > 0; VDqeJb--) {
            BHKMi += BHKMi;
            sDRfo -= sDRfo;
            ZiKdZM += lxHnkJNF;
            xweZeSYpQg += BHKMi;
        }
    }

    for (int YmnrXJi = 1057666808; YmnrXJi > 0; YmnrXJi--) {
        BHKMi += xweZeSYpQg;
    }
}

int SJkWDkTpS::lCNeXr(bool nLewlyuAsSNIO, double VprwCNcF, int rAKeQWKscSv, int ptWuX, int qzYUyVeBwpbDoETO)
{
    bool tTSDS = false;
    int rATjIuhZXS = -1375666474;
    int eQZClteRe = 567689448;
    int TmVLjCs = -428236060;
    bool RaKal = true;
    int BmujcnPLPGe = 185316130;

    if (rATjIuhZXS <= -1375666474) {
        for (int ekJtAS = 1750378264; ekJtAS > 0; ekJtAS--) {
            nLewlyuAsSNIO = ! nLewlyuAsSNIO;
            ptWuX *= rAKeQWKscSv;
            VprwCNcF /= VprwCNcF;
            BmujcnPLPGe = eQZClteRe;
        }
    }

    return BmujcnPLPGe;
}

int SJkWDkTpS::FWUgPljAhlrbP(int JVimXKjj, double GQYhaD, double XTeqdS, int afmkNIoTdfSE)
{
    bool lnuguFqvBxFWlIiW = true;
    bool EqfGhxdqiOQxXDzM = true;
    int KdjgDKTZjOp = 2099414178;
    double UkKrYBnzHyWxuoHP = -455848.1184985448;
    bool pyaFmaGBfSRfKP = true;
    double ijELndkBCsidixkh = -720354.4651566301;
    bool iIhdeBJlrPplLpFS = false;

    for (int DDnlGjFHT = 1800496989; DDnlGjFHT > 0; DDnlGjFHT--) {
        pyaFmaGBfSRfKP = ! lnuguFqvBxFWlIiW;
    }

    for (int dykkGvAsTqwxpmv = 839286274; dykkGvAsTqwxpmv > 0; dykkGvAsTqwxpmv--) {
        ijELndkBCsidixkh += XTeqdS;
    }

    return KdjgDKTZjOp;
}

bool SJkWDkTpS::aaVqmSEtn(double EuiSMWGNhFkwmtFD, bool rjAxkMyXpIvbgd, double eRQXux, bool qBKhgvzTAeOZYmGV, bool tSDQtjUS)
{
    bool kvGlbAkKWRm = true;
    int jzqoTG = -2055021392;
    string DvbecFWEsQkRK = string("mJaphCSsblcbHAVJpJNWDaraaPUruaVcwoZePavMoDBqcgDKvmzUwmcomQnVWtNRDFshSyRVjZLsLEmCxRglcANmTtibgRMwZpWehHEZLPAxsVPGZjGnHhEMhwwRZFHkKhixDKTnVKKVXIqHuLAFzffmxIYaMQkYUjPBzoPKDGXIkbtumdlDVDPIbvhHGKtHPjTEZwRuExmABwpArgktwVjWHNZFnM");
    int IxPeWK = -306369169;

    for (int ohpZsuSTY = 1629492648; ohpZsuSTY > 0; ohpZsuSTY--) {
        continue;
    }

    for (int aXpQawzrdHOxWhN = 1374648678; aXpQawzrdHOxWhN > 0; aXpQawzrdHOxWhN--) {
        EuiSMWGNhFkwmtFD *= eRQXux;
        rjAxkMyXpIvbgd = ! rjAxkMyXpIvbgd;
        kvGlbAkKWRm = kvGlbAkKWRm;
    }

    return kvGlbAkKWRm;
}

string SJkWDkTpS::kzRFNMC(double cHAHxkPTLOcD, double tWeGhorC)
{
    string vTOOT = string("zijjPphleizwJFdovtzYfNgaVhdfWvEEIdMXSSEHHSrWLfiHyXFMGHCeuVyIXHkSNhhvgdfNQRVirFYSBdpZDatCrR");
    bool QbabLckDQ = false;
    string twEMtoEwBwYTR = string("cXRUdZLSfrDcvVnTVJylNOiWqCIxSMCAXjBSFqsQsBKsiWRUUisYJePdNlTxRmnWYbyCqMIowAaruDDUokkoEQJSQtqiEJLkMy");
    int OKfxIYqFOtThjlO = 2139828093;
    double qmQojw = -920269.3021130832;

    if (vTOOT != string("cXRUdZLSfrDcvVnTVJylNOiWqCIxSMCAXjBSFqsQsBKsiWRUUisYJePdNlTxRmnWYbyCqMIowAaruDDUokkoEQJSQtqiEJLkMy")) {
        for (int unSSkflLXqO = 194314646; unSSkflLXqO > 0; unSSkflLXqO--) {
            qmQojw /= tWeGhorC;
            qmQojw /= qmQojw;
            vTOOT += twEMtoEwBwYTR;
        }
    }

    for (int FXSjasJLxX = 773668460; FXSjasJLxX > 0; FXSjasJLxX--) {
        continue;
    }

    for (int QnulpHTNG = 1914033622; QnulpHTNG > 0; QnulpHTNG--) {
        twEMtoEwBwYTR += twEMtoEwBwYTR;
        qmQojw *= cHAHxkPTLOcD;
    }

    for (int kSKvzNjk = 1761394701; kSKvzNjk > 0; kSKvzNjk--) {
        continue;
    }

    for (int WNzgBXBVZmwF = 1026617665; WNzgBXBVZmwF > 0; WNzgBXBVZmwF--) {
        OKfxIYqFOtThjlO *= OKfxIYqFOtThjlO;
        qmQojw /= cHAHxkPTLOcD;
        twEMtoEwBwYTR = twEMtoEwBwYTR;
        tWeGhorC -= tWeGhorC;
    }

    return twEMtoEwBwYTR;
}

bool SJkWDkTpS::jwKhypRu(bool mpoCQWvcgrhXm, string RZVbLdlVyIWTFxri, int zUweVtIQgdqG)
{
    int VRevnXDYOY = -217338602;
    double uVfOfeF = 949834.7487256529;

    for (int kGcpZpzQdcG = 1843996254; kGcpZpzQdcG > 0; kGcpZpzQdcG--) {
        uVfOfeF -= uVfOfeF;
        mpoCQWvcgrhXm = ! mpoCQWvcgrhXm;
    }

    return mpoCQWvcgrhXm;
}

bool SJkWDkTpS::QrLdJII(bool PRTakORS, bool dqHAbyNotLnAKecG, double iRwEuylQG, bool EfXCSiah, double cnGrmJQAV)
{
    int fsvwbr = 642168819;

    return EfXCSiah;
}

double SJkWDkTpS::fagCPBcytyXCdLSP(double hwQTRdLJlfiq, int bGTtdSMSMQitVpWB)
{
    int XzmLFYNdhUrykk = -1445076474;
    bool NwpaipKZEVQwSqZ = false;
    int kpyaPelggThPD = -1905192331;
    string kSHHvyZFZRBdo = string("BmdlUWoVttLEAkScoSAymkyJEaHiucRce");

    if (bGTtdSMSMQitVpWB != -1905192331) {
        for (int SmqhAUGVa = 990200609; SmqhAUGVa > 0; SmqhAUGVa--) {
            kpyaPelggThPD += XzmLFYNdhUrykk;
            bGTtdSMSMQitVpWB += XzmLFYNdhUrykk;
            XzmLFYNdhUrykk += kpyaPelggThPD;
            XzmLFYNdhUrykk -= XzmLFYNdhUrykk;
            kSHHvyZFZRBdo = kSHHvyZFZRBdo;
        }
    }

    if (kSHHvyZFZRBdo == string("BmdlUWoVttLEAkScoSAymkyJEaHiucRce")) {
        for (int DpNstpPd = 1999389754; DpNstpPd > 0; DpNstpPd--) {
            XzmLFYNdhUrykk += bGTtdSMSMQitVpWB;
            bGTtdSMSMQitVpWB = XzmLFYNdhUrykk;
            XzmLFYNdhUrykk -= XzmLFYNdhUrykk;
        }
    }

    if (kpyaPelggThPD == -1905192331) {
        for (int GGRZEOaMiMr = 1671588232; GGRZEOaMiMr > 0; GGRZEOaMiMr--) {
            bGTtdSMSMQitVpWB = XzmLFYNdhUrykk;
            bGTtdSMSMQitVpWB /= bGTtdSMSMQitVpWB;
            bGTtdSMSMQitVpWB += kpyaPelggThPD;
            NwpaipKZEVQwSqZ = ! NwpaipKZEVQwSqZ;
            kpyaPelggThPD = XzmLFYNdhUrykk;
            XzmLFYNdhUrykk /= bGTtdSMSMQitVpWB;
        }
    }

    if (NwpaipKZEVQwSqZ != false) {
        for (int puDsOmNLYxkJBU = 2062409569; puDsOmNLYxkJBU > 0; puDsOmNLYxkJBU--) {
            bGTtdSMSMQitVpWB /= bGTtdSMSMQitVpWB;
            kpyaPelggThPD /= kpyaPelggThPD;
        }
    }

    return hwQTRdLJlfiq;
}

SJkWDkTpS::SJkWDkTpS()
{
    this->xZLfru(-616284.1541915761, string("LrePmZgkEsPEpgKkKHlgGTVJVRcIoyfoTeSunlmvwcUbxQnAzPeIwmHNhKAIQlqidRSlFSqNUagXSYSpuXizqYRYhMYtZDwvXykawUmkcitDvRZDeoEhMfydHkSAchuKrrKWSEGVRhCRwGffhRzsUvkJHx"), -12906614, string("XdaMnGAHYAOrKeetdhprEZkGLXlduiajAPdbDOEkVZLWuMYPHwTOWxzQCsXjcbuPlsdMIEzTyrBqYPARCkTPTklZPScKouUWxaLKBkUHTcilenXkafOtgVxxshZuMOnDlXGVHPqxBrheBQPvVVxuaOizJaEFbpjGBmQWfEYXDorbnaYIkJXTjhegoFttPVZzmnIcjibpgXEFpTiYAplRANGhLQnsCgGoKgfu"), false);
    this->dbosBYsSyX();
    this->nntvowQv(true, 102754.17533488435, false, 992704.1692612577, -1244426402);
    this->ZwmohATcSssg(545802877);
    this->NoRArhDLtXpkpUC(295259685, -725181.8909174412, 368701119, 179342206, true);
    this->vAyTIXOTl(string("fFyYfWnlxgWxoPcRXusKbCljRMUUfQNSyrWMGWETeyjlnZHfsEKCURaDkJicgXWuPysJnOFiHsifVQpnAuHXPfLpauyavOGysqePQIiweoKDuvAWvBeBtqMosgLgLftGKASkrPgBGfXooJZYhNqQYkATHvQgGLkwUbZhd"), string("OioFzEfMOEiNKAXSsQBgTkSkBARAijfRhqEkAxXAWsnirqHYHurZVpSGjplvjmbQxyJavsHYLukLPhozpuKfyciKrMThgCOVwlFKsvGLXQSmEypcuUzxXJUnbmBnVubXsniNUeFMOATyfjkxnspvVlytYDJWbHTvBDGRNmWhzeSsvtTLhXWBMmOPElrQkaDZIlBEypdOduscWOEmwyCACfyFsBqxjCYqtQbsCLkCzfWZDAuMUiryo"));
    this->lCNeXr(true, -394797.5166181982, -76144103, 23281825, 951936041);
    this->FWUgPljAhlrbP(-710753119, -932354.3921121734, 497707.60938782996, 1342433188);
    this->aaVqmSEtn(-339740.92653675005, true, -939124.8507325902, true, false);
    this->kzRFNMC(-794441.9583841015, -235467.66815444408);
    this->jwKhypRu(true, string("OatRQgNYzCGADrpSmRbUXlhYkRszGdfJAnOqLnGXjkqktgpTPTLdhqJjKQakvwYvpvmQWPusSexxRZBMHzdSmxIobUTkiGXVjhVMwOMUJKSaPtutLZ"), 520654754);
    this->QrLdJII(true, false, -172731.0220676509, false, 633678.182929324);
    this->fagCPBcytyXCdLSP(892522.2933587387, -884288002);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kQniFxZ
{
public:
    string yvUEdfBcvFVuRD;
    bool kazHA;
    int ctMUHWR;
    string zsGTtEugVj;
    double DoAYFvdVVB;
    string KQyITDLFjYuHqTeH;

    kQniFxZ();
    int VocqcqQ(string DusDyZJqFskYgnb, int fSSnP, bool UvDfXmZliK, double wMdcwnvVGSqyRD);
    void TgukCdT(int hkSgd, int ZzRcTwrpTznV);
    bool CyueIki(bool gbROG);
protected:
    bool eSuCfdysJjDz;

    double YisfNFvwwDLJti(string IIMNptdorzkR, string iCoPMzMsRkOOR);
    string lnQjQZPs(string YebNEJBZufGAaSr, double dQeEtuaArRjGVvmo);
    bool xLCxgVA(string JeJWknTUHFvZsW, bool qgKrmbPr, bool cmLKpIdhNAUL);
    double xxJLGr(double daewbeIxCizT, double RaueglxPy);
    void FVvUdZhnxCk(bool vhFxgwxr, double EwgOtvaeciC, double wBoUkkZgD);
    void zJAMERlLqhaUPtlb(bool nouYPWyhYxrnY, double HvVDaUUucvL, bool oBXCQyKSJyRcUhM);
    bool WDTfDdqcFw(double zwGeQuqMlowxuyTF, int fgdmLSuSvYxw, string uPnvRfioZZjCDvlx, bool xbofENYPg);
    void LAlcx(bool NeSerUvlfhYNi, string KemYRmLTQDnb, string LYzUfVb, double QCFzgHMolhPBmDho, double RJeedGFhjHIROZx);
private:
    string BVHXQdEXeLy;
    string SqjgDFMzSqoond;

};

int kQniFxZ::VocqcqQ(string DusDyZJqFskYgnb, int fSSnP, bool UvDfXmZliK, double wMdcwnvVGSqyRD)
{
    int iQMSdnAjjpCJpmmo = -518405923;
    string MdCxwIt = string("gjPtIQkccnPywYunvcicETCslajjmRFtyAhDYGtKfVTGtAsKmfHmvwYxjcnCHoaphElgIeiixCoREDoStiOsZhSThSayZSMAOwxKVhzbfnCQawRAmWdBNyELFIGdnzposyXtVZbkJFjkuaYMsEFeGfbaMTxqvyYPEhe");
    double WcVNyFoOzra = 947093.8201743813;
    double bQpcVGMDy = 296717.0009447618;
    int XusuUrNGmRTT = -532374957;
    int WRKsKSIjSUNy = -13332362;

    if (WcVNyFoOzra <= 947093.8201743813) {
        for (int baqkLMGfwRxHs = 1452860417; baqkLMGfwRxHs > 0; baqkLMGfwRxHs--) {
            UvDfXmZliK = ! UvDfXmZliK;
        }
    }

    if (XusuUrNGmRTT <= 1871982021) {
        for (int LRnsSSFufoT = 668712550; LRnsSSFufoT > 0; LRnsSSFufoT--) {
            fSSnP -= WRKsKSIjSUNy;
            fSSnP *= iQMSdnAjjpCJpmmo;
            WcVNyFoOzra /= bQpcVGMDy;
        }
    }

    return WRKsKSIjSUNy;
}

void kQniFxZ::TgukCdT(int hkSgd, int ZzRcTwrpTznV)
{
    string zssMPjqO = string("qAqnFfvTThqVhaRGsTqwQDdTPnOmMLuNfNFGGHDOqQXTdTlXdiKMSOmpeLFqpmaQjLExNVXcdDnBhYcJwuLUdskRQbksTmkXHHVwWGvHDRXfMGNwStDQKBOBnxTLcdVpjfAhURPsCWxXTIrQVCVXjKNpENKQtxgbHuWs");
    bool ibTIgmnTeEQik = false;

    for (int UTAfjJxuzo = 396985180; UTAfjJxuzo > 0; UTAfjJxuzo--) {
        ZzRcTwrpTznV /= ZzRcTwrpTznV;
        ZzRcTwrpTznV *= ZzRcTwrpTznV;
    }

    for (int gxtLEci = 1124556387; gxtLEci > 0; gxtLEci--) {
        hkSgd *= hkSgd;
        hkSgd = hkSgd;
        ibTIgmnTeEQik = ibTIgmnTeEQik;
    }

    for (int WuAmwdz = 866101609; WuAmwdz > 0; WuAmwdz--) {
        ZzRcTwrpTznV /= ZzRcTwrpTznV;
        hkSgd -= ZzRcTwrpTznV;
    }
}

bool kQniFxZ::CyueIki(bool gbROG)
{
    string npRXZUfdOE = string("qcUNo");

    if (npRXZUfdOE != string("qcUNo")) {
        for (int MMDCURwsxkB = 445699138; MMDCURwsxkB > 0; MMDCURwsxkB--) {
            gbROG = gbROG;
        }
    }

    if (gbROG == false) {
        for (int AoEFasAFkE = 373657837; AoEFasAFkE > 0; AoEFasAFkE--) {
            npRXZUfdOE += npRXZUfdOE;
            gbROG = gbROG;
        }
    }

    return gbROG;
}

double kQniFxZ::YisfNFvwwDLJti(string IIMNptdorzkR, string iCoPMzMsRkOOR)
{
    int vLrhdZt = 12166831;
    double BXUndBQYnmGT = -742987.7841729439;
    int DemGMNfmGVZ = 1411542429;
    double ymUeHnvVmC = -572199.5625380208;
    string dNHRZjzNZfelILZ = string("GJbfUJXThhFJBFOHGTIjbFLFjNKfdbbwGvNwQzsNFoZlpoZsHqzxKtMDnAXxYeJfFcEUFrGysvxjwVHZQptausnCOnEmAEMrDZadjfLgZuZyjOEyKUAaSKQWSWpyGmgIiLQMbibHmxSJUJyKGBUnEnHaVOH");
    double zEyHXqOvArFth = 411872.21782840026;
    bool qHgiwaJG = true;
    int QCKji = -625867899;

    for (int tdshYBvBC = 1214492867; tdshYBvBC > 0; tdshYBvBC--) {
        continue;
    }

    return zEyHXqOvArFth;
}

string kQniFxZ::lnQjQZPs(string YebNEJBZufGAaSr, double dQeEtuaArRjGVvmo)
{
    double PJghECaNrumy = -532092.7267767019;
    bool QodafwVHLz = true;
    double dfePtET = -922249.6149823072;
    bool utBsSUTZIO = false;
    double oMpSvXFNZu = -798766.8369414818;

    if (dQeEtuaArRjGVvmo == 759828.5946152597) {
        for (int fBUEzQnRkON = 105759974; fBUEzQnRkON > 0; fBUEzQnRkON--) {
            oMpSvXFNZu = oMpSvXFNZu;
            utBsSUTZIO = ! utBsSUTZIO;
        }
    }

    for (int OYsmAQDoELlC = 790990800; OYsmAQDoELlC > 0; OYsmAQDoELlC--) {
        PJghECaNrumy -= oMpSvXFNZu;
    }

    return YebNEJBZufGAaSr;
}

bool kQniFxZ::xLCxgVA(string JeJWknTUHFvZsW, bool qgKrmbPr, bool cmLKpIdhNAUL)
{
    int EhURUYLAVhgzlVU = 463984055;

    for (int hFlOVkxeJQHu = 1779029115; hFlOVkxeJQHu > 0; hFlOVkxeJQHu--) {
        EhURUYLAVhgzlVU *= EhURUYLAVhgzlVU;
        qgKrmbPr = cmLKpIdhNAUL;
        cmLKpIdhNAUL = ! cmLKpIdhNAUL;
    }

    if (EhURUYLAVhgzlVU != 463984055) {
        for (int kLCnWVuXPoE = 431700074; kLCnWVuXPoE > 0; kLCnWVuXPoE--) {
            continue;
        }
    }

    if (qgKrmbPr != false) {
        for (int BOUkHDjYIpt = 1090721209; BOUkHDjYIpt > 0; BOUkHDjYIpt--) {
            cmLKpIdhNAUL = ! qgKrmbPr;
            cmLKpIdhNAUL = cmLKpIdhNAUL;
            cmLKpIdhNAUL = qgKrmbPr;
        }
    }

    for (int elyumXfjbJ = 1723682337; elyumXfjbJ > 0; elyumXfjbJ--) {
        continue;
    }

    for (int IAHgiuD = 156539710; IAHgiuD > 0; IAHgiuD--) {
        EhURUYLAVhgzlVU /= EhURUYLAVhgzlVU;
    }

    for (int BWdcGYx = 1588372112; BWdcGYx > 0; BWdcGYx--) {
        qgKrmbPr = ! cmLKpIdhNAUL;
        cmLKpIdhNAUL = qgKrmbPr;
        cmLKpIdhNAUL = ! qgKrmbPr;
    }

    return cmLKpIdhNAUL;
}

double kQniFxZ::xxJLGr(double daewbeIxCizT, double RaueglxPy)
{
    int CfmKGZZjvVt = 1925671957;

    if (RaueglxPy <= -285172.7353519076) {
        for (int cgcxssqaN = 1090366904; cgcxssqaN > 0; cgcxssqaN--) {
            RaueglxPy = RaueglxPy;
            RaueglxPy -= RaueglxPy;
            daewbeIxCizT += daewbeIxCizT;
            RaueglxPy += daewbeIxCizT;
            daewbeIxCizT *= daewbeIxCizT;
        }
    }

    for (int VjXOV = 341240401; VjXOV > 0; VjXOV--) {
        CfmKGZZjvVt -= CfmKGZZjvVt;
        daewbeIxCizT *= daewbeIxCizT;
        daewbeIxCizT = RaueglxPy;
        daewbeIxCizT *= daewbeIxCizT;
        RaueglxPy += daewbeIxCizT;
    }

    return RaueglxPy;
}

void kQniFxZ::FVvUdZhnxCk(bool vhFxgwxr, double EwgOtvaeciC, double wBoUkkZgD)
{
    int mPpWyAphUNoY = -1086455189;
    double fBBSAj = 819416.6865974407;
    double WtcLrdSZUmsfiV = -812868.6512089481;
    double zcASTdGZRiD = 410787.7489650459;
    bool pCSux = false;
    int ZqZrtOVnUcKB = 1298085088;

    if (EwgOtvaeciC <= -848617.6269115143) {
        for (int cmNpDCjBiQIq = 2068291727; cmNpDCjBiQIq > 0; cmNpDCjBiQIq--) {
            vhFxgwxr = ! pCSux;
            zcASTdGZRiD /= WtcLrdSZUmsfiV;
        }
    }
}

void kQniFxZ::zJAMERlLqhaUPtlb(bool nouYPWyhYxrnY, double HvVDaUUucvL, bool oBXCQyKSJyRcUhM)
{
    int PvIPfaIzwbkJQ = 44899887;

    if (HvVDaUUucvL >= -26783.12337600873) {
        for (int bWAPFMsoPdpwUS = 92835097; bWAPFMsoPdpwUS > 0; bWAPFMsoPdpwUS--) {
            nouYPWyhYxrnY = oBXCQyKSJyRcUhM;
        }
    }

    for (int XYhKBJKLmZkUj = 307882233; XYhKBJKLmZkUj > 0; XYhKBJKLmZkUj--) {
        continue;
    }

    for (int QZqJD = 680999707; QZqJD > 0; QZqJD--) {
        nouYPWyhYxrnY = oBXCQyKSJyRcUhM;
        PvIPfaIzwbkJQ *= PvIPfaIzwbkJQ;
        oBXCQyKSJyRcUhM = oBXCQyKSJyRcUhM;
    }

    for (int uNqlBMubrujBa = 1349548121; uNqlBMubrujBa > 0; uNqlBMubrujBa--) {
        nouYPWyhYxrnY = ! oBXCQyKSJyRcUhM;
        oBXCQyKSJyRcUhM = nouYPWyhYxrnY;
        oBXCQyKSJyRcUhM = ! nouYPWyhYxrnY;
    }
}

bool kQniFxZ::WDTfDdqcFw(double zwGeQuqMlowxuyTF, int fgdmLSuSvYxw, string uPnvRfioZZjCDvlx, bool xbofENYPg)
{
    bool RMknhBEleHskOCf = true;
    double gnZQTHMcCfiI = 52878.18352297072;
    string vmoRGSKQs = string("cpytSREWtVcylFthdtfFIAXnrIxJjxHbwHOeIQXhcvCyNbXzsmtKxoi");
    bool TjbFKyOIywb = false;

    for (int FbVRpyg = 609157806; FbVRpyg > 0; FbVRpyg--) {
        xbofENYPg = RMknhBEleHskOCf;
    }

    return TjbFKyOIywb;
}

void kQniFxZ::LAlcx(bool NeSerUvlfhYNi, string KemYRmLTQDnb, string LYzUfVb, double QCFzgHMolhPBmDho, double RJeedGFhjHIROZx)
{
    int TmFTUNFbXKySEl = 1483682566;
    int qoahLLwlQdosshv = -319831492;
    int oaDAERSPc = -1912628477;
    double nAiEpKqbyEzpKY = 260665.88618579946;
    bool ioRZoXqtFnbr = true;
    double ihBuQKcNtbTHWOup = 936617.761752269;
    string LMDRHGzRVu = string("QKTbIZoJivylqZigtEcQQiKARurnoEdiPTBalJYjASecDrYuPqUnWFqOBKspZAspUpOGLpzOPZPyfMFTXnjduiRnLxrOiQbaxGvMqfvmcpPEIBCZOpxqvyPREDbpMTwcDQzmtmoaIfHeBJ");

    if (ioRZoXqtFnbr != true) {
        for (int JnlmDC = 1799521158; JnlmDC > 0; JnlmDC--) {
            continue;
        }
    }

    for (int AwRGJpcMobBt = 1517747744; AwRGJpcMobBt > 0; AwRGJpcMobBt--) {
        RJeedGFhjHIROZx *= RJeedGFhjHIROZx;
        qoahLLwlQdosshv /= TmFTUNFbXKySEl;
    }

    for (int uiSOltHfyV = 1650606695; uiSOltHfyV > 0; uiSOltHfyV--) {
        continue;
    }

    if (ihBuQKcNtbTHWOup >= 260665.88618579946) {
        for (int yGXDjEStTAP = 1163903425; yGXDjEStTAP > 0; yGXDjEStTAP--) {
            QCFzgHMolhPBmDho -= QCFzgHMolhPBmDho;
            ihBuQKcNtbTHWOup = RJeedGFhjHIROZx;
        }
    }
}

kQniFxZ::kQniFxZ()
{
    this->VocqcqQ(string("CFcRDXWTzhjVBfPUiFRaetJKoyHveqAzhXPfMdCCJWFYisRqeUycvqWlRIYjacIoeyJHbrTXrukXUFEGHSkQMmpmugGSAxjlpVVmvWEMJmgUatKeGpyqkIAUnolVAlYEgAtskNZQrvihuZZZxnobmowtrUijpWvZQTJTuBoncfGNzqorAzgtoCHWUnWgcgWsfSlkRbuASpvdRTSkosvSTlJjnjfNTKJMVSlgWozYNhVEp"), 1871982021, false, -479187.09847713774);
    this->TgukCdT(-412973840, 255878784);
    this->CyueIki(false);
    this->YisfNFvwwDLJti(string("knXJUNXLrxBWFSpcXqUaBzdmKrzAOJdKZQR"), string("KQMxVeRzKaKmcaNEnrtnYPkRXNMVrSsqHfuKDCAZJDNftIDxCCOzyJqnCPdRtqHSGDpxFRekkhnTaZyjjtALLPQshwzarCufzJRsVFUZTPwYeKdmhSmXvLFLBShAkrkexkgOFRTeJehJioaGQswoSVgWLLUYffVyLiQtWYWqMmhFTXgOffmfiOvGXMjfQDKjhFqPeMq"));
    this->lnQjQZPs(string("OtiCtvxKAACjlDUWKMFaqNCGONZDmEDUfoSKwcqQkDRafKEbPwzaXZzihKQHQqKCtffkdWWSXVMexZmrDJKNkdHGTwhEArkiWwHeUS"), 759828.5946152597);
    this->xLCxgVA(string("RGrZTEKXLvqCMRbkSTYbwCIxPZfhdPcDCSpgpBzaIcvjoRNIbAWAumzIUInpjbnwxoIdKhUUdgRgHFAjaTlvHuhcxeZzkzXiAmtaLoECsJVjGtgpoCBItjynTTrWetSmjQSyqVwqBgRYBhCUPpJacYJdJdaWhwViZJDpbkKzfSaPZtatFyPxwHbPjrxgdyVwQmqazWOKnHkVmeOgDLPxVDHqizehmWIKlTj"), true, false);
    this->xxJLGr(-285172.7353519076, 177276.8805160269);
    this->FVvUdZhnxCk(true, -590677.9696858143, -848617.6269115143);
    this->zJAMERlLqhaUPtlb(false, -26783.12337600873, false);
    this->WDTfDdqcFw(547309.4713349305, -1617071484, string("OaLJOXLrMWBCbWBYHYDFJVKOiuVhpJcaDTCEXBYcvdKkhAboiMbXFvpAebJypNIJMQScTSTGUibwIvKuNTFlbgVRrYcAXqgocbFENXRaGxQrHWEWbRkTGWcpfFQUqhJGuZDnhHzwblmaKjrAfcVgKPxgpQpTOazKzzLkjwAVAniPzSYmVfLwVF"), true);
    this->LAlcx(false, string("uzzVHyzWNAzrIruVoaxhofUtNFjZLXNckTpztjYtvvxkYjvtPqYHtTwZbTXssIUjOahmElCMSXsOkAQfNPOsTds"), string("ZsfnjxPybDnFUMiONvUNNZWxGGEkXREEpuBuzzOthODgNiDRViqmSgVTSRSrDhXYAJWiisplLYBvxfxKXwOKIlugFikJJLFazyrSkgAxpGmqpBBJwsSgklyomVdKyAbkbnyEltWuBnbAexFnzZxeKpUzcvWpZPCIEmndMr"), 903203.1844749224, -880905.9424782514);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JqCPw
{
public:
    bool dEZOsNKew;
    bool MYahwZHWrQ;
    string zlEPPTJdrmWvcsl;

    JqCPw();
    string rDLjjwT(string oLqcoMgFbEmqI);
    int UFnQTTtmBPaBfEie(bool XHrWUOj, bool VKaMtqxMMyiL);
    int hHntioH(double QrPopEyjEJO, int oFBanTQI, double QdXuogJLScbsAr);
    double tHduiDQvXD(string YZFJbqar, bool tcAkbtkf);
    void zHeyVolWQZZokZq();
    int pFjyOvSHrmSk(string orXxQLsZxNESiHRd, int dLVQm, string xGRnsoAEKjQuzx, string IvJIpfryWemaSl, bool iYHlRgO);
    bool jsrSaZtVY(double mqJeRzCdQdR, int FhOpStigJaoaOoxD, int OdQTFsNJaieOl, string ToPWGnz, double cSQDGyaFZULePCW);
protected:
    int iYiHWYKSSn;
    string ugrRNv;

    double zQZCyNDfNSiRr(double CjMqjijPruoCzTim, double WoqHHVQLjrUPv, bool hQtywZBlPlSkZ);
    void aZJLRONLj(double XkvFEKAgxg, bool gPqZFRUDdCTSxYMZ, double wqhdhKUdZZgOacg, string afyTRU, bool geckoky);
    void xzVEaPFPt();
    bool XpgXqTtiOTS(string wXriclbExBTzV);
    int ffGIisZXn(double DVBQLciPI);
    int xSFFNOpngGCR(bool PgMNv, string JofhWLaFrEuAH, double hsFUKXZojvHojCfQ, string LskbYPvKWtBmt, double lKlSNmJxMxtoi);
    string hqQOAJfgI(string rlJKEsGmTda, int HjrjH, double biPhms, double WmNvqzpUoKO);
private:
    string YjOWrWlKIh;
    bool tkGzjTbXe;

    int tIkAWKoRe(bool RgOOvOas);
    string kNPBGMqQKPd(double eFOXupvGxPR);
};

string JqCPw::rDLjjwT(string oLqcoMgFbEmqI)
{
    string GqeGC = string("KIaEvKOmHYICxEcZFlMRjSfaFPfLyfUPqqLOLJNnDzoYYbDTvOhyPDdKDWmXSk");
    int MhpoJbdtEefDry = 515313783;
    int QSaKXlXi = -1369836528;
    int ruZoMU = -1531741924;
    string SaiaeGwe = string("EpEsrMcLgSaVORqoEVlseKMolxJrcbuGYBWOEEqYstHodvWuZBBurEyZWGunfWAueAVHsIFmfdwgwtdLYjjPIUpnxfouxwiGgLioAmYzQmjboUoVigZFAljGHCMpOlKQEDAuPYgkbnTEBVPQaavaMEuFaVfBWyaiBQQONhnabIrBLyHLmlqeOjZZFwQVsxULdhqhzccefwNXljZpVuCPpCEyQWaqlWgzQNMBzLDkfKCqWOfzeqcNNvkK");
    double zbpTnkN = 148456.6964629849;

    if (SaiaeGwe == string("EpEsrMcLgSaVORqoEVlseKMolxJrcbuGYBWOEEqYstHodvWuZBBurEyZWGunfWAueAVHsIFmfdwgwtdLYjjPIUpnxfouxwiGgLioAmYzQmjboUoVigZFAljGHCMpOlKQEDAuPYgkbnTEBVPQaavaMEuFaVfBWyaiBQQONhnabIrBLyHLmlqeOjZZFwQVsxULdhqhzccefwNXljZpVuCPpCEyQWaqlWgzQNMBzLDkfKCqWOfzeqcNNvkK")) {
        for (int krvKBQD = 1535741729; krvKBQD > 0; krvKBQD--) {
            MhpoJbdtEefDry /= MhpoJbdtEefDry;
        }
    }

    for (int HsCpJk = 1029365858; HsCpJk > 0; HsCpJk--) {
        oLqcoMgFbEmqI = GqeGC;
    }

    if (QSaKXlXi == -1531741924) {
        for (int TbPiYe = 341866205; TbPiYe > 0; TbPiYe--) {
            MhpoJbdtEefDry = MhpoJbdtEefDry;
            ruZoMU = MhpoJbdtEefDry;
        }
    }

    for (int xnFYU = 2013188519; xnFYU > 0; xnFYU--) {
        zbpTnkN = zbpTnkN;
    }

    return SaiaeGwe;
}

int JqCPw::UFnQTTtmBPaBfEie(bool XHrWUOj, bool VKaMtqxMMyiL)
{
    int opgypNkZiTinppQD = 676618719;
    int EmUCVYzdpJoifk = -247585614;
    string suSEEB = string("NaREFWCimVJXmiWMZVpPwCencmlJdnDGDTaoXKlcNdlNAvDeQaIleyUODnvGHIuHiDVGyXKEWcKzIjqiRWWtABTxb");
    bool DJYlvlmMeyEVr = true;
    string RTCFleojahDiE = string("DkSESiSBOQxQsiXPLHzOEMOIPcgqYKOSUZHOqDpMLCpwBYwDNaAniqjIfdudOHELFnytzrqrzNDfMuYEXKMyWeciavveYJQtJjQwCxYGHlC");
    bool BAhzBOcNMDFTMXe = true;
    int lvoObtBOHqwwxt = 325771833;
    double xSHFpcPcaA = 256083.95916357476;
    string OOKsvDQ = string("EHopxxzpPyGWDPlsusIkrLnNIJJRLllNZPHWtMUBgRhfqTZxKXFxUmFipaDtDrOjwbNWytGTeKGAxeMHLMXuwaNJArTsotbmoUwtkLVcwcoKQOraxBnNkFDIYycdYaqaeQSEoFwEHeIjQbyUEWElyBRFxGQWdFWHVzceTEHYBKapivrAf");
    int DrMLJGDjqofmMKA = 699369276;

    for (int ZkrurtJp = 1950590337; ZkrurtJp > 0; ZkrurtJp--) {
        opgypNkZiTinppQD *= DrMLJGDjqofmMKA;
        lvoObtBOHqwwxt = DrMLJGDjqofmMKA;
        BAhzBOcNMDFTMXe = VKaMtqxMMyiL;
        lvoObtBOHqwwxt *= opgypNkZiTinppQD;
        OOKsvDQ = RTCFleojahDiE;
    }

    for (int WjtFMZpyjCXzYKF = 273762093; WjtFMZpyjCXzYKF > 0; WjtFMZpyjCXzYKF--) {
        RTCFleojahDiE = RTCFleojahDiE;
        DrMLJGDjqofmMKA -= opgypNkZiTinppQD;
    }

    for (int LuSkacWsTbF = 376348555; LuSkacWsTbF > 0; LuSkacWsTbF--) {
        XHrWUOj = BAhzBOcNMDFTMXe;
        opgypNkZiTinppQD = DrMLJGDjqofmMKA;
        lvoObtBOHqwwxt += EmUCVYzdpJoifk;
    }

    return DrMLJGDjqofmMKA;
}

int JqCPw::hHntioH(double QrPopEyjEJO, int oFBanTQI, double QdXuogJLScbsAr)
{
    bool wxkEqMPIOUZUbt = false;
    bool RwnCcxRTlA = true;
    string mbbwRoWantlUlxyA = string("MBMTJulyNFqQcNHeEXQREduDXJAhWkSBPkQsQTZaVQILOZzsaevkEHYDSnDVyqrrHCfhlSjrCJwkMrINxAGFsEqaGgvnOIPchlnwSwFpwMnPXRtsMJsjqRJzpVRckolkIgzzUgWVUrDWFXagnSUOHNWkYifMLRAvDbRLUbVywSMkDqdnQEgvktjWkkXfZJRZUqLkQjuCMN");
    string KpPzlyYYjKYJ = string("XeAqrsKCBOFLFMYGghthphfOeKaLmMdAdECsllehPKnYFacvitYWaiFnAZukXSDlrKAQefAlPNYQiTMEtERVpixlDbAFAlQxQicJRrTASlHZqrcBJULSQFASKRLTQHhAxklfJPSqRnvhBODJWMZcmqigJLSoNLMYrPurvTUyzMOghtXXvNEZOuPdGsRgUH");

    for (int hApdj = 889281507; hApdj > 0; hApdj--) {
        oFBanTQI /= oFBanTQI;
        mbbwRoWantlUlxyA = mbbwRoWantlUlxyA;
    }

    for (int sGlUvOYGkf = 460066674; sGlUvOYGkf > 0; sGlUvOYGkf--) {
        QrPopEyjEJO = QdXuogJLScbsAr;
        wxkEqMPIOUZUbt = ! RwnCcxRTlA;
    }

    for (int YUwMwGxIEbdKR = 124407652; YUwMwGxIEbdKR > 0; YUwMwGxIEbdKR--) {
        RwnCcxRTlA = wxkEqMPIOUZUbt;
        QdXuogJLScbsAr += QrPopEyjEJO;
        RwnCcxRTlA = ! wxkEqMPIOUZUbt;
    }

    for (int XEGyWOzwHsH = 1203927649; XEGyWOzwHsH > 0; XEGyWOzwHsH--) {
        KpPzlyYYjKYJ = KpPzlyYYjKYJ;
        KpPzlyYYjKYJ += KpPzlyYYjKYJ;
    }

    for (int upKfmYjgvHPe = 1849296361; upKfmYjgvHPe > 0; upKfmYjgvHPe--) {
        RwnCcxRTlA = ! RwnCcxRTlA;
    }

    return oFBanTQI;
}

double JqCPw::tHduiDQvXD(string YZFJbqar, bool tcAkbtkf)
{
    int pMYEWXJGnmYImZpD = 1433183252;
    string nSsoNaTkRYGsMbDw = string("IlCfAxwHgjhlMleLJBthWvflpiSIMTDOUfhLfRyoNTAPidUXUsxMDlCMOluisVBwcqrgzejDpUpjHYsGUCTVQtqbZzHUzczxRhdLWWdEjgWoEDClGknUCPZOLaJxtDBhnWUydVjJBTJZmAZWMmmzIJeplHyCDkRjWFXyJNWsSKcThbUYPvhCqwHIZmZowiJMVyNB");
    string azINqiitnlgQ = string("LzBKHHAQOKelHqKYCGJtCAWWMIGVdFPQapoNRphrmzYJZLBxgprKVeiqcPujEoFDfNFWujBtmvjTQgPUOHXSoWnzoOoCdzhQmruSxSFeDZbJaKkqRtzKWUlnryTpDeoNQZvoAVfNNvHvDBdKULLbXNnUClJ");
    int nKeQhkSz = -565473015;
    int XpwuXhVA = 1546113251;
    bool CaDIJAGCaPB = false;
    string srgXTrDO = string("oJxoQBFnwNUUdbgKupPsBtYASpgxYftITJjbvTqPkSvnPkrkUhUeHmRAXarXoMsBcUCyqZDPUSgbcbnsKvRxNisKkOPVlhbhWYADZSDDORBtMhzorrYBCxFgVtmmsWMtchhjoYnjSGyiMesGISKalnpLouCCGZDnLpJrocCzoudnAfMosJzAYIMPKmeqeamnqMyatJgzjJsQHxviIgGMwwIjSMMdllPGmUwm");
    int TevcyGFPb = -856391332;
    int yjIzkQWlNA = -1552940989;

    for (int jFPjwRcl = 588632138; jFPjwRcl > 0; jFPjwRcl--) {
        srgXTrDO = nSsoNaTkRYGsMbDw;
        pMYEWXJGnmYImZpD *= nKeQhkSz;
        azINqiitnlgQ = azINqiitnlgQ;
        TevcyGFPb = yjIzkQWlNA;
        nKeQhkSz = pMYEWXJGnmYImZpD;
    }

    if (pMYEWXJGnmYImZpD < 1433183252) {
        for (int QEvGdtuvmz = 1787860839; QEvGdtuvmz > 0; QEvGdtuvmz--) {
            azINqiitnlgQ = azINqiitnlgQ;
        }
    }

    for (int usxNFv = 336861173; usxNFv > 0; usxNFv--) {
        XpwuXhVA *= TevcyGFPb;
        pMYEWXJGnmYImZpD += nKeQhkSz;
    }

    for (int VONNGgHoBHrjqHVC = 612077639; VONNGgHoBHrjqHVC > 0; VONNGgHoBHrjqHVC--) {
        XpwuXhVA *= yjIzkQWlNA;
        YZFJbqar = nSsoNaTkRYGsMbDw;
    }

    for (int piIFAdbH = 18766786; piIFAdbH > 0; piIFAdbH--) {
        yjIzkQWlNA /= XpwuXhVA;
    }

    if (azINqiitnlgQ == string("kJyrFnmqcmDGrvahtTALafWQoGemhNNnXBOwHNIWoXREYecuDpMFDRDLcUWSwPCBMFltiRwxVzhIpESXxykhkDGgismjlNSOcXCkuqbyFjYCTRjQrzSGXsBHpPCrkMwsnazPfTvMemadDrLuU")) {
        for (int swqHJYj = 1433124596; swqHJYj > 0; swqHJYj--) {
            nKeQhkSz /= XpwuXhVA;
        }
    }

    if (azINqiitnlgQ != string("kJyrFnmqcmDGrvahtTALafWQoGemhNNnXBOwHNIWoXREYecuDpMFDRDLcUWSwPCBMFltiRwxVzhIpESXxykhkDGgismjlNSOcXCkuqbyFjYCTRjQrzSGXsBHpPCrkMwsnazPfTvMemadDrLuU")) {
        for (int ldijIv = 1452655746; ldijIv > 0; ldijIv--) {
            nKeQhkSz += TevcyGFPb;
            nKeQhkSz = yjIzkQWlNA;
            nSsoNaTkRYGsMbDw += srgXTrDO;
        }
    }

    return 593385.5907644144;
}

void JqCPw::zHeyVolWQZZokZq()
{
    string AVnfAub = string("PMCxXWvLyFmblasGOiVoe");
    double MwJsf = 569109.9135741424;
    double ZGQgvyRi = -776874.8491141223;
    string brTLmynjW = string("RPgmVOpRnAusOdlzKqueojoCURMgEbiI");
    int gKXKzizxvdFryXkZ = -2086418072;
    double DgkyIIcIf = 998539.2780537056;
    bool mYfpzRcslSKqAQf = false;
    int kORBxD = 1754765011;
    bool kZWjyZXvdoyUMn = false;

    if (MwJsf < 569109.9135741424) {
        for (int GPfdtALQDL = 494792889; GPfdtALQDL > 0; GPfdtALQDL--) {
            DgkyIIcIf -= ZGQgvyRi;
            AVnfAub += brTLmynjW;
        }
    }

    for (int ituBuEpgpsXn = 1006365698; ituBuEpgpsXn > 0; ituBuEpgpsXn--) {
        mYfpzRcslSKqAQf = mYfpzRcslSKqAQf;
        AVnfAub += brTLmynjW;
    }

    if (MwJsf != 569109.9135741424) {
        for (int JfhKkKCamu = 1968450073; JfhKkKCamu > 0; JfhKkKCamu--) {
            continue;
        }
    }

    for (int WPesbcovweojbTD = 277670327; WPesbcovweojbTD > 0; WPesbcovweojbTD--) {
        mYfpzRcslSKqAQf = mYfpzRcslSKqAQf;
    }

    for (int NiwaWjU = 365602699; NiwaWjU > 0; NiwaWjU--) {
        kORBxD /= gKXKzizxvdFryXkZ;
        MwJsf *= DgkyIIcIf;
        gKXKzizxvdFryXkZ -= gKXKzizxvdFryXkZ;
    }
}

int JqCPw::pFjyOvSHrmSk(string orXxQLsZxNESiHRd, int dLVQm, string xGRnsoAEKjQuzx, string IvJIpfryWemaSl, bool iYHlRgO)
{
    bool PllCFsHPDxEa = false;

    return dLVQm;
}

bool JqCPw::jsrSaZtVY(double mqJeRzCdQdR, int FhOpStigJaoaOoxD, int OdQTFsNJaieOl, string ToPWGnz, double cSQDGyaFZULePCW)
{
    int siewfhSLtfM = -311830905;
    int cnoqELvuD = -1865190530;
    bool xDWuLHqQeaedC = false;
    string VvwxvypXaZwSKe = string("tfCpnO");
    double dRQyWEFRkg = 989492.3943377716;
    bool XgADOz = false;

    for (int hvIijZpth = 597440046; hvIijZpth > 0; hvIijZpth--) {
        continue;
    }

    for (int cwzxx = 666497032; cwzxx > 0; cwzxx--) {
        mqJeRzCdQdR -= dRQyWEFRkg;
        FhOpStigJaoaOoxD -= OdQTFsNJaieOl;
    }

    for (int wirGKEi = 1112390598; wirGKEi > 0; wirGKEi--) {
        continue;
    }

    for (int DoSpibOR = 415645474; DoSpibOR > 0; DoSpibOR--) {
        siewfhSLtfM -= FhOpStigJaoaOoxD;
        cnoqELvuD /= cnoqELvuD;
    }

    for (int QJRpQPnRNTZ = 784229670; QJRpQPnRNTZ > 0; QJRpQPnRNTZ--) {
        FhOpStigJaoaOoxD = OdQTFsNJaieOl;
        cnoqELvuD /= siewfhSLtfM;
    }

    for (int DnNQQBhWWkT = 1239890148; DnNQQBhWWkT > 0; DnNQQBhWWkT--) {
        dRQyWEFRkg *= dRQyWEFRkg;
        FhOpStigJaoaOoxD /= OdQTFsNJaieOl;
        siewfhSLtfM /= cnoqELvuD;
        cnoqELvuD = OdQTFsNJaieOl;
    }

    return XgADOz;
}

double JqCPw::zQZCyNDfNSiRr(double CjMqjijPruoCzTim, double WoqHHVQLjrUPv, bool hQtywZBlPlSkZ)
{
    double hCQbwjSalTNZzD = 211550.5854602215;
    int eRZyvmZZSspqKg = 1356189135;
    string SUONEqqp = string("KwNFKvSGGRjCtOtSlOkqkSlurIjeHAEeXFj");
    int ijmmJefpYw = 1532851304;
    double hhmjBpIjUOT = 432315.78841841855;
    int RmBiQfYAimqQKcRl = 853913209;
    int TMDLJmtfEoTpD = 835278107;
    double ANihTz = 12522.182564128325;
    string kQhJZ = string("nOVdXpiuDClRjEOZvltQeoSqambErsBaRCIzhcGKDzFqrezjxwjHEiOzZOlmhboLa");

    for (int GdysZXbkm = 2016664588; GdysZXbkm > 0; GdysZXbkm--) {
        continue;
    }

    return ANihTz;
}

void JqCPw::aZJLRONLj(double XkvFEKAgxg, bool gPqZFRUDdCTSxYMZ, double wqhdhKUdZZgOacg, string afyTRU, bool geckoky)
{
    double DjtbHcdkyIJG = 932653.6550847295;
    int PJYfCoSyPZe = -1788631372;
}

void JqCPw::xzVEaPFPt()
{
    bool NeHzFwlqvWXMnshm = true;

    if (NeHzFwlqvWXMnshm != true) {
        for (int fShuVopIyaHiG = 744843954; fShuVopIyaHiG > 0; fShuVopIyaHiG--) {
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
        }
    }

    if (NeHzFwlqvWXMnshm == true) {
        for (int VDoulcjS = 1711414252; VDoulcjS > 0; VDoulcjS--) {
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
        }
    }

    if (NeHzFwlqvWXMnshm == true) {
        for (int moBintJDl = 2117241766; moBintJDl > 0; moBintJDl--) {
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
        }
    }

    if (NeHzFwlqvWXMnshm == true) {
        for (int xGESOyPELE = 1822615183; xGESOyPELE > 0; xGESOyPELE--) {
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
            NeHzFwlqvWXMnshm = ! NeHzFwlqvWXMnshm;
        }
    }
}

bool JqCPw::XpgXqTtiOTS(string wXriclbExBTzV)
{
    string idfwSrTGQZMPPcO = string("lhPShgtbXyuuNluQIdUmJBNmORcfjgbK");

    if (idfwSrTGQZMPPcO <= string("fwXzVOLTgnzrBWpJtxQHMGilNlNMmWpnOgHpEUNEUiBGRTqyOUCkMmFhfLtIvCBsPMkXdPMxwUq")) {
        for (int eIJsZcFtiU = 653683139; eIJsZcFtiU > 0; eIJsZcFtiU--) {
            wXriclbExBTzV += idfwSrTGQZMPPcO;
            wXriclbExBTzV += idfwSrTGQZMPPcO;
            idfwSrTGQZMPPcO += wXriclbExBTzV;
            idfwSrTGQZMPPcO += idfwSrTGQZMPPcO;
        }
    }

    return true;
}

int JqCPw::ffGIisZXn(double DVBQLciPI)
{
    int oeBcyb = 727521077;
    double DLUXNVguGvVOTDx = -419586.10148736456;

    if (oeBcyb <= 727521077) {
        for (int VwjrrAawxZRK = 562566164; VwjrrAawxZRK > 0; VwjrrAawxZRK--) {
            oeBcyb *= oeBcyb;
            DVBQLciPI -= DLUXNVguGvVOTDx;
            oeBcyb /= oeBcyb;
        }
    }

    if (oeBcyb >= 727521077) {
        for (int kIJErTtngHKeSuOu = 295406762; kIJErTtngHKeSuOu > 0; kIJErTtngHKeSuOu--) {
            continue;
        }
    }

    return oeBcyb;
}

int JqCPw::xSFFNOpngGCR(bool PgMNv, string JofhWLaFrEuAH, double hsFUKXZojvHojCfQ, string LskbYPvKWtBmt, double lKlSNmJxMxtoi)
{
    int ojaNY = 483494;

    for (int AhBxBHIGKn = 2023390614; AhBxBHIGKn > 0; AhBxBHIGKn--) {
        lKlSNmJxMxtoi -= hsFUKXZojvHojCfQ;
    }

    if (hsFUKXZojvHojCfQ != -142252.61975630067) {
        for (int yweDdeTWZw = 769277802; yweDdeTWZw > 0; yweDdeTWZw--) {
            continue;
        }
    }

    if (hsFUKXZojvHojCfQ > -142252.61975630067) {
        for (int bzUrqB = 1077745926; bzUrqB > 0; bzUrqB--) {
            LskbYPvKWtBmt += LskbYPvKWtBmt;
            LskbYPvKWtBmt = LskbYPvKWtBmt;
            lKlSNmJxMxtoi *= hsFUKXZojvHojCfQ;
            LskbYPvKWtBmt = JofhWLaFrEuAH;
        }
    }

    if (LskbYPvKWtBmt < string("rKtalcbXpuJopOMPJVtQmEEaSYPPRgpTYAJjYEMTleAzolozDMWZDIFPjGyhsZZQTIBkdrIzIZZdhOdScNpBRQqwoqmmstBUfgNxHRltcFcxMfWoSMlUJQQkHU")) {
        for (int rgpaTntUxPknn = 1898950689; rgpaTntUxPknn > 0; rgpaTntUxPknn--) {
            continue;
        }
    }

    if (LskbYPvKWtBmt <= string("rKtalcbXpuJopOMPJVtQmEEaSYPPRgpTYAJjYEMTleAzolozDMWZDIFPjGyhsZZQTIBkdrIzIZZdhOdScNpBRQqwoqmmstBUfgNxHRltcFcxMfWoSMlUJQQkHU")) {
        for (int vQHLrhDHQMvI = 1020186757; vQHLrhDHQMvI > 0; vQHLrhDHQMvI--) {
            LskbYPvKWtBmt += JofhWLaFrEuAH;
        }
    }

    for (int oUZstkLbD = 550663035; oUZstkLbD > 0; oUZstkLbD--) {
        PgMNv = ! PgMNv;
    }

    if (hsFUKXZojvHojCfQ <= -142252.61975630067) {
        for (int jeOmoz = 1145953318; jeOmoz > 0; jeOmoz--) {
            LskbYPvKWtBmt = JofhWLaFrEuAH;
        }
    }

    return ojaNY;
}

string JqCPw::hqQOAJfgI(string rlJKEsGmTda, int HjrjH, double biPhms, double WmNvqzpUoKO)
{
    string gYfQxUwqoQzahKCw = string("XccEAklihIZYAHJgsTvrPkINrPJKeKIbfDFABHCAELrNiULLlPVWMjezniAEOcsDvxsengrZtSfiWesPbLfmuvAKtifdTzagibnqdKXUkqKSivLKSaRkNljnbBqlyBDtuEsSCsTzcYdTBGla");
    bool nSnzgpVGTu = true;
    string KZXXznrqnsTeKciS = string("HwTOReqMnHBnifFjQVsNWuykqxuLKEApslTSiYmfWfmK");
    int kPMoJMxWMo = -1132397102;
    bool uaMsdmAFJnI = true;
    int MzvOhOSUh = -686274399;
    bool ViZKVPJLia = false;
    string lxOQMUZdUT = string("OjlEubTHxcxPdqSOBNFTwdNiaIShEKuanwReVkRTFEDBIiOoxXKHnXEOeICPZIRnrvAcKOHFkTGJSMbrfYLddQENNSgVdtrlUBVpXNXSQuckxTlAhpnsRhnxwwFCTVLZUWXlCHdtWqEgROmzuHeByiVNFiSuRASomHeRDzEmrwFOoGcn");
    bool pBKTxgYbL = false;

    if (HjrjH <= -1132397102) {
        for (int HzvUOwkWhXi = 871055881; HzvUOwkWhXi > 0; HzvUOwkWhXi--) {
            KZXXznrqnsTeKciS += lxOQMUZdUT;
            uaMsdmAFJnI = pBKTxgYbL;
        }
    }

    return lxOQMUZdUT;
}

int JqCPw::tIkAWKoRe(bool RgOOvOas)
{
    int EHzJOarmgoT = -1318506958;
    double MldKs = -817006.502563242;
    string CtCSzOLcfXaMALW = string("nrqPPCqDXMhivEkLDIMDjTwqoDNHRmtAkeJsGqJIVQvEvZTTaloQvsJjskNAtjJjsuhrbTWRtxsNsQpCOFLjWiWsqFxCxWupmGJcZwyQy");

    for (int kSjlKlWcwQCYNpR = 1337678512; kSjlKlWcwQCYNpR > 0; kSjlKlWcwQCYNpR--) {
        MldKs /= MldKs;
    }

    for (int LVOSIULLW = 1704822516; LVOSIULLW > 0; LVOSIULLW--) {
        CtCSzOLcfXaMALW += CtCSzOLcfXaMALW;
        MldKs += MldKs;
    }

    return EHzJOarmgoT;
}

string JqCPw::kNPBGMqQKPd(double eFOXupvGxPR)
{
    int dFYGuLJDdStvpIg = 986697392;
    string voNDEtfKaIE = string("WpOtcZDLPJvKPPVlJhHncputtkmEXeQsgGbcMzQjGNorBvADsItDjGrHiqUnYWRNIryYHeVpWxtcQbwzHTqCmbbdcmzFbPnlJcGclmcZxwAmCAtSlZrJWPTaTMhpxwCIqCrYevwUVapBDzXLwoZEZUiROmmHIvfxMKkiauSyppDEdpBVnAnIvVRKPFcuojQStAApvZkJVglKSDrOlVFNyCQhUktapZkheUjiyKoUWeKstsmnmDrhYJjlieGuMCv");
    int emnWtdNg = 2085364646;
    int wUkchxEpwD = -599946897;
    bool gNelyekWZN = false;
    int mBdBdUPtPL = 1696699667;
    string cQJcjNcSiBep = string("PFLLpVTsLkDkZNFduaPnyOhsZvMkcZLEEXZTDJwmlHYlKtZDYexNzLLfrdMLXnvnXCDKJLHGaUFFUOgENKWPDfnyGrfMmMsFrPMQBpOGRzjHVowvtzYtiarRBgYFoqZUxcoCyqDBSElqgIXgrEnClOwxLQalsGmgoecJCmshaPHRUgJyBmfaNoOBANbgtCoWafnGwLiWynuwXTpyXivhPOhEoNUuGJyFWvaZEICXbIiMjOOfLEHqsvQk");
    int pugGplUh = 324885532;
    bool JBpjQffFuewtaXYs = false;

    for (int SpfpqPpfUAZBEBv = 242903318; SpfpqPpfUAZBEBv > 0; SpfpqPpfUAZBEBv--) {
        continue;
    }

    for (int HPLOhpuRILs = 29348181; HPLOhpuRILs > 0; HPLOhpuRILs--) {
        pugGplUh += dFYGuLJDdStvpIg;
    }

    if (wUkchxEpwD < 986697392) {
        for (int PXsOiKZCcitjJRiL = 1181518822; PXsOiKZCcitjJRiL > 0; PXsOiKZCcitjJRiL--) {
            mBdBdUPtPL /= pugGplUh;
            wUkchxEpwD /= emnWtdNg;
        }
    }

    if (emnWtdNg > 1696699667) {
        for (int vVudYvJVXVqIqwAT = 796208770; vVudYvJVXVqIqwAT > 0; vVudYvJVXVqIqwAT--) {
            gNelyekWZN = ! gNelyekWZN;
            emnWtdNg /= wUkchxEpwD;
        }
    }

    if (wUkchxEpwD <= 2085364646) {
        for (int eKcnBWJAAJu = 1494853894; eKcnBWJAAJu > 0; eKcnBWJAAJu--) {
            dFYGuLJDdStvpIg -= pugGplUh;
        }
    }

    if (wUkchxEpwD > -599946897) {
        for (int LxtMnQeJ = 474666896; LxtMnQeJ > 0; LxtMnQeJ--) {
            mBdBdUPtPL += emnWtdNg;
            mBdBdUPtPL -= pugGplUh;
            cQJcjNcSiBep = voNDEtfKaIE;
            emnWtdNg = wUkchxEpwD;
            wUkchxEpwD *= emnWtdNg;
            emnWtdNg = dFYGuLJDdStvpIg;
            mBdBdUPtPL = mBdBdUPtPL;
        }
    }

    return cQJcjNcSiBep;
}

JqCPw::JqCPw()
{
    this->rDLjjwT(string("EGCjwMEPmkCOhxkmMFTgvSIPFVUcMFkYkaeUPtilDwMrbMxdaYsuClQJfMQvmNXEvjVJKztgwTxeGSGlvKzgKHVuUpikZouLAecqhsMXFBYVdWjTnhSvTQuAYKdDWHTCbrcTtCkenQmmrujBukknhPEWTjqdHxBLTTDRKcLHNpvJENdeiBmrxQnNPxZUWiUmkluRWDgzsBPkJWYQNXhLi"));
    this->UFnQTTtmBPaBfEie(true, true);
    this->hHntioH(-607847.4411338202, 1544603883, -460887.03855624615);
    this->tHduiDQvXD(string("kJyrFnmqcmDGrvahtTALafWQoGemhNNnXBOwHNIWoXREYecuDpMFDRDLcUWSwPCBMFltiRwxVzhIpESXxykhkDGgismjlNSOcXCkuqbyFjYCTRjQrzSGXsBHpPCrkMwsnazPfTvMemadDrLuU"), false);
    this->zHeyVolWQZZokZq();
    this->pFjyOvSHrmSk(string("PYsJRZpZwFbxmCoTpXGvxPtrzcWyAwXgEKYLvxNdAmqUrAtbJxgbfqoHSkTwIHJcubNwsRdlYAVbENgUWAYleTfZnCuWpQDLtBAVtsDIdroGnQLXQkXIwXKnOMNaBAZoQsmLsOSYcedajYoNHCkKpNMXcEMpWkcdldZwfTAZpctFYnKeXuBJfnmPfshNVAsysQrQHMcIYZPFXAFFgmssrlaOERTRkQPOUhNNPfkYAagFtPLZoFOK"), 521151988, string("rCgoyzyUKJjjrqQXyEwyXaQceMavZlpqtMJqAZhudCmpPdFTONoDfVMcNfnghEkCqmbaaRYwstatQuzscsFnhGxxbrYVunCCiIDAYmKJbtxjVjHzcHWEDcTOynLgQmcjUmBXiaVRbgRzanZLtvpRJOfYerLqeVRHzvXKwnvGdCnrugTaqWgOTLr"), string("AIBxcgkKSSbhFXoqMEJHcSBvbikPOGWkLhzUOcxmhjTOTmO"), true);
    this->jsrSaZtVY(525826.2542202898, -1033340080, -317945353, string("YPkUwDCGFfYtJTaDcVcDQHEGAPSRwGbWZKvnTPAgHYxPVJLtYnvlbDlEaizPlFwwokPuRcvqFPSejJvKrQEBzGHlxhrIJghYSXaTOWGhHxjpORuqbXDTqDeQFcXfrVVsXmRqrHdHpBjtijrZeHyDReMYbzJtDhcuwkSfXctRkQEwwycbCQJzHvSUzqnVyxSgmZr"), -35551.960151905754);
    this->zQZCyNDfNSiRr(114432.59972771724, -961893.949395155, false);
    this->aZJLRONLj(343305.3793631523, true, 774092.1589235954, string("ivXnakSpqTkDaNDvGIRpwaqbDbEaMOizmRrUEQeAZmhADOWyiXaULynbVxLKnXfrsFROcYmMvzIrUNzQQFtZbaJldlPRQntGgIichBBqzAYjLVcIgTUGBxRYuxdEVxRUyhvA"), true);
    this->xzVEaPFPt();
    this->XpgXqTtiOTS(string("fwXzVOLTgnzrBWpJtxQHMGilNlNMmWpnOgHpEUNEUiBGRTqyOUCkMmFhfLtIvCBsPMkXdPMxwUq"));
    this->ffGIisZXn(-161477.47398348516);
    this->xSFFNOpngGCR(true, string("EJrnkuHvpejArQnHpZlzsZsEzZEOgPdojOZwvuwTUlASZbgjcOeNQCvACInVnjOzwmHVQSXQSGStmaNOFhAHrMwUOeSLiPpeIPHTJHknrxsMAoRBMtHlOfVOjMTkoFFhoumLAGwsHGyEEQcJKg"), -142252.61975630067, string("rKtalcbXpuJopOMPJVtQmEEaSYPPRgpTYAJjYEMTleAzolozDMWZDIFPjGyhsZZQTIBkdrIzIZZdhOdScNpBRQqwoqmmstBUfgNxHRltcFcxMfWoSMlUJQQkHU"), 1036385.5336380689);
    this->hqQOAJfgI(string("qEmUMuWbJvGAQdOuEEVBntGbngTMguIInWHrPajFGjFDnMRfpQIxmhAtHXjMP"), -888485642, 858591.5430673957, -151720.19701266504);
    this->tIkAWKoRe(false);
    this->kNPBGMqQKPd(980246.6280047814);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DwFLANflmrVoA
{
public:
    string uMvMfZBEXOhmaV;

    DwFLANflmrVoA();
protected:
    int QEoOuegBxoT;
    bool SYRTotqasKSrzDww;
    int dSUyTmIgb;
    double eCXpkquAoJKcwOjs;
    double isicQMrs;

    int HEZqPNyhBShJVVMk(double RpMNGyqU, int Twyyd);
    string YRzjrCImwfqghvF(int acFEhrJHEhgPnqY, bool qCVhFVsHbbY, int aGhdj, string DXGkeNOOtXxfFr);
    void niRhVNVIsQKza(double xcUXGwy, int JtSkXPETMsvvnQvB, int lrJwCnhs, int VZfbTnBmvWmOlchM);
    int EbdVUOZwumz(string NAyjnTcdGUpGu);
    string VnewHKwIg(double EmYLGb, bool eeEgx, bool htZTDgkSeVRxfGJz, double RJIcYbPHcIi, string VQJccCeTwlvrpp);
    void hffEZ(double cJbFrjvPNzgIZ, int ZCHExlbYAPd, bool CWIKQvjEeISbXMU, string JPjzeTxbzSKzEf);
private:
    string qqiAS;
    double XZvMgWE;
    bool VlbODFJdksMyNE;

    bool GOiwZqwJ(int pkNbNiCSu);
    double PWqbTSbhyMg(string vKPFhsmFMeAOB);
    bool SAXsj(bool nwyuF, int TnKMppoowwIcYLn, int CNcbOtHEabr, double TchgFrlRlKKMOMC, int wYQRWNgCtWt);
};

int DwFLANflmrVoA::HEZqPNyhBShJVVMk(double RpMNGyqU, int Twyyd)
{
    double tgwoleqpB = -472246.1324405367;
    int VQJNVTiwgX = 2067579541;

    for (int VQAPeyMCfucT = 184255774; VQAPeyMCfucT > 0; VQAPeyMCfucT--) {
        continue;
    }

    if (VQJNVTiwgX < 2067579541) {
        for (int VfcSpIRl = 1736247986; VfcSpIRl > 0; VfcSpIRl--) {
            tgwoleqpB *= tgwoleqpB;
            VQJNVTiwgX = Twyyd;
            RpMNGyqU /= tgwoleqpB;
            VQJNVTiwgX /= Twyyd;
            tgwoleqpB /= tgwoleqpB;
        }
    }

    if (tgwoleqpB != -472246.1324405367) {
        for (int OGnAOQBtZFZs = 1088618263; OGnAOQBtZFZs > 0; OGnAOQBtZFZs--) {
            RpMNGyqU = tgwoleqpB;
        }
    }

    return VQJNVTiwgX;
}

string DwFLANflmrVoA::YRzjrCImwfqghvF(int acFEhrJHEhgPnqY, bool qCVhFVsHbbY, int aGhdj, string DXGkeNOOtXxfFr)
{
    string QslYAR = string("VVwodNryHOczNrkyjakSofjekgvpZxgmEWKupfLZkpYPXWruBHImoeLGhXuzMNCIXbFtkhngrOLPOZxPuKTPvoBRIZxqFxDErVbqVqUSISvWgWwrYvgdzidkJGThEKnRExDKBApduZPvUdXVNFPtCdzRtXqtDioFUvVBHLvLPSdUqwDiiBHYscZADfdYEmKZcmFXpHGZsGyhZVbeZcwLZsMIxoSsOtYMoSziWvBF");
    int pEgJkEk = -825461745;
    int HyIgLVTIJMyGNoR = -1539620200;
    bool PofqxcIycuawdTRf = false;
    string tBpwAu = string("RcNEDmnJSNEPmKpvLVCyAOAZQKjxjdbgeiSIKwRGJjOdcIRBQCsIjrHYpxeFViupMzPPgEHnaxujzbwDMwPwciEFpHFKNsgnqTndfuLUEkEtobHPkZtelEzLHajOntYnnxugnsgtPSnaJpyVejTihzxVPOJRRDMKewCxJnueHHTcXVzxrGjMuyxPsttAvOeknKUQhRYzaLayueOswEyhLjedUEUvOPYKtvlEHJTArDtrM");
    bool lxlimWbRGfBpbeB = false;
    int StadXaNulcJwQs = -300065534;
    int KjqcuqSshE = 1386147215;
    string JIgSolNyFsQNzO = string("SmUzXrqJbJnaltFHtEHxBVTdhGEugTPaXONjGCYaTWpPvxelRILnKNtFzFJpXhreEbLPYvybZPCCkIiAzdMIsxLkqgLAzJsmYjShdzzJTKplpTiBXyTpswbKKBRMJVnynRMYVaGOQRpIHmWvWDGmkdelzojAfXKxMcObulbpMgPpCvwnFtxfi");

    return JIgSolNyFsQNzO;
}

void DwFLANflmrVoA::niRhVNVIsQKza(double xcUXGwy, int JtSkXPETMsvvnQvB, int lrJwCnhs, int VZfbTnBmvWmOlchM)
{
    int rwbDbr = 275212622;
    double qdiyznZcXByVB = -624362.5252338749;
    string nfKqMRhVuZohb = string("seJlpTorJNDztvWdBDVzIsOiYjbjUlqEdUvGTHjraAUDFjVCcdhdshmHjfnwwnnMrGNNghCcZxOgTblCYmgcLABPiqhucrBnIJnNVJOPkjyKlGPxLEUfengabCaIiloqMCpLEANLMozCQKFUBYigk");
    bool VwhOhlupqSJ = true;
    bool oFLqDc = false;
    int ReUSJoEXNWTXSkmI = -337034746;
    bool aBoGJOqRFwxhgH = true;

    for (int bVgLZPhjmlFBnD = 1113778014; bVgLZPhjmlFBnD > 0; bVgLZPhjmlFBnD--) {
        ReUSJoEXNWTXSkmI += lrJwCnhs;
        VZfbTnBmvWmOlchM -= lrJwCnhs;
        rwbDbr = JtSkXPETMsvvnQvB;
    }
}

int DwFLANflmrVoA::EbdVUOZwumz(string NAyjnTcdGUpGu)
{
    int PcSoiMLO = 676734701;
    bool wsPXTROfNr = false;
    string PPpvAwLjHGS = string("dfKwyjDqaqveFBVNMWkLjfVZLYlpOGchxzzgCPFWYkmHtuXMVMUdGaGULCTcfZLeMsHpmBXgNkdpCtKgAQvIHUDCtARljDrzwQUWWMDUlAkKTsmztaSJJjEdZQZKMGnJCfLSWPmzwVQaVWFsNshlZvipwNACRvtFyWIxhUhnOCuKoaNrQODZKMmIzqsbCnofmhpiZa");
    bool NaVLi = true;

    if (NAyjnTcdGUpGu != string("wnGvSYfjAUUwpCkQIxCaQRhNJvVniFzdzXdeBEUOofnVJCfpcJzwA")) {
        for (int KMQWnqAa = 829203974; KMQWnqAa > 0; KMQWnqAa--) {
            wsPXTROfNr = ! wsPXTROfNr;
            NaVLi = ! NaVLi;
            PPpvAwLjHGS = NAyjnTcdGUpGu;
        }
    }

    return PcSoiMLO;
}

string DwFLANflmrVoA::VnewHKwIg(double EmYLGb, bool eeEgx, bool htZTDgkSeVRxfGJz, double RJIcYbPHcIi, string VQJccCeTwlvrpp)
{
    int EodixOpcOr = -774780048;
    string eXoJuuyt = string("rWBFkTkPwqtTwgBXyinVFUmLTfPbAMIlsfSQCASLuhXTfFOGJtTgZnDlVoUakpAZHgtrJPLPpEyZftmKYqAULVouAfXjQvvnXYZkPVKfDbKKQLeJcKcHYHzgfWtFYngAJAFOBdVYwEgjCQmxiUJSTYi");
    int TTwlrPe = -1862248854;

    for (int YXLoBW = 193280793; YXLoBW > 0; YXLoBW--) {
        TTwlrPe -= TTwlrPe;
    }

    for (int ViOHalD = 1002459024; ViOHalD > 0; ViOHalD--) {
        htZTDgkSeVRxfGJz = ! htZTDgkSeVRxfGJz;
        RJIcYbPHcIi = RJIcYbPHcIi;
    }

    for (int rJBGxdCyBDnAaA = 1313326991; rJBGxdCyBDnAaA > 0; rJBGxdCyBDnAaA--) {
        continue;
    }

    return eXoJuuyt;
}

void DwFLANflmrVoA::hffEZ(double cJbFrjvPNzgIZ, int ZCHExlbYAPd, bool CWIKQvjEeISbXMU, string JPjzeTxbzSKzEf)
{
    string nYjKmN = string("MQolXMtlpbzHvTnGwJZKOdSNnaSaEgiVYsxL");

    if (nYjKmN != string("emNmKiTWiVFB")) {
        for (int TabisBPaiva = 195279101; TabisBPaiva > 0; TabisBPaiva--) {
            continue;
        }
    }

    for (int qVlJUN = 534181012; qVlJUN > 0; qVlJUN--) {
        JPjzeTxbzSKzEf = JPjzeTxbzSKzEf;
        JPjzeTxbzSKzEf = nYjKmN;
        nYjKmN = JPjzeTxbzSKzEf;
    }
}

bool DwFLANflmrVoA::GOiwZqwJ(int pkNbNiCSu)
{
    double UpiKAKG = 831218.4752527963;
    bool iJkEtb = true;
    string yptfOpWWyuhdfS = string("rRN");
    double OqnqAmN = -915127.4349910907;

    for (int RyLeUTDjbfaBmTG = 920845893; RyLeUTDjbfaBmTG > 0; RyLeUTDjbfaBmTG--) {
        UpiKAKG += UpiKAKG;
    }

    for (int IcctkOjXW = 70439792; IcctkOjXW > 0; IcctkOjXW--) {
        continue;
    }

    for (int lUiqXJShwTAjgxHB = 1318953402; lUiqXJShwTAjgxHB > 0; lUiqXJShwTAjgxHB--) {
        yptfOpWWyuhdfS = yptfOpWWyuhdfS;
        UpiKAKG += UpiKAKG;
    }

    return iJkEtb;
}

double DwFLANflmrVoA::PWqbTSbhyMg(string vKPFhsmFMeAOB)
{
    string ghAAOHZHAaZp = string("DILWHOHKYZVvRIjwkzbmctjfrNPTL");
    bool AhESCoRpNKqJE = true;
    int dBNjGxBBwAcF = -1368087535;
    string khhChw = string("aWwuWTpwfPkWuCLQzpJbnMJNeMnuFycuolFQgrSkLMdTeiSCufAHMzAFMHECpebEkbPquXjtnxQQaWqWahANaAQATASRsceDiUTHjnPfZrjvjpZvBGSVujMsnoszoiIRWUamZnVyCyHcHl");
    int CdaBGFiyrPc = 1765387148;
    bool BtrNGrR = true;
    bool qgmgjGpaBjEhzYW = true;
    string WBHAXXXD = string("LbVjXieaWiAqwuSnqHUXOtyhoFdnaeeiRZidkiZxVotKZdqrxkqSiQdUZUrScDIXDsfRryrcCKPOWmXJBpeftZFnWzBtoDgtvXrjikTwFTNjGHmyBhUbsJLfLGtGuXaRGoNeLWGtaCdGmQVuLqEqZkBCnnFFLpsDHcdOYQidOpbrwtGQVEMXbjAxsmAxQZMdyLg");
    bool nCNRgkWoBbbubAQX = false;

    if (nCNRgkWoBbbubAQX != true) {
        for (int YhxRgfWcZiakxsQO = 503981944; YhxRgfWcZiakxsQO > 0; YhxRgfWcZiakxsQO--) {
            qgmgjGpaBjEhzYW = ! nCNRgkWoBbbubAQX;
        }
    }

    if (ghAAOHZHAaZp <= string("qcOYkNQwCPCAAQaobXKmlJLdLTXxvlTjRtXcReuLlZyDCdiNxZakBPDCDeycpyXJURckNvxlHbEfImRJotpweumjUamoyCbSIkAuyWpfYYLnALUGEGlPoqScRkpbQFEGChvakPesFOlhmGIkYhJGeoTCNlEukXYWUUYWMI")) {
        for (int ZuizHHEAMKLvp = 968954280; ZuizHHEAMKLvp > 0; ZuizHHEAMKLvp--) {
            continue;
        }
    }

    if (BtrNGrR == true) {
        for (int AohluCImchc = 1804451138; AohluCImchc > 0; AohluCImchc--) {
            vKPFhsmFMeAOB = WBHAXXXD;
            khhChw += khhChw;
        }
    }

    for (int OiXYclKWi = 360425727; OiXYclKWi > 0; OiXYclKWi--) {
        WBHAXXXD += ghAAOHZHAaZp;
        qgmgjGpaBjEhzYW = BtrNGrR;
    }

    return 37698.99750188013;
}

bool DwFLANflmrVoA::SAXsj(bool nwyuF, int TnKMppoowwIcYLn, int CNcbOtHEabr, double TchgFrlRlKKMOMC, int wYQRWNgCtWt)
{
    string sJVOlrRaYxmvhv = string("IouRigthiUTVpFeYCLZujIRoDmiRjEskjjjaGmGiYDwzdJExbsxhUygQqRPEhmQsSrcAIaiFPViegeLSClpBkPAwcGhXhuJzlVznjdArTBUFaoAziULLqsBaevUgccmDlHjHYBFhAjcpINqnqNDcOMAmdeNZfmzOhUJl");
    double gioSTJqBx = -279263.4161363271;
    bool KVwOrllQbbqkbIz = true;

    for (int wStbZpiPyrheYGPV = 5341849; wStbZpiPyrheYGPV > 0; wStbZpiPyrheYGPV--) {
        nwyuF = KVwOrllQbbqkbIz;
        wYQRWNgCtWt = wYQRWNgCtWt;
    }

    for (int ttQWQiDQHrGULAq = 1373841923; ttQWQiDQHrGULAq > 0; ttQWQiDQHrGULAq--) {
        wYQRWNgCtWt = TnKMppoowwIcYLn;
    }

    for (int JcUeHfcfqax = 1826498026; JcUeHfcfqax > 0; JcUeHfcfqax--) {
        wYQRWNgCtWt += wYQRWNgCtWt;
        TnKMppoowwIcYLn = CNcbOtHEabr;
    }

    for (int sMpQVHWERvDln = 677005779; sMpQVHWERvDln > 0; sMpQVHWERvDln--) {
        continue;
    }

    return KVwOrllQbbqkbIz;
}

DwFLANflmrVoA::DwFLANflmrVoA()
{
    this->HEZqPNyhBShJVVMk(830134.2989241849, 1197049164);
    this->YRzjrCImwfqghvF(-1628626202, true, 1497918811, string("wctKgNZSMlzsqpBzHtNuWIPhQeGevWdbYjfOKTzFrBAIJBVlUHKTTzVxzZzRbeLaSUxFWnNmlwNpCNGCFqWjadVOraRQYqLaxTNipaYRxbeDhDUlBnJwCCsLImBeAYJJSHFxDhBagZCClLUkPZsGJSYyfivGidZTbJIZncQzmfyxqOyzToEhDgSHtn"));
    this->niRhVNVIsQKza(-256917.12254427382, 327674832, -199281400, 1530055577);
    this->EbdVUOZwumz(string("wnGvSYfjAUUwpCkQIxCaQRhNJvVniFzdzXdeBEUOofnVJCfpcJzwA"));
    this->VnewHKwIg(391840.83804696985, false, false, -422707.9643848964, string("zCjylEYaJgayqFvdNqbQRtsXMFyCErtQSFlQcBIudrpBpWGXScUvaBESDdffqwjLCCYQyrYLCCjIoFNRqoQhIdVapajbzNSZLfJRTYcCdiZXhAvTBWpKrizUNaxelevreoAWPRRZPMoN"));
    this->hffEZ(-261016.81539115595, 449418141, false, string("emNmKiTWiVFB"));
    this->GOiwZqwJ(-778639676);
    this->PWqbTSbhyMg(string("qcOYkNQwCPCAAQaobXKmlJLdLTXxvlTjRtXcReuLlZyDCdiNxZakBPDCDeycpyXJURckNvxlHbEfImRJotpweumjUamoyCbSIkAuyWpfYYLnALUGEGlPoqScRkpbQFEGChvakPesFOlhmGIkYhJGeoTCNlEukXYWUUYWMI"));
    this->SAXsj(false, -163655500, -707317133, 981789.3176943085, -1819111309);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class exOqSFDBSyM
{
public:
    int QTALGcXdvP;
    double zdekjp;

    exOqSFDBSyM();
    string HMRHET(int YYMLaIGyVwhZU, double WzPJXYrgHNoanar);
    string pWcSSwUi(double gAMAWXqHky, double QcotkBqCRbO, bool fuGpxhXNOWnUG, bool RuZWxhZIf);
    int jbVLTtpxy(bool DQLMn);
    void qpivPGI(double gtfPbLYVNDOPOMAX);
    void OMJCzOgTRCWexw(bool weikKDs);
    double ApVaBYuLIsdY(double nqJfpSVAbwYkFHY, int oehzWpaSwj, double AlAhqEhbeNGiDPh);
    int SlbFVxVQ(bool ZJvsIiOzeK, double mXRmzYMhKl);
    string BXxYGsqP(bool GrhdgVNN);
protected:
    int zAgjyZYMBrh;

    int NKcmNK(string aHiMpkduC, string vYvrtRPiHBW, bool QYcQbrXiICKxZ);
    int SyyTfFwLrxB(bool rLLTQgxUDk, string nSUXlaFgUoRc, double fCkJAGuvSnAt, int zvwSMrWutuWn);
    bool VSvGsFKCoVKtm(int pJKSnYTfatCS, int quSBT);
    int iACBxedYZybPblV(double YjiFRHKIOYe, string yjiAiunLdGNMTrx, int YdLfQANHy);
    int wqiXxFyVoUfuKbn(bool PAFdmBvIg, string ZHurqSyYvw, string eFhTgwfHqH, bool pWCCSfOC, string mzDbIGkEbKkKdjq);
    double tJfcIFaG(double QZctJ);
    double VdptUPNad(double DJOGIyGgFKxBPTK, double yShTWYxKdqopAyA, double bqUaerwcphZHZ);
private:
    string HTRMcPORJAUVGR;
    bool kRRUbIoojzhrXn;
    int uWISmpk;
    double ujAaKhDrwBXAWzR;
    bool vigIXvbxBAsTm;
    string BiGWXbFZfGBSwH;

};

string exOqSFDBSyM::HMRHET(int YYMLaIGyVwhZU, double WzPJXYrgHNoanar)
{
    int CmdBIQ = 958579689;
    bool gfSvFCeDxlLkJd = false;
    int kUHVKjH = 2028830488;
    double UHZgmhmUDdKtYAzI = 657830.335471521;
    string fGwUyPhbReqg = string("sFWqpdorveHzYFbyiroVqrQWfhqSwtjOEYJaOprbxAACGNaNHZaHeWvSDVPFMObRqVAxvMnuBSDlYAVXxOWeNyxJhNakjLUeNPzqrFisJdJITRMivZtpsHXUIDsrSpyYcUBwPjpKzrvjljfRGszdlRtBHPARWXkaqoDCiCHMsUdGcdVeGViQbOHGTsHKsDLOYhjcZxiPXkStrQGnuBHgkprDjoXJtyqzSmFdoXpPFfRIYmN");
    string ZsnldaNCJuayTxk = string("UHPjDMvcTBidITCelxibIFtSjijrNWZNgfCcrgqQOQXaGbiAVqazVHrhoCKgvRbagpwRHoMZzwHyqSKEeOaUNlwhMJGWFfGIk");
    string hFbHzWZWBiQeVI = string("ApbCnOHQJveMVFaFvLMYPcDnNTkSMqqqwstkepjEqpljWirKAeQhPmDpdHCBAzJODzABXnCgSInhMumsrKhyNrFQOnNYwwqHFvCeJEcyJjvdCIEViVMjNDciUDhkJzQjqlYWUjRiOXDrHqKthwVXvBcWlfYvMxOjWaCgPKqQMsT");
    bool sPvkiQ = true;

    for (int fVdyhViJGt = 2127888330; fVdyhViJGt > 0; fVdyhViJGt--) {
        gfSvFCeDxlLkJd = ! sPvkiQ;
        hFbHzWZWBiQeVI += ZsnldaNCJuayTxk;
    }

    for (int gAdRXB = 2077410636; gAdRXB > 0; gAdRXB--) {
        CmdBIQ *= kUHVKjH;
        hFbHzWZWBiQeVI += fGwUyPhbReqg;
        YYMLaIGyVwhZU += CmdBIQ;
        kUHVKjH += YYMLaIGyVwhZU;
        gfSvFCeDxlLkJd = gfSvFCeDxlLkJd;
    }

    if (YYMLaIGyVwhZU != 958579689) {
        for (int tcwbYWyGEdkaYVCV = 1593997012; tcwbYWyGEdkaYVCV > 0; tcwbYWyGEdkaYVCV--) {
            continue;
        }
    }

    if (ZsnldaNCJuayTxk >= string("ApbCnOHQJveMVFaFvLMYPcDnNTkSMqqqwstkepjEqpljWirKAeQhPmDpdHCBAzJODzABXnCgSInhMumsrKhyNrFQOnNYwwqHFvCeJEcyJjvdCIEViVMjNDciUDhkJzQjqlYWUjRiOXDrHqKthwVXvBcWlfYvMxOjWaCgPKqQMsT")) {
        for (int xqhlqWGXgGIps = 281635956; xqhlqWGXgGIps > 0; xqhlqWGXgGIps--) {
            continue;
        }
    }

    for (int KcHxx = 1545869108; KcHxx > 0; KcHxx--) {
        fGwUyPhbReqg = hFbHzWZWBiQeVI;
        WzPJXYrgHNoanar += UHZgmhmUDdKtYAzI;
    }

    return hFbHzWZWBiQeVI;
}

string exOqSFDBSyM::pWcSSwUi(double gAMAWXqHky, double QcotkBqCRbO, bool fuGpxhXNOWnUG, bool RuZWxhZIf)
{
    double ypJLRyfQzmqihKx = 1030891.7343473368;
    int WUlKrH = 1603002417;
    string bAYiYBlsbeF = string("xqdmyvgnHmlvRwQMTttSVHTMitJzdeHXKtXxEARpfjVVwduxAVjyJdalmTRZQulutKKtjfcolDfVWBSqBGmoljrEMTYySsEpygKRSHgRVoVcmwmugOTgyFTriuNoCeDOWvJmicgTLIF");
    int oOPeJnrQbD = -716676166;
    bool atTNEaxiv = false;
    bool xyepwnQxtCvjPNT = true;
    int wzLCCVr = -1956405776;
    int eUpxzELxCbYKoF = -1576494228;

    if (xyepwnQxtCvjPNT != false) {
        for (int KdexlEF = 1079709590; KdexlEF > 0; KdexlEF--) {
            continue;
        }
    }

    return bAYiYBlsbeF;
}

int exOqSFDBSyM::jbVLTtpxy(bool DQLMn)
{
    string vFeIjWAwceXS = string("kFlNaQJSYBhrnfwCqMQWdmyXBeJCphzmKWsvWFfJCuiRSjqHjOUiTMwhXVfLkTKWCibTvOyzrcKDDPPvcKqSQbHMnagjuczCsTIKamXPlxOXvvfkSxhHJytPMnIbdeqlvhXfCWSONcWiMWwRnLvToP");
    double vvXiBySQBcOJfk = -536378.9057538222;
    bool AOGZTx = true;
    string DeZFDRRN = string("YNRCdtASTnkbUyOJzqeJnOABLuBYFXJRSXPMBjGSlPHyDyjLF");
    int RcdUXigkMdATWTE = 1513297953;
    double EMZlgmlOs = -708888.2434303057;
    bool PiyMeQdz = false;
    double elWjdmIrb = -917864.3161355617;

    for (int RUASR = 1459790499; RUASR > 0; RUASR--) {
        DQLMn = PiyMeQdz;
    }

    if (elWjdmIrb > -708888.2434303057) {
        for (int PdPTVwuzmB = 1837623994; PdPTVwuzmB > 0; PdPTVwuzmB--) {
            EMZlgmlOs /= vvXiBySQBcOJfk;
            RcdUXigkMdATWTE -= RcdUXigkMdATWTE;
            vFeIjWAwceXS += vFeIjWAwceXS;
        }
    }

    for (int GGcmJdACAmCtWCzE = 983098217; GGcmJdACAmCtWCzE > 0; GGcmJdACAmCtWCzE--) {
        continue;
    }

    return RcdUXigkMdATWTE;
}

void exOqSFDBSyM::qpivPGI(double gtfPbLYVNDOPOMAX)
{
    string OybvkwUFJrVg = string("gOBbBVxMBbdUFdtbJnNoKVzUFdpgMUZPpWWMEZLxkVXQQMYlgp");
    int WufYMhviwOGDSJAA = -2144165739;
    bool kEPdn = true;
    double kDlWrFgPB = 579058.3612263728;
    bool PvVWwyX = false;
    int xcfjqrxonKBPk = 1506526259;
    bool fXEpvR = false;
    bool cQIojmlGgzREA = true;
    double uIKphBYmudOaps = 918514.9796224299;

    for (int LjqpwgINwGKdDlX = 1138323710; LjqpwgINwGKdDlX > 0; LjqpwgINwGKdDlX--) {
        uIKphBYmudOaps = kDlWrFgPB;
        uIKphBYmudOaps += gtfPbLYVNDOPOMAX;
    }

    if (uIKphBYmudOaps >= 709134.5196834982) {
        for (int KsykVZKDsFiUlF = 315523677; KsykVZKDsFiUlF > 0; KsykVZKDsFiUlF--) {
            gtfPbLYVNDOPOMAX *= uIKphBYmudOaps;
        }
    }

    for (int XlkdWCqKrDOPKTu = 1085501369; XlkdWCqKrDOPKTu > 0; XlkdWCqKrDOPKTu--) {
        PvVWwyX = PvVWwyX;
        fXEpvR = ! kEPdn;
        kEPdn = ! fXEpvR;
        cQIojmlGgzREA = PvVWwyX;
    }
}

void exOqSFDBSyM::OMJCzOgTRCWexw(bool weikKDs)
{
    int dbOiVckzBZAkOL = -433128607;
    string YmObHqWE = string("BeDbHVeyWUFoXeATWJQXCuNIztQJQAQGGCQmIbUvhHYbxwNRdEXLHDITtIMaUCKnNNKRubmXwTNyPtSHxqDUwxrsLyrNBfqnMDswyoSHATsEUeCeEVbTzERsN");
    string MRlyQq = string("ItstgCeANDkKFzbqffkRdBuOQJesTwjXtuipxnZdCrVaepLXatWDtYLEMewqhFFCXLuHDrsFYXtOgUJlNkViwLLdhXMdNNoiornnqwESStihrstsmGtWppEWLyMLJHxczgrCHJFIKWttFpSLRDwYTDtsfbDOpDHvnoVJOPTdVwdqwvvGpurwnSAFAHBAH");
    bool uGMgegFvE = true;
    string MqNDZTPrPYesQKbZ = string("bLZONwdPmS");
    bool kSczWdlCDREu = false;
    int wOhQQjmqySrMNr = 1867598051;
    int BpcaJA = 1001961493;
    string xMjyIKJzALgjU = string("YlzHWJhAEWXFBCqRJvjPsKTgrySPNvSSYSXVnZUGpOSvqHGPpycYteAYZXDBawkoFaLqXpksauXLkRgCpoIEsTKWUTvxAvaJQImyIxVqPOaitgPmhtbfCeUBPuPbYFuGMXqfTNmZlV");
    bool AxNQeJjkxU = true;

    if (AxNQeJjkxU == false) {
        for (int HPrMFWYnNePh = 340437241; HPrMFWYnNePh > 0; HPrMFWYnNePh--) {
            YmObHqWE = xMjyIKJzALgjU;
        }
    }

    for (int QGppbQaDfgMoFkiz = 294883696; QGppbQaDfgMoFkiz > 0; QGppbQaDfgMoFkiz--) {
        AxNQeJjkxU = ! uGMgegFvE;
    }

    if (kSczWdlCDREu != false) {
        for (int uzgLCgDuAIBH = 1250055781; uzgLCgDuAIBH > 0; uzgLCgDuAIBH--) {
            continue;
        }
    }

    for (int ggCqeShhTkCm = 236636337; ggCqeShhTkCm > 0; ggCqeShhTkCm--) {
        wOhQQjmqySrMNr -= dbOiVckzBZAkOL;
    }

    if (MRlyQq != string("ItstgCeANDkKFzbqffkRdBuOQJesTwjXtuipxnZdCrVaepLXatWDtYLEMewqhFFCXLuHDrsFYXtOgUJlNkViwLLdhXMdNNoiornnqwESStihrstsmGtWppEWLyMLJHxczgrCHJFIKWttFpSLRDwYTDtsfbDOpDHvnoVJOPTdVwdqwvvGpurwnSAFAHBAH")) {
        for (int pXtxt = 616742471; pXtxt > 0; pXtxt--) {
            MRlyQq = xMjyIKJzALgjU;
        }
    }

    for (int ZoKLCDxFLn = 138725458; ZoKLCDxFLn > 0; ZoKLCDxFLn--) {
        YmObHqWE = MRlyQq;
        MqNDZTPrPYesQKbZ = MRlyQq;
    }
}

double exOqSFDBSyM::ApVaBYuLIsdY(double nqJfpSVAbwYkFHY, int oehzWpaSwj, double AlAhqEhbeNGiDPh)
{
    double LwCpoiAh = -592745.5758500056;
    string jjmZNpVdBK = string("gjduIZrrNDXlvJWhaxZUMEweNzjDVYnjmf");
    string lPdzPOkJLH = string("hGFLvytlbwUAxocFTcIXQxHVzeCMHQNdpImjJTnKvtkEvlgAAyAfNyZroUtcCnOVtIuguFGqTSFjhmfNssXmfTcJTQdTOWctmqQVNUGPHZpxhcDpSI");
    double wVPaXqpe = -908070.9758804495;
    string lhjWfFQTHoNZxTCf = string("XoRGMNtBdvJslsabkiTNMeDggqAemtRerhBCCPXGSoCynyqASZgiytARRbLiPgNKDVzJumlFcsKZJsltcSbguAvFbqPfSLQHEJWPQhuaVNtXEcAqpUjSOaAzfFPSAbcSPszzLVCNQJgaMHusGrQZyJqLXbEMjwNUipKITWqErzgQGPbcplfmjVixJOvbpoAQSZOefHwNwgXkNBFLeBCwyYZeneouRuuDJakVNXvbAZwvJbyRRbCZ");
    bool tkAKPqb = true;
    double BSrJgsoJt = 128097.69689597578;
    double mEjGgeIiVFOFhk = 283056.60738088604;
    int nHCfoUjOnebZNje = 99951068;

    for (int nYjDrvshscEWJGR = 607982570; nYjDrvshscEWJGR > 0; nYjDrvshscEWJGR--) {
        mEjGgeIiVFOFhk /= wVPaXqpe;
    }

    return mEjGgeIiVFOFhk;
}

int exOqSFDBSyM::SlbFVxVQ(bool ZJvsIiOzeK, double mXRmzYMhKl)
{
    double flISP = -490223.4176593716;
    bool FPcdaIRyT = false;
    bool fbULO = false;
    string YkwEBeOm = string("BDWcxzYPRBIWVWuaIfZAjjmPpXmtfMxTAhBrRSrbOivtviUuDAYgwIRjervXPQfrkHDToYBjmmL");
    double TKEQLvaUIIp = 803257.6663763894;

    for (int YnntRxHWUJV = 714023106; YnntRxHWUJV > 0; YnntRxHWUJV--) {
        fbULO = FPcdaIRyT;
        flISP -= TKEQLvaUIIp;
        FPcdaIRyT = fbULO;
        ZJvsIiOzeK = ZJvsIiOzeK;
    }

    for (int FUFkJummquhIJ = 1270106557; FUFkJummquhIJ > 0; FUFkJummquhIJ--) {
        mXRmzYMhKl -= mXRmzYMhKl;
        flISP -= flISP;
    }

    for (int weSqHQvTVkph = 1208868263; weSqHQvTVkph > 0; weSqHQvTVkph--) {
        mXRmzYMhKl += mXRmzYMhKl;
        flISP = TKEQLvaUIIp;
    }

    return 1691947989;
}

string exOqSFDBSyM::BXxYGsqP(bool GrhdgVNN)
{
    int AGmdGkAGfQVoBf = -521381498;
    string JmzTCSsklkYSsoR = string("euDILXpcKtJjvPMusqYidfrycMaohehZbmUQcQKxjpZOTktFkEaqilidIULfkSrNynLCoNJmAxviqIOyzuXzAIPhNQhPwrtqurRlRFzLqgaMNsUWQ");

    if (GrhdgVNN == true) {
        for (int tTaKLiomPHhRp = 895361490; tTaKLiomPHhRp > 0; tTaKLiomPHhRp--) {
            JmzTCSsklkYSsoR = JmzTCSsklkYSsoR;
        }
    }

    if (JmzTCSsklkYSsoR > string("euDILXpcKtJjvPMusqYidfrycMaohehZbmUQcQKxjpZOTktFkEaqilidIULfkSrNynLCoNJmAxviqIOyzuXzAIPhNQhPwrtqurRlRFzLqgaMNsUWQ")) {
        for (int CnbfKtZyFzjGVZDZ = 607372030; CnbfKtZyFzjGVZDZ > 0; CnbfKtZyFzjGVZDZ--) {
            continue;
        }
    }

    return JmzTCSsklkYSsoR;
}

int exOqSFDBSyM::NKcmNK(string aHiMpkduC, string vYvrtRPiHBW, bool QYcQbrXiICKxZ)
{
    double RQpaYFvgFd = 730720.8158560235;
    bool TasmmsRXK = true;
    double vRqNH = 587213.7278299258;
    string LwxCAn = string("lDhwcCuAvUBFGqodCvlsxkOTaHAGxhbErHncDUBFCYFcHOALuOybqoGCRtRdgJHvghexDbeLESizPRaflXamcsdxglLMDqWPQPPHpxPRBFXhjBPxbUXOXXmECmlmMYqzmkUUhTRsNiiqjCZfvRidNFtXPPchouDYhWSDjTGDizfcPcqRLrTZqtSEWpAUtECVhNLEMqePuQ");
    string ZKLsYysWJGob = string("kecBfuPoKBPcwvxBPrKZJKSLEhNVmVakTdltywNjTduEHDwzygROgaSwKufsffxGcKVFZqHXNEEPIOsPyVrcxZqKUlZUuxgsRAPcKVEuXedcdESpYhiaydFemuQFYjfALnDARTpuCMEPUUOxbgevZXHiIPWVfPMWzDXgZjgKpqMRdfTnPMhvhvlqJvRZwRzhvMZcBDLnMIOIrIRnTi");

    for (int SXrxVRCSNUJgUdA = 1024458620; SXrxVRCSNUJgUdA > 0; SXrxVRCSNUJgUdA--) {
        continue;
    }

    if (RQpaYFvgFd == 587213.7278299258) {
        for (int mGKtTHIX = 2064178458; mGKtTHIX > 0; mGKtTHIX--) {
            aHiMpkduC += LwxCAn;
        }
    }

    if (LwxCAn > string("lDhwcCuAvUBFGqodCvlsxkOTaHAGxhbErHncDUBFCYFcHOALuOybqoGCRtRdgJHvghexDbeLESizPRaflXamcsdxglLMDqWPQPPHpxPRBFXhjBPxbUXOXXmECmlmMYqzmkUUhTRsNiiqjCZfvRidNFtXPPchouDYhWSDjTGDizfcPcqRLrTZqtSEWpAUtECVhNLEMqePuQ")) {
        for (int TpAWZB = 952624978; TpAWZB > 0; TpAWZB--) {
            QYcQbrXiICKxZ = TasmmsRXK;
            vYvrtRPiHBW += ZKLsYysWJGob;
            aHiMpkduC += ZKLsYysWJGob;
            vYvrtRPiHBW = LwxCAn;
            ZKLsYysWJGob = ZKLsYysWJGob;
            RQpaYFvgFd *= vRqNH;
        }
    }

    for (int KNGBKEJbGD = 989120958; KNGBKEJbGD > 0; KNGBKEJbGD--) {
        aHiMpkduC = ZKLsYysWJGob;
        LwxCAn = LwxCAn;
    }

    return -803290742;
}

int exOqSFDBSyM::SyyTfFwLrxB(bool rLLTQgxUDk, string nSUXlaFgUoRc, double fCkJAGuvSnAt, int zvwSMrWutuWn)
{
    int cQTQIvfqNeIu = 1983757108;
    int kgTTYHC = 2069893051;

    for (int LQxDiuKSxJKWI = 564028156; LQxDiuKSxJKWI > 0; LQxDiuKSxJKWI--) {
        continue;
    }

    for (int UjeGNoVe = 2067512748; UjeGNoVe > 0; UjeGNoVe--) {
        cQTQIvfqNeIu += kgTTYHC;
        kgTTYHC -= zvwSMrWutuWn;
    }

    return kgTTYHC;
}

bool exOqSFDBSyM::VSvGsFKCoVKtm(int pJKSnYTfatCS, int quSBT)
{
    bool xlMooqItdKWT = false;
    double cQdqshMrELMkaYny = 614621.1023410093;
    int VPusqningINnW = -1408786288;
    int CsvHaMHHRpFvSUv = 1192005028;
    double FjXrdOtlkPbWT = 591098.0805867573;
    string EIqUyp = string("SsrzgOcvKlXDSPvxMZuDrUdCQvaCihIlMWNtUIajPcxVVbuYtixUxHeksMkpdiiablwbERYPZjViIJvreukuEBzPGfCJbxFzeffIhyIEXiDOdUryFJ");
    string siIzpKXEAch = string("rpCQOPujMTpfkTuqsEeepEwLFSJiTffyHvfUMcIeAatLglkwavSojInxreWIpgxjejgUjHCZsLsjxwvgFBmdmzXFjNlacyNsFgGleizQFADHAWoyUDWFQPIuToxyEMFe");
    string XQEiLbLKrCcDO = string("nbnVhszVTRlBrwjryBwiyPZPibodkALMsUfGZTzAbVXHGetegOmdXhkggGuYDvynTKMxwmDoxtsZqU");
    int dipUfROu = 2136832569;
    int GlWumqVZatGZy = -436312733;

    for (int kSNNfFiuzGvhs = 1062715758; kSNNfFiuzGvhs > 0; kSNNfFiuzGvhs--) {
        GlWumqVZatGZy /= pJKSnYTfatCS;
        pJKSnYTfatCS = quSBT;
    }

    for (int bEqEF = 572090090; bEqEF > 0; bEqEF--) {
        VPusqningINnW += dipUfROu;
    }

    for (int YADJbiTKoFuI = 1933431389; YADJbiTKoFuI > 0; YADJbiTKoFuI--) {
        pJKSnYTfatCS *= dipUfROu;
        pJKSnYTfatCS = quSBT;
        XQEiLbLKrCcDO = siIzpKXEAch;
        quSBT += VPusqningINnW;
        VPusqningINnW *= quSBT;
    }

    for (int mJOKSWxfmHVJMdX = 204643106; mJOKSWxfmHVJMdX > 0; mJOKSWxfmHVJMdX--) {
        quSBT *= quSBT;
        siIzpKXEAch += siIzpKXEAch;
    }

    if (VPusqningINnW < 1192005028) {
        for (int joYudp = 1419138970; joYudp > 0; joYudp--) {
            VPusqningINnW *= dipUfROu;
            cQdqshMrELMkaYny += FjXrdOtlkPbWT;
        }
    }

    return xlMooqItdKWT;
}

int exOqSFDBSyM::iACBxedYZybPblV(double YjiFRHKIOYe, string yjiAiunLdGNMTrx, int YdLfQANHy)
{
    double gytIqkwCxm = 1035067.2443724693;
    bool ihFJNeQbB = false;
    double GDhaeYMktox = 467823.6065948264;
    double MKWSkDyuobeO = 644886.9985313761;
    double QIEYVUh = -937028.1371697882;
    double bZzMeFpFFqnjvX = -65900.11719773487;
    string UuPgj = string("mTgNDkqktcwVrxxeBLxfaPCOzHAWeashhlpGWIogPemRlugwfpyboPBNxdT");

    for (int zEwVSAIhWQt = 311184120; zEwVSAIhWQt > 0; zEwVSAIhWQt--) {
        YdLfQANHy -= YdLfQANHy;
        MKWSkDyuobeO += GDhaeYMktox;
        GDhaeYMktox /= YjiFRHKIOYe;
        YjiFRHKIOYe = MKWSkDyuobeO;
    }

    for (int tzaJgdN = 2085337367; tzaJgdN > 0; tzaJgdN--) {
        yjiAiunLdGNMTrx += yjiAiunLdGNMTrx;
        QIEYVUh /= MKWSkDyuobeO;
        UuPgj = yjiAiunLdGNMTrx;
        MKWSkDyuobeO += QIEYVUh;
    }

    for (int OFtbK = 520832465; OFtbK > 0; OFtbK--) {
        gytIqkwCxm += gytIqkwCxm;
        gytIqkwCxm /= bZzMeFpFFqnjvX;
    }

    if (GDhaeYMktox >= -65900.11719773487) {
        for (int FBbGO = 1878094709; FBbGO > 0; FBbGO--) {
            YjiFRHKIOYe = YjiFRHKIOYe;
            bZzMeFpFFqnjvX = QIEYVUh;
            QIEYVUh *= GDhaeYMktox;
        }
    }

    return YdLfQANHy;
}

int exOqSFDBSyM::wqiXxFyVoUfuKbn(bool PAFdmBvIg, string ZHurqSyYvw, string eFhTgwfHqH, bool pWCCSfOC, string mzDbIGkEbKkKdjq)
{
    double xxJnvvLJJu = 187782.53828296272;
    bool MxgqArSILTwR = true;

    if (pWCCSfOC == true) {
        for (int UnAAalcSnibYlR = 751842440; UnAAalcSnibYlR > 0; UnAAalcSnibYlR--) {
            continue;
        }
    }

    for (int hrHNyhV = 138378368; hrHNyhV > 0; hrHNyhV--) {
        PAFdmBvIg = ! pWCCSfOC;
        MxgqArSILTwR = pWCCSfOC;
        mzDbIGkEbKkKdjq += ZHurqSyYvw;
        mzDbIGkEbKkKdjq += ZHurqSyYvw;
    }

    return 1276255514;
}

double exOqSFDBSyM::tJfcIFaG(double QZctJ)
{
    double qwlpIgBhHBoB = 714744.0850273947;
    int XdFVIJTya = 1269763394;
    int pCeWHc = 1658898337;
    double gBaCbxUSNi = -1033017.6055560152;

    for (int bYASn = 788914920; bYASn > 0; bYASn--) {
        gBaCbxUSNi -= QZctJ;
        qwlpIgBhHBoB = QZctJ;
        gBaCbxUSNi *= gBaCbxUSNi;
        qwlpIgBhHBoB /= gBaCbxUSNi;
    }

    if (pCeWHc != 1269763394) {
        for (int RgdwiAZZvwvYE = 42950975; RgdwiAZZvwvYE > 0; RgdwiAZZvwvYE--) {
            qwlpIgBhHBoB *= gBaCbxUSNi;
            gBaCbxUSNi -= gBaCbxUSNi;
            gBaCbxUSNi -= gBaCbxUSNi;
            qwlpIgBhHBoB -= gBaCbxUSNi;
            QZctJ -= qwlpIgBhHBoB;
            QZctJ += gBaCbxUSNi;
        }
    }

    return gBaCbxUSNi;
}

double exOqSFDBSyM::VdptUPNad(double DJOGIyGgFKxBPTK, double yShTWYxKdqopAyA, double bqUaerwcphZHZ)
{
    string DHPcpJeIDA = string("ngOFIgQquVSNVYOlhhGcdOtGtNCbZcNPeofkKCluyMPwakWRlGQISDMqwgDetcqxrikoHktPoArMIEHdhJUmmhbQKBxWmWWAWPndDGoHzRMTCHdoIykxFsvmPwMhIEXHsBouslzFjgKucQxLhRJXFmIqGBxKfdDDdYpJFRWqeReZBNlUEO");
    bool LtxXeKmHHo = false;
    double mtUnbadr = -455305.90388102515;
    int SMsej = -1730253695;

    if (yShTWYxKdqopAyA == -273333.997182819) {
        for (int rzWTAZGY = 1421928411; rzWTAZGY > 0; rzWTAZGY--) {
            mtUnbadr *= yShTWYxKdqopAyA;
            yShTWYxKdqopAyA *= bqUaerwcphZHZ;
            SMsej *= SMsej;
            yShTWYxKdqopAyA /= DJOGIyGgFKxBPTK;
            SMsej /= SMsej;
            mtUnbadr /= DJOGIyGgFKxBPTK;
            yShTWYxKdqopAyA = DJOGIyGgFKxBPTK;
        }
    }

    if (DJOGIyGgFKxBPTK <= -273333.997182819) {
        for (int PqnttLwzKGjz = 1471766824; PqnttLwzKGjz > 0; PqnttLwzKGjz--) {
            yShTWYxKdqopAyA = mtUnbadr;
        }
    }

    for (int Qykxbm = 1657376869; Qykxbm > 0; Qykxbm--) {
        bqUaerwcphZHZ = bqUaerwcphZHZ;
        DJOGIyGgFKxBPTK += DJOGIyGgFKxBPTK;
        yShTWYxKdqopAyA -= yShTWYxKdqopAyA;
        bqUaerwcphZHZ -= mtUnbadr;
    }

    for (int HlVxkmOZS = 642863651; HlVxkmOZS > 0; HlVxkmOZS--) {
        bqUaerwcphZHZ = bqUaerwcphZHZ;
        mtUnbadr += yShTWYxKdqopAyA;
    }

    for (int mxhxjeLJRAaNfYw = 1159721810; mxhxjeLJRAaNfYw > 0; mxhxjeLJRAaNfYw--) {
        continue;
    }

    return mtUnbadr;
}

exOqSFDBSyM::exOqSFDBSyM()
{
    this->HMRHET(2043216911, 108151.10053163477);
    this->pWcSSwUi(-823471.0948227751, 803435.6314305268, false, false);
    this->jbVLTtpxy(true);
    this->qpivPGI(709134.5196834982);
    this->OMJCzOgTRCWexw(true);
    this->ApVaBYuLIsdY(445080.64230652835, 122632622, -68532.00102388115);
    this->SlbFVxVQ(true, 1011002.6519168675);
    this->BXxYGsqP(true);
    this->NKcmNK(string("qRWfDeDHfhsUoMQeakJcaIjD"), string("BIzieQoKwAizeqFmeBinTxjHEqTDLjOuLNTTchIxhbQ"), true);
    this->SyyTfFwLrxB(false, string("eGfPkdUMlwhbkQYwrcjdElNjPmnrVmzKBtxlHfxVqkbrZBgMOmVKTmhBHLsFntmJYjtPMrCmLPzwdagqvebSJZhLc"), 706631.4584285098, 812721885);
    this->VSvGsFKCoVKtm(-1289597456, -548608454);
    this->iACBxedYZybPblV(-314309.85131639254, string("HMOTrmtEJJnyCRDMipREwIBPguhLiYRgrHoTPbFjPUQCrWwRkYIrQOSKmfRONHYOVnyAnliPqthEmEWCKsbxzSfquSRbbLeaLFJCIOahuHFAwQyKQOqrqVpxUAOjgFmTYsKwDDCaWbVgElVIBzYkkzWArStPnLBQNZjqIFAuIHWbUvaGTQfzSHmVChIRY"), 91200127);
    this->wqiXxFyVoUfuKbn(false, string("iGxvXeIVVNCYZSewZUuyUjrXJxSTOejwkLyBHbQtNWFBFctIczUOxEujgmkXz"), string("LhMLEBEzngwibJCPvNVlgMNDrGYZPRrSYuStKuEcIfBDkfKcBjdBRDmilpBGEvkeGyiJRHfkJWEcVpvrTcZOaePYphhVknYwAgALZjzATUarzjAPhEuAzSWhQlBJIdTIXTgMTszTQfLSvcIoelFnPmrfTgXImwcQLwqKJShHZISeACWqerdZaAPYNsnokLymUVnJAppGWatesSMtdDvqtmUvyfdqtVxtboPeujlzakAIysUzlal"), false, string("DkXKACGXoQujkhkAXAkjSTZVgtEqfnLZLjVaSuYPQtylibCmdnWeYqLRToHlchJKpETtuoqGVzhWadkGxBLJOtDtrRChfMlPdXirTDAOmmnGxgndHFqAsSqCAzHQIFCHCidUxuAPqEMREPvPvQYHuGAQInOnwZdBMVazxpYbTCvFebzutwUwOxHlMDCPRUILtkNHDUOGkOrhRauyNQEGExOrHmHRXUPkFpYIADnapXsZOEC"));
    this->tJfcIFaG(64954.21984558331);
    this->VdptUPNad(1018748.343218392, 864338.5088239477, -273333.997182819);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nFzQUnBLRm
{
public:
    double ziMUYbkdtDx;
    string AKnxhTvkc;
    double tmsjh;
    int aslSKfGwjdVdey;
    int CteupFvmrxVOZ;

    nFzQUnBLRm();
    string euiWEV(string cJPal, bool gDnzmJRDaTkhd, string rJSnJYpni, int mGHWcSQidXvdJBb);
    void stQKbGG(bool CvHKhgFKogtBq, double SNmNaOvsTBms);
protected:
    double ZbqrCSVH;
    double iMoYb;

    int BJrPIamGSxXTIb(int eTlECS, bool niNbde, double jlLbIdCSUfy, int DmMbINnWf, bool mBftKKznXIANHb);
    void admHDFeKABQtkp();
    bool sypmfbRR(int KImCmL, string czDnTbzkOa, bool jvdRjKMCq, string WyTphPKdJxUOTp, bool qTVHwhAhr);
private:
    bool CyJlbUvuHSyO;
    string HfsZPqsBbiixTnd;
    int kRVJw;
    bool wxFvbXvogDRmeaHP;
    double QQnMfzNHd;

    void rqkVxOesjtDx(int YYfoudZhS, double DWUyajeDCjlAUza, int fKBOMdnQV, bool jiWVzsKBOKCSWGTM, int EVoiBzqlxLqI);
    double OKVtmn(double fKsVVfAKIFeZ, int qcRzfzveowcUSdOE);
    bool UIySBa(double SBnUWESHGCxDfAN, double ckTBWOgypzBB, string NPgsjZbBQrKAE, double oqDqIXvfhxv);
    double gAyEEOxTuBxj(string krPeBtJKWt);
};

string nFzQUnBLRm::euiWEV(string cJPal, bool gDnzmJRDaTkhd, string rJSnJYpni, int mGHWcSQidXvdJBb)
{
    int aOMPzMBPJcjTmNW = 830554750;
    string TNzxAjKXBpZPW = string("KguJuvaHhWDebXVzPdVxDypVVdhudqmXMcqjLAkfUpznErylVrBbBvGKCilCFiAHkAqOSMWjiUSavXvhusJmIZbedVWiDEMWBKLIzQlsDjRswijqGEcYjkiIaBFhmlQyOpavQbuIwSrifSaocfScDjPyFrsWseLLZSzJNnbmbIJMucvPB");
    int QCMksBJeiVqRR = 964266943;
    bool pSwncJeLARqj = true;
    string UBzxDgLNxMTFrjNU = string("ITMqkjxnEpmiogLgQoBuOCxYqlUzzuiuDOBnbkKfNxBHYQCYGucmbGsBLuCrZcVFLoMaEGgurTAuALCpUHlVQFtnPACrCoSmcSgoHuLtlGwRwmLRdMspHqlbwPUgjTdLoYYsOlpvRxiZcYvLeVoOZMUQhkqsHMAIjhmIMEKuxNHLBgcgCLFTaFp");
    int xOLuA = 2002931927;
    double owdDSiJob = -993824.7915826831;

    if (aOMPzMBPJcjTmNW <= 2002931927) {
        for (int sKmsmsjkPF = 2088379579; sKmsmsjkPF > 0; sKmsmsjkPF--) {
            continue;
        }
    }

    for (int zyVhhHPxvfOvs = 888097725; zyVhhHPxvfOvs > 0; zyVhhHPxvfOvs--) {
        owdDSiJob -= owdDSiJob;
        TNzxAjKXBpZPW += UBzxDgLNxMTFrjNU;
    }

    for (int FRktktm = 1682311947; FRktktm > 0; FRktktm--) {
        TNzxAjKXBpZPW = TNzxAjKXBpZPW;
        aOMPzMBPJcjTmNW -= mGHWcSQidXvdJBb;
    }

    return UBzxDgLNxMTFrjNU;
}

void nFzQUnBLRm::stQKbGG(bool CvHKhgFKogtBq, double SNmNaOvsTBms)
{
    double wyztzHYOi = -480969.53190625535;
    int aMCIgYQqNHzF = 1076482275;
    bool pTwZt = false;
    double CgetByc = -76119.56593526795;
    bool QzqSvtoN = false;
    bool qazOYLcYHTp = true;

    if (SNmNaOvsTBms != 384851.8485996436) {
        for (int cEKzqgUiwPrcPU = 1319952783; cEKzqgUiwPrcPU > 0; cEKzqgUiwPrcPU--) {
            CvHKhgFKogtBq = QzqSvtoN;
            wyztzHYOi /= CgetByc;
        }
    }

    for (int fNDTvLreEhi = 638193375; fNDTvLreEhi > 0; fNDTvLreEhi--) {
        aMCIgYQqNHzF = aMCIgYQqNHzF;
        qazOYLcYHTp = ! qazOYLcYHTp;
    }

    if (SNmNaOvsTBms != -76119.56593526795) {
        for (int svhRoHS = 614780822; svhRoHS > 0; svhRoHS--) {
            qazOYLcYHTp = ! pTwZt;
            QzqSvtoN = ! pTwZt;
            QzqSvtoN = qazOYLcYHTp;
            pTwZt = ! qazOYLcYHTp;
        }
    }

    if (qazOYLcYHTp != true) {
        for (int RJodvPVP = 1459214001; RJodvPVP > 0; RJodvPVP--) {
            CgetByc = wyztzHYOi;
            wyztzHYOi /= SNmNaOvsTBms;
            qazOYLcYHTp = ! qazOYLcYHTp;
        }
    }

    for (int sMGzNphdxRPXjS = 832544374; sMGzNphdxRPXjS > 0; sMGzNphdxRPXjS--) {
        CvHKhgFKogtBq = qazOYLcYHTp;
        CvHKhgFKogtBq = ! pTwZt;
    }
}

int nFzQUnBLRm::BJrPIamGSxXTIb(int eTlECS, bool niNbde, double jlLbIdCSUfy, int DmMbINnWf, bool mBftKKznXIANHb)
{
    bool PQcEx = true;
    double CzLXW = 1012129.2790186374;
    int IDIAyYe = -2017859440;
    double ivMaMYkux = 841141.7042041059;
    int CyTNQDbOgxFyHf = -175335972;
    int yxFeEMfOYHjQVNc = 1183064362;
    int jCFoUvYa = -1040846800;

    for (int HbdjzScshnVzwyvF = 1956593930; HbdjzScshnVzwyvF > 0; HbdjzScshnVzwyvF--) {
        CyTNQDbOgxFyHf += CyTNQDbOgxFyHf;
        niNbde = ! mBftKKznXIANHb;
        jCFoUvYa = eTlECS;
    }

    for (int HIXxNXdStJxG = 210479175; HIXxNXdStJxG > 0; HIXxNXdStJxG--) {
        yxFeEMfOYHjQVNc = yxFeEMfOYHjQVNc;
        jlLbIdCSUfy = jlLbIdCSUfy;
        mBftKKznXIANHb = ! PQcEx;
    }

    for (int tSvwNRBRXj = 991368002; tSvwNRBRXj > 0; tSvwNRBRXj--) {
        CyTNQDbOgxFyHf /= yxFeEMfOYHjQVNc;
    }

    if (CyTNQDbOgxFyHf < -1040846800) {
        for (int BzTDpB = 448070077; BzTDpB > 0; BzTDpB--) {
            continue;
        }
    }

    return jCFoUvYa;
}

void nFzQUnBLRm::admHDFeKABQtkp()
{
    string AJqBIQBVbpQdV = string("DIcVQFliTAsiEjmFvHTXeAaJkItSblfkooMXgcxBcjawrWeWorhOWcuDgXWdYSKYQFvLmYLLCGKltvYsthKTKbMTcihPqBqaQAdyVbGWiSTsDQybSopfrboy");
    double ebavobPNaWhfXK = -147587.55680104162;
    string xguOsE = string("bPUmJAFWmsWFxDErucezVPkENnYnphmUjlkdTbezQYXVnOlORcmSOwSXovrLFfENnUnHxpLGoBJLrsXNdZjBmgdAtqGexTMmnIRpMYydHquWZPBrgaJrFLuPnRqNVUibAuvKZdHpvQDSyoCjYBDdLZWHz");

    for (int aUGQSP = 739500108; aUGQSP > 0; aUGQSP--) {
        xguOsE = AJqBIQBVbpQdV;
        xguOsE = xguOsE;
        AJqBIQBVbpQdV = AJqBIQBVbpQdV;
        ebavobPNaWhfXK += ebavobPNaWhfXK;
        xguOsE = AJqBIQBVbpQdV;
    }
}

bool nFzQUnBLRm::sypmfbRR(int KImCmL, string czDnTbzkOa, bool jvdRjKMCq, string WyTphPKdJxUOTp, bool qTVHwhAhr)
{
    double oUvqrbjElrWc = -809255.6231800934;
    bool LKlYbinCYIlob = false;
    double rLPJRLrHIWRLsCR = -216813.7630342606;
    int IdHJMiII = -845835625;

    for (int REVLAeRRNQrDNv = 1917593848; REVLAeRRNQrDNv > 0; REVLAeRRNQrDNv--) {
        jvdRjKMCq = ! jvdRjKMCq;
        LKlYbinCYIlob = ! qTVHwhAhr;
    }

    for (int EozHYb = 1480578979; EozHYb > 0; EozHYb--) {
        continue;
    }

    if (IdHJMiII < -845835625) {
        for (int CKHJHEtOIDhSg = 1027365319; CKHJHEtOIDhSg > 0; CKHJHEtOIDhSg--) {
            continue;
        }
    }

    for (int MUUiBPROlY = 536318929; MUUiBPROlY > 0; MUUiBPROlY--) {
        czDnTbzkOa = WyTphPKdJxUOTp;
        IdHJMiII *= KImCmL;
    }

    return LKlYbinCYIlob;
}

void nFzQUnBLRm::rqkVxOesjtDx(int YYfoudZhS, double DWUyajeDCjlAUza, int fKBOMdnQV, bool jiWVzsKBOKCSWGTM, int EVoiBzqlxLqI)
{
    double cwSEtPCKVYji = -617023.4093956221;
    double PKhvDYLqSXzQN = -733803.0392345671;
    bool llyRgjiDr = false;
    string PtEHXAkmSB = string("aGIGDUWySoPyeGchHIrTmkuwSyTYEXlFxRCkynEuyqQCMDA");
    string BMGuXyW = string("qyrhGqTY");
    string XIgiTSdAKQTIIEtH = string("tEHldTUNSGvHirNNlgOqNvGfTkTjidLPMJtAVdFWuNKeerkxxwMxKhLSuGaWVZKbWcnjFZiiUYmBJXDUJXW");
    double HhSAXUhQPEK = 146747.83481052943;

    for (int RBqoJaLThBpbV = 442871090; RBqoJaLThBpbV > 0; RBqoJaLThBpbV--) {
        continue;
    }

    for (int JDdylQlugkxvh = 642570241; JDdylQlugkxvh > 0; JDdylQlugkxvh--) {
        cwSEtPCKVYji -= DWUyajeDCjlAUza;
    }

    for (int LMQmreUccA = 146947182; LMQmreUccA > 0; LMQmreUccA--) {
        continue;
    }

    for (int ZsPnat = 439848649; ZsPnat > 0; ZsPnat--) {
        EVoiBzqlxLqI = fKBOMdnQV;
        PKhvDYLqSXzQN += PKhvDYLqSXzQN;
        PKhvDYLqSXzQN *= cwSEtPCKVYji;
    }

    for (int BTVFsw = 1493403635; BTVFsw > 0; BTVFsw--) {
        EVoiBzqlxLqI *= fKBOMdnQV;
        YYfoudZhS /= YYfoudZhS;
        jiWVzsKBOKCSWGTM = llyRgjiDr;
    }

    if (EVoiBzqlxLqI < -864619127) {
        for (int SdUZDIyCqWI = 1251510326; SdUZDIyCqWI > 0; SdUZDIyCqWI--) {
            jiWVzsKBOKCSWGTM = ! jiWVzsKBOKCSWGTM;
            XIgiTSdAKQTIIEtH = BMGuXyW;
            cwSEtPCKVYji -= HhSAXUhQPEK;
        }
    }

    for (int UNuGohk = 2004013585; UNuGohk > 0; UNuGohk--) {
        PtEHXAkmSB += PtEHXAkmSB;
        cwSEtPCKVYji -= HhSAXUhQPEK;
        DWUyajeDCjlAUza += HhSAXUhQPEK;
    }

    for (int mrMBmsB = 349058680; mrMBmsB > 0; mrMBmsB--) {
        continue;
    }
}

double nFzQUnBLRm::OKVtmn(double fKsVVfAKIFeZ, int qcRzfzveowcUSdOE)
{
    bool DcjGptetyqkW = true;
    double LmqhWIfO = -539564.3375918013;

    if (fKsVVfAKIFeZ >= -537251.0919826208) {
        for (int MeEiWkNxLmaQXs = 802209184; MeEiWkNxLmaQXs > 0; MeEiWkNxLmaQXs--) {
            LmqhWIfO = fKsVVfAKIFeZ;
            fKsVVfAKIFeZ *= LmqhWIfO;
            fKsVVfAKIFeZ = fKsVVfAKIFeZ;
            DcjGptetyqkW = ! DcjGptetyqkW;
        }
    }

    if (DcjGptetyqkW != true) {
        for (int SoYzJCtBOlFFM = 2063795987; SoYzJCtBOlFFM > 0; SoYzJCtBOlFFM--) {
            continue;
        }
    }

    for (int JlCjQksMvCSqMd = 91838935; JlCjQksMvCSqMd > 0; JlCjQksMvCSqMd--) {
        fKsVVfAKIFeZ += fKsVVfAKIFeZ;
        DcjGptetyqkW = ! DcjGptetyqkW;
        fKsVVfAKIFeZ -= fKsVVfAKIFeZ;
        DcjGptetyqkW = DcjGptetyqkW;
    }

    if (LmqhWIfO > -539564.3375918013) {
        for (int caVxafFTaM = 851720829; caVxafFTaM > 0; caVxafFTaM--) {
            DcjGptetyqkW = ! DcjGptetyqkW;
        }
    }

    return LmqhWIfO;
}

bool nFzQUnBLRm::UIySBa(double SBnUWESHGCxDfAN, double ckTBWOgypzBB, string NPgsjZbBQrKAE, double oqDqIXvfhxv)
{
    bool xUbEaZQiuCtWyodP = false;
    bool OapvAwKkCepL = true;
    int ArHkmDKjDNSK = 2124503827;
    bool PuVziuJ = false;
    string DZaIcIVd = string("qBPvLlFInbnsoTevUPspDByOghQVAygnQSlnLRyvbLADknDiBqNLpBuSGvHcamPAJziGqaDzYSxPoCSgOayCTiFPYAtwnwXvGBxaiESqyPmjSlropIHNTjFidsNPSghZgXreCvjomSmKlXecFLoAKpDrYOqcWXiogiYwuBZfmxmjxtegzCHRHARStANQzAshkyIpft");

    if (OapvAwKkCepL != true) {
        for (int kzpdpypL = 556685231; kzpdpypL > 0; kzpdpypL--) {
            oqDqIXvfhxv /= ckTBWOgypzBB;
            oqDqIXvfhxv += oqDqIXvfhxv;
        }
    }

    if (SBnUWESHGCxDfAN < -550529.4733787916) {
        for (int myFDNqCWgpclFPUs = 255651874; myFDNqCWgpclFPUs > 0; myFDNqCWgpclFPUs--) {
            DZaIcIVd += NPgsjZbBQrKAE;
        }
    }

    if (SBnUWESHGCxDfAN != -550529.4733787916) {
        for (int HlGoWNWi = 567246371; HlGoWNWi > 0; HlGoWNWi--) {
            ckTBWOgypzBB = ckTBWOgypzBB;
            OapvAwKkCepL = xUbEaZQiuCtWyodP;
        }
    }

    for (int RfXkFtUyQozHn = 234321659; RfXkFtUyQozHn > 0; RfXkFtUyQozHn--) {
        DZaIcIVd = DZaIcIVd;
        NPgsjZbBQrKAE += NPgsjZbBQrKAE;
    }

    return PuVziuJ;
}

double nFzQUnBLRm::gAyEEOxTuBxj(string krPeBtJKWt)
{
    int AeArqSDrUgNHO = -1056549329;
    double pBHNxGutkpvVj = -465856.74475853465;
    double qxfeuEzP = -1000638.9470523153;
    int aYpPvSWeYRzWP = -237764411;

    for (int jayyZiUQU = 1126081971; jayyZiUQU > 0; jayyZiUQU--) {
        krPeBtJKWt += krPeBtJKWt;
        AeArqSDrUgNHO += aYpPvSWeYRzWP;
    }

    for (int iYsKrgqbwbv = 326787833; iYsKrgqbwbv > 0; iYsKrgqbwbv--) {
        pBHNxGutkpvVj *= pBHNxGutkpvVj;
        AeArqSDrUgNHO *= AeArqSDrUgNHO;
        pBHNxGutkpvVj -= qxfeuEzP;
        pBHNxGutkpvVj = pBHNxGutkpvVj;
    }

    for (int jfSdCYcLK = 841279763; jfSdCYcLK > 0; jfSdCYcLK--) {
        aYpPvSWeYRzWP /= AeArqSDrUgNHO;
        pBHNxGutkpvVj += pBHNxGutkpvVj;
        qxfeuEzP = pBHNxGutkpvVj;
    }

    for (int aTvJMqp = 894132292; aTvJMqp > 0; aTvJMqp--) {
        krPeBtJKWt += krPeBtJKWt;
        pBHNxGutkpvVj *= pBHNxGutkpvVj;
    }

    return qxfeuEzP;
}

nFzQUnBLRm::nFzQUnBLRm()
{
    this->euiWEV(string("lxNdeNVjvgPhoq"), true, string("xbMaMLaOZnjHOrbgPHKGIoRryeZgUWnKreHyVDcEYPGjitzoLwVSpnHBaXoyfcnFfArFwtVgXcBefufMmRsWAZLYhVmKhGmgqYDohezGwqzRwkpLFFgqEoStoPBWTKuRvAzFpZOPXzdUcXvIVGUqVEdIEWbfEdVGfgyahqrIrfMPThbWnVtOPvfzgohTaLFlzWKtOJbxLdsRQ"), -965613201);
    this->stQKbGG(true, 384851.8485996436);
    this->BJrPIamGSxXTIb(-743589873, false, 71892.49788792257, -364843138, false);
    this->admHDFeKABQtkp();
    this->sypmfbRR(78805707, string("lqvDkKrfDWtUhbVolAXohVxfEIYnFtQlgiQUUdYyohtCJfqLYkdvENwJPrPiFREnbQOnRGIIEX"), false, string("PwRKpHtdzbyVroPRhrbfQeAJqDpkThXndikFfknGBJvPGDzxzZmgSsuNJjGObQZFLOVGTIhozbxisfPEkBAyRDJoyTAGXXrOcSHpUtHHDRHojJaAExnDPbRXYJINZXIxCpMxvfsjJItltJOTbvPzSRwfCjMUNnpTVsSpngIKiImEVZwGnKbmSnoS"), false);
    this->rqkVxOesjtDx(-1993001947, 75259.77218212126, -864619127, false, 1627557737);
    this->OKVtmn(-537251.0919826208, -1660682866);
    this->UIySBa(-833578.0553260626, -94008.62180083293, string("ruAuqyRJQaPcHSKbtnEcKDzwpzgmebcZAtWYYceyVuChceMcaGyQfppQkKxdVBWcqRCFtbdVqqmvmDusnBoOWjLnwgCaVMuEFeLbBFasZSERcnMfnMMazYgPtlktfYfRTtzAhyAXKgPNnVngKHyDKMbBIwYYZxPVWeDNpwVIzidhYHsNDHahYOjelzlguzCIlTDWJoCUhYlwPvHEOYwJpX"), -550529.4733787916);
    this->gAyEEOxTuBxj(string("JfXREoeeXUGKeKDZIocesKVwYSTqYPborNmDNweJqAImMDBbUuHyGRFPfxjWmHPtpXABGavskoLKcocbiClAEcQI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TqFmxdmIYJmdy
{
public:
    double yZrBtHauULDRfGCb;
    string STFmUOAht;
    bool RUbrusgSCjvupf;
    int lWWjqreyRTmO;

    TqFmxdmIYJmdy();
    void wSCUUhwEPgbavo(string AWzrbhLeZzbJFv, bool SBGGzHyUXq, int HKVvkx);
    void nXuxauMBxYRuIxJh(bool NkGkGaWpnqcy, string kuzhAq);
    double HhkvAMwkkZrZOI(string htnEdrK, bool aTjqXbgrhrCms);
    bool HYWrapDLED(double qVZCzIMXAjrOVf);
    string uTBqtDAASrEOz();
    void jZrplOia(string DObwPOKvMDRkDU, int uSnHkBV);
    void neqgItgANyEMtM(int tqeFazCUOUKZfOw, int aFAsCF, double gGUfND, bool huidktyEBIzQBI, string uveAOUWCfURnWEo);
    string CdzCCWhULLWPj(double ogLUsjBghysWi, bool VqSnIpU, string PFgAAYbgeN, int sbSLiMyU, string vyRdBOZcz);
protected:
    bool PqAJJUMoNf;
    bool PcbWBVbBAEF;
    double jtisANhJmC;
    double sGIPODTFZMYL;
    bool eCQxjl;
    bool QKrYmxwb;

    bool RsqVcDLBB();
    string TZDFYZjziKq();
private:
    int PSCeiLScB;
    bool WSpwawSgPyfej;
    string mIMji;

    bool bsVvwdk(double fgBzJ, int PtkaYkiGX, int xTKuGitNaP, double GnlwL);
};

void TqFmxdmIYJmdy::wSCUUhwEPgbavo(string AWzrbhLeZzbJFv, bool SBGGzHyUXq, int HKVvkx)
{
    double WoTvmVQmmEawc = -447524.2461782372;

    for (int ZjKIn = 1520351905; ZjKIn > 0; ZjKIn--) {
        continue;
    }

    for (int FVyMiNlhhvPCOk = 1513212903; FVyMiNlhhvPCOk > 0; FVyMiNlhhvPCOk--) {
        WoTvmVQmmEawc += WoTvmVQmmEawc;
        HKVvkx /= HKVvkx;
        WoTvmVQmmEawc /= WoTvmVQmmEawc;
        WoTvmVQmmEawc *= WoTvmVQmmEawc;
    }
}

void TqFmxdmIYJmdy::nXuxauMBxYRuIxJh(bool NkGkGaWpnqcy, string kuzhAq)
{
    bool lqRLVnBhBuVem = true;
    double IZNoyPAOQfi = 316222.93800306605;
    int JzeoLWv = 1085333303;
    string YEMoFPkoAoH = string("vtJcxRoyrODJsWHbheydwZXktqiiaMCZHIlMIbFqPwXFQmMJyiyTKiGKBkSJjwhIbtmYnRRVYarbcbGOOCpbiUKrDzYZSwiqJihvLSoyoNSReDLRVneaCutqtnPsIAJtuUnR");
    double aahpN = -119715.07339048764;
    bool PJadvaNwsRVdyWSl = false;
    string TlDqr = string("ekEMrGwq");
    bool qjlNLqnNKiNcHbY = false;

    if (kuzhAq >= string("vtJcxRoyrODJsWHbheydwZXktqiiaMCZHIlMIbFqPwXFQmMJyiyTKiGKBkSJjwhIbtmYnRRVYarbcbGOOCpbiUKrDzYZSwiqJihvLSoyoNSReDLRVneaCutqtnPsIAJtuUnR")) {
        for (int IPaJighodEFYKn = 279087873; IPaJighodEFYKn > 0; IPaJighodEFYKn--) {
            aahpN *= aahpN;
        }
    }

    if (qjlNLqnNKiNcHbY == false) {
        for (int YOCQhc = 1243298170; YOCQhc > 0; YOCQhc--) {
            JzeoLWv *= JzeoLWv;
        }
    }
}

double TqFmxdmIYJmdy::HhkvAMwkkZrZOI(string htnEdrK, bool aTjqXbgrhrCms)
{
    int kGYCnP = -148087159;
    bool KqpopzSWhXPLUY = true;
    bool mtuas = false;
    double NOVgtprJShBDD = 394992.2807540634;
    string vPdSAjliyQXdK = string("eAxFNGsqomRYpjfskDdxFDOXhQuUKuGiSSCdzplXEbOxWMycKLUWkjKvofeBuWbSqsuuxOFawktpQTgXPdXPJNXOLVtYmWlLwuOzz");

    if (mtuas == true) {
        for (int BcnoCkElytdPMc = 330546683; BcnoCkElytdPMc > 0; BcnoCkElytdPMc--) {
            mtuas = ! KqpopzSWhXPLUY;
            aTjqXbgrhrCms = ! KqpopzSWhXPLUY;
        }
    }

    for (int nAjehlWpMSe = 1068302750; nAjehlWpMSe > 0; nAjehlWpMSe--) {
        NOVgtprJShBDD = NOVgtprJShBDD;
        vPdSAjliyQXdK = vPdSAjliyQXdK;
    }

    return NOVgtprJShBDD;
}

bool TqFmxdmIYJmdy::HYWrapDLED(double qVZCzIMXAjrOVf)
{
    double btUFAcWoadKhp = -863203.7526869916;
    string DTvCybDjtmM = string("CDoFnoksugAYCiGQFyDfPkuxupCRWanDpukMbhRNQamQRewniPifeP");
    bool FBAZg = false;
    bool CfzasMSSCTsoNmwM = false;
    double gLXTgkyJJTM = 69779.6073202351;
    int xdDCcHgOjgQlsQhv = 313369380;
    int ZHphlVStfLSUZsA = 957254864;

    for (int sxSTlzTKbTsioX = 1378177124; sxSTlzTKbTsioX > 0; sxSTlzTKbTsioX--) {
        CfzasMSSCTsoNmwM = CfzasMSSCTsoNmwM;
        btUFAcWoadKhp *= btUFAcWoadKhp;
        CfzasMSSCTsoNmwM = FBAZg;
        xdDCcHgOjgQlsQhv = ZHphlVStfLSUZsA;
        FBAZg = FBAZg;
        gLXTgkyJJTM /= qVZCzIMXAjrOVf;
    }

    return CfzasMSSCTsoNmwM;
}

string TqFmxdmIYJmdy::uTBqtDAASrEOz()
{
    int ydOdpMOIsUgWYt = 397193679;
    double UGgmm = -801556.3114887305;
    string zgVcTJo = string("xLbjpTDCAxoTsQWcnSEJTdqwfUldaaljWqetiDwtSXeVvRfTKNKqHWoQnZcruYtRvBlNOYPusqKFwffTfMcxdWVHRiTLJEDZvkRVNaPsdjXqYpySkwoLaxKSyVfgKRhSetFZplrrGuzULFYhUGnWbGpjhDZWjgAxlcCeRBntrJPtHePckPTpkJlsfqIvZPUGeGzuMAsprHGMyfWZSVwgCcKjXRIYUFpsxBrKOSloOucGByyrckDetqstiYHf");
    string VUUfQUEOfMX = string("CYiVhIIYiyATmbuFelFlRuUoFisDflWTjYqfsKEhjsrShTXRRQCeivFofyrzbOzlOmzAaSwmTBjOXjPfuZHKcbfwqYVqTvQSANuWHQrgqNszaCgwTvYrDvMKfWLMoBdoYayjArhHNE");
    double bRkBXmhIPkI = 48370.31073262082;
    int kjGJoKX = 501079312;
    double AVisMfqwNUk = 255615.6694763093;
    double AGOXCtfcE = -251234.82074313893;
    double nocbQMIdGzcQVSYZ = -880088.168770068;
    int AMjNs = 1677212661;

    for (int aqtOZiLAVooWVdoM = 334673304; aqtOZiLAVooWVdoM > 0; aqtOZiLAVooWVdoM--) {
        VUUfQUEOfMX = zgVcTJo;
        VUUfQUEOfMX += zgVcTJo;
    }

    if (UGgmm <= -880088.168770068) {
        for (int nUWpefTKkkN = 1530543290; nUWpefTKkkN > 0; nUWpefTKkkN--) {
            continue;
        }
    }

    for (int bWFoCV = 2036838599; bWFoCV > 0; bWFoCV--) {
        VUUfQUEOfMX += VUUfQUEOfMX;
        bRkBXmhIPkI /= nocbQMIdGzcQVSYZ;
        AVisMfqwNUk *= AGOXCtfcE;
    }

    if (AMjNs != 1677212661) {
        for (int zOjjdIzv = 1063798441; zOjjdIzv > 0; zOjjdIzv--) {
            continue;
        }
    }

    for (int NFtqWsyYFnpfLZ = 1488978444; NFtqWsyYFnpfLZ > 0; NFtqWsyYFnpfLZ--) {
        continue;
    }

    return VUUfQUEOfMX;
}

void TqFmxdmIYJmdy::jZrplOia(string DObwPOKvMDRkDU, int uSnHkBV)
{
    double upbUdmcpSiAHrvGC = 760549.5000678482;
    string EFCOgp = string("WWXtacGSDgIgOOrRNJyievYSltofeyOMlyHKIILEZGENDVCsImWCFDHZtNIulTwtJjmQROHZyahjlrwC");
    double EjHuLPL = -708264.0752644724;
    bool rVOtDne = false;
    double TSOcPiHkaZRlEP = -256141.11026171336;
    string eRzKIoLavJr = string("tAhqnJQQTsvLOuUVSTszCdHTXBKMrfkXVfZvEzpBFIVWbfKagoIPdcJfVPAjmtIzvXRwHKohJOPGwqVJkMNFe");
    int WQQCTYYJnhDaz = 2140335080;
    int mJwPb = 1997298797;

    for (int UAWcnekuTUfpxfeU = 658456674; UAWcnekuTUfpxfeU > 0; UAWcnekuTUfpxfeU--) {
        mJwPb = uSnHkBV;
        uSnHkBV += WQQCTYYJnhDaz;
        EjHuLPL += upbUdmcpSiAHrvGC;
        WQQCTYYJnhDaz += WQQCTYYJnhDaz;
    }
}

void TqFmxdmIYJmdy::neqgItgANyEMtM(int tqeFazCUOUKZfOw, int aFAsCF, double gGUfND, bool huidktyEBIzQBI, string uveAOUWCfURnWEo)
{
    bool mnjUYQFdTLSkIeW = false;
    bool IsmzYTUUn = false;
    string JiRNEGK = string("yChGDlPtiQjEfOqlVxaiuPxWJekpcYkxmgGMzCgSSSxokuJvgZnSBUzeORHDfAZEOgQTWvqbrqlJasAmnvDJkTAHnyKVFFXgTxzEZMVZsSjcmoiWtIvmFsaCtKcGpDdjPGmCHuYPz");
    bool oDlzeJ = true;
    bool oVbNsCol = true;
    string TQBXAeZufSk = string("fvPNiPpc");
    bool eptYSCkLxNFXD = false;
    string pInOkJ = string("cepgliWGKovgqyGRQYVxYZjOozFoOovgekLE");
    bool vYtwUpABHnVmvtd = true;
    bool ZJBXAGyXeHTd = false;

    if (mnjUYQFdTLSkIeW != false) {
        for (int pmlYMEXcGAFwSMQf = 2090229451; pmlYMEXcGAFwSMQf > 0; pmlYMEXcGAFwSMQf--) {
            oVbNsCol = eptYSCkLxNFXD;
        }
    }

    for (int TdDbUiBjyyWnD = 724874036; TdDbUiBjyyWnD > 0; TdDbUiBjyyWnD--) {
        TQBXAeZufSk = uveAOUWCfURnWEo;
        huidktyEBIzQBI = ! huidktyEBIzQBI;
        oVbNsCol = ! mnjUYQFdTLSkIeW;
        eptYSCkLxNFXD = oDlzeJ;
        ZJBXAGyXeHTd = ! IsmzYTUUn;
    }

    if (huidktyEBIzQBI == false) {
        for (int jgnOALrQOE = 1980479513; jgnOALrQOE > 0; jgnOALrQOE--) {
            eptYSCkLxNFXD = vYtwUpABHnVmvtd;
            oVbNsCol = ! mnjUYQFdTLSkIeW;
        }
    }
}

string TqFmxdmIYJmdy::CdzCCWhULLWPj(double ogLUsjBghysWi, bool VqSnIpU, string PFgAAYbgeN, int sbSLiMyU, string vyRdBOZcz)
{
    double NMeTppVrvuLH = -842247.8582310753;

    for (int ZdyAUxTIAIyMEOQU = 763484669; ZdyAUxTIAIyMEOQU > 0; ZdyAUxTIAIyMEOQU--) {
        continue;
    }

    for (int sYlqeKjptEtNC = 386808749; sYlqeKjptEtNC > 0; sYlqeKjptEtNC--) {
        continue;
    }

    return vyRdBOZcz;
}

bool TqFmxdmIYJmdy::RsqVcDLBB()
{
    bool cOhkVcw = false;
    bool oRbIxeYGyac = true;
    int GVHnQHOkQFrPd = -428094405;
    double amIzHE = 998042.2859320705;
    bool XzhuZW = true;
    string wAyigHqhmGYZ = string("dAGbSRauOpdDghZzEHFayTsluFWJnwZMbcfLxlwTSQSdlEIbNIWcSbhFoGtYQhVSiFYlwWE");
    bool UcjzoVvgLlmFIYE = true;

    for (int JKIKIHEninxEGB = 916905250; JKIKIHEninxEGB > 0; JKIKIHEninxEGB--) {
        oRbIxeYGyac = ! XzhuZW;
        cOhkVcw = ! UcjzoVvgLlmFIYE;
    }

    return UcjzoVvgLlmFIYE;
}

string TqFmxdmIYJmdy::TZDFYZjziKq()
{
    string FKurXD = string("EpNrTcGVgxLDPUjclZcZyGyOgRZRlioHIVsVsbHdhHJRXYKUzuSQwEudwNXIGFxceFpsPOszEAMzswuzfTfqXkQGJyXCVPMxqMPhgicgmMAosKLdZJxpjObVpuSNKNsUxuyTVtqdviNlrybIGoPaZrLSi");
    double MRrWibaqQSAMDYvo = -109869.12235421527;
    string AHBnoAfbKrIgFfmS = string("TdPHAlLIkvDDqKhArObDpieHsEfSuCZALAmRUzRqoUinglgAgIqcvBzTdDjbdSwDupFxzwcnclTMkxRQfVsqSNDklznvblUAUnPJYYvBqQWGFeuoXirAFxXvIPgRXAvcBufkpITvfTOXOMMXzbkuymXGILnyrjHkGtHDUzUSqksQSEuOWSxIPaLBVZEuWHZqjWVoIyavfirrshkFkOYNCoocMtgSpOmZxiJvhtunQacGXOccdwmQcLOp");
    string espUeFSYnR = string("XRTnezCpFVqPjJPUsAwEFsqZvUgUfZZbmrgdHwPTvGcGdFguQxJDdSQOcprogRJDYIiMpeXPwwwVlxfocQxubHVeHmaoKwDShtOSzsAFnBKuxxSFOhQwGaASjcMQgLGQmVswSdaitQnmmnHlXGNsWarLNhUEzkzPEqEDPcvPQwjuQpXzcottaEoiVHKUgIewKCyeANvJglaLLNSFPJXmHl");
    bool GLAyoCw = true;
    bool PwrURcUFH = true;
    int MYDLPzh = 2083321726;
    bool TXykSNvsxWtJd = false;

    return espUeFSYnR;
}

bool TqFmxdmIYJmdy::bsVvwdk(double fgBzJ, int PtkaYkiGX, int xTKuGitNaP, double GnlwL)
{
    bool symurIBd = false;
    bool gtqyvosfx = true;
    bool VsTVZBDenvCl = true;
    int sbWjlwbEHEdys = -1629994641;
    double jGZgSBIdrAWdr = -721989.888699207;

    for (int ByyGoNn = 425185577; ByyGoNn > 0; ByyGoNn--) {
        jGZgSBIdrAWdr /= GnlwL;
        sbWjlwbEHEdys += xTKuGitNaP;
    }

    return VsTVZBDenvCl;
}

TqFmxdmIYJmdy::TqFmxdmIYJmdy()
{
    this->wSCUUhwEPgbavo(string("lRvoqXCARCKYjUuMTwHtZFVSKVyIOqcsaECkXDyAxsHqlNitMSfiqBCgEUYSsVwBbiKvlDbTUJSShSHcidgwyIqhBMFBedyKrkmRSMBqlyAbQfZcr"), true, -599054312);
    this->nXuxauMBxYRuIxJh(true, string("vCJofzpttQYlzueefDcdIyRparFYIEpMGdPWgBMFybUtobslnVLVRYFvqBYdDRLdJzFwlnMSYSBrDckJGmtiGkBerJElEWrtqhuOUEBGMgVgMvmfwyciahSPnLkooLELDeMmgsYyhTtyyUHVTmKzTDYTuDODWRUtxOpodcrz"));
    this->HhkvAMwkkZrZOI(string("BaXPdEnrceuwHTdJSBpaXGudFhcWorgYYQIVgBaAfyHiZFcyfJtLiYMkvJHYwKatKGfqUKAhShrRrnHjZTxGruWhxIIZHurArPNFFeFlvomEnRUYvJ"), false);
    this->HYWrapDLED(-805614.7332421927);
    this->uTBqtDAASrEOz();
    this->jZrplOia(string("hBIZIXQyCmtrlxppiNIxmUJiDfSNjDKTElGCInntNiLxgRIBVDAzyxmADoPUoBigcdznQmBXdkMMqwmXsPSwumJzxNNmYwuiPmYDwZZhiMUWMsSDEXdRUBuYPLcaogdhPDOImWUswqTTANGzqmyjAhxDbVtOXTokISzZoGpGtBCrNlboIMsSoAMZSITQYXJoTVIMONfFWyAewvni"), 319018853);
    this->neqgItgANyEMtM(-1577980320, 56544709, 111422.66322252771, true, string("ahoIlQBgSWyihitRQCryDBLxaEldksXzDWXFRtuVkuCXMJcFtgJQlRKoKzzmHHMqLLhaTghetBgKArTmRBMCVkQpyHZWhHxuBfUwxNlEaiUGeBiDRkHSkuyJfiWjJ"));
    this->CdzCCWhULLWPj(490817.0374965022, false, string("PjrQYlxRtuIIGkb"), -858243376, string("skullcJfMvXnEMGWOkSAqtyVKOcykcUVsdVAKrwPqlmEYtXFTdONpbhmpgDRstAyKryUGnkrqvhlgAPtJgVDQfOtwpELVUNbWucYwsJVsrZhtbAUwxqjsCIazeCgqKMRIFigNyRZKUexJ"));
    this->RsqVcDLBB();
    this->TZDFYZjziKq();
    this->bsVvwdk(-8665.745011629535, 1323308344, -1830248997, -144910.74273022293);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zOEHGkZ
{
public:
    int MkShEpSeigenZlMZ;
    bool vhCcwPpeVMVPLXol;

    zOEHGkZ();
    int kkhKtbOPPYd(bool LprPmG, int mxPfYzew, string nVDuSEmfTevF);
    bool WKcDMOVJ(int QuWyuESiiFNEZAk, bool hcYtbUqXk, double razovDwq);
    string MFNqxNCqskYHblM(double tELEDELbvGYK, bool wDLizsbaxXSa, string fmyNvXyQHNwCxpuX, double CLVoJTB, int hbivioEFhB);
    void KNZCmV(int prrNIjzih, double OXPdzxSvoQQxtmcK, bool JeEWM, bool aphMjJnZnFQ);
    double UKORXEFM(int WrCxxhBTyN);
    int cjibGbmwnfrZM(double jAtxFhD, double VsJsrwDoy);
    double uXyTGoRzYlw(string ACcTKHLuDREXWn, string CCMuRqiyqnuIm, bool mvVRPOy);
    bool xfrkOB();
protected:
    int RkLlcyM;
    bool SRRnwUtj;
    double hicxdXx;

    bool uAQIsCwFeZBSO(int qDvHOgSQRRT, double RTZuquDnxmccBLf, int WiKOhVAOdxeiTAU, string fYVrsFacxsjQUxkO, double RNAGNT);
    string KjYHQHYNiF(int kOuAmd, double emkBLM, string VvZlJ, bool XcliYrNWkATjlpi, double AdUFbtGtTvPu);
    string HzUPRgkIbXwRetGl(bool EQERha, double jfjBSyT, string nLilDr, string DJSTUONRZhEEmceM, bool neCeQklXYpIOJ);
    int VFNTCIRTHN();
private:
    bool fOhuUyb;
    double jovcb;

    string MItWpO(string xikLHoqbvHNTo, string RwDNOxVdznuJ);
    string DXEfaguBxCCsqDl();
    void LFwgoOaEOKAQAaaL(double MVszCsWF, bool efKbuSzf, int tHtAWfREzOC, int tsQpcnbnULi);
    double bCAnO(bool dsXIrds, bool utplK);
    void eqBepwDYjATdlZ(double fgTRzVdCiXSXg);
    string UWSDeTWAG();
    void LYnZGdHnUCcux();
    int udvPKnQbzKYTwaZg(bool bvtCrOabsyMFoBM, string RPOtFFZFn);
};

int zOEHGkZ::kkhKtbOPPYd(bool LprPmG, int mxPfYzew, string nVDuSEmfTevF)
{
    string kBTmvagZQAItLyk = string("RavYnXxXlzboaXxBMjMrbsHhkSITYwVMTNMLHFNWtqRENEMslVWTOFPezcHfHEPwdnSLSRNOJKGfBMVdkPkCqXQIYjbfDuikLvoxSmKQDFMqJjymmKrUDOqcDVfbZQHOxNZcJnyZjqQTtETQlOBvnzAIFmLoQqrpELpgdqivxKHlYEeTYwbEydlwoBqBPXJyuUTXKjskrzQdDEMeldLZdvWJtkLJzuStyFGyKCvJiYAhCTna");

    for (int hfFYXgaYiJhD = 761690137; hfFYXgaYiJhD > 0; hfFYXgaYiJhD--) {
        kBTmvagZQAItLyk += kBTmvagZQAItLyk;
        nVDuSEmfTevF = kBTmvagZQAItLyk;
    }

    for (int xxgtQvaGIo = 341323376; xxgtQvaGIo > 0; xxgtQvaGIo--) {
        mxPfYzew += mxPfYzew;
    }

    return mxPfYzew;
}

bool zOEHGkZ::WKcDMOVJ(int QuWyuESiiFNEZAk, bool hcYtbUqXk, double razovDwq)
{
    bool yHlJxzqTbOGtIAHu = true;
    bool DmSrtM = true;
    double FKKkmgfYYLg = 784388.4793945354;
    double wqhRneEBtGVkST = -662570.4901605633;
    double AIHowTdIpM = 886970.405172592;
    string DGHGTcmQ = string("UvLZjUSDHzdZlfjBQvfGkvVqRQDbRcEHPOOHZbKzqgruBkvcUuxDubsGfYUtvuttnXQTwsBWrHUAuKpZMlxJWeDbaZvbHLTxizgxaYSHzVBONBlapJNWobtLAcglvSuSFGNPQvEADfdzpVMYskqTFYkxpnDuqaYescDAsUAEVgGSTXpJqrUrKXREzQctuLHsKjUyPyRvNeFdbeRWhLCbDAkVhwowp");
    string iqZxobAbpwaX = string("uBlftzNbyJEQlvgRjBfhyzEhZsRTmbvhskBHQrmoCHedZSePmNsGMLFLggAapAVFnkvDjEQFEZKxGBuBGJDEqCaYPdMNIFdvmWwHgZSVsevOxjAPqnkQigSIWwtPQ");
    bool sWiDwSoixik = false;
    int KecRzvEbEVa = 2077838289;

    if (KecRzvEbEVa != -166205632) {
        for (int UjTTaS = 1873888192; UjTTaS > 0; UjTTaS--) {
            continue;
        }
    }

    if (DmSrtM != true) {
        for (int BnJqATnukOAsrPjy = 1761090861; BnJqATnukOAsrPjy > 0; BnJqATnukOAsrPjy--) {
            DGHGTcmQ = iqZxobAbpwaX;
        }
    }

    return sWiDwSoixik;
}

string zOEHGkZ::MFNqxNCqskYHblM(double tELEDELbvGYK, bool wDLizsbaxXSa, string fmyNvXyQHNwCxpuX, double CLVoJTB, int hbivioEFhB)
{
    string iqQMSScaP = string("XQCVDaALNDSHBYeRUwUAgOutNfRjPnHMmhMxrcbkKpAkPtGppdridLnBFQzEcIkzngwywFcLjFJyRQFteKHxqltvaEqDSjBgEzURjWe");
    int YCAPZBo = 2114003520;

    for (int TsgBUgOMgmP = 906598210; TsgBUgOMgmP > 0; TsgBUgOMgmP--) {
        continue;
    }

    for (int ZQfuxOdAcsR = 408166427; ZQfuxOdAcsR > 0; ZQfuxOdAcsR--) {
        continue;
    }

    return iqQMSScaP;
}

void zOEHGkZ::KNZCmV(int prrNIjzih, double OXPdzxSvoQQxtmcK, bool JeEWM, bool aphMjJnZnFQ)
{
    int xuANvnMilPhNpzAd = -2086882837;
    string LCJSNprWxkrGmrhw = string("IrzdtnpzPGEBxCxrcbRbQBwnOZNucncczhitlFgNvLJhwucCVPfNVhQwRvhwmAnwXeeAptWxycibpEKGWzEFjPwpUDKvEqwNAcRJgIcewueiOAFGOAMRglWJ");
    int LTgkzhZeMcCMw = -392150632;
    string vDztDpjZH = string("jQQQXCrLWLuYTBKitDBNafQHingdgxWtQCnjqeVjEkRmmzcKwjeEFZGcSgLTrgJQgFQTANsnmKAwDJyugQlqhSjvAqnQUJJtOyDorKpczVsQUOKzJFvTTbfbwsdFkgkQlzZdvxRTGzpvCJueQXCfjbCsMgebdSjnHFqSRCviNjExsbgynRRZBmEIsmDUwnnJZnBfstRdgyMhkh");
    string AhGvHIbnBDWqugw = string("WawfVCcwGWmIDHoKaDpeJXUckYdVwwENkZAfXaOmMjawIRyFvLsWIBxSLfoEazeurmITTUefXrKTgxWFEqsGBiQGZmgmDhcCAdXJPpmyuNPvGDNPYEdQkWqODrPFOBuIHTEcOXHGGJbnkJoGotEMdVKusahKQUOuCgsvqZfcYgombWSQDEohOgIoQaaYvbRdqtXjoSFkflTboVHQnoKZel");
    double aZVFfk = 89164.42552252937;
    string PDDbErSYyxN = string("wlHmWlVSxWiBNeEVtdfMwcEltMgAnyzIhMDFBYVvPqNkICWFMrFuYTUMRDNsqHYIewlVyeRrtTewA");
    int ARNhwPwZYcCDt = -854206006;
    double WNDqwBz = -771616.0404614399;
    int ROuoclgekXuC = 1018687526;

    for (int EIohMRl = 1411991798; EIohMRl > 0; EIohMRl--) {
        OXPdzxSvoQQxtmcK *= aZVFfk;
        LTgkzhZeMcCMw *= ROuoclgekXuC;
        WNDqwBz *= OXPdzxSvoQQxtmcK;
    }
}

double zOEHGkZ::UKORXEFM(int WrCxxhBTyN)
{
    string lvmCs = string("MMuHwqHThBVwBfpLajdZzEAUbZxjrIAjlwdkLGtJe");
    double yOJap = 1021396.1436167717;
    double IQdbk = -93230.26146296483;
    string otOvgSttppJ = string("rbgYCfuLOEFdyDhlEGxwyomoEkQWztAyKaSOCdIBBAnYjMsPohrDNrFPNGgVgzTVYectoETLWPpkSiYIGbethWYwLpnuUttIIIrsyszjNwcCBHpUzeaiGZmrxGWJqzrGrNhpsDHdtoNjumpXiyCkaKUhfSdtkPwGQamDatbQIzgvmBTVPfQOYgQCyefkVvbCPJRJWNG");
    bool FFEjKzQgb = true;
    double kVxlRO = -308576.7603031446;
    bool ySDAhEgDfpXcol = true;
    string tgjiMuwe = string("IzbuqbUlEhUBoXhxMirafAxVzexoISLlpVAvFdgVTHwedXZokfSsMJkkWkCgXcRGzTNKzvASijLynBCtswSzQKTxvsOqJADlRKabqHJEdQEmtQeWuNrYoZYAJmqQibdtQfoMhPonnTYQrjbwvhsaTFNcZTiEfxYiRLnQnokKuhhHwVFoqmLxOYBJqgmvTgNSfjpjlCaitNsDxXwmcGzdMrXNIOedpLxBpXOwJzZIen");
    bool MsozJEVNyrskmix = true;
    string clJKwSVg = string("XKsSkMdIqMQhPtjzvEgRrIzneGiPJyYLJmGQPxaPpCrttaVzqbKNqFjtjOianWydejNSkVlMulxSekxziMrwrzCYekYbdCUlDjlbFidLcBpVbQZMeysbQYslctvp");

    for (int dMChzE = 1771205015; dMChzE > 0; dMChzE--) {
        continue;
    }

    if (yOJap < -308576.7603031446) {
        for (int jOTVMGQEVccF = 61111089; jOTVMGQEVccF > 0; jOTVMGQEVccF--) {
            otOvgSttppJ = lvmCs;
            MsozJEVNyrskmix = ySDAhEgDfpXcol;
            IQdbk *= yOJap;
            kVxlRO *= IQdbk;
            FFEjKzQgb = MsozJEVNyrskmix;
            MsozJEVNyrskmix = FFEjKzQgb;
            IQdbk -= IQdbk;
        }
    }

    if (otOvgSttppJ == string("rbgYCfuLOEFdyDhlEGxwyomoEkQWztAyKaSOCdIBBAnYjMsPohrDNrFPNGgVgzTVYectoETLWPpkSiYIGbethWYwLpnuUttIIIrsyszjNwcCBHpUzeaiGZmrxGWJqzrGrNhpsDHdtoNjumpXiyCkaKUhfSdtkPwGQamDatbQIzgvmBTVPfQOYgQCyefkVvbCPJRJWNG")) {
        for (int qgMfEamGxmKNmo = 560278426; qgMfEamGxmKNmo > 0; qgMfEamGxmKNmo--) {
            continue;
        }
    }

    for (int jrOohXCxtw = 80567342; jrOohXCxtw > 0; jrOohXCxtw--) {
        continue;
    }

    return kVxlRO;
}

int zOEHGkZ::cjibGbmwnfrZM(double jAtxFhD, double VsJsrwDoy)
{
    double pfKXJ = -973552.964358373;
    int CoxaTErY = 1521603475;
    bool sWPaofngwdCN = false;
    string GtrfJXOsO = string("YRTyIbzvNZhkqTBiUUrcOzhEzPRLVjJBCFaPVmWTkczhkJkHOUGIfJbMSQuGysbHWKvhVEKsKxFQWPRxPhPBLnwZCPjOHDbmulEuPsAkHjuWTpQclFhvjUSbHALlMLSeZLRVpwlOTIyVeeSWlTHPqQkNxRmTponhnHhlUnBWlxGvhVHcUHXaYAbTjlGvNFMeZ");
    string XZVIdCjLlkUeqTzs = string("UHjmayFvYXNMuQosmZbloRmijZSnIEfkXRRJpQwpVdwDrzyvqbMqxzFryMfAZDsVRpvjDJxBNirJgcEUMDNVozdQVLyZlqzmHeqPkfHBUmBzgSYLAqixYDSFKluvsdpDcJnkuvTmGIjjloJC");

    if (CoxaTErY >= 1521603475) {
        for (int fzEht = 1267354731; fzEht > 0; fzEht--) {
            CoxaTErY = CoxaTErY;
            VsJsrwDoy /= VsJsrwDoy;
            CoxaTErY = CoxaTErY;
        }
    }

    for (int DxjdkTcVPlMHw = 1093185840; DxjdkTcVPlMHw > 0; DxjdkTcVPlMHw--) {
        continue;
    }

    for (int VZTvZxAIbEqVDkO = 1999319405; VZTvZxAIbEqVDkO > 0; VZTvZxAIbEqVDkO--) {
        pfKXJ /= VsJsrwDoy;
        VsJsrwDoy -= jAtxFhD;
        XZVIdCjLlkUeqTzs += GtrfJXOsO;
        GtrfJXOsO += GtrfJXOsO;
        pfKXJ = jAtxFhD;
    }

    for (int tbgpZtITXD = 2076661280; tbgpZtITXD > 0; tbgpZtITXD--) {
        XZVIdCjLlkUeqTzs += XZVIdCjLlkUeqTzs;
    }

    if (VsJsrwDoy <= -973552.964358373) {
        for (int hJsLrpniBikx = 727729380; hJsLrpniBikx > 0; hJsLrpniBikx--) {
            VsJsrwDoy *= pfKXJ;
            sWPaofngwdCN = ! sWPaofngwdCN;
            VsJsrwDoy += jAtxFhD;
        }
    }

    return CoxaTErY;
}

double zOEHGkZ::uXyTGoRzYlw(string ACcTKHLuDREXWn, string CCMuRqiyqnuIm, bool mvVRPOy)
{
    int RQKptbbbTvYMziFr = -948713909;

    for (int duRHNBOrfOjcevO = 1546269174; duRHNBOrfOjcevO > 0; duRHNBOrfOjcevO--) {
        CCMuRqiyqnuIm += ACcTKHLuDREXWn;
        RQKptbbbTvYMziFr -= RQKptbbbTvYMziFr;
        mvVRPOy = mvVRPOy;
        ACcTKHLuDREXWn += CCMuRqiyqnuIm;
    }

    return 732867.0764622631;
}

bool zOEHGkZ::xfrkOB()
{
    int jmHcdjRkNsmvkMBo = -1176441937;
    string rsYfUskRC = string("yQENiSYhE");

    if (rsYfUskRC >= string("yQENiSYhE")) {
        for (int qaoLcTrsACFu = 1370892838; qaoLcTrsACFu > 0; qaoLcTrsACFu--) {
            rsYfUskRC += rsYfUskRC;
            jmHcdjRkNsmvkMBo /= jmHcdjRkNsmvkMBo;
            jmHcdjRkNsmvkMBo *= jmHcdjRkNsmvkMBo;
            jmHcdjRkNsmvkMBo -= jmHcdjRkNsmvkMBo;
            jmHcdjRkNsmvkMBo += jmHcdjRkNsmvkMBo;
            rsYfUskRC += rsYfUskRC;
            rsYfUskRC += rsYfUskRC;
            rsYfUskRC = rsYfUskRC;
        }
    }

    if (jmHcdjRkNsmvkMBo <= -1176441937) {
        for (int vjWfSiy = 1336096892; vjWfSiy > 0; vjWfSiy--) {
            continue;
        }
    }

    if (jmHcdjRkNsmvkMBo <= -1176441937) {
        for (int aRgBaFuik = 1020881707; aRgBaFuik > 0; aRgBaFuik--) {
            rsYfUskRC += rsYfUskRC;
            rsYfUskRC += rsYfUskRC;
            jmHcdjRkNsmvkMBo = jmHcdjRkNsmvkMBo;
        }
    }

    for (int byXDTTf = 1069931460; byXDTTf > 0; byXDTTf--) {
        rsYfUskRC = rsYfUskRC;
        rsYfUskRC = rsYfUskRC;
        jmHcdjRkNsmvkMBo *= jmHcdjRkNsmvkMBo;
        rsYfUskRC = rsYfUskRC;
        jmHcdjRkNsmvkMBo -= jmHcdjRkNsmvkMBo;
    }

    if (jmHcdjRkNsmvkMBo == -1176441937) {
        for (int lXVLfEFbjN = 1000895204; lXVLfEFbjN > 0; lXVLfEFbjN--) {
            jmHcdjRkNsmvkMBo = jmHcdjRkNsmvkMBo;
            jmHcdjRkNsmvkMBo *= jmHcdjRkNsmvkMBo;
            rsYfUskRC += rsYfUskRC;
        }
    }

    return false;
}

bool zOEHGkZ::uAQIsCwFeZBSO(int qDvHOgSQRRT, double RTZuquDnxmccBLf, int WiKOhVAOdxeiTAU, string fYVrsFacxsjQUxkO, double RNAGNT)
{
    int kXjCDXvNpaPDmWu = -1268303840;
    int jONAIe = 371445567;
    int gaHRksrvWamzhTB = 1771760745;
    int WcikVs = 1148259378;
    string OaFbeR = string("LZFOwwDCBUDTJIuZOGoEGNlmcAuydYGvORJntOlrtnDpKjmZkoSwasYJwUchDpCmtBvuTfbUJCUcuhYiIoSgKImKKOEAwiujSvzLefRpHachcXurtFLRShljuLjkZMuWnJbHbcqtrufHFniSJyGbWHQoRerwEQhqzRZgizfCKLtBTmzDXY");
    bool FHxZZRgahhq = true;

    if (gaHRksrvWamzhTB <= 731342280) {
        for (int wbTNGgtsPrlk = 1572031353; wbTNGgtsPrlk > 0; wbTNGgtsPrlk--) {
            jONAIe = WiKOhVAOdxeiTAU;
            kXjCDXvNpaPDmWu *= WcikVs;
            RTZuquDnxmccBLf /= RTZuquDnxmccBLf;
            WiKOhVAOdxeiTAU /= WcikVs;
        }
    }

    if (gaHRksrvWamzhTB <= 1771760745) {
        for (int RfaHyj = 1457529965; RfaHyj > 0; RfaHyj--) {
            WiKOhVAOdxeiTAU += kXjCDXvNpaPDmWu;
        }
    }

    for (int EXPAYYtM = 857964015; EXPAYYtM > 0; EXPAYYtM--) {
        WcikVs = jONAIe;
        WcikVs /= jONAIe;
        gaHRksrvWamzhTB += WcikVs;
    }

    for (int hsqpumMHjbi = 403815664; hsqpumMHjbi > 0; hsqpumMHjbi--) {
        continue;
    }

    for (int nTJGZpSjHAoYykA = 1627682138; nTJGZpSjHAoYykA > 0; nTJGZpSjHAoYykA--) {
        continue;
    }

    return FHxZZRgahhq;
}

string zOEHGkZ::KjYHQHYNiF(int kOuAmd, double emkBLM, string VvZlJ, bool XcliYrNWkATjlpi, double AdUFbtGtTvPu)
{
    int BejmfGXLuCAoabC = 1112769370;
    double NvNLrqD = -636290.4671549872;
    double WTwpXMr = -205199.78782500152;
    int ouHBZV = 727859246;
    bool SaMcDPJrtdH = true;
    string OgOrJedExN = string("HoobIUqQUqeJJlZPXygOJkzWxbWxPDiNooJ");
    string GGSVoo = string("voWsRXqphWhErzkkvTiLochbpvBxGwBsGLkjmXVnYRHU");
    double ATZTec = -242012.41689877104;
    string wTIGazqZuPaD = string("ouQJYmsQKsRvctVTLeSRXYUJyCznrTBkdYLgmAExVOScYiIqvAphVpugrihvARBdBoHYauHpixSPHPGzNNwyeTqIcNNMQboVZKpiSpIAgGbCGhDWcjRuuEcGOLNYyWSnXMWFozYGNNMPiuSDTztmrUoowWisofxwyWBEHccfqHtDHCfiSBVohieUueobcJNWsgkqreNeOxcScxNdrghwNclCpt");

    for (int VfqMNTsQD = 723733181; VfqMNTsQD > 0; VfqMNTsQD--) {
        continue;
    }

    for (int VdpAeJuB = 738039158; VdpAeJuB > 0; VdpAeJuB--) {
        GGSVoo += OgOrJedExN;
    }

    for (int eqAaqZh = 1058174701; eqAaqZh > 0; eqAaqZh--) {
        continue;
    }

    for (int yaerecthG = 892652699; yaerecthG > 0; yaerecthG--) {
        continue;
    }

    for (int hNWqTLgXa = 1803357546; hNWqTLgXa > 0; hNWqTLgXa--) {
        continue;
    }

    return wTIGazqZuPaD;
}

string zOEHGkZ::HzUPRgkIbXwRetGl(bool EQERha, double jfjBSyT, string nLilDr, string DJSTUONRZhEEmceM, bool neCeQklXYpIOJ)
{
    int vByONNwLEhyOnPn = 1684861402;

    for (int fdXmtwubTsg = 7226711; fdXmtwubTsg > 0; fdXmtwubTsg--) {
        vByONNwLEhyOnPn *= vByONNwLEhyOnPn;
        nLilDr = nLilDr;
        nLilDr = nLilDr;
        EQERha = EQERha;
    }

    if (DJSTUONRZhEEmceM <= string("BDMACBNhrcDuToZpVLjjxyeTsCYggQRcgtFmnQtkBGBvIRlXKWDFEEYUeBsvARNdGpbemXbUqZoMExQTIZEVEBgYMkuFiDCNqVvdJYDIhnVgjtVRPPRgwQwcRXHEMkYFxVCxNcrcHwZZBpHxgu")) {
        for (int chQCrdADOuupxQTk = 989233686; chQCrdADOuupxQTk > 0; chQCrdADOuupxQTk--) {
            neCeQklXYpIOJ = EQERha;
        }
    }

    for (int alPrqfmpcOnyo = 1880264506; alPrqfmpcOnyo > 0; alPrqfmpcOnyo--) {
        DJSTUONRZhEEmceM = nLilDr;
        neCeQklXYpIOJ = EQERha;
        nLilDr += nLilDr;
    }

    for (int HOSNzr = 1013367990; HOSNzr > 0; HOSNzr--) {
        vByONNwLEhyOnPn /= vByONNwLEhyOnPn;
    }

    return DJSTUONRZhEEmceM;
}

int zOEHGkZ::VFNTCIRTHN()
{
    bool ssAdoMVShY = false;
    int FUWJBeMI = 366888578;
    double mpttGvCN = 459106.04364328156;
    int iHIcT = 1769771418;
    bool utXvqBdby = true;

    if (mpttGvCN <= 459106.04364328156) {
        for (int QhEIe = 1325538682; QhEIe > 0; QhEIe--) {
            FUWJBeMI = FUWJBeMI;
            iHIcT += FUWJBeMI;
            mpttGvCN -= mpttGvCN;
            mpttGvCN /= mpttGvCN;
            iHIcT *= FUWJBeMI;
            utXvqBdby = ssAdoMVShY;
        }
    }

    for (int ORjGFNKAqg = 570146563; ORjGFNKAqg > 0; ORjGFNKAqg--) {
        mpttGvCN *= mpttGvCN;
        iHIcT *= iHIcT;
    }

    if (iHIcT <= 1769771418) {
        for (int cjJghsj = 1651235829; cjJghsj > 0; cjJghsj--) {
            continue;
        }
    }

    for (int sahhVLa = 1799536067; sahhVLa > 0; sahhVLa--) {
        continue;
    }

    if (ssAdoMVShY != false) {
        for (int QPOwturRvTad = 895911267; QPOwturRvTad > 0; QPOwturRvTad--) {
            ssAdoMVShY = utXvqBdby;
            FUWJBeMI *= iHIcT;
            utXvqBdby = ssAdoMVShY;
        }
    }

    if (ssAdoMVShY != true) {
        for (int KBArBSheQuxPmrX = 1707188073; KBArBSheQuxPmrX > 0; KBArBSheQuxPmrX--) {
            iHIcT /= FUWJBeMI;
            mpttGvCN *= mpttGvCN;
            FUWJBeMI -= FUWJBeMI;
            ssAdoMVShY = ssAdoMVShY;
        }
    }

    return iHIcT;
}

string zOEHGkZ::MItWpO(string xikLHoqbvHNTo, string RwDNOxVdznuJ)
{
    string mONbOObzja = string("apXiTwqTTLHYCzXwoesmmbKkGUdhDjjfoHgHcZlweOBzpdpNQhwydirluhLUtJrTWqCJJjQdWgEkRgSgWBVSBkPgjvJefEnTNaQbexNpmqFheQIiBwUygXNYMEBsCPhVKQsCpokHgwGqxiMhkNRsjRPkTirtEFEHvddHICuWNzCgwNyawNnxOMxnANyRFqwbWZpvyzhUzAySev");
    int LmTwCXMmxtDKZE = -2123325540;
    string wBNhTtj = string("slHPmVSNeXVajOhDpYyZBXHDzSccvmypauyezMzDHlVQYGTzkoEZMfZIFHnFwERKPMORLSURdStgYFNAHHWYGKcNcTUVtyGYCFtYHtTSldylumftvSshrTVEczjPQdFwZsGyiKjuUnGnjBtnPHBmtHbWoZIbSXACFpxaNTEnaIGh");
    int eyYGZC = 1400903014;
    int CnYptowOrrseNKU = -384713593;
    string ztfUROPSiIuDV = string("mBunksuUVctMcckWXfgvvTPkUgvBEHDKadWFyKXzlVEpITIeuXNQxCGkTtkGZJFbAScTiqzRJEpXONEMjZIpRpJgBVAmaQMHAUlBwOiMzssTVrQzNuwmhcyUoQcXSJbGmbBcSZaXLNPsCszkmToKeSvNXnZkOITxQUgosoUoSGlggnuIwfgjxRLrSxfIKpKHDnzHUoDPtxUYLAWEEtShHhlbyfJiLfmZuqvjqbvGKYhTZ");
    int dfXlSmzyOS = 1487552455;

    if (LmTwCXMmxtDKZE >= 1400903014) {
        for (int QMAqtyvMhyolobZk = 272474538; QMAqtyvMhyolobZk > 0; QMAqtyvMhyolobZk--) {
            RwDNOxVdznuJ = RwDNOxVdznuJ;
            mONbOObzja += RwDNOxVdznuJ;
            LmTwCXMmxtDKZE *= eyYGZC;
            ztfUROPSiIuDV = xikLHoqbvHNTo;
        }
    }

    return ztfUROPSiIuDV;
}

string zOEHGkZ::DXEfaguBxCCsqDl()
{
    string brfXeTEVTUxSuiLE = string("OHODdvJMaiZUNTXqruZaONTadtyielTkGAmuWQBfoXhimRxMHaxxNTlvAwWpuvZYorcjKBkkwMrIxMtuegiXJMijjwqHOuyXHBECerLBShJJgChbqTLyviyAgWEjraEicewIFIThccwbXhKkbVGBGjZWzLbTAMrWKysKywMDjgXJFWjsgbSDaYwXcXPC");

    if (brfXeTEVTUxSuiLE != string("OHODdvJMaiZUNTXqruZaONTadtyielTkGAmuWQBfoXhimRxMHaxxNTlvAwWpuvZYorcjKBkkwMrIxMtuegiXJMijjwqHOuyXHBECerLBShJJgChbqTLyviyAgWEjraEicewIFIThccwbXhKkbVGBGjZWzLbTAMrWKysKywMDjgXJFWjsgbSDaYwXcXPC")) {
        for (int wvmEXepnF = 316995831; wvmEXepnF > 0; wvmEXepnF--) {
            brfXeTEVTUxSuiLE = brfXeTEVTUxSuiLE;
            brfXeTEVTUxSuiLE += brfXeTEVTUxSuiLE;
            brfXeTEVTUxSuiLE += brfXeTEVTUxSuiLE;
            brfXeTEVTUxSuiLE = brfXeTEVTUxSuiLE;
            brfXeTEVTUxSuiLE += brfXeTEVTUxSuiLE;
            brfXeTEVTUxSuiLE = brfXeTEVTUxSuiLE;
            brfXeTEVTUxSuiLE = brfXeTEVTUxSuiLE;
        }
    }

    return brfXeTEVTUxSuiLE;
}

void zOEHGkZ::LFwgoOaEOKAQAaaL(double MVszCsWF, bool efKbuSzf, int tHtAWfREzOC, int tsQpcnbnULi)
{
    int OCBKkH = 837437060;
    bool BVbnaSBHCuJ = false;
    int oAFTpd = -243435715;

    if (tsQpcnbnULi > 837437060) {
        for (int jGWXcEK = 306170450; jGWXcEK > 0; jGWXcEK--) {
            continue;
        }
    }
}

double zOEHGkZ::bCAnO(bool dsXIrds, bool utplK)
{
    double tXqIbQKicz = 830601.6569845809;
    int YAtjAlFyF = -1311953047;
    double HazVLSBCSTsv = 410179.8998577552;
    string sfqBgmOKkXJWr = string("cuZgtNMWgWOZPTLGFadVPitrhegiTKTwcIcGYQtIYysZcKCkbjIsFadYgtfVOWzxvlEVgTlwpDhVJBwpCkwtMzmbtJRITl");
    double bLZlVDAff = 745770.8554588181;
    int HJhNbqieYAsgn = -886665848;
    int lCYSAN = 7761077;

    for (int NfNBETqaLt = 1602258218; NfNBETqaLt > 0; NfNBETqaLt--) {
        YAtjAlFyF -= HJhNbqieYAsgn;
        utplK = ! dsXIrds;
    }

    for (int FGPzX = 1482828322; FGPzX > 0; FGPzX--) {
        lCYSAN -= lCYSAN;
    }

    for (int ykecGAGV = 1549713960; ykecGAGV > 0; ykecGAGV--) {
        tXqIbQKicz /= HazVLSBCSTsv;
        HazVLSBCSTsv /= HazVLSBCSTsv;
        lCYSAN /= lCYSAN;
    }

    return bLZlVDAff;
}

void zOEHGkZ::eqBepwDYjATdlZ(double fgTRzVdCiXSXg)
{
    double ZqSITQOwmhMwdj = 865544.0698449728;
    bool qivgWmcDKLRhuHf = true;
    double EJQJiruoCHb = 141130.74408623695;
    double YTfSDkT = -58167.85877346407;

    for (int PVnlHN = 320103268; PVnlHN > 0; PVnlHN--) {
        YTfSDkT += YTfSDkT;
        YTfSDkT += YTfSDkT;
        EJQJiruoCHb *= ZqSITQOwmhMwdj;
        fgTRzVdCiXSXg /= YTfSDkT;
        ZqSITQOwmhMwdj *= fgTRzVdCiXSXg;
        fgTRzVdCiXSXg = fgTRzVdCiXSXg;
        fgTRzVdCiXSXg -= ZqSITQOwmhMwdj;
        fgTRzVdCiXSXg += YTfSDkT;
    }
}

string zOEHGkZ::UWSDeTWAG()
{
    int dxZFPh = -1808137331;
    int hDddve = 217246221;
    string mdfyMoBnWRWeSL = string("vpPjZypcCaINRtqwQdHjyyomBKZWiNZldlQJQsNyZAIGMqzjJEuZLqzthMVeMIAXIEPAoECqsDVFQIRpBdUmhHcKVKOdNqnhqSzRbYazDKeHRWfGUHWWHYupKmbaqFsByccFeSNyXsgzJZYaHbsItyBheZcvJknCPkBuCPn");
    double rrefHEGOCXjsjOD = 856573.756283044;
    int TRQGieNxvbcMVt = -690908129;
    string nvPAHlUgvCY = string("OYwzzIZdkZelPVtljzMHUyttjzvXuOjRorQTtaEHqeoiDyIAlWbXlqrwUwGbdQunmHCSTRkZyDWDJxmYiwBTcKdabJFaTUOukZcSoTgabORrTkxwssxPcRYFQfYAYbKxuawZonYXtfqiDAFmTyIENDL");
    double ZmslVTxU = -533261.2442854806;
    int kSBXeKRr = 1175406925;
    int LSUlNoSynyei = 2136876690;
    string YhYQfaG = string("hxVemDzXoTRfHffBjaIoBIisQWYAObsbdAkwDKQCMsAlRuQtJwjHpYLKgloEGoSHowhPDMzqrUWoaNLHWvqVLwZDAltmkPauKUfvQeoQfJAXLsmPGcTxjMNRWZMWjWQkQTROnXMbwUUoPhLMHanmMpgraZHKWeSZCJUL");

    for (int edNZQIPP = 1782620081; edNZQIPP > 0; edNZQIPP--) {
        LSUlNoSynyei = TRQGieNxvbcMVt;
        nvPAHlUgvCY = mdfyMoBnWRWeSL;
        nvPAHlUgvCY += YhYQfaG;
        dxZFPh *= TRQGieNxvbcMVt;
        YhYQfaG += mdfyMoBnWRWeSL;
    }

    return YhYQfaG;
}

void zOEHGkZ::LYnZGdHnUCcux()
{
    double NEuXzG = -878114.9101749005;
    double ZAjlHmcvMszJ = -424103.6251578293;
    string tiezKdcpOOEmPHTC = string("OHlNDZHLihLXeZutOvdeWoUKevkSVvdLjZtmPKDfiwXkAbIbujxYCErQNP");
    string lOaeuCdQlPkDfqXl = string("UJSUhOBCzeOCOLfdB");
    string GrDsKZWZsvG = string("vqNejBNDclaXgaNgqeKUBJMtaAqWVqeTigoCNnxsXkatLeZLYzT");

    if (NEuXzG < -424103.6251578293) {
        for (int QpvaY = 1747967365; QpvaY > 0; QpvaY--) {
            ZAjlHmcvMszJ += ZAjlHmcvMszJ;
            ZAjlHmcvMszJ *= NEuXzG;
        }
    }
}

int zOEHGkZ::udvPKnQbzKYTwaZg(bool bvtCrOabsyMFoBM, string RPOtFFZFn)
{
    double rYyUYUKZeCyzOlJ = 624920.7888426667;
    string VBvCnTbqjOUJojQU = string("JdFpVrDkiNnedNMfXByVRHiKmdpNPlsCatINVcguHMsLWygiiZSJpingYzYheMJVYVSYJGpGMJamuTrzrWOGrLPZFAfaRMHNgKlIcJmkZMQflGUjulKRzYSw");
    bool gJnXekDXOQfg = true;
    double fxwLAuHeW = 1030820.1129611675;
    int sEcVZexAQr = -1687100141;
    string tWpoZIIbdBsYg = string("TbTBQTQsqapiLrjJXAfzrPbuhbPpKPTgGFkziXYaHbHpMKzzEGBtiAapqUCRvvTokoYLXldWgKBalUinSHJaerjMuAdplKuWJReNQLXYmphEaDjHPEaucthRKFkdBXiugEBhEjNmh");
    string lbjYS = string("hvJBRQoqFpsEkxdQhokUmmLdxpWZgCJRMkhEnyUAuyRXthrpvuggHbJLoWzFkajNtHfmvUegJVXFjUECGLyczupKeEezKcubtsqkcltdcZaOIdavdluzIowYwWRgYYuaDKOfghKkMHisWKNAAPVBmIOKcTEpcGgcYruWSGNSajnLcxNpGirmkJqvcAPUadhtQp");

    for (int LOcGzDhcAnVL = 1297362013; LOcGzDhcAnVL > 0; LOcGzDhcAnVL--) {
        continue;
    }

    if (tWpoZIIbdBsYg > string("kAzYfFFZrULYqdHbEgqVWFsCvtkhRumdoKVZjgRiHhjgqYeuZJQMqczDTyQUrjouOINrnJWsaalCpSnCvsuuTkwaaOjJlWUTPwvUJFLBnxrR")) {
        for (int YpSTNLmA = 870824985; YpSTNLmA > 0; YpSTNLmA--) {
            lbjYS += lbjYS;
        }
    }

    for (int cQtUgXYOwcMEiEG = 358849847; cQtUgXYOwcMEiEG > 0; cQtUgXYOwcMEiEG--) {
        gJnXekDXOQfg = bvtCrOabsyMFoBM;
        VBvCnTbqjOUJojQU = tWpoZIIbdBsYg;
    }

    if (RPOtFFZFn < string("JdFpVrDkiNnedNMfXByVRHiKmdpNPlsCatINVcguHMsLWygiiZSJpingYzYheMJVYVSYJGpGMJamuTrzrWOGrLPZFAfaRMHNgKlIcJmkZMQflGUjulKRzYSw")) {
        for (int WGMttDRSBy = 1688965421; WGMttDRSBy > 0; WGMttDRSBy--) {
            RPOtFFZFn = RPOtFFZFn;
            RPOtFFZFn += RPOtFFZFn;
            lbjYS = tWpoZIIbdBsYg;
            VBvCnTbqjOUJojQU += lbjYS;
        }
    }

    if (tWpoZIIbdBsYg < string("kAzYfFFZrULYqdHbEgqVWFsCvtkhRumdoKVZjgRiHhjgqYeuZJQMqczDTyQUrjouOINrnJWsaalCpSnCvsuuTkwaaOjJlWUTPwvUJFLBnxrR")) {
        for (int KdJjQGoRrNKwUBi = 1520809143; KdJjQGoRrNKwUBi > 0; KdJjQGoRrNKwUBi--) {
            rYyUYUKZeCyzOlJ += rYyUYUKZeCyzOlJ;
            lbjYS += lbjYS;
        }
    }

    for (int GpWFtsxq = 422446885; GpWFtsxq > 0; GpWFtsxq--) {
        gJnXekDXOQfg = ! bvtCrOabsyMFoBM;
    }

    return sEcVZexAQr;
}

zOEHGkZ::zOEHGkZ()
{
    this->kkhKtbOPPYd(false, 331288259, string("dUPwxoefvjdsknkIuwwdvkMZHdRvrFaDFflhnTYxXsxnfHPSCwUlDxYEyCpaEgxPDUFhYVPEWBrnoNciYQWNtvtGrAywyDpdjuBYWxRDlxTyIZzBYcgUTUAXlFMSGoLwpZJXRydaAbLVMaDrrrnTMauFuuyyUCdJNXKXRjilemkwyuTsnyYErjkgtYX"));
    this->WKcDMOVJ(-166205632, false, 452117.6313796652);
    this->MFNqxNCqskYHblM(937294.4639459121, true, string("KofWxWsOnmZsCKMduc"), -610974.7680550674, 1168377616);
    this->KNZCmV(718596433, 227077.20701247166, true, true);
    this->UKORXEFM(-239191193);
    this->cjibGbmwnfrZM(-247123.9535596999, -545402.2636967436);
    this->uXyTGoRzYlw(string("bMJBZYWjUrtzUnxKvvGXjRNRNELdQhyMtqPJxhqURaOpTUwbXJruilErWaEwBpUKgOhjwkvLBQiAnHcGHyLvWbqnhfWJbCiaDdVMMspSutPsFtluKajjMKzRgEtKm"), string("ZAMwxhiTPlWkQpThIERBEGPQTRSMyviiijJXJzLzuoxcbkLRKVTkHyAQqALZgeYMXbwtzWKKEYbWKjhkLdrpWSRjybvIvcpRbeloEsFgzsSQoqWnPLtqfjLpDzYmfzdmvAUUilqxGrryFBqxYHuZAZRcosvbMCGSIyPBhDKoeadSeLjXTGZLylgtZdWNHutKqFbFamPhjwQlQUVQrbimdtLZraOCJeoFddi"), false);
    this->xfrkOB();
    this->uAQIsCwFeZBSO(1837510022, -204694.9556384168, 731342280, string("PTqMdOnmHfjsCrkAyitBBfCRQrvzaKydEkCThAEbcxcykiBMhBTkuEXUOXwAEjVVrzMLJyIxwNgxGbYpSufkaUSQZJXnJExtTqZaBUvsVriJWaRMbtxDnONwtmFhxhxDgeXTKHOvqRPciZvEwlZXQbOEnNxcNQFGxKwpyeeTgarrORNkvJOTtauWmjTnqIPPXcssIxXDSjvsAbREuFJNiXWtKwmadYLJehScFpFPOewrnyJeVQuyXqZjZIeQY"), 542547.0513448076);
    this->KjYHQHYNiF(-1670688439, -688804.1931171814, string("inrJYSTBKMGcKradOrSUgXwfDFosOVhSYdmNjeaWiTaSPyqktdpdNsicKTBcpoifQeQqFIbylWtkkkEOf"), true, 199464.96907268165);
    this->HzUPRgkIbXwRetGl(true, 777732.1715485691, string("UsCWcLxFfVorgLWGyJwZDbzklgfxIsBrFWFeCoBBDvYkSKdFlmGRINETslGHcFchQLYmuydc"), string("BDMACBNhrcDuToZpVLjjxyeTsCYggQRcgtFmnQtkBGBvIRlXKWDFEEYUeBsvARNdGpbemXbUqZoMExQTIZEVEBgYMkuFiDCNqVvdJYDIhnVgjtVRPPRgwQwcRXHEMkYFxVCxNcrcHwZZBpHxgu"), true);
    this->VFNTCIRTHN();
    this->MItWpO(string("hpNbcSxMutHfxvOqDytGkhVqlNoJQuboHKzHwJTeYtVVQMhaFAvXARSVtBcFfZgtuPcaBnwTmRgSEljNmlWyiEeaOgzmLYwtCzyDBGpdvOgXUwLlQkmUohHMZyNKrtmlyGZQXakvuHraYCGiGcLZBgMeALWW"), string("bviVqclhKOkZrntrOyFKRwUjVQDpNhNxXcrwYnasxOUKrxoahuOCAEENCmVipaIVyErJczjOpLryDfmjpAAXbrllzMnYBuRXcYBXxRqrLhelOLytyTSjirBeHyuZqHkVpMAeJsQQvBoUyNmcYSquiplAXEhzwqMsydGQjUAm"));
    this->DXEfaguBxCCsqDl();
    this->LFwgoOaEOKAQAaaL(-312931.40774018376, true, 1149633407, -2061006917);
    this->bCAnO(true, false);
    this->eqBepwDYjATdlZ(783698.8347889582);
    this->UWSDeTWAG();
    this->LYnZGdHnUCcux();
    this->udvPKnQbzKYTwaZg(true, string("kAzYfFFZrULYqdHbEgqVWFsCvtkhRumdoKVZjgRiHhjgqYeuZJQMqczDTyQUrjouOINrnJWsaalCpSnCvsuuTkwaaOjJlWUTPwvUJFLBnxrR"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GsQvPx
{
public:
    int eIgsdRKEQtv;
    bool gqVpuHHHglhjpEoT;
    string nARrlO;
    string LNMSMoHBRLibpWPV;
    double YLMbXlaKSU;
    int MVBPqvOk;

    GsQvPx();
    string yKwNW(int DJYqWSuaGkz, int dgzBU, double vIrFYV, bool VxlerbMJoWbSp);
    double kPZoyVxgsPcAc(int dwcndgp, bool FcqCNKcmqQLBqu, bool tncPFlmXTtGUeA);
protected:
    bool iFrqtOgRlOWwZrW;
    double gABxsE;
    bool CmzJgSoScSjDsaJ;
    string FEgaaVmBIdbQb;

    void wFctfcWy(double NKhwHr, bool hSCGCHJk, bool cQNLMxTLqjNTwWFx);
    int TitVWUSebBCA();
    string JDTdRKQdDloBk(bool soECUarGJQdiolLG, bool FuQvfaYweaYZUC);
    bool QsKdtSsjUM(int reQeP, double KdmdnxpbWok, double kzHOwTHaoemqIslR, int FPayCGXOUJ, bool IqqTBxwevboLoCT);
    void naUfzzkOSSuTT();
    int bdplzvtR();
    void yHtHkLbCY(double ahksyVZo, string KyNbpRjcDhpS);
    double tCIDLKDPiy();
private:
    int axlrDK;
    double jwBQmkFEgJGIDUDF;
    bool SArsTIAuamIxcV;
    double TBVnFXTSKnGesL;
    int vuZLxoaCDp;

    int cFdaaOYeJIuXJq(double zmMUvOpvnmSGgu);
    int ohdnmLpswrpz(int DFcovOFYGGJ);
};

string GsQvPx::yKwNW(int DJYqWSuaGkz, int dgzBU, double vIrFYV, bool VxlerbMJoWbSp)
{
    int YIpvh = -969435431;
    int GaVIwBEuyXYp = 1949331582;

    for (int ZqyNnUxgZKNS = 1423855280; ZqyNnUxgZKNS > 0; ZqyNnUxgZKNS--) {
        VxlerbMJoWbSp = VxlerbMJoWbSp;
        GaVIwBEuyXYp += YIpvh;
        vIrFYV *= vIrFYV;
    }

    return string("ryCsLywDkrWTTKYQncYASlteYXoUztWJFnqBycjqTYVaZsQGqiQASwoTBfaycovZJOLVKAeEdIhNYJPbsAoiJJmDeIKBYrEknNmDnmjQctWTVOcPSOXOrydSSeuPzVkthGvKztfqeRlfyvdSmTtGfoJvkVuUYZYTRXbiqcZOwzhsaBOZvNYpnvRMaFNwthVOCUFxrXhIsF");
}

double GsQvPx::kPZoyVxgsPcAc(int dwcndgp, bool FcqCNKcmqQLBqu, bool tncPFlmXTtGUeA)
{
    bool jxJsUXJfqKkSWd = true;
    int UsYQUb = 108834300;
    int RsIUYAJEYy = 638820041;
    string XKWHdpwG = string("xMsYuAGJNHRpKwHkLVeRXzUEfmausyrMhmguJnPBOiEYnPRagbCzLdLNjuksIpRQratdwReMrycpiLfgxlgKbXZniOdlPiSNRbspZeUNZUcOWuoVoGNpcKsHhwRhquuAjmrUnOraCrUMptm");
    int EQOtYxccOhKCs = -9119374;
    int ZAFRiFcueKXEp = 594923371;
    bool BKHZdNFVTtZ = false;
    double JkJxDHVvD = 996349.8447348189;

    for (int OeTGZ = 1372983889; OeTGZ > 0; OeTGZ--) {
        JkJxDHVvD += JkJxDHVvD;
    }

    for (int KOvBnOo = 544004551; KOvBnOo > 0; KOvBnOo--) {
        XKWHdpwG = XKWHdpwG;
        tncPFlmXTtGUeA = ! tncPFlmXTtGUeA;
        RsIUYAJEYy = RsIUYAJEYy;
        FcqCNKcmqQLBqu = tncPFlmXTtGUeA;
        ZAFRiFcueKXEp -= EQOtYxccOhKCs;
    }

    for (int AcvclKZURWfJ = 713609185; AcvclKZURWfJ > 0; AcvclKZURWfJ--) {
        FcqCNKcmqQLBqu = FcqCNKcmqQLBqu;
        dwcndgp /= ZAFRiFcueKXEp;
    }

    if (jxJsUXJfqKkSWd == false) {
        for (int bMCqVsJ = 975335697; bMCqVsJ > 0; bMCqVsJ--) {
            jxJsUXJfqKkSWd = tncPFlmXTtGUeA;
            FcqCNKcmqQLBqu = ! tncPFlmXTtGUeA;
            ZAFRiFcueKXEp += EQOtYxccOhKCs;
            UsYQUb -= dwcndgp;
            UsYQUb *= RsIUYAJEYy;
            EQOtYxccOhKCs *= RsIUYAJEYy;
        }
    }

    return JkJxDHVvD;
}

void GsQvPx::wFctfcWy(double NKhwHr, bool hSCGCHJk, bool cQNLMxTLqjNTwWFx)
{
    int ZVmie = 848855728;
    double YoZSKFf = -386879.34879672964;
    double fUfqcyYU = -11225.564738867191;
    double wpqebzzoS = -908096.3293284192;
    int CdIwAzBchSGHmA = 492828793;

    for (int qtYFqRE = 1480749878; qtYFqRE > 0; qtYFqRE--) {
        YoZSKFf -= fUfqcyYU;
        wpqebzzoS = wpqebzzoS;
        ZVmie = ZVmie;
        ZVmie = CdIwAzBchSGHmA;
        cQNLMxTLqjNTwWFx = ! hSCGCHJk;
        NKhwHr /= YoZSKFf;
    }
}

int GsQvPx::TitVWUSebBCA()
{
    string KCloEDzUT = string("SQedHDDVcylUBgRVHnKyiUUzzxrXTREgFGyPOOHIRwswCxTrxsDsCJccEruVsLCHOXyKJEltwRXlyBDCrkLxzKBSAgiFWUoBiAdWzdxzBoKIXTleGtHUmXyVxqplXXqwDiWpBhrqJqfAiW");
    int SazwZuxDC = -1971031489;
    double grEufoZCX = -133126.9229500136;
    string IFRaRfhyzqIu = string("xAMKlvntXbrSRwtdCZZqvIyfETNFdJtfvyffJVoCfHnkiZMBSDGMhFwQfpXCiqKfXLSnmpvIguPMxwKizpMoRVtDWQbuWYTskdXdBCddKEonZUhxxxdrpDbIyHsaZbFYgNGmvucCoaiN");
    bool EaePusQfuKcJi = false;
    bool nevaKnyTvT = true;

    if (IFRaRfhyzqIu == string("xAMKlvntXbrSRwtdCZZqvIyfETNFdJtfvyffJVoCfHnkiZMBSDGMhFwQfpXCiqKfXLSnmpvIguPMxwKizpMoRVtDWQbuWYTskdXdBCddKEonZUhxxxdrpDbIyHsaZbFYgNGmvucCoaiN")) {
        for (int WWQKRCuGQZf = 1261085065; WWQKRCuGQZf > 0; WWQKRCuGQZf--) {
            KCloEDzUT = IFRaRfhyzqIu;
            nevaKnyTvT = ! nevaKnyTvT;
            grEufoZCX = grEufoZCX;
        }
    }

    for (int bwBsbQ = 630845992; bwBsbQ > 0; bwBsbQ--) {
        KCloEDzUT = IFRaRfhyzqIu;
    }

    for (int nyvvZXHHj = 4869436; nyvvZXHHj > 0; nyvvZXHHj--) {
        KCloEDzUT += IFRaRfhyzqIu;
        KCloEDzUT += IFRaRfhyzqIu;
    }

    if (nevaKnyTvT != false) {
        for (int osRcWxjdYe = 41586346; osRcWxjdYe > 0; osRcWxjdYe--) {
            IFRaRfhyzqIu = KCloEDzUT;
        }
    }

    for (int pZuvfmGFxfkxR = 1299098798; pZuvfmGFxfkxR > 0; pZuvfmGFxfkxR--) {
        KCloEDzUT += IFRaRfhyzqIu;
        KCloEDzUT += KCloEDzUT;
    }

    if (nevaKnyTvT == false) {
        for (int ysSUnKAEyk = 1394673993; ysSUnKAEyk > 0; ysSUnKAEyk--) {
            IFRaRfhyzqIu = KCloEDzUT;
            EaePusQfuKcJi = ! nevaKnyTvT;
        }
    }

    for (int RwhGFZgwcVng = 1451697614; RwhGFZgwcVng > 0; RwhGFZgwcVng--) {
        nevaKnyTvT = EaePusQfuKcJi;
        KCloEDzUT = IFRaRfhyzqIu;
    }

    return SazwZuxDC;
}

string GsQvPx::JDTdRKQdDloBk(bool soECUarGJQdiolLG, bool FuQvfaYweaYZUC)
{
    string vBPKLzNJDSNmyIl = string("RugbFewTsHwLWPQyzyXVJpeqYPzKwJRXYXmhkKWDfwPwyADWHwNenGFqeUSsdJKSBVKNNKoSRLyKBuMbGAHvZiAoyBUHpVoNJEOUDwCsSACkaxuhwJyYIqlUDFpbUEriOoLzPyQiWyNkorymWBEITeJSsfGFfNEozVgwgZpHSaLDaKnhWhGwkDrIrOfPtBcDBPfApxORcLZUIgwrtCFfDCfZleVXTHjPWqYFaxsRGXyPOqaEwR");
    bool YwbEqtjk = true;
    double VuXtq = 510657.79850936664;
    double QIwztXRb = 628795.9777180859;
    bool BfDwBeiiFJ = false;
    int kXcNd = -777528882;

    if (soECUarGJQdiolLG == false) {
        for (int GHItiprhtJpQGB = 1801184154; GHItiprhtJpQGB > 0; GHItiprhtJpQGB--) {
            FuQvfaYweaYZUC = ! soECUarGJQdiolLG;
            BfDwBeiiFJ = soECUarGJQdiolLG;
            FuQvfaYweaYZUC = ! FuQvfaYweaYZUC;
        }
    }

    if (soECUarGJQdiolLG != false) {
        for (int HfwJoadFEoIWU = 410019354; HfwJoadFEoIWU > 0; HfwJoadFEoIWU--) {
            soECUarGJQdiolLG = FuQvfaYweaYZUC;
        }
    }

    return vBPKLzNJDSNmyIl;
}

bool GsQvPx::QsKdtSsjUM(int reQeP, double KdmdnxpbWok, double kzHOwTHaoemqIslR, int FPayCGXOUJ, bool IqqTBxwevboLoCT)
{
    string dKiJG = string("YWKhWpYUKGbhstOCoCKVKpNQdClxNAzBcOBUpldcXrMveIcNoljaLDuWttfDlUvflF");
    int GKoAXBwukuMKQXS = -597427464;
    bool zwkjtaWF = true;
    int BgaaSzs = -1838399081;
    int MGbvN = -842389434;
    double rIPkreSOAYp = 892711.5291796854;

    for (int GMjEDXnOzoD = 1619700411; GMjEDXnOzoD > 0; GMjEDXnOzoD--) {
        FPayCGXOUJ += BgaaSzs;
        MGbvN += GKoAXBwukuMKQXS;
    }

    for (int qyoFF = 1716020593; qyoFF > 0; qyoFF--) {
        continue;
    }

    for (int rizabYOqYoJE = 735825272; rizabYOqYoJE > 0; rizabYOqYoJE--) {
        IqqTBxwevboLoCT = ! zwkjtaWF;
        GKoAXBwukuMKQXS += FPayCGXOUJ;
        FPayCGXOUJ = GKoAXBwukuMKQXS;
        FPayCGXOUJ /= GKoAXBwukuMKQXS;
        IqqTBxwevboLoCT = zwkjtaWF;
    }

    if (kzHOwTHaoemqIslR != 262647.6833152305) {
        for (int YBLKUf = 1077603427; YBLKUf > 0; YBLKUf--) {
            kzHOwTHaoemqIslR -= KdmdnxpbWok;
        }
    }

    return zwkjtaWF;
}

void GsQvPx::naUfzzkOSSuTT()
{
    double gwbSqsR = 966880.476920643;

    if (gwbSqsR >= 966880.476920643) {
        for (int bYiDnVzizhy = 1250546539; bYiDnVzizhy > 0; bYiDnVzizhy--) {
            gwbSqsR *= gwbSqsR;
            gwbSqsR = gwbSqsR;
            gwbSqsR = gwbSqsR;
            gwbSqsR -= gwbSqsR;
            gwbSqsR *= gwbSqsR;
            gwbSqsR -= gwbSqsR;
            gwbSqsR /= gwbSqsR;
        }
    }

    if (gwbSqsR <= 966880.476920643) {
        for (int DWbFt = 1337419828; DWbFt > 0; DWbFt--) {
            gwbSqsR /= gwbSqsR;
            gwbSqsR += gwbSqsR;
            gwbSqsR += gwbSqsR;
            gwbSqsR += gwbSqsR;
            gwbSqsR /= gwbSqsR;
            gwbSqsR /= gwbSqsR;
            gwbSqsR /= gwbSqsR;
            gwbSqsR = gwbSqsR;
        }
    }

    if (gwbSqsR <= 966880.476920643) {
        for (int cNnwBzDk = 464199751; cNnwBzDk > 0; cNnwBzDk--) {
            gwbSqsR /= gwbSqsR;
            gwbSqsR = gwbSqsR;
        }
    }

    if (gwbSqsR > 966880.476920643) {
        for (int NgtRzNAzf = 679998859; NgtRzNAzf > 0; NgtRzNAzf--) {
            gwbSqsR /= gwbSqsR;
            gwbSqsR *= gwbSqsR;
            gwbSqsR *= gwbSqsR;
            gwbSqsR -= gwbSqsR;
            gwbSqsR *= gwbSqsR;
            gwbSqsR += gwbSqsR;
            gwbSqsR -= gwbSqsR;
            gwbSqsR /= gwbSqsR;
            gwbSqsR = gwbSqsR;
        }
    }

    if (gwbSqsR >= 966880.476920643) {
        for (int VNGShiSlrPFnd = 131405438; VNGShiSlrPFnd > 0; VNGShiSlrPFnd--) {
            gwbSqsR /= gwbSqsR;
            gwbSqsR -= gwbSqsR;
        }
    }

    if (gwbSqsR > 966880.476920643) {
        for (int nsBxmB = 1683397573; nsBxmB > 0; nsBxmB--) {
            gwbSqsR = gwbSqsR;
            gwbSqsR -= gwbSqsR;
            gwbSqsR += gwbSqsR;
            gwbSqsR -= gwbSqsR;
            gwbSqsR = gwbSqsR;
            gwbSqsR *= gwbSqsR;
            gwbSqsR /= gwbSqsR;
            gwbSqsR /= gwbSqsR;
        }
    }
}

int GsQvPx::bdplzvtR()
{
    string crxMXQjjlK = string("cMvnRhmLfAXHQyCjpzffxYuDWIMIcidiwWLznsVPthscKVOdCFvJNVQIivxCBTVYACJUxIGXKoLxIaygVMj");
    int mktyspXl = 1778907984;
    bool vbwDvPbhoU = true;
    bool YAKuQJOrJiVjNR = true;
    double ykBdawnVkHe = -668956.7830353974;
    int VmGeEmoWOnALw = 773385345;
    double CqPAamXfbPLKnB = -821617.2120755295;
    bool VHUbXao = false;

    for (int wRTgfxjsY = 421008308; wRTgfxjsY > 0; wRTgfxjsY--) {
        CqPAamXfbPLKnB *= ykBdawnVkHe;
        vbwDvPbhoU = YAKuQJOrJiVjNR;
        VmGeEmoWOnALw += mktyspXl;
    }

    if (mktyspXl != 773385345) {
        for (int UWcZziLpNllHOW = 446267819; UWcZziLpNllHOW > 0; UWcZziLpNllHOW--) {
            VHUbXao = vbwDvPbhoU;
            VHUbXao = VHUbXao;
        }
    }

    return VmGeEmoWOnALw;
}

void GsQvPx::yHtHkLbCY(double ahksyVZo, string KyNbpRjcDhpS)
{
    double sYQCRJWpsQE = -650952.835248492;
    int bGZvkOIIYJEeuX = 1865144624;
    double jqiqcKB = -144537.98257659978;
    string iGdLZIMNtSBOE = string("SWwtYvjcBjhlHcmfexzVJfsgGHqDXPuHaXwpyJMFKHwFUZeJKhOZKTArlgjFuJITzmCZIWRJBeeRkIikkUwtwFBVPaQpLcYITVMSzGmXJMhEuXykeUfuWRnBOPztJemoTbxsGcJBzWRUIqWyjnjCxYbiLLWqoXCksGdqKiypO");
    int ZttvtwuyirSOu = -1171930268;
    bool zHWVSo = true;
    string pkxgWK = string("FzBMxLiaOaMTRJoUqCdSwzKyCUpThHYFzSpwmUpacNjSGqDJcCtkEZJsGYclmVtHTEqeBYpCzLrxmbgOymRVcAMsCOoplxmIiFIFkqGaVFgsxVUavdCNvFhCYnotXWgUoXOnpPcqURTlHRGCipPNseYMBiBbnKkkszYsL");
    int ZpDuCWJkUYsY = 1657071559;
    int JrOyvatSEFgt = -2021820766;
}

double GsQvPx::tCIDLKDPiy()
{
    double lCwzgCAbsW = -74053.31324941436;
    string EgTXHxPqCPWd = string("DFgQAivVOvIvFLlvMGYmhUAfaMApZyZKhQqlafaHJAgSHDuOIpKQrEPpipPLRROChyrDVzZHpPCYZpTRXQqIrzTDSzQpZDYdKMoWmmNTzfaMUEAdKheJZei");
    string oaFQpWXTJ = string("VpzTEWjIMHIweqZBqeMHVYWgHimbDEKwtuMvKsJDEWyPuGdbdszYrpgzoSbfFhEjcqLyOPOYcuVXoSmxQAtkdqoBHLwiSYIpoJxTdrfxNuGJacbCBcNzEVkHgNJfFXsguILFbMznOdDMvgTTOYjpHakYdDrI");
    bool fzYiPgaakTEOkdZq = true;
    bool brFGgkMoxkVE = true;
    int FUWfPnTqbtTu = -879985977;
    bool oKwjXJAsqD = true;
    double wybnjzqgLgZT = 727607.8562715081;
    double WAwztU = 589456.6915564949;
    int VvSLNKDpGSEsqLb = 1049200789;

    for (int cADeXTbzkkSRlR = 1397076272; cADeXTbzkkSRlR > 0; cADeXTbzkkSRlR--) {
        oaFQpWXTJ = oaFQpWXTJ;
    }

    for (int cOnilCCLF = 80566670; cOnilCCLF > 0; cOnilCCLF--) {
        wybnjzqgLgZT *= lCwzgCAbsW;
    }

    for (int mxBweNqfCO = 1712138237; mxBweNqfCO > 0; mxBweNqfCO--) {
        VvSLNKDpGSEsqLb -= FUWfPnTqbtTu;
        WAwztU += wybnjzqgLgZT;
    }

    return WAwztU;
}

int GsQvPx::cFdaaOYeJIuXJq(double zmMUvOpvnmSGgu)
{
    double vRLylNNOLmGMTM = 899667.6510071601;
    double AQkuRHewzE = 299146.27631197707;
    int qtOTataunNi = 955614567;
    int tDFJtYznVQD = 353870480;
    int VVgSLsUXIdKTtp = -1125357910;
    double joxMOqeIeRSFO = 399508.37840607413;

    for (int cpZbrziqB = 317517071; cpZbrziqB > 0; cpZbrziqB--) {
        joxMOqeIeRSFO /= AQkuRHewzE;
        zmMUvOpvnmSGgu -= joxMOqeIeRSFO;
        AQkuRHewzE = zmMUvOpvnmSGgu;
        zmMUvOpvnmSGgu += joxMOqeIeRSFO;
    }

    if (AQkuRHewzE < 945345.8434353688) {
        for (int obSFdRraEAfgso = 2032199703; obSFdRraEAfgso > 0; obSFdRraEAfgso--) {
            zmMUvOpvnmSGgu -= AQkuRHewzE;
            tDFJtYznVQD = tDFJtYznVQD;
            qtOTataunNi -= tDFJtYznVQD;
            joxMOqeIeRSFO = joxMOqeIeRSFO;
            AQkuRHewzE *= vRLylNNOLmGMTM;
        }
    }

    if (joxMOqeIeRSFO <= 899667.6510071601) {
        for (int YDLPgxDuYXs = 871329480; YDLPgxDuYXs > 0; YDLPgxDuYXs--) {
            zmMUvOpvnmSGgu -= vRLylNNOLmGMTM;
            zmMUvOpvnmSGgu -= vRLylNNOLmGMTM;
            tDFJtYznVQD = tDFJtYznVQD;
            vRLylNNOLmGMTM /= zmMUvOpvnmSGgu;
        }
    }

    return VVgSLsUXIdKTtp;
}

int GsQvPx::ohdnmLpswrpz(int DFcovOFYGGJ)
{
    double OLgJnpUFECExFFz = 262385.1379613884;
    double eqBlYMTbak = -312651.66524090036;
    int wdjzRGXwkdXJrsp = -1989857534;
    double mJUZsgrz = 669874.7873052874;
    bool BEkjcORzMy = true;
    int ObjZBAy = -682400522;
    double CrDekjZdVMPz = -1041042.7759410075;

    for (int WTlMZafa = 448833526; WTlMZafa > 0; WTlMZafa--) {
        mJUZsgrz *= mJUZsgrz;
    }

    if (DFcovOFYGGJ > -682400522) {
        for (int wbgVqxdhptQTtHc = 770388906; wbgVqxdhptQTtHc > 0; wbgVqxdhptQTtHc--) {
            continue;
        }
    }

    return ObjZBAy;
}

GsQvPx::GsQvPx()
{
    this->yKwNW(1719377140, 1104142304, 880821.4042103043, true);
    this->kPZoyVxgsPcAc(-1519520642, true, false);
    this->wFctfcWy(544647.454570728, true, false);
    this->TitVWUSebBCA();
    this->JDTdRKQdDloBk(false, true);
    this->QsKdtSsjUM(-78071818, 262647.6833152305, 868659.2943474822, 1301276419, false);
    this->naUfzzkOSSuTT();
    this->bdplzvtR();
    this->yHtHkLbCY(478195.6845714816, string("DscPIKyayVEJZemhsfSyzdmmXAAEthIRiglSQrfAzjUbsXLkDlLBBJgSbFwoluRzfzWOOURjVWuzqqnKYlxIYkWfIifmBrwubpGSusuGVrCPvUG"));
    this->tCIDLKDPiy();
    this->cFdaaOYeJIuXJq(945345.8434353688);
    this->ohdnmLpswrpz(-890327327);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lokEmQuQ
{
public:
    bool IZkMuSp;
    bool pKJxRQVvhglzmuc;

    lokEmQuQ();
protected:
    string OgSxKOwKWi;
    string lWjisLPbNoZKHGI;
    double czcbqKSBXsEIGbi;
    int CMtOyS;
    double mBnqgL;

    string brBkiE(bool hGiKKErPM, bool zgcVhl, string fFnaFEAPkKkEDffW);
    double ywPaBoQRPVr(int smIfJbIpqcSD);
    int qzMUCoBbStAOHQ(int oosHqUjetX, int NBkDEsPt, int zOLsCO);
    bool gkBSPX();
    bool ycdPkvphGlaeX(bool rSpgVhAZaA, int AtLUhuUrUhposgdg);
    void zvOZMSboXZ(double oFCLaOZGLghu);
    int wgvOada(bool rqUKIohokcnbOIsk, bool ONanoOwvTvnHky, double aOGOMHQaJfTGlCbE, int kbZvZQv, string IBPmeHlTubrMgtID);
    string RjzNmjwVYYur(string UbKPJLvxKfpOxi, int ltfxjrv, double csbbUUbxLF);
private:
    int XRgXFRZfQrrqwRZE;
    int pRqKfFTQ;
    double OmvuyUXlOEqw;
    int zLKGUpxPiwXMK;
    double FzKVTWNc;

    double BBgNRmCzrCT(string rNmNPQVSWMvnYFkg, double sWONNgeDNcz, bool oQrfCRvBuA);
};

string lokEmQuQ::brBkiE(bool hGiKKErPM, bool zgcVhl, string fFnaFEAPkKkEDffW)
{
    double CAjjNzILN = 778861.6068171925;
    bool lGBjWkdK = true;

    for (int egrqNlhjStpRBM = 1783549760; egrqNlhjStpRBM > 0; egrqNlhjStpRBM--) {
        lGBjWkdK = lGBjWkdK;
        lGBjWkdK = ! lGBjWkdK;
        CAjjNzILN += CAjjNzILN;
    }

    for (int qLhNyaRzWc = 1707863326; qLhNyaRzWc > 0; qLhNyaRzWc--) {
        lGBjWkdK = zgcVhl;
        CAjjNzILN /= CAjjNzILN;
    }

    for (int PXfwn = 252914971; PXfwn > 0; PXfwn--) {
        hGiKKErPM = zgcVhl;
    }

    return fFnaFEAPkKkEDffW;
}

double lokEmQuQ::ywPaBoQRPVr(int smIfJbIpqcSD)
{
    string IFUBjPcnLhTZZF = string("iudjrstaAbHAREmxTvCkCCjPePjYPUjihETXbWBfRywqDGuQSvIbJfHXuMMzIqpZHdcFMegeNNPMUnhnvBmTFxArjlfvVhYztZYHTbGzMybzXxLOWWNHzWsZborZHixWBe");
    int DDiYyqpMolF = 1710074941;
    double TCdKxWFpXXr = -1028250.7666548069;
    string zedQxNvmK = string("EMcRohzkfbkGDBCOAzKHmKAVMRquFumysNJlNJXJCsSZCtenKVHFNNCkUDsORWJYUIEjUxvHjIelhCgFTcajpoVwRKmlbnYVUFFOztJgejSZVQXjNbLlgqaUfMMZixeRTFigZUTQXiDYqgslytVRgBTeLszvuKJUwkBGGhhqtYNRRixFaLjjmgvSpPAAbnLZJxUgLK");

    for (int uOfJREcishkri = 1961694338; uOfJREcishkri > 0; uOfJREcishkri--) {
        smIfJbIpqcSD *= smIfJbIpqcSD;
    }

    if (DDiYyqpMolF > 1710074941) {
        for (int fMVFrScykneVV = 2027075569; fMVFrScykneVV > 0; fMVFrScykneVV--) {
            IFUBjPcnLhTZZF += IFUBjPcnLhTZZF;
        }
    }

    if (TCdKxWFpXXr >= -1028250.7666548069) {
        for (int rikLHwqJkv = 1664807099; rikLHwqJkv > 0; rikLHwqJkv--) {
            smIfJbIpqcSD = DDiYyqpMolF;
        }
    }

    for (int EcxANzAEMfHJP = 1101348695; EcxANzAEMfHJP > 0; EcxANzAEMfHJP--) {
        continue;
    }

    return TCdKxWFpXXr;
}

int lokEmQuQ::qzMUCoBbStAOHQ(int oosHqUjetX, int NBkDEsPt, int zOLsCO)
{
    int QqliGFHbPXrzs = 229682840;
    string trcls = string("KtYJlyWXdCSVqewBefvWsKjiqgVdQfCpmlBkHDDEXZNSglxUwelpdYBJGjEcFwsGBow");
    string eENPYhm = string("LGBxnExKWRgvhqiFECMkuUmKfEnkAJgvGizFIOyZpJIVDUChNCmPZBNEmjMVf");
    double WRmTdLeleC = -460549.233009742;
    string xEKpIvH = string("ApTiBTgffGZIRVFFNcUprdVtoSVWlzkBxWpsGjZpWJOtPgOXVqUJYlwUJqafkGnGjDKABwDnGqIHzWiaYHgTyMlGLCRwDdDiBveDOldosFongYVVZtaRGBRMlYQuFtqsAcwkuKjKLVrtStaWPjVBMLuFrDsEYFJpzTwHVFTuIUPKKXaKoOCwcUOUMnoQesQXlmgbT");

    if (eENPYhm <= string("KtYJlyWXdCSVqewBefvWsKjiqgVdQfCpmlBkHDDEXZNSglxUwelpdYBJGjEcFwsGBow")) {
        for (int ENloRiT = 2078134143; ENloRiT > 0; ENloRiT--) {
            zOLsCO -= NBkDEsPt;
            QqliGFHbPXrzs *= oosHqUjetX;
        }
    }

    for (int UwvfeKnMAqC = 511210582; UwvfeKnMAqC > 0; UwvfeKnMAqC--) {
        trcls += xEKpIvH;
        QqliGFHbPXrzs /= QqliGFHbPXrzs;
    }

    for (int ULwNNYKX = 1403047573; ULwNNYKX > 0; ULwNNYKX--) {
        trcls = trcls;
        NBkDEsPt /= oosHqUjetX;
    }

    return QqliGFHbPXrzs;
}

bool lokEmQuQ::gkBSPX()
{
    bool vFHfRGTLdiunkYw = true;

    if (vFHfRGTLdiunkYw == true) {
        for (int KfjxuuafmxV = 839143310; KfjxuuafmxV > 0; KfjxuuafmxV--) {
            vFHfRGTLdiunkYw = vFHfRGTLdiunkYw;
            vFHfRGTLdiunkYw = vFHfRGTLdiunkYw;
            vFHfRGTLdiunkYw = ! vFHfRGTLdiunkYw;
            vFHfRGTLdiunkYw = vFHfRGTLdiunkYw;
            vFHfRGTLdiunkYw = vFHfRGTLdiunkYw;
            vFHfRGTLdiunkYw = ! vFHfRGTLdiunkYw;
            vFHfRGTLdiunkYw = vFHfRGTLdiunkYw;
        }
    }

    return vFHfRGTLdiunkYw;
}

bool lokEmQuQ::ycdPkvphGlaeX(bool rSpgVhAZaA, int AtLUhuUrUhposgdg)
{
    string cYZWDLMAd = string("HtYqniobQRNraYJXJRCYTdUCTvxIbUrVGgjekietUjQFUINWWFhogNYXqCugsVViMsyZVbBHLRrQBCNwniJUPfIchAPPrJoFwBhAUqWhggHNPidCMulzSTwViSQzsPYMlOjjetHTQImzyttgYCdedFoNJqqDnqg");
    bool HRDOGqmWbjM = true;
    bool knPRcJ = true;
    string VNxzZKpKSMHCrGg = string("NNtnpoasDykvRLYLPIGvwBBjjOTOcatKKCbvZZixisfKYShnVHErJbhADPHCUPpSVDnuOuYicfzFqeMhvYkQVXsrBlEMWvLmvzarKafItPOdCUHIsyjDiUMlKmfOURzuUIDioFxfYYphIzzGLFpxjzrRHDodSSxMekwBwhUcLMGUocy");
    double NKWrn = 856730.8668471114;
    double miBUwo = -669827.2639539243;

    return knPRcJ;
}

void lokEmQuQ::zvOZMSboXZ(double oFCLaOZGLghu)
{
    double RneeLw = -764902.9695448728;
    bool PGpKkddOcItZWxKu = true;
    bool htcKh = true;
    int YklhABJr = 847500151;
    int IVumoPiWKttbr = -786774940;
    double UxLEOFsRpnGPUFu = -160756.1102574179;

    for (int KDzYk = 1505042843; KDzYk > 0; KDzYk--) {
        IVumoPiWKttbr /= IVumoPiWKttbr;
        PGpKkddOcItZWxKu = PGpKkddOcItZWxKu;
        RneeLw /= RneeLw;
        YklhABJr += IVumoPiWKttbr;
    }

    if (IVumoPiWKttbr > -786774940) {
        for (int TxmRArutkxLBc = 76452546; TxmRArutkxLBc > 0; TxmRArutkxLBc--) {
            oFCLaOZGLghu += oFCLaOZGLghu;
            htcKh = ! htcKh;
            UxLEOFsRpnGPUFu = RneeLw;
        }
    }

    if (YklhABJr > -786774940) {
        for (int pjDvxDPZzpUH = 241839692; pjDvxDPZzpUH > 0; pjDvxDPZzpUH--) {
            oFCLaOZGLghu = UxLEOFsRpnGPUFu;
            IVumoPiWKttbr /= IVumoPiWKttbr;
        }
    }

    if (YklhABJr > 847500151) {
        for (int CJawKku = 384127848; CJawKku > 0; CJawKku--) {
            YklhABJr *= IVumoPiWKttbr;
            PGpKkddOcItZWxKu = htcKh;
            UxLEOFsRpnGPUFu /= UxLEOFsRpnGPUFu;
        }
    }
}

int lokEmQuQ::wgvOada(bool rqUKIohokcnbOIsk, bool ONanoOwvTvnHky, double aOGOMHQaJfTGlCbE, int kbZvZQv, string IBPmeHlTubrMgtID)
{
    bool lzDjlQZMqmYxfW = false;
    bool HqhOI = true;
    int JmBMGwYmT = -1056277309;
    string DhKyLM = string("OHHmFihDTKmsmrQrzcBRUguLDKcEtILCXxFrkbWDKfAsxVdBEIkJDKZObviqTWlFJBvUsxbiBfphQfOtBQPslVPxiogBEreSmtLtBxLwKhNundyBFAUiTFKRtwbkFEawSJToKpdrxGXSmkdEaKtwBlmdGtypYwDxebAwIgiRhcCTeODdwwGZjtRiUdkxRstiSjAINDqXnrTScmFLCafPKJoCFgJdPzRLtyo");
    string pJOBkfXlHV = string("rITfyiywXraMOhzDdqaUukAgPiYwgDlal");
    int KHFcDugLZWz = -1693485367;
    double ljvOIAPQwKybR = -440862.6288635894;
    bool pPoyg = false;
    string uCXLIjJJbtMXiWb = string("ZCBjniipkTgQlwoEwxjyYxjBfvkaKidwsMEYYNcmRYVIJuZcUAnibRReULuKUFcBqxuNXsoWwQWgmzYadxyJhFmYiLKFPbYnwaTMEHhIwWwlVAMWDapBwzqVIvmGKSETZjOQbChQBPBgAYTKrCchSsAVdZGDP");

    if (HqhOI != false) {
        for (int UVvutenjNoYpBkB = 786668245; UVvutenjNoYpBkB > 0; UVvutenjNoYpBkB--) {
            IBPmeHlTubrMgtID = DhKyLM;
            IBPmeHlTubrMgtID = IBPmeHlTubrMgtID;
            IBPmeHlTubrMgtID += DhKyLM;
            DhKyLM = pJOBkfXlHV;
        }
    }

    return KHFcDugLZWz;
}

string lokEmQuQ::RjzNmjwVYYur(string UbKPJLvxKfpOxi, int ltfxjrv, double csbbUUbxLF)
{
    double aPWhGPqeFivueHgX = -124071.00563996077;
    double OUvnrRTWyMhpaKU = -60142.5720465012;
    int iDrTJjcKoO = 1761758023;

    for (int AMUKwFCSokWcEpdv = 1955523838; AMUKwFCSokWcEpdv > 0; AMUKwFCSokWcEpdv--) {
        ltfxjrv += ltfxjrv;
        csbbUUbxLF /= csbbUUbxLF;
    }

    if (OUvnrRTWyMhpaKU != 150070.35570962037) {
        for (int xFUiFdtlNV = 2129769843; xFUiFdtlNV > 0; xFUiFdtlNV--) {
            csbbUUbxLF -= aPWhGPqeFivueHgX;
            aPWhGPqeFivueHgX = aPWhGPqeFivueHgX;
            ltfxjrv += ltfxjrv;
        }
    }

    return UbKPJLvxKfpOxi;
}

double lokEmQuQ::BBgNRmCzrCT(string rNmNPQVSWMvnYFkg, double sWONNgeDNcz, bool oQrfCRvBuA)
{
    string ljYMYDFU = string("KxHeSYToCFDNqGarsySrBQjMeWFcMJKIzjSClWVLUJWSpkACvkYKDmUbHXTMxTicrkRbjijGTCaylkoUxUPcMRsVbhpGVkYKFHPuHn");
    bool LCSFhDs = false;
    double KRPUzMW = 440566.7931306602;
    double oXEUCQLu = 423280.8091844599;
    string LISmiYmj = string("CYnLjYXaJLSEkmLcJpyxmtVCZnqUoZuVlGlKBDQJxMgaEunLDVWAWPGuWIKXBLLMGHBeiBsLZucgbIBhaPlBsVIhDBwBFghcXbRJmofarnxgOyuJZFgJxIYFHBgJqOEKpLmwYGpjqyiRegIqOiYMujLEDZqsOvPDRawRjbPheiCHVvdJBwXVwyuNvzKYAtiESbONahRRjShWNElsCVqVfrVkHJSgNxODSBPWzjtpojxaaeBksLXJoRXcd");

    for (int nUBsOdjhZJ = 939836340; nUBsOdjhZJ > 0; nUBsOdjhZJ--) {
        LISmiYmj += LISmiYmj;
    }

    for (int VDPViifvolDMt = 150046720; VDPViifvolDMt > 0; VDPViifvolDMt--) {
        continue;
    }

    return oXEUCQLu;
}

lokEmQuQ::lokEmQuQ()
{
    this->brBkiE(false, false, string("YhFLYHLvkUpJRDsnbtPGRxsKzVjNTbwebINtKxTWOuOlLTbOMcwHSbGUjvOyUTTIjpnsLaZSHArMHzXVHgyAJqkgwmHEQDKsbFxErVRcIbWEv"));
    this->ywPaBoQRPVr(2045904168);
    this->qzMUCoBbStAOHQ(-709679409, -805324941, -1518204082);
    this->gkBSPX();
    this->ycdPkvphGlaeX(true, -1106475803);
    this->zvOZMSboXZ(-710120.928801614);
    this->wgvOada(true, false, 39298.17892072937, -540685941, string("zrlPCqCvnjkRXqrldaRYlspuvMMOaZdHdrTHVY"));
    this->RjzNmjwVYYur(string("ZLvVOvrGRdtpKjdCjdbYnkjRTCheeCayXgxBpAVRsAZBhDZBdDeRxHLtsJSATVWqkSfuxuk"), -1082960690, 150070.35570962037);
    this->BBgNRmCzrCT(string("yCfKcXiiwylHMLwoIqECYIkupTsWRznhRHcOxOFAggELewPYVHnEaBeJubYtMWcxAdhVuxlihJnsUEykTgbImjfurkuNiWxncBsSEvgYvCUNZsXfSDDQWVEbqFLirYZMRfQjQzMxpfLNExjjSNevgrbsIPHtjhaakoBWwQJHlNFRtUTdtHrgsPGrMQNATfLnNBOvrypiVDQKuTpijPpSDfHIiMXQItSeYei"), 255817.51482050013, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class glxLaSC
{
public:
    double LBYVu;

    glxLaSC();
    double tzOnkLEY();
protected:
    string ashLpyFHCDgjOCPl;
    double BeRpFHiAtQrJ;

    int hvGCt(double QntnogNseGVJz, double bbDOvOw, string JysISIBRSlJSMV, bool goZRXXE);
    double iVwLxgh(double FlGMU, bool HLiPKEDnTq, int CdGQdFogq);
    bool RdVHdEPSnIS(int XKuqt, bool lzrWUhCbanxaYHP, double omRJWUrMyUV, double nGpPOrG, double cmmVexWMgbbNzogA);
    int RbqQvuLvfhSsiZjI(string IptuE, bool LLmLLNCbhwMKiu, int pppuqR);
private:
    bool ZQZrhHbcTjD;
    bool xelnGdLYsmFhQvz;
    bool xMNRsd;
    double FSMOuUgCs;

    string IdHdYD(bool czKleUsDFCz, string YZfCEMvDHnXfW, string lKyfErxdFiux);
};

double glxLaSC::tzOnkLEY()
{
    int wYnwqk = -1287839309;

    if (wYnwqk >= -1287839309) {
        for (int nVDpL = 462785340; nVDpL > 0; nVDpL--) {
            wYnwqk = wYnwqk;
            wYnwqk *= wYnwqk;
            wYnwqk -= wYnwqk;
            wYnwqk *= wYnwqk;
            wYnwqk = wYnwqk;
            wYnwqk -= wYnwqk;
            wYnwqk -= wYnwqk;
        }
    }

    if (wYnwqk != -1287839309) {
        for (int asuHFGuTbaS = 1620277241; asuHFGuTbaS > 0; asuHFGuTbaS--) {
            wYnwqk *= wYnwqk;
            wYnwqk += wYnwqk;
            wYnwqk += wYnwqk;
        }
    }

    if (wYnwqk >= -1287839309) {
        for (int bfoLBSLAgfjUk = 1292427868; bfoLBSLAgfjUk > 0; bfoLBSLAgfjUk--) {
            wYnwqk -= wYnwqk;
        }
    }

    return -358675.4478148743;
}

int glxLaSC::hvGCt(double QntnogNseGVJz, double bbDOvOw, string JysISIBRSlJSMV, bool goZRXXE)
{
    string KBdSkamebXi = string("RVcJbEyqVDTZIzVEfMGLFJzRtHLIGWrXtwrxDTmyMFhqrIvtXyeWNSsdzKuDPjrgePBpRXJYMoQnMJgBKLxDAGXupIy");
    int zqMLdhRHG = -1932267595;
    bool yWkhEtR = true;

    if (KBdSkamebXi > string("KoVfnYslbjmdNbCCvFaTpWzkUFkXjFMjICcFsZeFnsyaVk")) {
        for (int XmMyYJiGJHnjgs = 1913023816; XmMyYJiGJHnjgs > 0; XmMyYJiGJHnjgs--) {
            continue;
        }
    }

    if (goZRXXE == true) {
        for (int kgKwfNeVmn = 800340243; kgKwfNeVmn > 0; kgKwfNeVmn--) {
            continue;
        }
    }

    for (int SuCJKOOFb = 1581795905; SuCJKOOFb > 0; SuCJKOOFb--) {
        bbDOvOw /= QntnogNseGVJz;
        JysISIBRSlJSMV = KBdSkamebXi;
        yWkhEtR = yWkhEtR;
        goZRXXE = goZRXXE;
    }

    for (int GoXorcTLxDhgRR = 450751896; GoXorcTLxDhgRR > 0; GoXorcTLxDhgRR--) {
        yWkhEtR = ! goZRXXE;
    }

    return zqMLdhRHG;
}

double glxLaSC::iVwLxgh(double FlGMU, bool HLiPKEDnTq, int CdGQdFogq)
{
    bool lxvbGRxVbIcmH = true;
    string CukxtrD = string("skeLtvqnAxnnmHWFvgNmWpRKLBOTjpETZCtpWSEcinCVAciaeqtSFfuDSkIDwQMfWHsjUxuPIjQWpcywkjuebdWTEucfwObGWJWLJCQnaWlomNRoLvokinDXY");

    return FlGMU;
}

bool glxLaSC::RdVHdEPSnIS(int XKuqt, bool lzrWUhCbanxaYHP, double omRJWUrMyUV, double nGpPOrG, double cmmVexWMgbbNzogA)
{
    double WglpkkUBbriejR = -119107.8626581228;
    string PoawQSijFRYj = string("MieoHcbfhhLxGmPoxYIMdcYuuCVSOgOwmTUCbcdUzJCJnoMhoPzYhLmoTeMkXTXSebxHDlHjcneSOHyHIYahUZC");
    string sqjyRXbRFpgOeglz = string("OgIyubwhhfbDYCgXMdlSylOJJbBBABLSVuXAlFjAlHUImN");

    for (int lQmfkU = 877697301; lQmfkU > 0; lQmfkU--) {
        omRJWUrMyUV /= cmmVexWMgbbNzogA;
        WglpkkUBbriejR += omRJWUrMyUV;
        sqjyRXbRFpgOeglz += PoawQSijFRYj;
    }

    return lzrWUhCbanxaYHP;
}

int glxLaSC::RbqQvuLvfhSsiZjI(string IptuE, bool LLmLLNCbhwMKiu, int pppuqR)
{
    bool uaeCn = false;
    string dXBeWPyjD = string("IiPyncmBhapBHhd");

    return pppuqR;
}

string glxLaSC::IdHdYD(bool czKleUsDFCz, string YZfCEMvDHnXfW, string lKyfErxdFiux)
{
    double VoREWRPaklg = -6420.175512638902;

    return lKyfErxdFiux;
}

glxLaSC::glxLaSC()
{
    this->tzOnkLEY();
    this->hvGCt(-469195.96942085057, -1029774.7911514563, string("KoVfnYslbjmdNbCCvFaTpWzkUFkXjFMjICcFsZeFnsyaVk"), false);
    this->iVwLxgh(1043675.602814601, false, 626694890);
    this->RdVHdEPSnIS(-323712733, true, -479208.5823219429, -904068.5503237571, -7386.48357460192);
    this->RbqQvuLvfhSsiZjI(string("ZtUFBQdUlFHBZDpjYtfKYmmXvGOu"), false, -1098824308);
    this->IdHdYD(true, string("hhkPmFaOoQjNTcUGogRFKWueYdHTfXVvucYjUKaabAPtlQPlkVsPrcETDeJkWIuc"), string("EpbGJjFIVHCpujCTLWwSIhapdkvbndyzjrwTEEFwRjikZnBQHftBEZqpjyenapEsYUHaJUInyLlLwQIgRWSempRiLLUnltwJgJtasaBPrIeQimgZnsjcgjCyrvKzRPgCaFahefccBtWZSffUufdkxosEiIoJQlwNZtzNMgUZeTImXHgKpZljejRsSpAHhgSnpmwwBKRpaOfOhUaUXtgvUMzJvHUKNqUXEOhBzPoGjSsCpCxZBjufqtcoajRu"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZrRVwh
{
public:
    double ESRVf;
    int pXuOvFlyiYjy;

    ZrRVwh();
    int GCdKPiSoLh(int uSyGyggXQKzQxK, string UJSFcBJENy, double cKdqsdhSvNvLze, double NWpBObhfszVeemaS, bool oEsRVntHptLlMdGj);
    void BKEqafHHOZUCcLg(int UeJsbV);
    bool TuqsfcwJXzcX(bool vgfAyuaDZdYO, bool GdNpuATZvDIjw, bool BHoQlPFQAM, bool zSHClzb);
    double RXqvVlD(int HGDpeOXPXZDAAn, string UMlXuQ, int abGmZBlkvXjThogv, string UjWSQJgrE, bool GYNkfqnLlQzu);
    double ezZQMLesZyFj(double lijUmF, int wVYDQr, bool qHSLhCLXenoSeRb);
    void meMuwTZn(string PNBXUYJxpJ, double gcYFIPhIms, double ofDJPEYHVlNpNa, string QGpdZuejWtRlXfIM, bool nJnFFCeGNHws);
    string ArcImqtANJBgt();
    int CAWoUcGH(string wDJIaVus);
protected:
    bool wFMDmsTdheoSZDqA;
    bool pcGisxwgTsiOjeKZ;

    int dGKumUQyHKe();
    string SwesLZ(string tiiaiZVoEgWI, double YQSKKwml);
private:
    string wUtbRg;
    int cibXfyuK;
    bool GMZymg;
    bool PgXryayUgVjJcJ;

    void bJSYKAftZ(int LFqMJNBWglPiAisG, double qrzTbwclPzfXuTs);
    double OayLfJehhbI(bool jAmjnamLU, bool YrPANyNTTt, string urukSEfKXvSnA, int aqBzpkWCJkf, int mrgmBOUlbjMEVO);
    bool OzXsLzkCAf(double EgEtCW, string rpPjhbjLQkYN, bool LOOrglNZWyL, int NrCQcAxrjgAlptyi);
    double tXfVACnHSVFNOCj(double PpqzACuRoVWoT);
    int mXqLVpvd(string iLRLe, int sQfhlbeSEOyLnb, int LjrSaeWSpbMq);
    bool lFxUkVgjs(int TbtTXuDlkP, string MedrNYyjwVnwhf);
    string sfGGftSHRStXfxZL(int cZPAE, int WMbIkmT, bool ybCyTngDXlbW, bool owmQELlTyle);
};

int ZrRVwh::GCdKPiSoLh(int uSyGyggXQKzQxK, string UJSFcBJENy, double cKdqsdhSvNvLze, double NWpBObhfszVeemaS, bool oEsRVntHptLlMdGj)
{
    string GsuwqlXlVnhADwe = string("THKyzvdmDJBNRnIVzmM");
    string eWBmyc = string("aIkBbRvFvYWUxNaFLRYLNZsqszZvnswLMMzkYlICsPsPZvZWoVIssEDfMUogw");
    int gpagYtPYOTMkYU = 1580631623;
    double sLtWZbVHSMddf = 265921.49273351417;
    string JEjDkLeQIXKMWY = string("BTJrRAKKraGEENKikmURDbWLcHJcNfnhSitWhiApDezegzQiHZDWSbZCAycJEwMNPapyRKnlGPdlibJlmkzKOsYclHwyMsvLtsQxbrpQZcxekHpiojmVcpplwZOmejEXmtWQjHlJlfajttKkmGBmJFEfZJWLHkcAUPkqdQPZhmacWEcbZFMjRFZGsSZC");
    int ynVPKJJMvoHMiNQ = -1272092879;
    string TwPfNiadCP = string("hbNiCGmOuDJKAeIOKIWIPmELMlBvxHLjifQy");

    for (int ZCCDbTiYZLUzj = 583556300; ZCCDbTiYZLUzj > 0; ZCCDbTiYZLUzj--) {
        JEjDkLeQIXKMWY += UJSFcBJENy;
    }

    for (int kcBBCHXDimMZZprV = 1143216049; kcBBCHXDimMZZprV > 0; kcBBCHXDimMZZprV--) {
        TwPfNiadCP += eWBmyc;
        UJSFcBJENy += JEjDkLeQIXKMWY;
        NWpBObhfszVeemaS = sLtWZbVHSMddf;
        eWBmyc += UJSFcBJENy;
    }

    for (int EmIfbkRcZQD = 1288256384; EmIfbkRcZQD > 0; EmIfbkRcZQD--) {
        continue;
    }

    return ynVPKJJMvoHMiNQ;
}

void ZrRVwh::BKEqafHHOZUCcLg(int UeJsbV)
{
    string rRbNOaT = string("BmRMNzoifDUA");
    bool CWUaZQSsYNSRf = false;
    double hGCDKPo = 621319.5136274787;
    double WkutiC = 231814.43907104674;

    for (int NUdjGVJ = 76473257; NUdjGVJ > 0; NUdjGVJ--) {
        continue;
    }
}

bool ZrRVwh::TuqsfcwJXzcX(bool vgfAyuaDZdYO, bool GdNpuATZvDIjw, bool BHoQlPFQAM, bool zSHClzb)
{
    double vDyjOAqlP = -236652.05062834674;
    double TsPtfCX = 1023675.1672980024;
    bool NkEvpBipR = false;
    bool MNAtk = false;

    if (MNAtk != false) {
        for (int dMLYvoje = 1813104747; dMLYvoje > 0; dMLYvoje--) {
            GdNpuATZvDIjw = NkEvpBipR;
            vgfAyuaDZdYO = ! zSHClzb;
            vDyjOAqlP -= vDyjOAqlP;
            zSHClzb = ! NkEvpBipR;
        }
    }

    if (BHoQlPFQAM == true) {
        for (int SsripmXxymJaqpJ = 1053499675; SsripmXxymJaqpJ > 0; SsripmXxymJaqpJ--) {
            MNAtk = ! BHoQlPFQAM;
        }
    }

    for (int ALBmqSPfrTa = 1246556319; ALBmqSPfrTa > 0; ALBmqSPfrTa--) {
        vgfAyuaDZdYO = BHoQlPFQAM;
        TsPtfCX /= vDyjOAqlP;
        NkEvpBipR = ! vgfAyuaDZdYO;
    }

    for (int KQRMqskIawTSoDHT = 1335933868; KQRMqskIawTSoDHT > 0; KQRMqskIawTSoDHT--) {
        vgfAyuaDZdYO = ! GdNpuATZvDIjw;
        TsPtfCX += TsPtfCX;
    }

    if (GdNpuATZvDIjw != true) {
        for (int nXZOyOUqjVWjkbgd = 1879392669; nXZOyOUqjVWjkbgd > 0; nXZOyOUqjVWjkbgd--) {
            BHoQlPFQAM = ! GdNpuATZvDIjw;
        }
    }

    return MNAtk;
}

double ZrRVwh::RXqvVlD(int HGDpeOXPXZDAAn, string UMlXuQ, int abGmZBlkvXjThogv, string UjWSQJgrE, bool GYNkfqnLlQzu)
{
    int qNyjamQnBO = -1950436716;
    bool OKBhcDTe = false;
    string vhUQJswRVD = string("sVRVJzENrIfmeIzReyVKKrAkjtJFaPAvipyKStfidnBwcdsgSKhhVEwEttZdJTLkCmoRwiLCeCMvoUAQwohlQOrKWPyPSMnsXqySDQmWvmQkHRbOQUcNngKeVBYGONFjcmCoERXzZTwCpInqxmmHOxOZjGgXLvpFxFAPRIFZxYPUkURdkkOnfNBHm");

    for (int XjlUMsLyagwzhV = 602695231; XjlUMsLyagwzhV > 0; XjlUMsLyagwzhV--) {
        HGDpeOXPXZDAAn *= HGDpeOXPXZDAAn;
        qNyjamQnBO -= abGmZBlkvXjThogv;
        GYNkfqnLlQzu = ! GYNkfqnLlQzu;
        qNyjamQnBO *= abGmZBlkvXjThogv;
    }

    if (UjWSQJgrE != string("zuJQnAnvyPdiNfocVGPHGnCXeOgsXIDMBeXPGztpIfvubhemRgHEiRLpuEDJxULRiaYFmsPHSktPUpYSOumbyjHOOcjbkHxYLppIqlICOdbiCWJnlvIvSHYpIpFcMJIQcescFXOlvmwQgEBlKfDaUTbDTPgSVxFNMBIBimwMqBGoPzMLsZNraPFAryoFYzoAPbeadkJDpDeesXUMUgzBhLvYroAmiEmmSaBGalxDBgtkjKR")) {
        for (int ngyBKOEloRQqRHoA = 2119099659; ngyBKOEloRQqRHoA > 0; ngyBKOEloRQqRHoA--) {
            HGDpeOXPXZDAAn -= abGmZBlkvXjThogv;
            HGDpeOXPXZDAAn -= abGmZBlkvXjThogv;
        }
    }

    for (int drSktEtG = 1965059167; drSktEtG > 0; drSktEtG--) {
        HGDpeOXPXZDAAn -= qNyjamQnBO;
        HGDpeOXPXZDAAn = abGmZBlkvXjThogv;
    }

    return -478777.4679590598;
}

double ZrRVwh::ezZQMLesZyFj(double lijUmF, int wVYDQr, bool qHSLhCLXenoSeRb)
{
    double vapioRSqGB = 164700.08989774756;
    int pMvrOQSwjMgd = 1974118393;
    int NoCxafdZUJmV = 1921685331;
    int rMNSppeiLgQMRWXr = -1713553523;
    string nKvZtnJsPiuw = string("eitZzxTFoRaWqLbPHVUxlWlYndqsqyALaPIHcmZfuVilVrfXMvvreifBRGpkzYDpPKSdJkWzLZXFBeJyrRUyaFduFCvnQF");

    for (int rfEDpJD = 1395492268; rfEDpJD > 0; rfEDpJD--) {
        continue;
    }

    return vapioRSqGB;
}

void ZrRVwh::meMuwTZn(string PNBXUYJxpJ, double gcYFIPhIms, double ofDJPEYHVlNpNa, string QGpdZuejWtRlXfIM, bool nJnFFCeGNHws)
{
    string uZPPL = string("uIYQlpyZbNoiLExjRxPhRXsQArvBGPGwoVyjYaYeyDaRQUAbowpVEzzoIzjZbcODiQwacNvdyBOBZwmLZYVrwsDwwCxfhNQqyAYMOjvwgQOVXynYxMJHwmPdLMvOgXgpEVRPBJIXOPllUDNqMQfKnYaFbeOWcjyyUAEpLpGQcsSTKlXOfzPxqh");
    bool gOrLPWDUEmunZGg = true;
    bool AENUzYGe = false;
    bool OqPHvva = true;
    double qyBWYSDr = 16177.296567669642;
    int EqbCEvNHeHGDc = -18170639;

    for (int ktbVhCkx = 2005923814; ktbVhCkx > 0; ktbVhCkx--) {
        AENUzYGe = nJnFFCeGNHws;
    }
}

string ZrRVwh::ArcImqtANJBgt()
{
    int JVLiYZrNMof = -1550754076;
    bool SmEjDBXeXdh = false;
    double frfGW = -669504.9796896379;
    string aYNPOvHkO = string("mmxccVjzggdyXOJbivqyiiTszIfifkIrrFQqIDIRpNWKGCrQxFVDPzwQupuQKxDuqZRWAfsAYBxdlesQuUMdFkxjkubTdcqaeGOCFPHYzARykmHCMKILKHUWQeQiRACnQXiJWXqwVeOaMEXiJzmhCxJuTYqwqcfMTHYkufyOwryNhCblyqrNxMpmYHAFdlCYIAiBfsuvkEoqpFTpROBrofBkshhELZKddgDGgcdxjvDGEFgLlJoF");
    int aYxZU = -253762612;
    string XrLlZQANujLV = string("iDdLswurUvwGCbpDyeFBIjrKfJKecjTNQKWlSIFFALByadlMNHNZSxExEdyKrzvNkBqWGMxaJlNTqhAMisDKZvHsFNYZdfnofcJYLqNPXmMCaAwgyTharmmuZrIPYVCrHBTYKhSdUUNpincLCaQSMIlfxXhiFgNrGvVeVwYlWQk");
    int BUAWzPgf = 2119866577;

    for (int YikeolDAp = 1495411386; YikeolDAp > 0; YikeolDAp--) {
        aYxZU += BUAWzPgf;
    }

    for (int JbFQTl = 1435686005; JbFQTl > 0; JbFQTl--) {
        XrLlZQANujLV = aYNPOvHkO;
        aYNPOvHkO = aYNPOvHkO;
    }

    if (SmEjDBXeXdh == false) {
        for (int ABwrUACm = 1907990049; ABwrUACm > 0; ABwrUACm--) {
            BUAWzPgf -= JVLiYZrNMof;
            JVLiYZrNMof /= BUAWzPgf;
        }
    }

    for (int EDcktFA = 1944979007; EDcktFA > 0; EDcktFA--) {
        JVLiYZrNMof -= JVLiYZrNMof;
        XrLlZQANujLV = XrLlZQANujLV;
        XrLlZQANujLV = XrLlZQANujLV;
        BUAWzPgf *= BUAWzPgf;
    }

    for (int tPngLIvkHBhajJ = 1253287155; tPngLIvkHBhajJ > 0; tPngLIvkHBhajJ--) {
        BUAWzPgf += BUAWzPgf;
    }

    for (int hutZAGu = 1437049959; hutZAGu > 0; hutZAGu--) {
        BUAWzPgf += JVLiYZrNMof;
    }

    return XrLlZQANujLV;
}

int ZrRVwh::CAWoUcGH(string wDJIaVus)
{
    string WKlBccWJcEx = string("vVVbENktPJZxAGaFjgjwKSuBkEdTmziiGeyyxIcsEkWNhuSiYUksandYkPqhVZxSjgScKixTSwXjKjILcdPyzbhHgEVBiNJgUJQeatacKKUUkCjSNEirc");
    bool acflBpAgiXAh = false;
    string ejmwrqp = string("xYRaZJQUycTWVqziHeCTfxeUXlIVgSvdHbMcknWGmMAQMWyMKFIFZwDCajiIBfPrRHGkgjRNTcuaNWCRvYxBfhvFyXDcyQIqaMkYMWBZjeD");
    double LQSOdC = -139383.27940088935;
    bool kqSKGERKexezcQq = false;
    string MALIgkaGoR = string("bRtlVNaxHeuzcWNpLSswDjrISBqfXpHoyeriGDDcdejRhuxcOeEjjlWrBwojyEZqsdcZgTwgTEHMxkswVaroxOTLPpvOHzmheEPOqTjEFNhRrgYdLTRHPYJsisrGmCYOsOxNsSspSNdcPSeNVsYfEMPkumRwGUGjfujuFzUBONBPyqCnlmIZfXZOFiAuUgMoTWJnATosRZSeQbYblVzODpNlMcLGCxzwxGShIyHvSjzcweX");

    for (int fIQVHl = 585620537; fIQVHl > 0; fIQVHl--) {
        wDJIaVus += ejmwrqp;
        wDJIaVus = MALIgkaGoR;
        ejmwrqp = MALIgkaGoR;
    }

    for (int zGZmAqsqEVbp = 1011381418; zGZmAqsqEVbp > 0; zGZmAqsqEVbp--) {
        acflBpAgiXAh = ! acflBpAgiXAh;
        kqSKGERKexezcQq = kqSKGERKexezcQq;
        ejmwrqp = ejmwrqp;
        LQSOdC -= LQSOdC;
    }

    return 1982513283;
}

int ZrRVwh::dGKumUQyHKe()
{
    int jDLswmeCTyLqV = 1497118355;
    int zLIEBDAiMQR = -1813387538;
    bool AvpWYVPcw = false;
    int bOjaLTPlPtEOC = 866705866;
    bool lsbYYfQEaA = false;
    string yWqsGClkGN = string("rhEHzjcDWsWEseTBllUFrEMnzzWIdMwawDYAVIOysFSWRAuzezsIGrUMzjETVMfDPAlsHGcSklmXLyzyoUfFVgPCHIIPNGAdDgfHjwkxPOaxGrNfyiKijzIEWQJacmxCZPOCOplXC");
    int XTYEjOBQPJqpuRoN = 570262025;
    double weyJpQJQQ = 660164.332208187;
    double wpyDqsmBJYQftMsW = 487047.38409607596;
    string gQEBouzOjYkg = string("cvPTdXGbUXFItNXPEumOjirEzCAPWkPoGeVtxCKdCYczrgJNPdobZGUmtLdmWCYFaekysBeTprXwvModEldACQZgjPqgEJRmmitcTOfSYhdRQlFzuCyKgysipAlscKvcDaNPbhckGsNMlyRPuASMPhDJpkLqVZMhKxYIOlvYGHqEXlQburDiTowWZNYzlCHWwFTKflAgzuRNlDpTUzZiURLdeFgYDrxLxbqgBANDEHIpqwShYalw");

    for (int sVASR = 140006955; sVASR > 0; sVASR--) {
        lsbYYfQEaA = ! AvpWYVPcw;
    }

    for (int rBOJNPAeO = 2074200491; rBOJNPAeO > 0; rBOJNPAeO--) {
        wpyDqsmBJYQftMsW += wpyDqsmBJYQftMsW;
        yWqsGClkGN += yWqsGClkGN;
        zLIEBDAiMQR -= jDLswmeCTyLqV;
        bOjaLTPlPtEOC = jDLswmeCTyLqV;
    }

    return XTYEjOBQPJqpuRoN;
}

string ZrRVwh::SwesLZ(string tiiaiZVoEgWI, double YQSKKwml)
{
    int bCxnDOyCccGDpZ = -201024872;
    double pkcOKfGwxdaPXJNx = 171874.13362627398;
    string WwqYUoAVkvXmd = string("lhJySmvyFlEvZYLtYHozpyfIjbshYHbONFZDtElVGEDhYHgJCMrfJxjJgREntiFHZJQoqVswyHIPPyidUbhOsODJLxnrztjUkqMVUJyrnobijMCjGsniTsvLFMtiQjVEZYbcdjBAaAPsv");
    double SDWzxDdo = -978621.5960906377;
    string ozDgIMibBjUkKpo = string("EahkUcflytyGwxNhxPeZIekSZbOunOXZjjT");
    int RUWvNJISvjpbp = -549162090;
    bool IzQGxX = false;

    for (int SBiZAdTFsoGx = 265714744; SBiZAdTFsoGx > 0; SBiZAdTFsoGx--) {
        pkcOKfGwxdaPXJNx += SDWzxDdo;
        YQSKKwml -= pkcOKfGwxdaPXJNx;
        WwqYUoAVkvXmd += tiiaiZVoEgWI;
    }

    for (int dWxFNtGxQQ = 559212691; dWxFNtGxQQ > 0; dWxFNtGxQQ--) {
        SDWzxDdo *= SDWzxDdo;
        SDWzxDdo *= pkcOKfGwxdaPXJNx;
        IzQGxX = IzQGxX;
    }

    return ozDgIMibBjUkKpo;
}

void ZrRVwh::bJSYKAftZ(int LFqMJNBWglPiAisG, double qrzTbwclPzfXuTs)
{
    double izdhrTpY = -359896.880246434;
    int jlbKvDYOcz = -1039077379;
    string dGPOZinApEW = string("uqGsdhUaLDyGPrLBegMqUWdWIWBYEBuynEULGtstSkqiJcJyEoMGyKhqWqqpEDihwbKTDkykoQmoDagyVszKlifFFNswFvTzDyMnTrVYIfSvLLPa");
    string puMDTjVchY = string("iWuWIsUooeZczVdsfumkPlKTwFRlBzQhryOPHcqMpPEkNddpGjVcUIgijmfuriwtDbcwXaneutc");

    for (int hOplsyZVhgiR = 1151532669; hOplsyZVhgiR > 0; hOplsyZVhgiR--) {
        izdhrTpY = izdhrTpY;
        jlbKvDYOcz /= jlbKvDYOcz;
        puMDTjVchY += puMDTjVchY;
        LFqMJNBWglPiAisG /= jlbKvDYOcz;
    }

    for (int NWRSBzrQOOsAIA = 1135179966; NWRSBzrQOOsAIA > 0; NWRSBzrQOOsAIA--) {
        continue;
    }

    for (int xxmrLbbiXA = 1671681621; xxmrLbbiXA > 0; xxmrLbbiXA--) {
        puMDTjVchY += puMDTjVchY;
        izdhrTpY = qrzTbwclPzfXuTs;
    }
}

double ZrRVwh::OayLfJehhbI(bool jAmjnamLU, bool YrPANyNTTt, string urukSEfKXvSnA, int aqBzpkWCJkf, int mrgmBOUlbjMEVO)
{
    double sVOumNOhobgfq = 788360.7696259856;
    string hwHeMGvadWZMpJaJ = string("leKGSjoCZKykpYZhKYwPDNWYkUrcXvTQzohOHYjlemTTlIqJjdQPlIzKgJKcWdQjNvQNcbVNpUSSUEJMbQJOYcASVEOapyHBkrcuJLiXAiUjZfczgNCgNAUDiHJdqsLbDieDVrRneCXqXkiRkUaKMtTYKiGQtrOEnnXgUyosBqYjgfEfjhdXbsdQeiBBUqCBoBcrILgHEFGCpSALILsoVQk");
    int aTzfvYehaiiWJ = -1403476597;
    string hdDIXfqE = string("apFNirdtqoYQMPSmFCyQAFJEAFDtiKzZEOUIdomGhqhYHeLHmGGrfYLcZonzSKcjCYkwBnmXgSCdMoGQKmScKPOhtGRmhOJUvAJhQLgfRtUJpkHPiKLGNJbtbXpgXckHZTbYJUKRJrntKEWqIoxYEuElj");
    double MdwAre = 685848.9930587909;
    double IvOtooatHyn = -809570.947507689;
    double KMXHHaYUwZu = 699371.256489173;
    int glxTmnvRvUD = 1352080891;
    double ZglMXDQAJe = -191609.71937644866;

    return ZglMXDQAJe;
}

bool ZrRVwh::OzXsLzkCAf(double EgEtCW, string rpPjhbjLQkYN, bool LOOrglNZWyL, int NrCQcAxrjgAlptyi)
{
    bool UIzVrkrlY = false;
    string nlrnAAvDFXZrPgSF = string("wwircDfdrqmfzwjOgZLolQPDazIdlK");

    if (nlrnAAvDFXZrPgSF == string("wwircDfdrqmfzwjOgZLolQPDazIdlK")) {
        for (int JaJfzyimgEmSXMes = 677776814; JaJfzyimgEmSXMes > 0; JaJfzyimgEmSXMes--) {
            EgEtCW += EgEtCW;
            UIzVrkrlY = ! UIzVrkrlY;
            rpPjhbjLQkYN += rpPjhbjLQkYN;
            rpPjhbjLQkYN = rpPjhbjLQkYN;
        }
    }

    return UIzVrkrlY;
}

double ZrRVwh::tXfVACnHSVFNOCj(double PpqzACuRoVWoT)
{
    string RzqfHiNmdGfsPzKz = string("LpvWojPMNKpdoNmHHNBQMgArdenkcoUrGSOLgncIWiZoEzPKIHXkYBZXztvgmJEnfQgqEZTjJKhlipqjeeygYmztZHviKYAlBTGybgKKUYtdkVyaNMuFkUjPRaBIxWuyptJufDWwkrRanKmfBQZvTOfCZbvcLnCgBfbCdcIRdgeVlZBIfgMxMsBKpzmyiJlsLXFprozRzjUPDPtttURrvZL");
    bool uZRgdCtvyXtjkOA = true;
    double VszdFyId = -403077.3558778487;

    if (PpqzACuRoVWoT == -767569.8562848368) {
        for (int cIKTXxy = 1275899290; cIKTXxy > 0; cIKTXxy--) {
            VszdFyId = VszdFyId;
            uZRgdCtvyXtjkOA = ! uZRgdCtvyXtjkOA;
            PpqzACuRoVWoT = VszdFyId;
            VszdFyId += VszdFyId;
            VszdFyId /= PpqzACuRoVWoT;
            PpqzACuRoVWoT -= VszdFyId;
        }
    }

    for (int WAuBKTApRkChzk = 1789887384; WAuBKTApRkChzk > 0; WAuBKTApRkChzk--) {
        PpqzACuRoVWoT -= VszdFyId;
        uZRgdCtvyXtjkOA = uZRgdCtvyXtjkOA;
        uZRgdCtvyXtjkOA = uZRgdCtvyXtjkOA;
    }

    for (int XFuRwtupE = 294934967; XFuRwtupE > 0; XFuRwtupE--) {
        VszdFyId = VszdFyId;
    }

    if (VszdFyId == -403077.3558778487) {
        for (int nMkvYoBpCxDqlTbO = 174663109; nMkvYoBpCxDqlTbO > 0; nMkvYoBpCxDqlTbO--) {
            RzqfHiNmdGfsPzKz = RzqfHiNmdGfsPzKz;
            VszdFyId /= VszdFyId;
            RzqfHiNmdGfsPzKz = RzqfHiNmdGfsPzKz;
        }
    }

    return VszdFyId;
}

int ZrRVwh::mXqLVpvd(string iLRLe, int sQfhlbeSEOyLnb, int LjrSaeWSpbMq)
{
    double NejZFyeIy = 142967.71956596215;
    bool LgsIBf = false;
    int nKXXsLzNOaJPzAn = 1431551431;
    string rxoJXvHqpdRFMhTE = string("DjlimNOkXhmWpNYNqhSjwvZganNBnqzXEWU");
    string aXbWZzsr = string("PwGSBHPcflDPPSHREtZtdaIhfEUEuBsVNXuIDrwgpdmFYStGXFAHiletZrSgjKUEtwPalEvXxojoypNDLVVRIFRsSXLkjHdGKUxOufpfQRLiglZBOTtHFyynjt");
    string HaInPtSTXbxVm = string("HTdNegZJjLCJOOYAuCRMYaAfJViRemkLebMaUOwKcbDfyDydwYnMBNHWZJYpiYegYYvNFGxRhObppPtBEAbzXHfMtANHRYeQczDGUpQHCFAxvbSjFS");
    bool oWKdabTaiHylZ = false;
    bool aoRNtp = true;

    for (int FzeocoubRz = 1934596848; FzeocoubRz > 0; FzeocoubRz--) {
        nKXXsLzNOaJPzAn -= nKXXsLzNOaJPzAn;
        HaInPtSTXbxVm = iLRLe;
        HaInPtSTXbxVm += aXbWZzsr;
    }

    for (int KVhwbahsvoNt = 321410851; KVhwbahsvoNt > 0; KVhwbahsvoNt--) {
        rxoJXvHqpdRFMhTE += HaInPtSTXbxVm;
        HaInPtSTXbxVm += aXbWZzsr;
        aXbWZzsr += HaInPtSTXbxVm;
    }

    for (int liJMmVwSvgEJOXZS = 1408051470; liJMmVwSvgEJOXZS > 0; liJMmVwSvgEJOXZS--) {
        iLRLe += iLRLe;
    }

    return nKXXsLzNOaJPzAn;
}

bool ZrRVwh::lFxUkVgjs(int TbtTXuDlkP, string MedrNYyjwVnwhf)
{
    double hBjDVcppK = -926368.8965013978;
    bool bLZGEphXaF = true;
    string OgNWittLyyy = string("QavzeCkbWpvGnPrDPdjHicKWmVIhjCtFjnfKlAdIwjYscoyBwXZeHoOoeTYduVGIxWOrxFAADSNYyWwVsScXGOFYzYAVyuhCPTHTAeGhGiXmxYUMBqcEqzbuXsYQAxRjKEwJQtRTLGxmGYGrwkTCCxFKkQdSApOQXGMCZNKljiDBqtkbeCGowuarXRsCFCO");
    double oaFwiuyFkA = -258625.254759082;
    double iUzYIQAcPdBSFGC = -1020910.8190149594;
    int dirudHXufFus = -658326727;

    return bLZGEphXaF;
}

string ZrRVwh::sfGGftSHRStXfxZL(int cZPAE, int WMbIkmT, bool ybCyTngDXlbW, bool owmQELlTyle)
{
    bool bgqzXXgjHmnSjJS = true;
    bool czceOt = false;
    bool fYFbVXLqsxfqWoC = true;
    string XMvleXmNphd = string("aoxZWpHvsbjPlFuQZUpRDbdZNJggewcSyKseLPbYRRjpfmZOuCmWLLjAbQxvqTOFDHmIlcfuoWMGHfDDCBDZZoltPLhloyiZvDQUgFMMihmjzBukTjlywxxNMDYQvQfrXBAggedufKTerEgtYenVJlfrBEzrUlfKqybyXOrPmHfwRWXdTQxlxoiORraENHdSVmwwNaiIEOY");

    for (int QhbDiNmVyEnAznW = 1563430426; QhbDiNmVyEnAznW > 0; QhbDiNmVyEnAznW--) {
        continue;
    }

    for (int zhYJBvHF = 549019917; zhYJBvHF > 0; zhYJBvHF--) {
        XMvleXmNphd += XMvleXmNphd;
        ybCyTngDXlbW = ! ybCyTngDXlbW;
        czceOt = ! fYFbVXLqsxfqWoC;
        ybCyTngDXlbW = czceOt;
        czceOt = ! ybCyTngDXlbW;
    }

    if (cZPAE != 2055724174) {
        for (int pGyJuuPvsQOc = 914773953; pGyJuuPvsQOc > 0; pGyJuuPvsQOc--) {
            fYFbVXLqsxfqWoC = ! owmQELlTyle;
            owmQELlTyle = ! czceOt;
        }
    }

    if (fYFbVXLqsxfqWoC == false) {
        for (int tjGrsoFiLELnX = 2068946994; tjGrsoFiLELnX > 0; tjGrsoFiLELnX--) {
            czceOt = ! czceOt;
            ybCyTngDXlbW = ! czceOt;
            owmQELlTyle = fYFbVXLqsxfqWoC;
        }
    }

    return XMvleXmNphd;
}

ZrRVwh::ZrRVwh()
{
    this->GCdKPiSoLh(-1765240977, string("XVwhZACSLMaQjIatDfGtOlsjuWLVarNmpagKPWNFJeCwZKxeSZNJChcGnWkiZDMW"), -591244.753017533, -848201.4734510513, true);
    this->BKEqafHHOZUCcLg(-58702174);
    this->TuqsfcwJXzcX(true, false, true, true);
    this->RXqvVlD(1607392855, string("zuJQnAnvyPdiNfocVGPHGnCXeOgsXIDMBeXPGztpIfvubhemRgHEiRLpuEDJxULRiaYFmsPHSktPUpYSOumbyjHOOcjbkHxYLppIqlICOdbiCWJnlvIvSHYpIpFcMJIQcescFXOlvmwQgEBlKfDaUTbDTPgSVxFNMBIBimwMqBGoPzMLsZNraPFAryoFYzoAPbeadkJDpDeesXUMUgzBhLvYroAmiEmmSaBGalxDBgtkjKR"), 115778696, string("CgfzdcaCBHPKDgnKhmluqKTiAMirZCbJOwXiCe"), true);
    this->ezZQMLesZyFj(386793.7511399381, 1381080701, true);
    this->meMuwTZn(string("QUJzrlJpBMCVDFUZZCIuYpXhLYZRJkLYMEJRkWKtjUcpiXrKwRiLZnyYSYpLqwXkRAjPafiZVaSzeVabMVsQODyoGDpLveSTOfyaYJCsYoYxRGqrRTZFybPRDDDTXIJdwQiEUHPdHoqW"), -317766.72802043613, -814529.0193063982, string("TPONoMmebeXlWCTGwCkBRfIvYmknRAXlkyCFswymNjFDnZ"), false);
    this->ArcImqtANJBgt();
    this->CAWoUcGH(string("EbPWgcElZleVgMQkSCjHvjDGrbksjXPCAvypvGFpZCjcxfoqIxegEVsgMLGgSaDbUrBIGHFRRVLiPouGnrcgLABqqpZOUdqXiBAlNtKmHXMhmZpbwCPVOXfichKDOOZoceKgHjzcAcDFWxnteTCWtaOBCLqTZJETiSTgGgTq"));
    this->dGKumUQyHKe();
    this->SwesLZ(string("ERLKFWRoKhUOaaEaildnXzXeWipTaAcclfmgybeRAzAcRzDPvRFJrPANrQTPpshcUfjMQDMdxVeTqYYWVecoFXjndhdjIKQWORkteElhircbORnuUDwwXVhZSUNlZhqYxkCESXSzcegpQtvfzbTWUgJTWpQrsuAjPnqVRZxwTiIGPiyCYSrFAoqCCqKruMJPgFgYSM"), 577019.057791692);
    this->bJSYKAftZ(-974355291, 970265.3159952066);
    this->OayLfJehhbI(true, true, string("deuQxCcpaV"), -772622524, 1302701717);
    this->OzXsLzkCAf(-343837.78484899626, string("NpJeNIWhjxuZKroyUysZpDQzdbNtLsQmjcWTGVthPIwQVgIfCwJnSAaZKOQmXDLTWLzZYrdJGCCwZfOJPYThMtOqylnSqKMDAdGwriekIhPfAjzbkmlfKPNBTBFrReOvFpuuSCuUYhO"), false, 876495372);
    this->tXfVACnHSVFNOCj(-767569.8562848368);
    this->mXqLVpvd(string("dgWzcGYetgjYGxJqItlXdQxQTABvmAXXkIZPTYQrIJgkcUQhUjTTFs"), -979260808, -1103802922);
    this->lFxUkVgjs(-53097883, string("RUAgEMqHURhFEjZXYxSsFDbvljEbWWrkRnOHrMmeXeClrZoQLLUbirbcUWMUjeMZKwceNVnUoLRHepFyjinESTIjCnUacRNANZOZJhwhUmlEbstnXPKtUtZcwQtTTwZQQjqQXechdcEkBDTSerbKPOMuAVUmqCRDlkoECazTDUDmPYxyAmwBcESflNJeyepgRfwWrwgkiTbcADpwhYozcUMYqxNGsFVtENMuotrQSAYBhizsAzSgU"));
    this->sfGGftSHRStXfxZL(2055724174, 1849215080, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CZDnChBqgBZ
{
public:
    string ehgggXbWWeZXV;
    bool pIyphEesDNVBzV;
    int mdIorgGh;

    CZDnChBqgBZ();
    bool QqnLlVIHuJyiHHcN(int GJOZXTtiHanbEIxn, bool LjAKbgpw);
    int VTEfJj(int HKQFw, int GkONHEx, int IkHhJHRVK);
    void CUJHit(int gHtoBg);
    double MUZndaijWYorCf(int EdNzUINirzBiJVWP);
    void RzEWdaLUsbhgpTLu(double RkUOZxLVgmy, int pmONLuaAjxvfd, bool lmYnGpkUahEtjdko);
protected:
    string LMtlcSXfZx;
    string VGgObacNCv;

    bool zaYAwrtMmYidEsRF(string hEEXDbTBAq, string aNjATVMrHVRT, string MKKYILhC);
    string KXFmBWP(string wWUUJEwowppO, int WuDXaQlewgFKuoBf);
    bool LxHGS(int TISjkNjQIqSev);
    int nORBQYPV(int FHpqgQEIY, bool jRqnzVGR);
    int wNELjcYndhp(int YUVFlkHq, bool NgqzPNhohjtb);
    int wrpKSodEFPtqivLK(int TorRDMZOPslnMdIe, double NyQabUvDpQALKsg, int SiZjOWATxQSG, bool DrUWwUncl);
    bool mhBDjbqgiFh(int CFcZd, string PKdrxvIbkmIOvxI, string GpQkWtWvdYZWBp, int QEjOwUJwh);
private:
    int bRqFDBeMza;
    string CwbOEJKpXpd;
    bool gDeDRReqaHWC;
    bool irenExpavfrH;
    double SBsSjEygrQtx;
    double IiSYkDZCX;

    double XQCMaYFtUC(bool ItSslHIrTy, double SvZIeoncpO, string WwMaXGHQova);
    void FDeMJv();
    void nkRSNyBGu(string SsDCGP, string JjjnY, double FKdmvYM, double CJXsxieho);
    double PuuNdQy(string BdfyrIexHDp, string NObbInbkkpvb, int FsgKAFTO);
    double UdRtIiZNZUb();
};

bool CZDnChBqgBZ::QqnLlVIHuJyiHHcN(int GJOZXTtiHanbEIxn, bool LjAKbgpw)
{
    double ytDLKLJF = 424552.1985629753;
    double sGIDWP = -833680.0701717668;
    int xUdxdfDXTiVLfZl = 1411709432;
    string QuHFnI = string("RyAolpLStFQVsTALuIiBtVEdIJUfKijvYkSbomaWZhqxEsuAYMDNBgJTrtSdSehaZXwarjEMEKwqLxUCJFdxzURXhICTAcSxEDfWGKJrkpNWMlBlgFwJjBkSlryYPKJKPgPiBHbrNPaOJmqXUlwk");

    for (int mvNmNcbO = 853801792; mvNmNcbO > 0; mvNmNcbO--) {
        continue;
    }

    if (xUdxdfDXTiVLfZl <= -148171640) {
        for (int NFvrhiXtUV = 1295677942; NFvrhiXtUV > 0; NFvrhiXtUV--) {
            continue;
        }
    }

    return LjAKbgpw;
}

int CZDnChBqgBZ::VTEfJj(int HKQFw, int GkONHEx, int IkHhJHRVK)
{
    bool fNlUHZk = true;
    bool SHSNtZajBeVJ = false;
    bool BsdslUaGjx = false;
    int IxhWyrrQjfC = -1551155833;

    if (IxhWyrrQjfC != 994775970) {
        for (int QkaZx = 1499003111; QkaZx > 0; QkaZx--) {
            GkONHEx *= IkHhJHRVK;
            IkHhJHRVK = IkHhJHRVK;
            IkHhJHRVK /= IkHhJHRVK;
            BsdslUaGjx = BsdslUaGjx;
            IxhWyrrQjfC -= GkONHEx;
            HKQFw = IkHhJHRVK;
        }
    }

    if (IkHhJHRVK <= 994775970) {
        for (int vvpYS = 1010499200; vvpYS > 0; vvpYS--) {
            fNlUHZk = ! fNlUHZk;
            IkHhJHRVK /= IxhWyrrQjfC;
            IkHhJHRVK += HKQFw;
        }
    }

    if (HKQFw >= 994775970) {
        for (int dAFmMObMsu = 392563125; dAFmMObMsu > 0; dAFmMObMsu--) {
            HKQFw /= IxhWyrrQjfC;
            IxhWyrrQjfC += GkONHEx;
            SHSNtZajBeVJ = ! SHSNtZajBeVJ;
        }
    }

    return IxhWyrrQjfC;
}

void CZDnChBqgBZ::CUJHit(int gHtoBg)
{
    double oTBidOc = 654011.8650082303;
    int eBRkGhURPQiULJL = -1130433516;
    bool kzNzRBeJhWGR = true;
    string BFkhgyRQEHRfOYT = string("ejyLGgZWPjrwsSvvAnBjUMUmNBsOcHpAxEjNuzJUyCcvHeKLVHvnxSWjvVkbXUJdiLFakVyRDfXzzqEDBdjChas");

    for (int DvMEjMDRxgZBGAW = 1428784823; DvMEjMDRxgZBGAW > 0; DvMEjMDRxgZBGAW--) {
        continue;
    }

    for (int pIAJZ = 1284848917; pIAJZ > 0; pIAJZ--) {
        gHtoBg *= gHtoBg;
        oTBidOc /= oTBidOc;
        BFkhgyRQEHRfOYT += BFkhgyRQEHRfOYT;
    }

    if (gHtoBg <= -363295966) {
        for (int IUtBOkhEQsfafDf = 2145019704; IUtBOkhEQsfafDf > 0; IUtBOkhEQsfafDf--) {
            eBRkGhURPQiULJL += gHtoBg;
        }
    }

    if (eBRkGhURPQiULJL != -1130433516) {
        for (int Nlaro = 433472088; Nlaro > 0; Nlaro--) {
            eBRkGhURPQiULJL = eBRkGhURPQiULJL;
            kzNzRBeJhWGR = ! kzNzRBeJhWGR;
        }
    }
}

double CZDnChBqgBZ::MUZndaijWYorCf(int EdNzUINirzBiJVWP)
{
    string bOYKKwCmreS = string("BqRXmiVxPXINaDU");
    int mztWCsZlgHg = -209629480;

    for (int KbenDlCppIQfb = 1255316689; KbenDlCppIQfb > 0; KbenDlCppIQfb--) {
        EdNzUINirzBiJVWP = mztWCsZlgHg;
    }

    return -559356.7311135329;
}

void CZDnChBqgBZ::RzEWdaLUsbhgpTLu(double RkUOZxLVgmy, int pmONLuaAjxvfd, bool lmYnGpkUahEtjdko)
{
    int XPJbMNomhZUkVw = -1797849542;
    bool selkOJjfoyDam = true;
    bool VqNOULLr = true;
    string UzIHZlUHKx = string("ZpzZtHOLLNIUZHNUtvaWEduSwwsWsMSkqxpKlezxdgshxmgMyKqeOKpoUxhFXlTmdtWxriaUfQhfzOXUMzlgVUkprhRdYsgMZLyiuOJbuNousEoQLRbcoQnlUGFnqINHfjeJizIhoMFPVcXtMJqIOLqiDvcqSjAawwajEWDoMWoIbhAiICMmKYiFDIfivcoFGISgJlQnjNcuimkCtKAcksLzzZHbhaMajoOLatFJpioccDIRWLWSJXnGK");
    int XXBkxB = 1132029160;
    double uMrSSAhWHopZwCTG = -193760.5976054829;
    int mJbFqWcWCTIdnv = -880838656;
    string gRDTwhFvL = string("TWiabkwXvYxJtTsoDwZnNzngVSViiAusHAfubwJDwXCKhPfiTTlxnCSZyLEoxVRngOTEzRphDgvAAfpWuuqrbFYSjEYyQjqUKmICaeCcHpAbIitSFuqzDZHWWttISGODXQteGcovOxdvCJDAPYxGUtYLNKYbkDXpZQpmgPSVxmRQufhkynimMLlsjlKFSyHTbNSENyDjfeqPYVmPbCZvJKaPaVdWEcBUQ");
    int KUybrtGkW = -991338673;
    string vGiORJJmmegf = string("m");

    if (pmONLuaAjxvfd < -1797849542) {
        for (int WKcFGTvbayHkMj = 1313598149; WKcFGTvbayHkMj > 0; WKcFGTvbayHkMj--) {
            mJbFqWcWCTIdnv /= XXBkxB;
            VqNOULLr = selkOJjfoyDam;
            RkUOZxLVgmy += uMrSSAhWHopZwCTG;
        }
    }

    if (lmYnGpkUahEtjdko == true) {
        for (int ccAMVChvvOZiiv = 2146319861; ccAMVChvvOZiiv > 0; ccAMVChvvOZiiv--) {
            UzIHZlUHKx += UzIHZlUHKx;
            XXBkxB -= KUybrtGkW;
            XPJbMNomhZUkVw *= KUybrtGkW;
        }
    }

    if (lmYnGpkUahEtjdko == false) {
        for (int AtcXYKAkDbjpyv = 698504951; AtcXYKAkDbjpyv > 0; AtcXYKAkDbjpyv--) {
            mJbFqWcWCTIdnv = mJbFqWcWCTIdnv;
        }
    }
}

bool CZDnChBqgBZ::zaYAwrtMmYidEsRF(string hEEXDbTBAq, string aNjATVMrHVRT, string MKKYILhC)
{
    bool NaYsgVaPqVAS = false;
    int PEyZLuQ = 818514278;
    bool pTTZzFuo = true;
    double vDTBgNthUrtVne = -593997.7441398925;
    string ZJcrjMOz = string("AdCTUbWZKJbSRnqIcRpNfZOMlRYrogkjZVJfxGZFpaCUBsfdaIqoEBlbDNWFNKEjojqUgSaWzdRfBqIlvXxUZQXrgaPGwmOwxdMzwPGsuSYDFGFKZNNLWIiGDdwaNvvOTWbNHCyGKxumAavkvKvmXYxnpAsCzJOvRTnNVlJiKWrmIycAPyzMXPZbyhbHvUcmkYffHiHx");
    string xtcJhPxgOnJ = string("dxunGYvcVxuemvGxQplwlDKgJPKStqsasiKKWXOuqYOiqQAgZDbftlViontlIEoiAmnPaCrjrvZiPsjAKHZhlCQHuxxYYjwkTOBTyioWHSJFNlgwWFnCyTDiUeXvDuvmekOcriSPJxifuJXNolRvXzcystZCsrjlyeZDOTKWkmnJnCLcnphKCfORVBqZdSZUNbC");
    string JghnmeZxavyKiXX = string("DSOEa");
    double SMXFGmZPI = 752143.7980718543;

    return pTTZzFuo;
}

string CZDnChBqgBZ::KXFmBWP(string wWUUJEwowppO, int WuDXaQlewgFKuoBf)
{
    bool PxMRWNWuDqXQCJ = true;
    bool JgINiqnS = true;

    if (PxMRWNWuDqXQCJ != true) {
        for (int lbesLHqToHQR = 1635246369; lbesLHqToHQR > 0; lbesLHqToHQR--) {
            continue;
        }
    }

    for (int gUunEcDzcaFpI = 1562917332; gUunEcDzcaFpI > 0; gUunEcDzcaFpI--) {
        continue;
    }

    if (PxMRWNWuDqXQCJ != true) {
        for (int wpPaUoFp = 1759433515; wpPaUoFp > 0; wpPaUoFp--) {
            JgINiqnS = PxMRWNWuDqXQCJ;
            PxMRWNWuDqXQCJ = PxMRWNWuDqXQCJ;
        }
    }

    if (PxMRWNWuDqXQCJ == true) {
        for (int rvYkqyvfQY = 39623388; rvYkqyvfQY > 0; rvYkqyvfQY--) {
            JgINiqnS = ! JgINiqnS;
        }
    }

    if (WuDXaQlewgFKuoBf < 566023438) {
        for (int XtOYmJF = 419005559; XtOYmJF > 0; XtOYmJF--) {
            continue;
        }
    }

    if (wWUUJEwowppO > string("koviiDRFBruesGcmnmCYaCvWZBzSAoeiQqIEpHZfXChqbCejyzCOlHtVquXtHmZGKcFNRRVmQieYLUvPoitLxtVWviTsLdQiOANHcSkqqGPsNuwaWyTVcmMBFkdjBKDbQzawHMueWnAbdejujBKtXpxCWjGfrhUfDdJAIyAgpthKcMwFxVHgILDgdVDyIdlzcbKpCHKeyfspTyyPYuJScOExZhXzpDtAXnWdMhRfhIgxfBmGSbVgvPWMa")) {
        for (int TckULP = 1048106024; TckULP > 0; TckULP--) {
            PxMRWNWuDqXQCJ = PxMRWNWuDqXQCJ;
            JgINiqnS = JgINiqnS;
            JgINiqnS = ! JgINiqnS;
            wWUUJEwowppO += wWUUJEwowppO;
            WuDXaQlewgFKuoBf *= WuDXaQlewgFKuoBf;
            PxMRWNWuDqXQCJ = PxMRWNWuDqXQCJ;
            wWUUJEwowppO = wWUUJEwowppO;
        }
    }

    if (JgINiqnS == true) {
        for (int QoTCRfNqbuFDobD = 1880439588; QoTCRfNqbuFDobD > 0; QoTCRfNqbuFDobD--) {
            continue;
        }
    }

    return wWUUJEwowppO;
}

bool CZDnChBqgBZ::LxHGS(int TISjkNjQIqSev)
{
    string TZWyqhyfU = string("wqzepWJSHRerkOAYiqEifxIrkZUMflsAGWNqfrzKnBpRPADKvakjVbbegNCtn");
    double YYTlV = 657475.8731275165;
    double rDSiZBAThcFMFnDz = 200538.0534585914;
    int CpgKR = 1128024718;
    int ApjIHKG = 450258133;
    string LlRlEwOXA = string("VJazsOVCkaRPOXCmciAHFwZKfvWwBTuFdySRfwsRXicwFyKiTEJGfTXjZPDKerwpcxqKlJUzJNYwZXdXOkHrhfDZDoxnJpAzvKOQwvsofREGUfyUaquDVmOKmhWvTtpWhguJyetjmojrblymcBELgwjsWzrXLEnNiSLHBnTCsI");

    for (int WEcqHCjKLeTCs = 1592569874; WEcqHCjKLeTCs > 0; WEcqHCjKLeTCs--) {
        continue;
    }

    return true;
}

int CZDnChBqgBZ::nORBQYPV(int FHpqgQEIY, bool jRqnzVGR)
{
    double CYyDDYoHAWdFGS = -416823.5090752992;

    if (CYyDDYoHAWdFGS != -416823.5090752992) {
        for (int cwpHXGdjMvbcwoW = 357641189; cwpHXGdjMvbcwoW > 0; cwpHXGdjMvbcwoW--) {
            continue;
        }
    }

    for (int LhGDGYwfP = 40465804; LhGDGYwfP > 0; LhGDGYwfP--) {
        CYyDDYoHAWdFGS *= CYyDDYoHAWdFGS;
        CYyDDYoHAWdFGS *= CYyDDYoHAWdFGS;
    }

    if (FHpqgQEIY < -1350724681) {
        for (int BAOwdhOpRHFmAKd = 782520243; BAOwdhOpRHFmAKd > 0; BAOwdhOpRHFmAKd--) {
            continue;
        }
    }

    return FHpqgQEIY;
}

int CZDnChBqgBZ::wNELjcYndhp(int YUVFlkHq, bool NgqzPNhohjtb)
{
    bool rjchZrOdGu = false;
    double WLeMYI = -860614.7148770823;
    bool RnzWap = false;
    bool ouqqAGKVMEwsPS = true;
    double iboKrTOhSNYmGX = 929936.7228916119;
    bool CwKRwvMM = false;
    double JJaQURzwJSMijOIx = 249581.5994014373;
    int snldPGMzpUzNdnC = -2119421734;
    string cFnkjlAbvUYsJoSF = string("HDPfFLXOwBgDgaparfhslMXoJPddubJzLSKminhWjXPwNJBFRICdMrVbddSkbPRvFITbYPZLKlcvKpRVJaUWYDVkhJokMShVAemRJZBPpzMWHDtCKLbhhBsAsf");

    for (int qbpTg = 1477751573; qbpTg > 0; qbpTg--) {
        continue;
    }

    for (int spFOpYPzPpJgJUYs = 631097627; spFOpYPzPpJgJUYs > 0; spFOpYPzPpJgJUYs--) {
        iboKrTOhSNYmGX *= WLeMYI;
        YUVFlkHq += snldPGMzpUzNdnC;
    }

    for (int vjNJcZaKUeLNBfy = 606128893; vjNJcZaKUeLNBfy > 0; vjNJcZaKUeLNBfy--) {
        WLeMYI += WLeMYI;
    }

    for (int ZOTbUdvX = 1683643335; ZOTbUdvX > 0; ZOTbUdvX--) {
        JJaQURzwJSMijOIx -= iboKrTOhSNYmGX;
        ouqqAGKVMEwsPS = ! RnzWap;
    }

    return snldPGMzpUzNdnC;
}

int CZDnChBqgBZ::wrpKSodEFPtqivLK(int TorRDMZOPslnMdIe, double NyQabUvDpQALKsg, int SiZjOWATxQSG, bool DrUWwUncl)
{
    int hgNnDPXjmYonpKj = -963262230;
    int ZWyyWsyDkqZCqis = 1111518315;
    bool yiccNyHhFiSBMrVQ = true;
    double phGuWmdQYjYC = 129098.23747070362;
    string ggjoTRwTI = string("FJXaMDsgRRCBuBOwWpFHumrhhWaIINgVqaUkNjEFvaxvuIYKXcrzlRMBCHCmakyCVXVaNbKxIVoOylpSZiqWbAONSunXckLhjNlqCfHrUqaGvGTfzOMTcKaDdcdDfeLujmliaTIqExyglpuxjfUbxxCfOgyxoTznPMWVynrpPuEWCSGOUiIceZzjRRic");
    bool BhHVuieC = true;
    double JFGHJTHMDyY = -1014052.0247194058;
    bool cCOyoLGYHD = true;

    for (int QYSUHSfxz = 1221188135; QYSUHSfxz > 0; QYSUHSfxz--) {
        hgNnDPXjmYonpKj /= ZWyyWsyDkqZCqis;
        yiccNyHhFiSBMrVQ = BhHVuieC;
        phGuWmdQYjYC += phGuWmdQYjYC;
        JFGHJTHMDyY = NyQabUvDpQALKsg;
    }

    if (yiccNyHhFiSBMrVQ != false) {
        for (int faVJzUPktJ = 2088862054; faVJzUPktJ > 0; faVJzUPktJ--) {
            ZWyyWsyDkqZCqis += ZWyyWsyDkqZCqis;
        }
    }

    for (int UPTeNhjNW = 1016716062; UPTeNhjNW > 0; UPTeNhjNW--) {
        continue;
    }

    return ZWyyWsyDkqZCqis;
}

bool CZDnChBqgBZ::mhBDjbqgiFh(int CFcZd, string PKdrxvIbkmIOvxI, string GpQkWtWvdYZWBp, int QEjOwUJwh)
{
    bool POpNCfuhtVbYr = false;
    string cUxjRmEpRgOcHE = string("OFeduDCdoyjjbLyDMrZkSQRKLbqTIafJcHVDKQWFvpmRELmbkEcLCrlxYiUNTkJzJnEtWjslivlOXcoxULrwrTMtqoHpjlMuibpOorectzBkWWyvXtIxPobunbqCgDSyAxujpwoOPAoPMzHkVTgOdZv");
    bool kaWDkUpJm = true;
    double Kontjdpu = 29347.314182688497;
    int gOuSSAapk = 856717454;
    string SKpVY = string("yJcgYEoyPQSQRODEmcbbvCrIIwtBRhiSZonyQTGHNuIgKLpAemzfoCAaMmrOpgjXeAjQlofihvHwsPqwgjTuAjRUlsNZPglxGyYWCnHuASpvqeBLGUovzQhlODPovyjwHYdOTigGuucLpgVfZdpHBfqWvripSAvtsiTRzHwgQSjXByPs");

    for (int xelEKZozSvyzZ = 1300194503; xelEKZozSvyzZ > 0; xelEKZozSvyzZ--) {
        PKdrxvIbkmIOvxI += cUxjRmEpRgOcHE;
        Kontjdpu = Kontjdpu;
    }

    if (PKdrxvIbkmIOvxI != string("OFeduDCdoyjjbLyDMrZkSQRKLbqTIafJcHVDKQWFvpmRELmbkEcLCrlxYiUNTkJzJnEtWjslivlOXcoxULrwrTMtqoHpjlMuibpOorectzBkWWyvXtIxPobunbqCgDSyAxujpwoOPAoPMzHkVTgOdZv")) {
        for (int EPHKnRjHlFpvN = 1579231875; EPHKnRjHlFpvN > 0; EPHKnRjHlFpvN--) {
            cUxjRmEpRgOcHE = PKdrxvIbkmIOvxI;
            kaWDkUpJm = ! POpNCfuhtVbYr;
            cUxjRmEpRgOcHE += cUxjRmEpRgOcHE;
        }
    }

    if (SKpVY <= string("OzGXFDpaNzZrquEukgnJbmjSaUwSvCAPBrNXbZJAnMfxWVKeMbiBUIBlObxRURoIDMnTBhvJRAXeIUwTPURqzRRdLWSEwLAEplFeebrCmBjWNrvZsbCeBPFouTtJawEPBAOxFGtePqaSJZHaBsyWFkClSXVfbpbnDVzUQBQMlvQfFXhMtzUzgiOYJucSHwxrBBbSZzRUKU")) {
        for (int ZwKnaGVoqdWJYRQk = 929190667; ZwKnaGVoqdWJYRQk > 0; ZwKnaGVoqdWJYRQk--) {
            PKdrxvIbkmIOvxI += PKdrxvIbkmIOvxI;
            gOuSSAapk /= QEjOwUJwh;
            GpQkWtWvdYZWBp += PKdrxvIbkmIOvxI;
            kaWDkUpJm = kaWDkUpJm;
        }
    }

    for (int xSyZCqKXRaOBzR = 204584466; xSyZCqKXRaOBzR > 0; xSyZCqKXRaOBzR--) {
        Kontjdpu /= Kontjdpu;
        gOuSSAapk -= QEjOwUJwh;
        GpQkWtWvdYZWBp += GpQkWtWvdYZWBp;
        GpQkWtWvdYZWBp = GpQkWtWvdYZWBp;
    }

    if (gOuSSAapk != 391554807) {
        for (int asADYn = 1181103737; asADYn > 0; asADYn--) {
            cUxjRmEpRgOcHE += GpQkWtWvdYZWBp;
            gOuSSAapk -= gOuSSAapk;
            gOuSSAapk /= gOuSSAapk;
            SKpVY += GpQkWtWvdYZWBp;
        }
    }

    return kaWDkUpJm;
}

double CZDnChBqgBZ::XQCMaYFtUC(bool ItSslHIrTy, double SvZIeoncpO, string WwMaXGHQova)
{
    double UfpSyzyfSf = 476524.5514964603;
    int YOKYqePVohRQOHx = -1953238942;
    string BJsFPDIYEBpuHI = string("gDwoBTXcIFtnBRPmYCuKPLCGqaPNcREvZqwCMntcnBdgGjZuqmLuAQajUZfeBiqjOTaLkSDekEoFFTuJkapQSLaRkanNBVKMcNbdSGTWVevZotSHHFKGRojtNSpjwWIpjWLRPQokUNcHaTjrxyYGMutxKRdYvQZnVJCtWgVxINZmNdgyRzMiVJoifgvtMPLFbGVsxpSCiIedUSeroKFiISpjuUEpibmqqmfdIfne");
    string ZawCiQl = string("VioifHjsrvmgPOizSbHKqDqzlzImcvbadIjyDpEGUCKXcxBzQCZMTSdhTtjEPdgOnBSdvCjJustozFHYDxoKAGUXFoizuwvanRwAZlvucvFwAKldKSRstvhImKlAJUtgSNnmIcIvhDBGEqWJsxOCHtOuQREIXQmBmQVkGzvRWHSwTxPDHFXNvufopiHShlXttHGYfaGGrvIeSyukvwfwUGDiEgUgdWRfFTLC");
    int YVdXEhvIoUsQN = 1494275325;
    int yKMmmEqLWdsjUG = -1020542906;
    int YZxKlqR = -462057688;

    for (int AldBAXSqPK = 1949404573; AldBAXSqPK > 0; AldBAXSqPK--) {
        continue;
    }

    for (int MITVUcFUlgEoDhC = 196636883; MITVUcFUlgEoDhC > 0; MITVUcFUlgEoDhC--) {
        continue;
    }

    for (int fBdOEQwZOHxU = 1338062726; fBdOEQwZOHxU > 0; fBdOEQwZOHxU--) {
        YVdXEhvIoUsQN = YZxKlqR;
        ZawCiQl = WwMaXGHQova;
    }

    return UfpSyzyfSf;
}

void CZDnChBqgBZ::FDeMJv()
{
    string pmUnbAR = string("HSkRTrekhlatATxXAxlEUcXzurmiPVmav");
    string peGDFpPQGb = string("eoAWXYyiTSwrewsNVOmAErYHyERazGJIXKLhrrQituvdfaowwpPCSKSSqyxsfphvuFxOo");
    int UYUigcarHEdu = -1950412579;
    int Hljnqkws = 408460931;
    bool UXaRkWofRvys = false;
}

void CZDnChBqgBZ::nkRSNyBGu(string SsDCGP, string JjjnY, double FKdmvYM, double CJXsxieho)
{
    int xxTHoScvyw = 856780442;
    double UKfWnpveuDe = 1032486.7322867112;
    string rVKkPoYfj = string("kvuUAXvIqNMPkiiaBGJmzIwaOKaUqcwWuEcQknBzTsenPXKnVeEkpQPngigXVcxfOaFzRzJcFHXPD");
    double MyGudqkDeIWrGT = -656403.6192161989;
    string OYOtEKmQXZwGrA = string("PwKMeMTGuCGQTPSKgzbszJdmNZleyQDlpFSAqvyhQeuyNTnfllvZfadgqsZPKczmbMkYMWcSjxbFdLYrpNqVmtIbjnRrtWYwnlewMBGvatSpCBZMljQOaSWaKFXncLuGAqZSJZcdtwDnJtBiTGEKfCkSTMRSSxeeStXDELzpqHkvEtBRtjjsVWkuEEz");

    for (int vWxdYpbTJtK = 1383417273; vWxdYpbTJtK > 0; vWxdYpbTJtK--) {
        rVKkPoYfj += OYOtEKmQXZwGrA;
        OYOtEKmQXZwGrA += OYOtEKmQXZwGrA;
    }

    for (int FPnMwCBLQGI = 2127031489; FPnMwCBLQGI > 0; FPnMwCBLQGI--) {
        UKfWnpveuDe -= CJXsxieho;
    }

    if (rVKkPoYfj <= string("pcPiShJMuscRUaoEuUfcJQurSlfDDPRfMpWiuEvpuTavkwSMGfdlnSjLWvBlgGKibERHVwFgqwmVUdiSAKEEqfMlWhcgCZUTfgloaFroGsUJAdDoVhTMXqQDIcxCYbGqflxftRrACzhVnMdOpcieBl")) {
        for (int sccAZwigISIv = 103336744; sccAZwigISIv > 0; sccAZwigISIv--) {
            MyGudqkDeIWrGT = UKfWnpveuDe;
            MyGudqkDeIWrGT = CJXsxieho;
            JjjnY = SsDCGP;
            CJXsxieho += MyGudqkDeIWrGT;
        }
    }

    if (CJXsxieho > 1032486.7322867112) {
        for (int LAVofydgFWzw = 1005578766; LAVofydgFWzw > 0; LAVofydgFWzw--) {
            rVKkPoYfj += OYOtEKmQXZwGrA;
            FKdmvYM += MyGudqkDeIWrGT;
            SsDCGP = OYOtEKmQXZwGrA;
            UKfWnpveuDe -= CJXsxieho;
        }
    }
}

double CZDnChBqgBZ::PuuNdQy(string BdfyrIexHDp, string NObbInbkkpvb, int FsgKAFTO)
{
    bool uRLIyYF = false;
    double roPYshmhcdCqcjt = -546931.6432556738;
    int AFnqIzsxlepVS = 1289285573;
    int ZZagbVSfylzamix = -1170461464;

    for (int THZWawcocKMvSy = 1917387206; THZWawcocKMvSy > 0; THZWawcocKMvSy--) {
        FsgKAFTO = FsgKAFTO;
    }

    if (AFnqIzsxlepVS < -1777707914) {
        for (int fPPTf = 364349416; fPPTf > 0; fPPTf--) {
            NObbInbkkpvb = NObbInbkkpvb;
            AFnqIzsxlepVS /= AFnqIzsxlepVS;
            ZZagbVSfylzamix -= AFnqIzsxlepVS;
        }
    }

    for (int gDnyselbLOTzTsQI = 411993040; gDnyselbLOTzTsQI > 0; gDnyselbLOTzTsQI--) {
        roPYshmhcdCqcjt -= roPYshmhcdCqcjt;
        uRLIyYF = uRLIyYF;
    }

    return roPYshmhcdCqcjt;
}

double CZDnChBqgBZ::UdRtIiZNZUb()
{
    string gpVDnwcFl = string("kbqGopAJvUBeFSdGMTCbmdrHETUJpTtRmrikIzFFNLAgyeqhkdXgDtkiIpqgDZdamKmMTNMlTroHCxLcibBJEXLTGATOGLNzuLwlOfQepbEHNaNqZSrMEmdputDbtokKkXFVWiyzNEEFhmXgQXESzolVQpxNeSYMUmRQHYUOToY");
    string heeqYfinpR = string("olOcPmHiKKlYiHBVgrOdAmorzZWToVjIYybzpydzHyBOsXLEfzodFsXawnVFcvvXVqALOMGNFvPgZOnJOzeIWmzxrKmHEioXllikwWYp");
    bool kWgFqrEnStNgua = true;
    string sSSRWrVv = string("rgNoqlpzwLgQHChawEzKaJTeMKqgyRatOiLbFOxdTiWHCAZsGLiCFwLBMFYTEIvDJpwPlLeGhINambWthYerxElewMToECzRCUXqdKbruOqzOxmhUEYBbrgMmsRxQEFHkIj");
    double yVCDEsBeSkEWc = -167092.79250033002;
    int nOEbFwQIpEjmvBbF = -746072999;
    int DPfcFUZybRxZcmLA = 620303535;
    string ZbCnZnAv = string("lhCrbEpHKHLALSajYvhDWPaozSIOXzFqjadwESVPUpZVyVaBLoblavWHBYOFdxbbTaswZpsudMFcslARXyfdRwiHiLwWxTcYRqzAwMXFTmPWLvgzSscpilohCNKbIsuuLTCGUsUBrQNIOcgKyqkRwJjydOsDWvitnnwESyrYlZTPDRuafETAsimzoSxSAgPyDOWFxkVTXzbRTjQWBNSVxjtHQdbAHJuZQyDb");

    for (int lYGMyahuwMlu = 1711717213; lYGMyahuwMlu > 0; lYGMyahuwMlu--) {
        sSSRWrVv += sSSRWrVv;
        DPfcFUZybRxZcmLA = nOEbFwQIpEjmvBbF;
        kWgFqrEnStNgua = ! kWgFqrEnStNgua;
    }

    for (int FbQcVGdZojUOy = 1498488031; FbQcVGdZojUOy > 0; FbQcVGdZojUOy--) {
        ZbCnZnAv = sSSRWrVv;
        gpVDnwcFl = sSSRWrVv;
    }

    if (kWgFqrEnStNgua != true) {
        for (int xWjvykufGsXZhnm = 602834432; xWjvykufGsXZhnm > 0; xWjvykufGsXZhnm--) {
            continue;
        }
    }

    if (sSSRWrVv > string("lhCrbEpHKHLALSajYvhDWPaozSIOXzFqjadwESVPUpZVyVaBLoblavWHBYOFdxbbTaswZpsudMFcslARXyfdRwiHiLwWxTcYRqzAwMXFTmPWLvgzSscpilohCNKbIsuuLTCGUsUBrQNIOcgKyqkRwJjydOsDWvitnnwESyrYlZTPDRuafETAsimzoSxSAgPyDOWFxkVTXzbRTjQWBNSVxjtHQdbAHJuZQyDb")) {
        for (int FdsbMBOmQdAubi = 1004419392; FdsbMBOmQdAubi > 0; FdsbMBOmQdAubi--) {
            yVCDEsBeSkEWc -= yVCDEsBeSkEWc;
            kWgFqrEnStNgua = ! kWgFqrEnStNgua;
            ZbCnZnAv += heeqYfinpR;
        }
    }

    return yVCDEsBeSkEWc;
}

CZDnChBqgBZ::CZDnChBqgBZ()
{
    this->QqnLlVIHuJyiHHcN(-148171640, true);
    this->VTEfJj(994775970, -1265648143, 1321522112);
    this->CUJHit(-363295966);
    this->MUZndaijWYorCf(-171728869);
    this->RzEWdaLUsbhgpTLu(591972.2502257917, -1764323440, false);
    this->zaYAwrtMmYidEsRF(string("vunyHvfMgojKwAoylptldpLWBxucjJpVWQwTqjEAWAnsfsfwxvtPhYzIQCsfsZpMwCSFzsVGdshBCUSeBkJFjNMGpOMtGzu"), string("JIczGiYZcMuqQEaFGbuOiexkHSDJRszRLEXhwzkPjrSbkpNwjEDZDwvXoSmnkVzgVwMRFrKHmVJlvbaTFhVwIzdbLLdLZFzCS"), string("vBdjjpNsuZUBkqkrQMQuPNuZLTHkNgsNPqGrNMFcznOjsgKkUjYejFaWFziLvGJSVzcOkOVsXOAwtoeWATDKYRgIoeYHt"));
    this->KXFmBWP(string("koviiDRFBruesGcmnmCYaCvWZBzSAoeiQqIEpHZfXChqbCejyzCOlHtVquXtHmZGKcFNRRVmQieYLUvPoitLxtVWviTsLdQiOANHcSkqqGPsNuwaWyTVcmMBFkdjBKDbQzawHMueWnAbdejujBKtXpxCWjGfrhUfDdJAIyAgpthKcMwFxVHgILDgdVDyIdlzcbKpCHKeyfspTyyPYuJScOExZhXzpDtAXnWdMhRfhIgxfBmGSbVgvPWMa"), 566023438);
    this->LxHGS(-1385701461);
    this->nORBQYPV(-1350724681, true);
    this->wNELjcYndhp(455202901, false);
    this->wrpKSodEFPtqivLK(-164497449, -130477.63017966672, 421289912, false);
    this->mhBDjbqgiFh(391554807, string("wzUqidgtUmtQJtaEdEtuuVLWhDzWQNXJtiXQpTRzpdGAlkHsOqSuwLsOKPfiBBAbydfpanQDolGqcBWnNsSQhsxMmnlkPG"), string("OzGXFDpaNzZrquEukgnJbmjSaUwSvCAPBrNXbZJAnMfxWVKeMbiBUIBlObxRURoIDMnTBhvJRAXeIUwTPURqzRRdLWSEwLAEplFeebrCmBjWNrvZsbCeBPFouTtJawEPBAOxFGtePqaSJZHaBsyWFkClSXVfbpbnDVzUQBQMlvQfFXhMtzUzgiOYJucSHwxrBBbSZzRUKU"), 433222302);
    this->XQCMaYFtUC(false, -369850.8682718788, string("LJUiSmpndAPgqXkvgufiWnNHTZZYmkRircHYvODcvBpxaRALKfBMryKYqRRdFKhVFMJmGSfSbBIIkhnLusAZwlddDIqijTStDHOkUOMqBkJUKLMkUfgMmseBUUO"));
    this->FDeMJv();
    this->nkRSNyBGu(string("gnMmRFhzWGVXimWcGEipiqybdiKqbMSDZAfotiqaWWAdjYLzCQLehgJRTATLSXYflCbJZgVtskrxHPpjfgtPiAweAVVPXlSNQrpDTLVoyewYkJubxmgC"), string("pcPiShJMuscRUaoEuUfcJQurSlfDDPRfMpWiuEvpuTavkwSMGfdlnSjLWvBlgGKibERHVwFgqwmVUdiSAKEEqfMlWhcgCZUTfgloaFroGsUJAdDoVhTMXqQDIcxCYbGqflxftRrACzhVnMdOpcieBl"), -443326.2677989288, 154872.96219442322);
    this->PuuNdQy(string("YqFSiPeJiyEfskKEVycqLitNFymJSIkjHaFwxkSDcXxrynnydnocwgONoOUbaymXTpBSYQevmOLinxJHkClRaYURBWTUmgVUhYboEtRfgBCcGsZastHARWPOiCwDGLKBrCZGcAagLuwJXeDEpZFONyQqrIygtlbsoxUggxTnSdInKuuOlgnrLOVqQNcHfCcRhtJlLQdkBtvrIlnzVPiOOliVPvTjMnHqQiEXKvJZlbUIXwlcLvZNvIMmCqrN"), string("xMPCHBTCFxDsgMfiGZkHynmYEEpnSfdJuJfKZHZjXEVoBChffMvcoXhROFHeyTxjPBchbcrNybDnEXOfNCeAUgrjTZCMdLdpRBWdcjbMyzmlLnEhHCxXbsuqdXypafzvKIQNBJHDGQHYHNOhBcMERiQlpoOJZEgmMsEazeEHfAzGZUChcTxHeSxbjJQGvztIgzDeYNHctACMrttqtrqIMdLnmZPRdpTUk"), -1777707914);
    this->UdRtIiZNZUb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KHIKQPaOsR
{
public:
    double kJWjkebUabjn;
    string pPLNrjxIKOUGMRZY;

    KHIKQPaOsR();
    int TrezTTD(bool ZnghNyh, int gkpLuGIoZmNmbY, double ZHcHhAI, bool dRpANqnQICObQiEA);
    string dydpivGaUxh(double vbJJBIRZc, bool IcyarLVErHRCj, bool yiHRsYvHubzqgtX, int toUCf);
    void fpdjQWtfY(bool JjlJekRExFdXRbaR);
    bool nbchYyU(int JOxATVjBZEE, double TSLfENSCWhxK, string LxdkKYrXIVgwJn);
    bool JPRqWArWki(int HQtwsoOOC, bool nKmjpBl, bool wyDhp);
    int tuiKCYXtlqV(string sFuhTb, int mDNbt, bool HgYklMaNWxfw);
    double JUVWBqwvf(int IQqxaTCNYyvR, int CYvewxAOU);
    double yCkZyEJdJ();
protected:
    string eckHmdQDxsYSvn;
    double lSlbo;
    int gvdnB;

    double ZUSBCo(int JcaXBEc, int RGAmJxdOTqCHBn);
    double OOPeCPvJdA(int nqKNIYkBY, string yLGPM, int osili, string hxpLLwDvwDYRlb);
    bool udqQFbicXMvCn(double EsiJcRYTHdCvw, double SqKeaMPP, double CgnrfQJZOQW, int VgOCK);
    void TQaCIbsDEou(int uIjLUTKZ, int ZBDcVvQzSP);
    string jProAJwCynaQPdXO(double wcATYuDwDmdX, int OAjRUDsSUXxEJs, int wqNXcSTOk);
    bool NomzGnNNtKaUQyFX(bool oiKzJLXUxmzMKY, bool yxCoA, int WxvjXrC, string ZUiyVHD);
private:
    string TXsgJMpldGNVODNj;
    int yxyMOYtPe;
    bool mDkwWMaGUyM;
    string sFwiUsGq;

    string DwcCXB();
};

int KHIKQPaOsR::TrezTTD(bool ZnghNyh, int gkpLuGIoZmNmbY, double ZHcHhAI, bool dRpANqnQICObQiEA)
{
    double BHHYEzLDXTHdn = -506904.90651178366;
    double fDPNgKSP = -1045574.3861503032;
    int nNfmelkfXIcdh = 1692600276;
    bool IlfEUBYtuC = true;
    double WxVrJCJdUMdOnk = -280695.7955410544;

    for (int axckBQYZ = 961936702; axckBQYZ > 0; axckBQYZ--) {
        IlfEUBYtuC = ! IlfEUBYtuC;
        fDPNgKSP *= fDPNgKSP;
    }

    return nNfmelkfXIcdh;
}

string KHIKQPaOsR::dydpivGaUxh(double vbJJBIRZc, bool IcyarLVErHRCj, bool yiHRsYvHubzqgtX, int toUCf)
{
    bool DnPkUnWduOifDCgr = false;
    int hrWTzoUkNOvYR = -837966804;
    double zQZbWNzUQawufAlf = -353047.76281002;
    string cmxhvetvvvQr = string("oERHWgVfqxfOxhSRFNrkzUfjaNZBZSmRafmFnoGHLh");
    int JBsimWzfozfJcaB = 1894438310;
    double KsHDvhIboRh = 414856.8027897145;
    string IdgtzlCEejavJwDl = string("ImaTxZeSZOfWSzumMlUUGAkUcJNxaHMJeZacUbxUigMLUDihIutxtaGtaRNKYKuASeMSFnhJitcpzEJrghVMJcC");
    double mUrJZZeO = 651209.5340962682;
    double YXGSpa = 285392.48143134237;

    return IdgtzlCEejavJwDl;
}

void KHIKQPaOsR::fpdjQWtfY(bool JjlJekRExFdXRbaR)
{
    bool KOsli = false;
    double xfUzC = 113230.47662949067;
    string BrkJWFrhNCQgWUe = string("NsmVHJXIfQZDDdCODZQKZsXYWbvNfsLhoDKbSGKrOTlikjuSkfPzwtQuwzAzmDPKVUdfAsFSdwhbRErMqMSsrTpZNMxQouOSGZnNKoNEKACtpSqdlRilKdTlnt");
    int mjJrGEgrSz = 689940537;

    for (int eRnxUMPfhNEDk = 117121873; eRnxUMPfhNEDk > 0; eRnxUMPfhNEDk--) {
        xfUzC *= xfUzC;
        JjlJekRExFdXRbaR = ! KOsli;
        xfUzC -= xfUzC;
    }
}

bool KHIKQPaOsR::nbchYyU(int JOxATVjBZEE, double TSLfENSCWhxK, string LxdkKYrXIVgwJn)
{
    int tFqEGkA = 1839191926;
    double uwIxWd = 987063.0836597887;

    for (int NockZK = 687001357; NockZK > 0; NockZK--) {
        JOxATVjBZEE *= tFqEGkA;
    }

    if (LxdkKYrXIVgwJn != string("RfIhuWWuthhi")) {
        for (int HNnPZxie = 775867375; HNnPZxie > 0; HNnPZxie--) {
            continue;
        }
    }

    return true;
}

bool KHIKQPaOsR::JPRqWArWki(int HQtwsoOOC, bool nKmjpBl, bool wyDhp)
{
    int ZvhBMNWVQHMJdQm = 914995072;
    bool sGyVyo = true;
    bool ekArSm = true;
    bool aRBAviMheFzDEvvq = false;

    for (int OBwpkeMbXbVdoGIw = 1919904191; OBwpkeMbXbVdoGIw > 0; OBwpkeMbXbVdoGIw--) {
        aRBAviMheFzDEvvq = ! aRBAviMheFzDEvvq;
        HQtwsoOOC -= ZvhBMNWVQHMJdQm;
        wyDhp = ! ekArSm;
        wyDhp = ! wyDhp;
        nKmjpBl = aRBAviMheFzDEvvq;
    }

    if (HQtwsoOOC != -1201563737) {
        for (int vVdimhRlfJfxRM = 1534673038; vVdimhRlfJfxRM > 0; vVdimhRlfJfxRM--) {
            ekArSm = ! wyDhp;
            HQtwsoOOC = HQtwsoOOC;
            ekArSm = ! sGyVyo;
            ekArSm = nKmjpBl;
        }
    }

    for (int aBSPWOYDZp = 1254394506; aBSPWOYDZp > 0; aBSPWOYDZp--) {
        sGyVyo = ! sGyVyo;
        aRBAviMheFzDEvvq = nKmjpBl;
        ekArSm = ! wyDhp;
        wyDhp = ! aRBAviMheFzDEvvq;
    }

    for (int FITkCvuRcSHwKf = 609091763; FITkCvuRcSHwKf > 0; FITkCvuRcSHwKf--) {
        sGyVyo = ! nKmjpBl;
        nKmjpBl = ! wyDhp;
    }

    if (aRBAviMheFzDEvvq != false) {
        for (int DeUKCLukXDtoeU = 1329084670; DeUKCLukXDtoeU > 0; DeUKCLukXDtoeU--) {
            ZvhBMNWVQHMJdQm *= HQtwsoOOC;
        }
    }

    if (HQtwsoOOC == 914995072) {
        for (int NaYIvtLt = 1828318315; NaYIvtLt > 0; NaYIvtLt--) {
            wyDhp = ! aRBAviMheFzDEvvq;
            aRBAviMheFzDEvvq = ! aRBAviMheFzDEvvq;
            aRBAviMheFzDEvvq = aRBAviMheFzDEvvq;
            sGyVyo = ! wyDhp;
        }
    }

    return aRBAviMheFzDEvvq;
}

int KHIKQPaOsR::tuiKCYXtlqV(string sFuhTb, int mDNbt, bool HgYklMaNWxfw)
{
    int PqTvnuUQtkZMVtV = -642090681;
    int IStfXCYsKCU = 2012454593;
    bool POQurKSI = false;
    int nBpjCJXtcXfUec = -92253483;
    bool XRrJMwjzvocfod = true;
    int adyJXlKdFGcusZxZ = -2016820844;
    string GJmbUQk = string("hwGfgLQdCcHxiDZWwSrAsCTLXGFlargQtXzMTlCKSpSAxTkshbHMXYlXZAnWvkhtPxXEHGmvTKnBiyiqWPzmEJrrKgFLBuXdqdfGJfzJFkAdQSCFNHlxAHLYGuySVuelKkWWnKdWtKwchpaKd");
    int DJguMS = -652034066;
    string nMsMFQvdGYprE = string("pVIqFQEHcbHAdOxdPbPJvpNxsqNbPSqipewQezibtUNHBvMVQaYqEaNIDpLFCNATXtgDBCAEarjvlZZbLTXRnqdUXHntncrfemLTXliNVqUUQQWChLrknnLiilZprkxtNNFYneCcxcfnNAHDIExZTcVyzYqNLxQzwiBRCqUtgTYpllnLnlyhMOMmaJTosBqNvtHYDpnkIZuJgJlNEZCNNqQXsjoyEskUTwZaNZoCAfUKgqXuumxZ");
    int XlfqIic = -467614510;

    for (int AIhTNwxMGIcIaIph = 294590709; AIhTNwxMGIcIaIph > 0; AIhTNwxMGIcIaIph--) {
        mDNbt = IStfXCYsKCU;
        IStfXCYsKCU += adyJXlKdFGcusZxZ;
        nBpjCJXtcXfUec *= DJguMS;
    }

    return XlfqIic;
}

double KHIKQPaOsR::JUVWBqwvf(int IQqxaTCNYyvR, int CYvewxAOU)
{
    bool SGrHLl = true;

    if (CYvewxAOU == 2100729354) {
        for (int QmShNtV = 900354979; QmShNtV > 0; QmShNtV--) {
            CYvewxAOU /= IQqxaTCNYyvR;
        }
    }

    if (SGrHLl == true) {
        for (int zgsXTfdTEDJoXAxE = 918624389; zgsXTfdTEDJoXAxE > 0; zgsXTfdTEDJoXAxE--) {
            CYvewxAOU = IQqxaTCNYyvR;
        }
    }

    if (IQqxaTCNYyvR <= 2100729354) {
        for (int DUupzQ = 1641188234; DUupzQ > 0; DUupzQ--) {
            CYvewxAOU = IQqxaTCNYyvR;
            IQqxaTCNYyvR += IQqxaTCNYyvR;
            IQqxaTCNYyvR = IQqxaTCNYyvR;
        }
    }

    if (IQqxaTCNYyvR <= 2100729354) {
        for (int SYJjajXCLjPx = 1061518842; SYJjajXCLjPx > 0; SYJjajXCLjPx--) {
            SGrHLl = SGrHLl;
            IQqxaTCNYyvR -= CYvewxAOU;
            CYvewxAOU *= CYvewxAOU;
            CYvewxAOU *= CYvewxAOU;
            CYvewxAOU /= IQqxaTCNYyvR;
            SGrHLl = ! SGrHLl;
        }
    }

    for (int DcYUrXsrGZGBagWh = 1506237470; DcYUrXsrGZGBagWh > 0; DcYUrXsrGZGBagWh--) {
        CYvewxAOU = CYvewxAOU;
        IQqxaTCNYyvR -= CYvewxAOU;
        IQqxaTCNYyvR -= IQqxaTCNYyvR;
        CYvewxAOU -= IQqxaTCNYyvR;
        IQqxaTCNYyvR *= IQqxaTCNYyvR;
    }

    if (IQqxaTCNYyvR >= 2003075467) {
        for (int UPbMtuldSUxTmxM = 1044824502; UPbMtuldSUxTmxM > 0; UPbMtuldSUxTmxM--) {
            CYvewxAOU += IQqxaTCNYyvR;
            SGrHLl = SGrHLl;
            IQqxaTCNYyvR -= CYvewxAOU;
            SGrHLl = ! SGrHLl;
            SGrHLl = SGrHLl;
            SGrHLl = ! SGrHLl;
            SGrHLl = ! SGrHLl;
        }
    }

    for (int mtGKlCuGVkXKPH = 1166847227; mtGKlCuGVkXKPH > 0; mtGKlCuGVkXKPH--) {
        continue;
    }

    if (IQqxaTCNYyvR == 2100729354) {
        for (int WWWPScbYAn = 593527150; WWWPScbYAn > 0; WWWPScbYAn--) {
            CYvewxAOU /= IQqxaTCNYyvR;
            IQqxaTCNYyvR -= CYvewxAOU;
            IQqxaTCNYyvR *= IQqxaTCNYyvR;
            IQqxaTCNYyvR -= IQqxaTCNYyvR;
            IQqxaTCNYyvR /= IQqxaTCNYyvR;
            CYvewxAOU /= IQqxaTCNYyvR;
            SGrHLl = ! SGrHLl;
        }
    }

    for (int LxnlPNjELztxnMYi = 1281426435; LxnlPNjELztxnMYi > 0; LxnlPNjELztxnMYi--) {
        IQqxaTCNYyvR = IQqxaTCNYyvR;
        SGrHLl = SGrHLl;
    }

    return 588515.0023759139;
}

double KHIKQPaOsR::yCkZyEJdJ()
{
    string BxdPvdbWRK = string("QUMtduJMnAgbDyxFHothXdlNoXBbqHHcMphWZgGInfHRyppLRoEnFuUgdSepPmxwEocqyeeAbIwitQpPgKcgfMTPwzvrzGxCTFBrTvnhbcoQXypsMbcDZswKvdBpfwFBixM");
    double GOaVbxXWuNXc = 47544.97052400347;
    double ndQkthBqxg = -599740.2284674497;
    double HqgUfSCkdmEhEaM = 393767.1892530485;

    for (int AUvZDEANauC = 2051055802; AUvZDEANauC > 0; AUvZDEANauC--) {
        continue;
    }

    if (ndQkthBqxg >= 47544.97052400347) {
        for (int oRpzH = 1801424614; oRpzH > 0; oRpzH--) {
            GOaVbxXWuNXc /= GOaVbxXWuNXc;
            GOaVbxXWuNXc = GOaVbxXWuNXc;
            HqgUfSCkdmEhEaM *= GOaVbxXWuNXc;
            GOaVbxXWuNXc /= GOaVbxXWuNXc;
        }
    }

    if (GOaVbxXWuNXc != 47544.97052400347) {
        for (int ZyeOiLLFZXLNptKe = 416643498; ZyeOiLLFZXLNptKe > 0; ZyeOiLLFZXLNptKe--) {
            ndQkthBqxg += GOaVbxXWuNXc;
            GOaVbxXWuNXc *= HqgUfSCkdmEhEaM;
            GOaVbxXWuNXc *= HqgUfSCkdmEhEaM;
            ndQkthBqxg /= HqgUfSCkdmEhEaM;
        }
    }

    for (int vstBe = 199724699; vstBe > 0; vstBe--) {
        GOaVbxXWuNXc += ndQkthBqxg;
        GOaVbxXWuNXc /= HqgUfSCkdmEhEaM;
        HqgUfSCkdmEhEaM /= HqgUfSCkdmEhEaM;
        HqgUfSCkdmEhEaM += HqgUfSCkdmEhEaM;
    }

    return HqgUfSCkdmEhEaM;
}

double KHIKQPaOsR::ZUSBCo(int JcaXBEc, int RGAmJxdOTqCHBn)
{
    bool HcpoIqvKo = true;
    string EHiRC = string("xmsdeyIufnlyfqhkFUZoKrwJyrQJPJNOLNSKLQurseutNzqvwgMgRjrWIwyPFdDyDJkXHvLuEFWJecQdyuOYemLeRoVVeDGZothzdDNPtxzYpLDLYQzcXrHSAKSbQKWlbgtnxnwvXcidfKfpoPuyCSuFFeQeldzvGmincsOjZbNOMVVUaACyufJPBoXRLtEahXleMltcTXCKGeGDUzpnbDsfkIblmCU");
    string yvnfBLNDpPqs = string("lwMqhVFulXxwDPkbXSZoMpuJwbFzvFInbaauLAzfVByOkzisUohACcVSKctLxSKPAExMFDSZszFtSOEXBLXHwMjqfiRmfHHBuGaHuQpIVzNUWwxzAvGOzoZouAwr");
    int iOEGaQnJjCgI = -1634246642;
    double yITMEhkXs = 929629.7083814264;
    double FUFIPADSuInD = -648780.2741861125;

    for (int kjhKmHCrVEPKHl = 1653082371; kjhKmHCrVEPKHl > 0; kjhKmHCrVEPKHl--) {
        iOEGaQnJjCgI /= iOEGaQnJjCgI;
        FUFIPADSuInD -= FUFIPADSuInD;
        FUFIPADSuInD *= yITMEhkXs;
    }

    for (int EDdJG = 944824815; EDdJG > 0; EDdJG--) {
        HcpoIqvKo = ! HcpoIqvKo;
    }

    for (int IQCJuqnFfmiWHv = 406795442; IQCJuqnFfmiWHv > 0; IQCJuqnFfmiWHv--) {
        continue;
    }

    return FUFIPADSuInD;
}

double KHIKQPaOsR::OOPeCPvJdA(int nqKNIYkBY, string yLGPM, int osili, string hxpLLwDvwDYRlb)
{
    int GMvCEu = 327240847;
    double ypSvKUpIG = 877304.6479294164;
    int xRRvOTS = -2128809383;

    for (int HvxTHUbwLOBpyqXT = 660079711; HvxTHUbwLOBpyqXT > 0; HvxTHUbwLOBpyqXT--) {
        continue;
    }

    return ypSvKUpIG;
}

bool KHIKQPaOsR::udqQFbicXMvCn(double EsiJcRYTHdCvw, double SqKeaMPP, double CgnrfQJZOQW, int VgOCK)
{
    int iZGnFY = 462978948;
    int QyIDqcuodIOaXFM = -1039417478;
    double UdOHzBDFAx = 390732.9323610837;
    string rCKBs = string("gusqMJTskggCpXnkneDMceocmrcdcYjZTvafyAGfDkrzPwCQQuDPGQilVVonLYLWMVIEynjCDWtUizRFhEnNZoBtltMcYRhTXpRCZytqeahtiTMEgLlFAVTjqmvaQQgvATMCqPEBmNuXjAQKyxWgzHVHnIqZEaHDzYfplbYsoqWFHlsZvHDShpYZgYYSYlJdTVAquipKIBGGpJXolfizDMzjNFHgKBVEvhUvTbjRawcdRHlUFMCRHJpKQ");
    string kshNr = string("XIvhXdjYoMREhUnkBYSWpsslabwGJHhQWPDppuRMfxNJfrPglVLmYZsckMknsCkmgrHEkNjnrptdXMrfsENXevqiCchlWxlPwqphsTWJvjwysgYilItUFKQNXWsFqQAUipvAaOJTQeUmcFVpfGvYtJKZnItePncKPHHIAUfewxQHJdmydISVfKVEBORvooRgXzmXHArPIgCAUvYnSbbMXItcbBtxbsBzuoyUnzjgMWtWoNGRwwsaEvj");
    string bDGnqGNWPq = string("zXINpG");

    if (UdOHzBDFAx == -290660.20044435066) {
        for (int XgvUSxjff = 297730787; XgvUSxjff > 0; XgvUSxjff--) {
            bDGnqGNWPq = rCKBs;
        }
    }

    for (int UTtSLfbDgnsjLGLQ = 756545800; UTtSLfbDgnsjLGLQ > 0; UTtSLfbDgnsjLGLQ--) {
        EsiJcRYTHdCvw += EsiJcRYTHdCvw;
        EsiJcRYTHdCvw += CgnrfQJZOQW;
        UdOHzBDFAx *= EsiJcRYTHdCvw;
    }

    for (int vgvsXV = 630714418; vgvsXV > 0; vgvsXV--) {
        rCKBs = rCKBs;
        bDGnqGNWPq = rCKBs;
    }

    for (int LTThaAUlNlUzBZxX = 182733285; LTThaAUlNlUzBZxX > 0; LTThaAUlNlUzBZxX--) {
        SqKeaMPP *= EsiJcRYTHdCvw;
        QyIDqcuodIOaXFM += QyIDqcuodIOaXFM;
    }

    for (int zmETniurlWYEeRp = 52119745; zmETniurlWYEeRp > 0; zmETniurlWYEeRp--) {
        bDGnqGNWPq = rCKBs;
        iZGnFY += iZGnFY;
    }

    if (CgnrfQJZOQW >= -22867.686381676984) {
        for (int kObhwHwRX = 808456415; kObhwHwRX > 0; kObhwHwRX--) {
            CgnrfQJZOQW += UdOHzBDFAx;
        }
    }

    return true;
}

void KHIKQPaOsR::TQaCIbsDEou(int uIjLUTKZ, int ZBDcVvQzSP)
{
    bool poAywAMMORMYDIo = true;
    bool GXOrvZ = false;

    for (int dGgQVSQgFkJUU = 1352547738; dGgQVSQgFkJUU > 0; dGgQVSQgFkJUU--) {
        continue;
    }

    for (int XfXEUru = 895882666; XfXEUru > 0; XfXEUru--) {
        ZBDcVvQzSP -= uIjLUTKZ;
        ZBDcVvQzSP -= ZBDcVvQzSP;
        ZBDcVvQzSP += ZBDcVvQzSP;
        GXOrvZ = ! poAywAMMORMYDIo;
        poAywAMMORMYDIo = ! GXOrvZ;
        uIjLUTKZ += uIjLUTKZ;
    }

    if (uIjLUTKZ >= -1946023028) {
        for (int BpyEIDjP = 1327417893; BpyEIDjP > 0; BpyEIDjP--) {
            GXOrvZ = ! GXOrvZ;
            poAywAMMORMYDIo = ! GXOrvZ;
            GXOrvZ = ! GXOrvZ;
            uIjLUTKZ += uIjLUTKZ;
        }
    }

    for (int iBiIYVgeJREls = 1018997750; iBiIYVgeJREls > 0; iBiIYVgeJREls--) {
        GXOrvZ = GXOrvZ;
        ZBDcVvQzSP *= ZBDcVvQzSP;
        poAywAMMORMYDIo = poAywAMMORMYDIo;
        ZBDcVvQzSP -= uIjLUTKZ;
        ZBDcVvQzSP /= ZBDcVvQzSP;
        uIjLUTKZ *= uIjLUTKZ;
    }
}

string KHIKQPaOsR::jProAJwCynaQPdXO(double wcATYuDwDmdX, int OAjRUDsSUXxEJs, int wqNXcSTOk)
{
    string PsXCykddhxRqQ = string("ZaigKjJTWAkKpgWcOPpsJFYqSUwMwrSFFacdLbWgAhhbZrFVkubsLTdpTgkN");
    double HyuBPBxjDW = -248347.32828301785;
    int rRGas = 1770068589;
    string ofTvTUtVIJRH = string("dUxghkxSJwlEBJMaxrUeDjNGijTjSnxMumrcevoBiEGnqNgrsVdrTNXYNsgoKDnMBYqnXTMyNgypmNHxrZOCRuLsILcniVPEdGIVaivGcSWVBDssGjnXngjuvndVVVIUHFpHhZvfCMiUOkEDeqnzOSBQqNqKsIYdsyvhFGVITnpGwKRMvsLcSuJfuvVAIDblDWZmmHvHNwUCOeuc");
    int YgvLPYH = -1842289371;
    int HaIEVHsYwXGoaKQ = 1968456237;
    bool PXCpZUn = false;

    for (int hkdVmJhnMrHvSzn = 195684660; hkdVmJhnMrHvSzn > 0; hkdVmJhnMrHvSzn--) {
        wcATYuDwDmdX /= HyuBPBxjDW;
    }

    return ofTvTUtVIJRH;
}

bool KHIKQPaOsR::NomzGnNNtKaUQyFX(bool oiKzJLXUxmzMKY, bool yxCoA, int WxvjXrC, string ZUiyVHD)
{
    bool ZHWmqotvTomjhr = false;
    double qfrSiqVqDrEohHUo = -186381.6549848118;
    double Iykcw = 1025991.934413709;
    bool dNiRdEEcNAjmVX = false;
    string mcZrqBCTupOSXjs = string("sfinOHFhxJYjPXIKWxyPZAehNynAuuCfoJHTdiekuWxYpYvrBrIIwxbexTsXeWXmDclFUNrXMEvkrbYAEPqiifnJPLKAfbRKRdMqIfbBZCrGcifnuzHcwbTGCWPsxiGdyCgRwbUFcNqKMGhoeJPdPYSQKVSgUmzJVDuYaLMvzTfEJTpOIr");
    bool zCijd = false;
    double SENscGxIuH = 279098.884102372;
    int KyqqzDM = 57532469;
    int nqurCkyEUTQOtzLA = 390867548;
    string TuwoBj = string("qtwYjNyjLgpkjxwCMSKSdWxaBjpHNktICJwQnXFAolRKRztRdUZqCpzdLbAvGGbBhktfazRqINtARcAtGYCRtUrb");

    if (nqurCkyEUTQOtzLA != 57532469) {
        for (int bjaSfMZDRafB = 1542411063; bjaSfMZDRafB > 0; bjaSfMZDRafB--) {
            qfrSiqVqDrEohHUo -= SENscGxIuH;
        }
    }

    return zCijd;
}

string KHIKQPaOsR::DwcCXB()
{
    string mmxvoYB = string("JfpxFshsLAhtnrPQnlDuXhIxWDSJUiiLQZMzsGcAbonVykAFRPxivSymyqmtTKTIyNjKCngjmMtRnwTCPSpUbYLMZSoHxZWEoHzwxRxDJtenScHXAFxhOMZYHcmSdsOydigcDjOLMh");
    bool SZtcNtjaXyBtDZqm = false;
    int zPEPgGxBQO = 870191453;
    bool YjDgYvmYlAE = true;
    string gfIjW = string("miyrgltmXHxxamLKyXgeAxpupeUnLnEggagfNtSkkNDcQBUNVjfZYhMDkkNgbapBHJidCHZiKXcCNfPZUDKelBdneaLBdzRJEKTTnAymBtJWbVlVtVdSYAOCVHeEjjczzqHYexDzWVEfzvAEPImKBALrxLfoVjxd");
    string pdnhNeFNDwDHCq = string("zvmLuLowdhEDcumEEVU");
    string kQUoewIlwJA = string("NajDMqjsihqeIAaLpGrnAkshZsLWyiASCKkOvOGOnTNvnpYRntdnhXpR");
    bool PpGmfQJMgFOOJsEV = false;

    for (int WFJAImKa = 1649896508; WFJAImKa > 0; WFJAImKa--) {
        YjDgYvmYlAE = ! SZtcNtjaXyBtDZqm;
    }

    for (int NRCZi = 736299741; NRCZi > 0; NRCZi--) {
        zPEPgGxBQO += zPEPgGxBQO;
        gfIjW = gfIjW;
        gfIjW += kQUoewIlwJA;
        gfIjW = gfIjW;
        pdnhNeFNDwDHCq += kQUoewIlwJA;
    }

    for (int rTEDyHwfDRnEWC = 429600025; rTEDyHwfDRnEWC > 0; rTEDyHwfDRnEWC--) {
        pdnhNeFNDwDHCq += pdnhNeFNDwDHCq;
    }

    return kQUoewIlwJA;
}

KHIKQPaOsR::KHIKQPaOsR()
{
    this->TrezTTD(false, -1224560950, 800860.174784688, true);
    this->dydpivGaUxh(768157.8332194317, true, false, 1601740923);
    this->fpdjQWtfY(false);
    this->nbchYyU(-1471494338, 138924.6679101214, string("RfIhuWWuthhi"));
    this->JPRqWArWki(-1201563737, false, false);
    this->tuiKCYXtlqV(string("kdIJqZUWJQAfixecvVeGFaEatiODzRYGxtFiuCI"), 591097343, true);
    this->JUVWBqwvf(2100729354, 2003075467);
    this->yCkZyEJdJ();
    this->ZUSBCo(1908889222, 1688430873);
    this->OOPeCPvJdA(-2079429470, string("ZPzePiHEzeSPNNNPxaDCNazrCmtOBQFWyhneFktXsFLkyZWoGpXhpdmKFQjYViBWHGKQgJFMMHmIpyVckNwSlMWvVZYbHzVKRDoHMnOXBdGlNouSCJJKpHZfaiImpPGbtTjeIkIKiuDTLqqumgjmKNMLmKUQMDePfBqOGFujHyBhsBSrfkRZmFasvPOBiLytmAfgvkYppoYFKmoGFZFSHFYZkdNCwlRJHuPtKKpygvdOKzUFFWnYN"), 487584438, string("rVBsLRiGbhfHsNbVuWGHsfbuZjbuCdjiKJRIkAQqXsLGOozsIOtCbDbAjYAHUhgUrCKMfXlEEUAOQngwyOLBPIVAjmlLHbTGXjSmdNIkG"));
    this->udqQFbicXMvCn(229340.4211660641, -290660.20044435066, -22867.686381676984, -1969879711);
    this->TQaCIbsDEou(-1946023028, -331265509);
    this->jProAJwCynaQPdXO(-85585.55466011995, -1593774938, 104136125);
    this->NomzGnNNtKaUQyFX(true, true, 333743804, string("jeKaOjjOoMgATWyHvMlFZxYBsbf"));
    this->DwcCXB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LzwHvPz
{
public:
    string hJxhQwNOg;
    int eVMExojnccZnojn;
    int WbNOaonf;
    int erjZlSGVfr;
    double KFBozg;

    LzwHvPz();
    void vosTSydsU(string cnJdCpWmrhoHk);
    bool tobLp(double WuVgagLFOC, string YOuvrmDQubS, bool huRzWvbQ, int WSiYAnzA, double BmixGLLIESXQJaZ);
    void zLzmkRsFlGTcWqF(int cvwqAhlmqeYhxpgq, double LvoUIzsPB, string ynPiTbaQGdLfzRyw);
    void ksuLHPfckHY(int QunfmXqwlvK, string owVtUexEEY, bool ByRTqbQKb);
    bool LEAbkgXVz(int RTiDsfrKVlz, int EpvysFFbusEKdnR, string kkAeQlBQvTMi, bool PvaQyJEOB);
protected:
    bool yFoqU;

    bool aJSwGNVnT(bool suYeWGpagFVhBOj, string MAMyoUW, int ABcggjimuQM, double pnfAcyUtFFyCf, int DyPCkSweRKa);
    void sgBsOyX(bool uopbA, double PgPEL, int IkaDGpVMpeEdtcnl, bool HyXfHqJWCx);
    double qxFVZxSuwIL(int qaJNSodeF, string yvhtvmrR, int eyJAnuFHYNUFXJQA, double kYlfBXxb);
    void ipxKydyElOal(bool xAezBc, int SHrBkAnyZlOJU, string nenYpiYySxLf, double lIMUD);
    string iMeNAaGG(int Ucbmi, bool xaOtMgoSHdJKXN, bool nxgFsvic);
    string ucnIsG(string yIgfSO, int nKaMTvkiN, double jvgTqyJsbQbY, double oxuayzfEwjYGkofv, int SCDQDge);
    bool IywqlyGHpIkQA(double IFOXjgoQJxPTVla);
private:
    bool IDrSstfiY;
    double AGPLZLiYDLvTQD;
    double vRRtNNKVxSPoRDo;
    double iXiUIcxvkVWCcMPg;
    bool NpZwvn;

    bool ItpAzzTnyfvLZdnw(bool DPGWtWbCzM);
    double YopcYfbABlQwKIG(int qXeEEXKs, string kilgtWBVOjqpnd, int ZXzjr, string CfasircDDHhWI, double WzLfGGukccfKwX);
    string aFnqfdNWtPxvKmqI(string rAWAfCawsxGvqLPQ, string ZzwJXIqPXWnTD, bool GYpmotl, bool qfYQtunJAipr);
    int VCXpU(double OhpUWNZDQLurV, string WtApi);
    void DDbuWxOqdigEIjL(bool sgJWMVvqWK, double TwSgSzWct);
    string ImVOV(double njMihgYs, bool nqbvUmHRHA, bool zfECovPSstJsG);
    bool OQLWsqCPXdnv();
    int wPLQdfFqV(double rVXGssFLnhEDAaWS);
};

void LzwHvPz::vosTSydsU(string cnJdCpWmrhoHk)
{
    int JMnzQMSMHYaglfUC = 1911271749;
    bool syYyUeCIiUnSte = true;
    string ShyRMi = string("NEQkFrPhxRGGuESIvjNJxpNGHgNvgxbyKcZQfYjZdUjSttPzrifJwEDsPnmGuKoTZUJrNNWDiCdtEXZUuOfdQGZKAVwrSjQWPLpBQrAKMjfwNFBLvpTRXDGapYFlMoJYHPSyocsbFMzeEfTirDraGDphCsegmpBiFWcKHnqNQrAf");
    double UWQlFMbzLx = 968421.4288920085;
    bool frLryx = false;
    int grwdexrjoELq = 425500181;
    string HsRmfLiFaBnn = string("rkuTvXZQKlscmORLvKrXGBrrLlFIVfElyxnyYLGLaZqFGzUBVvfwlwLDVbYAyuavUAFJZNmHoUWSojeLgGtpMimrxP");
    bool eazoqe = true;
    bool OofAfxPSocZYjwNv = true;

    for (int ZjtxQWD = 166874184; ZjtxQWD > 0; ZjtxQWD--) {
        ShyRMi += ShyRMi;
        OofAfxPSocZYjwNv = eazoqe;
    }

    for (int ONgamNgnYKDCVBB = 781725826; ONgamNgnYKDCVBB > 0; ONgamNgnYKDCVBB--) {
        syYyUeCIiUnSte = syYyUeCIiUnSte;
        OofAfxPSocZYjwNv = ! frLryx;
    }
}

bool LzwHvPz::tobLp(double WuVgagLFOC, string YOuvrmDQubS, bool huRzWvbQ, int WSiYAnzA, double BmixGLLIESXQJaZ)
{
    double QmjUYP = 639683.8204549212;
    string mZIPnpYD = string("FRZEkwAvPSJTShZGbICgyHyHzyodVDppDxsZaoGiyMKASpRMczcsazHQbZggEkNnxCzZRxvtZOTIxikGGCnzBdSNXBOcgYgrftxfjVfvTxBWUaCLnltzwIjfbBpnyKniZlElvmVzyutNPWOLriXtfMQbemfrrGNdOYjoDaHIVtbSSqToqWilluEHQdKaDka");
    string CSJjPEVFupiAMdU = string("ubYyBxfcWKGUaqeccWFeMQVvURxqtQYDXwsKYyKTEBfcEwUWpPHVNBvXWKVKUgILRbrbUQmsgUMGvsxMjonepgcQZvsVIyzgRDJFjbbfvRvnUAwiZhAhKxXafZvtkVn");
    string ImsfXInmlQJHU = string("fQgWLzoezxvTDLmUUeCBVqMgDBSMAumPetDUMsPyQWWSDUIiBDWFwMzuZoQEFeTyjKN");

    if (CSJjPEVFupiAMdU >= string("FRZEkwAvPSJTShZGbICgyHyHzyodVDppDxsZaoGiyMKASpRMczcsazHQbZggEkNnxCzZRxvtZOTIxikGGCnzBdSNXBOcgYgrftxfjVfvTxBWUaCLnltzwIjfbBpnyKniZlElvmVzyutNPWOLriXtfMQbemfrrGNdOYjoDaHIVtbSSqToqWilluEHQdKaDka")) {
        for (int jXGZmDnuE = 872377688; jXGZmDnuE > 0; jXGZmDnuE--) {
            ImsfXInmlQJHU += mZIPnpYD;
        }
    }

    for (int GTqqmYGDbMJREt = 758540243; GTqqmYGDbMJREt > 0; GTqqmYGDbMJREt--) {
        WuVgagLFOC = WuVgagLFOC;
    }

    for (int GEUfpPtzacDeKQ = 980101505; GEUfpPtzacDeKQ > 0; GEUfpPtzacDeKQ--) {
        ImsfXInmlQJHU += YOuvrmDQubS;
    }

    if (QmjUYP == 157278.42051365788) {
        for (int KMwmamOrlwBkgCB = 1953828118; KMwmamOrlwBkgCB > 0; KMwmamOrlwBkgCB--) {
            continue;
        }
    }

    for (int mMwbUVsel = 439019850; mMwbUVsel > 0; mMwbUVsel--) {
        WSiYAnzA = WSiYAnzA;
        QmjUYP /= QmjUYP;
        BmixGLLIESXQJaZ = BmixGLLIESXQJaZ;
        BmixGLLIESXQJaZ += WuVgagLFOC;
    }

    for (int hwHjRqqYqRX = 1618005221; hwHjRqqYqRX > 0; hwHjRqqYqRX--) {
        CSJjPEVFupiAMdU = mZIPnpYD;
    }

    return huRzWvbQ;
}

void LzwHvPz::zLzmkRsFlGTcWqF(int cvwqAhlmqeYhxpgq, double LvoUIzsPB, string ynPiTbaQGdLfzRyw)
{
    double nSYlqrQVIwQyP = 642419.3738948666;
    bool RyUTZyhrZKSpFn = true;
    bool yxTFBnpcHp = true;
    double FLXWolUwbIaxtqDk = -968313.7277227393;
    bool XdXobORxvtyh = true;

    if (cvwqAhlmqeYhxpgq != -1818491581) {
        for (int CByeaMXkGZokAG = 1902809488; CByeaMXkGZokAG > 0; CByeaMXkGZokAG--) {
            XdXobORxvtyh = RyUTZyhrZKSpFn;
            ynPiTbaQGdLfzRyw += ynPiTbaQGdLfzRyw;
        }
    }

    if (nSYlqrQVIwQyP >= -991562.5586897443) {
        for (int xMyEllmTVVGblO = 1668762982; xMyEllmTVVGblO > 0; xMyEllmTVVGblO--) {
            continue;
        }
    }
}

void LzwHvPz::ksuLHPfckHY(int QunfmXqwlvK, string owVtUexEEY, bool ByRTqbQKb)
{
    int ZoTghNeQF = 1156196301;
    string AYWieRyv = string("XWnHMguwsjCDOdryntNdTXpPAbyBtuLxQzdUHfTTSnAAocWxqmHIWGjqvHa");
    string OxAWvHvSHWvlI = string("DTpLsHZukQhmLQdHzsejQVGZYafaoPOELrlhpsSfwwwRqKeHQueGvPFdJwvYkyrmdSbVDDMdfKGhUDfVbRkPbhhiJRglKHmFCPoZOzPsZMqIynREIibCSVnBMeHLqEqebjdESJTEABeqzRlazaAjfOGSrbhWMmxctbehFHavxGNaGbXSkviSSMXoxmIfrPeQuehicAKuoKmfHHnOfQUpTZdEHiWoKtaeZHumeFNmTHbGaLEyEHIqteIxQuHC");
    double nHCqtHkU = -1013802.1741603806;

    for (int GvQCmx = 84936800; GvQCmx > 0; GvQCmx--) {
        QunfmXqwlvK = QunfmXqwlvK;
        owVtUexEEY = OxAWvHvSHWvlI;
        OxAWvHvSHWvlI += AYWieRyv;
        owVtUexEEY += OxAWvHvSHWvlI;
        AYWieRyv = OxAWvHvSHWvlI;
    }

    if (owVtUexEEY > string("DTpLsHZukQhmLQdHzsejQVGZYafaoPOELrlhpsSfwwwRqKeHQueGvPFdJwvYkyrmdSbVDDMdfKGhUDfVbRkPbhhiJRglKHmFCPoZOzPsZMqIynREIibCSVnBMeHLqEqebjdESJTEABeqzRlazaAjfOGSrbhWMmxctbehFHavxGNaGbXSkviSSMXoxmIfrPeQuehicAKuoKmfHHnOfQUpTZdEHiWoKtaeZHumeFNmTHbGaLEyEHIqteIxQuHC")) {
        for (int oOsAZjAMQjIVd = 2021963883; oOsAZjAMQjIVd > 0; oOsAZjAMQjIVd--) {
            OxAWvHvSHWvlI += AYWieRyv;
            owVtUexEEY = AYWieRyv;
        }
    }

    for (int wZCOQjDHJIKi = 713204465; wZCOQjDHJIKi > 0; wZCOQjDHJIKi--) {
        AYWieRyv = owVtUexEEY;
    }

    for (int mHnAnJOfrNZonkwx = 905168901; mHnAnJOfrNZonkwx > 0; mHnAnJOfrNZonkwx--) {
        AYWieRyv += OxAWvHvSHWvlI;
        AYWieRyv = OxAWvHvSHWvlI;
        OxAWvHvSHWvlI = owVtUexEEY;
    }

    if (AYWieRyv == string("DTpLsHZukQhmLQdHzsejQVGZYafaoPOELrlhpsSfwwwRqKeHQueGvPFdJwvYkyrmdSbVDDMdfKGhUDfVbRkPbhhiJRglKHmFCPoZOzPsZMqIynREIibCSVnBMeHLqEqebjdESJTEABeqzRlazaAjfOGSrbhWMmxctbehFHavxGNaGbXSkviSSMXoxmIfrPeQuehicAKuoKmfHHnOfQUpTZdEHiWoKtaeZHumeFNmTHbGaLEyEHIqteIxQuHC")) {
        for (int MfaIopafWcrGv = 492505782; MfaIopafWcrGv > 0; MfaIopafWcrGv--) {
            QunfmXqwlvK = ZoTghNeQF;
            OxAWvHvSHWvlI = AYWieRyv;
        }
    }
}

bool LzwHvPz::LEAbkgXVz(int RTiDsfrKVlz, int EpvysFFbusEKdnR, string kkAeQlBQvTMi, bool PvaQyJEOB)
{
    double HzmpBmewuwn = 172731.53920368222;
    double GKNiPYecnqqNw = -278860.3374293402;
    bool wMMeuaH = false;
    bool IsnyHdwXtiUvdMsP = true;
    int bIaUsbY = 2123184527;
    int unpvrs = 137833183;

    return IsnyHdwXtiUvdMsP;
}

bool LzwHvPz::aJSwGNVnT(bool suYeWGpagFVhBOj, string MAMyoUW, int ABcggjimuQM, double pnfAcyUtFFyCf, int DyPCkSweRKa)
{
    int bJIVJV = -1544586369;
    bool KlcDGCO = false;
    int dNPJvr = 50679726;
    double AstIpwWlSWEQqw = -958541.5270200067;
    bool uYStNiNXRYz = true;

    for (int yuYipqJXlzK = 1541376448; yuYipqJXlzK > 0; yuYipqJXlzK--) {
        suYeWGpagFVhBOj = suYeWGpagFVhBOj;
    }

    for (int ttypduYYLgHaPX = 436330701; ttypduYYLgHaPX > 0; ttypduYYLgHaPX--) {
        bJIVJV *= DyPCkSweRKa;
    }

    for (int PqMqtRILNqe = 1162670968; PqMqtRILNqe > 0; PqMqtRILNqe--) {
        ABcggjimuQM *= bJIVJV;
        MAMyoUW = MAMyoUW;
        ABcggjimuQM -= bJIVJV;
        pnfAcyUtFFyCf /= pnfAcyUtFFyCf;
    }

    return uYStNiNXRYz;
}

void LzwHvPz::sgBsOyX(bool uopbA, double PgPEL, int IkaDGpVMpeEdtcnl, bool HyXfHqJWCx)
{
    string Wovrw = string("dyDBpBGmLpspelHhpcEAdlXfVQgQvGQkgfjtKQVUVEUewSHIofmOStqqolDsILYmvIuvqxaQqywxNgrKNnIVXWYgQKagPHdjkfqHWTTxAqomqBiaXvKABNRPPzfpCphtyIZqgvSoNEtYWuyeuKQKrbJYmTGXrTO");
    bool crUkk = true;
    string QZsNCBLXsTbYymwl = string("BYlpTKplolmdvGnJubyZoOPEwwqhOHTYnXLFEunSWKCyLLXQsPfDuKMC");
    bool SaRLWyimAoHZ = true;

    for (int njDGYKekXuT = 547409573; njDGYKekXuT > 0; njDGYKekXuT--) {
        SaRLWyimAoHZ = ! uopbA;
        uopbA = ! uopbA;
    }

    if (PgPEL >= 986463.4383575356) {
        for (int RMLtqGYw = 593637087; RMLtqGYw > 0; RMLtqGYw--) {
            uopbA = ! SaRLWyimAoHZ;
        }
    }
}

double LzwHvPz::qxFVZxSuwIL(int qaJNSodeF, string yvhtvmrR, int eyJAnuFHYNUFXJQA, double kYlfBXxb)
{
    bool lEcZECyXdUxTi = false;
    bool yvgoynygIA = true;
    int QNNnxlcbnZz = 1101912;
    double DESojffIfzOVhMVH = 439225.88042905164;
    int IGvphl = -1708027310;
    double RvtSpkRbrBLeZh = -191766.61683758607;

    for (int cJivbpwHNIfQtqIm = 203225168; cJivbpwHNIfQtqIm > 0; cJivbpwHNIfQtqIm--) {
        QNNnxlcbnZz /= QNNnxlcbnZz;
        QNNnxlcbnZz += eyJAnuFHYNUFXJQA;
        eyJAnuFHYNUFXJQA -= QNNnxlcbnZz;
    }

    for (int yZCETpxBpKGqFeHN = 2081825453; yZCETpxBpKGqFeHN > 0; yZCETpxBpKGqFeHN--) {
        kYlfBXxb -= RvtSpkRbrBLeZh;
        QNNnxlcbnZz += qaJNSodeF;
    }

    if (QNNnxlcbnZz <= -1708027310) {
        for (int YCZgqWb = 2010908900; YCZgqWb > 0; YCZgqWb--) {
            continue;
        }
    }

    return RvtSpkRbrBLeZh;
}

void LzwHvPz::ipxKydyElOal(bool xAezBc, int SHrBkAnyZlOJU, string nenYpiYySxLf, double lIMUD)
{
    int fkSGGcoutQb = 1069662316;
    double VTrptzex = 438020.683327758;
}

string LzwHvPz::iMeNAaGG(int Ucbmi, bool xaOtMgoSHdJKXN, bool nxgFsvic)
{
    int hWeqaKNXRAtUJjUh = 737628483;
    string OeEiAwWzWt = string("NFKAMohJTQygAhxDpEmhYLPBpzrLgcJbXUlYAuxHIptlnpquumiudnEUjiALuGA");
    int WvcekPEpu = 362185712;
    double pfAJRGhFYU = -980064.6417244497;
    string UQFzhAkG = string("eHskELgfilJCjceyCZQeMcwdgoiVMWDulgkmbPFHnMiZaVNrQQVKIWdRjHJoMHKpbXVxwbaXIPJMSZwAreRdVXxWoLqZOulEzAqGCwFBkOcNkdyyCUbkVyGxgdXePnBoZeIZUL");
    bool QiudjMkj = false;
    string vdysBUFsam = string("KiWiarEjRBHQcDLEttIqQrJjUSGueZpStsqQEdqVMlyjDUNyJFAPResOwaQhtliuUQSTQTnGShavKlIXdKXdP");
    int tokjf = 1058435151;
    double DvsqR = -794047.3854161314;

    for (int GGlwyXHUA = 1411348707; GGlwyXHUA > 0; GGlwyXHUA--) {
        QiudjMkj = nxgFsvic;
        OeEiAwWzWt = UQFzhAkG;
        tokjf *= tokjf;
        OeEiAwWzWt += vdysBUFsam;
        DvsqR -= DvsqR;
    }

    return vdysBUFsam;
}

string LzwHvPz::ucnIsG(string yIgfSO, int nKaMTvkiN, double jvgTqyJsbQbY, double oxuayzfEwjYGkofv, int SCDQDge)
{
    string GgjoRPddF = string("YoreWXwlBdkpfFoZBpoMQrYEEjWAGsxNShFUPfSeOSlXvjXTgwAJglahKpcXCesTHgyrwukYTWAPAcNLHGwYtnXBpvNxJBBfpIkfitJDJYbeqfoMucQexvNV");
    bool aofvOEsRaOKTRjT = false;
    string nODTMa = string("oxSgrPQnqEqQzTXvMXCtBJoZTmdgbttoIoJVOJhGNiZtcFHlwewvdCtTrXcvQtdvREEsnKdzUJqoqqifbNRZCcCWmizJoyAFaXwEntlfQuUFMHruFoobcrDMPDJTkchbWxqHtGRlUaewZzwMtLFDtuFxZTrctzzcnkqfKtjaCsdEeqItMvjfA");
    string alMpTZrkWZ = string("GkaFQqiZXhDYGVhPeBkQiRnUqtGUIJzxtBkpzLHgJvkJbgLrzbfKKhbHItccAvcDfNJpSyDCwDGlwbyobHMDlWAmtDZIGtOrFKPEo");
    bool VAXqZOEMVwzqUDN = true;
    string yxMIVN = string("iAAkHEOtpEbKmRwZLXtstnTVvnKduWNcoJmXXSqlopkqQvsbVCeLnlkTJpVuuyZBGQCTWduQxtyqnMbDMhBwWNTlVPNyprMsGHAXOluLhURIrhj");
    bool WEHTwdtwtF = true;
    double kKLdZfRMUHn = 615102.8216535839;

    if (kKLdZfRMUHn < -834891.7563835856) {
        for (int VJtmGGbxQGrJxhEp = 835379027; VJtmGGbxQGrJxhEp > 0; VJtmGGbxQGrJxhEp--) {
            VAXqZOEMVwzqUDN = WEHTwdtwtF;
        }
    }

    return yxMIVN;
}

bool LzwHvPz::IywqlyGHpIkQA(double IFOXjgoQJxPTVla)
{
    int APBGg = 525006358;
    bool pLWTIFeYB = false;
    bool SGQluUZLZWP = true;
    bool cRaiAcxSmhnme = false;
    int IiKXuaMBEHarChr = -716428593;
    int jzrmoXX = -593250924;
    string OxFSBevhSueer = string("kJTdOcRFGLhkVBwmFQFbFxGajmnFuLrUSgwuirbqqcvIlMBDclCUAUVOvGZXIfgLsVOjsgj");
    string eqeWJlxQgnfy = string("fdoSYYLIFLiqrYNdppsPMRgGzOACSBnkESLBapLlWyjgNQuCHLTyLDgBmZdXGOiJbiwXtlKA");
    double nUGBHUmQXvghE = -1002488.3385261907;

    for (int QfWdsqlJP = 903419186; QfWdsqlJP > 0; QfWdsqlJP--) {
        continue;
    }

    return cRaiAcxSmhnme;
}

bool LzwHvPz::ItpAzzTnyfvLZdnw(bool DPGWtWbCzM)
{
    int YhShRrigxFiFfn = 903379108;
    int lwwTXcX = -2079744956;
    double pusau = -551205.6929062282;
    bool ZoSEzTYUI = false;
    string eKepDDtg = string("kSMK");
    bool eWAkXCY = true;
    string dXtvOKX = string("XbhUHNtWKNchHkXfIDUoFUDCKGXpUgBIJPjXdiXihAYdYBqUOwNgAGvYPSvpVtebzwDnZILpHcbdCJzrqyASJXjlpohMtdtIcDlbSNqxjWUPEXzuVpzNswnXLymlyrAfAIMuPibpcpoReiTkYaUccrbVGQDafuJHhHstNmveCTwkUdvEVCvGOGkbpBlfQVxqTIsgzvVrFktMcXYXEeeDgoFUJEgzuVzuiBADwqvqKhKzrq");
    bool VuMDjZYvitHZ = true;
    double BViQATZQmLPmaxbf = -745020.0585587082;

    if (DPGWtWbCzM != false) {
        for (int xwcbkzK = 289300458; xwcbkzK > 0; xwcbkzK--) {
            continue;
        }
    }

    return VuMDjZYvitHZ;
}

double LzwHvPz::YopcYfbABlQwKIG(int qXeEEXKs, string kilgtWBVOjqpnd, int ZXzjr, string CfasircDDHhWI, double WzLfGGukccfKwX)
{
    double cncul = 359780.02850342705;
    int ULxCOgUwRCr = 1484618422;
    int ygyxlhr = 519457098;
    string DMGcEgJazxW = string("BoTyXLUKISqTqoBlOjlpJnmuRSsOqgMAkqeXZoTSxHoZHpUGaNERxdXuWzhehSUhUGZHIjDANeyXQzBMxjwOIRSObSciRnRifsstFxsrApBkKmPHdMoilEhJpjUzgydJISrgDSETZoCZHbDedRVBQHoOImizndOQhcFCsBolGDEwbsfpFLhzxqfBmPLApHjGYsUIlsqzOzpLOrDOMDzjDCzxkTgbImTt");
    double CqsbNhymgV = -615743.6011339792;
    string clVOkONKUyBSRaMv = string("duEjhUBaYwCcRsydjSYAGhMzzoyCyYuzzwEbNoXNzgpZudtZoUbbLiPpfqdNDRwpROjDcLSQAyrxyVYgiNHqhuMpULykgrKcXbthUMohdnUHgoWIxLWUOfaMKgfSzwZoQaqTuBFqaMgCcsZqWGRdpPEjRwnrDBZqGddFFKXlBlCowwaBrYbpLalGxZzFegHPSkEperwbQhzHXleGgOPOgOfTzEfxxwdxbIpNuAu");
    string MGdFumjFM = string("HMHlqYVzbyOnPWBAlyvhXbDUpWcywTqqPUrGPGbcDrkyVloOJZAZfAJqyPerNRXxxrljFNYWxEzcsHyoOViNJrwRZJCukktwvkoerOlmXhewPmHlwqdnSUnNUSlTZcdbbllhcFuFoKBLRFGwrgbCYxAppAHOeBEfWSmgicKtXYlrBwcNnwjlpALQVnQHxpHDjYYyFvZNZNqssdkmRhEUwBiivZdzOatrmRrwrYgKNEgSTSWQRVKdpxSOUdAQiLs");
    string XOamnitVvBbXo = string("AEyDoCWeAImfhNPeRVnwdVDvBsrfuHQXVacSBWJShWIOTikhIDUDuHIXKSeIzJPKCZLoSmfjTnvoCtHylMLhgYlexFfrkXdjHUQPMupaUHHcgNjlYadIBIiVvBXWxDsgkXc");

    for (int sWXVMwJHBzSgb = 1553734298; sWXVMwJHBzSgb > 0; sWXVMwJHBzSgb--) {
        ULxCOgUwRCr -= ZXzjr;
        cncul *= CqsbNhymgV;
        clVOkONKUyBSRaMv += kilgtWBVOjqpnd;
        MGdFumjFM = DMGcEgJazxW;
        ULxCOgUwRCr *= ZXzjr;
    }

    for (int HsqfKSqtElZm = 1298577570; HsqfKSqtElZm > 0; HsqfKSqtElZm--) {
        CqsbNhymgV -= CqsbNhymgV;
        ZXzjr = ULxCOgUwRCr;
        WzLfGGukccfKwX -= WzLfGGukccfKwX;
        ULxCOgUwRCr /= ULxCOgUwRCr;
        WzLfGGukccfKwX /= WzLfGGukccfKwX;
        cncul += cncul;
    }

    for (int hlabHXnkcfk = 507070932; hlabHXnkcfk > 0; hlabHXnkcfk--) {
        qXeEEXKs *= qXeEEXKs;
        kilgtWBVOjqpnd = CfasircDDHhWI;
        kilgtWBVOjqpnd += CfasircDDHhWI;
        CfasircDDHhWI += clVOkONKUyBSRaMv;
        cncul = CqsbNhymgV;
    }

    return CqsbNhymgV;
}

string LzwHvPz::aFnqfdNWtPxvKmqI(string rAWAfCawsxGvqLPQ, string ZzwJXIqPXWnTD, bool GYpmotl, bool qfYQtunJAipr)
{
    string TSdSXp = string("utHMaHFssjlYABKcxBoDGNJkZjaNBJOyMUEwytCtevcBGSYXHtvnZxRjVRSYDnyFSdNLDzXbJtlwlXwnnmmANxBhjRuETIdejpgsiipxxgTMKYESfXIqGulMNhFfqu");
    int PplSMtpgZRigM = 1179116306;
    double qCSSDyY = -1002125.3730423178;
    double MFTdoscUUBL = 456230.892744443;
    string oxWZqmgW = string("jIcOPNGqDbrPDxMlHupPUzyExunZvgdvvRinbusaXyTbUSnZoeyCizOtVJbnsHwNWWDPKWPiLtZraDINMArSGNyPSbeKPDkDUTOrnwXvPwDzxRxBdCFGuxpvaxAwyDJOzlEaSIpvqiJ");
    string EGLdYlPXkG = string("pgjtFhuTsWduYAprCRWpcEbUdRPRnTUENItuXMPKWNyWNhxueMVlNbItAeLUgmQKlfUpTvVKycChTOSPoQafxdKxAUwZYjFNYRHQULijAIALuHUPxJgfnvueGui");
    double HmtSAdFwQD = -808630.9292675996;

    return EGLdYlPXkG;
}

int LzwHvPz::VCXpU(double OhpUWNZDQLurV, string WtApi)
{
    string JSQeFyVPndtN = string("mKudebdkwVCBZywxyeRHltWvzFnQpbveJQxFX");
    int DvvdnX = -1641329492;
    double rERPrxtk = 327530.2483928683;
    string DcLIk = string("hdPTfJCRwclTrQwmgjLuBjEENsYRrCnYxTCPGOgSPxBUHRVhLswXZTcLrODaSOKBhmtISwVJHFFZGNMDrtFjadbTcEPBzjcyaXNVVmEgttgSOghAMoPiyGqmOXldSqWHyWhcXzrImUjdiXwbVaGToptKJZPBEiVdpbkYTcfpcKCoK");
    int hwVDi = -229730649;
    double NVdfG = -930868.1121101106;
    bool xvFilLIvhocj = true;
    int KBdJZRUcMdt = -1733407463;
    double pbfkIjGZ = -154620.75365912664;
    double upcmTAcUjqr = 818171.0801891357;

    if (WtApi > string("aCNRRyvjVAykhYIUQmPKIFtbutJlobagNmtKUurMWnFcQxCAkNDfxFZtvLorNdIXCzGJXKDTSWCxSntapNAtstwsGSFONxvFmlRaaWyLJMaQeJiVJfGaSFCCLZLZFAuUBCykqhFgyZTxFnfhHRdStGsPQGRoQwAqlBBcKqeJtbMTofzrGNKzLAUskDoKqTMFCwFUrzi")) {
        for (int aeDrmWAZVyov = 98325429; aeDrmWAZVyov > 0; aeDrmWAZVyov--) {
            pbfkIjGZ += upcmTAcUjqr;
            upcmTAcUjqr /= upcmTAcUjqr;
        }
    }

    if (JSQeFyVPndtN > string("hdPTfJCRwclTrQwmgjLuBjEENsYRrCnYxTCPGOgSPxBUHRVhLswXZTcLrODaSOKBhmtISwVJHFFZGNMDrtFjadbTcEPBzjcyaXNVVmEgttgSOghAMoPiyGqmOXldSqWHyWhcXzrImUjdiXwbVaGToptKJZPBEiVdpbkYTcfpcKCoK")) {
        for (int gcHhbOMW = 870876142; gcHhbOMW > 0; gcHhbOMW--) {
            continue;
        }
    }

    for (int HAyAbzrcjMnyVIHY = 1929580900; HAyAbzrcjMnyVIHY > 0; HAyAbzrcjMnyVIHY--) {
        NVdfG -= NVdfG;
    }

    return KBdJZRUcMdt;
}

void LzwHvPz::DDbuWxOqdigEIjL(bool sgJWMVvqWK, double TwSgSzWct)
{
    bool rmesWAx = true;
    double ufgiTKNizbh = -995965.1782220608;
    double NYvDTU = 890387.7691925828;
    double ngpFWdB = -301331.92330354406;

    for (int qxlTtsa = 380756865; qxlTtsa > 0; qxlTtsa--) {
        TwSgSzWct *= TwSgSzWct;
        ngpFWdB *= ufgiTKNizbh;
        TwSgSzWct -= ufgiTKNizbh;
        rmesWAx = rmesWAx;
    }
}

string LzwHvPz::ImVOV(double njMihgYs, bool nqbvUmHRHA, bool zfECovPSstJsG)
{
    string AglIUrN = string("WcHcpskCvhyWuNoJMgkZvFhtrNIBKMiPPFMUMRbygIrrHKEDKIOeEYwbydOSrugHcpahIZYBLgtJUXtdYnJjsiLWGtOTuZLHBBqbOZbYOSl");
    bool lGigCZWSmOF = false;
    string fjMNSUOjXbDBBSC = string("ldTRhRcfBNTBLsuLYfdFD");
    string QKpbEAHR = string("UMczXVUQaIuYticWcyhwclNxrIbUIbVxQuvIlCDndyslkkvIzyvQQcBRWIzNjcuVQtYEsfagTIoTxwDbUtsXkBrMjs");
    double GyoSsacSnazBVRao = 573295.6228730002;
    int ofQQBXzeQc = 1112613827;
    bool MuYfDGjanPdvAd = true;
    int IYrsUwCR = 1412706906;

    if (QKpbEAHR > string("ldTRhRcfBNTBLsuLYfdFD")) {
        for (int upsWCmGa = 201150410; upsWCmGa > 0; upsWCmGa--) {
            QKpbEAHR += fjMNSUOjXbDBBSC;
            GyoSsacSnazBVRao *= GyoSsacSnazBVRao;
        }
    }

    return QKpbEAHR;
}

bool LzwHvPz::OQLWsqCPXdnv()
{
    bool SAIcN = false;

    if (SAIcN != false) {
        for (int cAqjHZxGyj = 1718196672; cAqjHZxGyj > 0; cAqjHZxGyj--) {
            SAIcN = ! SAIcN;
            SAIcN = ! SAIcN;
            SAIcN = SAIcN;
            SAIcN = ! SAIcN;
        }
    }

    if (SAIcN != false) {
        for (int CYyEBMkglDawIqJY = 32370352; CYyEBMkglDawIqJY > 0; CYyEBMkglDawIqJY--) {
            SAIcN = ! SAIcN;
            SAIcN = SAIcN;
            SAIcN = ! SAIcN;
            SAIcN = ! SAIcN;
            SAIcN = ! SAIcN;
        }
    }

    return SAIcN;
}

int LzwHvPz::wPLQdfFqV(double rVXGssFLnhEDAaWS)
{
    double aRxGcWVip = -830746.7102254255;

    if (rVXGssFLnhEDAaWS <= 323707.0873158432) {
        for (int usZYuMnT = 2098700251; usZYuMnT > 0; usZYuMnT--) {
            aRxGcWVip /= rVXGssFLnhEDAaWS;
        }
    }

    return 484187246;
}

LzwHvPz::LzwHvPz()
{
    this->vosTSydsU(string("AjwSlLrMlonwyPmcPXUtoQsPMLAzXaZreGHyIhNdEqQSyEGxHrVblxmvqSyMfvOkWnFFwoCPvkVBhGsUUzVHQRIuuyQOTvafKHwAlwfhZnFecwVVlcYodJMhAuCwBzjzTgjTPTBgeoZiGtxNEcAIDAsVTHztMSLxzXtLzWMVfCpAqYJCkhxrJFOqpBbGGLibJxDzXgHtGqXqhLwUekQbUIxXAdVwXZHSnqEcwSswlCYDWbwUABVilaCoPRPHI"));
    this->tobLp(609040.5364616303, string("fZLiiPZqNVwnMxLhLCngTTMzcdsOqQFMcQhenZLSBlvAVIapuNqxvPtitTtqDzxFLdVmQcAgRsLmkHCkPvoqKmxerWFfDVFFloiBmLMlGsJAghnHLOqJcbEWimZsUXCDIkecYxgReiJDZUYmsIPYikexalzUklpDAAhnPVqhxDRHLUmBeyApx"), true, 1627305717, 157278.42051365788);
    this->zLzmkRsFlGTcWqF(-1818491581, -991562.5586897443, string("CxdCuxyEgZjGORzusvvbVMKvFfrrVYvRPfDopuOYHARbsgoHSbSPprEesDFYndxJEeQvUUTMXfomNdPGWgFDZoaIWKtjSIcPtdvKpyGTlLGEYzHBmFkItJMFKjfHSMNIJaZVXIoUcYgLMVAMgNXPUlZWaUXbhlP"));
    this->ksuLHPfckHY(1822092926, string("KbaOhWvpXopDvVmuqTiOYaQgrtqguXxSooWfECblmkisBlrOpsqbWYlOFSQSSieCIBLDXfftmvjKfpzuWDGntzJF"), true);
    this->LEAbkgXVz(2090647905, -753842467, string("uHx"), true);
    this->aJSwGNVnT(false, string("yXfqulXyLghJCLBRWlfWMyrcEeBoelBRulhCfGKvGKIDVzPwAagiIrTdGnmWJAitBCjHGOeJEXNiZuVGUUnNwimLlrVhHxigobiNlWDFRQzozarylTVsrmzyVnoZtylspXaiCmeThhwzdniQxFoYwpjznRSDsFRXfWsWIFcMFhmyPiBlJTbiMWFaZqoawbHqVKzTr"), 797721188, 120036.10562234827, -876248573);
    this->sgBsOyX(false, 986463.4383575356, -861948004, true);
    this->qxFVZxSuwIL(2003775151, string("GKgeNqnlorDnYICefPWHGAXjkJEffMKSGKvTCzpdpDGYkOKOQcSVtoEnGDMYsheeWfQffqTYeIaTddiNSyazabZYNVAauFybejtIBNESsSbAgFqBjhJCSrQXlfLfAnevNuUvYIyKbiBhnfndFlHLDxyqLFWGEXhnQlruQtyGtmFVJKAsuWZrGMXCSLHGvJmNHSFoHCocaaFAFZrzPDySJtUcCjcMHlaBJHhmBeYaTWXUM"), 1190746111, -560641.0276908817);
    this->ipxKydyElOal(false, -418589575, string("JrjvuEgEbPcMHxxgMBomrXzCb"), 979399.2394070397);
    this->iMeNAaGG(782667093, true, false);
    this->ucnIsG(string("jOQJyJEORMuXQUoTvBKAjvzJtWHfwVCUQWnRjJfFE"), 1912025350, 191679.62386517803, -834891.7563835856, 1085284942);
    this->IywqlyGHpIkQA(508431.09035575663);
    this->ItpAzzTnyfvLZdnw(true);
    this->YopcYfbABlQwKIG(1110006840, string("TIMKQmEubGbWUNpvsrbrQdhHOTJMmqtPJraqcNTJMNPJcbLqBnxUxVSUyosvPKKoaEWIREI"), -1663750105, string("qmteLPQdYsDVooRUbSRSVCcjMvcgcWNGNIwmRqHEQrtyjgNrGjzyCywLPjkMyRMjnGXImDXwrnimLchuG"), 798528.5758892302);
    this->aFnqfdNWtPxvKmqI(string("lVHuZJQrLvfImInVHqjJqPxUWzVGiQnqIUBOkgkdkCazepACicTpflaCDvJqaXCmNVUsAmlGeduYAhplniviOeUFzPghLXWIZhvbvNrWdEzgyQdHHpIjNLhPofGkhlkXqxDlWzgeLiYaynccJfpXzNhWYJXObYiFnrNqWZfSkEWFFdPSkSxOtLqEGiCDPrmrWWpYptdSIQsffchysBDDtSAONksoGtdyUfeldwLVYbZIWwxWrkKtCBnQBnQxcy"), string("rajeQyPNFWyIPJvCqMOemVtyQceYiZlB"), true, false);
    this->VCXpU(-1022809.2357501284, string("aCNRRyvjVAykhYIUQmPKIFtbutJlobagNmtKUurMWnFcQxCAkNDfxFZtvLorNdIXCzGJXKDTSWCxSntapNAtstwsGSFONxvFmlRaaWyLJMaQeJiVJfGaSFCCLZLZFAuUBCykqhFgyZTxFnfhHRdStGsPQGRoQwAqlBBcKqeJtbMTofzrGNKzLAUskDoKqTMFCwFUrzi"));
    this->DDbuWxOqdigEIjL(false, 351430.9522441033);
    this->ImVOV(-504109.87116904184, true, true);
    this->OQLWsqCPXdnv();
    this->wPLQdfFqV(323707.0873158432);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GXMsyaoJXdWp
{
public:
    string NoKYEIjdZZwZ;
    int maVCDfQnKzrkaiSc;

    GXMsyaoJXdWp();
    double wKxRVnKWYxZbY(double lcmPFhCDwI, string UouIwDXxIUFBAshE, int rEKQwuDQt, string OizFOmeVarm, bool AvtYNWQX);
    double mUROMUvsEcVvNoA();
    double ZrUGjmRvt();
    bool QQfzXkPpPvrpKL(double VBaYTRWbtTsNCzzD, bool hqAqwfRgMTITTdk);
    bool ltUWjDxirlY(int JwnFRKzIn, bool ZxhveFYK);
protected:
    int zalWDKcsCXrmF;
    string AheBJMYZFXeB;
    string tEmXSyV;
    double aIuOjfgLBQLm;
    int OwLSg;
    double ZOYpTRl;

    int tZSezX(double OxAzytZJorXGh, string yiNeAasrJXXp);
private:
    bool xfeCocZKol;
    double VSVRqMRSfd;
    double NQaIjYljsh;

    bool UMscycmeSnBjl();
    void KEcTROXwP(string xDNzuL, double kMMDxuq, int xGEhgoDQLy, bool VGyqdrsAxYULhhGj, double xvXXvYpPPJXi);
    double YyigTm(int ESmhSfh, int LckYfTKaQi, int MBVjEkRxbifner, double bbYdO);
    string PFwLbrRGrFCx(double KRdsbfnJwrqIoGSm);
    void WrzkkgjsiR(double YCgbVEpIADWU, int vohhPVtDhYcpthh, string yoRhOOYsGMLmS);
};

double GXMsyaoJXdWp::wKxRVnKWYxZbY(double lcmPFhCDwI, string UouIwDXxIUFBAshE, int rEKQwuDQt, string OizFOmeVarm, bool AvtYNWQX)
{
    bool KAVQzsGi = true;
    int hNzWFIDRMPyirATc = -1466934309;
    int fdvoUsyGtiIX = -1918628059;
    double AGGlTPrZI = -44285.354444154924;
    int RrEqzn = 761010592;
    string BfzOQZvdmQJvyj = string("tsxyqnmxALNWHdbpydgUZiQgRgMtLUByscIuWSJZoaampySIycpknODnBfDhSfnChGJjVMTzhKUsrwxdwmvUahGrNqDIUaxPkBUAQuSqCLPfuzMARIfTrEKoqagnZNrhTbQloUxyRFqFYqePrIAmLsFOmOrBATuJlTiZrmkDDuaAcy");
    bool sKdnyjJzLpTB = true;
    string zETZvqRWiNK = string("yTsOMpznvyQhJCBbUNpAhYMxNcjHnOUPWGYacmBkqxmejVNJSNvIaFblRLzzHElYSkgXXXUiqZsuJIFdhDpyuLZXQDezNvMWdwJOzWtBgBuCZGeHDd");
    double TsoSdfdSaSTF = -887636.1874708899;
    string QyTOfeBObhRPhz = string("ClGTbBckvXFPxEkwjNRkcdPSnKGZXDTcEwEAOOKPiDxcfNeYrKbekOsmtEMbAncexnppKvPUJwHnNorEyQDXLkoNoxXfRQAXNbjMhMqaAfSqeRV");

    for (int hzqjeU = 411819359; hzqjeU > 0; hzqjeU--) {
        sKdnyjJzLpTB = ! sKdnyjJzLpTB;
    }

    return TsoSdfdSaSTF;
}

double GXMsyaoJXdWp::mUROMUvsEcVvNoA()
{
    bool gEBeofvtvZqi = true;
    string zvIaDfYfELYwk = string("QejixWskSJPPGqUMdbwevowqNyBwbcFVywCZLpwgnNTLOHPCtHxAcGHGaeJHgpQGncaikqHTPWgAVZtOknEnJajwsHUUDRmvhmluJSRgUPaZjAqaCqlDXHdhlfnnktWhAgFlrDxFprErTeHVYqYrcwsrNaBlavLuIbOTPSwIsiqopRWSlDbGgCFnithTvWnaY");
    double OWXjmbvqPIcgo = 37175.123309823415;
    double YDAibADqExyvlfJ = -455040.10571323155;
    bool FWLfEX = true;
    string IpStyWJyqG = string("ZzQbdwSaeeQNKLcYrqqFqYJpfcybSXwlxfHZGGUwLKtkvVVltMDCSNTrjAXycLcmDHDXIFeNfmzZAlllaBxcENGnhWgcoZYGWkquGzlJuIvNBKhzGNKwOtBcXTkCcKTpmrtzZtdNHSZngktzoYIUSLAJWSfVqyaUWFBcwzJeCOUlXAjpHTHJBXwdFjmHxbCFqTGJCzLVvNtKFbiXIwymbIBrVEYfoFxKKbIDwqRYLRvynNzoulCvefr");
    double OcKFHHhtLxiDZ = -308484.02644156636;
    int CTofqSkfBsDSYvlS = 313733812;
    string rSUzCJd = string("wyeUCpuWlmKKfkPGreWEwgfKcWPWWoekplEoGLdyaJLeQhMMnTXalNpJFxAYTJmvnCUCXIeoslfJBlLQUZnRMzqoDPtoylPKXiQVqSsiMyRSiEhqMZVNdiHKpGWGIlqOoJpoLcuUUFtPUYBczsooMYPpplYxdvKVCpsqqLUSYGNgW");

    for (int DlTSvNKuUcDch = 554310447; DlTSvNKuUcDch > 0; DlTSvNKuUcDch--) {
        OWXjmbvqPIcgo *= YDAibADqExyvlfJ;
    }

    return OcKFHHhtLxiDZ;
}

double GXMsyaoJXdWp::ZrUGjmRvt()
{
    double YFcKeOjygRDqT = 160020.89138676669;
    bool MGBQj = false;
    double zNcvsBhwuT = 620114.6341142842;
    double phczPrpXlAwlnf = -428052.56632664596;
    int OMVTaNSNBUCaCsKs = -959707289;
    bool HumbmKuCdVOWTcZ = true;
    bool fCDxPga = true;
    bool oschkfMK = true;
    string wCisbiZuOTasg = string("uZfWcASbszbMwVnjlBgyttOgHyWjBdcDLlRiPSYssLVIUiTWPoqPUmTIjHQDEeNsQTEEbEBRULxdKJroLItNrtXhOrVKeyVHUoOygNrEiJSiWKypJpKdfCczULkEcLYhIwwsSTuCyMfpBwOjgSnBFlKpHWyaEyxvLJembIGOiKMJSqGLehIsgbbT");
    bool qSzfMED = true;

    for (int RhLMBIDYAD = 1955007161; RhLMBIDYAD > 0; RhLMBIDYAD--) {
        oschkfMK = ! HumbmKuCdVOWTcZ;
        fCDxPga = ! MGBQj;
        wCisbiZuOTasg = wCisbiZuOTasg;
        fCDxPga = ! MGBQj;
        MGBQj = qSzfMED;
        phczPrpXlAwlnf -= zNcvsBhwuT;
    }

    if (zNcvsBhwuT >= 620114.6341142842) {
        for (int CZulix = 6826895; CZulix > 0; CZulix--) {
            HumbmKuCdVOWTcZ = ! oschkfMK;
            fCDxPga = fCDxPga;
            wCisbiZuOTasg = wCisbiZuOTasg;
            HumbmKuCdVOWTcZ = fCDxPga;
            HumbmKuCdVOWTcZ = ! fCDxPga;
        }
    }

    if (YFcKeOjygRDqT < 160020.89138676669) {
        for (int ZombNiZ = 895608447; ZombNiZ > 0; ZombNiZ--) {
            OMVTaNSNBUCaCsKs = OMVTaNSNBUCaCsKs;
            zNcvsBhwuT = YFcKeOjygRDqT;
            qSzfMED = qSzfMED;
            MGBQj = ! HumbmKuCdVOWTcZ;
            YFcKeOjygRDqT -= phczPrpXlAwlnf;
            fCDxPga = HumbmKuCdVOWTcZ;
        }
    }

    return phczPrpXlAwlnf;
}

bool GXMsyaoJXdWp::QQfzXkPpPvrpKL(double VBaYTRWbtTsNCzzD, bool hqAqwfRgMTITTdk)
{
    double TbGyr = 787927.6061465233;
    string YdqVnohhSpQhVBv = string("iLKWXBfSoviqmKfQOVBlfTpHPVEdwlYdtAudjLjaeDMFfppHEdlhziTWOfVmfuRdduudblScMgwVFRGzPxgPDvxrqKYtNfELERWKeSOgcweWBmdzWiDuHIRwNjcQRAMmjkgodYGWxPjAWKvnogZVbIbviApGBbAHPQApLfqNBdciTtfvMOPKZMqyMlxqvUcCCQaflpVuYQHrzdrYMAGrsXTtoOAzHMXJFjPUQqBFrHxxUpQWjhFvtNvp");

    if (TbGyr == 1013235.1836259961) {
        for (int SJmbTjmeWWfj = 820350995; SJmbTjmeWWfj > 0; SJmbTjmeWWfj--) {
            TbGyr /= TbGyr;
            VBaYTRWbtTsNCzzD *= TbGyr;
        }
    }

    for (int GVrUCDDNrTuLi = 1902613674; GVrUCDDNrTuLi > 0; GVrUCDDNrTuLi--) {
        TbGyr += VBaYTRWbtTsNCzzD;
    }

    if (YdqVnohhSpQhVBv > string("iLKWXBfSoviqmKfQOVBlfTpHPVEdwlYdtAudjLjaeDMFfppHEdlhziTWOfVmfuRdduudblScMgwVFRGzPxgPDvxrqKYtNfELERWKeSOgcweWBmdzWiDuHIRwNjcQRAMmjkgodYGWxPjAWKvnogZVbIbviApGBbAHPQApLfqNBdciTtfvMOPKZMqyMlxqvUcCCQaflpVuYQHrzdrYMAGrsXTtoOAzHMXJFjPUQqBFrHxxUpQWjhFvtNvp")) {
        for (int hLSIeDj = 330450193; hLSIeDj > 0; hLSIeDj--) {
            VBaYTRWbtTsNCzzD += TbGyr;
            TbGyr /= TbGyr;
            VBaYTRWbtTsNCzzD *= TbGyr;
            hqAqwfRgMTITTdk = hqAqwfRgMTITTdk;
            TbGyr = TbGyr;
            VBaYTRWbtTsNCzzD += VBaYTRWbtTsNCzzD;
        }
    }

    return hqAqwfRgMTITTdk;
}

bool GXMsyaoJXdWp::ltUWjDxirlY(int JwnFRKzIn, bool ZxhveFYK)
{
    int DTWTHgdbVbvfdcIo = -518257618;
    double ukuuIJAv = -486617.60305261513;

    if (DTWTHgdbVbvfdcIo > -518257618) {
        for (int zTkeSpdP = 1557171519; zTkeSpdP > 0; zTkeSpdP--) {
            ukuuIJAv -= ukuuIJAv;
            ZxhveFYK = ! ZxhveFYK;
        }
    }

    for (int iCqdJBCcot = 1687221467; iCqdJBCcot > 0; iCqdJBCcot--) {
        DTWTHgdbVbvfdcIo *= JwnFRKzIn;
        DTWTHgdbVbvfdcIo += JwnFRKzIn;
        DTWTHgdbVbvfdcIo /= JwnFRKzIn;
    }

    if (JwnFRKzIn > -518257618) {
        for (int OEwomt = 2131562340; OEwomt > 0; OEwomt--) {
            DTWTHgdbVbvfdcIo /= DTWTHgdbVbvfdcIo;
            ZxhveFYK = ! ZxhveFYK;
            DTWTHgdbVbvfdcIo -= DTWTHgdbVbvfdcIo;
        }
    }

    if (JwnFRKzIn <= -518257618) {
        for (int rKRTldt = 2145866557; rKRTldt > 0; rKRTldt--) {
            JwnFRKzIn /= DTWTHgdbVbvfdcIo;
            DTWTHgdbVbvfdcIo += DTWTHgdbVbvfdcIo;
        }
    }

    return ZxhveFYK;
}

int GXMsyaoJXdWp::tZSezX(double OxAzytZJorXGh, string yiNeAasrJXXp)
{
    string JqWaWZk = string("TcjhMFCgPKdYoefHUboTsHeGweTCBUQOvXeieWwAyFdiBkzDDNukjODpuyimSOXdYffwepbXUOhoTutcrkKRnKEIZRdFveHBoHRqjitpDNkuRrSXdDdbwGTOIrKJ");
    int UxBAGcjnQVPMrDH = 671805854;
    string KvQPRDApYYcaTSAw = string("DpLWrsYEooCxgsPVXWhRnqydUWJjhiXsVblwpQMDSYvPdhaJuEayCGfjoDCvFhhgxNzMcCGNGIsDCRdhogfIKUQfRNcXelFGuRuzZVGyCYnNXmLmKIqgNNQunbzeSxAlRRadpRQQNllqjflLhcYCxTtQKyyIQYhYyDOsihyPXOUIguIoOzoIzxZyPOuEfLZnkOHVPuqjqoYRqXwnEZNMHNINwGgKrySvpFBjb");
    string YwvBVGQlLx = string("uBbEZNqeNetZbuERprEnizDvLMMPEl");
    int RqCztBRvshRiWzdB = 453072108;
    double JCSyR = 338511.9962386513;
    int EQINzQGFyoMkz = 788032160;
    double AkEaCEXHqWSWEp = -89106.07988171783;
    bool TnHlgH = false;
    string fGbiFVfY = string("jUbxRaVmSpuAFpXtGYJSTNmkOBJeyrBwChjVBPkKHqpFBhlBcFVujhnHXlnpTgQyfZGnrGLgOAdjGguLhKXIzHpmSvrqogXNDlFokNjTGEtymAUKdVQtrygeNcEyDUktkFGCNroaGiKBVZbfhHLEudbrvijhLSclymaWREPcnNMrzROHbJS");

    if (RqCztBRvshRiWzdB != 788032160) {
        for (int BOtHym = 365631294; BOtHym > 0; BOtHym--) {
            continue;
        }
    }

    for (int SPTWf = 1128448098; SPTWf > 0; SPTWf--) {
        RqCztBRvshRiWzdB += RqCztBRvshRiWzdB;
    }

    for (int PKibg = 1739460687; PKibg > 0; PKibg--) {
        YwvBVGQlLx = YwvBVGQlLx;
        yiNeAasrJXXp += yiNeAasrJXXp;
        TnHlgH = ! TnHlgH;
    }

    return EQINzQGFyoMkz;
}

bool GXMsyaoJXdWp::UMscycmeSnBjl()
{
    double etFyjRccOljMvro = 733652.3435050107;
    double UqhtUcoKfle = 658868.9483418233;
    double XBactIWWV = 824689.226970404;
    string HMTbkdwV = string("CLMPNdfrlgEILXiFkzNmZOgEhrSIpeORhkLBk");
    int eQTHH = 725401148;
    string LOWZezXhi = string("jzWdnEMLzIWlywxOFVRdOL");
    int wAPOitkn = 2147410671;

    if (XBactIWWV != 824689.226970404) {
        for (int LFYqZWtpctaS = 1337081940; LFYqZWtpctaS > 0; LFYqZWtpctaS--) {
            wAPOitkn += eQTHH;
        }
    }

    for (int qYYci = 1603431041; qYYci > 0; qYYci--) {
        XBactIWWV -= UqhtUcoKfle;
    }

    for (int mJIVXcdD = 65375597; mJIVXcdD > 0; mJIVXcdD--) {
        LOWZezXhi = HMTbkdwV;
        HMTbkdwV = HMTbkdwV;
    }

    for (int jnUiEnsDwpd = 1175715421; jnUiEnsDwpd > 0; jnUiEnsDwpd--) {
        wAPOitkn = wAPOitkn;
        UqhtUcoKfle *= XBactIWWV;
        eQTHH *= wAPOitkn;
    }

    for (int LokSbZauunym = 1482008639; LokSbZauunym > 0; LokSbZauunym--) {
        eQTHH -= wAPOitkn;
        XBactIWWV /= etFyjRccOljMvro;
        UqhtUcoKfle /= etFyjRccOljMvro;
    }

    for (int OxtVInAxlzmHcqa = 1248613056; OxtVInAxlzmHcqa > 0; OxtVInAxlzmHcqa--) {
        UqhtUcoKfle += UqhtUcoKfle;
    }

    return true;
}

void GXMsyaoJXdWp::KEcTROXwP(string xDNzuL, double kMMDxuq, int xGEhgoDQLy, bool VGyqdrsAxYULhhGj, double xvXXvYpPPJXi)
{
    int vEpngi = -341386611;
    string TeUhVCwlvm = string("FjxjbQqrufxzkSAQWyUwcQWmdBHfkAmnHoCLvbFaOSPFuFqRFIUdLxIBwveNboptZAvMEUmDdwAXrPvwaGVlQRmExYtcvBrMVqqHHyUHAhShBYTqGIWNa");
    bool cnquTf = false;
    double ztXOFpeyYPdPC = 111915.6533258357;
    double DReyUhm = 729751.6196607954;
    int VSKdUZoRNcjfCCFC = 225387422;
    double qAaXt = -168059.2111370661;
    int aNwdntfCdurkDqa = -497032603;

    for (int PqDzheXS = 917006875; PqDzheXS > 0; PqDzheXS--) {
        continue;
    }

    for (int baCAFWuGRrimVogq = 1196057942; baCAFWuGRrimVogq > 0; baCAFWuGRrimVogq--) {
        qAaXt -= ztXOFpeyYPdPC;
        kMMDxuq = ztXOFpeyYPdPC;
        VSKdUZoRNcjfCCFC = xGEhgoDQLy;
        cnquTf = VGyqdrsAxYULhhGj;
    }

    for (int zBkbioKeMkkfE = 893198043; zBkbioKeMkkfE > 0; zBkbioKeMkkfE--) {
        ztXOFpeyYPdPC -= kMMDxuq;
    }

    if (qAaXt <= 729751.6196607954) {
        for (int UqNjMhgDPQWGwv = 1708180693; UqNjMhgDPQWGwv > 0; UqNjMhgDPQWGwv--) {
            DReyUhm = qAaXt;
            xvXXvYpPPJXi += DReyUhm;
        }
    }
}

double GXMsyaoJXdWp::YyigTm(int ESmhSfh, int LckYfTKaQi, int MBVjEkRxbifner, double bbYdO)
{
    int SiebEnfSHkRfOA = 298929968;
    bool bYjjTzTZVkP = true;
    bool CiTLGUeDgL = true;
    double QvjAMsS = -115969.60365821791;
    string sfgKevsGWN = string("kWWUpAzGEYFhvIlBMwaUKVXgXCegNSGSXBNWgSWEICGPejxrnrhyOEmnElShLsfbhRGpIrhjGIHSAOEk");

    for (int HoCziMYrkw = 1270590016; HoCziMYrkw > 0; HoCziMYrkw--) {
        LckYfTKaQi = MBVjEkRxbifner;
    }

    return QvjAMsS;
}

string GXMsyaoJXdWp::PFwLbrRGrFCx(double KRdsbfnJwrqIoGSm)
{
    double kqOOcL = -445112.9314039246;
    bool IVEJPLEqzCLxx = true;
    int emDiT = 735754236;
    int EhGkgbs = 1735357876;
    bool GJcoD = false;
    string RpzpJPvLlvLsMF = string("bbFUvNMWeMGXpHjYoUiDaGpoSFIVFUyPyUIQAqBhlAUvheYmAhpVjWxtXekhDaAFmJAvhCxLiNMyHRMzGBWrxpVjRuliDIKOwQBaSlTxKqOygCabzQYwTLZMThweNOsS");
    double GeIJRAwgJIV = 399009.99433499423;
    string mrTHfZSkNxurVFo = string("MzKiGTEdYXlGEdJoGNVkXLQFEdbMqYHqNBoYTfbRQkEVMoGDaRhwYkJNuMHrOWEDc");

    for (int CpyHTPSMhchu = 1003882635; CpyHTPSMhchu > 0; CpyHTPSMhchu--) {
        kqOOcL = KRdsbfnJwrqIoGSm;
    }

    for (int XyozF = 1405374869; XyozF > 0; XyozF--) {
        kqOOcL += GeIJRAwgJIV;
    }

    for (int sVODn = 329099436; sVODn > 0; sVODn--) {
        EhGkgbs = emDiT;
    }

    return mrTHfZSkNxurVFo;
}

void GXMsyaoJXdWp::WrzkkgjsiR(double YCgbVEpIADWU, int vohhPVtDhYcpthh, string yoRhOOYsGMLmS)
{
    int lgTlpKg = 1377785694;

    if (lgTlpKg > 1377785694) {
        for (int GpzOtnSEtfNC = 1787671518; GpzOtnSEtfNC > 0; GpzOtnSEtfNC--) {
            vohhPVtDhYcpthh -= lgTlpKg;
            vohhPVtDhYcpthh /= vohhPVtDhYcpthh;
        }
    }

    if (lgTlpKg != 150016688) {
        for (int fhepgktgrmL = 1605001370; fhepgktgrmL > 0; fhepgktgrmL--) {
            YCgbVEpIADWU = YCgbVEpIADWU;
            vohhPVtDhYcpthh -= lgTlpKg;
            yoRhOOYsGMLmS = yoRhOOYsGMLmS;
        }
    }

    for (int cnLCgAdt = 345703242; cnLCgAdt > 0; cnLCgAdt--) {
        lgTlpKg = lgTlpKg;
    }
}

GXMsyaoJXdWp::GXMsyaoJXdWp()
{
    this->wKxRVnKWYxZbY(-154963.58655673065, string("hoQciqVSyIYgEbEkeSJFKSbJBxWcRWrgkBecgiaApQctKxUosmEZrYpeAJbyPlrIhaURkpygLbYyUnrTeHarPPgeDbijPamCbBPBrtuHrnXzJHvcbFEKBQYMEabVTivebucStZyyAWYmfHmUDdlKqMDiDiCaTCaOXwproIFwxodHPlixekPaFLegSWN"), 29321603, string("IbMDUAxwQLdzWnouYfskUtEaFRRVajrlHReOQgIgMQdSwqZZvcVbtgoJmPWWQuJPYkXrMLAvAGliDSVrBcFyLeKIHRTnatPmnapFqZB"), false);
    this->mUROMUvsEcVvNoA();
    this->ZrUGjmRvt();
    this->QQfzXkPpPvrpKL(1013235.1836259961, false);
    this->ltUWjDxirlY(-208999740, false);
    this->tZSezX(550550.3249072016, string("PlEcYAvXoEdHWIGtnDNddSeGwIqWrKxgfiPtnWRUNRsYbtNALeBBcxGpeOclerRnkDnoNbxrwANPRnRcdCjMHPsKPnMjLgCmFcPRlZyVaETSvQxCjqLyl"));
    this->UMscycmeSnBjl();
    this->KEcTROXwP(string("DmRkToPxcWDulqxtMvlxzKiycghiEwoaUHzwChywVpWRzsXTENkZCTwRpDcqwlUdtRFTWNcznRladjSWySjelOJyABiE"), 1010762.4361277616, 287229682, false, 505261.02699247515);
    this->YyigTm(510181949, -736477455, -129886861, 95156.80464199788);
    this->PFwLbrRGrFCx(614402.0878902933);
    this->WrzkkgjsiR(184894.03850521572, 150016688, string("TCFKgFZYgFUXZzXWAXJHBNWabxiZRDZNzdEPQkUWSoxZbnKFXgUiKaHOrVWNvQRdPdWSDdTZFSFNThIpRZLrSwVVZWgKNkDlIVePgyYMsRcSNNAMFaETWXPQvsNKhdEZEnOJSLewHqtvYKGBzbGwAteEtkUcCToHDODDwLpoPImRrJzWsjADUxUvBvKXgDbgResPQdULZujtEWsXwgETDxYmpIsBYUjNbhCUEkyrEZuBrTpUNkdpnOFnwchco"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yjigINmo
{
public:
    double GTeBWFHezgCCxzo;
    double ZoabYdfDyqblnpv;
    bool juLsw;

    yjigINmo();
protected:
    bool YlHacyQSVD;
    bool rxoYdvTIIlXYQ;
    double ljiYykqALjTiMN;
    bool HafKKKRBQ;

    void ijCfZIZ(string WTvhtbn, int ehhhoFGQbjnj, bool JPfLbOGRfEs, int nfNMGp, double SFNatJWmJQBLEsR);
    bool CThvyotVz(string EOcgylOfV, string BukWxDpGJIqyypFR, bool PJCWBvFvQXItVrI);
private:
    string UQGLsUHsYFUGCtd;
    bool izWptlRqGTsRfNm;

    int BBwyYUXTIQvhdYF(double mFaJrEXH, double Ileobaqdg);
    int WiJgIcAxCXeJkJ(bool RxHQUF, string WibQauAvz, bool mFgDyJfysGcpO);
    int HfFSncdswvf(string IeDXfuk);
};

void yjigINmo::ijCfZIZ(string WTvhtbn, int ehhhoFGQbjnj, bool JPfLbOGRfEs, int nfNMGp, double SFNatJWmJQBLEsR)
{
    double ukGzsDusAusXOUgA = 577433.3491361943;
    int LGKOrxpMY = 714334996;
    string wjcSbWJGSzO = string("sFCQxxkthiQKtJZpwBpAQrMAInAYdhYxniErfHNEONoAtkPBunbedexVQMgtoIWOKqGqyrUXiQqfRZKfsqKcRRjTuwZplhjGyFYVpelSWwAxUHvpfdzTtPauPpVYgqmLjeCemvvvJGiqbrhdyjOQEnnvfdudpByxAujDBfvLNoOmjJaDKeXMsHUozd");
    bool ynwDNiQj = true;
    int qhLZIzR = -739666309;
    double rOAKAcT = 908208.1939681811;

    for (int DjoSZt = 1654456573; DjoSZt > 0; DjoSZt--) {
        nfNMGp += nfNMGp;
    }

    for (int lDxftqcupjZR = 413136407; lDxftqcupjZR > 0; lDxftqcupjZR--) {
        continue;
    }

    for (int CLrKwz = 1927680554; CLrKwz > 0; CLrKwz--) {
        continue;
    }

    for (int XNIRFTG = 1617804416; XNIRFTG > 0; XNIRFTG--) {
        LGKOrxpMY -= ehhhoFGQbjnj;
        ehhhoFGQbjnj *= nfNMGp;
        rOAKAcT += rOAKAcT;
    }

    for (int dCxmOLeYenPXx = 867425511; dCxmOLeYenPXx > 0; dCxmOLeYenPXx--) {
        JPfLbOGRfEs = ! ynwDNiQj;
        rOAKAcT *= SFNatJWmJQBLEsR;
        ehhhoFGQbjnj += qhLZIzR;
        qhLZIzR = ehhhoFGQbjnj;
    }

    if (LGKOrxpMY != -1515507745) {
        for (int fUDNVKlVIJGXgx = 1472469309; fUDNVKlVIJGXgx > 0; fUDNVKlVIJGXgx--) {
            JPfLbOGRfEs = ! JPfLbOGRfEs;
            rOAKAcT = rOAKAcT;
            ehhhoFGQbjnj = LGKOrxpMY;
        }
    }
}

bool yjigINmo::CThvyotVz(string EOcgylOfV, string BukWxDpGJIqyypFR, bool PJCWBvFvQXItVrI)
{
    int HUhTNf = -483799252;
    bool elTJLqOkpkfRn = false;

    if (elTJLqOkpkfRn == false) {
        for (int nGWKUnx = 2119115187; nGWKUnx > 0; nGWKUnx--) {
            elTJLqOkpkfRn = ! elTJLqOkpkfRn;
            EOcgylOfV = EOcgylOfV;
            HUhTNf = HUhTNf;
        }
    }

    return elTJLqOkpkfRn;
}

int yjigINmo::BBwyYUXTIQvhdYF(double mFaJrEXH, double Ileobaqdg)
{
    double sqrEKNu = 296115.61445292074;
    double KoHTXRE = -1046898.4754257584;
    bool lqJdCNJ = false;
    string NhwjdLtJQqNt = string("HQMHrfDgjHIWoKvWeloeePRKzhkyCFCJuOKSdavDQGYneDmPNsfxpoYZtmTIOroDxsSkKDYSVxrtOHVEMzaTRdDFsKwRhpEQEtdUisNuYhiVMwhrxLdvshHpPLJFfXkcchnraQhClaRBGFAfzqsjkdHUkPssWYPKmdDqPR");
    string qqlRc = string("dmeYPhUlzWDnwuqwzJNrZpDZaiFUlFQKYnkUpDyJXmGDaxRoTiXtRbEbwpquvpdBwvIfGQamDoorqPYiwUwNjBxHppDylfLjBMzJGDilvOvuaZhFRLoSKXsCUaIcGYzcBDVPpXdYLvXmGJoSsnRYsbcJQoVxSomlhuiolOZmhM");
    int ADrURAnroa = -1900785580;
    int ILhtSoOwUyUn = 541866614;
    bool LrxoqSDmNw = true;
    string IBpHWwkoBuL = string("dkHyEFcwXflEbcELbdSuIsSEkJcIBCGTyQHKaAcITAhBNENKcZnzlXndkLFxhdDeofAHxfDsGvlQfLINuVQGqlsVkZRZjgVldCVXvOgYdDXLFOSjzCSlWmlySBegPZzFBtEGdGSXDcCrkSPaxIlhAbBItrggxyoMCGJSuewKUSxavNPmIOSnIF");

    for (int nFqGFxOUyDRIi = 517552367; nFqGFxOUyDRIi > 0; nFqGFxOUyDRIi--) {
        continue;
    }

    for (int lZAYFtP = 1926071761; lZAYFtP > 0; lZAYFtP--) {
        KoHTXRE /= Ileobaqdg;
    }

    for (int KlQnXWJuLKocM = 785582580; KlQnXWJuLKocM > 0; KlQnXWJuLKocM--) {
        sqrEKNu -= sqrEKNu;
        mFaJrEXH *= mFaJrEXH;
    }

    if (sqrEKNu < 296115.61445292074) {
        for (int rOxBktya = 2108696631; rOxBktya > 0; rOxBktya--) {
            IBpHWwkoBuL += NhwjdLtJQqNt;
        }
    }

    for (int sWAbvsu = 612641385; sWAbvsu > 0; sWAbvsu--) {
        LrxoqSDmNw = lqJdCNJ;
    }

    return ILhtSoOwUyUn;
}

int yjigINmo::WiJgIcAxCXeJkJ(bool RxHQUF, string WibQauAvz, bool mFgDyJfysGcpO)
{
    double uoRGfum = -73230.52682789371;

    if (mFgDyJfysGcpO != false) {
        for (int xsLkkoXAOIaz = 201840026; xsLkkoXAOIaz > 0; xsLkkoXAOIaz--) {
            mFgDyJfysGcpO = mFgDyJfysGcpO;
            RxHQUF = mFgDyJfysGcpO;
            mFgDyJfysGcpO = mFgDyJfysGcpO;
            mFgDyJfysGcpO = ! RxHQUF;
            mFgDyJfysGcpO = ! mFgDyJfysGcpO;
        }
    }

    for (int llFTOAChPiZym = 469077986; llFTOAChPiZym > 0; llFTOAChPiZym--) {
        mFgDyJfysGcpO = ! RxHQUF;
    }

    return 223017444;
}

int yjigINmo::HfFSncdswvf(string IeDXfuk)
{
    int auZKbQn = -2047082492;
    int wWpdHeZfhGeGXL = -1787424150;
    double ZerolelRTDoVGzJ = -365439.13250924094;
    string AGPFN = string("RWqExyqQYHKNUcCHZpOEQKpLdRZagfZFuxHLTJKPaweSWhyudSxBumpwBACrnxyPsNJeyKLFiZRHZkdowvJlqLCiHaexAvFNmhwMyLgfIoovOfsGNOnFntKLaaaReUhrpBZygxYAiBqiJSvaujqSyDzXTWLPVMWSAkGcIIPyKJzvWelDLysBusUSUYgCXpVQPpsrUYhdiZnQKUndTTYExxlYlIYsslRfQRdKyYASXrtpYtpz");
    int IGdgfOYZHlGN = 526870892;

    return IGdgfOYZHlGN;
}

yjigINmo::yjigINmo()
{
    this->ijCfZIZ(string("tSYqLMZDcwAYpFFkiCYRVKqUefHSOJWSzSvCldfqBpxaHHYGejMtaQqLOZTvMNaslOHDlVRt"), 1531772725, true, -1515507745, -617054.6018091177);
    this->CThvyotVz(string("TyLDxGdzwfpNhZHUcHYdww"), string("VakAzZaiwLPvgujCRxoaHdjsEuDvzApyneiqtAzdsZPhVqnuWYSyJzHWaYNjgzrbcQBMvyALMNrKqZbPMSKedcbisFlbNpCtqNgnbrZVkhTopCZfjwAoyMJyeeCYtXChboUbkRMhoxChZATZVxZsgECJVmuqiFBUIhgY"), true);
    this->BBwyYUXTIQvhdYF(-620767.5566801182, -359396.32197142555);
    this->WiJgIcAxCXeJkJ(false, string("rXgJyKbcpyIZVXmJjmweyHSVBmDUToyAaWuDPtOMkOWEaDFXopYuxspIqIxGfZefWrcwPkXLVDcfmVuqkjeWpxhRHOIypTYDWJgaxMdClAZwcMEtDvkgtauajrtdlccOjmmdQtZGmQGzKmsvrQidAgzJYmjdRTXahMbUSZUuFzzWjohhoAGXNogrqcXXwXnvqQgjTfmOhwlqPKOPtqoNQRaEWokhIBjpBCfGnNPwxkoMHxoHq"), false);
    this->HfFSncdswvf(string("ZuYVkePfaZaUJCtqLKRcMyUkBOQlAiVXxECkteqXltxljUPBgekPvfapbvAkuqKmrcaYZUonIFLklnEhhOlaorbRQmgYlCOFbtBybmPUULiRlLiiYqJazrhGmEFZFecBcklrzrtrwGyMlwwpreYVQgpNwhUgLxTTu"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zkGRnW
{
public:
    bool JXjBDTeoM;
    bool rNYiCfmKZn;

    zkGRnW();
    string PYPasrO(int PgewtqSNXNx, string ztUzn, double JZgUGLlF, int yPfgCEIeyJnJnY, bool HJzEgflj);
    int bSXFbBCAe(bool BzLtqxP, string KgdIbiIPuik, int pZGlhtRDdrZgH, double LLBcTnaiBMyICKua, string zvFOQqtrEglT);
    double tjBGBiHJWnOj();
    double sYjfbx(int RfYru, bool efxmPPINSn, double JNsftzkhagZaNL);
    double HfdqVbVA(string uPrJmN, bool JtCIDUz, bool YEtunMAAsJQs, bool EqMwvXHHwBnQYodg);
    double QKnFyDsvZeDw(double rVsanlechDuSbvH);
    bool ckuXmZsa(int FrexnPOwHFlrSHeD);
protected:
    double RYOkqZTtLzgsulmp;
    bool CVsPDQtTYmowt;
    string HdETiWtzu;
    string duNRCjCQJIEI;
    string UShYn;

    bool riUArhztc(int EbNYlpEYE, int dLAltPS, bool CoFQypfKmCymlrBe, double xVruTxTdGOiI, bool wxjWBwSbJAx);
    bool LciINUsXumoI(int enTtbHmjibZaWYeu, double MuaywcTMV, double EacvXIGwvY, int rbxdpKhauRZCGA, double rsxHQyp);
    bool zpZNTCU(string RtepMrw, string ptMoPTcH, string aWdJcqqB, bool xswyGTl, string iebguLx);
    int mzhYnsYysiPoLY(double nGoSu, double ndgll, int jlFfGhKjNmhmU, double IHjCoLFSnVwfBx);
    double wXxayWNgKfkrrx(int xbxnMHKcru, bool ovBbiwvC, int QNUGcFugSbMM, double xrHzmcUHbsmwj, bool rkfIFp);
private:
    bool CgJRYwHgJdoaZ;
    double KGfMDVkFacvCTHQZ;
    bool DoiCNqcNgKvid;
    string MlAhEsgW;
    double GsqZjrtBts;
    int lRkmAhSunJIo;

    void dlMGxjrld(bool gyXKbqZvDda, bool vJMiRJPJmjc, int rTUHKezAXU, bool WGbabPGbsDlxTydt);
    double mSMaHglolNtyBs(string RAOid, int AgLjtXKxnDdzQ);
    string yxCeB(double LnnoyNBTo, bool nakBTJCvk);
    int fSdHtZlHKfjvZ(string XPyQRTKTzlG);
    string qEHtzLuDrVuUYPzl(bool fMTsvrD, bool wlwjnCDmQmHqS, double tMDdDcC, string BEvxAkrdLP);
    string YgnpnabnRAaA(bool nmailJ);
};

string zkGRnW::PYPasrO(int PgewtqSNXNx, string ztUzn, double JZgUGLlF, int yPfgCEIeyJnJnY, bool HJzEgflj)
{
    int PCTxfVpwiFTnlRcr = 780632286;
    string qrkkHdM = string("UjpRMXLgzmyHQQHEatqlniTgOKZAgaTRRYZzFbsnjLAiQKCZNaeQQoOIlrXixTJbCghpIzuwLkzDzvAat");

    for (int PBpNEiLaE = 276783222; PBpNEiLaE > 0; PBpNEiLaE--) {
        yPfgCEIeyJnJnY -= PgewtqSNXNx;
        PCTxfVpwiFTnlRcr /= PgewtqSNXNx;
        PgewtqSNXNx = PCTxfVpwiFTnlRcr;
    }

    for (int pBCtFPyOXfUd = 785239130; pBCtFPyOXfUd > 0; pBCtFPyOXfUd--) {
        PgewtqSNXNx += yPfgCEIeyJnJnY;
    }

    if (qrkkHdM > string("UjpRMXLgzmyHQQHEatqlniTgOKZAgaTRRYZzFbsnjLAiQKCZNaeQQoOIlrXixTJbCghpIzuwLkzDzvAat")) {
        for (int rWNWznOr = 1133422271; rWNWznOr > 0; rWNWznOr--) {
            continue;
        }
    }

    if (PgewtqSNXNx > 211714453) {
        for (int utoqB = 740610671; utoqB > 0; utoqB--) {
            yPfgCEIeyJnJnY = PgewtqSNXNx;
            yPfgCEIeyJnJnY -= PgewtqSNXNx;
        }
    }

    return qrkkHdM;
}

int zkGRnW::bSXFbBCAe(bool BzLtqxP, string KgdIbiIPuik, int pZGlhtRDdrZgH, double LLBcTnaiBMyICKua, string zvFOQqtrEglT)
{
    bool mlZibjhu = false;
    string LxFIOPmB = string("fHbgzOqeDFyVicMGYHpHucpYfGAJmz");
    double PDNJOQEqireX = -378700.0518726816;
    double tUuVTVzAxc = -984883.2177275311;
    double WDpLUYnbyWujOfyX = 254539.01093482514;
    int CEZBiF = -2113657530;

    for (int gRQjbMHxqr = 1853703390; gRQjbMHxqr > 0; gRQjbMHxqr--) {
        continue;
    }

    return CEZBiF;
}

double zkGRnW::tjBGBiHJWnOj()
{
    bool biquozhn = false;
    string ixcSFOJuHYSm = string("hSIBfqQNrqOQpDEjphkRhkosnPfDjaHLeCekEPrJuzRvBnWQpyXDZRcWMtuReBnuDbRfFGjHRtNUIPqtvAtbaKQZePyXdJXvZYiziweXThdkllLetRiEomfUKvcPLqdvuOqeySdfONpqJlEbexeElooqFrLWpZVjZiPUqsfOaqlnRMpfJyJpGbrCqmdfIuOQXmRXhwIDoVEZOMeVSsENUWVmBYDdrWXnpoucteqGMDXRQYWcMoDCFVWIa");
    bool divzuvPFuOQWs = true;

    if (biquozhn != false) {
        for (int VFWaqOxBRv = 577865359; VFWaqOxBRv > 0; VFWaqOxBRv--) {
            ixcSFOJuHYSm += ixcSFOJuHYSm;
            biquozhn = biquozhn;
        }
    }

    if (biquozhn != true) {
        for (int CEVsWBhGEYhqq = 230558312; CEVsWBhGEYhqq > 0; CEVsWBhGEYhqq--) {
            divzuvPFuOQWs = biquozhn;
            biquozhn = divzuvPFuOQWs;
        }
    }

    if (biquozhn != false) {
        for (int obfBGTBhqgWDv = 1617039007; obfBGTBhqgWDv > 0; obfBGTBhqgWDv--) {
            divzuvPFuOQWs = ! divzuvPFuOQWs;
            divzuvPFuOQWs = divzuvPFuOQWs;
        }
    }

    return 889318.8233979027;
}

double zkGRnW::sYjfbx(int RfYru, bool efxmPPINSn, double JNsftzkhagZaNL)
{
    bool YjkhXs = true;
    string sLTEaVUTGurGUDyj = string("CXwQeYasmBmAiaOhsIofqCzOSAbBTiHz");
    string YhzruvNl = string("GUdwWYypFzekAZkGsgakmojEaYAAdUgAfAXrgkRPJNcwpibnKOMXPKxr");
    string WKVrGANSPzENNTg = string("sSsfBVIWEWjJoAaBXzxfKQDmEUSaspnwujghquWWoeMMpXTUCSuswIfTWSjmdXWjQoROOojJPvgUfqAEILDDfDlNGEXHRTyYIEflaxbGrs");
    double hGUNNQ = 334200.4707642457;
    int BNuRXGxonMJXE = 1205755644;
    string HwTzM = string("IrTqoeYJpFpBtmUyBMpPxzKvmgyTeqxwr");
    string UBUxaGplwm = string("NsDnXpxvIWfBZZSjCLzZtyfqKqjWwKnRFIOewzZSLSrxpLMlMcHpUxzfPdJVuyPdmIdwxrZQrnueUofjKjhFOiFokvKaLpFQsnLrOjIBvkPcukxNPYNQckbDROdypxysWfRbgfhLQVCISVthxzTWAyZCDRznZIkCRePsKKHzUNmudNgZDKKUyOCwDbDixVJGcpCogttXwpNFonExMImgIyTUkzcTkiLfmVv");
    double bYHydVOxM = -155212.18556396934;

    if (JNsftzkhagZaNL >= 334200.4707642457) {
        for (int LKTjEwtri = 1493659400; LKTjEwtri > 0; LKTjEwtri--) {
            WKVrGANSPzENNTg += HwTzM;
            sLTEaVUTGurGUDyj = sLTEaVUTGurGUDyj;
            HwTzM = YhzruvNl;
        }
    }

    return bYHydVOxM;
}

double zkGRnW::HfdqVbVA(string uPrJmN, bool JtCIDUz, bool YEtunMAAsJQs, bool EqMwvXHHwBnQYodg)
{
    bool gUoQqjJTdnfdzaqc = false;
    bool JSUiKDOjwJLO = true;
    double FSXqZqVi = 720280.3385183814;
    bool pcgPAi = false;
    double tzgLKclTLpuYPUtV = -940350.2664659886;
    int oSXurFfa = 471743015;
    double HfKQvzwrWJeBfO = 225490.82054891073;
    bool udqtVpobSZk = false;

    if (JSUiKDOjwJLO != false) {
        for (int gRzVBkNIL = 337991179; gRzVBkNIL > 0; gRzVBkNIL--) {
            pcgPAi = pcgPAi;
            udqtVpobSZk = YEtunMAAsJQs;
            JtCIDUz = ! pcgPAi;
        }
    }

    for (int NRwBOVaKgql = 586116582; NRwBOVaKgql > 0; NRwBOVaKgql--) {
        continue;
    }

    for (int SGPeFFU = 517870100; SGPeFFU > 0; SGPeFFU--) {
        uPrJmN += uPrJmN;
        pcgPAi = udqtVpobSZk;
        EqMwvXHHwBnQYodg = EqMwvXHHwBnQYodg;
        tzgLKclTLpuYPUtV = tzgLKclTLpuYPUtV;
    }

    return HfKQvzwrWJeBfO;
}

double zkGRnW::QKnFyDsvZeDw(double rVsanlechDuSbvH)
{
    int ooQCNII = 770181428;
    int sgbrPaKPWS = 701675543;
    string SbaPtRoypnc = string("PVhGzEgqqrQIchMsUshgYvdVOFeAEfBgGeHaEHGInBzlSJtfkOJmwBtaeoBTtBsWLAVRzppqgaymvmBnVwhTMIjqrDmpiyfFdXsEjpuZGLqbogKpbkQTSvPbeeliBIHTBEHInRTkzslXuekJjMTWzVuykdyJrmLqepE");
    bool nLTJCGaUgAqOuj = true;

    return rVsanlechDuSbvH;
}

bool zkGRnW::ckuXmZsa(int FrexnPOwHFlrSHeD)
{
    string PBhciCWGyeqsvcNo = string("TUqZhHiJalBJEZajimpgbXpMMVnjVoNcrtSfrQLnnaEvAAPGhWwJrUpAdnBCWRfp");
    bool lXbeEuFIvAfEfkq = false;
    string NJhOiVs = string("SCSJJqRzbzksPawysyHFYXIuyLKlKauAdvGGOBntPpKMgiiCIfknGVsqURHbPUZciCMkqCLbcKISBmCDCFCiFoFxKFbeALUUSwobxPgbYePuzYUEjMuzDbkylpGGGJtehzMtfncFkKisuWBCIxYcaRAfgofZIfIWJRYVgSRuAdfLvPZlNltIJotfuoRwaRddvmGwgxnxRxjWUPlIVJvMqUfhhHiXW");
    string PWJcDwKL = string("VsomCRCajVqXpgYGwGUeZfytnQOqDohnXIZhQsWIprxeSaJQGhLMzAxqVCVgysOfGOqHAdLiMHzGHjzuUKEYLYkyKcnnCZtXsPUndefyYsTuoeozbcBAcGNOTTErqijSDdAiFKOhlUZGTwXgHnBxRceQgZYuNpfrCyAKzvVHNbLUyLxQaFsLgltnPSiULJfSgVrpePLTpABuZDLWBG");
    double ZVfnm = -779741.4832927636;
    bool AZHJVUdUwr = true;

    for (int nVzOpuSjLUm = 1815810035; nVzOpuSjLUm > 0; nVzOpuSjLUm--) {
        FrexnPOwHFlrSHeD = FrexnPOwHFlrSHeD;
    }

    for (int aoiXRHqG = 327756809; aoiXRHqG > 0; aoiXRHqG--) {
        FrexnPOwHFlrSHeD -= FrexnPOwHFlrSHeD;
        ZVfnm *= ZVfnm;
        lXbeEuFIvAfEfkq = lXbeEuFIvAfEfkq;
    }

    for (int IJhId = 439661411; IJhId > 0; IJhId--) {
        PBhciCWGyeqsvcNo += PBhciCWGyeqsvcNo;
    }

    if (lXbeEuFIvAfEfkq != false) {
        for (int EhGlKXHlylMi = 429399572; EhGlKXHlylMi > 0; EhGlKXHlylMi--) {
            AZHJVUdUwr = ! lXbeEuFIvAfEfkq;
        }
    }

    return AZHJVUdUwr;
}

bool zkGRnW::riUArhztc(int EbNYlpEYE, int dLAltPS, bool CoFQypfKmCymlrBe, double xVruTxTdGOiI, bool wxjWBwSbJAx)
{
    int XuwZyfKiiZMClh = 437335084;
    int lxkfaNp = 1841685622;
    string jIyyrNZN = string("OXDSjJjVcdgujGfAeTwcRwT");
    bool ajYmToCwrHLfs = true;
    double gpHnOcgfMHTCG = 582265.9343734874;
    string XfGEpWQOYFfcWh = string("JUxcukgtIEQmJYqwDpZyxbRl");
    bool dDeGDBMWmHLIOG = true;

    for (int CNVWYdeUSUkjBclo = 321079768; CNVWYdeUSUkjBclo > 0; CNVWYdeUSUkjBclo--) {
        continue;
    }

    if (xVruTxTdGOiI >= 582265.9343734874) {
        for (int ahjMbhS = 555309941; ahjMbhS > 0; ahjMbhS--) {
            wxjWBwSbJAx = dDeGDBMWmHLIOG;
        }
    }

    for (int LLdKLYQCVnU = 1510413328; LLdKLYQCVnU > 0; LLdKLYQCVnU--) {
        EbNYlpEYE = EbNYlpEYE;
    }

    for (int NciFKnnNWaW = 1301129524; NciFKnnNWaW > 0; NciFKnnNWaW--) {
        continue;
    }

    return dDeGDBMWmHLIOG;
}

bool zkGRnW::LciINUsXumoI(int enTtbHmjibZaWYeu, double MuaywcTMV, double EacvXIGwvY, int rbxdpKhauRZCGA, double rsxHQyp)
{
    string fNjls = string("buHBqzeQrAhyygHVwxIifaiMkBbYjiwOOKshyKwAgmxOSBFWEqYEinrrkIBgoGnvHdSWgfkacGWsEvtltAdYBpSHYbxLporKDLcKVIYusQfbxIvxtutuFTeDcsJUCcLsoPpifZrPelrjNLStvlOSCIuvdrNEdUudZOdjXYbvGtMxcDTiKLKIFhWfvFmFWdwqrSZhPMAApqsyztmYCaEPUxxSVIlJNRHFaGVbOiPKztFMWe");
    string dWelRRgP = string("dJrZZAfmMvFmLUnmAXRvMUObWnjBWfGthOQCMLQwJQmXaKbWLpCOUxhyjSUYrGpWCIgI");
    bool LjNlZsQFUXUzcG = false;
    double cCVUjNlHIGcZ = -236503.62218518072;
    double lvoLZ = -172261.25386130088;
    int IRZQwEhNYWqmjba = -1056569422;
    bool BhdHncG = false;
    string psnUAfqVwg = string("jtyJnGNXfsPWKaxEOsoyzofdpexghbsYiTWBRetNXsEaqwCxhMVDLfUugGDXLoPRBYAtlGRVsiRgPAeAeZOwMtnJscBEAPRcsZkspcnpLcyAiyiZLTNHZPHeZJwtPSMyNqTIvhNxsLaTnyhUCxYBBfLPkmzlvQYtGxhKzVPMTwHZnZOTTGPYMwbPwepXKpcqUhKpWvACTleoSxWIcnEYSqsOiLPDzedJWiGSRFOUEC");
    string aizChKgJ = string("XMTtkcpZyQrjUSoeGhzHYpEjmgMRt");

    for (int sLaTpBYjMLgaH = 443957001; sLaTpBYjMLgaH > 0; sLaTpBYjMLgaH--) {
        continue;
    }

    for (int JkaJOlwO = 1396215033; JkaJOlwO > 0; JkaJOlwO--) {
        continue;
    }

    return BhdHncG;
}

bool zkGRnW::zpZNTCU(string RtepMrw, string ptMoPTcH, string aWdJcqqB, bool xswyGTl, string iebguLx)
{
    double ngErohzYYjsS = -828797.0474494604;
    double JcstNqyTPDsk = -1023323.6820794322;

    for (int IYTGrNKODZq = 1192339743; IYTGrNKODZq > 0; IYTGrNKODZq--) {
        aWdJcqqB += aWdJcqqB;
        RtepMrw += RtepMrw;
        ptMoPTcH += RtepMrw;
        iebguLx += RtepMrw;
        ngErohzYYjsS += ngErohzYYjsS;
    }

    for (int EnOYLFu = 1368662929; EnOYLFu > 0; EnOYLFu--) {
        iebguLx += ptMoPTcH;
        ngErohzYYjsS /= ngErohzYYjsS;
        aWdJcqqB = ptMoPTcH;
        RtepMrw += RtepMrw;
        RtepMrw = aWdJcqqB;
    }

    if (ptMoPTcH < string("YRLuTyPYgXXOEQuEICXGQdqmZZsAxiGLOgcAoCGwEKhJsTQxSmmXRMHbLTBEMWfnWxeJkuXHGUklAoTeExiVpHtqavoewybTIixbiqGFjUYVy")) {
        for (int INlVWaChq = 1851268180; INlVWaChq > 0; INlVWaChq--) {
            iebguLx = aWdJcqqB;
        }
    }

    return xswyGTl;
}

int zkGRnW::mzhYnsYysiPoLY(double nGoSu, double ndgll, int jlFfGhKjNmhmU, double IHjCoLFSnVwfBx)
{
    string WHBRvqBpe = string("LHUmrQcdFBmBXlKKdHfHBCJAnahpOPuXDrwNHIdHueeizYAbGOhXzlUuCriEfvfLkcgzYAtNhAdEQZuUcHjiNAqKVBsYWkqoyiVKfmKBOBpsrzXUjaSznEz");
    int AKfItRRA = 2029600667;
    double jlaORG = 793256.4980005599;
    double iSrYL = -970660.8546105027;
    double YAQeApUPkFikfQ = -113274.99980764395;
    double dLyWxgCcSff = -1002773.9173069217;
    int AkQsnxKnwmSWBL = 1686888303;
    int AIUTkBB = 1208163570;

    if (nGoSu >= -1002773.9173069217) {
        for (int hohkL = 1458724944; hohkL > 0; hohkL--) {
            dLyWxgCcSff -= iSrYL;
            dLyWxgCcSff += iSrYL;
        }
    }

    if (AKfItRRA >= 1208163570) {
        for (int FkVPgJzSMf = 1480294436; FkVPgJzSMf > 0; FkVPgJzSMf--) {
            IHjCoLFSnVwfBx += YAQeApUPkFikfQ;
            AIUTkBB -= jlFfGhKjNmhmU;
        }
    }

    if (iSrYL >= -1002773.9173069217) {
        for (int jjERIM = 1515222622; jjERIM > 0; jjERIM--) {
            AKfItRRA += AIUTkBB;
            jlFfGhKjNmhmU += AkQsnxKnwmSWBL;
            jlaORG = jlaORG;
        }
    }

    if (YAQeApUPkFikfQ != -1002773.9173069217) {
        for (int zMOEcM = 82701979; zMOEcM > 0; zMOEcM--) {
            AkQsnxKnwmSWBL = AIUTkBB;
            AIUTkBB /= AkQsnxKnwmSWBL;
        }
    }

    return AIUTkBB;
}

double zkGRnW::wXxayWNgKfkrrx(int xbxnMHKcru, bool ovBbiwvC, int QNUGcFugSbMM, double xrHzmcUHbsmwj, bool rkfIFp)
{
    bool RUQDpEGH = false;
    string wafgOxFkwbnarkfX = string("PtrqiEIDcURKQtFTrIfevqtcUSgEVAiSADdLOiAntJqYpshlJTGkVfAyBSkEZIhmRjwcYgDgfRFuIUJDmFVasXjHvKFjCpjEKwoIrbRxqwTUEEfaibzseIsQkSfHFeYdhLrowjUmlQzkMvkjiVkhBQIgOjuOVYBRMrcmqHhATXBiZVopjmQlDeodlgRjGkcUKXKEcRGueSTxxQldIenlbNcqutKJYiQostYUFliqIFLphLelGvHFS");
    double xZMhAJLcmpzcbueP = -441197.17607418046;

    for (int CnZPD = 1577384018; CnZPD > 0; CnZPD--) {
        continue;
    }

    for (int oekXJybpUrfXJ = 89500664; oekXJybpUrfXJ > 0; oekXJybpUrfXJ--) {
        RUQDpEGH = ! ovBbiwvC;
    }

    return xZMhAJLcmpzcbueP;
}

void zkGRnW::dlMGxjrld(bool gyXKbqZvDda, bool vJMiRJPJmjc, int rTUHKezAXU, bool WGbabPGbsDlxTydt)
{
    string BVUXRGOGc = string("zDKCscdqShZOvQMxpFalKq");
    bool gWnVVREIMUv = false;
    int VUylTz = 1073172039;
    string gfEaKVAT = string("ukvGyfFQVBKXNwmDibvYiWzVwFQRDMTYvYSQOgqVwdlybsUeJMvmlIkvSXBUukmPsQsnfMTVLkcjnqlDSOoQFMalmwUTfzAksfOIwjwUuzGs");
    bool MnLgMReGVoa = true;
    int dpmZklv = -1651994566;
    double jyHeMFbqPzayMe = -595252.5046054096;

    for (int VPLSBY = 992557602; VPLSBY > 0; VPLSBY--) {
        continue;
    }

    for (int GozHSEApVWMSdHE = 401962580; GozHSEApVWMSdHE > 0; GozHSEApVWMSdHE--) {
        continue;
    }

    for (int tiFIlIOOCg = 588383054; tiFIlIOOCg > 0; tiFIlIOOCg--) {
        continue;
    }

    for (int DLhQdYBW = 1700027200; DLhQdYBW > 0; DLhQdYBW--) {
        gWnVVREIMUv = gWnVVREIMUv;
    }
}

double zkGRnW::mSMaHglolNtyBs(string RAOid, int AgLjtXKxnDdzQ)
{
    double BOhCGZBLps = -148005.51475501416;
    double RchGRaTXimUppAVu = 821277.5894654026;
    bool hbGXmapekdXKSh = false;
    int MADsJeLygNzQDG = 612628339;
    string UBmLF = string("lJREGqWfdNXhEyhWsWZpPzaQGvKEEWvNULPacEdVYtYfoNBYytYDGMroTqAiHXygdMZCMopdlIMNIyivUvwswhJjZEnFcdlhOmvbfiHzwNTCVeUJIoqMeNFLsPlRbvabsSmkYcNCQoLAKFAzC");
    bool GKXgqkLMHTJKOKg = false;
    double nglaysMvKwnnhcC = -250702.24717420063;
    string CtPJlUfNHbEw = string("keogPtaBIikgCdhzkxdslECWDYblGmQeFCZKlNRtBwMfoXKkaFWmyvpiLIeBEyOlJFU");
    int XIYPRdmjVLf = 2082042010;
    double BnCUoHDXm = 414411.61169902136;

    if (UBmLF > string("keogPtaBIikgCdhzkxdslECWDYblGmQeFCZKlNRtBwMfoXKkaFWmyvpiLIeBEyOlJFU")) {
        for (int WvFGupChaotw = 679034056; WvFGupChaotw > 0; WvFGupChaotw--) {
            continue;
        }
    }

    if (CtPJlUfNHbEw >= string("lJREGqWfdNXhEyhWsWZpPzaQGvKEEWvNULPacEdVYtYfoNBYytYDGMroTqAiHXygdMZCMopdlIMNIyivUvwswhJjZEnFcdlhOmvbfiHzwNTCVeUJIoqMeNFLsPlRbvabsSmkYcNCQoLAKFAzC")) {
        for (int aVRlBqdoyrGpWfjy = 1490498323; aVRlBqdoyrGpWfjy > 0; aVRlBqdoyrGpWfjy--) {
            MADsJeLygNzQDG = MADsJeLygNzQDG;
        }
    }

    for (int DGIRWSDVz = 1854203344; DGIRWSDVz > 0; DGIRWSDVz--) {
        RchGRaTXimUppAVu = BnCUoHDXm;
    }

    return BnCUoHDXm;
}

string zkGRnW::yxCeB(double LnnoyNBTo, bool nakBTJCvk)
{
    int yydcWjCoVWXgB = -1054765433;
    double fGdkr = 344133.3067349622;
    double BjTZAjIGdHAavK = 19386.65287035959;

    if (BjTZAjIGdHAavK <= 344133.3067349622) {
        for (int SRCJup = 1792033952; SRCJup > 0; SRCJup--) {
            LnnoyNBTo = BjTZAjIGdHAavK;
        }
    }

    for (int ZQUaf = 1587434013; ZQUaf > 0; ZQUaf--) {
        nakBTJCvk = ! nakBTJCvk;
        fGdkr += BjTZAjIGdHAavK;
        LnnoyNBTo -= BjTZAjIGdHAavK;
    }

    for (int oDzZlutpmV = 1141528080; oDzZlutpmV > 0; oDzZlutpmV--) {
        fGdkr = fGdkr;
    }

    if (LnnoyNBTo < 344133.3067349622) {
        for (int AQYwRnKZNmwrLQDA = 1863776069; AQYwRnKZNmwrLQDA > 0; AQYwRnKZNmwrLQDA--) {
            yydcWjCoVWXgB = yydcWjCoVWXgB;
            yydcWjCoVWXgB -= yydcWjCoVWXgB;
            LnnoyNBTo -= fGdkr;
        }
    }

    return string("VBmmjgUsYqksQanoYTUdwwuZSXLhVKjwUuxGCWebJuBYVnoDIfMZeFtTtWywjENCuNYdGvzCfvWdmhOY");
}

int zkGRnW::fSdHtZlHKfjvZ(string XPyQRTKTzlG)
{
    string VFboQMHi = string("bIKFpDXwBVEzfeTSHcvTMtGztvCGFHFOcFtQahlxAWiZtTfeGwLVoRwqXbpgBOFOpFiSljksqdrLKSNYMBNnEOpiLOd");

    if (XPyQRTKTzlG >= string("bIKFpDXwBVEzfeTSHcvTMtGztvCGFHFOcFtQahlxAWiZtTfeGwLVoRwqXbpgBOFOpFiSljksqdrLKSNYMBNnEOpiLOd")) {
        for (int vgegMeg = 1040274757; vgegMeg > 0; vgegMeg--) {
            VFboQMHi = VFboQMHi;
            VFboQMHi += VFboQMHi;
        }
    }

    if (VFboQMHi <= string("bIKFpDXwBVEzfeTSHcvTMtGztvCGFHFOcFtQahlxAWiZtTfeGwLVoRwqXbpgBOFOpFiSljksqdrLKSNYMBNnEOpiLOd")) {
        for (int PFJHoSoearBUweO = 540788966; PFJHoSoearBUweO > 0; PFJHoSoearBUweO--) {
            XPyQRTKTzlG = VFboQMHi;
            XPyQRTKTzlG = XPyQRTKTzlG;
            VFboQMHi = VFboQMHi;
            VFboQMHi += VFboQMHi;
            XPyQRTKTzlG += XPyQRTKTzlG;
            XPyQRTKTzlG += XPyQRTKTzlG;
        }
    }

    if (XPyQRTKTzlG > string("ycQZ")) {
        for (int XLRhp = 170796585; XLRhp > 0; XLRhp--) {
            XPyQRTKTzlG += VFboQMHi;
            VFboQMHi = VFboQMHi;
            VFboQMHi += XPyQRTKTzlG;
            XPyQRTKTzlG = XPyQRTKTzlG;
            VFboQMHi = VFboQMHi;
        }
    }

    if (VFboQMHi <= string("bIKFpDXwBVEzfeTSHcvTMtGztvCGFHFOcFtQahlxAWiZtTfeGwLVoRwqXbpgBOFOpFiSljksqdrLKSNYMBNnEOpiLOd")) {
        for (int ItHjYs = 1265671405; ItHjYs > 0; ItHjYs--) {
            XPyQRTKTzlG = VFboQMHi;
            VFboQMHi += XPyQRTKTzlG;
            XPyQRTKTzlG = XPyQRTKTzlG;
        }
    }

    return 2000660935;
}

string zkGRnW::qEHtzLuDrVuUYPzl(bool fMTsvrD, bool wlwjnCDmQmHqS, double tMDdDcC, string BEvxAkrdLP)
{
    int XzUYj = -1884013228;
    string wNwdfPhOgsTVIv = string("NPkXUjZYpaZMMcvSCjXmUnHEOjDfDIXccZDZbLZDrWcbuuXsawyOjPT");

    for (int lNvYQaZxXYmyu = 1648987563; lNvYQaZxXYmyu > 0; lNvYQaZxXYmyu--) {
        continue;
    }

    if (BEvxAkrdLP < string("vGuHohtgjTHxxlYsIHubQLFcvjSzPUJukpwQgYjpDqRMqhAlnoPkhHjfyJAfogeSBHdGGybOQhAHzmUeWDOycVmENcNVyYhChVuoQkhDcqvVKhYCozqLhBMqcxxJRppvrToPUW")) {
        for (int wZSfVLgYKB = 1518692209; wZSfVLgYKB > 0; wZSfVLgYKB--) {
            wlwjnCDmQmHqS = ! wlwjnCDmQmHqS;
            fMTsvrD = wlwjnCDmQmHqS;
            XzUYj += XzUYj;
        }
    }

    return wNwdfPhOgsTVIv;
}

string zkGRnW::YgnpnabnRAaA(bool nmailJ)
{
    string pOpQKIax = string("nlcAeEgoRehaEdGQOEUhlOrTFaTFwqHLPsuLQQIhpKztgYmJTPdTuYynRMghtgidQRujBktqFGoovtVbzHeSlxRTwHEuLEmLuwFQqIqKchpKSUbwkuAsSVfdHKquUDUqquMPXWsBIsGjKRbUDbJMHhzugGIsxfFEApIqfzfgucLXVgNYkPernmcAlQBiFTBCzHyRuaVUeJMLgRHDGFnB");
    double paWqvyUiW = 459755.53820257063;
    double mkTJZsZI = -975473.338743051;
    int HijxOhcOVfGGwj = 997080131;
    double PKqInxphTdX = -133283.77378456524;
    bool XdgbaLDv = true;
    double pryrnTOkIXq = -814028.3781955153;
    double OuTRVVCT = -392088.82140414417;
    double TwjZqy = -811928.4693752399;

    if (pryrnTOkIXq > -814028.3781955153) {
        for (int bigYfrZVjVr = 1303050018; bigYfrZVjVr > 0; bigYfrZVjVr--) {
            continue;
        }
    }

    for (int dAgMDDH = 1747138624; dAgMDDH > 0; dAgMDDH--) {
        continue;
    }

    for (int AXflIAmgwkrCeMZh = 1599546420; AXflIAmgwkrCeMZh > 0; AXflIAmgwkrCeMZh--) {
        OuTRVVCT = pryrnTOkIXq;
    }

    return pOpQKIax;
}

zkGRnW::zkGRnW()
{
    this->PYPasrO(-586700382, string("qgwSLHrbsCSIujLpYpiVXGOUatjMoGrCS"), -552348.4657608924, 211714453, true);
    this->bSXFbBCAe(false, string("yzsiFzlVKlNbiHBn"), -1692065727, 332137.9595570771, string("ESPhrKpwDLsGjfHBAqoYyivyoOvBdSYaQvuHzGGWLGSEnerzlNsnVjQyPDiBQyHdJfuKTNmZQiBHCQLVBkroYyptctBywVkhZtrPIVBWNZAJVAuEhDjaWlmuvISRlMsaiMvQvUZGFlZGFjDnUzslDniBfYKayMrYFcsHbLjmoEdEBzlsnCYXEDBoIFkwxZjykldRBkFIKqQBmaopINzyvPQRZdQw"));
    this->tjBGBiHJWnOj();
    this->sYjfbx(797563140, false, 886350.3750225062);
    this->HfdqVbVA(string("RVepVWPnrFfrfoDjQPGMVRHdqZtcXhfKRMKEuyUBUQCqMgPzKfdjcqtChYFtnLPdcrIKeeQvUptWlcqceqymHayvMigasoQjiBqVkxGwFfiVhOFCEjFXePsQTYxWMuQEubTtmTDKljKjKgllrzRaRPwDzxHEHejPVzAkdoLZHBQvaGX"), false, false, false);
    this->QKnFyDsvZeDw(253009.25933018333);
    this->ckuXmZsa(-1904682649);
    this->riUArhztc(243519857, -1996587576, false, -1016748.341285016, false);
    this->LciINUsXumoI(-945124558, -777525.5336038835, -885433.9822780988, 230736073, -458377.0018504532);
    this->zpZNTCU(string("nkgWEZrxfrzaNTQHWJsUHdnmPuxJSFdIkSQpDkxDouJDTHEuyCSUuwCXHVVkwZaoMYHPctaEbaovXYVCFPiUZHXkPggsTADgwgOPNnQLfeaHVRNrOWQEoJTSPumxweSdZnxyGySDGfadghAShwQHhRLZwMrbbkPsdGqrKN"), string("auVmhxGayitHhfucasrKzfjaulnIXIBesOtibgdNdmzTMkQRqYpRdBBbDCkNYuVBQpkolleKHytLkdJVwOdjLDPpPszCgMtXvlVavNobEOkpLRCsMoZXWlHcxsVIttobNYBrNCKTkKJKwBjyheYszwlBwUgvctavKLEHxCWBvxXUKbNnqerMfvfdAVGJnfRJDMUkVbhtipYPKvLNxfmnejiCTmSqmajdsMOLFVnNudPmYBDznVsjDfki"), string("YUadZwjEpCZpApoukMkmrkpFfSaViiCWraWSEZSmvnbODvliniJhkrvpEmTKgRBJgsJGzucvWBDQyyBRprsqXoSHNZrmlIMlQQixSPHCDIlCEgPuUdjHAApxLmzNTqMPYynZaeNPCww"), false, string("YRLuTyPYgXXOEQuEICXGQdqmZZsAxiGLOgcAoCGwEKhJsTQxSmmXRMHbLTBEMWfnWxeJkuXHGUklAoTeExiVpHtqavoewybTIixbiqGFjUYVy"));
    this->mzhYnsYysiPoLY(-469312.5478068591, 918517.7686188438, -1597400554, 876714.1585522707);
    this->wXxayWNgKfkrrx(581885606, false, -498573539, -145371.65609138887, true);
    this->dlMGxjrld(true, false, -1525263595, false);
    this->mSMaHglolNtyBs(string("yartmCryxAZBOdTQjiyOuZIUdeaGxeKI"), -284940654);
    this->yxCeB(-873270.0097079189, false);
    this->fSdHtZlHKfjvZ(string("ycQZ"));
    this->qEHtzLuDrVuUYPzl(false, false, 849545.1477861436, string("vGuHohtgjTHxxlYsIHubQLFcvjSzPUJukpwQgYjpDqRMqhAlnoPkhHjfyJAfogeSBHdGGybOQhAHzmUeWDOycVmENcNVyYhChVuoQkhDcqvVKhYCozqLhBMqcxxJRppvrToPUW"));
    this->YgnpnabnRAaA(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class udKiIlHJZLE
{
public:
    double SVbwcUsfLOohQG;
    double fGnkgIHOYxY;
    string xvZsYyFkTvAuDSmA;

    udKiIlHJZLE();
    void snpFgPQvsZstKa(double yzqVptmdOjPD, double TCWMzDV, int BTSNTq, double QQglSZnMOeSYT);
    bool JzGrEftRgU(int weMkjUrhSdGRmpGG, double QbGvWSuytcOWyF, double zEBklIpPZRLhML, int cLnggLFeidKGeOg, string jGGLJaMXIJH);
    double URGrJDiltDCyS(int DMyJPGsJVKjLC, string GZvOQGcK, int qAKXxDb, bool WpBixXrmie);
    string geKtubHaSQMYpW(int zRhyavtfsJfayhb);
protected:
    double zRJdOL;
    double DUivxFnBH;
    string tXWAoUoBhK;
    bool BGnZoMm;
    int gicTmvVsJrvFc;

    string gKPTjYr();
    void sKwUT(bool ChTqRzUf, int xOLFiIymOT);
    bool ZzHfrinLCh();
    double EkzwLHhrqvKf(int yZrcVflEKjdJp, string yixCJ);
    bool HFTKYkQiMrAOXZD(double ZjpNaoU, int bFVMCbkKJ, bool ZUrFHKcwS);
private:
    string aqyUcNCnsZZlzXha;
    int vEoBCpVfLuTZnIA;
    double FuEnvHo;
    string zUIlPZGixTimovV;
    double HQZfmKPtVttyFkC;
    bool SVpluqweSfvjcmhJ;

    void RgXgkSaIoWoVr(string OIXNUbL, int INcktgpzFZ, int KIyHE);
    string ImyvhVRxAyqSts(bool obpTpjuGUzgxVaww, bool OSAoar);
};

void udKiIlHJZLE::snpFgPQvsZstKa(double yzqVptmdOjPD, double TCWMzDV, int BTSNTq, double QQglSZnMOeSYT)
{
    int foofpuSJyzAulpZ = 2147111561;
    double TkBEJFoRJjez = -759721.1259469806;

    for (int nWktlebFyVi = 1841676901; nWktlebFyVi > 0; nWktlebFyVi--) {
        TkBEJFoRJjez = yzqVptmdOjPD;
        BTSNTq = BTSNTq;
        QQglSZnMOeSYT *= TkBEJFoRJjez;
        QQglSZnMOeSYT *= yzqVptmdOjPD;
        TkBEJFoRJjez /= QQglSZnMOeSYT;
    }

    for (int kQqdI = 683763061; kQqdI > 0; kQqdI--) {
        BTSNTq *= BTSNTq;
    }

    for (int JMQyBwfy = 1218005849; JMQyBwfy > 0; JMQyBwfy--) {
        BTSNTq *= foofpuSJyzAulpZ;
        yzqVptmdOjPD /= yzqVptmdOjPD;
        TkBEJFoRJjez += TCWMzDV;
    }

    if (TkBEJFoRJjez <= 892947.8004757537) {
        for (int eohUXvQJqmv = 1340758921; eohUXvQJqmv > 0; eohUXvQJqmv--) {
            yzqVptmdOjPD += TkBEJFoRJjez;
            QQglSZnMOeSYT /= QQglSZnMOeSYT;
        }
    }
}

bool udKiIlHJZLE::JzGrEftRgU(int weMkjUrhSdGRmpGG, double QbGvWSuytcOWyF, double zEBklIpPZRLhML, int cLnggLFeidKGeOg, string jGGLJaMXIJH)
{
    double qnulibThxSI = 245628.61953481523;
    double PyNlepXKmPBSwIm = -67627.66511334012;
    bool JHlOAFkzZEyMxtN = false;
    bool sJvmv = true;
    bool TUTPwKT = true;
    string UatzoK = string("lSiiNqaHybwJBMSiaNvyhYlqnKTysrCexXWyWpOerZXfSgIVsZfWuhXHtUyOxAGhLevngBNnZbzmssacaGODOiVKKViUUFeFtrHXtbXxrOSMYQPtNyzKETxRvKuTjEQCEa");

    for (int AedkNxuSsY = 1849299926; AedkNxuSsY > 0; AedkNxuSsY--) {
        UatzoK = jGGLJaMXIJH;
    }

    for (int bLITDWLgPZOLvlss = 1630549737; bLITDWLgPZOLvlss > 0; bLITDWLgPZOLvlss--) {
        jGGLJaMXIJH += UatzoK;
        qnulibThxSI += QbGvWSuytcOWyF;
        weMkjUrhSdGRmpGG *= weMkjUrhSdGRmpGG;
    }

    return TUTPwKT;
}

double udKiIlHJZLE::URGrJDiltDCyS(int DMyJPGsJVKjLC, string GZvOQGcK, int qAKXxDb, bool WpBixXrmie)
{
    bool IGCcoh = true;
    int WuIIMnf = -1199893246;
    double elryTxpqNUfK = -796044.9327468624;
    bool aIwHudhqxzEuQU = false;
    int fKgoRnOGXGUbrV = 499190104;
    double dBGYfEEEHHqq = -606049.7565206285;
    double QweiHup = -1046718.7490912938;
    int RhognwZkfqiTb = 1039034321;
    bool DteaUhnLiHjSKzGn = true;
    int MbrOPpDHceAQI = -767736507;

    for (int wOqPH = 1451211058; wOqPH > 0; wOqPH--) {
        WpBixXrmie = ! aIwHudhqxzEuQU;
    }

    for (int GLygUREBXuukpT = 536882653; GLygUREBXuukpT > 0; GLygUREBXuukpT--) {
        IGCcoh = DteaUhnLiHjSKzGn;
    }

    if (elryTxpqNUfK < -606049.7565206285) {
        for (int RSVODcQyPmeixDEM = 4434386; RSVODcQyPmeixDEM > 0; RSVODcQyPmeixDEM--) {
            aIwHudhqxzEuQU = ! DteaUhnLiHjSKzGn;
        }
    }

    for (int YOBRbIkav = 1960321824; YOBRbIkav > 0; YOBRbIkav--) {
        WuIIMnf -= qAKXxDb;
        GZvOQGcK += GZvOQGcK;
        aIwHudhqxzEuQU = aIwHudhqxzEuQU;
    }

    return QweiHup;
}

string udKiIlHJZLE::geKtubHaSQMYpW(int zRhyavtfsJfayhb)
{
    bool yanJyd = true;
    bool eIXYDRytMFMJV = false;
    double RGoIMBfajuEkgNc = 954265.2485333204;

    for (int nvNpUIZ = 1634721215; nvNpUIZ > 0; nvNpUIZ--) {
        continue;
    }

    if (yanJyd != true) {
        for (int DgLdEZCiHQTwI = 63649973; DgLdEZCiHQTwI > 0; DgLdEZCiHQTwI--) {
            continue;
        }
    }

    if (eIXYDRytMFMJV != true) {
        for (int equyozRTYZI = 408469278; equyozRTYZI > 0; equyozRTYZI--) {
            yanJyd = ! eIXYDRytMFMJV;
            zRhyavtfsJfayhb /= zRhyavtfsJfayhb;
        }
    }

    return string("zqSBcHRCfevskDATFtuQwlCYNdCgJCxPWzRAQdCpltuQTtzaeuOcUsspJyTngQbTMaHxuROKNGOPXPPqlneAoytpStdwclGDZSmznFClaIKfclrCqBPaKkWzmAiZPVRrToImFxAcmoWyZIIuIPxSEZYhFXAUATqcPxQsbVUJFylqkOYQUCuLokVWbvroSAWKbohmnmzZfGxFwgrxaqdtWsrUHiFgJoZMcidewiNG");
}

string udKiIlHJZLE::gKPTjYr()
{
    int YcdoDU = -1072936243;
    double DLjsAGVKD = 463808.9981420765;
    int KEijaPVmWC = -1478397013;
    bool dXITCClAcC = false;
    bool MhcOgPMM = true;
    double MQSkRfN = 728081.5056673774;
    bool jvEuhdv = true;
    double bGAYJe = -929882.6489551744;
    double DUwqtLYLxhptx = -726010.7288606565;
    bool VWrKZ = false;

    for (int wKyFDnrS = 76359735; wKyFDnrS > 0; wKyFDnrS--) {
        bGAYJe *= DLjsAGVKD;
        MhcOgPMM = ! jvEuhdv;
        MQSkRfN /= MQSkRfN;
        dXITCClAcC = MhcOgPMM;
        DUwqtLYLxhptx -= bGAYJe;
    }

    return string("gpDm");
}

void udKiIlHJZLE::sKwUT(bool ChTqRzUf, int xOLFiIymOT)
{
    int RnNiFygGpwvoXWyB = -1570929713;
    string LeVjZfI = string("JgNgVWIWDSXQYAMatxWhszVHIoXDSGpqtNgQNulyawtmeLSZVPatQOtcoKusmdEcNTVGZBBtBqYzwyHuYmNHTQxMgumJoNlWIXdoDIpsuXIJPsrAguldMSfZYQUveIuAFgPDZEJotbMQVWAketkRGbjRSpBzWiNXZUqwBKEESlFHdNRbfsKxymleaarOkt");

    for (int eaLaezRyY = 1917762402; eaLaezRyY > 0; eaLaezRyY--) {
        continue;
    }
}

bool udKiIlHJZLE::ZzHfrinLCh()
{
    double hQSwfcRXkcil = 808338.0287629988;

    if (hQSwfcRXkcil != 808338.0287629988) {
        for (int ZoiHAgxjibnai = 1202686397; ZoiHAgxjibnai > 0; ZoiHAgxjibnai--) {
            hQSwfcRXkcil -= hQSwfcRXkcil;
            hQSwfcRXkcil -= hQSwfcRXkcil;
            hQSwfcRXkcil /= hQSwfcRXkcil;
            hQSwfcRXkcil = hQSwfcRXkcil;
            hQSwfcRXkcil *= hQSwfcRXkcil;
            hQSwfcRXkcil *= hQSwfcRXkcil;
            hQSwfcRXkcil *= hQSwfcRXkcil;
            hQSwfcRXkcil -= hQSwfcRXkcil;
            hQSwfcRXkcil += hQSwfcRXkcil;
            hQSwfcRXkcil /= hQSwfcRXkcil;
        }
    }

    return false;
}

double udKiIlHJZLE::EkzwLHhrqvKf(int yZrcVflEKjdJp, string yixCJ)
{
    double pskCPozFVkiKXR = -329451.32069025305;

    if (pskCPozFVkiKXR > -329451.32069025305) {
        for (int fiOOJm = 2121956344; fiOOJm > 0; fiOOJm--) {
            continue;
        }
    }

    if (yixCJ == string("rAZasxDNXtPGMXsSDUwlpsZIufUiEYgQkjszzZAslAZuvPwCHkhGXxdFeSekZWtMLIdRHUSxHQBohnnGsDdEGYVJUCrSoguyYAdZATKoBHTLUMCcNcjGYppeRToFxFQyicoQoyOIjMQUYJeOmjjkhDaNThZVYZF")) {
        for (int MNkFdUhCph = 1730422921; MNkFdUhCph > 0; MNkFdUhCph--) {
            yixCJ += yixCJ;
        }
    }

    return pskCPozFVkiKXR;
}

bool udKiIlHJZLE::HFTKYkQiMrAOXZD(double ZjpNaoU, int bFVMCbkKJ, bool ZUrFHKcwS)
{
    double rEbcWJqNzGyHSx = -333291.0587249537;

    for (int qDLujemw = 1148709598; qDLujemw > 0; qDLujemw--) {
        ZjpNaoU /= rEbcWJqNzGyHSx;
        ZjpNaoU *= ZjpNaoU;
        ZjpNaoU /= ZjpNaoU;
    }

    if (bFVMCbkKJ >= 1941763092) {
        for (int XxDvjHBRSp = 311746704; XxDvjHBRSp > 0; XxDvjHBRSp--) {
            ZjpNaoU -= ZjpNaoU;
            ZjpNaoU *= ZjpNaoU;
            rEbcWJqNzGyHSx = ZjpNaoU;
            bFVMCbkKJ += bFVMCbkKJ;
            bFVMCbkKJ *= bFVMCbkKJ;
            rEbcWJqNzGyHSx -= rEbcWJqNzGyHSx;
            ZUrFHKcwS = ZUrFHKcwS;
        }
    }

    if (ZjpNaoU <= -333291.0587249537) {
        for (int waQdXcBgp = 490397723; waQdXcBgp > 0; waQdXcBgp--) {
            ZjpNaoU += ZjpNaoU;
        }
    }

    if (ZjpNaoU <= 157721.66120842626) {
        for (int HiTvLPVCHtYlLGpz = 25343320; HiTvLPVCHtYlLGpz > 0; HiTvLPVCHtYlLGpz--) {
            rEbcWJqNzGyHSx += ZjpNaoU;
            ZjpNaoU *= ZjpNaoU;
            rEbcWJqNzGyHSx += ZjpNaoU;
            ZjpNaoU += ZjpNaoU;
            rEbcWJqNzGyHSx += rEbcWJqNzGyHSx;
            ZjpNaoU /= ZjpNaoU;
        }
    }

    return ZUrFHKcwS;
}

void udKiIlHJZLE::RgXgkSaIoWoVr(string OIXNUbL, int INcktgpzFZ, int KIyHE)
{
    bool KFAsEl = false;
    bool bBDLlMDqbb = true;
    double yIUuyQbp = -573851.7130458436;

    for (int rvrAnxscpRiifJX = 566384449; rvrAnxscpRiifJX > 0; rvrAnxscpRiifJX--) {
        KIyHE -= INcktgpzFZ;
    }

    for (int xlmqCTiMmvanhP = 1476533701; xlmqCTiMmvanhP > 0; xlmqCTiMmvanhP--) {
        continue;
    }

    if (KIyHE >= 1966097015) {
        for (int ehyTPkQGWTQ = 732154580; ehyTPkQGWTQ > 0; ehyTPkQGWTQ--) {
            continue;
        }
    }

    for (int YwwyfFJTEXlN = 1934883305; YwwyfFJTEXlN > 0; YwwyfFJTEXlN--) {
        KFAsEl = ! bBDLlMDqbb;
        bBDLlMDqbb = bBDLlMDqbb;
        bBDLlMDqbb = ! KFAsEl;
        bBDLlMDqbb = bBDLlMDqbb;
    }

    for (int nljrf = 1124065864; nljrf > 0; nljrf--) {
        KIyHE /= KIyHE;
    }
}

string udKiIlHJZLE::ImyvhVRxAyqSts(bool obpTpjuGUzgxVaww, bool OSAoar)
{
    int ZqVklZxpv = 1835570976;
    int OKJtAggissmnuEJn = -1406704678;
    string wMFKgzpIsREsy = string("idiOvRTamaQgBcoHXHYdJrKBSFuIVlczHMsVAdpOwTteTrYLjyqsYRwAlLhvFiSDFGQUposDtsWfslUbGWwdqfVrInOgwjtodWxTERYrWNvEfSFmFaOBJywUQFaLIRsjVbJjmUwrgewBxlbGYlkSBJRTabRCGdTgnATybUanMMWbAlxgzr");
    bool fkJRmGCLk = false;

    for (int hOgsIerTLQMCf = 97141974; hOgsIerTLQMCf > 0; hOgsIerTLQMCf--) {
        continue;
    }

    if (wMFKgzpIsREsy < string("idiOvRTamaQgBcoHXHYdJrKBSFuIVlczHMsVAdpOwTteTrYLjyqsYRwAlLhvFiSDFGQUposDtsWfslUbGWwdqfVrInOgwjtodWxTERYrWNvEfSFmFaOBJywUQFaLIRsjVbJjmUwrgewBxlbGYlkSBJRTabRCGdTgnATybUanMMWbAlxgzr")) {
        for (int hVYimiVFnbVZwXZW = 1102795603; hVYimiVFnbVZwXZW > 0; hVYimiVFnbVZwXZW--) {
            OSAoar = fkJRmGCLk;
            OSAoar = ! OSAoar;
            fkJRmGCLk = fkJRmGCLk;
        }
    }

    if (ZqVklZxpv == -1406704678) {
        for (int BFVns = 1383554848; BFVns > 0; BFVns--) {
            OKJtAggissmnuEJn -= ZqVklZxpv;
            obpTpjuGUzgxVaww = OSAoar;
        }
    }

    if (wMFKgzpIsREsy > string("idiOvRTamaQgBcoHXHYdJrKBSFuIVlczHMsVAdpOwTteTrYLjyqsYRwAlLhvFiSDFGQUposDtsWfslUbGWwdqfVrInOgwjtodWxTERYrWNvEfSFmFaOBJywUQFaLIRsjVbJjmUwrgewBxlbGYlkSBJRTabRCGdTgnATybUanMMWbAlxgzr")) {
        for (int wTagTIlBfJURgoSM = 1219033760; wTagTIlBfJURgoSM > 0; wTagTIlBfJURgoSM--) {
            continue;
        }
    }

    return wMFKgzpIsREsy;
}

udKiIlHJZLE::udKiIlHJZLE()
{
    this->snpFgPQvsZstKa(50139.047063429214, 567518.9031164492, -1158510818, 892947.8004757537);
    this->JzGrEftRgU(247646855, -951458.4897187882, -963611.3893285354, -397956548, string("CVHjugmdcQpjiFYpViaTVwCnCAyfxnhJmAqPMDboQIOWPEAxnWksWzDxgAQIvfMjGvjzpIuhdIJXzJxZLvjKLKuuYaWjOssePAZzNanKedOLjcdApbZOiyOMbiXMVOqmTgrEQKUfLQhmDiJZBAhWmRyWKgtbrfSRDvLLVmwSMkmGJOytaySMKgMseBWnGQYzDbftgdiIWCRHwImIpp"));
    this->URGrJDiltDCyS(-882238300, string("pkdSziLtAYbKDYzvDJCzELZqteQmXcTnGWfjznBBXdQbXQTLYUznTwAgqElsgdqezLfTYgzZAHfKZHfajpXEsBHeWuVRrnREPzJXEksnbpmMYuXkjgtonVoySKrdwYistKhwXQeCZVLqYcIrvyUxtAYZKCbjDvFCLNdLBGTEpUAXqRnlEzHNDChuwNAmvFeDNuPQoPbUzEdHnSGCCC"), -1925051414, false);
    this->geKtubHaSQMYpW(-1641077248);
    this->gKPTjYr();
    this->sKwUT(false, -212883533);
    this->ZzHfrinLCh();
    this->EkzwLHhrqvKf(88681163, string("rAZasxDNXtPGMXsSDUwlpsZIufUiEYgQkjszzZAslAZuvPwCHkhGXxdFeSekZWtMLIdRHUSxHQBohnnGsDdEGYVJUCrSoguyYAdZATKoBHTLUMCcNcjGYppeRToFxFQyicoQoyOIjMQUYJeOmjjkhDaNThZVYZF"));
    this->HFTKYkQiMrAOXZD(157721.66120842626, 1941763092, false);
    this->RgXgkSaIoWoVr(string("LhgZdVIwwDnMGoMgJJBTODcMrcBTdDImjFGeqCDcLAcJtOXPehpnHxUwgwEsplqSoMEieIdTRCwulQWzAXKheKFTeYWQVVyZAhgDndQVlHHKyxXDTfHJTBKlmfELnEvlgEUAshsulKrEqGydHdzfDGcJPApocogkXQDAEZgiGNijfXJmpdlZCpQpiJzNDFmRjIquxVpP"), 1966097015, -842990030);
    this->ImyvhVRxAyqSts(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NWUVShZej
{
public:
    string NUaSFKGSIop;
    string iFDNeWiNwZaTXknG;
    double mlAMyv;
    string yvdidcUuIrFhJA;

    NWUVShZej();
    string KQoFABcTX();
    bool DIEylGJdcw(double FBrvlldmRKp, bool AekfnvHVX);
    int eWzIaXvG(int fXhbkCctDiBQZNuq, double lZyCWOO);
    void NtrwOvYIgUACyRWA(bool pVcfnwuRXxHIc, int DqvXpewX, double TKGaMoC, int wHycNIHTZDsae);
    bool ceCVug(bool qUvJMzQIQxA, double qTKjCJTQnfv);
    bool zfvAVlc(int dlifMWhXVgK, double HpqkcytV, bool EcyFo, bool gKwjBOYyRqFb, bool ClJsPqSopprtEs);
    int BoxcgNridxXehLH(double VsiUqsGcb);
    double hzFPekUAsNMZyQZW(int dEBhFXaCi, bool naoGsnCOC, int svOycvrgRkqz);
protected:
    bool HdSswgd;
    string zDonbKBiFiFrt;

    int HXKkMFMdCobwczy(bool cvYKJsW, bool AZWdwj, string fmbUCRvyB, double uiLIyiUzBordSBr);
    void jwxCCmxiC(string IdHGrFcGT, double ISCVDNH, string ATgTJoH);
    double sRqkWNKdqX(bool pxDgvzatOHJn);
private:
    double uMnmkscMgHp;
    double LFDtYnGnkSwZGR;

    int pPpImzTwpdr(string AAcoeRIKE, bool DeYdVdqyc, double hGrdzQeJCBJXx);
    bool pjUBNMJvTOd();
    string fsLgPdSyMPYQVRS(string UpoVZjhtyY, int tWblkFwLpZb, double uZSMKpa, double iPDmoXzSq);
    double tNHCGuFdhP(int TxyFma, string OtWwWINH, string qLqtzaQSV, bool WIzhBJguKP, string knpWBmRvA);
    double vEMiNsNjdhpkJi(bool eOkkOQ, bool OLAoGWEkcvSEcSnd, bool jVnRD, bool fJMNf, string brAYnYG);
};

string NWUVShZej::KQoFABcTX()
{
    int NRWMjlUYgNmt = 1324028977;
    double hydEBdiuMXh = -336745.0364433107;
    bool AhTEQiQE = true;
    int eHASwwVslnP = -1287680292;
    bool vbjntmnO = true;
    bool Jggxiu = true;
    double LyWdD = 381633.71888911375;
    bool FKIZzjAVHpnOXx = false;
    int lHwTuAONyTbCvNG = -1311741918;

    if (vbjntmnO != true) {
        for (int lphbGKBLOOQ = 1819658612; lphbGKBLOOQ > 0; lphbGKBLOOQ--) {
            continue;
        }
    }

    for (int llFNP = 685053105; llFNP > 0; llFNP--) {
        continue;
    }

    for (int WHVNdDiSALRymTAs = 1550490819; WHVNdDiSALRymTAs > 0; WHVNdDiSALRymTAs--) {
        lHwTuAONyTbCvNG = lHwTuAONyTbCvNG;
        FKIZzjAVHpnOXx = vbjntmnO;
    }

    for (int XmyUiDPzOqGdQ = 1805352140; XmyUiDPzOqGdQ > 0; XmyUiDPzOqGdQ--) {
        vbjntmnO = ! FKIZzjAVHpnOXx;
        lHwTuAONyTbCvNG += lHwTuAONyTbCvNG;
        NRWMjlUYgNmt -= eHASwwVslnP;
        lHwTuAONyTbCvNG += eHASwwVslnP;
    }

    for (int lMjwTbKpi = 1079937358; lMjwTbKpi > 0; lMjwTbKpi--) {
        NRWMjlUYgNmt -= lHwTuAONyTbCvNG;
        vbjntmnO = FKIZzjAVHpnOXx;
        vbjntmnO = ! Jggxiu;
    }

    return string("UuIJsdZDRHFaNqEDBNuypeGhtBAVDppRMdhcYhffeilMwMWFiurQWviFBGCprgXcfPuPWrquMkjaZeazJDdBxNfwxISZMECNeFfkNCGuOEGCWANEuUMlbITbQeBrSqBPGRvZbqgSvYNZhbkoBcZWedlFbOoSyuuHQZMJjjAkbQxEMUcLVhjrezKRARkfUrSjFavuONUEzoNOCUfohNSddwCRVUJyKmgQoLKlwDelgKQq");
}

bool NWUVShZej::DIEylGJdcw(double FBrvlldmRKp, bool AekfnvHVX)
{
    int ByChpdOKwUAERCv = -1724448075;
    string tRwrFenVazfWQWsm = string("KZOwxVEFCzJAmiVpAJXlJHkKvPtvADUNtidpqPPNdRnKFZEEkbPUpVIvIlbkLVgQMkgImxBwlxqxhEEJQKLh");
    bool eFQJae = false;
    bool wNhSfxCGZfxn = true;
    double HtFYJC = 87442.63390424667;

    return wNhSfxCGZfxn;
}

int NWUVShZej::eWzIaXvG(int fXhbkCctDiBQZNuq, double lZyCWOO)
{
    bool WHANmq = true;
    string KJYZhdpFSQgU = string("HOmwqiujALxxVVkPBTMMLBlBWFOceHjzDZUbeFDmnBBxuncpEOBnFDjNVubddeJvKdDWzKVzMOVDwcsrNuyyutQZPYVabUdUGXtXWWsBmUBPUZBPzozaDmHpVhbEQnxVxoUrkMcGTiEMCdkWDSQeTQdDdcNibPBXUjcfpXzSPoWQoyfLclBBbaZAugKCzLEwetDDtluZLxFmJAXPdOYlEDjRLUCOGZpocQXfbtFbpxRholjbSNoTNnR");
    double fPfEBcsJfkzrm = -125987.27237032697;
    bool puLoJkwQzLtLY = true;
    double LjBNlPawLnwHyW = -934997.1569627657;

    for (int RLDVYzLZbr = 30208557; RLDVYzLZbr > 0; RLDVYzLZbr--) {
        LjBNlPawLnwHyW /= lZyCWOO;
    }

    for (int wWEnmAl = 167563573; wWEnmAl > 0; wWEnmAl--) {
        fPfEBcsJfkzrm *= fPfEBcsJfkzrm;
        KJYZhdpFSQgU = KJYZhdpFSQgU;
        puLoJkwQzLtLY = ! WHANmq;
    }

    if (lZyCWOO >= -934997.1569627657) {
        for (int xnvyaNKKat = 262621734; xnvyaNKKat > 0; xnvyaNKKat--) {
            continue;
        }
    }

    return fXhbkCctDiBQZNuq;
}

void NWUVShZej::NtrwOvYIgUACyRWA(bool pVcfnwuRXxHIc, int DqvXpewX, double TKGaMoC, int wHycNIHTZDsae)
{
    double gpAGZhpfGxNPX = -200808.14359335072;
    double ZGPTDmPLHP = 876347.4351067422;

    for (int ZsQRBZtznurOOM = 504934773; ZsQRBZtznurOOM > 0; ZsQRBZtznurOOM--) {
        gpAGZhpfGxNPX *= TKGaMoC;
        TKGaMoC += gpAGZhpfGxNPX;
        ZGPTDmPLHP += TKGaMoC;
    }

    if (DqvXpewX < 2118486242) {
        for (int oKXFwUFOxXKBXk = 1555489060; oKXFwUFOxXKBXk > 0; oKXFwUFOxXKBXk--) {
            DqvXpewX += DqvXpewX;
            TKGaMoC += TKGaMoC;
            TKGaMoC = TKGaMoC;
            pVcfnwuRXxHIc = pVcfnwuRXxHIc;
        }
    }

    for (int bTjiZqlDRMW = 1906299421; bTjiZqlDRMW > 0; bTjiZqlDRMW--) {
        TKGaMoC = gpAGZhpfGxNPX;
        TKGaMoC += ZGPTDmPLHP;
        gpAGZhpfGxNPX /= ZGPTDmPLHP;
        wHycNIHTZDsae += wHycNIHTZDsae;
    }
}

bool NWUVShZej::ceCVug(bool qUvJMzQIQxA, double qTKjCJTQnfv)
{
    bool SQyYIdK = false;
    bool gLBbGmMTWKr = false;
    int aDySPtLfbSELoX = 654688873;

    for (int WyQADhTznEhWHJ = 1517509993; WyQADhTznEhWHJ > 0; WyQADhTznEhWHJ--) {
        gLBbGmMTWKr = ! qUvJMzQIQxA;
        aDySPtLfbSELoX += aDySPtLfbSELoX;
        SQyYIdK = gLBbGmMTWKr;
    }

    for (int GAYoKaF = 989355585; GAYoKaF > 0; GAYoKaF--) {
        continue;
    }

    for (int dpJHv = 659988487; dpJHv > 0; dpJHv--) {
        qUvJMzQIQxA = ! qUvJMzQIQxA;
        qTKjCJTQnfv -= qTKjCJTQnfv;
        gLBbGmMTWKr = ! gLBbGmMTWKr;
        gLBbGmMTWKr = ! qUvJMzQIQxA;
    }

    return gLBbGmMTWKr;
}

bool NWUVShZej::zfvAVlc(int dlifMWhXVgK, double HpqkcytV, bool EcyFo, bool gKwjBOYyRqFb, bool ClJsPqSopprtEs)
{
    bool qUpdLUBbidsAuhsR = false;
    int mGfYPUCXpMxD = -952676429;
    int exEEay = -2044450525;
    int VOvLxQAUv = 2071895379;
    int ywbdhpUlkOgak = 1316525760;
    int dLIhol = -1735684556;
    double QRLFSovRtBJzeNVs = 252033.3205668176;
    int egLEIYxsIB = 1706065457;

    if (mGfYPUCXpMxD >= -2044450525) {
        for (int dFAlTBAK = 412795455; dFAlTBAK > 0; dFAlTBAK--) {
            gKwjBOYyRqFb = ClJsPqSopprtEs;
            gKwjBOYyRqFb = ! gKwjBOYyRqFb;
            gKwjBOYyRqFb = gKwjBOYyRqFb;
            exEEay /= exEEay;
            ClJsPqSopprtEs = ! EcyFo;
            VOvLxQAUv = dLIhol;
        }
    }

    for (int zSgndZMCEOzHl = 727452867; zSgndZMCEOzHl > 0; zSgndZMCEOzHl--) {
        qUpdLUBbidsAuhsR = qUpdLUBbidsAuhsR;
        dlifMWhXVgK /= mGfYPUCXpMxD;
        egLEIYxsIB = dlifMWhXVgK;
        egLEIYxsIB -= mGfYPUCXpMxD;
    }

    if (EcyFo == false) {
        for (int efHgJnESeVCL = 86056807; efHgJnESeVCL > 0; efHgJnESeVCL--) {
            gKwjBOYyRqFb = EcyFo;
            HpqkcytV /= HpqkcytV;
            mGfYPUCXpMxD = VOvLxQAUv;
            ywbdhpUlkOgak -= egLEIYxsIB;
        }
    }

    for (int SlfMANEEvNzg = 495336522; SlfMANEEvNzg > 0; SlfMANEEvNzg--) {
        mGfYPUCXpMxD /= ywbdhpUlkOgak;
        dlifMWhXVgK += exEEay;
        VOvLxQAUv *= VOvLxQAUv;
    }

    if (dLIhol == 1302050447) {
        for (int kNXvQsADxmyCIR = 1939242422; kNXvQsADxmyCIR > 0; kNXvQsADxmyCIR--) {
            VOvLxQAUv *= exEEay;
            dlifMWhXVgK += dlifMWhXVgK;
        }
    }

    for (int WMgpX = 1601456090; WMgpX > 0; WMgpX--) {
        dLIhol /= ywbdhpUlkOgak;
        ClJsPqSopprtEs = ! gKwjBOYyRqFb;
        ClJsPqSopprtEs = ! EcyFo;
        mGfYPUCXpMxD /= dLIhol;
        dLIhol -= exEEay;
    }

    for (int EuDePtRewf = 714623738; EuDePtRewf > 0; EuDePtRewf--) {
        mGfYPUCXpMxD *= dlifMWhXVgK;
        qUpdLUBbidsAuhsR = ClJsPqSopprtEs;
        mGfYPUCXpMxD += dlifMWhXVgK;
        ClJsPqSopprtEs = ! EcyFo;
    }

    if (QRLFSovRtBJzeNVs < -657705.9689603712) {
        for (int ZzdNI = 1633999140; ZzdNI > 0; ZzdNI--) {
            dLIhol += mGfYPUCXpMxD;
            EcyFo = ! gKwjBOYyRqFb;
        }
    }

    return qUpdLUBbidsAuhsR;
}

int NWUVShZej::BoxcgNridxXehLH(double VsiUqsGcb)
{
    double eBDlsg = -292731.6028735978;
    string yNstgWFuhHB = string("IkdZNFNSVVjoRrBbitmQvKbFTGXQHKrwpWTsIdPsAZOjFSTu");
    int yKQKiIwCF = 1469604995;
    int CnfJgboeFg = -312941635;
    double DweJiKIEfnGoZrDI = -325994.28139979055;

    for (int NThucF = 1604121063; NThucF > 0; NThucF--) {
        VsiUqsGcb += VsiUqsGcb;
    }

    for (int ivcxLJ = 1163341682; ivcxLJ > 0; ivcxLJ--) {
        continue;
    }

    for (int TeQPHJ = 194523887; TeQPHJ > 0; TeQPHJ--) {
        yNstgWFuhHB += yNstgWFuhHB;
    }

    for (int arOQJehOnb = 1863229157; arOQJehOnb > 0; arOQJehOnb--) {
        yNstgWFuhHB += yNstgWFuhHB;
        DweJiKIEfnGoZrDI /= DweJiKIEfnGoZrDI;
    }

    return CnfJgboeFg;
}

double NWUVShZej::hzFPekUAsNMZyQZW(int dEBhFXaCi, bool naoGsnCOC, int svOycvrgRkqz)
{
    string bSVwpWFRDtXlAjT = string("srutnNLLhLbzJYKmsPBnBVLnaBycoEEfXercjMXmzvzyLLjJqEMlwQqtcxUHmbROVrPkJsibsxfLVOJzLDlLAkVOEixYobAHZggULQyQYCEQpKSMNHhmVgszrRdeXXoasnyAxiiPxMAPUuRVjEYH");
    bool BxIyE = true;
    bool JcTNFETcqsqa = true;
    int oVmRnxwzov = -437565250;
    bool iafnrPfGesanEFk = true;
    double XuCjUGqFqgeNs = -985784.3948958634;
    bool fmxFuXFMl = true;
    double BKfvYhylyCmxc = -280090.10064215295;

    return BKfvYhylyCmxc;
}

int NWUVShZej::HXKkMFMdCobwczy(bool cvYKJsW, bool AZWdwj, string fmbUCRvyB, double uiLIyiUzBordSBr)
{
    bool yYjOStAguZMYYBD = true;
    double OHaxdKEBExWZCk = 956410.725291519;
    bool iUOIs = false;
    bool weRHENcSmshQKaAh = true;
    bool dbBmXb = true;
    string fZWeV = string("GdiKCvzJNblqzdgERYep");
    double waUZqePVhyAeCi = 781080.0024623926;

    if (uiLIyiUzBordSBr <= 975087.7659446464) {
        for (int qNWOmDnqLLXW = 2090216058; qNWOmDnqLLXW > 0; qNWOmDnqLLXW--) {
            yYjOStAguZMYYBD = cvYKJsW;
            iUOIs = iUOIs;
            cvYKJsW = ! dbBmXb;
            waUZqePVhyAeCi += OHaxdKEBExWZCk;
            fmbUCRvyB = fZWeV;
        }
    }

    if (iUOIs == true) {
        for (int rsmuKBLOEdqW = 40117200; rsmuKBLOEdqW > 0; rsmuKBLOEdqW--) {
            iUOIs = ! weRHENcSmshQKaAh;
        }
    }

    return 2120335955;
}

void NWUVShZej::jwxCCmxiC(string IdHGrFcGT, double ISCVDNH, string ATgTJoH)
{
    bool rqRjgNMzhSzFyjym = true;
    bool pIocVBAGeDUCoqyz = false;
    int grNJSuF = -2054834289;
    double eRHGQvxU = 47119.950075825756;

    for (int LvatImqXH = 1274319337; LvatImqXH > 0; LvatImqXH--) {
        IdHGrFcGT += ATgTJoH;
    }

    if (ATgTJoH > string("cZvJaOXdxmoGUYxlgNzXFgKElHGfvrzVsejQgIJrvzAjGOeiMUWxLyxfjWFCXUxnSzcWAWrKBqUlfDrQkmTzJpQPTxfVPKQOxKLMPRrhxrynlXBuPlztqUXdrrPlLkCdTOCfcsAhGIlAdPSojuavziTSrAhGfoPNDkznjATnwVR")) {
        for (int VnzLkvrrXQSqBPi = 1686747637; VnzLkvrrXQSqBPi > 0; VnzLkvrrXQSqBPi--) {
            continue;
        }
    }
}

double NWUVShZej::sRqkWNKdqX(bool pxDgvzatOHJn)
{
    bool adyiRoXdRQFwuBF = true;
    string IFpvBCeSw = string("JeGXToNeOAVqaUsPEPYXBoeOUcOMVjogepQakseadOnhjMrVNyeVnRRuSomsYxNfwDHajimSrYeGksRNWblArphniQIKCvuMcVuebPpFKGLShmbKeFTVBxLSYsVQINrakcSljnMuORCjnuRQuvEIuqXJjiUOZ");
    double jBUDLQZVfOVxQYlF = 983210.1501087232;
    int hXykZXsVTEDTKwt = 1777240270;
    bool rpusVgkVGJzqRNK = false;
    int gViXDgGoDrn = -813341632;

    if (rpusVgkVGJzqRNK == true) {
        for (int fDHNSyd = 1221651926; fDHNSyd > 0; fDHNSyd--) {
            rpusVgkVGJzqRNK = pxDgvzatOHJn;
        }
    }

    for (int JgBkwD = 135642804; JgBkwD > 0; JgBkwD--) {
        IFpvBCeSw = IFpvBCeSw;
        hXykZXsVTEDTKwt /= gViXDgGoDrn;
    }

    for (int aNGeDDIYIjWN = 1676017101; aNGeDDIYIjWN > 0; aNGeDDIYIjWN--) {
        jBUDLQZVfOVxQYlF *= jBUDLQZVfOVxQYlF;
    }

    for (int sfhckACINP = 743140052; sfhckACINP > 0; sfhckACINP--) {
        continue;
    }

    if (gViXDgGoDrn <= -813341632) {
        for (int SejWhhhW = 862170271; SejWhhhW > 0; SejWhhhW--) {
            pxDgvzatOHJn = ! adyiRoXdRQFwuBF;
        }
    }

    return jBUDLQZVfOVxQYlF;
}

int NWUVShZej::pPpImzTwpdr(string AAcoeRIKE, bool DeYdVdqyc, double hGrdzQeJCBJXx)
{
    double cEFIVTS = -943590.6583084745;
    bool TypZOZmbDOePCSBZ = true;
    int GaHyDJ = -144182723;
    double SOnNWQ = -213215.38534058246;
    int cpfHsPktrxVy = -305713203;
    bool JCvdJ = true;

    for (int ysAICU = 1384498046; ysAICU > 0; ysAICU--) {
        GaHyDJ /= cpfHsPktrxVy;
        DeYdVdqyc = ! TypZOZmbDOePCSBZ;
        GaHyDJ = GaHyDJ;
    }

    for (int UyAmCtwU = 592028281; UyAmCtwU > 0; UyAmCtwU--) {
        GaHyDJ /= GaHyDJ;
        cpfHsPktrxVy += GaHyDJ;
    }

    for (int hhUGdB = 1263213299; hhUGdB > 0; hhUGdB--) {
        GaHyDJ = cpfHsPktrxVy;
        cEFIVTS /= SOnNWQ;
        GaHyDJ += cpfHsPktrxVy;
    }

    for (int quZqnjYOhkU = 229476971; quZqnjYOhkU > 0; quZqnjYOhkU--) {
        continue;
    }

    return cpfHsPktrxVy;
}

bool NWUVShZej::pjUBNMJvTOd()
{
    string mVcZZmlMeYCNRRU = string("INzSaFwtrvDHLFEzTTDQiwUiosvsvgJbBULTWOlnyLDrUOEFDXTrYIjljVjOseKUwPBbZrqbKaughqyWtXnEhwmTwAIyVopkafzEhKdRpLpdxYoxmLbrfreifVkOmICvUQZItYkFKuGdFXSCerlCvusMrgzYHZXXWpjipZEytdSOVEiwXOZCYAZowAYxjzRnWghWgqOCBeQenoaBGzsLaXUXKJNdHT");
    string iyiOdElctebJ = string("TQWaiHFMgfdYRWOoMnHslaNrONAkNrmFXElnwnuXNPWfg");
    int ACIExZMAuu = 485031390;
    int MosgaJLDieruYzLM = 613140769;
    double asyvOOyAEsS = 1046643.6280189946;
    double bCcVIQPNMXx = 797434.0983445259;
    double HphikQAUTxHi = 48007.89683912723;

    if (iyiOdElctebJ <= string("INzSaFwtrvDHLFEzTTDQiwUiosvsvgJbBULTWOlnyLDrUOEFDXTrYIjljVjOseKUwPBbZrqbKaughqyWtXnEhwmTwAIyVopkafzEhKdRpLpdxYoxmLbrfreifVkOmICvUQZItYkFKuGdFXSCerlCvusMrgzYHZXXWpjipZEytdSOVEiwXOZCYAZowAYxjzRnWghWgqOCBeQenoaBGzsLaXUXKJNdHT")) {
        for (int XzctXmvSGebrERa = 781354354; XzctXmvSGebrERa > 0; XzctXmvSGebrERa--) {
            asyvOOyAEsS *= bCcVIQPNMXx;
        }
    }

    return false;
}

string NWUVShZej::fsLgPdSyMPYQVRS(string UpoVZjhtyY, int tWblkFwLpZb, double uZSMKpa, double iPDmoXzSq)
{
    string OlkqbRobHeBk = string("cgwKiqtHUtPxSHAKIdIzeDGEobxktEmLOxutiBbHAtqXiJmonRaoqeFeIQaFtIsXJXgezgENBhgYceXJOGoiLmPNzXXgAYyPJRhgcUWtwTpRrTBinLFZPNpFw");
    double rzOjOXYnaCGqAMh = 235016.62831131023;
    bool bpKulzEii = false;
    bool TsjfeG = false;
    bool JOAAKsHEpfx = true;
    bool glkEKPMYx = false;
    bool CCwzNm = true;
    string BlBpmnFMllOIf = string("jCbAogczSGsWCTBMlcZoycPwQKhahfgNrDnwvipaIypFPDGwuOqNkZSPeQegDZpyMLySuRLofFZOXoJZthxTJtdhQliFyjijLUFUuhMkKgmqnuxCWvueCHmrJMfqCAgqedmOxOkOlvRUjgJiJWaVZ");
    double pYbrwWQPMFXTn = 92839.0943768495;

    for (int TLMQv = 2033978972; TLMQv > 0; TLMQv--) {
        bpKulzEii = ! glkEKPMYx;
        CCwzNm = ! bpKulzEii;
    }

    if (JOAAKsHEpfx != false) {
        for (int iZhXWHM = 766902603; iZhXWHM > 0; iZhXWHM--) {
            BlBpmnFMllOIf += UpoVZjhtyY;
        }
    }

    for (int gbfgGcfeMHLyMDsJ = 1850236724; gbfgGcfeMHLyMDsJ > 0; gbfgGcfeMHLyMDsJ--) {
        rzOjOXYnaCGqAMh -= pYbrwWQPMFXTn;
        bpKulzEii = TsjfeG;
    }

    return BlBpmnFMllOIf;
}

double NWUVShZej::tNHCGuFdhP(int TxyFma, string OtWwWINH, string qLqtzaQSV, bool WIzhBJguKP, string knpWBmRvA)
{
    int fzwAcddO = -682529971;
    bool lfevW = false;
    string xTYvAHWT = string("FymViDLgSfYQClWnzbWaYumoTkegfyjFdpqFlhRyKbTYwISlwPcGlVnJxVFacewEPaFjTbDDQ");
    string qlBLzkBuxkZzC = string("lbzmBYEIbhlUDOarXTRlAWTUNPyEjqVawCVGZSrtLrrUGiJlxKBFCEwXPFMKOVrnZsFCQMAfCdhlLaFkAdjLLBVdEEllYKxOPxXniBrLyCbxMqSJCTYIcjfPJCisXQhlzaETiRgnQOQmsLLqsJH");
    bool nZtkr = false;
    double RAAkkQbItAvTu = -529688.8719448843;
    string NgEFCOERlcTYGxG = string("pHNwhItPEPvjrtxuRafWmwYVvyHK");
    int ElLWYxgN = 1799081697;

    for (int uyAhxRetWZbArBY = 2001653334; uyAhxRetWZbArBY > 0; uyAhxRetWZbArBY--) {
        knpWBmRvA = qlBLzkBuxkZzC;
        qlBLzkBuxkZzC = qlBLzkBuxkZzC;
    }

    if (nZtkr == false) {
        for (int wxPpQss = 1344167027; wxPpQss > 0; wxPpQss--) {
            knpWBmRvA += knpWBmRvA;
            xTYvAHWT = xTYvAHWT;
            xTYvAHWT += OtWwWINH;
            WIzhBJguKP = ! WIzhBJguKP;
        }
    }

    return RAAkkQbItAvTu;
}

double NWUVShZej::vEMiNsNjdhpkJi(bool eOkkOQ, bool OLAoGWEkcvSEcSnd, bool jVnRD, bool fJMNf, string brAYnYG)
{
    int yVjqzrNKKtfEz = -1596119092;
    string gFCHeYMMHfkFv = string("becvOOvcfDxXKcdooYfmqznolYyxugJLyHfZaRiYyiKStDcaBrnnElRWnoMcWinBxHUlXiptCCjKEDxfMwwgbVyfzfHsOOqasOrZKjDoResnwypsTOdoUTSXArDZEzYMfRqfiKG");
    bool KhVnxCbyN = true;
    int mbMuifWJlyTQ = -269405506;
    int EWjvDqUtisaDw = 785155443;

    if (jVnRD != false) {
        for (int BtAaBIfETeDF = 1523002372; BtAaBIfETeDF > 0; BtAaBIfETeDF--) {
            KhVnxCbyN = eOkkOQ;
        }
    }

    for (int DpfhatCeoaBotgp = 1171230368; DpfhatCeoaBotgp > 0; DpfhatCeoaBotgp--) {
        jVnRD = KhVnxCbyN;
    }

    return -696472.8898150134;
}

NWUVShZej::NWUVShZej()
{
    this->KQoFABcTX();
    this->DIEylGJdcw(314710.8011358607, true);
    this->eWzIaXvG(998843934, -85342.86148980206);
    this->NtrwOvYIgUACyRWA(false, 1691900869, -561016.3358931807, 2118486242);
    this->ceCVug(false, -937775.1032830768);
    this->zfvAVlc(1302050447, -657705.9689603712, false, false, true);
    this->BoxcgNridxXehLH(-188814.83741882388);
    this->hzFPekUAsNMZyQZW(480034787, false, -1631588019);
    this->HXKkMFMdCobwczy(true, true, string("aISJUeifanSKVuvTGfhlkQwAHiPDIUcOuMdTHVAfVVxGNePcJzMgkncboIfVHFSDEddOztJfmtAuzDahNxLsUVAShbfiQxITLoTSyjBFmoMNrEyzFOpUoZAvKCTGKIifMwcYXeIwTOaVjFFTdblysaOrsdIhnweIUzwGmKudNPfJyddYXRzrttKckzZsXEForaCzgzqTWkHsUPcLShEukuSXCqjSUVcbktuLZmrwoWAwEtwBNlkhmHwLwJzg"), 975087.7659446464);
    this->jwxCCmxiC(string("ODaYvGoRKoHoYeTiJTgANuhXETFuvoZrDTyL"), -720640.6137430281, string("cZvJaOXdxmoGUYxlgNzXFgKElHGfvrzVsejQgIJrvzAjGOeiMUWxLyxfjWFCXUxnSzcWAWrKBqUlfDrQkmTzJpQPTxfVPKQOxKLMPRrhxrynlXBuPlztqUXdrrPlLkCdTOCfcsAhGIlAdPSojuavziTSrAhGfoPNDkznjATnwVR"));
    this->sRqkWNKdqX(false);
    this->pPpImzTwpdr(string("qvjOBjihDpLFSxRvhQgixDHFBfBGroTJywvTYpiEonWMsnsgcg"), false, 595286.3971427461);
    this->pjUBNMJvTOd();
    this->fsLgPdSyMPYQVRS(string("vWkLHyYeowugQFcqTWxvBwSVXoZOdIVUgAUwdwOhCGwLOREMTzxcqztXqJVWvluXQIYhQLgQKEjiobUtCctrXCOeHWCLiHzYbLB"), 94473911, 57659.35011605834, 880197.0423086513);
    this->tNHCGuFdhP(-1700071169, string("UaiIaebOcZtTqLcmYPuRBrDHuohYIMtJYIHtyqTqhJeXZHxFgMPfifoFrOGCvrIqumnPkvqrpCHWzSLjZhPjvMZoQCRDFCKYpDvUmnqYnQBhZKhXrwcafQZJSkgwIvCGhFkcPXmjuymjRmzNEAGvLZfJZYexQTQvGKJNjTumbgvkrYpfMeDOQeDrDfPxtSTUUHIBOZOMfnon"), string("NVjLPUkygvMuerEDVYQIRvXdawXENrOBycxVPNWycdmIktmdfrOJmGuIkbrfKEMhUIyEnCbHJAFHRSYzBKQuUMffckrphHqUkOzvsvaGFrmwUpxMAGgOZFlXERyKVEGaozyDzboQZqqAOSNfgaDziEsnyJplFyUnBlMXjLdsEcZjCJNgENEjXprkhAUmvVtkCekmoZPSRzstmPwtxVjDChQSduRWlXGUZeKcbtezGXKdKGRzTbaqOlxkt"), false, string("HTOFmfSPOgYdSyzhIcWPPSyEdDdDAfSVNMvdSgsiyVBppSQfqtpOrNyzGMXzGoQIdofbMGSqODyaNwHlAhEjjuQAaWfIRVSordHJBsHNSkDglCSSzOjGFRCQlTgXOzwurGnmtCqnkrncmXpklJTarenABkGOWviGbMYfFWHkVjlMx"));
    this->vEMiNsNjdhpkJi(false, false, false, false, string("UQGvnycLF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zsJEJQX
{
public:
    int ZlhxliffMLjl;
    string dGSQkYu;
    int khaqDJnpwiBaO;

    zsJEJQX();
    double iGPvSA(bool EtTXuQk, bool TKcUiDEayeN, double yPQIJfTa, string zppDneNt);
    double zGwrYdJq(double sTtRvsQLTckHOgwH, double bGpVBMUkbDsBgwVn, int wVHVhgtj, bool uPFmLGOfJ, double mLZUCMhmLqNEE);
    string edTYOANuAqMoTS(bool tcBaQsBNSeo, string AuacmfeGL, bool ErKZqrmOE, bool JOknRvJ, string AoaJKFeJQKJGtm);
    double ZwChkzGjCUDi(string ovQlkGGNBxERRgBp, bool bhZVKqAtoIeH, bool mFNPfEvXb, double frBaAZXBjCzXnC, bool UMjYGMvl);
    double QglUg(double mNewrSd, int mRFATccAfGxPU, bool WXgdKgPJuFVESqi);
    int FbjcmmUIx(double DqfkCAUp, double HpbTD, bool JAgKUxsx, int GRBJJLgRaswmpxz, bool rKNamGcCdlUght);
    void AHxsTVxDZLnYsVxL(bool MXZvGtbAIDWF, int RbdxHrUPJea, int AYxEfiTz);
    int eIMneEWZYDLESNT(int MokYIG, double rqEsMcUxi, string jNAyBZxHQlUc, bool NmTKGrzLiQPaIf);
protected:
    bool pNkUF;
    bool KnfUXfcwO;

    int wmvqv(int EVExeyrLqOkNe);
    double xuAncIfgXJ(double KpIXOQpCsxjlCv, int xnVsaARqEWRMOBIG, bool Szkux);
private:
    int aeEmkvmyFJXbUId;
    bool gBffOgQCU;
    bool JqIqBoKOOQY;
    double FKMhWlrGHiXdbDb;

    void CvZOVYrP(int uFWFdSfrKZk);
    bool PMALz(int ZoVPRm, double gBNHStfuNj, double SAfyKMFadGspD);
    int TqbivpLPWG(string ZhxQZj);
    string cobGSUxtj();
    bool zxjFFAUvOeaZsggx();
    string IwNDtQSkcYzH(bool JOEaqamEtKk);
    void SDMElOJOOyNU(bool clvPkSg, string qpxJJIatqpQlZsF, int EgBuTlLJ, double EfGYoERx);
};

double zsJEJQX::iGPvSA(bool EtTXuQk, bool TKcUiDEayeN, double yPQIJfTa, string zppDneNt)
{
    double YTykEjvdnFy = 528318.5410984816;
    int Ytkqxe = 1979738198;
    string pxZoaVU = string("ngEWPUFmivUFwobkwcfOqqVGmhGfAfnGgaXHpmeyCSLxaYrVpTuwveqCbsslRtFqMJgUTBEukZFiGmN");
    string xNlAOWmQHNxeVd = string("BWFOySuWzOrvAwjYBzdcyorAEwcgZigfvlMHImPPqvzIZODEGcXqfWIpEDqRobbDwXNLgfJRnUUITywsctimZCeiKaQFFITIsxazHMjMPbKiwzoLOTGFaITrrJZpTDottmGJQhZGwNtCGzlrBNUCuAoFR");
    string GiMkfP = string("tSyXXOpAfaExFyMlhuvGocHwhKOzWPJIEJGwssGszFcLHpqqGkCJwOxUISiEEMrriAhiQCwoUrXSjYnZjZVQXBQUDWnLRcPbMaxIYUixCFbBPYNVSyAOmZRBsXEQsAtBSKCttqPIRNIQoGuwvMuevwlmkYRfNoVJJBEszyQonPutQISoUlHNFhbjlhtaYiortqPxjMsUaJkjHvpVndDGdGvgxRnJwtUOiAyhlifogvrRbGrVdtmxQZpaDiIY");
    bool UmqRltxa = false;
    bool YxirihK = true;
    bool DdQtR = true;
    bool bSOjOinX = true;
    int HHOpShQwFu = -596464225;

    for (int UDAxLmQWtpP = 1140349092; UDAxLmQWtpP > 0; UDAxLmQWtpP--) {
        DdQtR = YxirihK;
    }

    for (int iWGwr = 28680075; iWGwr > 0; iWGwr--) {
        continue;
    }

    for (int qNrptULLUQm = 1455205633; qNrptULLUQm > 0; qNrptULLUQm--) {
        EtTXuQk = ! EtTXuQk;
        YTykEjvdnFy += YTykEjvdnFy;
        pxZoaVU = pxZoaVU;
        xNlAOWmQHNxeVd += zppDneNt;
        EtTXuQk = EtTXuQk;
    }

    for (int FRCFTnHvEC = 363015564; FRCFTnHvEC > 0; FRCFTnHvEC--) {
        continue;
    }

    for (int SprjxcuzyoMSq = 1314742137; SprjxcuzyoMSq > 0; SprjxcuzyoMSq--) {
        zppDneNt += xNlAOWmQHNxeVd;
        YTykEjvdnFy = YTykEjvdnFy;
        zppDneNt = zppDneNt;
    }

    return YTykEjvdnFy;
}

double zsJEJQX::zGwrYdJq(double sTtRvsQLTckHOgwH, double bGpVBMUkbDsBgwVn, int wVHVhgtj, bool uPFmLGOfJ, double mLZUCMhmLqNEE)
{
    double yDswzF = -74231.39352016324;
    string LSBEXLnY = string("ujRwWhpnAEzxs");
    string IJuDEgpUUQGSA = string("ZqBs");
    int oyvBb = -1385876493;
    bool raohrujIBjGMzays = false;
    string axQliS = string("vdNOTndvmJzRKPIwXpzWnVgAluqjeyfEZBfLcwULckAmcJQO");
    int dfZAQkoqhyDAIzv = -631728680;
    int JdCZTrIWo = -1269336102;

    if (wVHVhgtj != -631728680) {
        for (int qBhFzVNuSk = 2096709391; qBhFzVNuSk > 0; qBhFzVNuSk--) {
            wVHVhgtj += JdCZTrIWo;
            raohrujIBjGMzays = raohrujIBjGMzays;
            sTtRvsQLTckHOgwH -= bGpVBMUkbDsBgwVn;
        }
    }

    if (sTtRvsQLTckHOgwH != -74231.39352016324) {
        for (int zwMuaT = 1925342670; zwMuaT > 0; zwMuaT--) {
            IJuDEgpUUQGSA += axQliS;
        }
    }

    for (int aaxSOimyCKtfKOR = 2023637055; aaxSOimyCKtfKOR > 0; aaxSOimyCKtfKOR--) {
        continue;
    }

    return yDswzF;
}

string zsJEJQX::edTYOANuAqMoTS(bool tcBaQsBNSeo, string AuacmfeGL, bool ErKZqrmOE, bool JOknRvJ, string AoaJKFeJQKJGtm)
{
    double fILvIDxDxstRI = 584709.6753687568;
    int CYYPSkWZ = 1514862581;
    int EOtnptOvJrvktO = -1431262660;
    double MAbnpVSSiGiPW = -239297.44642611092;
    string kVbAhwUbjVR = string("WRfWiFqWmMvseOaQNpmrXhzzFpSGNVSVeYNtqqqvrKWQkHSTHtXMhyARkroPEzEdvaYiqCKRQVUtKnomkbqEkkjqDssFxyWUtAXDYQJpGZJhSOMeNkacUlSSDLNzLYPkSdvBGMSMCfAlvZtsrHDeAidBGtboFzfPDDqPnMnInonkSdwSmXddQOhZMJndWEzpVoMAKaHSQTGLidGRPYZMJcAEyrOZazrnafGS");
    double JTbbiiHmb = -929736.7124428862;
    double xGEfHktNLogb = -117101.1020084837;
    string KxuPDwXHSNe = string("NCYLLzfcruS");

    if (tcBaQsBNSeo == true) {
        for (int pbUGhs = 325112933; pbUGhs > 0; pbUGhs--) {
            fILvIDxDxstRI *= MAbnpVSSiGiPW;
            fILvIDxDxstRI -= JTbbiiHmb;
            AuacmfeGL = kVbAhwUbjVR;
        }
    }

    for (int YUmpFeokN = 1732030246; YUmpFeokN > 0; YUmpFeokN--) {
        AoaJKFeJQKJGtm += KxuPDwXHSNe;
        kVbAhwUbjVR = KxuPDwXHSNe;
    }

    for (int DMLdVjPHiHHLzD = 291671656; DMLdVjPHiHHLzD > 0; DMLdVjPHiHHLzD--) {
        KxuPDwXHSNe += kVbAhwUbjVR;
        EOtnptOvJrvktO = EOtnptOvJrvktO;
    }

    for (int dKTcVTmlqvn = 1044677588; dKTcVTmlqvn > 0; dKTcVTmlqvn--) {
        JTbbiiHmb *= MAbnpVSSiGiPW;
    }

    return KxuPDwXHSNe;
}

double zsJEJQX::ZwChkzGjCUDi(string ovQlkGGNBxERRgBp, bool bhZVKqAtoIeH, bool mFNPfEvXb, double frBaAZXBjCzXnC, bool UMjYGMvl)
{
    string vGlGtPJKA = string("intgWGNgmiYLogsyaRlfPVhNvLoixrCTkuRoFjGlhVssrDuPbGmxZvFhHKlMepBXiZChwsFRaowTtKlOaiNNvinzkcWmrRlhlBjlctyeWKzIkbfaYPNeguYoOucCwuSFCVvmBgYXRshsdlxMPXILjJlKcWoWazSVnELpPMPuKgHHILnvuOhBLyrqstpeoKVXWwvocQQDULzVgEVgKxkcTVkoxzemtTOCujShRROyuUFFlD");
    string SktwhXMtMBXs = string("XtzjJUYmQyRvUdslXlJPgOkGrpQcAWSkJnmWZFDVYvdlnHJcwOoZAyReTvNFRvfjxOrJCoBbKGWfeQjNaRNzjqDaEzoDlBHCDiJGm");
    int UHUgALtHw = -325340658;
    string HZyEWTxKalstg = string("CdWXAWqpjEpVmcrvysmqvgNYZLEEJHqxWKBhHVfBTQQaRQdPBhkbcwlHVZwtpRndVcavIOmIiwVrhvHzzODL");

    for (int fIPNMIKvPGEhO = 826290915; fIPNMIKvPGEhO > 0; fIPNMIKvPGEhO--) {
        ovQlkGGNBxERRgBp += vGlGtPJKA;
    }

    for (int PSUbQXjJ = 1187983748; PSUbQXjJ > 0; PSUbQXjJ--) {
        mFNPfEvXb = mFNPfEvXb;
        HZyEWTxKalstg = HZyEWTxKalstg;
        mFNPfEvXb = ! bhZVKqAtoIeH;
        ovQlkGGNBxERRgBp = vGlGtPJKA;
    }

    if (vGlGtPJKA <= string("intgWGNgmiYLogsyaRlfPVhNvLoixrCTkuRoFjGlhVssrDuPbGmxZvFhHKlMepBXiZChwsFRaowTtKlOaiNNvinzkcWmrRlhlBjlctyeWKzIkbfaYPNeguYoOucCwuSFCVvmBgYXRshsdlxMPXILjJlKcWoWazSVnELpPMPuKgHHILnvuOhBLyrqstpeoKVXWwvocQQDULzVgEVgKxkcTVkoxzemtTOCujShRROyuUFFlD")) {
        for (int rZarHHVQDBigOQr = 219772954; rZarHHVQDBigOQr > 0; rZarHHVQDBigOQr--) {
            SktwhXMtMBXs += ovQlkGGNBxERRgBp;
            mFNPfEvXb = UMjYGMvl;
            bhZVKqAtoIeH = bhZVKqAtoIeH;
        }
    }

    return frBaAZXBjCzXnC;
}

double zsJEJQX::QglUg(double mNewrSd, int mRFATccAfGxPU, bool WXgdKgPJuFVESqi)
{
    string SxOCoLHzTBQaL = string("ySZcwGmxhAVGncEkzOlooyvNyCPHPMhmTkgiUMLYKXYdybCvcKvl");
    double EHxta = -695526.3708579832;
    string bzoocWdPuCh = string("TnuoFrcftdBpZGvBapOuNkRbkIHAYrDiPtbOzbsPLHRtLfhAgYyezjAZUpfTWWzyzvlbLFpwgWKPDJQyGmAvvdl");
    double BubaSaLh = -356225.01286959613;
    string BWBcu = string("QxtqXORyDGqqLjhsrmHJuUdGLIamgGdgRcLqHEAzeWyqrvnjmyOKAcogfFwPPuXHfMnbgZBxLDkTeiCYakHOCgNAMtQgzvroOJBvmxweeJ");
    int ZiWmLWkXzujROP = 1149762638;
    bool kAIHrHESFFxmRL = true;
    string KflzEp = string("kHQbXbCnghkmIAQtZVvSFPmtjtuhtKLEpI");
    bool hiTQgxGYoQ = false;
    bool bGDRUiM = true;

    for (int CJHULYXxhSi = 91087575; CJHULYXxhSi > 0; CJHULYXxhSi--) {
        mRFATccAfGxPU *= ZiWmLWkXzujROP;
    }

    return BubaSaLh;
}

int zsJEJQX::FbjcmmUIx(double DqfkCAUp, double HpbTD, bool JAgKUxsx, int GRBJJLgRaswmpxz, bool rKNamGcCdlUght)
{
    string GUUIwsoo = string("nXYVjvzgdGGtWSnuJZDqNjBYqWbYTAReHuTPWoZvPEmpvrrPmrOPEVkdZsxnkpta");
    double PCOMQDliNHtW = 337825.38008060143;
    bool ilDTBjYIzuKl = false;
    string oaIBu = string("ZAbdHPHqjCWqhbWNbVGiPURrkeSozFcVtLrNRMOUlKRoDIFnWDVcytwOqRDVmbndbezQPNmDxNPwKZYeImnbxTx");
    int swVqdbZOtZOl = 1166164379;

    if (PCOMQDliNHtW >= 355008.8160330556) {
        for (int WPAPPXhv = 776952187; WPAPPXhv > 0; WPAPPXhv--) {
            oaIBu = oaIBu;
        }
    }

    return swVqdbZOtZOl;
}

void zsJEJQX::AHxsTVxDZLnYsVxL(bool MXZvGtbAIDWF, int RbdxHrUPJea, int AYxEfiTz)
{
    double wVHScml = -845939.4134571026;
}

int zsJEJQX::eIMneEWZYDLESNT(int MokYIG, double rqEsMcUxi, string jNAyBZxHQlUc, bool NmTKGrzLiQPaIf)
{
    int npLgbaAVwpVPN = 1693039247;
    string VpxlYqP = string("pXmMOgGtQwKfgKcAdXfYijvHIlyvLOJPtCAIHtlPJtrJHMGGiqqycDJVIMqgcFhUIxiYNSieyRNAfZqOZSXIUJXdMCYZaHwdWzLVsfLbUKfCNuszCTWEHJSjeFrtOaAmqErFDatEmIHzrDUxoyDrubrALSGnSPAzIcGgRZPHRAwznGJQ");

    return npLgbaAVwpVPN;
}

int zsJEJQX::wmvqv(int EVExeyrLqOkNe)
{
    int YzEcGjJQ = -1384573263;
    bool VpIVkanbpRv = false;
    int pCYTQMwdWmW = -2131991908;
    bool sCIksTGCroy = true;
    int RqXKJsSjuP = 1824696146;
    int pWHkSMU = -1255823100;
    int ETaLLtP = 983778846;
    bool JDPozhWmrT = true;

    if (pWHkSMU != -1255823100) {
        for (int sCYrCfzzjKWIBwH = 472902235; sCYrCfzzjKWIBwH > 0; sCYrCfzzjKWIBwH--) {
            pCYTQMwdWmW -= RqXKJsSjuP;
        }
    }

    if (EVExeyrLqOkNe > -2131991908) {
        for (int fXSzOaLWhuBQXNSN = 521860369; fXSzOaLWhuBQXNSN > 0; fXSzOaLWhuBQXNSN--) {
            EVExeyrLqOkNe += ETaLLtP;
            pWHkSMU /= YzEcGjJQ;
            pCYTQMwdWmW /= pWHkSMU;
        }
    }

    if (YzEcGjJQ != 1824696146) {
        for (int gWDoonGKbWX = 190377325; gWDoonGKbWX > 0; gWDoonGKbWX--) {
            YzEcGjJQ *= pWHkSMU;
            pWHkSMU += ETaLLtP;
        }
    }

    return ETaLLtP;
}

double zsJEJQX::xuAncIfgXJ(double KpIXOQpCsxjlCv, int xnVsaARqEWRMOBIG, bool Szkux)
{
    double SAfZRO = -485893.71138549433;
    bool OSyZUqNPfIEwVa = true;
    string xEyCzhqMxnJPY = string("ztFmvkvzspTjGEfLmeAVbyYIuREUAfqPBUcXwznxjyrpEvzg");
    double TBlCKoZyarZ = 470403.8743397668;
    bool YLLuIujm = false;
    double aAfNjzGJaWys = -835043.7870865255;
    string KCKwbUOqKzNl = string("nvTKxDFfIFLeeRFYIWeGXXMiWEheWoHZllErAaSlocxKxxiBSMgTJxCcNjEOsxhXGOpXwpKqwuyDRpVXnUABBynusbDddWvfAyXexmwjCJkrSxrflpcGAvKAwUsHgGTZhHMZsVpuSbNvYxGtQwSaXkLNfSyfCwDjIJaOJHrRPkENDFLJQKrV");
    double qvBCKoJ = 716443.0332664388;
    int rwvuxboapitIQ = 1895424390;
    string mKehL = string("CtNLdXOkiwUULoGskTGhUNtvPxhAZRODEzrsyQjNfCXJUJDecSKNFghTmvntzdvpJEgDaRVAXIUrfpagMGWFFHTBhRNihQzBjFTKxhetfYmyXxGxmWJDszhwwNKrXdAvk");

    for (int neyvAXbHnUmK = 1909664547; neyvAXbHnUmK > 0; neyvAXbHnUmK--) {
        TBlCKoZyarZ /= TBlCKoZyarZ;
        rwvuxboapitIQ *= xnVsaARqEWRMOBIG;
    }

    for (int wCaUxCEISasCe = 1169423777; wCaUxCEISasCe > 0; wCaUxCEISasCe--) {
        mKehL += KCKwbUOqKzNl;
        KpIXOQpCsxjlCv /= aAfNjzGJaWys;
        aAfNjzGJaWys /= SAfZRO;
        qvBCKoJ -= aAfNjzGJaWys;
        YLLuIujm = ! Szkux;
    }

    for (int RcLLlItQDrD = 1806278544; RcLLlItQDrD > 0; RcLLlItQDrD--) {
        qvBCKoJ = qvBCKoJ;
        Szkux = OSyZUqNPfIEwVa;
        SAfZRO *= KpIXOQpCsxjlCv;
    }

    for (int kXQolViuaxEQX = 2133852253; kXQolViuaxEQX > 0; kXQolViuaxEQX--) {
        qvBCKoJ -= aAfNjzGJaWys;
    }

    return qvBCKoJ;
}

void zsJEJQX::CvZOVYrP(int uFWFdSfrKZk)
{
    double seYxyG = -24307.1312504042;
    string vzebbiaCwsEAjXIx = string("Oz");
    string OYNKGwWT = string("YOUiTfCEbSAFnASVBkIBeCqlWLAJxVDCjKZLbbQVAKRaoqYNYzyTPLQWyJJqUENtiNuJJTuKGntUBLgLZheMhdtjkCurSOBjLkNxoJDqAbTJguznOhvdObzdIkTLSK");
    string wSLDA = string("XAqlqlbVvbXCTseYlknJqGlKRFiWuTxRlbccMhciTPmnyzYWIztqDQJazokWjrkCVGkeglIpknBggiPyFkIhCbudaIddzgjVZsawGSKZbmhpjGxoaLTwRiNGuiSgjJdgAFpwAWhZHNgzIserLTYaDOIyhlADCOhNAamBlFvbokCKuhSWURMXkxubyDhsHDoFLDEdSlJADkzNWjtdINMEHreAtsGqRD");
    double hSWbBa = 403862.30617640243;
    double decoxlDgBXZs = -341496.5088220898;
    double FNjYNhxDI = 275751.01586666843;
    bool jAIHISG = true;

    for (int XUoUYIPHOFntfNPl = 1577180146; XUoUYIPHOFntfNPl > 0; XUoUYIPHOFntfNPl--) {
        hSWbBa *= decoxlDgBXZs;
    }
}

bool zsJEJQX::PMALz(int ZoVPRm, double gBNHStfuNj, double SAfyKMFadGspD)
{
    int fjFjnSvliraaHdih = 333000866;

    for (int XpGLyHDxOHVXXvEI = 1977023691; XpGLyHDxOHVXXvEI > 0; XpGLyHDxOHVXXvEI--) {
        gBNHStfuNj = gBNHStfuNj;
    }

    if (ZoVPRm >= 333000866) {
        for (int HrloVFEvbtube = 1256006745; HrloVFEvbtube > 0; HrloVFEvbtube--) {
            fjFjnSvliraaHdih *= fjFjnSvliraaHdih;
            gBNHStfuNj /= gBNHStfuNj;
            fjFjnSvliraaHdih = fjFjnSvliraaHdih;
        }
    }

    if (gBNHStfuNj == 346165.18740423565) {
        for (int wvGAUEcPIsSdXcrt = 474557180; wvGAUEcPIsSdXcrt > 0; wvGAUEcPIsSdXcrt--) {
            ZoVPRm *= ZoVPRm;
            ZoVPRm += fjFjnSvliraaHdih;
        }
    }

    if (ZoVPRm != -664014894) {
        for (int zZmJBRFht = 123417910; zZmJBRFht > 0; zZmJBRFht--) {
            fjFjnSvliraaHdih /= ZoVPRm;
            ZoVPRm /= fjFjnSvliraaHdih;
            gBNHStfuNj += gBNHStfuNj;
            fjFjnSvliraaHdih = ZoVPRm;
        }
    }

    if (gBNHStfuNj != 346165.18740423565) {
        for (int kaBEBYiwG = 134537009; kaBEBYiwG > 0; kaBEBYiwG--) {
            SAfyKMFadGspD += SAfyKMFadGspD;
            ZoVPRm = ZoVPRm;
        }
    }

    return false;
}

int zsJEJQX::TqbivpLPWG(string ZhxQZj)
{
    int OPeVVinYZhATB = -1753803679;
    int fIsbHyLWSXmLu = 1912845709;
    string fnLYIcJLTiBdaD = string("vYlNBarZzamLCVqtsVcXEpsyfLtLhQxoTCUmZGPCDdwQjufFFAOjxlhzzZrwkhEEtHwcXIKHhlTggpWDBaRWMBcNBIxeVaQ");
    int efwWEbQ = 24562310;
    bool CaMsYxHPxMhBWX = true;
    double pnxzXQeTSoDX = 56651.11976902411;
    double QgyHoMAYbP = -480766.91065151413;
    string prXOUxPchp = string("CvODylJxcrZMRhpwUdNejkEsxomysaBIGDlCzSdhleSoVmVkExfOVvrljBoieyXqkxzazgyKbyUhqcUutGeRXCamUspHNHXzgrpdGVqenkEnGycaWlceYYRfAzvmGFqVerQwgSvzINNMAUuVZqUoZPYlJqEeXRMTJgfvSuKtFRrHwmJZcArswlWMVIhhiNvUeLdYeSRuXEnyYCEwXCbhZtLTGWF");
    bool spbfA = false;
    int wUuisyULWwhY = 896292997;

    for (int StaBXYl = 372343043; StaBXYl > 0; StaBXYl--) {
        ZhxQZj += fnLYIcJLTiBdaD;
    }

    return wUuisyULWwhY;
}

string zsJEJQX::cobGSUxtj()
{
    bool ECaFfdhVc = true;
    bool GApKBKzIxxLkv = false;

    if (ECaFfdhVc == true) {
        for (int RMGTy = 463658876; RMGTy > 0; RMGTy--) {
            ECaFfdhVc = ! ECaFfdhVc;
        }
    }

    if (ECaFfdhVc != true) {
        for (int tnReVnfo = 224588329; tnReVnfo > 0; tnReVnfo--) {
            GApKBKzIxxLkv = ECaFfdhVc;
            ECaFfdhVc = ! GApKBKzIxxLkv;
            ECaFfdhVc = ECaFfdhVc;
            ECaFfdhVc = GApKBKzIxxLkv;
            ECaFfdhVc = GApKBKzIxxLkv;
            ECaFfdhVc = GApKBKzIxxLkv;
            GApKBKzIxxLkv = GApKBKzIxxLkv;
        }
    }

    return string("RwOLYbtVilqwSlhdHzotejvvANaSVJHWPsgphPMYubPQnGmCQoliCquyjDTDqacIdnkIchTyegkuFRPYvqHEhOfhOKjrSzvznusNefMnaWMMotSmaoVqHYbknHVJMxFKEoOvhnCUKWywETXMVNvrUuLzmSGgpoRJwyylnYsLQFPhjHufawmJjSaxHhMHKbqKzNrnsqDYugCVLdnwsfVidKAiMcHrUjoTwQL");
}

bool zsJEJQX::zxjFFAUvOeaZsggx()
{
    int PlPaOx = -1827189022;
    double evxWJ = -508919.7724620659;
    bool xGQGcMmKVSK = true;
    int JZeOX = 684248201;
    bool HeuDZWVL = false;
    double hCHaODJUjNbxVXf = -737609.7960761097;

    return HeuDZWVL;
}

string zsJEJQX::IwNDtQSkcYzH(bool JOEaqamEtKk)
{
    int unIBfTaG = 1637670205;
    int ZzFQZHTmrsvP = 1616558251;

    for (int nhPRcBtSlcvtK = 1133686109; nhPRcBtSlcvtK > 0; nhPRcBtSlcvtK--) {
        ZzFQZHTmrsvP -= unIBfTaG;
        ZzFQZHTmrsvP -= unIBfTaG;
        JOEaqamEtKk = JOEaqamEtKk;
        unIBfTaG /= unIBfTaG;
    }

    if (unIBfTaG != 1616558251) {
        for (int jnLLiiGPYmof = 1082804794; jnLLiiGPYmof > 0; jnLLiiGPYmof--) {
            ZzFQZHTmrsvP /= unIBfTaG;
            unIBfTaG += ZzFQZHTmrsvP;
            JOEaqamEtKk = ! JOEaqamEtKk;
            ZzFQZHTmrsvP += unIBfTaG;
            unIBfTaG *= ZzFQZHTmrsvP;
            JOEaqamEtKk = ! JOEaqamEtKk;
        }
    }

    if (ZzFQZHTmrsvP <= 1637670205) {
        for (int IsrUqbuV = 1506955504; IsrUqbuV > 0; IsrUqbuV--) {
            ZzFQZHTmrsvP -= ZzFQZHTmrsvP;
            unIBfTaG -= unIBfTaG;
            ZzFQZHTmrsvP *= ZzFQZHTmrsvP;
        }
    }

    return string("UDtNfZSkPLdVSIqpvKjQYFjvHRKttVcLoZwtjPdBgJjPdMnDYzGJrCcFXUdOEPxwozUkudEWAHIKlUTvUOunQDemoQyBwJWRsgVCuvguvONTaklfcHVmODPseobWsfGnsTQSNAUqTcYHgMsIpYyeqUStWBbBuuRoupkNeNgLmexHI");
}

void zsJEJQX::SDMElOJOOyNU(bool clvPkSg, string qpxJJIatqpQlZsF, int EgBuTlLJ, double EfGYoERx)
{
    bool xlQhntGjy = false;
    string RrzMeAUe = string("QXdVovFyYGdOQCOJvzVMQznSTdb");
    int TFoLPJLGXqvolI = -1202483165;
    string FlQjBconVqZfrp = string("dIGrTLfynstVxQCMSEpUGqFcuZSZZfbFwpjobxhbqPCkNkkPAmcQrLNRPGprJBqMcXJtWFWbUnWWURwOvtJsU");
    string JybHRMtTGeyak = string("KLrKxKOYYEjWOSyodeqhFAAcrHRQvOGnXaaBDHIJlkpJgCTriUqNLXYhyduKabFEVBCEjxSUYvXqWNZayYZDQeUtQzRIBoEhguDUIQIokykAROwodJPEyeGqLMrbuapkYAINdVgVcrGROORnGviBdqaZNTcSWZuuiMRaFzjwbfkFQCeYlfMJLZA");
    double RIcwfUwjXM = 542105.5189142615;
    bool SjzATbMztd = false;
    int rhbevbDviwXuMzt = 591306399;

    for (int RFmxFaLrii = 1373389551; RFmxFaLrii > 0; RFmxFaLrii--) {
        qpxJJIatqpQlZsF = RrzMeAUe;
        qpxJJIatqpQlZsF = RrzMeAUe;
        clvPkSg = xlQhntGjy;
    }

    for (int GmyORYdO = 1924128394; GmyORYdO > 0; GmyORYdO--) {
        FlQjBconVqZfrp += qpxJJIatqpQlZsF;
    }

    for (int lEUOjSk = 951128739; lEUOjSk > 0; lEUOjSk--) {
        FlQjBconVqZfrp += FlQjBconVqZfrp;
        RrzMeAUe += RrzMeAUe;
        clvPkSg = ! clvPkSg;
        TFoLPJLGXqvolI /= rhbevbDviwXuMzt;
    }
}

zsJEJQX::zsJEJQX()
{
    this->iGPvSA(true, false, -599623.9988690707, string("bmTYLqsfsnPXTvCquTlGeJWlsEPCUYTlKhDQJxSceLWHRcxGCWMneUsvLWHfiaOrXqKXnaNnlsJrSRtuuGhacDVgIyIxPMOaDiwKLyaNsGUzZhhwRqZJfujuvBKexaMwVpEWxsUqMGdOHTSKyCecOiNsKCNYadBOpwHExQipzjWdVD"));
    this->zGwrYdJq(372915.3512951425, 344475.13565670466, 2030910174, false, 1037163.4949266921);
    this->edTYOANuAqMoTS(true, string("ErcrCAjQOBwHiGseVFpAakvIEAyiEBdjHfWpFmfHEqrzYVQplFzvqIbbkvVYXaIUyfw"), false, true, string("vMNjndzCgaPHPwpmlVahuqDVYEpyHtnOYwRRUiVufyPwEDCDkUMylFExzwvCfXIYcUovgitLaXBbTXlSvIGpBTSafqrPTwSUcctvAsTvldCHTGxqAneJvXDbnibNSXkcUhsiINcibTgNQZxwlGaGLNldRtxXWWrHLEmGyK"));
    this->ZwChkzGjCUDi(string("juhlYutPujCgUKLtQGZKzBdITyTOIkFLLNjjalzeqOICEtdqhmVNdnnnqsnfirpHvoMPedaZdNbsNfGwBhCUEQFiHnWjsvpkSOitVskdNuTfzZAPtoOdDHSoaAJNNqHjtyEPXcBuhStKFEjqpdOULieUkXqGUZPbFxSqcQlxOeYzhvGhacJFaTmHmVYxVJBFdQbavxFPJGnvuxAR"), false, true, 41901.148093912685, true);
    this->QglUg(-783436.5005885303, 449325370, true);
    this->FbjcmmUIx(-141788.318470766, 355008.8160330556, false, -1663774247, true);
    this->AHxsTVxDZLnYsVxL(false, 1068012803, -1871486102);
    this->eIMneEWZYDLESNT(527179752, 932683.9356897705, string("PoRgVglKBbKauSFpPKXJLWZ"), false);
    this->wmvqv(-1921177220);
    this->xuAncIfgXJ(155737.1913661332, -1557552267, true);
    this->CvZOVYrP(384107493);
    this->PMALz(-664014894, 507056.3158964545, 346165.18740423565);
    this->TqbivpLPWG(string("PDNMaFIcUvrgLXMastTcrLMLBxNCTvEABfBCSEPQCkIUirmJlGiijmlRxWlfeKNnljFUftMNAYQyhGzQJXZjzeQkMaHwHGiSIaKaFMcJEreEvkjlrTexcNxYhvTfcDwmhifqKfrFCshQjGPZWMQvSorFKeLAFagRGfQyrpLgMCuhVtUbqUtYzKHnikmsWqku"));
    this->cobGSUxtj();
    this->zxjFFAUvOeaZsggx();
    this->IwNDtQSkcYzH(false);
    this->SDMElOJOOyNU(false, string("hvKsePP"), 158867707, -314991.7075506774);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nPitdvOyZKpNiry
{
public:
    int niIICWMEvFCfeW;
    string azlMrYEpybM;

    nPitdvOyZKpNiry();
    int tfknEWcPcfaqhqu(double SYYMWrBjnVUSKti, int MOhpDEIGIcWiE, bool YyqMF, double VYBlDhU);
    int cCBrxvCd();
protected:
    int qmyorwcuJAmRr;
    int zbuEGFwXuJwg;
    bool lSSkYz;
    double lrqcHNapoiBZFFz;
    double AGSFjFm;

    string TxXETTBzdMWV(bool ZtKNTIPY, string GJXnpuqq);
    double BnBxfVAsP(int mZrGRtyAEK, bool eEORp);
    int uVAdgHYEsOY(bool jppXOIberat, double tpVaTM, string hkvcOBY, bool mYjbw, int rXLqXUYu);
private:
    double cGNHTEpXoBoUVX;
    string mjlKvGgQxnV;

    bool NGAodvCDVZQVFrmx(double JAGfPEFf, string uPAcbmL, double wMwrypfvJ);
};

int nPitdvOyZKpNiry::tfknEWcPcfaqhqu(double SYYMWrBjnVUSKti, int MOhpDEIGIcWiE, bool YyqMF, double VYBlDhU)
{
    double ApuIIGFeCYZFc = -805854.8779523909;
    int enqdKhkigLtQBeD = 121400621;

    for (int XrcJTcBPlEURzJW = 562221543; XrcJTcBPlEURzJW > 0; XrcJTcBPlEURzJW--) {
        ApuIIGFeCYZFc = SYYMWrBjnVUSKti;
    }

    for (int rwcAhGpX = 1960594608; rwcAhGpX > 0; rwcAhGpX--) {
        continue;
    }

    if (SYYMWrBjnVUSKti == -478756.98722235847) {
        for (int wunroMn = 328943382; wunroMn > 0; wunroMn--) {
            ApuIIGFeCYZFc += VYBlDhU;
            VYBlDhU /= ApuIIGFeCYZFc;
        }
    }

    for (int gVAUYlnulfrC = 1632538316; gVAUYlnulfrC > 0; gVAUYlnulfrC--) {
        continue;
    }

    for (int rDnzDvjGEwtTRk = 178986393; rDnzDvjGEwtTRk > 0; rDnzDvjGEwtTRk--) {
        YyqMF = ! YyqMF;
        ApuIIGFeCYZFc *= ApuIIGFeCYZFc;
        enqdKhkigLtQBeD += MOhpDEIGIcWiE;
    }

    if (VYBlDhU == 35223.05561803646) {
        for (int cXdZVg = 1442377475; cXdZVg > 0; cXdZVg--) {
            VYBlDhU -= VYBlDhU;
            YyqMF = ! YyqMF;
        }
    }

    return enqdKhkigLtQBeD;
}

int nPitdvOyZKpNiry::cCBrxvCd()
{
    string yGcoAJHbEvCNHbS = string("PdMvqIvgFPxRIKrqzRLNXUaQbNKveknzJtrReYekPIjjuyybDjFJmyByAoxFTnORAWGeguqnANSxgKFNCdrdRhFhJUlXauHdghzhIwhIsJYcwuJTEBYfwQrNrowUmNunQVzYzlxpqauSzLNynFPbHb");

    if (yGcoAJHbEvCNHbS < string("PdMvqIvgFPxRIKrqzRLNXUaQbNKveknzJtrReYekPIjjuyybDjFJmyByAoxFTnORAWGeguqnANSxgKFNCdrdRhFhJUlXauHdghzhIwhIsJYcwuJTEBYfwQrNrowUmNunQVzYzlxpqauSzLNynFPbHb")) {
        for (int EJoLdx = 2022535063; EJoLdx > 0; EJoLdx--) {
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
        }
    }

    if (yGcoAJHbEvCNHbS == string("PdMvqIvgFPxRIKrqzRLNXUaQbNKveknzJtrReYekPIjjuyybDjFJmyByAoxFTnORAWGeguqnANSxgKFNCdrdRhFhJUlXauHdghzhIwhIsJYcwuJTEBYfwQrNrowUmNunQVzYzlxpqauSzLNynFPbHb")) {
        for (int WPlkpYNPebppf = 1993558219; WPlkpYNPebppf > 0; WPlkpYNPebppf--) {
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
        }
    }

    if (yGcoAJHbEvCNHbS == string("PdMvqIvgFPxRIKrqzRLNXUaQbNKveknzJtrReYekPIjjuyybDjFJmyByAoxFTnORAWGeguqnANSxgKFNCdrdRhFhJUlXauHdghzhIwhIsJYcwuJTEBYfwQrNrowUmNunQVzYzlxpqauSzLNynFPbHb")) {
        for (int lJCqxwp = 1929457736; lJCqxwp > 0; lJCqxwp--) {
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
        }
    }

    if (yGcoAJHbEvCNHbS < string("PdMvqIvgFPxRIKrqzRLNXUaQbNKveknzJtrReYekPIjjuyybDjFJmyByAoxFTnORAWGeguqnANSxgKFNCdrdRhFhJUlXauHdghzhIwhIsJYcwuJTEBYfwQrNrowUmNunQVzYzlxpqauSzLNynFPbHb")) {
        for (int tQBwiAa = 848733466; tQBwiAa > 0; tQBwiAa--) {
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS += yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
            yGcoAJHbEvCNHbS = yGcoAJHbEvCNHbS;
        }
    }

    return 1982076496;
}

string nPitdvOyZKpNiry::TxXETTBzdMWV(bool ZtKNTIPY, string GJXnpuqq)
{
    bool HUmyCPQaEDYydX = true;
    double OGReiNqYcf = -302105.31033520657;
    int YPZubvQmwyZ = 1824750195;
    double CDpYyiuMO = 406060.7366816817;
    int CxyfnsJQXegFj = -1693773932;
    double aDUpT = 105735.48467824237;
    double gAiMNkuLWlTdb = 980764.6694524988;
    bool AfRQROWGeVQhZa = true;
    string VdBuKzTor = string("pSfFFNkBXqrBTnCUFJRMEuYUjoMADJYjFYEelrRKOVKSmEqSNCYNMdTqIsRtHcOEoljjJzrsVqOemhGNTLiuvzjqyqelmiujuwhPJNCKtRSqpVMwRwMbsnKiBhFYlhuogHZOEzG");
    string uvPypxfYOgH = string("txjxLBeCVPZIOGGBdRUJzHKSvWAWzQJZRMoeDPezaMoiuHgUHjUmMFAIRNURGaREejvFYONAViShnausCWnsexqQfbArddSwmVRFSiqSAhRjdaZKpZYAFCQvipAnYXhgBMSosoOfOFSUIUjyElrwqLsfmaqnkqOMLSmbcmMTmYv");

    if (VdBuKzTor < string("pSfFFNkBXqrBTnCUFJRMEuYUjoMADJYjFYEelrRKOVKSmEqSNCYNMdTqIsRtHcOEoljjJzrsVqOemhGNTLiuvzjqyqelmiujuwhPJNCKtRSqpVMwRwMbsnKiBhFYlhuogHZOEzG")) {
        for (int twlytoGecz = 474093871; twlytoGecz > 0; twlytoGecz--) {
            continue;
        }
    }

    for (int dPhvMn = 2087717908; dPhvMn > 0; dPhvMn--) {
        CxyfnsJQXegFj = CxyfnsJQXegFj;
    }

    return uvPypxfYOgH;
}

double nPitdvOyZKpNiry::BnBxfVAsP(int mZrGRtyAEK, bool eEORp)
{
    int RsZOuTQRwHdRBVR = -1701191159;
    string DpIZaEhztXBJv = string("UnPgCqfySCNKgACbOnmuHsbWSuClOWwslpvLGIMoWIrevbFxiCHKnqLNyGJMGiqZTrnNKlaHXAATWAwPxatowEgVZNoUBdObWJzJERVTlWpMXiAPQJaMSPnrbLHhqWrZPzqcThSrtnOdCcFksuJDtecDouMPfHYFBKzIStiILIVoxQpMeZgUQurQtXiNueCWAIcnTwKCaedMZtRQENYNJphDOwVMYq");

    for (int ipfQWiBqSnBlkUoE = 1456786767; ipfQWiBqSnBlkUoE > 0; ipfQWiBqSnBlkUoE--) {
        DpIZaEhztXBJv += DpIZaEhztXBJv;
        mZrGRtyAEK *= mZrGRtyAEK;
    }

    for (int ytlcQIvpWDFSkV = 1872543933; ytlcQIvpWDFSkV > 0; ytlcQIvpWDFSkV--) {
        continue;
    }

    for (int LOxQTXbwTUBewu = 488348934; LOxQTXbwTUBewu > 0; LOxQTXbwTUBewu--) {
        RsZOuTQRwHdRBVR -= RsZOuTQRwHdRBVR;
        eEORp = ! eEORp;
        mZrGRtyAEK = mZrGRtyAEK;
        RsZOuTQRwHdRBVR += mZrGRtyAEK;
    }

    for (int pcXQjFTDRVkC = 2139141667; pcXQjFTDRVkC > 0; pcXQjFTDRVkC--) {
        mZrGRtyAEK *= RsZOuTQRwHdRBVR;
        mZrGRtyAEK *= RsZOuTQRwHdRBVR;
        RsZOuTQRwHdRBVR = RsZOuTQRwHdRBVR;
    }

    return -241230.21351465152;
}

int nPitdvOyZKpNiry::uVAdgHYEsOY(bool jppXOIberat, double tpVaTM, string hkvcOBY, bool mYjbw, int rXLqXUYu)
{
    bool yWxVMRmJfoeyXYHj = true;
    string fNzZcOsrREFEDhqx = string("gKDgTWVsrGJDyusvasnxMvQAfzuIWdISVYsToRdivMaMNIQtqcTBzbtOplovRwmDAabYhqvvbcWKOqmMcfwwSaHFuKQzpwNhLdwCupOPiCqIzneDpSHofQakJAwdtcrfMvLxuUTTLa");
    double pusdcmduUOyC = 30407.237976349916;

    for (int wZOHtbiUUOXKSNK = 974178293; wZOHtbiUUOXKSNK > 0; wZOHtbiUUOXKSNK--) {
        tpVaTM = tpVaTM;
        rXLqXUYu *= rXLqXUYu;
    }

    if (rXLqXUYu > -30633889) {
        for (int ZkjoMDLPgZgtl = 2088287410; ZkjoMDLPgZgtl > 0; ZkjoMDLPgZgtl--) {
            tpVaTM = pusdcmduUOyC;
            fNzZcOsrREFEDhqx = hkvcOBY;
            mYjbw = ! jppXOIberat;
            jppXOIberat = ! jppXOIberat;
        }
    }

    for (int uEpbJmnFGVQMwHru = 933512921; uEpbJmnFGVQMwHru > 0; uEpbJmnFGVQMwHru--) {
        jppXOIberat = yWxVMRmJfoeyXYHj;
        fNzZcOsrREFEDhqx = fNzZcOsrREFEDhqx;
        yWxVMRmJfoeyXYHj = ! jppXOIberat;
    }

    if (jppXOIberat == true) {
        for (int ThZmUOXsr = 165642953; ThZmUOXsr > 0; ThZmUOXsr--) {
            hkvcOBY += fNzZcOsrREFEDhqx;
        }
    }

    return rXLqXUYu;
}

bool nPitdvOyZKpNiry::NGAodvCDVZQVFrmx(double JAGfPEFf, string uPAcbmL, double wMwrypfvJ)
{
    double anOUUVbK = 90769.17561208819;
    double BZQlZxvNAHdb = -205946.57244332458;
    double hDrzzneiFFaDtn = -99397.8462632996;
    double vxaTO = 580174.4634250868;
    double glDNRJclxqd = -441371.097133662;
    string dQBIm = string("SZRJcZdwdDigZuVPXRmyuWKNHsjBTRieTKbCojJprldMSpMNTegPfCHRbEhUPjOrmQgbeOLsmhVvqUsVXKgMMirCHWHUSyEFlmpMHNYtoghlbqefmtKRYWSYWkJWUPlwFMwHhqFRcvvnYLsCBcoNbdOIDifpvmVcEmllJpUmDGHdoORyMVejJ");
    bool gTPVoIlYJFqU = false;

    for (int boTAOfPZjsuroRwV = 1349644511; boTAOfPZjsuroRwV > 0; boTAOfPZjsuroRwV--) {
        hDrzzneiFFaDtn = vxaTO;
        vxaTO /= JAGfPEFf;
        BZQlZxvNAHdb = BZQlZxvNAHdb;
        wMwrypfvJ -= anOUUVbK;
        hDrzzneiFFaDtn += glDNRJclxqd;
    }

    return gTPVoIlYJFqU;
}

nPitdvOyZKpNiry::nPitdvOyZKpNiry()
{
    this->tfknEWcPcfaqhqu(35223.05561803646, 517528133, false, -478756.98722235847);
    this->cCBrxvCd();
    this->TxXETTBzdMWV(true, string("ucbKERKSyODffkcgiUWfvoPlJFfuKmQPQapKYVsKPj"));
    this->BnBxfVAsP(1958387111, false);
    this->uVAdgHYEsOY(false, -605765.3503292415, string("UekuBamaAoiUPEsGOJJlUqQnCnHMwPnOorWlkSfnWpEwxSFhTzJFGqDPsgaheSVYWgvkdoZEOydsarsiGszVjPAVYKfsOjwhpBJFhbtOVRUKOmqmWcwbAASRlUXuWjbdulkSdYFJeSnkTKSavIlceMBUaZasVgOMKepiDbXnZmhPovQahpZYNlHQbZzvukveqK"), true, -30633889);
    this->NGAodvCDVZQVFrmx(336865.0703504125, string("nOuKPqreXQaD"), 1022304.2586454578);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qysmbRNnDPf
{
public:
    int aUkBVRudmje;
    double kcCBw;
    bool YfilySF;
    string XOzrOhtV;

    qysmbRNnDPf();
    bool IyPxvyO(int mlVPYl);
    bool pupUdkZ();
    bool PqRwk();
    string uVQTAhohjt(string EuCmwBRLeSAB, int NvruFKGxMyKqG, int wArTY, int vnIofMKbAe, int ZdiBAAP);
    bool QnDgEs(bool wOGPVjjltdW, bool pGNuPPVFP, double UeRpYljGSF, int rRLmD);
protected:
    string jLRtd;
    bool LjAtmes;
    int RNfjNT;
    bool VOqRwTdXqbkvGh;
    double xtxXGLAjNCtc;
    int EOgCikfVCLU;

private:
    int KIDqEOj;
    string bKuJnKhxd;
    int CushEg;

    bool uzsnmiOYs();
    string TuhVzU(string PJuJyen, bool YVqpAcHZtRWFKkka, bool KMuRyIAybTtdBY, string KhLWgWwYJgE, int lCAxdMgLcJbFBDNm);
    bool OIyaOsQuGzRwCipd(string BJdpIXyg, int CIMPQorOYW, bool CzwxTfJqZroTBzV);
    double DxMuDkip();
    int ikKpJOMJ(int rEYLFCeQlKfcWTe, double KBUvHB, int VdYpwKSTzvdlf, bool jzzJxQjfgSe);
    bool cCzwuWhbOIRNZ(double ILYDdQm, double ZIvVOpYMiZllVfjg);
    int cCfmuunWNEHDjSq(double pFvaX, double eXsWUfqwFVK, int xRXaleSuIPhZ);
};

bool qysmbRNnDPf::IyPxvyO(int mlVPYl)
{
    double dSXGVqemcjC = -262269.27385367977;
    string iWJpHlKTdQ = string("ztRXOmsvJNpBbKXsgDbIcwOvwvTKHLsuUUpETWpOKNNlOalfvzDxmfPpqwOlIlpBEyofjbSlFeHpasJWvdMOlfVbJkizntnRmGPJHHagsCRqNjvVQsyQizSqlxcVUowzrajzCUVNitHtCMUPZPtjeRiggRjDtXHvqXeVcYzDYEooLMmCwhMCcsOGKwPyjaQVjXPGfwEtntHi");
    bool TIlfFXQsasKgMXvM = false;

    for (int fmCKz = 710817773; fmCKz > 0; fmCKz--) {
        TIlfFXQsasKgMXvM = ! TIlfFXQsasKgMXvM;
        mlVPYl *= mlVPYl;
    }

    for (int tyjhQH = 685700188; tyjhQH > 0; tyjhQH--) {
        iWJpHlKTdQ = iWJpHlKTdQ;
    }

    if (mlVPYl <= 1888009158) {
        for (int JqPiX = 288796355; JqPiX > 0; JqPiX--) {
            mlVPYl *= mlVPYl;
            iWJpHlKTdQ += iWJpHlKTdQ;
        }
    }

    for (int DWMtQoLGl = 1517449026; DWMtQoLGl > 0; DWMtQoLGl--) {
        continue;
    }

    return TIlfFXQsasKgMXvM;
}

bool qysmbRNnDPf::pupUdkZ()
{
    string VRMzkvVZiv = string("lMqsWYQYpPHuvFnLePffqgDfPlPFIbNFaJBHuGOMtTsueqFOpGfLARbUMWxfgGaECSkJwbHHIhEZjezvOtIa");
    int OhVBmRyhRhns = 1091306527;
    double WuIFnPgvZDmiBG = -978191.6504624109;
    string ngtWVEWUcKdgL = string("BtBcOSwIVpTGApTLfdhGymDfrIrLMDwsvMXyLGdMULsNgyKsxzveWlubcIUHoHJRaduSFgQRSWrKKgzLfhDDuG");
    bool KqPEbJGLdEicQpQO = false;
    int vSqvs = -702535136;

    for (int QrtyZlRyJHGBS = 1387058680; QrtyZlRyJHGBS > 0; QrtyZlRyJHGBS--) {
        continue;
    }

    for (int JQmTIobPSJfVLKV = 853949351; JQmTIobPSJfVLKV > 0; JQmTIobPSJfVLKV--) {
        KqPEbJGLdEicQpQO = ! KqPEbJGLdEicQpQO;
        KqPEbJGLdEicQpQO = KqPEbJGLdEicQpQO;
    }

    return KqPEbJGLdEicQpQO;
}

bool qysmbRNnDPf::PqRwk()
{
    string LBpURQsuTeoqoU = string("quoKkFlgTMtRdtSCXmwINacMBTRtNZEUpvNpWElhraXKMDTACQWgJEZUjqSnpfEuVpzJmqTR");
    bool UNXvVuCFEgWwlg = false;
    bool PsxTUcrdjsfV = false;

    if (LBpURQsuTeoqoU <= string("quoKkFlgTMtRdtSCXmwINacMBTRtNZEUpvNpWElhraXKMDTACQWgJEZUjqSnpfEuVpzJmqTR")) {
        for (int SItjgAZvpCUSmLp = 866494550; SItjgAZvpCUSmLp > 0; SItjgAZvpCUSmLp--) {
            LBpURQsuTeoqoU += LBpURQsuTeoqoU;
            UNXvVuCFEgWwlg = PsxTUcrdjsfV;
            PsxTUcrdjsfV = ! UNXvVuCFEgWwlg;
        }
    }

    return PsxTUcrdjsfV;
}

string qysmbRNnDPf::uVQTAhohjt(string EuCmwBRLeSAB, int NvruFKGxMyKqG, int wArTY, int vnIofMKbAe, int ZdiBAAP)
{
    bool vIlxudjTXPdC = true;
    string HsaOtzfsTJq = string("wJRqpdoZZvtCtCRFsUPsiecrJznIExsifAbFabCFjjkfSHuDEdexNdXTCgfSyycwHsuzoCAxfbtEPbARDCvIsMNUvVWoGUJzmCMYugHZbWwzYHVdpVpUaJRFMyKVnpQBlUCIIIHRpmsUMlkAmPEEpJBFmUTUrRRjCqlzXRTylPFuAoWnMaYmRwfuxPkpwzxL");
    bool nDSBF = true;
    double TqHuzckxTF = -858097.2799379558;
    double iojkgJUkZZXMtGvf = -616517.8694426335;
    string ZQejof = string("iAtVeIUdGebVthohwziZqsmQeMTkUoSBbWQmyTlPiaYcMkzYAOEITebbLMsEIMEuWKtiZcKuBjxMaBKtqQHiZcOxarecSCg");
    string VpqtJPAuzbCFq = string("MCAfbtvxecezWnyFvQWGoYlsdcqttakNBbAOlgAhiwwTNfqZYcSxSnHcokTXAhdLDPkvuGHUOmDECHaD");
    double ILqbXqoFd = 452097.6350424836;
    int vfjPxDRKtfjOgpWN = -1264585104;

    for (int vFIXTYOvEhAlC = 330320943; vFIXTYOvEhAlC > 0; vFIXTYOvEhAlC--) {
        iojkgJUkZZXMtGvf += TqHuzckxTF;
        vnIofMKbAe *= ZdiBAAP;
    }

    return VpqtJPAuzbCFq;
}

bool qysmbRNnDPf::QnDgEs(bool wOGPVjjltdW, bool pGNuPPVFP, double UeRpYljGSF, int rRLmD)
{
    bool WkHyBTV = true;
    bool bogyZohtD = false;
    int dvkTWboohv = -928373468;
    bool KyAYdviUXt = true;
    string SsGSETJpwMBbzHTA = string("QdSJLTWKbKSpudaqa");
    int EryPGfNApVQasYB = 1578761564;

    return KyAYdviUXt;
}

bool qysmbRNnDPf::uzsnmiOYs()
{
    bool hADOeGT = true;
    string zzpGYhcK = string("BAdsyBnPslOXqklmF");
    int imURIBZw = 810575645;
    int WyZayfmiWi = -412864632;
    string rYUHejcK = string("SAJcOeWcWaaNsspMQLaMnsytUXhjTtYOLTavCgExbquIapIMDCdfEbYjJMiWvKRBVRiRdtZZqwLZFqjYNBVVAAfuhjULDsiqtUqDyRnVRjBNjZgxgsSNASMzaECiMPhaRwtteNyiphcJfXfBCRsarBfGOHGIQLwNfATHhNFSXWxcFICdZNSqmKWIVDfEgGbBrdt");
    int UnwTBjBNJlD = 1109473702;

    for (int LkXPPcLuPEua = 100282550; LkXPPcLuPEua > 0; LkXPPcLuPEua--) {
        rYUHejcK += rYUHejcK;
    }

    for (int hAxGvwVbUTZsmA = 2041913751; hAxGvwVbUTZsmA > 0; hAxGvwVbUTZsmA--) {
        imURIBZw *= UnwTBjBNJlD;
    }

    if (WyZayfmiWi >= -412864632) {
        for (int MrftXWiHnWhJfuMI = 2048024123; MrftXWiHnWhJfuMI > 0; MrftXWiHnWhJfuMI--) {
            WyZayfmiWi -= WyZayfmiWi;
        }
    }

    return hADOeGT;
}

string qysmbRNnDPf::TuhVzU(string PJuJyen, bool YVqpAcHZtRWFKkka, bool KMuRyIAybTtdBY, string KhLWgWwYJgE, int lCAxdMgLcJbFBDNm)
{
    bool ZYqBXTDFZMXxR = true;
    bool TlNIlcmxKKo = true;
    string CzIzuCpzTu = string("iQyYLCIOZJcyQkREvRfRjVeyoYGkFhMrBfYXaEijldWYNwoEpmHNQejaELwYmpATBPDzFOtqMabTHaPLINpVjEaHsbUzZFXtdSJQILGOQlcGQTqLUItHJgDGWkTcioBPDGqsUQxBhcIdZVILhpDwzKiuUaTOGdFibtmqtnuGIsufQcxzXJOjPTLLibDSKUmenvJtPjsvOZPCZtHDaPQqDqYZoFEkSQgCdeJazYLPJdptJHBGmStpMHIAAAhPi");
    string FvOgERmMNEVxN = string("DOYnbbfFsqxiyPtTeY");
    int JzKcR = -84931277;

    for (int UvZSPJKA = 797855265; UvZSPJKA > 0; UvZSPJKA--) {
        PJuJyen += PJuJyen;
    }

    for (int eLqiMkAp = 954951142; eLqiMkAp > 0; eLqiMkAp--) {
        lCAxdMgLcJbFBDNm -= JzKcR;
        FvOgERmMNEVxN += PJuJyen;
        YVqpAcHZtRWFKkka = ! KMuRyIAybTtdBY;
    }

    for (int pZdgHAU = 1539181429; pZdgHAU > 0; pZdgHAU--) {
        KMuRyIAybTtdBY = ! TlNIlcmxKKo;
        FvOgERmMNEVxN = FvOgERmMNEVxN;
    }

    if (PJuJyen > string("iQyYLCIOZJcyQkREvRfRjVeyoYGkFhMrBfYXaEijldWYNwoEpmHNQejaELwYmpATBPDzFOtqMabTHaPLINpVjEaHsbUzZFXtdSJQILGOQlcGQTqLUItHJgDGWkTcioBPDGqsUQxBhcIdZVILhpDwzKiuUaTOGdFibtmqtnuGIsufQcxzXJOjPTLLibDSKUmenvJtPjsvOZPCZtHDaPQqDqYZoFEkSQgCdeJazYLPJdptJHBGmStpMHIAAAhPi")) {
        for (int mzeTpmDhgbTKKP = 1182807727; mzeTpmDhgbTKKP > 0; mzeTpmDhgbTKKP--) {
            KhLWgWwYJgE += KhLWgWwYJgE;
            CzIzuCpzTu += FvOgERmMNEVxN;
        }
    }

    for (int mxOjsOvOPjwx = 1830314894; mxOjsOvOPjwx > 0; mxOjsOvOPjwx--) {
        PJuJyen = KhLWgWwYJgE;
        lCAxdMgLcJbFBDNm *= lCAxdMgLcJbFBDNm;
        lCAxdMgLcJbFBDNm -= lCAxdMgLcJbFBDNm;
        TlNIlcmxKKo = ! TlNIlcmxKKo;
        JzKcR += JzKcR;
    }

    return FvOgERmMNEVxN;
}

bool qysmbRNnDPf::OIyaOsQuGzRwCipd(string BJdpIXyg, int CIMPQorOYW, bool CzwxTfJqZroTBzV)
{
    string xlmJVmU = string("cLCPmxByvUevXakeGNmfuJPZILMdjEPuqNJercvKcHoilAlMIwlHXFDvBKnxlVQzhbBabvWbuvZbQsnLEfBgTATdnghxHBrrBzcdVIEzqCbOQXmrMaGpRkBaJHlRUsJYYGbpzKOKflpwOTMwpYjmhViDqvkoUbUOZwYGqRASqfb");
    string MvhHSTXd = string("YdbAQqXXJlpMsThdKcMmPZBysjzctLuXiqsOnzCqbkevIECwYYXQHKOYZjHanNoHLQMgatQbvKrMVClemMeLHDaPiMPMqFhMbfxeBOLkRniFtIAuEXcaxTOKhkvvxpuZCNAmvczqNfABAKDGKHYoCYBzpzqYenEUERsxAFOpRptozahHfVGSHjVeBOkDABJcmwKbGVHcSuPsXgTjpkZeifVPBxhafTNfQHaWDcVIpxNFcas");
    int SWqhxdhVC = -1614424803;
    int lgZGbVlb = -1414993136;
    double OiDkCbepIjpPmWcX = 626464.8947881515;
    double HwWoqLI = -625642.1400356315;

    if (MvhHSTXd <= string("cLCPmxByvUevXakeGNmfuJPZILMdjEPuqNJercvKcHoilAlMIwlHXFDvBKnxlVQzhbBabvWbuvZbQsnLEfBgTATdnghxHBrrBzcdVIEzqCbOQXmrMaGpRkBaJHlRUsJYYGbpzKOKflpwOTMwpYjmhViDqvkoUbUOZwYGqRASqfb")) {
        for (int iuPzO = 1679892806; iuPzO > 0; iuPzO--) {
            HwWoqLI /= OiDkCbepIjpPmWcX;
        }
    }

    for (int fQzrerrPPxS = 380866945; fQzrerrPPxS > 0; fQzrerrPPxS--) {
        SWqhxdhVC /= CIMPQorOYW;
    }

    if (CIMPQorOYW < -853374803) {
        for (int iKJMXKYVvYHNOs = 595553178; iKJMXKYVvYHNOs > 0; iKJMXKYVvYHNOs--) {
            SWqhxdhVC -= CIMPQorOYW;
            MvhHSTXd = BJdpIXyg;
            CIMPQorOYW -= SWqhxdhVC;
        }
    }

    for (int vUEGbEEHerHaI = 1608948977; vUEGbEEHerHaI > 0; vUEGbEEHerHaI--) {
        BJdpIXyg = xlmJVmU;
    }

    return CzwxTfJqZroTBzV;
}

double qysmbRNnDPf::DxMuDkip()
{
    double fubOOZKIL = -276657.16186894634;
    int atSgGD = 2073987395;
    bool XRMaF = false;
    string dXqcUKSwR = string("LhXPosehOqRXspssUSrVQbWWNvqnjRbklhvBJoBxiSERVMKWJBrTrutHIjUfRRXzrGaqKBkAqtcwhnLyCNLNtQqaJGBGtHXxRzjWcmjmkhbOlZCvxDiwkLLDbyKLfQgTWtuSKHbpuBugjDfNzQdhFJbaiSpXuTIQERiplZJVBVHnOBXmCFzgiiWeuuGwZziFZIKTupzZSPpIUMIAg");
    string WxegfXIPy = string("YlbBqOoMySJJdlaGrebmImwHIoQuSOTTwVRAXMEupWqNxwhoNawistWHNmTfOErsYMCoeRAUELiEMGWEAMcWXCLovIzYRsiiuJbwmducphfPBwjSdkzm");
    bool xfLgzBWNtyG = false;
    int mIfdCMjazHynfA = -1834934949;
    double CUsfrDXQEdVCJI = 141359.68898236827;
    double FuwIqKT = -12684.369941170127;

    for (int pguTJVgA = 723984391; pguTJVgA > 0; pguTJVgA--) {
        dXqcUKSwR = dXqcUKSwR;
        mIfdCMjazHynfA -= atSgGD;
        CUsfrDXQEdVCJI *= CUsfrDXQEdVCJI;
    }

    for (int qyVyNMhioIT = 2037479089; qyVyNMhioIT > 0; qyVyNMhioIT--) {
        dXqcUKSwR = dXqcUKSwR;
        mIfdCMjazHynfA -= atSgGD;
    }

    for (int EKVCdDtVnYgJTQ = 1266094400; EKVCdDtVnYgJTQ > 0; EKVCdDtVnYgJTQ--) {
        continue;
    }

    for (int frRHLZaFNSXOK = 1063796531; frRHLZaFNSXOK > 0; frRHLZaFNSXOK--) {
        XRMaF = xfLgzBWNtyG;
        mIfdCMjazHynfA /= atSgGD;
        mIfdCMjazHynfA -= mIfdCMjazHynfA;
        XRMaF = ! XRMaF;
        dXqcUKSwR = dXqcUKSwR;
        dXqcUKSwR += dXqcUKSwR;
    }

    for (int LvGUSyv = 54789869; LvGUSyv > 0; LvGUSyv--) {
        FuwIqKT /= fubOOZKIL;
    }

    return FuwIqKT;
}

int qysmbRNnDPf::ikKpJOMJ(int rEYLFCeQlKfcWTe, double KBUvHB, int VdYpwKSTzvdlf, bool jzzJxQjfgSe)
{
    string WlNMOsrKXrzCyT = string("nHszzcncQWtwrQWPOiokzgCVEdtaadbhltewyzhaeXxpVkUwgfsGnrdbVkKmgzGvRGceGDBLGJCJTogiNtWhbMlqFCyBNETpOKQN");
    bool immwAWohvHEkn = false;

    if (WlNMOsrKXrzCyT == string("nHszzcncQWtwrQWPOiokzgCVEdtaadbhltewyzhaeXxpVkUwgfsGnrdbVkKmgzGvRGceGDBLGJCJTogiNtWhbMlqFCyBNETpOKQN")) {
        for (int UqJsnniyITaTglu = 804124698; UqJsnniyITaTglu > 0; UqJsnniyITaTglu--) {
            VdYpwKSTzvdlf = VdYpwKSTzvdlf;
        }
    }

    return VdYpwKSTzvdlf;
}

bool qysmbRNnDPf::cCzwuWhbOIRNZ(double ILYDdQm, double ZIvVOpYMiZllVfjg)
{
    string KOrwqI = string("bTDEJrreKJDCFiuGizWUoQuvVKURSoTtyUxpUOoTOPoQgZjuNvMRYYwnU");
    double WuQwXwcwvzjtwpC = -151667.683447747;
    int VwuihmGGM = -567733079;
    int qEDWZZGZVFJToB = 2039547090;
    double UvoiXxn = 552791.3892657516;
    double TPIqQPSgmbahVbU = 391043.602384445;
    double jpoWilaJXT = -649566.1865334921;

    for (int UXnVL = 2021287579; UXnVL > 0; UXnVL--) {
        WuQwXwcwvzjtwpC /= ILYDdQm;
        ILYDdQm *= ZIvVOpYMiZllVfjg;
        ZIvVOpYMiZllVfjg -= ZIvVOpYMiZllVfjg;
        TPIqQPSgmbahVbU /= ILYDdQm;
    }

    for (int QmjLdEXtp = 1143166150; QmjLdEXtp > 0; QmjLdEXtp--) {
        WuQwXwcwvzjtwpC *= jpoWilaJXT;
        qEDWZZGZVFJToB = qEDWZZGZVFJToB;
        ILYDdQm /= jpoWilaJXT;
    }

    if (WuQwXwcwvzjtwpC > -649566.1865334921) {
        for (int ejSUojmbBEuaUgB = 8501966; ejSUojmbBEuaUgB > 0; ejSUojmbBEuaUgB--) {
            TPIqQPSgmbahVbU /= TPIqQPSgmbahVbU;
            TPIqQPSgmbahVbU = WuQwXwcwvzjtwpC;
            WuQwXwcwvzjtwpC += UvoiXxn;
            qEDWZZGZVFJToB /= qEDWZZGZVFJToB;
        }
    }

    if (UvoiXxn < 192484.90082900735) {
        for (int NMpEAkRfoVSl = 1442735604; NMpEAkRfoVSl > 0; NMpEAkRfoVSl--) {
            jpoWilaJXT = TPIqQPSgmbahVbU;
            ILYDdQm /= ZIvVOpYMiZllVfjg;
        }
    }

    return false;
}

int qysmbRNnDPf::cCfmuunWNEHDjSq(double pFvaX, double eXsWUfqwFVK, int xRXaleSuIPhZ)
{
    string pPpdRHO = string("CyYfquPRgoLrZxQqUhPfnfiuEcwpyJxvnBjYReNgdolnAVIEYJRzUzAPuVSOIKVcXDiQxiDUiqxpuVaQzGnOouGXrYShipedKEqFLKemOqnGTKRfwfPdDrcYHwUjUHpIdzxpnpKKUXcuBcRxQDGUmwExOdUCehXWRyjiIArsWFCBglqihBeWTHbaaqQSwnsKLVNOVwkSlqalpmyMAGpTkUENEWkrGHJXWKVOtLdpKdWjhmchnZuomV");
    int ihoFwhX = 2102317488;

    for (int iHKeHRkd = 1796439053; iHKeHRkd > 0; iHKeHRkd--) {
        xRXaleSuIPhZ = ihoFwhX;
    }

    if (pPpdRHO >= string("CyYfquPRgoLrZxQqUhPfnfiuEcwpyJxvnBjYReNgdolnAVIEYJRzUzAPuVSOIKVcXDiQxiDUiqxpuVaQzGnOouGXrYShipedKEqFLKemOqnGTKRfwfPdDrcYHwUjUHpIdzxpnpKKUXcuBcRxQDGUmwExOdUCehXWRyjiIArsWFCBglqihBeWTHbaaqQSwnsKLVNOVwkSlqalpmyMAGpTkUENEWkrGHJXWKVOtLdpKdWjhmchnZuomV")) {
        for (int sykumybvIh = 724428887; sykumybvIh > 0; sykumybvIh--) {
            xRXaleSuIPhZ = ihoFwhX;
            pFvaX = eXsWUfqwFVK;
            pPpdRHO += pPpdRHO;
        }
    }

    if (xRXaleSuIPhZ <= 1533152918) {
        for (int alVzwETpcxQgF = 367890003; alVzwETpcxQgF > 0; alVzwETpcxQgF--) {
            eXsWUfqwFVK = eXsWUfqwFVK;
            eXsWUfqwFVK = eXsWUfqwFVK;
        }
    }

    return ihoFwhX;
}

qysmbRNnDPf::qysmbRNnDPf()
{
    this->IyPxvyO(1888009158);
    this->pupUdkZ();
    this->PqRwk();
    this->uVQTAhohjt(string("pshcHruUHpWsUsMkFqzPAuTtEmEMXabeayrcuBnqQVndIRQewSrhRpfqmGENiKtSAfCabZeHqYwDhpItOfYGtnrWpbMjCmTeOGPyXoLuqVxhahWYiCbSGQpwmQSuCTxapzDx"), 2142584079, 2012340285, 164902855, -2130568615);
    this->QnDgEs(false, false, -564908.3935468959, 855443182);
    this->uzsnmiOYs();
    this->TuhVzU(string("nEsluBsJsxzPDjxVSlVVrswNTmRSMtSGsnVqjYohnbJZbNYJVBCFHuBUjOXydayhYgxjgrcOZrmpywgSmIdOYtHsUNwZJKojdgGfgktyLbVJXVtDdOgBIUyG"), false, true, string("FxTCAGVSWaWginnLNauHaiFHccMMXuSzImYVIcGAQOORWlvyZqAoISZxeRlyeyNHAKiqaQGMKSWHnBlmLZQZRDKrBnVpsnXNnymGmHQfrRYruBViprzmZTFPGwfDVUKuJfGdhKCfPjyWNYQ"), 2102058093);
    this->OIyaOsQuGzRwCipd(string("jfIydHWXKAqOMAHISKIvAoPxNCPnnlyQCOIYeqFsrdIoHmyBzoGpGqmEfxSzJIHNomKEJGlvMyNQWvswIIkyZPQojsqr"), -853374803, false);
    this->DxMuDkip();
    this->ikKpJOMJ(922433414, 1000128.0965485488, 1880828222, true);
    this->cCzwuWhbOIRNZ(-1045743.6002953702, 192484.90082900735);
    this->cCfmuunWNEHDjSq(-442024.4606517158, -457162.90961547394, 1533152918);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HmzAKFaPPcw
{
public:
    string cCvzZBjY;
    string jKSFUtWTSSIzLmru;
    bool rQZGQ;
    string jxjYWiRRpC;

    HmzAKFaPPcw();
    double CSZfTzKksVlpQw(bool NoGaotKRDmiA, bool lTmsxkLIc, string oPKwafg, int lydZp, string hNrLnZQcImFiAt);
    int egjggrlQAoYP(double mGAVGFigPdyg, double xmhDlzAKyLQeK, double zHrzXeOaELQNvRZ, bool SKmMQlZaMS, int jZcAcyHbmKlF);
    int tUwSUtuDK(int XADlzfGJn, double scaDysgIH, string exxztqTNytoHw, int nfSHkkIDQlmmytw);
    int ZLFiAi(bool DJGyrdtylGikYR, string DXZSyETer);
    string eoboAJYDPrNteOrz(int uNDlhugEikAwRW, double oflJfmEZuaJ, double YCsObn);
protected:
    bool gTTwbPUHT;
    int xxddPWnFGoAQsR;
    bool ftVvikiTr;
    string BYUJw;
    bool MpBPMsN;

    bool TgwiIhJGABGcvF(double GYTeNSTAjpUlFfnh, string ntGyaRyuVmNVlBR, double FPRBSfROdihbg, string GxUsJyHua);
    bool fZhurgBKic(string RuSwtI);
    double JvcAEndJenosFUws(int QrAwxuFJ, int NZPbutKQraD);
    void PPDzFjzCUbgOGd(int NIdSvjWd, bool jygbCCjFaX, double kPCoONM, string VvkLiQjwGkZe);
    int YBBKjmtCHvgasNTu(bool aiBBizUplE, string vYFCzmyDuQO);
    string CyXzIskhs(int OCrOhCveNw, string CUTwdAle, int ikQNjFVMf);
private:
    string WUhtaVeNuyJ;
    bool EJwrYLWTZOXnfLK;
    bool GjVIqasogLinNi;
    double heXajwsQh;
    bool OfHfY;
    int ZrOTb;

    bool WJUGXiprNx(int UuGOg, bool UWpKgEDnsippnkzU, bool FCtMgXlHKR);
    void fkrxTmAjZUo(double hxOOsXPPyCDOwzW);
    bool guNVUjqIhWdd(bool yPPseSqeqkJC, int ADZqcNNjOYfkt, int GZGwAGTGAPj, int PizSsLjwJYe);
    bool NkneBJZP(double UOJaMTwMdtO, bool xKUyp, bool hWYbatMWGiS);
    bool kMFhWMWbPr(bool yDrcxcUENZSgfH, double kVkqwCkEGvimVYdU, double VRBeAnICRyhn);
    double YivQdzjT(double WgnrtWAatoXb);
};

double HmzAKFaPPcw::CSZfTzKksVlpQw(bool NoGaotKRDmiA, bool lTmsxkLIc, string oPKwafg, int lydZp, string hNrLnZQcImFiAt)
{
    bool PdOks = false;
    double LczbFxxPapoFi = -723250.5914341781;
    string iycMb = string("mDJCYboSPENKjyKcanireWLwsTrcXwLjMBdoCvdxpUEKoDbiNIDCVUkbGHaWEeHXbbHviNShSZiNfCbWZPWEyWPMCnIrZbsRBXgxwkrbXZAnieucrOYNmdCMNoSjVrvDPZyygwEUznfHvbqGLPbjbNfGMbGzllMkqynVunzitOuwVXxjZlWhyAsDIYkwmlrgJAkfCWhUaaDkuvnJprIzmmDEhYLAWvpfLQadnXENHftZCJtGEfJp");
    double KhxJsGCV = -76134.04157514349;

    for (int higJPgAVxvojXZfV = 347158252; higJPgAVxvojXZfV > 0; higJPgAVxvojXZfV--) {
        continue;
    }

    for (int XurGBioIkwOqRO = 1420729002; XurGBioIkwOqRO > 0; XurGBioIkwOqRO--) {
        PdOks = NoGaotKRDmiA;
    }

    for (int YQCBOfwXNdsZiPsb = 953064641; YQCBOfwXNdsZiPsb > 0; YQCBOfwXNdsZiPsb--) {
        hNrLnZQcImFiAt = oPKwafg;
        oPKwafg = iycMb;
    }

    return KhxJsGCV;
}

int HmzAKFaPPcw::egjggrlQAoYP(double mGAVGFigPdyg, double xmhDlzAKyLQeK, double zHrzXeOaELQNvRZ, bool SKmMQlZaMS, int jZcAcyHbmKlF)
{
    double OVqzrztJEKe = -790.8255070101005;
    double hasHDKIEJoUK = 713360.0916411545;
    string zGXouPatrjQV = string("WrmzDpyCfNgeiaUYMZIAquoM");
    int RAEuFqk = -1634266429;
    bool ymIhVzofTdHDV = false;
    double QUxAtyLLPw = -138497.12397831786;
    string ETOMbfXocbFEgwU = string("fKMzpStxONtICrTsWYgySadIBvczdUNSeNReyIxfSLBdsZRXkKoSNsntAKXoGbjxMENFcErESBstNKhIKQLBsQKGxvdGVVsdCOroacvNIPdhqYSOWQbcwBAsrypVOKRStklUeEatKiKSQfhaIytEEmNZXIpanzHSxyewdIsrScVWetcFFeARYussCCdNvFwMMYHwzHsZeGOkTeVIhaSG");
    double aBvtHvWurLY = 805133.3867978456;
    bool lHDAEjgWptj = false;
    string tdcVsXgdDiFjYap = string("eMuYwJRcYxRa");

    for (int FCKBPTeCHNvLrhvQ = 2003303282; FCKBPTeCHNvLrhvQ > 0; FCKBPTeCHNvLrhvQ--) {
        zGXouPatrjQV = ETOMbfXocbFEgwU;
        tdcVsXgdDiFjYap += zGXouPatrjQV;
        zHrzXeOaELQNvRZ *= mGAVGFigPdyg;
        QUxAtyLLPw += mGAVGFigPdyg;
    }

    return RAEuFqk;
}

int HmzAKFaPPcw::tUwSUtuDK(int XADlzfGJn, double scaDysgIH, string exxztqTNytoHw, int nfSHkkIDQlmmytw)
{
    double MPYPPrfSHgyWo = -1030210.5973458615;
    bool caTbXodj = true;

    if (scaDysgIH != -1030210.5973458615) {
        for (int rEvAkAJG = 141188139; rEvAkAJG > 0; rEvAkAJG--) {
            MPYPPrfSHgyWo += MPYPPrfSHgyWo;
        }
    }

    for (int tNwfxViFVGIOM = 2104272382; tNwfxViFVGIOM > 0; tNwfxViFVGIOM--) {
        continue;
    }

    for (int xScTmBFHYvHKvP = 680055795; xScTmBFHYvHKvP > 0; xScTmBFHYvHKvP--) {
        continue;
    }

    if (exxztqTNytoHw <= string("rXEYoXOjnbZdlDEkstpPtsfnijmwZFvNnOufBspYIudNeouiSHLFqVQXPstkuPzlbYQTDzvXZEfUhgzXAwbNgfrziojZllfmJmyYjiVoBKCPHgEeuGPtYEosAEMpDYCHMHAskaMYuZnBXemSqpcKEzKWtQulboZyLrskTmvoZNJfcfUAkCdvCOw")) {
        for (int fdETHFwh = 751217755; fdETHFwh > 0; fdETHFwh--) {
            scaDysgIH += MPYPPrfSHgyWo;
            MPYPPrfSHgyWo -= MPYPPrfSHgyWo;
        }
    }

    return nfSHkkIDQlmmytw;
}

int HmzAKFaPPcw::ZLFiAi(bool DJGyrdtylGikYR, string DXZSyETer)
{
    bool eCRczUxCFFGSImtJ = false;
    double cXGBblJjrICk = -512836.11210746574;
    int gxDRNjsqxs = -148466450;
    int MRmmKLb = 1744286802;

    for (int aehCBnF = 767079927; aehCBnF > 0; aehCBnF--) {
        cXGBblJjrICk += cXGBblJjrICk;
        DJGyrdtylGikYR = ! eCRczUxCFFGSImtJ;
    }

    for (int RoKsOYmmQWq = 741600733; RoKsOYmmQWq > 0; RoKsOYmmQWq--) {
        MRmmKLb = MRmmKLb;
    }

    if (DJGyrdtylGikYR == true) {
        for (int xCLQfvnatpzHgu = 1376673116; xCLQfvnatpzHgu > 0; xCLQfvnatpzHgu--) {
            eCRczUxCFFGSImtJ = ! DJGyrdtylGikYR;
            DXZSyETer = DXZSyETer;
        }
    }

    if (MRmmKLb == -148466450) {
        for (int RZqAAtDNCww = 673846033; RZqAAtDNCww > 0; RZqAAtDNCww--) {
            gxDRNjsqxs += gxDRNjsqxs;
        }
    }

    if (gxDRNjsqxs >= 1744286802) {
        for (int ZWgEalGKdxT = 860641506; ZWgEalGKdxT > 0; ZWgEalGKdxT--) {
            MRmmKLb -= gxDRNjsqxs;
            MRmmKLb -= gxDRNjsqxs;
        }
    }

    for (int lElnnVDzi = 1508824424; lElnnVDzi > 0; lElnnVDzi--) {
        continue;
    }

    return MRmmKLb;
}

string HmzAKFaPPcw::eoboAJYDPrNteOrz(int uNDlhugEikAwRW, double oflJfmEZuaJ, double YCsObn)
{
    bool AMOAdlDqoTvgk = true;
    double qBjsJsWawz = 837249.3221376506;
    bool KdHUjgj = false;
    double oUBmtw = 571874.9815072179;
    bool jXyYX = true;
    double zjzBLlXWSJkbORB = 411501.6716552322;
    string FLqluPJWxQJC = string("DOMQdJgsonhRfmdLVxFnXGXvFDgxcgjdCrHXmkQSTfjmqyStFnRytZqBmKAbEacapaddVWVxUJUzgMEaCnzXQPnaFgwQuzujVzCGwoGaiyrvIiRGauZQGhgHpvBQiIFCsJuFBqSFoqBolWJPUvQskmWYhDJOFMVMPALHlxdHspEkzJmtHkLsHOemoZrdoZCPltQDnAXVXWRfzQBfOunrRPYnVaYT");
    string JcyvnNGwofWX = string("UDzENoNTtvfkPUYgVFXrraYSjUpdMVoOpRnbVgSsZOXoDuyOooCrbXfUuFWFRGVNSnZLIPYpFVqmHUZRVeRyQzsyiURWgxZJRInJgNJFkZgsLUwcuRiFgPvIxAVrgxLChymhUUkefYCYUZrsCRVaGRPsWGnEoFfkcOvaTYiDhUCTBfigNwPWUciAedwi");
    string JRKKoQddRusyy = string("AqdFpwLJFakwjWwZKdxbBRQzcYVNmHNjYvYzmferIDElUBcYlwWGybFSzWRKEWApAQZffflSsvsHxjbwLieSXNvBsJAKNgQvRRgituLlGMrJyjgkQqXiXjmCkqjEYNLBjHfWhNvGiiLqdaJuzYkjOpigpRVIfRGYQnELZWSwoDz");
    int ggVjezAjT = 1385118874;

    if (uNDlhugEikAwRW != 1385118874) {
        for (int jttdbjm = 1394464283; jttdbjm > 0; jttdbjm--) {
            oUBmtw = zjzBLlXWSJkbORB;
            zjzBLlXWSJkbORB *= YCsObn;
            FLqluPJWxQJC += FLqluPJWxQJC;
        }
    }

    if (oflJfmEZuaJ == 837249.3221376506) {
        for (int oUBWvMo = 2002313577; oUBWvMo > 0; oUBWvMo--) {
            oflJfmEZuaJ /= qBjsJsWawz;
        }
    }

    for (int PDXeIZXoAXat = 1637153989; PDXeIZXoAXat > 0; PDXeIZXoAXat--) {
        continue;
    }

    if (FLqluPJWxQJC >= string("UDzENoNTtvfkPUYgVFXrraYSjUpdMVoOpRnbVgSsZOXoDuyOooCrbXfUuFWFRGVNSnZLIPYpFVqmHUZRVeRyQzsyiURWgxZJRInJgNJFkZgsLUwcuRiFgPvIxAVrgxLChymhUUkefYCYUZrsCRVaGRPsWGnEoFfkcOvaTYiDhUCTBfigNwPWUciAedwi")) {
        for (int ZRGjJmVROVMRx = 65406891; ZRGjJmVROVMRx > 0; ZRGjJmVROVMRx--) {
            continue;
        }
    }

    if (oUBmtw <= -440030.0477366791) {
        for (int shgkvqBO = 800730556; shgkvqBO > 0; shgkvqBO--) {
            qBjsJsWawz -= zjzBLlXWSJkbORB;
            FLqluPJWxQJC = FLqluPJWxQJC;
        }
    }

    if (JRKKoQddRusyy < string("AqdFpwLJFakwjWwZKdxbBRQzcYVNmHNjYvYzmferIDElUBcYlwWGybFSzWRKEWApAQZffflSsvsHxjbwLieSXNvBsJAKNgQvRRgituLlGMrJyjgkQqXiXjmCkqjEYNLBjHfWhNvGiiLqdaJuzYkjOpigpRVIfRGYQnELZWSwoDz")) {
        for (int jDxDbreNzwu = 612034066; jDxDbreNzwu > 0; jDxDbreNzwu--) {
            YCsObn -= oUBmtw;
            KdHUjgj = ! KdHUjgj;
            YCsObn += zjzBLlXWSJkbORB;
        }
    }

    if (oUBmtw == 837249.3221376506) {
        for (int zurDZWSFCZLKuBkv = 1774084927; zurDZWSFCZLKuBkv > 0; zurDZWSFCZLKuBkv--) {
            continue;
        }
    }

    if (JcyvnNGwofWX == string("UDzENoNTtvfkPUYgVFXrraYSjUpdMVoOpRnbVgSsZOXoDuyOooCrbXfUuFWFRGVNSnZLIPYpFVqmHUZRVeRyQzsyiURWgxZJRInJgNJFkZgsLUwcuRiFgPvIxAVrgxLChymhUUkefYCYUZrsCRVaGRPsWGnEoFfkcOvaTYiDhUCTBfigNwPWUciAedwi")) {
        for (int IHpDs = 842782951; IHpDs > 0; IHpDs--) {
            ggVjezAjT += ggVjezAjT;
            uNDlhugEikAwRW /= uNDlhugEikAwRW;
            KdHUjgj = ! KdHUjgj;
        }
    }

    return JRKKoQddRusyy;
}

bool HmzAKFaPPcw::TgwiIhJGABGcvF(double GYTeNSTAjpUlFfnh, string ntGyaRyuVmNVlBR, double FPRBSfROdihbg, string GxUsJyHua)
{
    int prrxAw = 2618250;
    double aozoaSwSQo = -935909.4592559552;
    string fJeOnG = string("FbRlMjwUHqfFMpTVmBzMLMEaXXbeUQUsoCnXcHqUsdJBMyZmYTuGdjdBabaTjKMzfHXgJVsiRsDibREKegfsvaOAUNbeNYdFgoiXnZAJIBwdyvBrZnCMFAVPemrANyLdDRt");

    for (int TxuNxF = 574543881; TxuNxF > 0; TxuNxF--) {
        GxUsJyHua += GxUsJyHua;
        FPRBSfROdihbg *= GYTeNSTAjpUlFfnh;
        fJeOnG += GxUsJyHua;
        FPRBSfROdihbg /= GYTeNSTAjpUlFfnh;
    }

    for (int yWForP = 1863151117; yWForP > 0; yWForP--) {
        ntGyaRyuVmNVlBR = ntGyaRyuVmNVlBR;
        ntGyaRyuVmNVlBR = ntGyaRyuVmNVlBR;
    }

    if (prrxAw >= 2618250) {
        for (int TazULuN = 863980098; TazULuN > 0; TazULuN--) {
            ntGyaRyuVmNVlBR = fJeOnG;
        }
    }

    for (int KkeoGeEZ = 802769975; KkeoGeEZ > 0; KkeoGeEZ--) {
        fJeOnG = ntGyaRyuVmNVlBR;
        FPRBSfROdihbg *= GYTeNSTAjpUlFfnh;
    }

    for (int YmDRzHDqNFWAuvm = 2020803488; YmDRzHDqNFWAuvm > 0; YmDRzHDqNFWAuvm--) {
        GYTeNSTAjpUlFfnh += aozoaSwSQo;
        FPRBSfROdihbg += aozoaSwSQo;
        fJeOnG += fJeOnG;
        ntGyaRyuVmNVlBR = GxUsJyHua;
        fJeOnG += GxUsJyHua;
        aozoaSwSQo /= GYTeNSTAjpUlFfnh;
    }

    return true;
}

bool HmzAKFaPPcw::fZhurgBKic(string RuSwtI)
{
    string kqfsfiWFxk = string("GEArLziNYlLgirVkhUuPqIkOKWsknxTaFyIalqwLsACanAKJtflelhfNxaqmHcBvcemivuPcoWiRCPlmyVpMzptsuAXSuElSfwDEXLQwbQFwoxEjfLUYxInpRqkaPoLnQgpigR");
    int dTRVxlchlK = 690310879;
    string ddiLHeNJTcyAy = string("rbtwyulIRuywlionCrSyHHmoUJQQzIdumxnINetYrY");
    int yvPhFgkk = -1625029355;
    bool ZdSwq = false;
    double BzROUobxxYZOat = 753417.4827997629;
    bool ouOdnLzRU = false;
    bool SLnKmciVtYQiGEFL = false;
    bool GfGEsg = false;

    if (kqfsfiWFxk >= string("uHwUFpGAmiKmZhEIsuYwTNJWorGZlpbauOIECPCCkUXMlODtQWykcmeCMztmSQPwkqEIkrvMKtgbeJPYswItLVahvRTSCjMSHSTvQDwcpAmuzgwDToBhsaNJbMHJGETrmvXFsDPxwcRZNyUFvdUCFRMqhIGdOQspxlQVwjQfXFMugGEZKmsVJzvjwfSXaLazYeTMqrULsWLOjelcTtWqJEWEAYcBmcwBjzYiCHGfBzTYMiunQNMn")) {
        for (int WpzMT = 4690931; WpzMT > 0; WpzMT--) {
            GfGEsg = ! ouOdnLzRU;
        }
    }

    for (int HXZaOk = 280929718; HXZaOk > 0; HXZaOk--) {
        ouOdnLzRU = ! ouOdnLzRU;
        SLnKmciVtYQiGEFL = ! ZdSwq;
        ZdSwq = SLnKmciVtYQiGEFL;
        kqfsfiWFxk = ddiLHeNJTcyAy;
    }

    for (int pcwGwXCG = 136878621; pcwGwXCG > 0; pcwGwXCG--) {
        ddiLHeNJTcyAy = ddiLHeNJTcyAy;
        RuSwtI += kqfsfiWFxk;
        ddiLHeNJTcyAy = RuSwtI;
    }

    for (int uCFsixpQzExzCxHf = 951455591; uCFsixpQzExzCxHf > 0; uCFsixpQzExzCxHf--) {
        ouOdnLzRU = ! SLnKmciVtYQiGEFL;
    }

    for (int hooHnMjpvaRgy = 1942059860; hooHnMjpvaRgy > 0; hooHnMjpvaRgy--) {
        GfGEsg = ! SLnKmciVtYQiGEFL;
    }

    return GfGEsg;
}

double HmzAKFaPPcw::JvcAEndJenosFUws(int QrAwxuFJ, int NZPbutKQraD)
{
    bool uBfYrFtOAFAv = false;
    bool gIJsJNxRgEHGqkss = true;
    string nlaMYwYhxw = string("ZSw");
    bool uAtizDlOsE = false;

    if (NZPbutKQraD > 1176865283) {
        for (int MSRxeU = 127140559; MSRxeU > 0; MSRxeU--) {
            gIJsJNxRgEHGqkss = uAtizDlOsE;
        }
    }

    if (uAtizDlOsE == true) {
        for (int UUneUhnsVSIbb = 1611712592; UUneUhnsVSIbb > 0; UUneUhnsVSIbb--) {
            gIJsJNxRgEHGqkss = ! gIJsJNxRgEHGqkss;
        }
    }

    for (int mpxGqtyZBa = 1950765912; mpxGqtyZBa > 0; mpxGqtyZBa--) {
        uAtizDlOsE = ! uBfYrFtOAFAv;
        uBfYrFtOAFAv = uBfYrFtOAFAv;
    }

    if (uBfYrFtOAFAv != true) {
        for (int tHaWWuszxJD = 1280173568; tHaWWuszxJD > 0; tHaWWuszxJD--) {
            continue;
        }
    }

    if (uBfYrFtOAFAv == false) {
        for (int thVgkDcfswr = 329939855; thVgkDcfswr > 0; thVgkDcfswr--) {
            uAtizDlOsE = ! uAtizDlOsE;
            uBfYrFtOAFAv = ! uBfYrFtOAFAv;
            QrAwxuFJ = NZPbutKQraD;
        }
    }

    for (int hLBPbaiyxBS = 148822271; hLBPbaiyxBS > 0; hLBPbaiyxBS--) {
        uBfYrFtOAFAv = gIJsJNxRgEHGqkss;
    }

    for (int vebMryFGO = 1074426065; vebMryFGO > 0; vebMryFGO--) {
        uBfYrFtOAFAv = uAtizDlOsE;
    }

    for (int lbsPLl = 111818346; lbsPLl > 0; lbsPLl--) {
        nlaMYwYhxw += nlaMYwYhxw;
    }

    for (int YzYmwTH = 740839426; YzYmwTH > 0; YzYmwTH--) {
        uBfYrFtOAFAv = ! uBfYrFtOAFAv;
        NZPbutKQraD /= QrAwxuFJ;
        NZPbutKQraD *= NZPbutKQraD;
        nlaMYwYhxw = nlaMYwYhxw;
        uAtizDlOsE = ! uAtizDlOsE;
    }

    return 173711.21837028567;
}

void HmzAKFaPPcw::PPDzFjzCUbgOGd(int NIdSvjWd, bool jygbCCjFaX, double kPCoONM, string VvkLiQjwGkZe)
{
    int pLlTmGTvnDRPj = 973823155;
    int IcWnwk = 371702165;
    string KxYoeOdKcPNtF = string("mQ");
    bool SxYnotzoP = false;
    double UaAxjVbJEDOwZgtM = -970977.6627311307;
    string TsAddrKnMy = string("EVWPsOfGIIDOGtifltbxCTAMLsZqhMoSsURUfeEYUfLNYQQhTfSNuxsgEzKLuBtE");
    string SKkNNFv = string("olIyjhuLtKoPUanPvlCkRHqcQRXVBbtxPrNMEulCjfaCDpXwLhjSemosWhnnUdynYaWgsEFSboANyBWbRJqLFSbPTQZUcGmBbyiMXdpBECbgmFeGsizXGUCYoxRMxxoq");
    int MEwjwCruCBmr = 2062831780;
    int qjTgQHWANYumjIin = 1239174272;
    string oCxBVeX = string("CJpiWIxPVagtCKZEMWGLeFMCaiUrtBfFhFIpughdXVUiDCczZXVMzClCwvoAmqmjOnmZdXofKzCUNqLZSWlRGfYiaCnKHpksveISXZxBWMUfkPaIqPcWqKDQKZOwokQSfQDGzw");

    for (int HDhJkkEGAzw = 231833775; HDhJkkEGAzw > 0; HDhJkkEGAzw--) {
        jygbCCjFaX = ! SxYnotzoP;
        VvkLiQjwGkZe = TsAddrKnMy;
        qjTgQHWANYumjIin = qjTgQHWANYumjIin;
    }

    if (TsAddrKnMy == string("mQ")) {
        for (int MJHJZyMuZVbDwov = 1234759832; MJHJZyMuZVbDwov > 0; MJHJZyMuZVbDwov--) {
            qjTgQHWANYumjIin -= IcWnwk;
            qjTgQHWANYumjIin -= qjTgQHWANYumjIin;
            KxYoeOdKcPNtF = SKkNNFv;
        }
    }
}

int HmzAKFaPPcw::YBBKjmtCHvgasNTu(bool aiBBizUplE, string vYFCzmyDuQO)
{
    string VLfPziPGKBccctt = string("dMSawxjgBdZWGwwIIjwKCaShGWxjbTHQhyKyakXivkAEyiQdETcSrvlvrODizOtdzgptReIKZPSIAdCzwBZWwzWRrHZpXrtwlLTebhHHguHdBhEvQDwwcDqwQBgHoETowguemaDTjsDVOZFBDdkLtLSvvtQiVzdgRQMNMINRzLsJEaHMpGGhcVIsknPuVcSoqatGmJTYpnvNspnmEwWrAFbfSqaohsPIBCUZsliRNhSSkqJQZQMmJEHkvAcG");
    double wbFwoXf = 786303.3277373579;
    string RZnpEZdCRuiEuyAc = string("IXsSsEmOmspQYkfIPBrplTdCkkEcKjRmWhdFPxLEcDdsOggvzavfrwmdiZstnzQaZapxtsDCUZRayGSaFYXIGHbXVvXGvYVNGfkSAKjiWsMfoLaaxsqtNpCNMUIKfglCvTqenAgePTsZArTFVhehmHIsdzBzlPqrKPKAFNRdhOdTYiKIFhCUHjsYaIDuRVGcmiOBUjlVRmnqqmyPuKTNnjEyUfzUEYWQbvOdmbPnSdYP");
    string qiQpaqpSratWfijP = string("XByyfbeaZTqJvAzEBZlSlBcGnzIzWddjlzwfCmAA");

    for (int SIcUSVG = 263642864; SIcUSVG > 0; SIcUSVG--) {
        continue;
    }

    for (int CAqtAkuH = 148858671; CAqtAkuH > 0; CAqtAkuH--) {
        RZnpEZdCRuiEuyAc = VLfPziPGKBccctt;
    }

    return 66623923;
}

string HmzAKFaPPcw::CyXzIskhs(int OCrOhCveNw, string CUTwdAle, int ikQNjFVMf)
{
    bool bzCKRhbg = true;
    int BiwSPNaJvCiuoxx = -1625267326;
    int MMqmwLHMbdaIjdIe = 389913918;
    int jHhpkLhgFNgfOD = -881525025;
    string GSerVivSzy = string("MHxhDDItcGDlENMuSCrdnyuRUWIZAnoLLfceMNZYzIWXGSwIWYifsFOfKdENUNXHlqHRRTfUGHsVEtpXAAWYrxvbDEjFtmuubagYsjcmKzqaTmNTIUxo");
    string eMdCSj = string("LkVdmADuXsDiVKQKGubgecLznRQtzmWaCTksGVDjnzBAlgmGOPKTAmWdvpRnYufBZvYFuAVFgaHNthGfJesbSOQySeZqLpHwHgPyHUcsjUxHDxcwWPkHrZzqsfVELsIofQZmZuDlAZhByqgbFeSvwrEOtvylNPcsQbQDBuWuGFJwvgkgzmvKurGqckmONwqeAZXehCanKPWfSzyClgOqnQgOZrGXAYNKJTEd");
    string AtHHukUpxyqA = string("rgRVzoXMRBNHXIOhccSRiKgTWCuFMqarfvPEYWtObVfFIMRkSoTmDFpxItmxxthzwsKNCrWHjKpjgXj");
    string bZSTwNMLIDzMAYz = string("VTFLFdWckeDcrCassKIhEEprspktVyOoFXhaGiDWYPjBEWfRSTptWiyyvwnUrxvFhzjymWkINehguMdHlAygyauKiZFLnOfYdsxOZQfkdUvOWJAvmLzZazPayKxed");
    int mruqbPTZfqwChbqM = -1672324207;
    bool PdgjAxOfNq = true;

    for (int XaRYIiCFaFexycz = 713035680; XaRYIiCFaFexycz > 0; XaRYIiCFaFexycz--) {
        jHhpkLhgFNgfOD = OCrOhCveNw;
    }

    if (CUTwdAle <= string("eWynARSGjvDKwPeFgiaKiRfWiAfKukQFZMRofDcISxRdPVmgnPjlAxHZzQUFooODnNNqAQRXACFBKToRKkkcpTASmJbjLkmoxNznVuRgYlCOUBXeVFZuBrKGvAqunTRxDmmqjCuIkYGrGoqRlQdjBcsjSOBSFpjVIacnADBsbOnCOpEAJUnkHRNusTNUJRQAaCfEqoJHYjUCGkbSTJYUswFidzMAuVfTICLKlxuanxOnOnh")) {
        for (int HGWTyuElsFnWugM = 1390628691; HGWTyuElsFnWugM > 0; HGWTyuElsFnWugM--) {
            eMdCSj = eMdCSj;
            CUTwdAle = AtHHukUpxyqA;
            eMdCSj = CUTwdAle;
        }
    }

    return bZSTwNMLIDzMAYz;
}

bool HmzAKFaPPcw::WJUGXiprNx(int UuGOg, bool UWpKgEDnsippnkzU, bool FCtMgXlHKR)
{
    string dfeMlAPmQgAFkR = string("DCxqvAczPjPnzxmjlafCaQdAOWxFkOleHotwVsgQXjuqOibVPvrMUhbnlQLqMjMyKMSykdxwTSxPMWwkZmlONltCqZIGgetxPxYYZhUKLRVDWdypUVGyZLHPGRFPYeEhWcBrnIhgcaZCUJfSscrzFaMWbBnApOCoBmUrRcJmiPVOhNSSvhsCAQckRpEXOusomkDIjxXwSfcZxrWCzLN");

    for (int XNqsGClUOpCvz = 644885451; XNqsGClUOpCvz > 0; XNqsGClUOpCvz--) {
        UWpKgEDnsippnkzU = ! FCtMgXlHKR;
        UWpKgEDnsippnkzU = ! FCtMgXlHKR;
        FCtMgXlHKR = ! UWpKgEDnsippnkzU;
    }

    for (int hEpBSmyF = 1701379464; hEpBSmyF > 0; hEpBSmyF--) {
        UWpKgEDnsippnkzU = ! FCtMgXlHKR;
        FCtMgXlHKR = UWpKgEDnsippnkzU;
        UuGOg *= UuGOg;
    }

    return FCtMgXlHKR;
}

void HmzAKFaPPcw::fkrxTmAjZUo(double hxOOsXPPyCDOwzW)
{
    bool cRHcpf = false;
    bool llzEBDHl = true;
    bool zJkrAUFQN = false;
    double APiBcXQd = 662592.4998168398;
    int tweCk = 42756550;
    bool naEACW = false;

    if (hxOOsXPPyCDOwzW <= 679213.1285361345) {
        for (int jgwOrecBnw = 744010512; jgwOrecBnw > 0; jgwOrecBnw--) {
            hxOOsXPPyCDOwzW /= APiBcXQd;
            tweCk *= tweCk;
            hxOOsXPPyCDOwzW = hxOOsXPPyCDOwzW;
        }
    }

    for (int dotOSebY = 1009962504; dotOSebY > 0; dotOSebY--) {
        llzEBDHl = naEACW;
        APiBcXQd += hxOOsXPPyCDOwzW;
        zJkrAUFQN = cRHcpf;
        APiBcXQd /= hxOOsXPPyCDOwzW;
        tweCk = tweCk;
    }

    for (int pTjaROTy = 252919447; pTjaROTy > 0; pTjaROTy--) {
        cRHcpf = ! llzEBDHl;
    }

    for (int FbpKwYxLVWOPZcxl = 981412360; FbpKwYxLVWOPZcxl > 0; FbpKwYxLVWOPZcxl--) {
        APiBcXQd /= APiBcXQd;
        naEACW = zJkrAUFQN;
        APiBcXQd += hxOOsXPPyCDOwzW;
        naEACW = ! llzEBDHl;
    }
}

bool HmzAKFaPPcw::guNVUjqIhWdd(bool yPPseSqeqkJC, int ADZqcNNjOYfkt, int GZGwAGTGAPj, int PizSsLjwJYe)
{
    int qyfpuE = 1137819005;
    bool aaRijvE = false;
    bool EeMcGGsiIp = true;
    bool LPVOfvtip = false;
    bool McQxsDUJ = true;
    int jTZILOkEcImYx = -1554053683;
    int DmsbPK = 992126550;
    string EBdVPFGThX = string("mwsyFBnIzTDulaDYyaWsPIUrYOwxtIITnvXXldXqLJbrPIiYTrlkfIOoDcEQXEftQDiEqMtLlEmcDIFXHHLAqjfaweLxYadqwJcrLcGFBxDRHFJqeMiYWIQZvPgpJTATxobZQdMoPjBwlluaU");
    bool KbuAmFekMwhnIL = false;
    double yzReNzIYbClVlglF = 521394.29745332676;

    for (int kzsqPPi = 654196539; kzsqPPi > 0; kzsqPPi--) {
        jTZILOkEcImYx /= qyfpuE;
        LPVOfvtip = LPVOfvtip;
        ADZqcNNjOYfkt = ADZqcNNjOYfkt;
        jTZILOkEcImYx += DmsbPK;
        aaRijvE = ! aaRijvE;
    }

    return KbuAmFekMwhnIL;
}

bool HmzAKFaPPcw::NkneBJZP(double UOJaMTwMdtO, bool xKUyp, bool hWYbatMWGiS)
{
    string fbmsOWFMtZ = string("VjQZAjPAepKQiMcFdcLFVdOmyOpPDujLoowvUNBiozkSrJDLpHqekCrUcNnNkoxtldcEMPlQxPAgnPmPkzEgnnjhVanFkeKMiCRaXFNTwbaJWsuMpmwvQuulXjz");
    double nemSkNmr = -595524.3285180421;
    bool vDnxaPqHNYaiA = true;
    string TYemaxROKgVPg = string("rCEZJaNSOcboBhQkGmwYxdRETnDOVYTSrYedGDuoiBYNScguRcyrASYxjhATgpUG");
    int QHGBigHKOIQymj = -1820914570;
    int IYRkVHa = -1184553581;
    bool mOlQMXtkNMnhA = true;

    for (int hiHGeNexJtCmB = 1406707476; hiHGeNexJtCmB > 0; hiHGeNexJtCmB--) {
        UOJaMTwMdtO += UOJaMTwMdtO;
    }

    for (int bDoymEJK = 747942947; bDoymEJK > 0; bDoymEJK--) {
        IYRkVHa += IYRkVHa;
        mOlQMXtkNMnhA = ! mOlQMXtkNMnhA;
        mOlQMXtkNMnhA = hWYbatMWGiS;
    }

    if (xKUyp == false) {
        for (int hossC = 1210518454; hossC > 0; hossC--) {
            continue;
        }
    }

    return mOlQMXtkNMnhA;
}

bool HmzAKFaPPcw::kMFhWMWbPr(bool yDrcxcUENZSgfH, double kVkqwCkEGvimVYdU, double VRBeAnICRyhn)
{
    double FNxfHSfxmoMVq = 488307.49838596955;

    if (VRBeAnICRyhn > -985438.9424364929) {
        for (int KfrwAORhzXgFYO = 1900426593; KfrwAORhzXgFYO > 0; KfrwAORhzXgFYO--) {
            FNxfHSfxmoMVq /= kVkqwCkEGvimVYdU;
            FNxfHSfxmoMVq -= kVkqwCkEGvimVYdU;
            yDrcxcUENZSgfH = ! yDrcxcUENZSgfH;
            FNxfHSfxmoMVq -= kVkqwCkEGvimVYdU;
        }
    }

    if (FNxfHSfxmoMVq != -985438.9424364929) {
        for (int nNXcAA = 1484290538; nNXcAA > 0; nNXcAA--) {
            VRBeAnICRyhn -= FNxfHSfxmoMVq;
            VRBeAnICRyhn += VRBeAnICRyhn;
            kVkqwCkEGvimVYdU /= VRBeAnICRyhn;
        }
    }

    for (int rzgTFiaJfQDJ = 1877930205; rzgTFiaJfQDJ > 0; rzgTFiaJfQDJ--) {
        FNxfHSfxmoMVq = FNxfHSfxmoMVq;
        FNxfHSfxmoMVq -= VRBeAnICRyhn;
        VRBeAnICRyhn = VRBeAnICRyhn;
    }

    for (int oJYCMPwIV = 797009305; oJYCMPwIV > 0; oJYCMPwIV--) {
        VRBeAnICRyhn /= VRBeAnICRyhn;
    }

    return yDrcxcUENZSgfH;
}

double HmzAKFaPPcw::YivQdzjT(double WgnrtWAatoXb)
{
    int TLgVfsQTFYl = -421053225;
    double uPmRvgt = 529780.5915343668;
    bool fHwxjF = true;
    double oYGVoHodWWbBeyw = 501551.0050724604;
    bool edkaaqLn = false;
    double pZYDUzkYSmQZZWL = 502902.44058276573;
    bool EavYpxdAM = true;

    if (TLgVfsQTFYl > -421053225) {
        for (int YHFWWq = 227727704; YHFWWq > 0; YHFWWq--) {
            uPmRvgt /= pZYDUzkYSmQZZWL;
        }
    }

    for (int HfCTaDoiVnTljL = 1745286663; HfCTaDoiVnTljL > 0; HfCTaDoiVnTljL--) {
        edkaaqLn = edkaaqLn;
    }

    return pZYDUzkYSmQZZWL;
}

HmzAKFaPPcw::HmzAKFaPPcw()
{
    this->CSZfTzKksVlpQw(false, false, string("jtHSwgKdEBYhajsqLnYijqFIMwJDyenvvcjIdTlvKfZPVNPsNzCKpkFuFCGxemSTOiIdDJtDSuEALbqyQZByjFiguzPCmWGBaOjCeHANMAZMprmqjYyrQIVUdpUVXiQSRvFMdlZFNZwhGlRpGSUSvxQfFXeFEKvgjnvvkthzeNgaEbeNwTBXkGrlZpjOCcluiGmoMWoTVNGuTIFstEdeVSOzwvXjVRtpxTHtFpstHpBEZeOJIzBzgDqdgHy"), -791892538, string("lbiLZfGGcrmvfhOvmcjluJFdWqqPFkkPYkzkVUchgXoefvZOoeSRhNxFZHZqAsgilHcseIRZZvwFeqOhQMCJdtEnoESOrsvpTNDRRSiqjjoklGAQKM"));
    this->egjggrlQAoYP(708751.4063220117, -700747.375872308, 526258.7269949294, true, 630524791);
    this->tUwSUtuDK(439965698, 1013357.1722402618, string("rXEYoXOjnbZdlDEkstpPtsfnijmwZFvNnOufBspYIudNeouiSHLFqVQXPstkuPzlbYQTDzvXZEfUhgzXAwbNgfrziojZllfmJmyYjiVoBKCPHgEeuGPtYEosAEMpDYCHMHAskaMYuZnBXemSqpcKEzKWtQulboZyLrskTmvoZNJfcfUAkCdvCOw"), 346261816);
    this->ZLFiAi(true, string("aowwvpPWLQlshaxvlpVejBBGksNECcbmKPArMcmCUPqUzBHSJzXWYbmfrKzEiEYIApFsNJixaFjtGRbVwPijLQPdtgiMlqTeNpUEFwsNiVznzTzAqJXjOXqStIdEhipAlSLXAfKSDGLlIehkHDdWgoXtTqjdhnBmHfzboQhRfwjGYEFXSepAXDhNvQvxlqroIYEZfRiyxY"));
    this->eoboAJYDPrNteOrz(155305332, -257395.75243246733, -440030.0477366791);
    this->TgwiIhJGABGcvF(114412.96703859919, string("JJAvuAVqlQBvFQlIiNYbmdznSilJQbXUDvtZpqquZBmmZCCSmAieHMTjLmOXJPZXNlXjxAMHaacJMnEgRFMClxBsocdSuJfWmieqnpuWSbLMZFMwivYeMNVOTBfrizzAMtRmtadqbAsfevNEprCUdKsnCqrxRhSQsvqUpVymBMgLXYfjzacwBCaVPhjgDOwreICgihUrebqiRZrmwwiYQKDwHbcmyriuyYWqJwnIZycDfw"), 557830.3276822, string("kRpeoepTyqGDMzBEnJCgglnSNEYEVHrzwcyNKCzcnhgfAZobbnZVCipPZsRYvomcCJdKfxnwlpMwQFmDbVPCFhhddReaQzEKvsgvqhR"));
    this->fZhurgBKic(string("uHwUFpGAmiKmZhEIsuYwTNJWorGZlpbauOIECPCCkUXMlODtQWykcmeCMztmSQPwkqEIkrvMKtgbeJPYswItLVahvRTSCjMSHSTvQDwcpAmuzgwDToBhsaNJbMHJGETrmvXFsDPxwcRZNyUFvdUCFRMqhIGdOQspxlQVwjQfXFMugGEZKmsVJzvjwfSXaLazYeTMqrULsWLOjelcTtWqJEWEAYcBmcwBjzYiCHGfBzTYMiunQNMn"));
    this->JvcAEndJenosFUws(233092114, 1176865283);
    this->PPDzFjzCUbgOGd(-54680463, true, 253069.738257053, string("PavdpvNnclywSvSaGIlMDTDvdepzNnMSPIlpUhPyPHoYnYorbrGrWQySNeGtYxaQWHpdzpTwLQrbFgxaUrHJiVJoInlSHijPIZDAmMeQplrQcSFDuUKeIrbbvjlKsyJBXJjuFFksjtHyZWwjQCyakejBLmvTfltfIPyhHGBjOJZBkrUfcDrsSnuvfZBUvR"));
    this->YBBKjmtCHvgasNTu(true, string("XpRbqEVEIqOOLYLVIOtGtTYxDTBHTUQGEhpUZPpiCeyMnjZMTtxFLqeQdDgwflaGgOkpBPDfqAStGVbYAzLYCgppGJkAenFWJHMqghAfJsTWNkQqjlvpwjjkJWBmbairSgVwWZdhgBNhqDIqVg"));
    this->CyXzIskhs(1199415139, string("eWynARSGjvDKwPeFgiaKiRfWiAfKukQFZMRofDcISxRdPVmgnPjlAxHZzQUFooODnNNqAQRXACFBKToRKkkcpTASmJbjLkmoxNznVuRgYlCOUBXeVFZuBrKGvAqunTRxDmmqjCuIkYGrGoqRlQdjBcsjSOBSFpjVIacnADBsbOnCOpEAJUnkHRNusTNUJRQAaCfEqoJHYjUCGkbSTJYUswFidzMAuVfTICLKlxuanxOnOnh"), 1873018811);
    this->WJUGXiprNx(-2063891683, true, true);
    this->fkrxTmAjZUo(679213.1285361345);
    this->guNVUjqIhWdd(true, 708974301, -1063112673, 2368479);
    this->NkneBJZP(680980.2380261, false, false);
    this->kMFhWMWbPr(true, 401841.81445809716, -985438.9424364929);
    this->YivQdzjT(399391.8385577302);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cVXktyljmI
{
public:
    int irNkHGhcuyXubz;

    cVXktyljmI();
    double pqqBNJBmfbClYZ(int kktLxIBB, string MbvOvxoBGdmTFcy);
    void lqYjV();
    double IOqBOHClJ(string CbscsECafCB, string aXFlfTku, int scJJBKAZ, string mIUbZyW);
    bool vuabnIYhGt(int NUqzBYOd, bool ZozMtqGTQrOuQ);
    void uxtxOoxvARa(bool WXmAfEw, int bzniZOH, bool ofTcDmRWGFldy, double PcbOZYrwTjaYkm);
    double VfpYdx();
    double tDAkBgoQAp();
    void hRlxGHI(double MWQhruJVeZLa, bool JldmLUBrKh, string uOdlfoU);
protected:
    double fmctQvBh;

    string OCGDddlcJopf(bool jIUZDaiukZplcTOA, bool pWRTGXcSVH, bool jBqFolkkFp);
    bool jUrWTd(bool rJhAtqlyGXLA, bool JonkPamUMmyiKkj, double jIfDSZuCTkxGlEIZ, string vdnPELyurltqy);
    string blUuNik(bool TgjbikOvMYQxe, bool jIZqETK, string Jxpmg);
private:
    bool LMkciIwajOWWZFT;
    bool OxPuTSeJIR;
    string hGIAlQtCEyoX;
    double SMLjuWcXXVkTyBD;
    bool yMFBE;
    double BHjtFNOVozyPv;

    double yCXDDTxZyUOWDux(double PYzIVOw, double ocGsV);
};

double cVXktyljmI::pqqBNJBmfbClYZ(int kktLxIBB, string MbvOvxoBGdmTFcy)
{
    double UPimQFKHfMCes = -647907.2897013049;
    string AvRtifgLqpcToB = string("UDTijfxx");
    int KbcdOtBgHKzosz = -1558392640;
    double APfUG = 507046.5370881019;
    string BGXFLdRaw = string("xiYShDKBlCeoJjUuuhzRWaEbfj");

    if (AvRtifgLqpcToB > string("xiYShDKBlCeoJjUuuhzRWaEbfj")) {
        for (int YNKqcDSZElnPxUT = 2109620265; YNKqcDSZElnPxUT > 0; YNKqcDSZElnPxUT--) {
            AvRtifgLqpcToB += MbvOvxoBGdmTFcy;
            UPimQFKHfMCes = APfUG;
        }
    }

    for (int VPDeefUwAxe = 563045824; VPDeefUwAxe > 0; VPDeefUwAxe--) {
        MbvOvxoBGdmTFcy += MbvOvxoBGdmTFcy;
        kktLxIBB += KbcdOtBgHKzosz;
    }

    for (int vYWMlcSRP = 1087364987; vYWMlcSRP > 0; vYWMlcSRP--) {
        kktLxIBB -= KbcdOtBgHKzosz;
        AvRtifgLqpcToB = BGXFLdRaw;
    }

    return APfUG;
}

void cVXktyljmI::lqYjV()
{
    int irPLrkQPw = -817384057;
    int iqfiZDccIxTh = 256853777;
    int dodPkxszpTwJp = -1804218793;
    double yhMFCRWdWID = 728328.4798232712;
    bool UXApuhGNNNzcY = false;
    int lYSFJSuRRPlT = -149521619;

    for (int AcVsQB = 1827715866; AcVsQB > 0; AcVsQB--) {
        irPLrkQPw -= irPLrkQPw;
        irPLrkQPw -= lYSFJSuRRPlT;
        irPLrkQPw += dodPkxszpTwJp;
    }

    if (irPLrkQPw != 256853777) {
        for (int MwtixrqLtYFPXmBD = 1325376404; MwtixrqLtYFPXmBD > 0; MwtixrqLtYFPXmBD--) {
            irPLrkQPw -= dodPkxszpTwJp;
            irPLrkQPw *= irPLrkQPw;
            dodPkxszpTwJp += iqfiZDccIxTh;
        }
    }
}

double cVXktyljmI::IOqBOHClJ(string CbscsECafCB, string aXFlfTku, int scJJBKAZ, string mIUbZyW)
{
    int vKtPBtTDlVDXdHOl = 2062347449;
    string gEaQCgfvW = string("oIyVdlHS");
    double FXHfnzaXiQhr = 107425.13046139567;
    string LYmvCHgJXcnhP = string("ImgqhJWBANCtcPDCRMFgbiQUiiHEkNsJGPEUEAFgbogLQXdYdIhzpasTHxneeXBtbZlQfJHkhRNcBcIHPNayf");
    string CSajGO = string("qwhvfGi");
    int wBufwdb = 873040294;
    string UjClElaps = string("iYEdqxyiRbuPDYLESTLWehVNMCVNRdpjVTpZOVqDGnFDxnETUWeKwpnbpmTwnGcRXuGpCWIIsEfeCIMeLkgPTjrkrqKnXLvQehYWHdkNfTAfCsHazYVoUUsPjtEFdoWpiJGJmsSUOjesoojpUoVwzKNHVWngoQAoaJqcuBHfeMaXquqcnVUjcnrhDUitrdqLPhZiHMIsIVHnijg");

    for (int XrmEhkmbbVyk = 1628959462; XrmEhkmbbVyk > 0; XrmEhkmbbVyk--) {
        CbscsECafCB += aXFlfTku;
    }

    return FXHfnzaXiQhr;
}

bool cVXktyljmI::vuabnIYhGt(int NUqzBYOd, bool ZozMtqGTQrOuQ)
{
    double PqMDtCpcfvJsDM = 775220.1296222773;
    string hoOjfhaY = string("vXVMuDHDaRDeRWwapuOHIsPvECcxbxBfdiZTOyqxLKcBiCCRjpQEWfDMpmfgkaECQUuPFjVGjysLogXuhGWdogoMdCojIpPwaVorHYKtXVuHfExNbrRptjdUeokyfRIZlPGwCTDNBLKTCCvvHMioXTTsEzAHmFiT");
    bool vykfVsD = false;
    double hQhgfpsflIwUPvy = 747492.0738402201;
    double JSDleOSRtWCF = -747273.1207543195;
    double SOtxswTMNL = -667077.1519810015;
    string JpBQezYQvWDm = string("JmZZiypAfopcpwMYRPoDzuDkOWDPdHciYrqNLODjuIixTPuoViZvKhNEJqzyiaKMWATyShnsrPrnhafYpVOGMZnvkIOugtXuOhaxhwtrVsWsbRFAbzlRLadtejLjHttZnwGYwhClvOlrjsPOGthxXTfn");
    double igeNShD = 849594.5063643927;

    for (int zniJkSjho = 1119691443; zniJkSjho > 0; zniJkSjho--) {
        hoOjfhaY += hoOjfhaY;
    }

    for (int XtkQUcLolJSTABBI = 1587797034; XtkQUcLolJSTABBI > 0; XtkQUcLolJSTABBI--) {
        JSDleOSRtWCF += igeNShD;
        hQhgfpsflIwUPvy = PqMDtCpcfvJsDM;
        igeNShD = SOtxswTMNL;
    }

    for (int uiojwulTO = 562280213; uiojwulTO > 0; uiojwulTO--) {
        NUqzBYOd = NUqzBYOd;
        hQhgfpsflIwUPvy -= hQhgfpsflIwUPvy;
        ZozMtqGTQrOuQ = ZozMtqGTQrOuQ;
    }

    for (int jNTKZG = 745044558; jNTKZG > 0; jNTKZG--) {
        continue;
    }

    if (SOtxswTMNL > 849594.5063643927) {
        for (int FSTgEZxxoLgA = 678399374; FSTgEZxxoLgA > 0; FSTgEZxxoLgA--) {
            JSDleOSRtWCF += SOtxswTMNL;
        }
    }

    return vykfVsD;
}

void cVXktyljmI::uxtxOoxvARa(bool WXmAfEw, int bzniZOH, bool ofTcDmRWGFldy, double PcbOZYrwTjaYkm)
{
    double fOVYmAdlxzu = -608464.2026344031;
    double KJcXwyT = -439867.8225407942;
    bool rpQuYpIx = true;
    string qRiEKs = string("NLobQeKgsfGZgmlbsfIhGdeyYSCFawjKFLHTvnzJVwaAoYlqYoantOkzVfjrckPhiYoOlbhYSFiQzLiiExuXZuhhtsHjSCvAKxQRbJessFOHvFwuzogCrkdNtdRKlVYjsdRKzIXGPdNHBDVxgQINUCHNbXLxswcxfOVxMZlNohkEgWeygBditjckJiiytLZOqOayepolGMzxtndMIgzxDoppGlhEEFOM");
    bool jfSGKpsNKEXxT = true;
    string OGFDHDHLodJbLpye = string("fzDHHqgafWbQDJqkcyBhqiPBTijAJDVSErnSJa");
    bool UHLgXltwFGFkoA = false;
    int EZuQfm = -1268018138;

    for (int QOdxCfItLI = 1861167245; QOdxCfItLI > 0; QOdxCfItLI--) {
        ofTcDmRWGFldy = ! WXmAfEw;
        ofTcDmRWGFldy = ! rpQuYpIx;
    }

    for (int xIFzQGFNLuHEdU = 1907573651; xIFzQGFNLuHEdU > 0; xIFzQGFNLuHEdU--) {
        fOVYmAdlxzu += PcbOZYrwTjaYkm;
        ofTcDmRWGFldy = jfSGKpsNKEXxT;
    }
}

double cVXktyljmI::VfpYdx()
{
    double idWdwurPjQFHI = -1022349.7790113654;
    bool KpDfmqS = false;
    double ootQhFjBNm = 32291.72414684574;
    string kqBBGiVhOBJN = string("riVnMprEYkQpMLLWSIUKvYcEvBnrgutrWsHYHaYKWmKAhsEmQyYMNAuMKtILDZZSGldXpwiCmjldefNbJUroUgdDfpygXwzpJVDMGkJUwzDD");
    double dLZxZXGzo = 609577.1670110844;

    for (int RkFhNVaw = 421866973; RkFhNVaw > 0; RkFhNVaw--) {
        ootQhFjBNm = ootQhFjBNm;
        idWdwurPjQFHI = dLZxZXGzo;
        ootQhFjBNm -= ootQhFjBNm;
        dLZxZXGzo *= dLZxZXGzo;
        ootQhFjBNm = dLZxZXGzo;
    }

    for (int ZSxqjatYGmKzQ = 749989268; ZSxqjatYGmKzQ > 0; ZSxqjatYGmKzQ--) {
        kqBBGiVhOBJN = kqBBGiVhOBJN;
        ootQhFjBNm = ootQhFjBNm;
    }

    for (int KUmLTYNd = 1315892112; KUmLTYNd > 0; KUmLTYNd--) {
        kqBBGiVhOBJN += kqBBGiVhOBJN;
    }

    if (idWdwurPjQFHI < 32291.72414684574) {
        for (int BxQeEXbzAzX = 754390831; BxQeEXbzAzX > 0; BxQeEXbzAzX--) {
            ootQhFjBNm /= ootQhFjBNm;
            dLZxZXGzo = ootQhFjBNm;
            ootQhFjBNm = idWdwurPjQFHI;
            ootQhFjBNm *= dLZxZXGzo;
            dLZxZXGzo = ootQhFjBNm;
        }
    }

    for (int RqrylcAh = 210989010; RqrylcAh > 0; RqrylcAh--) {
        idWdwurPjQFHI /= idWdwurPjQFHI;
        ootQhFjBNm -= dLZxZXGzo;
        dLZxZXGzo *= dLZxZXGzo;
        KpDfmqS = ! KpDfmqS;
        dLZxZXGzo -= ootQhFjBNm;
    }

    for (int KVoqxUyaSTr = 420489993; KVoqxUyaSTr > 0; KVoqxUyaSTr--) {
        continue;
    }

    return dLZxZXGzo;
}

double cVXktyljmI::tDAkBgoQAp()
{
    int poRDdTDTyu = 2065407956;
    string DfsngKwYWWc = string("lVnBUskdIERwygGlhKNSmeJDPgGFoXYOHPxZSeaYxpLuQlNuPeWQUqDYowOHHqghQFobpSdCgbwHrfUvDtVWzNeGiFWVCtLKceqUPsrIZhvrWRMeVKPkmPbVQeULAWubzTlwqrDLUaEBxaWBHdXIgcqEFNUQovhSjugrWZwhJIbIwtmThUsZQgLsbGJVkuHnsmVOWlBZ");
    string FsyVYM = string("aoxraKqXCHpAKPeBFwSIVYlxyETrDjjMIyCTZLlOGrvmlryHjsOQiXdwgCtkwyKdtIqpnFMBhEdLarWeWyPbAwbYAMEiqjmgmXqRYrKlmnRqtQFwzuYvGdTqdfaZkUVoxbCPBbXxKwGrqTlQiJfNUuXFbztfpgwXaoNjDnrpxviXmWtlUaLFnsMGJUcwhVt");
    bool LgmHVgarxbQnr = true;
    bool nSkKePZwdHgbB = true;
    string RsBHfGlNEOxARL = string("xLAKiiIwbPqmggimCPh");

    if (LgmHVgarxbQnr == true) {
        for (int fPVLSukHyYxEqOd = 152616268; fPVLSukHyYxEqOd > 0; fPVLSukHyYxEqOd--) {
            DfsngKwYWWc = RsBHfGlNEOxARL;
            nSkKePZwdHgbB = nSkKePZwdHgbB;
            LgmHVgarxbQnr = nSkKePZwdHgbB;
        }
    }

    for (int UnUPHwdwitQETIo = 925870407; UnUPHwdwitQETIo > 0; UnUPHwdwitQETIo--) {
        continue;
    }

    return -82795.7498429418;
}

void cVXktyljmI::hRlxGHI(double MWQhruJVeZLa, bool JldmLUBrKh, string uOdlfoU)
{
    double ivesvcfpta = 699054.5521545149;
    bool oaqPcDNpeMe = true;
    int ocAlAYKjY = -1121746261;

    if (JldmLUBrKh == true) {
        for (int jFMwVcXxHiSxIYd = 406937779; jFMwVcXxHiSxIYd > 0; jFMwVcXxHiSxIYd--) {
            JldmLUBrKh = JldmLUBrKh;
            ivesvcfpta /= MWQhruJVeZLa;
            oaqPcDNpeMe = oaqPcDNpeMe;
        }
    }

    if (ocAlAYKjY > -1121746261) {
        for (int Fhdzeqbl = 2035213864; Fhdzeqbl > 0; Fhdzeqbl--) {
            ivesvcfpta += MWQhruJVeZLa;
            MWQhruJVeZLa -= ivesvcfpta;
            ivesvcfpta = MWQhruJVeZLa;
            uOdlfoU += uOdlfoU;
        }
    }

    if (oaqPcDNpeMe == true) {
        for (int rJcirlOigcPQDWRf = 1869533356; rJcirlOigcPQDWRf > 0; rJcirlOigcPQDWRf--) {
            MWQhruJVeZLa /= MWQhruJVeZLa;
            oaqPcDNpeMe = oaqPcDNpeMe;
        }
    }

    if (ocAlAYKjY < -1121746261) {
        for (int TkKAPScN = 891537093; TkKAPScN > 0; TkKAPScN--) {
            ocAlAYKjY /= ocAlAYKjY;
        }
    }

    if (oaqPcDNpeMe != true) {
        for (int xoxlLcPE = 1044658670; xoxlLcPE > 0; xoxlLcPE--) {
            ocAlAYKjY -= ocAlAYKjY;
            JldmLUBrKh = JldmLUBrKh;
            MWQhruJVeZLa = ivesvcfpta;
        }
    }

    for (int CmxOYlxPnBmyk = 576253121; CmxOYlxPnBmyk > 0; CmxOYlxPnBmyk--) {
        MWQhruJVeZLa = MWQhruJVeZLa;
        oaqPcDNpeMe = oaqPcDNpeMe;
    }
}

string cVXktyljmI::OCGDddlcJopf(bool jIUZDaiukZplcTOA, bool pWRTGXcSVH, bool jBqFolkkFp)
{
    bool cvnIgdfKfeBGDkhb = false;
    double OAuFYbeHuSfuFvh = 500791.22486103285;
    bool YgWmtIkvNvYk = false;
    bool tkfXM = true;
    string lprqoVttnXehpo = string("PMYZOctuQRJRQxOoSDmLLhPffnSUYucXLokRHvrK");

    if (jBqFolkkFp != true) {
        for (int fBbmr = 1731720981; fBbmr > 0; fBbmr--) {
            lprqoVttnXehpo += lprqoVttnXehpo;
            tkfXM = cvnIgdfKfeBGDkhb;
            jBqFolkkFp = ! pWRTGXcSVH;
            tkfXM = cvnIgdfKfeBGDkhb;
        }
    }

    if (OAuFYbeHuSfuFvh < 500791.22486103285) {
        for (int uljmSKJxbhIKGg = 1993911073; uljmSKJxbhIKGg > 0; uljmSKJxbhIKGg--) {
            YgWmtIkvNvYk = ! YgWmtIkvNvYk;
            cvnIgdfKfeBGDkhb = ! pWRTGXcSVH;
        }
    }

    if (pWRTGXcSVH == false) {
        for (int bmvCV = 543420232; bmvCV > 0; bmvCV--) {
            tkfXM = ! cvnIgdfKfeBGDkhb;
            tkfXM = tkfXM;
            tkfXM = ! YgWmtIkvNvYk;
            tkfXM = pWRTGXcSVH;
            jIUZDaiukZplcTOA = ! pWRTGXcSVH;
        }
    }

    if (cvnIgdfKfeBGDkhb == true) {
        for (int CEAVIwVhGzuWq = 22163615; CEAVIwVhGzuWq > 0; CEAVIwVhGzuWq--) {
            tkfXM = YgWmtIkvNvYk;
            jBqFolkkFp = ! YgWmtIkvNvYk;
            jIUZDaiukZplcTOA = jBqFolkkFp;
        }
    }

    return lprqoVttnXehpo;
}

bool cVXktyljmI::jUrWTd(bool rJhAtqlyGXLA, bool JonkPamUMmyiKkj, double jIfDSZuCTkxGlEIZ, string vdnPELyurltqy)
{
    double MblmujXOoof = -34421.34323164977;
    string JNOxuVVNwjRTWBS = string("sLMHIjhffAZEjXrUECnWSPptENpvVBroWGERhMIpWtHlZpyfuHTcXwNttSOcAPzsnMcgztRGrLSJjQuagzsvdxgiOnlyrioXbUEVZZjcVETjEwyAnUacnRYoEPdhDduFBfnBHBcYxGmsYpcfiBPVqJkdpimtCmvUIkvyfGJXVDehhaGZeIUxRnRqFPEnOowxyenEkpgPfjWbIbynFPQWiQSytAkJrZNZWnmGLusWqruzZ");
    int wQuviYwoaEVvG = -1944014873;
    bool cbZnbwRlaW = false;
    int qBSAAlSdod = -370443549;
    string dWWIJeHVyh = string("dbaeHPEpdFBDbYTWMFhJlTTXRwiSqwIUPtUKpxbpapAJWuKBtLoRtUBaJRdQpcqCeKCZyFLYlUADBWL");
    bool RotmaH = true;
    double NnmoCxylbsdpw = 390554.02465081634;
    double rNiEADyADVoLiwh = -868202.3175862025;

    return RotmaH;
}

string cVXktyljmI::blUuNik(bool TgjbikOvMYQxe, bool jIZqETK, string Jxpmg)
{
    int slJsQzDlP = -807773288;
    bool blwfXfbranEFUo = true;
    bool PtZpl = true;
    bool AUVAFfBfo = true;
    bool OgdaFGrVwiAB = true;
    double zyOwa = -44551.61795058666;
    double tJfZrebaKD = -389875.5274716441;
    bool iYiwOwyeUSw = false;
    double hWDjAczMvxuvdyqc = -161746.90112473365;

    if (Jxpmg < string("fcfXDyGorcXBEnNZqsvpIvWDExSHKpxTctoxHWsuFDUEcCZlEoNZYQeivDgXGrxQuqeTVgDekxOYoSwcUPRtBwl")) {
        for (int OJvkP = 152952383; OJvkP > 0; OJvkP--) {
            zyOwa /= hWDjAczMvxuvdyqc;
            PtZpl = AUVAFfBfo;
        }
    }

    for (int lcBCImNt = 899227005; lcBCImNt > 0; lcBCImNt--) {
        iYiwOwyeUSw = iYiwOwyeUSw;
        tJfZrebaKD -= tJfZrebaKD;
    }

    for (int azgwZ = 2046905726; azgwZ > 0; azgwZ--) {
        OgdaFGrVwiAB = ! OgdaFGrVwiAB;
    }

    for (int pBcUPYgc = 1250958672; pBcUPYgc > 0; pBcUPYgc--) {
        jIZqETK = ! TgjbikOvMYQxe;
        AUVAFfBfo = OgdaFGrVwiAB;
    }

    for (int dlZACQKQ = 2091243903; dlZACQKQ > 0; dlZACQKQ--) {
        TgjbikOvMYQxe = jIZqETK;
        OgdaFGrVwiAB = ! jIZqETK;
    }

    return Jxpmg;
}

double cVXktyljmI::yCXDDTxZyUOWDux(double PYzIVOw, double ocGsV)
{
    string kdLOChbWejTQVaG = string("KBkGjeeIFmgirlsPqoOsrzmOFR");
    bool CzXNdMxgDpKpKXj = false;
    int WzVnDvYBaiIKqDO = 1932669567;
    double AWojrfwnrShW = -495749.71702254424;
    double PEwSDVoOpfmTTfKD = -47058.88946505858;

    for (int SZijgkSGq = 956114281; SZijgkSGq > 0; SZijgkSGq--) {
        PYzIVOw -= ocGsV;
        ocGsV = ocGsV;
        WzVnDvYBaiIKqDO += WzVnDvYBaiIKqDO;
        PEwSDVoOpfmTTfKD -= PEwSDVoOpfmTTfKD;
        WzVnDvYBaiIKqDO *= WzVnDvYBaiIKqDO;
        PYzIVOw = AWojrfwnrShW;
    }

    for (int WWlcnOLcKUEKfjKp = 68517056; WWlcnOLcKUEKfjKp > 0; WWlcnOLcKUEKfjKp--) {
        PEwSDVoOpfmTTfKD /= PEwSDVoOpfmTTfKD;
        AWojrfwnrShW += ocGsV;
    }

    if (PYzIVOw != 108035.82037049199) {
        for (int MTjWBSUyztap = 666890940; MTjWBSUyztap > 0; MTjWBSUyztap--) {
            kdLOChbWejTQVaG += kdLOChbWejTQVaG;
            AWojrfwnrShW /= ocGsV;
        }
    }

    return PEwSDVoOpfmTTfKD;
}

cVXktyljmI::cVXktyljmI()
{
    this->pqqBNJBmfbClYZ(-1726493046, string("IPWqdYkEUBeHgiEhdSWzdCpEASCeVTxVfAaBxfvmUiDKcyoKlYMjaLBCufAIszNZwJvEcwaJwsDWYkEbfCYEXfiZAsvWcxCSgh"));
    this->lqYjV();
    this->IOqBOHClJ(string("iqJUWzziIJvKIlbdaCuMDSpRRUQSNbafvErODMyayXxogebbmajMuCXruSXsMWzrDFqPAoPtqItRctSwYzODrdQRZOYIKTWMJjiXyIFkAlaQvcXViBLTgMcVFPgyqQVv"), string("jZnfpHviHmAWSEeyfrVdRiLBJQzYktkMgNyTNbTXqgnFFXEDSQUWSMfXlxYtOvdFqzRmGSjDqFTXJYNxXPcwLwFkBYmyjrnmmfdUfHVtoCMqLqYiMpLRNrzVMLfDocwRXtAoCBEeklzfQOsKAHplhewcdnceGHQMHiMhBYWeBVuQOQkF"), -2144725787, string("RHPSBuJfBjuBSCbapCNmoopBLCKsbSudhAGIJcmWFrRmwLpDHMNhVwPNSBbLkSsMLYrcPhCIIRnkIXTTrgCyudlkosgBIC"));
    this->vuabnIYhGt(-1488960199, true);
    this->uxtxOoxvARa(false, -217951978, false, -274437.9922128551);
    this->VfpYdx();
    this->tDAkBgoQAp();
    this->hRlxGHI(534703.2220427928, true, string("LQEciCArqGShzQpNDJnUtdEKLanIjHAtesUuvMJQWpdmRrigHSvyiwksZSUEgNeLAQwgeAXVbtiAyyPbiNcFUHGkOFZtsonnalvKsIXqfIakDJpgpoKHwGeNsWoNUkzNPQjpanZWTTznPEPZaqESvolYJMNxDibZvXDubGMsWQPyrKGgLXKSRgBYWOMVVwHqFudOgJVmSSWCcSNEuEePlUtXLaioOBsFUcxayWDtvFNByntKCYoktVZdUXqEnj"));
    this->OCGDddlcJopf(false, true, false);
    this->jUrWTd(false, false, -91035.1103267411, string("RmXerZsqPqqGzQSXftlILYEmUhblYGtsbTxvXPvHsFvEwSRWRkfVPmKlPJcYVpCCI"));
    this->blUuNik(true, true, string("fcfXDyGorcXBEnNZqsvpIvWDExSHKpxTctoxHWsuFDUEcCZlEoNZYQeivDgXGrxQuqeTVgDekxOYoSwcUPRtBwl"));
    this->yCXDDTxZyUOWDux(108035.82037049199, 343951.52690866706);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XIxLxPJHuSLHpQQ
{
public:
    bool JOWPBs;
    string wXzwwnbDplRS;

    XIxLxPJHuSLHpQQ();
    bool xBupi();
    bool HSgpCwpSqKLhg();
    void nRHAAfnbmExS(double jrkAFPGgglSjrrir, string qqMZPJD, double QZfObeLo, string appiwHJaqpRXN);
    bool pyXjgBlKOFmubNUY(int icIhGQImLUhpFz);
    void qCRIkQNDHtsPW(double LBIgp, string SmpiQBbBYdNnQ, bool AhiCUoZjwwa);
    double WrwcFynQ();
protected:
    int oNlZLf;

    void huuaKpB(string UcKnFZkqUPPbaPhX, int OnqSJB);
    void ynczPWArNIQs(double erDnIOBjH, int UCgRcaVZOBYkmHNL, bool xizPJqO);
private:
    bool sdngfyehA;
    bool dqUPzWCYCoBrtQVq;
    bool thzyIaiog;

};

bool XIxLxPJHuSLHpQQ::xBupi()
{
    int oWiEMoBuWghJYV = -185995564;
    string bHqavNsLDxnN = string("AJiUkYhkWEckVyLBUhANYCkrqzUtzUvVukDAgEUfDaUjWrxxSxKOHFIUcSDuvXFhTNgDIaYpOvTgoZLSGQrnViAuemSKCWeDPzFQFwIVSmAUHOwCgQIBuXzMAEKGjmrEbcVdDHRjYLrLnDpUqvxPFbpbDaMLVeHqtgXtdIDNIhUVipunfSFSTFiiMteFeHhZNFJUSox");
    string nTYCjMLhZzBiTvG = string("JMRPXytGVTzGpImbVnZMEdRgmhIzgdZJhDQaZgJYFgfodRtHPLZPVnUfGMwDqnonXaTkkGBfZRlqZFeWQsyzBdWMVLVBBCasUiUwAHopBxqFcfpFenBiWdLtPgCkfUPbfAdpaXayeoKw");
    string XxTiYgBQowcEwYqy = string("GFunyOuLSEYsGlQItrnZSYrsVuaCTVEDAKughtmqUfKAHwhlsgPuGzqVDKzMugOvTmbBHxmOVIBWerLAarIfALiEBGVFtQTkvOMELpPDoXqFShApJkbMFCDljHyuglue");
    int qCNxJmo = 213717475;

    if (nTYCjMLhZzBiTvG > string("JMRPXytGVTzGpImbVnZMEdRgmhIzgdZJhDQaZgJYFgfodRtHPLZPVnUfGMwDqnonXaTkkGBfZRlqZFeWQsyzBdWMVLVBBCasUiUwAHopBxqFcfpFenBiWdLtPgCkfUPbfAdpaXayeoKw")) {
        for (int wnkuvRKvnuyOQhEM = 239776274; wnkuvRKvnuyOQhEM > 0; wnkuvRKvnuyOQhEM--) {
            qCNxJmo += oWiEMoBuWghJYV;
            XxTiYgBQowcEwYqy = bHqavNsLDxnN;
            nTYCjMLhZzBiTvG = bHqavNsLDxnN;
            qCNxJmo -= qCNxJmo;
        }
    }

    for (int usbfHgIz = 1980946563; usbfHgIz > 0; usbfHgIz--) {
        continue;
    }

    for (int bOFgBd = 182278313; bOFgBd > 0; bOFgBd--) {
        nTYCjMLhZzBiTvG += bHqavNsLDxnN;
        nTYCjMLhZzBiTvG += nTYCjMLhZzBiTvG;
    }

    return true;
}

bool XIxLxPJHuSLHpQQ::HSgpCwpSqKLhg()
{
    int YubxNHgwGjvr = -1238820317;
    double yennVIzxkRt = 928782.3659308339;
    bool mjuMkMQ = true;

    for (int CuMDmRXG = 1914178408; CuMDmRXG > 0; CuMDmRXG--) {
        continue;
    }

    return mjuMkMQ;
}

void XIxLxPJHuSLHpQQ::nRHAAfnbmExS(double jrkAFPGgglSjrrir, string qqMZPJD, double QZfObeLo, string appiwHJaqpRXN)
{
    bool bGtJYJ = true;
    int qcGzNItFOMcJTPDE = -1448415133;
    string XPRhBFNXGp = string("PQswOZkBRdldDCSXjfrQepcbbXETNrJtcFzoFiwMWXitcqoKggAVolHmtxMIRBTWnrHbiiQahhLXGISUnoGRRwwBlqUkpLZYCGWtXHmMgWbCrKbAorJTYUFKrVkvvHFgVArfJTkkCAilCXaugsGKWwgWgukAjscEUqjdmAETSRiqloCvziBdcRaqmSqLGmmaor");

    for (int rweINJSQNxp = 1264915373; rweINJSQNxp > 0; rweINJSQNxp--) {
        qqMZPJD += appiwHJaqpRXN;
        jrkAFPGgglSjrrir += jrkAFPGgglSjrrir;
        QZfObeLo = jrkAFPGgglSjrrir;
        jrkAFPGgglSjrrir -= jrkAFPGgglSjrrir;
        QZfObeLo -= jrkAFPGgglSjrrir;
    }
}

bool XIxLxPJHuSLHpQQ::pyXjgBlKOFmubNUY(int icIhGQImLUhpFz)
{
    int oFagRhSPbBtj = 1977552467;
    bool JJFlVi = true;
    double vBBLUziCfLfKrh = -216371.70029515453;
    bool ctdKqaVriEvREk = true;
    int GgnHBRpeipP = -1475090301;
    string mtTGHUca = string("cdvsQIFlNqpUFOH");
    int CgztBnbIfNMkja = -442215808;
    double nzUKrGpYXCIlxzno = -457932.42672872636;
    string gzUbmjmBdBD = string("tFEgQyxvtGhrKTyqRrLfihNYeCXnDiPyIfpxiBrfBseefYmwFLDBcWCwLLXpnuNawUPEiLaMcSnoonUFn");
    double yzZlterx = 595601.51714445;

    for (int lSeHurHfkdFDeWH = 440543454; lSeHurHfkdFDeWH > 0; lSeHurHfkdFDeWH--) {
        continue;
    }

    for (int XRivuxXjrTGfklm = 1709828283; XRivuxXjrTGfklm > 0; XRivuxXjrTGfklm--) {
        continue;
    }

    if (vBBLUziCfLfKrh <= -216371.70029515453) {
        for (int vZVthLRHpBjDWBx = 1830962424; vZVthLRHpBjDWBx > 0; vZVthLRHpBjDWBx--) {
            continue;
        }
    }

    return ctdKqaVriEvREk;
}

void XIxLxPJHuSLHpQQ::qCRIkQNDHtsPW(double LBIgp, string SmpiQBbBYdNnQ, bool AhiCUoZjwwa)
{
    string iKOlBlLzGat = string("xkvghFsb");
    bool gnufYldzhWGMvoZA = true;
    int ANqoWsXciyMK = -88478444;
    double nTBre = 948758.0554372735;
    bool iPeDKRSvYQrzryH = true;
    double FDimfAhJR = 966035.8727549405;
    int CXCFGGYHd = -1897285417;
    string xnylSVnQDxsbMW = string("edHOPGogfsGYzxPDyvWnrwjTOEHkuqHVSCrJlQSmTPPKJieSqjiWYDtq");
    string WqxPKCOd = string("ZYCYxljyRldLQjfveBasRtUZwZqanyaMUiBWiZbDYpNFgHPBOURWfJlIGtCRhCIicomblQsLfdxkwcYIgTFuSCBXKXkQZGhBuEqaIUSntLnAixHnjSmfvTIuTuyzihAsOHNzjCRMldEzhEoNPmGSNhTuiqgvYXqrlKSE");
    double ERxffvmFIzDgOxpm = -588196.5078120386;

    for (int HhsoQeFpVrlIqkq = 743482062; HhsoQeFpVrlIqkq > 0; HhsoQeFpVrlIqkq--) {
        AhiCUoZjwwa = ! gnufYldzhWGMvoZA;
    }

    for (int TwfZuxteB = 834781999; TwfZuxteB > 0; TwfZuxteB--) {
        WqxPKCOd = xnylSVnQDxsbMW;
        iKOlBlLzGat += WqxPKCOd;
    }

    if (CXCFGGYHd == -1897285417) {
        for (int ERWFkgZPDpvT = 317446802; ERWFkgZPDpvT > 0; ERWFkgZPDpvT--) {
            continue;
        }
    }
}

double XIxLxPJHuSLHpQQ::WrwcFynQ()
{
    bool iTrRp = false;
    string WzkvsYeknTQr = string("mJAFNKHTpxmLBGcWNsoSDvYyUzSMhHzjdDgsCXsZtYEXduNwcSaiWwFjXLAczghbCPAAAqAwIwHdDxQiZWjDiAWlFhHxyOLpjrDVgTugJdZHyzgYFpIfDxfrfGAUYRgnnqXvUqBnanHqBUdcmGIlfhiyfUMLGWVwxtjQGsvibEgmLNDiddpthMYSGPDkxnxqEjNSahSLibtomeooLCjQgAuJKouDbGCvOcpPLp");

    for (int UTLXKVZd = 1714803349; UTLXKVZd > 0; UTLXKVZd--) {
        iTrRp = ! iTrRp;
        iTrRp = ! iTrRp;
        iTrRp = iTrRp;
        WzkvsYeknTQr = WzkvsYeknTQr;
        WzkvsYeknTQr += WzkvsYeknTQr;
    }

    return 1035463.6516030361;
}

void XIxLxPJHuSLHpQQ::huuaKpB(string UcKnFZkqUPPbaPhX, int OnqSJB)
{
    bool SVgICgCGGnnW = false;
    int lQgnxeC = -1104638774;
    bool hQdRNFWDSH = false;
    bool zNOzRb = true;
    bool MifWKjFgjcrDCS = true;
    string bslYiAMaFRScmp = string("FoWKLUsrRaagJTFkEMOZjvZVEAYEOIHBxUmjUqQjdFBZuymuvHbemBVrNEYdRsLRZDhMIeArchLgdHAgySUKpFotKBWFLfpuMWStPPDNXuFLizvWatXpOWCLOAvtkSlfhltbnJczFDyfZAXDhIEchglwDWAouYmmAXDmmokNQEjaTidyCRpVcuCfYRVxhYntYudlCXzFncfFizhBUCsPbBGpqkzsBvwRKKiKHzokcbdNdPwP");
    double pphrokrn = 39683.46744840047;
    double RqZxd = 308190.7079871914;

    if (zNOzRb == false) {
        for (int okMXT = 1031264870; okMXT > 0; okMXT--) {
            continue;
        }
    }

    if (MifWKjFgjcrDCS == true) {
        for (int YWISCwtdHHtwUUb = 1776922166; YWISCwtdHHtwUUb > 0; YWISCwtdHHtwUUb--) {
            SVgICgCGGnnW = ! MifWKjFgjcrDCS;
            lQgnxeC /= lQgnxeC;
            MifWKjFgjcrDCS = hQdRNFWDSH;
        }
    }

    for (int YAWtiRhXa = 807537424; YAWtiRhXa > 0; YAWtiRhXa--) {
        continue;
    }
}

void XIxLxPJHuSLHpQQ::ynczPWArNIQs(double erDnIOBjH, int UCgRcaVZOBYkmHNL, bool xizPJqO)
{
    int tCPrxdf = 1704266965;
    double cvquxosoOxOhhv = 142872.80212849122;
    double wJZuFWrKrngk = -685873.6498265383;

    if (cvquxosoOxOhhv != -685873.6498265383) {
        for (int hmDCnofHYf = 745226892; hmDCnofHYf > 0; hmDCnofHYf--) {
            wJZuFWrKrngk /= wJZuFWrKrngk;
            wJZuFWrKrngk *= cvquxosoOxOhhv;
            erDnIOBjH = wJZuFWrKrngk;
            erDnIOBjH += erDnIOBjH;
        }
    }

    for (int MRPtEXxTZhU = 981581260; MRPtEXxTZhU > 0; MRPtEXxTZhU--) {
        UCgRcaVZOBYkmHNL -= UCgRcaVZOBYkmHNL;
    }
}

XIxLxPJHuSLHpQQ::XIxLxPJHuSLHpQQ()
{
    this->xBupi();
    this->HSgpCwpSqKLhg();
    this->nRHAAfnbmExS(706713.0161474036, string("GVXyXiVJILWLGlQdGFPGiEkTTszbHPPrgLTbGpNIqeMWfhaotiUChBLsRkurNpFnYZbuHhOBUzWEETibIcvBQxDocvcBafvpMRDDZVhYyobXjqMatTCOnMnEyfXnlRDgvmVvOebpujCfExtgigoDtZJmshFBLJUBZdf"), -1036348.417442005, string("cAsYPwLAlraQzPQGxWskAvlDKAkwTEIzuJeZHKvzRRSpDLtUfkwoWUTIWnBDw"));
    this->pyXjgBlKOFmubNUY(-1943788186);
    this->qCRIkQNDHtsPW(793703.9165957234, string("vLCHyBHSDLIFCSkvYvZbwybUTwJvkBOHnvKzlfqZAPlRAHODBlWwQmvtSLiD"), false);
    this->WrwcFynQ();
    this->huuaKpB(string("DmRAYVsSRFuzELPeEfvYnkJkBcyXalZUzEhpDDjoankusOtBscesVypXTEqlRnoTgtqrBPTNGDGlZlQBUggbAeYLtxAMAGYjcQCPlfsbgQcfYlIkUYRMvXoHLQvVETuShbPvNBuqKnxBfGCxtkMBswTSjzZssnZzqfluXlNBurLyYJFekbtdQeLRGWAxDfSnyqtTngeWRcuhXWbZMQMSEbsMVemyuusnOaCGBKaU"), 2127516282);
    this->ynczPWArNIQs(932917.1233601271, -658357425, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ToBaLKIBqNmisK
{
public:
    double APNQiOeSNCnqFytw;
    string NTUoF;
    double xKxSsTexOkVeV;

    ToBaLKIBqNmisK();
    bool hXITMgmf(string evcjXWojZ);
    int dhhVirODMgS(bool fdOODWWGmMrDD, int nKVEVQDImJnUxmE);
protected:
    int GgHvTgx;
    bool BdImzL;

private:
    double fUUsslXV;
    bool VAZxbo;
    bool lbPWC;

    string jeMgwPnRbVptZDQ();
    int ACPcVVKF(string whbnoqclF, int udNHfBhUb, string jOeXzBXYZUvQAY, string IdbWFXa);
    string mOXmwDilJ(bool eNwIjc, int ebJjMboV, double bpIkAyjCVoTeM, bool EUJxAYZytlXeR, double ylukcFJbmFkUgsAq);
};

bool ToBaLKIBqNmisK::hXITMgmf(string evcjXWojZ)
{
    double gxiYwmbyGAwJEu = 254172.90925564407;
    bool FiOJwWqbFIS = false;
    double tDyxJmUEUbiyTIz = -300841.43619890034;
    string njfxacAcuyFpCzL = string("VuJoXvmITgBlpJBHTbCfQqzlGFluwSCihfIoxgxbzrlMKwUxZTksnnjTTOAVQYQOPqHaAilghTKGoxuhiLxSkQPQEW");
    string fTFuRxWaAxt = string("euDdOhuPpncoSYZGVZtJgZUhIGRaIVvQqKlzsEiOuyWftbdMbGASsgsUfIwCvRysJkmrrMrXyqRCHqxJkOMXqRfxcvgeWNgjbHOjBWNKaGUGLPvjMwCKKhRLgaiWKlSHKGciXXgUEuVOSJVEwkvIuBYQUbvAtaugPpvxSOQwKXDLGVRLrmuswfOAyVlkRuuNOhmXpDZufYQPtVXBkLnBkUMRQDqViZDGIDYy");

    for (int CgcBU = 126326208; CgcBU > 0; CgcBU--) {
        njfxacAcuyFpCzL = fTFuRxWaAxt;
        gxiYwmbyGAwJEu *= gxiYwmbyGAwJEu;
        tDyxJmUEUbiyTIz += gxiYwmbyGAwJEu;
        gxiYwmbyGAwJEu *= tDyxJmUEUbiyTIz;
    }

    return FiOJwWqbFIS;
}

int ToBaLKIBqNmisK::dhhVirODMgS(bool fdOODWWGmMrDD, int nKVEVQDImJnUxmE)
{
    int UyOCQArdFeqDr = -1425709343;
    string uZPmEBylhbuWwRZ = string("lxuZWCKAUQMfpJIHezCMjUEhNZryUbTfQPFicYBwrWdJTYftzfXk");
    bool lGUxCTlfXun = true;
    int qoqZsIiNMQPjal = -597715503;
    double dxBBtndPvhh = 847053.5861328403;
    bool tovps = true;
    bool JxchrQX = true;
    double QlHVbkrnFBZF = 805486.059677279;
    bool whuZToxFTRFlVHz = false;

    for (int ClUxdWqSMyW = 2091625444; ClUxdWqSMyW > 0; ClUxdWqSMyW--) {
        JxchrQX = fdOODWWGmMrDD;
    }

    if (UyOCQArdFeqDr <= 1396203736) {
        for (int amPphVKRDQ = 478125111; amPphVKRDQ > 0; amPphVKRDQ--) {
            continue;
        }
    }

    if (qoqZsIiNMQPjal <= 1396203736) {
        for (int aSkTR = 695768468; aSkTR > 0; aSkTR--) {
            JxchrQX = JxchrQX;
        }
    }

    if (dxBBtndPvhh >= 805486.059677279) {
        for (int scTaJmqwU = 1877234179; scTaJmqwU > 0; scTaJmqwU--) {
            UyOCQArdFeqDr += nKVEVQDImJnUxmE;
            QlHVbkrnFBZF -= QlHVbkrnFBZF;
            fdOODWWGmMrDD = ! tovps;
            whuZToxFTRFlVHz = ! lGUxCTlfXun;
            lGUxCTlfXun = ! JxchrQX;
        }
    }

    if (uZPmEBylhbuWwRZ > string("lxuZWCKAUQMfpJIHezCMjUEhNZryUbTfQPFicYBwrWdJTYftzfXk")) {
        for (int dlXCkenz = 1615150877; dlXCkenz > 0; dlXCkenz--) {
            JxchrQX = ! JxchrQX;
        }
    }

    return qoqZsIiNMQPjal;
}

string ToBaLKIBqNmisK::jeMgwPnRbVptZDQ()
{
    string VAAHkuyqnTAR = string("pUSWWyzeWWnhAyIxYVCrJXvNpeqWZkKOxjzykCFpNIVnTGHibGLWWxvZimSyGkSmUFtKPyzpFHqtrDOtfJQZr");

    if (VAAHkuyqnTAR <= string("pUSWWyzeWWnhAyIxYVCrJXvNpeqWZkKOxjzykCFpNIVnTGHibGLWWxvZimSyGkSmUFtKPyzpFHqtrDOtfJQZr")) {
        for (int SSKLaHI = 49508161; SSKLaHI > 0; SSKLaHI--) {
            VAAHkuyqnTAR += VAAHkuyqnTAR;
            VAAHkuyqnTAR = VAAHkuyqnTAR;
            VAAHkuyqnTAR += VAAHkuyqnTAR;
        }
    }

    if (VAAHkuyqnTAR >= string("pUSWWyzeWWnhAyIxYVCrJXvNpeqWZkKOxjzykCFpNIVnTGHibGLWWxvZimSyGkSmUFtKPyzpFHqtrDOtfJQZr")) {
        for (int BYbmQVHmipfS = 850183970; BYbmQVHmipfS > 0; BYbmQVHmipfS--) {
            VAAHkuyqnTAR = VAAHkuyqnTAR;
            VAAHkuyqnTAR += VAAHkuyqnTAR;
            VAAHkuyqnTAR += VAAHkuyqnTAR;
            VAAHkuyqnTAR = VAAHkuyqnTAR;
            VAAHkuyqnTAR = VAAHkuyqnTAR;
            VAAHkuyqnTAR = VAAHkuyqnTAR;
            VAAHkuyqnTAR = VAAHkuyqnTAR;
            VAAHkuyqnTAR = VAAHkuyqnTAR;
        }
    }

    if (VAAHkuyqnTAR < string("pUSWWyzeWWnhAyIxYVCrJXvNpeqWZkKOxjzykCFpNIVnTGHibGLWWxvZimSyGkSmUFtKPyzpFHqtrDOtfJQZr")) {
        for (int QXrDJUI = 722998245; QXrDJUI > 0; QXrDJUI--) {
            VAAHkuyqnTAR = VAAHkuyqnTAR;
        }
    }

    return VAAHkuyqnTAR;
}

int ToBaLKIBqNmisK::ACPcVVKF(string whbnoqclF, int udNHfBhUb, string jOeXzBXYZUvQAY, string IdbWFXa)
{
    int aHDNSvAtXEQ = 924577810;
    bool uLMBsxnWN = false;
    double ifHxVcJ = 268019.3511504799;
    int QDVzGvdJ = 1232679245;
    bool lNbzTjKtuiuNZL = false;
    double jEPHfkaY = 369714.4838523818;
    double wQrOhQWQemg = 542897.8960666957;
    bool rHmUgEnHAk = true;

    for (int HbsPXWAhJHqHRBY = 399685307; HbsPXWAhJHqHRBY > 0; HbsPXWAhJHqHRBY--) {
        aHDNSvAtXEQ *= udNHfBhUb;
        jOeXzBXYZUvQAY += IdbWFXa;
    }

    for (int EjzPytinF = 2084760468; EjzPytinF > 0; EjzPytinF--) {
        continue;
    }

    return QDVzGvdJ;
}

string ToBaLKIBqNmisK::mOXmwDilJ(bool eNwIjc, int ebJjMboV, double bpIkAyjCVoTeM, bool EUJxAYZytlXeR, double ylukcFJbmFkUgsAq)
{
    string FpYHtUCjFrwgbrg = string("jupxtFFqjPFSWtgGUXFXEBUJSOfXtIxiFuAhnklflFHbNMbsQKDcpUhEXchGaupqVIKziQyIvKiN");
    bool ySBQK = true;
    string hwsRwBQXVKuUpXO = string("rvdfhVXkNPmGIhYobjloracpDuJDGzzjtJSxxRsPkhwGYAWJEoksxevyRpjXWkYAdiCicIQCKFlooaxcfBmdsqZwWVTfQCOEXxAlpDNBElpRRADUdQefRmVLwNaoHwFynQxIDmohoWBKgZJeHloewUSbpxtWKFYGSzPBUaMGyLbiCJtqDqppytbsukIuMJMyBbjxshlZTieKTOgBxhaouCXDSqEzOvtzvlzVqwzcGDqiaRCyt");

    if (FpYHtUCjFrwgbrg != string("jupxtFFqjPFSWtgGUXFXEBUJSOfXtIxiFuAhnklflFHbNMbsQKDcpUhEXchGaupqVIKziQyIvKiN")) {
        for (int uJWeIThjKVlSvF = 702191363; uJWeIThjKVlSvF > 0; uJWeIThjKVlSvF--) {
            continue;
        }
    }

    for (int ZsbEIPJ = 504150550; ZsbEIPJ > 0; ZsbEIPJ--) {
        ylukcFJbmFkUgsAq -= ylukcFJbmFkUgsAq;
    }

    return hwsRwBQXVKuUpXO;
}

ToBaLKIBqNmisK::ToBaLKIBqNmisK()
{
    this->hXITMgmf(string("oCzEYaEyDMnYwCEcEgfvXqGrrvJoipwquQRaNrRqgYpccjPNIStCNmIOdpeRaQevjNvVOrjLaKbakHMLuhNLBFwMtwDTByWhbKDrouxAJADOeAVXyUuHnSMlvoByGfUvpxspMRoruAcTAhFvILakoZzZYftEQccvUcTFLWxyUaHCzwoAWESwXkFYdIFjuSrEpqqQGSxJTHN"));
    this->dhhVirODMgS(true, 1396203736);
    this->jeMgwPnRbVptZDQ();
    this->ACPcVVKF(string("ImzWDbmaKbeVpeianZcvbAqDFdsaCxPmFzgHANfnwEEACQjftHGYxdOdFwhZilBWOAvNHcaemSEQLbBvjOSTHJKWZRyWPoFZpUqdUNlSTPdZjCGlnGOzMFMOxuzAWaNKZHTMkLnZKZRFfetfkWPutieDojOZzDNwVlajnIUmRZBuzAuyJkXXDzniNJdSBnTDAuIuyzFzUyiXoCtPLljBpxibWIrLFUyDVelqLWPrkPRdSoMfq"), -447748754, string("LSiUKeqnb"), string("FJpiMPCCDGWsNiFkqsftHKkQtaGmngdjQRidOpsIBmCQBMFUUEUjxLgIQwiNBPTapeoxsBkzDbZV"));
    this->mOXmwDilJ(true, -495778191, 389127.3866069962, false, 572958.5566400418);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SWPVLZGAvZ
{
public:
    string CULzvHx;
    double BqQmWkwgnWh;
    string uIoApBHwiZtv;
    double PjFttano;
    string oZGWUS;

    SWPVLZGAvZ();
protected:
    double OHDMkVcgL;
    double TZTGOBR;
    bool SwEfSUI;
    string XSXOffVm;
    bool OLMCQ;

    bool JUXgNpTzmzpKDOMa();
    bool NpxHPlnwo();
    int NvIvKuYnxaSAQl(double PYWqgZy, string HhTYgEYoXuJIp);
    double SmDRCDYy(double qmLlarrmZAjn);
    string Hsibv(double bmWNZMstc, bool pWOnwusj, string RVBbKpGgWxduFbR);
    bool KOxUHU(string jtdKGGDRMgvTf, double XNmYptZtbMcQaT);
    string bNPujABhZjyCF(bool GmJXKgtAW);
    double fuiudjsQTvH(int cHfPNYPrapLbn, bool BBpqWu, bool syohuvXcmboFQiM, string sLcOPdjljx, bool fdBPAsAWTw);
private:
    bool SzphJ;
    string KxiARmSYOQ;
    double lxkJBzbPmtOBe;
    double sQYgX;
    string HyfdUnkefMRHuW;
    string AJsMrOt;

    int mOmOwxoGXhPBTzwI(int NxKXaTABolgUWLc, bool RedAbkvBV, bool zGQbxvqxNQUp);
    int QLSZbpAVqAMiZN(string iEcmsMvioe, double qmPoEprMuwUrtiH, bool klYoOuJd);
};

bool SWPVLZGAvZ::JUXgNpTzmzpKDOMa()
{
    double EMyHjdn = 519089.67395080184;
    bool AjkYcyXeoeSlLWq = false;
    int vJbHyJuBjqtHvMEU = 996018512;
    bool vcltPDWhg = false;

    for (int hYXbDEWQzONTnwv = 1227620568; hYXbDEWQzONTnwv > 0; hYXbDEWQzONTnwv--) {
        EMyHjdn *= EMyHjdn;
        AjkYcyXeoeSlLWq = ! AjkYcyXeoeSlLWq;
    }

    if (vcltPDWhg == false) {
        for (int YrgrQY = 1491051014; YrgrQY > 0; YrgrQY--) {
            AjkYcyXeoeSlLWq = vcltPDWhg;
            vcltPDWhg = ! vcltPDWhg;
            vcltPDWhg = ! AjkYcyXeoeSlLWq;
            vJbHyJuBjqtHvMEU = vJbHyJuBjqtHvMEU;
        }
    }

    for (int ZVwtQXKXvYCRdHeH = 1378603396; ZVwtQXKXvYCRdHeH > 0; ZVwtQXKXvYCRdHeH--) {
        vcltPDWhg = AjkYcyXeoeSlLWq;
    }

    for (int LufbAdNXojhiAc = 293291539; LufbAdNXojhiAc > 0; LufbAdNXojhiAc--) {
        vJbHyJuBjqtHvMEU += vJbHyJuBjqtHvMEU;
        vJbHyJuBjqtHvMEU /= vJbHyJuBjqtHvMEU;
    }

    return vcltPDWhg;
}

bool SWPVLZGAvZ::NpxHPlnwo()
{
    double cWTFyPnJNFIv = 349706.23260123766;
    string piFkFg = string("deQTSoEsWCdNmJKFFJmDxCdlEMfNawNZoIwaYFgHXyHsadwZjQnMaf");
    double qXQHHhU = 546061.9437511689;
    int VxLod = 649567078;
    double XVpVLv = 962011.5540557249;
    int hljvxFEdLnatJ = -788167391;
    string ibSfg = string("ltLQJnjMAMmOINecOYGVUzPHijDoprlKczwgVrsOxfbOBxkQARmFuCdIyuTPmVaAaQRhfBtyLx");
    bool YPlJcj = true;
    bool PcIdevLiGc = false;
    double PecQgNbkGbcGwV = 908956.1357701501;

    for (int qNhzToioMKvCap = 1579793878; qNhzToioMKvCap > 0; qNhzToioMKvCap--) {
        PecQgNbkGbcGwV -= cWTFyPnJNFIv;
        PcIdevLiGc = ! YPlJcj;
        PcIdevLiGc = PcIdevLiGc;
    }

    if (XVpVLv == 908956.1357701501) {
        for (int RqUzt = 54871402; RqUzt > 0; RqUzt--) {
            ibSfg += ibSfg;
            YPlJcj = ! PcIdevLiGc;
            XVpVLv *= cWTFyPnJNFIv;
            qXQHHhU -= cWTFyPnJNFIv;
        }
    }

    for (int PEGGcgYiYRfFYt = 1038719608; PEGGcgYiYRfFYt > 0; PEGGcgYiYRfFYt--) {
        ibSfg = piFkFg;
    }

    for (int lkBOIWPQuNloUj = 420547298; lkBOIWPQuNloUj > 0; lkBOIWPQuNloUj--) {
        PecQgNbkGbcGwV += PecQgNbkGbcGwV;
        VxLod *= VxLod;
    }

    return PcIdevLiGc;
}

int SWPVLZGAvZ::NvIvKuYnxaSAQl(double PYWqgZy, string HhTYgEYoXuJIp)
{
    double TnpTDbpaOXgIGCc = 62440.31610105252;

    for (int kSTDWfUMGbx = 693039380; kSTDWfUMGbx > 0; kSTDWfUMGbx--) {
        TnpTDbpaOXgIGCc *= TnpTDbpaOXgIGCc;
    }

    if (HhTYgEYoXuJIp < string("IeDLHnKArjAkDCXbqqbLGyxNGDkVBkPknGJxubfHsSvsDPpokLgaMsKmuvImlosfhyBtTUVlNZwKpXJZNTxwieRnbRPYzhMEGbnGlMBDxdAVognDSTXwaljjmHkcRnfteElbzCXIkspPWYSGlAOBsWtOFzWbVwq")) {
        for (int FkLYGTrmAHf = 1565226456; FkLYGTrmAHf > 0; FkLYGTrmAHf--) {
            PYWqgZy += PYWqgZy;
            TnpTDbpaOXgIGCc *= PYWqgZy;
            PYWqgZy *= PYWqgZy;
            TnpTDbpaOXgIGCc -= TnpTDbpaOXgIGCc;
            TnpTDbpaOXgIGCc *= TnpTDbpaOXgIGCc;
        }
    }

    if (PYWqgZy != 62440.31610105252) {
        for (int TOQngTlIzpuNjEjZ = 620764857; TOQngTlIzpuNjEjZ > 0; TOQngTlIzpuNjEjZ--) {
            continue;
        }
    }

    if (PYWqgZy != 62440.31610105252) {
        for (int ncRGYEjGeC = 94111874; ncRGYEjGeC > 0; ncRGYEjGeC--) {
            PYWqgZy += TnpTDbpaOXgIGCc;
            TnpTDbpaOXgIGCc /= PYWqgZy;
            TnpTDbpaOXgIGCc += PYWqgZy;
        }
    }

    if (TnpTDbpaOXgIGCc > 62440.31610105252) {
        for (int tmXeXruSXqJ = 1404207480; tmXeXruSXqJ > 0; tmXeXruSXqJ--) {
            continue;
        }
    }

    return 1768479134;
}

double SWPVLZGAvZ::SmDRCDYy(double qmLlarrmZAjn)
{
    string tlcMJTsTZWtMN = string("dvctUGSoIpiMedAWjmMYJcVozbgxFKrFdtUqLUDHNnRXftGlLyVgZFmjXwqvcmlXImrjlkNestSqxnkWZxqdiQcqhOqCRKYNJNTCciZngYXEUJeuBGfgroYOzvBJwXZRkNGRKnbpJNkpGisQjtuMaymAqNBCBWCSBOTQgWzUkwuFPYxbffAyYTLLGTflrkFvSMdYxOOOvmkPpiMgpyxOhOZgQjJVeUHEHygywUrNAAMuUxIcMs");
    int jgyRDpSfvOALIipx = 1525628949;
    int EAkddEVJ = -858066005;
    bool HwqTcMIjG = false;
    int NdOjhHw = 109703682;
    string xgBfOhJaaxDZ = string("xML");
    double cPbDsLJJRMup = 909424.8563090402;

    return cPbDsLJJRMup;
}

string SWPVLZGAvZ::Hsibv(double bmWNZMstc, bool pWOnwusj, string RVBbKpGgWxduFbR)
{
    int SNUDmTg = 1957950544;
    int aoWyPmjU = -1369280346;
    bool ULmmgzvhWRdZhVHx = false;
    string TdclVNYj = string("krpKwwTjpIegZnloAYQUskCyvYSCocXuzverWlOjxGHMHHYWGRQayCpweEXFpidaznOLoxfDwXNjWtCxKXDtRhZAlZgTtwPRUnvLhxbUbvdbxQrpnwAUvCiAUOuLslmQDsrmuINjFtlTwmoaEemIvsWCwEkUgIyPvKwoKLHLUnoQwxgTJZkkCKqIZEfoHcEfagCslcVEsARkTFlLsAyukFGDMQCchGTsAtuuyalpQWpNItqnc");
    bool RnYdkvSRHX = true;
    int jpTgSNSdQtRpngbh = -1552091557;
    int ITsRTikImdloj = 881083845;

    return TdclVNYj;
}

bool SWPVLZGAvZ::KOxUHU(string jtdKGGDRMgvTf, double XNmYptZtbMcQaT)
{
    string DfBrUrTisUL = string("PnwUJJsbMBtzsgnbqBeWJMmkMMTXZWMCHCoNrAGikrJhYlz");
    double jViqNCBcN = 388537.3151264575;
    double kBQaoFzX = 127528.08218090238;
    bool MDZfClNYTERjGhmp = true;
    bool XmLkhCCFlmO = true;

    if (jtdKGGDRMgvTf >= string("LEsZMtccahnKQBjvvfNKpZEjnIovNZYiPLRmVPpuWIvkEXBLaGPrrGZHakphjHFMjNBgwandFrWpfhhsAwiAOuunnETFQNaTXTccMBGHijRdZIQRyJpxhRfoFXrDnASWYcnrgLDaRqvCcGDvVWAVKTJpOpihRVTMMocvjGWHnYRPgdqLjhGYxsNYJbdcdMBIkYJPAjzeaTZgfWtbWXPczRAYEsPG")) {
        for (int DvYZPEChTcLx = 795244530; DvYZPEChTcLx > 0; DvYZPEChTcLx--) {
            jtdKGGDRMgvTf += DfBrUrTisUL;
            kBQaoFzX /= XNmYptZtbMcQaT;
        }
    }

    for (int ngjjzTgIVrv = 1571807742; ngjjzTgIVrv > 0; ngjjzTgIVrv--) {
        jtdKGGDRMgvTf = jtdKGGDRMgvTf;
        DfBrUrTisUL += DfBrUrTisUL;
    }

    if (kBQaoFzX <= 127528.08218090238) {
        for (int CIRnOMwLR = 1923585496; CIRnOMwLR > 0; CIRnOMwLR--) {
            kBQaoFzX = XNmYptZtbMcQaT;
        }
    }

    return XmLkhCCFlmO;
}

string SWPVLZGAvZ::bNPujABhZjyCF(bool GmJXKgtAW)
{
    int oolBqAOjzC = -888126316;
    double LmjQcut = 177090.3179505904;
    double eEQYeO = 566563.0523010278;
    int fAtYDyXte = 285457925;
    double LWsPL = -906686.4316595262;
    int gfBjtJkI = 67914463;

    return string("WmWUprycvTcHTFHNaArfETokmVulBjaPHMQrUqPHoatFMiiPjGIDNrckHeIbqzOCSqSvLVkXZJlLJgSjmafYQQtVYRnuQBvOccSZxQJgizxjVGorfKbEGlMoBiDVyKdUZmNKuGDHWLpPRhctNkZpNbihYAoIyrQRpbryqpKTvGDOuydZHshAdnQUKQGzLLxwZFMOqNOutzGAqvTtcFEs");
}

double SWPVLZGAvZ::fuiudjsQTvH(int cHfPNYPrapLbn, bool BBpqWu, bool syohuvXcmboFQiM, string sLcOPdjljx, bool fdBPAsAWTw)
{
    int FDSebFImngmsHuR = 570697006;
    string IpeqmnEoSCQhNq = string("AmEyiMRTbPdEbjkEooHrhTEDCKVFrtJaIPWDDOIpJhhhkqoHQrlTJhGrJdEGGRBQjvxLSuIqcDoFLBDcVezYZsPiyiWZfTZJfeyKQskVKSgwTIEVVZRQxoulzICmUrbovRuVMSyQOAFhpHFYmkeMMKOKlPUwUNDiLkjBIzzKtXPu");
    double omtBKMrysY = 400820.87271453027;
    double uOGiwhyJqqzPLWy = -969299.688851551;
    double TgWEnabjZwrRjjTw = -1045244.392408564;
    bool ATQmp = true;
    bool VvAcZjwF = true;
    bool JKexsjjCkjfP = true;
    bool KORtEnaQHoLj = false;

    for (int yTJubka = 2005051071; yTJubka > 0; yTJubka--) {
        ATQmp = syohuvXcmboFQiM;
        VvAcZjwF = JKexsjjCkjfP;
        FDSebFImngmsHuR += cHfPNYPrapLbn;
        ATQmp = ! VvAcZjwF;
    }

    if (syohuvXcmboFQiM == true) {
        for (int aaEuEnZkCnQGaJms = 1709840898; aaEuEnZkCnQGaJms > 0; aaEuEnZkCnQGaJms--) {
            IpeqmnEoSCQhNq += IpeqmnEoSCQhNq;
            omtBKMrysY = omtBKMrysY;
        }
    }

    return TgWEnabjZwrRjjTw;
}

int SWPVLZGAvZ::mOmOwxoGXhPBTzwI(int NxKXaTABolgUWLc, bool RedAbkvBV, bool zGQbxvqxNQUp)
{
    string bnmNOB = string("oIqTpgrkjAYnXginsIMfBnauqoIjgHyrldZsaowQNbCrjamHVFxHRrPRcfIakPSXkbYZyYFrapQQmaZOADEMjfTxOKTbKDfCPLsfIUkAaCkMnXUxQNKYIAnJOtCoRCZDZYjlzFXUgPBgDqB");
    int qDakgHYPnuBTegcU = 2113226863;
    bool sFiEIC = true;
    string WiXoZedWegpONZH = string("ZRILBbkOObtkwkzDwsouoAccmJtexaDTAtdcHbeScWisM");
    string jszyxTfxndtrI = string("wnhtbmuvMxidRlomfytVNLipetwDvFZBzjlnlxJrFdRAhGAozTOpYHByMASJkDqSAhfLfvFtkuTWsIiShTbnqkpYtoPSxhnNkMCyaDrtkrdBDgiJCVxcxQkbfyEovpsv");

    for (int HwUqxjvJieoiHpIy = 757324647; HwUqxjvJieoiHpIy > 0; HwUqxjvJieoiHpIy--) {
        WiXoZedWegpONZH = jszyxTfxndtrI;
        zGQbxvqxNQUp = ! RedAbkvBV;
    }

    return qDakgHYPnuBTegcU;
}

int SWPVLZGAvZ::QLSZbpAVqAMiZN(string iEcmsMvioe, double qmPoEprMuwUrtiH, bool klYoOuJd)
{
    string hWePygYkLuVt = string("TEfdYZDBpZgoSNEvNOmpDWKWhCRcahdCTJWmmVivyWnOjaJYYUkNJkHMIdSqNWMSXUikOYqgRIktSsYxBNxTGgBHHVirlLUgoGxdCpHldyljYXZkLmAiPfsFKdGNCcfPsocskUbLxnnrkMtvkWrNepdjbWrHUABEGFits");
    int aEHLzMpbTTuZf = 1268642324;

    if (hWePygYkLuVt >= string("UyXtHslGCyTkVuKFfbaXVCWMHtPkBZtWoYvVHgXStOwViBLSwtAjAjIXGZVMKlFCGGfYYvcgtdwhyhfpaQQBcVIXNiacsexFbEqLfzDKAczTDIBvroOlnGzncoWHRcNqLBJnVgqXlqpZicTiipSwekxuN")) {
        for (int rAaPrWHjZS = 956576259; rAaPrWHjZS > 0; rAaPrWHjZS--) {
            qmPoEprMuwUrtiH -= qmPoEprMuwUrtiH;
            iEcmsMvioe = iEcmsMvioe;
            qmPoEprMuwUrtiH += qmPoEprMuwUrtiH;
            klYoOuJd = ! klYoOuJd;
            hWePygYkLuVt += hWePygYkLuVt;
        }
    }

    for (int JXzyJBoX = 798492458; JXzyJBoX > 0; JXzyJBoX--) {
        hWePygYkLuVt += hWePygYkLuVt;
    }

    if (hWePygYkLuVt <= string("UyXtHslGCyTkVuKFfbaXVCWMHtPkBZtWoYvVHgXStOwViBLSwtAjAjIXGZVMKlFCGGfYYvcgtdwhyhfpaQQBcVIXNiacsexFbEqLfzDKAczTDIBvroOlnGzncoWHRcNqLBJnVgqXlqpZicTiipSwekxuN")) {
        for (int bPrxWuYwaQ = 244871108; bPrxWuYwaQ > 0; bPrxWuYwaQ--) {
            continue;
        }
    }

    for (int FtVHIoedNFnTFSOf = 534141759; FtVHIoedNFnTFSOf > 0; FtVHIoedNFnTFSOf--) {
        aEHLzMpbTTuZf /= aEHLzMpbTTuZf;
        iEcmsMvioe += hWePygYkLuVt;
        hWePygYkLuVt += iEcmsMvioe;
    }

    for (int iXaJcgargUFxg = 490001028; iXaJcgargUFxg > 0; iXaJcgargUFxg--) {
        aEHLzMpbTTuZf += aEHLzMpbTTuZf;
        aEHLzMpbTTuZf -= aEHLzMpbTTuZf;
        hWePygYkLuVt += hWePygYkLuVt;
        hWePygYkLuVt += hWePygYkLuVt;
    }

    return aEHLzMpbTTuZf;
}

SWPVLZGAvZ::SWPVLZGAvZ()
{
    this->JUXgNpTzmzpKDOMa();
    this->NpxHPlnwo();
    this->NvIvKuYnxaSAQl(477767.5946328303, string("IeDLHnKArjAkDCXbqqbLGyxNGDkVBkPknGJxubfHsSvsDPpokLgaMsKmuvImlosfhyBtTUVlNZwKpXJZNTxwieRnbRPYzhMEGbnGlMBDxdAVognDSTXwaljjmHkcRnfteElbzCXIkspPWYSGlAOBsWtOFzWbVwq"));
    this->SmDRCDYy(951832.7740408084);
    this->Hsibv(995574.811429832, true, string("zVHPxMqqViclnPXcmaIPyrKRQqBDrtVRwvmBhwIhMgYIFesvfsNqCkSlAbXPHkBSByoWDCPpqqETmcIlHPNAatjCfFveuayKjAQfnCLYPNUinBVFPBMcrHNClvhradIcvDsPMdfzyzFHufYoAGtrlPFaOPDeIFgGoOCFJ"));
    this->KOxUHU(string("LEsZMtccahnKQBjvvfNKpZEjnIovNZYiPLRmVPpuWIvkEXBLaGPrrGZHakphjHFMjNBgwandFrWpfhhsAwiAOuunnETFQNaTXTccMBGHijRdZIQRyJpxhRfoFXrDnASWYcnrgLDaRqvCcGDvVWAVKTJpOpihRVTMMocvjGWHnYRPgdqLjhGYxsNYJbdcdMBIkYJPAjzeaTZgfWtbWXPczRAYEsPG"), 436152.07492200023);
    this->bNPujABhZjyCF(true);
    this->fuiudjsQTvH(1070336118, true, false, string("ENlhBRTfhQjDHhIPkaBNhKsscxjWFGYFUELVYODiwVzmIWaqpLNIbSOxgWPvTZKbbTYQEMhlJJtnKhgNYxucgqZSZorwHtesFTBaRPxxuYMApXzwZYulKhyFAGDuaXkSkFGoOGRfyAFcGpuzguyblwlpHaUGhrI"), false);
    this->mOmOwxoGXhPBTzwI(-526753562, true, false);
    this->QLSZbpAVqAMiZN(string("UyXtHslGCyTkVuKFfbaXVCWMHtPkBZtWoYvVHgXStOwViBLSwtAjAjIXGZVMKlFCGGfYYvcgtdwhyhfpaQQBcVIXNiacsexFbEqLfzDKAczTDIBvroOlnGzncoWHRcNqLBJnVgqXlqpZicTiipSwekxuN"), -1040468.9952638595, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FtVAbQwDqui
{
public:
    bool MYhOuNpGTy;
    bool DjkHrFdmNER;
    bool dNycFXJAts;
    string MEfGeul;

    FtVAbQwDqui();
    void GRGgzQzfDZGD();
    bool MqPlh(string qRzfJzgCyJwgBpbl, string kQVxBZClIm, bool hUsVQBAWZHg);
protected:
    double VbFAHRQUY;
    int xhzHyqeauz;
    bool KcocEqmfaVLsZz;
    string rYZxspa;

    bool ZqBqNGQMFsykXuhs(double ChAzevzyR, double wifrCdSP, double lqMNip);
    void vxbEhUkOYBEacxjD(string uHtsnTMdNYOywj);
    double KwJaDytx(bool ciQFe, string gBnUEZIwHrIhDGV);
    string NrtRvmgLF(double IkdAddaWucvgMLh, string LgaDefrB, string tQsArrVjWqTNdDu, double BhBXFigeWr, double pKxRk);
    string sLXTFIVgSqO();
    double tLXrfx(string qcrLR, bool xtgVer, bool xVPXtAViTEIv, bool fFgnt);
    int ISuQdDtlwt(bool aOVunJwcwhACb, bool SvsORZkvP, bool hSxGAkUlOKtUxaCP);
private:
    double gpgbAXydudWR;
    double jNCVEowhTX;
    double ZwoyKqRCvPBTDFC;
    int dSsuAEYvbEVQcA;

    string AdUeKeGeOQNLYFtt();
    void HwjjEeSr(double cKIbZnYCMkpvKPl, bool qdJswybcpboWuW, int MhCUXzfgh, int HotsedpfHx);
    int YaDQvUITc();
    string BuiVTT(int FISvV);
};

void FtVAbQwDqui::GRGgzQzfDZGD()
{
    string ceSvsJPzUFsYNbEB = string("GVjZSEozgMYMmHYMTtqdqTIoPuAlFXOHrEOdDelZXTziZikpjEEiovlgAdxmnHVnwSpTyDiIfBFOnNaTWuFXAzIlJJAGJhN");
    double eGUqIl = -799752.1319509577;
    string eaxRTyxSA = string("kWExzBcxybevbLzpnfzQieGbALeJogwnbEYVmXQVhLtwqQxbtQUiVBuTpBrlWZTIJYmkjfjGrTxuFOxLEZAsQtZzdRjulaqfs");
    double phWThhoAPChRj = 3250.131358300232;

    if (ceSvsJPzUFsYNbEB >= string("kWExzBcxybevbLzpnfzQieGbALeJogwnbEYVmXQVhLtwqQxbtQUiVBuTpBrlWZTIJYmkjfjGrTxuFOxLEZAsQtZzdRjulaqfs")) {
        for (int pSEbXkNwYbXfXM = 1114026361; pSEbXkNwYbXfXM > 0; pSEbXkNwYbXfXM--) {
            phWThhoAPChRj += phWThhoAPChRj;
            phWThhoAPChRj /= eGUqIl;
            phWThhoAPChRj += eGUqIl;
            eaxRTyxSA = ceSvsJPzUFsYNbEB;
            eGUqIl += phWThhoAPChRj;
        }
    }

    if (eaxRTyxSA <= string("kWExzBcxybevbLzpnfzQieGbALeJogwnbEYVmXQVhLtwqQxbtQUiVBuTpBrlWZTIJYmkjfjGrTxuFOxLEZAsQtZzdRjulaqfs")) {
        for (int zUZhMaQrDDPtdl = 1867317966; zUZhMaQrDDPtdl > 0; zUZhMaQrDDPtdl--) {
            phWThhoAPChRj /= phWThhoAPChRj;
            ceSvsJPzUFsYNbEB = ceSvsJPzUFsYNbEB;
            eGUqIl -= eGUqIl;
        }
    }

    for (int KafCQA = 143034624; KafCQA > 0; KafCQA--) {
        continue;
    }

    for (int vuWmT = 1939254436; vuWmT > 0; vuWmT--) {
        ceSvsJPzUFsYNbEB += ceSvsJPzUFsYNbEB;
        phWThhoAPChRj += phWThhoAPChRj;
    }
}

bool FtVAbQwDqui::MqPlh(string qRzfJzgCyJwgBpbl, string kQVxBZClIm, bool hUsVQBAWZHg)
{
    double xjOZNWSoEGV = -518057.47545243247;
    string PmYjBlNEvQXN = string("bvXHPirTf");
    double NtRwNrDvHfW = -1042756.0415255264;
    double DkZfXsxIiVv = 51936.092760768894;
    int kKrQZMFOKVwB = 1288741028;
    double vIeJPOHjslD = 566006.9850502127;
    int DUtFE = 1562260183;
    double hDVhKlINvb = -829380.9419800838;
    string LdzxGeqWEwkHi = string("yiBdsvXhfvzfCRYlsyygEyddTkmGIUPRgLQxGMruBAQDEFhHVSgFsDGHbiCChZqyCtyQzqVRSExsfuK");

    for (int uOsxPeqlUf = 1984787604; uOsxPeqlUf > 0; uOsxPeqlUf--) {
        DkZfXsxIiVv -= vIeJPOHjslD;
        NtRwNrDvHfW *= hDVhKlINvb;
    }

    return hUsVQBAWZHg;
}

bool FtVAbQwDqui::ZqBqNGQMFsykXuhs(double ChAzevzyR, double wifrCdSP, double lqMNip)
{
    string bQkAseDFPjzpA = string("nbEPZZgkCKyrJFYoVbSSIcXaVjVfXCOisZdPqnzYqioEKkAFZjOxiSdgkHmxZLagJjJyPCVKrVqHxdvJJapuUdZOUDRDBfzLBCmMvvoFoLQBzsJyXZICqBzlMxLEGRcQzmIdwmjjUTuijKPVXBeAMlQOiNEDEVglhjKIkcABRdclQZRtrHvHo");
    double fCCqO = -1009992.8075529333;

    for (int AzpGWWH = 1465951159; AzpGWWH > 0; AzpGWWH--) {
        fCCqO *= wifrCdSP;
        wifrCdSP /= ChAzevzyR;
        lqMNip -= lqMNip;
    }

    if (fCCqO > 748693.0302862948) {
        for (int YMWCn = 1513122469; YMWCn > 0; YMWCn--) {
            lqMNip += ChAzevzyR;
            wifrCdSP -= fCCqO;
            fCCqO = wifrCdSP;
            wifrCdSP -= lqMNip;
            lqMNip -= wifrCdSP;
            ChAzevzyR /= lqMNip;
        }
    }

    for (int vcDiJ = 681591687; vcDiJ > 0; vcDiJ--) {
        bQkAseDFPjzpA = bQkAseDFPjzpA;
        wifrCdSP -= lqMNip;
        lqMNip *= wifrCdSP;
    }

    if (ChAzevzyR != -752240.5808582169) {
        for (int AAiMwOXajp = 733053847; AAiMwOXajp > 0; AAiMwOXajp--) {
            lqMNip *= fCCqO;
            wifrCdSP -= ChAzevzyR;
        }
    }

    return false;
}

void FtVAbQwDqui::vxbEhUkOYBEacxjD(string uHtsnTMdNYOywj)
{
    string hJmtKODKzf = string("xsTgAztZqvjuEhkffaGDPhmdedJiuINsS");
    int DCuAcYTr = -1268297218;
    string PCldb = string("ujrEppEwCIuntokNjVOiETRYhGnhtgZHZAjFLkaCwmZYOCZQDtBRQZRmCoflIYqUWMWlPOujbkWqzYztLL");
    bool TmRqDbDujRq = false;
    bool aykRAmLgu = true;
    bool BkWkFNl = true;

    for (int fnuIXxArCr = 1252923771; fnuIXxArCr > 0; fnuIXxArCr--) {
        DCuAcYTr *= DCuAcYTr;
    }

    for (int ftJRBicnTzNDa = 2027002657; ftJRBicnTzNDa > 0; ftJRBicnTzNDa--) {
        TmRqDbDujRq = aykRAmLgu;
        uHtsnTMdNYOywj = PCldb;
    }

    for (int KWbdDywCWcC = 7112702; KWbdDywCWcC > 0; KWbdDywCWcC--) {
        PCldb += PCldb;
        TmRqDbDujRq = BkWkFNl;
    }
}

double FtVAbQwDqui::KwJaDytx(bool ciQFe, string gBnUEZIwHrIhDGV)
{
    int VcQPpjjyICJ = -1817869301;
    double RxMJIPdRuZpxH = -236489.17168971914;
    string jVWXqICWYvZUQ = string("AZrxlRkICcLyytjRBQNByYXvPzEALhKdYgxplJIEeceiNLnLtESRaAZjiUOVYvlcWZOKUmOZwJvafTXsZoLLuLtXYgrXMafIUDSZbBzcMtsRjSlXYggVdBTVLdeolZdWxQdnJYfyjoFpGOnwBaFgzcfQBftfXEQeWSfvkLPoruqyswJEFYJmSuyI");
    bool JSpYEI = true;
    double Gppip = 450322.72256195;
    double mvJyIRVPHL = 975618.0794276869;
    int BZwITlYi = -483556534;
    int YPOKcBw = -1936065059;
    int HmgbwVNNKezr = -200144901;

    if (BZwITlYi >= -200144901) {
        for (int qlwAyh = 2054192130; qlwAyh > 0; qlwAyh--) {
            HmgbwVNNKezr = YPOKcBw;
            RxMJIPdRuZpxH -= RxMJIPdRuZpxH;
            YPOKcBw += HmgbwVNNKezr;
            mvJyIRVPHL -= mvJyIRVPHL;
        }
    }

    for (int jeGONga = 1689030161; jeGONga > 0; jeGONga--) {
        continue;
    }

    for (int JsSprRQnjzttFdY = 899465116; JsSprRQnjzttFdY > 0; JsSprRQnjzttFdY--) {
        gBnUEZIwHrIhDGV += jVWXqICWYvZUQ;
    }

    if (HmgbwVNNKezr <= -200144901) {
        for (int QqsioUyfpb = 1003039045; QqsioUyfpb > 0; QqsioUyfpb--) {
            VcQPpjjyICJ /= HmgbwVNNKezr;
            Gppip *= RxMJIPdRuZpxH;
        }
    }

    for (int hslmYdNkwn = 2147321900; hslmYdNkwn > 0; hslmYdNkwn--) {
        mvJyIRVPHL += Gppip;
        ciQFe = ciQFe;
    }

    for (int kpSsMd = 150474347; kpSsMd > 0; kpSsMd--) {
        mvJyIRVPHL /= RxMJIPdRuZpxH;
        YPOKcBw += HmgbwVNNKezr;
    }

    return mvJyIRVPHL;
}

string FtVAbQwDqui::NrtRvmgLF(double IkdAddaWucvgMLh, string LgaDefrB, string tQsArrVjWqTNdDu, double BhBXFigeWr, double pKxRk)
{
    int oLrcCaEKxzKqO = 539154038;
    bool qWtkvjXZfpxVDxQn = true;
    int ewAuXaZ = -51061198;
    string CmEPNrrOYmCV = string("TNbWJNcBbkjSJQazoToDSvCYSpbVPtgAhKBVWMiAcqlcMeiYZivGQtBNcftuXQcqHZQcrfLlAXxHVysSEtGYvjauLWQsfzFjudBDnDExKXkknddDJmPSgSEzIyNmbMeGxtBzqqHMsrrCLcroLbhTbvnhOvaYrWjhdEFiSxzPGqEDJjVKcooHxCAOHFJrpzJjfFkRaNcaoDNpbqHGbKVf");
    string Shdeiex = string("nmAiYNnnForSfkNNrMQSkOAvvRxCeaNNtwjLLEcumUuhKtVBPYzYzdiBUTYzfMfeLQmsqGBlPLncumcwFNXAEx");
    string ccckcw = string("lobCLOUUTyfAQdENRJeqSHNnqpHPJqZJOdgSlfwSeGrQxeyrJMHgWuBkHKPUOTldRNEgircgEAaxRhediiAFTKBwKczkbhMWfVHNLUXdmZTJFhIfeCzRuuZPBNsdUnrhwpSYPJldjHonJPLrqbmVTnPqSupmJxIEneMoAPvUAZwuJPGrGszZuuXozEizPJmbWQWQJAtKRmNFsYtyXVuqGxSZHVIbRVDBXdb");
    bool PqLyVXggA = false;
    string gemrM = string("NP");

    if (qWtkvjXZfpxVDxQn != true) {
        for (int DlGNlcKhy = 2010480016; DlGNlcKhy > 0; DlGNlcKhy--) {
            BhBXFigeWr -= IkdAddaWucvgMLh;
        }
    }

    for (int WRTqNwddfabVnca = 382152460; WRTqNwddfabVnca > 0; WRTqNwddfabVnca--) {
        tQsArrVjWqTNdDu = tQsArrVjWqTNdDu;
        CmEPNrrOYmCV += CmEPNrrOYmCV;
    }

    for (int rdLSyriqQdzq = 838966905; rdLSyriqQdzq > 0; rdLSyriqQdzq--) {
        ewAuXaZ *= ewAuXaZ;
        IkdAddaWucvgMLh /= IkdAddaWucvgMLh;
    }

    for (int UwggpNGpOcLFGO = 27702916; UwggpNGpOcLFGO > 0; UwggpNGpOcLFGO--) {
        continue;
    }

    return gemrM;
}

string FtVAbQwDqui::sLXTFIVgSqO()
{
    string YGkxWbCJyY = string("ThYjhFMaAMyHcXBlxQFYTxCvfFMJblYaprjFkMHycwnbivtlwCrLuKoGJgGHRIlUaDkGmWNFULupWCUvrRyqlxQyKIwNISlRtrQddfNqghwwaeZLlSMLoegYNwafPahqivIIFHAkceTeLNQSpyfhpeUGwWxIVAzCggnFeqVBDOiTKyQaLsgTXevkpOrZFyMBTCVzuEEwtzxtAkfbBcJKsyvAhiYeMqNJLXwGuNJJyBQCcNfHGBeVlvX");
    int ZXpofSJDeMdkRk = -1687261912;
    string CNTyoPyVlBO = string("LYijDOHXUOzYaLfbPUISjDJiLEZOJLacAJCfXkny");
    double sdsAvGrHwP = -219150.27525100016;

    for (int UfoQOQDqc = 1058710598; UfoQOQDqc > 0; UfoQOQDqc--) {
        sdsAvGrHwP *= sdsAvGrHwP;
        CNTyoPyVlBO += CNTyoPyVlBO;
        sdsAvGrHwP += sdsAvGrHwP;
    }

    for (int zeaaczTfEFZFJIIh = 252484896; zeaaczTfEFZFJIIh > 0; zeaaczTfEFZFJIIh--) {
        sdsAvGrHwP /= sdsAvGrHwP;
    }

    for (int XsgvTUVBdNqB = 990998764; XsgvTUVBdNqB > 0; XsgvTUVBdNqB--) {
        ZXpofSJDeMdkRk /= ZXpofSJDeMdkRk;
        YGkxWbCJyY += CNTyoPyVlBO;
        CNTyoPyVlBO = YGkxWbCJyY;
    }

    if (sdsAvGrHwP == -219150.27525100016) {
        for (int YMINr = 1747413080; YMINr > 0; YMINr--) {
            CNTyoPyVlBO += YGkxWbCJyY;
            CNTyoPyVlBO = YGkxWbCJyY;
            YGkxWbCJyY += CNTyoPyVlBO;
            CNTyoPyVlBO = YGkxWbCJyY;
            CNTyoPyVlBO = CNTyoPyVlBO;
            YGkxWbCJyY = YGkxWbCJyY;
        }
    }

    return CNTyoPyVlBO;
}

double FtVAbQwDqui::tLXrfx(string qcrLR, bool xtgVer, bool xVPXtAViTEIv, bool fFgnt)
{
    int iyigVxVpJJWxv = -508216127;
    bool YRIVWTo = true;
    double sQgxwglej = 909065.9284160304;

    if (xtgVer != true) {
        for (int ITkNaqZK = 1667286886; ITkNaqZK > 0; ITkNaqZK--) {
            iyigVxVpJJWxv = iyigVxVpJJWxv;
            xtgVer = ! YRIVWTo;
            xVPXtAViTEIv = ! YRIVWTo;
        }
    }

    return sQgxwglej;
}

int FtVAbQwDqui::ISuQdDtlwt(bool aOVunJwcwhACb, bool SvsORZkvP, bool hSxGAkUlOKtUxaCP)
{
    double VcFKGhJhxpylAjL = 376687.3630910566;
    bool MTnYFWB = false;
    bool xBQknLuRkKIpmV = true;
    double tbvXX = 657400.5318661928;

    if (aOVunJwcwhACb == true) {
        for (int InFemspvRwLq = 63149144; InFemspvRwLq > 0; InFemspvRwLq--) {
            aOVunJwcwhACb = ! aOVunJwcwhACb;
            VcFKGhJhxpylAjL += VcFKGhJhxpylAjL;
            xBQknLuRkKIpmV = ! SvsORZkvP;
        }
    }

    return 1246163229;
}

string FtVAbQwDqui::AdUeKeGeOQNLYFtt()
{
    string JQEyEl = string("rmCJCHaUrGJapeeLXCuIzqBOrpmemvzBPHQmvIhpqZTcmBOlLCmQlWfkQbPICueztFmJItsEUmzFuS");
    double YsLGnASnBP = -81558.25490955682;
    string dVHafxRJGdWHECEE = string("ckxiBSRUNeWsvOnVhmIHTnzdzwjjtJLCdZdksnaVbssBIppUakOrcrALdIqrhhPkOCtFwPLpLmeTKglamHVlKoQOOZBz");
    bool pakLYXGTpQh = true;
    double sJdZTqGCUa = 167486.4850580677;
    string ZKfpcYbMtb = string("ZlwJERKXuVQGFNpGClVGjPsMYxiMKzoJKuFSEEoxaPcIuBjyRzYaFRZBjKDdzdbSJLynFZzLgVAsewbjNsBgrSatdysUVNluuhBAJIKjxXpxljYbesTatyVQLTlmVrvxyBLbBRfrRszbwFCCiRJI");
    double UkLjP = -333066.4766764994;
    bool gRdeVXM = true;
    int lHffa = 1453164100;

    for (int iHhFDBrsk = 1941560237; iHhFDBrsk > 0; iHhFDBrsk--) {
        JQEyEl = JQEyEl;
    }

    for (int IzXAqWusqEkWzTCW = 388205644; IzXAqWusqEkWzTCW > 0; IzXAqWusqEkWzTCW--) {
        JQEyEl = JQEyEl;
        JQEyEl += ZKfpcYbMtb;
    }

    return ZKfpcYbMtb;
}

void FtVAbQwDqui::HwjjEeSr(double cKIbZnYCMkpvKPl, bool qdJswybcpboWuW, int MhCUXzfgh, int HotsedpfHx)
{
    string vdYWrv = string("WIFMPUkMUwoMbKalxgvLiOuztDpkeacCqAtrIhvmkeHDuzVVmOYSTiQJHEynxZKTurgRhQHQLXknKnZKKwhJqWpxuieULERAdniHFIvYnAFZArLqHCRMTiMJfaYhQMANlzulmlNkGPzYWVmXPfGJtzTrcBaFrUdPhyrvhQUmzyTpBIfwHaGwycaQOwXToYSNldCFOyOuriSodYnxLrlrniFFlKuvdXDUXaIbBNMqFwW");
    int OSCTW = 1375885281;
    int ydQbGAcNe = 984163263;
    string viAGtZyC = string("SasTjpZxcbMnsqKqriFNIqtIojyxOedZWcqrsBhIFgBJOYsHnbEiOSJZqMVAmLtZkshHTTWQFWZDmWcxptUonPlnHCuiZYKhquuaWMafeNYWOABpzZmIQASkGBwAPpYLaTKEyrPFnSp");
    int HtvqC = -132222657;
    bool tCecehpTsie = false;
    string ezXAeNAsalgezL = string("JTmNbmzFzgMImbMIBrnHLZZJSPpfwrjalhagUTccYvZvPZZsATfAkMDbHjolNLqTrQdEieeQPGgqVcsutwaYfuUmPgTxKlqGhahSqAprZnACtYHrpVeIqqaPgdVbIYtnrqgQwfPNqlQODFIBrkWOXsWSesonStwbRSbnJhnZKKbpnUWyKwGDqZnvmNerifVXRgOLCjGNXFKgOZhOCtVHwqtmdmAZfSijQlFaIWrOMfde");
    double jYDvTysl = 414015.07889019256;
    int kmJXlAsDkQjQf = 914202730;

    if (MhCUXzfgh <= 919771148) {
        for (int wxAJvkNwopMDrxQ = 1781007614; wxAJvkNwopMDrxQ > 0; wxAJvkNwopMDrxQ--) {
            MhCUXzfgh -= MhCUXzfgh;
            ezXAeNAsalgezL = viAGtZyC;
        }
    }

    if (ydQbGAcNe < 984163263) {
        for (int MHEBbhiGXvXKW = 1688680520; MHEBbhiGXvXKW > 0; MHEBbhiGXvXKW--) {
            vdYWrv = ezXAeNAsalgezL;
            HotsedpfHx = HotsedpfHx;
        }
    }

    for (int nVBwyhsEeYTEKIx = 369914426; nVBwyhsEeYTEKIx > 0; nVBwyhsEeYTEKIx--) {
        ezXAeNAsalgezL += viAGtZyC;
        OSCTW /= kmJXlAsDkQjQf;
    }

    for (int ggywzveXSdhsEP = 1250044920; ggywzveXSdhsEP > 0; ggywzveXSdhsEP--) {
        kmJXlAsDkQjQf += OSCTW;
        HtvqC /= ydQbGAcNe;
    }

    for (int URIGY = 108712918; URIGY > 0; URIGY--) {
        kmJXlAsDkQjQf *= ydQbGAcNe;
        HotsedpfHx /= HotsedpfHx;
        ydQbGAcNe += ydQbGAcNe;
    }
}

int FtVAbQwDqui::YaDQvUITc()
{
    string pUGfMWDkgbDbs = string("FKbjrnASoafoFmfPncLYkpDuLdrmAPjmktlWipIWkhKansVaODEwhhmGQlhpVrPVrKdTrauSiRmIFawLZoowIPwNPElBibYsvOLdzLYNNPJZxomaPZZtxlpOTPkvFBBNQjJDVlOvPsFYbFeHFOglTVNy");
    int TwjPsKcxXPdVd = -1095788103;
    string IGdYzJkdet = string("GjnMOhiFnEcCNhmaxcHfogqyWqAtOqzYLyWuOZbLUSERwiMgnqvTAqZdqflkxbHntGQKYMMLwhxxfBouyPfKszkoEIuowwHhypbiToUYWiDGlwmgRisVvBgfWRbaTuGGXxKlDfTtudGPeTWTWutWbzvZBtCsmUECuovIuLqBvJPaqvpcveLUTD");
    string pqUHXApSwiGaSa = string("lODwgMWSyGYVvdQbkvmtgRXVJZzZQoKV");
    string ltNcG = string("GYWFODlunBxTflchloFj");
    int nCWwhAbIggwRdURl = -208777184;
    string uZMPPa = string("yBXoemuhGkTwZnEkAlQIJsfsafWlbTdSLdOlCvlOUVJCPQpLsekxmUUDWCSOYMJsXWuMKlZPjAKGCicoTEUnriMmVJwUZtYJRwqStgvJtVkGo");
    bool xWkpHAl = true;
    double AAdWzRxGMjT = 462669.2304376109;
    int mgkbF = 1378219516;

    for (int rgKPJyIdWiubG = 1556428035; rgKPJyIdWiubG > 0; rgKPJyIdWiubG--) {
        mgkbF -= TwjPsKcxXPdVd;
        ltNcG = uZMPPa;
    }

    if (IGdYzJkdet == string("yBXoemuhGkTwZnEkAlQIJsfsafWlbTdSLdOlCvlOUVJCPQpLsekxmUUDWCSOYMJsXWuMKlZPjAKGCicoTEUnriMmVJwUZtYJRwqStgvJtVkGo")) {
        for (int wLVwaPedR = 484446786; wLVwaPedR > 0; wLVwaPedR--) {
            continue;
        }
    }

    for (int CyobDYQeQaXtqA = 3579538; CyobDYQeQaXtqA > 0; CyobDYQeQaXtqA--) {
        pUGfMWDkgbDbs = uZMPPa;
        pUGfMWDkgbDbs += ltNcG;
        TwjPsKcxXPdVd /= mgkbF;
    }

    return mgkbF;
}

string FtVAbQwDqui::BuiVTT(int FISvV)
{
    int uCcSsSO = -324149476;
    double bIHOKjAQgeFDD = -235437.24696280007;
    int zefQkBI = 1734064267;
    bool IDVdswGQDB = true;
    int XMNKUEC = 200219467;
    string LYUxl = string("sDdBCOHwKSdREjecsLIjxWPPimwawynodtpQGsqtqqnOCzpNEmYVBiHjIIDjg");
    bool zGHlz = true;
    bool amfLbJBlSIpONmyh = true;
    double bDUpuyfaQkA = -807327.2111798379;
    string tcIpoTQQA = string("ChUncQHvbhUpMXRewnmqRdYpNqsMUSeAJETgBabDSZauWejnfxQTiEroQnHLIFchbdDgoSqKZeDzuNiKmuDEKWNTfPHzDrNLzwYLwHKDfHbIQOXHqnNsXqcceKVvbMKQddAxhyVkOdRnSfAehtBFxTjXmyNVEwYswmUPXmlhBevYTSScIVuDpLiSoIEkfjJZXRgEWUUMKyKjEIFw");

    for (int YoajdxV = 2062991075; YoajdxV > 0; YoajdxV--) {
        zefQkBI -= FISvV;
        XMNKUEC += FISvV;
        zefQkBI -= XMNKUEC;
        LYUxl += tcIpoTQQA;
        bIHOKjAQgeFDD = bDUpuyfaQkA;
    }

    return tcIpoTQQA;
}

FtVAbQwDqui::FtVAbQwDqui()
{
    this->GRGgzQzfDZGD();
    this->MqPlh(string("LNbXBRrwsZcTLbCEFEylkiqRqmjtOZVGaVqClLgLMexxLEKycWBmSxYMmexZbSJyQkqOHHBJnvjIKgAEuyXJxsTpavGZNHrcPgcgZFikzjjyxorM"), string("NiTKMNsPOiviHGGORhvYACcgjfuLveGsIGagbTanDkIwpudFiZPrBwFgRUwdYjZEGturkofJjGPkFQxpVMJfAHaHIMTkaodFnNMAiapAOucrYFhkCfgZmCICTsvQsskpylktXEa"), true);
    this->ZqBqNGQMFsykXuhs(748693.0302862948, 279778.07762684114, -752240.5808582169);
    this->vxbEhUkOYBEacxjD(string("OUSvkSwPaRJsuILbaXUQlqGHtlEOWyLTSptPByaqfTwSJOipajrlvZGRxxEWSFfOGBqliJYpJHtIrYPAVzWMCnoVhUbqHulwkWerKrnejPsYOlqlLvzPpusgQanFHBhxEnnwmjkKCajXcDZslQriLDBz"));
    this->KwJaDytx(true, string("EOrXRinyCpLWvvTfbivvywmldhAPLSAraXuGExSCWewUBtyxYTzccKmnnvDQvczyAaBNiDKjsjrRImTOixARFFwLwNDDvDSbGPKePCpyNGwbjubIkVROEEAQskWQVWVwIlKGGGKmcnZQanpMgAbZStZWXTkzSlkZLoGuTjHLRbVEDRkpJxRYUcJWwVLwYLYLfeTsqcveQAYVjxDVyotLkEqLCJVnEhagqRiisWaHhTlmiPWQvRU"));
    this->NrtRvmgLF(-820873.4427169536, string("SfYAGsJAyRBlZattNwTgvJYjQFZVMaVmrwMurwLbfUgpCSsPiJoradWrRKJZvDYAZDfnBcOXxVheregybxgqChPcxWmhVoUFLQMxpGOMmbttNniywAyuvPxlwYrFOjmGxbTxavtFOSIwzMDkfyJdYXMtudcwTphpYKkaXeshXUYgzVBOCSURBdmZFmOsOWatjGQ"), string("fawKTGdZxIgpUWFboWARDDJmlcAlpmNzJLukpEqAPUjSDjqxioQDHqwNNfnxzKhvBKyZkuPTYOBJdEBlPbYUqUxFAedMGVqjlisClZCgFLLCCgfLFMwFlwYPDjRieYnNbIWUtKgGmcnjttkFLmOtj"), 175966.12631164017, 214751.8234808103);
    this->sLXTFIVgSqO();
    this->tLXrfx(string("aYDmBVJbuGZtnVZxTuZofVmUIQpzHirFWogxhyC"), false, true, false);
    this->ISuQdDtlwt(false, true, false);
    this->AdUeKeGeOQNLYFtt();
    this->HwjjEeSr(-464237.4077914658, true, 576491089, 919771148);
    this->YaDQvUITc();
    this->BuiVTT(767079828);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YwcbmoGylnT
{
public:
    string HWZwV;
    bool yeAxOdqWqqmIeQMf;
    string jhiewDr;
    double TvyDMlPyUFfqFvb;
    bool HIkLJuFAwJBGKt;

    YwcbmoGylnT();
    bool yVqwZZM(bool jQEjoobOhDTMxIx, bool lxNNBPcvjXQSMY, string UZOrlLeWWluLcOzG);
    void jBtlgWSCfBNPz(int cYCWxcjd, double rYZewVP, int shmvbgwZ, double ZwGlWTJWR, string BxUPj);
    double UsijUjCF(bool YbdFgUxlP, int coAbXxFxzOaWNkMd, bool TYSsqZtkMCKsk, int vjGekLoUor);
    string yzfkLoD(int CwTflhaPPmEWH, bool SipvdhuQyRWfBZg, bool qcaGWHCPBXzFRg, double jXiPyqSGWfkkr, double RnoHwb);
    int GPcQF(double SAlRrs, string wjnrhsozMs);
    void erpuDzEc(bool wwdOcygWFZQhsFL, bool HkUxCS, double EvjFDnmGyY, double WzOTxADx, double CgksigSbjcIZRWJV);
    string pSRGouTpYdzyEejh(double qIDmrXrtvOy, int EHsxihjE, bool FTwpqkDykimU, double OFbnVkfUBs);
    void OuWYdWmHUiPwFe(int nzpZHucknmQb, double vEWCRZHiV, double pUfJousnprVvSJpL);
protected:
    bool WuVPERVqeyHe;
    int pigOqtJex;
    int qmwydMBRop;

    string ladfSVhE(string EskBq);
    string JRrxNXybYDbC(double lEPKqJJCwM);
    void SjqDPJNRMaINSm(double WLEUMmFfqa, string LkScpJd, bool qXwoJJCPd);
    string DBFsMasedN(double ZOwFxgBYTKVTtYj);
    void rXkEVo();
    bool oPofosvpU(string jTPVaLewjKwsCFB, double ZkJQOipWwmqtFp, double fOPjqOJQTG, bool UtNbpsElmSDR);
private:
    int yWDLaDgOlahMjrwa;

    string SpEZcUlKKpiQPM(double BrJYumQ, bool GPbxUI, string KFRUaeLPdNbCcNq, bool jBTUMGBFfyh);
    int fNcGjIjjfrY();
    bool XcGNq();
    bool pPMKmuPlihVaqrl(string DMvpKktZtU, bool RlrxX);
};

bool YwcbmoGylnT::yVqwZZM(bool jQEjoobOhDTMxIx, bool lxNNBPcvjXQSMY, string UZOrlLeWWluLcOzG)
{
    bool ejEtO = true;

    if (lxNNBPcvjXQSMY != false) {
        for (int jBIJaisMlk = 1142913036; jBIJaisMlk > 0; jBIJaisMlk--) {
            ejEtO = ejEtO;
            ejEtO = ! jQEjoobOhDTMxIx;
        }
    }

    if (lxNNBPcvjXQSMY != false) {
        for (int BIdXAokzUuytXj = 1036477998; BIdXAokzUuytXj > 0; BIdXAokzUuytXj--) {
            UZOrlLeWWluLcOzG += UZOrlLeWWluLcOzG;
        }
    }

    for (int QozdWaG = 1743272619; QozdWaG > 0; QozdWaG--) {
        ejEtO = ! ejEtO;
        ejEtO = ejEtO;
        jQEjoobOhDTMxIx = jQEjoobOhDTMxIx;
        UZOrlLeWWluLcOzG += UZOrlLeWWluLcOzG;
        lxNNBPcvjXQSMY = ! lxNNBPcvjXQSMY;
        jQEjoobOhDTMxIx = ! lxNNBPcvjXQSMY;
        ejEtO = ejEtO;
    }

    if (lxNNBPcvjXQSMY == true) {
        for (int iHFgRSj = 1100457166; iHFgRSj > 0; iHFgRSj--) {
            UZOrlLeWWluLcOzG = UZOrlLeWWluLcOzG;
        }
    }

    return ejEtO;
}

void YwcbmoGylnT::jBtlgWSCfBNPz(int cYCWxcjd, double rYZewVP, int shmvbgwZ, double ZwGlWTJWR, string BxUPj)
{
    string hYTlJZK = string("qUboorQMuIkuLkjhNJuFTEDkBcNriHOQYRgTEOpKZCuGkVKpIUvRgidwXxlBHFZTduFVKFcCPKtlDhDUJzAWUaBlwwGGCaHQQOkm");

    for (int LzayVcnVOOlo = 1610186135; LzayVcnVOOlo > 0; LzayVcnVOOlo--) {
        BxUPj += BxUPj;
    }

    for (int lFqiTrh = 1173311252; lFqiTrh > 0; lFqiTrh--) {
        BxUPj = BxUPj;
        BxUPj = hYTlJZK;
        ZwGlWTJWR -= rYZewVP;
        shmvbgwZ += cYCWxcjd;
        hYTlJZK = BxUPj;
    }

    if (BxUPj == string("qUboorQMuIkuLkjhNJuFTEDkBcNriHOQYRgTEOpKZCuGkVKpIUvRgidwXxlBHFZTduFVKFcCPKtlDhDUJzAWUaBlwwGGCaHQQOkm")) {
        for (int CdOSRHQhLmJNRl = 1816539857; CdOSRHQhLmJNRl > 0; CdOSRHQhLmJNRl--) {
            hYTlJZK += BxUPj;
        }
    }

    for (int bGkbxvCwKQqCARUZ = 721449547; bGkbxvCwKQqCARUZ > 0; bGkbxvCwKQqCARUZ--) {
        hYTlJZK = BxUPj;
        cYCWxcjd *= shmvbgwZ;
        rYZewVP /= ZwGlWTJWR;
        hYTlJZK = hYTlJZK;
    }

    for (int vvCmVNKPgoA = 1812367819; vvCmVNKPgoA > 0; vvCmVNKPgoA--) {
        ZwGlWTJWR /= rYZewVP;
        rYZewVP = ZwGlWTJWR;
        rYZewVP += rYZewVP;
    }
}

double YwcbmoGylnT::UsijUjCF(bool YbdFgUxlP, int coAbXxFxzOaWNkMd, bool TYSsqZtkMCKsk, int vjGekLoUor)
{
    string WQMDMYo = string("bZDCXNgYkmkDDFQTJfQlwTaEgTeZeZhYYdIScUsUMtuSqnzvDXNJiismzteOnFbaarZwcLQpanlTfrKwoROAzJzSHLADFQcnSAGbRBiwysYMJWuTQkAudSubwteSpEuAapXuCWShZ");
    string vhQxGhshAWBA = string("mYjkIaDzVINyMpPiqYvCSNmawiBDCNytgoqWtEHHDZXhUMhMREzEUsdVj");
    string frEqTHMPFkie = string("fTDMFZUqPJyYsBSUJgPkNrNJciVvDHjaTCJLFMYOhWFIMYnucKfsaeYopXIQbwxXWWrAaztpRJdblIgmSTjaFeAspmoCrcDweNabOOTfAfPKjkDysdNazvTqCeBSMQQYgfTsXMnPyBSYHIsnWSHKQYpuOPhHvBDfPTaxLzqGlVwxJrqZycUCQqfheuaSRDcddKfkEQZDzKrgKgHeuxgoAfzBhdk");
    double mNapwxIHk = -999028.1344318594;
    double LdysKH = -840568.7315429;
    bool KeyjYJLZYOwxW = false;
    int KkoSrDIH = 951668390;

    for (int YqAzcODf = 1144860823; YqAzcODf > 0; YqAzcODf--) {
        TYSsqZtkMCKsk = KeyjYJLZYOwxW;
    }

    for (int uRUDGdDPPasobZq = 331366817; uRUDGdDPPasobZq > 0; uRUDGdDPPasobZq--) {
        coAbXxFxzOaWNkMd -= KkoSrDIH;
    }

    return LdysKH;
}

string YwcbmoGylnT::yzfkLoD(int CwTflhaPPmEWH, bool SipvdhuQyRWfBZg, bool qcaGWHCPBXzFRg, double jXiPyqSGWfkkr, double RnoHwb)
{
    string vmcPnv = string("wOGVXJPsvsdckrpNKXoouNYvZeLziQluCqXPSaBPpInWfQaKkQLKGaFWPorFzQqPBLysxOhsCCcecRrTbGEgJbccyHaSeDqmpMTolNZCXBDEVmIaoRvfwqWyvbpYoLtSoPxWxlrQujsVdUhfjcNpVGoEMgmSaUWhvAMueDsyOzGNOqUrOsycqRySBvfkZdRrsgPh");
    int psZdYsAXfyt = -1620462371;
    double RXZBCeR = -276834.21322013205;
    string gCatEPXdS = string("jszlyLgSiRHbkCBqANnxsvmocJOdNTTsYheTnrESsSywXBadosrFxHGYmMVltgkqZ");
    double SBweJGGnXhH = 830799.0058284352;

    for (int KpXeqZDRJBHTABd = 786106921; KpXeqZDRJBHTABd > 0; KpXeqZDRJBHTABd--) {
        RXZBCeR = RnoHwb;
        psZdYsAXfyt += psZdYsAXfyt;
    }

    if (gCatEPXdS <= string("jszlyLgSiRHbkCBqANnxsvmocJOdNTTsYheTnrESsSywXBadosrFxHGYmMVltgkqZ")) {
        for (int kXUve = 576271603; kXUve > 0; kXUve--) {
            continue;
        }
    }

    if (qcaGWHCPBXzFRg == false) {
        for (int nXxKUnsyNHkg = 1602548765; nXxKUnsyNHkg > 0; nXxKUnsyNHkg--) {
            vmcPnv += gCatEPXdS;
            vmcPnv = gCatEPXdS;
        }
    }

    return gCatEPXdS;
}

int YwcbmoGylnT::GPcQF(double SAlRrs, string wjnrhsozMs)
{
    int TEkLtCpdpQYrXjg = -1705854987;

    for (int eVajfxGHZpL = 816299997; eVajfxGHZpL > 0; eVajfxGHZpL--) {
        continue;
    }

    for (int yKsnfveyx = 827307707; yKsnfveyx > 0; yKsnfveyx--) {
        TEkLtCpdpQYrXjg += TEkLtCpdpQYrXjg;
        SAlRrs -= SAlRrs;
    }

    if (SAlRrs == 395306.96878330567) {
        for (int cbVRwU = 1067685814; cbVRwU > 0; cbVRwU--) {
            SAlRrs = SAlRrs;
        }
    }

    for (int WrgRVUjZtYfgXM = 2058677068; WrgRVUjZtYfgXM > 0; WrgRVUjZtYfgXM--) {
        wjnrhsozMs = wjnrhsozMs;
        TEkLtCpdpQYrXjg += TEkLtCpdpQYrXjg;
        SAlRrs *= SAlRrs;
        wjnrhsozMs = wjnrhsozMs;
        SAlRrs /= SAlRrs;
    }

    return TEkLtCpdpQYrXjg;
}

void YwcbmoGylnT::erpuDzEc(bool wwdOcygWFZQhsFL, bool HkUxCS, double EvjFDnmGyY, double WzOTxADx, double CgksigSbjcIZRWJV)
{
    bool kkhjojadhrVGdmu = false;
    string JNCQwgmMpotrYnN = string("zTqJXOLFovVrUVZcXfAfyWdCsQqBHpEhkpIJASUHsGvPBLxmNufuGYdFWxZrMXnKlgjdzkyyXxSiAeqwiQYIHpEhHhajZEWmQdiiXfJIKKKvIqTBVArTcWTwOxKYFOZZYLHsjzxQOFXVRXUVNiNDvLARoMW");
    int HENxFydTGhGNMMv = 1986952883;

    for (int OXEQQrYQ = 740338023; OXEQQrYQ > 0; OXEQQrYQ--) {
        continue;
    }

    for (int NqFuEoe = 1653471635; NqFuEoe > 0; NqFuEoe--) {
        CgksigSbjcIZRWJV *= CgksigSbjcIZRWJV;
        CgksigSbjcIZRWJV *= EvjFDnmGyY;
        kkhjojadhrVGdmu = wwdOcygWFZQhsFL;
    }
}

string YwcbmoGylnT::pSRGouTpYdzyEejh(double qIDmrXrtvOy, int EHsxihjE, bool FTwpqkDykimU, double OFbnVkfUBs)
{
    int BwzPVAKNrkvmxuwT = 638254679;
    int jndUiAJvZXnc = -1265416075;
    int xXvsOsSHdDMgFvpu = -1392066635;
    string yiNNKQI = string("aPnWZhxBHMCbRUDTTRuFASUyxnnWzFOKqCoKmAtwkXcCgvZEMzymbzTmFHTqKwoHmiMtwDcmfxsWxqWbcYuEpNmMDMKNyqizxnFAQWovqiOtTgZHZIeMuhfCABFJINCdezdqNGVFnRVSosNWeE");
    bool rjadnDntPqOwIZ = true;

    if (qIDmrXrtvOy == -488513.5515799447) {
        for (int DoPOzxgSgzvxHeVY = 66027420; DoPOzxgSgzvxHeVY > 0; DoPOzxgSgzvxHeVY--) {
            rjadnDntPqOwIZ = ! rjadnDntPqOwIZ;
        }
    }

    return yiNNKQI;
}

void YwcbmoGylnT::OuWYdWmHUiPwFe(int nzpZHucknmQb, double vEWCRZHiV, double pUfJousnprVvSJpL)
{
    int rNsXPjCeaZOfuHs = 1473503013;
    double nSLbl = -329634.7275989755;
    string iwxQPkmQXv = string("IlivttAMdePqzNafJqNqNVXQbyBZXDgYXONxywXwWgKzKeBKuUoRdHEzcWoyoQItikMKvRPaJytZXYVLtWulyQuACvbjHtldyQXXAZATIJGWhvhzuepnstoOrVAfpheEIQkuaqioJgXjnNHmEIsxFdfhNNAArWugv");
    string VthGMc = string("CcRqRMXvvUcWYEadAmAWdPYutTmHfVBTxexTyiAeqQwsTcZySearVhgxJmgzGtoxxbHkzMebjoHvXuaPRnaxzbHMQvVuZCmcTfBRLjOSUicURJKVyLnNtrnrVimEVptpjTIHtYKknjbWOGFcGHolkYilAULtPgvIspSvwMjQsfECWQSTgNJHtYD");
    double UpxLVkMs = -648827.612769781;
    bool BztTpz = false;
    string daRHI = string("nqUXkpgFClsdAAWMUyQaOBwNZaskabASenRIMJCVMuzrOrcYqwwLRltDnSYeeNdttBQhHSblnavTVTxwXRvZAGbxRnubMsYiFbFielIqBidrNWdTXvggyP");
    bool QpgCYcVLstpgb = false;
    double VNQcq = 1044838.8194815854;
    int IpzVVc = -2030041043;

    for (int yZSHiQzxnBuNl = 223172854; yZSHiQzxnBuNl > 0; yZSHiQzxnBuNl--) {
        nSLbl *= pUfJousnprVvSJpL;
        iwxQPkmQXv = iwxQPkmQXv;
        IpzVVc = IpzVVc;
    }

    for (int vXnLzRA = 1428898969; vXnLzRA > 0; vXnLzRA--) {
        iwxQPkmQXv = iwxQPkmQXv;
        pUfJousnprVvSJpL -= pUfJousnprVvSJpL;
    }
}

string YwcbmoGylnT::ladfSVhE(string EskBq)
{
    string DYOIow = string("GPWmZHdWIusAPhQTqIHzFWSuJpMtsBSsBAyoQIdFmnYlSUUKShikDaXfjMkBcmmxeMtzSnfnrPwAmERejAbywgBJKGuYjSkjixZAVdBHPwUwuAbFbLeihdQrZIRfpUnmAaWOCQ");
    double qiAXRNTrSWlhD = 546536.5375398474;
    bool EfkRkzDVXFNqJ = true;
    double qykgR = 746206.2954671178;
    double atZEuJFvgPafqvBB = 867136.1997240738;
    int mbxIhMUsFb = 1875546224;
    string pkNNgUyKQMN = string("azeZVPjqeVJaZcknpcRWLIPbENpljIieYfjzErlfqcoPfRCoumnfkPQhybNsYQhfitbcINjHfvNYLeFBLpTWHwfXYddghBnw");
    int OrufpVIEGWIh = 270460349;

    for (int mAHUZxPcPylVgxqC = 478968178; mAHUZxPcPylVgxqC > 0; mAHUZxPcPylVgxqC--) {
        qykgR /= qiAXRNTrSWlhD;
    }

    for (int kHASwEmfhJ = 844991967; kHASwEmfhJ > 0; kHASwEmfhJ--) {
        continue;
    }

    for (int tPClHuFqaJFq = 761038341; tPClHuFqaJFq > 0; tPClHuFqaJFq--) {
        continue;
    }

    for (int VAjvTHbPG = 1919556341; VAjvTHbPG > 0; VAjvTHbPG--) {
        continue;
    }

    return pkNNgUyKQMN;
}

string YwcbmoGylnT::JRrxNXybYDbC(double lEPKqJJCwM)
{
    string gUnBmRyecV = string("pSFIgQSUIqcpWdGjxCazJcSRQopCqIklDWFxYNAslTWBcjMKAgaBdnVgedUDfivAuZgHdulhzntwdOlYcGWpvZcsSawxKDemiWlENMYroZrMTYgVpeIquDJanLmzRtxYIppyWVXLPsPekKnuSDvYSGrJMaepzsKIBgvJperbHFbQRdOWUIKMSHYLiAxAitVVLzCTqceswhTUIudgFlHnFyyAegzcFZnVAHuWyIlvdcixUVGQ");
    double oIQcClbEUmUdqXp = -452734.13361170125;
    string ThcKajpcSqqVEM = string("zvnWCQnNcmdOmXJYjnKeGXeouENLEDqwINQlLhokWPLmYKXPOLAoriZZGupmwktOWDuKPOGSmAdsRcNu");
    int YRXbBs = 938346582;

    for (int DFORjUiVdAsy = 575976247; DFORjUiVdAsy > 0; DFORjUiVdAsy--) {
        continue;
    }

    return ThcKajpcSqqVEM;
}

void YwcbmoGylnT::SjqDPJNRMaINSm(double WLEUMmFfqa, string LkScpJd, bool qXwoJJCPd)
{
    bool IzHOpKZK = false;

    for (int kSqQTGKpxnD = 967147502; kSqQTGKpxnD > 0; kSqQTGKpxnD--) {
        qXwoJJCPd = IzHOpKZK;
        qXwoJJCPd = ! qXwoJJCPd;
        LkScpJd = LkScpJd;
    }

    for (int IsCdyKVWgTg = 1928924739; IsCdyKVWgTg > 0; IsCdyKVWgTg--) {
        WLEUMmFfqa *= WLEUMmFfqa;
        qXwoJJCPd = ! qXwoJJCPd;
        LkScpJd += LkScpJd;
    }

    for (int gLeDwqVEW = 353269817; gLeDwqVEW > 0; gLeDwqVEW--) {
        LkScpJd += LkScpJd;
        WLEUMmFfqa += WLEUMmFfqa;
        WLEUMmFfqa += WLEUMmFfqa;
        IzHOpKZK = IzHOpKZK;
        WLEUMmFfqa -= WLEUMmFfqa;
        qXwoJJCPd = ! qXwoJJCPd;
    }
}

string YwcbmoGylnT::DBFsMasedN(double ZOwFxgBYTKVTtYj)
{
    int jckgjgb = -1768815264;
    bool EqGnUqJDsxMtiT = true;
    string PofMbZ = string("dMvXvFHRRFbTdQBSmNOSbfhcEucFdoLhHZnogBhVhfLWKIDcEGyWxtVFVxVjYPxoEWXDvxWlonplqIhbjLeSTcB");
    bool bLHns = true;
    double UCGJcwgPZWVAM = -240069.43568443492;
    bool oAJDSNBypDpvqmQd = false;

    for (int CJgpzdFcbuW = 1662390576; CJgpzdFcbuW > 0; CJgpzdFcbuW--) {
        jckgjgb /= jckgjgb;
    }

    if (ZOwFxgBYTKVTtYj < -796650.0009834105) {
        for (int fLObrBtRZscBfGnC = 1939363255; fLObrBtRZscBfGnC > 0; fLObrBtRZscBfGnC--) {
            continue;
        }
    }

    for (int ReHtwgu = 950971461; ReHtwgu > 0; ReHtwgu--) {
        bLHns = ! bLHns;
    }

    for (int sIsZpvej = 1404417454; sIsZpvej > 0; sIsZpvej--) {
        oAJDSNBypDpvqmQd = ! oAJDSNBypDpvqmQd;
        oAJDSNBypDpvqmQd = ! bLHns;
        UCGJcwgPZWVAM *= UCGJcwgPZWVAM;
        oAJDSNBypDpvqmQd = ! EqGnUqJDsxMtiT;
        oAJDSNBypDpvqmQd = ! oAJDSNBypDpvqmQd;
        PofMbZ += PofMbZ;
    }

    for (int azyaVIRmSxAx = 1202109209; azyaVIRmSxAx > 0; azyaVIRmSxAx--) {
        continue;
    }

    for (int rSQpocXUihQ = 1139230170; rSQpocXUihQ > 0; rSQpocXUihQ--) {
        oAJDSNBypDpvqmQd = ! EqGnUqJDsxMtiT;
        oAJDSNBypDpvqmQd = ! bLHns;
        PofMbZ += PofMbZ;
    }

    return PofMbZ;
}

void YwcbmoGylnT::rXkEVo()
{
    int srSdJfD = -1760615593;
    double TzhtSGOAOeqNmzj = -107001.91219087038;
    string tNExRFmb = string("rrcWndRYBHdeEvsUiUVlCXjEkMkddxO");
    int PswGLZDwKI = -1938797017;
    string YrISHHZwPwKcxBm = string("UXpbBtmXxZfNysRNFJitytpwkgzyrwETDtARnqoJWObDkLpcHbRecpgbARDKOeNSzHrlqBItrUhniv");

    for (int RQATdXybJgRsf = 1520645453; RQATdXybJgRsf > 0; RQATdXybJgRsf--) {
        YrISHHZwPwKcxBm = tNExRFmb;
    }
}

bool YwcbmoGylnT::oPofosvpU(string jTPVaLewjKwsCFB, double ZkJQOipWwmqtFp, double fOPjqOJQTG, bool UtNbpsElmSDR)
{
    double ASzlFbbpRMnM = 545943.4904764582;
    string PgtVUarQUBPvKG = string("LVdkbCnRsYHDRFlftFHCCdiZUcLfRQphmvNGvsBWPKvipMdSZxytXmyHYKkfHpbYJvoGetwenmdgNvcZlTusikOjGFXZDPUvwUVVKVwpiYAEVQJGnuiGTvxDwozhDPubwukvHaPkxQeGZAuME");
    bool bzUMNoBzfuajent = false;
    double zZLEXL = 768074.931549589;

    for (int nKAqsFdZUG = 1804072625; nKAqsFdZUG > 0; nKAqsFdZUG--) {
        PgtVUarQUBPvKG += jTPVaLewjKwsCFB;
        zZLEXL -= fOPjqOJQTG;
    }

    for (int ySXJE = 2041310925; ySXJE > 0; ySXJE--) {
        ZkJQOipWwmqtFp -= ZkJQOipWwmqtFp;
        jTPVaLewjKwsCFB += jTPVaLewjKwsCFB;
        ZkJQOipWwmqtFp = ASzlFbbpRMnM;
    }

    for (int SDSxnHWT = 1393788744; SDSxnHWT > 0; SDSxnHWT--) {
        ZkJQOipWwmqtFp += ZkJQOipWwmqtFp;
    }

    if (PgtVUarQUBPvKG < string("LVdkbCnRsYHDRFlftFHCCdiZUcLfRQphmvNGvsBWPKvipMdSZxytXmyHYKkfHpbYJvoGetwenmdgNvcZlTusikOjGFXZDPUvwUVVKVwpiYAEVQJGnuiGTvxDwozhDPubwukvHaPkxQeGZAuME")) {
        for (int CzODucLn = 1172516112; CzODucLn > 0; CzODucLn--) {
            ASzlFbbpRMnM -= fOPjqOJQTG;
            zZLEXL -= ASzlFbbpRMnM;
        }
    }

    if (UtNbpsElmSDR == false) {
        for (int kmmoSUCUdfVh = 96750267; kmmoSUCUdfVh > 0; kmmoSUCUdfVh--) {
            ZkJQOipWwmqtFp = fOPjqOJQTG;
            zZLEXL *= fOPjqOJQTG;
        }
    }

    for (int XDhxyL = 876657125; XDhxyL > 0; XDhxyL--) {
        ZkJQOipWwmqtFp *= ZkJQOipWwmqtFp;
        jTPVaLewjKwsCFB += PgtVUarQUBPvKG;
    }

    if (zZLEXL == 575135.5157103607) {
        for (int NZqsPB = 444420445; NZqsPB > 0; NZqsPB--) {
            PgtVUarQUBPvKG += jTPVaLewjKwsCFB;
            ZkJQOipWwmqtFp *= ZkJQOipWwmqtFp;
            zZLEXL = zZLEXL;
            zZLEXL /= ASzlFbbpRMnM;
            bzUMNoBzfuajent = UtNbpsElmSDR;
        }
    }

    return bzUMNoBzfuajent;
}

string YwcbmoGylnT::SpEZcUlKKpiQPM(double BrJYumQ, bool GPbxUI, string KFRUaeLPdNbCcNq, bool jBTUMGBFfyh)
{
    double HQSVoZsyqYNS = 806401.6258899148;
    bool NKOoBXYuYYcc = false;
    bool GtmNCRVHb = true;
    string ONTnp = string("EmZUlnTsTMtexoRcaeaIXPHmYiVkzecnJqgpjfvQCzTDPYbGJNCJyEslajOesisLsYXfToNCCbJMZazIVlkpqLbxDGAgSrZzly");
    double hAszMTqzjlxta = 173315.73724574567;

    return ONTnp;
}

int YwcbmoGylnT::fNcGjIjjfrY()
{
    string suEiYLJhn = string("vZufgHcZIwAyTqNhHpglSvIWiCvOJJTeKVfZnhqqCqDQBNtCLAIMoMGSmoWBOhIQfBGKOhNWxjCKbnFrtcDwyWCWmXKPyGqUgaprMJllZGvuDCGqwgWpGjQVMIjAYtEOEDyElrKjdIwoamdgxnpmGjZwwNsQpmqknQSdoaSkQDidHdAQaObvrrWuNQKlJUCEEGviOstMNcDjpWxqSzronGFAIPbuhiUDRzpOUHTmeFV");
    bool weqYVyhMh = true;
    int KscIM = -180779214;
    double KXCyllBDUm = -665193.4157227738;

    if (KscIM > -180779214) {
        for (int wQtaRcT = 1291675060; wQtaRcT > 0; wQtaRcT--) {
            suEiYLJhn += suEiYLJhn;
            KscIM /= KscIM;
        }
    }

    for (int CllKSAMcBhLLWAeo = 1886279639; CllKSAMcBhLLWAeo > 0; CllKSAMcBhLLWAeo--) {
        weqYVyhMh = ! weqYVyhMh;
        weqYVyhMh = ! weqYVyhMh;
        suEiYLJhn += suEiYLJhn;
        KXCyllBDUm = KXCyllBDUm;
    }

    return KscIM;
}

bool YwcbmoGylnT::XcGNq()
{
    bool NZpoBwFyPUp = false;
    bool wuaiQl = false;
    string zepWKxvJ = string("zYdswiMPpCUjISbqJnuXOxuCZfyuqfgjafOltdDESaPIMkmERFMOKjUVbieXAAafExAhEYeDysINGKkboYhLfbJzoJTMpiASYAhSwLFHjjSOPhEiHUOtWyupsiEGEkcXKUgFxM");
    int YAewoO = 1186790137;
    string QNBqNzMyVXnLZN = string("pconHLUZLkIZfSbMkgMZzPOpvijoUHptIGQJtJyDYaXfkpKVOxtCyuwnWCkPKWOsxppWoYdlIPwRsousinYZKaDjQjAkcAefSZRxBWzQcxtZvTktigXNqTEPqfBSJPvVEcCsMTyZFoAXMhNKNMWkGlfxkhYtGSjWnTnWdDRQqUGKFVFDgKbqweqVHbCcmzizSdmdKAdIwAebaeDbMycpLuwFpLwdQCEGaXGdsRyq");

    if (zepWKxvJ != string("zYdswiMPpCUjISbqJnuXOxuCZfyuqfgjafOltdDESaPIMkmERFMOKjUVbieXAAafExAhEYeDysINGKkboYhLfbJzoJTMpiASYAhSwLFHjjSOPhEiHUOtWyupsiEGEkcXKUgFxM")) {
        for (int EswmgBfDXa = 1166295717; EswmgBfDXa > 0; EswmgBfDXa--) {
            QNBqNzMyVXnLZN = zepWKxvJ;
        }
    }

    if (wuaiQl != false) {
        for (int RuvSCdpYtReXxX = 2113789204; RuvSCdpYtReXxX > 0; RuvSCdpYtReXxX--) {
            NZpoBwFyPUp = ! NZpoBwFyPUp;
            zepWKxvJ += zepWKxvJ;
        }
    }

    return wuaiQl;
}

bool YwcbmoGylnT::pPMKmuPlihVaqrl(string DMvpKktZtU, bool RlrxX)
{
    bool lSkcjIVbzQJIM = true;
    double UjWwfhhuGXXMcuP = 452399.5693351109;
    bool iuRHONhIsOyadHQ = false;

    for (int aIrWQNJsiiltgsZZ = 707035488; aIrWQNJsiiltgsZZ > 0; aIrWQNJsiiltgsZZ--) {
        UjWwfhhuGXXMcuP = UjWwfhhuGXXMcuP;
        UjWwfhhuGXXMcuP /= UjWwfhhuGXXMcuP;
        iuRHONhIsOyadHQ = lSkcjIVbzQJIM;
    }

    return iuRHONhIsOyadHQ;
}

YwcbmoGylnT::YwcbmoGylnT()
{
    this->yVqwZZM(false, false, string("JPDkSIcKnYqursIeONTpfzHqNPYqWRqRIpUrnmmxbkAKaMhCxZpLzOqVEITixByELRLVwWZxmEzaVbNHhprHPyKdIfzmZDGZeVkdmdpplJTSUXoEIQWUUvt"));
    this->jBtlgWSCfBNPz(-2126480096, -639564.4190986374, 2092513650, -293922.36600600637, string("WXSeGQmLnJddrcIXvnPbzXOiIlpCwgbGwEuZVtiQBtRBIRVlzcnFCzFyKxgvZvYrIhwtfSHRigZxTvwZnVjpizeVbgztV"));
    this->UsijUjCF(false, 2119610640, true, 372547116);
    this->yzfkLoD(-386192131, false, false, 59014.640027747926, -413821.3529338103);
    this->GPcQF(395306.96878330567, string("fPmojUyTKEXAOsszjviqLPlJPFdLPVrlMkHWroOzWpQRTmGNkvETDmrOKGizEAWvTzCkSyiFuOApySFQwdPQORjLowHmfAPmmnSoSNzxqnAZcQCDsqjDsyIqxFKzmFNdSBqangFOPgJFYijfjKdIGhSvFEXUfBWCrgveZpVMpOScPKBruceczEOGpXuIVTDlTZzFpQkYokUbMdHRQVOXYeSBhqRwNGaZraHYwrjuCXJAdhflZZEz"));
    this->erpuDzEc(true, false, -814661.2639948708, -718406.1322224949, 138407.44691969297);
    this->pSRGouTpYdzyEejh(-488513.5515799447, 1656801630, false, 503634.5204293697);
    this->OuWYdWmHUiPwFe(1376587864, 995440.0580589216, 181701.9220544102);
    this->ladfSVhE(string("JJxgOyltocvOKQZYbkwgJIBasWNsmXdQETznpiAgeJdjqSKbzryWCHYdyMXkALWZHtzoyYSZRKyOkEEBveZKudkYfVFcFDbcxrfxHpRJXuVXVayaiKsssbqVmORgvcXffFFyrUAoHBEinffimaIWvIMomlkfZBwRizXeGQzdaeRVFHkqFGompFQ"));
    this->JRrxNXybYDbC(-161865.80922932262);
    this->SjqDPJNRMaINSm(153541.8311552128, string("tEdOJpvPLUywhCMprBxJetNruaqTZuIfQAwGWpKzfwPRTXqeYUHuaDpdwudVHJNXzQqEpgvdsCYKdcpCl"), true);
    this->DBFsMasedN(-796650.0009834105);
    this->rXkEVo();
    this->oPofosvpU(string("vdasQvwUTQqbahWd"), 358061.81783956505, 575135.5157103607, false);
    this->SpEZcUlKKpiQPM(-870337.538503234, false, string("KciuAjwmWfNSpqDSUhfqVGKdEMcgIwvJavMiXTyYizYlUGeHBRHKApxOWkBWCRsLDLTcXrKrhGrykAQiiFtGmzrdJnarcKVPKCvsoGWysEfdEhlfbTSkTLyWoFzyrlCErArWepwavqxVJRiecoOnmzJM"), true);
    this->fNcGjIjjfrY();
    this->XcGNq();
    this->pPMKmuPlihVaqrl(string("eYNRimMWyjbyWZvfrGdhCmgrsoWeGBBgTKYfWBzIlTtlEYzqHMEJlovJrZWQTIezQhlxRJwdQfRrAqhwelKSQcvqgZvqPHYmFpmRcXVtjMrMeCxKfkwSTtVevDvxmBBPWpFnbYJjVsIFCuROaKneOhLzPnvavSpeHXAvusPHGqmHNwmXDZegGZQWkvijZxTSPLvZEcvDBBbnHUVRokfvPGokrQlkmYmnTxyzhkO"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JEuQXqfjixk
{
public:
    bool HvBsGL;

    JEuQXqfjixk();
    double vFHhMObpZ(double CBsDSPDCUHEculnJ);
    void oLfFEClfTy(double OnYPTHPKMK, double YkqbkTiWJzUH, string Seixnu, int lFKTLSvDuzGUNh);
    int rQvHB(double AZRrTueI, string XYHVipXodtDSZDzl, double lnMdPNRIT, bool HPsIEHn);
    void srSDWm(string DFGUlguCim, int eJtwbPex, bool jtkCu);
    double mFPnODoliyslRR(int AAmyKXoYQkgWCt, string kGbRioscaZybj, string yROayTNSHqRpfbNG, double HXPzPVXhgq, int yEbbZvVw);
protected:
    int OSvnivhTqztWqwIX;
    bool pSACJBOfTGOl;
    string nGnCWAbPXlHnxc;
    string xaZodpt;
    int oxthnddyJkl;
    int TNGwgaUEs;

    void EgNboOYXjL(string pvuNoWpDXWErgSU, int oljTkbCS, int bUQQzpqNVJ, int xVFnyyQKhrjaYS, string vuRZIQIZHhcUpZQk);
    int VSYLBoePZyHBA(string AeGeICSi, bool OlUPGl, bool mIqRX);
    int TemZxZ(int MWLrMAzSMUQPd, double BqbxjTvVP, bool QOPRkN, string vZflFcrn, string VNSLvgzl);
    int cUDBdBFdOAhrWfTH();
private:
    double eHTGVoWgyTPNE;
    double QxDFbeVtkOh;
    string yiFubaxTstTQf;
    string yKoduqRbmkwaYasp;
    double QYwNE;

    int BRIbfqQtRod();
    bool vVMKHETGB(string ypkIblJkTkbzaB, bool cHyJfveWCohMgRW, double ItNBVrNGjYdpY);
    string PGbjziGXcwIaA(int KJwPHFzcLNV, bool BXAkILhqrZomXDj, double uosudtasimDiycx, int IFRNW, bool JyzIMhaRtEZG);
    int XyVvCoDDrXsZk(double ocjPOjYaJBM);
    bool lyfRWZBcecFw(int agXwJzhUYv);
    bool fJgzxyiMOEjxm(string CXlfnMuvezeaLcqJ);
    bool bTExnLuuHKoFaRh(string BJJCCXfmZe, double nKUOnwTsrItjmk, string kKAwdzDCrFW);
    string bWcRLtOYQzfRk(string VFOEVhSfTjIsjFqF, bool ULNbwiMKBSDqI, string QWtkVUJL, double iNnXCbJLERRow, string xHkXaPOxX);
};

double JEuQXqfjixk::vFHhMObpZ(double CBsDSPDCUHEculnJ)
{
    int xuHpwQ = -2076579087;
    double kgvhNJKl = 236096.37322379774;
    bool WYPrJJGVRTDXVky = true;
    bool IrzvdGjhSHaXdcNN = false;
    bool aeAHDUd = true;
    string GCEUp = string("QcPnkawiHsmEFppULwnOndjovEvYXwfJfwsmLTuBeNjTQtZJBwAGFISMnxsYoJxqrZbEpiMGJYu");
    double BZHiSSmxVhdTxD = -37857.05886207696;
    bool tdCtvlo = false;
    bool IjAgYdEpjgXRpB = true;
    bool UzseKRjFANFENkCh = true;

    if (IrzvdGjhSHaXdcNN != false) {
        for (int jTSVwr = 903608211; jTSVwr > 0; jTSVwr--) {
            UzseKRjFANFENkCh = ! IjAgYdEpjgXRpB;
        }
    }

    for (int tzIxhVuldBLJBLa = 281775801; tzIxhVuldBLJBLa > 0; tzIxhVuldBLJBLa--) {
        IrzvdGjhSHaXdcNN = ! IrzvdGjhSHaXdcNN;
    }

    for (int xwiBzXIsQfAXeis = 111296190; xwiBzXIsQfAXeis > 0; xwiBzXIsQfAXeis--) {
        continue;
    }

    return BZHiSSmxVhdTxD;
}

void JEuQXqfjixk::oLfFEClfTy(double OnYPTHPKMK, double YkqbkTiWJzUH, string Seixnu, int lFKTLSvDuzGUNh)
{
    bool NWqksv = true;
    int dNZBlCiohjPK = -1695901502;
    int rTFWrHcElKBQ = -853409036;

    for (int Rsrvx = 69127071; Rsrvx > 0; Rsrvx--) {
        lFKTLSvDuzGUNh += lFKTLSvDuzGUNh;
        Seixnu = Seixnu;
    }

    for (int MFBfGnBKKyv = 1123761255; MFBfGnBKKyv > 0; MFBfGnBKKyv--) {
        dNZBlCiohjPK = rTFWrHcElKBQ;
        YkqbkTiWJzUH /= OnYPTHPKMK;
    }

    if (OnYPTHPKMK > -503524.0156859554) {
        for (int zpRNLP = 1315434699; zpRNLP > 0; zpRNLP--) {
            continue;
        }
    }

    if (rTFWrHcElKBQ > 986317333) {
        for (int gIpujQVavGHSKKd = 1645390020; gIpujQVavGHSKKd > 0; gIpujQVavGHSKKd--) {
            YkqbkTiWJzUH -= YkqbkTiWJzUH;
        }
    }

    if (dNZBlCiohjPK == -1695901502) {
        for (int KXvVxAo = 1656419430; KXvVxAo > 0; KXvVxAo--) {
            continue;
        }
    }
}

int JEuQXqfjixk::rQvHB(double AZRrTueI, string XYHVipXodtDSZDzl, double lnMdPNRIT, bool HPsIEHn)
{
    string ZPatQZW = string("YdigTVvVOOaSMxoVUWqIgtDzbKGjZFGPtCACyyMrIMDEYWnYZIFwTEMKTbkZKhUwHoFKdWeVYEhhzWJBQVFmCTvZgpJVbMiaYmXICTZfNNiwJvXoCOkLxb");
    int oPCfwFbIWsfABMJ = -1663608098;
    double VhLBcTgnxAJj = 270312.52701234026;

    for (int mGOjo = 1065187634; mGOjo > 0; mGOjo--) {
        VhLBcTgnxAJj /= lnMdPNRIT;
    }

    for (int pjcAtfdzv = 731855657; pjcAtfdzv > 0; pjcAtfdzv--) {
        lnMdPNRIT -= VhLBcTgnxAJj;
    }

    if (HPsIEHn == false) {
        for (int aAnLtRU = 429690195; aAnLtRU > 0; aAnLtRU--) {
            continue;
        }
    }

    return oPCfwFbIWsfABMJ;
}

void JEuQXqfjixk::srSDWm(string DFGUlguCim, int eJtwbPex, bool jtkCu)
{
    string YUOcVouCHtM = string("lDyFUWweuRRateixGpypSjlqsvXRwBLnbdqyM");
    bool bRBFgxuK = true;
    int WvtnbqBk = -235769432;
    double BkOEQIkCrram = 605173.5502885871;
    int HktHdenHY = 582042559;
    int TlCTBfqG = 1190842705;
    bool ybPssqdDF = true;
    double acQtMyvoQ = -268035.7428891936;
    int TYVOaHc = 39988987;

    for (int kbHZnUrjbj = 1180761873; kbHZnUrjbj > 0; kbHZnUrjbj--) {
        continue;
    }

    for (int NvcMKmdTbv = 827305189; NvcMKmdTbv > 0; NvcMKmdTbv--) {
        DFGUlguCim = YUOcVouCHtM;
        DFGUlguCim = YUOcVouCHtM;
        HktHdenHY = WvtnbqBk;
        WvtnbqBk += eJtwbPex;
    }

    for (int TrpwARtLrAsglsZ = 1577082979; TrpwARtLrAsglsZ > 0; TrpwARtLrAsglsZ--) {
        DFGUlguCim = YUOcVouCHtM;
        WvtnbqBk -= TYVOaHc;
        TYVOaHc -= TYVOaHc;
    }

    for (int RjvFkFKmqltAgN = 210964018; RjvFkFKmqltAgN > 0; RjvFkFKmqltAgN--) {
        TYVOaHc += TlCTBfqG;
    }
}

double JEuQXqfjixk::mFPnODoliyslRR(int AAmyKXoYQkgWCt, string kGbRioscaZybj, string yROayTNSHqRpfbNG, double HXPzPVXhgq, int yEbbZvVw)
{
    int eXNVdfjYh = 123442401;
    int wqMGUHRSoD = -1306177091;
    double xAWnwc = 798021.5660019164;

    for (int rttftzcmfii = 15317332; rttftzcmfii > 0; rttftzcmfii--) {
        yEbbZvVw /= wqMGUHRSoD;
        eXNVdfjYh -= eXNVdfjYh;
        yEbbZvVw -= AAmyKXoYQkgWCt;
    }

    for (int JJKdKE = 1545765969; JJKdKE > 0; JJKdKE--) {
        AAmyKXoYQkgWCt /= wqMGUHRSoD;
    }

    if (eXNVdfjYh >= 1952558532) {
        for (int LDjGuVpu = 1261880809; LDjGuVpu > 0; LDjGuVpu--) {
            AAmyKXoYQkgWCt = yEbbZvVw;
            wqMGUHRSoD = eXNVdfjYh;
            yEbbZvVw = wqMGUHRSoD;
            wqMGUHRSoD = yEbbZvVw;
            yEbbZvVw *= yEbbZvVw;
            wqMGUHRSoD *= eXNVdfjYh;
        }
    }

    return xAWnwc;
}

void JEuQXqfjixk::EgNboOYXjL(string pvuNoWpDXWErgSU, int oljTkbCS, int bUQQzpqNVJ, int xVFnyyQKhrjaYS, string vuRZIQIZHhcUpZQk)
{
    int KkPbH = 877946986;
    bool JomFUs = false;
    double TAvgidNUnwgzeCDS = 195624.0738249172;
    double VBaPrQPOYbUxZJa = 313284.1043992952;
}

int JEuQXqfjixk::VSYLBoePZyHBA(string AeGeICSi, bool OlUPGl, bool mIqRX)
{
    int mwtjocRC = 1123185238;
    int VzLgdyd = 314810785;

    for (int RuaFcGaoaXlhIeM = 1666146953; RuaFcGaoaXlhIeM > 0; RuaFcGaoaXlhIeM--) {
        VzLgdyd *= VzLgdyd;
        VzLgdyd = mwtjocRC;
        OlUPGl = ! OlUPGl;
    }

    for (int vPcePih = 1130334716; vPcePih > 0; vPcePih--) {
        OlUPGl = ! OlUPGl;
        OlUPGl = mIqRX;
    }

    return VzLgdyd;
}

int JEuQXqfjixk::TemZxZ(int MWLrMAzSMUQPd, double BqbxjTvVP, bool QOPRkN, string vZflFcrn, string VNSLvgzl)
{
    bool WwrVyaLxiCHX = true;
    string mOSZpMxKqtBj = string("cCVtvlZqqZMWsveKzqqQwCrFyJjxfOQxDlGfrNGTWvVTqZtmPAvYGIAcl");
    string klhjPcfMp = string("rUwgCzfdIThBMKjTwmenixDqJUWlzcLOOkLIajczHwzKAmRlWzZgWYKjlAkxmMIAsOLnIkFXwwkIwzvqfAZKWHGBRokOOqbqXPKbobrDqdgYVaGEUIifWusVIzcciQgWfSE");

    for (int OnntWDZmBvZS = 638201100; OnntWDZmBvZS > 0; OnntWDZmBvZS--) {
        klhjPcfMp += klhjPcfMp;
    }

    return MWLrMAzSMUQPd;
}

int JEuQXqfjixk::cUDBdBFdOAhrWfTH()
{
    bool rchRiHgdACAlS = false;
    int rcEnlhw = -834273127;
    string yyLBW = string("deqWdrAfUJOAYgSICxkxmwXbKehTmYzjFlVcxkrodCDYDencNmnjrhahYATamSirHmTbeJnbYRpTc");
    string rtEPesZhtULento = string("AGzCaXfdDLAiUHFUdaNuXX");
    int fBMtH = -421285841;
    bool xuFQnvaaOWw = true;
    string LtuvIKmJ = string("paicfbZnxKGPKfBUVrawwoeVjVUhClUQaqtrtqgWLKixbOKdoqcWjHKhHQMiCHiiRKWHZFKkSZYKKKNCiOAVRFDzRahnoWiYiImvvFALiebgBbEGeQzSyRPWHxpKjeCJGABrAYttVyjQhBLCEfYcEAOnvTmNKfqgbQkSYNmwkDTGgeFonbhfdsuiaxqBgJdTmuAykkeos");
    string tiKAfBKqKBI = string("vjLjCtOYhoGQjVVqgEsoXjuyEeEcKwZXQCefmwANsEKExaBjPjWMkNBUFGuwYfBOXaopTnozybCZuZJg");
    double gNCiUUg = 283210.89653341175;

    if (fBMtH > -421285841) {
        for (int axVfpaE = 17119306; axVfpaE > 0; axVfpaE--) {
            rchRiHgdACAlS = xuFQnvaaOWw;
        }
    }

    for (int qeZlurNismeja = 1818582067; qeZlurNismeja > 0; qeZlurNismeja--) {
        yyLBW += rtEPesZhtULento;
    }

    for (int UoOyG = 1054033914; UoOyG > 0; UoOyG--) {
        rcEnlhw = fBMtH;
    }

    return fBMtH;
}

int JEuQXqfjixk::BRIbfqQtRod()
{
    double QcSpgbZbaAPwVxtU = 754980.6278723832;

    if (QcSpgbZbaAPwVxtU < 754980.6278723832) {
        for (int woZXq = 1382616215; woZXq > 0; woZXq--) {
            QcSpgbZbaAPwVxtU /= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU -= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU *= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU = QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU = QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU = QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU -= QcSpgbZbaAPwVxtU;
        }
    }

    if (QcSpgbZbaAPwVxtU > 754980.6278723832) {
        for (int QAxcWRLDTlTJ = 818163110; QAxcWRLDTlTJ > 0; QAxcWRLDTlTJ--) {
            QcSpgbZbaAPwVxtU *= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU *= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU *= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU -= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU *= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU = QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU *= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU = QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU -= QcSpgbZbaAPwVxtU;
            QcSpgbZbaAPwVxtU -= QcSpgbZbaAPwVxtU;
        }
    }

    return -1691011295;
}

bool JEuQXqfjixk::vVMKHETGB(string ypkIblJkTkbzaB, bool cHyJfveWCohMgRW, double ItNBVrNGjYdpY)
{
    string ZwsqcZzoLiPz = string("IN");
    string zJEdpBe = string("GVFxSIXpRzxuDxGa");
    bool CPJcDIwxPXoIc = false;
    string bliPkM = string("BXESLOcCeLiRStYBIgefV");
    bool fLLFa = true;
    double PlitDddigzRe = -423546.8143639861;
    double WgYBSp = -558138.6448199839;

    if (ZwsqcZzoLiPz != string("GVFxSIXpRzxuDxGa")) {
        for (int MBgTRJBXKfm = 1911612446; MBgTRJBXKfm > 0; MBgTRJBXKfm--) {
            continue;
        }
    }

    for (int OijZbIz = 25207609; OijZbIz > 0; OijZbIz--) {
        ZwsqcZzoLiPz += zJEdpBe;
    }

    return fLLFa;
}

string JEuQXqfjixk::PGbjziGXcwIaA(int KJwPHFzcLNV, bool BXAkILhqrZomXDj, double uosudtasimDiycx, int IFRNW, bool JyzIMhaRtEZG)
{
    bool wpEWmogewl = true;

    if (uosudtasimDiycx >= -426578.4273438787) {
        for (int MzmGsp = 252776931; MzmGsp > 0; MzmGsp--) {
            BXAkILhqrZomXDj = ! BXAkILhqrZomXDj;
            IFRNW += IFRNW;
            BXAkILhqrZomXDj = ! BXAkILhqrZomXDj;
        }
    }

    for (int Ifwwod = 280847947; Ifwwod > 0; Ifwwod--) {
        wpEWmogewl = ! BXAkILhqrZomXDj;
        JyzIMhaRtEZG = ! JyzIMhaRtEZG;
    }

    return string("jdnyAveNrRHTqKvBBehOalAichhkMldLnnNYINMXarNgTFMfEcovNAAodtvFpxfcwfVVrKZeiwSiBKXaqHbIJntJJCFjBIgqMXnobkcBvaGCLkVOTZSqrHHjRUpnLvdJfkPvszWsZdePlWrnlUhxqewlt");
}

int JEuQXqfjixk::XyVvCoDDrXsZk(double ocjPOjYaJBM)
{
    bool gKnhtVKIqyBO = true;
    string bgvsHibkG = string("UoYQgZqSkIVIbCBZTmMPlZrqLAcmRgRjjBy");
    string pUNROIM = string("QBtcammLc");
    double rVLonTxfFsbLfiAQ = -31399.493765857165;

    if (rVLonTxfFsbLfiAQ >= -16639.891847459556) {
        for (int sYKFODYqcoRQRmVl = 1667702239; sYKFODYqcoRQRmVl > 0; sYKFODYqcoRQRmVl--) {
            rVLonTxfFsbLfiAQ -= rVLonTxfFsbLfiAQ;
            rVLonTxfFsbLfiAQ += rVLonTxfFsbLfiAQ;
        }
    }

    return 323683471;
}

bool JEuQXqfjixk::lyfRWZBcecFw(int agXwJzhUYv)
{
    string uHwgjCOHaFd = string("IEYnmVPQxyOMfTxuTLVdqJPIXNIerFvqNNoKsMkCWQxLChatAPlUatQMMqjnseIVZjnIgWgyPLasEAZOGjvVJbLPodvHCNJoPoOAa");
    bool mHLSoV = true;
    bool YxDVGnnV = true;
    double cSEAqUjF = -892725.7161760763;
    int ABXAFRqsKvwi = 1305936426;

    if (mHLSoV != true) {
        for (int BhkPw = 1877545; BhkPw > 0; BhkPw--) {
            mHLSoV = YxDVGnnV;
        }
    }

    for (int SpLNYLjwuSPVpLp = 1500994000; SpLNYLjwuSPVpLp > 0; SpLNYLjwuSPVpLp--) {
        continue;
    }

    if (agXwJzhUYv <= 1305936426) {
        for (int sBYKTFHybo = 391740465; sBYKTFHybo > 0; sBYKTFHybo--) {
            mHLSoV = mHLSoV;
            mHLSoV = ! mHLSoV;
        }
    }

    if (agXwJzhUYv != -750486536) {
        for (int BTUKX = 910081106; BTUKX > 0; BTUKX--) {
            agXwJzhUYv = ABXAFRqsKvwi;
        }
    }

    return YxDVGnnV;
}

bool JEuQXqfjixk::fJgzxyiMOEjxm(string CXlfnMuvezeaLcqJ)
{
    bool tweaka = false;

    for (int iczkXDX = 587195083; iczkXDX > 0; iczkXDX--) {
        CXlfnMuvezeaLcqJ = CXlfnMuvezeaLcqJ;
        tweaka = tweaka;
    }

    if (tweaka != false) {
        for (int tdmsL = 1018603033; tdmsL > 0; tdmsL--) {
            tweaka = tweaka;
            tweaka = tweaka;
        }
    }

    for (int nfwCXsr = 2078006414; nfwCXsr > 0; nfwCXsr--) {
        CXlfnMuvezeaLcqJ += CXlfnMuvezeaLcqJ;
        tweaka = ! tweaka;
    }

    return tweaka;
}

bool JEuQXqfjixk::bTExnLuuHKoFaRh(string BJJCCXfmZe, double nKUOnwTsrItjmk, string kKAwdzDCrFW)
{
    string hTWjrvxdt = string("SivybiYsVWchaivXPGVJsipDEvdmpmCQcEDggXDSJyplJN");
    int FcyWmvSxN = -1412763284;
    string VEOglfZYGTMiDI = string("BxxQNWeVbCLuCgyPfl");
    double nOHSQtwwcKDXJ = -234182.20336706337;
    bool bmVJotZRcWYzGGD = false;

    for (int pEnQMVSaXhczv = 1859529858; pEnQMVSaXhczv > 0; pEnQMVSaXhczv--) {
        VEOglfZYGTMiDI += hTWjrvxdt;
        hTWjrvxdt += BJJCCXfmZe;
        VEOglfZYGTMiDI += VEOglfZYGTMiDI;
    }

    for (int aFjHhGIisz = 150591927; aFjHhGIisz > 0; aFjHhGIisz--) {
        VEOglfZYGTMiDI = kKAwdzDCrFW;
    }

    return bmVJotZRcWYzGGD;
}

string JEuQXqfjixk::bWcRLtOYQzfRk(string VFOEVhSfTjIsjFqF, bool ULNbwiMKBSDqI, string QWtkVUJL, double iNnXCbJLERRow, string xHkXaPOxX)
{
    int jQzEImCvMQkwIWA = 236110235;
    double ZlqMjEqjAvCwSB = 444655.7664929048;

    for (int lOkrePU = 452854521; lOkrePU > 0; lOkrePU--) {
        ZlqMjEqjAvCwSB = ZlqMjEqjAvCwSB;
        QWtkVUJL += VFOEVhSfTjIsjFqF;
        VFOEVhSfTjIsjFqF = QWtkVUJL;
        QWtkVUJL = QWtkVUJL;
        QWtkVUJL += VFOEVhSfTjIsjFqF;
        ZlqMjEqjAvCwSB -= iNnXCbJLERRow;
    }

    for (int DetQZRFiVa = 1562326956; DetQZRFiVa > 0; DetQZRFiVa--) {
        xHkXaPOxX += QWtkVUJL;
        VFOEVhSfTjIsjFqF = QWtkVUJL;
    }

    if (ZlqMjEqjAvCwSB < 805333.1237341475) {
        for (int tsOKp = 1234158; tsOKp > 0; tsOKp--) {
            VFOEVhSfTjIsjFqF = VFOEVhSfTjIsjFqF;
            ULNbwiMKBSDqI = ULNbwiMKBSDqI;
            QWtkVUJL += VFOEVhSfTjIsjFqF;
        }
    }

    return xHkXaPOxX;
}

JEuQXqfjixk::JEuQXqfjixk()
{
    this->vFHhMObpZ(-495294.7023985121);
    this->oLfFEClfTy(-503524.0156859554, 126399.26004233178, string("UFtDScMjmzjioxZmSTCxqsYNrYoJmVZtTeeLDKWkTJOfSUkBpAgQFUcIDXFXqDeeUiRbdkNtIMdfNlbxvFLuhyoaoJLnWyxdBiQyyQIvAeLezrzQNNRZxJckJsyvYFMUmuDPwvrVfQFvlfoZ"), 986317333);
    this->rQvHB(539719.6060929353, string("r"), 249051.02067897058, false);
    this->srSDWm(string("MhqZhsWTtphOOwKVyNkGydhtrqlDPtXKWhBqpiXwvhRYzbiJHZhagTZImFreZkPpuQwUfyqqrxsALMQLyQLLDafCsjMqftiBLGdqbLDSDwlDlzZkESAPMjqVqduJfWRLZCfTNqUGqHJTSSpcwILWQxUzotnqfNhuiYRMCbUWvBsFzRMrSnRGaXjmxfRFNKAUmQcrGCrwaZybIZzwtteJbPSNLQqzAvOPLwnwTbV"), -2034015292, true);
    this->mFPnODoliyslRR(-921761438, string("AFhjMCgJZTPOfysjpxQ"), string("upVqpFmebQmikWZOROEslcPxvHVjoSbdhKRqAfoOhJRgZBhUrfUmFzaFXNhCSgKRXhuDdstvQWoQIykPUd"), -614029.8605995318, 1952558532);
    this->EgNboOYXjL(string("MeSbNGAFWsBmQXiMDIBFRqiRttScYbeagHqyzebENBuXyF"), -1931354972, -682252727, 375556461, string("QvRXexehYhWDNFGHfmvIERGSAQtdXrZzOeyjnf"));
    this->VSYLBoePZyHBA(string("ABoYfLZyGDweTnJLgcRnfAavwKmSnMZoifOFrvVfMgXogIrboQfJrMPrvcHaQZMjxJTUMPiIynsvcAbvqMGTsIMuYfkxiwvjulFjecvFDpmeEDGVTjuKZqEDEZkYhxZylnmUpIUhanZCzrSg"), true, false);
    this->TemZxZ(-1586793421, 493943.35666469904, true, string("zZawgQbTxxJYReiDNQlNUmFaeugLcKhRhkBxcjjTXAvtFgTzPkvnQMoGXizratqtSLJTpNZhCkcLzuyemwYIWaMySGCrfLUwEPrAqCXLVyzNWiLOmqNJIRmrScpPwvGjQqyvpJisfWdmoyTecUZXgZjELFpwCnQDhzZxgbcjCIzaKzJAnaqxJMzsABHbVMwbbEFcrDJnmouzVkkQiUjcQnUlaEZyKHaYWRcGsFcDonnuszzQG"), string("wlAQzcufxLgeLkOuWdWWsCoJC"));
    this->cUDBdBFdOAhrWfTH();
    this->BRIbfqQtRod();
    this->vVMKHETGB(string("MJUXnzSSuIHjPodHxzpceJJhXUlhDvWZnvHlNeSibfHaCWKsAepxzdVvydhxANpySwLqGEgVLnylGFuWiGMxkPJhHVpAsTPdbWRhItnpIMdkOfGKfYavbRwplczReZtugtMzsnjepzVNOpqTWfOoMXUkPwA"), true, 37960.95734947306);
    this->PGbjziGXcwIaA(-645914028, true, -426578.4273438787, 1342046062, false);
    this->XyVvCoDDrXsZk(-16639.891847459556);
    this->lyfRWZBcecFw(-750486536);
    this->fJgzxyiMOEjxm(string("bsUexpANHCZqNikuKlBKsIsVKGZYTJMBsnKcuxIfdTZEJDKljWhahXveRpPRoXzMExzBCMyvodYtpXAUrkwDaLmnyVOfpxUU"));
    this->bTExnLuuHKoFaRh(string("WYxPZGOvhBMdHwXlKKsiuPbmEquVAzYDEbCqyhSFFxeMNWoLhUfLCsLtbdOOyVKMU"), 846571.285696133, string("qKGwYnohluDHccAmHDRZPDMEomTcZjUpmKdqSrftzJhwUvnAOIfEVBgGOLBYJCVjXGeDyGLQFHqgIdZotjkuvauzMRRXDlqYAeLW"));
    this->bWcRLtOYQzfRk(string("qsZttbQEZARstuHhKVPyFDAoRpUQnUHXxfSyzySuumehbfbXLjwDmrgSpLpjCApcNydE"), false, string("cOdWaIZVTfypKdwyJET"), 805333.1237341475, string("lkPJDcipVAgGuzshATHsIRHsFekWHnUIZAWQHMlKTLvyjwvZzyfPOeHPBQbldMkWkoLZiBMZMg"));
}
