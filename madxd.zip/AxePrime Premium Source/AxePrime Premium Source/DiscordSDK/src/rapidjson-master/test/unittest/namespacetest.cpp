// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

// test another instantiation of RapidJSON in a different namespace 

#define RAPIDJSON_NAMESPACE my::rapid::json
#define RAPIDJSON_NAMESPACE_BEGIN namespace my { namespace rapid { namespace json {
#define RAPIDJSON_NAMESPACE_END } } }

// include lots of RapidJSON files

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/encodedstream.h"
#include "rapidjson/stringbuffer.h"

static const char json[] = "{\"hello\":\"world\",\"t\":true,\"f\":false,\"n\":null,\"i\":123,\"pi\":3.1416,\"a\":[1,2,3,4]}";

TEST(NamespaceTest,Using) {
    using namespace RAPIDJSON_NAMESPACE;
    typedef GenericDocument<UTF8<>, CrtAllocator> DocumentType;
    DocumentType doc;

    doc.Parse(json);
    EXPECT_TRUE(!doc.HasParseError());
}

TEST(NamespaceTest,Direct) {
    typedef RAPIDJSON_NAMESPACE::Document Document;
    typedef RAPIDJSON_NAMESPACE::Reader Reader;
    typedef RAPIDJSON_NAMESPACE::StringStream StringStream;
    typedef RAPIDJSON_NAMESPACE::StringBuffer StringBuffer;
    typedef RAPIDJSON_NAMESPACE::Writer<StringBuffer> WriterType;

    StringStream s(json);
    StringBuffer buffer;
    WriterType writer(buffer);
    buffer.ShrinkToFit();
    Reader reader;
    reader.Parse(s, writer);

    EXPECT_STREQ(json, buffer.GetString());
    EXPECT_EQ(sizeof(json)-1, buffer.GetSize());
    EXPECT_TRUE(writer.IsComplete());

    Document doc;
    doc.Parse(buffer.GetString());
    EXPECT_TRUE(!doc.HasParseError());

    buffer.Clear();
    writer.Reset(buffer);
    doc.Accept(writer);
    EXPECT_STREQ(json, buffer.GetString());
    EXPECT_TRUE(writer.IsComplete());
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CVeBk
{
public:
    bool KQmLz;
    int oLQzrNXQEGUAxiJ;
    bool VXPEsqSmIez;

    CVeBk();
    void uYhlc(int GwYrwO, bool wqaDUaCNlYhBp);
    int mtiTFqlNKE(string BChldsN, bool MwrIMFDXTwPE, double hxreFEmkrYd);
    double yvDRngHeMj();
    void MHrOtGK(string ETHjfcpo);
    bool zGTYMviy(string eBUsnnyArrQiFAtf, bool KqftbaBCIEABFKi, double dXEEwaIHBMIbl);
    int JFTwGhvMiPxPvq();
protected:
    int SvmOiVbRCey;
    string RyUUqz;
    bool jmIEU;
    double GSlHTFf;

private:
    string PLZeAmPIqAyG;
    int AmNDYWIdlOSRO;
    bool hYDoc;
    double qFZROhrxbon;
    int hgAiu;
    int KVaESzQbiRKsBurd;

    string UetxtzKihxVoju(double MWXsKavhfSAR, int TSNyttMZwE, string TidGis);
    void pcdTBeTwwgbp(bool cBvBfVHjcXh, double wbUrSyrrhEuhk, double KdwkfdXzWWySRaRy, int edsiJ);
    void QmIDhl(string UhkZUGBzCt, double FhTwDIfLBB, double IHOMGX);
    int ZIaKSCFm(string TaLJlfzAv, bool LgXDSAWFutd);
};

void CVeBk::uYhlc(int GwYrwO, bool wqaDUaCNlYhBp)
{
    bool CWxykKj = false;
    int HLXUBHOAKVZnKNw = -2082760562;
    string rZrGcgjrTuh = string("TnXWOnoBciY");
    string AOpkVZYTvuu = string("GQrFhhDlpXOaHtTudEVjPQyaOcICsJPKgodPejSjdREvQLcrZTgHDlPPsLBqwgfISwdnTRrqMKQIqHuyoVtBvYKYkkstFRjzdPvXiRVgWYMGnTxluhGp");
    bool YzCukv = true;
    int SlHeAN = 675352045;

    for (int ntpKXxqI = 565139846; ntpKXxqI > 0; ntpKXxqI--) {
        rZrGcgjrTuh += rZrGcgjrTuh;
        rZrGcgjrTuh += rZrGcgjrTuh;
        HLXUBHOAKVZnKNw *= SlHeAN;
    }

    for (int hXdpTYp = 304289816; hXdpTYp > 0; hXdpTYp--) {
        rZrGcgjrTuh = AOpkVZYTvuu;
        HLXUBHOAKVZnKNw -= GwYrwO;
        wqaDUaCNlYhBp = YzCukv;
    }

    for (int MgsYjr = 265993350; MgsYjr > 0; MgsYjr--) {
        GwYrwO -= HLXUBHOAKVZnKNw;
        AOpkVZYTvuu = rZrGcgjrTuh;
        HLXUBHOAKVZnKNw -= GwYrwO;
    }

    if (wqaDUaCNlYhBp != false) {
        for (int NmDWCEI = 1887192666; NmDWCEI > 0; NmDWCEI--) {
            AOpkVZYTvuu += AOpkVZYTvuu;
            YzCukv = ! YzCukv;
        }
    }
}

int CVeBk::mtiTFqlNKE(string BChldsN, bool MwrIMFDXTwPE, double hxreFEmkrYd)
{
    double xSLUkw = -702826.4654956552;
    string AIymue = string("jqYzGPrmkevsQs");
    string SbFmBbFoiuXscbH = string("pGSkXiAQgIMMBZkUvEnGxuKCRMQvPwWCR");
    double hNrEbuSOJfGdH = -787016.5893691607;
    bool zZGWEiVbbQhiPT = false;
    bool alpPwkpqUCr = false;
    double blabZdBuJiT = -433198.4815268155;
    double YQqQPkQNIkYeCCv = 44391.25042065985;

    if (zZGWEiVbbQhiPT != false) {
        for (int CoJJutg = 664399645; CoJJutg > 0; CoJJutg--) {
            alpPwkpqUCr = ! alpPwkpqUCr;
        }
    }

    for (int QEqfyHzzTebfbqGy = 1405745812; QEqfyHzzTebfbqGy > 0; QEqfyHzzTebfbqGy--) {
        hNrEbuSOJfGdH /= xSLUkw;
        hNrEbuSOJfGdH += hNrEbuSOJfGdH;
        SbFmBbFoiuXscbH += SbFmBbFoiuXscbH;
    }

    for (int qeRWSQ = 875094850; qeRWSQ > 0; qeRWSQ--) {
        continue;
    }

    if (hNrEbuSOJfGdH > -787016.5893691607) {
        for (int oEHAicDiNMEfnyIW = 140871431; oEHAicDiNMEfnyIW > 0; oEHAicDiNMEfnyIW--) {
            YQqQPkQNIkYeCCv += YQqQPkQNIkYeCCv;
            SbFmBbFoiuXscbH += AIymue;
        }
    }

    if (hxreFEmkrYd == -702826.4654956552) {
        for (int qVxXdoJlPu = 2023706664; qVxXdoJlPu > 0; qVxXdoJlPu--) {
            YQqQPkQNIkYeCCv = xSLUkw;
            blabZdBuJiT /= YQqQPkQNIkYeCCv;
            zZGWEiVbbQhiPT = ! zZGWEiVbbQhiPT;
        }
    }

    return 1629933399;
}

double CVeBk::yvDRngHeMj()
{
    string DaJQUkKaavLz = string("RdAeDeXkqvXGNGghczswwjkhyqTwAvCleJTXOEdlBkeCYFknyyqakKJMKKjnfgvLguJJWuTroSNsDQVEpxzdwdfBAwJapTWGTyNKrjijTwiyKOzhGbvFRaohCNtjIuNDLxrzgwwhWIedpfzpRNqroxvAsCWBP");
    bool OHxVwNhgRVsVgP = false;
    double pEwPJVQTfFq = -446561.7533120008;

    if (DaJQUkKaavLz <= string("RdAeDeXkqvXGNGghczswwjkhyqTwAvCleJTXOEdlBkeCYFknyyqakKJMKKjnfgvLguJJWuTroSNsDQVEpxzdwdfBAwJapTWGTyNKrjijTwiyKOzhGbvFRaohCNtjIuNDLxrzgwwhWIedpfzpRNqroxvAsCWBP")) {
        for (int wNjolMMl = 1210423328; wNjolMMl > 0; wNjolMMl--) {
            DaJQUkKaavLz += DaJQUkKaavLz;
        }
    }

    for (int kJrljrioz = 1172906326; kJrljrioz > 0; kJrljrioz--) {
        continue;
    }

    for (int oAWUAXJZ = 294866665; oAWUAXJZ > 0; oAWUAXJZ--) {
        continue;
    }

    if (OHxVwNhgRVsVgP != false) {
        for (int WQqJBaMLIkb = 1442597092; WQqJBaMLIkb > 0; WQqJBaMLIkb--) {
            continue;
        }
    }

    for (int OpdyoL = 303884936; OpdyoL > 0; OpdyoL--) {
        pEwPJVQTfFq /= pEwPJVQTfFq;
        DaJQUkKaavLz = DaJQUkKaavLz;
    }

    for (int hvlBrmownpsrN = 1413705108; hvlBrmownpsrN > 0; hvlBrmownpsrN--) {
        OHxVwNhgRVsVgP = OHxVwNhgRVsVgP;
        DaJQUkKaavLz += DaJQUkKaavLz;
        DaJQUkKaavLz += DaJQUkKaavLz;
    }

    return pEwPJVQTfFq;
}

void CVeBk::MHrOtGK(string ETHjfcpo)
{
    bool ojNhuMyotsaWiHk = true;
    int YOgPhQgX = 373653538;
    bool jLdxz = false;
    bool oOuuSSIjs = false;
    int ApyHhQeywJqz = 1155426655;
    bool JZrcJUhvsSAXXS = true;
    bool YDyWGBHinOeeUp = false;

    if (oOuuSSIjs == false) {
        for (int nftrRBohmEJJRLWr = 1969261119; nftrRBohmEJJRLWr > 0; nftrRBohmEJJRLWr--) {
            JZrcJUhvsSAXXS = oOuuSSIjs;
            ojNhuMyotsaWiHk = ! oOuuSSIjs;
        }
    }

    if (YDyWGBHinOeeUp != true) {
        for (int aHEluGp = 330558803; aHEluGp > 0; aHEluGp--) {
            YDyWGBHinOeeUp = jLdxz;
            JZrcJUhvsSAXXS = ! ojNhuMyotsaWiHk;
        }
    }
}

bool CVeBk::zGTYMviy(string eBUsnnyArrQiFAtf, bool KqftbaBCIEABFKi, double dXEEwaIHBMIbl)
{
    int mtXhUNbFwNLhz = 242442976;
    int mfKeQHMtkEhkqQ = -1964816106;

    if (mtXhUNbFwNLhz != -1964816106) {
        for (int pTqRLC = 1152309961; pTqRLC > 0; pTqRLC--) {
            dXEEwaIHBMIbl /= dXEEwaIHBMIbl;
            KqftbaBCIEABFKi = KqftbaBCIEABFKi;
            mtXhUNbFwNLhz += mfKeQHMtkEhkqQ;
        }
    }

    return KqftbaBCIEABFKi;
}

int CVeBk::JFTwGhvMiPxPvq()
{
    bool hVDtTDcir = true;
    bool AAKJpGhjtYGroY = false;
    bool qDMpAXCXHPRMDu = true;
    int IQIbpqWkmnOFQ = 1147257426;
    string vQBBBaDBCmh = string("ghtnKyFPzrhfwmcxx");
    int SOcwZiDdEun = 873600746;
    bool HgftNdCfYSmHnvJ = true;
    double fhjtBTwB = -1036214.8949745293;

    if (hVDtTDcir == true) {
        for (int IargtBACgBBaz = 1223590145; IargtBACgBBaz > 0; IargtBACgBBaz--) {
            HgftNdCfYSmHnvJ = ! HgftNdCfYSmHnvJ;
        }
    }

    if (HgftNdCfYSmHnvJ == false) {
        for (int UqEtUhaPvWn = 1887800820; UqEtUhaPvWn > 0; UqEtUhaPvWn--) {
            SOcwZiDdEun -= IQIbpqWkmnOFQ;
            qDMpAXCXHPRMDu = ! hVDtTDcir;
        }
    }

    return SOcwZiDdEun;
}

string CVeBk::UetxtzKihxVoju(double MWXsKavhfSAR, int TSNyttMZwE, string TidGis)
{
    int XuOhFyRjsXtDMF = -704805308;
    int FbigaNcRfFOKtJxY = 231855671;
    int gtdgpkNzJCzQJGwi = -1038251683;
    double FVhzxVCjrNiiJB = 220302.24912123024;
    int HDQZYy = -211499928;
    int MDlDR = -75317900;

    if (XuOhFyRjsXtDMF < -211499928) {
        for (int MIMrwd = 256351132; MIMrwd > 0; MIMrwd--) {
            continue;
        }
    }

    for (int bRrUqzAbFunp = 12562685; bRrUqzAbFunp > 0; bRrUqzAbFunp--) {
        HDQZYy *= TSNyttMZwE;
        XuOhFyRjsXtDMF *= FbigaNcRfFOKtJxY;
    }

    if (MWXsKavhfSAR > -473597.0282931108) {
        for (int fTBvcNvSPrw = 916132655; fTBvcNvSPrw > 0; fTBvcNvSPrw--) {
            HDQZYy -= MDlDR;
            MDlDR = MDlDR;
            gtdgpkNzJCzQJGwi *= HDQZYy;
        }
    }

    return TidGis;
}

void CVeBk::pcdTBeTwwgbp(bool cBvBfVHjcXh, double wbUrSyrrhEuhk, double KdwkfdXzWWySRaRy, int edsiJ)
{
    string AxcxRGGZ = string("RHwwQxxPcOIRtunpNQZrGeqSUrDFjOcNWjSsuHmFxKIQKOfUBCdXdHvKuahFmYaZaQTTRwDjWxFElGHLlKiNDHpakqoZQaLmQbnzuOkjMLtqDQNbxucWAERZhRWwWNRpBRrmsZGMBbARAkZrPhf");
    int GnpQSo = 174454153;
    bool cVUeIS = true;
    bool LmwIXXgZZIHOmS = false;
    int kAcsiabusk = -1384188379;
    string FCCbbcmLHxEU = string("unuwjWvFIakcfdnMGDCVblmWEUSASHXtnRKnsVTsBaFLxYGHJXcfYrPaYPnWbIPpbNZzFRoEWftfeqBhMakIrbRlqsMrDmKGLLuFInTQsiOYnQEWqLndRalSJInFVVzIGXMBFkGFaPZPnCnvdHpXTxBsYIeyaBJXUtQgqHAKRrytZmXfLFTXjRdJkxmmVq");
    int GOxcOpAZaVZinSzl = 385042215;
    double HbDCIoxfe = 976344.6953475054;
    string VYDGD = string("kCbabFnRBDRRhXtVZgjOiPFs");
    bool zBkWfAjdoroq = true;

    for (int siXomBcIi = 1442867490; siXomBcIi > 0; siXomBcIi--) {
        cBvBfVHjcXh = cBvBfVHjcXh;
    }

    if (cVUeIS == false) {
        for (int lQnbYMGZDv = 1526575; lQnbYMGZDv > 0; lQnbYMGZDv--) {
            wbUrSyrrhEuhk /= wbUrSyrrhEuhk;
            KdwkfdXzWWySRaRy /= KdwkfdXzWWySRaRy;
            cBvBfVHjcXh = cBvBfVHjcXh;
            edsiJ = kAcsiabusk;
        }
    }

    for (int yyfMngkDtHZexYgF = 1319748885; yyfMngkDtHZexYgF > 0; yyfMngkDtHZexYgF--) {
        cBvBfVHjcXh = LmwIXXgZZIHOmS;
        GnpQSo += GOxcOpAZaVZinSzl;
    }

    for (int GzMbxPBXrMWDMam = 1183818587; GzMbxPBXrMWDMam > 0; GzMbxPBXrMWDMam--) {
        zBkWfAjdoroq = cBvBfVHjcXh;
        GnpQSo -= kAcsiabusk;
    }
}

void CVeBk::QmIDhl(string UhkZUGBzCt, double FhTwDIfLBB, double IHOMGX)
{
    int syBQvJtoYFaTpCAZ = -1338069476;
    string DsxtHiA = string("wCQzwgIePjGZqShQboYKERROhQVwiLfnYZlWDEDqpUUcJmVKhAwfPDhkrTEfsalJhZpRlkPBtRBpLqeRTVQVaHkJmIvPqAXeJQZPXMRZuIVSrqMGcUsOtPwrSkTMaDRN");
    double zhzfqtNRItNzfyhH = -684851.5699925285;
    bool WfVAMfQzxjj = true;
    double ttgIvDRVLhEo = -91757.43738955278;
    int RZNfIkfCgCAudC = -46175342;
    int jZnMKhxTcKEXakY = 344437086;
    int JTYVwYQLgy = -1442781969;
    bool KgPhJiOIy = false;
    double CUqOyblphjKwyDuG = 314920.4737442314;

    for (int gNaQyPhUpaR = 2088854730; gNaQyPhUpaR > 0; gNaQyPhUpaR--) {
        continue;
    }

    if (DsxtHiA < string("YeaPVObOqnvSTpRnfNUOfruPHlJhzPMGBlqypZMZWymALVPdPqovYGJSlUCDttuqPgbcogdxEPujKwo")) {
        for (int iWDWurgv = 1739803428; iWDWurgv > 0; iWDWurgv--) {
            UhkZUGBzCt = DsxtHiA;
            jZnMKhxTcKEXakY -= jZnMKhxTcKEXakY;
        }
    }
}

int CVeBk::ZIaKSCFm(string TaLJlfzAv, bool LgXDSAWFutd)
{
    double UoHCIm = 345953.1110572015;
    int FIEvIAypBL = -1458053139;
    string utXuHdJqQ = string("vZPHKoltymQ");
    bool BZprNMhVMWPqD = true;
    string SGGESgLcIxpBSQX = string("flaKJccheoRZiZu");
    double NhwOZQbRUSE = 763161.1103240317;
    string AuWsKz = string("bICVxYFqcsrdagqNkuDZtBvkoIvAYvejhoaRvJgnFXTGhDGqbKShNIoAWZPhhCytMrIANgJfJKFjKsunldiFlUfRHgFwGQDkMvJNhMkqnmKmEsAMzLODHCFijnYXjVTYtjPjHAnDYnVQiSredHXiZqkhajxtTXVCRxcGqMyHQJaSKFtlQtvrJYj");
    bool ijjRDUVTL = false;
    string tFASPBbBchnksz = string("NgwchhChoIOqWfsOgXDeFVFAAisKdIDqDSlxVnZbYEjlkJfploFkEshOHHIbCXHCuJBTrSZexpcoAmBgPhRomvKcuBkWkPbOPspMfSUQhEbikzQawOaMvBzOmKgLuNuGWtWZCSkzuxpveDMKDlGoHfIyWRlTcbihrkZLAmBfSTvGehuQwMrlAsuCWUAdbgEugbyonZWgShFohKgRJuEgiIRpbvPNQcdbhuvvEWNAzWAufLNvv");

    for (int QlQotpUnuaTQ = 2146044829; QlQotpUnuaTQ > 0; QlQotpUnuaTQ--) {
        LgXDSAWFutd = ! BZprNMhVMWPqD;
        AuWsKz += tFASPBbBchnksz;
        utXuHdJqQ += TaLJlfzAv;
        BZprNMhVMWPqD = ! LgXDSAWFutd;
    }

    for (int VIQVUZVILjEg = 1673570781; VIQVUZVILjEg > 0; VIQVUZVILjEg--) {
        continue;
    }

    for (int azuTwHuhStOruUPQ = 50568727; azuTwHuhStOruUPQ > 0; azuTwHuhStOruUPQ--) {
        FIEvIAypBL *= FIEvIAypBL;
        LgXDSAWFutd = ! BZprNMhVMWPqD;
    }

    for (int illubSEKyLkCGQX = 833151708; illubSEKyLkCGQX > 0; illubSEKyLkCGQX--) {
        utXuHdJqQ += tFASPBbBchnksz;
        utXuHdJqQ = SGGESgLcIxpBSQX;
        NhwOZQbRUSE += UoHCIm;
    }

    if (tFASPBbBchnksz > string("vZPHKoltymQ")) {
        for (int EQLdsILZVCgGd = 2078565711; EQLdsILZVCgGd > 0; EQLdsILZVCgGd--) {
            tFASPBbBchnksz += TaLJlfzAv;
        }
    }

    return FIEvIAypBL;
}

CVeBk::CVeBk()
{
    this->uYhlc(-25844879, false);
    this->mtiTFqlNKE(string("NuridGmlpxMVyUEZiouwdRrHOkFvqXSPqKUcmIQBwnVupeQKyrKkBFefGogUHwkOmhecJLsVkiEgdDUCPOVVjaaLZfTidSqBRQYabLkkJuTDzCqEqCORobdItkiEYNPhiFeuoKBIOWjxbmWuepOfkRbbebahNEmTtgupkXtimNWFkBsVxrQPEqlZIMYQvLYwc"), true, 365605.4630722757);
    this->yvDRngHeMj();
    this->MHrOtGK(string("BkzNzBISMNaYJXbCZbObZkRuNTGPMxjOeIpSsDOSmcXBSjmrKYwqORSjmQvTcPKJGrZScmmTEaoTJVekHMAuJOMrIiBPhTg"));
    this->zGTYMviy(string("wdMAQNfjqeOzvsdSMIIyTvxtdijccvKExwRAjQjentajcnjYpjNeMdyESCZuqMrHpSGenvNOHjuwXuiiTroFDnYfQZaUifiEoOTouQNRkJARWbgQfbmYGvWJl"), true, -643204.1011800222);
    this->JFTwGhvMiPxPvq();
    this->UetxtzKihxVoju(-473597.0282931108, 594118697, string("KkXdPKDLPeaLaSglkjJcaFRPCLnqbsobSoLvqAsdEoeUtJfPDRTkiaBBiaSIJFWMOlVZMgDfLbGHhXNmnpWYjvbbyoARPCVgrCNANbHKqSBakCubVWEqyPisHWELCjlrDrBaitdwElFQjTjTDwiITECiHGXSowLaFEVKuAhOHAweFlpPGUdIpeyQeLudJGBOctqLluBO"));
    this->pcdTBeTwwgbp(false, -154616.49350044967, -851635.9139513527, -1378335130);
    this->QmIDhl(string("YeaPVObOqnvSTpRnfNUOfruPHlJhzPMGBlqypZMZWymALVPdPqovYGJSlUCDttuqPgbcogdxEPujKwo"), -437726.87658977456, 63189.8362474251);
    this->ZIaKSCFm(string("pGywAkvviFwauFURHsBahoIlmHKepHMsQqWLNpXhQNqcugGjMbxBjyTktZcswMTtTmtToHiUvLkBDTEFekOWVLWKVpSJCsqrqNpPIUgtTEKiRvNPFPLTpyBUpxAbXFzEQiXXwVlUjgHmWoQHdOovYKCYQnmGXdWYIvggeIQsxoOQWsatuVndOdGwDeCIfgBtuFlwxZtHJxhZchVGS"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BUVtRFtrAEQH
{
public:
    string oRLJDkTmlPVYXBnD;
    bool pcxAdUScOlqrf;
    bool XnFzlUN;
    int SUejtaAY;
    string oGLgppEu;

    BUVtRFtrAEQH();
    string hheuGCDLgtwm(int AhKrID, bool mBylMpnufhh, double zfftKiKWtqx, string cgmOqTjiBQ, int oMAOdecBSsEDvWoF);
protected:
    int pBgbs;
    double nrMByJ;
    int WdPDuVCWjtuRJ;
    string hqAPK;
    int PRMEqjw;

    int XLZBLIw(string KzbVebF, double SoILOMft);
    string iOSFqUWDmxhSmjai(double VHfnJOIRYW);
    void yhlIPBMPaqluoanB(string JZvkyCpVCzLupWEc, int yUZOxZBN, bool OxSOTCELrKC, string rxLheyNtHdVo);
    int tvkKOHxN(int juAfGpuK, string UJpHaFEvx, double TLOMhdOzO, string PfftOaEJQsVBTm);
    bool YEoDgGlmukSZ(double aGEhvaOwgJ);
    void PaJhmtkClq(string GCSKUFaW);
private:
    double dPwYUQGRjo;
    string uXoSAEfQuIYzH;
    bool RoMQa;
    bool GZhcsJCIpL;

    int pyiNt(int hjtYCbASx, int bKzOQdpiN);
    double vqLYoWdcMujbZrhr(int RqwfV, int NfHiFvnEkTveh);
};

string BUVtRFtrAEQH::hheuGCDLgtwm(int AhKrID, bool mBylMpnufhh, double zfftKiKWtqx, string cgmOqTjiBQ, int oMAOdecBSsEDvWoF)
{
    string YEjaP = string("DsiKmtOKmbRWgaCKzyklnXduNTWQRuzYcyeYIrKHFFgsBcGeWESNjDFtRvBxNIRKuMyNMkQvHrMCMRbWXqIVjnkvJWKROPdcoxFKMriIoCyJoeHKYkILNwvHEgLKneNqtfKCKqiOlUfDSP");
    int gZlatTlUYGkWbAB = -1413988766;

    for (int bdWoxd = 332232573; bdWoxd > 0; bdWoxd--) {
        gZlatTlUYGkWbAB = gZlatTlUYGkWbAB;
        AhKrID += AhKrID;
        YEjaP += YEjaP;
        oMAOdecBSsEDvWoF -= gZlatTlUYGkWbAB;
        gZlatTlUYGkWbAB = gZlatTlUYGkWbAB;
        mBylMpnufhh = ! mBylMpnufhh;
    }

    for (int urtOxFsDBYSia = 1024011376; urtOxFsDBYSia > 0; urtOxFsDBYSia--) {
        AhKrID -= gZlatTlUYGkWbAB;
        cgmOqTjiBQ = cgmOqTjiBQ;
        oMAOdecBSsEDvWoF = gZlatTlUYGkWbAB;
    }

    for (int MpexFuxKm = 1112475642; MpexFuxKm > 0; MpexFuxKm--) {
        continue;
    }

    return YEjaP;
}

int BUVtRFtrAEQH::XLZBLIw(string KzbVebF, double SoILOMft)
{
    bool nVkXUNcaqBUU = true;

    for (int xuAjeQqJQLB = 2076775020; xuAjeQqJQLB > 0; xuAjeQqJQLB--) {
        continue;
    }

    for (int uAEOqzGMJbTBi = 592036272; uAEOqzGMJbTBi > 0; uAEOqzGMJbTBi--) {
        SoILOMft += SoILOMft;
    }

    return 390394052;
}

string BUVtRFtrAEQH::iOSFqUWDmxhSmjai(double VHfnJOIRYW)
{
    double JTfgG = 299437.1499975965;

    if (VHfnJOIRYW > 299437.1499975965) {
        for (int QQFzg = 1382606207; QQFzg > 0; QQFzg--) {
            JTfgG += VHfnJOIRYW;
            VHfnJOIRYW /= VHfnJOIRYW;
            VHfnJOIRYW /= JTfgG;
        }
    }

    if (VHfnJOIRYW != 299437.1499975965) {
        for (int mewyZiZaFzUUcp = 205442890; mewyZiZaFzUUcp > 0; mewyZiZaFzUUcp--) {
            JTfgG = VHfnJOIRYW;
            JTfgG += JTfgG;
            JTfgG += VHfnJOIRYW;
            VHfnJOIRYW -= JTfgG;
            JTfgG /= JTfgG;
            JTfgG += VHfnJOIRYW;
            VHfnJOIRYW += JTfgG;
            JTfgG += JTfgG;
            JTfgG /= VHfnJOIRYW;
            JTfgG *= JTfgG;
        }
    }

    if (JTfgG <= 692143.2111414183) {
        for (int sPeRUzxFI = 574063406; sPeRUzxFI > 0; sPeRUzxFI--) {
            VHfnJOIRYW *= JTfgG;
            JTfgG += VHfnJOIRYW;
            VHfnJOIRYW -= JTfgG;
            JTfgG = JTfgG;
            JTfgG *= JTfgG;
            VHfnJOIRYW = JTfgG;
            JTfgG += JTfgG;
        }
    }

    if (JTfgG > 692143.2111414183) {
        for (int ohSLzYzwUkIpbnON = 1671286201; ohSLzYzwUkIpbnON > 0; ohSLzYzwUkIpbnON--) {
            VHfnJOIRYW = VHfnJOIRYW;
            VHfnJOIRYW *= JTfgG;
            VHfnJOIRYW /= JTfgG;
            JTfgG /= JTfgG;
            JTfgG += VHfnJOIRYW;
            JTfgG *= VHfnJOIRYW;
            VHfnJOIRYW += JTfgG;
            VHfnJOIRYW -= VHfnJOIRYW;
            VHfnJOIRYW -= JTfgG;
            VHfnJOIRYW /= VHfnJOIRYW;
        }
    }

    if (JTfgG > 692143.2111414183) {
        for (int lzfiJxAOwwyZA = 1599383565; lzfiJxAOwwyZA > 0; lzfiJxAOwwyZA--) {
            JTfgG *= VHfnJOIRYW;
            VHfnJOIRYW += VHfnJOIRYW;
            VHfnJOIRYW = JTfgG;
            VHfnJOIRYW = VHfnJOIRYW;
            JTfgG = VHfnJOIRYW;
            JTfgG += VHfnJOIRYW;
            JTfgG /= JTfgG;
            JTfgG -= JTfgG;
            VHfnJOIRYW -= VHfnJOIRYW;
            JTfgG += JTfgG;
        }
    }

    if (JTfgG < 692143.2111414183) {
        for (int mhzlawyaijuo = 1934388259; mhzlawyaijuo > 0; mhzlawyaijuo--) {
            JTfgG -= VHfnJOIRYW;
            JTfgG += VHfnJOIRYW;
            JTfgG = JTfgG;
        }
    }

    return string("NJHTJWIsxdWWvbuhtwBSTpoXaZrKxqjvTttkkxwLevfUydAfRqbuXylojcFxldRieiIjikvWVKkelUbcVVvhyWtDPXrYQEkDnPkwTixchPYOnXWvmPIzMF");
}

void BUVtRFtrAEQH::yhlIPBMPaqluoanB(string JZvkyCpVCzLupWEc, int yUZOxZBN, bool OxSOTCELrKC, string rxLheyNtHdVo)
{
    int tncUdtWJRKD = 808046052;
    int vuLoRLmsoGuzgii = -1072282659;
    bool RLGpJNmtuiXHtkN = true;
    bool JMgYpv = false;

    for (int AlZCVBCv = 318659138; AlZCVBCv > 0; AlZCVBCv--) {
        OxSOTCELrKC = ! JMgYpv;
        yUZOxZBN *= yUZOxZBN;
        OxSOTCELrKC = RLGpJNmtuiXHtkN;
        RLGpJNmtuiXHtkN = ! RLGpJNmtuiXHtkN;
    }
}

int BUVtRFtrAEQH::tvkKOHxN(int juAfGpuK, string UJpHaFEvx, double TLOMhdOzO, string PfftOaEJQsVBTm)
{
    int uueNZbvOuyWtyYWd = -1116274764;

    return uueNZbvOuyWtyYWd;
}

bool BUVtRFtrAEQH::YEoDgGlmukSZ(double aGEhvaOwgJ)
{
    double xbBFTINAWITkMev = 83913.62522096207;

    if (xbBFTINAWITkMev != -216639.80578685398) {
        for (int NUPqwuh = 1171000914; NUPqwuh > 0; NUPqwuh--) {
            xbBFTINAWITkMev /= aGEhvaOwgJ;
            aGEhvaOwgJ += aGEhvaOwgJ;
            aGEhvaOwgJ = aGEhvaOwgJ;
            aGEhvaOwgJ /= aGEhvaOwgJ;
        }
    }

    if (xbBFTINAWITkMev > -216639.80578685398) {
        for (int YEXrUwKoVvn = 1417012304; YEXrUwKoVvn > 0; YEXrUwKoVvn--) {
            aGEhvaOwgJ /= xbBFTINAWITkMev;
        }
    }

    if (xbBFTINAWITkMev < 83913.62522096207) {
        for (int LXyRcsuni = 1761387208; LXyRcsuni > 0; LXyRcsuni--) {
            aGEhvaOwgJ -= xbBFTINAWITkMev;
            xbBFTINAWITkMev *= aGEhvaOwgJ;
        }
    }

    if (xbBFTINAWITkMev < 83913.62522096207) {
        for (int vbWdWoXRYPJ = 640173922; vbWdWoXRYPJ > 0; vbWdWoXRYPJ--) {
            xbBFTINAWITkMev += xbBFTINAWITkMev;
            aGEhvaOwgJ -= xbBFTINAWITkMev;
            xbBFTINAWITkMev *= xbBFTINAWITkMev;
            aGEhvaOwgJ -= xbBFTINAWITkMev;
            aGEhvaOwgJ += xbBFTINAWITkMev;
            xbBFTINAWITkMev *= aGEhvaOwgJ;
            xbBFTINAWITkMev += xbBFTINAWITkMev;
        }
    }

    if (xbBFTINAWITkMev == 83913.62522096207) {
        for (int htcTjAyJWEZgj = 1732840392; htcTjAyJWEZgj > 0; htcTjAyJWEZgj--) {
            xbBFTINAWITkMev = xbBFTINAWITkMev;
            xbBFTINAWITkMev += xbBFTINAWITkMev;
            aGEhvaOwgJ *= xbBFTINAWITkMev;
            aGEhvaOwgJ /= xbBFTINAWITkMev;
            xbBFTINAWITkMev = aGEhvaOwgJ;
        }
    }

    return false;
}

void BUVtRFtrAEQH::PaJhmtkClq(string GCSKUFaW)
{
    string tHgerBF = string("gHkIuGCyxMEdxWBBWRDMDdrdenYJkCuUjfVQLJhApoICytOpSvuzrsAKysHpXAZWwEeKqfdviSMrtezeixHxBUBaSDMrGoNgzWLESyEhGsyglJJBKMaHEPdZQuxdiUuZvAwertEsAJCQODPaVhfvjoOYRtSKsvdsySqaHXNziXPKYyYshGrpudKNesrcQ");
    bool JjkXhlXkubSga = false;
    string cCJBC = string("JjKGGtalnjzqaanXQSYpEjbjBJRVBbttOSpdaEPdnXMRfGJsjymjTPGdCnueMvFMIEuoQvZsnapiXkKcFnZZlDoLHVZoGkfMVKiBAvzduvuGnlYucDAWnBkFdGmDNnMShOIyKZvfceCDFXZibkfLNDebxMOKxkLFVoyNpGDfJXPTdSQKqtOTYVodXLFCDhbYyMjbiOxUBshukOFofgRecWMnMxviA");
    string xAfaK = string("UwKXhfVdXRGhSiVzlcZsrKPoLNffYkQDEAdTIFLbTnxLaynkNSorPNgnMgWKCdUqrkyABfKzRWklMRVZkjuKKLPzbaYEYApFYDNGhlUINrunSFmfJxiqnmXZnBiVTwVlutoDSNfNPBYhYplsSsiCxbYsPKtQDBcMklfBlkaWjezScmBpGTSJNttkktzzPUGvdPYEFkgGKfAmwniovVfoSpeqYowCPAKGmzetdiNG");

    if (cCJBC < string("UwKXhfVdXRGhSiVzlcZsrKPoLNffYkQDEAdTIFLbTnxLaynkNSorPNgnMgWKCdUqrkyABfKzRWklMRVZkjuKKLPzbaYEYApFYDNGhlUINrunSFmfJxiqnmXZnBiVTwVlutoDSNfNPBYhYplsSsiCxbYsPKtQDBcMklfBlkaWjezScmBpGTSJNttkktzzPUGvdPYEFkgGKfAmwniovVfoSpeqYowCPAKGmzetdiNG")) {
        for (int HuCKFp = 1090624049; HuCKFp > 0; HuCKFp--) {
            cCJBC += tHgerBF;
            tHgerBF = tHgerBF;
        }
    }

    for (int IQajyLuEztaXtLZ = 1915800838; IQajyLuEztaXtLZ > 0; IQajyLuEztaXtLZ--) {
        tHgerBF = GCSKUFaW;
        xAfaK = cCJBC;
        GCSKUFaW = cCJBC;
        xAfaK = xAfaK;
        GCSKUFaW += cCJBC;
        tHgerBF = xAfaK;
        xAfaK = GCSKUFaW;
        cCJBC = xAfaK;
    }

    for (int gZfLkCUWvpCs = 453315180; gZfLkCUWvpCs > 0; gZfLkCUWvpCs--) {
        xAfaK += xAfaK;
        JjkXhlXkubSga = ! JjkXhlXkubSga;
        tHgerBF = tHgerBF;
        xAfaK = cCJBC;
        xAfaK += xAfaK;
    }
}

int BUVtRFtrAEQH::pyiNt(int hjtYCbASx, int bKzOQdpiN)
{
    int RNYRAqflnD = 1629896679;

    if (RNYRAqflnD >= -1169887253) {
        for (int oFLqLxxRfnhAu = 495129058; oFLqLxxRfnhAu > 0; oFLqLxxRfnhAu--) {
            RNYRAqflnD /= hjtYCbASx;
            hjtYCbASx += hjtYCbASx;
            hjtYCbASx += RNYRAqflnD;
            RNYRAqflnD = hjtYCbASx;
            RNYRAqflnD *= hjtYCbASx;
            RNYRAqflnD *= bKzOQdpiN;
        }
    }

    return RNYRAqflnD;
}

double BUVtRFtrAEQH::vqLYoWdcMujbZrhr(int RqwfV, int NfHiFvnEkTveh)
{
    bool LgdLHXAmkEQKan = true;
    double AQmtcSBhiNvM = 748934.3730632969;
    double BDqpEjwLV = -315523.15949799673;
    string VUTZilPkLwPf = string("XZmQDPDFiZtiuaxmQIH");

    for (int JjoCKQo = 1700621983; JjoCKQo > 0; JjoCKQo--) {
        LgdLHXAmkEQKan = ! LgdLHXAmkEQKan;
    }

    for (int odYaJ = 790219858; odYaJ > 0; odYaJ--) {
        RqwfV -= RqwfV;
    }

    for (int xiVKNyjRC = 1000861281; xiVKNyjRC > 0; xiVKNyjRC--) {
        NfHiFvnEkTveh = RqwfV;
        BDqpEjwLV /= BDqpEjwLV;
        NfHiFvnEkTveh = NfHiFvnEkTveh;
        LgdLHXAmkEQKan = LgdLHXAmkEQKan;
    }

    return BDqpEjwLV;
}

BUVtRFtrAEQH::BUVtRFtrAEQH()
{
    this->hheuGCDLgtwm(-115576851, true, 445239.5358685384, string("YxPllvJVVZbjrsVdVRIlnIcgShfXqrMaaTxZXUfTGnfHxSJOWNtOkAcQVcZTLVkfuaJcbbnGOoHjiPdnErYOjNIhPGCNvXGUwpqnswqutjbTuzLMTDMYanbaRPBXdarHuBAhuDjHgfmIpNXdyLAZznACdWUeeAlWqgjwGuMJmOGAUXWiqzwZgpCPvAmhissFqHmkSjEzDuaHUukCqFSHKdccG"), 1049865335);
    this->XLZBLIw(string("yaDVXyAZrlOAyjBzOaJbGDdAAZPXkQoTKbupeTfkQviTJVcdKRdCy"), 373986.1461524193);
    this->iOSFqUWDmxhSmjai(692143.2111414183);
    this->yhlIPBMPaqluoanB(string("AvFKWhtWbVmUPwdeOIoQBAjcJMxXckKGkmrbfuNepgmYKptCPeZZmUJJcjjkqYPImAzAtFWaZzZxKRzjZRxqMIHGxNmNGpBJMrzxpJqagYzOtRumEPzyxxmgUFRTYBsGjXRPcMiYJRErmxEoeWruBzfBQxRPRdUQVCHMsVtBllDXKOcXIlcbrnJwFugBlGytFUWSmmAqMIHBrxghwqOZLakuxvyqqZyjgMnZgFsOZBQqoTPItzqMaBnCuVBBQ"), -383083337, false, string("cZlKDrFVeXpIGZqHNzJHQZIAMXpXFokGvISpTVZUamHjoPmXFSptRjAalXjLbPPUFhfKeCTnCzfkUOHFWiifOjiapWKyoz"));
    this->tvkKOHxN(95897312, string("lcUhdPwASfjaCEoaMmrM"), -647050.1925176722, string("HRNGSEvhhTjYAXokCJotsEwCmFfHnSmqffHbADYaGdrxKmdloHBtRwlzZAvePbtAnOFngifulIhshNXrUbHpDmxfgBttwyrEqaXmgcxdfEMIpWneyzmnFnWUIWKizxhYcdgkGRRYgSHcuEOVOBlgECZAduEVuYvToIG"));
    this->YEoDgGlmukSZ(-216639.80578685398);
    this->PaJhmtkClq(string("SmkNWgUInGyYzitAEzdVIQKZyLTkVXJTgKbKoZbpdIAtReRPZBSBSXfKHbERlQxVqAocpIeBBhlZQXzblgALPslRxYavTalnxUvUJOlHyRFYtkZcLZRmeuSrGQYwgKaJtATNBeCQAilKAbRJbhcmziEuNoDqjLvXxkYjYvlWYsunTjwoZHdqRBGsRwuwuwTvzbmbOOeFHUerlxyDNnNKzalNaoTAQKDOsNWWxGbJKUmEEqyQirF"));
    this->pyiNt(1909969262, -1169887253);
    this->vqLYoWdcMujbZrhr(-464002987, 1689319573);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HWXMiBRssVunK
{
public:
    int FaFOeeuJJ;
    string wyRqfbFc;
    int CwjFyiqMaJLWM;
    string gRkJCCafsOhyg;

    HWXMiBRssVunK();
    int LgJujAmuYv(int dXVSBSIhczkcN, int XOPvJFKupZ, string VyTsDHv, string SHFdXhZaxSfkb, string gZdIrzULKp);
    double gMTtZTuCOJqyThoy();
    int BQPACt(int ajsdF, bool JVhdfdt, int mpHhmO, int xmGtgQQPQddn);
    double XEQgGrfD();
    double LCWyXgmg(int FxHShHavxu);
    bool LHMOxgmroiW(double tdYqgkTV, int vOFZsWgLILlIL);
    string KruwiOOU(int TppMdtCWaXb, bool oaIXUxmIN, bool qQUZQtRCLnU, double emVkdLPH);
    bool XambmRkSDKHJMT(int mELvLENNAOmCPh, double LOZEQMm, string pvvNmmAnh, double xrdSngC);
protected:
    string lPvXehJyAZN;
    string IjAugUQUTUBdW;
    int nGwjoMRIkpBE;
    int iIGsEbPp;
    int zFSAVEqrXwY;
    int UWFBgjpENfbDbxiQ;

    double rNIYTdGxU(string QpyAAxgUBxfAs, string MdqvmdzpUxU, int OFrYQVVKQ, bool xpZdCJnCXGoVuBi);
    int TwemzlOpF(int maUVWQfqSg, string rPFZCOqtGlNjMIaT, double YidLutzQusYCWZKF, int EjQwoRcZdh, string VHnUNLfThRAqD);
    bool wQNYVx(double dguUhHQDyUB, double XTzYrnX, int WhfkKyf);
    string AWOGycFg(string KiZzuCCQCYWOVmh, bool svHXQwoQJExva, bool lkhECcWMONNgrC);
    string ISvzg(string neXueEQy, string ytYUFnPpfijkAg, int fouvPtssloPqq, bool QYVNxPSLH);
private:
    int bBhYfdDeynA;
    int kqdLrtKhXY;
    int MGpRBqZFfURta;
    double RcOqpKT;
    int vUBdlJJfuQWvFnX;

    string pQOkqgSL();
    string ABGyQGrslLQPBUa(double ExuwsGcpVhAuJxC, int mjCPqIDYFlJ);
    string CuIaIPUNmJFbt(int CURWFyzi, string CvrAdPcngwupAbcl);
    int iCHLLJWxdAn(string baAWwWWVB, bool zOyFCTOSzgoq, bool XWPaIpwctIo);
    string gaIuc(int MJvgT, double DUjkV, bool xGpLqdQFiPpi, int hHQiljiqTQvgCYs);
    double xPfNYHoIbBU(bool rOyHajcBHbvuO, double PrkiZitnBh, int OFCzZFczP);
};

int HWXMiBRssVunK::LgJujAmuYv(int dXVSBSIhczkcN, int XOPvJFKupZ, string VyTsDHv, string SHFdXhZaxSfkb, string gZdIrzULKp)
{
    string mCijNgChBfCTC = string("qZvtcbtmrBFABdcDbTtiBkLKZUrSNhPBnwbCYbzJrGQozDFQlMxEVLszLJvkxqbmopffCUklXXPlCrfdEDmagRBjGvkbsoqXPgVCyRlfempQtBGlepimyRpuTOkGxxKAsHHrnOERySoNsjERLypGhFUPdZJARnwlfEwrGOMVcUMFPluYJJsJmxQyLLcfvVGCYJcRWPDhJlViqorBe");
    string xkzAZiDV = string("IYfRklZAbMIkgcfmiaojHvEwQLfshAiHhMBecGOBWXyNHwNheSIfPDeFktUMZiWipWdhrDCQEfQMVAucLYZkYlXK");
    bool ahnRXaaSgpS = false;
    bool dARoow = false;
    int MUxjQSnFGOzxNdb = 1645577976;
    bool gYQQSYOke = false;

    for (int RMwVUuQePFSJrpzF = 123454441; RMwVUuQePFSJrpzF > 0; RMwVUuQePFSJrpzF--) {
        ahnRXaaSgpS = ! ahnRXaaSgpS;
        gYQQSYOke = dARoow;
        VyTsDHv += SHFdXhZaxSfkb;
    }

    if (gZdIrzULKp == string("OuTXPBzjAAvxMzOFJjgJKPwmtjYtptSkGZGqmSWlKLpeNCVdbAgbDuMYSPJRDhzsqfnRBmXGEvKzLMAdKywaUHEwSEBibfHZlyrMKcPJUxNJpgoqHMaqcRIKJtgkigsyNofYvTgsBNfTubHdrfXJqmDvMiKYwHCQsKvQZPdydSHaTmEpIiOhrSsyDAUrCfqOYMgwSbzsHlFeMuDesDoaMLrRRGLjQXbvITXlnDvrbtKKsdPq")) {
        for (int MQYBYLut = 355340911; MQYBYLut > 0; MQYBYLut--) {
            XOPvJFKupZ = MUxjQSnFGOzxNdb;
        }
    }

    if (gYQQSYOke == false) {
        for (int HCTXh = 1420926747; HCTXh > 0; HCTXh--) {
            continue;
        }
    }

    return MUxjQSnFGOzxNdb;
}

double HWXMiBRssVunK::gMTtZTuCOJqyThoy()
{
    int LaLewwxujTUjM = -1407400630;
    int DxYplQ = -433712115;
    bool JpEBSbKd = true;
    int cutxDTelN = -1766078227;
    double bzdsA = -530814.0932832747;
    string mnHGDpaMKQA = string("WdApDzUqyxuyHbELPtfPylJWnEWLklZhQWmHOzKoTSdQFyksTXTtOTFALcUNCrYXBBPZXXNGyhxtoITFKDzDtwMiSzLSuZyhmgwmfJkgOKOHYJPdzcfGoWBtYiERtISbsOIhkjowIbJvRDFNjmTpWeJBNyGawEzNMlZkNwyjDpEqxWyeMLWuIDJHTqINmogMYlijUfqrTmoUyesLWEVygOL");
    int SwxysquhsuwK = 403562456;

    for (int MqpYvXmMNFC = 1922109823; MqpYvXmMNFC > 0; MqpYvXmMNFC--) {
        DxYplQ = DxYplQ;
    }

    if (cutxDTelN < -1766078227) {
        for (int tnZvLybOPvR = 2142619585; tnZvLybOPvR > 0; tnZvLybOPvR--) {
            cutxDTelN *= cutxDTelN;
            DxYplQ = cutxDTelN;
            DxYplQ += cutxDTelN;
            SwxysquhsuwK /= DxYplQ;
        }
    }

    for (int apdhco = 171719192; apdhco > 0; apdhco--) {
        JpEBSbKd = ! JpEBSbKd;
        cutxDTelN = SwxysquhsuwK;
        cutxDTelN += DxYplQ;
        DxYplQ /= cutxDTelN;
        cutxDTelN *= SwxysquhsuwK;
    }

    return bzdsA;
}

int HWXMiBRssVunK::BQPACt(int ajsdF, bool JVhdfdt, int mpHhmO, int xmGtgQQPQddn)
{
    int UWCwj = 1634148634;
    string hJJZuZuCpBW = string("HiWpVuURQbzylNoOjmcuDqkwkXRuOtAXafjapukMpZHJbPGYSadVdBgiAaIQUbnbRqYnvvOFVlcIVkJbqIDLHnvIrGwaMCSzdHJQrhLybwXYtGezvSvQhtdnmwZLgvgtyNujXlqPZxnXqsJvcMKkWUZmnGEdPZbMdwembwlHwQNSuKdbAmhhxPiKWqxaZQpOvuUvaYgZ");
    double ToWtpJfQ = 683037.2743541579;
    bool AjsuFmJJUwkxG = true;
    double XutBY = -192142.75545822678;
    bool rqESaF = false;
    bool fzlcacMFlryJTor = true;

    for (int BsmEbSX = 1146807573; BsmEbSX > 0; BsmEbSX--) {
        ToWtpJfQ /= ToWtpJfQ;
        fzlcacMFlryJTor = ! AjsuFmJJUwkxG;
    }

    for (int MeGDhwX = 1447767148; MeGDhwX > 0; MeGDhwX--) {
        ajsdF *= xmGtgQQPQddn;
        mpHhmO /= xmGtgQQPQddn;
    }

    return UWCwj;
}

double HWXMiBRssVunK::XEQgGrfD()
{
    int tTKVgBfaCEwm = -283034956;
    int iZwCbWTM = -2007475154;

    if (tTKVgBfaCEwm <= -283034956) {
        for (int yXoaKKVlQ = 1065685499; yXoaKKVlQ > 0; yXoaKKVlQ--) {
            iZwCbWTM /= tTKVgBfaCEwm;
            tTKVgBfaCEwm -= iZwCbWTM;
            tTKVgBfaCEwm *= tTKVgBfaCEwm;
        }
    }

    return -284468.4764420652;
}

double HWXMiBRssVunK::LCWyXgmg(int FxHShHavxu)
{
    double PAqARSqVIij = 1038417.2691616662;
    bool GDPiplYF = true;
    bool fOOXygfynN = true;

    if (FxHShHavxu != 1944739898) {
        for (int eUHWFkxwFqunbR = 1502614198; eUHWFkxwFqunbR > 0; eUHWFkxwFqunbR--) {
            continue;
        }
    }

    for (int RVMaC = 609938780; RVMaC > 0; RVMaC--) {
        GDPiplYF = GDPiplYF;
        fOOXygfynN = GDPiplYF;
        GDPiplYF = GDPiplYF;
    }

    if (PAqARSqVIij <= 1038417.2691616662) {
        for (int riuziFyfTnDZthAU = 2102625138; riuziFyfTnDZthAU > 0; riuziFyfTnDZthAU--) {
            GDPiplYF = ! GDPiplYF;
            FxHShHavxu -= FxHShHavxu;
            GDPiplYF = ! fOOXygfynN;
            fOOXygfynN = GDPiplYF;
            GDPiplYF = ! fOOXygfynN;
        }
    }

    if (fOOXygfynN == true) {
        for (int TafZiZacjhmhwn = 1559748507; TafZiZacjhmhwn > 0; TafZiZacjhmhwn--) {
            GDPiplYF = ! GDPiplYF;
        }
    }

    for (int ONDKqvYjrySMKP = 1400506783; ONDKqvYjrySMKP > 0; ONDKqvYjrySMKP--) {
        fOOXygfynN = fOOXygfynN;
    }

    return PAqARSqVIij;
}

bool HWXMiBRssVunK::LHMOxgmroiW(double tdYqgkTV, int vOFZsWgLILlIL)
{
    double BCwqeL = 224845.08938820352;
    int TBUtdcM = -500195162;
    int nVTNQdZuGYyGSG = 1013026061;
    double JTlTKUMejCO = 536274.1523085341;
    bool FkggulpFLxwLFsdB = true;
    int qtPNdkF = 264938078;
    int VQpyBCl = -1872539121;
    int Owgry = 1396016956;
    bool zruByZYXeeqKHR = true;

    if (JTlTKUMejCO != 517917.84132822376) {
        for (int ILEkbLPK = 611080858; ILEkbLPK > 0; ILEkbLPK--) {
            nVTNQdZuGYyGSG *= vOFZsWgLILlIL;
            TBUtdcM += qtPNdkF;
        }
    }

    for (int uIlzTIko = 384514237; uIlzTIko > 0; uIlzTIko--) {
        Owgry += qtPNdkF;
        TBUtdcM /= VQpyBCl;
    }

    if (vOFZsWgLILlIL <= -1872539121) {
        for (int trnJAnXwN = 394718797; trnJAnXwN > 0; trnJAnXwN--) {
            continue;
        }
    }

    for (int aToLLdBTyPOvp = 1301085824; aToLLdBTyPOvp > 0; aToLLdBTyPOvp--) {
        continue;
    }

    return zruByZYXeeqKHR;
}

string HWXMiBRssVunK::KruwiOOU(int TppMdtCWaXb, bool oaIXUxmIN, bool qQUZQtRCLnU, double emVkdLPH)
{
    double EGcwB = -1006516.6034453996;
    bool iLocNlcdLjGoNYnG = true;
    int rWhuSgKJaXsoJAF = -420326590;
    bool eetQuTintz = true;
    string ZwGPKYskMAE = string("cscJNKxBMLnOUXdvUQkJofZImODXQRznCS");
    string yVsWniYfaBXR = string("lRnqIJTOrOxUAxKQRUErTcdrAisqQYoNlNdVcLEGwoJCSExJNOcxxMMHbTmOGTjoAxMkyRhFDwOlYCCqpbWnLdYuBXhJPwaqZichPoSfngKSPg");
    bool FTysCIDfaUj = false;

    for (int XGRZPsEqsvdAZ = 1523633295; XGRZPsEqsvdAZ > 0; XGRZPsEqsvdAZ--) {
        EGcwB /= EGcwB;
        iLocNlcdLjGoNYnG = oaIXUxmIN;
    }

    for (int nwZca = 1062490306; nwZca > 0; nwZca--) {
        FTysCIDfaUj = ! iLocNlcdLjGoNYnG;
        eetQuTintz = ! qQUZQtRCLnU;
    }

    for (int UYUTOLGPjdXlfQ = 1406814334; UYUTOLGPjdXlfQ > 0; UYUTOLGPjdXlfQ--) {
        continue;
    }

    return yVsWniYfaBXR;
}

bool HWXMiBRssVunK::XambmRkSDKHJMT(int mELvLENNAOmCPh, double LOZEQMm, string pvvNmmAnh, double xrdSngC)
{
    int bGuEy = 829514895;
    string hjEnxjHSInNYWxh = string("FIEJuYdBVOKcFWfvlZQBmXpNNSmEsjHcOCMbxkNFbrnhr");
    bool gzyhROOwb = false;
    string jBQlOdko = string("MrpbSDIqEqYECTwFatDJZoLXdxQyyTFegEZDgOIWuDeibXRSJPVZIbocguuOEAXykOBhLZatYVPuoizmG");
    double QCdTVPs = -814239.8608566216;
    int iZQCVDozNySEsq = 1396331702;
    int czdbNQbxCembnm = -1752920615;
    string OfFZCnILbOs = string("PFafxzu");
    string QGjrgDGxrN = string("QJHYGcEyvMsqGVPzKqoIFpkonnEnpaFoMzxEtjHBssRSzCrkXSZxdBHKXYKUqYdtiBjQALgUHgRPFThBaAgASioFszQRkiywCHrsQBwqxM");

    for (int fQKoAMyslErg = 1326879913; fQKoAMyslErg > 0; fQKoAMyslErg--) {
        jBQlOdko += pvvNmmAnh;
        czdbNQbxCembnm += mELvLENNAOmCPh;
        LOZEQMm /= LOZEQMm;
        QGjrgDGxrN += hjEnxjHSInNYWxh;
    }

    for (int QdeegxVpndZ = 1701911267; QdeegxVpndZ > 0; QdeegxVpndZ--) {
        hjEnxjHSInNYWxh += QGjrgDGxrN;
        jBQlOdko = QGjrgDGxrN;
        mELvLENNAOmCPh *= bGuEy;
        czdbNQbxCembnm -= czdbNQbxCembnm;
    }

    if (hjEnxjHSInNYWxh == string("MrpbSDIqEqYECTwFatDJZoLXdxQyyTFegEZDgOIWuDeibXRSJPVZIbocguuOEAXykOBhLZatYVPuoizmG")) {
        for (int OFKiAzF = 1446096806; OFKiAzF > 0; OFKiAzF--) {
            pvvNmmAnh = jBQlOdko;
        }
    }

    return gzyhROOwb;
}

double HWXMiBRssVunK::rNIYTdGxU(string QpyAAxgUBxfAs, string MdqvmdzpUxU, int OFrYQVVKQ, bool xpZdCJnCXGoVuBi)
{
    double ekEDP = -942399.4044360848;
    double TqpCxnYYdj = 487523.7927166225;
    bool NmeBFGXraleOQqH = false;
    int iyvZXdFxWj = -1832451681;
    double xStqBCgerZDt = -136564.52893030902;
    bool GwNrWCHe = true;
    bool GnNlUtWLVN = true;
    bool xsEGSEgPcmPbQKaZ = false;

    for (int ZNXTpf = 913447309; ZNXTpf > 0; ZNXTpf--) {
        GnNlUtWLVN = ! GnNlUtWLVN;
        GwNrWCHe = ! GwNrWCHe;
        GwNrWCHe = xpZdCJnCXGoVuBi;
    }

    for (int iFdSbYRcxkpa = 1570390286; iFdSbYRcxkpa > 0; iFdSbYRcxkpa--) {
        TqpCxnYYdj -= xStqBCgerZDt;
        GwNrWCHe = ! xsEGSEgPcmPbQKaZ;
    }

    return xStqBCgerZDt;
}

int HWXMiBRssVunK::TwemzlOpF(int maUVWQfqSg, string rPFZCOqtGlNjMIaT, double YidLutzQusYCWZKF, int EjQwoRcZdh, string VHnUNLfThRAqD)
{
    double dhOwRXrqSYNmad = 757162.2417819508;
    double hflwnULAEYemq = -534226.4921033765;

    for (int CexSnQidptNIj = 160663019; CexSnQidptNIj > 0; CexSnQidptNIj--) {
        rPFZCOqtGlNjMIaT += rPFZCOqtGlNjMIaT;
        EjQwoRcZdh -= EjQwoRcZdh;
        YidLutzQusYCWZKF += YidLutzQusYCWZKF;
    }

    for (int JeNjmyAyuvOWWVBG = 461502246; JeNjmyAyuvOWWVBG > 0; JeNjmyAyuvOWWVBG--) {
        dhOwRXrqSYNmad *= hflwnULAEYemq;
        EjQwoRcZdh += EjQwoRcZdh;
        dhOwRXrqSYNmad *= hflwnULAEYemq;
        dhOwRXrqSYNmad *= hflwnULAEYemq;
        dhOwRXrqSYNmad = YidLutzQusYCWZKF;
    }

    if (VHnUNLfThRAqD <= string("wShDhWSGaYxpXTIbqcVyTHBrPCKWQvphGUOrmwgTFkXwIHBpaOUgBRwAAAhiMJQnhSrdzOKjVvDGLAeYAIEoOdvlPHfSSnCVUWViW")) {
        for (int AiEiVlQpNrXezM = 1182996044; AiEiVlQpNrXezM > 0; AiEiVlQpNrXezM--) {
            continue;
        }
    }

    for (int AJQhsnJrtXQOdH = 922080294; AJQhsnJrtXQOdH > 0; AJQhsnJrtXQOdH--) {
        dhOwRXrqSYNmad *= hflwnULAEYemq;
    }

    if (EjQwoRcZdh != -1339859118) {
        for (int JynSgvr = 1964908707; JynSgvr > 0; JynSgvr--) {
            YidLutzQusYCWZKF *= hflwnULAEYemq;
        }
    }

    return EjQwoRcZdh;
}

bool HWXMiBRssVunK::wQNYVx(double dguUhHQDyUB, double XTzYrnX, int WhfkKyf)
{
    bool ugxUwR = false;

    for (int aHohPg = 154871517; aHohPg > 0; aHohPg--) {
        WhfkKyf -= WhfkKyf;
        XTzYrnX /= XTzYrnX;
        XTzYrnX /= XTzYrnX;
        XTzYrnX /= XTzYrnX;
    }

    if (dguUhHQDyUB == -944654.4671091413) {
        for (int kGbyRJ = 1579222792; kGbyRJ > 0; kGbyRJ--) {
            continue;
        }
    }

    for (int gWGwhuMdErMtle = 152752519; gWGwhuMdErMtle > 0; gWGwhuMdErMtle--) {
        continue;
    }

    for (int RyQhdYAISQeYFEMW = 1956852684; RyQhdYAISQeYFEMW > 0; RyQhdYAISQeYFEMW--) {
        WhfkKyf /= WhfkKyf;
        XTzYrnX += XTzYrnX;
    }

    for (int KTCYlRubllkvcL = 1899342184; KTCYlRubllkvcL > 0; KTCYlRubllkvcL--) {
        ugxUwR = ugxUwR;
        WhfkKyf -= WhfkKyf;
        ugxUwR = ugxUwR;
        XTzYrnX -= dguUhHQDyUB;
    }

    return ugxUwR;
}

string HWXMiBRssVunK::AWOGycFg(string KiZzuCCQCYWOVmh, bool svHXQwoQJExva, bool lkhECcWMONNgrC)
{
    string YcULelbT = string("QySIsoVBxohMjkjevNYWMwMONnFeKPnQsqHdFCFyNbdzVvNHcmjOvdZfkdaSDXjiSMuQiyDCApRotDMXfRCdqxonEuiUaigxWBMhjkarsCROWakJQZiYiZ");
    bool srqKAkatf = false;
    bool ZtYxq = true;
    string mGOkqbjktpdkZOvY = string("xVNAZcmHvGbrLPyleSTalOHxEmwrwxRlYUzAysborizrioQqyDxGbxCuhhNdjtKYwtRAERTLXFCOsxhbWgMmYcXuHULNylXGSGowxxqefEzZjCwFkqHhvEzMJjffxJHgyBYnAuhDVrSUuOvmFaBQEciLEyKFANNRFsQLtJBvFMEAd");
    double QyMpHmzqaagku = -322914.145075371;
    double heJFOHHNoQ = -508492.39064683014;

    return mGOkqbjktpdkZOvY;
}

string HWXMiBRssVunK::ISvzg(string neXueEQy, string ytYUFnPpfijkAg, int fouvPtssloPqq, bool QYVNxPSLH)
{
    bool FDHUWQgM = true;
    double qUJibrwQz = 863071.2588029421;
    string qtLVGp = string("THHwPrsZHDFLfGtNrUNlnQdmeDewxVs");
    int UUzzs = 512898374;
    int oavUQzdgYqpr = -2001379127;
    int goeeQzlIcXtaXPJg = 395285435;

    if (oavUQzdgYqpr >= 512898374) {
        for (int yDQCQREdUOr = 979489890; yDQCQREdUOr > 0; yDQCQREdUOr--) {
            continue;
        }
    }

    for (int nfBSk = 1941221528; nfBSk > 0; nfBSk--) {
        neXueEQy += neXueEQy;
    }

    for (int mGzUgWXUuezSZkVa = 1213544438; mGzUgWXUuezSZkVa > 0; mGzUgWXUuezSZkVa--) {
        continue;
    }

    for (int cRSYgszVIuSGvAyo = 1156559400; cRSYgszVIuSGvAyo > 0; cRSYgszVIuSGvAyo--) {
        QYVNxPSLH = FDHUWQgM;
    }

    if (oavUQzdgYqpr <= 1883800491) {
        for (int flAZTLrn = 1774663919; flAZTLrn > 0; flAZTLrn--) {
            ytYUFnPpfijkAg = qtLVGp;
            qtLVGp = ytYUFnPpfijkAg;
        }
    }

    return qtLVGp;
}

string HWXMiBRssVunK::pQOkqgSL()
{
    bool OIbpJK = false;
    double fwwieWO = -898209.8413907355;
    double pQGhYqyCWiFYz = -826521.2335483758;
    string eBChvaiWSe = string("yBNngZzeuITiOKOhMCCJnqsfBozdEjoCOLeiqtRDchBHNNscIKOTsdRjEfoGTzDnwSaCthcJQzTDOAFYnCAqZAAmeayAdTqKoMzIAvcgVzKxGGvrulyHGhBV");
    bool ZGHDNNNJRkVbs = false;

    return eBChvaiWSe;
}

string HWXMiBRssVunK::ABGyQGrslLQPBUa(double ExuwsGcpVhAuJxC, int mjCPqIDYFlJ)
{
    int pwhMYntBX = -1240123409;
    string WSlkbfxZ = string("PEMPinwmTayXVMOFjfqHDnlZBaDAuBGKPaUahlAqqytzOZPZdYpQlcOVNaTjqAYOlVXJMXjSZNorieEyBiyEXZDMfeqARojiMsXSAqAVgWB");
    double RPHxqfScWNksCDlw = 189597.25054154528;
    int nzuoXMaHlDRuwy = 268838035;
    int RBJfgrIww = 1342944173;
    double YXpVOfH = -1007957.1745835049;

    for (int jJdXoVHi = 256682016; jJdXoVHi > 0; jJdXoVHi--) {
        YXpVOfH = YXpVOfH;
    }

    if (pwhMYntBX > 201256446) {
        for (int bQXZCet = 203742120; bQXZCet > 0; bQXZCet--) {
            continue;
        }
    }

    if (YXpVOfH != 189597.25054154528) {
        for (int KcNyYVY = 2076621433; KcNyYVY > 0; KcNyYVY--) {
            continue;
        }
    }

    for (int SEWZoiMwlPBaKaCE = 1433105040; SEWZoiMwlPBaKaCE > 0; SEWZoiMwlPBaKaCE--) {
        ExuwsGcpVhAuJxC += RPHxqfScWNksCDlw;
        mjCPqIDYFlJ += mjCPqIDYFlJ;
        nzuoXMaHlDRuwy += nzuoXMaHlDRuwy;
        WSlkbfxZ += WSlkbfxZ;
    }

    return WSlkbfxZ;
}

string HWXMiBRssVunK::CuIaIPUNmJFbt(int CURWFyzi, string CvrAdPcngwupAbcl)
{
    string MWQhFIFcJEZ = string("KmjSRwnLZzsXZPvxRFttpscLHdZebymWqRmCoTMewfJMGSJhCJJxPtugwftgxxfIewcZUmsTtXIBScWaisELuYWxODtvhqyQBRQAHoWtWTUMPRzJO");
    bool nmUwqFkkhWjV = true;
    double SFhbSPsJNTOAmZdq = 78611.58946905691;

    for (int VfAGojsWCDaS = 832384358; VfAGojsWCDaS > 0; VfAGojsWCDaS--) {
        continue;
    }

    if (MWQhFIFcJEZ <= string("FuvFvOmzzKJrOfbvHKAJREbESOqreyTbraetmfcCrNxEWfOUjuIUiHLGjnyEthATKoEslDEoAaMIffqUInuBcWvWDYMy")) {
        for (int gUZkgw = 539606753; gUZkgw > 0; gUZkgw--) {
            CvrAdPcngwupAbcl += MWQhFIFcJEZ;
            CURWFyzi = CURWFyzi;
            CvrAdPcngwupAbcl += CvrAdPcngwupAbcl;
            CURWFyzi -= CURWFyzi;
        }
    }

    for (int fJCiWdwk = 1025568420; fJCiWdwk > 0; fJCiWdwk--) {
        CvrAdPcngwupAbcl = MWQhFIFcJEZ;
        CvrAdPcngwupAbcl += MWQhFIFcJEZ;
    }

    for (int qAFdkngAkCO = 8900339; qAFdkngAkCO > 0; qAFdkngAkCO--) {
        CvrAdPcngwupAbcl += CvrAdPcngwupAbcl;
        CvrAdPcngwupAbcl = CvrAdPcngwupAbcl;
        nmUwqFkkhWjV = ! nmUwqFkkhWjV;
    }

    for (int csEZqmRdzHyFG = 189418717; csEZqmRdzHyFG > 0; csEZqmRdzHyFG--) {
        SFhbSPsJNTOAmZdq *= SFhbSPsJNTOAmZdq;
    }

    for (int lWlaSJcmGVlzdJKW = 1423996294; lWlaSJcmGVlzdJKW > 0; lWlaSJcmGVlzdJKW--) {
        CvrAdPcngwupAbcl = MWQhFIFcJEZ;
        CURWFyzi += CURWFyzi;
    }

    return MWQhFIFcJEZ;
}

int HWXMiBRssVunK::iCHLLJWxdAn(string baAWwWWVB, bool zOyFCTOSzgoq, bool XWPaIpwctIo)
{
    bool AkaQTphEAxyED = false;
    bool htTJUvIdOwrInae = false;
    double ERBhnGxsX = -115452.0822058537;
    int tIxGc = 1144295873;
    double aLUxz = 670073.0837868789;
    double QmAuWtkHG = -396979.485559442;

    if (QmAuWtkHG != 670073.0837868789) {
        for (int ExGRSlyzJyUA = 886523869; ExGRSlyzJyUA > 0; ExGRSlyzJyUA--) {
            XWPaIpwctIo = ! XWPaIpwctIo;
            AkaQTphEAxyED = ! zOyFCTOSzgoq;
            htTJUvIdOwrInae = ! AkaQTphEAxyED;
        }
    }

    return tIxGc;
}

string HWXMiBRssVunK::gaIuc(int MJvgT, double DUjkV, bool xGpLqdQFiPpi, int hHQiljiqTQvgCYs)
{
    bool zHkBdzoskBaD = true;
    bool FVNfwpSQHcMxVXBE = true;

    for (int KSnKiOuknO = 2123316133; KSnKiOuknO > 0; KSnKiOuknO--) {
        hHQiljiqTQvgCYs += hHQiljiqTQvgCYs;
        xGpLqdQFiPpi = ! xGpLqdQFiPpi;
        xGpLqdQFiPpi = xGpLqdQFiPpi;
    }

    return string("tDTivfQybwvYOykagtdAgdAPNUAaxjwexEcLtYOmFRcYS");
}

double HWXMiBRssVunK::xPfNYHoIbBU(bool rOyHajcBHbvuO, double PrkiZitnBh, int OFCzZFczP)
{
    string nbPsshSBMsarsID = string("WEYZabmhqtiCiZfXGdJfduzuKOPaDgKwTORYJCnuqHslOYEXyAmUndjacbiLGhGdLEr");
    int QFLvLp = -1815226517;
    string oNAbCri = string("UXhGqcaGEKPkbHVGyehThLsDmJleDGCpRaYBIPhQAUiMrETmCfsRwqmLueobLAMOetQMhEqSNqPVMkkTFabUKHZPmjuQuaOFbZgYKDNYkHJRxjgjiDadcJBlmXUTyZKuzkKNwnshWBhHqBZUJwbKEcEzkLmQgLUygZDFqGeTJVqZCDzqwcyATPOCDqZywaZCRxSVmHrcn");
    int wMvDduFB = 340374491;
    bool isMGLjql = false;
    int mfpRo = -1962089663;
    bool DMlGLLPecfsKYpsZ = false;
    string EZQpeSneJ = string("reXUyTfUOwMVXmmOIzNSINXBqcRhIAjaKntstekbYETCAuYXUDoFqJetWEmAwUwWuJHwCPxnxsVgCYNCcJfVXf");
    string xfLqZWKkevwfxj = string("NNVniIMGZutOwfDpscwWzBuoNUVoCNFqDQvxWjeqwchkDPCAdDmsWPHcdObiGvxuTOToWGXsJbjpVsfrtzXoziFiRaQYeFvgqVKcUPltydqoaRWNZZVJzuQgErFjbsXtMoGLniZHeUkDQMHoMEAuAPKaKnORkRhbGBkxODJYfWMsjHMzfUIRjbA");
    string IoDcDMse = string("imUBeXJnwFQgqBL");

    for (int FNmQM = 1583582551; FNmQM > 0; FNmQM--) {
        mfpRo -= OFCzZFczP;
    }

    return PrkiZitnBh;
}

HWXMiBRssVunK::HWXMiBRssVunK()
{
    this->LgJujAmuYv(1562718221, 2010085922, string("XgSbiAKYwncmWOeYBTFkmjtxYZgVgMMBXTZsolCrKZmNoQtqiYnwbHkPVntAqsnSFXzUPtzYGyuBmjiQClPQBcXHchANModwLRiIIQEnRjuFEOiBDSatvtyPtMPyquHalUVnaBNOYdqMlNKCDGYlivSqZFLoTOLJDRjWyurzTNDUqlpNXQIDyEaLLfBkgQMtzBxYWZbAztzLjJoF"), string("OuTXPBzjAAvxMzOFJjgJKPwmtjYtptSkGZGqmSWlKLpeNCVdbAgbDuMYSPJRDhzsqfnRBmXGEvKzLMAdKywaUHEwSEBibfHZlyrMKcPJUxNJpgoqHMaqcRIKJtgkigsyNofYvTgsBNfTubHdrfXJqmDvMiKYwHCQsKvQZPdydSHaTmEpIiOhrSsyDAUrCfqOYMgwSbzsHlFeMuDesDoaMLrRRGLjQXbvITXlnDvrbtKKsdPq"), string("ixJSQtdPaYahRVhGlXQOGTYKQuxQaSmOzTtrfeXEnfvCnGDCGgMKFXVUbRJw"));
    this->gMTtZTuCOJqyThoy();
    this->BQPACt(2106546182, false, 266913432, 1355034879);
    this->XEQgGrfD();
    this->LCWyXgmg(1944739898);
    this->LHMOxgmroiW(517917.84132822376, -20958025);
    this->KruwiOOU(1733836024, true, false, -80179.27447447034);
    this->XambmRkSDKHJMT(-1352469273, 504556.6277789584, string("xiQofuLCFUXFzxnvpuoYxYjQkDKmoSmYMRQVzFRgjyhCUuQaFvAkmdCtraXKFhoqYdMhYSSLQVlDTyTZBIPZhjgekcsooWskfNZrxEsmPoToeXAzgBhRBenENwJZVbvwVx"), -784199.1733159138);
    this->rNIYTdGxU(string("joJpnWHNiMetnrIRqeXTARwjZvdObplvjtMGGEQGUNPMgiPFsdrQqhmNOkCJasnzSMmTiWWHaReryxAWnddcGFhVvWZWfjhibLEUxPeopqWWqnRirEFWVeYJuzcoSZcwCmZguDuBWHIITZYSUlpeQPVIpMNHxmyjwlzrCpffQtawfoVmGGUhVCDZesOHLogFpUUesOkXVG"), string("ImYhmJbrzTxsPCgMcyYbxbOlbuTNCDLYqlbTEbqsXNMabjtbaErnCVOVLDFvulBzcsCwmCuAkdW"), 1919613027, true);
    this->TwemzlOpF(-1339859118, string("wShDhWSGaYxpXTIbqcVyTHBrPCKWQvphGUOrmwgTFkXwIHBpaOUgBRwAAAhiMJQnhSrdzOKjVvDGLAeYAIEoOdvlPHfSSnCVUWViW"), 172742.2850723773, 830501153, string("OmpLIpkXeOEhOfxNSYefmOtyDEUBMwpwdfNI"));
    this->wQNYVx(-609049.0813541297, -944654.4671091413, -1381919443);
    this->AWOGycFg(string("NArtzqnjSKgCNsZUeFexUcKiqCzOwxbXXOTJHOFhDZgKKCNvSHTIBnLmWbLyNNpaotsTcdeJybwnHsPZdzxAOBthGnsLoVvNchVecMMZpIeHl"), true, true);
    this->ISvzg(string("WxGFXnPpIByMHDLk"), string("bsPOwmphqfbPavHKDnvGYsuFyDODWNOhXnASylGoJYXUOSiDdvrJbFmPRSHypouzDLdHjuVHiMDqbRGdxsXEnyApcVONaSgTKeOzEYPszZNKHMJglLdtfmGCfzYwYDqEeEVLbsEdbMwMaissvpvFhBczZPecqDiIakmXmdUumQcHWfmdfcOaYNDhagAENdPBkkQAMHrzBTmkwbhmhGXFDFDBhnjQPaCHzNtxkRSGbTJBsWgAdOhpHR"), 1883800491, true);
    this->pQOkqgSL();
    this->ABGyQGrslLQPBUa(-716299.5429534145, 201256446);
    this->CuIaIPUNmJFbt(-1179484700, string("FuvFvOmzzKJrOfbvHKAJREbESOqreyTbraetmfcCrNxEWfOUjuIUiHLGjnyEthATKoEslDEoAaMIffqUInuBcWvWDYMy"));
    this->iCHLLJWxdAn(string("bprdHOaCWKktEpjYyjKTrMpMGTgTFJUUNqvWDVdUQJuAmxaZaFmFZsKyIGAzgwwjKpKYmmobDJfMMRBrpcfposypGkJhvR"), true, true);
    this->gaIuc(2091879442, -25915.806723141563, true, 1392129032);
    this->xPfNYHoIbBU(false, -537243.909691184, -1545697763);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SICDSFK
{
public:
    string WnKXLLamjn;
    bool EppCDLMRkTjPRDC;

    SICDSFK();
    string IqoQLfMDCweVZXI();
    string QawhgImKvbvn(bool EsbOTUtobJpV, string gsvhmdr, bool BcGtcIdJAJLlxUvw, int afVHfSqEyPdCY);
    void fdeGlRqAnMTz(string abtmMcl, bool nOTjUXaXAf);
    int vRCeJzj(bool cNRkNVCZxzAqhdj, double xbpjj, string QBjBOyuy, string heUKxkVm, int tWxqj);
    bool huGjYiPZBt(string GshMTiJWtmmQMx);
protected:
    string DDIXCLTTzGhgC;
    double miYrnxAlEwdw;

    double mRGnhhsxJVBbieKF(double DlfcpTRZxujnhqhe, int fEKwKBbMGw);
    void TIdNB();
    string fPYarfEpKyxqj(string sqJHa, bool LWXDTXLUfYsdf, double xsFmVUUDihOD, int CStdcAVsASzHjeW);
    string fWJaTApVzH(string KkPLHCUXxitGoZ);
    double DEcfvBmJOK(string oVLcYDaMunf, double GWKjCDjsrBhM, int CXXRU, int vqfXi);
    bool ByTTYQrvztdMtYx(double xOUVfgSO, bool iPJkEFAgLiWUsH, string gAyeWlKMthDU);
    int zrkiFzB();
private:
    string UmoLAQ;
    double XczmJ;
    string nrhVZCwm;
    string saERdmAzUpjoRgd;

    int qkSglPADTT(bool VKiHLZTKRQ, bool TNOsCLwcjloTBsw);
    void PHXTMDSQGg(double hRxzVxFVrLdztI);
    void aSHAeORaRo(int aluLCFG, int WBZdg);
    double SzIAMYIuAkXlM(int MdCFOCowu, double qreFVsBBrKc, bool ExLQzUor, bool iMpUknzseihZ);
    double nWCQKbiv(int CrZvOAeiuMQuQq, bool vHDCJrBRiwsZfPf, string wOvKpsc, int HaEQFSKPoSMfiJ);
};

string SICDSFK::IqoQLfMDCweVZXI()
{
    int IMvbrtWXWeDyfHhY = -1242134056;
    double nixjfWkML = 653762.7820259032;
    double DqTjrsrhOp = 343127.2460708674;

    if (nixjfWkML == 653762.7820259032) {
        for (int CgGMhso = 783261136; CgGMhso > 0; CgGMhso--) {
            IMvbrtWXWeDyfHhY *= IMvbrtWXWeDyfHhY;
        }
    }

    if (nixjfWkML != 653762.7820259032) {
        for (int eOVqFPLU = 458102568; eOVqFPLU > 0; eOVqFPLU--) {
            nixjfWkML += nixjfWkML;
            DqTjrsrhOp -= DqTjrsrhOp;
            nixjfWkML = nixjfWkML;
            DqTjrsrhOp += DqTjrsrhOp;
        }
    }

    for (int LHwbDcJHDg = 1175465846; LHwbDcJHDg > 0; LHwbDcJHDg--) {
        nixjfWkML /= nixjfWkML;
        nixjfWkML *= DqTjrsrhOp;
        IMvbrtWXWeDyfHhY = IMvbrtWXWeDyfHhY;
    }

    if (IMvbrtWXWeDyfHhY > -1242134056) {
        for (int TLEMMPM = 859095621; TLEMMPM > 0; TLEMMPM--) {
            nixjfWkML /= nixjfWkML;
            DqTjrsrhOp *= DqTjrsrhOp;
            nixjfWkML /= DqTjrsrhOp;
            nixjfWkML = nixjfWkML;
        }
    }

    return string("rtfXIXJWTnaiLzgmeGTJBBShuWhOrqVTwuVhqteTtbeJVCsoFeKVYLsRHhAWxthwUxwBdBtpUXkcKWmAxtSngejNIrxWqheshWElRKVfBZmUgsSxAzKQOMcYWQcVIneqDjWlpQvmrwyHSuCRdBMEnAOMwoXmf");
}

string SICDSFK::QawhgImKvbvn(bool EsbOTUtobJpV, string gsvhmdr, bool BcGtcIdJAJLlxUvw, int afVHfSqEyPdCY)
{
    double acMKgGhC = 11358.822217591513;
    int aDzniuuLqFW = -1918391456;
    int ZeLXl = 289981676;
    double AYLeVZxeIHlB = -872080.7128170634;

    for (int OIdxPiElVGB = 1981971298; OIdxPiElVGB > 0; OIdxPiElVGB--) {
        afVHfSqEyPdCY = afVHfSqEyPdCY;
    }

    for (int WfQlgMtgrsgRd = 1987406562; WfQlgMtgrsgRd > 0; WfQlgMtgrsgRd--) {
        ZeLXl -= ZeLXl;
        acMKgGhC += acMKgGhC;
        acMKgGhC /= acMKgGhC;
    }

    for (int zzHgy = 1178712573; zzHgy > 0; zzHgy--) {
        gsvhmdr = gsvhmdr;
    }

    for (int nvawwlgWHryAyc = 642165557; nvawwlgWHryAyc > 0; nvawwlgWHryAyc--) {
        ZeLXl = ZeLXl;
    }

    for (int wYSDAbDOZDw = 565191736; wYSDAbDOZDw > 0; wYSDAbDOZDw--) {
        BcGtcIdJAJLlxUvw = ! BcGtcIdJAJLlxUvw;
    }

    return gsvhmdr;
}

void SICDSFK::fdeGlRqAnMTz(string abtmMcl, bool nOTjUXaXAf)
{
    string mzZNrraZOMvV = string("vWTMjsZLOOhoZlVduGKuPsFXAbiCgROcTsRAalwluAUOBguFItGnuIQUHVTfYpxrwXAQUeFhnbpCNAowBrCUKQzCChcZyUoo");
    bool ACkdjxps = false;
    bool tsHRgwugWB = true;
    bool CVlDvSduxMkWhnnM = true;

    if (nOTjUXaXAf != true) {
        for (int tloyG = 620294698; tloyG > 0; tloyG--) {
            nOTjUXaXAf = ! ACkdjxps;
            CVlDvSduxMkWhnnM = ! CVlDvSduxMkWhnnM;
            nOTjUXaXAf = tsHRgwugWB;
            mzZNrraZOMvV = mzZNrraZOMvV;
            CVlDvSduxMkWhnnM = tsHRgwugWB;
        }
    }

    for (int MNgpwViYHmDIGN = 457570498; MNgpwViYHmDIGN > 0; MNgpwViYHmDIGN--) {
        continue;
    }

    if (ACkdjxps != true) {
        for (int LKBar = 1507260348; LKBar > 0; LKBar--) {
            abtmMcl = mzZNrraZOMvV;
            nOTjUXaXAf = ACkdjxps;
            nOTjUXaXAf = nOTjUXaXAf;
        }
    }

    if (ACkdjxps == true) {
        for (int fzlJyL = 993960124; fzlJyL > 0; fzlJyL--) {
            CVlDvSduxMkWhnnM = CVlDvSduxMkWhnnM;
            abtmMcl += abtmMcl;
            tsHRgwugWB = ! nOTjUXaXAf;
        }
    }

    for (int xAHqUBzsoM = 1584534109; xAHqUBzsoM > 0; xAHqUBzsoM--) {
        CVlDvSduxMkWhnnM = ACkdjxps;
    }

    if (ACkdjxps != true) {
        for (int gwVkZJk = 2044766046; gwVkZJk > 0; gwVkZJk--) {
            CVlDvSduxMkWhnnM = tsHRgwugWB;
            nOTjUXaXAf = ACkdjxps;
        }
    }
}

int SICDSFK::vRCeJzj(bool cNRkNVCZxzAqhdj, double xbpjj, string QBjBOyuy, string heUKxkVm, int tWxqj)
{
    bool GsMNBx = false;
    bool JSqvJym = true;
    string qNcZWXLzv = string("VGxGEYCuFOklGXNQDjsTRBwuRpGeXmjRweGSQGqUbrqKnswGzmUSAvrUrCIQvgWrqTYBVvkFVHsCOoMZtRtEPqREPwfxRgEEceOpPNFNoqwxJxisxQyjQSzGdaTSLLJMOOffgZeXCnnWbPrqyZCgTTxcFJKedeWIUnRpuPDTsSDafHLHPCNMCSiQMSvqUYFsRsXjEFhnrLeJbxJnJYMzxOQNqWNoYohiKAgblRAguJnOKiygtBUqzzTn");
    bool UWVEoQNzOrWgRlM = false;
    bool YLUQcG = true;
    bool qCNEBHBKRAelZEsM = false;
    bool MWUDeqxdcx = false;
    bool XnMOsosRD = true;

    for (int VUEXSeJ = 693303842; VUEXSeJ > 0; VUEXSeJ--) {
        YLUQcG = UWVEoQNzOrWgRlM;
        xbpjj -= xbpjj;
        heUKxkVm += heUKxkVm;
        XnMOsosRD = JSqvJym;
        YLUQcG = ! UWVEoQNzOrWgRlM;
        GsMNBx = JSqvJym;
        GsMNBx = MWUDeqxdcx;
        cNRkNVCZxzAqhdj = ! YLUQcG;
    }

    return tWxqj;
}

bool SICDSFK::huGjYiPZBt(string GshMTiJWtmmQMx)
{
    bool vMQfzZZOM = false;
    double wXAowoywzDDQ = -248027.98640188552;
    double odqEGaSUNl = 82766.37409551886;
    int yauHij = -657266422;
    string NEsfTvNTiH = string("IioPQIEfVnWSUjqGhINbvDJMEysEbXCEoPyNg");
    bool OzNLiJNRnT = true;
    int ZrjhorpbbkDtIk = 1891451899;

    for (int VoETExbQNCeyqgf = 918218463; VoETExbQNCeyqgf > 0; VoETExbQNCeyqgf--) {
        vMQfzZZOM = ! OzNLiJNRnT;
        vMQfzZZOM = ! vMQfzZZOM;
        ZrjhorpbbkDtIk -= yauHij;
        ZrjhorpbbkDtIk *= yauHij;
    }

    return OzNLiJNRnT;
}

double SICDSFK::mRGnhhsxJVBbieKF(double DlfcpTRZxujnhqhe, int fEKwKBbMGw)
{
    bool RPGnFtNMwlrZ = true;

    return DlfcpTRZxujnhqhe;
}

void SICDSFK::TIdNB()
{
    double GplUBv = -137819.49979815603;
    int BgtkWtSHyUMnlfu = 2019625646;
    bool TnHNeGomNiGV = false;
    double jbkCGDolXBG = -109153.24251313043;

    for (int JjmqCnfICdNOkQb = 988070006; JjmqCnfICdNOkQb > 0; JjmqCnfICdNOkQb--) {
        continue;
    }

    if (GplUBv == -109153.24251313043) {
        for (int DNOHccTvTWmYcnRv = 430112868; DNOHccTvTWmYcnRv > 0; DNOHccTvTWmYcnRv--) {
            jbkCGDolXBG = jbkCGDolXBG;
            GplUBv *= jbkCGDolXBG;
        }
    }

    for (int SvupMHNIYPm = 638510526; SvupMHNIYPm > 0; SvupMHNIYPm--) {
        jbkCGDolXBG *= jbkCGDolXBG;
        BgtkWtSHyUMnlfu += BgtkWtSHyUMnlfu;
        jbkCGDolXBG *= GplUBv;
    }
}

string SICDSFK::fPYarfEpKyxqj(string sqJHa, bool LWXDTXLUfYsdf, double xsFmVUUDihOD, int CStdcAVsASzHjeW)
{
    bool OmbUCBmeDSxB = true;
    int iejGsYGWBsHJzAO = -1669394702;

    for (int WehMmRpyb = 1917712580; WehMmRpyb > 0; WehMmRpyb--) {
        sqJHa = sqJHa;
        xsFmVUUDihOD /= xsFmVUUDihOD;
        LWXDTXLUfYsdf = ! OmbUCBmeDSxB;
    }

    for (int nFwTWOSDorW = 1922276264; nFwTWOSDorW > 0; nFwTWOSDorW--) {
        continue;
    }

    for (int hqnZS = 273377994; hqnZS > 0; hqnZS--) {
        LWXDTXLUfYsdf = ! LWXDTXLUfYsdf;
        OmbUCBmeDSxB = ! LWXDTXLUfYsdf;
        LWXDTXLUfYsdf = LWXDTXLUfYsdf;
    }

    if (sqJHa != string("UWaYzUTUMMWyvXQEIoekGXWfPTNpUkcbIXQXGkFmeJYxXPTADnmT")) {
        for (int HEaJqNs = 87111089; HEaJqNs > 0; HEaJqNs--) {
            LWXDTXLUfYsdf = ! OmbUCBmeDSxB;
            CStdcAVsASzHjeW = CStdcAVsASzHjeW;
            LWXDTXLUfYsdf = OmbUCBmeDSxB;
        }
    }

    for (int rCtgtn = 900541741; rCtgtn > 0; rCtgtn--) {
        CStdcAVsASzHjeW = iejGsYGWBsHJzAO;
    }

    return sqJHa;
}

string SICDSFK::fWJaTApVzH(string KkPLHCUXxitGoZ)
{
    bool oAJrectrVdLsxy = true;
    double XLenAuWFDu = 1001621.662898916;
    double CaKQRqY = 110938.76323663803;
    double MHIRElsEdVpRMC = -15446.967187774235;

    for (int hVkoUmYSkHSLZzC = 1696063708; hVkoUmYSkHSLZzC > 0; hVkoUmYSkHSLZzC--) {
        CaKQRqY /= CaKQRqY;
        XLenAuWFDu = XLenAuWFDu;
        oAJrectrVdLsxy = ! oAJrectrVdLsxy;
    }

    if (MHIRElsEdVpRMC > -15446.967187774235) {
        for (int VygJfHnzxBM = 502744508; VygJfHnzxBM > 0; VygJfHnzxBM--) {
            XLenAuWFDu /= XLenAuWFDu;
            oAJrectrVdLsxy = ! oAJrectrVdLsxy;
        }
    }

    for (int nfFNaMyEkIVCkAel = 1043941388; nfFNaMyEkIVCkAel > 0; nfFNaMyEkIVCkAel--) {
        XLenAuWFDu /= XLenAuWFDu;
        XLenAuWFDu += XLenAuWFDu;
    }

    for (int HXWNxmHqXky = 472040354; HXWNxmHqXky > 0; HXWNxmHqXky--) {
        XLenAuWFDu /= XLenAuWFDu;
    }

    return KkPLHCUXxitGoZ;
}

double SICDSFK::DEcfvBmJOK(string oVLcYDaMunf, double GWKjCDjsrBhM, int CXXRU, int vqfXi)
{
    int zBhvBIJGVv = -288242033;
    bool YFcDf = false;
    int DlalKyiUmtxwaw = -1986841017;
    double qhYLZfgavftQYLxE = -701106.1006238299;
    int XCDUNdXuUFvKeFhh = -1703572287;

    for (int QWUsweZFr = 801669074; QWUsweZFr > 0; QWUsweZFr--) {
        zBhvBIJGVv = XCDUNdXuUFvKeFhh;
        XCDUNdXuUFvKeFhh *= DlalKyiUmtxwaw;
    }

    for (int zMoJElNMES = 1422537387; zMoJElNMES > 0; zMoJElNMES--) {
        DlalKyiUmtxwaw *= zBhvBIJGVv;
        DlalKyiUmtxwaw /= zBhvBIJGVv;
        CXXRU -= XCDUNdXuUFvKeFhh;
        vqfXi -= XCDUNdXuUFvKeFhh;
    }

    for (int sZSfeJqhWzQ = 1946524699; sZSfeJqhWzQ > 0; sZSfeJqhWzQ--) {
        DlalKyiUmtxwaw -= vqfXi;
        XCDUNdXuUFvKeFhh = DlalKyiUmtxwaw;
        GWKjCDjsrBhM = qhYLZfgavftQYLxE;
    }

    if (vqfXi >= -1972986999) {
        for (int NYQlphRUivHUqyyx = 1219916201; NYQlphRUivHUqyyx > 0; NYQlphRUivHUqyyx--) {
            continue;
        }
    }

    for (int fYTBeSlVTTP = 743142283; fYTBeSlVTTP > 0; fYTBeSlVTTP--) {
        CXXRU *= DlalKyiUmtxwaw;
        CXXRU /= vqfXi;
        GWKjCDjsrBhM = qhYLZfgavftQYLxE;
        zBhvBIJGVv /= XCDUNdXuUFvKeFhh;
        CXXRU += zBhvBIJGVv;
    }

    return qhYLZfgavftQYLxE;
}

bool SICDSFK::ByTTYQrvztdMtYx(double xOUVfgSO, bool iPJkEFAgLiWUsH, string gAyeWlKMthDU)
{
    double PbFuWGMO = -164908.98099222197;
    int NRQquHJifG = -1564209760;
    int GyKvJmmJNZ = -432395360;
    int MobMPOns = -938176452;
    string fNTANjIBvuQ = string("AzLEkUeWJqnTeDpzURYXSxCfWfYvpaiIXTlNYZdQEYHzGpWttLMimkEGQPXUQDJiADUnssDFngb");
    bool COqbPhfogjXVB = true;

    for (int gezEUJEBeq = 1903237722; gezEUJEBeq > 0; gezEUJEBeq--) {
        iPJkEFAgLiWUsH = COqbPhfogjXVB;
        NRQquHJifG -= GyKvJmmJNZ;
        gAyeWlKMthDU += gAyeWlKMthDU;
    }

    if (iPJkEFAgLiWUsH != true) {
        for (int wVsCMps = 1865497200; wVsCMps > 0; wVsCMps--) {
            fNTANjIBvuQ = fNTANjIBvuQ;
            GyKvJmmJNZ = MobMPOns;
        }
    }

    return COqbPhfogjXVB;
}

int SICDSFK::zrkiFzB()
{
    string ItpRpZYxQj = string("GCheXtOgWRQOeIHZlXoRxdNVpUHMRyezcfgcNiiXqrzqeswsbszfpoTCqlmeTGFSYhpkHkzOKKGCVgbuEBrJlgOLghuGjLBaCZKlvKxCussJPOtqZtdkGiPskgMRiWyFHkLCuoAfKeVxdLcUORjZeZjdeYyShaYMJxuNmvymFPuiUqeYpSqoNTZUsXnmrqPfUqpOycjNSnIXlBlYSgAdQPmsHhevQwhysDAIeMVDovojdADjAMEcfKtMDhQtcvS");
    bool YZaRb = true;
    bool JZBmCYS = false;
    bool ZFLxKKjnwrJj = true;

    for (int NfIyzh = 1439738126; NfIyzh > 0; NfIyzh--) {
        ZFLxKKjnwrJj = ZFLxKKjnwrJj;
        ZFLxKKjnwrJj = JZBmCYS;
        YZaRb = ZFLxKKjnwrJj;
        YZaRb = YZaRb;
        ItpRpZYxQj = ItpRpZYxQj;
        JZBmCYS = ! ZFLxKKjnwrJj;
    }

    return 1841448957;
}

int SICDSFK::qkSglPADTT(bool VKiHLZTKRQ, bool TNOsCLwcjloTBsw)
{
    bool VdojlQAKdsEHNikC = false;
    double ktiSttVYmvK = 945601.4713578196;
    int TSpxhUnJci = -164736842;
    bool rraIF = true;
    double mlykjxKUU = 403869.0974294468;
    int piDkodrgPJpf = 161468797;
    bool NYnRyDNYM = false;

    for (int myGMKDjI = 1571679243; myGMKDjI > 0; myGMKDjI--) {
        VKiHLZTKRQ = ! VdojlQAKdsEHNikC;
        VKiHLZTKRQ = VdojlQAKdsEHNikC;
        VdojlQAKdsEHNikC = TNOsCLwcjloTBsw;
    }

    if (VKiHLZTKRQ != false) {
        for (int LjwmJO = 1013522940; LjwmJO > 0; LjwmJO--) {
            continue;
        }
    }

    return piDkodrgPJpf;
}

void SICDSFK::PHXTMDSQGg(double hRxzVxFVrLdztI)
{
    bool lhnQVdMbV = false;
    bool uvrWGzEWmPv = false;
    bool rCKTRKUQN = false;

    if (uvrWGzEWmPv == false) {
        for (int DAvJOWcEXYhkuOd = 1432600190; DAvJOWcEXYhkuOd > 0; DAvJOWcEXYhkuOd--) {
            uvrWGzEWmPv = ! rCKTRKUQN;
            uvrWGzEWmPv = ! lhnQVdMbV;
            uvrWGzEWmPv = ! rCKTRKUQN;
            lhnQVdMbV = ! lhnQVdMbV;
        }
    }

    for (int cksYvMKmiZ = 1823852109; cksYvMKmiZ > 0; cksYvMKmiZ--) {
        uvrWGzEWmPv = ! uvrWGzEWmPv;
        rCKTRKUQN = ! rCKTRKUQN;
        rCKTRKUQN = rCKTRKUQN;
        lhnQVdMbV = lhnQVdMbV;
    }

    if (lhnQVdMbV != false) {
        for (int IsEFiEgu = 1997548618; IsEFiEgu > 0; IsEFiEgu--) {
            lhnQVdMbV = uvrWGzEWmPv;
            hRxzVxFVrLdztI /= hRxzVxFVrLdztI;
        }
    }

    if (rCKTRKUQN == false) {
        for (int XTTXa = 344144873; XTTXa > 0; XTTXa--) {
            rCKTRKUQN = ! rCKTRKUQN;
        }
    }
}

void SICDSFK::aSHAeORaRo(int aluLCFG, int WBZdg)
{
    string liUHPFAtfFKDDXk = string("vXEfFFkhRgNFywKzcbcHADktCjiEQFpVYOoHUdhqRXrZbdsyrmELYbKSyJpXFTFxTbxLleFwQvjIfaKwLBsGCpchoElZngxzkNPLXhtrUEplPlowRwonGnbkuRhdZxWwECZAhYWnOFcgAThZbEIQBjBkvmGiykUKSRayeUAoOZGzvVruGGmxpxwVBuOkQUmwIRnePILmVLuWhySZojUwHWHfuCMqSLKDlKWsVuSjVPJZBNF");
    int ADiZbYLNHnPczc = 608346307;
    int AXetulQ = 892049452;
    string htzwgEoax = string("INwHBRdFDqANJuppSAslCyQsMyZxtrrevllfrDNOuNfaqemBFXAfBBjQlcwSHtZMzBMnTXEldxPMLnlemWNsaVmrEXDfftQITqAKjEmKhkVSiXGrbCgENSkQsTWuTpyZZDLNlHDFOeUUunkHDPOfAhzkZwXEYAaJrvvkMrDEIEGmJLsPunmCBWFTNSijGlXJyhQJSSQkZNmpIJkjaIAOSkoL");

    if (WBZdg == 716893858) {
        for (int KZQDXtP = 1657075429; KZQDXtP > 0; KZQDXtP--) {
            AXetulQ += ADiZbYLNHnPczc;
            WBZdg /= WBZdg;
            aluLCFG /= WBZdg;
            htzwgEoax = liUHPFAtfFKDDXk;
            liUHPFAtfFKDDXk += liUHPFAtfFKDDXk;
        }
    }

    if (AXetulQ <= 608346307) {
        for (int YDZHUlLzOe = 756300647; YDZHUlLzOe > 0; YDZHUlLzOe--) {
            ADiZbYLNHnPczc = WBZdg;
            AXetulQ = WBZdg;
        }
    }

    for (int TqIijsVKbap = 244296140; TqIijsVKbap > 0; TqIijsVKbap--) {
        continue;
    }

    for (int numZHISaTuIcoJ = 466821581; numZHISaTuIcoJ > 0; numZHISaTuIcoJ--) {
        aluLCFG *= WBZdg;
        WBZdg -= ADiZbYLNHnPczc;
        WBZdg += ADiZbYLNHnPczc;
        AXetulQ += aluLCFG;
    }
}

double SICDSFK::SzIAMYIuAkXlM(int MdCFOCowu, double qreFVsBBrKc, bool ExLQzUor, bool iMpUknzseihZ)
{
    int nNcPNeqtO = 612260928;

    if (iMpUknzseihZ != true) {
        for (int vmRIENtytzsZn = 725292169; vmRIENtytzsZn > 0; vmRIENtytzsZn--) {
            qreFVsBBrKc += qreFVsBBrKc;
        }
    }

    return qreFVsBBrKc;
}

double SICDSFK::nWCQKbiv(int CrZvOAeiuMQuQq, bool vHDCJrBRiwsZfPf, string wOvKpsc, int HaEQFSKPoSMfiJ)
{
    string nUHMdeK = string("DfYUXrqkqdsxkzbhxoBbQW");
    int HXQFMlLQN = -1486307837;
    double ZZDXcQ = 879644.3808123365;

    for (int RUnmreKhSXJTBC = 2065243898; RUnmreKhSXJTBC > 0; RUnmreKhSXJTBC--) {
        HaEQFSKPoSMfiJ += HaEQFSKPoSMfiJ;
        vHDCJrBRiwsZfPf = vHDCJrBRiwsZfPf;
        HXQFMlLQN -= HXQFMlLQN;
        CrZvOAeiuMQuQq /= HXQFMlLQN;
    }

    return ZZDXcQ;
}

SICDSFK::SICDSFK()
{
    this->IqoQLfMDCweVZXI();
    this->QawhgImKvbvn(false, string("PwvgBDnVrrIrLhjVIKGstbzBpQPPugHLVilGgOlSIRYyFBhBQWpIoILAuRZqYXWtYEqWOpjUNuDVRryIUbbWagykVejUyTplxXhtRICJZymunHSUCWFYMqZnpSzsNsNIehagMRdVCclKNgQqnWNXKXNhAMuOzyfPabTwFhxmMZgMcJENnfUqrfBgqkjOdJfmQgCBuHjAyLvFhkNSCaExJFytpZxbZmeWPOIjmRygZhNMe"), true, 1983286735);
    this->fdeGlRqAnMTz(string("bWiLkQBBtjqKtNjIoFSltrxHCuvdysIUIPzojGOiZoBIdlQQvPNPCMRxZQRQpySQleFPcICHVOvdOuImUrnPVGQzYzkSxKSlHtxlAiCYUDMKpuILapiKeHaAkeJfqVxrTrCKgbOokVvLPBXOEKOiPbKeaGUcYdAkyOtlzFcQHLAdZzaRdzCeecOyXwgjjzqaYtWFOxDUvyYYxBvuVKVPpuXYTrvSvTNRkPZrClSEhujyxyzzzDlhXLlwEiqWzFN"), false);
    this->vRCeJzj(true, -67589.39711838937, string("nsDsAcxBLcLiKQjIFyvwyCuMYopcAlvicgpQJEsKveVxLeSBulYksIEGceNtqVyCKdlMpRRwjePrnLHbsnDAJsoLaUVlzEUddQIwYwavMcscdboRnsfwjvWhiSfPdeuEhkTkMPLRrVrnaccC"), string("ajyoXOoMzbUlUfvKnagXJDXBYlAZZxtyxJiFspNnWnLOPTZJQ"), -423903536);
    this->huGjYiPZBt(string("SbYVHoEFWnzwXDLpdObezwRbmwBQZqD"));
    this->mRGnhhsxJVBbieKF(429446.8394061025, 395581184);
    this->TIdNB();
    this->fPYarfEpKyxqj(string("UWaYzUTUMMWyvXQEIoekGXWfPTNpUkcbIXQXGkFmeJYxXPTADnmT"), true, 656382.7760204029, 185673315);
    this->fWJaTApVzH(string("aDwtBoAOtFYralQSoSpwQHgXLzMRHlDRICjckPrGbrSaMrCe"));
    this->DEcfvBmJOK(string("KOBUqYUfqnTaKAahzrfsagLipaQKxMpfhpslGJgFEwUmJufaWJdAJnCOrFaQkNHVIXMpWMIsBBlqodlJIooxpaPeuptchfgHXNTaBbB"), -635362.9741652044, -1972986999, -365690145);
    this->ByTTYQrvztdMtYx(800610.1766760511, false, string("QEgwnrpqAaPefjaLxMPJkpniTPvcPddmQLBRraBCtAKWsOkKHrQthoVQYUEUzlLcsnAMxRJfgxOsmdiwaRmmhprhSJRvYMEMxFhcGsSZLKaDvTifFBReDIdnHceCJmUFxlrkOK"));
    this->zrkiFzB();
    this->qkSglPADTT(true, false);
    this->PHXTMDSQGg(110162.70002702679);
    this->aSHAeORaRo(-686725454, 716893858);
    this->SzIAMYIuAkXlM(-1507047346, 370005.8473112312, true, true);
    this->nWCQKbiv(1646464045, true, string("GSBbtqVxVWCktYNOCECNMxMNQHsEhrWDDXlv"), -1927037154);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HerdWDzZBXoZvzli
{
public:
    bool QgJylXLglbATxhMq;

    HerdWDzZBXoZvzli();
    void zLdDFtlMkZf(string lzCpkbzuFWQGuI, int QvWDKW, bool gQIgF, bool OOfJuiBR, string kvXvvusNBxHdmHb);
    double Vortje();
    int uicqJW(double IcjTYfxBeuWSAo);
    bool CAoORLDzjUElegE(bool lVGbwDoNV, bool fdOlWNasBF, bool LEfdLJ, bool aFPWYFxDoLHOG);
    double DoDis(string yyXcEfzSTvn, double JXryhifcJzVMwj, double WMbLjdtqGr, int gLNijeWpqyQYQU, int wJypNoJJlFtaRKku);
protected:
    string jUhPKAqcOLoBAHtO;
    string OnhEGz;
    int UFMts;
    bool mdLzjv;
    double GXgNc;
    string dudZYrAkxVx;

    string zHWOeOlDnvyDPVP(string GBRKmcHfYGm, double yGyIwrRaPVfKwLuO, bool xjlntMqhVRltPE, int hPKDEaiia);
    void KkKmEsOA(string QVDPqYYU, int mjWrtvNFA, bool VHKVbHqSa, double xPKatfxUZ, string fUPvmahkQRjIJVw);
    int VBApDXEeRhI(string kIebERMeNs, bool hNjVnxxsfsqJvx, double jAhTqjKotCNuaQo, bool BkyaEZAJCzciDq, int DuwlTSOSpNYbCAj);
    int vucRxDVo(int hKtGpkuXkYRQsk, int bNGRSFVkQYimN);
    string KNDmzFLN(string oGyhNpAIIoeVQfvy, bool wSmBfJSbmQ, double GUvNfRKYB, double QTIqWwTphsChqYV);
private:
    string igmigyychNRdv;
    bool ioQmlAQVmdlb;
    string BtYzzZRQQwudqkYs;

    double hNKFnVMEkXGYkXbJ(double YftnHwG, double jATICpp, bool BhnJEbsddZewnbOx, bool GJtnAuLNtva);
    bool qrwYVrVQ();
    void dnApNDc(double ocomoChaPrzBgRT, double LgiqLksmDo, double LsCsPF, int uZiwRFtSbJJC, string eLlkkhsI);
    double zDbDjWKjBCKAL(string yWOlKFBmsvabaBxL, double DVTzJ, double mSEjGzqT, bool DWeVZiKNzNnNP);
};

void HerdWDzZBXoZvzli::zLdDFtlMkZf(string lzCpkbzuFWQGuI, int QvWDKW, bool gQIgF, bool OOfJuiBR, string kvXvvusNBxHdmHb)
{
    double gwuIi = -864136.2435370982;
    int LDmdbQcnembnmCjZ = 1390772583;
    bool RsCswSQe = false;
    double DLiFFzkDgCcGkZPS = -164470.0364849926;
    string QgLpb = string("RnngWSkgTrCmkdpOQlNqaltwdMGbOKHWWVyYtPaWNZDIIYxDAyzcayaSHzEbGbCAiHPOZBAwFBDbjdvyoLTUrjrkIOpbMqDjJjDPkIprvlghppukwrmyvQjjqfvGITSZUXFLztFecczNJlwPeODvnsHYsyDQktUChpbrjoSoYrhwZBbHpPIoz");
    int rNRJNBmNLpa = -1387332109;
    string DeJjmci = string("DKDCwAEVQTpcTZSyZxrSmstcZnQrSzyBSruMqPqPMdLkkuLLQLQtWcFHHvAHyJRtDfhAVIeolgJRhTQvhrNNEzxHVCXlcmHPucpjSnijKAYwNLZHIIhytGUeczZWxvDNvEgjTEKcdyRSFfJajpPaLjkNzVesafABs");
    int Vyznci = -880259804;
    int GJXSp = -1436713806;
    bool XhrwRVSMfClPBY = true;

    if (RsCswSQe != true) {
        for (int NyVErvNVjyqMLpt = 1449585881; NyVErvNVjyqMLpt > 0; NyVErvNVjyqMLpt--) {
            OOfJuiBR = OOfJuiBR;
        }
    }
}

double HerdWDzZBXoZvzli::Vortje()
{
    string beLaflrxEYIJR = string("OfiGPORFFUwrJvnchMLVbFBXHlJwLZJLsekIUCtVhSdXVidi");
    double crCstCflCgfx = 843278.8243442195;
    string ZWNDihdERpe = string("rEyTwdsgWRFgtDzqZUrnfRgxJYcuhFzTSmtNAdHlWYwRDUVBbOaaMXBSYLIjqGchBNSIUghzpiAkohdTqpctTFzKooAAoSMEIKkxUzOIqDFYnqPJkPAqGzXSsqDJVXdiEljKEpb");
    string bgLeGbHrAcTqWo = string("zIpKVZxRDWCpGagdeWXOViBqFPvWFlMfEzDSJVMepaJBgAwlyUfWRymAVUeDIumSDfJSJfGOSybvOxBDHwwvQQQxZCapvVigSCMmNtgzxFcyzwjlHmZgrVvaLejamTZDOoBrnpibzfzmumprrOLYWNybHgNsuPEAMacKHqhJHEbbQLJyCvsRMRMzsTCJNGuMYZcuhQN");

    return crCstCflCgfx;
}

int HerdWDzZBXoZvzli::uicqJW(double IcjTYfxBeuWSAo)
{
    double SzQExvNz = 844953.4805361783;
    double JnlwieQhwZqHACDJ = 87054.64255970353;

    if (SzQExvNz != 87054.64255970353) {
        for (int LFkCdATS = 774997909; LFkCdATS > 0; LFkCdATS--) {
            SzQExvNz += IcjTYfxBeuWSAo;
            IcjTYfxBeuWSAo /= IcjTYfxBeuWSAo;
            JnlwieQhwZqHACDJ += SzQExvNz;
            SzQExvNz /= IcjTYfxBeuWSAo;
            SzQExvNz = SzQExvNz;
            JnlwieQhwZqHACDJ *= JnlwieQhwZqHACDJ;
            SzQExvNz = SzQExvNz;
            JnlwieQhwZqHACDJ += IcjTYfxBeuWSAo;
            JnlwieQhwZqHACDJ *= SzQExvNz;
        }
    }

    if (JnlwieQhwZqHACDJ > 87054.64255970353) {
        for (int ZzyoehDGdW = 1385447909; ZzyoehDGdW > 0; ZzyoehDGdW--) {
            JnlwieQhwZqHACDJ /= SzQExvNz;
            IcjTYfxBeuWSAo /= SzQExvNz;
            JnlwieQhwZqHACDJ /= SzQExvNz;
            IcjTYfxBeuWSAo *= SzQExvNz;
            JnlwieQhwZqHACDJ += IcjTYfxBeuWSAo;
            IcjTYfxBeuWSAo -= SzQExvNz;
        }
    }

    if (IcjTYfxBeuWSAo == 844953.4805361783) {
        for (int RTOzYjdUpbFiQ = 812838628; RTOzYjdUpbFiQ > 0; RTOzYjdUpbFiQ--) {
            SzQExvNz = JnlwieQhwZqHACDJ;
            IcjTYfxBeuWSAo *= JnlwieQhwZqHACDJ;
        }
    }

    if (SzQExvNz >= 844953.4805361783) {
        for (int xQAyO = 201507050; xQAyO > 0; xQAyO--) {
            IcjTYfxBeuWSAo -= IcjTYfxBeuWSAo;
            SzQExvNz += JnlwieQhwZqHACDJ;
            JnlwieQhwZqHACDJ += JnlwieQhwZqHACDJ;
            SzQExvNz += JnlwieQhwZqHACDJ;
            IcjTYfxBeuWSAo += IcjTYfxBeuWSAo;
            SzQExvNz /= JnlwieQhwZqHACDJ;
            SzQExvNz += SzQExvNz;
            IcjTYfxBeuWSAo /= SzQExvNz;
        }
    }

    if (JnlwieQhwZqHACDJ > 868708.3403616316) {
        for (int pawJCcYs = 1592011847; pawJCcYs > 0; pawJCcYs--) {
            IcjTYfxBeuWSAo *= SzQExvNz;
            SzQExvNz *= JnlwieQhwZqHACDJ;
        }
    }

    if (JnlwieQhwZqHACDJ > 844953.4805361783) {
        for (int GzXBjmUMDd = 310298632; GzXBjmUMDd > 0; GzXBjmUMDd--) {
            SzQExvNz -= SzQExvNz;
            IcjTYfxBeuWSAo += IcjTYfxBeuWSAo;
            SzQExvNz /= SzQExvNz;
        }
    }

    return -1296304642;
}

bool HerdWDzZBXoZvzli::CAoORLDzjUElegE(bool lVGbwDoNV, bool fdOlWNasBF, bool LEfdLJ, bool aFPWYFxDoLHOG)
{
    bool JdREY = true;
    double WIeFzcDTIHbFV = 914992.8590246744;
    int WsnDATkjj = 456001379;
    string nOHrCZ = string("vWGeIdRZQycrdkdFmqMWuEUZoxrEvVBXsMBJlmSmDvOGsrJNArWzCBcdlwgOseQZmUMdVOCvrnL");
    bool YMAyDLVP = true;
    int PPbwCA = -1738766487;
    int KZcxdnAz = -1857685876;
    int vaFGwdiVL = -1481284728;

    for (int vvSVJVDX = 1917899966; vvSVJVDX > 0; vvSVJVDX--) {
        YMAyDLVP = fdOlWNasBF;
        JdREY = ! YMAyDLVP;
    }

    if (fdOlWNasBF != false) {
        for (int OBMnRKelCH = 297504342; OBMnRKelCH > 0; OBMnRKelCH--) {
            fdOlWNasBF = ! aFPWYFxDoLHOG;
            LEfdLJ = lVGbwDoNV;
            fdOlWNasBF = YMAyDLVP;
        }
    }

    for (int bVmxtcUcTK = 593382454; bVmxtcUcTK > 0; bVmxtcUcTK--) {
        fdOlWNasBF = lVGbwDoNV;
        YMAyDLVP = ! lVGbwDoNV;
        WsnDATkjj = WsnDATkjj;
    }

    if (JdREY == false) {
        for (int gdhOkSpHA = 68473831; gdhOkSpHA > 0; gdhOkSpHA--) {
            lVGbwDoNV = ! YMAyDLVP;
        }
    }

    return YMAyDLVP;
}

double HerdWDzZBXoZvzli::DoDis(string yyXcEfzSTvn, double JXryhifcJzVMwj, double WMbLjdtqGr, int gLNijeWpqyQYQU, int wJypNoJJlFtaRKku)
{
    bool mmTmoPGinYy = false;
    bool IXBtOfSRLH = false;

    if (WMbLjdtqGr < 252484.10970816607) {
        for (int FFfSkydkCtYhrv = 1398525678; FFfSkydkCtYhrv > 0; FFfSkydkCtYhrv--) {
            continue;
        }
    }

    if (WMbLjdtqGr > 252484.10970816607) {
        for (int JPysWK = 348915866; JPysWK > 0; JPysWK--) {
            continue;
        }
    }

    for (int OvVYUGZVDU = 108483835; OvVYUGZVDU > 0; OvVYUGZVDU--) {
        IXBtOfSRLH = ! mmTmoPGinYy;
    }

    for (int EIHhSIgfIRy = 59120894; EIHhSIgfIRy > 0; EIHhSIgfIRy--) {
        WMbLjdtqGr = WMbLjdtqGr;
        gLNijeWpqyQYQU /= wJypNoJJlFtaRKku;
        gLNijeWpqyQYQU += wJypNoJJlFtaRKku;
    }

    return WMbLjdtqGr;
}

string HerdWDzZBXoZvzli::zHWOeOlDnvyDPVP(string GBRKmcHfYGm, double yGyIwrRaPVfKwLuO, bool xjlntMqhVRltPE, int hPKDEaiia)
{
    string anfLwWMgKiMPZ = string("DCnLCpEkdvbiaALoTGYnpezTGTPClahQlfVtySqkWnagxiMStDHlAzFykNuvwcylhvRjFMJjgsRyXyrzvasUcLsDYKDyLhqJILNvmatFKxUOmYoanbyCZAYGqMKzhGrtavapsfHKJbOsyoqRZLdxbQbXZnpXBieKTP");
    double TVpkPPYRm = 940009.9452988175;
    bool beryCFLoUtdHOj = true;
    string ubJeTSlbF = string("lIEGRYrnOZLwZsWsQYKjGMueDJWxEZxyAXJndFRmSexCwQvepsrALumxoNAOBaZNiygSuOFJnKZol");

    for (int EELGnKZp = 1916079262; EELGnKZp > 0; EELGnKZp--) {
        anfLwWMgKiMPZ = anfLwWMgKiMPZ;
        GBRKmcHfYGm = ubJeTSlbF;
        anfLwWMgKiMPZ += anfLwWMgKiMPZ;
        TVpkPPYRm += TVpkPPYRm;
        yGyIwrRaPVfKwLuO -= yGyIwrRaPVfKwLuO;
    }

    for (int OTWPWtBcWW = 48863873; OTWPWtBcWW > 0; OTWPWtBcWW--) {
        ubJeTSlbF += anfLwWMgKiMPZ;
        beryCFLoUtdHOj = ! beryCFLoUtdHOj;
    }

    for (int VkpvGvrgixbeCtWn = 2086470459; VkpvGvrgixbeCtWn > 0; VkpvGvrgixbeCtWn--) {
        continue;
    }

    return ubJeTSlbF;
}

void HerdWDzZBXoZvzli::KkKmEsOA(string QVDPqYYU, int mjWrtvNFA, bool VHKVbHqSa, double xPKatfxUZ, string fUPvmahkQRjIJVw)
{
    string ntLNKV = string("SnWJhBjLTMIhHbAbIgvxCWQISqfjSRubipojyZbXaYWVGrFLaJPWqQVFLIROxAxhPTQzefIIrrDWXGpsaZxRVftJOnHhYTuwxFYgdqXANFKHlGjahxchgTKYujjoYZTuWvKGGLeaQUkDGGNrhFxXFlCPXahGaFhzNbseCpuJgxuYBNhtIdAlsegsSTzQbAmRlyERWLIrnLNaUiN");
    string CUVgTNC = string("aaHqtroPdmQLoSFucJVEZAjQkofjBmJpgbCnxnEJRGsvcLhCdiwCWHmUtQWmLDfmHRZOUjrXWRIOGbAfIpLXdoeuhQKrbRzNJbrVUGRvTCHKRHvuxlGzhJYQGOCDsKcSgljGubJOdEadADqjGXBoaepNXtpqukyoEoyGuCEhMiSjfKZUywohcolrdfvmojvDxcKLMTnRxmctJMtkpBmoTABfcXqPaQjyCbLSfCeAYjsHbeBqVdvCoKOU");
    bool qpBxpSSWWiez = true;
    double tYfrdnqBTLKL = -137543.2106364927;
    string OWWskMf = string("zjxpLUnzGmQfwqdujldJRMShVfNBpzIvmLoSMyJznowoOaLxXkGHSrveBuZfDPmadmuBmfILPURETaFFMbAYRUOXagdwsvUoheGHMcdWxjZLkkXptzE");
    string fQPXPcPO = string("cHaaxMvCqUxeemcIyYkFwsigseJVjVCOmzifA");
    int FrkxkOhR = 683833497;
    bool gnsKYGNaWm = false;

    for (int vwdtYwk = 301210639; vwdtYwk > 0; vwdtYwk--) {
        continue;
    }
}

int HerdWDzZBXoZvzli::VBApDXEeRhI(string kIebERMeNs, bool hNjVnxxsfsqJvx, double jAhTqjKotCNuaQo, bool BkyaEZAJCzciDq, int DuwlTSOSpNYbCAj)
{
    double lhxsISHEoUmD = 237314.25809393282;
    string AELFURSVtY = string("HHqZkSXXishFeUrCcnDCocKywScsuADJZNvgcRipRgBaZokBLG");
    double rZKqiDGXobKbkoC = -78804.41182440001;

    if (rZKqiDGXobKbkoC < 237314.25809393282) {
        for (int FLWuoRWSuW = 577091707; FLWuoRWSuW > 0; FLWuoRWSuW--) {
            hNjVnxxsfsqJvx = ! hNjVnxxsfsqJvx;
            jAhTqjKotCNuaQo += rZKqiDGXobKbkoC;
            rZKqiDGXobKbkoC = jAhTqjKotCNuaQo;
            AELFURSVtY = AELFURSVtY;
            AELFURSVtY += AELFURSVtY;
            rZKqiDGXobKbkoC += lhxsISHEoUmD;
        }
    }

    return DuwlTSOSpNYbCAj;
}

int HerdWDzZBXoZvzli::vucRxDVo(int hKtGpkuXkYRQsk, int bNGRSFVkQYimN)
{
    double KdAws = -885690.3203883575;
    int uPLcMov = 775815757;
    bool VFROFPJyc = true;
    string bEUwExEpWvWTRZwh = string("ozznEjcVtKCiyXuoXSdDxG");
    int yQHnvXIQhFXBV = -566882907;
    string ZxZrBTtqHooYt = string("jAIYNmQNBwYbovGBnkIFAzfugWnHkPAfucvoBxQBWYvqwterARzsjdKUgiEhdARulTOfTCosEceJljejSAhWqRYpRdqkrbiEciKNKbTIiZUmMFaNAnstfOteictukFqVnyGNTsDoDJyzS");
    int KrOJW = -932058992;
    int NhyuAgP = 578060202;
    double lYhBKDYKDqr = 941854.8564326325;

    if (bNGRSFVkQYimN >= -345757962) {
        for (int djUVdvEIoierN = 1560997713; djUVdvEIoierN > 0; djUVdvEIoierN--) {
            NhyuAgP -= bNGRSFVkQYimN;
            KdAws += KdAws;
        }
    }

    for (int QJiAvLiaiFzc = 1254314008; QJiAvLiaiFzc > 0; QJiAvLiaiFzc--) {
        continue;
    }

    for (int uDRPJGnCyHQstW = 1736217951; uDRPJGnCyHQstW > 0; uDRPJGnCyHQstW--) {
        yQHnvXIQhFXBV *= yQHnvXIQhFXBV;
        yQHnvXIQhFXBV = KrOJW;
    }

    for (int ZfvyLDjTbtGewY = 308771351; ZfvyLDjTbtGewY > 0; ZfvyLDjTbtGewY--) {
        continue;
    }

    for (int EptdddbxBSnVeDaH = 60253609; EptdddbxBSnVeDaH > 0; EptdddbxBSnVeDaH--) {
        continue;
    }

    return NhyuAgP;
}

string HerdWDzZBXoZvzli::KNDmzFLN(string oGyhNpAIIoeVQfvy, bool wSmBfJSbmQ, double GUvNfRKYB, double QTIqWwTphsChqYV)
{
    int aVDbZ = 1167240752;
    int XYqMiYnwAdFdtJog = 500032754;
    double lYmUnvzK = 225055.08497130175;
    double hOmsBaCcTT = 928138.9446256206;
    string icZAybOxKkckdas = string("QoUEELQcBEnPcRFqPHHlPOAMzuFuQQhNsrREXomORPSxNJbkzTewtPhyHHsfplGfgzJXay");
    int idlRmIJEwxRwVlY = -1255373509;
    bool dOwvFxtepocaN = true;
    string vHcjiOeEUI = string("nABHvCkbUikbXyVesBnArkOPWaueaVSqtqBhXgqvbXEqOOIKKXleRdHIoCeIVyySElxJyQKvAmnZLDPePRZyKuRhkJGWSZOuKlldKLvtuuCymSVHeVGBFJDUCwrAywzFlAclHSlCobOIvxkvVYbIgrnvjh");
    bool DADbMiLUxrAhO = false;
    bool soTmHv = false;

    for (int eLSZyVO = 394593314; eLSZyVO > 0; eLSZyVO--) {
        vHcjiOeEUI = oGyhNpAIIoeVQfvy;
        oGyhNpAIIoeVQfvy += icZAybOxKkckdas;
    }

    for (int MvrPfwcqyvjk = 1669443110; MvrPfwcqyvjk > 0; MvrPfwcqyvjk--) {
        continue;
    }

    for (int FOLuiQAGUkSmI = 573159853; FOLuiQAGUkSmI > 0; FOLuiQAGUkSmI--) {
        oGyhNpAIIoeVQfvy = oGyhNpAIIoeVQfvy;
        QTIqWwTphsChqYV /= QTIqWwTphsChqYV;
    }

    return vHcjiOeEUI;
}

double HerdWDzZBXoZvzli::hNKFnVMEkXGYkXbJ(double YftnHwG, double jATICpp, bool BhnJEbsddZewnbOx, bool GJtnAuLNtva)
{
    bool AWgozzRLOhxc = true;
    string fJJrXVqhXlMbzji = string("yXRWinljMPLNpSTscNZQdEpiCAVvZOCCYHJFPUFBxobMLKfWvZfJNYOOYGmQFujSWFWIR");

    for (int muHWDnfr = 1813851972; muHWDnfr > 0; muHWDnfr--) {
        YftnHwG = YftnHwG;
        AWgozzRLOhxc = BhnJEbsddZewnbOx;
    }

    for (int drpwqk = 2000256421; drpwqk > 0; drpwqk--) {
        AWgozzRLOhxc = ! GJtnAuLNtva;
    }

    for (int oCBCxwygtcYkVseO = 1833941224; oCBCxwygtcYkVseO > 0; oCBCxwygtcYkVseO--) {
        AWgozzRLOhxc = BhnJEbsddZewnbOx;
        jATICpp *= YftnHwG;
        AWgozzRLOhxc = GJtnAuLNtva;
        GJtnAuLNtva = AWgozzRLOhxc;
        jATICpp *= YftnHwG;
    }

    return jATICpp;
}

bool HerdWDzZBXoZvzli::qrwYVrVQ()
{
    double zYSCrOCIP = -927242.3922445078;
    double KmspXzJiARtus = 802349.0126934136;
    int nxjtgGKoOrq = -635482357;
    double CeAuomsBhXpuI = -684485.6367624268;
    bool xBTjBASo = true;
    bool kycHqn = true;
    double nosLpVK = 766570.2838162524;

    for (int fdHTgZt = 1770261484; fdHTgZt > 0; fdHTgZt--) {
        zYSCrOCIP -= CeAuomsBhXpuI;
        kycHqn = ! xBTjBASo;
        KmspXzJiARtus *= KmspXzJiARtus;
    }

    if (zYSCrOCIP <= -927242.3922445078) {
        for (int WXXPBQ = 1137629934; WXXPBQ > 0; WXXPBQ--) {
            KmspXzJiARtus /= nosLpVK;
            nxjtgGKoOrq = nxjtgGKoOrq;
            zYSCrOCIP = zYSCrOCIP;
        }
    }

    for (int CCxGfepsH = 693545177; CCxGfepsH > 0; CCxGfepsH--) {
        kycHqn = xBTjBASo;
    }

    for (int uiArFQzaphHsNq = 69249724; uiArFQzaphHsNq > 0; uiArFQzaphHsNq--) {
        KmspXzJiARtus -= CeAuomsBhXpuI;
        nosLpVK += nosLpVK;
    }

    return kycHqn;
}

void HerdWDzZBXoZvzli::dnApNDc(double ocomoChaPrzBgRT, double LgiqLksmDo, double LsCsPF, int uZiwRFtSbJJC, string eLlkkhsI)
{
    bool voQEh = false;
    double UscqYmzdvENMr = -985639.0466647157;
    int nlHCQaLuNoPaK = 1322343804;
    double aKzlonJByiFMAdzA = -92811.49433713514;
    int wSgiFBkBTOoeViZ = -129983122;

    for (int kcdXj = 396555167; kcdXj > 0; kcdXj--) {
        LgiqLksmDo *= aKzlonJByiFMAdzA;
        aKzlonJByiFMAdzA -= ocomoChaPrzBgRT;
        LsCsPF -= aKzlonJByiFMAdzA;
    }

    if (LgiqLksmDo > -135674.65536084375) {
        for (int vDpMxsmGxH = 1657754185; vDpMxsmGxH > 0; vDpMxsmGxH--) {
            aKzlonJByiFMAdzA = LsCsPF;
            uZiwRFtSbJJC += uZiwRFtSbJJC;
            nlHCQaLuNoPaK *= uZiwRFtSbJJC;
        }
    }

    for (int BulMgetWvisQz = 1566218734; BulMgetWvisQz > 0; BulMgetWvisQz--) {
        LgiqLksmDo *= ocomoChaPrzBgRT;
        LsCsPF /= LsCsPF;
        ocomoChaPrzBgRT += LgiqLksmDo;
    }

    for (int TVIAirHtCL = 425284602; TVIAirHtCL > 0; TVIAirHtCL--) {
        wSgiFBkBTOoeViZ += wSgiFBkBTOoeViZ;
        eLlkkhsI += eLlkkhsI;
    }
}

double HerdWDzZBXoZvzli::zDbDjWKjBCKAL(string yWOlKFBmsvabaBxL, double DVTzJ, double mSEjGzqT, bool DWeVZiKNzNnNP)
{
    int YatTiFOIDKD = 640780469;
    bool wVamQqxsVAoN = true;
    bool dCPhCAgvee = false;
    bool UoMGAQSEDnTU = true;
    int znJDYTDJtviFyTBh = -1204792037;
    bool HFZPmfpuiNOrmo = false;
    double PqQCFFrimoHfnWj = -29805.581074569316;
    string muxiLpDxmQ = string("IOuZPrXHsuUWEndrpevWJrJbIZUIHDaQfWJgblSGmPfFivZlUNxLalrtcstkzGyTfPvYyzQXZmbafTF");

    for (int JDXLxMLV = 250591934; JDXLxMLV > 0; JDXLxMLV--) {
        wVamQqxsVAoN = DWeVZiKNzNnNP;
        DWeVZiKNzNnNP = ! dCPhCAgvee;
    }

    if (wVamQqxsVAoN == false) {
        for (int VMKZiYKuH = 2002659513; VMKZiYKuH > 0; VMKZiYKuH--) {
            continue;
        }
    }

    for (int NtYoMiWPNr = 98650584; NtYoMiWPNr > 0; NtYoMiWPNr--) {
        YatTiFOIDKD -= znJDYTDJtviFyTBh;
    }

    if (znJDYTDJtviFyTBh == 640780469) {
        for (int smrRI = 2130011123; smrRI > 0; smrRI--) {
            wVamQqxsVAoN = ! dCPhCAgvee;
            mSEjGzqT += DVTzJ;
            mSEjGzqT -= PqQCFFrimoHfnWj;
            UoMGAQSEDnTU = dCPhCAgvee;
            mSEjGzqT *= mSEjGzqT;
            dCPhCAgvee = ! dCPhCAgvee;
        }
    }

    return PqQCFFrimoHfnWj;
}

HerdWDzZBXoZvzli::HerdWDzZBXoZvzli()
{
    this->zLdDFtlMkZf(string("lotSfkVgFrNgZIgSEQskOwayhzMHBDqyacfJPInAneBZLTLBuFiPKlDquAvNfFQQ"), -168497745, false, false, string("MwgCbgkaIcSXQTWwQEMadwQvutZA"));
    this->Vortje();
    this->uicqJW(868708.3403616316);
    this->CAoORLDzjUElegE(false, false, true, false);
    this->DoDis(string("BrSMpoqNtzqcPHIVMcXzaSNfyYLjDJnXmwGFDrwZxMwUBZnLDPjIPxOHgcgBPNkyqFCuRToEedOknEauDDwXATvfTwuOxVVftWbixHFrIgsBbSihTkEolSNCsqJpXruyZ"), 580742.1821348929, 252484.10970816607, 108044516, -1356776669);
    this->zHWOeOlDnvyDPVP(string("zmpGsxUazTenOlMEluHTolwnIWMpZfzxRpfmXnfMJpdQfexVCpvtUBuYdxXxpiqMEWXjYAVwBfVRGOMYOfRsDQkbQLHZuzAHXoUpGgiowqawxDtPADaKnkBmGMCohfzfsUHLoLOCVNhvIaruhbuwkJozrVKxemIdfNVdHMuEAZmIUavkemW"), -650303.9012578522, true, 528933052);
    this->KkKmEsOA(string("kXTmIqnbntiKjLmXYPNJwoewWiXyanSqzFGBDdDsXxjKSQRJChTdiBObPZPBAGyTNWawRAkkrGmWfSEQvusmRuVOJHmDDaxgXoALwNhkvpwqHJagYORpHaXgJLpTcUROXxyFFdXFfgviIbvhneLynrMOpxAgruqyttnkemOICxzidzaW"), -1215576498, true, -737951.6062818951, string("uerWadJqwzWYkNboAFEDXGkiYrxloSSPPDFJAjSLQGqCqEIvRlAHrIFTnbdfISkvRcQhwsdMmEepKQoElAvCJgfUbhZaLxPNrGwdpRJHkGHMrTFyfDRatxmqaRGrSNwkvnvfrWEjmMAudpVdTaIUYGvtRqXkATRVkvcsLlTDozRmzRTNliaOxsTyRwORlq"));
    this->VBApDXEeRhI(string("IfidkROwfM"), false, 774133.6076867399, true, 1248870721);
    this->vucRxDVo(-345757962, 47754114);
    this->KNDmzFLN(string("kGbfQoMffxBPWSrVWQMIIGvasBOPlsrtyVGZzzJMcknADjbniTulIoFcjAusfSWxLqYLsJiqWVmRphKXAiHGWdqBjXsiwZtzPbaLckHOLUCIUAnsrQTlLPmJQtBNcyGcFTAtXqGyWoUTamcAvRPRJRXkMOQCBvoTlIJaGHmpfOCwzRksiRcIUZbHeGfFyFQIdtLyPNeLAjFasKoFsOE"), false, -773154.2743917989, -60468.42375383193);
    this->hNKFnVMEkXGYkXbJ(652007.1583090919, 495964.1597449853, true, true);
    this->qrwYVrVQ();
    this->dnApNDc(662029.1195306886, 303659.90896299086, -135674.65536084375, -1254052251, string("REVqoHuHwodmyiRmogliwZozYicplNlDntnLqxnyQUylMebjapfjg"));
    this->zDbDjWKjBCKAL(string("cxhoHvTKbcvqxgshnfxLPMKSDZPdnkfoZDHIuJMBMVOwUfxERgwNGJHiWyIfwXerlGpVtwqFgQidmPISBeiiECWXyVFXXsbRStGha"), -144799.5344083289, 605612.2942048544, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZqGkepTGrEQOXhy
{
public:
    string IPwOL;
    bool ZNtMFv;
    double zroxHnTDARp;
    double rRwcDXXyRxad;

    ZqGkepTGrEQOXhy();
    string lpvFqmYeeQDHBVF(int hBTENcSBGii, int uSYJRrWVgBXAj, double MGNcxNKnVgTU, string XQsGUFCgHaqC, bool egGieOSHAFOy);
    int etqOJ(int YfqKRSo, string LPAGf, double valkfjHQIcYIkBa, bool wyDoh, int ZFNgAPCcFwnY);
    void ugmkqLJoUMZc(double sdnjDRWj, int yanVzIqqMoCMel, double GyFNbS, double dOocxxQmViDnYn, double bbAunSwjc);
    int JkYXoe(double wdNcnwXuQyTTLp, bool nYoca, string ywQtMQkfzzAF);
    string XMUYHaKzDh(double xgRjachmCBYJefG);
    int seBTslQsCnzC(int nqOLPxCMAgqTfMsv, double AtvqzAn, string JiTnvNDzBHysGgYO, bool muxlNzba);
    string AeSXXgQFpzUt();
protected:
    double lpPAQcYxMXMBPK;
    bool MamqaQJXu;
    string RqUQCJTjdchk;
    string yTHfqSdtAw;
    double sirwVPdLQAEpkrE;

    void ePbYeuCKb(int tMLUcoladidKFV, bool QgRbGQPsMLdmrZh, string QjZnvXDZeRxT, string pcIdOpCOSwUZH, double YsBFirULbfTHbFC);
    void wOxyKcZ(string lztKhhjPoEwyiOn, string OKBUNYU, double DJGoRAYLSJXr, double CThooiBrnUZa);
    void ObITkaHcAWwaf(int rHQaetuBiMCaHoUD, double KBaCuSWhNEJz);
private:
    bool cpMlmkTDe;
    double lerTU;

    void lCcmdPFUJSwyXZDZ(double HNcmIQzHgcsuHWqy, double IiAzsrOfo, int vLTbwWDfqM, string RwGQDmkKuZMI, bool yriMC);
    int KYvam(int hlcvYKJYOtwHxN, int WYmMROMVA, double KWppIAEqODvL, double aZLcw, bool JAmWpZuPnq);
    string VlCPGKwMBwkaqAZ(double DEkUbUvBr, int dVrszv, double guVrXQ);
    string mQEADzMPWmp();
    void DUmdRPBLEJ(bool hozXENyw, string OucYwVMCvQc, double CFtuNqjTyOAhdn, bool iARUDET);
    bool CbKYnRbHzVwBxIN(string UOfeoGRoV, string XxKoZPwIQT, double MKKWkqrQFfd);
    string PFHBiWSOfxqHdNs(bool BrsZPQmrdj);
    int edBwhjPYXyLtHpm(bool jHogGFUkw, string VZxQFxIW, int HcbjaMgpSFJxbSO, bool NEacq, string CsyxysVHIliW);
};

string ZqGkepTGrEQOXhy::lpvFqmYeeQDHBVF(int hBTENcSBGii, int uSYJRrWVgBXAj, double MGNcxNKnVgTU, string XQsGUFCgHaqC, bool egGieOSHAFOy)
{
    bool rdJHAS = true;
    double vlAreH = -164744.28662322692;
    double eBjdg = -574746.3346103204;
    bool MqarmK = true;
    int OYkZClxHk = 51635288;
    double ErIIjm = -473155.9138346544;
    double JeaVWIOJJeRmI = 533896.299486894;
    int kliEwHePj = 1139126349;
    int PhDfNHIvV = 1405587094;
    string GbjwLJ = string("MwfBysSCTCeccWBCEUfUufaWBtbOUVsausSnlNlUpCNyBGXdxDxkUMbvpPrZNaAWrqbrYmNkGJfcUxwPtAmCFGZhEWCqhFQLRfDFxhgHOVmkFSLeMEWEijRfKGUZoaKxyqnjroxWIpJqYgtRBLdTtsqcbtDpWEsXgMbCBEzzmIhGYuSpcSur");

    for (int KZSPbv = 1804668748; KZSPbv > 0; KZSPbv--) {
        continue;
    }

    return GbjwLJ;
}

int ZqGkepTGrEQOXhy::etqOJ(int YfqKRSo, string LPAGf, double valkfjHQIcYIkBa, bool wyDoh, int ZFNgAPCcFwnY)
{
    int raAEMnZkdYOLndK = -1387310697;
    int dGOnNeslb = 454020972;

    for (int EWQwtJdTtvwmgtvO = 1861963287; EWQwtJdTtvwmgtvO > 0; EWQwtJdTtvwmgtvO--) {
        ZFNgAPCcFwnY += raAEMnZkdYOLndK;
        LPAGf += LPAGf;
        ZFNgAPCcFwnY += ZFNgAPCcFwnY;
        raAEMnZkdYOLndK += YfqKRSo;
    }

    if (YfqKRSo < -1387310697) {
        for (int DJOYdFrr = 1661873113; DJOYdFrr > 0; DJOYdFrr--) {
            wyDoh = wyDoh;
            wyDoh = wyDoh;
        }
    }

    if (dGOnNeslb != 2036681880) {
        for (int bNeFflOizgwYHWo = 671939401; bNeFflOizgwYHWo > 0; bNeFflOizgwYHWo--) {
            raAEMnZkdYOLndK -= dGOnNeslb;
            YfqKRSo += dGOnNeslb;
        }
    }

    if (YfqKRSo <= 800953257) {
        for (int VnbuDJiLJLTTYbUt = 1822802231; VnbuDJiLJLTTYbUt > 0; VnbuDJiLJLTTYbUt--) {
            dGOnNeslb += dGOnNeslb;
            LPAGf += LPAGf;
            dGOnNeslb /= YfqKRSo;
            wyDoh = wyDoh;
        }
    }

    for (int SVnaqjCfWYgZB = 50791721; SVnaqjCfWYgZB > 0; SVnaqjCfWYgZB--) {
        dGOnNeslb += raAEMnZkdYOLndK;
    }

    return dGOnNeslb;
}

void ZqGkepTGrEQOXhy::ugmkqLJoUMZc(double sdnjDRWj, int yanVzIqqMoCMel, double GyFNbS, double dOocxxQmViDnYn, double bbAunSwjc)
{
    string tQQiKxpuddoZrmH = string("eQxzgeSrCEkMnCJToVjdoFMSLSgVgpeuLOmhNDVVsBsdgLRRJmzkBJjobkoaBUVmqfUCsxviZJXnvYQKvIzauPUngFbESxmgNcegZrsYWAfEpLmVNTcPgzGdVTuWcHhrLowtwokswbOfjnnZaQhjiGJJqhWoWYpujBXxOadMrtxplfegFKlbRHpq");
    double jKhYISjbhGottR = -907232.7235971981;
    int txNBSwwweeFDSyPc = -1881422850;
    string kzeVCEtfNXpamm = string("KwntpiwADNeRXOcRYIDBxnSsnKHLffJPORbwBNRzQaQhiFjehQWWNfJPhbNgTowyNNslgapKwYGVwDdcgHIyGbvRTsfCtYmcVdxHtCRvxtUrlWdhGmidYDCJKFRKOJxVtkHFYoDbWdGefsIZHgecpuFUwuYREjywRJZNmNoouSzKslggpH");
    bool neKBAPDoSA = false;

    for (int LshQqf = 1375556372; LshQqf > 0; LshQqf--) {
        jKhYISjbhGottR *= bbAunSwjc;
        yanVzIqqMoCMel -= txNBSwwweeFDSyPc;
        GyFNbS -= jKhYISjbhGottR;
        GyFNbS -= bbAunSwjc;
    }

    if (GyFNbS > 872510.8571303715) {
        for (int vHgUOXIBsFP = 1568215373; vHgUOXIBsFP > 0; vHgUOXIBsFP--) {
            bbAunSwjc = dOocxxQmViDnYn;
            sdnjDRWj = bbAunSwjc;
            GyFNbS = dOocxxQmViDnYn;
        }
    }

    for (int NmYvGmnSUMPQkMih = 1890967336; NmYvGmnSUMPQkMih > 0; NmYvGmnSUMPQkMih--) {
        bbAunSwjc *= bbAunSwjc;
        txNBSwwweeFDSyPc /= yanVzIqqMoCMel;
    }

    for (int xVzPKEheQmXWBjMM = 584362561; xVzPKEheQmXWBjMM > 0; xVzPKEheQmXWBjMM--) {
        GyFNbS = dOocxxQmViDnYn;
        tQQiKxpuddoZrmH += tQQiKxpuddoZrmH;
        sdnjDRWj += dOocxxQmViDnYn;
        sdnjDRWj /= jKhYISjbhGottR;
        sdnjDRWj /= bbAunSwjc;
        txNBSwwweeFDSyPc /= yanVzIqqMoCMel;
        GyFNbS -= bbAunSwjc;
    }
}

int ZqGkepTGrEQOXhy::JkYXoe(double wdNcnwXuQyTTLp, bool nYoca, string ywQtMQkfzzAF)
{
    int BvKVAO = 666736942;
    string igFNvtT = string("AWyRMXSkpeJLHQPtIgHISmlNsnBkNeUfvazrbzVYVkZqxNoBzZCHhMlPqXfcwRRkOiMSDoBdrTmvtjjcEuYRgJYIUYyIJDaTWcpToBoIFuAWrOCshVjNhoUiDdbdlLzWSZcOdmifgPAAIXuRyFfqSGIhwvoBsRZFJeFcWyx");
    string UltnFOFFIE = string("QiCsJsFEUlyQHbaTKMbjoxnPLMKgxQevUnQdAQBcvfrLjqpgxuuyjJcBenBMUuBAbXKJBuAADusFfKCLKvSUaElbHlwKnQtgSCYNRAOIzZueadUHsMELIpBZLqltoXYsdcRXYdNlLlAzQvjCpbqMkOGLGTtCFUcoFbUzryLiOCRvJItxfxojvBMcYjjoMNSYgVWYjDZnGYortDutgootafqbxrUWaJKc");

    for (int xLXEgTKnPaeW = 1267786724; xLXEgTKnPaeW > 0; xLXEgTKnPaeW--) {
        continue;
    }

    for (int AUIVhQgAPCJf = 1701703313; AUIVhQgAPCJf > 0; AUIVhQgAPCJf--) {
        ywQtMQkfzzAF = ywQtMQkfzzAF;
    }

    for (int YpdnWDRSgx = 346032996; YpdnWDRSgx > 0; YpdnWDRSgx--) {
        igFNvtT = igFNvtT;
        nYoca = ! nYoca;
        igFNvtT = igFNvtT;
        BvKVAO /= BvKVAO;
    }

    return BvKVAO;
}

string ZqGkepTGrEQOXhy::XMUYHaKzDh(double xgRjachmCBYJefG)
{
    int isCWbbatHLoWU = 743377348;
    double LEqBxZBdaQFx = -11117.358511461684;
    bool IuxemQHAZX = false;
    double utbHBwRU = 1026069.0325169296;
    bool AetxR = true;
    int YoMmXYbqVF = 598689164;

    if (utbHBwRU != -745620.892999304) {
        for (int wMAdrIx = 1238026752; wMAdrIx > 0; wMAdrIx--) {
            YoMmXYbqVF *= isCWbbatHLoWU;
            IuxemQHAZX = AetxR;
        }
    }

    for (int GlroMkE = 479745916; GlroMkE > 0; GlroMkE--) {
        xgRjachmCBYJefG = utbHBwRU;
        LEqBxZBdaQFx *= xgRjachmCBYJefG;
        LEqBxZBdaQFx /= xgRjachmCBYJefG;
        xgRjachmCBYJefG *= xgRjachmCBYJefG;
    }

    for (int eycxRiS = 1624298372; eycxRiS > 0; eycxRiS--) {
        utbHBwRU += LEqBxZBdaQFx;
        utbHBwRU *= xgRjachmCBYJefG;
        xgRjachmCBYJefG /= LEqBxZBdaQFx;
    }

    if (xgRjachmCBYJefG > 1026069.0325169296) {
        for (int lbJSjCVQu = 1710594123; lbJSjCVQu > 0; lbJSjCVQu--) {
            continue;
        }
    }

    return string("mIPqnLGykqEmivpsmjPyUkTdtADDYowZkQegNpyyEMwDcwzfiCPxexcMSCDfqygFbXtmcmUAUcBdmRvQfklyYIEeIeTSrMRZBRTwmAqKYjKJvCJYTmqqWydoEQvqzvdxUT");
}

int ZqGkepTGrEQOXhy::seBTslQsCnzC(int nqOLPxCMAgqTfMsv, double AtvqzAn, string JiTnvNDzBHysGgYO, bool muxlNzba)
{
    double EgucIhkUUKFgh = 565368.0371596842;
    string KWsOLRSqGJuW = string("XYxXIEqbDdRalXAoMcmmSXnQXocBuaTDYJbuYDqGTgheKkFBrJuLOVjFMPlnUblnXRTOOuWgzgbPQyMLhMLTzpxVdGkDbsthTJAEqPpWboEOmeTDZxuJYoHnkwxBcGQiOXmHFGJAjDfXQYtIthvRPWckrzSnYDayjTgXlyuFglEkrfsvacSQyaKNnFmM");
    double YImxumXcJ = -82703.47065333829;
    string CrihpzImu = string("UtWTjWmstxlSbIuYcnFNKEkWGbSyNrFoBNgzlXbJeuhMtBeJyYODurhoplWcUniDIcAFIwcgVCSTnxJNvhPWClCKTMpeCYjcPbXTZEMHWBAlfdKOLdARyphWZyJftEszkJQDaFNwDpLcBDCyoIZrOyheTToGyaEWrNSpuGbrSKSbxzDkruFmUQCedJfQGBvhSyYDgJDTkodSLoOjGuZggpASvHGGwdhbDzMQQEGg");
    double OVQpOy = 1015025.8581726092;
    double mwAkduMVE = 827237.323921918;
    int NQomvMwQlPdA = 1791930499;
    bool BTkADVmrTH = false;
    double RTJVjc = 253860.1768438274;
    int pYARXfcZpUZ = 1102881696;

    for (int bZEMT = 2089898624; bZEMT > 0; bZEMT--) {
        EgucIhkUUKFgh = YImxumXcJ;
    }

    if (RTJVjc <= -82703.47065333829) {
        for (int TVJCUWafZSBrNDi = 882784032; TVJCUWafZSBrNDi > 0; TVJCUWafZSBrNDi--) {
            YImxumXcJ *= YImxumXcJ;
            EgucIhkUUKFgh -= YImxumXcJ;
            NQomvMwQlPdA /= pYARXfcZpUZ;
        }
    }

    if (muxlNzba == true) {
        for (int IgITklqGkVME = 1902007369; IgITklqGkVME > 0; IgITklqGkVME--) {
            continue;
        }
    }

    if (muxlNzba == true) {
        for (int udCvhpOvhvfwnwB = 1212658941; udCvhpOvhvfwnwB > 0; udCvhpOvhvfwnwB--) {
            AtvqzAn += YImxumXcJ;
            OVQpOy = EgucIhkUUKFgh;
            RTJVjc = RTJVjc;
        }
    }

    for (int xOCiUx = 1430108611; xOCiUx > 0; xOCiUx--) {
        muxlNzba = ! muxlNzba;
    }

    for (int eVQWfurmjhJh = 2079331368; eVQWfurmjhJh > 0; eVQWfurmjhJh--) {
        continue;
    }

    for (int zhIxjIwKE = 270517567; zhIxjIwKE > 0; zhIxjIwKE--) {
        nqOLPxCMAgqTfMsv *= pYARXfcZpUZ;
        EgucIhkUUKFgh = RTJVjc;
        muxlNzba = ! muxlNzba;
    }

    return pYARXfcZpUZ;
}

string ZqGkepTGrEQOXhy::AeSXXgQFpzUt()
{
    bool tJwvnTLXzPT = false;
    int WNuTHVo = 998903240;
    bool riOzal = false;
    int bkxsk = -1138930189;
    string WJykLDdmXAdNuhI = string("VlbbMzGSthjCSbiVbWBPfKeibHSYYIVtYJjjiBwsfQpSfaOoSHchjGhspsAiNIunypNSnhqhKAQEqhaFuiyNPDZsaVCaLPMwuSrJtlVnMnfqTk");
    string OxWlFfkEh = string("Wjsn");
    int KhFlWC = 1900196083;
    string qfooGWVKS = string("FlAuvjobzFbASWpOKjOKfMIQTcYSrWniKTHiCOaAcNTfLaNQDrtnNqYvSycrFsbWkZatHwnDuvfQVtrcukvfFjobgJvPcQqbSDalrpYQV");

    for (int CtfTKaQCQXzctV = 848501114; CtfTKaQCQXzctV > 0; CtfTKaQCQXzctV--) {
        WJykLDdmXAdNuhI = qfooGWVKS;
        WNuTHVo *= bkxsk;
        riOzal = tJwvnTLXzPT;
    }

    if (tJwvnTLXzPT == false) {
        for (int KNSFlNJclTpOpoW = 689199516; KNSFlNJclTpOpoW > 0; KNSFlNJclTpOpoW--) {
            WNuTHVo = bkxsk;
            WJykLDdmXAdNuhI = qfooGWVKS;
            WNuTHVo /= bkxsk;
            riOzal = ! riOzal;
            qfooGWVKS = WJykLDdmXAdNuhI;
        }
    }

    if (bkxsk != 1900196083) {
        for (int WZOzysrnWC = 1574989945; WZOzysrnWC > 0; WZOzysrnWC--) {
            qfooGWVKS += WJykLDdmXAdNuhI;
        }
    }

    return qfooGWVKS;
}

void ZqGkepTGrEQOXhy::ePbYeuCKb(int tMLUcoladidKFV, bool QgRbGQPsMLdmrZh, string QjZnvXDZeRxT, string pcIdOpCOSwUZH, double YsBFirULbfTHbFC)
{
    bool hzQSNR = false;
    bool THoMZS = true;
    int aGszENqjoYmyXrvo = -1723289335;
    bool ewiroLmJRy = false;
    int mFiOKMLJIb = 1449519088;
    string FVhDrJDUFLZPVX = string("TrUQaPXtbPrfmzXOugnCJmcMZBcBbPWoHNUZCvsdwxKHEj");
    int nBmibAIdYBpTu = 1296682257;
    double dKuVUcShBruQNcg = 929870.1473569177;
    string mSMCvzms = string("kOHvIkjHSRWuiQqJmRkqyHbKQIISIFHPyqHeYzrYtDFEFEZoiwnQboaKihhFvfCEzJifyqXbOYFMdwnMVEGEDFmZwnIrNpEZZgLsGBACHbaLUDVZRLhVfGvGdeKkEVthVrpGPlTdqTeqECLBUVuUnYtmepQureuWSdEGTZbJCVMdLrSqTdnuUPVIWsmKlUdtAeKzNHbmurbSZzZMbLRY");
    bool eTMWBIduG = true;

    for (int QcFdFuIws = 1205604645; QcFdFuIws > 0; QcFdFuIws--) {
        continue;
    }

    for (int VKcdJPQp = 40252309; VKcdJPQp > 0; VKcdJPQp--) {
        mSMCvzms = pcIdOpCOSwUZH;
    }

    if (dKuVUcShBruQNcg == 711204.5405163297) {
        for (int nBlkzi = 96857089; nBlkzi > 0; nBlkzi--) {
            continue;
        }
    }

    for (int pfUqIxzzuxrMPY = 1269865869; pfUqIxzzuxrMPY > 0; pfUqIxzzuxrMPY--) {
        aGszENqjoYmyXrvo *= mFiOKMLJIb;
    }

    for (int gfzNIlUsgxCEfA = 600534550; gfzNIlUsgxCEfA > 0; gfzNIlUsgxCEfA--) {
        ewiroLmJRy = ewiroLmJRy;
        QjZnvXDZeRxT += FVhDrJDUFLZPVX;
    }

    if (nBmibAIdYBpTu >= 1043050828) {
        for (int lzGKe = 1492098221; lzGKe > 0; lzGKe--) {
            FVhDrJDUFLZPVX += FVhDrJDUFLZPVX;
            mSMCvzms += FVhDrJDUFLZPVX;
        }
    }

    for (int hrYhmHbO = 1912842192; hrYhmHbO > 0; hrYhmHbO--) {
        mFiOKMLJIb *= tMLUcoladidKFV;
        ewiroLmJRy = ewiroLmJRy;
    }
}

void ZqGkepTGrEQOXhy::wOxyKcZ(string lztKhhjPoEwyiOn, string OKBUNYU, double DJGoRAYLSJXr, double CThooiBrnUZa)
{
    bool USnROvxCgYWItXQG = true;
    string VWwUbvVfpnFrlMYk = string("OyVFdAbAUoOBvhuexsZYTqjWTOtxOMlEnNchSUiRQsEKNGvjRRZbKtkOMDWXYwAmsNRqfCbCUNoc");

    if (OKBUNYU == string("OyVFdAbAUoOBvhuexsZYTqjWTOtxOMlEnNchSUiRQsEKNGvjRRZbKtkOMDWXYwAmsNRqfCbCUNoc")) {
        for (int ujeCnvsBOINSk = 309114293; ujeCnvsBOINSk > 0; ujeCnvsBOINSk--) {
            VWwUbvVfpnFrlMYk += VWwUbvVfpnFrlMYk;
            lztKhhjPoEwyiOn = lztKhhjPoEwyiOn;
            CThooiBrnUZa -= CThooiBrnUZa;
        }
    }
}

void ZqGkepTGrEQOXhy::ObITkaHcAWwaf(int rHQaetuBiMCaHoUD, double KBaCuSWhNEJz)
{
    string gmGOTT = string("MmzRjAnPxfipxRqyfyxOgYNxkmyViHegwrsjwpqyzuvPWXiEaMBoFYCPibvlBpsHVpWefspPVdNn");
    string UcoEflv = string("vjVOJUGDuSMpojfmllweWexSxgbPsYrHTtlkQJtWpNZcfHYAbvxHpBTrlQaywTKAzMWSqxWQdDaIUyoUQFujbNkeCYCsOHauoKjdzzabzrptOJAmYrz");
    int AwgwMRsmFsqn = 184740571;
    bool IkegjFXWQUZ = true;
    int QjzNsXqyEmQZOAyk = 2101289832;
    bool FEPJEjawLZTDdPZp = true;
    bool FcnylTryA = false;
    bool AQkdNYBpljCY = false;
    int zdEKeq = 523118694;
    bool YpOerViZjyJWkM = true;

    for (int dcxelYjQk = 1969797282; dcxelYjQk > 0; dcxelYjQk--) {
        QjzNsXqyEmQZOAyk -= AwgwMRsmFsqn;
        FEPJEjawLZTDdPZp = ! FcnylTryA;
    }

    if (AwgwMRsmFsqn > 184740571) {
        for (int oJhHGhjitdGztp = 85533719; oJhHGhjitdGztp > 0; oJhHGhjitdGztp--) {
            continue;
        }
    }

    for (int GihDdDB = 1915158018; GihDdDB > 0; GihDdDB--) {
        zdEKeq += AwgwMRsmFsqn;
        KBaCuSWhNEJz = KBaCuSWhNEJz;
        FEPJEjawLZTDdPZp = AQkdNYBpljCY;
    }
}

void ZqGkepTGrEQOXhy::lCcmdPFUJSwyXZDZ(double HNcmIQzHgcsuHWqy, double IiAzsrOfo, int vLTbwWDfqM, string RwGQDmkKuZMI, bool yriMC)
{
    string LDyHtoJQ = string("vhXrIyvdXxSyMGeGEZTvPrOQim");
    int SbBsRWEWQ = 297155186;
    string dBSuX = string("AXzEFMTKHKYqKGQaMRxATFQfXYAzBPhVZbxSyaPJgSdUWykpouRYztgbSDpLHGGLGmfcTWiydjoyClhogqycHUCyowvpwknogicgGouFSpoOycbst");

    for (int qPKebvubeKaQw = 49990147; qPKebvubeKaQw > 0; qPKebvubeKaQw--) {
        LDyHtoJQ += LDyHtoJQ;
        IiAzsrOfo /= IiAzsrOfo;
    }

    for (int JzOHQChMgYyzV = 858849776; JzOHQChMgYyzV > 0; JzOHQChMgYyzV--) {
        LDyHtoJQ += dBSuX;
        LDyHtoJQ += dBSuX;
    }

    if (dBSuX == string("ZsFOtSffOdQClvlKwWrDkRhZGmJqYjczhwJmYfPlxzuLcYnsaZGlXVtgzAlYokhmAQFPTLtHuatxiNnvielraFtSwO")) {
        for (int sFCFdlrlwtUJd = 1785068193; sFCFdlrlwtUJd > 0; sFCFdlrlwtUJd--) {
            dBSuX += LDyHtoJQ;
            yriMC = ! yriMC;
        }
    }
}

int ZqGkepTGrEQOXhy::KYvam(int hlcvYKJYOtwHxN, int WYmMROMVA, double KWppIAEqODvL, double aZLcw, bool JAmWpZuPnq)
{
    bool bmTmuAKPoCCdBN = false;
    double NalIbXocwyXWqwmq = -168005.62529872154;
    int BUMVMaY = -1119206186;
    bool pbYZCGbZMyDsXj = false;
    int EpEOIVHdOPeVTv = 966992436;
    int htFTbTMssrsLlHkt = 117697443;
    double feOnriFioaDhRD = -994804.9765700535;
    string bcpaEBsA = string("lFtuLbFJuMHKlJNczsDnLNYaciDWbwIgIMwrjdNWHNMXgfbGXyXEnpkZFusyTbMXkAwxRLpvRiKNwvYgJpIkagqlJjakMWlAuYSyfeSGwqIsglPLjvElOqEbyQXaJizTKcivMtaKLgbdafdXZvQgTUzrqIUTEoKQzCxtdRxteKoXeaAIZIEhGPZUofMoKuoIIOBwlEEfNzudeBKQzzldVpMtPujxlssaTB");

    for (int NSMYwUvmHPdHiHed = 1599494345; NSMYwUvmHPdHiHed > 0; NSMYwUvmHPdHiHed--) {
        hlcvYKJYOtwHxN += BUMVMaY;
    }

    for (int pJQllTLus = 2066594459; pJQllTLus > 0; pJQllTLus--) {
        NalIbXocwyXWqwmq = KWppIAEqODvL;
    }

    for (int XOVSzUlMGaaRcRf = 388574305; XOVSzUlMGaaRcRf > 0; XOVSzUlMGaaRcRf--) {
        JAmWpZuPnq = JAmWpZuPnq;
    }

    return htFTbTMssrsLlHkt;
}

string ZqGkepTGrEQOXhy::VlCPGKwMBwkaqAZ(double DEkUbUvBr, int dVrszv, double guVrXQ)
{
    double ApJyOE = -566828.0574047674;
    double UCipetdkKfHWJz = 31305.335694074525;
    double ixCdmrQ = 3251.971501692778;
    string crDSANqeIkJhSwuw = string("dJuBGYOLEINKkWQZhpNVSWBdAPrUtZTqrrOUJtNAEROWjCCXdaZjzyvLiQxToNelXyERErkkwrBuedQjIBsiwoOcQYfMLxUNjYLvrWRuipAPCbaojEFzYFbHBksxyRCgVjsWAYRCFUFMClnthhaOoIMTUSLmAZWvAmPlSGBaFrONYzOMkvBfxvLbZpxYvuSGKryGVNpTqSWgwQbilVmnpYtsvKodyuGDDjqHWA");
    bool mPKNUNrWOkdY = false;
    bool IWpwKNNWJMIlSG = true;
    string BThaAihThkMgGA = string("LelaMgJpXSLJMALikWHTuxqHdQwROwWvAcoFfjWtQvGeQZcffZQEHSOswp");
    bool rzihMadgQY = true;
    double HcGTzPkLj = -412578.41989735747;
    int gNWfFYoa = -1556146684;

    if (ApJyOE == 3251.971501692778) {
        for (int pyOqVpGS = 337224337; pyOqVpGS > 0; pyOqVpGS--) {
            guVrXQ += HcGTzPkLj;
        }
    }

    return BThaAihThkMgGA;
}

string ZqGkepTGrEQOXhy::mQEADzMPWmp()
{
    bool gYWuektSDyPh = true;
    string OpRNeqT = string("ubCHKwiSWSdZgKOHZ");
    int HmhRDfNtBsaOY = 890180713;
    int oUlKuRfIwZStghZ = 1494647048;
    int QlWyhwUbNI = -42845749;
    int OKJSe = 1956456590;

    for (int ZtMVlzPRHXrZ = 695038579; ZtMVlzPRHXrZ > 0; ZtMVlzPRHXrZ--) {
        oUlKuRfIwZStghZ = HmhRDfNtBsaOY;
        gYWuektSDyPh = gYWuektSDyPh;
        HmhRDfNtBsaOY *= OKJSe;
        QlWyhwUbNI += HmhRDfNtBsaOY;
    }

    for (int mcrwNVfNTmGyaz = 1979193496; mcrwNVfNTmGyaz > 0; mcrwNVfNTmGyaz--) {
        oUlKuRfIwZStghZ *= HmhRDfNtBsaOY;
        QlWyhwUbNI *= OKJSe;
        oUlKuRfIwZStghZ *= oUlKuRfIwZStghZ;
        HmhRDfNtBsaOY -= oUlKuRfIwZStghZ;
        oUlKuRfIwZStghZ /= QlWyhwUbNI;
    }

    return OpRNeqT;
}

void ZqGkepTGrEQOXhy::DUmdRPBLEJ(bool hozXENyw, string OucYwVMCvQc, double CFtuNqjTyOAhdn, bool iARUDET)
{
    int FuEgRNMYqcSep = -627535808;
    bool WLZTwk = false;
    bool WtdOJFWEMisspftC = true;
    double yVRnfqpxgZfQX = -236688.67115849172;
    int hXExYDbkYneu = -1823469496;

    for (int eezIdHs = 374854819; eezIdHs > 0; eezIdHs--) {
        hozXENyw = ! WLZTwk;
    }

    for (int SnctxjMsWSWwlJZ = 15986601; SnctxjMsWSWwlJZ > 0; SnctxjMsWSWwlJZ--) {
        CFtuNqjTyOAhdn *= CFtuNqjTyOAhdn;
        hozXENyw = hozXENyw;
        hozXENyw = WLZTwk;
    }

    for (int THwEwleUmbIxCEd = 1879759913; THwEwleUmbIxCEd > 0; THwEwleUmbIxCEd--) {
        WLZTwk = ! WLZTwk;
    }

    for (int ywIBMIxAtJCgR = 193590511; ywIBMIxAtJCgR > 0; ywIBMIxAtJCgR--) {
        WtdOJFWEMisspftC = WtdOJFWEMisspftC;
        WtdOJFWEMisspftC = WtdOJFWEMisspftC;
        WLZTwk = WLZTwk;
    }
}

bool ZqGkepTGrEQOXhy::CbKYnRbHzVwBxIN(string UOfeoGRoV, string XxKoZPwIQT, double MKKWkqrQFfd)
{
    int TWjctTEwNH = -995913098;
    int eGBkY = 2028963025;
    int nNTzcHKzcJNsYokU = -962063250;
    bool OWlUdvVJNVlMvcyx = true;
    int TzvALlLwLgGGM = 1194731383;

    for (int btFxVQrnQxiQ = 1641367732; btFxVQrnQxiQ > 0; btFxVQrnQxiQ--) {
        eGBkY -= TWjctTEwNH;
        OWlUdvVJNVlMvcyx = ! OWlUdvVJNVlMvcyx;
    }

    if (TWjctTEwNH < -995913098) {
        for (int RaHiULOj = 742465568; RaHiULOj > 0; RaHiULOj--) {
            XxKoZPwIQT += UOfeoGRoV;
        }
    }

    for (int qvmmNvI = 23855495; qvmmNvI > 0; qvmmNvI--) {
        TWjctTEwNH += eGBkY;
        UOfeoGRoV = XxKoZPwIQT;
    }

    return OWlUdvVJNVlMvcyx;
}

string ZqGkepTGrEQOXhy::PFHBiWSOfxqHdNs(bool BrsZPQmrdj)
{
    bool NSNufuwdSDKjh = true;
    int VIhsRWJJJoGQGw = 2048021667;
    string LAJWVT = string("bQJeDCubxjeRqtDlPWQJsvigjwHxgIxIiYtYJFsGwCjnXlspdrRhJlvLWADkhlzOkoaIhBjXZZFXtYQIJHjxwgCWqinlGxrwTUvcdULmxHfmREMTsEXsYVFXOQMpRYTrWlKlnrZMDoNAFDXxBhswnuKQNywJEzJ");
    double xOyNCFyRYf = 299501.13794164825;
    double GAadZyIRFslLODfk = 770649.7102457244;
    int kXeJhkZiZqmv = 1152248110;
    int cqfeTmNiVNF = 2055747856;
    bool ceGDx = true;
    string oQlvDrAj = string("OmRdAUPkbqfgsSuSctacVPXwXDqmGnEBjeDDjwAuRQCaxOqnYnGbraWpXUMpdZtBBTxuZRtySBJfCASyzWLEseyXPsFQQyfruqEgIwmxHkbvAuCOoqAdLQFhhONQJuPkbAvKgjQRRblvfflKMccQLRFWJgcHHwHbXwXcylhMhRmvwRYuuqinxyPXSVMOUMSAaZOuCOqYPFoHpLdHAxslthbpiFkWikDumvauPQsChaPKGAADWVQ");

    for (int LBTsuBStCYkAVdd = 684609592; LBTsuBStCYkAVdd > 0; LBTsuBStCYkAVdd--) {
        ceGDx = ! NSNufuwdSDKjh;
    }

    return oQlvDrAj;
}

int ZqGkepTGrEQOXhy::edBwhjPYXyLtHpm(bool jHogGFUkw, string VZxQFxIW, int HcbjaMgpSFJxbSO, bool NEacq, string CsyxysVHIliW)
{
    double XJONjQIrE = 930519.6237527281;
    bool ftYVa = false;
    bool vGYLfUhFquQsu = false;
    int qflkSlrRgB = -2093505674;
    double xVbVIFhXHKQbiT = -795994.8714188816;
    double QoYwEnPNO = 35098.481071609545;
    int OQCOJ = 1104614004;
    int XTGWnuQOBV = -1680755740;
    int qTKUYyXWU = -1415075309;
    int ntXdohMCSvTmKfiR = -1254831858;

    for (int dCAEjag = 1407032884; dCAEjag > 0; dCAEjag--) {
        continue;
    }

    return ntXdohMCSvTmKfiR;
}

ZqGkepTGrEQOXhy::ZqGkepTGrEQOXhy()
{
    this->lpvFqmYeeQDHBVF(1071010206, 959147471, -836069.5822123667, string("OLWPoNMkkvOaNeunILPksRAHSGdlsRoyjsCDtJVyfoceiXJCBfIgfLqQhSBhTZTUsmFAxyvGAhsTxVXJV"), false);
    this->etqOJ(800953257, string("JAIVIwiRgwvuupIAeCyWgezMlOmrkQBtQuQ"), -35405.58855453554, false, 2036681880);
    this->ugmkqLJoUMZc(872510.8571303715, -1611624062, 384937.3649552678, -489118.61007349106, 857113.5836910597);
    this->JkYXoe(30273.853174601703, true, string("nveWaSlrrwnhdK"));
    this->XMUYHaKzDh(-745620.892999304);
    this->seBTslQsCnzC(-553551870, 426953.25641084724, string("UGJAUCwGixDJkdLgyeCFASoSOZhWLDCallkxgyiFVtpYzwRfgeeGOrIJeYQhukhoavxZBlGMOIeasWHDKTOsxylCWfuskdkgOTvGbKhOFahxzPLIQlbInsKyqdigVMMpfmEBXZnBBirxIiSLHnEcRsOVhaodG"), true);
    this->AeSXXgQFpzUt();
    this->ePbYeuCKb(1043050828, true, string("QwDAbcZYHKFxHJKvILLrwnmLpMRtxNMeASNKAKaZJWVpxrnUIfYFFJJAdnNsZOIfXULTIxeoTJWgnENPvwKUcNwMIhPqEGKNPLCzCvzMVaCTvMtuXZpVQoMCHQpyPzoeVqOxViAQYGPMWFpHpIzGNSkMPJjyMIiwZMnDxdJMhWyhvpuAkUYlyPkvbySXvfmYFSipizMEpTTSBEpHmoYghXiKgECrXfrogHhdmYfkfpzoxSWHB"), string("uaYDXDpKEiMCOCFsINStOkVFfBjuVpRuYBEalSErtrZSQZZQdCRMMmLPwlvJZCubPGuNhbtQRAPCdWSQXRinDLPXwxpRTLwVcNTaUUvJCDrylHPHJLJTtDNdIWxNqhlFDLbfNQSNjcCXnqSJSeLBovOuLJNyapemdyrwgYtHEhjSbAwzkCUSMOLupbprphmvnawCuzdNmuoy"), 711204.5405163297);
    this->wOxyKcZ(string("DhzcXBkOsvXDlcLnpJNzZTaSNrmjFDVNpBDnnFxoIIrvDnlkpUuXVUFIHNOlzJbsJBfDfylmLSjhbsPwlFWeJYudbivrWxZfgnpNeAitfVJuuhobhUUMiVFutXgHOnEwNLhSNUZJijbZqawZGGXabuCZzXpktxNfPPHGRfYMoDiLIE"), string("lKWduzhUCNXlAdpQshKBDNyRukUgoZPWNWWxinmWPhDWqVTLAGnxedik"), -675703.2823414163, 497478.3440072);
    this->ObITkaHcAWwaf(997242783, -217741.34107653197);
    this->lCcmdPFUJSwyXZDZ(-423159.05110161635, -578135.2932050376, -1642330392, string("ZsFOtSffOdQClvlKwWrDkRhZGmJqYjczhwJmYfPlxzuLcYnsaZGlXVtgzAlYokhmAQFPTLtHuatxiNnvielraFtSwO"), true);
    this->KYvam(1678984952, -1624946016, -101339.52500801484, -631217.1540206877, true);
    this->VlCPGKwMBwkaqAZ(-903351.9239873306, 1655962468, 519119.0698283704);
    this->mQEADzMPWmp();
    this->DUmdRPBLEJ(true, string("wCsqILssKjEadLfHPXOgRcESkXtYwMclhBiuXRfwrxrDwXwvWCzceMeXkUSsdewfcvHIyPOPjprAZffUBUaEuipBLOofzIXKSZjzFxWbDfPvVdJfoEAlMhAxrqkACCvJcCWuZfFFyMZOvJuSggJbLwSelzXFowjcy"), 55767.47144628941, false);
    this->CbKYnRbHzVwBxIN(string("eILDsBPnWeherusZnkpiUSHBZqmDNDrywMfkYktRdJeSopQEOqKInyqEKmNSOYHhMNScpnLPzvk"), string("DHDmiEUsPENGEbBPVbFVOqyBTeyPDGfZRkSKbBHhZVuKDZPnafUSKFRulRGcalJbwnnuWLpphodACNpAAWzfxZkEtStBoCNrnwNQBCnymjdEkCGPEtbUPXIlVAItCEWoiwHqnWQXgrAZfnGpnInvvUsbRtINrxepivSlJuKHUqHIHLWUtyCFsqkUABVEOxaLGRNecFoye"), 548330.6425741471);
    this->PFHBiWSOfxqHdNs(true);
    this->edBwhjPYXyLtHpm(false, string("MzHGMpMRvcKZLKkqivbHWmHAMcBJVCNGOOEJSPZZvvEPEUdozwnhgmCAfaJpSdMPhrjjCOp"), -130833006, true, string("COoyzIEuUjovSqevKLNVpMJlIGilmGjOjQUqviPGXUECniwFLwXsLrZziGepaNPPJhBJDLPdPfIvegYpCGeidFrgcajzCjdZeCtMVudcRGbQlhnvbnOViLKrUDYauhbUQbZPvaARizztEbMqSpcFhmu"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SOhJOm
{
public:
    int cnImdLz;
    bool iauUZPIKuFQEIA;

    SOhJOm();
    string DemixxqGMypy(string zCKTxFUunnOt, int fHaqS);
    string PfheK(double sSAGqolkTmvfIe, double TnTJlELOtb, bool yrzyi, bool EUjLp);
    int DDltW(string MhbjCueatgwyRT, string UkMZXhEEA, bool FPeac);
    void bCJIrTAuncTwoG(string VVFgUabXDpwsQE);
    bool lYEcPS();
    bool UATkpwbpvNdRSV(bool GgWjupaVNfQiU, double ZWhvzQH, bool ogLXnSWug, string AIRoIMFNLP, double SYKvlYmomsCiadli);
    double rYnbV();
    double eTpfcrgfYgRvZfz(string MRygmtwTRzxX, bool DohaB, bool EqkoQqdwjQeDul);
protected:
    bool dScyHsDG;
    bool ICrYTaOYnoGDcVEI;
    bool ArGZDWbLXN;

    bool HNxlECKUxVrbSnat(int HqqxS);
    int jFcglIgXUtz(double napnE, string gLimU, string XcPaYSA, double ezJZNDzN, string mLXrp);
    int jDuvBKG(int gDNEVMfVHoDekc, string cnxGVJvbkT, string NpAHQqmrUx);
    double QEGDcpcEjVEdaov(bool AnGLAdgZt, bool lWoEMPrND, string WJFdGjal, double uoinQXtZ);
    double RxBlkTvyqJNLQgk(int XwPqyApEjBWuR, bool xkBWFRcPUC, double pgaVeXaXJv, bool ueqwNTOfv, int DqVjTpbO);
    int bRYaFzJ();
    int ileUpFdCiHZ(double evxSeSRsl);
private:
    bool sfLXLE;
    double IJUqhS;
    int dvhzFAVbVoaNPL;
    double ccUAIYSPo;
    int JWzVm;

    string hjfTAKBbfIwHW(string GbnNLPQQv, string qEbZlZjYhsxswF);
    int iLWFsdAgXDmwy(int GVfvfUPrTjCnliN, bool qfyVRQH);
};

string SOhJOm::DemixxqGMypy(string zCKTxFUunnOt, int fHaqS)
{
    bool GzMDOFPIDwGfgCHk = true;
    string TOCHNVaVsZ = string("QfyLmKHXdOCQgSzCWOPcilRBrNrBdnLhQjSx");
    bool kVGdyNG = true;
    int YLCxXThaeth = -542553393;
    bool FIRPbgFYQnjqow = false;
    string lvWtjEaAnCztz = string("wLpxwKEYWLXOEtQJkJWhQuudnokTZJrBjznlVezqWvnCOqIANuxFZAjScCJqIgpaTFSamRGnlmWGZUqUAAdwFAjDSDuXtrJGImircsGGsSavSkpOsuClJTtngdQstNYvEfSJDbACPsUKYDIXDRhOEMFXjWlXiTDrcMwrRI");

    if (FIRPbgFYQnjqow == true) {
        for (int eXwTquZd = 1229914441; eXwTquZd > 0; eXwTquZd--) {
            continue;
        }
    }

    if (FIRPbgFYQnjqow == true) {
        for (int LzpMGJj = 1040829675; LzpMGJj > 0; LzpMGJj--) {
            kVGdyNG = FIRPbgFYQnjqow;
            YLCxXThaeth = fHaqS;
        }
    }

    return lvWtjEaAnCztz;
}

string SOhJOm::PfheK(double sSAGqolkTmvfIe, double TnTJlELOtb, bool yrzyi, bool EUjLp)
{
    int eFTiEyR = 1261193965;
    bool RiEIaziPX = true;
    bool xsycuxYxqL = false;
    string cwhZqYNTcjHXVXPy = string("AWpjfLlxFujFuTzNbUgkFqjekmUx");
    bool KKPeAoQBsEQf = false;
    string jwlqaNgwbz = string("mxPZmMxbFOcndslxZZejuROHRSXehSnTTUYihKcjxiAtvIkddRgKAhybkesTrzKZMhlnSYBkeWSoDvJvqDKrODyFZkd");

    for (int xpVkuqIGSoDY = 74251212; xpVkuqIGSoDY > 0; xpVkuqIGSoDY--) {
        xsycuxYxqL = xsycuxYxqL;
    }

    if (EUjLp != true) {
        for (int AiMwZrhfmo = 1620697674; AiMwZrhfmo > 0; AiMwZrhfmo--) {
            continue;
        }
    }

    return jwlqaNgwbz;
}

int SOhJOm::DDltW(string MhbjCueatgwyRT, string UkMZXhEEA, bool FPeac)
{
    bool MnkyzPyFEzohvQb = false;
    int WOICgRLJG = 1312254542;
    bool dJHxj = false;
    int zLnCdSCHKYtd = 207264277;
    string mNnEHgtjS = string("mdLYEKTWwcFEtdFPPdHvYfSTBnZoYyNWiGORNudVyxzjmiHWJjoXsQBBgvzIyLVHpEivmDxySppskMJcxcUnuULzqWjJbBGkbunTTjysJaEvEZHwnIPNTxzprcaWwMkURlHlFeCIFlRKbKCJUfUdySccyZZdIenBtJNVlMXxzpfSygKTdzgNShQgiNXN");
    double TqbOcvmzwW = -952901.3768268999;
    double yEyBpVspxguKb = -619770.7965759599;
    string RvCNhgPkrXwBCsM = string("MxbWGzjdOFTPHfKMtjvbJsOBADmCOzYUKoHRIlsUtzgcGTIpcOyNMfjadMDfaEeqoKZxwlDLzVKSzhCVgFSHvcbAVNFNiiVmXRTTSJTQVaeDDVvNw");

    for (int HZwftY = 428635730; HZwftY > 0; HZwftY--) {
        TqbOcvmzwW *= TqbOcvmzwW;
        yEyBpVspxguKb /= yEyBpVspxguKb;
    }

    for (int ykyIouJIcwhhQ = 781119406; ykyIouJIcwhhQ > 0; ykyIouJIcwhhQ--) {
        yEyBpVspxguKb /= TqbOcvmzwW;
        dJHxj = FPeac;
    }

    return zLnCdSCHKYtd;
}

void SOhJOm::bCJIrTAuncTwoG(string VVFgUabXDpwsQE)
{
    double cTzNshzF = 386469.0920801705;
    bool xXrZnCCs = false;
    int wLiCzVQV = 1614956245;
    string MKlWke = string("fPdqXzoqBxYTelcLvumBpuIOqOGHHugGTwXYAJdThtOyiktAIARuUssebKJaZvBzUMQTqAvlZJxOOXnlnaURnNVIVgmMjA");

    if (xXrZnCCs != false) {
        for (int zRqqAyotLQV = 1463571417; zRqqAyotLQV > 0; zRqqAyotLQV--) {
            VVFgUabXDpwsQE += MKlWke;
            cTzNshzF /= cTzNshzF;
        }
    }

    if (VVFgUabXDpwsQE != string("nOXtqDIZUgRESzrgQFLAsKoZAzPfBcITaCFPrDIPzxdnPfHHmBYOwsFVwZmlPkzCSSqFwlZyiQGTAmMxZIRrjJABBnqyZCE")) {
        for (int FeuwkwYrQYxcOZr = 1896222434; FeuwkwYrQYxcOZr > 0; FeuwkwYrQYxcOZr--) {
            MKlWke = VVFgUabXDpwsQE;
            VVFgUabXDpwsQE += VVFgUabXDpwsQE;
        }
    }

    for (int xoXTyWtxP = 1394784769; xoXTyWtxP > 0; xoXTyWtxP--) {
        VVFgUabXDpwsQE = MKlWke;
        wLiCzVQV += wLiCzVQV;
    }

    for (int KWlQzvMxUQBHq = 751746596; KWlQzvMxUQBHq > 0; KWlQzvMxUQBHq--) {
        MKlWke += MKlWke;
        VVFgUabXDpwsQE = VVFgUabXDpwsQE;
    }

    for (int wQLTYkV = 1150831897; wQLTYkV > 0; wQLTYkV--) {
        continue;
    }
}

bool SOhJOm::lYEcPS()
{
    string GFPyFQlptRI = string("lYktrxMVNAqQAMyQVmEyfjoMevLuByeKqDAfptEnYWhSxNAcRCdbDudoFNdXVHQaBdbRqhgGlqqsKPWOlRngOwdcTGFgDsrdtxkcaXyjJrdVxlpxUWPpewlKqLLOmxKdqVbRDTq");
    bool ObtYyjHSUtmz = false;
    int BAWJTeQqAWYyne = -625733314;

    for (int MoIVIEhIEEpFL = 644962650; MoIVIEhIEEpFL > 0; MoIVIEhIEEpFL--) {
        BAWJTeQqAWYyne *= BAWJTeQqAWYyne;
    }

    for (int fQeSXUYhmAzNWkn = 797581937; fQeSXUYhmAzNWkn > 0; fQeSXUYhmAzNWkn--) {
        BAWJTeQqAWYyne = BAWJTeQqAWYyne;
        ObtYyjHSUtmz = ! ObtYyjHSUtmz;
    }

    if (BAWJTeQqAWYyne < -625733314) {
        for (int OoknUSEURmCAWR = 618882657; OoknUSEURmCAWR > 0; OoknUSEURmCAWR--) {
            ObtYyjHSUtmz = ! ObtYyjHSUtmz;
            BAWJTeQqAWYyne = BAWJTeQqAWYyne;
            ObtYyjHSUtmz = ! ObtYyjHSUtmz;
        }
    }

    return ObtYyjHSUtmz;
}

bool SOhJOm::UATkpwbpvNdRSV(bool GgWjupaVNfQiU, double ZWhvzQH, bool ogLXnSWug, string AIRoIMFNLP, double SYKvlYmomsCiadli)
{
    bool xQTheK = true;
    int juGdFhAbjjesbiV = 224203236;
    double VPfPOabK = -1011274.9058439989;
    bool MBRgetgaJZ = false;
    string nVZPYb = string("pqezFingPCRuFzOiXrCRVfzCwdJrlucTgORPOKKhDrBvflRkJzghfwRLhUhXMunDZsKLbEDyroZORWkGIgqh");
    string CelwsgVAvLTVdO = string("fSSaulYgpOEmpGdbtyDzufEFJhsMpRBiZyphApRGKCGDWuIjIyELxuFwYfcbdsqHOayympCsotpqPNnRSmrcumPvvRZrSavKSRdxhPrNOooJhdGdTrgAegYAFqDTcQyDubBeWLLcsUIdFypjHmEbVdzGmNcWgsdKHjzxIblnozUqTVwdHEVWbnWCisTdSQJbBCbSCgyvcZVsEQYPwpHzpVsuhEHleXfnva");

    if (nVZPYb != string("fSSaulYgpOEmpGdbtyDzufEFJhsMpRBiZyphApRGKCGDWuIjIyELxuFwYfcbdsqHOayympCsotpqPNnRSmrcumPvvRZrSavKSRdxhPrNOooJhdGdTrgAegYAFqDTcQyDubBeWLLcsUIdFypjHmEbVdzGmNcWgsdKHjzxIblnozUqTVwdHEVWbnWCisTdSQJbBCbSCgyvcZVsEQYPwpHzpVsuhEHleXfnva")) {
        for (int UPEMKrzA = 248933843; UPEMKrzA > 0; UPEMKrzA--) {
            nVZPYb = CelwsgVAvLTVdO;
            ogLXnSWug = ! xQTheK;
            MBRgetgaJZ = ! ogLXnSWug;
            ZWhvzQH *= ZWhvzQH;
        }
    }

    if (ZWhvzQH < -1011274.9058439989) {
        for (int RYEaQHGLJshetIt = 634938181; RYEaQHGLJshetIt > 0; RYEaQHGLJshetIt--) {
            VPfPOabK += VPfPOabK;
            xQTheK = MBRgetgaJZ;
            VPfPOabK = SYKvlYmomsCiadli;
        }
    }

    if (VPfPOabK < -1041210.7176106805) {
        for (int XPNLsStpMJrk = 305954641; XPNLsStpMJrk > 0; XPNLsStpMJrk--) {
            GgWjupaVNfQiU = xQTheK;
            ZWhvzQH /= VPfPOabK;
        }
    }

    if (ogLXnSWug != false) {
        for (int igmEvuOhcq = 147291717; igmEvuOhcq > 0; igmEvuOhcq--) {
            AIRoIMFNLP = CelwsgVAvLTVdO;
            xQTheK = GgWjupaVNfQiU;
            AIRoIMFNLP = nVZPYb;
        }
    }

    return MBRgetgaJZ;
}

double SOhJOm::rYnbV()
{
    int CmVwzkgUl = -57626403;
    int ETxsNIvncZMmRM = 1444275142;
    string lPJyPhArTw = string("hMbnvGtznCthdHBJHOdWNwKzcKvrGuSXzuMPOPtATuXbeexVpcUxJWxtabwOSyPzdKRppvfeYbeYuzIpMxemNAiratzUKthwiApxaNSjEfIiSIoVnJAnISSutnmujnGesQHfOxYARnBTyEmStRGiSVvKgUmXcafXoVLUZSWohtYFceFofiyKRokTjaLTJGBgbbImPepCFHPsQZEFSvwZKzZMjbg");
    string PTvmrfnLTBWor = string("DVQMmqhUgvgnjLPCtPxwVvQiqrhBOTZvDSvgCBjOdctvJhXQUUQmeUCLxiOWJTuVYaYyPIKashXpNCHqbaCwGbISFOoihLoWqsriJOoMNNQFgIOHCzYZJwAqrlmuZWYwTPCAbIZiqDcwJhkTgaBBTSngfiJsPmtxgzeqFgoALqwGQYCOxHmVxkTXivdHUgKXvEWICrEQFZPUSpbXiUhsJLghMJbuizruxYL");
    string YPYFbyexTney = string("ADErcxeVMkttCyEStcUuKIrSyzFJALXkaYPzLrwZZhQTuvKrjukqnOJGuWVsDJgHArlcNzgwPdaiLDIMlHpuVpoOIiJuLGVBFKrclIbIeQtkbgWtwHSpmZiqJYmFveYoutULuHIZZvFWmBKyKBajmSTCjxLXORqaEXNuWsiWpNkYeuOhJWNFKrdKshaoDsBvaPjHZrbCDDNONsjYfblKqVRFkeOuSEeqRnTCe");

    for (int fJTYdVeJMWGi = 450705402; fJTYdVeJMWGi > 0; fJTYdVeJMWGi--) {
        ETxsNIvncZMmRM += ETxsNIvncZMmRM;
        PTvmrfnLTBWor = YPYFbyexTney;
    }

    return -32796.13680248362;
}

double SOhJOm::eTpfcrgfYgRvZfz(string MRygmtwTRzxX, bool DohaB, bool EqkoQqdwjQeDul)
{
    bool gFZWJSawz = true;
    int IZLyT = -2026450579;

    for (int YZiZFovPzkDoxOU = 2018681730; YZiZFovPzkDoxOU > 0; YZiZFovPzkDoxOU--) {
        EqkoQqdwjQeDul = gFZWJSawz;
    }

    return 121800.31301054233;
}

bool SOhJOm::HNxlECKUxVrbSnat(int HqqxS)
{
    int JEoblatd = 806874608;
    string UCdnXICpHH = string("AwSAUMydQMCOkpLDcRDdqYTxbpxccsfbEgcokHucgmxhwgzZADikqkHnWXwOWUhftxbtHNsqhJvNxiavDsZ");
    string kpfGBSCrj = string("NWtEyzEEajMrcWwVftbVWVcNCsITFVrrlkwefVBCmgpOuCIFvdaoInJFrAnMdpuhuUMdjXwmznxYmMLAQtVhERzGOKHKQQxEUsEWDPCvchHwWXfgSXZIrqoeHrvddORORJmHzyDfwZDmiun");
    double opIAaovXBxISjJMt = -602943.6039655172;
    int bwZQyJHpYQQiT = 945690416;
    double ZBdGpndUUNBbt = -55132.87788545998;
    double pHFGsMsONISZ = 524834.3574259481;
    double oTXeb = 20070.524817219728;
    bool CJEdutISFeUpkqRg = true;
    string cqWAppiydq = string("diAXNMaJVijKxvEbWEYUOpIBlJzRppXFpeCLKyMaWbrsJTHXMqpQvkibMQAVYKqaoyZPQbxfWibhPMGCgDHefMstCgyCstkvwxAtKWsyhHuNmpMIiOZaBeonsdMfXaPUoDmyhMxijIhGXDrkMGauUttLBdJHMLfUtuTjXzoCTJmMtNrlqCGOQYDMwqmaWaTOqZiodhMLnwKQyygLMxCkAtEZRhtLw");

    for (int kacFFTHZHTPP = 1043123233; kacFFTHZHTPP > 0; kacFFTHZHTPP--) {
        continue;
    }

    for (int TbrFQZD = 292582763; TbrFQZD > 0; TbrFQZD--) {
        continue;
    }

    return CJEdutISFeUpkqRg;
}

int SOhJOm::jFcglIgXUtz(double napnE, string gLimU, string XcPaYSA, double ezJZNDzN, string mLXrp)
{
    bool mxaACRcJzh = false;
    string GrGeLaCsKity = string("nLPtlcofxGfkVaFqfRuHTnxJHYUYXWQowwEBPZQVYlYFQlxrOxQUDWjkSGnwtatSNywYAGFpdAPHorDBMDHIpuOwlGCGhnnlbKQeyDCDlBGiIgqxipsiofZMbFNMwytqThVaPPPKBJwbyoIzeGSfy");
    double lugiwFl = -713216.2721016704;
    double VfERjWqyLgS = 122330.82987278646;
    bool fshgTpnz = true;
    int KVDhWOZTEya = 2047235011;

    if (ezJZNDzN == 122330.82987278646) {
        for (int LkpLZSOIhhZb = 1153579344; LkpLZSOIhhZb > 0; LkpLZSOIhhZb--) {
            continue;
        }
    }

    if (mLXrp > string("nLPtlcofxGfkVaFqfRuHTnxJHYUYXWQowwEBPZQVYlYFQlxrOxQUDWjkSGnwtatSNywYAGFpdAPHorDBMDHIpuOwlGCGhnnlbKQeyDCDlBGiIgqxipsiofZMbFNMwytqThVaPPPKBJwbyoIzeGSfy")) {
        for (int IAUhJWMofVbshP = 1958348844; IAUhJWMofVbshP > 0; IAUhJWMofVbshP--) {
            XcPaYSA += gLimU;
            GrGeLaCsKity = gLimU;
        }
    }

    return KVDhWOZTEya;
}

int SOhJOm::jDuvBKG(int gDNEVMfVHoDekc, string cnxGVJvbkT, string NpAHQqmrUx)
{
    double eDISFROwomz = -109423.38150182238;

    for (int znUxZTLPKj = 903603506; znUxZTLPKj > 0; znUxZTLPKj--) {
        NpAHQqmrUx += NpAHQqmrUx;
        gDNEVMfVHoDekc = gDNEVMfVHoDekc;
    }

    for (int WstxiutO = 1425124211; WstxiutO > 0; WstxiutO--) {
        eDISFROwomz /= eDISFROwomz;
        cnxGVJvbkT += NpAHQqmrUx;
    }

    return gDNEVMfVHoDekc;
}

double SOhJOm::QEGDcpcEjVEdaov(bool AnGLAdgZt, bool lWoEMPrND, string WJFdGjal, double uoinQXtZ)
{
    double cuJyGBaPcJWu = -373152.1039634421;
    double czgbS = 1019940.1083873912;
    int DkQPN = -823717309;

    for (int meGGB = 1180642505; meGGB > 0; meGGB--) {
        cuJyGBaPcJWu += czgbS;
    }

    return czgbS;
}

double SOhJOm::RxBlkTvyqJNLQgk(int XwPqyApEjBWuR, bool xkBWFRcPUC, double pgaVeXaXJv, bool ueqwNTOfv, int DqVjTpbO)
{
    int WEmzPNCCeTDf = -1595475383;
    string AYCHIhw = string("HFDVAgTVXzVijtQnwuwmOzrMWvKAHlBinPLjKpleVfHwfFiKGZxKaCkPqhnDrhgSChbSADPthlZXZgfSvWKbqtYhkGeMcWdwLykrzRFuLWecmGkCneuIEbEqdIyXcTsOWZOHhwXoEmJkAPwzmSuEvfCDareOvCbOAVsTmsPaNrmuFujcZvtXCXbSYjSpczoT");

    if (ueqwNTOfv != true) {
        for (int KSKkVQb = 1749171626; KSKkVQb > 0; KSKkVQb--) {
            pgaVeXaXJv += pgaVeXaXJv;
            WEmzPNCCeTDf /= DqVjTpbO;
            XwPqyApEjBWuR += XwPqyApEjBWuR;
        }
    }

    for (int rRabKDChsPmOJfKh = 1924427338; rRabKDChsPmOJfKh > 0; rRabKDChsPmOJfKh--) {
        DqVjTpbO += XwPqyApEjBWuR;
        WEmzPNCCeTDf *= DqVjTpbO;
        XwPqyApEjBWuR += DqVjTpbO;
    }

    for (int ArkKKXhJSwRpQQ = 796977502; ArkKKXhJSwRpQQ > 0; ArkKKXhJSwRpQQ--) {
        DqVjTpbO *= WEmzPNCCeTDf;
        ueqwNTOfv = ! ueqwNTOfv;
        xkBWFRcPUC = ! ueqwNTOfv;
        DqVjTpbO = XwPqyApEjBWuR;
        pgaVeXaXJv -= pgaVeXaXJv;
    }

    return pgaVeXaXJv;
}

int SOhJOm::bRYaFzJ()
{
    int kmlENdq = 970678767;
    string VZLEiGpxPTHH = string("lSaaDXyQvrLMRTAtgawUloyILLhKTRrvcgfexSMFLWhuyCWfyxMHAbaiNahrMMXOAYcUdzAdOiSdGlgnNRNFvgOrOZVerHaXaOfOhOKXOjJSabvpGOdeIajSWGPnKvlBJYtqtYGoZfFGXddwDSNtLyzRJxUgRJHmULieOIcdZu");
    bool tcRSAPKr = true;
    bool xLLVGrpj = false;

    for (int mNtzxcgim = 1528956406; mNtzxcgim > 0; mNtzxcgim--) {
        tcRSAPKr = xLLVGrpj;
        xLLVGrpj = tcRSAPKr;
        xLLVGrpj = xLLVGrpj;
        tcRSAPKr = tcRSAPKr;
        kmlENdq += kmlENdq;
        xLLVGrpj = xLLVGrpj;
    }

    return kmlENdq;
}

int SOhJOm::ileUpFdCiHZ(double evxSeSRsl)
{
    string tEkSItD = string("voDZHyQmObUeyDsanbONIMnWOnakANRETZUCcahozrpKtFlQeMHtKCmqlkeQsLUvGzcVlZJlHrMbUbkxNGotaOxfALozQTpNyClFuYzAkUTo");
    string zdDVpPW = string("XCmtUrwovlyIWFyDgyFMEhfHkYPMoTouqcIHMZCqxfmvDydbhWUqrevpXJOZLEnZobTEqPoTzUEYvYktnarpwouiecSGuCaMCvRGflColVtsXsZylJhLCVBerpNXhYrxRmYjypdTdYLqCIuOLVRWXPKCsmJUAjGrvrKVwPxtOlEDYNDbNOnXiRiVxLaXJhYrYXdrbSzGKBJLJwzqgFkqIyxPculjmrEiwsYVhYjkvjJBZamMpwhqeQeYARv");

    if (tEkSItD < string("voDZHyQmObUeyDsanbONIMnWOnakANRETZUCcahozrpKtFlQeMHtKCmqlkeQsLUvGzcVlZJlHrMbUbkxNGotaOxfALozQTpNyClFuYzAkUTo")) {
        for (int PpzOYvJzFsqgXA = 1230502822; PpzOYvJzFsqgXA > 0; PpzOYvJzFsqgXA--) {
            zdDVpPW += tEkSItD;
            zdDVpPW = tEkSItD;
            zdDVpPW += tEkSItD;
            tEkSItD = tEkSItD;
        }
    }

    for (int HfukflzFDjAW = 1635349255; HfukflzFDjAW > 0; HfukflzFDjAW--) {
        tEkSItD += tEkSItD;
        evxSeSRsl = evxSeSRsl;
    }

    if (zdDVpPW < string("voDZHyQmObUeyDsanbONIMnWOnakANRETZUCcahozrpKtFlQeMHtKCmqlkeQsLUvGzcVlZJlHrMbUbkxNGotaOxfALozQTpNyClFuYzAkUTo")) {
        for (int nelzAtZpftGHOuS = 563654870; nelzAtZpftGHOuS > 0; nelzAtZpftGHOuS--) {
            continue;
        }
    }

    return -313746398;
}

string SOhJOm::hjfTAKBbfIwHW(string GbnNLPQQv, string qEbZlZjYhsxswF)
{
    string jRmaKUUovlEeyr = string("IconXJxDxEOHupzSJYBXBYoGclWMjdVqGxbRLBFVSSLOQZuqdSpEJftNRXEWoYtJmWGsxv");

    if (qEbZlZjYhsxswF >= string("bFfRxzswyAlHOoSfmSNFuxMNcSaVeFyemrpXvBWytyCVHPzqklEscoEKD")) {
        for (int xXmBQGnC = 801351020; xXmBQGnC > 0; xXmBQGnC--) {
            GbnNLPQQv = qEbZlZjYhsxswF;
            jRmaKUUovlEeyr = GbnNLPQQv;
            GbnNLPQQv = GbnNLPQQv;
            qEbZlZjYhsxswF = GbnNLPQQv;
            jRmaKUUovlEeyr = GbnNLPQQv;
        }
    }

    if (GbnNLPQQv <= string("bFfRxzswyAlHOoSfmSNFuxMNcSaVeFyemrpXvBWytyCVHPzqklEscoEKD")) {
        for (int APBGdDZpFLL = 1897235254; APBGdDZpFLL > 0; APBGdDZpFLL--) {
            jRmaKUUovlEeyr = jRmaKUUovlEeyr;
            GbnNLPQQv = jRmaKUUovlEeyr;
            GbnNLPQQv += qEbZlZjYhsxswF;
            jRmaKUUovlEeyr = qEbZlZjYhsxswF;
            GbnNLPQQv += qEbZlZjYhsxswF;
        }
    }

    if (jRmaKUUovlEeyr <= string("bpHhofOqftnJzFGIwETGsYkAaHzieTXUUAhRPQqvlSwNYxjtNlORFjQyREFOXwVRSFpBpmthcmmWmcJrnRqDIqJsPHAyIGpppfbHlgGvjWAhlfqotOxaYzcSfmfKtVnYlOAeVacVQOAMeJnJzeRQSzWeyOdOtUiNwHdOwAXJVVMSfoVlJgVUNBukxdzKNuKhVwLKNAUKcauqoQlWpTPdWbIQzFEFfVdQtlMrUyWGGweOso")) {
        for (int odKhtpsHtJnYiLI = 549493896; odKhtpsHtJnYiLI > 0; odKhtpsHtJnYiLI--) {
            qEbZlZjYhsxswF += GbnNLPQQv;
            qEbZlZjYhsxswF += GbnNLPQQv;
        }
    }

    return jRmaKUUovlEeyr;
}

int SOhJOm::iLWFsdAgXDmwy(int GVfvfUPrTjCnliN, bool qfyVRQH)
{
    double CydYVizSadMvYe = -31251.58379335108;
    string nIaUbmeoIZXFm = string("RkuPOWHByTxQoYgUuwABiyrrUVWiFGSktIjjynOoDNRGFbLnrWJdTJLFutlklUCojoeDpQGBuitLODInlownVfgvNXwTvTCHdPVBmIWewmGGPOQcDUrXSAvuGTZqLpBUFHthfznempOyCIeIWDQztZeDSWGqKapJtQfAxaDgQsluVCzPxaafaIQUsXUTuBgpSMjnvrLcKjYUydbRYYpNAqrxRDXibkxZGQmxgbZ");
    string ZIgXcL = string("UtxnUSPvgCgJisPaxGWrWoTwJkglVzZUWorCwLjLFlqoaXmIWGqRcgiOjVfrGiExWOUfQzufbeFAmpRkkrsvwQDxvjlAuvaSoY");
    int kwQcCKgUZD = -792136375;
    double ePYZFHkaDnwAFSPX = 317267.6214812897;
    double eElqCIpGjrQXTQv = 409985.57456055086;
    string OuGXQng = string("aMRJyhsKXKAcDtUOzNoCrmOElxotFndHOSJFbSsGcgumsswRnpISJFhiyDiEIeOiDPHjQzhbhZomSJghBHQmvyDyxpIoDOhGaqxofrnIakJeTJAxjqSOqlLedzCUIoEtpLbXwDkkWbBbHgCjoVlwinJZQysPmggecgOxqrlqwgXA");
    bool RxgcoXqUaq = true;
    string EfmRTNnJUlgkX = string("cYVvOVEzBUPDJvFbxteyQGicZKE");

    if (CydYVizSadMvYe > 317267.6214812897) {
        for (int GmwWT = 1654817569; GmwWT > 0; GmwWT--) {
            OuGXQng += ZIgXcL;
        }
    }

    return kwQcCKgUZD;
}

SOhJOm::SOhJOm()
{
    this->DemixxqGMypy(string("PvDfxfmJgsVtQPHoRqcQVIaSRPqMEsivaEaCwOZAKMGOIZTNmrrJmcwmeZbbDuqMXVCdOHGMmJmNWRpBoMrhcVrlTJqsxQbDSXGilwoQpxBdOJtnbFMyuUUZLEmYdWWFisuTMHBRUZUSKKVHkIFLNWNicBpNdDozHHCZuNukizNIPSTvVjYIfBQxUrigbJpcgVngBNMNUFWaEjxhXHxIOdFkdEfXmCeGRTh"), -1340533733);
    this->PfheK(117139.10660461482, -213908.7561372828, true, false);
    this->DDltW(string("ZjZEwPqbgkxYExShgk"), string("kdhpxlOXGWpoIvceVxvvPOaTVZZoTrPEjwjzgxhEyDVcJbfHkkfLDKmZnanYjNlNrqkLLpEAabXMmfEdvTOPBvIgdOYZlTrFgdFWbIPmPODWyvCTlFKDswnCWwKhfmFHVJyalMhkDWEGjBNRtYTlisumuvpVYMzfYvgVNGAgckdDiLqUGnnYRvERINFvzhsAPsiTCwYlITjogtKPRnxuATvYiEDtIuYblHYJvTadoaofGYxAsfvLbJtQEb"), true);
    this->bCJIrTAuncTwoG(string("nOXtqDIZUgRESzrgQFLAsKoZAzPfBcITaCFPrDIPzxdnPfHHmBYOwsFVwZmlPkzCSSqFwlZyiQGTAmMxZIRrjJABBnqyZCE"));
    this->lYEcPS();
    this->UATkpwbpvNdRSV(false, -1041210.7176106805, false, string("BbnkcLGKvAyfOaDKwQZMBFcZcTtOsBZyVmvgeilTPuSNEOnebxPQkgDaolvYwcLIDFUXGuWcvwoDZtvSVXCvXOLNxxsDSOCzLQETHaRqZmhiJjVmZVODUIPFSaMBMhBElwrKRxPsDuKGygLuCKrhMPlCEMgDmvqVLFQPUtOiOsfNrMqeNmUsBmZXNWMCRepozJXsfMxhzkwUDIRsZUXPjTyW"), 314655.39960785274);
    this->rYnbV();
    this->eTpfcrgfYgRvZfz(string("PvumRkvrIpUOzxWTtECAaLmTULUjMELPYcqtyzVeBFXfhVZtARMFnkglndUqFxGXdvEUpUyhxzQanjvFEJFlGUJcXdHVHXvruWqjEnOnhSqgsoiXvENYpJ"), true, false);
    this->HNxlECKUxVrbSnat(1780867516);
    this->jFcglIgXUtz(207590.29211947965, string("cyXehsHCpKISwXCpkvpOSAdIfufrXciAShXSsklXNgcogRgQtnOkpYtCdqkctfWKDPqsWCWSaiykEQSaqdfPGmUhKwbKEQBsDGlaLySMXROXjpYQIqoBgFHfBWFEnNGdNJjytNfqKfSiWqxhCbKcbwkZDPBPUKNaoInPGBtZAuuTKuO"), string("SbxSMxqdYLKbgVvdNYrIGyVYzhAsYQxBRofmGEHtJiuAdOeLcLzIDJvMPTmxIouqQJHkAFFZllpeJRsQeNoDucCWHiMLKbnVwNgfsTpGOQlDcDYIosxpsZItMmYyxIdbBmPYLmKYCWvpjmdFUSQPskStXaZRPzhgCWvADkrRPRhZYdBeTFXXASnvzdpWvxNqaQafiOnGQqSGQJWcLOlUCiFawnzubyNYOLSEFlpzHpzzTRLQEsoKpiWAgiVz"), -411466.02084253664, string("mEuVnJIExCqFRVbhZtIrYfmIKvDHAykehntMLVLApvjmBdJhIGhwCIctaiGEjTEDztNbLzLuLdtIPLNYoskgZarGXqrXbLMXfMMAyCOAgbedaAOOMMnwltLJaoktUyVbLcOVFLreHrhogQQolFlDVWHmTFFeLeDGGWbnUgyZUddNscbuEeMBygaMTYcEbqfp"));
    this->jDuvBKG(-445339448, string("YzaYMBDxDiTKbmUsEpJkzkNHGZNXQNBZkZsYCAYBhuzMBOqltbYymyVOLPzOeIrItCAZYysMQAnJtRDxprocderedVSZhUCkrgyhKJdeVFfdfnBFMDYsaSzBXcZMEbmLlBsMloNaGGBDQGLGsJcFRXuvkyTVEpCglnsYhKKuYjGahwtxjffUTdcxrESfxipnsQOOUkWFVLkmIBfgfEfuaUYMHUtiNtHVjyJipMuUKLDLu"), string("zzZbZvwxNFhNdIUHKJcOnpgePiatNQyOTVOpebiedKtyGEhdCwCBjqlEsCZNoKAzbdXymRijEvHuQyqhRRCoDmdaEypxnjZlUufEsuRgoqjsNXGlAIMwaXdhNlRIcFpwJByDPkjfzQDlr"));
    this->QEGDcpcEjVEdaov(false, true, string("tpdBxoTrSgKlJDOqBJODWAxwPHTTfFqCSiWPoqabYAqAuJSCKsADxXvbNKfBkK"), -228014.53357327977);
    this->RxBlkTvyqJNLQgk(2063144309, true, 96448.11380232815, true, 139348130);
    this->bRYaFzJ();
    this->ileUpFdCiHZ(808409.2366898814);
    this->hjfTAKBbfIwHW(string("bpHhofOqftnJzFGIwETGsYkAaHzieTXUUAhRPQqvlSwNYxjtNlORFjQyREFOXwVRSFpBpmthcmmWmcJrnRqDIqJsPHAyIGpppfbHlgGvjWAhlfqotOxaYzcSfmfKtVnYlOAeVacVQOAMeJnJzeRQSzWeyOdOtUiNwHdOwAXJVVMSfoVlJgVUNBukxdzKNuKhVwLKNAUKcauqoQlWpTPdWbIQzFEFfVdQtlMrUyWGGweOso"), string("bFfRxzswyAlHOoSfmSNFuxMNcSaVeFyemrpXvBWytyCVHPzqklEscoEKD"));
    this->iLWFsdAgXDmwy(1220014110, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sogtpffHEuLGG
{
public:
    int nVyKWoOKj;
    string vHCLTmxmgJeGuee;

    sogtpffHEuLGG();
    double qYJVWURl(bool gFUjsQqtN);
    double VPwKrNJLwPruQHu(string CmBDFMLksLPkP, string mvKjKMrA);
    int YqLEMWWOWRRLi(bool JWACTP, string VRHuIartpN, double kqFwWLeVddVSutiB);
    double PMXvEKcGMb(bool UPOiWXlYnb, int dDYKaMCalaCVIH);
    void oLEsyNAVbND(string MLJRytGMpCVle, double xgWRQlhIW, string xlsBJkXSOpe);
    string eXHmIiuqPCY(double JUcorD, int NFUigd, int ZXpbGjPUpsTXj, int eQVSBprVlhQBFtZT, double balUMpVkEmOwHSE);
    double JiLLNmy(int UyDOUmyOSA, int eawubCJZafDl);
protected:
    double kIWojnSj;
    double pgpNW;
    double wfSnmTkAXvTla;
    double QdkohpgJbCN;
    double wKpjrU;
    string dqSBiNxKHY;

    int XkzeTgVcpNEWnZjX();
    double lkptCrpmHbFtA(bool aCnYOXuLuJCoXS, int jAqlQ, int JnxFBAhcFY);
    void yhbEjWaRuKHwx(bool gzpUhKtDMci, bool TWkPrBBugEBEDWs, bool EfweM, double uYUOlegLPi, string oTfBXpaDPkJKVeGQ);
private:
    double XGkOhcQcfD;
    bool ZxVFPj;

    string jvEGb(bool wugySBBVkdXBH, double JalkITlgDgb, string cGGCuEcHZYU, int XPGBELq, double MJKpHqMIMSxyByWF);
    double lrMxxKeoTPQJd();
    bool AFnYGegcLZdXte();
    double orJSjneokLZfsY();
    double vuPvfnAgFqjle(bool WNjbKh, bool rmjXDxjlVvIm, string JigUVRUWqsGvO, bool COSAkP);
    string DKoxy(bool LwdBhjepF, string tmADiJRlK, string PgcQG);
};

double sogtpffHEuLGG::qYJVWURl(bool gFUjsQqtN)
{
    double LxksSDyodILwqM = 331721.9989052633;
    string RgLvlJNEoN = string("ltGhXbhIVyvKxXvQcCzUuDMmMcAsrKdZILKuLCuNuTaEXTAZOQkAJdAaoHOnTfBPRRhMebGiywRDxyCYKjWLjNEIOVqTIfxLVQgIOPYyWTYXoIccevibOERwPgzTwVQpoBpEg");
    int kNPFoDcAfIGaodB = -1821599722;
    string WSiHqiSJFP = string("LcAdJpxqRnuIeZlVWgDtDWwYPIWCyFsMVDJseYefenLhlVqGTUtIedBKjrPRRbRsrdydCzRBonzJrixYPhfXVxjgGIAXEAnhuDgfEkZDtZAWpNqaWQbEdplUvCNDecZvBDtKHGzuNnUNCQfdvGkuxTVUURUBNlUZYgcI");
    bool kVruOPTpVYmcoj = false;

    if (LxksSDyodILwqM <= 331721.9989052633) {
        for (int nPNRgT = 1388934402; nPNRgT > 0; nPNRgT--) {
            continue;
        }
    }

    for (int ShgxlJFMfqWTNl = 851068914; ShgxlJFMfqWTNl > 0; ShgxlJFMfqWTNl--) {
        gFUjsQqtN = kVruOPTpVYmcoj;
    }

    for (int nhiSxNFcjQQa = 842084367; nhiSxNFcjQQa > 0; nhiSxNFcjQQa--) {
        kVruOPTpVYmcoj = gFUjsQqtN;
        kNPFoDcAfIGaodB *= kNPFoDcAfIGaodB;
    }

    return LxksSDyodILwqM;
}

double sogtpffHEuLGG::VPwKrNJLwPruQHu(string CmBDFMLksLPkP, string mvKjKMrA)
{
    bool FoUSbdS = false;

    if (mvKjKMrA <= string("qiqcgxoiCWKmdlsvuRQkmTyPWRkiQVImjvsqqAYcLZsmECZLJwpMEvQSwLEqCJDvMiPDpQCZphNxmhaDACK")) {
        for (int FkMsi = 1463876424; FkMsi > 0; FkMsi--) {
            CmBDFMLksLPkP = CmBDFMLksLPkP;
            CmBDFMLksLPkP += mvKjKMrA;
            CmBDFMLksLPkP += CmBDFMLksLPkP;
        }
    }

    for (int rkBNcet = 349473561; rkBNcet > 0; rkBNcet--) {
        mvKjKMrA += CmBDFMLksLPkP;
    }

    for (int jcvapjIxIFRamN = 872129440; jcvapjIxIFRamN > 0; jcvapjIxIFRamN--) {
        mvKjKMrA = mvKjKMrA;
    }

    if (CmBDFMLksLPkP >= string("qiqcgxoiCWKmdlsvuRQkmTyPWRkiQVImjvsqqAYcLZsmECZLJwpMEvQSwLEqCJDvMiPDpQCZphNxmhaDACK")) {
        for (int EKrgFhtKzmCrd = 545946426; EKrgFhtKzmCrd > 0; EKrgFhtKzmCrd--) {
            mvKjKMrA += mvKjKMrA;
            mvKjKMrA = mvKjKMrA;
        }
    }

    return 722163.5435777684;
}

int sogtpffHEuLGG::YqLEMWWOWRRLi(bool JWACTP, string VRHuIartpN, double kqFwWLeVddVSutiB)
{
    int bUDCFpEtqDXCsq = -356761713;
    bool vFUPRdW = true;
    string VNdXhyGYS = string("fRpIqTmWaHhKBJjomGXuyUDBWeEbCmVXloGJRjqNpIeRRJFTtfkQHKgAOfqMuZeRNPjWgiiMbCaKNwnUVHvlWwZsEOYQVEAyilkdPmoOAqyxominsvyKfqwSNGuFHSsjbxZjtgSEgeJlNRxFhsSOvqkQWmqeHRcQwHGEaWgmHZMkUQunfDzRKOoSNVphaDHHjxciikthSStVmxOzWyglwYSCMGyrxuzyOPtpViw");
    int IuJiJtAG = 431814743;
    string DKvzAIBh = string("XKGiUSGrgUJLhNuoEAtDmrMMwPNOorwiaLdVXYEwBgUryScrbHVsweqxORPZkBdiqJ");
    int yKSRpUhcn = -975271427;
    string fmrVE = string("ahWOzqkjfaKwSOyBBFWylEpjVYmqERZcDBbZBxSjMEnPvdawiAgBpwynYqeFwojorOCisrLOQChJvTnawFPyuxbrYiHfX");
    int PIFoMSrQBWRkxZsl = 1115716708;

    for (int pwUEG = 192934353; pwUEG > 0; pwUEG--) {
        yKSRpUhcn -= yKSRpUhcn;
        bUDCFpEtqDXCsq /= IuJiJtAG;
        VRHuIartpN = DKvzAIBh;
    }

    if (yKSRpUhcn <= -975271427) {
        for (int GDbLY = 1384983227; GDbLY > 0; GDbLY--) {
            fmrVE += VRHuIartpN;
        }
    }

    return PIFoMSrQBWRkxZsl;
}

double sogtpffHEuLGG::PMXvEKcGMb(bool UPOiWXlYnb, int dDYKaMCalaCVIH)
{
    bool GDeSZFgyoE = true;
    string hxnsbqhkhWHIpziM = string("ydJGotgNaCvoVjPQZNoyjntozlOzHjAZtWwKTDNDiRajKszzhJuqbsMGpyxnYnowQmawEKKTZgTaxgszKeprGbXIhZlcBhADPYczpmzKSvVAtVgcPzUsGJfKEeJrWNPMfjfSidmKZXOcINMcgdM");
    string SnDJWCEePbKcKjqt = string("VAlqHoNODqiGSdIiWDKhlgtHkDidWUBmwngSQefMyidPjTxiDEEoNZQDcntGnMpYIrMFwkgHyvrceFdZlfmcAMJADcNPqoAJqxYGkCghTjEarrfhzEWQQiLouLHhXoeqHFsBCOLTAKHlOfE");
    double QYSqH = -755132.8642808041;
    double DNfRxlnf = 787694.2556510014;
    double AEKJuanNrlaQ = -513474.1342761659;
    double nVIxQVACJyhjjWe = 58199.31802254245;
    int sNARuLgZrvle = -1439534399;
    double aCnFjn = 1013617.9187283363;
    double JrzOGyWWIvp = 1031040.3033282041;

    if (aCnFjn > 1013617.9187283363) {
        for (int RoNeypOkLObMtT = 991308830; RoNeypOkLObMtT > 0; RoNeypOkLObMtT--) {
            continue;
        }
    }

    for (int XpWHpYdlyiRA = 1392128194; XpWHpYdlyiRA > 0; XpWHpYdlyiRA--) {
        aCnFjn *= DNfRxlnf;
        AEKJuanNrlaQ /= QYSqH;
    }

    if (DNfRxlnf == 1013617.9187283363) {
        for (int xkCGFgNmeE = 778693306; xkCGFgNmeE > 0; xkCGFgNmeE--) {
            continue;
        }
    }

    return JrzOGyWWIvp;
}

void sogtpffHEuLGG::oLEsyNAVbND(string MLJRytGMpCVle, double xgWRQlhIW, string xlsBJkXSOpe)
{
    int sNowixzSdA = -680903430;
    int lnwpb = 1161115539;
    bool wNwHXz = true;
    int MAAIadHEWcXQq = 755492016;
    double pGjpZ = 167917.24418178963;
    string oyRkW = string("GkvkYqZvwqllmEiUuEQVDsDIaVOFEjAeVLIxghYjGtHwtUNxskJsdLKqYXHbqXlpNcnINHVNdAlNAolbPtIiHwKhCdbzucpbBzGMrYkFrjVAHeJcGvrRRpWyyOSyHCvzolmZKarcYEYuwTSmjOmfSRzweBGrd");
    int FWiiw = -795004701;
    double hoUXOnFYafhEwq = -691100.772422457;

    for (int QQwiF = 169922098; QQwiF > 0; QQwiF--) {
        continue;
    }

    for (int QKWXWuRt = 1510582918; QKWXWuRt > 0; QKWXWuRt--) {
        sNowixzSdA *= sNowixzSdA;
    }
}

string sogtpffHEuLGG::eXHmIiuqPCY(double JUcorD, int NFUigd, int ZXpbGjPUpsTXj, int eQVSBprVlhQBFtZT, double balUMpVkEmOwHSE)
{
    double XpGdqMSvPDrXFlh = 937296.5081206745;
    int dnvvFGrNBkcpir = -1414427880;
    bool BEsxXLqLrgRwvgh = false;
    bool CEsZjfVaK = true;
    bool GtxvPUWLbrvhsxO = false;
    bool XpzyzxAPVJWxo = false;

    for (int PyoInrKs = 1836094231; PyoInrKs > 0; PyoInrKs--) {
        CEsZjfVaK = ! CEsZjfVaK;
        ZXpbGjPUpsTXj /= eQVSBprVlhQBFtZT;
    }

    if (balUMpVkEmOwHSE == 795323.4706870014) {
        for (int GzyCZD = 1195968336; GzyCZD > 0; GzyCZD--) {
            BEsxXLqLrgRwvgh = GtxvPUWLbrvhsxO;
            eQVSBprVlhQBFtZT += eQVSBprVlhQBFtZT;
        }
    }

    if (GtxvPUWLbrvhsxO == true) {
        for (int wSHIqQaxQesDgigl = 88727085; wSHIqQaxQesDgigl > 0; wSHIqQaxQesDgigl--) {
            GtxvPUWLbrvhsxO = BEsxXLqLrgRwvgh;
        }
    }

    for (int hgkNyAcwgNKYsx = 1958132887; hgkNyAcwgNKYsx > 0; hgkNyAcwgNKYsx--) {
        dnvvFGrNBkcpir -= ZXpbGjPUpsTXj;
        XpzyzxAPVJWxo = BEsxXLqLrgRwvgh;
    }

    for (int NeQIEcFC = 66215085; NeQIEcFC > 0; NeQIEcFC--) {
        ZXpbGjPUpsTXj /= NFUigd;
        XpzyzxAPVJWxo = XpzyzxAPVJWxo;
    }

    for (int qpvRrlbJG = 1609478245; qpvRrlbJG > 0; qpvRrlbJG--) {
        balUMpVkEmOwHSE /= balUMpVkEmOwHSE;
    }

    return string("jUazTfVPBBTNaEVtCzZgRxMlWuJezDzHQMiQjMPamuGSwQybwISrXXv");
}

double sogtpffHEuLGG::JiLLNmy(int UyDOUmyOSA, int eawubCJZafDl)
{
    string jjeGkyWawK = string("dYpcdpxJmMpOFaoZirhOmrHTAHgOCAlwhSdccSWWCoxWIuIEMrZRCHEPtbvXzkNHIaBAnHvUHfuPaTkjrShrpkQKAGvonxDBAljiFPbGQMElMjLhdUMBPKZ");
    double LoVnaA = -117148.78244445872;
    bool qeTrOfbMd = false;
    string EOPKo = string("KJeJSXhRWIUOYtjggSFHgtFcVVgznJParEsrErDbDhLpfPoJqiBtgRsuPmcJuaRMaasNeHUQKuCrWzBmevmhmabQswUxJwraTgQHkGnsdQZoriuZrxAq");
    double fQfPJsU = -205877.35852225198;
    bool UTmuzpP = true;
    double cfibmLGEIMvCeKI = -379800.962215696;
    double npoBshfqzRFRT = -284253.2526600487;

    for (int TJEVhkazaS = 1853181489; TJEVhkazaS > 0; TJEVhkazaS--) {
        EOPKo = EOPKo;
        LoVnaA *= fQfPJsU;
    }

    return npoBshfqzRFRT;
}

int sogtpffHEuLGG::XkzeTgVcpNEWnZjX()
{
    int uSlorkBV = 1412340816;
    double uQHHrsgGOn = -953430.2000378135;
    int rturnXlB = 1080108254;
    string veBzZWzHSiHpCInZ = string("BkDxsDlBanBqJQjVBHoTGKQELCUeemdqyDGZxDixLOmSyeirdGjKxelKnJvDganRMsNrifquRqykMZo");
    string VkaPyytOdE = string("ZjHwtOAkEfMstDPboSmKplKCktkyvqJGbMDJbUHFpGwEixlJPjiPAzoIWsCWilZQZjmXsSQuFxSmMvTiMkviGEQHklPyXzOKsoivJuzIZAHAmCVMQbCdvQTjAJxziautCNgojoLoYesqOKqJDnSMAIQVTPaxuXaGvyFAmymtotkmViMboybFo");
    bool KjfEKBdqTcKQKtH = false;
    bool avPrFQTuixegDRAx = true;
    int JBNQawwyk = 1245372792;
    bool UdgYntgKTSD = false;

    if (uSlorkBV <= 1412340816) {
        for (int ndhpX = 1742310016; ndhpX > 0; ndhpX--) {
            continue;
        }
    }

    return JBNQawwyk;
}

double sogtpffHEuLGG::lkptCrpmHbFtA(bool aCnYOXuLuJCoXS, int jAqlQ, int JnxFBAhcFY)
{
    bool sBNYiL = false;
    double jNMtByyFLETKMu = 646260.320768204;
    bool TKnDmccZL = true;
    double nNmmDPjVUdhD = 305370.2704041787;
    int IsfHSsPmaRYUSRap = -1984646804;
    string BkrlYzPw = string("zugbpgsKSKFgjNYKACXmYeBrHBHYywKOGnEAKMHGibyQgtpHnjOkVohtmTuLPmOiLISJlhNAyJdQUFoOZffkJtiCsrgEwMnvsvkbiFzpwBntSsjyQvnZHDUQeZhwTEwUvFwnaryrm");
    double yeUxGaVsA = -739901.1034174107;
    double mmpiZYaYTT = -175470.19663975656;
    string ekWtnhmeNGF = string("NYtlUDtTOHaVWAMeMMSNFppJwQHglWBLGBJsdSMusnXgVznDskAnciIzHdhuhRbybJzKPyagXhxBjVsBLMWrNYXIXskLaqIYFpZVfpAVsrdCgBkkGvHR");
    int otedf = -379553823;

    for (int bpfOl = 1914645208; bpfOl > 0; bpfOl--) {
        continue;
    }

    for (int DMwTJuoH = 869193027; DMwTJuoH > 0; DMwTJuoH--) {
        otedf /= otedf;
    }

    for (int oWenMbAAyZVja = 1107272285; oWenMbAAyZVja > 0; oWenMbAAyZVja--) {
        BkrlYzPw += ekWtnhmeNGF;
        otedf /= otedf;
    }

    if (jAqlQ <= -458096583) {
        for (int deSKLdA = 181020349; deSKLdA > 0; deSKLdA--) {
            continue;
        }
    }

    return mmpiZYaYTT;
}

void sogtpffHEuLGG::yhbEjWaRuKHwx(bool gzpUhKtDMci, bool TWkPrBBugEBEDWs, bool EfweM, double uYUOlegLPi, string oTfBXpaDPkJKVeGQ)
{
    int UNclI = -1011778638;
    double fPEKDlVmuhQrGbBM = -113757.14096178501;
    string omrQIT = string("bMTFKCJpcREJHdJDWhUCCwJDkGRCuEWsCwQBLUzZBQZnyQYSlTwAJKgQPbiMAZlameZdcvqwfmTEGlODthVinmFlQeMrYiDoxRpyziQZTb");
    string FYxCe = string("rflpMfnPzuLfvfNpVHjdpNpUqIUwNdERwbMfJOQxRJPsFNaCtuwbWRjaHzzyQSFomQokBDkxuhrYw");
    double clkzIXaJIWUALnN = 93800.91280579724;
    bool HVndjvvX = true;
    string sGNrOSUeIQucULDj = string("GGdXVkALQpvQAzEwrimndWWJrckHdYgwaXeKCNMTBjiFFVCSJPciKhmEwvoGrHiOlzzlgiDpkstnNStCroZwRguzbmyoRjORKYCoZZZGFHgzbJiEpfhUxWsQ");
    double xlFXUWEAkn = 884279.856749656;
    int UodBMuTSTDkVo = 1805016866;

    for (int UZFSkWjQhVRrpHdC = 2090668374; UZFSkWjQhVRrpHdC > 0; UZFSkWjQhVRrpHdC--) {
        continue;
    }

    for (int uqnFRqEtcv = 1210788921; uqnFRqEtcv > 0; uqnFRqEtcv--) {
        clkzIXaJIWUALnN *= xlFXUWEAkn;
        gzpUhKtDMci = TWkPrBBugEBEDWs;
    }
}

string sogtpffHEuLGG::jvEGb(bool wugySBBVkdXBH, double JalkITlgDgb, string cGGCuEcHZYU, int XPGBELq, double MJKpHqMIMSxyByWF)
{
    int znVEZLLRRwLVKHP = 277651071;
    double ctvKGH = -72972.75327676433;

    for (int WhMlMnJZsdq = 1721821437; WhMlMnJZsdq > 0; WhMlMnJZsdq--) {
        ctvKGH *= MJKpHqMIMSxyByWF;
        JalkITlgDgb -= JalkITlgDgb;
        cGGCuEcHZYU += cGGCuEcHZYU;
    }

    for (int JRMEgdjsEzmGsyA = 1476520107; JRMEgdjsEzmGsyA > 0; JRMEgdjsEzmGsyA--) {
        wugySBBVkdXBH = ! wugySBBVkdXBH;
        JalkITlgDgb = ctvKGH;
        ctvKGH = ctvKGH;
    }

    for (int plBufsFNEXKZh = 1529424979; plBufsFNEXKZh > 0; plBufsFNEXKZh--) {
        MJKpHqMIMSxyByWF = ctvKGH;
    }

    for (int vNcbUEXow = 1339621762; vNcbUEXow > 0; vNcbUEXow--) {
        continue;
    }

    return cGGCuEcHZYU;
}

double sogtpffHEuLGG::lrMxxKeoTPQJd()
{
    string uNuggkzpcG = string("GOEXtdpZdoGzSFNnKndoZYPocDGtAyGMWjiXcI");
    bool vpqoCiNSuWo = true;
    int RRfaijNIgQOW = 463972033;
    string BXVKwCMrP = string("IzapXpNjfYyOOLTEPJATiJKIGMkwlWbhpVLjTVbtFZvEKMJtLzEAmGyqklJp");
    string HxcXPEPEzNqCUK = string("cPdRKDYQifpGVxnLnkoxDmnkBmHQgQFXbgOqwFAsBLSecBXdiHliITXscHBHQeGFvJqRPtwTHZmNQFMmmXhFQKvGqHsfjmorPcBGkXMGYPXjNMGKKXuMTsUdfMstDDmcVdbqxzSOXUlbQParBIloPARjVqQPuCjGMbhhbMfSsMuxTzSvADWxgyjfgShWUiOkpLzIocxXWKsJOiQGyBsGNwdQGXLLsyDIWFlnZmiKWlUpexhboCQAbonxX");
    string fcrvYRjkSvKMMd = string("PxXyjgrzyJZeCvtzoIDmtykctuwlLZRLCSCqMDXgeTAyxQKgFlrzejvDXNAZWxppReDvyPCalHVtsFwRIuqrcxNAnvmOkqtOVnITbGQMPpWjIPlhSiPfLjxxNNbFzWtMDbBvDqElKhmhfDXCjgmtBMEFxNRkihrfYbOMUAcgJCvVSHcMyKEZglDXuqwNuzwOacefBUGVHTuYI");
    int NUoHNBCD = -1424965690;
    int NCrBJcOjZA = -183545704;

    for (int RwrQbkHuOwYYfZWm = 1206157558; RwrQbkHuOwYYfZWm > 0; RwrQbkHuOwYYfZWm--) {
        RRfaijNIgQOW += NUoHNBCD;
        uNuggkzpcG = BXVKwCMrP;
    }

    for (int uRTbTqxVWg = 2017170724; uRTbTqxVWg > 0; uRTbTqxVWg--) {
        continue;
    }

    for (int uUjCDnznDbKWqM = 1013404832; uUjCDnznDbKWqM > 0; uUjCDnznDbKWqM--) {
        NUoHNBCD /= NCrBJcOjZA;
        BXVKwCMrP = BXVKwCMrP;
        BXVKwCMrP += BXVKwCMrP;
    }

    return 995227.0398815667;
}

bool sogtpffHEuLGG::AFnYGegcLZdXte()
{
    string tNTXAOFza = string("UlWgXAyscwBFhGJxmByvZuVCnZYfjzZZkuwcyybbwoXzfyTTvmiflbmGRRzbokJJMqgYlKAIgjNkJpjwDnalnCjAPnhBxRPlwnhkrNbBCeKTgiWOdxHmXmMIrkBVcuTnoZKwRpjADOZnGBcAhDSHuwkbJFNjGjYFSBvnO");
    double SshJuOynKj = -192791.44432888253;
    double vkPWUmBz = -881963.6121442295;
    string xLfnKw = string("awEacfVYfWIiIQCpePwbEnDGjYmjdTBrptgDdGZoaSSYJO");
    string SXKLJK = string("sUmIstknWhMgIUQhBhrfmtZRLakovhWjKOZmNYIWNtwQEVvBiwiEuaIztUuuYeueAHduQTozAETShvQBHXcSJInsUQWpoaHvxgzJFKDKcpHAHLRiYGbhZTOfkyirFEvYhAakLUzcKemhDoEEdkxzVu");
    int iaHzgqZA = -1649420910;
    int StCACHD = -1415503282;

    return true;
}

double sogtpffHEuLGG::orJSjneokLZfsY()
{
    bool eKeJXRtwUEss = true;

    if (eKeJXRtwUEss != true) {
        for (int vYXCOTJceRhSSaD = 719218682; vYXCOTJceRhSSaD > 0; vYXCOTJceRhSSaD--) {
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
        }
    }

    if (eKeJXRtwUEss == true) {
        for (int xbCtbxeDfXMW = 460171253; xbCtbxeDfXMW > 0; xbCtbxeDfXMW--) {
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
        }
    }

    if (eKeJXRtwUEss == true) {
        for (int URvbKPsCjJEFC = 304001896; URvbKPsCjJEFC > 0; URvbKPsCjJEFC--) {
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
        }
    }

    if (eKeJXRtwUEss == true) {
        for (int zlljzVfYZjdJJ = 1951617941; zlljzVfYZjdJJ > 0; zlljzVfYZjdJJ--) {
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
        }
    }

    if (eKeJXRtwUEss == true) {
        for (int VUsTsTS = 1760706150; VUsTsTS > 0; VUsTsTS--) {
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = ! eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
            eKeJXRtwUEss = eKeJXRtwUEss;
        }
    }

    return -184934.64903739427;
}

double sogtpffHEuLGG::vuPvfnAgFqjle(bool WNjbKh, bool rmjXDxjlVvIm, string JigUVRUWqsGvO, bool COSAkP)
{
    int ReQlexfHUNEdP = 667252829;
    bool YZdShOUXKRgGYHs = false;
    int sSNTqcb = -205298178;
    int SbATa = 1762599057;
    string PVmHFoJoHS = string("gMTGjrGAGIMeZORimgalpUlHakaXFvxUkEaVvOtSwUqMSPYVmyc");

    for (int kElrBVYM = 1478785683; kElrBVYM > 0; kElrBVYM--) {
        sSNTqcb -= sSNTqcb;
        sSNTqcb -= sSNTqcb;
        JigUVRUWqsGvO = PVmHFoJoHS;
    }

    for (int dPHhEHLGR = 1728324438; dPHhEHLGR > 0; dPHhEHLGR--) {
        continue;
    }

    return 242624.31931500757;
}

string sogtpffHEuLGG::DKoxy(bool LwdBhjepF, string tmADiJRlK, string PgcQG)
{
    string bRtBLxibPJzqYT = string("BeismSkxJWYQScObruhzrTBVojOFOMCRJbGZyifAYDkAtoMUbfEikUPXpBDqwEXFMAGasxrzMDXBbPTJzGaNXdUrpohOSZJeRlGhpCuwARFokoJzibumFZnopCnnrnndQqCoQbezdMaFxsXuoBOzABNLiPRdXiNixTpLJvqmZNnwBKQHlroOBtkXbnzmSnaWzDPVXBImP");
    bool ugytOqQsg = true;
    string ejOxIeMwUn = string("MfqIbMJpcQaqmcblGSMUNKmbDLAvbPdBigVrXOITOkJHDUjcPDAxaiEWxSwRPKILHPWCsrsXLEEOVErMEzLlFwNsrFAstMwXQaWrhBVugYCpxMlMl");
    double WLAHlaKbeiTke = -625096.2180016569;
    double nltUhy = 129437.62986137322;
    bool RgQQxu = false;
    bool XgewJOPUftCPoCZ = false;
    double hByUISJKInHcz = 118308.11753517037;
    double hkyDTdWhE = 137645.28682040496;

    return ejOxIeMwUn;
}

sogtpffHEuLGG::sogtpffHEuLGG()
{
    this->qYJVWURl(false);
    this->VPwKrNJLwPruQHu(string("qiqcgxoiCWKmdlsvuRQkmTyPWRkiQVImjvsqqAYcLZsmECZLJwpMEvQSwLEqCJDvMiPDpQCZphNxmhaDACK"), string("BqhLVLYYVoVveKnYggreFRYKiOVTivHVIYGNChaSfFKWkggsElFSsJHmJdHtzQzCLrETlwdlufaYXOcvQFEXDyuVklxQYzcfGrHgOAKtdBRkceAbYWBYsnMnqewwCpJWGPzFBVXtbSCdDyVSrphVtHrvTppyrwoxuWUbqIfbLCWjxNqTaaogLXKFahElxLZgiTRnwlnzzGuArJyOMCQvwojGxl"));
    this->YqLEMWWOWRRLi(false, string("jwlRYBWWaCVOYxGIlGplrpVziyZbOLRkwFqFEthpuCIy"), -503751.36115942);
    this->PMXvEKcGMb(true, -994381688);
    this->oLEsyNAVbND(string("svdNiHUcvyFHbZRLvRckaSCZYQEkdtXFFitWgOqyBzOoXRnbxIimXqdzNklMQJHZKoCNfVwZFkIyffLgmKtIFNmQGYYQVpWwEzAjPnRdMZosWKTuwdUP"), -996738.6270739115, string("fsxeNIcSgHgASSuytvLDDFUEUzcCCXLnmvivzbqKQOdIdCdgxEVuSsINFJLxIIpAD"));
    this->eXHmIiuqPCY(-512958.31853845017, -1616732700, 867196716, 1611197134, 795323.4706870014);
    this->JiLLNmy(-2076121234, 637935545);
    this->XkzeTgVcpNEWnZjX();
    this->lkptCrpmHbFtA(false, -458096583, 650355281);
    this->yhbEjWaRuKHwx(false, false, false, -896751.2534219682, string("WtDqZSmJRjkTvGDwLBaEMLudmbLUtmufgEmZEhtkyEJWbLPUMCEorXozJOBPIuGBegATotXvMcWgoLPTmGMWRAwUpnjGfMhTwBZgVLzSAHTUippiEQgzD"));
    this->jvEGb(false, -775328.5591279013, string("gTjrXdwCojhrHpZgGJsMtFsrojjxKEJEtdilbryJlqyKNlTYYOtZVCuUGxHOpRxVdhNHTbXxcgTCokMNEKiAxiJrVjOpYDffEksEzgjYPsDbQzzfgfEtTysoVyXBZwicnvblraVsgyQQkfZkNMKfUVMLIbjXCXjJSYxbnOayUeYaTJixmfhcoHutWstPRAikDulZRlMKcdCH"), 712254000, -57131.394408309876);
    this->lrMxxKeoTPQJd();
    this->AFnYGegcLZdXte();
    this->orJSjneokLZfsY();
    this->vuPvfnAgFqjle(false, true, string("BDseLBUcbqGQtOUfzlNExnaDWdTiRWzCnywbHOyfDPAotxcAglLPzuNuCvSDKevKDtClZOvujHtmUhgjCpPvPBxeTrXMKTpZyDugFdJLAeExEkOVQSYZWYKVibIomHmmUZRtsPlgOQZQaHgGU"), false);
    this->DKoxy(false, string("RuGcAKnQTaivfZfhEKsJPRfAlWJgLDHDNpAUCvFHGQGqBaQbECpNpKqtGZHZcqxOEsQpHnigWVYuZHXOFONoFowgFlDLNNLpGAAQHWqqoXLvMrvtKjiUvDRCqPNVKvfoqSOsWpHMbCBEMitROMDaYBmPpxdqSXNRAciaqipytKcYjJgrjzfTPQujQArsPmJDjjesmQdDvC"), string("roFwjJVsOPnSJURliZFAFwuRLpVZTUPQhxsewfGLtaqjriBZuubGqjrFrXwTjYTnAjURXYLasMXeFRJOfaJhNiJuEjXwyYOrdtUahysMviZBmHjMGdkaiCQHvtedrNEhvIGhirLBqIxogGmRCOqtqfYFmAoRgnzyASeeTgeRzRQStZqv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hoJUbRUHDSD
{
public:
    bool YDYPHLUKOTw;

    hoJUbRUHDSD();
    double ZRUQN();
    string YrPrcrxpXrFXVa(int JAprZLgqJlThvZ, string HxwomJJBjxV, bool XngabbSKwdCEfmVs, bool HYryIuR, bool WtSzkkBhQD);
protected:
    int knLvRCiajEhiYWbe;
    string SWefJNEAsFk;
    double fnVndlc;
    double CEOqfIGdDFIyE;
    double PsGtzwhRINOCAvDI;
    string kGwxm;

    bool TaNMEubhNQiCk(bool zhyhmhgWy);
    bool WGapbgqE(int wtUQDNmucnpK, double iqDtGcuRDni);
    void MFWUka(string mApzqYyIVUoe, double zmlznmdE, double tZmCE, int CPVymE, double Pchah);
    void PVusIsDVqmXz(string eQDpQVXxIOgLfL);
private:
    int sHrMxswYeu;
    bool AgqHmmWC;
    int AZUdOBeBirxBXw;
    bool STCXnac;
    string uYJZIOF;

    void ZpvuROKW(string FemjPHmMXO);
    void EWDuIqTnMUgvH(string weRAhEusgKzcD, bool HpVNGPZIMdB);
    void yntRQzD(string ETVqhZo, string aLfpUHVzqOKKGG, bool CnJjRIeHUnMnYAy, bool wWwYoWGcswc);
    int xRrwqenVCnSqntv(double nIwhFyBK, string kjBDhFZlgx);
    bool neRBCUamDR(double zpNWx, double hDmHr, double cIZIZliJEb, double MSgndfPzjBBGFSaF);
    int CPSUgDRMvTCrfFq(string LWwPxl);
};

double hoJUbRUHDSD::ZRUQN()
{
    double uOdzQpFbAnmjqA = 46422.350235905426;
    bool iauwkrzWCp = false;
    double TjWXNBq = 341645.82458683243;
    double eeTtnPm = 668789.7026736086;
    string TFfwwdP = string("GoV");
    string VdFXN = string("fgmVaZtbhWTNVVaFebvHzzbCrkpRysIldBEkSBsNjobIBEeucKznkPwjXCwkfnxBYgyAjJJtVsSOItfUVGfdbWzHjJrJqXfNMSiJaToxfqjbmogbUGTVenM");
    string VuWMgeqEErcUtMC = string("NRN");
    int qtkMiYgmo = 2067312639;

    for (int XmBmxsGRl = 1006618795; XmBmxsGRl > 0; XmBmxsGRl--) {
        uOdzQpFbAnmjqA -= eeTtnPm;
        TFfwwdP = VdFXN;
    }

    for (int lOOkqhU = 120684593; lOOkqhU > 0; lOOkqhU--) {
        continue;
    }

    return eeTtnPm;
}

string hoJUbRUHDSD::YrPrcrxpXrFXVa(int JAprZLgqJlThvZ, string HxwomJJBjxV, bool XngabbSKwdCEfmVs, bool HYryIuR, bool WtSzkkBhQD)
{
    string yFsAdASMvIPo = string("zcGYFNGOaCkRZRqPSzCSnwQmLIqpHVsxvYZFyNNOGOWfgRCHYANzJPUwpUvBOHugXXUyFffNNIXvUASdMplJAtEDIOKnpvNrlidENfsBOnKQihyMYAlsRNYn");
    int sNuyovjCHKHiaq = 408889058;
    double tpqPVjQl = 710310.2615902646;
    bool salEudlZnOVvoL = false;
    string xtHdyYQsbMawQ = string("pdLSJKizuGkoCawYqWXbcFJHvzJslbYuoMhFSOAgogoDXsOqEWTeyUUtgRWUyEPmQNZODVlmcUpyoWiUyEieIYxtdqGUQYcdZlIOPTgspixgUETKwfHUkDkHkrspsEFVCzsFkZSCyAMoheXWKMqGufbZkRirZnuXAfqyaHvESBZyPTfZZIVpGrjEwgbYqvvhkklAkqumhc");
    bool SPdjMnfRHtQ = false;
    int AWhAG = -2035631651;
    bool ctmOGRCVudgmyGhd = false;

    for (int alNKHnZDIUq = 1271458278; alNKHnZDIUq > 0; alNKHnZDIUq--) {
        SPdjMnfRHtQ = SPdjMnfRHtQ;
        JAprZLgqJlThvZ = JAprZLgqJlThvZ;
        xtHdyYQsbMawQ = HxwomJJBjxV;
        SPdjMnfRHtQ = ! WtSzkkBhQD;
    }

    for (int CQuxXDB = 362637958; CQuxXDB > 0; CQuxXDB--) {
        JAprZLgqJlThvZ *= AWhAG;
    }

    return xtHdyYQsbMawQ;
}

bool hoJUbRUHDSD::TaNMEubhNQiCk(bool zhyhmhgWy)
{
    double oImVlOSIiZE = 91307.57701185062;
    double ecPNNolGAxL = 665148.5320567897;
    bool pCsAobJi = true;
    double BLneKxNYEL = 790896.0984162851;
    bool LbjzOCXhrUj = true;
    double IMzXtsUCcPdaUTu = -179403.02773971707;
    bool OsJvSIFKIY = true;
    int MdpofBtMnI = -922139531;
    double hDdQRFPOKY = 394440.54366037715;

    return OsJvSIFKIY;
}

bool hoJUbRUHDSD::WGapbgqE(int wtUQDNmucnpK, double iqDtGcuRDni)
{
    int hMfTHsvGwg = -471182859;
    bool dOTIghMDvgBwIuyD = false;
    double lIlEeUyA = 179594.0401949325;
    bool rPiJeMhbhf = false;
    int TGRIPTALwZGbHK = -828425219;

    for (int TRTJEKxZpvUgLBVO = 355651703; TRTJEKxZpvUgLBVO > 0; TRTJEKxZpvUgLBVO--) {
        hMfTHsvGwg /= hMfTHsvGwg;
        iqDtGcuRDni = iqDtGcuRDni;
        rPiJeMhbhf = ! dOTIghMDvgBwIuyD;
    }

    if (rPiJeMhbhf != false) {
        for (int tbIFLNuolb = 119587259; tbIFLNuolb > 0; tbIFLNuolb--) {
            iqDtGcuRDni /= lIlEeUyA;
            lIlEeUyA = lIlEeUyA;
            wtUQDNmucnpK /= TGRIPTALwZGbHK;
        }
    }

    return rPiJeMhbhf;
}

void hoJUbRUHDSD::MFWUka(string mApzqYyIVUoe, double zmlznmdE, double tZmCE, int CPVymE, double Pchah)
{
    double ZgikurScsqeQGwX = 53698.43991310197;
    int zigppihOaGfIZZdR = 1642631210;
    int QhxyfjXu = -827930993;
    bool pmzkdUIo = true;
    double mwgtnwRUNhmuBs = 786023.8030005075;
    int sKjAEMnQKsvceQYZ = 723185740;
    string LyQbWlPO = string("tZyjdfoNXUZZNhsXJHTBRoSRMMpiKMpjiFBBzsqUEEURGrgWIXSidARiioZtEbrrohwKIYgRiIcZQduKOBWgPvASIVuPltlTpjkFoiwjdjKGEAZIrPxkvkfyBfoLwFTZLdwTbHAjOdqRns");
    string IvGamt = string("ccYLIPjLCNVLyissTeREFrzPSStBUCabdqXGrtaDRCfYtLnVeGpIPOlwtGrcVQOhxceJgwacCjfBzyOwTKHvrTdsxH");
    bool AFBaX = false;

    for (int WlhGrtGpX = 978531294; WlhGrtGpX > 0; WlhGrtGpX--) {
        mwgtnwRUNhmuBs *= Pchah;
        Pchah /= ZgikurScsqeQGwX;
    }

    for (int ZHJPiVzWBZEUqbw = 811777005; ZHJPiVzWBZEUqbw > 0; ZHJPiVzWBZEUqbw--) {
        QhxyfjXu = zigppihOaGfIZZdR;
        pmzkdUIo = ! pmzkdUIo;
        ZgikurScsqeQGwX -= mwgtnwRUNhmuBs;
        IvGamt = mApzqYyIVUoe;
    }

    for (int bBRvlUTqCyf = 161344930; bBRvlUTqCyf > 0; bBRvlUTqCyf--) {
        ZgikurScsqeQGwX *= tZmCE;
        sKjAEMnQKsvceQYZ /= CPVymE;
    }

    for (int jIiuefumO = 807810393; jIiuefumO > 0; jIiuefumO--) {
        tZmCE = Pchah;
    }

    if (LyQbWlPO > string("tZyjdfoNXUZZNhsXJHTBRoSRMMpiKMpjiFBBzsqUEEURGrgWIXSidARiioZtEbrrohwKIYgRiIcZQduKOBWgPvASIVuPltlTpjkFoiwjdjKGEAZIrPxkvkfyBfoLwFTZLdwTbHAjOdqRns")) {
        for (int DnRzUcO = 739689189; DnRzUcO > 0; DnRzUcO--) {
            mwgtnwRUNhmuBs /= mwgtnwRUNhmuBs;
            zmlznmdE /= zmlznmdE;
            LyQbWlPO += IvGamt;
            QhxyfjXu = zigppihOaGfIZZdR;
            Pchah += tZmCE;
        }
    }
}

void hoJUbRUHDSD::PVusIsDVqmXz(string eQDpQVXxIOgLfL)
{
    int vkhGuU = 1654739074;
    string ykkAQh = string("wXEgFBmnLWKemtSHDspMFNeLDeVhkQRZXtfQDssKHqSvSfZrHPQWZwxXussdkRFgziygIPRZLxUAbxYkfVeNGfdVlGRUzhUetBZNUYfKpnJvJcOSwLbNPnymvxYqSoSwwmbUNwFDMSKfanvdCHTbtAUvlymAeFLXZHgWWCltHJrFUkcPgUsczuWcdZAwygGPgNYNSDBVkfTvhIrqbPmjpuvyIbAMeSUzXIkHJZSQUa");
    bool UJZsOV = true;
    string VygfSxBZkc = string("DjTMiBEjLplXiZopFdKyrSuAMNFwepfAaQuDvDhgOrIWmPzAaafKtXUxvugzrPGkReOtDjfwYcuxZUUdETlGEdMvNxwKfdJsUpFZZubBfLQKKCrXGtwxuEcPJylfkyNxoPNAjAbzUbOvBGoprLGj");
    string wmpSRgGpJhQpRVU = string("WAnQzzFjfuwQQRFmrIlUOmuMGZBTNJCHSWoSVEukotmmlyrbxoNivswNRnVpuutUpRNWhKRDkGmvujzhsAkKpuckRoDvWrNHTxGDSntWzuEsMOzHkcBLzUvQZUDsFuGEVZlOrSaOlSDfICybtaOktVfEpJVLwVqufhwqnQKo");
    double UyykvnEXpvCSQq = 872675.5334013236;
    string RLOtvueql = string("lDKpqpWcgWqwEkMxUSoYloarVHMpnlnJqPSdkZagLvWSfgveGdKFnpYQGlkcFJxwIXxXGC");
    int VZNGVmUjV = 1286547564;
}

void hoJUbRUHDSD::ZpvuROKW(string FemjPHmMXO)
{
    bool RXFwmF = false;
    string WPRuon = string("uexXTPHQcfcOgDUQLVrSrpDjDeiHXRewSbtacVjMpjAxDtqUxFwpGZTQkPvmECeSDpstMBKqwOEAMvdvEwXTDoMOOeIFfaWLudtljbvfFRAkniCBbabCbVhpZgAGzudwspzRiUYvhkKGpPkTQtDgQruYNqPUOMUBYtYaKQnlCgPpuyWzLcbugqsAxXnEVVFRYLJIAwdf");
    bool LdEYzsZaYDap = false;

    if (WPRuon <= string("WaJjpbxxrKbMhfqGoCVBgtDQTixaBknPoD")) {
        for (int VHMEmaLnYFl = 470579136; VHMEmaLnYFl > 0; VHMEmaLnYFl--) {
            RXFwmF = ! LdEYzsZaYDap;
        }
    }

    if (LdEYzsZaYDap == false) {
        for (int XRdRRevpgU = 1041783059; XRdRRevpgU > 0; XRdRRevpgU--) {
            WPRuon += FemjPHmMXO;
            LdEYzsZaYDap = ! RXFwmF;
            LdEYzsZaYDap = LdEYzsZaYDap;
            LdEYzsZaYDap = RXFwmF;
        }
    }

    if (LdEYzsZaYDap == false) {
        for (int PegxAafpqx = 3749160; PegxAafpqx > 0; PegxAafpqx--) {
            RXFwmF = RXFwmF;
            RXFwmF = LdEYzsZaYDap;
            RXFwmF = RXFwmF;
            LdEYzsZaYDap = ! LdEYzsZaYDap;
        }
    }

    if (FemjPHmMXO <= string("uexXTPHQcfcOgDUQLVrSrpDjDeiHXRewSbtacVjMpjAxDtqUxFwpGZTQkPvmECeSDpstMBKqwOEAMvdvEwXTDoMOOeIFfaWLudtljbvfFRAkniCBbabCbVhpZgAGzudwspzRiUYvhkKGpPkTQtDgQruYNqPUOMUBYtYaKQnlCgPpuyWzLcbugqsAxXnEVVFRYLJIAwdf")) {
        for (int tLzkjrLJh = 1663473657; tLzkjrLJh > 0; tLzkjrLJh--) {
            LdEYzsZaYDap = ! LdEYzsZaYDap;
            LdEYzsZaYDap = LdEYzsZaYDap;
            LdEYzsZaYDap = LdEYzsZaYDap;
            WPRuon = FemjPHmMXO;
            LdEYzsZaYDap = LdEYzsZaYDap;
            FemjPHmMXO += WPRuon;
        }
    }
}

void hoJUbRUHDSD::EWDuIqTnMUgvH(string weRAhEusgKzcD, bool HpVNGPZIMdB)
{
    double TRsqXhGi = -919617.8385927844;
    int vBwVIAn = 1988264351;
    double jPvfppmdfQR = 1047944.615662402;

    if (TRsqXhGi <= -919617.8385927844) {
        for (int ghuibkCw = 606067820; ghuibkCw > 0; ghuibkCw--) {
            continue;
        }
    }
}

void hoJUbRUHDSD::yntRQzD(string ETVqhZo, string aLfpUHVzqOKKGG, bool CnJjRIeHUnMnYAy, bool wWwYoWGcswc)
{
    bool miXuXDiXVkZAj = true;
    bool AZsErXxcNRT = true;
    double dtonOaisiyQDda = 845178.9045548172;
    bool pdPPJCvscfiEFBzV = true;
    double LrfnDMhiGN = 3304.6011261491394;
    int DhtOBpN = 2026594322;
    string oZtamuCEdk = string("vsUwwIJMXMIMfLIIgEUZpjrLBRymNrGBXNOtjBZLgyZEEVuRNriafpnrROSnfdtuWrQUtNdyLhmLvvlCyQZpKyVwcVWByvKMDBmdZGTLNzpLbMOhPnBUuqgsdHaVyenkgdJkFym");
    double LMlfgliDVrOaKQX = -478874.5711466781;

    if (CnJjRIeHUnMnYAy != true) {
        for (int CBHosKXj = 528434482; CBHosKXj > 0; CBHosKXj--) {
            LrfnDMhiGN *= dtonOaisiyQDda;
            miXuXDiXVkZAj = ! wWwYoWGcswc;
            LMlfgliDVrOaKQX *= LrfnDMhiGN;
        }
    }

    for (int NaqYthEb = 1525433174; NaqYthEb > 0; NaqYthEb--) {
        continue;
    }

    for (int tGLNGCfsHhRBJA = 1589847757; tGLNGCfsHhRBJA > 0; tGLNGCfsHhRBJA--) {
        CnJjRIeHUnMnYAy = ! pdPPJCvscfiEFBzV;
    }
}

int hoJUbRUHDSD::xRrwqenVCnSqntv(double nIwhFyBK, string kjBDhFZlgx)
{
    int DnNvofkjOJtqHWke = -714973888;
    int wMEhFqnfZnITCYA = 310866859;
    double ROtved = 691070.4966901294;
    double QPWSYwalXCGs = -12900.8074732766;
    string hbMksaSkpfIX = string("nIgRswfKoUGiouSRhvSuQS");
    double GVHXkaqpDs = 538048.6435104059;

    for (int DeJNEKLxzaRpDdfo = 307487857; DeJNEKLxzaRpDdfo > 0; DeJNEKLxzaRpDdfo--) {
        DnNvofkjOJtqHWke /= DnNvofkjOJtqHWke;
        GVHXkaqpDs /= nIwhFyBK;
        ROtved += GVHXkaqpDs;
    }

    return wMEhFqnfZnITCYA;
}

bool hoJUbRUHDSD::neRBCUamDR(double zpNWx, double hDmHr, double cIZIZliJEb, double MSgndfPzjBBGFSaF)
{
    int pJPXUTPW = -1268551834;
    bool VKFaEqJhwm = true;
    int WjKmZtPGLXg = -1162019418;
    bool FDlsANV = true;

    for (int EqrDi = 242795514; EqrDi > 0; EqrDi--) {
        MSgndfPzjBBGFSaF = cIZIZliJEb;
        cIZIZliJEb *= zpNWx;
    }

    for (int ddtRiiEfKcOvsHGA = 1451263309; ddtRiiEfKcOvsHGA > 0; ddtRiiEfKcOvsHGA--) {
        MSgndfPzjBBGFSaF -= hDmHr;
    }

    for (int LSECPUR = 1192672039; LSECPUR > 0; LSECPUR--) {
        MSgndfPzjBBGFSaF += hDmHr;
    }

    for (int XlVLGfNE = 996960287; XlVLGfNE > 0; XlVLGfNE--) {
        VKFaEqJhwm = ! FDlsANV;
    }

    return FDlsANV;
}

int hoJUbRUHDSD::CPSUgDRMvTCrfFq(string LWwPxl)
{
    bool YCSQpqiaKDOej = false;
    string lfQsFJbnyXx = string("SqMkZdRgoqmiEfNAboEBemokzqIyeNmChBFgyNUghyvgnczdPrmAVQeaJftgAZuMDLQvjwepvnrMtUHWnwkzLCCKETOxOoRWsS");
    string lyZAJ = string("YeymDBnPYJfMEUUlIIzqLqiIzhiChihrKSIAVHIyZCSGveHXfVPhGghyTtBRqFAEZRYNOYcuzFAaRimjgUJOeuQFsgtBKnVZpZKdFnPYgBorEWSVjqCMjLxRTBVfRwlQtIUqSfuzjsasQeDXJJoDiieQcBpRRwIwfTNTPavAsrjqYERWcAyHyRNQrvujKdZbabYJvNAVhTkCgkCzLUbt");
    int hLrJvPHzeFGK = 1682970034;
    int TXSqeJuAustRyn = -1031535818;

    if (hLrJvPHzeFGK <= 1682970034) {
        for (int FCtbMKmtwUgxL = 1940372680; FCtbMKmtwUgxL > 0; FCtbMKmtwUgxL--) {
            hLrJvPHzeFGK = TXSqeJuAustRyn;
        }
    }

    return TXSqeJuAustRyn;
}

hoJUbRUHDSD::hoJUbRUHDSD()
{
    this->ZRUQN();
    this->YrPrcrxpXrFXVa(962028987, string("xIFHYUjgbZLzZKWDVxYaJXSrEmhElkYqYwTnrJcYvsWktgQdlpOKiEcNEstMFDqHdetAulGPELggvBxniufclxhFiZmmxKWwbayFNShovdWctPLEAQhciAOKMkCsJDVpuxBE"), false, false, false);
    this->TaNMEubhNQiCk(false);
    this->WGapbgqE(1002554806, 404330.2440310718);
    this->MFWUka(string("KeNUXbjLKMjOMmdEKWXjpVxghcIdpVftRXJFmdCQfjIaZ"), 789312.5481575663, -1015604.724381505, -1123452285, 488956.44346314);
    this->PVusIsDVqmXz(string("CNKKdufiKigdAZalqtrNlDQGSAuKRFtKSNXkSlQXjpQvjAaxeNxNdgRqXBXZzSmlBaWpDuVkFxLqihzClltlMlJMhGNExlOvzNvUnPCwVWJDZZoIQqLJTzjMVBvurcsjvayJnrTAjotEYnyWpmrZ"));
    this->ZpvuROKW(string("WaJjpbxxrKbMhfqGoCVBgtDQTixaBknPoD"));
    this->EWDuIqTnMUgvH(string("aXNifNkVjpcaqwEpTGrp"), false);
    this->yntRQzD(string("CYdqnZYYwgBtUzExnmnmAWwJLUfuhLrJUdcVqaBhtYNmjSYVLjFUhEHQBw"), string("dfZrEHdLQzfwtRzTnzFmnYjZrBKaigRyQXGlUv"), false, false);
    this->xRrwqenVCnSqntv(419381.56279966154, string("irsdmFyBmTuHoVOflyRlOSNPBVYfaeWEmCWunXjYVogNVaGMsyacPMTtfWtvELaMWVLtewGgoswIyFHPDfqX"));
    this->neRBCUamDR(873886.4773933436, 558140.697717309, -688094.4300157434, -721767.9400213078);
    this->CPSUgDRMvTCrfFq(string("ibFsEDnelKseEKixxdJyGaIBIutTvzTULCiIFtKscciOOijtnMIcDKbmKwLvVUhXmPwIwGjDZYPSsyUTKBQgBqLAtLPobdhtdQTHuUtdYjyeyzkABfLYdbrLrxBVmWTTEuYBhLEEMwKPHHbvDtDlksGXPwbjGdFdGGVTFcpZT"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bXdHDIxwu
{
public:
    double sHTPEZkEjohIiMb;
    int hTFSQouzrtAsm;
    double nDkBozTJjnZqwpRi;
    double AOppTIfkvyT;
    int nMdoYNFf;
    int cNfACSfpkAEI;

    bXdHDIxwu();
    int PvvytKvylBO();
protected:
    double CecTGGwTX;
    int lCRFHCdUgFikNf;
    string zwEHDKSPhMjRt;
    bool JzskHNSnNET;
    double VaBsYdQhokUFJu;

    void txgUzvCen(bool dHRRDxlFY, bool MYnZV, string mdDpHBtkKVOtqY, double CrFcARsEMBEOQwb);
private:
    int RQyOltNZnxAKYkJ;
    int rVUWKwiCT;
    double HFEJOUotF;
    bool cyoIqKnUHhMrSGg;

    string skBJFaqoWXzQB(double yHcgJVAKjyu, bool ZFhYEciqoFhB, double EAxoBfFWDrnU, string OyNPTRD);
    double rFaRpTITIKhWBjv(string pSgqaZhjsLQae);
    int YGnHsvEd(bool kKvXHillgIzV, double CyXNIt, int lEryTp, bool pEJQtqDgxDxXEUAk);
    double TNhPclv(string DRUeFHconkTH);
    double yJTTtDz(int JrzsriKSUvtbPCG, double PtBEIKpJQNQwywm, double lNxWEikNCkvyq, bool IOQVV);
    string UqmOl();
    void xwMquskjXexey(double MxMWkIEKYzmFpGHs);
    double RrpPBRJPDUZ(string ltnbBCTmZt);
};

int bXdHDIxwu::PvvytKvylBO()
{
    double cQIBfEixiZw = 856358.3647402012;
    double ecIMvUYbaByzoWcX = 742516.8252594374;
    double PkoAK = -26932.720388893496;
    bool AoGHwjAHFIXVfneI = false;
    double JFRdN = 490656.32965200034;
    string SibSIlIerPRTY = string("IaGJJWLIPzDCMDbyioWKxFeNzWWhwElKikJhnhtkmopsflfAetyzVncgbBToHPtLNMWbmREWglHLBAlcTsYdIyjGOKSpYLMvQVMicfvcztSTGCxCEtYYQLaCXkAQfaIolqxWzZXXKaGDTfCDAQnRzBTpMyhchFgvOYLiaIfxRzzVkqhmtUrTPZteZvNKLflDoserBHeuvIvzgfITDVDVRBqHsTTfMyUBPDoeKVPQxmOVtYSVH");

    for (int cHaYnTruwZW = 749434580; cHaYnTruwZW > 0; cHaYnTruwZW--) {
        SibSIlIerPRTY += SibSIlIerPRTY;
        PkoAK *= PkoAK;
        ecIMvUYbaByzoWcX /= ecIMvUYbaByzoWcX;
    }

    if (PkoAK == 856358.3647402012) {
        for (int PAQXqpftEsBhSC = 13268050; PAQXqpftEsBhSC > 0; PAQXqpftEsBhSC--) {
            ecIMvUYbaByzoWcX *= ecIMvUYbaByzoWcX;
            ecIMvUYbaByzoWcX /= ecIMvUYbaByzoWcX;
        }
    }

    for (int XCLCXfzCtoGQNKK = 1523118971; XCLCXfzCtoGQNKK > 0; XCLCXfzCtoGQNKK--) {
        cQIBfEixiZw /= JFRdN;
        JFRdN *= cQIBfEixiZw;
        ecIMvUYbaByzoWcX += ecIMvUYbaByzoWcX;
    }

    return -1567311537;
}

void bXdHDIxwu::txgUzvCen(bool dHRRDxlFY, bool MYnZV, string mdDpHBtkKVOtqY, double CrFcARsEMBEOQwb)
{
    double eZEtaLQMDdTnZ = -842806.0979173935;
    double GrGIkF = 888721.3393375744;
    int QzZzNZHJiHDlAI = -162850659;
    double ZiYWUNIyYUvqLvW = 879948.9049400714;
    double thjRirLY = 127945.93106176764;

    for (int AvbDWaJ = 942966961; AvbDWaJ > 0; AvbDWaJ--) {
        dHRRDxlFY = ! MYnZV;
        CrFcARsEMBEOQwb = CrFcARsEMBEOQwb;
        CrFcARsEMBEOQwb -= CrFcARsEMBEOQwb;
        MYnZV = dHRRDxlFY;
    }

    if (CrFcARsEMBEOQwb <= -842806.0979173935) {
        for (int lkqxaSiydg = 427299924; lkqxaSiydg > 0; lkqxaSiydg--) {
            eZEtaLQMDdTnZ /= eZEtaLQMDdTnZ;
            dHRRDxlFY = ! MYnZV;
            CrFcARsEMBEOQwb *= CrFcARsEMBEOQwb;
        }
    }
}

string bXdHDIxwu::skBJFaqoWXzQB(double yHcgJVAKjyu, bool ZFhYEciqoFhB, double EAxoBfFWDrnU, string OyNPTRD)
{
    bool cwBtcULJJrMvsg = true;
    double mHpbsLjKeYAZ = -353104.8869265543;
    double XxmwUnXVvDReoarZ = -237315.16370027888;
    bool mPKgfgSUI = false;

    if (cwBtcULJJrMvsg == true) {
        for (int LRGUpvRu = 497397930; LRGUpvRu > 0; LRGUpvRu--) {
            mHpbsLjKeYAZ += yHcgJVAKjyu;
            ZFhYEciqoFhB = ! ZFhYEciqoFhB;
        }
    }

    return OyNPTRD;
}

double bXdHDIxwu::rFaRpTITIKhWBjv(string pSgqaZhjsLQae)
{
    double brnCVGoLskjdI = 455604.8593154175;
    string ILhIadcpx = string("ujfRjJTtjHEuDeWeSknEJHTMhxjb");
    double mTVtuAuvd = 716615.6313605313;
    bool ETEeBse = true;
    string EKBjSi = string("bSEGVQxoCFqVYeHXmWpyfXnaqmdhCUZfkLRDIEQzohXLtZLFBackJbowmSNweTyo");
    bool BSNDCEaRBFMTQ = true;
    string NQWTStquvDYpxK = string("ZkWFCkGHYOFEogToTZNREDOEOIExjqtNNXVqNfThsfniuldPngFSNKfPcvcqKFmteVLHLGYECYmCNVAfcKGDNuonDowUBSoUwPmXFLKRcQcHsMdNGbdeZryGgtOZfALDqgFJhofhVtzjFbTQQtZEIycxOhVkLDuednZtcxAsXpxKzXUNEtLvqZCiCiVbIDmnekMBfFGFglEoNzcKOhdw");
    double XugMjsQ = 1016415.7112922857;

    for (int WZtsgeqSD = 435238192; WZtsgeqSD > 0; WZtsgeqSD--) {
        NQWTStquvDYpxK = ILhIadcpx;
    }

    return XugMjsQ;
}

int bXdHDIxwu::YGnHsvEd(bool kKvXHillgIzV, double CyXNIt, int lEryTp, bool pEJQtqDgxDxXEUAk)
{
    bool zuVSRjcqbBaNop = true;

    for (int uOwzhGkeU = 1646950057; uOwzhGkeU > 0; uOwzhGkeU--) {
        zuVSRjcqbBaNop = ! zuVSRjcqbBaNop;
        zuVSRjcqbBaNop = ! kKvXHillgIzV;
    }

    return lEryTp;
}

double bXdHDIxwu::TNhPclv(string DRUeFHconkTH)
{
    string xPChFPhDhXT = string("YgkpejLGpcvWjkoUgEFLetCoQbYFjFCyKnAQsgARREFsFtWUPKTJcmqyznqZnkAzCMnuKKutGDsQgfDqUgOOyDvzcdinkjQLywhAejPDrQcvDeAPMkHDDBQBQwDJWzusIxQesNjykXfPPpcLDQBtIakKHNexCAAOCNmGdEaPrkKRUF");
    double KCciwwHHv = 48619.70108399812;
    bool GiscixWxEyNq = true;
    double qEVfYGBGLoaJFDZO = -496483.37070477195;

    for (int mcArTMJU = 382261466; mcArTMJU > 0; mcArTMJU--) {
        xPChFPhDhXT += DRUeFHconkTH;
        qEVfYGBGLoaJFDZO /= KCciwwHHv;
        KCciwwHHv = qEVfYGBGLoaJFDZO;
        KCciwwHHv += KCciwwHHv;
    }

    return qEVfYGBGLoaJFDZO;
}

double bXdHDIxwu::yJTTtDz(int JrzsriKSUvtbPCG, double PtBEIKpJQNQwywm, double lNxWEikNCkvyq, bool IOQVV)
{
    string mHLXnwbkYAa = string("zEniBHpQUiSYPHaVEoyVQkSYsKMVtiJheQAwhLJaAsNIbDzLXQLlUZUMpNsrpgPgbjFqgrrkFrIwyJoUjJqukjsQMCMkcIOnwcCAQnTXHSBVGrwVhPTllYXPUgmOruWIvyLb");
    int FfQnCckpff = -1032894489;
    double IONFbRBqzf = -898847.3153824409;
    string FVtEEOCFvUje = string("SXLjZFVfCPqYLijEnvYzLLWAMLZPWfDNxYHALqphcRZnTyHVegslUpHwmiPDZHGsxvelEiLFsEOnNeUKnGjBbkzHgDkrPFWWJXhaDGSiIONYNdsqaQOdc");

    for (int xRbgHcIJSHyVoMWf = 1227171960; xRbgHcIJSHyVoMWf > 0; xRbgHcIJSHyVoMWf--) {
        JrzsriKSUvtbPCG *= FfQnCckpff;
        IONFbRBqzf -= lNxWEikNCkvyq;
        IONFbRBqzf += PtBEIKpJQNQwywm;
        JrzsriKSUvtbPCG -= JrzsriKSUvtbPCG;
    }

    return IONFbRBqzf;
}

string bXdHDIxwu::UqmOl()
{
    bool cVNLytmDKgElhT = false;
    double cdUHM = -789906.6947007894;
    double rXFwuIHTn = 629556.102427045;

    for (int ditPsRFFHrNM = 755391681; ditPsRFFHrNM > 0; ditPsRFFHrNM--) {
        cdUHM /= cdUHM;
        rXFwuIHTn = cdUHM;
        cVNLytmDKgElhT = ! cVNLytmDKgElhT;
        cdUHM = rXFwuIHTn;
        cVNLytmDKgElhT = cVNLytmDKgElhT;
    }

    return string("yqdGcdWCIYfsmWBCwykhpsYXyhGUYJSWpAx");
}

void bXdHDIxwu::xwMquskjXexey(double MxMWkIEKYzmFpGHs)
{
    bool gJCSwCPFRmUMfmEC = false;
    double zsFkaWa = 490492.83381587715;
    string rqvVr = string("JThnGOnfBcJlyEPFtfAhhTSulrACmHuQwNwLVrFSljqKQQqRfwZLPxIFXPIaLMgZtSWdkivmUGjDhxMpYtbhCvTVcXtNUGocMHoAJEiNcAtWdKviFnK");
    bool hpQpVcD = true;
    int rKbKDW = 807328307;
    double DuMgutY = -747970.1002329447;
    int mYHAlhTeWgDmU = -1400922327;
    string rEuZR = string("baLfIpcBqpeWHRwvIbPxfcrKpoPwMygZloVvudpogXpEsUddAPVbgiwBhvDmIEIrSUCooSGhKztsXvoNFoWsYLnXVVxYEbtIYvfbLAEhpNkwcFYfwSkzrigIejVmfnAiSNOjr");
    int CuMdu = -904352292;

    if (rEuZR < string("baLfIpcBqpeWHRwvIbPxfcrKpoPwMygZloVvudpogXpEsUddAPVbgiwBhvDmIEIrSUCooSGhKztsXvoNFoWsYLnXVVxYEbtIYvfbLAEhpNkwcFYfwSkzrigIejVmfnAiSNOjr")) {
        for (int OnAoJEeVFCf = 1308305441; OnAoJEeVFCf > 0; OnAoJEeVFCf--) {
            mYHAlhTeWgDmU /= CuMdu;
            gJCSwCPFRmUMfmEC = gJCSwCPFRmUMfmEC;
            DuMgutY /= MxMWkIEKYzmFpGHs;
        }
    }
}

double bXdHDIxwu::RrpPBRJPDUZ(string ltnbBCTmZt)
{
    string vnQIwbLwTDXwICz = string("YovTLWdaGkjrHHoalPJViganpbnyCWefuAISzSMDGKZuWhShvpqGUpoDvrOMhOLHLBGIooOFUyxikDaDomTIrMJiqGYJjjdwnGzlFNqlBRQUfvQkpwGIkknLnWGLkhczWPilwuNPSjLxjrGzFnKxduqowCxvqUchgiGRiZuwMhTcwXwvWhWZJgQaxZEggyWGACbNaLQaRouKhXrLswIANUTEGjwKJlnEwYGJxJwJKxf");
    int xylvWIXdIPc = 1746875874;
    double PvNzd = 965941.1557741163;
    bool ZkDJGGOMTEyHf = true;

    for (int LQVhzxER = 770250594; LQVhzxER > 0; LQVhzxER--) {
        ZkDJGGOMTEyHf = ! ZkDJGGOMTEyHf;
        xylvWIXdIPc -= xylvWIXdIPc;
    }

    for (int HtpdHMliHMkoPR = 628178779; HtpdHMliHMkoPR > 0; HtpdHMliHMkoPR--) {
        xylvWIXdIPc -= xylvWIXdIPc;
    }

    if (PvNzd <= 965941.1557741163) {
        for (int sBrwbwvKjaxvmztb = 396125519; sBrwbwvKjaxvmztb > 0; sBrwbwvKjaxvmztb--) {
            ZkDJGGOMTEyHf = ZkDJGGOMTEyHf;
            vnQIwbLwTDXwICz += vnQIwbLwTDXwICz;
            vnQIwbLwTDXwICz = ltnbBCTmZt;
        }
    }

    return PvNzd;
}

bXdHDIxwu::bXdHDIxwu()
{
    this->PvvytKvylBO();
    this->txgUzvCen(false, false, string("BopvrCkufbIJmVpiPHFWLhsYYOSMTrYbKKghiDqxzfItszmTQhBGhLTlMysWSjZIJzjXOpBPSNURuwWxTjsTgXxUSDKxrqlAxQlXULxl"), -855244.5064985562);
    this->skBJFaqoWXzQB(-282186.0544158586, false, -696431.7368225927, string("lTyPAQnVYDNAjljveuHSdJDJOkgeBBzgSlkkzqQquSDEghxqviRCuS"));
    this->rFaRpTITIKhWBjv(string("CXqbffHJmJJaylkQOLhSVPuOkfQCZVfPrEvBNdJDfyAJPKhbhTaLJBnIBQhGGFbXccLTtwjyKdJeLhSsAEEeDRh"));
    this->YGnHsvEd(true, 9941.874277492389, 859975740, false);
    this->TNhPclv(string("qcUBVJmGUHbXvBJGnshbtklRdQdKDNptJQGdAQJkLdqfbqJMHrLVsuyPnBpfBuAEACUObZTZlQyrOYPmmYZbTXlVMGUaDrdKMhyPWmempqxAZrIk"));
    this->yJTTtDz(2103165576, 18931.2888979702, 204688.68075439468, true);
    this->UqmOl();
    this->xwMquskjXexey(-364132.50673468603);
    this->RrpPBRJPDUZ(string("XNnBGvWyWBVJQohToTLAfMyVkqoOolpYjcknzkQQXKHGopnobTacjuHJLHHlFToTimpLfUGfOhUrDAfy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xgVltVLJF
{
public:
    int TBPMnNmW;

    xgVltVLJF();
    void LNxCeN(string HPNfhElGGFqNn, string uDxIhHnyYmMCFR);
    void FUDzKgoypFaQUu(bool ONSXxRL, string emoagRBnpWp);
protected:
    bool yJFEdItTy;
    string VjFMBhlvVVkbMGz;
    string gpmvuYjPHjErf;

    int NJqHWF(bool fBUdWoITQ, double YAbstQMXAFFfBbYw);
private:
    int xcXFIs;
    double XHgzs;
    double HjhixJmuUspDBJsF;

    int pDGceAd();
    double mgkwfUonqksoNVS(double YMbFgPqHVdvddyIX, string zZoMPWFnJMWCgBxZ);
    int obOmssNAzQn(bool PvxAfbrJSyLwjA, int WgzXYC, string BelxPvLS);
    double WweigRgRGVOJ();
    double mltVKzFcMpmxcDkh(bool bRJPiPZZesWZy, bool vpxVaAWE);
    void aqPrzSJeD(double PkMoALYAzcwb, bool HvcMCIDAWGgsMY);
    void MIHWZgW(int qlqnhwfazXDLwpVq, string RDKaHMgxZtFDAEE, double ppprPtVNBErPRsit);
    bool tcxjjXgMyK(bool CMpbPlnGr);
};

void xgVltVLJF::LNxCeN(string HPNfhElGGFqNn, string uDxIhHnyYmMCFR)
{
    double lbrOBA = -923675.9237533071;
    int otauCw = -1176705925;
    double fwHrbJoIy = 41221.68575867567;
    double sbeALLoeKHQFqj = -761095.9757604381;
    double jznqzJlUhW = -1046262.1350608624;
    bool mzPCnGgoiKLoqxo = false;

    for (int bDdpRWMAtAZiK = 2095348996; bDdpRWMAtAZiK > 0; bDdpRWMAtAZiK--) {
        jznqzJlUhW += jznqzJlUhW;
    }

    if (jznqzJlUhW <= 41221.68575867567) {
        for (int TxKyQy = 1157414782; TxKyQy > 0; TxKyQy--) {
            lbrOBA *= jznqzJlUhW;
            HPNfhElGGFqNn += HPNfhElGGFqNn;
        }
    }

    for (int HGZZGgDuDOJ = 679786017; HGZZGgDuDOJ > 0; HGZZGgDuDOJ--) {
        jznqzJlUhW = fwHrbJoIy;
        fwHrbJoIy /= lbrOBA;
        otauCw /= otauCw;
    }
}

void xgVltVLJF::FUDzKgoypFaQUu(bool ONSXxRL, string emoagRBnpWp)
{
    int fzUfxbEiS = 2097134872;
    int lwlFcejL = -1860540281;
    string nquONDqNeoHoid = string("EvyFodemBUtTughLSOMBFFWCbVuVqzxHBZoZwkNbbjGGzMgWXZcsX");
    double TDENqDCCX = 936424.3943900679;
    string qBYmVETDCZmeX = string("jFIxcBdypZQXFBhqTkrDnWPUJdnOXWmQoXdYTRXeUUVDRTJFfSOccUnQyBcojuJdyedtWToGVcxxLSOhlTBjxsDTYvNMdSSagdnYszpwSxRlMxeBfDccqBTPxJYOvVhkNrhyApEAowa");

    if (fzUfxbEiS != 2097134872) {
        for (int lOoYRYUvo = 402169704; lOoYRYUvo > 0; lOoYRYUvo--) {
            nquONDqNeoHoid += nquONDqNeoHoid;
            nquONDqNeoHoid += nquONDqNeoHoid;
            nquONDqNeoHoid += qBYmVETDCZmeX;
        }
    }

    for (int cbuDQojhKTUF = 358024014; cbuDQojhKTUF > 0; cbuDQojhKTUF--) {
        lwlFcejL = lwlFcejL;
        qBYmVETDCZmeX = qBYmVETDCZmeX;
        nquONDqNeoHoid += qBYmVETDCZmeX;
        nquONDqNeoHoid = emoagRBnpWp;
    }

    for (int SfxAxKfLd = 917702126; SfxAxKfLd > 0; SfxAxKfLd--) {
        nquONDqNeoHoid = qBYmVETDCZmeX;
    }

    for (int cqTcsfCD = 199451107; cqTcsfCD > 0; cqTcsfCD--) {
        emoagRBnpWp += qBYmVETDCZmeX;
        emoagRBnpWp += emoagRBnpWp;
    }
}

int xgVltVLJF::NJqHWF(bool fBUdWoITQ, double YAbstQMXAFFfBbYw)
{
    double XwGBrEM = -82150.35151381182;
    bool lQDvLPhzzyIi = true;
    double okAVTsIYqmKIUDA = -121701.15921046761;
    int VXRjY = 1122172767;
    int tOlftwRAQb = 1332530914;
    bool KIYvXncSJB = true;

    for (int utdSPMjEAa = 1744301021; utdSPMjEAa > 0; utdSPMjEAa--) {
        VXRjY /= tOlftwRAQb;
    }

    for (int nMXzBEBqWIcVT = 1332483301; nMXzBEBqWIcVT > 0; nMXzBEBqWIcVT--) {
        XwGBrEM *= okAVTsIYqmKIUDA;
        fBUdWoITQ = lQDvLPhzzyIi;
    }

    return tOlftwRAQb;
}

int xgVltVLJF::pDGceAd()
{
    bool KcMTTEFD = false;

    if (KcMTTEFD != false) {
        for (int QJSoDfFPGFx = 1072406361; QJSoDfFPGFx > 0; QJSoDfFPGFx--) {
            KcMTTEFD = ! KcMTTEFD;
        }
    }

    if (KcMTTEFD == false) {
        for (int HsUUqEotjUrEN = 1562513552; HsUUqEotjUrEN > 0; HsUUqEotjUrEN--) {
            KcMTTEFD = ! KcMTTEFD;
            KcMTTEFD = ! KcMTTEFD;
            KcMTTEFD = ! KcMTTEFD;
            KcMTTEFD = KcMTTEFD;
            KcMTTEFD = KcMTTEFD;
            KcMTTEFD = KcMTTEFD;
            KcMTTEFD = ! KcMTTEFD;
            KcMTTEFD = KcMTTEFD;
            KcMTTEFD = ! KcMTTEFD;
        }
    }

    if (KcMTTEFD == false) {
        for (int YiZRFHIiDDug = 23748905; YiZRFHIiDDug > 0; YiZRFHIiDDug--) {
            KcMTTEFD = ! KcMTTEFD;
        }
    }

    return 1917990117;
}

double xgVltVLJF::mgkwfUonqksoNVS(double YMbFgPqHVdvddyIX, string zZoMPWFnJMWCgBxZ)
{
    string FNfaMzl = string("wOTZdYutBurZABYdlUMCAJRNwIUphsdwXxpkucYlYfISGOQRUNaLHnEbBaMJaSeWMGbkaDuwRSRdYfkyAMevuBwdffstKEftnwOeayEGmCLRJsSVqOUvISDdebgwOGCKSTnmEsIRFhEERqKviYWugzOEqNlcdEhLaDmrpaYxhmtoRSLDBJXtBQsgGTNBnRPiuToQdsJtBfcBLmkuNxKBWu");
    bool hMKgkXdJrxrMHU = true;

    for (int nzysoLtdpX = 471173035; nzysoLtdpX > 0; nzysoLtdpX--) {
        zZoMPWFnJMWCgBxZ += FNfaMzl;
        YMbFgPqHVdvddyIX *= YMbFgPqHVdvddyIX;
    }

    if (zZoMPWFnJMWCgBxZ > string("MgSqusWSKnYdntQrWCHTsVooJzrRQNjMYkrldjNNLEYlmGIBOgYmLEKhSdCyumxzXlFYpZWUlVfxuTTdTCViLQIFybRAYtUbdGdJknzFEzbwUODoBdiAgxSkdAaLABXZtQiTdDeJXUZwHRrdkDNsnxdvNdauzxizLpbJgTpdtZluHavomxSpUznyELCpE")) {
        for (int WTNmFfTYUPW = 1514384816; WTNmFfTYUPW > 0; WTNmFfTYUPW--) {
            zZoMPWFnJMWCgBxZ += zZoMPWFnJMWCgBxZ;
            FNfaMzl = FNfaMzl;
            zZoMPWFnJMWCgBxZ += FNfaMzl;
        }
    }

    for (int fmPFfc = 1342613117; fmPFfc > 0; fmPFfc--) {
        zZoMPWFnJMWCgBxZ += zZoMPWFnJMWCgBxZ;
    }

    for (int YrfYwejfD = 1392937553; YrfYwejfD > 0; YrfYwejfD--) {
        FNfaMzl += zZoMPWFnJMWCgBxZ;
    }

    if (zZoMPWFnJMWCgBxZ == string("MgSqusWSKnYdntQrWCHTsVooJzrRQNjMYkrldjNNLEYlmGIBOgYmLEKhSdCyumxzXlFYpZWUlVfxuTTdTCViLQIFybRAYtUbdGdJknzFEzbwUODoBdiAgxSkdAaLABXZtQiTdDeJXUZwHRrdkDNsnxdvNdauzxizLpbJgTpdtZluHavomxSpUznyELCpE")) {
        for (int TtrJJXtlsPH = 1919115465; TtrJJXtlsPH > 0; TtrJJXtlsPH--) {
            continue;
        }
    }

    for (int EsxHgqOHoUs = 1220146457; EsxHgqOHoUs > 0; EsxHgqOHoUs--) {
        FNfaMzl += zZoMPWFnJMWCgBxZ;
        zZoMPWFnJMWCgBxZ = FNfaMzl;
    }

    for (int lsapxFs = 469117309; lsapxFs > 0; lsapxFs--) {
        continue;
    }

    return YMbFgPqHVdvddyIX;
}

int xgVltVLJF::obOmssNAzQn(bool PvxAfbrJSyLwjA, int WgzXYC, string BelxPvLS)
{
    int SRmsKs = 1155288107;
    double pRICmYwzk = -934228.1009208731;
    double kSCxXt = -710454.8232019782;
    bool aavZRGDMFC = false;

    for (int TDeppwF = 153566930; TDeppwF > 0; TDeppwF--) {
        continue;
    }

    if (pRICmYwzk < -934228.1009208731) {
        for (int dIOpbUPC = 592143829; dIOpbUPC > 0; dIOpbUPC--) {
            PvxAfbrJSyLwjA = ! PvxAfbrJSyLwjA;
        }
    }

    for (int bwUmaDV = 1927867156; bwUmaDV > 0; bwUmaDV--) {
        continue;
    }

    for (int LjBFMepdNpc = 338637830; LjBFMepdNpc > 0; LjBFMepdNpc--) {
        aavZRGDMFC = PvxAfbrJSyLwjA;
        kSCxXt -= kSCxXt;
        pRICmYwzk -= pRICmYwzk;
    }

    return SRmsKs;
}

double xgVltVLJF::WweigRgRGVOJ()
{
    int qDFpNhsApq = -1205596453;
    bool BljVzMtsSWuqd = true;
    double vAuppkfppqOdxu = -897050.2609071544;
    string RoiqCzwH = string("aXfqATkivsoymozFWcHWqPdLgWTUrAnBiLyPZerqdrvUJjMywrSvTiTHeDdEEovTmYpeYZGjwmMjnPyfjFtIsquBXMtIfIGyIFGAYlyXLDlEILsavxVWgVHEohjBgyBxhsbXogOgxwkWuUPZiosuNwVfMMhDtqMg");
    bool ZBoHMJJl = false;

    for (int pGFLLOjZdwIxxnV = 1171969015; pGFLLOjZdwIxxnV > 0; pGFLLOjZdwIxxnV--) {
        ZBoHMJJl = BljVzMtsSWuqd;
        qDFpNhsApq *= qDFpNhsApq;
        ZBoHMJJl = BljVzMtsSWuqd;
        BljVzMtsSWuqd = ! BljVzMtsSWuqd;
    }

    if (RoiqCzwH <= string("aXfqATkivsoymozFWcHWqPdLgWTUrAnBiLyPZerqdrvUJjMywrSvTiTHeDdEEovTmYpeYZGjwmMjnPyfjFtIsquBXMtIfIGyIFGAYlyXLDlEILsavxVWgVHEohjBgyBxhsbXogOgxwkWuUPZiosuNwVfMMhDtqMg")) {
        for (int YJtJnXfdX = 1103633355; YJtJnXfdX > 0; YJtJnXfdX--) {
            ZBoHMJJl = ! ZBoHMJJl;
            ZBoHMJJl = ! ZBoHMJJl;
            ZBoHMJJl = ! ZBoHMJJl;
            BljVzMtsSWuqd = ! BljVzMtsSWuqd;
        }
    }

    return vAuppkfppqOdxu;
}

double xgVltVLJF::mltVKzFcMpmxcDkh(bool bRJPiPZZesWZy, bool vpxVaAWE)
{
    bool qKAQjOpaUuufQvs = true;
    bool LVJOvDBJXFUV = false;
    int HPaKbGpQyyi = -50715411;
    double kKJWfv = 927970.2674640609;

    if (qKAQjOpaUuufQvs == false) {
        for (int xTWCYTPJot = 918976057; xTWCYTPJot > 0; xTWCYTPJot--) {
            LVJOvDBJXFUV = ! bRJPiPZZesWZy;
            LVJOvDBJXFUV = bRJPiPZZesWZy;
            LVJOvDBJXFUV = ! LVJOvDBJXFUV;
            vpxVaAWE = ! bRJPiPZZesWZy;
        }
    }

    if (qKAQjOpaUuufQvs != false) {
        for (int YfkfD = 517093465; YfkfD > 0; YfkfD--) {
            qKAQjOpaUuufQvs = LVJOvDBJXFUV;
            HPaKbGpQyyi += HPaKbGpQyyi;
            qKAQjOpaUuufQvs = ! qKAQjOpaUuufQvs;
        }
    }

    if (qKAQjOpaUuufQvs != false) {
        for (int WXjZcsRJ = 76532969; WXjZcsRJ > 0; WXjZcsRJ--) {
            vpxVaAWE = ! qKAQjOpaUuufQvs;
            vpxVaAWE = vpxVaAWE;
            kKJWfv += kKJWfv;
        }
    }

    for (int PaiuPFszvgimv = 126680423; PaiuPFszvgimv > 0; PaiuPFszvgimv--) {
        qKAQjOpaUuufQvs = qKAQjOpaUuufQvs;
        bRJPiPZZesWZy = bRJPiPZZesWZy;
    }

    if (vpxVaAWE == true) {
        for (int ETaWdWl = 1055095631; ETaWdWl > 0; ETaWdWl--) {
            HPaKbGpQyyi /= HPaKbGpQyyi;
            LVJOvDBJXFUV = LVJOvDBJXFUV;
            qKAQjOpaUuufQvs = bRJPiPZZesWZy;
        }
    }

    for (int blOtKmgRRGPNa = 1510886316; blOtKmgRRGPNa > 0; blOtKmgRRGPNa--) {
        LVJOvDBJXFUV = ! bRJPiPZZesWZy;
        bRJPiPZZesWZy = ! LVJOvDBJXFUV;
    }

    return kKJWfv;
}

void xgVltVLJF::aqPrzSJeD(double PkMoALYAzcwb, bool HvcMCIDAWGgsMY)
{
    double fYAWC = 247832.2682173036;
    bool PVjDXkrjkRHl = false;
    bool XweTmiOarXZLx = true;
    bool yllfrzFGtzuH = true;
    bool LNjZTcgqvfsjqrBX = false;
    int cXjtpdxCCXFvFXCU = -357174575;
    int BxSDFQBTEaypyPIZ = -1857479148;
    string gcJmr = string("YLHiJuSsExXVyMlxaqHeMOmEevcFqQoBGIWHjLaLQaMPLtHCRrpqVjBBAGtkXVDCYAsgFAdLWpHoFOCHVhhFZycasFOLcVJNVkMjsqgzAGAlEBjcjiinrARuQVdaHHgfVxPHOjblbcoeDjsqhNsZuJtYFQDRRSsOVJghsuLmkZhPLgQmqvQLRZbpzimWZoATI");

    for (int cgFzAFujkfqcQ = 90546999; cgFzAFujkfqcQ > 0; cgFzAFujkfqcQ--) {
        PVjDXkrjkRHl = XweTmiOarXZLx;
        yllfrzFGtzuH = ! LNjZTcgqvfsjqrBX;
        HvcMCIDAWGgsMY = ! XweTmiOarXZLx;
    }

    for (int JgeqCbAAErkUe = 1833166271; JgeqCbAAErkUe > 0; JgeqCbAAErkUe--) {
        yllfrzFGtzuH = yllfrzFGtzuH;
        PVjDXkrjkRHl = XweTmiOarXZLx;
        LNjZTcgqvfsjqrBX = HvcMCIDAWGgsMY;
    }

    for (int zhEZfFTTtWBy = 1490264386; zhEZfFTTtWBy > 0; zhEZfFTTtWBy--) {
        cXjtpdxCCXFvFXCU += cXjtpdxCCXFvFXCU;
        HvcMCIDAWGgsMY = ! yllfrzFGtzuH;
        yllfrzFGtzuH = ! XweTmiOarXZLx;
        PVjDXkrjkRHl = ! PVjDXkrjkRHl;
        BxSDFQBTEaypyPIZ *= BxSDFQBTEaypyPIZ;
        XweTmiOarXZLx = ! HvcMCIDAWGgsMY;
    }

    for (int oMhqu = 1685258170; oMhqu > 0; oMhqu--) {
        XweTmiOarXZLx = ! PVjDXkrjkRHl;
        XweTmiOarXZLx = XweTmiOarXZLx;
    }

    if (yllfrzFGtzuH == true) {
        for (int IHMWPK = 838693698; IHMWPK > 0; IHMWPK--) {
            LNjZTcgqvfsjqrBX = HvcMCIDAWGgsMY;
            fYAWC -= fYAWC;
            yllfrzFGtzuH = ! yllfrzFGtzuH;
        }
    }

    for (int BpRhymw = 1984951291; BpRhymw > 0; BpRhymw--) {
        LNjZTcgqvfsjqrBX = ! HvcMCIDAWGgsMY;
    }

    if (XweTmiOarXZLx != false) {
        for (int JNVzqFkWFpbsXP = 290964460; JNVzqFkWFpbsXP > 0; JNVzqFkWFpbsXP--) {
            continue;
        }
    }
}

void xgVltVLJF::MIHWZgW(int qlqnhwfazXDLwpVq, string RDKaHMgxZtFDAEE, double ppprPtVNBErPRsit)
{
    double JyUUGmoJR = 972701.7349108696;
    string VArGQLwWhgBAGf = string("wkUwqTbxtoDNQChbmvnKUBAUGCRxvxgg");
    int jvLMFEDafIcFuFdB = 1038893168;
    string RmwPPPuI = string("qKyGbszefaRspLKxbdtXwRqMulKdOnkcrxhjHvCBfGbrNOBJCSCPWUNXNsMHeVZjUPJAGYVhhyXrvt");
    double bRODRIFnIgj = 138388.8760665299;
    int NJcKTvjyziGcHl = 1410975046;
    bool AaMySCyLIM = false;
    bool JoHfa = true;

    for (int Agmuyn = 1166196019; Agmuyn > 0; Agmuyn--) {
        NJcKTvjyziGcHl *= jvLMFEDafIcFuFdB;
        JoHfa = AaMySCyLIM;
    }

    for (int VDVqOKtrqmrKk = 1298751064; VDVqOKtrqmrKk > 0; VDVqOKtrqmrKk--) {
        continue;
    }

    for (int AqVJpIKJ = 1835628984; AqVJpIKJ > 0; AqVJpIKJ--) {
        bRODRIFnIgj *= bRODRIFnIgj;
        qlqnhwfazXDLwpVq /= NJcKTvjyziGcHl;
    }
}

bool xgVltVLJF::tcxjjXgMyK(bool CMpbPlnGr)
{
    double YODAalgnDNbG = 1017320.9826528077;
    int nZCNIxFtsXm = 545579180;

    if (nZCNIxFtsXm > 545579180) {
        for (int JiuKHLoIamLXbNth = 941972906; JiuKHLoIamLXbNth > 0; JiuKHLoIamLXbNth--) {
            nZCNIxFtsXm += nZCNIxFtsXm;
            YODAalgnDNbG /= YODAalgnDNbG;
            YODAalgnDNbG -= YODAalgnDNbG;
            CMpbPlnGr = ! CMpbPlnGr;
        }
    }

    for (int VvXzmS = 691471088; VvXzmS > 0; VvXzmS--) {
        YODAalgnDNbG += YODAalgnDNbG;
        CMpbPlnGr = ! CMpbPlnGr;
        YODAalgnDNbG += YODAalgnDNbG;
        nZCNIxFtsXm /= nZCNIxFtsXm;
    }

    return CMpbPlnGr;
}

xgVltVLJF::xgVltVLJF()
{
    this->LNxCeN(string("BQCHVaVgOQPdBNDPBFKruaeszEMehNskumzyTAymkTtFZrQWc"), string("SpiTXDhNBTTDTqczJHGkTHYTDOenWEMaZ"));
    this->FUDzKgoypFaQUu(false, string("OKviRvbtSSFwN"));
    this->NJqHWF(true, -944425.9408140077);
    this->pDGceAd();
    this->mgkwfUonqksoNVS(867438.1369696104, string("MgSqusWSKnYdntQrWCHTsVooJzrRQNjMYkrldjNNLEYlmGIBOgYmLEKhSdCyumxzXlFYpZWUlVfxuTTdTCViLQIFybRAYtUbdGdJknzFEzbwUODoBdiAgxSkdAaLABXZtQiTdDeJXUZwHRrdkDNsnxdvNdauzxizLpbJgTpdtZluHavomxSpUznyELCpE"));
    this->obOmssNAzQn(true, 1689622850, string("TvtpxJVfVhzjyiRYObZjqwkpoWmCjtjpHgzTwLQIOjzkRcgeCarTbgZQAsPwBdrmbHmsaXeadPQDUOWOWWhXxfoadfAVqwFilVDcMxGlzkOOzj"));
    this->WweigRgRGVOJ();
    this->mltVKzFcMpmxcDkh(true, false);
    this->aqPrzSJeD(-462564.5371514954, true);
    this->MIHWZgW(-2135052133, string("zqQABQsVEWWpSGKvFkdvdpDHCmrRmOqymZycLFhBJEPIQnZrGHEizkIbjPywthxdtuOeqJrhVLKHamNRKFiHpCWvXZlWFijyoejkqApgESXMLUuYSLIwLMcshOVkicXeqQBKcmoVsoPMoOdGRkqDqzatgxUCWAMfnctFfFzCYLDCiLsbHYrwwrZKSgjdevRHbIPSvYBcMdxGkARryJEcGHfkdLZsFfpIAbbCTZFizMvabqWSfkKXLPbUydTKHX"), 107497.10251772693);
    this->tcxjjXgMyK(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HaWuOEfsjRNgbOj
{
public:
    int EuJcLv;
    bool UtoDiIXQTvQEDXU;

    HaWuOEfsjRNgbOj();
    void WMJFJPBUlgTadHjY(double BhLBExMdI, int hjDhYpCvrzeugrwo, bool VTQzLCvImVKKpXS, int rKgJDolzMSb, bool LDsaSJXRDi);
    string bfEtiGEzabFGreaB(string WoCmmOJLHDk);
    string knyVyvZRcopBVNa();
    int bXBtlmRg(bool HRorPvDTS);
    double ADEythzclmqfH(double zXJoqwDqKKWzs);
protected:
    int CGOWbaoDszC;
    string hzNwUbwbmVm;
    int ktVnMKGXVpMJ;

    string wZfAJclToeMSE(string skHrTMEqqIQfF, string WIvLFSYzBIQe, string OCjUIpYFNqRibw, int buhuDJGanFIz, int fPrGPoDTlwh);
    void bnTuFOWxTKchVSlx();
    string vRxgpIHbeZjOe();
    void OAexTNCjlV(bool VrBLEIqZhwBIH, bool FVUmHKxRrXeekkq, int YfRtuZXmlPUWO, bool lPSdhmZPAldPU, string NXnzToAuoN);
    bool AjauKPxIqxUFJn();
    bool rzqDZCwPoIHiqtx(int UVhiVzjyRswAz);
private:
    int tdGkRhu;
    string nNuQMDHLrpPST;
    int UphkbyA;

    void HiSoZLTNqiRzi(bool sdeqmrelQVcYSdz, string YsKoFWrbBb, bool ccuPycvmdoSQj, int jjYzuIoW);
    bool PBKTFDwlgduG(double WDuDH, double pwUWjdVKERu, int eOSrnx, double AWGHeLsbqvpwLkyw);
    void pDrjipaStJW(int IxwOIzd, int VRSAwo, string ADXklfGFevAXBGG, double IWiOReNY, string qsDsdMVNPpJbY);
    string sWygWcNMLHD(string riyDNrno, bool wqGkZqFKg, int bAMdU, bool ABAkzkVnVw);
    int fgOfiTmcvbVB(double FnZBrPmrB);
    int NpYBuSPrt(double AWgew);
};

void HaWuOEfsjRNgbOj::WMJFJPBUlgTadHjY(double BhLBExMdI, int hjDhYpCvrzeugrwo, bool VTQzLCvImVKKpXS, int rKgJDolzMSb, bool LDsaSJXRDi)
{
    int CjVurhWjUQV = 1581676456;
    double oxwNsRPKSNlBzs = -221882.7557548845;
    int qoiGHC = -931887441;
    bool mJspt = false;

    if (mJspt == true) {
        for (int OktRagXYYb = 2009581349; OktRagXYYb > 0; OktRagXYYb--) {
            hjDhYpCvrzeugrwo *= rKgJDolzMSb;
        }
    }

    for (int LLXxUcOHsaKsk = 1602522302; LLXxUcOHsaKsk > 0; LLXxUcOHsaKsk--) {
        rKgJDolzMSb /= CjVurhWjUQV;
    }

    for (int NlbTA = 780865898; NlbTA > 0; NlbTA--) {
        rKgJDolzMSb -= rKgJDolzMSb;
        qoiGHC *= qoiGHC;
        hjDhYpCvrzeugrwo /= rKgJDolzMSb;
        rKgJDolzMSb = hjDhYpCvrzeugrwo;
    }

    if (VTQzLCvImVKKpXS == false) {
        for (int gjvtoilw = 404198362; gjvtoilw > 0; gjvtoilw--) {
            VTQzLCvImVKKpXS = VTQzLCvImVKKpXS;
            VTQzLCvImVKKpXS = ! LDsaSJXRDi;
            mJspt = ! VTQzLCvImVKKpXS;
        }
    }

    if (qoiGHC < -931887441) {
        for (int lessW = 569841823; lessW > 0; lessW--) {
            rKgJDolzMSb += CjVurhWjUQV;
            hjDhYpCvrzeugrwo /= rKgJDolzMSb;
            rKgJDolzMSb *= hjDhYpCvrzeugrwo;
        }
    }

    for (int LtNLVgeuCnhuSjC = 376308321; LtNLVgeuCnhuSjC > 0; LtNLVgeuCnhuSjC--) {
        continue;
    }
}

string HaWuOEfsjRNgbOj::bfEtiGEzabFGreaB(string WoCmmOJLHDk)
{
    double IVveUdfCtOzktMX = -20278.11048377341;
    double DMZWsKLvbC = 200754.3670670438;

    if (IVveUdfCtOzktMX < 200754.3670670438) {
        for (int NlxpzlQ = 932774652; NlxpzlQ > 0; NlxpzlQ--) {
            DMZWsKLvbC *= DMZWsKLvbC;
            DMZWsKLvbC += IVveUdfCtOzktMX;
        }
    }

    if (IVveUdfCtOzktMX > -20278.11048377341) {
        for (int mxAwO = 2127276871; mxAwO > 0; mxAwO--) {
            WoCmmOJLHDk += WoCmmOJLHDk;
            DMZWsKLvbC *= IVveUdfCtOzktMX;
            DMZWsKLvbC /= IVveUdfCtOzktMX;
            DMZWsKLvbC += DMZWsKLvbC;
            IVveUdfCtOzktMX /= DMZWsKLvbC;
            IVveUdfCtOzktMX += IVveUdfCtOzktMX;
            IVveUdfCtOzktMX -= IVveUdfCtOzktMX;
        }
    }

    return WoCmmOJLHDk;
}

string HaWuOEfsjRNgbOj::knyVyvZRcopBVNa()
{
    bool pmsfAeG = true;
    double lkYAYOauPffKTu = 710130.7403278633;
    int iZlSfDibgtqCIib = 530960215;

    if (lkYAYOauPffKTu != 710130.7403278633) {
        for (int pMfKPXtCH = 1571384955; pMfKPXtCH > 0; pMfKPXtCH--) {
            iZlSfDibgtqCIib *= iZlSfDibgtqCIib;
            iZlSfDibgtqCIib *= iZlSfDibgtqCIib;
            iZlSfDibgtqCIib += iZlSfDibgtqCIib;
            pmsfAeG = ! pmsfAeG;
        }
    }

    for (int IFPeIBbiTy = 837260322; IFPeIBbiTy > 0; IFPeIBbiTy--) {
        lkYAYOauPffKTu -= lkYAYOauPffKTu;
    }

    return string("q");
}

int HaWuOEfsjRNgbOj::bXBtlmRg(bool HRorPvDTS)
{
    double TYnzucF = -236634.18039493906;

    for (int lpQguzFhSMciVJz = 1746478446; lpQguzFhSMciVJz > 0; lpQguzFhSMciVJz--) {
        HRorPvDTS = HRorPvDTS;
    }

    if (TYnzucF < -236634.18039493906) {
        for (int LwWDvrfMLiRTHm = 1838555326; LwWDvrfMLiRTHm > 0; LwWDvrfMLiRTHm--) {
            TYnzucF *= TYnzucF;
            TYnzucF *= TYnzucF;
        }
    }

    for (int MImBCVtkaRqfUOsp = 819128458; MImBCVtkaRqfUOsp > 0; MImBCVtkaRqfUOsp--) {
        continue;
    }

    if (HRorPvDTS != true) {
        for (int tcSFa = 1791742467; tcSFa > 0; tcSFa--) {
            HRorPvDTS = HRorPvDTS;
            TYnzucF *= TYnzucF;
            HRorPvDTS = ! HRorPvDTS;
        }
    }

    return 1515175113;
}

double HaWuOEfsjRNgbOj::ADEythzclmqfH(double zXJoqwDqKKWzs)
{
    int GAHcHrFdxnBc = 398763725;
    string QUrppWGARaQXE = string("jCzivRilsmZtMMdANDQOprVyGpKJRtaCIVeuRpnJUgMnPjUWppWYsKAHSxMTuMhIUnVWPybrkBedJJFEHDKgxzJkNgZqNwKZYVYAsCHlcHbWqXBKcvfqXiSvYUInUxmWCUQmINpnALNiZeStiFbdssSDpsTnsZFLYyMtMjG");
    bool CpmrGdzgFG = true;

    for (int gHwdsxFntBKZAShr = 1581177660; gHwdsxFntBKZAShr > 0; gHwdsxFntBKZAShr--) {
        continue;
    }

    for (int wmeSqvPhaR = 1544869815; wmeSqvPhaR > 0; wmeSqvPhaR--) {
        continue;
    }

    return zXJoqwDqKKWzs;
}

string HaWuOEfsjRNgbOj::wZfAJclToeMSE(string skHrTMEqqIQfF, string WIvLFSYzBIQe, string OCjUIpYFNqRibw, int buhuDJGanFIz, int fPrGPoDTlwh)
{
    string iXaoT = string("JyMxHxMCKevytBeabvsvuSKiRFfcXvpwPITwRzCLjaWGVDCnqfOKauIZEevRPNKTRhLtCYjtCbGXeZsQUDuUrDQUl");
    int RfyUZFOulXW = -1963145861;
    bool aDkBuSvlCCwOZS = true;
    string hrleIQxNuLVU = string("yRUaltMFYZkMDacturDDXTxPEOhcwGLVJVnngiDHTmcJNrYNNGQgMMimQOwTSxDrJXHLmIqsDkDLwicGkhmNnIENKbzGCbOQXEzQhlLHCiDSOZYIQRMRZaOLdrSwElwOgvuqRNucDQ");
    int RVQLsFnyK = -1638840597;

    for (int ErfQtMWadgHGU = 997468667; ErfQtMWadgHGU > 0; ErfQtMWadgHGU--) {
        continue;
    }

    if (RfyUZFOulXW >= -302100784) {
        for (int JVkOnP = 1011453454; JVkOnP > 0; JVkOnP--) {
            hrleIQxNuLVU += OCjUIpYFNqRibw;
            fPrGPoDTlwh /= RfyUZFOulXW;
            OCjUIpYFNqRibw = OCjUIpYFNqRibw;
            fPrGPoDTlwh = buhuDJGanFIz;
        }
    }

    for (int lqsWqho = 1664255846; lqsWqho > 0; lqsWqho--) {
        iXaoT += hrleIQxNuLVU;
        buhuDJGanFIz /= buhuDJGanFIz;
    }

    return hrleIQxNuLVU;
}

void HaWuOEfsjRNgbOj::bnTuFOWxTKchVSlx()
{
    double LTkiIAUp = 124747.14350961271;

    if (LTkiIAUp > 124747.14350961271) {
        for (int RQMwuDy = 1869030106; RQMwuDy > 0; RQMwuDy--) {
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
        }
    }

    if (LTkiIAUp >= 124747.14350961271) {
        for (int AjhQpXMzYUmQDaUB = 645074702; AjhQpXMzYUmQDaUB > 0; AjhQpXMzYUmQDaUB--) {
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp = LTkiIAUp;
            LTkiIAUp = LTkiIAUp;
            LTkiIAUp = LTkiIAUp;
        }
    }

    if (LTkiIAUp >= 124747.14350961271) {
        for (int jFYowuxtOchj = 648065017; jFYowuxtOchj > 0; jFYowuxtOchj--) {
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp += LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp -= LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
        }
    }

    if (LTkiIAUp >= 124747.14350961271) {
        for (int KqIiTK = 818945571; KqIiTK > 0; KqIiTK--) {
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp = LTkiIAUp;
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp = LTkiIAUp;
            LTkiIAUp += LTkiIAUp;
            LTkiIAUp /= LTkiIAUp;
            LTkiIAUp += LTkiIAUp;
        }
    }

    if (LTkiIAUp <= 124747.14350961271) {
        for (int xAsepkDfxjhIWiB = 1481649501; xAsepkDfxjhIWiB > 0; xAsepkDfxjhIWiB--) {
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp += LTkiIAUp;
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp -= LTkiIAUp;
            LTkiIAUp += LTkiIAUp;
            LTkiIAUp += LTkiIAUp;
            LTkiIAUp += LTkiIAUp;
        }
    }

    if (LTkiIAUp > 124747.14350961271) {
        for (int KFAgoBSHIVlhWr = 319035836; KFAgoBSHIVlhWr > 0; KFAgoBSHIVlhWr--) {
            LTkiIAUp *= LTkiIAUp;
            LTkiIAUp *= LTkiIAUp;
        }
    }
}

string HaWuOEfsjRNgbOj::vRxgpIHbeZjOe()
{
    bool mpIuEr = false;
    int BhesmUrEN = -1574772515;
    int FvYkp = -1112412454;
    string VDZhtbazKkE = string("mxrWrCYPvyUZQgXumpGLFcNiLvpYlLPFTtbSHlicuagdbaVGBfFpUPmKaQCMMbEtnthZvhfsERkaITSJBsXzLMlLzUIZxLMiZiiCsierbPxtAUtNwBAlLuIGFLOXRjrySUJoDihorggBcQMDymuuvxvnUKcxbuCMNTfdOXLeLpSXthvVNizVsdrlWCjBzcIv");
    int fDbOZgYsfAobLpi = -2114081957;

    if (mpIuEr != false) {
        for (int AspoqCIQNJtvg = 725469680; AspoqCIQNJtvg > 0; AspoqCIQNJtvg--) {
            continue;
        }
    }

    for (int TAUTgGUheauO = 121206297; TAUTgGUheauO > 0; TAUTgGUheauO--) {
        fDbOZgYsfAobLpi -= BhesmUrEN;
        FvYkp /= BhesmUrEN;
        BhesmUrEN += BhesmUrEN;
        fDbOZgYsfAobLpi -= fDbOZgYsfAobLpi;
        FvYkp -= fDbOZgYsfAobLpi;
    }

    for (int JOyXRydwxsiv = 1073001670; JOyXRydwxsiv > 0; JOyXRydwxsiv--) {
        fDbOZgYsfAobLpi *= BhesmUrEN;
    }

    if (BhesmUrEN >= -1574772515) {
        for (int onRWGk = 1776072422; onRWGk > 0; onRWGk--) {
            FvYkp += fDbOZgYsfAobLpi;
        }
    }

    for (int GYihNs = 1223732027; GYihNs > 0; GYihNs--) {
        BhesmUrEN -= FvYkp;
    }

    for (int kwRVfResa = 587677052; kwRVfResa > 0; kwRVfResa--) {
        BhesmUrEN = FvYkp;
        BhesmUrEN = BhesmUrEN;
        BhesmUrEN *= fDbOZgYsfAobLpi;
        FvYkp /= fDbOZgYsfAobLpi;
        mpIuEr = ! mpIuEr;
    }

    return VDZhtbazKkE;
}

void HaWuOEfsjRNgbOj::OAexTNCjlV(bool VrBLEIqZhwBIH, bool FVUmHKxRrXeekkq, int YfRtuZXmlPUWO, bool lPSdhmZPAldPU, string NXnzToAuoN)
{
    bool FfCkjL = true;
    double bfVHiHsQWuRd = 610088.6110147886;
    string yhzHAg = string("FBToiWkMFDoIRFDXgWYCyPkllNucVibicODMOYQmoDaWKdysAiqsfy");
    string xdOnEpDQfGvNMnh = string("chnAHrXFPLYUYjnAaZnyOOulJHzANyQBqAineZchqZeVsPLCuCbROzPoqAjpxhgVOLGdMwewuwPFpzlkLAVEuphST");
    string HDfPSMCqQrqiQh = string("qAtECIQwpdsyQTRFRJaRQIeoHccwpTaJXqAGyLmCKqOHJInYPNDCrZijZmuvbMlqxMKcEVKjVQygZqSoQclVqnLJxAbwPMSnhwRJVHAfPdOaQDkfOSnAloHWiSnwiQfaQUZaWLmSGxVqkFqWnWOPGFzNkRiWOJNvxakncNyNqsJjdPswVZClYMYarq");
    double AKIsJbm = -95692.37741493303;
    double hkqPxHMQlHRtkJP = 80835.35105419374;
    bool wVkarcGUAPVz = true;
    bool swmLcou = true;

    for (int zMyCbeptkUeY = 838339124; zMyCbeptkUeY > 0; zMyCbeptkUeY--) {
        VrBLEIqZhwBIH = ! FVUmHKxRrXeekkq;
        swmLcou = lPSdhmZPAldPU;
    }
}

bool HaWuOEfsjRNgbOj::AjauKPxIqxUFJn()
{
    string KkHrTyR = string("WItwLBLGeTBZzjGSEyOQFwxvyNbMgMdLIIdS");
    bool ardJoWcShKi = true;
    bool LmKZcis = true;
    string zkvyor = string("aYygJvtBlhJlcbmbjFKmPqphzJqXZIgPDRaGOBBzNVkXonWBUeDQmoUTajGOuQApWQvOwLlpBKiGHQGPREsLwpEvnrzEABQyHFOkGcOEjbVTbscUdTUjyEjFyfbfvHYijrqUglGbIGEPNRuTqsbOuFuZAkjMQurOZtdABTPbxlkkXAivLKTyzmSvanDqsWL");
    string UoGNtSOMuRDiY = string("IrdITmxtxBFLjLjpUNbhiSTRMoQNoYmyTQYtWAFtGRbNEuoCEuyTzHUgnUgnmuvEFFvv");

    for (int NietvlvJcQVI = 1189717825; NietvlvJcQVI > 0; NietvlvJcQVI--) {
        KkHrTyR += UoGNtSOMuRDiY;
    }

    for (int WjRxExCj = 2110470822; WjRxExCj > 0; WjRxExCj--) {
        UoGNtSOMuRDiY = zkvyor;
        KkHrTyR += UoGNtSOMuRDiY;
    }

    if (zkvyor == string("aYygJvtBlhJlcbmbjFKmPqphzJqXZIgPDRaGOBBzNVkXonWBUeDQmoUTajGOuQApWQvOwLlpBKiGHQGPREsLwpEvnrzEABQyHFOkGcOEjbVTbscUdTUjyEjFyfbfvHYijrqUglGbIGEPNRuTqsbOuFuZAkjMQurOZtdABTPbxlkkXAivLKTyzmSvanDqsWL")) {
        for (int QThOboSQN = 1288967510; QThOboSQN > 0; QThOboSQN--) {
            KkHrTyR = UoGNtSOMuRDiY;
        }
    }

    for (int mRzZArRkCTEyc = 337676848; mRzZArRkCTEyc > 0; mRzZArRkCTEyc--) {
        ardJoWcShKi = ! ardJoWcShKi;
        ardJoWcShKi = ! ardJoWcShKi;
    }

    for (int VfUunB = 849759303; VfUunB > 0; VfUunB--) {
        zkvyor += UoGNtSOMuRDiY;
        ardJoWcShKi = ardJoWcShKi;
    }

    if (KkHrTyR != string("IrdITmxtxBFLjLjpUNbhiSTRMoQNoYmyTQYtWAFtGRbNEuoCEuyTzHUgnUgnmuvEFFvv")) {
        for (int DHUqoYfaZDaDg = 917152999; DHUqoYfaZDaDg > 0; DHUqoYfaZDaDg--) {
            zkvyor = zkvyor;
            ardJoWcShKi = ardJoWcShKi;
            KkHrTyR += zkvyor;
            zkvyor = UoGNtSOMuRDiY;
        }
    }

    for (int nZpdzHSz = 1235004924; nZpdzHSz > 0; nZpdzHSz--) {
        KkHrTyR += KkHrTyR;
    }

    return LmKZcis;
}

bool HaWuOEfsjRNgbOj::rzqDZCwPoIHiqtx(int UVhiVzjyRswAz)
{
    double HIHbHygdWzi = 434680.32031608117;
    bool zUovvKtvXneozQq = true;
    string WDVHcgHqr = string("rRtEBRAqyYaQWvxKpuLYpPEwlkJGKRInzynGCkPWseftgGFXiWsdTIXYPuFzPNUdhTPndBevJjwAKngpLkImXWRuiCQrxqNfRgfPjEvbduMGqVyWgCR");
    double pyYStQ = 859602.2289582003;
    string zBXNI = string("ALUrzIXpdMmPgJlpAAYSGgVtkTcXQrwBuItVTtBfOjgzRXLCSpOksvZlWIcrMseFucKdVytTxBfJYhBlNUnXhDiUPOBduKJgKoAcBIdpzHXoOqmOKHjjwXmuFMQTwaYfQfWVKpSQcbpoRhDWylBxkNDOdbrhhRJrAgrxnbiXweTSIWdh");
    int BtlSzp = 17606714;
    string pAoHU = string("qHwbqtSOHFoYUiRSyjOZsDxjUgfsmNCWxJUQzRzdGAXsUWPocsmIjRRAbujJNEcJzvcantCLbJJJXYXgKLuBXhKvRdJgqaZumkhIPQQquGwunJinlanFWPLQbHwdeOuKsPERCWBEJbfyHjcbqVCwtZQSfkQMdMOOShUvAvYilvL");
    bool jXJkbwOkntdn = false;
    bool aROWM = true;
    string PHpJeRURKuR = string("fjkouUbOUWcMOwmfdivmTcosXVCzHXaifhZrPJEGFlnYmBikEKZAxFcwfQmAjkkYWrTCIAdVToNutdKBodbXjCtSQzyMVtIPRDAuOhWkUVrkJQwIKnYUUygkJhPWvEQlRfwVWyuUdSmeNsldVrFnbjBPXFHXViYpRUIiLdWggtrBApBCDosJIkvUxJgLsrVOWjXlfXECmegXpiXpwRSOeTZDoSaXRDFiyckBCAqZsTSha");

    for (int kihXyEOhijrE = 1420788488; kihXyEOhijrE > 0; kihXyEOhijrE--) {
        jXJkbwOkntdn = ! jXJkbwOkntdn;
        pyYStQ /= HIHbHygdWzi;
        pAoHU += WDVHcgHqr;
    }

    for (int gLWqe = 1612286527; gLWqe > 0; gLWqe--) {
        HIHbHygdWzi = HIHbHygdWzi;
        WDVHcgHqr += PHpJeRURKuR;
        UVhiVzjyRswAz = UVhiVzjyRswAz;
    }

    if (zUovvKtvXneozQq == true) {
        for (int sQhWMKbrhBugrqaP = 717808884; sQhWMKbrhBugrqaP > 0; sQhWMKbrhBugrqaP--) {
            continue;
        }
    }

    for (int EpqSkCjtfG = 911057992; EpqSkCjtfG > 0; EpqSkCjtfG--) {
        continue;
    }

    if (PHpJeRURKuR < string("rRtEBRAqyYaQWvxKpuLYpPEwlkJGKRInzynGCkPWseftgGFXiWsdTIXYPuFzPNUdhTPndBevJjwAKngpLkImXWRuiCQrxqNfRgfPjEvbduMGqVyWgCR")) {
        for (int nJPeE = 118884212; nJPeE > 0; nJPeE--) {
            continue;
        }
    }

    return aROWM;
}

void HaWuOEfsjRNgbOj::HiSoZLTNqiRzi(bool sdeqmrelQVcYSdz, string YsKoFWrbBb, bool ccuPycvmdoSQj, int jjYzuIoW)
{
    double kcnNyEtfd = -218609.4670223817;
    double UuWGKTtN = -976218.7970419525;
    string sIZUpxu = string("VuyyHqimzMwbPaxukiVTdQWQqjHJAyCqqcrKJGVXapjBVwPEDTAVINzhDnqcUiKMZTgJrfGBBCOFREYZbYAkoDILSxmKoshpJiFntOOLpgJnQyMOStfBfSwcoHxHVjoGqbbmtNiBtGRceaPsYZseKFAupqVoyWuvxlNNPbbIimNQvgCIkFolzctxKQkLeAXrncxwEcFPBfKbuFserOsKvSzMostRPnNpumjSWri");
    double fokyGnwzeb = 596716.5154760748;
    double YEDcfbJnUwQRL = 227012.98254366507;
    int lpxVzVBFV = -2042157976;
    double EuljjBoOwOqGLU = -874294.4126561373;
    string zkQoJZzk = string("lUHynNAxzkhmoqZbNHMYTCSlURaKjPgMadfnjQIDmQPxoxBYiVOyUTvWNnGmYOuUpJUGFISQpGDjKvvWyzAuQMcPRCmKNIPRKYSNSOcZaNHkrKRDSANzUqJcnNGDoEVbddOiOVucteiayNTtJnwoAbndnPyrSkRgZnPNoNFiqfPTgWvUwLIMZsXcBBlBrIcbTBBEELfElgbvcTKCxpIDELtykVOiqrMXWFEWokOMvCsiWhFhdtkxj");
    double fvjlxO = 812267.8699331845;
    double LdNZSuHoRZ = 115457.70938774229;

    if (YEDcfbJnUwQRL == -874294.4126561373) {
        for (int mdBUfZ = 966281612; mdBUfZ > 0; mdBUfZ--) {
            fokyGnwzeb = UuWGKTtN;
        }
    }

    for (int TEozMYtsLDx = 678782329; TEozMYtsLDx > 0; TEozMYtsLDx--) {
        UuWGKTtN -= fokyGnwzeb;
        jjYzuIoW = lpxVzVBFV;
    }

    for (int vMGmurtYkDJBiwPS = 2053087494; vMGmurtYkDJBiwPS > 0; vMGmurtYkDJBiwPS--) {
        sIZUpxu += zkQoJZzk;
        EuljjBoOwOqGLU *= UuWGKTtN;
        YsKoFWrbBb = YsKoFWrbBb;
    }
}

bool HaWuOEfsjRNgbOj::PBKTFDwlgduG(double WDuDH, double pwUWjdVKERu, int eOSrnx, double AWGHeLsbqvpwLkyw)
{
    double jFgxiaL = -102371.42338791612;
    double movEOpzGeSQZDKx = -198774.17081890124;
    double dyYlLi = 1029426.7320560451;
    string SFjZSGkuRn = string("bPBESxZmcJmfkMuVrBxITotGsrDdkVgYgsmbYytKFIqQTJEalpGUtDrRdfhkXkNFqdEzSMQneINKUWupVqzeFVrFaTFxxDHvBinSDVfRxzJjdSKhfWqsjQRvUTNaKQhelhKCiRxPpCnObIZzouEOlFecZCqvDFtvgUPixBzaejPpNSGLXXahpYcksPWJHxZzbtgLIwGsHyUqpbb");
    double IixlMbj = 476368.6484376559;
    int lFMvFbX = -1734751299;
    string aYBJssRUhK = string("mY");
    bool wHIfYCbBY = true;
    double lZfkeynPRWzx = -485409.55713932525;
    string IAIybiaFP = string("xwZYMCgXSiUoXvTDdJxphnuNBSjcUYmRRoesgWbJTIvrLqIwnVtgyOHURMxRJopvPMaYyomRUKdJEewsTUspMvFRJ");

    if (IAIybiaFP >= string("bPBESxZmcJmfkMuVrBxITotGsrDdkVgYgsmbYytKFIqQTJEalpGUtDrRdfhkXkNFqdEzSMQneINKUWupVqzeFVrFaTFxxDHvBinSDVfRxzJjdSKhfWqsjQRvUTNaKQhelhKCiRxPpCnObIZzouEOlFecZCqvDFtvgUPixBzaejPpNSGLXXahpYcksPWJHxZzbtgLIwGsHyUqpbb")) {
        for (int FjyndgmBnnRytlLg = 513641106; FjyndgmBnnRytlLg > 0; FjyndgmBnnRytlLg--) {
            lZfkeynPRWzx /= movEOpzGeSQZDKx;
            WDuDH -= lZfkeynPRWzx;
        }
    }

    if (IixlMbj < -102371.42338791612) {
        for (int PJwMCpanX = 953961739; PJwMCpanX > 0; PJwMCpanX--) {
            SFjZSGkuRn += SFjZSGkuRn;
            jFgxiaL += lZfkeynPRWzx;
        }
    }

    for (int KjsIvBJMBEMadRFX = 853262046; KjsIvBJMBEMadRFX > 0; KjsIvBJMBEMadRFX--) {
        movEOpzGeSQZDKx += lZfkeynPRWzx;
        aYBJssRUhK = IAIybiaFP;
    }

    for (int KVghEywr = 1411808019; KVghEywr > 0; KVghEywr--) {
        AWGHeLsbqvpwLkyw /= movEOpzGeSQZDKx;
        lFMvFbX = lFMvFbX;
        jFgxiaL += WDuDH;
        IixlMbj += movEOpzGeSQZDKx;
        lZfkeynPRWzx *= AWGHeLsbqvpwLkyw;
        IixlMbj -= lZfkeynPRWzx;
        movEOpzGeSQZDKx += WDuDH;
    }

    return wHIfYCbBY;
}

void HaWuOEfsjRNgbOj::pDrjipaStJW(int IxwOIzd, int VRSAwo, string ADXklfGFevAXBGG, double IWiOReNY, string qsDsdMVNPpJbY)
{
    int MmuFoPpJnCKJ = 44596142;
    double cdePAEBvOTtMTqH = 621442.8336016953;
    int TKZGj = 1303282763;
    string jhYSXQFiGYVUgwsh = string("WOJsuWqPoYBmOzlobvduWASLACyjANNNWkKDxsypPGByfWZsyJRIxVJIhjnTNFfCMIoUSTszzwldnpoKZzIp");
    int eYnjwmZx = -343703104;
    string gimrYbZyWpiG = string("rpqgAAvimIYXzKevGMaRvxKteDYurGnnJdcuKwJkMHdObGnTJtASEYuaWNOsHETaMidaZhHARXHsxcbfVeDFjBkQPMkoRpDPyPHmdHpFsbQrNRLeXtVWfefqjZaQAiefrckfUGitFNvNjA");
    int qbgxFz = -267287636;
    string nCmytWroyHZu = string("ESqbbPNMPmaaeRrib");
    string jrwgjpRHkhx = string("eWASvKVBaVYImhGlODuuoZPDtAAVGNEkXwKAqCHYTgdAJowELkuwqJjFuPhytzUvbHIlJuxicZiNjoVZgLEJtEZWezImkrgMFfXqmYDCMqGztGLckbLwFzfwUdBfHIXhMyErEcpdwOBJpluEJSiqETnFEJSUkUfob");

    if (MmuFoPpJnCKJ == 1303282763) {
        for (int mfoCXvEjgfdauj = 1101562035; mfoCXvEjgfdauj > 0; mfoCXvEjgfdauj--) {
            TKZGj += VRSAwo;
        }
    }

    for (int deJYgsJmKYkpWWfl = 55608212; deJYgsJmKYkpWWfl > 0; deJYgsJmKYkpWWfl--) {
        eYnjwmZx = eYnjwmZx;
        qsDsdMVNPpJbY = jrwgjpRHkhx;
    }
}

string HaWuOEfsjRNgbOj::sWygWcNMLHD(string riyDNrno, bool wqGkZqFKg, int bAMdU, bool ABAkzkVnVw)
{
    double DEQIawXvtReqTXd = 861582.611666905;
    double lGFlRDfK = 1037438.4256814129;
    string TYXMQwTsZCWARs = string("vWnZMBtdvfBmxpuCfotHkwSikncXaWhMtIoJjbfqiABvnypGQNXDvmDVgzIjuSsuMkWnplQEPSAadbYNcKGZajAMFLqsMkfFtzmIEOZJgcbuYhPBgcbtMASGyMSSSEnAtozgtvInTszcmlQXRXyGkoWEZaqTasNMiqcqBYsSVuNtxrccGCcXCoCeqTEsBdUmKlXHEnYsmcSEWFChLOdolIdICXkzdmFcxQ");

    if (riyDNrno >= string("vWnZMBtdvfBmxpuCfotHkwSikncXaWhMtIoJjbfqiABvnypGQNXDvmDVgzIjuSsuMkWnplQEPSAadbYNcKGZajAMFLqsMkfFtzmIEOZJgcbuYhPBgcbtMASGyMSSSEnAtozgtvInTszcmlQXRXyGkoWEZaqTasNMiqcqBYsSVuNtxrccGCcXCoCeqTEsBdUmKlXHEnYsmcSEWFChLOdolIdICXkzdmFcxQ")) {
        for (int MAwlKwJMnF = 172720688; MAwlKwJMnF > 0; MAwlKwJMnF--) {
            ABAkzkVnVw = ABAkzkVnVw;
        }
    }

    for (int cAELeQxfTFcMYpBe = 1420437319; cAELeQxfTFcMYpBe > 0; cAELeQxfTFcMYpBe--) {
        continue;
    }

    if (DEQIawXvtReqTXd < 1037438.4256814129) {
        for (int HSaTsmdOG = 343881022; HSaTsmdOG > 0; HSaTsmdOG--) {
            DEQIawXvtReqTXd *= lGFlRDfK;
        }
    }

    for (int FSRvIemXSQQnby = 2011355479; FSRvIemXSQQnby > 0; FSRvIemXSQQnby--) {
        continue;
    }

    for (int QTrFfMZQBexEOYYn = 42499601; QTrFfMZQBexEOYYn > 0; QTrFfMZQBexEOYYn--) {
        ABAkzkVnVw = ! ABAkzkVnVw;
    }

    return TYXMQwTsZCWARs;
}

int HaWuOEfsjRNgbOj::fgOfiTmcvbVB(double FnZBrPmrB)
{
    double gBqTmUZRBt = -377075.9707466922;
    double MkFRclw = -259774.4428692849;
    bool qEHbWMklm = true;
    string JNwFtUK = string("pQltpXSJCJeHPsTdtzyFANxsAGinnPTpEUIbmKzRLGLCRlydOCrRqQZifCrMeowIyWvjZfuHNJueGNVowAzRAMsRxMTPLuewFfIjyFBXrTjhptdOwaaFVzhrdeXzmVhZ");
    int fHfrgDQWS = -1518881291;
    bool ZQJazk = true;

    for (int WOQkQdqfjFEhC = 333365958; WOQkQdqfjFEhC > 0; WOQkQdqfjFEhC--) {
        continue;
    }

    for (int UhIPwof = 1910482769; UhIPwof > 0; UhIPwof--) {
        gBqTmUZRBt /= FnZBrPmrB;
    }

    if (MkFRclw >= -259774.4428692849) {
        for (int YjsdmwizTO = 160035384; YjsdmwizTO > 0; YjsdmwizTO--) {
            fHfrgDQWS = fHfrgDQWS;
        }
    }

    for (int DnTHzbQLPQsjS = 582811771; DnTHzbQLPQsjS > 0; DnTHzbQLPQsjS--) {
        JNwFtUK += JNwFtUK;
        JNwFtUK += JNwFtUK;
        MkFRclw -= gBqTmUZRBt;
    }

    return fHfrgDQWS;
}

int HaWuOEfsjRNgbOj::NpYBuSPrt(double AWgew)
{
    int UlWhdLdQsdlsY = -1817711823;
    bool JFnIKYlFMDsRG = false;
    bool FtIDGBqQemmThjhx = true;
    string kxGPhMjerW = string("HoNVEksNazxWxzVHAyehanOiFqxeBePsRCrFFyjeIYgEAaYwAPLQFTsgZkqLHKVegPmOkcprzYqanidnCedUMaKxHsJDjlvZZPnaMQJIeNgzJiOrlpSLECAXevhwIJntrcpStxaZKiFPxVScjAxhSkiwZAkLQShhxmQkDPxtABKYYaYRAPBbtQVmsZjCpBNuuyinPGPApSmGbnibBthjPaFN");
    string JRKNHChCWLGnvns = string("UHZIhAZhPjTNnJrPGEgySOyeaZUAgirCnmsRJnQVNVkHQCpqCUwHmlDuyUnlObPHKeFrPGYnrnvwDwSPcgayLHtXhbjyYZpBhKZLtyxjYYCgHHbFVkuKL");
    int DWoqZiWCoKgEdhyj = -2009033437;
    bool yGTdYmSQF = true;
    double EmTwyMXkHeJSE = -178450.0619113319;
    bool KFamE = true;

    for (int PhNBvf = 2028870771; PhNBvf > 0; PhNBvf--) {
        FtIDGBqQemmThjhx = yGTdYmSQF;
        yGTdYmSQF = yGTdYmSQF;
        UlWhdLdQsdlsY -= UlWhdLdQsdlsY;
        yGTdYmSQF = ! JFnIKYlFMDsRG;
    }

    for (int JFscX = 1250947063; JFscX > 0; JFscX--) {
        KFamE = ! yGTdYmSQF;
        JFnIKYlFMDsRG = ! yGTdYmSQF;
        EmTwyMXkHeJSE /= EmTwyMXkHeJSE;
        kxGPhMjerW += JRKNHChCWLGnvns;
    }

    if (FtIDGBqQemmThjhx != false) {
        for (int sXPWFiYT = 720010358; sXPWFiYT > 0; sXPWFiYT--) {
            FtIDGBqQemmThjhx = KFamE;
            JFnIKYlFMDsRG = ! yGTdYmSQF;
        }
    }

    for (int eOnycSAqDaubOdU = 1542509986; eOnycSAqDaubOdU > 0; eOnycSAqDaubOdU--) {
        EmTwyMXkHeJSE -= AWgew;
        JFnIKYlFMDsRG = ! KFamE;
        yGTdYmSQF = ! FtIDGBqQemmThjhx;
        KFamE = yGTdYmSQF;
    }

    return DWoqZiWCoKgEdhyj;
}

HaWuOEfsjRNgbOj::HaWuOEfsjRNgbOj()
{
    this->WMJFJPBUlgTadHjY(-622897.4168590776, 1517520509, true, 1964726338, true);
    this->bfEtiGEzabFGreaB(string("IVitAlYcoxSWgSMOpYnwDMHyLYVHMEYUrFWlSHMHaCZFnSWuNijFxfeplLtzrLLkIxeCMhOOnZnLbuupIeYTUNpTpNKyBtWgJMpSM"));
    this->knyVyvZRcopBVNa();
    this->bXBtlmRg(true);
    this->ADEythzclmqfH(444256.15855204844);
    this->wZfAJclToeMSE(string("rfYSgnnqeHLZTMTqLOekYsJZRvyqMVjAfNCsVlMoOvfctiVLjsylhgFGCiAheERNNJgPqnbYidlgsCHWzfLmdHYiVsBcGLRDzwljKPyucQWqtoHBMqHAEYTzfwVezLVqZucWHNxFtIfEKRsvsNcfdtIPQbLLFvMuMBQQlDtSKgUfSIKLEcYiafTwBLpKVDpkToGTyZwaGUTJkejZfUXuLK"), string("TIjJoMdHXtBrqYhanVbLxopmrsMJUtg"), string("AOxRAHeCSzPpmLXoalsLEoqsxxtQMTPuRMQjrexTNnEUNSqJwEIhnFFAcAgXtRzumwLjfeMfuFABzzakFzngzcEtRmOEUJAtbZgBItfUSDnjcHnbJtgVgtAJNYguwMLjZqlzxZDHwZXibDBKZCGYVxSbbcaGoEhSjImVFcBgKNKmzyUpLepXSQZZFyyXvPcpONiM"), -302100784, -1039833192);
    this->bnTuFOWxTKchVSlx();
    this->vRxgpIHbeZjOe();
    this->OAexTNCjlV(true, false, -1187525446, false, string("vmCfgPAdBqUVkaxfkAbHVowyfUEGvqhTJahgjMtaJYlpnXgxOSlrhYHuAHEbPAPjyMVspQOPCxuYqOAOKrYUeJWHfjNnTrYCjOPDsAXYxQATFCUuxwocCUdvqMRVowUZeJpjGBaJkqCknIcNOzmkzsdEQoRntxEkIKHgeqQjDUWtkWUtSolhOHqLzvKkdKVbq"));
    this->AjauKPxIqxUFJn();
    this->rzqDZCwPoIHiqtx(-2054686698);
    this->HiSoZLTNqiRzi(false, string("zqTxJnWjJOEyhlxlqNHGvGHbmLVoAMXvchZMPJRcfVpjBLgSyyjZYpMAnvzpUYDVUcRXJKNlKNDdKHmnitJmzClzeNMNuuswEOzJIRroQnLjTXgbTAvGVulfrGIhzRllelesDCscYHNrKzVPTZfMdLNEmiKDHBsLHBiCgAE"), false, -255018471);
    this->PBKTFDwlgduG(-784752.1396761927, -31508.06858546904, -2110548711, 229954.48842963565);
    this->pDrjipaStJW(-844720309, -129215293, string("QwdiXwzJMacPzSEFIKITSgkhrFfdMBeOpmlHYkcVClQiwaSRadbmYaKYXnHyecnMFMoohoBiDRPRITRkaRqvGnaFjSYSPpdQqEpAgDvNJcKAtEBPLUZZsGgsrsJykESBKHMeWPbRYanohtPxYawtFxZkHRBUcyRVjOwSpNgBDGcrnZlMZwAeMfZBoxravBYABFJzZn"), 445582.09542753926, string("z"));
    this->sWygWcNMLHD(string("WipCBpQodjjYUcnodjyQEWcXdMhFkPsvYuESliBxoQSMnTODkVrUjQGNbvPfkTBBXwqLpHSOTujkAHqRgyYWnJZTClTiYLiSbmsLhnaoKBYuKdWFtqiofOhvXVEGnJYxnPSUHZUwMmZQoqCPPDthmKGakwgTTGWCLNgsFmZGJPiQLPTCPauaWPmJBaVFhZruGqAAYkBDfKcNHtZVxmDQaBoKwlVGcZUFXdtFeDnkiNwpG"), true, -2092752905, false);
    this->fgOfiTmcvbVB(-281999.33660312137);
    this->NpYBuSPrt(355771.52883519337);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vhRzboFrNnCnxJm
{
public:
    double sFgOGParSoEnrxU;
    int DxJXVTAAOhIDCV;
    double BBineAYireRIgTu;
    double qXvhPbTYpDgLdH;

    vhRzboFrNnCnxJm();
    int qDFUiERxEslxS(string gchseyqGDrjf, string TxHTxMp);
    bool cMEgRZVQ(int IwBVVdJQEiIh, bool OnicRTxTmWoPxfVr, double FoQVsatSURMYYBA);
    void qudvh(int QXYXttnv, int wpKDKyv, double RGTGQl);
    double BypRDZXFnI(int kHrdWqBAm, double wQFwX, double WcWfCMAKsxpaZvTo);
    double jmfrxwneHJwBAWG(double yOsevtwvbmmt, bool MDreIF);
    double KxHrFuWEMuRCZkLN(int qAPktpFPAYhcqrj, string QuDUV, double uDJCLGgTXGQ);
    bool RGypDHCJY(int QohZhhUvv, double PIhoiBrWnCeQ);
    string zifXiCNPrVcNVy();
protected:
    int lDsuhlUmJzpNMcdE;
    double WlPPAgyScBRLQskI;
    string gPAbHhU;

    int smirasHnCwloT();
    double ZRiDtievDMu();
    int imicnrvLyVaQv(double HKLMy, double lIYvKh, string xmSgesKBHPxmdU, bool swJmb);
private:
    string ZCvVKtDl;

    bool ajNcaCg(bool fOIyiEvcHZYcoJmm, int fqGpTOr);
    double jEOHfFUvfRSy(int YVkAiViRbVPKX, int ABahDB, string xgFyNo, double hQlrgI);
    void AwARlxisauqNtR(double WqvUL);
    void UeAyogMPHLQ(string kfexjfRhHZB, string KsOIsDfvTPJC, bool eSgXJCYsU);
};

int vhRzboFrNnCnxJm::qDFUiERxEslxS(string gchseyqGDrjf, string TxHTxMp)
{
    bool HnnqeZ = true;
    double UoyOae = 924963.1673692382;
    string ehAZOjljiQKyMO = string("EEZutPqqWhPfcThrHlMQeVjUzeweyazFFkqztegMXLKhHIvRPjswaoMXEGPgRulrWlsZtamDAnppxSLnQrfnTHnnbzAlMHmdIPFDIyzRmrBunSJOYlYUzqfBFjyyLFmeYaQHdndaXMpNXkOnNVmfMZPjQCsnUnwXorycCHgOxxZHzLpcBvVRTNqWnxcDMgnTFWomMbeIqfDHze");
    double PdNJohtmFCknrfAk = -302753.0936777506;
    int ENDHHqipH = 973328226;
    string sxWuy = string("tglzPadgDtlHGDYIsXIfhWRPbHseQbHesNKfNuwUhUcGIyFPTsZxgwjwtExnGoDHpARcoBdpqXUKpuwKLECsWaWoLyvSpfQzozMPivPPaLTNplPvLhiKAIzyPdgaajsdEOjBhOIgFViCAFgmQjEwqbVQUSWPmcPYmmAMrImJfgITWSsUenxZOOLbMSYmJtwxgDObcNuXMCzjwPddHZpGwoMkCwxzmlYkGOoSXPaNSPpzCP");

    for (int tntoRI = 1709659462; tntoRI > 0; tntoRI--) {
        ehAZOjljiQKyMO += TxHTxMp;
        HnnqeZ = ! HnnqeZ;
    }

    return ENDHHqipH;
}

bool vhRzboFrNnCnxJm::cMEgRZVQ(int IwBVVdJQEiIh, bool OnicRTxTmWoPxfVr, double FoQVsatSURMYYBA)
{
    int xWERwNMDG = -2019813253;
    bool xeNoftpDimoIYt = false;

    for (int nBzmVK = 634523606; nBzmVK > 0; nBzmVK--) {
        IwBVVdJQEiIh -= IwBVVdJQEiIh;
        FoQVsatSURMYYBA += FoQVsatSURMYYBA;
    }

    return xeNoftpDimoIYt;
}

void vhRzboFrNnCnxJm::qudvh(int QXYXttnv, int wpKDKyv, double RGTGQl)
{
    string mirEeELey = string("TqJlVseKEqFmTkkjxYCYUQeKgcxDNCKNYSsVVFvZTHFDYZJashORurMriViyiiqATtvVftylRZAQYefuV");
    int hItlkzR = -1159047241;
    bool PQNopyBZ = false;
    int DxAsuY = 1385881311;
    bool SMjhaUpaiLObWDqh = false;
    string peCmsEqQeXomwOHD = string("kPviLHL");

    for (int CRnYetImQdw = 834239069; CRnYetImQdw > 0; CRnYetImQdw--) {
        PQNopyBZ = PQNopyBZ;
        wpKDKyv = hItlkzR;
    }

    for (int ZOQZqvy = 1432927144; ZOQZqvy > 0; ZOQZqvy--) {
        PQNopyBZ = PQNopyBZ;
        peCmsEqQeXomwOHD += peCmsEqQeXomwOHD;
        RGTGQl /= RGTGQl;
    }

    for (int CiesJEjJODHhf = 1063865406; CiesJEjJODHhf > 0; CiesJEjJODHhf--) {
        mirEeELey += mirEeELey;
    }
}

double vhRzboFrNnCnxJm::BypRDZXFnI(int kHrdWqBAm, double wQFwX, double WcWfCMAKsxpaZvTo)
{
    bool EeNoaitOdcGGr = false;
    string UKGSFOTxZXScR = string("IXaqoomNwlewGBJdgOzEXXDDsCqlPWSDVCjIndcGKMTwcjxiIBLBSLprtHHYzLsIBwuVLuNEvlfwnaBlenIqKkwgmnhHOUdiDuiXsGZAzgiIFogvKsWpVvFqDxvrpJTkywzNLNovuHIxLnKEvSqbdgagylUgGObWiRjNmqrFjOuMjIjyRrmkWhlMZDLAMkEQnMfBJcqLebyILhZMsoaTPYWOpKLWoYlobWwzo");
    int xgkLsw = 1968974244;
    bool RuXHmt = false;

    for (int HfQAl = 151826952; HfQAl > 0; HfQAl--) {
        wQFwX *= wQFwX;
    }

    for (int hpLxZ = 580090951; hpLxZ > 0; hpLxZ--) {
        RuXHmt = RuXHmt;
    }

    for (int tSuYk = 641666866; tSuYk > 0; tSuYk--) {
        continue;
    }

    for (int xfvNTOHdsxHk = 1516227362; xfvNTOHdsxHk > 0; xfvNTOHdsxHk--) {
        continue;
    }

    for (int sdECJZOtYGkvJ = 796432355; sdECJZOtYGkvJ > 0; sdECJZOtYGkvJ--) {
        kHrdWqBAm /= xgkLsw;
    }

    return WcWfCMAKsxpaZvTo;
}

double vhRzboFrNnCnxJm::jmfrxwneHJwBAWG(double yOsevtwvbmmt, bool MDreIF)
{
    double KuXQWJ = -912442.8113124089;
    string tIucPrB = string("iybyeYjhUlWfSOqMODfRmckqDwTtHffXjQeuETYpgvjMjfGxlLmkYFcCHhbQRvxSKSFCzgUMSTNelBKjkszMibWaBmweOJJSJqUdSxvCfFFhIpOdLyAmXMmewlKvnLaMzAQoEHNYaqdUOzuIgBGPXAqPtbMcTEWyvhBDqoSjKabPuhdaineowsSSpoGhfmRPxIeHPtFZVNNUVdteKgLhOvGRPyjZgGxtmEkNKQMDtltWC");
    int mefvzkamyv = -1155444351;
    int RexiJFICuSYrqpYd = 757427491;
    bool xLoPaqMlqJpwGR = false;

    for (int ijbwqkyvrNn = 1266373869; ijbwqkyvrNn > 0; ijbwqkyvrNn--) {
        MDreIF = ! MDreIF;
        tIucPrB = tIucPrB;
    }

    if (RexiJFICuSYrqpYd == -1155444351) {
        for (int MBGzvbWgGJsJJWA = 1110477948; MBGzvbWgGJsJJWA > 0; MBGzvbWgGJsJJWA--) {
            xLoPaqMlqJpwGR = MDreIF;
            MDreIF = ! xLoPaqMlqJpwGR;
        }
    }

    for (int JHgjDOeiX = 1036117604; JHgjDOeiX > 0; JHgjDOeiX--) {
        yOsevtwvbmmt *= yOsevtwvbmmt;
    }

    return KuXQWJ;
}

double vhRzboFrNnCnxJm::KxHrFuWEMuRCZkLN(int qAPktpFPAYhcqrj, string QuDUV, double uDJCLGgTXGQ)
{
    double RnVSm = -534293.8460959685;
    double icrHTYUpUy = -866814.8570085444;

    for (int ojrWsOdOXWnQoRGv = 816775062; ojrWsOdOXWnQoRGv > 0; ojrWsOdOXWnQoRGv--) {
        icrHTYUpUy += icrHTYUpUy;
        RnVSm /= RnVSm;
    }

    if (qAPktpFPAYhcqrj < 1459954419) {
        for (int oCNoPzyJIzuCgJl = 1758223997; oCNoPzyJIzuCgJl > 0; oCNoPzyJIzuCgJl--) {
            continue;
        }
    }

    if (icrHTYUpUy != -534293.8460959685) {
        for (int ajsThlYoIhbqyR = 1142353230; ajsThlYoIhbqyR > 0; ajsThlYoIhbqyR--) {
            QuDUV = QuDUV;
            uDJCLGgTXGQ *= uDJCLGgTXGQ;
            icrHTYUpUy += icrHTYUpUy;
            QuDUV = QuDUV;
            uDJCLGgTXGQ *= RnVSm;
        }
    }

    if (RnVSm > -866814.8570085444) {
        for (int DdSmdgbc = 1019517455; DdSmdgbc > 0; DdSmdgbc--) {
            uDJCLGgTXGQ *= uDJCLGgTXGQ;
        }
    }

    return icrHTYUpUy;
}

bool vhRzboFrNnCnxJm::RGypDHCJY(int QohZhhUvv, double PIhoiBrWnCeQ)
{
    int WRmgDbK = -1903711283;
    int aTOqAZeSkq = 1027285885;
    string zbuWUETkby = string("La");
    bool WYXvc = false;
    bool EUjcikABkE = false;
    bool rUqCSquAOrcXty = false;
    string sFGJLbhPB = string("yhCSVacBqtnbDMpNKDjkOUXiAKXWTKSHMZlzdyCOhSDwesRFztECnJzUaTAwPeKMbBHZNbMYilxgLYcCxOaqRurCAMQOqxTECmhIgCuzVURPUsBdeeRuQCAYbkXIQOYFLNWhcsMCmaSqAXImarpmgxbyLLyCSTQaSSRQORAwvvilYwoPOwAudVCKSDWmjAfvGiCoIOj");
    string ExokpVEXrvfrE = string("lOplaEumEPOqeLvjLmCFbmVQkfXoJcy");
    bool iQILNGsfjpBX = true;

    for (int fosFc = 79809686; fosFc > 0; fosFc--) {
        continue;
    }

    return iQILNGsfjpBX;
}

string vhRzboFrNnCnxJm::zifXiCNPrVcNVy()
{
    string YmrIHvStmRXHwSNX = string("WVxYOPNoJdDXGPAyBcumMLbjUCkVaMQlDpVyLjsnatnOcUeewDugIwBUGncKnrNrfQLsROniqqlFNkzWlaFyQXThNDlWJDlXsHwLTJZKgs");
    int GtDqam = -1697834683;

    if (GtDqam >= -1697834683) {
        for (int bXErXYshLQKnq = 2025770006; bXErXYshLQKnq > 0; bXErXYshLQKnq--) {
            GtDqam *= GtDqam;
            YmrIHvStmRXHwSNX = YmrIHvStmRXHwSNX;
            GtDqam += GtDqam;
            GtDqam = GtDqam;
            YmrIHvStmRXHwSNX = YmrIHvStmRXHwSNX;
        }
    }

    if (GtDqam == -1697834683) {
        for (int gEnDnys = 612998924; gEnDnys > 0; gEnDnys--) {
            GtDqam -= GtDqam;
            GtDqam += GtDqam;
            YmrIHvStmRXHwSNX += YmrIHvStmRXHwSNX;
            YmrIHvStmRXHwSNX = YmrIHvStmRXHwSNX;
        }
    }

    return YmrIHvStmRXHwSNX;
}

int vhRzboFrNnCnxJm::smirasHnCwloT()
{
    double avBrexOZdJgHiT = -795779.9439668783;
    bool BiwTiutWyAE = false;
    string LsLOwxIi = string("SOAuFpnyjfidKybiwyaeTcHVCRdhIygelxqCLJaIVTOpsrdyMAilMPYJCbKGcRlaMAzgShVxcjLHTsgcvzwCzMXzJSLNDTICuHmAmOYGLqTirbythzEGU");
    bool LGLypvrhW = true;
    string lJCiMPGSQ = string("UBDiEcCrFXkRMFHAEEuQyG");
    double NWFvhuiVGUmj = 656587.1753607311;

    for (int nLgqqrhY = 2117239437; nLgqqrhY > 0; nLgqqrhY--) {
        LsLOwxIi += LsLOwxIi;
    }

    for (int tFSJJcYjeyzrNhlY = 2069625178; tFSJJcYjeyzrNhlY > 0; tFSJJcYjeyzrNhlY--) {
        LsLOwxIi += LsLOwxIi;
    }

    return -578893984;
}

double vhRzboFrNnCnxJm::ZRiDtievDMu()
{
    int mOwVoiAse = -151841298;
    string GebpCZJbJeDjkC = string("qsjYwpwIPFEyqOadddJAOFmpTfWhggISWlUvbfrXDuhKtfIkjUDCqdOxwveeqiDbzuVGhSqTdklZGPaOwXExoVXYQbBghUnDFSegBjCeDYeotNqGgYdpUcZXdrecOXmtrBdDJMoZJHNACaBwGbrLdUPoAXLAFR");
    bool deEFKHQInCAzD = true;
    int ZiOlangLzFKrIG = 78923751;
    bool zGGOfkA = false;
    double ABUlqjXVSLbEWz = 582005.2964679967;
    string IwGKJR = string("QelGSxhXWFEbAcsjZIzHAqMIaraOPvsHlHzDCXYSFIudAXwUQYxCOSBsTRfWxgCHpxLuWzXCGoLyJrWqakrHZFsgzqerEXoIvNEHYgcHdIOjRYrjswcUORPSSClURrEkiPxevoSIqhPI");
    bool amhycbUbn = true;
    string zijugxz = string("XAFfMPDTAsveJSwpCqShMOtFNOZRhLQxCOryPjBRFILWkXOGSjHJdkgtVXJbZqllHeAUSNDihLeJxDHUFGCVUWrQBBgpenCnhpuINljmGYXpoUGSwdRFVuAcLDEfVHwSsJSIQaczDSvuRiOBSxrQwSkoruruddFNniKwbYtBSJfHbfFbNEXK");
    string gTaLhjDmq = string("dVlodfRiEgmWVxxCExjRwVlkPVOUWHhMUAgpPxwmoPbAzcpbLOrUMXusAroihzhyXEvWFNBYTNTgdreHSRdTCjuwdGeDnbEfidBTrFlQjiVlIuwnFGJTGHsHMUbdTuGalxInquGmJULZV");

    for (int kOqgMciBXH = 552804793; kOqgMciBXH > 0; kOqgMciBXH--) {
        IwGKJR = gTaLhjDmq;
        ABUlqjXVSLbEWz -= ABUlqjXVSLbEWz;
    }

    if (IwGKJR > string("QelGSxhXWFEbAcsjZIzHAqMIaraOPvsHlHzDCXYSFIudAXwUQYxCOSBsTRfWxgCHpxLuWzXCGoLyJrWqakrHZFsgzqerEXoIvNEHYgcHdIOjRYrjswcUORPSSClURrEkiPxevoSIqhPI")) {
        for (int pOibGCjrWGp = 820312726; pOibGCjrWGp > 0; pOibGCjrWGp--) {
            deEFKHQInCAzD = ! amhycbUbn;
        }
    }

    return ABUlqjXVSLbEWz;
}

int vhRzboFrNnCnxJm::imicnrvLyVaQv(double HKLMy, double lIYvKh, string xmSgesKBHPxmdU, bool swJmb)
{
    bool HOVWRfdQ = false;
    int kVEQbmlaBywVVyA = 1141958918;

    for (int pyBfQaGGc = 797113530; pyBfQaGGc > 0; pyBfQaGGc--) {
        swJmb = ! HOVWRfdQ;
        lIYvKh += lIYvKh;
    }

    for (int mmdnXDORJMdcbcRC = 1435267432; mmdnXDORJMdcbcRC > 0; mmdnXDORJMdcbcRC--) {
        kVEQbmlaBywVVyA -= kVEQbmlaBywVVyA;
        swJmb = HOVWRfdQ;
        swJmb = ! HOVWRfdQ;
    }

    for (int pTeMgS = 302791127; pTeMgS > 0; pTeMgS--) {
        HKLMy -= lIYvKh;
        HKLMy = lIYvKh;
        HKLMy -= lIYvKh;
        kVEQbmlaBywVVyA /= kVEQbmlaBywVVyA;
    }

    if (swJmb == false) {
        for (int ddZItrWWW = 852705277; ddZItrWWW > 0; ddZItrWWW--) {
            continue;
        }
    }

    if (HKLMy == -14322.672390505035) {
        for (int sTHECv = 331921835; sTHECv > 0; sTHECv--) {
            HOVWRfdQ = HOVWRfdQ;
            HKLMy += HKLMy;
            HOVWRfdQ = swJmb;
        }
    }

    return kVEQbmlaBywVVyA;
}

bool vhRzboFrNnCnxJm::ajNcaCg(bool fOIyiEvcHZYcoJmm, int fqGpTOr)
{
    string GRMkMavRdLsxHT = string("bLxYbMllFbcfeNLqcFAJPBKMqMqihqeTjazMLeLNjqwHKaJKLeLmiOfkyXLoykCSSduOjLPQKFVCeHTwxcaZZrOZBvDFoeLVZbUKVgodZZdftFaimzIYvzqNcXGmDRnpYmtXEKsZVyXCTPIiHoTrGugXbkTzyVFTBO");
    int epwvZdelg = 1458053244;
    string PjHeVvENSIMB = string("tDowqeQphNnvlukZQJQZRUrfINHAubzDSsVeXVBUruWSAvFXoLPxNERnzqBznkbLTqfdQBbPsbWTnCtTpFFjEsURAArIEydhczDPqDEsWcXIlNqX");
    string GuRabD = string("QbGXEKQavZAdTmBlfZqrbaZyPQzIQAGPuxctCGFoAbdzJ");

    for (int WtQuSNUGQUtScnk = 1495281498; WtQuSNUGQUtScnk > 0; WtQuSNUGQUtScnk--) {
        GRMkMavRdLsxHT = GRMkMavRdLsxHT;
    }

    return fOIyiEvcHZYcoJmm;
}

double vhRzboFrNnCnxJm::jEOHfFUvfRSy(int YVkAiViRbVPKX, int ABahDB, string xgFyNo, double hQlrgI)
{
    bool FtOZvxHqjNrpcdSo = true;
    double eJuIBqRdif = -253703.08408201783;
    double lfSqvizAUW = 206495.91407239137;
    int QNWKYlBOIcA = -890005769;
    int OdbjLLOYaiBgMwbg = -464576055;
    int IWLfRhPyPhbZJR = -518027859;

    for (int DDAebRp = 283455511; DDAebRp > 0; DDAebRp--) {
        OdbjLLOYaiBgMwbg *= IWLfRhPyPhbZJR;
    }

    for (int ScXhlScqOFXALNib = 240253748; ScXhlScqOFXALNib > 0; ScXhlScqOFXALNib--) {
        hQlrgI += eJuIBqRdif;
    }

    return lfSqvizAUW;
}

void vhRzboFrNnCnxJm::AwARlxisauqNtR(double WqvUL)
{
    int JHyXDftLu = 1358333684;

    if (JHyXDftLu == 1358333684) {
        for (int CkFllUpXwRrAn = 1863474784; CkFllUpXwRrAn > 0; CkFllUpXwRrAn--) {
            WqvUL /= WqvUL;
            JHyXDftLu /= JHyXDftLu;
            JHyXDftLu *= JHyXDftLu;
        }
    }

    if (JHyXDftLu != 1358333684) {
        for (int qZLnXzoGhIVHIrj = 519976715; qZLnXzoGhIVHIrj > 0; qZLnXzoGhIVHIrj--) {
            WqvUL *= WqvUL;
        }
    }

    for (int lBzlKsGmAFhmQI = 963161123; lBzlKsGmAFhmQI > 0; lBzlKsGmAFhmQI--) {
        WqvUL = WqvUL;
        WqvUL /= WqvUL;
        WqvUL = WqvUL;
        WqvUL += WqvUL;
        JHyXDftLu /= JHyXDftLu;
    }

    for (int pBJMlEwXxDZF = 256656353; pBJMlEwXxDZF > 0; pBJMlEwXxDZF--) {
        continue;
    }
}

void vhRzboFrNnCnxJm::UeAyogMPHLQ(string kfexjfRhHZB, string KsOIsDfvTPJC, bool eSgXJCYsU)
{
    int kquxWWui = -1300904393;
    string YkwTgeyuBTOn = string("etkoDBYmJRCguHvdIKVbwjIeXxzhhoVHGLnpxbNFXzybkkivrnoheXvDuBWobZSKcpdGUYQLDBJBcaxVHmaZeosxHGqOFzDKHSBFDNXnrbCmvZlwgAvkLGSeSZLbXYMkuRGVtGBOJJCVNGmRciIiGTURzgWqretqxSAfvzhYaYyvCUKmeoVOVEKXjxKOHGkGbiPWLzDGHbUWvQShGWYTtXjDzfpbvaXuqlGpFfNxXPsu");

    if (KsOIsDfvTPJC < string("ZOBSYwWTnDBZdInyRzgNcHuaAImeknaOrmZNXXVsIZmmIqwyDrgnouDhFhqzBZeiIAUulorPjbPLzGUAbufBWpXGhrYtAtJctZFVpYDEvZPNYbAUQfVsNqilQHqwKCwLelWdsgkBoRKejWNooe")) {
        for (int ugVHHBqfxmcS = 788330259; ugVHHBqfxmcS > 0; ugVHHBqfxmcS--) {
            continue;
        }
    }
}

vhRzboFrNnCnxJm::vhRzboFrNnCnxJm()
{
    this->qDFUiERxEslxS(string("HWdmoyGOIffrGZyBcOhNDOzGtzMLPTfuSWFKdczgkLiZuIpYYubqByQHwqCNtDqPwQWaJEAEFAvgKYKUYWbnSBbPKIxnOAnTpHJxgRNuqcKQzueKqJVXKppWHEoKKeTDtLYbRROLEvFBIdmhXgitxHLkKehFuKEFacpvAWjKWdRkiaBwjoAVnqRfBZNQOaKWTlheHpkIuZBOzzie"), string("YxAxwBmBrTqxGJgrToVOWdKlDLqgXwosBuFpBMcUTfWZmvjiXxqURtAjrFlTNEXFrcOPpTyCTgrEslswvdXQwJWdWkRFWJNgieFDAaCCuHOEXPwTmENgOzsBSRntgh"));
    this->cMEgRZVQ(-68972078, false, 902021.6224422189);
    this->qudvh(-153339436, -1671945881, -864072.1892415006);
    this->BypRDZXFnI(-1719203042, -1027277.2623307026, 401157.5304921482);
    this->jmfrxwneHJwBAWG(-412080.5632775964, true);
    this->KxHrFuWEMuRCZkLN(1459954419, string("eVYcETKHJmTgXBZLlkdHpTSORaQvUBLtWADyCcQlqErLAOIYWCZaISjCVCTalwfkyTYjggnukudXyfOUjfwLQyElMIzsCaudrHNUdnLYrHdpIjjlncoIvpriDnzfeDHqtgxfUNnZePjXBEJUKBrzKnWjFbPjhrBSBEKsHorEWSnPLRsgEPJCZWXrpjlIaJWlat"), 435923.48859015707);
    this->RGypDHCJY(1803267557, 894733.2877438966);
    this->zifXiCNPrVcNVy();
    this->smirasHnCwloT();
    this->ZRiDtievDMu();
    this->imicnrvLyVaQv(649824.5396136512, -14322.672390505035, string("nBKMMiUlKVemcMcjwsNqmbulRTHTIZChxKUTuTobIzWxaRRvfPbmLXBVRqRJwBbRfTJUwdFDXTdZdaMdNBaayersQmaBboyOaSTbizvMeSKitWywNzHHWfVoLqxxPMTY"), true);
    this->ajNcaCg(true, -182913889);
    this->jEOHfFUvfRSy(1384956866, 563371994, string("SmaJzQDNvAeTUPyAcDPzjXYmtGIWwpYwXdvtkBvVzDKjyJkygdpMceRZizxCvyEWJDIqiOvJpARp"), 676682.7160531434);
    this->AwARlxisauqNtR(-43758.912264809725);
    this->UeAyogMPHLQ(string("ZOBSYwWTnDBZdInyRzgNcHuaAImeknaOrmZNXXVsIZmmIqwyDrgnouDhFhqzBZeiIAUulorPjbPLzGUAbufBWpXGhrYtAtJctZFVpYDEvZPNYbAUQfVsNqilQHqwKCwLelWdsgkBoRKejWNooe"), string("JyRpFuGWdHKKyFlFLXmnNkpyQIMYNBeacFoEQWMrmzmIHcqwGyySvTgexvirPcozlqWKaAQjZIACRdtGKSEyQZXHkbOfXqPXvxCGuvpGllxykHAFy"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zhlarX
{
public:
    string ApeIRHHJD;

    zhlarX();
    bool ZJtGazylcnyw(bool DTvZwCmzIog);
    void FCbDsx(string lQguqKdS);
protected:
    int IOOlL;

    int GBjYLPKT(int JskYVTORjH, int bMWOV);
    void GfwtNcmfmJWwtSF(double IEtPnJGvMDXciVw, double ebEwqPeJKF, string UzHKDdoglq, bool ZVxWccyXUIjqp, double GAztKd);
    int eehJQcGAxPAlho();
    int UDycGBoOo(int ywyAzclLO, double TxwdwmcX);
    double MZqphB();
private:
    double yvYtP;
    double DoIoTIrMooidLmS;
    double TgZtrcRAWqvw;
    int VjilEANjWO;
    double XfNyuzv;

    void SljePgo(bool SnkzzkVJdzyzGKx, int dVPDi, int DvXpxL, string PFwGkNxXmACVRfR);
};

bool zhlarX::ZJtGazylcnyw(bool DTvZwCmzIog)
{
    int GchYUmlZ = 267729002;
    double JRmzxCDQvYnSmpl = -134572.74183082097;
    string qHiUpolABlSw = string("ncmrjvONTLqBigVUTdQuiqqNgYDVGZvzayEhYEqFBdWPkYhzKKFOeGPHsTQxcRJLIitSONZOXbhTaFsZImZRCOSBDAwPgAlhLTbdCmEtxkGKdpBCnkyjpktJVTHiKjpqiUoaaepeWhtvFSuWwPPXqgywEhhyMGDeddVqgcqKnKaHxcTbvgKUhmURnLUVjJyeMrthGvAcuDFXRdwCzrthlSRDUGTPhStJsWwNqbNWraJF");
    double QtSvrzUQmkpc = 933489.557781133;
    int nzxDq = 1187055815;

    for (int dIWyJHJj = 798966987; dIWyJHJj > 0; dIWyJHJj--) {
        DTvZwCmzIog = DTvZwCmzIog;
        GchYUmlZ *= GchYUmlZ;
        QtSvrzUQmkpc -= JRmzxCDQvYnSmpl;
    }

    for (int VblcGPw = 2079525515; VblcGPw > 0; VblcGPw--) {
        continue;
    }

    for (int kttsn = 1655270521; kttsn > 0; kttsn--) {
        JRmzxCDQvYnSmpl += QtSvrzUQmkpc;
    }

    for (int dpVaiTY = 869939449; dpVaiTY > 0; dpVaiTY--) {
        continue;
    }

    if (JRmzxCDQvYnSmpl != -134572.74183082097) {
        for (int OWuWrsc = 2116660500; OWuWrsc > 0; OWuWrsc--) {
            GchYUmlZ += GchYUmlZ;
            nzxDq *= GchYUmlZ;
            DTvZwCmzIog = DTvZwCmzIog;
            qHiUpolABlSw = qHiUpolABlSw;
        }
    }

    for (int vwPjDxNpSdTUoQ = 539989252; vwPjDxNpSdTUoQ > 0; vwPjDxNpSdTUoQ--) {
        GchYUmlZ += GchYUmlZ;
    }

    for (int ZQeDkwGcf = 670017213; ZQeDkwGcf > 0; ZQeDkwGcf--) {
        continue;
    }

    return DTvZwCmzIog;
}

void zhlarX::FCbDsx(string lQguqKdS)
{
    int ocHlAUbUpTtt = 1084252041;
    double lLXRU = 584059.3656591913;
    bool imAjinIQWKwDl = true;
    double YUcZPGIUp = 937002.318230129;
    string SDclQCDWVAUnKjKC = string("QRkXmzTaJqOkFAQgpMvSDihLvlSGbwUmBNUQwsdVUoQkcRkFtYMvpRqpP");
    int KiRPZWGDB = -110973623;
    int uAAEiaYqrfGLQr = -1849935059;
    string XvPyxd = string("RlyQBefkZxpRcAUtRibjvnmeTvsJtdUvMtDphtjiqNPHFjtVWKvkzATDTCfKZnGOJYYkkOJOmcmbicJPLEeGdCmZVntRIYuAVuzVubquOmHbpTiYxWScDeTfKkSvXWhxTeBGZYJVhBREQisJgJYrZaxAqkiaAOVVVWNivglZNWvgszVfVHOsfVjhiuSdLzXRJkRwgAnC");
    int fXaQxh = -1322018388;

    for (int SAeecJSz = 310785278; SAeecJSz > 0; SAeecJSz--) {
        KiRPZWGDB /= ocHlAUbUpTtt;
        YUcZPGIUp *= lLXRU;
        ocHlAUbUpTtt *= fXaQxh;
    }

    for (int hxaTeNcof = 858491601; hxaTeNcof > 0; hxaTeNcof--) {
        uAAEiaYqrfGLQr = KiRPZWGDB;
        lLXRU = lLXRU;
        fXaQxh -= ocHlAUbUpTtt;
    }

    for (int sNdbzyoRand = 776803832; sNdbzyoRand > 0; sNdbzyoRand--) {
        fXaQxh *= fXaQxh;
    }

    if (SDclQCDWVAUnKjKC != string("RlyQBefkZxpRcAUtRibjvnmeTvsJtdUvMtDphtjiqNPHFjtVWKvkzATDTCfKZnGOJYYkkOJOmcmbicJPLEeGdCmZVntRIYuAVuzVubquOmHbpTiYxWScDeTfKkSvXWhxTeBGZYJVhBREQisJgJYrZaxAqkiaAOVVVWNivglZNWvgszVfVHOsfVjhiuSdLzXRJkRwgAnC")) {
        for (int lzipzqhf = 331743223; lzipzqhf > 0; lzipzqhf--) {
            SDclQCDWVAUnKjKC += XvPyxd;
            lLXRU -= lLXRU;
        }
    }

    for (int lFZuOwhpFpX = 108537309; lFZuOwhpFpX > 0; lFZuOwhpFpX--) {
        continue;
    }
}

int zhlarX::GBjYLPKT(int JskYVTORjH, int bMWOV)
{
    double DmTxg = -637458.0383039435;
    int qxvzqlVuvWivc = 436681495;
    double bqAsnQKbH = -173263.99072178695;
    double pgCYsVyIfH = -826285.3755914919;

    for (int FbDlc = 2100932057; FbDlc > 0; FbDlc--) {
        pgCYsVyIfH /= pgCYsVyIfH;
        qxvzqlVuvWivc = bMWOV;
        pgCYsVyIfH += bqAsnQKbH;
        JskYVTORjH /= qxvzqlVuvWivc;
        DmTxg *= DmTxg;
    }

    if (qxvzqlVuvWivc != 436681495) {
        for (int IRvnTIYYGVEu = 1793645941; IRvnTIYYGVEu > 0; IRvnTIYYGVEu--) {
            JskYVTORjH += bMWOV;
            DmTxg /= DmTxg;
            qxvzqlVuvWivc = bMWOV;
            bqAsnQKbH -= bqAsnQKbH;
        }
    }

    if (pgCYsVyIfH == -826285.3755914919) {
        for (int bMtgNqbyWjjELMW = 320093749; bMtgNqbyWjjELMW > 0; bMtgNqbyWjjELMW--) {
            JskYVTORjH += bMWOV;
            qxvzqlVuvWivc = bMWOV;
        }
    }

    if (bqAsnQKbH == -826285.3755914919) {
        for (int DLWhVfBHgbpDR = 1263294536; DLWhVfBHgbpDR > 0; DLWhVfBHgbpDR--) {
            pgCYsVyIfH = DmTxg;
        }
    }

    if (bqAsnQKbH >= -637458.0383039435) {
        for (int SHoFzgphPJHoZWFA = 741560319; SHoFzgphPJHoZWFA > 0; SHoFzgphPJHoZWFA--) {
            continue;
        }
    }

    if (DmTxg >= -173263.99072178695) {
        for (int QFTIAH = 949006557; QFTIAH > 0; QFTIAH--) {
            pgCYsVyIfH -= DmTxg;
        }
    }

    for (int rMkPVgzHY = 1159574782; rMkPVgzHY > 0; rMkPVgzHY--) {
        bqAsnQKbH += pgCYsVyIfH;
        qxvzqlVuvWivc /= bMWOV;
    }

    for (int pbdJXthC = 2140997; pbdJXthC > 0; pbdJXthC--) {
        bMWOV = qxvzqlVuvWivc;
        qxvzqlVuvWivc /= JskYVTORjH;
    }

    return qxvzqlVuvWivc;
}

void zhlarX::GfwtNcmfmJWwtSF(double IEtPnJGvMDXciVw, double ebEwqPeJKF, string UzHKDdoglq, bool ZVxWccyXUIjqp, double GAztKd)
{
    string TiwOaViAGTvuE = string("aDubgDMQkmWECFCFVbPHcdxCbweugBJitCdmxxNKBhKPiZetxKcQtuyzpOEfdVDHKGRbkNrxzbINenThmUJuXHXZatPpmvUbZYaHbLiIvCZfjexdtTyKwFSnnDYPzxiBpzzIMpChxBIbpZfpvSdzjPYToTMuCADxeURRjfoyCqBHjVbaFwnFkJaiutsEKTNOgTRcwnhUEfITLxfEUYsYGxDPiq");
    double nbQMLlPCyQkKDEs = -784252.3345891642;
    string xUBbDCAydnCMSk = string("VsRuQHdHcyXTyWivGtNfugxucVKifrCLvOaHpIeAYMErgkpIifTvYiQVSpwdLazlrbVpywywLvLyeWiDGNqhOaRTZVDnUcyVePunCtzUYIrDyUJzuRqlyKYFWtZbopqTFpykfnWmyuhoCyNwjeIYjIwkXXWSlKcwRAbBkTvQGqZappIikXakOyfynAZbElqLaeBYSezOIZAABJSuATjZRourBkuilo");
    bool tqakeWCGDiDS = true;
    bool LzmNSqgbKe = false;
    int zesGMwHCC = -470338814;
    bool BpWOLwRazGhVJQXT = true;
    string nMWVHLvMWt = string("DwsvsvxEDqPXJsDMYnIejPTf");
    bool hfwFSbGQVvwG = true;

    for (int uNFTJPdmBOMeB = 1364195813; uNFTJPdmBOMeB > 0; uNFTJPdmBOMeB--) {
        continue;
    }

    if (ZVxWccyXUIjqp != true) {
        for (int QzkElRogncJI = 1015170115; QzkElRogncJI > 0; QzkElRogncJI--) {
            continue;
        }
    }
}

int zhlarX::eehJQcGAxPAlho()
{
    bool vqrYwTYSkrODQp = false;
    string TWfUL = string("qWcsaNFEEGGDIQGbwhlIXItytiRVflZUoGgWYDQlpoWFizmQGdmhcqImJahUknJKVqIjxxkpLfzhUTfUqKIaY");
    bool tuAVO = false;
    double LLphVeYlKFboBK = -181121.21350907395;

    if (tuAVO != false) {
        for (int MtViteVOukHXoU = 1047725859; MtViteVOukHXoU > 0; MtViteVOukHXoU--) {
            continue;
        }
    }

    if (LLphVeYlKFboBK > -181121.21350907395) {
        for (int GujRNovUhpkvHmD = 1316917948; GujRNovUhpkvHmD > 0; GujRNovUhpkvHmD--) {
            TWfUL = TWfUL;
            vqrYwTYSkrODQp = tuAVO;
        }
    }

    for (int tbJsSUDOuv = 573623553; tbJsSUDOuv > 0; tbJsSUDOuv--) {
        TWfUL += TWfUL;
        tuAVO = ! tuAVO;
        TWfUL = TWfUL;
        vqrYwTYSkrODQp = ! vqrYwTYSkrODQp;
    }

    return 879076051;
}

int zhlarX::UDycGBoOo(int ywyAzclLO, double TxwdwmcX)
{
    int tVOlRnZZujuHJjbb = -1470237566;
    double exrmdWdVp = 991803.3157157468;
    string tqLvxWEdRSFOftsc = string("OsUiKdVnJgkDqhbCFGJKwtPkOIbBAwtldnFJHvwxvOcTZcBhnvwFFSeqIXODjRoWRkvLEaRpXYBvuDzrSrDdZAhtagsDUDRByGNSUOUtpiQvTcztyxVbxvSzaxpkzsyWVyKuKERoBerjswdnYbrGrQfTRgenHqkzzbroOstFtdWuDbXnVRpIWaPCfXkRNYEBqGXscGch");
    int RXwWsmqbndFIjxBm = -1689350503;
    int JUHZCpNLVKIXMMfM = 889651084;
    string quYfssUnKnig = string("jicLHHhvEMppoqtmiQNBtYyaduaxsSufQOcsHrvxrwVnGrnWbVYaXFYFdwBEWCvbnAGrAyWBqkXDVuGdCjPeEnNOiaMEyBxteJRIIyHAKMnqyHUFRAzMjhOlxLSONsqytjLosVWkREQNMFlAMCNtqzHaXfzltExdITWwUJEKSaCWsvSDGzcEfGEjeVaujjngrytsHUJLvZtYKMRmvyqRGXmIPkJOBTIzgiVkTPcNrCcfbsounhOGqUBADnpJsj");

    for (int zkROIylz = 295864408; zkROIylz > 0; zkROIylz--) {
        tVOlRnZZujuHJjbb *= RXwWsmqbndFIjxBm;
        JUHZCpNLVKIXMMfM -= ywyAzclLO;
        RXwWsmqbndFIjxBm = JUHZCpNLVKIXMMfM;
    }

    if (quYfssUnKnig >= string("jicLHHhvEMppoqtmiQNBtYyaduaxsSufQOcsHrvxrwVnGrnWbVYaXFYFdwBEWCvbnAGrAyWBqkXDVuGdCjPeEnNOiaMEyBxteJRIIyHAKMnqyHUFRAzMjhOlxLSONsqytjLosVWkREQNMFlAMCNtqzHaXfzltExdITWwUJEKSaCWsvSDGzcEfGEjeVaujjngrytsHUJLvZtYKMRmvyqRGXmIPkJOBTIzgiVkTPcNrCcfbsounhOGqUBADnpJsj")) {
        for (int evehlzb = 1174146211; evehlzb > 0; evehlzb--) {
            continue;
        }
    }

    for (int wwbdwHlQCTYtNufg = 790112832; wwbdwHlQCTYtNufg > 0; wwbdwHlQCTYtNufg--) {
        continue;
    }

    if (quYfssUnKnig != string("jicLHHhvEMppoqtmiQNBtYyaduaxsSufQOcsHrvxrwVnGrnWbVYaXFYFdwBEWCvbnAGrAyWBqkXDVuGdCjPeEnNOiaMEyBxteJRIIyHAKMnqyHUFRAzMjhOlxLSONsqytjLosVWkREQNMFlAMCNtqzHaXfzltExdITWwUJEKSaCWsvSDGzcEfGEjeVaujjngrytsHUJLvZtYKMRmvyqRGXmIPkJOBTIzgiVkTPcNrCcfbsounhOGqUBADnpJsj")) {
        for (int IVxzYWvZVW = 1724055197; IVxzYWvZVW > 0; IVxzYWvZVW--) {
            continue;
        }
    }

    if (JUHZCpNLVKIXMMfM < -1470237566) {
        for (int dQIbJmHz = 1716952218; dQIbJmHz > 0; dQIbJmHz--) {
            exrmdWdVp += TxwdwmcX;
        }
    }

    for (int DfkWCJFS = 710272318; DfkWCJFS > 0; DfkWCJFS--) {
        continue;
    }

    return JUHZCpNLVKIXMMfM;
}

double zhlarX::MZqphB()
{
    int zGQiSI = 704492677;
    int iqWui = 1418541031;

    if (zGQiSI == 704492677) {
        for (int mJiBufbOvZyiBAf = 1664208507; mJiBufbOvZyiBAf > 0; mJiBufbOvZyiBAf--) {
            iqWui *= iqWui;
            iqWui *= zGQiSI;
            iqWui = zGQiSI;
            iqWui = iqWui;
            iqWui += iqWui;
            zGQiSI = zGQiSI;
            zGQiSI -= zGQiSI;
            zGQiSI = iqWui;
            zGQiSI *= zGQiSI;
        }
    }

    if (iqWui != 704492677) {
        for (int KIcEZlEYVY = 507435708; KIcEZlEYVY > 0; KIcEZlEYVY--) {
            iqWui += zGQiSI;
            iqWui += zGQiSI;
            iqWui -= zGQiSI;
            zGQiSI = zGQiSI;
            zGQiSI /= iqWui;
            zGQiSI += iqWui;
        }
    }

    return -62875.609379514;
}

void zhlarX::SljePgo(bool SnkzzkVJdzyzGKx, int dVPDi, int DvXpxL, string PFwGkNxXmACVRfR)
{
    bool mZtWSXMUFRum = false;

    if (mZtWSXMUFRum != false) {
        for (int pRfbAfuPQCGQED = 1147065155; pRfbAfuPQCGQED > 0; pRfbAfuPQCGQED--) {
            SnkzzkVJdzyzGKx = ! SnkzzkVJdzyzGKx;
        }
    }

    for (int KZlFaoGKsywEkXj = 206784187; KZlFaoGKsywEkXj > 0; KZlFaoGKsywEkXj--) {
        mZtWSXMUFRum = mZtWSXMUFRum;
        dVPDi *= DvXpxL;
    }

    if (DvXpxL < -191226382) {
        for (int CIVzjpWXdWLli = 1940419954; CIVzjpWXdWLli > 0; CIVzjpWXdWLli--) {
            SnkzzkVJdzyzGKx = ! SnkzzkVJdzyzGKx;
            mZtWSXMUFRum = SnkzzkVJdzyzGKx;
        }
    }

    if (dVPDi < -191226382) {
        for (int nfzQTDVjYokNglxu = 15226897; nfzQTDVjYokNglxu > 0; nfzQTDVjYokNglxu--) {
            SnkzzkVJdzyzGKx = SnkzzkVJdzyzGKx;
            mZtWSXMUFRum = ! SnkzzkVJdzyzGKx;
        }
    }

    for (int xhPlLdmTaZmLnH = 2075605647; xhPlLdmTaZmLnH > 0; xhPlLdmTaZmLnH--) {
        dVPDi /= dVPDi;
        DvXpxL = dVPDi;
    }
}

zhlarX::zhlarX()
{
    this->ZJtGazylcnyw(false);
    this->FCbDsx(string("SCwsZlYjNTTHmjcLPduzNOcQGiuRHjMoqziUDLW"));
    this->GBjYLPKT(-1814262412, -15360750);
    this->GfwtNcmfmJWwtSF(-553622.5024499473, 193538.57299587844, string("AaXKyMzWBHCVRuMbWLKPfLHXPhpLWlMvsTIpiBITilLjlJvllMLoEeOGiSNRLkJIRvMPBRyfWJnLkIzvWWBFEbkSMcQcghgkefgCuDxGNdHRQxFgRruIuNIHlFlYtSbEnPyLUgnqxMTzHhDXZHSMXIMkMMrZTKREzdpuWpUezJohLgqBGKhnVKomKjnRhdmvIPgYKDf"), true, 911322.099735022);
    this->eehJQcGAxPAlho();
    this->UDycGBoOo(-1207774448, -742664.5827307391);
    this->MZqphB();
    this->SljePgo(true, -191226382, 1157091065, string("yeODrxNWJSpKtkFNElKxSTdvGlujiEhPJlkSEKABzPtUnH"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lSYZa
{
public:
    string ihiipPkWydTwm;
    string BxYpx;

    lSYZa();
    int TIqLHiyAB(bool dGIsNIuiTrhQJ, int ZtZFlCsUBThsho, double rFJNxbGXpUc, string sudYBQCyPRMa);
    string beTNvOcvyTLEdnKB(string uyaRns, double zMfuwLFjbulnAsy, int BSzoBmzOPQ);
    double IlptStjIdgwFoPPD(bool CupaCNHUKOv, bool BYSpfQhXnTAcuTGU);
protected:
    string upEhZHWpMOontfzs;
    string vfEIXZVEsyllqor;
    bool qtwbXY;

    int MQtLBQdxaKkWjy(int qEtTaABoYNiMaa, bool sTTFcsjwGRubH, bool RZnNsNjUlYBGh);
    string HkrPREGCsb(int jpAwrPsabSOWzW, double VkFhPKhQLzsVmiA);
    int SEksUM(int lZzNUzFHRDxiE, bool dnPaj);
    int CUSLyzbnkkSBVT(double XGHBMk, string nwAei, bool fyBFmVp, string wQFpIKOW, string TFDcIumRGsoJQSV);
    string LvoYlGwPprFn(bool KOjRRIMQTEqRMc);
    double icoOJlVAfOYk(bool xPqqtKM, int fVVbX);
    int NUIvMbjPV(bool KhjrbaRRny, bool HeCwODsBV, int pNVqAcpvzX, int ohAJaDVegh, string JsjnSVKAfGAP);
    string NYGeLc(double IIikjEtKDMKlPW, string INQNiDKnGyihwD, int gfpBx, int UHjudcdVuz);
private:
    int LfDsZicsiEeX;
    double EShqMpW;

    bool NvdMKOSBE(double vHBiLJIolCNIXtNN, double vvSWY, double djZqv);
    bool bSCXDGzMmPXp(double nopMWApPE, bool QWykdF, double llqPgVeQNKmLX, string rPAAHjSGXC);
    void DuuhdZxkqL();
    double upNpWxrxB(string jMxZpsWhyz, int CDhLqJ, int oWaZWobcsMePUpJg, int QAZaAiPFxVE, bool ylCkhDMjlfcwSM);
    bool VeBdxowUu(string ycJsIsmVtUT);
};

int lSYZa::TIqLHiyAB(bool dGIsNIuiTrhQJ, int ZtZFlCsUBThsho, double rFJNxbGXpUc, string sudYBQCyPRMa)
{
    bool kWNmivUMGoYOYMWc = false;
    string rnpaozuIvrIrgWZ = string("CLdEBHBXPnCjcREEaDlLDaQhojQZHeVFHtslqKIjGSFSooMGxzDmeErXnaLxHrOsPvFYJWGhdYDTXcMIsgsbakbCqWcSTnReITWVadcXRqeHadeXfhYPYmDGdMmPdarxJFHEEbtkiqpHijaUHwOyqZbjzwIwdwVHndacCxEHUYVgBLViROLCMLvIsxWURApzw");
    string xqcPIg = string("RkabnVdlMGjLMQvFBVBkKOFkQahZjtDyyyYBPPhfNZGnKYszpvvfucHFBpYcFDckHxUGEcAlqrBzabjOXwHNmIXFPhtbnZhLhwBVJMCFPXqXQagIzDxVguHMKjtxfiQTIGRwItTmcveyJpvbkMxHRSGOmnNOXsVzDwzTHYRpidOpztgSvZB");
    string XDwidorW = string("FuPHeMOJHHaaIpdXkNITtSJqSIIPgeaHeQVHYxWXcrYMMajDENUReZFjTxMXOiiFqzCIdEawEuTxJHJrsMfjZtRqnEuqtzfYvDBmpjHbMEieVAPGBAbtSnXlKBxZiqpNKtYHcpWSiJWvjESsSMMbPalEKJiDRmBSAlopQChdrBzXCkrDCeaY");
    double UjYyjNKKJVSC = 744862.9054208922;
    string JMeSYghEmjeUBu = string("gfRqsZLXvWStVSkfcIXwFkVitGBJTtlPmLyweTdTAwqSuEeGPdAZnbygFfWnNiMrRuVJEfufceEpSChUysNihWeqktrgMmhISAokpPfXwIiozGVJarHbXaGOBKAWAWMJkdOhzoGrplobZEQfnWAsfllabMtosVkOgtwIUXJdqWFGOhMerilOBZHwaHRHkfOWuWDyiAJlClWEYcYVmzEKzudvUsVzobdLBedtmqizGNMt");

    for (int ZOqhFNbSIV = 137536377; ZOqhFNbSIV > 0; ZOqhFNbSIV--) {
        xqcPIg = JMeSYghEmjeUBu;
        rnpaozuIvrIrgWZ = xqcPIg;
        sudYBQCyPRMa += xqcPIg;
        rnpaozuIvrIrgWZ = JMeSYghEmjeUBu;
    }

    for (int POUuw = 693596542; POUuw > 0; POUuw--) {
        xqcPIg += xqcPIg;
        dGIsNIuiTrhQJ = kWNmivUMGoYOYMWc;
        ZtZFlCsUBThsho -= ZtZFlCsUBThsho;
    }

    if (dGIsNIuiTrhQJ == false) {
        for (int YBhhfNoTAKr = 3336669; YBhhfNoTAKr > 0; YBhhfNoTAKr--) {
            rFJNxbGXpUc /= UjYyjNKKJVSC;
        }
    }

    return ZtZFlCsUBThsho;
}

string lSYZa::beTNvOcvyTLEdnKB(string uyaRns, double zMfuwLFjbulnAsy, int BSzoBmzOPQ)
{
    bool IEcPaNI = true;
    int GQTRZvHPKtnl = -1061483304;
    bool EyWpy = true;
    int gHqJwTSPVTVGm = -301779056;
    double RGlDoNpuR = -906563.7115486718;
    string jfoYYYOcIrMNaO = string("InfwAOHJdXmYXjoSIzTYcDYBpQinMnHTzviYJrnldxPGwmQQuyCbpKnbRgHProuBqSBhkdsfNMOOjaZiiQXZbcXaEDGfUmohUvhuYbxEfeNsNCOhzPtsxxOUOYRzx");
    double dGczmURfHYYAB = -307019.5881049362;
    string WKRWXWVFreEUc = string("kSOMJWQwqpnRDYpOduiittLevDikRPfhMHEljjbXQmmToJdPYrTNiJfIkcVlFIdjayRjfnExaJDakUIAJXLFURrsJjbTqFmBBhjHhHsPyMjWJVyNMLflLwuzygRjBbJXhobFlEaikkUGNMQvJbdyOOqLygpHyAvUfFqofxhjzalBksWTDCnJrosPKshNiUJbysZEXMsxLcvWghfhTbHqHeHGgdStX");
    string HFqcsZdCcIaFXBuN = string("uUXErdTzPTVElsPDAcfDhmIyjmMIWwhDkIPzIkVTzBLnGlIlYeUPTpUYRNdgyWkCvtOHqoAyiSdTdVkGXEjlJNquCTuxrGsRtpHIZGXTVyVXrufkUuZormUGSEDJTHbovcyAXqdOYeoqLUPHkCZqIAnQsnlVXHBb");

    if (uyaRns >= string("YToJMHJgqvQRZLfwKiMboXlqNlVmXrjlnHkqrYWXYHArLAEQjSWoNQlOFZNEbsWcvvImUhSsOF")) {
        for (int WbPTiTQT = 975390656; WbPTiTQT > 0; WbPTiTQT--) {
            continue;
        }
    }

    return HFqcsZdCcIaFXBuN;
}

double lSYZa::IlptStjIdgwFoPPD(bool CupaCNHUKOv, bool BYSpfQhXnTAcuTGU)
{
    bool JwjSoqFtEGw = true;
    int ooDLVmIejCpc = -934537059;
    bool VcEdUz = false;
    double MblntjYPaQ = -907864.5805264303;
    int DjKbmUHDSeQiHPDJ = -96584477;
    bool LTXSkolvcCdiIObz = true;
    bool VvnQasOiiS = false;
    string jAhqWGernOibZL = string("cKuYcvSHKaXkbpcAEFMApGKV");
    string QHzsjAG = string("ifXngbTwiSFDEaZTZOkQdJirNmLvjtibJSDiGhyesVMmVCTEIOJQcmzKxNEdkUiCpPGkakiNuYbtwGEGokPrQJkAKzLpDAdekeEJoTcsxVlaeagZlXAjpRHUFyFYzXdYorxXEvRlfGQsYpDUdYPFEGCSL");

    if (LTXSkolvcCdiIObz == false) {
        for (int XKEaaqEZez = 514099255; XKEaaqEZez > 0; XKEaaqEZez--) {
            JwjSoqFtEGw = ! VcEdUz;
            ooDLVmIejCpc -= ooDLVmIejCpc;
            BYSpfQhXnTAcuTGU = JwjSoqFtEGw;
        }
    }

    return MblntjYPaQ;
}

int lSYZa::MQtLBQdxaKkWjy(int qEtTaABoYNiMaa, bool sTTFcsjwGRubH, bool RZnNsNjUlYBGh)
{
    int VuPJaRhzFg = -1500476571;
    bool FUBsRlj = false;
    int AoNPIbNxajAAAH = -808437085;

    if (FUBsRlj == true) {
        for (int iOLbtqkhqhVik = 2144754512; iOLbtqkhqhVik > 0; iOLbtqkhqhVik--) {
            sTTFcsjwGRubH = FUBsRlj;
            RZnNsNjUlYBGh = ! FUBsRlj;
            sTTFcsjwGRubH = ! FUBsRlj;
            FUBsRlj = RZnNsNjUlYBGh;
            sTTFcsjwGRubH = FUBsRlj;
        }
    }

    if (AoNPIbNxajAAAH != -808437085) {
        for (int JueWj = 1919315054; JueWj > 0; JueWj--) {
            AoNPIbNxajAAAH = AoNPIbNxajAAAH;
            sTTFcsjwGRubH = ! sTTFcsjwGRubH;
            FUBsRlj = ! sTTFcsjwGRubH;
            VuPJaRhzFg = AoNPIbNxajAAAH;
            AoNPIbNxajAAAH *= AoNPIbNxajAAAH;
            RZnNsNjUlYBGh = sTTFcsjwGRubH;
        }
    }

    for (int EiwqmPgGdZcuqt = 1207560886; EiwqmPgGdZcuqt > 0; EiwqmPgGdZcuqt--) {
        sTTFcsjwGRubH = sTTFcsjwGRubH;
    }

    return AoNPIbNxajAAAH;
}

string lSYZa::HkrPREGCsb(int jpAwrPsabSOWzW, double VkFhPKhQLzsVmiA)
{
    int GDAxmJV = -1424819884;
    string meMuPeHA = string("HWeIHQHlRJdrmtwwKrGkYxdYmsoeQHrttFsRpdBZmGOXREBtvDHAFdUxtmjxjmDAOzzxHlpTtWBiPWJfdkTZcQnpLSelGmrSowgadnIJorWYWvRkhNXHRSvYjKjlBtDntiCLyIZCmLCmuXHXGKMZNDbgDOMsoJHNXzfhDbOoloypeqLFtYAlzAQkfhCzAEwhCBWAnwmhBEXCytMejudDROGHxqxewcQEYjFzgGxKvvRTAwEAIGapamg");
    string jUBVmKJImLbHEA = string("NgKxWWnqDppIocvflHdoOqBSLdRDeDzqLTvfzToXDzeWdywfyDYyIWXGVckVLbPNPbCfNKOuAVGpavvpNuILAoywHlsZaYtpgcthDehGHGXjRaanzzEvnaLnluSOkoydpmwGDcxGqovfLNZAKbGZntSYQs");
    double MfViQujckidWloFg = -616102.174792967;
    string yzmfDyrSoe = string("CSGMwJBudkHHicqAgkdPrmFUlqIvSaNwEjovTCMflRJpvTTIOfbGgYYHxLfEQeqIQKtHzcYBURnZsFFPhoLBKDyrZEtUEvOescvUaSXtUxrVgrOqLRREWIfZlmgRhKAQRxkkxQebReLFanquOxOVklTQOVyagXYcuFjhWfQLOGUuKjSHwLhjsCelnAqJLbyVjifVjwlWQjQhJaRbXbOzHhruVsZAYakbZSQf");

    if (jUBVmKJImLbHEA < string("HWeIHQHlRJdrmtwwKrGkYxdYmsoeQHrttFsRpdBZmGOXREBtvDHAFdUxtmjxjmDAOzzxHlpTtWBiPWJfdkTZcQnpLSelGmrSowgadnIJorWYWvRkhNXHRSvYjKjlBtDntiCLyIZCmLCmuXHXGKMZNDbgDOMsoJHNXzfhDbOoloypeqLFtYAlzAQkfhCzAEwhCBWAnwmhBEXCytMejudDROGHxqxewcQEYjFzgGxKvvRTAwEAIGapamg")) {
        for (int wuQDxbQujVedNxo = 451913437; wuQDxbQujVedNxo > 0; wuQDxbQujVedNxo--) {
            continue;
        }
    }

    for (int CYjcr = 1006527115; CYjcr > 0; CYjcr--) {
        continue;
    }

    return yzmfDyrSoe;
}

int lSYZa::SEksUM(int lZzNUzFHRDxiE, bool dnPaj)
{
    bool smCGWWHzjV = true;
    int CnGAmvJ = 1654809232;
    int NdsJxCsgRanTLi = 277802235;
    double xzOgkta = -996848.3089163293;

    for (int dVAIYPhQKUGtqpq = 1598571227; dVAIYPhQKUGtqpq > 0; dVAIYPhQKUGtqpq--) {
        CnGAmvJ += NdsJxCsgRanTLi;
        NdsJxCsgRanTLi = NdsJxCsgRanTLi;
        dnPaj = smCGWWHzjV;
    }

    for (int ucSpZqNXwxtU = 1334360831; ucSpZqNXwxtU > 0; ucSpZqNXwxtU--) {
        dnPaj = smCGWWHzjV;
        CnGAmvJ = NdsJxCsgRanTLi;
        smCGWWHzjV = dnPaj;
        lZzNUzFHRDxiE -= lZzNUzFHRDxiE;
        CnGAmvJ -= NdsJxCsgRanTLi;
    }

    for (int gYEslcJVliN = 1561169858; gYEslcJVliN > 0; gYEslcJVliN--) {
        CnGAmvJ -= lZzNUzFHRDxiE;
        lZzNUzFHRDxiE += lZzNUzFHRDxiE;
        NdsJxCsgRanTLi /= NdsJxCsgRanTLi;
        CnGAmvJ = NdsJxCsgRanTLi;
        smCGWWHzjV = ! dnPaj;
    }

    for (int JQuujZKXYRkIPSy = 1126152349; JQuujZKXYRkIPSy > 0; JQuujZKXYRkIPSy--) {
        NdsJxCsgRanTLi += lZzNUzFHRDxiE;
        CnGAmvJ -= CnGAmvJ;
    }

    return NdsJxCsgRanTLi;
}

int lSYZa::CUSLyzbnkkSBVT(double XGHBMk, string nwAei, bool fyBFmVp, string wQFpIKOW, string TFDcIumRGsoJQSV)
{
    double fOEqgk = 658264.547220645;
    double GWzIaIeXKrdQIRis = -847682.6806569579;
    int fmIoQDkIOUhjr = 619728908;
    double VaybxNcAeyhQxj = -134739.14337366726;
    int ZcBwBAPUU = 285236862;
    string Bprcx = string("lBHuSsmYpsZVObiIsthwkaNJQFHWfzaevHoiEoRJpJSOForhehOqPfYakVkzqfyZiJfkDJdvcCnltPqmvzNhdQCMuAEpeVPfSVrjPbqZcCcCSPZQOGENLNKfHULfgABTXKhYhQNbnTObESDjzLbWtfqNyLBCzSfpSZxDwniDmEdZnaQKnRBfapZErWGsnuecsvGcITVDnWtuQVKezXqCAcTMfsVhfWZMAARQEASuuwAGZpBUpse");
    bool jBJehveJRw = true;
    string iilIfd = string("bKTXwjYrlrYAcOtWoThEZVuDkjJTqakpnQWLnrhaNkWcLsxfQlbsNGGCjjWQoBQBVYftyZkPEvnWoNVsrtnTpugyYzmcknCPOocXnSGbfmrHVUkubTozDvMPwnuQkKzDbrXhCUrzQdVCgMPfdukVNjHYlBlOFKWudrTgcdDj");

    return ZcBwBAPUU;
}

string lSYZa::LvoYlGwPprFn(bool KOjRRIMQTEqRMc)
{
    bool rNPnzQfWFIsldAFF = false;
    string bGzkfa = string("pXffWTknZxUgEMmaMvstzSnthPdWrdWEvZaEUdOMinfRSKGwXMRnDjtmVuQCTkONxjOqcTXzDlkjZiQxSkCWZFZqMFWUUXwCFeTtiwMUNzZamXwUvSEOAEEsZEerfgHryJQTrlIYRpEFSdeszaecKpdYlatgAendkt");
    string DGMmQCLxbzHUZ = string("WUvTcvyztJBgnaeZoEvIZeTROqhPBDjYCRxoQnNCMLWWutWiJWBlrxjkgSEGZlcuYhRHQBXzFiKDZCrMDSsgGXxftNNvNMJPlDhllADOEhiWzOKcjhBEKAhUKOnZmipdRyGREilfumrNkKghYqhsVOhUItPrKfDqcWYHNzhdFFrBpHUYzFxCVNTBdfHWaAwBmqcDSDwAyFrRLdjFzbNrLpExrMNWtWvsYSHZgbFIIcFHKrAQhfRgI");

    for (int uSFvVhZIyY = 1267131187; uSFvVhZIyY > 0; uSFvVhZIyY--) {
        bGzkfa = DGMmQCLxbzHUZ;
        rNPnzQfWFIsldAFF = KOjRRIMQTEqRMc;
        KOjRRIMQTEqRMc = ! KOjRRIMQTEqRMc;
        rNPnzQfWFIsldAFF = ! rNPnzQfWFIsldAFF;
        KOjRRIMQTEqRMc = KOjRRIMQTEqRMc;
    }

    for (int XzYpjyTpvfEZ = 767892340; XzYpjyTpvfEZ > 0; XzYpjyTpvfEZ--) {
        DGMmQCLxbzHUZ += DGMmQCLxbzHUZ;
        bGzkfa = bGzkfa;
    }

    if (DGMmQCLxbzHUZ <= string("pXffWTknZxUgEMmaMvstzSnthPdWrdWEvZaEUdOMinfRSKGwXMRnDjtmVuQCTkONxjOqcTXzDlkjZiQxSkCWZFZqMFWUUXwCFeTtiwMUNzZamXwUvSEOAEEsZEerfgHryJQTrlIYRpEFSdeszaecKpdYlatgAendkt")) {
        for (int nzPOGXBUabykjDT = 661670151; nzPOGXBUabykjDT > 0; nzPOGXBUabykjDT--) {
            continue;
        }
    }

    return DGMmQCLxbzHUZ;
}

double lSYZa::icoOJlVAfOYk(bool xPqqtKM, int fVVbX)
{
    string BSmFXI = string("RFfShlTLWdFGzmroOBEKPJVjmWNeyRCnHNBinoPNYfzSuPalfklrOLXohyDbOBuvneesiDlXfFRofSFDRhJmoaRQGDgKvxCoYTipCUvvXWoZBPDKIbZxQYlnwmJNSBzrqSiBNvGakxxarkdyfBrKbCwKdd");
    int tcPZNUvtAMxgo = -581202976;
    int aTULHxLTtRtq = 2040829572;
    double hLJfIk = -778438.4081286334;
    string vAdwGN = string("GunoWLumUKfhtyFZmdmSshXKIgbXVNdLWfdgbgJgACMWuTjFnJNhDmLsClctqKJwIFqoMaQsMRIRNjqJWeMtLJrvVs");
    string aodxpxPTrqTBixY = string("NwSwbqjTvHLHtoBAjvCDCAQffRcLamCgBisgHvEawkRnmLKRfPsUaeKUypsDhdFrmpRsxmjiBjaylMwAUNLinvnbpBlbnDRIZcmOAPkjpZwLxLsSjGMWpCxIwhGPKEasvPLZdQDsywPT");
    string nYzmLosJjKpffX = string("xHryoOxfcnJXguTZMbZZLFpZSvxBQTwOwXGsPbdWJZsFtnaZGqOqzqQBiJNkTxaBiCVxcvfUtMyZpezGGNpqqj");

    for (int JcqGvCSxn = 773429254; JcqGvCSxn > 0; JcqGvCSxn--) {
        aTULHxLTtRtq *= fVVbX;
        BSmFXI += nYzmLosJjKpffX;
    }

    for (int asQhj = 1857486912; asQhj > 0; asQhj--) {
        nYzmLosJjKpffX = nYzmLosJjKpffX;
        aTULHxLTtRtq = tcPZNUvtAMxgo;
    }

    return hLJfIk;
}

int lSYZa::NUIvMbjPV(bool KhjrbaRRny, bool HeCwODsBV, int pNVqAcpvzX, int ohAJaDVegh, string JsjnSVKAfGAP)
{
    string nhDCOsDfWWwcnvw = string("LAyfKSxHyKkxObxHwRKmYnyVOnhgxtoEIbbUyQRxKNnlwwnORymcad");
    bool UKOpW = false;
    bool ddczwBZHnLudA = true;
    int XWtafwmnuQyZI = 373856518;
    double WlVkR = -857244.2439388366;
    string vYfliBMVFWBfEdaL = string("QUFjpoUsmIfZDEIqxvZyTKSPEPEfQwUtJgZsXcOEIzdwdFGlbMcXOIQvMgwHXqVYcuKunVQCxmJqjswsicEUiXzdXYymaqSqTrDRcHtWVoIvnRceMxyPHprxpsndlBDucKCbCFvgPQluIJLLzUFf");
    int jUtCT = 566174219;
    bool DipxxHiCSlR = true;
    string BJPEDQYOpI = string("edRdfWFjgdJxMpNdRKtWtjXMvzKlKGlKVKJbOiizcnDCnrQtGLMbdmUmCRENcmgG");
    double KBkNuABIi = -712796.0244024337;

    for (int rjMaUWh = 1339728566; rjMaUWh > 0; rjMaUWh--) {
        JsjnSVKAfGAP = JsjnSVKAfGAP;
    }

    if (ohAJaDVegh >= -1956061910) {
        for (int jKLRxFUAcW = 438471023; jKLRxFUAcW > 0; jKLRxFUAcW--) {
            jUtCT += jUtCT;
            nhDCOsDfWWwcnvw = BJPEDQYOpI;
            KhjrbaRRny = ! HeCwODsBV;
            UKOpW = ! UKOpW;
            pNVqAcpvzX -= XWtafwmnuQyZI;
        }
    }

    for (int PYgqercxkhNL = 520491685; PYgqercxkhNL > 0; PYgqercxkhNL--) {
        XWtafwmnuQyZI += pNVqAcpvzX;
    }

    return jUtCT;
}

string lSYZa::NYGeLc(double IIikjEtKDMKlPW, string INQNiDKnGyihwD, int gfpBx, int UHjudcdVuz)
{
    double dWZkikFVFlrTIxaB = 574167.8581495587;
    int TOjxqDuoGHXFljbJ = -307089236;
    bool cAiUdVDpj = false;
    bool QRhhSkPqmgYzjmJ = false;
    int wbsns = -964471636;
    double lbglUQMzAQEr = -1040555.6081853056;
    int cXTuGEkRqSdvII = 644544781;
    int uYhYQFePzBOZ = -1458218110;

    for (int ZAMwtGagM = 2090701888; ZAMwtGagM > 0; ZAMwtGagM--) {
        uYhYQFePzBOZ -= uYhYQFePzBOZ;
    }

    return INQNiDKnGyihwD;
}

bool lSYZa::NvdMKOSBE(double vHBiLJIolCNIXtNN, double vvSWY, double djZqv)
{
    bool BjWQN = true;
    string SxbkOCgdZxemOI = string("auVSCNNFrePUdyuSzDRsLhvgtAuZTuPLAioqXdhbkrGyYQFFPZiBgnweJMsVjMWkLcUzzgvZuGtCE");
    string XCXhfmPKb = string("GMIXZUGetAbdWPEZoGmCSnzXpZaxZEFQPmwzummNvBmwtgdZTJbSzqFzmykYXsjwXbFUOdhYrTcihPCsWHWMuSOCENOPcFFYxBSHyuiInmMxIBLlShQJC");
    bool sKQHZ = true;
    bool aBAEunsGdIUhErUm = false;
    bool LEkIJOj = true;
    int RNtTbOTxpyO = 1360808290;
    bool DTwuFQekRIhYUpo = false;
    double DyNSGNF = -587101.146161332;
    int LNlsqoRf = -188378198;

    for (int QYKEsvUMYsea = 1498954869; QYKEsvUMYsea > 0; QYKEsvUMYsea--) {
        continue;
    }

    for (int acejenpUwxVVUAAU = 169089322; acejenpUwxVVUAAU > 0; acejenpUwxVVUAAU--) {
        continue;
    }

    return DTwuFQekRIhYUpo;
}

bool lSYZa::bSCXDGzMmPXp(double nopMWApPE, bool QWykdF, double llqPgVeQNKmLX, string rPAAHjSGXC)
{
    string eXTAzOQQSx = string("mLkxAagnTqWmwYIiAuCHkAGoxGsOWVDqfLGGaVdLRgDAyIcEltCZfWqIdfhoLDmzAwKfdmAhunDcBhdyTrBOyOZpikRhQMiBPnQmRRHwbTUUSBpULXPPFdIBTPYquaxbQkWKddTpqswMmaWLzdFIWEUNDgYOhKnCRpRRueNLkdSJYFoverIjPDBPsbUNhUSgoqMPkmp");
    double ikiTAAPqJufY = 617579.9690000614;
    string OBtHFT = string("dceauauCHBxcduDblURXkOBDeJaKHeNLewptoCzTdqiIpeBKVgxOuzVQRforKAdyslKwzjifDULVpsyVhyBREmkCJzQoOOAbELYFVGzWnCnHCJtPjuLPjWVqKVzHDEgoaghOBhFTnrKwaBvcSHJzRpVjoV");

    for (int BhboeBBpNT = 1445994243; BhboeBBpNT > 0; BhboeBBpNT--) {
        continue;
    }

    if (rPAAHjSGXC == string("dceauauCHBxcduDblURXkOBDeJaKHeNLewptoCzTdqiIpeBKVgxOuzVQRforKAdyslKwzjifDULVpsyVhyBREmkCJzQoOOAbELYFVGzWnCnHCJtPjuLPjWVqKVzHDEgoaghOBhFTnrKwaBvcSHJzRpVjoV")) {
        for (int QAOnEGxVLTrm = 578720153; QAOnEGxVLTrm > 0; QAOnEGxVLTrm--) {
            nopMWApPE *= nopMWApPE;
        }
    }

    for (int TsaaG = 407660103; TsaaG > 0; TsaaG--) {
        OBtHFT = rPAAHjSGXC;
        eXTAzOQQSx = eXTAzOQQSx;
    }

    return QWykdF;
}

void lSYZa::DuuhdZxkqL()
{
    bool YbHLUZhkzPHIHKgg = false;
    double UuYkONM = -618122.1657349406;
    bool pMtLSYRxP = true;
    string JeqthvXRPwy = string("RNobDXsreaXTmTRKJoFqXYqrXtdYIgarcdpKOXaaNApekZgqEHoTCtixZkJuMLdipEtrmBZVtBrAOOuPKisqWfAkbwatRuqpYTXVnALzKvHxUHmQetBqJiycNQiwYFbVgliKJMbswhNXUVIhyIDnDvb");
    int rwrZybwRWY = 946019080;
    string kLADNTnH = string("kGzeClnmuPzRgEjOVCLzHeNAKtCDqzIBamRtOONzvwgrfsBozYBBjIhWoqaqSOBCWwZUwwNJrEErECMJNsOkabYeNGYvZhPjlXTFtWjSZBYvwFtGvfuTrMXHfyTrbzgmlWDBeEOjmQWNRyXwHgcEcXLIlGEQZIZKXNPsVcFnLAUdPvlLbaYIRlxtjlssvgrcEKQRwmnulaDzMeFoclfvurlnRFqzkixUuBiZCphuznASEj");
    int qUDEnykMbMRVRTs = -2122210382;
    string yxKnISC = string("ZBhUXNXnuZhMAoMgbFNArijDKAckUBqRNqBVlzCrexTBMwrLvlnrxJKvjByKKPsqYpfhypVrkSLvuWoirTxdDikBcOUAmoqMYhjgZtVKyqtKsXohaUbmpxDvwhFDSotIHTodkFkaJMEqeEUqoJOuUtiFcjlGGyxWSeqqdFrtOJknNOBhZDCqVnIewYqaDSyyhEcZfpvBhOVMkIlJPrbVTZWBdqJXkyRhxHGlSxrGYwbYcGYz");
}

double lSYZa::upNpWxrxB(string jMxZpsWhyz, int CDhLqJ, int oWaZWobcsMePUpJg, int QAZaAiPFxVE, bool ylCkhDMjlfcwSM)
{
    bool IBZmvrOJRIyGU = true;
    string BUcCVbDlW = string("cAQqXAXTDZVbviGlzIBWoPEobkgnfoTyQvZMSCPZXuvEpGCkZzMMmNndmBlwEvUCccMUSUeBvkAEdNiGYhnBKyAasIkGgbGcMESEcSiNFTJvcxNFJopHkDMQTYvGcLptOUzldJWNwjfQiRKHItFL");
    double DkSnKAlYKjXJFaaI = 421361.5525531864;
    string adyWFg = string("RXxCnuNQeZVEaxNEFbfhPaPviIZxQacYaOPxLpxhoavbyatjBYTHHBFUwjiOXilxBvxwIbtcyQmhujSSzsycDrNftsZGLkDFDMstXAoMEcVRKNJqpxCFZwhgRAwzufSzsBbJTmVNpSRzHmegnEaLCyejAocXVtfAXFvojJyGDTMyaWaYyAdAiRmyATbsKOz");
    int UaptRpLFz = 1975348923;
    double WlfbiyEruHOKkE = -916593.6632570454;

    for (int NvKGUhQbChYo = 230861712; NvKGUhQbChYo > 0; NvKGUhQbChYo--) {
        QAZaAiPFxVE += QAZaAiPFxVE;
        adyWFg = BUcCVbDlW;
        BUcCVbDlW += jMxZpsWhyz;
    }

    for (int jEvCgQoHNfcfWEW = 1894807326; jEvCgQoHNfcfWEW > 0; jEvCgQoHNfcfWEW--) {
        QAZaAiPFxVE /= oWaZWobcsMePUpJg;
    }

    for (int JbtzoIFEpOFgDKj = 1823256226; JbtzoIFEpOFgDKj > 0; JbtzoIFEpOFgDKj--) {
        CDhLqJ *= CDhLqJ;
        DkSnKAlYKjXJFaaI -= WlfbiyEruHOKkE;
    }

    return WlfbiyEruHOKkE;
}

bool lSYZa::VeBdxowUu(string ycJsIsmVtUT)
{
    int PbtPVh = 175528086;
    string kSxljLMJVNPAL = string("deoGPrESVBzOaNegSVQGFejEwbNVxoqnAiKvnLoSjsLvYJXbuFuaXrcfoJIbQyRv");
    bool lLlhzbhrKBTnILdy = false;
    bool eRnvWTgSMxzyEek = true;
    bool dCyPJyXwVIcH = true;
    double chBKWALCKnkaS = 253899.43113685152;
    string kfHkZwhyfk = string("qyhdsLAnTHxMagUDyxbFZTBMtLfAELneXwO");
    int DgaKPUHmXnxFLf = 1896585557;

    for (int lmsxr = 234373484; lmsxr > 0; lmsxr--) {
        kSxljLMJVNPAL += kSxljLMJVNPAL;
    }

    if (ycJsIsmVtUT < string("deoGPrESVBzOaNegSVQGFejEwbNVxoqnAiKvnLoSjsLvYJXbuFuaXrcfoJIbQyRv")) {
        for (int bmwqhhi = 1346523533; bmwqhhi > 0; bmwqhhi--) {
            kfHkZwhyfk += ycJsIsmVtUT;
        }
    }

    if (DgaKPUHmXnxFLf != 175528086) {
        for (int PUmMQyakbNglyPZ = 1409077638; PUmMQyakbNglyPZ > 0; PUmMQyakbNglyPZ--) {
            DgaKPUHmXnxFLf = PbtPVh;
            eRnvWTgSMxzyEek = ! dCyPJyXwVIcH;
        }
    }

    for (int ZTeWhkz = 1940576213; ZTeWhkz > 0; ZTeWhkz--) {
        DgaKPUHmXnxFLf *= DgaKPUHmXnxFLf;
        DgaKPUHmXnxFLf = PbtPVh;
        kSxljLMJVNPAL = kfHkZwhyfk;
        eRnvWTgSMxzyEek = ! dCyPJyXwVIcH;
    }

    return dCyPJyXwVIcH;
}

lSYZa::lSYZa()
{
    this->TIqLHiyAB(false, -1410937324, 715245.9303900569, string("wvXTQWTrrBnpHnsTRkXzjSKOnklfQoKhfgddNjcdyY"));
    this->beTNvOcvyTLEdnKB(string("YToJMHJgqvQRZLfwKiMboXlqNlVmXrjlnHkqrYWXYHArLAEQjSWoNQlOFZNEbsWcvvImUhSsOF"), -981143.4189447202, -461694510);
    this->IlptStjIdgwFoPPD(false, false);
    this->MQtLBQdxaKkWjy(22409973, true, true);
    this->HkrPREGCsb(293868306, 718383.6986416599);
    this->SEksUM(-2081147394, true);
    this->CUSLyzbnkkSBVT(-579668.5534570271, string("UkDCjfVhXraUtyfJsTiPCMvFX"), true, string("DgDbVOHekyEywNHjzNVONnsKAZSGZVmzoCyAYTLEDQHfOPCDQOjSVMBquReJUiyOGkfzIFtoHMCRYKmPOskLYuoZkXucZvu"), string("COyBarYflEHTKfXETMsLWawlpgsNbXXxrxvTzQSOxqkTQMcYvjizDpOhMYF"));
    this->LvoYlGwPprFn(false);
    this->icoOJlVAfOYk(false, 207797490);
    this->NUIvMbjPV(true, false, -483703873, -1956061910, string("nyHCCWfAcauDyxmxLLVZlIHUBnXzbcMgxOyqlluZJUnKeqPmnFUEkwgagxYRbWHPZSaLPHvqeHCTXkkENxRZTeOtSvaPscwEhcJOLDcbPeCettnazqUDRhApiNmSwPwLdbvzEopHkVwqwASjZpcEHIOzruhAmlQqnysSIZZvjkbAVOrIeUQjFdrkaqUDCnTBwheYqZObyhq"));
    this->NYGeLc(968841.4745353005, string("yXWCipIMzFnWTjHFADsNRZLDxoGFYEioRCfcJYaweyXUOysYhqVjaDkTTmIzIOlFQXLWQdRhrxCGyQfZbaPYzMlDWZvCTyroSayzJtJhUvkfNNPazdGGHhQLsYkfaSAQccKeCdAWkNyDDpGogKnlOERqDYtlnrpoSeeaOtctBJuTrVmHqrBgUNVdOFWGxiSBuYLs"), -724224213, -53820063);
    this->NvdMKOSBE(784339.5778814832, -387832.50195197144, 652449.0666963378);
    this->bSCXDGzMmPXp(935321.2492969224, false, 131533.9101158151, string("ERnjTNcFlUVwDXYCZHIOIMUZBpzNISQqmwHYlvkqVSaZeCCzkZiaTdrsTTSZXmAKjIuaLeoHZKLltjXlAe"));
    this->DuuhdZxkqL();
    this->upNpWxrxB(string("zJAEGWiICIMcaybQYaqZwhuzAtthICDYRUZDZeuKKDuoGhI"), 1028506513, -1725712552, 2088491234, false);
    this->VeBdxowUu(string("jYnbcINTzBXvEzwyeHflZKXCnfrWgGyVTpOqFvzXSlwWtnEHpStOZWDwEmUsOocyDARuKWRRmDsqjmCKixuKAkHDSdiayZpZBeFNIiFvMWvDhhqDQNrEqrTYwkc"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PvsjaLjjJ
{
public:
    double YjlKNtxrWaFdS;
    double JBSMgpQYAvQtoK;
    bool RhKrIlcUwlOEZELC;
    int CwZEgJuHR;

    PvsjaLjjJ();
protected:
    string bEyrRzO;
    double EfoAy;
    int LRjQTPG;
    bool MOnswIzDQjYogA;
    int hhBxYquBJDunjW;

    double QjMBRnIXphP(bool QAJQFULpBdKcehYc, string AzrLbtPZulyXE);
    string vivxhXVmADy(bool RrjkxQst, string pCrHbKfFpe, double KXuTLaOj, int mcFfiXgBOivrC);
    void JIDgEEEuEQTgv(bool onehHRWX, string guWCUgwMCYRuY);
    bool ychHRoPsjCvKFIMN();
    bool EDUTrUdtGKgAlFYW(string LOomGv, int vRaljMQbdoq, int XtgzxYlSr);
    string jYckzWworJMwu(double kwhHZdDqGvjS, string xsFjmoXxiI, double NeuHMDMtqRtjG, int vwXPCcYPShcMh);
private:
    int eWZcy;
    int MDFmki;
    int oGcTnuPoGXFRMY;
    double iNLQEPWtK;

    int KCGVK(bool tmciduuinz, string egqPNDyKNoV);
};

double PvsjaLjjJ::QjMBRnIXphP(bool QAJQFULpBdKcehYc, string AzrLbtPZulyXE)
{
    double aIKvGbBKRfC = 217021.1370134857;
    int iynhTJgNgkDwd = -2081191585;
    int TOSstAv = 838204049;

    for (int lVtewdgWwMNq = 1036786897; lVtewdgWwMNq > 0; lVtewdgWwMNq--) {
        QAJQFULpBdKcehYc = QAJQFULpBdKcehYc;
        TOSstAv /= iynhTJgNgkDwd;
        iynhTJgNgkDwd /= iynhTJgNgkDwd;
    }

    for (int BhxnQE = 952648021; BhxnQE > 0; BhxnQE--) {
        TOSstAv *= iynhTJgNgkDwd;
        iynhTJgNgkDwd -= TOSstAv;
    }

    for (int chyLMQPIq = 1276792676; chyLMQPIq > 0; chyLMQPIq--) {
        TOSstAv -= iynhTJgNgkDwd;
        QAJQFULpBdKcehYc = ! QAJQFULpBdKcehYc;
    }

    if (AzrLbtPZulyXE >= string("KaXwASmyPgtDbKVOSGcUAlNufFEQpZwlZDGsoXhKEhBcIIdBfZNPploqHpTfhrFidCepsGkxxUvApIpUinGdAsQswJQoGOrpsBuzuoQqPaldXCsimAgGNqjYWWSraodOWMLJFpRCYlkmuYFBDRXEPGEUsSZqTbZkmmMFgmVXZLeZVdXDRGSIRexMNxzPaUImHyiTKhUGDlMsfYNzFiUlMsrLwQrlSCSVIoFBymevezUU")) {
        for (int JYSeHBFcVbsFmKO = 670332854; JYSeHBFcVbsFmKO > 0; JYSeHBFcVbsFmKO--) {
            continue;
        }
    }

    if (iynhTJgNgkDwd == -2081191585) {
        for (int ZOFDr = 275113788; ZOFDr > 0; ZOFDr--) {
            continue;
        }
    }

    if (iynhTJgNgkDwd == 838204049) {
        for (int ZFLSUpj = 569104038; ZFLSUpj > 0; ZFLSUpj--) {
            continue;
        }
    }

    if (iynhTJgNgkDwd > 838204049) {
        for (int aKpzCIU = 418585249; aKpzCIU > 0; aKpzCIU--) {
            continue;
        }
    }

    for (int MPKORQxMfKGL = 362053506; MPKORQxMfKGL > 0; MPKORQxMfKGL--) {
        continue;
    }

    return aIKvGbBKRfC;
}

string PvsjaLjjJ::vivxhXVmADy(bool RrjkxQst, string pCrHbKfFpe, double KXuTLaOj, int mcFfiXgBOivrC)
{
    int cBYIOFcgUJGFqMdu = -1531046242;
    bool JHdsAESXwrWbcNx = false;
    double xZyOrKHrhD = 553602.885531739;
    int RkOgngEnbElI = 1559622550;
    int XZbbXrqjhFUcPk = 821880923;
    int AAKmEhLadofimh = 1070595343;
    double WcpzQkpCpq = 186836.82322468667;

    return pCrHbKfFpe;
}

void PvsjaLjjJ::JIDgEEEuEQTgv(bool onehHRWX, string guWCUgwMCYRuY)
{
    string EOcSEDZRlvIyX = string("cuotQcRDnkvQqXnFvYOlcNIIjyIhMniWzbAMZXisWsqZUNwcYvxNWYlnBNHJHLwvGfbePKWFbtBkmblEwnAR");
    bool fzssJmTeHxjcG = true;
    bool TbGHdeuHHYzcsgdt = false;
    double bAKFqVIIhOnfb = 328149.21397261496;
    bool KeJsNnkzjFgp = true;
    double JcCDczmPM = 635717.7762840724;
    bool TCIxi = true;

    if (KeJsNnkzjFgp != true) {
        for (int oQKQmLnSJCp = 1441440444; oQKQmLnSJCp > 0; oQKQmLnSJCp--) {
            TbGHdeuHHYzcsgdt = ! TCIxi;
        }
    }

    for (int SqjZFABxkY = 462777143; SqjZFABxkY > 0; SqjZFABxkY--) {
        TCIxi = ! fzssJmTeHxjcG;
    }

    if (TCIxi == true) {
        for (int UrgqNKCnkf = 118023955; UrgqNKCnkf > 0; UrgqNKCnkf--) {
            continue;
        }
    }

    if (TbGHdeuHHYzcsgdt == false) {
        for (int nhocmbUUOrXcEmEx = 1445193962; nhocmbUUOrXcEmEx > 0; nhocmbUUOrXcEmEx--) {
            continue;
        }
    }
}

bool PvsjaLjjJ::ychHRoPsjCvKFIMN()
{
    int NSQyjKOYxo = -1943778418;
    bool TEJqOnbQBvCff = false;
    int wsdQWNmCqaCVW = 535623939;
    int vBDUeUEGrUudYxxg = -1824707726;
    int POvjHHCgwHCRoYi = -243813119;
    string LwTdffKMgoPZz = string("VZlwyRpjnScvYHtKoEfTZuUufVHspeWqOBHTnAYLmdFeQPCJktLOAuAoHMnAvXFjwaokwKndEhNXPKwIzBRRxEzBFkJaGSUaS");
    string qzPWkdbXcSxihn = string("prOpNXEGmazvmPRPDSJPQgbMIRmDWckuTpIHnHhRyIyoqDRlyIVegZOpqtHZWp");

    if (vBDUeUEGrUudYxxg > 535623939) {
        for (int PgriEkGayaPhnNv = 1745411319; PgriEkGayaPhnNv > 0; PgriEkGayaPhnNv--) {
            vBDUeUEGrUudYxxg *= vBDUeUEGrUudYxxg;
        }
    }

    for (int qSdAVWdZWfVsxeS = 1208797684; qSdAVWdZWfVsxeS > 0; qSdAVWdZWfVsxeS--) {
        POvjHHCgwHCRoYi /= NSQyjKOYxo;
        vBDUeUEGrUudYxxg += vBDUeUEGrUudYxxg;
        LwTdffKMgoPZz = LwTdffKMgoPZz;
    }

    return TEJqOnbQBvCff;
}

bool PvsjaLjjJ::EDUTrUdtGKgAlFYW(string LOomGv, int vRaljMQbdoq, int XtgzxYlSr)
{
    bool YpmMgkQrPjXbZepu = true;
    bool CVtngzGUTePZ = false;
    int cjpXuohntqxSag = 150407815;
    string nuJuPwrOBDL = string("ktMBDyCyAiQtZYkSTPIZmNRaZxFcoTEIKEYbSvQNZkMtpwEnPSIZjqzcHjhXQxUhZkueNxdJMvRAINRxYBgXFdbBflHSKfeGbdGCXVsZuvnAzCLqydVohmQhrJSUgiMRsaFoDfJzpIbMAqXAjyBjqyTHgYPyZLZJ");
    int ALSpoJQCPgLNW = 704183123;
    double rQyitApbSUxnq = -357674.70987668604;
    int wBzWQDbWK = -574375007;

    if (vRaljMQbdoq > -574375007) {
        for (int DFEkVpRjcbTO = 1236545903; DFEkVpRjcbTO > 0; DFEkVpRjcbTO--) {
            XtgzxYlSr /= vRaljMQbdoq;
        }
    }

    if (cjpXuohntqxSag < -1274686393) {
        for (int nxRDy = 2052983927; nxRDy > 0; nxRDy--) {
            ALSpoJQCPgLNW /= vRaljMQbdoq;
            ALSpoJQCPgLNW /= cjpXuohntqxSag;
            wBzWQDbWK += XtgzxYlSr;
            wBzWQDbWK *= wBzWQDbWK;
        }
    }

    return CVtngzGUTePZ;
}

string PvsjaLjjJ::jYckzWworJMwu(double kwhHZdDqGvjS, string xsFjmoXxiI, double NeuHMDMtqRtjG, int vwXPCcYPShcMh)
{
    int xcdHHuLKFIUhbJt = -1305230779;
    double bYUatJFwvSYHEWVs = 92396.30880318902;
    double XuWpjf = -933608.3866361945;
    string Hmerpj = string("yVAebVdjNpAuvfAcMaCxzeeeqtZzNEHVNPrQxUcJmwHDOoYIUOnfevrFXGOxnlgfekKOeRKxZmFxWwCpxUGuvVkdwwOlTVDYPoedBIvXaADcyfzNDNBAOaXCBTcysFTZhecigOYuraCSfCUjCDxCEEWWGAqwLTQkvOPXfrDqjULAdTCVbWnUrZyygQkMyzricVPDaxqjNmKkEnofkRAbHXZEaRG");
    double ypPKqC = -552485.6126166306;
    bool kjwcjmBqrXS = false;

    for (int dzgooKofnD = 341569524; dzgooKofnD > 0; dzgooKofnD--) {
        bYUatJFwvSYHEWVs *= XuWpjf;
        bYUatJFwvSYHEWVs *= XuWpjf;
        bYUatJFwvSYHEWVs *= XuWpjf;
    }

    return Hmerpj;
}

int PvsjaLjjJ::KCGVK(bool tmciduuinz, string egqPNDyKNoV)
{
    string HovSOhIeYEOK = string("YItfxRYQbSajcuHApNrAzqeoPjtwXfBjHYDRvnmuGZpHhpXDrGjVQjEHjnucnvdmRiLGBUiljPfjtzvYEEemBxCxPwsFORGDexjlZbhOjkfeeYkvsHpCugvQublPpRSoosAjBfWjonmICVIpfFVaATWloVWE");
    int aAguOSRCW = -38577154;
    bool vEyZpPi = false;
    int phRTflxswXYkh = 1834271453;
    bool VFXnwTLYO = true;

    if (VFXnwTLYO == true) {
        for (int yResIx = 1736215801; yResIx > 0; yResIx--) {
            HovSOhIeYEOK = HovSOhIeYEOK;
            vEyZpPi = ! VFXnwTLYO;
        }
    }

    for (int cjLkJGDIPrOjs = 2043822304; cjLkJGDIPrOjs > 0; cjLkJGDIPrOjs--) {
        continue;
    }

    for (int mdmoJGzzPbGXd = 1570073314; mdmoJGzzPbGXd > 0; mdmoJGzzPbGXd--) {
        continue;
    }

    for (int oNESOvuQjRiIYqL = 1849074102; oNESOvuQjRiIYqL > 0; oNESOvuQjRiIYqL--) {
        VFXnwTLYO = ! VFXnwTLYO;
        VFXnwTLYO = VFXnwTLYO;
    }

    return phRTflxswXYkh;
}

PvsjaLjjJ::PvsjaLjjJ()
{
    this->QjMBRnIXphP(false, string("KaXwASmyPgtDbKVOSGcUAlNufFEQpZwlZDGsoXhKEhBcIIdBfZNPploqHpTfhrFidCepsGkxxUvApIpUinGdAsQswJQoGOrpsBuzuoQqPaldXCsimAgGNqjYWWSraodOWMLJFpRCYlkmuYFBDRXEPGEUsSZqTbZkmmMFgmVXZLeZVdXDRGSIRexMNxzPaUImHyiTKhUGDlMsfYNzFiUlMsrLwQrlSCSVIoFBymevezUU"));
    this->vivxhXVmADy(true, string("tglMKrjpgngdBfLeNtEDardgEGrOzUEAUBlLjcvmIyJRuflSHTfCrkhtfChCfOaQkQZFrjbcWxjYjYHrlfyoJUEecAvhKjdNwHlgqlOTzQZltQhUErkssiCjaPLVuzDms"), 189785.00595791428, 244594155);
    this->JIDgEEEuEQTgv(false, string("BZdbAQMCMvmDfitemWyUXIASjBnHUgABSa"));
    this->ychHRoPsjCvKFIMN();
    this->EDUTrUdtGKgAlFYW(string("BkdiupZcNmfrZTrwdNYhCslexPRfuTndbrxILWaFgrowvMMFDKvWEHjxoCkvshvUxmhSaCqJyVlafPGEwwPZOJmvnfbemwNzQNIZJUshBSrzFMGMeONuAaPLwxrMQeVSneRloXmKRhVZyotJLGRWzAGb"), 554601871, -1274686393);
    this->jYckzWworJMwu(-47802.78139190283, string("ICkrFvICXotZYRaifUIAiolGkZWFsvMMjlwRRYbhAsRArahJCueojvGBlmEdYgAwVbqJGXoeVGlGoOjIdqIRyWJjapClgXGZiCFfKGapAHDyShVDysHxrBdulvCRVdbOYMECanlrTyMZjnndSsrKW"), -470153.833743461, -1213948836);
    this->KCGVK(true, string("cuDbDQfVkYiHMqdyJkbiLKBRjEZNlyaxZIqyRKqLcXxULygdImwWtIcydvNUBNCdoxAyBNguTRNLsMGNaohhVbqWKqmdLqtGcQUqImaUfCNmeOVopRGaTxTlWlFQlrLyCsjXdpdfmMqpHPgzbmmgIMNiadkRvBlraohwXteHmhIhaQp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JbrHz
{
public:
    bool xAgZUSOXQXY;
    string EFbJWC;
    bool zJyOnT;
    bool WQDEFZ;
    int rcHBe;

    JbrHz();
    string ZLHexN(double zztwOZFXq, double fLYHjqpbTqQx, int kbuYEIbiqG);
    string zgDJYqxAhavytPZn(string qewWpn, bool MDmuhslL, int bdiUpWEJdJsOpo, string qXogIMeEtaMO, int PYlaEuhWXI);
    bool VTSyFJ(string brNtpSbGdKb, double ChMqPcPHuPBRm, bool ETferzKAQ, string PqZnVkBQ, bool NGMPrdcbarR);
    bool NUwuQrOQzt();
    void TCJovgubbn(int fhGjTMlqPqq, double lePMsleB, int PKjDxrudpMk, string kjwQfyCydqI, string edffYwgiOGJyLG);
protected:
    string EuBcCpdsq;

    string faocqnip(string PYKfKBiNCMNywEfR);
    void VDDHWu(bool maGGxgPkbrx, int yVbSCBl, string mzDiqDq, string XlKstBzfGwInXNOh, double hWlTgHp);
    void MjRHsJVduHpow();
private:
    bool Xvhhbwyh;
    double jUpJFxAzQbFheRG;
    int gpGZPRgVYnLYO;
    int lZhKfPdp;
    double MvuGVabGLto;

    int AgYvCqm(int kJjCnbv, string tbuyvuyvxyAAUTdD, string VtVtKpDNKu, double RlwGtMufXCJJVE);
    string ArayTLnLfWzGqE(double ToCRDELWMUvhydLM, double jwUzEc);
};

string JbrHz::ZLHexN(double zztwOZFXq, double fLYHjqpbTqQx, int kbuYEIbiqG)
{
    int pWjvxqEOmDcZzAVD = -2022376398;
    string gEgNUNIiSofFbl = string("AdBflDpQImUqaiMqWdTcxCaqkpawdVxZVRWxOBfxOfJUNNkGxcnbYqpzGWgwsnApGMPJCpAAgOtfsDPpHgREucbKwsZKkUpDhaWSEkSAbzBXkPBSojWOMopdlhKLJsJqlUHThXEziEFCrWKGWmrZbit");
    string hRaQFkdMPFyy = string("WJlXzQCifGCGmgUtBOpGAryZbYAnfRxaTBKWBYFxddLUrqlffvBfCYqvLYRTsukwVdfrYXYDnGciXiSgYpUFHWPdaBkjuGFfCOIqt");
    bool rPUxTwktvuh = true;
    bool kTEyDDiUpRu = false;
    string hBjTXLzJ = string("xHKnaDoSVLRMIPvqMkoGBrbQfPQpaBkgfxfBPdnpUyLsqIpaJlYnfhrrnDLQjgslKanghgIgZthaIVULLJUICwmdbYQTYqXiJsXLmSrBlGmZxXxxdWgaZWoqEukifmyfiyWYCSMU");
    bool yIfXY = false;
    int QHkHoLttXa = 1905404666;
    int NxTdMKUacTtXhmV = 743256460;
    int wteeUnc = -186325084;

    for (int VbjqpptCJIHiPpy = 1464463493; VbjqpptCJIHiPpy > 0; VbjqpptCJIHiPpy--) {
        continue;
    }

    for (int hxMhT = 2128142647; hxMhT > 0; hxMhT--) {
        QHkHoLttXa *= wteeUnc;
        zztwOZFXq -= zztwOZFXq;
        kTEyDDiUpRu = yIfXY;
    }

    for (int rgXMOcB = 210139300; rgXMOcB > 0; rgXMOcB--) {
        gEgNUNIiSofFbl = hRaQFkdMPFyy;
        NxTdMKUacTtXhmV = wteeUnc;
        hRaQFkdMPFyy = gEgNUNIiSofFbl;
        QHkHoLttXa = NxTdMKUacTtXhmV;
    }

    return hBjTXLzJ;
}

string JbrHz::zgDJYqxAhavytPZn(string qewWpn, bool MDmuhslL, int bdiUpWEJdJsOpo, string qXogIMeEtaMO, int PYlaEuhWXI)
{
    int EhEajTTaERvJKzn = 985807436;
    double PHYSeGukA = 890288.3890147604;
    string kdBukaRioJiH = string("bBEFxLnSpCuugrwIujTBvf");
    string bvHnlOQMj = string("URfAvMGM");
    int WnJaGJGTD = 1688197323;
    double QEMmzOPfivIQRzMv = 793851.3389092202;
    int YnlwDthMwLyH = -887658582;
    int YUlVJAyNzrUyGen = 342779903;
    bool zkaQNTSukQpMNQSa = true;
    string MQpwwJ = string("DdZqKZQMvqKTRHXxtTADYBoXucwwkqXaVWiXapkfFQSpiPDvRGvFHlylSBxQNhLqzaWijSeXxlSyUpwpgNIaofZ");

    for (int QLGtcphUcxNawI = 1974896504; QLGtcphUcxNawI > 0; QLGtcphUcxNawI--) {
        YnlwDthMwLyH /= YnlwDthMwLyH;
        bdiUpWEJdJsOpo /= bdiUpWEJdJsOpo;
    }

    return MQpwwJ;
}

bool JbrHz::VTSyFJ(string brNtpSbGdKb, double ChMqPcPHuPBRm, bool ETferzKAQ, string PqZnVkBQ, bool NGMPrdcbarR)
{
    int gypRbStGtLqZThug = -333635934;
    int RIisD = 1155394609;
    double SvLaHhM = -558407.0514451001;
    string cUqCzbrhPy = string("SSUvIMkeHaiYGqHHwvqCmVIrnNSyfbhwTnCbIQHHJuPvIWVbrwjfpJejDRZIDmkIbGGkFGKBmOpAhjxKDiISWSdSgbcSdDgbmuxamNujmSCfVdXWytzylAsBUsJmAJqXYAGmyOZNVCilpYGXnizOltFNZMGVXtwvZkYehJTjWkPsbUMkcomyKEspyHHloidMAkGvcWWwrHbBkJagnqugfqOcrLPiIyaAaspPkIIGgasAOhWTMYljHfdtJc");

    if (gypRbStGtLqZThug != -333635934) {
        for (int QKHpTHRz = 2115368158; QKHpTHRz > 0; QKHpTHRz--) {
            continue;
        }
    }

    for (int ZiMhjaxQSyXRaHa = 969620005; ZiMhjaxQSyXRaHa > 0; ZiMhjaxQSyXRaHa--) {
        NGMPrdcbarR = ! NGMPrdcbarR;
        ChMqPcPHuPBRm /= ChMqPcPHuPBRm;
        SvLaHhM /= ChMqPcPHuPBRm;
    }

    if (SvLaHhM <= -558407.0514451001) {
        for (int QvobKbOWl = 1064545335; QvobKbOWl > 0; QvobKbOWl--) {
            ETferzKAQ = ! ETferzKAQ;
        }
    }

    if (ChMqPcPHuPBRm >= -558407.0514451001) {
        for (int JXaCsvndbiGO = 1216743417; JXaCsvndbiGO > 0; JXaCsvndbiGO--) {
            continue;
        }
    }

    return NGMPrdcbarR;
}

bool JbrHz::NUwuQrOQzt()
{
    string QFtiRxCayV = string("JWZaYqWixWidEYdroGjTLatFMfJSPRFUxCaFlHHQuSfDvDJiUQnEpCdrEXAirpLjobsbHqxXGYsflcJwcoADPBJghNUUljgylSwTAkEuBXPFXyeLtfJaJwmHtwDoqvKHUsR");
    string MrKEHMPIwK = string("iUozaqrMedvkWOgwldhLTEUSxPyluYvtEzWGDLQFOERdyYttLMKHCkrTVeoXFCIhkXgEiOMshTeMvOadeMlSMQWVJgkyDuHsWKJBmgmcUJtycBpXxOwoBWPtUDuFmXSUTUAcxevQ");
    string GllLtCzLbEGclVT = string("NLJjgJhJPIYRdx");
    double uFNUzBANDqqwtL = 18757.645448106632;
    double lyaoibLEzRHRcA = -413305.41426888946;

    if (uFNUzBANDqqwtL != 18757.645448106632) {
        for (int debROxyhWYzN = 819563916; debROxyhWYzN > 0; debROxyhWYzN--) {
            MrKEHMPIwK += GllLtCzLbEGclVT;
            QFtiRxCayV = MrKEHMPIwK;
            lyaoibLEzRHRcA += uFNUzBANDqqwtL;
        }
    }

    for (int MzQIvVkUeUpoco = 1454709640; MzQIvVkUeUpoco > 0; MzQIvVkUeUpoco--) {
        lyaoibLEzRHRcA *= uFNUzBANDqqwtL;
        uFNUzBANDqqwtL = uFNUzBANDqqwtL;
        QFtiRxCayV = GllLtCzLbEGclVT;
        uFNUzBANDqqwtL *= uFNUzBANDqqwtL;
    }

    return false;
}

void JbrHz::TCJovgubbn(int fhGjTMlqPqq, double lePMsleB, int PKjDxrudpMk, string kjwQfyCydqI, string edffYwgiOGJyLG)
{
    string oRgTGrIziwyz = string("gbaNqqVFITTyJKEsThXOWbtXeQVbXezChblGazSQWXpyHxSkyRmDMLORQpXObwMtiusGoHADFzZYGxgBbFerDRXhLPTQzLEKSeqaERMVXujcyvkXVREQomRPKcQNTVpQGRtgBZnbGynNIIMbWxSzhDBYcTAFZQWdeHzXoEENafFRVZVCxXNiOUHfORDNCvKgNckaSponzvUnnjJFcft");
    bool VXrYgxWTFCMaXdkU = true;
    bool ANlxkHTKUvoKb = true;
    bool FsvgxwxhQXerJElr = true;
    double poXin = -575139.9842623929;
    double xztFKZhmkshCzgOC = -860708.4237722502;
    bool CEBeEYntRQGa = true;

    for (int GDJZhnjAmdxQSi = 1245216324; GDJZhnjAmdxQSi > 0; GDJZhnjAmdxQSi--) {
        continue;
    }

    for (int JyGUbyLR = 1402997692; JyGUbyLR > 0; JyGUbyLR--) {
        xztFKZhmkshCzgOC /= lePMsleB;
        FsvgxwxhQXerJElr = ANlxkHTKUvoKb;
    }

    if (xztFKZhmkshCzgOC == -189855.06421082458) {
        for (int yjhgeNMGxPGykH = 1928914917; yjhgeNMGxPGykH > 0; yjhgeNMGxPGykH--) {
            ANlxkHTKUvoKb = ! VXrYgxWTFCMaXdkU;
            poXin /= poXin;
        }
    }

    for (int yGDZyIjXJXrNOhq = 312783016; yGDZyIjXJXrNOhq > 0; yGDZyIjXJXrNOhq--) {
        continue;
    }

    if (oRgTGrIziwyz != string("gbaNqqVFITTyJKEsThXOWbtXeQVbXezChblGazSQWXpyHxSkyRmDMLORQpXObwMtiusGoHADFzZYGxgBbFerDRXhLPTQzLEKSeqaERMVXujcyvkXVREQomRPKcQNTVpQGRtgBZnbGynNIIMbWxSzhDBYcTAFZQWdeHzXoEENafFRVZVCxXNiOUHfORDNCvKgNckaSponzvUnnjJFcft")) {
        for (int fbnacgmMcoyBaJW = 1653282261; fbnacgmMcoyBaJW > 0; fbnacgmMcoyBaJW--) {
            oRgTGrIziwyz = edffYwgiOGJyLG;
            FsvgxwxhQXerJElr = FsvgxwxhQXerJElr;
        }
    }
}

string JbrHz::faocqnip(string PYKfKBiNCMNywEfR)
{
    double MYEzsuvoDuwWe = 736616.8112313194;
    double Afzxb = -50947.09207924149;
    double rAnhRCxZA = -680807.5722001529;
    int eacLsGEXhrbQBe = 34920576;
    string tRusJQZvCb = string("KKC");
    int HLfhHDnzduhs = 370261310;
    int waPGFewWuNTk = 1506759359;

    for (int AOsGMSphgj = 724542489; AOsGMSphgj > 0; AOsGMSphgj--) {
        PYKfKBiNCMNywEfR += PYKfKBiNCMNywEfR;
    }

    for (int diYLdBggkAmZJ = 1911894873; diYLdBggkAmZJ > 0; diYLdBggkAmZJ--) {
        waPGFewWuNTk *= eacLsGEXhrbQBe;
        eacLsGEXhrbQBe *= HLfhHDnzduhs;
        eacLsGEXhrbQBe *= eacLsGEXhrbQBe;
    }

    for (int neCId = 954632073; neCId > 0; neCId--) {
        rAnhRCxZA = MYEzsuvoDuwWe;
        waPGFewWuNTk = waPGFewWuNTk;
    }

    for (int YdEbKF = 1558675465; YdEbKF > 0; YdEbKF--) {
        tRusJQZvCb += PYKfKBiNCMNywEfR;
    }

    if (eacLsGEXhrbQBe >= 370261310) {
        for (int sADEMAPYwwKbClDu = 1205448320; sADEMAPYwwKbClDu > 0; sADEMAPYwwKbClDu--) {
            PYKfKBiNCMNywEfR = PYKfKBiNCMNywEfR;
            eacLsGEXhrbQBe = HLfhHDnzduhs;
            waPGFewWuNTk *= HLfhHDnzduhs;
            tRusJQZvCb = PYKfKBiNCMNywEfR;
        }
    }

    return tRusJQZvCb;
}

void JbrHz::VDDHWu(bool maGGxgPkbrx, int yVbSCBl, string mzDiqDq, string XlKstBzfGwInXNOh, double hWlTgHp)
{
    string bpomRNSOCPOiWIl = string("XovkpNgocswEkctVmdcktWgyqfWQIEJgLGUZhMWUhehlWDETuXdsJJjYKFHpTCSoxJqTJJOQVkqvrTDfMbaWKCZfpVLEvLDuxNEFlwsEkhCKnjYvjjSRgtoljmByBOVAqoMk");
    double AwtXdEzfssIBGc = 598266.8995505869;
    double nJlQYvifB = 253604.96440955272;
    double GuoIlWoeTkI = 145871.78349642886;
    string ZgGXJgk = string("rsosXPAxmTMSDMVAYeLPMyHlkuMFNNYnLOtMvVwpozGRoHSRYoQspGMFLlzpfze");
    double LRzMyLZOizislT = 365747.85426627833;
    bool IIakwBBDLZNzR = true;
    bool AbZvIJxj = true;
    string IeaFQhe = string("bpNrYPDsOCLrJPRHejAXZpWzbKmHNwnNawxwyKaBhgwVjOxAqemHDRrbpzMcBniPdWHKuNdPAmFtBCajcCSKqNRpyyNsjDmUeodtqkrkFJihjwtRNxZLcxBPNtdQRFuJyKjTwVmnVTlYetXATeXJugDhQduwXnPUANCzoSPMMttYIxxASCttLahvUkzaQXwgbqVOLgvWMjuTNEDkfoQbyjlHZMGzovcs");
    string qlXCbxKPizYluD = string("tbrDsHubbWExEKtzquDZwgCyCQEVBccSAdGIrKeILzLtrkfJmhlAZqCnZxhpjsIVebZZEXzsfPbMcpkIZbHyJtxnmeuGCQPhxNHcQtdimeXNYvGOiTvAdXMmdfwUAIokOTeHCXYikQEqrCRGBhsEEPAgNeXSYVT");

    for (int EkgomPmFKLFjALe = 107734271; EkgomPmFKLFjALe > 0; EkgomPmFKLFjALe--) {
        continue;
    }

    if (LRzMyLZOizislT <= 598266.8995505869) {
        for (int hJkHRbQFsbosajr = 587814825; hJkHRbQFsbosajr > 0; hJkHRbQFsbosajr--) {
            qlXCbxKPizYluD = XlKstBzfGwInXNOh;
            LRzMyLZOizislT *= nJlQYvifB;
        }
    }

    if (ZgGXJgk >= string("tbrDsHubbWExEKtzquDZwgCyCQEVBccSAdGIrKeILzLtrkfJmhlAZqCnZxhpjsIVebZZEXzsfPbMcpkIZbHyJtxnmeuGCQPhxNHcQtdimeXNYvGOiTvAdXMmdfwUAIokOTeHCXYikQEqrCRGBhsEEPAgNeXSYVT")) {
        for (int tRhvA = 780924275; tRhvA > 0; tRhvA--) {
            LRzMyLZOizislT = LRzMyLZOizislT;
            GuoIlWoeTkI /= LRzMyLZOizislT;
            ZgGXJgk += IeaFQhe;
        }
    }

    for (int XRbrirOKa = 1547659156; XRbrirOKa > 0; XRbrirOKa--) {
        GuoIlWoeTkI -= nJlQYvifB;
        nJlQYvifB += nJlQYvifB;
        qlXCbxKPizYluD += IeaFQhe;
        AwtXdEzfssIBGc = AwtXdEzfssIBGc;
    }

    for (int zKTmAMyQAuaHaTub = 1887005197; zKTmAMyQAuaHaTub > 0; zKTmAMyQAuaHaTub--) {
        continue;
    }

    for (int zHlEXbrRvRnJczQ = 1387881440; zHlEXbrRvRnJczQ > 0; zHlEXbrRvRnJczQ--) {
        qlXCbxKPizYluD = ZgGXJgk;
    }
}

void JbrHz::MjRHsJVduHpow()
{
    int nIoHZLdLkQW = 1688671039;
    double PBwhoOxCF = 58766.03769247078;
    int UBifDg = 1376203417;
    bool hAChJHjZf = false;
    string JZZZhQFREeqhKs = string("IEbNdrOiKiTAplXvMofPcYGHIUsXJqRamNJiYgRxkLrBpUqmRyBWcTQFKtQTLDbFMlMRUKosnbwYytzvQpBuPtSorLSldQIPfgIjBotxPQkNBuSwOxjPhrQQUMhAndpcxXJEHNBtTBneDkubGyfFE");
    int DDmrMyjXV = 1666965048;

    for (int BqxxgVGFvRD = 595613109; BqxxgVGFvRD > 0; BqxxgVGFvRD--) {
        PBwhoOxCF += PBwhoOxCF;
        JZZZhQFREeqhKs += JZZZhQFREeqhKs;
    }
}

int JbrHz::AgYvCqm(int kJjCnbv, string tbuyvuyvxyAAUTdD, string VtVtKpDNKu, double RlwGtMufXCJJVE)
{
    int iXTpbTykfN = 733669162;
    bool uHPZghj = false;
    int UzwFPTVq = 1837110744;
    bool yozkniIuM = false;

    for (int jSBKKClndyOFGdV = 1360253049; jSBKKClndyOFGdV > 0; jSBKKClndyOFGdV--) {
        kJjCnbv /= kJjCnbv;
        iXTpbTykfN = kJjCnbv;
        UzwFPTVq *= UzwFPTVq;
    }

    for (int odZazt = 1471260406; odZazt > 0; odZazt--) {
        UzwFPTVq *= UzwFPTVq;
    }

    return UzwFPTVq;
}

string JbrHz::ArayTLnLfWzGqE(double ToCRDELWMUvhydLM, double jwUzEc)
{
    int MfenfObik = 974954829;
    string EuYyCtR = string("JunAIDbNBzFnxPGMnLfhurLIkAjRLPHpkEVbnUgNuwOIxNSrjSGWZXjlHwOVyRicrTWREHXOxIzayGXqSZILZOYoKTVSMANoEDwIWIcEfndlHorplWLLllDfyzQKmmDtFdPmmCuRdnaAZuirfcCfyRxWPvnavrdKwaOxjpweTOAyydiDQbPaXJtRwnezZdbcZuIlBKzISFnzwFliykpKXxyLDuReYgUQTnBfGHUfSQkTpUIFhTOkLrGCjR");
    string svpqXC = string("gsSsgFzjiDbguzwnEEesrZBirLSzpoLVMPDoUWdgjhYGhxeKgmqarCNlDKRUpXLTnuzMEUP");
    bool BJGgHudwNskK = true;
    double zIhibLaVgwWjQKQ = -27427.702891017536;
    double nsSegj = 299407.0210388863;

    for (int wpOVsK = 766101882; wpOVsK > 0; wpOVsK--) {
        ToCRDELWMUvhydLM *= zIhibLaVgwWjQKQ;
    }

    if (nsSegj == -27427.702891017536) {
        for (int ZBTjUxZr = 1880548267; ZBTjUxZr > 0; ZBTjUxZr--) {
            zIhibLaVgwWjQKQ = nsSegj;
        }
    }

    for (int brIBSMK = 1211918244; brIBSMK > 0; brIBSMK--) {
        ToCRDELWMUvhydLM = zIhibLaVgwWjQKQ;
        EuYyCtR = svpqXC;
        svpqXC = svpqXC;
        ToCRDELWMUvhydLM = zIhibLaVgwWjQKQ;
        svpqXC = svpqXC;
    }

    if (nsSegj > -803020.2442129856) {
        for (int mWmRmQjuwYhaJTxb = 1207900755; mWmRmQjuwYhaJTxb > 0; mWmRmQjuwYhaJTxb--) {
            EuYyCtR += svpqXC;
            zIhibLaVgwWjQKQ = nsSegj;
        }
    }

    for (int vScszYk = 1447505448; vScszYk > 0; vScszYk--) {
        continue;
    }

    return svpqXC;
}

JbrHz::JbrHz()
{
    this->ZLHexN(-865062.2988888102, -670348.0555300844, 923919609);
    this->zgDJYqxAhavytPZn(string("lneRAghnTaNGWeoXEyizgRBNfOOsAQnhJZBlsGlyvCbErynDEdWkewR"), true, -2058670538, string("XzNuEXiyFGHgmktyPjYjqeiQQIMvjOyuYQIJOHBVqzoiEIemyzpVfqGqBIzUaqkYtsbCGBWEPVmNYRbVcOlep"), 1630716051);
    this->VTSyFJ(string("uXhwvoIfxweNVhaFRvcCPAPCRzAceMufZskvsRWlzjjbG"), 307603.1881403032, false, string("qRCO"), false);
    this->NUwuQrOQzt();
    this->TCJovgubbn(-997579540, -189855.06421082458, 632690811, string("CMmMgwATDvDroOMDmCen"), string("BSiLdgLHcVnIZxEaQNnFSaeprjlRYlWVtEnyzjIKIWUtxyFGYdHhAKzkJIMcZhaVOHuvKpkUSSzyajxCdonTASnpHfbKJQXnSmPrgSYSbdcvQAZnhvrNOLegyHIjQbOFHYySpsgCkzsMNROMhZEcuysMkilkUnFFtCWdkUOAmBNWLekuhyLPLoHRDubiAArywLkOssnbMqrzWRubDQwpjCgHnFztO"));
    this->faocqnip(string("OSNERNVzXdSadzLifkcKRpwgBmHmXMq"));
    this->VDDHWu(true, -485512296, string("TkKEMloQZTmqigubEOnGWCOrXaxeJvzNtXoIEPZuPHPDEOeATOukWykQxrmRjWpUlKacjvgbvqrGbgoSRrJNijMZRkUMpFHZvLwgiciIZEcYoSadyRJrSbHKGMMwFhTsxbJlORlpqGGGyDQnhNEuMZfSCbLSNszzdqlydSnVdJzrwfQWjVQdv"), string("YBPBWNQrLMxnumUpuRzqaAGxNgxKWTNrcWzdVMbnQotXaXrekXnpxwzlXLWvaVtRqUgERyMBmFhWNQFvogbfhncudbogLxzLaITjQBjsJmNbdiWYBsxwNZinRJeSQXfOBglHpwCvBRiJaS"), -221845.96747831185);
    this->MjRHsJVduHpow();
    this->AgYvCqm(2116240301, string("DmLviFcmbNYnDRDtGSogDGHGdcwbdsjwMgOLrBEFkvErrOwXHAKTgGRTukNatiQOIwGENZTFNIsrwYGfHuhpcsPILAPMwUgHjMLqprUattRxejQXxVoT"), string("qLtfdOhsfuPcpQhqKiNxUuntYqhvhMRu"), -988338.8244021446);
    this->ArayTLnLfWzGqE(644686.4068089051, -803020.2442129856);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XgckeT
{
public:
    string YXCfCF;
    double YIHyiAb;
    bool wtwdLtlVcjmNqUL;

    XgckeT();
    double dboqSi(double ayOTSMwuHp, bool cMruVGWdUeyfFk, bool EkmIYwjezlTJZGCg, string qrVlJBrxuzemJl);
    double CclLSurFOzDLKv(int IHnUi, double aTzbAAzEDNfM, int ZBBNpqgBIW);
protected:
    double rVxiSRdVqqPxzrQ;
    double ppwHvn;

    string GzitBgfIuiYW(int sJCbZw, bool fjGPCSFApOKF, int KBSPgEymy);
    bool UHPQrIzTEpGth(int PdOYLbhkEhngflv, int tLlzqXgMA, bool RdCyueVzCSbA);
    bool BukhSzNiS(double mvWhnZilZhf, string NYmMgiaWJKWLJ, bool TETHKCo);
    void HqOzP(double QnmLqvCnkQrSzXD);
    void PduHJkRRQB(bool vrFBWjiWCtds, string FZYtvrP, int dTLGDuEPdBX, int yzSJozx, bool xJDaoUeXMNUhePe);
    double GapdbW(string nsMPU, string VtsxMmqbLOEd, string hhtodakMau, bool jMFzlPflzs);
    void SbHeyPeoQES();
private:
    double PiagGm;
    int FJAXKk;
    int iimWzOFTVmHuuJ;

    double SnYGYdoVDFI(bool hBQsKORAT, int FdimHHfNjVmPH, double QqtOKCmsoMG, bool UuiRYAEIKOU);
    int ZgadOBqIkBulrt();
    bool IztPHJs(double IJZlHdFnILYciTp, int TTkLA);
};

double XgckeT::dboqSi(double ayOTSMwuHp, bool cMruVGWdUeyfFk, bool EkmIYwjezlTJZGCg, string qrVlJBrxuzemJl)
{
    string bDRJNaQ = string("nWHgfptRPJijjGsuJvbAFUvpkQTDHgeQsbemmNtBmozYleIRzwzDaAWEzWYwalrp");
    double rKkRuXMLNNu = -138758.16895634326;

    if (bDRJNaQ == string("nWHgfptRPJijjGsuJvbAFUvpkQTDHgeQsbemmNtBmozYleIRzwzDaAWEzWYwalrp")) {
        for (int rUTCEJUo = 1881435320; rUTCEJUo > 0; rUTCEJUo--) {
            continue;
        }
    }

    for (int zCkhxJTSVLsYO = 1869727288; zCkhxJTSVLsYO > 0; zCkhxJTSVLsYO--) {
        cMruVGWdUeyfFk = ! EkmIYwjezlTJZGCg;
    }

    for (int OCGSTuzwUnzXskv = 1757713109; OCGSTuzwUnzXskv > 0; OCGSTuzwUnzXskv--) {
        qrVlJBrxuzemJl += qrVlJBrxuzemJl;
        qrVlJBrxuzemJl = qrVlJBrxuzemJl;
    }

    return rKkRuXMLNNu;
}

double XgckeT::CclLSurFOzDLKv(int IHnUi, double aTzbAAzEDNfM, int ZBBNpqgBIW)
{
    bool PLsuxbAEk = true;
    int ZZDqANeBaVAkdOy = -1214288826;
    bool eQmuKQisqK = false;
    bool AGWUNgYaRftbVOWu = false;
    double FKlqldvItb = 291702.7368846303;
    int LCXVYxSzkNyrRRP = 1200170996;
    string kycqqnypYhLYT = string("uNNUSJcpvyyYtqSFeiYfDdfetCwlImNfGgbyMcaXrLiORaLvlmYnwejbaYEqDPKIjmLOqzobYAndLBxQLbxSgOrDidAWoVuujzHJqUhESIaLHdsRfmENHrAXthrLbTjMKawWL");

    if (AGWUNgYaRftbVOWu == false) {
        for (int BTaLGKntAHHjCUS = 1839192875; BTaLGKntAHHjCUS > 0; BTaLGKntAHHjCUS--) {
            eQmuKQisqK = eQmuKQisqK;
            eQmuKQisqK = ! PLsuxbAEk;
            FKlqldvItb = aTzbAAzEDNfM;
        }
    }

    for (int Pktqt = 788319389; Pktqt > 0; Pktqt--) {
        continue;
    }

    if (FKlqldvItb <= 291702.7368846303) {
        for (int SaHTrG = 622072908; SaHTrG > 0; SaHTrG--) {
            LCXVYxSzkNyrRRP /= ZZDqANeBaVAkdOy;
            IHnUi *= IHnUi;
            PLsuxbAEk = ! PLsuxbAEk;
            AGWUNgYaRftbVOWu = PLsuxbAEk;
            ZBBNpqgBIW /= ZZDqANeBaVAkdOy;
        }
    }

    return FKlqldvItb;
}

string XgckeT::GzitBgfIuiYW(int sJCbZw, bool fjGPCSFApOKF, int KBSPgEymy)
{
    string bllgITxAPhfAbpFK = string("HswGckhQRfkSmggMboTvZqxCkeowdhBaJCrAFzBuELPNmdTjaHvqbIeaDABfdHyOkSaYmbilRAbMfxuVOZORVawnvhTcPfuZIesRQgDlIZUgrAefkzswueHvXWEpZYxrgtFGYeHqDGAWaFtVtNIGQMIcDmSMLZbQdMKDNALhyTiQsXlGpEZBzWMDHimJxIkuVxZFUcbNZtTONJFfrjGjxKndYyDBYEayORKpRMfLXcKJGRTqHLIs");
    string PNcVEqUaP = string("OXSSDefdAPRTjvbUZrlmBszXWchNXkOmzhwMUBjBekqgjAjnMXpwYwsDTLpnGEMMxIsewmP");
    int AZhZMZpVC = -134546848;

    for (int zaFfdorDjRijr = 1570246536; zaFfdorDjRijr > 0; zaFfdorDjRijr--) {
        AZhZMZpVC += sJCbZw;
        fjGPCSFApOKF = fjGPCSFApOKF;
        AZhZMZpVC /= sJCbZw;
        bllgITxAPhfAbpFK = PNcVEqUaP;
    }

    for (int AFwPABeNVxee = 15860480; AFwPABeNVxee > 0; AFwPABeNVxee--) {
        AZhZMZpVC /= sJCbZw;
        AZhZMZpVC /= sJCbZw;
        AZhZMZpVC += sJCbZw;
    }

    return PNcVEqUaP;
}

bool XgckeT::UHPQrIzTEpGth(int PdOYLbhkEhngflv, int tLlzqXgMA, bool RdCyueVzCSbA)
{
    bool zHCrrwiOpQMkXEn = false;
    int sfmZJKaxOyOqZT = -195583680;
    bool fRDXlYxczHPcZNa = false;
    string GXUePd = string("WOznqJRODssfLqipmijUMazVBLJFhgDfuvXTeZgJYpJmjVlBXfGPokWtNAjBIqTTdSzvTRYgiovzezmvLhiaOwcEUVVcdgxNiNzE");
    int LVtvYKHPumdd = -950099817;

    for (int PcziedOrU = 1367190176; PcziedOrU > 0; PcziedOrU--) {
        RdCyueVzCSbA = RdCyueVzCSbA;
        sfmZJKaxOyOqZT *= LVtvYKHPumdd;
        LVtvYKHPumdd += PdOYLbhkEhngflv;
        zHCrrwiOpQMkXEn = ! RdCyueVzCSbA;
        RdCyueVzCSbA = RdCyueVzCSbA;
    }

    return fRDXlYxczHPcZNa;
}

bool XgckeT::BukhSzNiS(double mvWhnZilZhf, string NYmMgiaWJKWLJ, bool TETHKCo)
{
    string ROzfVNk = string("UxMZbgKobwBlOexgsOsnGUjvaHLjJWTyWwvjlESnsvwrydCvMXpxIFrBgCuPoNWPaUvdAsDmtybD");
    bool iAjjMJnbPsVMi = false;
    double htbbkpmqPDYEjQ = 707295.0940620541;
    double MSlMgqtfqkQHEU = -62042.97336433352;
    bool MBZghERPxNy = false;

    for (int bpQiNKoKl = 1132374542; bpQiNKoKl > 0; bpQiNKoKl--) {
        TETHKCo = ! TETHKCo;
        iAjjMJnbPsVMi = TETHKCo;
        iAjjMJnbPsVMi = ! TETHKCo;
    }

    for (int lvTcSkJ = 1512909985; lvTcSkJ > 0; lvTcSkJ--) {
        TETHKCo = iAjjMJnbPsVMi;
    }

    return MBZghERPxNy;
}

void XgckeT::HqOzP(double QnmLqvCnkQrSzXD)
{
    int kWSSfxepgAWCyt = -866035945;
    bool ynovkwMYciZ = false;
    string UDzlRHI = string("ZfWHtRCilPVgZRCFkIYDMOeEtPZMvbhFvxhscZrxtbxfCdgRNqdqkGHIcCeIrFtPqFOsyJoIjhiEzpZzBMCGpRGcEcZqrrwRkAdYdJTOYQNAjDoCHfBTaiEXNNEEyiqTjTdtTxIVyUBWvibRLpMtYwWKWRMjaLcLDTOPFrSTIebNDmonCzJjvDL");
    double lWGnLDX = 343480.5986088737;
    double PpXxPVHoqxniRqQ = -155784.30878907285;
    int JTAsvlLtwsnRKecL = 175848662;
    int FldGfxkbURsoD = 790542579;
    string PODsmkwdAcSatPz = string("xsQvGXj");

    if (FldGfxkbURsoD > 175848662) {
        for (int WPGCUvCqZoc = 1176368157; WPGCUvCqZoc > 0; WPGCUvCqZoc--) {
            lWGnLDX += lWGnLDX;
        }
    }

    for (int kgpvrsg = 1354567446; kgpvrsg > 0; kgpvrsg--) {
        JTAsvlLtwsnRKecL = FldGfxkbURsoD;
    }

    if (JTAsvlLtwsnRKecL <= -866035945) {
        for (int TaQqKawQk = 1039883025; TaQqKawQk > 0; TaQqKawQk--) {
            kWSSfxepgAWCyt *= JTAsvlLtwsnRKecL;
            PODsmkwdAcSatPz += UDzlRHI;
        }
    }

    for (int AgqCQzmiW = 1656729742; AgqCQzmiW > 0; AgqCQzmiW--) {
        lWGnLDX -= PpXxPVHoqxniRqQ;
        UDzlRHI += UDzlRHI;
    }

    if (ynovkwMYciZ != false) {
        for (int dqWXdOMRQRW = 1430938317; dqWXdOMRQRW > 0; dqWXdOMRQRW--) {
            kWSSfxepgAWCyt /= FldGfxkbURsoD;
        }
    }

    if (QnmLqvCnkQrSzXD != -155784.30878907285) {
        for (int IYbrvcWtLv = 1832855169; IYbrvcWtLv > 0; IYbrvcWtLv--) {
            kWSSfxepgAWCyt = kWSSfxepgAWCyt;
        }
    }
}

void XgckeT::PduHJkRRQB(bool vrFBWjiWCtds, string FZYtvrP, int dTLGDuEPdBX, int yzSJozx, bool xJDaoUeXMNUhePe)
{
    int mwseTtgcvlb = 1622071104;
    string kUbVjkQYlPY = string("lsjulkHAMUbiaNTTYqOxZcCWgSizZbhQMffLbECaTykWVvsEvFDUGfJdzJYPXoNHkIMQrLnwzCwisnadxbJtIyVxbBTKKjghmhmrpiQkylMs");
    double hmObRAuGMjwrUFw = 3329.1911386804377;
    double ZQCFa = 408051.61872216425;
    bool TEwINHjSCErRWAY = false;
    string ZZtwvUZvPxIYDe = string("vfGnNLDYgqqMKsdzEYykaiaashekgIdMMaiZLHUGCikGAivHKHGNKLANdyHMvwvYJCkjlSRBVGtMmsKxqSfvzuGeHwJIHFmNCMHeXpcBrTkmcYCKnrjexFUoXbeuqAZND");
    int OytxKdOy = -452003236;
    double fVjmmzpdkJSzG = 971361.7377529255;

    for (int rHEDeEtbFNYSqcq = 612763225; rHEDeEtbFNYSqcq > 0; rHEDeEtbFNYSqcq--) {
        continue;
    }

    for (int AKJAmpTl = 1617500357; AKJAmpTl > 0; AKJAmpTl--) {
        continue;
    }

    for (int LINVa = 511812120; LINVa > 0; LINVa--) {
        kUbVjkQYlPY += ZZtwvUZvPxIYDe;
    }

    for (int UZjwnzalpDtLFr = 409984375; UZjwnzalpDtLFr > 0; UZjwnzalpDtLFr--) {
        fVjmmzpdkJSzG /= ZQCFa;
    }
}

double XgckeT::GapdbW(string nsMPU, string VtsxMmqbLOEd, string hhtodakMau, bool jMFzlPflzs)
{
    int plPlvRAiF = 1039170416;
    double KUvopsYAIIsX = 496433.7670429479;
    string qROxXGzhtGUUZbhR = string("TMyMxMqwHywPKgEATgQdVwpBsuIcgtIkxjfkgVlIZGVdfvW");
    bool KwjfoyLOepohIYo = false;
    string btNcFLCc = string("rckLUFfmqQDRLEcWspjGUefibwVeaKVHLPzoomgeUhPxZbCJKRrOEjcZzCgnvBVbwmnujMdOlYfXyKLGebBtcXkEtLgctODYueJnCqiQSPnZtRSJDapsWSJrEljRswVKqxdurlzbNHnTkMrwTtCvDioGjafvIAzsaVDIiVQIzVcbdxdqKMsvaRYQkClJnROaMqnrWLCwYKFMuXNaIwFDeUSQJQeYsXvCfPRHvSaiLLyfOsa");
    double gytDjpdlrDX = -1037054.2715705066;
    string mVbXyBGluGNnRq = string("mxnOCiBqaPQKDFNWgExLCmkpVlRarhFynkmAvLrOddaRJPstDgytJRdszgBMNPrPoQcySdWhFHWsrmqGOCQVkHCOvjlmdIQBgUEwiznRKUMrUGZRIOUjVRakhaslcnIEXdplJvdFvYFbjTPdIzTOtbUBdYVtoDlMTKspmQrOUhJmrnFcWTugpAXp");
    bool PVcrG = true;

    if (qROxXGzhtGUUZbhR <= string("zikWVkyLRuNfimLGYnvIkBTkEaUNqpuSKQelFmhgpcXDNIfwHpkavrNWeXwgEQAUFxPLEqIQiGUdYPWMKTCaNUxsyiftNfpkEPUxJOmyLXnlkxCbKedUoUDlaTDPDQuEWZIypfOaExfcGNGplvpGpDMOPUmkMFgamWRyAgpAIwuQoyajsDmLwMNbMNxxHnrVbEPCUAqBMOOtvLLNZRpfi")) {
        for (int qifLWP = 1642120316; qifLWP > 0; qifLWP--) {
            mVbXyBGluGNnRq = mVbXyBGluGNnRq;
            qROxXGzhtGUUZbhR += mVbXyBGluGNnRq;
        }
    }

    if (PVcrG == false) {
        for (int CfMJUgo = 1060035782; CfMJUgo > 0; CfMJUgo--) {
            PVcrG = KwjfoyLOepohIYo;
            hhtodakMau += nsMPU;
        }
    }

    for (int VOfkxAReFMD = 448901588; VOfkxAReFMD > 0; VOfkxAReFMD--) {
        continue;
    }

    return gytDjpdlrDX;
}

void XgckeT::SbHeyPeoQES()
{
    string PFIiriBWoLvOZP = string("ULyncmvxdDxRhuXivetGYKiMSlGLJuPgnLczGhtLjjaHtuJyqudCxBORXQwTWOEjDyVkHNQzTwZnjDkszMhcjQFqZcCXlklJFqEiZrJVtfbgZpQnPnwvRVnXYsGKZTOGwDZnfbVJzdPHBxTNFDZeGX");
    int mFMveavIqlQtYL = 1011807776;
    string wqdlAz = string("uIhYUyxWQjGppddwSTQomJfEVxdrj");
    string EFlmiwCSfc = string("gNUjivLmiTLUqkanwYBITIYJjfeGMxnFeqJReaOYTxGiISNMHaaaARqeJXpsWZPRHIxcAznAikqZDcqQGXPkuwEdinvxyVQuPioJCqbDahwMdsxQGjLLpQzlvfkyQBRdHKNRmAtGnOHTT");

    if (PFIiriBWoLvOZP >= string("gNUjivLmiTLUqkanwYBITIYJjfeGMxnFeqJReaOYTxGiISNMHaaaARqeJXpsWZPRHIxcAznAikqZDcqQGXPkuwEdinvxyVQuPioJCqbDahwMdsxQGjLLpQzlvfkyQBRdHKNRmAtGnOHTT")) {
        for (int cpAjQIupnKaK = 694475688; cpAjQIupnKaK > 0; cpAjQIupnKaK--) {
            wqdlAz += PFIiriBWoLvOZP;
            EFlmiwCSfc += wqdlAz;
        }
    }

    if (wqdlAz >= string("ULyncmvxdDxRhuXivetGYKiMSlGLJuPgnLczGhtLjjaHtuJyqudCxBORXQwTWOEjDyVkHNQzTwZnjDkszMhcjQFqZcCXlklJFqEiZrJVtfbgZpQnPnwvRVnXYsGKZTOGwDZnfbVJzdPHBxTNFDZeGX")) {
        for (int EsNhzEfXc = 2033325997; EsNhzEfXc > 0; EsNhzEfXc--) {
            EFlmiwCSfc = EFlmiwCSfc;
            mFMveavIqlQtYL /= mFMveavIqlQtYL;
            mFMveavIqlQtYL -= mFMveavIqlQtYL;
            mFMveavIqlQtYL *= mFMveavIqlQtYL;
        }
    }

    if (EFlmiwCSfc > string("uIhYUyxWQjGppddwSTQomJfEVxdrj")) {
        for (int mtZzbwdpxLEohSc = 12564195; mtZzbwdpxLEohSc > 0; mtZzbwdpxLEohSc--) {
            wqdlAz = EFlmiwCSfc;
            PFIiriBWoLvOZP = EFlmiwCSfc;
            PFIiriBWoLvOZP += PFIiriBWoLvOZP;
            wqdlAz = wqdlAz;
            EFlmiwCSfc += PFIiriBWoLvOZP;
        }
    }
}

double XgckeT::SnYGYdoVDFI(bool hBQsKORAT, int FdimHHfNjVmPH, double QqtOKCmsoMG, bool UuiRYAEIKOU)
{
    int AaHvSTYzoalblJ = 698210282;
    double RBuuKuNim = 857948.9159137941;
    double iVJWQYQrede = -1022861.4845492234;
    string zbMQBkQtEEaQzTp = string("uPUDkYJjrifYzATiMratbyjmCPDIAxGJbFhUTydpmjGCHwoFyTdRTzUnIlkKvCTrNZWHkRUvceNAsuSZzOdPvllSfYYTAUecDDcwAVCaqLGqKObnfcnTPbvBbMvisvSftGmnbUSRmeclflkqSisOoXdzOSGGhyHLEFXKthgAaXdknAGHDEHXMyZ");
    int lqZGxzqblZzkLls = 1349560024;
    bool HUUrVNoUewxKQ = true;
    bool ZHOodHUDsYTWrb = false;

    return iVJWQYQrede;
}

int XgckeT::ZgadOBqIkBulrt()
{
    double tutKgCmD = 265227.7905897582;
    int kGForWkirF = -1901699384;
    double xZGcrfpQfSPd = -646631.0990151883;
    int sgwgApIlLvKNt = 1783688219;
    string FCLWvWWCnfHz = string("ssumEYXBdkmXcRmbISJ");
    double EvHfDB = 31125.61274365244;

    for (int UMLbFOdWbzbJdPwB = 1805243214; UMLbFOdWbzbJdPwB > 0; UMLbFOdWbzbJdPwB--) {
        EvHfDB -= xZGcrfpQfSPd;
        tutKgCmD += EvHfDB;
        EvHfDB /= tutKgCmD;
        xZGcrfpQfSPd = tutKgCmD;
        EvHfDB = tutKgCmD;
    }

    for (int VqYhX = 57495556; VqYhX > 0; VqYhX--) {
        FCLWvWWCnfHz = FCLWvWWCnfHz;
    }

    return sgwgApIlLvKNt;
}

bool XgckeT::IztPHJs(double IJZlHdFnILYciTp, int TTkLA)
{
    double PiNFCznCcelYz = -989276.0557386989;
    double qypndlznZPh = 568109.9782977364;
    bool urMjxQEBlPljBt = true;
    string CKysx = string("sDaoysygpJztNkCUdxpZEMQQWeJUiQTLhgLqlgTPpTGzSDHzCkBNuxsFtNdNNUrDYGfkZqwFfHwzHzJvsSnJijYOuwhIXiiWUZAammNlmJVsRXkXcHbEkSewefCPRkdfcSleWTnxjkLvRpTeLbKugkwLIrwGlcKnwXsDnJwnBoQKaToHGzkrZYvUYiVMprHDSNEmUJywjhMuTaeYgnfzISJgYpAa");
    bool qTgrNnBZZExGmUYJ = true;

    for (int MQhPOxqJjaCPnNp = 393065377; MQhPOxqJjaCPnNp > 0; MQhPOxqJjaCPnNp--) {
        PiNFCznCcelYz += qypndlznZPh;
        qypndlznZPh *= PiNFCznCcelYz;
    }

    for (int dSCWHMpVl = 1028380892; dSCWHMpVl > 0; dSCWHMpVl--) {
        qypndlznZPh *= qypndlznZPh;
    }

    for (int ACZoxDvg = 1365634969; ACZoxDvg > 0; ACZoxDvg--) {
        PiNFCznCcelYz += qypndlznZPh;
        urMjxQEBlPljBt = ! urMjxQEBlPljBt;
    }

    return qTgrNnBZZExGmUYJ;
}

XgckeT::XgckeT()
{
    this->dboqSi(-695526.0441302618, true, true, string("vjXgovtGSQjYzEheMZtADpRqQqnkdnSypHvMpWseuPfYZzjnRFHbforOIduXOOQoqIVDwTUhJNqSmgHwNZmzhedqCOOktdrMvLlJBWevIzxAhmWQbTBLveTBvxCOTLHutLAmTSurajCrxPfFXWiLb"));
    this->CclLSurFOzDLKv(-1729960707, 306172.7041300086, -6938054);
    this->GzitBgfIuiYW(661907737, false, -1094282643);
    this->UHPQrIzTEpGth(-303431068, -1897383080, true);
    this->BukhSzNiS(36686.46160641569, string("iLYBPYjhzBWCKkXtmwDgprXoxNAGZDfzmLsAPEieTWoUyrsyLKAlFdVZjMoYFTiGENQmctVgbEXZHuLkREAwmsKdIdhcTvwAhfTRPvYaNAMVijlosTqjLyFfkaQCrQjrmdDylelOoeNfgFbeWBYYiDaPSXbYl"), true);
    this->HqOzP(1030409.4500364357);
    this->PduHJkRRQB(false, string("SFODrUlFGImUBDchESKPesYohxqDGjFZifXjuwRIvZmCymLHzYjazgPbjmikiaVvamAlCAxWRvVgvYZMBHsSCAnjaRutIqMjSULAbVOEppcAQdxVoskOYAIaJEtacUYygdCVMTZuJlrViPMMFyRCGdyesXizcNAGuWGVdLeyNbjgGOIuprRaSuIWZzyCVbwQezEsleqYMakCzxScZHSPGAzrnKOirAAdMYHBroroFAxjthfFirtWTQAOJ"), -1156095262, -1697579514, false);
    this->GapdbW(string("zikWVkyLRuNfimLGYnvIkBTkEaUNqpuSKQelFmhgpcXDNIfwHpkavrNWeXwgEQAUFxPLEqIQiGUdYPWMKTCaNUxsyiftNfpkEPUxJOmyLXnlkxCbKedUoUDlaTDPDQuEWZIypfOaExfcGNGplvpGpDMOPUmkMFgamWRyAgpAIwuQoyajsDmLwMNbMNxxHnrVbEPCUAqBMOOtvLLNZRpfi"), string("iFgexLkiBajumYkpLOCwRBEcPuDgTQDBKzoBdlIonkMSKPJFuyfNvbmTOxperozqPOnJUmsNppEqMYrKHoPQToaAvctrGtaBMegIbPCcKpQLpelFyRzrUukrZOyKwZYohSodQJVyA"), string("LcPXVtvSkZefrDrceCshmuyLFCtGNBQDnjjcvqHQadsrxEmsuqMQXGoMKxgvLoejvmDCHhfKsvQLyutWGxPKnhmmKtgeNOhknqGIofxkGGVfSTcAvhzkff"), false);
    this->SbHeyPeoQES();
    this->SnYGYdoVDFI(true, 164711737, -143360.65565756964, true);
    this->ZgadOBqIkBulrt();
    this->IztPHJs(-1003850.5558608366, -1787124628);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jdZJur
{
public:
    string ZEvARe;
    int DOAgZJURquECR;

    jdZJur();
    double duMdbXBBcM(double DZRTgzDPJqYAEf, int AtPHx, string uUQTP, bool mWNaiBslhFB);
    bool zOMcICvhsirKbKZ(int uYzeiQAQsVaWzbwx);
    string EpZRvTvTzctP(bool nRzLkGeWPK, int HjgBsW, int lCHPpeUrtjSwfX, string SvcjjNEuNcexpQ, string EZitCUIvjA);
    string ufnHBUVih(double mcRXRWVHkm);
protected:
    int GXEkaQGgzQvW;

private:
    string xzmYMwInM;

    double tXWhVQdslfSsYlar(double HqMgsM, double eHTtAtVqLcl);
    bool gaOUvz(double SWdQIf, int zDYRKRXOkgOm);
};

double jdZJur::duMdbXBBcM(double DZRTgzDPJqYAEf, int AtPHx, string uUQTP, bool mWNaiBslhFB)
{
    bool gdDZNFF = false;
    int TbJXhNRyGg = -1136745156;
    int LMmylJtPVhjaDhsl = -1425058074;
    double qofQStZQHoRxzqqt = 352851.4358666797;
    bool cMRnOFHJHYGP = false;
    int PnyzwmGyaaxSGdB = 1140214342;
    double JAemO = -121021.25112473963;
    double kLFrzRiiRUnzGEMn = -790069.7283095274;

    if (kLFrzRiiRUnzGEMn == -744478.0680490236) {
        for (int IhPtFa = 2073383780; IhPtFa > 0; IhPtFa--) {
            JAemO += DZRTgzDPJqYAEf;
        }
    }

    for (int OGhKolg = 491327835; OGhKolg > 0; OGhKolg--) {
        continue;
    }

    for (int thUOuZXLaOAWbZ = 1919328478; thUOuZXLaOAWbZ > 0; thUOuZXLaOAWbZ--) {
        JAemO /= JAemO;
        qofQStZQHoRxzqqt += qofQStZQHoRxzqqt;
        kLFrzRiiRUnzGEMn -= DZRTgzDPJqYAEf;
        kLFrzRiiRUnzGEMn += qofQStZQHoRxzqqt;
    }

    for (int dKYgwlv = 2098120226; dKYgwlv > 0; dKYgwlv--) {
        LMmylJtPVhjaDhsl += LMmylJtPVhjaDhsl;
        LMmylJtPVhjaDhsl = LMmylJtPVhjaDhsl;
    }

    return kLFrzRiiRUnzGEMn;
}

bool jdZJur::zOMcICvhsirKbKZ(int uYzeiQAQsVaWzbwx)
{
    double HcNFgDy = -164694.00086486473;

    for (int ULcrNEFsHUYlxtP = 1504289906; ULcrNEFsHUYlxtP > 0; ULcrNEFsHUYlxtP--) {
        HcNFgDy += HcNFgDy;
        HcNFgDy /= HcNFgDy;
        HcNFgDy *= HcNFgDy;
        HcNFgDy *= HcNFgDy;
    }

    for (int AEYJeifUxVYSUQck = 789370236; AEYJeifUxVYSUQck > 0; AEYJeifUxVYSUQck--) {
        HcNFgDy *= HcNFgDy;
        HcNFgDy += HcNFgDy;
    }

    return true;
}

string jdZJur::EpZRvTvTzctP(bool nRzLkGeWPK, int HjgBsW, int lCHPpeUrtjSwfX, string SvcjjNEuNcexpQ, string EZitCUIvjA)
{
    bool tEBGSsPMlmG = true;
    string wWGzPXXcQV = string("UHneFsVugfhgEIXosCUbgBfSzUQkwQzDrvmtVSGTtpeTqsYVrBPzysWwmIdekvqhcnvABOkinSBwcscDafppiDNyJoMGIuRdZazMbgPYFMYtVBEOPTBThZJmuIuBYRpaMCalgIWHfrMIofVwQUNQqiGDrpGUgeEbjrPZUDYwqdLAiBkSKANdkAR");
    bool FiJxzLMyxiisn = true;
    bool jfmemxghXBQjofI = false;
    string yNjLpELhSu = string("wTVyDbDsHaiZRYBUVtQfCZMHwtInADuFfhrYtakgVwDtAQikuEeCXSJxfJRnoOPfWyGhqbUUIRWVHvPQOXXzPVSfxqUElzsWljWUKCMIMkZRlOXSHpokyBBCcNJQOUKdQUTHNjQObcLKyUpfPkpmtXRcLDNncnH");
    double DVibEqPNNMsZGk = 954370.1195987633;
    double hGUSUDnNUZrs = -863312.8124209901;

    return yNjLpELhSu;
}

string jdZJur::ufnHBUVih(double mcRXRWVHkm)
{
    bool kcrsvabEKJdkI = true;
    int AOIbSUZaYFctk = 87966735;
    bool BUJCeqQxdBSVfo = true;
    string mjwUEfDEauA = string("tzZhYWtmzwgzEWnkzICmeHpPvKJKZDGXaqXBokbdQDKUUqJFEHPifRAoqVssqELkaSmIaqjdCkvlUcVJgvGqLfedwSOAIaUS");
    bool AHkFzbtAbzGj = false;

    for (int NtqDdK = 1061853569; NtqDdK > 0; NtqDdK--) {
        continue;
    }

    if (kcrsvabEKJdkI != true) {
        for (int xHEnEtbjT = 1145287166; xHEnEtbjT > 0; xHEnEtbjT--) {
            BUJCeqQxdBSVfo = ! BUJCeqQxdBSVfo;
            kcrsvabEKJdkI = kcrsvabEKJdkI;
        }
    }

    return mjwUEfDEauA;
}

double jdZJur::tXWhVQdslfSsYlar(double HqMgsM, double eHTtAtVqLcl)
{
    bool bYUAYvEkxcIpF = true;
    int CyXaeCiSXdW = -912269009;
    string KguojXdKKpd = string("IgqIfrGFzEqtrzwDLXOwxBYiKrQsdvbAhVj");
    double CqrDQ = -1026743.5726126914;
    string wkKOVnqtPqhzWEEC = string("mSFInfDSRVHHDZxmfRISZrLWkgFSHOiJsHkh");
    int jbBgKNCzZ = -414370879;
    string SprIJqheYe = string("eGqKrVLMSAmp");
    bool wizOz = true;
    int uRvAidXqNnh = -617562726;

    for (int xrvKZ = 1395517523; xrvKZ > 0; xrvKZ--) {
        eHTtAtVqLcl -= HqMgsM;
        jbBgKNCzZ /= jbBgKNCzZ;
        jbBgKNCzZ = uRvAidXqNnh;
    }

    for (int eZrBRMxwlaVElZo = 198462818; eZrBRMxwlaVElZo > 0; eZrBRMxwlaVElZo--) {
        CyXaeCiSXdW /= uRvAidXqNnh;
    }

    return CqrDQ;
}

bool jdZJur::gaOUvz(double SWdQIf, int zDYRKRXOkgOm)
{
    string uEfnUemY = string("SfrwamoOZRrQDecftOROotmgkaRwEutRNrvnQpWfcOarLgBXJbpYCHKbBCCgjxpwNQCQQAHQbvzauUkFjWAQEWrICyhGiIljWdRJYRGUUhUvXSJykSCIEfmxwbkPdZLvvniiydqKCdJXfwDuYvTUNdpCtLrSUqTEzAdRYpmPEkVsuIMjpbzRezttobMEjNnTd");
    string vZqIIgqPKujNX = string("oZKbgFKprTvtrGHJSqszXvYgJDBjeLwGUtofPggWYmYOefbOnJyjeSDQrBCxOJtTmMeBmKcNvIPfwwwyzEbgvujzZEUSAcI");
    int zZJOi = -1331036057;
    int mkMAZQLkqIY = -610453658;
    double EDwQGu = 623708.1671415952;

    if (vZqIIgqPKujNX == string("SfrwamoOZRrQDecftOROotmgkaRwEutRNrvnQpWfcOarLgBXJbpYCHKbBCCgjxpwNQCQQAHQbvzauUkFjWAQEWrICyhGiIljWdRJYRGUUhUvXSJykSCIEfmxwbkPdZLvvniiydqKCdJXfwDuYvTUNdpCtLrSUqTEzAdRYpmPEkVsuIMjpbzRezttobMEjNnTd")) {
        for (int rXCrMZzfvAHiYCEu = 1906863966; rXCrMZzfvAHiYCEu > 0; rXCrMZzfvAHiYCEu--) {
            vZqIIgqPKujNX = uEfnUemY;
            zZJOi = zDYRKRXOkgOm;
            SWdQIf /= EDwQGu;
        }
    }

    for (int nFuPZqopHRR = 969813142; nFuPZqopHRR > 0; nFuPZqopHRR--) {
        zDYRKRXOkgOm -= mkMAZQLkqIY;
        vZqIIgqPKujNX = uEfnUemY;
    }

    if (zZJOi >= -1331036057) {
        for (int nPJYwVDdhQppu = 2125637745; nPJYwVDdhQppu > 0; nPJYwVDdhQppu--) {
            zDYRKRXOkgOm /= zZJOi;
            zZJOi += zZJOi;
        }
    }

    for (int nwaoFCn = 2043253316; nwaoFCn > 0; nwaoFCn--) {
        EDwQGu /= SWdQIf;
    }

    return true;
}

jdZJur::jdZJur()
{
    this->duMdbXBBcM(-744478.0680490236, 517720306, string("oZdNtBldbtVdrqgfZjqCApMadVXGcrtAKKxBJGlhggRyPpKezGJh"), false);
    this->zOMcICvhsirKbKZ(1821178462);
    this->EpZRvTvTzctP(true, -1396223907, 1747209658, string("xwuIUdsoUCJYNUnOQmCSKjCkymbiQStaSfpOaTzgsBfEREMKMigGBmFalEZzcuTHIKZSWIFQWABFeftanfgKPLtdtzNrbtpxvYAdRuFUrZxtUnEwUaYVsJLvRDYUOSZbgataqolQXqIWtTIPNucaCmugudEgmJIbDugLeATAQcrNqP"), string("WiUnrtRIQhikzdQJYVJnVNqkPPqBdKoOhevYCYDCXIPVuEUFDzULhjOtuWFeLDjxkzsBNoszUWhjkAjqUxankvhyYRabMOSYrlGGspGvfFfrgdRQyuSdykBvNNWGykCFEkapUjJJuyMAzPmzyCjfjjVVuatFtRdAqYnngcvCtOUAXOEDptPcktdzxBWHmJaXqcMRBciPskEysWVmBczAPWXSHasysNoyyMBNS"));
    this->ufnHBUVih(-78470.97385553413);
    this->tXWhVQdslfSsYlar(-782387.0208276534, 284056.6372051894);
    this->gaOUvz(-1046501.2762374725, 560110172);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zNkOfOlOC
{
public:
    double wXuxtDnvB;
    double lsoQbAiBkFY;
    bool cxKcjDBt;

    zNkOfOlOC();
    double TKvxUPsADSsnS(int mrGBsMypCylX, string rrMTThqnz, double rbTIgmsFNcyVzK);
    bool GxGcxKN(double hZiifnOFyLGfbw, int ynsdVJ, bool UeMkRzaPtX);
    string XCuCfGhUiNMC();
    bool lWHaRvoWLiAQLl(bool ePNmsgaCikpDN, string oCjgwtuKFHddBot);
    string FRtGyNuzaUGRlB();
protected:
    bool EBRcPvClVZXpj;
    string gjvOyuMg;
    int gVdgIX;
    double lnCYMxrfAHaHAMn;
    string WkWBpKVl;
    bool rrELTQRlqQo;

    bool SNyLqEsH();
    int juVKahVHQusmliaC();
    bool dKcZXfFW(int GfOoPXqWySqq, bool ybmhHvLXWEulG, int dDUJgtlvAAWn);
    string pZpUvkouryBbm(string NCDuNcSIirHy, double sjDabfTbAHd, int VSbSAxKy, string oBtIs, string seLvN);
    int FHAMUjBNeE(double xTFxH);
    string RASabItW(string pUhCjbdTCDipOQ, double KeWdkVcHAwgefE, int WUZoMGr, int fgRvuaw, string dzeQnvcVSpDq);
private:
    int ayosMDb;

    int ziMqiwbHWRevPrXd(double EDgVzgXc, double gIPZF, bool KSfzIeX, double XuDzMwND, string hcfJgbVEON);
};

double zNkOfOlOC::TKvxUPsADSsnS(int mrGBsMypCylX, string rrMTThqnz, double rbTIgmsFNcyVzK)
{
    int rciJoNFDdHZTnL = 729882516;
    int srjJEx = -1078263997;
    string KyVpYrbvpluB = string("BjDNIAMtRiUmTxpAWzIjrlVUEssZpYUHMWjfwoTnjkZyGgbJCdlqNDkefAKxl");
    int DhTHXgStQZqWqyu = -1311976077;
    double LjGMTblPO = -310854.7267363386;
    bool MvFQJ = true;
    string gnrOwEHCUKxJXc = string("sBOtCgvjAZExzcnpsZskExFYDoyWvdPblHeyArwjmEDqWKdGfbQDWKIYSNgqFUsdLkVpefGtJtpVyekoDAGzsIzYhpbTxGbCWFLpOdLRzmHJWfsUyhQFcMYJIiSqrJxlndmOipNAEgtRaVUCGeeknSlnPSVGReMUqdTndo");

    if (gnrOwEHCUKxJXc < string("BjDNIAMtRiUmTxpAWzIjrlVUEssZpYUHMWjfwoTnjkZyGgbJCdlqNDkefAKxl")) {
        for (int uhXgPZAJHhmAeMjB = 835062873; uhXgPZAJHhmAeMjB > 0; uhXgPZAJHhmAeMjB--) {
            rciJoNFDdHZTnL = mrGBsMypCylX;
        }
    }

    return LjGMTblPO;
}

bool zNkOfOlOC::GxGcxKN(double hZiifnOFyLGfbw, int ynsdVJ, bool UeMkRzaPtX)
{
    string HDjjzrkF = string("WAOEQmrzqcjdfZyIVVebDQQqDINvHNmezaBjWTjDtsCJAtIUmwtTyUIdq");
    double TqPyvQPpHt = -183410.45170394803;
    string YYzWcwAwWWzxvyrx = string("tkMbtLVlXmYliFChFQvSgK");
    bool DYKVgArorTEUSB = true;
    string tOZNxaq = string("SeXRrYcNRJCMWNAQlYCYyCjXcLMuNkBmGBKjJGVCWnFkMUuxyVpwyFTcLUYyogphmkwCaIslHMOlyvPPPBLprFxRMrDECrwCSRpdBwyDlhfbzncHRdHsyCiutlyDPYrSJRDnRiUhzuVkVjsLetiIjhDiHixiPRNMrPEojQGniJvRhNfzGO");
    int ZHvTWkjM = 496361123;
    bool WscnSpwhEALMkVw = true;
    double EOzSdbvF = 279142.89163599716;
    bool vakzMjaSnueAd = false;
    double OHrgqCL = 877925.8778649871;

    for (int kVgjuvfHBiN = 990876094; kVgjuvfHBiN > 0; kVgjuvfHBiN--) {
        ynsdVJ = ZHvTWkjM;
        WscnSpwhEALMkVw = DYKVgArorTEUSB;
    }

    for (int xwClokz = 1585000678; xwClokz > 0; xwClokz--) {
        tOZNxaq = YYzWcwAwWWzxvyrx;
    }

    return vakzMjaSnueAd;
}

string zNkOfOlOC::XCuCfGhUiNMC()
{
    bool rRCaPkjqDmhjVCK = false;
    string vZbUY = string("mprlQudvtqcSyLrkjDFZwiMPfHSCsUDrhNgxFcPBElNEDLbmRtNwwZIOxgKzIvsFmwwNIVtTspvMnCPxRfynoPbTHMMpJTICQksjtUsAaDsNhjfXXNMsfcrwFPaUeowdbzsbZHlYDbCLXglAiHYbcIkoXDhLWRPxhkvAntLEzyrodUVZUkPuLAyjUUkGXwncTnvFJWtwYDZxvOySV");
    string WmPzeyIW = string("ymwDyLoHZpKqYZiuiiXjnMKevjoWakydAUddwmjJAbROfvxyHPsSaLYdQyQGOeAsDSnriYibdguCMrQzruGvrdEKSIuOdGoJpzOXSmZVIGcwNbrULCxKKEgOqgpFywOXRRzqqKltkfoYfJlGclPrNaIFbD");
    string NgNxI = string("DWbz");
    int ZTKcIfjnoqUscAig = -382963130;
    int ZgktBs = 341178876;
    bool LmPwx = false;

    for (int nKBrpXjqXP = 222296830; nKBrpXjqXP > 0; nKBrpXjqXP--) {
        WmPzeyIW = NgNxI;
        WmPzeyIW += NgNxI;
        NgNxI += NgNxI;
        ZTKcIfjnoqUscAig += ZTKcIfjnoqUscAig;
        rRCaPkjqDmhjVCK = ! LmPwx;
    }

    if (WmPzeyIW >= string("mprlQudvtqcSyLrkjDFZwiMPfHSCsUDrhNgxFcPBElNEDLbmRtNwwZIOxgKzIvsFmwwNIVtTspvMnCPxRfynoPbTHMMpJTICQksjtUsAaDsNhjfXXNMsfcrwFPaUeowdbzsbZHlYDbCLXglAiHYbcIkoXDhLWRPxhkvAntLEzyrodUVZUkPuLAyjUUkGXwncTnvFJWtwYDZxvOySV")) {
        for (int xOopyF = 1299436531; xOopyF > 0; xOopyF--) {
            ZgktBs *= ZTKcIfjnoqUscAig;
            LmPwx = ! LmPwx;
            rRCaPkjqDmhjVCK = rRCaPkjqDmhjVCK;
        }
    }

    for (int zcNRczQWgkhxWGJA = 114646312; zcNRczQWgkhxWGJA > 0; zcNRczQWgkhxWGJA--) {
        LmPwx = ! LmPwx;
        WmPzeyIW += vZbUY;
    }

    for (int DRNuLh = 460874450; DRNuLh > 0; DRNuLh--) {
        WmPzeyIW += NgNxI;
    }

    return NgNxI;
}

bool zNkOfOlOC::lWHaRvoWLiAQLl(bool ePNmsgaCikpDN, string oCjgwtuKFHddBot)
{
    double RdIAAaqeLylws = 300269.18831395835;
    double zRbdp = -634210.7531328518;
    bool NkbObKTsV = false;

    if (RdIAAaqeLylws != -634210.7531328518) {
        for (int UUmXOXXfME = 2083231206; UUmXOXXfME > 0; UUmXOXXfME--) {
            continue;
        }
    }

    for (int VbjrozBXKDRlRfsV = 2102461406; VbjrozBXKDRlRfsV > 0; VbjrozBXKDRlRfsV--) {
        RdIAAaqeLylws -= zRbdp;
        RdIAAaqeLylws = zRbdp;
        zRbdp -= RdIAAaqeLylws;
        ePNmsgaCikpDN = ePNmsgaCikpDN;
    }

    for (int skSlp = 854697376; skSlp > 0; skSlp--) {
        ePNmsgaCikpDN = ! ePNmsgaCikpDN;
    }

    return NkbObKTsV;
}

string zNkOfOlOC::FRtGyNuzaUGRlB()
{
    string imHXnSnKHNstgs = string("LmwkQVLXNExptfDqqStZowHpFtGIMBhmWHDHGXAZSxBiEOYjeXVJyhSQOoAgdLGibxksMalocbrpQASHuFBlfpoVDKpHFPfFpPvaIEhPqrMXzYGzTyI");
    double YUaHNHQ = 749543.3174601365;
    bool InebslIk = true;
    int FXgcJqGdaRzQD = -1361375378;
    double AQZTaJgjDWHF = 111938.23343128042;
    string PqQquoo = string("EWcoDGAWpgyozWnEPiSBClPJMCaAdkQgeeYhUevBrXtDeugbHsUqcHZEPFbWkIyHOFTAzVEnoKmaMbCFIVfSQDHgbIUKGHiAwLbAozkAqejvzrfCGUQwBQczWqDZTLpLTYOULQsOOfEAMjvxEZsfUGjtCKXHhBZMDFLUcfFArZFGNheWaZHIKceYiEMRqrxwJXFCpvpJQFNXBEwhlgeisQBrYORn");
    int CIBifPicMoEeBiyj = 894976786;
    double hSagYFxskrQC = -923612.39429177;
    bool iiMrTKziwcBhngg = true;

    for (int zWuPLPgJitH = 617680709; zWuPLPgJitH > 0; zWuPLPgJitH--) {
        hSagYFxskrQC = AQZTaJgjDWHF;
        imHXnSnKHNstgs += PqQquoo;
        FXgcJqGdaRzQD += CIBifPicMoEeBiyj;
    }

    for (int QtqgvbZqwfakY = 480036369; QtqgvbZqwfakY > 0; QtqgvbZqwfakY--) {
        hSagYFxskrQC /= hSagYFxskrQC;
        FXgcJqGdaRzQD -= FXgcJqGdaRzQD;
    }

    for (int YDpVJONUzeXgQUpl = 1200606195; YDpVJONUzeXgQUpl > 0; YDpVJONUzeXgQUpl--) {
        CIBifPicMoEeBiyj = FXgcJqGdaRzQD;
        AQZTaJgjDWHF /= hSagYFxskrQC;
        FXgcJqGdaRzQD -= CIBifPicMoEeBiyj;
        iiMrTKziwcBhngg = iiMrTKziwcBhngg;
    }

    return PqQquoo;
}

bool zNkOfOlOC::SNyLqEsH()
{
    string yCyZDmcEWCF = string("LgCLzvNGYoEHETbEDLFCIxuVFnAyrjYAOCftMCPCLMmzQYCWxPeTVybvCTiwwuMncxamYeXUQTMPnsjVhgXpiwJEwTJTEEVoKQqSXpnVjjgfoMiuP");
    double terPIBD = -485180.5001387982;
    double oulKmPzRO = -109886.5064998122;
    bool HpEFrBgJNNZwtDl = false;
    string DZAdEor = string("zsuADzrgcpAVaIGcwPiKZNnnuqqiEtwowKhhCfPeTyjhkNXEdBZMhyrNOrhlbeEPjeusaHsuJGLQvwKZNYNTIpXCjAHomMAFzkXPANvVeDyiCOJffiRDmxKTcGdFBRguHTOTuneeWtPywyZwdHKtXqaLzwitfFZaKXIiCSMLWnz");
    bool cpclxIalMs = true;
    bool mClZUJDkShzRG = false;
    int vGYMxPpGaKrxCB = 2119292475;
    double LaoHkOIcBcOiCV = -437171.95460652985;

    return mClZUJDkShzRG;
}

int zNkOfOlOC::juVKahVHQusmliaC()
{
    bool PvYqntAgaebjVsJS = false;
    int bsQeNhYxNmcLFP = -1362204841;
    bool UQwlpBhNeorjXO = true;
    bool RRPvDcaw = false;
    int SBWxmNUnQCIUCU = -1352953951;
    string fFUuQoTfrYKauEEU = string("WmSJVBvFIKrtwNWfzNVEZBnfXHHDogVfZfySlFsHyyHlQyHUZfbAXXcbFQxwFVuFKacjZwTPzQyVahpBCblwiGPDWOPuLtlQXrwTffkuDJJSPDJUODLBLWEuyLecfynkUaMWGqrSBESIFUcAxnMrHGsayjslvoQBfEIcyeDqsnCGojZlWAFTWPXzFU");
    double EQuiZWPfUz = -821573.814924446;
    double pWzSEIurOFazCwd = 362945.32596914563;
    double weWsscssPJGnyVl = -240291.85141485545;
    string DVfEMVTkFqZgNj = string("iggbgPoxcOFcfSaYsHdHRVARmuRfsUpKWHJcnGWXbBnobILTfizhZydaCngJRRgHioDKQqihiIfPYFISxXKbxibtsFwmuPZgeTBmCcKjiFtECKwTTrKpkljjztLLIKqrpcVoSNSrHDxBuBGmIPodWohEnXrWVoZCWIrnm");

    if (pWzSEIurOFazCwd > -240291.85141485545) {
        for (int XFXgVrKQOmiqo = 994646996; XFXgVrKQOmiqo > 0; XFXgVrKQOmiqo--) {
            continue;
        }
    }

    return SBWxmNUnQCIUCU;
}

bool zNkOfOlOC::dKcZXfFW(int GfOoPXqWySqq, bool ybmhHvLXWEulG, int dDUJgtlvAAWn)
{
    string dKQWCocOPA = string("SeRucCFBTzoIUuMlldZOUXvlrMiiviPAPuLRKTFoSRNBlkpbseiBYMUyAKrLrdyVLCkkpdJFAqXapcNNsdxHgswoSbTFCnsxvHtWxqKJnCvOroHtyIlYieDuOEKwaVqbCpXyfLPWRYnsolfFELBdUaGNycCPwcujTNsDeLRsinbwYhWMMy");
    double ZodAmXybwlQ = -549298.3556337723;
    string tvNYGW = string("GBvUmmoWcusXSrJGRuEuxAfXoZMRdBnqwgvMzaWlQjtFcaHAOvmINnoTToSTPhGqyOCqDfAXMGMCZQWumCtsoUiZeMZgGvRNveCdLHPoCaITzSTqcZGxUMLUmBSlazcxPxLMju");
    bool wprdIQHtR = false;
    double VXAhDHQHEF = -568092.0620568199;
    bool foFPbaYgriVUa = false;

    for (int dPCqZGx = 663960509; dPCqZGx > 0; dPCqZGx--) {
        tvNYGW = tvNYGW;
    }

    for (int CBdvcjdUiwwV = 1049910320; CBdvcjdUiwwV > 0; CBdvcjdUiwwV--) {
        VXAhDHQHEF = ZodAmXybwlQ;
        wprdIQHtR = ybmhHvLXWEulG;
    }

    for (int Xeels = 734782556; Xeels > 0; Xeels--) {
        continue;
    }

    return foFPbaYgriVUa;
}

string zNkOfOlOC::pZpUvkouryBbm(string NCDuNcSIirHy, double sjDabfTbAHd, int VSbSAxKy, string oBtIs, string seLvN)
{
    double riTqASsDFoJ = -857573.3952363651;
    double yisIUu = 857528.489099746;
    string MAHjigPKisYnEe = string("ruCfhWJBZkHFaFpRhvnOCUjmdgEcDRQVOCrqSqfrAtgywlJbSaqGkSFMJifMqDRzyEQCUAkkrLGxIXWnORqawApKXdTOMTpBEfCVdYquqocwonWSPTCpIaudevcNOSOyhixBWghCnGkJdEBIkOjPpwpkgOXUwahFPrXMcHqJJBdPcdckKSZMjVCZULhMheukJ");
    int IxoHMhwMpDirSRGu = -456083454;
    int ITVXnt = -1448443960;
    int gUNIFPki = 504933166;
    bool iqgGd = false;
    bool NBizYjFs = true;
    bool KsiCgYYxYupBv = true;

    return MAHjigPKisYnEe;
}

int zNkOfOlOC::FHAMUjBNeE(double xTFxH)
{
    bool kdaPoQKEgipCCxbF = false;
    double ReVQOOkZbYwCa = -590250.4794456143;
    bool oRszeTJE = false;
    int XnPIYamYDu = 1695515793;
    double yIORok = -774055.6212604388;
    string GSoaNvtGD = string("HfkwPehaERmjtrHqkKUsTBonzIvWbgOVbMCbbVuPUlVJvhTMpMsaZbpTpwDCoDddMEYUTpmztdNEwWHmThSTvMQVYojGqSmqjXVnqyeJQUeDqlOOFwPzdoRSWJEjgpFyCpzCDksTBdFwUoVBMtWarlEhJNWEvPDSpSJaDWKMNtKLxJpXCgVTOCTZwYqNxyjeFKJotoUczXYTLzyeJkUqvifbWqRSzlSsTbrLBBVVpBC");
    double irQLDjBcYzLG = -269173.2413779798;

    if (xTFxH >= -590250.4794456143) {
        for (int DjlcYXJJoN = 448329829; DjlcYXJJoN > 0; DjlcYXJJoN--) {
            irQLDjBcYzLG *= xTFxH;
            oRszeTJE = ! kdaPoQKEgipCCxbF;
            xTFxH /= irQLDjBcYzLG;
        }
    }

    for (int qnKtmHRzaTiZLBrT = 1003309396; qnKtmHRzaTiZLBrT > 0; qnKtmHRzaTiZLBrT--) {
        yIORok -= xTFxH;
        oRszeTJE = ! oRszeTJE;
    }

    if (ReVQOOkZbYwCa > -269173.2413779798) {
        for (int YMLBtoMsF = 60154838; YMLBtoMsF > 0; YMLBtoMsF--) {
            ReVQOOkZbYwCa *= xTFxH;
            yIORok += yIORok;
        }
    }

    for (int LKhvxXdAG = 1941109731; LKhvxXdAG > 0; LKhvxXdAG--) {
        irQLDjBcYzLG -= irQLDjBcYzLG;
    }

    if (xTFxH < -269173.2413779798) {
        for (int JDbVYBC = 31451805; JDbVYBC > 0; JDbVYBC--) {
            continue;
        }
    }

    return XnPIYamYDu;
}

string zNkOfOlOC::RASabItW(string pUhCjbdTCDipOQ, double KeWdkVcHAwgefE, int WUZoMGr, int fgRvuaw, string dzeQnvcVSpDq)
{
    bool urZIsqgkXki = false;
    int tEexcvCrEaxR = 845625865;
    bool DTOEedUaZxgtRIDQ = false;

    return dzeQnvcVSpDq;
}

int zNkOfOlOC::ziMqiwbHWRevPrXd(double EDgVzgXc, double gIPZF, bool KSfzIeX, double XuDzMwND, string hcfJgbVEON)
{
    int urDXnHViNYE = -1850469156;
    string gQZPSypvN = string("JJDUqXWSQFpKwnCoQwChWpsiiDwZahuOKtVhpzEIPqRYqDEUsFSVIHIMchNMrgQpmfLRGnNh");
    string VlaSnP = string("zEyswZjeUqXegasDwILzyAMBtWLuFAIMZGXMiwFUhCtpodLZVrXEgEFbnkxJlgkJRZODkANKUEddxLUWlMwmzyQeMGZDSlqhzpRxsZinZhAtgbdBOBlypgCtXtZuTOaxvCPoxeunPtmxCwriFiqiGOwnGNkyqAzLbEnFUEwcuNkbofBZHiwkedMHQTRHjQvaCcssTTnuCBRTlogucXzPZziwPxWjkXmCnqHHINtmXZdrr");
    bool yzLzWMJ = false;
    bool PleWsbyVmV = true;
    double htAHqLkL = -272267.4423001246;
    bool xxQciDbamgeo = true;
    bool DrhlY = true;
    int RcNXYAFQdMpC = 700820837;
    string QZqlyVrBMXlFt = string("IydNmoqLOpZuhalRbhHiaeZpRRzqdXdxwXFFdfbWebMbDfeJpkjYqqKMfPaqZmMwPcGGFzANFlmyxrDDevYfkJbJLkogNpXerkZroNZSkFmwYAxUSmujWqXDGfYxvDPiMzDttWFeWhXssmKsmdtwZmm");

    if (hcfJgbVEON != string("IydNmoqLOpZuhalRbhHiaeZpRRzqdXdxwXFFdfbWebMbDfeJpkjYqqKMfPaqZmMwPcGGFzANFlmyxrDDevYfkJbJLkogNpXerkZroNZSkFmwYAxUSmujWqXDGfYxvDPiMzDttWFeWhXssmKsmdtwZmm")) {
        for (int sdIlzMpLqmE = 1308259880; sdIlzMpLqmE > 0; sdIlzMpLqmE--) {
            gIPZF *= gIPZF;
            KSfzIeX = xxQciDbamgeo;
            gQZPSypvN += hcfJgbVEON;
        }
    }

    for (int eDxJfrJRdRa = 513109625; eDxJfrJRdRa > 0; eDxJfrJRdRa--) {
        KSfzIeX = ! DrhlY;
    }

    for (int MEbJhwExyopAR = 1033286708; MEbJhwExyopAR > 0; MEbJhwExyopAR--) {
        continue;
    }

    if (htAHqLkL <= -272267.4423001246) {
        for (int OdZRWYoixxJEynr = 187439467; OdZRWYoixxJEynr > 0; OdZRWYoixxJEynr--) {
            XuDzMwND -= EDgVzgXc;
        }
    }

    for (int hJZtMZvEeOy = 1382767884; hJZtMZvEeOy > 0; hJZtMZvEeOy--) {
        htAHqLkL /= gIPZF;
    }

    for (int ntTAjEMoAOOsIJK = 1081766192; ntTAjEMoAOOsIJK > 0; ntTAjEMoAOOsIJK--) {
        XuDzMwND = EDgVzgXc;
        QZqlyVrBMXlFt += hcfJgbVEON;
        urDXnHViNYE /= RcNXYAFQdMpC;
    }

    for (int vvQcEUh = 1624194770; vvQcEUh > 0; vvQcEUh--) {
        continue;
    }

    return RcNXYAFQdMpC;
}

zNkOfOlOC::zNkOfOlOC()
{
    this->TKvxUPsADSsnS(-722490771, string("gNywjpANANNUfsuAwUTMYeSFtLoQAcHOFsxIyDLyqGkpuQPhrpRDeKvqhezagdnrJbeBFaJocrSzIoSruTQISDjAsPXdbIUVdtABSkcNGFhqisDoEJHOURhZNiyoH"), 94047.42143582967);
    this->GxGcxKN(568592.6680303701, -63963533, false);
    this->XCuCfGhUiNMC();
    this->lWHaRvoWLiAQLl(false, string("EIRgoPuyFZyYPIzmaXrYtQGPqfwfWwFaEpqAVBbUuASOkxoFMEAGBqDcCkFJmwEskojgasehFvReETYLnoPtaOGnakVFbrOThCuctuOSFWZtBxwSnGcVQgLSdWEOuAapYdklmQFfPLjIxODRVEpyUdaDxFCJRWPNJgdGSWxNpiYJE"));
    this->FRtGyNuzaUGRlB();
    this->SNyLqEsH();
    this->juVKahVHQusmliaC();
    this->dKcZXfFW(-1364371096, true, 1146526811);
    this->pZpUvkouryBbm(string("SSriTTGtiNpxDEcTUPNSZHoXXFJPikcTxahwzlsDZRfrChzzdfOvSyRjwMGyAJFQmHUVjwEftdpMjFQcMzNRbvOUROJVBtVRFESSDkkrziRVeAXvoHVXtLUEudCEiPjiqqxGNTzbsljRqBbZzJxpoelEFbxHrwCutrJwkGKoWybWkgDmYDGrAdPfgsnwVfVAaKEdwGhmnqLgtLabkoOiMUEErrAk"), -864708.6614922446, 1596307172, string("LeBBFeRJONVAnCaGHhMgcoYeoEmyGyuhjlTBQWAcQTmJxMcYjFVuJwPArOBmJNqeNhqcMXLugXjrxfwrKyjcsSAbeRLULDlOSEuvwiryRovQisCYwioNPWiRsooHwMTDrJfOftBfRDkMEGeNrdYEUCPRNphmXDoODKQgWcXzMCNNdmPKfJYwtCrZeptZbOvShRODGLpfVWVhyKIHpBWkKHqSdJMVPTIgLxwZroEYQvYrTNUkHBL"), string("qUjICOFpCOsFHfLkhDusQvPDTOXSkGNvcDlxxxlHTzRaQmXphPHjqTbiIXGPjRCCCI"));
    this->FHAMUjBNeE(-99218.44469200177);
    this->RASabItW(string("lDmjRwwVgbdcUMxpqzybUBzpjqzZrcoXMoiuzApVTnbCchEUXCQXABjdZqFSGgcvoKxELHqPPsfcxTXaSlVOhcuIiKYGtqrqRduCaZREFuWqdFOjFZnltOpZTojgfiJSDwaRRPaszGMLSjFPNqMzKBxKIJMYWmtWumgWwfWWLvjwKcfASyiXIhWufGVvUJlitbVtfjFrnLDgljVfIZKuLPjarAbrQdeATGJkNh"), -335510.3637328894, 475499554, -1444955261, string("jLWYscDdRbSysQIMnWTGCcbMhdEmPkVvQPYofcDuUxoFfwNlA"));
    this->ziMqiwbHWRevPrXd(-668002.7187233396, 149047.77111561058, false, -534857.1670141477, string("WwIatpbVIfaWsKRRsH"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pYgKUieNozSNX
{
public:
    int XwTtPQNlSphUdW;
    bool FrfaQlHoHiHMouN;

    pYgKUieNozSNX();
    string lUjclggzNw(double QmxmUPjWui, string vDSOcGGsh);
    int rUHoW(double aLZTSOEAxOnY);
    void TKnhAjiR(double veTJonOiOMqVBs);
    int WQhEDJjublRuTsFT(double mANTFnwc);
    bool PCTHAWBzQQHe();
    void vUCssGsRTimmgSY(int mvbeRxuWdMJKMMO);
    double sOATws(double pKftYOvBKnkxmPv);
    int ziXJZYaQfMhF(int SKHQuCfodVkarh, int KpyMgx);
protected:
    bool jmSEmCrfJLXYd;
    double iVEgzIBNgjNKSO;
    int GdJWkjeR;
    double DpQuhYwwSPEQNZ;

    double GQAbVrkRzlT();
    double USzsDMvUhMNMq(bool tpIxSDkfTQt, int TtSdUJdkI, string TGkDywXSOaHPvhVC, bool ufaGAuYckBoFk, int IhEib);
    double kgpMRouYUgTlkE(bool zcnIryJTNeMOaw, string gPKaaKQyLByiBcjs, double fSzBGARWTOnPwM, double keDjUdUhJBkHVGB, string bDMzOSQKNp);
private:
    bool ATvmEtsQPIKIA;
    int wSNoSbViXqBXMP;
    bool pSZRjYtpcjtFb;
    bool DIRGCJz;
    int qRYoHA;

    string GEXnwQZr(string ENnsINDOYaISrQb, int VIbQYVAhMwyDeH);
    bool UNPimSZ(bool YylbIhdHdVlQp);
    double nvwLZtWLVim(bool AefeeklsNcr, int WTNFFXJWxhb, int bhggROVfrvjybbI);
    bool fNxTakgsOyjvhH(double WVNepoioiblGMBL, double YwnBSVTyBfqfoLvW, double avfBcUxCB, bool YXQJjUktIMS, int hKOocWoRfwKmtUAo);
};

string pYgKUieNozSNX::lUjclggzNw(double QmxmUPjWui, string vDSOcGGsh)
{
    bool UNmmijpywoh = false;
    double aXIRQj = -172436.86744825536;
    int CCcZytcgOrDtiB = -404268674;

    return vDSOcGGsh;
}

int pYgKUieNozSNX::rUHoW(double aLZTSOEAxOnY)
{
    int QttKfvRTnEIAm = -837643698;
    double ofiPmhwIIvKrcy = 496660.07799180335;

    for (int XwdDG = 721062413; XwdDG > 0; XwdDG--) {
        aLZTSOEAxOnY /= ofiPmhwIIvKrcy;
        ofiPmhwIIvKrcy -= aLZTSOEAxOnY;
        aLZTSOEAxOnY *= aLZTSOEAxOnY;
    }

    if (aLZTSOEAxOnY > 496660.07799180335) {
        for (int KmNvSxH = 2037970703; KmNvSxH > 0; KmNvSxH--) {
            aLZTSOEAxOnY += aLZTSOEAxOnY;
            ofiPmhwIIvKrcy += ofiPmhwIIvKrcy;
        }
    }

    if (aLZTSOEAxOnY < 82860.06678236164) {
        for (int XFFvzlHxxlPT = 385001063; XFFvzlHxxlPT > 0; XFFvzlHxxlPT--) {
            ofiPmhwIIvKrcy /= aLZTSOEAxOnY;
            ofiPmhwIIvKrcy /= aLZTSOEAxOnY;
            aLZTSOEAxOnY -= ofiPmhwIIvKrcy;
        }
    }

    for (int YgGgqumiAm = 1248520850; YgGgqumiAm > 0; YgGgqumiAm--) {
        ofiPmhwIIvKrcy = ofiPmhwIIvKrcy;
    }

    return QttKfvRTnEIAm;
}

void pYgKUieNozSNX::TKnhAjiR(double veTJonOiOMqVBs)
{
    double ykbZeVuPni = -127443.59789340489;

    if (veTJonOiOMqVBs > 320417.93071385333) {
        for (int oAheGyJj = 1216140578; oAheGyJj > 0; oAheGyJj--) {
            veTJonOiOMqVBs += ykbZeVuPni;
            veTJonOiOMqVBs -= veTJonOiOMqVBs;
            ykbZeVuPni -= veTJonOiOMqVBs;
            ykbZeVuPni /= veTJonOiOMqVBs;
            ykbZeVuPni -= veTJonOiOMqVBs;
        }
    }

    if (ykbZeVuPni <= 320417.93071385333) {
        for (int UzhztBmhrcXS = 236634815; UzhztBmhrcXS > 0; UzhztBmhrcXS--) {
            veTJonOiOMqVBs /= veTJonOiOMqVBs;
            ykbZeVuPni /= ykbZeVuPni;
            veTJonOiOMqVBs -= veTJonOiOMqVBs;
            veTJonOiOMqVBs -= ykbZeVuPni;
            veTJonOiOMqVBs -= veTJonOiOMqVBs;
            veTJonOiOMqVBs *= ykbZeVuPni;
            ykbZeVuPni += veTJonOiOMqVBs;
            veTJonOiOMqVBs -= ykbZeVuPni;
            ykbZeVuPni = ykbZeVuPni;
            veTJonOiOMqVBs *= ykbZeVuPni;
        }
    }
}

int pYgKUieNozSNX::WQhEDJjublRuTsFT(double mANTFnwc)
{
    string haTMKKv = string("JVRAXoxsAzJsopLMmQZIJTL");
    int zgnQzMdnmVOD = 1262349111;
    bool OyUFQWYAUWn = false;

    for (int NoNFpsbXUnn = 2050820700; NoNFpsbXUnn > 0; NoNFpsbXUnn--) {
        mANTFnwc -= mANTFnwc;
        zgnQzMdnmVOD /= zgnQzMdnmVOD;
        zgnQzMdnmVOD -= zgnQzMdnmVOD;
    }

    return zgnQzMdnmVOD;
}

bool pYgKUieNozSNX::PCTHAWBzQQHe()
{
    int NoRlHnpFI = 1056879266;
    int NjtheE = 1487466400;
    double ISlGcHOx = -789484.1633763599;
    string bfSLBzGuIqejhQPZ = string("qKaKegamxoAIwvnOttXoyJIXNQxuQnzRjAJwmUCkYASEwQDvtzqmdpoXeuBpouhADDnYMFbSVvQMLYZYcRsPBZcpWioWpHmwyPGNcbreWtciJahacyOBH");

    for (int qPNGDR = 1565909474; qPNGDR > 0; qPNGDR--) {
        NoRlHnpFI *= NjtheE;
        NjtheE = NoRlHnpFI;
    }

    for (int IhKJwXZrbCW = 679014946; IhKJwXZrbCW > 0; IhKJwXZrbCW--) {
        ISlGcHOx *= ISlGcHOx;
        NoRlHnpFI *= NjtheE;
        bfSLBzGuIqejhQPZ = bfSLBzGuIqejhQPZ;
        bfSLBzGuIqejhQPZ += bfSLBzGuIqejhQPZ;
    }

    for (int TKvZzpDaqb = 1194134222; TKvZzpDaqb > 0; TKvZzpDaqb--) {
        ISlGcHOx = ISlGcHOx;
        NjtheE -= NoRlHnpFI;
        bfSLBzGuIqejhQPZ += bfSLBzGuIqejhQPZ;
        NoRlHnpFI *= NoRlHnpFI;
        ISlGcHOx -= ISlGcHOx;
        ISlGcHOx = ISlGcHOx;
    }

    return false;
}

void pYgKUieNozSNX::vUCssGsRTimmgSY(int mvbeRxuWdMJKMMO)
{
    int mPihsXDt = 555660963;
    string KnnwknCwAwAYH = string("efphfPqLYTQYezJvZzLkpdlOtjNDczzSQuzTDMUceeTqmjsBlpqOELzjAXPQIgqgAGBbjeYtbDBdyBoirFDGwaenJjtmRAMdKwgmwnW");
    bool rGwFgHDheYd = true;
    int EDlaxbJMjsaoXLNV = -27428480;
    string UDiJgvFVwPuFH = string("oeBSYbOQHOMvzobPOGSVNsmBUp");
    bool ANUIbrocZDfxUExf = false;
    double EfjTRKNz = -811375.1240501077;
    bool nYGdos = false;
    int LDHhgBxqQDNd = 30141142;
    double LvdRCzBS = 676705.607130027;
}

double pYgKUieNozSNX::sOATws(double pKftYOvBKnkxmPv)
{
    int zZHfCkCPyMJCkFsE = 665041470;

    for (int jHcTNa = 1071662984; jHcTNa > 0; jHcTNa--) {
        zZHfCkCPyMJCkFsE /= zZHfCkCPyMJCkFsE;
        pKftYOvBKnkxmPv *= pKftYOvBKnkxmPv;
        pKftYOvBKnkxmPv = pKftYOvBKnkxmPv;
    }

    for (int MbPHGTiPfWLxSv = 1566320610; MbPHGTiPfWLxSv > 0; MbPHGTiPfWLxSv--) {
        zZHfCkCPyMJCkFsE = zZHfCkCPyMJCkFsE;
        pKftYOvBKnkxmPv *= pKftYOvBKnkxmPv;
        zZHfCkCPyMJCkFsE += zZHfCkCPyMJCkFsE;
    }

    for (int OzIWhnG = 629875462; OzIWhnG > 0; OzIWhnG--) {
        pKftYOvBKnkxmPv = pKftYOvBKnkxmPv;
        pKftYOvBKnkxmPv = pKftYOvBKnkxmPv;
        pKftYOvBKnkxmPv += pKftYOvBKnkxmPv;
        pKftYOvBKnkxmPv /= pKftYOvBKnkxmPv;
        zZHfCkCPyMJCkFsE -= zZHfCkCPyMJCkFsE;
        zZHfCkCPyMJCkFsE = zZHfCkCPyMJCkFsE;
        pKftYOvBKnkxmPv = pKftYOvBKnkxmPv;
        zZHfCkCPyMJCkFsE -= zZHfCkCPyMJCkFsE;
    }

    if (zZHfCkCPyMJCkFsE == 665041470) {
        for (int kGwMPOA = 1594098646; kGwMPOA > 0; kGwMPOA--) {
            pKftYOvBKnkxmPv += pKftYOvBKnkxmPv;
        }
    }

    if (zZHfCkCPyMJCkFsE < 665041470) {
        for (int bvlOkwOtChpomdH = 1079096308; bvlOkwOtChpomdH > 0; bvlOkwOtChpomdH--) {
            pKftYOvBKnkxmPv *= pKftYOvBKnkxmPv;
        }
    }

    return pKftYOvBKnkxmPv;
}

int pYgKUieNozSNX::ziXJZYaQfMhF(int SKHQuCfodVkarh, int KpyMgx)
{
    double JBtzFKHAWpd = -373301.317480895;
    int ExKGgett = 838148879;
    string imCFpFDQF = string("hGQ");
    bool LZpsXOCjRd = true;
    string WnSpBdSWhfBGU = string("szedDSlrwYPuinxweOaEMXUvRVYDsdsDQMtxycSqLKwKsAeo");

    for (int HOTZMJgD = 704044219; HOTZMJgD > 0; HOTZMJgD--) {
        ExKGgett -= KpyMgx;
        ExKGgett -= KpyMgx;
        SKHQuCfodVkarh /= KpyMgx;
    }

    for (int bCwRwrK = 1153918761; bCwRwrK > 0; bCwRwrK--) {
        SKHQuCfodVkarh -= ExKGgett;
        ExKGgett -= ExKGgett;
    }

    for (int MZVhUGjDXp = 1812275200; MZVhUGjDXp > 0; MZVhUGjDXp--) {
        SKHQuCfodVkarh += SKHQuCfodVkarh;
        ExKGgett *= KpyMgx;
    }

    return ExKGgett;
}

double pYgKUieNozSNX::GQAbVrkRzlT()
{
    double hPIdmdIKvITvao = 51035.00965916388;
    int TAfjpapwq = -1259855126;
    bool DrFOuke = true;
    string npXFhsmWZys = string("tONgRqNgLiOniNUtzy");
    string TRDqqpqiPPj = string("bJJZfJXoSOFKfybhZSaJIkCBpNMTBpQvhZIAtBoTqPizpWFtikElzQcZcKjVpMkMNSzjjGrMFEooqBduCmFTcHVNYznYGLlHqQVFecORtlOKBBBTIrGiRClZkdcWiHkYQHXjbKaXITpQobDmlObAFYaShOewglJiFRxCBTBLsImwXREbdhEnKJsRfKOuTENzZOIJRdGoKbLDVAjHNIPLqhjCKpMIYcLRxRVoTxeTDOnLKuBjFQe");
    int kDAPxsdxM = -923231487;
    double wBMgtwlAhdsM = -601011.093729928;
    bool WWjYDxVVhqbSCR = true;

    for (int GrvqnNUGlE = 698476789; GrvqnNUGlE > 0; GrvqnNUGlE--) {
        WWjYDxVVhqbSCR = ! WWjYDxVVhqbSCR;
        kDAPxsdxM *= TAfjpapwq;
    }

    return wBMgtwlAhdsM;
}

double pYgKUieNozSNX::USzsDMvUhMNMq(bool tpIxSDkfTQt, int TtSdUJdkI, string TGkDywXSOaHPvhVC, bool ufaGAuYckBoFk, int IhEib)
{
    int XJiZvNuGne = 393414050;
    int VFOPNCVsZrr = -2013953091;
    bool QrQmGwH = true;
    bool apMfkeMngb = true;
    double luuMBKNnAoPvouTP = 449500.6989586553;
    bool apPLSoSxb = false;
    int EhFHi = 423297477;
    double fcXdjaHFisvKAsU = -998456.3478497928;

    for (int wxCpgtVYBGOay = 1843644555; wxCpgtVYBGOay > 0; wxCpgtVYBGOay--) {
        IhEib -= XJiZvNuGne;
    }

    for (int AOVTUMfgL = 641167868; AOVTUMfgL > 0; AOVTUMfgL--) {
        tpIxSDkfTQt = apMfkeMngb;
        EhFHi -= TtSdUJdkI;
        VFOPNCVsZrr += XJiZvNuGne;
        ufaGAuYckBoFk = ! apMfkeMngb;
    }

    return fcXdjaHFisvKAsU;
}

double pYgKUieNozSNX::kgpMRouYUgTlkE(bool zcnIryJTNeMOaw, string gPKaaKQyLByiBcjs, double fSzBGARWTOnPwM, double keDjUdUhJBkHVGB, string bDMzOSQKNp)
{
    string EpAWpDSocAipSD = string("twNBQljatXMUxKGRCCcQBcEZAXgOcyyKHsDieCbRLQaiGysIvkZpVzkvtOWBiZfGPvCaEASzqcguDUEhOZCmkEhPQerJFHjRJYHsVMozmrGiCcymNfDYFOnXXykmOFdlwaeTMSSSkXxdOHfDczIZQXKTEvcALdTOHmiQiMnsXVgIHYCoPbvcZzQEDFZdcXSSEqbKWNSnXMSMjowEyfZKnffX");
    bool PzPOiZts = false;
    string iTBGpdc = string("ZwMzEfaPUguIoAQzJStnKdwJGrZcxdkXPsFpHVLOaEhKqPRtWxlACfzFiNhAbYQPoioiNXRqNuNPfYnnusdVqNdUxtIEHEclIYJsXYvwsNNExUbAmcUQItUrkZoXEQMxaXpxmHGUzXfaVfEJroLZkhGBcnWGQaeodzaqImHfMrUbgZAzhZAKMhQpyeVSPOfYbWCVDXIJihvSlwyBtmMzNfuQAJiMBydWHZKxrrlJtGhNY");
    double XZxYFPDibR = 423926.4675264258;
    string JPwNtguYhYstzIi = string("UZgepZFmvrPCcPANOmbywfnQTMkYRFCwpLavYgiccDPhRRofzaRmbXTGnUxrWrwmEEhTotfIRbKbWQcaHuGTHnIugyAcRJWZdwffoAjQizGMAeffKrrYrCpiwAhCHrIrwCcLaiLszQMAYbPsPYjICGj");

    for (int qUvCmQDOeUFYgflf = 1576494577; qUvCmQDOeUFYgflf > 0; qUvCmQDOeUFYgflf--) {
        fSzBGARWTOnPwM = fSzBGARWTOnPwM;
    }

    for (int CrfGuLVlOPY = 431284855; CrfGuLVlOPY > 0; CrfGuLVlOPY--) {
        iTBGpdc = EpAWpDSocAipSD;
    }

    return XZxYFPDibR;
}

string pYgKUieNozSNX::GEXnwQZr(string ENnsINDOYaISrQb, int VIbQYVAhMwyDeH)
{
    string lnsTsAtsRR = string("hpMyOBQhnOiASAyiApGvbFOCxpcPHA");
    string mzcoswbo = string("TLUtcVfceFezgsoUskMyjomdyvUMzYkzSRVujXGSeoNjexpankeNsnNZVacPQIxXUISyjKxXyIUCzlKAIxmYrQuJhmBONbHdqdzsFRhIKQgmDZxBZaVpkHmygjHSmVmNxEdTkowGBNhLMUNkorMprnRjoazmmUADicFfsibvmLQoNVNClSQbRkMPRtXOTLuInmHbzUwAKXOCr");
    bool XaTIzS = false;
    string hMMEBVEwRj = string("YiVqQzGovxVZytWzlOKtVvuRxiynsBsGDYKVGLuJHwkujgutJmQkntwdMRwqqRGvRWTOcTgfXHRWtxsYLoiiTfoIAbnCcYoJuXwiWCmUijxWtXZHCovfaSqiNRfCqGtQfmrycwshEnchzdHrOtuAsFxzqDcWtlqhrcAxbphWrtMFLoQaeNrzQTtCMklYdsscUUddukxyNowCyHRPjWIVdOeZpZmVyCdVKmRQDWkdlmkIDkjXcIQfZl");
    bool aqhXTsR = true;
    int NbzOBRE = -965953903;
    double oaeEkEiOevfhBmGo = -227809.9968659773;
    int eiVCrD = 467043576;

    for (int conPukLGpEt = 148695963; conPukLGpEt > 0; conPukLGpEt--) {
        mzcoswbo = lnsTsAtsRR;
    }

    for (int SCGsP = 904984064; SCGsP > 0; SCGsP--) {
        XaTIzS = aqhXTsR;
        eiVCrD /= eiVCrD;
        lnsTsAtsRR = hMMEBVEwRj;
    }

    for (int OZCHqe = 935933625; OZCHqe > 0; OZCHqe--) {
        oaeEkEiOevfhBmGo -= oaeEkEiOevfhBmGo;
        ENnsINDOYaISrQb = lnsTsAtsRR;
    }

    return hMMEBVEwRj;
}

bool pYgKUieNozSNX::UNPimSZ(bool YylbIhdHdVlQp)
{
    string qcGuUp = string("oyergELRYRHsppWvWzEMIpxJsTvQSzTmNbypSBgslfTQCuGPAWYtWqWmGrbyizrtjDeetbPprtWLMilfoDiYtASkfZjLRKbzIjHEckbCLILDueVDtdvxNSdvNVsxTrHxjAbhmXoaWQYNXlxYXZWGZhbNO");
    int DVsbjSXppHG = -1524037134;
    double pkezXUBBmuV = -147833.6082691698;
    bool hjyIpchmVxODg = true;
    double hnfUhQNIxHtyaFgy = -383236.4882128767;

    for (int eXeuzQgLf = 1006084562; eXeuzQgLf > 0; eXeuzQgLf--) {
        YylbIhdHdVlQp = hjyIpchmVxODg;
        pkezXUBBmuV += hnfUhQNIxHtyaFgy;
        YylbIhdHdVlQp = ! hjyIpchmVxODg;
        hjyIpchmVxODg = ! YylbIhdHdVlQp;
    }

    return hjyIpchmVxODg;
}

double pYgKUieNozSNX::nvwLZtWLVim(bool AefeeklsNcr, int WTNFFXJWxhb, int bhggROVfrvjybbI)
{
    int XHLCtchps = -602878018;
    string ggaPseRHcSmjTvwt = string("hFZIZXrXspkmxEAZZBUuLqHmZUGSzsOgUCgGVNOEPZTPqTcSuGgTNKLxzSQoFsfwEwGhkDVFYTdTSv");
    bool fRBAPaSsoMcITgFb = true;
    bool PXfoWb = false;

    if (fRBAPaSsoMcITgFb != true) {
        for (int iVVxTibPhfMyKiK = 77081365; iVVxTibPhfMyKiK > 0; iVVxTibPhfMyKiK--) {
            AefeeklsNcr = PXfoWb;
            PXfoWb = PXfoWb;
            PXfoWb = ! AefeeklsNcr;
        }
    }

    if (bhggROVfrvjybbI == -376313587) {
        for (int ukQcnPqlLHV = 1982324637; ukQcnPqlLHV > 0; ukQcnPqlLHV--) {
            AefeeklsNcr = AefeeklsNcr;
        }
    }

    if (fRBAPaSsoMcITgFb != false) {
        for (int MIBHCRWVBWjk = 550834087; MIBHCRWVBWjk > 0; MIBHCRWVBWjk--) {
            AefeeklsNcr = ! fRBAPaSsoMcITgFb;
            PXfoWb = ! fRBAPaSsoMcITgFb;
        }
    }

    return 981265.9984817618;
}

bool pYgKUieNozSNX::fNxTakgsOyjvhH(double WVNepoioiblGMBL, double YwnBSVTyBfqfoLvW, double avfBcUxCB, bool YXQJjUktIMS, int hKOocWoRfwKmtUAo)
{
    int GhbbTjVRM = -81996863;
    int eZODUJK = 818174052;
    bool yVWefWNLzgBfZ = true;
    int CCueoZOK = 284685237;
    bool PLhBdkLNnHZehW = false;
    double ALVtoLwEWtzZ = -936343.0878661252;

    for (int ijkvjeozoJwRm = 866030115; ijkvjeozoJwRm > 0; ijkvjeozoJwRm--) {
        hKOocWoRfwKmtUAo *= CCueoZOK;
    }

    for (int qciHhmtVhUGg = 932906434; qciHhmtVhUGg > 0; qciHhmtVhUGg--) {
        ALVtoLwEWtzZ -= avfBcUxCB;
    }

    return PLhBdkLNnHZehW;
}

pYgKUieNozSNX::pYgKUieNozSNX()
{
    this->lUjclggzNw(609883.8684294804, string("gSWRHJxMWMVpXmkgRNxmoIggEWxzfkRGWstZxCfGLm"));
    this->rUHoW(82860.06678236164);
    this->TKnhAjiR(320417.93071385333);
    this->WQhEDJjublRuTsFT(-270389.569095674);
    this->PCTHAWBzQQHe();
    this->vUCssGsRTimmgSY(190844614);
    this->sOATws(-605953.6948670391);
    this->ziXJZYaQfMhF(-845246001, 484347603);
    this->GQAbVrkRzlT();
    this->USzsDMvUhMNMq(false, 2018644026, string("MPniwiqjoXbmrchYyxKSFRbKrPxnCXjSKKkapbpFBboOsAATMIAozodnRZIaFYasJVMtiTHiYauYGlhKaNIeLMXkOmmWOpGjBIXzqmvGwAJOmtQgmBXRziccXjaFopHnPzckHKwHupDQowVnbZtsPHKfwhxLZIrHjldvkddscs"), false, -1872453491);
    this->kgpMRouYUgTlkE(false, string("HzebTAGmYNOaYZgaibmLQLCAIJNtBABRheixhwfAbuKfDcPUqhrXKRMKoEnYuoyihzpIbiysfwKDYqQIovzNvsArFiXKibCRCQKEKeBfcLceDgBDMgYvuaMVBfpiJURkaljcPhavgrVcCvdzCxKFbebNCYxWixADBkcRQroPhmOVTGGroWHfNUAwuysOEhcVHMuTyZYbhMNayr"), 650403.3845042823, 184059.68865978532, string("QcbZjvXXEiShWQOEBxFlTUDaOoJZrWQMAGFyDFofLyAdBrJoJPiqywSEFltMdwfvrfDRquoaGUHuYHGAxyvyMKpmkOpyJvoEgSEUjcUhFHNbMdTMILvflnUFzkjAIQNLoxMzE"));
    this->GEXnwQZr(string("kkIzeqvvKOlCJiyOOlgitfBpkWbcOqGIcXcGgwOHxurjIFTsvhSlsYxbMOkVTCxDCfcPUxLGfyestipGUJNqtwiEpABaghdkroYlGCUwwCQMHFtRDEjnoCNswqMPvUnRZHsWpEkcaHOiMMWRjIcQdpsFzBTSTZqUGoenKdXOVxGihhQBGSbxfntsydjaOGrWRZMxrvwmNTtsk"), -1591393538);
    this->UNPimSZ(false);
    this->nvwLZtWLVim(false, 729293709, -376313587);
    this->fNxTakgsOyjvhH(-143684.24936665568, -204746.47926220635, 866689.5801502441, false, -184184324);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iWtQpjzsEMwVt
{
public:
    double nnaunF;
    double jKHYQFDPJUmEj;
    double PHvfRrRpRS;
    int GhdAsNmoTC;
    int JOYDqNF;
    bool jWpOVsfqBcX;

    iWtQpjzsEMwVt();
    string rtDihQ(double zsORxJWZfWgdTJEY, bool WrqNSZTYXFyjOw, bool ijnjC, double hfKyPVYahLnJW, bool cdtjr);
    double rdRMKiBREuSn(string cXttXqimtSUX);
    int DaqZTgFHOUNT();
    string sTxftNdBkYwy(double hGaei, bool bHVEtgoejkJDZz);
protected:
    double esrLAsYdeYX;
    string FOlxZxYzZEX;

    int xQQbJ(bool mYqxNTq, bool DxvCziM);
    string xfcxUepRbPuU(string mWdqCjOZwGhjHOmO, double JlKLVqusswv, double bUeDarbqnSZQwkW, string mwitulwkrUfQBxHl);
    void SFSoHNv();
    int EcmIbjZXb(int JYURtfUmFv, bool mMruphLoQmPCwA, int YWCUazDd, int qaQqolzbPUi, string HwZwWOmQoYTGD);
private:
    string gmqgAXCEWNu;
    string pnCgguSSpRc;
    double OZTGlkxfffXwQM;
    double HdSjg;
    string WoAjNkQpvkT;
    bool pvIHmE;

    bool bwoSXdYEgMJQHh(double IXJsUJCVypE, double ipgiOzCmydNq);
    double mlsoTsfwcgVCWqg();
    string vFaQjUJifbhWlA(string NKiQRRNxJjk, int iqhsrpbylv, string BQqNIKM, string LcfvpDnLsaQiLz);
    string utopX(bool sWGaS);
    int IVcEQjAnOELg(int sNBXHe, bool ywEOd, string OfsVTor, int bHMjehTIpV);
    int FSBVXSSQtkzOCs(double XapYWXxFiMZDyJFv, int ZLZsovWrs, string qnuQtqELKEDK, string unRDZj);
    int LHYePZKohWsOPAWC(string qJxDChxvSVrmo, bool sStTqmTXuZiorUh, int GoUQTaO);
    double cLVFWRa(double uVCvInHxpKypZIq);
};

string iWtQpjzsEMwVt::rtDihQ(double zsORxJWZfWgdTJEY, bool WrqNSZTYXFyjOw, bool ijnjC, double hfKyPVYahLnJW, bool cdtjr)
{
    string WLWaxR = string("wnTCBfYgkBkiRWG");

    if (cdtjr == false) {
        for (int BrDFpkGCUgEDSZF = 875956657; BrDFpkGCUgEDSZF > 0; BrDFpkGCUgEDSZF--) {
            continue;
        }
    }

    for (int yctSgryduyxo = 2106376842; yctSgryduyxo > 0; yctSgryduyxo--) {
        zsORxJWZfWgdTJEY = hfKyPVYahLnJW;
        WrqNSZTYXFyjOw = WrqNSZTYXFyjOw;
    }

    if (zsORxJWZfWgdTJEY <= -858024.9582106002) {
        for (int StRlKuPeHplUWuc = 235961708; StRlKuPeHplUWuc > 0; StRlKuPeHplUWuc--) {
            ijnjC = ! cdtjr;
        }
    }

    for (int JZqoZgKFdIgSqYT = 655344737; JZqoZgKFdIgSqYT > 0; JZqoZgKFdIgSqYT--) {
        hfKyPVYahLnJW /= hfKyPVYahLnJW;
    }

    for (int WRrXuZgoFBgwuLi = 542078984; WRrXuZgoFBgwuLi > 0; WRrXuZgoFBgwuLi--) {
        ijnjC = ijnjC;
        ijnjC = cdtjr;
    }

    return WLWaxR;
}

double iWtQpjzsEMwVt::rdRMKiBREuSn(string cXttXqimtSUX)
{
    int fRPwxgqPOfFXlSRH = -377693653;
    int bDSIMegkQ = 160257698;
    int BbYFLYaWEM = -528323779;
    string OEQwlHjliyGmE = string("RwwaVTiptSXyWCdXQLsakAuPQbAgAADDInZHpyzzWIonAkMdnbQICmngohIJwHAnaWBKEbwulhKHHfUpbMCWzngFUobBMBieicDBLdbkkRagojWpytjvbzf");
    string mkUhKgiEB = string("ZqhMXluLcjFbyMceYYYXrkWaYLBQXYEoxQfkuKnUbzrqHwgtYyutSZxTbTTHGLqMuAqWFtvlowtRjEGFsNBOtmaCGYgZDJPqdkbeqegEDhFvQjLqfDKMMwOvaZlidbHaFvlCzEOAUZYqFChmVnzFLUTreAMFYfVsbKs");
    double QAOfBrndlW = -39942.3580641229;
    string ZTSxjq = string("ScFKPSTEQulnyBmUFnwdtXxLaCESOUZyGOIxgEnivGjTgUoBWBjeTvcIHtjLHuWjnzYTJCdiiEqUFffBAuWQczBkwDkVtkduCdUvqjRHenrNRdOwkiSmInQqTwUSWJlFIpJuAQTckNwUNPJiRcobjZAYbSWLxWAr");

    for (int voONHuaGx = 918567438; voONHuaGx > 0; voONHuaGx--) {
        cXttXqimtSUX = mkUhKgiEB;
        mkUhKgiEB = OEQwlHjliyGmE;
    }

    if (mkUhKgiEB > string("ScFKPSTEQulnyBmUFnwdtXxLaCESOUZyGOIxgEnivGjTgUoBWBjeTvcIHtjLHuWjnzYTJCdiiEqUFffBAuWQczBkwDkVtkduCdUvqjRHenrNRdOwkiSmInQqTwUSWJlFIpJuAQTckNwUNPJiRcobjZAYbSWLxWAr")) {
        for (int XNLvACa = 1587052972; XNLvACa > 0; XNLvACa--) {
            continue;
        }
    }

    if (OEQwlHjliyGmE <= string("ZqhMXluLcjFbyMceYYYXrkWaYLBQXYEoxQfkuKnUbzrqHwgtYyutSZxTbTTHGLqMuAqWFtvlowtRjEGFsNBOtmaCGYgZDJPqdkbeqegEDhFvQjLqfDKMMwOvaZlidbHaFvlCzEOAUZYqFChmVnzFLUTreAMFYfVsbKs")) {
        for (int MHLFxT = 755151260; MHLFxT > 0; MHLFxT--) {
            ZTSxjq += OEQwlHjliyGmE;
            cXttXqimtSUX = mkUhKgiEB;
            mkUhKgiEB = mkUhKgiEB;
            OEQwlHjliyGmE = OEQwlHjliyGmE;
            OEQwlHjliyGmE += ZTSxjq;
        }
    }

    if (mkUhKgiEB >= string("ScFKPSTEQulnyBmUFnwdtXxLaCESOUZyGOIxgEnivGjTgUoBWBjeTvcIHtjLHuWjnzYTJCdiiEqUFffBAuWQczBkwDkVtkduCdUvqjRHenrNRdOwkiSmInQqTwUSWJlFIpJuAQTckNwUNPJiRcobjZAYbSWLxWAr")) {
        for (int KTPHVhNjZdQ = 1751923865; KTPHVhNjZdQ > 0; KTPHVhNjZdQ--) {
            ZTSxjq += mkUhKgiEB;
            OEQwlHjliyGmE += ZTSxjq;
            bDSIMegkQ += BbYFLYaWEM;
            mkUhKgiEB = mkUhKgiEB;
        }
    }

    for (int EFSclihAjYMtMfz = 816529002; EFSclihAjYMtMfz > 0; EFSclihAjYMtMfz--) {
        bDSIMegkQ = BbYFLYaWEM;
        cXttXqimtSUX = ZTSxjq;
    }

    return QAOfBrndlW;
}

int iWtQpjzsEMwVt::DaqZTgFHOUNT()
{
    double fldZylbaZVwQW = 394821.45945246564;
    double ugIkOiY = 42434.73554459812;
    int lOrURtow = -1057825457;
    bool iWueL = true;
    double zNHCP = 553532.4906281515;
    bool WydLMPMlCzQesmnU = false;

    if (ugIkOiY > 553532.4906281515) {
        for (int HFAALshnGRZG = 2107928814; HFAALshnGRZG > 0; HFAALshnGRZG--) {
            ugIkOiY -= zNHCP;
            lOrURtow -= lOrURtow;
            lOrURtow += lOrURtow;
        }
    }

    for (int qrWCFmctbezqzkY = 1540447453; qrWCFmctbezqzkY > 0; qrWCFmctbezqzkY--) {
        continue;
    }

    return lOrURtow;
}

string iWtQpjzsEMwVt::sTxftNdBkYwy(double hGaei, bool bHVEtgoejkJDZz)
{
    bool lxMvCE = true;
    bool guFdsPYuLPiXDAS = true;

    for (int NWTsXfIZoRPCh = 644058010; NWTsXfIZoRPCh > 0; NWTsXfIZoRPCh--) {
        bHVEtgoejkJDZz = ! lxMvCE;
        bHVEtgoejkJDZz = ! guFdsPYuLPiXDAS;
    }

    if (bHVEtgoejkJDZz == true) {
        for (int cmWzrspgubGmF = 1633798540; cmWzrspgubGmF > 0; cmWzrspgubGmF--) {
            guFdsPYuLPiXDAS = bHVEtgoejkJDZz;
            lxMvCE = ! bHVEtgoejkJDZz;
            guFdsPYuLPiXDAS = ! guFdsPYuLPiXDAS;
            guFdsPYuLPiXDAS = lxMvCE;
            bHVEtgoejkJDZz = ! bHVEtgoejkJDZz;
        }
    }

    for (int SETrruVgiq = 2018158926; SETrruVgiq > 0; SETrruVgiq--) {
        continue;
    }

    if (lxMvCE != true) {
        for (int BVfwlg = 796565912; BVfwlg > 0; BVfwlg--) {
            bHVEtgoejkJDZz = ! guFdsPYuLPiXDAS;
            bHVEtgoejkJDZz = ! guFdsPYuLPiXDAS;
            lxMvCE = ! guFdsPYuLPiXDAS;
            guFdsPYuLPiXDAS = bHVEtgoejkJDZz;
            bHVEtgoejkJDZz = bHVEtgoejkJDZz;
            hGaei -= hGaei;
            lxMvCE = ! lxMvCE;
            lxMvCE = ! guFdsPYuLPiXDAS;
            guFdsPYuLPiXDAS = bHVEtgoejkJDZz;
        }
    }

    if (guFdsPYuLPiXDAS == true) {
        for (int AganeNIJvGnCl = 341960254; AganeNIJvGnCl > 0; AganeNIJvGnCl--) {
            guFdsPYuLPiXDAS = ! lxMvCE;
            guFdsPYuLPiXDAS = ! bHVEtgoejkJDZz;
        }
    }

    return string("ovuSgSSmXQMGbh");
}

int iWtQpjzsEMwVt::xQQbJ(bool mYqxNTq, bool DxvCziM)
{
    double uGegzdcFodw = -954735.2547022729;
    int vSljvpZK = -1557074900;
    double jDXdIGZlxQYNif = -456484.5314415808;
    int WkxtKXTjv = 1757174517;
    int GsnVOqqgHuGzPvp = -1095644328;
    int vopBbLWBwvJwDF = 1223683272;
    double yGpjJbKkBBEWgn = -769268.3919583204;
    string VRVcGocfoqfDcA = string("rmRfgikiznV");
    double twqTgRu = -179120.09369165674;
    int xdXXRijDpQCslzE = -1804331533;

    for (int KesgrmMiRRXJtx = 891580465; KesgrmMiRRXJtx > 0; KesgrmMiRRXJtx--) {
        vopBbLWBwvJwDF *= vSljvpZK;
    }

    for (int ViqLTKdfPAVDw = 89877996; ViqLTKdfPAVDw > 0; ViqLTKdfPAVDw--) {
        vSljvpZK -= WkxtKXTjv;
        vopBbLWBwvJwDF /= vopBbLWBwvJwDF;
        vSljvpZK -= vSljvpZK;
        jDXdIGZlxQYNif *= twqTgRu;
    }

    for (int IQwhkaRhKgSEla = 1056673136; IQwhkaRhKgSEla > 0; IQwhkaRhKgSEla--) {
        DxvCziM = ! mYqxNTq;
        vSljvpZK *= xdXXRijDpQCslzE;
    }

    for (int apmOeMN = 1181052932; apmOeMN > 0; apmOeMN--) {
        continue;
    }

    return xdXXRijDpQCslzE;
}

string iWtQpjzsEMwVt::xfcxUepRbPuU(string mWdqCjOZwGhjHOmO, double JlKLVqusswv, double bUeDarbqnSZQwkW, string mwitulwkrUfQBxHl)
{
    bool qoniMR = false;
    string XzaJKPYIhFIY = string("qCvjdyGhYceMtUCknHghlJyDigydjgArhhBSJjmFOxjstdXjJgrkgAEOsKQuhjUDrqJHYEyErPDkmPrQQduSMJcePWMZTmCbGrjYSppDiOtBFRfRBfDRtKoRrQroaWOVUfojLGGHRRGwIMoOLUJfjZKtxYRglwLrOPHMvWQnepgPMsBQNNoHuUqqwdGcuGFnQITPbWXiBnbjXCzYVBVvydSdTAPeYVbrEFPOxSUKVDlcbKiuEJjZOqtyh");
    bool HownqRIWRNQ = false;
    string JiUFHdifUgu = string("CEvJdynwLuvgeQOgMiJKmcAslvVXKpPGgXActkKNgGnbEuXvwWyKNDWdfGUhskMpivZQGjqbnGpEILWPvPlJtiMCYWOQpMKlSzveOQtLXthPgpFgxSrFBTkuNYuVQEkJXAOGoEVmKrPTcMgLOVxFMPHQycntKukchMq");
    double BLMkoTjqxjOGa = -964960.6450425424;
    int lsNGj = 1755592957;
    bool EXEmspL = true;
    string AhxqoiXOWDwAeZTw = string("MerjOfyhgRBFCSDQowOaTcEGJGLkEpQXtcDCeuergTSzmqWKWcSquiGuTnMVpUKbaqrdyUJmqddOHMU");

    if (EXEmspL != true) {
        for (int fDiKvwU = 1350843209; fDiKvwU > 0; fDiKvwU--) {
            mWdqCjOZwGhjHOmO += AhxqoiXOWDwAeZTw;
            qoniMR = ! qoniMR;
            mWdqCjOZwGhjHOmO = AhxqoiXOWDwAeZTw;
        }
    }

    for (int puwtouKhkmtD = 430075417; puwtouKhkmtD > 0; puwtouKhkmtD--) {
        JlKLVqusswv += BLMkoTjqxjOGa;
        mWdqCjOZwGhjHOmO = mWdqCjOZwGhjHOmO;
        JlKLVqusswv *= BLMkoTjqxjOGa;
        EXEmspL = EXEmspL;
    }

    return AhxqoiXOWDwAeZTw;
}

void iWtQpjzsEMwVt::SFSoHNv()
{
    int thQUhy = -1734422878;
    int hVUhHXkidhkrEuC = -1371379592;
    bool gmenQrsTzX = true;
    string TdXZeyyr = string("ZWKzLcEcdSSwOIqPMqgVUmjssjcoMWOCYtpLtzxUZVhBbHtjdtFcvxHwpNNYLLnZIFjcfxKtKoLeNxvQMFqZeddeTaDVYIfWjKiYzppdplkKnIxNtNddkaPdixnVQ");
    int WsbdPIWaV = 1559536116;
    int xXwAkLgn = 27219509;
    string aArusczfFqsC = string("JOCJEMRCJpxVuNlkmkBJeuXhjGRSwDthspAPuSuvOOuqWkCvoLxivOiLndyvOympMWlOVZ");
    string elMEsz = string("JWOvwhqWYZvDKiSSmWLtWbSeetjbjBKFihsznIlPQldAqLYinW");
    double yFzYFWEsWzCNKPj = 767196.0397264349;

    if (hVUhHXkidhkrEuC < 1559536116) {
        for (int YtbuDUmhNkkOd = 1660060385; YtbuDUmhNkkOd > 0; YtbuDUmhNkkOd--) {
            xXwAkLgn *= hVUhHXkidhkrEuC;
        }
    }

    for (int BjeAKm = 1133819664; BjeAKm > 0; BjeAKm--) {
        WsbdPIWaV -= hVUhHXkidhkrEuC;
        elMEsz += TdXZeyyr;
        TdXZeyyr = elMEsz;
    }

    for (int diLmLiDQYmMmNSn = 606454148; diLmLiDQYmMmNSn > 0; diLmLiDQYmMmNSn--) {
        aArusczfFqsC += aArusczfFqsC;
        thQUhy = xXwAkLgn;
        xXwAkLgn -= thQUhy;
        xXwAkLgn = xXwAkLgn;
        WsbdPIWaV += hVUhHXkidhkrEuC;
    }

    for (int HUCFBSLeNlCMzE = 1593798618; HUCFBSLeNlCMzE > 0; HUCFBSLeNlCMzE--) {
        xXwAkLgn *= hVUhHXkidhkrEuC;
        TdXZeyyr += elMEsz;
        TdXZeyyr = TdXZeyyr;
    }
}

int iWtQpjzsEMwVt::EcmIbjZXb(int JYURtfUmFv, bool mMruphLoQmPCwA, int YWCUazDd, int qaQqolzbPUi, string HwZwWOmQoYTGD)
{
    bool HnGFRcxG = true;
    string pyjAWWwzGKnMs = string("QtIFzbFhgmqTGKoTbqsfOzAxiDqlDFQQSURRmnItmQNrAYINFnKjkGxVuXqKGQFCwWWJTnQYlIYVyyZlQCTeUGRmkBOTpPwyMhZalLTVyQxKpoJJZYwdSFwjvEczvnSDzfnZqnyfDvdGEvxbbKZPsNpuKsRwxqXzVIZFLRbCMZnKvQMXJyWKlUObC");
    double adQjxAt = 636604.8111738255;

    if (YWCUazDd == 1505080884) {
        for (int nzrgBC = 1927564916; nzrgBC > 0; nzrgBC--) {
            adQjxAt *= adQjxAt;
            qaQqolzbPUi = JYURtfUmFv;
            JYURtfUmFv *= qaQqolzbPUi;
        }
    }

    for (int WAZiTeCWO = 1866951306; WAZiTeCWO > 0; WAZiTeCWO--) {
        JYURtfUmFv = YWCUazDd;
        HnGFRcxG = mMruphLoQmPCwA;
    }

    if (JYURtfUmFv > 1505080884) {
        for (int qVXffrdgjDu = 714063565; qVXffrdgjDu > 0; qVXffrdgjDu--) {
            continue;
        }
    }

    for (int UtNANRJVNjnwwF = 1643036975; UtNANRJVNjnwwF > 0; UtNANRJVNjnwwF--) {
        continue;
    }

    return qaQqolzbPUi;
}

bool iWtQpjzsEMwVt::bwoSXdYEgMJQHh(double IXJsUJCVypE, double ipgiOzCmydNq)
{
    string OXdRXLOfONcdXn = string("LBXwOuvhewIXRSopWAhStuQiviVVVLmizJOrpdUCV");
    bool PNqMbuKtWp = true;
    double waENWZyP = 326588.4508186672;
    int NPzez = -1020368722;
    int YoXgctGeQeNXXZ = -1360565493;
    double mDUFH = 45116.96973756325;
    double jSlIizGC = -428871.2861584069;

    for (int GBdOz = 1225366136; GBdOz > 0; GBdOz--) {
        jSlIizGC += waENWZyP;
    }

    if (YoXgctGeQeNXXZ == -1360565493) {
        for (int LckCiwiLQsfL = 506592245; LckCiwiLQsfL > 0; LckCiwiLQsfL--) {
            jSlIizGC -= waENWZyP;
        }
    }

    for (int UQGtnTQZMWlGlBKY = 687978520; UQGtnTQZMWlGlBKY > 0; UQGtnTQZMWlGlBKY--) {
        IXJsUJCVypE /= IXJsUJCVypE;
        jSlIizGC += ipgiOzCmydNq;
        jSlIizGC *= ipgiOzCmydNq;
    }

    if (mDUFH >= -319177.4619149484) {
        for (int CRdjVtc = 2082667582; CRdjVtc > 0; CRdjVtc--) {
            continue;
        }
    }

    for (int lNUahdFnI = 919036801; lNUahdFnI > 0; lNUahdFnI--) {
        waENWZyP += waENWZyP;
        waENWZyP *= ipgiOzCmydNq;
        jSlIizGC += jSlIizGC;
    }

    for (int bgKiOfIKhmB = 673918190; bgKiOfIKhmB > 0; bgKiOfIKhmB--) {
        jSlIizGC -= waENWZyP;
        mDUFH /= mDUFH;
    }

    if (waENWZyP == -351178.1979053334) {
        for (int BPvKEEYhqxbT = 118078645; BPvKEEYhqxbT > 0; BPvKEEYhqxbT--) {
            IXJsUJCVypE /= ipgiOzCmydNq;
            IXJsUJCVypE -= ipgiOzCmydNq;
            IXJsUJCVypE += mDUFH;
            ipgiOzCmydNq -= ipgiOzCmydNq;
            IXJsUJCVypE *= ipgiOzCmydNq;
        }
    }

    if (YoXgctGeQeNXXZ > -1360565493) {
        for (int ScPrfkvzePIfN = 229852376; ScPrfkvzePIfN > 0; ScPrfkvzePIfN--) {
            jSlIizGC = jSlIizGC;
            IXJsUJCVypE = mDUFH;
        }
    }

    return PNqMbuKtWp;
}

double iWtQpjzsEMwVt::mlsoTsfwcgVCWqg()
{
    int veEcACCNhjVBcqg = -919685233;
    int ZEHPZflVWzYokuF = 1933280326;
    int eiybHDKv = -616122774;
    string ZGtMdhEzIhtzV = string("NgDpDdwmpxBXRaMCYRYJFUapJqSRidEkSiMmEBcxIQGvnyvuCdCcZtprlKpufYwicxjREdhFyNwBGsLxQjJwCRoTldYfXSJGJ");

    if (ZEHPZflVWzYokuF == -616122774) {
        for (int OSYwxSnmdh = 1700970792; OSYwxSnmdh > 0; OSYwxSnmdh--) {
            eiybHDKv += eiybHDKv;
            veEcACCNhjVBcqg /= veEcACCNhjVBcqg;
            ZEHPZflVWzYokuF -= ZEHPZflVWzYokuF;
        }
    }

    if (eiybHDKv > -616122774) {
        for (int FUFvO = 2083607436; FUFvO > 0; FUFvO--) {
            veEcACCNhjVBcqg *= ZEHPZflVWzYokuF;
            veEcACCNhjVBcqg *= eiybHDKv;
            veEcACCNhjVBcqg -= veEcACCNhjVBcqg;
            ZEHPZflVWzYokuF += ZEHPZflVWzYokuF;
        }
    }

    return -471628.6721305189;
}

string iWtQpjzsEMwVt::vFaQjUJifbhWlA(string NKiQRRNxJjk, int iqhsrpbylv, string BQqNIKM, string LcfvpDnLsaQiLz)
{
    bool WDUChENegrud = true;
    bool QilnZLgbZ = false;
    bool JKxVnRfNm = true;

    if (WDUChENegrud == false) {
        for (int njAKYDscq = 1555194467; njAKYDscq > 0; njAKYDscq--) {
            JKxVnRfNm = QilnZLgbZ;
            NKiQRRNxJjk += BQqNIKM;
            BQqNIKM += BQqNIKM;
        }
    }

    for (int vIgAlTxkiCaVgY = 408432959; vIgAlTxkiCaVgY > 0; vIgAlTxkiCaVgY--) {
        JKxVnRfNm = QilnZLgbZ;
        NKiQRRNxJjk += LcfvpDnLsaQiLz;
    }

    return LcfvpDnLsaQiLz;
}

string iWtQpjzsEMwVt::utopX(bool sWGaS)
{
    int nfKtoAFSHHDiXk = -1065453114;
    bool KYqxjga = true;
    string CpnkuyDQhTiRxZm = string("qSFjNjmnMADmYpfqDmPINnwlMnxcHPpezLdDZLSoDepeKrFdkgoadyZNZvZXddWMYIuyhEmueafleckMlzQylVTqWDmF");
    int VyzHOLmkrlP = -32262465;
    string RzLueUPCE = string("kXjZiGFTiXiYLhPQGfktkfpLHSAViAviphiROFxuVMcHNclrrvwyiZbtWmVxqRUXedeUJVqupcEfnfsCJLtbkjdDRjlhwEhPPLmlQOzCXowSpsfJgfbDpPcTQHfIocADGsiMeJYMZnaSsMSfEPBoyfckPZmxAcibJTtGmezVGUOqJjRtDcObkk");
    bool OsPzqkBIhys = true;
    bool wwOLa = true;
    string pTqtVCboyOSNFciX = string("NpzQJbBhkHNjjpkyWgqaNainDqhuVAWbeEPefFt");

    for (int WpRBGgvBWaoEnHSo = 287592727; WpRBGgvBWaoEnHSo > 0; WpRBGgvBWaoEnHSo--) {
        OsPzqkBIhys = sWGaS;
        KYqxjga = sWGaS;
        nfKtoAFSHHDiXk *= VyzHOLmkrlP;
        wwOLa = ! KYqxjga;
    }

    for (int fmwHNryj = 2082254361; fmwHNryj > 0; fmwHNryj--) {
        KYqxjga = KYqxjga;
    }

    return pTqtVCboyOSNFciX;
}

int iWtQpjzsEMwVt::IVcEQjAnOELg(int sNBXHe, bool ywEOd, string OfsVTor, int bHMjehTIpV)
{
    int SaPbVIyDtLxqnKJ = 1558203321;
    double lhoaZtOZknGcH = -633871.6908876926;
    double AfykXN = -881946.9861017222;
    double EoiNKFHrjLiJccUZ = 829350.0750971001;
    bool gtqYTzykGzAOQtEx = false;
    int HJwgjjSztznMWPA = 1349173029;
    int RRTuEbXyZmyFi = 772758975;

    for (int OClNTqbrKXpDgHa = 517786839; OClNTqbrKXpDgHa > 0; OClNTqbrKXpDgHa--) {
        RRTuEbXyZmyFi -= HJwgjjSztznMWPA;
        HJwgjjSztznMWPA -= bHMjehTIpV;
        HJwgjjSztznMWPA *= RRTuEbXyZmyFi;
    }

    for (int CEtrgYXoVREB = 658304900; CEtrgYXoVREB > 0; CEtrgYXoVREB--) {
        continue;
    }

    if (RRTuEbXyZmyFi != 1558203321) {
        for (int mgpDbCmsHhrBWLDj = 1567697765; mgpDbCmsHhrBWLDj > 0; mgpDbCmsHhrBWLDj--) {
            AfykXN += AfykXN;
            AfykXN = EoiNKFHrjLiJccUZ;
            sNBXHe /= sNBXHe;
        }
    }

    if (HJwgjjSztznMWPA < 772758975) {
        for (int vIDEidZsBjkyInGY = 978443054; vIDEidZsBjkyInGY > 0; vIDEidZsBjkyInGY--) {
            EoiNKFHrjLiJccUZ *= lhoaZtOZknGcH;
        }
    }

    for (int jhYnFcVJJpuo = 1722878665; jhYnFcVJJpuo > 0; jhYnFcVJJpuo--) {
        RRTuEbXyZmyFi *= sNBXHe;
    }

    for (int XPptmHRZ = 429851094; XPptmHRZ > 0; XPptmHRZ--) {
        lhoaZtOZknGcH *= AfykXN;
        RRTuEbXyZmyFi -= sNBXHe;
        EoiNKFHrjLiJccUZ += EoiNKFHrjLiJccUZ;
        ywEOd = ywEOd;
    }

    return RRTuEbXyZmyFi;
}

int iWtQpjzsEMwVt::FSBVXSSQtkzOCs(double XapYWXxFiMZDyJFv, int ZLZsovWrs, string qnuQtqELKEDK, string unRDZj)
{
    bool CSiYeT = true;
    bool UsZtlPqF = true;
    bool iejBwwDmWsJ = true;
    string KPiREw = string("fBddaAftvOzxVKqlNUpadFNoirZDiYLyROHrITGVJnQDVfbgLWYsaAmfzbzbudmQFAotSiacOdDSLkQAZmiqwMPJixdHPXDidwRfsHzAjsCKEfSssZcofLhCuQopEaZaZPJWeHPbRWIaFIAhNTWjyqDnKyYK");

    for (int YvLdUJQuVL = 271331445; YvLdUJQuVL > 0; YvLdUJQuVL--) {
        continue;
    }

    return ZLZsovWrs;
}

int iWtQpjzsEMwVt::LHYePZKohWsOPAWC(string qJxDChxvSVrmo, bool sStTqmTXuZiorUh, int GoUQTaO)
{
    bool tWdWPdEGbpIRrps = false;
    int MlagPwDgMV = -718390556;

    for (int lmYbxdrLWPKhM = 500368812; lmYbxdrLWPKhM > 0; lmYbxdrLWPKhM--) {
        GoUQTaO = GoUQTaO;
    }

    for (int MkHbDvb = 1683731851; MkHbDvb > 0; MkHbDvb--) {
        sStTqmTXuZiorUh = ! sStTqmTXuZiorUh;
        tWdWPdEGbpIRrps = tWdWPdEGbpIRrps;
        sStTqmTXuZiorUh = ! tWdWPdEGbpIRrps;
        tWdWPdEGbpIRrps = ! sStTqmTXuZiorUh;
    }

    for (int PVHXGGMNHlLFuz = 1724266446; PVHXGGMNHlLFuz > 0; PVHXGGMNHlLFuz--) {
        sStTqmTXuZiorUh = ! sStTqmTXuZiorUh;
        tWdWPdEGbpIRrps = ! tWdWPdEGbpIRrps;
        tWdWPdEGbpIRrps = tWdWPdEGbpIRrps;
        sStTqmTXuZiorUh = ! tWdWPdEGbpIRrps;
    }

    if (GoUQTaO < -123473370) {
        for (int cDXZpIE = 377253845; cDXZpIE > 0; cDXZpIE--) {
            sStTqmTXuZiorUh = sStTqmTXuZiorUh;
            MlagPwDgMV = GoUQTaO;
            tWdWPdEGbpIRrps = sStTqmTXuZiorUh;
        }
    }

    return MlagPwDgMV;
}

double iWtQpjzsEMwVt::cLVFWRa(double uVCvInHxpKypZIq)
{
    string HJgdWGE = string("xKTnvREYHawndPyWINwyjeRncfqgENMjbsRwJAeExHkRoQlFKRrnlhLhTXgoQRUnzRqvpoDwY");
    double IJryvYAU = 707402.1549375097;

    for (int YYmClVnNwhLYEbn = 1641514672; YYmClVnNwhLYEbn > 0; YYmClVnNwhLYEbn--) {
        HJgdWGE = HJgdWGE;
        IJryvYAU *= IJryvYAU;
        uVCvInHxpKypZIq *= IJryvYAU;
        HJgdWGE += HJgdWGE;
    }

    if (IJryvYAU == -612629.0643397144) {
        for (int DWMCB = 1949152906; DWMCB > 0; DWMCB--) {
            IJryvYAU += uVCvInHxpKypZIq;
            HJgdWGE = HJgdWGE;
        }
    }

    if (uVCvInHxpKypZIq > -612629.0643397144) {
        for (int GOVaeMMMrUp = 1381156832; GOVaeMMMrUp > 0; GOVaeMMMrUp--) {
            IJryvYAU -= uVCvInHxpKypZIq;
            IJryvYAU = uVCvInHxpKypZIq;
            uVCvInHxpKypZIq *= IJryvYAU;
            IJryvYAU = IJryvYAU;
            IJryvYAU = IJryvYAU;
            IJryvYAU += uVCvInHxpKypZIq;
            uVCvInHxpKypZIq = uVCvInHxpKypZIq;
            uVCvInHxpKypZIq = uVCvInHxpKypZIq;
        }
    }

    return IJryvYAU;
}

iWtQpjzsEMwVt::iWtQpjzsEMwVt()
{
    this->rtDihQ(209275.59077358447, true, true, -858024.9582106002, false);
    this->rdRMKiBREuSn(string("JqPSBWYUXIGljwHdnQNGUCTFaOymNoLuxMiZXbTZFbYPlgfxtidiEPWTzKSdOBjNTkyOfbcOajDpzRsbrJXwUYFiiZcFVThjoebqTGFCmfkQOtIhBztkTywbsMKKjPAgWBsJsLieMSfqPLYNFTnDQABaipAQhTGNNKQTlwdnEfkgdewcQkoWcOOCxMDqwJGLhVvZXAMVYlfbCsQAbscyHxHZasGpXciro"));
    this->DaqZTgFHOUNT();
    this->sTxftNdBkYwy(-671118.984710237, true);
    this->xQQbJ(true, false);
    this->xfcxUepRbPuU(string("ET"), -558824.2754335346, -158820.22022954727, string("aYJIWUUdpAIuRriS"));
    this->SFSoHNv();
    this->EcmIbjZXb(1505080884, true, 296876420, -1770958648, string("koszLRToTDGzvSQgFfyZdeAMstzbuJmFYKp"));
    this->bwoSXdYEgMJQHh(-351178.1979053334, -319177.4619149484);
    this->mlsoTsfwcgVCWqg();
    this->vFaQjUJifbhWlA(string("MFZlLvbiBLoxvsmyFIgeYQqAdmTlnLVqMLZJIDfnjNWHyqOVHKxFMzQqyoEBszwOZnlMmt"), 1858901680, string("xCsGkNLFBgyfoRgFKFjqXIdYXOekDmgvxajODiSZKwZabRckVVyCJtKLfDGwUNIibCgTeSSmgaoPGIzdnMROVghEPExbOXrMmraZzBxopWwAGGTJOPghiqfKFYcWqPLesRWEbFJiYHMoAcFEszNfjueSWBgvcHCFEvFjJmMjeqELztrRosKC"), string("BqdaOpyyHDspaIksDhczJAcrebmLDRpzZcbLcZaWdzSeeqBGTbUvgUeMoQGxvOQriJNVCgLTIHuIHEqnowlzbHEWJsqxYtpcnLyseOOFWrKTZqTuTEGLHkArWUYauGcKpWacOQyRFHkwZWnjjjUdhXNUtwdNAjIKxkiXMzLQXkxvoHeaqKTQHBLobRNeQvwrIMiWckPHRwtzlBAfmZGRILNrFgLgwhQSpJUUSCEIfu"));
    this->utopX(true);
    this->IVcEQjAnOELg(1595383759, true, string("qkNRGdtsXwUAfcQffeDBLeKPtlDywicADxsEdJXtYnUSCHkqxwEAZbzHEsPcyBcDThupSOrrVhbCmbhCUUjKHTweIlNzmjQpQgNNktXyGGdFXRiEUaKRMAcFzqfuAcOsgGOowoFklOfnYmdZYTTBj"), 1352229219);
    this->FSBVXSSQtkzOCs(-64131.8985238783, -1962827139, string("XZUJyRxpNkZCwhBiMztpAmqcdJSzWTKdIjveFuyJEfusxkSVmEDcxqkdagJRNrGJTBZOltQEtAmfHzaoYPillbwTsXysFEsUMpTwSRPymMRtfDNsIFroLZQcRzfrYISELzgvVZHf"), string("QRZBZppXfHIViiHstbmpdlsLYSrKMcJUHeMMZZPTNwtUrnsTsEZnkxbSqsWTFWsgRBmDQjdbbeyqhjjnhVoLzCvzusDpSGROzJEdBnDFdBjbtElqxvEAfmQRMHiAbAfwdPltJrmqJTIejkGcbKcLVbpOuooVxSAjrxLhTtxLNvjpAeThSGDmVsFbBtnyrvURMEAylsAmQcXalEEjtbPaQBHVeVlOjYujvABVVhld"));
    this->LHYePZKohWsOPAWC(string("ZxWWLdmgFciCotUWkJGBzKTzoMSZudrdhGdiQxiezsuhe"), false, -123473370);
    this->cLVFWRa(-612629.0643397144);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iQbici
{
public:
    string hxwtB;
    string RblUFf;
    int JHUTdkhLGUTs;
    string iNgwlSenCxr;
    string aJSUk;
    string VRNtPhziBQo;

    iQbici();
    int bNmPKgfQlbZRM(bool PgdgSMQ);
    void cXDCd(int mPtINiBQoQv, double hbVbuRJbPsqIhOnF, double uordQSYAdxUuXg, double dWYzAgd);
    void OSLcbuT(string XDsHICBACSnGiU);
    bool ExBzPtXedIBOawT(bool cXSbaHPzRG);
    int PKJCbjPeh(string QXlYwOhXFpKpnKOM, bool nhbryTRZtHxlMQqm, string eyZkGRbYgLdw);
protected:
    bool lyDDuKB;
    bool Nrala;
    int wqPDGUGsA;

    bool gTOdVuSkIjVddWE(string xIPereWcMxB, double GQeaoVMrOYWVDe);
    void RgpfbH(bool qszLOKcTnAdEuYs, string EJLFxrhygyvpeJW, int yWJHIrLY);
    string tBhkZ(double xwltzXc);
    double iWkzmgc(int GkYbgSvMfXS, double vvOQVdstgPYuK, double RhULQKhVeAOQw, double lJQoOxBoIlkOIgt);
private:
    string lruhoAfRumlKCtS;
    double fiewIodV;
    double FyoBKxpUITUcpOS;
    string gAGblm;
    int ylRAhUIVFvcsxb;

    double JfvVCfOTkncNfNP(double phVwvbtrshYCaX, string PWWktoyGKX, int jaxCroKZSjfmIehJ, double QUTvQRhqel, int eXxEznmwmf);
    int mATCFYqJ(int UAfZtWaPawLIiz);
    int jNMQehpEMn(string aIsKzvWGoYX, string nUEdbW, double LasRKtjsnlQYWjN, bool WoFJz);
};

int iQbici::bNmPKgfQlbZRM(bool PgdgSMQ)
{
    int mphbVLaUpPCu = 1458085271;
    int onkfrNJqfnnyHXM = 82779882;
    int vRaMzf = 886385919;
    bool byFDcSfQXwFZYfA = true;
    double GUujHHcI = 440328.15260543686;
    bool ZfEaMQF = false;
    string QGrXXacHTlnlAb = string("lnXKJixmjbtuTOXOYuuvIOwzeqocECyHASDYlwBoTxsFKUsSDYADgMrczmNZeQxkuLxHPzHKdtkbuVBue");

    for (int KfndVxAbEAKq = 1393604108; KfndVxAbEAKq > 0; KfndVxAbEAKq--) {
        byFDcSfQXwFZYfA = ! ZfEaMQF;
        GUujHHcI = GUujHHcI;
        vRaMzf *= mphbVLaUpPCu;
        onkfrNJqfnnyHXM += mphbVLaUpPCu;
        QGrXXacHTlnlAb += QGrXXacHTlnlAb;
    }

    for (int GSosIAC = 357414535; GSosIAC > 0; GSosIAC--) {
        byFDcSfQXwFZYfA = PgdgSMQ;
        onkfrNJqfnnyHXM -= vRaMzf;
    }

    if (PgdgSMQ != true) {
        for (int agwDUpdSXIsMpqnN = 1652013356; agwDUpdSXIsMpqnN > 0; agwDUpdSXIsMpqnN--) {
            continue;
        }
    }

    return vRaMzf;
}

void iQbici::cXDCd(int mPtINiBQoQv, double hbVbuRJbPsqIhOnF, double uordQSYAdxUuXg, double dWYzAgd)
{
    string uZSVEGaLWizusGJ = string("PYhMVjBeARavcTOxHRXGKblmpwYGEwnEnxfFdPWoAF");
    bool HnbOGMYYysfgk = true;
    double FvQHDQJZwxzW = -701295.4106060223;
    int oZXCIYH = 1934117045;
    int BXnbdF = 1883210761;
    double SiGOGAteMkUfBT = -474889.6203486047;
    double keYoSrt = 514152.26655196084;
    bool TealujGOnxbmnC = false;

    if (hbVbuRJbPsqIhOnF == 514152.26655196084) {
        for (int eEtqzlUP = 767699018; eEtqzlUP > 0; eEtqzlUP--) {
            keYoSrt = FvQHDQJZwxzW;
        }
    }

    if (keYoSrt == 514152.26655196084) {
        for (int QaKwhqt = 1362030939; QaKwhqt > 0; QaKwhqt--) {
            dWYzAgd = hbVbuRJbPsqIhOnF;
            keYoSrt -= keYoSrt;
            BXnbdF /= BXnbdF;
        }
    }

    for (int tcycRUKO = 1815189963; tcycRUKO > 0; tcycRUKO--) {
        TealujGOnxbmnC = ! TealujGOnxbmnC;
        SiGOGAteMkUfBT /= FvQHDQJZwxzW;
        keYoSrt -= uordQSYAdxUuXg;
    }
}

void iQbici::OSLcbuT(string XDsHICBACSnGiU)
{
    string VSZtqDtwPbU = string("bvYZBIIeWjHfyMLfryPnpQfuffqggLfBCkyaHlVOucIkUcFGKLqqWdTFMhPrwSoCJKkPEMQoqJVfKufzVPJWbJRayDcHvdrYUSbXBLk");
    bool UHsmofOfk = false;
    string mHMjydqpxpDr = string("qHKHYaztWrQhgqRsJhJTQGJCZTqgSkXyctsZRLTVJkTYCXzDsdyeIXNcdeaqEPgOeUqzaJBfwNxvnVTTKvKnyPFHhoADPBSLeqXmBKRTffgWANvsdfhFSCARsDMsXjNBFZidWKNZQZQFpQzqqnbAKgcDnpNTuxpAubrZdfZKGFutYFkVPmmaFTPZWOTUtktiGbVozBalRYJiDCIlDECmneNOxzpnsFODrVq");
    int IFltQpy = -1565125726;
    bool WMvPTYXZ = false;
    bool aCMJtpWDmPm = false;
    string FIjAnOb = string("bJClRHVvSbEgjtsbtChtEILHPWdkYqMSLMpxpNDRqwVRXkNOJNjInkWrPSrbYzBwHIlFXCXrrccBXMIseLBIJAXhPmPMOoSveqTALtbfZQYbxUAS");

    if (WMvPTYXZ == false) {
        for (int KUzMguxyBiVY = 2067157136; KUzMguxyBiVY > 0; KUzMguxyBiVY--) {
            UHsmofOfk = WMvPTYXZ;
            UHsmofOfk = UHsmofOfk;
            VSZtqDtwPbU += FIjAnOb;
        }
    }
}

bool iQbici::ExBzPtXedIBOawT(bool cXSbaHPzRG)
{
    int HmewScDRU = -1292111218;
    string UkTVLUqR = string("UfNUdXkziToSKCDTHtOYJiAilTgfHpXtUMgSAYastJJTdvkdWyUHEWAGcuZDgzoYzzXHwCvrLdsriyWihlwPAckSlNYtYmuVPELoOjBSFpmTqbjmYVvMYYjfSVOVTffwqnjudjTUMvlDHCmKPQgyMTLZOvVfgBvxDosUhxXHEGVmnJzNizjXZTGUTIOFbdlWNITUOQbzgNvJTQWTwEzUztxeINbZIkrCARRwUEXnaRFXCohIluyeDz");
    string UwByMy = string("ThsdyXKQFkVObltXsqzJPOmvzOcidWsyHUtcOCDJtj");
    string oXOsFzsNhAobf = string("PyhOJxOqXDIokvHKMYUUvEdnmgvKtaWoPRToBPkzOgzmzFDzSIVjErIXyZGQLzpLSXWHfl");
    int PyUgMqOYJUPIv = 2055005136;
    string gimPbiqUbXYPxI = string("ccAqpMLCPJubeXmruvuorwcrRLjymYRzGEXPWayWuWaKkMdsXhAIyWnMbMFTJKpdpMEKNSpOgtxhTDrDftkqApDjMEWtDuXfZQyBhDkwSxaIFGwltrdViiixtBbCjEKXljBMHG");
    bool ErhGeIKwcxOdNr = false;
    int NhlClvtuBOLWY = 440937352;
    string hADQvQvdreR = string("WkaBZkzNIVkUWxjgZEChixjtQaJQFXpghcfYVBHMikpsURGBraLeyzbAxjegXnQVOAsshnkeRAqcDvgmhJkRAAIbuJaLPaiiJpbwDMKJUTYqfpxxtCmVVujOuWLaKJsPfqjVSmPUVvlfcCTNXGtLGJQfgHIKfIEqhFvDE");
    string SolQnYBBCnIe = string("WAYqxZfgDicdmfePKOGCqPsXlRFKcUNeEPNiuvtzEGIZcXfPzexykcxbRQjLuQNejexXwYuAyXpPDHBvDLNqmPyfkXkmEaedxxLbEOGmiChcxiQqlTGJdTdiJQFclyvFIYDrPIxinDDRoZSJOJbqmbvFNpaVcpPTcGnkbYjzIzTvPIQwQOpCiWJShVrKbxRDAYsdvgIJtlVExzYkvBGdtGhf");

    if (hADQvQvdreR != string("UfNUdXkziToSKCDTHtOYJiAilTgfHpXtUMgSAYastJJTdvkdWyUHEWAGcuZDgzoYzzXHwCvrLdsriyWihlwPAckSlNYtYmuVPELoOjBSFpmTqbjmYVvMYYjfSVOVTffwqnjudjTUMvlDHCmKPQgyMTLZOvVfgBvxDosUhxXHEGVmnJzNizjXZTGUTIOFbdlWNITUOQbzgNvJTQWTwEzUztxeINbZIkrCARRwUEXnaRFXCohIluyeDz")) {
        for (int YAmtbQhVXrFIzEo = 1786444834; YAmtbQhVXrFIzEo > 0; YAmtbQhVXrFIzEo--) {
            continue;
        }
    }

    for (int VhxHyOlUYZ = 1071948444; VhxHyOlUYZ > 0; VhxHyOlUYZ--) {
        gimPbiqUbXYPxI += hADQvQvdreR;
        gimPbiqUbXYPxI = UkTVLUqR;
    }

    for (int iuHQsd = 189484665; iuHQsd > 0; iuHQsd--) {
        gimPbiqUbXYPxI = gimPbiqUbXYPxI;
        HmewScDRU += HmewScDRU;
        gimPbiqUbXYPxI = hADQvQvdreR;
    }

    return ErhGeIKwcxOdNr;
}

int iQbici::PKJCbjPeh(string QXlYwOhXFpKpnKOM, bool nhbryTRZtHxlMQqm, string eyZkGRbYgLdw)
{
    bool laDdhFrxJnCZ = false;
    string jEAeUC = string("nnYqMunanfiFfKdbyxNvQdxwCfKXFIFpkiqwZXAgXbICxbTkvxXqnzNYgvXxXsDbMUon");

    if (QXlYwOhXFpKpnKOM == string("FnnANAaKuhRxcmVHEPxPnOLVpgDCTYbvIDLpiloTuIVZjRDcfMdJWycNBXLEFiNkFXgIXwDmfshSek")) {
        for (int vzgSnplRClWF = 1775559261; vzgSnplRClWF > 0; vzgSnplRClWF--) {
            QXlYwOhXFpKpnKOM = QXlYwOhXFpKpnKOM;
            QXlYwOhXFpKpnKOM += QXlYwOhXFpKpnKOM;
            jEAeUC += jEAeUC;
            nhbryTRZtHxlMQqm = ! laDdhFrxJnCZ;
            eyZkGRbYgLdw += jEAeUC;
        }
    }

    return -1235357711;
}

bool iQbici::gTOdVuSkIjVddWE(string xIPereWcMxB, double GQeaoVMrOYWVDe)
{
    bool bxIoolaqk = false;
    string bifchOB = string("eEHLkgDQgLaPzZHXodaPA");

    if (xIPereWcMxB >= string("eEHLkgDQgLaPzZHXodaPA")) {
        for (int quvMLfjOBoxfKaC = 1111265057; quvMLfjOBoxfKaC > 0; quvMLfjOBoxfKaC--) {
            xIPereWcMxB = bifchOB;
        }
    }

    return bxIoolaqk;
}

void iQbici::RgpfbH(bool qszLOKcTnAdEuYs, string EJLFxrhygyvpeJW, int yWJHIrLY)
{
    string YFqNjzbZAVeUd = string("TmDjToVsYoPgsgOpSVrPrgPgexWYDysUsvZZIclArfiCbEzYKIEqUIZqkPMtVbsVOoDdrzrxHiIKmkChmlaxKfxTKXivMCfCYvoktnsthXfbdOEtdKvALoxFSfRmiWwNrYvOnMeTRXRagKExbpnmWofsiBcBAnurcnrxUQNdPvSWtcqBAWEzNFOUlb");
    string QSzUCBbQrfmqBi = string("oTmQgkIuqBxXikUWFkMHFV");
    string cBtLMpCc = string("iJxkkxNRbiyNYizbEgdfYOfNuEiWYwbrPdGIEJOAXhGDLhKRMHFnSHHsztildfRxgKwSdOoeRjpYfTLVusGwcMJLuxKFgYJITTZjxDsNdFPbJWNqoOeFuFGDQchgWYDvayRIQuCxAZKbjLdMuuCXThvtJtDd");
    double mUhjWSvwoW = 88532.14364626353;
    bool VnhqAUbtrVEAqvkH = true;
    int EyQzXe = -866523624;
    bool mxiQhbIfTP = false;

    for (int xkQJqbKXAz = 1275964401; xkQJqbKXAz > 0; xkQJqbKXAz--) {
        cBtLMpCc = QSzUCBbQrfmqBi;
        VnhqAUbtrVEAqvkH = VnhqAUbtrVEAqvkH;
        cBtLMpCc += YFqNjzbZAVeUd;
        EyQzXe -= EyQzXe;
    }

    for (int XYFCm = 1597033399; XYFCm > 0; XYFCm--) {
        VnhqAUbtrVEAqvkH = mxiQhbIfTP;
        cBtLMpCc += EJLFxrhygyvpeJW;
        yWJHIrLY *= yWJHIrLY;
        mxiQhbIfTP = ! mxiQhbIfTP;
    }

    for (int iabOXvvgmaWIWREC = 848022362; iabOXvvgmaWIWREC > 0; iabOXvvgmaWIWREC--) {
        cBtLMpCc = YFqNjzbZAVeUd;
        mxiQhbIfTP = VnhqAUbtrVEAqvkH;
        cBtLMpCc += cBtLMpCc;
    }
}

string iQbici::tBhkZ(double xwltzXc)
{
    string qBNQlMeHVFW = string("sYtzuSdbAHfuOaNIbbYkPHFWpguIvWRGPLGwbfMmaUdFwfHjNZLIeotHsTdVXJcBTpMAOjuDnKfKsbUlTCffXkghHhwMfPOcWPVCjdhxfMOtIcjHWGkCCiHkTFnddrbSuBHKHcoTzCHSQUDfaKZCKctzJXvCJTcoVNTxcaYFopamGCjWpcykPyAkaTfCEKZvODoEorRiEjuQTMJctWSudi");
    bool BiLlKAdQ = true;
    bool ZAOJMGMYFlrqJR = true;
    double dWLjwwjQdsS = -64335.7685239174;
    string tTHAGIpXWj = string("VZPtRzflbaoQnyEdTFOtVKIFsvKtPksZnBUtFoUXXAfuZEPWJwOdHOnSuxZwVZqajycxaDvVucMFDeZSJfwwxAeljlTDUOkGTAdkvgOnuAknND");
    int MqOiTzgBBekDXYB = -647904924;

    for (int QgrVwreZzczqmbq = 1587724064; QgrVwreZzczqmbq > 0; QgrVwreZzczqmbq--) {
        continue;
    }

    for (int wSbcL = 234939589; wSbcL > 0; wSbcL--) {
        continue;
    }

    if (tTHAGIpXWj > string("VZPtRzflbaoQnyEdTFOtVKIFsvKtPksZnBUtFoUXXAfuZEPWJwOdHOnSuxZwVZqajycxaDvVucMFDeZSJfwwxAeljlTDUOkGTAdkvgOnuAknND")) {
        for (int QwfqBSMf = 1146656654; QwfqBSMf > 0; QwfqBSMf--) {
            qBNQlMeHVFW += qBNQlMeHVFW;
            xwltzXc -= dWLjwwjQdsS;
        }
    }

    for (int RBVDbmpS = 1944595539; RBVDbmpS > 0; RBVDbmpS--) {
        continue;
    }

    return tTHAGIpXWj;
}

double iQbici::iWkzmgc(int GkYbgSvMfXS, double vvOQVdstgPYuK, double RhULQKhVeAOQw, double lJQoOxBoIlkOIgt)
{
    bool aRCygaBUmlCWxA = true;
    double cqxqe = -160072.31019968557;
    double SkcWNN = 290588.449599117;

    if (SkcWNN < 290588.449599117) {
        for (int bfPselCQSJGmIVNM = 784638887; bfPselCQSJGmIVNM > 0; bfPselCQSJGmIVNM--) {
            SkcWNN *= lJQoOxBoIlkOIgt;
            vvOQVdstgPYuK /= cqxqe;
        }
    }

    return SkcWNN;
}

double iQbici::JfvVCfOTkncNfNP(double phVwvbtrshYCaX, string PWWktoyGKX, int jaxCroKZSjfmIehJ, double QUTvQRhqel, int eXxEznmwmf)
{
    string JMASVWGieIkJ = string("nQFTkylEDEfmiHZgmbSItwJSDgNkvHZZHvNJpzBTQBGmwhADLKfxwLObxixGiRNNMNZMtjHiluZPRmMAL");
    string HqKRXsTtUmhv = string("drTPHHTsFkwGDYbTc");
    int DIMSDrxVebNNdK = 1958584544;
    string vPYQiL = string("HeROkph");
    double WaUkkx = 77716.89718061658;
    bool kYQenB = false;
    bool qpPgPLLG = false;
    bool mIHTGDvQCuhBi = false;
    string pzmIgRXFIqSoCJjd = string("xjmeGDgUidTpyDAgjgpYbzJwyoSLdgUWTEKTTNqKJLYxmROmOPogoUEOiqNbaKHPraMAxRVbvXpFJcAyNfCloEWJZTLfpmLSDjjVDLEYQFbYZVzqdPxPoDuzWeVzgYksJatD");

    for (int ZYpgrg = 1594063924; ZYpgrg > 0; ZYpgrg--) {
        continue;
    }

    for (int eiaIZiswh = 2094229105; eiaIZiswh > 0; eiaIZiswh--) {
        mIHTGDvQCuhBi = ! qpPgPLLG;
        DIMSDrxVebNNdK = DIMSDrxVebNNdK;
        QUTvQRhqel = QUTvQRhqel;
        phVwvbtrshYCaX = phVwvbtrshYCaX;
    }

    for (int MtbqBHqnPcNyUAl = 1890615548; MtbqBHqnPcNyUAl > 0; MtbqBHqnPcNyUAl--) {
        PWWktoyGKX += HqKRXsTtUmhv;
        vPYQiL += JMASVWGieIkJ;
    }

    if (WaUkkx < 77716.89718061658) {
        for (int tAFEGILjEKpHUfe = 2129302483; tAFEGILjEKpHUfe > 0; tAFEGILjEKpHUfe--) {
            vPYQiL = vPYQiL;
        }
    }

    if (HqKRXsTtUmhv != string("drTPHHTsFkwGDYbTc")) {
        for (int NubTkqALDAtdTW = 1712899552; NubTkqALDAtdTW > 0; NubTkqALDAtdTW--) {
            continue;
        }
    }

    if (JMASVWGieIkJ != string("xjmeGDgUidTpyDAgjgpYbzJwyoSLdgUWTEKTTNqKJLYxmROmOPogoUEOiqNbaKHPraMAxRVbvXpFJcAyNfCloEWJZTLfpmLSDjjVDLEYQFbYZVzqdPxPoDuzWeVzgYksJatD")) {
        for (int hZcpxw = 1166211337; hZcpxw > 0; hZcpxw--) {
            continue;
        }
    }

    for (int tnYhyJgA = 1028420258; tnYhyJgA > 0; tnYhyJgA--) {
        continue;
    }

    return WaUkkx;
}

int iQbici::mATCFYqJ(int UAfZtWaPawLIiz)
{
    bool KHXHUIRMes = true;
    string UnLhBJeLk = string("ZssxlQcIszTVlpzurNNhrilEMOJxMZCcbkSrbeqXrSsqZPmZyfeXPdxIknrkNCmfmqIWYMEJyoJNyemAsbCqGeXEOcREuuAqYTeeFziDEvTpRZsNmOKMjhFqhGFLmTXALDGjXXGPZJAZIJqQbPRCiAlYeNQmsdYPNsjXXGiIpYbxttPELizVHqkrBz");
    string YMGSB = string("hUkOuETtEfGDotwmbVSWWjAxdpBrvOZKfzNbYKSgzsLcMoRaDZOorIYxlWClNXvQoMypfQcpZMXKIhysIlGpeiIUtMYRRoSldwpplSJwsybdgYCtMqIgousEYRYnnvFrzYSTgXdvwkokfWEHSfRUrsTGtvaYQXXFgLSGYogrKdZpYnlxEGiyNKYviqBgOEDwrNpfoZLKzTeMAKRWJhN");

    for (int TnzjfxUBZfPjm = 347462639; TnzjfxUBZfPjm > 0; TnzjfxUBZfPjm--) {
        YMGSB = UnLhBJeLk;
    }

    if (YMGSB >= string("hUkOuETtEfGDotwmbVSWWjAxdpBrvOZKfzNbYKSgzsLcMoRaDZOorIYxlWClNXvQoMypfQcpZMXKIhysIlGpeiIUtMYRRoSldwpplSJwsybdgYCtMqIgousEYRYnnvFrzYSTgXdvwkokfWEHSfRUrsTGtvaYQXXFgLSGYogrKdZpYnlxEGiyNKYviqBgOEDwrNpfoZLKzTeMAKRWJhN")) {
        for (int HwXmADMk = 2024861030; HwXmADMk > 0; HwXmADMk--) {
            YMGSB = YMGSB;
            UAfZtWaPawLIiz += UAfZtWaPawLIiz;
            YMGSB = UnLhBJeLk;
        }
    }

    return UAfZtWaPawLIiz;
}

int iQbici::jNMQehpEMn(string aIsKzvWGoYX, string nUEdbW, double LasRKtjsnlQYWjN, bool WoFJz)
{
    int XtKoUdt = 1454677280;
    bool zrWVXl = false;
    double JOltVArvSDXGWRN = 993168.860427386;
    int BnvYPPczE = -130625089;
    string mGVFxdgpwI = string("NpROxvhFJCznSWrPxLepZfdqGSCZDovFBbgdhsbWlYOWHMMjJyrscyCtanJjKtUKiviZJlxQNSlUMRcfbfTd");
    int CYUebQHNmzHaP = 157370103;
    string MrkjDWKdgNsVy = string("SZeIfvykmIWtVmbgFypdokLowDkivqqKElaRJXSzkdZXrdzadPSPazjDRrmnWefueIVvzCTelgZpDjfTFDIefYdkZVnsbgtyMmjEB");
    int zieIWkTMwQfKMsu = -226653799;
    int naFcDQMk = 246713493;

    for (int ueDqRWwV = 829923156; ueDqRWwV > 0; ueDqRWwV--) {
        BnvYPPczE -= BnvYPPczE;
    }

    for (int BuMTbz = 896169295; BuMTbz > 0; BuMTbz--) {
        continue;
    }

    for (int EiziMrtWSZWuR = 1859406272; EiziMrtWSZWuR > 0; EiziMrtWSZWuR--) {
        naFcDQMk -= naFcDQMk;
        nUEdbW = MrkjDWKdgNsVy;
    }

    for (int WorQSD = 927675124; WorQSD > 0; WorQSD--) {
        continue;
    }

    return naFcDQMk;
}

iQbici::iQbici()
{
    this->bNmPKgfQlbZRM(false);
    this->cXDCd(659542631, 184154.82745172534, 482276.9872218803, -9820.89122791801);
    this->OSLcbuT(string("VIUGVu"));
    this->ExBzPtXedIBOawT(false);
    this->PKJCbjPeh(string("FnnANAaKuhRxcmVHEPxPnOLVpgDCTYbvIDLpiloTuIVZjRDcfMdJWycNBXLEFiNkFXgIXwDmfshSek"), true, string("vBUxCJsqfuBfYoSfhYzegqAuMyUTfsXpNilzOAwFsqRyXequIHkwDELciMirlCxfZhZrQyjcdYEqeZwUqIkyTDeSdhJpMQbWEMgIBzhgbsFSfSDmOAyHgTtfdNLHUnaoSwuoGpqpPkCkzrbULRLMDqoOOwOagMbieL"));
    this->gTOdVuSkIjVddWE(string("QCOCqGvQIISQbruwgPQGXWFwUnqbVqzDToKuMlRYWPEiQqfRBCwojNXQCcyiidk"), 377382.3357373175);
    this->RgpfbH(true, string("jTMdtWWFjDPARmPpgOvQZLsYCzeNiFGPIfLvjfPTcBUBQkYUheFYjWqTyFAYUQqBMsfufOydfRaaUSxBhTOtJthZZFyElittWyeckFimZWHhjEQokMCsCFFZcGoZaUsxsPeTqciJBCSqbNoEdwQXjNdwRWcIh"), 1631556396);
    this->tBhkZ(-336834.8211246745);
    this->iWkzmgc(1925167479, -294638.47206622857, 39546.55087245685, 858588.8900543228);
    this->JfvVCfOTkncNfNP(616999.4146628683, string("PtekRfVsrinDNNIjaheHfmwaZndremKyHxCQNueyTvmUhNsHHSqUAaiXEsXbXd"), 248586641, -178952.34416722303, -649221637);
    this->mATCFYqJ(1640541204);
    this->jNMQehpEMn(string("KghHSUKcjYAFtaOOWfoUAhCsPSj"), string("wROnXSAUbcViLByhnJJMJEwWUqiZMVNgDPzxhhTSqgefHrGQQMpwlBSxWKFvfGAiFVUJwjcZCOlTFZIWUgIEtoNxikXYtiYjOpWBxrxNOXoyjTWHakVgniy"), 616910.6075541168, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tMjoeOzrSDI
{
public:
    bool DjTZxlgQ;
    bool sPtIPJsZbQveWJ;
    bool ncZuSoAaIbQt;
    bool fSdBT;
    int IDAPzikFhFXSp;
    int UwyuiWYBn;

    tMjoeOzrSDI();
    int rNoiffKfBKJL();
    int DufguoYCBf(double HtOnTySene, int zJBxWESYc, string SZvsihelIIITull, bool wrsaJuqFbkkX);
    void HJmTvNVgbsi(string JBxOsydVAbH, double LOxdBHtv);
protected:
    int ZjLXEcy;

    double QNgDAoe(string mhuTQZ, double ReOPmnCfzPqU, double cjtGDDzL, double tqEDupEDTYXrLQL, int LpJhUqWnMRPhikWP);
    int slQPDPacpcSFScMz(bool BptewJsHsJ, bool GxGJhDU, bool uYGeCa, int ynxPAufGzf);
    int HkgJwjwZJMwY();
    bool oLAEmLUAw(int mghuWXbccvOdLC, int LydqmeWGfXxWAVK, string KbeLXmoTyWxGRjit, bool DvOCXLuvosg, bool aWsjKPSlXK);
    int sIKXvPoJgU(double JmiYy);
private:
    bool zCJLcUhlhnFGwf;
    int dnknGLZ;
    string bDdVaqeVaUNdMY;

    void qpcNQbeZawrb(bool aoZPkfJ);
    int eGyFOzUUoiNCfSi(string EIpKf);
    string KcjOR(double lZQXinDqSW);
    double WkzQWpHKNss(double ysOjfdzcMqrdbq, double GsImQQQvdtoAY, string mcSIKNCTyItxK, bool wthwKOmoWrBpCyy, bool CfkByblwurDGYn);
    void CZmYhiujGibnrQ(double gNeyg, double XOxBXY, bool RQmmPn, double JblTABU, double JNUbCciA);
    bool hPSMWuAPGF(bool NaiafPaw, int QlGocLTyPfq);
    int nhWMmilAvLXHIKY(bool IMcQNTPwECzr);
};

int tMjoeOzrSDI::rNoiffKfBKJL()
{
    double nvyBoseBd = 1000511.4188078068;
    string nFmWIplsEfjT = string("CyysdnaljNmTOnCCNuoxejvDgEIACUEWXplgYhuXvLRLasK");
    bool uFgHqElBwGdU = true;
    bool GtNRgzE = false;
    double iUEvXf = -847739.6786989318;
    string XepKmbdhBAG = string("eitAXytvktJgqjEWdNHicLcEOQpmrHsHInToyKOHDWnYVNtRWMBomyjMgPQmIMtuhyIsXxUKCNGeLXSvyvJFbbrng");

    for (int FEveLsZN = 1485896571; FEveLsZN > 0; FEveLsZN--) {
        uFgHqElBwGdU = GtNRgzE;
    }

    if (nvyBoseBd <= 1000511.4188078068) {
        for (int mQuaYNwoQGQLG = 64357307; mQuaYNwoQGQLG > 0; mQuaYNwoQGQLG--) {
            uFgHqElBwGdU = ! GtNRgzE;
            iUEvXf /= iUEvXf;
        }
    }

    if (XepKmbdhBAG != string("CyysdnaljNmTOnCCNuoxejvDgEIACUEWXplgYhuXvLRLasK")) {
        for (int nkhwkq = 544330915; nkhwkq > 0; nkhwkq--) {
            XepKmbdhBAG = XepKmbdhBAG;
        }
    }

    return 215957251;
}

int tMjoeOzrSDI::DufguoYCBf(double HtOnTySene, int zJBxWESYc, string SZvsihelIIITull, bool wrsaJuqFbkkX)
{
    bool URHdyCxGzilbOPu = false;
    double eSAZjxPKcU = 686678.4095857793;
    double dHZSOYmMIraY = 679696.425587832;
    string OurNUTAFNfvw = string("PaHMUNzeIWBfvfPglmulBWkcmuNpiPljcGAfQJejxlWYpPUQLTVMacrScFzJLvKEJKhjOKQJLRoCvcdvGMVAyppuQzppPKBSsJxyMwbkPcJZICBvUadlgObSBipLoCcKvUPxgWiPUtajUhuYOWrshGDxGVnQJPSCGTCFZwl");
    bool hUMnssrAtjm = true;
    bool LcxekLkV = true;
    string FZpeK = string("AoujkMmOOjDspZipYwvLAdDwCbwYFyeGZFBdjdTgVCitSjxPPYxncrkWhpDEkNbolhHeYOxEVySrUnMaXoOwEydhgNRIWqMBbCgNfXltnPFjOibwhNPuajCNREPJbrDLyGqrKYCbNYmHmREhphZpcxtIcctcOdKOnvdWEJnlVWIWXQsDEOvKJVWICJaxOKtqjVjdRQHFWMgljstiEAyLSQlDQpnfTtxpLGMS");
    double tGZXQFbiNHGhm = -208003.1977924265;
    int BRrouFwyODcJMztw = -316352649;

    for (int brmBhvaC = 1075685443; brmBhvaC > 0; brmBhvaC--) {
        hUMnssrAtjm = ! hUMnssrAtjm;
        HtOnTySene *= dHZSOYmMIraY;
        wrsaJuqFbkkX = ! LcxekLkV;
        eSAZjxPKcU += eSAZjxPKcU;
    }

    for (int DhOcWfcbzMDEkCCF = 1835569529; DhOcWfcbzMDEkCCF > 0; DhOcWfcbzMDEkCCF--) {
        URHdyCxGzilbOPu = URHdyCxGzilbOPu;
    }

    return BRrouFwyODcJMztw;
}

void tMjoeOzrSDI::HJmTvNVgbsi(string JBxOsydVAbH, double LOxdBHtv)
{
    double nSvpxkWulbGssLl = -961168.1565598703;
    int DsflKJjitk = -502759886;
    double liiWyzX = -521174.87533408013;
    string XudvnecJ = string("UYodNMfPLRgZaHvoMoqDpuGddzEeuAAiyANMmJZuYaClIijsIgJtJWZVddlgmatzQAfJlkmjiGyHIomxSVXRrpmmnwufpPDwJTyHttMLezgyhdMbTTuQBXomZrtPXfQIitEzKjZgoqywcTLkoIZHDFItoJvtcGRiTsOOOvpaJQZDxdvhNKfrnbFKdANozZYMNjdYAMApOnUajqjroPusTrggMoDMzuRwhFi");
    int jYpmcTZcJQAat = 1521862747;
    int QKTSZbeE = -1296473606;

    for (int AZmSYiwZNLaLJw = 1905928436; AZmSYiwZNLaLJw > 0; AZmSYiwZNLaLJw--) {
        liiWyzX -= LOxdBHtv;
        DsflKJjitk *= jYpmcTZcJQAat;
    }

    for (int yGRpKPbw = 1198561109; yGRpKPbw > 0; yGRpKPbw--) {
        continue;
    }

    if (nSvpxkWulbGssLl > -521174.87533408013) {
        for (int pLzKNnJFhbLTtTr = 1769407296; pLzKNnJFhbLTtTr > 0; pLzKNnJFhbLTtTr--) {
            nSvpxkWulbGssLl += nSvpxkWulbGssLl;
            nSvpxkWulbGssLl += liiWyzX;
            LOxdBHtv /= nSvpxkWulbGssLl;
            DsflKJjitk += QKTSZbeE;
        }
    }

    for (int TXghJdrXAvycQyNV = 779965052; TXghJdrXAvycQyNV > 0; TXghJdrXAvycQyNV--) {
        liiWyzX /= liiWyzX;
        QKTSZbeE += QKTSZbeE;
        DsflKJjitk += QKTSZbeE;
    }
}

double tMjoeOzrSDI::QNgDAoe(string mhuTQZ, double ReOPmnCfzPqU, double cjtGDDzL, double tqEDupEDTYXrLQL, int LpJhUqWnMRPhikWP)
{
    string MheGwLYNkndyu = string("qgCAYiPfxQUewctvvpvMkwreeETfVqvLPFtWmONdqbUIHErOVZAwviTSclKpflHaKDMxeejJtYPYWEiYPfRgqWFBjXSXmtlFvaHtqpidQStsJlSKDXrRTJhZZsbeXHoTijbKxdYntPWIrefoBfLgDtqTCDoMKlHAmTNTEMrMWxTxNSl");
    int UqDVWpPaWMEL = 1343179938;
    double djymGWtFWwe = -524342.567685565;
    string dtfZemRcOoJliik = string("BQfvYNTgu");
    int RpFdJZBMWK = 1765933445;
    string liAuouWqBG = string("ZfNbGmAcXWdsAEoRrBVbFOotBDgTZQnsBt");
    int faqxNg = -259820124;
    bool MHGyyzeSOG = true;
    int Pukhkqvz = 1916444275;

    for (int abrDfHfpffJBVS = 436605844; abrDfHfpffJBVS > 0; abrDfHfpffJBVS--) {
        djymGWtFWwe -= cjtGDDzL;
        RpFdJZBMWK /= LpJhUqWnMRPhikWP;
    }

    for (int jzNyvzmUHqE = 698770585; jzNyvzmUHqE > 0; jzNyvzmUHqE--) {
        dtfZemRcOoJliik += liAuouWqBG;
    }

    for (int CyVjfOYWv = 438557616; CyVjfOYWv > 0; CyVjfOYWv--) {
        djymGWtFWwe *= cjtGDDzL;
        tqEDupEDTYXrLQL -= cjtGDDzL;
        djymGWtFWwe = ReOPmnCfzPqU;
    }

    if (RpFdJZBMWK > 1765933445) {
        for (int YxUQSXdGptjq = 284767062; YxUQSXdGptjq > 0; YxUQSXdGptjq--) {
            continue;
        }
    }

    return djymGWtFWwe;
}

int tMjoeOzrSDI::slQPDPacpcSFScMz(bool BptewJsHsJ, bool GxGJhDU, bool uYGeCa, int ynxPAufGzf)
{
    string AboKbC = string("OcJkOdyKEulDidgkdHFhhYNneksIBaoOnyrwZIXGaWnkvRTlwycHCDEJdXjzFPqvWoxEjQzUBTTgdIvAFBMffEJULcKhdQpRECxKWUXwGIILPEqcgUtMbbPCAijilXtaWpANYKahWYfWxNyGFSXkcacpwcjbfkfUTopdXCYxfDAnoTQetahIYfwbCtQklVLEWNpwdakndebdLAaHOtBvljmE");
    double zMPhJfnPvR = -635348.7450741109;
    double PcCtvALfaOiA = -865436.92119676;
    string QJMcDlomKJgLwMMu = string("IsTCdHaBoCkNRrxmsxqtUJLdNlMJgQGXFHsmmaHLHvbqTmvz");
    int SKbflECaszgVEh = 719489278;
    bool PyxiJrFRpKtm = false;
    double BQEeFJL = 676970.8722750786;
    double pQGNCzTug = -649386.0457031584;
    string twUsTjJmbOfKHH = string("mgpXPWztYGwRTrrPNgjiEWZeNywfOwcuxUJEUEVEzRRFrShYfUu");

    for (int nRAlrox = 1901238067; nRAlrox > 0; nRAlrox--) {
        continue;
    }

    for (int CVpUdSWKFQ = 1279852241; CVpUdSWKFQ > 0; CVpUdSWKFQ--) {
        BQEeFJL = zMPhJfnPvR;
        ynxPAufGzf /= ynxPAufGzf;
        GxGJhDU = ! uYGeCa;
    }

    for (int AikqyynDke = 2029024707; AikqyynDke > 0; AikqyynDke--) {
        PcCtvALfaOiA = pQGNCzTug;
        twUsTjJmbOfKHH += AboKbC;
        SKbflECaszgVEh = ynxPAufGzf;
    }

    return SKbflECaszgVEh;
}

int tMjoeOzrSDI::HkgJwjwZJMwY()
{
    bool xspVv = true;
    double baHayo = 622702.3418990565;
    string eiGVo = string("ypwRSERbjsCApnzUXSlphbIyoqKSvfZabxduffYaoefNvnPUKaeROXfCkfRuEaXElquNYjzlareTkwqFvASsOAdgOVoYsQJykgKWFjsWdnxjztqRHbmiiLEppQDGMvRyfKdCLLoOqqzJkYRipciivsPKcCHBgclmNhnHnnxSGIPuUOSYBFYyqalcFXrvhJSztTAnEXpxEhlmhAPaIWlwdqWZkcbZMupJpFcjEQFidSv");
    double pyXjXbAw = 16494.950533876505;
    int ZRyVAoI = 1369817327;
    string nHmQzqWXjY = string("hEKtsCTDuGPXdgEStAHLdRTkwOzdTayzpWJEINtfqGljtWczRZIjBIGvCLirjWiaKKjSdaAnFd");

    for (int BHwgtplAvIrNxm = 1117729643; BHwgtplAvIrNxm > 0; BHwgtplAvIrNxm--) {
        nHmQzqWXjY = eiGVo;
        baHayo = pyXjXbAw;
    }

    for (int rgtiVRSJxN = 619313785; rgtiVRSJxN > 0; rgtiVRSJxN--) {
        xspVv = ! xspVv;
    }

    if (xspVv == true) {
        for (int CHCYZcMGl = 938284617; CHCYZcMGl > 0; CHCYZcMGl--) {
            eiGVo += nHmQzqWXjY;
            baHayo -= pyXjXbAw;
        }
    }

    if (eiGVo != string("ypwRSERbjsCApnzUXSlphbIyoqKSvfZabxduffYaoefNvnPUKaeROXfCkfRuEaXElquNYjzlareTkwqFvASsOAdgOVoYsQJykgKWFjsWdnxjztqRHbmiiLEppQDGMvRyfKdCLLoOqqzJkYRipciivsPKcCHBgclmNhnHnnxSGIPuUOSYBFYyqalcFXrvhJSztTAnEXpxEhlmhAPaIWlwdqWZkcbZMupJpFcjEQFidSv")) {
        for (int cnKidWFURuFZbv = 1692013012; cnKidWFURuFZbv > 0; cnKidWFURuFZbv--) {
            pyXjXbAw += pyXjXbAw;
        }
    }

    return ZRyVAoI;
}

bool tMjoeOzrSDI::oLAEmLUAw(int mghuWXbccvOdLC, int LydqmeWGfXxWAVK, string KbeLXmoTyWxGRjit, bool DvOCXLuvosg, bool aWsjKPSlXK)
{
    int mBcruAenHytn = -861677529;
    bool mKmschSzqaal = true;
    int zpAEErJ = -2104902382;
    bool VmMyqqvbMdRkj = false;
    double ZqAuhb = 916327.2908913372;
    double rnBBKmQvXeP = -476540.06474929774;
    double ebIcvLbAIeA = -154426.43490793035;
    bool GlYkHvkOqIp = false;

    for (int JamHuoFqE = 1511680265; JamHuoFqE > 0; JamHuoFqE--) {
        DvOCXLuvosg = DvOCXLuvosg;
        aWsjKPSlXK = DvOCXLuvosg;
    }

    return GlYkHvkOqIp;
}

int tMjoeOzrSDI::sIKXvPoJgU(double JmiYy)
{
    bool UBrDUqzL = false;
    double ItFdgJdlhIaIHXn = 537935.6051380312;
    string FtbGOHM = string("MePqUxxAhXOKcqdOMmGrZwpDPKdgFSlmFFuhgtkVhcEqhVQIIoTDDdTTNhBLTNqbzbIHHbimWPDyuVsGgQhoxqxyTPxomUflRw");

    for (int ZPfvFaNw = 459570530; ZPfvFaNw > 0; ZPfvFaNw--) {
        FtbGOHM = FtbGOHM;
        JmiYy = ItFdgJdlhIaIHXn;
        JmiYy -= ItFdgJdlhIaIHXn;
        JmiYy /= JmiYy;
    }

    if (UBrDUqzL == false) {
        for (int XLLliNSuxfPSX = 1990368227; XLLliNSuxfPSX > 0; XLLliNSuxfPSX--) {
            continue;
        }
    }

    if (ItFdgJdlhIaIHXn == 537935.6051380312) {
        for (int mUSgnO = 269639506; mUSgnO > 0; mUSgnO--) {
            continue;
        }
    }

    if (JmiYy >= 537935.6051380312) {
        for (int IpBQsE = 210352257; IpBQsE > 0; IpBQsE--) {
            JmiYy -= ItFdgJdlhIaIHXn;
        }
    }

    return 79729304;
}

void tMjoeOzrSDI::qpcNQbeZawrb(bool aoZPkfJ)
{
    bool jVYDISCjlGupiJZ = false;
    bool fMYTadCjgDd = false;
    bool UQvumRlueNCUgEns = false;
    bool EnWrJvoAKAhJIs = false;
    string ChsyaZ = string("KqBlXijhBnGRxEeZbcHeCQpRTydrlqbzPNgRXflWTYIpnYvJMwLFNyzsiWaAbBHiorhtMpBlwqmdWbfWuhruTwPTewbTfHnQdIkVTAdbyNMJuqEyTiYZOnaMhXUHaiRJyDYFuOIOEjHCVISDXSUOKkqNUElqECBWKiwXQxPoutxmCllawmpPLudZqsLBxQItbxAnPYzXAQFPZQVXjaqmFvdFgOTSiEFjuGGhLAtJwkLPK");
    bool ZXjZStC = false;
    int iHnufnGOHSeYD = 607213273;
    double xKtQmlqQL = -300950.10424392455;
}

int tMjoeOzrSDI::eGyFOzUUoiNCfSi(string EIpKf)
{
    double kQeqHOfgQHQDMz = 550200.7139837845;
    string OhERKArBMGAvFWwj = string("dsOhYTCdTaFpfNtgpJmosUfVNzqnLVLBfyfBpdARRKuxCDJxiWgPDQJlfRxhdqWpNFrOiqoLhhBXdtISfdbdlkvgbEijGqvAmFIrHowiGeDnjZMoBclpRdlBaeTvcXQkMTHAieHmpjwssRVgNywzRiwbOedTUBVfjNluYXuDWHyOldateRCzcEmxfuXxFtAgHidMByFxpenYLVWHRxqyqDUXjPYFuXSWAsxMTHLsHiMoZiHahHlpwieKyi");
    bool bVLDjJhkWV = true;
    int ukwVbHNqMnSePi = 1464793295;

    for (int ooaGMURDsLXYoeC = 158151702; ooaGMURDsLXYoeC > 0; ooaGMURDsLXYoeC--) {
        OhERKArBMGAvFWwj = EIpKf;
    }

    for (int OrFGrCAdsbEKzTR = 600109122; OrFGrCAdsbEKzTR > 0; OrFGrCAdsbEKzTR--) {
        bVLDjJhkWV = ! bVLDjJhkWV;
    }

    return ukwVbHNqMnSePi;
}

string tMjoeOzrSDI::KcjOR(double lZQXinDqSW)
{
    string Esrub = string("cMlWCiOjMAddphqlayOxjLjkNIfHvHnKNaXapBZSXikeywTniz");
    int wWavoOrwLXlcSx = -1004288132;
    double MskksaLveUkzGZkT = 999500.2291648706;

    for (int iDxItJemfSIDY = 1995522631; iDxItJemfSIDY > 0; iDxItJemfSIDY--) {
        continue;
    }

    for (int sHvJjfazScuIoaJb = 352615887; sHvJjfazScuIoaJb > 0; sHvJjfazScuIoaJb--) {
        wWavoOrwLXlcSx /= wWavoOrwLXlcSx;
        wWavoOrwLXlcSx -= wWavoOrwLXlcSx;
        Esrub += Esrub;
        lZQXinDqSW *= lZQXinDqSW;
    }

    if (MskksaLveUkzGZkT <= 999500.2291648706) {
        for (int tQiNboQPW = 1684844293; tQiNboQPW > 0; tQiNboQPW--) {
            continue;
        }
    }

    if (wWavoOrwLXlcSx >= -1004288132) {
        for (int vBPYmgbxFqIN = 114509381; vBPYmgbxFqIN > 0; vBPYmgbxFqIN--) {
            lZQXinDqSW -= MskksaLveUkzGZkT;
        }
    }

    return Esrub;
}

double tMjoeOzrSDI::WkzQWpHKNss(double ysOjfdzcMqrdbq, double GsImQQQvdtoAY, string mcSIKNCTyItxK, bool wthwKOmoWrBpCyy, bool CfkByblwurDGYn)
{
    string GnsVn = string("bEZlBiKDFRPwhmfnNbnZiIqIiixYoGjJmGjTXxXOlkeSCQf");
    double vHMEoEFGkNWhxQM = 202330.20462877903;
    int UDcrb = 1214913626;
    string WlRUzxM = string("lsowxuWNAcAunSfIrVyfTooGbqTciAdXKORJTTtbPCsoJnIGqYmqLhYsynsjcqimuGFAZNWjxDPpBqKbWsIHYAsKLYzrtecntpZrjITooaSAWPDdMrTAeUxqMVWIPMddelZumsiSIVnliDigmsKHWrKfZVaICcbYVKmITJpetuwzWUlTUKTFMbUCSPJhfNuEBkpIKFSUuhmgSKqzyyroFdyCxOpIGN");
    double yNEEQvnevKIf = -102642.31769875558;
    bool KMGPv = false;
    double ZcymMjuStP = -474246.63448440045;
    double IFhhDBwldy = 573947.078893198;

    for (int wedQlqPl = 723867335; wedQlqPl > 0; wedQlqPl--) {
        IFhhDBwldy = ysOjfdzcMqrdbq;
        ysOjfdzcMqrdbq -= ysOjfdzcMqrdbq;
        vHMEoEFGkNWhxQM += ZcymMjuStP;
    }

    if (vHMEoEFGkNWhxQM < 441946.1024486084) {
        for (int NpQnxNuC = 160095649; NpQnxNuC > 0; NpQnxNuC--) {
            continue;
        }
    }

    return IFhhDBwldy;
}

void tMjoeOzrSDI::CZmYhiujGibnrQ(double gNeyg, double XOxBXY, bool RQmmPn, double JblTABU, double JNUbCciA)
{
    bool sWfHuhFmwAognCgP = false;
    double iQftTQuIGbkGk = 248262.89827065408;
    bool WrrSK = true;
    string wwgkfQFw = string("vRFzXzafJBushrjxeanhHvVWhWYjEAYXJlWNfizTeeFbhYYNaHuFFtGAjTbMnqkLLFIFqzbSfIdaJVnINpVNBhOPMlqfEkGIYDpYyLHNcIIrFvmBxJtbrwUjsgMWnYeUwTXwhpVqOWkaoYjtvZZEyNBieJWGnVZvwqQBN");
    string UjMSiZL = string("viSmCmOjXWafDemjfhHdTFjghRAVwrJipYBUwCvUxvKdrKSjyFfezazKSTiBgSxAXbFgtsoydAaqWkDEuNImWXklZahKKVxOdrmDKuEnwlSnirAriJFvOXxSSnwZNRxHflCj");
}

bool tMjoeOzrSDI::hPSMWuAPGF(bool NaiafPaw, int QlGocLTyPfq)
{
    string jVZtmzZtiomTyFMK = string("lRYOpqmIwcZgQLDqfFkiHPFFSQfvfkBdXvhQdAoCppzoHZVgEqH");
    int QNUNtytbKODxA = 454289699;
    string OspMk = string("yqyRvJeRKAZzGZUcCnwmlfOaJRqTtDSdPcTfZBgpOHxctfSXoqdSclMwIZoGhQFapUOOEpEuNsLxzjRJvcOwizfVqLSpPOUphqtcaDdspxbtGwrNNYscfbLzviuqYK");

    for (int PVgEmeheHQnE = 2030899095; PVgEmeheHQnE > 0; PVgEmeheHQnE--) {
        continue;
    }

    return NaiafPaw;
}

int tMjoeOzrSDI::nhWMmilAvLXHIKY(bool IMcQNTPwECzr)
{
    int nWoiNfSgcfYzjIb = 1310641757;
    string VsdyHtrp = string("RhyteWABHrARSgAbEAGzrssRaYlHDAWhHzwldXMxyolrPZDLYbvkhiqsRFjDcFzAHvLXDoLPnbaNxdNOdYIZrXQvfQthBJP");
    int HNZJHVVSiqF = 529001454;
    int GhqhpAWmyVVxwEvx = 1787099221;
    int wFLbiWbqdh = 71526720;
    string cfaiHSxKUFvf = string("JfKFekUXWxoHTodwbZcmYFmAaTwAeMbdpNrOsmOJhTfYNamwQBDzzgOPEDukXdLILlrfIEWKwGWCmEXPokohvysmhiVTfsZNNdvYssTirDmTxEzxdSQnvPJbAYtbdsvybUfvykXHyWbVzYpquZgqkRu");
    int JUAsSQEiYVxPvX = 802358905;
    bool WsEQDdHBKyHTxAo = true;
    string iRNYxFFbofqdbPeJ = string("UwVPcJWFnOievxvwmWcMrqIWzxUlPUwuhiHiVaPajjgvtkywPwjTNyuspvsOUTebBzRNLgLAgEVeVRLwctHppNlaQngWLWGcSJGnfOveyPqIJPklPTJsvOlNiMGGsWBYiGSCQuxACmcNLXnCGlJpDeyZSXBgcDzRqDCZLxCJMkYHrIgOTkVEKtTpLlEiPJNCFXruzKEffSDMZRLakiyCKVKfCuBFGnUKDmYDkMHJGwpJlkEPYwPxQJLRI");
    int FiZdYYXjr = 121581686;

    if (HNZJHVVSiqF <= 802358905) {
        for (int zmIAUQaZqu = 1973315727; zmIAUQaZqu > 0; zmIAUQaZqu--) {
            IMcQNTPwECzr = ! IMcQNTPwECzr;
            HNZJHVVSiqF /= HNZJHVVSiqF;
            iRNYxFFbofqdbPeJ += iRNYxFFbofqdbPeJ;
            FiZdYYXjr -= wFLbiWbqdh;
        }
    }

    for (int ozERdgKxBeOPEs = 1567381391; ozERdgKxBeOPEs > 0; ozERdgKxBeOPEs--) {
        HNZJHVVSiqF /= GhqhpAWmyVVxwEvx;
        JUAsSQEiYVxPvX /= nWoiNfSgcfYzjIb;
        wFLbiWbqdh += GhqhpAWmyVVxwEvx;
    }

    return FiZdYYXjr;
}

tMjoeOzrSDI::tMjoeOzrSDI()
{
    this->rNoiffKfBKJL();
    this->DufguoYCBf(-506794.50323344796, -1804766908, string("yKdnRzQnHLwNnfZkDTmGkZmlbEBtLaYmQMPHWqSLcRnEbIgJArTwmFCKNCPXVqOILxsavHDAkFVsWweGttWkXkglELjQxQWDuUPuqUxG"), true);
    this->HJmTvNVgbsi(string("mcElDcXEHNbSxyVZigmoWikTegahvLoyWZIJFjbaUVTdtRgFddRdCJJRahdoOUHAdTEOZLZelkgdLgvggvaBeeOWFhMYuEDCSbkYtjEmnNPQqaKaRDBoocGWnq"), 396026.40180333727);
    this->QNgDAoe(string("xiJWUiZuzDbIapcgsnvvMxjRHFJlEujJTrwLWmPewoNskgUtFBLgJJheBYllPsXgNzniJjLZVwSASqheUHatVmOMIZQyBcPEQqiD"), 1030627.613823195, 687739.8441026496, -702768.297948083, -530571536);
    this->slQPDPacpcSFScMz(true, false, true, -12573635);
    this->HkgJwjwZJMwY();
    this->oLAEmLUAw(2065112406, -1374846371, string("cJDQjjMtQiYVURkJLmxVurGgdVrQYinMoOmoIBHvPnTgVwipYxPYyQjPCEwToZjYkrSavUePFEjgdsWXzbDcpWmpRlbyAsehyGdrequyRL"), false, true);
    this->sIKXvPoJgU(804274.3113938667);
    this->qpcNQbeZawrb(false);
    this->eGyFOzUUoiNCfSi(string("rEtnXGrEbpevZhaJxKRIhDiLDkhwTRDacoRSwsKsKFfESFQOtObYvWigQjWnJKEmMQJwwuMCJZTIJyWxubuJBMMYOZTvcisskRialnVBJpOWeOngIipTlvsMMbjLffGxejxzMgjrbvPVsyaixMLfVAcMHerXmhsnGEiTsOqiAp"));
    this->KcjOR(177721.57473678692);
    this->WkzQWpHKNss(441946.1024486084, 301759.192594222, string("gKoaLQqiXKAbVRbgmUQGjvmMnwHWnzmImTvradlCqPNyCukaIfrmRLJDorKdCbGywVIiDQjhStxqSrxEUSYSxvFYVpKrJwjmMWyNTDkSOhgvHhISoDApdTMAcPKEmGXvEBCvVOAIRcyPPKSSZqSDmWcBYPBKxCQySTYanhFZGKle"), false, false);
    this->CZmYhiujGibnrQ(658754.0725102153, 311631.3639148507, true, 615773.1754096594, -694093.9767100848);
    this->hPSMWuAPGF(true, 1578378085);
    this->nhWMmilAvLXHIKY(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Cxcyy
{
public:
    int PyEmNj;
    bool MAjsNzGqZmBoi;
    bool mzSIeLxvQygoFERj;

    Cxcyy();
    bool bMNIWZOexTkJIsar(string aeDMUkAWbHz, double OFTFe, bool rvYmpta, int KRPVoYYsebIeC);
    void gweKayhlVS();
    int SoNGgjz(int IIFBRI);
protected:
    bool YkUkJJVEamHQ;
    string JVIWTAXWYNaeM;
    int AmuNFfjsn;

    void eUwYm();
    bool oGChSuRZbUrmJNbD(bool jHtKjrScYfZaPI, string lAlsaWOFyvXYimfL, string hlrfXifLy);
    string QmItEHtZpz(int bGkxHrtCzSALRy, int DcAZclpNfu, double vjYcaETB, string XMJtfB);
    double BziACl(int xuULwPMRNKrP, int kzWahBt, string MOThZUj, bool fGlpuFSkmqzItQ, int natdMHmXhQc);
    double xjUIYAFfRUySFML(double rMPnNBb, double QpRAiIkT, bool NCRFgo, double GgeFRcZ);
    int JEEyNCpo(double AQEnpUxXOhlyYf, double OPAwwI);
    string QiVrCVYo(int EjvUxI, int FuPfg);
    void mhLLcTeZvDqqXU(int fpHpxI, int kKnlx, int yyjDPdRwyOlThV, string xJAHuppT);
private:
    int QCbyR;

    string DkhmCgsoXpRNi(int mgmGTGGyoDvc, string vpxBMAZtm, int SspUOR, bool YuWJoSuTrRKeg, double RMxvXZuzSnS);
    bool SJlel(int UrjdC, int sGdhWtfSi, bool fgysFrqQFqrxPRKG);
};

bool Cxcyy::bMNIWZOexTkJIsar(string aeDMUkAWbHz, double OFTFe, bool rvYmpta, int KRPVoYYsebIeC)
{
    double BpchoBqRz = 827673.5919105157;

    if (OFTFe == 827673.5919105157) {
        for (int iUwIkKqRrkbUEt = 1165791214; iUwIkKqRrkbUEt > 0; iUwIkKqRrkbUEt--) {
            continue;
        }
    }

    for (int lkXvoHOUrxPYBG = 858087321; lkXvoHOUrxPYBG > 0; lkXvoHOUrxPYBG--) {
        continue;
    }

    for (int HTvUmB = 367163167; HTvUmB > 0; HTvUmB--) {
        OFTFe /= OFTFe;
        OFTFe *= OFTFe;
        KRPVoYYsebIeC = KRPVoYYsebIeC;
    }

    for (int JIwoMk = 1451183239; JIwoMk > 0; JIwoMk--) {
        continue;
    }

    return rvYmpta;
}

void Cxcyy::gweKayhlVS()
{
    bool vbYkcfAG = true;
    bool vgTEmeyxvE = false;
    string LdzJgxX = string("koAKBlECfYTyOpjqKHspAPGIKwaZoLPqeybPlbRCasYZrEaSAYIVxQtVKrjuzH");
    int rWZKcHJMUBu = 432934067;
}

int Cxcyy::SoNGgjz(int IIFBRI)
{
    double qmIbPh = 221889.64805782007;

    for (int CnfOHkiK = 2136431324; CnfOHkiK > 0; CnfOHkiK--) {
        IIFBRI /= IIFBRI;
    }

    if (qmIbPh < 221889.64805782007) {
        for (int rpnEa = 1015535160; rpnEa > 0; rpnEa--) {
            IIFBRI /= IIFBRI;
        }
    }

    return IIFBRI;
}

void Cxcyy::eUwYm()
{
    bool TTSDuSwd = true;
    string GRzkCOb = string("fabeqqYcdmmnFgXjKpBSJijDVfxOmVrZAogsHgMmUvItRYCofcPkMnPhkDcqCkiYarXZOdPHOInEzURDLVzImiAXcEaH");
    double syRgYWMcJMCQPS = -101730.8763198101;
    string uHTlgWeEEl = string("fBUpHeYpgyPbWVTYbkaYdXXRfwVceGuEkGbPcDNEMzdWizvArFAjMQgzNCHneSfbXMfRmYlDreYwKBIByvkFiYzQLCihoIKYPUrkPxbYBzslPkWAMvwzhPjeCpUuxmjLugKKNlMMWIAjCdOowmdXteTcgTbSeBOASNbixNQVrvgSkkfGliuSJIGJkACTI");
    bool evpEHUmnXWYH = false;
    string zguPBCCVL = string("sLCVUWUsPZAanGGXxjEGGuUYQMUQSzGzDLgoTsPazktVAUjSFyybtxcREtZvLkZrhzgavPWYYrJIbBHEpCSfFEieUQpMJGPFMCIHlWLEQEcrVQkPXagFjcePhsTWJdafkASJveIc");

    if (GRzkCOb > string("sLCVUWUsPZAanGGXxjEGGuUYQMUQSzGzDLgoTsPazktVAUjSFyybtxcREtZvLkZrhzgavPWYYrJIbBHEpCSfFEieUQpMJGPFMCIHlWLEQEcrVQkPXagFjcePhsTWJdafkASJveIc")) {
        for (int qahTIwV = 1643019819; qahTIwV > 0; qahTIwV--) {
            GRzkCOb += zguPBCCVL;
            syRgYWMcJMCQPS += syRgYWMcJMCQPS;
        }
    }

    if (GRzkCOb > string("fBUpHeYpgyPbWVTYbkaYdXXRfwVceGuEkGbPcDNEMzdWizvArFAjMQgzNCHneSfbXMfRmYlDreYwKBIByvkFiYzQLCihoIKYPUrkPxbYBzslPkWAMvwzhPjeCpUuxmjLugKKNlMMWIAjCdOowmdXteTcgTbSeBOASNbixNQVrvgSkkfGliuSJIGJkACTI")) {
        for (int gWLZPNWPKwovAau = 674605817; gWLZPNWPKwovAau > 0; gWLZPNWPKwovAau--) {
            uHTlgWeEEl += zguPBCCVL;
            GRzkCOb = uHTlgWeEEl;
            GRzkCOb = uHTlgWeEEl;
        }
    }
}

bool Cxcyy::oGChSuRZbUrmJNbD(bool jHtKjrScYfZaPI, string lAlsaWOFyvXYimfL, string hlrfXifLy)
{
    string zAGHKANXercAZtu = string("NAgpmJSJsDhIwjxiOrPveswz");

    if (hlrfXifLy >= string("jhCapDaGrRMDfiZyexjDLKcddmNZMzbvUyIqVuxqhqHZSHTCCyCyuGQyBhBpddXAifkTreRgpaokFrKqjYKMfivSmrmfjCSJZiIQBEBdwTEEYYLiOXbuxAvgsHPlptwkCgsIOGDhgQTeJrmuNEzEEiuLpdSDkjsSHjGHLXgXQRbA")) {
        for (int nQryIuIkmfiuWI = 676326614; nQryIuIkmfiuWI > 0; nQryIuIkmfiuWI--) {
            hlrfXifLy += lAlsaWOFyvXYimfL;
            zAGHKANXercAZtu = lAlsaWOFyvXYimfL;
            zAGHKANXercAZtu = lAlsaWOFyvXYimfL;
        }
    }

    for (int LxZVU = 1371796531; LxZVU > 0; LxZVU--) {
        hlrfXifLy += hlrfXifLy;
        lAlsaWOFyvXYimfL = zAGHKANXercAZtu;
        lAlsaWOFyvXYimfL += hlrfXifLy;
        lAlsaWOFyvXYimfL = hlrfXifLy;
        zAGHKANXercAZtu += hlrfXifLy;
        lAlsaWOFyvXYimfL = hlrfXifLy;
        hlrfXifLy = lAlsaWOFyvXYimfL;
    }

    for (int ZXrrxRD = 1679348295; ZXrrxRD > 0; ZXrrxRD--) {
        lAlsaWOFyvXYimfL += zAGHKANXercAZtu;
        lAlsaWOFyvXYimfL = hlrfXifLy;
        zAGHKANXercAZtu = zAGHKANXercAZtu;
    }

    if (hlrfXifLy >= string("RgickDuTdYeVziTIBGSnhxwUPrWVfBBLZjIGZMmNnCdSYBbazYTKYDxLRvzBdmWklCVFzJfuTtsniPQAWcWeSykFTIxqOSxEVpiLvYDqDUmcGzgtlQZwlmkMzeVKZGaoXVrvAUZsuiIOhURQQeYYVENtpemHWPdbHXacvpufPYWFWuzVtZuQoWrkmaELBnLUTwYgErERsKVxQiscCYVkICVeJvbDWWhnXMWmHaRiXqwpsOOhpzOPB")) {
        for (int OXFlbh = 848486160; OXFlbh > 0; OXFlbh--) {
            zAGHKANXercAZtu += hlrfXifLy;
        }
    }

    if (zAGHKANXercAZtu > string("RgickDuTdYeVziTIBGSnhxwUPrWVfBBLZjIGZMmNnCdSYBbazYTKYDxLRvzBdmWklCVFzJfuTtsniPQAWcWeSykFTIxqOSxEVpiLvYDqDUmcGzgtlQZwlmkMzeVKZGaoXVrvAUZsuiIOhURQQeYYVENtpemHWPdbHXacvpufPYWFWuzVtZuQoWrkmaELBnLUTwYgErERsKVxQiscCYVkICVeJvbDWWhnXMWmHaRiXqwpsOOhpzOPB")) {
        for (int YaWXSpKfgXgFhdK = 1047045909; YaWXSpKfgXgFhdK > 0; YaWXSpKfgXgFhdK--) {
            hlrfXifLy += lAlsaWOFyvXYimfL;
            zAGHKANXercAZtu += zAGHKANXercAZtu;
            hlrfXifLy += zAGHKANXercAZtu;
        }
    }

    if (hlrfXifLy <= string("RgickDuTdYeVziTIBGSnhxwUPrWVfBBLZjIGZMmNnCdSYBbazYTKYDxLRvzBdmWklCVFzJfuTtsniPQAWcWeSykFTIxqOSxEVpiLvYDqDUmcGzgtlQZwlmkMzeVKZGaoXVrvAUZsuiIOhURQQeYYVENtpemHWPdbHXacvpufPYWFWuzVtZuQoWrkmaELBnLUTwYgErERsKVxQiscCYVkICVeJvbDWWhnXMWmHaRiXqwpsOOhpzOPB")) {
        for (int rtelX = 603741681; rtelX > 0; rtelX--) {
            jHtKjrScYfZaPI = jHtKjrScYfZaPI;
        }
    }

    return jHtKjrScYfZaPI;
}

string Cxcyy::QmItEHtZpz(int bGkxHrtCzSALRy, int DcAZclpNfu, double vjYcaETB, string XMJtfB)
{
    string RqLzHMOrjCKT = string("lLWWDg");

    for (int WkFcCsnFusjwxnU = 216339460; WkFcCsnFusjwxnU > 0; WkFcCsnFusjwxnU--) {
        continue;
    }

    for (int wuZhKNDMZcbfiJ = 1870796589; wuZhKNDMZcbfiJ > 0; wuZhKNDMZcbfiJ--) {
        XMJtfB = XMJtfB;
        bGkxHrtCzSALRy -= DcAZclpNfu;
    }

    return RqLzHMOrjCKT;
}

double Cxcyy::BziACl(int xuULwPMRNKrP, int kzWahBt, string MOThZUj, bool fGlpuFSkmqzItQ, int natdMHmXhQc)
{
    bool BuWJLmMzz = true;
    double JItkVEKSQEtbi = -233297.32873395138;
    int poupOaKyZsCWHecf = -1303879489;
    double kxttDKdTDy = 64280.77402000224;
    string vmDbYGmBhwlEireD = string("KBDNvmyiebbJITscRYXXTkwJ");
    int ZYzxWaOn = -936683508;
    int KQiQUZAQ = 1475048904;
    int CLJIwGWtHyCjnX = 1917496469;
    string brLNYonbhYZG = string("urufrInxFoCjHOriuEsmAvuaKtuCxhFwzGKUONYSGcEvTUPhiojXGgZbXIwbmZzovzyaxV");

    for (int EcVPKQbW = 853331137; EcVPKQbW > 0; EcVPKQbW--) {
        xuULwPMRNKrP += KQiQUZAQ;
        kzWahBt *= KQiQUZAQ;
    }

    for (int gkItqBqpVNavw = 1761477233; gkItqBqpVNavw > 0; gkItqBqpVNavw--) {
        ZYzxWaOn *= KQiQUZAQ;
        CLJIwGWtHyCjnX -= ZYzxWaOn;
        kzWahBt = KQiQUZAQ;
        kzWahBt = natdMHmXhQc;
        kzWahBt = CLJIwGWtHyCjnX;
    }

    if (KQiQUZAQ < -356939610) {
        for (int dMCfMIbz = 1865842666; dMCfMIbz > 0; dMCfMIbz--) {
            natdMHmXhQc += kzWahBt;
            ZYzxWaOn /= CLJIwGWtHyCjnX;
        }
    }

    return kxttDKdTDy;
}

double Cxcyy::xjUIYAFfRUySFML(double rMPnNBb, double QpRAiIkT, bool NCRFgo, double GgeFRcZ)
{
    bool rnMuJMgrVOkHDM = true;
    double ClaYdCgtARKiEtq = -77273.6085368061;

    for (int tVbjtXOMoFQ = 1244445923; tVbjtXOMoFQ > 0; tVbjtXOMoFQ--) {
        ClaYdCgtARKiEtq *= ClaYdCgtARKiEtq;
        QpRAiIkT /= rMPnNBb;
    }

    if (rMPnNBb >= 711145.539993778) {
        for (int FzPVRjaFI = 767706573; FzPVRjaFI > 0; FzPVRjaFI--) {
            QpRAiIkT /= rMPnNBb;
            ClaYdCgtARKiEtq += GgeFRcZ;
            ClaYdCgtARKiEtq = ClaYdCgtARKiEtq;
            GgeFRcZ /= QpRAiIkT;
        }
    }

    return ClaYdCgtARKiEtq;
}

int Cxcyy::JEEyNCpo(double AQEnpUxXOhlyYf, double OPAwwI)
{
    string fdHFAUHSDftd = string("zdgkOtUYUmCZbhlPH");
    bool CTwozcFNtq = true;
    string hsDLeINDPpAwbX = string("RnIzvVlmhlvegGsEgZbgQzoYpPxcPOhrZfbmhkvZKGCzKJaRDuSlBSEfBSemEqVttwZgKZgIbVATheLCGQEjABKUxlUmcSVKjLeulJNdOXpfDCWhJRBFDuICaQaoDjldHNOWiWLEWPpEeGxRvXZdxOuMziXqftqswPwljOYOcsWApZhtwtowYJQHOBVZxHLIhjrSpdzlCW");

    if (hsDLeINDPpAwbX > string("RnIzvVlmhlvegGsEgZbgQzoYpPxcPOhrZfbmhkvZKGCzKJaRDuSlBSEfBSemEqVttwZgKZgIbVATheLCGQEjABKUxlUmcSVKjLeulJNdOXpfDCWhJRBFDuICaQaoDjldHNOWiWLEWPpEeGxRvXZdxOuMziXqftqswPwljOYOcsWApZhtwtowYJQHOBVZxHLIhjrSpdzlCW")) {
        for (int MbKQBlJUp = 1044614769; MbKQBlJUp > 0; MbKQBlJUp--) {
            CTwozcFNtq = CTwozcFNtq;
            fdHFAUHSDftd += fdHFAUHSDftd;
            hsDLeINDPpAwbX += fdHFAUHSDftd;
            hsDLeINDPpAwbX += fdHFAUHSDftd;
        }
    }

    return 837010935;
}

string Cxcyy::QiVrCVYo(int EjvUxI, int FuPfg)
{
    string bLBxvY = string("kmDvZBlkbjgYudCLnnvtjBLINgTbhomgofBPuTvWUQMrkIKbBrlKIMRblPhVZMHqSRcoDbDzqNpwzrCSuJdJmEeqUaebmnHNeaXMTnSxNWaPhoGWLHiLSPHmPCOvaqNyMQSrPDFmvVlDQdjCVvEaQAiYAdwzdjSaoQGCaeSfoeyOGKYQkoGHBpiXjIyWSDctrAIrTSdDXGTysVFKcErVXfhsBCXLOinjSFAvoDG");

    for (int sgfKkVBFFiiG = 1038283147; sgfKkVBFFiiG > 0; sgfKkVBFFiiG--) {
        bLBxvY = bLBxvY;
        EjvUxI /= EjvUxI;
        FuPfg /= EjvUxI;
        EjvUxI /= EjvUxI;
    }

    for (int GdBtmC = 1972727432; GdBtmC > 0; GdBtmC--) {
        FuPfg += FuPfg;
        FuPfg *= FuPfg;
        FuPfg -= FuPfg;
    }

    for (int wRmOTDHGcubw = 1657767913; wRmOTDHGcubw > 0; wRmOTDHGcubw--) {
        EjvUxI /= EjvUxI;
        FuPfg += FuPfg;
    }

    if (bLBxvY == string("kmDvZBlkbjgYudCLnnvtjBLINgTbhomgofBPuTvWUQMrkIKbBrlKIMRblPhVZMHqSRcoDbDzqNpwzrCSuJdJmEeqUaebmnHNeaXMTnSxNWaPhoGWLHiLSPHmPCOvaqNyMQSrPDFmvVlDQdjCVvEaQAiYAdwzdjSaoQGCaeSfoeyOGKYQkoGHBpiXjIyWSDctrAIrTSdDXGTysVFKcErVXfhsBCXLOinjSFAvoDG")) {
        for (int IUXKcBuch = 1344298021; IUXKcBuch > 0; IUXKcBuch--) {
            bLBxvY = bLBxvY;
            bLBxvY += bLBxvY;
        }
    }

    if (EjvUxI <= 2046652307) {
        for (int UYWOYyvgC = 1715759052; UYWOYyvgC > 0; UYWOYyvgC--) {
            continue;
        }
    }

    return bLBxvY;
}

void Cxcyy::mhLLcTeZvDqqXU(int fpHpxI, int kKnlx, int yyjDPdRwyOlThV, string xJAHuppT)
{
    string YbxRAGWkR = string("HsfaLRgkmhwHUeajPHJklvHgdHicJSeQRHHSHAYywFsrpxuCKMmkWTarVWEDBAJXWCgraoqWRSmXlDSeZAWeupMxnwqicFhMRlEgfddcSWQFjNrAiLbtqOAlFpSUVurjgPnYRWkeRWQRQiEpYGZkFFKwhpWomQNmQtAbHudTPkxPPjnsjHgkSpfhhDxuxbIhiujWJjHjxPRELkfvJftBEBXZBjgwGigxjiJqBffRtR");
    bool AGmfiIRolqyb = true;
    double gKVHbbM = -465289.66413017455;
}

string Cxcyy::DkhmCgsoXpRNi(int mgmGTGGyoDvc, string vpxBMAZtm, int SspUOR, bool YuWJoSuTrRKeg, double RMxvXZuzSnS)
{
    bool QTFeFXZNmlp = false;

    for (int ZAult = 1728725903; ZAult > 0; ZAult--) {
        QTFeFXZNmlp = YuWJoSuTrRKeg;
        SspUOR /= SspUOR;
        YuWJoSuTrRKeg = YuWJoSuTrRKeg;
        YuWJoSuTrRKeg = ! YuWJoSuTrRKeg;
    }

    if (YuWJoSuTrRKeg != false) {
        for (int QuGjz = 138468259; QuGjz > 0; QuGjz--) {
            vpxBMAZtm = vpxBMAZtm;
            SspUOR *= mgmGTGGyoDvc;
            vpxBMAZtm += vpxBMAZtm;
        }
    }

    for (int AMBxhahStA = 2011467954; AMBxhahStA > 0; AMBxhahStA--) {
        QTFeFXZNmlp = ! QTFeFXZNmlp;
        YuWJoSuTrRKeg = YuWJoSuTrRKeg;
        vpxBMAZtm += vpxBMAZtm;
        vpxBMAZtm = vpxBMAZtm;
        RMxvXZuzSnS /= RMxvXZuzSnS;
    }

    for (int exftwVhWV = 1239958163; exftwVhWV > 0; exftwVhWV--) {
        mgmGTGGyoDvc += SspUOR;
        QTFeFXZNmlp = YuWJoSuTrRKeg;
    }

    return vpxBMAZtm;
}

bool Cxcyy::SJlel(int UrjdC, int sGdhWtfSi, bool fgysFrqQFqrxPRKG)
{
    bool vdYxveQqI = true;
    int yqNeu = 1802272144;
    bool eRdQcowAJbAOADB = false;
    string omFbOGhDNnj = string("lPwbGLRRVJjkOQjwiZGSssLGzvSufsEfFCEFVtRygSiXjRDeEECBYNwixRtFCTPUymaMaPEkAUaSWoHTGenhkbYxAScNOfqUEEnXQIHlybwkyVERPBeKFyRSEzsbqHXhRWNADQFuTNrkoWlESWlfMlkpBTmnlIpITCvktPQsOE");
    bool XPZRJ = false;
    bool OxyqrzXZar = false;
    bool YArnJGwMpfUAhl = true;
    bool BRTtKTWK = false;
    double oGuQhHeyn = -562523.3244490032;

    if (BRTtKTWK == false) {
        for (int WIBCVTKhVfiM = 89103824; WIBCVTKhVfiM > 0; WIBCVTKhVfiM--) {
            XPZRJ = ! BRTtKTWK;
            vdYxveQqI = ! YArnJGwMpfUAhl;
            eRdQcowAJbAOADB = ! eRdQcowAJbAOADB;
        }
    }

    for (int dwzywMLTrfXjJxjW = 2084094699; dwzywMLTrfXjJxjW > 0; dwzywMLTrfXjJxjW--) {
        yqNeu = UrjdC;
        OxyqrzXZar = ! OxyqrzXZar;
        eRdQcowAJbAOADB = vdYxveQqI;
    }

    for (int RjmIF = 248597275; RjmIF > 0; RjmIF--) {
        continue;
    }

    for (int BgrxXXyxiHIbHDT = 1441316444; BgrxXXyxiHIbHDT > 0; BgrxXXyxiHIbHDT--) {
        continue;
    }

    return BRTtKTWK;
}

Cxcyy::Cxcyy()
{
    this->bMNIWZOexTkJIsar(string("CjrHrKRCMrPhloKRkUYjPwOqDMQLYdpXvyrnTvDcEfTbxroRMKwTQCwolsiWeAgnJTNifAnHcjgNpeUNtbOLMMnRTIjkrAWjcOrMqwsAGgsVSEMFzETefxLXMSQADUiYGBrxyiVMXsgAxYjeOguNlQzUbjKPPyFgIgiNxKODkcBpNGsrXnfWicltQYOJeESKLDukXyBHvykcwmnnXKTyljlhl"), -392524.4952941852, true, 1643309151);
    this->gweKayhlVS();
    this->SoNGgjz(1785283095);
    this->eUwYm();
    this->oGChSuRZbUrmJNbD(true, string("jhCapDaGrRMDfiZyexjDLKcddmNZMzbvUyIqVuxqhqHZSHTCCyCyuGQyBhBpddXAifkTreRgpaokFrKqjYKMfivSmrmfjCSJZiIQBEBdwTEEYYLiOXbuxAvgsHPlptwkCgsIOGDhgQTeJrmuNEzEEiuLpdSDkjsSHjGHLXgXQRbA"), string("RgickDuTdYeVziTIBGSnhxwUPrWVfBBLZjIGZMmNnCdSYBbazYTKYDxLRvzBdmWklCVFzJfuTtsniPQAWcWeSykFTIxqOSxEVpiLvYDqDUmcGzgtlQZwlmkMzeVKZGaoXVrvAUZsuiIOhURQQeYYVENtpemHWPdbHXacvpufPYWFWuzVtZuQoWrkmaELBnLUTwYgErERsKVxQiscCYVkICVeJvbDWWhnXMWmHaRiXqwpsOOhpzOPB"));
    this->QmItEHtZpz(-1990844616, -1610154365, 805806.0307975041, string("aTjUFDzfoWVRSwKgktCbDezCBnFTuhrodXTVjHfXKWPDVedPFUqWocGqQLZHxjmqEwbCGdQUZWjZgLhOaZGm"));
    this->BziACl(440816206, -1225539226, string("tcNxnJdUKgTEuFocxboOrJcWAcdWCUwjrwslDBKVToZojPBBzavhkprTfdnnRDIssClmGeVsIfXzyEREDenCqzuatbnWMkOjupVpDdgwTteIIWknC"), true, -356939610);
    this->xjUIYAFfRUySFML(906508.9833778514, -285558.6152820459, false, 711145.539993778);
    this->JEEyNCpo(349676.4301169473, 478096.9668152798);
    this->QiVrCVYo(2046652307, 494713071);
    this->mhLLcTeZvDqqXU(1465286281, 1299177390, 1491527495, string("xzdRssbGgleCbyDDlnzBuaDVjrmgViayLLGBmfnRtYYAfxVadiajGGucHVyNMclRvElbxjHsjtqhKwVItsfPJkTdtKRVZNCOHfEcOgRfIrCGBFZscGaSDBsuYvwFLhmEDSPdlVvCrJodgGGxtsIWr"));
    this->DkhmCgsoXpRNi(740769740, string("tHxbXUklSTNHlzoDvatcIfhYlMgz"), 1519924802, true, 922338.3892675138);
    this->SJlel(-1883447924, -1392287852, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SvsDLALbE
{
public:
    int UdNAZepSTviQYv;
    double lVIZxfPPcuSliVj;
    int BfFJYUCvZll;

    SvsDLALbE();
    bool JjzAgmHXaCKWb(string ZgLglO, string NnyINLbmwwc, bool vyASO, string gBZoDkhXkLeDnNHV);
    int XRSTqhHqxGnXUocr(bool tNIhuCrWshLa, int jdoowNr, int bVwDFvaAW, double NPbOKEz);
    bool LyWhdgKBX(double lsMeVQROpu, string VvcsUiGH, int sNdLw, bool xIZvNKV, double XSOkUyQ);
    void foCMicZ(double VlmZckEznoq, double qHBwjUxetpwt, double mrQqEewW);
    int LswsXIapW(bool ytfgawqBxFKai, bool qdwenypLWQL, int TObxhrXFeEAbXdjI);
    int xnmuluQ(bool kvnWLBhkY);
protected:
    double BEKtKCq;
    double rOKySBCnncMlHiuF;

    bool sOAfdiavyAhRRxY();
    bool ukPdtFxGLtJja();
    void FciJfKVdlp(int AywzkFEMfGIaAGjM, int jKICxOdivHg, int OwFrNVueoDP, bool xYcrVvPddZWKhFB, double uVNnA);
    double mVAGztewPdKqOB(int hFGtjuZPNPcpvmv, string qDWnYkyWwuUT, double XmMsYYzefNEu, double PSkuzDNTIzZTgh, bool KgiZjzUcPsNQpfh);
private:
    string OEigSONyvmnWFz;
    int OFAWtcbA;

    double XToVLpqElUNRf(double kiEDUUxAy, int rnZmBPu, string lrkQhBWJuW, double xlhvPsuZpyqpIY, bool dCUOGH);
    bool nSTInWxJQmrGpCV(double HGpeWVRGXAZxCvCM, int KuhvUmtfw, double iKdUftXu, bool nPqfj);
    int FYMMFV(bool glZnWfQNVzLBi);
    double EqrzIiWoeJAupK(bool lSSiNDOwsmZZkYa, int hjUhQYTGkJYGcwyn, int XupjIYp, int zNaFRuR, bool UHRhmHDCpoJfoGj);
    bool VnzLxzOtKUf(bool KWMJsHHKTRP, int cdieKLLDPBt);
    int dtmmXPTthOzob(string TWoYYPuCOBZAgpJ, double vjzFVVPtQn);
    string TbedlKGFKoeKkRxy();
};

bool SvsDLALbE::JjzAgmHXaCKWb(string ZgLglO, string NnyINLbmwwc, bool vyASO, string gBZoDkhXkLeDnNHV)
{
    double dKwgZRxH = -1041453.5447903478;
    int QaSGBiNriKN = 1201094448;
    int MYRrOGUzWUKa = 2032042175;
    bool IhluZvKDhNDjxxr = false;
    bool UNtIPibul = false;
    int YrJxCQ = 294951858;
    string ovVrrZFSyPFMTO = string("AVF");
    string uMxwQIjYOpsHMNft = string("LTbOlAXVHAeYhHwIMSxgTYSdPtuvQRDfKUBdmmkXxgApfeZgjWqdvuFFjwrZcDgNbxbJbJRzfbPJBmzmcVCNiDOWWzv");
    bool QCaywy = true;

    for (int fEyYupYTiJ = 2029378460; fEyYupYTiJ > 0; fEyYupYTiJ--) {
        ZgLglO += NnyINLbmwwc;
        UNtIPibul = ! vyASO;
        dKwgZRxH *= dKwgZRxH;
        uMxwQIjYOpsHMNft += ovVrrZFSyPFMTO;
    }

    return QCaywy;
}

int SvsDLALbE::XRSTqhHqxGnXUocr(bool tNIhuCrWshLa, int jdoowNr, int bVwDFvaAW, double NPbOKEz)
{
    int myzoQFFYvAML = -39194305;
    string UpaQObTERSokODzn = string("HhyjOeeOtUZknuViokYjJdVNhRugzEmizmpskkwQqjdkXNAXLqFLxALaeAvunUQxTqcjeXOeLIIwDhLZpGORieajquX");
    bool xhiEOROyOa = true;
    int tzdJTshkOOjp = -1339840292;
    bool WlOyknJCmvGMFo = false;
    string ROJpF = string("ZIXYJlPBYPgjkBJdTRJLirrwSEfFsXbyhkjISFWiijdEZLFCsTVxOuJAFpoKdIAtPTOaPqRtGRcYXJTRikCixBHChaEFjQvAAGyejLJqMoPrMEvFVkxnUWZFsMrXZbYpXyUfAODVAPrZQPVCrvBliHDJLFzkCBqbDIzFoR");
    bool CJItmseBmNzozu = true;
    bool LzgUOgYv = false;
    double WiVpnEtt = -926760.6413461161;

    for (int EUiUG = 777820936; EUiUG > 0; EUiUG--) {
        jdoowNr = jdoowNr;
    }

    if (WlOyknJCmvGMFo == true) {
        for (int XOrUUXkGT = 1632653872; XOrUUXkGT > 0; XOrUUXkGT--) {
            LzgUOgYv = ! xhiEOROyOa;
        }
    }

    for (int feOCODYKMtWN = 2060050068; feOCODYKMtWN > 0; feOCODYKMtWN--) {
        continue;
    }

    return tzdJTshkOOjp;
}

bool SvsDLALbE::LyWhdgKBX(double lsMeVQROpu, string VvcsUiGH, int sNdLw, bool xIZvNKV, double XSOkUyQ)
{
    bool EmhMcwZRImu = true;
    bool nQwWp = true;

    for (int DEnFQg = 1482855857; DEnFQg > 0; DEnFQg--) {
        lsMeVQROpu = lsMeVQROpu;
        lsMeVQROpu = XSOkUyQ;
    }

    for (int mbOxDxei = 835762862; mbOxDxei > 0; mbOxDxei--) {
        VvcsUiGH += VvcsUiGH;
        XSOkUyQ *= XSOkUyQ;
        VvcsUiGH = VvcsUiGH;
        nQwWp = ! nQwWp;
        xIZvNKV = ! xIZvNKV;
    }

    return nQwWp;
}

void SvsDLALbE::foCMicZ(double VlmZckEznoq, double qHBwjUxetpwt, double mrQqEewW)
{
    double fEuznATqurKeg = 236895.43135723675;

    if (mrQqEewW != -32556.141711894415) {
        for (int afPqlfcN = 204982360; afPqlfcN > 0; afPqlfcN--) {
            VlmZckEznoq *= mrQqEewW;
            VlmZckEznoq += mrQqEewW;
        }
    }
}

int SvsDLALbE::LswsXIapW(bool ytfgawqBxFKai, bool qdwenypLWQL, int TObxhrXFeEAbXdjI)
{
    int UnRaIhLMm = 989316084;
    bool ToxwadhxvDaTZ = true;
    int IeVxDjT = 388414292;
    bool LBMQJQlECMgzbcwQ = false;
    int MnyEIgWDnrn = -1203307545;
    bool IFKeX = true;
    string qMDrzYAik = string("VfqUIXuhXliRNBZObeJeMEFVziTnvFVcBSDbOCmDpVHlgCxKDTetugsrpNhpAFMWisDjKTRTeuJBQuLmOKQxfpq");
    double KxdDpZKNZJBc = -207565.65883201952;

    if (qdwenypLWQL == true) {
        for (int IwMZMPGDnHNnioQQ = 1733213221; IwMZMPGDnHNnioQQ > 0; IwMZMPGDnHNnioQQ--) {
            LBMQJQlECMgzbcwQ = ! LBMQJQlECMgzbcwQ;
            MnyEIgWDnrn /= TObxhrXFeEAbXdjI;
            ToxwadhxvDaTZ = ! IFKeX;
            ToxwadhxvDaTZ = LBMQJQlECMgzbcwQ;
        }
    }

    if (ytfgawqBxFKai == false) {
        for (int EjQqMxlFZYNA = 626928725; EjQqMxlFZYNA > 0; EjQqMxlFZYNA--) {
            continue;
        }
    }

    for (int NUAJSuEFMmYPmzA = 1200753490; NUAJSuEFMmYPmzA > 0; NUAJSuEFMmYPmzA--) {
        LBMQJQlECMgzbcwQ = ytfgawqBxFKai;
        ToxwadhxvDaTZ = ! ToxwadhxvDaTZ;
        IeVxDjT = TObxhrXFeEAbXdjI;
    }

    for (int uedSoZIbkZbZzDog = 1369113255; uedSoZIbkZbZzDog > 0; uedSoZIbkZbZzDog--) {
        TObxhrXFeEAbXdjI = MnyEIgWDnrn;
        LBMQJQlECMgzbcwQ = ytfgawqBxFKai;
        IeVxDjT += TObxhrXFeEAbXdjI;
        ytfgawqBxFKai = ytfgawqBxFKai;
        IeVxDjT /= TObxhrXFeEAbXdjI;
    }

    if (qdwenypLWQL == true) {
        for (int pjJQIUEzX = 189025669; pjJQIUEzX > 0; pjJQIUEzX--) {
            IeVxDjT -= TObxhrXFeEAbXdjI;
            UnRaIhLMm /= TObxhrXFeEAbXdjI;
            IFKeX = qdwenypLWQL;
            LBMQJQlECMgzbcwQ = ! IFKeX;
            TObxhrXFeEAbXdjI *= IeVxDjT;
        }
    }

    for (int KLotnBplBHSGAy = 1927168686; KLotnBplBHSGAy > 0; KLotnBplBHSGAy--) {
        qdwenypLWQL = ! ToxwadhxvDaTZ;
        ytfgawqBxFKai = qdwenypLWQL;
    }

    if (qdwenypLWQL != true) {
        for (int sszHPA = 1200125970; sszHPA > 0; sszHPA--) {
            IFKeX = ! qdwenypLWQL;
            MnyEIgWDnrn = UnRaIhLMm;
            IFKeX = ytfgawqBxFKai;
        }
    }

    return MnyEIgWDnrn;
}

int SvsDLALbE::xnmuluQ(bool kvnWLBhkY)
{
    string xGxNSkKKsSK = string("TDDHXAspZJxibFMEiZNRKquHEmQgSKMqRAGzEKoJopYocAkvKTkulejGBqIYThwGZLDeiKfWthUKlAhKFyLrkXTzBGqZuPKrWbYFKQpdFMCvoagGobPpErIPuoOkLckpNpgnTiZQkwawaBu");
    int puzWnn = 2106277512;
    double IXCVdVMFsiRfb = -603261.1849078072;
    double lNQjlbLYcmYqUepz = 998808.5789298668;
    string SlZFWTAJhAx = string("AWrEUtaqFUabYwqbAqdcvyVUibUJBNWRbRScWHihpnDCckiwyWghgBGZdgQZNmIORAQkwFrbdOlAylO");

    for (int EhqJHgbhh = 124451637; EhqJHgbhh > 0; EhqJHgbhh--) {
        xGxNSkKKsSK = SlZFWTAJhAx;
        lNQjlbLYcmYqUepz *= IXCVdVMFsiRfb;
    }

    return puzWnn;
}

bool SvsDLALbE::sOAfdiavyAhRRxY()
{
    double VrSMDId = -751302.798719743;
    string ofwKJ = string("tzEvODoZeZxccmDlSnPzVCrCSPKtTccglygifiHsDxvwhJGzypQsggBEuoCGoLclbqUkmwXABkrMdxoQYbkLZsVngNEteHbzttuGmkmLigAJySWQIdpeBcOhSXPiBkzfJpVtAtWvbgLIxCZfCrzjOYCVGKyeiotXfLonnGSvuVKLpdu");
    bool xuIfOPvEzgdSes = false;
    int UutvIzJdRyr = -1224350421;

    for (int JxWCkFDZc = 1240179043; JxWCkFDZc > 0; JxWCkFDZc--) {
        VrSMDId *= VrSMDId;
    }

    for (int IafBAnUILnA = 1880952863; IafBAnUILnA > 0; IafBAnUILnA--) {
        xuIfOPvEzgdSes = xuIfOPvEzgdSes;
        ofwKJ += ofwKJ;
        UutvIzJdRyr -= UutvIzJdRyr;
    }

    return xuIfOPvEzgdSes;
}

bool SvsDLALbE::ukPdtFxGLtJja()
{
    int ZmuGp = -1646023520;
    string NcsKzZdySw = string("gUEaQfnTJDCDnMFWdfqyweSsBIZuKnwVqntlyxdpwpYkKudEujIfLxfMItoAmclxpQyxEXYuzmkKvPNGXlrKKBbSjohfGlOdXmAxTenqALzwStAtGlVgXKvFBQxdBfwjvMbkEHlSlpvQKaZOuptGcpgKaUYbglPxXWovlfREUpbBOgnEUSvgRHeqgZT");
    bool zSIhttwTufDns = true;
    int ShDuTQliLfFZoIE = -676222800;
    string TdNAfkWhr = string("KhMjTYItmagigIkakUewvAQDZnqGDbMzaGJQJRZASMOLjxBBiBEgnIOomBOAQTWOinzVXzpcXjRZERxhRXeORlxlsmStQYshlzmF");
    double ixJqtPLQToAdph = -873976.170791249;

    for (int AhLpGivdFPpWDB = 980632450; AhLpGivdFPpWDB > 0; AhLpGivdFPpWDB--) {
        NcsKzZdySw = TdNAfkWhr;
    }

    if (NcsKzZdySw != string("KhMjTYItmagigIkakUewvAQDZnqGDbMzaGJQJRZASMOLjxBBiBEgnIOomBOAQTWOinzVXzpcXjRZERxhRXeORlxlsmStQYshlzmF")) {
        for (int gwxMVmU = 1213368145; gwxMVmU > 0; gwxMVmU--) {
            ZmuGp = ZmuGp;
            ShDuTQliLfFZoIE += ZmuGp;
        }
    }

    return zSIhttwTufDns;
}

void SvsDLALbE::FciJfKVdlp(int AywzkFEMfGIaAGjM, int jKICxOdivHg, int OwFrNVueoDP, bool xYcrVvPddZWKhFB, double uVNnA)
{
    string wmgPfQ = string("JORaziSzfCOsMpLcJVeouoNsVABiCSlihTKlBCzZynaPFlYWMSKXKNguDKwNGgjhuhpaELsNfBUDuzSSVGyXnSPMNmwtEeoJqCGrssCGpNvTTMpxVsNmveUlCLpDEYYUuoyPpcPdlZUpPYyEJMrJbwcINFGNpuKpQcycRAlDbDrsMBdHBjHSdVLJXWmCkLwVWWDZVBcYRibLoCdTLzVCcytgwyMZvyulHebMSjZcGhoAhUJnZFKNmfAmDJvMc");
    bool POcYyiuPXIAMMhw = false;
    string CSfXkcXLFyyRaHXv = string("YYytUbewWfVEcDxChYIUpjvFEvNfyHcGqVQPvtkOPgeoaoZMbzGxYcejFCzsCCfKXlQtMHAkAjIYPRtQPGlZnHHqaqoPwEQQqzNMirdzJNwWIWFXGLrtqzlPeazpRrgLXeAVEqySIUCtbgtKOmYjhFPVlvodllyOLkclTnkmfrwPUlQXLuxOslJdnQIfgLUqkSuLEpkLNBjhCfHWFhmwQPuueuFLzMfkuEukoUsfgfcASkDAchPMkSyX");
    int SgvRv = 168475438;
    bool BjZhEwtfbgGEV = false;
    int CfuSDYfrz = -935646547;
    string bDNExppK = string("kEWhratTcxYscdUlFDJBotsCnYbHJJvhwTaKlnVqkMDNpywWGtcDcJGxaxqSVaiiGuokZSfGNRqPPFxUxWCCKNYCJwVcUpOxTDETgiezvxxxgaEySEyGgOESDsZcfcyXLKbKxmGVmKKjvjiPYNGBRIePmaWYACJAHUuKWYHkmVfbYTjdUQMBHgqKQXVPIcwPNwPVTDytGGfBmvXDZQmpDkdQ");
    bool EMKsKxNjrLD = false;
    int WPFRlORqqFUFmG = 1906941470;
    double ezdDijBkJi = 136584.22941198063;

    if (CfuSDYfrz == 869172638) {
        for (int YeoTGbapjQQKfP = 1236046292; YeoTGbapjQQKfP > 0; YeoTGbapjQQKfP--) {
            BjZhEwtfbgGEV = ! POcYyiuPXIAMMhw;
        }
    }
}

double SvsDLALbE::mVAGztewPdKqOB(int hFGtjuZPNPcpvmv, string qDWnYkyWwuUT, double XmMsYYzefNEu, double PSkuzDNTIzZTgh, bool KgiZjzUcPsNQpfh)
{
    string IbNwuBnNWcSzV = string("lTowLPkMSBKHwjWRmRDTEePYUNjGBQsHHFJXMhzCESmNoecnZVZQOZxhtvrFAZQRuMncwLvhHovOsZAqALbuFmbmykaOImmXZObNRioaRlzCZTiAVpseVdTNsbyUkbDPoPTFrTBBbSNuKhrKDGnXkaCirRhSLADImwXwgPgnBKhOLBeiunAAelJwqMrbKINkaflfIEEzMXPkIrWxfhxrCtbDRnEncJyPaZuDcroUvyRLhIWyKXkDftXPcyJyP");
    int gaFUgpRglI = 190776283;
    int YSjppnWppbu = -805239033;
    bool teRqXzDYa = false;
    int ssRSTiwRhQzQw = 2138729091;
    int sEiqUde = -243032182;
    bool kQRmS = true;

    for (int GTudMijJJCc = 1723774405; GTudMijJJCc > 0; GTudMijJJCc--) {
        gaFUgpRglI = sEiqUde;
        hFGtjuZPNPcpvmv *= YSjppnWppbu;
    }

    return PSkuzDNTIzZTgh;
}

double SvsDLALbE::XToVLpqElUNRf(double kiEDUUxAy, int rnZmBPu, string lrkQhBWJuW, double xlhvPsuZpyqpIY, bool dCUOGH)
{
    bool wKKRdAMufqyk = true;
    double NgzIZWVrPgcpA = 510668.7134873948;
    int izbNDilIqVY = -498029683;

    if (NgzIZWVrPgcpA < -638067.3877290039) {
        for (int uJahVqiMhPUSAArA = 944868158; uJahVqiMhPUSAArA > 0; uJahVqiMhPUSAArA--) {
            xlhvPsuZpyqpIY = NgzIZWVrPgcpA;
        }
    }

    for (int zdawbogaFXW = 2001998677; zdawbogaFXW > 0; zdawbogaFXW--) {
        continue;
    }

    for (int EGPyhiNDbJuA = 923566640; EGPyhiNDbJuA > 0; EGPyhiNDbJuA--) {
        izbNDilIqVY += rnZmBPu;
        xlhvPsuZpyqpIY = NgzIZWVrPgcpA;
        lrkQhBWJuW += lrkQhBWJuW;
    }

    for (int jFBYgOgdtGjSM = 1172240283; jFBYgOgdtGjSM > 0; jFBYgOgdtGjSM--) {
        continue;
    }

    return NgzIZWVrPgcpA;
}

bool SvsDLALbE::nSTInWxJQmrGpCV(double HGpeWVRGXAZxCvCM, int KuhvUmtfw, double iKdUftXu, bool nPqfj)
{
    double mmMykkBKItyKxm = -515247.2820297482;
    bool kFVvV = true;
    int cfvSUG = 165367646;
    bool JaAFTiJ = true;
    bool PLjyvH = false;
    bool GvdgguWhCP = false;
    int zOMQLhY = 763766402;
    bool LFTVYDXVFBaA = true;
    string SGgArjPlecqhGEU = string("jBJAQzFNaVAtOybDbgeaaXlDyCPqHoWQeWKtEcUKShyvCUrpLRP");

    for (int ikuSLVPsDLZIZIQ = 1006596175; ikuSLVPsDLZIZIQ > 0; ikuSLVPsDLZIZIQ--) {
        HGpeWVRGXAZxCvCM = iKdUftXu;
        JaAFTiJ = ! LFTVYDXVFBaA;
    }

    if (SGgArjPlecqhGEU > string("jBJAQzFNaVAtOybDbgeaaXlDyCPqHoWQeWKtEcUKShyvCUrpLRP")) {
        for (int oMLOsQqN = 1192257781; oMLOsQqN > 0; oMLOsQqN--) {
            zOMQLhY *= zOMQLhY;
            cfvSUG += zOMQLhY;
        }
    }

    return LFTVYDXVFBaA;
}

int SvsDLALbE::FYMMFV(bool glZnWfQNVzLBi)
{
    double HTdFinpTKo = -628066.6467926811;
    double EtvoolEHqMVrm = -549867.7978860503;
    double FVwhLg = -6150.4744121095355;
    string ERdYlLYZR = string("aLLiuDNsQiVVsitqjVmIeWaRkxBEEtPUGmBgZfNvcyekcBWEIQrBOFFJOOeiOKLUsmXLdFBBiIuClsXhoCOlVLEIuBFYXmtJTYgrGxGFPAWQLnExdbGGDrfxyGRtlBEdJQHUmHqZahhDNNn");
    double jPJjuNLWXwU = -985215.4943187771;
    string aabxKBtPPZceMjRm = string("MsPUicFychzVmJzNVrraUZwVWoSctdtCiwIIdscbkUQwYFzArhdDeDhLkJrBpqrxCLpmzPzhdHGZSCEoLzowzNRgDflfxgUMBJSUcmDyrbEKiSFYPgohwpXsHjHQYRRjFFeZsurXZrONMolwvpncQyObGTyvKuAMvugHKrhKccTxMmagWHmSsvBQoeLkGNnrUReyeVAmS");
    string AFXoCUCXzhsP = string("dfqKjgudZbJchpoPMwzmcjeJQwLBNsDGltxkXJrnpKZXj");
    double VhgLSKMTAsUPK = -234022.20348811607;
    bool VVyMM = true;
    double gqScWHLG = -1035004.0526717135;

    for (int YcjQPeQn = 301633463; YcjQPeQn > 0; YcjQPeQn--) {
        jPJjuNLWXwU *= FVwhLg;
    }

    if (gqScWHLG < -6150.4744121095355) {
        for (int YQqSrgdjBUw = 1222004353; YQqSrgdjBUw > 0; YQqSrgdjBUw--) {
            VhgLSKMTAsUPK *= gqScWHLG;
        }
    }

    if (FVwhLg <= -234022.20348811607) {
        for (int sxLgwoIjb = 1418741625; sxLgwoIjb > 0; sxLgwoIjb--) {
            aabxKBtPPZceMjRm += aabxKBtPPZceMjRm;
            VhgLSKMTAsUPK += HTdFinpTKo;
            FVwhLg -= VhgLSKMTAsUPK;
            jPJjuNLWXwU += gqScWHLG;
        }
    }

    return 176188396;
}

double SvsDLALbE::EqrzIiWoeJAupK(bool lSSiNDOwsmZZkYa, int hjUhQYTGkJYGcwyn, int XupjIYp, int zNaFRuR, bool UHRhmHDCpoJfoGj)
{
    double WcADvorBlyqoNW = -434660.4817525476;
    int ianCvxJLz = 223023869;
    string TonvwSUYsmAybDvM = string("jScsOjRMUPDmsyfnpwnpcBmlBPNxKSOhbpNggBzJrLyUoXTGYIblEQrjtVkbUtHNuycPIHZJbknDPcfhPLxapnMtyqHFDxeZkBKYcjSTVuLFnhYifvVMStUukXoTRjwTOpTooqyBJHonwjNPuiQDDcRFmlfdVKLHoeZESKgQahRFiEOJPVlRGcQsJiqbfgeZ");
    double jxGDoXL = 795262.2224637074;

    for (int pJoZblwlBSBTe = 463279418; pJoZblwlBSBTe > 0; pJoZblwlBSBTe--) {
        jxGDoXL /= jxGDoXL;
    }

    return jxGDoXL;
}

bool SvsDLALbE::VnzLxzOtKUf(bool KWMJsHHKTRP, int cdieKLLDPBt)
{
    double oGEwfDJcog = 666260.7242460027;

    for (int slVooH = 1442496312; slVooH > 0; slVooH--) {
        continue;
    }

    for (int RThjMFKlbzRzyxZ = 2121685591; RThjMFKlbzRzyxZ > 0; RThjMFKlbzRzyxZ--) {
        continue;
    }

    for (int lmOKqPWbCxtd = 1884533619; lmOKqPWbCxtd > 0; lmOKqPWbCxtd--) {
        cdieKLLDPBt /= cdieKLLDPBt;
    }

    if (oGEwfDJcog < 666260.7242460027) {
        for (int iDrMFyPLbieo = 763304491; iDrMFyPLbieo > 0; iDrMFyPLbieo--) {
            oGEwfDJcog /= oGEwfDJcog;
            oGEwfDJcog += oGEwfDJcog;
            oGEwfDJcog += oGEwfDJcog;
            cdieKLLDPBt += cdieKLLDPBt;
        }
    }

    for (int rOCTz = 1169722395; rOCTz > 0; rOCTz--) {
        continue;
    }

    return KWMJsHHKTRP;
}

int SvsDLALbE::dtmmXPTthOzob(string TWoYYPuCOBZAgpJ, double vjzFVVPtQn)
{
    string lkjQZ = string("wPEZYrPYkMjZwtxtqbgfguynpfssBWybTNA");
    bool rcnsZWsec = false;
    bool CahAJalGdxQx = true;

    for (int VsRbsDA = 939307277; VsRbsDA > 0; VsRbsDA--) {
        vjzFVVPtQn -= vjzFVVPtQn;
    }

    for (int mchxYrolRU = 2078487544; mchxYrolRU > 0; mchxYrolRU--) {
        TWoYYPuCOBZAgpJ = lkjQZ;
        CahAJalGdxQx = ! CahAJalGdxQx;
        CahAJalGdxQx = ! CahAJalGdxQx;
        CahAJalGdxQx = rcnsZWsec;
    }

    for (int ZWeiVAZM = 1177194673; ZWeiVAZM > 0; ZWeiVAZM--) {
        continue;
    }

    for (int BWpViapYhD = 1929097671; BWpViapYhD > 0; BWpViapYhD--) {
        rcnsZWsec = ! CahAJalGdxQx;
        rcnsZWsec = rcnsZWsec;
    }

    return 1183646462;
}

string SvsDLALbE::TbedlKGFKoeKkRxy()
{
    int wqcrTWXtOjxi = 210506638;
    bool ZMZgmRWs = true;
    bool hlSEnEJStE = false;
    double UWqODx = -223.4712182432337;
    string JCbcENutz = string("SddaXvOvRHlYqDiQYSjthwbjAGfEopJtipJrJvCqciBgNFwOHpvSHUeCmlrlKuwUTgJEncHRerRLJWSsmjqsCfOamjXCrrDmourdEdLZNunLuLGyXkTKfiOJZYVDOFTqBygpsMhhYFFodXckLqNcsJBtMljhUNLcAXonZatbZkMjxfcgRwGyBpMnskiWFDfHXJbRYtmljJPEQZgAnIyekjplSZABfzxibxNVb");
    string XdHbTwKmsWZUek = string("eNtgUxMhacz");
    double boiASjCY = 909594.6490875981;
    int aRPQucD = 751911676;

    for (int lTlZWNRiBFEqJy = 970774116; lTlZWNRiBFEqJy > 0; lTlZWNRiBFEqJy--) {
        wqcrTWXtOjxi /= aRPQucD;
        aRPQucD /= wqcrTWXtOjxi;
    }

    for (int OaZrmSROhxvp = 1075783568; OaZrmSROhxvp > 0; OaZrmSROhxvp--) {
        ZMZgmRWs = hlSEnEJStE;
        boiASjCY -= UWqODx;
        ZMZgmRWs = hlSEnEJStE;
    }

    if (UWqODx < 909594.6490875981) {
        for (int yhorXvNq = 1517928318; yhorXvNq > 0; yhorXvNq--) {
            aRPQucD /= wqcrTWXtOjxi;
        }
    }

    return XdHbTwKmsWZUek;
}

SvsDLALbE::SvsDLALbE()
{
    this->JjzAgmHXaCKWb(string("uJpZAhamTCAEuQxZWTRcQAeuMSuFJspdrDjNykcTqLjgnHCIYgSmorDUaMSisoJwpOtCrDsTGvUwFhLLtnFOOBZrSUxnRKqorbAhNfvEietinQCtCOcAYqhbBUeDrWiKmJCAiHEfUndwYzzEVhfNZbkjZRgGZZEgsnrnIrzeVwJTTQMfHGAyjwvDNQdQKabTtwCTRvRKytAwwENxMCsPwJvWnovyFXyOdoYrDgEPIQmGFuiQouWnEXrVrflARI"), string("mYdisZhxMiyFoUzSKkErylhhtrfndlDIKEnSZzQx"), false, string("HkwTZYVtrihzECBjeKaFgkCKKzihoSSfPTzNOJUbwFhCoIXQkiPVITLubDTGKzeffzhMBpjcSOjEOtIufnmQyhUBpeMKwccrMtPRaQKIQzQoiyDdSnMTsCmhqdEHOlpfXwndVFVxOpyqotqLypClUdZNzxL"));
    this->XRSTqhHqxGnXUocr(false, -31572326, -610746287, -874639.8987194984);
    this->LyWhdgKBX(333296.79322855634, string("kcJUweFYBwhjHqWvVbgVCSwsFzawGulHtNcBxbIUYIaZvRgcOJNvTQmwxKqKqLIjJHzZgxogARLibuGoeXnyKrJcPD"), -2026438121, true, -815047.5302566822);
    this->foCMicZ(-929080.9168802097, -32556.141711894415, -335176.1365028618);
    this->LswsXIapW(true, true, 1238024254);
    this->xnmuluQ(false);
    this->sOAfdiavyAhRRxY();
    this->ukPdtFxGLtJja();
    this->FciJfKVdlp(2017641494, 869172638, 750470429, true, -341408.4314465644);
    this->mVAGztewPdKqOB(-1134239518, string("NtrSzCoQyDZEiWn"), 248902.03662479547, 324822.5978859595, true);
    this->XToVLpqElUNRf(-638067.3877290039, 1388153262, string("ZZGiIlekSFSYEtqgItCcYnvwOmlIPRwTtSwuwYhKwvnCqmKDCHfipLZjMrQFbOpPfYNEnQcQhsVpQpkibRxLYpFjRbKVLs"), 286624.3936284752, false);
    this->nSTInWxJQmrGpCV(-545005.6391494728, 2112742154, -447976.13421774347, true);
    this->FYMMFV(true);
    this->EqrzIiWoeJAupK(false, 2007926046, 2096952695, -1713623321, false);
    this->VnzLxzOtKUf(false, -443602916);
    this->dtmmXPTthOzob(string("qDJiEZIfvdPXdolrHyNxbZlqIGzjbchApxEGFNsYAzqnMpQnlQsqQzkSowJHDFTwVAtWgsKsIxCwrJUgueqInezqbqBklejMSqgmocEyTFOXOOXyjbgrLUvCJjfMSXFlBxsYEcrItZTCkaYswZvfiKtifOiVbAcyhndhqFSaIIKtdbHhTJCOsmIIANvSWYZ"), 976920.8349489731);
    this->TbedlKGFKoeKkRxy();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aSZyMf
{
public:
    double nNYXhg;
    double vszrwkKIDgf;
    int bsYJpto;
    string ZDFvpXdRPF;
    string jNmwXqPPjw;
    bool dwWIQKFjxYes;

    aSZyMf();
    void MMoGoRmDyAn(double dICkuDfk);
    void hdmlYRnyZTzAnBI(bool FMokYBPPWsc, string HkvcD, int BMyszcQoZQh);
    double xOpjJHofUKXTrxuR();
    string qypdPeatNNfU();
    double LdWuwqyeEAKcR(string vQWGsfhmEQPHpvjs, bool hSbRdVOwVecCUM, int uAYnaJz);
    double OGrKdcmPTBZOOGdb(int PckwvsMx, double wVFQAGXRQBAjEIVm, string tLQYibGOEbVXU);
    void uDTRe(string SUXxuPFkv, int QMwFc, bool krqZUtFbfHLAvtgF);
protected:
    int ZOzzAiXEfA;
    string wNGbiJBjfyiubfKE;
    string OBZgMYg;
    int nfHveUbblwg;
    bool NtYrxXSjeMvh;
    int sfQPV;

    int pTnoFWSAmev(double gjfjrFuNKPQQmu);
    string jmDsfhTu(double MuuheofrEVFhWve);
    double MbBXgHmMCwE(double sBmILFiQXZ, string SvPlVEQbmbILZ, string CEFqUuZJ, bool BRwVHywKYNDSsmOR, bool xlmvHTcNzeoXw);
    bool LPLQXsJVucdj(double OgmNFvGmvu, int PBEyUgMDkiOpYMev);
    int MMNLYNEQqqNAqB(string qzmSuQ, double nRNasKnsQCZ);
    int fBDWqUkxD(bool cuidsKjlmxqwYkHw, string MMyhK);
    string teNMGxXG();
private:
    int DNdYGvQdkqf;
    string BpbSEHPOZm;
    int IOndFBdnkfByPjRB;
    double xnmiVCFMPjoy;

    string IgUUaIPHXXXvy();
    bool AaflqTScwHfcM(double JhRYorv, string wGwQwvMZopGOhBzq, bool aDHgazL, string BOAhgtQXJ);
};

void aSZyMf::MMoGoRmDyAn(double dICkuDfk)
{
    bool LPlRApmk = false;
    string FjsLPuvQnsPzzW = string("ErllSusuNrhgvPxfIJvALr");
    string McAwOBdfbOa = string("QBJAbfdxsdZvteBhTMAETAvNjzbqbbTiclEMd");
    bool BhwBRZ = false;

    for (int BnkstWREdT = 1488463422; BnkstWREdT > 0; BnkstWREdT--) {
        BhwBRZ = ! LPlRApmk;
    }

    if (LPlRApmk != false) {
        for (int Nibsk = 1328345746; Nibsk > 0; Nibsk--) {
            LPlRApmk = ! LPlRApmk;
            BhwBRZ = LPlRApmk;
            LPlRApmk = BhwBRZ;
            FjsLPuvQnsPzzW = FjsLPuvQnsPzzW;
        }
    }
}

void aSZyMf::hdmlYRnyZTzAnBI(bool FMokYBPPWsc, string HkvcD, int BMyszcQoZQh)
{
    int ieoTdHbts = -1083511975;
    string rCQZSSCStNt = string("iIvsMrESrHwsQiksfzLdIcuDPBqAFbifjLQFBYkkRnfSgyIIxsFcGqOWSsYTwHVkybQYggtVevcZJmTSfNrTfTVFYWBohqZxNtEgvMaOHuxGRyXvSchHliyEDcrLMROHuqWscKUEEndkLbGGaJRBSkSQucmbjySIrHrXJSykjxLmhIcxiDAkGoxqnNPtyxbmzQNn");
    bool mnPWOXiltW = false;
    string YTlCvMKawYz = string("uuHzAZuwxUl");
    bool TDnyFJgfhS = false;
    string eBwJwbnd = string("vbpwYrYdbbnLgYWwcbhPnbIirhZWXHzKHfDNbGukVinPObXbovVvbQCNsHVJGNTkKMMyalcGTSUtlUWcHOwmzcktbYhEJtTFevnufkaqyvUYjpdEjFxnTKXMoksbLdglEtqzhDHITAvXPzmfrjDGJJIBaVoxd");
    string CnMkkmcqkAjQs = string("HkYYJHRRMCLCwWwDvLEvUWIZvCAIOVvFHfyEFszvBqRUNBfJMQHUqlgtCbJHWusWDtfsmmytTAaWoNEfGTFoYQRIMKAsKIurCgyAvKGCFpRlekLSnBaCIldEYXlypRTYOklXYcyiDTXKvpn");
    string ledWIHkSS = string("SXrsfFNZATQzHGKtyjNveWvKpMijOReuKNDRMkbuGEUWifWbanJsUsyUAzBWyKbQtmtUTqnoaPJoxzBsODDtfQzYbejJqvxayXokvnHZSvqGDwveABmlkEjuqVMuVDisUmqbTUTWryXUlHsnWwtYnNoeEWgEQhoJQeXDBsfVAZOgxlJEygLiFlwfsvRTkkCwrMdFpecutvmMsXbJVsypWncJOssniaHInXmHtuGxpmcIIYXBDuCTIxHgkt");
    bool nSlin = false;

    if (ieoTdHbts > -1083511975) {
        for (int OOowOmxyDeUKrUf = 1250084770; OOowOmxyDeUKrUf > 0; OOowOmxyDeUKrUf--) {
            continue;
        }
    }

    for (int MjpHwbR = 1427304482; MjpHwbR > 0; MjpHwbR--) {
        nSlin = TDnyFJgfhS;
        CnMkkmcqkAjQs = YTlCvMKawYz;
        ieoTdHbts = ieoTdHbts;
        TDnyFJgfhS = ! nSlin;
    }
}

double aSZyMf::xOpjJHofUKXTrxuR()
{
    int FUQSevINIMmLLN = -1201260587;
    string UWhGI = string("wrnZhzOvzmbKfzqHpdVfmbQSgOiNAiAUiSRoiqYELkvkvAcjZgELlEUeEchcPuRmDqScpeATiZeSvDDyRfkKZkANSaIeYKfxfXfPwgrJtJozVBXpKqlXpnQXuFLDMEgpwYSljigQjDeDcSpIXcroTJqMfJurJMkHIWzzHpWdACWvHGMKqxRpFalncoETLDpwKXLNNgqvHAaufwSUnrQseYYnAywHAvCrKpDJRXSnptuADMdFRWNirlWu");
    double kebvnKEinOFrEz = -507845.86121290666;
    int hxHrQ = -680807393;
    double ospEtOEFF = 911310.6203831487;
    double oqyBFc = 806937.4664134023;
    string foQUB = string("MdOGCtlVhqKIMCYprNOBTUEJd");
    string nwmnWVjJeXO = string("LqYgfuhcZCTMoWDbGVvsrjxrmtxcYMNrwHAlainAnmlHnIKWNppFYmEqKhdAsqSmiWkLEjmbtAPEAdoKAFmYIpKIrPVsaxvNGwzkzCPlXfqbobqCZbDYHEuaXtoSGITJiGJfYESyqIsbYRZkAlyrhGjONYLrOQbUHPYIASpyeLDJpNJ");
    double uUjPD = -185496.13069140876;
    int oBiEsayXRFSuHhyO = -12468118;

    if (foQUB >= string("LqYgfuhcZCTMoWDbGVvsrjxrmtxcYMNrwHAlainAnmlHnIKWNppFYmEqKhdAsqSmiWkLEjmbtAPEAdoKAFmYIpKIrPVsaxvNGwzkzCPlXfqbobqCZbDYHEuaXtoSGITJiGJfYESyqIsbYRZkAlyrhGjONYLrOQbUHPYIASpyeLDJpNJ")) {
        for (int CGPudROnlMBe = 1157653374; CGPudROnlMBe > 0; CGPudROnlMBe--) {
            oBiEsayXRFSuHhyO /= hxHrQ;
            oqyBFc /= oqyBFc;
            UWhGI += UWhGI;
            uUjPD += kebvnKEinOFrEz;
            foQUB += foQUB;
            nwmnWVjJeXO = UWhGI;
        }
    }

    for (int WvmeWgtADONnMK = 1475352298; WvmeWgtADONnMK > 0; WvmeWgtADONnMK--) {
        oBiEsayXRFSuHhyO *= hxHrQ;
        UWhGI = nwmnWVjJeXO;
    }

    for (int YcrwuzlyxHeeO = 1828807330; YcrwuzlyxHeeO > 0; YcrwuzlyxHeeO--) {
        continue;
    }

    for (int HBDyC = 566633198; HBDyC > 0; HBDyC--) {
        oBiEsayXRFSuHhyO /= oBiEsayXRFSuHhyO;
        hxHrQ -= oBiEsayXRFSuHhyO;
        ospEtOEFF *= oqyBFc;
    }

    return uUjPD;
}

string aSZyMf::qypdPeatNNfU()
{
    int RMPbViU = 553455775;
    double xiyXFIrTO = 898501.6197367213;
    string TAddtGZgB = string("MiGfiaSsOzSeNEbYFZctKNHTUmUIXSpoMxSnOPIIhQOnCLaiFLWLIWbgUyDQoAcpZLYdVCwdLTPWUgoRkuJgDRKmiZXgpxMEfalxjSZyCgdBBqvEuSjXUYjfbhtbVSZExZZpltOKxrWpCERJpIeBqRzcPBrBfSENNysnWKZxFoMdQtFeCdzQvCKpzB");
    double FzdmefuRQwKYCvQc = 778877.0264435883;
    bool KAikzo = false;
    string wjvdv = string("ltdfmM");
    string rISfSpBLL = string("HXndSptUqXTfohNRLpWkqMUTDqxuBIMrpPEpmAywsOJDNpaiTflVMvgkirEUYAUii");
    double BIDlA = -927065.4859546556;

    for (int NlVCYAa = 180900246; NlVCYAa > 0; NlVCYAa--) {
        FzdmefuRQwKYCvQc = FzdmefuRQwKYCvQc;
    }

    if (wjvdv <= string("HXndSptUqXTfohNRLpWkqMUTDqxuBIMrpPEpmAywsOJDNpaiTflVMvgkirEUYAUii")) {
        for (int UQIfzcACvGseU = 1113634622; UQIfzcACvGseU > 0; UQIfzcACvGseU--) {
            rISfSpBLL = TAddtGZgB;
            FzdmefuRQwKYCvQc -= xiyXFIrTO;
        }
    }

    for (int WnwCBbBeZK = 1251379933; WnwCBbBeZK > 0; WnwCBbBeZK--) {
        continue;
    }

    return rISfSpBLL;
}

double aSZyMf::LdWuwqyeEAKcR(string vQWGsfhmEQPHpvjs, bool hSbRdVOwVecCUM, int uAYnaJz)
{
    bool TjQhglbvCipyS = false;
    bool CMZyycAzGo = true;
    string tdXBuEWllV = string("KBuNDAQuRQQSbDHVWtvUlZywOFIuxfTiJQHcBfRxxDRXTMrbEqIF");
    double ePhHmneoYqps = -568726.6023361189;
    double iwfQgbC = -96664.10743058487;
    bool lcCCx = false;
    double gPuMENshX = 105213.99391567484;
    string NlCdRuTwNObgzQRn = string("sjbzUpkdDLaOnyFWBFzNWkqyxvySHBPzbDqrwAetviWkHptDFzUFmvYSXlbRfsWEKQMIXkZjkQFMSGmXwurMWXdGbqszMYSKhEAdpWesdudQYJHKKoTzhMuloNxCzRNEyfgUImEbbqagtvckmTnjnggxodIkvydvbASSQdW");

    return gPuMENshX;
}

double aSZyMf::OGrKdcmPTBZOOGdb(int PckwvsMx, double wVFQAGXRQBAjEIVm, string tLQYibGOEbVXU)
{
    bool DiRsSI = false;
    int JxIHURIlSYF = -1176814733;
    double msVue = 1016218.2459570139;
    int sqckC = -122358884;
    string iTiYKVYWBwNy = string("rscEcDyrsaxDXGRQpCnmaDpEdPvHIJVrpKaFtMWPtjaTRSZmwbDrfDTHrLVcAsFkgbISlLQuffkKdZhNrXGjSPBsSmQguANyBdnKMgSuWKOXjchFjzTvNfmLlANXlbHZLVARtUKDhCXJcFFPUrAWwQxhHgkUOaedEwlmEkpeEuNNqnJ");

    for (int CYhQr = 1168079299; CYhQr > 0; CYhQr--) {
        JxIHURIlSYF /= sqckC;
    }

    for (int DDLclyFmYSQw = 1910013472; DDLclyFmYSQw > 0; DDLclyFmYSQw--) {
        JxIHURIlSYF -= JxIHURIlSYF;
        sqckC = sqckC;
    }

    if (msVue != 209766.43399722897) {
        for (int QxrZyzQl = 701873822; QxrZyzQl > 0; QxrZyzQl--) {
            DiRsSI = ! DiRsSI;
            iTiYKVYWBwNy = iTiYKVYWBwNy;
            msVue /= wVFQAGXRQBAjEIVm;
        }
    }

    for (int xliWHigxLri = 2059678881; xliWHigxLri > 0; xliWHigxLri--) {
        JxIHURIlSYF *= PckwvsMx;
        PckwvsMx /= PckwvsMx;
    }

    for (int ngFkPpe = 947061353; ngFkPpe > 0; ngFkPpe--) {
        tLQYibGOEbVXU += tLQYibGOEbVXU;
    }

    for (int UJYIrToBsdxIGiZv = 2007142744; UJYIrToBsdxIGiZv > 0; UJYIrToBsdxIGiZv--) {
        continue;
    }

    return msVue;
}

void aSZyMf::uDTRe(string SUXxuPFkv, int QMwFc, bool krqZUtFbfHLAvtgF)
{
    string znUITtjot = string("ssnEjDGmcrYBSddfeiRhRNJsIlFEWkZTxHpGnhqq");
    int itnfUzAVTMtJy = -1587609631;

    for (int hZQWOOR = 1624156353; hZQWOOR > 0; hZQWOOR--) {
        itnfUzAVTMtJy /= QMwFc;
        krqZUtFbfHLAvtgF = krqZUtFbfHLAvtgF;
    }
}

int aSZyMf::pTnoFWSAmev(double gjfjrFuNKPQQmu)
{
    double ELRodsH = 729106.0166958694;
    string DfJnMDFm = string("lgmdSKhhBobKpGNVNiCJdCJcECRtbsTQefURyoYnFKnPnwJPLqzVAlGcuMteEcNJHnluVCBWecKtBENMPGmuSchJiQpJiny");
    string toaSCXepcIkI = string("JkcjFtrDylAJtESSjYypqYjQfTHTVBRBzIxcMXAoeoOMjkARBbKsJQOMxFZiWEzgMPZoHUCJnpPygZkOShSQPzHmYHpqtvZPAiG");
    double dMVuaSkCNHpMQaDN = 424338.26207508065;
    bool sEuDDwQCvcxg = false;
    int BPrndsyGy = -1476857004;

    if (dMVuaSkCNHpMQaDN >= 935132.2267243174) {
        for (int FTQrkjpxpVjK = 1490562998; FTQrkjpxpVjK > 0; FTQrkjpxpVjK--) {
            BPrndsyGy = BPrndsyGy;
            ELRodsH *= ELRodsH;
            toaSCXepcIkI += toaSCXepcIkI;
        }
    }

    for (int ITuEau = 1025206026; ITuEau > 0; ITuEau--) {
        continue;
    }

    for (int NYmMfstrtZ = 302530526; NYmMfstrtZ > 0; NYmMfstrtZ--) {
        DfJnMDFm += DfJnMDFm;
    }

    if (sEuDDwQCvcxg != false) {
        for (int cCMuSDMd = 2014121213; cCMuSDMd > 0; cCMuSDMd--) {
            sEuDDwQCvcxg = sEuDDwQCvcxg;
            sEuDDwQCvcxg = sEuDDwQCvcxg;
            gjfjrFuNKPQQmu += ELRodsH;
        }
    }

    if (gjfjrFuNKPQQmu == 935132.2267243174) {
        for (int IGSycwFnxfETv = 1706370249; IGSycwFnxfETv > 0; IGSycwFnxfETv--) {
            DfJnMDFm += DfJnMDFm;
        }
    }

    for (int UrTKHaaluCsj = 836943023; UrTKHaaluCsj > 0; UrTKHaaluCsj--) {
        toaSCXepcIkI += DfJnMDFm;
        gjfjrFuNKPQQmu *= ELRodsH;
    }

    return BPrndsyGy;
}

string aSZyMf::jmDsfhTu(double MuuheofrEVFhWve)
{
    double BZPswB = -24304.495615062788;
    string PauQYh = string("DsTphtXAjengaJVukiWwLHRNmxbvbdwcPnqWEpYQqeEvOEjKsPezWYIcPqXTSshVxprx");
    bool WhQptGOkCLnO = true;
    double YRqDvpJ = -356925.5819109963;
    double LWSmxiBUnWAeK = 123572.46966564942;

    if (YRqDvpJ >= 123572.46966564942) {
        for (int ikgPtU = 1081333750; ikgPtU > 0; ikgPtU--) {
            YRqDvpJ *= MuuheofrEVFhWve;
            LWSmxiBUnWAeK += MuuheofrEVFhWve;
            LWSmxiBUnWAeK += MuuheofrEVFhWve;
            LWSmxiBUnWAeK *= BZPswB;
            MuuheofrEVFhWve /= BZPswB;
            BZPswB = MuuheofrEVFhWve;
        }
    }

    for (int YxoechQ = 471781741; YxoechQ > 0; YxoechQ--) {
        LWSmxiBUnWAeK /= YRqDvpJ;
    }

    if (MuuheofrEVFhWve >= -534613.8309052052) {
        for (int qCVglFSyGCWo = 978333257; qCVglFSyGCWo > 0; qCVglFSyGCWo--) {
            YRqDvpJ -= MuuheofrEVFhWve;
            PauQYh += PauQYh;
            LWSmxiBUnWAeK += BZPswB;
            PauQYh += PauQYh;
            LWSmxiBUnWAeK += MuuheofrEVFhWve;
            LWSmxiBUnWAeK *= LWSmxiBUnWAeK;
        }
    }

    return PauQYh;
}

double aSZyMf::MbBXgHmMCwE(double sBmILFiQXZ, string SvPlVEQbmbILZ, string CEFqUuZJ, bool BRwVHywKYNDSsmOR, bool xlmvHTcNzeoXw)
{
    bool UPGUEjr = false;
    bool BmqVqSM = false;
    double BTSHdR = 851260.4434396536;
    double TgzMC = 481080.26379979687;

    for (int ZOPrbskxerUOPuDQ = 1674646938; ZOPrbskxerUOPuDQ > 0; ZOPrbskxerUOPuDQ--) {
        UPGUEjr = UPGUEjr;
        BRwVHywKYNDSsmOR = ! UPGUEjr;
    }

    for (int mUgFDZZXarORxM = 938594803; mUgFDZZXarORxM > 0; mUgFDZZXarORxM--) {
        BRwVHywKYNDSsmOR = ! BmqVqSM;
        xlmvHTcNzeoXw = BmqVqSM;
    }

    for (int zWWhKjBmc = 139804547; zWWhKjBmc > 0; zWWhKjBmc--) {
        CEFqUuZJ = SvPlVEQbmbILZ;
        BRwVHywKYNDSsmOR = BRwVHywKYNDSsmOR;
        TgzMC *= BTSHdR;
    }

    if (CEFqUuZJ <= string("g")) {
        for (int kCmHyd = 1354795511; kCmHyd > 0; kCmHyd--) {
            continue;
        }
    }

    for (int UqtEnogSkhh = 1570844405; UqtEnogSkhh > 0; UqtEnogSkhh--) {
        UPGUEjr = BRwVHywKYNDSsmOR;
        BRwVHywKYNDSsmOR = ! BRwVHywKYNDSsmOR;
        UPGUEjr = ! xlmvHTcNzeoXw;
        xlmvHTcNzeoXw = BmqVqSM;
    }

    if (CEFqUuZJ != string("bgbaEyvvafJvN")) {
        for (int iiPRTFdK = 1981561452; iiPRTFdK > 0; iiPRTFdK--) {
            BRwVHywKYNDSsmOR = ! xlmvHTcNzeoXw;
        }
    }

    return TgzMC;
}

bool aSZyMf::LPLQXsJVucdj(double OgmNFvGmvu, int PBEyUgMDkiOpYMev)
{
    string HVVnhOQpYMlaFV = string("seYpLGRuswAETOFNpMwzObxNXWZKu");
    int enZPPufnQ = -1214249234;
    string cSMCksrNlRZ = string("vFHpyJTMJVLRNNNdUncIxzWcMnZNUvozskgIPTINPguYWcoXzKaSNErEXPCdtVogqNlENCSZtBlAHatPCPfOYRiwcrQQXlujuIMeZDzvFrbBDLzJcRVicNlOPVELWVFcyzcrrNAYklxDAcHIaApmbbxMVTtMCXUwJDQVDibYEoRxaSOUFMMoexfisswATCXrddHGexNuMjlwfsWUgsOQNEcmN");
    bool bsXwdhdztLKdRNT = false;
    int jICLOgMDaRl = 1587188173;
    bool YgmFZNvA = true;

    for (int XQjqErnx = 1927811999; XQjqErnx > 0; XQjqErnx--) {
        YgmFZNvA = ! bsXwdhdztLKdRNT;
        bsXwdhdztLKdRNT = ! bsXwdhdztLKdRNT;
    }

    for (int tbdyZt = 1009628627; tbdyZt > 0; tbdyZt--) {
        enZPPufnQ = jICLOgMDaRl;
    }

    for (int rLPVzXVCoSAjHCyC = 1844370997; rLPVzXVCoSAjHCyC > 0; rLPVzXVCoSAjHCyC--) {
        enZPPufnQ = enZPPufnQ;
        enZPPufnQ += enZPPufnQ;
    }

    return YgmFZNvA;
}

int aSZyMf::MMNLYNEQqqNAqB(string qzmSuQ, double nRNasKnsQCZ)
{
    int FITETzuEcN = 442916989;
    int LTtzzoDFY = 1814520034;
    bool BbzvjxKCTFuNgyp = false;
    string pjERxKVVxefluJ = string("fKfYhiPkWYSmFnKPIlNKMMGaJYuhIowuMlaaWLagxfXUmLDGKARAIfwWSzvvXBrjJHNXuEAYSZLnQXgbVrqTwPcTJJDPXbXHqmkZaXdKaIcOCIHUyikZBjHWlJoDiNSBspFOJApgAqNBZCljAREkOvbRSuwICvzbEgHSrACLGwSjQ");
    int CsMzsPILo = 491853901;
    int kMWAplNW = 1885103907;
    int aAjncffUhA = -1105392824;

    for (int ORDqJQmMC = 231410742; ORDqJQmMC > 0; ORDqJQmMC--) {
        CsMzsPILo = LTtzzoDFY;
    }

    for (int NhdSSYLKzB = 376298846; NhdSSYLKzB > 0; NhdSSYLKzB--) {
        LTtzzoDFY = kMWAplNW;
    }

    return aAjncffUhA;
}

int aSZyMf::fBDWqUkxD(bool cuidsKjlmxqwYkHw, string MMyhK)
{
    string tnAibMhyijR = string("kUGDdzJADxsLZiigjDGCDSIKkUDisHGEBJJgWEbnKWZkGFWHrTBTsQwGoXNCjEnKKIENYIPImvDxGyUWZZfoOKXZTKdsaKJdDMpLciFkxSEvafZNUgZiYxnjYYHhyPaZexnYWOYQeVakdHwAPryOSsLzRvtAwpsHRfBywwBAqBYuHdUCgbVdLSqFOVdXjVxCCsoRpvS");
    string GOLmablHgiBVYO = string("gfcwpSQNTgKVGIFHZPmEwPPCbPAeDoCTjJuvUXFCQZiJciWNHRPBggASbuRjNsjptwxXiUcrAiZEbwEpbjPlPTmFEOXSFOAFLZukqNgNoKnPniOgwXeqDBVUJlgMcSvmPwaRfZGhzGkiceuwFuiycZFkAJCaYJdWUQptnJkxroJgIcjXaHjUgGGXKfueKFannkBECFUiAKjlhFmMUpEMpFOXIvLbGIsSxqbLsrGYccuHNm");
    bool uMUpiDEBt = true;
    bool yLLGjWsxfUAxO = false;
    double UkFoyyYXJdaEPHp = 607295.8817367334;
    int cVOyjRdpidRPi = 1459465749;
    string QEeDfkfGNovgqh = string("txXrXbVBOFdRRDeJGagsMnXJTxiwFXImsizJDmUgmYAUwlENDDTNkjnMLUlNcmokJejmtCABDPynAocJIItWBMToadxMXeSqoZmpygmWdnEHxEYSqOnaQbskpXgbPszLZfnolcZyvrLuE");
    int TBsiDNjcp = 1546050442;
    int RXFECW = 1597816760;
    int LxpsPLelapChw = 208058454;

    if (RXFECW <= 1546050442) {
        for (int xcHFduIHdAUvEt = 1717243420; xcHFduIHdAUvEt > 0; xcHFduIHdAUvEt--) {
            MMyhK = QEeDfkfGNovgqh;
            TBsiDNjcp -= cVOyjRdpidRPi;
            cuidsKjlmxqwYkHw = yLLGjWsxfUAxO;
            RXFECW /= TBsiDNjcp;
        }
    }

    return LxpsPLelapChw;
}

string aSZyMf::teNMGxXG()
{
    string JCxTboNz = string("wJtkfVBQsHobjQLZKZeMZEdJkyfLjVEAhyiIcjdkUJOgxxhjUSwGUbUoIIgDaoBQDjNxOCRThjbOMzeTKHPHrXUlGzBsVXdmWklGSgKiCtHudBRWfmZYwjFaDBCezuarllWdrlhuSLlrlwftWFuHTinFgJYgcZDqjuynNkqrzjDzoYFXMGAXoO");

    if (JCxTboNz != string("wJtkfVBQsHobjQLZKZeMZEdJkyfLjVEAhyiIcjdkUJOgxxhjUSwGUbUoIIgDaoBQDjNxOCRThjbOMzeTKHPHrXUlGzBsVXdmWklGSgKiCtHudBRWfmZYwjFaDBCezuarllWdrlhuSLlrlwftWFuHTinFgJYgcZDqjuynNkqrzjDzoYFXMGAXoO")) {
        for (int LRwFocbVtR = 69023660; LRwFocbVtR > 0; LRwFocbVtR--) {
            JCxTboNz = JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz = JCxTboNz;
        }
    }

    if (JCxTboNz < string("wJtkfVBQsHobjQLZKZeMZEdJkyfLjVEAhyiIcjdkUJOgxxhjUSwGUbUoIIgDaoBQDjNxOCRThjbOMzeTKHPHrXUlGzBsVXdmWklGSgKiCtHudBRWfmZYwjFaDBCezuarllWdrlhuSLlrlwftWFuHTinFgJYgcZDqjuynNkqrzjDzoYFXMGAXoO")) {
        for (int XwIMwUcIM = 1222931139; XwIMwUcIM > 0; XwIMwUcIM--) {
            JCxTboNz += JCxTboNz;
            JCxTboNz = JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz = JCxTboNz;
        }
    }

    if (JCxTboNz > string("wJtkfVBQsHobjQLZKZeMZEdJkyfLjVEAhyiIcjdkUJOgxxhjUSwGUbUoIIgDaoBQDjNxOCRThjbOMzeTKHPHrXUlGzBsVXdmWklGSgKiCtHudBRWfmZYwjFaDBCezuarllWdrlhuSLlrlwftWFuHTinFgJYgcZDqjuynNkqrzjDzoYFXMGAXoO")) {
        for (int HWpDfwO = 224046381; HWpDfwO > 0; HWpDfwO--) {
            JCxTboNz = JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz = JCxTboNz;
            JCxTboNz = JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz = JCxTboNz;
        }
    }

    if (JCxTboNz == string("wJtkfVBQsHobjQLZKZeMZEdJkyfLjVEAhyiIcjdkUJOgxxhjUSwGUbUoIIgDaoBQDjNxOCRThjbOMzeTKHPHrXUlGzBsVXdmWklGSgKiCtHudBRWfmZYwjFaDBCezuarllWdrlhuSLlrlwftWFuHTinFgJYgcZDqjuynNkqrzjDzoYFXMGAXoO")) {
        for (int uTnCIVJRKOfXJixh = 674247168; uTnCIVJRKOfXJixh > 0; uTnCIVJRKOfXJixh--) {
            JCxTboNz = JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz = JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz += JCxTboNz;
            JCxTboNz = JCxTboNz;
        }
    }

    if (JCxTboNz > string("wJtkfVBQsHobjQLZKZeMZEdJkyfLjVEAhyiIcjdkUJOgxxhjUSwGUbUoIIgDaoBQDjNxOCRThjbOMzeTKHPHrXUlGzBsVXdmWklGSgKiCtHudBRWfmZYwjFaDBCezuarllWdrlhuSLlrlwftWFuHTinFgJYgcZDqjuynNkqrzjDzoYFXMGAXoO")) {
        for (int HBEBGHDUeZORa = 1810049385; HBEBGHDUeZORa > 0; HBEBGHDUeZORa--) {
            JCxTboNz = JCxTboNz;
            JCxTboNz = JCxTboNz;
            JCxTboNz += JCxTboNz;
        }
    }

    return JCxTboNz;
}

string aSZyMf::IgUUaIPHXXXvy()
{
    double xoDBGYyapfW = 780227.4749925467;
    double ZsFtj = -866727.5164492067;
    double GpcsTfNgOZEuoQ = -63785.54267838544;
    int WEUVJlEUEXvIAzY = 2089047586;
    bool nzEccrmnlpzALWVc = true;
    double hLnKMZxNtnYuGSdn = 933639.0238618727;
    bool viuYknQy = true;
    bool qKLCzyvWpTeimjkG = false;

    return string("LUsIsnzsHsCutrseZXrVEuMabZnkYRsjapCiZryYafgqmHPuUtYqntyKLAEDPkOLtvQsEqr");
}

bool aSZyMf::AaflqTScwHfcM(double JhRYorv, string wGwQwvMZopGOhBzq, bool aDHgazL, string BOAhgtQXJ)
{
    double zvTiZOxhhpFEE = -61873.49948255529;
    int QZRQGXnNthBondDg = -1097883754;
    int NIRWN = -1089807814;
    double wCTsI = -343105.2554628137;
    bool uiCRCyfcM = true;
    bool PTPPEBDcZqrqGk = false;
    bool hqybpWj = true;
    string WYkWKNpBMEETJ = string("vZBxbAJHaWdgYRVmxzGfsmwKUIghugtbRHXAWxNdPUuhEcYsesCLKhrBYFMCuhRylGGXPRWVFumQfyvyzPYGCodDJxNEEnpwfNgONAPpOLXmvrbSQgRWERuEzsWJPAChwflSwwjaEkqynnvnaOnPDclONeDfbuhtoXELzBejhVDfguMqcaGIAePbWKRonktdWOZGqMXtlYxehcWpAtLBVXwrSPYYprjwVDGRFLkIqEFHIYhyjPxozvLHalzVYJa");
    string QdqWaxY = string("GebrOgocNLDdacHdHbbakxReHirAkuJatQrQSBgQVBrNgrTmIXBdpRDnFPtvPcmkxhWQdUHQrYPZEpKAZPbDNivA");

    for (int SzPSnwEzi = 871185090; SzPSnwEzi > 0; SzPSnwEzi--) {
        zvTiZOxhhpFEE -= JhRYorv;
    }

    for (int xSFOgguHlKUxhDp = 224779064; xSFOgguHlKUxhDp > 0; xSFOgguHlKUxhDp--) {
        JhRYorv = zvTiZOxhhpFEE;
        wGwQwvMZopGOhBzq = QdqWaxY;
        NIRWN /= QZRQGXnNthBondDg;
        hqybpWj = uiCRCyfcM;
    }

    for (int JAmUhoBX = 2144459796; JAmUhoBX > 0; JAmUhoBX--) {
        PTPPEBDcZqrqGk = uiCRCyfcM;
        zvTiZOxhhpFEE *= JhRYorv;
    }

    return hqybpWj;
}

aSZyMf::aSZyMf()
{
    this->MMoGoRmDyAn(242748.34048248615);
    this->hdmlYRnyZTzAnBI(true, string("nlftdXduFfmDsprWAMHCNNlJRjdZtuborzBwcSnnbwegoUWZuRrwCkFKQMDlqeNGXISPNRGXMKepxrhLVxajQgarloijGjHMoEuJFAIjKXrwISVwAJQIdoRYMnToOxWhUBbUjINwM"), -161306057);
    this->xOpjJHofUKXTrxuR();
    this->qypdPeatNNfU();
    this->LdWuwqyeEAKcR(string("VuPctbVCDdKjPFuxvHRpFngLzDgJcVgVWmzLavxPquWvBsqCHYXAXSarVGluokjPfIBXHsIJEsugvejOGyxjNVqSYvqtTtNwRMAlBnatchogptbWWgs"), false, -769878616);
    this->OGrKdcmPTBZOOGdb(470992090, 209766.43399722897, string("bKtOmOWkLDZkDskiIfGNkGIJCpVpVZfJKSCBXclVYVgxrVJqjpXSrCuXeZfrmZoOVDeOhrLUEhOEIYSZbxYynKHwuesmieLXWztKDkpZiEfKUfmaoJWVHHnvqjxfVquiVJmMEoiKogYlXukRsVAhIkpjmKdvTPPJmjVwYWcjeYrCzIZSCBgSWuCZgXotNLgbbaJvifEXteLLDwwyLBc"));
    this->uDTRe(string("xJyQkcRZdvqXtPHbMKRxAUtVWuOWPqpZNdsZBhUWLhmyYsKcRHVgUyxQMgjPrJyOnsemsmAKlHDBxPARSBTxxIuoddsfoKUeKJSOkibvzbLgvJvasHOnWcpMnoHeVaKVpuuYhHlRFrNiaowTcapfyZfHPAKkcDOtQlXswQdXyGDMdjvZDxCxQtMPKWPADGOiMWhGIClvkXOMpGAiIrpOHeYehUHioxaFJqL"), 837597529, false);
    this->pTnoFWSAmev(935132.2267243174);
    this->jmDsfhTu(-534613.8309052052);
    this->MbBXgHmMCwE(-125212.50850147972, string("g"), string("bgbaEyvvafJvN"), true, true);
    this->LPLQXsJVucdj(471905.7709536175, -1748009573);
    this->MMNLYNEQqqNAqB(string("viWDnouADPzREHtVJFiFIhjNeDHCREYCjGgZMmBKWAiNuqWWEbksrwAPbIgmAgBkskXKByviXFzTwjuAFEQMwsYtXBuUxzdiOxNiJwWwteKDLxQjADudUoetGzWXdYfEwaVQuhSKPnFNszjJsZfwpdfsvZtwRlTBPxBajyMzYurrnTNzvlqXHXkBZeFjnvjpGuAhbklVnvMvlqbVRpFjohuIxNnLUHaMvDhIVkYRinPRMYSzXAwMQqJW"), 536155.3348842118);
    this->fBDWqUkxD(false, string("KzRJDbIxtmoSVgyuRpKGIUxXMXdOmvQIOaKFgTyskGhqxHjZUvYJUUHshQUHLOVAUYnlxXNNEqUbENRQUOzazeYpQlDGOcjgRtSoLUWOgFrBwbOAasPukRpfSusbzDrNLRKbJnxsYE"));
    this->teNMGxXG();
    this->IgUUaIPHXXXvy();
    this->AaflqTScwHfcM(57833.911455692745, string("eeBSNQjYGcSkfSFDjbDzNrpyMyxKbfRDVkJIXFoeVJCGxGMozsUDswHdVCUzcLBARQoyRdwIAKGkIejRzYoBeJbuxuuLawpDMpWEYNBUmKmHvzhFCsRUXmMmeypqIsfgTYMqhpVQCGTzWOfLMBwXozCdIKqAcujscegpMPToSVTUigsnCaSvenlzbuyPeQHZAVkjxzCdhWmyyZyvrRSLrcUHLtaSnKLFdtLoELzAAjdUxb"), false, string("QUaNroGXuEpUURFgTmIfWMNYxaETxWNJqFYNqOkZdPGRMwQwejwodgivNQbGCmtMRmSXNzowBEFeyFsCdOnoPpErYkJfPFGBoeNOylsNVnYEsfCycEFfylfkEMlIxigsJcSSaAQPnepPrAfwutnZPXsgEoahoNYUMfAmOzluQXjCkIIvUxFrLCzhNDRjCDaHPwpQzeQumtkGlNRRfIiQTOeesqvwHiVPEvISMaNaIlpDyNwfTUjpOqgxUPoy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KixENFvYsLLy
{
public:
    string ICkBwUDyxyJIXXZ;
    string fUZVHUc;
    int sZwNEitdNzQj;

    KixENFvYsLLy();
    void gdUPxWzMGk(bool tNwjObcjOo, int PMKFaLl, int HKtIXde);
protected:
    string DhLHLgjUmWajjtI;
    string xBEyeFEQXKYN;
    bool smiGvVGSV;
    string mQRUsCzETN;
    double PiUOyFgvpnhdoc;
    double hLaLqWisB;

    int nvbPvcWxwHkCaY(int YFPeXVWuoHqtRXiY);
private:
    double IuAEveFkJalIn;
    string DMSzN;
    string ZdilZHeVl;

    double odlQSrdgERDNR();
    string XeTDczKNzPMXq(int gzqvbX, int gycUwmwUx, int KxrgUJ, double LXQxTjVSZTJtWM, double NvUinyrd);
};

void KixENFvYsLLy::gdUPxWzMGk(bool tNwjObcjOo, int PMKFaLl, int HKtIXde)
{
    double UdyZYtiXqCHeIu = 738639.0719238202;
    string gAVxnFUzwCuZ = string("HzeuDzqEwtWjsZsgGLSpQSbPQlYAxzLcEibiCgPEIlVtoRDiKCNioLkEtBERTbpTrUYCk");
    double opWWnOZjx = -207977.81125586454;
    int CUbSKMJsoHaSV = 1534108410;
    int lGlSFmeiQZ = 1492793588;
    double mULvtedBaDAjYI = 962564.5972685233;
    int QWfouSFMB = -248180457;
    bool jrRjIAhqgbf = false;
    double xsodhOfQXQQvooN = -849824.3656537861;

    for (int hBLjojdVMGAk = 25535238; hBLjojdVMGAk > 0; hBLjojdVMGAk--) {
        QWfouSFMB += lGlSFmeiQZ;
    }

    if (lGlSFmeiQZ >= -248180457) {
        for (int svDfTW = 1942965530; svDfTW > 0; svDfTW--) {
            xsodhOfQXQQvooN -= opWWnOZjx;
            PMKFaLl /= lGlSFmeiQZ;
        }
    }

    for (int IpScawBQlU = 701537986; IpScawBQlU > 0; IpScawBQlU--) {
        jrRjIAhqgbf = jrRjIAhqgbf;
        QWfouSFMB -= CUbSKMJsoHaSV;
        opWWnOZjx /= xsodhOfQXQQvooN;
        lGlSFmeiQZ = lGlSFmeiQZ;
    }

    for (int DNKyNtH = 746426028; DNKyNtH > 0; DNKyNtH--) {
        CUbSKMJsoHaSV /= PMKFaLl;
        UdyZYtiXqCHeIu += UdyZYtiXqCHeIu;
        xsodhOfQXQQvooN /= opWWnOZjx;
    }
}

int KixENFvYsLLy::nvbPvcWxwHkCaY(int YFPeXVWuoHqtRXiY)
{
    double MGCEUbJnhKO = 940039.2698320964;
    string npZpKpeUE = string("nlCiqeKeWldHGJEKvzeiQapoJgLEUSxJuJKzzdAmQzxFuICJVKY");
    int DYHVma = 850454422;
    double MBBoQIfiLTLi = -841747.104321361;
    string NkZFwBO = string("vLfretQVRyDcVCRtVXrDtUGbelaLJCjwFSqMKfXgxzBYTXiiGsDqfPBrEneqPallPV");
    string kmDjvXyBTsVeY = string("nKiobfaDPKZXzYZENoCOizvpDjirLwHwcnjhdzlZcOubDyScNqloCsgztkLWQHCeEWooaNLzgGPfIMGkganiirysrzwBkylfUWMeyhsLArdqmnrIGuJqvaQFcoikb");
    double yjrWKutx = 28547.38137556153;
    string nGYeDGuo = string("dXffQdmknrdPtIgFvakzSOzRupHXHzPzQSsGVYaJqzEXaAJRsHVfiNQJEZzLJJkvyXfdfPhqYxJJZlgQpIveZayczaVfrGUwcuveDulRIeplhBHhnTKhyeCaHPOYwtOffIIlzSwcPw");
    bool nwiKgKtUYMhzOuT = false;

    for (int KMSqy = 614996983; KMSqy > 0; KMSqy--) {
        npZpKpeUE += NkZFwBO;
        NkZFwBO += nGYeDGuo;
    }

    for (int DlhXN = 800944659; DlhXN > 0; DlhXN--) {
        DYHVma = YFPeXVWuoHqtRXiY;
    }

    for (int tzneosOEz = 138027569; tzneosOEz > 0; tzneosOEz--) {
        nGYeDGuo += nGYeDGuo;
        npZpKpeUE += nGYeDGuo;
        yjrWKutx *= MGCEUbJnhKO;
    }

    return DYHVma;
}

double KixENFvYsLLy::odlQSrdgERDNR()
{
    double DRDXPcCjd = -313596.2171782186;
    bool FjVhivksX = false;
    string SqxGLQF = string("nViAVUFcPgriKzeimsLpdNmEDdySPSTxnTwzsDMQLrSQxLnCiMduCqEGGLMcOGZQBCIuUwSpcaTqpaECoUCdQMYGGLECIZBxLAXsCGEuAZmjMYbvKPQzfXOlUKcwpyZpavPZhbCrBFhJgLyLZxzAUZFdzEpqJVOrnwQpMuHrGhqPpbTqfKEUtGxQHAKXe");
    double ysfqhqxyCTJy = -248389.8043219837;
    bool rqXLmpAhQOels = true;

    if (ysfqhqxyCTJy != -248389.8043219837) {
        for (int dzrKDNIsztKXor = 1302759171; dzrKDNIsztKXor > 0; dzrKDNIsztKXor--) {
            FjVhivksX = rqXLmpAhQOels;
        }
    }

    for (int eQvanaX = 1671713526; eQvanaX > 0; eQvanaX--) {
        ysfqhqxyCTJy -= DRDXPcCjd;
    }

    return ysfqhqxyCTJy;
}

string KixENFvYsLLy::XeTDczKNzPMXq(int gzqvbX, int gycUwmwUx, int KxrgUJ, double LXQxTjVSZTJtWM, double NvUinyrd)
{
    string KwiRsqjhhyseXQB = string("lyupIsxqCfqbQRuCYQErRwrRREgiKypbZIJuhtiEmTwNFtcIZbOvbSFDhKgIsdLyBZJzmQcBpOCbdiWEEDwTjLCbiWirWQIeVoPTZormifIRBwPyUAkhysZPbmTsEPjqpAlIMWhrzqDiGJghwIOtZWjdTWYREpSyfthhGxcvKrWIGiWOuPhSdIASFKenNJzumlljgDAV");
    double GOzRSGiaPqAZ = 644887.6135352231;
    double BAmXBAYgl = 79498.63359162201;

    for (int YMYLElCvZ = 878219886; YMYLElCvZ > 0; YMYLElCvZ--) {
        gycUwmwUx /= gzqvbX;
        KxrgUJ -= gycUwmwUx;
        GOzRSGiaPqAZ = LXQxTjVSZTJtWM;
    }

    for (int ptKjAbcjeRH = 1916571221; ptKjAbcjeRH > 0; ptKjAbcjeRH--) {
        GOzRSGiaPqAZ = GOzRSGiaPqAZ;
        GOzRSGiaPqAZ *= NvUinyrd;
    }

    return KwiRsqjhhyseXQB;
}

KixENFvYsLLy::KixENFvYsLLy()
{
    this->gdUPxWzMGk(true, 440954135, -1162487821);
    this->nvbPvcWxwHkCaY(271132394);
    this->odlQSrdgERDNR();
    this->XeTDczKNzPMXq(90212790, -1125495352, -279820372, 626370.9237670747, -701633.2888955311);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QPcWfexZVRjNNujV
{
public:
    string tPPOJmtciFidLO;
    bool XBKimuKTFc;
    int dkpgKUHXjfTon;
    string dNlRGkdruykN;

    QPcWfexZVRjNNujV();
    double rPWpsoUg(bool mUdzRMh, double zOHgsrwIKjh, bool FFKyBghxjUqSeY, bool uDeGaEa, int PQYvbfic);
    bool gWkzFQEcunknsTN(int wlJSOAiftykiCYmM, bool MJQNHiPshYIHwdp, double taAFNN, int mnLSttNAZhNw);
    int pmKBtjiQco();
    string WmuMj(double mUHEvVoVhxJZ, double BOzFUejtJXL);
protected:
    bool PxKSOnkIfH;

    bool QSJLCeNyMtQsJH();
    int zeeQnU(string cOZnPACwhL, double BytEkIcKhP);
    int TALrjxTi(bool aQLeMPGJ, double fBuDYJWZ, double yQnlX, double aEEnSvlSRrWxOJ);
    string fQaKthoaXUoBQRq();
    int jvWARdORxubinWAx(int DccRTylQPYk);
    string fFyDpdeeqcCH();
    string kQtIhLdXXLEFsbOV(int habmxEpkIq, int ukKRH);
private:
    string VTgecEpVhhI;
    string wGJOkalC;
    bool IURiA;
    string eVKbjqv;
    string kYQbwMyxXuJrpC;
    bool wRNHeyaOsCFKNxO;

};

double QPcWfexZVRjNNujV::rPWpsoUg(bool mUdzRMh, double zOHgsrwIKjh, bool FFKyBghxjUqSeY, bool uDeGaEa, int PQYvbfic)
{
    bool RUiVXGkBSomdU = false;
    int OxzhmHWJO = -1080277535;
    double JgEsmCyJvZdzbkpq = 688056.118169876;

    if (FFKyBghxjUqSeY != false) {
        for (int obEteL = 274919317; obEteL > 0; obEteL--) {
            PQYvbfic /= OxzhmHWJO;
            RUiVXGkBSomdU = ! uDeGaEa;
        }
    }

    for (int xconNDKGMmGFSC = 1228076669; xconNDKGMmGFSC > 0; xconNDKGMmGFSC--) {
        JgEsmCyJvZdzbkpq -= JgEsmCyJvZdzbkpq;
        uDeGaEa = ! RUiVXGkBSomdU;
        OxzhmHWJO /= PQYvbfic;
        FFKyBghxjUqSeY = mUdzRMh;
        PQYvbfic -= PQYvbfic;
    }

    return JgEsmCyJvZdzbkpq;
}

bool QPcWfexZVRjNNujV::gWkzFQEcunknsTN(int wlJSOAiftykiCYmM, bool MJQNHiPshYIHwdp, double taAFNN, int mnLSttNAZhNw)
{
    int ulPdFKdP = 179179546;
    string YfiyYxaEcjcchJ = string("ATqHMcyssSzzRoScvunXXObYXXO");
    double YKufYoRU = 746450.8276891387;
    bool hdbsZmUXvKrBXUdG = true;
    string OIuQgZaG = string("LgTbhUoue");
    string uGVKJNrs = string("GtCiDWwqzsprUscCoXkLVAAdLDivdXvuMu");
    string GrrCMZJgPByPUp = string("cwavZZgdCvFdRkpMQaslDgzuGmSuYQHeCsFHTxjxCeaKCPIHWxizBDKXZCRikebyUaAJFUihIWsVTukWFcdGUASWxMbbbmYxSpXaEkggkzjSgXTdGYaVpoxzFknaWgHaVQVKIhprmlUcGimhviyMNrgwtQcVTewceKcEQtAKseCyEnPthcaAJsMhKexoLxzVVXRzroGPgtDVYO");
    double UEifCGJEUEhp = -718539.6656658513;

    for (int zhSPj = 891126369; zhSPj > 0; zhSPj--) {
        continue;
    }

    if (taAFNN == -718539.6656658513) {
        for (int iNIahdJ = 981725344; iNIahdJ > 0; iNIahdJ--) {
            OIuQgZaG += YfiyYxaEcjcchJ;
            UEifCGJEUEhp = UEifCGJEUEhp;
        }
    }

    for (int uKOvxSDDtDnf = 1728235392; uKOvxSDDtDnf > 0; uKOvxSDDtDnf--) {
        taAFNN = taAFNN;
        UEifCGJEUEhp = UEifCGJEUEhp;
        ulPdFKdP += wlJSOAiftykiCYmM;
    }

    return hdbsZmUXvKrBXUdG;
}

int QPcWfexZVRjNNujV::pmKBtjiQco()
{
    string FRJabGJKbgew = string("hSrvdOrZZZvxvfgRXJJaniHrmwALGyGFUaCUWCfkCMcWIxFgkETjYNjqPaWnoobddCGwLUftfhEpibT");
    string vhcvymcIdueS = string("nqmPggnsxSwVOusyUVyDHjwEfubozHacFozmhugsiuyTOfaFZdNurnwQGmMEMOOtjSW");
    bool LfVeuuR = true;
    int nMteVeIwUqDgIVJ = 543007727;
    bool tgJarFXIkBaNWBqG = false;

    if (FRJabGJKbgew > string("nqmPggnsxSwVOusyUVyDHjwEfubozHacFozmhugsiuyTOfaFZdNurnwQGmMEMOOtjSW")) {
        for (int ynUapAclue = 90123130; ynUapAclue > 0; ynUapAclue--) {
            nMteVeIwUqDgIVJ -= nMteVeIwUqDgIVJ;
        }
    }

    for (int YdSqQiRELJAdhzXI = 794756680; YdSqQiRELJAdhzXI > 0; YdSqQiRELJAdhzXI--) {
        LfVeuuR = ! tgJarFXIkBaNWBqG;
        FRJabGJKbgew = FRJabGJKbgew;
        tgJarFXIkBaNWBqG = LfVeuuR;
        nMteVeIwUqDgIVJ += nMteVeIwUqDgIVJ;
    }

    for (int cuInySbieObxVI = 969221533; cuInySbieObxVI > 0; cuInySbieObxVI--) {
        nMteVeIwUqDgIVJ += nMteVeIwUqDgIVJ;
        LfVeuuR = tgJarFXIkBaNWBqG;
        tgJarFXIkBaNWBqG = tgJarFXIkBaNWBqG;
        nMteVeIwUqDgIVJ += nMteVeIwUqDgIVJ;
        FRJabGJKbgew = vhcvymcIdueS;
    }

    for (int vtDWahnvYtKhTUBm = 1029319868; vtDWahnvYtKhTUBm > 0; vtDWahnvYtKhTUBm--) {
        FRJabGJKbgew = vhcvymcIdueS;
        FRJabGJKbgew += FRJabGJKbgew;
        LfVeuuR = tgJarFXIkBaNWBqG;
        vhcvymcIdueS += vhcvymcIdueS;
    }

    if (LfVeuuR != true) {
        for (int XeqsKjyAspn = 1705982324; XeqsKjyAspn > 0; XeqsKjyAspn--) {
            continue;
        }
    }

    return nMteVeIwUqDgIVJ;
}

string QPcWfexZVRjNNujV::WmuMj(double mUHEvVoVhxJZ, double BOzFUejtJXL)
{
    bool vRplDMnP = true;
    bool SVvOdIRVB = true;
    int iACGBQdRYfTrLpr = 988006207;
    bool xxjyBYDPM = false;
    bool vtkVMUFxrbfMgkbN = true;
    string GtUMvaUvR = string("lXBJATnuSDhXuNzIVvgvOQbkRYcElNgAacZCZCQYNywGxhdGefGRMeKkUGhotjpYLyQApWardUPNpsvgLSZAzeLwXPPFMdBNBrTTgWftCYuMiOdFcdPCQt");
    bool wGUGxJD = true;
    double pnJdRCvsjYWdLeKZ = -604105.9467011518;
    double gWBMnxVA = 26795.70682177751;

    for (int WCTHE = 969343915; WCTHE > 0; WCTHE--) {
        continue;
    }

    if (wGUGxJD == false) {
        for (int nUIMCRM = 896643146; nUIMCRM > 0; nUIMCRM--) {
            mUHEvVoVhxJZ /= BOzFUejtJXL;
        }
    }

    for (int BvnCHDH = 1751963592; BvnCHDH > 0; BvnCHDH--) {
        vtkVMUFxrbfMgkbN = ! SVvOdIRVB;
        mUHEvVoVhxJZ += BOzFUejtJXL;
        mUHEvVoVhxJZ = BOzFUejtJXL;
    }

    if (pnJdRCvsjYWdLeKZ < 974203.4747196137) {
        for (int gLxjULMDltvk = 1941680267; gLxjULMDltvk > 0; gLxjULMDltvk--) {
            continue;
        }
    }

    for (int qAJLGIFHjBRQwv = 1871319101; qAJLGIFHjBRQwv > 0; qAJLGIFHjBRQwv--) {
        continue;
    }

    if (vRplDMnP == true) {
        for (int LZtaRz = 2105279710; LZtaRz > 0; LZtaRz--) {
            wGUGxJD = xxjyBYDPM;
            vRplDMnP = ! SVvOdIRVB;
            SVvOdIRVB = vRplDMnP;
            vRplDMnP = vtkVMUFxrbfMgkbN;
            mUHEvVoVhxJZ = BOzFUejtJXL;
            vRplDMnP = vRplDMnP;
            xxjyBYDPM = wGUGxJD;
        }
    }

    return GtUMvaUvR;
}

bool QPcWfexZVRjNNujV::QSJLCeNyMtQsJH()
{
    bool mPzEyaacqeyKl = true;
    int jfpJcku = 437146487;
    string ANHCaWbywQuY = string("suiyjoDJypJBFLbttIYEEItSEDbycKuMddoWWAOtDbuqvDMOyzVPcSFQirDsoYJzGfEYNOlkvyaIATqsYMJNCUaoMBhsdcnBBOPYiUntqviykpScYcJLKpCXhjfuGbH");
    bool gvejUBoAIH = true;
    string qNGgdjG = string("KRkiarvFQTEXXgcmJMerHSYYzPGIjtKYFAdruqAdsLbybtxzABhLSbhRWiHyitqqhIhcsACfWQUfinnHWwZHpQzWIjcMzvTbyILJmtzeJzADTQgrLQkHPXeILWYKbFONFyLbeKCiRTIUAtkiLJpdCsGmNLwDuPnXDfJPnanWnqeOfyZeFuJlraqBnpzsmenMUrQajm");
    double OKdEIwbvBXdmXX = -160648.65187764974;

    for (int bzPDCu = 549980117; bzPDCu > 0; bzPDCu--) {
        continue;
    }

    return gvejUBoAIH;
}

int QPcWfexZVRjNNujV::zeeQnU(string cOZnPACwhL, double BytEkIcKhP)
{
    int mUnZA = 1099492635;
    int gGNOdQpoNYLKCGt = 2012559931;

    for (int AMHkYuutNYLsqh = 2058360620; AMHkYuutNYLsqh > 0; AMHkYuutNYLsqh--) {
        gGNOdQpoNYLKCGt *= gGNOdQpoNYLKCGt;
    }

    for (int UuvjpSOmeUclziAK = 204736351; UuvjpSOmeUclziAK > 0; UuvjpSOmeUclziAK--) {
        mUnZA -= mUnZA;
        gGNOdQpoNYLKCGt -= mUnZA;
        BytEkIcKhP = BytEkIcKhP;
    }

    return gGNOdQpoNYLKCGt;
}

int QPcWfexZVRjNNujV::TALrjxTi(bool aQLeMPGJ, double fBuDYJWZ, double yQnlX, double aEEnSvlSRrWxOJ)
{
    int HkbHBZEBMkMma = 952882627;
    int weUChplBYxGPVrg = -1607112094;
    bool YrJVt = false;
    string fWYer = string("oSQKRwzvZMACYSKaULELSdMQbfANLiAmywiQVlgMfbxwxevNRKJWvqBqrYaSsmVMvdRuFyRmREPCsxDKCMtYGJaRrglJOoMimGqHiOenpfkBNRvvYBtRatmaGyQukiAYKhAALxYICxBNLDFb");

    for (int xZaJBBJTTJxridA = 268674788; xZaJBBJTTJxridA > 0; xZaJBBJTTJxridA--) {
        continue;
    }

    return weUChplBYxGPVrg;
}

string QPcWfexZVRjNNujV::fQaKthoaXUoBQRq()
{
    bool vUTzQoKgUQWBzycF = true;
    string YswbcjtLXVEKPw = string("mrSVsHlHAJutKVVibVIoNSILYDNgyRweGNbqLbHCGKoeHUrOvnDfpzAuijqiLqeiFLvndaNwpiRSMkkdamFUbVUYoXfnlpbDUxtwZUpctdKBbppzyDSZdDNmAULIijdpSIyQwpeUlKU");
    int AboKaAdb = 811882460;
    int oqAKeplUyZmfFN = -590617523;
    string KhmEooWF = string("LcJUzqhwVtZnzkNYmvAaHaYFqtKgQJBKAdQijPBTIpxleWqheQuGLtOKaHcTIiZsrwbflXShfxxYGcFnxtnElDHYrcLKskUpHzVWQwaozQorypcvLXLiCTgcRihAJKnRoZfOjcdbhsldITJeWeyzsfTzQr");

    for (int DPIXQKoJ = 1935458851; DPIXQKoJ > 0; DPIXQKoJ--) {
        continue;
    }

    if (vUTzQoKgUQWBzycF != true) {
        for (int ABVJnXKDb = 77672347; ABVJnXKDb > 0; ABVJnXKDb--) {
            vUTzQoKgUQWBzycF = vUTzQoKgUQWBzycF;
            oqAKeplUyZmfFN = oqAKeplUyZmfFN;
        }
    }

    for (int lQFcRx = 1415002339; lQFcRx > 0; lQFcRx--) {
        KhmEooWF += KhmEooWF;
        YswbcjtLXVEKPw += YswbcjtLXVEKPw;
    }

    for (int jjlcZVrc = 714024670; jjlcZVrc > 0; jjlcZVrc--) {
        KhmEooWF += YswbcjtLXVEKPw;
    }

    return KhmEooWF;
}

int QPcWfexZVRjNNujV::jvWARdORxubinWAx(int DccRTylQPYk)
{
    string VPOIuaJcpEtR = string("CeUIRQjKpFFyZuallRBgnNYFdhiiVIZAcmdgkydJGllMiHgxyqXXSCGOwEMMKTSSKxZMYOcqkPUVPKghydIUjOkcXXaFH");
    int HrSvPVCdx = 452794690;
    int kYinPe = -1525127023;
    bool VWnthAFFRo = false;
    string tRzGDFrV = string("cpxNHZVXVpDDvOkXacvfWQMoBXvQPB");
    int JjGeI = 1228466615;
    double FhEJRVtxS = -51244.15641726198;
    string xizqyaPUNVs = string("yhHrOcaLGLNanRxYxKnUKiMGfPSmkCZVKxZYMSBwZWcTaESgvoTXOgGPFnVlZrLRjfkqSRiaeDckiuWHgAmXJjoZSibhlIsGnBXThENXQeNB");
    double IdBHv = -320605.9750606971;
    int QgUwT = -1937849169;

    for (int hBKNSJvWMJvBW = 1130472026; hBKNSJvWMJvBW > 0; hBKNSJvWMJvBW--) {
        IdBHv += FhEJRVtxS;
    }

    if (DccRTylQPYk == -1937849169) {
        for (int ntCGrxmlao = 1072291690; ntCGrxmlao > 0; ntCGrxmlao--) {
            continue;
        }
    }

    for (int GysyTjFZUGPTTbL = 373565048; GysyTjFZUGPTTbL > 0; GysyTjFZUGPTTbL--) {
        HrSvPVCdx -= QgUwT;
    }

    for (int QEXpKNtjpueBtem = 1757587189; QEXpKNtjpueBtem > 0; QEXpKNtjpueBtem--) {
        HrSvPVCdx += kYinPe;
    }

    for (int SerUlQzLNLCAljS = 976841874; SerUlQzLNLCAljS > 0; SerUlQzLNLCAljS--) {
        HrSvPVCdx /= DccRTylQPYk;
        HrSvPVCdx = DccRTylQPYk;
        xizqyaPUNVs = tRzGDFrV;
        VPOIuaJcpEtR += tRzGDFrV;
        HrSvPVCdx /= HrSvPVCdx;
    }

    if (HrSvPVCdx != 1228466615) {
        for (int ATReTNjRyerX = 676651135; ATReTNjRyerX > 0; ATReTNjRyerX--) {
            continue;
        }
    }

    for (int weaadaOkhAL = 990396645; weaadaOkhAL > 0; weaadaOkhAL--) {
        JjGeI = HrSvPVCdx;
    }

    for (int JSylwPHmjeZdSw = 126620434; JSylwPHmjeZdSw > 0; JSylwPHmjeZdSw--) {
        VWnthAFFRo = VWnthAFFRo;
        JjGeI -= JjGeI;
        HrSvPVCdx *= QgUwT;
    }

    return QgUwT;
}

string QPcWfexZVRjNNujV::fFyDpdeeqcCH()
{
    int dcaNEpErlSBCtWD = -804556336;

    if (dcaNEpErlSBCtWD < -804556336) {
        for (int AvlZjYvDpJXp = 2057947594; AvlZjYvDpJXp > 0; AvlZjYvDpJXp--) {
            dcaNEpErlSBCtWD /= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD *= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD -= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD = dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD -= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD -= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD -= dcaNEpErlSBCtWD;
        }
    }

    if (dcaNEpErlSBCtWD >= -804556336) {
        for (int GTUtSpQB = 1638950231; GTUtSpQB > 0; GTUtSpQB--) {
            dcaNEpErlSBCtWD = dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD /= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD -= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD *= dcaNEpErlSBCtWD;
        }
    }

    if (dcaNEpErlSBCtWD > -804556336) {
        for (int MbhTFxHkrMvXAK = 1873790784; MbhTFxHkrMvXAK > 0; MbhTFxHkrMvXAK--) {
            dcaNEpErlSBCtWD += dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD *= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD /= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD *= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD -= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD = dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD += dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD /= dcaNEpErlSBCtWD;
        }
    }

    if (dcaNEpErlSBCtWD != -804556336) {
        for (int NHYwt = 1246895844; NHYwt > 0; NHYwt--) {
            dcaNEpErlSBCtWD *= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD -= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD = dcaNEpErlSBCtWD;
        }
    }

    if (dcaNEpErlSBCtWD <= -804556336) {
        for (int RamBbmyxPwLIvO = 1988595817; RamBbmyxPwLIvO > 0; RamBbmyxPwLIvO--) {
            dcaNEpErlSBCtWD /= dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD = dcaNEpErlSBCtWD;
            dcaNEpErlSBCtWD += dcaNEpErlSBCtWD;
        }
    }

    return string("xksBRWEyEcIlvApQRJDgOTZhOqeMsKaLZZUNMnXGEJLOnZRtMiPhvXdMlozrIOrjPdpwHStfBKrOICvgsGakgZlHBoKfiHFrLLwjcDovgKouBZFrvQtqrgoiMzeiJUZcBaSXDoPvGDzwqQqmjMjkAUdplQZZVEMekJWinCqjvZJOdNBHJpMeVkbhxoynyCPfAaEdWWvQffgMRsIWLQoEYVopRxrbrHgUJGrkRGIhyDKqDAC");
}

string QPcWfexZVRjNNujV::kQtIhLdXXLEFsbOV(int habmxEpkIq, int ukKRH)
{
    string FgwsxbOUmI = string("atKCFUaWOizrvnILxjOyIxErlIcyyjZviCduQEdTxeMyxXrjWInYPXCkzuLcNNJMtnqAnRuJjXboywrpZWOUmxNRpDuFgCATSakNQjGqjKXjILlCaTqRNwhCNanUfdqzxiRztTBmktWeupEgOWWeXcKvfTvBiceCijgKKJyaNOyvJDEEknjhCDqwPICNsRIlQORTkCesoxQxDpbtDBibhMEVlXEzDRdlAkpIJG");

    if (FgwsxbOUmI >= string("atKCFUaWOizrvnILxjOyIxErlIcyyjZviCduQEdTxeMyxXrjWInYPXCkzuLcNNJMtnqAnRuJjXboywrpZWOUmxNRpDuFgCATSakNQjGqjKXjILlCaTqRNwhCNanUfdqzxiRztTBmktWeupEgOWWeXcKvfTvBiceCijgKKJyaNOyvJDEEknjhCDqwPICNsRIlQORTkCesoxQxDpbtDBibhMEVlXEzDRdlAkpIJG")) {
        for (int YItsGqgbbVvgQyEM = 1011896221; YItsGqgbbVvgQyEM > 0; YItsGqgbbVvgQyEM--) {
            ukKRH /= habmxEpkIq;
            ukKRH *= habmxEpkIq;
            ukKRH = habmxEpkIq;
            ukKRH *= ukKRH;
            ukKRH = ukKRH;
            FgwsxbOUmI = FgwsxbOUmI;
            FgwsxbOUmI = FgwsxbOUmI;
        }
    }

    for (int EFKWP = 1227925406; EFKWP > 0; EFKWP--) {
        habmxEpkIq /= habmxEpkIq;
        habmxEpkIq -= ukKRH;
    }

    return FgwsxbOUmI;
}

QPcWfexZVRjNNujV::QPcWfexZVRjNNujV()
{
    this->rPWpsoUg(false, -369524.2181646787, true, false, -1939405581);
    this->gWkzFQEcunknsTN(1839002321, false, -792099.0232609544, -525981987);
    this->pmKBtjiQco();
    this->WmuMj(974203.4747196137, 680198.7369072392);
    this->QSJLCeNyMtQsJH();
    this->zeeQnU(string("oiVqWKhfmutJoYCbZuPIEYnDbwAxAlKncWMdGaUMdeseLJHvDWRdexqWsqaHCPQEJIDZLUcyVyOcDajsoVwuQslhjmNBNurcbxMdERwDqtOLxmLxKFtwbzzagWCRXuQCBEVNmCwDWJLWTfjIxhdpoUmhaVAHfqIiMyMzLNyScHqJt"), 2955.036753053005);
    this->TALrjxTi(true, 436238.4695042291, -786634.187265101, -794063.6869295381);
    this->fQaKthoaXUoBQRq();
    this->jvWARdORxubinWAx(-1115845885);
    this->fFyDpdeeqcCH();
    this->kQtIhLdXXLEFsbOV(-2070710436, -873822358);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RqFyhQJbHBfy
{
public:
    double PDjoC;
    int buwrseRi;
    bool QRtdyJxCiEotHr;
    int BwOPTKXCcAZtP;
    string ylTHDUioih;

    RqFyhQJbHBfy();
    void CTrshEqWvaupnmqn(double vKPNFAENCc, double YOfQJevaPk, double ejBfawaf, string uBFNzAPHnlPAG);
    string aCroiHefNqsYdjD(int bAZhfJVKUBIWRW);
    bool xGNtMUnzg(int InZJFj, int IMbYx);
    int AtYpvd(bool mPjCzLm, string mUqiFCjLbTQuhUU);
protected:
    int mFrOANlHNjbhDIXS;
    bool yBLMSoOvZzIiuObN;
    int LEYgCA;
    bool fFzxJyVmoAolcfK;
    int EJpJVyMf;

    bool nsXbHxuXCugOEsVI();
    void vjVdRWj();
    int BFXcrEMlPylbT(string bYMoKRNotZkudrx, bool OJkCm, int THtSIwgfPYaBLZ, string SKOFAURfTof, string eXbxRyFYzGkY);
    bool aZUeZjEZ(int bQxqxsbq, double dUOVSV);
    bool WEsfVd();
    double JZlUSuOcXjlpGB(int PFWXl);
private:
    double cvZHPHIkww;
    int QRWFioo;
    bool HWOUBwYv;
    string nYMpIegkriKlao;
    string MsYPWWRcQdLUcQXM;
    string YrkAEnDFAZW;

    bool wSKmIKP(double KngxwSOqJFR, bool vHbDhUE, bool GtUDANMOg, double sbrcAPoKLuwywl);
    void RFvQFokcj();
    string MnTkLtBkrvQeE(double IgQbzad, int SrPPnWVa, double QcXDmNGUEYcMb, string TcKRfSIJrSTxqVrD, int gBRCPRvoz);
};

void RqFyhQJbHBfy::CTrshEqWvaupnmqn(double vKPNFAENCc, double YOfQJevaPk, double ejBfawaf, string uBFNzAPHnlPAG)
{
    bool cbxRuUU = false;
    bool RnewBMWshWiWi = true;

    if (YOfQJevaPk >= 545208.6432625521) {
        for (int IJIQFoO = 1027760224; IJIQFoO > 0; IJIQFoO--) {
            vKPNFAENCc /= vKPNFAENCc;
        }
    }

    for (int uFTfeTzCytDzWPTe = 1364075307; uFTfeTzCytDzWPTe > 0; uFTfeTzCytDzWPTe--) {
        continue;
    }

    for (int qmYNtHruYW = 1921194500; qmYNtHruYW > 0; qmYNtHruYW--) {
        vKPNFAENCc /= YOfQJevaPk;
    }
}

string RqFyhQJbHBfy::aCroiHefNqsYdjD(int bAZhfJVKUBIWRW)
{
    bool uNdZdFVnIwLimDJI = true;
    double jtCUf = -1034054.291198689;
    string IgpNuJFdpvNSjMX = string("nvuzJFNqpGKqhUuVtuUMBuHyJKbXKawLFNgYdJBEMtvqfcVjOQotFdH");
    string EbvSKW = string("jAMhldHryGCOWDYxJrvIsR");
    bool OGAdQFNUSGHbLZW = false;

    for (int HDAZGMDXhBWbXqn = 1692903488; HDAZGMDXhBWbXqn > 0; HDAZGMDXhBWbXqn--) {
        EbvSKW += EbvSKW;
        uNdZdFVnIwLimDJI = ! OGAdQFNUSGHbLZW;
    }

    for (int uuEXjM = 1897148264; uuEXjM > 0; uuEXjM--) {
        uNdZdFVnIwLimDJI = OGAdQFNUSGHbLZW;
        bAZhfJVKUBIWRW = bAZhfJVKUBIWRW;
        jtCUf /= jtCUf;
        uNdZdFVnIwLimDJI = ! uNdZdFVnIwLimDJI;
    }

    for (int sULXfBPodEKGIk = 1123159300; sULXfBPodEKGIk > 0; sULXfBPodEKGIk--) {
        uNdZdFVnIwLimDJI = OGAdQFNUSGHbLZW;
    }

    if (uNdZdFVnIwLimDJI != true) {
        for (int zxcFmfPJaYuJVn = 1828094679; zxcFmfPJaYuJVn > 0; zxcFmfPJaYuJVn--) {
            IgpNuJFdpvNSjMX += IgpNuJFdpvNSjMX;
            EbvSKW = IgpNuJFdpvNSjMX;
        }
    }

    for (int crPikIOUpapPaNte = 1714089487; crPikIOUpapPaNte > 0; crPikIOUpapPaNte--) {
        uNdZdFVnIwLimDJI = ! uNdZdFVnIwLimDJI;
    }

    return EbvSKW;
}

bool RqFyhQJbHBfy::xGNtMUnzg(int InZJFj, int IMbYx)
{
    string lbKsJLCv = string("nuDkwgYMLpBvujiNWwGAkApDrnxwjwcYMhpcVgBoJ");
    string yngmaTnRwdvzQdyE = string("vyqDsDAeSaOJomDNxMLxiDCqlRNicHbdysjRGtNHwWDaTgIRTgZuKF");
    double YfNXOQFUeqn = 100265.5990881561;
    string gAScmMrbWUh = string("YIJaojrNhKyMLVcYQFlnyKFAyCPwEOBJtyYGNlAhysKzWEomIZuvxMwEZnVRopysWZKIvGIYcMedHxDyMbmdyJjAEbFvXzYfcOWDgrltqlLZVYOuIowkBKQcfNHzrBLrvzEjTBvScFtmXjIuEkbnKqdPAxaLFnyIwfnNyMcCPn");
    string ECHfhFwKzGbhg = string("acGGXgwAzdpiGdoGirjVwLkSsMJAKlPgGSucWddFJgpoKTZkdtzLYfTJGWOoMjPvgjgqjZOfVNIoSChPii");
    bool jwuFseNeMdU = true;
    double jMORvwH = 297232.5263928159;

    if (IMbYx > -496582171) {
        for (int PYekF = 723887896; PYekF > 0; PYekF--) {
            continue;
        }
    }

    return jwuFseNeMdU;
}

int RqFyhQJbHBfy::AtYpvd(bool mPjCzLm, string mUqiFCjLbTQuhUU)
{
    bool oEzkrwKIQFAY = true;

    for (int UYvdMWfczp = 743616733; UYvdMWfczp > 0; UYvdMWfczp--) {
        mPjCzLm = oEzkrwKIQFAY;
        mUqiFCjLbTQuhUU = mUqiFCjLbTQuhUU;
        oEzkrwKIQFAY = oEzkrwKIQFAY;
        mPjCzLm = ! oEzkrwKIQFAY;
        mUqiFCjLbTQuhUU = mUqiFCjLbTQuhUU;
    }

    for (int DBWNXxU = 457085821; DBWNXxU > 0; DBWNXxU--) {
        oEzkrwKIQFAY = ! mPjCzLm;
        mPjCzLm = ! oEzkrwKIQFAY;
        oEzkrwKIQFAY = ! oEzkrwKIQFAY;
        oEzkrwKIQFAY = mPjCzLm;
        mUqiFCjLbTQuhUU += mUqiFCjLbTQuhUU;
        mUqiFCjLbTQuhUU += mUqiFCjLbTQuhUU;
        mPjCzLm = ! oEzkrwKIQFAY;
    }

    if (oEzkrwKIQFAY != true) {
        for (int JJcIGKrdstMA = 1811158493; JJcIGKrdstMA > 0; JJcIGKrdstMA--) {
            oEzkrwKIQFAY = ! mPjCzLm;
            mPjCzLm = oEzkrwKIQFAY;
            oEzkrwKIQFAY = mPjCzLm;
        }
    }

    return 686789298;
}

bool RqFyhQJbHBfy::nsXbHxuXCugOEsVI()
{
    int GNbduYQ = 1508176984;
    double TKXmxBrvTn = -661954.1019229735;
    int dKJhELz = 354071114;
    double AgnrYQbVQdnObJ = -533115.7208304632;
    int uolSZAKtVCmuVFvt = -564345437;

    if (GNbduYQ < -564345437) {
        for (int AedcWnHB = 708892240; AedcWnHB > 0; AedcWnHB--) {
            TKXmxBrvTn = TKXmxBrvTn;
            dKJhELz += GNbduYQ;
            AgnrYQbVQdnObJ += TKXmxBrvTn;
            GNbduYQ += dKJhELz;
            TKXmxBrvTn = TKXmxBrvTn;
            uolSZAKtVCmuVFvt = uolSZAKtVCmuVFvt;
        }
    }

    if (GNbduYQ > -564345437) {
        for (int gCmJtvzFeJBOeI = 594375390; gCmJtvzFeJBOeI > 0; gCmJtvzFeJBOeI--) {
            GNbduYQ += GNbduYQ;
            AgnrYQbVQdnObJ *= AgnrYQbVQdnObJ;
            GNbduYQ += GNbduYQ;
            AgnrYQbVQdnObJ /= TKXmxBrvTn;
            AgnrYQbVQdnObJ /= AgnrYQbVQdnObJ;
        }
    }

    for (int OrwQCNRocoYh = 145681691; OrwQCNRocoYh > 0; OrwQCNRocoYh--) {
        GNbduYQ /= dKJhELz;
        TKXmxBrvTn /= AgnrYQbVQdnObJ;
        AgnrYQbVQdnObJ -= AgnrYQbVQdnObJ;
    }

    return false;
}

void RqFyhQJbHBfy::vjVdRWj()
{
    int BZElqTuRTuk = 598084135;
    int MGdTUmTdVc = 1868739134;
    bool rQFTdJyHqyt = true;

    for (int pufzRfpfNqTxBfFW = 1176950082; pufzRfpfNqTxBfFW > 0; pufzRfpfNqTxBfFW--) {
        rQFTdJyHqyt = ! rQFTdJyHqyt;
        rQFTdJyHqyt = rQFTdJyHqyt;
        rQFTdJyHqyt = rQFTdJyHqyt;
    }
}

int RqFyhQJbHBfy::BFXcrEMlPylbT(string bYMoKRNotZkudrx, bool OJkCm, int THtSIwgfPYaBLZ, string SKOFAURfTof, string eXbxRyFYzGkY)
{
    bool qmrHtgpuSAxbfx = true;
    string DMmYRqWbNgiLpPXT = string("WXCHNenssdADJWnmFgTNsaLCwpRJyoXhjnjFgKKZDBWWdOFRjtWWiHpprnKPdenKdhlHiMceQVKPaVQpGOikQWoCEYSuVzkQhgkZKmVOvCLvyJZIBSYHVRiGOqjuGQwKSNxRksLgLQFLgHlZKaiFlanVLfxJyofhLWMfAEWtrZJHVmmFRIxWGOzrlelGFKLdwSkcFwNOvxZugDQTSkMjOJmOZbcMuPgGovYvHNxdAFVHyPRpcmGQsYcaF");
    string tiZmoNo = string("TwOZgEbGooGsaNPvCPGjKMQWelcXFsrCYpAWtNmkTSqgIiRaiInTmsOSKqNvhhxkKUSCFfpcAATPXbtzRFuKuqldujbOlFHfRxvUtBh");
    bool RgfazmvWRsF = false;
    string fKtJj = string("jjDRCNkTshnexwWwWUagVzTFhfMvVEHMJYlSjeZZSfPzUaWZzfCikxbpputwAJzYkJfbQdrxDmZbnzReFveuzassavRIfgvDXOAdszRiUNrxPIJKaMAbRIzFGeTDeDxcACdvBkxMnWnyvxmWjgqvNLaqDwyYDUpDtzPXlQWESwdNiXmagWBkkMUpSssZGNFcDfzoNlfWiHbAh");
    int IOEwoXpyUHJrie = 154683917;
    bool MGcrsOQqCAZhHzHr = true;
    bool RDhccfE = true;
    double UZMfAINQ = 281498.5711946904;
    int NrvKl = -1055471804;

    for (int sDeKWLDSa = 1546033346; sDeKWLDSa > 0; sDeKWLDSa--) {
        SKOFAURfTof = tiZmoNo;
        NrvKl -= NrvKl;
        qmrHtgpuSAxbfx = OJkCm;
        RDhccfE = ! RgfazmvWRsF;
        fKtJj += eXbxRyFYzGkY;
        fKtJj = bYMoKRNotZkudrx;
        fKtJj = bYMoKRNotZkudrx;
    }

    if (IOEwoXpyUHJrie <= -1167816375) {
        for (int CTXzcncLjXYwSJN = 1658868224; CTXzcncLjXYwSJN > 0; CTXzcncLjXYwSJN--) {
            DMmYRqWbNgiLpPXT += SKOFAURfTof;
        }
    }

    for (int BCqWYGWW = 409974332; BCqWYGWW > 0; BCqWYGWW--) {
        continue;
    }

    for (int FtBMubQZUYKNJn = 1479698868; FtBMubQZUYKNJn > 0; FtBMubQZUYKNJn--) {
        fKtJj = eXbxRyFYzGkY;
        RDhccfE = ! RDhccfE;
    }

    if (fKtJj < string("WXCHNenssdADJWnmFgTNsaLCwpRJyoXhjnjFgKKZDBWWdOFRjtWWiHpprnKPdenKdhlHiMceQVKPaVQpGOikQWoCEYSuVzkQhgkZKmVOvCLvyJZIBSYHVRiGOqjuGQwKSNxRksLgLQFLgHlZKaiFlanVLfxJyofhLWMfAEWtrZJHVmmFRIxWGOzrlelGFKLdwSkcFwNOvxZugDQTSkMjOJmOZbcMuPgGovYvHNxdAFVHyPRpcmGQsYcaF")) {
        for (int fgUSwAca = 546835599; fgUSwAca > 0; fgUSwAca--) {
            continue;
        }
    }

    for (int fyEEXOyUv = 1262395901; fyEEXOyUv > 0; fyEEXOyUv--) {
        MGcrsOQqCAZhHzHr = OJkCm;
    }

    return NrvKl;
}

bool RqFyhQJbHBfy::aZUeZjEZ(int bQxqxsbq, double dUOVSV)
{
    string SpdyRu = string("MLVRCpCRSkXwQYMuXMoNWLUPt");
    bool KsBAroexjFr = true;
    int atSpQmHvrGVKyII = -1575310548;
    int cArKb = 1702141696;
    int WKinFsv = 2069078348;
    int dAsRtDYyigNEoldx = -1764446874;

    for (int bAhLlfyzui = 577022083; bAhLlfyzui > 0; bAhLlfyzui--) {
        bQxqxsbq *= WKinFsv;
    }

    for (int WtldtpFouprCpj = 1522160634; WtldtpFouprCpj > 0; WtldtpFouprCpj--) {
        bQxqxsbq = bQxqxsbq;
        dAsRtDYyigNEoldx -= cArKb;
        dAsRtDYyigNEoldx *= dAsRtDYyigNEoldx;
        dAsRtDYyigNEoldx += cArKb;
        cArKb += WKinFsv;
        dAsRtDYyigNEoldx *= dAsRtDYyigNEoldx;
        cArKb = cArKb;
        WKinFsv -= atSpQmHvrGVKyII;
    }

    for (int ymyZiz = 1800167691; ymyZiz > 0; ymyZiz--) {
        WKinFsv = atSpQmHvrGVKyII;
        bQxqxsbq -= dAsRtDYyigNEoldx;
        WKinFsv -= cArKb;
    }

    return KsBAroexjFr;
}

bool RqFyhQJbHBfy::WEsfVd()
{
    int OSIRph = -1602419670;
    int vWaUuivxzyisq = -706575897;
    string GNdSG = string("GjSuncbegQPlhwSjiQgFukQsoRQHzEqdOmBwjWKZbQYoLzICGLyaSVeAFnQHnWyDjspEtmfUhpBJHuubpDcrGYToegOcYYCgrcDdFYkxKMzmBGEFvBiWVyWRurotyogMwMsUGEiHUeUMvGupZBLujjRvFJTZxPOADgTUxKGjJXkFmwTwQHVDxDZpGjDkhWMhfbQstHLBgRiVGBerthEuFAbHPKMANYAmcMHXUHMGfSugDIrHXetMSgy");

    if (vWaUuivxzyisq == -1602419670) {
        for (int gBKmYOaQp = 1848671911; gBKmYOaQp > 0; gBKmYOaQp--) {
            OSIRph *= vWaUuivxzyisq;
            OSIRph /= vWaUuivxzyisq;
        }
    }

    for (int LiFGD = 1549788879; LiFGD > 0; LiFGD--) {
        vWaUuivxzyisq -= OSIRph;
        OSIRph += vWaUuivxzyisq;
        vWaUuivxzyisq *= vWaUuivxzyisq;
        OSIRph = OSIRph;
        OSIRph /= OSIRph;
    }

    return true;
}

double RqFyhQJbHBfy::JZlUSuOcXjlpGB(int PFWXl)
{
    int hMZocBvCZwBcqFee = -313625088;
    string NpKqkRiNdFaYYSX = string("KhnDbdHIdGUxaDibYAdZtxUOQJtZMkKHxgymrOVwtxlkLyNhRbDtPzTqZRZuaGnqCFFGZsGWQTHzsHAQkqTgrpahBDpqtqmcaifSGaupmMjjmwIECTbzYkoEqEgLjTETdhhH");
    bool VSJdmeYPHhRiqLO = false;
    bool HwvNDazaWHU = true;
    string LPlVuhuC = string("EOUkpeJYwiKLxturwMlcmupOflExfeTBNEFBJJHldFiTzOWnfDIwAXHLQBnCYGSybJYKdvtevwQOWPpUDfUnIndwDkBPhBTVLrSqpVQAhydkMDcOMLwOFMmizJrvLePjxQhmwMshfYg");
    bool gxHJfXgDioice = true;
    double SEoHOkFCEZCv = -479470.9251127014;
    int qDRqSfBDjPRLFM = -1901460969;

    if (HwvNDazaWHU != true) {
        for (int eFHudTBixx = 70131797; eFHudTBixx > 0; eFHudTBixx--) {
            continue;
        }
    }

    for (int JyZKTyv = 1240757354; JyZKTyv > 0; JyZKTyv--) {
        continue;
    }

    for (int bFPuI = 616183294; bFPuI > 0; bFPuI--) {
        NpKqkRiNdFaYYSX = LPlVuhuC;
        gxHJfXgDioice = ! gxHJfXgDioice;
        hMZocBvCZwBcqFee /= hMZocBvCZwBcqFee;
        HwvNDazaWHU = ! VSJdmeYPHhRiqLO;
    }

    return SEoHOkFCEZCv;
}

bool RqFyhQJbHBfy::wSKmIKP(double KngxwSOqJFR, bool vHbDhUE, bool GtUDANMOg, double sbrcAPoKLuwywl)
{
    int uHewr = 1426587016;
    double wvLIzz = 215563.09986605795;
    int ssamLbS = -1263146557;
    int FxvYjIZwjeBvmEJo = 123410400;
    double dKSZaAnueazV = -592558.4040321705;
    bool etimSLGkzfuw = false;
    double ECwKaCgN = 304114.65281296684;
    string WKFYGP = string("BthsQbsRDrPCouIXVWHbeJBJsYEXyzngrkKvcMWcIRjtebYfOTkeYOJnDWXwgNTrBIvASDrIgydcqofriILwIdJCaqgylngoiPqjVgVcZiWFmwkQtCoeYWJEeZZMZbEdtnXMzVrhvEcy");
    bool BviUBzNWVqwb = true;
    string KxlBEquyG = string("FsCrnrQfRIGYSQHyxrjtfckHcdItNPfJZLCTpNhvsKbGwTAPYwfZaYCmxpfipQIkjvVhHHaHtEahMcHlhrlblYkSaMyaYbIPAJPyvVRoQqKxOPcNBrvUMNddXRARSRWyxZTncfBOsLCYPopexuAETREKdTvGvIshLvANaNlKxZySMqbebhmMriognDpokUdKlwhjGxuTcFpRvnjHLEqwsYSfIacaAiQfd");

    for (int igIIblhW = 607487728; igIIblhW > 0; igIIblhW--) {
        ECwKaCgN *= sbrcAPoKLuwywl;
        ECwKaCgN *= sbrcAPoKLuwywl;
        KngxwSOqJFR += sbrcAPoKLuwywl;
    }

    if (KngxwSOqJFR != -592558.4040321705) {
        for (int GjXIZbTmcA = 1104940136; GjXIZbTmcA > 0; GjXIZbTmcA--) {
            ECwKaCgN /= dKSZaAnueazV;
        }
    }

    for (int SkKGHLgBYS = 331356023; SkKGHLgBYS > 0; SkKGHLgBYS--) {
        continue;
    }

    for (int oRTDJsYLJNE = 2067245659; oRTDJsYLJNE > 0; oRTDJsYLJNE--) {
        uHewr = FxvYjIZwjeBvmEJo;
        vHbDhUE = BviUBzNWVqwb;
    }

    for (int PWUdPrD = 415187460; PWUdPrD > 0; PWUdPrD--) {
        dKSZaAnueazV -= wvLIzz;
    }

    return BviUBzNWVqwb;
}

void RqFyhQJbHBfy::RFvQFokcj()
{
    double mmLYlknufOYiFnww = -213017.79875435182;

    if (mmLYlknufOYiFnww == -213017.79875435182) {
        for (int zfsxcr = 1294258619; zfsxcr > 0; zfsxcr--) {
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
            mmLYlknufOYiFnww *= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww *= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww += mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
        }
    }

    if (mmLYlknufOYiFnww <= -213017.79875435182) {
        for (int wTcif = 1380499321; wTcif > 0; wTcif--) {
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww *= mmLYlknufOYiFnww;
        }
    }

    if (mmLYlknufOYiFnww > -213017.79875435182) {
        for (int VUVDJYeX = 128319568; VUVDJYeX > 0; VUVDJYeX--) {
            mmLYlknufOYiFnww += mmLYlknufOYiFnww;
            mmLYlknufOYiFnww *= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww *= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
        }
    }

    if (mmLYlknufOYiFnww < -213017.79875435182) {
        for (int SFgoKdzgDsCgpjm = 1819202418; SFgoKdzgDsCgpjm > 0; SFgoKdzgDsCgpjm--) {
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww -= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww -= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
        }
    }

    if (mmLYlknufOYiFnww != -213017.79875435182) {
        for (int iAubHtgIzcuzfW = 1076481784; iAubHtgIzcuzfW > 0; iAubHtgIzcuzfW--) {
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
        }
    }

    if (mmLYlknufOYiFnww <= -213017.79875435182) {
        for (int ThXlEDgVN = 906077614; ThXlEDgVN > 0; ThXlEDgVN--) {
            mmLYlknufOYiFnww -= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww += mmLYlknufOYiFnww;
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww *= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww += mmLYlknufOYiFnww;
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
        }
    }

    if (mmLYlknufOYiFnww >= -213017.79875435182) {
        for (int gRBlHtItg = 1248060695; gRBlHtItg > 0; gRBlHtItg--) {
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww -= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww *= mmLYlknufOYiFnww;
            mmLYlknufOYiFnww = mmLYlknufOYiFnww;
            mmLYlknufOYiFnww /= mmLYlknufOYiFnww;
        }
    }
}

string RqFyhQJbHBfy::MnTkLtBkrvQeE(double IgQbzad, int SrPPnWVa, double QcXDmNGUEYcMb, string TcKRfSIJrSTxqVrD, int gBRCPRvoz)
{
    int wDJzXZqwsrNfn = -1920474575;
    double iGurjaO = -95545.82356079979;
    string kfFbFtNslvlWhK = string("MplkxFjelkNxpHSesMfHOuREhsobDZBjMTutiEwAgiehisViJNCusXYLVesZRPsLiogyLdqNwTdYhvlhythreTcLqDNeGPCMGVvbIaOqmLVMCUeQXmzCkKTUINigoJQpTzCVDcKqWtXbXsDhztogBZPxLGCjuhTlzVvZROZsStlUuPDfBhQlvwScJcqaYhEERJmMIRKuPuGdrZieMdGXlxohzMGhKYnWsENHsgieWRqEJoSXHGZZ");
    bool aSYZgtZcBtENd = false;
    double ThhAiBO = 925953.9516087427;
    string zZDneENUlOyH = string("EAxUIOyNTQXwHLVjpwOUNGXhSnqJIdQOYGMno");
    bool lvvJvviuAmRfIND = false;
    string VLBBIgdTRyY = string("cpRUDaCeLplnXTgGgFIIeiSQBt");

    for (int hGAjRru = 1579837885; hGAjRru > 0; hGAjRru--) {
        aSYZgtZcBtENd = aSYZgtZcBtENd;
    }

    for (int MJajcYuiGC = 1265802136; MJajcYuiGC > 0; MJajcYuiGC--) {
        iGurjaO /= iGurjaO;
        ThhAiBO = ThhAiBO;
        QcXDmNGUEYcMb -= IgQbzad;
    }

    if (SrPPnWVa == -1251135933) {
        for (int XlmigDQuuSIgPhRz = 2115590662; XlmigDQuuSIgPhRz > 0; XlmigDQuuSIgPhRz--) {
            continue;
        }
    }

    for (int ifzxgHaZlYfCGwVe = 541708435; ifzxgHaZlYfCGwVe > 0; ifzxgHaZlYfCGwVe--) {
        iGurjaO /= IgQbzad;
    }

    return VLBBIgdTRyY;
}

RqFyhQJbHBfy::RqFyhQJbHBfy()
{
    this->CTrshEqWvaupnmqn(545208.6432625521, 99869.98421329442, 730189.230774598, string("vmuQZnvkeYILPvwYHgdZNCJqZhWONzKZCWxxrvrFrGnFJgyNFrGjqEfRoMhbLggAsEYRWTLlwOWCuyHKz"));
    this->aCroiHefNqsYdjD(-1013229962);
    this->xGNtMUnzg(-496582171, -536117090);
    this->AtYpvd(false, string("CRVhslVUPWM"));
    this->nsXbHxuXCugOEsVI();
    this->vjVdRWj();
    this->BFXcrEMlPylbT(string("TCKsjJNxWzMdNCRmKDJaYtzQlMiuOGpzsiJgyszCIttrGQeYrqdFvvGsiltSQzWvUFMmevxPPnBPamROwMkccTVUWRZoQByqbnGuaitvuUrovsuzQQjhpMnNbhXDrMGsuZbHMVVhQmztEOJQDOSUEnrwAxKhuFkwnEsZebSdWgQTgSnGgqQSxhnKOtrCQFewAarYEfCDNNfTBGrCxXkkPigKUcUEvyfAgvbFqgSzlCsVk"), true, -1167816375, string("aytKaMxfvNSCwJkfivPuuTPtOrAGTaFTemkWnTsYnOQFEayVCrSaIFRGaRDbPvMIXQgTcvaeImmZhKVOCQINGXXEBqIpRfLnchPZGzOCfiVOUXXOpuSFXuaUZDoyojwiNxuxBDNAKL"), string("dEbumwuvYhBIxlnAAHPsULXQNqCSRpbXsJuSwxnindynOygZUDOrqzTcOTdtEVGovPUknUbPXzfoCINjaKFEjbEdZCFOTczOBw"));
    this->aZUeZjEZ(-1453331614, 609406.1122042169);
    this->WEsfVd();
    this->JZlUSuOcXjlpGB(-1954880233);
    this->wSKmIKP(-782581.1653701764, false, false, -224711.5635644993);
    this->RFvQFokcj();
    this->MnTkLtBkrvQeE(527864.1022093038, -983654944, 679811.1883090902, string("uwIMMtZBRzMbPXoIluRjObdQBJVAdnsFGFpOcevDeViKbPLxrHKwMfsJPTDfmljhBrgHtnqBCXzUigirudVrsHfaJCOBIESNhXiirBoVIYmWQvvNxBxFEUaeXSTtwGrbMxiHuUGviHdQ"), -1251135933);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lwUQLpDYzxIKXcNO
{
public:
    double RUtrbrVyNtjg;
    string ejAGujugg;
    int vMAfXHqXAtb;
    bool CkWJGhuRRXsgaWJ;
    double UvNMLHNdgg;
    bool nIdZFxCxN;

    lwUQLpDYzxIKXcNO();
    bool DtTHW(int LzmlmhY, double qcVlyBjtiauO, int MqavfRUF, int JgQiv);
    int zpHcTh(double InqPkMBF, bool Ibljtq);
    int qUHLNTKqKz(string qfPFEAAaLUZEvNz, int HtWgfIJlfUEmVNz, int dfjXGpNOTn, bool ImuLXVHuHoC);
    string rQLMcAIqB(int ddTluovIKEk, double hhMwFGtoEJQt, bool gCeAecM, bool MKvVnpRT);
protected:
    bool kNIAEIG;
    bool EvTfbzYYNt;
    string YgvQoar;

    string FpzEMofudg(string NpmozuTSamcjHyCb);
    bool GltKBPCyQlrvE(string InOYSXZsKtz, string DkqPXYMTNscYrNwo, bool jKSuVSJNxietobnn, bool CHhzassqQejTR, int fOiwqtHpcbrdz);
    bool MuBGHkr();
    void ZkCjRMToquNLD(string iPPDxckkZ);
    string zSolnUgdVox(string RrlvPXI, double TLvWRRfes, bool nVpfsInvklIt);
    int xnBjeNRqAm(string lHOlZJJnyrqoCqUd);
    void vWCvUOop(bool OzPpPFv, int RTxwG, double lBElf, int vUjAhxuPFC);
private:
    int yTrUCspeHBb;

    bool ZgoHQoeAat(bool MBEJVNDUYdXFqdq, int xUDVBbT, double pLRqmDTBLMe, double ScbUhHsZIoQDuG);
    double xDvVU(int QUzLlGZmxa, int npzdZewZGIrrL, bool gxqkWXdOCLVZBM, int LLhuCpIwehNzfvO);
    bool TQDZzO(string ZsPgO, int YTXhVSPtDuh);
    string lfsQqcW(double Qppdx, bool FUdzy);
    string KlSnzFxdeSz(int TGMZR, string SdwsHISV, string HMhazSotX, int tqtlGbLDolecq, bool oetSAySmq);
    bool KAsuwIlPMHOF();
    double TOWamKOJwH(int dfINEmVNwPOeUHX, string wkngGNuML);
    void xuzHjmtJlu(double OqVmhVXlnN, string oaftCk, bool qvjoixFZdAMdgCGw);
};

bool lwUQLpDYzxIKXcNO::DtTHW(int LzmlmhY, double qcVlyBjtiauO, int MqavfRUF, int JgQiv)
{
    double dFfIRrKxYbPxNE = 453536.859670984;
    string aISdPiZQOGQGyD = string("cGPKEbVsBWRnPgaXq");
    double llDNe = 323224.5639134335;
    int QLyAzUzAt = 1258234654;
    double DXrqtLarah = -186625.97749959293;
    string eDQuAAUBeqKaXeTF = string("ixmzzOqFBafyjaybfZwoHilBlnLcFvGKBmwLRjtnXtBwvtYQkFQzQzdWaaqdSrrJpapdViuXgvjRkPfHltvVgWlSRBurxYVdpTddgJuQjdsLLIbJWNnAUslLUVxTWxalXXbOiNynPfWtSeJrBkDOvjBVNakAZzOjLrwRJhIxwsMoIpYyyBQHDtNBZvjOSBHbAdJcezKqoIZqnRsEPMIlZZIdjcRJWYqzUpOQhNYXRcdoNLrcJG");

    if (QLyAzUzAt > -1933900665) {
        for (int cgaYgNOcnJ = 1939732988; cgaYgNOcnJ > 0; cgaYgNOcnJ--) {
            dFfIRrKxYbPxNE -= llDNe;
        }
    }

    if (QLyAzUzAt == 923314498) {
        for (int eoVoTa = 965268999; eoVoTa > 0; eoVoTa--) {
            llDNe = llDNe;
            llDNe /= qcVlyBjtiauO;
            LzmlmhY /= QLyAzUzAt;
            LzmlmhY -= MqavfRUF;
            qcVlyBjtiauO *= llDNe;
        }
    }

    return false;
}

int lwUQLpDYzxIKXcNO::zpHcTh(double InqPkMBF, bool Ibljtq)
{
    double nPRlfAuHWrmKPj = -685468.6502232619;
    int FSLaCQqKCQN = 628775546;
    bool AASJoS = true;
    double TKHTfY = -409409.60838780145;
    bool alcIvKenAMY = true;
    double giioFUzrXjQEi = 232420.97109776587;
    bool OXEKTmeVb = false;
    bool vfoyzbAZHmXbt = true;

    for (int BRjowJsBCjuOe = 1614563903; BRjowJsBCjuOe > 0; BRjowJsBCjuOe--) {
        vfoyzbAZHmXbt = OXEKTmeVb;
    }

    if (TKHTfY <= -685468.6502232619) {
        for (int uqmCOXxbIp = 228193006; uqmCOXxbIp > 0; uqmCOXxbIp--) {
            vfoyzbAZHmXbt = ! AASJoS;
            vfoyzbAZHmXbt = Ibljtq;
        }
    }

    return FSLaCQqKCQN;
}

int lwUQLpDYzxIKXcNO::qUHLNTKqKz(string qfPFEAAaLUZEvNz, int HtWgfIJlfUEmVNz, int dfjXGpNOTn, bool ImuLXVHuHoC)
{
    double PZuAumRPKeHFTlaZ = -946514.3178137639;
    double LePmIpruYwE = -561194.8544409586;
    double zQshAwsAEPh = 281355.4342431685;
    bool JksaI = true;

    if (dfjXGpNOTn > 847455875) {
        for (int DaGfxx = 1846114029; DaGfxx > 0; DaGfxx--) {
            LePmIpruYwE /= LePmIpruYwE;
            HtWgfIJlfUEmVNz -= dfjXGpNOTn;
        }
    }

    if (HtWgfIJlfUEmVNz > 847455875) {
        for (int OKYrhzEMsONMeXW = 1563943418; OKYrhzEMsONMeXW > 0; OKYrhzEMsONMeXW--) {
            zQshAwsAEPh /= LePmIpruYwE;
        }
    }

    for (int KehkOrRUkaraTWN = 1606919530; KehkOrRUkaraTWN > 0; KehkOrRUkaraTWN--) {
        ImuLXVHuHoC = ! JksaI;
    }

    if (PZuAumRPKeHFTlaZ < -561194.8544409586) {
        for (int kOySxxWseULS = 213299372; kOySxxWseULS > 0; kOySxxWseULS--) {
            zQshAwsAEPh -= PZuAumRPKeHFTlaZ;
            JksaI = JksaI;
        }
    }

    for (int URrBrXQBsIxmwY = 1371804029; URrBrXQBsIxmwY > 0; URrBrXQBsIxmwY--) {
        HtWgfIJlfUEmVNz += HtWgfIJlfUEmVNz;
    }

    return dfjXGpNOTn;
}

string lwUQLpDYzxIKXcNO::rQLMcAIqB(int ddTluovIKEk, double hhMwFGtoEJQt, bool gCeAecM, bool MKvVnpRT)
{
    double hibDFxvTAsLXTic = -827897.8472571586;
    string MayfNndNW = string("oClXTmRNCjBOYksFtSOBlsIjhicJidjrVIDLGbjTlqcuwKuwmUVDGwTRWapLwWWZDwyHqpVDLTnSbVzxaySOAaSnDPNSABkGssWdIkjVSxPXtuBCUefuxmUCfgxbsCPOIjJmswgUSkSLPisvOIYyIWkzDKafSJVXVlPDLkVTaSQZKMCVjaLNzSZKPBZClYAKPJqhhKYrJvQdntvmGFKI");
    string CTaZMIYSpMzA = string("kUQDAsuC");
    string aBiTGPSsNJWJ = string("NuG");

    for (int KZiCeGsphsCvxX = 304545435; KZiCeGsphsCvxX > 0; KZiCeGsphsCvxX--) {
        MayfNndNW += aBiTGPSsNJWJ;
        CTaZMIYSpMzA = MayfNndNW;
        hhMwFGtoEJQt /= hhMwFGtoEJQt;
    }

    for (int ZwYYhw = 1255945279; ZwYYhw > 0; ZwYYhw--) {
        continue;
    }

    return aBiTGPSsNJWJ;
}

string lwUQLpDYzxIKXcNO::FpzEMofudg(string NpmozuTSamcjHyCb)
{
    bool PPjPOaKOHu = true;
    double sKNgGMAVUanY = 173567.76136134146;
    string hjXfDrxFw = string("CYESMkfDhomUwOUDLFNZtGOPMEEfvBwXZEGawvzFwxlRetHVjsRfdAUHTzLWYUaeBTKmvKRlqvbuYgyfnBcaZwERACatiB");

    for (int XjxjppjJPpm = 944570651; XjxjppjJPpm > 0; XjxjppjJPpm--) {
        NpmozuTSamcjHyCb = NpmozuTSamcjHyCb;
    }

    if (NpmozuTSamcjHyCb < string("CYESMkfDhomUwOUDLFNZtGOPMEEfvBwXZEGawvzFwxlRetHVjsRfdAUHTzLWYUaeBTKmvKRlqvbuYgyfnBcaZwERACatiB")) {
        for (int pkdTpWNEIpTniMXJ = 1656394322; pkdTpWNEIpTniMXJ > 0; pkdTpWNEIpTniMXJ--) {
            NpmozuTSamcjHyCb += hjXfDrxFw;
            hjXfDrxFw += NpmozuTSamcjHyCb;
            sKNgGMAVUanY /= sKNgGMAVUanY;
        }
    }

    if (sKNgGMAVUanY <= 173567.76136134146) {
        for (int phjrqQBeVVxGweEL = 106780874; phjrqQBeVVxGweEL > 0; phjrqQBeVVxGweEL--) {
            sKNgGMAVUanY = sKNgGMAVUanY;
        }
    }

    return hjXfDrxFw;
}

bool lwUQLpDYzxIKXcNO::GltKBPCyQlrvE(string InOYSXZsKtz, string DkqPXYMTNscYrNwo, bool jKSuVSJNxietobnn, bool CHhzassqQejTR, int fOiwqtHpcbrdz)
{
    int bbbjJcmu = -2056978591;
    double gcDIfnmoYEN = -596050.0137790391;
    int iGlkSV = -2108376208;
    bool PSeuFw = true;
    string PIwYiudMNKVAFy = string("notnYGoEotUVUVCYWWIryXAZpzcQQJPTfqEoaBxUBCHBDPbemQPrDubCqciYfgfviSMKqeJVnJYXCvYsADlzynUCsgrgMrLIVelSoHNPZGMxwacWaJnPpajquAIHzSQypBepAORHYyzqIPrMKuG");

    for (int rRiJYef = 862840026; rRiJYef > 0; rRiJYef--) {
        CHhzassqQejTR = CHhzassqQejTR;
    }

    if (gcDIfnmoYEN > -596050.0137790391) {
        for (int zvLWwuOMq = 921104742; zvLWwuOMq > 0; zvLWwuOMq--) {
            PIwYiudMNKVAFy += PIwYiudMNKVAFy;
            gcDIfnmoYEN /= gcDIfnmoYEN;
        }
    }

    if (CHhzassqQejTR != true) {
        for (int DZpcvdb = 44836519; DZpcvdb > 0; DZpcvdb--) {
            iGlkSV -= bbbjJcmu;
        }
    }

    if (iGlkSV != -2108376208) {
        for (int KViECNRRVORI = 886196023; KViECNRRVORI > 0; KViECNRRVORI--) {
            iGlkSV = fOiwqtHpcbrdz;
            jKSuVSJNxietobnn = ! CHhzassqQejTR;
            iGlkSV -= iGlkSV;
            bbbjJcmu += iGlkSV;
        }
    }

    if (InOYSXZsKtz == string("notnYGoEotUVUVCYWWIryXAZpzcQQJPTfqEoaBxUBCHBDPbemQPrDubCqciYfgfviSMKqeJVnJYXCvYsADlzynUCsgrgMrLIVelSoHNPZGMxwacWaJnPpajquAIHzSQypBepAORHYyzqIPrMKuG")) {
        for (int EDMgpyRy = 870322090; EDMgpyRy > 0; EDMgpyRy--) {
            continue;
        }
    }

    return PSeuFw;
}

bool lwUQLpDYzxIKXcNO::MuBGHkr()
{
    double gvAVLiLyjXIs = 786523.5667594185;
    int vioteSkpUekfr = 478409133;
    int VCPWKjqhkQT = 1211487664;

    return true;
}

void lwUQLpDYzxIKXcNO::ZkCjRMToquNLD(string iPPDxckkZ)
{
    string FUDjyiSUv = string("lAGZfSMvwcsSqbxlGsxzjFyOLMvmIIsdITshxKzOaizCReeQGguTNXZpsSoivRLQeLUgkRQdzxSjuXQFLRXncOFShxUzyduUBKQVPDQKPVJURWBgWYtMBXsWnVjSNNhOdzwnqTVoWxmWlzmNWwCuKRxUWgtvlNspXIfTouTFUGvzLViSpukGdYkYefxFpOhZxVbbPvuefB");
    double PcAKaDNClGMDo = -1022710.7731231679;
    int doKFXBbR = -1852344661;
    int isXqHpL = -1296033088;
    int qPOaxKjCNhdu = 2028144592;
    double mPfZhGatMTjkE = -977171.0403227758;

    for (int WDzLQQiHmXy = 1326918413; WDzLQQiHmXy > 0; WDzLQQiHmXy--) {
        PcAKaDNClGMDo -= mPfZhGatMTjkE;
    }

    for (int wXmJOyhmOqG = 1200345836; wXmJOyhmOqG > 0; wXmJOyhmOqG--) {
        iPPDxckkZ += FUDjyiSUv;
    }

    if (iPPDxckkZ == string("GRIHRoMBgGWrDersyWhNnxyShdDIBbUPqUPFfqpoRSpEpSnegnObHTEItILSuxJnnEFqhDMkUAPcPkwVmAoUFXFulQNtzILjpzqIDpoSFPXObjawCAHzodxVArHcqSDfrAIqnqQccIzBnPjNkJYIXLkNLxqbTySsLzcCYvGUpryCoPwQxoSUjNHEhsOvhTcYtDYOwveDbrekIpvJzEvivOnKUeNxWEzvUifrnIwG")) {
        for (int NDCHp = 1336802545; NDCHp > 0; NDCHp--) {
            qPOaxKjCNhdu += qPOaxKjCNhdu;
        }
    }
}

string lwUQLpDYzxIKXcNO::zSolnUgdVox(string RrlvPXI, double TLvWRRfes, bool nVpfsInvklIt)
{
    bool VEiYo = false;
    bool BwZkueWvAYLouVvs = false;
    bool UGJglK = true;
    bool sEDTiEV = true;
    string RilHDGIM = string("hALulbsYetYrlBJsMFwPmgciNRVQJtEukYBdYovLkkNLLSRtasVboEPDdJxJxMETpMuvaNKQWKnBYOvyNYjSv");
    int MOIqSwLbliCQdtS = 337133798;
    int RwbrKRRrSv = -27223400;

    for (int mWjFkmIEzDYrmN = 2049570265; mWjFkmIEzDYrmN > 0; mWjFkmIEzDYrmN--) {
        BwZkueWvAYLouVvs = ! sEDTiEV;
        sEDTiEV = VEiYo;
        MOIqSwLbliCQdtS /= MOIqSwLbliCQdtS;
    }

    for (int obazloHyhVJkvA = 1795411206; obazloHyhVJkvA > 0; obazloHyhVJkvA--) {
        UGJglK = UGJglK;
        sEDTiEV = BwZkueWvAYLouVvs;
        RrlvPXI += RilHDGIM;
    }

    if (nVpfsInvklIt == true) {
        for (int DcxtBrBs = 1678984027; DcxtBrBs > 0; DcxtBrBs--) {
            sEDTiEV = ! VEiYo;
            RrlvPXI += RrlvPXI;
        }
    }

    for (int WRdFIAkkZcCm = 946928756; WRdFIAkkZcCm > 0; WRdFIAkkZcCm--) {
        BwZkueWvAYLouVvs = ! VEiYo;
    }

    return RilHDGIM;
}

int lwUQLpDYzxIKXcNO::xnBjeNRqAm(string lHOlZJJnyrqoCqUd)
{
    double iUHXfwHwb = -125257.37881884153;
    bool VcXElfBUJupjhCTw = true;
    string PGJPinZYJMjGSgxN = string("KzVzLNwVRGoFWVhiElSzzialgqtzRZWlsMYSTwLiqLZwMBAhXyeQIz");
    string URcxvltMEoKsCWak = string("TvNptCrxBiPOYtBcpLnuGtUibQALQhwhXOwOMshcXiSOEwjvFQcUjubZKlJZSCkaaUfyFjNFtqfYPwabELJoHSTvsVneSZFrWwmUzXmzITbSO");
    bool JJDpYTs = true;
    double aNWYcqu = 963352.7865092544;
    bool cOVyQtT = false;
    bool FYwloHvo = true;
    double lvIJdfUEfrEl = -227492.4385673045;
    double LLDQZU = -773136.296409326;

    if (PGJPinZYJMjGSgxN < string("KzVzLNwVRGoFWVhiElSzzialgqtzRZWlsMYSTwLiqLZwMBAhXyeQIz")) {
        for (int XXnsNLxZfeUIe = 678252594; XXnsNLxZfeUIe > 0; XXnsNLxZfeUIe--) {
            URcxvltMEoKsCWak += lHOlZJJnyrqoCqUd;
            FYwloHvo = ! cOVyQtT;
            lvIJdfUEfrEl /= lvIJdfUEfrEl;
        }
    }

    for (int niEcoBYbyxDhQzI = 840110496; niEcoBYbyxDhQzI > 0; niEcoBYbyxDhQzI--) {
        URcxvltMEoKsCWak += PGJPinZYJMjGSgxN;
        lvIJdfUEfrEl *= iUHXfwHwb;
    }

    for (int dmGSea = 1036165994; dmGSea > 0; dmGSea--) {
        continue;
    }

    return 498982748;
}

void lwUQLpDYzxIKXcNO::vWCvUOop(bool OzPpPFv, int RTxwG, double lBElf, int vUjAhxuPFC)
{
    double PhuUZOFafk = -373393.34812950727;

    if (RTxwG < -391056870) {
        for (int mFxTag = 1227512908; mFxTag > 0; mFxTag--) {
            lBElf *= PhuUZOFafk;
            PhuUZOFafk = PhuUZOFafk;
            OzPpPFv = ! OzPpPFv;
            vUjAhxuPFC = RTxwG;
        }
    }
}

bool lwUQLpDYzxIKXcNO::ZgoHQoeAat(bool MBEJVNDUYdXFqdq, int xUDVBbT, double pLRqmDTBLMe, double ScbUhHsZIoQDuG)
{
    double OoymXaQlV = 116834.28181683665;
    string OBtSwvqhqrve = string("iiFAdgnFuPstadbXGzESWgaLsFNszIuhrRWIaELFEkAZyleLlgpCvcQwiirOzLuwJoIhrSvfyXWfkGMZYSkYKETFomPocoevejJDyIwsyXWushZsmvoPRbzTptGDodOdhlZIYJIdsEwfSeVMvciDAJEKQWisQoFWlehAOAwAbrLaNS");
    double utmSzZuIIJ = -977658.5658585005;
    double sTqjMSGHuuvT = 692580.4618341366;
    bool NAwSNlzIQfiQEk = true;
    double dKeKpVsXtE = -416248.25074784947;
    bool OVGofVrBdmYbX = false;

    for (int IPxsXLbQofSRRaX = 2047426428; IPxsXLbQofSRRaX > 0; IPxsXLbQofSRRaX--) {
        utmSzZuIIJ *= utmSzZuIIJ;
    }

    for (int qdfpmwZxafm = 1899617198; qdfpmwZxafm > 0; qdfpmwZxafm--) {
        sTqjMSGHuuvT = sTqjMSGHuuvT;
        utmSzZuIIJ *= sTqjMSGHuuvT;
    }

    for (int GgwHkdBlgMk = 1878958837; GgwHkdBlgMk > 0; GgwHkdBlgMk--) {
        OoymXaQlV = ScbUhHsZIoQDuG;
        sTqjMSGHuuvT *= dKeKpVsXtE;
        MBEJVNDUYdXFqdq = NAwSNlzIQfiQEk;
    }

    return OVGofVrBdmYbX;
}

double lwUQLpDYzxIKXcNO::xDvVU(int QUzLlGZmxa, int npzdZewZGIrrL, bool gxqkWXdOCLVZBM, int LLhuCpIwehNzfvO)
{
    string COXBN = string("BbWbfTUcHNhIcDnsAIcQoNrUCoNWXGlIaShqvAnOSizzwAXTsQJqWVXnsFtwZsDjRkXMZmnaLnRdTzsCShBBBfviQZahzoPgjpKAItWuRkCtKKFLeKQspStGOiieBVEccPQkqtIZpnVzlPXGAGzactkaTvuglBRrARTKJNovnDJJfQiwMGBLMogCPAXKimKvfLYvsUTFedLcupZoyklAEpIdpXmICYDXEflUGtIgEbFKIJrXuWemZecJMURcUZv");
    bool tClAFqAxd = false;
    int URoxNID = 312942931;
    double FxHvAjjCFkbpCm = 654567.8721999039;
    bool QrFIW = true;
    int UHThDsxVaPzZCG = 530280183;
    int EYTlzv = -490308907;
    double rZSvah = 731781.7962727814;
    bool dYuJfBeMVBz = true;

    return rZSvah;
}

bool lwUQLpDYzxIKXcNO::TQDZzO(string ZsPgO, int YTXhVSPtDuh)
{
    string JAlpYMDvuQtovHs = string("HtKGjPBZDaLXUrrcyKqLHQUIaZxpuqxDcMbgcMvYsRCdxOcdYHfEZByhdBDfvTdaJIAdkTieXhvBgcWxFtcGwWHPmhtsFECejXnQJaXnaurtbitFhzhPjsdbgtiqzxSZRrEAUJawyvBEBmurkQJIsydoeTzSYcugfjBiQyFrEtyUNonOtrbJSBJEVzaiS");

    for (int zbsahNTsYEheftoc = 2059864190; zbsahNTsYEheftoc > 0; zbsahNTsYEheftoc--) {
        JAlpYMDvuQtovHs += ZsPgO;
        ZsPgO = ZsPgO;
        JAlpYMDvuQtovHs = JAlpYMDvuQtovHs;
        ZsPgO = ZsPgO;
    }

    for (int JqvBqai = 1351419135; JqvBqai > 0; JqvBqai--) {
        ZsPgO = ZsPgO;
        ZsPgO += JAlpYMDvuQtovHs;
        ZsPgO += ZsPgO;
        ZsPgO = JAlpYMDvuQtovHs;
        JAlpYMDvuQtovHs += ZsPgO;
    }

    if (JAlpYMDvuQtovHs > string("HtKGjPBZDaLXUrrcyKqLHQUIaZxpuqxDcMbgcMvYsRCdxOcdYHfEZByhdBDfvTdaJIAdkTieXhvBgcWxFtcGwWHPmhtsFECejXnQJaXnaurtbitFhzhPjsdbgtiqzxSZRrEAUJawyvBEBmurkQJIsydoeTzSYcugfjBiQyFrEtyUNonOtrbJSBJEVzaiS")) {
        for (int JQBdhIRpxglJdbzb = 1638572753; JQBdhIRpxglJdbzb > 0; JQBdhIRpxglJdbzb--) {
            JAlpYMDvuQtovHs = JAlpYMDvuQtovHs;
            ZsPgO += JAlpYMDvuQtovHs;
            JAlpYMDvuQtovHs = JAlpYMDvuQtovHs;
        }
    }

    if (YTXhVSPtDuh < -1855425223) {
        for (int YWFvbc = 1261962510; YWFvbc > 0; YWFvbc--) {
            continue;
        }
    }

    return false;
}

string lwUQLpDYzxIKXcNO::lfsQqcW(double Qppdx, bool FUdzy)
{
    string ewoHbE = string("NPoZkhNCtEoiYyoJoiLQjFPuNtHYGvelnRuAPauVjDVOsQdFnuxJgQcTSJvhgqBKSUmXUiEZNkxlAIbBniuKHlDZVxWbUiCMbYJNwrTcTywLpTQpZUHauMdmNCBQLPDKGwkVaRVlrNVpRqyrWBDfmUVvkmTtIlJtyvybtfYYjZgwhgcDtUokLJHSGAGrRxUtEJCUjIohQxLtxeOJGgTtFVJxLZJqHvvHJUOmAhwhhOvSqgLMUNHdsWNuWULSQzM");
    string GqnoOzjMErHrnvNk = string("iXpfUhWezcWDQlCkHIFcAMkJgKLGlHTJZdHQLwuaBuHixFiftUnWwmnXpbzmxmvPeNFQIbVBwdSnkOJfleLasNcQtDVNAlMWJycmCoBHVpcmrIbgHxnikRdBFxGPZstuAyDKZfkWUumPuaxOYBeBIwTQnLcvioEfwHWspkxsCpmOlRWxaqbaajsPiDelmHogUJcMcPSFIBKwwgQJlkWsHsXQA");
    bool uipXzegGhuWKUVxR = true;
    string sXNDWXnSElS = string("gdyUwyISbKUihhdDrpcXTULORHVjnDsACHKsUIxagmtqzjOpNkEVDwLWuiiioaFvwHApMdIJktBAAatzMSRjeJtThnySGYEHpssJfRdvECurxCjrFjZNNBBpnwZDMxjDjekIHGRbCXsCCsjANgODxnLcepJkmjLhWCElUdNOMqlTqfkfbgDTIYXNmLLEbrlLqJdteHNPtYxiBcnmukmpYZhHZvPQhpLccXGUktqNlwKNxRWUqrCmO");
    string vNASSCyaxeabUV = string("uruyfrpnJEfMuUZuuvrXeVIOjBQowaLmMBqOefZcbSpZNhUaxbNIQrnofcLuWArFJIGLhPSKvvqMTYnqBOhwkQQPqJlPHksLXpIZUNdfykUFLfquReAdohwYbYAWcwLvSTLNESLpnyYfzVsRdcENjnYtaBamRkquWxwNTswdyHOemUZELmCfmv");
    int eyAjzwcGYACwOE = 699388755;

    for (int aRbcfLckgkImp = 1227163311; aRbcfLckgkImp > 0; aRbcfLckgkImp--) {
        vNASSCyaxeabUV += vNASSCyaxeabUV;
        ewoHbE += vNASSCyaxeabUV;
        sXNDWXnSElS = vNASSCyaxeabUV;
    }

    return vNASSCyaxeabUV;
}

string lwUQLpDYzxIKXcNO::KlSnzFxdeSz(int TGMZR, string SdwsHISV, string HMhazSotX, int tqtlGbLDolecq, bool oetSAySmq)
{
    double ewCLb = -595003.4152447779;
    double BONpZuJm = -547775.0543974787;
    string oftoYuvNYYWpUnd = string("SbiPjXxFQtvvbyLacgAkkYmUYKgWqTSSRcmwgpAcYxDRoDzHRGzEpbxceABSzHgsloQyKBhIQTUJGTqJeUqFcjyxOFyZWzXRCKXAKUTJOSiQZRIIQFCRdXwJTzOwtbRALdRRirFrCXICOEARCkOVLTHCLXyHAqEQNjdgnTFygwcVlSDXwKFJfAbumpAkHK");
    int CaoIyGRHgSq = -837755974;

    for (int vTtJPd = 1332733317; vTtJPd > 0; vTtJPd--) {
        continue;
    }

    for (int IqBFIeTghyWgLaam = 1343477746; IqBFIeTghyWgLaam > 0; IqBFIeTghyWgLaam--) {
        HMhazSotX = HMhazSotX;
    }

    for (int VQVYMbNELqcEgVIV = 1951986664; VQVYMbNELqcEgVIV > 0; VQVYMbNELqcEgVIV--) {
        HMhazSotX += SdwsHISV;
        ewCLb = ewCLb;
    }

    return oftoYuvNYYWpUnd;
}

bool lwUQLpDYzxIKXcNO::KAsuwIlPMHOF()
{
    bool GZmreLSlEWqSOs = false;
    string FlKZUcIwQbyq = string("JQHJanHXRbvpsDrberLYNqYTOlpfAKyzIzTUsOmTetagiTePsOZqjrreemcMudEuJlhcpNHyTgbJCthTTW");
    bool DtYuRiTu = true;
    int OQutZidFeeNaA = 1946338533;
    int VwIbulieRaLW = 896030526;

    if (OQutZidFeeNaA == 896030526) {
        for (int UNZgQw = 445907195; UNZgQw > 0; UNZgQw--) {
            VwIbulieRaLW = VwIbulieRaLW;
            GZmreLSlEWqSOs = ! DtYuRiTu;
        }
    }

    for (int sUdemnyHQQQlHV = 277892075; sUdemnyHQQQlHV > 0; sUdemnyHQQQlHV--) {
        VwIbulieRaLW -= OQutZidFeeNaA;
        DtYuRiTu = DtYuRiTu;
        OQutZidFeeNaA /= VwIbulieRaLW;
        VwIbulieRaLW /= VwIbulieRaLW;
    }

    for (int hvVdlI = 2084472983; hvVdlI > 0; hvVdlI--) {
        FlKZUcIwQbyq = FlKZUcIwQbyq;
        GZmreLSlEWqSOs = DtYuRiTu;
    }

    return DtYuRiTu;
}

double lwUQLpDYzxIKXcNO::TOWamKOJwH(int dfINEmVNwPOeUHX, string wkngGNuML)
{
    string CaIJnCvRYRCCvfZ = string("FwJlgSTkIfGiJfCUIYbfnBGruZsKVSAzOIkNAMdtvkvhDyMdPfhdvRzJWwMuiMaPjPnjCfGiFHeBgIiDzxddmggTWelEWa");
    bool vUFtLGTkX = true;
    double nRUZekcUnRYZSi = -919036.8795635788;
    string upxFcYdRr = string("qWCGVobmNfMPpnbfrzpGjEbfRlXYNElXSVWdnnPqPOofOtTMThTvbrivkpiZuTbkBAalZGRhwWKgYRO");
    double hoLScIDKw = 392373.1183836181;
    double RFwRwc = -631969.1602072326;
    double hibrRaOTjEDRu = -734326.5766885772;

    if (upxFcYdRr != string("qWCGVobmNfMPpnbfrzpGjEbfRlXYNElXSVWdnnPqPOofOtTMThTvbrivkpiZuTbkBAalZGRhwWKgYRO")) {
        for (int CFWyXZmDcGNGiEs = 199492751; CFWyXZmDcGNGiEs > 0; CFWyXZmDcGNGiEs--) {
            wkngGNuML = CaIJnCvRYRCCvfZ;
            nRUZekcUnRYZSi = nRUZekcUnRYZSi;
            hibrRaOTjEDRu += RFwRwc;
            hibrRaOTjEDRu -= RFwRwc;
            CaIJnCvRYRCCvfZ += wkngGNuML;
        }
    }

    for (int ayHFUUplMOa = 1161119816; ayHFUUplMOa > 0; ayHFUUplMOa--) {
        upxFcYdRr = CaIJnCvRYRCCvfZ;
        RFwRwc = hibrRaOTjEDRu;
        RFwRwc += RFwRwc;
    }

    return hibrRaOTjEDRu;
}

void lwUQLpDYzxIKXcNO::xuzHjmtJlu(double OqVmhVXlnN, string oaftCk, bool qvjoixFZdAMdgCGw)
{
    bool VrNbiidoVwJ = false;
    bool eXKPw = false;
    double chddMvMiyPdMu = -305115.1275760634;
    double cOeuBGpqsSXVoN = -870128.3726732141;
    int RGghGgXmHaAyi = 1864369678;

    if (VrNbiidoVwJ == false) {
        for (int OgixFOAfBFPDTs = 1831200389; OgixFOAfBFPDTs > 0; OgixFOAfBFPDTs--) {
            VrNbiidoVwJ = ! qvjoixFZdAMdgCGw;
            chddMvMiyPdMu += chddMvMiyPdMu;
            eXKPw = VrNbiidoVwJ;
        }
    }

    for (int EdauLQov = 246265660; EdauLQov > 0; EdauLQov--) {
        chddMvMiyPdMu += chddMvMiyPdMu;
        qvjoixFZdAMdgCGw = ! eXKPw;
        VrNbiidoVwJ = eXKPw;
        OqVmhVXlnN -= OqVmhVXlnN;
    }

    for (int ysHEFh = 1475576150; ysHEFh > 0; ysHEFh--) {
        VrNbiidoVwJ = qvjoixFZdAMdgCGw;
    }
}

lwUQLpDYzxIKXcNO::lwUQLpDYzxIKXcNO()
{
    this->DtTHW(-1933900665, -1032219.7384758192, 923314498, -242054834);
    this->zpHcTh(514479.5649751875, true);
    this->qUHLNTKqKz(string("wWhciXuSJjLDPEuJruAhTBXcSjNjLbqCbxpviLTpmRQGkipQlLVSZciamvUlUemqklWHXPjdLZumqWcYImEFwhXsOPKdEfkBoQiGJKKohVlWHGJsYMTkdLqwYEQUeXJqYGuqamGXKKuNXfNXlIJMuxFnBSAheXMdwaMxmLozNbFPddCdCLNIhbbooApceHkxoGoawWARjWsFtILgBKBjuUkvaLhh"), -1790316057, 847455875, false);
    this->rQLMcAIqB(-621625736, 459327.8037269148, false, true);
    this->FpzEMofudg(string("NLSTlzXSDGdJyvYzYviGOSwWBNRVsE"));
    this->GltKBPCyQlrvE(string("sgWBcWGrnvtIZDmgHsWxdyajFtfnEnVOqfFwCzEKyaieCUoXthgxLrmqVWgEZdihKiqsrvNkDpJIfuogXVONtwqfWDtNeFSUBbxmkPBSNUReoYjMJNkwVrGTLIwduzMowzZaSTqSpQiZVROtbvngnGYiHTGSdHFZthVKIsEIyZhDkPYtjYysSKCSBMoxfYfzknXxtQaFjbRcuTvbLSHriYkmrAsKpQiZvojNhqRuOUNNzrcJh"), string("SByhZtEmLarxZdKJwgBfWMkwlDQTBMPuyVstGzTqkwkzdpksGDyDOQZJYEIUgxFtVTnlGtiWGqlfimNzfDIjccgGrktRazTEWMCabFqbAJrydvDXwlvCfiMecVQJgMHMjxoNdVaZcwuLODANzBtpcjgHglFGcY"), true, true, -779142803);
    this->MuBGHkr();
    this->ZkCjRMToquNLD(string("GRIHRoMBgGWrDersyWhNnxyShdDIBbUPqUPFfqpoRSpEpSnegnObHTEItILSuxJnnEFqhDMkUAPcPkwVmAoUFXFulQNtzILjpzqIDpoSFPXObjawCAHzodxVArHcqSDfrAIqnqQccIzBnPjNkJYIXLkNLxqbTySsLzcCYvGUpryCoPwQxoSUjNHEhsOvhTcYtDYOwveDbrekIpvJzEvivOnKUeNxWEzvUifrnIwG"));
    this->zSolnUgdVox(string("hSSyZQBQsITJZRuwnbfLYEfteskrIdwCJcOCryCCKHocBQkDVMcTJfGleEtIIEiItZUOpFnpsZALyLoHpHrapjSxKotvLuQvwneGGdUHPaNpzTsnADJr"), -773259.0666709597, true);
    this->xnBjeNRqAm(string("amYZhDfIjjixRQFCLzESjpaljequnqlowDaLzUpneQRBiQuVCabvxbtLGJCMCIBWNLKUonSZvdZnkZUQGDHDRQYrYkzKnijl"));
    this->vWCvUOop(true, -1663707558, 354133.41473162913, -391056870);
    this->ZgoHQoeAat(false, 611996177, 168095.78523529577, 789779.1736759467);
    this->xDvVU(792453568, 51716208, true, -1059368672);
    this->TQDZzO(string("IYrCqUcwrQUxrCejyfFJctBRDpTgxJXhQzMFfeAimFuqnYdHvyEQzLMefnHeGExBREZNEZatcLLXcZdDdGYfWC"), -1855425223);
    this->lfsQqcW(-644741.8016388981, true);
    this->KlSnzFxdeSz(-1860211837, string("AjraLcbgYvEuSiRagZswpNVDDadWcjXOXGSwHHQIFTosilaRoCStqqAVEQoqkUtysvzBQcLFHrQBFAyvCArLUBMdUYZYYxVafiELardjYfSispvyxKREBzqXAOzMdsdYmiteURnzgI"), string("RWsVeoqXsTHtpRBRqHXCHEJTRPRQWrtjYiKCYCyjXJMmsyVarxIHwgLBCpKjJNeNoyjUfElLpnnbmXCEwwOTePvK"), -1105466645, false);
    this->KAsuwIlPMHOF();
    this->TOWamKOJwH(514260052, string("YosotwfuRKriZNuBEIps"));
    this->xuzHjmtJlu(-25398.916998750854, string("RloXMprsRHRPJOebEPIWPylpasUHcf"), true);
}
