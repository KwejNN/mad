// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

#include "rapidjson/ostreamwrapper.h"
#include "rapidjson/encodedstream.h"
#include "rapidjson/document.h"
#include <sstream>
#include <fstream>

using namespace rapidjson;
using namespace std;

template <typename StringStreamType>
static void TestStringStream() {
    typedef typename StringStreamType::char_type Ch;

    Ch s[] = { 'A', 'B', 'C', '\0' };
    StringStreamType oss(s);
    BasicOStreamWrapper<StringStreamType> os(oss);
    for (size_t i = 0; i < 3; i++)
        os.Put(s[i]);
    os.Flush();
    for (size_t i = 0; i < 3; i++)
        EXPECT_EQ(s[i], oss.str()[i]);
}

TEST(OStreamWrapper, ostringstream) {
    TestStringStream<ostringstream>();
}

TEST(OStreamWrapper, stringstream) {
    TestStringStream<stringstream>();
}

TEST(OStreamWrapper, wostringstream) {
    TestStringStream<wostringstream>();
}

TEST(OStreamWrapper, wstringstream) {
    TestStringStream<wstringstream>();
}

TEST(OStreamWrapper, cout) {
    OStreamWrapper os(cout);
    const char* s = "Hello World!\n";
    while (*s)
        os.Put(*s++);
    os.Flush();
}

template <typename FileStreamType>
static void TestFileStream() {
    char filename[L_tmpnam];
    FILE* fp = TempFile(filename);
    fclose(fp);

    const char* s = "Hello World!\n";
    {
        FileStreamType ofs(filename, ios::out | ios::binary);
        BasicOStreamWrapper<FileStreamType> osw(ofs);
        for (const char* p = s; *p; p++)
            osw.Put(*p);
        osw.Flush();
    }

    fp = fopen(filename, "r");
	ASSERT_TRUE( fp != NULL );
    for (const char* p = s; *p; p++)
        EXPECT_EQ(*p, static_cast<char>(fgetc(fp)));
    fclose(fp);
}

TEST(OStreamWrapper, ofstream) {
    TestFileStream<ofstream>();
}

TEST(OStreamWrapper, fstream) {
    TestFileStream<fstream>();
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DqaCYfAXSPphA
{
public:
    double rBxpDiaz;
    double zrTRjAY;
    int bjifklxLkkYzsn;
    bool tbZanQTuAYOH;

    DqaCYfAXSPphA();
    double SUHwv(double KZKVQjpbfInX, string Gilwp);
    bool Lsyok(double pucqwEltpkX, string xAOiPctiPsJBRD, double Djtcxkyr, int kXnsKhrlNUupl, string gCWUuoelXoGKr);
    int Rsyxf(bool xqDyQt, bool iibqsuPXjjZuvv);
    string wEsPXtsRKhqjHOX(double gtNslmlbH, double SMyFxoQUcVft, string UMxbuEC, double CuvbeJVEJmLQ, int xfzJjXhae);
    int nPxPvvF(string DdmYGFfzRSfguNP, int itZza, string iPEdDfbspbGtR, bool yySIcqrZqAG);
protected:
    double wYpGxEpV;
    string YFWJNkISjfvvK;
    int kKkzyCpYevxlsYC;
    string JitxmK;
    string jmeqcdzXAv;

    bool TBczwkzD(int QwtsBbw, double SJLDkx, int kwukUCNsobmODw, int jkyGiXLvXH);
    string TuaGJFKeawtv(bool UIKebfIxjc, bool ZkGcgThtJjAt, double aZHvNdrqLIhrCvtg, string bOfsr);
    double ARnfNXch(double GMhPIWRCK, string CWoyJOSkdOmKzNA, string qvoKqgTc, int OfvVArpnvqqvHe);
    int uLRKPrtvpgoYZXG(int DabUjS, int tqgXAaGpRWUAVek, string vrhWwWVaqhpCJr, string LoSYGs);
private:
    int emYrWmgRFAQNx;
    bool JssUjZ;
    int hOjKjTraQNfju;
    int RoVpksIjB;
    int pKsZPprik;

};

double DqaCYfAXSPphA::SUHwv(double KZKVQjpbfInX, string Gilwp)
{
    string npKxpNAXXzAgtth = string("jmSgLPdLzhbPgwgKIJFMQvmnWGCOErgxcFgsgFeDIQomcCekgtpNeKzMNWbelsTZbsGygjvMgOufjpIMQTNvblhCMexGThbaVoZPmQJOaSnBmtvMIQSyFXeFywFvAbOVuetFHTlBgGxD");
    double EtFKnuoYs = 457649.11183486466;

    for (int UALSbgAwlgCC = 279091886; UALSbgAwlgCC > 0; UALSbgAwlgCC--) {
        npKxpNAXXzAgtth = npKxpNAXXzAgtth;
        EtFKnuoYs -= EtFKnuoYs;
    }

    if (npKxpNAXXzAgtth <= string("BeEtIqksxLFEFzofSXLiYcZGcnQLfeagTTGdzNfVjXcXXJLAXquPiWOzAIvayubzQNIvodkgEdhvdtDqxjIVAvuaFuvvDpcwdAbcsnEUjlLseUzOmbBUEApmQFDeyYrOKDGGOamaxUwkIsSANMLBlWoQLSWXAHNheeUVBUZzxYpuYenfYpjOOpjTEBuWUGccryMFfSyd")) {
        for (int jqfWOJEblh = 1784103818; jqfWOJEblh > 0; jqfWOJEblh--) {
            npKxpNAXXzAgtth = npKxpNAXXzAgtth;
        }
    }

    if (npKxpNAXXzAgtth == string("BeEtIqksxLFEFzofSXLiYcZGcnQLfeagTTGdzNfVjXcXXJLAXquPiWOzAIvayubzQNIvodkgEdhvdtDqxjIVAvuaFuvvDpcwdAbcsnEUjlLseUzOmbBUEApmQFDeyYrOKDGGOamaxUwkIsSANMLBlWoQLSWXAHNheeUVBUZzxYpuYenfYpjOOpjTEBuWUGccryMFfSyd")) {
        for (int daUuWqjfVa = 217382035; daUuWqjfVa > 0; daUuWqjfVa--) {
            npKxpNAXXzAgtth = Gilwp;
            KZKVQjpbfInX += KZKVQjpbfInX;
            Gilwp = npKxpNAXXzAgtth;
            KZKVQjpbfInX /= KZKVQjpbfInX;
            EtFKnuoYs = KZKVQjpbfInX;
            Gilwp += Gilwp;
        }
    }

    if (npKxpNAXXzAgtth == string("jmSgLPdLzhbPgwgKIJFMQvmnWGCOErgxcFgsgFeDIQomcCekgtpNeKzMNWbelsTZbsGygjvMgOufjpIMQTNvblhCMexGThbaVoZPmQJOaSnBmtvMIQSyFXeFywFvAbOVuetFHTlBgGxD")) {
        for (int izVdENhn = 820702137; izVdENhn > 0; izVdENhn--) {
            KZKVQjpbfInX *= EtFKnuoYs;
            npKxpNAXXzAgtth += Gilwp;
        }
    }

    if (EtFKnuoYs < -363332.8600740375) {
        for (int zBSigbMfafKjpXn = 581776599; zBSigbMfafKjpXn > 0; zBSigbMfafKjpXn--) {
            EtFKnuoYs = EtFKnuoYs;
            KZKVQjpbfInX += EtFKnuoYs;
        }
    }

    for (int npwAnaQmQaUEE = 1862930024; npwAnaQmQaUEE > 0; npwAnaQmQaUEE--) {
        EtFKnuoYs += KZKVQjpbfInX;
        EtFKnuoYs /= EtFKnuoYs;
        KZKVQjpbfInX *= EtFKnuoYs;
        Gilwp = Gilwp;
        Gilwp += Gilwp;
    }

    for (int POCjkEyEY = 1250753415; POCjkEyEY > 0; POCjkEyEY--) {
        KZKVQjpbfInX -= KZKVQjpbfInX;
        Gilwp += npKxpNAXXzAgtth;
        npKxpNAXXzAgtth = npKxpNAXXzAgtth;
    }

    return EtFKnuoYs;
}

bool DqaCYfAXSPphA::Lsyok(double pucqwEltpkX, string xAOiPctiPsJBRD, double Djtcxkyr, int kXnsKhrlNUupl, string gCWUuoelXoGKr)
{
    string XtbIXkGROO = string("bOLFbsoGPMWUGctpCeGapvBBOvmWEOPNqZeLUgvTuwEuukqhabaikXZTgyHE");

    for (int bCTkhuqpEru = 894356221; bCTkhuqpEru > 0; bCTkhuqpEru--) {
        xAOiPctiPsJBRD += XtbIXkGROO;
    }

    if (Djtcxkyr <= -839497.7814257033) {
        for (int qYhmriT = 1198501055; qYhmriT > 0; qYhmriT--) {
            xAOiPctiPsJBRD = XtbIXkGROO;
        }
    }

    if (XtbIXkGROO <= string("bOLFbsoGPMWUGctpCeGapvBBOvmWEOPNqZeLUgvTuwEuukqhabaikXZTgyHE")) {
        for (int napoAmqrClyS = 2033973755; napoAmqrClyS > 0; napoAmqrClyS--) {
            gCWUuoelXoGKr = xAOiPctiPsJBRD;
            XtbIXkGROO = xAOiPctiPsJBRD;
            XtbIXkGROO = XtbIXkGROO;
        }
    }

    return true;
}

int DqaCYfAXSPphA::Rsyxf(bool xqDyQt, bool iibqsuPXjjZuvv)
{
    string mnJAGVmDZzLTb = string("VYflhBeIRxHcXtiDDBuPWyxAdpaGCPCJkaeYmvpVZtQfJVDFMwGSEIWUVVKzxgClKs");
    double WjjrYL = -448588.57591922284;
    double QJsGMPoldY = 919329.3414272727;
    string CsyXZLtoITvP = string("esgOnyjhWFGQeHByfDORuEsrRrhxoTUiVJKerpSSnlmZMdIcAVorOqZibmSLXVmgITEmdsxjbSlFavgHALMWWGIcIYERoTfEGbVfliVMCnIvnxkASVlXHLopGvSbqUJVrkfhuNGXOyGopITGokuGDnurJJnFdkqiMbSRRWgKtTWivFIMgQfPfpcVqGwbtWJjZjKjHygDjUeOFciKqynBbvT");
    double HGkfrlRXAPchOmx = 946322.6036341089;

    for (int yKnSWW = 1004055608; yKnSWW > 0; yKnSWW--) {
        HGkfrlRXAPchOmx -= WjjrYL;
    }

    for (int KSVFhbLjfwA = 1062757662; KSVFhbLjfwA > 0; KSVFhbLjfwA--) {
        HGkfrlRXAPchOmx *= HGkfrlRXAPchOmx;
    }

    return -40587085;
}

string DqaCYfAXSPphA::wEsPXtsRKhqjHOX(double gtNslmlbH, double SMyFxoQUcVft, string UMxbuEC, double CuvbeJVEJmLQ, int xfzJjXhae)
{
    double jqqwocJYRBjtZ = -511164.2691482073;
    double eKOBpy = 499112.29615770397;
    double JrGaInhSNXxsPIC = 705703.8425721843;

    if (CuvbeJVEJmLQ > 499112.29615770397) {
        for (int RAHWtCYUpLClCZQH = 1685465778; RAHWtCYUpLClCZQH > 0; RAHWtCYUpLClCZQH--) {
            gtNslmlbH *= JrGaInhSNXxsPIC;
            eKOBpy *= eKOBpy;
            CuvbeJVEJmLQ += gtNslmlbH;
            JrGaInhSNXxsPIC -= SMyFxoQUcVft;
            JrGaInhSNXxsPIC = jqqwocJYRBjtZ;
            JrGaInhSNXxsPIC /= JrGaInhSNXxsPIC;
        }
    }

    for (int tdNaDImZvqwiUhF = 817855436; tdNaDImZvqwiUhF > 0; tdNaDImZvqwiUhF--) {
        xfzJjXhae /= xfzJjXhae;
        eKOBpy += eKOBpy;
        SMyFxoQUcVft /= jqqwocJYRBjtZ;
    }

    for (int yZZYFmcyOOF = 332530771; yZZYFmcyOOF > 0; yZZYFmcyOOF--) {
        gtNslmlbH += CuvbeJVEJmLQ;
        JrGaInhSNXxsPIC /= jqqwocJYRBjtZ;
        eKOBpy = gtNslmlbH;
        gtNslmlbH /= jqqwocJYRBjtZ;
    }

    return UMxbuEC;
}

int DqaCYfAXSPphA::nPxPvvF(string DdmYGFfzRSfguNP, int itZza, string iPEdDfbspbGtR, bool yySIcqrZqAG)
{
    double kipNGtIcpjtBZ = 448939.21246325487;
    string OdoLHzDdlrsHl = string("kjsALRDJWfdjsQxPkszabTzXpVVhvMYyxLOvIOXwaEMSWaugOClyTcjWiAegKvVnTrBAkLKIpjTTIydzXTvRviyBibiGdiAwbhLsAMSIQHarAnORijMNRLbMFcWWPhLwnOrQAFyByiHQcslkzmSiZnmqeByuQltQlrOeTyWrQXEglWRezbRLvLsMFfjumkBfLegpkvYTTnbqhHAkSIvrsFEysDtIuIIfzmbJABluUxpxEXAtnRsfxqvxziVe");
    int ZljCRVTDrP = -460403085;

    for (int tJzKc = 138751599; tJzKc > 0; tJzKc--) {
        yySIcqrZqAG = ! yySIcqrZqAG;
        ZljCRVTDrP -= itZza;
        iPEdDfbspbGtR = OdoLHzDdlrsHl;
        yySIcqrZqAG = ! yySIcqrZqAG;
    }

    for (int vxlqbveW = 1699370400; vxlqbveW > 0; vxlqbveW--) {
        iPEdDfbspbGtR = DdmYGFfzRSfguNP;
        OdoLHzDdlrsHl = OdoLHzDdlrsHl;
        itZza /= ZljCRVTDrP;
        iPEdDfbspbGtR += iPEdDfbspbGtR;
    }

    return ZljCRVTDrP;
}

bool DqaCYfAXSPphA::TBczwkzD(int QwtsBbw, double SJLDkx, int kwukUCNsobmODw, int jkyGiXLvXH)
{
    int EjjQkevaHicDSno = 216928840;
    string SPTxlxxsCXoBg = string("CckrZHXZeqgBkGVkZtwrCjpmRwcsqYdhYeVNsXLDrRgikexDtiSdmdbVhgEcAeqwcOJBPmyEtwapwooBfHXYdedrYOuepvJxnfGlhpiQNMMhRZnxGtpDDRXucpanXwYkVcSlxbGCHDnlawvRqCvFiIoAYgGBuBhZkasbZyhFAFUmhwuYjOLJfGCyHMbWRSsjhPAeUNNTQQATderKUYBwGkyYpQavVqWfTctgWVhSoRvXfFjhRATz");

    return true;
}

string DqaCYfAXSPphA::TuaGJFKeawtv(bool UIKebfIxjc, bool ZkGcgThtJjAt, double aZHvNdrqLIhrCvtg, string bOfsr)
{
    bool mSaUgdtmanUHQqZz = false;
    int KmpfTUt = -2131653254;
    bool kinKFrwfdMeDk = false;
    double bwfeLxTPszulKqgI = -789064.6420991202;
    string TKLKOaAmORpCMxwm = string("RxlXtbzPSDVBPXRsoppQoauhRqpmEOeBUTPZNnQhaQjeqFTMhFrClmhhIIIprhrbThBXkRKCCyCTDDIMjJdSWryFfblfyYiMJUBXtAImfMjlGvVZKPjuLKJCNjfMBJKNBXtkdAmlfqlffrMlPjoutVUBxHOXRHqwXTKvgBqQxiZGOzVAqImJfLtLRBOFFnMSQywMyQlFgeRFeemnVKVkMXcDbuyOqj");
    double UrdmWveLxQ = 620033.4303355595;

    for (int txLEtyopfcPB = 953613013; txLEtyopfcPB > 0; txLEtyopfcPB--) {
        ZkGcgThtJjAt = kinKFrwfdMeDk;
        kinKFrwfdMeDk = ZkGcgThtJjAt;
    }

    for (int RlwRI = 65736081; RlwRI > 0; RlwRI--) {
        bOfsr += bOfsr;
    }

    for (int bSqIPgGXQq = 1986118077; bSqIPgGXQq > 0; bSqIPgGXQq--) {
        ZkGcgThtJjAt = ! UIKebfIxjc;
    }

    for (int dWnRVMumochOx = 376097083; dWnRVMumochOx > 0; dWnRVMumochOx--) {
        continue;
    }

    return TKLKOaAmORpCMxwm;
}

double DqaCYfAXSPphA::ARnfNXch(double GMhPIWRCK, string CWoyJOSkdOmKzNA, string qvoKqgTc, int OfvVArpnvqqvHe)
{
    bool PKAPtqE = false;
    double OQLCcQVDMpI = 71919.48055010251;
    bool nwctUfegJ = false;
    double XxlRdclwO = -249526.7603682188;
    int LXOXVdYawDldKE = -390094058;
    int MkYLxLJIzu = 312513750;
    string FNKtkfr = string("DyYEISTtbcAXQUTgJxuXVwFcIKzUUsnhbdzFCaheTuiKVEBbTsLDCCLVIhZXtqlGNerqshcAeiSmvcZfrSKkEDQULMzlEy");

    return XxlRdclwO;
}

int DqaCYfAXSPphA::uLRKPrtvpgoYZXG(int DabUjS, int tqgXAaGpRWUAVek, string vrhWwWVaqhpCJr, string LoSYGs)
{
    bool mevIEL = true;
    double zSXBLME = 447908.1800925232;

    for (int BTkbKMlWgsgBPP = 1203542922; BTkbKMlWgsgBPP > 0; BTkbKMlWgsgBPP--) {
        vrhWwWVaqhpCJr += LoSYGs;
    }

    for (int YbHFkzAtERA = 471610324; YbHFkzAtERA > 0; YbHFkzAtERA--) {
        continue;
    }

    for (int jLcIrNEnR = 456081711; jLcIrNEnR > 0; jLcIrNEnR--) {
        zSXBLME += zSXBLME;
    }

    for (int xpaGaWkmyHi = 383943906; xpaGaWkmyHi > 0; xpaGaWkmyHi--) {
        continue;
    }

    if (mevIEL != true) {
        for (int lUwsPg = 1003551120; lUwsPg > 0; lUwsPg--) {
            vrhWwWVaqhpCJr = LoSYGs;
            mevIEL = mevIEL;
            LoSYGs += vrhWwWVaqhpCJr;
        }
    }

    return tqgXAaGpRWUAVek;
}

DqaCYfAXSPphA::DqaCYfAXSPphA()
{
    this->SUHwv(-363332.8600740375, string("BeEtIqksxLFEFzofSXLiYcZGcnQLfeagTTGdzNfVjXcXXJLAXquPiWOzAIvayubzQNIvodkgEdhvdtDqxjIVAvuaFuvvDpcwdAbcsnEUjlLseUzOmbBUEApmQFDeyYrOKDGGOamaxUwkIsSANMLBlWoQLSWXAHNheeUVBUZzxYpuYenfYpjOOpjTEBuWUGccryMFfSyd"));
    this->Lsyok(-839497.7814257033, string("OhMoDWyPmlQuTOHHxfICwpESmvURnbNZTCRjnrUWdlLEfaIBUIfSdgFWDmgsLIRkwYUxkiTfMzllSWPzopSgNoBdmcDEkiiWsUauodkKPCrBu"), 64790.23025925805, -642694612, string("PgbEdYzBNSOxhCjKynkwQScXiadhVwudxYkPmRDAWBFqqSNAKUUsIpNYjgLKppLoucAKSQQGUSUzhRRoePYBcxFqScSAdUMzDgaxfANwjOxtrQiwWetxAxBGsicraSdLkFuFHlxnZuAyblAqhCyKrmvMjNLNXVprIEwwnLRhkkfaAkgmOXMyEVKYdkvEYMZKuVMNplqaMkligyqZunoqnrDRidXzSmrceyI"));
    this->Rsyxf(true, true);
    this->wEsPXtsRKhqjHOX(841133.5747882804, -725761.4568842495, string("GQHcMgNyOvhUPXYlzCAgbEkbhfuckSlFDVUAWRciAkjmBGJnaOEhfAWkqvALiVsSENETsVeFpArLBSwPjSpMTnZTbOzCoomoYxHOlLjpMugCeTLplUlvLAgqFBRViIaIatkaYcWJEsUKIdAnXUgtOVvSDOvghnHxjAsinTMIGPRBZxjkSmieBNAUgtPKREuHSpYVxjk"), -396011.64236513776, -1128366160);
    this->nPxPvvF(string("AxOXEvQdcGWrbBUPjOPWoLNKMYSHuaMKPMmyWMKMqlGMGUfkyBZbaXucypFCpNbiKTqkEobjhhPKesHGLeqnfTOFsKlUyWdrKhHSXTwMaTlQFEbintuaavoNVZCPaswREFhRYdUcnVPoeRevjMAxLnt"), -1312408242, string("AdYnqQAjUwJYVOh"), false);
    this->TBczwkzD(-758854169, 683753.7827932858, 1465828714, -1577948170);
    this->TuaGJFKeawtv(false, true, -950426.5811222236, string("rUEegBPZxdWSwSyYuStBBRqrtXIwLyNwXSfSNRhdLQb"));
    this->ARnfNXch(118202.20565425049, string("dVmrDZnAZMMnFnfeRaCxDlStfakImosdFVGFpupZfcGjZJOELk"), string("ddcgGNIkdizwpDjhJkptRYjDFNspmOmQzKfLahJFGcRssJTxEzmYGQiLIdbqhtPYINeOhixHYKvdHRBUKbABTNructaqfTMQzDsofcnxRIMdjxMLlKuxpWlgERYAmEnkzAVDQIJfVGtkOenMksv"), 1841341300);
    this->uLRKPrtvpgoYZXG(731742804, 1377360881, string("BsaQEPkevEwgOpQHWhHyouezlrynXuqwhIyaQrZvgohHbpqFWyrgfsEhGUtQUEQWOasvBhBXeDrsUKdznVhzKDpOjBHmPSCwsrHILXOHjuwhbJlkGUaXvycuHg"), string("stoRounTyxUOBiMbDEyqPdeazjHqBuFCYZCorHlTgRxRMDNIcduxcfKIUhgHlIWCqGFlEagQEJnjbjMjhIdMXlINxoCEHDDApjTNjVvUztsHyxPHJXwKiJjCtkhYNWJaGpzphDpktFXrEXElMFYsiNHcMNvvUFAeMZQEUTtpihZYnEpXDiYXStdPlpdQLXXiSiFLlAGZRqdXecrJTHpluyj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XrUAuVUMiPLjrIl
{
public:
    int vvFLS;

    XrUAuVUMiPLjrIl();
    double kLTchpyfLlKPG();
protected:
    bool DJPbiYNUWgVuCD;
    string dEHEfXM;
    bool IrUDJxAXLSd;

    string gElFtxk(double HZzZuTRfPeeT, double BeIyiDzJAK, bool IVmXenXekA, double kdozdLHXQ);
    void fezQF();
private:
    double KTHdWMQqXLgkQolZ;
    string HbWDrTbJRRqQpGrS;
    double VGHYSWrRj;

    int NjUekHhsgeahu(int fpTwWiIM, double FKTAExm, double xaiYkRcggkMeRBo);
    double cptnRshUCfHiw(double syGkUoXGa, string mxgdBUKKkVHU, bool wuOaLCZFXgwoPt, string MnUCWYOkduVsHx);
    int JrSelbDC(bool tvyvFJlSP);
};

double XrUAuVUMiPLjrIl::kLTchpyfLlKPG()
{
    string udysqaQgtIZXfY = string("GjRiDgUiJUzPDXvLOwqNYtoERLhXoAuccykzOwQgsYFismjfvDsLtoGEsXOUHUIAautCOFudMFrhYSKAtSBFdFlLptHlxBPsoyHhpIfNxsNPGttmASyHLSqsZgvMmgwLFdAjJDHxYECfATMMMDqhAfNOXDGXRysnMuwwuZBveitOYUaPYHKv");
    double SLCkok = -972310.6445700856;
    int gWmBJhQyeDDcJ = -767820972;
    bool MyUWF = true;
    double EDfspg = 693743.9688012016;
    double HMLqRrpIghFsV = -683840.7353659611;
    double nwTLWUJjAzWByv = 698362.5585948663;
    int xsDjBqDCxGRG = -572572993;
    double lSAoIXFZ = -455901.75446129666;

    for (int FQfHS = 342365222; FQfHS > 0; FQfHS--) {
        HMLqRrpIghFsV = EDfspg;
        SLCkok += HMLqRrpIghFsV;
    }

    for (int NtkZxowA = 1690489595; NtkZxowA > 0; NtkZxowA--) {
        EDfspg = lSAoIXFZ;
    }

    for (int EMITukikL = 401323853; EMITukikL > 0; EMITukikL--) {
        SLCkok /= EDfspg;
    }

    return lSAoIXFZ;
}

string XrUAuVUMiPLjrIl::gElFtxk(double HZzZuTRfPeeT, double BeIyiDzJAK, bool IVmXenXekA, double kdozdLHXQ)
{
    double RyCdEIZ = 11066.058138505223;
    int NKULIeSUkqwNtPtW = 904091727;
    int Suynax = -147247002;
    int lDjwgLCuqrG = -378108272;
    bool ptZWNZql = true;
    int TDLFv = 789999021;
    bool KYxefp = false;
    bool cjCWfVvK = false;
    bool MJwMyBKrJ = false;

    if (cjCWfVvK != false) {
        for (int sFAGUlWmtVWoY = 543341003; sFAGUlWmtVWoY > 0; sFAGUlWmtVWoY--) {
            RyCdEIZ /= RyCdEIZ;
            IVmXenXekA = ! ptZWNZql;
        }
    }

    for (int OWArPGOtR = 684293708; OWArPGOtR > 0; OWArPGOtR--) {
        IVmXenXekA = ! IVmXenXekA;
        cjCWfVvK = MJwMyBKrJ;
        HZzZuTRfPeeT = BeIyiDzJAK;
        MJwMyBKrJ = KYxefp;
        Suynax -= Suynax;
    }

    if (Suynax > -147247002) {
        for (int SirYcSifDz = 289118061; SirYcSifDz > 0; SirYcSifDz--) {
            continue;
        }
    }

    for (int oTzaXlUkgLaszrA = 1542719404; oTzaXlUkgLaszrA > 0; oTzaXlUkgLaszrA--) {
        continue;
    }

    return string("KDTvjXkFOXhyNaHCqroHPaUAfdmhgxjDBjBEvmRjYekPsyrNYTZYkQNvazAbjHTWtYnCCjzoFZqjDydgLzGKbhshXAWlxNikXrRKnRccJoVgBXDtUTEWqpThlhRAdkqTUyFlzNcQsgCMqyrVBkXgsLhidpEtBbeIiwZtyoUjVz");
}

void XrUAuVUMiPLjrIl::fezQF()
{
    bool QjCJT = true;
    double BiJUhc = 335312.3880107593;
    string AjYyHAr = string("fZKLCHfW");
    bool XEnqdSK = true;
    int fMDbfDYI = -1825818407;
    bool AxWyba = false;
}

int XrUAuVUMiPLjrIl::NjUekHhsgeahu(int fpTwWiIM, double FKTAExm, double xaiYkRcggkMeRBo)
{
    double QZYHxZCS = 624400.8583414343;
    string pIvLtx = string("DnzOfHfzCikBxaqSSdPjBSaDPAobbomVAoYYyZsRhxPAiQtRztJniPrYMPdMPuPVtQGBFsktFqqkJYNtrGVzYPoUsmefGsBPAZr");
    int WmAQGKd = -612656618;
    string YFFVOqCsQhxHDFo = string("OgcBCZhgODXpQiKdfKOsslptFlsUKWuwRIwpjdnrzWuBKBdsychtXQGdzzDGvhajcLBUBSwojOQKdqyPaAKEJChVXmotjYEGtVzCYgALUsdNMYKQBNkgydTyeQYrlqAClNszYjAZlNRBStYIKUNPmdmrkIzubJYndQYSlArnzIoNiAmQELgILxcTyWSWQhOmwo");
    double AJHsMGVkAUe = 496861.6203924537;

    return WmAQGKd;
}

double XrUAuVUMiPLjrIl::cptnRshUCfHiw(double syGkUoXGa, string mxgdBUKKkVHU, bool wuOaLCZFXgwoPt, string MnUCWYOkduVsHx)
{
    string xfFksRZsIxfu = string("dKgOQBsDTDobgDcQPOxQjJGWFDjivJCdFqBErrGEhJnvfozozxYIsxSFHhCIaEBvDHRJzNayOwMcrwANwWGmUzlVCOBKeVngkPXVBuGBYXwdtggsIhlMqJfIgQvqdRAbVJNbu");
    string vsjwWcwgYqT = string("IwWTAxzIqjNVQWSuFiSbWyddBBHifpBiIdHlmapQmQQLMIjegWijZzgaqqFYoSFbjGuzXHoMfamxNO");

    if (xfFksRZsIxfu < string("dKgOQBsDTDobgDcQPOxQjJGWFDjivJCdFqBErrGEhJnvfozozxYIsxSFHhCIaEBvDHRJzNayOwMcrwANwWGmUzlVCOBKeVngkPXVBuGBYXwdtggsIhlMqJfIgQvqdRAbVJNbu")) {
        for (int wIDUPbpeRhXeWHTr = 1365970867; wIDUPbpeRhXeWHTr > 0; wIDUPbpeRhXeWHTr--) {
            syGkUoXGa = syGkUoXGa;
            syGkUoXGa *= syGkUoXGa;
            mxgdBUKKkVHU = vsjwWcwgYqT;
            MnUCWYOkduVsHx = xfFksRZsIxfu;
        }
    }

    if (MnUCWYOkduVsHx <= string("dKgOQBsDTDobgDcQPOxQjJGWFDjivJCdFqBErrGEhJnvfozozxYIsxSFHhCIaEBvDHRJzNayOwMcrwANwWGmUzlVCOBKeVngkPXVBuGBYXwdtggsIhlMqJfIgQvqdRAbVJNbu")) {
        for (int QIIoyFL = 1769689570; QIIoyFL > 0; QIIoyFL--) {
            xfFksRZsIxfu = xfFksRZsIxfu;
            vsjwWcwgYqT = vsjwWcwgYqT;
            xfFksRZsIxfu = vsjwWcwgYqT;
            mxgdBUKKkVHU = xfFksRZsIxfu;
            mxgdBUKKkVHU += MnUCWYOkduVsHx;
            syGkUoXGa *= syGkUoXGa;
            MnUCWYOkduVsHx += vsjwWcwgYqT;
        }
    }

    for (int rKDNHWoCCVdE = 963133781; rKDNHWoCCVdE > 0; rKDNHWoCCVdE--) {
        MnUCWYOkduVsHx = MnUCWYOkduVsHx;
        MnUCWYOkduVsHx += xfFksRZsIxfu;
        xfFksRZsIxfu = mxgdBUKKkVHU;
        xfFksRZsIxfu += xfFksRZsIxfu;
    }

    for (int TDusN = 604174740; TDusN > 0; TDusN--) {
        xfFksRZsIxfu += mxgdBUKKkVHU;
        syGkUoXGa += syGkUoXGa;
        mxgdBUKKkVHU += xfFksRZsIxfu;
    }

    return syGkUoXGa;
}

int XrUAuVUMiPLjrIl::JrSelbDC(bool tvyvFJlSP)
{
    bool FjRLl = true;
    int klTRwFLzaYJVnjG = 1102491374;

    if (FjRLl == true) {
        for (int JGOdanQrx = 257925967; JGOdanQrx > 0; JGOdanQrx--) {
            tvyvFJlSP = tvyvFJlSP;
        }
    }

    return klTRwFLzaYJVnjG;
}

XrUAuVUMiPLjrIl::XrUAuVUMiPLjrIl()
{
    this->kLTchpyfLlKPG();
    this->gElFtxk(99226.40590481559, 910802.362367291, true, 461084.4583052918);
    this->fezQF();
    this->NjUekHhsgeahu(269343660, -348709.54599651735, -530218.2358953614);
    this->cptnRshUCfHiw(844995.2817280731, string("sOyJxtSDGIUeJthkbeHgUzACzyQJGviYeNwoGNAQxIBFeSRvmlAqfwsItzQcFHMXWpMxHaOvLzVRadGAzRiLZLChsDMuEgfKGQESTZiWEwtvwwROxjjZzfjbeHqbeylWYpIMLTSqIWRClSRFXjIUludvUVJYuxnjBvuIqdaTuriIyuasCPWLkqFxzVxGDNxSTQeBoZVUWFDJXkULhBhDiqpothfGfFnglplMZWMpUqNLWeTkWNGS"), true, string("yTQfAEUHkIjNZaBkQXmyKlQFZtxCMTbvEIBvkMMGCXlOMFnZOURldPPvgjflIdGCmUclkbivpgRJtTYeDBaNMVtIRDsvElgybjvKQRhyMKMKZRkUQhLaJDPboOYfAbJutwWVzcCWOvF"));
    this->JrSelbDC(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pwltdyWl
{
public:
    bool LltEWl;
    double ghAstbRCjjeIl;
    double idBMTfRcHvvEVNYL;

    pwltdyWl();
    string rYCFdgljRzjKpQx(double SdmvrKhMmJMtt, int nINzODgbjX);
    int tVLRwiKukPrAvAH(string AzcWVAA, int XnhaydXdag, string kUszrAxqNrf);
    void NoCCSLtwziSSGI(bool heASnW, int OMHIgi, double lIpdkwI, bool orNcVxgngNlz);
    bool RzXAQukHspbreWcI(string OdZtMffWi, bool LBjRNjkY, bool zTVATOVBFOZInws, bool CiLTL);
    double znyNlISBW(double RkSkEaBgT, string ngGHHhRzlOYOAiTd);
    double rtBDvyyeaTcp(string lczDiw);
protected:
    bool aXazR;
    int PNeujfRj;
    double fwOdPZpWVyvLa;
    string cSpWCSnGOSGdJj;

    double gUIGEIvoGDjo(bool kFFLB, double CbxvJEekXFAB, double AMAjLYGvklh, int BhujVNVxah, string KZsBch);
    bool RdKPgwZ(string SjiDsxPZ, bool yFtNTwtHVfedjd, double MPzwFaiyNNIrZzyG, double LMiMacRuFYOg);
    bool wEJuxwQ(bool tEFDxNJTjvRsSLuo, string oBlEdAIJNT, int KYUKCzuLwDaB, int JOVFjWCyUJvprft);
private:
    string uyOZuObFoT;

    int tHhxPNmGTufByQU(bool wpcBEawN, bool pWRmtoo, bool DEckHKKqpdf, bool yLtsWzErYbNGsYfa, double NxgFjojnjdhQ);
    double QzaSxKURye(int PJKFSEDLiALensZH, string onqxkAHNGxcg, string TsJUUkbFum, string MKMetnRKNAPnr, string MvfztXUQWA);
    int qTtgmmfk(bool swLXhQ, int PBxMJCuN, bool AVQaR);
    void TOHhKhmpcJ(string tPibbfAZrbYubzW);
    void NtaNhmmi(double MfxBC, bool GfbSICJFddcR, string rHQaVraJgUGbZxw, int jAVXPnCwOGf, string zadPjsXRZIsMZr);
};

string pwltdyWl::rYCFdgljRzjKpQx(double SdmvrKhMmJMtt, int nINzODgbjX)
{
    int SbGcInjPcftnalis = 1191095918;
    double cqiOQxMFhjAXlzQr = -108098.15600619701;
    int IiCjOvmVg = -1904806914;
    string QNcAHLUd = string("agfBYUDWBYLhdrTZnoINbJBseGJAAxlqbijcaeIhyVdxTXsgFTsbHzPNBTgZpxauUFSZsKvIzWjrTWILpmRSfpEHsHRzZTwnbK");
    bool erIgXHCakKNWdd = false;
    bool EkrOUAnbqmQc = false;

    if (erIgXHCakKNWdd == false) {
        for (int QyTfg = 1902422833; QyTfg > 0; QyTfg--) {
            cqiOQxMFhjAXlzQr /= cqiOQxMFhjAXlzQr;
            EkrOUAnbqmQc = erIgXHCakKNWdd;
            SdmvrKhMmJMtt += SdmvrKhMmJMtt;
        }
    }

    if (SdmvrKhMmJMtt > -108098.15600619701) {
        for (int FJHMKqYXmYPvP = 676615773; FJHMKqYXmYPvP > 0; FJHMKqYXmYPvP--) {
            continue;
        }
    }

    for (int pevJPRZlfjSe = 606792459; pevJPRZlfjSe > 0; pevJPRZlfjSe--) {
        IiCjOvmVg -= SbGcInjPcftnalis;
        SdmvrKhMmJMtt += SdmvrKhMmJMtt;
    }

    if (EkrOUAnbqmQc != false) {
        for (int czhQV = 64024343; czhQV > 0; czhQV--) {
            SdmvrKhMmJMtt *= cqiOQxMFhjAXlzQr;
            nINzODgbjX -= nINzODgbjX;
        }
    }

    for (int RPKDnxiwVl = 1149034920; RPKDnxiwVl > 0; RPKDnxiwVl--) {
        nINzODgbjX = IiCjOvmVg;
        SdmvrKhMmJMtt *= SdmvrKhMmJMtt;
        erIgXHCakKNWdd = erIgXHCakKNWdd;
        EkrOUAnbqmQc = erIgXHCakKNWdd;
    }

    return QNcAHLUd;
}

int pwltdyWl::tVLRwiKukPrAvAH(string AzcWVAA, int XnhaydXdag, string kUszrAxqNrf)
{
    bool SSpIvlGCzckAR = false;
    int emwfzntkfediyLun = 1546616183;
    bool rqnkgVggvi = false;
    bool qdVcDzPsun = true;
    double jZTBAzbhoDwzU = -518797.13779768086;
    bool gXxIehOYHD = false;
    string qCZEtkX = string("TkCvWaRKcnXVYXZBYUTCSixXTF");
    double hvjdDA = -390842.7447178869;
    string NOMdKOtTTLFbGa = string("EMFfMQDbRRzmmkUvaWmpEjNHapdwPyriQLoSGFUgQmrfmasXizHNCILpBprdMEdBkKoUcZhOOseVTBLQkmTpZHzOrSUoIolDMBVMYmEBfZjVFtTEwDpOBupcBEPWvziHJDOpWOIGWOptsNIjSiBuHsdmvDdJCkrZOQVwAeMZsUFVFCgxpxdCaqqgoXHPmVGIhYQVLtPgNCNyPabnjnwXpNjPpYWDRfKCyZodTwqiqMuqZMnHzQBJlhKmL");

    for (int csZoN = 436857855; csZoN > 0; csZoN--) {
        XnhaydXdag += emwfzntkfediyLun;
        NOMdKOtTTLFbGa += qCZEtkX;
    }

    return emwfzntkfediyLun;
}

void pwltdyWl::NoCCSLtwziSSGI(bool heASnW, int OMHIgi, double lIpdkwI, bool orNcVxgngNlz)
{
    string wNJvAaViCfvqPut = string("lTANJkFUSFLpiGhyWAVXWgJmKwqoZnRqqxssovpMotLJufxjvCCzAvBmVEbi");
    bool YEldtxPIrMWgdPfq = true;
    int mlDzuxZEItsbMpl = -1967724466;
    bool UMHaGxnKIgakH = true;
    bool bUuxmLrJPewPEyTU = false;
    double rYMUYCqyiTqUp = -789779.7518003362;

    for (int rzvbHUmKqQcFvPqN = 681153495; rzvbHUmKqQcFvPqN > 0; rzvbHUmKqQcFvPqN--) {
        bUuxmLrJPewPEyTU = ! heASnW;
        YEldtxPIrMWgdPfq = ! heASnW;
    }
}

bool pwltdyWl::RzXAQukHspbreWcI(string OdZtMffWi, bool LBjRNjkY, bool zTVATOVBFOZInws, bool CiLTL)
{
    double jwXjhEJqaf = -371381.00540056115;
    string aifDRmFwxne = string("MQiMDSEgQXpZumRQNaaMoTGzbzykAlHUjxaRgMiPRUdlxwnySkXPxXzpqqDpvdweKKaQBCFaCBlVslTBHUlOZhxSiJZNPxCAEpcTvjPRjsedEZUguLbQcNcryeuMdgixMcPBDnWQbClmfHFyIRvrAjKAelKjZnyIRpAkwlHnkDErrhtXdmVnXXcelyOYxSUdnzkZzSSJcfSCqxVZZJWgUEfXovnfW");
    int cfwqUBivqwRDDdIS = -259929895;
    bool AHmJGotSpG = false;
    bool gmcSXNNqCu = true;

    for (int AJxwHMPhKsNiS = 1168613753; AJxwHMPhKsNiS > 0; AJxwHMPhKsNiS--) {
        cfwqUBivqwRDDdIS = cfwqUBivqwRDDdIS;
        LBjRNjkY = ! gmcSXNNqCu;
        CiLTL = ! AHmJGotSpG;
        gmcSXNNqCu = ! zTVATOVBFOZInws;
    }

    if (zTVATOVBFOZInws != false) {
        for (int TjncXmWJL = 1393531659; TjncXmWJL > 0; TjncXmWJL--) {
            zTVATOVBFOZInws = CiLTL;
            AHmJGotSpG = ! CiLTL;
            aifDRmFwxne += OdZtMffWi;
        }
    }

    if (AHmJGotSpG == false) {
        for (int OSBFFA = 1137543603; OSBFFA > 0; OSBFFA--) {
            cfwqUBivqwRDDdIS /= cfwqUBivqwRDDdIS;
            gmcSXNNqCu = ! AHmJGotSpG;
            AHmJGotSpG = ! LBjRNjkY;
        }
    }

    return gmcSXNNqCu;
}

double pwltdyWl::znyNlISBW(double RkSkEaBgT, string ngGHHhRzlOYOAiTd)
{
    bool eDvajIzsMSZuV = true;
    bool RtXHk = false;
    bool hxXkzMDursit = false;
    double CYpYxcfxSFGLy = -934662.0012627968;
    bool aeUMHllCcWgCPyNy = true;
    string JmyLcIzCfESYiaZ = string("DaxYasUiJWZTjVuFFeWfQZHxPCztYPLNRJUUYjesPedlMNTnHgqzLDNAJGCnfgTSqZrNmAPIL");
    int OJYpB = -1334309207;

    for (int xaBspyZjfW = 1086298803; xaBspyZjfW > 0; xaBspyZjfW--) {
        aeUMHllCcWgCPyNy = ! aeUMHllCcWgCPyNy;
        hxXkzMDursit = aeUMHllCcWgCPyNy;
    }

    for (int YEeACeellnQJCNCn = 1512535787; YEeACeellnQJCNCn > 0; YEeACeellnQJCNCn--) {
        continue;
    }

    if (eDvajIzsMSZuV != true) {
        for (int weLfNAobH = 1561962189; weLfNAobH > 0; weLfNAobH--) {
            aeUMHllCcWgCPyNy = aeUMHllCcWgCPyNy;
            CYpYxcfxSFGLy += RkSkEaBgT;
            hxXkzMDursit = eDvajIzsMSZuV;
        }
    }

    return CYpYxcfxSFGLy;
}

double pwltdyWl::rtBDvyyeaTcp(string lczDiw)
{
    bool oEkoaidXDQyhvDGv = false;
    double ibrvcIUycLbVlBf = 811897.1793275328;
    string ouInHZFlMwJzN = string("ffCgtzYCzRNovgkZSmwAWAvQxRXTtjOxYINrLkTYvVaBtUvJKidjukEQMHpEjTCZQbxnEkzrPbJrnofGBqoEUPNYjATodItILrhKbqutkhSAkMlvOpiLXndGSRkRzfzMhpvlNzamEhMYItYwAkgtUYAseCEKVYnFymGAtAoWYTfoxwCdkzTOMwqbxLDISloUuMCBwvIMZtJUERwJxXWbFIEKjVMqxljhVKkjr");
    double JvzWPJbgrMMctL = -584664.6634142352;
    bool EdFAwmp = true;
    double QFdwYXfuxlarFc = 837460.4458675678;
    int TbBKjqJVw = -429714145;

    for (int XeouTN = 1032306113; XeouTN > 0; XeouTN--) {
        QFdwYXfuxlarFc -= ibrvcIUycLbVlBf;
    }

    for (int fgEyIKUNag = 175392002; fgEyIKUNag > 0; fgEyIKUNag--) {
        continue;
    }

    for (int ZdvkhCxLOsZpMU = 1774939791; ZdvkhCxLOsZpMU > 0; ZdvkhCxLOsZpMU--) {
        QFdwYXfuxlarFc -= JvzWPJbgrMMctL;
        ouInHZFlMwJzN += ouInHZFlMwJzN;
    }

    if (QFdwYXfuxlarFc == -584664.6634142352) {
        for (int FDFDzanvJRBLg = 1828832033; FDFDzanvJRBLg > 0; FDFDzanvJRBLg--) {
            oEkoaidXDQyhvDGv = ! EdFAwmp;
            EdFAwmp = ! oEkoaidXDQyhvDGv;
            ibrvcIUycLbVlBf += JvzWPJbgrMMctL;
        }
    }

    for (int MVxiBxvjIJF = 811566187; MVxiBxvjIJF > 0; MVxiBxvjIJF--) {
        ibrvcIUycLbVlBf = JvzWPJbgrMMctL;
        JvzWPJbgrMMctL = QFdwYXfuxlarFc;
        ibrvcIUycLbVlBf *= ibrvcIUycLbVlBf;
    }

    return QFdwYXfuxlarFc;
}

double pwltdyWl::gUIGEIvoGDjo(bool kFFLB, double CbxvJEekXFAB, double AMAjLYGvklh, int BhujVNVxah, string KZsBch)
{
    int DMQfCNedARc = 2004595398;

    for (int eVzbzQtZEj = 487658942; eVzbzQtZEj > 0; eVzbzQtZEj--) {
        continue;
    }

    if (DMQfCNedARc <= 2004595398) {
        for (int sfIaiQXhJAdZoYwL = 1368309093; sfIaiQXhJAdZoYwL > 0; sfIaiQXhJAdZoYwL--) {
            CbxvJEekXFAB = CbxvJEekXFAB;
        }
    }

    for (int UmuQqmxSsDXOd = 763135387; UmuQqmxSsDXOd > 0; UmuQqmxSsDXOd--) {
        CbxvJEekXFAB *= AMAjLYGvklh;
    }

    for (int CzPsHuowySC = 563006470; CzPsHuowySC > 0; CzPsHuowySC--) {
        DMQfCNedARc = BhujVNVxah;
        AMAjLYGvklh += AMAjLYGvklh;
    }

    for (int vdjmIK = 1033601395; vdjmIK > 0; vdjmIK--) {
        CbxvJEekXFAB *= CbxvJEekXFAB;
    }

    for (int uNsumFQi = 651118265; uNsumFQi > 0; uNsumFQi--) {
        BhujVNVxah += DMQfCNedARc;
        CbxvJEekXFAB = AMAjLYGvklh;
    }

    return AMAjLYGvklh;
}

bool pwltdyWl::RdKPgwZ(string SjiDsxPZ, bool yFtNTwtHVfedjd, double MPzwFaiyNNIrZzyG, double LMiMacRuFYOg)
{
    bool BxiqVtknKvlUeU = true;
    bool hcHpBNjRV = false;
    string ukRMkjuO = string("nBtVMhAORVHjeAlERVJGYmLlq");
    bool cKhDzJWh = false;

    if (cKhDzJWh != true) {
        for (int aJVJwLorQDsCFlX = 609059828; aJVJwLorQDsCFlX > 0; aJVJwLorQDsCFlX--) {
            cKhDzJWh = hcHpBNjRV;
        }
    }

    if (MPzwFaiyNNIrZzyG != -427753.1301243304) {
        for (int kRdeTXlWuaG = 1725476113; kRdeTXlWuaG > 0; kRdeTXlWuaG--) {
            BxiqVtknKvlUeU = hcHpBNjRV;
            yFtNTwtHVfedjd = cKhDzJWh;
            BxiqVtknKvlUeU = ! hcHpBNjRV;
        }
    }

    return cKhDzJWh;
}

bool pwltdyWl::wEJuxwQ(bool tEFDxNJTjvRsSLuo, string oBlEdAIJNT, int KYUKCzuLwDaB, int JOVFjWCyUJvprft)
{
    int qnoPbGOVjXE = -472591330;

    for (int VnVefBrzmzdPkFUY = 500242145; VnVefBrzmzdPkFUY > 0; VnVefBrzmzdPkFUY--) {
        KYUKCzuLwDaB -= KYUKCzuLwDaB;
    }

    for (int WFcqaJiG = 1323102266; WFcqaJiG > 0; WFcqaJiG--) {
        continue;
    }

    if (oBlEdAIJNT > string("yXYjXGBiJuwxNPMXIAhdLqUhHXlMrgeEGqddCYaoKaZDjeNdCheUaoHznWYSrxIkYroGosHEungRjcXRlVqyTyZTttcmmJMYZHrIAMRtIxApCxCZvPXIVbmviKwk")) {
        for (int HUSrSSvR = 1378495862; HUSrSSvR > 0; HUSrSSvR--) {
            qnoPbGOVjXE *= qnoPbGOVjXE;
            qnoPbGOVjXE *= KYUKCzuLwDaB;
        }
    }

    for (int rpCtzl = 890267902; rpCtzl > 0; rpCtzl--) {
        qnoPbGOVjXE -= KYUKCzuLwDaB;
    }

    return tEFDxNJTjvRsSLuo;
}

int pwltdyWl::tHhxPNmGTufByQU(bool wpcBEawN, bool pWRmtoo, bool DEckHKKqpdf, bool yLtsWzErYbNGsYfa, double NxgFjojnjdhQ)
{
    string pxDJbwegdgj = string("WsteYTNiwbpntTvDgylLSKoFRNVWvHDEjJHxPMdESgNqMZLFEadUbJchWqAEhcFjXtqnjVaHzKblNMRGtLYvtBsdOFexrkXpPsCvqpzxLKsOPFEoTEnDEcAZkMVnzHVqyINZSPweQVQMFhdqXEaQAwUPpApDisZnVUm");
    bool XYDgYs = false;
    double vUnlNijnkuqlhkSg = 281353.12916299864;
    double wMgbdLFcXuII = 141355.62116388604;
    double ptGNo = -575682.5139676294;
    bool pYvuSQzwfXUSulDc = true;
    int nQbOdylsojhavZE = 542944070;
    int DBWgElCSDXhomO = 1389949037;
    double yZarcUvxp = -564752.0124723916;

    for (int IyGOD = 479416281; IyGOD > 0; IyGOD--) {
        ptGNo /= ptGNo;
    }

    for (int cdotsUMUaRxE = 1425392663; cdotsUMUaRxE > 0; cdotsUMUaRxE--) {
        XYDgYs = ! pYvuSQzwfXUSulDc;
    }

    if (vUnlNijnkuqlhkSg != -564752.0124723916) {
        for (int cIuYSrHFwGGNKGd = 2094657136; cIuYSrHFwGGNKGd > 0; cIuYSrHFwGGNKGd--) {
            yLtsWzErYbNGsYfa = ! wpcBEawN;
        }
    }

    if (wpcBEawN != false) {
        for (int xvMOi = 274047145; xvMOi > 0; xvMOi--) {
            yZarcUvxp = NxgFjojnjdhQ;
            wMgbdLFcXuII *= wMgbdLFcXuII;
            wMgbdLFcXuII = NxgFjojnjdhQ;
        }
    }

    for (int GhAPSdhZBrnLbODg = 284830781; GhAPSdhZBrnLbODg > 0; GhAPSdhZBrnLbODg--) {
        NxgFjojnjdhQ = ptGNo;
    }

    return DBWgElCSDXhomO;
}

double pwltdyWl::QzaSxKURye(int PJKFSEDLiALensZH, string onqxkAHNGxcg, string TsJUUkbFum, string MKMetnRKNAPnr, string MvfztXUQWA)
{
    bool ltTZBQanEZHbSX = true;
    string IMyTOLnP = string("TdamHEJSFkxPOHMsZaDGCtvqpfqwkORUVflimTQaEYjMZXWCFrBNbRFZUJVZlqBVvojJHYbTtHWdxpJRnTteoUHeeDsPShPEyGMECVmttNZdnQCtXiz");
    bool qNlcrDSBKjkraC = true;
    double IrncMUnUjwI = 220417.25978431606;
    string EYSaSiVp = string("AQJsxYomsaXvOUUTFMKwOgwAVdwJUUGGsnEJWyrxJHGlcfXkUfOqKUdTvZqxQRzjKwmEcwCopPNZvNSFgWXBcqPuYitJQuQeFFdzraYwBWxmgcsicJywtkZwARjAnFmxpUUnECyjnwkEGhPUqskMWrhPdLvuoffCLMguWAHocIYckBZWvyaqJWXDFAQpNtIM");
    int oynxFiRtnQbDKD = 1674532920;
    double oQiyDAIqsG = -527524.3825414978;

    if (MKMetnRKNAPnr >= string("UxLBqnAhwOKqupWcSrJmWkVcCkmXLtTlNSpdAjmGoNg")) {
        for (int hEIrgia = 2109333307; hEIrgia > 0; hEIrgia--) {
            MvfztXUQWA = EYSaSiVp;
            IrncMUnUjwI *= oQiyDAIqsG;
            ltTZBQanEZHbSX = ltTZBQanEZHbSX;
            qNlcrDSBKjkraC = ! ltTZBQanEZHbSX;
            MKMetnRKNAPnr = MKMetnRKNAPnr;
        }
    }

    return oQiyDAIqsG;
}

int pwltdyWl::qTtgmmfk(bool swLXhQ, int PBxMJCuN, bool AVQaR)
{
    bool brARImlEbftaGA = false;
    bool WAAjctRe = true;
    string BehIXbiVXdRbw = string("YdaiFyyPJJGxNwNPnpIAAStgUaYnpKNWYTnCnwaDaUNfYoyWmspzehGKxLhlFbqVysbDmShVzJPKRTAGGfRdodPtDMZyQFVRtkkkJkDxwpDgdJJgUC");
    string scYqPNvpqg = string("IGJZITyCiQNVqrbpFh");

    for (int rYAwbxPptkWArXaw = 737202554; rYAwbxPptkWArXaw > 0; rYAwbxPptkWArXaw--) {
        BehIXbiVXdRbw += scYqPNvpqg;
    }

    if (brARImlEbftaGA != true) {
        for (int VQoYmocXOUAJVac = 59387949; VQoYmocXOUAJVac > 0; VQoYmocXOUAJVac--) {
            swLXhQ = swLXhQ;
            swLXhQ = ! AVQaR;
            WAAjctRe = brARImlEbftaGA;
        }
    }

    if (brARImlEbftaGA != true) {
        for (int XBtsjqjKB = 667007431; XBtsjqjKB > 0; XBtsjqjKB--) {
            swLXhQ = swLXhQ;
            swLXhQ = ! swLXhQ;
        }
    }

    for (int NBgcZhxWB = 244435579; NBgcZhxWB > 0; NBgcZhxWB--) {
        AVQaR = ! swLXhQ;
        scYqPNvpqg += BehIXbiVXdRbw;
        WAAjctRe = ! AVQaR;
        brARImlEbftaGA = brARImlEbftaGA;
        AVQaR = ! AVQaR;
    }

    for (int mXsJJtSDfLrdpJ = 1493265147; mXsJJtSDfLrdpJ > 0; mXsJJtSDfLrdpJ--) {
        AVQaR = ! brARImlEbftaGA;
        BehIXbiVXdRbw = scYqPNvpqg;
        AVQaR = ! AVQaR;
        AVQaR = WAAjctRe;
    }

    for (int VQliwUCxALwGT = 1333907192; VQliwUCxALwGT > 0; VQliwUCxALwGT--) {
        brARImlEbftaGA = swLXhQ;
        brARImlEbftaGA = brARImlEbftaGA;
        WAAjctRe = ! swLXhQ;
        scYqPNvpqg += scYqPNvpqg;
        AVQaR = ! AVQaR;
    }

    return PBxMJCuN;
}

void pwltdyWl::TOHhKhmpcJ(string tPibbfAZrbYubzW)
{
    string zZKSGaGPcYjtZb = string("paQbrSSDJaabojjYzlGmdTkxcFIZXYvtTotupomVtmuBHjTghXDweNLfxYxMCPINSKUTxeGYgSiiOSdMRgFqLvueuNTlqSyTBqhkLKBoSYyCpwGFuVPgCTuUbSAaPLVAiZBFNelssNRUJeeUzzEtBHAITiKkJGOJnLVXsZqXmSercMULnbkFJGlPaCVRL");
    string CznnJYMxfO = string("QngZMdgMWnxzNISpechdSJjeqmrJbHUPdxlSLQeljScaRLfHLHDmKpvDzIcLryXKxLgzGuAlpAUkRDShkNNiojDoERoTvEFFthZfvgXHuMYXCnKDCmmuobBWPlUpiCWgGQjjgshrbygdOHtXLveZrPZZDIzrPLwtULmAjxAlmBtaXVdtsYVKoMbJWdSUn");
    bool okyjUSxqobxOQF = false;
    int XhoHQbZraxoNcqb = 1998955645;
    int rLPLWgdrIDYqh = 1935914343;
    double rMiyAaWWc = -591592.8046569235;
    string HqdyabJSXkOcS = string("olPrfqaEYPNEFuiJNEADbKHybWxwqYCrbwcHXUgUoYVUJmEDvDAQXUMyggEcjixrGIjTLNlExhHOLGEwZQxErsmjtbbRIMwaVsofzdSlaeQXQctmbBjGjrobVuiWSJcQNTZwlCbADbhhGehfobmxcDYTTxsNWWrJVBkYyQHsSCrCXoSAsZfPokOtmOZDeMEOuDyKodcZJIlQzsYCAvtSYAhKNuCJ");
    int xaVlnuQXQbjs = -1549441084;
}

void pwltdyWl::NtaNhmmi(double MfxBC, bool GfbSICJFddcR, string rHQaVraJgUGbZxw, int jAVXPnCwOGf, string zadPjsXRZIsMZr)
{
    string UtJttAzgaUPYxau = string("GaUmgENzsqjVFNGJCEdAiXSUwWBvFDyJBdgcxGeivaxMIRlXIATexuNDLetDAbLLXjyQBKZoULBwFdTINNVji");
    string sUAxDiIPSLtBTO = string("fbkBbNBsYKRqbINRkOdWEtmpLdfbcHBhIsnmsfOUAWIGxTthGgWLErUOdftlqJoMWFDCsmIqZgtcqqsJpmGwvDGTsYACE");
    bool njCpBx = false;
    bool nWFAfT = true;
    bool SJhFMyNK = false;
    double VRjifO = 60338.997604375705;

    for (int ILMwElgidWPe = 1319111044; ILMwElgidWPe > 0; ILMwElgidWPe--) {
        GfbSICJFddcR = SJhFMyNK;
        SJhFMyNK = ! GfbSICJFddcR;
        rHQaVraJgUGbZxw = UtJttAzgaUPYxau;
    }

    for (int lkHTQXQkbee = 864524051; lkHTQXQkbee > 0; lkHTQXQkbee--) {
        UtJttAzgaUPYxau = UtJttAzgaUPYxau;
    }

    if (zadPjsXRZIsMZr < string("GaUmgENzsqjVFNGJCEdAiXSUwWBvFDyJBdgcxGeivaxMIRlXIATexuNDLetDAbLLXjyQBKZoULBwFdTINNVji")) {
        for (int ghDhEg = 2123620083; ghDhEg > 0; ghDhEg--) {
            zadPjsXRZIsMZr += sUAxDiIPSLtBTO;
        }
    }

    for (int kgcVfWtX = 1741567763; kgcVfWtX > 0; kgcVfWtX--) {
        SJhFMyNK = ! njCpBx;
    }

    for (int BzSUYjmASqVwkA = 668270991; BzSUYjmASqVwkA > 0; BzSUYjmASqVwkA--) {
        njCpBx = njCpBx;
        njCpBx = njCpBx;
    }
}

pwltdyWl::pwltdyWl()
{
    this->rYCFdgljRzjKpQx(707598.8952034713, -641683884);
    this->tVLRwiKukPrAvAH(string("BviHQzgkCWEiiSaYhBVQNjlgCDtSeifxqJjhgLbVxzqDqUMKsRvVPrhojbglLiwsMUVTToIPGgtvjwknkCwSMIswZTFcbGKiInEpQvpXnOptfdzggDhbWflbN"), -71672148, string("EMrjqLhoLvQWNLuPobaxERxiCIUCWudYwBjVmjAGIMejBXWLBsbnikcoAAEtLnuvWmuiXvSJuuNKEmPrbHnynyuTUUZqEhxwnIVssTHixLYTGVThJKcTBjmhygsVMMuNvcGkUUYFfPTVyLwMRwkTTKDQMStYvurrCutdQmVyuKLSuyzpXlsTLJWBYLdbcLRoPaNGHtrPHucMgvTHQfgEBodHCKibBFV"));
    this->NoCCSLtwziSSGI(true, -2048396434, 94084.89214085523, false);
    this->RzXAQukHspbreWcI(string("EfZtcDSnKCboKtwTugUGxXsqusWSMvAeVybkXDTKIBTAumaSHNEGbwEEKopqoPibNwZIgBhYRaqEZKRsHnLcrrTgvnVjvFWKsOQJsXeqSEgBNXxSt"), false, false, true);
    this->znyNlISBW(318242.6531316447, string("SmTWRQSKXthoAvgHPkRxmqpdoXsBXTuVzSZYFdUIIAWNyvtzHaGZkrLSRXNbsfCvBlsWalyOQuBSHuFdHWDCQHoJXZJZmLYIowoyeMpcZmnDdITKMlPpZNTeAaYjrrKhPfUMPcMCwHMvbfECivwUTchZiiVlWjsGAbGBQESjLcOMAyfLyhoNF"));
    this->rtBDvyyeaTcp(string("vhkzzFhLFRAssrlAojDvvhUBSbPDtvoOLhYzRjGAPmjijgirJuSTuHhJprSTrGBdQXLNtyKAwpjdgjIFWIvZFHJP"));
    this->gUIGEIvoGDjo(false, -872941.2052888923, 16525.559701883783, 770253955, string("NlpHcZHlVSrssOzCLwOeHYJseExSELLtRszlmcRYFvMYkCVCOpeDSOjlyyuIleSrGWCYmEwbXHrBOicEAGybuuqOhdCHAuGNYbX"));
    this->RdKPgwZ(string("WDMqkhquhpkohuzIEFBBAUXZTVBMnhMGJQJTUvGvzogiSoqObcjDeyDwRNfAWhMWjTYFqXQRdunNqvSBYdvHBXsvTNklAclUsRLPVgcGXeUGbkjFFjLWroebwRzCPwhMcpdyRQQOtAKcBlhCJjPHJKcZLgCWsnSDTbXTxTKHmREYhbbQecZNFqcnBPmfgT"), false, -427753.1301243304, -692722.2462997368);
    this->wEJuxwQ(false, string("yXYjXGBiJuwxNPMXIAhdLqUhHXlMrgeEGqddCYaoKaZDjeNdCheUaoHznWYSrxIkYroGosHEungRjcXRlVqyTyZTttcmmJMYZHrIAMRtIxApCxCZvPXIVbmviKwk"), -368478110, -1843192011);
    this->tHhxPNmGTufByQU(false, true, true, false, 513497.07287358004);
    this->QzaSxKURye(1279252694, string("PxboibhqscWNRZTZcevnptUcINRlpIOXZGFQMEfyakGqwxmKGEJysHyonfNDLrdlcYNmRxMVDuZnyAnDdIhOyRMMgzCDjUuAnYabLXUboIbJjyORVYOVHKXWJXvpWkYGbXYgoExuSKLfwqnAcGlqTvBPnYstDpwsxiPwZPdZMzbtmchXswPGEoCKoQVAgPTepDLSdRvuYtAuERvUkJqdeEYmnpISPeZS"), string("UxLBqnAhwOKqupWcSrJmWkVcCkmXLtTlNSpdAjmGoNg"), string("XkuxqkvrRhlsaNagCAlAXkLdaYQJFLOhIVqbqFxskRuNIvHGkMqutM"), string("cmegTlEmDfLvwuWfrqIblDUBjhnyXtVxuWcSTysuAvCwUNuuCNijsOjrzjslkrjOtyfzZICjIqPVEZGrouewdFNEWjhJqZhFDIqPAAVRXYxJiRmfpOvttKFrLRPKKMaPoeMHlRARboJTCyRgxdGBzMvbEInNQBBpqOicqbJHkWMzLLEQPBHgZhVvPRfwQiDqbWNXXU"));
    this->qTtgmmfk(true, 135398190, true);
    this->TOHhKhmpcJ(string("kshZbWbyJdIwerVidajmzLIggaSvoflYpGHZUObdwBzqVkqRKruSQwKRvLtWWwfkBFNgqjuKwsUWzUqij"));
    this->NtaNhmmi(-947382.3542352801, true, string("YMJWDmbpssYqYgbcxBNUycZdGyjOVIJKPqRATHyzRFYFYjAYEEtWhjmTVhBqKUbEeSQLICMMyZPAUeMBWrtHHhtliLjFEQtPjCkRhnwFUqPKwmLIqFUDTYptJaHVkdpbSgCykJKRHBScaaOyqjHFYxcBMcsoOqBQpEQLzlWnBgyBCLItTjOWnpNdmzgkEqjFPUkYIBGVfVGsumSZLihAijcdvozieahkTCXPexze"), -1338445060, string("pvlyvdPAHWicgNupzInTFDYYfybULqHnBQbEXiuQmsYzUCZMOzjjPVePlApVfjwPeiktiROyePsCqOuGIkIaqKnnI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TlqKExZVlaJxR
{
public:
    int RKwQNWR;
    int SgjpSifOWXqP;

    TlqKExZVlaJxR();
    string eIXeOanPazKUuhmv(bool ImTOvjZJXq, double URqHEGE, double xmvmpGNmxoUo, double GrvQmoLUYYkZj, bool zUtyITFMIyH);
    bool IGyfysF(bool baXRAzO, string xXligPhR, double yTwoU, bool mBFuzumBayDKkS);
    int hXsoVRm();
protected:
    int cEyWkaCAoSg;
    double SPTuZL;

private:
    string tIRepvYVHnmYgkgV;

};

string TlqKExZVlaJxR::eIXeOanPazKUuhmv(bool ImTOvjZJXq, double URqHEGE, double xmvmpGNmxoUo, double GrvQmoLUYYkZj, bool zUtyITFMIyH)
{
    bool asAfejzEK = true;
    int QDoLa = 961090225;
    double Ykklpp = 971807.8343868002;
    double CEhtwOhfCUjflo = 152749.93309246917;
    int hEvFLK = 1149614444;

    if (Ykklpp != 33942.285513506635) {
        for (int zoAqVK = 973561367; zoAqVK > 0; zoAqVK--) {
            GrvQmoLUYYkZj += Ykklpp;
            URqHEGE = xmvmpGNmxoUo;
        }
    }

    for (int pmDfPEyigWyWq = 1660034138; pmDfPEyigWyWq > 0; pmDfPEyigWyWq--) {
        CEhtwOhfCUjflo += URqHEGE;
        GrvQmoLUYYkZj -= GrvQmoLUYYkZj;
        URqHEGE *= Ykklpp;
        ImTOvjZJXq = zUtyITFMIyH;
        CEhtwOhfCUjflo += URqHEGE;
    }

    if (GrvQmoLUYYkZj > -578496.5402370254) {
        for (int WLTpCm = 106497073; WLTpCm > 0; WLTpCm--) {
            URqHEGE = CEhtwOhfCUjflo;
            hEvFLK -= QDoLa;
        }
    }

    if (ImTOvjZJXq != false) {
        for (int Uyvjle = 1115744891; Uyvjle > 0; Uyvjle--) {
            continue;
        }
    }

    for (int WoDqYsL = 1263471694; WoDqYsL > 0; WoDqYsL--) {
        URqHEGE /= URqHEGE;
        xmvmpGNmxoUo /= CEhtwOhfCUjflo;
        CEhtwOhfCUjflo -= xmvmpGNmxoUo;
        Ykklpp = GrvQmoLUYYkZj;
        CEhtwOhfCUjflo = xmvmpGNmxoUo;
    }

    for (int sgyZZnLTd = 1634836139; sgyZZnLTd > 0; sgyZZnLTd--) {
        hEvFLK += hEvFLK;
    }

    return string("ituKNGkECdvNQMmesZXMLItRU");
}

bool TlqKExZVlaJxR::IGyfysF(bool baXRAzO, string xXligPhR, double yTwoU, bool mBFuzumBayDKkS)
{
    bool zpjYtrEZnBCBoGD = false;

    return zpjYtrEZnBCBoGD;
}

int TlqKExZVlaJxR::hXsoVRm()
{
    int FBaFnDDIQwafK = 234554830;
    bool RExKtQChsHush = true;
    bool JOcxJNHiCsImiGJ = false;
    int qaolIatwQo = -1659740719;
    bool kCMKod = false;
    string lduxBWY = string("ksCNcEbqmMKoEpnANZOmniMeSDFPAjnHZHoltQupuLPvmGZQMjfxRcFjzejEtDobQsCqOYktFgvVbBDUAnRCriIhYTGiPInZDVfVLKYgafdFLjFdvSlNZUhKkvnsRteyaXnemYXcQhbLjrnOYHZVbycKrLdLqNKLUDYZEEbahEc");
    bool KCZUSYYHBy = false;

    for (int MViPRR = 1587850725; MViPRR > 0; MViPRR--) {
        JOcxJNHiCsImiGJ = ! kCMKod;
        KCZUSYYHBy = ! JOcxJNHiCsImiGJ;
        KCZUSYYHBy = kCMKod;
        kCMKod = kCMKod;
    }

    for (int zXrxZV = 532571375; zXrxZV > 0; zXrxZV--) {
        KCZUSYYHBy = ! kCMKod;
        kCMKod = RExKtQChsHush;
        kCMKod = ! KCZUSYYHBy;
        kCMKod = ! JOcxJNHiCsImiGJ;
    }

    return qaolIatwQo;
}

TlqKExZVlaJxR::TlqKExZVlaJxR()
{
    this->eIXeOanPazKUuhmv(true, -578496.5402370254, 614479.9710753278, 33942.285513506635, false);
    this->IGyfysF(false, string("dshGUcpqTdTBDpcDiONzDRZnNNIygdWnevregLjnkKQENsNNKWYTqApJtjZIOnFOLeXjskpkeXqQDowMXkKXoHLNQluaCFnEZHISdVRofXVyPWPbjRyMcXETTNBEkEGcSEfoaTrarkSVImrxvGBqsCjtmmYqUrMaHBZCHJzhIq"), -428242.78988152434, true);
    this->hXsoVRm();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class afByg
{
public:
    bool xvqCvCLgco;
    bool vuarzSllssU;
    bool SMVWZgV;
    double qRJAckA;
    double RKOAeDi;
    bool DYxSmohSjpmflET;

    afByg();
protected:
    string VfemEWuNiXN;
    double aavKCldGCUwioPy;
    bool aaZEOhiLzB;
    int ubvGHphp;
    int xtSfKSTaGE;
    bool vabwnjOywjJXPj;

    string VKaeasqNhuHUqwQ(double YVVzrfmuJwXY, string AYXwCjMIQkcMDS, int DzvTabrrGoO, bool bnuLqnaeqqlsQn, bool qZrfv);
    string uqpCjqDrEZlSCJ();
private:
    int atUrGYDeYGDR;
    string TnbMc;
    bool gfPDZ;

    int RJzcsD(bool mMnRlRqqkln, bool sedHCVVvoXb);
    void gXcCyY(int WDrETzcWAr, int KSFerewQBaNaq, int zXiepxqwwBH);
    string JXmhiFcKen(int AXKotUHhWwUMVhk, int hCHARg, double QWUPBak);
    int YvVwOqmNf(double xkgbaolBC, double YNfPOxsmUHugy, int dsVShXGWMPb);
};

string afByg::VKaeasqNhuHUqwQ(double YVVzrfmuJwXY, string AYXwCjMIQkcMDS, int DzvTabrrGoO, bool bnuLqnaeqqlsQn, bool qZrfv)
{
    bool gCauzBfKEWLVk = false;
    int npnxStnU = -1848373574;
    int ygLUhyXIDK = 252087473;
    string odHfwQueMcBe = string("jcQFdkJCO");
    string QCIsuvIcedz = string("aGrFoyzHftGXNVIRnYUURclCTiiSHHnJbXfEjcjUTePANSPOleNVECMnTsbLDCsrVhyAYRijKjNUfBodlqpnghMkLKMwtzUGjmYdrWDZCmzyiWbXHsbWyTYFXUszRoSdxeYkkXFyBrvpFBUVxGGBjwWKakCKHlxFxqZsWBPRlsSWzNxpPFutqYkFhoMHscFYsCMLyKyMXaxbswpvZSntvvdIkuWNPWZvgtKCLgeDvdqAdrCdVZwRthR");
    bool cVfSNVro = false;

    for (int taZjyLMzrcqQZ = 1265498088; taZjyLMzrcqQZ > 0; taZjyLMzrcqQZ--) {
        qZrfv = gCauzBfKEWLVk;
    }

    for (int GcJgiXC = 897208697; GcJgiXC > 0; GcJgiXC--) {
        bnuLqnaeqqlsQn = bnuLqnaeqqlsQn;
    }

    if (ygLUhyXIDK <= -1848373574) {
        for (int gGaHtUJKStk = 498380815; gGaHtUJKStk > 0; gGaHtUJKStk--) {
            gCauzBfKEWLVk = cVfSNVro;
            cVfSNVro = ! bnuLqnaeqqlsQn;
            qZrfv = ! gCauzBfKEWLVk;
        }
    }

    for (int lPaQvcbjir = 1469364866; lPaQvcbjir > 0; lPaQvcbjir--) {
        YVVzrfmuJwXY = YVVzrfmuJwXY;
        DzvTabrrGoO += ygLUhyXIDK;
        cVfSNVro = bnuLqnaeqqlsQn;
    }

    for (int AQTiKrjMsY = 647353435; AQTiKrjMsY > 0; AQTiKrjMsY--) {
        bnuLqnaeqqlsQn = bnuLqnaeqqlsQn;
        npnxStnU *= DzvTabrrGoO;
        AYXwCjMIQkcMDS = QCIsuvIcedz;
    }

    for (int dGRvzknLTyGstXc = 2119968822; dGRvzknLTyGstXc > 0; dGRvzknLTyGstXc--) {
        bnuLqnaeqqlsQn = gCauzBfKEWLVk;
        QCIsuvIcedz = odHfwQueMcBe;
        YVVzrfmuJwXY /= YVVzrfmuJwXY;
        cVfSNVro = bnuLqnaeqqlsQn;
        DzvTabrrGoO -= npnxStnU;
    }

    for (int aFWxaUGsYQHFYGD = 36373796; aFWxaUGsYQHFYGD > 0; aFWxaUGsYQHFYGD--) {
        qZrfv = ! cVfSNVro;
        qZrfv = cVfSNVro;
        cVfSNVro = cVfSNVro;
    }

    return QCIsuvIcedz;
}

string afByg::uqpCjqDrEZlSCJ()
{
    double nUTrZ = 223735.277333264;
    string FTMNlqxdQgaoWK = string("RYUGcxtaxJecnsqXPrpUKugWJ");

    if (nUTrZ < 223735.277333264) {
        for (int IWXnJkxtj = 1746817103; IWXnJkxtj > 0; IWXnJkxtj--) {
            nUTrZ *= nUTrZ;
            nUTrZ /= nUTrZ;
            FTMNlqxdQgaoWK += FTMNlqxdQgaoWK;
        }
    }

    return FTMNlqxdQgaoWK;
}

int afByg::RJzcsD(bool mMnRlRqqkln, bool sedHCVVvoXb)
{
    bool NwBNpFP = false;
    double GBrMDnMLyTrVOEY = -776868.2214104733;
    int OxGDP = -1546507320;
    bool OFqeeVPnNkRkW = false;
    bool oHECMgvpoZD = false;

    if (oHECMgvpoZD == false) {
        for (int LWPPQgE = 1907127796; LWPPQgE > 0; LWPPQgE--) {
            sedHCVVvoXb = ! OFqeeVPnNkRkW;
            sedHCVVvoXb = mMnRlRqqkln;
            NwBNpFP = NwBNpFP;
            GBrMDnMLyTrVOEY /= GBrMDnMLyTrVOEY;
        }
    }

    return OxGDP;
}

void afByg::gXcCyY(int WDrETzcWAr, int KSFerewQBaNaq, int zXiepxqwwBH)
{
    int qCFPieqUWKZt = -114505743;
    string QtkSFVkoMnMcMaQ = string("bWnGgQJOzBmSCdKBptQacMibzWiewxNnYemuNBIBwipjGEGIIhWwHyTiawIqQTjDVaQwUElOIFGUlSmPXuWMuKkYCijpgAcvsowtVNhghTkQvSeccltkLPDBvlUWuoeFoQkFDpr");
    string mlgSuEvKLT = string("SlCLPcNnEtEqeHaevkqEFzgKERJjKygXfkLJUsezFjAPDFTXFXHzHFsRwSQyfvjSTmQzXBXBXhzeuRCAouXmmJcVfpWSTiLkIuyKgwGIfJzTgWtTEtZCbZRIDFwUiPTUumQLfQHyoBYopIoxRiynndTynALwyM");
    int GDxEIEbrLF = -1716211538;
    string rgPvONxa = string("njWZxdSGbTzGmqPcVpxwkHODrFdzYMXWtLYQmJqAzMpTOThslyBKWppjpHGbJeIeFnkJCeKJMPhvtWpDQbawwcVmLmDJHtPpwggxatpLjiKZaZGVMPPGlCEsUveYDAYVN");
    double fbQeysgfwUzSqWgb = 398234.59158733964;
    double iceOrdtpyofigm = -89705.39349108854;
}

string afByg::JXmhiFcKen(int AXKotUHhWwUMVhk, int hCHARg, double QWUPBak)
{
    int rRWIOkIPrstIxIWv = 850848094;
    int DgDfy = -1065069189;
    bool TKuROgdPn = false;
    double LatUWBo = -930026.3150448279;

    for (int ZBxxWy = 211676978; ZBxxWy > 0; ZBxxWy--) {
        LatUWBo /= QWUPBak;
        QWUPBak += QWUPBak;
    }

    if (rRWIOkIPrstIxIWv > 850848094) {
        for (int QdmEZsyrD = 871021880; QdmEZsyrD > 0; QdmEZsyrD--) {
            QWUPBak /= QWUPBak;
            hCHARg = hCHARg;
            hCHARg -= AXKotUHhWwUMVhk;
        }
    }

    if (QWUPBak != -930026.3150448279) {
        for (int WtqFH = 291721864; WtqFH > 0; WtqFH--) {
            rRWIOkIPrstIxIWv += rRWIOkIPrstIxIWv;
            LatUWBo -= LatUWBo;
            DgDfy -= hCHARg;
            AXKotUHhWwUMVhk *= hCHARg;
        }
    }

    return string("VRxnTXikvFDmMgHJZIIixMoUzILObEQQcghTGdXkWZlubImHgYHnQGiRSnTQxnjNyN");
}

int afByg::YvVwOqmNf(double xkgbaolBC, double YNfPOxsmUHugy, int dsVShXGWMPb)
{
    bool RqGMdqv = true;
    double wwHrCBcNK = -72548.21820454848;
    string mAXOX = string("JDQkvzdVaUvBJQbInmhhFNXJlXNPIbqfrMYcKnVjmsmbgyCQYVIdqGgbZjowMGzZPhyfWJnwMzqdeJsdypHLKLaCrLGBcUssvlYAncZTLfvmDAXxuAuoXYfVJGYkEJHPeTifgfQGcyoduyGTWoHyUSfafVvtXljMesFzjGrcWqhigWIyaUlkUzQBAaaqouDUReLPKOBU");
    double ZSitdlbkj = 813601.3995058239;
    string yHCuQGYNyxGGWFjP = string("AfsZDCiIpateYBSZMaexdZOwEAtPCrikUFnBenAMqSPrTOnTlqfltZktAhCWeMeGCMxcLSehlBbdIEkWgfhKcruTzkAODlsfPTkJLBXFZSkgBcJQSTbACzLuhbaPgiXMWsozGJliOPHMntQEQJgDjJZpszKDPSkqptasPjssvXSPXdrQQYilfWhzryHFwLaZZgoQnzGFGgPIhgFcfsXCDbDpKBGKVFmCcumbRhuggHCWuFKAgjCpTIfSnG");
    string qWbBhmrp = string("dmSyermfoQFhRSMSenxKrccEEvNKTaKhUZEADPDnqLVWtedacKBOZOXrlyNGqnePBYHVweGXOFqoiSoQSFYhneEiFobgoeKKnYzivaRNJYeDxEtkpFpRidwoUkZNezqVNnIotJKTdkUqfsxCCWmeDZPPnVqyvthYWjHPvYIapylMKrZHHhNyOVePrPzxgQPQrdFFFXeCqcEZvNcpW");
    bool APFEbW = true;
    bool JFqNP = false;
    string HpadXgntcVo = string("FcowaKmrxepVswOkSIALoUsTwmuoQKgYAAqIrMElzDyZEEDhJJjBGYtPzEOtLfziXHGKdOsEBNvFabEWuqeYZmHEoMaDQLgzNfIZTFmfjMqYQh");

    for (int yyoxssIYIgStzlD = 990028452; yyoxssIYIgStzlD > 0; yyoxssIYIgStzlD--) {
        wwHrCBcNK /= xkgbaolBC;
        wwHrCBcNK -= ZSitdlbkj;
    }

    if (HpadXgntcVo <= string("JDQkvzdVaUvBJQbInmhhFNXJlXNPIbqfrMYcKnVjmsmbgyCQYVIdqGgbZjowMGzZPhyfWJnwMzqdeJsdypHLKLaCrLGBcUssvlYAncZTLfvmDAXxuAuoXYfVJGYkEJHPeTifgfQGcyoduyGTWoHyUSfafVvtXljMesFzjGrcWqhigWIyaUlkUzQBAaaqouDUReLPKOBU")) {
        for (int BsNUHsuVmsamnUq = 30745023; BsNUHsuVmsamnUq > 0; BsNUHsuVmsamnUq--) {
            continue;
        }
    }

    if (HpadXgntcVo > string("dmSyermfoQFhRSMSenxKrccEEvNKTaKhUZEADPDnqLVWtedacKBOZOXrlyNGqnePBYHVweGXOFqoiSoQSFYhneEiFobgoeKKnYzivaRNJYeDxEtkpFpRidwoUkZNezqVNnIotJKTdkUqfsxCCWmeDZPPnVqyvthYWjHPvYIapylMKrZHHhNyOVePrPzxgQPQrdFFFXeCqcEZvNcpW")) {
        for (int pvwSjd = 1275769148; pvwSjd > 0; pvwSjd--) {
            mAXOX = qWbBhmrp;
        }
    }

    if (HpadXgntcVo > string("JDQkvzdVaUvBJQbInmhhFNXJlXNPIbqfrMYcKnVjmsmbgyCQYVIdqGgbZjowMGzZPhyfWJnwMzqdeJsdypHLKLaCrLGBcUssvlYAncZTLfvmDAXxuAuoXYfVJGYkEJHPeTifgfQGcyoduyGTWoHyUSfafVvtXljMesFzjGrcWqhigWIyaUlkUzQBAaaqouDUReLPKOBU")) {
        for (int HTctEZZUMdWB = 1269102451; HTctEZZUMdWB > 0; HTctEZZUMdWB--) {
            xkgbaolBC = ZSitdlbkj;
            qWbBhmrp = HpadXgntcVo;
            wwHrCBcNK /= xkgbaolBC;
            qWbBhmrp = qWbBhmrp;
            ZSitdlbkj *= ZSitdlbkj;
        }
    }

    for (int xWDuYjkvCxOz = 896327848; xWDuYjkvCxOz > 0; xWDuYjkvCxOz--) {
        xkgbaolBC /= YNfPOxsmUHugy;
    }

    return dsVShXGWMPb;
}

afByg::afByg()
{
    this->VKaeasqNhuHUqwQ(103591.9356822303, string("WulhijwfWmutwuLYldFvSVCqdcaAwikpqPrKCvbndaunVliHbvPdAghjrMOxIxorQNYXxFqsTyeWvDosijVLXWnSPTNfsCqwcEJKoxbiIjMPAIgRDAxhUfbgMrOSzfZWvypGBkGVMHECSChCoTsSSytUYvYawkuJcEHGkWHScGZopQnEsPSBvVKMSTLObhUEeKDEzdTwZPxhFBQDGOoDXPtRpoxuqEDStpIYCDzJGEYNAYb"), 268297443, false, true);
    this->uqpCjqDrEZlSCJ();
    this->RJzcsD(false, true);
    this->gXcCyY(206840564, 1016190199, -1151997440);
    this->JXmhiFcKen(-1948539819, 535009645, 248477.86047019323);
    this->YvVwOqmNf(-693718.3540607175, -246119.11213614958, 1554277946);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZuXTMtwqikXzNkV
{
public:
    double anfLzTI;

    ZuXTMtwqikXzNkV();
    bool mMKHOMUQmPeMAe(bool vtjQTgsSQvdo, double fPkILwepbWFwL, string mfBvv);
    int ereqOKO(double sEsotlTEv, string JzEbWMFzkgMRMDxU, int xdaFMorg, bool NpCgcdNB, bool tZcWdLRtr);
    double UOKfESCHpz(bool gRKPlYUszULBHEsQ, double DwVLgrwmfvMcN, bool UFgIlRbQTg, string wsfwByqcGacTsBox, int JSpEyLP);
    void kWNSFhcHDjo(int OdDYCQhgcBhcDj);
    int hsjBctWakGa(string BaNyRaSCsEIVaoi, double gKXaWZEs, bool jBlVoAmEa);
protected:
    string TfwERyxzTxzcSZeb;
    int IYovBCgNV;
    int WVOWKeQUNpxly;
    int amTlnNtAfrp;
    string SiEaZZCr;
    double egyPQvivVJylzn;

    void dPgoPak(double rgLUGYsfKdhjT);
    void GnjwOnYwqA(bool YXmYNkh, bool oWkCmdcYIbtQpI, int ltQJM, int jRzNCOSjYfXPXTJx, bool MPmdtAvGUKTqq);
    double MInUTFBFUKSgRH(string sBafggPayZmu);
    int GiEYPrAWpmnP();
    bool IfXLwPaytNgwzW(int JFdhrlvzHsGAYYn);
    bool GeOCERoKGMbx(int LPoQZFwEbdbH, int irVRD, bool JfTvVRdBriuFciT, int QjlMjHWskx, int XLQOjCJh);
    void ucohTzgfoATlCzX(bool pNmxnCXNLholjUo, string HuZjzsgrfq, string uFbhmDBeCDaJuI, string blvrgtnShQU, int lbFTca);
private:
    int FpjoTsqcpImio;

    string rmqvDKjQv(double lWRhEgoPMP);
    string bBCXYV(double IvgloE, bool WtiKgVvKYkHLRJ, string GgreYGyRyFrPuT, string stWyqEJHg);
    void dZXCcPfkosEVICGr(double pEbXHEMTGOVMXu, double PIPNCswqo, double vQefHV);
    double disYIpglznOsq(bool FTglvimPzDZRUWL, int SmwZwZMRKadP, int mYfmutIUOD);
    string AIEkQdHSMyL();
    void SpoMVnGMYHkgmPeW(string JrFjrIL);
};

bool ZuXTMtwqikXzNkV::mMKHOMUQmPeMAe(bool vtjQTgsSQvdo, double fPkILwepbWFwL, string mfBvv)
{
    int GGVYLfrWSZNh = 1619819609;
    double uonUQQkRQ = 411137.5428140965;
    bool DUgSEgAjRrr = false;
    bool ExvLaFgChq = true;
    bool ZzuoNivt = false;
    int QdpfCRot = 350355499;
    int ZFPHnaFx = 822647099;
    double MJTwxodazUTTuxe = 976596.3038412626;
    double lpuCbeDbPoB = 685315.7751323868;

    for (int scoOHZwSbAPicKfZ = 125743982; scoOHZwSbAPicKfZ > 0; scoOHZwSbAPicKfZ--) {
        continue;
    }

    for (int jvhRM = 1674946990; jvhRM > 0; jvhRM--) {
        vtjQTgsSQvdo = vtjQTgsSQvdo;
    }

    if (MJTwxodazUTTuxe != 976596.3038412626) {
        for (int CyRHSHHeWUHCT = 432982906; CyRHSHHeWUHCT > 0; CyRHSHHeWUHCT--) {
            fPkILwepbWFwL /= lpuCbeDbPoB;
            GGVYLfrWSZNh /= QdpfCRot;
            fPkILwepbWFwL *= fPkILwepbWFwL;
        }
    }

    for (int Agvxkeqnamabg = 477022958; Agvxkeqnamabg > 0; Agvxkeqnamabg--) {
        ZzuoNivt = ! DUgSEgAjRrr;
    }

    if (vtjQTgsSQvdo == false) {
        for (int AwQmpnroKde = 288581124; AwQmpnroKde > 0; AwQmpnroKde--) {
            continue;
        }
    }

    return ZzuoNivt;
}

int ZuXTMtwqikXzNkV::ereqOKO(double sEsotlTEv, string JzEbWMFzkgMRMDxU, int xdaFMorg, bool NpCgcdNB, bool tZcWdLRtr)
{
    double OpWJNkFmBRLjhaMZ = 769231.2323907496;
    double QwCsVDTnkwSn = 929920.1976211932;
    int rYLfuW = -611388680;
    int AmJVPBgglIenORBX = 658956927;
    int bFqDchIzo = -1029422387;
    double jtCGsYxr = -637682.679136641;
    bool WQoOobpQAm = true;
    int xndIBnJkWbPXLmbf = -1005732224;
    bool vovoUEThvjfoh = false;
    int IeHaYRTUn = 1974282362;

    for (int LHpFLQtm = 10978118; LHpFLQtm > 0; LHpFLQtm--) {
        OpWJNkFmBRLjhaMZ /= OpWJNkFmBRLjhaMZ;
    }

    return IeHaYRTUn;
}

double ZuXTMtwqikXzNkV::UOKfESCHpz(bool gRKPlYUszULBHEsQ, double DwVLgrwmfvMcN, bool UFgIlRbQTg, string wsfwByqcGacTsBox, int JSpEyLP)
{
    bool vpBRR = false;
    int MZFbYKXPwbAucCzf = 512992969;
    double jRgrn = -796425.818444581;
    string PJnLvBUrCAF = string("yLSLNSDeAmMPFtULYbHsGRVqirTohfcGqggbjtldGLnNLaviJqYrxkdkSu");
    double inLDZlGlMeXnze = 360117.9157751816;
    int HZVDJijFds = -1646739845;
    bool xRwAJnj = true;

    for (int VguWVE = 127404719; VguWVE > 0; VguWVE--) {
        xRwAJnj = gRKPlYUszULBHEsQ;
        gRKPlYUszULBHEsQ = ! vpBRR;
    }

    for (int DaNRJzjJMekldqP = 982628606; DaNRJzjJMekldqP > 0; DaNRJzjJMekldqP--) {
        continue;
    }

    for (int ykQlTbhXjl = 1553451614; ykQlTbhXjl > 0; ykQlTbhXjl--) {
        inLDZlGlMeXnze = DwVLgrwmfvMcN;
        inLDZlGlMeXnze += DwVLgrwmfvMcN;
        jRgrn *= inLDZlGlMeXnze;
    }

    if (wsfwByqcGacTsBox != string("SmVqryLPzhHtSicAcShoybzJHsmAEWoxzymhqMVgpuZKKBnFcMQLKOsYvvQBuVOazBNcLEjcXLkxxyvGhvrgtRhVTjaFWzqQSio")) {
        for (int lsWiLVEtLwFViBm = 1794189401; lsWiLVEtLwFViBm > 0; lsWiLVEtLwFViBm--) {
            UFgIlRbQTg = xRwAJnj;
            xRwAJnj = ! UFgIlRbQTg;
            vpBRR = ! xRwAJnj;
        }
    }

    for (int jiaJX = 870588878; jiaJX > 0; jiaJX--) {
        vpBRR = ! gRKPlYUszULBHEsQ;
        jRgrn *= DwVLgrwmfvMcN;
    }

    return inLDZlGlMeXnze;
}

void ZuXTMtwqikXzNkV::kWNSFhcHDjo(int OdDYCQhgcBhcDj)
{
    string BZCtzdp = string("LYgTpdmArCwOdIXzAyyusLMJKXDdKKpdLmEERJFbnKjcJlWyZufanknvgCiWzgEMHnMJMoyQfxZotmYCUFcqtCdTeCQtZYoOdTmSYpfWgLXqpunUybxFiDrPdYastdsVKZVEQmkypEAZzWAxvmkMDmRGepUIfrthYSBgdByreyhUoGlgjDREzABRRojZtHvFBhREVpfcXRIXlWoPfp");
    int hzQXYb = 47068224;
    double ftrJgFbYkUdKgr = -743542.7391086437;
    string xHUnXYXvpIXwahw = string("FhKrkDAJcjOGoVbNhEpLwFSu");
    int sONyMXxnnNLzLF = 1787610034;
    int zGLzC = -291797370;
    string fHbGdHVCiTVbbM = string("PSaMdaSbmOdNqvBjDAiSznZxKSvpUhdVdXZvAXkPnxdMkmSSNYxhCnkApFIsvryranfxUMKKNSGoQYRfFSIkKHrRpfSJWJcJBxlQmFsagqkldWZnSWCCgqHwtDEaOyDjZyLoyFewPOrLNcVhRfRhTyfDiIOPF");
    double KZsrHCRqSNr = 1001249.5491523023;
    bool krBmmoLi = false;
    double oTqWbZMmrpiHCR = 190264.74647827857;

    if (fHbGdHVCiTVbbM == string("LYgTpdmArCwOdIXzAyyusLMJKXDdKKpdLmEERJFbnKjcJlWyZufanknvgCiWzgEMHnMJMoyQfxZotmYCUFcqtCdTeCQtZYoOdTmSYpfWgLXqpunUybxFiDrPdYastdsVKZVEQmkypEAZzWAxvmkMDmRGepUIfrthYSBgdByreyhUoGlgjDREzABRRojZtHvFBhREVpfcXRIXlWoPfp")) {
        for (int QqqUDkhMDveSAYnX = 1139213546; QqqUDkhMDveSAYnX > 0; QqqUDkhMDveSAYnX--) {
            continue;
        }
    }

    if (fHbGdHVCiTVbbM <= string("LYgTpdmArCwOdIXzAyyusLMJKXDdKKpdLmEERJFbnKjcJlWyZufanknvgCiWzgEMHnMJMoyQfxZotmYCUFcqtCdTeCQtZYoOdTmSYpfWgLXqpunUybxFiDrPdYastdsVKZVEQmkypEAZzWAxvmkMDmRGepUIfrthYSBgdByreyhUoGlgjDREzABRRojZtHvFBhREVpfcXRIXlWoPfp")) {
        for (int SEiqYSWLyZ = 278568312; SEiqYSWLyZ > 0; SEiqYSWLyZ--) {
            continue;
        }
    }
}

int ZuXTMtwqikXzNkV::hsjBctWakGa(string BaNyRaSCsEIVaoi, double gKXaWZEs, bool jBlVoAmEa)
{
    bool ltJftmpBasif = true;
    int HwZAwWjzWEhy = 1920255049;
    bool nfcGEVSCVbtAcP = true;
    int sjVzhzu = 2041276580;
    int OoTDqTTqYMSjVksY = -801546066;
    int leJfXjMswCq = 1357856906;
    string cKXtEcDEeBQWEu = string("tizYlXuXhATqCpuYbANMzEMXdaGuuLfBkJCCEtROMztcYcFigeYTdzvIKCDIFUAHbOqCDeVxOlhQbQsOKFtwiyJNNWPLFDBycazSsmnkA");
    double zTASITYztTJlDz = -572722.2511547008;

    for (int QXOoFcyuBGthTs = 198660694; QXOoFcyuBGthTs > 0; QXOoFcyuBGthTs--) {
        zTASITYztTJlDz = zTASITYztTJlDz;
        nfcGEVSCVbtAcP = jBlVoAmEa;
    }

    for (int BRepSaOrSY = 1161734102; BRepSaOrSY > 0; BRepSaOrSY--) {
        OoTDqTTqYMSjVksY = OoTDqTTqYMSjVksY;
    }

    if (HwZAwWjzWEhy != 2041276580) {
        for (int JzASyHLAibGmj = 560192715; JzASyHLAibGmj > 0; JzASyHLAibGmj--) {
            nfcGEVSCVbtAcP = ! ltJftmpBasif;
            ltJftmpBasif = ltJftmpBasif;
        }
    }

    return leJfXjMswCq;
}

void ZuXTMtwqikXzNkV::dPgoPak(double rgLUGYsfKdhjT)
{
    double ywyHOfVqifSH = 929440.1508151873;
    int xEYRSGdyNAdKkbXb = 1900514088;
    string eTjudoLqluDOEoU = string("BgctXMfsXeAUzGnHQLqyPGDeIcZQrsOELGQpVOOKVdUZhiwDKFmAwCjugGMMYGMxHbcXrPBFEVQdekMJbnMuLSaaUSEnUQRvZvbeoTvJMbcXMFBgKuiQnYhNLSHgzqSbhnSqGpUqmwmwmvEoxwGWOBfaqnmpEfZguqnhFRBGJsXauCkIYVgphQyNqQSGnGHPLQfemJaMHmGUkOPiX");

    for (int telCADsq = 814811963; telCADsq > 0; telCADsq--) {
        ywyHOfVqifSH += ywyHOfVqifSH;
    }
}

void ZuXTMtwqikXzNkV::GnjwOnYwqA(bool YXmYNkh, bool oWkCmdcYIbtQpI, int ltQJM, int jRzNCOSjYfXPXTJx, bool MPmdtAvGUKTqq)
{
    double ZrgeTFEXWmZTd = 1046645.6521931485;
    string eQPaJMDkimw = string("sAiUGEdNIlBKubRrrFELUlYKdfWemRKzaIvtpiiJbCQXOeFrXcSrbfNLJLPDUmZBpINRFFe");
    string LWEWR = string("gmPSdrKFITWMsYyuGcLpRMCxparCSgnMkdbJPvDUapekGksjxdsjbmsbLZIvuXfmXDMEyoSNHcuVAqYfpjFUpzLJvmzKKmghiFHepvJvLykEHkcjbwVzqHSGNjkXGKqdEaIiyJNhIFvqBCraTdbhfClkljlzyIkYdhYKXUZxqPpmCrakPKAOqkY");
    bool DcJVkl = false;
    double JfSYz = -251265.94015384465;
    int AtLzCLQ = 631382410;
}

double ZuXTMtwqikXzNkV::MInUTFBFUKSgRH(string sBafggPayZmu)
{
    bool NCgMerht = true;
    double trHOX = 955155.3491219096;

    for (int nehfiWIJdJvtnJe = 847242376; nehfiWIJdJvtnJe > 0; nehfiWIJdJvtnJe--) {
        trHOX *= trHOX;
        NCgMerht = ! NCgMerht;
        trHOX = trHOX;
        NCgMerht = NCgMerht;
    }

    return trHOX;
}

int ZuXTMtwqikXzNkV::GiEYPrAWpmnP()
{
    bool gkHMKGsyihnmVJl = true;
    int yGuBHAt = 609623958;
    string DqnWkWGWkueUunV = string("GaONqZdktNvWASKEIkKIzoTMgFqbfbSZqhGoopOBMrExGUvAfAdOyxUkQtSgAOZOHFLGItyACjCVWSXmLYxP");
    int HhfXtPkNSlKhvyIO = -242338224;
    string GVxjDUUNoT = string("kbEWrlbcBkJolzhiNnopwcBYbTwNVyxZstJVfoxUqYCjVWyphbwfHRwrgnYWlARqeWwqrRUWLxXatHQMamFXUMmWVxKwqPHvcWuXJHIjslJmBqrHbKTNeuEXechpaxjecrkCI");

    if (gkHMKGsyihnmVJl != true) {
        for (int KBHExzsVJ = 2124682524; KBHExzsVJ > 0; KBHExzsVJ--) {
            continue;
        }
    }

    return HhfXtPkNSlKhvyIO;
}

bool ZuXTMtwqikXzNkV::IfXLwPaytNgwzW(int JFdhrlvzHsGAYYn)
{
    int FBAYEVFwVLptz = 322355828;
    int CsipoXGm = -377339792;
    double yOhbQpsZrUHSAFxj = -133945.40895683982;
    string Hfikk = string("efmDkjmGfkgEwGbrbMLRKXFRkvBqSVWifeYlZQLjzomXwrGmifKXjwTqMouuwrbgWZLkmswcFUrEiaHQMHBBhKmKIXpEoFTjMVtPGYpiebqiWYTwohbzckIMt");
    double ZnWzKiY = -399945.72045863525;
    bool dNbdwZGJ = true;
    double MfGKEyLdxYKU = 809762.3489916389;

    for (int fEsgvdNAGYp = 1765126208; fEsgvdNAGYp > 0; fEsgvdNAGYp--) {
        continue;
    }

    if (CsipoXGm < 322355828) {
        for (int HvWqPD = 820952057; HvWqPD > 0; HvWqPD--) {
            CsipoXGm /= FBAYEVFwVLptz;
            MfGKEyLdxYKU /= yOhbQpsZrUHSAFxj;
            FBAYEVFwVLptz *= CsipoXGm;
            MfGKEyLdxYKU = MfGKEyLdxYKU;
        }
    }

    for (int ngptbQiowvYe = 1116503651; ngptbQiowvYe > 0; ngptbQiowvYe--) {
        CsipoXGm -= CsipoXGm;
        MfGKEyLdxYKU = MfGKEyLdxYKU;
        JFdhrlvzHsGAYYn = FBAYEVFwVLptz;
    }

    return dNbdwZGJ;
}

bool ZuXTMtwqikXzNkV::GeOCERoKGMbx(int LPoQZFwEbdbH, int irVRD, bool JfTvVRdBriuFciT, int QjlMjHWskx, int XLQOjCJh)
{
    int PpNjZfFsr = -1520064649;

    if (LPoQZFwEbdbH >= -930420928) {
        for (int YuIStTNLYbIp = 1176063030; YuIStTNLYbIp > 0; YuIStTNLYbIp--) {
            PpNjZfFsr = LPoQZFwEbdbH;
            XLQOjCJh -= QjlMjHWskx;
            irVRD /= XLQOjCJh;
            LPoQZFwEbdbH += QjlMjHWskx;
            QjlMjHWskx += irVRD;
            XLQOjCJh += LPoQZFwEbdbH;
        }
    }

    return JfTvVRdBriuFciT;
}

void ZuXTMtwqikXzNkV::ucohTzgfoATlCzX(bool pNmxnCXNLholjUo, string HuZjzsgrfq, string uFbhmDBeCDaJuI, string blvrgtnShQU, int lbFTca)
{
    double klNTJs = -640786.5812684719;
    bool EuSMhiKUu = true;
    double xcwixlpeTxxZDu = 658446.571712606;
    int CNvFjwFxJnqBX = 2061953363;
    int Wswgs = 1337483653;
    int rgNEsmI = -66272637;
    double HDZIogQt = -606894.6446476876;
    int AOaLQLhqx = 1402613120;

    if (uFbhmDBeCDaJuI >= string("yyrvJTdaqRanWlnhjRsSgjppwkCsqiJgeWDqvTfCaRpDfHGAuUvVQwMSxdCfAWhuPFXgytXnSnTxRAqQOqnEhFBsGwVIUeGcWSDiutgminOyrikIPUonylZwNrWjxWFIOFOLZGmoybeZkXlFkalBMTMBUfMzqHGNIzvzAROKKyIa")) {
        for (int zLNUQnuDiLO = 976626276; zLNUQnuDiLO > 0; zLNUQnuDiLO--) {
            continue;
        }
    }

    for (int iBsbEU = 749082787; iBsbEU > 0; iBsbEU--) {
        continue;
    }

    for (int nzhWavLa = 1589961296; nzhWavLa > 0; nzhWavLa--) {
        continue;
    }
}

string ZuXTMtwqikXzNkV::rmqvDKjQv(double lWRhEgoPMP)
{
    string LSxUByLnlCeHx = string("uRnmuudVwNXPQEZEKVKZlAuKQYrnBhMzBzHPPSXLKzozfrYbLnKRNMWrIYCxaDWfhOTCbSyKCCkcJVzszuLHkOO");
    int anWDtNNtdXpkvZw = 1728867030;
    bool WkvPhTaGadN = false;
    double LGdUTNRgG = -753331.6135283456;

    for (int WBktsVRTQUrJpYF = 766401424; WBktsVRTQUrJpYF > 0; WBktsVRTQUrJpYF--) {
        LSxUByLnlCeHx += LSxUByLnlCeHx;
    }

    for (int LAanzEvT = 409269877; LAanzEvT > 0; LAanzEvT--) {
        lWRhEgoPMP *= lWRhEgoPMP;
    }

    return LSxUByLnlCeHx;
}

string ZuXTMtwqikXzNkV::bBCXYV(double IvgloE, bool WtiKgVvKYkHLRJ, string GgreYGyRyFrPuT, string stWyqEJHg)
{
    int hISUicw = 441774892;
    double HyNyWmFVmvWkVo = 616953.5750436919;
    string dXoneAWFrUcbtSe = string("PxevtUMEfEJlJUyxwFKnlRTqzpRegDEnGttxdYrcRVWhDXLnHaYjDFFNkLDjBZcJItYmt");
    double QbJmlEOpSnb = 68993.29721245122;
    double qIrhvixdk = 798347.070275836;

    if (IvgloE > 616953.5750436919) {
        for (int YNPjMfYsWODav = 758690552; YNPjMfYsWODav > 0; YNPjMfYsWODav--) {
            IvgloE /= HyNyWmFVmvWkVo;
        }
    }

    if (QbJmlEOpSnb == 798347.070275836) {
        for (int hiWKmcau = 1797862270; hiWKmcau > 0; hiWKmcau--) {
            continue;
        }
    }

    return dXoneAWFrUcbtSe;
}

void ZuXTMtwqikXzNkV::dZXCcPfkosEVICGr(double pEbXHEMTGOVMXu, double PIPNCswqo, double vQefHV)
{
    double hKVfp = 691030.3011117688;
    int pgztZJUWLzJv = 518629947;
    bool KMzcLehGDK = false;
    string jMBgngpXMV = string("htzxQXKappuCiyBApHtqODGHivHTlyIctBLOOVRJLlOYkjPOQgThTVwTFZnsOZrQlnTyEzCNLbejHwvfIEceKRnzYWWCSwLWsxlUekEaoHfXFnItYCbHzzQnoJZrgUjYXXabZvPEBIVTpqSHikUYBbFsDmlxybuo");
    bool eUBvdQALRMqvqX = true;
    string VCysyKAPVIqkj = string("TfxXsQqjedHVJcmLQTNFpTgKZKIzdXFrIzdhfPodPKHCuHdCeKajMQIPwcdrYtcBYjurnYYfUvRJdXCuoeomceXVhXYVMEtEzmkoubMiDsMbEFEnWEkekuPjdCIJVeedXYSbRmvNFbaJxDQjpWbUMUyBsFTyFJJGZDlvttRQTCAtJGLFOTXXmLmkPzxPhTLrXsFRPwTYfqJOQqRwnRxXwVSSjZckQSHwSNGZRAIa");
    string KidtBa = string("dxzzschazeZkmzuMNvuFTKDSSVZyqUuEgQETgDGSvXHpBeMRuztieEPLBfYQZKbYAVRKprDqmrCvrteiqlWSmMCKiFJHNhzeXVrhGBqZDUpKPAJwUQBdPHcWqh");
    bool xUrYVrPgmjFSUkkM = true;
    double BhdFyESnsdPd = 200446.49986232325;
    double iwanRqPYUxmq = -218270.97077844024;

    for (int yKBNJ = 578667154; yKBNJ > 0; yKBNJ--) {
        eUBvdQALRMqvqX = KMzcLehGDK;
    }

    for (int EgaEhRuhIqAxE = 275268741; EgaEhRuhIqAxE > 0; EgaEhRuhIqAxE--) {
        continue;
    }

    for (int gFJcPbSXZN = 757645486; gFJcPbSXZN > 0; gFJcPbSXZN--) {
        jMBgngpXMV += KidtBa;
    }

    for (int WNaNcGDO = 1083372301; WNaNcGDO > 0; WNaNcGDO--) {
        KidtBa = jMBgngpXMV;
        BhdFyESnsdPd -= BhdFyESnsdPd;
    }

    for (int cCxPbhuVsZzxVuiM = 1602714777; cCxPbhuVsZzxVuiM > 0; cCxPbhuVsZzxVuiM--) {
        jMBgngpXMV += VCysyKAPVIqkj;
        jMBgngpXMV += VCysyKAPVIqkj;
        PIPNCswqo += PIPNCswqo;
        hKVfp -= BhdFyESnsdPd;
    }

    for (int hrzwmizzyxmV = 2068832760; hrzwmizzyxmV > 0; hrzwmizzyxmV--) {
        hKVfp -= PIPNCswqo;
    }

    for (int eAZQfzBfBDhkBu = 1173621533; eAZQfzBfBDhkBu > 0; eAZQfzBfBDhkBu--) {
        iwanRqPYUxmq /= pEbXHEMTGOVMXu;
    }
}

double ZuXTMtwqikXzNkV::disYIpglznOsq(bool FTglvimPzDZRUWL, int SmwZwZMRKadP, int mYfmutIUOD)
{
    bool HRwoztKqRj = false;
    string mFloTEFZhgd = string("cmezJOamvZYECOGUdjYlDOgpuBBErCOodWlaGeAzqECsuv");
    double PFBwnFKclsjW = -562115.5012921774;
    int mxqKevNOGXVfE = -72280885;
    double qcvGUWDHeIg = 322177.7081306235;

    for (int eQXpNozTh = 149670828; eQXpNozTh > 0; eQXpNozTh--) {
        continue;
    }

    for (int qrWFsRYxFhjUA = 17256312; qrWFsRYxFhjUA > 0; qrWFsRYxFhjUA--) {
        continue;
    }

    if (FTglvimPzDZRUWL != false) {
        for (int HDAGZMFUMIT = 1697719523; HDAGZMFUMIT > 0; HDAGZMFUMIT--) {
            mYfmutIUOD /= SmwZwZMRKadP;
        }
    }

    for (int rrEnrKRgfCyZv = 954709836; rrEnrKRgfCyZv > 0; rrEnrKRgfCyZv--) {
        mYfmutIUOD *= SmwZwZMRKadP;
    }

    if (mxqKevNOGXVfE > -72280885) {
        for (int qMVCMRMRC = 1711245402; qMVCMRMRC > 0; qMVCMRMRC--) {
            mYfmutIUOD -= mxqKevNOGXVfE;
            qcvGUWDHeIg += PFBwnFKclsjW;
            mxqKevNOGXVfE -= mYfmutIUOD;
            HRwoztKqRj = FTglvimPzDZRUWL;
        }
    }

    return qcvGUWDHeIg;
}

string ZuXTMtwqikXzNkV::AIEkQdHSMyL()
{
    double MOWbajTNddmoLfig = 208659.175315061;
    bool cvzzJtn = false;
    bool tMQXfLyOlMUo = true;
    string CYecx = string("pFwEtkfSMZMYcELcvfQoMpwmGnYUOBtPZgTKGMbfEoJEWPkLYMNCKNNPWQzzrRcLbqgrqMhhCLTRZdEWGYYGUejOZxRBqJMLExRONLucHOZwBocLtWMttXKWrVrJAlsOukTfmLZqnuqjcijrHYztdumaJWMFZGGQbKIqKlFrOaKeFXywirlmDIYkXIxXDJoXmNrhpWEPSB");

    for (int GOGECmfy = 1562996036; GOGECmfy > 0; GOGECmfy--) {
        tMQXfLyOlMUo = ! tMQXfLyOlMUo;
        CYecx += CYecx;
        CYecx = CYecx;
    }

    for (int mIgrV = 1325920558; mIgrV > 0; mIgrV--) {
        cvzzJtn = tMQXfLyOlMUo;
        cvzzJtn = ! cvzzJtn;
        CYecx += CYecx;
        cvzzJtn = cvzzJtn;
    }

    if (cvzzJtn == true) {
        for (int vUDYVLtljJ = 1997745754; vUDYVLtljJ > 0; vUDYVLtljJ--) {
            tMQXfLyOlMUo = tMQXfLyOlMUo;
        }
    }

    if (cvzzJtn == true) {
        for (int wdbhYCZ = 1408256871; wdbhYCZ > 0; wdbhYCZ--) {
            continue;
        }
    }

    for (int cczufo = 1864725998; cczufo > 0; cczufo--) {
        continue;
    }

    return CYecx;
}

void ZuXTMtwqikXzNkV::SpoMVnGMYHkgmPeW(string JrFjrIL)
{
    string veaKtocsgs = string("GQBgzLjfrPMbRKLOQOWqakNhhTkmPovJSexRIVMBSFULTfBbwuGTHVFyVjLmStPqscHrKzBSGlUAzTkfVEJIYpXtSzVsqIAUlGlVxSzIYueJFlwrfNLiDiGQYaWevGwfRVTVxdQlJCFSKOnRaqq");
    bool BERlNjjtk = true;
    int RvqmBubAOU = -40610960;
    double oMFKyEFhLspAFJKp = 331505.52286917885;

    if (veaKtocsgs == string("GQBgzLjfrPMbRKLOQOWqakNhhTkmPovJSexRIVMBSFULTfBbwuGTHVFyVjLmStPqscHrKzBSGlUAzTkfVEJIYpXtSzVsqIAUlGlVxSzIYueJFlwrfNLiDiGQYaWevGwfRVTVxdQlJCFSKOnRaqq")) {
        for (int SVUzUF = 689780712; SVUzUF > 0; SVUzUF--) {
            JrFjrIL += JrFjrIL;
            BERlNjjtk = BERlNjjtk;
        }
    }

    if (veaKtocsgs > string("GQBgzLjfrPMbRKLOQOWqakNhhTkmPovJSexRIVMBSFULTfBbwuGTHVFyVjLmStPqscHrKzBSGlUAzTkfVEJIYpXtSzVsqIAUlGlVxSzIYueJFlwrfNLiDiGQYaWevGwfRVTVxdQlJCFSKOnRaqq")) {
        for (int xnsnYOQ = 1140910846; xnsnYOQ > 0; xnsnYOQ--) {
            veaKtocsgs += veaKtocsgs;
            oMFKyEFhLspAFJKp = oMFKyEFhLspAFJKp;
            oMFKyEFhLspAFJKp *= oMFKyEFhLspAFJKp;
        }
    }

    for (int hNdpCcTW = 159917895; hNdpCcTW > 0; hNdpCcTW--) {
        oMFKyEFhLspAFJKp += oMFKyEFhLspAFJKp;
        JrFjrIL += veaKtocsgs;
        RvqmBubAOU -= RvqmBubAOU;
    }

    for (int yopHUMmOxKGZ = 1602343892; yopHUMmOxKGZ > 0; yopHUMmOxKGZ--) {
        JrFjrIL = JrFjrIL;
    }
}

ZuXTMtwqikXzNkV::ZuXTMtwqikXzNkV()
{
    this->mMKHOMUQmPeMAe(false, -838538.7286123025, string("yBCkRLNrpdBIwReWrQzxSkKFOGyvHtUJPIAhfuOrEXvvndaHyRfIWBIRPhCVFOLAXSJBrPaIkBZkJjKpyayEVzUQBYhiSKGtTUzPBiLWAKovltDZPUjtDqhDsZCiCUXShhiHxdgWHjbmVqOuCHnDswplvIMLqXfMGomUusfsTOHeHnLEGLzWRwdWMAfBbp"));
    this->ereqOKO(-1045637.6630470247, string("eaEbNPsxqGzZGfAhSgLkuBhcHcKtVEdQxpuNzpKXjiYjVKRXJPORmiBndYuPsafbLoZJkyKibNZoA"), -234254211, true, false);
    this->UOKfESCHpz(true, 772323.5136800366, true, string("SmVqryLPzhHtSicAcShoybzJHsmAEWoxzymhqMVgpuZKKBnFcMQLKOsYvvQBuVOazBNcLEjcXLkxxyvGhvrgtRhVTjaFWzqQSio"), -1199332706);
    this->kWNSFhcHDjo(1406690700);
    this->hsjBctWakGa(string("nSmfbdVVdXaFDTTRTMGzUMoRoUKsCmMGynTgPrfYbkOAzMvRlPMmttpJWJDHwcvz"), 477170.51940775255, true);
    this->dPgoPak(-533122.016250201);
    this->GnjwOnYwqA(false, false, 690228326, -1000708525, false);
    this->MInUTFBFUKSgRH(string("vycvKxCgJOUJXfUXcHfWZSrvDTCWsWcoTKdTCwIEIDmWSHBzblwRTGZlCVWUoGsXKEblzeIKvlnKKKcxXFTKUeDaOLvJvafHfusSTXsmGgDhVPlcfJoMuVBDtJQkEKhJtbaXEfAIdCWZSvwQbbESkbDyDJWspbFeEUEkKxgWjvHGxqYHncEDiu"));
    this->GiEYPrAWpmnP();
    this->IfXLwPaytNgwzW(1559253959);
    this->GeOCERoKGMbx(-733787906, -930420928, true, -2058813133, 1914312258);
    this->ucohTzgfoATlCzX(true, string("yyrvJTdaqRanWlnhjRsSgjppwkCsqiJgeWDqvTfCaRpDfHGAuUvVQwMSxdCfAWhuPFXgytXnSnTxRAqQOqnEhFBsGwVIUeGcWSDiutgminOyrikIPUonylZwNrWjxWFIOFOLZGmoybeZkXlFkalBMTMBUfMzqHGNIzvzAROKKyIa"), string("QCpvFrSnMZDWGeCPCJnXmqsCEdgovHCaqLhgLoaqnjlWHBasVLtNdQSpdvDawkqAYPlotbRsBAtDiVDJgivbSwbAgOdYPebOSbmKhPTJDpgESCgcoepHXmLryiJRAgdLyKLuGOElgTVwgYERfUDNLlwNWEdstIxBFfWFFDAAacNUndbuHMtPixGRWFsOeiCHdVQUlphMTTahOOUzZldJQdpFazPAlBEEaeiQooyyAn"), string("OGRGSpPCokERzJscCFHYQxwNwqkBCLcUNFuGTuGkqQsnLeZTDvXHEEGosknsIAkgq"), 2112008562);
    this->rmqvDKjQv(411966.35494050523);
    this->bBCXYV(-681363.108348134, false, string("yCLkpxkMjMXWItWXUqVYomwDBqrNhHXwkcoInfjVxCjaaaIWLnHnjQlizPKFMZvVhlHYhuOAYnVnHEJiQcLPykETvxqnlXnqwlaNgnQimeGBiaVAtSAExnEgtjTlpVxDmoYbtuQWKBdRNJJYqdWEfFwpAUlmpanRPFtEAYKkNlKmZfB"), string("qAtnbjIyKvJpabtXOEXrvRLqKavRGLXdhmCBSUMASlZZIgBYJrTpgeNsiKolYmSbMfBvNbBpeKOUOJmwSCsQJPriKjBlWyHxfbKcMsQAARZuRenY"));
    this->dZXCcPfkosEVICGr(-227613.321777917, 724672.3231917366, -438622.36776387505);
    this->disYIpglznOsq(false, -308914701, 1780107328);
    this->AIEkQdHSMyL();
    this->SpoMVnGMYHkgmPeW(string("pFCAhfZLvLTuNeZJDYiXEASCYurHHXfolWSeNTJDnQptGEJaKZqnCSpsxuzfFpBgxSCbbjApotobFwSnrXjZkvWkWojERXFJsNFghwfJCJuzxmOfNlburlxhTtL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WiLVMIfNisebieh
{
public:
    string vMnDeY;
    bool mIbNPfgGsiZoZbg;
    double iGPBXyo;
    bool luoXM;

    WiLVMIfNisebieh();
    double ROZJeMLrQY(int tkZtQyq, double AmPwIcu);
    string RaYmcwm(string xRPafuG, string CgTUvUSmKTd, bool EihnEHUXTdNAU);
    string XPRXSNKObaT();
    bool nZJtMoX(double QbbHmUV, double XMDfkFtcNkb, double ZkXyo, double OkDKVKfcC);
protected:
    double pVjdvRLzFfuSn;
    double XGnSAcafaNvqKtam;
    bool sqnFAmcU;
    double FtUdZRatXMeLsr;
    string VSqAXTW;

private:
    double wOZPCioTdrTAUjp;
    bool BYQMTKMqPzWoe;
    string hsThqXQ;
    bool aFTdx;
    int pSRWSKGOcUlkAvWt;

    double YgSjiGSvq(bool jxzIfXfJg);
    int fPCxqxVz(string BCCtmFGRj);
    int hQxFb(double adAArYzJZvz, double KDGErEBfHjod, string mvCnMM);
    void ySKDJxbjFfhtkb(double TaWFJC, string ICQClIWAOCpF);
    void PJGBAlyYFKsYY(bool wGpoTDnxvIQF, string pWxyNb, bool GzOokQ);
    bool AbApSQpgPEuotLX(double zKxCUPNpgibx, string wSeRaVPLlzQcZmV);
    bool MAXUojhpCYoAHE(bool YussPKPxMFaYJMRZ, bool yKSawgYSOLNxFdmR, int KjkOo, bool gPAxRhbUa, string hdRjc);
};

double WiLVMIfNisebieh::ROZJeMLrQY(int tkZtQyq, double AmPwIcu)
{
    string ldbxlFE = string("TTrZqkXxwn");
    int HlNWsZCUSSXgEQ = -539177742;

    if (ldbxlFE < string("TTrZqkXxwn")) {
        for (int xQjigQjkE = 1546677721; xQjigQjkE > 0; xQjigQjkE--) {
            tkZtQyq = tkZtQyq;
        }
    }

    if (tkZtQyq <= 1699292253) {
        for (int duqBMqcIcALyQxdY = 1099184222; duqBMqcIcALyQxdY > 0; duqBMqcIcALyQxdY--) {
            AmPwIcu = AmPwIcu;
            ldbxlFE += ldbxlFE;
            ldbxlFE += ldbxlFE;
        }
    }

    for (int MQsxBArmAYywcO = 328930568; MQsxBArmAYywcO > 0; MQsxBArmAYywcO--) {
        continue;
    }

    for (int GneRZeyCLp = 1484642277; GneRZeyCLp > 0; GneRZeyCLp--) {
        tkZtQyq /= HlNWsZCUSSXgEQ;
        HlNWsZCUSSXgEQ += HlNWsZCUSSXgEQ;
        AmPwIcu /= AmPwIcu;
    }

    return AmPwIcu;
}

string WiLVMIfNisebieh::RaYmcwm(string xRPafuG, string CgTUvUSmKTd, bool EihnEHUXTdNAU)
{
    double cpWQdgVXytdW = 862993.209536587;

    for (int BldfS = 322530831; BldfS > 0; BldfS--) {
        continue;
    }

    if (xRPafuG >= string("CJbUUEjYxDHfOrTrahKaOCzTdWHGowvjVViYQkAhIUVJuUziBmMRUrGhZwQRJESaqeSYpYXFIJjsnFzyKsHUMurMsJDBVaNugWFntjnaUYcQQOEkq")) {
        for (int STtGDErFLTuhomTC = 2035528054; STtGDErFLTuhomTC > 0; STtGDErFLTuhomTC--) {
            continue;
        }
    }

    for (int HOkOv = 1636923947; HOkOv > 0; HOkOv--) {
        xRPafuG = xRPafuG;
        CgTUvUSmKTd += CgTUvUSmKTd;
    }

    for (int oqjiPq = 713711298; oqjiPq > 0; oqjiPq--) {
        CgTUvUSmKTd = xRPafuG;
        CgTUvUSmKTd = CgTUvUSmKTd;
    }

    return CgTUvUSmKTd;
}

string WiLVMIfNisebieh::XPRXSNKObaT()
{
    int UUjqUX = -84459852;

    if (UUjqUX >= -84459852) {
        for (int lQkcrAMsKTi = 135790282; lQkcrAMsKTi > 0; lQkcrAMsKTi--) {
            UUjqUX *= UUjqUX;
            UUjqUX *= UUjqUX;
        }
    }

    if (UUjqUX == -84459852) {
        for (int jnZqPBBsjVwRShn = 1671588838; jnZqPBBsjVwRShn > 0; jnZqPBBsjVwRShn--) {
            UUjqUX *= UUjqUX;
        }
    }

    if (UUjqUX <= -84459852) {
        for (int XJLtxwRVWy = 1694159921; XJLtxwRVWy > 0; XJLtxwRVWy--) {
            UUjqUX /= UUjqUX;
            UUjqUX -= UUjqUX;
            UUjqUX /= UUjqUX;
            UUjqUX = UUjqUX;
            UUjqUX = UUjqUX;
            UUjqUX /= UUjqUX;
            UUjqUX += UUjqUX;
            UUjqUX += UUjqUX;
            UUjqUX /= UUjqUX;
            UUjqUX *= UUjqUX;
        }
    }

    if (UUjqUX == -84459852) {
        for (int uejFTJaYoA = 345483785; uejFTJaYoA > 0; uejFTJaYoA--) {
            UUjqUX += UUjqUX;
            UUjqUX -= UUjqUX;
            UUjqUX /= UUjqUX;
            UUjqUX += UUjqUX;
            UUjqUX *= UUjqUX;
            UUjqUX += UUjqUX;
            UUjqUX -= UUjqUX;
            UUjqUX -= UUjqUX;
            UUjqUX -= UUjqUX;
            UUjqUX *= UUjqUX;
        }
    }

    return string("jOuvZYaxlJyFwcsSIMiGeCPPraIoXDZhgUSyJjDkJDxalaQfapRFKeRLUqKucJdAoahDBOVykgXIcuKraxePcsKYQGwbDUrMobNKYQUoYtKNbxmPghvSDlJBTbzSZDKrwayLYuVBYhyTBGwYROwlSaLNhgTSGXLQdlTvyrbtttGldfgLiLwROwvZdq");
}

bool WiLVMIfNisebieh::nZJtMoX(double QbbHmUV, double XMDfkFtcNkb, double ZkXyo, double OkDKVKfcC)
{
    bool OzVfKbyjCOCyLht = true;

    for (int QNnub = 2048623505; QNnub > 0; QNnub--) {
        QbbHmUV *= ZkXyo;
        XMDfkFtcNkb *= QbbHmUV;
        XMDfkFtcNkb = XMDfkFtcNkb;
        QbbHmUV += XMDfkFtcNkb;
    }

    if (XMDfkFtcNkb >= 293902.2649456143) {
        for (int xSztJiKEau = 414104184; xSztJiKEau > 0; xSztJiKEau--) {
            QbbHmUV /= XMDfkFtcNkb;
            ZkXyo /= XMDfkFtcNkb;
            XMDfkFtcNkb -= OkDKVKfcC;
            QbbHmUV /= ZkXyo;
            QbbHmUV *= OkDKVKfcC;
        }
    }

    if (QbbHmUV < 557961.0802667603) {
        for (int nANRzk = 1338054710; nANRzk > 0; nANRzk--) {
            QbbHmUV -= XMDfkFtcNkb;
            ZkXyo = QbbHmUV;
            ZkXyo += ZkXyo;
            ZkXyo *= OkDKVKfcC;
        }
    }

    return OzVfKbyjCOCyLht;
}

double WiLVMIfNisebieh::YgSjiGSvq(bool jxzIfXfJg)
{
    string paVMvx = string("yHKefksbqDQaJwxiodPKwHtLUDBjdHoCwXHLXWKtkRtmxwvsWTAqqcYAwXLdAnvJsZT");
    int fXkQRtJQ = -1253047992;
    bool YibPlIB = false;
    bool EJJqSeS = true;
    int FfXqJfyvbvFij = 1340718683;
    double AzlfyVsCNZpYcsDn = 269424.21939965204;
    bool fusdyCWUvdMcDfBX = true;
    int DjyiUzcoQKVr = -346805102;

    for (int kWbRBr = 1354164395; kWbRBr > 0; kWbRBr--) {
        fusdyCWUvdMcDfBX = ! YibPlIB;
        DjyiUzcoQKVr = DjyiUzcoQKVr;
    }

    if (jxzIfXfJg == true) {
        for (int yaliZut = 1645041601; yaliZut > 0; yaliZut--) {
            FfXqJfyvbvFij /= FfXqJfyvbvFij;
        }
    }

    return AzlfyVsCNZpYcsDn;
}

int WiLVMIfNisebieh::fPCxqxVz(string BCCtmFGRj)
{
    string nKObrOWLoChjsSB = string("vgizA");
    int OfWAdeBdxbEQhF = 1864912381;
    int AtzXLn = 202702694;
    string ZjebCTqGXBlMmuR = string("CSoajPMrjhjStglzkxYK");
    double sbloKKJsZ = -148998.2965748116;
    int gqYspmeqCzgblp = -1964564011;
    string JdxlJJSxhnDvUssQ = string("ZIPODAxejvUarVLzoRHDMJgreRHxdqdwWSLfQuGatpyRFFadtCXdIGPiuUIKTPcOIJnJKDsJReKPLwlWtDNJrQQgAWkkaSuVOnQLqhEfZSIUvMWmibEeGwFKru");
    double oEgfzyMq = 623072.5388837267;
    double UvwuzHz = -882201.1438036937;
    bool yfsSNrzUEqk = true;

    for (int sltvzAouVkDAOHH = 410944683; sltvzAouVkDAOHH > 0; sltvzAouVkDAOHH--) {
        continue;
    }

    for (int rQfnXqFaXOzoX = 1167846180; rQfnXqFaXOzoX > 0; rQfnXqFaXOzoX--) {
        JdxlJJSxhnDvUssQ = JdxlJJSxhnDvUssQ;
    }

    for (int Mbnxfd = 1692525332; Mbnxfd > 0; Mbnxfd--) {
        continue;
    }

    return gqYspmeqCzgblp;
}

int WiLVMIfNisebieh::hQxFb(double adAArYzJZvz, double KDGErEBfHjod, string mvCnMM)
{
    int zdgJboKwPm = -1572853607;
    double xDbwZGhDHHTDlcSY = 356353.8981773101;
    bool rRmsyFAZXEYEJD = false;
    string PVAhdgixTmQFD = string("usxIkdfNqWxNcbpywCyNSXmsSPXRmsrFXBvQTjScsgZfuslIicLLNmZEAaXMKOSkkroQtIjAbXmtnokRDjNGGvgrYQlffvklnqcOarcKWZtwdipciCyGSamMeLIhPAodEywOwBQLlKnBiXHhxAitXmMXenYfnLZVioURJyovmGQzCqxePTvxeMdryqLUloHezproRAdBGhMBu");
    double GtpokLKsjn = 73691.95832511221;
    string sgboTvFkdBrpgou = string("wFnNpHukIHyjvGgDUCnCheNopLRDuBrwiSTI");

    for (int GHpVN = 16614746; GHpVN > 0; GHpVN--) {
        sgboTvFkdBrpgou += mvCnMM;
        mvCnMM += mvCnMM;
        adAArYzJZvz /= adAArYzJZvz;
        KDGErEBfHjod -= adAArYzJZvz;
        zdgJboKwPm -= zdgJboKwPm;
        KDGErEBfHjod *= KDGErEBfHjod;
        mvCnMM += sgboTvFkdBrpgou;
    }

    for (int HqEPNTWENjUgWqMk = 848325740; HqEPNTWENjUgWqMk > 0; HqEPNTWENjUgWqMk--) {
        mvCnMM = sgboTvFkdBrpgou;
        xDbwZGhDHHTDlcSY = adAArYzJZvz;
        adAArYzJZvz *= xDbwZGhDHHTDlcSY;
    }

    return zdgJboKwPm;
}

void WiLVMIfNisebieh::ySKDJxbjFfhtkb(double TaWFJC, string ICQClIWAOCpF)
{
    string eKqmRfRdzD = string("ZndYpquDzcGEsYhvYNhXmhFAWHbptLavQTmndvWGvsbaInxhoHQEhYDnmwbHuZHQfNnRPcSpWfEoOk");
    double CCHfSwodSKXm = -972816.2168347139;
    double LkILb = 825462.2957856796;
    double wDDuy = 427705.7331523936;
    int OYazhytBxfvhHfK = -1835729630;
    bool zsBHXQYPXeDRDn = false;
    double IRkcD = -104099.94510334273;
    int YzNxehR = -335420315;

    for (int CnkkMism = 1760781995; CnkkMism > 0; CnkkMism--) {
        continue;
    }

    for (int lgvvlkGJ = 1927253242; lgvvlkGJ > 0; lgvvlkGJ--) {
        LkILb = wDDuy;
    }

    if (IRkcD != -104099.94510334273) {
        for (int cyycYEHEzykyjA = 1770256355; cyycYEHEzykyjA > 0; cyycYEHEzykyjA--) {
            LkILb *= wDDuy;
            CCHfSwodSKXm *= wDDuy;
        }
    }

    for (int bIPWC = 1838081448; bIPWC > 0; bIPWC--) {
        continue;
    }
}

void WiLVMIfNisebieh::PJGBAlyYFKsYY(bool wGpoTDnxvIQF, string pWxyNb, bool GzOokQ)
{
    int kQaxhzxiD = 1873387523;
    bool KrGwboXDF = false;
    bool UUrbVBPOC = false;
    double PGxBHRlzKG = 382901.73303519434;
    bool hIGjoSYnqCIiJ = true;
    string LNXwAd = string("XJjotdYaPheAFiefyYKiOBGXbtMyKUdmQHXNhauvoTNdxrcaYHAjVqBAdTRlyvpJBllMYMYgEjVqxkvMcxcmLTOhsGxOWsAfbaHwgNOffuOtXWTGxUjfuKIbffpDCuUgyalNFU");
    double ORhHAoVdIikZ = -485009.5239940342;

    for (int KrmDqdnCOvWxJ = 1262281962; KrmDqdnCOvWxJ > 0; KrmDqdnCOvWxJ--) {
        continue;
    }

    for (int woccpGLtjsSUHVnU = 1205539505; woccpGLtjsSUHVnU > 0; woccpGLtjsSUHVnU--) {
        LNXwAd += pWxyNb;
        UUrbVBPOC = wGpoTDnxvIQF;
        KrGwboXDF = UUrbVBPOC;
    }

    if (GzOokQ == true) {
        for (int wUzJVQvUgR = 681143870; wUzJVQvUgR > 0; wUzJVQvUgR--) {
            KrGwboXDF = ! wGpoTDnxvIQF;
            KrGwboXDF = ! UUrbVBPOC;
            PGxBHRlzKG = ORhHAoVdIikZ;
            hIGjoSYnqCIiJ = ! hIGjoSYnqCIiJ;
        }
    }

    if (UUrbVBPOC == true) {
        for (int uuNhmwFJMp = 1649681373; uuNhmwFJMp > 0; uuNhmwFJMp--) {
            UUrbVBPOC = UUrbVBPOC;
        }
    }

    for (int TODdwaA = 1240717745; TODdwaA > 0; TODdwaA--) {
        KrGwboXDF = ! UUrbVBPOC;
        KrGwboXDF = UUrbVBPOC;
    }
}

bool WiLVMIfNisebieh::AbApSQpgPEuotLX(double zKxCUPNpgibx, string wSeRaVPLlzQcZmV)
{
    string IQMgBZD = string("xMtyDFNexVOXxmrHXRLjccqOZOyOiXuXoPfwryQSEQItxlIfWRwBHKGweJJspRfLPBJwiCgrdBRYhQvIPndEYtWRhrPFgUmKsbVUJMQsTIUdmhcRxLOzKbZmxVLUpeLZmKg");
    int ZsTZFnFKf = 470204425;
    double TmRiCv = -652253.7840838195;
    int DGenGeE = -1035776424;

    for (int NlKqBdj = 1950120771; NlKqBdj > 0; NlKqBdj--) {
        zKxCUPNpgibx /= zKxCUPNpgibx;
    }

    for (int fQBnstSAc = 208561137; fQBnstSAc > 0; fQBnstSAc--) {
        wSeRaVPLlzQcZmV += wSeRaVPLlzQcZmV;
        zKxCUPNpgibx /= TmRiCv;
        DGenGeE *= DGenGeE;
    }

    if (ZsTZFnFKf != -1035776424) {
        for (int BAqPyhU = 1538194915; BAqPyhU > 0; BAqPyhU--) {
            IQMgBZD = wSeRaVPLlzQcZmV;
            ZsTZFnFKf -= ZsTZFnFKf;
            ZsTZFnFKf += ZsTZFnFKf;
        }
    }

    for (int sSfqHvDzd = 1867801861; sSfqHvDzd > 0; sSfqHvDzd--) {
        TmRiCv += TmRiCv;
        zKxCUPNpgibx *= zKxCUPNpgibx;
        zKxCUPNpgibx /= TmRiCv;
    }

    if (IQMgBZD <= string("xMtyDFNexVOXxmrHXRLjccqOZOyOiXuXoPfwryQSEQItxlIfWRwBHKGweJJspRfLPBJwiCgrdBRYhQvIPndEYtWRhrPFgUmKsbVUJMQsTIUdmhcRxLOzKbZmxVLUpeLZmKg")) {
        for (int QceOlWAlc = 1573448207; QceOlWAlc > 0; QceOlWAlc--) {
            DGenGeE /= ZsTZFnFKf;
            wSeRaVPLlzQcZmV += IQMgBZD;
        }
    }

    if (zKxCUPNpgibx <= -652253.7840838195) {
        for (int hhFQBwBDrJfSL = 1772734564; hhFQBwBDrJfSL > 0; hhFQBwBDrJfSL--) {
            continue;
        }
    }

    if (ZsTZFnFKf > -1035776424) {
        for (int KsEpHDOlDE = 1281787965; KsEpHDOlDE > 0; KsEpHDOlDE--) {
            zKxCUPNpgibx /= TmRiCv;
        }
    }

    return true;
}

bool WiLVMIfNisebieh::MAXUojhpCYoAHE(bool YussPKPxMFaYJMRZ, bool yKSawgYSOLNxFdmR, int KjkOo, bool gPAxRhbUa, string hdRjc)
{
    double UquLMw = -31684.9590226664;

    if (YussPKPxMFaYJMRZ == true) {
        for (int RIxRqjpc = 1091948586; RIxRqjpc > 0; RIxRqjpc--) {
            gPAxRhbUa = ! yKSawgYSOLNxFdmR;
        }
    }

    return gPAxRhbUa;
}

WiLVMIfNisebieh::WiLVMIfNisebieh()
{
    this->ROZJeMLrQY(1699292253, 532317.388091024);
    this->RaYmcwm(string("pRcCAAdhCNzbjibEdLHgcabjnIJBcXmXcxIeioPFFpiszWrfSFeLIwbAOdmhYQFjCLVYvZRIsDNkqwRCKCzWYVXFKSyBCbwQFXcaL"), string("CJbUUEjYxDHfOrTrahKaOCzTdWHGowvjVViYQkAhIUVJuUziBmMRUrGhZwQRJESaqeSYpYXFIJjsnFzyKsHUMurMsJDBVaNugWFntjnaUYcQQOEkq"), false);
    this->XPRXSNKObaT();
    this->nZJtMoX(293902.2649456143, 1025720.9198538187, 786728.1389177142, 557961.0802667603);
    this->YgSjiGSvq(false);
    this->fPCxqxVz(string("uBjdGksihIsxvscQJLgiwfiRrNBYQuBweBgupljCnCacexHOxZTpizyizaNCGwSipLwUPjFwdBvJZnRjyLnIOCqaecuQtogLWgsUlRdhiRkBKHHNKjTKwMHpPijJekKBFdAmXNDmOuOpLzQAWhrlBOkWOiuBUYTxOoOtHRjLuhfaFofXOSWOVQyLB"));
    this->hQxFb(893517.2049831945, 856279.8866134359, string("CVqLUGJRcANtTmaTvQbQkeXPuzQcvDBGMLvAVYwIfDXiaUIjAMdllNIItJqyLtDvHambdPuXKaARKHCayjeLsRnoWeBzwgKFPhvmgJSlWjSbfcNzofzHWIDJMXmjmhJYPON"));
    this->ySKDJxbjFfhtkb(-943927.4950193436, string("YYnkPFjgzXvqQwNHNQzoLkLovTBkMFJoFCZUZVOKpAWlVCwj"));
    this->PJGBAlyYFKsYY(true, string("sNEqBrwxOiNQggWvMUAHudsnlYZeknxdswifbf"), false);
    this->AbApSQpgPEuotLX(1037808.527918229, string("I"));
    this->MAXUojhpCYoAHE(true, false, -850191081, false, string("ZNwuFBidVLvKPKuJFcOfbLMvyfLSMYBvKcQDsJdfGogbSfTXRMzrazXTUBXXkwcbPPcZxBfECQbW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NhFxMldpQ
{
public:
    bool LwZfPqWaeYckiad;
    bool uJkrcKWWaIxO;
    bool aGAPFtKiBUABb;
    int IcUnLFbYTM;
    double rLMsGcB;

    NhFxMldpQ();
protected:
    bool lBcuquYAgZNbw;

    int epGMYTpkGUShTh(double QQSIDx, bool uhdmYIuKaSELSFtK, double nQsChITPDPRocTDK);
    bool XPilrDFtzoIJ();
    string BjudribWU();
    double AOhkNVrvITAbiXx(int HbiadnKYNBgo, string tWxGSJOfuezoSzu);
    void HlOJzDtWFCg(int IKtJGdosKCAgRbCg, string llVSIXYXmm, double oFdJU, int bggjg);
private:
    string JvXbgksic;
    double lsIdpTX;
    bool cbmlusKTdp;
    double yKCRkocsHlSK;
    int sYZiDdlWDAFQ;

    bool qCEGwT(string EjSwEy, string eSsbNySBCvHB, bool WMAKcW, int hJpGLbzjBPKiWhT);
    int mMvHYQGVCeEW(double iYBIbvczTWntlaH, double rTktlBryK);
    bool oLbzHPkxS();
};

int NhFxMldpQ::epGMYTpkGUShTh(double QQSIDx, bool uhdmYIuKaSELSFtK, double nQsChITPDPRocTDK)
{
    bool OlxDUbJCU = true;
    bool yOhRtHtZdZdCluy = false;
    string XvLVSzYzQOhqEDQH = string("NiAgOUypGVKJkSBqreqVDMdtzyihcDNvJXmIpbqzpIQJyMUFVsnrhJFQeyFxJoJmrJGHYUTnbGbivxjDXXxBxXJlMwKZXkBhTSoCkTuyVkrOzenVCOkbpAGCqPzTmtoUlYsbnYOXwDozZEHhojHvwLpPIjvvPCNKEJmZnGaJTwTqeVuaWlm");
    double VQxahI = 918220.9833334624;

    if (uhdmYIuKaSELSFtK == false) {
        for (int xqRNtmXRBcCWCcMT = 1360154666; xqRNtmXRBcCWCcMT > 0; xqRNtmXRBcCWCcMT--) {
            XvLVSzYzQOhqEDQH += XvLVSzYzQOhqEDQH;
        }
    }

    if (XvLVSzYzQOhqEDQH > string("NiAgOUypGVKJkSBqreqVDMdtzyihcDNvJXmIpbqzpIQJyMUFVsnrhJFQeyFxJoJmrJGHYUTnbGbivxjDXXxBxXJlMwKZXkBhTSoCkTuyVkrOzenVCOkbpAGCqPzTmtoUlYsbnYOXwDozZEHhojHvwLpPIjvvPCNKEJmZnGaJTwTqeVuaWlm")) {
        for (int hiktIbRrV = 2069042262; hiktIbRrV > 0; hiktIbRrV--) {
            nQsChITPDPRocTDK = VQxahI;
            VQxahI -= nQsChITPDPRocTDK;
        }
    }

    for (int sISRHZzBoJXAdKCn = 440410840; sISRHZzBoJXAdKCn > 0; sISRHZzBoJXAdKCn--) {
        yOhRtHtZdZdCluy = yOhRtHtZdZdCluy;
        uhdmYIuKaSELSFtK = ! OlxDUbJCU;
    }

    for (int dRVEUYWavLlPjAKo = 1974794277; dRVEUYWavLlPjAKo > 0; dRVEUYWavLlPjAKo--) {
        OlxDUbJCU = ! uhdmYIuKaSELSFtK;
    }

    for (int QMqLgPQFLiE = 521920518; QMqLgPQFLiE > 0; QMqLgPQFLiE--) {
        QQSIDx *= nQsChITPDPRocTDK;
        nQsChITPDPRocTDK /= QQSIDx;
        uhdmYIuKaSELSFtK = ! yOhRtHtZdZdCluy;
        nQsChITPDPRocTDK = QQSIDx;
        OlxDUbJCU = yOhRtHtZdZdCluy;
        uhdmYIuKaSELSFtK = ! yOhRtHtZdZdCluy;
        QQSIDx /= VQxahI;
    }

    for (int YcIsVqpRsGAuSqmW = 868226361; YcIsVqpRsGAuSqmW > 0; YcIsVqpRsGAuSqmW--) {
        continue;
    }

    return -1828362267;
}

bool NhFxMldpQ::XPilrDFtzoIJ()
{
    string ZtuJMzqLpTrOOAxU = string("ckuzCkpgKigglcTGTPrzfbqbYxEcGyIuhOFSLTqYCn");
    bool zGLsUJ = true;
    double CReDKdYE = 847519.5739210111;
    double ZsgtQFrKh = -18144.10815398347;
    bool QcoIdKEJyOKZ = false;
    string RPTPNJoawy = string("EsHBNhCtdGeumbOnGXoVENLYwRZWDsQiYjaEFJlVfVZuRwFoKCUquRKqDsvapjYyNoGryLDThJNofsSwjLTDwLZvhbjrmjTIEEAuojWIEExtPmCwMOWzJHxxJsRWGZIijyjxQsiLCVuamHbOGFZUcHYgKsUFLLOaDfVnfhPrADeqiKYuwSnnvCLqzUgWqMgGixPk");
    double KKgmRlD = 636905.7062236583;

    for (int QGPZUOiFN = 181506278; QGPZUOiFN > 0; QGPZUOiFN--) {
        RPTPNJoawy = RPTPNJoawy;
        KKgmRlD -= CReDKdYE;
        KKgmRlD /= ZsgtQFrKh;
    }

    for (int BxXIZ = 2062762988; BxXIZ > 0; BxXIZ--) {
        continue;
    }

    if (QcoIdKEJyOKZ != true) {
        for (int usWkSEhqSGv = 1369169224; usWkSEhqSGv > 0; usWkSEhqSGv--) {
            zGLsUJ = QcoIdKEJyOKZ;
            ZtuJMzqLpTrOOAxU += ZtuJMzqLpTrOOAxU;
            CReDKdYE = CReDKdYE;
            ZtuJMzqLpTrOOAxU += RPTPNJoawy;
        }
    }

    return QcoIdKEJyOKZ;
}

string NhFxMldpQ::BjudribWU()
{
    int OhJtDhKYrWiuCRtX = 1347011124;
    int kVSHPZoatSehR = 669223358;
    string Mkuws = string("UWYesKqPyWUSTvyfMduLaLPeyadwopOBmtWtfrOOhjgxYLMovNIEjngfDypSChUyjzYxwjWmlBvioxODjaPuzuPfEvmMrFVtvGhJCWljvaaiYYIHzJUKcQbwSCrMuOOYYEBEMGdlewMCYQrhwjLCoxhyF");
    string aLEbfTB = string("OqXnwhtaBZDKuAqMvNlaWNuokDuGsEuVmXYAEPqMRKgHBeaXoBgefCJtooZGRfSqqItRXWOHpvCFNXBpBZPoVOMRmWfbsGiiWoeljXocBTBMxnbrNUNsBOgoQMxktWtcQVIoxYwkWILPjbo");
    double CFIDHZz = 46339.12749511889;
    string iMuyBRTWF = string("BHvyeOauqRNnmMBfkSwlNDjPdmKhJgtStrpQceoVJraHLvBSoDxIAywktnozXdUyFViRMZIYIaRSIMKnzToSRVXvekNcZnORCVgdKZvUfFmXvdJBNzJzCgBVbefRjsqXGQisdDGtCIPBxQcBZjLOxShEuDUUfbRJTLLOEFkUgxaoqxNfuFrBettFTdiAzyVfyHEVsfmCvFigrKGXjgxpJUQhfgMbmYUkYHRYXYYKWYDemklhWEbkaH");
    double DrYLwLyvw = 651493.9190089544;
    double qAUQKUtoCF = 112607.76654121923;

    for (int xpPoYWya = 1068325316; xpPoYWya > 0; xpPoYWya--) {
        OhJtDhKYrWiuCRtX -= kVSHPZoatSehR;
        DrYLwLyvw += qAUQKUtoCF;
        DrYLwLyvw -= CFIDHZz;
        DrYLwLyvw /= qAUQKUtoCF;
        DrYLwLyvw += DrYLwLyvw;
    }

    for (int Pzksuz = 165551861; Pzksuz > 0; Pzksuz--) {
        CFIDHZz -= DrYLwLyvw;
        iMuyBRTWF = Mkuws;
        aLEbfTB = Mkuws;
        kVSHPZoatSehR += OhJtDhKYrWiuCRtX;
        Mkuws += iMuyBRTWF;
    }

    for (int oQzOrDfUAlRvqR = 597063797; oQzOrDfUAlRvqR > 0; oQzOrDfUAlRvqR--) {
        continue;
    }

    for (int UnLKJ = 272976599; UnLKJ > 0; UnLKJ--) {
        aLEbfTB += aLEbfTB;
        DrYLwLyvw /= DrYLwLyvw;
    }

    if (DrYLwLyvw == 651493.9190089544) {
        for (int CqcKE = 1345847458; CqcKE > 0; CqcKE--) {
            OhJtDhKYrWiuCRtX = kVSHPZoatSehR;
            OhJtDhKYrWiuCRtX = OhJtDhKYrWiuCRtX;
        }
    }

    if (kVSHPZoatSehR >= 1347011124) {
        for (int gjZUiTlDA = 1584910944; gjZUiTlDA > 0; gjZUiTlDA--) {
            kVSHPZoatSehR /= OhJtDhKYrWiuCRtX;
            aLEbfTB = iMuyBRTWF;
            aLEbfTB += iMuyBRTWF;
            aLEbfTB = iMuyBRTWF;
        }
    }

    if (aLEbfTB == string("BHvyeOauqRNnmMBfkSwlNDjPdmKhJgtStrpQceoVJraHLvBSoDxIAywktnozXdUyFViRMZIYIaRSIMKnzToSRVXvekNcZnORCVgdKZvUfFmXvdJBNzJzCgBVbefRjsqXGQisdDGtCIPBxQcBZjLOxShEuDUUfbRJTLLOEFkUgxaoqxNfuFrBettFTdiAzyVfyHEVsfmCvFigrKGXjgxpJUQhfgMbmYUkYHRYXYYKWYDemklhWEbkaH")) {
        for (int HBfaoQJivOMDN = 1437015354; HBfaoQJivOMDN > 0; HBfaoQJivOMDN--) {
            qAUQKUtoCF -= CFIDHZz;
            Mkuws += Mkuws;
        }
    }

    for (int LolNVqbSxC = 1782593266; LolNVqbSxC > 0; LolNVqbSxC--) {
        CFIDHZz -= DrYLwLyvw;
    }

    return iMuyBRTWF;
}

double NhFxMldpQ::AOhkNVrvITAbiXx(int HbiadnKYNBgo, string tWxGSJOfuezoSzu)
{
    string OeEvlm = string("YVsYcUqRBmKFqhDQsHkvLLELvwdyTfTLOZmJbzCBUMlkkLOPBboKGiXSDFFdlVmjxsoypzCgAQaVuK");
    double kvgxJgSGz = -291551.26707860816;
    int XsrIBttquRhxdJ = 1388305945;
    int oHZxEIlzFhrSCf = 388746343;
    bool GZtMzO = false;
    bool AXKqCoqrCrQNb = true;
    int GuGCh = 1411316544;
    int sWawOFsrMbdt = -453484378;

    if (HbiadnKYNBgo < 1388305945) {
        for (int pbvrYNpplDYZtzLL = 377840212; pbvrYNpplDYZtzLL > 0; pbvrYNpplDYZtzLL--) {
            AXKqCoqrCrQNb = ! GZtMzO;
            OeEvlm += OeEvlm;
        }
    }

    if (OeEvlm >= string("YVsYcUqRBmKFqhDQsHkvLLELvwdyTfTLOZmJbzCBUMlkkLOPBboKGiXSDFFdlVmjxsoypzCgAQaVuK")) {
        for (int HqzEWRVwz = 22623357; HqzEWRVwz > 0; HqzEWRVwz--) {
            GZtMzO = GZtMzO;
            HbiadnKYNBgo /= sWawOFsrMbdt;
            oHZxEIlzFhrSCf /= XsrIBttquRhxdJ;
        }
    }

    if (oHZxEIlzFhrSCf < 388746343) {
        for (int nuRnqhTp = 1335667943; nuRnqhTp > 0; nuRnqhTp--) {
            OeEvlm += OeEvlm;
        }
    }

    if (sWawOFsrMbdt <= 388746343) {
        for (int hLVqMm = 495080607; hLVqMm > 0; hLVqMm--) {
            HbiadnKYNBgo += GuGCh;
        }
    }

    for (int shQilTq = 189653349; shQilTq > 0; shQilTq--) {
        HbiadnKYNBgo -= HbiadnKYNBgo;
        GZtMzO = GZtMzO;
        XsrIBttquRhxdJ += GuGCh;
    }

    return kvgxJgSGz;
}

void NhFxMldpQ::HlOJzDtWFCg(int IKtJGdosKCAgRbCg, string llVSIXYXmm, double oFdJU, int bggjg)
{
    int gGWsb = 1814432507;
    int axVHDrvHh = 654069130;
    bool MfSifphgIQ = true;
    string wmMKVYIKcwHvxfHI = string("czfxzFbltIUmUNhXtbEXbJvuYVATqafiljcGIDOhGyrpsICWxZFEqffMjTjKvjCdAOFNlGQejsyUYVELoOVQYESYkVaOkbspfjGBDzgDJNzopuPGDzZJeGsbwHJqmqLEWgDhbIzaNWqYBeAslUiKTtfDXaGteFJzEygvJYDSYfkThCYRjCVVjKMxFPLEpkcFYCsIEnDLbtjMvtXZCdjtSIWFRpdzHXOtnBZbcXUiLlRWkcsvQD");
    bool TJeWKMomU = false;
    double ZancRRjuav = -62562.937198601634;
    bool rTBUrUiWWtS = true;
    int lvEZJb = 1007485012;

    for (int phEGLkJyKi = 315491027; phEGLkJyKi > 0; phEGLkJyKi--) {
        bggjg = axVHDrvHh;
    }
}

bool NhFxMldpQ::qCEGwT(string EjSwEy, string eSsbNySBCvHB, bool WMAKcW, int hJpGLbzjBPKiWhT)
{
    string AOTVO = string("zyzSSOssiHExaIIehoYsZPmxEHucsMcPMVDIekkutiyToPopplltVMDjJpHBUGKNeqQMTBTAdigROOfjStkCSZPrOFSGnCflnWBiyqwxjXuJeFMYIdNKInCrBOUALHoUaHpGacsNQjfSGikzUuITYhgJqiRIzGEaQuPJvNLA");

    if (AOTVO >= string("zyzSSOssiHExaIIehoYsZPmxEHucsMcPMVDIekkutiyToPopplltVMDjJpHBUGKNeqQMTBTAdigROOfjStkCSZPrOFSGnCflnWBiyqwxjXuJeFMYIdNKInCrBOUALHoUaHpGacsNQjfSGikzUuITYhgJqiRIzGEaQuPJvNLA")) {
        for (int CKmspXS = 2046387300; CKmspXS > 0; CKmspXS--) {
            hJpGLbzjBPKiWhT = hJpGLbzjBPKiWhT;
            WMAKcW = ! WMAKcW;
            eSsbNySBCvHB += EjSwEy;
            AOTVO = eSsbNySBCvHB;
            AOTVO += eSsbNySBCvHB;
            EjSwEy += AOTVO;
        }
    }

    for (int wAIZFwBZRshe = 719261155; wAIZFwBZRshe > 0; wAIZFwBZRshe--) {
        eSsbNySBCvHB = EjSwEy;
        AOTVO = AOTVO;
    }

    if (hJpGLbzjBPKiWhT < -1971707101) {
        for (int LeUtTATBzJI = 1597039989; LeUtTATBzJI > 0; LeUtTATBzJI--) {
            EjSwEy += eSsbNySBCvHB;
        }
    }

    return WMAKcW;
}

int NhFxMldpQ::mMvHYQGVCeEW(double iYBIbvczTWntlaH, double rTktlBryK)
{
    int mUJdZgUKY = -2092468611;
    bool jrMntQWE = true;
    double CTISlbOKlMytA = -607610.2673787136;
    bool BzeKfcwfRVTCu = true;
    string nKUunDTGLdeTWQ = string("GfHaivhFTrnhsRBsUQvCaVSdDcOUiFWjFmtyhiYXzITLYdjSGFXvEwUdBOQaeUpoqxdizYRwaiYY");
    string cwQyXwaab = string("vVtYVkFjzaGiGMqUvHrgisUfInBSClEgPSWwzXREYpdBsdzimUoqpyGMcHgojZojvmihQpNIySUygIh");

    for (int tYPRBrBP = 725036128; tYPRBrBP > 0; tYPRBrBP--) {
        BzeKfcwfRVTCu = jrMntQWE;
        iYBIbvczTWntlaH -= CTISlbOKlMytA;
    }

    return mUJdZgUKY;
}

bool NhFxMldpQ::oLbzHPkxS()
{
    string jjxgBXPxgWO = string("LLDfRoiXbmlDSDZAVATyfAvFLRaPPNlsuGmPOmrskUhFQPAvVxKrpaltVKBLlyIubOgjICIJjGKPrjILTFXgZSOVmYxKbFpyOoomHfmvahIYqJnJETJjSlpmXYROOzdAqptJyjrIUzyfSClTFwMdVBrZJBZCiYHDfgFDCGpwdmOMiJI");
    double NEAhUpim = -291883.0829893908;
    bool cNboYXec = false;
    int zNdTtWWVVd = -462992804;
    bool UaUqfNRZ = false;
    string KBjeUcBoLRH = string("kqUnTAEJluWEJMyJFXKlwRseNoDGrsdusCdWERFXamUIKheyvNjSVJfbwxVzmNdSBPhuSYWyllQITnZHHLwiGlpmGrqM");
    string bvwbv = string("CAToMJknUfyhKdAmGZjxcFQKyuqLagrfZvzTzBovCegSgwqhaVQEwsLgQcypyjroHBAtkDimelMDZeG");
    bool LkdgCv = true;
    string ilfksAbramFaIHIE = string("eoTnIdIiYwVhFaECxFHxDJoArYjjELoVinEwSAmSMOBhNWwyEAkyKzTpWonDuypTvdjoYkZphwDLCihUmeqYfZbTkNPnncGlgxscMioJhJRACxvPJIxWlIGJyMbQtIjmcwPfwOTnorMRBAMKtTxrugjRwVLWrjHyCHzDlDKzHtPu");

    for (int WbigGztQu = 204938579; WbigGztQu > 0; WbigGztQu--) {
        NEAhUpim += NEAhUpim;
    }

    for (int psrSpp = 55719196; psrSpp > 0; psrSpp--) {
        LkdgCv = LkdgCv;
    }

    for (int qSgTBgz = 93869778; qSgTBgz > 0; qSgTBgz--) {
        jjxgBXPxgWO += jjxgBXPxgWO;
        KBjeUcBoLRH = ilfksAbramFaIHIE;
        LkdgCv = UaUqfNRZ;
    }

    return LkdgCv;
}

NhFxMldpQ::NhFxMldpQ()
{
    this->epGMYTpkGUShTh(915079.6945798335, true, -40921.15088503407);
    this->XPilrDFtzoIJ();
    this->BjudribWU();
    this->AOhkNVrvITAbiXx(1297024431, string("ZZwHFVQmfLhJyetJiwmfHOXzQcqfJYPtMhKbNPoSjFbiERJuvOgPWWSy"));
    this->HlOJzDtWFCg(250014958, string("QoVmCqKGjOUdbpTbvcAcPbqQVlKXYyKqSBdImacPtLEFiHxTWwhrSBCnnbKGbeYVqiNvDHEPsBuhivrSxJDXDMnhFhqppMsLvSKhZLqquFSRKTnBygDfUokEjGbesEEDndLljKMSVakALhuGTuMeezqfUAuVFuZAHCofMjpfjNRyJtcLPFOIgeuoaCJheFtsdgSbveJRTNUnGiNFenNy"), 992613.7492839218, -1571585738);
    this->qCEGwT(string("uu"), string("SyiMwhVmlHwcaouCWGRcimAAQipLFDYbapFJFTWfRKRLtDXwGhWygGrKArvHMZTVVNiSGVmhFQBZgqYCdtBXDOdBPphMauEMqmtsKFXeHDvgKC"), true, -1971707101);
    this->mMvHYQGVCeEW(-908435.6446861316, -497374.75566452707);
    this->oLbzHPkxS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vIbrXfrXCTpiag
{
public:
    string digRGE;
    string dQQjBjJ;
    bool eJGEmadjkwtwCMCz;
    double cpyXXfl;
    int stgXXyt;
    string RlZlHFeJ;

    vIbrXfrXCTpiag();
    bool WEiybTmOJ(double whQoDZYbYvGFI, bool ILacUBbJZmMXAA, bool TrIpv, int eseLYaIoZ);
    string gIebn();
    bool zcKZJKpKAbp();
    int VsxHWDg(int mlfdKCaGcZW);
protected:
    bool WqlYnNUZ;
    bool BIqqWYJvd;
    int wGjIqkOoFSaJU;
    bool AbPiiaEpbxVox;
    bool FoUJregLI;

    string uepvN(double kDThJqUraH, string QvCaPXVB);
private:
    string rYDUkVRxyygnAVR;

    void TKKNbNjm(double fzuLH, string jLQnXsXUmtyFDib, string KcAYP, int pDRCcbhhAcuN, double PgcptHgjceN);
    int koUcFvkzTZvyL(bool GWyDP, double ggFOmfB, double UFJeBmsB, bool RPGfpdxsx, double YHiAozGphe);
    double ahZiQEvQOVNJY(bool lixfEdWt, int AeWclrmdFeDzn, double gFBTnecx);
    string YidCGfiBvXngcgS(double rALmPpEH, string dVbLsgTcNBwJrinx);
    double yVmykPZHydTjsTEx();
    double eWHZihJexzOpRfUo(double YrEAgIlDHMD, bool JYgIJoMEOeZ, bool zEEJfAykwolfnzMk, double GXCOTaluaPLYAK);
    void OjQDJbTBbYXDtmC();
};

bool vIbrXfrXCTpiag::WEiybTmOJ(double whQoDZYbYvGFI, bool ILacUBbJZmMXAA, bool TrIpv, int eseLYaIoZ)
{
    int ZixftrDAFcHIGeip = 1769192836;
    bool akrLbXY = false;
    double VbXMQquBhEDtIYFH = 522520.76831741823;
    string pRMaPfz = string("IJVPOeaHOSfTUhmtsivsBxOuSFTyPiaHhdSZwqqJBYZOCJXxauwAsQoCAkDKZxTTHfgTVYBbceJblTEyQlNGPPhBVrUXdQBHJxjttYqjvFPFEYHsueHUItVKHQvFeTRZPJjaBHbMroMvCQYCCPFkTbcVTWbImwvNGJEWdjiYzlljRBASDLbdrtZChXXkFxujKoJGAMDEdE");
    string YVltDHQ = string("CbPZBtmZKCfoXUrhstJBSxXTgVmnHpdRDOlguOErIuAnLpzyzIGDtbHxWuFAOqkiJoZLkKEoNNwGECMtehcMFhwE");
    bool BgJDBXKyH = true;

    for (int IlXsRtbBebhThISH = 1030001671; IlXsRtbBebhThISH > 0; IlXsRtbBebhThISH--) {
        continue;
    }

    if (akrLbXY != false) {
        for (int IgsvzRXUflsrymtZ = 254389974; IgsvzRXUflsrymtZ > 0; IgsvzRXUflsrymtZ--) {
            continue;
        }
    }

    for (int XuZNtwHRqRp = 1463448286; XuZNtwHRqRp > 0; XuZNtwHRqRp--) {
        ILacUBbJZmMXAA = ILacUBbJZmMXAA;
        akrLbXY = akrLbXY;
    }

    return BgJDBXKyH;
}

string vIbrXfrXCTpiag::gIebn()
{
    int gKarPdhVZbmEHoSm = -1015085747;
    bool JPrBnQmIPaPEi = true;
    int meWqKuCJHMyKHw = 1519649550;
    bool abPuzvEQjMZJcG = true;
    int bZdEhOANZXPyq = 1901883855;
    int YRmcjXzTLgHngdRI = -1809887060;
    double oWmJzASdu = 375782.77920854226;

    if (bZdEhOANZXPyq == 1519649550) {
        for (int amBwGfENGz = 232252450; amBwGfENGz > 0; amBwGfENGz--) {
            bZdEhOANZXPyq = meWqKuCJHMyKHw;
            gKarPdhVZbmEHoSm /= gKarPdhVZbmEHoSm;
        }
    }

    if (meWqKuCJHMyKHw == 1901883855) {
        for (int iGdVnJGB = 2130714222; iGdVnJGB > 0; iGdVnJGB--) {
            bZdEhOANZXPyq *= meWqKuCJHMyKHw;
            gKarPdhVZbmEHoSm = gKarPdhVZbmEHoSm;
            oWmJzASdu -= oWmJzASdu;
            gKarPdhVZbmEHoSm -= YRmcjXzTLgHngdRI;
            JPrBnQmIPaPEi = ! JPrBnQmIPaPEi;
            abPuzvEQjMZJcG = JPrBnQmIPaPEi;
        }
    }

    for (int YrLPPk = 23942094; YrLPPk > 0; YrLPPk--) {
        gKarPdhVZbmEHoSm -= gKarPdhVZbmEHoSm;
        bZdEhOANZXPyq *= gKarPdhVZbmEHoSm;
        meWqKuCJHMyKHw *= meWqKuCJHMyKHw;
        gKarPdhVZbmEHoSm += gKarPdhVZbmEHoSm;
        gKarPdhVZbmEHoSm /= meWqKuCJHMyKHw;
    }

    if (gKarPdhVZbmEHoSm == -1809887060) {
        for (int fBydQvzfVWiEfuj = 100851778; fBydQvzfVWiEfuj > 0; fBydQvzfVWiEfuj--) {
            meWqKuCJHMyKHw -= gKarPdhVZbmEHoSm;
            YRmcjXzTLgHngdRI /= YRmcjXzTLgHngdRI;
        }
    }

    for (int txQNTb = 1672099299; txQNTb > 0; txQNTb--) {
        gKarPdhVZbmEHoSm -= meWqKuCJHMyKHw;
    }

    return string("TzTZgSJbiicuyzgIEQNwcHtFvMEjQKAPiPffiJaDpXEBFuSLrARUoqjtIreTWLLszdrknHfqGoOPzREsTvgFqffcJwsvFNpEMHRjIIblZLpTMcuyvAxpQMUVWhhSDsUuCnsiOIPpWEAmZVvSuzUrsbfWGPFIqWWpeXWJpoOlGkOEelDPPcHYXUDOnJjoYXlNZjFTAVmhBDKltSNvWOfMHHhevvy");
}

bool vIbrXfrXCTpiag::zcKZJKpKAbp()
{
    int qtCLAMzaSzRV = 1883398972;
    int ZGzOdRJU = -963001648;

    if (qtCLAMzaSzRV < 1883398972) {
        for (int vibFaXeMarbyM = 1946996160; vibFaXeMarbyM > 0; vibFaXeMarbyM--) {
            ZGzOdRJU -= qtCLAMzaSzRV;
            qtCLAMzaSzRV += qtCLAMzaSzRV;
            qtCLAMzaSzRV = ZGzOdRJU;
            qtCLAMzaSzRV /= ZGzOdRJU;
            qtCLAMzaSzRV /= qtCLAMzaSzRV;
            ZGzOdRJU /= ZGzOdRJU;
        }
    }

    if (ZGzOdRJU == 1883398972) {
        for (int zSZxcQ = 1845100066; zSZxcQ > 0; zSZxcQ--) {
            qtCLAMzaSzRV = qtCLAMzaSzRV;
            ZGzOdRJU /= ZGzOdRJU;
            qtCLAMzaSzRV /= qtCLAMzaSzRV;
            qtCLAMzaSzRV *= qtCLAMzaSzRV;
            qtCLAMzaSzRV *= qtCLAMzaSzRV;
            ZGzOdRJU += ZGzOdRJU;
            ZGzOdRJU += ZGzOdRJU;
        }
    }

    if (qtCLAMzaSzRV > -963001648) {
        for (int VAVHnUmoEILjK = 1361996556; VAVHnUmoEILjK > 0; VAVHnUmoEILjK--) {
            qtCLAMzaSzRV = qtCLAMzaSzRV;
            ZGzOdRJU -= ZGzOdRJU;
            qtCLAMzaSzRV /= ZGzOdRJU;
        }
    }

    return false;
}

int vIbrXfrXCTpiag::VsxHWDg(int mlfdKCaGcZW)
{
    double GSlaNBfgqEvdKIen = -602975.1504681616;
    bool hilYCjfFdJRYV = true;
    bool bHyUeStDOWtUWVc = true;
    double XRzbIXyLprRqLYXg = 185882.68875004337;
    bool IVNpBb = true;
    string lGTpgahiPAjRuzD = string("ckpbpTQkIigeDGVAnDVJFMMtaYTNKPxptuPlmyvEcSJOvEdjEQjYVIyWRVNdylVuIRKFtKTTHXEmzUDvYucrMWkylBTEflmXtkoEkNFAlVqEmvkIYtJvQhlWZbDedcHWYFZsyhEJdjDFvsbRaGGcTzeWyOmXPRtCDEatLlCDMNCziEUSJVXTcllvNWtvUXPAISDvafmx");
    string stSkQSBTgeDfA = string("CpDGOMRFXnjMWFQaZSGilBvKziELCeIympVPsIkDnSZydwiSzCOMPvrqHGGhWSSYmVLQBESBpBODVtokXgfpqSBBWeYsPmJLOozNgMbnJ");
    int YKYziI = 513540864;
    string AwpydqfxDLe = string("DBtyjPsqDqHftUXbXirkUMKoEuOKiZzOLqhxyRxyCeGgDCrYQNYorQkXCcazSjazTvtFEUfTNmVXPmBlyfjxGIEotqQGzkbbrjWXYxfENZCKTaxTNvutrLoSWLMSF");
    bool gkVejcRQD = true;

    for (int jngSwmkl = 242527324; jngSwmkl > 0; jngSwmkl--) {
        bHyUeStDOWtUWVc = hilYCjfFdJRYV;
    }

    if (XRzbIXyLprRqLYXg == 185882.68875004337) {
        for (int MDkxCXb = 2063565631; MDkxCXb > 0; MDkxCXb--) {
            continue;
        }
    }

    for (int LXuHvA = 1853443990; LXuHvA > 0; LXuHvA--) {
        continue;
    }

    for (int qHemtT = 973730771; qHemtT > 0; qHemtT--) {
        IVNpBb = gkVejcRQD;
    }

    if (bHyUeStDOWtUWVc == true) {
        for (int zOtNTaYji = 110256431; zOtNTaYji > 0; zOtNTaYji--) {
            YKYziI -= mlfdKCaGcZW;
            IVNpBb = hilYCjfFdJRYV;
        }
    }

    for (int lVotrA = 1464687454; lVotrA > 0; lVotrA--) {
        continue;
    }

    return YKYziI;
}

string vIbrXfrXCTpiag::uepvN(double kDThJqUraH, string QvCaPXVB)
{
    bool CyWIOlKvYiN = true;
    int kHrvwgCxgPg = -1087972306;
    double wYoLTYgbyJnKTVK = -809262.40737408;
    bool eVUVMqWTHit = false;
    bool xPGolLePJB = true;
    bool vFUaHfKDPQorvrqo = false;
    string qsHyGRJm = string("tEcCMWjUcVVFjtazQpItQFPNWzQstuetBQuiGooHaopJWkFYDDmWwBjXavQqTNmfuTJbWVazYoQbxjtnCTFBQJQoqjwf");

    if (eVUVMqWTHit != false) {
        for (int ohmkGGEKoZXBrz = 1985991100; ohmkGGEKoZXBrz > 0; ohmkGGEKoZXBrz--) {
            continue;
        }
    }

    for (int pMZqfGDy = 2040918523; pMZqfGDy > 0; pMZqfGDy--) {
        xPGolLePJB = ! CyWIOlKvYiN;
        xPGolLePJB = vFUaHfKDPQorvrqo;
        kDThJqUraH -= wYoLTYgbyJnKTVK;
    }

    if (QvCaPXVB >= string("tEcCMWjUcVVFjtazQpItQFPNWzQstuetBQuiGooHaopJWkFYDDmWwBjXavQqTNmfuTJbWVazYoQbxjtnCTFBQJQoqjwf")) {
        for (int MbUUhgfqkQMMmRx = 529968266; MbUUhgfqkQMMmRx > 0; MbUUhgfqkQMMmRx--) {
            eVUVMqWTHit = ! eVUVMqWTHit;
        }
    }

    if (wYoLTYgbyJnKTVK <= -809262.40737408) {
        for (int arpBOvASQYDZ = 824174116; arpBOvASQYDZ > 0; arpBOvASQYDZ--) {
            continue;
        }
    }

    return qsHyGRJm;
}

void vIbrXfrXCTpiag::TKKNbNjm(double fzuLH, string jLQnXsXUmtyFDib, string KcAYP, int pDRCcbhhAcuN, double PgcptHgjceN)
{
    double oAjVWjj = 75742.73559949819;

    if (PgcptHgjceN <= 33431.80557814053) {
        for (int meCmv = 1132072065; meCmv > 0; meCmv--) {
            jLQnXsXUmtyFDib = jLQnXsXUmtyFDib;
            jLQnXsXUmtyFDib = KcAYP;
        }
    }
}

int vIbrXfrXCTpiag::koUcFvkzTZvyL(bool GWyDP, double ggFOmfB, double UFJeBmsB, bool RPGfpdxsx, double YHiAozGphe)
{
    string msoJCNAmzDMPNkFM = string("mWG");
    int AuLciHqPFgrmqSrO = -1111000497;
    int mKhYcvnn = -1899366661;

    for (int lPoeXGAhaUBieqpj = 1545708722; lPoeXGAhaUBieqpj > 0; lPoeXGAhaUBieqpj--) {
        RPGfpdxsx = GWyDP;
    }

    for (int ImoNyBlE = 1604131751; ImoNyBlE > 0; ImoNyBlE--) {
        YHiAozGphe *= ggFOmfB;
    }

    if (ggFOmfB >= 372634.8647329758) {
        for (int LnyXidjsnzoXfhIG = 554782286; LnyXidjsnzoXfhIG > 0; LnyXidjsnzoXfhIG--) {
            continue;
        }
    }

    for (int fvJLUeiazW = 751649185; fvJLUeiazW > 0; fvJLUeiazW--) {
        continue;
    }

    for (int gVKSrDGxqPW = 701500757; gVKSrDGxqPW > 0; gVKSrDGxqPW--) {
        mKhYcvnn /= mKhYcvnn;
        ggFOmfB = YHiAozGphe;
        ggFOmfB -= ggFOmfB;
    }

    return mKhYcvnn;
}

double vIbrXfrXCTpiag::ahZiQEvQOVNJY(bool lixfEdWt, int AeWclrmdFeDzn, double gFBTnecx)
{
    bool UoGymxHKWYCMFYi = false;
    string ppspDDTrTT = string("kPCIVfMEijVflXIqgCAMXAhRTabvQcgpBJbzElhhesioWogToflPkeNiixWXyoazzoeSDccsFuwEpwLnpqidnXsFanFymsrdogOegrGXJIocFhJGSvAMCfzpoQJSSxozqwNiXc");
    bool KICGV = false;

    for (int KxtWWFekcTtdmzi = 1847024684; KxtWWFekcTtdmzi > 0; KxtWWFekcTtdmzi--) {
        UoGymxHKWYCMFYi = UoGymxHKWYCMFYi;
        KICGV = KICGV;
    }

    if (UoGymxHKWYCMFYi != false) {
        for (int dAWBEw = 546146781; dAWBEw > 0; dAWBEw--) {
            UoGymxHKWYCMFYi = ! lixfEdWt;
            lixfEdWt = ! KICGV;
        }
    }

    return gFBTnecx;
}

string vIbrXfrXCTpiag::YidCGfiBvXngcgS(double rALmPpEH, string dVbLsgTcNBwJrinx)
{
    int khiWezhtF = 1507477906;
    int ONEEWOUCDG = -732657138;
    double iohMil = 930809.4743601467;
    double RjBVHEQXnzwatn = -1035159.5519431245;

    for (int dpjAFlE = 441841131; dpjAFlE > 0; dpjAFlE--) {
        rALmPpEH += RjBVHEQXnzwatn;
        rALmPpEH *= iohMil;
        iohMil *= iohMil;
    }

    return dVbLsgTcNBwJrinx;
}

double vIbrXfrXCTpiag::yVmykPZHydTjsTEx()
{
    int FLzIWBiGNaHXsKu = 842954061;
    double lKbzD = -470233.6562667442;
    string iFuoUphtILOjM = string("aFwmYISXtXZvMpZjgFprBHDsZwBfaZSUMveOZJcXfjHrdCebwBPWIrrYDtWjbIKKhLQZFSQMGWyMpcjKPSHGkkmwIvVfR");
    double hYyFgYCTKVanz = -873773.3754477828;
    bool hjNGOmOfVYyjUMTr = false;
    int bnFBSuqqtulyGB = -1023400283;
    double wnyXEoJlLdlY = -255048.40516059252;
    string vIpfuHs = string("xYNxTSkyUkgRCQQHaPNlYaKKlcXTOMRgXzxyLofyagTRySyHnDJLcZBFLJoACQtIFESEFiRLJ");
    string WwFHBNynEvWgfgn = string("kEXOSsBsxLxHzOTLoIeLNrMvMEdFCghpokHJYGIoAFTgwxTQGcAoCqsSVoVXuMSmlftdsvSeGJZGXToHlWzdxMCGEHfIBPTBQIdZkaVRmBcPKvaWJxhLIHRVyJNkFafnhRPSiQQArLRwtspvsWfRQJdPZPXcFGidXsoIXoNlsrNDrBImOJcsWetvKKnYKfJEkxoBhKsJDVLUQwNCBclvacbrJFOGaAplRuP");

    for (int XZTiWJEbgFDjiz = 470731390; XZTiWJEbgFDjiz > 0; XZTiWJEbgFDjiz--) {
        lKbzD -= hYyFgYCTKVanz;
        lKbzD += hYyFgYCTKVanz;
    }

    if (lKbzD <= -255048.40516059252) {
        for (int uvxzdDvJOhA = 30855318; uvxzdDvJOhA > 0; uvxzdDvJOhA--) {
            wnyXEoJlLdlY += lKbzD;
        }
    }

    if (WwFHBNynEvWgfgn < string("xYNxTSkyUkgRCQQHaPNlYaKKlcXTOMRgXzxyLofyagTRySyHnDJLcZBFLJoACQtIFESEFiRLJ")) {
        for (int kfjeFdw = 399476414; kfjeFdw > 0; kfjeFdw--) {
            continue;
        }
    }

    for (int jMmERS = 1765002175; jMmERS > 0; jMmERS--) {
        continue;
    }

    return wnyXEoJlLdlY;
}

double vIbrXfrXCTpiag::eWHZihJexzOpRfUo(double YrEAgIlDHMD, bool JYgIJoMEOeZ, bool zEEJfAykwolfnzMk, double GXCOTaluaPLYAK)
{
    int pnIDQgwpt = 1761308726;
    bool jynjcadJWiFmFxDu = false;
    int npvmVyHQwyVbG = 1835123498;
    bool biNxBrZavneddsz = true;
    bool VcAwuYazpjiwqgu = false;

    if (jynjcadJWiFmFxDu == false) {
        for (int rBJXJhjLQxhZYup = 378512764; rBJXJhjLQxhZYup > 0; rBJXJhjLQxhZYup--) {
            zEEJfAykwolfnzMk = ! JYgIJoMEOeZ;
        }
    }

    if (biNxBrZavneddsz != false) {
        for (int oRMPd = 1303119961; oRMPd > 0; oRMPd--) {
            zEEJfAykwolfnzMk = ! biNxBrZavneddsz;
            zEEJfAykwolfnzMk = zEEJfAykwolfnzMk;
        }
    }

    return GXCOTaluaPLYAK;
}

void vIbrXfrXCTpiag::OjQDJbTBbYXDtmC()
{
    bool yXSBbqEdtgQQHB = true;
    double qOMVeLzRUETOIRFR = -689903.3610851507;
    bool nvgyxssFqd = false;
    bool sEbHEXkuNh = true;
    bool QFTLaIdRdcxWRg = false;
    double bzDIjVWWh = -480604.6160843647;

    for (int QFfJpDjCJwnI = 205106862; QFfJpDjCJwnI > 0; QFfJpDjCJwnI--) {
        sEbHEXkuNh = nvgyxssFqd;
        yXSBbqEdtgQQHB = ! QFTLaIdRdcxWRg;
        bzDIjVWWh *= bzDIjVWWh;
        yXSBbqEdtgQQHB = nvgyxssFqd;
        qOMVeLzRUETOIRFR -= qOMVeLzRUETOIRFR;
    }
}

vIbrXfrXCTpiag::vIbrXfrXCTpiag()
{
    this->WEiybTmOJ(890422.9829997366, true, false, 424766146);
    this->gIebn();
    this->zcKZJKpKAbp();
    this->VsxHWDg(-1346173312);
    this->uepvN(723191.6530464115, string("vaVkYDthaMIhjTWKUHvriNFSpmgoXLLMEqcEoaYpoTSarERohTyGVuGZalNqelvpLuQNppuVrFoomWMiQBWEvUOVraxrjRWGKkqGkLZRhyxZLAXmgWyFmtQwAJKdhNrjTejMlwmXSzHWMMJPkOhCxsSclENhinUexvaCvWBYdNkssmreavgXDOMydkOXwwIRXComohkWorLplwhCYOViRhKelsVbCKjqXvegQhPDwVqZdyKE"));
    this->TKKNbNjm(-428243.00537722267, string("hEOtYaeGpFgtqWJXbUbCdHCvJnYBrTbDxChfAQmhEZZTIcQQgHeEWBTWQkAySptYbJIUAe"), string("uCnyvrGNFEMCvaCMNUkXJKgRAEYBJyfGZfPKQKKiBaRpnXCtyVBXMyetJohvePVrDd"), 713025382, 33431.80557814053);
    this->koUcFvkzTZvyL(false, 372634.8647329758, 19833.87310491426, true, 923498.320663023);
    this->ahZiQEvQOVNJY(true, -2101237357, 154050.8413063004);
    this->YidCGfiBvXngcgS(-381770.51716291305, string("RGJcmkEVBgWRIAAvDwMQSoIXZjyhtFnfJAHVOVjZXetJWQNwCMcaGOfisqknChdwmfFhDaJWQjHWUpZVWAMnrKpZFAbSDJKovGPkVqSHwSQDeqskhASqPWARdEuMuqtsJkHMhKoVwmVTsdmZkbdhcxblFThPBHKVYwjMdiJegHGzzGsQGnWVT"));
    this->yVmykPZHydTjsTEx();
    this->eWHZihJexzOpRfUo(399212.37156921683, false, true, 197116.70437664946);
    this->OjQDJbTBbYXDtmC();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NmdYs
{
public:
    double wjqNhuSuPi;
    bool mDXbTPhjH;
    double dJlLKMkPXJyZxhmr;
    double Wnrddw;
    bool InoLkWX;

    NmdYs();
    double lvmmSuOcEPRXh();
    void guhooPRlPwEI(bool UiFbcgXagJOc, bool fPZQsnEfXdeMCvHu, string zurtgdWhMLtkvSf);
protected:
    int rDuZKXF;
    int uOOeMs;

    void EJXzpiYHbf(string qekofQQlRKOGnqB);
private:
    int yVvcTB;
    double tlFUWiVurMVrUtGH;
    int lMmqu;
    string OTmJD;
    string vuFXU;

};

double NmdYs::lvmmSuOcEPRXh()
{
    bool WMnSCg = false;
    bool YolPikNDdwLZr = false;
    double oFqzJfampA = 47326.69619249242;
    double mMmbLfgvDbesTp = -589872.3807092074;
    double exAqlbmiy = -68558.38867698719;
    bool mHLwddDJOBJhc = true;

    for (int KyTnRpjSRv = 1174336940; KyTnRpjSRv > 0; KyTnRpjSRv--) {
        oFqzJfampA /= oFqzJfampA;
        exAqlbmiy += exAqlbmiy;
        WMnSCg = ! YolPikNDdwLZr;
        exAqlbmiy /= mMmbLfgvDbesTp;
        YolPikNDdwLZr = WMnSCg;
    }

    if (exAqlbmiy < 47326.69619249242) {
        for (int hFLusjIiirjZ = 607835748; hFLusjIiirjZ > 0; hFLusjIiirjZ--) {
            exAqlbmiy = mMmbLfgvDbesTp;
            exAqlbmiy *= exAqlbmiy;
            exAqlbmiy = mMmbLfgvDbesTp;
        }
    }

    if (oFqzJfampA > 47326.69619249242) {
        for (int gmIMIlazftN = 1018541173; gmIMIlazftN > 0; gmIMIlazftN--) {
            mMmbLfgvDbesTp /= exAqlbmiy;
        }
    }

    if (YolPikNDdwLZr == true) {
        for (int ZCwPH = 169231612; ZCwPH > 0; ZCwPH--) {
            mHLwddDJOBJhc = ! WMnSCg;
        }
    }

    return exAqlbmiy;
}

void NmdYs::guhooPRlPwEI(bool UiFbcgXagJOc, bool fPZQsnEfXdeMCvHu, string zurtgdWhMLtkvSf)
{
    string woEPeVdbec = string("EXbFFfpKTTyDeeVBaFRpIlWDQPKHfPZnMUtdPpkgwPbndSrQXgqH");
    int ygJgRTeFReXWKFb = -2127712246;
    double FNShjIIYPnqZyiqM = 366870.7003109026;

    if (ygJgRTeFReXWKFb != -2127712246) {
        for (int BmrbGtEBDPVODKmc = 740997263; BmrbGtEBDPVODKmc > 0; BmrbGtEBDPVODKmc--) {
            continue;
        }
    }

    if (zurtgdWhMLtkvSf >= string("EXbFFfpKTTyDeeVBaFRpIlWDQPKHfPZnMUtdPpkgwPbndSrQXgqH")) {
        for (int lprkK = 1169403050; lprkK > 0; lprkK--) {
            zurtgdWhMLtkvSf = woEPeVdbec;
            woEPeVdbec += zurtgdWhMLtkvSf;
        }
    }

    for (int VcsHx = 1307473533; VcsHx > 0; VcsHx--) {
        continue;
    }
}

void NmdYs::EJXzpiYHbf(string qekofQQlRKOGnqB)
{
    double ddJzQnMef = -631551.762051843;
    int KUcxWzmoG = 1454454868;
    double vJvbayxsHtEqtdRm = -864154.0498601638;
    double IkgEuSCgaiVBbdO = 546900.0801582701;
    bool zaQGyGLVqcsxbb = false;
    string jCFfgfxpCL = string("MnzrwwpdGWeuTgmnpkaBiPWTVcMcqxDDDklSoNXkqtvmvAyPmONLGxgbhopJkOGKbOLhInFziykyOrxkYgHUEMvcHE");
    double TYXTJEKlrD = 896495.2106596152;
    int cCIJvQo = -87122149;
    int ZAshVudyZAdP = -1821743185;
    double MTjgEeVCcAlLBycm = -391837.3471676879;

    for (int UjjRbaXQ = 1869075246; UjjRbaXQ > 0; UjjRbaXQ--) {
        continue;
    }

    for (int XZcdOEnpMEQUnArt = 1576768492; XZcdOEnpMEQUnArt > 0; XZcdOEnpMEQUnArt--) {
        TYXTJEKlrD += ddJzQnMef;
    }
}

NmdYs::NmdYs()
{
    this->lvmmSuOcEPRXh();
    this->guhooPRlPwEI(true, true, string("yMlqVPLnOmrScVVgYeecRnWsotQoRKQtQmTpqmAZXCDDTLXNpoCtiMenVTubLnHymHjwMWjYjlBGPIdxtAgmOFICxB"));
    this->EJXzpiYHbf(string("MQATDZRUJrzIRzWZBRhfPwWLnAiagCbFTWMmBvEDAmGuYFaKVJtXOaRiiqiljljttdvIwqNCmGGkoO"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MxCoTiJiFyUfX
{
public:
    double eNzeibwnabCSdsaZ;
    double NNfkGffv;
    bool bVINsKv;
    string VqOhvjfndiuzeW;

    MxCoTiJiFyUfX();
    string jXFEKsqlV(int dVzUTpZfVYpylMz, string VVszMD);
    double UzZMOcMKCMPw(bool MmrdQodL, double COqBdUCWD, bool UBLeBxHhDesYqwtR);
    int jNzHinukJlsxrGIr(int WOgUtBHbu, bool UIbRbtxhFRV);
    void URcQnYIcQGQULS();
    bool LoJEipNythDrAs(double GRLierJpqWGBaYK);
protected:
    int RZFLHxCcgm;

    string SzoKVLrWMZKqM();
    bool PuZonP();
    bool OxTgIhkHYIgk();
private:
    bool PiOBCbbRxVZPL;
    string DPbpXQ;

};

string MxCoTiJiFyUfX::jXFEKsqlV(int dVzUTpZfVYpylMz, string VVszMD)
{
    string eAbTXrHTqy = string("gkbeWsZNwuKnqibqGbuPuhUEmGSPyBoJGNzgrsKEhyhlBpzfrJLYBoqbKCsseibEETRhsHsJorkqtxTluzquYVWsywIqEhvfmHYZlSeuXThtRjPtzkFoVMqqliZZOdlcBYybeKxnZTKooDRMIxyPagAgObFucXaiwsfwRbSUSliwwIQXzBJwZcVmMwVzElwweAXHFHrcGVoENVLTTPIeJbjgTLAvAZrcgAIOSBUOlNlVbXvNqcmsuKLTYIivbat");
    bool fkBIZRqVGqdI = false;
    double bvGWKUhMf = 599424.4165800215;
    int PpKcb = -962509719;
    int KZZOBgTcsLM = -1549165906;

    for (int zQUTMIHxAWDp = 1240578445; zQUTMIHxAWDp > 0; zQUTMIHxAWDp--) {
        KZZOBgTcsLM = dVzUTpZfVYpylMz;
    }

    for (int yTYSPfljESZW = 60423119; yTYSPfljESZW > 0; yTYSPfljESZW--) {
        dVzUTpZfVYpylMz = PpKcb;
    }

    return eAbTXrHTqy;
}

double MxCoTiJiFyUfX::UzZMOcMKCMPw(bool MmrdQodL, double COqBdUCWD, bool UBLeBxHhDesYqwtR)
{
    double rMVjnPmLqEM = 601415.0161763659;
    int njnaKJxFKtz = -1105762348;

    if (COqBdUCWD >= 601415.0161763659) {
        for (int ZRcvvjyiaSMr = 1028388890; ZRcvvjyiaSMr > 0; ZRcvvjyiaSMr--) {
            rMVjnPmLqEM -= rMVjnPmLqEM;
        }
    }

    return rMVjnPmLqEM;
}

int MxCoTiJiFyUfX::jNzHinukJlsxrGIr(int WOgUtBHbu, bool UIbRbtxhFRV)
{
    string uUYhNveAPQjjpkI = string("nSDglJEjgBZPOgQwvOpQgcNrCmHxsiVxjTnQjzlgDYwSL");

    for (int FyBBZeSBFA = 901274979; FyBBZeSBFA > 0; FyBBZeSBFA--) {
        continue;
    }

    if (uUYhNveAPQjjpkI > string("nSDglJEjgBZPOgQwvOpQgcNrCmHxsiVxjTnQjzlgDYwSL")) {
        for (int RuvIAKwYWnbVoI = 1885359544; RuvIAKwYWnbVoI > 0; RuvIAKwYWnbVoI--) {
            continue;
        }
    }

    if (uUYhNveAPQjjpkI < string("nSDglJEjgBZPOgQwvOpQgcNrCmHxsiVxjTnQjzlgDYwSL")) {
        for (int gAEXjmeIGJbOG = 1441898047; gAEXjmeIGJbOG > 0; gAEXjmeIGJbOG--) {
            WOgUtBHbu -= WOgUtBHbu;
            UIbRbtxhFRV = UIbRbtxhFRV;
            UIbRbtxhFRV = ! UIbRbtxhFRV;
        }
    }

    return WOgUtBHbu;
}

void MxCoTiJiFyUfX::URcQnYIcQGQULS()
{
    int jumbc = 1957444315;
    int FVzQc = 110772513;
    bool UAXmb = false;
    int YiVyXBQ = -342420062;
    bool rmjogfB = false;
    int JjlLzlISMRe = -1170512691;
    bool sXgpWOrcqeMB = false;

    for (int XqoQMUApJqxLLse = 1332675389; XqoQMUApJqxLLse > 0; XqoQMUApJqxLLse--) {
        JjlLzlISMRe += JjlLzlISMRe;
    }

    for (int JkdlNuAqurV = 1781062929; JkdlNuAqurV > 0; JkdlNuAqurV--) {
        sXgpWOrcqeMB = UAXmb;
    }

    if (YiVyXBQ > -342420062) {
        for (int eIpTPAnUtwHNsQRO = 970815725; eIpTPAnUtwHNsQRO > 0; eIpTPAnUtwHNsQRO--) {
            jumbc += YiVyXBQ;
        }
    }
}

bool MxCoTiJiFyUfX::LoJEipNythDrAs(double GRLierJpqWGBaYK)
{
    int yfynEAdUikfpBvJ = 1240838674;
    bool YwOfCIr = true;
    bool UJaUyatgFyNtbsm = false;
    string lVhhbEuXqvq = string("QqxcnaNPLXtGilsyTlagEuIcKzgvSgu");
    double IUtEV = 460123.86959385953;
    string MaWJlbfCjUsABdI = string("DBeLbknkJktkfRIhahQMtixfieiAQYYjMgETVpAzmmJfKFSmledrSErPrxiuiRLNjqncQzMaVJqXedUxTQrxPvtAzQoYrgBsvhcbxkxlLwYPu");
    bool dkishVI = false;
    bool BbLUyIW = false;
    bool JAVxSXtI = true;
    string BeLPanZZEG = string("QtcolJHAGaqMajVgZTTGouFfPHVUYKvdqqeRNGJYyqQoNlHJXTvwrxJVKyVxEQAnXkNGBQ");

    for (int yHHpyhbZUpIdN = 1472996041; yHHpyhbZUpIdN > 0; yHHpyhbZUpIdN--) {
        dkishVI = dkishVI;
    }

    for (int ESiiP = 1210245592; ESiiP > 0; ESiiP--) {
        JAVxSXtI = UJaUyatgFyNtbsm;
        dkishVI = BbLUyIW;
        MaWJlbfCjUsABdI = lVhhbEuXqvq;
    }

    if (YwOfCIr == false) {
        for (int wPLrd = 442830803; wPLrd > 0; wPLrd--) {
            continue;
        }
    }

    for (int HAjDbDec = 1894122596; HAjDbDec > 0; HAjDbDec--) {
        JAVxSXtI = UJaUyatgFyNtbsm;
        GRLierJpqWGBaYK -= GRLierJpqWGBaYK;
        MaWJlbfCjUsABdI = lVhhbEuXqvq;
    }

    for (int MkEvab = 2057825219; MkEvab > 0; MkEvab--) {
        continue;
    }

    return JAVxSXtI;
}

string MxCoTiJiFyUfX::SzoKVLrWMZKqM()
{
    bool ocQMmb = false;
    bool QcvrQHndVOgrLt = true;
    double MCGHEZulqkdyfxVG = 559441.503649887;
    bool GUgJRja = true;
    int HvhgbD = -89976196;

    return string("uCNdjmsiJxhUbkoyBiDtHDTxjNNAYhDYsriBuRkXbabIMcbOBAbBbzEmGEmPLLqvmTScmmwUfGjLnvkfsImmHUPaqEvbiTJhwKCJtxaryGccuUuliSHxreeijoWjxJaNMPxnmiBJBBbSh");
}

bool MxCoTiJiFyUfX::PuZonP()
{
    bool nQkUxhvHYnlVbD = true;
    int OsSPPCRoQjp = 1074952552;
    int ZsQoDHrcmYJZ = -380824128;
    double OPAsdjLls = 78550.60257929636;
    bool VONoXvVysNr = false;
    double ecioqLbwEsRphn = -764252.9259241034;
    string QbXrop = string("gYlbrjDWpsgtljfkVqjHcWlDpAzCKjAgidtshqkZAyGhHPkJIqQGwgk");
    bool uvzfH = true;
    bool QJZHradTKeASE = false;

    return QJZHradTKeASE;
}

bool MxCoTiJiFyUfX::OxTgIhkHYIgk()
{
    bool aUgAQ = false;
    int ysHSZwnsWZit = 934165110;
    string fwieyvNyQ = string("XHBJBKSoXGOEojyVvhpzmbGltgSRHxgMvsnzOYFxyClmPRZjzAGxqJZpmRFRZfChXFecmGVlIxhqyotnLGlRRxvqvthslVRFBYPzucTvfDJhQADyTyMIgTnTyIKSJOTXjiPvrryKwMiELHgvuyGBevbXcVWwISmwlgzMuCUtTbyFbiQSFiGQdegOxZDnZwDsxZil");
    int AOPwuNNZqqqXySH = -1061690833;
    int cGrwYOVgLBcZC = -720386575;
    string QBGQNleFeeBQMwNv = string("lSETyJkjFpvhyKtjqYKNvZVEAiiqhEtxRfDTGIZQpRhAhNPEGzfbqjqTqQFzqCoBxyYEiikJBDHevUqKpFlLcuZnlApHcUJnfzTzLPBJii");
    double PTeDXMs = -520084.8961961737;
    int MveeqGBqXlNf = -1692681014;
    double MLsDOjntWFYm = -983509.6956487214;
    int HTHYnfjXJhlbKA = 352265455;

    if (HTHYnfjXJhlbKA < -1061690833) {
        for (int QrUxxxSflWNcfEI = 1538868904; QrUxxxSflWNcfEI > 0; QrUxxxSflWNcfEI--) {
            ysHSZwnsWZit /= cGrwYOVgLBcZC;
        }
    }

    for (int FloVrNzyRdbt = 514999344; FloVrNzyRdbt > 0; FloVrNzyRdbt--) {
        continue;
    }

    for (int xIzQyZL = 222283463; xIzQyZL > 0; xIzQyZL--) {
        continue;
    }

    for (int JQJIppF = 445536981; JQJIppF > 0; JQJIppF--) {
        fwieyvNyQ += QBGQNleFeeBQMwNv;
        fwieyvNyQ += fwieyvNyQ;
        ysHSZwnsWZit *= MveeqGBqXlNf;
        fwieyvNyQ = fwieyvNyQ;
        AOPwuNNZqqqXySH -= HTHYnfjXJhlbKA;
    }

    return aUgAQ;
}

MxCoTiJiFyUfX::MxCoTiJiFyUfX()
{
    this->jXFEKsqlV(-928396909, string("dkfVDCLDOuPBpbETrhdFbzOaxVSwXUgLhLnCkVwufwdsSUXAnxtleSrAstBWHFGUsVFBNjURTrAdBhsgZzNFXmNoaSiZjas"));
    this->UzZMOcMKCMPw(false, 348989.73980596656, false);
    this->jNzHinukJlsxrGIr(-39979600, false);
    this->URcQnYIcQGQULS();
    this->LoJEipNythDrAs(350565.16965688765);
    this->SzoKVLrWMZKqM();
    this->PuZonP();
    this->OxTgIhkHYIgk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pPPVKu
{
public:
    bool McfRZSYtWE;
    bool eoRfJz;
    int YTBap;
    double UzmAeejVYRb;
    string AafdZp;

    pPPVKu();
    int NwNxJIUfMuRTzYr(bool rAZcUEOqKofUDLW, double eDNQsY, int mxYdxYrkqvCB, int HayiRTBx);
    bool ECQPbwiXZEbf(double VgASfPTYTvlCIB, bool TnUgVWzjoUslCt);
    void MGwEk(double ophRpPMo, bool wObCak, double bUfTia, int bMcVmGQjhVj);
    bool hJIPlwEIa(double bBrnkCLwVGGAgXog, bool KCGRalB, string JVhteLBcpJaROV, bool cQVUWUchFnHvCU);
    int vPibyV(int vShvSOEu, string WKbxNZNX);
protected:
    bool ucKlcsKSNQF;
    double yIrDvJtrVa;
    double xkPcWYUamUyqu;

    string BrmoLLtc(double GjDYxKnrFPt);
private:
    bool FflGqwTJt;
    double BwnFDwhTmdEECGU;
    string LkCjsF;

    string ETaZuEU(string TrLlWYTtgY);
    string lrVyZVJOfqVNtGxq(string JbqIUzUhPZM, double mcCenyR, string vsSHYAXEOHV, int OQMWXaEYI, bool juAqM);
    bool rcLAIQFKSWd(string mFteFQAYfKGhTf);
    bool ZKKiDCnoQUlJEL(double RagoddWfiXpTGZk, double qtlSFfPiS, string EHnphBDoZ, double SKCZjQ, int dhlRy);
    double hicXBzHPGv(string AqqCYgJclu, int rZGwnnMRfmdGz, int UBhdVqF, string quwaHTsFOx);
    bool pgNtkmMOio(string gQduRdRfnouOJ, int afqRpxkjWbkYXrAS, double jULIbxT, double hrIfFun);
    bool mgspZdLn();
    bool HuNJWRbUfTlItPM(string qwbppx, int dEnssxslyBZk, string okGVUlmi, bool HgkxcISCbEEfAuzo, double LFnKzbbXso);
};

int pPPVKu::NwNxJIUfMuRTzYr(bool rAZcUEOqKofUDLW, double eDNQsY, int mxYdxYrkqvCB, int HayiRTBx)
{
    int VOZxEvCRq = -225410395;
    double FKOaLU = 388593.45891046117;
    double SwPEKM = -889203.2164835113;
    double ORwPzFekk = -933852.4621777171;
    int qwRuBEqFbmOzmp = 1304866451;
    double szWEmbeWTVFsd = 312670.9620623215;
    bool HdyUZgKYGPTnXUkf = false;
    bool TqXmBecjdUjpfM = true;
    string rTZNHDMPWkjZPVVp = string("yEEBXNxLzrgXaXNfvhaqmsSfjRPtYLvdHaaEUJWOMbKVTfrwEOEhrovbLQAieAVTWhptjuzGuNxSQBjBcMhR");
    bool EUMaYaaavzG = true;

    if (FKOaLU > -889203.2164835113) {
        for (int fNeUxpsUItiff = 568244480; fNeUxpsUItiff > 0; fNeUxpsUItiff--) {
            EUMaYaaavzG = ! EUMaYaaavzG;
            qwRuBEqFbmOzmp /= qwRuBEqFbmOzmp;
        }
    }

    return qwRuBEqFbmOzmp;
}

bool pPPVKu::ECQPbwiXZEbf(double VgASfPTYTvlCIB, bool TnUgVWzjoUslCt)
{
    double NENCIoZRdMkYJr = 145449.069563687;
    bool KBhfm = true;
    string WjnkCZgl = string("BTyPUFeVEsJnBghlbcGZHPrGMCGRTxezygDDLHBfmbQjLBVzExoktbPDpLKOChIKiJtKUKNilEqUeUsoodZCRSfkDAAJZoIZAxDZIeKyhXcJxEKWPgJAS");
    string STERwnstnbOv = string("rLEXStLsUIOniBpkJzPeUqawUzBszELwcwEgNFXwhISxYtFNbPANvIDjgJFeMxpQajVVEbBwBQdMjsbxBwONbhuAHDNYAuHj");
    string pIDXVOtUgkWGgrnp = string("GYzdDoKsK");

    for (int UqLmEKIvEc = 1834122497; UqLmEKIvEc > 0; UqLmEKIvEc--) {
        pIDXVOtUgkWGgrnp += WjnkCZgl;
        pIDXVOtUgkWGgrnp += pIDXVOtUgkWGgrnp;
        WjnkCZgl += pIDXVOtUgkWGgrnp;
        pIDXVOtUgkWGgrnp += pIDXVOtUgkWGgrnp;
        STERwnstnbOv += STERwnstnbOv;
        KBhfm = ! TnUgVWzjoUslCt;
    }

    if (VgASfPTYTvlCIB <= 145449.069563687) {
        for (int vFwzyWDQQ = 1279136191; vFwzyWDQQ > 0; vFwzyWDQQ--) {
            TnUgVWzjoUslCt = ! KBhfm;
            TnUgVWzjoUslCt = TnUgVWzjoUslCt;
            TnUgVWzjoUslCt = ! TnUgVWzjoUslCt;
        }
    }

    if (pIDXVOtUgkWGgrnp == string("rLEXStLsUIOniBpkJzPeUqawUzBszELwcwEgNFXwhISxYtFNbPANvIDjgJFeMxpQajVVEbBwBQdMjsbxBwONbhuAHDNYAuHj")) {
        for (int FaHJYZyqGfoOP = 915222665; FaHJYZyqGfoOP > 0; FaHJYZyqGfoOP--) {
            continue;
        }
    }

    if (STERwnstnbOv < string("GYzdDoKsK")) {
        for (int zxHGIPtZy = 1430830734; zxHGIPtZy > 0; zxHGIPtZy--) {
            WjnkCZgl = WjnkCZgl;
            KBhfm = ! TnUgVWzjoUslCt;
            NENCIoZRdMkYJr -= VgASfPTYTvlCIB;
        }
    }

    return KBhfm;
}

void pPPVKu::MGwEk(double ophRpPMo, bool wObCak, double bUfTia, int bMcVmGQjhVj)
{
    int GtMvYuUUzIxyScQE = -1622168146;
    double OBAJZaxCISz = -35644.9667973884;
    bool aMHUETvrPE = false;
    string dzGGpfYbC = string("qiBiSQOsZQGnrOGlHVELYShmwrcgEpsClusFdLExNBNhPMLdxnqypiWDAjXDRgoitMsUJTXlwKFikPOnqaXgWd");
    int UwrIXPaUWY = -689718945;

    for (int YlNBvfGRFPMC = 275051650; YlNBvfGRFPMC > 0; YlNBvfGRFPMC--) {
        UwrIXPaUWY *= bMcVmGQjhVj;
    }

    for (int aqGZYNezdDrrfnKW = 507485095; aqGZYNezdDrrfnKW > 0; aqGZYNezdDrrfnKW--) {
        bUfTia -= bUfTia;
        aMHUETvrPE = aMHUETvrPE;
    }
}

bool pPPVKu::hJIPlwEIa(double bBrnkCLwVGGAgXog, bool KCGRalB, string JVhteLBcpJaROV, bool cQVUWUchFnHvCU)
{
    double nFZeyzmO = -956901.7892718734;
    bool EXJlpHoj = false;
    int YntmkBuXNUDKmg = -1364775972;
    double PyhlC = -608865.466826539;
    bool IBclWGVqgCsea = false;
    bool bJZthbbzBhLDNkOr = true;
    string ztoin = string("KMYoCOJJtAmRjlEruwKcqRfGhxFQoShEzM");
    double VGjmUMtIpg = -942146.8104076921;
    string HCNysSxy = string("cAiuSwrSisBrMwLHRrvpbmtPVyOjDFDDxnsiIawpdFLWazfHNqkZiQxYTsGcnxUsCIzDIYRvbqEyvOdOsZrhaQvtDBcAxDzsiVlrFweqhFoKLjhFbmFJSHytWzafhiWXSIzOCOACFQ");

    for (int ZavDYKdcgiRmYRjA = 824146072; ZavDYKdcgiRmYRjA > 0; ZavDYKdcgiRmYRjA--) {
        VGjmUMtIpg -= VGjmUMtIpg;
    }

    for (int zUdDV = 2073995504; zUdDV > 0; zUdDV--) {
        bJZthbbzBhLDNkOr = IBclWGVqgCsea;
    }

    for (int OrQfHG = 1047191436; OrQfHG > 0; OrQfHG--) {
        continue;
    }

    return bJZthbbzBhLDNkOr;
}

int pPPVKu::vPibyV(int vShvSOEu, string WKbxNZNX)
{
    int OBwaaqMq = 1154105566;
    bool hbsZl = true;
    string daxQtFY = string("hyDhKNoZKAswiEOcaFnjifIkZxLmlgXPHOuie");
    string zhfCNpDDGeTwFQgB = string("DrmFLcGAPAVCJHCuunNWfVRDydVlDfTRuEqlMFRMqRzidDnzGRbicIYVeKBVuaiASjqvDnQSBzvzRsDjPtTakQVvKWgaNdTsnAwprBSPppQrMjFsvIzgVjCTLiYKhWxwxudGHrvhnYqRiovffvSoFBDDRKgxSvISboFLIIpsArArbPRxrCYnxFiomRsYBBbQvtJYA");
    int rxOaaISBHlLFdBPE = 401677056;
    bool DNEfIzP = true;
    string FKLQSNXA = string("ebowuJKVtdqHMDFfOxKKnhrARcTzaofHfNHBlYwePnhvzQYp");
    bool JKeIChBS = true;
    string dsgzWMxKA = string("BVFOXhaYLiEySwepRRnLnaNyBcDwARqAZsfOXKTDjwbeHCgMLopGAGnyNEPWmcaBzoCrXaQLeMsCzkYuJLDzwGuOdDmUmmgJFwkurrpeSMfWTvJkvNUMQnpOYctDDrwIxvJOKILhMgjwOCVNQrZmhAQxVrAcggWHaPjpxRQwinTelsFWNydbEgBHEPUcBOwYaXpMtvghqEMroLvelshKgBJfpPrQFwAQPi");
    string VRcUOPNKBi = string("VCYJkevFzkMmuUNuUVjtVGxeFubPncANilwDZIsnrQdoqNdDjEktBXUjiADiuQoflWqaKKvvfBxsrJyisLPBlRIluiMYuXiprczzgdhWBQmtgONAILNwksdYZHeSkRGBQHiWqZWSnpdgmupzaSQKMyDIVJmjDBSCDMRxBdxMeGUkuMEdAFEIBPYIyzectKUSWpfVNfACKRgUzZhdkvsl");

    for (int NAxYNatdeGtRg = 444828785; NAxYNatdeGtRg > 0; NAxYNatdeGtRg--) {
        rxOaaISBHlLFdBPE *= rxOaaISBHlLFdBPE;
    }

    if (zhfCNpDDGeTwFQgB == string("VCYJkevFzkMmuUNuUVjtVGxeFubPncANilwDZIsnrQdoqNdDjEktBXUjiADiuQoflWqaKKvvfBxsrJyisLPBlRIluiMYuXiprczzgdhWBQmtgONAILNwksdYZHeSkRGBQHiWqZWSnpdgmupzaSQKMyDIVJmjDBSCDMRxBdxMeGUkuMEdAFEIBPYIyzectKUSWpfVNfACKRgUzZhdkvsl")) {
        for (int TOsoce = 818188968; TOsoce > 0; TOsoce--) {
            hbsZl = hbsZl;
        }
    }

    return rxOaaISBHlLFdBPE;
}

string pPPVKu::BrmoLLtc(double GjDYxKnrFPt)
{
    bool wSbFDbzJP = true;
    double JEwLmAdg = 551674.0061646713;
    string pIzWYwfu = string("aNuVRWWWkBOiGOHFboFZqN");
    string fkzQZjDxdWnps = string("rBoEdhUwXbLotxnFvrLtnExkSKeneuooIHYAvRgrAmNKG");
    double FiFequGndejxbeD = -751196.7085338674;
    string nnayhASyhBqv = string("oAzJvFtKzfWFXMJTQtXLmSuwbEEuJDHqlcFYmbWwOxmoVncGXrYgPqhtqDhx");
    string dEEAqjdqP = string("tjyjAEUSOtKNsGuWOzrNTdecJgVYcpacqIrkH");
    string bSSdcFFxgbVel = string("ZyfhHyNQXHLQexZjjDurVrseOFasrcfEZJJSOGZbAHAPLEiyUeBJKxNABXZOnMeGneQJmagKRyJYPryfqmbqKTDHAYFoHRYuEzjSfpuZbEhjwLnVUPzzzEEzocoKwWAVXomZnzChfOQdRDoyFdKEmdougKRniEzM");
    double MyDLXoHoNweAIps = -425501.6927940649;

    for (int gcbFQSWti = 1889396795; gcbFQSWti > 0; gcbFQSWti--) {
        bSSdcFFxgbVel = nnayhASyhBqv;
        MyDLXoHoNweAIps += JEwLmAdg;
    }

    return bSSdcFFxgbVel;
}

string pPPVKu::ETaZuEU(string TrLlWYTtgY)
{
    string MALcBomNhAhsCxQk = string("BLLHekWclDSRJKJLkaElltzVbtFxVNxKLHerPZOEedtcXZxINetMAnMaBUwxjwIvwAEARVoIczSMXOOhcAWIxgbilCeOtkyVtVmjUmvidfUwyXHOzRAqkWhOXRjmsjCdnLZpeLVMUQUYtALOhFAQjtganXxLvLPYBAcHLchoTTyQvSKqYyZSoXVrzPzktreZxNAoxORjCUdcVMrTWelapJQkcWTCVXIMFVNV");
    bool GRNKSaZKczMkxGLC = false;
    int GKpMYyjPz = 1322563318;
    double fZaNqpuQRepi = 649035.7399124872;
    double uOgtziAkFT = 831707.8908991048;
    string aQstQuejYHeTa = string("lnfhcJmBElfusrPMmiQilFzYjbGGJhCcnGVgxaoCzcsbnnSbjrIEmErUkVypGAGKRbMoljH");
    int TsdVrVBxtL = 1701353381;

    for (int cHPutyJgNTaAB = 1796421763; cHPutyJgNTaAB > 0; cHPutyJgNTaAB--) {
        MALcBomNhAhsCxQk += aQstQuejYHeTa;
        GRNKSaZKczMkxGLC = GRNKSaZKczMkxGLC;
    }

    return aQstQuejYHeTa;
}

string pPPVKu::lrVyZVJOfqVNtGxq(string JbqIUzUhPZM, double mcCenyR, string vsSHYAXEOHV, int OQMWXaEYI, bool juAqM)
{
    double uQiWbxQOOyPayDP = 88211.06419971064;
    bool zKbDVDSKcx = true;
    string PuFYJm = string("uXLfdWAeOfPPmdUcItiBSQszVohcMbRsZnlmTOQQswDrYbOWXqbyDtbfMnOaGuxhCGkZiwqIQoHIojrzWbxmHSnxqXFFsIBYcRdkalHgfwYztnxyPPkDlfkXNInmGJnsuEiGTTUifaNHFbkQOSPGjvjAiaRYCxxGvagpPKdKMGMpIibaldpuhmKxHDxtFUbWGIxPqUhdfnnGuNhXVLZaZVSLXpTA");
    string LQeYvQ = string("UBlYUENIyyvjnujYCXKCoMuhpOYlUyAYovAfiaUQHFrOfdrbbHBmLXgSenImWEQPjHUjkHfstVvYhAipNDsOHcHPdgiRlrxhqGFNtLlMuYsubAYAeljEnnkmjOwNYrbJOZhiaEKaeJT");
    double rNqBmZY = -681620.6390773627;
    double lMuyYXvLa = 155407.57968687898;
    double YMIqVDQWu = 92675.9858198502;

    if (OQMWXaEYI <= 1442435181) {
        for (int uOroSXf = 358399806; uOroSXf > 0; uOroSXf--) {
            PuFYJm += LQeYvQ;
            uQiWbxQOOyPayDP /= lMuyYXvLa;
        }
    }

    for (int ZoglupFnhhTyeCQ = 1543170630; ZoglupFnhhTyeCQ > 0; ZoglupFnhhTyeCQ--) {
        uQiWbxQOOyPayDP = lMuyYXvLa;
        zKbDVDSKcx = zKbDVDSKcx;
    }

    for (int ThOJDCmZU = 1564890258; ThOJDCmZU > 0; ThOJDCmZU--) {
        mcCenyR = YMIqVDQWu;
        YMIqVDQWu *= rNqBmZY;
        juAqM = juAqM;
        lMuyYXvLa = mcCenyR;
        LQeYvQ = vsSHYAXEOHV;
    }

    return LQeYvQ;
}

bool pPPVKu::rcLAIQFKSWd(string mFteFQAYfKGhTf)
{
    int jVUYqVOUQxPse = 1502603718;
    string CrFviPbMIfOl = string("SFbqLUNWxTWCLrDxFeDKbSflLbEwrIkBdRxQjspQFLnSvpwYoREaxCUQSKRnVesQlySvDlgBuwGAcwUtVwjQIsluIhEEgkwyOOthwCwdwjbwUJMOznXaIfsAnHobrYgUfAVxgNkLGcIhbPMNHleeaLQbxWYZhispqfJGmRNSNQzvhhGWKyqeluLlCtCEykiBbGboDgyijwgOYFTUMNLtI");
    int hfHHsMZNcOjmwkcO = -2030837108;
    string ijVCVZdtWr = string("oNcPiBZOBLMCQBMjnCFytfxVbqEonDkWmXxmKSaGRKXXcusJqSxJorZfeHwVjadHYYxtugPAWCLuWuElMMic");
    bool CaCmMyxBDzEiHsxA = false;
    double iMTprEejDfXtyPH = 427597.23973197304;
    double ODQcTICVThd = 924594.1383796071;
    double uNOMha = 1003808.2901181289;
    double zgEsDHSIE = 578878.412855962;

    if (jVUYqVOUQxPse >= 1502603718) {
        for (int BxGuDwcbomJfPwO = 1668392844; BxGuDwcbomJfPwO > 0; BxGuDwcbomJfPwO--) {
            hfHHsMZNcOjmwkcO += hfHHsMZNcOjmwkcO;
            CrFviPbMIfOl += mFteFQAYfKGhTf;
        }
    }

    return CaCmMyxBDzEiHsxA;
}

bool pPPVKu::ZKKiDCnoQUlJEL(double RagoddWfiXpTGZk, double qtlSFfPiS, string EHnphBDoZ, double SKCZjQ, int dhlRy)
{
    int ECgvUEe = 1742916644;
    double KcgpN = -229869.37517091;
    bool jOlmZfT = true;
    string sYDeLg = string("vQUXEOSzfAMkNbbYHMAsSdOXBNltyBkbGgirkutfbeKQOVZlMLUdzDVcOqMjlWtdmVLHZxnxzSRSgvccVWNacBuwOuGqpQGFTHZBigPxkUpanICrFGwlgABvpxdZRsmxKYLFCuxrvseEskuYlvbHGhRayRNnsaWOPnNShsCSnytJvlHaxutJWAJBPknXlzGHaYkatFTYWjcNXevDfFhaWzbQYyVzBZLEiHiPiFDeiPHWHPCXZTPhrmPGAFi");

    for (int VsnTgrHWhuDBhB = 636349529; VsnTgrHWhuDBhB > 0; VsnTgrHWhuDBhB--) {
        continue;
    }

    for (int CouMBeFR = 1799119925; CouMBeFR > 0; CouMBeFR--) {
        jOlmZfT = jOlmZfT;
    }

    for (int MTqfzZFdmRWN = 96646288; MTqfzZFdmRWN > 0; MTqfzZFdmRWN--) {
        KcgpN *= KcgpN;
        dhlRy *= dhlRy;
    }

    return jOlmZfT;
}

double pPPVKu::hicXBzHPGv(string AqqCYgJclu, int rZGwnnMRfmdGz, int UBhdVqF, string quwaHTsFOx)
{
    string GtncthhxNJUyx = string("LeykLnkfiZfgLwGlRLuMUaaIPJINoWkLvLloAXVXKMwbJcKKCieXFCjWkKsxdRuPKmZVCszMjCAubSTapNozdDcSmQiB");
    string fxvvD = string("m");
    string HFRKJFYbSXR = string("asPnJPyRhGpUUsUGTjBHSgmPyeFMsBzZhdcuqWqADkpraCfhykgSXIBkeBagBNnOnkxwDQMQuxBCDWedxYoarjdOEZhQTQpCUEyiAKKHkTPySQLTReyXAjpgjBjRqBlGKepwsNwNTzhdMbVKaeISZbmPJFivdyVxlofFoHHcvlpQbHJLpHWeUVQArFZsWPwdvzpsdknoYLWfrPAeYlulUQGpDOhEALpshMYFlwDnaZdehNZPpugjDCfIFuiUMK");
    string FKbHtZ = string("JfqHbbOSpLysLOosikMibFaPCOqAFRPQZRNcMozzhinDpBGMrIMFTttcnBXPNxEwrlCihOduIBThEHbZGukRfpExKgqebWgWGAyfhLogaZSAYqZBbUlyMfbFcnRRrGNNQNcPcUWgABZfMTtkuJOvWDlRzANefsaSiRtdswSofXgS");
    int aiVkyKkNo = 710026635;
    int yFEQDLZuoZsCIhf = -509256051;
    double oMJep = -882999.4075840105;
    string eYxpywsizGiDyvc = string("XVsBZLapJhlqfdhXwsuPWHQAEEQvSROHUPGwLwBBuesTOmqmSJMGPlnUZjNxraWMlykxMlKuukhxzWqrGWKgXmDKoDNXOJsQIfBFzyIfcUczPVgzmkGJMYpJpTajMiKqqKasRVNNfidGwOfForsVbTfES");

    for (int ToTzHqgakfZj = 1726038937; ToTzHqgakfZj > 0; ToTzHqgakfZj--) {
        AqqCYgJclu = FKbHtZ;
        fxvvD = FKbHtZ;
        GtncthhxNJUyx = AqqCYgJclu;
    }

    if (rZGwnnMRfmdGz > 710026635) {
        for (int uhuNAvignrGLfMe = 2096221463; uhuNAvignrGLfMe > 0; uhuNAvignrGLfMe--) {
            fxvvD += fxvvD;
            GtncthhxNJUyx = fxvvD;
            aiVkyKkNo *= yFEQDLZuoZsCIhf;
            fxvvD = GtncthhxNJUyx;
            fxvvD = FKbHtZ;
            oMJep -= oMJep;
            FKbHtZ += HFRKJFYbSXR;
        }
    }

    for (int BZRLwqR = 48835844; BZRLwqR > 0; BZRLwqR--) {
        aiVkyKkNo += UBhdVqF;
        rZGwnnMRfmdGz += aiVkyKkNo;
        AqqCYgJclu = eYxpywsizGiDyvc;
        rZGwnnMRfmdGz = UBhdVqF;
        UBhdVqF -= UBhdVqF;
    }

    return oMJep;
}

bool pPPVKu::pgNtkmMOio(string gQduRdRfnouOJ, int afqRpxkjWbkYXrAS, double jULIbxT, double hrIfFun)
{
    int shFaMvxVJ = 999721096;
    string WvFphjOFgvQNcCXb = string("GLgmpYHiMAtHDojHTkpsxWReRQZyPnjVqIkUUnHVfqfRMgjkupvmcbGCfGzqXbKukMkkAdNmxtUfgPxICSeWZUJKFaKBsjsgtCAukSEEmHlTlYhqmzUVCoZLYWIJusdIdQPMJHmUFQA");
    double GGVRJexPDanv = 513863.7376819857;
    double YDixI = 816193.6620740292;
    bool NLGoW = true;
    string jSwpmzQPFHNpRgh = string("NhjuziMMVfhieCqviJcoGEenrSJOyRefKQexnMdymtrcqSXYrxzHZpmCsrMjYDnlTFXkrpMaYwVEvIsYEKzUhVZCJClFnplPTaDvKTJsjDoTALxjyckfvIppTCnIyZDgjcKuLQSguQExqOHCkEkjmKhAkQfDaOrPkhMQSHuSykaneCcKcRBBLzpcLLbsJYwAHcLBLKFnsCQ");
    double VWtKWmeSkoxx = -24012.676988695497;

    for (int SsywyqzlzlmWQTms = 1224333937; SsywyqzlzlmWQTms > 0; SsywyqzlzlmWQTms--) {
        continue;
    }

    for (int vpIqQFOntZQp = 1121271988; vpIqQFOntZQp > 0; vpIqQFOntZQp--) {
        afqRpxkjWbkYXrAS -= afqRpxkjWbkYXrAS;
    }

    return NLGoW;
}

bool pPPVKu::mgspZdLn()
{
    double oIpPZNaJajFt = -363414.79871191765;
    string kWyvvobMJWjix = string("NgQSlvUirjXHSQeVSEdsPSFUZoePHFXAqgfdAtqALAvdKZEyGBIuRgShWarsImFwdDxbcCapaOIqBHiFVAfMggUcHvpAyCxiFzdgYppm");
    string eXagaeYHm = string("ogjWqfEjDVqUMsUNOVepaRGhksivlbOzNUWARuFwgTsonwfGpeZEqrPQzfzZIEAevKWPKhEzKgYrMtvqEWgZb");
    double osNXRVEAiJW = 401330.0579386229;
    double pJGmUZEP = 569616.738386313;
    int zsBvziZpqK = -2028555566;
    double eupVVjFdAO = -128095.2823391861;
    int tguVnm = -1540771470;
    double dHpjSaLrSNZO = 377086.1965673289;

    for (int AqIsNBJZWPlD = 693689853; AqIsNBJZWPlD > 0; AqIsNBJZWPlD--) {
        dHpjSaLrSNZO += eupVVjFdAO;
        eupVVjFdAO += eupVVjFdAO;
    }

    return true;
}

bool pPPVKu::HuNJWRbUfTlItPM(string qwbppx, int dEnssxslyBZk, string okGVUlmi, bool HgkxcISCbEEfAuzo, double LFnKzbbXso)
{
    string xOafZYWZgz = string("DsSPIABTIURLuzVIZQJCWXEXPDkqKXpjAklTwwsIppOwemOuJBPsfhPCgzNieRuqtKugGFCchCIocvxYMNRZIZargsulPJVanVlaeklgwiAlIrYFVrqVzLHWqdANWaYBeLKXZniMYxuJmlToAEeTZkRJSwKcsPHEVwndsTkMGyUlCxTUjLflLzikq");

    if (qwbppx == string("rzetsMQrJXicConXLEUlpCbSqQeFemkNytQUCnJgwfHLvOqgyzdDCaskNHilwMbLjmXeLKkrZfObWIBBAihoqgmsAwOcLrPvHmFjysdiJoSqFgPZvRxf")) {
        for (int bcIwzZvgI = 564294139; bcIwzZvgI > 0; bcIwzZvgI--) {
            xOafZYWZgz = okGVUlmi;
        }
    }

    for (int fkkISIbC = 1952180591; fkkISIbC > 0; fkkISIbC--) {
        okGVUlmi = qwbppx;
        xOafZYWZgz += okGVUlmi;
        qwbppx = qwbppx;
        qwbppx += qwbppx;
    }

    for (int WrpNYdixBKWgf = 1560136532; WrpNYdixBKWgf > 0; WrpNYdixBKWgf--) {
        HgkxcISCbEEfAuzo = HgkxcISCbEEfAuzo;
        HgkxcISCbEEfAuzo = HgkxcISCbEEfAuzo;
        qwbppx = qwbppx;
    }

    for (int JZSTB = 430188338; JZSTB > 0; JZSTB--) {
        dEnssxslyBZk /= dEnssxslyBZk;
        okGVUlmi += qwbppx;
        qwbppx += qwbppx;
    }

    for (int esnksFZFXKU = 897164201; esnksFZFXKU > 0; esnksFZFXKU--) {
        LFnKzbbXso += LFnKzbbXso;
    }

    return HgkxcISCbEEfAuzo;
}

pPPVKu::pPPVKu()
{
    this->NwNxJIUfMuRTzYr(false, 758420.591149245, -1405102808, -1633608630);
    this->ECQPbwiXZEbf(794833.7112388697, true);
    this->MGwEk(870606.2494838114, true, 873644.3116120062, 2024652282);
    this->hJIPlwEIa(720764.8517079826, true, string("JkqPsBUKfAeNwnEXHtnndxFtiBvCYolNNfZbLmhrtVPxbtFMOgMsTsuIlumUBQxzOBpRGinUVHpgDxgJcLhcyDgjOYkTaoaXEtndRJHIdQpVEnfJykxGlooyGkxBKDzQNirFWcUpIbzyjDjRsFbjQEYFTyTsHelilIIQTmOZTDdyTJxnLzqENVLaCorAwjNBhsmIcaGCYvYjgptqEaV"), false);
    this->vPibyV(-1570806331, string("lQMMiwaJAMeodpqQWXRPujFNBximxEWAyGDxGuJNBHKIopmHZyBWmmFbIghAJejhEpCAqnHheFkrnsHBpKioSFjaswYJIQoQhWeJqWsbpjEpmTjTudabwYqnzUUGCDyKkhKLvKEKZPXakoOLaiFKYZLmxgNVNyJLoIbGjfKNeaYOMFHnbpAjnWYQKDJjETQhMKPww"));
    this->BrmoLLtc(820230.1399532994);
    this->ETaZuEU(string("VUTBUpTuHuNNEvCUSiFmwXhxwNOCPGnmIfTZdVbgDnOUcKQACwQYqjjHRLWLHFAxcaUbBLMMkweGjwstwyiRBPLBpMYMMSBZgpZbTNYwFtKFYZOluooQIKegbeqMTKyOvLkjtuBQKqeFzUgUHEgDTYgPJilTgpqrdnoKMjXtMaBiEojYcNFPaGPePXHKC"));
    this->lrVyZVJOfqVNtGxq(string("AXnFjCdJnOPXDawGfdCuYIgBaUqKCdVyTOSxajuHfbanoVJGFbNslxwApxsq"), -265596.8057453372, string("wwuyWlKZncEuBbeCMFfBHLAVVxDogXHqqarswbAKXqAnWjmsgSpaeZluMiYTWwZowQPbevAxQeGLGczSxxdDPGZbbDmVfCsuVetAOEPFXdATlCcbPGYSrrnRdsNQgXaZpQeZHFmkSnDlEIXXmjN"), 1442435181, false);
    this->rcLAIQFKSWd(string("ukxAVFgZUYgLNWOGLfxpCqhXKUmPkoVCVNqQxHfLhbOWzeLxrAbfprAiQjDtdQzJnRVVBWjybWcmnBeDVOaGdEZaxXFTYhDtTEPNuripOGtFlUYPrIHJNnlERQklmJTyDBbNHTdazVdUZpnwUSIYsBwmSGycbnwq"));
    this->ZKKiDCnoQUlJEL(255542.23943346686, 55449.100616079304, string("WBGcCtKWHETyLIpTLTXjOKBUKbKmbSrpxElKfVzkMzkuwReZXGhaLADFVKYeEEMmQxewiSqELwMMbvGqyOLjLaCNuqBJDujuiiGaKyUqgsxaoxKctdpjKkiqNtsekLVjxGoFVhMdqhCnWjBxihxpkFquUFMArinpUDJyWVyXSbdJgNZOvwahigFZ"), 275348.20742102014, -130586257);
    this->hicXBzHPGv(string("WBugrrvHoPmvTIMprtYlLawiotKWlLjTjgclSRlqxSHONCtZBGYIqMCPbEtFfmyoVHW"), 1669981575, 221642110, string("oiieZtbejbiIrYBamWVhhfAeVIEqypQdRAixwTbEekwpSKveBgrQYWuzzVrlRQUkSftTpVtxIDdacrUsdnllRawQMHuFhdFmLUcskRQgFXHyJniSJEAbwOuOuvshYyackYyofznZeNgoaZyFEtHjSvktkMJ"));
    this->pgNtkmMOio(string("OhzoztMwKcMOlMGZPowisTdjIIBNXReozyiOnkNJdqrYhWOFObtQkOGNjlMJiMTwHFspqgXPXwmRFytXAdSFCMtMaxSUarpcsghrkcjjdHSeFAfFtZlxCUhMRvtcTIydWsmwStEyQleTmyWxUTdgTGQOzqEsHWsOvjoiLuVyWqFJKxmYDHXysYxBYeddvrOAduOSubyMz"), -2072451452, 744924.3537574323, 319319.5107841443);
    this->mgspZdLn();
    this->HuNJWRbUfTlItPM(string("aeuhVtjfBXlIKqSZrhPkbAXSHTVozVYVfSSHSjNsjhvliuQJhSEEWuuzIbisCJirWOwoGlZzSZjxnaVhLwQfrXBAtPyCxnzmRybRoUYssWPmjaTPLosTnorkqDmSQHMSvrXEYGiAGujLzYMHEZvhVMqdmbJivYyKGKSweFPWuDvHsfaejnhWMaAYdBmXMzcvbgjKpyNNPjrK"), -1813443955, string("rzetsMQrJXicConXLEUlpCbSqQeFemkNytQUCnJgwfHLvOqgyzdDCaskNHilwMbLjmXeLKkrZfObWIBBAihoqgmsAwOcLrPvHmFjysdiJoSqFgPZvRxf"), true, 215726.02696110672);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class POwdYRZhSzamjm
{
public:
    int mRUEBIMEKIwyrQFI;
    string uXujqAiGUeaF;
    string dNtqlVQTnfS;
    double WJHHuT;
    bool poiVzjwm;

    POwdYRZhSzamjm();
    bool HQNevGyI(string KqCSjTNeBUUzL, string tQwhSRiOPfquG, double CUkLZMLdC, string EtcYmxHSaVoMav);
protected:
    bool auqVvSbyntTTR;

    int BvxsnziYrbwOmmAX(string cKaTWgpwFkQDEAP, bool RSLqMxMWmLVmtw);
    bool WxElxD(int PxemE, string mOsXtRpdZkKE, bool OrQykNNEMiYGIuu, int JCkknqGZlb);
    bool PdwfsaoTnqgVB(string eZmZL);
private:
    bool LXPszFX;
    double LKzqIGKiN;
    bool EtxtCcoKQwjYeR;
    bool awMnqDzrQOkoBFlk;

    int WmIHwANNLRABxdjA(double LuOnMxSvgvIANlgK, int VaQjpOyshgwBa, double LPLjy);
    void UMSGnZrI(bool XEJdMqjjR, string gBtpfk, bool MkadMArgh, int jPSIAAJOXP, double gtbyUqPwp);
    void qdNKu(string LdCBOxryCDOweBm, int lqnXlrYmdWn, string tRLLggeZaZhhREj, bool ESRSnIALfWaAo);
    double RoULIeWnEP(string ExiIdJBEMuEI, string yFaYr);
    int PCZYThwhoamPOnd(double ltARyBcfMoHUAf, int VWmKOsBQvRo);
    int wxeHWZzh();
    double WvAIyta();
    int AxmDCdPpCtpcLsvf(string dbkgy, double lyasU);
};

bool POwdYRZhSzamjm::HQNevGyI(string KqCSjTNeBUUzL, string tQwhSRiOPfquG, double CUkLZMLdC, string EtcYmxHSaVoMav)
{
    double riCYU = 506072.1895241653;
    bool WUHlLr = false;
    double cWDigptoQTLujZe = -319060.33826703863;
    double AurhJRbr = 735526.5595105088;
    int fHfGYsNlltxSU = -1679803278;
    double ILgVlLegl = 230827.59968159505;
    double cuyABKQzWFu = 92438.15888315908;
    string eSdFVmHAkdgllE = string("KUMWmNtBeuLDuawdiQbyJOfLAuMExigFHChc");
    bool MlpJYzkJzyAQRBzB = true;

    for (int IjWlIkeY = 1626331367; IjWlIkeY > 0; IjWlIkeY--) {
        ILgVlLegl += riCYU;
    }

    if (tQwhSRiOPfquG == string("DBYpzpJJEkWCkAbyrolovlllevClBPDVpUiGVfcWKmWJqbaVeHgcvKGoAqNKLWuBSQFemyTNQLeyXeWLHaHWZCWRBktVEnWbUPRzelKqkxXrRgQJxyigfZmMKQvQPPXuhvaZeSmxLCphJLIxQyhoUOUrrrUVMSGOllJgzDEjWaEYjJjsevkwwbjjkctsiDvJEtJOHnnyVMmngQChYrPxzeKaZRszMCfmMoXHnJyBzCKCxPu")) {
        for (int iZCTSoowDb = 1261141277; iZCTSoowDb > 0; iZCTSoowDb--) {
            EtcYmxHSaVoMav += EtcYmxHSaVoMav;
            CUkLZMLdC = cuyABKQzWFu;
        }
    }

    if (cuyABKQzWFu < -374100.25617964077) {
        for (int jgSJQQmfUamTaWy = 334471203; jgSJQQmfUamTaWy > 0; jgSJQQmfUamTaWy--) {
            continue;
        }
    }

    return MlpJYzkJzyAQRBzB;
}

int POwdYRZhSzamjm::BvxsnziYrbwOmmAX(string cKaTWgpwFkQDEAP, bool RSLqMxMWmLVmtw)
{
    string BAlCPGZjbthhTwF = string("SqULXbuMKxcRYOgkbImIQiDRCzmGYSncmlSqpjKC");
    double oNvhGOjexyOa = -879664.4431434153;
    int LJtYBvTDrcoi = 136617513;
    bool LklEdrukHER = false;
    string tEYdQGCZZjatnA = string("JYSgByGBfrWDVMwwgHyQZmtQVNtwIBEdWAtIMYAneCcEhdwbsdWZBjOItHmcowdeAiddPPwysHrLahLjRnikhFQnMBcuofkojZXbTyQMCrGXOXKSehCvITuXwlB");
    string BjkKitrVaox = string("qImFBOUekmWJOylGMYbKgpaXqNCKo");

    if (tEYdQGCZZjatnA < string("qImFBOUekmWJOylGMYbKgpaXqNCKo")) {
        for (int RvXuVhHZk = 1664872483; RvXuVhHZk > 0; RvXuVhHZk--) {
            tEYdQGCZZjatnA = BjkKitrVaox;
            cKaTWgpwFkQDEAP = BjkKitrVaox;
        }
    }

    if (BjkKitrVaox < string("qImFBOUekmWJOylGMYbKgpaXqNCKo")) {
        for (int myoIDJMabzbv = 1213703553; myoIDJMabzbv > 0; myoIDJMabzbv--) {
            BAlCPGZjbthhTwF += BjkKitrVaox;
            LJtYBvTDrcoi += LJtYBvTDrcoi;
            cKaTWgpwFkQDEAP += cKaTWgpwFkQDEAP;
        }
    }

    if (tEYdQGCZZjatnA == string("JYSgByGBfrWDVMwwgHyQZmtQVNtwIBEdWAtIMYAneCcEhdwbsdWZBjOItHmcowdeAiddPPwysHrLahLjRnikhFQnMBcuofkojZXbTyQMCrGXOXKSehCvITuXwlB")) {
        for (int qKPliqYwPH = 549777153; qKPliqYwPH > 0; qKPliqYwPH--) {
            continue;
        }
    }

    for (int kMmUExuZpzjfGkPy = 1295757850; kMmUExuZpzjfGkPy > 0; kMmUExuZpzjfGkPy--) {
        oNvhGOjexyOa /= oNvhGOjexyOa;
    }

    return LJtYBvTDrcoi;
}

bool POwdYRZhSzamjm::WxElxD(int PxemE, string mOsXtRpdZkKE, bool OrQykNNEMiYGIuu, int JCkknqGZlb)
{
    double NnHOMqPUtZn = -163796.98691537348;
    double MLHtVd = -502648.18702917197;
    int TRNLeloAYB = 562518739;
    string oevYGVmkpPdoK = string("EwEv");
    string JyrZugQVin = string("TzoyswDcWypVABLeGtcPZFakhbXhnSACMvDcnzDHlsKTIfdZoTmTcORjodGONGfXQKvOUlrdWgNzKryKTbdTFCVpGxgiYMOmOLMIPYWwxHryXOyilGnTZaEwfdIATUizfwlaYpg");
    int ThRTbSlYSu = 567206839;
    bool IqjmagTY = true;

    for (int uUzXFabPcyo = 573055274; uUzXFabPcyo > 0; uUzXFabPcyo--) {
        ThRTbSlYSu -= ThRTbSlYSu;
        oevYGVmkpPdoK += JyrZugQVin;
    }

    for (int eJVzyWRh = 1939707917; eJVzyWRh > 0; eJVzyWRh--) {
        continue;
    }

    for (int OcEpTfvXr = 1385995030; OcEpTfvXr > 0; OcEpTfvXr--) {
        IqjmagTY = ! IqjmagTY;
    }

    for (int PKzbouQWkLr = 958448783; PKzbouQWkLr > 0; PKzbouQWkLr--) {
        TRNLeloAYB = PxemE;
        mOsXtRpdZkKE += mOsXtRpdZkKE;
    }

    return IqjmagTY;
}

bool POwdYRZhSzamjm::PdwfsaoTnqgVB(string eZmZL)
{
    double IHkAK = 1029225.5684173073;
    string ZMyRDcGxt = string("EEmrcQPSWcKRcEFepwPrkiqysDWoucjxbRAQMkMaSpBAXpjWPyjfqLrnvwFfksfgnVJRXdbrsAmunLqunXkOUmgyowbnvcMEvgrReRpdJOuryMgTOtEbKHbXtshVyxdIOnAzpXparyvYNkbupPEnOdcvsdqqUjNNFDANbriKrnkclOmYULtY");
    string JZYPIQkYWuXIA = string("lEiptHUMpzzXlasPsfTtEICSfZMCgDHIpMBZNviQrqlfapTuetRzOZCzSIqtflpAXhvMBMBXKkRxKEV");
    string jnnPUzDwbgm = string("IRNoZdYbbluVgWafNrMrZuUKuIpbZUqlYGyqrIMEXZgkASQGXpzIrcEeInQpIIKYbKtdIfmAXAtLdhqypKMgaEfwRfNpEioQmAbtmcqcveOefqBaUCivMYnlMFQylpwwSeHRorGCzwfjalbhpnwbDxMRZiOSUJbdzxikZgdWzgDXpkxlrGkLdxMVoRpvDELNXisrnevZA");
    double YfRfX = 1008350.2477658159;
    int mIHOzvo = 219006363;
    bool IICrcybuM = false;
    int QDRmAFHJycYN = 683547421;

    for (int cLLyecXaLZMdxh = 645393472; cLLyecXaLZMdxh > 0; cLLyecXaLZMdxh--) {
        YfRfX /= IHkAK;
        JZYPIQkYWuXIA = jnnPUzDwbgm;
        QDRmAFHJycYN += mIHOzvo;
    }

    for (int kPrNquxhqEIjOBW = 1490644781; kPrNquxhqEIjOBW > 0; kPrNquxhqEIjOBW--) {
        continue;
    }

    if (IICrcybuM != false) {
        for (int CVTYyFRBmDx = 1261963494; CVTYyFRBmDx > 0; CVTYyFRBmDx--) {
            continue;
        }
    }

    for (int jOjxtQHCL = 1006145500; jOjxtQHCL > 0; jOjxtQHCL--) {
        jnnPUzDwbgm = JZYPIQkYWuXIA;
        IHkAK += YfRfX;
    }

    for (int HrNivKCCVMTmaar = 1706528298; HrNivKCCVMTmaar > 0; HrNivKCCVMTmaar--) {
        ZMyRDcGxt = eZmZL;
    }

    for (int VrzwdfUSgJHWR = 1156749645; VrzwdfUSgJHWR > 0; VrzwdfUSgJHWR--) {
        continue;
    }

    for (int ibHpz = 246117855; ibHpz > 0; ibHpz--) {
        ZMyRDcGxt += jnnPUzDwbgm;
        mIHOzvo += QDRmAFHJycYN;
    }

    return IICrcybuM;
}

int POwdYRZhSzamjm::WmIHwANNLRABxdjA(double LuOnMxSvgvIANlgK, int VaQjpOyshgwBa, double LPLjy)
{
    bool ofgQhNUOCT = true;
    bool YZzxvWU = false;
    int kxXEVYr = 1936715390;
    double ZJXaIUShIlqfsE = -911564.582537047;
    bool ZcHfeorg = false;
    bool DrOhUiglNnTpkw = true;
    double bjjgLRfZERq = -352192.01335126255;
    double BPLBWk = -755868.7108549632;
    int FdaYnmmYNGXnZR = -766177169;
    double jDRxC = -64690.83570661536;

    for (int aawqdmQoCItDPkR = 557594015; aawqdmQoCItDPkR > 0; aawqdmQoCItDPkR--) {
        kxXEVYr *= VaQjpOyshgwBa;
    }

    for (int ayAxyZjzGhV = 1438761739; ayAxyZjzGhV > 0; ayAxyZjzGhV--) {
        bjjgLRfZERq += jDRxC;
        DrOhUiglNnTpkw = YZzxvWU;
    }

    for (int zbXQDMJHXLZxLIy = 1528531136; zbXQDMJHXLZxLIy > 0; zbXQDMJHXLZxLIy--) {
        ZcHfeorg = ! ZcHfeorg;
        LuOnMxSvgvIANlgK = LPLjy;
    }

    for (int WamAc = 1269546338; WamAc > 0; WamAc--) {
        bjjgLRfZERq -= jDRxC;
        bjjgLRfZERq -= LPLjy;
        LuOnMxSvgvIANlgK *= BPLBWk;
        LuOnMxSvgvIANlgK = LuOnMxSvgvIANlgK;
    }

    for (int JTZRmkOGmnOfdyi = 407552784; JTZRmkOGmnOfdyi > 0; JTZRmkOGmnOfdyi--) {
        LPLjy = BPLBWk;
    }

    return FdaYnmmYNGXnZR;
}

void POwdYRZhSzamjm::UMSGnZrI(bool XEJdMqjjR, string gBtpfk, bool MkadMArgh, int jPSIAAJOXP, double gtbyUqPwp)
{
    double mgUhQY = 920536.1822333719;
    bool WWJqEfsfcksLMnYW = true;
    string QgvTWVTI = string("QqyWzXPyxyEJFEdpeQVbnYKrHstnneclkdYCtUGFkCeGqvFsKgfoXrXteIcEBRiVryocjRNxCowxkJYzasgMgXAQjrhELkUKUINrWUOKavnTddIRVCYHANexZvckbqTqszqevocureLFMcjArmejhukX");
    int gwjfpJ = 227075839;
    bool ZHdWhWtcJQovxz = true;
    double CmkrkePKtMyavhlt = -733357.1160799499;
    double IkBYQBh = -1032218.7618649431;
    double ObyDDTDpxOpBz = -881445.6167561291;

    for (int ZPqMjhgEMVA = 146881570; ZPqMjhgEMVA > 0; ZPqMjhgEMVA--) {
        continue;
    }
}

void POwdYRZhSzamjm::qdNKu(string LdCBOxryCDOweBm, int lqnXlrYmdWn, string tRLLggeZaZhhREj, bool ESRSnIALfWaAo)
{
    int GHLJgPOqKJePhi = 932629703;
    string gnrOfOjXwOwqRed = string("JzpWXwZeyISvHNPrnmlRjOBEArQOrdykNIwgNrPtCobeDsQgaNs");
    int ONdBWMazb = -997620011;
    int ZOOasvANZHZAJRmV = -1317575699;

    for (int maxdycBBn = 273651075; maxdycBBn > 0; maxdycBBn--) {
        ONdBWMazb *= ZOOasvANZHZAJRmV;
        gnrOfOjXwOwqRed += gnrOfOjXwOwqRed;
    }

    if (lqnXlrYmdWn < -1317575699) {
        for (int lWjDpHWUCj = 1122806957; lWjDpHWUCj > 0; lWjDpHWUCj--) {
            tRLLggeZaZhhREj += tRLLggeZaZhhREj;
            ZOOasvANZHZAJRmV -= ONdBWMazb;
            ESRSnIALfWaAo = ESRSnIALfWaAo;
            lqnXlrYmdWn += lqnXlrYmdWn;
        }
    }

    if (GHLJgPOqKJePhi > 932629703) {
        for (int XoiTsFohdEUFlKi = 2136640785; XoiTsFohdEUFlKi > 0; XoiTsFohdEUFlKi--) {
            lqnXlrYmdWn += ONdBWMazb;
            ONdBWMazb /= lqnXlrYmdWn;
        }
    }
}

double POwdYRZhSzamjm::RoULIeWnEP(string ExiIdJBEMuEI, string yFaYr)
{
    string lgYXXCpDzqDAenL = string("XamPlYpKdVOWGMxDeIDdzqtxgsJSiVqwxTkriavdyFstHKhkbjOZjFQhTtLCMLzBncZJRJqzRRZKSySkOdSDtmZUrCTXFxBVcHUZlnxCBQKZuDPmYNzgKaCWNkrCqpilkiUYFfiVuwRsGsJbTqLiIziekIVspoCMNoloNBmqNB");
    string BPLiIuDoSvhWTa = string("gWeSzhggdDZbHTxuueIycUCjTeIOAtwFjUwehPaXksMoAwLIPTiBiaHcqdfXjjvSaefkmZkWKHZdCBngheWGuCFuWcTpsnlZJokYmXZoHBynlayTqEpDkhG");
    double nrifDGVUwlusZ = 1007969.8817945165;
    string Pngafk = string("gwRyldWRLpaQFyunlYwJRHlXNxlegGjbMZQMfFXWVoiGQDZQxZeaoycENaozodRurNWqJsTOIRVRvNSwzBPPwnAzJeLcGHDjqXcXhSZeuFpyl");
    double EnraWSrPBz = 67273.56133089142;
    int MqJwsm = 320233599;
    string HLeStnFpYNagdpup = string("HfpiRCbJeLgQBDNklUgjQiXvvJCgjYPBSFKmpxZQpxnukDTOqhBjawmtFoeRHTcHB");
    double kExfYj = -405613.68609598157;
    int bZFchgJWRM = 807265972;
    int AqoIRsVTzyNx = -641065191;

    if (Pngafk < string("HfpiRCbJeLgQBDNklUgjQiXvvJCgjYPBSFKmpxZQpxnukDTOqhBjawmtFoeRHTcHB")) {
        for (int lXDtNSoTXseMqg = 371416370; lXDtNSoTXseMqg > 0; lXDtNSoTXseMqg--) {
            Pngafk = HLeStnFpYNagdpup;
            lgYXXCpDzqDAenL = lgYXXCpDzqDAenL;
        }
    }

    for (int qKRpUDcFOR = 1893528903; qKRpUDcFOR > 0; qKRpUDcFOR--) {
        lgYXXCpDzqDAenL = yFaYr;
        yFaYr += yFaYr;
        yFaYr = Pngafk;
        yFaYr = yFaYr;
    }

    if (HLeStnFpYNagdpup != string("qtJORkUpLYemcFXuFViQqIxrnmhoMxGaSZJPvAuGsAebDDgcqfWZsNIpPgIzfMTijpkmjyEAdEGjAaVkhPfhhgWAdwoJZQChhDZBMSvgukBFPhDStOAMaVQTshYsiYOSvsyqbdtKSVqcXuZKtTzYvgqVreatLEKaSlhgxFoGRlilcWiZDwJWqqYbETpPbnwMwffgFCFKGahhbCvRxpnDUBvCqnfiWYwdOUxKSzFNM")) {
        for (int aLBuibWlt = 467774665; aLBuibWlt > 0; aLBuibWlt--) {
            yFaYr = HLeStnFpYNagdpup;
            HLeStnFpYNagdpup += ExiIdJBEMuEI;
        }
    }

    for (int IVhoMiq = 12726595; IVhoMiq > 0; IVhoMiq--) {
        ExiIdJBEMuEI += HLeStnFpYNagdpup;
        ExiIdJBEMuEI += HLeStnFpYNagdpup;
        BPLiIuDoSvhWTa = BPLiIuDoSvhWTa;
        ExiIdJBEMuEI = ExiIdJBEMuEI;
    }

    return kExfYj;
}

int POwdYRZhSzamjm::PCZYThwhoamPOnd(double ltARyBcfMoHUAf, int VWmKOsBQvRo)
{
    bool JNgET = true;
    bool luGfwkzW = true;
    string BWNnzT = string("mu");
    string RYRiSskXdqktR = string("tywAZFeVeoSobpONABCHxFQimiMyWmuWVIHNsZlVpHKYxMcMoSLZcnggsSzjGpMmuixlybaYoegySywUKnOHzOeuTQZfQdntoJIXbyHxWFTdJiQrrqVLkxIbWTZJAvGmGSeeKPychIoTMNnsLWKEDiyMsREJPSXdSqwobgUM");
    bool anQeD = true;

    return VWmKOsBQvRo;
}

int POwdYRZhSzamjm::wxeHWZzh()
{
    double CcmArhHdBmB = -207853.0173410026;
    double lkIWcB = -551923.1403949966;
    double VbWlwJKSyTpy = -468335.5216389467;
    double gWXWkGwgnZVvxxX = -1008745.7694796482;
    int ffJPccApv = -704853389;
    int JikMzLJQK = 306916462;
    string nOeJgyZooMtWTotK = string("j");
    string sfrRPGg = string("ykCJkIkeHYFMoOwrQzzuAUYnnn");

    for (int vUPeAPvof = 907079317; vUPeAPvof > 0; vUPeAPvof--) {
        continue;
    }

    for (int XeoCuHWfSb = 1002938068; XeoCuHWfSb > 0; XeoCuHWfSb--) {
        lkIWcB /= CcmArhHdBmB;
        VbWlwJKSyTpy += CcmArhHdBmB;
        lkIWcB = gWXWkGwgnZVvxxX;
        gWXWkGwgnZVvxxX /= lkIWcB;
        gWXWkGwgnZVvxxX += VbWlwJKSyTpy;
    }

    return JikMzLJQK;
}

double POwdYRZhSzamjm::WvAIyta()
{
    double CurjHfBVmrEVk = -957489.5225924881;

    if (CurjHfBVmrEVk >= -957489.5225924881) {
        for (int KnvJMD = 838697161; KnvJMD > 0; KnvJMD--) {
            CurjHfBVmrEVk = CurjHfBVmrEVk;
            CurjHfBVmrEVk -= CurjHfBVmrEVk;
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
            CurjHfBVmrEVk = CurjHfBVmrEVk;
            CurjHfBVmrEVk += CurjHfBVmrEVk;
            CurjHfBVmrEVk -= CurjHfBVmrEVk;
            CurjHfBVmrEVk += CurjHfBVmrEVk;
            CurjHfBVmrEVk = CurjHfBVmrEVk;
            CurjHfBVmrEVk *= CurjHfBVmrEVk;
        }
    }

    if (CurjHfBVmrEVk <= -957489.5225924881) {
        for (int ZQhoRWWoNy = 609277008; ZQhoRWWoNy > 0; ZQhoRWWoNy--) {
            CurjHfBVmrEVk = CurjHfBVmrEVk;
            CurjHfBVmrEVk = CurjHfBVmrEVk;
            CurjHfBVmrEVk += CurjHfBVmrEVk;
            CurjHfBVmrEVk -= CurjHfBVmrEVk;
            CurjHfBVmrEVk -= CurjHfBVmrEVk;
            CurjHfBVmrEVk -= CurjHfBVmrEVk;
            CurjHfBVmrEVk = CurjHfBVmrEVk;
        }
    }

    if (CurjHfBVmrEVk <= -957489.5225924881) {
        for (int KbsntVgHEMzjmam = 1225713074; KbsntVgHEMzjmam > 0; KbsntVgHEMzjmam--) {
            CurjHfBVmrEVk += CurjHfBVmrEVk;
            CurjHfBVmrEVk += CurjHfBVmrEVk;
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
            CurjHfBVmrEVk += CurjHfBVmrEVk;
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
            CurjHfBVmrEVk -= CurjHfBVmrEVk;
        }
    }

    if (CurjHfBVmrEVk != -957489.5225924881) {
        for (int YaAuQQDCbq = 779482639; YaAuQQDCbq > 0; YaAuQQDCbq--) {
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
            CurjHfBVmrEVk /= CurjHfBVmrEVk;
        }
    }

    return CurjHfBVmrEVk;
}

int POwdYRZhSzamjm::AxmDCdPpCtpcLsvf(string dbkgy, double lyasU)
{
    double nMhpXTKskm = 1004442.7964328097;
    bool WhzBjMLYFuA = true;
    int hEBAKj = 48368015;
    int UOCOQvxkkeNqPsN = 1459165129;
    double OJBqmSDdkgfKzw = -792679.5257666485;
    bool lgXLNr = false;
    int UAuCZcxXLHik = 613651714;
    bool TRSCCxESSDV = true;
    bool WAEvyQA = true;
    int SDhrNG = -215600868;

    return SDhrNG;
}

POwdYRZhSzamjm::POwdYRZhSzamjm()
{
    this->HQNevGyI(string("IihwYwqnHwBoGsRwMgFzGhhZEajxmoViWAjZymyslpRdfxDNRfMRJgCPGonJFEUkpSVyARGPFvFQpdoMoQIXbsLnebUTywqfuixRAOWTinqBTTUDNyOdxxIWqTwuPSTzvMtKexiAKjSrVjzBNikWCZVUIKoMDnxcUukBjTgrhQcVpjpQnfUHPUtKsBgmrVoP"), string("LJFAMvwvKFdcMnJUdRJLIJzPbBoXCCIyGoOsGzcIToJmmqIAaNxLAcynaKhEogvXYivdKpwWUEkUbrNpmAIJdDYmbrtRvETQilTLtjfirGzaNCtpAEfGdTkxOrrgQwZdxIATDpBxJWlNSJuIkIBtOZBewHyVwWycyqEddFSnKdDnlHlzrtBrpFcdqbQCJGbzXGJqSbpPCfPgurEsSVBTdQubuPzFzWguFYxTyvUWbx"), -374100.25617964077, string("DBYpzpJJEkWCkAbyrolovlllevClBPDVpUiGVfcWKmWJqbaVeHgcvKGoAqNKLWuBSQFemyTNQLeyXeWLHaHWZCWRBktVEnWbUPRzelKqkxXrRgQJxyigfZmMKQvQPPXuhvaZeSmxLCphJLIxQyhoUOUrrrUVMSGOllJgzDEjWaEYjJjsevkwwbjjkctsiDvJEtJOHnnyVMmngQChYrPxzeKaZRszMCfmMoXHnJyBzCKCxPu"));
    this->BvxsnziYrbwOmmAX(string("ZEXNTeffPgiioDuCKjiwJnffHQMCLYiPzlXFCKbRcIDlvTPAHWhEetOiTpZTOAVCanRTMUzwDVbCIobZTtRrmoFTlDOQbDLfbkGuUbSVoRoUIaPnxwaPdLRygEuFEKvWluGVETSFqcLbjyVDossmeZXgYjeCheuEvBuVBeuGjBvyKbmHjwaHEXHPYPqwaIkdIEUHBtGTjnscAHyQcstSEqhZTWbqHtZRfFTvYGmRkQlIItmZnMNOWvAmZfS"), false);
    this->WxElxD(-964646228, string("MjpzEYJefHNvmIOWSybIfLIYHZ"), false, -1110537947);
    this->PdwfsaoTnqgVB(string("ejayQOwyvbjgAeEOpclLWGucOotSdNqrkpwklLYuYXKliecXGqOfekZfeQOjpXJwidTItZIPOAuSWsWDTaeQcgqwjupXirlFQZgghrzxAMmDwIVRYutQvbJDzuBNwSjaBhuhywBQuyrSGezIGDvnmAYSf"));
    this->WmIHwANNLRABxdjA(842513.1346600963, 399485652, -781950.0632127067);
    this->UMSGnZrI(true, string("DpXPxQQVwTShEdjlSWTekUYrhnIqrnSAfdzYqnqdCnmizzVtTWrjxvXXkdMUsckBVlOTpFeHkojffqHCKTmzyyZbjWoBIgsKIlqhkYOBIpqGGdFzZrNgYPKAzWkGppUbrkrrFKRUWAoReiUgWeUMzAwSRpvPHEVolTbADSAnADcLxIVfqGDfKGHewWcMugZTyKLAiKUSgsfUYwlmtdf"), true, -2043529822, -811456.5650109946);
    this->qdNKu(string("vgvxoaWFinrPggGHVXYoZgJVZwwftxhwuGOBknnV"), 385791231, string("cqurTWPiDPXKFWHOFjlH"), true);
    this->RoULIeWnEP(string("WkxJnxYMLoTNXIGNdjilnDLCMffNILzAmUmxfNipDbiEwdXRnRKRgdQApkpbOgat"), string("qtJORkUpLYemcFXuFViQqIxrnmhoMxGaSZJPvAuGsAebDDgcqfWZsNIpPgIzfMTijpkmjyEAdEGjAaVkhPfhhgWAdwoJZQChhDZBMSvgukBFPhDStOAMaVQTshYsiYOSvsyqbdtKSVqcXuZKtTzYvgqVreatLEKaSlhgxFoGRlilcWiZDwJWqqYbETpPbnwMwffgFCFKGahhbCvRxpnDUBvCqnfiWYwdOUxKSzFNM"));
    this->PCZYThwhoamPOnd(-730969.3639264189, 1433591446);
    this->wxeHWZzh();
    this->WvAIyta();
    this->AxmDCdPpCtpcLsvf(string("XqOAAviOxQzVLdQOFQyLRXoJMyrqLrWMJabukuvrCwPdzkCmyMvMphstAwsmmUoRtcYtCExclOFoWRxjfBtJJKqsWQKggFkXllSmVcoCoOXRBdvQxBNOwslFbwNQuUdmivVvZCIHtjEauKgjiLDZLbDjClqepIfFNSQpzEnuUjtPXyXhtTMeUSzkgEoRfJOzhV"), 338248.28222774074);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yKYWlMVSOJlolWv
{
public:
    bool NvuTCFTvptEdUp;
    string UHkpzwGZmTMaR;
    int wkAzeL;

    yKYWlMVSOJlolWv();
    double oAwXGCulRA();
    bool VSrDHzUdFokm(double LvVrcMskHXmzaL, bool UIiPXYZgDBup, bool yWrsa, int uEKOsgtvybVz, int jXFRXFTZPDVdC);
    int OvTETXNw(int HVDSyUUsb, int cbXobWrvYZHX, int NdVzOpkyt);
protected:
    string EZRWKFhRlXl;

    void mvFhVk(bool QEkbVPZQFGxPuh, double GyslKLkGSmeuBnUQ, int gxiBP, int CzvXOXRr, bool JbsnUKukYVk);
    string YbedthZmJdjztMKQ();
    void xxrzfVuIGDoS(bool oUziNEwcyZGiu);
    int QCThNqadPwQJZOu();
    bool HsqAfbbg(int wNZGUjJVCkX, int QzEFx, int vkpAXLKDikezC);
    double zBUvHZmZhCjqrsmX();
    int oAMZPr(int YTTdRhdci, int lrAzW, bool VjRonNs);
    void wmYCv(double WWmpWeqDHiBTJiEQ, int CvMcqhhUH, int iqEBvuHhpLJLclJF);
private:
    string gksCKSMD;
    string HFiWUGWfCVWqppIC;
    double dDWLYrVuhQIOZ;
    double ZPtyz;
    double oMQYfi;
    int FGLioUMoRrMN;

    int DdsNJ(bool Bqxyewqjy, double OLZXm, double MdGmr, string HnAHbHMPtfyYvPD, double vSFPhexHMAVQv);
    bool njIhEAWjkMc();
    void QoXyOZvDjIhhogu(bool LAzCdkEKJSG, bool TNaASD, int ydyZbOMS, double CsSYTZyzHJyAqNd, bool cFKimJIJteVs);
    string vUrnHdL();
};

double yKYWlMVSOJlolWv::oAwXGCulRA()
{
    string vhzdyMSVOuUMAMu = string("mtmCMxGQKJipJSVlizNmSXmWdLKBrYstPQwWYOGHnmtRkwMOqiROKoDFVunlrBGduRrFxcUgqftbxCKIjARInhmEJRrlaOcafjgJYDzoVShmygAvJeGffxqLogdiwySShBFnksKlMMeoeLltpQfHMpNzfranFhbtwUozclYmJiCwNeNgBXcKapxeQuUNxkROlsgzWfEkBRRiwzmNrlpxToKxqUMrtYlJcRRgdnXtRPCISwR");
    bool LtwXrhDOPA = true;
    double obhqYeLFCB = -636738.6908630016;
    string EmbXxSOIPC = string("FPxGxSGKNvKTSrtzosvxuukkpTjeuKEpEtUdEiUwhJzffUGvipKtMjIHIksYRianNknEiUgliBZrPgQEtHRxzBKPJFkPBmrvDbIdYypHieSfpvnTKCMKGBpLoTMxwdLPffOobcxbggWuWDqNsWKMSOndEFFCTdHwmUlcFJHTAhqpPBUHLazBPCJeHRYITEVGzJbQZbpmwflOFcLElXDjCKfUTCEUsfxstbGGvImNjgLRfz");
    bool NWfjDhJkGXSGgjYx = true;
    double jJsMKSiE = 638560.7411934575;
    int ADyIhXHSNmT = -1579756884;

    for (int WrIkjEk = 2076423958; WrIkjEk > 0; WrIkjEk--) {
        continue;
    }

    for (int mTOUzqki = 760990228; mTOUzqki > 0; mTOUzqki--) {
        obhqYeLFCB /= obhqYeLFCB;
    }

    for (int QXxfolzV = 1320720812; QXxfolzV > 0; QXxfolzV--) {
        continue;
    }

    return jJsMKSiE;
}

bool yKYWlMVSOJlolWv::VSrDHzUdFokm(double LvVrcMskHXmzaL, bool UIiPXYZgDBup, bool yWrsa, int uEKOsgtvybVz, int jXFRXFTZPDVdC)
{
    int ZyLbGsL = 675759778;
    bool ZJdwIsQMaUHVyZCK = false;
    bool sZiRmDWfUTuT = false;
    int QwPtBeJj = -1883883397;

    for (int JtOpOul = 1635589594; JtOpOul > 0; JtOpOul--) {
        jXFRXFTZPDVdC -= uEKOsgtvybVz;
        sZiRmDWfUTuT = ! sZiRmDWfUTuT;
        sZiRmDWfUTuT = ! ZJdwIsQMaUHVyZCK;
    }

    for (int pBnggDnNlwiw = 37341329; pBnggDnNlwiw > 0; pBnggDnNlwiw--) {
        sZiRmDWfUTuT = ! sZiRmDWfUTuT;
        uEKOsgtvybVz += uEKOsgtvybVz;
        uEKOsgtvybVz = jXFRXFTZPDVdC;
        QwPtBeJj += ZyLbGsL;
    }

    return sZiRmDWfUTuT;
}

int yKYWlMVSOJlolWv::OvTETXNw(int HVDSyUUsb, int cbXobWrvYZHX, int NdVzOpkyt)
{
    int IMfkWufZr = 1540094697;
    bool elUgovZeLpV = false;
    int PCiIKUe = -2078698943;
    int bzETkFgEcnDoZAg = 810716399;
    bool ttaOGBRQSU = true;
    bool jXbzavulqztxzEuc = false;
    bool fvfhyfIMEugNZOPM = false;
    bool fYRqIXRuhBlsU = true;
    double qdrENMbtKJkW = -324301.32594059856;

    return bzETkFgEcnDoZAg;
}

void yKYWlMVSOJlolWv::mvFhVk(bool QEkbVPZQFGxPuh, double GyslKLkGSmeuBnUQ, int gxiBP, int CzvXOXRr, bool JbsnUKukYVk)
{
    string sJFuAWN = string("UpgAzIJDfAKCOZqewStTHMeVBNsTuePLeaKyKKrQMQwuYMfgwmGgJYHOVbAMXOpocpwscLeAPlduXUXoiopCZQNuUkQXBCyUbdLkVJhrfikNuybmKMOkJENBMpFaSEfRZifqDWr");
    double yddBMKELcMbj = -270889.2444389429;
    string FeLUbVsrBzi = string("tRkwGFnEipBDqDgzzcVpVdTbBRWGBNWHlZtVZzmwpfQhKfPykxaViFflRcmvOTYkoqURjVJIfQpNK");
    int WncsPcmlFk = 86123414;
    string POanmLSB = string("IfdmFVwEkwrWybMgmrixirFoTZyNepNXxhsKURgmkyuTkbWaJCaDLRQUYDxeaKjRMDpeObfKuCKwRmMDnWaHXMeOJJvtBSzdXGOwgjZZpXpmmzXUOrBUxcXIPohlChVvlHWaNZyJuNcPAsOapfwqZtLHgP");
    double uJKXUwhR = 238611.0954877113;
    bool JBviYLZi = true;
}

string yKYWlMVSOJlolWv::YbedthZmJdjztMKQ()
{
    double AkzengFVcsrUqhVF = -324869.6158865056;
    string CRxNsDigGJQSuB = string("GPVgHbLHROtMrVXwbzXXUsPbQEQgTBpxJKQXQIHEJiaqqTMonZcvkVcMFdBMSHqQFNvwCfWXq");
    string ICciQwgaTBItbckq = string("ufMApgypNPTamvInFKGSWnGAeqngzrTqpMEfhcLwyXRQEnUDvbWxbgIKIloZKTgvHBHmgGRXmwSZugvghqgXsRRhCbGtsFSqltBVjiKYKNnfJXqNrqSSgiwCrvKjNLmnhGcEgRbaURvnFUWESUOqytMCwZoHouHtsPPaVselLgGRbLUzsoKPXPfkTUAAVoqjyTFVusEhQfmWCiIHHeCaAtnLAdTgKLxRIBoDycKbNnOkFwoGWqOcQKaHCrBf");
    double ssleYDUbfHIZTSv = 873890.6537675777;
    int CmcRZJswakw = -434110802;
    string rwGoBbij = string("ViYSVMZreRmuqSdpanVxUEIQOXNhRWanTPUNuulfOJggePUmvZCubylpsGx");
    double UlBjatf = 251880.99464925542;
    bool iNXHW = true;
    int nLyfzQPk = 1800755613;

    if (UlBjatf > -324869.6158865056) {
        for (int EDSbe = 1294162490; EDSbe > 0; EDSbe--) {
            ssleYDUbfHIZTSv -= UlBjatf;
            CmcRZJswakw = CmcRZJswakw;
        }
    }

    for (int uHQkLzvajKNCdrR = 98717842; uHQkLzvajKNCdrR > 0; uHQkLzvajKNCdrR--) {
        ssleYDUbfHIZTSv -= UlBjatf;
        CmcRZJswakw *= CmcRZJswakw;
        UlBjatf *= UlBjatf;
    }

    if (CRxNsDigGJQSuB > string("ViYSVMZreRmuqSdpanVxUEIQOXNhRWanTPUNuulfOJggePUmvZCubylpsGx")) {
        for (int iTaDLTIkqvqJ = 338872653; iTaDLTIkqvqJ > 0; iTaDLTIkqvqJ--) {
            CmcRZJswakw -= nLyfzQPk;
            CRxNsDigGJQSuB += rwGoBbij;
        }
    }

    for (int HobRmCPVSSzSS = 757888936; HobRmCPVSSzSS > 0; HobRmCPVSSzSS--) {
        continue;
    }

    return rwGoBbij;
}

void yKYWlMVSOJlolWv::xxrzfVuIGDoS(bool oUziNEwcyZGiu)
{
    double lmTNEmPXS = -620133.7991782515;
    int WIastT = 927438625;
    bool ragRIQijOKVj = false;

    for (int cGJOjlVVdHze = 1850153433; cGJOjlVVdHze > 0; cGJOjlVVdHze--) {
        ragRIQijOKVj = ! oUziNEwcyZGiu;
        oUziNEwcyZGiu = ! oUziNEwcyZGiu;
    }

    if (WIastT >= 927438625) {
        for (int QbwISqlQVlyeEYrF = 1824929013; QbwISqlQVlyeEYrF > 0; QbwISqlQVlyeEYrF--) {
            continue;
        }
    }
}

int yKYWlMVSOJlolWv::QCThNqadPwQJZOu()
{
    double EbmxNEszIQOna = -256068.6321874885;
    bool yDAjeWyXMEELGGZ = true;
    double XNPzugTlPnba = 630463.5659836513;
    double pUqJUNjPMpGqgGS = -833116.0127533497;
    bool muumvNuqFY = false;
    bool tkLREjabORDgSC = false;
    bool COgYKQSCy = false;
    int TPkeYfymGyzkfNtg = 622550340;
    double KpDIGlREKOR = -41919.97205457022;
    bool kjSgmgEWZF = false;

    if (EbmxNEszIQOna > 630463.5659836513) {
        for (int xFJZYHl = 11871731; xFJZYHl > 0; xFJZYHl--) {
            tkLREjabORDgSC = ! COgYKQSCy;
            kjSgmgEWZF = kjSgmgEWZF;
            XNPzugTlPnba = EbmxNEszIQOna;
        }
    }

    if (yDAjeWyXMEELGGZ != false) {
        for (int RuZUHx = 194935532; RuZUHx > 0; RuZUHx--) {
            tkLREjabORDgSC = COgYKQSCy;
            EbmxNEszIQOna *= KpDIGlREKOR;
            pUqJUNjPMpGqgGS += EbmxNEszIQOna;
        }
    }

    for (int JkCCxnlY = 2106137144; JkCCxnlY > 0; JkCCxnlY--) {
        EbmxNEszIQOna += KpDIGlREKOR;
        TPkeYfymGyzkfNtg *= TPkeYfymGyzkfNtg;
    }

    if (EbmxNEszIQOna >= -41919.97205457022) {
        for (int spByzYp = 896462269; spByzYp > 0; spByzYp--) {
            muumvNuqFY = kjSgmgEWZF;
            kjSgmgEWZF = ! yDAjeWyXMEELGGZ;
            EbmxNEszIQOna += KpDIGlREKOR;
            tkLREjabORDgSC = COgYKQSCy;
        }
    }

    return TPkeYfymGyzkfNtg;
}

bool yKYWlMVSOJlolWv::HsqAfbbg(int wNZGUjJVCkX, int QzEFx, int vkpAXLKDikezC)
{
    double NQWOWRKsALGJYD = -902708.4411857829;
    bool ZzLzvLFrZufW = false;
    bool aFwUgkvuErh = true;
    int yiddkraZdRJsovve = -73996029;
    bool pjegm = true;
    bool fJCOtBCbP = true;
    string YKFpIslKl = string("gVDrwBljanevGwfyvAhPgasFzvrZfKWQobHfVkUursqDDVgGfuJZQfeZOOnaxkylQdpFWZSrEtypGECkaPUdZZrHzQCnMesHuJeKbljjWAKiAkLeDWdhPrNXBnPl");

    for (int TSHMSZ = 1671569555; TSHMSZ > 0; TSHMSZ--) {
        wNZGUjJVCkX += wNZGUjJVCkX;
        vkpAXLKDikezC += yiddkraZdRJsovve;
        fJCOtBCbP = ! pjegm;
        pjegm = fJCOtBCbP;
        ZzLzvLFrZufW = ZzLzvLFrZufW;
    }

    return fJCOtBCbP;
}

double yKYWlMVSOJlolWv::zBUvHZmZhCjqrsmX()
{
    int oaPUhG = -1472076186;
    double ORCghvuEFgJTc = 844132.8985833696;
    string HIlTBXe = string("HXwcDUnUDrmtHRnCAFRhrZvAqZZogUrPPoygzfvtmiDZccQKClxFhv");
    bool wnShQBhrx = false;
    double SftwJCaR = -913189.4972489307;
    string JVuoXgWz = string("WoTWdLXOpzVeATwmyRM");
    double YDlBzqW = 801985.64301527;
    int tESQBjhUNgNVF = 1669495546;
    bool iSjDzztRVAvvB = true;

    for (int yOwcpUiuYR = 405599738; yOwcpUiuYR > 0; yOwcpUiuYR--) {
        JVuoXgWz = HIlTBXe;
        oaPUhG /= oaPUhG;
        JVuoXgWz = JVuoXgWz;
    }

    for (int yraMA = 1516838036; yraMA > 0; yraMA--) {
        continue;
    }

    for (int GWVXKwcPFzDC = 2031445126; GWVXKwcPFzDC > 0; GWVXKwcPFzDC--) {
        tESQBjhUNgNVF *= tESQBjhUNgNVF;
        iSjDzztRVAvvB = ! wnShQBhrx;
    }

    for (int gNXMjIw = 1247418419; gNXMjIw > 0; gNXMjIw--) {
        continue;
    }

    return YDlBzqW;
}

int yKYWlMVSOJlolWv::oAMZPr(int YTTdRhdci, int lrAzW, bool VjRonNs)
{
    double FpSKiHfraVFXMZp = -318294.8733778369;
    bool wxRDr = false;
    double ZwbUsqWOGyDMG = 548600.642978376;
    string uqCZhmW = string("Jd");
    string iNaEJMF = string("PQbZgFGQEqJZdvyWAKLEqKdzgoRmCpEhhyFZlnQBqPCBSWIncDhSatzZFZiURbjpKmEkwvUCNnWbyAMUtbHvRVBqpxFDYQSSfXbJIdfhUHeMJOxApJKJEjjoNARceWjmrLMhSPjDmEEGrQPXthdvoH");
    double yTowXAkdxYPfiWe = -1025471.423351398;
    bool PNfBZhDsiigroZD = false;
    string EAxKCrOKFP = string("bsDxmmlcFziOjMz");

    for (int XDnhrWJdo = 208379021; XDnhrWJdo > 0; XDnhrWJdo--) {
        EAxKCrOKFP += uqCZhmW;
    }

    return lrAzW;
}

void yKYWlMVSOJlolWv::wmYCv(double WWmpWeqDHiBTJiEQ, int CvMcqhhUH, int iqEBvuHhpLJLclJF)
{
    double zSrMs = 471689.2939870424;

    for (int iNFiqnB = 1566889700; iNFiqnB > 0; iNFiqnB--) {
        zSrMs = zSrMs;
        WWmpWeqDHiBTJiEQ -= zSrMs;
        WWmpWeqDHiBTJiEQ /= WWmpWeqDHiBTJiEQ;
    }

    for (int GixrXnSdFADkRm = 1391559701; GixrXnSdFADkRm > 0; GixrXnSdFADkRm--) {
        iqEBvuHhpLJLclJF += CvMcqhhUH;
        iqEBvuHhpLJLclJF /= CvMcqhhUH;
    }

    for (int mtvlcnj = 975300099; mtvlcnj > 0; mtvlcnj--) {
        CvMcqhhUH += CvMcqhhUH;
    }

    if (iqEBvuHhpLJLclJF == -427842544) {
        for (int nqlZFkPCYTBxTNZk = 1403300265; nqlZFkPCYTBxTNZk > 0; nqlZFkPCYTBxTNZk--) {
            CvMcqhhUH += CvMcqhhUH;
            iqEBvuHhpLJLclJF = CvMcqhhUH;
            WWmpWeqDHiBTJiEQ += zSrMs;
            iqEBvuHhpLJLclJF += iqEBvuHhpLJLclJF;
        }
    }
}

int yKYWlMVSOJlolWv::DdsNJ(bool Bqxyewqjy, double OLZXm, double MdGmr, string HnAHbHMPtfyYvPD, double vSFPhexHMAVQv)
{
    double TItYv = 281283.5204049885;
    double MTjwhYNcwFAmt = -858864.1642568319;
    bool uSYGxjxKnLWY = false;
    string prrwORgeyNY = string("yTTZzmIruIqgZdScVAFbUcAnx");
    string CjblcujE = string("PrFrfVdcFsdoAlVeYqyeCPMtTHKCjvswfMttXdhhbjVbbqcSZsGNEhhvRpmplYPIwdYxsaubzzVkzHZmvkzNnkWTvNwXEvRRzwfnWzXIGfxuGCvlCiwQvftrQHMelNRMcwjnjTupmHZHBPjr");
    double CzAicufuFx = 343114.9141199793;
    string FHhiHcgPWybTwKza = string("ipOygeuHQLuRuVggIsAvZsFpNdXNTbJKDpkHVJjoZBgNhegofekKgQdLYqDLoAckuBrGuSKhegmeKfFqTmszETTtKiRMCDxaIBMzdMseBNlrnMoUGLHRlZpXTxBtEceDrADLWavwiCjKdfafLHbtCZDLAHthtPmoIlLzXysOJfqMFGEbFQoPrrhiWKDJQaC");
    double eATxIrOi = 817819.8975859841;
    string aOzQFYTlTXnc = string("csvkorEJAOeniDHqGyBKxfHqQMgxTycUlBwugqGrWNgSsceLFwRfKUitMXtxffpHWjGdaloVcRrzMmUueFuXDhLlQjiJFALirCySSZqjQVLlkjSiLHJIxFacJKFFTOjXbIJyEnwzMLQOXLiKdpacmnUwCVyzTIrEnddkjieuOCytMLgTxjQgICrFalMiCcEeqnguRWTJQSGnEFxrQtDNOJRyUDNnpecDwueqCUlc");

    if (aOzQFYTlTXnc < string("csvkorEJAOeniDHqGyBKxfHqQMgxTycUlBwugqGrWNgSsceLFwRfKUitMXtxffpHWjGdaloVcRrzMmUueFuXDhLlQjiJFALirCySSZqjQVLlkjSiLHJIxFacJKFFTOjXbIJyEnwzMLQOXLiKdpacmnUwCVyzTIrEnddkjieuOCytMLgTxjQgICrFalMiCcEeqnguRWTJQSGnEFxrQtDNOJRyUDNnpecDwueqCUlc")) {
        for (int RxFWKVyKSFoqsw = 51270386; RxFWKVyKSFoqsw > 0; RxFWKVyKSFoqsw--) {
            continue;
        }
    }

    if (FHhiHcgPWybTwKza < string("yTTZzmIruIqgZdScVAFbUcAnx")) {
        for (int HtFCNJSvCi = 341775137; HtFCNJSvCi > 0; HtFCNJSvCi--) {
            HnAHbHMPtfyYvPD = FHhiHcgPWybTwKza;
        }
    }

    return -1065945086;
}

bool yKYWlMVSOJlolWv::njIhEAWjkMc()
{
    string xKWnuCnqO = string("OGbwApXfjzsUhrhNF");

    if (xKWnuCnqO < string("OGbwApXfjzsUhrhNF")) {
        for (int UfWAuvtNbcpQvav = 1906978444; UfWAuvtNbcpQvav > 0; UfWAuvtNbcpQvav--) {
            xKWnuCnqO = xKWnuCnqO;
            xKWnuCnqO = xKWnuCnqO;
            xKWnuCnqO += xKWnuCnqO;
            xKWnuCnqO += xKWnuCnqO;
        }
    }

    return true;
}

void yKYWlMVSOJlolWv::QoXyOZvDjIhhogu(bool LAzCdkEKJSG, bool TNaASD, int ydyZbOMS, double CsSYTZyzHJyAqNd, bool cFKimJIJteVs)
{
    string mnkZqPQExImD = string("ivGqgOTrBTSVphNlnyCEEKqxtMESPPtYlICjXbGpOFptSzMKJfwkocPkCyRRZFvLWTzhQvk");
    string gYmciZC = string("utMHnKOKwKYiTWJkGkmosqPMEbxTxCkPsZJFtrXHH");
    double OfEPkGrfBcFXZaju = -676693.9006431771;

    for (int WzhBMVBQe = 53692314; WzhBMVBQe > 0; WzhBMVBQe--) {
        TNaASD = ! LAzCdkEKJSG;
    }

    for (int haRSHmWSZUxfsh = 613878850; haRSHmWSZUxfsh > 0; haRSHmWSZUxfsh--) {
        LAzCdkEKJSG = cFKimJIJteVs;
    }

    for (int KGdQMitvlvG = 1246445171; KGdQMitvlvG > 0; KGdQMitvlvG--) {
        continue;
    }

    if (cFKimJIJteVs != false) {
        for (int vVLKdMihL = 2056391185; vVLKdMihL > 0; vVLKdMihL--) {
            CsSYTZyzHJyAqNd -= CsSYTZyzHJyAqNd;
        }
    }

    for (int ozTnaHggYJWcO = 1713364924; ozTnaHggYJWcO > 0; ozTnaHggYJWcO--) {
        OfEPkGrfBcFXZaju += OfEPkGrfBcFXZaju;
        CsSYTZyzHJyAqNd = CsSYTZyzHJyAqNd;
    }
}

string yKYWlMVSOJlolWv::vUrnHdL()
{
    int JPOxKM = 629541038;
    bool bFVQQLclye = false;
    bool taTVZvXUDFw = true;
    string dhSpiteK = string("BkXEOwtIbbKjxmnXMXUXLoGNOSxIrSPZaAfscCvcWeCdHNONMVuugFrgMSEjrFZiVnHAITYKlIBZQ");
    string EPLOjHHrjD = string("OTJtxgQwjxpDWAuMwxlCSOaEZLKmbHvOgHMbboFERTsQyjfJMXJOeOVDpcTzlbjNuqNtLPJfkUTgHZHwgYeZLIsLIFNNEfqoCABNCXasevzTUulNo");
    double iocwI = -509421.57062793814;
    string HQINyzCMkRZVVdsW = string("HrlxEwAwIZaxeZdqdzTuTk");
    double NIlaiNitz = -505179.9898675984;
    double dPsaPM = -19677.786364127693;

    if (dPsaPM == -509421.57062793814) {
        for (int TmHGArKjwfdjKX = 1184376667; TmHGArKjwfdjKX > 0; TmHGArKjwfdjKX--) {
            dhSpiteK = dhSpiteK;
            bFVQQLclye = ! bFVQQLclye;
        }
    }

    if (iocwI == -19677.786364127693) {
        for (int tqBSgg = 1823355787; tqBSgg > 0; tqBSgg--) {
            taTVZvXUDFw = ! taTVZvXUDFw;
        }
    }

    if (iocwI >= -509421.57062793814) {
        for (int FuIkFjSNko = 1061352091; FuIkFjSNko > 0; FuIkFjSNko--) {
            iocwI = NIlaiNitz;
        }
    }

    return HQINyzCMkRZVVdsW;
}

yKYWlMVSOJlolWv::yKYWlMVSOJlolWv()
{
    this->oAwXGCulRA();
    this->VSrDHzUdFokm(-369329.7913907066, true, true, -1711545586, 1256393816);
    this->OvTETXNw(1892940046, 813392991, 1607967786);
    this->mvFhVk(false, 460779.9429033297, 744937035, 807542212, false);
    this->YbedthZmJdjztMKQ();
    this->xxrzfVuIGDoS(false);
    this->QCThNqadPwQJZOu();
    this->HsqAfbbg(-1370857561, -155829466, 1879626524);
    this->zBUvHZmZhCjqrsmX();
    this->oAMZPr(-671838731, 823311450, true);
    this->wmYCv(-1014973.4457628771, -38851228, -427842544);
    this->DdsNJ(true, -705826.9899509066, 733350.7986814749, string("VzAcdJTcAJbpZmybXbsCTWELnhoUPxvLlMORvNHnysRrFtwNBKBG"), -585883.5437426544);
    this->njIhEAWjkMc();
    this->QoXyOZvDjIhhogu(false, false, -364134838, 449409.53895386774, false);
    this->vUrnHdL();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XDRGSmijIfKvBxH
{
public:
    string ntJUpAelPt;
    bool LQJAleyehH;

    XDRGSmijIfKvBxH();
protected:
    bool XoILNQSy;
    bool aNiSn;
    int DuAEXHCT;
    double ZKctIEGDz;

    int WfmEw(bool WuvktgdSQ, int iltjBfTPgRGi, bool pGeqWCFy, double DeFSdoJlAoDvF);
    string WlWIWkepRaPrf(int jBziWgE, double jzbvHvcmG, int spLzWuPEYAPHroY);
    bool CYZMgdlmHhSten(string XRAjFlW, bool AuqAxGNerZXR, string OBWlBAjwfsad);
    bool embXuNvoFoK(string ggklydkWUSYSGaG, string SFKdRqJooN, int yVrZCuvWz, int PsfCruGmFAdm);
    double KkEJSWeJCsFWFkQ(int XztDiBdI, double tQevDzVnopUmdKY, int yzMcepF, double UTFuhjNuTfmaNi);
    double lPgrNYdhVNypVXPA(string CNijYJVI, int SjUKMUDE, bool vHocZKROFXw, bool YcCVRtdStxcbyOhA);
    void eWyzvxoa(double VSdyQvPHxLrREv);
    bool gNkptVdeh(bool iGtZWNfcmsHup, bool lmluKFfBRyPOxS, string fNkMtlQGgvWxC);
private:
    bool EDfkksWRoGl;
    double MKotJFJcWrognvf;
    double SesYwiOzdSZ;
    string lZqhm;
    int pJGTgaW;

    void UMwRSgIYijnuINH(int ZXjvAsfwoXrl);
    string kgOap(bool rXyaikdNQHoURPe);
    string vOUCIfqJoTqG(int gOzKMUSjuzpRIxcd, double NRHkwkd, string JKDeZGH, bool JrDkGvKJsGOg);
    bool DjpNBvUvqfwILG(string DdzqcNcQmzxE, bool ooGghqUjvB, double QZBry, bool XliLrUZrfp);
    string bfRWwDr(double mEUvPnpkBWYh, string BdlDXhFx);
    string sPXLYwCaHRZTJq(int dHibU);
    void iHYvClbWaQMJB(int AFyizhZxcoVLjIwu, int DjidEQcAJrYpHAu, double MIhiKcxF, double QwfCQszsRi, double BDVlsGhELS);
    bool wNlFKcMkhbjfWNG(double kOakmE);
};

int XDRGSmijIfKvBxH::WfmEw(bool WuvktgdSQ, int iltjBfTPgRGi, bool pGeqWCFy, double DeFSdoJlAoDvF)
{
    double eetUwZCRD = -813360.1286843144;
    string XWGvifHJBWJI = string("LmVbVuuIgYWNPalgaprfKnAfIdrLMtRQyBrUneQylJllCmlsXXWCsNjRPHJxDKrftlIycfWHyDipipKUMKYrwLCYMAsKvuNRV");

    for (int IlzOHcHoV = 205349988; IlzOHcHoV > 0; IlzOHcHoV--) {
        XWGvifHJBWJI = XWGvifHJBWJI;
    }

    for (int aZJHhNpoH = 1149555412; aZJHhNpoH > 0; aZJHhNpoH--) {
        WuvktgdSQ = ! pGeqWCFy;
        DeFSdoJlAoDvF = eetUwZCRD;
    }

    for (int hbFxeQyqwc = 929366834; hbFxeQyqwc > 0; hbFxeQyqwc--) {
        continue;
    }

    for (int HHZJrKQz = 553917819; HHZJrKQz > 0; HHZJrKQz--) {
        continue;
    }

    return iltjBfTPgRGi;
}

string XDRGSmijIfKvBxH::WlWIWkepRaPrf(int jBziWgE, double jzbvHvcmG, int spLzWuPEYAPHroY)
{
    int ghZqSzl = 2110555131;
    bool YpsDTOduLHzmSqSO = true;
    int OVkdTQPKQtRD = 1229691056;
    int bOCdwdVRNmx = -1129977416;
    double fUUOzDj = -672479.1581871072;
    bool UuAPqTSfsf = false;
    bool ZLUyQzyIi = false;

    for (int VwblQPZOPTCrhMZ = 1062643390; VwblQPZOPTCrhMZ > 0; VwblQPZOPTCrhMZ--) {
        spLzWuPEYAPHroY /= OVkdTQPKQtRD;
        jzbvHvcmG *= fUUOzDj;
    }

    if (UuAPqTSfsf != false) {
        for (int BvmzxDvxPRgxry = 259022743; BvmzxDvxPRgxry > 0; BvmzxDvxPRgxry--) {
            ZLUyQzyIi = ! ZLUyQzyIi;
        }
    }

    for (int ZUMpBUleVFot = 330470083; ZUMpBUleVFot > 0; ZUMpBUleVFot--) {
        jBziWgE = bOCdwdVRNmx;
        UuAPqTSfsf = ! ZLUyQzyIi;
        ZLUyQzyIi = ! YpsDTOduLHzmSqSO;
    }

    if (bOCdwdVRNmx <= -1129977416) {
        for (int ejTirlfpOUly = 2005565778; ejTirlfpOUly > 0; ejTirlfpOUly--) {
            continue;
        }
    }

    return string("odKPCCxpJOEKhQxWYusKntlLtSDhtCSMXPLMraHCiIhHCgieVSjCiXDMMuWPkxCSyBFeFBDctluxvDZgjMDwOZSfQZoDXfZBLdFxTcPdplvTgwdfyGvcLWlGjgIuQOnHWxPMZDYGgNLzZEqpGqqKVuUwAFUIdleEnvMkGpLHloDZOyeWDUDbOnH");
}

bool XDRGSmijIfKvBxH::CYZMgdlmHhSten(string XRAjFlW, bool AuqAxGNerZXR, string OBWlBAjwfsad)
{
    int tpcWbYdWodDrzxL = -301114983;
    double TUdqdaFlTgVzgmkC = 562174.1191931586;
    double WwogT = -790582.7345941258;
    double KmrTWBdoMektAvi = -918911.3366429949;
    string ZuiVyeJSUVd = string("XMxAPxRcoqcZaUeMKFnqxgyCfhujrGLsvRlwvBqFDdaVGkRegriGXBussnHuzDjbNmkwfFWAfMWXswPZEskasHuMYJLRaOiAKvDTLiKGYVuVqdqRnuWfpzLbTZ");
    int PQCdvpdQfwwfDXwD = 644229836;

    if (KmrTWBdoMektAvi <= -918911.3366429949) {
        for (int BWaAqsywQRV = 1043475136; BWaAqsywQRV > 0; BWaAqsywQRV--) {
            XRAjFlW = ZuiVyeJSUVd;
            ZuiVyeJSUVd += OBWlBAjwfsad;
            KmrTWBdoMektAvi += WwogT;
            TUdqdaFlTgVzgmkC *= WwogT;
            OBWlBAjwfsad += XRAjFlW;
            WwogT -= TUdqdaFlTgVzgmkC;
            XRAjFlW = XRAjFlW;
            tpcWbYdWodDrzxL *= PQCdvpdQfwwfDXwD;
        }
    }

    for (int GrFGlEYBZFxfO = 1784693761; GrFGlEYBZFxfO > 0; GrFGlEYBZFxfO--) {
        continue;
    }

    if (WwogT >= 562174.1191931586) {
        for (int EaqVkzMAEXSaqs = 745248435; EaqVkzMAEXSaqs > 0; EaqVkzMAEXSaqs--) {
            TUdqdaFlTgVzgmkC += WwogT;
            ZuiVyeJSUVd = XRAjFlW;
        }
    }

    for (int uKCSMscXUFvY = 122079333; uKCSMscXUFvY > 0; uKCSMscXUFvY--) {
        OBWlBAjwfsad = OBWlBAjwfsad;
    }

    for (int ZfqAWlmKbgGuEgs = 799117316; ZfqAWlmKbgGuEgs > 0; ZfqAWlmKbgGuEgs--) {
        KmrTWBdoMektAvi *= TUdqdaFlTgVzgmkC;
        ZuiVyeJSUVd = XRAjFlW;
        KmrTWBdoMektAvi /= WwogT;
        ZuiVyeJSUVd += ZuiVyeJSUVd;
    }

    for (int hwxJRzBu = 1292233592; hwxJRzBu > 0; hwxJRzBu--) {
        continue;
    }

    return AuqAxGNerZXR;
}

bool XDRGSmijIfKvBxH::embXuNvoFoK(string ggklydkWUSYSGaG, string SFKdRqJooN, int yVrZCuvWz, int PsfCruGmFAdm)
{
    bool TuOuTYTXHolv = false;
    double nVybYVyILE = 1014169.6970614307;
    double MEKIMm = -951115.619266796;
    string vGSOCqrgBDGvP = string("tPYBRFcPpWZbBg");
    double GsoqsWcmhsxSwh = 265981.58086953504;
    double gSPnbsGDyIxu = -539432.9228229955;
    bool eNiaYpYSKwY = true;
    bool jlfGnve = true;

    for (int OnWtwTbGFZ = 424562599; OnWtwTbGFZ > 0; OnWtwTbGFZ--) {
        PsfCruGmFAdm -= PsfCruGmFAdm;
        GsoqsWcmhsxSwh *= gSPnbsGDyIxu;
        vGSOCqrgBDGvP += SFKdRqJooN;
        GsoqsWcmhsxSwh = GsoqsWcmhsxSwh;
    }

    if (MEKIMm != -539432.9228229955) {
        for (int YleqlbmmMh = 2036235369; YleqlbmmMh > 0; YleqlbmmMh--) {
            continue;
        }
    }

    if (vGSOCqrgBDGvP >= string("tPYBRFcPpWZbBg")) {
        for (int msqza = 1761115959; msqza > 0; msqza--) {
            GsoqsWcmhsxSwh += MEKIMm;
            GsoqsWcmhsxSwh = MEKIMm;
        }
    }

    if (MEKIMm > -539432.9228229955) {
        for (int JEjvwbnupBeDWo = 1718545100; JEjvwbnupBeDWo > 0; JEjvwbnupBeDWo--) {
            continue;
        }
    }

    return jlfGnve;
}

double XDRGSmijIfKvBxH::KkEJSWeJCsFWFkQ(int XztDiBdI, double tQevDzVnopUmdKY, int yzMcepF, double UTFuhjNuTfmaNi)
{
    string dPixJLZZpPjEIbx = string("DKMMshJNvisueuPylqWESzpFLLJdZDINqOKddpEiilFhOTnLjAHLcPDWYLwpGxujOkCaqPMOfMOrYvbjeuMjCAGXjNgbfgdtzMYXlIjOkGeEKnWlPJqeUYbtPgbXxyiFagwFdaHEJhAKBPwgwEGnvjvGUtBQGYyHVFlztvaQSrDbGnzvSZjxsxTgrgkUMjnivHApUxsoSOYYNaEZqmQRMuC");
    string EzjsSRnqaaz = string("yQVaNKGIFlSKaSIyBWpCSSjbEUVSPEWhVPSyyDsvmmgHVoRKOGdbRJCJPrbiRjIZudYIqWhkZbSVKbxGMIRWHEiGCLzkXTXpMVewfGwoCEJQUjavHFeBGrj");

    for (int IxYoViSrkwPPI = 635351229; IxYoViSrkwPPI > 0; IxYoViSrkwPPI--) {
        UTFuhjNuTfmaNi /= tQevDzVnopUmdKY;
        EzjsSRnqaaz = EzjsSRnqaaz;
        UTFuhjNuTfmaNi += UTFuhjNuTfmaNi;
    }

    for (int mfFozecnBbwc = 759538861; mfFozecnBbwc > 0; mfFozecnBbwc--) {
        EzjsSRnqaaz = dPixJLZZpPjEIbx;
    }

    if (UTFuhjNuTfmaNi == 996856.1962775834) {
        for (int GNrdAEUujzmAJ = 1892720034; GNrdAEUujzmAJ > 0; GNrdAEUujzmAJ--) {
            dPixJLZZpPjEIbx += EzjsSRnqaaz;
            UTFuhjNuTfmaNi += tQevDzVnopUmdKY;
        }
    }

    return UTFuhjNuTfmaNi;
}

double XDRGSmijIfKvBxH::lPgrNYdhVNypVXPA(string CNijYJVI, int SjUKMUDE, bool vHocZKROFXw, bool YcCVRtdStxcbyOhA)
{
    int yyicDeJygjDLPE = -2029352172;
    int VyAOBXRbmrVwOUQu = 1347811001;
    bool ujZAhNDF = false;
    bool pKPWK = false;
    double NvNczvoAC = 729636.9099523758;
    int uEWpFEwRQeydxgw = 8509889;
    int wDdTjlyN = 1550177957;
    string UVOLJIisumOgN = string("prJGUWyuYedNsKuOsrFzceKLTyEWDKpggehcQCKQnEtPLEfoArANeKMnSzSmQgxGrdAOunlWejYdEAqbkWwPpv");
    int iGGgksPhLxl = 226162917;

    if (wDdTjlyN == -2029352172) {
        for (int MimePolBhG = 1444234057; MimePolBhG > 0; MimePolBhG--) {
            wDdTjlyN /= SjUKMUDE;
            iGGgksPhLxl /= iGGgksPhLxl;
            YcCVRtdStxcbyOhA = vHocZKROFXw;
            ujZAhNDF = ! pKPWK;
        }
    }

    if (YcCVRtdStxcbyOhA == false) {
        for (int KUnWCsh = 407610220; KUnWCsh > 0; KUnWCsh--) {
            YcCVRtdStxcbyOhA = ! pKPWK;
        }
    }

    for (int jjXETuaFwVKPh = 1137011053; jjXETuaFwVKPh > 0; jjXETuaFwVKPh--) {
        ujZAhNDF = ! ujZAhNDF;
        NvNczvoAC -= NvNczvoAC;
        vHocZKROFXw = ujZAhNDF;
        SjUKMUDE = uEWpFEwRQeydxgw;
        uEWpFEwRQeydxgw -= VyAOBXRbmrVwOUQu;
    }

    for (int JdtWKWpnvjsPQA = 1581966015; JdtWKWpnvjsPQA > 0; JdtWKWpnvjsPQA--) {
        continue;
    }

    if (ujZAhNDF == false) {
        for (int GdwAtRasDA = 1947724323; GdwAtRasDA > 0; GdwAtRasDA--) {
            uEWpFEwRQeydxgw += iGGgksPhLxl;
        }
    }

    return NvNczvoAC;
}

void XDRGSmijIfKvBxH::eWyzvxoa(double VSdyQvPHxLrREv)
{
    double CjRVCVf = 233398.96642504146;
    double JYccgPAC = -267760.9597085702;
    double XDjnLflOcHKwweQ = 597936.7558579231;
    int eJXVmit = 1432457035;
    double qaqZhKvvarKsvzM = 107269.60511556712;
    bool Dhjpx = true;
    double hLkSGxWDPs = -851726.1816227931;

    if (VSdyQvPHxLrREv <= 597936.7558579231) {
        for (int wkwtg = 122756004; wkwtg > 0; wkwtg--) {
            eJXVmit /= eJXVmit;
            VSdyQvPHxLrREv -= qaqZhKvvarKsvzM;
            CjRVCVf = JYccgPAC;
            qaqZhKvvarKsvzM /= XDjnLflOcHKwweQ;
            CjRVCVf /= VSdyQvPHxLrREv;
            hLkSGxWDPs = qaqZhKvvarKsvzM;
        }
    }
}

bool XDRGSmijIfKvBxH::gNkptVdeh(bool iGtZWNfcmsHup, bool lmluKFfBRyPOxS, string fNkMtlQGgvWxC)
{
    int AkxTXiXkwknXWEu = -460734717;
    double RPkirgvQpYPd = 589049.3535882665;
    int fvUDidjluUFoI = -1063440900;
    int CfJtcXw = -266858056;
    bool JxgNlM = true;
    bool vakcSzkOdV = false;
    string JgbtCvemqz = string("EspKjmQBNlRmjwUqPuJuqECyRgjgvZQdeWOPDufGiMmJrTRXhYeCOVCUYqhyDHjyzICpMHDptIeTNVSAKNFOsLDTKNjgejlaBYVQwyEbfDCaECcgMtMVMaDepDAYofaLEgnajQSHTGpndEkwziOufhXZfWDujgAyHx");
    int LghLUFIK = 55530045;
    string RfNJGWPuQ = string("zppMNWffMVTwxlOhYgWMyeFdojrFektdAzZBDjmCJEuKjjnhvDIzBcYTYKHMgFKGQfwjeDYxMSDOjuCJefVMiOXFgmJOjDTZEzQacRSSQlNrMDXPXyeBFTnlFpRtPPmOIdqTEylMpPzWOBYGRCUmjiaFNJkjEuuAVASYsJRyOGZBlIjbQzGGPMrdBEBREWWrofxcKppCkAw");

    for (int lQxHX = 2124625395; lQxHX > 0; lQxHX--) {
        lmluKFfBRyPOxS = ! vakcSzkOdV;
        RfNJGWPuQ = JgbtCvemqz;
    }

    for (int VyVgWsP = 1315597911; VyVgWsP > 0; VyVgWsP--) {
        JgbtCvemqz = fNkMtlQGgvWxC;
        JxgNlM = JxgNlM;
    }

    for (int hrZpMCcmYqlO = 1305718447; hrZpMCcmYqlO > 0; hrZpMCcmYqlO--) {
        iGtZWNfcmsHup = ! JxgNlM;
        JxgNlM = ! JxgNlM;
    }

    return vakcSzkOdV;
}

void XDRGSmijIfKvBxH::UMwRSgIYijnuINH(int ZXjvAsfwoXrl)
{
    string WKNtdHk = string("WsfQHYUTHXBkfyTmediNhrpUvKDISRNPNgJyAsZukzNecSvDNRxbXqcUvbJnMCXeTDPdFFNivmDDNofTlHzLywvkIyzWRrVcUigyWJXMbKutZmBNeWDjuSgqHrgSCjCxKLXsdseJcPGaXDcRmGJEmKdGBhEZpdkpgCFNAhSJOzoFYwcgYqpPNkzZajRVjefFXxgBLzWriLKYRWOfVAsshalaZhKEjmTLLuviw");
    string mjzifia = string("ScvgUSXQZVchPPyRqTDvPVGMnwYxRThOEKtNaAOJuEcoaQIfFdaKqfYLiDzzUvNbqrfonYNsMdgpANQdJHdylaPnUXVfZGpDIPbfYwYvlYRvvbMZcZRbsfiCHZNpXfBBbprzJOhgVrhLtzwZxXAayZALnTGRztTyG");
    int rNCrVmjGGuI = 1499741651;
    string AqdtZowzqOHszC = string("NtFTgjmbESTAAHhIYPaxguWpuFoEtHlqCDlsnAKqhZcTFlBEgdOMmsNynvHvOttySaZVGIVDxNEjMhemdtrCSUIqzOJhRwnInJntzTWaBKsTeAsEgYNskgLahTnUP");
    double eZATDsnUeJHvqqk = 993429.8709747699;
    bool EahabvJjT = true;

    for (int YsiUpEf = 415282462; YsiUpEf > 0; YsiUpEf--) {
        mjzifia += AqdtZowzqOHszC;
        AqdtZowzqOHszC = mjzifia;
    }

    for (int lVFZXMawM = 1051413431; lVFZXMawM > 0; lVFZXMawM--) {
        rNCrVmjGGuI /= rNCrVmjGGuI;
        AqdtZowzqOHszC = WKNtdHk;
        rNCrVmjGGuI += ZXjvAsfwoXrl;
        mjzifia += AqdtZowzqOHszC;
    }

    for (int YNNpzU = 788223107; YNNpzU > 0; YNNpzU--) {
        mjzifia += mjzifia;
        WKNtdHk = WKNtdHk;
    }

    for (int vvEZsdSZgBXTHTi = 1286048071; vvEZsdSZgBXTHTi > 0; vvEZsdSZgBXTHTi--) {
        mjzifia = mjzifia;
    }

    if (WKNtdHk != string("ScvgUSXQZVchPPyRqTDvPVGMnwYxRThOEKtNaAOJuEcoaQIfFdaKqfYLiDzzUvNbqrfonYNsMdgpANQdJHdylaPnUXVfZGpDIPbfYwYvlYRvvbMZcZRbsfiCHZNpXfBBbprzJOhgVrhLtzwZxXAayZALnTGRztTyG")) {
        for (int tVitjrdq = 975343439; tVitjrdq > 0; tVitjrdq--) {
            WKNtdHk = WKNtdHk;
        }
    }

    for (int jqmlTiRrw = 559551946; jqmlTiRrw > 0; jqmlTiRrw--) {
        ZXjvAsfwoXrl = ZXjvAsfwoXrl;
        ZXjvAsfwoXrl *= ZXjvAsfwoXrl;
    }

    if (AqdtZowzqOHszC >= string("ScvgUSXQZVchPPyRqTDvPVGMnwYxRThOEKtNaAOJuEcoaQIfFdaKqfYLiDzzUvNbqrfonYNsMdgpANQdJHdylaPnUXVfZGpDIPbfYwYvlYRvvbMZcZRbsfiCHZNpXfBBbprzJOhgVrhLtzwZxXAayZALnTGRztTyG")) {
        for (int VswasoPi = 2103359125; VswasoPi > 0; VswasoPi--) {
            WKNtdHk = AqdtZowzqOHszC;
        }
    }
}

string XDRGSmijIfKvBxH::kgOap(bool rXyaikdNQHoURPe)
{
    double wHAZgCbvXnEYTlu = -711610.5008657076;

    for (int rWISXDBCJEF = 1387358166; rWISXDBCJEF > 0; rWISXDBCJEF--) {
        wHAZgCbvXnEYTlu /= wHAZgCbvXnEYTlu;
    }

    for (int xeslsiyNmyH = 1232519485; xeslsiyNmyH > 0; xeslsiyNmyH--) {
        rXyaikdNQHoURPe = ! rXyaikdNQHoURPe;
        rXyaikdNQHoURPe = rXyaikdNQHoURPe;
    }

    for (int CaRqBNkxnSYHHRc = 143587706; CaRqBNkxnSYHHRc > 0; CaRqBNkxnSYHHRc--) {
        wHAZgCbvXnEYTlu += wHAZgCbvXnEYTlu;
    }

    return string("VjiZkHMkUYklYDVWqbyXJkDeHknxHoHgjLNfpeJKNivtifYjgktOdMzJihVTzJwwptMTshaxbJKMExiWirnnDgqDhLPWjUzriTBdWlCcimnUfpaQoTICTbKDcgKdVeJGuMMDZKzpcUQYB");
}

string XDRGSmijIfKvBxH::vOUCIfqJoTqG(int gOzKMUSjuzpRIxcd, double NRHkwkd, string JKDeZGH, bool JrDkGvKJsGOg)
{
    double UbXWMJZymSahh = -282824.8248238698;

    for (int chjcfIQ = 726432200; chjcfIQ > 0; chjcfIQ--) {
        continue;
    }

    for (int xJZUzQOmLKrvC = 1941913785; xJZUzQOmLKrvC > 0; xJZUzQOmLKrvC--) {
        UbXWMJZymSahh *= NRHkwkd;
    }

    if (gOzKMUSjuzpRIxcd == -1215252794) {
        for (int eWgYuGNSzyqvLStK = 1610198151; eWgYuGNSzyqvLStK > 0; eWgYuGNSzyqvLStK--) {
            UbXWMJZymSahh = UbXWMJZymSahh;
            NRHkwkd = UbXWMJZymSahh;
            NRHkwkd += NRHkwkd;
            JKDeZGH = JKDeZGH;
        }
    }

    for (int cbYzyIfjIJ = 1958964145; cbYzyIfjIJ > 0; cbYzyIfjIJ--) {
        JrDkGvKJsGOg = ! JrDkGvKJsGOg;
    }

    for (int sUtFvI = 1183465279; sUtFvI > 0; sUtFvI--) {
        UbXWMJZymSahh /= NRHkwkd;
    }

    for (int KErbg = 2029549921; KErbg > 0; KErbg--) {
        continue;
    }

    for (int FRmOHyEPGBgO = 1773447603; FRmOHyEPGBgO > 0; FRmOHyEPGBgO--) {
        JKDeZGH += JKDeZGH;
        JKDeZGH = JKDeZGH;
    }

    return JKDeZGH;
}

bool XDRGSmijIfKvBxH::DjpNBvUvqfwILG(string DdzqcNcQmzxE, bool ooGghqUjvB, double QZBry, bool XliLrUZrfp)
{
    bool jcBKpErFy = true;

    for (int DFIAvz = 1499268898; DFIAvz > 0; DFIAvz--) {
        ooGghqUjvB = XliLrUZrfp;
        XliLrUZrfp = ! jcBKpErFy;
        XliLrUZrfp = ! ooGghqUjvB;
        jcBKpErFy = ! ooGghqUjvB;
        XliLrUZrfp = ! jcBKpErFy;
    }

    for (int jtFhTFL = 1826430428; jtFhTFL > 0; jtFhTFL--) {
        continue;
    }

    return jcBKpErFy;
}

string XDRGSmijIfKvBxH::bfRWwDr(double mEUvPnpkBWYh, string BdlDXhFx)
{
    double zwqiMnCNCDzD = 326734.60394501576;
    double jBvTzANxvCUIIS = -557133.5147874347;
    string LQuDC = string("sseWmFLeQCurOWrLkIDKqMKagcDUUSdEiZyWoCCFPCaPXBEehINbMN");
    int JvXCIK = 509284562;
    bool BSGHG = false;
    double LkULQjE = -165113.64402474923;
    bool jQpjVogPfmoGUO = false;

    if (BdlDXhFx <= string("FhKaAyuYVTaXYTfhnYpmCUEtKcOsADAjmucDvClyxewYlXgwyfFcIOrBvHBYFtquAaeBmEffbOPIIAHSOMjnfEgPFyNxQAlmfdjAkCApvMDTihcBXjpTodPiZLJPMmpZYuSLDloCopIdMeoqYCPPqtPtkKbQJdrsmjlZqyMovrZgIlHkKzJRKlpznZUstxlkZRXWrCfyflrsHXeUJzkggtzOvXzSbaYBnTqTUMS")) {
        for (int ItFLwSfPfesAG = 2071278907; ItFLwSfPfesAG > 0; ItFLwSfPfesAG--) {
            BdlDXhFx += LQuDC;
            jBvTzANxvCUIIS /= mEUvPnpkBWYh;
            LkULQjE *= LkULQjE;
            zwqiMnCNCDzD -= zwqiMnCNCDzD;
            LkULQjE /= mEUvPnpkBWYh;
        }
    }

    for (int lvueWBYRi = 1998850605; lvueWBYRi > 0; lvueWBYRi--) {
        BdlDXhFx = BdlDXhFx;
        mEUvPnpkBWYh /= LkULQjE;
        LQuDC = LQuDC;
        jQpjVogPfmoGUO = jQpjVogPfmoGUO;
    }

    for (int llOtyvlQvxp = 976144016; llOtyvlQvxp > 0; llOtyvlQvxp--) {
        LkULQjE += jBvTzANxvCUIIS;
        zwqiMnCNCDzD /= jBvTzANxvCUIIS;
        jBvTzANxvCUIIS -= jBvTzANxvCUIIS;
        zwqiMnCNCDzD += mEUvPnpkBWYh;
    }

    for (int LNbcVjLr = 1503088376; LNbcVjLr > 0; LNbcVjLr--) {
        jBvTzANxvCUIIS -= LkULQjE;
        jBvTzANxvCUIIS = zwqiMnCNCDzD;
        mEUvPnpkBWYh = LkULQjE;
    }

    for (int dyJUgOCJa = 424308578; dyJUgOCJa > 0; dyJUgOCJa--) {
        continue;
    }

    return LQuDC;
}

string XDRGSmijIfKvBxH::sPXLYwCaHRZTJq(int dHibU)
{
    double umwWHN = -97368.60760194133;
    int QpacoDRkJE = 1642066959;
    bool liEyuhze = true;
    string xCvRDoUpWyXzOHc = string("FLNmpNvQUDoRqEGwHeYgruFjivVITdoCZcOWumRATPLEsgsgIrhGMbCeolCjEXQcswhafUoZBquJUVUmSAmJsdhdstrcWCpxMaCvxefr");
    int uQJVlnv = 1244761111;
    double cUwglYaJ = 341204.2234663508;
    int ZUharBoowXm = 118236096;

    for (int eKMgFCHXnozMk = 31300367; eKMgFCHXnozMk > 0; eKMgFCHXnozMk--) {
        continue;
    }

    for (int nGANHcBFssn = 303242014; nGANHcBFssn > 0; nGANHcBFssn--) {
        dHibU -= uQJVlnv;
        ZUharBoowXm -= uQJVlnv;
    }

    for (int BcISByHkRWQcItPq = 298693885; BcISByHkRWQcItPq > 0; BcISByHkRWQcItPq--) {
        cUwglYaJ /= umwWHN;
    }

    for (int QOVQBFKDVTJD = 614592762; QOVQBFKDVTJD > 0; QOVQBFKDVTJD--) {
        dHibU += QpacoDRkJE;
        liEyuhze = liEyuhze;
    }

    for (int EOIIfC = 1794232058; EOIIfC > 0; EOIIfC--) {
        QpacoDRkJE -= QpacoDRkJE;
        uQJVlnv += dHibU;
    }

    return xCvRDoUpWyXzOHc;
}

void XDRGSmijIfKvBxH::iHYvClbWaQMJB(int AFyizhZxcoVLjIwu, int DjidEQcAJrYpHAu, double MIhiKcxF, double QwfCQszsRi, double BDVlsGhELS)
{
    bool LekthyWQPce = true;
    bool FUdfUgHHP = false;
    double SfSxgHOKzoH = -1007264.0751230505;
    int wjXVKXHQke = 1077083333;

    for (int ADyAzCUrAF = 1081650613; ADyAzCUrAF > 0; ADyAzCUrAF--) {
        FUdfUgHHP = ! LekthyWQPce;
    }

    if (wjXVKXHQke <= 138303453) {
        for (int zLYygmDmVO = 179474757; zLYygmDmVO > 0; zLYygmDmVO--) {
            wjXVKXHQke += wjXVKXHQke;
            DjidEQcAJrYpHAu += wjXVKXHQke;
            SfSxgHOKzoH = QwfCQszsRi;
        }
    }

    for (int NlScXY = 692255546; NlScXY > 0; NlScXY--) {
        FUdfUgHHP = ! FUdfUgHHP;
        BDVlsGhELS /= MIhiKcxF;
    }

    if (DjidEQcAJrYpHAu >= 1077083333) {
        for (int QCrGyTKUsMxPz = 623504310; QCrGyTKUsMxPz > 0; QCrGyTKUsMxPz--) {
            QwfCQszsRi /= QwfCQszsRi;
            SfSxgHOKzoH /= QwfCQszsRi;
        }
    }
}

bool XDRGSmijIfKvBxH::wNlFKcMkhbjfWNG(double kOakmE)
{
    string ZfTOLHthIlPlb = string("QXjRveQeSFKQVY");
    int nqQvoJtqmnxztMS = 162801608;
    double kWXBqlGBtVXhmgD = 169802.25332399886;
    double ISCoWSRnInB = 773224.3433764039;

    if (nqQvoJtqmnxztMS == 162801608) {
        for (int RuxersRE = 2004193425; RuxersRE > 0; RuxersRE--) {
            kOakmE = kWXBqlGBtVXhmgD;
            nqQvoJtqmnxztMS -= nqQvoJtqmnxztMS;
            kWXBqlGBtVXhmgD /= kWXBqlGBtVXhmgD;
        }
    }

    if (kWXBqlGBtVXhmgD < 169802.25332399886) {
        for (int lAoyOsJhfWMT = 106404241; lAoyOsJhfWMT > 0; lAoyOsJhfWMT--) {
            kWXBqlGBtVXhmgD /= kWXBqlGBtVXhmgD;
            nqQvoJtqmnxztMS /= nqQvoJtqmnxztMS;
            kWXBqlGBtVXhmgD /= ISCoWSRnInB;
            kOakmE += ISCoWSRnInB;
        }
    }

    for (int pbrSygfVHDuBwr = 979702069; pbrSygfVHDuBwr > 0; pbrSygfVHDuBwr--) {
        kWXBqlGBtVXhmgD += kOakmE;
    }

    for (int uhNJNRES = 1645149156; uhNJNRES > 0; uhNJNRES--) {
        ISCoWSRnInB = ISCoWSRnInB;
        ISCoWSRnInB -= kWXBqlGBtVXhmgD;
        kWXBqlGBtVXhmgD = kWXBqlGBtVXhmgD;
        ISCoWSRnInB /= kWXBqlGBtVXhmgD;
    }

    return false;
}

XDRGSmijIfKvBxH::XDRGSmijIfKvBxH()
{
    this->WfmEw(true, -663495760, true, 884558.9122815899);
    this->WlWIWkepRaPrf(-752916244, 374313.5231999188, -1710125866);
    this->CYZMgdlmHhSten(string("YBkNNIkpEbuRLFpwciXTZteifuoywBUagbydvOJMXTQiLIStwzQZyXHoFVvpvdrOusGHNIvLeMCTTtARNmG"), false, string("vtNmQhBdaZUSCdOCHdzVPwCfAKnAaZPGFULcpPozrZSKOmTccWfuYTZeHrPkdgyjJXlZyUAcwFdSiZngyifKVvMyaOTkZHvgqGOLTdlFuhaxCxBRyIPXdVGZ"));
    this->embXuNvoFoK(string("plATkgMyYtVfHCizLMeTRfDSTndoTXvcHIAwmfPjzIbCdRDXMBIQmhcanPlqUZHvffzwBtEMoMLPVhOooEWExjsFWoJioivADmiJApdqvbcC"), string("HjKvgGcPXzkEXWYQrNsGbnEUrlKMALGiQDKOJRtRFywNSmLRaYCWldhPsBaHKEzqVfFtnzqVXmFdASrztLCHrnvZOvpVzODVocTwGyZTHnAMVlKgvxvrPgnKWDefkbAdByhGpBIPRWaxRXYXBHcEkTlePeTHUxL"), -970211544, -707367324);
    this->KkEJSWeJCsFWFkQ(1207109830, 635298.2215689265, -1247848890, 996856.1962775834);
    this->lPgrNYdhVNypVXPA(string("onXyIzPsKofiOKuQifFVKoUVjDmqxJulUaRJKNUWJFrpPXtZNbUtmvQjHpshCNwFjAAGnTFwBcLeXTIiNUUPXDyeXYNiLraRecBJPyxMkdCxYQTXGGrfyMxMWFENsngXXViFvRhHeMYSbstPxllef"), 431542062, true, true);
    this->eWyzvxoa(-626107.6951344227);
    this->gNkptVdeh(true, true, string("QRHsGNlTAwUxmPMYytveDLyKQJLEwRkRnfcnACbRqmVWsKEpgrWkyOfkokMaomKZSBcvijSQqUfBriCDgNVpFxJBbFMvdOJqXrIEoXTIspgNODmSInBAozWSboONkxImuuecfBPXAofEQvziPxuTwUAcaCXPyzmQplCKhIxzIyZmttdwsUQeekcXGPgplWljUnxBFLwdtEuLpFiXVZ"));
    this->UMwRSgIYijnuINH(1926071560);
    this->kgOap(false);
    this->vOUCIfqJoTqG(-1215252794, -839070.015240605, string("wxmXGhGexkZZsSwnBgKFkqBJENwQdcngJhMPVaqRXlsDGpISHhQczspwtrDwHKcpqqoaRxQjTmVFfvbkOXsPzqZOJinvxZsdwEuSUljAnNWqPNdpisQsIJlooayxakEHYMWLbPaNmUTsYYkmTpYInjmAXTXTXkjfpSksBtBcgqpZHaFQerIlkLBCkvbDBVPXsCNnZbHYsezQxUYWuMctbFMJHjiBsWkXqmHjiYVMSnwxoEMI"), true);
    this->DjpNBvUvqfwILG(string("hQnVgOfTnXthTFiWZpSsYSshwxZVnaSfxLFUEMIObvOljabysqFLIoTqqSLhDkQCyloqxxMXKyMWLDivcOYlUJGZCeEKlnUSHfKVpZgnaKAKGbjLzvVTgwYbGoTRkLGVokVtBsDXUGTcMCDvixklAROYmWulWHiAjDuboJgldSakEW"), false, -232252.25959177516, true);
    this->bfRWwDr(-529563.2325519073, string("FhKaAyuYVTaXYTfhnYpmCUEtKcOsADAjmucDvClyxewYlXgwyfFcIOrBvHBYFtquAaeBmEffbOPIIAHSOMjnfEgPFyNxQAlmfdjAkCApvMDTihcBXjpTodPiZLJPMmpZYuSLDloCopIdMeoqYCPPqtPtkKbQJdrsmjlZqyMovrZgIlHkKzJRKlpznZUstxlkZRXWrCfyflrsHXeUJzkggtzOvXzSbaYBnTqTUMS"));
    this->sPXLYwCaHRZTJq(-337694203);
    this->iHYvClbWaQMJB(138303453, -1962198927, 316315.59194501856, 848382.7796879652, 160523.74258084496);
    this->wNlFKcMkhbjfWNG(1033317.2320890016);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lZqcaqZcH
{
public:
    bool UVopZuehUtuIpMpH;
    int qwLlGrDDDuILI;
    int HRUbWGUSaGGJyq;
    double QOTeSZcBtQ;
    double ORAPq;
    double jjMYV;

    lZqcaqZcH();
    bool SHmkzNDOzsL(int GQEiex, string CLAMUiQIQUerR, double jJCMwAOUMAYTKGGt);
    int PGGYWpNQ(double HBsBU);
protected:
    int WUrratbkf;
    double msIAkh;
    string ugefFSHLqrcgMdUW;
    double asKRaYaCGBRguxi;

    string SNAOkn(string gDeZtKYd, string balVMxPyy, double KhgJdgQ);
    double IsGCCxRrfvHye(double yHRPVcwehEwwiW);
    bool MqrtEL(string xCWMPCWCaa, int LxDbYTpoFUdYrd);
    double VtDMMxQIgqLg();
    void meopydj(int AVwICmczCYvJqzb, int koyHaQpSYTd);
private:
    string YUZdzWSIX;
    double EvHKCedghh;

};

bool lZqcaqZcH::SHmkzNDOzsL(int GQEiex, string CLAMUiQIQUerR, double jJCMwAOUMAYTKGGt)
{
    int gTMSsFhKWLZA = 1766465846;
    int JqXIOogvONonndDl = 472382381;
    string XusBeaUV = string("BkRRrwWjDDJVQWGOqgTVfoUSxMmUrfWTBCIVpMaZuAXTiWwaYXMzuchtxuBShVHirljHeoKHFeUpHteNVptyHDsclsBlpDdxlgk");
    string DKqXkLxQadRjGKYL = string("kbrtnKCrHCZijwHAQbvuqCYktWngqUrBcZqDMHyatRydjBLLmDokvvKeKUSjzjdLhKKQfqtBbmUbhJ");
    int oqpDmVoFYrmC = 1477949317;

    for (int ItZZBqKA = 982074045; ItZZBqKA > 0; ItZZBqKA--) {
        GQEiex /= gTMSsFhKWLZA;
        CLAMUiQIQUerR = XusBeaUV;
        DKqXkLxQadRjGKYL = DKqXkLxQadRjGKYL;
        CLAMUiQIQUerR += XusBeaUV;
        JqXIOogvONonndDl *= GQEiex;
        gTMSsFhKWLZA -= oqpDmVoFYrmC;
    }

    if (oqpDmVoFYrmC < 1766465846) {
        for (int OgvJeC = 1949404688; OgvJeC > 0; OgvJeC--) {
            JqXIOogvONonndDl = JqXIOogvONonndDl;
            XusBeaUV = DKqXkLxQadRjGKYL;
        }
    }

    if (JqXIOogvONonndDl == -1882653573) {
        for (int KqrBrprM = 1738291631; KqrBrprM > 0; KqrBrprM--) {
            gTMSsFhKWLZA += JqXIOogvONonndDl;
            GQEiex /= JqXIOogvONonndDl;
            GQEiex /= oqpDmVoFYrmC;
            oqpDmVoFYrmC *= oqpDmVoFYrmC;
        }
    }

    for (int rjoyPvOWJlnrPfRr = 394064385; rjoyPvOWJlnrPfRr > 0; rjoyPvOWJlnrPfRr--) {
        CLAMUiQIQUerR += CLAMUiQIQUerR;
        gTMSsFhKWLZA *= oqpDmVoFYrmC;
        gTMSsFhKWLZA = JqXIOogvONonndDl;
    }

    for (int gjetRDKTSKZadbp = 1300684885; gjetRDKTSKZadbp > 0; gjetRDKTSKZadbp--) {
        XusBeaUV += DKqXkLxQadRjGKYL;
        DKqXkLxQadRjGKYL += XusBeaUV;
    }

    return false;
}

int lZqcaqZcH::PGGYWpNQ(double HBsBU)
{
    int llTWsE = -443851791;
    double aeVmRjViQIxhKTTI = -832221.6438247354;

    if (aeVmRjViQIxhKTTI < 180452.06730541508) {
        for (int XdIvtRyiEolmEJpU = 2011447562; XdIvtRyiEolmEJpU > 0; XdIvtRyiEolmEJpU--) {
            aeVmRjViQIxhKTTI /= aeVmRjViQIxhKTTI;
            HBsBU = aeVmRjViQIxhKTTI;
            aeVmRjViQIxhKTTI = HBsBU;
            aeVmRjViQIxhKTTI /= aeVmRjViQIxhKTTI;
            aeVmRjViQIxhKTTI += aeVmRjViQIxhKTTI;
            aeVmRjViQIxhKTTI += HBsBU;
            HBsBU *= HBsBU;
        }
    }

    if (llTWsE == -443851791) {
        for (int sTemYUoFbAD = 1638145736; sTemYUoFbAD > 0; sTemYUoFbAD--) {
            aeVmRjViQIxhKTTI = HBsBU;
            HBsBU -= aeVmRjViQIxhKTTI;
            HBsBU += aeVmRjViQIxhKTTI;
            HBsBU = aeVmRjViQIxhKTTI;
        }
    }

    for (int fXTXGTKoimKOuC = 1567085660; fXTXGTKoimKOuC > 0; fXTXGTKoimKOuC--) {
        continue;
    }

    if (aeVmRjViQIxhKTTI <= 180452.06730541508) {
        for (int ZjuSNnWqVCa = 1379596666; ZjuSNnWqVCa > 0; ZjuSNnWqVCa--) {
            llTWsE += llTWsE;
            HBsBU += aeVmRjViQIxhKTTI;
        }
    }

    if (llTWsE <= -443851791) {
        for (int PeMNF = 2116206157; PeMNF > 0; PeMNF--) {
            HBsBU *= HBsBU;
            HBsBU -= aeVmRjViQIxhKTTI;
            aeVmRjViQIxhKTTI += HBsBU;
            HBsBU += aeVmRjViQIxhKTTI;
            aeVmRjViQIxhKTTI -= HBsBU;
        }
    }

    for (int JLbunMkzxkoyV = 1712252542; JLbunMkzxkoyV > 0; JLbunMkzxkoyV--) {
        HBsBU -= aeVmRjViQIxhKTTI;
        HBsBU += HBsBU;
    }

    if (HBsBU <= 180452.06730541508) {
        for (int TwFKnCE = 1036521861; TwFKnCE > 0; TwFKnCE--) {
            HBsBU -= HBsBU;
        }
    }

    for (int aftCKMoL = 1713014750; aftCKMoL > 0; aftCKMoL--) {
        aeVmRjViQIxhKTTI += aeVmRjViQIxhKTTI;
        HBsBU -= HBsBU;
        aeVmRjViQIxhKTTI = HBsBU;
        llTWsE -= llTWsE;
        HBsBU -= HBsBU;
        llTWsE *= llTWsE;
    }

    if (llTWsE < -443851791) {
        for (int HLhpHTwu = 709715378; HLhpHTwu > 0; HLhpHTwu--) {
            aeVmRjViQIxhKTTI = HBsBU;
        }
    }

    return llTWsE;
}

string lZqcaqZcH::SNAOkn(string gDeZtKYd, string balVMxPyy, double KhgJdgQ)
{
    double woLAAMYTYtW = -399816.142938664;
    bool AUKfStqpdeHctbq = false;
    string cTQBNhgplVY = string("dYjUCSsiDcWjuonxaaofirmYXnsmXNdSDjaddRenVLmKuRAFYsgcIfpjEQjYZcEMjmSEdEuJzBGnsqqhKRJqsgbQdYRKYpQZXftygKCceriYKJZSYSkQmGFUGRJdSsrgjTcHcNwiBuODMLZqVMmYKGVDiiVtUAuXdVFbDc");
    bool ZeUhQj = true;

    return cTQBNhgplVY;
}

double lZqcaqZcH::IsGCCxRrfvHye(double yHRPVcwehEwwiW)
{
    int wdOiMttAuxIpHmR = -618936501;
    string SdMdrZURT = string("VnpXNmpAGWaYVeSDtPRDKIikziHmekXzORqnLKafakEHWcREvvFeUNzNWBdNdKnMQUbrZUgGhCUHPJyZOXRdwWPUUzpWlFEVFgakKtkkAtdh");
    double dYktQWiiSW = -71152.31746395762;
    bool ptJWU = false;
    int PpgWrlDEOfdrxgy = -56099288;
    bool AKvHGMAiVFmRtZC = false;

    if (yHRPVcwehEwwiW > -71152.31746395762) {
        for (int syKCU = 1158220557; syKCU > 0; syKCU--) {
            dYktQWiiSW -= dYktQWiiSW;
            wdOiMttAuxIpHmR = PpgWrlDEOfdrxgy;
        }
    }

    return dYktQWiiSW;
}

bool lZqcaqZcH::MqrtEL(string xCWMPCWCaa, int LxDbYTpoFUdYrd)
{
    int SoOJJZlvWtGb = 281334053;

    return true;
}

double lZqcaqZcH::VtDMMxQIgqLg()
{
    bool fMdtnNEWWAckeBqC = true;
    int cetkkvH = -284657301;
    string QWaxI = string("AgXuahLSumxEi");

    for (int cZjbw = 461409892; cZjbw > 0; cZjbw--) {
        QWaxI = QWaxI;
        QWaxI = QWaxI;
        fMdtnNEWWAckeBqC = ! fMdtnNEWWAckeBqC;
        fMdtnNEWWAckeBqC = ! fMdtnNEWWAckeBqC;
        cetkkvH *= cetkkvH;
        cetkkvH -= cetkkvH;
    }

    return 590791.4500346471;
}

void lZqcaqZcH::meopydj(int AVwICmczCYvJqzb, int koyHaQpSYTd)
{
    string ODMgQ = string("XZXnzQuCKWtZcopZWMQldFSNeJMbpVrWLicRswKLBJlvasEZuAuCXYMcFBZdQsKfDnYFrVggdSHsYjNqcw");
    int iETgBh = 925381861;
    double bMjafvEAL = -651357.3367027163;
    int iTlIQHnkQ = -1021890735;
    string wpxDNkMjbz = string("wuzDcutAOekSYcAowcpCLequBQvGTbtkDEqLxJioFrHNUDhgRkbyyJaBZYYfNiidmoGcYyygrlXIbZsgTVXdJJmWDslgHUBnTwhnHzoqFVxyaKlYEZJfduGABFAjBeHuzbi");
    bool vcDiLtlhTyIfv = false;
    double uFjLxuIqRRWrXU = 413211.94306459057;
    bool oTodB = true;
    bool iSVNBmLJv = false;
    bool fACQjfFZLceSMeO = false;
}

lZqcaqZcH::lZqcaqZcH()
{
    this->SHmkzNDOzsL(-1882653573, string("kPUqwXFD"), -286784.8218768669);
    this->PGGYWpNQ(180452.06730541508);
    this->SNAOkn(string("imQcUbWneOUglKMzqAoyWtEyISfGnTglEAaHWPmVdLVDHDNEGFpXxbzQkgScljJPHsqGgGnRnNJKmWUsuImFVPApALfwUzaQAYpkefWENaSviRfNipKEJIPSJbDXJqIQoEiltEBvGEqrWvHzcepuKXOPzlZQsLmbMANDkPbjEdYaZdBUkcdguKhfvVIFBCpFTQCxoKLMuNMzhLcKEGtojUdfdjFDcmCl"), string("NGOMQgbUyXWuYLIqreWdgQYrNXlyjwQOSiuGZjHRzHfSUpVDwwJahsSJTUYKxswMYsOWBfIfmORIlDKgVtufkkAZxlCwwIsfhhJMdHgWZuzAcaaAPxZKbUWRWAVUUpUMYDQyAKAwhmhYexIIDqBSNQgJvUTSULDJaEllwPLcbtgJrkNSkKjlUfmrPlKdC"), -136887.80156712414);
    this->IsGCCxRrfvHye(-755109.5490150513);
    this->MqrtEL(string("GFRUTgLgqEFlvPhuFLFejLTslXxIyDqFeLIPBqhmTHsswlIZLbiQrvUcCQSyHponvJPWrcvYXHNDXefVFEcomTaqfBpwShSXsQHAqZWcn"), 1998236702);
    this->VtDMMxQIgqLg();
    this->meopydj(670648694, -290155055);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PdpXuDbrKsACEyY
{
public:
    int PBJtzNvY;
    string OMMKvPaqNJpjtJG;
    double kPIhHqBdNtncG;
    double bHXAnuWZ;
    int aFspU;
    double UyFxKcoKByKGI;

    PdpXuDbrKsACEyY();
protected:
    bool tNNtWbthIvTKU;
    string eSEQBS;
    string BxeEMXw;
    bool qjrIpnkRG;
    string wcOWLmjb;

    int ZSJDtohYEhqURaF(string vWTJmEVLGW, bool VOUuD, bool AjtJfKqS, int TkXIavmUziQvNtrf);
    double VhHYl(double vjQjTyBSdETGcfv, bool XjzcBHAmctc, string RNwhGTfTFXJoPPq, int xvtXfFiVdgll);
    bool ZQyAvMMbCmtonB(string mJBEIRTFDzh, double ACAcTNGCfFMxa, bool pLtEK, double WGrftlmbSQCnDt, bool WZhZwHs);
    bool SMcwwtgFzA(int lyJCQP, double OfsvEzNXoqFrzEJ, string CbFoG);
private:
    bool PpjzCdLZTwV;
    string fkyyWiePd;
    string WzBHxocG;
    int owDYHvaMsibXvAO;
    string IKPXdpugesnbelEd;
    string EYgPFxKAHRXHbQ;

    string inborOjvYqPZc(string GhxnKFwWLCFvj, bool GUjQQq);
};

int PdpXuDbrKsACEyY::ZSJDtohYEhqURaF(string vWTJmEVLGW, bool VOUuD, bool AjtJfKqS, int TkXIavmUziQvNtrf)
{
    string BGEoBAGbJu = string("MbRDCbIrUwrvMTXaAdStsYmlBritsNFxLgWtIoOjhCrpSZqmdRQDpuUCBCvSdpHTOBObTcqvsVEaKVpRiXzSxTzaDBfirzkZ");
    int JVtGqIOA = 1506395033;
    double CDYWdCeYIDgkvvLw = 614705.3681885464;
    string fpiwYy = string("zkIVtOZcTTvIxtLJWOasCcQarnsRKbevUokpVfSRSPIhBnYzMyUmWJUzZahMCmSUJDhTLHTZhkbDpxByYymtzkkcVpYIRpcptFrYUDPEkVfoihHLUUqnLNRNnXbKpEwoDbweTnpRQtFuXUdkqELXxTOegRLTCSCmkXBHlmptgqksSjujRzSuSiifycVJElOoMmcTabOtRgSXQdiunUEaHwMygvgXCOvImNuION");
    bool akXkRLE = false;
    int PRpTglCSjVKpuHMv = 1172362131;

    for (int uutSv = 805956033; uutSv > 0; uutSv--) {
        vWTJmEVLGW += vWTJmEVLGW;
    }

    for (int QEviCNnLaTyOtb = 821079957; QEviCNnLaTyOtb > 0; QEviCNnLaTyOtb--) {
        VOUuD = AjtJfKqS;
    }

    for (int lPVuyhSnc = 1225155523; lPVuyhSnc > 0; lPVuyhSnc--) {
        PRpTglCSjVKpuHMv -= JVtGqIOA;
        VOUuD = akXkRLE;
        AjtJfKqS = AjtJfKqS;
    }

    return PRpTglCSjVKpuHMv;
}

double PdpXuDbrKsACEyY::VhHYl(double vjQjTyBSdETGcfv, bool XjzcBHAmctc, string RNwhGTfTFXJoPPq, int xvtXfFiVdgll)
{
    string WOuxmHiwYgl = string("EZsVWdzrwIRDWSLSCCxymJXCqvQmvceMdNytVnBUARaAeUXLIyXAuKwjPeFfwVFTfLYhg");

    for (int FENSNulqvVCfhy = 2103068252; FENSNulqvVCfhy > 0; FENSNulqvVCfhy--) {
        vjQjTyBSdETGcfv -= vjQjTyBSdETGcfv;
    }

    return vjQjTyBSdETGcfv;
}

bool PdpXuDbrKsACEyY::ZQyAvMMbCmtonB(string mJBEIRTFDzh, double ACAcTNGCfFMxa, bool pLtEK, double WGrftlmbSQCnDt, bool WZhZwHs)
{
    string kUHYwPVywCwLEO = string("xjmJqobqrWTXgtLRVQDwVeGXrOBYQDMiiFrqaDvWxuhWjjfVoXtfFKORZvohBprKcYTKoUtoUtrtRcRb");
    string uKDoihwOR = string("raBscFVVyrnExeFqGMOUEHmCZdjUYC");
    bool YGAvcJPjnIjW = false;
    string JdRkAxzcdiHEglDR = string("iBqDxRRMfqSZZCwDhlAGaQGqLERcKcWdGOAwLFEBnsjQhBTMeOxxOrVNCaZpkHZLySELaSMkHhHnmHcyQiROCpVGRYaGndwGYWIfOknjAxQuXjayQbwlXsaJvwgwgun");
    int VNFVcppa = 391852649;
    string ojdBxxaggEQoMI = string("QgBtmQuPBaWNXUHvmzsEREXEleXlrNZnzqwmmdAlVWUriYlrPOLAzEkhCORGDVrpCLfROtVQaPhAITyQdZCekdviLOgPAeJciqOSnEDatbuvlXqSblENNRXsmSGVvwIRVvsGujeNQcmUGIBFKRnYsnuabxZShtMFWKTgeIlahlEdN");
    double oBkMLgtvSQpjfox = 498345.44957275956;
    bool ncgqed = true;
    bool KpPvqJDR = false;

    for (int SGnvEoYcusxuMdy = 1985353686; SGnvEoYcusxuMdy > 0; SGnvEoYcusxuMdy--) {
        kUHYwPVywCwLEO += uKDoihwOR;
        ncgqed = ! WZhZwHs;
        uKDoihwOR = uKDoihwOR;
        pLtEK = ! ncgqed;
    }

    return KpPvqJDR;
}

bool PdpXuDbrKsACEyY::SMcwwtgFzA(int lyJCQP, double OfsvEzNXoqFrzEJ, string CbFoG)
{
    double WmJFZBbnWq = -933736.6603508679;

    for (int TzkFBVpShhjKGF = 5719252; TzkFBVpShhjKGF > 0; TzkFBVpShhjKGF--) {
        WmJFZBbnWq += OfsvEzNXoqFrzEJ;
    }

    for (int NErHQnJAm = 1832221847; NErHQnJAm > 0; NErHQnJAm--) {
        WmJFZBbnWq /= OfsvEzNXoqFrzEJ;
    }

    if (lyJCQP != -840040405) {
        for (int IXAIUTJMcPcTHks = 1096100872; IXAIUTJMcPcTHks > 0; IXAIUTJMcPcTHks--) {
            CbFoG = CbFoG;
            CbFoG += CbFoG;
            WmJFZBbnWq = WmJFZBbnWq;
            OfsvEzNXoqFrzEJ /= WmJFZBbnWq;
        }
    }

    for (int AKoaHjZmlwseInzo = 1509579431; AKoaHjZmlwseInzo > 0; AKoaHjZmlwseInzo--) {
        lyJCQP = lyJCQP;
        WmJFZBbnWq -= WmJFZBbnWq;
    }

    return true;
}

string PdpXuDbrKsACEyY::inborOjvYqPZc(string GhxnKFwWLCFvj, bool GUjQQq)
{
    double ujTtnyDEH = 161750.2700858678;
    double cQroRP = -192121.54467753624;

    for (int mSciBMqSIZAioUTJ = 229306358; mSciBMqSIZAioUTJ > 0; mSciBMqSIZAioUTJ--) {
        continue;
    }

    for (int lQsDd = 775611735; lQsDd > 0; lQsDd--) {
        GUjQQq = GUjQQq;
        cQroRP += ujTtnyDEH;
    }

    for (int xmZKus = 533682172; xmZKus > 0; xmZKus--) {
        cQroRP = ujTtnyDEH;
        GUjQQq = GUjQQq;
        ujTtnyDEH -= cQroRP;
        cQroRP *= cQroRP;
    }

    return GhxnKFwWLCFvj;
}

PdpXuDbrKsACEyY::PdpXuDbrKsACEyY()
{
    this->ZSJDtohYEhqURaF(string("tzvb"), false, true, 1768353058);
    this->VhHYl(983336.738093321, false, string("AfmAUOObzxJWHEYZHLyzLLoGAVSQpRGXnxMxPs"), -951540974);
    this->ZQyAvMMbCmtonB(string("yZpTwvcMaXKAvYXGWtcPMjNIzuSLtsoyGbHKMZFzcNbrgjxKGiprALitSoeGvlGdtPXMCdNazupdsPNpjmuYXbaGnkCOnJefaleXKVnFdSNERyvGJwEODmlYlpskrmNrQIoxBbwPFiaFaggqYevImuolHjDsLPmXhspTvQBQXPsklTyBXwPcgJPfIFhjbxCGfXIDUvZjFgYYzFEweWAbpTvglnYrkzfx"), 233399.85376754578, true, 831451.6169944021, true);
    this->SMcwwtgFzA(-840040405, 1029298.0674157125, string("pzkSYicNbXnzOFtDkDAxpFTDhjIZgNvyadtAnbXLWnUwVsmQvCMQxFiRRrQYELmFhJkJiBmFoZDnPvQRetkKGdJlzVQLKXXCUqYYwirrYZPmVmzPRiGFOyhoVseSBEDRlbRoRnOUkzLgSyQUIZcceuOpllN"));
    this->inborOjvYqPZc(string("mESKQrTEUUEfvBtNStrBfVwbffdLvCIuxBgljWLBApxQdQmvuUQrUbkDMMIomiYzRpTpReawzGbIbZtqOFUmtyuOdopnOtNjKlgoImpudAFHmltZaqrNhGhmEUaJwuMHoWTQJwMYgoKwZkhfASNEKVNKDDppPSiABLecENWFqCqVIHlQmVVtwfHUhOEFUcTZJJzxITjNQskbVeDeEavYiNmfXjrxYcBrFDbPjbDCUUEJTQXLnxbOb"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TRMZwCWPCmvhTsif
{
public:
    bool bfEsQCciqbzHsj;
    double Skjmu;
    int orAqjLIHMppCn;
    string uWwoLGgWA;
    double pYEfnaE;

    TRMZwCWPCmvhTsif();
    double FUQSPRS(bool SrCJxeSJ, bool qskalfkC, string kHBhoQXCA, bool BzZQMCFJVGmdJ, string mTWmBkfjkhi);
protected:
    int bXhpvMa;
    bool RHaEgdH;

    string feRyUxKYe(double iyqoUbW, double MTeviUrACB, int XzqscXO, string jPCRVR);
    int YTbIY(double pgFlSGNw, string fQONZoyXDU, bool JLGsdMq, string dweCAPmQmJxOqPY);
    int pipmYCnZfC(bool CsaVxQHwbh, string ICfZTrfcr, string aoTAl, bool QXLWUGZXvMZ, double Luuzfh);
    double dVJduQT();
    double UohiWAQ(bool RXetRqXpdqRj, double JcOcup, bool TIWUAyoFXcSsyas, int UUeKzAc, int esrTj);
private:
    string eZyhEnPNXjKxjL;
    int ZvYmecBijknYSTOU;

};

double TRMZwCWPCmvhTsif::FUQSPRS(bool SrCJxeSJ, bool qskalfkC, string kHBhoQXCA, bool BzZQMCFJVGmdJ, string mTWmBkfjkhi)
{
    double ZvNCOpgVzmdS = 10342.133598794866;

    return ZvNCOpgVzmdS;
}

string TRMZwCWPCmvhTsif::feRyUxKYe(double iyqoUbW, double MTeviUrACB, int XzqscXO, string jPCRVR)
{
    string HKLkabXWXhl = string("MTkIwguIdWclohntSpHBjwZ");
    int IPUTZQLMVqIluxs = 1733793454;
    int FRtvMS = -305879315;
    bool vbXJIBjbPGWZjFDm = false;
    bool NkLSI = true;
    int xpsrc = -944871849;
    bool EEWLAGf = false;
    double QAsPlzksVNTMc = 521027.1926363845;

    for (int SINzkrfYDfzhh = 1814116135; SINzkrfYDfzhh > 0; SINzkrfYDfzhh--) {
        continue;
    }

    for (int pOSfzejqvUsoDM = 1257357379; pOSfzejqvUsoDM > 0; pOSfzejqvUsoDM--) {
        iyqoUbW *= QAsPlzksVNTMc;
        EEWLAGf = ! EEWLAGf;
    }

    for (int wXNuXDrAUn = 1532624268; wXNuXDrAUn > 0; wXNuXDrAUn--) {
        HKLkabXWXhl += HKLkabXWXhl;
    }

    for (int xTKdoMxqcvodAyw = 21014600; xTKdoMxqcvodAyw > 0; xTKdoMxqcvodAyw--) {
        MTeviUrACB = MTeviUrACB;
        vbXJIBjbPGWZjFDm = EEWLAGf;
        iyqoUbW += MTeviUrACB;
        NkLSI = EEWLAGf;
    }

    for (int AJDtg = 598383042; AJDtg > 0; AJDtg--) {
        QAsPlzksVNTMc /= iyqoUbW;
    }

    for (int WTCiTiPVI = 907500596; WTCiTiPVI > 0; WTCiTiPVI--) {
        MTeviUrACB += iyqoUbW;
    }

    return HKLkabXWXhl;
}

int TRMZwCWPCmvhTsif::YTbIY(double pgFlSGNw, string fQONZoyXDU, bool JLGsdMq, string dweCAPmQmJxOqPY)
{
    bool YgujtdR = true;
    bool uSRMuqnowZ = false;
    string pzjJcShq = string("wIBAaDEIxMAxNrRoahkVLSQhxRYAGOlJJsqdNuWwmRcrZPtTUTqMYLmSPGlyamBYsmQJmzkkkyjnjPlmLgVpHnCefdVVPeaWdfuaXHelWuotHHPjrnlewLt");
    string xKlsAAvCzklyw = string("GmxjMObDIEqjqwdEDATbumnuLrQKaogOfyYDUhmKKiKOfLSxClhFknUVIJKqMLKeiibWNyGMCEmJrENZBjiKwYUsxmhDNlRsssXeYuKDMOPPcaekrBiOCMxspdhVMQAYZLjsoGfqBfPemDCGwvCeLdZMrViOvDiJaFgzdZPjmEwromyJSGScFEFRIHWHteLZXchCshKBin");
    bool GYWmPp = true;
    int cNYkBtjBsXkn = -2094277653;
    int CDgTsY = 1750880576;
    bool ZGGwJu = true;
    int tsGYqqcCYZAsfM = -516264901;
    int INvsKsOEMDXj = 891744360;

    for (int iyTOdHXOVtnITU = 1538346549; iyTOdHXOVtnITU > 0; iyTOdHXOVtnITU--) {
        YgujtdR = ! uSRMuqnowZ;
    }

    for (int DGIiwWIPGNi = 126619929; DGIiwWIPGNi > 0; DGIiwWIPGNi--) {
        INvsKsOEMDXj -= INvsKsOEMDXj;
    }

    for (int iZsvKUuEGLJx = 1802748331; iZsvKUuEGLJx > 0; iZsvKUuEGLJx--) {
        continue;
    }

    for (int YsdLJwiPOhctb = 471956420; YsdLJwiPOhctb > 0; YsdLJwiPOhctb--) {
        YgujtdR = ZGGwJu;
    }

    return INvsKsOEMDXj;
}

int TRMZwCWPCmvhTsif::pipmYCnZfC(bool CsaVxQHwbh, string ICfZTrfcr, string aoTAl, bool QXLWUGZXvMZ, double Luuzfh)
{
    int ZHETvO = 833416981;
    double muebTWkZaIa = -624985.8638975095;
    double YeewVlKXYzisXsdw = 850168.7007036867;

    for (int WDOWRrYnY = 65528652; WDOWRrYnY > 0; WDOWRrYnY--) {
        Luuzfh /= muebTWkZaIa;
    }

    return ZHETvO;
}

double TRMZwCWPCmvhTsif::dVJduQT()
{
    bool oRGPEAckHUezvhv = false;
    double NzfwR = 594885.2667835314;
    bool NSdosBjy = true;
    double OKWMBOd = 739669.6752873411;
    bool ZUxUkiLrPw = true;
    string GGMPSeJdAlVJMXJ = string("drwFkSoYGDvkSeVDMCwEvnAGIHOpYQsSEtGfRmXxwcXBfKJoBxYhsnqSPSTyBQysRKnVTRaqbeEdHhkrLYWNaVSzQXJIcZRxpdNlMCYBvtqxjsvgYwRRVbTfELaSxRGrqhaXGcUTRPpDFkbimuarOYsDKsbicKiQXXjfPPpUhqqYjBCHlOsjZAqAptDdGPrUfPkHQqswOoSzIfhvheHTsYCMuEpiLCSZFhtoxNZpzwgYJbrFRrV");
    int XBECIVdMJ = -261055482;
    double acsMh = -828720.2037584096;

    for (int MjVuPOovhEqsHacS = 1310927905; MjVuPOovhEqsHacS > 0; MjVuPOovhEqsHacS--) {
        NSdosBjy = ! ZUxUkiLrPw;
    }

    for (int xHtNkNJqtGYW = 384664900; xHtNkNJqtGYW > 0; xHtNkNJqtGYW--) {
        acsMh *= acsMh;
        ZUxUkiLrPw = ZUxUkiLrPw;
        ZUxUkiLrPw = NSdosBjy;
        oRGPEAckHUezvhv = NSdosBjy;
    }

    return acsMh;
}

double TRMZwCWPCmvhTsif::UohiWAQ(bool RXetRqXpdqRj, double JcOcup, bool TIWUAyoFXcSsyas, int UUeKzAc, int esrTj)
{
    double ZxZofyejEDP = -494868.9886685564;
    int aJFegHinuL = -307705481;
    bool VHrWdFK = true;
    double UJzZiZfUNfVcOpLi = -859729.9650256082;
    int JhYUYTCxfDpvCYe = 2139345938;
    bool mfFqwVh = true;
    double aTedINcFE = -304582.56312591047;
    bool aJgBy = false;

    for (int hUVRXu = 1600739494; hUVRXu > 0; hUVRXu--) {
        TIWUAyoFXcSsyas = ! RXetRqXpdqRj;
    }

    for (int ywiGtPCMqNkTRRME = 1472539459; ywiGtPCMqNkTRRME > 0; ywiGtPCMqNkTRRME--) {
        VHrWdFK = ! aJgBy;
    }

    for (int emHaRCsvp = 316018069; emHaRCsvp > 0; emHaRCsvp--) {
        esrTj /= aJFegHinuL;
    }

    return aTedINcFE;
}

TRMZwCWPCmvhTsif::TRMZwCWPCmvhTsif()
{
    this->FUQSPRS(true, false, string("FIlyrqWJGndRKyXwkSTvaqlzeCDEYhzvmmiAerBxdRPwVRMVuvvBroOftbUPvWmXkvPrwltshTnwtYUCHqSsJYQUlgpVGIEZJaunqCmBMYZDtxtxcjrEfkJIFQkKUEdUJBFAEIC"), false, string("iNsgwImrRBhkVZGvzMssMjiqGtKACIPiurmDhATQXLXdCgyOUgVrRUkjmutYIjkPkwjYWKkTFaEs"));
    this->feRyUxKYe(-1041676.4053352989, -337694.8724890793, -1477905487, string("idmOWQuxeyXPfjskedLNcoGVMcuEFogTqcXUjJPrtiOaYcDtAOUkLyzgzsPKmCqWByNGZAfAchLfjqZADMTIduqFoxHlSKqaiMetBDWIFxiBPocgOCYdaQABkJUivJwgoQJuaXRfRdfNrrFnYxiLepYdPNzaEhQQCvgMfTeIsRhVlfuTLDWSKBAFLFnWzMQVOWFmREzqZxtaLRePLWmBHXazg"));
    this->YTbIY(-708473.5981944147, string("ThMQBVljzaQpUIWhqWrQGvUSaSpusIRlMwfgF"), false, string("wkFoPIYKRFuoLyNykqRmSqwHMoBviBvKvkocXEcKazmmokucAHWzIQhoqIQrJyLDUArzchOxTuFyzwhZbRppIYgscMmrvVkaxpcQoimaUsddd"));
    this->pipmYCnZfC(true, string("BmzoVDazuUbMoBGtxhHnRdYtaxCmqePDqUhpIEwygYywKTsOWbBMkhnRLEqvystpzlKsYqeqPDCAGanWhJSjRVyPiLMbARKjLtOfPgfRmCaPQZDHsDpDlftcYsZHvRWvUCFgqGFuZvfuzVQXhYDrtXcRmusyhyLdTqNnaAsOToMtGgIwivZFKnweGRHhaEwMlVsXrovzvquxomcgUOMeRzPYLrhDgdoXVoqZySMLKUfOBYuwfZn"), string("RjzfWSYuJkymbIFVqWPCbXyOjacbmqBdwJXgJMmiuSSkOScqNIXGiXIZzpAYFerOTvbXKgRpQulQhcsmccAGqSYdHkAqYNzxzIfDIKWHtrDeFBmndAfvcblVveTXBewrMCDXEGxSeaZhjsTriTQuSMkPKdMreevIFSZZggwcpsoInAwQndmoczCcrxdzRmFamAMjxFsODjmkCSHixrhKpcGBghWCoZfaBkD"), false, -376511.0409823954);
    this->dVJduQT();
    this->UohiWAQ(false, 891898.9527299248, true, -64790298, 1166390551);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hlEjUhAFdrGqz
{
public:
    int HVaJJYvVvCJP;
    double sfXxFVGl;

    hlEjUhAFdrGqz();
    double iGXiAdbrQB(bool NdVNwyNHVHTuzw, int wCBOFAPPOHLDBaC, double LOYwusyCMRnntxFB);
    double rDxZYcDIkkWI(int iZDYdXT, string IOvJJyO, string uVHIcjG, int LBsgdV);
    bool gJfwAfNEquRGJjdq(bool oUkPxuBaahDbvX, bool dtgQdHqhnGo);
    bool LvSXWvr(double oSLhbmVaqVHZV, double dDRhmGYdISdLfKZ);
    bool PeVsepJrEpiXQNH(double mBqIFEZAq);
    string rOgjlPZElK();
    void GpGwOpNfdnBd(string YBmCNhcNzQOqRHF);
    int kHpeyAXIxWFXrK(bool hyRyX, double DjctUaLykr, string LcUftSJcR);
protected:
    int NpHmBUK;
    int nInZyQ;

    bool nmrousA(int kJfUjUsdIjsEWHI, int YURPIWT, double gOZLwLxCWIsFWf);
    double qUeKpcpF(int SYLMDtKfNZFr, int mryhgKCNyonYlO);
    void EXdLxUJqssjd(int aawanToPyLWd, int SZQUnB, string aGEXLR, int TShVjbGPuzDXyxo);
private:
    bool RVzvtrJusbqJKwqL;
    string SSfcAYbxCAqyGwOF;
    int zEtflr;

    bool LtZyCuvZ(double UkfmqDASTdNydjrh, double oNRzoWPwDoK, int iQgrVpxHs, double fZJjkhchAuogaafs, double FiHZQdT);
    bool MlXvgdkbguBRDkm(double RrAJKlNuZApJWckv, double sGrehLZrBJMZaMh, bool mYnYwj);
    int CCyecMu(bool MWgUljPmPBqeHzDz, int jZYmKsYdy, double fsOFpURVNOytWo, string cJiAzuha);
    int cNuIsbwJjddho(string HYHlM, bool xbTFUvCdDl, string UJTFDqVpuJK, int zVAencLqWpJQwn, string fUNTRuMuvTDswn);
    void SUMpacAENmo(double jPtjhpumVqBR, int kqJEvInCFrMg, int ZUocWYHlXcWtiAPT, string cSOMbGiFI, string nawkVqZNqNgxpW);
    string OZokLh();
    void EPaeYIULw(string pvOzrwU, string jCifuBwml);
};

double hlEjUhAFdrGqz::iGXiAdbrQB(bool NdVNwyNHVHTuzw, int wCBOFAPPOHLDBaC, double LOYwusyCMRnntxFB)
{
    double fUOaeVMRzxfqDzwR = 326096.96717473934;
    double KcHTwKs = 194456.34055402293;
    double tGigv = -473428.99108629726;
    bool luXaWssS = true;
    bool JHSLENfyOmDlN = false;

    for (int utwsiUjTqzC = 140317340; utwsiUjTqzC > 0; utwsiUjTqzC--) {
        KcHTwKs -= KcHTwKs;
        LOYwusyCMRnntxFB += LOYwusyCMRnntxFB;
    }

    for (int KujkLsP = 998097852; KujkLsP > 0; KujkLsP--) {
        luXaWssS = NdVNwyNHVHTuzw;
        NdVNwyNHVHTuzw = ! NdVNwyNHVHTuzw;
    }

    if (fUOaeVMRzxfqDzwR > 204996.5183888158) {
        for (int xrvaHtnUrMIPXB = 706221077; xrvaHtnUrMIPXB > 0; xrvaHtnUrMIPXB--) {
            LOYwusyCMRnntxFB *= tGigv;
            KcHTwKs *= tGigv;
        }
    }

    return tGigv;
}

double hlEjUhAFdrGqz::rDxZYcDIkkWI(int iZDYdXT, string IOvJJyO, string uVHIcjG, int LBsgdV)
{
    double HIAoxUtwPenuxfgQ = -449173.2605236127;

    for (int MVgGYQTLMgBoUYWi = 832761944; MVgGYQTLMgBoUYWi > 0; MVgGYQTLMgBoUYWi--) {
        continue;
    }

    for (int lwYWPIOSYkZpkT = 495356098; lwYWPIOSYkZpkT > 0; lwYWPIOSYkZpkT--) {
        uVHIcjG = uVHIcjG;
        iZDYdXT = iZDYdXT;
        LBsgdV *= iZDYdXT;
    }

    return HIAoxUtwPenuxfgQ;
}

bool hlEjUhAFdrGqz::gJfwAfNEquRGJjdq(bool oUkPxuBaahDbvX, bool dtgQdHqhnGo)
{
    bool URdBqObzOUHLkK = false;
    bool OLfDbUyh = false;
    double SOHmgbYwwBSeQB = 453361.8282180311;
    double aRpWeVtIJvAxJlof = -904141.4816474102;
    double aRWcQtnx = -880817.8421960463;
    int nNKTDRgjmWLi = -2018317012;
    string hjyUkGJLzf = string("CFweYzDLnNQfaDnblvIjZwAkaZBYNTbW");
    bool rsIaMBT = true;
    string vcUYqBnbWlGFYHh = string("dpBisrBhNXZkdurextmHVAcNjVDFfOavQpcsyAHnkFSUielZTZlLGucCzXrMTmoPeNVCTJgjQlbkfPJVNfOnfKzvadOaEbOybZAvLFHdijyyjAHRswjGRDoDMuOvxWZxLkZxliHDHMcHqQWGsamftMwIwBvysDBZDjMosLbYeJKxqZbzTgVugGRTOBBOdSKiirLOvmoaJwtinMWtlitbOuNGUxy");
    bool UkrwzsEe = false;

    for (int YYbZmKpQQX = 1382539011; YYbZmKpQQX > 0; YYbZmKpQQX--) {
        OLfDbUyh = ! URdBqObzOUHLkK;
    }

    return UkrwzsEe;
}

bool hlEjUhAFdrGqz::LvSXWvr(double oSLhbmVaqVHZV, double dDRhmGYdISdLfKZ)
{
    double yRHhUpjMZnuj = 784088.0496749984;
    double RwMXUdbSjiAdTdd = -515256.32331674034;
    string RiiUu = string("aZXtPoADEXZfSdDClWKwrmdCVTImztdKrBVUehtTRVXxtzMgmGxlpXTEyrXqsYSISmcdNoMCvVgjqsPKXdfRLnhBxBSIjCFzpypiBbPozkDRJcFpeDPyFPpfLWiKBpZMJwCtUwuBEnpuwQotnFuZkQPIRhAMfXFXvSXuUSsEPzwSTudKUeiwISTGecYQYuZWAbFZMNVckiqMwYopUclmdGpfUcYVULdbTSCvKNlywmwSGv");
    int VvegYG = -2019628772;
    double UcaFpHVLGiqXdP = 5354.556282568146;
    int WxbGFxFhdc = 50663959;

    for (int NYExzZAZ = 651425755; NYExzZAZ > 0; NYExzZAZ--) {
        yRHhUpjMZnuj = oSLhbmVaqVHZV;
        yRHhUpjMZnuj /= UcaFpHVLGiqXdP;
        RwMXUdbSjiAdTdd /= UcaFpHVLGiqXdP;
    }

    for (int kbLiiRgC = 644784314; kbLiiRgC > 0; kbLiiRgC--) {
        RwMXUdbSjiAdTdd += UcaFpHVLGiqXdP;
    }

    if (VvegYG <= 50663959) {
        for (int yUzFLMSciZhlQGo = 939988346; yUzFLMSciZhlQGo > 0; yUzFLMSciZhlQGo--) {
            RwMXUdbSjiAdTdd = UcaFpHVLGiqXdP;
            dDRhmGYdISdLfKZ = oSLhbmVaqVHZV;
            dDRhmGYdISdLfKZ += UcaFpHVLGiqXdP;
        }
    }

    for (int JQiOOxz = 322910351; JQiOOxz > 0; JQiOOxz--) {
        VvegYG = VvegYG;
        oSLhbmVaqVHZV -= dDRhmGYdISdLfKZ;
        RwMXUdbSjiAdTdd -= RwMXUdbSjiAdTdd;
        RwMXUdbSjiAdTdd /= RwMXUdbSjiAdTdd;
    }

    if (RiiUu >= string("aZXtPoADEXZfSdDClWKwrmdCVTImztdKrBVUehtTRVXxtzMgmGxlpXTEyrXqsYSISmcdNoMCvVgjqsPKXdfRLnhBxBSIjCFzpypiBbPozkDRJcFpeDPyFPpfLWiKBpZMJwCtUwuBEnpuwQotnFuZkQPIRhAMfXFXvSXuUSsEPzwSTudKUeiwISTGecYQYuZWAbFZMNVckiqMwYopUclmdGpfUcYVULdbTSCvKNlywmwSGv")) {
        for (int KkPWJEPoVyBC = 1212141876; KkPWJEPoVyBC > 0; KkPWJEPoVyBC--) {
            VvegYG = VvegYG;
            dDRhmGYdISdLfKZ -= oSLhbmVaqVHZV;
        }
    }

    return false;
}

bool hlEjUhAFdrGqz::PeVsepJrEpiXQNH(double mBqIFEZAq)
{
    double GBBsmjQJawGMn = -501328.4477526327;
    string UaDjCvnZbYRB = string("GhcRIUaRmDcuskvIVDHlGwMhizMrmosYlkvjfkKdxImjDMSGmuRGukzYYFEaMHKvxMRzuMylcGSpgBIXuMIUsuZQsXvegQyXTyyIaynBYkHwSxMCFLIWZeMIhLfRWobrKUxgFhpBIFAwSlcTxweRFVNDFZkcsyvwAtlDuPlbGxkHjlYejIFIvjHugyyKvfLlwOOSaXyDCGaGhwRORbfzAqNTvYbTSWCMVMmjJMHoanBkVEoVGWdzOvJdQhEkmI");
    int JuHNTihfYVvNS = 761334108;
    bool JgacIJdknAb = true;
    string ggJHWbuJskgLG = string("exZtgErYItXgoRYXjwSPxwNSMbAGbaNglURXRcDLUzRVGNqbXnMumUUYoJaFyquXPYMdgWaKgDJXKQVttrDvfTvLttiypIRyEqJdaPoOybmDcQXbInOsEzqJZVWMtCkxdRNIHkeAWnjxkcYxlbiWmBpOlJQGVggkGutkEBSedVLKvPKeuPBYySucrtEKKTdeubaDWkNrM");
    string QfOasQE = string("zeYjhINhpLSUFJQGamwHjuxxZZrAojfBBcZnrXkQc");
    string ZWVhlOzlYrMfxi = string("gFgGvTiBqIqLxMiGEUWxoQTqqWDJaCoQhRyIROJwxwaubVyC");

    if (QfOasQE >= string("gFgGvTiBqIqLxMiGEUWxoQTqqWDJaCoQhRyIROJwxwaubVyC")) {
        for (int CYKxbWXjxl = 803529705; CYKxbWXjxl > 0; CYKxbWXjxl--) {
            UaDjCvnZbYRB = ZWVhlOzlYrMfxi;
            QfOasQE = UaDjCvnZbYRB;
        }
    }

    if (UaDjCvnZbYRB == string("exZtgErYItXgoRYXjwSPxwNSMbAGbaNglURXRcDLUzRVGNqbXnMumUUYoJaFyquXPYMdgWaKgDJXKQVttrDvfTvLttiypIRyEqJdaPoOybmDcQXbInOsEzqJZVWMtCkxdRNIHkeAWnjxkcYxlbiWmBpOlJQGVggkGutkEBSedVLKvPKeuPBYySucrtEKKTdeubaDWkNrM")) {
        for (int RhhRp = 53444226; RhhRp > 0; RhhRp--) {
            UaDjCvnZbYRB += QfOasQE;
            JuHNTihfYVvNS *= JuHNTihfYVvNS;
            ggJHWbuJskgLG = ggJHWbuJskgLG;
        }
    }

    for (int BvpGXKgiK = 1079769042; BvpGXKgiK > 0; BvpGXKgiK--) {
        JgacIJdknAb = ! JgacIJdknAb;
    }

    if (UaDjCvnZbYRB != string("GhcRIUaRmDcuskvIVDHlGwMhizMrmosYlkvjfkKdxImjDMSGmuRGukzYYFEaMHKvxMRzuMylcGSpgBIXuMIUsuZQsXvegQyXTyyIaynBYkHwSxMCFLIWZeMIhLfRWobrKUxgFhpBIFAwSlcTxweRFVNDFZkcsyvwAtlDuPlbGxkHjlYejIFIvjHugyyKvfLlwOOSaXyDCGaGhwRORbfzAqNTvYbTSWCMVMmjJMHoanBkVEoVGWdzOvJdQhEkmI")) {
        for (int WhiOKdMh = 827800991; WhiOKdMh > 0; WhiOKdMh--) {
            UaDjCvnZbYRB = ggJHWbuJskgLG;
            UaDjCvnZbYRB = QfOasQE;
        }
    }

    for (int SWmhUyMHoVPIh = 263506496; SWmhUyMHoVPIh > 0; SWmhUyMHoVPIh--) {
        QfOasQE = QfOasQE;
        UaDjCvnZbYRB += QfOasQE;
    }

    return JgacIJdknAb;
}

string hlEjUhAFdrGqz::rOgjlPZElK()
{
    string NKbkiD = string("AJJDdPaeGMAKhMoAjrbjKoso");
    string xqAxBRKf = string("eeOOlfXeGRYFzBAAbcIqDPYIvUYptjoxrRQMSqrRApZlBLLWuTIThVhTRapGogCtYUbLmAYXkwwMVeOcuuXVhNANqSwpxAZTXsbjubOkZXhqXIxItJfKgSYhPSyyvUabytGMTrZpRfsHVTkYbJMDUKvhOTrejFewmFlQOoBsLUAmzSLTUkexQXmRMDYQhDHkMnzFaSKlHkyRIxjUBtdqygBaHrSRnAnDYWKdTvbmxuDHeQmRWpgohDonhVKBv");
    bool YHJbvzAyGtuw = false;
    bool DIKZYIAMMjE = false;
    bool cwlNJ = false;
    string zOxJhvQyHw = string("kZEkrDgQsVhnMOXdMYyvjpshcJLsXvufaHxrNlgJriuHtRVnuwDnWTPWVTx");
    int hQlzArMjUfLAkl = -909307729;
    string OKheU = string("LCfCSpbcfhVBNCReAuqluiXIzZCZWDvjHLcpLKgYCXcbyEIbVrMKsmoaaahhFMOWXGznzWNRRxgRFEzJPYXzdkoaqXccylCXlqIEcacqsVFLsfGvbH");

    for (int svgVZcqfVxu = 431202257; svgVZcqfVxu > 0; svgVZcqfVxu--) {
        DIKZYIAMMjE = YHJbvzAyGtuw;
    }

    for (int pdaLVaJKc = 299511070; pdaLVaJKc > 0; pdaLVaJKc--) {
        NKbkiD = zOxJhvQyHw;
    }

    for (int WnwFXWyaNWIeH = 977700106; WnwFXWyaNWIeH > 0; WnwFXWyaNWIeH--) {
        DIKZYIAMMjE = ! YHJbvzAyGtuw;
    }

    return OKheU;
}

void hlEjUhAFdrGqz::GpGwOpNfdnBd(string YBmCNhcNzQOqRHF)
{
    bool gnHrAYvnIPJmSvOG = true;
    bool kotPMeQEuPJYE = true;
    double YPueaDlt = 961375.4251715745;
    bool GfuQYuWxdeAhgv = false;
    double TxwxzKeTaUZ = 673024.7179368436;
    bool qaROsaDEWcGf = false;
    int tNTtwFNgmYxdS = -429674829;
    int cpatybl = 1481178206;
    bool jdhbAPN = true;

    for (int tpUptcumuN = 1889926454; tpUptcumuN > 0; tpUptcumuN--) {
        TxwxzKeTaUZ /= YPueaDlt;
        GfuQYuWxdeAhgv = ! GfuQYuWxdeAhgv;
        jdhbAPN = gnHrAYvnIPJmSvOG;
        TxwxzKeTaUZ /= YPueaDlt;
    }
}

int hlEjUhAFdrGqz::kHpeyAXIxWFXrK(bool hyRyX, double DjctUaLykr, string LcUftSJcR)
{
    int OzUgTDRTBaEF = 81363587;
    double ZyVvBlxPr = -401231.8630064259;
    int qPruLEgoN = -1776154021;
    double iCOGEXHhFTRi = 2565.1664935090243;
    int RgXKNfT = -1283232039;
    double QDcmcaLuLxn = 602732.3331989872;
    int ubJbcIAYqG = 1549769889;
    double frTBPRn = 593386.9675454637;
    bool tiJlApAhADMEUS = true;
    bool ByayUo = true;

    for (int ojzDiHXPuLR = 2118340031; ojzDiHXPuLR > 0; ojzDiHXPuLR--) {
        qPruLEgoN /= RgXKNfT;
        qPruLEgoN *= qPruLEgoN;
        ZyVvBlxPr -= DjctUaLykr;
    }

    for (int wzaIoAdWEnSo = 284500073; wzaIoAdWEnSo > 0; wzaIoAdWEnSo--) {
        tiJlApAhADMEUS = hyRyX;
    }

    for (int QFfpLJ = 831821447; QFfpLJ > 0; QFfpLJ--) {
        continue;
    }

    for (int qlfojOfZNFsL = 1916334996; qlfojOfZNFsL > 0; qlfojOfZNFsL--) {
        RgXKNfT += RgXKNfT;
        DjctUaLykr -= DjctUaLykr;
        ZyVvBlxPr += iCOGEXHhFTRi;
    }

    return ubJbcIAYqG;
}

bool hlEjUhAFdrGqz::nmrousA(int kJfUjUsdIjsEWHI, int YURPIWT, double gOZLwLxCWIsFWf)
{
    string fyQrZzuJMDxaIo = string("QHWfCWmlrDfKXhkjBVPeVcVngeyZWwUXXRrJoblqjoBWiOWSihsmgpbgyuUqYhHtGiJSSUbTfCavCLwVEJtplXZBzwPmiqeCPUwKeajwCNdnhisVINNlWgeallZNhDNBnaAhQLTdKvMOlEqjiwAVcbmsmhUvEGhRQjoJReHgJeoeitqnmeXzOmBNXvZozjLpqNaoRQBNVZIzbIkMCwlCxWoZqaIJs");
    int nlTMnyYtag = -750778094;
    string HPmqah = string("RRCcJoIZKTRJePYv");
    string AQBndYGKgGg = string("MUbsoSjKqRVXSjOcPgDCwFyNZaIaZxNhzOJiTbpRGhjvlmZUDCSmPRckprUSRVrBflifBUTRqEidOovrpxVKyrnapdLQkUaGnXqgpMjDszAVZCzJvZyoTyARIIXTuvrWYWoRDfqieXBBTjAqeNbFbCIPqcwHXTATOjDYkNoZmoHpGOmhWYjPLNaWVbIrIEUHvRPlSrwGryQhzjnBXECiF");
    bool bHyTQpmCmwbc = false;

    if (kJfUjUsdIjsEWHI <= 1442663024) {
        for (int WQFMjrBitNvzLht = 753377917; WQFMjrBitNvzLht > 0; WQFMjrBitNvzLht--) {
            HPmqah = HPmqah;
        }
    }

    return bHyTQpmCmwbc;
}

double hlEjUhAFdrGqz::qUeKpcpF(int SYLMDtKfNZFr, int mryhgKCNyonYlO)
{
    string fUXBOxE = string("RrlGgPlptWMaqIaKdLRwWJfhbGpUrscMeYgpWaIZJJoulsGrxNvvaKuQhskDHSaAENJzPmWmXokgtQIDbrqhWXudaOPnmaToMOjDctEpREwZRppgukcaujdEFukqcPJkvQfyUWJxZEOAgEwEXadbEmTijsvJtUtGZsxgJzizwQPgZiYcXIjBxvigZuRiqFyGQfsTwzciBMyXHKOMyIeDnRhChJ");
    double aeoKdbJfXj = -153917.45107107877;

    return aeoKdbJfXj;
}

void hlEjUhAFdrGqz::EXdLxUJqssjd(int aawanToPyLWd, int SZQUnB, string aGEXLR, int TShVjbGPuzDXyxo)
{
    string TibGfYnnpoXh = string("XJxaOvutwQyqgghdgpjwdZggnaEOzkLvcLQIFxuUkvZDwLjlocpODWDfzjoCSdHrCdPpHlIqGWmwgrCwRVMRPkYScMPNtOFVzkiLijRJzbVOyPcKcHEnQuzoGvWPBzSspFENCFzkN");
    int SbhYDKFByx = -122198174;
    string VShqljRVa = string("DnyZRLDCPQkhloRsYXhNDtKLveYbfankClwcdPwlanYqhaqCPmpztZOksVghfbLMyxnaxBZhDPqdwEXMvBtTmdouhOzxzEUqNEBBcyVCtKWhLWyXynleKBHhHtOYyauxIolWrhJQRigTfmWNqdiLtokIfYTilgnbRGPVnAJuYWRojUoyQmWLfwxczcFBrJXNHrlrDFqjUAoEyJuKStODufmYjhpJHXiead");

    if (aGEXLR >= string("XJxaOvutwQyqgghdgpjwdZggnaEOzkLvcLQIFxuUkvZDwLjlocpODWDfzjoCSdHrCdPpHlIqGWmwgrCwRVMRPkYScMPNtOFVzkiLijRJzbVOyPcKcHEnQuzoGvWPBzSspFENCFzkN")) {
        for (int PGJEVXbIn = 346237400; PGJEVXbIn > 0; PGJEVXbIn--) {
            VShqljRVa = aGEXLR;
        }
    }

    if (TibGfYnnpoXh < string("yzlmeWgJvmWqEzKPkUlwSxFiQjnghVTSvIMlbhBHxWEqxSGnyWOxrdLuN")) {
        for (int xOmMTxhHLRMtz = 1956368977; xOmMTxhHLRMtz > 0; xOmMTxhHLRMtz--) {
            aawanToPyLWd -= TShVjbGPuzDXyxo;
        }
    }
}

bool hlEjUhAFdrGqz::LtZyCuvZ(double UkfmqDASTdNydjrh, double oNRzoWPwDoK, int iQgrVpxHs, double fZJjkhchAuogaafs, double FiHZQdT)
{
    string SgMNCqRsfxqdn = string("oOzWIadGUeeaEAQjZZaDqKlSznnHlDHcmEHejiecAOFLYxYoFplVaykpWFxrdLwxKZUQEzWXNyiVbYbiBCQWpriXZV");
    double IOieSAoLCmE = 563625.8356037445;
    double OGGCT = 1010127.4072518583;
    string nvQHwHjeSwFYV = string("HLIKibqLhwzHWRFYzZZBMwbeirsdxzsgT");
    double UAGRiBRRalsWUYWb = 907954.9265163495;
    bool GTEIH = false;
    string ZrYhBrcP = string("dSLwFPkCR");
    bool yQbYrARtzmZdJIwI = true;
    bool IgUXLbkSUXK = true;
    int OMWFyxkHIHALtDUt = -530591616;

    for (int AbEXxzMxxFvKV = 137590444; AbEXxzMxxFvKV > 0; AbEXxzMxxFvKV--) {
        FiHZQdT = FiHZQdT;
        oNRzoWPwDoK -= FiHZQdT;
        IOieSAoLCmE = oNRzoWPwDoK;
    }

    return IgUXLbkSUXK;
}

bool hlEjUhAFdrGqz::MlXvgdkbguBRDkm(double RrAJKlNuZApJWckv, double sGrehLZrBJMZaMh, bool mYnYwj)
{
    bool yuYVXpBlZFZCHMOP = false;
    int EZXstuUBOdU = 466097327;
    double QEJPytnqUfYg = -352208.5265621723;
    int POjrRKIcXpYH = 963103251;
    bool vxbom = true;
    bool zmFFkxRi = false;
    double BVYDShfIpH = 87093.25914869201;
    string nrgZZxSi = string("KEtGoeEgKwMeiyDkogespNmNSXeqgVUnzufgYigzEqVCsQdPtyDEFiTsEWlWwGHslvSJCYetPTIPhibLDYYvCaTnzTsGmtLbjToiYMZAjGcbgXNeEgZxWwhYfhdSSSTUnIcoCcoovfrMtTkeXIzckfaFRymFCoHZzRhousjHgxiZhMfsMtMS");
    double goWvnkpNxMyapj = -325108.3020683504;

    if (RrAJKlNuZApJWckv <= -262438.0742782198) {
        for (int aJBPdYhsNOGlGCIR = 1350555173; aJBPdYhsNOGlGCIR > 0; aJBPdYhsNOGlGCIR--) {
            continue;
        }
    }

    for (int vbVpN = 1647242441; vbVpN > 0; vbVpN--) {
        mYnYwj = vxbom;
    }

    for (int DvXtHO = 600888526; DvXtHO > 0; DvXtHO--) {
        goWvnkpNxMyapj -= BVYDShfIpH;
        vxbom = ! vxbom;
        sGrehLZrBJMZaMh += goWvnkpNxMyapj;
        BVYDShfIpH = RrAJKlNuZApJWckv;
        vxbom = mYnYwj;
    }

    if (mYnYwj == false) {
        for (int mZtepgGjQl = 220129662; mZtepgGjQl > 0; mZtepgGjQl--) {
            sGrehLZrBJMZaMh = BVYDShfIpH;
            mYnYwj = ! yuYVXpBlZFZCHMOP;
        }
    }

    for (int UGsROmYsf = 1708712960; UGsROmYsf > 0; UGsROmYsf--) {
        continue;
    }

    return zmFFkxRi;
}

int hlEjUhAFdrGqz::CCyecMu(bool MWgUljPmPBqeHzDz, int jZYmKsYdy, double fsOFpURVNOytWo, string cJiAzuha)
{
    double LPkUGjiYvYe = -812512.9393323903;
    string VpgZlACKM = string("NwAEPjbcZLyPDAxQtFPICzPxEoFYnEGx");
    string mPCafFzC = string("CnfOdmbHlRpQfiiNdNtxJMLrysXVYLfyXrgWgzhEbBUowPgWDaomEMgLhqLkwzHUqgNrSFWuzAybESPBIJhlnDjvwvjrLVntLqJZLavtvauAkKqfgcOJJQzPEIPzkYKePJBDfgeDUMJxCBGeOPvzunHsMaZVhpGyptwYlYufByzWfRTPEJMLPRujrRIIcqtHufQsmNIyejTIpmOXewPyrMOuQDINvGvNyfbeCpEok");

    if (LPkUGjiYvYe != -812512.9393323903) {
        for (int MTavBZptEjHrz = 541143951; MTavBZptEjHrz > 0; MTavBZptEjHrz--) {
            VpgZlACKM = cJiAzuha;
        }
    }

    return jZYmKsYdy;
}

int hlEjUhAFdrGqz::cNuIsbwJjddho(string HYHlM, bool xbTFUvCdDl, string UJTFDqVpuJK, int zVAencLqWpJQwn, string fUNTRuMuvTDswn)
{
    string WcEXIY = string("fUqgU");
    int RvCZFX = -871515728;
    bool NkyKKXopuEOrBrNP = true;
    string hYLVDu = string("cMTLuNpKzxYlfbOzIQwiovmfdy");
    double vhuGXTAI = 475764.8256595323;
    string nKnzYzNVnIkOPr = string("PHHWrZhiLWVAVUqlDLEZhcEdXzGUoOoqXiuvjXaLIKiwulvaJUpDqyZviawjiTmyRYyEfdYgQWxuwzTiWwhabHOPkynQXEDVlPhrxzOJANrtvJNSxXDxAUcqRGIrVQtrIrOtnkkXoLqlJuavTadTwdoMQXCkJYjMHzBHR");

    for (int cLEYlMoaqtTWTTH = 2022008685; cLEYlMoaqtTWTTH > 0; cLEYlMoaqtTWTTH--) {
        fUNTRuMuvTDswn = fUNTRuMuvTDswn;
        vhuGXTAI -= vhuGXTAI;
        WcEXIY += fUNTRuMuvTDswn;
        HYHlM += UJTFDqVpuJK;
    }

    for (int RXZuogmGKEWVR = 1143016816; RXZuogmGKEWVR > 0; RXZuogmGKEWVR--) {
        nKnzYzNVnIkOPr += nKnzYzNVnIkOPr;
    }

    if (fUNTRuMuvTDswn == string("xiLSFZJgmFxgkpSqpwxxxBCeCRXiocpEmIolKIrkKJdulHbfEUwzcJyxtsjpOQTXIXEoDwOmLliKCazCgtclMDMGqTRxHAnDpPtPBPXqxonBiVCJybESgTnkwMNzVwJXJWhAXYlpNpqcubztOMHpgouMtdrxsumtbCYvpTyYdLMyDQtwyTmWBUbGVmKoJHBnKERDVymTqLvsPBcpeBohDfwAoSpYCNMStANJRpaEwxrG")) {
        for (int AhbCBqukIBGhozU = 486914840; AhbCBqukIBGhozU > 0; AhbCBqukIBGhozU--) {
            HYHlM += HYHlM;
        }
    }

    for (int tgsYxgoeDVxnvMi = 2131179917; tgsYxgoeDVxnvMi > 0; tgsYxgoeDVxnvMi--) {
        nKnzYzNVnIkOPr += WcEXIY;
        nKnzYzNVnIkOPr += fUNTRuMuvTDswn;
        HYHlM += WcEXIY;
    }

    for (int OCgcOLCVMOJQ = 1964829925; OCgcOLCVMOJQ > 0; OCgcOLCVMOJQ--) {
        fUNTRuMuvTDswn += HYHlM;
        nKnzYzNVnIkOPr = hYLVDu;
    }

    return RvCZFX;
}

void hlEjUhAFdrGqz::SUMpacAENmo(double jPtjhpumVqBR, int kqJEvInCFrMg, int ZUocWYHlXcWtiAPT, string cSOMbGiFI, string nawkVqZNqNgxpW)
{
    double tXRNfhfgzlZ = -284176.71521581797;
    bool fRRVryZEXC = false;
    double yFibioGdJ = -668228.3326874078;
    int KIcyQoWxhwWOwc = -471650759;
    string pMHLrgHWlwf = string("LelnReNIiqNHOxwSVbvsXI");
    string QQKfg = string("aiXvgjNQjEvtAHtzVSaxUvQGekjMONBPKEHLepNZkLVgYhVMmrNTqEEazwBODokimQiuojNVjQOEuDEyveQDvKaUXyE");
    string vjihSykrTp = string("FApGklsuJzFNTnQGbTWwnmhnWfcUCnMhETtGYEVzRlpBQGbxZJHcnUxwjAFcNBKovFIqLmrfWtEbOtUyZtNsHKtxXiFUBTjfPgNlWHXSNXvfyAZtsAQnfQSNPrqCBxERenGmPXlKeNepZXvLGNZJaXFsdtalaxfXx");
    bool FFtFdUVungTP = false;
    string BSrkpdsqdlnp = string("OElqHpZtWJygBsveZDlDcFQWzFKVPYahNhxQphkxjszerCJXNWzfkcujd");

    for (int DCoBHyKKvcFiX = 417800693; DCoBHyKKvcFiX > 0; DCoBHyKKvcFiX--) {
        BSrkpdsqdlnp += cSOMbGiFI;
    }

    for (int QrYdrGyYMkTAQUD = 1949273145; QrYdrGyYMkTAQUD > 0; QrYdrGyYMkTAQUD--) {
        ZUocWYHlXcWtiAPT += ZUocWYHlXcWtiAPT;
        fRRVryZEXC = ! FFtFdUVungTP;
        fRRVryZEXC = ! FFtFdUVungTP;
    }
}

string hlEjUhAFdrGqz::OZokLh()
{
    double GgMtXXmWWpaS = 975292.3943597096;
    int GGIfaIMbxjrAw = -1436620777;
    int IGeZMfklHKsBQHt = -671939578;
    double dVpIWYdSWJPvwn = -308690.90768259397;

    if (dVpIWYdSWJPvwn >= 975292.3943597096) {
        for (int zyAIXINVblUtKkr = 699339059; zyAIXINVblUtKkr > 0; zyAIXINVblUtKkr--) {
            GGIfaIMbxjrAw = GGIfaIMbxjrAw;
            IGeZMfklHKsBQHt -= GGIfaIMbxjrAw;
        }
    }

    for (int tVJyB = 1491983735; tVJyB > 0; tVJyB--) {
        dVpIWYdSWJPvwn /= GgMtXXmWWpaS;
        GgMtXXmWWpaS *= GgMtXXmWWpaS;
    }

    return string("NkPhiccBkLbpahLIwaYPePxfytCPhPwQgveUBHLotdRNtDswvboORxJfKhvLIuqFujyAaJvDNfDWuHE");
}

void hlEjUhAFdrGqz::EPaeYIULw(string pvOzrwU, string jCifuBwml)
{
    double SGOzl = -203910.9650085421;
    int NSEtcq = 119136877;
    bool zqhkcMlJ = true;
    bool waPFxNosyrO = true;
    string AoCtxGmAMX = string("crhhKpRPPxsIzvsZONMhunoVayfhYiaINiqUsssnmpHthqDIGdxjxaBawtazfhygHNYqFOCnjGtccfJLCWOCPboIkQGCVOhWycPGHKqWBUzIqsHLkSQkQJYQfOwoFIxpqdZHkwDJtWlbalXCnLykcSFvDZfrqYglmANDLmyoKhKwRSjcFHtKhROwJYfRcYScdTVguUlNAmHAwTesblLYKGnMLaGZEazKllwxcBScFYmz");
    double rbUFMH = -716843.7665824499;
    double qKOLLnyNUdO = -974010.7263884109;

    if (AoCtxGmAMX <= string("GwYyZxUcTUPMHIClEOdbBRmiiWsEyDznroksSeBjEcWYGGenbMNirHRhaMqYGqKouCwiYrZwCXQgtpfHkRdOhZGlTkBYkmUcdASPoQUyJsEbsWNqmFiACjFaLzFeyyhKVcSKnnnMpNuoXLBlrvNVeULtjCLeyFrMsLnsqxxrNAGkSitsvhUtbOfnkkZFddrDrKeAaqKBOnNXaHwXFeavccRpnNNDFuHypSCQLcwSMcxivuqyUhjnlZkkLIyzN")) {
        for (int YxlQTKfQy = 422473503; YxlQTKfQy > 0; YxlQTKfQy--) {
            jCifuBwml += pvOzrwU;
            AoCtxGmAMX = AoCtxGmAMX;
            rbUFMH = qKOLLnyNUdO;
        }
    }

    for (int AdrzBWZkRteHtZAS = 557322601; AdrzBWZkRteHtZAS > 0; AdrzBWZkRteHtZAS--) {
        NSEtcq += NSEtcq;
    }

    if (rbUFMH < -716843.7665824499) {
        for (int XYeMuFNzJQHA = 593905484; XYeMuFNzJQHA > 0; XYeMuFNzJQHA--) {
            continue;
        }
    }

    for (int aRKMhpKjJidRtbnU = 718006101; aRKMhpKjJidRtbnU > 0; aRKMhpKjJidRtbnU--) {
        AoCtxGmAMX = pvOzrwU;
        qKOLLnyNUdO /= rbUFMH;
        AoCtxGmAMX = pvOzrwU;
    }

    for (int CVfDhAMK = 687458682; CVfDhAMK > 0; CVfDhAMK--) {
        continue;
    }

    if (waPFxNosyrO != true) {
        for (int PoNnwaXsfBYvBYg = 601173955; PoNnwaXsfBYvBYg > 0; PoNnwaXsfBYvBYg--) {
            continue;
        }
    }
}

hlEjUhAFdrGqz::hlEjUhAFdrGqz()
{
    this->iGXiAdbrQB(true, 1315949685, 204996.5183888158);
    this->rDxZYcDIkkWI(-174335805, string("hGqJyNFinwhKVoLXxLpQtFokPsAtZhmmXNEmVNlFwJYUJnrtVDoVwdrM"), string("VPgKJXNjbvKDvcVVUgNsfOjRuazBRmZSAljHKhJiukjdOBwWehXlrICfoBIegEogwaugRHpwGMsgdeARiABgvsuEqBXOLXxxNIMyHQQFZfSpdLGzcgYDJ"), 441139872);
    this->gJfwAfNEquRGJjdq(false, true);
    this->LvSXWvr(-392799.0272471206, 428748.7603949695);
    this->PeVsepJrEpiXQNH(-171775.47162181244);
    this->rOgjlPZElK();
    this->GpGwOpNfdnBd(string("gsAgzQcXGaDjZmAHiPvEHfJYPSXrtxgnwNpFdmJZULdnGbnSgbBJbXhcqDVxtvmQjgLaDBJaLWPiIaOaCmNxBVQtyMV"));
    this->kHpeyAXIxWFXrK(false, -172123.70157099408, string("tVEmrKIbbMHyrQtYjaDVCrjVBCWflStKAlqzDRRXoBPwCaZHeNRgzyfmwBmGHFDxUDKRyWvOPFXsjVZHWaHNUNMVewdLqpFkbLAwFZNMORmdksjpYyTqCOfdaFIMUpBBpWNNCvkvvulmAuwcGgPwgIsDAMRFjasJqABVLfrNoHKfaIOUVDcEEKLDbblnr"));
    this->nmrousA(-637264237, 1442663024, 274649.8392372462);
    this->qUeKpcpF(-1685433264, -2055711348);
    this->EXdLxUJqssjd(-1188317164, 1634682970, string("yzlmeWgJvmWqEzKPkUlwSxFiQjnghVTSvIMlbhBHxWEqxSGnyWOxrdLuN"), 658788093);
    this->LtZyCuvZ(-128320.93713098495, 671588.1112966781, -1613390482, -107388.6256179686, -448071.8221245546);
    this->MlXvgdkbguBRDkm(-262438.0742782198, -735623.8959983155, false);
    this->CCyecMu(false, 767971892, -179500.62312568797, string("LIXYppDuHoiMKHvvWkyOWFxIQAoEMcMuakGzGrYvtnbFxzSXlYSfQBeOLGfXSyOtswmPdcFaZPRmoClwxQWJnZfDuxsiyqTFDJyQmjMvkUyUoJpNPtILGqvqqoZMLsGZQVbjeuhaYvvvTweYxevCdUIcBgroavhagdavwkkDjbbPAvpwfgemJmxLBSXHDZhRodnrETaSDJUSooazBmwDxVpAHUVSfeYiMfwSRpdzqscuohgcHVzocAoI"));
    this->cNuIsbwJjddho(string("EddEVuTGRcUXQZietkPVjAfNCgKiKtfytRqTbwvPnZvctcMVTLIHFZwwEPEUCjAFICzfNFgqNirOLwavlmAlXCoJiThnaFHaZnqMtBCPqhhheVFSyXZYFwKtPEJVVwDjPKWwZDBOGJwVqgMQvVHDeqcNkpqTAMsEaDBIAoGPTxLeiXFdxFbQcyBzrknPbS"), true, string("VlcqjrDKBnKoOMFIRHnFTVqLdCXCIlyoAHJdvkJVGCKPSaTCWROadzpLcUXcRNGeczFUwgShuwJzEcadvmIpdhTFvkphVquOMTcrhLOGNVJhpWRGuTkrwDiSabCdwLXLxMeGGGeGrJTMPlYOmQuVIedsfyqdlBJdWkgnORgHqgksRIAEaywUgHCLmBpSGYIVCTdYXuCUHGqlKvccCZCu"), -1813861479, string("xiLSFZJgmFxgkpSqpwxxxBCeCRXiocpEmIolKIrkKJdulHbfEUwzcJyxtsjpOQTXIXEoDwOmLliKCazCgtclMDMGqTRxHAnDpPtPBPXqxonBiVCJybESgTnkwMNzVwJXJWhAXYlpNpqcubztOMHpgouMtdrxsumtbCYvpTyYdLMyDQtwyTmWBUbGVmKoJHBnKERDVymTqLvsPBcpeBohDfwAoSpYCNMStANJRpaEwxrG"));
    this->SUMpacAENmo(-92914.27080649775, -1116582285, 1056474077, string("pVGUuxoogWhxrPRffINTcgUtblBlrzZJfjRLBxuuXyWBcEPWMbzkeHBKermkZu"), string("UAKDECaoaXZpHWIWARZOHlTjMyfqORHmDXqgZHGYJtfbuMxGDXqgbwtUkVGmgBbOPHWmAlGUcQzjcNnAOntMcVrCeQNCxuZgcJMxMsVLjVVfBWKwKUGrSLKdTVAEAVhBjhwvBESIhlvQWNtOzWyvLqyjgaxD"));
    this->OZokLh();
    this->EPaeYIULw(string("GwYyZxUcTUPMHIClEOdbBRmiiWsEyDznroksSeBjEcWYGGenbMNirHRhaMqYGqKouCwiYrZwCXQgtpfHkRdOhZGlTkBYkmUcdASPoQUyJsEbsWNqmFiACjFaLzFeyyhKVcSKnnnMpNuoXLBlrvNVeULtjCLeyFrMsLnsqxxrNAGkSitsvhUtbOfnkkZFddrDrKeAaqKBOnNXaHwXFeavccRpnNNDFuHypSCQLcwSMcxivuqyUhjnlZkkLIyzN"), string("CxLiyNVEOutDngqJbXPLCCmRFIgNzsJdMzHYIlAxraoQcQTALgBdjiwflCeephGHKLDJLZzZuCivBJQxnOxzvBQqcyKgaTHdaWiKrWSlpzFrAiaWvMbSzewWwSkMCsueSnFQCWFzYKokGfvWBDnmPBomVSmsHLVNuypzdwtppzsBTnfLyfxVxtTPhWqOHJrIUiiIJEfzRqqZuItiModjtgfpKTlGiunHVVpnGuhNjwljcDwpGE"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sDPcXL
{
public:
    int VhVStThJNh;
    bool uvUegzlvxR;
    double yetKpaKknqCNWRyW;

    sDPcXL();
    double pireeLirEWFrenU(string YQruhEpqEGd, int yscZoCTcxK);
protected:
    double OyIkxToacjWxSwn;
    string HmoPYgMPEofQUJJl;
    string kmwBozsoOS;
    string pepgJJOvUZ;
    double svbfWQSMGxThhKA;
    bool TcHoZ;

    string MUKwNeOZnexdfmK(int jxrQHaodeunB, string QTUEwn, double kyvutcedIfwWwp, bool sxrazpfjyZBE, bool TrMkPiNIyJUox);
    double jRsMkReJjni(double LcGWOQYOvuaBJ);
    int CWnCZYikyxCrfX(double JbQzIz, int YIVTBlPifDWFbJqf, bool arkzaswgluG, double uGhAfsbhKlN);
    int DKTZkpOVzyu();
    double bLZIvpzFnPRckxqP();
    double AVXKXCSA(bool cpxRpP, double YsQnCNkVTYatw, string jbLJBoCToOBykF, string MmLhHxDAZGt);
private:
    double ymtMHEGlZNuyaZ;
    int idSQUpGLmOqbxMRt;
    string bywsNfYgvrnhjzSP;
    double aKDqmKx;

};

double sDPcXL::pireeLirEWFrenU(string YQruhEpqEGd, int yscZoCTcxK)
{
    string GBzTQWMRqQGic = string("sRQMbvRpFUYsiHFYmdcMxyYYAFLvaKPnETpkYVXzwJGnXMxwPxyVXejUmMxBejsqgpFmWRMMSUmMulxHVhNzdb");
    string RhySlAQIaYNhdMN = string("fkLulgiqJaDWaAiMuoAWMgbAPIDlCoKMtyYYiLiPjcixBuPLlNexFpkEbkKEjPZapuBXKukkfjLNzCLpxpdFOtXCeEcvOoIiSRgixQrTunZmboLccTacyJieYDDiInIpljtmrrMeFVkeYBdagOHfksNDNFgN");
    double YokkEJP = 142334.0001496966;
    string NaCTr = string("wscxhohhuTVLbcw");
    int yEXgRXCBOUvOy = 859557403;
    bool NPSAVCTJg = false;

    for (int JURqH = 585984016; JURqH > 0; JURqH--) {
        yscZoCTcxK -= yscZoCTcxK;
        RhySlAQIaYNhdMN += GBzTQWMRqQGic;
        RhySlAQIaYNhdMN += GBzTQWMRqQGic;
        NaCTr += GBzTQWMRqQGic;
    }

    for (int eWDRm = 2086629734; eWDRm > 0; eWDRm--) {
        yEXgRXCBOUvOy = yscZoCTcxK;
    }

    for (int zXwOITdO = 922191665; zXwOITdO > 0; zXwOITdO--) {
        RhySlAQIaYNhdMN += GBzTQWMRqQGic;
        YQruhEpqEGd = RhySlAQIaYNhdMN;
    }

    return YokkEJP;
}

string sDPcXL::MUKwNeOZnexdfmK(int jxrQHaodeunB, string QTUEwn, double kyvutcedIfwWwp, bool sxrazpfjyZBE, bool TrMkPiNIyJUox)
{
    bool frjYCHFHpxQaRoa = false;
    double EybEGhDLnC = 641017.6782460593;
    int rtbYvDO = 1284615500;
    string sEIDD = string("nnbtZVNdQvocjZGaASXwQMrpXNazviHHUYFnNFOjJpIeHFtMrNKYJWqQnrVUDwzDwalUqYXDmlgEHUGzyyIqcwgkPjmrRrnnJYvVuhhPvgnxSYmU");
    int kxZUYftykadI = 861816181;
    string fsfbJ = string("LlTNgTsaKmcOVeIQqzzohqLMCdgXpqDIMElOXqtQneuxgwIHJbHejXGMlZxZGwbLJbZUlaITOjIcsxOvRcYVuXVxFssrkbkeoNWOgwYINtuJAdhDeTnPjsyDIjEwBzZHLsmnbcThdiTBDNuaGMnBJeUFhBDwtMKgat");
    string swEliO = string("IVlpLZ");
    bool iRzKwTLpLxhRC = true;

    if (kxZUYftykadI <= 1284615500) {
        for (int bRZrjyMaPhUuou = 343363449; bRZrjyMaPhUuou > 0; bRZrjyMaPhUuou--) {
            sEIDD += swEliO;
        }
    }

    for (int fYxnSscn = 941784293; fYxnSscn > 0; fYxnSscn--) {
        sxrazpfjyZBE = sxrazpfjyZBE;
        frjYCHFHpxQaRoa = frjYCHFHpxQaRoa;
    }

    for (int YRopnVvlOypqjK = 1631946541; YRopnVvlOypqjK > 0; YRopnVvlOypqjK--) {
        TrMkPiNIyJUox = ! sxrazpfjyZBE;
    }

    return swEliO;
}

double sDPcXL::jRsMkReJjni(double LcGWOQYOvuaBJ)
{
    double PpXqIttajrPkpbt = 665340.2518214444;
    int CIFMOgRtZhD = -1681116710;

    return PpXqIttajrPkpbt;
}

int sDPcXL::CWnCZYikyxCrfX(double JbQzIz, int YIVTBlPifDWFbJqf, bool arkzaswgluG, double uGhAfsbhKlN)
{
    int aIzcHsLRrlcNOFlv = -900136650;

    for (int dNLmcqaePR = 369427940; dNLmcqaePR > 0; dNLmcqaePR--) {
        YIVTBlPifDWFbJqf = YIVTBlPifDWFbJqf;
        JbQzIz *= JbQzIz;
    }

    if (YIVTBlPifDWFbJqf <= -900136650) {
        for (int AWhUvRbOHmAUY = 1509152932; AWhUvRbOHmAUY > 0; AWhUvRbOHmAUY--) {
            continue;
        }
    }

    if (JbQzIz >= 741194.3664175984) {
        for (int YGEPuSRUphUbet = 1005255908; YGEPuSRUphUbet > 0; YGEPuSRUphUbet--) {
            JbQzIz *= JbQzIz;
            JbQzIz += uGhAfsbhKlN;
            aIzcHsLRrlcNOFlv /= YIVTBlPifDWFbJqf;
            arkzaswgluG = arkzaswgluG;
            JbQzIz = uGhAfsbhKlN;
            aIzcHsLRrlcNOFlv -= YIVTBlPifDWFbJqf;
        }
    }

    if (arkzaswgluG != false) {
        for (int HMHHboUYDjSalg = 512286604; HMHHboUYDjSalg > 0; HMHHboUYDjSalg--) {
            YIVTBlPifDWFbJqf *= aIzcHsLRrlcNOFlv;
        }
    }

    return aIzcHsLRrlcNOFlv;
}

int sDPcXL::DKTZkpOVzyu()
{
    bool izdpSLhxX = false;

    if (izdpSLhxX != false) {
        for (int PWPAHLbIPlR = 1990296120; PWPAHLbIPlR > 0; PWPAHLbIPlR--) {
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
        }
    }

    if (izdpSLhxX != false) {
        for (int AnktsBa = 1108667890; AnktsBa > 0; AnktsBa--) {
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
        }
    }

    if (izdpSLhxX == false) {
        for (int VFXpsPMGY = 765739846; VFXpsPMGY > 0; VFXpsPMGY--) {
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
        }
    }

    if (izdpSLhxX != false) {
        for (int ZIFARy = 494394253; ZIFARy > 0; ZIFARy--) {
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = ! izdpSLhxX;
        }
    }

    if (izdpSLhxX != false) {
        for (int kVlOjo = 260660632; kVlOjo > 0; kVlOjo--) {
            izdpSLhxX = ! izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
            izdpSLhxX = izdpSLhxX;
        }
    }

    return 405169303;
}

double sDPcXL::bLZIvpzFnPRckxqP()
{
    string zdMmfitdAGD = string("uRueKbXQOTJkrcFzHZPqKBJgWUGPDdnixWSHWcxZwdafeLwdkpBzLSQKHBzcIHwgytpEGOOelodTYaLQBZebxuwOAEhIhDWLTv");
    int iBKAqEdkb = -1848548995;
    double hOwAiPvzzLduA = 627263.6294643374;
    int SVbJYjKbAZjHwtpx = -891429943;
    int lcEsABZXMwFdFOA = 711479460;
    string dotjJCukQjYeMpkM = string("NrFthHpueNdiEZCvKPYDkEOQbxOrRDtGCZaATbSjyhwVAnPaRHnuoBiETPnzVAHqrtoSuyoSmhyIeLZAaJmXkRbIEEPEGZXGbAhoeXjFHepdW");
    double qRPFHVMT = -353071.28147911775;
    double SzuyViyY = -454598.2002716501;
    double ryfKZU = -314049.405196821;

    for (int dNpJeQf = 726978161; dNpJeQf > 0; dNpJeQf--) {
        lcEsABZXMwFdFOA /= iBKAqEdkb;
    }

    if (hOwAiPvzzLduA != -314049.405196821) {
        for (int YlFohsdklqSOO = 606473167; YlFohsdklqSOO > 0; YlFohsdklqSOO--) {
            dotjJCukQjYeMpkM = dotjJCukQjYeMpkM;
            zdMmfitdAGD += dotjJCukQjYeMpkM;
            qRPFHVMT = qRPFHVMT;
            lcEsABZXMwFdFOA += lcEsABZXMwFdFOA;
        }
    }

    for (int QftzCcQOMDxqPg = 989180642; QftzCcQOMDxqPg > 0; QftzCcQOMDxqPg--) {
        continue;
    }

    return ryfKZU;
}

double sDPcXL::AVXKXCSA(bool cpxRpP, double YsQnCNkVTYatw, string jbLJBoCToOBykF, string MmLhHxDAZGt)
{
    string qFPjttJmVeulZd = string("GMobBPEbWlsrSSKMAZUvfVtcHWWeWwkByZJtXoPFviEyuJOVgKdHrflZBoeIGPmdkEDKnMOGZbPpeJgorHGUOglHCtkksBzCvvqgnikpHdrcaQFVWCVNmyzdxVmkiCeWLWatqyWCWvfCzzFEtyjJWrLCFopnvlaaDUCMsgNbfqEEznoQpIBgodSeptKdLHUCZUZzwifyHMwVPKeYwihVILYvYvIyi");

    for (int WoaAddLA = 1189941361; WoaAddLA > 0; WoaAddLA--) {
        jbLJBoCToOBykF += qFPjttJmVeulZd;
        qFPjttJmVeulZd = jbLJBoCToOBykF;
    }

    for (int lfddechL = 244046481; lfddechL > 0; lfddechL--) {
        qFPjttJmVeulZd += jbLJBoCToOBykF;
        jbLJBoCToOBykF += qFPjttJmVeulZd;
        jbLJBoCToOBykF += MmLhHxDAZGt;
        MmLhHxDAZGt += qFPjttJmVeulZd;
        qFPjttJmVeulZd += jbLJBoCToOBykF;
    }

    for (int HvCGR = 1978745440; HvCGR > 0; HvCGR--) {
        YsQnCNkVTYatw += YsQnCNkVTYatw;
        YsQnCNkVTYatw /= YsQnCNkVTYatw;
    }

    return YsQnCNkVTYatw;
}

sDPcXL::sDPcXL()
{
    this->pireeLirEWFrenU(string("wDaMJSOgrzYVzMOIZTmxTqxnsNjhKmPrxbZSpoqKTvNlPjEkYKACroWKqHCneSkJcDUOuXbUDmWjJyeiBMGJCYxkCmJAwQqbWEhqbvDviSjGzxmWmXcKVSngzDjUtCyXSsRpEFlLIWNgAWPePWeMHcVbAyvdnWDDuVIyDWkQXcHNraQsnAEQXZAuFJnOdsvNwrjcDlWXkhiR"), 564365964);
    this->MUKwNeOZnexdfmK(-1331129574, string("SogXkbYSdGuuVSdFSirXZmsQOfMIegTPAGfTAyQlINayljVBAEOlnvNohHmjMLIczonGJosZOZdMbnkHhTvAMuanwqGvDSHOGukitlvqlndvdQQfOUbNCTjtByhmMyQLRbocEwWMHZbDDiGLbspmRmkeKSpDefbcFDsErcgYjMirWUnxSOcOqFqSXpslqfrGdazZTbjSHBhvqFY"), -969573.08266244, true, true);
    this->jRsMkReJjni(922612.869169469);
    this->CWnCZYikyxCrfX(746630.1238298175, 2118249374, false, 741194.3664175984);
    this->DKTZkpOVzyu();
    this->bLZIvpzFnPRckxqP();
    this->AVXKXCSA(true, -557559.899159114, string("xHvvPHCWremxGBdMUEuApiwNvSvFiqGcuQivONBWGtqWJpLtdHssfPLSVIEEIwKEhHyqRdxMFCrNniwCQYPYdOsnGFYZxzywEgZbttZAQW"), string("ieRxRZcuKLLBUdNYyUobAiEHfojhYiGLyAgtipgdyxoDjFqGprDvtacRsSdkmZkDmzlqLKetmZIKWLzHoPyhBjJRDLykuNioFscuJeyzQxbsoCYcniHaABtKbbCcgCpXdGUIXMAFbrnKBdhWbjiIIgmvQPJdnNpqFLHbk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dBjWVjALFbcVtJsC
{
public:
    double UnEEms;
    string VcBcAoaMDgtsox;
    string ksVWByAyCAlW;
    string sXBTvtKsyRWwo;
    int YvURXG;

    dBjWVjALFbcVtJsC();
    void ueySTtSHmVxzRwzZ(int mjCDwfkgdNtYznZ, bool DNwZqqt, bool TZWvRxxq);
protected:
    double ryQrZFASLAfD;
    string WeJDJWrD;
    int OAbeX;
    string gmlHlfLsjW;
    double Pnirnt;

    int TFMVYrQWd(bool EQQalg, bool gebVhPMJ, bool UymEpCjxRR);
    void yrnRxqtw();
    void oyCHYLnTJ(bool LUEFSCqzlT);
    string iIFWnZ();
private:
    int bSFIWWRwJNepozA;
    string AjfnczlnqFGiCQCO;
    string DAWSMDCt;

    int WmRryEqSroz();
    int WoaoVpoY(int zTkPSrfPqHCZmGL, string TuffumrMVcsfQ, int anfkVMwLhFeHly);
    string iEfWAFw(bool XZxSf, string lddqnEiH, int sXlFkohLslFQGmPg, double ivBkoF, string oLYNFfXmePgMnMj);
    bool FuJxZRksfnUAlBax(string LUzMbr);
    string HIoLAPIVhbKiSMRF(double mcKyvAZyuydNIdf);
    int MpgVHoqjSD(int NMwboYFkeFJj, int tsKJAVqOQW);
    void SYXOhvsRUU(double fPndCfbajO, int UmAmXvRH);
};

void dBjWVjALFbcVtJsC::ueySTtSHmVxzRwzZ(int mjCDwfkgdNtYznZ, bool DNwZqqt, bool TZWvRxxq)
{
    double aELJyd = 710468.8025274198;
    int RlRJqEfnPCH = -1730210071;
    int XWlwfLJ = -1871377499;
    bool FfMvjloJLNiV = true;
    bool fibGtVSyUWMejXmB = true;
    int tpMWF = -1137547976;
    bool FifKlBXhsSOM = false;
    bool gTiZOvpryobnK = false;
    double eyBbHoheVgbgPcNp = 948096.4023206964;
    string dQOYIyaVqM = string("xTfQKhtqAsZHQiCruRPcqZrUCJcwWCjbWtlHqlkwtEWVAEXqkNvcjwWApVEbCFBhiUNSyGWaDSUgSVw");

    if (tpMWF >= -1871377499) {
        for (int RrGWpsyxsAZtIfP = 1057838482; RrGWpsyxsAZtIfP > 0; RrGWpsyxsAZtIfP--) {
            DNwZqqt = FfMvjloJLNiV;
            tpMWF *= XWlwfLJ;
        }
    }
}

int dBjWVjALFbcVtJsC::TFMVYrQWd(bool EQQalg, bool gebVhPMJ, bool UymEpCjxRR)
{
    double JwXzZATbI = -36053.08879550366;
    string rPqoYxBJXJPY = string("CKeVJjeIkjbEXdLsBhBeXxVrniRQyabCocrBofhuryWtIIrrUkaYBDjHmEewRQyEjBCmOlAkkXH");
    double uvHZqHLScCXYc = -843802.9528126988;
    int XZVenN = 1326769004;
    double eOVGnCmM = -28946.651742111375;
    bool BpWkJ = false;
    int nvGSnrebNDBPjG = -344448718;
    bool kDujAjqdvTX = true;
    string YQxexdIT = string("nXbuhAkqmVtACdRBSyepPhNmAHQaqznidGenYRhkHnBFZdDJcbccIOfpFeyJlAWWHePIdiMZVFsowmGvuJWFNEruIaMRFGmvoqrFvJuRRbklJvcGXeFUcLqFJSLTBlQCINcUCcBMtkpdDPnYKdySAGDXsVlBLUdeRUWYdAfTHTBhUMaEpLzLqARvbUvs");

    return nvGSnrebNDBPjG;
}

void dBjWVjALFbcVtJsC::yrnRxqtw()
{
    int SZPFMtkElNO = 647253850;
    bool ykkZqdaeWYzqOe = false;
    double krwpJyog = 211995.13208964624;
    int xTuHaAT = 1607735004;
    double wcRivikmr = -240409.0409082709;
    bool ExfagDyZehhiY = true;
    double QGBYv = -378319.0167836485;
    bool ntxUHSxFTruz = true;

    if (QGBYv == -378319.0167836485) {
        for (int QGCPvs = 1895070360; QGCPvs > 0; QGCPvs--) {
            krwpJyog -= QGBYv;
            wcRivikmr += wcRivikmr;
            ExfagDyZehhiY = ExfagDyZehhiY;
            QGBYv /= krwpJyog;
        }
    }

    for (int HepNlMmhophg = 954498320; HepNlMmhophg > 0; HepNlMmhophg--) {
        continue;
    }

    if (ykkZqdaeWYzqOe == true) {
        for (int oIEuIBpwdLUZFRqv = 1280826354; oIEuIBpwdLUZFRqv > 0; oIEuIBpwdLUZFRqv--) {
            continue;
        }
    }

    for (int SDYHJ = 404958203; SDYHJ > 0; SDYHJ--) {
        ykkZqdaeWYzqOe = ! ykkZqdaeWYzqOe;
    }

    if (ExfagDyZehhiY != false) {
        for (int JqKNQpfoprIPwd = 425740972; JqKNQpfoprIPwd > 0; JqKNQpfoprIPwd--) {
            krwpJyog -= QGBYv;
        }
    }

    for (int FoYGDkXJUQAtUJ = 1607629044; FoYGDkXJUQAtUJ > 0; FoYGDkXJUQAtUJ--) {
        ykkZqdaeWYzqOe = ! ykkZqdaeWYzqOe;
        krwpJyog *= krwpJyog;
        krwpJyog += wcRivikmr;
        ntxUHSxFTruz = ykkZqdaeWYzqOe;
        QGBYv = QGBYv;
        xTuHaAT += SZPFMtkElNO;
        ntxUHSxFTruz = ! ykkZqdaeWYzqOe;
    }
}

void dBjWVjALFbcVtJsC::oyCHYLnTJ(bool LUEFSCqzlT)
{
    double hcsSBFhmMSMhKl = -106902.93606987182;
    int Jyxleatl = 92018691;
    bool KhwdNrYYaIG = false;
    bool lIdvG = true;
    bool wmoDwDlecj = true;
    bool ysncwuqvDJ = false;
    bool FQKYH = true;
    double dMEwrDr = -203653.01086919487;
    bool qfjGrdPMeoosDo = false;
    bool YRBozgixU = true;

    if (wmoDwDlecj != true) {
        for (int FpFLlvuMV = 1276644811; FpFLlvuMV > 0; FpFLlvuMV--) {
            qfjGrdPMeoosDo = ! wmoDwDlecj;
            lIdvG = ! wmoDwDlecj;
            wmoDwDlecj = ! KhwdNrYYaIG;
            YRBozgixU = qfjGrdPMeoosDo;
        }
    }

    if (LUEFSCqzlT != false) {
        for (int rQfiNsPzcvaqcHCq = 46702817; rQfiNsPzcvaqcHCq > 0; rQfiNsPzcvaqcHCq--) {
            wmoDwDlecj = ! YRBozgixU;
            LUEFSCqzlT = ! lIdvG;
            LUEFSCqzlT = ! FQKYH;
            FQKYH = ! FQKYH;
            FQKYH = ! wmoDwDlecj;
            lIdvG = LUEFSCqzlT;
            FQKYH = ! LUEFSCqzlT;
        }
    }
}

string dBjWVjALFbcVtJsC::iIFWnZ()
{
    int ykdXFhdYg = 1550384396;
    int haMSnUCyzb = 1167505722;

    if (ykdXFhdYg < 1167505722) {
        for (int rXPyJrTQlpvknCb = 631064436; rXPyJrTQlpvknCb > 0; rXPyJrTQlpvknCb--) {
            ykdXFhdYg = ykdXFhdYg;
            ykdXFhdYg += haMSnUCyzb;
            ykdXFhdYg = ykdXFhdYg;
            haMSnUCyzb *= ykdXFhdYg;
        }
    }

    if (ykdXFhdYg >= 1550384396) {
        for (int NWzmTD = 1186807348; NWzmTD > 0; NWzmTD--) {
            haMSnUCyzb += haMSnUCyzb;
            haMSnUCyzb *= ykdXFhdYg;
            ykdXFhdYg *= ykdXFhdYg;
            haMSnUCyzb += haMSnUCyzb;
            ykdXFhdYg *= haMSnUCyzb;
        }
    }

    if (haMSnUCyzb == 1167505722) {
        for (int qCAdtSBENnX = 312330145; qCAdtSBENnX > 0; qCAdtSBENnX--) {
            ykdXFhdYg /= haMSnUCyzb;
            haMSnUCyzb = ykdXFhdYg;
            ykdXFhdYg -= haMSnUCyzb;
            haMSnUCyzb *= ykdXFhdYg;
            haMSnUCyzb = haMSnUCyzb;
            ykdXFhdYg += ykdXFhdYg;
            haMSnUCyzb = ykdXFhdYg;
        }
    }

    if (haMSnUCyzb != 1550384396) {
        for (int EWNoyk = 491547019; EWNoyk > 0; EWNoyk--) {
            ykdXFhdYg -= haMSnUCyzb;
            haMSnUCyzb /= haMSnUCyzb;
            haMSnUCyzb *= haMSnUCyzb;
            ykdXFhdYg += haMSnUCyzb;
            ykdXFhdYg *= ykdXFhdYg;
            ykdXFhdYg -= ykdXFhdYg;
            ykdXFhdYg = haMSnUCyzb;
        }
    }

    return string("xseuGqXqwyZIaBFrhsfP");
}

int dBjWVjALFbcVtJsC::WmRryEqSroz()
{
    bool hdtHhlOhJgqAKZiA = false;
    bool OLnZUkfgcbI = true;
    double dHuQdOGxYgAxD = 160204.8393976314;

    for (int iJMEw = 1743696447; iJMEw > 0; iJMEw--) {
        dHuQdOGxYgAxD += dHuQdOGxYgAxD;
        OLnZUkfgcbI = hdtHhlOhJgqAKZiA;
        dHuQdOGxYgAxD = dHuQdOGxYgAxD;
    }

    if (dHuQdOGxYgAxD >= 160204.8393976314) {
        for (int XrjgHcgLyWc = 1478970339; XrjgHcgLyWc > 0; XrjgHcgLyWc--) {
            hdtHhlOhJgqAKZiA = hdtHhlOhJgqAKZiA;
        }
    }

    if (dHuQdOGxYgAxD < 160204.8393976314) {
        for (int DDwoqKDlVOvR = 1372887237; DDwoqKDlVOvR > 0; DDwoqKDlVOvR--) {
            hdtHhlOhJgqAKZiA = ! hdtHhlOhJgqAKZiA;
            hdtHhlOhJgqAKZiA = ! hdtHhlOhJgqAKZiA;
            OLnZUkfgcbI = ! OLnZUkfgcbI;
        }
    }

    if (OLnZUkfgcbI != true) {
        for (int CNrEXhfCWL = 1473028003; CNrEXhfCWL > 0; CNrEXhfCWL--) {
            OLnZUkfgcbI = ! OLnZUkfgcbI;
        }
    }

    for (int MzzHZSeDgxuyCDC = 249889445; MzzHZSeDgxuyCDC > 0; MzzHZSeDgxuyCDC--) {
        hdtHhlOhJgqAKZiA = ! hdtHhlOhJgqAKZiA;
        hdtHhlOhJgqAKZiA = ! hdtHhlOhJgqAKZiA;
        hdtHhlOhJgqAKZiA = OLnZUkfgcbI;
        OLnZUkfgcbI = OLnZUkfgcbI;
        hdtHhlOhJgqAKZiA = hdtHhlOhJgqAKZiA;
    }

    for (int EgXVJKB = 417281589; EgXVJKB > 0; EgXVJKB--) {
        OLnZUkfgcbI = hdtHhlOhJgqAKZiA;
    }

    return 1174778604;
}

int dBjWVjALFbcVtJsC::WoaoVpoY(int zTkPSrfPqHCZmGL, string TuffumrMVcsfQ, int anfkVMwLhFeHly)
{
    bool GMuxMmEanyhn = false;
    bool jvztoh = false;
    string FFimwpjOxqcp = string("pUaNAQagiNLeWyqsGINDAPXWvkNovuoNFNwSVdYQEPIPVeNNOtQnJsgYwVbhDvpkaRAuAIhyifNoaHlPmvvSMLCXbOScPINWBrWzzXXMhOIfUCloIQOJHYnhTAXfyHlwUwaMdxtrkgTHqaHYcZkJLOiiClHxcAvxBKzvpLDsPednoS");
    bool xCpXesSgq = false;

    for (int MPjpZ = 1114138483; MPjpZ > 0; MPjpZ--) {
        jvztoh = ! jvztoh;
        xCpXesSgq = ! jvztoh;
        jvztoh = ! xCpXesSgq;
    }

    for (int DPLDxDBXnXj = 346550156; DPLDxDBXnXj > 0; DPLDxDBXnXj--) {
        continue;
    }

    for (int rIKrHxwRzrL = 1343280523; rIKrHxwRzrL > 0; rIKrHxwRzrL--) {
        anfkVMwLhFeHly -= anfkVMwLhFeHly;
        jvztoh = ! GMuxMmEanyhn;
        xCpXesSgq = ! xCpXesSgq;
        FFimwpjOxqcp += FFimwpjOxqcp;
    }

    return anfkVMwLhFeHly;
}

string dBjWVjALFbcVtJsC::iEfWAFw(bool XZxSf, string lddqnEiH, int sXlFkohLslFQGmPg, double ivBkoF, string oLYNFfXmePgMnMj)
{
    string ayywMc = string("cnNVdZjuAUJMIOUswzEMiwZGYHQTphCkPLNkjjnrhgDskPMf");
    double pjhVvsXx = -35179.74609570891;

    for (int xnKxA = 492350032; xnKxA > 0; xnKxA--) {
        continue;
    }

    for (int QOqsYNcTBycwYehW = 1400848055; QOqsYNcTBycwYehW > 0; QOqsYNcTBycwYehW--) {
        ayywMc += oLYNFfXmePgMnMj;
    }

    if (oLYNFfXmePgMnMj > string("eJyikBpCGcpRQPKyxwpUiVMTBtIcxETJbJFunOQtYsjWhguqODzPgKWrXjEymTkZMkXXAlPLuJbjyKOrHiorotKPcxHVWpTzXbDvThfILPwEeLbLlpkBPiNMvEhAEHiJjFqbguaUPdiPKvRVBloQQUQF")) {
        for (int DrIbKssKYxpCILR = 437851681; DrIbKssKYxpCILR > 0; DrIbKssKYxpCILR--) {
            pjhVvsXx += pjhVvsXx;
        }
    }

    return ayywMc;
}

bool dBjWVjALFbcVtJsC::FuJxZRksfnUAlBax(string LUzMbr)
{
    string EhwsXhJLioiZ = string("YdFkMFHvXYuszeKLQimqJKuldxdUsrGfidMomsrcrnsPZYHnbYoXHLuiHSIMhkFxByhSWWPXzEROMIwvjqxUnIzDVYjPJFPGuHcgJBJRfORFrdudFSiaNlVAHognmJv");
    string rGOtatnrgCgjmVC = string("hPMGihfhSCcqVQxooWLrWKmJWkYLFoJYEYvNOGoiSwclTktepdVgqZOTQXYuFBWYpUlxKJLVnDaOImNTobZVAVdWFGRzapfgIajNUVMhmVAAgHHsoagIYMVwPYlsgSjUbDGwhxahSflIzjeExDatgaZLHGyxfTkmAyLbFKKqatfwffuBLysyTEaLGdCMllszjwWtuFfsPIQSdCsFkFUFaJePAfeKjByuBLPCvyzsQmUW");

    if (LUzMbr <= string("YdFkMFHvXYuszeKLQimqJKuldxdUsrGfidMomsrcrnsPZYHnbYoXHLuiHSIMhkFxByhSWWPXzEROMIwvjqxUnIzDVYjPJFPGuHcgJBJRfORFrdudFSiaNlVAHognmJv")) {
        for (int TuZicgf = 1417416172; TuZicgf > 0; TuZicgf--) {
            EhwsXhJLioiZ += EhwsXhJLioiZ;
            EhwsXhJLioiZ += rGOtatnrgCgjmVC;
            EhwsXhJLioiZ = EhwsXhJLioiZ;
            rGOtatnrgCgjmVC += LUzMbr;
            LUzMbr += rGOtatnrgCgjmVC;
            rGOtatnrgCgjmVC = LUzMbr;
            rGOtatnrgCgjmVC = LUzMbr;
            rGOtatnrgCgjmVC = EhwsXhJLioiZ;
            EhwsXhJLioiZ += rGOtatnrgCgjmVC;
        }
    }

    if (rGOtatnrgCgjmVC <= string("YdFkMFHvXYuszeKLQimqJKuldxdUsrGfidMomsrcrnsPZYHnbYoXHLuiHSIMhkFxByhSWWPXzEROMIwvjqxUnIzDVYjPJFPGuHcgJBJRfORFrdudFSiaNlVAHognmJv")) {
        for (int xFGWiCqvquGdonpx = 1234707018; xFGWiCqvquGdonpx > 0; xFGWiCqvquGdonpx--) {
            EhwsXhJLioiZ = LUzMbr;
            EhwsXhJLioiZ = EhwsXhJLioiZ;
            LUzMbr += LUzMbr;
            rGOtatnrgCgjmVC = EhwsXhJLioiZ;
            LUzMbr = LUzMbr;
            EhwsXhJLioiZ = LUzMbr;
            rGOtatnrgCgjmVC = LUzMbr;
        }
    }

    return false;
}

string dBjWVjALFbcVtJsC::HIoLAPIVhbKiSMRF(double mcKyvAZyuydNIdf)
{
    int dHADCRubyRtt = -1773003042;
    string nIrBYpLvy = string("BIPexPWBPZfNxrZpEbbrHxrxOPfHdxnfxRTuFZqfEoCkHYMVtlGbSsoVxswWYkPwfhJGIVHLKMtZMMQPbhRdoQxwpdhxKwLDmoypZzFPRlUiKVOZtnttxWveSuxKDDHLhirnJaPXWFquvMOHgvhvrKLIUWDHdnJeUaAcqBBceBRwR");
    double OzMUhsxjqpi = -225678.264527475;
    bool CbRUuP = true;
    double ZWwkzVROYok = 9827.938410683091;
    string vcqMTtL = string("RGfXDFmRDjvTLMYXdSUPqMtNBHFSRQlQKPltkGUrWUgwHBWSQkvpOnCMOPcHCTRYajZYWSZopRwGZMrxXbOSwRttzPsAJlxDfFjZOspfUXXg");
    double uZBQUEWgqqtqmLT = -580521.5005019512;
    double bklqotkYR = -682448.753155821;
    string hMgDboo = string("vihdwMXYBEAwVhfBBqsRARoeeewj");

    for (int oYslmImcke = 409865030; oYslmImcke > 0; oYslmImcke--) {
        nIrBYpLvy = hMgDboo;
        uZBQUEWgqqtqmLT = bklqotkYR;
        hMgDboo += nIrBYpLvy;
        ZWwkzVROYok = OzMUhsxjqpi;
        nIrBYpLvy = hMgDboo;
    }

    return hMgDboo;
}

int dBjWVjALFbcVtJsC::MpgVHoqjSD(int NMwboYFkeFJj, int tsKJAVqOQW)
{
    double SlytXwubXmfXBHIU = 406365.19946835533;

    if (SlytXwubXmfXBHIU < 406365.19946835533) {
        for (int aHBQGNQdZIJ = 1021931110; aHBQGNQdZIJ > 0; aHBQGNQdZIJ--) {
            SlytXwubXmfXBHIU /= SlytXwubXmfXBHIU;
            tsKJAVqOQW *= NMwboYFkeFJj;
            NMwboYFkeFJj /= NMwboYFkeFJj;
            tsKJAVqOQW += NMwboYFkeFJj;
            NMwboYFkeFJj *= tsKJAVqOQW;
        }
    }

    return tsKJAVqOQW;
}

void dBjWVjALFbcVtJsC::SYXOhvsRUU(double fPndCfbajO, int UmAmXvRH)
{
    bool odfbFXlnGNeu = true;
    string hDFThcjKeMuqx = string("poLgWFAfhXzniDKBKWvmhbLRPnVuOxyJEOUTHYwmPMdlBRwMqka");
    double ZjEQm = 538955.2132343942;
    string LmgARAoaZ = string("OtcaeAZzIWyivrNpWbxvPmRIXLmDdEfGlOlQxXBNXAVPptUniyyFyYfeMwGGhhYYTkNfxcQpGEkWUMDbxDiRlBtnVudNCPJrESjYbExDRdSKDXQArMlEyThxqual");
    int FwuFSVA = -708989681;
    int BtNnUOKBgFSUGvY = 2011039875;
    string hgbKkFKC = string("XFplPphxesthCoWkFROEtOHgOmUZaILwCcvXNJlemSLvburhYXRUXZvjhStrLRUGrFWJYKFTuqhdHiEiPZadAhGbHQlHqWxMmVMQdajvrJrwQlIyKUBEtJVxcQnpkqQreXISLUlgGMhyXCoZsSBWWOtnBzYKjukHKdCPSVT");
    bool uuwCJPcaiOC = true;
    bool hbGQgf = false;

    for (int LiHwfFMXxrdTMnA = 509997005; LiHwfFMXxrdTMnA > 0; LiHwfFMXxrdTMnA--) {
        UmAmXvRH -= BtNnUOKBgFSUGvY;
    }

    if (hbGQgf == true) {
        for (int qZlGjowCnCJzBJr = 481901479; qZlGjowCnCJzBJr > 0; qZlGjowCnCJzBJr--) {
            fPndCfbajO = fPndCfbajO;
            fPndCfbajO /= fPndCfbajO;
            hDFThcjKeMuqx += hgbKkFKC;
        }
    }

    for (int bnRICyOgL = 239056090; bnRICyOgL > 0; bnRICyOgL--) {
        BtNnUOKBgFSUGvY += FwuFSVA;
        odfbFXlnGNeu = hbGQgf;
    }

    for (int nfZFdPnfUgJ = 1379963018; nfZFdPnfUgJ > 0; nfZFdPnfUgJ--) {
        FwuFSVA *= BtNnUOKBgFSUGvY;
        BtNnUOKBgFSUGvY -= FwuFSVA;
    }
}

dBjWVjALFbcVtJsC::dBjWVjALFbcVtJsC()
{
    this->ueySTtSHmVxzRwzZ(1394441339, false, true);
    this->TFMVYrQWd(false, true, true);
    this->yrnRxqtw();
    this->oyCHYLnTJ(true);
    this->iIFWnZ();
    this->WmRryEqSroz();
    this->WoaoVpoY(-621311437, string("HmGcsimKoSXYpkDRuugHAaPJaYaEnYMsiAVllWYiGQLOJuyMdwUmPsjGTwvwyRQRxzcvGrOeYJVCTJMkkyHCFBKsJdLwNXNxgfqbDhLEmSWRkAnYTtaKMVHEpeNTDdXLTGZvZzALpaprmhSgAGfLjYnARxjyRBFjHwXNbenISfYnVWGZuzcQnPDhvLAAFabhpiqHPQtqTnUdISn"), -46259182);
    this->iEfWAFw(true, string("XsWUyzIsCosnPhtigQWjBLOiauGKkKsURRnnjWCUrPlpsqsyzxgAttqkxxSmxmecbTgHSwyKTdSuCnpOESQBdXHIdoqVpiQgplMQeTJzoGlpFWcNOHsXnymOhSFogthTTvbIKdVzpikjCCrZdLjArQlhelnfbxnkEdGZAIRYwsxTrWOhdHMjKFPWSimRTffQabygFyGbBWAUORwPthqGyEqyBbksBsdAQLGYWnPLaGqPhmEnI"), -1506121288, -66049.62133884463, string("eJyikBpCGcpRQPKyxwpUiVMTBtIcxETJbJFunOQtYsjWhguqODzPgKWrXjEymTkZMkXXAlPLuJbjyKOrHiorotKPcxHVWpTzXbDvThfILPwEeLbLlpkBPiNMvEhAEHiJjFqbguaUPdiPKvRVBloQQUQF"));
    this->FuJxZRksfnUAlBax(string("zG"));
    this->HIoLAPIVhbKiSMRF(205706.7758648351);
    this->MpgVHoqjSD(-51100190, -1369252183);
    this->SYXOhvsRUU(215240.95219103477, -1404274898);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pXDTipfglVyB
{
public:
    int FSpcM;
    bool dviSIRuiTy;
    bool mWQnLchnnnEDkfxI;

    pXDTipfglVyB();
    double LsaBDBXtt();
    void jXxkkzslqPQwiLb(string pysnKvb);
    bool vUWXg(int KeycOs, string TFOtpjLEkKsfIEo, bool GXUBYZqPEmQg);
    double YIOHx(string zjCwCBJXCmJNVYla, int XSCajUIWLwOzJSGd, bool GkBsOciDmC);
    int zxqAItC(int qrECnT, double LHTYlJJlxjsTU);
    bool eHptYZc(double SFtlpYbIZJI);
    double lwawxXlYUxtheFI(bool YRBrSPVwLOHek, string EQtbOsToMFTCQq, string jFPDhasLbcEP, bool FMOKdC);
protected:
    string NQnKaA;

    string QMKvAlfkPApPU(int drnjiJ, double KCbptp, int TBUeKaVQXSJo, string XjDfkxnP, double ZJOQNw);
    bool THvvSTdiRuIom(string UeBUAVPnuUaCJzQ);
    int xhbAtCvlmxKpmGr(bool ZtYwQVeXwnd);
    double GxpFYO(double UodbPHOfnKiJQuCO);
    bool DNphfSToKwkKw(bool KtomMqThDaJfRref, int PPwlR, bool xDHxEDVKahL, bool LvgeniQ);
    double RXMLawECoohCYC(string vxxyueFcyHuMQ, string lERpjcMKgs);
    bool TudovAkONnfhtLfb(string usIqQSTJuJPdN, string gZkmIUwFPHpY, int UoQqxcBtHpfgwk, double LDSYKoT, double AJVFVUIAWUlQ);
private:
    double YDDaW;
    double vXrApbScNoB;
    int ZGbyXOlKC;
    string hNjPZQyZPF;

    bool drMzV(int IpuPHpZg, bool MfVgylqiXtrJE, double xOfGEQmgiog, bool JhwVibinrV);
    bool vmaKNCVzugUNjti(bool AlNNMYyGu, bool uyYICKJATq);
    int euLyPuwBF(string hfsUsEZXSfaGgvq, string vfjAObehP, bool AEAVJRmf, bool OMKWz, bool aGYWNm);
    string IdaFrGJjBZiNjzaH();
    double FfpSvPbrw(double GtpYymIQCK, bool gvNjzOUpXNu, double giXePEQpBl, int dUIwBNhoPyN, double xiZGEcFqnKuOj);
    int piurKGU(int FbuttSgJH, string gadFFUv, int EWtLewSFs);
    string QPVqGEEygtC(bool ZzuAxwzQsKXujKL, double nXpmotaiHugde, bool ZAqHhWe);
    void apaeTP(string JTFavboScW, double xhzYtmglIUwPwC, bool WdzAseoSTXB, int tqQuTARlKbLvN);
};

double pXDTipfglVyB::LsaBDBXtt()
{
    bool Nxvzpbizf = true;
    bool WcimVPM = false;
    string vTxntRgnBE = string("ZKVEUgehAHUyOlsdWcjBTZnnTcEtxjqFVYGDSDQwiIiHmBRlGtlnSIxxrkcxZibItgjcyZMGfpOrVIZnPbuyOHyqNCvdGjDk");
    string NwRwhKFdMhCFF = string("HuTBDMdcfx");
    int IKAIfHdvaFK = -1726908627;
    int aCsTfoZ = 55146000;
    string lqTkFyY = string("vUuVLoKRZnurKbKJAGIsRTBIWzgfAOpkFGtBDmQPEWblcvGKemNPdiwoFoHctcvjuIDZgJTphgIZwmuojcdjuGlROVmnqWrvWbLzZkNaNLxEVLfZDNEHktkGvDohLqsBrdJiZOyrsgkXgCCNzYEfyyamXQWISHImsYeXyiKQQEhiFGuLeKIo");

    if (NwRwhKFdMhCFF != string("vUuVLoKRZnurKbKJAGIsRTBIWzgfAOpkFGtBDmQPEWblcvGKemNPdiwoFoHctcvjuIDZgJTphgIZwmuojcdjuGlROVmnqWrvWbLzZkNaNLxEVLfZDNEHktkGvDohLqsBrdJiZOyrsgkXgCCNzYEfyyamXQWISHImsYeXyiKQQEhiFGuLeKIo")) {
        for (int mcgRjerWFFUb = 1421664219; mcgRjerWFFUb > 0; mcgRjerWFFUb--) {
            NwRwhKFdMhCFF = NwRwhKFdMhCFF;
            vTxntRgnBE += vTxntRgnBE;
            lqTkFyY += vTxntRgnBE;
            lqTkFyY = NwRwhKFdMhCFF;
        }
    }

    for (int OdnqfXWJiJO = 622303391; OdnqfXWJiJO > 0; OdnqfXWJiJO--) {
        lqTkFyY += lqTkFyY;
        IKAIfHdvaFK /= IKAIfHdvaFK;
        lqTkFyY = NwRwhKFdMhCFF;
    }

    if (NwRwhKFdMhCFF != string("HuTBDMdcfx")) {
        for (int VWRdFV = 16237334; VWRdFV > 0; VWRdFV--) {
            WcimVPM = ! WcimVPM;
            vTxntRgnBE = lqTkFyY;
            vTxntRgnBE += NwRwhKFdMhCFF;
            aCsTfoZ *= aCsTfoZ;
        }
    }

    for (int cqzWg = 667814719; cqzWg > 0; cqzWg--) {
        aCsTfoZ += IKAIfHdvaFK;
        WcimVPM = WcimVPM;
        IKAIfHdvaFK /= IKAIfHdvaFK;
        WcimVPM = ! Nxvzpbizf;
        lqTkFyY = NwRwhKFdMhCFF;
    }

    for (int OHsPuXrFQBxFeNz = 787890933; OHsPuXrFQBxFeNz > 0; OHsPuXrFQBxFeNz--) {
        WcimVPM = Nxvzpbizf;
    }

    return 88102.9852149909;
}

void pXDTipfglVyB::jXxkkzslqPQwiLb(string pysnKvb)
{
    bool kZLfVIEzWUbM = true;
    int HDOIfxit = -895139326;
    int PJVaUgESFmgATFmL = -79415703;
    double GPlXWjvW = 438335.2242989571;
    double SgkKWfVmvvzHTtZj = -42686.61341056142;

    for (int BovtlZVStf = 1918228460; BovtlZVStf > 0; BovtlZVStf--) {
        SgkKWfVmvvzHTtZj += SgkKWfVmvvzHTtZj;
        SgkKWfVmvvzHTtZj += SgkKWfVmvvzHTtZj;
        PJVaUgESFmgATFmL *= PJVaUgESFmgATFmL;
    }

    for (int WGcUtsjJnN = 917187851; WGcUtsjJnN > 0; WGcUtsjJnN--) {
        SgkKWfVmvvzHTtZj = SgkKWfVmvvzHTtZj;
        PJVaUgESFmgATFmL *= PJVaUgESFmgATFmL;
        GPlXWjvW *= GPlXWjvW;
    }

    for (int eUgAlBQUilhIXON = 101996375; eUgAlBQUilhIXON > 0; eUgAlBQUilhIXON--) {
        pysnKvb = pysnKvb;
        PJVaUgESFmgATFmL -= PJVaUgESFmgATFmL;
    }

    for (int yqVhrtlYoKfSTp = 744967766; yqVhrtlYoKfSTp > 0; yqVhrtlYoKfSTp--) {
        kZLfVIEzWUbM = kZLfVIEzWUbM;
    }

    for (int RtlAlbY = 1853258126; RtlAlbY > 0; RtlAlbY--) {
        PJVaUgESFmgATFmL = PJVaUgESFmgATFmL;
    }

    for (int NsudxZJvY = 77283189; NsudxZJvY > 0; NsudxZJvY--) {
        continue;
    }
}

bool pXDTipfglVyB::vUWXg(int KeycOs, string TFOtpjLEkKsfIEo, bool GXUBYZqPEmQg)
{
    bool LgOzfrBWvLoNu = false;
    string AhFkoF = string("ULMvNksmcScnmIjLmTQQNtBqVPymRveoRNuXYdHdrynvoYTQXcPvmWhhRAFKjEwiVDVppGUWvRFbLTwOcpCpdyISWKKGzyOUtOhtgirPgzBrsAOqmCmVkvMzzTCGYKLbQyRVnxztfOc");
    double MwhWeVOQcnSg = 663067.3763468616;
    int BqGgMDQcGMxcZ = 226563386;
    double SFKPDd = 77063.24116338982;

    for (int THPPsHQFYRhXQv = 954688227; THPPsHQFYRhXQv > 0; THPPsHQFYRhXQv--) {
        AhFkoF = TFOtpjLEkKsfIEo;
    }

    for (int YmITIRbR = 1566642144; YmITIRbR > 0; YmITIRbR--) {
        LgOzfrBWvLoNu = ! GXUBYZqPEmQg;
        KeycOs -= BqGgMDQcGMxcZ;
    }

    if (GXUBYZqPEmQg == false) {
        for (int LzTDVqZwE = 666854392; LzTDVqZwE > 0; LzTDVqZwE--) {
            continue;
        }
    }

    if (MwhWeVOQcnSg > 77063.24116338982) {
        for (int KekYbQ = 1117329388; KekYbQ > 0; KekYbQ--) {
            GXUBYZqPEmQg = GXUBYZqPEmQg;
        }
    }

    for (int LCTWXXdiU = 1572808236; LCTWXXdiU > 0; LCTWXXdiU--) {
        MwhWeVOQcnSg *= SFKPDd;
        AhFkoF = TFOtpjLEkKsfIEo;
    }

    if (MwhWeVOQcnSg >= 663067.3763468616) {
        for (int tURzlNyqbSt = 950588978; tURzlNyqbSt > 0; tURzlNyqbSt--) {
            TFOtpjLEkKsfIEo += TFOtpjLEkKsfIEo;
            KeycOs *= BqGgMDQcGMxcZ;
        }
    }

    return LgOzfrBWvLoNu;
}

double pXDTipfglVyB::YIOHx(string zjCwCBJXCmJNVYla, int XSCajUIWLwOzJSGd, bool GkBsOciDmC)
{
    bool GKoTHPK = false;
    int HRATXEoIhuX = 666748696;

    if (HRATXEoIhuX != 666748696) {
        for (int wFSPyiARCkFKaA = 1099485551; wFSPyiARCkFKaA > 0; wFSPyiARCkFKaA--) {
            continue;
        }
    }

    if (HRATXEoIhuX < 666748696) {
        for (int OoUaAHPfoH = 930094071; OoUaAHPfoH > 0; OoUaAHPfoH--) {
            HRATXEoIhuX += HRATXEoIhuX;
            GKoTHPK = GkBsOciDmC;
        }
    }

    return -617515.8898130677;
}

int pXDTipfglVyB::zxqAItC(int qrECnT, double LHTYlJJlxjsTU)
{
    double PEwHGHtS = -938167.4320191913;
    bool tCYKdRJf = false;
    int BaWCQSpqPYTGA = -1376525994;
    bool xOEetgPYRrtK = false;
    bool ceIKiGEXQEwnFVn = false;

    for (int cCMLa = 406688295; cCMLa > 0; cCMLa--) {
        tCYKdRJf = xOEetgPYRrtK;
    }

    for (int eDuOpGLUI = 2055298645; eDuOpGLUI > 0; eDuOpGLUI--) {
        tCYKdRJf = ! tCYKdRJf;
        xOEetgPYRrtK = ! tCYKdRJf;
    }

    for (int hSpLUPzgti = 2124960759; hSpLUPzgti > 0; hSpLUPzgti--) {
        PEwHGHtS *= PEwHGHtS;
        qrECnT += BaWCQSpqPYTGA;
    }

    for (int ifncvnWWhTf = 23093918; ifncvnWWhTf > 0; ifncvnWWhTf--) {
        tCYKdRJf = xOEetgPYRrtK;
        qrECnT /= BaWCQSpqPYTGA;
    }

    if (qrECnT > -1376525994) {
        for (int yCtzUfeBiUbq = 313888484; yCtzUfeBiUbq > 0; yCtzUfeBiUbq--) {
            xOEetgPYRrtK = ! ceIKiGEXQEwnFVn;
            LHTYlJJlxjsTU += LHTYlJJlxjsTU;
            xOEetgPYRrtK = xOEetgPYRrtK;
        }
    }

    for (int uoRLQvjDZQAmHSW = 920847670; uoRLQvjDZQAmHSW > 0; uoRLQvjDZQAmHSW--) {
        qrECnT /= qrECnT;
        BaWCQSpqPYTGA += qrECnT;
    }

    if (ceIKiGEXQEwnFVn != false) {
        for (int QKORbxHnveAoG = 567851332; QKORbxHnveAoG > 0; QKORbxHnveAoG--) {
            continue;
        }
    }

    return BaWCQSpqPYTGA;
}

bool pXDTipfglVyB::eHptYZc(double SFtlpYbIZJI)
{
    string frxiilIuxOKNk = string("LjXbzNASTIKsnkIQjUKXQCBfyUnargSxilzFHHTdvFytWfzTPXdGuvJBRpqrTXphrhfWFgcsiGHljoBzQhdDArRQUQtPIsmUopStMPvlIpeiAnOqfDijOXNBBTWsGLyDGSfVRsBFtdyoWZCWCcghXssAGwJMpCXhJBAwBesZhzyDtMKTXnALJFGIMOOwZVBRmxiyjBjOrtn");
    string EfQlm = string("CxGwYofgwQoZFmzolfSByixZaeTChEZfBEKRIbxkdthYNNfTaovVjTlRNmBNRgBKuMqgpYPwzVGWzdtOwjwEBRFYoiCiLQzMnDobaWKHXWAEnWFYJEFOqGsjwgNPHdihYfHotOAeCMuPUipJXxGKApVPnmSeBeEtMnCRxKLJqUOItPlAkUQisiYYnmbvmrhVhOTchGYxoTMxWiqTZKJsZGXsNQU");
    string sdkZhfIAYrAArudy = string("AJVCpjUsApuPCZsyyZdjFotLlIh");
    int JgaqXNkZWPRNKEK = -1458474079;
    int LUuIoiccwgfYYm = -1990689435;
    string ginVLQZQJnronO = string("snORaNNjzIyLPDIgYcxnxfGmrXVtGnwcaQWOQbLdmRDJOnZjNnAGKKgGwZcnLUgDwdFPtwbhTqzhMlIrIAKoeAHPcGLfaxhrYcVjQsdUPvzrFDsZqIvbgUtYygbWwBUbsZAZmbAhiPtCyDzZvpoWQkMddpVfPLSWbidOaKvdeZZJUEQFdtNphZxDuQ");
    int VEDNUyunvreH = 324582200;

    for (int cjqNZhDmV = 1631557058; cjqNZhDmV > 0; cjqNZhDmV--) {
        JgaqXNkZWPRNKEK /= VEDNUyunvreH;
        frxiilIuxOKNk += ginVLQZQJnronO;
        LUuIoiccwgfYYm = LUuIoiccwgfYYm;
        VEDNUyunvreH -= JgaqXNkZWPRNKEK;
    }

    if (SFtlpYbIZJI >= 144492.16215623458) {
        for (int YkRkwdyWLLER = 1858744847; YkRkwdyWLLER > 0; YkRkwdyWLLER--) {
            frxiilIuxOKNk = ginVLQZQJnronO;
            JgaqXNkZWPRNKEK = VEDNUyunvreH;
            VEDNUyunvreH *= VEDNUyunvreH;
            JgaqXNkZWPRNKEK -= LUuIoiccwgfYYm;
        }
    }

    if (JgaqXNkZWPRNKEK > -1990689435) {
        for (int vddkDruloN = 435387057; vddkDruloN > 0; vddkDruloN--) {
            EfQlm = sdkZhfIAYrAArudy;
            frxiilIuxOKNk += sdkZhfIAYrAArudy;
        }
    }

    if (sdkZhfIAYrAArudy != string("AJVCpjUsApuPCZsyyZdjFotLlIh")) {
        for (int nHamqmUGEcjSD = 2037276117; nHamqmUGEcjSD > 0; nHamqmUGEcjSD--) {
            continue;
        }
    }

    for (int eoDEOadkcahVXESV = 1510003275; eoDEOadkcahVXESV > 0; eoDEOadkcahVXESV--) {
        ginVLQZQJnronO += EfQlm;
        LUuIoiccwgfYYm -= VEDNUyunvreH;
        VEDNUyunvreH *= LUuIoiccwgfYYm;
    }

    for (int XLZbSMfL = 2106265908; XLZbSMfL > 0; XLZbSMfL--) {
        EfQlm = sdkZhfIAYrAArudy;
        EfQlm += EfQlm;
        ginVLQZQJnronO += EfQlm;
    }

    return true;
}

double pXDTipfglVyB::lwawxXlYUxtheFI(bool YRBrSPVwLOHek, string EQtbOsToMFTCQq, string jFPDhasLbcEP, bool FMOKdC)
{
    bool jiGDHcppKVznVotp = false;
    double kdwXuw = -679586.7561481118;
    string mBTyPsr = string("cYaxFtaAmPrRnRDonCGwYbaIq");
    bool GAZNYd = false;
    bool LxzMuwTpPvSQR = true;

    if (kdwXuw != -679586.7561481118) {
        for (int rMeUkvCS = 32104385; rMeUkvCS > 0; rMeUkvCS--) {
            jiGDHcppKVznVotp = YRBrSPVwLOHek;
            jFPDhasLbcEP = EQtbOsToMFTCQq;
        }
    }

    for (int KhNwtTYBbVfU = 330985930; KhNwtTYBbVfU > 0; KhNwtTYBbVfU--) {
        EQtbOsToMFTCQq = mBTyPsr;
        mBTyPsr = jFPDhasLbcEP;
    }

    return kdwXuw;
}

string pXDTipfglVyB::QMKvAlfkPApPU(int drnjiJ, double KCbptp, int TBUeKaVQXSJo, string XjDfkxnP, double ZJOQNw)
{
    string tAoiAenYFLjW = string("DUiHGcPkFqvpcfxVe");
    bool TdCMBCYHa = false;
    double IvYxmjX = -643906.9631108086;
    double nXXOIsTZnjc = 621919.9719145204;
    double cmdMOeAahEwVLMS = -681771.3906621992;
    string QLjKIb = string("VwmKoxMjvUdmARxJfLwVVHjPLeoHdSwsPFtnFaJtjdMyUzeWOWXLOFFLNSNeECH");
    double BgInKFDr = 308367.44010924496;
    string mmxgElqXLYRCPF = string("jAmFgtOVkMaBqpyIeMaLMbiTILchCCKgndiOvobtTMQxAOHE");
    double rWlxGNrhj = -199131.78082969872;
    double FKYzfHqxQVTmkC = 572032.1265780724;

    for (int dYOXZU = 2077440885; dYOXZU > 0; dYOXZU--) {
        ZJOQNw *= ZJOQNw;
        IvYxmjX /= FKYzfHqxQVTmkC;
        ZJOQNw -= BgInKFDr;
    }

    for (int lNLyJp = 488435239; lNLyJp > 0; lNLyJp--) {
        FKYzfHqxQVTmkC += BgInKFDr;
    }

    for (int ojojxsZBSIDYyhs = 1185890980; ojojxsZBSIDYyhs > 0; ojojxsZBSIDYyhs--) {
        ZJOQNw -= IvYxmjX;
    }

    if (BgInKFDr >= 621919.9719145204) {
        for (int XbUfGXO = 151852117; XbUfGXO > 0; XbUfGXO--) {
            KCbptp *= rWlxGNrhj;
        }
    }

    if (cmdMOeAahEwVLMS > 572032.1265780724) {
        for (int lFGxViHJ = 1968473409; lFGxViHJ > 0; lFGxViHJ--) {
            cmdMOeAahEwVLMS *= IvYxmjX;
            nXXOIsTZnjc += ZJOQNw;
            drnjiJ += TBUeKaVQXSJo;
            BgInKFDr = IvYxmjX;
            rWlxGNrhj *= nXXOIsTZnjc;
        }
    }

    return mmxgElqXLYRCPF;
}

bool pXDTipfglVyB::THvvSTdiRuIom(string UeBUAVPnuUaCJzQ)
{
    int WxyPB = -1648272933;
    bool bIPvteCfLSBp = false;

    for (int QOeHyeJuVteBK = 695958420; QOeHyeJuVteBK > 0; QOeHyeJuVteBK--) {
        WxyPB -= WxyPB;
        WxyPB += WxyPB;
        bIPvteCfLSBp = bIPvteCfLSBp;
    }

    for (int sXlJqtNPvw = 351208863; sXlJqtNPvw > 0; sXlJqtNPvw--) {
        WxyPB *= WxyPB;
        WxyPB = WxyPB;
        bIPvteCfLSBp = ! bIPvteCfLSBp;
        WxyPB /= WxyPB;
        UeBUAVPnuUaCJzQ = UeBUAVPnuUaCJzQ;
        WxyPB -= WxyPB;
    }

    if (bIPvteCfLSBp != false) {
        for (int FfCpXfJgVTnD = 968104192; FfCpXfJgVTnD > 0; FfCpXfJgVTnD--) {
            continue;
        }
    }

    if (bIPvteCfLSBp == false) {
        for (int TchbQRQzfiWmE = 1991765957; TchbQRQzfiWmE > 0; TchbQRQzfiWmE--) {
            continue;
        }
    }

    return bIPvteCfLSBp;
}

int pXDTipfglVyB::xhbAtCvlmxKpmGr(bool ZtYwQVeXwnd)
{
    int DxmYaTz = 407583167;
    bool hnTcNfhuLKougC = true;
    string sSxdKnTrACtd = string("sacUPwfVtRuBQrsdWT");
    string uZfQzGBHV = string("ZsczNgPnlNzZOGUnKncGvdNsUqoeFFYBiwbrnQLWZjdBxSCKTPDPaTJZUcoJRdhJySXtYMbtLDRRzZuUBJvTHjZeaWOWLCudWFmMIibjtHtxBqqInYeJxeVsqKWzDXuEiKjjRVGTshAjBlwBziDjXmDcUKxNizLVtOLmIGFNghmsvHuihWtliuOctDJDRnCDwSvSvDETimiZQtdwlLIRo");
    int qrqpPAh = 977259277;
    double QTvaNm = 954420.8527361996;
    double aulextgoNsfRa = 564158.1622105241;
    int DHcQdlsSQFmjVRQ = -1921738808;
    bool ukxCJyz = false;

    return DHcQdlsSQFmjVRQ;
}

double pXDTipfglVyB::GxpFYO(double UodbPHOfnKiJQuCO)
{
    double JSnGLjt = -664157.4906009219;
    int EYkRJURjSIHM = 1056171468;
    string hemiDbBvwJ = string("KdhLgvZfDoPYLAUjvzPnWeubTwDefuAqErIMsQRfKnbIaBSSMcygIHbSauXTDHqNyfydGkZLcoZDtyHAWchUZPrsxRrSGRBVjnxnOSfnhWnVVPrcLnHlAvYcRDHetMDvhPGWWoRastdxyrsKphHBqNvkVPjZhHzbeMbHMsJOAjxWhWrDfglovRqPDuZVuPfDxcSLYc");
    double urIPQuqcROBneO = -771213.217284874;
    int PiHOMkD = 804702854;
    int eXinT = -794038518;
    bool sYICbZjwxVBeM = false;
    double IDnMOQlJqN = 47415.9706902469;
    bool NVFPkxAwYX = false;

    for (int EaacdGb = 119423175; EaacdGb > 0; EaacdGb--) {
        IDnMOQlJqN *= UodbPHOfnKiJQuCO;
        hemiDbBvwJ += hemiDbBvwJ;
    }

    for (int iJLoQ = 2098705678; iJLoQ > 0; iJLoQ--) {
        PiHOMkD = PiHOMkD;
        urIPQuqcROBneO /= IDnMOQlJqN;
        hemiDbBvwJ = hemiDbBvwJ;
    }

    return IDnMOQlJqN;
}

bool pXDTipfglVyB::DNphfSToKwkKw(bool KtomMqThDaJfRref, int PPwlR, bool xDHxEDVKahL, bool LvgeniQ)
{
    string grNqP = string("ORKDQPTybjwzVmwgDwPBgdzym");
    int RQxxUFpC = -2073873641;

    for (int yZQjcZ = 1309133046; yZQjcZ > 0; yZQjcZ--) {
        xDHxEDVKahL = ! xDHxEDVKahL;
        PPwlR *= PPwlR;
        LvgeniQ = ! KtomMqThDaJfRref;
    }

    for (int QcRMbJKVuyraF = 62834542; QcRMbJKVuyraF > 0; QcRMbJKVuyraF--) {
        xDHxEDVKahL = xDHxEDVKahL;
    }

    if (LvgeniQ != false) {
        for (int oBqTBWpFEJfjvVGg = 241782493; oBqTBWpFEJfjvVGg > 0; oBqTBWpFEJfjvVGg--) {
            KtomMqThDaJfRref = ! KtomMqThDaJfRref;
        }
    }

    for (int GphksjnKMhPUiNRK = 880692787; GphksjnKMhPUiNRK > 0; GphksjnKMhPUiNRK--) {
        KtomMqThDaJfRref = xDHxEDVKahL;
        KtomMqThDaJfRref = xDHxEDVKahL;
        xDHxEDVKahL = ! LvgeniQ;
    }

    for (int voGOOMrkRqTPjeiT = 913230193; voGOOMrkRqTPjeiT > 0; voGOOMrkRqTPjeiT--) {
        xDHxEDVKahL = ! KtomMqThDaJfRref;
    }

    if (RQxxUFpC > -805254681) {
        for (int pSxDKBrpLM = 771066184; pSxDKBrpLM > 0; pSxDKBrpLM--) {
            continue;
        }
    }

    if (grNqP >= string("ORKDQPTybjwzVmwgDwPBgdzym")) {
        for (int iJmjnptvuXyPv = 419755363; iJmjnptvuXyPv > 0; iJmjnptvuXyPv--) {
            continue;
        }
    }

    return LvgeniQ;
}

double pXDTipfglVyB::RXMLawECoohCYC(string vxxyueFcyHuMQ, string lERpjcMKgs)
{
    int meGYVNRhTZDdzIL = 1245611748;
    double BVblkIfRXJ = 1039660.801749435;
    bool TAhjNeFb = false;
    bool zNrHguN = false;
    int tMYfbXn = 781934172;
    bool FyjCX = false;
    int oyrCwoAQNVGxAU = -1150110752;
    bool ngWonGZ = false;

    if (oyrCwoAQNVGxAU >= 781934172) {
        for (int jvLuOYXyDdlZazB = 1896194203; jvLuOYXyDdlZazB > 0; jvLuOYXyDdlZazB--) {
            TAhjNeFb = ! FyjCX;
            FyjCX = FyjCX;
        }
    }

    for (int FfqkaHDlKBeECq = 180507790; FfqkaHDlKBeECq > 0; FfqkaHDlKBeECq--) {
        continue;
    }

    return BVblkIfRXJ;
}

bool pXDTipfglVyB::TudovAkONnfhtLfb(string usIqQSTJuJPdN, string gZkmIUwFPHpY, int UoQqxcBtHpfgwk, double LDSYKoT, double AJVFVUIAWUlQ)
{
    double OBOBMZ = 498043.059530737;
    bool WqyMOu = true;
    double HNoVvWtElZ = 616286.9920408238;
    double KcdDhMEyIQtmnaP = 452095.6652274047;
    string uvHXLcfTgknJ = string("jPoSjhwbJbLRGPlrBXivrqtpNVeRrfYuSjnwjJuKTBtyQOsumyYYOvXYYDPUhkpFlnhwtNZUZrcVMSgPhxGoNMuuPJP");

    for (int HqpwRFdwcdv = 1463976875; HqpwRFdwcdv > 0; HqpwRFdwcdv--) {
        AJVFVUIAWUlQ *= AJVFVUIAWUlQ;
    }

    for (int EOqqVbqgtzjsuVN = 705213760; EOqqVbqgtzjsuVN > 0; EOqqVbqgtzjsuVN--) {
        LDSYKoT -= KcdDhMEyIQtmnaP;
        KcdDhMEyIQtmnaP -= LDSYKoT;
        gZkmIUwFPHpY = usIqQSTJuJPdN;
    }

    return WqyMOu;
}

bool pXDTipfglVyB::drMzV(int IpuPHpZg, bool MfVgylqiXtrJE, double xOfGEQmgiog, bool JhwVibinrV)
{
    int QgzuaRTYIpsM = 993413531;
    bool ZiWfJgSRgpM = true;
    string iQelZ = string("HHQtFOjktLKfYnipNtNdEKHUlq");
    double wLkvvcpDHl = 503639.96223411756;
    int ukxKCpWv = 588402391;
    int DClMJJjQkEuru = 589580656;
    int XIPsVrH = -259527753;

    for (int azPrbwMOh = 895146107; azPrbwMOh > 0; azPrbwMOh--) {
        XIPsVrH -= IpuPHpZg;
        XIPsVrH *= IpuPHpZg;
    }

    for (int cXrajEjyETzuiJ = 912530953; cXrajEjyETzuiJ > 0; cXrajEjyETzuiJ--) {
        ukxKCpWv += ukxKCpWv;
        QgzuaRTYIpsM = DClMJJjQkEuru;
        XIPsVrH /= QgzuaRTYIpsM;
    }

    for (int ctsCPevMzXEtWHNM = 973901674; ctsCPevMzXEtWHNM > 0; ctsCPevMzXEtWHNM--) {
        QgzuaRTYIpsM += QgzuaRTYIpsM;
        xOfGEQmgiog = wLkvvcpDHl;
    }

    for (int zxBGygtn = 1570186405; zxBGygtn > 0; zxBGygtn--) {
        xOfGEQmgiog /= xOfGEQmgiog;
    }

    return ZiWfJgSRgpM;
}

bool pXDTipfglVyB::vmaKNCVzugUNjti(bool AlNNMYyGu, bool uyYICKJATq)
{
    string MQbSZySv = string("xixBnqo");

    for (int pIPIWDt = 1369475157; pIPIWDt > 0; pIPIWDt--) {
        AlNNMYyGu = ! uyYICKJATq;
        uyYICKJATq = uyYICKJATq;
        MQbSZySv += MQbSZySv;
    }

    for (int uLZGWEkWqYXDXf = 23904297; uLZGWEkWqYXDXf > 0; uLZGWEkWqYXDXf--) {
        uyYICKJATq = ! uyYICKJATq;
        uyYICKJATq = ! AlNNMYyGu;
        AlNNMYyGu = AlNNMYyGu;
        MQbSZySv = MQbSZySv;
    }

    if (AlNNMYyGu != false) {
        for (int oHDfoYQnIAZijaed = 1244798888; oHDfoYQnIAZijaed > 0; oHDfoYQnIAZijaed--) {
            uyYICKJATq = ! AlNNMYyGu;
        }
    }

    return uyYICKJATq;
}

int pXDTipfglVyB::euLyPuwBF(string hfsUsEZXSfaGgvq, string vfjAObehP, bool AEAVJRmf, bool OMKWz, bool aGYWNm)
{
    int vMXziNrG = 1633206040;
    double NOSXjzeT = -10684.45495893099;
    string HaNEKzXwnBT = string("HhhyusHgjWlrQUOoMVzDsonMUYJaxBLVWwdhqmMWxnGsDHZgvxfvuXyXWscgFSyAUAsXjcXcDpZsYGGdQHzxUMXMQTLulikdRZIhddlwFDPHfoXWUhVTuiJeeTkSMVDdXtwNByyQQXGrDtxMqAJnARqNwNDRwDH");
    double TXCHrSPgloYv = 717705.7513174198;
    int lgONRfTMzM = 434613995;
    string zalNkZpRHwTZVg = string("zkWFSjObiwUzlUUyAHmvPqUoSZWOSufuZfvLOsdubiPzjZkUhyvTugwxZLwKZSejvLUdUGYEYNPMNGiZlKmbKNeWMIOLgxuTNqNQQWlLlyssaCftTciuuFVKzCLsTfBXySkwyENKxHbUyQmtlGxShpaCOoVuDyeKkVukotmVlVJcGDulJWHjBfdflvHOYcLkSvy");
    double BfCIxdPaGDZbzr = 962912.8068939971;
    double fCBVMOwgvf = 929277.3755373744;
    bool GsooTJwTvBpIf = false;

    return lgONRfTMzM;
}

string pXDTipfglVyB::IdaFrGJjBZiNjzaH()
{
    string JFasvvQSxkUpqnZk = string("xCsPJhhTABms");
    double HwtPOcxxhKnFvnVl = -620261.9549098839;
    bool TsSmAvLMGky = false;
    double NYYmMKzy = -61546.239389497394;
    bool kzLBqIxjUgrCsu = false;
    bool XmcRPiDqurHsAx = false;
    int gVQZBeL = 1159545486;
    bool qxLKJzBl = true;
    string eHSCgaaR = string("NtXwdDDsdsfmdxyZoBtVjpTOhVuxGOogCRpqFyPOblcKnluNBcfTLdzwIXTzvExdgPphVLOoxFaSKnffrVlCnNhpBCuMltBtVDYoFimelDBiYLmtkoWhgYGfBrpoCgQzJMDTfyzJcACSxXISBuvSPUacTQrvOj");
    int FFLXfBALPGXlWYcK = 428794813;

    if (kzLBqIxjUgrCsu == true) {
        for (int CFlfzFS = 1983657438; CFlfzFS > 0; CFlfzFS--) {
            JFasvvQSxkUpqnZk += eHSCgaaR;
            XmcRPiDqurHsAx = qxLKJzBl;
        }
    }

    for (int YgAGiSUUm = 1809296134; YgAGiSUUm > 0; YgAGiSUUm--) {
        continue;
    }

    return eHSCgaaR;
}

double pXDTipfglVyB::FfpSvPbrw(double GtpYymIQCK, bool gvNjzOUpXNu, double giXePEQpBl, int dUIwBNhoPyN, double xiZGEcFqnKuOj)
{
    double sycIaYbyNc = 687598.8635663915;
    bool KXcMlZEzLZZfm = true;
    int FBGoBejWHVKgi = 316306248;
    bool tbFCfBCQixVdgVcL = false;
    double GZuejSrX = 811472.7374414759;

    if (sycIaYbyNc == 811472.7374414759) {
        for (int FWaoAYxNslgNwUZr = 1326889044; FWaoAYxNslgNwUZr > 0; FWaoAYxNslgNwUZr--) {
            GZuejSrX += sycIaYbyNc;
            gvNjzOUpXNu = ! gvNjzOUpXNu;
            gvNjzOUpXNu = ! gvNjzOUpXNu;
            sycIaYbyNc = xiZGEcFqnKuOj;
        }
    }

    for (int NrmQaChSY = 1447349962; NrmQaChSY > 0; NrmQaChSY--) {
        GZuejSrX = GZuejSrX;
        giXePEQpBl /= xiZGEcFqnKuOj;
        tbFCfBCQixVdgVcL = ! KXcMlZEzLZZfm;
        KXcMlZEzLZZfm = ! KXcMlZEzLZZfm;
        giXePEQpBl = GtpYymIQCK;
    }

    if (GZuejSrX <= 822107.5689198589) {
        for (int RQsXVMqGCmGLYS = 1994061311; RQsXVMqGCmGLYS > 0; RQsXVMqGCmGLYS--) {
            gvNjzOUpXNu = ! KXcMlZEzLZZfm;
            FBGoBejWHVKgi -= FBGoBejWHVKgi;
        }
    }

    if (GZuejSrX >= -241921.87311323095) {
        for (int GiIUBzZYMLCEwS = 996069501; GiIUBzZYMLCEwS > 0; GiIUBzZYMLCEwS--) {
            giXePEQpBl *= sycIaYbyNc;
            GZuejSrX *= GZuejSrX;
            xiZGEcFqnKuOj -= GZuejSrX;
            FBGoBejWHVKgi -= dUIwBNhoPyN;
        }
    }

    for (int DyijfaTebrJnE = 390327031; DyijfaTebrJnE > 0; DyijfaTebrJnE--) {
        giXePEQpBl = giXePEQpBl;
        giXePEQpBl -= GtpYymIQCK;
    }

    for (int EnnQSaiLZADTTpx = 1880431522; EnnQSaiLZADTTpx > 0; EnnQSaiLZADTTpx--) {
        continue;
    }

    return GZuejSrX;
}

int pXDTipfglVyB::piurKGU(int FbuttSgJH, string gadFFUv, int EWtLewSFs)
{
    int nQFiQbabRmsbcE = -1658151202;
    double HdsGiGuCItMkYstH = -400376.2797090669;
    bool enQKaqsKbMdguk = true;
    string LqhOV = string("HTJ");
    double GrIOb = -145272.75928730314;

    for (int sTyeG = 2048524471; sTyeG > 0; sTyeG--) {
        EWtLewSFs *= FbuttSgJH;
        gadFFUv += LqhOV;
        HdsGiGuCItMkYstH += GrIOb;
    }

    return nQFiQbabRmsbcE;
}

string pXDTipfglVyB::QPVqGEEygtC(bool ZzuAxwzQsKXujKL, double nXpmotaiHugde, bool ZAqHhWe)
{
    string ixUXitzoiQPkpYc = string("jIfNOPzXavdwRKfygNzNSaiuPwXFWwjbROgPDZyHrvcYqIKAvjrfKxfbtFUUYiqAPsXfBFouyDjjctyxcvoUWThSJzscVNFkxiVCYDYfqSARctUfiBbPMxVxfYIz");
    bool UXpiHYoxi = false;
    string AHAaTIbslxBJpmr = string("ngBPvupEgqRaxAyo");
    double dEEUpSeVlQ = 168341.16685761415;
    double SPtxTUer = -987849.7755650552;
    double OzAxm = -2127.0235372873144;

    return AHAaTIbslxBJpmr;
}

void pXDTipfglVyB::apaeTP(string JTFavboScW, double xhzYtmglIUwPwC, bool WdzAseoSTXB, int tqQuTARlKbLvN)
{
    string SrjYfJ = string("KsvnJBTrjjFEuyIyVFuctgskvyXBQcrMOJGEVpdJ");
    string FAcBLgvnLQN = string("MITcDFJhXDoQQAEXKkKPLmjhqtWSJoKxnlAKSLSKEUsRRKLTBWScnVahPbWsbQqMapzLmhCKDjQozIGaWWRMVxjCHnWWmEAMzEDlgQDUcZNjXlJqRuuMeaSjAaRz");
    string SXPHXAyvorBc = string("MhnBirPLJyEceEUUlCnfWqZJqgVMNL");
    string MmVOJwqiacCu = string("gsPOWELITABYfpHoABhJMVgrbdednmJeIXRPkBvBoihmnsSceaMghYaTBrHgTRjwWYhovKEhoteZgmoakDnRtHOAQEkXWiMCPMYCF");
    int Kjkhrqxuxyymz = -1059130687;
    string xFeARkFX = string("lpECHBKlRcGZEAcqyyJPPJcNdyURjVkKGhPrhZOYcJocrMU");
    bool paHxTaAcWb = true;

    for (int XENmFwXJHjpVfvP = 1240186479; XENmFwXJHjpVfvP > 0; XENmFwXJHjpVfvP--) {
        JTFavboScW += MmVOJwqiacCu;
    }

    if (JTFavboScW < string("BNHhzBXWQJUXkBNzFcLomYSjnYhWRSFwXGONTbQuAqchPvYTIoVNJvQvIIyFcFSjgbpFhSKwMQEpiGDyPojbTmzYTMArJySaXbkUXbxXfkpbHxIGtXqAgFACJZRXNlCPMMORkehrvDcoTpNQUamuVKrxRRECijFfyPPDNNFRsVQloTR")) {
        for (int rUfcYmGgQeZiuONB = 644117264; rUfcYmGgQeZiuONB > 0; rUfcYmGgQeZiuONB--) {
            xFeARkFX += MmVOJwqiacCu;
            SXPHXAyvorBc = MmVOJwqiacCu;
            WdzAseoSTXB = ! WdzAseoSTXB;
        }
    }

    if (SrjYfJ == string("lpECHBKlRcGZEAcqyyJPPJcNdyURjVkKGhPrhZOYcJocrMU")) {
        for (int tmekX = 1461065508; tmekX > 0; tmekX--) {
            JTFavboScW = xFeARkFX;
            tqQuTARlKbLvN -= tqQuTARlKbLvN;
            SXPHXAyvorBc += JTFavboScW;
        }
    }
}

pXDTipfglVyB::pXDTipfglVyB()
{
    this->LsaBDBXtt();
    this->jXxkkzslqPQwiLb(string("JaWFRbowRixFHVtVJeMXLOQbfucscVPPklgiNdWIrlAkZsbfOTrpLQyctWGyNwlRFjPAyugAacLHMGMOgagVjdhVjjeRfwKJZVDnCyubVvREZzRfCoYvZEkpLZRpRjEYsuNNLKFzcsJRSUoSTIKNbbReRXVTESOYDDDbaMYWHfevusNVfQrUUiNVcFk"));
    this->vUWXg(-1159205270, string("MpfHTgdXuyjZKwMRlFbBjizMrTugeKXkvMMkTNEGmCBsvLkvWvElRifAClAgLkRapajttUoqpvJzapLNHGAnOmUBXriAQSgUYorStFBqVabuzidMChbjHEahtFbFNscoShiTFcp"), false);
    this->YIOHx(string("KBrNoBHfjGLVxKAyEZsqqpBrpgMScNdgRuhNXJesMNriYwupdIWbnexzxSJnKxDTinQPQgmOnrGwpQyGA"), -1127046298, false);
    this->zxqAItC(705787621, 73766.36876511307);
    this->eHptYZc(144492.16215623458);
    this->lwawxXlYUxtheFI(false, string("jSLroVVGbkSCDTGzWpaYaRNCUx"), string("PJAxLJSNlFFYObINLbkmusOHEwXUOvninqeQOzoGHPtXPGgxbXAlejnNZrcFDsBJEdakLcudxTNtltgfRUMazxsaSUVHUSstXhv"), true);
    this->QMKvAlfkPApPU(2050734419, 384346.5011522201, -1805234342, string("wmgYUAFuDjbKWCwaeqwBfDaiQMRpHopGSLnIbAZsZvSMjcFOlJMDAiDsJCWivGkfMtOZMOtgaa"), -105786.4861618848);
    this->THvvSTdiRuIom(string("hceDSUEbonAfrdzPbrfQOVlbztuDLwgwfwOiePwdwfZeIUnLDiQzfpnNiuSDEkrflNczPIuIzpzClQdhtKWpSgbcsKmfBxAnOjgBQNCZeCvSVEqFZYPpDAyyfbBIdsUqufjtafBwRioGIDGfnKTqxpJSUvfRsrriokYUlaRcIalYzjfOehLKcKHcNmcrOCEIykmKitdAiCYyslFircubYhhev"));
    this->xhbAtCvlmxKpmGr(false);
    this->GxpFYO(-124366.74700705869);
    this->DNphfSToKwkKw(false, -805254681, true, false);
    this->RXMLawECoohCYC(string("moSRBlwxCzcCzfEScXVjIHGlcWRIReDpiJwNujmzjrMLjZAiJQCFbkkMqcGTbFfMOHXONJWxsStkixMgxhOaNCbVfTpUdaMNR"), string("vkEcZPsHtlorkQLMtrIXbtmJXhdCjXQpGTdsBmRvMICnQfphmjqjsaYrLjyduqcuEBXLZWTURH"));
    this->TudovAkONnfhtLfb(string("HiBKlAKPLUvxpnMJLuwidZlaBexxPXdzBKPFAyDRclIgWewZDycqYXyyppZRLHUQwKTCUFbLULNTZUdzSQddReDdJGiyqXzLplHuxJjJwROJkKvBgEeeSzYTVKLYYqxtnuxqSfaqNrsOSEFyUtNzrnbVkeEItlboqGxsYvVxsamAzdSOQkzTMPhMYVSffPmcyLPGyviMbDUsPYazLvwuCAppyCeVWVtxNVmEivmkMgbgASygwEvyoqjABwgLiRi"), string("asggbmJXWKcCrcnMHlmzYURwlkcVWuVWIPyrmfqDfpAXmACvMUVdAxDRUvrAdTxmpYfPDqnwPObfCZizpHcMsVSxMnBBeHQhnpIDHycRAXdDcYAJxGSnfLVzDSXmtiFnpJXNyniieRrXt"), -2020247646, 874390.1128708025, -266837.71240147186);
    this->drMzV(-1928954915, false, 929103.3211510258, false);
    this->vmaKNCVzugUNjti(false, false);
    this->euLyPuwBF(string("MgYTZfkJfugqyQbaKBKChlcgKPfdbsJrLGYatTmDYNVGNlseSOMVnwJVQnanSeNMzaHTkruvpmsqdXXzMdNrPIWjVOieoYQIJRSWKTOeSUTFDAGXOdYNZQvFQFaFkocyIHITiDtEsRhIssWOv"), string("zWzXDJYQefDwtcipqaGGyZRNNwSlmcjvSqmtRnNpITvOmFGQpEhMeEolOVYBqGEbopmBRteLnGKTxGmfvBxoNZGswpNTiGpiulJuotBJXfbXGEbZaFXeBangtHRMVgxpAyujFluPStFJBhtPJEeNiYQBmFwIBXHnptjXCedaeQIyGgNuqameWPXhvdWWudoeHMweMAkdEkKDYaSXkfRJCubAbRfYlilOxGjrcZNjkxBwRmzuuHcpnChIyvn"), false, true, false);
    this->IdaFrGJjBZiNjzaH();
    this->FfpSvPbrw(822107.5689198589, false, -931386.9798610321, 197794417, -241921.87311323095);
    this->piurKGU(819927182, string("HRzwQqVwMsbuHrsjcBPlqDSrshWNfsEHGSRodGAWBmUs"), 104416615);
    this->QPVqGEEygtC(true, 263622.2752992224, false);
    this->apaeTP(string("BNHhzBXWQJUXkBNzFcLomYSjnYhWRSFwXGONTbQuAqchPvYTIoVNJvQvIIyFcFSjgbpFhSKwMQEpiGDyPojbTmzYTMArJySaXbkUXbxXfkpbHxIGtXqAgFACJZRXNlCPMMORkehrvDcoTpNQUamuVKrxRRECijFfyPPDNNFRsVQloTR"), -842592.5844295558, false, 498782323);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NhPnnhLywnw
{
public:
    bool vXTWrLgFztvw;
    int mYbQgbzh;
    string pcszBCPbzHIahjX;
    bool vRbpHThQq;

    NhPnnhLywnw();
protected:
    double LnaEMwhviKhVwDKf;
    string SOvLTRlySPn;
    int afSez;
    bool PmLfTPBUq;
    bool bznOROetT;
    int LHopgyXTFhQGRU;

    void JPrdxgoPmWXshH(string WnipA, int rsVtYGfjlPxnfux, int DkFSOfnVHJvdW, bool qyoKNaBEcgWaKT, int fjcKtHqLKwzbqXuF);
    double IgjsOHN(double jaXKOdqgQRNcK, string gQfdqTK, string DaVmdPNfbHkCwbB);
    bool dRTIVHoap(double JOVdRYRNQArxEnYp, bool NBlAemUplkirNgw);
    int AKmVunT(string XbZvoCYWeWkppf, int uHfzfQEIzjpuuQtb);
    int JEaoUTUmSE(double rEzhCl, double hzXcU, int hliPKL, double pAbHrUkMgHHxB, double fMqqoukcnKPe);
    int yevnHuei(int okUdBwTvgtDT, double lyNYgnhHBIVDaUYL, string eAwViZyMUyXWPCsa, bool ewSibpXcj);
    double KQeCsBYrTZLG(string rnGtGB, int TZpaLBYsQT, bool WJEHnHB, string olDazvymMH, string MdewQ);
    string PTvplPx(int hYurUire, double NnRifKcwBhVti);
private:
    double DqlNgacHRUaKQE;
    int HXYIyonRrXOJHJE;
    bool MJloVyhpAwDKWJ;
    int IMOCGobJzHL;
    bool HtwuXwqqPvhiU;

    double YvLwdrRANBc(string IfouVLinn);
    void ycGnAQbCidTjZdV(double BCrqse);
    bool DSAOgZCamu();
};

void NhPnnhLywnw::JPrdxgoPmWXshH(string WnipA, int rsVtYGfjlPxnfux, int DkFSOfnVHJvdW, bool qyoKNaBEcgWaKT, int fjcKtHqLKwzbqXuF)
{
    bool dwIQG = false;
    double BtAimCSgGKRpmxAq = 787014.4889505112;
    bool XqVeBsneii = false;
    bool HckpFaEGWUa = true;

    if (WnipA > string("kZmXZWligNjLZfChSpTwUFznDjLukkoyejfcwmRLsdKGGvkFCqrdqHXETr")) {
        for (int yYYRdlprpxLYQKlH = 900250654; yYYRdlprpxLYQKlH > 0; yYYRdlprpxLYQKlH--) {
            HckpFaEGWUa = ! HckpFaEGWUa;
        }
    }

    if (dwIQG == false) {
        for (int CaFKlh = 1436518775; CaFKlh > 0; CaFKlh--) {
            HckpFaEGWUa = ! HckpFaEGWUa;
            fjcKtHqLKwzbqXuF -= fjcKtHqLKwzbqXuF;
            rsVtYGfjlPxnfux *= rsVtYGfjlPxnfux;
        }
    }

    for (int hLwRDWNmfKygo = 1644744091; hLwRDWNmfKygo > 0; hLwRDWNmfKygo--) {
        HckpFaEGWUa = dwIQG;
        HckpFaEGWUa = dwIQG;
        HckpFaEGWUa = XqVeBsneii;
    }

    if (fjcKtHqLKwzbqXuF > 1607826666) {
        for (int prNstEP = 1367557849; prNstEP > 0; prNstEP--) {
            qyoKNaBEcgWaKT = XqVeBsneii;
            qyoKNaBEcgWaKT = qyoKNaBEcgWaKT;
            DkFSOfnVHJvdW -= rsVtYGfjlPxnfux;
        }
    }

    for (int LWyXZrvlfhcHz = 1696719227; LWyXZrvlfhcHz > 0; LWyXZrvlfhcHz--) {
        HckpFaEGWUa = ! qyoKNaBEcgWaKT;
    }
}

double NhPnnhLywnw::IgjsOHN(double jaXKOdqgQRNcK, string gQfdqTK, string DaVmdPNfbHkCwbB)
{
    int oSowvZYz = 615544381;
    string fBeKVzNlVr = string("qeRIdWZRYzcfRgCfObfaVPHSuMWHASZmYCWwuGjvoJANavKeUAEsFBomXYCItKhbKUvurxuiHFOzwBuMABvEpZnwUkeozZzkEqtUqSIvxDrxxcKroVKZCQuRApJiSmHjJNmzfAiLKVvUSUwtviSKSrFeRyPttzvEtAXvFykbKRCxqJBXuxuMitXGZbdYVrxWiLkaKD");
    bool MZuXFJaI = true;
    double QhjQqqjD = -78347.76083519064;
    string sFwbrodmUD = string("nfrJMYdEfnYUAKtmmrtVvNimbLEsZLwNOyBHC");
    int lEjOILQt = 903197134;
    int SbjRWAyKjHV = -1086426341;
    int kybCfLgU = -1167114077;
    int cCUzPkham = 1918008105;
    int ciLAZ = 1464786250;

    for (int wofoVdHvTEvXVH = 1245312954; wofoVdHvTEvXVH > 0; wofoVdHvTEvXVH--) {
        ciLAZ *= oSowvZYz;
        DaVmdPNfbHkCwbB += fBeKVzNlVr;
    }

    return QhjQqqjD;
}

bool NhPnnhLywnw::dRTIVHoap(double JOVdRYRNQArxEnYp, bool NBlAemUplkirNgw)
{
    bool bqAuh = true;
    double FowICMAwvPKRQuw = 263151.46946982155;
    double VMAAhM = 205981.11193931755;
    bool tolXgaDJIQW = false;
    bool uHnPes = true;
    double FEySIMneOSGCwov = 370981.4654249029;
    int qYOslHbFU = -1681216345;

    for (int kiLXBTlj = 284618526; kiLXBTlj > 0; kiLXBTlj--) {
        bqAuh = ! tolXgaDJIQW;
        JOVdRYRNQArxEnYp /= JOVdRYRNQArxEnYp;
        bqAuh = bqAuh;
    }

    for (int ZEOMJyUOLpt = 649207198; ZEOMJyUOLpt > 0; ZEOMJyUOLpt--) {
        uHnPes = tolXgaDJIQW;
        FowICMAwvPKRQuw -= VMAAhM;
    }

    for (int CwAfxnEwDoQK = 1555914848; CwAfxnEwDoQK > 0; CwAfxnEwDoQK--) {
        FEySIMneOSGCwov += VMAAhM;
    }

    for (int SzoAZkV = 42063445; SzoAZkV > 0; SzoAZkV--) {
        continue;
    }

    if (tolXgaDJIQW != false) {
        for (int sfxLbb = 1644325119; sfxLbb > 0; sfxLbb--) {
            bqAuh = uHnPes;
            bqAuh = ! bqAuh;
        }
    }

    return uHnPes;
}

int NhPnnhLywnw::AKmVunT(string XbZvoCYWeWkppf, int uHfzfQEIzjpuuQtb)
{
    string ZVXPdtJW = string("BaGqsSbwOVFyTUJTzjTrjVVUveJXHmuveJTWmZBGqjzEmixFjsuRsbWRuiiizzUAOdlaHWVqdGXlpLoRlTAWTxlxLQ");
    bool caYJmvopQSSOO = true;
    string TzmHspwdnez = string("NPFcRCYsKUIVLR");
    int HuMAJMjryZkPepua = -1935030593;
    int vFhocMcRRCPlutcI = -1799357300;
    int yJqiOdEMIyGyW = 675622343;
    string NUOAkhGroy = string("NLnYKprKzEXwxhcfwrVMFlUBRzyUTHIKfPsbXUJGTKMoSnZYemEsPuveCwKSnhAnmvJBjxYFOWzAIdLrEMDmmcontabpGiJxywTniLKkpKqNwiUmzissuouUkqFtFByWcXcRGGgyTzOoQnAODKwpDSwXOXZXkEiLeStxOYnwvrvCJynKVkHvFfYhHXyXHNkXCWHJKwAKUBveKCOtghlugNkSAFEQpglvFUN");
    int fAtFuAA = 334642573;
    bool NtEfNgnc = false;
    double WretB = 715609.2630916118;

    if (uHfzfQEIzjpuuQtb <= 675622343) {
        for (int mGRUPFfddbfc = 2107267153; mGRUPFfddbfc > 0; mGRUPFfddbfc--) {
            yJqiOdEMIyGyW += fAtFuAA;
            vFhocMcRRCPlutcI /= yJqiOdEMIyGyW;
        }
    }

    if (NUOAkhGroy != string("BaGqsSbwOVFyTUJTzjTrjVVUveJXHmuveJTWmZBGqjzEmixFjsuRsbWRuiiizzUAOdlaHWVqdGXlpLoRlTAWTxlxLQ")) {
        for (int TnCYETKc = 693240632; TnCYETKc > 0; TnCYETKc--) {
            TzmHspwdnez += XbZvoCYWeWkppf;
            uHfzfQEIzjpuuQtb += HuMAJMjryZkPepua;
        }
    }

    if (vFhocMcRRCPlutcI < -1935030593) {
        for (int blrBgThRtKgioB = 1775254804; blrBgThRtKgioB > 0; blrBgThRtKgioB--) {
            yJqiOdEMIyGyW /= uHfzfQEIzjpuuQtb;
            NUOAkhGroy = NUOAkhGroy;
            XbZvoCYWeWkppf += ZVXPdtJW;
        }
    }

    return fAtFuAA;
}

int NhPnnhLywnw::JEaoUTUmSE(double rEzhCl, double hzXcU, int hliPKL, double pAbHrUkMgHHxB, double fMqqoukcnKPe)
{
    int pHfGk = 1801868293;
    int rECQTQlUwZjsk = -1984144690;
    bool TneqKCkH = false;
    double FEqoNxeXDFrnqd = 116198.89744477849;
    string qwchxGYybhLbe = string("egUaNFEQOxtvNKPcfNSfdzhCKtCwSnSnifcPzftDPgsTJBnjSYUFqSKQaXwPyqbxgHtpJkCADJMfgUYehWbTlvjGElObDLkauyGVfhAIAnBXGEkYgtmiNAEjLloewHwoEHdwzCzRwTVVqvcFpKDlZtefUsSlmypHnDStGcDCVtaLWjBoqFaWjwKnHwpihhHd");
    string HGzvbUaKJbsat = string("EdyiAzAhikcieLUVsPLmLQuRgExhEeaQLiAbIrJxpTeOQKPfcyDQLmVuvzCJnajFdzxwhRskdbITVwkgCeAiRQQzhHIQCCKvGCYCRLWjdkroDZJBRFtzVeXgNAIqYBWhNhxzAbvLWOHGnHftnJdmCEFSqcxPhCRSaeWDrtVvxUSFQARkAoxQQhIAobdM");
    string stOQjqjaIIb = string("VxnuYTaqotLRRoQHkdLvPzaMbpNzBLRazPTcvVBufBMZCjjAbGezChaSMxiPaozJVpMqFnaSoWQjRIRBViPKATuewy");
    int kXigU = -450343263;

    if (pAbHrUkMgHHxB >= -945096.9101834566) {
        for (int hQdCFoN = 1561111434; hQdCFoN > 0; hQdCFoN--) {
            rECQTQlUwZjsk /= pHfGk;
        }
    }

    for (int gSXKptedZi = 685111417; gSXKptedZi > 0; gSXKptedZi--) {
        pHfGk /= pHfGk;
        qwchxGYybhLbe += qwchxGYybhLbe;
    }

    return kXigU;
}

int NhPnnhLywnw::yevnHuei(int okUdBwTvgtDT, double lyNYgnhHBIVDaUYL, string eAwViZyMUyXWPCsa, bool ewSibpXcj)
{
    string MbKcDgNo = string("ULnXnXjpqvYnBQSZvMZEXVbuZaQUNycwhGoTZrOqAhCBzsZsaYJKmIOCJyvqMOXhKjvJsTqNgxHkKtJrNBEicWArZqyOuOegikWIdQbPNlMZSqgBbuBhdMEUGeRgYaKktCpUFybQtcfutWoPJogSeP");
    bool CYhiPCXbxEJe = false;

    if (ewSibpXcj != true) {
        for (int jAQWRkibQtb = 143720525; jAQWRkibQtb > 0; jAQWRkibQtb--) {
            eAwViZyMUyXWPCsa = MbKcDgNo;
        }
    }

    return okUdBwTvgtDT;
}

double NhPnnhLywnw::KQeCsBYrTZLG(string rnGtGB, int TZpaLBYsQT, bool WJEHnHB, string olDazvymMH, string MdewQ)
{
    int nCvqdN = 573663728;
    string qSDuACprKsoRWlz = string("bfvcnlJeZRfieypnOnS");
    string nfiHdnU = string("fzoqlCNEdaFUEZPEMjjyzWtGJmXhtNpskHqlHjWsfpgtSyvNCFVATeGMhcDrxFGLWPNCNsuzaWfmZNUyQZeUkMSYmxaFMtpXuTcqjHtjhGmZsVndiBvwTqRJajNsvKOdUtpabvxMBmyXABpXlyXEAQozcwwmZTvpRomiTNCJoeQrcXA");
    int rSsjemtZzlaiB = -1727645980;
    double JKrfqw = -454076.07895625115;
    int GUkhjR = 1882277924;
    string hTNUITLILCQyB = string("lFGMNgpHxetrNXutNdpAHfFQVnXgVkzXQrxRGGNbgMSaelRzwkSHskFOtplrByHEcWNdWammbmDCneofFXtJZBUXAHLFtZpfifEHIPQumeUjVjpRsejLD");

    for (int UOzvb = 595223457; UOzvb > 0; UOzvb--) {
        olDazvymMH = rnGtGB;
    }

    if (TZpaLBYsQT > -1727645980) {
        for (int BKINz = 592031430; BKINz > 0; BKINz--) {
            continue;
        }
    }

    return JKrfqw;
}

string NhPnnhLywnw::PTvplPx(int hYurUire, double NnRifKcwBhVti)
{
    int wvFpKkfAnSG = -950263224;
    string CLFSxqKJixHfjP = string("psrjRyaXrEGUTwAlcSTvuBftxWvBkoJLIwbmpYbdiUeLnlCSWhfWjvlyaNmtnQQbvbJZdmQMAoSFzPHJLuwrnEerWVXpmoRaxEZXWOVQGBjgtnTLawALdNbMmxAMNW");
    int aCddokaxMGX = 3359125;

    for (int AgBKrWgs = 2122849053; AgBKrWgs > 0; AgBKrWgs--) {
        NnRifKcwBhVti = NnRifKcwBhVti;
    }

    if (wvFpKkfAnSG != 1076131808) {
        for (int ylxmaNTVnXcb = 776011463; ylxmaNTVnXcb > 0; ylxmaNTVnXcb--) {
            hYurUire *= hYurUire;
            aCddokaxMGX -= wvFpKkfAnSG;
            CLFSxqKJixHfjP += CLFSxqKJixHfjP;
        }
    }

    for (int TnKwLBZAAnT = 855208563; TnKwLBZAAnT > 0; TnKwLBZAAnT--) {
        continue;
    }

    return CLFSxqKJixHfjP;
}

double NhPnnhLywnw::YvLwdrRANBc(string IfouVLinn)
{
    int exQrWbO = -17758750;
    double XxVczX = 812049.2296352739;
    double yxESY = -744951.9022841734;
    string jIuzdiRtgB = string("TzQAcPMiOsNiWwSMVsSWCQoemFxkXIlJCsZsldozpIxImjRZBSdzXNAQAZDRASREHZMTSELVhVjCeaXCYuPSyaZptfyBWCNINMAakKZlrUgSPDoKvrmLDeWbYINCqsBwcgQvfMRMbMOJbEMnOmKJOOSDwdSJmVQNfhyXxsLzczAapvWQoXkJZdBs");
    double OhNNPSvLJQDWjNx = -633907.0694224228;
    int pZhlyXyx = 1619146183;
    int BTmRdnnWaOFAXRi = -1257363053;
    int FJcmebkuLPKQLEfc = 1360833741;
    double MxkBjgITY = 313797.81320971274;

    for (int oPoEshRHaBWAO = 2035722476; oPoEshRHaBWAO > 0; oPoEshRHaBWAO--) {
        IfouVLinn = jIuzdiRtgB;
    }

    return MxkBjgITY;
}

void NhPnnhLywnw::ycGnAQbCidTjZdV(double BCrqse)
{
    string hsLALyrKc = string("QPRqcSuoslSeyhbxVAwyzZBqdnSQjVbbvLPOAqajRbkrEisEzbvRBINtHvgtSPQQhTYoSNcZoYcnVjFXXOZTHbOMnexBZpPLrhMMXWENYFlMeMdnKpShpIOSSQPlLJIXhiJLTCzyFTVBzUfziMQFxAVYNobuOdVPYHqBjiiitazEmuvzDYOzxkYQMYaxbAizFnLrO");
    double DqtvxxSzPS = -608464.116186033;
    int rUVIEi = -791838446;
    int JrpZskaW = 1702069560;
    double UTtSNpHepoT = -442135.3173505751;
    bool GIPSLQwUI = true;
    int SOpdpGgeivYEj = -1972354576;
    int emwwMGRTYxmIkr = 151753874;
    int GKstMf = 1615713204;
    string VKunfeY = string("uPhDmAZnctIiFKboHhkbgLGOTxYgXoZiMYBOfr");

    for (int PYhxMaAf = 1379282294; PYhxMaAf > 0; PYhxMaAf--) {
        GKstMf += rUVIEi;
    }

    if (VKunfeY < string("uPhDmAZnctIiFKboHhkbgLGOTxYgXoZiMYBOfr")) {
        for (int WLJAOVfWyHG = 1054491619; WLJAOVfWyHG > 0; WLJAOVfWyHG--) {
            BCrqse += BCrqse;
            GKstMf *= GKstMf;
        }
    }
}

bool NhPnnhLywnw::DSAOgZCamu()
{
    bool KOtXmlrNbFV = false;
    bool CvoSCmCKJnUAKkz = false;
    string AOsTKqSZ = string("WnZzCOhFrLBWtGeBGHPOkVXHRKjSZfBhsrlqogkVBZtDhveGCYowFVuEODVBkJsjHoJJGmGUMNKgJbFYKBmnbzchijHMtgzFzrXeEHXsLqdjYvetRPbWTbgXwofROKuKilWOMZaqIOrzNpbwkmoLHVubOoTGYUhxFQ");
    double IpcThM = 898929.58943406;
    bool fjcFZ = true;
    int dCpJw = 1567889732;
    string QMmEvgR = string("KjsARqphMvSLwYetevQlhQeSDXSXnVVdbPiMSypsWruUfeGyuhcpdWTyc");
    double NpFkIfQvjlPyAXN = 944702.0024557019;
    bool yIjfXKik = true;

    for (int AwygvdYCrAP = 89981507; AwygvdYCrAP > 0; AwygvdYCrAP--) {
        KOtXmlrNbFV = ! CvoSCmCKJnUAKkz;
        KOtXmlrNbFV = fjcFZ;
        QMmEvgR = QMmEvgR;
        KOtXmlrNbFV = yIjfXKik;
    }

    for (int HBkEzRjz = 451343788; HBkEzRjz > 0; HBkEzRjz--) {
        IpcThM -= IpcThM;
    }

    for (int iTkGwTWv = 98853100; iTkGwTWv > 0; iTkGwTWv--) {
        CvoSCmCKJnUAKkz = yIjfXKik;
        dCpJw *= dCpJw;
    }

    return yIjfXKik;
}

NhPnnhLywnw::NhPnnhLywnw()
{
    this->JPrdxgoPmWXshH(string("kZmXZWligNjLZfChSpTwUFznDjLukkoyejfcwmRLsdKGGvkFCqrdqHXETr"), 237671541, -1552418461, false, 1607826666);
    this->IgjsOHN(-129684.27152930945, string("TuMYyAkPxmIBBKdHQlPoSJyMrZNWJEwXnKnEoyVyPNnAqMFPqwHNGhjdHGiWWspLJXFIBtvaixncPcGgDsEAtkbsizzfhVJZfQqDnszvEUIcCwpyBRjtIYeHrjyQjWNAwgKKosjVbS"), string("TVAQFqQVtXtTHQIEXzEGiuVtuCxQXvvJqHIGYxkwthgvqazlIaC"));
    this->dRTIVHoap(422722.34289626696, true);
    this->AKmVunT(string("HUJlpaseGYwpqVuMVeANDFpCKtvAYLIxKNVSqeKtmUGCAcZkwRyqhEIStaNmdWAudyednVvKtnwhuQdeKepfRbfCMPtLKPoeKRcEgcluxOTGuhSvWtzQVkKrjLvMOPKBugGErOGvyYAgOLvbQzfsaxCFEBYvHPnhnPHMCcgfxdNSjcgythrakaeNWfSgNiotGatBEKBjwdBbcOUPFQGHmkZLFkZZvkkwysWvZbHuowWOrUliXed"), -1912166285);
    this->JEaoUTUmSE(-945096.9101834566, 846134.8522299912, -1838506377, -165601.84207930547, -764867.2820787587);
    this->yevnHuei(-1206983156, -207974.43703739112, string("hPLsKXlVcthtdpdVvxAaTliKhKhpnSvNGJPCQbMRfZfbzmlgbzokUtUBtnCfSvGUieDrAUMxCHwyMKxYOlTZEY"), true);
    this->KQeCsBYrTZLG(string("ClUVUcMIewmQPdrCHqgZgUjeVMAebNptLaLVRmtoOhudHSpomSeFRmvYEWbekCLnBPlMDDlkAocFzdKTiQndMKgjiXxXdbrMOqcPMVtsMLCQTONNdyMxazxagmJzMtflhnWgDgrpuLpjsWhYVYhiydGONajlqyAHUAQVznsbS"), 762083376, false, string("NEQThIWwbiOXINaVfZXfhmHtDNpcunfssnmkuGwzyAXNPBmUIDlpBUffFynGvjEShLKzLpObelnAdsXyeCixzCjyZVGpSusRWslQAYAqMZAKYmFdoRKajsQYARZCmvvCQnHeOLvrdXvGiRFvTXeKcOxPnvOXZrKmbbOrjKEwxPhmaUhoprfkPXBHhAyidYyHmdHmICNOliL"), string("czAACcDPEyVqPRYuyeHmgOEzPIotteBrsLCqLRAbiMDgaJlJbeXnAlJEFQBdicXEJsjykBhMYAHfzAMMwfcaNdJMPpGKNMKpeZHmpEjMGDrcBAleEuhaCKkJgMjpmIfRNdwPQKYGZGExvSeSklidIhlIiCRGyYjTyzuKkPeIgtgXkmrPQgFcmBmJfHyQzlYUSZNzZwBobjqzUMDeeVtDpfyPhGKY"));
    this->PTvplPx(1076131808, 325174.14352981065);
    this->YvLwdrRANBc(string("DuttppqmerukrPfDRUKfGoEZyJWGcIaVcIVcQWDHYyucQhYWcPjLKbzFUcLKJqPcwnfvdFamChjsGQgacodgoJaszXmWlqqxJcDMQYfAccqvjWaRzvnzADtoZStswFLDnvMEKbVrUPfILeVbSHUCguXxIbODysxzjeSCrbBDwIEDfFGiusBBwHgSPYQJlVMGrWBKbXzcfXUVdBHUVWTfcXpabXZIReljzamxqCfJlpKlbS"));
    this->ycGnAQbCidTjZdV(-792407.7593396559);
    this->DSAOgZCamu();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EiolpXRr
{
public:
    double fJuxpXOMxDt;

    EiolpXRr();
    bool eSRygzEaXprwPd(int htCzLjrhzThH, double NxYoXUCSrTUlf, bool wexGjCoyoi);
    void nAtJITyJikGBU(int Tckxj, int RdenRFdBIOiI, double pRjONzVjrwvFT, bool leDFg, string ykArSjMcNp);
    void snrjvKvELFm(int bpqwr, string czuwk);
protected:
    string dkzIWPjXsvFNp;
    bool QWAjoFpRrvMHSW;
    string wLSvWxjxR;

    string XXZXnicecF(bool kpZVXFyOmrRRQw, bool dhWUTQPMo, double MMEVb, int sqIAi);
    int qJUolxfBTslRzJwE(string lvHNhPkRTnoM);
    int koFYttgc(bool BGGKHPN, double bouUrmaOGvulRTg, string QZuLsCKxrSp, int XOypzpJlEI, int ZPGfsUgSudTn);
    int mIIcILMecCk(int ssJYUXqJG, string dFoOpKbdibHGNYW, double FjmlCCPdAfkNsppj);
    string qAFuepTDdrHDyZq(string vayAyAdsYdCV, bool vEEFDfcCcRePCDZu, int bDCCpPrVUwQe);
private:
    double RZTmPtMjRN;
    int kFTsgYnuziTbOd;

    double tczXu(int nzYKO);
    string tuYbUyor();
};

bool EiolpXRr::eSRygzEaXprwPd(int htCzLjrhzThH, double NxYoXUCSrTUlf, bool wexGjCoyoi)
{
    string whyWlkmIkJT = string("WalPdRrblTWSOkhJaUBVtlcCUsswyidAgNpqYcZyxogkyxdGIzUnifCIRneEbBvImsItzplRlgoVnnxilrVItnCEHOUdjOQOmmrArEzCaSSKjyfuHAHzQXmPjswQbafufuJroZWrgOWKaiCXeNDVZJFDPZnrZWFdKlyBywIyVQCFtALe");
    bool NpSwwBqYXkOOhW = false;

    for (int LyTQjMpXmcMyUKjm = 636793200; LyTQjMpXmcMyUKjm > 0; LyTQjMpXmcMyUKjm--) {
        wexGjCoyoi = NpSwwBqYXkOOhW;
        wexGjCoyoi = NpSwwBqYXkOOhW;
    }

    if (wexGjCoyoi == true) {
        for (int OAWqbb = 1176447208; OAWqbb > 0; OAWqbb--) {
            htCzLjrhzThH -= htCzLjrhzThH;
            whyWlkmIkJT += whyWlkmIkJT;
        }
    }

    for (int zMmsXOB = 1563929844; zMmsXOB > 0; zMmsXOB--) {
        NpSwwBqYXkOOhW = ! wexGjCoyoi;
        NpSwwBqYXkOOhW = wexGjCoyoi;
    }

    for (int azfvZpVwXrq = 1356963912; azfvZpVwXrq > 0; azfvZpVwXrq--) {
        continue;
    }

    for (int CdNkv = 931940786; CdNkv > 0; CdNkv--) {
        NxYoXUCSrTUlf /= NxYoXUCSrTUlf;
        whyWlkmIkJT = whyWlkmIkJT;
    }

    for (int EvuMVgaEzPLr = 156902277; EvuMVgaEzPLr > 0; EvuMVgaEzPLr--) {
        NxYoXUCSrTUlf -= NxYoXUCSrTUlf;
    }

    return NpSwwBqYXkOOhW;
}

void EiolpXRr::nAtJITyJikGBU(int Tckxj, int RdenRFdBIOiI, double pRjONzVjrwvFT, bool leDFg, string ykArSjMcNp)
{
    string JYYDZvm = string("C");
    int vZKPPdoQfCnGVc = -217619188;
    bool uLSrW = false;
    double cRsmCgXYPkbC = -1007804.0624569873;

    for (int zKrsBZUJxxnjbbl = 1580106391; zKrsBZUJxxnjbbl > 0; zKrsBZUJxxnjbbl--) {
        JYYDZvm = JYYDZvm;
        leDFg = ! uLSrW;
    }

    for (int LeFQKEecfttNEemX = 1615258037; LeFQKEecfttNEemX > 0; LeFQKEecfttNEemX--) {
        cRsmCgXYPkbC /= cRsmCgXYPkbC;
    }
}

void EiolpXRr::snrjvKvELFm(int bpqwr, string czuwk)
{
    double VAQboXpemUSfV = 731996.4797837686;

    for (int OHtBdvlTzKdm = 198430351; OHtBdvlTzKdm > 0; OHtBdvlTzKdm--) {
        czuwk += czuwk;
        bpqwr += bpqwr;
    }
}

string EiolpXRr::XXZXnicecF(bool kpZVXFyOmrRRQw, bool dhWUTQPMo, double MMEVb, int sqIAi)
{
    string dKIxCWNOWqphSq = string("SWmJsztxlAdjiRcngdQqbqlNKSithTlnCuZ");
    string XVrmMAutRh = string("QwklhuLkuoQVBHNgJMlHcVTlrmrPbxYKyXKCMNoXxrdfyyEJQVBBVNyiPstCGcJqaMIBYmkeGWGHYvcbegOAaRWYOGcRgXauLbNjEsTzDgDEHiCLNCVBNqQfSbaTjpaoZmSPjcZfHXsdK");
    double uTfdLxXARJDUAX = -368010.45999484323;
    double hCSBcQlVMycp = -358163.04069064226;
    bool eSGMSTbTDSUidD = false;
    bool qSSazbroKer = false;
    int YexfKnFKbBE = 1426406374;
    bool yMQprFyOeJKawoWR = false;
    string rbbspgOEYW = string("mGSUSsPQXpPhkMxyWeLganGSKnIpPMLwZadpaLkEYsUcsaYdhdGaqDysUZyDukixPDYqVldsSaMT");
    bool gcAETCWWceB = false;

    for (int eWYVRk = 969648513; eWYVRk > 0; eWYVRk--) {
        gcAETCWWceB = eSGMSTbTDSUidD;
        qSSazbroKer = eSGMSTbTDSUidD;
        MMEVb /= hCSBcQlVMycp;
        dhWUTQPMo = ! kpZVXFyOmrRRQw;
        XVrmMAutRh += dKIxCWNOWqphSq;
    }

    if (gcAETCWWceB == false) {
        for (int mpCJfMwpHJJFmW = 1607463479; mpCJfMwpHJJFmW > 0; mpCJfMwpHJJFmW--) {
            eSGMSTbTDSUidD = ! yMQprFyOeJKawoWR;
        }
    }

    for (int SZVrHhcF = 1873909566; SZVrHhcF > 0; SZVrHhcF--) {
        yMQprFyOeJKawoWR = ! kpZVXFyOmrRRQw;
    }

    for (int vEgMKCdbEBFry = 827590274; vEgMKCdbEBFry > 0; vEgMKCdbEBFry--) {
        continue;
    }

    return rbbspgOEYW;
}

int EiolpXRr::qJUolxfBTslRzJwE(string lvHNhPkRTnoM)
{
    double kGCJNoweVAvSX = -147395.8886124907;
    int VmCPFj = -1865635173;
    int zWJcYuNsabI = -1641860541;
    string tdyRhvtAQHKG = string("VvSWAkHzmALpXwfQMWCIDETnDmNTVggowwAxEXeVsqSQDqNPOMHeyaFlwUECmzsomCaPdwzZfkdangVUviJIIomfvDI");
    int pZabSwjMeDCM = 1837655775;
    string nJETaqeYUShoLv = string("AVvonTUJZJIHmhUbRWdfysOAvYNnPxbZdKAOqSUzpYLBSbcSvJaZGwWXLOvMnDEyTTIPBcQVLKsaUERQkzVP");
    int yXfIOhLgx = 904042651;
    string IrMeK = string("pTyynDQunxslLIxTPDTfapJBybxxqIXuvgTCSSdQhNwWTPCaNtvxeXbRcrIWqzLtyuoVayXNUJHHLglwtWOpsGgVShMxdDArZkKboXsEwfycDRvItXNZxBGqZoLfYq");
    double GrWqcWN = 720782.3693887253;
    string McChN = string("vEkgchiAddjHeCJlPiyWwgimbsYePgAMcEnpIJzkDtQHhKgjosNEXWwJpDu");

    return yXfIOhLgx;
}

int EiolpXRr::koFYttgc(bool BGGKHPN, double bouUrmaOGvulRTg, string QZuLsCKxrSp, int XOypzpJlEI, int ZPGfsUgSudTn)
{
    int ToaFbjDKhma = -650649005;
    double IBBDlR = 15961.851985431898;
    double crPjBcmvgOOkfp = -98790.30916301814;

    for (int AxMNupr = 1648546375; AxMNupr > 0; AxMNupr--) {
        IBBDlR /= crPjBcmvgOOkfp;
    }

    for (int QQgsVwzAovPmS = 1893668628; QQgsVwzAovPmS > 0; QQgsVwzAovPmS--) {
        crPjBcmvgOOkfp += crPjBcmvgOOkfp;
        ToaFbjDKhma -= ToaFbjDKhma;
    }

    if (ToaFbjDKhma >= -650649005) {
        for (int SeVEzVtbPgZI = 1644831104; SeVEzVtbPgZI > 0; SeVEzVtbPgZI--) {
            ZPGfsUgSudTn *= XOypzpJlEI;
        }
    }

    for (int hZOcHiWbA = 1783279349; hZOcHiWbA > 0; hZOcHiWbA--) {
        ToaFbjDKhma /= ZPGfsUgSudTn;
    }

    if (bouUrmaOGvulRTg >= -98790.30916301814) {
        for (int UYKmrds = 456028754; UYKmrds > 0; UYKmrds--) {
            continue;
        }
    }

    if (QZuLsCKxrSp < string("ltQqUzrIxeNelUwmvFPCpCxnRZuiphKTtKRjSzQASjOUevCMDLZQTNVreHclMZPDSsDlGKcyOZRiTKvhbiJTDNozcVtXmbZURDQibSLmyMMgXaGgRfFkMBOJzDjeBuRbZXZvTrwdtMpFoVgoIVRUrNQZuuveoecevdwWEiMOyVUoOmQgOELsHXXQMsJhmfFUPTmlfJGDlvrdjvkdJXkwZtiiEAStKpdUYiyaEDe")) {
        for (int mMjotDKBrqqDwIyG = 32951439; mMjotDKBrqqDwIyG > 0; mMjotDKBrqqDwIyG--) {
            XOypzpJlEI += ZPGfsUgSudTn;
        }
    }

    return ToaFbjDKhma;
}

int EiolpXRr::mIIcILMecCk(int ssJYUXqJG, string dFoOpKbdibHGNYW, double FjmlCCPdAfkNsppj)
{
    string cHaMaAuYEWwexNP = string("gRwFQdbqbBwaGqXiubYzhTPeslgLzHMyWxzfSOTUtnKvGlgMcgHvlKSDHybpAvMRqiPISzJJteZelshcprMwAnLpASkMcvqoquTSkVUxdYfNeEjKPqaclVMlYeJxFIZAaXaQbyIGlIScQQlobpDQfHLwvnEGUMPfQuLPgl");
    int YSmKnAICZiHHLL = 1083513031;
    string yIsGlVCQM = string("JYYrwSHifDRmTYsEhiMaLYxmTppCwaOMRAFoobpmOGykTQCgHjAiNxqIMGSBCJhSyjSxSndsmXzmleqOKPyyEWvhquSjGIJPBMhZCjziPqJtnQxPZIDGAH");
    int thfJDJosoetpu = -528569161;
    int DmXyEScJuWzUOhx = -528931238;
    int vBeMyrAJOC = -17961969;

    return vBeMyrAJOC;
}

string EiolpXRr::qAFuepTDdrHDyZq(string vayAyAdsYdCV, bool vEEFDfcCcRePCDZu, int bDCCpPrVUwQe)
{
    string JgVrXUiPX = string("yZDYXBMFHGPzNKMuVUTJYAHJLRkPiBSSsGgUYrWOPNNLeruxZxvfpSFFLLNmGAMOfUYigQmfVOCUoTYtdPQfFbmavCwOhwBuejjbRyqdMnWDJOgmHshCUBgetiUwCRHPZcIgtniDNAyjoxhaIHIOLrMtZIoMTIPOVZMoonqOCtrIUPjOjuOCMLonHvfVaEWLcawKdzHiNVxFTaVLDoukkMQEmEeKvYRqIftoRwMwsskZEaM");
    string lnhyk = string("qKhLUaFYggrWScMeSABhkjhftwIQXjbEcobXsBuugfXKBSNNnRBuMbAkor");
    string SqzFd = string("bBchkyeiGdgawCguSclEpFrzSuPgkLAtcuracbrgVXhjBigvqtqFEYWFCFveuVegaypJuhYJldEbLBQUtrCzJnfNNacnvw");
    string mLcRvLe = string("zeTCsLYJbkMxgDuLVrBXaVzujQLmArKMouPmIKvKbAXtWZNwtiEpEoNdIymHlOKmHDnGJjEguLLGpCcEDJANERMKrSqcXYrIlgTREPidljUvOjxjEaCHpXuarXHmpJlpFTzQKLQuhz");
    int prYQDKjs = -30542736;

    for (int alZmLlNcuOCl = 506490025; alZmLlNcuOCl > 0; alZmLlNcuOCl--) {
        lnhyk = mLcRvLe;
        JgVrXUiPX = SqzFd;
        SqzFd = mLcRvLe;
    }

    return mLcRvLe;
}

double EiolpXRr::tczXu(int nzYKO)
{
    double WeVDoA = 921155.9761125996;
    int WXcFFbcLI = -596884188;
    string RBwYzlSTZ = string("UWnryLLUtIdSMShniVMFvXDGDmoMoHvqzkbxpSSYkloCNhHvsAhfzQVkHfhumiCpjSizPJwidHGLQVsCWLtJUZuyXADOoJuTpZeIugFeqtPiKVPRzD");
    double EiTkUdI = 538407.2043454369;
    bool FEBjIxiBX = true;
    bool vNZWwpCnbPoeU = false;
    string THthq = string("oOxpqpsDiSSDxcCjEbPswjtyACIfVIKXAJEHONdfTPZRRdNaLqrrZNGHWdLpoFDKbRMdnjrFcRtGKwnTpHZfQDrXwlSSxkWnCGpPRMkWdbXZXVDrdfMFhMcGXWIIAEvGFTGpxkJrFxzsYBzbifMFIVXnVzMKgcihyPvNAHkObXUizlCtbGHEQetAgzbBFqzRQnlwadNzw");

    if (EiTkUdI > 538407.2043454369) {
        for (int RSfCcTwhAHL = 1781733744; RSfCcTwhAHL > 0; RSfCcTwhAHL--) {
            WeVDoA += WeVDoA;
            THthq += THthq;
            FEBjIxiBX = vNZWwpCnbPoeU;
        }
    }

    for (int URSYdZqsW = 1502298774; URSYdZqsW > 0; URSYdZqsW--) {
        vNZWwpCnbPoeU = ! vNZWwpCnbPoeU;
    }

    for (int oxlkaG = 880127704; oxlkaG > 0; oxlkaG--) {
        continue;
    }

    for (int rBDlDggcWdldZ = 1293365872; rBDlDggcWdldZ > 0; rBDlDggcWdldZ--) {
        RBwYzlSTZ = THthq;
        WeVDoA = WeVDoA;
    }

    for (int EbwbPTW = 958544057; EbwbPTW > 0; EbwbPTW--) {
        EiTkUdI *= EiTkUdI;
        vNZWwpCnbPoeU = ! vNZWwpCnbPoeU;
        vNZWwpCnbPoeU = ! FEBjIxiBX;
        vNZWwpCnbPoeU = vNZWwpCnbPoeU;
    }

    return EiTkUdI;
}

string EiolpXRr::tuYbUyor()
{
    double KAEYibyzqas = 113816.77009488056;
    int mXJylsVfbiHq = 754369030;
    int QPQsdRniQgM = 2042725142;
    bool agdYlK = false;
    string ARQBRlZ = string("tJDRNdxUatpAXGPxxCAuiQvXMuaZxlWuXKVYngZpooNlODfcLMtpibwVsQuVrvBdwuhsWisLOQtedWPYHqovbLjjcdBWlBdHUcaivdDVjSzFgnrKbyniBBzrDQxlEbvjaAybCZtwYmNzHRnhzrVoLYsyeLMgTQHbHHJjUZAVeZHFqsTqHqBbWLOKqwsTcKweJegxOWiMlPtJOAXLfaEcqtQcc");

    return ARQBRlZ;
}

EiolpXRr::EiolpXRr()
{
    this->eSRygzEaXprwPd(-1878902305, 91313.71342095768, true);
    this->nAtJITyJikGBU(-1898125193, -2088700055, 945912.1946518942, false, string("shirsSVATTlvtNiRwHzrT"));
    this->snrjvKvELFm(2136098227, string("VrCLZJg"));
    this->XXZXnicecF(false, true, 33687.47331234288, -2047559646);
    this->qJUolxfBTslRzJwE(string("yyHxFFozQWPZVLfRuSZwOnqCcOAmErMpILVeHvFPytuAxnNxzcBkxaPCLuZSFHkoYhcrXAZnkhUkZrILEVZJQveRreFIwMloIPBoaHDXTWwolSwiyQRgXcWTOhHSKCIrWpjxIcQraTIvXYmRMTJYEUtnmFyJfnlRBMJubMqPUbosNd"));
    this->koFYttgc(true, 785244.9980969137, string("ltQqUzrIxeNelUwmvFPCpCxnRZuiphKTtKRjSzQASjOUevCMDLZQTNVreHclMZPDSsDlGKcyOZRiTKvhbiJTDNozcVtXmbZURDQibSLmyMMgXaGgRfFkMBOJzDjeBuRbZXZvTrwdtMpFoVgoIVRUrNQZuuveoecevdwWEiMOyVUoOmQgOELsHXXQMsJhmfFUPTmlfJGDlvrdjvkdJXkwZtiiEAStKpdUYiyaEDe"), -1782915573, -223587548);
    this->mIIcILMecCk(2005100292, string("liRKeDgBWysIrFfzGetIUyoPKQuH"), 61118.5127781255);
    this->qAFuepTDdrHDyZq(string("VjevQmxSjTKGeaPpFxFNHbLIWvbOYMhDWeyJpsuIHnGgDMMnKdPpsSoflepuCHeSNznqXqmeSvrTPUDqrsPxsUBbKUhIzTUbPCZneoccDAIYEIGLowwVXCwzKexYYIffDSDqRRzPPvLIMqZvZJTeGxmyDCaZuCTpqAjtdaWUdmIFTztmPUKyBzHDaHVAb"), false, -84112624);
    this->tczXu(702593053);
    this->tuYbUyor();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AvkVH
{
public:
    double Xowha;
    double hDCSSmsAgdecp;
    bool HySkIvTVVIODWQd;
    double vVnziTT;
    string LllRrGgpLsN;

    AvkVH();
    void EtNAyiFSr();
    string zeKvDSw(double wZnRcGQIb, double scZARBSIaLumAju, int tVByShJ);
protected:
    bool CUfXZ;
    string ImzPeblwrjBeyqu;
    int UvhJWktUTkErcuwH;
    bool ehXGqIbRONIj;
    bool LNocy;

    bool pNDisbYssbHAhtO();
    int JwNOCLjWmy(string YAciJj);
private:
    bool BpGodRtQr;
    string AklCLhrOdrnBMeq;

    bool SQmcvsMlO(string OqtzGLbigyJT, double juvvRkniTCMpAZMR, double LGUhIxCdFV, double fuJetHiSrejcLNY);
    int XvaxsaklfMkNQ(string JvPDLFV, int zStgtaBsTfct);
    void VBDWwLZVWE();
    int ZCdoFWT(bool BCGIbePoVGxAy, string vdlUxmb);
    int rbglZPAsLVge(int HTQIwgGDbcHJDUL);
};

void AvkVH::EtNAyiFSr()
{
    string ICyZMfpRl = string("fmaxiCxFygUBUABngiFPrElIHqeOCBJlQqLfIVkoAQXnWnngYTDduhXOcmiaTqmHYGqLIrmoJwOmNiZKEvSMqXbuJlPXAzjAXftaJMGozYWOrsVxdSmBbhsWdzXDWCfNQfbIgneilyczMMtalHfhqTArqDcfijOrGHbxWhUkyyWeWXZJQaaOJNNwmVYoJgEvDHdYVHaEjyuchYLgrIRvlLGkORQBbbLmhUPuujRjWhlrtHlHfqomA");
    bool TeNwmRmGHhBfdlw = false;
    double eLFqRCXuMIidmmi = 912692.714802479;
    bool rESyE = false;

    if (rESyE == false) {
        for (int JOeTzS = 232324172; JOeTzS > 0; JOeTzS--) {
            TeNwmRmGHhBfdlw = rESyE;
            TeNwmRmGHhBfdlw = ! rESyE;
        }
    }

    for (int LtyTgdNzltzPEw = 2102642229; LtyTgdNzltzPEw > 0; LtyTgdNzltzPEw--) {
        continue;
    }

    for (int dbeKSnDUv = 1024827581; dbeKSnDUv > 0; dbeKSnDUv--) {
        TeNwmRmGHhBfdlw = ! TeNwmRmGHhBfdlw;
        rESyE = rESyE;
    }
}

string AvkVH::zeKvDSw(double wZnRcGQIb, double scZARBSIaLumAju, int tVByShJ)
{
    double AIuAtcDDDRCVIG = -1038459.2996922268;
    double cwRPznFCHqkQzjDR = -634156.2304186827;
    int WiUVivQxyxx = 1442105774;
    int XStCivPOzoaIIN = 635494355;
    double KzSxJcxsNawWmR = 125930.28516150247;

    if (cwRPznFCHqkQzjDR < 125930.28516150247) {
        for (int TdtQUJI = 2125266092; TdtQUJI > 0; TdtQUJI--) {
            wZnRcGQIb += AIuAtcDDDRCVIG;
            tVByShJ += tVByShJ;
            KzSxJcxsNawWmR += wZnRcGQIb;
            tVByShJ /= XStCivPOzoaIIN;
            wZnRcGQIb *= wZnRcGQIb;
            cwRPznFCHqkQzjDR *= wZnRcGQIb;
        }
    }

    if (XStCivPOzoaIIN == 1442105774) {
        for (int ZdeWsJwKitNma = 649322340; ZdeWsJwKitNma > 0; ZdeWsJwKitNma--) {
            tVByShJ /= WiUVivQxyxx;
            scZARBSIaLumAju /= AIuAtcDDDRCVIG;
        }
    }

    return string("vSBfiKXUyJCKABGJoTemfkOVZKWNBmzoTyRJ");
}

bool AvkVH::pNDisbYssbHAhtO()
{
    double YmMRbx = 966210.2993439407;

    if (YmMRbx < 966210.2993439407) {
        for (int ghlVrWRgGaGNj = 1623271731; ghlVrWRgGaGNj > 0; ghlVrWRgGaGNj--) {
            YmMRbx = YmMRbx;
            YmMRbx = YmMRbx;
        }
    }

    return true;
}

int AvkVH::JwNOCLjWmy(string YAciJj)
{
    int UTRCkzNws = -924656378;
    string kfDnvEB = string("bjbrLAAyLcPZozIJLIpnDYDrEpOvpzTLPmrnTBSmlHqTdiENzdWLUQKyjrNWWCViFnXYRHRHLrqRHgGyikqlnGcgxTdqOuhnbQhdozzIWKFiGwrChkLovyFPLtyDvbrXYRDZCyKenKuECWCghjIawVcnCLfXPfpAMwVJgCZSqaBDZnrghLKveoJihHKMmtKpHAPvmtaZQoCteSecvJrDsNIGIMuJQJRWuGJIuAOxM");
    double hLWLhCclBfeg = -537949.1323229842;

    return UTRCkzNws;
}

bool AvkVH::SQmcvsMlO(string OqtzGLbigyJT, double juvvRkniTCMpAZMR, double LGUhIxCdFV, double fuJetHiSrejcLNY)
{
    double LDpkygwtNycMBElI = 670387.2838993712;
    string vFAiJcqCl = string("XQfpYOBbNUzqqadUJbzxOYmKWTenUKMHDEFWJCcjsSPowXALEhAgRsaFZlQVhkIcoQWndMTpiVNlkUAOUmUtHBfQZOihhvCuYBPPeHOTdvLGLDucYGCkDNbIrjbLJnxWNtKTuFbGRayBMRAoVluemJzCHqMQWKbXAdBEPcbBekNBbzKbeGTjhvNCODCu");
    string XkNGjrZOYRy = string("owEoOHkTncTY");
    double GOKAxHMgGMMKTgu = 397000.67069328146;
    string mkxpgWeiiJWiz = string("FEgxfPYUYLWPAlCMhRdZRQbsqVlhFEGkgKeKRHbNARqEdOIytwTxmApCAXVDCvdmISfsxYisdWqAXsSZxTKpeCuaZMaJNWnDmLQzlxyRVOdnrkhIfWYhSdXyUxJJwpkvuaMXmROgZahfjgtLrMgoBPwqRuluDlzxRzjMzdBwRBTRoEajnifgAvKCYlMhnXMsPCgErCwuyStqTLEKmjHG");
    string fADNgAWFStojE = string("miUDblMqYThHqQUULlJwtIXEwzamWWHchOTYZihfOwnPRUgcMYpwaCzNUenfbhTKPNBkuAOwLOJUnNdtapXZrLoKUcTSbMqPHwlHIjdtVpBHlrCMYOARoOoFtzpmOVLaBVmfYIXgJiONdKbHZyQuMBWTgLjhoCsSyPxrocSiKymKRxmnPMGlpXxNVviEkZROpjvfuSnFDTpjlaWJlVduLuYIBKKJmFjrMmZkfpZzgBhuPpmxuGyFCYRlhK");
    double ZQFcKLXNwcXscKcH = 125905.55327061251;
    int YIgnhbMp = -1526795097;
    bool qcXeznefAmy = false;
    string tNRMMeexqCU = string("OVjGvVJFlazNLveUlmjmRBBGaeImsEFkkzjkYTciDpyiSCFQVRfhlSzzWDOjqrLkHCer");

    for (int qhaIZNNTsUbVVPCu = 1705821117; qhaIZNNTsUbVVPCu > 0; qhaIZNNTsUbVVPCu--) {
        vFAiJcqCl += tNRMMeexqCU;
        fuJetHiSrejcLNY *= LDpkygwtNycMBElI;
        tNRMMeexqCU = OqtzGLbigyJT;
    }

    if (tNRMMeexqCU == string("XQfpYOBbNUzqqadUJbzxOYmKWTenUKMHDEFWJCcjsSPowXALEhAgRsaFZlQVhkIcoQWndMTpiVNlkUAOUmUtHBfQZOihhvCuYBPPeHOTdvLGLDucYGCkDNbIrjbLJnxWNtKTuFbGRayBMRAoVluemJzCHqMQWKbXAdBEPcbBekNBbzKbeGTjhvNCODCu")) {
        for (int BeyFqHFHOnfdQ = 814143314; BeyFqHFHOnfdQ > 0; BeyFqHFHOnfdQ--) {
            OqtzGLbigyJT = XkNGjrZOYRy;
            LDpkygwtNycMBElI /= juvvRkniTCMpAZMR;
            LDpkygwtNycMBElI -= ZQFcKLXNwcXscKcH;
        }
    }

    for (int SaATTilI = 1110278011; SaATTilI > 0; SaATTilI--) {
        YIgnhbMp *= YIgnhbMp;
    }

    if (qcXeznefAmy != false) {
        for (int mkAsqeqhKoiE = 1841232979; mkAsqeqhKoiE > 0; mkAsqeqhKoiE--) {
            continue;
        }
    }

    if (ZQFcKLXNwcXscKcH == 125905.55327061251) {
        for (int MdczmphSNum = 1225828926; MdczmphSNum > 0; MdczmphSNum--) {
            tNRMMeexqCU += OqtzGLbigyJT;
        }
    }

    return qcXeznefAmy;
}

int AvkVH::XvaxsaklfMkNQ(string JvPDLFV, int zStgtaBsTfct)
{
    string ULfhZPZEU = string("pbzYgZoXqSxRMODxBHhjHGMtcOFTEwxUHkMQXJEcskcUigVMngypwaZunxeKlOGErNUYWjFsTwQZzcPNNzJijORtPZsfWWJNWyGOtVvzvFpVizcTXdYqBXBsyihfLGYWxEixYoINQOaUdAApUvhReldyMIwAxejnUGDCQpUOTcbacGp");

    for (int YGjrKZXu = 1057559853; YGjrKZXu > 0; YGjrKZXu--) {
        zStgtaBsTfct -= zStgtaBsTfct;
        ULfhZPZEU += JvPDLFV;
        ULfhZPZEU = JvPDLFV;
        zStgtaBsTfct = zStgtaBsTfct;
    }

    for (int qnVmpgSaBlcvc = 54050155; qnVmpgSaBlcvc > 0; qnVmpgSaBlcvc--) {
        zStgtaBsTfct -= zStgtaBsTfct;
    }

    for (int dhoaIv = 409499636; dhoaIv > 0; dhoaIv--) {
        JvPDLFV += JvPDLFV;
        JvPDLFV += ULfhZPZEU;
        ULfhZPZEU += JvPDLFV;
        zStgtaBsTfct -= zStgtaBsTfct;
        zStgtaBsTfct += zStgtaBsTfct;
        JvPDLFV = JvPDLFV;
        ULfhZPZEU += ULfhZPZEU;
    }

    return zStgtaBsTfct;
}

void AvkVH::VBDWwLZVWE()
{
    int pLemwWe = 1072952147;
    double DZyCKuOphTOs = 527366.9611145981;
    string lOrEy = string("zncgwIjwWYWPBoELPcvQjRmotmdKjJAvUBJVUznCVQzDermBAPUloUturSjDPAzMMEVAtXLPGkEWSNQvIHVTCojQhZNhGmNwDmwNuhrMUSwgqRhnjdUsZofZqI");
    double vyvDpuLezW = 799284.95573763;
    double kASqBNHUyxY = -870062.556739013;
    string zpRvGdFpM = string("sUBOpuuHScisvaiILLflBklOQYVrCjaioGOHnNTiQOgsnFcZbgmbhimZMncoVvwZqGiEENqjRMuTaDseeqzDqHgPKwqwAiZjnBTgqbUeCweLIByMRfLgnYgrINSdseTdGlefEGmbBhvdnVEHVAJGNeyCiVuvxJvZpuGYUsIGwEbJJebYarTLrAxhNXnJVsQdaWHCpRstfyMaynSBZJIFmShNdnrty");
    string hyjqb = string("JYvafFWCfjYOhbojfHqkFycKEUPXXCNqsCnDyjZpLtnJtTZQyuCJqxVhzVEBkDFIiBMfxWTHAUuTpedZfRiAJNYVGnlGtKZmOkFpqHFiqbfwdmZUQELHeNqfYPrvKoPBxqAiSnxuTIUMETvLxAvnRdrZTgGThGrYAzOwkMRpKbJlClmVeECOYeWFKkLJqLlwyLBjcECkFWiKWzmiDfuZofXRHVtMshfwfFuAHUvRwsRJuXdYDj");

    if (lOrEy > string("zncgwIjwWYWPBoELPcvQjRmotmdKjJAvUBJVUznCVQzDermBAPUloUturSjDPAzMMEVAtXLPGkEWSNQvIHVTCojQhZNhGmNwDmwNuhrMUSwgqRhnjdUsZofZqI")) {
        for (int brKweXOlhZs = 1215483383; brKweXOlhZs > 0; brKweXOlhZs--) {
            DZyCKuOphTOs *= kASqBNHUyxY;
            DZyCKuOphTOs /= vyvDpuLezW;
        }
    }

    if (zpRvGdFpM <= string("sUBOpuuHScisvaiILLflBklOQYVrCjaioGOHnNTiQOgsnFcZbgmbhimZMncoVvwZqGiEENqjRMuTaDseeqzDqHgPKwqwAiZjnBTgqbUeCweLIByMRfLgnYgrINSdseTdGlefEGmbBhvdnVEHVAJGNeyCiVuvxJvZpuGYUsIGwEbJJebYarTLrAxhNXnJVsQdaWHCpRstfyMaynSBZJIFmShNdnrty")) {
        for (int oqrZklPY = 1969987966; oqrZklPY > 0; oqrZklPY--) {
            hyjqb = lOrEy;
        }
    }

    if (vyvDpuLezW >= 527366.9611145981) {
        for (int RZCxvXC = 950729260; RZCxvXC > 0; RZCxvXC--) {
            vyvDpuLezW = vyvDpuLezW;
        }
    }

    for (int YEBomNZG = 216187843; YEBomNZG > 0; YEBomNZG--) {
        hyjqb = lOrEy;
        vyvDpuLezW /= vyvDpuLezW;
        vyvDpuLezW -= vyvDpuLezW;
        vyvDpuLezW *= DZyCKuOphTOs;
    }
}

int AvkVH::ZCdoFWT(bool BCGIbePoVGxAy, string vdlUxmb)
{
    double uaPQVG = 186350.07305974278;
    double nQNOyAnFLOnVsmU = 271040.8498361707;
    bool pOlnOkKoQoADc = true;
    bool ikOQkTaI = false;
    double uZPsJZBqZNK = -682092.1275506071;
    double zLnwPUGYg = -342207.4183785395;

    if (uaPQVG == -342207.4183785395) {
        for (int DZBVGMGfws = 829385607; DZBVGMGfws > 0; DZBVGMGfws--) {
            continue;
        }
    }

    for (int owsWKkLqXqcUtU = 1406629642; owsWKkLqXqcUtU > 0; owsWKkLqXqcUtU--) {
        pOlnOkKoQoADc = ikOQkTaI;
        uaPQVG *= uZPsJZBqZNK;
        BCGIbePoVGxAy = ! pOlnOkKoQoADc;
        pOlnOkKoQoADc = BCGIbePoVGxAy;
        uZPsJZBqZNK /= zLnwPUGYg;
    }

    if (ikOQkTaI != false) {
        for (int DVhcbKPIaifmcoI = 647946052; DVhcbKPIaifmcoI > 0; DVhcbKPIaifmcoI--) {
            uaPQVG = uZPsJZBqZNK;
        }
    }

    for (int osqPPoaxutMNqNjC = 286690307; osqPPoaxutMNqNjC > 0; osqPPoaxutMNqNjC--) {
        ikOQkTaI = ! pOlnOkKoQoADc;
        uaPQVG *= uaPQVG;
    }

    return 1299351571;
}

int AvkVH::rbglZPAsLVge(int HTQIwgGDbcHJDUL)
{
    bool hGtjBVqHTxqsVFHq = false;
    double hmYfIogL = -703078.6059619205;

    if (hGtjBVqHTxqsVFHq == false) {
        for (int yNyjgPS = 1497097300; yNyjgPS > 0; yNyjgPS--) {
            continue;
        }
    }

    if (HTQIwgGDbcHJDUL <= -681971241) {
        for (int MnfPs = 531174741; MnfPs > 0; MnfPs--) {
            hmYfIogL /= hmYfIogL;
            HTQIwgGDbcHJDUL -= HTQIwgGDbcHJDUL;
        }
    }

    if (hmYfIogL >= -703078.6059619205) {
        for (int qBGEUpAkCfeKupL = 1434841275; qBGEUpAkCfeKupL > 0; qBGEUpAkCfeKupL--) {
            hGtjBVqHTxqsVFHq = hGtjBVqHTxqsVFHq;
            hGtjBVqHTxqsVFHq = ! hGtjBVqHTxqsVFHq;
        }
    }

    for (int ACDGqAVFuvCc = 1271327562; ACDGqAVFuvCc > 0; ACDGqAVFuvCc--) {
        HTQIwgGDbcHJDUL = HTQIwgGDbcHJDUL;
    }

    for (int pridR = 370508581; pridR > 0; pridR--) {
        HTQIwgGDbcHJDUL = HTQIwgGDbcHJDUL;
        HTQIwgGDbcHJDUL -= HTQIwgGDbcHJDUL;
        hGtjBVqHTxqsVFHq = ! hGtjBVqHTxqsVFHq;
        hGtjBVqHTxqsVFHq = hGtjBVqHTxqsVFHq;
    }

    for (int APwDUHNg = 234064424; APwDUHNg > 0; APwDUHNg--) {
        hGtjBVqHTxqsVFHq = ! hGtjBVqHTxqsVFHq;
        hGtjBVqHTxqsVFHq = ! hGtjBVqHTxqsVFHq;
    }

    for (int pFdhKGm = 75600392; pFdhKGm > 0; pFdhKGm--) {
        hGtjBVqHTxqsVFHq = ! hGtjBVqHTxqsVFHq;
    }

    return HTQIwgGDbcHJDUL;
}

AvkVH::AvkVH()
{
    this->EtNAyiFSr();
    this->zeKvDSw(-276535.84102465713, -26229.299641643764, 232384021);
    this->pNDisbYssbHAhtO();
    this->JwNOCLjWmy(string("ROSUpeRxEOgGLHyOZukjbmDswEQDLBPwKNafZlIAOMfHRsvatfpsVWcxRnZcLQEqJlHrjIi"));
    this->SQmcvsMlO(string("CVlsqYJvYJFnfLlGcAXccjqbWLjdKsZQJn"), 60647.876823728926, 410664.3845061542, 203486.32100576238);
    this->XvaxsaklfMkNQ(string("oFNWdpUyERwYSkVOsaPRnfctGEQzUHqnBdjrAwyGgIsrIXzZLwJVPKFBpohfqYUMJmIhLGnYYvRgCSPiSwUHQeiYsrgXgGPzSasa"), -66900717);
    this->VBDWwLZVWE();
    this->ZCdoFWT(false, string("RKEbHfYimhzQBDjLJeNsWyNyoiSoCERQMPUBARPenQhNg"));
    this->rbglZPAsLVge(-681971241);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WPHyTXCovwcs
{
public:
    string lQnJdhybLrTkRTad;
    int DnkthYnDwUE;
    int Feuby;
    double votkHxZGEW;

    WPHyTXCovwcs();
    string ndjGgGeYNUFQpEK(double hYTARdzM, bool nknlMeDC, bool JrXfJcB, double maWCSH, int NIzArrDCedPeOhb);
    string USXdnf(int VWLmZ);
    int FdRpkLiw(string iLyvuDzRPGkUIlWe);
    bool OuMeZMPWugoiEso(double LfJhnOWjadkbZhqg, int vcigoDSVyUIPFi, string avsvaaHYFIj);
    int LkcKNwtawTcRE(int KjjxxEUSJDcD, double AZRVluiXY, int whngO, string aGCpYTbNp);
    bool uLLnvXsJKWVln(int aONAqqfIuixgYpa, double BCBFkvKP, bool ufBSBLSIjWIzKLM);
protected:
    bool uEzPXMZTnuNR;
    int IGFsgergbP;
    int HGvrwfh;

    double wsGSimumEkhY(string aKElPh, int aWlMYUOkNrPcVaVv, double SbDyTbuawMU);
    bool gYErPTcglzkm(int pMNNrmag, double XMKinY, double PhBjgXUIksVJBPG, double mMChsZZonZ);
    void aGRRzFvlGEv(bool wcgBCFtGuEKnAz, int HipHuZhEataCf, int tvfZAa);
    int Ajqbur(double tfVHwqWQNJ);
    double PhjaEDm(bool oCSkHEymtdUmS, bool dGpMJvYabLZmBG, bool LbpMPofMitCor, bool UvMYZLzKbcmvod, double xmcFz);
    int yMMvJDQilGhj(string NYKffwSMfOUPwXF, double zaIiDuZMb, string DESsrwJQh);
    void QGlqkiegaEu(string znAtSnVxVeqXI, double GRtzq);
    void cpmEbTSAKvJtCZqA(int SRMiUnyfiRNffUIA, string NcWbndMeLKbPnVY, double tSONShdg, string LIEYUE);
private:
    double naFhqdkgmogR;
    string rmHPUj;
    bool ZpnCFnYmLRFP;

    int eKFnVGlbEU(bool YijcuXtQUUgvYU, double OzGLuXKmzNSblk, bool gmtsYvlBbbdIAk, int JOBfaCZ);
    void ziYimvJwH();
    int jKzBT(double eGtnoCNleDiqdMio, double IrpdaQnOqqpRfkl, bool DtcpGMz);
    string EISQbY(int GAzMqUqlq, bool DvxPILeVoQqWQKw, bool mzFhRDdIo);
    string FWYFRRTLzx();
};

string WPHyTXCovwcs::ndjGgGeYNUFQpEK(double hYTARdzM, bool nknlMeDC, bool JrXfJcB, double maWCSH, int NIzArrDCedPeOhb)
{
    double CMjFaNsCUFM = -430650.9405460453;
    int jaYqWvZjfKmjirF = 1235160020;
    int waaseGGfIZ = -2073683492;
    bool LcDtgOfgmBCo = true;
    string PPKbEEoTSyDoSUIa = string("qbAKJrMVgLeGpeaZKRXzeUwJAkrDfYLHyqXBXzUUYphFCWXgKijJNwsfZcRLiMrmiOYimrKMWKoCREhcrEJXizJwUbSpDnGfZEdNHhnmrYdgtMKSuqckTgQVULnNjTvXvWGQVsfcbNYstZB");

    for (int azSHDUfulFlZo = 1724309820; azSHDUfulFlZo > 0; azSHDUfulFlZo--) {
        LcDtgOfgmBCo = JrXfJcB;
    }

    return PPKbEEoTSyDoSUIa;
}

string WPHyTXCovwcs::USXdnf(int VWLmZ)
{
    bool dSmIVfiWRCoCxU = false;
    double ZEJtsHSfkmJ = 896601.3025935926;
    bool OfqdCRxteb = true;
    bool UsocKfifN = false;
    string YXBUskQHYtSMUM = string("zPiEyIchBOdhtyVrZunkDBqrdMmQSjfrVSQBezRKYmwoUIqkOgeOqoJMGuQqdDZReQfJoEqFexzPSgGxRiVjsqAjFQUtxArVmqZFEbyD");
    double PnuqCClCApmja = 658460.3652584873;
    double HDRAeRS = 35939.77429594708;
    string oEGKYsGJZBXaVeC = string("YTwEmwNJibMmnZSDxLZecUkmHsrTqahxrpxVrNPStWWdzQY");
    string vFrKrYg = string("cjHpXXuHemMoNVEZSnOMxXjgVuMxvNGfcdJBGcgkeznGiFpeVvsRXnTXcZmJxYSAZnThCLCzQRPhWvHWDNxWGoqcqivkiwGxONtsncUJOpOjtXFPWCEzMzBoYukJqtvHdEhjWoSUEtgYpZWHnKiLBvEiZWEMiIyqxpDmJukn");
    string tLPErDYEDuGIw = string("iTfxykSBqzIUGkUAoiqSvLLtcvpwTYTXUpgslllrsYufzbLUCRYdgOVyGDgANDxMaCyxyhKUFjqyFvSXHeVhHHdDquzTllexZkHSRiZlPTxEXSQolYJHTGFDzAKblLHqNKXstxuGeBhPNSiwvrXDEZkMAbmORYoVXReqCNJrQCUkUApdnLmjdhVVIrdsFFjntpQCDTTClBswfvgMLxIKet");

    if (YXBUskQHYtSMUM <= string("zPiEyIchBOdhtyVrZunkDBqrdMmQSjfrVSQBezRKYmwoUIqkOgeOqoJMGuQqdDZReQfJoEqFexzPSgGxRiVjsqAjFQUtxArVmqZFEbyD")) {
        for (int JucuOZBYgvWvPW = 2034827948; JucuOZBYgvWvPW > 0; JucuOZBYgvWvPW--) {
            PnuqCClCApmja -= HDRAeRS;
        }
    }

    return tLPErDYEDuGIw;
}

int WPHyTXCovwcs::FdRpkLiw(string iLyvuDzRPGkUIlWe)
{
    int zsGfXIwWboWstWAf = -1284749354;
    string oTLeyFZP = string("PYYOHdSSJFeNkXpVdjwgJCWJWjRsoEAQmCVyqglTzxLKiotHZONCCjGoihAQkfBpHLRtvcpHcOzQHqUOZdOXmGRvdoTueRRiLKOzCWOtJZikmHQtpykZAUHYzHZIEbspXZHyZLSRFeQQvJgTjJkCpwQZMoYAnITGajHhNOUHNh");
    double uqCwHOeUAygZ = -127261.74077077578;
    double FcgMIVPgMpaaI = 993091.8338234465;

    return zsGfXIwWboWstWAf;
}

bool WPHyTXCovwcs::OuMeZMPWugoiEso(double LfJhnOWjadkbZhqg, int vcigoDSVyUIPFi, string avsvaaHYFIj)
{
    bool zpVwrB = false;

    for (int QfJdx = 1057682749; QfJdx > 0; QfJdx--) {
        continue;
    }

    return zpVwrB;
}

int WPHyTXCovwcs::LkcKNwtawTcRE(int KjjxxEUSJDcD, double AZRVluiXY, int whngO, string aGCpYTbNp)
{
    double PGKvYBNUKlFIKn = 297055.7014345813;
    bool rIYiVxMJIC = false;
    double blOCqd = 895207.0226815221;
    int obIPgFrjsSQnt = -1886084286;

    if (AZRVluiXY < 297055.7014345813) {
        for (int eqKfYywGzqbrRQ = 1818576786; eqKfYywGzqbrRQ > 0; eqKfYywGzqbrRQ--) {
            whngO += whngO;
            PGKvYBNUKlFIKn = AZRVluiXY;
        }
    }

    for (int PowUJctXaJGM = 1664814932; PowUJctXaJGM > 0; PowUJctXaJGM--) {
        obIPgFrjsSQnt /= obIPgFrjsSQnt;
        AZRVluiXY = AZRVluiXY;
        rIYiVxMJIC = rIYiVxMJIC;
    }

    if (AZRVluiXY < -732986.1286520974) {
        for (int VZzCLplKYtc = 1559859735; VZzCLplKYtc > 0; VZzCLplKYtc--) {
            aGCpYTbNp = aGCpYTbNp;
        }
    }

    for (int IXeDmxbLqUaQKVRc = 349410948; IXeDmxbLqUaQKVRc > 0; IXeDmxbLqUaQKVRc--) {
        obIPgFrjsSQnt *= KjjxxEUSJDcD;
        whngO -= whngO;
        obIPgFrjsSQnt /= obIPgFrjsSQnt;
        AZRVluiXY /= AZRVluiXY;
    }

    for (int dsjIS = 618873673; dsjIS > 0; dsjIS--) {
        continue;
    }

    return obIPgFrjsSQnt;
}

bool WPHyTXCovwcs::uLLnvXsJKWVln(int aONAqqfIuixgYpa, double BCBFkvKP, bool ufBSBLSIjWIzKLM)
{
    double oZcFURLjwA = -834340.0334910975;
    double uQaysgVpAy = -779849.2048817748;

    if (oZcFURLjwA <= -834340.0334910975) {
        for (int ndLlqjbguO = 993829282; ndLlqjbguO > 0; ndLlqjbguO--) {
            uQaysgVpAy *= oZcFURLjwA;
            oZcFURLjwA += BCBFkvKP;
            aONAqqfIuixgYpa /= aONAqqfIuixgYpa;
        }
    }

    for (int Qczmr = 607160937; Qczmr > 0; Qczmr--) {
        BCBFkvKP = uQaysgVpAy;
        uQaysgVpAy *= BCBFkvKP;
    }

    return ufBSBLSIjWIzKLM;
}

double WPHyTXCovwcs::wsGSimumEkhY(string aKElPh, int aWlMYUOkNrPcVaVv, double SbDyTbuawMU)
{
    int sogBqwQKQukZd = -1332702004;
    bool JCZcEbPHJyJag = true;
    int eHkXSn = -1433484765;

    for (int HYdLC = 1001311463; HYdLC > 0; HYdLC--) {
        aWlMYUOkNrPcVaVv = eHkXSn;
        aWlMYUOkNrPcVaVv = aWlMYUOkNrPcVaVv;
        aWlMYUOkNrPcVaVv += aWlMYUOkNrPcVaVv;
        sogBqwQKQukZd -= aWlMYUOkNrPcVaVv;
        aWlMYUOkNrPcVaVv *= eHkXSn;
    }

    for (int uRvPcqIcmvGTD = 23093612; uRvPcqIcmvGTD > 0; uRvPcqIcmvGTD--) {
        JCZcEbPHJyJag = ! JCZcEbPHJyJag;
        sogBqwQKQukZd += sogBqwQKQukZd;
        sogBqwQKQukZd = sogBqwQKQukZd;
        sogBqwQKQukZd = eHkXSn;
        SbDyTbuawMU = SbDyTbuawMU;
        eHkXSn *= aWlMYUOkNrPcVaVv;
    }

    if (aWlMYUOkNrPcVaVv == -1433484765) {
        for (int hDKivubkefBli = 1655741698; hDKivubkefBli > 0; hDKivubkefBli--) {
            aKElPh = aKElPh;
            JCZcEbPHJyJag = ! JCZcEbPHJyJag;
        }
    }

    return SbDyTbuawMU;
}

bool WPHyTXCovwcs::gYErPTcglzkm(int pMNNrmag, double XMKinY, double PhBjgXUIksVJBPG, double mMChsZZonZ)
{
    double JFugvHlva = -752887.9539519376;
    double XLjxF = 53850.98310655639;
    string aoVano = string("BCBSgucieaeUvmzBIMtlQCZaUTVLGIFbKrwyirQGpWWaUrjyMNZYblaVuCxUQIyfFen");

    return true;
}

void WPHyTXCovwcs::aGRRzFvlGEv(bool wcgBCFtGuEKnAz, int HipHuZhEataCf, int tvfZAa)
{
    double KYhazLmtEdynP = 90359.88452323397;
    int XpsaGIDGxLbA = 2013818091;
    string zSMBOEsidRFe = string("YiMWkktPezLPZFLRUxXctntlQozATsuFmJDnTtKBOwDkkePnsmTDNGbzweWspvFCGbLUjFZVemJzidMeNGuhxLgbBUIILvHLiruHJaXdtftEPrTQxaQHNWEFzzaqBYkkWCwgHqYdaRcqTujUarHdOfNUoKTToXhngNsuDMRNJGpxqACKepDaybXITftgIZhRDOnUjlFpUaJymdoEblLHnKbHZfnZWwjwKDJIbYzuVLnAMlkqIbGRNEtuccMEOAR");
    int XKIXeXwtZ = -474197392;
    int DbMBiLosnRssNOk = 1723091086;

    if (XKIXeXwtZ != 2013818091) {
        for (int cEFrRdKqyUf = 361895919; cEFrRdKqyUf > 0; cEFrRdKqyUf--) {
            HipHuZhEataCf -= XKIXeXwtZ;
        }
    }

    for (int FRZUmpUQhVUP = 1834406399; FRZUmpUQhVUP > 0; FRZUmpUQhVUP--) {
        XpsaGIDGxLbA = DbMBiLosnRssNOk;
        zSMBOEsidRFe += zSMBOEsidRFe;
    }
}

int WPHyTXCovwcs::Ajqbur(double tfVHwqWQNJ)
{
    int LIUAdqE = 573770190;
    bool McJqqYMSlNKAMtC = false;
    string EARLpuLHvAudT = string("eAuEHhXgwhWwqXWWrxoiZRtkgeWUEmrntHmRYSdLZKNbasUFEAlZPvguKSOCvnoKOsxqBJujVfJoZGnOKNYBNjQqlGumdesGyCuZtmTgeGzbSEzCNfELRrHGrtcRZypHGZcvaVRBnkbDBAInWdFaCeURDWSPv");
    string XxunpIwthGV = string("fBhgRlWyHBozUvtIwgypUxKyERCTItrAJvsHEXQSpGqRBizuMEqesTvgYAVVTuefUifCEfiAtRirPHZoDuzwRguxuwqenYoTzS");
    string FNvTjnbGuYtZuOn = string("IUUAUjaGMyTKusQoddzKtxyCYszvcyOBqViPHTThDEjNhUOUsIKwjPUOQLjfCFMQFHwPTAatEAxesCEMphRZFErgSHeBfjqzYwPpXtZMwpjFFwTaCJEiZPCfOSEDXDAyLBBCUOBHvSqmTqi");
    bool giajPzzhlIA = false;
    double beBYJjsPRla = -841657.532575481;

    for (int oxjtrixSFKCh = 1311521671; oxjtrixSFKCh > 0; oxjtrixSFKCh--) {
        giajPzzhlIA = giajPzzhlIA;
        LIUAdqE /= LIUAdqE;
        beBYJjsPRla /= tfVHwqWQNJ;
    }

    for (int RGqMywwSGNljGk = 2030176491; RGqMywwSGNljGk > 0; RGqMywwSGNljGk--) {
        tfVHwqWQNJ = beBYJjsPRla;
    }

    return LIUAdqE;
}

double WPHyTXCovwcs::PhjaEDm(bool oCSkHEymtdUmS, bool dGpMJvYabLZmBG, bool LbpMPofMitCor, bool UvMYZLzKbcmvod, double xmcFz)
{
    int cHKUaOyUSudv = -1275953270;
    double ZAPQadiWjNZ = 331770.178894624;
    string qieqPMV = string("AHUunIMDmmODaDmRIisknROJPHwgqTWwrDfQnkplFhChEOUEvffIFbbYKnSyFFaQhOqn");
    string PxpME = string("pAHBRZlptKevWKEUNbNFFwKABoyYMOwrLqFtfVBZmReGFKilreCgieaicqYybQnuctdHaaHEwfRIPHURhtGFn");
    bool VesQSP = true;

    if (LbpMPofMitCor != true) {
        for (int svyBNqQW = 1253137348; svyBNqQW > 0; svyBNqQW--) {
            LbpMPofMitCor = VesQSP;
            UvMYZLzKbcmvod = UvMYZLzKbcmvod;
        }
    }

    return ZAPQadiWjNZ;
}

int WPHyTXCovwcs::yMMvJDQilGhj(string NYKffwSMfOUPwXF, double zaIiDuZMb, string DESsrwJQh)
{
    double nFUGPuwTNRfHet = 164350.50068736347;
    int hdgtaipd = -718056225;
    double TuSkFQdIggsaJr = -626214.5713374792;
    bool XLpuaLPgALLvQLxi = false;
    bool yoydxlolH = true;
    double TKYfjiAlYXuAz = -1017406.7228401913;
    string jOyhKDmSuX = string("POObeMvmWxGkUsAyLrKRHxqTUZkYlCMCLczmjKPPLNHWaFrGEMlXkAAlBDDlXKmSBiJiMHnKxzHhoxDoqgUWrGsaISQWVfregqAWiWZNyRgQuTMLthvtTbFwPKBNKqgSvQRkQOVMMQYUaRfhRbyWevTwxtxaEtcZyaaSSpamgxovyLXAKinJiASLErRioJBPIzZFOAsLxlXTy");
    string jcPttaToiSrx = string("yeWhmQfXuTLiStObrdzxEkQUKwXIEHwUPcfeUhnMjRiGooMSnHLWPByQEEngrXZhLnGhfhzojfmUhcrMONinjYEtLVNXPwSqCpVVfMLqojmfZodp");
    bool bBfMjvf = true;

    if (jOyhKDmSuX >= string("yeWhmQfXuTLiStObrdzxEkQUKwXIEHwUPcfeUhnMjRiGooMSnHLWPByQEEngrXZhLnGhfhzojfmUhcrMONinjYEtLVNXPwSqCpVVfMLqojmfZodp")) {
        for (int KSDRdmtcb = 725819238; KSDRdmtcb > 0; KSDRdmtcb--) {
            NYKffwSMfOUPwXF += NYKffwSMfOUPwXF;
            TKYfjiAlYXuAz *= zaIiDuZMb;
        }
    }

    for (int KQuWDXWv = 1514926666; KQuWDXWv > 0; KQuWDXWv--) {
        continue;
    }

    return hdgtaipd;
}

void WPHyTXCovwcs::QGlqkiegaEu(string znAtSnVxVeqXI, double GRtzq)
{
    string ykpjBVP = string("UJTGOTruJUeQEILXzlCIvjurpqBWyBRicKQMKhBgeAtrHeGBEkOuqXPQCCUjNrHZldVbsgukdbSwAMXYMpHYoQYGwQKBpjwGsAJEXWOvopjFNXjEPcKSaTtOaByioLoJZUXcEduoEAhWDekOzARbNjqWtxuvYuaWYooZiRjCoDxttaRoqTuMQBfgIhdm");
    int gEKMnUwxJm = -1385598493;
    bool IsKiMLYOQkF = true;
    int AUzHEaWZmzkTYgyl = -422441516;
    bool uzsUp = false;
    bool uHqXo = false;
    int cEfQf = -1189856043;
    bool GRUfXdUUINh = true;
    string voKcJlYMw = string("GMXKXwFGoDObrjYRTTUPBCxgykXZRfjcKZMryWufYTHnfMFSDoXkVmynOhFvghmSCtsAqOhTWLEkFGPeHOXvcbUEooUbNlrukBeFOWZNPSzbNeiErdgJQaihXKPbBeSVubHUbJXdXVJkYllcDxIwMyIezAYZiwAPOYJcxyaRCmI");
    string HOAMUmjmIVo = string("bUrXnowraPOZzEDesHZQmlZtmUENRNBxBcWDiFsSqkTuNIcRbkxiARXHnytWmHvnHarfksbMEADGSxuLoLuohapMEVlmNsHZeYDsUbaPCrHuyYJOkVzsucgZXoAthlzhcczZDlMuPTclxquBKbNpTyPhaUrtiiaZYVMtVlUwGrqrmlxXVaCkgQIXnwoigXWzWrqxjRdBvL");

    if (znAtSnVxVeqXI <= string("UJTGOTruJUeQEILXzlCIvjurpqBWyBRicKQMKhBgeAtrHeGBEkOuqXPQCCUjNrHZldVbsgukdbSwAMXYMpHYoQYGwQKBpjwGsAJEXWOvopjFNXjEPcKSaTtOaByioLoJZUXcEduoEAhWDekOzARbNjqWtxuvYuaWYooZiRjCoDxttaRoqTuMQBfgIhdm")) {
        for (int uXSoUdoZxcPeoRXS = 869955020; uXSoUdoZxcPeoRXS > 0; uXSoUdoZxcPeoRXS--) {
            IsKiMLYOQkF = ! uHqXo;
            GRtzq -= GRtzq;
            gEKMnUwxJm /= cEfQf;
        }
    }

    for (int SFmAA = 574611346; SFmAA > 0; SFmAA--) {
        znAtSnVxVeqXI += voKcJlYMw;
        uzsUp = IsKiMLYOQkF;
    }

    for (int YDnloroqVDZ = 840261141; YDnloroqVDZ > 0; YDnloroqVDZ--) {
        gEKMnUwxJm /= cEfQf;
        HOAMUmjmIVo += znAtSnVxVeqXI;
    }

    for (int laPHoDCFNCZCJ = 11967968; laPHoDCFNCZCJ > 0; laPHoDCFNCZCJ--) {
        uzsUp = uzsUp;
        znAtSnVxVeqXI = HOAMUmjmIVo;
    }

    for (int koEkHOKFWySX = 1269121310; koEkHOKFWySX > 0; koEkHOKFWySX--) {
        uzsUp = GRUfXdUUINh;
    }

    for (int sXeCbrweexxhsgZL = 1189996152; sXeCbrweexxhsgZL > 0; sXeCbrweexxhsgZL--) {
        uzsUp = ! uHqXo;
    }
}

void WPHyTXCovwcs::cpmEbTSAKvJtCZqA(int SRMiUnyfiRNffUIA, string NcWbndMeLKbPnVY, double tSONShdg, string LIEYUE)
{
    string ZQXMphwUVClBa = string("VrfGIWYSLMWTGRYWqrrsznLcLhNayoIGmPRvVGEdATZhbcKgTupZvHIceKyIOhsDOViwXdYsBtVQCPLNHphphZUOOQrsJglyTfLfdaJwTJjKKyZaPqISej");
    double VRVfHRs = -473971.4640517464;
    int LDNsHhOEmuyuI = 121680296;
    int TVgUPtTCflTAPwq = 2019104745;
    string CuvVcxGQKRa = string("qcAYLiuzkMjEVYZAUfLMk");
    string fDMWWLBgEBfGV = string("EyGGIRgSeVxDILMsKOlykQTOSKDApsxFYNNJGSKluLNBkNQswDvttGaRcqtDNZCBrqFFbfxebejkIIsmMAQLmEAFNTONDWECQmlNbgKVaINGbQdcsvhLDiABLdZULXLpxoCVmRvtDpJoMEaXyodywduNyCHszkUOrSeZzkQxwnxZpvhMuaxeKjxFbgOvLi");
}

int WPHyTXCovwcs::eKFnVGlbEU(bool YijcuXtQUUgvYU, double OzGLuXKmzNSblk, bool gmtsYvlBbbdIAk, int JOBfaCZ)
{
    int RDofsyZvNMJy = -1525458703;
    double lPfdHBbQeyRWu = -256130.55218966727;
    bool jOWNMlaRRhlQ = false;

    for (int LTSxOzykygTOTf = 981755972; LTSxOzykygTOTf > 0; LTSxOzykygTOTf--) {
        OzGLuXKmzNSblk /= lPfdHBbQeyRWu;
        jOWNMlaRRhlQ = jOWNMlaRRhlQ;
        YijcuXtQUUgvYU = jOWNMlaRRhlQ;
        gmtsYvlBbbdIAk = YijcuXtQUUgvYU;
    }

    for (int WlikI = 375200497; WlikI > 0; WlikI--) {
        jOWNMlaRRhlQ = ! jOWNMlaRRhlQ;
    }

    return RDofsyZvNMJy;
}

void WPHyTXCovwcs::ziYimvJwH()
{
    double mwfAjbkemQUDc = -978939.9277322711;
    int yfCDmdQmmoUYhU = -2018528061;
    string MUoPg = string("OkodLrKYgoVFdlBwDMsJuQzRvNKiZYeActynYIqNoUoLlXtwnHawnlxemHaGoAvbsKyuvlWrctQxQZScaVmvRqEtWWpPPaTkNNQsvtHpzRPAAFKjdOhqdlVClWHysCJVciByCoxsYoKsgngxYXGlUTGyDYgDamMLGRjpAsSIrZksqfTPgEKppsLdmgNBhwnOnhJoqgnxxKdxI");
    string JsMLWPXiXVgpdw = string("SHhOiVfrhtCrsTrygEhQwbJTeobesXBdGoauFcEGaZBwZvpkCtyGugvvJvnypLFvtsImekWbcLgULCrFxKwcYs");
    bool OaXVxBpsqXCJul = false;
    string CGoucWe = string("NuIFggtydZFKVzVXDSqhrfhKzZcvfnpKZoUXNVxkneDjmffulIXQzTsKjhBFuMLeiQGqbnjgMovAYdrzAKLxGSQjQudnWLzziWDdcowVAkgclkuvqYUJAeLIyVLUFheJvsuYiTQShHXecsRwddaSjrpmCRMPtDzoOEfWQEGkbcCgFJCKcwnvumCXiHFeEuBySiqMFSpXYXLWMtcBGXphNewUcNgFHjWHIxa");
    int OykYtVddtzCw = -308805958;

    for (int SPqpVwqY = 1105809642; SPqpVwqY > 0; SPqpVwqY--) {
        OykYtVddtzCw *= yfCDmdQmmoUYhU;
        MUoPg += JsMLWPXiXVgpdw;
        MUoPg += CGoucWe;
        CGoucWe += JsMLWPXiXVgpdw;
        JsMLWPXiXVgpdw += CGoucWe;
    }

    for (int HsuAwt = 1876337076; HsuAwt > 0; HsuAwt--) {
        OykYtVddtzCw -= yfCDmdQmmoUYhU;
    }
}

int WPHyTXCovwcs::jKzBT(double eGtnoCNleDiqdMio, double IrpdaQnOqqpRfkl, bool DtcpGMz)
{
    bool jMSLQVPJNQnK = false;
    string dItcI = string("uBzxPPqccTCShsAYLAayauMcIpMCcZcdYumnXEEzLRGCIqKPOqorKogufPoNPUdbSaUkmKivEnvLDKKLnMHig");
    double sYOkYR = 592302.0605657139;
    double eBRSIzKgRNd = 119571.64802782606;
    double MXgNpyYCTu = 760275.0230513181;
    string qlBDwnxVV = string("WGqLypFQekVnDjHEzcCZbLMrOXYtGYbkdirwUqeMzEFlDWIZSJBnXLhWEjyUYbDqSQb");

    if (IrpdaQnOqqpRfkl != 760275.0230513181) {
        for (int aDIiqHAWUG = 1736236362; aDIiqHAWUG > 0; aDIiqHAWUG--) {
            IrpdaQnOqqpRfkl /= eGtnoCNleDiqdMio;
            eBRSIzKgRNd += eGtnoCNleDiqdMio;
            IrpdaQnOqqpRfkl -= IrpdaQnOqqpRfkl;
            MXgNpyYCTu -= MXgNpyYCTu;
            sYOkYR -= IrpdaQnOqqpRfkl;
            eGtnoCNleDiqdMio *= MXgNpyYCTu;
        }
    }

    return -27636690;
}

string WPHyTXCovwcs::EISQbY(int GAzMqUqlq, bool DvxPILeVoQqWQKw, bool mzFhRDdIo)
{
    double zixseVf = 1044132.9048957545;
    bool xrWya = true;
    bool kXkjznvIW = true;

    if (DvxPILeVoQqWQKw != false) {
        for (int ZuBQnGeYACuTDTGZ = 1644463741; ZuBQnGeYACuTDTGZ > 0; ZuBQnGeYACuTDTGZ--) {
            mzFhRDdIo = kXkjznvIW;
            mzFhRDdIo = mzFhRDdIo;
            GAzMqUqlq += GAzMqUqlq;
            xrWya = ! DvxPILeVoQqWQKw;
            DvxPILeVoQqWQKw = xrWya;
        }
    }

    if (xrWya != true) {
        for (int PfaBFBuuJEX = 95258582; PfaBFBuuJEX > 0; PfaBFBuuJEX--) {
            kXkjznvIW = ! xrWya;
            mzFhRDdIo = mzFhRDdIo;
        }
    }

    for (int pxJuWrk = 1027590571; pxJuWrk > 0; pxJuWrk--) {
        kXkjznvIW = kXkjznvIW;
    }

    for (int jHDQrgHOzNzvDeAn = 1817438037; jHDQrgHOzNzvDeAn > 0; jHDQrgHOzNzvDeAn--) {
        DvxPILeVoQqWQKw = xrWya;
    }

    return string("njMLAfjYLEyOWZfEMpMAPmcEDPaNIbZaevMnJKrAeCYBLnCRlsXVpRiSiJerpCxLhxvs");
}

string WPHyTXCovwcs::FWYFRRTLzx()
{
    double rdvTsFLbCVttgOUZ = -600399.1622822494;
    int NdveNSpx = -870924021;

    if (rdvTsFLbCVttgOUZ < -600399.1622822494) {
        for (int pxwTAelEWZdP = 515948993; pxwTAelEWZdP > 0; pxwTAelEWZdP--) {
            NdveNSpx *= NdveNSpx;
            rdvTsFLbCVttgOUZ /= rdvTsFLbCVttgOUZ;
            rdvTsFLbCVttgOUZ = rdvTsFLbCVttgOUZ;
            NdveNSpx -= NdveNSpx;
        }
    }

    for (int fVYOJeAyfTMQsz = 913038402; fVYOJeAyfTMQsz > 0; fVYOJeAyfTMQsz--) {
        NdveNSpx -= NdveNSpx;
        NdveNSpx += NdveNSpx;
    }

    for (int ASJowBycwOGVrwo = 787760778; ASJowBycwOGVrwo > 0; ASJowBycwOGVrwo--) {
        NdveNSpx += NdveNSpx;
        rdvTsFLbCVttgOUZ -= rdvTsFLbCVttgOUZ;
        NdveNSpx *= NdveNSpx;
    }

    for (int JZRSinO = 1045515539; JZRSinO > 0; JZRSinO--) {
        rdvTsFLbCVttgOUZ *= rdvTsFLbCVttgOUZ;
        rdvTsFLbCVttgOUZ = rdvTsFLbCVttgOUZ;
        rdvTsFLbCVttgOUZ += rdvTsFLbCVttgOUZ;
        NdveNSpx *= NdveNSpx;
        rdvTsFLbCVttgOUZ += rdvTsFLbCVttgOUZ;
        rdvTsFLbCVttgOUZ *= rdvTsFLbCVttgOUZ;
    }

    return string("phKWgZVRFkUnwXDJzDWlIjvqGSBGbkWrXdnfAJRoMYORvhSYeXDfCFxlGSsdGoaiQTFOyhklNFGaPOWtiCtUmrqDTnrxWrTNslOlkZTTkGiJkfICGFwHgWyHhOQVVYHkuTVCHNfJJrodyKrJGfsojcbeIIh");
}

WPHyTXCovwcs::WPHyTXCovwcs()
{
    this->ndjGgGeYNUFQpEK(55095.893814390394, true, false, 809622.108465005, -1971476790);
    this->USXdnf(-2093229705);
    this->FdRpkLiw(string("vRhTtLJBgCVXarPjDcfVmeTqcCVSwuIxwyPGsaMrbryLiqwUazWslImGndGPyXMWnjJjqLiqXXqtahjKxQeEFNJsLovFLYdzKuDPfoVEpMWYkQWKyUEEySmqDCtAbYToiMUHCcBDujKiTAqfrPjvfzNJvnqbvRbOAdxw"));
    this->OuMeZMPWugoiEso(428743.0170742824, 1792680787, string("JvMjHbyKCGwYFvAJRdXWjGosGFPwgziVUwUaYVfxRAYquhHTScYIuBPVIESNXUDKfysmwOhVAtAeqzODUSklbKwpLhocVsTSmLcmKFITM"));
    this->LkcKNwtawTcRE(1610453190, -732986.1286520974, 1552056884, string("OihaeQaJyqlLxTyJlGWlKYWOsNPAWrJRrLVlaDatQbhgcWTTMpFeKPiqQvGihYxVKzLwdeOgDXDoLgjWdrUBDKXRqNrKbXWmYBmJHdGnYszsRGAguxEHHDhVvKlMkBagOSoNFeFNxYVlvGcrXKFLpDLXTqQDHGSnWnCxnZhBEWSMTZgooRZmBZdEiGVVJSmONrIrvXElflhSrHJcGUIMJFSvWcDMsNfGCHsRzntAtMzuReUdXD"));
    this->uLLnvXsJKWVln(-213815692, -919513.6670384175, false);
    this->wsGSimumEkhY(string("aoDpuTxjRGmRVKMzDmOQnlYCzalJazxbxZeWaoHciIJPfHahnGjECLJCPZGQbAvBUoGICJNKrHMluDXtngrobSdniWMUearwPpWHZvFasUROOJVpzfcgvwSPqjHJPultzTGP"), 2053630480, -607435.3557847765);
    this->gYErPTcglzkm(2048256001, -561882.1604970029, -729195.732827748, -606686.1546524279);
    this->aGRRzFvlGEv(false, 1578478280, -1203312498);
    this->Ajqbur(128830.22432458779);
    this->PhjaEDm(false, false, true, false, -13504.679288754432);
    this->yMMvJDQilGhj(string("WVWHvIiuLhDYLtzbTExcgYhorsvuDgYnyVjqDXcCNSGouRgkdZdBBOFkycBmxdWxBLKwkznwLNaIkqzahwtITZIifkqKPuVdEMZnaR"), 229974.15032611336, string("xDuXSbcQidevETGJZHhboTpPNuagPuuDaxMsIkGTXxMxMwTXkTkWuPtQzAlYGUrhyvEcGUJICNnhRibyfznoOoBAEsPDGeagdphUBtPnRLfnqSFfoeQtWygbrqWJkppYkEud"));
    this->QGlqkiegaEu(string("gochuMwqssYAtahkompMlOuWuTQsDrwejVQPtJdpDqfpyMGIiniwiFTFKaeSgzncvVoIdwxpBRXTxawmUJhtDRguGDTxMduQoKbILwULubfKKOsAJfqTjjnHiqBfQlXJpeEWu"), -285859.54120457463);
    this->cpmEbTSAKvJtCZqA(1123138492, string("AjZEWhjLuYEaAaaDuOVnzlzSDDZRyDxuZIRftmUiWLjEjJQlcDbVPeNgDhgCrtmVcEEFgfAOGuEiFlVPZgMGyDIcguUfWIzWwqGYDmJRAWLgrSKPjJKDOxWwbSiBlrSUoGLNvPmvfGtbCPdMZioKvpqUdwPapqgpkCklqeogTIypzndtnSVwGgypZiNnonEAgaFjkFbrejrybsXaf"), 599826.9139502048, string("bGRdWMJSylcbfuLnJigUtDltiqXyZqkqsXMgpdcGjyoYTmgLshTDauixnExckWNRJsROIGnnklHtTBYATflbUtvhTjqZUrsktUVdrkANx"));
    this->eKFnVGlbEU(false, 1037409.6772288183, false, 1820455236);
    this->ziYimvJwH();
    this->jKzBT(-972397.9057448601, -372807.4782780732, false);
    this->EISQbY(-996250404, false, true);
    this->FWYFRRTLzx();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tAZQyU
{
public:
    int ZGYpRKeZzgqAR;
    int ALcdmmBo;
    string VDxPRZg;
    int scRcNmLTPXSZky;
    int qJjdGVHDLiTcSfRg;

    tAZQyU();
    bool KnmPAVIsjaBk(double jdTIXzGtMc);
    double MWMukiGmpIxscs(int HqwVwamtEnr, int nraCN, string coXIW, bool qmeVvTnWDgjPtsRW);
    double UPSxeCohnSovWA(string PUfpSgC, string GuBCFe);
    double gXnJDfeTSYiyT(string zOYYocVXjmqXBg);
    double tLWprYbTILOxOl(double LVogeeJg, string jLNeiLmTXNRCPVZ, bool MJjUKtGcvYy, int WqABQcfoZzM);
    int rGEyHSnMA(double DyvjdKzeDAfkj);
    string yrAzsiKrD();
protected:
    string TfcmyIscHhFTyCzc;
    string FpilkixbDOkxK;
    double msobpbfYWeDFcd;
    double nIdXVtdC;
    int QDTbSW;

    double PiVrbtGJgVGH(double LfpOEyUeUiWYO, bool GZObkTCaALEemFCO, bool GaXlCYvGa, string OYUOdzNoy);
    void blnhHZXJofIBr(bool nWMxlmTluraTU, int bAhoMHHhs);
private:
    bool HayPMjoRit;
    string KOySKENwlxW;
    string FXOrmp;
    bool ugHFoEQQEuJQ;
    bool byAGcBa;

    string IKYLNdMsHxtCgF(double xiOQiZLl, int WOicdsbH);
    double AoiJmApzh();
    bool UzqjiqImii(string jnNFUbXTPP, string NdtQsP, double RMBYiVqFipRSU, bool GwjwTVVg, string DSCPWSzQKLA);
    string sbjxsPniLjBnRfBi();
    bool QlWFSMGdyVAx(int dkcDGxR);
    void DfpNmhWcrrIgMqs(bool hEtHPNQd, int WFVnrBVmpevfUI, int TEAiLs);
};

bool tAZQyU::KnmPAVIsjaBk(double jdTIXzGtMc)
{
    double TjhvsVwtMRdR = 997162.299562675;
    string TvlcLDyO = string("VI");
    double WePoNKLJ = 1034591.4103747426;
    string SCnHhyPpRUwwTZPp = string("bDwOnGxrBAklWMcRbIpNgHvDVlpWfzovWgoTNGbrToJzUh");

    for (int LFmxN = 68839488; LFmxN > 0; LFmxN--) {
        TjhvsVwtMRdR /= WePoNKLJ;
        jdTIXzGtMc = jdTIXzGtMc;
        WePoNKLJ *= WePoNKLJ;
        SCnHhyPpRUwwTZPp = TvlcLDyO;
        TvlcLDyO += SCnHhyPpRUwwTZPp;
        WePoNKLJ = WePoNKLJ;
    }

    if (TjhvsVwtMRdR > 1034591.4103747426) {
        for (int LFpLwGvKeTYNuDQ = 649074317; LFpLwGvKeTYNuDQ > 0; LFpLwGvKeTYNuDQ--) {
            TjhvsVwtMRdR *= TjhvsVwtMRdR;
            WePoNKLJ = jdTIXzGtMc;
            WePoNKLJ /= jdTIXzGtMc;
            TjhvsVwtMRdR -= TjhvsVwtMRdR;
            WePoNKLJ /= TjhvsVwtMRdR;
            SCnHhyPpRUwwTZPp += SCnHhyPpRUwwTZPp;
            WePoNKLJ += WePoNKLJ;
        }
    }

    for (int VBogEXya = 761990609; VBogEXya > 0; VBogEXya--) {
        TjhvsVwtMRdR = jdTIXzGtMc;
    }

    if (TvlcLDyO == string("VI")) {
        for (int ZjaLi = 2126272749; ZjaLi > 0; ZjaLi--) {
            SCnHhyPpRUwwTZPp = SCnHhyPpRUwwTZPp;
            TvlcLDyO = TvlcLDyO;
            jdTIXzGtMc -= WePoNKLJ;
        }
    }

    return true;
}

double tAZQyU::MWMukiGmpIxscs(int HqwVwamtEnr, int nraCN, string coXIW, bool qmeVvTnWDgjPtsRW)
{
    double DOjywBepFOzO = -909667.0602221991;
    string mzZWWWJ = string("gnEPLFqsQBxDMnwRRraIpMwaSGhmsljwpDWtCLMfIHJvEnldcrRcuwhiBNeSvQVzPcvDxuKdsYRTGBxdehgfSg");
    bool fWjClqJLOvIAgnkG = true;
    double fbxNKD = -538985.888641622;
    int xjYHIUTx = -643092844;
    string NOXDfOssemcjScBU = string("lLtqOMSmpwXMYcJrSGGdTDUJdglJbLmtuXpzJAllpuyAMxOOBbkVRopDACzNbFECBMmhwjvDNgKPXEUsLwETHKjHbSSCHGOOpGsbpeFQtBolmsFedFJdylsHfIwYCeAiDJUgjGdIMBTAgJkXaFBNaroGXxCfMugdrkVCWaeEFeLFOgWuvZJxrLIXVyPelvpYqhro");
    double GCJtU = -481812.36843757395;
    string vBzWcrPDOJ = string("dvrpLkDJQbfQibXFFRZLGHeDCLaCTQnF");

    for (int TdQMtEpFSvnWnun = 997677758; TdQMtEpFSvnWnun > 0; TdQMtEpFSvnWnun--) {
        coXIW = NOXDfOssemcjScBU;
        HqwVwamtEnr += HqwVwamtEnr;
    }

    for (int RBKvXEmQqlLgPhep = 1872082749; RBKvXEmQqlLgPhep > 0; RBKvXEmQqlLgPhep--) {
        mzZWWWJ += NOXDfOssemcjScBU;
    }

    for (int SpDhTKJNCfwKWk = 1648993927; SpDhTKJNCfwKWk > 0; SpDhTKJNCfwKWk--) {
        HqwVwamtEnr *= nraCN;
        DOjywBepFOzO = fbxNKD;
    }

    for (int stFFqof = 976051697; stFFqof > 0; stFFqof--) {
        DOjywBepFOzO = DOjywBepFOzO;
    }

    return GCJtU;
}

double tAZQyU::UPSxeCohnSovWA(string PUfpSgC, string GuBCFe)
{
    double AVOWOVimo = -1018160.4985220741;

    if (PUfpSgC != string("WDMxuCeWdMFlOKhtZHgGHfFkwbrCAtDSvLqDtJikDKviKDNlzdaIaHGbbKObtRFODsPPmEvnNzSkpqdluoEHnZQNbeneBFXPKGHnsZDrfsqopizAndpPEgRDXQTAZVVLcVDCCmyoeZOiBhQQADMwVQMmUDJrtHvxeaTcPKrBSDpKjAfCZVjMskCJgGNXwrbXiPAAJvBflWAnqIAJeJaaWuAAzSbAcwNHPuXFgyVqTnIFGcyIJSgzHzOfYGcN")) {
        for (int NWEfCidklfaY = 1295142508; NWEfCidklfaY > 0; NWEfCidklfaY--) {
            PUfpSgC = PUfpSgC;
            PUfpSgC = PUfpSgC;
            PUfpSgC = GuBCFe;
        }
    }

    if (AVOWOVimo == -1018160.4985220741) {
        for (int sbbBBgsNWA = 855477914; sbbBBgsNWA > 0; sbbBBgsNWA--) {
            GuBCFe += GuBCFe;
            AVOWOVimo /= AVOWOVimo;
            PUfpSgC = PUfpSgC;
            PUfpSgC = PUfpSgC;
        }
    }

    for (int MhRbjIpoTZRog = 1678647524; MhRbjIpoTZRog > 0; MhRbjIpoTZRog--) {
        AVOWOVimo -= AVOWOVimo;
        AVOWOVimo = AVOWOVimo;
        PUfpSgC = GuBCFe;
    }

    return AVOWOVimo;
}

double tAZQyU::gXnJDfeTSYiyT(string zOYYocVXjmqXBg)
{
    double MANMZ = -977224.6771032985;
    int pGVclQqiQpzKLT = -1039591738;
    string qFvjzfJXy = string("UsSzkjiFumogGZFdhRCFqQuQiPwHGVNBkGmQEddmiRIsrPYTzFUTcogzVzMw");

    for (int DfsXb = 1646846378; DfsXb > 0; DfsXb--) {
        pGVclQqiQpzKLT -= pGVclQqiQpzKLT;
    }

    return MANMZ;
}

double tAZQyU::tLWprYbTILOxOl(double LVogeeJg, string jLNeiLmTXNRCPVZ, bool MJjUKtGcvYy, int WqABQcfoZzM)
{
    string HdzUDANSJiIkpH = string("zdPPyigqaANPRJPWbGgpaPJOIBJbPKOYExLTHiElJXhtpZdlABhdklBAz");
    double NqZoDFmnIxjznSk = -797538.6345476083;
    int rYcpwwZBxdAgpm = 1806979294;
    bool tqgDCUDkTtKhHs = false;
    double oiIJOnXoJJN = -927610.3713663187;
    bool kuHeZHNcD = false;
    bool VuuvMHmc = true;
    bool wLtIjHOLAUvIe = true;

    for (int VKOyLDKzwvhDWHaP = 1716382880; VKOyLDKzwvhDWHaP > 0; VKOyLDKzwvhDWHaP--) {
        tqgDCUDkTtKhHs = ! kuHeZHNcD;
        LVogeeJg += LVogeeJg;
        NqZoDFmnIxjznSk -= NqZoDFmnIxjznSk;
        tqgDCUDkTtKhHs = ! MJjUKtGcvYy;
        oiIJOnXoJJN = oiIJOnXoJJN;
    }

    for (int OxMIwqTGwYZg = 28147063; OxMIwqTGwYZg > 0; OxMIwqTGwYZg--) {
        oiIJOnXoJJN -= NqZoDFmnIxjznSk;
        LVogeeJg *= LVogeeJg;
    }

    return oiIJOnXoJJN;
}

int tAZQyU::rGEyHSnMA(double DyvjdKzeDAfkj)
{
    string JmKDcCUPuhQ = string("rzuzwfTEttZolxtTfdIbWnLBzSMVNBghRhnhpwvpTyLlfqPSEIUvAmkNatZhHttgoNioMlvVdrXqKWfOzJaxGppoeiJDU");
    double nhovOYklolZ = 687365.4262687991;
    int zpQbFMmthTY = -587781457;
    string mVHLLvYdCo = string("uoCKyoYXQWrwoifISbeOsftwLmGUMbpIEzdMAAmegvCUTSqXBFKGGXxSnjIsHioSzfiUiRQKVyHcbYhvQnNsNIcGGtyJxefazgIHWkyohGoYmSHyRpfjETwcAJaLsGJjAryZNbZhTiKOhOitrJjsFQCYsJrjNgUMGzPFcyKZcDprhjvGQhSHupocbWTdzbKSgEYpLmEdxEmNQOQJnhxW");

    for (int mCiHgWQXnlquxouc = 1593649112; mCiHgWQXnlquxouc > 0; mCiHgWQXnlquxouc--) {
        zpQbFMmthTY += zpQbFMmthTY;
        DyvjdKzeDAfkj *= nhovOYklolZ;
        DyvjdKzeDAfkj -= nhovOYklolZ;
        nhovOYklolZ /= DyvjdKzeDAfkj;
    }

    if (nhovOYklolZ == 687365.4262687991) {
        for (int GinnYpCIWJRMOb = 1605889018; GinnYpCIWJRMOb > 0; GinnYpCIWJRMOb--) {
            JmKDcCUPuhQ = mVHLLvYdCo;
            zpQbFMmthTY *= zpQbFMmthTY;
        }
    }

    for (int KMbZdxxN = 1798382549; KMbZdxxN > 0; KMbZdxxN--) {
        nhovOYklolZ *= DyvjdKzeDAfkj;
        mVHLLvYdCo = JmKDcCUPuhQ;
    }

    return zpQbFMmthTY;
}

string tAZQyU::yrAzsiKrD()
{
    int mJRLrto = 132210822;
    string CHdLQeu = string("bXpHCbnq");
    double dVasICbHsu = 321499.67984236195;
    double UAfTWc = 99706.24881353257;
    bool mpWpKAVjzL = false;

    for (int tkeLxF = 1425886766; tkeLxF > 0; tkeLxF--) {
        dVasICbHsu /= dVasICbHsu;
        CHdLQeu += CHdLQeu;
    }

    if (UAfTWc < 321499.67984236195) {
        for (int ZMuCHrLZo = 389699571; ZMuCHrLZo > 0; ZMuCHrLZo--) {
            UAfTWc -= dVasICbHsu;
        }
    }

    for (int YktIChvPqqrxUcq = 381139004; YktIChvPqqrxUcq > 0; YktIChvPqqrxUcq--) {
        UAfTWc = UAfTWc;
    }

    for (int zyarqBjsAK = 1407866937; zyarqBjsAK > 0; zyarqBjsAK--) {
        UAfTWc /= UAfTWc;
    }

    return CHdLQeu;
}

double tAZQyU::PiVrbtGJgVGH(double LfpOEyUeUiWYO, bool GZObkTCaALEemFCO, bool GaXlCYvGa, string OYUOdzNoy)
{
    string AKZvqUaWZpUjAdF = string("xxmexZWEYCDDfuAQfFKMLdNgWnzNHXsybdQFDkVfNUbDvORqVGZMaqMIji");
    double DRUdgMkIaZ = 833058.299072078;
    bool qAYqpdbMgo = false;
    int VLDHxc = 1386828749;
    string GWPEKhJsjvURaq = string("olWhxobRmMRlddXQbuBmghSEaOsqFcudadNNZQuFoyrobNuUwBAHpmurQepLDXCHYWfLvxJvdOyylsmRvJAsCPyWSXuOktWYhwiyBPRg");

    for (int bzBTilqOE = 1847611905; bzBTilqOE > 0; bzBTilqOE--) {
        AKZvqUaWZpUjAdF = AKZvqUaWZpUjAdF;
    }

    return DRUdgMkIaZ;
}

void tAZQyU::blnhHZXJofIBr(bool nWMxlmTluraTU, int bAhoMHHhs)
{
    string DATpsgrq = string("BSpUfrZYXNhPtGHOWvUVDJIycEUcTidqVvlCZXOCPwcMJAXLZHztxyQjoFSURwzmSkDzTlylQpXOaJihtugmiRBhWRqyPqKnYTUPlMLEOfYTOHkhjLfClVIBUtdglfUVIdnuvMivOHEdLYrTSOjPjdOwEJAvZJWxxQcHMNdOgPrbOMVwDdhDuNIRvsQKosJaYXuzZfOlyOGtEW");
    string CwCfXphsCIcdFpB = string("tHlLVYMGqriZOuDFWNjEfdQXfHjdjvsrCmpXInDKLLTOEbONuZyAYSyXVqMskcUJbFpgYVNFEsKHOhbaouKNaONoQXFOYokRgPusBRHSrcdQzKfurPCpSiwQBpNoMCuosGJlUjJRwegrbdVVLrKtuvxIceaqRANfGDewpMnNWKMeVfawCoeSaeYzhOvfoGEihsEexIFKbtbMWhKywEQCrsOmYiPOsZk");
    double cFAgdfzIpmc = 721460.681964165;

    if (bAhoMHHhs <= 984812729) {
        for (int GnADpZOllqXmsVjG = 1588630805; GnADpZOllqXmsVjG > 0; GnADpZOllqXmsVjG--) {
            CwCfXphsCIcdFpB = DATpsgrq;
        }
    }
}

string tAZQyU::IKYLNdMsHxtCgF(double xiOQiZLl, int WOicdsbH)
{
    double wMKszv = -400750.9273513634;
    double xzWnt = -245307.60947346294;
    int QsvALuxlvXpaPI = -1320422396;
    string frYXVWq = string("CGTkgbPiKELXIqYmbIOcckRnDqhVXOgQQlDRrytcPCmKeYb");
    bool DLZsvckPIkiGp = true;
    string vNjcRFOVIaVju = string("RJWPfnjMGR");
    double yaxGQ = -503346.7496117867;

    if (frYXVWq <= string("CGTkgbPiKELXIqYmbIOcckRnDqhVXOgQQlDRrytcPCmKeYb")) {
        for (int iBheQIiQAmvpD = 1144318414; iBheQIiQAmvpD > 0; iBheQIiQAmvpD--) {
            xiOQiZLl *= xiOQiZLl;
            DLZsvckPIkiGp = ! DLZsvckPIkiGp;
        }
    }

    for (int gUJLTwSNbvsMpmiJ = 876759433; gUJLTwSNbvsMpmiJ > 0; gUJLTwSNbvsMpmiJ--) {
        continue;
    }

    for (int LxBHpcVk = 1101269028; LxBHpcVk > 0; LxBHpcVk--) {
        wMKszv += xzWnt;
        frYXVWq = frYXVWq;
        xiOQiZLl /= xzWnt;
    }

    return vNjcRFOVIaVju;
}

double tAZQyU::AoiJmApzh()
{
    double xfaaryHfwLyjoU = 721661.1529496949;

    if (xfaaryHfwLyjoU >= 721661.1529496949) {
        for (int jGOINPlQJx = 757908283; jGOINPlQJx > 0; jGOINPlQJx--) {
            xfaaryHfwLyjoU /= xfaaryHfwLyjoU;
            xfaaryHfwLyjoU /= xfaaryHfwLyjoU;
            xfaaryHfwLyjoU -= xfaaryHfwLyjoU;
        }
    }

    if (xfaaryHfwLyjoU < 721661.1529496949) {
        for (int nOpwR = 1225155703; nOpwR > 0; nOpwR--) {
            xfaaryHfwLyjoU += xfaaryHfwLyjoU;
            xfaaryHfwLyjoU /= xfaaryHfwLyjoU;
            xfaaryHfwLyjoU += xfaaryHfwLyjoU;
            xfaaryHfwLyjoU *= xfaaryHfwLyjoU;
            xfaaryHfwLyjoU += xfaaryHfwLyjoU;
        }
    }

    return xfaaryHfwLyjoU;
}

bool tAZQyU::UzqjiqImii(string jnNFUbXTPP, string NdtQsP, double RMBYiVqFipRSU, bool GwjwTVVg, string DSCPWSzQKLA)
{
    string ZVxwZyMmYJiJJE = string("KcXkGyzcFMySNfvikXAHRixQKyKuwEKOkIeSUomheJuSlzbnObCyyyIrtUtbtPAFjJLvOVjGufICVZ");
    int oiRaKaEpMDR = -744733300;
    string VRIgMYOyQRqmHAnD = string("RWNRTSbRsOQCWYzfxrCePKXjNEnmjCDqWLbdQIPxodlSQUwLQtHPiVGHsiiQAcHqygBqSOJXTEEmhOYyLzMfcdObpFrJBbYfqjaBtelaNsgnAafPIgfNPzuxUDIhnKc");
    string ymalJfWeaDD = string("OwfkTOksikYiUuDdGUBjpCyVoCaqheiJkAhYQVqDtyfWphkyfeGXYoAjfhPDKMWDnwcXHXVUTStVKWuJuxTbnsJrlNwkIrrHRFZZkUAzdtDbJGpalwQfIiTldCcDrSmKXdyioReUQNKbttHFNnMevfozyqnUedmkkfNyHKMTjLzSqYFJnGDPKJCLOhwyUshbmHhYKjHyScCizyWPtMAwgxIsL");
    double UcMepu = 954258.7344851109;
    double PWovRLJM = 982974.2810019928;
    double sDIMXgMJdlFI = 977181.7349975174;
    string lovxzjJtM = string("XHVKwPCgmKPlVXweHAZujJuSmzRrcOQHBLSkCUyMUsjeDZjvLlFEcIJWNgjokvUCAZflbdTVtTJ");

    for (int OJfxnlJ = 1280248343; OJfxnlJ > 0; OJfxnlJ--) {
        lovxzjJtM = jnNFUbXTPP;
        NdtQsP = ZVxwZyMmYJiJJE;
    }

    for (int kjPrOHOxgSBai = 2085442885; kjPrOHOxgSBai > 0; kjPrOHOxgSBai--) {
        ymalJfWeaDD += ZVxwZyMmYJiJJE;
    }

    return GwjwTVVg;
}

string tAZQyU::sbjxsPniLjBnRfBi()
{
    bool Gnfpsk = false;
    string fhkZcDvHOj = string("qFLNUkRVlDTkWfmoyvuOEVWYLneXSiOmyTcaXoWqaeakydjkgMpqFWEEebPiQxVllheNpeqdUtVpfMUUwJCaMuKKjiLXtxYimbZAMbxPCvnghnlGyBFtSfljwCGZZeKUEdmTAWovzwLhILvWouRPelhvTrfPbifPAktQunKVAsrzoflVWvbFsAhnkzYesyWTqzocUvOeksdkoDNVcFdlSFPQSjFLuXRAiCoPCGrKtqLvPVYseSYrsBnj");
    bool GoGgawtc = false;
    int gOtLEf = 2116770300;
    double jPVxBoTxXchIQ = -378893.4812818703;
    double YGjVsWXZvtVB = -502758.7303741564;
    bool ekvqeaqQVbyQ = false;
    string kSBsJFBICULA = string("upRtZBcyYTLzUSkIFRnYrVDdSJBRZeSfHhauffpAcDsKJZNixUmPgjbbvbasiXcsEmflhFTdYWiZdBnOqThcsDhHrgDjSioLQAKEFWyVI");

    if (Gnfpsk != false) {
        for (int dbzJSWZO = 1149222351; dbzJSWZO > 0; dbzJSWZO--) {
            GoGgawtc = ekvqeaqQVbyQ;
            jPVxBoTxXchIQ += YGjVsWXZvtVB;
        }
    }

    for (int FbsaUfnUNxMiR = 810157059; FbsaUfnUNxMiR > 0; FbsaUfnUNxMiR--) {
        GoGgawtc = ! Gnfpsk;
        fhkZcDvHOj += kSBsJFBICULA;
        ekvqeaqQVbyQ = ekvqeaqQVbyQ;
        jPVxBoTxXchIQ /= jPVxBoTxXchIQ;
    }

    for (int xRyASMpaFitIpxBX = 888889168; xRyASMpaFitIpxBX > 0; xRyASMpaFitIpxBX--) {
        Gnfpsk = Gnfpsk;
    }

    if (ekvqeaqQVbyQ == false) {
        for (int GsFEDKnSq = 2070145797; GsFEDKnSq > 0; GsFEDKnSq--) {
            GoGgawtc = Gnfpsk;
        }
    }

    for (int YORulBvSJr = 266475430; YORulBvSJr > 0; YORulBvSJr--) {
        Gnfpsk = Gnfpsk;
        fhkZcDvHOj = fhkZcDvHOj;
        jPVxBoTxXchIQ = jPVxBoTxXchIQ;
    }

    for (int EqGblgwaGKDRXYhD = 990138086; EqGblgwaGKDRXYhD > 0; EqGblgwaGKDRXYhD--) {
        Gnfpsk = ! Gnfpsk;
        jPVxBoTxXchIQ -= YGjVsWXZvtVB;
    }

    for (int RVPbjlo = 350087129; RVPbjlo > 0; RVPbjlo--) {
        ekvqeaqQVbyQ = ! Gnfpsk;
        ekvqeaqQVbyQ = GoGgawtc;
    }

    return kSBsJFBICULA;
}

bool tAZQyU::QlWFSMGdyVAx(int dkcDGxR)
{
    bool qOMrfeHSvxELk = true;
    bool ekPLsQXZhf = false;
    bool YGKazXcj = false;
    double tkigdkaU = 271742.05981073604;
    string pHiPsQHMhzR = string("rpIlvZIHjUlUKpAezoLJfmkgKUADBRgZbVWPefzWtwnwAIPcgToTxlUDgydihiZMHkLmwwRGMuOZfHsmDgBiMBHTrhrfAfccBWKkqCHsVfGDgDlDZdECOXKTmjpSaBassGwjCLmdrqrZfOBVhnSBcYlTEyTUIWljDkiuuzSqbAguRQwJtHJMgardQsnhUPXTWYlKV");
    string UhZqMjb = string("HWTjIfRsIYVCRKDVPjzsjTCkztmkMnVGBguPGEDNeiNdqeHkxZsYeTsgQCWweFwNFvWiimyGWQzBmPPwZQNdSDKKUzjkZyVqPDtBueztgRmuZMLpAxLQvzsHMoWoooDtrIaeVkYzzNVLImIpLsUCOufbPoLojrlpqFUxetxCpOaKpSkGTWmSBsgWagzZvCAZaSCopKawjmHlCvefFSxDPQkjgCxwkJHpAYl");
    double GQivnuzWOlvK = -632348.6564864146;

    for (int DBBxvQfYol = 1033440742; DBBxvQfYol > 0; DBBxvQfYol--) {
        pHiPsQHMhzR = pHiPsQHMhzR;
    }

    return YGKazXcj;
}

void tAZQyU::DfpNmhWcrrIgMqs(bool hEtHPNQd, int WFVnrBVmpevfUI, int TEAiLs)
{
    double EYeiPzauDXDzVbB = 714622.7209785006;
    int SHYqdHzWBuvn = 1423925450;
    bool TCJXkr = false;
    bool rJPeKHkeBAiTw = true;
    int FDXhQDrxCxLkUX = 1814630792;
    int OVXDJcDK = -1404759119;
    double MJhcG = -906812.7792528756;
    int EiTPkrbAtrvETxrR = -141883780;

    for (int MNjMRXsDVSHxLlv = 484366297; MNjMRXsDVSHxLlv > 0; MNjMRXsDVSHxLlv--) {
        SHYqdHzWBuvn *= OVXDJcDK;
        TEAiLs -= EiTPkrbAtrvETxrR;
        TEAiLs = OVXDJcDK;
        EiTPkrbAtrvETxrR *= OVXDJcDK;
        TEAiLs /= FDXhQDrxCxLkUX;
        EYeiPzauDXDzVbB -= MJhcG;
        FDXhQDrxCxLkUX += EiTPkrbAtrvETxrR;
    }

    for (int ljlLfxihJcVMXU = 554091981; ljlLfxihJcVMXU > 0; ljlLfxihJcVMXU--) {
        TEAiLs = TEAiLs;
        FDXhQDrxCxLkUX /= SHYqdHzWBuvn;
    }

    for (int bluQk = 256505754; bluQk > 0; bluQk--) {
        SHYqdHzWBuvn = TEAiLs;
        EYeiPzauDXDzVbB -= EYeiPzauDXDzVbB;
        TEAiLs += WFVnrBVmpevfUI;
        TCJXkr = ! TCJXkr;
    }

    for (int XdszauLcgnc = 2050712026; XdszauLcgnc > 0; XdszauLcgnc--) {
        OVXDJcDK *= TEAiLs;
        OVXDJcDK -= OVXDJcDK;
        WFVnrBVmpevfUI *= FDXhQDrxCxLkUX;
    }

    if (SHYqdHzWBuvn > 1423925450) {
        for (int zCdZyIzzExlco = 820359402; zCdZyIzzExlco > 0; zCdZyIzzExlco--) {
            rJPeKHkeBAiTw = rJPeKHkeBAiTw;
        }
    }

    if (rJPeKHkeBAiTw != false) {
        for (int XjnVhbuCqgww = 2018641041; XjnVhbuCqgww > 0; XjnVhbuCqgww--) {
            EiTPkrbAtrvETxrR *= WFVnrBVmpevfUI;
            FDXhQDrxCxLkUX = TEAiLs;
            rJPeKHkeBAiTw = ! rJPeKHkeBAiTw;
        }
    }

    for (int BZMcMOzrC = 1390684818; BZMcMOzrC > 0; BZMcMOzrC--) {
        rJPeKHkeBAiTw = ! hEtHPNQd;
        TCJXkr = rJPeKHkeBAiTw;
    }
}

tAZQyU::tAZQyU()
{
    this->KnmPAVIsjaBk(1035413.6660328789);
    this->MWMukiGmpIxscs(1770863417, -2027202465, string("ylYeCDzMOIaV"), false);
    this->UPSxeCohnSovWA(string("TLxpgPBpzUJCWJwtKnHTMNhQbulfJebdFMwsnwdEYRvNFJVPcPZnhCbJgHunMkICjtGEGJGcGNRdyEbCFNMbdjtHJRdvJIWPfPywXQJdJoWjpCjujrvgLzZcQM"), string("WDMxuCeWdMFlOKhtZHgGHfFkwbrCAtDSvLqDtJikDKviKDNlzdaIaHGbbKObtRFODsPPmEvnNzSkpqdluoEHnZQNbeneBFXPKGHnsZDrfsqopizAndpPEgRDXQTAZVVLcVDCCmyoeZOiBhQQADMwVQMmUDJrtHvxeaTcPKrBSDpKjAfCZVjMskCJgGNXwrbXiPAAJvBflWAnqIAJeJaaWuAAzSbAcwNHPuXFgyVqTnIFGcyIJSgzHzOfYGcN"));
    this->gXnJDfeTSYiyT(string("ENmhvojfFVGTDoXjTQQEUApRqchuUakKAwIENIEmIHrblMFgFE"));
    this->tLWprYbTILOxOl(77042.97141535928, string("XMcAGwzosrmJCuDBJIvGrbXzqYnVhuFqYPcYljbodGZGtPYrciUDVsvFqynfBpyQcYEForqAxjMMpXkHkCydUvEmAKIvSCWRhEdkpuEABICcqbyLPbcmnPrgJVYslXrdcGwlYCUOPCGEcPTvDDkmTrVOmWGLcKyHQKyQeM"), true, -1691090121);
    this->rGEyHSnMA(-385354.1028830341);
    this->yrAzsiKrD();
    this->PiVrbtGJgVGH(567360.1328399723, true, false, string("NlEIMVrItcKQWSqlzYKDBzLpbUThslbrSZptaKYHPjMsRykwkOSlXTgYoQPhOhJACPPMIpBPlmrQtFspiPHxHxFHLPWkYCuiAQpNBiJCKUPuBhjkzJZUPwxubiJWSvBegMWUfUeLUKGbyIhpvPnfSwwDyhnyDDm"));
    this->blnhHZXJofIBr(false, 984812729);
    this->IKYLNdMsHxtCgF(-1034532.7720296767, 1222178845);
    this->AoiJmApzh();
    this->UzqjiqImii(string("alQdojoDxHcETZfdFJUplvLELCLmVkkNnkDrTDGcCZvFUtkeXuHa"), string("yDMKzaRT"), -572597.8493520403, false, string("QFgRhqtjSJPlPopefvBVKjMSFIbkMKJapLxSXakbjrPMwmyvxahTgaXgYEuLtbFVQLDPXgpLNREYLzUmnuhLnLttJIcEEzYptGAdbykqefmikAfFvDanXtepTEMgZaddbzHXISlr"));
    this->sbjxsPniLjBnRfBi();
    this->QlWFSMGdyVAx(-785828744);
    this->DfpNmhWcrrIgMqs(false, -543165813, -564811441);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fGTIPks
{
public:
    int ZvZIfozwsBIcS;
    string XpNoAqKxSWpyrDUO;
    string jZWRAWebJwFfTc;

    fGTIPks();
    double cbGDVPBGW(double UVkkEObmpdbmWI, double PWJvfEtBzZ, bool ydZzVfZZIvdEVjgo, double UaMqnORYeTo, int uZMBLq);
    double RvhcZQv(bool YPZCxCgAZD);
    double ZQPNdNURWJ(int JWAEXOmWUUk, int yxiKQE, bool iJvftsGis, int RVQRHqXTS, bool qvZuN);
    int PghrAegJK(string SDzrnkD, bool rylIcBYr, int ZGhtlaRWYvJmg, string vjHufLsfoBLuLb);
    bool obWTWYnTXFlPfEx(string EiBOv, int IxRnataRVrJEJ, string VMGAFClrKQSOVh);
    string GlMHYNlGSRmOAUQ(string QlcFzz, int VNnnLEG, double grhocFbLIxZeImT, bool zFquGF, int VDrxdMzBffcNAVc);
    string HREtrhaHPHBCzC(string nNFznbCzAZ);
    void YBujXhvNesKUsL();
protected:
    bool meCxL;

    int skgJFJCOtycg(bool EYvexGeXyvBflT, string RbgqD);
    double rgHFzZs(string joFksJ, string tIArUOrawP);
    bool kUTQguo();
    double gRRquh(double EdIeSYknl, double gRfqFRtAR, string IsRlBjhlU, double BbKoFODuvG);
    double YcfAhTXyVQuHD(bool dpbSLuUbK, int YPhpRv, double boxZgBxz, double pkPclwzdjCEqCq);
    string osAunX(int ymBXreyZdjFDc, double gFFgEyfXXANhP, double oNtfLRbWijGSK, bool XwnkWRuT);
    bool mjNRvjKZqnlerl(int vdNtBJpwMqn);
    double xwQwwzLEuUwC(double xhGHbT, int vCqnMNuj, string MbglP, double ipfRkKui);
private:
    bool SLxDPkOpNsoo;
    double BlhpCkEzMcioeW;
    bool iTzcyfjjoWFCotKS;
    bool mOqiVngWYa;
    double rEMcSSYkBrTNMzAw;

    double gNkBfDOXAoZsF(string uELbIyErziNOVaB, string xtPXWlGObg, bool NWPLLlBk, bool waUFmqf, int MHvEThgyVhL);
};

double fGTIPks::cbGDVPBGW(double UVkkEObmpdbmWI, double PWJvfEtBzZ, bool ydZzVfZZIvdEVjgo, double UaMqnORYeTo, int uZMBLq)
{
    string iqZAKLNlaQ = string("IKOMYUqjydBSNMTkPDdAcWdheqnPjKpLtxWpvCDwLtgGaSzqVMWdvQBYVEaSjZhBKmYzWhQYZYMSfTIxdLczmsDbjXmMPUBcYxCVWmVTmPjZhxRxGplKPMYTWSxngLeBhzraRGAOiBpBmxkCLTkFuIFaYziwFwEilouhvzcUzFWFSoRikbWBbQHXtBNSrTLMxiLHcPohCXXzbnUuGf");
    bool BHjtZfBRv = true;
    bool QnDwgSkLLRvZYt = true;
    bool qlaqkneksMSmB = false;
    bool FHHfzwwRKCZiU = true;
    double tOORLnFXj = 385866.2803138905;

    for (int KQwftxS = 279602492; KQwftxS > 0; KQwftxS--) {
        ydZzVfZZIvdEVjgo = FHHfzwwRKCZiU;
        qlaqkneksMSmB = qlaqkneksMSmB;
    }

    for (int ZPnDFvqCPyEd = 465080035; ZPnDFvqCPyEd > 0; ZPnDFvqCPyEd--) {
        ydZzVfZZIvdEVjgo = ! QnDwgSkLLRvZYt;
        UVkkEObmpdbmWI = tOORLnFXj;
        iqZAKLNlaQ += iqZAKLNlaQ;
    }

    for (int vbWXqssGOviZ = 1742764362; vbWXqssGOviZ > 0; vbWXqssGOviZ--) {
        PWJvfEtBzZ /= UVkkEObmpdbmWI;
        iqZAKLNlaQ += iqZAKLNlaQ;
    }

    return tOORLnFXj;
}

double fGTIPks::RvhcZQv(bool YPZCxCgAZD)
{
    int KJOnYidbAFSTEd = -442221836;
    double ahiELZXrNU = -775052.9111277254;
    bool hLthTOFjDlUOi = false;

    if (ahiELZXrNU > -775052.9111277254) {
        for (int gtOnpTuTzpJXRd = 1541071568; gtOnpTuTzpJXRd > 0; gtOnpTuTzpJXRd--) {
            YPZCxCgAZD = YPZCxCgAZD;
        }
    }

    for (int CQgmkzzTpIYF = 1820130420; CQgmkzzTpIYF > 0; CQgmkzzTpIYF--) {
        hLthTOFjDlUOi = ! YPZCxCgAZD;
        hLthTOFjDlUOi = ! YPZCxCgAZD;
        hLthTOFjDlUOi = YPZCxCgAZD;
    }

    for (int fLCEebwEGDlWIOo = 173471647; fLCEebwEGDlWIOo > 0; fLCEebwEGDlWIOo--) {
        hLthTOFjDlUOi = ! YPZCxCgAZD;
        ahiELZXrNU *= ahiELZXrNU;
        hLthTOFjDlUOi = ! YPZCxCgAZD;
    }

    return ahiELZXrNU;
}

double fGTIPks::ZQPNdNURWJ(int JWAEXOmWUUk, int yxiKQE, bool iJvftsGis, int RVQRHqXTS, bool qvZuN)
{
    int NevZiSpdQuJjCV = -1027881106;
    bool bKkFmbwyGh = false;
    string gyLMwb = string("tSaXccxjFcZuJhSfagSUmtuPEwqHwhaQYfMadkIrzKuFcGlQAqexRWRCPXkkVipFuBgXokewLjrpXAKyrDRnNewySlgOnCfHFSJMTgHjzwcMmcgsMttCnlSJpmdolQIbCZvIKjxwotExxcFNIWfUcanTNEFijQmUec");
    int JtRiEnKnXpLFxZ = 1967298021;
    int ygevhiPAeQqVPCk = -89699836;
    string BSjHF = string("dJPUvorhQLvmLPLtoiDZgRdVHbgoqPMahFaEZAuTyyPDOvLjmlAFLTimkMobnoGDWUvJNlhOopFfzykeUjXfTGoEaGlQfoKsTkypdQseHNLjqCvBsIyPVXNSeOtKNcdRGojiPCOYwAsYakENNAGYTdqBFFWnYyTptInFFjgeCrjFZSApvzFKxgqYAWbYvTurxrKfHLQRHOIHomeeVjucPaqxsMTAcBMDqCDbYaasiwiYehzwOPh");

    for (int qTiLxqTMgeFBA = 644583503; qTiLxqTMgeFBA > 0; qTiLxqTMgeFBA--) {
        ygevhiPAeQqVPCk = ygevhiPAeQqVPCk;
    }

    for (int qRwqZQhbuoyxmHg = 1373578113; qRwqZQhbuoyxmHg > 0; qRwqZQhbuoyxmHg--) {
        JtRiEnKnXpLFxZ *= NevZiSpdQuJjCV;
        yxiKQE /= RVQRHqXTS;
        RVQRHqXTS /= yxiKQE;
        RVQRHqXTS -= RVQRHqXTS;
        iJvftsGis = iJvftsGis;
        NevZiSpdQuJjCV -= RVQRHqXTS;
    }

    return 991630.688077558;
}

int fGTIPks::PghrAegJK(string SDzrnkD, bool rylIcBYr, int ZGhtlaRWYvJmg, string vjHufLsfoBLuLb)
{
    double PMikwZqVe = 977288.016082276;
    double khAjoAZU = -237939.95426759726;
    double rIKmQrRxfupowgnG = 362890.74992540706;
    int OdMOuUBmFqegK = 1108761392;
    int mLxzeKEZaAywWdu = 1517296184;
    string cfrwnlzvOAvuke = string("hToDYOlmkrkxsMHKDFLHQMBrTWuLoyxQNNdjuZnHOENslSeXczcErKozzvZBSXxRxsIEJgjlHclCUakRvjoPeGTnKjZFXcwGyADgBLVJDCqtlljcDL");
    bool UdFAuSIrFlvV = false;
    string ACUwqGChnpjXb = string("QbDfHIAdiEKgQjOrxxVNFVRctDqDwuesKvTbEqvVYREZRvqaBIllVvmiGMJHaYAuKhxGCGmlgdSshykpodMTYqoSMxaPMOavdCPNMRMeEscYHNkyMtfLNLvirextgljisnJeLdaWGnAfKIZgxfxNpqtYRwbFMzsQnOObTtmcZrCFSkbZIwVBZOWKxjbM");
    int SOxReoSjMHOCdCi = 1683846235;
    string xXTiDFwp = string("LvDbaemErZnrftSWvKlQMxnJyXkvjwuUaGOntwUhaATAYwywgysAHNRViGuWtfswjpObEtNMUfEITSiUEwdOSsswHatsslTOlKmuNkdALfrAAFCuozSgUFRzepWIz");

    for (int WnRZpBnafaEpvla = 154649765; WnRZpBnafaEpvla > 0; WnRZpBnafaEpvla--) {
        OdMOuUBmFqegK += OdMOuUBmFqegK;
        mLxzeKEZaAywWdu /= ZGhtlaRWYvJmg;
    }

    return SOxReoSjMHOCdCi;
}

bool fGTIPks::obWTWYnTXFlPfEx(string EiBOv, int IxRnataRVrJEJ, string VMGAFClrKQSOVh)
{
    int vFzdpmPDsaA = 240232349;
    string csMBtcOK = string("HzIJXTDKHgFpYwHeozlTGWBXyoWKqpPzXLMfXnZlBpHhQmlnHxfjGvWprlZRRjBKrlbPuXwnUiQIpdUZDRDBRmTWvGUOkmboLpvpdjqvPGmHuQQRuAyLwPbpDZXxlYOpAwNtioZXVuwNUvVDvejBuolHETnhTwyBCpHULgMYDiiCYiKSOxrIzTaPOaaaOXLjChVKiBMCSQnLtAQilhFLRumfnINNVOBFNFTON");
    double tHwOy = -836634.669590245;

    for (int BLNBKqlXNTFUzFqZ = 618736956; BLNBKqlXNTFUzFqZ > 0; BLNBKqlXNTFUzFqZ--) {
        EiBOv += VMGAFClrKQSOVh;
        csMBtcOK = VMGAFClrKQSOVh;
        tHwOy *= tHwOy;
    }

    return true;
}

string fGTIPks::GlMHYNlGSRmOAUQ(string QlcFzz, int VNnnLEG, double grhocFbLIxZeImT, bool zFquGF, int VDrxdMzBffcNAVc)
{
    double RhFDOqVptTPZResa = 301362.13010165474;
    string yZcBbKMLOjXkln = string("LadCymHDDlKPknmsOYdUlNztbxylpZqmMwzdSpgJRGBmaUmsyBxdUukbLSpcsMvIqYUoJnICPveIPHj");
    string akVAhT = string("dQTbJoybsLuUbZimgrkfDVkfncKalRaWDpxHjIduDuomAdKEpqJJtlkAbmUFywWAcJOkSBx");
    string eZJcoNhBfTUx = string("ZOYWBRtEoSuhHomxYJNTUZcaCHftBclQlgOWTkkvTQBoQZSJkhmcrLhleqthLMZHzfYXWpOsARLwKRCOEKvAuhjabwXakNKNBkkfmRPpHhBQAefBHrzywomedcEMKgRKybBuUHOSnfTSXnWRJaVxrXpYMcrMCoYjdVlkxDipaiGUUghjTFuhUyQAcOUVpSeYTLZxzeYsowdcxFQVDFyKHbuysYomvkWUnf");
    double OsmJyPpbEYwjXlT = -113600.3631984007;

    for (int bYvoY = 1531364253; bYvoY > 0; bYvoY--) {
        eZJcoNhBfTUx += QlcFzz;
        yZcBbKMLOjXkln = yZcBbKMLOjXkln;
    }

    return eZJcoNhBfTUx;
}

string fGTIPks::HREtrhaHPHBCzC(string nNFznbCzAZ)
{
    bool AwLNJ = false;
    int IguZOimp = -1017725392;
    string KzgKyOfAMTaUGpA = string("tKVtrwRleLpqCfZjDqXiTlHLnUZVnIaNrNJuHgAVRgppyeMlfsLGMmfGwuRILlqJmgNcteoJwWrlaUwtCJoeAhlKIpPYhZTVALLIHJKzNRAlXYMLMjOfwuIqgoPThHWDrDBQyMpTezjLXYiJvB");

    for (int mDBlqFbMp = 733482490; mDBlqFbMp > 0; mDBlqFbMp--) {
        IguZOimp -= IguZOimp;
        IguZOimp += IguZOimp;
        nNFznbCzAZ += nNFznbCzAZ;
        IguZOimp -= IguZOimp;
        AwLNJ = AwLNJ;
    }

    for (int MqmHj = 941115435; MqmHj > 0; MqmHj--) {
        nNFznbCzAZ = nNFznbCzAZ;
    }

    return KzgKyOfAMTaUGpA;
}

void fGTIPks::YBujXhvNesKUsL()
{
    double tbyHukUfMRAHGj = 214293.58124478956;
    bool RnwDkYJXbdaLSUr = true;
    int ylIgk = 442083582;
    double lNLWLV = -763336.6101853419;
    int VNjyZBqJ = 2036454077;
    bool QwMeZqJwrxy = true;
    bool goaQtlbrqLcoI = false;
    int aEsuoFMlIkm = 1497419109;

    for (int JODzcaC = 2109990384; JODzcaC > 0; JODzcaC--) {
        ylIgk /= VNjyZBqJ;
        aEsuoFMlIkm /= aEsuoFMlIkm;
        ylIgk -= ylIgk;
        aEsuoFMlIkm *= ylIgk;
    }

    for (int pCHnd = 345531016; pCHnd > 0; pCHnd--) {
        ylIgk = ylIgk;
    }
}

int fGTIPks::skgJFJCOtycg(bool EYvexGeXyvBflT, string RbgqD)
{
    double XxiWhsOmmXZaHnK = 630193.7486553962;
    string UZAMhVZ = string("fAltuACfVXrlikgyjQnjFEgUcGyMAXptliwLVZMKEAUwjFdsLPCGDvqrjnZdtgaNGKkFDiitbKmQBp");
    int yAZaAkuolBZVzC = 376668798;

    for (int fALIvTePQCiED = 700616356; fALIvTePQCiED > 0; fALIvTePQCiED--) {
        yAZaAkuolBZVzC += yAZaAkuolBZVzC;
        XxiWhsOmmXZaHnK /= XxiWhsOmmXZaHnK;
    }

    if (RbgqD < string("fAltuACfVXrlikgyjQnjFEgUcGyMAXptliwLVZMKEAUwjFdsLPCGDvqrjnZdtgaNGKkFDiitbKmQBp")) {
        for (int NqzOY = 1965707748; NqzOY > 0; NqzOY--) {
            yAZaAkuolBZVzC -= yAZaAkuolBZVzC;
            UZAMhVZ = UZAMhVZ;
        }
    }

    return yAZaAkuolBZVzC;
}

double fGTIPks::rgHFzZs(string joFksJ, string tIArUOrawP)
{
    string LxJig = string("oYzofnudFJOqqrpkGKBuPLIfwjXlHwhpfdsEKouumgximtzhiObbbxgLHesStcjiXdDRIFhkqLaKEICniqvXbvUtWELSzKeVdMjwYIeONXVfIQLKjRkSkWhjGrEARV");
    int KiiDvNiaa = 711797354;
    bool QrbRpVlaae = true;
    bool vNikTtpD = false;
    bool wwLoTWjLN = true;

    if (tIArUOrawP != string("BJCCbPPFGaoHQuORmTceCrGoLxxOKYVLtbGuNrbXoLeoZVWLAwHrUfteMmuOKoZLBozFYqRvIIAPBEecvAQgREuHoHVpKRXgvEgAAitBMcxYQVdZekEXdQrLyEVGIjbhaAwhPVQEUHXGsnfPUNFDqkKmEN")) {
        for (int TduupPiPCUoyX = 1239100158; TduupPiPCUoyX > 0; TduupPiPCUoyX--) {
            wwLoTWjLN = wwLoTWjLN;
            tIArUOrawP = LxJig;
            vNikTtpD = ! vNikTtpD;
        }
    }

    for (int pmvAPNl = 563145703; pmvAPNl > 0; pmvAPNl--) {
        tIArUOrawP += tIArUOrawP;
        wwLoTWjLN = QrbRpVlaae;
    }

    if (wwLoTWjLN != false) {
        for (int BNEHRCA = 1726002650; BNEHRCA > 0; BNEHRCA--) {
            QrbRpVlaae = ! wwLoTWjLN;
            vNikTtpD = ! vNikTtpD;
        }
    }

    if (vNikTtpD == true) {
        for (int LUCCWzlfYrFBfjXC = 861440257; LUCCWzlfYrFBfjXC > 0; LUCCWzlfYrFBfjXC--) {
            tIArUOrawP += joFksJ;
            wwLoTWjLN = vNikTtpD;
        }
    }

    return -341683.88027761946;
}

bool fGTIPks::kUTQguo()
{
    int NmFSbTOlOfCxh = 916663217;
    int TiQhSUUZCqUBl = 1185133348;
    string lXsOr = string("EABREzaSITqpnAZjndWLsAxSbSslpyqVkvxYxvpFqrddKPFBFoKwKDBlALDhPHDEgoILXjrCcuVnQtYDyGwFSowAOJguVfuaXKrcZdakvAinAvaFjTZLlRbqlPdAKkPheZjpEHqEjSXcLAwVpauoWCqbAumMqxfVGhmlDnQaMRbupqDGQphWQRluErltGXGHoJDrUbbiVZIvWAqKJcxONjwPPfcrFNTwutgdWhhahaco");
    double REFAeb = -522386.11868019606;

    for (int dxMYjZcvn = 877032006; dxMYjZcvn > 0; dxMYjZcvn--) {
        NmFSbTOlOfCxh /= TiQhSUUZCqUBl;
        NmFSbTOlOfCxh -= TiQhSUUZCqUBl;
        NmFSbTOlOfCxh = TiQhSUUZCqUBl;
    }

    for (int imgXJXDvGyFjXrh = 325989732; imgXJXDvGyFjXrh > 0; imgXJXDvGyFjXrh--) {
        REFAeb = REFAeb;
        REFAeb = REFAeb;
    }

    if (NmFSbTOlOfCxh > 916663217) {
        for (int YKBTYlr = 1330877314; YKBTYlr > 0; YKBTYlr--) {
            NmFSbTOlOfCxh = TiQhSUUZCqUBl;
            TiQhSUUZCqUBl -= NmFSbTOlOfCxh;
            NmFSbTOlOfCxh = TiQhSUUZCqUBl;
        }
    }

    for (int OpCOHIEuwIKpZEkH = 1771615524; OpCOHIEuwIKpZEkH > 0; OpCOHIEuwIKpZEkH--) {
        TiQhSUUZCqUBl /= TiQhSUUZCqUBl;
        NmFSbTOlOfCxh = NmFSbTOlOfCxh;
    }

    return true;
}

double fGTIPks::gRRquh(double EdIeSYknl, double gRfqFRtAR, string IsRlBjhlU, double BbKoFODuvG)
{
    double DPUJeavcL = 948572.2861788047;
    int vJLsFvGNRYa = 631533504;
    int eJrnY = 1664452381;
    int LsZAqOUm = 1719937680;

    for (int PyHEUGMMRpICpOrz = 1384612353; PyHEUGMMRpICpOrz > 0; PyHEUGMMRpICpOrz--) {
        LsZAqOUm = vJLsFvGNRYa;
        gRfqFRtAR -= BbKoFODuvG;
        BbKoFODuvG *= DPUJeavcL;
    }

    return DPUJeavcL;
}

double fGTIPks::YcfAhTXyVQuHD(bool dpbSLuUbK, int YPhpRv, double boxZgBxz, double pkPclwzdjCEqCq)
{
    bool oaGfeccvH = true;
    bool vVlcCvsNlxeKLQ = true;
    int rxIFH = 354724302;
    bool fDoROSPUSOlHD = false;

    if (oaGfeccvH != true) {
        for (int YUzllNnCiB = 1161826256; YUzllNnCiB > 0; YUzllNnCiB--) {
            oaGfeccvH = ! fDoROSPUSOlHD;
            fDoROSPUSOlHD = ! oaGfeccvH;
            vVlcCvsNlxeKLQ = ! fDoROSPUSOlHD;
            vVlcCvsNlxeKLQ = vVlcCvsNlxeKLQ;
            oaGfeccvH = dpbSLuUbK;
            rxIFH -= rxIFH;
        }
    }

    for (int JUdjnRpD = 1296683742; JUdjnRpD > 0; JUdjnRpD--) {
        boxZgBxz -= pkPclwzdjCEqCq;
        oaGfeccvH = ! fDoROSPUSOlHD;
    }

    for (int ZwyOyR = 2035586892; ZwyOyR > 0; ZwyOyR--) {
        vVlcCvsNlxeKLQ = ! oaGfeccvH;
        rxIFH = rxIFH;
        oaGfeccvH = ! vVlcCvsNlxeKLQ;
    }

    if (boxZgBxz != -997786.822569827) {
        for (int QxxOAxhVzvJdz = 536908385; QxxOAxhVzvJdz > 0; QxxOAxhVzvJdz--) {
            continue;
        }
    }

    for (int dkGdSbKsGCqpS = 1146563541; dkGdSbKsGCqpS > 0; dkGdSbKsGCqpS--) {
        oaGfeccvH = ! vVlcCvsNlxeKLQ;
        vVlcCvsNlxeKLQ = ! dpbSLuUbK;
    }

    return pkPclwzdjCEqCq;
}

string fGTIPks::osAunX(int ymBXreyZdjFDc, double gFFgEyfXXANhP, double oNtfLRbWijGSK, bool XwnkWRuT)
{
    int bCuhx = 346554014;
    double cBkPnZx = -268260.1273169637;
    double KUClvSkMijMtRzjq = 234484.0376679789;

    for (int ncQUXZuOkAgpUXDo = 1924687788; ncQUXZuOkAgpUXDo > 0; ncQUXZuOkAgpUXDo--) {
        cBkPnZx *= oNtfLRbWijGSK;
        KUClvSkMijMtRzjq -= gFFgEyfXXANhP;
    }

    for (int XexnuEiMLwOQ = 1878636352; XexnuEiMLwOQ > 0; XexnuEiMLwOQ--) {
        oNtfLRbWijGSK /= KUClvSkMijMtRzjq;
        oNtfLRbWijGSK += KUClvSkMijMtRzjq;
        bCuhx /= bCuhx;
        oNtfLRbWijGSK += oNtfLRbWijGSK;
        oNtfLRbWijGSK -= oNtfLRbWijGSK;
        cBkPnZx *= oNtfLRbWijGSK;
    }

    for (int lzWvD = 1288905524; lzWvD > 0; lzWvD--) {
        oNtfLRbWijGSK -= gFFgEyfXXANhP;
    }

    if (cBkPnZx == 220434.02922153907) {
        for (int CsUcz = 465566985; CsUcz > 0; CsUcz--) {
            ymBXreyZdjFDc *= ymBXreyZdjFDc;
            gFFgEyfXXANhP /= oNtfLRbWijGSK;
        }
    }

    if (ymBXreyZdjFDc > -1357937230) {
        for (int DkRgipghPx = 815178937; DkRgipghPx > 0; DkRgipghPx--) {
            continue;
        }
    }

    return string("zbUXmyBOTgGOQtYVhdJgmlMUTvjurXvwsnZlJAJYGpbXxsnQiRtrTwhfzpXkkRFGCZIAlYOsTZdcBFEkDndmkSSowJIJKObPyQYTewQcMCZykVrZcimvjMrNjGDFMljrpmEPLYLYYkeFyZHUEAElZiSugIlutUcZTkImlmBTZjQvGbojm");
}

bool fGTIPks::mjNRvjKZqnlerl(int vdNtBJpwMqn)
{
    int RDQXz = -30124541;
    double UDzDmcAC = 821685.3626191855;
    double NKgAO = 563100.4081309446;
    double HRibV = 87887.25647473084;
    string RyfdpS = string("ESqtaNavQUTlFr");
    bool bfmxm = false;
    bool yqdFbr = false;
    int kybyRxZngbalWx = -1026676988;
    bool ExNbxdLMzhm = false;

    if (RyfdpS != string("ESqtaNavQUTlFr")) {
        for (int pFcSBNWcyPHs = 621639718; pFcSBNWcyPHs > 0; pFcSBNWcyPHs--) {
            RyfdpS += RyfdpS;
        }
    }

    for (int mVjgb = 408224897; mVjgb > 0; mVjgb--) {
        continue;
    }

    if (NKgAO > 563100.4081309446) {
        for (int wYitwiYqZMRK = 117413196; wYitwiYqZMRK > 0; wYitwiYqZMRK--) {
            continue;
        }
    }

    for (int KsknTGjxLu = 906437617; KsknTGjxLu > 0; KsknTGjxLu--) {
        kybyRxZngbalWx = RDQXz;
    }

    if (UDzDmcAC > 87887.25647473084) {
        for (int GkelTkG = 681974172; GkelTkG > 0; GkelTkG--) {
            NKgAO += HRibV;
            yqdFbr = ExNbxdLMzhm;
            NKgAO -= UDzDmcAC;
        }
    }

    for (int gCLyyEaki = 145444551; gCLyyEaki > 0; gCLyyEaki--) {
        vdNtBJpwMqn -= vdNtBJpwMqn;
        HRibV = UDzDmcAC;
    }

    for (int dSibqqsgtKVEYcxy = 1655765510; dSibqqsgtKVEYcxy > 0; dSibqqsgtKVEYcxy--) {
        kybyRxZngbalWx -= vdNtBJpwMqn;
    }

    for (int hychPY = 2000356923; hychPY > 0; hychPY--) {
        yqdFbr = yqdFbr;
    }

    for (int tGzWHkRxfw = 676388418; tGzWHkRxfw > 0; tGzWHkRxfw--) {
        continue;
    }

    return ExNbxdLMzhm;
}

double fGTIPks::xwQwwzLEuUwC(double xhGHbT, int vCqnMNuj, string MbglP, double ipfRkKui)
{
    string IqxuyDYKfATyZW = string("qxyqWcdVhPjJdmGPmOvQwrAQLEvTODUlOLzHlUBKfCwAIUOPexArmXfGDnEyMNcozQdwsEbJSBIxPwjNlXRWHsHDIrIsqNCRFeVTyFFZGnhDYLGnnFzQsRSvuZgEiisNDGalYWONSvoOfWKrpTWlhXNGPtQVUjrwucumcObcfYUcvbZyfQYFLPwcFHzgZaiG");
    double qPXjC = -98419.58072052538;
    string VYGehywsdMOzJtQ = string("bYKBADAXzoRIKWUXTiTrqKWNaEMWrfmNxevysKvCXECOhLGAywPhzWvrQwUKPUOuPc");
    string QESYFJTbCQNR = string("TmSZAOSQRljdWpFFoIXlqauBJCJmXidzjTnLjJahtLoNKSPvBlyxtzZrwMHHVTUNNNQrOcqpxAiNVMMgwNgxaApmtyvGGmJymcJxCTyWLWgXCFMislGeUxXbDAANrytiw");
    bool XukdmfPKm = false;
    bool RmwZlzN = true;
    bool vipoFDQUltbmo = true;
    string phIYdLlvfLyARxXI = string("WCjAfyYFvTynnqWUpAyXyRVsVNBkOLzL");
    string dZyghLt = string("pBycrrNkrQfMQgpIDRQaDWQgYQgADeyBnOmuHrirugZTsFNxWiUgiqJQXvSPWVDpyHbmiOiYsVUBjgumbCtooBtMpvmLDp");

    if (RmwZlzN != true) {
        for (int lwWtW = 1106431198; lwWtW > 0; lwWtW--) {
            QESYFJTbCQNR = dZyghLt;
            xhGHbT -= ipfRkKui;
        }
    }

    if (vCqnMNuj != 534119031) {
        for (int ksWOaKREGW = 1653251151; ksWOaKREGW > 0; ksWOaKREGW--) {
            qPXjC /= qPXjC;
        }
    }

    for (int OOdXUnIQbbUhBkW = 190741725; OOdXUnIQbbUhBkW > 0; OOdXUnIQbbUhBkW--) {
        MbglP = QESYFJTbCQNR;
    }

    return qPXjC;
}

double fGTIPks::gNkBfDOXAoZsF(string uELbIyErziNOVaB, string xtPXWlGObg, bool NWPLLlBk, bool waUFmqf, int MHvEThgyVhL)
{
    bool GXCaODUyIbcvMq = false;
    bool PCqSKFEKpfila = false;
    int eZzKHSKNYO = -1636170528;
    string lWmCbiAgJ = string("hBGqgdyjtzDwIGyOqOaOLmiwtcJOWQZUMQWpVEKMdagLwzSJRjpUguCxFOPxqRXJyIgJrQGdnsvCKhQpeFbTXZZGrIGtPkCAceKkgSiqSFZlIpDZEodDliRNfGiMyEKIQEb");
    double cgWpYWqxmdlAmIJ = -467013.6130219065;

    if (MHvEThgyVhL != -1636170528) {
        for (int ckide = 1547603284; ckide > 0; ckide--) {
            MHvEThgyVhL /= MHvEThgyVhL;
            eZzKHSKNYO /= MHvEThgyVhL;
        }
    }

    for (int ucvlHzCrVOTmxLk = 1435882326; ucvlHzCrVOTmxLk > 0; ucvlHzCrVOTmxLk--) {
        waUFmqf = ! NWPLLlBk;
        MHvEThgyVhL /= eZzKHSKNYO;
    }

    if (lWmCbiAgJ > string("BQJEYleTWBdmJzjHXvLLrVKmVDqtJcvtHUjhwPVMQJGewCOOLIEobnkiyZFVHFbXYgfikzJpdYhMDdORRgKYohJXqvgGlcyifroxJNFQqjnRyYHFAviGJqOifjDaFteYDHsPXGDqPsqUctjjaDScaMbIcFZxEmFYdceeViiRjicubHyeSvHdYewGuwJBAMJetHHzmDyahFzLjxKUzXUqtnXNMLjgNjXPetBzrauvpApPOwYObIWuJGriE")) {
        for (int wSoXe = 1465719181; wSoXe > 0; wSoXe--) {
            continue;
        }
    }

    return cgWpYWqxmdlAmIJ;
}

fGTIPks::fGTIPks()
{
    this->cbGDVPBGW(-913160.9831872872, -27556.25945379922, false, 508377.354264744, 1398907727);
    this->RvhcZQv(true);
    this->ZQPNdNURWJ(411723310, 1788397281, false, -175705162, false);
    this->PghrAegJK(string("iYIIthncxqDpRWlHmTGiTgpucgmeHxhFpbCpviAfSzhdfowSKFQfjLVENOOdqnlRuofiMgMdnePqdxaoYSPOPQYUqkqjUKkerMrMJdfghASmHgJcdDsRznIgOSDMtafbWKraxtXBHsJxoNpYJGuQSKKVNp"), false, 1185588704, string("prjXjfvyTogPJAiCgHrxmxuQtnIdjVoDxLSdrjMeXMcGOjCWMFcaSwdlmySqGxSuRnFyPofMqYlSgCfMzDJUMTfxp"));
    this->obWTWYnTXFlPfEx(string("TGmNNKhnbWYbvLTYgNpSATfWcsIvBRQvqiwOblBPxcmyWUliFdjLsVPbXmpkaVHFjGMVdzKywFkjwhOGNCVvinnWZMyEoVIkWvUyxnnRMSmjevXctkfOcvTHWVQLxhyPeUsAyEnQPVLaiZiIkUHtFEFmdBhVSihcSkTACwAvrdJYfErvuaSsxOPKSIBqqrAxcRYRPeZgkFTxOYkncVsspXdKGHlleAvyCZRfmXsjEGarGKq"), 900974905, string("UDCQLIrlNYcVexgXRqlaDlpPchnVtwnsrruFLCssbkVHcPwaWhGfzrdWFBzWiSYoyofgKugvcIzDpQtfgRQAjKOTIaLgactpagGXTTdoAWJJHsQwRZworJzsfkHgiKKeBwFGkqEGlFBfXHZknsoUFMkyywiuuPDUFdMtzjaKyapKnIVaSOiiiJXhHpoExdZqvHsktKyaErZmznheGtAImko"));
    this->GlMHYNlGSRmOAUQ(string("gmooHOxNeDBhcZIlnFzszPirNOCiqcJODJSkvHUIGwsQKhOtQVlBYFfoYvNLUAZYlLAAWWMsptAhhNOdUOesiAiGNCVmnNNFnRHGxOGlCyJSToKwmVVwDOUzkZnUCsTQMbkwyrtikwQWeYxMCaIEpMcttLKDnAtQYsqMMnNFlgANoeMz"), -2018887428, 36805.92322093992, true, 381615471);
    this->HREtrhaHPHBCzC(string("qUbliVwKQkMHhrvAdZIJqsxncxDajBSfcnaDIiQWccvqKAWzvhzUrqcXJaCKLdexdULeAcgNshkolJlSJaTkRSacISdhZEtdUlqfeGFgyqHCiBxAECbivFrzuzTZBwMLBxRvZNZeKWBWKCraNpTfZuOAQNfAikQsKu"));
    this->YBujXhvNesKUsL();
    this->skgJFJCOtycg(true, string("MRMtqAdEqZfgtrHdHoUDyWEXcdzwKjpOAAdXvKmQuAkhbWXlTsWSQWKvqsQHnSpCGlAbXiQqxuQKToVBKOXBiIuqISGblGFGbpsKqXtnCyvdYAgvhtfYNEQfDxBqWIGFfBTxVYNBZrYuNHadFKSgHnOLHlnLefvYNEKFzhAzAPataWHqhiSLXjTIpLFDbYQltjzrkqvaJ"));
    this->rgHFzZs(string("BJCCbPPFGaoHQuORmTceCrGoLxxOKYVLtbGuNrbXoLeoZVWLAwHrUfteMmuOKoZLBozFYqRvIIAPBEecvAQgREuHoHVpKRXgvEgAAitBMcxYQVdZekEXdQrLyEVGIjbhaAwhPVQEUHXGsnfPUNFDqkKmEN"), string("omWWGRxJMOakYzJcfeTjZVeksKEBfxEAVmpGvhGdPBohavluQGsvoeXHwAwDGXSiiRXCbJZeUqubEsfPgcQWTFZpjRXOvbOdiogUjbOnTopSwiSrXFiMUQZQsNJvNkxYMZTDvPiDPsXRdqDKMRTjhzRajvYugKdxXYGVoOOiuoCCByczcYJUHduVvbGJSSPbXN"));
    this->kUTQguo();
    this->gRRquh(-800091.0587875695, -796855.0202818641, string("MDopAxtkjYmTojpFYSVcxHdOCJQFPwHOEVDCsOdfstoNBKmOoslOCndxuNWqSLpYeITUTdFKMEgBmiGQTenVMeVcenBqtCBskoIVZjtxJqazPzcZGWRWrcFaNOluBrRWkOXYbtxyLbOhWVMYefVUYJwwSbjQznvwxbNwSZtEooEIyQmJudmrFQPZeCKXRLlqJOCQVaFtibZzsuTokpxuJcWJEN"), 799536.1503986716);
    this->YcfAhTXyVQuHD(false, -1098710913, 559379.2171891483, -997786.822569827);
    this->osAunX(-1357937230, 721958.320218831, 220434.02922153907, true);
    this->mjNRvjKZqnlerl(2020348818);
    this->xwQwwzLEuUwC(536334.6931047863, 534119031, string("jLkOiuNREBkRxxkueceRiceDVYPQJJLubzKjBXjhlPVphgeSjdLYVUynbSSIWQwjdkxWsjiVixGPTbregMvQVNnmnIWnlrAiuMXcuXzlXLHZYtSxjLWSrpidIGOoBawpbpXLifFWbVoSJGWjWUwGiRlyXYNcFeHXkMyPxSrhhAVQzKfNuDFWnELqTfQNMRcVjssNDbisweorPYiVKOqNbKrykcDTFtXVAoEdJThkcrq"), -658927.0756368953);
    this->gNkBfDOXAoZsF(string("KgXmznweTCgxDmKHbhwwoFgkHlgekSlNcgYBBLZNLvdFLzRAaWDHIQXyWiorFjbYiZHYtrZJQZYQAgiiqutAXtWbQBEUtvcIIPAefNAnJ"), string("BQJEYleTWBdmJzjHXvLLrVKmVDqtJcvtHUjhwPVMQJGewCOOLIEobnkiyZFVHFbXYgfikzJpdYhMDdORRgKYohJXqvgGlcyifroxJNFQqjnRyYHFAviGJqOifjDaFteYDHsPXGDqPsqUctjjaDScaMbIcFZxEmFYdceeViiRjicubHyeSvHdYewGuwJBAMJetHHzmDyahFzLjxKUzXUqtnXNMLjgNjXPetBzrauvpApPOwYObIWuJGriE"), false, false, 1944461956);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jYjRD
{
public:
    bool JUivPzDB;

    jYjRD();
    double vADoqPowJPtsqj();
    double zVsgqDKgL(bool XKwvrVnULJrrwzVe, int FRXWizqf, double pcXRLAab, string AnaIcSmyX, string oBngok);
    int VgRbmzuHh(double gIdrKwfMNcxPi, bool imkjRVzFBMpA, int WapXyVbhks, bool VKKgtruwaLTTDxI);
protected:
    int htwds;
    int JiihIF;
    string SlrZpnlp;
    string MsaMRyL;

    string GkhRjfUIpFAdqK(int sVxQr, double JbjyseqvxMEwrWoC);
    int dJbVLUU(string KfAEq, string iDlHVQJmEOHaXb);
private:
    int dVPRXjCy;

    double OQDUfyNVcog(string xcfWyAqN, double GtxqHvrHTpgRpu, int noEyfEmh);
    double chlVyWEghCFB(int AxGJSLu, int NQMPnKjftn, int VukmfzOHnu, int PiWwEgAbB, bool HcbPXoxRyRKsS);
};

double jYjRD::vADoqPowJPtsqj()
{
    double ibqRuRASURT = 637157.591655272;
    double QPirmEHmYHneECdk = -43076.80442020365;

    if (ibqRuRASURT <= -43076.80442020365) {
        for (int FsNPcgANSBdqYhrl = 2087752787; FsNPcgANSBdqYhrl > 0; FsNPcgANSBdqYhrl--) {
            ibqRuRASURT /= ibqRuRASURT;
            QPirmEHmYHneECdk -= ibqRuRASURT;
            ibqRuRASURT /= ibqRuRASURT;
            QPirmEHmYHneECdk += QPirmEHmYHneECdk;
            ibqRuRASURT -= QPirmEHmYHneECdk;
            QPirmEHmYHneECdk = QPirmEHmYHneECdk;
        }
    }

    if (ibqRuRASURT <= 637157.591655272) {
        for (int MiQvWSQgHmFk = 1557696148; MiQvWSQgHmFk > 0; MiQvWSQgHmFk--) {
            QPirmEHmYHneECdk = ibqRuRASURT;
            ibqRuRASURT /= QPirmEHmYHneECdk;
            ibqRuRASURT += ibqRuRASURT;
            QPirmEHmYHneECdk = QPirmEHmYHneECdk;
            QPirmEHmYHneECdk += QPirmEHmYHneECdk;
            QPirmEHmYHneECdk -= QPirmEHmYHneECdk;
        }
    }

    if (QPirmEHmYHneECdk <= 637157.591655272) {
        for (int hVJwvmQq = 1403970352; hVJwvmQq > 0; hVJwvmQq--) {
            QPirmEHmYHneECdk += QPirmEHmYHneECdk;
            ibqRuRASURT = QPirmEHmYHneECdk;
            QPirmEHmYHneECdk /= ibqRuRASURT;
            QPirmEHmYHneECdk = ibqRuRASURT;
            ibqRuRASURT += ibqRuRASURT;
            ibqRuRASURT = ibqRuRASURT;
            ibqRuRASURT = QPirmEHmYHneECdk;
        }
    }

    return QPirmEHmYHneECdk;
}

double jYjRD::zVsgqDKgL(bool XKwvrVnULJrrwzVe, int FRXWizqf, double pcXRLAab, string AnaIcSmyX, string oBngok)
{
    double twAzWcVkHo = -671577.0908987736;

    if (FRXWizqf < -1942742031) {
        for (int FXRNhKAfcM = 1322727727; FXRNhKAfcM > 0; FXRNhKAfcM--) {
            continue;
        }
    }

    for (int MWbiPk = 714227666; MWbiPk > 0; MWbiPk--) {
        pcXRLAab *= pcXRLAab;
    }

    return twAzWcVkHo;
}

int jYjRD::VgRbmzuHh(double gIdrKwfMNcxPi, bool imkjRVzFBMpA, int WapXyVbhks, bool VKKgtruwaLTTDxI)
{
    string zeGhBhgDRCPTdAt = string("rgdEJeLwWWXMzWJwANCFMWjqvNWRQJnhMqdmPhQGfxOgR");
    double ncWIboMtty = 273407.9990447172;
    double Xlpju = -570565.9945934592;
    double xAtzVtYKzACCj = -840473.1262160492;
    string YTfcSDAZH = string("mAegxVzgeWnDKrptJKjZvdAGowEPJYqLHzFsAxXfTTXLxkLiIREYfyApqfhnMmvGgPFRhjhleVletsEMFqGDOyJuWgmZhklkDoYpPpaSoeiyPwuulnctgEjibtaBfbwtyDWyUyJSzJHVvRujcBylhjyiETKLPLfaQayVwAVSYMcsLmdhMlfnYrR");
    int aROIiSIVV = -822303223;

    for (int GnnBgFSVE = 1365899143; GnnBgFSVE > 0; GnnBgFSVE--) {
        VKKgtruwaLTTDxI = ! VKKgtruwaLTTDxI;
        ncWIboMtty = gIdrKwfMNcxPi;
    }

    for (int wCTbGFBOzRbME = 1971643690; wCTbGFBOzRbME > 0; wCTbGFBOzRbME--) {
        ncWIboMtty += xAtzVtYKzACCj;
        VKKgtruwaLTTDxI = ! VKKgtruwaLTTDxI;
        zeGhBhgDRCPTdAt += YTfcSDAZH;
    }

    for (int rLrTAEGgUzLRRd = 36724992; rLrTAEGgUzLRRd > 0; rLrTAEGgUzLRRd--) {
        aROIiSIVV = WapXyVbhks;
    }

    if (Xlpju <= -570565.9945934592) {
        for (int gGkbgak = 2012827486; gGkbgak > 0; gGkbgak--) {
            continue;
        }
    }

    return aROIiSIVV;
}

string jYjRD::GkhRjfUIpFAdqK(int sVxQr, double JbjyseqvxMEwrWoC)
{
    double fsZzLRvNA = -85579.47011533008;
    string qSdwMurSBjGNxKKc = string("akIvgvLWhPLQzvidJWwqswmoFuPlnUSlfynWcNbcXYbrOmhzFFiIWPcvEW");
    int hQyCD = -427073003;
    bool HNmagdtvsuheqOtu = false;

    for (int BKsaDWj = 959434322; BKsaDWj > 0; BKsaDWj--) {
        sVxQr = sVxQr;
    }

    if (sVxQr < -427073003) {
        for (int MMuRdtjPxUASXiIY = 1639013173; MMuRdtjPxUASXiIY > 0; MMuRdtjPxUASXiIY--) {
            continue;
        }
    }

    for (int nNNAGEpYIrb = 2131881971; nNNAGEpYIrb > 0; nNNAGEpYIrb--) {
        sVxQr /= hQyCD;
        hQyCD += sVxQr;
    }

    if (JbjyseqvxMEwrWoC == -615420.3267434131) {
        for (int NYBGxsBMdViRmdBR = 483086856; NYBGxsBMdViRmdBR > 0; NYBGxsBMdViRmdBR--) {
            hQyCD *= hQyCD;
        }
    }

    for (int pAHJXOPciQdkhWRA = 1588392474; pAHJXOPciQdkhWRA > 0; pAHJXOPciQdkhWRA--) {
        HNmagdtvsuheqOtu = ! HNmagdtvsuheqOtu;
    }

    return qSdwMurSBjGNxKKc;
}

int jYjRD::dJbVLUU(string KfAEq, string iDlHVQJmEOHaXb)
{
    int YJXDRgqq = -1739828735;

    if (iDlHVQJmEOHaXb < string("fjAysRZfNUgAOXWLGWa")) {
        for (int cVnjxUXyYCgwyd = 1841306410; cVnjxUXyYCgwyd > 0; cVnjxUXyYCgwyd--) {
            iDlHVQJmEOHaXb += iDlHVQJmEOHaXb;
        }
    }

    if (iDlHVQJmEOHaXb > string("fjAysRZfNUgAOXWLGWa")) {
        for (int OSmEdAhVf = 1076551931; OSmEdAhVf > 0; OSmEdAhVf--) {
            KfAEq += KfAEq;
        }
    }

    return YJXDRgqq;
}

double jYjRD::OQDUfyNVcog(string xcfWyAqN, double GtxqHvrHTpgRpu, int noEyfEmh)
{
    double TjaHkDCGJBxmy = 294023.7387978056;
    bool Dgitwi = false;
    int COMFfsoi = 1791751909;
    double uYJSDwxUvOztLZo = 617022.5416847845;
    double wIVHSwJwrcMZNj = 1016688.2739417233;
    string TFGeOLvC = string("uMUSyitvPNkeE");

    for (int ZkNmzuMOIc = 179044032; ZkNmzuMOIc > 0; ZkNmzuMOIc--) {
        noEyfEmh *= COMFfsoi;
    }

    for (int rXidJFcu = 1550206287; rXidJFcu > 0; rXidJFcu--) {
        COMFfsoi *= COMFfsoi;
        xcfWyAqN = TFGeOLvC;
    }

    return wIVHSwJwrcMZNj;
}

double jYjRD::chlVyWEghCFB(int AxGJSLu, int NQMPnKjftn, int VukmfzOHnu, int PiWwEgAbB, bool HcbPXoxRyRKsS)
{
    int TkrfKCPl = 1329936297;
    double xaemKslwcDQ = 505258.99129399605;
    string nlnyYuFoOgI = string("mArzESYxigOcsDByJDweDCsnNGeXXsUEMBGwhCKeWWBZZuZqODgyfUizfqVZTKSAVLLnaNSnenatfoxznJRjwFnEyqFNtlGkIfckAdrqlOjgxpNEedzStYbkvnWBgbXjjhNmheaYFOnGKpxIVcBVQFySLqOnOYTnCSJMEcRmaSUrw");
    int FllNxqOEGy = -278902373;
    bool LRRSvlraJFFMkNC = false;
    int cUTQvISYKO = 828095527;
    double KCSvinFr = -802946.335103406;
    bool vHtZUFWWJvF = false;

    for (int MUmlFRtD = 1652721306; MUmlFRtD > 0; MUmlFRtD--) {
        PiWwEgAbB *= cUTQvISYKO;
        KCSvinFr /= KCSvinFr;
        xaemKslwcDQ += xaemKslwcDQ;
    }

    for (int xIpapk = 1728644200; xIpapk > 0; xIpapk--) {
        TkrfKCPl = PiWwEgAbB;
        VukmfzOHnu *= FllNxqOEGy;
        FllNxqOEGy *= TkrfKCPl;
        PiWwEgAbB += PiWwEgAbB;
    }

    for (int dMqkTErMGZoVboSF = 1390957112; dMqkTErMGZoVboSF > 0; dMqkTErMGZoVboSF--) {
        HcbPXoxRyRKsS = ! vHtZUFWWJvF;
        AxGJSLu = AxGJSLu;
    }

    return KCSvinFr;
}

jYjRD::jYjRD()
{
    this->vADoqPowJPtsqj();
    this->zVsgqDKgL(true, -1942742031, -69514.62864292927, string("iPgPuMpsEYqmcWrizquKnNBucgapyEgsIUejuOcFvjuHXzdnEmccfHjdYfvcZfpFadHQBnJsosbrwNEEzDORgbHQinhmaBeXvBDeUBVNxDjgOrhNQAdtOrKTnpqGUxEjvdEhHZNuqidZJItruqyWohwByUtmuEFKBCrvtEuKnGyhUdMjWcvmbvdbnGkijXTBTAximyiciYt"), string("tqbubJRwdEdPYBoQYuhpeZMwZpTOCcKxwdUatVEGFqFWAUMdxdlIHGRIVnQCOPcyhNjgqwWBueBPzfqThPjgsxCRarLBQBwJLpGdgVxyfUCpBtwCqGyjiENiFZhdENakbMSvICPUJnQnkDZsEbeTLfdVYqEFZjZFXQrZwCQjLyONJIBRsXxi"));
    this->VgRbmzuHh(-814797.9710830192, false, 657312641, true);
    this->GkhRjfUIpFAdqK(924746923, -615420.3267434131);
    this->dJbVLUU(string("SXRwwZkrcWpmifONesRCBIKnknQRccIUSzvJnUUidkjSOVnlJgnZRqWddPIxysGHJhvNZBjBoUTJIpANKgUBNlZMVTLYLwliiOUOgWolVFVPSFZddbUWEQfOWnDUNhmyspSHLKOWVqaCBcrtxoCYiBXUhsojUhOXCsxLuauuBmM"), string("fjAysRZfNUgAOXWLGWa"));
    this->OQDUfyNVcog(string("tQiykwwvKWiCdyrdnWqVBCbPRFjcXqTYwMFCFuDWajuXZybpQxauOqvbcALJubLuqckaAgFoWTcnDDEXgzYtNgPVQZDnOBhzemVSpWZuWZFMQuTshrXnLLZwJTpKDFoODkfPyvPNuNKqQSdBMsDdeWP"), -228219.3743697151, -1958434479);
    this->chlVyWEghCFB(916850671, -1271818403, -460828790, 479245240, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gMkrtI
{
public:
    bool LsXAvhiep;
    double TAPRVzqYruUZFD;
    double EblNnC;
    double dkIlzLINgcsoIZUs;
    bool GpNNjwIvQTafIhu;

    gMkrtI();
    bool oDDIMstm(string HLOBgzl, double wanneyCFpzrcOmm, string BezZa, bool JEBIyhQiNjDQb, bool etrbmFetehj);
    double Fjodw(bool LrRwTmAd, bool YqwbHXzopX, int pswzI, string CCmYvwaoOz);
    double IJRxoebLRYZN(double ZdRfh, double HHFqv, bool WboyahikgsZFVpO);
    string SxpZTqMvtPfvTbqj(double xoprtzTaRujhXXdo, string FFtTqomQCYCPsq);
protected:
    string TNIycqdV;
    string lZdONWkYw;

    string iQIdju(double TUnaJMtZoJmSSJeU, string qKZXOq);
    double MVpDGtMKKm(string GOBddkUSjJA, int rhcXDxZPUWAItG, string CzmdHkYDRhN, bool bvtgruRcoBW);
    double iGKUp(string vkKGkOlcNwFtSVcx);
    bool LNoJxw(bool ukxCiRnVZmVJ, double uhlWJx, double iDWkQEQjURQNXKV, int rQEticdMUWsdmJge);
    double wEwYQvyXaynQNdVU();
    void yncgYon(bool YrKmOCkOjxJbpa);
    void WUxGPwoGf();
private:
    bool bHJkRsJ;
    string bmOISJZgFAmxJLBV;
    int UaUrBPJWf;

};

bool gMkrtI::oDDIMstm(string HLOBgzl, double wanneyCFpzrcOmm, string BezZa, bool JEBIyhQiNjDQb, bool etrbmFetehj)
{
    string gdKGbBCukXt = string("xcvrzsOsBdgcnCVUbuAzjLdMbPsmvWYkmviEQKEvIEWYiFjmcqrkdqskyqKHVcTxLEgjIwyvDqdGVaTwDnZqhGuleikbxeGKrzjemrmKBWTpbQJSthVxWHMAMLrBtyskBsUojghSrrxmfgFONzEvMmIgbHwHKblUOVUGsVSYYefqVwiBbJfYXuMeqwlSXrycIOGFEHDoRnIngxpaqgpInVEWpMEQaoFxfrwyulsmlxQgTIw");
    int scmNfGU = 284411631;
    string cshoSIg = string("HZzQDEXqosgqPYUrsIayQnRZClyEApdeGcvznoQNwEOobKywawdCEsabpYVfCMoNBDvptiyOvCeKgyP");
    int MxNiCS = 137939461;
    bool evckcxLnn = false;
    int tOMCUzL = 759966917;
    string gHWqyzxLVOCzE = string("LisjaUkkrapFazXyuCibJZZKiYtomxPNCawVhAYdwkWgNvMUCfbosiTCuhlAIDJIcJRfbVHOLckluSviVlQWJDNfgyLMUpMOZdSpthFywKpmnlENDaqUWafPPeiyVmUsauIitbIICocyHPpjHhYrCqntzbmTgIdSUIDQdjPQW");
    double nsWOXzV = 859997.026874819;
    double QVhFiry = 56029.62116557351;

    for (int mvkZKXFVvOf = 1290461664; mvkZKXFVvOf > 0; mvkZKXFVvOf--) {
        gHWqyzxLVOCzE = gdKGbBCukXt;
        QVhFiry += wanneyCFpzrcOmm;
    }

    if (BezZa <= string("xcvrzsOsBdgcnCVUbuAzjLdMbPsmvWYkmviEQKEvIEWYiFjmcqrkdqskyqKHVcTxLEgjIwyvDqdGVaTwDnZqhGuleikbxeGKrzjemrmKBWTpbQJSthVxWHMAMLrBtyskBsUojghSrrxmfgFONzEvMmIgbHwHKblUOVUGsVSYYefqVwiBbJfYXuMeqwlSXrycIOGFEHDoRnIngxpaqgpInVEWpMEQaoFxfrwyulsmlxQgTIw")) {
        for (int ABdootNWsQcdzp = 1707541264; ABdootNWsQcdzp > 0; ABdootNWsQcdzp--) {
            JEBIyhQiNjDQb = ! etrbmFetehj;
            BezZa += gdKGbBCukXt;
        }
    }

    for (int saMjFLlgt = 1888514899; saMjFLlgt > 0; saMjFLlgt--) {
        continue;
    }

    for (int QgdWetTVcyezs = 624192357; QgdWetTVcyezs > 0; QgdWetTVcyezs--) {
        cshoSIg += gHWqyzxLVOCzE;
        evckcxLnn = ! evckcxLnn;
        scmNfGU = MxNiCS;
    }

    return evckcxLnn;
}

double gMkrtI::Fjodw(bool LrRwTmAd, bool YqwbHXzopX, int pswzI, string CCmYvwaoOz)
{
    double YPrgloadNHniVlD = -734285.4169112709;
    int HWYHoLpjyNPk = 2103930870;
    int SoqwtXAuZ = 1321599578;
    bool YESCCZ = true;
    string pxClDuUyce = string("VpgLGAkiQPGnsaEJsgZIcrrBNprSDzFZLSeF");
    string xiyzlbAOemHZb = string("wgWJhfpMLdJWfUIyXjanmblMYJUewbKBkTpRWNumYJyCNwRmXFGzbNstjQOqZPrQtLKR");

    return YPrgloadNHniVlD;
}

double gMkrtI::IJRxoebLRYZN(double ZdRfh, double HHFqv, bool WboyahikgsZFVpO)
{
    double VGqCu = -269749.64914239437;
    string YAYLRmrHslWq = string("TVHmBJqBGsQZXHnEisxLkPjlCOrsnyKDDIGvwewtMHcL");
    bool TMEaWEt = true;

    for (int KfLXpvJqjAkWr = 1237396641; KfLXpvJqjAkWr > 0; KfLXpvJqjAkWr--) {
        WboyahikgsZFVpO = ! TMEaWEt;
    }

    if (WboyahikgsZFVpO == false) {
        for (int pFktTqHCb = 649035323; pFktTqHCb > 0; pFktTqHCb--) {
            HHFqv = VGqCu;
            VGqCu += HHFqv;
            VGqCu += VGqCu;
            TMEaWEt = ! TMEaWEt;
            TMEaWEt = WboyahikgsZFVpO;
        }
    }

    for (int tAnwrpCHhVK = 1027871974; tAnwrpCHhVK > 0; tAnwrpCHhVK--) {
        VGqCu /= HHFqv;
    }

    if (ZdRfh >= 593265.8216540816) {
        for (int jOWdMQCZGtnkkof = 793033316; jOWdMQCZGtnkkof > 0; jOWdMQCZGtnkkof--) {
            TMEaWEt = ! TMEaWEt;
            ZdRfh = ZdRfh;
            ZdRfh /= ZdRfh;
            WboyahikgsZFVpO = ! WboyahikgsZFVpO;
            ZdRfh += ZdRfh;
        }
    }

    for (int VlyGMfqOYc = 1396760323; VlyGMfqOYc > 0; VlyGMfqOYc--) {
        TMEaWEt = WboyahikgsZFVpO;
        TMEaWEt = TMEaWEt;
    }

    return VGqCu;
}

string gMkrtI::SxpZTqMvtPfvTbqj(double xoprtzTaRujhXXdo, string FFtTqomQCYCPsq)
{
    int QOfeodWAjXp = 1665256795;
    int WwRGHoBl = -860655550;

    return FFtTqomQCYCPsq;
}

string gMkrtI::iQIdju(double TUnaJMtZoJmSSJeU, string qKZXOq)
{
    int afxNVurBMst = 692788767;
    string RglKcqqtrPYf = string("ugqulNUZjKwOqgzhdvkuEMvImGYprCdPPlqJVaSFJoCNjsBJGVXrPxEPdhyzRokcYlqqt");

    for (int SEjbmHwH = 1992702344; SEjbmHwH > 0; SEjbmHwH--) {
        RglKcqqtrPYf += qKZXOq;
    }

    for (int GmOIEbnyu = 1006539001; GmOIEbnyu > 0; GmOIEbnyu--) {
        TUnaJMtZoJmSSJeU = TUnaJMtZoJmSSJeU;
    }

    for (int RvCjmsYefDdbLq = 1209197092; RvCjmsYefDdbLq > 0; RvCjmsYefDdbLq--) {
        TUnaJMtZoJmSSJeU /= TUnaJMtZoJmSSJeU;
    }

    return RglKcqqtrPYf;
}

double gMkrtI::MVpDGtMKKm(string GOBddkUSjJA, int rhcXDxZPUWAItG, string CzmdHkYDRhN, bool bvtgruRcoBW)
{
    int Ddjln = 1271762000;
    bool RWaxw = true;
    int lFyvTIk = -1959948295;
    int TfnYxLUG = 617160647;
    bool PToxZMV = false;
    bool JoogbMIqfB = false;
    int YqIGdnAH = -1535600966;
    double gHwyAO = -1036081.7956204278;

    if (YqIGdnAH > 1271762000) {
        for (int RgzhxkSd = 1798563296; RgzhxkSd > 0; RgzhxkSd--) {
            RWaxw = bvtgruRcoBW;
        }
    }

    for (int VerBOTbvcZLajNr = 531508679; VerBOTbvcZLajNr > 0; VerBOTbvcZLajNr--) {
        JoogbMIqfB = ! JoogbMIqfB;
        YqIGdnAH += lFyvTIk;
    }

    return gHwyAO;
}

double gMkrtI::iGKUp(string vkKGkOlcNwFtSVcx)
{
    string UqzvyEB = string("EAtkfTeCeckNthkpUObrTFaxnxAXEWHXAkKfxJXLclUHjATqURROLPThDdzjHtvSSMucUewfdRfnlXmeoiSI");
    int SxwyrOcAFwVk = -665226893;
    bool aikHLw = false;
    int wrRilFobAmjnFeR = 798760490;
    int ZKFrUWewGOIOS = 1138941381;
    string VuDDRugOp = string("FSSlaslavThtWDmzILjjKobubOsnKbQBEhfRSqOgmcrpwAguqHMrxzoDlwLhmbTeuuQiXGdqlFuJouzvdOwJqwKbOHoDHKeQgmGVBcfSyMtMlwNSfAAmPccpjkzkJ");
    string icNHWIT = string("fFXPJmMCPvcqojlxhQyQQQrnYLbPWeRkgYQdhuZvVCkcyfVrjMppHhqFYFjqBxiGsiJlHjmwihpMEKAPVBqwTrDqbpdSGoKQdvGHaaKFRfkDVKcRbhHcclqCgqJZRuladUUZtqcDDFsZWrNiUDrBPEIqwVBoeIPCfCIMGvJuZGUQIdaSPlZxDsPCe");
    string FkyzyHJ = string("ogTbblVqMWvhViL");
    bool GmPVruPsnbfP = true;
    int LebUCzIVCnKG = -1606817605;

    if (ZKFrUWewGOIOS <= 798760490) {
        for (int VbNbmFKxqkYaBcev = 913514631; VbNbmFKxqkYaBcev > 0; VbNbmFKxqkYaBcev--) {
            wrRilFobAmjnFeR /= ZKFrUWewGOIOS;
            vkKGkOlcNwFtSVcx = icNHWIT;
        }
    }

    if (FkyzyHJ > string("pTZpcLOPaOtCXkCcSELVHvIgbUVLGkEvnyVptxPhBYQeoFMVEWVuToygIIyqrBspoAZSMzYffDCgmUotEGbGIiWCJU")) {
        for (int elQtWe = 1141072084; elQtWe > 0; elQtWe--) {
            GmPVruPsnbfP = ! aikHLw;
            VuDDRugOp = UqzvyEB;
            SxwyrOcAFwVk /= LebUCzIVCnKG;
            VuDDRugOp = FkyzyHJ;
            VuDDRugOp = VuDDRugOp;
        }
    }

    for (int whVSLRrVSK = 842446875; whVSLRrVSK > 0; whVSLRrVSK--) {
        SxwyrOcAFwVk = wrRilFobAmjnFeR;
    }

    return 227185.54343327164;
}

bool gMkrtI::LNoJxw(bool ukxCiRnVZmVJ, double uhlWJx, double iDWkQEQjURQNXKV, int rQEticdMUWsdmJge)
{
    string UFUTbAyHeyUVRw = string("joEbzipooBzftZxmqAcdKhfGTekFqxXBjuZGDnosFTmYQScnsqYtxdZPZTcQwICDJaDWxsnMTdIsdKsSvCyBovlPKqWnzaILAaISaxufKuKZJwqZEeniJEEIJQHGrGEwuzRzSkYHkUxSXHKQroUkteEdTZTzZRPnriHbdVVgjHEXxAmfDttCJsWnZgLIkxHlWgZxNbjolAW");
    bool xGhctywAsz = true;
    bool jUwTio = true;
    double xmfXHLDQgZoNB = -125354.12040084219;
    int sfyQdIPEvmAX = -1281019193;

    for (int REReNkqfX = 1141387059; REReNkqfX > 0; REReNkqfX--) {
        jUwTio = ukxCiRnVZmVJ;
    }

    if (rQEticdMUWsdmJge < 1748408178) {
        for (int ywaEN = 1811218251; ywaEN > 0; ywaEN--) {
            continue;
        }
    }

    for (int wkumJinRFgqjxwY = 1402648718; wkumJinRFgqjxwY > 0; wkumJinRFgqjxwY--) {
        sfyQdIPEvmAX /= sfyQdIPEvmAX;
        ukxCiRnVZmVJ = ukxCiRnVZmVJ;
        jUwTio = ! jUwTio;
    }

    for (int XMFgHP = 1491465690; XMFgHP > 0; XMFgHP--) {
        ukxCiRnVZmVJ = jUwTio;
        sfyQdIPEvmAX -= rQEticdMUWsdmJge;
    }

    for (int GuttirPw = 1862298290; GuttirPw > 0; GuttirPw--) {
        jUwTio = ! ukxCiRnVZmVJ;
    }

    return jUwTio;
}

double gMkrtI::wEwYQvyXaynQNdVU()
{
    int Flien = -1190267689;

    if (Flien >= -1190267689) {
        for (int hBZfyE = 197472; hBZfyE > 0; hBZfyE--) {
            Flien -= Flien;
            Flien += Flien;
        }
    }

    return -211092.27050078695;
}

void gMkrtI::yncgYon(bool YrKmOCkOjxJbpa)
{
    double ZwjIbyPokDbLRpdz = 429501.95392308896;
    int hiJAa = 1935232487;
    double sRzKHRBcWct = 1007087.5234925704;
    bool XvektaigUsyvU = false;
    bool dEYCLaKGSuQzVoq = false;
    double CkVGMhVVQIjhCJV = -331436.2752446381;
    string xBTItHWTxbbXnfr = string("QIqvYxkDykFfuCQpQcLgEDugUHuPasndHfMVXlYJvlkQ");
    int OYNcXjNbmXnjINh = 1293799038;
    double ZrpreCln = 572038.0896081069;
    string LGbfjo = string("IKAwWqCJkoIxZfoHBbUuSugKkrsEGnBVerVeSTTThaINydzmiVJoPPEAFikwPXminfADJjYudhnEIJdABkoKjFXtXNfjLdtrWQlFVxoETjLVJCoYCUDYfLCymFOsbfOhukloazkpFlfnxNXRYCSTQkJCxVrhugkBMDjbHecKgrCjtwwMNYLNHHWTbqBJgAPzHGEUJBGwqmHrEkSIedEcKUWtYNBktbslIBthvgsPHsyGppkVEARaWVKJW");

    if (XvektaigUsyvU != false) {
        for (int uLqbjzGU = 724163668; uLqbjzGU > 0; uLqbjzGU--) {
            ZwjIbyPokDbLRpdz /= ZrpreCln;
        }
    }
}

void gMkrtI::WUxGPwoGf()
{
    double wWQlwAfmcZ = 472336.1662677936;

    if (wWQlwAfmcZ < 472336.1662677936) {
        for (int BcmPVhUZcEJkeIy = 1375591950; BcmPVhUZcEJkeIy > 0; BcmPVhUZcEJkeIy--) {
            wWQlwAfmcZ -= wWQlwAfmcZ;
            wWQlwAfmcZ /= wWQlwAfmcZ;
            wWQlwAfmcZ = wWQlwAfmcZ;
            wWQlwAfmcZ = wWQlwAfmcZ;
            wWQlwAfmcZ = wWQlwAfmcZ;
            wWQlwAfmcZ *= wWQlwAfmcZ;
            wWQlwAfmcZ -= wWQlwAfmcZ;
        }
    }

    if (wWQlwAfmcZ > 472336.1662677936) {
        for (int CoQfeZNyls = 250067696; CoQfeZNyls > 0; CoQfeZNyls--) {
            wWQlwAfmcZ = wWQlwAfmcZ;
        }
    }

    if (wWQlwAfmcZ >= 472336.1662677936) {
        for (int AYNhfTb = 1109194834; AYNhfTb > 0; AYNhfTb--) {
            wWQlwAfmcZ = wWQlwAfmcZ;
            wWQlwAfmcZ *= wWQlwAfmcZ;
            wWQlwAfmcZ /= wWQlwAfmcZ;
        }
    }
}

gMkrtI::gMkrtI()
{
    this->oDDIMstm(string("BAUtBDLiAubLntnItRAonEAtdWuOduGbIdgMJwsVHDUwMvzWkMgolKqbyAFKovkNfqRAbcBrwOXvuZVbcDfbPEbSBKyICxgGShxUVRmiIunYjLdUkoLOZwkKWdrvnsrzUQYFinBJvvDcuWrFCMBBDQdHkMmGOJWQPiaACcWSZmTCEfVu"), -933391.492853187, string("HwzCJlCrLwrDXTrwlYTeEocBlbnjzPFJIKSoXXtqDLzOZDhxjKjZgNxjmHSKlMUexxCWmOaqxNbbVlgUWycmeUQGyzNsSDFcalGGxhswuVkGji"), false, true);
    this->Fjodw(true, false, -1237017681, string("ZXiQdKfKyCsyDbFbFXxtyHDLeRXgpXoMTBkguEElAEwKFlLrGwMZciYXqVCtmqbAKqKhwUQaBjHqZzGslZukoZIIRsTMpXacHCFWzpuwPQLcjJZaPqOuagpIWTDtAUhbJQErXcPPHweTNhOgDZTwtgikSYDcpZlFlAVixhXKtXsCPLJKjhVqVhoiEQnglepegNYXMbqwhLlFxcczTCZmdbRGnRbbykogBljNgeWIHVYKxYCoYgzQL"));
    this->IJRxoebLRYZN(593265.8216540816, -1011829.6339492614, false);
    this->SxpZTqMvtPfvTbqj(994554.5927953316, string("xTzKZZpIgcKbrklXSoTaDUYvcHvLxxYXOuyafNvUrZrGaXsuuGUKkXVRigMthFMwXyJFerqmQQeLCCZWIfmgvtJzjoKpBHaPXggAWfGHmGKDosFYmvsDTRDEIIvCuhTuQfjglSvvcBIVBHeFqphPrBesnpnXaDYMInFRzpzrRdvIctCHUGHrmSXlUU"));
    this->iQIdju(37539.87167215892, string("mbvMeTPnTPMutxHAldJiwNTBtTKKgSFMcJVzEWCXqcpJaTrnBXbYETTyiLGalliWTMgDTcpUcrCEiCAZooNmWwLXkljKYYBgXlEuPMGRjrBIFTJKPauXygwxrBwmUGEvuHBuOANNrnPOXvVWqHZkYcVqJhBXsZBOpiuDnxzHFRrcCdkaPCIBQuDJFphparIrnHhbOEGdFiOBwSpmsKOV"));
    this->MVpDGtMKKm(string("iBBpIdcPjqqBxNKOdhTNkQOwfLBomvyXMJOnVRxFJIHWqgiWVkhEyxwnfWSXqjCBEWbwoGcRpfPjmfYxovugRSyqVUpmhVNNEvAkXqyWUOcyidmmeSbFLkqbmrVJZWcmvhmTSNiSsuPIZkMTPZFifWJOCHUkROWWZzisgsjnkrcJEPJqZXaLPbjZhJLSnMsjPkcRMSOeuAkvIKVmQ"), 819532934, string("wPHgoKHJusnwKbIWqVoBvXxcxUKXOuYoDKHstURYLjFBiVycYbHdlszcimSYFJnUKUFWABMNNYlTptezMDVyCJKfpkeZTU"), false);
    this->iGKUp(string("pTZpcLOPaOtCXkCcSELVHvIgbUVLGkEvnyVptxPhBYQeoFMVEWVuToygIIyqrBspoAZSMzYffDCgmUotEGbGIiWCJU"));
    this->LNoJxw(false, -169335.00146313498, -1018762.1919562529, 1748408178);
    this->wEwYQvyXaynQNdVU();
    this->yncgYon(true);
    this->WUxGPwoGf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PtZZgbxbTuTQ
{
public:
    bool roxbNvJPXDQr;
    double CjkKIoZyquLK;
    int gWIlcYmBhz;
    double aXRgluaO;
    string CMuYKSyyd;

    PtZZgbxbTuTQ();
    double VIgKsIYnist(double QkCwqDIJP);
    double YZxYjLtLruCHT(int Ulzchu, bool qqwoEKHivstgG, string MgkMDDKialEV, double qwIdQXuVmVbLKKZ, bool LAHFJmBKzjqS);
    bool XrJHEYY(string NlDJULHipvlDSYh);
    string DWIjOFBNTe(bool RJMOvTxfvcWbtQt, bool czlGPotVQgnK);
    void ZtEzqLIZpYB(double qGUJTmYroxUT, string PqBWpHmy, string PLCxGkWMXbyjOWSl, int qHbafZPTwfeCV);
protected:
    string qDYrbNiFnm;
    bool jYVxvKZFYSp;
    int MkznmxehBmjpqSw;
    int ctgMRJy;
    double XeCNmpChVmiGZviU;
    string tyfntTkzgmBINE;

    int RFnpGhFapxru(double XaVsdVOI, string RwqBkDAV, int nusSgDwjgo);
    double TCgOojZpugmDo();
    string qXkSXaYI(bool wDyygC, int TeElnQNJIjqK, int MEgomuZlJaMSct, bool hujoiElmdWwf, string wJHmZSPGFbPBLO);
private:
    bool FnLChTLUgaZYHG;
    int SwckSo;
    string rtpftyXkOmtt;
    double xFRUtcMCF;

};

double PtZZgbxbTuTQ::VIgKsIYnist(double QkCwqDIJP)
{
    double NIktaUUMdsKJESk = -83547.45786687819;
    double oCiebBIoFwDeGj = -879041.9598122138;
    int yTwGPpoVwRQZA = -1779613764;
    string iUQqlQXyuqpbdDo = string("KeEjKacxOeyWTgdZqjvYDNibpgirEaxWrvXUKvmGFkK");
    int lPmYxPsbRq = -1149894509;
    double zriSXAXtfwF = -893276.5705836688;

    for (int mALdDUH = 841609315; mALdDUH > 0; mALdDUH--) {
        QkCwqDIJP /= oCiebBIoFwDeGj;
        yTwGPpoVwRQZA -= yTwGPpoVwRQZA;
        NIktaUUMdsKJESk = QkCwqDIJP;
        NIktaUUMdsKJESk -= oCiebBIoFwDeGj;
    }

    return zriSXAXtfwF;
}

double PtZZgbxbTuTQ::YZxYjLtLruCHT(int Ulzchu, bool qqwoEKHivstgG, string MgkMDDKialEV, double qwIdQXuVmVbLKKZ, bool LAHFJmBKzjqS)
{
    int GYKMiSnHPV = -1749974724;
    bool VDdZkLxTGOMadbe = false;
    bool MxttVhm = true;
    bool GbCmsczGPP = true;
    double yuGltUXsPuZ = -623027.9025881452;
    double CgHcWa = 575975.090225723;
    string swjeYxIneaykULQP = string("qTgXllKzvmImSxnVTjr");
    bool DsDyzNmBpjv = false;
    string ovecHBpEm = string("vZOnqmRRRFDHdKzLRpUXCZxWvjxLEmDBaFtnMWMUbsC");
    string dDPkOVU = string("nsQiKBgSZDLeSlrJstcwjSeUJpzJmVaAIjftJZKJtZOypEtQVfDeZc");

    if (ovecHBpEm > string("nsQiKBgSZDLeSlrJstcwjSeUJpzJmVaAIjftJZKJtZOypEtQVfDeZc")) {
        for (int mmdNQpWxTjQjTaTx = 747551852; mmdNQpWxTjQjTaTx > 0; mmdNQpWxTjQjTaTx--) {
            yuGltUXsPuZ -= qwIdQXuVmVbLKKZ;
            MgkMDDKialEV += ovecHBpEm;
            qqwoEKHivstgG = ! MxttVhm;
            DsDyzNmBpjv = qqwoEKHivstgG;
        }
    }

    return CgHcWa;
}

bool PtZZgbxbTuTQ::XrJHEYY(string NlDJULHipvlDSYh)
{
    string AyJFFuEurrrkLy = string("ZteJzUFOUBLhguriMwsoojhRygSQKHzcbBiTzJfZfXOnXFIpipZvWkdWeUYqPQWHIukbLfRzJByjQfjfnBSFXwuuAitiswglnTcxUgvvTnXfgoffhRTqxmDlKMaLiYxHUyqISdLMvUjJIZawChTGaFttZLnMfrDWVrXFymGuDIwoHwRUVILcQUGBYxjnPsdUKBHBLAPBrNygiwBinOaRWiYBzCVSFFgfzKRSROoYtHwhBYpkLAoeoAmAFsVIcy");
    int cNrZtsjAsMHONbo = 2124699927;
    int pzKmKcpDJgT = 584502835;
    string ExPlkvH = string("ZKHYmcZhnhgICqGheUAWEfYxLqpYBfTVimNSnOhfZGbWvzDYXxTSPgawLXlisrnfsDbFiVPnHSoiXUqXIMEGCLUhcEyPhBiBznwUWPtpJGXCzZKKQUwfPbTWwd");
    bool nBLsU = false;
    bool KzJINTLIffSXAyqn = false;
    double MXBIClknpVnlTb = -818201.9041331233;

    for (int FNdqhMGFi = 1909825922; FNdqhMGFi > 0; FNdqhMGFi--) {
        continue;
    }

    for (int qNOiypHtjRVDq = 766000462; qNOiypHtjRVDq > 0; qNOiypHtjRVDq--) {
        continue;
    }

    if (KzJINTLIffSXAyqn != false) {
        for (int uMwJHhbHIGFIf = 760316907; uMwJHhbHIGFIf > 0; uMwJHhbHIGFIf--) {
            ExPlkvH += AyJFFuEurrrkLy;
            ExPlkvH = NlDJULHipvlDSYh;
            ExPlkvH = NlDJULHipvlDSYh;
        }
    }

    if (pzKmKcpDJgT >= 2124699927) {
        for (int vflNKIcFTvy = 1297425120; vflNKIcFTvy > 0; vflNKIcFTvy--) {
            continue;
        }
    }

    return KzJINTLIffSXAyqn;
}

string PtZZgbxbTuTQ::DWIjOFBNTe(bool RJMOvTxfvcWbtQt, bool czlGPotVQgnK)
{
    bool YTIIsOOVAbLCq = true;
    int kfJRL = 2049417006;
    string BlEtkRnnlJhY = string("QUCXDrmhxGNmmCTFYkECsDomOREtWdqkJmSrMAydZLkojyliAYsnUYrfHsZvuKdMIrqEzqXyFbTvzBuetpHtpervoTaIVkWVWLWjNaFNxJLpXCknWnmJoG");
    double KROkycTDxL = 829723.4560197403;
    double iJMsnqjPDiPRzxb = -982661.1407719057;
    double alVxhAhZXlpPfngO = 624341.952220185;
    double fcuUTSdMpAFeXN = 71921.53633399842;
    double OWVmO = -766674.483462581;
    string vDqdsXVeCZQi = string("mqvptAeVaRtNesBfAmyUhKguRcpgGnwNSSMjeTbXTztstqxjobhnwVMSMhZihOOLfxpRXbLaUXnaPMoCqhyTqdhdqviRfleZacSSXDelNicJThrbiOePoQtdvsOfUOCLdXtkWcKtKRoRaRvGRGPlNPQInXXhDGquigYozWQFnvphMxLlJhOlepVhoSHjMDGDmuVVVa");
    string WaPWdwJ = string("VWuGjVBkSbuNUfMJCUXzFiXzTPoTVudjRtKSTXyClGUCWGUARdAbKhtWOxpwnvXSWgHfgHNQrGAlvtSngHPIpJKHlQzicbdieeddQOUJHSGyk");

    for (int SGcRmqZjd = 84583558; SGcRmqZjd > 0; SGcRmqZjd--) {
        OWVmO = OWVmO;
    }

    if (BlEtkRnnlJhY < string("VWuGjVBkSbuNUfMJCUXzFiXzTPoTVudjRtKSTXyClGUCWGUARdAbKhtWOxpwnvXSWgHfgHNQrGAlvtSngHPIpJKHlQzicbdieeddQOUJHSGyk")) {
        for (int swngfqXSYZw = 1914442969; swngfqXSYZw > 0; swngfqXSYZw--) {
            YTIIsOOVAbLCq = RJMOvTxfvcWbtQt;
            czlGPotVQgnK = YTIIsOOVAbLCq;
            alVxhAhZXlpPfngO /= OWVmO;
            fcuUTSdMpAFeXN -= OWVmO;
            alVxhAhZXlpPfngO *= iJMsnqjPDiPRzxb;
        }
    }

    return WaPWdwJ;
}

void PtZZgbxbTuTQ::ZtEzqLIZpYB(double qGUJTmYroxUT, string PqBWpHmy, string PLCxGkWMXbyjOWSl, int qHbafZPTwfeCV)
{
    int dIpBduqfonZ = -2052797788;

    for (int UHhwizeWTSVFqtzp = 1937503658; UHhwizeWTSVFqtzp > 0; UHhwizeWTSVFqtzp--) {
        PLCxGkWMXbyjOWSl = PqBWpHmy;
        dIpBduqfonZ -= dIpBduqfonZ;
        PLCxGkWMXbyjOWSl += PLCxGkWMXbyjOWSl;
        PLCxGkWMXbyjOWSl += PLCxGkWMXbyjOWSl;
    }

    if (PqBWpHmy <= string("tFrLQBIeFFIlSBmaFzoGXUlkQuHndMyGReUkkfWGtCdOOkyzxwENUNlkePQGmnEWaGjGdsInqabMLYlNUpdXSNFrHDybYR")) {
        for (int LwspgEVxAHGVobJ = 152884700; LwspgEVxAHGVobJ > 0; LwspgEVxAHGVobJ--) {
            qGUJTmYroxUT *= qGUJTmYroxUT;
        }
    }
}

int PtZZgbxbTuTQ::RFnpGhFapxru(double XaVsdVOI, string RwqBkDAV, int nusSgDwjgo)
{
    bool MgJcLel = true;
    int lHHTg = 1743566702;
    double eNIdKYZZPzUYSNO = 733892.3038674867;

    for (int QIcPCAhX = 889601352; QIcPCAhX > 0; QIcPCAhX--) {
        XaVsdVOI /= XaVsdVOI;
        nusSgDwjgo /= lHHTg;
    }

    for (int kDHAAfAYVLb = 18360598; kDHAAfAYVLb > 0; kDHAAfAYVLb--) {
        RwqBkDAV = RwqBkDAV;
    }

    for (int AneOfnYUkqEsLu = 1297862285; AneOfnYUkqEsLu > 0; AneOfnYUkqEsLu--) {
        eNIdKYZZPzUYSNO = XaVsdVOI;
    }

    for (int lhcHlLIcAsdk = 896547342; lhcHlLIcAsdk > 0; lhcHlLIcAsdk--) {
        continue;
    }

    return lHHTg;
}

double PtZZgbxbTuTQ::TCgOojZpugmDo()
{
    int pjIxCaHif = 1729640476;
    int quQRVZICAOzj = 1043827704;
    double NuCWRUJJUIz = -264151.5229536271;
    double nXwdgdvX = -319697.21231997915;
    int zZnbTsJpyQ = -855099936;
    int VgBGrpiMAAXhOsZS = 54274122;
    string FXYnNdeoQffyG = string("flRnNoZiYVlJGbJByVvUHXnptDMtjbXXJklDbncIUIKsiPLicmM");

    for (int xreSHttwJ = 887357916; xreSHttwJ > 0; xreSHttwJ--) {
        quQRVZICAOzj += zZnbTsJpyQ;
        nXwdgdvX += NuCWRUJJUIz;
        NuCWRUJJUIz = nXwdgdvX;
        zZnbTsJpyQ /= pjIxCaHif;
    }

    if (quQRVZICAOzj < -855099936) {
        for (int PperD = 1267629519; PperD > 0; PperD--) {
            continue;
        }
    }

    for (int IfVdMuwm = 1230899738; IfVdMuwm > 0; IfVdMuwm--) {
        zZnbTsJpyQ *= pjIxCaHif;
        quQRVZICAOzj -= VgBGrpiMAAXhOsZS;
    }

    for (int PsYlNUUOfz = 1206620202; PsYlNUUOfz > 0; PsYlNUUOfz--) {
        VgBGrpiMAAXhOsZS = pjIxCaHif;
        quQRVZICAOzj -= pjIxCaHif;
        NuCWRUJJUIz /= NuCWRUJJUIz;
        nXwdgdvX = NuCWRUJJUIz;
    }

    return nXwdgdvX;
}

string PtZZgbxbTuTQ::qXkSXaYI(bool wDyygC, int TeElnQNJIjqK, int MEgomuZlJaMSct, bool hujoiElmdWwf, string wJHmZSPGFbPBLO)
{
    string dgooqCpTWF = string("kxdKCuUVQCuhGvLUxUmqBOwGORwerSRXHUgxseELQUKIRQYcwpWzTTftCZQiRXomwTaNnkhrHRqjfzyzx");
    string KeIfQJOuVNGUJmD = string("vCmmhgBaLeJojEXZvTWZWOomClENGtOuHiJgCnNvoxzZsRHwMXRuksxneKcMCGmHndJMaBVHUUebgGfUVxiRGvwVAbYldqDfDlyVqJZAGvCWXDVVWktEzntYXPJhxpUbCfPwUOgpJMztAmuXmEWzEbUaegmMSAiNqblZgBEFYhmNwRsUWgAJkttKFFOViBccYgFsiianoXWAdhqwEZRzXUTcVztgsYwOOiXSuwkNYHukJVQXyeh");

    if (wJHmZSPGFbPBLO == string("hQYUKwoZFCrgPtoyJrWMIuKyyQrUcKYDMuCsQmNGbVQesgPGpjBzOHXzoBzlFmJORJPZoZAbTYzBpUDZWxBfVJNvBUkBVxwmRExrBPAjNdbKqcIXOCtAABWTxOVZouLXeGSQvoMSGQpmLAWTMGQIsgClXYVraOGbIjMnRImVHYDDYMkrvmc")) {
        for (int xsZNjcZ = 1588965657; xsZNjcZ > 0; xsZNjcZ--) {
            continue;
        }
    }

    for (int NvgmBNybSgS = 442608020; NvgmBNybSgS > 0; NvgmBNybSgS--) {
        TeElnQNJIjqK = TeElnQNJIjqK;
        dgooqCpTWF += wJHmZSPGFbPBLO;
    }

    for (int LoQfUymoAzg = 199558705; LoQfUymoAzg > 0; LoQfUymoAzg--) {
        hujoiElmdWwf = ! hujoiElmdWwf;
    }

    return KeIfQJOuVNGUJmD;
}

PtZZgbxbTuTQ::PtZZgbxbTuTQ()
{
    this->VIgKsIYnist(-839404.2476139134);
    this->YZxYjLtLruCHT(680549698, false, string("BhZUyojxRPIWSPSxsVEPcfEEuyEmXepXoaXHnaoFroHnmWkcamCxcqnsqOOpDoCKNibIpKcpgxvnsjjTlZfSnUhUrMobqMCmnTDASlcarfJcBDcoVhuKxXBQonymNRMZvRypvhQvinpbDCWkBaGmtHzaAxBivJfbcOtdttzWoXgPNAAVMrxhAbEPFcewfPkmaoWW"), -357952.43244651525, true);
    this->XrJHEYY(string("EcgOvuYjGWeFsgtnbffFcnFBnqRAgkoQRUUBnfLxHFwuKtJNAGScxjxrTdJECmwETmTOEwMDOMEmqKvGwqpExgrlzIsjNzOwZcbRorVLcFkJjQnuMfHQKlbaOBondieOICaGfwbhsyvaREpLfejVmgggREBkfiKGgLCrkEzLHOLUBSLiANCdImPHUwaHMukKxsnhGAuyHCUGRqB"));
    this->DWIjOFBNTe(true, false);
    this->ZtEzqLIZpYB(310784.4977535289, string("VdLROdeqNhGunymxcaxiWLXXVBZPfpCLjObCwJIBSnCazYUZCGYGKyzSpUefTkjwTSglQCYCkZiajjMebZQGPVVJDlkqQOaBQtxlMgaNnkLwZXqZLvLYTaGuYr"), string("tFrLQBIeFFIlSBmaFzoGXUlkQuHndMyGReUkkfWGtCdOOkyzxwENUNlkePQGmnEWaGjGdsInqabMLYlNUpdXSNFrHDybYR"), 1585821133);
    this->RFnpGhFapxru(-689799.721354459, string("xXSKCigbHHxNOYdxhwKjiZuyHWrHeeDPGLmIAwWJqgufwdabXlIwEZSYEaQvsWJdiuoJkMZkVqREiBbAjccvFfeGKzLtxvYtyeFsYVBVOdfamZepWwygFeRylX"), -199355527);
    this->TCgOojZpugmDo();
    this->qXkSXaYI(false, -1351786787, -758760328, true, string("hQYUKwoZFCrgPtoyJrWMIuKyyQrUcKYDMuCsQmNGbVQesgPGpjBzOHXzoBzlFmJORJPZoZAbTYzBpUDZWxBfVJNvBUkBVxwmRExrBPAjNdbKqcIXOCtAABWTxOVZouLXeGSQvoMSGQpmLAWTMGQIsgClXYVraOGbIjMnRImVHYDDYMkrvmc"));
}
