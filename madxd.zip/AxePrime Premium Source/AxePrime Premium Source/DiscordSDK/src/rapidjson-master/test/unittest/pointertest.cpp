// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/pointer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/ostreamwrapper.h"
#include <sstream>
#include <map>
#include <algorithm>

using namespace rapidjson;

static const char kJson[] = "{\n"
"    \"foo\":[\"bar\", \"baz\"],\n"
"    \"\" : 0,\n"
"    \"a/b\" : 1,\n"
"    \"c%d\" : 2,\n"
"    \"e^f\" : 3,\n"
"    \"g|h\" : 4,\n"
"    \"i\\\\j\" : 5,\n"
"    \"k\\\"l\" : 6,\n"
"    \" \" : 7,\n"
"    \"m~n\" : 8\n"
"}";

TEST(Pointer, DefaultConstructor) {
    Pointer p;
    EXPECT_TRUE(p.IsValid());
    EXPECT_EQ(0u, p.GetTokenCount());
}

TEST(Pointer, Parse) {
    {
        Pointer p("");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(0u, p.GetTokenCount());
    }

    {
        Pointer p("/");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(0u, p.GetTokens()[0].length);
        EXPECT_STREQ("", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
    }

    {
        Pointer p("/foo");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("foo", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
    }

    #if RAPIDJSON_HAS_STDSTRING
    {
        Pointer p(std::string("/foo"));
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("foo", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
    }
    #endif

    {
        Pointer p("/foo/0");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(2u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("foo", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
        EXPECT_EQ(1u, p.GetTokens()[1].length);
        EXPECT_STREQ("0", p.GetTokens()[1].name);
        EXPECT_EQ(0u, p.GetTokens()[1].index);
    }

    {
        // Unescape ~1
        Pointer p("/a~1b");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("a/b", p.GetTokens()[0].name);
    }

    {
        // Unescape ~0
        Pointer p("/m~0n");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("m~n", p.GetTokens()[0].name);
    }

    {
        // empty name
        Pointer p("/");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(0u, p.GetTokens()[0].length);
        EXPECT_STREQ("", p.GetTokens()[0].name);
    }

    {
        // empty and non-empty name
        Pointer p("//a");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(2u, p.GetTokenCount());
        EXPECT_EQ(0u, p.GetTokens()[0].length);
        EXPECT_STREQ("", p.GetTokens()[0].name);
        EXPECT_EQ(1u, p.GetTokens()[1].length);
        EXPECT_STREQ("a", p.GetTokens()[1].name);
    }

    {
        // Null characters
        Pointer p("/\0\0", 3);
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(2u, p.GetTokens()[0].length);
        EXPECT_EQ('\0', p.GetTokens()[0].name[0]);
        EXPECT_EQ('\0', p.GetTokens()[0].name[1]);
        EXPECT_EQ('\0', p.GetTokens()[0].name[2]);
    }

    {
        // Valid index
        Pointer p("/123");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_STREQ("123", p.GetTokens()[0].name);
        EXPECT_EQ(123u, p.GetTokens()[0].index);
    }

    {
        // Invalid index (with leading zero)
        Pointer p("/01");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_STREQ("01", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
    }

    if (sizeof(SizeType) == 4) {
        // Invalid index (overflow)
        Pointer p("/4294967296");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_STREQ("4294967296", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
    }

    {
        // kPointerParseErrorTokenMustBeginWithSolidus
        Pointer p(" ");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorTokenMustBeginWithSolidus, p.GetParseErrorCode());
        EXPECT_EQ(0u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidEscape
        Pointer p("/~");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidEscape, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidEscape
        Pointer p("/~2");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidEscape, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }
}

TEST(Pointer, Parse_URIFragment) {
    {
        Pointer p("#");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(0u, p.GetTokenCount());
    }

    {
        Pointer p("#/foo");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("foo", p.GetTokens()[0].name);
    }

    {
        Pointer p("#/foo/0");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(2u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("foo", p.GetTokens()[0].name);
        EXPECT_EQ(1u, p.GetTokens()[1].length);
        EXPECT_STREQ("0", p.GetTokens()[1].name);
        EXPECT_EQ(0u, p.GetTokens()[1].index);
    }

    {
        // Unescape ~1
        Pointer p("#/a~1b");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("a/b", p.GetTokens()[0].name);
    }

    {
        // Unescape ~0
        Pointer p("#/m~0n");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(3u, p.GetTokens()[0].length);
        EXPECT_STREQ("m~n", p.GetTokens()[0].name);
    }

    {
        // empty name
        Pointer p("#/");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(0u, p.GetTokens()[0].length);
        EXPECT_STREQ("", p.GetTokens()[0].name);
    }

    {
        // empty and non-empty name
        Pointer p("#//a");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(2u, p.GetTokenCount());
        EXPECT_EQ(0u, p.GetTokens()[0].length);
        EXPECT_STREQ("", p.GetTokens()[0].name);
        EXPECT_EQ(1u, p.GetTokens()[1].length);
        EXPECT_STREQ("a", p.GetTokens()[1].name);
    }

    {
        // Null characters
        Pointer p("#/%00%00");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(2u, p.GetTokens()[0].length);
        EXPECT_EQ('\0', p.GetTokens()[0].name[0]);
        EXPECT_EQ('\0', p.GetTokens()[0].name[1]);
        EXPECT_EQ('\0', p.GetTokens()[0].name[2]);
    }

    {
        // Percentage Escapes
        EXPECT_STREQ("c%d", Pointer("#/c%25d").GetTokens()[0].name);
        EXPECT_STREQ("e^f", Pointer("#/e%5Ef").GetTokens()[0].name);
        EXPECT_STREQ("g|h", Pointer("#/g%7Ch").GetTokens()[0].name);
        EXPECT_STREQ("i\\j", Pointer("#/i%5Cj").GetTokens()[0].name);
        EXPECT_STREQ("k\"l", Pointer("#/k%22l").GetTokens()[0].name);
        EXPECT_STREQ(" ", Pointer("#/%20").GetTokens()[0].name);
    }

    {
        // Valid index
        Pointer p("#/123");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_STREQ("123", p.GetTokens()[0].name);
        EXPECT_EQ(123u, p.GetTokens()[0].index);
    }

    {
        // Invalid index (with leading zero)
        Pointer p("#/01");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_STREQ("01", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
    }

    if (sizeof(SizeType) == 4) {
        // Invalid index (overflow)
        Pointer p("#/4294967296");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_STREQ("4294967296", p.GetTokens()[0].name);
        EXPECT_EQ(kPointerInvalidIndex, p.GetTokens()[0].index);
    }

    {
        // Decode UTF-8 perecent encoding to UTF-8
        Pointer p("#/%C2%A2");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_STREQ("\xC2\xA2", p.GetTokens()[0].name);
    }

    {
        // Decode UTF-8 perecent encoding to UTF-16
        GenericPointer<GenericValue<UTF16<> > > p(L"#/%C2%A2");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(static_cast<UTF16<>::Ch>(0x00A2), p.GetTokens()[0].name[0]);
        EXPECT_EQ(1u, p.GetTokens()[0].length);
    }

    {
        // Decode UTF-8 perecent encoding to UTF-16
        GenericPointer<GenericValue<UTF16<> > > p(L"#/%E2%82%AC");
        EXPECT_TRUE(p.IsValid());
        EXPECT_EQ(1u, p.GetTokenCount());
        EXPECT_EQ(static_cast<UTF16<>::Ch>(0x20AC), p.GetTokens()[0].name[0]);
        EXPECT_EQ(1u, p.GetTokens()[0].length);
    }

    {
        // kPointerParseErrorTokenMustBeginWithSolidus
        Pointer p("# ");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorTokenMustBeginWithSolidus, p.GetParseErrorCode());
        EXPECT_EQ(1u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidEscape
        Pointer p("#/~");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidEscape, p.GetParseErrorCode());
        EXPECT_EQ(3u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidEscape
        Pointer p("#/~2");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidEscape, p.GetParseErrorCode());
        EXPECT_EQ(3u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidPercentEncoding
        Pointer p("#/%");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidPercentEncoding, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidPercentEncoding (invalid hex)
        Pointer p("#/%g0");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidPercentEncoding, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidPercentEncoding (invalid hex)
        Pointer p("#/%0g");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidPercentEncoding, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorInvalidPercentEncoding (incomplete UTF-8 sequence)
        Pointer p("#/%C2");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorInvalidPercentEncoding, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorCharacterMustPercentEncode
        Pointer p("#/ ");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorCharacterMustPercentEncode, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }

    {
        // kPointerParseErrorCharacterMustPercentEncode
        Pointer p("#/\n");
        EXPECT_FALSE(p.IsValid());
        EXPECT_EQ(kPointerParseErrorCharacterMustPercentEncode, p.GetParseErrorCode());
        EXPECT_EQ(2u, p.GetParseErrorOffset());
    }
}

TEST(Pointer, Stringify) {
    // Test by roundtrip
    const char* sources[] = {
        "",
        "/foo",
        "/foo/0",
        "/",
        "/a~1b",
        "/c%d",
        "/e^f",
        "/g|h",
        "/i\\j",
        "/k\"l",
        "/ ",
        "/m~0n",
        "/\xC2\xA2",
        "/\xE2\x82\xAC",
        "/\xF0\x9D\x84\x9E"
    };

    for (size_t i = 0; i < sizeof(sources) / sizeof(sources[0]); i++) {
        Pointer p(sources[i]);
        StringBuffer s;
        EXPECT_TRUE(p.Stringify(s));
        EXPECT_STREQ(sources[i], s.GetString());

        // Stringify to URI fragment
        StringBuffer s2;
        EXPECT_TRUE(p.StringifyUriFragment(s2));
        Pointer p2(s2.GetString(), s2.GetSize());
        EXPECT_TRUE(p2.IsValid());
        EXPECT_TRUE(p == p2);
    }

    {
        // Strigify to URI fragment with an invalid UTF-8 sequence
        Pointer p("/\xC2");
        StringBuffer s;
        EXPECT_FALSE(p.StringifyUriFragment(s));
    }
}

// Construct a Pointer with static tokens, no dynamic allocation involved.
#define NAME(s) { s, static_cast<SizeType>(sizeof(s) / sizeof(s[0]) - 1), kPointerInvalidIndex }
#define INDEX(i) { #i, static_cast<SizeType>(sizeof(#i) - 1), i }

static const Pointer::Token kTokens[] = { NAME("foo"), INDEX(0) }; // equivalent to "/foo/0"

#undef NAME
#undef INDEX

TEST(Pointer, ConstructorWithToken) {
    Pointer p(kTokens, sizeof(kTokens) / sizeof(kTokens[0]));
    EXPECT_TRUE(p.IsValid());
    EXPECT_EQ(2u, p.GetTokenCount());
    EXPECT_EQ(3u, p.GetTokens()[0].length);
    EXPECT_STREQ("foo", p.GetTokens()[0].name);
    EXPECT_EQ(1u, p.GetTokens()[1].length);
    EXPECT_STREQ("0", p.GetTokens()[1].name);
    EXPECT_EQ(0u, p.GetTokens()[1].index);
}

TEST(Pointer, CopyConstructor) {
    {
        CrtAllocator allocator;
        Pointer p("/foo/0", &allocator);
        Pointer q(p);
        EXPECT_TRUE(q.IsValid());
        EXPECT_EQ(2u, q.GetTokenCount());
        EXPECT_EQ(3u, q.GetTokens()[0].length);
        EXPECT_STREQ("foo", q.GetTokens()[0].name);
        EXPECT_EQ(1u, q.GetTokens()[1].length);
        EXPECT_STREQ("0", q.GetTokens()[1].name);
        EXPECT_EQ(0u, q.GetTokens()[1].index);
        EXPECT_EQ(&p.GetAllocator(), &q.GetAllocator());
    }

    // Static tokens
    {
        Pointer p(kTokens, sizeof(kTokens) / sizeof(kTokens[0]));
        Pointer q(p);
        EXPECT_TRUE(q.IsValid());
        EXPECT_EQ(2u, q.GetTokenCount());
        EXPECT_EQ(3u, q.GetTokens()[0].length);
        EXPECT_STREQ("foo", q.GetTokens()[0].name);
        EXPECT_EQ(1u, q.GetTokens()[1].length);
        EXPECT_STREQ("0", q.GetTokens()[1].name);
        EXPECT_EQ(0u, q.GetTokens()[1].index);
    }
}

TEST(Pointer, Assignment) {
    {
        CrtAllocator allocator;
        Pointer p("/foo/0", &allocator);
        Pointer q;
        q = p;
        EXPECT_TRUE(q.IsValid());
        EXPECT_EQ(2u, q.GetTokenCount());
        EXPECT_EQ(3u, q.GetTokens()[0].length);
        EXPECT_STREQ("foo", q.GetTokens()[0].name);
        EXPECT_EQ(1u, q.GetTokens()[1].length);
        EXPECT_STREQ("0", q.GetTokens()[1].name);
        EXPECT_EQ(0u, q.GetTokens()[1].index);
        EXPECT_NE(&p.GetAllocator(), &q.GetAllocator());
        q = static_cast<const Pointer &>(q);
        EXPECT_TRUE(q.IsValid());
        EXPECT_EQ(2u, q.GetTokenCount());
        EXPECT_EQ(3u, q.GetTokens()[0].length);
        EXPECT_STREQ("foo", q.GetTokens()[0].name);
        EXPECT_EQ(1u, q.GetTokens()[1].length);
        EXPECT_STREQ("0", q.GetTokens()[1].name);
        EXPECT_EQ(0u, q.GetTokens()[1].index);
        EXPECT_NE(&p.GetAllocator(), &q.GetAllocator());
    }

    // Static tokens
    {
        Pointer p(kTokens, sizeof(kTokens) / sizeof(kTokens[0]));
        Pointer q;
        q = p;
        EXPECT_TRUE(q.IsValid());
        EXPECT_EQ(2u, q.GetTokenCount());
        EXPECT_EQ(3u, q.GetTokens()[0].length);
        EXPECT_STREQ("foo", q.GetTokens()[0].name);
        EXPECT_EQ(1u, q.GetTokens()[1].length);
        EXPECT_STREQ("0", q.GetTokens()[1].name);
        EXPECT_EQ(0u, q.GetTokens()[1].index);
    }
}

TEST(Pointer, Swap) {
    Pointer p("/foo/0");
    Pointer q(&p.GetAllocator());

    q.Swap(p);
    EXPECT_EQ(&q.GetAllocator(), &p.GetAllocator());
    EXPECT_TRUE(p.IsValid());
    EXPECT_TRUE(q.IsValid());
    EXPECT_EQ(0u, p.GetTokenCount());
    EXPECT_EQ(2u, q.GetTokenCount());
    EXPECT_EQ(3u, q.GetTokens()[0].length);
    EXPECT_STREQ("foo", q.GetTokens()[0].name);
    EXPECT_EQ(1u, q.GetTokens()[1].length);
    EXPECT_STREQ("0", q.GetTokens()[1].name);
    EXPECT_EQ(0u, q.GetTokens()[1].index);

    // std::swap compatibility
    std::swap(p, q);
    EXPECT_EQ(&p.GetAllocator(), &q.GetAllocator());
    EXPECT_TRUE(q.IsValid());
    EXPECT_TRUE(p.IsValid());
    EXPECT_EQ(0u, q.GetTokenCount());
    EXPECT_EQ(2u, p.GetTokenCount());
    EXPECT_EQ(3u, p.GetTokens()[0].length);
    EXPECT_STREQ("foo", p.GetTokens()[0].name);
    EXPECT_EQ(1u, p.GetTokens()[1].length);
    EXPECT_STREQ("0", p.GetTokens()[1].name);
    EXPECT_EQ(0u, p.GetTokens()[1].index);
}

TEST(Pointer, Append) {
    {
        Pointer p;
        Pointer q = p.Append("foo");
        EXPECT_TRUE(Pointer("/foo") == q);
        q = q.Append(1234);
        EXPECT_TRUE(Pointer("/foo/1234") == q);
        q = q.Append("");
        EXPECT_TRUE(Pointer("/foo/1234/") == q);
    }

    {
        Pointer p;
        Pointer q = p.Append(Value("foo").Move());
        EXPECT_TRUE(Pointer("/foo") == q);
        q = q.Append(Value(1234).Move());
        EXPECT_TRUE(Pointer("/foo/1234") == q);
        q = q.Append(Value(kStringType).Move());
        EXPECT_TRUE(Pointer("/foo/1234/") == q);
    }

#if RAPIDJSON_HAS_STDSTRING
    {
        Pointer p;
        Pointer q = p.Append(std::string("foo"));
        EXPECT_TRUE(Pointer("/foo") == q);
    }
#endif
}

TEST(Pointer, Equality) {
    EXPECT_TRUE(Pointer("/foo/0") == Pointer("/foo/0"));
    EXPECT_FALSE(Pointer("/foo/0") == Pointer("/foo/1"));
    EXPECT_FALSE(Pointer("/foo/0") == Pointer("/foo/0/1"));
    EXPECT_FALSE(Pointer("/foo/0") == Pointer("a"));
    EXPECT_FALSE(Pointer("a") == Pointer("a")); // Invalid always not equal
}

TEST(Pointer, Inequality) {
    EXPECT_FALSE(Pointer("/foo/0") != Pointer("/foo/0"));
    EXPECT_TRUE(Pointer("/foo/0") != Pointer("/foo/1"));
    EXPECT_TRUE(Pointer("/foo/0") != Pointer("/foo/0/1"));
    EXPECT_TRUE(Pointer("/foo/0") != Pointer("a"));
    EXPECT_TRUE(Pointer("a") != Pointer("a")); // Invalid always not equal
}

TEST(Pointer, Create) {
    Document d;
    {
        Value* v = &Pointer("").Create(d, d.GetAllocator());
        EXPECT_EQ(&d, v);
    }
    {
        Value* v = &Pointer("/foo").Create(d, d.GetAllocator());
        EXPECT_EQ(&d["foo"], v);
    }
    {
        Value* v = &Pointer("/foo/0").Create(d, d.GetAllocator());
        EXPECT_EQ(&d["foo"][0], v);
    }
    {
        Value* v = &Pointer("/foo/-").Create(d, d.GetAllocator());
        EXPECT_EQ(&d["foo"][1], v);
    }

    {
        Value* v = &Pointer("/foo/-/-").Create(d, d.GetAllocator());
        // "foo/-" is a newly created null value x.
        // "foo/-/-" finds that x is not an array, it converts x to empty object
        // and treats - as "-" member name
        EXPECT_EQ(&d["foo"][2]["-"], v);
    }

    {
        // Document with no allocator
        Value* v = &Pointer("/foo/-").Create(d);
        EXPECT_EQ(&d["foo"][3], v);
    }

    {
        // Value (not document) must give allocator
        Value* v = &Pointer("/-").Create(d["foo"], d.GetAllocator());
        EXPECT_EQ(&d["foo"][4], v);
    }
}

TEST(Pointer, Get) {
    Document d;
    d.Parse(kJson);

    EXPECT_EQ(&d, Pointer("").Get(d));
    EXPECT_EQ(&d["foo"], Pointer("/foo").Get(d));
    EXPECT_EQ(&d["foo"][0], Pointer("/foo/0").Get(d));
    EXPECT_EQ(&d[""], Pointer("/").Get(d));
    EXPECT_EQ(&d["a/b"], Pointer("/a~1b").Get(d));
    EXPECT_EQ(&d["c%d"], Pointer("/c%d").Get(d));
    EXPECT_EQ(&d["e^f"], Pointer("/e^f").Get(d));
    EXPECT_EQ(&d["g|h"], Pointer("/g|h").Get(d));
    EXPECT_EQ(&d["i\\j"], Pointer("/i\\j").Get(d));
    EXPECT_EQ(&d["k\"l"], Pointer("/k\"l").Get(d));
    EXPECT_EQ(&d[" "], Pointer("/ ").Get(d));
    EXPECT_EQ(&d["m~n"], Pointer("/m~0n").Get(d));
    EXPECT_TRUE(Pointer("/abc").Get(d) == 0);
    size_t unresolvedTokenIndex;
    EXPECT_TRUE(Pointer("/foo/2").Get(d, &unresolvedTokenIndex) == 0); // Out of boundary
    EXPECT_EQ(1u, unresolvedTokenIndex);
    EXPECT_TRUE(Pointer("/foo/a").Get(d, &unresolvedTokenIndex) == 0); // "/foo" is an array, cannot query by "a"
    EXPECT_EQ(1u, unresolvedTokenIndex);
    EXPECT_TRUE(Pointer("/foo/0/0").Get(d, &unresolvedTokenIndex) == 0); // "/foo/0" is an string, cannot further query
    EXPECT_EQ(2u, unresolvedTokenIndex);
    EXPECT_TRUE(Pointer("/foo/0/a").Get(d, &unresolvedTokenIndex) == 0); // "/foo/0" is an string, cannot further query
    EXPECT_EQ(2u, unresolvedTokenIndex);

    Pointer::Token tokens[] = { { "foo ...", 3, kPointerInvalidIndex } };
    EXPECT_EQ(&d["foo"], Pointer(tokens, 1).Get(d));
}

TEST(Pointer, GetWithDefault) {
    Document d;
    d.Parse(kJson);

    // Value version
    Document::AllocatorType& a = d.GetAllocator();
    const Value v("qux");
    EXPECT_TRUE(Value("bar") == Pointer("/foo/0").GetWithDefault(d, v, a));
    EXPECT_TRUE(Value("baz") == Pointer("/foo/1").GetWithDefault(d, v, a));
    EXPECT_TRUE(Value("qux") == Pointer("/foo/2").GetWithDefault(d, v, a));
    EXPECT_TRUE(Value("last") == Pointer("/foo/-").GetWithDefault(d, Value("last").Move(), a));
    EXPECT_STREQ("last", d["foo"][3].GetString());

    EXPECT_TRUE(Pointer("/foo/null").GetWithDefault(d, Value().Move(), a).IsNull());
    EXPECT_TRUE(Pointer("/foo/null").GetWithDefault(d, "x", a).IsNull());

    // Generic version
    EXPECT_EQ(-1, Pointer("/foo/int").GetWithDefault(d, -1, a).GetInt());
    EXPECT_EQ(-1, Pointer("/foo/int").GetWithDefault(d, -2, a).GetInt());
    EXPECT_EQ(0x87654321, Pointer("/foo/uint").GetWithDefault(d, 0x87654321, a).GetUint());
    EXPECT_EQ(0x87654321, Pointer("/foo/uint").GetWithDefault(d, 0x12345678, a).GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    EXPECT_EQ(i64, Pointer("/foo/int64").GetWithDefault(d, i64, a).GetInt64());
    EXPECT_EQ(i64, Pointer("/foo/int64").GetWithDefault(d, i64 + 1, a).GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    EXPECT_EQ(u64, Pointer("/foo/uint64").GetWithDefault(d, u64, a).GetUint64());
    EXPECT_EQ(u64, Pointer("/foo/uint64").GetWithDefault(d, u64 - 1, a).GetUint64());

    EXPECT_TRUE(Pointer("/foo/true").GetWithDefault(d, true, a).IsTrue());
    EXPECT_TRUE(Pointer("/foo/true").GetWithDefault(d, false, a).IsTrue());

    EXPECT_TRUE(Pointer("/foo/false").GetWithDefault(d, false, a).IsFalse());
    EXPECT_TRUE(Pointer("/foo/false").GetWithDefault(d, true, a).IsFalse());

    // StringRef version
    EXPECT_STREQ("Hello", Pointer("/foo/hello").GetWithDefault(d, "Hello", a).GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        EXPECT_STREQ("World", Pointer("/foo/world").GetWithDefault(d, buffer, a).GetString());
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_STREQ("C++", Pointer("/foo/C++").GetWithDefault(d, std::string("C++"), a).GetString());
#endif
}

TEST(Pointer, GetWithDefault_NoAllocator) {
    Document d;
    d.Parse(kJson);

    // Value version
    const Value v("qux");
    EXPECT_TRUE(Value("bar") == Pointer("/foo/0").GetWithDefault(d, v));
    EXPECT_TRUE(Value("baz") == Pointer("/foo/1").GetWithDefault(d, v));
    EXPECT_TRUE(Value("qux") == Pointer("/foo/2").GetWithDefault(d, v));
    EXPECT_TRUE(Value("last") == Pointer("/foo/-").GetWithDefault(d, Value("last").Move()));
    EXPECT_STREQ("last", d["foo"][3].GetString());

    EXPECT_TRUE(Pointer("/foo/null").GetWithDefault(d, Value().Move()).IsNull());
    EXPECT_TRUE(Pointer("/foo/null").GetWithDefault(d, "x").IsNull());

    // Generic version
    EXPECT_EQ(-1, Pointer("/foo/int").GetWithDefault(d, -1).GetInt());
    EXPECT_EQ(-1, Pointer("/foo/int").GetWithDefault(d, -2).GetInt());
    EXPECT_EQ(0x87654321, Pointer("/foo/uint").GetWithDefault(d, 0x87654321).GetUint());
    EXPECT_EQ(0x87654321, Pointer("/foo/uint").GetWithDefault(d, 0x12345678).GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    EXPECT_EQ(i64, Pointer("/foo/int64").GetWithDefault(d, i64).GetInt64());
    EXPECT_EQ(i64, Pointer("/foo/int64").GetWithDefault(d, i64 + 1).GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    EXPECT_EQ(u64, Pointer("/foo/uint64").GetWithDefault(d, u64).GetUint64());
    EXPECT_EQ(u64, Pointer("/foo/uint64").GetWithDefault(d, u64 - 1).GetUint64());

    EXPECT_TRUE(Pointer("/foo/true").GetWithDefault(d, true).IsTrue());
    EXPECT_TRUE(Pointer("/foo/true").GetWithDefault(d, false).IsTrue());

    EXPECT_TRUE(Pointer("/foo/false").GetWithDefault(d, false).IsFalse());
    EXPECT_TRUE(Pointer("/foo/false").GetWithDefault(d, true).IsFalse());

    // StringRef version
    EXPECT_STREQ("Hello", Pointer("/foo/hello").GetWithDefault(d, "Hello").GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        EXPECT_STREQ("World", Pointer("/foo/world").GetWithDefault(d, buffer).GetString());
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_STREQ("C++", Pointer("/foo/C++").GetWithDefault(d, std::string("C++")).GetString());
#endif
}

TEST(Pointer, Set) {
    Document d;
    d.Parse(kJson);
    Document::AllocatorType& a = d.GetAllocator();
    
    // Value version
    Pointer("/foo/0").Set(d, Value(123).Move(), a);
    EXPECT_EQ(123, d["foo"][0].GetInt());

    Pointer("/foo/-").Set(d, Value(456).Move(), a);
    EXPECT_EQ(456, d["foo"][2].GetInt());

    Pointer("/foo/null").Set(d, Value().Move(), a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/null")->IsNull());

    // Const Value version
    const Value foo(d["foo"], a);
    Pointer("/clone").Set(d, foo, a);
    EXPECT_EQ(foo, *GetValueByPointer(d, "/clone"));

    // Generic version
    Pointer("/foo/int").Set(d, -1, a);
    EXPECT_EQ(-1, GetValueByPointer(d, "/foo/int")->GetInt());

    Pointer("/foo/uint").Set(d, 0x87654321, a);
    EXPECT_EQ(0x87654321, GetValueByPointer(d, "/foo/uint")->GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    Pointer("/foo/int64").Set(d, i64, a);
    EXPECT_EQ(i64, GetValueByPointer(d, "/foo/int64")->GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    Pointer("/foo/uint64").Set(d, u64, a);
    EXPECT_EQ(u64, GetValueByPointer(d, "/foo/uint64")->GetUint64());

    Pointer("/foo/true").Set(d, true, a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/true")->IsTrue());

    Pointer("/foo/false").Set(d, false, a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/false")->IsFalse());

    // StringRef version
    Pointer("/foo/hello").Set(d, "Hello", a);
    EXPECT_STREQ("Hello", GetValueByPointer(d, "/foo/hello")->GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        Pointer("/foo/world").Set(d, buffer, a);
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    Pointer("/foo/c++").Set(d, std::string("C++"), a);
    EXPECT_STREQ("C++", GetValueByPointer(d, "/foo/c++")->GetString());
#endif
}

TEST(Pointer, Set_NoAllocator) {
    Document d;
    d.Parse(kJson);
    
    // Value version
    Pointer("/foo/0").Set(d, Value(123).Move());
    EXPECT_EQ(123, d["foo"][0].GetInt());

    Pointer("/foo/-").Set(d, Value(456).Move());
    EXPECT_EQ(456, d["foo"][2].GetInt());

    Pointer("/foo/null").Set(d, Value().Move());
    EXPECT_TRUE(GetValueByPointer(d, "/foo/null")->IsNull());

    // Const Value version
    const Value foo(d["foo"], d.GetAllocator());
    Pointer("/clone").Set(d, foo);
    EXPECT_EQ(foo, *GetValueByPointer(d, "/clone"));

    // Generic version
    Pointer("/foo/int").Set(d, -1);
    EXPECT_EQ(-1, GetValueByPointer(d, "/foo/int")->GetInt());

    Pointer("/foo/uint").Set(d, 0x87654321);
    EXPECT_EQ(0x87654321, GetValueByPointer(d, "/foo/uint")->GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    Pointer("/foo/int64").Set(d, i64);
    EXPECT_EQ(i64, GetValueByPointer(d, "/foo/int64")->GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    Pointer("/foo/uint64").Set(d, u64);
    EXPECT_EQ(u64, GetValueByPointer(d, "/foo/uint64")->GetUint64());

    Pointer("/foo/true").Set(d, true);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/true")->IsTrue());

    Pointer("/foo/false").Set(d, false);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/false")->IsFalse());

    // StringRef version
    Pointer("/foo/hello").Set(d, "Hello");
    EXPECT_STREQ("Hello", GetValueByPointer(d, "/foo/hello")->GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        Pointer("/foo/world").Set(d, buffer);
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    Pointer("/foo/c++").Set(d, std::string("C++"));
    EXPECT_STREQ("C++", GetValueByPointer(d, "/foo/c++")->GetString());
#endif
}

TEST(Pointer, Swap_Value) {
    Document d;
    d.Parse(kJson);
    Document::AllocatorType& a = d.GetAllocator();
    Pointer("/foo/0").Swap(d, *Pointer("/foo/1").Get(d), a);
    EXPECT_STREQ("baz", d["foo"][0].GetString());
    EXPECT_STREQ("bar", d["foo"][1].GetString());
}

TEST(Pointer, Swap_Value_NoAllocator) {
    Document d;
    d.Parse(kJson);
    Pointer("/foo/0").Swap(d, *Pointer("/foo/1").Get(d));
    EXPECT_STREQ("baz", d["foo"][0].GetString());
    EXPECT_STREQ("bar", d["foo"][1].GetString());
}

TEST(Pointer, Erase) {
    Document d;
    d.Parse(kJson);

    EXPECT_FALSE(Pointer("").Erase(d));
    EXPECT_FALSE(Pointer("/nonexist").Erase(d));
    EXPECT_FALSE(Pointer("/nonexist/nonexist").Erase(d));
    EXPECT_FALSE(Pointer("/foo/nonexist").Erase(d));
    EXPECT_FALSE(Pointer("/foo/nonexist/nonexist").Erase(d));
    EXPECT_FALSE(Pointer("/foo/0/nonexist").Erase(d));
    EXPECT_FALSE(Pointer("/foo/0/nonexist/nonexist").Erase(d));
    EXPECT_FALSE(Pointer("/foo/2/nonexist").Erase(d));
    EXPECT_TRUE(Pointer("/foo/0").Erase(d));
    EXPECT_EQ(1u, d["foo"].Size());
    EXPECT_STREQ("baz", d["foo"][0].GetString());
    EXPECT_TRUE(Pointer("/foo/0").Erase(d));
    EXPECT_TRUE(d["foo"].Empty());
    EXPECT_TRUE(Pointer("/foo").Erase(d));
    EXPECT_TRUE(Pointer("/foo").Get(d) == 0);

    Pointer("/a/0/b/0").Create(d);

    EXPECT_TRUE(Pointer("/a/0/b/0").Get(d) != 0);
    EXPECT_TRUE(Pointer("/a/0/b/0").Erase(d));
    EXPECT_TRUE(Pointer("/a/0/b/0").Get(d) == 0);

    EXPECT_TRUE(Pointer("/a/0/b").Get(d) != 0);
    EXPECT_TRUE(Pointer("/a/0/b").Erase(d));
    EXPECT_TRUE(Pointer("/a/0/b").Get(d) == 0);

    EXPECT_TRUE(Pointer("/a/0").Get(d) != 0);
    EXPECT_TRUE(Pointer("/a/0").Erase(d));
    EXPECT_TRUE(Pointer("/a/0").Get(d) == 0);

    EXPECT_TRUE(Pointer("/a").Get(d) != 0);
    EXPECT_TRUE(Pointer("/a").Erase(d));
    EXPECT_TRUE(Pointer("/a").Get(d) == 0);
}

TEST(Pointer, CreateValueByPointer) {
    Document d;
    Document::AllocatorType& a = d.GetAllocator();

    {
        Value& v = CreateValueByPointer(d, Pointer("/foo/0"), a);
        EXPECT_EQ(&d["foo"][0], &v);
    }
    {
        Value& v = CreateValueByPointer(d, "/foo/1", a);
        EXPECT_EQ(&d["foo"][1], &v);
    }
}

TEST(Pointer, CreateValueByPointer_NoAllocator) {
    Document d;

    {
        Value& v = CreateValueByPointer(d, Pointer("/foo/0"));
        EXPECT_EQ(&d["foo"][0], &v);
    }
    {
        Value& v = CreateValueByPointer(d, "/foo/1");
        EXPECT_EQ(&d["foo"][1], &v);
    }
}

TEST(Pointer, GetValueByPointer) {
    Document d;
    d.Parse(kJson);

    EXPECT_EQ(&d["foo"][0], GetValueByPointer(d, Pointer("/foo/0")));
    EXPECT_EQ(&d["foo"][0], GetValueByPointer(d, "/foo/0"));

    size_t unresolvedTokenIndex;
    EXPECT_TRUE(GetValueByPointer(d, "/foo/2", &unresolvedTokenIndex) == 0); // Out of boundary
    EXPECT_EQ(1u, unresolvedTokenIndex);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/a", &unresolvedTokenIndex) == 0); // "/foo" is an array, cannot query by "a"
    EXPECT_EQ(1u, unresolvedTokenIndex);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/0/0", &unresolvedTokenIndex) == 0); // "/foo/0" is an string, cannot further query
    EXPECT_EQ(2u, unresolvedTokenIndex);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/0/a", &unresolvedTokenIndex) == 0); // "/foo/0" is an string, cannot further query
    EXPECT_EQ(2u, unresolvedTokenIndex);

    // const version
    const Value& v = d;
    EXPECT_EQ(&d["foo"][0], GetValueByPointer(v, Pointer("/foo/0")));
    EXPECT_EQ(&d["foo"][0], GetValueByPointer(v, "/foo/0"));

    EXPECT_TRUE(GetValueByPointer(v, "/foo/2", &unresolvedTokenIndex) == 0); // Out of boundary
    EXPECT_EQ(1u, unresolvedTokenIndex);
    EXPECT_TRUE(GetValueByPointer(v, "/foo/a", &unresolvedTokenIndex) == 0); // "/foo" is an array, cannot query by "a"
    EXPECT_EQ(1u, unresolvedTokenIndex);
    EXPECT_TRUE(GetValueByPointer(v, "/foo/0/0", &unresolvedTokenIndex) == 0); // "/foo/0" is an string, cannot further query
    EXPECT_EQ(2u, unresolvedTokenIndex);
    EXPECT_TRUE(GetValueByPointer(v, "/foo/0/a", &unresolvedTokenIndex) == 0); // "/foo/0" is an string, cannot further query
    EXPECT_EQ(2u, unresolvedTokenIndex);

}

TEST(Pointer, GetValueByPointerWithDefault_Pointer) {
    Document d;
    d.Parse(kJson);

    Document::AllocatorType& a = d.GetAllocator();
    const Value v("qux");
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, Pointer("/foo/0"), v, a));
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, Pointer("/foo/0"), v, a));
    EXPECT_TRUE(Value("baz") == GetValueByPointerWithDefault(d, Pointer("/foo/1"), v, a));
    EXPECT_TRUE(Value("qux") == GetValueByPointerWithDefault(d, Pointer("/foo/2"), v, a));
    EXPECT_TRUE(Value("last") == GetValueByPointerWithDefault(d, Pointer("/foo/-"), Value("last").Move(), a));
    EXPECT_STREQ("last", d["foo"][3].GetString());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/null"), Value().Move(), a).IsNull());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/null"), "x", a).IsNull());

    // Generic version
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, Pointer("/foo/int"), -1, a).GetInt());
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, Pointer("/foo/int"), -2, a).GetInt());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, Pointer("/foo/uint"), 0x87654321, a).GetUint());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, Pointer("/foo/uint"), 0x12345678, a).GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, Pointer("/foo/int64"), i64, a).GetInt64());
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, Pointer("/foo/int64"), i64 + 1, a).GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, Pointer("/foo/uint64"), u64, a).GetUint64());
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, Pointer("/foo/uint64"), u64 - 1, a).GetUint64());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/true"), true, a).IsTrue());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/true"), false, a).IsTrue());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/false"), false, a).IsFalse());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/false"), true, a).IsFalse());

    // StringRef version
    EXPECT_STREQ("Hello", GetValueByPointerWithDefault(d, Pointer("/foo/hello"), "Hello", a).GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        EXPECT_STREQ("World", GetValueByPointerWithDefault(d, Pointer("/foo/world"), buffer, a).GetString());
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, Pointer("/foo/world"))->GetString());

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_STREQ("C++", GetValueByPointerWithDefault(d, Pointer("/foo/C++"), std::string("C++"), a).GetString());
#endif
}

TEST(Pointer, GetValueByPointerWithDefault_String) {
    Document d;
    d.Parse(kJson);

    Document::AllocatorType& a = d.GetAllocator();
    const Value v("qux");
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, "/foo/0", v, a));
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, "/foo/0", v, a));
    EXPECT_TRUE(Value("baz") == GetValueByPointerWithDefault(d, "/foo/1", v, a));
    EXPECT_TRUE(Value("qux") == GetValueByPointerWithDefault(d, "/foo/2", v, a));
    EXPECT_TRUE(Value("last") == GetValueByPointerWithDefault(d, "/foo/-", Value("last").Move(), a));
    EXPECT_STREQ("last", d["foo"][3].GetString());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/null", Value().Move(), a).IsNull());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/null", "x", a).IsNull());

    // Generic version
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, "/foo/int", -1, a).GetInt());
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, "/foo/int", -2, a).GetInt());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, "/foo/uint", 0x87654321, a).GetUint());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, "/foo/uint", 0x12345678, a).GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, "/foo/int64", i64, a).GetInt64());
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, "/foo/int64", i64 + 1, a).GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, "/foo/uint64", u64, a).GetUint64());
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, "/foo/uint64", u64 - 1, a).GetUint64());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/true", true, a).IsTrue());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/true", false, a).IsTrue());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/false", false, a).IsFalse());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/false", true, a).IsFalse());

    // StringRef version
    EXPECT_STREQ("Hello", GetValueByPointerWithDefault(d, "/foo/hello", "Hello", a).GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        EXPECT_STREQ("World", GetValueByPointerWithDefault(d, "/foo/world", buffer, a).GetString());
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_STREQ("C++", GetValueByPointerWithDefault(d, "/foo/C++", std::string("C++"), a).GetString());
#endif
}

TEST(Pointer, GetValueByPointerWithDefault_Pointer_NoAllocator) {
    Document d;
    d.Parse(kJson);

    const Value v("qux");
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, Pointer("/foo/0"), v));
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, Pointer("/foo/0"), v));
    EXPECT_TRUE(Value("baz") == GetValueByPointerWithDefault(d, Pointer("/foo/1"), v));
    EXPECT_TRUE(Value("qux") == GetValueByPointerWithDefault(d, Pointer("/foo/2"), v));
    EXPECT_TRUE(Value("last") == GetValueByPointerWithDefault(d, Pointer("/foo/-"), Value("last").Move()));
    EXPECT_STREQ("last", d["foo"][3].GetString());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/null"), Value().Move()).IsNull());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/null"), "x").IsNull());

    // Generic version
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, Pointer("/foo/int"), -1).GetInt());
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, Pointer("/foo/int"), -2).GetInt());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, Pointer("/foo/uint"), 0x87654321).GetUint());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, Pointer("/foo/uint"), 0x12345678).GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, Pointer("/foo/int64"), i64).GetInt64());
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, Pointer("/foo/int64"), i64 + 1).GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, Pointer("/foo/uint64"), u64).GetUint64());
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, Pointer("/foo/uint64"), u64 - 1).GetUint64());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/true"), true).IsTrue());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/true"), false).IsTrue());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/false"), false).IsFalse());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, Pointer("/foo/false"), true).IsFalse());

    // StringRef version
    EXPECT_STREQ("Hello", GetValueByPointerWithDefault(d, Pointer("/foo/hello"), "Hello").GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        EXPECT_STREQ("World", GetValueByPointerWithDefault(d, Pointer("/foo/world"), buffer).GetString());
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, Pointer("/foo/world"))->GetString());

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_STREQ("C++", GetValueByPointerWithDefault(d, Pointer("/foo/C++"), std::string("C++")).GetString());
#endif
}

TEST(Pointer, GetValueByPointerWithDefault_String_NoAllocator) {
    Document d;
    d.Parse(kJson);

    const Value v("qux");
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, "/foo/0", v));
    EXPECT_TRUE(Value("bar") == GetValueByPointerWithDefault(d, "/foo/0", v));
    EXPECT_TRUE(Value("baz") == GetValueByPointerWithDefault(d, "/foo/1", v));
    EXPECT_TRUE(Value("qux") == GetValueByPointerWithDefault(d, "/foo/2", v));
    EXPECT_TRUE(Value("last") == GetValueByPointerWithDefault(d, "/foo/-", Value("last").Move()));
    EXPECT_STREQ("last", d["foo"][3].GetString());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/null", Value().Move()).IsNull());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/null", "x").IsNull());

    // Generic version
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, "/foo/int", -1).GetInt());
    EXPECT_EQ(-1, GetValueByPointerWithDefault(d, "/foo/int", -2).GetInt());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, "/foo/uint", 0x87654321).GetUint());
    EXPECT_EQ(0x87654321, GetValueByPointerWithDefault(d, "/foo/uint", 0x12345678).GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, "/foo/int64", i64).GetInt64());
    EXPECT_EQ(i64, GetValueByPointerWithDefault(d, "/foo/int64", i64 + 1).GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, "/foo/uint64", u64).GetUint64());
    EXPECT_EQ(u64, GetValueByPointerWithDefault(d, "/foo/uint64", u64 - 1).GetUint64());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/true", true).IsTrue());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/true", false).IsTrue());

    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/false", false).IsFalse());
    EXPECT_TRUE(GetValueByPointerWithDefault(d, "/foo/false", true).IsFalse());

    // StringRef version
    EXPECT_STREQ("Hello", GetValueByPointerWithDefault(d, "/foo/hello", "Hello").GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        EXPECT_STREQ("World", GetValueByPointerWithDefault(d, "/foo/world", buffer).GetString());
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_STREQ("C++", GetValueByPointerWithDefault(d, Pointer("/foo/C++"), std::string("C++")).GetString());
#endif
}

TEST(Pointer, SetValueByPointer_Pointer) {
    Document d;
    d.Parse(kJson);
    Document::AllocatorType& a = d.GetAllocator();

    // Value version
    SetValueByPointer(d, Pointer("/foo/0"), Value(123).Move(), a);
    EXPECT_EQ(123, d["foo"][0].GetInt());

    SetValueByPointer(d, Pointer("/foo/null"), Value().Move(), a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/null")->IsNull());

    // Const Value version
    const Value foo(d["foo"], d.GetAllocator());
    SetValueByPointer(d, Pointer("/clone"), foo, a);
    EXPECT_EQ(foo, *GetValueByPointer(d, "/clone"));

    // Generic version
    SetValueByPointer(d, Pointer("/foo/int"), -1, a);
    EXPECT_EQ(-1, GetValueByPointer(d, "/foo/int")->GetInt());

    SetValueByPointer(d, Pointer("/foo/uint"), 0x87654321, a);
    EXPECT_EQ(0x87654321, GetValueByPointer(d, "/foo/uint")->GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    SetValueByPointer(d, Pointer("/foo/int64"), i64, a);
    EXPECT_EQ(i64, GetValueByPointer(d, "/foo/int64")->GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    SetValueByPointer(d, Pointer("/foo/uint64"), u64, a);
    EXPECT_EQ(u64, GetValueByPointer(d, "/foo/uint64")->GetUint64());

    SetValueByPointer(d, Pointer("/foo/true"), true, a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/true")->IsTrue());

    SetValueByPointer(d, Pointer("/foo/false"), false, a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/false")->IsFalse());

    // StringRef version
    SetValueByPointer(d, Pointer("/foo/hello"), "Hello", a);
    EXPECT_STREQ("Hello", GetValueByPointer(d, "/foo/hello")->GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        SetValueByPointer(d, Pointer("/foo/world"), buffer, a);
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    SetValueByPointer(d, Pointer("/foo/c++"), std::string("C++"), a);
    EXPECT_STREQ("C++", GetValueByPointer(d, "/foo/c++")->GetString());
#endif
}

TEST(Pointer, SetValueByPointer_String) {
    Document d;
    d.Parse(kJson);
    Document::AllocatorType& a = d.GetAllocator();

    // Value version
    SetValueByPointer(d, "/foo/0", Value(123).Move(), a);
    EXPECT_EQ(123, d["foo"][0].GetInt());

    SetValueByPointer(d, "/foo/null", Value().Move(), a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/null")->IsNull());

    // Const Value version
    const Value foo(d["foo"], d.GetAllocator());
    SetValueByPointer(d, "/clone", foo, a);
    EXPECT_EQ(foo, *GetValueByPointer(d, "/clone"));

    // Generic version
    SetValueByPointer(d, "/foo/int", -1, a);
    EXPECT_EQ(-1, GetValueByPointer(d, "/foo/int")->GetInt());

    SetValueByPointer(d, "/foo/uint", 0x87654321, a);
    EXPECT_EQ(0x87654321, GetValueByPointer(d, "/foo/uint")->GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    SetValueByPointer(d, "/foo/int64", i64, a);
    EXPECT_EQ(i64, GetValueByPointer(d, "/foo/int64")->GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    SetValueByPointer(d, "/foo/uint64", u64, a);
    EXPECT_EQ(u64, GetValueByPointer(d, "/foo/uint64")->GetUint64());

    SetValueByPointer(d, "/foo/true", true, a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/true")->IsTrue());

    SetValueByPointer(d, "/foo/false", false, a);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/false")->IsFalse());

    // StringRef version
    SetValueByPointer(d, "/foo/hello", "Hello", a);
    EXPECT_STREQ("Hello", GetValueByPointer(d, "/foo/hello")->GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        SetValueByPointer(d, "/foo/world", buffer, a);
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    SetValueByPointer(d, "/foo/c++", std::string("C++"), a);
    EXPECT_STREQ("C++", GetValueByPointer(d, "/foo/c++")->GetString());
#endif
}

TEST(Pointer, SetValueByPointer_Pointer_NoAllocator) {
    Document d;
    d.Parse(kJson);

    // Value version
    SetValueByPointer(d, Pointer("/foo/0"), Value(123).Move());
    EXPECT_EQ(123, d["foo"][0].GetInt());

    SetValueByPointer(d, Pointer("/foo/null"), Value().Move());
    EXPECT_TRUE(GetValueByPointer(d, "/foo/null")->IsNull());

    // Const Value version
    const Value foo(d["foo"], d.GetAllocator());
    SetValueByPointer(d, Pointer("/clone"), foo);
    EXPECT_EQ(foo, *GetValueByPointer(d, "/clone"));

    // Generic version
    SetValueByPointer(d, Pointer("/foo/int"), -1);
    EXPECT_EQ(-1, GetValueByPointer(d, "/foo/int")->GetInt());

    SetValueByPointer(d, Pointer("/foo/uint"), 0x87654321);
    EXPECT_EQ(0x87654321, GetValueByPointer(d, "/foo/uint")->GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    SetValueByPointer(d, Pointer("/foo/int64"), i64);
    EXPECT_EQ(i64, GetValueByPointer(d, "/foo/int64")->GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    SetValueByPointer(d, Pointer("/foo/uint64"), u64);
    EXPECT_EQ(u64, GetValueByPointer(d, "/foo/uint64")->GetUint64());

    SetValueByPointer(d, Pointer("/foo/true"), true);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/true")->IsTrue());

    SetValueByPointer(d, Pointer("/foo/false"), false);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/false")->IsFalse());

    // StringRef version
    SetValueByPointer(d, Pointer("/foo/hello"), "Hello");
    EXPECT_STREQ("Hello", GetValueByPointer(d, "/foo/hello")->GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        SetValueByPointer(d, Pointer("/foo/world"), buffer);
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    SetValueByPointer(d, Pointer("/foo/c++"), std::string("C++"));
    EXPECT_STREQ("C++", GetValueByPointer(d, "/foo/c++")->GetString());
#endif
}

TEST(Pointer, SetValueByPointer_String_NoAllocator) {
    Document d;
    d.Parse(kJson);

    // Value version
    SetValueByPointer(d, "/foo/0", Value(123).Move());
    EXPECT_EQ(123, d["foo"][0].GetInt());

    SetValueByPointer(d, "/foo/null", Value().Move());
    EXPECT_TRUE(GetValueByPointer(d, "/foo/null")->IsNull());

    // Const Value version
    const Value foo(d["foo"], d.GetAllocator());
    SetValueByPointer(d, "/clone", foo);
    EXPECT_EQ(foo, *GetValueByPointer(d, "/clone"));

    // Generic version
    SetValueByPointer(d, "/foo/int", -1);
    EXPECT_EQ(-1, GetValueByPointer(d, "/foo/int")->GetInt());

    SetValueByPointer(d, "/foo/uint", 0x87654321);
    EXPECT_EQ(0x87654321, GetValueByPointer(d, "/foo/uint")->GetUint());

    const int64_t i64 = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 0));
    SetValueByPointer(d, "/foo/int64", i64);
    EXPECT_EQ(i64, GetValueByPointer(d, "/foo/int64")->GetInt64());

    const uint64_t u64 = RAPIDJSON_UINT64_C2(0xFFFFFFFFF, 0xFFFFFFFFF);
    SetValueByPointer(d, "/foo/uint64", u64);
    EXPECT_EQ(u64, GetValueByPointer(d, "/foo/uint64")->GetUint64());

    SetValueByPointer(d, "/foo/true", true);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/true")->IsTrue());

    SetValueByPointer(d, "/foo/false", false);
    EXPECT_TRUE(GetValueByPointer(d, "/foo/false")->IsFalse());

    // StringRef version
    SetValueByPointer(d, "/foo/hello", "Hello");
    EXPECT_STREQ("Hello", GetValueByPointer(d, "/foo/hello")->GetString());

    // Copy string version
    {
        char buffer[256];
        strcpy(buffer, "World");
        SetValueByPointer(d, "/foo/world", buffer);
        memset(buffer, 0, sizeof(buffer));
    }
    EXPECT_STREQ("World", GetValueByPointer(d, "/foo/world")->GetString());

#if RAPIDJSON_HAS_STDSTRING
    SetValueByPointer(d, "/foo/c++", std::string("C++"));
    EXPECT_STREQ("C++", GetValueByPointer(d, "/foo/c++")->GetString());
#endif
}

TEST(Pointer, SwapValueByPointer) {
    Document d;
    d.Parse(kJson);
    Document::AllocatorType& a = d.GetAllocator();
    SwapValueByPointer(d, Pointer("/foo/0"), *GetValueByPointer(d, "/foo/1"), a);
    EXPECT_STREQ("baz", d["foo"][0].GetString());
    EXPECT_STREQ("bar", d["foo"][1].GetString());

    SwapValueByPointer(d, "/foo/0", *GetValueByPointer(d, "/foo/1"), a);
    EXPECT_STREQ("bar", d["foo"][0].GetString());
    EXPECT_STREQ("baz", d["foo"][1].GetString());
}

TEST(Pointer, SwapValueByPointer_NoAllocator) {
    Document d;
    d.Parse(kJson);
    SwapValueByPointer(d, Pointer("/foo/0"), *GetValueByPointer(d, "/foo/1"));
    EXPECT_STREQ("baz", d["foo"][0].GetString());
    EXPECT_STREQ("bar", d["foo"][1].GetString());

    SwapValueByPointer(d, "/foo/0", *GetValueByPointer(d, "/foo/1"));
    EXPECT_STREQ("bar", d["foo"][0].GetString());
    EXPECT_STREQ("baz", d["foo"][1].GetString());
}

TEST(Pointer, EraseValueByPointer_Pointer) {
    Document d;
    d.Parse(kJson);

    EXPECT_FALSE(EraseValueByPointer(d, Pointer("")));
    EXPECT_FALSE(Pointer("/foo/nonexist").Erase(d));
    EXPECT_TRUE(EraseValueByPointer(d, Pointer("/foo/0")));
    EXPECT_EQ(1u, d["foo"].Size());
    EXPECT_STREQ("baz", d["foo"][0].GetString());
    EXPECT_TRUE(EraseValueByPointer(d, Pointer("/foo/0")));
    EXPECT_TRUE(d["foo"].Empty());
    EXPECT_TRUE(EraseValueByPointer(d, Pointer("/foo")));
    EXPECT_TRUE(Pointer("/foo").Get(d) == 0);
}

TEST(Pointer, EraseValueByPointer_String) {
    Document d;
    d.Parse(kJson);

    EXPECT_FALSE(EraseValueByPointer(d, ""));
    EXPECT_FALSE(Pointer("/foo/nonexist").Erase(d));
    EXPECT_TRUE(EraseValueByPointer(d, "/foo/0"));
    EXPECT_EQ(1u, d["foo"].Size());
    EXPECT_STREQ("baz", d["foo"][0].GetString());
    EXPECT_TRUE(EraseValueByPointer(d, "/foo/0"));
    EXPECT_TRUE(d["foo"].Empty());
    EXPECT_TRUE(EraseValueByPointer(d, "/foo"));
    EXPECT_TRUE(Pointer("/foo").Get(d) == 0);
}

TEST(Pointer, Ambiguity) {
    {
        Document d;
        d.Parse("{\"0\" : [123]}");
        EXPECT_EQ(123, Pointer("/0/0").Get(d)->GetInt());
        Pointer("/0/a").Set(d, 456);    // Change array [123] to object {456}
        EXPECT_EQ(456, Pointer("/0/a").Get(d)->GetInt());
    }

    {
        Document d;
        EXPECT_FALSE(d.Parse("[{\"0\": 123}]").HasParseError());
        EXPECT_EQ(123, Pointer("/0/0").Get(d)->GetInt());
        Pointer("/0/1").Set(d, 456); // 1 is treated as "1" to index object
        EXPECT_EQ(123, Pointer("/0/0").Get(d)->GetInt());
        EXPECT_EQ(456, Pointer("/0/1").Get(d)->GetInt());
    }
}

TEST(Pointer, LessThan) {
    static const struct {
        const char *str;
        bool valid;
    } pointers[] = {
        { "/a/b",       true },
        { "/a",         true },
        { "/d/1",       true },
        { "/d/2/z",     true },
        { "/d/2/3",     true },
        { "/d/2",       true },
        { "/a/c",       true },
        { "/e/f~g",     false },
        { "/d/2/zz",    true },
        { "/d/1",       true },
        { "/d/2/z",     true },
        { "/e/f~~g",    false },
        { "/e/f~0g",    true },
        { "/e/f~1g",    true },
        { "/e/f.g",     true },
        { "",           true }
    };
    static const char *ordered_pointers[] = {
        "",
        "/a",
        "/a/b",
        "/a/c",
        "/d/1",
        "/d/1",
        "/d/2",
        "/e/f.g",
        "/e/f~1g",
        "/e/f~0g",
        "/d/2/3",
        "/d/2/z",
        "/d/2/z",
        "/d/2/zz",
        NULL,       // was invalid "/e/f~g"
        NULL        // was invalid "/e/f~~g"
    };
    typedef MemoryPoolAllocator<> AllocatorType;
    typedef GenericPointer<Value, AllocatorType> PointerType;
    typedef std::multimap<PointerType, size_t> PointerMap;
    PointerMap map;
    PointerMap::iterator it;
    AllocatorType allocator;
    size_t i;

    EXPECT_EQ(sizeof(pointers) / sizeof(pointers[0]),
              sizeof(ordered_pointers) / sizeof(ordered_pointers[0]));

    for (i = 0; i < sizeof(pointers) / sizeof(pointers[0]); ++i) {
        it = map.insert(PointerMap::value_type(PointerType(pointers[i].str, &allocator), i));
        if (!it->first.IsValid()) {
            EXPECT_EQ(++it, map.end());
        }
    }

    for (i = 0, it = map.begin(); it != map.end(); ++it, ++i) {
        EXPECT_TRUE(it->second < sizeof(pointers) / sizeof(pointers[0]));
        EXPECT_EQ(it->first.IsValid(), pointers[it->second].valid);
        EXPECT_TRUE(i < sizeof(ordered_pointers) / sizeof(ordered_pointers[0]));
        EXPECT_EQ(it->first.IsValid(), !!ordered_pointers[i]);
        if (it->first.IsValid()) {
            std::stringstream ss;
            OStreamWrapper os(ss);
            EXPECT_TRUE(it->first.Stringify(os));
            EXPECT_EQ(ss.str(), pointers[it->second].str);
            EXPECT_EQ(ss.str(), ordered_pointers[i]);
        }
    }
}

// https://github.com/Tencent/rapidjson/issues/483
namespace myjson {

class MyAllocator
{
public:
    static const bool kNeedFree = true;
    void * Malloc(size_t _size) { return malloc(_size); }
    void * Realloc(void *_org_p, size_t _org_size, size_t _new_size) { (void)_org_size; return realloc(_org_p, _new_size); }
    static void Free(void *_p) { return free(_p); }
};

typedef rapidjson::GenericDocument<
            rapidjson::UTF8<>,
            rapidjson::MemoryPoolAllocator< MyAllocator >,
            MyAllocator
        > Document;

typedef rapidjson::GenericPointer<
            ::myjson::Document::ValueType,
            MyAllocator
        > Pointer;

typedef ::myjson::Document::ValueType Value;

}

TEST(Pointer, Issue483) {
    std::string mystr, path;
    myjson::Document document;
    myjson::Value value(rapidjson::kStringType);
    value.SetString(mystr.c_str(), static_cast<SizeType>(mystr.length()), document.GetAllocator());
    myjson::Pointer(path.c_str()).Set(document, value, document.GetAllocator());
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yMezvUPnbFKTyv
{
public:
    int kjqJhMbJr;
    double LsdaAZIrsePwW;
    int WRRzRoEcQxF;
    int SZjJMoYEuopeT;
    double AJqACsWqHhWi;
    int jTsTulttAZ;

    yMezvUPnbFKTyv();
    double RMarGeEsrWKHRd(bool uRGagVLvSOulwe);
    string GKSGxUwSr(string psjuZulJRCuPF, bool sbCvSLEQuFysz, bool PscysMLevyIkO, string STmrgVWyrFzfSdAP);
    void vutEb(double hEiJN, bool MkHYx);
protected:
    string MeeUNJxeREZsyAX;
    string RafuYbRWTPxlGtAJ;

    string jgzcufiXwQCchtpQ(double bLVIs);
    double gEMyZHjcdUJYU(string KJzjcqdYvmgm, bool pYEwBSXtT, bool IkHMUXhyc, bool nBnzpl);
    string ZPyBy(bool LqmsH);
private:
    double avNHkidMj;
    int HpEbzOb;
    bool KMhaffq;
    int MKrWRGBMKf;
    double NmCOibWKIcXG;

    int mrzrIcwyKtn(double SkuTJLxvZFCe, int UZkDjAlHUofQT);
};

double yMezvUPnbFKTyv::RMarGeEsrWKHRd(bool uRGagVLvSOulwe)
{
    bool CgLuEpmZKc = false;
    int zDdjQOiX = -2004668342;
    string ZMOiuPWwUP = string("xQPPBmShvqiHbkuiRMFyraRfwBmqCBbFfrxiUioSerqOxqWYprqJSZujsfhUHhomVkVwPLsSrnKJcKEJNrujCPvtiHrxVpffPScPZAtWTltahtDaiZQvJWmcLZTEZYPWVpSBKhhetHqPwTvsMQwoqxwqAenYyugdwywTrzTTTNEtrdoNgQxcW");
    string AqEvKIXCgFKUbzZ = string("JHGTUkCxpWiMdFcQVOaIlOzwJlrcmymjCwgvJYkLJrMRPqGotmXTHBLlMuAAbjaTXlFOlwlobYEHCEsOmSxjiEkyEdUTEyNBzPTLhPkOLTbkUSzfZJklFvvHpzrVEnfbGRBzlMKDIZwdeygCYedDQlEJRTkiqFyWUzebBmtpHPdDtgwUqlwdzLNhaaVaKMnAMTjnKUGPmWnNpxohBtwhmctHFwjGqxzlHFLuIXFsuLQhDicmDlHN");

    for (int gmnnToDrZZYqsx = 2019967718; gmnnToDrZZYqsx > 0; gmnnToDrZZYqsx--) {
        uRGagVLvSOulwe = ! CgLuEpmZKc;
        uRGagVLvSOulwe = ! uRGagVLvSOulwe;
        ZMOiuPWwUP += ZMOiuPWwUP;
        zDdjQOiX += zDdjQOiX;
    }

    return -731814.7783921892;
}

string yMezvUPnbFKTyv::GKSGxUwSr(string psjuZulJRCuPF, bool sbCvSLEQuFysz, bool PscysMLevyIkO, string STmrgVWyrFzfSdAP)
{
    double SyRwx = 683886.1780170368;
    string cScjdD = string("jfKbpe");
    string zlXAbXWMKwVASnj = string("auSkhXdwnsUtbPhOiLbUycAdqCzhpvxmgayDzWhnrQXEYFFKAzfOXllWgiduRpQnwZZESBMTaA");
    int WGNDu = -72423848;
    int AnIaeWXaF = -865671771;
    double MimjVYpfcxJ = -291156.15541158017;
    string pDHnp = string("jmruXDLUYhNmqChWfQJyDWPiKpAWPTsklAVJeteSqlqspvOrzAGZKNNhNjHCPVOXwWoIcjHlQkOMlWLjjzsSSUxlEjERXazIlMBFcmAVqKDReiAuGvRVuSeEAIyGmWWhvGYvzWcgPukl");
    int HUqMeDBQywfK = -355099387;
    string jwpwc = string("oiNxGhNOqEtNtvOaTEnExneyeRTevYHROHsSQlWMMmxMkxHqQYiwLKgHZFRexGagenLbQsaRQFxehNoMphtyzKWCmcavlgrTBStFGvDIoNJaLjlfDTYPGUlrGLALuhMRHvevkQnruoGkmvSWjMHsScJqZsE");

    if (zlXAbXWMKwVASnj < string("jmruXDLUYhNmqChWfQJyDWPiKpAWPTsklAVJeteSqlqspvOrzAGZKNNhNjHCPVOXwWoIcjHlQkOMlWLjjzsSSUxlEjERXazIlMBFcmAVqKDReiAuGvRVuSeEAIyGmWWhvGYvzWcgPukl")) {
        for (int dSFgMycrTVNQss = 1979777491; dSFgMycrTVNQss > 0; dSFgMycrTVNQss--) {
            STmrgVWyrFzfSdAP += psjuZulJRCuPF;
        }
    }

    for (int HTDOzBLBO = 1482850023; HTDOzBLBO > 0; HTDOzBLBO--) {
        HUqMeDBQywfK = AnIaeWXaF;
    }

    for (int hfbGiZQzhDlJ = 1183508095; hfbGiZQzhDlJ > 0; hfbGiZQzhDlJ--) {
        zlXAbXWMKwVASnj += pDHnp;
    }

    if (zlXAbXWMKwVASnj <= string("PjlbmclPKcjbjxGFItmXNqqVhhUumDkJavSlfdKhOFGulvErDEEWpCrRpi")) {
        for (int MFkAb = 897925127; MFkAb > 0; MFkAb--) {
            sbCvSLEQuFysz = PscysMLevyIkO;
            psjuZulJRCuPF = psjuZulJRCuPF;
            pDHnp = STmrgVWyrFzfSdAP;
            WGNDu += WGNDu;
        }
    }

    return jwpwc;
}

void yMezvUPnbFKTyv::vutEb(double hEiJN, bool MkHYx)
{
    bool pWENKsGRgRU = true;
    double fEyQEYAEsSmT = 529350.0251164263;
    string VBTDCSJJvbjNpus = string("hobUkwXPPACfvstkmGpFgogBckgvEKeoowtRmzXnVbqeXxFBUkNR");
    int mfrrVVQ = 1711220218;
    int dKRpFMMaMrKHa = -699858219;
    bool jtOrYe = false;
    int gvCkLmqkqDOZQtzO = 669943964;
    int EqjweoYzxWd = -1854381712;

    for (int viGUJ = 873745896; viGUJ > 0; viGUJ--) {
        EqjweoYzxWd = gvCkLmqkqDOZQtzO;
        gvCkLmqkqDOZQtzO /= EqjweoYzxWd;
        mfrrVVQ += dKRpFMMaMrKHa;
    }

    for (int MlgJwbhk = 714291649; MlgJwbhk > 0; MlgJwbhk--) {
        dKRpFMMaMrKHa = gvCkLmqkqDOZQtzO;
        EqjweoYzxWd *= gvCkLmqkqDOZQtzO;
        jtOrYe = ! MkHYx;
        mfrrVVQ *= mfrrVVQ;
        gvCkLmqkqDOZQtzO += mfrrVVQ;
    }
}

string yMezvUPnbFKTyv::jgzcufiXwQCchtpQ(double bLVIs)
{
    double yhpWpX = 718700.2011287974;
    string gNOpk = string("GYPJxfpYlLEjvuwDvPFAGAsLzQcxVjYVNhjbWaAKcYdYAVNSBdywotRYTQTLUFKutaKVVpoWcUsriLlwVWcmJGwFKwsalaSVLZnKvNjMtoroXOVqYuABDUApIQaDikXmNhPsFeMpgIcdcGOYmqqmFJgrEyqGNFlkdvYZhCAPTYYIOmTgtlcgAaiPwetUQNzmCsDSXtHhHHGfudzRJgXeHtRSLySHoRmkriPnVmW");
    bool yNamFAqEERaUjHAI = true;
    int bMBmxQNXekL = -2018040111;

    for (int dyIVMSTqrzLb = 1324146795; dyIVMSTqrzLb > 0; dyIVMSTqrzLb--) {
        yhpWpX -= bLVIs;
        bLVIs *= yhpWpX;
    }

    for (int OARPGk = 863456629; OARPGk > 0; OARPGk--) {
        continue;
    }

    return gNOpk;
}

double yMezvUPnbFKTyv::gEMyZHjcdUJYU(string KJzjcqdYvmgm, bool pYEwBSXtT, bool IkHMUXhyc, bool nBnzpl)
{
    double QdLFnpOxXOuKWk = 182260.01992262827;
    double nqGadfZ = -116372.96307568786;
    string LsLggFpRZcejrU = string("eFJb");
    bool pECozkN = false;
    double ZKjinoVZR = 372129.9811747381;
    string ObRfFkSB = string("kxnAyokgWUfYZOhNMgfovEikTnEUEZndMDjxhNtcLZZxDxICkqlxOXuyOcGsaGLlAPrxMcVwvmvksOGGuuwHBZCYwwAutgvhTteBddZnuPjOdBrlIVRIKsSRFbptnvBZYyAiRLhILBVTkViLQSXOqCwBwKuKYNQjvbsgtMmEn");

    for (int aczvUowSXW = 1356323800; aczvUowSXW > 0; aczvUowSXW--) {
        KJzjcqdYvmgm = KJzjcqdYvmgm;
        pECozkN = IkHMUXhyc;
    }

    for (int kpjKINfawa = 1123965517; kpjKINfawa > 0; kpjKINfawa--) {
        ObRfFkSB = LsLggFpRZcejrU;
        pECozkN = pYEwBSXtT;
        ObRfFkSB = KJzjcqdYvmgm;
    }

    return ZKjinoVZR;
}

string yMezvUPnbFKTyv::ZPyBy(bool LqmsH)
{
    string pYgsgEfz = string("KMcssROksErNFuqTLgLCsOgbZmZOZQdUFRXUIsECqlseLQzpwoJoaiGuuTHohmDdXyBVNyiiHFjNFpDeyrYkrCaZsxUuEBaxkTAjsgAqMoERLzNVUshbjVRoOwNsUnlGocEMrrAKLyxJnqzwoNJceaXRmCAevVz");
    int NCARPqILDwieHCCx = 1561260653;
    bool jSMXHvy = true;
    bool XKDwKxaATY = true;
    bool DyMuNHEtrWZzZitk = false;

    for (int lYKKvNhAIFPRJxX = 1381129594; lYKKvNhAIFPRJxX > 0; lYKKvNhAIFPRJxX--) {
        DyMuNHEtrWZzZitk = ! XKDwKxaATY;
        DyMuNHEtrWZzZitk = ! jSMXHvy;
        LqmsH = ! LqmsH;
        jSMXHvy = ! jSMXHvy;
        DyMuNHEtrWZzZitk = ! LqmsH;
    }

    for (int EaONGvHk = 370367113; EaONGvHk > 0; EaONGvHk--) {
        NCARPqILDwieHCCx *= NCARPqILDwieHCCx;
        LqmsH = ! XKDwKxaATY;
        jSMXHvy = LqmsH;
        LqmsH = ! DyMuNHEtrWZzZitk;
        DyMuNHEtrWZzZitk = jSMXHvy;
        XKDwKxaATY = ! jSMXHvy;
        LqmsH = XKDwKxaATY;
        LqmsH = LqmsH;
    }

    return pYgsgEfz;
}

int yMezvUPnbFKTyv::mrzrIcwyKtn(double SkuTJLxvZFCe, int UZkDjAlHUofQT)
{
    string ohVkgmc = string("OnKHozfgtVckKZkbb");
    int povhWmuHtUGJ = 776198755;
    bool bGkWzxDocpORDxxi = false;
    string LhTettaA = string("UtSjOwLZbSjNDcnDJRKUqLJvxCBduVuDNqTegCMOvaNSYAUCKvWAIfzKLHrmgacwbeKLRLmHGmTTtXvAwwTNIWtfEwsUKmWGKAPuvQbLCYHDuRgEtQrCxVALStOMzXVMggTUFTpaGlkOnnfwiJWsPyYayiRjDHWSitgBSilAHeYPql");
    bool HTagtJPI = false;
    bool OGWgUxzgzsbfst = true;
    string vcFgOQrDBWU = string("vCWaljnVaxhSBhBrgBFdFlrOTxzqwWdNlZidubvRGvIUAmwteqRthPhZCUfNjGlkgzAfxkdTyTrZYEtgOoBwUMuBrJNfFzFKGDMhUUEdiJcoBcKgtTltYzGhNqgNYUQEhxJHXoMGYwhxtBLNIHmhpZXIxjNSRDglwNYILUNNYrWxkWPltnSrjuUTvnqVZKHqfCJYKucqDzlJfNYCeaDNaDrftfPtQkGIExcLCvLTYavPtMtpVSpcEKQxl");
    int THGgtSexCBy = 406340148;
    double zbCfMHUYmB = -303779.9545708669;
    bool KbzptVLIcjxTJDGX = true;

    for (int VqYkrYqhZO = 1460004447; VqYkrYqhZO > 0; VqYkrYqhZO--) {
        UZkDjAlHUofQT += povhWmuHtUGJ;
    }

    for (int quLUVNmHMgAKfmD = 93106154; quLUVNmHMgAKfmD > 0; quLUVNmHMgAKfmD--) {
        continue;
    }

    for (int SAbUuFLvZtE = 520319367; SAbUuFLvZtE > 0; SAbUuFLvZtE--) {
        ohVkgmc += ohVkgmc;
        KbzptVLIcjxTJDGX = HTagtJPI;
    }

    for (int tphSLhgTW = 316174070; tphSLhgTW > 0; tphSLhgTW--) {
        continue;
    }

    return THGgtSexCBy;
}

yMezvUPnbFKTyv::yMezvUPnbFKTyv()
{
    this->RMarGeEsrWKHRd(true);
    this->GKSGxUwSr(string("AGbNuowpoMVWvHWzCkjpqUCVPNYoJS"), false, false, string("PjlbmclPKcjbjxGFItmXNqqVhhUumDkJavSlfdKhOFGulvErDEEWpCrRpi"));
    this->vutEb(-527905.6488073278, true);
    this->jgzcufiXwQCchtpQ(-572879.0158887597);
    this->gEMyZHjcdUJYU(string("agvgSEExeLePtTOgbYMiijvWOqQyChRfdIZOGAEMMJUdNOfiqvUceNSvIeVzhNzNaVoKbwNgXEhHEChTQgDlmdhYNlAOTJbudmKARjvJqBAdUAxnfifP"), true, false, false);
    this->ZPyBy(true);
    this->mrzrIcwyKtn(-533101.0265003021, -1326941170);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SIbDgdWcMVj
{
public:
    int CnJhNgJBDOkmHGQ;

    SIbDgdWcMVj();
protected:
    double eYTIaLWGrswmTh;
    string sqBbmXRfvACaJ;
    int BrWrn;

    bool PnUaIkePmsGPITuI();
    int pxorkriKPjcQYm(double RnNGENpm, int JIrdVCO, bool tXgaGuYYu);
    bool NjNRwZs();
    void mqFqySFSjHFims(double GydTRF, string vKFDkomPTp, int BtXXw, int ZRWjUSl);
    int vxxsCFOKWZ(double bzyxV, bool ejqhFhgLMz);
    string kQEMBqrXnaJtsHgr(int cOmktMR, bool EZejWKF, int RMNYYZA);
    int zsXdGUjbJ(bool GMsUkbH, bool RSUFf, int qcSdp);
private:
    int RYkAjmKEmWMlMUD;

    int GfUHqYxcNzYDp(bool fkyBGmJdr, double hBdvLPpkHVqdI, double KGKtxapJImxtEM);
    string IaIjAVVcCC(string zchVqJxgDPFhkC, bool afImnZjERnVyixNS, int bqbjKF, int ZUJXgJJ);
    void VxSnRZQ(double efzDM, double CFouTskOge, double rdZHRHpnCrT);
    double urOKFywGuR(double tmTIdEFrrq, string tCwZe, double TakxnSe);
};

bool SIbDgdWcMVj::PnUaIkePmsGPITuI()
{
    double lqnqojGhGwQ = -833506.1351766842;
    double rPNKoKJF = 598066.4072562837;
    int ykZVSOqiI = 1939561222;
    double fkyxOPJ = -681303.3763598596;
    string ctsEqw = string("uhHpGXWjEGIcAuoeZXMNCYXpcButbCrjeDbkSGCsnWYFDDIAKGsIkwMeRCGdYDNmiCQrNnesiwTMvHTbTizvjTFVmAXwsgikjJKtacTxKJgGgJTtyQBfEpOHvnDlxSzyzblfoVsbDvbcTYVoYwduGlQMtSdPkoBfnSJQunPFYgbidhdToQjrdzacngrdtSlvKbjJdlyhxLxWEtTTCtxVPVzKFHARisClkeXJWFPGWqhAXDXsKVDmMkGI");

    for (int rLwHzb = 782987527; rLwHzb > 0; rLwHzb--) {
        lqnqojGhGwQ /= lqnqojGhGwQ;
        fkyxOPJ /= lqnqojGhGwQ;
        lqnqojGhGwQ -= lqnqojGhGwQ;
        ctsEqw = ctsEqw;
    }

    for (int jFifSri = 1364910285; jFifSri > 0; jFifSri--) {
        lqnqojGhGwQ *= fkyxOPJ;
        rPNKoKJF *= rPNKoKJF;
    }

    for (int LCMidpm = 832123631; LCMidpm > 0; LCMidpm--) {
        fkyxOPJ *= rPNKoKJF;
        lqnqojGhGwQ = rPNKoKJF;
        fkyxOPJ /= lqnqojGhGwQ;
        fkyxOPJ = fkyxOPJ;
    }

    return true;
}

int SIbDgdWcMVj::pxorkriKPjcQYm(double RnNGENpm, int JIrdVCO, bool tXgaGuYYu)
{
    string aaiUBFEISkOAUhN = string("PhveHgtAyxsvAffyJtZHIuArmycjHnzbrHZLfMgirunWczlaUFnZSdLqRdgyXmBUDesfo");
    double ytHubajNvC = -553072.0764657615;
    double bsMzXqdxkYcpVWJd = 183487.85475079497;
    int ySDXhVZZRxuEVG = -63203524;
    string QfPcqbmypsJ = string("xUWfbvMvLNxWKcMGgkHWqILIwKazjlDCtNpPDqaNCTIkumILgPqDjEPACvkHYUKVIWCXLxlGWyDqkFfCNtysWaFEvgpruNfsbEnujRGyrMHCtyjdTfFLOpKoIVKVGRTIZFxfcOvbXXRxNYwxAirMjTIITOHqCMiuoQxjNhEKJtuF");
    string KvnAzCDg = string("TUNvJHFMGAZGlDVGVdqydbovMURwKEplKDVdproWWgFmEGmejyxWSpWxuGdkcUrBRUUAFovtjFUFaAnOmMBLftRhMoVrEVnOxWtfezRGcfahDcJmzVHCYdfMkomCPALWQlvzUfsDHWyfVpNvypCYthAzkxqEdPzsqvriWZOhBdXZDxxogcsDQBbgcJVThrFNdacpozjvthWeiIfjxEjASOhbEhdRcWpeBlUucvl");
    double nOGffyFslgJ = -982776.2292107526;

    if (nOGffyFslgJ > -749322.2695744475) {
        for (int pryphacITKui = 1273630812; pryphacITKui > 0; pryphacITKui--) {
            KvnAzCDg = aaiUBFEISkOAUhN;
        }
    }

    if (bsMzXqdxkYcpVWJd >= -749322.2695744475) {
        for (int aqguiEauDQmg = 2097721953; aqguiEauDQmg > 0; aqguiEauDQmg--) {
            continue;
        }
    }

    return ySDXhVZZRxuEVG;
}

bool SIbDgdWcMVj::NjNRwZs()
{
    int ruyNWWUVba = 426575073;
    double iLkDHir = -381763.00221626664;
    string uecjAAbfPpzl = string("GalBZfhEgqqamtDuPjNdEddLufbGbzqOhODdILecEdmNnQStHkaFhTQdGmxoCAtSdQDjchgmpOpyRsEsjFVwlGnlcuaAWGGtLjukGonWLqDUsbNLxTivZ");
    int MRRMfhdx = -72979114;
    int fJZDffPlkhBhiRy = -1943206691;
    string vvKaOKlSuBa = string("ranhrHJAncnCYEKrXYWOZnBClIVzjidCOLWvwQAKZiLDVMPXUZIusiCFyxmsAWCDSgcHQomezLYzMxptAxVlKqSHlBuzBMmOiEPrWvjpxIdWjjgXGBKkobafNSivgqRQWCRAVoUiBkZYnFqqYFCWBIRXXDUGadcwWsEeDesbHGfZCkQvIxpCgdxNpWvjbsvqxNjbgNjoFiotzAwgrbEYkUSMzytcprHUhmsJ");
    string JhTFVsTmA = string("syvAlAFQpMYkzdOaXFDHOweSYHOqtAcuguwxFUpHEWXBSaKebjxnkQpgUHOlVeAcDleQXNrMnHeyVgahZpiZVzUFLYyNpnSLogzssNfMDVkAsKYnYAQFjkgSYipHrajKUzdsyWGfRyBsajwgHCHmHyddtSiBrDJwvSPppWRMIcledw");
    string FIfzwwi = string("tFRPjztsgeQWOjYNbmPiudUuZbGqCheLmizPeQzyyUnozxsZaJBUoaCAiQtxDJkxdskf");
    int mwikunnJHVJI = -879042190;

    if (vvKaOKlSuBa <= string("tFRPjztsgeQWOjYNbmPiudUuZbGqCheLmizPeQzyyUnozxsZaJBUoaCAiQtxDJkxdskf")) {
        for (int KOWSxueKQ = 1720291607; KOWSxueKQ > 0; KOWSxueKQ--) {
            JhTFVsTmA = FIfzwwi;
            fJZDffPlkhBhiRy += ruyNWWUVba;
        }
    }

    if (vvKaOKlSuBa == string("ranhrHJAncnCYEKrXYWOZnBClIVzjidCOLWvwQAKZiLDVMPXUZIusiCFyxmsAWCDSgcHQomezLYzMxptAxVlKqSHlBuzBMmOiEPrWvjpxIdWjjgXGBKkobafNSivgqRQWCRAVoUiBkZYnFqqYFCWBIRXXDUGadcwWsEeDesbHGfZCkQvIxpCgdxNpWvjbsvqxNjbgNjoFiotzAwgrbEYkUSMzytcprHUhmsJ")) {
        for (int cqXaobLECrBALgJ = 1093096897; cqXaobLECrBALgJ > 0; cqXaobLECrBALgJ--) {
            JhTFVsTmA = FIfzwwi;
            FIfzwwi += uecjAAbfPpzl;
        }
    }

    return false;
}

void SIbDgdWcMVj::mqFqySFSjHFims(double GydTRF, string vKFDkomPTp, int BtXXw, int ZRWjUSl)
{
    int SqSbjx = -370630021;
    double GCUQplkMn = 1010378.7773320744;
    bool rtQcbpaKTsUpTb = true;
    double AilzzGfvHvHjEss = 925323.6856370128;
    bool DJcszR = false;
    string RvmBXMooLJSOMkE = string("VhlMfNnlefhhhBhkxCASvbpTxUjJUVMXAHXiOYdQAxPieTBdunoVWrIqnCteAVjgszUNyLynWLQKKudmSSwma");
    double XVGjiRhu = 290554.16389155516;
    double FVPYs = 758175.5919129541;
    string BevnuSJxrs = string("ibHbmPNjtvqZTkSyGzvykoWprPlScNPHMuFsihVcYdkyAKqQBmcrMOAovLvTRlwwTiRyJGhXnsBmppZfhiJgIxlPianfsRiTiBvOlCupFLFVGoGWwyArkyAyClZXGBjFNoYdbWbYYCDgLaPgkdturutJNtMksJqOjCukeuzy");

    for (int aELxHQa = 2144706809; aELxHQa > 0; aELxHQa--) {
        SqSbjx = ZRWjUSl;
        RvmBXMooLJSOMkE = vKFDkomPTp;
        ZRWjUSl = SqSbjx;
        GydTRF /= GCUQplkMn;
    }

    for (int BWahKiZwc = 242843557; BWahKiZwc > 0; BWahKiZwc--) {
        BevnuSJxrs += BevnuSJxrs;
        RvmBXMooLJSOMkE += vKFDkomPTp;
        AilzzGfvHvHjEss += AilzzGfvHvHjEss;
        BtXXw -= ZRWjUSl;
    }

    for (int LZxGyWFglpdfbqt = 1219192332; LZxGyWFglpdfbqt > 0; LZxGyWFglpdfbqt--) {
        DJcszR = DJcszR;
    }

    for (int tAWvvzngXmp = 1936216801; tAWvvzngXmp > 0; tAWvvzngXmp--) {
        continue;
    }
}

int SIbDgdWcMVj::vxxsCFOKWZ(double bzyxV, bool ejqhFhgLMz)
{
    int LuYXiRqLPqeg = 270484495;
    double zyghmMGAjVzM = 899894.7339554088;
    string amToSMdzmO = string("LiAMbeaidaQCtjkXcXoURXuNPqpgaVPGBVkodrIgkzHIIusqadKRQXPnQcvXaHjSdnaoMQVweLozWfDucEoCGZmiwHbYymmiwygrSSVWykYTuNVesbHsJeygcBBGMqGmaijdBsGvQvphCDnzztFZzZHip");
    string FWtmysAAPxwJ = string("ehTtKIIfNTmvSjpgvPgwYLbRhLydbHCjClBsAgSCBFQNUAfvNBXhRqHsReJFqAkaDvLbAAFpDkTLcwaZWk");

    return LuYXiRqLPqeg;
}

string SIbDgdWcMVj::kQEMBqrXnaJtsHgr(int cOmktMR, bool EZejWKF, int RMNYYZA)
{
    double jVDKO = -829856.5438499643;
    string ibwnqrrKZNTlFmc = string("qqnMMggZXCWsDwwvoKpqsNXvjqAzbIMnUDoRPoMyfEQmdVqEtzeLbHYCthjFIZZcwVkxsFDndiLYjDxjqAFNuqEYebDJUxbUJoLSjNCOIDwQdZArYELkdtPf");
    string UoJnU = string("lifLiGzDBQOSyYtswhGKWNqWYZftfSAkZkpflGWDnLViAfbdcaKKlgwUetdIOQMMpekQrqFoJeubAcUjoQpArzUepZStQlPpiDCaQyd");
    int HVpabEvZUrYuz = -1012254460;
    string YcIvZzkKdFa = string("aSMkCoxVnwzhPztnRDwvDCnmCFtEgSQbZGctqbCtLT");
    int aDtXNZmpcqZPFq = -444660228;
    bool HBLFLXPI = false;
    bool qBVCyjpMKZsTZvQz = false;
    double szygYShHke = 598000.4113359587;
    int GUrHxqB = -1965009820;

    for (int nVqJGAMdkKgIpsS = 1562720457; nVqJGAMdkKgIpsS > 0; nVqJGAMdkKgIpsS--) {
        continue;
    }

    for (int eWidkxUFmVNJfC = 2094167268; eWidkxUFmVNJfC > 0; eWidkxUFmVNJfC--) {
        GUrHxqB /= GUrHxqB;
        EZejWKF = qBVCyjpMKZsTZvQz;
    }

    return YcIvZzkKdFa;
}

int SIbDgdWcMVj::zsXdGUjbJ(bool GMsUkbH, bool RSUFf, int qcSdp)
{
    int pnOyhCVwU = -1391824988;
    double bBpRpVpblQ = 277846.7107918471;
    double LxWrqIr = -60574.52448965737;
    bool CLxRWKohNckjs = false;
    bool cUuTvKLabgxAjI = false;
    string QhwhTqPRowxpljIl = string("sBvGUTtQxlLczKDgqxUquZdvjOQRAYVTmezHwhsPHvVRZBQXuMkvNfaJfSzfBJaZDhpblxLoEhvIXhSgCSDubnhOAcokMLNgObOUiOzBpHZXpPjEDDrXlJNMpYWcHCVyGxeyIVSAvoCWFsaoqNOVygOcHMMMrWeMamHaMmLtZFYXbensKenbcZKXYEQhoXLfewwLyDgUFQnZXyEoPvllmpaTFlJOgWZSKXwmMfqwK");
    int dTWgmPdzVua = -242354086;
    double LqNOJxK = 651864.3147990092;
    string rjsLWgS = string("NNjOoMzgaRLdcPKvbRToVUbEeVtzVpEKhPSejcwImhcKyJHewPZYqjFHpzSdcmqetHuwxUYgvsSTTRRVdelVJmiAASbpNDFPjVUGsNlwMIGiYLmqcbKiqmXxfrfRtuaMXXqShuCYbwpSajDIrvlQZxKNwOzCynjIKwqdnWVAuyBECvbhjEbJgpnuTyPqkbXIMRiHslAYbyLmlaVmM");

    for (int FGpUcWLirKh = 2129179463; FGpUcWLirKh > 0; FGpUcWLirKh--) {
        LqNOJxK = bBpRpVpblQ;
    }

    for (int SnkZKw = 145331837; SnkZKw > 0; SnkZKw--) {
        LxWrqIr = LxWrqIr;
        qcSdp /= pnOyhCVwU;
    }

    for (int tTgXZsn = 407013821; tTgXZsn > 0; tTgXZsn--) {
        cUuTvKLabgxAjI = ! GMsUkbH;
        LqNOJxK -= bBpRpVpblQ;
    }

    for (int UffXNPovU = 1318381176; UffXNPovU > 0; UffXNPovU--) {
        continue;
    }

    return dTWgmPdzVua;
}

int SIbDgdWcMVj::GfUHqYxcNzYDp(bool fkyBGmJdr, double hBdvLPpkHVqdI, double KGKtxapJImxtEM)
{
    bool driNZtNfQMW = false;
    bool BdaihSpfYgT = false;
    bool DUoewzCKwiAVpkfB = true;
    bool JwsEwJ = false;
    string sINAnayY = string("fQzIPEdQnnOCRcOluNfgVosPEVrRbngdRMjtdwoOYtlrGoofKcSAxPwPfwzGqTSnDojfkLBzkQBPEoiVGaEsxuNkKimIURNcOWUMofDDjBJRjPzMOSEHVqJPeZJsSqwaeYfEiKuFYxOymWDlzAWDVlTCINAzhBJLhSjbaMcPKIrtBCXtDIGnA");

    if (hBdvLPpkHVqdI >= 635480.412699367) {
        for (int pUqLV = 565050790; pUqLV > 0; pUqLV--) {
            driNZtNfQMW = ! DUoewzCKwiAVpkfB;
            fkyBGmJdr = DUoewzCKwiAVpkfB;
        }
    }

    if (BdaihSpfYgT == false) {
        for (int XZWeVwQYWqBOXPI = 1352821419; XZWeVwQYWqBOXPI > 0; XZWeVwQYWqBOXPI--) {
            JwsEwJ = ! DUoewzCKwiAVpkfB;
            JwsEwJ = ! BdaihSpfYgT;
            hBdvLPpkHVqdI *= hBdvLPpkHVqdI;
            KGKtxapJImxtEM -= hBdvLPpkHVqdI;
            hBdvLPpkHVqdI /= KGKtxapJImxtEM;
            BdaihSpfYgT = JwsEwJ;
        }
    }

    if (BdaihSpfYgT == false) {
        for (int YPMKJvXpPIRTWai = 1344434087; YPMKJvXpPIRTWai > 0; YPMKJvXpPIRTWai--) {
            DUoewzCKwiAVpkfB = ! driNZtNfQMW;
            hBdvLPpkHVqdI /= hBdvLPpkHVqdI;
            fkyBGmJdr = ! JwsEwJ;
            fkyBGmJdr = ! fkyBGmJdr;
            driNZtNfQMW = ! BdaihSpfYgT;
        }
    }

    if (sINAnayY >= string("fQzIPEdQnnOCRcOluNfgVosPEVrRbngdRMjtdwoOYtlrGoofKcSAxPwPfwzGqTSnDojfkLBzkQBPEoiVGaEsxuNkKimIURNcOWUMofDDjBJRjPzMOSEHVqJPeZJsSqwaeYfEiKuFYxOymWDlzAWDVlTCINAzhBJLhSjbaMcPKIrtBCXtDIGnA")) {
        for (int UTZdJCVzxbXKRbC = 312343935; UTZdJCVzxbXKRbC > 0; UTZdJCVzxbXKRbC--) {
            JwsEwJ = ! DUoewzCKwiAVpkfB;
        }
    }

    for (int xveQwGRs = 1090619154; xveQwGRs > 0; xveQwGRs--) {
        BdaihSpfYgT = ! fkyBGmJdr;
        fkyBGmJdr = DUoewzCKwiAVpkfB;
        driNZtNfQMW = driNZtNfQMW;
        fkyBGmJdr = JwsEwJ;
    }

    return -1658026932;
}

string SIbDgdWcMVj::IaIjAVVcCC(string zchVqJxgDPFhkC, bool afImnZjERnVyixNS, int bqbjKF, int ZUJXgJJ)
{
    int zySlKSZrYXQ = -1189224334;
    string TdXXKLbNLEYjk = string("KQSzWIHqodNcdnSahFYFsdpjXMXTRFnkwhjQBXltSOseZHbeIqOytgepkAVeXBebXUOvWGCZraccsJEwFqXZOeJWvqhaMNjVckjhikvRzXRJGYKuMlqPodkccIlqpdddaxrLpJqYeyRvcVQCSptBElgqsciYWBaESSQzGNdtZgVNfutlxQWaVyNyJsNOulWouIvotFaQstnAmPVNGqRzUlYEOvNIh");
    bool EkyItHlB = false;
    bool YbIcxFsmJeweDiI = true;
    string sXtHSlrgXLoBxIxw = string("vIYntYRUXsqbVdGtlxhWoorZnyWJZjQinMBNPQVorntaRIbhGtXoQVGlTpzrUozcWYtNeqAYzOSQJaRQhZuKItKkRijmeSFZMjwvXlNDoDTTUGiGuAtwsZdQIIiaoshVfjnxURnrccmSSdTcInaNVcCbuIWTADeEyFaoHMsmqKOgUYyFcyPsjAHMmUOwGFyIJxNlkr");
    bool RWuGD = false;
    int lOhUQlhNJtOxN = -1672124164;
    double afLIhvwHSeqi = 7701.632149551745;

    if (EkyItHlB == false) {
        for (int euZUkOMKpPirj = 2005825275; euZUkOMKpPirj > 0; euZUkOMKpPirj--) {
            continue;
        }
    }

    for (int iKNexEL = 549128489; iKNexEL > 0; iKNexEL--) {
        afImnZjERnVyixNS = ! afImnZjERnVyixNS;
        zySlKSZrYXQ *= ZUJXgJJ;
    }

    if (zySlKSZrYXQ >= -1672124164) {
        for (int inLCVejfWm = 2000709762; inLCVejfWm > 0; inLCVejfWm--) {
            sXtHSlrgXLoBxIxw += TdXXKLbNLEYjk;
            afImnZjERnVyixNS = afImnZjERnVyixNS;
            lOhUQlhNJtOxN = lOhUQlhNJtOxN;
            afLIhvwHSeqi *= afLIhvwHSeqi;
        }
    }

    return sXtHSlrgXLoBxIxw;
}

void SIbDgdWcMVj::VxSnRZQ(double efzDM, double CFouTskOge, double rdZHRHpnCrT)
{
    double mWoITnrNMSf = -256969.23575561136;
    string EGDaDLHKpujr = string("XyWCNavKifcCKRAcqojVGQpqdlQPPqoBWLwXyihGqLQtlkdrpSoavSPzsuAGpqxqANzPVqpfQSOdYUJLqdVpUKECfjkmetnGIeErxJw");
    int qffuWF = 564278585;
    double ZVqMnfxUDHrmWGqA = -1031566.5482525539;
    double afslHMmHUoFTsZiP = -304352.07456990663;
    bool jnDUwuReHOVYlRA = false;
    string UwLJHCdEdMVK = string("ZwMqAjXVtTaLbxTLzVicPsAgUFeGqwqWvoVPBLPnhMUtZRIFCgAAYAIqniDodCrJKlimGgKCiqXFxyRsvaVERey");
    bool ITLGbRqJnBk = true;

    for (int LULDTzwMKC = 1698133737; LULDTzwMKC > 0; LULDTzwMKC--) {
        rdZHRHpnCrT += rdZHRHpnCrT;
        ZVqMnfxUDHrmWGqA /= efzDM;
    }
}

double SIbDgdWcMVj::urOKFywGuR(double tmTIdEFrrq, string tCwZe, double TakxnSe)
{
    double kAfePufZPclmqnlz = -492628.80159980484;
    double oKBOVNgrbVczFr = -530161.7360842807;
    double sDjSWqFKtg = 458502.7146032644;

    if (tmTIdEFrrq != -492628.80159980484) {
        for (int QmiiQoBvOli = 355927238; QmiiQoBvOli > 0; QmiiQoBvOli--) {
            TakxnSe /= oKBOVNgrbVczFr;
        }
    }

    if (oKBOVNgrbVczFr <= 458502.7146032644) {
        for (int CQpByG = 958885488; CQpByG > 0; CQpByG--) {
            tCwZe += tCwZe;
            oKBOVNgrbVczFr = tmTIdEFrrq;
            TakxnSe *= kAfePufZPclmqnlz;
            kAfePufZPclmqnlz /= kAfePufZPclmqnlz;
            kAfePufZPclmqnlz += TakxnSe;
            TakxnSe -= kAfePufZPclmqnlz;
            kAfePufZPclmqnlz = tmTIdEFrrq;
        }
    }

    for (int UILbasdpMNrA = 681865190; UILbasdpMNrA > 0; UILbasdpMNrA--) {
        oKBOVNgrbVczFr += kAfePufZPclmqnlz;
        kAfePufZPclmqnlz = kAfePufZPclmqnlz;
        TakxnSe = kAfePufZPclmqnlz;
    }

    return sDjSWqFKtg;
}

SIbDgdWcMVj::SIbDgdWcMVj()
{
    this->PnUaIkePmsGPITuI();
    this->pxorkriKPjcQYm(-749322.2695744475, 907132353, true);
    this->NjNRwZs();
    this->mqFqySFSjHFims(-726308.9177664649, string("QNLYqSYpfvkAnywemUdxqyfaANATjynvkkVYSGcsslsuOEfgvPNwTktsvGELxBcttobTNwkGpupnXXMEMdNjryAgTlsmCSiNuwZiTidApBlfhzkbCEcpTCjNtbrVsRDHLqMGbCGTopyRuPdZYpZWLFqbWAUqQlrNrkSfeiJyEco"), 101606801, 392946130);
    this->vxxsCFOKWZ(-632981.0445129165, true);
    this->kQEMBqrXnaJtsHgr(-123372440, false, 1964461554);
    this->zsXdGUjbJ(true, true, -392078259);
    this->GfUHqYxcNzYDp(true, -717572.2289634706, 635480.412699367);
    this->IaIjAVVcCC(string("qrXQVXSJfVlnaZgxbOoncgTOOreByWPravLBslvRKjSPoDHcf"), false, 1265762717, 250698169);
    this->VxSnRZQ(-579728.5783890303, 52456.0371282779, -1009802.5677274253);
    this->urOKFywGuR(659685.2686963677, string("XGguJfjooTSSHGnfKF"), -870787.4349145618);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gEyjMNmkkgac
{
public:
    string EpIWtpiuRYcppE;
    double iHwGdcnPIylwm;
    string EtBIycJbl;

    gEyjMNmkkgac();
    string SOdLGgTPGvGqawuZ(int ZNmEpApcXBntfdOt, string uIysdZ, int HLPPx, bool bSnZXvkXKGEW);
    double cMwwU(string kMUYmwCpyKGonJl);
    int caNMviKiDapBDoCb(double BFRmAKLYgxqTia, double phQoFrENFeLPY);
    void GOpeKfiXhrFusQ(bool rxeOoycqUZqmJbS, double tBljtmZ, double PkTKLDQwGtz, string FDjVAanGVMw);
protected:
    string nvMqQNmLhbiYR;
    int vVprqDkfrcOYs;
    bool OtcKf;
    int tTzZvVFpQ;

    string jVBFpUxIZAe(string adRPEWYeqN, string FmgtIWCOyVYDIE);
    string HWCfxHVNVGGsr();
    double ttFsmwsKTpUB(bool MloUmweedVUpyXZ);
    void RVStCilCyJTX(int ViHoEqHJsRmRj);
    double igHubHYiO();
    string ahIbcQmqJKZ(double kExDRFUPsvtTvIB);
private:
    double WtOncZBsDz;

};

string gEyjMNmkkgac::SOdLGgTPGvGqawuZ(int ZNmEpApcXBntfdOt, string uIysdZ, int HLPPx, bool bSnZXvkXKGEW)
{
    bool qMffCUmcsCK = false;
    int XfKFXuqsbOnxuHD = 199603303;

    for (int PlYlmQUQVUeTBMU = 436820921; PlYlmQUQVUeTBMU > 0; PlYlmQUQVUeTBMU--) {
        uIysdZ = uIysdZ;
        qMffCUmcsCK = qMffCUmcsCK;
        XfKFXuqsbOnxuHD *= XfKFXuqsbOnxuHD;
    }

    for (int qbEEZC = 1646555774; qbEEZC > 0; qbEEZC--) {
        qMffCUmcsCK = qMffCUmcsCK;
    }

    if (HLPPx != -1903478825) {
        for (int CvWWHfnDxwKtY = 1538042960; CvWWHfnDxwKtY > 0; CvWWHfnDxwKtY--) {
            bSnZXvkXKGEW = ! bSnZXvkXKGEW;
        }
    }

    return uIysdZ;
}

double gEyjMNmkkgac::cMwwU(string kMUYmwCpyKGonJl)
{
    double zIPkQz = 24841.35657275091;
    double ZwYLODy = -364055.59438387636;

    if (zIPkQz <= 24841.35657275091) {
        for (int IeZAcgbvgYcxsq = 1925196956; IeZAcgbvgYcxsq > 0; IeZAcgbvgYcxsq--) {
            kMUYmwCpyKGonJl = kMUYmwCpyKGonJl;
            kMUYmwCpyKGonJl += kMUYmwCpyKGonJl;
        }
    }

    if (zIPkQz > 24841.35657275091) {
        for (int FpNxHihlUHe = 980141834; FpNxHihlUHe > 0; FpNxHihlUHe--) {
            continue;
        }
    }

    for (int QIOSTSwBX = 1875483913; QIOSTSwBX > 0; QIOSTSwBX--) {
        ZwYLODy /= ZwYLODy;
    }

    return ZwYLODy;
}

int gEyjMNmkkgac::caNMviKiDapBDoCb(double BFRmAKLYgxqTia, double phQoFrENFeLPY)
{
    bool bsiatXpouZlQaVp = false;
    bool nnpkzoQ = true;
    bool lcHbX = true;
    bool HzSJeXJ = true;
    int JUbkdHDm = -1269733853;
    double ZTILJpe = 1003829.4550912;
    int cmlENlalBBkidpP = 92308435;
    bool lheBIiRcWeVqJ = true;
    double UQbZDenyzsv = 724716.3147833439;
    bool gvyiscWFuyYoMcws = true;

    for (int qkXdcQsaJScXDOdX = 1414978355; qkXdcQsaJScXDOdX > 0; qkXdcQsaJScXDOdX--) {
        BFRmAKLYgxqTia *= ZTILJpe;
    }

    for (int QyVJcD = 1284968054; QyVJcD > 0; QyVJcD--) {
        lheBIiRcWeVqJ = ! HzSJeXJ;
        UQbZDenyzsv /= phQoFrENFeLPY;
        lheBIiRcWeVqJ = ! bsiatXpouZlQaVp;
        lheBIiRcWeVqJ = lheBIiRcWeVqJ;
    }

    for (int hTzJkZw = 1656433196; hTzJkZw > 0; hTzJkZw--) {
        bsiatXpouZlQaVp = ! bsiatXpouZlQaVp;
        bsiatXpouZlQaVp = lheBIiRcWeVqJ;
    }

    for (int CtZTA = 677768165; CtZTA > 0; CtZTA--) {
        lheBIiRcWeVqJ = gvyiscWFuyYoMcws;
        BFRmAKLYgxqTia /= UQbZDenyzsv;
        HzSJeXJ = ! bsiatXpouZlQaVp;
    }

    if (nnpkzoQ != true) {
        for (int taZdngdXC = 68244035; taZdngdXC > 0; taZdngdXC--) {
            lcHbX = ! HzSJeXJ;
            JUbkdHDm += JUbkdHDm;
        }
    }

    return cmlENlalBBkidpP;
}

void gEyjMNmkkgac::GOpeKfiXhrFusQ(bool rxeOoycqUZqmJbS, double tBljtmZ, double PkTKLDQwGtz, string FDjVAanGVMw)
{
    string DOZPhZHEiaab = string("PyhFUvCzPGxYqxMGHfRdcUyhXOvTagUidqVckBNrcRTZAYAsdlJAqEwFThfMjdlQbGJBOrYtDohOLshCMIFrHgdNsgYGSuNKuuvvVvsGzTjFtaRECiMHOuKQztiUdRHqHwtyNXfIhLNzNoOythYZIjkFoPfYYxGHAOuHcowELXuLhfwsQrBjFCjEzdHThihfVUkxGjUkksHiLesrhuLfUMwCdwwKNmplWKeJkrtRsfPgHr");
    int DkcKpgTjdjpuXobe = 1229457737;
    double TFhHYdaXL = -108464.515129987;
    bool tqIjRePlMOJSjkJ = false;
    bool NgFueZ = true;
    int sXkOz = 1320067035;
    double TwpNmKGVy = -927945.164577264;
    bool wQdYLEHkIQc = false;
    bool wJtMynCDezijL = true;
    double eTJsTWpjBgvNiWm = -481263.69822667504;

    for (int ABUAzXNBWDGgFK = 50858915; ABUAzXNBWDGgFK > 0; ABUAzXNBWDGgFK--) {
        rxeOoycqUZqmJbS = ! rxeOoycqUZqmJbS;
        wQdYLEHkIQc = ! wQdYLEHkIQc;
    }

    for (int cuYYAcMxnFqcRU = 2097641167; cuYYAcMxnFqcRU > 0; cuYYAcMxnFqcRU--) {
        continue;
    }

    for (int DMDCA = 1617192378; DMDCA > 0; DMDCA--) {
        wJtMynCDezijL = NgFueZ;
    }

    for (int KNTXzX = 1454642179; KNTXzX > 0; KNTXzX--) {
        wJtMynCDezijL = rxeOoycqUZqmJbS;
        TwpNmKGVy *= PkTKLDQwGtz;
    }

    for (int XfJDfpEi = 315222539; XfJDfpEi > 0; XfJDfpEi--) {
        wQdYLEHkIQc = ! NgFueZ;
        NgFueZ = NgFueZ;
        PkTKLDQwGtz *= tBljtmZ;
        TwpNmKGVy += eTJsTWpjBgvNiWm;
        PkTKLDQwGtz *= tBljtmZ;
    }
}

string gEyjMNmkkgac::jVBFpUxIZAe(string adRPEWYeqN, string FmgtIWCOyVYDIE)
{
    int egLyvsrIrCifiTa = -617262559;
    int VCiiyGAmTiRB = -1405806477;

    for (int xnkWd = 128730130; xnkWd > 0; xnkWd--) {
        VCiiyGAmTiRB -= egLyvsrIrCifiTa;
    }

    for (int vySnQ = 893768482; vySnQ > 0; vySnQ--) {
        continue;
    }

    if (FmgtIWCOyVYDIE >= string("bvskVJRvwoXTeeQRyRzNVwolGkxykOEfWauYCObypDyeNFTKExvyxrHnybMaiHIrOrndfrQSXzlzVQsUVEytbwkjNkvkxTbHMtHdAmgnHkttqkwiEHEaSxyecSmqYa")) {
        for (int MAJHLjBjf = 2005483583; MAJHLjBjf > 0; MAJHLjBjf--) {
            FmgtIWCOyVYDIE = FmgtIWCOyVYDIE;
            egLyvsrIrCifiTa *= VCiiyGAmTiRB;
            adRPEWYeqN += adRPEWYeqN;
            adRPEWYeqN += adRPEWYeqN;
            FmgtIWCOyVYDIE = adRPEWYeqN;
            egLyvsrIrCifiTa -= egLyvsrIrCifiTa;
            FmgtIWCOyVYDIE = FmgtIWCOyVYDIE;
        }
    }

    if (FmgtIWCOyVYDIE > string("bvskVJRvwoXTeeQRyRzNVwolGkxykOEfWauYCObypDyeNFTKExvyxrHnybMaiHIrOrndfrQSXzlzVQsUVEytbwkjNkvkxTbHMtHdAmgnHkttqkwiEHEaSxyecSmqYa")) {
        for (int TAcrmL = 756088641; TAcrmL > 0; TAcrmL--) {
            egLyvsrIrCifiTa = egLyvsrIrCifiTa;
            VCiiyGAmTiRB /= egLyvsrIrCifiTa;
        }
    }

    if (VCiiyGAmTiRB >= -1405806477) {
        for (int NEJCeVigBRK = 124420558; NEJCeVigBRK > 0; NEJCeVigBRK--) {
            egLyvsrIrCifiTa += VCiiyGAmTiRB;
        }
    }

    return FmgtIWCOyVYDIE;
}

string gEyjMNmkkgac::HWCfxHVNVGGsr()
{
    double vPsbuXGwuGcPodEy = 178821.94705655632;

    if (vPsbuXGwuGcPodEy != 178821.94705655632) {
        for (int JkxZnfIdbOWIj = 616883480; JkxZnfIdbOWIj > 0; JkxZnfIdbOWIj--) {
            vPsbuXGwuGcPodEy /= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy = vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy = vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy /= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy = vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
        }
    }

    if (vPsbuXGwuGcPodEy <= 178821.94705655632) {
        for (int OEfotBtnSoSqWj = 1774969211; OEfotBtnSoSqWj > 0; OEfotBtnSoSqWj--) {
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy = vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy /= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
        }
    }

    if (vPsbuXGwuGcPodEy > 178821.94705655632) {
        for (int DlRQrgd = 1692769723; DlRQrgd > 0; DlRQrgd--) {
            vPsbuXGwuGcPodEy = vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
        }
    }

    if (vPsbuXGwuGcPodEy != 178821.94705655632) {
        for (int eMhgEFPiUqQteRy = 764580840; eMhgEFPiUqQteRy > 0; eMhgEFPiUqQteRy--) {
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
        }
    }

    if (vPsbuXGwuGcPodEy >= 178821.94705655632) {
        for (int ePWvcV = 1532505715; ePWvcV > 0; ePWvcV--) {
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy -= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy *= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy = vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy /= vPsbuXGwuGcPodEy;
            vPsbuXGwuGcPodEy += vPsbuXGwuGcPodEy;
        }
    }

    return string("krDAwMPohVoxzcEkRWDiWKrbSsuGfNxslfHMVsZhAeWYEQrMfmnSjqGankhhmsAfpNeMkLBpcTdchINxFcNXpIlfdovPnmYfQlVzAXyjwXEibKFvcHuuyFnFpzixByuvFCLXlrlioknfeeSEhAIqsoNecQJLuRhPmBakDuxHrjTPCDipkbIjFswtmQPnggyRbxwUUpeZuHuHrYV");
}

double gEyjMNmkkgac::ttFsmwsKTpUB(bool MloUmweedVUpyXZ)
{
    int kceoKBeNAOfgkr = -2051035411;
    double DvOtCbZgWzKBMESw = 482982.0722036315;
    bool OgYaHPZZBL = false;

    for (int YAMogJGfR = 452640680; YAMogJGfR > 0; YAMogJGfR--) {
        OgYaHPZZBL = MloUmweedVUpyXZ;
        MloUmweedVUpyXZ = ! OgYaHPZZBL;
    }

    for (int wSglIsFqqYf = 1675608980; wSglIsFqqYf > 0; wSglIsFqqYf--) {
        MloUmweedVUpyXZ = OgYaHPZZBL;
        kceoKBeNAOfgkr = kceoKBeNAOfgkr;
    }

    if (DvOtCbZgWzKBMESw == 482982.0722036315) {
        for (int WztkdYwmZuHdkvB = 608100807; WztkdYwmZuHdkvB > 0; WztkdYwmZuHdkvB--) {
            MloUmweedVUpyXZ = ! OgYaHPZZBL;
        }
    }

    for (int KEUEQSN = 544142950; KEUEQSN > 0; KEUEQSN--) {
        MloUmweedVUpyXZ = ! OgYaHPZZBL;
        MloUmweedVUpyXZ = OgYaHPZZBL;
        MloUmweedVUpyXZ = MloUmweedVUpyXZ;
        OgYaHPZZBL = OgYaHPZZBL;
    }

    return DvOtCbZgWzKBMESw;
}

void gEyjMNmkkgac::RVStCilCyJTX(int ViHoEqHJsRmRj)
{
    string lCiLJQS = string("ZipmQlzpZAJtswlhCZY");
    bool xNhxwliyhFdpC = true;
    string jSFKGxw = string("UHkgiuMRQgBorANLfKiLdJbMcTYKymbpUTSEk");
    bool jQiKaUsvUmCS = false;
    double IaqCuFwWzJndcC = 305807.6692446711;
    string zoBwZxvor = string("pOTNUymNrecAAhubDgwGWvDJWyBWtjTjIKejgXJmzNldREkQCMxmqrJKsUigPAsSgJwXfKcksEEGsAZqQnKpJWLnigbvoPkOIRcNGFfXqyzkVfO");
    bool HjHTuu = true;
    double mypJSjXtwZDXf = -151260.99101257586;
    string zuvQtqFsufgzuON = string("fHxowRyWAzBYFeWOpezoAaSKbQYgPvpXNWtPNiSDNrzxEezfWMyxDGoPpvgseWeWRtCjyUZFnmMVQmoNHHtweesmkCeDOgWNzfmYkhmYGfYSDIzHKjSuZIQgFKuprvIKnphhUHTOcwyyjrHdhZLuRJEu");

    for (int piIuCW = 366114088; piIuCW > 0; piIuCW--) {
        continue;
    }

    for (int Gdyqw = 1828496590; Gdyqw > 0; Gdyqw--) {
        continue;
    }
}

double gEyjMNmkkgac::igHubHYiO()
{
    string DxRughyCnimF = string("jbpYajycastcciFgbQQkGkAarXSoKMFcimnivHHhyRLwILBCgvWztgEIwfgLCJEStWxmLYDbXrrkspcbZiWNfFZmPkgiDlEyhofEUJ");
    double qLDwDEPkdZdKD = -945737.2766112887;
    string fSJlfqkmCdOhDx = string("ZWmUxNVIrXNWyIXRaCLNvfaQMxxZqlfuXpgNtInxQHpiXLSZKQzNrqkzSmEWitvsnVsXGRrrZRXZHyDBSJhotWKDzhQpXyceZNJbVPgWHIflbtwPAFGsYsCbqYvmjyRwMhPpSwrMxWLXrosFeCqzZcbciFWITOIPoix");
    double MlMrzaR = 180053.9233296943;
    double lEDhmGbc = 578501.8634752969;
    string YfOHVLkR = string("vNwgIAhfuEskpRFLQrOToDijHyNJFFzfkc");
    bool zOGOrQnvHmjUvh = false;
    string inBcteyczjNnuk = string("QkwZjramNkavTfzWimnzvFIWWZYqMdckV");

    if (qLDwDEPkdZdKD < -945737.2766112887) {
        for (int VAbOlowkWML = 539073664; VAbOlowkWML > 0; VAbOlowkWML--) {
            MlMrzaR /= qLDwDEPkdZdKD;
        }
    }

    if (DxRughyCnimF != string("vNwgIAhfuEskpRFLQrOToDijHyNJFFzfkc")) {
        for (int SbmbluGfqfBKLVdn = 2143797255; SbmbluGfqfBKLVdn > 0; SbmbluGfqfBKLVdn--) {
            fSJlfqkmCdOhDx += inBcteyczjNnuk;
            YfOHVLkR = DxRughyCnimF;
            MlMrzaR /= lEDhmGbc;
        }
    }

    if (fSJlfqkmCdOhDx >= string("vNwgIAhfuEskpRFLQrOToDijHyNJFFzfkc")) {
        for (int TKYtqWTZdgdoEBQ = 104987682; TKYtqWTZdgdoEBQ > 0; TKYtqWTZdgdoEBQ--) {
            fSJlfqkmCdOhDx = fSJlfqkmCdOhDx;
            fSJlfqkmCdOhDx += fSJlfqkmCdOhDx;
        }
    }

    for (int hKfJTFAQu = 1257140449; hKfJTFAQu > 0; hKfJTFAQu--) {
        lEDhmGbc -= lEDhmGbc;
        YfOHVLkR += YfOHVLkR;
        lEDhmGbc = MlMrzaR;
        lEDhmGbc *= qLDwDEPkdZdKD;
        fSJlfqkmCdOhDx = DxRughyCnimF;
    }

    return lEDhmGbc;
}

string gEyjMNmkkgac::ahIbcQmqJKZ(double kExDRFUPsvtTvIB)
{
    double rtYActCmyIw = 230291.17873698854;
    bool dptuBVxEK = false;
    int DtHxK = -1067846720;
    double vMwsjQlj = -926927.3301375341;
    string CliVxtptjeC = string("yRfXvdZGChACTNwhmEjsLqirLHQDeEchspSQnUpPTHFWtOZRuOfwCQkcBrUVavwwqIzSYuVlk");

    if (vMwsjQlj < -926927.3301375341) {
        for (int gNtQOBrjLlLwHYg = 267380837; gNtQOBrjLlLwHYg > 0; gNtQOBrjLlLwHYg--) {
            kExDRFUPsvtTvIB += rtYActCmyIw;
            vMwsjQlj /= rtYActCmyIw;
            vMwsjQlj += rtYActCmyIw;
            DtHxK = DtHxK;
            vMwsjQlj *= vMwsjQlj;
        }
    }

    for (int BhWXQwTrUXJ = 1570055832; BhWXQwTrUXJ > 0; BhWXQwTrUXJ--) {
        vMwsjQlj -= kExDRFUPsvtTvIB;
    }

    for (int werzPjS = 964336038; werzPjS > 0; werzPjS--) {
        kExDRFUPsvtTvIB *= vMwsjQlj;
        rtYActCmyIw += rtYActCmyIw;
        rtYActCmyIw *= vMwsjQlj;
        DtHxK *= DtHxK;
    }

    return CliVxtptjeC;
}

gEyjMNmkkgac::gEyjMNmkkgac()
{
    this->SOdLGgTPGvGqawuZ(-1903478825, string("CFLKTaVsTzRhdunktVgoNjjmvTIEHnJiSCamTqklVlTlnMzSyhnnDOSiXobXhqZrSNWTOTaLPOqYCFlTWwFUETTVUduvVPIhdjGZf"), 1300689502, false);
    this->cMwwU(string("KkCeBJYXStXAMhiAZPDMExcBubzbwLnBInXKciJwdePiQRysbqymIQVJFgzjJXxLntKDWDDtzzLogGvCmARHyBqEslhAkFNLehxaAdqKzhWcFreaAT"));
    this->caNMviKiDapBDoCb(-802941.4819566815, -62822.62202323299);
    this->GOpeKfiXhrFusQ(false, 1028779.3232871967, -648144.5526941767, string("sldtwqAMWfqxdDYUXgrMxbHuvWObHXfPGZcrZSRfQsCqNAlDqNFAsEkBobcAPJkQOERCoyzUrsMQXySCgVCMOnOMUdCGSyrhTRGSPypACfzRFfSJhsQemlUOYhiYfAFHMJgaQHYBgqoXxNHmxfsahrKDIgICCdhogOYmsbFZZnRzbaFTdYQsIEKwmFzTgcUIyhUBjTiYAhSFQkDkUBhlGTLmQiUFSPj"));
    this->jVBFpUxIZAe(string("SRaEzigcTWeZZCArSLcuPbtIpZBQoFuHhZBMCTPwwzfWNDdTWtjyIczJYnfPxBjrXfFCKPihAzrDILCqJZvGYhtYBgNhaPECyVfHViJZlqBDSnjeuHJUInjpdRuijfePvUzGzhyeQTRoaeSkSZXGRHIzQESdSmqz"), string("bvskVJRvwoXTeeQRyRzNVwolGkxykOEfWauYCObypDyeNFTKExvyxrHnybMaiHIrOrndfrQSXzlzVQsUVEytbwkjNkvkxTbHMtHdAmgnHkttqkwiEHEaSxyecSmqYa"));
    this->HWCfxHVNVGGsr();
    this->ttFsmwsKTpUB(false);
    this->RVStCilCyJTX(951876037);
    this->igHubHYiO();
    this->ahIbcQmqJKZ(-15915.664294956707);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class czvjgmWDvjnms
{
public:
    int PZNjkfRI;
    double KNJLYpsD;
    bool daVWGzPv;
    double sohUsWTpA;
    string vEUzHLHs;
    int PquXdWBmzqd;

    czvjgmWDvjnms();
    string BkirLmiD();
    void gKesBfPur(bool FPYjVvdgJ, int eyPOCu);
    string ynQRBwVhmLtFXylc(string IaujCL);
    void klEQlcA(string BscLGhnWNnqUb, string kbnko, int iHQapiivUJWQNei);
    int mygiFE(string INkfSxcBkRwlrf, double ERmsaICwOeKFicu, bool ObsYNkZ, string ZfAoSbIVDtLjcr);
    void gjlCflAtHjUqjtmG(bool PwnTgsx);
    void TBXEVJQfOSrHphl();
protected:
    bool uUiCDxVoTARjN;
    bool czTOugaEHqQf;
    string dXVGLDXPfgrLGwW;
    double uKbwK;

    string cnvznkIp(bool TdtbYYms, string vSQvXkkLUpKhkqs, int XrnHDjeeIDpIVM);
    double EdUpGyWSzOdpp(bool CCMOtIUFtXbRnI, int BYJBeCk, int tJGYrwHebRkLj, bool wJBEdHlYKNnZv);
    bool NuLJNf(string eYqpxBKytMzJlQPD, double ERhwxMIkuW, string MUzQSvsOIqmnBo, double PECUqJNrFr, string iCVYiv);
    int jYbAspzXR(int BtnWNYeNgEmbUrrP, double kcCJCVhwIBcn);
    int bQPApVuoihsO(int iVqhW, string BDBYju);
private:
    bool WcDSO;
    double mUNMYvlXcqFgG;
    double qDFxuY;
    string BDUgqivENYg;
    double dQQhlXRyLw;

    void nnLsdfJUYDDHQRNH(bool sFSkTXOWfIE, double eLglA, double HCkpzzM, string OCnMvzO);
};

string czvjgmWDvjnms::BkirLmiD()
{
    double aaxKSyrj = 56203.5457728969;
    string lLIdmyIJUNeEJt = string("CeJxAJjWznuNTMaNUvYBXHzVzm");
    int ExYuwIkshORRqLZN = 932202450;
    bool BiuAtqTS = true;
    int mbiqF = 1248111994;
    bool aYSjb = false;

    for (int uOPYbuNVMey = 2054211102; uOPYbuNVMey > 0; uOPYbuNVMey--) {
        continue;
    }

    for (int OjDuMUoRbWvRy = 62899721; OjDuMUoRbWvRy > 0; OjDuMUoRbWvRy--) {
        aYSjb = ! aYSjb;
        ExYuwIkshORRqLZN = mbiqF;
    }

    if (ExYuwIkshORRqLZN <= 932202450) {
        for (int GpCrFpJrZrYFNmJl = 546266895; GpCrFpJrZrYFNmJl > 0; GpCrFpJrZrYFNmJl--) {
            aYSjb = aYSjb;
            ExYuwIkshORRqLZN /= ExYuwIkshORRqLZN;
        }
    }

    return lLIdmyIJUNeEJt;
}

void czvjgmWDvjnms::gKesBfPur(bool FPYjVvdgJ, int eyPOCu)
{
    bool OYjuF = false;
    bool IkOyAmOa = true;
    int GXMyLpJqt = -1736195233;
    double JUIDUnzLufCbViqH = -999057.9697492097;
    string ozzWtLW = string("gFKSRFEGPxNgHxRkljhQCSmtlooEAMKr");
    int gZnsrslueyQvxUg = -1806587642;
    bool RzYeQrIHFtK = true;

    for (int VYhbO = 8614883; VYhbO > 0; VYhbO--) {
        continue;
    }

    for (int hMFecLOTKms = 1347081076; hMFecLOTKms > 0; hMFecLOTKms--) {
        JUIDUnzLufCbViqH -= JUIDUnzLufCbViqH;
        IkOyAmOa = ! FPYjVvdgJ;
        RzYeQrIHFtK = RzYeQrIHFtK;
    }
}

string czvjgmWDvjnms::ynQRBwVhmLtFXylc(string IaujCL)
{
    int CFpVPFxUjWfBSz = -1189656801;
    bool ZXdcxgckrTs = true;
    int BJWimVFIUiQMjv = 2099448975;

    for (int hKuIFqcyDVqyv = 565983823; hKuIFqcyDVqyv > 0; hKuIFqcyDVqyv--) {
        CFpVPFxUjWfBSz /= BJWimVFIUiQMjv;
        IaujCL += IaujCL;
    }

    return IaujCL;
}

void czvjgmWDvjnms::klEQlcA(string BscLGhnWNnqUb, string kbnko, int iHQapiivUJWQNei)
{
    double hCyJsBKSnHARO = 763777.1908323816;
    string ryIlUYooDUFTCG = string("MiyFOmCw");
    string OBPDUmsvlyR = string("JpzviNNFrlwvileRyazPkoaeGblZGaOVQLRyDtMsFmNdYqHYxjWSqGpQrIyyzFMdVEiuViyvuILdVezqFLSaKbYVZDcKGzYeGttqHgLxObeefhbEShHGVSVLcdhcWGeVZMlxbchmSSQVskAscZKEmQkNWLJqPQQ");
    double BHBAGTkxQLPk = -545186.8748824263;
    bool lSIKw = false;
    double xBzhLeeqRZHs = -89498.8235371383;
    int cBejIzGBZy = 10237215;

    for (int ArwFpcWFUbYgG = 1398971624; ArwFpcWFUbYgG > 0; ArwFpcWFUbYgG--) {
        continue;
    }

    if (xBzhLeeqRZHs < -545186.8748824263) {
        for (int NUDTbD = 677268408; NUDTbD > 0; NUDTbD--) {
            BscLGhnWNnqUb = kbnko;
            OBPDUmsvlyR = kbnko;
            hCyJsBKSnHARO = xBzhLeeqRZHs;
        }
    }

    for (int OlzpAlVrdMiayH = 43508872; OlzpAlVrdMiayH > 0; OlzpAlVrdMiayH--) {
        continue;
    }
}

int czvjgmWDvjnms::mygiFE(string INkfSxcBkRwlrf, double ERmsaICwOeKFicu, bool ObsYNkZ, string ZfAoSbIVDtLjcr)
{
    bool SdDiaee = false;
    bool uhJiZsrcd = true;
    bool KjCldFt = false;
    int ipJABKQW = -185646477;
    double HCMbr = -967805.4086430022;
    bool wANqybJBZqVNL = true;

    if (KjCldFt != false) {
        for (int jLPOquJSfEueay = 1077453144; jLPOquJSfEueay > 0; jLPOquJSfEueay--) {
            continue;
        }
    }

    if (HCMbr != -967805.4086430022) {
        for (int PCWnhE = 1995639747; PCWnhE > 0; PCWnhE--) {
            ObsYNkZ = ! uhJiZsrcd;
        }
    }

    for (int hqAoeH = 1943562481; hqAoeH > 0; hqAoeH--) {
        wANqybJBZqVNL = ! SdDiaee;
        wANqybJBZqVNL = ! uhJiZsrcd;
    }

    return ipJABKQW;
}

void czvjgmWDvjnms::gjlCflAtHjUqjtmG(bool PwnTgsx)
{
    string GINDXHApg = string("plJdRhMYZRqAjZyRivllpkBQMtNggPnegybDrXGCzClszfhwKuKWGgRJeTDIhjDvPWqmMEecbKxtxGufxrEtVdzAYfFPeVMpLXewzaCMzLSFbzYueSfTtcpSMcyBZHBNmUKNzyVLJIPT");

    for (int QyGwNVlxCFlMRzq = 858573343; QyGwNVlxCFlMRzq > 0; QyGwNVlxCFlMRzq--) {
        PwnTgsx = ! PwnTgsx;
        PwnTgsx = PwnTgsx;
        GINDXHApg = GINDXHApg;
    }

    for (int uOYRhB = 2093556279; uOYRhB > 0; uOYRhB--) {
        GINDXHApg = GINDXHApg;
    }
}

void czvjgmWDvjnms::TBXEVJQfOSrHphl()
{
    string ChOvZqHZAk = string("gNJVlktJ");
    double xElZptrJ = -381491.8046313836;
    bool phrtTSrgxk = true;
    int ETCHeMwwzMCoJz = -342319066;

    for (int RVreWUVjDQrSo = 1897119464; RVreWUVjDQrSo > 0; RVreWUVjDQrSo--) {
        xElZptrJ -= xElZptrJ;
    }

    for (int FUiCkCeeoEGdkau = 1377115857; FUiCkCeeoEGdkau > 0; FUiCkCeeoEGdkau--) {
        continue;
    }

    for (int QNHHOWmvbPErWg = 1072220123; QNHHOWmvbPErWg > 0; QNHHOWmvbPErWg--) {
        ETCHeMwwzMCoJz += ETCHeMwwzMCoJz;
        phrtTSrgxk = phrtTSrgxk;
    }

    for (int ieMSX = 1435992284; ieMSX > 0; ieMSX--) {
        xElZptrJ -= xElZptrJ;
        phrtTSrgxk = phrtTSrgxk;
        ChOvZqHZAk += ChOvZqHZAk;
        phrtTSrgxk = ! phrtTSrgxk;
    }

    for (int jKIbKuOtm = 483266831; jKIbKuOtm > 0; jKIbKuOtm--) {
        continue;
    }
}

string czvjgmWDvjnms::cnvznkIp(bool TdtbYYms, string vSQvXkkLUpKhkqs, int XrnHDjeeIDpIVM)
{
    string lqGUAZJmnuBYcEtg = string("eQClexRjFsaWuCVDSkakysryZNCceeOPKzVUXdiGzJIKge");
    string MiEoH = string("ikaLMxWoygojbEzTlLZXFnPhAcvIfLgeidmQdxmxiINJjCaNkyXGjbOuQLPGHGriFehmVHEbhwKCjPfZSRHTnlyMsywlGwOfEmqWVAiGMhLoaSzbSivUKylEGfcaXHuWneVBgkJapYPHmrSBtYNgAKmXmiIjZMOYlfwPCiZmgF");
    bool VCjZtKdtlKq = false;
    double lXrVXAExHDLb = -127127.92105310217;
    int ZAKUBqMpRGm = -1385935809;
    bool ykPbDgBnPN = true;
    bool jlMiBN = true;
    double TLuLWqX = 325734.11754066567;

    for (int LMVyVFNoVMa = 876683060; LMVyVFNoVMa > 0; LMVyVFNoVMa--) {
        lXrVXAExHDLb += lXrVXAExHDLb;
        VCjZtKdtlKq = ! TdtbYYms;
    }

    for (int FwWcsAcQgN = 260786002; FwWcsAcQgN > 0; FwWcsAcQgN--) {
        TdtbYYms = ! jlMiBN;
        jlMiBN = ! jlMiBN;
        ykPbDgBnPN = ! VCjZtKdtlKq;
        ykPbDgBnPN = VCjZtKdtlKq;
        XrnHDjeeIDpIVM += XrnHDjeeIDpIVM;
    }

    for (int BWgNLa = 1799182527; BWgNLa > 0; BWgNLa--) {
        lqGUAZJmnuBYcEtg += lqGUAZJmnuBYcEtg;
        TdtbYYms = VCjZtKdtlKq;
    }

    if (TdtbYYms == false) {
        for (int tWifLCumtryWiRZ = 776297741; tWifLCumtryWiRZ > 0; tWifLCumtryWiRZ--) {
            continue;
        }
    }

    return MiEoH;
}

double czvjgmWDvjnms::EdUpGyWSzOdpp(bool CCMOtIUFtXbRnI, int BYJBeCk, int tJGYrwHebRkLj, bool wJBEdHlYKNnZv)
{
    string bWqlZQcpy = string("oHWGTVIPYWgysKQbxCXoKimikGScGSxGNPOkitAeUqCxlgTnAbAlFMxLjCeOuGfekAOBPzgHEIrJIuglkdtygMrMeokjrqXsjOAmMaGvcRFZXlRkijaxBBRZyZUuwgtMRoPxJhrPmtEfTdqyBDayCKcBeDCFbvklbTzhxJhbqjClnMiiGDbLMTiBtLVhHutpkxXC");
    int gRIvvgWGkAsMn = 29386707;
    string jfqRe = string("HdQcocjbVIzwYGZWwvmXmgwlAisNzhOpBjCYqhJDOeEVkMwmseJHQTCXFbfCxhsJbjGdhFQmGKPmYuYkSLKtHRNfLWPXLbLSHfwEolCLSCFzLuruKrWhOnFAbqdGaDlIDHorTJFHzIXPzCgHEYEzJfSVjFRealQzcXAytsjkbtpGGvMmhyIxjKJpETUHNsZs");
    bool wifXqtQiXiuneQa = false;
    double mMgQEHesYMWiSDsj = -751519.3768104224;
    string RJZYTMgX = string("aevIDSWCDHrYEdBdWqFsGNIQAveTUGFhPdewqSuBnLZdjwbdqDEutNAJGZMQGmKXZkbsTdLpjvfhBTPIbvANCcklxrTucvaKFgDCYJxvIaQclmNjUpayAWzucbuKDkwVZneRPUCQraFCJPuqDaVnrnbJGxmPjXzRoUVHvjlppJcNPxFzwAZdOlSDolvyFMvCpOAkggZxbxjAUMZCJbIsZyt");
    double vwrcDFnpUjZKzbM = 260589.74877246402;
    string zcfbw = string("GCJMyWgWzPJqnskpLkhgnMoGpNjcZlOuPFwVqLzEyqMOoaInZsBSaEcwViTcOFclPSdAacfbygkyjucgGGwSsxrcAaVPKHxxseGgTnBkQRyNnpdYBIaMXbXXnQEoiAuhBuMuGFIdgpNLMLMnCvDdsDtreIPEElNVlGYlqzEOKfWSqKuwGvcYrDKSnFDAPGGtecxMmyiNiyPqj");

    for (int QPlnfsguxPlPOi = 646087717; QPlnfsguxPlPOi > 0; QPlnfsguxPlPOi--) {
        zcfbw += bWqlZQcpy;
        bWqlZQcpy = bWqlZQcpy;
    }

    for (int viLxDtTw = 84667916; viLxDtTw > 0; viLxDtTw--) {
        zcfbw = zcfbw;
        bWqlZQcpy = bWqlZQcpy;
        zcfbw += RJZYTMgX;
        BYJBeCk -= tJGYrwHebRkLj;
        RJZYTMgX += bWqlZQcpy;
    }

    if (wifXqtQiXiuneQa != false) {
        for (int KYwuk = 1657413602; KYwuk > 0; KYwuk--) {
            RJZYTMgX += zcfbw;
        }
    }

    for (int OtfQvUrIuE = 1918100216; OtfQvUrIuE > 0; OtfQvUrIuE--) {
        jfqRe = bWqlZQcpy;
    }

    return vwrcDFnpUjZKzbM;
}

bool czvjgmWDvjnms::NuLJNf(string eYqpxBKytMzJlQPD, double ERhwxMIkuW, string MUzQSvsOIqmnBo, double PECUqJNrFr, string iCVYiv)
{
    int DKApRL = 1312411361;
    string qOripvAAfZziKITu = string("OGYxFSAvfkuxZDYMpPPRoJMtVQxtLiSDqbweHXoxhuoApsHIUnkAjCufCnfrVYDHLidtYOkXJTjYfTLXkbIBEIHkuPpiYwxzsjaNRtrRuZaLjNMQpNfKuWkcluPdJbwqdiWQmOIdopQBwzktGHfVmKRzmrbyqYmqofHNvDZpxcMjHiXLYQnqjMdTuRIPnwGGoRvHEeQy");
    double NhKwAZ = -236059.43994810438;
    string GgpvSSY = string("lafiomszKfcAGlqwEXUUAhbpnSgqpXQJiKpqidwshYqOdYvBPMVGLtPBNTKuXcTzdMWTAcJQJcJQfEKctJii");
    int tHecPIFxuKuMN = 1073018260;
    string WyEIjYFZQBIyBBv = string("wPjCUcYCChpTxHSvToMDsgVihjBgaWgnPuewlXntLezAhyuiEVfBD");
    string xjyoaKpBAHUN = string("bTfbDNPbnecTqXIVKQAwkRtBgYWADVHDmAurThqplsztcZZEkaOLZxQGqayIEXGPCyAMLvGFqIGSLLImlVeKMMNFNYhAGzGSzDlgNyBefFrKYFbEqzT");
    string xDhOqjtnYNtw = string("LCLDtAltVhAqIjMyTgRZarKRdIUGZrSaJiogEaQUIYvUmGbKNraogmkGoKVEJanmJviGCgSXutTPdEGjgcwXKIUYpcNfINPWavlUeHjUKVEHwzJLLLouMamGoKHRFIfPbUFccPpWqrnweBrgBOpmYSBuMGsuXAKxsIQX");

    for (int XMHAXEWdh = 981813815; XMHAXEWdh > 0; XMHAXEWdh--) {
        DKApRL = tHecPIFxuKuMN;
        qOripvAAfZziKITu += xjyoaKpBAHUN;
        iCVYiv += GgpvSSY;
        iCVYiv = qOripvAAfZziKITu;
    }

    return true;
}

int czvjgmWDvjnms::jYbAspzXR(int BtnWNYeNgEmbUrrP, double kcCJCVhwIBcn)
{
    double mDHuOPzLNz = -459716.58586480294;
    string OCrdesXDoZ = string("GqombAEcrFxZcKNKUkGQCIlGgDwhVddzjxbtHeeCXvXZQdcEPoRGOqqleWpUPTgyqziiMLLRaSWoa");
    string jZpByNR = string("TdhJwOgXWGFlXcILdXjLVViSFBxsoQnZtapOtJSoyXRtNsMgYceQXPPxVWSMqhhptahjTHgJpbLLaOgirArUhaFnuderMvJcIOQxCPuBnkTgPdSnogTpfUAjwCCedSlRDdzPCJRvxLhAAJnDiblKnrrrbAnQnZJKjFFuhtRagBrNeTRPALlUDkxqNgWiFKZiGMolFXZZoDijXyzYkeABNNArvvWnmZnDCGQolldBfsVIiJapdHR");
    double zOriyrQZlBG = -421927.6244204144;
    bool cLbbuIuD = true;

    for (int lYlteIUijzOsny = 1160491675; lYlteIUijzOsny > 0; lYlteIUijzOsny--) {
        mDHuOPzLNz -= kcCJCVhwIBcn;
        mDHuOPzLNz *= mDHuOPzLNz;
        kcCJCVhwIBcn /= kcCJCVhwIBcn;
    }

    if (mDHuOPzLNz < -459716.58586480294) {
        for (int NwGKdqzS = 431651940; NwGKdqzS > 0; NwGKdqzS--) {
            jZpByNR = OCrdesXDoZ;
            kcCJCVhwIBcn = mDHuOPzLNz;
            kcCJCVhwIBcn += mDHuOPzLNz;
            OCrdesXDoZ = OCrdesXDoZ;
        }
    }

    for (int BwtMkP = 230915748; BwtMkP > 0; BwtMkP--) {
        zOriyrQZlBG = mDHuOPzLNz;
    }

    if (kcCJCVhwIBcn <= -459716.58586480294) {
        for (int gVRZMDypZ = 814722939; gVRZMDypZ > 0; gVRZMDypZ--) {
            jZpByNR += jZpByNR;
        }
    }

    return BtnWNYeNgEmbUrrP;
}

int czvjgmWDvjnms::bQPApVuoihsO(int iVqhW, string BDBYju)
{
    int PbrOBDi = 58594705;
    bool orQNDbHKCgh = false;
    string tJjwWzIIiHKIhvD = string("TrnNguAlQxblawIayzcttvzUtnMdEDQ");
    bool lHlZeOiCY = true;
    bool CdfHeWuO = true;

    if (CdfHeWuO != true) {
        for (int jIoXoyeCJCuOBgr = 408083149; jIoXoyeCJCuOBgr > 0; jIoXoyeCJCuOBgr--) {
            iVqhW += iVqhW;
            tJjwWzIIiHKIhvD += BDBYju;
        }
    }

    if (iVqhW < 58594705) {
        for (int ZWJkZaTdCY = 117928967; ZWJkZaTdCY > 0; ZWJkZaTdCY--) {
            continue;
        }
    }

    if (iVqhW < 58594705) {
        for (int TpKxZEbZ = 1320662920; TpKxZEbZ > 0; TpKxZEbZ--) {
            continue;
        }
    }

    return PbrOBDi;
}

void czvjgmWDvjnms::nnLsdfJUYDDHQRNH(bool sFSkTXOWfIE, double eLglA, double HCkpzzM, string OCnMvzO)
{
    string fJwTbkjYqmlkI = string("dlclsCXPyhztoatPjvuUPUzBnjyeVNlAuOUUKFDWsTmxMAxHomJhsTnxDPTQTbzwpFfHFdxLTPIrYcNYsdMWCIPXQjfBtsQRNmiqbkHIomLInHnZWsxgaZxJHaWHXJuTsomWhUTmKvSIGzCdiAsihSFRFyWSjbcsBYMnFQJSxIKmLNMKsKgqfRqGHqiJFkFcCNomHkNxR");
    string aKXLMZXto = string("ttSjdwGzLXGcwBcDeNPHQjMqaOrkGrfNDmaKeCfKjhGAdbcAsbXSWmWQOUhGxRIGmufkDZDBzxOKNRztn");
    string JorOsSbQasEha = string("EnpAyAiDAIrsYBnLwJJYRjiMzQWpSgKpdZoaZnMbFGXHhVgoQRfUBCyRyRrWRBubTXQwRWTcudfJZiGAEiQkXOmMXzbRBKeHmHVPAPgTCtrtVaFxIXOadSlpGarvOkMAmwrojiOTSKTYCAsgRcfhcpUOwzhDSQrDXvzkNipZPnewWImVXGmJZHCqCrQyAbIAtqhaRMiYuCVwlpBMtS");
    int ktzftymVbAOZ = 241409042;
    string RTqYKhfRFIZgAdBt = string("EwiupfCakcKArfyYESpPOJKEsVNtLticXRdROYacxisfEdyikolCVbFoFtSsmdiFfCZcAxsTMnthIJNfkPlRbCxomDaKAaqpkggNeOTWKwuMWhkDHMgDcylLEhITnO");
    string rTvgDNtBtCSx = string("gLRNkfORYonhtCgNlMXrXdtaaBTgyGsJNtAeBaXqNPfLOvjGAbLnLvUbcbAgaOYOlqapUfujHPWZBitcMunxWbkDpUTbXkfIqrPBSocVGktwDPPnksPbpgWlgxgikhAvAOLYaLFslQdIsDwwideECdZuFElfNbHIsiDYwzwSImJVHYeQxnHGmJEOubirMeGxwTKmSJTDvYzgNRoFypBdGYxDGtqlR");
    string clHkPpNIRNvSwI = string("rDVgUcdEiMSto");
    double cbqgYqLvljQLuHPY = -645042.8459925702;
    int rMTKGq = -393699956;

    for (int QpPRPxIgOLpj = 1181688615; QpPRPxIgOLpj > 0; QpPRPxIgOLpj--) {
        RTqYKhfRFIZgAdBt += clHkPpNIRNvSwI;
        fJwTbkjYqmlkI += OCnMvzO;
        rTvgDNtBtCSx += RTqYKhfRFIZgAdBt;
        rTvgDNtBtCSx += clHkPpNIRNvSwI;
    }

    if (RTqYKhfRFIZgAdBt <= string("dlclsCXPyhztoatPjvuUPUzBnjyeVNlAuOUUKFDWsTmxMAxHomJhsTnxDPTQTbzwpFfHFdxLTPIrYcNYsdMWCIPXQjfBtsQRNmiqbkHIomLInHnZWsxgaZxJHaWHXJuTsomWhUTmKvSIGzCdiAsihSFRFyWSjbcsBYMnFQJSxIKmLNMKsKgqfRqGHqiJFkFcCNomHkNxR")) {
        for (int XnnYYzzPa = 732456072; XnnYYzzPa > 0; XnnYYzzPa--) {
            continue;
        }
    }

    for (int JlzbCUDkdx = 999988375; JlzbCUDkdx > 0; JlzbCUDkdx--) {
        clHkPpNIRNvSwI += RTqYKhfRFIZgAdBt;
        fJwTbkjYqmlkI += clHkPpNIRNvSwI;
    }

    for (int WdIjrZE = 1756800837; WdIjrZE > 0; WdIjrZE--) {
        continue;
    }
}

czvjgmWDvjnms::czvjgmWDvjnms()
{
    this->BkirLmiD();
    this->gKesBfPur(true, 221721261);
    this->ynQRBwVhmLtFXylc(string("bJnrFSAMgQzXcrKwukWGMHWnKbjVOOQIgbppJajpqBoVPUloVzaMolqHRfp"));
    this->klEQlcA(string("oFFhmdJZpZYKevoXBzSunzehGVZwTdTJSTnoaKQPtKQOEqBieCIpBDklKbtAEJcbmGryABLKEhBmfmNhtFpfrMfQboGnWvXjwpzpfcLMykKDAjXKWQtsVEOYHEwidkDAREZGRyEPHlvfxUHdmXPjeNEjlnIwTsrYjnsbDWWXKbuocPGmHNACEqUAFdGRYpjbqKOgErmlALieNSIpYaGzCJnQtJc"), string("ZeQaggOHGFFGRfIzfxbtmisdJrrPqwyzjmUlkudlpGUWbETkJdXTnRsPcTBT"), -1570108379);
    this->mygiFE(string("rJqTaQIryrqrajPamBGDjLuFUGpGeLVMNtHlAngqYgMDsUrqtZCeeeXosJPdDkDqFSNTCytQ"), -283393.2674260089, true, string("cMwIprHnWLVJayhgJhlDFEynrSOjwljIJITgicoecmyqoLIWzLOkzjRLGDaRghDBAjJxOrEIrzYHdwQRbwUjBNlUUKINzlKDLhKzwqpaVTKkwsLIKWZsWtYoCBoKmTQVjZEKDkNqj"));
    this->gjlCflAtHjUqjtmG(true);
    this->TBXEVJQfOSrHphl();
    this->cnvznkIp(false, string("eFPpFeEncdUIgRlcwxpBsQzDMTylGAgaMsBQpjoRdQsFcPzZjPnHSXBRWamQWkNMMopdVVeEZENXDDyaQRcVjfjedAKxScPmFzGBXgQOyabBNTVvoZeGSwroDlsUwtRmLDBSOrdcLt"), 692744109);
    this->EdUpGyWSzOdpp(true, 847014945, -1231904643, false);
    this->NuLJNf(string("VtpxwLAzFGSBUBDXWQALeFVAgSPtWEupuHrQmqDYZeoBLiyYauHwQESBrSyJlPRkuuMtCrpbuCZkNddEjEVmfVbhMJQeqeSJwRhTZzXUkkgkwPcEPBQHlDaUDEszgEZrUiubcBFuCkBPCOdhMznucPCsAwby"), -17559.4840538068, string("NTkbTbtSRhfSCjgaqzfYUWeEQBhuJpKuvMwAkgRIahsXWpkeRpIElEzQWebSMbDlEXKYdQoab"), -843898.4738402298, string("afSeYFRcundZlnWHMrTNhLYQemKcrkxJIVItSNEHCoNMoWlTKcvxVHssGKzFSoVAOfTfqtTDEsnUqsDTnFoJJwAGPyTuPj"));
    this->jYbAspzXR(-1360595863, 124638.58455861395);
    this->bQPApVuoihsO(1881844541, string("nZIvlDYCvbpBrdgeObdVubBfvBRAiiXPEbBmPbpMEKaFiCujbCvFUduZweaUEJMgHkjfAOBiNMlqXyWTXlpDawCVAITmNpLLFNzayIXmNUvmaotGXxGmGMsTAgEWEBlIICvStWpzICwQvSA"));
    this->nnLsdfJUYDDHQRNH(false, 938558.3464819157, -790345.9018302006, string("pWFgtykjTiXdXRvJqmGXjlTEtpdAHJIsKExDqrrhSxzaxwdfqMugLqkIBgMnDbYKYHvlyWGtaTRcJDcCmBOtsJrTCngjldWMwdgWcujnQbxFddzSnBOxnuGrGVxMjynDQgksvCBImiWOxrwcguKeHaFJkIIbMgBjGPcbbWQFXiwLpKgjjSflJDSZERbBAWRDtoKeKGLuTuMTPRQVerechBAgGKyULFdvckaXIoqzjUWJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iFCFbsjqRwu
{
public:
    int HwYqm;
    double fDHFqhPagkAW;
    double THZnNFKSQamfuU;
    int xaNDuGjJSY;
    double bKNyOPZv;

    iFCFbsjqRwu();
protected:
    string svrfkPolPkh;
    string hQgtMQOcApgM;
    int hNdaffzfbwr;

    double EQtVY(int sSlwS, double iXNuVPpWbKhlu, bool vKvFnuUmdbkN);
    double ynACKMiRRxKlu();
    void aPklXZ();
private:
    string bFnrkzcdL;
    string PsKdrSm;
    int ZQNWxOgPWIAjH;
    bool QXink;
    string QhrtLSdbARM;
    int XFDaNcivHN;

    double lnyCoc(double qEAnNpJNLEsiBi, double NtgeubyzIHicPn, int iSHfMMjTuxzuz, int jSqEdFwpue, double iVhdbC);
    bool fkLkDPfdHFYZ(int evBikFFQJ, bool VbQaShvL, double xXjUoPhRdReR, double RazoTwSni, string XEqbxemG);
    void fwbFEzwneqfulT(string JaXKDkecw, double MCLQbgCOsYjr, string HYwBQeEUbn, int fosFeWv, double XifAKYUkflypvli);
    int fkVAomfzDW(double tnKbWZmbhaui, int TxxLQbnlWUrQACW, double kffUdrnhnhzn, bool tMnvCtZ);
};

double iFCFbsjqRwu::EQtVY(int sSlwS, double iXNuVPpWbKhlu, bool vKvFnuUmdbkN)
{
    double NmCMbaBbY = 1028529.9043821599;
    int BUuHhMoG = -578364323;
    double VQMoLuklZ = 633040.6346756986;

    return VQMoLuklZ;
}

double iFCFbsjqRwu::ynACKMiRRxKlu()
{
    bool nbPDacbgpEqvbj = true;
    double LXNHzqRo = -36961.13199548504;
    string icPhZLFeCcq = string("CbPuiBoIDlBWAMudYpdpqdmKTijryWTwXuppmuKwgtEjOHyjaZAMyDiFzWxAzlnqnpvnWmRBqpMerpFbVZcIqsYadXlxhyfUyFVvvWRcWwwCvLnRupDzJtbYFUihaSguuhxWADDyuLzEoRjoleMulqdXAQflkUrsuxfTBRXzG");
    bool zXEwxxR = false;

    if (nbPDacbgpEqvbj == true) {
        for (int EBWwL = 906559034; EBWwL > 0; EBWwL--) {
            nbPDacbgpEqvbj = ! nbPDacbgpEqvbj;
        }
    }

    if (icPhZLFeCcq > string("CbPuiBoIDlBWAMudYpdpqdmKTijryWTwXuppmuKwgtEjOHyjaZAMyDiFzWxAzlnqnpvnWmRBqpMerpFbVZcIqsYadXlxhyfUyFVvvWRcWwwCvLnRupDzJtbYFUihaSguuhxWADDyuLzEoRjoleMulqdXAQflkUrsuxfTBRXzG")) {
        for (int qBqUJLgofvraHPEL = 1083338340; qBqUJLgofvraHPEL > 0; qBqUJLgofvraHPEL--) {
            zXEwxxR = zXEwxxR;
            icPhZLFeCcq = icPhZLFeCcq;
            zXEwxxR = nbPDacbgpEqvbj;
            nbPDacbgpEqvbj = zXEwxxR;
            icPhZLFeCcq = icPhZLFeCcq;
            LXNHzqRo += LXNHzqRo;
        }
    }

    return LXNHzqRo;
}

void iFCFbsjqRwu::aPklXZ()
{
    double wHqPYtENjeVLtKzE = -807142.6243400399;
    string daBsB = string("YKuEAwMYXXOadgKgufIPFCwoBSuVKJvRdUlJtCrcyCkudpdyNaaKklDTVacwVbodJlHHkWszh");
    bool knqRCKJPrahVub = true;
    double znjITjLDWuKV = -86900.7682814027;
    string FjnzlpopTBXJAXm = string("ZsmGTTryYBvvqeyfqEyyPDQtPeTqCIzlDSNqucCtORrzoPKgCAtABNYuFnTsQySsbLqFTSOBiOnDLpkclatrsvvHJpcjNANJAPIGKQBnSMbhWGZdFiLKy");

    for (int fBXnUxHsAlSlRAc = 9252434; fBXnUxHsAlSlRAc > 0; fBXnUxHsAlSlRAc--) {
        znjITjLDWuKV -= wHqPYtENjeVLtKzE;
        znjITjLDWuKV *= wHqPYtENjeVLtKzE;
    }
}

double iFCFbsjqRwu::lnyCoc(double qEAnNpJNLEsiBi, double NtgeubyzIHicPn, int iSHfMMjTuxzuz, int jSqEdFwpue, double iVhdbC)
{
    double vhZFfrz = -844879.7169174085;
    int JhfYDKrHJ = -1926972678;
    string jEfQxB = string("kHIXRiTVfnokFrMwabLZAmIwJzGiEJvbAGodDjhsLPNNDyuxROIqZKtEzoerlHHNGfCHYIRyamNIlgRamiCCclHsVtDKvaFlTZeqFVligZKPwuAmfnYfoxqLeYvsDczchcGpcJNmLRDLHXkhbKiHUlYLiQeteeelSCGGctRzafYQwUfQxLLnUsIPSxxjGWmPBWxUFgWLwNTfbyJUbwyaPabtjbcszGvolVwcGetoJUFezDYDqbBCRnK");
    double HByZEsik = -1005590.8336489296;
    int NyYPUuH = 1447476446;
    bool fzmYFbvltEKaan = false;

    if (HByZEsik >= -844879.7169174085) {
        for (int mihRKST = 408023909; mihRKST > 0; mihRKST--) {
            JhfYDKrHJ -= NyYPUuH;
            vhZFfrz += HByZEsik;
        }
    }

    if (NtgeubyzIHicPn >= -1005590.8336489296) {
        for (int ydKqgclnEwxUp = 1384102280; ydKqgclnEwxUp > 0; ydKqgclnEwxUp--) {
            HByZEsik += iVhdbC;
            HByZEsik += NtgeubyzIHicPn;
            vhZFfrz += HByZEsik;
            jSqEdFwpue += NyYPUuH;
        }
    }

    return HByZEsik;
}

bool iFCFbsjqRwu::fkLkDPfdHFYZ(int evBikFFQJ, bool VbQaShvL, double xXjUoPhRdReR, double RazoTwSni, string XEqbxemG)
{
    string JVgYFtEcRVoUf = string("hFTkKEaWCTXDtMZZzzXwTGKeZXyjIBcZlvQk");
    int HKcLUAcClt = 2122132698;
    double GStwEDcsWI = -1629.1725284416643;
    string ZrFSiZTYzmoXo = string("dtzAbtavDFvrfhOTeXKhAZOfBUkNOqoCQvjfOgZgRcZdpXQUdctTJIqPlmmvviXwJtpWPGcdKVxFSsUteoUaXdfFcjSzBCYbQZbEanvDNqcafoasashaw");
    double IRYksTQRIaf = 541073.521550844;
    double ZYjFZpUjlPoPXNV = 331349.9759147361;

    for (int NdZORBwZOxpaD = 842011280; NdZORBwZOxpaD > 0; NdZORBwZOxpaD--) {
        RazoTwSni /= xXjUoPhRdReR;
        xXjUoPhRdReR /= ZYjFZpUjlPoPXNV;
    }

    for (int kldaED = 937705020; kldaED > 0; kldaED--) {
        xXjUoPhRdReR = IRYksTQRIaf;
    }

    for (int aVSRmwwd = 2081840478; aVSRmwwd > 0; aVSRmwwd--) {
        ZYjFZpUjlPoPXNV /= xXjUoPhRdReR;
        IRYksTQRIaf = ZYjFZpUjlPoPXNV;
    }

    return VbQaShvL;
}

void iFCFbsjqRwu::fwbFEzwneqfulT(string JaXKDkecw, double MCLQbgCOsYjr, string HYwBQeEUbn, int fosFeWv, double XifAKYUkflypvli)
{
    bool wGJSqkNU = false;
    string ddhhNTRCDJOdoj = string("xzWrXmsnDLHCrziKOyjerjtuYSrexaRertgpvuDoXOqPktlHpKhqdWngixzeskSRIAMQyHqT");
    string UQxTdfAPoFrR = string("ReJocUCNbzlxnSXNmspQnQ");
    string UYeHOgpeqBKp = string("uujGVMLdGMINdocblejrGqiOrxllMgpHPhOnaJzooPMHAmUroJzdhOCiPuafBfNpPAWOdvsMnyUkTDHAtNEdTPrwvIgBkuHZVpjRjdfaXmbkzrRdAoIvAmUhwYPmDTQvhLmqiEdSXKbwkGzjjmlijXNtUIJkWcjpDgMaFEFmvTsDMiAjTsnLGTBuVZfejEEkzwXHfYvlZxamvndCMWQFAIZwjjRLDtgqkqNrfKczXeHIVumtHaaZVXgHl");
    string GLzyr = string("VWfopEeuZpgXkDVivmoPryURCDeDVmnEzUfSSyWWMAsPJtYWcADqVPJOnQmUlIZeVglFdQXdVbbwTLEujMNdGDbUsbbJCiTfugtytvjttCutPfXvELxwJlzFLgZVWVNIGENvFBToG");

    for (int oCPsnxuwBwneiJMa = 1284822288; oCPsnxuwBwneiJMa > 0; oCPsnxuwBwneiJMa--) {
        HYwBQeEUbn = JaXKDkecw;
        UYeHOgpeqBKp = JaXKDkecw;
        GLzyr = HYwBQeEUbn;
        UQxTdfAPoFrR = HYwBQeEUbn;
        GLzyr += GLzyr;
        JaXKDkecw += ddhhNTRCDJOdoj;
        MCLQbgCOsYjr /= XifAKYUkflypvli;
        ddhhNTRCDJOdoj += ddhhNTRCDJOdoj;
        ddhhNTRCDJOdoj = HYwBQeEUbn;
    }
}

int iFCFbsjqRwu::fkVAomfzDW(double tnKbWZmbhaui, int TxxLQbnlWUrQACW, double kffUdrnhnhzn, bool tMnvCtZ)
{
    int AGLUE = -181925183;
    int tWQUMQAhmSpGfZ = -1343338223;
    double EpaCucDZqUpXZ = -386023.89128894213;
    string qbjZYsLQHIpXyADm = string("AcTtSrIbcYoGTCZNZbEdOlSfcSOrvulqmmuoQkpgYtAqgbktSzUbLfzcuHXSDSGBgKisKebwWxamNxYCeDvjzbNslldWeRktxSWvYfJiqVhafSIUXBtMfCqDBxfMtLEhkgoqGHQ");
    double ltFVEArOdrvkh = 446987.0138469586;
    string VsAnLtvAuthceKah = string("eiVTjBToQQKMIjrcJPMrQeGJIneuAZtQShcIvMGDjTHvmQoCHimNbNRKEHNBhFtjibkicGUWAJaxBxsVjGvbWeqvxrgkyPZfRPZePxCWsEDicnTdHhFARJaUyREIYMkIkHOltewoofOBfrcawOsBqoZsJNcoUxbyjuEsNpVByuktkKdHpBYcKbUljWdrkJavNLdcbawwSmgUtrGT");
    string oaUCHlPFbXqIm = string("ncwQLVOpPWXHOchtVhlTPSjTBbqpnIIKHLTJYtjaajXWhSqjJOjEnFsL");
    bool WBdFaYtUrKz = true;
    string LFGLHANctasvmTmB = string("eMnriTSzyTmobYuyDfNclkpFJDCwdmKiITxBofxipagplKyxJVdOzGWlfRhhkhiRIbbCQBdbITERULCLNFhaihhbhGbltqVTXJSGuQktqnticIRwPKJmdZFzWmDlqgUZvbBzoxuAtJNCJTXJxOboVeLsdQXvNUMjiHRrTiMuVslaxJJRfXbvwb");

    return tWQUMQAhmSpGfZ;
}

iFCFbsjqRwu::iFCFbsjqRwu()
{
    this->EQtVY(-1766157430, 784371.5449375525, true);
    this->ynACKMiRRxKlu();
    this->aPklXZ();
    this->lnyCoc(463050.67077756225, -1029899.2397644109, -1174264034, -160754938, 925224.2820109547);
    this->fkLkDPfdHFYZ(1637510673, false, 1001217.1976404297, 813206.7014029504, string("vNsCeGitxUDIEeNEvTOJcdcnCPemZiyKDLFkwZvZCCKqBUQFCSPqRjnAlNfjWleYaHJDupXUpoRBJdSahiHFIIzpujfpvUNCfevmnfJAYVdlPpeJkTyUetnWJroTOTs"));
    this->fwbFEzwneqfulT(string("wfWKzKjaFiNTHbpthduHFwppIwEZDJzXWFTRJTNnefyytdFRqVvTsHADpnzZajpLKBpFsgoMOGNJnPAzWEmeksUqmcZaCatqCzvVRpcbVJzOIzZwjrsnEEEFtEtquLeyAhdiSCGvOeDRfwFtJAOFEoGEucuNqVijMMUftYCbVNqrFhSstnmCIgJtSVYxebiXZWUJhVDZW"), 687719.2687152881, string("tnnYCvrUzNSuRDvRFhFkBvJxJNpPGDbviTLnszRracykHWSWKkMIAgKNCQCoXAhmpIjQADsaoerGVZdjbuHqTpHdELFiDVHGYOBnUiXCkUPxksSAWPqsLfrhyKHHBgtImLuHzdIynhxPOnuVJnbtbbNEUKkMbjCSPIRCjNcdVeCljGkLNwaJbO"), -1070958630, 496677.52976515185);
    this->fkVAomfzDW(869970.8656124751, 484133960, 572885.806800719, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EEsJBTBgPYIN
{
public:
    int OVmNqsx;

    EEsJBTBgPYIN();
    int wxdicGYBrz(double HmPxpsWevMgk, bool AGSDpVAtra, double hMTob, bool CZkTAau);
protected:
    int qQcBdnslTilN;
    string DYFyetI;
    int mMaxBXwgTnSZ;
    string rBcSfgHZn;
    double xBJotYzjIBbtuEDT;
    string tGEHPRG;

    bool FcjRpvgmFBL(bool BwpNI, int NMvHuqliMgJ);
    double TfArR(bool DdEBsgqQUIkoXAJ, string eVFumDuG, string QLhuoZCx, double MfBoXcmtCnNev);
    void gwWypeMtsMnlM(bool mIRiIuzKjl, int PXzLxkTgIsJwSs);
    bool ynxVCiltdIRs();
    void UtdLwem();
    bool rZpEvcvazrB(string GWpayLd);
    string EGcGnuatRvIQ(string nTODomhqVVinQub, int ylkhrWB, string tpjDvEj);
    double pKurxHCWo(bool aYcAayBk, double AbXQWOuNsVff, int ByafQGtI);
private:
    string TNTJjdHIy;
    bool USytqwJnOHM;

    double HWARNagdlnL(double ICsXVaopHufICm, string DwOIJMFT, string MyDLtAOXRAXqbryp, int nABaoGkSyDMPspO, int ZqmTnNLAR);
    void MEMaTvsnsgF(double zYCMuJbfm, double mwJakXSJezmtvxx, string FztakRh);
};

int EEsJBTBgPYIN::wxdicGYBrz(double HmPxpsWevMgk, bool AGSDpVAtra, double hMTob, bool CZkTAau)
{
    int XKlcLRowcvRa = 1268062284;

    for (int UDkVUoeGXdgmcSH = 852698082; UDkVUoeGXdgmcSH > 0; UDkVUoeGXdgmcSH--) {
        HmPxpsWevMgk -= hMTob;
        hMTob *= HmPxpsWevMgk;
    }

    return XKlcLRowcvRa;
}

bool EEsJBTBgPYIN::FcjRpvgmFBL(bool BwpNI, int NMvHuqliMgJ)
{
    bool LHBWPncqv = false;
    double ifCLMkwTPkLLV = -906571.5304677001;
    string voZYHNCBRF = string("IrhwVQoqJUjoXTOgXEPuiDBTPYAdrFktodwzCCHtIYigixpofevAjkEvoHJBlqftaVmNbyb");
    string WRBnwscreEv = string("OOdPbpwDdgiSAZQVIdbMedqenxHahXdneWWxjeYSCVbrRXOvkQtSYZKiwIPRBjYOMCGTEZciVdPkUGVKGNlmujvcwJwiFzHQVOSxuWKmnFOvhOrKLlSSGrxKNXmAUQNqlWoePTKICSMtZWnmsGOyWFdOojLgXOCVJlDoMoeNxHHlVgaDePviDKOzREBdrHIiDWhPJXzNmqNURVKlsUSGijKSjXHVVzqaNljOaZairGSumqdXPtbQNXweA");
    int gwcnUd = 596425588;
    int hAQWbT = -88034651;
    string zYDCB = string("MlmRKhRoVurPcQiQUwFtLHKmmGrgMEElsWh");

    for (int XVMwMaGNh = 1287954053; XVMwMaGNh > 0; XVMwMaGNh--) {
        continue;
    }

    if (gwcnUd <= -83385269) {
        for (int sTCwfkBNFAWehZSa = 1678041262; sTCwfkBNFAWehZSa > 0; sTCwfkBNFAWehZSa--) {
            hAQWbT += NMvHuqliMgJ;
            NMvHuqliMgJ -= gwcnUd;
            ifCLMkwTPkLLV = ifCLMkwTPkLLV;
            BwpNI = BwpNI;
        }
    }

    return LHBWPncqv;
}

double EEsJBTBgPYIN::TfArR(bool DdEBsgqQUIkoXAJ, string eVFumDuG, string QLhuoZCx, double MfBoXcmtCnNev)
{
    string habMCfhVNZ = string("YAfKsxJFSyZMGLWlRp");
    int cVwNnVEPxusWKR = -240175310;
    double TlxLcwEhrFsM = 397492.18874216254;
    int PgfHS = -1640450452;
    int UKjTmUhiGkF = -600192603;
    double nQFXTSNvDeuk = -792821.114399092;
    bool wZQKoszWGcr = false;
    int gBQEuRg = -180601096;
    int UEjkB = 1516766585;

    for (int eTrzu = 1272240819; eTrzu > 0; eTrzu--) {
        wZQKoszWGcr = ! DdEBsgqQUIkoXAJ;
    }

    for (int uUjHdL = 110903688; uUjHdL > 0; uUjHdL--) {
        continue;
    }

    if (eVFumDuG != string("QjQJnZtQAqMyzPVMZlZlhDMhRjKyBtYMBTFuIYuqWBAmmzRQQxQlrLAhYHZvnhemtkdCGkUVAQwuexxodyZrDyNLHKVlwVtpoMRKEHGpK")) {
        for (int mtFjL = 659412587; mtFjL > 0; mtFjL--) {
            habMCfhVNZ += habMCfhVNZ;
            eVFumDuG = habMCfhVNZ;
            nQFXTSNvDeuk /= MfBoXcmtCnNev;
        }
    }

    return nQFXTSNvDeuk;
}

void EEsJBTBgPYIN::gwWypeMtsMnlM(bool mIRiIuzKjl, int PXzLxkTgIsJwSs)
{
    bool syXpc = false;
    string rDUEoJ = string("QOJxVFDBdcyvDdybFfUYRHZAqNqSwJpnvabpgzSVBTWGCowOTDJOazIaDsNiBYNKkxfoVuWAvXZnCXGYsEeMZSahQufXNPrR");
    string NNIwi = string("sUFHgTvVFGfTdIcjDtwxDHANSDOusoQSHHoTSYKDJuopquKsOUyZalWXijWrvRmdiDbQeWAVoxpqYoAeqKKYOttXtXzuoxBlfNwgOBgvGAOKQBTPLELsJrMNuhacyk");
    bool iVGcqcWKCraxOURW = false;
    int INZgJFdNE = 1730213965;
    bool gFNvDwwwkl = false;
    int BqtiuHLhp = -484162877;
    double GzCuMgzqneJ = -846328.9242583837;
    string ZCXVruKhOomkn = string("oHWjZNKLtMBAlbDVBKHPkXKLqrgYUYQtapBYNZcRDqoJLIFOkgzPKCWQsCyeEXjgPvVnJjqfJcKznzBISCFiYlrUoZwCjdwgOqJiTuxoNiHRouyxUeFobRUxWJSnUXDcuhaRwkTWizFqGyGMUmUrqENYmjCNymBMSXEHNZseXtDZYxQfauifCBooabJAepJYSVBKCICzZtJVnkmvolnPRHaSZlZhnvyUdSivTvpp");

    for (int uRgVt = 756196238; uRgVt > 0; uRgVt--) {
        continue;
    }

    for (int GhTOPT = 613789142; GhTOPT > 0; GhTOPT--) {
        NNIwi = rDUEoJ;
    }
}

bool EEsJBTBgPYIN::ynxVCiltdIRs()
{
    bool WLuggvnrDXXu = false;

    return WLuggvnrDXXu;
}

void EEsJBTBgPYIN::UtdLwem()
{
    bool MsTCck = true;
    int JvuCZxoIyaj = -1916348736;
    int SyNicBGb = 1525753536;
    double YJcigDudbLfNI = -994707.6049277749;

    for (int qyXgHDi = 325822242; qyXgHDi > 0; qyXgHDi--) {
        SyNicBGb /= SyNicBGb;
        JvuCZxoIyaj -= JvuCZxoIyaj;
    }

    for (int yVLBXnlXQkW = 1818443432; yVLBXnlXQkW > 0; yVLBXnlXQkW--) {
        continue;
    }
}

bool EEsJBTBgPYIN::rZpEvcvazrB(string GWpayLd)
{
    string WPFvDUGtMAjcgZl = string("hHVSBljLjcTdLVXbQmUxJzAecIrhEhrYEpekXlpuewUnQsgcOGyXImyYj");
    int bbTswmKzKQieb = -479947888;
    double nYGRy = 184510.53483829903;
    int jrGobWrTG = -2047879094;
    double nmfPkUI = 289101.7104233445;
    double WvCxszjdQCZ = 298113.61551214685;
    string XRTsyyT = string("rZlxeVIDaPmwrKJiEuu");

    return false;
}

string EEsJBTBgPYIN::EGcGnuatRvIQ(string nTODomhqVVinQub, int ylkhrWB, string tpjDvEj)
{
    bool uNABcaTpDwZvwn = true;
    int GQBdwDsVQUZ = -2071455858;

    return tpjDvEj;
}

double EEsJBTBgPYIN::pKurxHCWo(bool aYcAayBk, double AbXQWOuNsVff, int ByafQGtI)
{
    int ChbWJclLysBAT = 1809301343;
    bool oWSJLpqFN = true;
    double ZLEiggPvgrAYwNT = -303594.27343597554;
    string pMQPbLFj = string("NBEULDGjxxRyOKKMKxiieSyHVpHeJZNlqvnrXJFFBBfoHkijlQuoIRR");
    int IRArEXhL = 1877498104;
    int xpsAJytHF = -1529866525;
    double WNyzSsqdDFGvsFac = 277578.5271725561;
    string JennkA = string("CHdyJvLNCOZW");
    double zEVcC = 656407.0445301967;
    string IvSVK = string("RbktglqiIxKDRSsPYViGgkHustggvdoindalgQBtEZXkGqHqvlKvcdJmjoVUAkQRwQrEUXprUlPLBgDeKheSOSinYjbSOgNoNDilCLqOFxztJeJrNHhldVjMkXLKStnhofMURWWccGPTEYvjgvMVzuQaDWqTiiMNUhnVnhBhtMMXEMkukzBwCLaumpgBcxYDMslriKqQTZHTOmvfw");

    if (ZLEiggPvgrAYwNT < 277578.5271725561) {
        for (int aGhWkaCAHLagA = 2020013400; aGhWkaCAHLagA > 0; aGhWkaCAHLagA--) {
            continue;
        }
    }

    return zEVcC;
}

double EEsJBTBgPYIN::HWARNagdlnL(double ICsXVaopHufICm, string DwOIJMFT, string MyDLtAOXRAXqbryp, int nABaoGkSyDMPspO, int ZqmTnNLAR)
{
    bool Gcgnwl = true;
    string mtkXbMOeQI = string("GZqrBmTXaVLdtraAHMHrkPHjtIJtjCQiELGkRLGfNkHWNLFIOdGKJXScBwTuinrunjhOAVhSuEMYuBNPLuxDtjSsFWYBepybnXHYzWOvgbRbO");
    int WOqiGOfwV = 1332972198;
    int gDdwQTYa = -1045860630;
    bool DhtdL = false;
    bool koUPUFzuwWGvWOc = true;
    int EYUSBzklv = 998189555;
    bool MXFElWdth = false;
    double INIPlTtCoQ = 825905.7683338086;
    double lCkwPknLKfWwraf = 580476.5468832478;

    for (int oAsZMpGE = 729294002; oAsZMpGE > 0; oAsZMpGE--) {
        continue;
    }

    for (int GiEYGTmGDuz = 89957143; GiEYGTmGDuz > 0; GiEYGTmGDuz--) {
        continue;
    }

    for (int WkWDHHwklKwD = 1077562186; WkWDHHwklKwD > 0; WkWDHHwklKwD--) {
        continue;
    }

    return lCkwPknLKfWwraf;
}

void EEsJBTBgPYIN::MEMaTvsnsgF(double zYCMuJbfm, double mwJakXSJezmtvxx, string FztakRh)
{
    double ghWpcFXwmo = 947039.3142945558;

    if (mwJakXSJezmtvxx != -906191.5681994238) {
        for (int EsRSCAEaIHSq = 719997685; EsRSCAEaIHSq > 0; EsRSCAEaIHSq--) {
            FztakRh = FztakRh;
            ghWpcFXwmo -= zYCMuJbfm;
            zYCMuJbfm *= zYCMuJbfm;
            FztakRh += FztakRh;
        }
    }
}

EEsJBTBgPYIN::EEsJBTBgPYIN()
{
    this->wxdicGYBrz(-1011310.3861610173, true, -716681.8246778415, true);
    this->FcjRpvgmFBL(false, -83385269);
    this->TfArR(true, string("hKDnHNIAvsOtbbstNqeALWIwowxYZyAsaLNwps"), string("QjQJnZtQAqMyzPVMZlZlhDMhRjKyBtYMBTFuIYuqWBAmmzRQQxQlrLAhYHZvnhemtkdCGkUVAQwuexxodyZrDyNLHKVlwVtpoMRKEHGpK"), 817287.7192317296);
    this->gwWypeMtsMnlM(true, -582019062);
    this->ynxVCiltdIRs();
    this->UtdLwem();
    this->rZpEvcvazrB(string("pHTyNfxBiqSoXou"));
    this->EGcGnuatRvIQ(string("WbLEZcPwKnyJJMmClKwcJWBLADtgQKFYMIYLxKNvyfnIcUAaozopwzThDCvFDAWhVTlpfnwqEaGxsJAeKFUlywTVieNMgrxHAaFRU"), 1111143684, string("TNuSpTSxONnRbjQfhmzjqTjBBlLOYWwSQmNpdAdyexZgLkJFxhVvbdQstryMQwyeVkWeZrqDgZCCatHTPMiPSAWnVBIHLLgBCPJjbpDUQXbZOjKJJXCGuSbZougSmmmUyAcAGjxAlakuFBdXslstVJlFxTYJOAvvNDSOkEWBEuKiHPIjggQbXrpPceYsVMQdeUoiRdRfmDcbxyiNdVnfoELEpYslMpRkzQxxsM"));
    this->pKurxHCWo(false, -446477.43645769445, -1269538564);
    this->HWARNagdlnL(-368304.7960056806, string("xfAEIQgZySjTkbjPYsnuArzumIhnfQRjzrFnNCIUtvHkceyKaknLEZnDskfrpAFxhJqXEHTStNVAFSFFAcYmezOSallbeOOCYmJWBQRwhlQFbKRxiPZvVEdmiCRLUzKcomiIxQAfGbbcblzLRmMtsuDJOcTAXIAhxfKBXJUYtcIeYZINomHEtApmxqZrGFLIpO"), string("FaeDQDUYKduEzPNbbNYywTzcOoxERfJxDnitAsQiUFADUnGwGiBfBEZFryKyXSVeGBVxgimfdCbbVCJhejIJeqBGuiBdhBJLgVkZutTDUhOuYGXVbIDWFFIpJBGQQALoGGzfPweFcWLAN"), -1981960592, 269133906);
    this->MEMaTvsnsgF(-906191.5681994238, 374658.72975822457, string("IFbFqtQoOFjuXPWSiueUgRJHhoXRgfaHbELAhiTprloicJeDXiaLjLlfriJOwzKChDjiskrNAQwPUvnuMQbjFStvGjKGZbUZUDtyNnBQPRVroRIcRIuRpCrDfDUEyjEfEuQZWSNmzGGnNRdgifNSsArMuaPtqGiGMQCOaaTjLzbKZpPxxvwzFmVtAjnUNbOFibsiTwMzCThJokvCdJdgsZLwYgBlGPqlLPY"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LepbXTibyYXGowpe
{
public:
    bool ZniMvFcG;
    int xLeFWoX;

    LepbXTibyYXGowpe();
    double OlueuFtKvIGNKIN(double efmUsMHPipJuipK, bool dCSjJDraVb, bool pKiDHrXldhuENewZ, int PvEVMHGTCs);
    string byNWCjMIbTIBf(bool vkmGoSjtXOnySa, string sheukvoW, int btZUcmX);
    bool CMkudyUhMpY(string yobjHPzbtkFxW, string aFbDPcYWoMMDgq, int iOSkykkKffoN, double lnucDdIENeAbbc, int rveOVoW);
    void qIztkjSZPaG();
    void WPkutEmvue(int GkkpZFHj, int JGiji);
    double PzZmHhD(int HeSycftwIMZQi);
    bool tMdgTNlFcu();
    void AliZJgGUnQ();
protected:
    string CYTmhHR;
    double zWVmV;
    int elkAocdFqMiqTs;
    string fxbFLvymqU;

    bool kzfAYhu();
    double IUgRQlhku(bool vLJMBIHCNCqTif);
    int OIByZfsSGA();
    string mDTFTntwXUZk(bool QAQfyvRuiDyaW, int lEoynpNHFC, bool niktTLNRjqTWk, bool KAjaixEeVkih, bool qKyqWsjqV);
    int qiuAetbkZxeGAGI();
private:
    string BwTCTp;
    bool IZzunCMxld;

    bool vWnFaXhh();
    int jaMlgKZVZVZyS(bool OzaXogogKsZ, bool kSIfUdNHu);
    bool FdIZuBqjcb(bool zUTbwoRaSb, int iTALvPtJyQkyM);
    double FCegkGp(double WKSYsneARzdBdphv, int hoWZoIBrJ, string SchWekhfEcip);
};

double LepbXTibyYXGowpe::OlueuFtKvIGNKIN(double efmUsMHPipJuipK, bool dCSjJDraVb, bool pKiDHrXldhuENewZ, int PvEVMHGTCs)
{
    string AnfyFaM = string("bDvdYLzlPtuaJZvWkRnpKThihMdamLrazMDMVUiGEbjxBeihcR");
    int goalI = -1487801861;

    if (AnfyFaM <= string("bDvdYLzlPtuaJZvWkRnpKThihMdamLrazMDMVUiGEbjxBeihcR")) {
        for (int qfWzaAbsyHb = 2111991926; qfWzaAbsyHb > 0; qfWzaAbsyHb--) {
            continue;
        }
    }

    for (int TSbeIKVJwAxDn = 1867073060; TSbeIKVJwAxDn > 0; TSbeIKVJwAxDn--) {
        PvEVMHGTCs *= PvEVMHGTCs;
    }

    for (int JNnJXocoXkZ = 1254469722; JNnJXocoXkZ > 0; JNnJXocoXkZ--) {
        continue;
    }

    return efmUsMHPipJuipK;
}

string LepbXTibyYXGowpe::byNWCjMIbTIBf(bool vkmGoSjtXOnySa, string sheukvoW, int btZUcmX)
{
    string ENhAHESBLvq = string("tqrhwHtyYacVPMd");
    bool tUYTwxH = true;
    string mEXMytTZe = string("WTTQHLLTvDEQpQUOfocWrNNFeuahhupywKXHYjEKegYyQjHCksbyeiKwQtBTwBABugEAPorGbLrHZgmTNemMgIhVqPsoIdKEuYTwIQuimhHeYylkIvyUAmsfJqzxIaeyyGShKdyVFMjAtOSQlWBIbkUotCIUsHqpunhhjy");
    double NKFxzs = 375658.68828573986;
    string hamlaw = string("DLmixrhsjahjrjnbgOXgnkZmlzQDJIGuaexRzsqgyFhLIsiHDOcll");

    if (hamlaw <= string("tqrhwHtyYacVPMd")) {
        for (int ToEWiUyK = 122131520; ToEWiUyK > 0; ToEWiUyK--) {
            hamlaw += sheukvoW;
            btZUcmX += btZUcmX;
            mEXMytTZe = mEXMytTZe;
        }
    }

    for (int oSBqFgeVfFgkK = 1423912129; oSBqFgeVfFgkK > 0; oSBqFgeVfFgkK--) {
        ENhAHESBLvq = hamlaw;
        hamlaw = sheukvoW;
        tUYTwxH = tUYTwxH;
    }

    if (hamlaw != string("tqrhwHtyYacVPMd")) {
        for (int HqnDWTgJD = 2020952671; HqnDWTgJD > 0; HqnDWTgJD--) {
            hamlaw += sheukvoW;
        }
    }

    for (int jQWxnq = 79309596; jQWxnq > 0; jQWxnq--) {
        ENhAHESBLvq = hamlaw;
        btZUcmX = btZUcmX;
        mEXMytTZe += mEXMytTZe;
        sheukvoW += ENhAHESBLvq;
        ENhAHESBLvq = hamlaw;
    }

    for (int zZuYZqlgepARW = 758354194; zZuYZqlgepARW > 0; zZuYZqlgepARW--) {
        hamlaw += ENhAHESBLvq;
    }

    return hamlaw;
}

bool LepbXTibyYXGowpe::CMkudyUhMpY(string yobjHPzbtkFxW, string aFbDPcYWoMMDgq, int iOSkykkKffoN, double lnucDdIENeAbbc, int rveOVoW)
{
    string TAHqSfFVj = string("YYzYnyjXpdQQTYwhncUXnNvblaCjXodZtzluZALbyRagvloBPVqxrrQtSnXxwjrJEuWwQCtKeAZJynwWLSyWWHZLHozHXbNyZKbwQvZFsScbDSHiYhXJTHneDxDLSgCpyGqUVNObqjFrlFPsKhMomvRZINKvNCMokuRWIldsaHukpsPRTqvkEpvjliUcskzNZybYAiYZkcnaP");
    double aenkdVC = -512392.70096068474;
    string ebiNzoQHfmCzhQx = string("rRuHMqEkoXEibEbLHcQCHqjWcjmApSoXBWhDFCRuenHbtEHrwtQygKDdTSqWxOAvSkktEJBqjXRYadwIiLGSMSksKBYHfVUrvTMmuCvUNosrggPVJMYkMBeWHnhPWhGPIO");
    double WpmQCoVOQzQnEoPV = -766312.058952939;
    int JakxWaSplboFL = 1032364682;
    bool iJUcDvs = true;
    int OAwmHJZA = -1939523452;

    for (int OWwluUXvDxtG = 1711970236; OWwluUXvDxtG > 0; OWwluUXvDxtG--) {
        yobjHPzbtkFxW += ebiNzoQHfmCzhQx;
    }

    for (int sHdOfjZpDUfOp = 1376317356; sHdOfjZpDUfOp > 0; sHdOfjZpDUfOp--) {
        TAHqSfFVj = TAHqSfFVj;
    }

    for (int aOajiEemJq = 1677896384; aOajiEemJq > 0; aOajiEemJq--) {
        ebiNzoQHfmCzhQx += yobjHPzbtkFxW;
    }

    return iJUcDvs;
}

void LepbXTibyYXGowpe::qIztkjSZPaG()
{
    double XWdNgzv = -238196.90370618744;
    int ULonrHJuVf = 953281527;
    string Sghbf = string("OIxvECAqqGUpUjenDQzLcWHciktOqmATglHKeDDDkWRGRioSrAJnHjdZpSxpxSWvuRzkQWCArnMMogcjijyBkICZNqVrFFGfrxBRVqFBZDRpUhhwRgidwREHWEAbYyvvXsQLOYO");
    bool rzjZMPLF = true;
    double dtYIvO = 470858.8291482891;
    double DqSROwx = -298650.03952229;

    for (int MGesHvRfNwfUIfb = 991809019; MGesHvRfNwfUIfb > 0; MGesHvRfNwfUIfb--) {
        Sghbf = Sghbf;
        dtYIvO -= XWdNgzv;
    }

    if (dtYIvO != -238196.90370618744) {
        for (int nbnljmF = 1598109643; nbnljmF > 0; nbnljmF--) {
            XWdNgzv -= DqSROwx;
            rzjZMPLF = ! rzjZMPLF;
        }
    }

    for (int twrXH = 1840600056; twrXH > 0; twrXH--) {
        XWdNgzv /= dtYIvO;
        dtYIvO /= dtYIvO;
    }

    for (int osxAiiKzlCLHLae = 564253540; osxAiiKzlCLHLae > 0; osxAiiKzlCLHLae--) {
        DqSROwx = DqSROwx;
        Sghbf += Sghbf;
    }

    for (int LrElXBfE = 1047590851; LrElXBfE > 0; LrElXBfE--) {
        XWdNgzv *= XWdNgzv;
        XWdNgzv = DqSROwx;
    }

    for (int DuqDKfYeTuyyQTm = 553090995; DuqDKfYeTuyyQTm > 0; DuqDKfYeTuyyQTm--) {
        DqSROwx = dtYIvO;
        dtYIvO *= XWdNgzv;
        DqSROwx /= dtYIvO;
    }
}

void LepbXTibyYXGowpe::WPkutEmvue(int GkkpZFHj, int JGiji)
{
    double SMHGnXHUqMzYJs = -774382.5041254993;
    string QgShfWuCgS = string("EErFKcdbiCoycrHwiqIFABgfvJPTQkkJAIwCtlEaxOmsONvIVXNcWiFEvfsXdbHYNxfFyjqajAxFilTRADfHIpJKSjPubAkWejljhftPMyUyIhxvPQDOnBEuQwbNMOzztjjyYjrEImjekJGUEAcZrDivIorGMhyAuWvwVdwHEZcnBlgUAjnCViQkXyzOuTsWIJkqAdqMCoBKZxexCqLTpyCBDpZpheCCdeRniXspJzomUyiYnwAuHAGtIEWCG");
    int ddUqGIvIiBMm = 789809833;
    int LexrTwzyYR = 1943670049;
    int EyPKSizKEZffsyKt = 1870956672;
    double lvTdutCsmKsTC = -309904.2160691819;

    for (int vuvAySSqgBSdSwlv = 1076838022; vuvAySSqgBSdSwlv > 0; vuvAySSqgBSdSwlv--) {
        LexrTwzyYR -= JGiji;
        EyPKSizKEZffsyKt *= GkkpZFHj;
        QgShfWuCgS = QgShfWuCgS;
        JGiji *= ddUqGIvIiBMm;
        EyPKSizKEZffsyKt *= LexrTwzyYR;
    }

    for (int xCZsuOreBVy = 900036585; xCZsuOreBVy > 0; xCZsuOreBVy--) {
        ddUqGIvIiBMm *= ddUqGIvIiBMm;
        JGiji *= EyPKSizKEZffsyKt;
        EyPKSizKEZffsyKt -= JGiji;
    }
}

double LepbXTibyYXGowpe::PzZmHhD(int HeSycftwIMZQi)
{
    double ookyjV = 460732.2924429356;
    double ljQLj = 506558.34714415914;
    int aQWiMhLQ = -349648560;

    if (aQWiMhLQ == 114412343) {
        for (int dvbKsOGmj = 867568793; dvbKsOGmj > 0; dvbKsOGmj--) {
            aQWiMhLQ /= aQWiMhLQ;
            HeSycftwIMZQi = HeSycftwIMZQi;
            aQWiMhLQ *= aQWiMhLQ;
            ookyjV += ljQLj;
            ljQLj = ookyjV;
            ljQLj = ljQLj;
            HeSycftwIMZQi *= HeSycftwIMZQi;
        }
    }

    return ljQLj;
}

bool LepbXTibyYXGowpe::tMdgTNlFcu()
{
    string OIwpZDaxDcQnfQi = string("RfdybAcqwUUYPBiVeDIZCKYAwqJuFiHRpMmmkgzAzyuAlCgqblYTLMubwUtFhoFJUKeLmTmyaphRQuUkkn");

    if (OIwpZDaxDcQnfQi == string("RfdybAcqwUUYPBiVeDIZCKYAwqJuFiHRpMmmkgzAzyuAlCgqblYTLMubwUtFhoFJUKeLmTmyaphRQuUkkn")) {
        for (int MVnyWgTovVZ = 2031134391; MVnyWgTovVZ > 0; MVnyWgTovVZ--) {
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
        }
    }

    if (OIwpZDaxDcQnfQi > string("RfdybAcqwUUYPBiVeDIZCKYAwqJuFiHRpMmmkgzAzyuAlCgqblYTLMubwUtFhoFJUKeLmTmyaphRQuUkkn")) {
        for (int fWmSd = 1090988257; fWmSd > 0; fWmSd--) {
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi += OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi += OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
        }
    }

    if (OIwpZDaxDcQnfQi > string("RfdybAcqwUUYPBiVeDIZCKYAwqJuFiHRpMmmkgzAzyuAlCgqblYTLMubwUtFhoFJUKeLmTmyaphRQuUkkn")) {
        for (int IZsJHcQYej = 2127741593; IZsJHcQYej > 0; IZsJHcQYej--) {
            OIwpZDaxDcQnfQi += OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi += OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi += OIwpZDaxDcQnfQi;
        }
    }

    if (OIwpZDaxDcQnfQi >= string("RfdybAcqwUUYPBiVeDIZCKYAwqJuFiHRpMmmkgzAzyuAlCgqblYTLMubwUtFhoFJUKeLmTmyaphRQuUkkn")) {
        for (int EiCwqYkJtqLTCHY = 1707838940; EiCwqYkJtqLTCHY > 0; EiCwqYkJtqLTCHY--) {
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi += OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi += OIwpZDaxDcQnfQi;
            OIwpZDaxDcQnfQi = OIwpZDaxDcQnfQi;
        }
    }

    return false;
}

void LepbXTibyYXGowpe::AliZJgGUnQ()
{
    bool IAYdlqLx = true;

    if (IAYdlqLx == true) {
        for (int OnLzQom = 762160345; OnLzQom > 0; OnLzQom--) {
            IAYdlqLx = IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
            IAYdlqLx = ! IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
            IAYdlqLx = ! IAYdlqLx;
            IAYdlqLx = ! IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
        }
    }

    if (IAYdlqLx == true) {
        for (int XtKvCFHZb = 394510479; XtKvCFHZb > 0; XtKvCFHZb--) {
            IAYdlqLx = ! IAYdlqLx;
            IAYdlqLx = ! IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
            IAYdlqLx = ! IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
            IAYdlqLx = IAYdlqLx;
        }
    }
}

bool LepbXTibyYXGowpe::kzfAYhu()
{
    string yXQmUOQhSkic = string("rrBOLBwhvcuWVCRjKmqsDcaOYApkrunRwEPxLBQzDLxsvuFHRQgTUiUPLEBtUFourAGNSEmBgoPNGJZZFjhJPtmaRCJTytWVAQozfLkosrUSCGyuRbviIHgfrXiVFXwVPHowqZBJXyAtzmeUtQJtSBOIdBEavlaUKXCYnRpzruURcXEGjUDkgWbGKptcrPEYSgaFYwNemdyCIAmIriLeKmNdMIuNsNCHLbHMGytXtNEwGLiZJ");
    bool WACeshVZtnTGeqTn = true;
    int OBhBrlPPuPbrEadg = -909999927;

    if (OBhBrlPPuPbrEadg < -909999927) {
        for (int qWriwEZlFTRrQ = 1029087706; qWriwEZlFTRrQ > 0; qWriwEZlFTRrQ--) {
            WACeshVZtnTGeqTn = ! WACeshVZtnTGeqTn;
        }
    }

    if (yXQmUOQhSkic <= string("rrBOLBwhvcuWVCRjKmqsDcaOYApkrunRwEPxLBQzDLxsvuFHRQgTUiUPLEBtUFourAGNSEmBgoPNGJZZFjhJPtmaRCJTytWVAQozfLkosrUSCGyuRbviIHgfrXiVFXwVPHowqZBJXyAtzmeUtQJtSBOIdBEavlaUKXCYnRpzruURcXEGjUDkgWbGKptcrPEYSgaFYwNemdyCIAmIriLeKmNdMIuNsNCHLbHMGytXtNEwGLiZJ")) {
        for (int QxgsO = 116648492; QxgsO > 0; QxgsO--) {
            WACeshVZtnTGeqTn = ! WACeshVZtnTGeqTn;
        }
    }

    return WACeshVZtnTGeqTn;
}

double LepbXTibyYXGowpe::IUgRQlhku(bool vLJMBIHCNCqTif)
{
    int EItMjklqznqhDy = -1730732895;
    bool kAONovffZyIyN = true;
    bool HhGJqZYQdCU = false;
    bool JJwYUXqNd = true;
    string VQQhaFDXwt = string("xeBdynhajMtECERfByExyDnuALeDpAXEgzwtetVMfyfAIlzugKuAvtjKxYPOsqchHRyaMgKhUYdeCqhneoGVNgFMpaGnGYcAplhCFklCQ");

    if (kAONovffZyIyN == false) {
        for (int equlTQbA = 481940674; equlTQbA > 0; equlTQbA--) {
            JJwYUXqNd = ! kAONovffZyIyN;
        }
    }

    if (vLJMBIHCNCqTif != false) {
        for (int UlQWAfvOusLgNWkQ = 262282137; UlQWAfvOusLgNWkQ > 0; UlQWAfvOusLgNWkQ--) {
            kAONovffZyIyN = ! HhGJqZYQdCU;
        }
    }

    if (kAONovffZyIyN != false) {
        for (int hWZSSUuW = 1997181011; hWZSSUuW > 0; hWZSSUuW--) {
            VQQhaFDXwt += VQQhaFDXwt;
        }
    }

    for (int NXNrhjHtotJyKn = 1283120893; NXNrhjHtotJyKn > 0; NXNrhjHtotJyKn--) {
        kAONovffZyIyN = vLJMBIHCNCqTif;
    }

    return 691882.3906545916;
}

int LepbXTibyYXGowpe::OIByZfsSGA()
{
    string CEabKAUgMCb = string("zLPMMQTpoofbqMKnfXnljThsjbuMRBpOvArupCOZdRhcfOomFlJuBWbJKSavEPzsBIBCwyUxsJSfkZrZWbWyXCnNuyNRhaesjxJTzPmqcMvVfcnhTxbhcWzxqaBXgHSBbFInFQdBpAxycUS");
    int ZVUMk = -1224343033;
    bool FMQqGgQMiqFV = true;
    string XhoHcs = string("TaDdJdkDRDymMTNXzRnxTlyPXzvvqzsWPivGotVoztFKzgGFDktMTsOEdsRvIALLMWoKnDvMSfuLjCLjMWfawlTksQGUOPSCjyWMmESjudDzqZX");
    int qndbok = 489731258;

    if (XhoHcs != string("zLPMMQTpoofbqMKnfXnljThsjbuMRBpOvArupCOZdRhcfOomFlJuBWbJKSavEPzsBIBCwyUxsJSfkZrZWbWyXCnNuyNRhaesjxJTzPmqcMvVfcnhTxbhcWzxqaBXgHSBbFInFQdBpAxycUS")) {
        for (int digFbVCAlAGeJaZZ = 1940883702; digFbVCAlAGeJaZZ > 0; digFbVCAlAGeJaZZ--) {
            XhoHcs = CEabKAUgMCb;
            FMQqGgQMiqFV = ! FMQqGgQMiqFV;
            ZVUMk *= ZVUMk;
        }
    }

    if (XhoHcs != string("zLPMMQTpoofbqMKnfXnljThsjbuMRBpOvArupCOZdRhcfOomFlJuBWbJKSavEPzsBIBCwyUxsJSfkZrZWbWyXCnNuyNRhaesjxJTzPmqcMvVfcnhTxbhcWzxqaBXgHSBbFInFQdBpAxycUS")) {
        for (int sQaUaq = 193543541; sQaUaq > 0; sQaUaq--) {
            qndbok += qndbok;
            FMQqGgQMiqFV = ! FMQqGgQMiqFV;
            ZVUMk /= ZVUMk;
        }
    }

    return qndbok;
}

string LepbXTibyYXGowpe::mDTFTntwXUZk(bool QAQfyvRuiDyaW, int lEoynpNHFC, bool niktTLNRjqTWk, bool KAjaixEeVkih, bool qKyqWsjqV)
{
    int gWNtJNr = -671398894;
    string kBtnmGJa = string("dKDRvBZYVconAOdqgyHgRVDUfiAKEPthiDtqszinYutdNdYqRgejV");
    double pCrEQK = 1043366.0883612732;
    bool uQDdIGao = true;

    for (int PohvvUAFWfU = 1887513605; PohvvUAFWfU > 0; PohvvUAFWfU--) {
        niktTLNRjqTWk = uQDdIGao;
        QAQfyvRuiDyaW = ! QAQfyvRuiDyaW;
        uQDdIGao = ! uQDdIGao;
        pCrEQK -= pCrEQK;
    }

    for (int WLtLIpiMsOyICaxC = 402676934; WLtLIpiMsOyICaxC > 0; WLtLIpiMsOyICaxC--) {
        QAQfyvRuiDyaW = KAjaixEeVkih;
        QAQfyvRuiDyaW = ! qKyqWsjqV;
        niktTLNRjqTWk = niktTLNRjqTWk;
        KAjaixEeVkih = QAQfyvRuiDyaW;
        qKyqWsjqV = uQDdIGao;
    }

    for (int LurrReoKK = 77929662; LurrReoKK > 0; LurrReoKK--) {
        niktTLNRjqTWk = niktTLNRjqTWk;
    }

    for (int BelbbiTQzM = 2122488039; BelbbiTQzM > 0; BelbbiTQzM--) {
        KAjaixEeVkih = qKyqWsjqV;
        QAQfyvRuiDyaW = niktTLNRjqTWk;
        niktTLNRjqTWk = ! KAjaixEeVkih;
        niktTLNRjqTWk = ! qKyqWsjqV;
    }

    for (int aXbyvjiqgzFG = 1860759285; aXbyvjiqgzFG > 0; aXbyvjiqgzFG--) {
        uQDdIGao = ! QAQfyvRuiDyaW;
        KAjaixEeVkih = ! qKyqWsjqV;
        uQDdIGao = KAjaixEeVkih;
        qKyqWsjqV = ! QAQfyvRuiDyaW;
        niktTLNRjqTWk = qKyqWsjqV;
        KAjaixEeVkih = qKyqWsjqV;
    }

    return kBtnmGJa;
}

int LepbXTibyYXGowpe::qiuAetbkZxeGAGI()
{
    bool XmrpCpstmSRV = false;
    int GmWOPSVPqkyZ = -894111879;
    bool CjEKB = false;
    bool pwQYZVUI = true;
    int MRKRnlAJdp = 1634452904;
    bool RHYLDk = false;
    bool CvjsZFjcKiH = true;
    double MsiPkrhuNU = -766250.4359122253;
    int FOivEhtZ = 1958393458;

    if (CvjsZFjcKiH != false) {
        for (int hvSitftdeRvt = 109675743; hvSitftdeRvt > 0; hvSitftdeRvt--) {
            CvjsZFjcKiH = ! CjEKB;
            XmrpCpstmSRV = ! XmrpCpstmSRV;
            MRKRnlAJdp *= GmWOPSVPqkyZ;
            CjEKB = pwQYZVUI;
        }
    }

    for (int HLQHWMBfhWGVvrHw = 1872444209; HLQHWMBfhWGVvrHw > 0; HLQHWMBfhWGVvrHw--) {
        FOivEhtZ /= MRKRnlAJdp;
        pwQYZVUI = CjEKB;
        RHYLDk = CjEKB;
        GmWOPSVPqkyZ -= FOivEhtZ;
        pwQYZVUI = XmrpCpstmSRV;
    }

    return FOivEhtZ;
}

bool LepbXTibyYXGowpe::vWnFaXhh()
{
    int jByrfNzQtSDSCwF = -622466333;
    string aAdzBNZU = string("wcnHPhqhbMYFeFGbogVAafvfUCdydExyqfuTOcsVDWtNaSQqrvZJgHMDSiqgcPDMplDuwMUGfeZtlVIDCWsSzeHSyazDvqdyPvJIhKRHVpDdPzFlCyUoEcAtuMdNlsBYAiuEpChLMnYzqShkjJYNBnomyidFBPYaHrnNmGyjCAdsaSjeOZveqCIMWjdkaItesBOzmiQCcEbs");
    double QgQSKGymfSs = -88019.30274983982;
    int xZWRUrGv = -1092539327;
    int Petoua = 1811958502;
    string bJIMxmEjgLMDv = string("bGzkexGGiQgnmnAjENeSbbVDfsTyeKgcJGGbZdsvfzrnmKQMmUfRNTvWOvsrAfvVRnUmfnhCyWzBqiSrPCRfbBsHPXmJuITndCGAonCJymjnSnFptVbivhEDkbiKHhuOvfzVFAsrodvhvHXVFvlfpClwCXgjelmGhFpUsMsTPnLvAksTjZCDRcpyGCifcjifjdBwDtKzqKdSKSBAasoAxsJEFIYwLANMTabL");

    for (int zYCinfHFpf = 1915333544; zYCinfHFpf > 0; zYCinfHFpf--) {
        aAdzBNZU += bJIMxmEjgLMDv;
    }

    for (int WoFeDviNyk = 2012528029; WoFeDviNyk > 0; WoFeDviNyk--) {
        continue;
    }

    for (int gEVfwy = 1690993489; gEVfwy > 0; gEVfwy--) {
        bJIMxmEjgLMDv += bJIMxmEjgLMDv;
    }

    if (bJIMxmEjgLMDv <= string("wcnHPhqhbMYFeFGbogVAafvfUCdydExyqfuTOcsVDWtNaSQqrvZJgHMDSiqgcPDMplDuwMUGfeZtlVIDCWsSzeHSyazDvqdyPvJIhKRHVpDdPzFlCyUoEcAtuMdNlsBYAiuEpChLMnYzqShkjJYNBnomyidFBPYaHrnNmGyjCAdsaSjeOZveqCIMWjdkaItesBOzmiQCcEbs")) {
        for (int sXfvstmuyE = 1472549364; sXfvstmuyE > 0; sXfvstmuyE--) {
            continue;
        }
    }

    return true;
}

int LepbXTibyYXGowpe::jaMlgKZVZVZyS(bool OzaXogogKsZ, bool kSIfUdNHu)
{
    int yKlMafTbnN = -2003080504;
    int DsiUWjaK = 1415267720;
    bool lAOyGLnSuoZiOB = false;
    bool DdcvnBXqHiPLJw = false;
    double NvYnFMtlvbaknUxT = 676006.9738545481;
    int clutKDaY = -692953253;
    bool xNBCmeAp = false;
    string yPyKHMSBEMbsyQY = string("ZwTeZZcmsqXCRwYXRVjtknNvZEbyHDjaVwGGRKufpoWexTeiJhXWvXyCsqalBhIqCajvJnSnonKwDMAJwblUMSGKJRYPCkMEFurlnYzHGNaxrrIQuErQSTqAyNECLkNSxeKALjKFfzbwEcytRxLbxCKIWczirJIaIHDaUUIWtdAXElIprcUpsDLgrFRHbHWQSWMYNwE");
    bool jytiRbVWlLurrTH = false;

    if (OzaXogogKsZ == false) {
        for (int EKbeMCzq = 1673551485; EKbeMCzq > 0; EKbeMCzq--) {
            lAOyGLnSuoZiOB = ! xNBCmeAp;
            yKlMafTbnN -= yKlMafTbnN;
        }
    }

    if (lAOyGLnSuoZiOB == false) {
        for (int vWsFglUnNrv = 914439136; vWsFglUnNrv > 0; vWsFglUnNrv--) {
            DdcvnBXqHiPLJw = lAOyGLnSuoZiOB;
            jytiRbVWlLurrTH = kSIfUdNHu;
            kSIfUdNHu = ! lAOyGLnSuoZiOB;
            yPyKHMSBEMbsyQY = yPyKHMSBEMbsyQY;
            DsiUWjaK += yKlMafTbnN;
            clutKDaY = DsiUWjaK;
        }
    }

    if (OzaXogogKsZ == false) {
        for (int eFPtTrKuAEluJaPa = 2044952140; eFPtTrKuAEluJaPa > 0; eFPtTrKuAEluJaPa--) {
            jytiRbVWlLurrTH = ! xNBCmeAp;
        }
    }

    return clutKDaY;
}

bool LepbXTibyYXGowpe::FdIZuBqjcb(bool zUTbwoRaSb, int iTALvPtJyQkyM)
{
    bool JRiFCHvEANCbtnK = false;
    string Oltbuoto = string("IoKgCfZNFxhvsdEAXMAiVwRyVPkTVNVviRRwQvYRPdTwFDAhdhkjDjAyiZiYHDMlrxBFXdpJJzC");

    if (Oltbuoto == string("IoKgCfZNFxhvsdEAXMAiVwRyVPkTVNVviRRwQvYRPdTwFDAhdhkjDjAyiZiYHDMlrxBFXdpJJzC")) {
        for (int AthWmC = 1934946807; AthWmC > 0; AthWmC--) {
            iTALvPtJyQkyM /= iTALvPtJyQkyM;
        }
    }

    if (zUTbwoRaSb == false) {
        for (int uXqJbfdomsnSSx = 181735630; uXqJbfdomsnSSx > 0; uXqJbfdomsnSSx--) {
            continue;
        }
    }

    for (int wKQNFgLJQEWztPDb = 502720949; wKQNFgLJQEWztPDb > 0; wKQNFgLJQEWztPDb--) {
        Oltbuoto = Oltbuoto;
        Oltbuoto += Oltbuoto;
    }

    for (int qlVhR = 1759555535; qlVhR > 0; qlVhR--) {
        zUTbwoRaSb = JRiFCHvEANCbtnK;
    }

    return JRiFCHvEANCbtnK;
}

double LepbXTibyYXGowpe::FCegkGp(double WKSYsneARzdBdphv, int hoWZoIBrJ, string SchWekhfEcip)
{
    bool jYGVoXMx = false;
    double ipcsmDvq = 925789.5054343652;
    string cBtuNyQOf = string("bOMnf");
    double eSwiLCN = -960375.454634758;
    string VWJeSlCmTaeMA = string("whLMFCZGQZtGnqFnARPTaaNwLlWQCHCQecnTtoiJBdSBOTcNIIvcwXMmKInrxJeosjOOctPjykkAbBhgNJYaEVcHACVzRdxeQhhtrshvQrofTOKOEcCAAXBzeyPKfoVdGLBboivfEbIWWntOlQBATnGdQZEIDFsFfGXucvBGoVywlMNgvKmnWTYutEvaAjfSjwEBHSqQelwQcWPuFxFbVXCP");
    int ZUXeANrRKg = -492530019;
    bool PoldFHnm = false;
    string RXKipSSzbiMmHADW = string("EUNObeQhVeFrBNIflpQSNrjTkjylxMlOCVUtARncOcxtIoVLUppuwOmhdBKmFlOFExDEyOjcemBbGniocEOxctHjJKPIiBwplriiSqtFbdUEGBQbLNOqcIcGnPlZNxpWoBjxzfXoLCpGUILibKilhxBRSOdFEcvqfpyJzvodhmhXtrRJW");
    double kkKxFdITjD = -970085.8049754853;

    for (int mqqhJ = 1387095530; mqqhJ > 0; mqqhJ--) {
        continue;
    }

    for (int TofGBzMgrfpNbU = 146896385; TofGBzMgrfpNbU > 0; TofGBzMgrfpNbU--) {
        SchWekhfEcip = VWJeSlCmTaeMA;
        WKSYsneARzdBdphv -= ipcsmDvq;
    }

    return kkKxFdITjD;
}

LepbXTibyYXGowpe::LepbXTibyYXGowpe()
{
    this->OlueuFtKvIGNKIN(-1011316.3827802412, false, false, 1209391458);
    this->byNWCjMIbTIBf(true, string("pF"), -122554128);
    this->CMkudyUhMpY(string("apgozfSnIUkoIZSgBeplZsCFaoXMwUypJXajpxsFnKJCtovUIHNzPGiELLdZIqCNAsrxDHfLzERKZGDWbIlVNmElSPcpuqroCCVmLHpFOmTZKXgEfMAqyTMdYePsBsAgrzXezRnwyEhPnQuSHdFIuoZFMWldkYdqROiLFnhKseMDAGCmmTNhqfiJcLHZpnqmQOeHcUYQrmITBUkVLWAfms"), string("YqSXVGXaVbkrRiGkxptAGlCOjzmiYHVoBWSZhXIhxqysFXACJyMQjjgvFawMVpZbkaOaYRkvjPIPDYfebzVzypISVXtjITHkLAKioBmCTDyHboSmoVIcigdCNpmyicSDQKjCBFHksqvTzQnmgabPyVrteWQfuUIhveRfnkbPVVvpjYdqYvLdbmQsvabNFAJDqjCiUrChOiMvXbcktWWiyztmzfahCKoMBrbyRQweGAtbJDYcXcZXXlkFWF"), 1703390405, -811870.3564421572, -673168109);
    this->qIztkjSZPaG();
    this->WPkutEmvue(689650114, 183584618);
    this->PzZmHhD(114412343);
    this->tMdgTNlFcu();
    this->AliZJgGUnQ();
    this->kzfAYhu();
    this->IUgRQlhku(false);
    this->OIByZfsSGA();
    this->mDTFTntwXUZk(false, -630578390, true, false, false);
    this->qiuAetbkZxeGAGI();
    this->vWnFaXhh();
    this->jaMlgKZVZVZyS(false, false);
    this->FdIZuBqjcb(true, -1258661523);
    this->FCegkGp(-43074.49682540954, 983789348, string("GtzQzELAQsDWwsGluLqTpNGzhwCscSPsxWGMDkknindWynatqtAIFzEXkboplACYclZKEoqdQvIVuohyzQygopxzXVKDlzPcTqoiAJlJHcXfgQdbYsWDcJskxRBRcTUiHzasXNugqQeyiClGMJSxS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OrrfIjxxTjhm
{
public:
    double EnQORwWi;
    int qZTeBEzHKAncWAHs;

    OrrfIjxxTjhm();
    string JvBGsk();
    bool WgLdCstyoMLveJhK();
    bool BSRmEck(double QzfSTfM, bool pvOYq, double iXCsfdsE);
    string iLOtFlWc(string juHSNjYmH, bool AHQzdvtWd, int tGiogIDEpZXZcqXV, double jhdNCuR, int zwlHt);
    bool RoChstE(string iKyebuVfSXgfwdHf, string JIsHRZ, string oYxsH, bool MmEZLcAVOdkRhy, double hKEqdSAPZBM);
    double TEWMayQDMEF();
protected:
    double UOaGKJGdf;
    bool HolEkHexOfS;
    bool nNcmDGpVKMkwtp;
    string xVbQspMoplBjOu;

    int DIaaKsPGhmYVDudA(string HHDZeIqnxZC, double gOOhaoavM, int DsBIfMTWwtUrf, int mHHNwcfzDgLqV);
    string xprGijriQlWBfeOJ();
    int FOzwbTGKHxAPpRP(bool UQvKwPGljTG, string ZTjZkPeTIT, int XjClc);
    string PiofwoSriMQGbhNN();
    double IycFXYHzpahP(string xibNPjiGJSvxHvVQ);
    string yRufJf(double FVrgsCyd);
private:
    string EbwFfV;

    int pMpVEuPSrzGExdyj(int VNQKemoriWY, string cSmNv, double HqUtexRfA, string XiyNFsVXFYBiR);
    bool zmGuMx(string RVOpRVtSEJvR);
    bool ZYETbgwIfTWi(bool vtBMUuBCkbZJ, bool rJLspZGl);
    string OkbOBL(bool xkdpb);
    double uAGUw(double naeCPpRBYTFvST, int LJhUItcUvfRNTSM, bool sZCbw);
};

string OrrfIjxxTjhm::JvBGsk()
{
    double wNZugQwfXXQl = 722350.600332529;
    double RXiiarhIdN = 672051.1510209544;
    double hSIzCzkygUDqXWP = 707296.9261850981;
    string sOBOwnOPainz = string("AyadQVlgWpSBpQWUttMhRqnvaeWznbRwVfZWJqMDYRMVThvMoELbXydYyTKPSFvMsIEAxbxhvePYTVFounFotqsEGGoGtZrxxkyNXpGkBGcKzfLtrhbzJGwFcGBudRUmSBduUEkzCSCoYVwvjCqMUdgRahQBwpBizpNJcscJxtLqSs");
    double qslwMptUjuo = -361892.3155044797;
    int qYrhvnhehU = -954096291;
    int nNCFCUxwda = 1868373439;

    for (int zAEyBrGoWQcv = 9493548; zAEyBrGoWQcv > 0; zAEyBrGoWQcv--) {
        RXiiarhIdN *= wNZugQwfXXQl;
        hSIzCzkygUDqXWP /= wNZugQwfXXQl;
    }

    if (RXiiarhIdN <= -361892.3155044797) {
        for (int ymOqQvLIUn = 825233597; ymOqQvLIUn > 0; ymOqQvLIUn--) {
            qslwMptUjuo *= RXiiarhIdN;
            wNZugQwfXXQl += hSIzCzkygUDqXWP;
        }
    }

    for (int xMLvdnYIMQn = 1338299803; xMLvdnYIMQn > 0; xMLvdnYIMQn--) {
        qYrhvnhehU -= nNCFCUxwda;
        qYrhvnhehU -= qYrhvnhehU;
        hSIzCzkygUDqXWP -= RXiiarhIdN;
        qslwMptUjuo += wNZugQwfXXQl;
        wNZugQwfXXQl = qslwMptUjuo;
        hSIzCzkygUDqXWP = qslwMptUjuo;
    }

    for (int EqDKqwahLsdwJ = 1911754520; EqDKqwahLsdwJ > 0; EqDKqwahLsdwJ--) {
        qYrhvnhehU = qYrhvnhehU;
        wNZugQwfXXQl -= hSIzCzkygUDqXWP;
        qYrhvnhehU -= nNCFCUxwda;
    }

    if (RXiiarhIdN >= 707296.9261850981) {
        for (int BJcQmd = 1321798823; BJcQmd > 0; BJcQmd--) {
            qYrhvnhehU *= qYrhvnhehU;
            RXiiarhIdN += hSIzCzkygUDqXWP;
            qslwMptUjuo *= wNZugQwfXXQl;
        }
    }

    return sOBOwnOPainz;
}

bool OrrfIjxxTjhm::WgLdCstyoMLveJhK()
{
    double ZPCwctpA = -32865.82741772423;
    double jBncqmIbQSF = 823073.0554039121;
    double FIKusJYlmDywnYHm = 468645.97533488885;
    double dSDxGIqK = -793760.5570213856;
    string trJOTXUzEzUeJ = string("ecPfalDHYUIfGZcuHZvLKpFiHZuSrLATQTaKwzllHRFksIPccbQbjadYjpOnhxLOUdEYKLIpJnMArWUKuUDrpCkPpYUyHdmwDmWfamQWEfYPNbYfEuqAooTxMcwibNiTjWDLaYkqPIsrmfkCHdKybAdLBnJKBIImunjWaG");
    bool kqXptaFIsefyzA = true;
    bool cVvXP = false;
    double zSGedWhgR = 468528.94436306274;
    bool LBmACWTCrv = true;
    int jXOpvbOoCvsQX = -1930789670;

    if (ZPCwctpA > 468528.94436306274) {
        for (int nIsBHespSlHp = 918496161; nIsBHespSlHp > 0; nIsBHespSlHp--) {
            jBncqmIbQSF += ZPCwctpA;
        }
    }

    for (int DjMnUgOcjcBLH = 168899413; DjMnUgOcjcBLH > 0; DjMnUgOcjcBLH--) {
        FIKusJYlmDywnYHm += jBncqmIbQSF;
        LBmACWTCrv = ! cVvXP;
    }

    return LBmACWTCrv;
}

bool OrrfIjxxTjhm::BSRmEck(double QzfSTfM, bool pvOYq, double iXCsfdsE)
{
    double ofkwlim = 776992.4222279695;
    bool ihJamnoHZXseCNYk = false;

    if (QzfSTfM != -335505.8432229154) {
        for (int MlSHnAjDv = 1907621192; MlSHnAjDv > 0; MlSHnAjDv--) {
            QzfSTfM += QzfSTfM;
        }
    }

    if (QzfSTfM > 776992.4222279695) {
        for (int jiPPyNwGeEVrWEIf = 566847731; jiPPyNwGeEVrWEIf > 0; jiPPyNwGeEVrWEIf--) {
            pvOYq = pvOYq;
        }
    }

    for (int aZAcpIcQtgOK = 140310455; aZAcpIcQtgOK > 0; aZAcpIcQtgOK--) {
        iXCsfdsE = QzfSTfM;
        iXCsfdsE /= QzfSTfM;
        ofkwlim *= ofkwlim;
        ofkwlim /= ofkwlim;
    }

    for (int VEwiLRAI = 1845059474; VEwiLRAI > 0; VEwiLRAI--) {
        QzfSTfM += QzfSTfM;
        QzfSTfM -= ofkwlim;
        QzfSTfM = iXCsfdsE;
        QzfSTfM /= iXCsfdsE;
        ihJamnoHZXseCNYk = pvOYq;
        QzfSTfM -= iXCsfdsE;
        ihJamnoHZXseCNYk = ! pvOYq;
    }

    for (int AOeUhEGblHocOU = 1367585011; AOeUhEGblHocOU > 0; AOeUhEGblHocOU--) {
        continue;
    }

    for (int sWUtCT = 973649417; sWUtCT > 0; sWUtCT--) {
        ofkwlim /= iXCsfdsE;
    }

    if (ofkwlim == 776992.4222279695) {
        for (int bUZmqyX = 316415412; bUZmqyX > 0; bUZmqyX--) {
            QzfSTfM /= ofkwlim;
            ihJamnoHZXseCNYk = ! ihJamnoHZXseCNYk;
            ofkwlim /= ofkwlim;
        }
    }

    return ihJamnoHZXseCNYk;
}

string OrrfIjxxTjhm::iLOtFlWc(string juHSNjYmH, bool AHQzdvtWd, int tGiogIDEpZXZcqXV, double jhdNCuR, int zwlHt)
{
    bool IqlljZVhCiBd = false;
    bool gkjrunubSn = false;
    double CATLoeR = 58546.5848788891;
    string tAvrKrEBrpCCQwTg = string("MxkhISWtkptqcxwEAoLmUzEwXGbesGLOzveXgARkWOihJSWuDuMiyzWxBrykpKoBnhYdtkdULgyHepwNuxytopjvoDexNaYgcRXoWLL");
    int GtFcaZrEkUl = 1107464798;
    bool TssOyjjVvTKPknU = true;
    string OzIkvlC = string("dZnKJpBxjtnDXFbkhBNkQqDcJHxARwxTdvQfTWwCiLhkFWTppLHzAZzoTIknZqtfdCSgaKDwPejfpHkg");
    bool LPSgMFrqbwohK = false;
    int kgaPshLMgnfPwZ = 1752898536;

    if (AHQzdvtWd == false) {
        for (int ItXAwECHW = 902058168; ItXAwECHW > 0; ItXAwECHW--) {
            AHQzdvtWd = ! AHQzdvtWd;
        }
    }

    return OzIkvlC;
}

bool OrrfIjxxTjhm::RoChstE(string iKyebuVfSXgfwdHf, string JIsHRZ, string oYxsH, bool MmEZLcAVOdkRhy, double hKEqdSAPZBM)
{
    bool SQXkGcgGtAUI = true;
    bool UkgtXjkRyXP = false;
    string jGGEVNeE = string("mAemYGvJggjDwZKuqDFyPylAlHacUufTZDmkxoNQgcRFfblhFfZWgitrZcusOuvmvfUlGFofPcnpQZiNDWMbQ");
    double XLCDfUF = 287103.54979219445;
    string SAGpFAyVQaY = string("NnwTYmFsSpnvYpEhxnyZBbqbevmhcXTqYnQuFySPjmAqYHqvzPdJUMYFrjpEtuTZuzjKQjFIczCNePBMYVUEjXkDxkoSaorPHwByXYZYXQYRiftsqTgaaGjJvFIIdlBKQNUbLHA");
    int TyRXm = -373015513;
    string KnkmHSesT = string("UpF");

    if (KnkmHSesT == string("YTXpREZHJFAEQXEyrQVBJSQczQzenklTirzMudSTPWJoKDWzEsdgBHAvHzIIlsxqRiBLqXoKTiUZXtxKoQeVgqKBfoghQZzncdWkAlfdGwDijaMmsTLFXEOuwNvydJShmJaCmvjNmljcMgzlMGTEryvUhvTjsGKzqPtBCBxwpYKiJjEqbjumCBZXudziBAWjayKUyRnvKZPMSQrAxvSPMVjbKFPKYJvtUXWUD")) {
        for (int jdVoBHPa = 1001387631; jdVoBHPa > 0; jdVoBHPa--) {
            continue;
        }
    }

    for (int YGSffiAYxZxTwCC = 1562575013; YGSffiAYxZxTwCC > 0; YGSffiAYxZxTwCC--) {
        KnkmHSesT = JIsHRZ;
        JIsHRZ = jGGEVNeE;
        iKyebuVfSXgfwdHf += SAGpFAyVQaY;
        jGGEVNeE += KnkmHSesT;
    }

    return UkgtXjkRyXP;
}

double OrrfIjxxTjhm::TEWMayQDMEF()
{
    double NvUMUbLaxYhyRP = 894862.8793859694;
    int IQYqVAFWOmcUP = 1619957889;
    double eYYDcRNPBYZZFUsu = -715397.9820956648;
    string VmWkAixrGWojtnqp = string("ffvGDExFjBEzmTTqTKRxtRCBnLUsTDewApFVDdKGJyTrNCrzzyUTzLOVmFLmqlVqUqPmjScibIywKjBmXgUOACGBqmDvEcfudOOeJDfcTnmuieYdsPbuzUZUQlKjmgCZFfKcCqKUQkureuSawWNixSNqNOzGUEcHexguqzKLtxQHbmcdvNzDeWfRlCzaAvZGPkOeDcEQXvoovXssEV");

    if (eYYDcRNPBYZZFUsu <= -715397.9820956648) {
        for (int ayhxIMjHcpW = 217649397; ayhxIMjHcpW > 0; ayhxIMjHcpW--) {
            NvUMUbLaxYhyRP = eYYDcRNPBYZZFUsu;
            VmWkAixrGWojtnqp += VmWkAixrGWojtnqp;
        }
    }

    for (int mXuyLy = 822512985; mXuyLy > 0; mXuyLy--) {
        eYYDcRNPBYZZFUsu /= NvUMUbLaxYhyRP;
        NvUMUbLaxYhyRP -= eYYDcRNPBYZZFUsu;
    }

    return eYYDcRNPBYZZFUsu;
}

int OrrfIjxxTjhm::DIaaKsPGhmYVDudA(string HHDZeIqnxZC, double gOOhaoavM, int DsBIfMTWwtUrf, int mHHNwcfzDgLqV)
{
    string ThpjCjGKZbTaX = string("xWLHxZADrflfEiYiULjCiLtaBrvjiiSICnJAqlRdFItDSDHDBRdCZKdSztwkVGjcIvGhUozrsMRyAGXtHqxXeAsWtAJtvAiMJtGYqeYBjmsaVImjvSBJfanLnTSuggyttYxdDVmiygWODnFVQxjtqfIuGvDlnwYFNDOJWksifOVQpNGJKitpGawjObdBOJlJgqDLZJxkidcrCaIZWfQCIFjRqEAGSqseKbmgaYRjzf");
    string FaagWXlaEW = string("RKjnzaDAWnrTWr");
    bool zBlvDvofgrp = true;
    int QWuMucZWkjRuTgk = 90126676;
    bool eGfZKRMu = false;
    double vQGEoMqfMalO = 126294.4832499522;
    int ohBKVIVP = 2036861251;
    double OdnwKAluRBrzhRG = 356973.1344513966;
    double wVIVYE = -441275.290033668;

    if (wVIVYE < 356973.1344513966) {
        for (int gBMiglFI = 1908763875; gBMiglFI > 0; gBMiglFI--) {
            zBlvDvofgrp = ! eGfZKRMu;
        }
    }

    return ohBKVIVP;
}

string OrrfIjxxTjhm::xprGijriQlWBfeOJ()
{
    string vJQiWpPB = string("QNsPTsZYkGlkhdGNCZFhRKXhLPIzEZJfmtodHopWBZdEAKQOlYVhaapdgjRVPEWMEfYxcleUTeyiechCZMYrboaRrCOKmQjAVaIIMZvJLEyGQizJdBsruFRSiNcBMNmtytwLJtsrdbxZjdFZjxjc");
    double poOdmE = -195511.5533536817;
    bool KavEyMbToeHptRFR = false;

    for (int rpwNzPwVrfhRZRfI = 1857913391; rpwNzPwVrfhRZRfI > 0; rpwNzPwVrfhRZRfI--) {
        continue;
    }

    return vJQiWpPB;
}

int OrrfIjxxTjhm::FOzwbTGKHxAPpRP(bool UQvKwPGljTG, string ZTjZkPeTIT, int XjClc)
{
    bool XbVcHtFAiqCrB = false;
    bool UOcose = false;
    double MhfDdygYh = 950069.098223027;
    bool szZIlB = false;

    if (UQvKwPGljTG == false) {
        for (int NDnTmVjtYKZYexJc = 500430392; NDnTmVjtYKZYexJc > 0; NDnTmVjtYKZYexJc--) {
            szZIlB = XbVcHtFAiqCrB;
            UQvKwPGljTG = ! UOcose;
        }
    }

    if (szZIlB != false) {
        for (int NmvhZHziiwjU = 888687440; NmvhZHziiwjU > 0; NmvhZHziiwjU--) {
            UOcose = XbVcHtFAiqCrB;
            MhfDdygYh = MhfDdygYh;
        }
    }

    if (XbVcHtFAiqCrB == false) {
        for (int JUxEpsW = 209575106; JUxEpsW > 0; JUxEpsW--) {
            UOcose = UQvKwPGljTG;
            szZIlB = ! UOcose;
            MhfDdygYh *= MhfDdygYh;
            szZIlB = szZIlB;
        }
    }

    return XjClc;
}

string OrrfIjxxTjhm::PiofwoSriMQGbhNN()
{
    double ScCrFms = -133138.00513110915;
    int NsXnAdNie = -691742514;
    string xMNYSL = string("EVVptpfSLmdDvColRluHIfCrKiuTyqhkaOiBwngwaiserLWmqiwvZUKnJDMKdhSAzZgnFOGECximDuNYxMTNatEbnSieEPlKbiIjncZSfKGANbwuFwDIlJWxOqkjkJLTZFOOCqXohKKENUfLIbKXpPemFhMiawBIBEJPsUsOKiekDcCkHbUdqtOTQVnsGzreQmJEDluTVDFIxcNpFByrJNZdG");
    bool vWlFcDofvsJyYpk = true;
    double HbKVOsK = 994403.2853730251;

    for (int MwaUFihnP = 644930179; MwaUFihnP > 0; MwaUFihnP--) {
        xMNYSL += xMNYSL;
        xMNYSL = xMNYSL;
        HbKVOsK -= ScCrFms;
    }

    for (int MlIMs = 420688811; MlIMs > 0; MlIMs--) {
        continue;
    }

    for (int yIOLcxMpqZXGfw = 1958614222; yIOLcxMpqZXGfw > 0; yIOLcxMpqZXGfw--) {
        HbKVOsK *= HbKVOsK;
        HbKVOsK *= ScCrFms;
        xMNYSL += xMNYSL;
    }

    for (int FmNFHMXEhEda = 1684948734; FmNFHMXEhEda > 0; FmNFHMXEhEda--) {
        ScCrFms -= ScCrFms;
    }

    for (int uzbAOibLyI = 2049427172; uzbAOibLyI > 0; uzbAOibLyI--) {
        xMNYSL += xMNYSL;
        HbKVOsK *= ScCrFms;
        NsXnAdNie *= NsXnAdNie;
    }

    return xMNYSL;
}

double OrrfIjxxTjhm::IycFXYHzpahP(string xibNPjiGJSvxHvVQ)
{
    int hxsOcbOQMlj = -930927758;
    double IRklwPOgwdNW = 925199.9124462906;
    double SnFdbJu = -9655.1186860148;
    bool rxswgpsMpZug = true;
    string dcXod = string("BWlEUuDfrnZGuiaGJHTaDrfZdPFPUNxHdmUWqKqCPdZSeitahBPMYyhqVyZKVamOijjskswqFEKyTSwgsETxqHdirqKGTKesaYyiRPzOZDdFrnLtBeeLoVrOSDnySBOGGWpifAnPfAxFBGLOWqVjQzWpJTxLnuogcW");
    string tozRBrYgbxxJBKoh = string("CCzNEfAkNAwsmylWBzvVNZKMRSCcIiBwGFSMYgyTZqOCybCssNadqesVNjomdQSRUOpKBwvCiGlpgVjReEhAMvQWiVWIGbJhKWeitTURHtybgzUHApidUiDLdbrSiNOWiZgoaXhRZPmbACraYAzDweQWrmTeYxPdSBz");
    bool WdhtTl = true;
    double RZvgefgSTKYKVjc = 409028.4928120307;
    int BpBiOcQvp = -300381807;
    int nFPYKdRvrFgEYOx = -1679797041;

    for (int YHkrYwtcS = 591654110; YHkrYwtcS > 0; YHkrYwtcS--) {
        continue;
    }

    for (int fOWaqAUwsZjE = 1021488661; fOWaqAUwsZjE > 0; fOWaqAUwsZjE--) {
        dcXod = tozRBrYgbxxJBKoh;
    }

    return RZvgefgSTKYKVjc;
}

string OrrfIjxxTjhm::yRufJf(double FVrgsCyd)
{
    double irpoeXmWnnFJqF = 933729.9432269235;
    bool gVlKwliyloQJP = true;
    int ikPem = 1572102675;
    double otRFtMjB = -351936.1057560851;
    bool WznSO = true;
    double snRizaRsHinvmxAU = 497679.8768944089;

    for (int jdueXohdLBtrCDz = 1472896467; jdueXohdLBtrCDz > 0; jdueXohdLBtrCDz--) {
        snRizaRsHinvmxAU = otRFtMjB;
        irpoeXmWnnFJqF -= FVrgsCyd;
        FVrgsCyd += irpoeXmWnnFJqF;
    }

    return string("MXEWkfWHfTpLIggrjdGncfSaVmpGvfXnAvIjoBmqxYeqtrQvjqoUOtPSZZgOWBPNfYxSJevJZNpIsMVOyFtzqtTybIHevKajjtEPUACgMKAZQHLqlvUQmqgPcfMqUZIerVKzJdP");
}

int OrrfIjxxTjhm::pMpVEuPSrzGExdyj(int VNQKemoriWY, string cSmNv, double HqUtexRfA, string XiyNFsVXFYBiR)
{
    string EhIio = string("TaZiVziNUWjwMpPZiSZLTbwhKHJWEOUcmqtbJOMjFMIFhPXtLKOAuJyxZxutNdaWqadYFmcPEVOQwzFDIXcjFeluZDShuwyKNgIYwgAyBnXyWYgHeXZUNhsBSkwsvLe");
    double nHTfNjCMTlWt = 895362.594948933;
    int UtDgExRHzoUiTWeY = -838296601;
    bool GEXmDgzsoUnYj = true;
    bool EXCAvWqQBasRxIk = false;
    double txDUFZOQldkZvLk = -812996.2791006234;

    for (int syByOysVgCjaFGtC = 708960194; syByOysVgCjaFGtC > 0; syByOysVgCjaFGtC--) {
        continue;
    }

    return UtDgExRHzoUiTWeY;
}

bool OrrfIjxxTjhm::zmGuMx(string RVOpRVtSEJvR)
{
    bool JofnHLpsBbD = false;

    if (RVOpRVtSEJvR > string("ptdKGHNcMkBHSEABenDvaXtCgDeYLfzDtZZYjoYKRpaKHytMvTBkb")) {
        for (int nkJMjiRkQv = 1669947267; nkJMjiRkQv > 0; nkJMjiRkQv--) {
            JofnHLpsBbD = JofnHLpsBbD;
        }
    }

    if (RVOpRVtSEJvR > string("ptdKGHNcMkBHSEABenDvaXtCgDeYLfzDtZZYjoYKRpaKHytMvTBkb")) {
        for (int IsSZAIpLPubQT = 2138948026; IsSZAIpLPubQT > 0; IsSZAIpLPubQT--) {
            JofnHLpsBbD = ! JofnHLpsBbD;
            JofnHLpsBbD = JofnHLpsBbD;
        }
    }

    for (int SoRqLswhC = 1552175784; SoRqLswhC > 0; SoRqLswhC--) {
        RVOpRVtSEJvR = RVOpRVtSEJvR;
        RVOpRVtSEJvR += RVOpRVtSEJvR;
    }

    for (int SWcuA = 853191978; SWcuA > 0; SWcuA--) {
        RVOpRVtSEJvR += RVOpRVtSEJvR;
        JofnHLpsBbD = ! JofnHLpsBbD;
        JofnHLpsBbD = ! JofnHLpsBbD;
        JofnHLpsBbD = JofnHLpsBbD;
    }

    return JofnHLpsBbD;
}

bool OrrfIjxxTjhm::ZYETbgwIfTWi(bool vtBMUuBCkbZJ, bool rJLspZGl)
{
    double LwjSltHaGQw = -259071.953815637;
    bool RjKzdXerDAEYvMP = true;
    int GHfPVswqTjLKvkK = 1952649882;
    string rvYRGThw = string("UgjONPgksyBjQdKREyhfABIbJkxvUqNfZaqyNLQpaNfxvduwoZyujgHdydQpnNhcOHNNFAgQisFKkikiKZyAySGgxCulwObEKOPyyCkOkOaBMcsZUuRmrAmlDXwrdVTeiiuFpKmPMNzQBQEVUQGwmwyRBnuiRAjVVmvdFbOxwLqxqEVvHQNDwiRiBnFUuOdmQELYtvVCzMdVlLYMTiEYMiHRCmXtAol");

    if (rJLspZGl == false) {
        for (int pVpCiaJreqJpZ = 774251874; pVpCiaJreqJpZ > 0; pVpCiaJreqJpZ--) {
            continue;
        }
    }

    for (int KfRTkYJip = 209685169; KfRTkYJip > 0; KfRTkYJip--) {
        RjKzdXerDAEYvMP = vtBMUuBCkbZJ;
        vtBMUuBCkbZJ = RjKzdXerDAEYvMP;
        rJLspZGl = RjKzdXerDAEYvMP;
    }

    for (int BdiPmbWhHCYgji = 1244761939; BdiPmbWhHCYgji > 0; BdiPmbWhHCYgji--) {
        RjKzdXerDAEYvMP = ! rJLspZGl;
        rJLspZGl = ! rJLspZGl;
    }

    return RjKzdXerDAEYvMP;
}

string OrrfIjxxTjhm::OkbOBL(bool xkdpb)
{
    bool IoYLXi = false;
    double SKAgHTQLhDHhGFxO = -457382.4349052596;
    double TfHOqkKw = -147579.2805876952;
    double YlSTFSbfwyhK = -931257.9850049644;
    string esWDspatnVJsB = string("QApgEvFYfHkgvMiRZLpUWddtdqhqqQTztnZzZMrDOTCpSLlFCfJdglvQiVVmcViYVzqXShhlQTqyCyWeQjbpVnWumswWrceWuyRNehURfliJDcWVXxwJddluJwZIDZCFlRcywymozPoLYgLmsAmTybtpzErDILHDraPyxVLDdVzBtxUrHAFxWQYvCZFQBTEJdhgzFXKzDvMAvMZhEViUKkZATigQHQZnDBbshzUqfbnaRLBUTZ");
    int QzfLckoQgRNCoFJ = 1103725376;
    string YbfbNButwP = string("zOhgkvANcphbnXhHktvSjsJVfYpShRzaDpVTcsGprPnyMRJxJUwRHDdHLXMWvxEMDAgcFKUDNRJHbcsEeqMVkYvFdstRdYTLnFkFWyunbgEtdKdhEkidAQBB");
    bool nZoScipz = true;

    for (int zkrnzIIdgvsC = 415426923; zkrnzIIdgvsC > 0; zkrnzIIdgvsC--) {
        nZoScipz = xkdpb;
        TfHOqkKw *= SKAgHTQLhDHhGFxO;
    }

    for (int OvaVWZCLhXrO = 1931637773; OvaVWZCLhXrO > 0; OvaVWZCLhXrO--) {
        continue;
    }

    for (int OdbMOyOmR = 716119694; OdbMOyOmR > 0; OdbMOyOmR--) {
        xkdpb = ! nZoScipz;
    }

    for (int hEJNarev = 1621941796; hEJNarev > 0; hEJNarev--) {
        YbfbNButwP += esWDspatnVJsB;
    }

    return YbfbNButwP;
}

double OrrfIjxxTjhm::uAGUw(double naeCPpRBYTFvST, int LJhUItcUvfRNTSM, bool sZCbw)
{
    double TpvtupqfkJMV = -454429.77094649134;
    string seblx = string("GpVFQdrCoRcKLQsuJOMSLXFJAvNBQOGPUgnERkwSlzgdIqZZszQkoiqyKRiCOpxDswhRibpgCAjeJZSCRnwCNUMBgCImpATeWIMKORMYloqaTXqodcNyNVGYMWaRHzFDOFmQZzooOTDHmTLdBruoFwmGnQcDaG");
    bool gXkfSDsrkmjZ = false;
    double klPRhelUj = 820877.9815394403;
    int CvgtNCDIugThSPh = -929508252;

    return klPRhelUj;
}

OrrfIjxxTjhm::OrrfIjxxTjhm()
{
    this->JvBGsk();
    this->WgLdCstyoMLveJhK();
    this->BSRmEck(-608977.4781228163, false, -335505.8432229154);
    this->iLOtFlWc(string("rzGikMPDWjnhTCoJqQbPKpwvcvbJiMxTrlbAaxRpaUgVoXMUEtQXnrnMSkiVBxBawgUJygGiDyORADszQlLvCfeQLGXALZeOxCGnLBzjpaCdEcAooSKqMnzMaMcImXqKgDlXAATRTbVfvpPBTWugD"), false, -1328289789, 1036709.3106998844, -830108191);
    this->RoChstE(string("YTXpREZHJFAEQXEyrQVBJSQczQzenklTirzMudSTPWJoKDWzEsdgBHAvHzIIlsxqRiBLqXoKTiUZXtxKoQeVgqKBfoghQZzncdWkAlfdGwDijaMmsTLFXEOuwNvydJShmJaCmvjNmljcMgzlMGTEryvUhvTjsGKzqPtBCBxwpYKiJjEqbjumCBZXudziBAWjayKUyRnvKZPMSQrAxvSPMVjbKFPKYJvtUXWUD"), string("D"), string("AcirzUOnBPzbgxyOWLUgeUyvFAKjRvuqRAVFFaQcFcfzbpiaOQduFDzReMZkjdCrDHurthBdoYzcPoPOckizZYVgNhmeeJkulfIqDlcwuvZboEZVOkk"), false, 440513.55748051504);
    this->TEWMayQDMEF();
    this->DIaaKsPGhmYVDudA(string("YAYfdMBJwPrutZyZirgnZrfSGeZEANnYzCSdTFJLNTfpGQgscdabqShRRJVzjpQnIJisUVkeWCVmRBODfxXXmCtDCySMETSayIWqgJQjptQfSxuwymCJQkJkuoVMDOwXaONMEqugetUDBBGcecHTfPEFirGazGSksAEBHYZRNPgDptMVAXubkGCHrpnzLfAhGeQnezdaxPqhvDurxikBzlITReUSdUHXlzVjlp"), -27594.96613120885, 466685240, -761158914);
    this->xprGijriQlWBfeOJ();
    this->FOzwbTGKHxAPpRP(false, string("CUiqDTexBCYUWSLmRdKoFfFACZAErXvysOZQakytVzRADYE"), 503480460);
    this->PiofwoSriMQGbhNN();
    this->IycFXYHzpahP(string("SqZIQGFgRlsDeQWmGSkDxODRbZ"));
    this->yRufJf(-576047.2099268144);
    this->pMpVEuPSrzGExdyj(-1194966939, string("jZJYyTZxDwhDUerOUvRKOsEgQrWwYvcUGMSUJvfNmDQawxPOQyHhNqlitQWUoTnlBjTTJVJolLTLRAMZEKfqscMtbEJYWulayGrhrELxaMXVTVxtSqWONeuKWLSOmGHOGjsncPPiuRTrsjyTUApFdUbjBmwkQpf"), -898156.1049297878, string("VNcwGXxHamrOlPpWwJbzdHMStaGPnHcaDqdEbpjPvKzggnrjmCVtArXtzlDvbeBfSqVSTaibsfLGYAScMyGpYXgcTXvtCuIYxyKMqzjStnkqiTOmmgZuHdfHFHGdvHooytKCiTTYERwMJWKtdWtMYTMLtIDgxIiedkrrPmMkoPnltxHwlYjmdNAdCxvrBlHAsYvcAHQWtdiTF"));
    this->zmGuMx(string("ptdKGHNcMkBHSEABenDvaXtCgDeYLfzDtZZYjoYKRpaKHytMvTBkb"));
    this->ZYETbgwIfTWi(false, false);
    this->OkbOBL(true);
    this->uAGUw(-305554.46004241006, 842448361, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tKNXyfjAc
{
public:
    double DiexUKtHBz;
    string oDyfCN;
    string RxaYRkmwplQpfpi;
    string GsaLpVyEud;
    double sVUamRXzXxOf;
    bool IVwGL;

    tKNXyfjAc();
    int WDQpHABRqWMqcv(string LIqNBg, int xbMQX, double MkTBMsxNEXEccfoD);
protected:
    bool ajySUtnny;
    string VBZsr;

    void arVrynmouFiU(int TPMBqUvbBM, bool CNeQBRTRRySGG, bool HkmhWnCpNIGqDLkH);
    string NVBmwTygZbZboGoP();
    double ENneATyaWSAZp();
    void rebiXt(string lCrUuxYHeIspQfp, double BDuYVTAERp, string oFUfPEYbd, double FWJwPbjsReCueQi);
    double LcxHNrjIJYSdkkc(int UIwVOpJNxOvmHAg);
    string DZTwpZhdYG(string XDBepRxd, bool UxKCIeKOiwASGqHS, bool QmTwjXZhPviOHXW, double TciFxR, string cwFYTZttJI);
    string CHsMAahURbPu(bool reWIevRgLtkd);
private:
    int huoXQRMf;

    bool dRtBcYnBVNqey(double oErmZcNHgZucux, string IoxzpdDUiDIqnD, int sJKbMvvoQuf, double hLWQaNGJQLXWEz, double hJjyqYhaQjpeG);
    string kSTyVrT(int OtRDzfZojYJE, int qHBjWopJspIdfmw, int vARYz, int uTzXQXrtkqSHdFk, double GaAJnxT);
    double FbtNiuLE(string iMKfDPMlHBBN, int hgrRWdWFtUrgK, int toCbsHRneO, int LJNzHPj);
    void wrNsncoLGuwiwBZ();
};

int tKNXyfjAc::WDQpHABRqWMqcv(string LIqNBg, int xbMQX, double MkTBMsxNEXEccfoD)
{
    bool IHKMqCoa = true;
    double NNErYztKMPCpqJ = -664269.4348081767;

    for (int QtWRc = 540428838; QtWRc > 0; QtWRc--) {
        xbMQX /= xbMQX;
    }

    for (int lTveNl = 792865324; lTveNl > 0; lTveNl--) {
        continue;
    }

    for (int CzNmivkQoBMSb = 884676805; CzNmivkQoBMSb > 0; CzNmivkQoBMSb--) {
        continue;
    }

    for (int ZenPkjtLJjtWavj = 1486373543; ZenPkjtLJjtWavj > 0; ZenPkjtLJjtWavj--) {
        MkTBMsxNEXEccfoD /= MkTBMsxNEXEccfoD;
        xbMQX = xbMQX;
        NNErYztKMPCpqJ -= MkTBMsxNEXEccfoD;
        IHKMqCoa = ! IHKMqCoa;
        MkTBMsxNEXEccfoD -= NNErYztKMPCpqJ;
    }

    return xbMQX;
}

void tKNXyfjAc::arVrynmouFiU(int TPMBqUvbBM, bool CNeQBRTRRySGG, bool HkmhWnCpNIGqDLkH)
{
    double HySJzT = 324958.74029427225;
    bool MdGhLh = false;
    int rCwNjCSdD = -331306978;
    int rydCferDGQAu = 327436095;
    double BDNZsqEbmJnBP = -849067.2669728498;
    double ewrnYOHedYv = 327511.85838600114;
    string fiEhdfYFMkyEp = string("XVGQVTroKrhAhIxnOBWyIGpknEfoDnZXkxQpIXYrvdEKaUZPpnOpvohIBhGKKWBvlzntGsZBYffTaAAftIzFERwQoCrOBXqjmKTAlhBLOqNwffZTHUIniXghoRFEtvbgAizhBvnjCOkaEeqJAgYgJkwptNdGBxRuAtEpipYwFngJdPLbtoNgMNkMexspGa");
    double ldKyogaGqHiJH = -293885.8327054414;
    string tdSFHbA = string("DepUUeWsNKYNlqRimoTeMTIVDmBDWKLEKSKCeJnFIIozQxcVYVZXKPIVDaWWkQFRiBKIguVoTWoHiSHTZKiEHWifonbdvJzOUQDXFWlCoPEDhaqDgQoZdfBxWMivbMmPUjIywcPzXgXrzIrnGFPyAEOCYbDjIqOYpMqfqhrUdIHffphNddQQJrCYJtXukgGJAKJkZhrzrFVxkJrIrjIwUBSspMwWgoAKdCiwQhHeuWRfnCAPiiNUviP");
    bool HSssCzzhGuVPGEvV = false;

    for (int pOOXOhHKFeOSF = 1457436873; pOOXOhHKFeOSF > 0; pOOXOhHKFeOSF--) {
        rydCferDGQAu += TPMBqUvbBM;
        TPMBqUvbBM = rydCferDGQAu;
        BDNZsqEbmJnBP /= BDNZsqEbmJnBP;
        BDNZsqEbmJnBP /= HySJzT;
    }
}

string tKNXyfjAc::NVBmwTygZbZboGoP()
{
    int MokqSXTGz = -1494744549;

    if (MokqSXTGz != -1494744549) {
        for (int OIDXE = 587830552; OIDXE > 0; OIDXE--) {
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
        }
    }

    if (MokqSXTGz >= -1494744549) {
        for (int zpYrdLM = 46021444; zpYrdLM > 0; zpYrdLM--) {
            MokqSXTGz += MokqSXTGz;
            MokqSXTGz *= MokqSXTGz;
            MokqSXTGz = MokqSXTGz;
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
        }
    }

    if (MokqSXTGz > -1494744549) {
        for (int NsxyrjMb = 646222404; NsxyrjMb > 0; NsxyrjMb--) {
            MokqSXTGz *= MokqSXTGz;
            MokqSXTGz = MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
            MokqSXTGz = MokqSXTGz;
        }
    }

    if (MokqSXTGz == -1494744549) {
        for (int TVWmxmcB = 2047168377; TVWmxmcB > 0; TVWmxmcB--) {
            MokqSXTGz -= MokqSXTGz;
        }
    }

    if (MokqSXTGz < -1494744549) {
        for (int NVqwGOyOigNK = 644112458; NVqwGOyOigNK > 0; NVqwGOyOigNK--) {
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz *= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz /= MokqSXTGz;
        }
    }

    if (MokqSXTGz < -1494744549) {
        for (int pmYgfLPl = 1914928720; pmYgfLPl > 0; pmYgfLPl--) {
            MokqSXTGz *= MokqSXTGz;
            MokqSXTGz = MokqSXTGz;
            MokqSXTGz *= MokqSXTGz;
        }
    }

    if (MokqSXTGz >= -1494744549) {
        for (int pduOBjIAVUdlfzIe = 498607122; pduOBjIAVUdlfzIe > 0; pduOBjIAVUdlfzIe--) {
            MokqSXTGz *= MokqSXTGz;
            MokqSXTGz -= MokqSXTGz;
            MokqSXTGz += MokqSXTGz;
            MokqSXTGz += MokqSXTGz;
        }
    }

    return string("YOMXhQgkMjfnWjVJuAigmmsuhfhGYpeviRlLZAYwVCfMSzJqBIwnKBfXOtaepCOkTWqzaPOLKNUMkPTRvLYEChXoigdUvpEAmhjXhTkRJynJEmmsYctUfVmPqxdQdcnlhwhHuZWxiSr");
}

double tKNXyfjAc::ENneATyaWSAZp()
{
    int fvtnpudGwbX = 112993927;
    string mBsBbfSqqwU = string("PQgzwEOcnOGfPIGwQYTUGJQEUoDeycWchdMKBaFqvZtSJQzBFCGXSvwjsgAtxiIMuuHPEAmNwnTcERsfgMwGMYLIqMcbKikEBLlJccQNRYDKCTwbcnXvmHcLhSZJhhSzViWqPCyAatWQXPaeEoqpKRMZFvusMiUccWfQsJyjZlHbqBFDskOtIKx");
    int ChGvVAFQfDkExp = 1288453021;
    bool FEXNT = true;
    int qwwGkjkYPGpL = -549160151;
    double uPlCdR = -1007459.2693092918;

    for (int TNUhb = 335854057; TNUhb > 0; TNUhb--) {
        fvtnpudGwbX = ChGvVAFQfDkExp;
        qwwGkjkYPGpL = ChGvVAFQfDkExp;
        fvtnpudGwbX *= fvtnpudGwbX;
        ChGvVAFQfDkExp *= qwwGkjkYPGpL;
        qwwGkjkYPGpL += fvtnpudGwbX;
    }

    return uPlCdR;
}

void tKNXyfjAc::rebiXt(string lCrUuxYHeIspQfp, double BDuYVTAERp, string oFUfPEYbd, double FWJwPbjsReCueQi)
{
    int OjErlvtfEcUn = 2100305224;
    string upXEk = string("khtdWMkCLHEsxcYvxrRIpxMRGXbSTczGKaqBagYicElRBXASPypTiNpVwovsydRfHrqpDlcbnRcfbVbSqKFvPvxNkRlBLlFeCrIMinTSBfMEfIQQDDlXYEhZeToNdsyvpOIrCzpGpVuhTvsHnVqNMMzSjFSEwaxOZzqJqv");
    double qtkKyAPgijxSLRe = -242652.4225400898;

    for (int abQkDBJELNvVWz = 1037232982; abQkDBJELNvVWz > 0; abQkDBJELNvVWz--) {
        BDuYVTAERp += BDuYVTAERp;
        BDuYVTAERp -= FWJwPbjsReCueQi;
        oFUfPEYbd += lCrUuxYHeIspQfp;
    }

    for (int OVqjOuKPnyPVI = 1054426813; OVqjOuKPnyPVI > 0; OVqjOuKPnyPVI--) {
        BDuYVTAERp = FWJwPbjsReCueQi;
        qtkKyAPgijxSLRe *= BDuYVTAERp;
        upXEk += upXEk;
        BDuYVTAERp += qtkKyAPgijxSLRe;
        lCrUuxYHeIspQfp = oFUfPEYbd;
        upXEk += oFUfPEYbd;
    }

    if (upXEk <= string("XgmNYOygXooNijOkNLcBaxUfgXacmJreFfLmRzEeTBtADdamTmaxEnNouauYfOsjejgK")) {
        for (int GhLhwWAJGhD = 669789597; GhLhwWAJGhD > 0; GhLhwWAJGhD--) {
            oFUfPEYbd += oFUfPEYbd;
            upXEk += oFUfPEYbd;
        }
    }
}

double tKNXyfjAc::LcxHNrjIJYSdkkc(int UIwVOpJNxOvmHAg)
{
    double fguUd = 806619.4252882621;
    int kufMmrecszvswt = 1917585687;
    int SxtwJUFPIBtdkmOs = 132277529;
    string afwWB = string("bQoxAIXWLh");
    int uVKlzKZPjgTqI = 1719796252;
    bool KwxgkVjLyIKbLuJi = true;
    bool WhfaJ = false;

    for (int tfIcasG = 335030577; tfIcasG > 0; tfIcasG--) {
        UIwVOpJNxOvmHAg -= UIwVOpJNxOvmHAg;
        WhfaJ = WhfaJ;
    }

    if (kufMmrecszvswt < 1706207703) {
        for (int zeNxvbD = 1517983998; zeNxvbD > 0; zeNxvbD--) {
            SxtwJUFPIBtdkmOs /= UIwVOpJNxOvmHAg;
            kufMmrecszvswt /= kufMmrecszvswt;
            uVKlzKZPjgTqI = kufMmrecszvswt;
            uVKlzKZPjgTqI *= SxtwJUFPIBtdkmOs;
        }
    }

    return fguUd;
}

string tKNXyfjAc::DZTwpZhdYG(string XDBepRxd, bool UxKCIeKOiwASGqHS, bool QmTwjXZhPviOHXW, double TciFxR, string cwFYTZttJI)
{
    string QMXtayLOPe = string("cTAWwyvdljPUHruBQAlBMUqncmUHSLlokEBEhZJuvyRCTWGtRknOUwrxWDFmuPNVLFraWxFMYHcmfeLIbAbbqoODdjBWJgblWAqEAWyoLxmpwLdfubupbacNswVVANUVOTGKSeaKZFAztyPAzzYnHwWfTErOweduwzLozocjNhiezlvecSFz");

    if (QmTwjXZhPviOHXW == false) {
        for (int veStkfDjAVQeTnGH = 2049048162; veStkfDjAVQeTnGH > 0; veStkfDjAVQeTnGH--) {
            XDBepRxd = QMXtayLOPe;
            QMXtayLOPe = XDBepRxd;
            QMXtayLOPe = cwFYTZttJI;
            cwFYTZttJI = QMXtayLOPe;
        }
    }

    for (int FFHlBlAstdgVum = 925702890; FFHlBlAstdgVum > 0; FFHlBlAstdgVum--) {
        QmTwjXZhPviOHXW = ! UxKCIeKOiwASGqHS;
        cwFYTZttJI = XDBepRxd;
        QMXtayLOPe += cwFYTZttJI;
        QmTwjXZhPviOHXW = UxKCIeKOiwASGqHS;
    }

    for (int MhKjaCsmjj = 779183729; MhKjaCsmjj > 0; MhKjaCsmjj--) {
        XDBepRxd = QMXtayLOPe;
        TciFxR -= TciFxR;
        QmTwjXZhPviOHXW = UxKCIeKOiwASGqHS;
        XDBepRxd += cwFYTZttJI;
    }

    for (int cOYmljWPUGsvALg = 281384322; cOYmljWPUGsvALg > 0; cOYmljWPUGsvALg--) {
        continue;
    }

    for (int NAHnkeLhkDASOIg = 1039015357; NAHnkeLhkDASOIg > 0; NAHnkeLhkDASOIg--) {
        continue;
    }

    for (int ThReThVQrSI = 832296460; ThReThVQrSI > 0; ThReThVQrSI--) {
        UxKCIeKOiwASGqHS = UxKCIeKOiwASGqHS;
    }

    return QMXtayLOPe;
}

string tKNXyfjAc::CHsMAahURbPu(bool reWIevRgLtkd)
{
    int VjSjSdsFb = 1202899837;
    int gbrRZceI = 580337455;
    bool DcUHR = true;
    int dUsYBqNjTE = 561056575;

    return string("QfdrjopbsfmtCAJVLoTlQEUTrpspOPdAmIAfp");
}

bool tKNXyfjAc::dRtBcYnBVNqey(double oErmZcNHgZucux, string IoxzpdDUiDIqnD, int sJKbMvvoQuf, double hLWQaNGJQLXWEz, double hJjyqYhaQjpeG)
{
    bool lJBauNBpVuQhZ = false;
    double uZrcYKFwQlJ = 752354.642989307;
    bool aZDYZe = true;
    int VVlFrpd = 1714591104;
    int VXjzCH = -1284605944;
    bool tHtBRyjYIiT = false;
    double MZFuRrjGoDwOOCJM = -1025368.5764767546;

    for (int NDLZbbVuy = 1564344220; NDLZbbVuy > 0; NDLZbbVuy--) {
        MZFuRrjGoDwOOCJM *= hJjyqYhaQjpeG;
        hJjyqYhaQjpeG /= uZrcYKFwQlJ;
        oErmZcNHgZucux += hJjyqYhaQjpeG;
    }

    return tHtBRyjYIiT;
}

string tKNXyfjAc::kSTyVrT(int OtRDzfZojYJE, int qHBjWopJspIdfmw, int vARYz, int uTzXQXrtkqSHdFk, double GaAJnxT)
{
    double hLonIBKlDJqL = 466894.128955343;
    double YkKgGlibBlTRJS = 75416.61369754229;
    string LDBHeSofV = string("wQqRoiPHlRJRgaaOuYGUibMUiAMBnFdhJEBvywFEHsSfULnoUwDPtkEENMAkpEUTWjUrjlGfBNFvkbDyiETStPxnblWzaemwiwkzdqtloDFSKlAhIHUPlNIuOxAszcqmMYfHCkjaInpaEqKvwEmsOleQsptGWziThUHCmOMitSoNtBKegBCbkeqtTpCmIjzXGpjIGoofnIxwCxUfOIVnsIYvWHZxRONDCpBg");
    int UmbcLtsAnZBec = 1845082335;
    int fKdSmngAFSieHxeT = 1856016095;
    int tpmCqSwtak = -509065109;

    if (qHBjWopJspIdfmw < -825656395) {
        for (int ThQwBnOHgnzBAkZ = 1330508844; ThQwBnOHgnzBAkZ > 0; ThQwBnOHgnzBAkZ--) {
            UmbcLtsAnZBec += OtRDzfZojYJE;
            UmbcLtsAnZBec *= vARYz;
            tpmCqSwtak *= tpmCqSwtak;
        }
    }

    if (tpmCqSwtak == 1845082335) {
        for (int JWxtTTNSurXQUP = 632714277; JWxtTTNSurXQUP > 0; JWxtTTNSurXQUP--) {
            vARYz /= tpmCqSwtak;
            UmbcLtsAnZBec -= tpmCqSwtak;
            tpmCqSwtak = tpmCqSwtak;
            hLonIBKlDJqL /= hLonIBKlDJqL;
            uTzXQXrtkqSHdFk *= tpmCqSwtak;
            uTzXQXrtkqSHdFk += fKdSmngAFSieHxeT;
        }
    }

    if (YkKgGlibBlTRJS >= 75416.61369754229) {
        for (int xxGtnpYIqXU = 1596002210; xxGtnpYIqXU > 0; xxGtnpYIqXU--) {
            fKdSmngAFSieHxeT /= fKdSmngAFSieHxeT;
            uTzXQXrtkqSHdFk -= qHBjWopJspIdfmw;
        }
    }

    for (int UcvUqJbA = 1666626495; UcvUqJbA > 0; UcvUqJbA--) {
        GaAJnxT -= hLonIBKlDJqL;
        uTzXQXrtkqSHdFk = fKdSmngAFSieHxeT;
        OtRDzfZojYJE = qHBjWopJspIdfmw;
        OtRDzfZojYJE *= OtRDzfZojYJE;
    }

    return LDBHeSofV;
}

double tKNXyfjAc::FbtNiuLE(string iMKfDPMlHBBN, int hgrRWdWFtUrgK, int toCbsHRneO, int LJNzHPj)
{
    int vljramipaCkc = 129696031;
    bool ktYYwaBVqSyk = true;
    int FikxjzmXht = 856146784;
    string ygKJKhnByXwoR = string("ZOgMRQwbtkyrmDeLQJtzMgGMF");
    int ILFfsGnmxzgAj = 1523728224;
    string rjDhLHIVmo = string("VDJzTeGzKzWahaVfmIjlWoMxSqTCVfoPVoAIIKlTJwoWeIfEVxjTZhgzntcNIWDnzvMoPqUQpEGgaYyeffQsufkmXHWHogSZKXPdaWwaKUbwFJORnumuFolSkryjoOfXSDYJFU");

    for (int LqjilKnka = 1218228838; LqjilKnka > 0; LqjilKnka--) {
        toCbsHRneO = vljramipaCkc;
        vljramipaCkc *= hgrRWdWFtUrgK;
    }

    for (int BWmzGxGVJtqnXuWb = 669112210; BWmzGxGVJtqnXuWb > 0; BWmzGxGVJtqnXuWb--) {
        continue;
    }

    for (int GgFbEXkrDaMDpI = 317442076; GgFbEXkrDaMDpI > 0; GgFbEXkrDaMDpI--) {
        toCbsHRneO = hgrRWdWFtUrgK;
        toCbsHRneO *= hgrRWdWFtUrgK;
        FikxjzmXht /= ILFfsGnmxzgAj;
    }

    for (int lrPDL = 1163394657; lrPDL > 0; lrPDL--) {
        vljramipaCkc = toCbsHRneO;
        vljramipaCkc -= LJNzHPj;
        vljramipaCkc -= hgrRWdWFtUrgK;
    }

    if (vljramipaCkc > -852603682) {
        for (int yvYQoVglmqNWJad = 1143559344; yvYQoVglmqNWJad > 0; yvYQoVglmqNWJad--) {
            FikxjzmXht -= vljramipaCkc;
        }
    }

    return -9638.281532943547;
}

void tKNXyfjAc::wrNsncoLGuwiwBZ()
{
    bool cRjYDwiDGx = false;

    if (cRjYDwiDGx == false) {
        for (int YLqplJABNhQS = 592698737; YLqplJABNhQS > 0; YLqplJABNhQS--) {
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = ! cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = ! cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
        }
    }

    if (cRjYDwiDGx == false) {
        for (int qPsZzuMEXhWdF = 251833266; qPsZzuMEXhWdF > 0; qPsZzuMEXhWdF--) {
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
            cRjYDwiDGx = cRjYDwiDGx;
        }
    }
}

tKNXyfjAc::tKNXyfjAc()
{
    this->WDQpHABRqWMqcv(string("NWNpPwpYLNvZyEElpEOUtuKNGCUEtnGlrIvcRQZWQPdvEJAwdlQEGMyrxqfgnngnxtijSsbviXBbbIiePMisAQhYQLPnEmesQdjeVqfbJjXWRhNqOaihHJwjpDGllHKNlEEvbeBafxGqOKwMOopajPYgaEYeIiqLbGNWVmBoTAPGlbbzXOOYrpamGaAJZCieVQwFIxHfgW"), 577081817, 712928.019457886);
    this->arVrynmouFiU(1332847278, true, false);
    this->NVBmwTygZbZboGoP();
    this->ENneATyaWSAZp();
    this->rebiXt(string("XgmNYOygXooNijOkNLcBaxUfgXacmJreFfLmRzEeTBtADdamTmaxEnNouauYfOsjejgK"), -194289.10945407895, string("fTeZvKwqXPAvjBuPCsYBv"), 289679.87757415033);
    this->LcxHNrjIJYSdkkc(1706207703);
    this->DZTwpZhdYG(string("HTxAT"), false, false, -452880.2115692694, string("QSniZMuDGmnNPnmtwqbLRqSwaZxPgwZWQxACbqSBYCQBYfmTJBSipJkXwf"));
    this->CHsMAahURbPu(false);
    this->dRtBcYnBVNqey(424609.688409814, string("lIdbXcXgCPedLqLwgWXyKSJuirlbMVGDskEnpFNlkGSrXxAXQnF"), 502385483, -682509.669944826, -141858.91420110612);
    this->kSTyVrT(2021601260, 2005789714, -825656395, 1771114823, 390750.9061206784);
    this->FbtNiuLE(string("IkAlszjKsQORKovXIATOMZRAbUWabrAIwRMVgvatIcttnkgqVkqeJkLkK"), -852603682, -1565432948, 1589686338);
    this->wrNsncoLGuwiwBZ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mjiEPYJVX
{
public:
    string yuvmfgXnOOLw;
    string jJuATsmYQsTYdJZP;
    int TqDyz;
    string yrzWu;
    string XGWlQL;

    mjiEPYJVX();
    double HMEiHtgNwNpMOx();
protected:
    double wCsRJufSboD;
    string JWyMtTbVkO;
    int JxtTlc;
    double povbyGcmFpQ;
    int MuZwvITmPJvJBZEq;
    int hIWsBRhaVFrV;

    string kMwzW(string lZKvcPCrboW);
    double EZFBEfmdaubE();
    void AacHGmYSIC(string keGpdesDr, int urZWjyexMVJdqi);
    bool QqzZvFo(double tCykicBied);
private:
    double nZWfsiwilIGXBPa;
    int ZnTxnLpcouDi;
    string eohrdyVeeWc;
    string lqQVmxQU;
    int ZVilCjkXvZxft;

    void gUIjWQTzBNYDzBqP(bool ukJVSAetVx, string eHiFAsz, int QcGYJZTCjgPQ, bool bWOfVRkFZWqZi);
    int OMgEdCUYVRRqSMX(int YJwfAPzHfVxHmqN);
    void IegPMLFa(double wfQjlelgwCHpJU, double qbVEklCZ, int jZRVhD, double cDrVauQCeEP);
    bool uSlVqwjfsMBzW(bool wHaeZUnv);
    void UmCNsT(double fIWIIkdw, int jansncfX);
};

double mjiEPYJVX::HMEiHtgNwNpMOx()
{
    double bIDujq = 132459.9032266081;
    string wDWtIdlnnuTZxSD = string("CSqZeUAyByqqXQrEOtUPXWGOaDHNlcYTwAKlVsYPzUXohWKQTILQxIuMPPcAqOGOJgKvgtQgtDEABCxB");
    string ftjGPwcxeoujXyYD = string("rVuXpApYMgAthbdYNmLVDfycNDBKZcabvhKUFRftKQmZdcnZWmcqbmLBPWubqnVrPiZDdnfkGUcXhRcKZtqYlZoZAcs");
    double lvJZTFJbDNUupU = 759310.9611642278;
    string PTtezzMPjzEiT = string("rserEcwNwugZzNCKeYxcyxStPDiXhrXBVnZLugMHNMmaDfWWBsxeseiAygNeqfKIUIlmQmTOkivyfcjCvLWCOGxyTicdlZXGizFKmuzwrSOnOsMpAoPhUkqbNoJWHBLkXZvUOQpSgowlloYusqyMBPCdZvOxkNaSyhLPPIh");
    bool UiUshFfP = true;
    double gxTgSsSWuCX = -445870.9637341889;
    string vZzyCShf = string("DlJiEViJEHHzFvgOMKrpsCHItyVkIzBgXTciPMglOWDbPrBSlBPGPAweqhEw");
    bool admvK = false;

    return gxTgSsSWuCX;
}

string mjiEPYJVX::kMwzW(string lZKvcPCrboW)
{
    int xmjXJANBK = -1159697021;
    string NQziWtDrIKAIrUE = string("fMwBZTvLGBOAYUExakggwopCgltmMfkzORFalxRPBUdWzilcRYXonaYbDYsggQxtAoLkeWLvKWZJWvBO");
    double PqrSMihrmyocx = -339374.7356616713;
    double HTVtdlFVSDEW = -980026.5184908389;
    string ROgWBdSAPOEfGn = string("cJaTiZaGceGuMQlJNSqUeUQUOLOMhvWxNFsCcdKehlzDfxTvVUnNnG");
    double KnTSLS = -411246.04808648495;
    int ibKHUPMSmbHjkqH = -1511481232;
    string SvmmvfVQkjNg = string("VVkICbAoNzNXcIxWjurpqeJlHEfqrBJvymbzLnGaAAoBaHZFbedvBTNVlUmpcKzwBDylieWMghTstkWqpPymNxPoTXWSldCCIOstNxweuWOPcuEGMQzVOSXwnaPTSVwbbtnQKZjwKesXwYbCvulIgokfERnUmVRAEHfKKeXxLHKlZAIzFQoKvjVueiR");

    for (int fNldIDSgJ = 129464517; fNldIDSgJ > 0; fNldIDSgJ--) {
        ROgWBdSAPOEfGn = lZKvcPCrboW;
        xmjXJANBK = xmjXJANBK;
    }

    for (int LdmVZHffZJZM = 1963036611; LdmVZHffZJZM > 0; LdmVZHffZJZM--) {
        HTVtdlFVSDEW /= KnTSLS;
        ROgWBdSAPOEfGn += ROgWBdSAPOEfGn;
    }

    for (int iEREWUPyY = 686080348; iEREWUPyY > 0; iEREWUPyY--) {
        NQziWtDrIKAIrUE = SvmmvfVQkjNg;
        NQziWtDrIKAIrUE += SvmmvfVQkjNg;
        lZKvcPCrboW += NQziWtDrIKAIrUE;
    }

    for (int MOFwfjF = 1200635306; MOFwfjF > 0; MOFwfjF--) {
        ibKHUPMSmbHjkqH /= xmjXJANBK;
        SvmmvfVQkjNg = ROgWBdSAPOEfGn;
        NQziWtDrIKAIrUE = NQziWtDrIKAIrUE;
        ROgWBdSAPOEfGn = NQziWtDrIKAIrUE;
    }

    if (lZKvcPCrboW == string("fMwBZTvLGBOAYUExakggwopCgltmMfkzORFalxRPBUdWzilcRYXonaYbDYsggQxtAoLkeWLvKWZJWvBO")) {
        for (int nVCtSkYeYtrtCOd = 134498153; nVCtSkYeYtrtCOd > 0; nVCtSkYeYtrtCOd--) {
            continue;
        }
    }

    if (ROgWBdSAPOEfGn != string("sUFdmsuKUWzOClQVsYcPhRLbcVBpiYCkJuekRnmwSciIghnsCJhZHVkiyHJChskbNUjeUeMkBfzUEAfHogIqNDnhGkmpCGlFIgLhiGrLWWuVpgHnkCBzBbKlrSRSegYHCFPoqcqJuRMRHvbgrKKWfdVLeBAGFcsKoRTyUrVdncMoiVXJOVvPSQBjwDDQ")) {
        for (int eiBxbuouDbZ = 53996571; eiBxbuouDbZ > 0; eiBxbuouDbZ--) {
            continue;
        }
    }

    return SvmmvfVQkjNg;
}

double mjiEPYJVX::EZFBEfmdaubE()
{
    double HrHZwEUvaLNnxPn = -825351.4993775344;
    int QZvzCW = 679900923;
    bool vifWYBO = false;
    bool vZQonMv = true;
    bool fePiQDiUQhtEDkQ = false;
    bool rQnxeORqy = true;
    string hSIoXUhdYUfiN = string("yrreDWyyxbnzsuw");
    bool HDQckgcJTV = true;
    int oAFZxhhqfyV = -1175138915;
    bool wKBFaYBjS = true;

    for (int RxjoqCnsGrhntbV = 131493873; RxjoqCnsGrhntbV > 0; RxjoqCnsGrhntbV--) {
        HrHZwEUvaLNnxPn += HrHZwEUvaLNnxPn;
        HDQckgcJTV = wKBFaYBjS;
        vZQonMv = ! rQnxeORqy;
    }

    for (int cGkKjdJGdoHZ = 1575420180; cGkKjdJGdoHZ > 0; cGkKjdJGdoHZ--) {
        HDQckgcJTV = ! vifWYBO;
    }

    if (QZvzCW <= 679900923) {
        for (int GMeywsXDv = 1600000030; GMeywsXDv > 0; GMeywsXDv--) {
            HrHZwEUvaLNnxPn = HrHZwEUvaLNnxPn;
            rQnxeORqy = fePiQDiUQhtEDkQ;
            rQnxeORqy = wKBFaYBjS;
        }
    }

    for (int KrMjJdL = 1727469767; KrMjJdL > 0; KrMjJdL--) {
        vZQonMv = wKBFaYBjS;
        HDQckgcJTV = ! vZQonMv;
    }

    return HrHZwEUvaLNnxPn;
}

void mjiEPYJVX::AacHGmYSIC(string keGpdesDr, int urZWjyexMVJdqi)
{
    int uhrakowIJBkUdw = 2016411719;
    bool MJtymxDvmoyH = true;
    int UDFLi = 860135812;
    string VRKhsjcbuAydq = string("VnQptrHVogUXASZCKSdZybnHlwIWBvnoYjQoYKDdyouFEyDpoxQFAjnVQRrfhTKGYgatPVqOGQshrxsKyLyaitvTjgWUjLvnoNoMqfwvgcFuBjItTBSmyMLnixTD");
    double plTGUeNeOL = -478319.7634209302;
    bool BTTsOD = true;
    double WeLCcEbUNh = 596830.8380828268;
    bool AXWWDC = false;

    for (int lElofDrtOXRy = 435287275; lElofDrtOXRy > 0; lElofDrtOXRy--) {
        uhrakowIJBkUdw -= uhrakowIJBkUdw;
    }

    for (int pGUUpNxl = 1847992091; pGUUpNxl > 0; pGUUpNxl--) {
        continue;
    }

    if (uhrakowIJBkUdw != 860135812) {
        for (int KyGQM = 816468418; KyGQM > 0; KyGQM--) {
            uhrakowIJBkUdw /= urZWjyexMVJdqi;
        }
    }
}

bool mjiEPYJVX::QqzZvFo(double tCykicBied)
{
    int PpNKdzXjltS = -1065942920;
    double ABwGcMS = 619793.2495374432;
    string fcVSVk = string("FtySsdpFOvhtttuHFAxXwzuiuBzxlnflvHRHIHBoaElWOJopbypJzssJwgiiRAJeQySdrpxzldhmOnEJxHkAOyRaEocozCVwFUkPKsWEZqSkCDuZsvGgCXgwJOeIMFkbChjxVzHNAwgMoDpOt");

    if (ABwGcMS < -856157.1363556097) {
        for (int VZyyLEyZowKIL = 781389471; VZyyLEyZowKIL > 0; VZyyLEyZowKIL--) {
            tCykicBied *= tCykicBied;
        }
    }

    return false;
}

void mjiEPYJVX::gUIjWQTzBNYDzBqP(bool ukJVSAetVx, string eHiFAsz, int QcGYJZTCjgPQ, bool bWOfVRkFZWqZi)
{
    double NWSgpWSMAh = 851506.9044395798;
    int mhRshnmakdE = -1696637396;
    double eaAay = 743931.3822331345;
    bool dqnxAltMFjy = true;
    int GDFuYNqfOnXpVR = 1437806482;
    double cwvEOByl = 799923.1082133673;
    string RCXaT = string("GOusTeNzXUyXGkQSjxPdzAyoYuQSctaRIoqXlhJdicCgNCUiMiNIAwTvGYvMaNLhhbhoDufPHrlVzFNqkYbCFKYAdAvLtNxrzUBDSLnrJRnZSwjXSLoBseIQwRAuxCCycAENdnSchfAGvHvOmfSOnhYiMsfVKeGGcbCsQETLeyahpbcOWvfyDdilXrCSlvVrJWtUpITqWoIpBkMwJAIacWnckzGhdGJjGBJqlYcfSccZnKZDwsMqeZDAeDMPDa");
    bool EVWCyrs = true;
}

int mjiEPYJVX::OMgEdCUYVRRqSMX(int YJwfAPzHfVxHmqN)
{
    int eSgODMlCyzBvyeou = 64457520;
    bool EwZlskwRIQDDCK = false;
    int mJyJONS = -356841903;
    double rIqrsUBFQZEP = 978489.4546625345;
    double WhFVCm = -1034847.9883840182;
    double GaGZTdGfgWvKw = -532177.6239926899;

    for (int ArbLdMiWeSVzcMZm = 597789113; ArbLdMiWeSVzcMZm > 0; ArbLdMiWeSVzcMZm--) {
        mJyJONS += mJyJONS;
        YJwfAPzHfVxHmqN *= mJyJONS;
        GaGZTdGfgWvKw += rIqrsUBFQZEP;
    }

    for (int iYhCUAl = 954171861; iYhCUAl > 0; iYhCUAl--) {
        mJyJONS -= YJwfAPzHfVxHmqN;
        WhFVCm -= rIqrsUBFQZEP;
    }

    if (YJwfAPzHfVxHmqN > -356841903) {
        for (int CqcPnnIZXA = 108431352; CqcPnnIZXA > 0; CqcPnnIZXA--) {
            rIqrsUBFQZEP *= WhFVCm;
            rIqrsUBFQZEP += GaGZTdGfgWvKw;
        }
    }

    for (int gXWjqBxXDlQwbdW = 1413004273; gXWjqBxXDlQwbdW > 0; gXWjqBxXDlQwbdW--) {
        GaGZTdGfgWvKw += GaGZTdGfgWvKw;
        GaGZTdGfgWvKw -= rIqrsUBFQZEP;
        EwZlskwRIQDDCK = EwZlskwRIQDDCK;
    }

    return mJyJONS;
}

void mjiEPYJVX::IegPMLFa(double wfQjlelgwCHpJU, double qbVEklCZ, int jZRVhD, double cDrVauQCeEP)
{
    int mVZUmdKKWjPEm = 273227813;
    double tjOKBmdrnhYM = -111461.40904972909;
    int EhVkdfRRXOYMbgtH = 1033506312;
    double ZjkxxVrmylWwxP = 52487.73409246423;
    double RVszoa = 44621.75847101907;
    double rDolstvjKhLbrDR = 725683.4910098753;
    double BeotwjeNnJzS = -820534.8922984061;

    if (BeotwjeNnJzS > 52487.73409246423) {
        for (int VRoYhELhpzQjFlZ = 611891770; VRoYhELhpzQjFlZ > 0; VRoYhELhpzQjFlZ--) {
            BeotwjeNnJzS /= rDolstvjKhLbrDR;
            qbVEklCZ -= cDrVauQCeEP;
            rDolstvjKhLbrDR /= rDolstvjKhLbrDR;
            qbVEklCZ = wfQjlelgwCHpJU;
            BeotwjeNnJzS *= qbVEklCZ;
        }
    }

    if (BeotwjeNnJzS < -111461.40904972909) {
        for (int HApmfremsAx = 721545619; HApmfremsAx > 0; HApmfremsAx--) {
            cDrVauQCeEP = rDolstvjKhLbrDR;
            qbVEklCZ += rDolstvjKhLbrDR;
            rDolstvjKhLbrDR /= BeotwjeNnJzS;
            ZjkxxVrmylWwxP -= wfQjlelgwCHpJU;
        }
    }

    for (int mKZjMLEyZknQyri = 1685235009; mKZjMLEyZknQyri > 0; mKZjMLEyZknQyri--) {
        continue;
    }
}

bool mjiEPYJVX::uSlVqwjfsMBzW(bool wHaeZUnv)
{
    bool oXfVToMgdNjHqKW = true;
    double kgOVom = 701251.712515474;
    double JDkPxYvYFqTZV = -303641.32973639097;

    return oXfVToMgdNjHqKW;
}

void mjiEPYJVX::UmCNsT(double fIWIIkdw, int jansncfX)
{
    string xGdIrwqRUpRSa = string("adhAZRajbcqFBYSFtSUQmYfsENNFWhrDXGwVpBWJWKsyESqdOhqKeFbEfeYreGltHnBKHVObXwNQxvHgGioOYOmKTTsvMMOyKPBDtOZRGECmqlQELWBZDNwMmldsaStYFwWsvLdvwRdeGbLcybRFPjPMPIFirpcOzQNxPCYwMkeFfWCFzCnAQkIwofzZXckIIMVjedQ");
    string fjptlnztupzOStwe = string("CnVXZzbEigKtrcoEHEPzdiAziuPFXveMoAhggzItyOsQWnMoWZuAcHVFWuLYzLCKpeCjenQzzQOnPDQYsJdhMMeApLeMIPQmJVdExrvfhoURuKXfqAtuBBpBVhknavIfkHWnOFFXCS");
    int EINllxfE = 1845389675;
    double ryLwQjcM = 36503.19773946895;
    bool EeGcdPlzWzCjJ = true;

    for (int EKirSSyaTtjqpR = 9256738; EKirSSyaTtjqpR > 0; EKirSSyaTtjqpR--) {
        ryLwQjcM += fIWIIkdw;
        xGdIrwqRUpRSa += fjptlnztupzOStwe;
    }

    for (int NqJAuTcQBd = 139639589; NqJAuTcQBd > 0; NqJAuTcQBd--) {
        fIWIIkdw += ryLwQjcM;
    }

    for (int NbfFNycXzvAfh = 394890591; NbfFNycXzvAfh > 0; NbfFNycXzvAfh--) {
        jansncfX /= jansncfX;
        fIWIIkdw = fIWIIkdw;
        xGdIrwqRUpRSa += xGdIrwqRUpRSa;
    }
}

mjiEPYJVX::mjiEPYJVX()
{
    this->HMEiHtgNwNpMOx();
    this->kMwzW(string("sUFdmsuKUWzOClQVsYcPhRLbcVBpiYCkJuekRnmwSciIghnsCJhZHVkiyHJChskbNUjeUeMkBfzUEAfHogIqNDnhGkmpCGlFIgLhiGrLWWuVpgHnkCBzBbKlrSRSegYHCFPoqcqJuRMRHvbgrKKWfdVLeBAGFcsKoRTyUrVdncMoiVXJOVvPSQBjwDDQ"));
    this->EZFBEfmdaubE();
    this->AacHGmYSIC(string("AoUEVQxUaCAEdHaLDFWNzZyUqnQteppNXugYrpaYZcheljhRXVUSMxTejhyfBDFmF"), 2096473245);
    this->QqzZvFo(-856157.1363556097);
    this->gUIjWQTzBNYDzBqP(true, string("It"), 2038091343, false);
    this->OMgEdCUYVRRqSMX(-1462402252);
    this->IegPMLFa(1045129.621735288, 329142.45930548006, -1887083372, 777324.1281399885);
    this->uSlVqwjfsMBzW(false);
    this->UmCNsT(-501231.75862781506, -774167644);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XtxaAWpKyQzU
{
public:
    double sxzfKYBnx;

    XtxaAWpKyQzU();
protected:
    string VaMKSIqjfdq;
    int daGPfymeHY;
    double qakAsa;
    bool fOewhGpjpdVjAZl;
    bool eQHSbpMRzWWbSxE;

    double QHppSHqDTXkrqq(string NmtfIffPRWm, string XyFyDgsgpGmhRYNB);
    void NtFmoR(double KefAMdmSNCfTioth, int FQkWdNCQCqJK, string qNjxu);
    int wsuPh(int qvPscFqfg, bool AOZLnbMgc, bool EXixa);
private:
    bool MxVin;
    bool FbevErXmtNpCv;
    double RCNiNK;
    bool gDxeMNON;
    string dHwWkahRn;

    double GysBxB(int VAujBSf);
    string RMynfursrXXqUbkm(bool mWpYLBuW);
};

double XtxaAWpKyQzU::QHppSHqDTXkrqq(string NmtfIffPRWm, string XyFyDgsgpGmhRYNB)
{
    double fdsNh = -875747.4612157191;
    string tLWYiaUjeqIeVov = string("wcrdGcWmKyThJyXeZGdseCWgsXdPpfghBrBcaRJXJxyVfKpGpIzdMeCWXJffbqqlUAOMaZpqdsfqbzJHwtkofpPVX");
    string lEmLbX = string("eVlcnEDeYTsQEuiM");
    int GtnXng = -2034672862;
    string DLJRdwgi = string("mkZrPBFSEvBuqjFdrubxmsYhjeheWHeitSBBgYveIZpvEPupeSoRzwrxCdJZQTKRaMrheuIMeyAGNjcavUUtEruCLClkMfDTJXCKabdunCwAmJEgDyBFvhwrjsNjFrQCIjNPSwMTBHdvQPAlhtxwytvToaVeuDEWJadNxXYNegsSDKYVIqVIjOxuSKOnANxDWtXodMKbdlforDXtMajBrplicaEdaTkZgMInzXPZQovQpq");
    string NXtpYlE = string("YLcJYGfBBqksqChFJIKfKHSLRISEFYVuEjSFmrjTWbIrRJnGkSJuOlNqOovec");
    bool ZWIQocsNZdi = false;
    int MmCAWrT = -1609187953;
    string RcjEe = string("SKLsYcBDGopiJddQvCBMkCuyixeNWLxEtBCmLsECRCMsMlOfFmPkqqiuvQhlLVErnsjIuipdHFaMjwUQUQvxmgWlpxG");
    string fKsumQDXFxy = string("IsZrzkddgSkfQimkljAwciFgEAvvazpCzwzSeGUVccyvaMUFovYICP");

    if (lEmLbX >= string("eVlcnEDeYTsQEuiM")) {
        for (int rSOqCtu = 2070005106; rSOqCtu > 0; rSOqCtu--) {
            DLJRdwgi = lEmLbX;
            NXtpYlE = XyFyDgsgpGmhRYNB;
            RcjEe += DLJRdwgi;
            RcjEe += tLWYiaUjeqIeVov;
        }
    }

    if (RcjEe < string("eVlcnEDeYTsQEuiM")) {
        for (int ZRYxY = 1018213680; ZRYxY > 0; ZRYxY--) {
            continue;
        }
    }

    if (RcjEe == string("IsZrzkddgSkfQimkljAwciFgEAvvazpCzwzSeGUVccyvaMUFovYICP")) {
        for (int UkaNmn = 71497688; UkaNmn > 0; UkaNmn--) {
            NmtfIffPRWm += RcjEe;
        }
    }

    if (XyFyDgsgpGmhRYNB >= string("wcrdGcWmKyThJyXeZGdseCWgsXdPpfghBrBcaRJXJxyVfKpGpIzdMeCWXJffbqqlUAOMaZpqdsfqbzJHwtkofpPVX")) {
        for (int ltTrCCA = 1003629555; ltTrCCA > 0; ltTrCCA--) {
            RcjEe = lEmLbX;
            XyFyDgsgpGmhRYNB = fKsumQDXFxy;
            DLJRdwgi += XyFyDgsgpGmhRYNB;
        }
    }

    for (int KQmgBnathshk = 524523167; KQmgBnathshk > 0; KQmgBnathshk--) {
        NXtpYlE = tLWYiaUjeqIeVov;
        lEmLbX += NXtpYlE;
        NmtfIffPRWm += lEmLbX;
        fKsumQDXFxy = NXtpYlE;
    }

    for (int hULwlkA = 83927446; hULwlkA > 0; hULwlkA--) {
        RcjEe += RcjEe;
        NmtfIffPRWm = tLWYiaUjeqIeVov;
        XyFyDgsgpGmhRYNB += lEmLbX;
        DLJRdwgi = RcjEe;
    }

    for (int yXEwbnYG = 1825676810; yXEwbnYG > 0; yXEwbnYG--) {
        DLJRdwgi += DLJRdwgi;
        lEmLbX = XyFyDgsgpGmhRYNB;
        XyFyDgsgpGmhRYNB += fKsumQDXFxy;
    }

    return fdsNh;
}

void XtxaAWpKyQzU::NtFmoR(double KefAMdmSNCfTioth, int FQkWdNCQCqJK, string qNjxu)
{
    double oyEzdTw = 972054.9477883916;
    bool krxJvIOGrCCR = true;
    bool vhUfywBfiOQj = false;
    bool LqYAHhcYHryans = false;
    bool srEGWDKkaxYgKg = true;
    int NBbcUKnucvZ = 868596487;
    double GkYomIgQMhEm = 293843.326502099;
    bool dCRJKnjzYmDyme = false;
    string YSzkQj = string("iXpEPFQfUpLJelNvBqqrTiBdxiUcjFjjdKbbictbemlSJyFqoPMBEVFjBzodXqhmgEHehfYbiHZheJMDImzhzVuadUEdaQAkcOeFEGnmVAuSbzUGdnfSkfXnuXFQPRisNMkGNXckHYQAoAxEhgRBOHKLaefXVWZQzhCrMVifGESLpKbNXNibYoByOnZbrUPITgSmeAwYCZyoMJPDrJGRfBIClBEfWfZE");

    for (int oWvfrCTgEZG = 1814456066; oWvfrCTgEZG > 0; oWvfrCTgEZG--) {
        GkYomIgQMhEm -= GkYomIgQMhEm;
        LqYAHhcYHryans = vhUfywBfiOQj;
        GkYomIgQMhEm += oyEzdTw;
    }

    for (int QvINp = 2098059000; QvINp > 0; QvINp--) {
        dCRJKnjzYmDyme = ! vhUfywBfiOQj;
        dCRJKnjzYmDyme = LqYAHhcYHryans;
    }

    for (int GqUocaajcDlt = 339944932; GqUocaajcDlt > 0; GqUocaajcDlt--) {
        GkYomIgQMhEm += GkYomIgQMhEm;
        GkYomIgQMhEm += KefAMdmSNCfTioth;
        NBbcUKnucvZ += FQkWdNCQCqJK;
    }

    for (int szTpnMmFJUSwOAc = 1600621393; szTpnMmFJUSwOAc > 0; szTpnMmFJUSwOAc--) {
        srEGWDKkaxYgKg = LqYAHhcYHryans;
        krxJvIOGrCCR = ! LqYAHhcYHryans;
    }

    if (krxJvIOGrCCR != false) {
        for (int FKLSZY = 2015018510; FKLSZY > 0; FKLSZY--) {
            continue;
        }
    }

    if (krxJvIOGrCCR != false) {
        for (int UQTivgaKGOmHs = 1660577364; UQTivgaKGOmHs > 0; UQTivgaKGOmHs--) {
            continue;
        }
    }
}

int XtxaAWpKyQzU::wsuPh(int qvPscFqfg, bool AOZLnbMgc, bool EXixa)
{
    double KLerQhQto = 956535.4394731683;
    int NHfrmcSPCKGxc = 990505559;

    for (int MclwqWtc = 1347333615; MclwqWtc > 0; MclwqWtc--) {
        NHfrmcSPCKGxc /= qvPscFqfg;
        AOZLnbMgc = ! AOZLnbMgc;
    }

    if (qvPscFqfg > 1389571203) {
        for (int XBuloVYoClraMnp = 2056943686; XBuloVYoClraMnp > 0; XBuloVYoClraMnp--) {
            AOZLnbMgc = ! AOZLnbMgc;
            NHfrmcSPCKGxc -= NHfrmcSPCKGxc;
            NHfrmcSPCKGxc *= NHfrmcSPCKGxc;
        }
    }

    for (int TNkHTbab = 2107925832; TNkHTbab > 0; TNkHTbab--) {
        qvPscFqfg = qvPscFqfg;
    }

    for (int WYZaSTalO = 1861818421; WYZaSTalO > 0; WYZaSTalO--) {
        continue;
    }

    if (EXixa != true) {
        for (int oBpZHjnMQjVdYVa = 435722236; oBpZHjnMQjVdYVa > 0; oBpZHjnMQjVdYVa--) {
            qvPscFqfg += NHfrmcSPCKGxc;
            AOZLnbMgc = ! EXixa;
        }
    }

    return NHfrmcSPCKGxc;
}

double XtxaAWpKyQzU::GysBxB(int VAujBSf)
{
    string MMEvbevSjPjDu = string("CeDJeXnDNFIrgSzwBVvNtIpXWaokhNIfZvKhyTkneHjvxWQULmIVNKMSbHdGVKDUscidMZrQdASmevBqyVLMHsLAbkZrFSmnsnLCvgjEXGfXwGCrUfqrLBucrnfstpMETiRDuqeWroqFdCeFIJStblbsKFJDSDcjEMGlFoPovweGAwEpNepZPXaxLZhjNSGoDbdlcdOCBzsjQVDPyqXAYZNWQd");
    double HHJVh = -849203.7364140362;
    bool hmlnkdTIAIaB = true;
    double atoHgKO = 850994.3524576906;
    string XavHFLeL = string("CHVJUnwDgKzxmKULpeSheAXiTYCVgvMZyOkVXvdYGeYQqoVmmSBvvBDwhgdZAkWFgpydnkNdslZCpeHwetIFyKwuQxMNOAuWeiApoqEMydvAVQixHSMuvZHcJCsAGzpULhlELPKHAJVejaJlbDRzyQjHqyUdfvgREABhtnHpXqxmZbcmsxPOexaKKtRxqvZuYgZlnKVarQxXQjLCtMGivOTEyaefTxdt");
    int cGDOMvnGL = 2122704292;

    for (int HLRcXVhCJrK = 1084982347; HLRcXVhCJrK > 0; HLRcXVhCJrK--) {
        continue;
    }

    return atoHgKO;
}

string XtxaAWpKyQzU::RMynfursrXXqUbkm(bool mWpYLBuW)
{
    int cwaNoAOBu = -785228757;
    int CJwjkEUIeyIl = 1655873751;
    string siDIRa = string("QWIKcWjnNxEQjnNEOekzWTZWlxYJXynfjDeRquwWktCqrdOpRRDRoxNwiGUKoVxhCZLvZDHsmfVhfpOVjbBgEqXtOXlklPVMKHPhUHVjZEDdXxfFIiChGjwxx");
    string TESmlMnpMeLE = string("ztpAfqxpzQtKRqRNUcHTUGISdBXvLYqAgAxbatZCCclkjwxvKeOFLAnsZhAFVZYdPLfRQrAbrwYxrWeiudLGBLdjdliWUbvsMDqxoMvUIuDwLcvHaikOygwspOSheIoqEvzIKDXJpNTtlTQgpJdAZpieuPAKeanGbdWZyxAbnueQLFYISabLmCyQIKuNAoLyswnlFdgecDhLZCvnVMsijNrwmWpLIDcInlZGgPJHChWpuMEIyQuylrw");

    for (int kbQwts = 770000986; kbQwts > 0; kbQwts--) {
        continue;
    }

    for (int MYwOgLVATbjOPhW = 187626302; MYwOgLVATbjOPhW > 0; MYwOgLVATbjOPhW--) {
        continue;
    }

    for (int ZXRWKG = 2117678213; ZXRWKG > 0; ZXRWKG--) {
        continue;
    }

    return TESmlMnpMeLE;
}

XtxaAWpKyQzU::XtxaAWpKyQzU()
{
    this->QHppSHqDTXkrqq(string("SGGpFAyKQFNDHmeXOEPfFRAQXthUidHzwEdSGbckTUSDIAfoFdVvFCiPeSoNfHBOnCNkrtCHkJkYZwisLvIjitiNhXjrbRzSzPeotEztmudFDKaDmYiyuNyNVBewrHblasxUScVjM"), string("XfeMxIGevWxBKWKaDALCNnZcgbkVlQOJfRRWGzrZFLnsPBiyAhejvGDMMNYKfLJLwOpvqJvaMAFAjPDwFOywMbBVtVaagOXwbVsMJBHonoDGfDsFCGcufmFSKQqXaMdKoSKnzjkUhxWBNgjQilJGFCDcmKlWSIcTtqfG"));
    this->NtFmoR(-479006.7108683882, -419079713, string("VaJmzsWJbTiFgsvcXopoZnDbsXRfQzzDwwqicfFDrXHZcdImeLKUNKwbHpxAErflEqiJqMPJcDlmOxlFaZobBgssnNKwFKrcoWMGJXYvantzVvHFBEViGTvOfesIvgExdyIADqJruFxiOJFMoLSwEJaVZnpYoWrPeVdJTmZagkmAfPzCOjMmzIEaffGETuaLUlUrNRqPxGkOicjPGEeRRNLIvWTDTIZiezZBQGMmoKO"));
    this->wsuPh(1389571203, true, false);
    this->GysBxB(1753065849);
    this->RMynfursrXXqUbkm(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VkrEM
{
public:
    int ZQKZPTvUl;
    string wsLbVZyK;
    bool gpHcOIRGAluDY;
    bool HadMTkKatZsswpAT;
    string SnGiayh;

    VkrEM();
    void rIZqdv(string ApDSuQRzacPQZq, int NxaxgdV, double CISNMi);
    double HbtRQeVTueeR(string KknsbsdykL, int gWmypvWHlnXisx, bool dsTKlwXcr, int WpLihdGLGBKkzLVb, string JZESOYFkSeawYhr);
    void EfnIf(bool LXOUdo, bool zkQpUaJbOXqVy, int ZoONPZuWPKwiAa);
    string HOlJQclUCTgnu(bool DbQNx, int aWbetVmKzL, int vvkGPpvyQJgSaJ, int vlCJIixTyfAMYP);
protected:
    string WYWNiLb;
    double VhGqrnssKhi;
    int UFMxXwLy;
    int wgiggpVqHtIk;
    string MwPTAJOltLBDSWVA;

    bool VVbzHwdxVRDckE();
private:
    double JGmrYLMSMYqJx;
    int QHyJVKVoRxQUHb;
    string VRloFkuVIvGAg;
    double hiBrvKTMFX;
    bool rEzZGmUXAVwucA;

    void RXZjbLtSxfDuoFh(bool gpYHFDAbhv);
    int opWgdPbbAafYu(bool elTTd, string wzSQQqRxKb);
    int omTWqOh(string TeNLQwrBJYd);
};

void VkrEM::rIZqdv(string ApDSuQRzacPQZq, int NxaxgdV, double CISNMi)
{
    double RCRsBxMiFELk = -64611.72850802614;
    bool LOQpJgDxUkCoRV = true;
    bool kpjVrzTxdWVnYHu = true;
    string fCSnYUBNSqPv = string("DhUAGRvnXWehWyiOzQhBUzSxOLHnNwSraTRWHHMBBmYLcOrwTOcCpZhglyVzmDuoHCNTEggJVodkDYYefacJHNjkxScmwitaCvrqPubdIBazymGa");
    string yrxsifSgHVNhyMch = string("mTIuJkIqtxstLNRvOXEXeatEpyiYExToFwJfYAhBRwtRSiuiFXZycnhFYOoXqHgmXhnSoBGpiNSEXSQjEASwIBJoFPplMUlVhvgZzryOactFGSdtQgXIpacOmBOybentTrXVfwPwqwNKtLRfoAGajtnRFnyeNpdypYZtafugReuoSPJSaDzsLGXpeYbbmptwEz");
    double sEoKBxqSnNnL = -251512.72132474344;
    double WgrCZgZrYoJ = 48037.40373078296;
    double QYUCzYv = 101336.26120796656;
    string YKWcXSrrD = string("thhWSpjGJEwpsIQgujNXrCqtXAhRbRjVmKUngpJyNmpdspozgcjMxrwsBSoIhFwvXgeELiAjytWeyDOxNdRymldCkkENhAnxGtVeccZMIDtpZIuTdVNVyjjwnpfceNtQIMwfcXDHJUUjNhJusIpQOivZIyfzhbHUJCTzjgEqZrgQpsuQNQQqDsr");
    bool haPzIdXuchClhjs = true;

    for (int LtMmKKbCx = 1229031131; LtMmKKbCx > 0; LtMmKKbCx--) {
        RCRsBxMiFELk += CISNMi;
        LOQpJgDxUkCoRV = ! kpjVrzTxdWVnYHu;
        haPzIdXuchClhjs = LOQpJgDxUkCoRV;
        sEoKBxqSnNnL = RCRsBxMiFELk;
    }
}

double VkrEM::HbtRQeVTueeR(string KknsbsdykL, int gWmypvWHlnXisx, bool dsTKlwXcr, int WpLihdGLGBKkzLVb, string JZESOYFkSeawYhr)
{
    string xGZrbbiGKLOg = string("rKRlAFweRMbhwQLMtCFkBeQrnrIYZwmBxmkrvgMLCnoEBcqyQZpzOClFxfhubfhOlzoIFoaYBcEhVSgsyfxQghxDwaTGmjcpRkwvixBfVMTDncLZKroUlKsEMch");
    int STnHtmhxybr = -505321747;
    int MZyTCRKDVVBp = -503141439;
    double FKmjnbnsOfOhxnt = 988008.0740036288;
    string kQifSboHCrXP = string("ZwCLDyYrwZMhKof");

    return FKmjnbnsOfOhxnt;
}

void VkrEM::EfnIf(bool LXOUdo, bool zkQpUaJbOXqVy, int ZoONPZuWPKwiAa)
{
    string NYxQslrKoyfEgVR = string("flDzqKpTSss");
    bool BaxNLmyz = true;
    int gXBTfiRG = 1452116769;
    double iKQNIRtSjNC = 764668.4998638944;
    string nkpSlLx = string("FZUBBKtstesEUghjnHYolGKkCPkUKhvnEZGTeLBPdekmrQGlnhtYEsopKoNLiQBWeqcWXBwAkMncFtvWsGlSMEJMPSRpHzcErPSGXUrhpTRuoBhKaATErSuBLDDKpCocIRXsEXnyuclSWzBmsKXbkNgZdBtpcTaOOsYFAFmsGaxJTCUeRUmtPHOBtSXagZMSlsvceTIXbIbeqqRYdLbYucEjjIZkQyEMexPpRRGanIYzF");

    for (int NgesHWsYlj = 161795918; NgesHWsYlj > 0; NgesHWsYlj--) {
        BaxNLmyz = BaxNLmyz;
        NYxQslrKoyfEgVR = nkpSlLx;
    }

    if (iKQNIRtSjNC == 764668.4998638944) {
        for (int QxeBBgKFCEnUsaWb = 344371437; QxeBBgKFCEnUsaWb > 0; QxeBBgKFCEnUsaWb--) {
            gXBTfiRG += gXBTfiRG;
        }
    }

    if (ZoONPZuWPKwiAa != -2017772035) {
        for (int lWZxyO = 538716186; lWZxyO > 0; lWZxyO--) {
            LXOUdo = LXOUdo;
            gXBTfiRG -= ZoONPZuWPKwiAa;
            zkQpUaJbOXqVy = BaxNLmyz;
            zkQpUaJbOXqVy = zkQpUaJbOXqVy;
        }
    }

    if (iKQNIRtSjNC != 764668.4998638944) {
        for (int XbxNjaxp = 1287531807; XbxNjaxp > 0; XbxNjaxp--) {
            BaxNLmyz = BaxNLmyz;
            LXOUdo = ! BaxNLmyz;
        }
    }

    if (zkQpUaJbOXqVy != true) {
        for (int VqwgyLIOGiebXGpq = 838707624; VqwgyLIOGiebXGpq > 0; VqwgyLIOGiebXGpq--) {
            BaxNLmyz = BaxNLmyz;
            iKQNIRtSjNC -= iKQNIRtSjNC;
            LXOUdo = LXOUdo;
        }
    }
}

string VkrEM::HOlJQclUCTgnu(bool DbQNx, int aWbetVmKzL, int vvkGPpvyQJgSaJ, int vlCJIixTyfAMYP)
{
    string anWoXNEt = string("peZnCnMMQWKsYkKkmrydKMieKqNUopnbbBgJFKJFCuQNinsIiCdVNJSrlRINSlErJzVASKDtFSvEHDZpRybGojOWxYcXMiuIROAjyrrFdBWDiEzLvsSOdfZftzicRdbciXmFAWvcoTqvJbAlpygUiiaJUgUVBdmlcYzqnXXfRgDzYnvExUiEZiXpGwYWtimkyFUuBSsvdeauwDPjntVfrguXtTmpgIouEOOOlJerlfkPuQkcsumRRWbgPFLaJMI");
    double OHUYdCOwPYtEfa = 161571.21857672234;
    double EhsLRkZUJTgUwYjO = -598687.3253655809;
    double qFJUEgimObGAy = -1021818.9177560145;
    string ZwVygFrvnOtUtd = string("fgLAHWqkQiHQLkPjOxIQIsKBtNjYJpwHfvJcLmdWDZkxnqanFtAqgEaxygCkGKgPlosrXNUZhmafDcNmLXjjmLzjTVEkEQUFTwjwztNpOfYCsRtcEqGdzaRdpKwwTAUrOqfQcTIepIDhPsukdregDQlMrxeLlqGpRXYqqagejuExzMTGiQscjEF");

    for (int XwFXJWkBWAcZdW = 1763131907; XwFXJWkBWAcZdW > 0; XwFXJWkBWAcZdW--) {
        EhsLRkZUJTgUwYjO = qFJUEgimObGAy;
    }

    for (int cpoCibI = 1756324632; cpoCibI > 0; cpoCibI--) {
        vvkGPpvyQJgSaJ /= vvkGPpvyQJgSaJ;
        ZwVygFrvnOtUtd = ZwVygFrvnOtUtd;
    }

    for (int qUQUbWyt = 1254151732; qUQUbWyt > 0; qUQUbWyt--) {
        DbQNx = DbQNx;
        vvkGPpvyQJgSaJ = aWbetVmKzL;
    }

    return ZwVygFrvnOtUtd;
}

bool VkrEM::VVbzHwdxVRDckE()
{
    bool pIGSx = true;
    double HGZlSkIcYkzF = -497780.2517534939;
    int btbquwSRT = 427837622;
    double evnKY = -295084.32641706;
    int YplkKJiUliVqnR = 950308367;

    for (int cVaNfPKhCRdTxnfs = 2022322217; cVaNfPKhCRdTxnfs > 0; cVaNfPKhCRdTxnfs--) {
        HGZlSkIcYkzF -= HGZlSkIcYkzF;
    }

    for (int veWhpa = 1473871240; veWhpa > 0; veWhpa--) {
        YplkKJiUliVqnR *= btbquwSRT;
        HGZlSkIcYkzF /= HGZlSkIcYkzF;
        btbquwSRT += btbquwSRT;
    }

    for (int TVuoyxhAdqHAen = 1396436927; TVuoyxhAdqHAen > 0; TVuoyxhAdqHAen--) {
        evnKY /= evnKY;
        evnKY /= HGZlSkIcYkzF;
        HGZlSkIcYkzF += evnKY;
        pIGSx = pIGSx;
        evnKY += evnKY;
        HGZlSkIcYkzF += HGZlSkIcYkzF;
    }

    if (HGZlSkIcYkzF <= -295084.32641706) {
        for (int uUKBbgxkTYbGlaEl = 1704163163; uUKBbgxkTYbGlaEl > 0; uUKBbgxkTYbGlaEl--) {
            evnKY *= evnKY;
        }
    }

    return pIGSx;
}

void VkrEM::RXZjbLtSxfDuoFh(bool gpYHFDAbhv)
{
    bool zmiKCHGnVXHq = false;
    int iYiVlAM = 1130075872;
    int KPHncZ = 1875258998;
    string STlvNoiiapZzZ = string("pwyfXKwWEOLtlhDRfkCCgOFAdDJiFvMAKXXWVQojVzsuFYmMbfXMQbLruUEDLIADGtsYqCDaVg");

    for (int nKYJtwAMpsUY = 1860733636; nKYJtwAMpsUY > 0; nKYJtwAMpsUY--) {
        STlvNoiiapZzZ += STlvNoiiapZzZ;
        KPHncZ *= iYiVlAM;
        gpYHFDAbhv = ! gpYHFDAbhv;
        iYiVlAM += KPHncZ;
    }

    for (int OGJYvaOXiVaikp = 1798019379; OGJYvaOXiVaikp > 0; OGJYvaOXiVaikp--) {
        gpYHFDAbhv = gpYHFDAbhv;
        zmiKCHGnVXHq = ! zmiKCHGnVXHq;
    }

    if (KPHncZ >= 1875258998) {
        for (int ZxkFhIJICUaYUW = 1011386165; ZxkFhIJICUaYUW > 0; ZxkFhIJICUaYUW--) {
            KPHncZ += iYiVlAM;
            iYiVlAM = iYiVlAM;
            gpYHFDAbhv = ! gpYHFDAbhv;
        }
    }
}

int VkrEM::opWgdPbbAafYu(bool elTTd, string wzSQQqRxKb)
{
    int KvjVNAT = 2068990852;
    int wNqtSHPHCJE = 1293072915;

    for (int aASCQTT = 596769899; aASCQTT > 0; aASCQTT--) {
        KvjVNAT /= KvjVNAT;
        wzSQQqRxKb += wzSQQqRxKb;
        wNqtSHPHCJE = wNqtSHPHCJE;
        elTTd = ! elTTd;
    }

    for (int KlYNRrjnejQhtU = 477215690; KlYNRrjnejQhtU > 0; KlYNRrjnejQhtU--) {
        elTTd = ! elTTd;
        wNqtSHPHCJE += KvjVNAT;
        wzSQQqRxKb += wzSQQqRxKb;
    }

    for (int SmBZpEe = 467918253; SmBZpEe > 0; SmBZpEe--) {
        elTTd = elTTd;
        KvjVNAT += KvjVNAT;
        wzSQQqRxKb = wzSQQqRxKb;
        KvjVNAT = KvjVNAT;
        KvjVNAT /= wNqtSHPHCJE;
    }

    return wNqtSHPHCJE;
}

int VkrEM::omTWqOh(string TeNLQwrBJYd)
{
    double MchbRB = -200687.83518225944;
    int QNdGcRG = 952292161;
    int xNNjE = 1070249486;
    int mvQDnpDaY = 1439401677;
    bool WQhNaUfWeL = false;
    double ECgTvO = 267087.2545585576;
    double gPsbT = 247690.9700123464;
    string phvoQOnbowtGZu = string("ShEozSrbLozOqxDKlQiemafOrZGnxjWomRMtEeYKscrnLJOYyIESgHgqjsUnziSxPclBYHDdaupkSqBOyXPiACuJPXjZWwSjhycGPrEuqCsbWHPatkkVpXttvWyhhMPckscLaggYEcgjclFNAZypNPasPlgKuzsRbdPVHyjvFFRYCX");
    int AIhORvucvMrF = -1587835300;
    bool AReUN = false;

    for (int GEFsOAiXwdFysr = 102968824; GEFsOAiXwdFysr > 0; GEFsOAiXwdFysr--) {
        xNNjE = xNNjE;
    }

    for (int LFIgG = 903051418; LFIgG > 0; LFIgG--) {
        AIhORvucvMrF -= mvQDnpDaY;
        QNdGcRG = QNdGcRG;
    }

    return AIhORvucvMrF;
}

VkrEM::VkrEM()
{
    this->rIZqdv(string("pCXJykIeAmSNMijQpWNBbnCMCtatXaJEgxzFOVqYobiEXugiMtzlOzcSOv"), 580110597, 48756.364624758455);
    this->HbtRQeVTueeR(string("nSqdhjYszEaDPiNbqUozgvJvQashrwLOWDTWgzUMNKvGchdocJdtEaKFUUUjhjUQCavQRyHuFaIPhWCjGYqaqbOVmCvqVwyFTwgstQGtjgLEfUTxJsULSmgbzOkHlczONkQHIWWMCZnjMKMwIBVXuWtmQXPwvEgaWQlIcuJVWSWsHpNhPNzVtZWWbrGBrgpFaarcxrjGUYFrZIocFMFzMzHeOYGCNigcGUorCndBnwrtVxKiaPBUF"), -1804239581, true, 627882061, string("jBmioGNCI"));
    this->EfnIf(true, false, -2017772035);
    this->HOlJQclUCTgnu(false, 1864021010, 1113781839, 1173507205);
    this->VVbzHwdxVRDckE();
    this->RXZjbLtSxfDuoFh(true);
    this->opWgdPbbAafYu(false, string("qBfltlkBEpSxblndffBTTjVCeJqnnkylrYxPQveygIPDjsFmIsHDBoVzMkRaHentqGvWqJuuVXKqerMaTMMqYPXomvNoCKDyNGpTjJtWMWCCJBlBRipuGLcMChlBjfVyOHeOascdYbWNhNwoycifn"));
    this->omTWqOh(string("uCZVdnzNhwSxcnevoBUnKlABkIRJmDYEjMlYXQMbisRrqDGuehNIdQnAaczeLbBPBtavCKzqUYbfvdGKyrDElNbcbEfbIJeqigsqDIB"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DcpykDJgd
{
public:
    int FZPHCQdZBO;
    string CeMhrQBsWEY;
    string fxJFYVyqJit;
    double XPJLtoosE;
    string EQlAB;
    string hKyZOHa;

    DcpykDJgd();
    bool GdjyV();
    double msDYJOW(bool IeckKBDBqyWSTDo, string mktEFuvfQ, bool LGUpMqnpbAmaLJXP, bool PWNRxNz, double bnrXDdBCm);
    void UKdJlG(bool PptNfrlhhQ, double SxNNBaktX, double YPXqRUEJoBxVlFxW, double IcXIrgL);
    double pBRIODs(bool wDIRNmsMFMsSzG, double YQxqIYbtKFes, bool WAMZyPJxVTrfi, bool nLrcQFlFT, string VlmxAgV);
protected:
    string WfOwdxwFEkDT;
    string fVBDBXLxRcPlGvqo;
    string gbTuhlXYefDU;
    int WORsTfkEUyjxFG;
    int wkKnwrCVcHPYEgeK;

    void JBemdBsDuwKxPfpR();
    void NMDmrjSBu(double lMxlrqdb);
    bool FXCORcmAnU(bool omSXLrnfJqI);
    string pmWEdB(string hxvxL, double wZecmrlllVon, string NMJBkKXeuqCT, bool eVWCkxXqhpXFSbg);
    bool aVoArSVVDchgWYJf(double OZvWdaMgCEYpbM, string nWgztpQIHg, bool sHWaPHNQTeMZt);
    void BRJOss(int xJckTZYPI, int YLqiEwXN, int WzgWceMfPSWEhP);
    double wCOjG(bool zIqyFf, string awIDMUwpmK, string FhpnzJEiK, bool wNKWkeFZ);
private:
    string qTZMOueWLtEYHwCQ;

    void vwlQsBfzZWmqFxSp(bool iCxtumA, double gUeUFiLeQv);
    int lTBcpmgt(bool gDDQQBPBVB, string VoSxTaXlslFoL, double qWGMjPjpapwA, double EgvrPSdF, bool PCPycFztr);
    double EeAvMWMPkmPIiKX();
    double wHsSQmfDGxeF(string gbHZDDC, bool NYIVDo, bool LFOKZhV, string mgFBzyepVOkusH, int HjUFqqgw);
};

bool DcpykDJgd::GdjyV()
{
    string KESDTCMvhgQzVzi = string("eFBMAGqaON");
    int lyyEASxtLYRElPC = -1745645258;
    double cCpxBunBqp = 129537.03440905696;
    double MLDMDFwBGShMv = 86820.0761793106;
    string yBPvPVlCkg = string("JiYlJrFcudLcJKoYROpiBypZA");
    int FDGGoKucgJlUw = 769030101;
    string FGDmTsiacbC = string("nwrVRLIsQXAGPoaXxFycSGHXeRFzzSPbpuqpsrjmmTZrjxrsnLugtzoAknvuejtBiPCoqLjwhUVwnsvdxPBqrSUUvEKOLKbEbcq");
    int ozNlXivHhLOQVy = -1198972763;
    int IFpbInzW = -1252443204;
    double CBIVkAuZKokCy = 945612.4445662381;

    return true;
}

double DcpykDJgd::msDYJOW(bool IeckKBDBqyWSTDo, string mktEFuvfQ, bool LGUpMqnpbAmaLJXP, bool PWNRxNz, double bnrXDdBCm)
{
    int pUmMuZK = 770372974;
    int wKyskjZBlsd = 2018942264;

    return bnrXDdBCm;
}

void DcpykDJgd::UKdJlG(bool PptNfrlhhQ, double SxNNBaktX, double YPXqRUEJoBxVlFxW, double IcXIrgL)
{
    int OPrwpJqDrFfLVbxE = -361081472;
    string YVlCjYiBtuLxR = string("igEcAiIytdKfQLIPCxNDyGwpTWXakYJSpyDgLvfcMWdRsMlrrDiMzLPOtSySuOcClOYzLmAhNSGLlCIYRAQboiUjGFukSYKRYfibFRC");
    string yMwtZ = string("RKBkeadzhoUyTfVOEPRrHBvzZWYvVntVSHxeIAVaJnMEelahbTROLRlGULTnjePFjuHoTzKGzODhkaLYlIibFKPMTLYaKPGwlWATsYMpYuVWLBuctEWtOWKlHEXykptRLkQgDCaqUpOOLCsPrTTQmusbuKuroQgnoDRMTpjTHsQwapHfvAQwlBgHKgglGwoAVHjksgknVKvMXj");
    double BDKphaMeDP = -499796.44067228335;
    bool cuMFifRHrYKwh = true;
    bool YepkPACKJjiekc = true;

    if (SxNNBaktX >= -304257.23880122096) {
        for (int oWSxeNqXttCDvyG = 1381080442; oWSxeNqXttCDvyG > 0; oWSxeNqXttCDvyG--) {
            IcXIrgL /= SxNNBaktX;
            YPXqRUEJoBxVlFxW /= IcXIrgL;
            PptNfrlhhQ = ! PptNfrlhhQ;
            cuMFifRHrYKwh = PptNfrlhhQ;
        }
    }

    for (int VCUBUAOlM = 306880499; VCUBUAOlM > 0; VCUBUAOlM--) {
        continue;
    }

    if (IcXIrgL <= -32483.958948525735) {
        for (int hEEmgjCfVOCVavKF = 1939349510; hEEmgjCfVOCVavKF > 0; hEEmgjCfVOCVavKF--) {
            continue;
        }
    }

    if (YVlCjYiBtuLxR == string("RKBkeadzhoUyTfVOEPRrHBvzZWYvVntVSHxeIAVaJnMEelahbTROLRlGULTnjePFjuHoTzKGzODhkaLYlIibFKPMTLYaKPGwlWATsYMpYuVWLBuctEWtOWKlHEXykptRLkQgDCaqUpOOLCsPrTTQmusbuKuroQgnoDRMTpjTHsQwapHfvAQwlBgHKgglGwoAVHjksgknVKvMXj")) {
        for (int jjwxWfS = 1397326174; jjwxWfS > 0; jjwxWfS--) {
            PptNfrlhhQ = cuMFifRHrYKwh;
            YPXqRUEJoBxVlFxW -= IcXIrgL;
        }
    }
}

double DcpykDJgd::pBRIODs(bool wDIRNmsMFMsSzG, double YQxqIYbtKFes, bool WAMZyPJxVTrfi, bool nLrcQFlFT, string VlmxAgV)
{
    string nRltVsBtjnSV = string("zawCcwocnbrLSHAIqwIezXVTLjadVSbPYHYZwNgoAgJJHORDJlTSRcMYhNyRhwECGkBiJBtjJdoXZBisLoiQMWwVICYfvcetqCbOaAeGzjJbSTUxOyWsujgSirCObhIPtHEOgQTRTSpTdfXitWwgzZhjBfwFHOBNnsNShHEQoWDbMSUAtfpoUsnTDSWuElbEcOpiQDevEuMtFCVsVilibAJfdDawchMbMXEKHkpZcQLEKPlTrpy");
    bool zbpnIvWytnm = false;

    for (int tpjpn = 1898269251; tpjpn > 0; tpjpn--) {
        VlmxAgV += nRltVsBtjnSV;
        VlmxAgV += VlmxAgV;
    }

    return YQxqIYbtKFes;
}

void DcpykDJgd::JBemdBsDuwKxPfpR()
{
    double sKMHgrRmnhywoYnc = -393958.012187956;
    bool jTXIYsdqrioDnXt = false;
    bool znDHROH = false;
    bool EKyHPcc = false;
    bool xqyAUwScTaySY = false;
    string MgfgRnHUAFX = string("ofSbPCgHtOOtVAZouKPTMNjgIXgEVxwjnDhwsaHmvEyOHYdYjlunYOFcEiywRDXBHwThgpYoxgCEYHRKMHMroqNuAjzgmdAtPwUhfGnPGoPAqJeIpEMbjReMdVhUhFZTcOTfUtPYvDZDSzlxhSpjyY");

    if (xqyAUwScTaySY == false) {
        for (int OUXPFs = 1112205151; OUXPFs > 0; OUXPFs--) {
            continue;
        }
    }
}

void DcpykDJgd::NMDmrjSBu(double lMxlrqdb)
{
    string oxfjDsH = string("hcUpIHQiXsxVrXVTkyzRtjQsrpuvAgylyjhQOcprfCxoEwydMTwTKzankEjAlKBqQXvtcnZyARtVIigWqosGkURdydCEBzQfKuadmYJJ");
    double wdvxkpKPmCkfuCt = 686329.5051408828;
    bool ZbDOneVF = false;

    if (lMxlrqdb < 686329.5051408828) {
        for (int VxSrC = 361591178; VxSrC > 0; VxSrC--) {
            ZbDOneVF = ZbDOneVF;
            lMxlrqdb += wdvxkpKPmCkfuCt;
            ZbDOneVF = ! ZbDOneVF;
            lMxlrqdb += wdvxkpKPmCkfuCt;
        }
    }

    if (wdvxkpKPmCkfuCt > 301392.6142669031) {
        for (int ocNVMyhsRLAyN = 2105660438; ocNVMyhsRLAyN > 0; ocNVMyhsRLAyN--) {
            ZbDOneVF = ! ZbDOneVF;
        }
    }

    for (int UBdHTrH = 895432022; UBdHTrH > 0; UBdHTrH--) {
        continue;
    }

    if (wdvxkpKPmCkfuCt <= 686329.5051408828) {
        for (int spGxftYRwTC = 1020739089; spGxftYRwTC > 0; spGxftYRwTC--) {
            ZbDOneVF = ZbDOneVF;
            ZbDOneVF = ZbDOneVF;
            wdvxkpKPmCkfuCt -= wdvxkpKPmCkfuCt;
            wdvxkpKPmCkfuCt -= wdvxkpKPmCkfuCt;
        }
    }
}

bool DcpykDJgd::FXCORcmAnU(bool omSXLrnfJqI)
{
    int HWWNTumWXXka = -1581418522;
    int pGoURF = 1093811715;
    int rxtgERo = -2096094221;
    int yxFbyRZtHwEC = -1540343482;
    bool FQSfMpGektgmf = false;
    int cJqqpjoHsxFWTj = -1446587789;
    double cVPSw = -420868.6519977246;
    double iERcyPGvagsXkcVZ = -135042.80141062188;

    for (int QEvCpw = 52490045; QEvCpw > 0; QEvCpw--) {
        HWWNTumWXXka = HWWNTumWXXka;
    }

    if (pGoURF != 1093811715) {
        for (int NxpFiCN = 2017253795; NxpFiCN > 0; NxpFiCN--) {
            rxtgERo += pGoURF;
            omSXLrnfJqI = ! FQSfMpGektgmf;
            FQSfMpGektgmf = ! omSXLrnfJqI;
            HWWNTumWXXka += HWWNTumWXXka;
            cJqqpjoHsxFWTj -= cJqqpjoHsxFWTj;
        }
    }

    if (omSXLrnfJqI != false) {
        for (int OTIQTEFYRLhY = 1321436682; OTIQTEFYRLhY > 0; OTIQTEFYRLhY--) {
            omSXLrnfJqI = ! FQSfMpGektgmf;
            cJqqpjoHsxFWTj -= rxtgERo;
            FQSfMpGektgmf = FQSfMpGektgmf;
            HWWNTumWXXka = rxtgERo;
            yxFbyRZtHwEC = cJqqpjoHsxFWTj;
            pGoURF -= cJqqpjoHsxFWTj;
        }
    }

    for (int wHMGqQtIM = 144837130; wHMGqQtIM > 0; wHMGqQtIM--) {
        pGoURF *= pGoURF;
        HWWNTumWXXka *= HWWNTumWXXka;
        rxtgERo *= rxtgERo;
    }

    for (int VxYyk = 566311258; VxYyk > 0; VxYyk--) {
        iERcyPGvagsXkcVZ -= cVPSw;
        HWWNTumWXXka /= HWWNTumWXXka;
        omSXLrnfJqI = FQSfMpGektgmf;
        rxtgERo += cJqqpjoHsxFWTj;
    }

    if (cVPSw == -135042.80141062188) {
        for (int SlRFNAjV = 939419645; SlRFNAjV > 0; SlRFNAjV--) {
            yxFbyRZtHwEC *= yxFbyRZtHwEC;
        }
    }

    return FQSfMpGektgmf;
}

string DcpykDJgd::pmWEdB(string hxvxL, double wZecmrlllVon, string NMJBkKXeuqCT, bool eVWCkxXqhpXFSbg)
{
    int DWHhfLGs = 1814127964;
    bool LDfDwJygkiAYimLf = false;
    string lrcpgOYcnugp = string("yrqJarUeojSfVhQVQEqlpltiLlfbtTtwJGzVGOHnErVSYqXaCUnHroXVeSoahbzifcZszlBIGTEPtrIJnZ");
    bool IqQfPOPrzSP = false;
    double vkqJGrU = -1018565.0033392627;
    bool yELhWRBHOvf = false;
    bool ZUPRbStsa = true;
    bool GiGInXw = true;
    int VMkYr = 553505409;
    int cTtxo = -1346785744;

    for (int FUUON = 1952514907; FUUON > 0; FUUON--) {
        continue;
    }

    for (int GiQooQBSjZgE = 1587961430; GiQooQBSjZgE > 0; GiQooQBSjZgE--) {
        continue;
    }

    for (int rRxQzIZw = 2108656185; rRxQzIZw > 0; rRxQzIZw--) {
        NMJBkKXeuqCT = NMJBkKXeuqCT;
        VMkYr /= cTtxo;
        IqQfPOPrzSP = yELhWRBHOvf;
        yELhWRBHOvf = yELhWRBHOvf;
        yELhWRBHOvf = ! IqQfPOPrzSP;
    }

    for (int cBxvci = 2079181936; cBxvci > 0; cBxvci--) {
        continue;
    }

    return lrcpgOYcnugp;
}

bool DcpykDJgd::aVoArSVVDchgWYJf(double OZvWdaMgCEYpbM, string nWgztpQIHg, bool sHWaPHNQTeMZt)
{
    bool WMEQQVZmhNa = false;
    double rhzaJhqTNgPyMJ = 49116.18315651768;
    double ZJOzJbzo = 196063.71406087573;
    int HepGbAhlbdtbB = -618199033;
    int cxVZpSZcmBhwSoS = 405810531;
    bool gRYAlUF = false;
    bool CCprvo = false;
    string CgquAnQka = string("OLWNuHlzoUfTzZflEuMUvTixAeGSmhbRMBQkcewADGtQfmcxGQWSuw");
    int oLxlWMsjkSFo = 1692889973;
    double hOwxUYQ = 1017449.2572929193;

    for (int XluzRfefyl = 299174921; XluzRfefyl > 0; XluzRfefyl--) {
        CCprvo = sHWaPHNQTeMZt;
        sHWaPHNQTeMZt = sHWaPHNQTeMZt;
        rhzaJhqTNgPyMJ += OZvWdaMgCEYpbM;
        CCprvo = sHWaPHNQTeMZt;
        gRYAlUF = gRYAlUF;
        hOwxUYQ /= ZJOzJbzo;
    }

    return CCprvo;
}

void DcpykDJgd::BRJOss(int xJckTZYPI, int YLqiEwXN, int WzgWceMfPSWEhP)
{
    string yucxAtO = string("rUHXeHYwYONsnGnxYRjDJJPTtCRIJYWxQxEMUD");
    bool lmUgIIIh = false;

    if (xJckTZYPI >= 1908867786) {
        for (int ohDvQuRQNRX = 605372172; ohDvQuRQNRX > 0; ohDvQuRQNRX--) {
            WzgWceMfPSWEhP -= xJckTZYPI;
            YLqiEwXN /= xJckTZYPI;
            lmUgIIIh = lmUgIIIh;
            YLqiEwXN = WzgWceMfPSWEhP;
        }
    }

    if (WzgWceMfPSWEhP >= -1052697406) {
        for (int PwDBKgRTopgx = 1064313359; PwDBKgRTopgx > 0; PwDBKgRTopgx--) {
            WzgWceMfPSWEhP -= WzgWceMfPSWEhP;
            YLqiEwXN += WzgWceMfPSWEhP;
        }
    }
}

double DcpykDJgd::wCOjG(bool zIqyFf, string awIDMUwpmK, string FhpnzJEiK, bool wNKWkeFZ)
{
    bool yNYhzHMOEyNm = true;
    bool eyLpou = true;
    string glWcluFJrFOAHHrh = string("TbsEBjZKYevIsvzbAyABrOGRXwJWHQTCtjhvxrPjLOkUCYhn");

    if (FhpnzJEiK <= string("TbsEBjZKYevIsvzbAyABrOGRXwJWHQTCtjhvxrPjLOkUCYhn")) {
        for (int vlEaIpFCKuiXZCz = 796212324; vlEaIpFCKuiXZCz > 0; vlEaIpFCKuiXZCz--) {
            FhpnzJEiK = FhpnzJEiK;
            wNKWkeFZ = zIqyFf;
        }
    }

    for (int wVCzMO = 1523942320; wVCzMO > 0; wVCzMO--) {
        continue;
    }

    if (FhpnzJEiK >= string("uYtEhFpprgVKyMqNAJQEQAuZUsQYnxeNWNoShEScsUZkZSGxlRmfpIoLSFYWDvlnpCWuUscOneqCCAlxMyFjjjJSDCJlGWbkMnRLiubBXooDSxnAJW")) {
        for (int RqydBQkudNQck = 1731511858; RqydBQkudNQck > 0; RqydBQkudNQck--) {
            eyLpou = ! zIqyFf;
            zIqyFf = eyLpou;
            zIqyFf = wNKWkeFZ;
            yNYhzHMOEyNm = ! zIqyFf;
            eyLpou = ! eyLpou;
        }
    }

    return 537209.1956237109;
}

void DcpykDJgd::vwlQsBfzZWmqFxSp(bool iCxtumA, double gUeUFiLeQv)
{
    double fDLPc = -780103.2645043781;
    string yYHUYDTef = string("uEbZuXEAgMzHnoykIFEVWavFfNzKlFDdSNPGDepuKtEEsWZdvFnxjLxTjamzMzVoZjXVGstIpwjBZBFYuIZHFIvgZrHTXMggCunACdURuzicAhlKgolAbtnNoQnSQIEuxRYNSkCOFTOSdhuxUyymmhafnRpulKGiyXyIHdGeANyjRkuahiQPzmTAEOLOjIPDhoktHeWnNXNjwqye");
    double UEwOGFpkxe = 400575.23970208736;
    string bTbQmt = string("ICENgMSPEWPlBgtoVQXZvPKsykUugViTecApklRwlFMhzrI");
    double SYfznrKpCGMo = 269867.8956909835;
    bool GOCELM = false;
    bool fSNChtaHRH = false;
    int WaEdvknVYDL = 1710421756;

    for (int NJDZdKbVvYZrw = 841996290; NJDZdKbVvYZrw > 0; NJDZdKbVvYZrw--) {
        continue;
    }

    for (int yEepoUqZ = 148692462; yEepoUqZ > 0; yEepoUqZ--) {
        iCxtumA = ! iCxtumA;
        GOCELM = ! GOCELM;
        SYfznrKpCGMo -= fDLPc;
    }

    for (int IrZbfJbaOrV = 1875621754; IrZbfJbaOrV > 0; IrZbfJbaOrV--) {
        UEwOGFpkxe *= fDLPc;
    }

    for (int JcTzcN = 1914894125; JcTzcN > 0; JcTzcN--) {
        continue;
    }
}

int DcpykDJgd::lTBcpmgt(bool gDDQQBPBVB, string VoSxTaXlslFoL, double qWGMjPjpapwA, double EgvrPSdF, bool PCPycFztr)
{
    int CAthaIBSYYb = -2090624842;
    double cqGRhWAPfjCt = 555566.6107152582;
    string IFqDXucDRrdmQPOE = string("OdPelVJFEsZxmBpAcJTUpQDEBNYYWQIHfZkxMnjUQDoIZvVdGfBLExwTuyDpUGptEfzGwDhWDTkLYgMknPStgMrHZDzsOByortMGMoGStNerUcdzaJzRzAflDZAaOrQeiKJWXKZKDYmrHCLMBxXcGltrZDZVXtIGAFTlGtRNTwzONHzlVbvtdryW");
    int VtaFeTCPDifV = 795533796;
    double pOYMynyn = -847451.975165887;
    double oiVuyzxUBMXmInY = -763284.4211889274;
    double glfboHhrbWtLJ = 296811.71185933455;
    int vHZtWSGofbXcl = -200613251;
    bool OafbIDMpkgTV = false;
    string cqKOxlieYMfLOD = string("bLTuGanAkUkKZGdYaejOOHLuCRMooYbzpXUHYcwDyzDleoLvYILHaHlfRQGedcZtQuBEgACytXxBbsZtUOffrkeMNrrAGZcBqGeYjRIUdPSikzcduWggNzVazjdZILAaQezOpsnEeRQdrCzGdpxloRNJHXLprjxjGIoJEjNvZNWJmyRitEotHsCLKVLoGKRjqFToHJVdcgTeeNpgmmuipEevJSKdnwTpUTkPGRbs");

    if (cqGRhWAPfjCt >= 779545.7137541852) {
        for (int evYalxrkeYHcMOlw = 402133212; evYalxrkeYHcMOlw > 0; evYalxrkeYHcMOlw--) {
            qWGMjPjpapwA += pOYMynyn;
            vHZtWSGofbXcl -= vHZtWSGofbXcl;
        }
    }

    for (int OFWDwEeLT = 902692224; OFWDwEeLT > 0; OFWDwEeLT--) {
        PCPycFztr = ! PCPycFztr;
    }

    for (int NAUxFiSbVXmcxhDc = 38564205; NAUxFiSbVXmcxhDc > 0; NAUxFiSbVXmcxhDc--) {
        glfboHhrbWtLJ = EgvrPSdF;
        pOYMynyn -= glfboHhrbWtLJ;
    }

    return vHZtWSGofbXcl;
}

double DcpykDJgd::EeAvMWMPkmPIiKX()
{
    string dUQkUSnmF = string("gcgHquxgxMWfjawkTIGyonphfFisaNwxPyaBhyTeSGNbEZlyOCCTZoHHqCwkxRNFCbQoZTgslDKmsZigxcdyWISsWNlTswIupqVTvNMVjvMT");
    int DgiXgYoHTZJN = -1672090878;
    string WzjiFhrUtjl = string("xheBKKasenBscfINdlXFRjxwjuAibsZuLsybvjKgrLhedWtCmfFpLntOpaaLlOiTeyIxuHdbseudnnoKcuyOGMZfjaSmYHvGoPSoAqlnrfiYNTvXAcWaVkotSNycnbtjYauWERTOJyUWaDBGiDYxMJOZKLSwvGdTfImGNUxM");
    string WRAeWFL = string("dHFzZoRyriWTrQxsDRWCtLoppqCYEWbHbJcJatBNghSgipOKIYpyBHusvaIuWlOrOfaRhakMeawLnqWujQgrVWLSlxdIPxsQkDpP");
    int argcqlXTqkp = -853420367;
    double hAwkEAyjmDrrw = -196115.97549430115;

    if (dUQkUSnmF < string("dHFzZoRyriWTrQxsDRWCtLoppqCYEWbHbJcJatBNghSgipOKIYpyBHusvaIuWlOrOfaRhakMeawLnqWujQgrVWLSlxdIPxsQkDpP")) {
        for (int XtyvOYyvlOCt = 807864478; XtyvOYyvlOCt > 0; XtyvOYyvlOCt--) {
            WzjiFhrUtjl = WRAeWFL;
            WRAeWFL = dUQkUSnmF;
            DgiXgYoHTZJN /= argcqlXTqkp;
            DgiXgYoHTZJN += DgiXgYoHTZJN;
        }
    }

    if (DgiXgYoHTZJN >= -1672090878) {
        for (int zPgnfehjY = 1900151311; zPgnfehjY > 0; zPgnfehjY--) {
            dUQkUSnmF = WRAeWFL;
            DgiXgYoHTZJN /= DgiXgYoHTZJN;
            hAwkEAyjmDrrw = hAwkEAyjmDrrw;
        }
    }

    for (int TmZpvxzVcHKuvi = 513696560; TmZpvxzVcHKuvi > 0; TmZpvxzVcHKuvi--) {
        dUQkUSnmF = dUQkUSnmF;
        WRAeWFL = dUQkUSnmF;
        WRAeWFL += WRAeWFL;
    }

    for (int MpCvtYbZlL = 404946366; MpCvtYbZlL > 0; MpCvtYbZlL--) {
        WzjiFhrUtjl = WzjiFhrUtjl;
        dUQkUSnmF = WRAeWFL;
        DgiXgYoHTZJN -= argcqlXTqkp;
        WRAeWFL += WRAeWFL;
    }

    for (int JzkryIzmpPkeCWXr = 1543398059; JzkryIzmpPkeCWXr > 0; JzkryIzmpPkeCWXr--) {
        WzjiFhrUtjl += dUQkUSnmF;
        WRAeWFL = WRAeWFL;
        DgiXgYoHTZJN += DgiXgYoHTZJN;
    }

    return hAwkEAyjmDrrw;
}

double DcpykDJgd::wHsSQmfDGxeF(string gbHZDDC, bool NYIVDo, bool LFOKZhV, string mgFBzyepVOkusH, int HjUFqqgw)
{
    int HnNybmMeAhF = 2137670720;
    int WMBcjXmlZCtGATc = -1428948249;
    bool HkzOzGKOpnwfy = true;
    double HcmumXeXesmM = 732243.5323961145;
    string NBPruArXTKApMBm = string("PPUzYhSWjDhPaYHzqXYXGoGlmFFdtZbPbqzPrUMFRkwIffzGJaDGQqBZNatPLspiKpqgSGVcJzeUIkMIjnElNhqthYiuBykdHWDvmPpzyCGDbKefhywjAuXReWdxRKUHLXaNWPTROgPHhEWmscuZdmgKtZe");
    bool Upapcqvd = false;
    string dmaWaEMmahr = string("GTFthXuiCeaxVUdmkCTxkHRlc");

    if (HjUFqqgw == 2137670720) {
        for (int sIYGanNCjGN = 1626243434; sIYGanNCjGN > 0; sIYGanNCjGN--) {
            gbHZDDC += gbHZDDC;
        }
    }

    for (int rceONhgSpSxZNx = 1755795622; rceONhgSpSxZNx > 0; rceONhgSpSxZNx--) {
        NYIVDo = ! NYIVDo;
        dmaWaEMmahr += NBPruArXTKApMBm;
        NBPruArXTKApMBm = dmaWaEMmahr;
    }

    for (int xeGWznAScLWnW = 686356050; xeGWznAScLWnW > 0; xeGWznAScLWnW--) {
        continue;
    }

    if (HkzOzGKOpnwfy == false) {
        for (int diJPRgCoiuUMq = 1743357471; diJPRgCoiuUMq > 0; diJPRgCoiuUMq--) {
            Upapcqvd = ! NYIVDo;
            mgFBzyepVOkusH = NBPruArXTKApMBm;
            HjUFqqgw = WMBcjXmlZCtGATc;
        }
    }

    for (int WvEWfZPi = 1765363663; WvEWfZPi > 0; WvEWfZPi--) {
        continue;
    }

    for (int qynnhjBhWHa = 279405105; qynnhjBhWHa > 0; qynnhjBhWHa--) {
        continue;
    }

    if (gbHZDDC <= string("GTFthXuiCeaxVUdmkCTxkHRlc")) {
        for (int BRsIDgUgSKC = 118421400; BRsIDgUgSKC > 0; BRsIDgUgSKC--) {
            HkzOzGKOpnwfy = ! Upapcqvd;
            HjUFqqgw += HnNybmMeAhF;
            NBPruArXTKApMBm += mgFBzyepVOkusH;
            WMBcjXmlZCtGATc /= WMBcjXmlZCtGATc;
        }
    }

    return HcmumXeXesmM;
}

DcpykDJgd::DcpykDJgd()
{
    this->GdjyV();
    this->msDYJOW(true, string("uFDLXZECTcHcaQQvDBLduKDZfU"), false, true, 223779.76419957975);
    this->UKdJlG(false, -304257.23880122096, -32483.958948525735, -554072.5542846888);
    this->pBRIODs(true, -825651.2868463019, false, true, string("bvoXTYjwoIzhURlKeXZSdSdimyDYeXDFldnMzPihygdzwpbkQvmJwMSePyOEFFSIZDIYMGbQPNtchKWDBWuddZFZBjAbhsCJkqN"));
    this->JBemdBsDuwKxPfpR();
    this->NMDmrjSBu(301392.6142669031);
    this->FXCORcmAnU(true);
    this->pmWEdB(string("gcGhyQUHoBBDcOPwTdVoXxMbrXIFEOWAFLLkfOdgIYcyZlmODPqsycJtEiUqhZiQkUnThGQEUkJILiyBtiMpXADoRFuYzbIKLOObcYHyxFIQvsIAzGHSOrWDFAYuLhmMTgDlhwBmufTHubRjsOMJgjLxkYlXCaCvpKJjTCnkLXADQFvqTKxpTwNEODNKqLMZXfIakdsGqGQYktSOzrLtdptIJFXWEZNmniOnRAdYBa"), 888464.4613481441, string("hdTWdeshTMRmFdmzhFgL"), false);
    this->aVoArSVVDchgWYJf(866874.0391188608, string("kqMGXvnwRpoZIHYSemaJZwpIUHgBYvKgBLeNDOuyuuisUsNOlwjrgkhiBgJYPSDoXTDMabCsMxMKlaOQJNqzVuCDcQMmuWrOTWhCCtVQTtHaamTmaMPJWMDACOQgPNRLHhPhKjLuCIpqhTeAjEfgUhsPIpngybAMehGOVVspmyXwDUJEsQcIxthtCDqeFiLlvkH"), false);
    this->BRJOss(1908867786, -1502227951, -1052697406);
    this->wCOjG(true, string("FQlIPUdNXqqZWoAcgBhaQOGAvxwHaKbGrEltiqTGUYRYihMBkIsyjmTySXDhEysvdbwlxWARVnThkCTqBaToUNYctSIHxdFLeJxg"), string("uYtEhFpprgVKyMqNAJQEQAuZUsQYnxeNWNoShEScsUZkZSGxlRmfpIoLSFYWDvlnpCWuUscOneqCCAlxMyFjjjJSDCJlGWbkMnRLiubBXooDSxnAJW"), true);
    this->vwlQsBfzZWmqFxSp(true, -611575.9206452186);
    this->lTBcpmgt(false, string("jTbqFWsHOxJGXvndgyhJGAwVEYhsjmnTALcbIhaUcrvzREYaUYOqknIcGLqoIAfLoSMCjdcTCqqXZ"), -1011313.5707137291, 779545.7137541852, false);
    this->EeAvMWMPkmPIiKX();
    this->wHsSQmfDGxeF(string("hbobRxNuLOoLRdDQxshIAFkKvToJqGxcnlXYyMPXyLIkhyGXQNqswvLsifSJsOjeCvHvOQZfECMbQxkfthKwqHYYalISRMnFovsscuRdGpucFzAqpKgzOohcthtnbnsEpIBtBNkUzUiCzMqq"), true, true, string("nIfPKrNNcvkniRKIaqRyyzDgukVqePEOFqkunMfpWalcWTCuzhIqujivKqACEoPthnJyPpVVzAVOWhvDjcybqkvZvnDgHAWQHrTxFqFxQbcrKvOwLhiRzXeTotAMJiSHkqExCmHmTUjfYjrTazuhNvSpaIOsRHUkJSCIKSQgEDOEqprDLOPTdnRhAzWRBcnXQSaybefKHzKOcXQDhjtPJtBMjFQA"), 2082060968);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uHrWrGjeJhkRA
{
public:
    bool HYyjGcxFwZ;

    uHrWrGjeJhkRA();
    void sWqpIDORhEk(bool lumTXCnmN, string QRLZNtrxFy, double VJdQxTUT);
    int XmbxpZSVBQmT(string egBDrwoYfuLstqv, string GIOGxgra, int VTqFMbfXQasI, int qwQcBBgnBDmRaaQ, int zyRAsSRZjpbIkcGf);
    string uBUQy(bool DFxtAPgNDNF);
    string RGrtqaISjLikaPnJ(double JBNZyEvgL, bool GvfLKNcHrICMWx, bool EljydJxJndDnHSIC);
protected:
    bool kfKHGkofxvBHt;

    double lHybBdXjxzBT(bool sCwkiFUCgeWnrIMi, string BbnTkugCVj, int ZUdGbKRlst, int BroMsMBFyvhJ);
    string HQJDufIV(string oTjxssDjrwXDe, bool gJiIgBHeqDzWlsMX, double YNuhALIVZevcTUQJ, int RYmTIjWfZboZ, bool tZcZvagsjoMhPvq);
    string SjrFmTdbZIqj(bool IGIwbPRnj, string NwxcfXBV, bool hpCtG, double hCbmgKbxtXeQg, string PsZFMKsMRn);
    bool IhnELxi(bool IyxuDzwp, bool HIJdzMCZLOkVVVB, bool vQdVPeGb, int anEsdASIqD);
    string YnuolEfmpjkCmRx(string kwdzskeHdijm, int jjMzBGbkH, int sVQutnVDnUxb);
    int kZsvZFW();
    void mlrAAKEI(bool dKIwVZKmsw, double mjvLwohAuGn);
private:
    string WlWfuxBs;

    string MfUnotSlXTwPmjk(string EoIxFMZpWOu);
    string LBPRD();
    int LhCvdPLQrWsVxSkW();
    int yRhSuVjGvl(string uMlgKDLdKUqhng, bool uaMcfYkSJmn);
    int bufthBHj();
};

void uHrWrGjeJhkRA::sWqpIDORhEk(bool lumTXCnmN, string QRLZNtrxFy, double VJdQxTUT)
{
    int AtiHWbenO = -1133097722;
    bool PDhUOo = false;
    int gKNjjzG = -885437188;
    string WmDZFuOeM = string("bhyGfaYBoqwoXHSIUwZjYvmJnONakuKWrHeyuXpuzqPOOEKvsdusjnNiwFjGZGNdYINVutquBqgYUnJOxsZMBsvsuyOINPFzhlFzjobQGQnuelTNRVBHnNzmgqPftReiKbYytPaKsmw");
    double XpDtgkEiHlOSTY = -615224.5606909163;
    string UsABUjqOLfARPhAk = string("wNxwxmkSQOmmksNktasmQsMtVhMQuXvQKVdbjrEjtUsWUvgdgfNmSXCCVpDDYpCNNNAgBHhYmOhacSLEyXMSzfETzCcwJCnpMWajGPQKdTGwsTTCWbRwddKNDZrdNvmudQbmelflhsjcebNHFnBmRVUepLQuYdCFVuwnwMMrwhGXILyHaKiIqpLniNUkIxwgyJzZDIkeFQfAG");
    bool mAkAqTnflwDQi = false;
    int exrAFoZuNqfqqjj = -36025358;
    int LprJeXRwIMUqFLyg = -1097434804;
    bool oeibuD = true;
}

int uHrWrGjeJhkRA::XmbxpZSVBQmT(string egBDrwoYfuLstqv, string GIOGxgra, int VTqFMbfXQasI, int qwQcBBgnBDmRaaQ, int zyRAsSRZjpbIkcGf)
{
    int aQwvdubLv = 2127070931;
    double QUrSozmyY = 584210.2211609588;
    string qUpKrmiisGpIWX = string("qXVDHSfVYtQG");
    string pOKPHk = string("SYbcrQTutqZHflDUMgmtgoPWIwLspLeldcXaOCGeaKSMjzQJ");
    double MCYVPGFgtDU = 791887.0910723652;
    double eJKJhiMNhsfrVq = 145963.33293611597;

    if (eJKJhiMNhsfrVq != 584210.2211609588) {
        for (int gmHxlKRSJqM = 474320563; gmHxlKRSJqM > 0; gmHxlKRSJqM--) {
            continue;
        }
    }

    if (qwQcBBgnBDmRaaQ != -824838774) {
        for (int HJPdHzjKxtzGj = 113610093; HJPdHzjKxtzGj > 0; HJPdHzjKxtzGj--) {
            eJKJhiMNhsfrVq = eJKJhiMNhsfrVq;
        }
    }

    return aQwvdubLv;
}

string uHrWrGjeJhkRA::uBUQy(bool DFxtAPgNDNF)
{
    int PaiyBLEatTZDXCen = -740631253;
    bool rAPljxNEZUopsX = true;
    int xKFEoMTFB = -1505965604;
    int OyxaRc = -808986362;

    return string("xnTcnmFKsLuNGiUTWFlpXciVNRBOTMLtZyYAtLlkFTmvddOPQVxgoTNdUCXxMKqHZrnbygzfiEqwZSElWnFlwCADeMSHmxUiVVUbwGcUbDHRUSVvM");
}

string uHrWrGjeJhkRA::RGrtqaISjLikaPnJ(double JBNZyEvgL, bool GvfLKNcHrICMWx, bool EljydJxJndDnHSIC)
{
    int abYqvZfWPQQaj = 1671156639;
    bool fKJewnyfIFO = false;

    if (EljydJxJndDnHSIC == false) {
        for (int zumbmxvPe = 1993402136; zumbmxvPe > 0; zumbmxvPe--) {
            EljydJxJndDnHSIC = ! GvfLKNcHrICMWx;
            GvfLKNcHrICMWx = GvfLKNcHrICMWx;
        }
    }

    for (int YFGlJWCkQfonpXYM = 206297687; YFGlJWCkQfonpXYM > 0; YFGlJWCkQfonpXYM--) {
        JBNZyEvgL -= JBNZyEvgL;
        fKJewnyfIFO = ! GvfLKNcHrICMWx;
        EljydJxJndDnHSIC = ! fKJewnyfIFO;
        fKJewnyfIFO = ! EljydJxJndDnHSIC;
        fKJewnyfIFO = EljydJxJndDnHSIC;
    }

    if (fKJewnyfIFO == false) {
        for (int GAzxPAuUQA = 213180044; GAzxPAuUQA > 0; GAzxPAuUQA--) {
            EljydJxJndDnHSIC = ! EljydJxJndDnHSIC;
            fKJewnyfIFO = ! GvfLKNcHrICMWx;
            abYqvZfWPQQaj *= abYqvZfWPQQaj;
            JBNZyEvgL /= JBNZyEvgL;
        }
    }

    for (int DLDQaZuwTjQxYnx = 1329222757; DLDQaZuwTjQxYnx > 0; DLDQaZuwTjQxYnx--) {
        continue;
    }

    return string("YaDLSjsjgbQeHJMdxMjugdFYRtLgEfmoTxlCpxgQzIjiBmzOCIGvNXiMEjEXKdjIhKXSGwACKibIGlmggYogzkmvxWMJHTLWmXuQewIxNeXMYcBoPAMUeIjHerpgmOIhbaZoKjRAJRQa");
}

double uHrWrGjeJhkRA::lHybBdXjxzBT(bool sCwkiFUCgeWnrIMi, string BbnTkugCVj, int ZUdGbKRlst, int BroMsMBFyvhJ)
{
    string SMkybjTSfy = string("voWovrpGgrYlxnYkAWUFBlcjrHHNcyrdsRiRubcGOflfasBnjZbyVwWsnWyB");

    if (SMkybjTSfy != string("sqTJXEYpdHjcZuaJHktWpAFVnvTrAmCuScBhkrbVONQKvzgeNqDtXEPCPlYptECKjhrHLXtdPQNhjkoANnsDDFYwfsiTtfYMpRUBtsuFZRDiJyzbhOAvaFJfwYArpbbJIVHjXnTktqlnZQcEVApyrGXY")) {
        for (int OhJIZwFeCdKKNNdL = 638633334; OhJIZwFeCdKKNNdL > 0; OhJIZwFeCdKKNNdL--) {
            SMkybjTSfy = SMkybjTSfy;
        }
    }

    for (int ugONLHU = 789991302; ugONLHU > 0; ugONLHU--) {
        BbnTkugCVj += BbnTkugCVj;
        ZUdGbKRlst *= ZUdGbKRlst;
        ZUdGbKRlst += BroMsMBFyvhJ;
    }

    for (int MQxTAlovSAk = 1332140820; MQxTAlovSAk > 0; MQxTAlovSAk--) {
        continue;
    }

    for (int xEwAIO = 1453443653; xEwAIO > 0; xEwAIO--) {
        continue;
    }

    if (ZUdGbKRlst < -1619564731) {
        for (int mXNoWOH = 446065063; mXNoWOH > 0; mXNoWOH--) {
            ZUdGbKRlst *= ZUdGbKRlst;
            ZUdGbKRlst /= ZUdGbKRlst;
            SMkybjTSfy += SMkybjTSfy;
            SMkybjTSfy += SMkybjTSfy;
        }
    }

    return -1036966.870844421;
}

string uHrWrGjeJhkRA::HQJDufIV(string oTjxssDjrwXDe, bool gJiIgBHeqDzWlsMX, double YNuhALIVZevcTUQJ, int RYmTIjWfZboZ, bool tZcZvagsjoMhPvq)
{
    bool TiaFAvJRTOdqnEw = false;
    int EnjHQ = -1652404796;
    double IMVBp = 1003636.6502810031;
    string HbVGlmlgEQawWV = string("aSfpkUUEiVssTbzzsXeqtAhNvecQJedlzuymiqiBFpmEoYuPAdhPumYWAhPFAWGuKlxrflkZvCPbASgzwJryAMsQiIHqROOcKHfPsfKgzaSYszRotZlCjVXjQTzZPhNQoXKGQxqkIDAORiGHKBfDmHJVAjWYBOaETmwVkxboTHiZKCCyDxpJ");
    bool rDknsDzFaNYNIOWo = false;
    string pakZrqYnyTI = string("FTWXKRBbOhsnaLaWVmAZRYwLcAkosVFQxNkmEWtkceXztYoOeAjNYk");
    int NPxdwLFECaYpx = 886733039;
    string GFeVzmMnu = string("STdxUkTtrWYobYxCgBtevuvbFMcLDiFeiFYUAoaDiSayrdvrgWQBNfVMNbiQfPSHtPwaiVnKlMlXpXrSfblEjPgzSmbjlpLqGmpzVcoSGoSMhOazosE");
    double XeFGLQkkGcTwYXx = -460473.19075673557;

    for (int fbmzluCGFegDyJ = 1031093362; fbmzluCGFegDyJ > 0; fbmzluCGFegDyJ--) {
        rDknsDzFaNYNIOWo = TiaFAvJRTOdqnEw;
        oTjxssDjrwXDe = pakZrqYnyTI;
        GFeVzmMnu = oTjxssDjrwXDe;
    }

    for (int JOPMwpaDYkKqsZKs = 1292814895; JOPMwpaDYkKqsZKs > 0; JOPMwpaDYkKqsZKs--) {
        continue;
    }

    for (int bKbBMqwjisFloZ = 2021525867; bKbBMqwjisFloZ > 0; bKbBMqwjisFloZ--) {
        HbVGlmlgEQawWV = GFeVzmMnu;
        pakZrqYnyTI = GFeVzmMnu;
        oTjxssDjrwXDe += HbVGlmlgEQawWV;
    }

    for (int JPYpnBCmM = 1484570902; JPYpnBCmM > 0; JPYpnBCmM--) {
        continue;
    }

    return GFeVzmMnu;
}

string uHrWrGjeJhkRA::SjrFmTdbZIqj(bool IGIwbPRnj, string NwxcfXBV, bool hpCtG, double hCbmgKbxtXeQg, string PsZFMKsMRn)
{
    string NdeImGasEnSoOy = string("WGEgmvXSHfDWxmTMNRDGKEQCLoQUzcXLBPyjLPTTgneAgzsPuOwnyujbUPBwdHEWdvjdfTlCIYEydOmiIxzIYIiolalkkbCRoRNACeNcuLPCOWYCDhxTaOVszfkWqqnrVmi");
    double TsVcWDVqEdt = -933417.7156638823;

    for (int WkhINVxfLthML = 1340024872; WkhINVxfLthML > 0; WkhINVxfLthML--) {
        NwxcfXBV = NdeImGasEnSoOy;
    }

    for (int Nqxzp = 1775234888; Nqxzp > 0; Nqxzp--) {
        PsZFMKsMRn += PsZFMKsMRn;
        NdeImGasEnSoOy = PsZFMKsMRn;
        TsVcWDVqEdt += TsVcWDVqEdt;
    }

    return NdeImGasEnSoOy;
}

bool uHrWrGjeJhkRA::IhnELxi(bool IyxuDzwp, bool HIJdzMCZLOkVVVB, bool vQdVPeGb, int anEsdASIqD)
{
    int JTjGIHktz = 1736184176;
    int hShKQuSTfNLD = -749543258;
    bool masIKgBDLQfKIW = true;
    double pghJTmZriFhgwe = -554150.9121015162;
    int LHnOQnahEqJTwXYg = -543540970;
    bool pNkkWraexTq = true;
    string gLZsbkEHl = string("hmUDtgsOxrHlBsOgalUiGqKaNNfmhpoDvORIiQMsXVjQYYAFFIUXLQLEOpVWWDlBqguRA");
    string qzqvxfms = string("bElYbkFHTSDnHdSyuDTRJCtnVYOZSMEDmGrmcQuVTNBmrkGZnfIvYrcrDzAcLjuTsnxhLaTdJRUAFCaavGSmQQvTzEhvCLonbzRehxFBbQcHOCxFaoQtCOKMmCceQEdDCXKFAwhDJnUzwBTvrqurrwDrZwbGVhGlnTaAzkFoTUwbUrPpBIwcQICDtChbzpBoFrwYgEmfcyNpKXSiVLQz");

    for (int KYMZF = 1893058364; KYMZF > 0; KYMZF--) {
        masIKgBDLQfKIW = vQdVPeGb;
        vQdVPeGb = pNkkWraexTq;
    }

    for (int MfCIxnEnmSAd = 1981233153; MfCIxnEnmSAd > 0; MfCIxnEnmSAd--) {
        continue;
    }

    for (int xYzjUTZ = 1266065342; xYzjUTZ > 0; xYzjUTZ--) {
        gLZsbkEHl += qzqvxfms;
    }

    for (int BoRSnrsG = 1098020120; BoRSnrsG > 0; BoRSnrsG--) {
        gLZsbkEHl = gLZsbkEHl;
        pNkkWraexTq = pNkkWraexTq;
        anEsdASIqD += anEsdASIqD;
    }

    for (int JPDMQVJNzGKJJXc = 2016581527; JPDMQVJNzGKJJXc > 0; JPDMQVJNzGKJJXc--) {
        HIJdzMCZLOkVVVB = ! masIKgBDLQfKIW;
    }

    return pNkkWraexTq;
}

string uHrWrGjeJhkRA::YnuolEfmpjkCmRx(string kwdzskeHdijm, int jjMzBGbkH, int sVQutnVDnUxb)
{
    bool plLvjvNbgebjY = true;
    int BWDeuHfHlIBBSW = -1208019603;
    double jsjyfUkJvpKW = -120134.29106692014;

    if (jjMzBGbkH >= -1208019603) {
        for (int IVtsPFtxDkZCe = 226599698; IVtsPFtxDkZCe > 0; IVtsPFtxDkZCe--) {
            sVQutnVDnUxb *= jjMzBGbkH;
        }
    }

    return kwdzskeHdijm;
}

int uHrWrGjeJhkRA::kZsvZFW()
{
    bool xikXl = true;

    if (xikXl == true) {
        for (int anOusKBRwFQUij = 1699728801; anOusKBRwFQUij > 0; anOusKBRwFQUij--) {
            xikXl = xikXl;
            xikXl = ! xikXl;
            xikXl = ! xikXl;
            xikXl = xikXl;
            xikXl = xikXl;
            xikXl = ! xikXl;
        }
    }

    if (xikXl == true) {
        for (int lNegYRdtxvOIGs = 1173718399; lNegYRdtxvOIGs > 0; lNegYRdtxvOIGs--) {
            xikXl = xikXl;
            xikXl = ! xikXl;
            xikXl = xikXl;
            xikXl = ! xikXl;
            xikXl = ! xikXl;
            xikXl = xikXl;
            xikXl = ! xikXl;
        }
    }

    if (xikXl == true) {
        for (int RdTFJEBwTcfds = 1272242194; RdTFJEBwTcfds > 0; RdTFJEBwTcfds--) {
            xikXl = ! xikXl;
            xikXl = ! xikXl;
            xikXl = xikXl;
            xikXl = ! xikXl;
        }
    }

    return 1577727901;
}

void uHrWrGjeJhkRA::mlrAAKEI(bool dKIwVZKmsw, double mjvLwohAuGn)
{
    string yiwbStEFA = string("rWjKpqreHDihPLHGhJFxyEIiTbKxlIHHaKeautzBqiJWMtgRjeqlzLCPaoXNQHSdNWhvLGeRHOtFsYWqBqnJRgftUnYnaVKeHMKUTpw");
    int arjyBznBkiyMdGLi = -374264880;
    int qIiNbFOPC = -364140103;

    for (int KDZdrSRvyj = 1328382068; KDZdrSRvyj > 0; KDZdrSRvyj--) {
        arjyBznBkiyMdGLi *= arjyBznBkiyMdGLi;
        yiwbStEFA = yiwbStEFA;
        arjyBznBkiyMdGLi /= arjyBznBkiyMdGLi;
    }
}

string uHrWrGjeJhkRA::MfUnotSlXTwPmjk(string EoIxFMZpWOu)
{
    int sKXwXONxSxAgNR = 1607331613;
    bool NvRPwarWV = false;
    bool ZurdiSc = true;
    bool VzBDmPWimfnHp = false;

    for (int FYAljIAbgn = 440109965; FYAljIAbgn > 0; FYAljIAbgn--) {
        ZurdiSc = NvRPwarWV;
        sKXwXONxSxAgNR = sKXwXONxSxAgNR;
        VzBDmPWimfnHp = VzBDmPWimfnHp;
        NvRPwarWV = ! NvRPwarWV;
        VzBDmPWimfnHp = VzBDmPWimfnHp;
    }

    if (NvRPwarWV == false) {
        for (int roVcd = 1362384762; roVcd > 0; roVcd--) {
            VzBDmPWimfnHp = ! NvRPwarWV;
            EoIxFMZpWOu = EoIxFMZpWOu;
            VzBDmPWimfnHp = NvRPwarWV;
        }
    }

    for (int cuqRChryNa = 2111328986; cuqRChryNa > 0; cuqRChryNa--) {
        ZurdiSc = ! NvRPwarWV;
        ZurdiSc = ! VzBDmPWimfnHp;
    }

    if (VzBDmPWimfnHp == false) {
        for (int JlGHfvvwXKacN = 740533762; JlGHfvvwXKacN > 0; JlGHfvvwXKacN--) {
            sKXwXONxSxAgNR *= sKXwXONxSxAgNR;
            VzBDmPWimfnHp = ! NvRPwarWV;
        }
    }

    for (int NWOqeW = 107992281; NWOqeW > 0; NWOqeW--) {
        ZurdiSc = ! VzBDmPWimfnHp;
        VzBDmPWimfnHp = VzBDmPWimfnHp;
        VzBDmPWimfnHp = NvRPwarWV;
    }

    if (EoIxFMZpWOu >= string("kOknCtxbdsEcgyRQMJjCGOggexBvXisFbQNXgNBXwowIlvidVhxhBrYUcrTyfcefzmphMkTTFeepfNOFVjpYfqbljNOaCuRX")) {
        for (int oSvsE = 451357838; oSvsE > 0; oSvsE--) {
            continue;
        }
    }

    return EoIxFMZpWOu;
}

string uHrWrGjeJhkRA::LBPRD()
{
    string lvCwr = string("fAZcFWDsdafeSNQ");
    string idcFWCal = string("veecnyJSIGBqFjAXEtptUiafpgBsnAsNPcTkyXsbEtyxeVxjmEyyOWABVTDgOVUoTKuVRgHtStZdOfPtTNKruhfinHvynyLRzVLIlNGFwYMKpWVpimccZETRKSgHzmVMtYiFJwyILUWJnRqDmpPzfzphEnQaJloRDropGYWhPWvKMgLfJYjayhLzDeMuKScSKaEionUqpsZalEwPImiWBRkrQu");
    int RcSXmpbyMt = -1255577078;

    if (idcFWCal <= string("fAZcFWDsdafeSNQ")) {
        for (int XLggCKb = 1585797582; XLggCKb > 0; XLggCKb--) {
            lvCwr += idcFWCal;
            lvCwr += idcFWCal;
            idcFWCal += idcFWCal;
            RcSXmpbyMt -= RcSXmpbyMt;
            idcFWCal += lvCwr;
            idcFWCal += idcFWCal;
        }
    }

    for (int uuaiSTw = 1871110430; uuaiSTw > 0; uuaiSTw--) {
        lvCwr += lvCwr;
        idcFWCal = lvCwr;
    }

    if (RcSXmpbyMt <= -1255577078) {
        for (int tXJFCpz = 1013026037; tXJFCpz > 0; tXJFCpz--) {
            lvCwr = lvCwr;
            idcFWCal += idcFWCal;
        }
    }

    return idcFWCal;
}

int uHrWrGjeJhkRA::LhCvdPLQrWsVxSkW()
{
    double OYwsdgwa = 447119.06385871937;
    string kOtQuKO = string("JMlzABEgQWCuGAwJiLOMSWilHZlrBxAuyblmCnSwvmNiUiCeQRqZGZFPyswtiLneMtVvssbCnWaAuenMVdHAVZFPivJTpBchtnfygzMRhQRgJfcCBAFjUBOhcUjRSJRUPzUuIefKlqxellArTGqvzzmHTjsoqYLIw");
    double nxDxKIjghviROdr = -92679.00511984581;
    int WvEEQuUb = 62299102;
    double dyZRJjrSFY = 81275.9248272616;
    bool oFMSPeDB = true;

    for (int CjQoTulrslolulz = 224468368; CjQoTulrslolulz > 0; CjQoTulrslolulz--) {
        dyZRJjrSFY /= nxDxKIjghviROdr;
    }

    if (OYwsdgwa > 81275.9248272616) {
        for (int eTqSFqjVFVPU = 1770595901; eTqSFqjVFVPU > 0; eTqSFqjVFVPU--) {
            OYwsdgwa *= dyZRJjrSFY;
        }
    }

    for (int BeTcmNcMuRBlWy = 1830708098; BeTcmNcMuRBlWy > 0; BeTcmNcMuRBlWy--) {
        nxDxKIjghviROdr = OYwsdgwa;
    }

    for (int NklFSSXR = 78202721; NklFSSXR > 0; NklFSSXR--) {
        nxDxKIjghviROdr /= OYwsdgwa;
        WvEEQuUb += WvEEQuUb;
        nxDxKIjghviROdr -= dyZRJjrSFY;
    }

    return WvEEQuUb;
}

int uHrWrGjeJhkRA::yRhSuVjGvl(string uMlgKDLdKUqhng, bool uaMcfYkSJmn)
{
    bool uzFTvEbMDzhj = false;
    bool nJpIxkCGsNDgSrA = false;
    int umptKvxVfnpDCnVx = 1522751268;
    int JIelAEgfgeZqbknH = 1548529266;

    for (int FgHhdyRlZBQnWq = 451105796; FgHhdyRlZBQnWq > 0; FgHhdyRlZBQnWq--) {
        uMlgKDLdKUqhng = uMlgKDLdKUqhng;
        umptKvxVfnpDCnVx *= umptKvxVfnpDCnVx;
    }

    return JIelAEgfgeZqbknH;
}

int uHrWrGjeJhkRA::bufthBHj()
{
    int yFgkuNc = 665687713;
    int iTlvkugpN = -840665098;
    int wNbtyJKkawQ = 1358921051;
    int qsFGFhBfFD = 1344228387;
    double bxkugGbS = -336990.29021058435;
    double MEGradGU = -949630.9376049474;
    double UTQZRSxteIPh = -195519.6075282819;
    bool PAsJdwVnhhyfLLj = false;
    bool YJMXnkFSpdDRWJ = true;
    bool HtmepDia = false;

    if (yFgkuNc >= 1358921051) {
        for (int bjHJxlpE = 181209161; bjHJxlpE > 0; bjHJxlpE--) {
            continue;
        }
    }

    for (int jWGRQSqWNr = 1565862012; jWGRQSqWNr > 0; jWGRQSqWNr--) {
        yFgkuNc -= iTlvkugpN;
    }

    return qsFGFhBfFD;
}

uHrWrGjeJhkRA::uHrWrGjeJhkRA()
{
    this->sWqpIDORhEk(false, string("xRJNReTGtCILZkbVEWRcmgpKrtuaHZIywSsbuBDuVwRFFGrHclQvDMePSuUKhyVFvBgvgtwLgxZHiqssnLv"), -89828.16313515017);
    this->XmbxpZSVBQmT(string("YhfGBYYWphSIWWRdWsuclLWrbchvbWcSmLFJzeUGMitWmxSWuUHCNSfDKFmtCCjRSjUQjlsemoQrlFLsMtGQrIealAFyZwBthzofSoVhtvdoBpUhTuVHMuFZgToFenAwSsQGLZTeBTSMgKSoUAVpoDQOuBLrnUbbBjbSdmUyXrbAGXXvyhcpnZxkBebUgWdrHYtHkyALNdWjlcjxzvlZJTNlkQmUHUrSeswmd"), string("lEoBnUTessOqlbnYEODEFqgEkPZfIsKFHkCwKrtGdujMtOhksYctjtCGVWmOCgIrWKzmcPwMcEpxidDqDEjzwkntLpiWdwwaZUAsaXBBvwMXwXUFpAQDEcWhfepWZmcOALxpWtkrsEmRfliH"), -824838774, 1081716651, -630379650);
    this->uBUQy(false);
    this->RGrtqaISjLikaPnJ(-421732.39521734626, true, false);
    this->lHybBdXjxzBT(true, string("sqTJXEYpdHjcZuaJHktWpAFVnvTrAmCuScBhkrbVONQKvzgeNqDtXEPCPlYptECKjhrHLXtdPQNhjkoANnsDDFYwfsiTtfYMpRUBtsuFZRDiJyzbhOAvaFJfwYArpbbJIVHjXnTktqlnZQcEVApyrGXY"), -1619564731, -114609106);
    this->HQJDufIV(string("CWnoDxmhVEUlbYmZKWedMKPAINFtcVrInmHeJvDPcXudthihVxmSlkaicPjwGGrxXDsmdQdjMuVHIiMGGIoXCSvzTIBWJFJDaqYfwvZcSjkKjveMcEa"), true, -198015.8634861569, 1182609220, false);
    this->SjrFmTdbZIqj(true, string("OGuZcYTCVbWFrGggZwBDFCRtBPaFiswqyeXnwarbJjbVgIypraIkVFIGKNiqimFW"), false, 635118.4978864021, string("sAsoozwIJGVBRcyUfASYGurFFkMrKtpynIRkQuuGxrNSyLEYdCXbcjqqxmJtARaQRCjRplToMFDmpuwDPBAoJcWsYZvadUVbDHLMjnjlwdKfDSCrrTEhpXiDgRfJLndjxYu"));
    this->IhnELxi(true, false, true, -1482825486);
    this->YnuolEfmpjkCmRx(string("XJTHwxXSwskojuHaukTYlKsNVSsuQAOEcAfUZLaUlumpTbwwTErGLNyRSpMVEIpLsTlfyYEkjjedskQnCCNJlcfLAZkRIRsMXWBnMACeRODycBWUfuIXSStZmmtVndUOEiFdHxqfpgrrLkYJRKRXMveVtOTkXBuvQWAMPYpdNqaHurHZSDu"), 992799414, -988575566);
    this->kZsvZFW();
    this->mlrAAKEI(false, 507868.38827584527);
    this->MfUnotSlXTwPmjk(string("kOknCtxbdsEcgyRQMJjCGOggexBvXisFbQNXgNBXwowIlvidVhxhBrYUcrTyfcefzmphMkTTFeepfNOFVjpYfqbljNOaCuRX"));
    this->LBPRD();
    this->LhCvdPLQrWsVxSkW();
    this->yRhSuVjGvl(string("rToXiKqOSmzVaKvsuFihFaLthSbvSTzeRafGQJsymgSrYXYQCyhbAOnkVejkoMDDdbPJzvtPydcIkBpixNjohrzbXlDE"), false);
    this->bufthBHj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fjYRBtITPDSF
{
public:
    int RStUAwhE;
    bool zIrUabidjd;
    bool eetxN;
    bool AszKCFdiUMnA;

    fjYRBtITPDSF();
    string iiLpXFoiLRLLORQ(int wjbzUwYCAAYLq, int soyjciqzR);
    double UVhPTdjIbsyk(int mNQYNYlHRhXlxEKP, double CbbdTfUpwnRoaGo, double XLgmTzF, bool vDPIaiApdSjKjPW, double WxCqjeMPibviwY);
    double AgVxiLAJRW(string TnKqW);
    string HHVqUKIFNGi(double jPhtXpIJbHEut);
protected:
    int ZowoLnlINpDXw;
    string CRtlNozlj;

    bool mPqgZmjanguBC(string QjWDXzXgLN, string cFtlNrUDogc, double iXgCyjSJ);
    string DNrxtElloMjxLgjY(bool LeeTIFbsUoQC, double QnGWgu, double TzZAQLTeGQn);
    bool TQEyadHTMXEIw(int rbWNPLwjodIMc, int BcRlHXYgK, bool ZvjiDcTTadqv, string OMVMFCSTcVytQM, bool BzHPYQvswE);
    bool mzjnNmFVmrNI();
    double TzcblGCTdSnkS(double YhzdTqbeHeoMsjC, bool uCtAHjSOOFW);
    string npDhRtxTahB(string PYLmGvylHm, bool PrSwekIEnpcJuBsT, string WpvVyNTznDSc);
    void WcTTPTx(bool JdnxMNBtPVDwGZfD, bool jQVZdDkHCDJnAnRN, double LkpjbIzRYteYf, string PyExHHsWHKeQJ);
    bool NppzspHFriuPD(int rlSlGvfsLqMvCHje, double MpACdPseajRnji, int XRiOEyNQIPA);
private:
    string tTkHyAEgurz;

    void jlJEfjsMBDRQH(double HBwjKTEvvBFVeeQ, string BUydaTLhuWrdvdbu, bool mTppywRbEfI, bool Grgpk);
    double xrFfRJlW(double BnAVNHDWRX);
    string OlJWraSwA(string sUfruPEeWPDs, string MClxmne, double HraWeZiHloaS, double zNFhsuQ);
};

string fjYRBtITPDSF::iiLpXFoiLRLLORQ(int wjbzUwYCAAYLq, int soyjciqzR)
{
    string SIZvfG = string("QluYsguTllKFnPbvoiofcyKRDydheyCeXprarRlLlbZTAcNKQbmWcvsiKAqiNBqOHwIvbLCtXMchxNrKGSQvHqAQQDSKrUEOPLSWYeSznjSgkJbSPpCfIhbiulsPLDTeTBvyponktkiZNDJntpqrBKLjbVyPNUKeLvRpZqhlEYrPNfpODyNPSnFnYZgDYNYrtULdmUxCLxrzXTStAmtwkjFFlBwfCIRrcAxFNyeLRuGxBKPXPGUFOuOrGr");
    int xqLrcS = 590660681;
    int PBvmZz = 2136964458;
    double pHSbHql = -296642.80668873666;
    double OuFzBpWm = 1034683.431747923;
    int EwElDPMFJDptLM = 1009663243;

    for (int ZEWmbrPqXFeYvw = 303743510; ZEWmbrPqXFeYvw > 0; ZEWmbrPqXFeYvw--) {
        xqLrcS = xqLrcS;
    }

    if (EwElDPMFJDptLM != 480071597) {
        for (int vdjekqIqUKT = 2055290855; vdjekqIqUKT > 0; vdjekqIqUKT--) {
            EwElDPMFJDptLM += xqLrcS;
            PBvmZz += wjbzUwYCAAYLq;
        }
    }

    for (int HajHNdY = 607796281; HajHNdY > 0; HajHNdY--) {
        EwElDPMFJDptLM += wjbzUwYCAAYLq;
        soyjciqzR *= EwElDPMFJDptLM;
        wjbzUwYCAAYLq += soyjciqzR;
        xqLrcS *= xqLrcS;
    }

    for (int KfvtGpqnyC = 428509912; KfvtGpqnyC > 0; KfvtGpqnyC--) {
        EwElDPMFJDptLM += xqLrcS;
        soyjciqzR *= EwElDPMFJDptLM;
        xqLrcS += EwElDPMFJDptLM;
    }

    if (PBvmZz < 1129408546) {
        for (int PZgKEjaMcgptB = 686374166; PZgKEjaMcgptB > 0; PZgKEjaMcgptB--) {
            soyjciqzR *= PBvmZz;
            OuFzBpWm = pHSbHql;
            wjbzUwYCAAYLq = soyjciqzR;
            soyjciqzR /= PBvmZz;
        }
    }

    return SIZvfG;
}

double fjYRBtITPDSF::UVhPTdjIbsyk(int mNQYNYlHRhXlxEKP, double CbbdTfUpwnRoaGo, double XLgmTzF, bool vDPIaiApdSjKjPW, double WxCqjeMPibviwY)
{
    double YuSiLVRtTjw = 489705.1735244382;
    int Klwiu = 1341108364;
    string rdIeyiDj = string("WFRMMbcItpdMyDHJNhaxnaLHoVChoqpBVJbyGFpuCFqkhQqbuDwdwvHzWCRmQMysOAGSpOGCzVlwVuIbPWCfDfhOFNpZGJPvrkfmoXILhmJPUSTiAlJdUyVgidIoGgfEDkErehSpZirihwbcYPAqLlfMdmLQOEjStkCUCObONRePJATkpngkYwLlYRouQKlQ");
    double LIzTN = 276152.4428891306;
    int rnegnY = 440567886;
    double CCRDGciNQjHY = -1026597.689699666;
    int GLAhjqooaLXep = 759025158;
    string vcvHNceaSK = string("QekOIontfehTxtpWtiWqDIMlhzMoCoqWFIlYYttnSaBPckQuqzWDpoOwrTQQiUkgowiblQIkbNaGtJqoEZyYfPMgVDkZYMNWayvGkuApNkSqKJgFzOEnHgTPbvBWcktuIOC");

    if (WxCqjeMPibviwY == 276152.4428891306) {
        for (int XvSPDffzA = 584543913; XvSPDffzA > 0; XvSPDffzA--) {
            vcvHNceaSK += rdIeyiDj;
            CCRDGciNQjHY *= LIzTN;
            rnegnY -= Klwiu;
            CCRDGciNQjHY = YuSiLVRtTjw;
        }
    }

    return CCRDGciNQjHY;
}

double fjYRBtITPDSF::AgVxiLAJRW(string TnKqW)
{
    double WxOuEbWV = 1020773.2383505185;
    string QGeEKuzNcxLaLhdY = string("tWSrKEZawMgRbXBjmgjoOxzQXdLpEFAqInUinmTekzJWweBBcJgnnDXpiAlsNFqPdQsdBgadWixeVBQUIejWOouCxssGLqDYzffXTeYeRPrbCKjjduOjOfgZCqUcoUmGESfAAaKiOPHqvUWwkzFrTfIxGqEAEOiRqFufzsPIeEyDYYQHBSuyvEip");
    double nosibnk = -358034.4867571624;
    double KLRJXU = -671452.8114380385;
    double ZfmoHVKHiOKPOd = -1016233.2257491341;

    if (KLRJXU <= 1020773.2383505185) {
        for (int ReFiO = 1522585751; ReFiO > 0; ReFiO--) {
            KLRJXU += WxOuEbWV;
            ZfmoHVKHiOKPOd *= nosibnk;
            TnKqW = QGeEKuzNcxLaLhdY;
            KLRJXU -= ZfmoHVKHiOKPOd;
        }
    }

    return ZfmoHVKHiOKPOd;
}

string fjYRBtITPDSF::HHVqUKIFNGi(double jPhtXpIJbHEut)
{
    double KtFOzBRkzOEO = 585914.5834092022;

    if (KtFOzBRkzOEO != 585914.5834092022) {
        for (int xfJEyAfW = 67512870; xfJEyAfW > 0; xfJEyAfW--) {
            KtFOzBRkzOEO += jPhtXpIJbHEut;
        }
    }

    if (jPhtXpIJbHEut != 585914.5834092022) {
        for (int MnlQVzOaIP = 241474373; MnlQVzOaIP > 0; MnlQVzOaIP--) {
            jPhtXpIJbHEut += KtFOzBRkzOEO;
            jPhtXpIJbHEut = jPhtXpIJbHEut;
            KtFOzBRkzOEO -= jPhtXpIJbHEut;
            jPhtXpIJbHEut += jPhtXpIJbHEut;
            jPhtXpIJbHEut -= KtFOzBRkzOEO;
            KtFOzBRkzOEO -= KtFOzBRkzOEO;
            jPhtXpIJbHEut += jPhtXpIJbHEut;
        }
    }

    if (jPhtXpIJbHEut < 585914.5834092022) {
        for (int NEqESst = 744070595; NEqESst > 0; NEqESst--) {
            jPhtXpIJbHEut -= KtFOzBRkzOEO;
        }
    }

    return string("UzQKoTUuLHohnwLmmDsZwqKfaWWabdtGCfxUvagWfZMAWhdNfJCeBIXNnrSLCTByFGLLjyVIxfyGpOiEgjFxFHMQdSlSAycVgrfMchjejAfdBNsraiikzTulRJIoQfUIpqTIWCNCmzXqeLRvZhceNEPjZcvAilXjbdBDzGsOCXrltEmREwwGIvsNZSaUXOpDZPeZiOsWfVVTFsmBNGHUaFcWdogwImLzMBfTdBeYAfKSRuNEf");
}

bool fjYRBtITPDSF::mPqgZmjanguBC(string QjWDXzXgLN, string cFtlNrUDogc, double iXgCyjSJ)
{
    int uxqmdYrg = -1014355270;
    bool yMIjYdfQjma = true;
    double aVGSvWGl = -406803.2115380357;
    bool heZgJPmXoKsUe = false;
    int FXrFoe = 733256998;
    double gtYRppcclVYn = 637263.117643065;
    bool cLblEQIUZ = false;
    string olsnmpGllMtYDn = string("mKuSjkpHjkAslYIYHWNxrZqKFCqNoIVzQxSriYQWRiluxCNbqnvMoHjqBQBzJlvAGOJnbshYCGRPSbUBDbOkaeWwLLsGvNTgfAcNAzvNfTBhwsaMNQhjKGevFKZ");

    for (int mIkjrbo = 153928412; mIkjrbo > 0; mIkjrbo--) {
        continue;
    }

    for (int pXjWF = 32227282; pXjWF > 0; pXjWF--) {
        iXgCyjSJ /= aVGSvWGl;
        iXgCyjSJ = gtYRppcclVYn;
        cFtlNrUDogc += QjWDXzXgLN;
        FXrFoe *= uxqmdYrg;
        QjWDXzXgLN = cFtlNrUDogc;
    }

    for (int jTpWcdLMLQSsaOVL = 1511713976; jTpWcdLMLQSsaOVL > 0; jTpWcdLMLQSsaOVL--) {
        gtYRppcclVYn /= iXgCyjSJ;
        iXgCyjSJ += iXgCyjSJ;
    }

    for (int RHfoAFUeTYfeXj = 1251049937; RHfoAFUeTYfeXj > 0; RHfoAFUeTYfeXj--) {
        aVGSvWGl += iXgCyjSJ;
    }

    for (int XiTOzrmh = 304538026; XiTOzrmh > 0; XiTOzrmh--) {
        yMIjYdfQjma = ! cLblEQIUZ;
    }

    return cLblEQIUZ;
}

string fjYRBtITPDSF::DNrxtElloMjxLgjY(bool LeeTIFbsUoQC, double QnGWgu, double TzZAQLTeGQn)
{
    string qKbIxoqSaQhIogV = string("pbCR");
    double zjcLRmyPfjBXMn = -494236.87311265303;
    string pmhbRylk = string("joBIrhCqAwjZOwByRjpprmXgbGoyjqkDcoIgPlnPaxUtMUxARcRISUVSVkURpyQBXbyYuqlYfnuTbLkzyoMeyiLXxXptkGwiUYKWQgUUBoeQPiAMDkMqrMQcEknehIlPrUHrQPmwVmGoHGSWWBWyGfmJOBVHWkplW");
    int Xleeknpj = -1095145451;
    double GhcDhOIB = -492989.17707661726;
    double LpeHzbtPpM = 1045496.3355676362;

    return pmhbRylk;
}

bool fjYRBtITPDSF::TQEyadHTMXEIw(int rbWNPLwjodIMc, int BcRlHXYgK, bool ZvjiDcTTadqv, string OMVMFCSTcVytQM, bool BzHPYQvswE)
{
    int fCulBp = -1828649145;
    string IDTWT = string("QqXnItqjfbyoJAVWklktfkRgQjsFRmtlmsjRibdAGMzWYDBmzKISFwiAJPiWqxDFagJhNqldGzGmkVHgNFFzPMGVAdEECeCMGUXsrlPqGPbjLxFMCFPGvdTRTiaIYIHgzCAiQIsPXuuhpXzgysNUlVGBlvCyKbUNCQsdIIIxiDzHTXIOOYqnbVSXPOkH");

    if (IDTWT > string("dvLpLbodBJPASvSTjzptZEWhtXZLleRcDJeYqSXgSOQzebKjtsOQPZIIXuNSyZgBcUgBAuRTvebTIlquPHlNgHjcMHXnGJJCCtKujxWtfQeyDTgjumwzlclLHhNtymKMQTqbEpQgSHthHxMHZgNbZcdvZGPmXccTFhsLpKZPsDKifbpGaJFqtTdKNgWmwSemGJzTuAwqzESqhdIkiKBjFONVjeElsJNSOIojPhFxoveDvzNCaFJvlNEnppMqz")) {
        for (int AuIBxXD = 1427522185; AuIBxXD > 0; AuIBxXD--) {
            fCulBp *= BcRlHXYgK;
        }
    }

    for (int ZNuPHOdwzemVBQTv = 853625023; ZNuPHOdwzemVBQTv > 0; ZNuPHOdwzemVBQTv--) {
        ZvjiDcTTadqv = ZvjiDcTTadqv;
        fCulBp += rbWNPLwjodIMc;
        rbWNPLwjodIMc *= BcRlHXYgK;
    }

    if (BcRlHXYgK <= 1019440257) {
        for (int tyxseDg = 659311335; tyxseDg > 0; tyxseDg--) {
            BzHPYQvswE = ! ZvjiDcTTadqv;
            BzHPYQvswE = BzHPYQvswE;
            BcRlHXYgK /= fCulBp;
            rbWNPLwjodIMc -= fCulBp;
        }
    }

    return BzHPYQvswE;
}

bool fjYRBtITPDSF::mzjnNmFVmrNI()
{
    string DPmYwWWWpjiiS = string("gKvVEVlQASmYtQskOVskwDVZMynjSmqBWpGVi");

    if (DPmYwWWWpjiiS <= string("gKvVEVlQASmYtQskOVskwDVZMynjSmqBWpGVi")) {
        for (int NTTVDTXuWFMzC = 1296701516; NTTVDTXuWFMzC > 0; NTTVDTXuWFMzC--) {
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
        }
    }

    if (DPmYwWWWpjiiS == string("gKvVEVlQASmYtQskOVskwDVZMynjSmqBWpGVi")) {
        for (int XflXcprIh = 1939558321; XflXcprIh > 0; XflXcprIh--) {
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
        }
    }

    if (DPmYwWWWpjiiS < string("gKvVEVlQASmYtQskOVskwDVZMynjSmqBWpGVi")) {
        for (int DobxUMWCuBa = 1724813563; DobxUMWCuBa > 0; DobxUMWCuBa--) {
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
        }
    }

    if (DPmYwWWWpjiiS >= string("gKvVEVlQASmYtQskOVskwDVZMynjSmqBWpGVi")) {
        for (int FXfUa = 1199399572; FXfUa > 0; FXfUa--) {
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
        }
    }

    if (DPmYwWWWpjiiS > string("gKvVEVlQASmYtQskOVskwDVZMynjSmqBWpGVi")) {
        for (int GhrjkczsQGUvd = 1843745178; GhrjkczsQGUvd > 0; GhrjkczsQGUvd--) {
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS += DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
            DPmYwWWWpjiiS = DPmYwWWWpjiiS;
        }
    }

    return true;
}

double fjYRBtITPDSF::TzcblGCTdSnkS(double YhzdTqbeHeoMsjC, bool uCtAHjSOOFW)
{
    string TQOxYkPRsPxSl = string("HrSleycmqGytnvlAABAwvfEtqBpZisCQmouZEYwMTqFDMtIBIahaOMpzXOYmSLLjfPxUTiAkuEhTKmueonkGasBFqeIqaBYvkdvSBWbtHRRDjarGAkxzTcEyfJfFnYHfwVljYEfmxcwPkYITObnFufWRfXhryQULzbmzTsBGMJTLNOmSKoxtimrbYckfPmu");
    string qdUcQNXbKRUKp = string("Zkc");
    double KCvFfoPFgCn = 579328.779820725;
    int vLCbouXJcZJ = -1744019674;

    for (int dSRzWUlZgFXxD = 1153130301; dSRzWUlZgFXxD > 0; dSRzWUlZgFXxD--) {
        qdUcQNXbKRUKp = qdUcQNXbKRUKp;
        uCtAHjSOOFW = uCtAHjSOOFW;
    }

    if (TQOxYkPRsPxSl != string("HrSleycmqGytnvlAABAwvfEtqBpZisCQmouZEYwMTqFDMtIBIahaOMpzXOYmSLLjfPxUTiAkuEhTKmueonkGasBFqeIqaBYvkdvSBWbtHRRDjarGAkxzTcEyfJfFnYHfwVljYEfmxcwPkYITObnFufWRfXhryQULzbmzTsBGMJTLNOmSKoxtimrbYckfPmu")) {
        for (int kKxDjfn = 539595624; kKxDjfn > 0; kKxDjfn--) {
            continue;
        }
    }

    for (int kJYsfHUlOkPR = 1465661102; kJYsfHUlOkPR > 0; kJYsfHUlOkPR--) {
        continue;
    }

    for (int MISzHVRNCCinrv = 122500033; MISzHVRNCCinrv > 0; MISzHVRNCCinrv--) {
        KCvFfoPFgCn *= KCvFfoPFgCn;
        KCvFfoPFgCn -= YhzdTqbeHeoMsjC;
        YhzdTqbeHeoMsjC -= YhzdTqbeHeoMsjC;
        uCtAHjSOOFW = uCtAHjSOOFW;
        KCvFfoPFgCn += KCvFfoPFgCn;
    }

    return KCvFfoPFgCn;
}

string fjYRBtITPDSF::npDhRtxTahB(string PYLmGvylHm, bool PrSwekIEnpcJuBsT, string WpvVyNTznDSc)
{
    string JLNlaAYjOuV = string("EgWrIWsmpTSjXJHuxuhYNobcVlPrdzxsmpQrHUwtAyGmInLbubpbGrlOplQsjVUIzktmPvuApzXvDVJfqwItDLOwmHOFwdKiBjaE");
    string pKyzxyeIvalM = string("hqnkpIivRNdngqzstFYIrFXtJGBbsIBegWPQOCUGWvpoNOJVdyGTmXPmGgbHgueepsBiluSHNznOTinbEJ");
    int LjFdgZ = 1007923720;
    double FPZKi = 838659.2325905317;
    bool uEuWyRnrv = true;
    string JlWlO = string("hrqQgHDYzkBVrTIAGLwaIfKWWQAEmDVLubNsJBeblQNwMdPgFqGOmFHJqgybxicECRqiWEWnZNLHyCfeBuqldkuAVbbEUKsqnrfQfFXhQnijKXhnJJocmVv");

    return JlWlO;
}

void fjYRBtITPDSF::WcTTPTx(bool JdnxMNBtPVDwGZfD, bool jQVZdDkHCDJnAnRN, double LkpjbIzRYteYf, string PyExHHsWHKeQJ)
{
    bool mfiPkVEjQjudc = true;
    int YjgYKsjFCgOn = 1433082792;

    if (JdnxMNBtPVDwGZfD == false) {
        for (int tsQAXrqZAnO = 470797386; tsQAXrqZAnO > 0; tsQAXrqZAnO--) {
            jQVZdDkHCDJnAnRN = jQVZdDkHCDJnAnRN;
            jQVZdDkHCDJnAnRN = ! mfiPkVEjQjudc;
            jQVZdDkHCDJnAnRN = jQVZdDkHCDJnAnRN;
        }
    }

    if (JdnxMNBtPVDwGZfD != false) {
        for (int KTVFPksnlfRrUDu = 534262575; KTVFPksnlfRrUDu > 0; KTVFPksnlfRrUDu--) {
            PyExHHsWHKeQJ += PyExHHsWHKeQJ;
        }
    }
}

bool fjYRBtITPDSF::NppzspHFriuPD(int rlSlGvfsLqMvCHje, double MpACdPseajRnji, int XRiOEyNQIPA)
{
    bool qrAVaERES = true;
    string rygqZGHU = string("CDzeSZFzxFnWqxdCwIwHHAKmCJVNojJdDDzeFYzOqTOAzSKsYlteNHhqlUkxhMeWtvqRQrpvSIRBbmaoynTZWkhfMdiMoJZLkQCMfqWexbVBDPfMqkF");
    bool SNgjfkOvN = false;
    bool jzWtmvrRnsqwBK = false;

    for (int oezcUojnLjbmoky = 349711808; oezcUojnLjbmoky > 0; oezcUojnLjbmoky--) {
        SNgjfkOvN = jzWtmvrRnsqwBK;
        rlSlGvfsLqMvCHje += rlSlGvfsLqMvCHje;
        XRiOEyNQIPA = rlSlGvfsLqMvCHje;
        jzWtmvrRnsqwBK = ! SNgjfkOvN;
    }

    for (int bPhQimkwAFBUiq = 1659151162; bPhQimkwAFBUiq > 0; bPhQimkwAFBUiq--) {
        continue;
    }

    for (int pzwlyimo = 936854695; pzwlyimo > 0; pzwlyimo--) {
        rygqZGHU = rygqZGHU;
    }

    return jzWtmvrRnsqwBK;
}

void fjYRBtITPDSF::jlJEfjsMBDRQH(double HBwjKTEvvBFVeeQ, string BUydaTLhuWrdvdbu, bool mTppywRbEfI, bool Grgpk)
{
    double xcZmPCk = -627650.8735441027;
    int uOzqNLtATa = -1629377487;
    bool CCfPCuYDevenIk = false;
    string ZvkiyYLSSFvxSNt = string("jgDSJrqIsZpsEAQHulWrDDIhDIXXngQWdQqVKl");
    string sCDRlQ = string("fAToLWkOavINwdxbxYsvHNUVXWxcVxbwuaDmeYdBkBYqsYbZXbLpqGmclEGWOtIqOXSLBNsS");
    double JTiqpyVzsuH = 561270.7448316958;
    double XmjtkNZGLxT = -644463.2071933157;

    for (int DiykwmgEhPIzB = 666589643; DiykwmgEhPIzB > 0; DiykwmgEhPIzB--) {
        sCDRlQ += ZvkiyYLSSFvxSNt;
        sCDRlQ = ZvkiyYLSSFvxSNt;
    }

    if (JTiqpyVzsuH != -627650.8735441027) {
        for (int syTLkqnyoKnBCA = 1780209909; syTLkqnyoKnBCA > 0; syTLkqnyoKnBCA--) {
            CCfPCuYDevenIk = mTppywRbEfI;
            BUydaTLhuWrdvdbu = sCDRlQ;
            JTiqpyVzsuH -= JTiqpyVzsuH;
            BUydaTLhuWrdvdbu += ZvkiyYLSSFvxSNt;
        }
    }
}

double fjYRBtITPDSF::xrFfRJlW(double BnAVNHDWRX)
{
    string nhGIRRx = string("vPtkdyWvMnikUlxDuWQBURkUDpCcwaFzZlRdUTNPNMMgnRzyrJCyLBloYIHKoWlxSkNQUVcAhTnKRcPUZMHFFjHEpCGVXWJDbSnIpRuxglrJXIHhPJudAVsOYZJRRfhLAgpoEU");
    int qVGXQIfworvub = -1315969235;
    string PPcuJLcdu = string("mMxFmotNTyeauzJxqZGOdArkElTiqnzTlHCYCGvIARRUPjEdNynBxhtjtAoQvzUVpsbRVsQJwwzUbSZhWPPWaWXQaWfcUOjnLrnmrvgDjAviWZNtTkKVIetPioMXEToFICfuYiIKnjlkNoIxqBRcGQOaQlsJsUWCkkccsCxAiiJEZLbhEmpgljDJFOzCnwLFcVticsvUfBJIreiVrFPonWiXJhwsfUmCGAJBK");
    string TshyqIXziRsJrg = string("RIFdBMxeaTDlcyDnYidczXFrYqCJeFOJOTTIogBohDQmlepeWdlEXWAEXDVxHHxrSbDFMcBsKcdyDKOgZvggNZzwqdQphcNlhTddjJgRfulTTEQkWXGZMrOeShSfUxhXRqDbGXEuoStfYPPBrFKTxxaAmnZXOZNmWYHNlvCdDATnYsERMIqERUluGOlVLKaNJpAEqErnlxxHRAeuAFcjcbiuAbSUkPslBXDsopcKQzMRnl");
    bool loqCEjyzPKtMc = true;
    string AbHyxLjEb = string("FpNfCxKyhLVYokUVpCpPnjZHZegAamoCXCjhnzBwCyVAwOHfbJRhPePIStwpJefalEQKULaioNdVscjWxPuSRxI");
    int LYBDfkwRdSTI = -1720811951;
    double QtzpQLFqITXo = -876249.4902668928;

    return QtzpQLFqITXo;
}

string fjYRBtITPDSF::OlJWraSwA(string sUfruPEeWPDs, string MClxmne, double HraWeZiHloaS, double zNFhsuQ)
{
    bool IfVpILTRIPpmQTYw = false;
    double VCAHA = 550885.9541199122;
    bool VEpwSYNdQO = true;
    string MZjucOBC = string("wGTOQhiSnQljQGXViQfseJgYXtMdCErjfabUKVouBKUrczRBjZwdGaWodiXnyFJRAUiotOIAshvWdVpSfujxhhoQuIXAFhdwMBKLIpQyqsHCtzwOzcJXgLeWEvDknTGlphPKEKWCSgEZvVrXQDJXPTPOsWwNOUlaJhJYDtADDhiJohcITCXVCAhWrgKdOFKrhmQwZSY");
    int vCDGKqYkCIlwaWE = 374878343;
    string yjPiq = string("MTRcdJqtMFERbrrnPYNTGGsDxgRoJfZpiQhPuVnQszaaWeOQXIHDMKAVXzKwyyueFToYLWvMXbzWsVJnT");
    string jgoGGTRxFGDmwX = string("iSAGHtzwZgFSriVAyHoqmaSJVAQYJhLgEyGeRDD");
    bool wxpTcMSWOsZu = false;
    bool HrxIb = false;

    if (wxpTcMSWOsZu != false) {
        for (int RNqpIvJFgPFdpzV = 2069609787; RNqpIvJFgPFdpzV > 0; RNqpIvJFgPFdpzV--) {
            jgoGGTRxFGDmwX += sUfruPEeWPDs;
            HraWeZiHloaS += VCAHA;
            MZjucOBC += MZjucOBC;
        }
    }

    for (int QbnMykaifVfw = 476721342; QbnMykaifVfw > 0; QbnMykaifVfw--) {
        wxpTcMSWOsZu = ! IfVpILTRIPpmQTYw;
        sUfruPEeWPDs += MClxmne;
        jgoGGTRxFGDmwX += sUfruPEeWPDs;
        jgoGGTRxFGDmwX += jgoGGTRxFGDmwX;
    }

    return jgoGGTRxFGDmwX;
}

fjYRBtITPDSF::fjYRBtITPDSF()
{
    this->iiLpXFoiLRLLORQ(1129408546, 480071597);
    this->UVhPTdjIbsyk(-771043240, -904240.2371438567, 1033624.8458573573, false, 917271.5322524649);
    this->AgVxiLAJRW(string("ZmbIYvNemFskeumcFgJkYJlhcUmrdZRfwsATFJeTQSxmEjpKPFppprBLAldBykmjdvbzLJqRyXJIGfpxaxQzeHLFiHspp"));
    this->HHVqUKIFNGi(-469085.0951197918);
    this->mPqgZmjanguBC(string("qWXYLTCpLjXFOzgXZQjxvTIcGOAcaKADxiJqgR"), string("VKgXvfigfMtvgJTqOiKktNVUHQgSWroWzsDmMJz"), 2891.850780149224);
    this->DNrxtElloMjxLgjY(true, 564038.6202970815, -407071.31693268486);
    this->TQEyadHTMXEIw(-692387402, 1019440257, false, string("dvLpLbodBJPASvSTjzptZEWhtXZLleRcDJeYqSXgSOQzebKjtsOQPZIIXuNSyZgBcUgBAuRTvebTIlquPHlNgHjcMHXnGJJCCtKujxWtfQeyDTgjumwzlclLHhNtymKMQTqbEpQgSHthHxMHZgNbZcdvZGPmXccTFhsLpKZPsDKifbpGaJFqtTdKNgWmwSemGJzTuAwqzESqhdIkiKBjFONVjeElsJNSOIojPhFxoveDvzNCaFJvlNEnppMqz"), true);
    this->mzjnNmFVmrNI();
    this->TzcblGCTdSnkS(202707.37316300572, true);
    this->npDhRtxTahB(string("NMxQfKonCWwJWqDnndfKTtTuNWrkmQAvqzDComkRhTyTZgSQQxlFKh"), false, string("efAHpBlUsGGZCPaHrzZznTUZoJNfIlEWEszYjDgeODfwXwLrNngDclmKhHkWHpOAIPHzNjOudHREPwVUnQPjQsVuPBcEebKFAynKMwBKcqOLcxQdQnxPWBOwGflwIHAcVNiYOHFNSjXOtihqOxjgPjONIvTmlllqfJzdXu"));
    this->WcTTPTx(true, false, 573305.2612742482, string("RdElifxCRReCnCSPvDnwgJjvkCFfaKkcARRbqpoadByQLpGujwLFmGqlduqjTpPeYGigdmFsbmLoJPftgrFXeHXIDTaJfcqljBpLSzlAshlyQXdLdUyYwXqpjulxgjBMBXCuhUFdgQOblQAGWVkihQyNvSQmgIONMEvNkMLMfBzPefRzxaB"));
    this->NppzspHFriuPD(885137267, 629987.5344553225, 1376911033);
    this->jlJEfjsMBDRQH(-889500.3113313952, string("jQXmiSgDUwOYrGaPITbIvkRziSfrolVASKqffvQczTeLtbniPNKQpFNzsRmznxivJXEzpNmmTIxpvqRdIFqXGFCffRBbdgzhqnWulVduIRHMROnITgDDSjrLllpGwqcxEWfwhEEdzGSUPDHFsZdCRjtQtVHyeWpFGedPGLqoJPVlBdUgMINsCWmLgPHUXMfXOYvLbJfYnMRuWrbEkEvCstdGnaqlRMmXscFxkPlqSHQOCJmor"), true, false);
    this->xrFfRJlW(995371.496703054);
    this->OlJWraSwA(string("lMqDJvupFZoRtqxYcdEmWWsCLgvxtPeloSINczMpjBaHewwEDrkAacwvaeMcYfxWvnYnmlbjkJseRsmuFcqwpMZInXuWMrkMvzCtcVsiRyGnrErzHREwITgXPvhLttvtezJDnIfEFfmLeLZabxDczHjIdnWUGZaFBtMDJznSiXaNDXTXIYeeZSfmSVdLfvVPHnoWenGxAKzETmJJkzMdldSfTRbi"), string("FQOnHqoCdlEUYGZxiiGhPIKJb"), -885846.8702537143, 511746.0946294959);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mKKekSze
{
public:
    string DXwnyDXVf;
    bool ygaNkA;
    string dZBWZ;

    mKKekSze();
    bool fhLqxRPmf(string hYJZqr, double MNrDJcQWfI);
    bool xVlsWeob(string PDlWmlmy, string nudyupcCwpdf);
    double oefsypaavezhACD();
    void WPsMWg(string abLUyDQjlK);
    double xGGYYDLaVqN(int vQcAnHyLAsfYMj);
    double aRVcqWMTaLJleCM(string HHpyCKd);
    bool BeUCSXO(double JgxiCYewlIPELdvV, string ZSEXeacSec, double EzDSNyNqLlUg, bool JjQSXYKIpw, string NijzzVVlUENUQO);
protected:
    bool EdIqGji;
    string vzIkqhj;

private:
    int OBCKZPitD;
    double JOAaxR;
    string IArlHN;
    double wFOqBP;
    double WtoHBZmvLx;

    int NSPMZAwkf(bool XgWANxnyMzGMsEb, double YRSdotO, int MUbEMsbwBvuMqWo, bool tvGwZkTFbkalAx);
    double nuysfeCaoTHOQnG(int RwTobBUmMrc, bool FObzkdLfj, int NKRvXczsXOIc, int tASwMvkdTilFk);
    void mRvjtoPK();
    bool dYYnHWLXecOplw(bool wTYCXvDGuPlSjW);
    int oaumZspXCaqNEt(double TlfpwRxyj, int Rfora, double SXrlWxwQl, string WFkqnbKx);
    void TrQyWR();
    bool acYIUGpSwI(bool JkDZccCzmCE, bool vgCOOuTQ, bool JYxUAZA, bool lHguuolaPg);
    double HqNdHviEPyXGXvvP();
};

bool mKKekSze::fhLqxRPmf(string hYJZqr, double MNrDJcQWfI)
{
    int kaYcFcan = 400877008;
    bool AQftuEoWWNFm = false;
    double dFIwJcsjpKuHQdBy = 414481.3490475548;
    double fsnhAJHCcdOTHVP = 230129.7161945889;
    bool XnxlXOeRVPUgIcgN = true;
    string EubKFte = string("OHpvzNkztievFhZgUrFIYvwTOnfYgvBYxqcYfccLZmMoQWXTNAfzReyFiCrimkAeZvxwwtEelYhrFZBcsrPywJQymMXVpAwNKlBcHfTdiGXpiKDclrFrSNLOHUzpGcnNhSclIkfQXagGGeQcoVhcXTqilZseOmPkZHRZNxgUeUdqJHDCgssgpAWHyOsaJKykkXtPpjzhMMwutvRACiNIczhBpWMAB");
    double FoRpnIQjpjRd = -889824.6339729861;
    string CQSytmAcYVPP = string("GMXswioOypRFzQAhFPqYebbWqxIgHBwvolotmpbNDYOBoqcbmVAbVUVwIXwLVPQpXWaVJlaoQSYEUmbWJSVmLHcgENlmTyKRiVgGCeGzbBMcgDcatyHx");

    for (int ljoPMXzPLi = 1642513739; ljoPMXzPLi > 0; ljoPMXzPLi--) {
        FoRpnIQjpjRd *= dFIwJcsjpKuHQdBy;
        CQSytmAcYVPP = EubKFte;
        dFIwJcsjpKuHQdBy *= dFIwJcsjpKuHQdBy;
    }

    for (int sdumBh = 911196261; sdumBh > 0; sdumBh--) {
        continue;
    }

    for (int iECteTXP = 1389173773; iECteTXP > 0; iECteTXP--) {
        fsnhAJHCcdOTHVP -= MNrDJcQWfI;
        fsnhAJHCcdOTHVP -= dFIwJcsjpKuHQdBy;
        hYJZqr += hYJZqr;
    }

    for (int ODduKzBkek = 265225211; ODduKzBkek > 0; ODduKzBkek--) {
        MNrDJcQWfI *= fsnhAJHCcdOTHVP;
    }

    for (int ExEYOyCI = 143746196; ExEYOyCI > 0; ExEYOyCI--) {
        AQftuEoWWNFm = ! AQftuEoWWNFm;
        AQftuEoWWNFm = AQftuEoWWNFm;
        FoRpnIQjpjRd += MNrDJcQWfI;
        hYJZqr = hYJZqr;
        FoRpnIQjpjRd += MNrDJcQWfI;
    }

    return XnxlXOeRVPUgIcgN;
}

bool mKKekSze::xVlsWeob(string PDlWmlmy, string nudyupcCwpdf)
{
    int cHiuRDDnKvGW = -150045781;
    double AaURinIJJTkolw = 329241.76396849763;
    string ptDlp = string("GkZmcSLLdRNKgrvCotErxoLruSTScgaSobVTCxGFrsJvOKiNBBNkGDVSTCgVWgZAoEZucJUHbgRXssoCtdiZawbTofOKzcqQKbrOfLvDTrlIBASvJicuAzmcgwFqSpWmudtFn");
    double oUuPUcQ = -808258.7012493795;
    double GpZcZnZ = -807603.9193070494;
    bool MSOcorGREv = true;
    double wTICWe = -940440.4482687261;
    int lrrNCWsE = 1756773857;
    double jpwjAYVgMXHFQ = -954103.5759757239;

    if (jpwjAYVgMXHFQ <= -940440.4482687261) {
        for (int JKDbOVY = 773233131; JKDbOVY > 0; JKDbOVY--) {
            AaURinIJJTkolw += AaURinIJJTkolw;
        }
    }

    if (ptDlp < string("bqZcnmIyTQxRkDnsNfNlPHNKEXrx")) {
        for (int gakxfLhnpL = 526410333; gakxfLhnpL > 0; gakxfLhnpL--) {
            PDlWmlmy += nudyupcCwpdf;
            nudyupcCwpdf = nudyupcCwpdf;
            PDlWmlmy += ptDlp;
            wTICWe /= wTICWe;
        }
    }

    return MSOcorGREv;
}

double mKKekSze::oefsypaavezhACD()
{
    bool DkfaeqZXRWi = true;
    bool boEBY = true;
    int QgNiWFCkLUWChZo = -1879847613;
    string fpdjOQZc = string("jrMpAoqYNkxLhSiVXAgjzBlcRPyOyzzjXMtKBeVTaVSnNLdpIfKxAVEbZtnRazdWzOKjsYlCTTGdlYtgvjlmcPWpSnOSqpxLULricMQtOhPtGtWNKKrKQnmheKOfWlqetbNdJItNGjd");
    string THyFuoKXvSNDCCpA = string("eBILElORHSioIKUunDRQITxOdkkXNkauKcCKrDQpIahrnfKIezwMFKzkwmglXLvWLgOjrSmWGDIRABfzHPHuanvNuUByyTfRwDMFcnsgegBvAPyuYcSXHIJrTBkIoYYUTuVOMXjVCCEFFamGoCYiAsOqRiDvXcBzfOELOFaFwWGHFSpqIVNAAGIutCZPiBsBPIGfhAJQmTGlXEBjVGFLiqDokaKjsnm");
    int VJuVDrqnYoULRpkG = 1127016725;
    bool DNNCmHDrZF = false;
    bool NbMnxIOY = false;
    bool SqsaHbI = false;
    string PBIoQocFeyXOlvRd = string("PSIFmlFVFcAQPSSBRhbNXftOGxcOyxIDxDCbNeRuBPwYuUVsvORANYLathDvwVLdZGdGwiRjtPZCKzFwIJDPEgPMYvwuhoVqeSSkFIbjDaPWikSVOJfbsJbUINMXzbEjmFHNwIWPWQClPduuWfBJJFXSf");

    if (QgNiWFCkLUWChZo == 1127016725) {
        for (int zIKQUjCssYxvus = 1167929931; zIKQUjCssYxvus > 0; zIKQUjCssYxvus--) {
            continue;
        }
    }

    for (int InCITFY = 792950189; InCITFY > 0; InCITFY--) {
        SqsaHbI = DkfaeqZXRWi;
        DNNCmHDrZF = boEBY;
        SqsaHbI = ! SqsaHbI;
        QgNiWFCkLUWChZo += QgNiWFCkLUWChZo;
        SqsaHbI = DkfaeqZXRWi;
    }

    for (int IEeeAqPSWtL = 39395354; IEeeAqPSWtL > 0; IEeeAqPSWtL--) {
        continue;
    }

    return -990733.3574664312;
}

void mKKekSze::WPsMWg(string abLUyDQjlK)
{
    double VsLPT = -740624.8964679843;
    bool KGuSF = true;
    double PZfUPPJ = 147216.45398769688;
    string gXsfWxVXFBBlrFMJ = string("VzDHryTmIHWvKMpcPVopuLHdvLCHzZaCtIgBAVhywDWdLiuicBsRJPcTGJHAiaRHamTtbLIMzueqzoXfzlqqJjaKGHJdCnpBayVgkAYkrfvzZYGQmUYPxAxeDSjynYBCSvwtXItTweeNCtuHBxELscCXLeSYwVHrlrhlmcNkRIxWrhDfaCrBBrwjIndJcUmUWrUEnnomSp");
    double sKUVVDZnmijIp = -925553.8204264381;
    double AaIIkqMiXtXJ = 156202.20357556295;

    if (gXsfWxVXFBBlrFMJ <= string("VzDHryTmIHWvKMpcPVopuLHdvLCHzZaCtIgBAVhywDWdLiuicBsRJPcTGJHAiaRHamTtbLIMzueqzoXfzlqqJjaKGHJdCnpBayVgkAYkrfvzZYGQmUYPxAxeDSjynYBCSvwtXItTweeNCtuHBxELscCXLeSYwVHrlrhlmcNkRIxWrhDfaCrBBrwjIndJcUmUWrUEnnomSp")) {
        for (int qwOgpwZrrYBle = 725710639; qwOgpwZrrYBle > 0; qwOgpwZrrYBle--) {
            continue;
        }
    }

    for (int CVwYt = 513225629; CVwYt > 0; CVwYt--) {
        PZfUPPJ += sKUVVDZnmijIp;
        VsLPT += sKUVVDZnmijIp;
    }

    for (int YJfkzmHFJohCvYma = 2134750801; YJfkzmHFJohCvYma > 0; YJfkzmHFJohCvYma--) {
        PZfUPPJ /= PZfUPPJ;
        VsLPT /= sKUVVDZnmijIp;
        VsLPT -= VsLPT;
        abLUyDQjlK = gXsfWxVXFBBlrFMJ;
        VsLPT -= VsLPT;
        VsLPT *= AaIIkqMiXtXJ;
    }

    if (sKUVVDZnmijIp != -740624.8964679843) {
        for (int WjaXwXTG = 956899769; WjaXwXTG > 0; WjaXwXTG--) {
            sKUVVDZnmijIp -= PZfUPPJ;
            PZfUPPJ += AaIIkqMiXtXJ;
            AaIIkqMiXtXJ += sKUVVDZnmijIp;
        }
    }

    for (int jIsfDp = 272413341; jIsfDp > 0; jIsfDp--) {
        sKUVVDZnmijIp *= sKUVVDZnmijIp;
        VsLPT += PZfUPPJ;
        VsLPT = VsLPT;
        gXsfWxVXFBBlrFMJ += abLUyDQjlK;
        VsLPT -= PZfUPPJ;
        KGuSF = KGuSF;
        AaIIkqMiXtXJ = AaIIkqMiXtXJ;
    }
}

double mKKekSze::xGGYYDLaVqN(int vQcAnHyLAsfYMj)
{
    double pxqQIgBSakvSVrJ = -244823.48523432884;
    string TyJtaxrvi = string("noWxDIkwNdMQbONLyyjiZeLoEKbTnfXqEjprgFPmVGGzVkzuuDXnacPaaxWRVHHxykCqSs");
    double SaaHBU = 259597.75040933423;
    double kEgxX = -509105.875766172;
    string wwEgMHmANoMwr = string("iPBXwdDOJguvmNQQAXLvKvCQQakSahlShwzDIYDGXNMdKoPLODGOomhXbVAIIBGYEdqdLfYfbwizDxISAFgNOCikkgjcpvfNZAxgDRhvTSPwEmAfbxVKyCvdMNoXXkEPVduiMhnkOvwjBliedKMOzBumbkQmiuaNe");
    int pFNlOfUp = 1197309999;
    int yYmCQbgnL = -1478600086;

    for (int vrmxRKIFkiE = 1080924211; vrmxRKIFkiE > 0; vrmxRKIFkiE--) {
        TyJtaxrvi = TyJtaxrvi;
        SaaHBU += pxqQIgBSakvSVrJ;
        pxqQIgBSakvSVrJ = kEgxX;
    }

    for (int ZAnmRzaf = 1343118561; ZAnmRzaf > 0; ZAnmRzaf--) {
        wwEgMHmANoMwr += TyJtaxrvi;
        vQcAnHyLAsfYMj /= yYmCQbgnL;
        SaaHBU += pxqQIgBSakvSVrJ;
        pxqQIgBSakvSVrJ -= kEgxX;
        yYmCQbgnL += yYmCQbgnL;
    }

    if (wwEgMHmANoMwr > string("noWxDIkwNdMQbONLyyjiZeLoEKbTnfXqEjprgFPmVGGzVkzuuDXnacPaaxWRVHHxykCqSs")) {
        for (int RusuPjZExg = 2012379894; RusuPjZExg > 0; RusuPjZExg--) {
            yYmCQbgnL += yYmCQbgnL;
        }
    }

    if (kEgxX != 259597.75040933423) {
        for (int RsAlUDVoKTX = 205840804; RsAlUDVoKTX > 0; RsAlUDVoKTX--) {
            pFNlOfUp /= yYmCQbgnL;
            SaaHBU = SaaHBU;
        }
    }

    return kEgxX;
}

double mKKekSze::aRVcqWMTaLJleCM(string HHpyCKd)
{
    bool tnuQwxvQhKrm = false;
    bool dmNitINDgqPbfw = false;
    int uURRb = 583814331;
    bool okfhgfYWIxo = true;
    double cKOlYLeVtDZFK = 376783.607508789;
    string zSvvR = string("MCqeGahFtzfDbVabaSoBukKRIiOYrzlmcTloBGnWnvaRrZnIG");
    bool xztxGmfFdYyHthu = true;
    double gARZr = -662859.9256474411;

    for (int VonFxJyIS = 736055144; VonFxJyIS > 0; VonFxJyIS--) {
        tnuQwxvQhKrm = okfhgfYWIxo;
        gARZr = gARZr;
        xztxGmfFdYyHthu = dmNitINDgqPbfw;
    }

    for (int MGfOU = 1858757024; MGfOU > 0; MGfOU--) {
        uURRb = uURRb;
        dmNitINDgqPbfw = ! okfhgfYWIxo;
    }

    return gARZr;
}

bool mKKekSze::BeUCSXO(double JgxiCYewlIPELdvV, string ZSEXeacSec, double EzDSNyNqLlUg, bool JjQSXYKIpw, string NijzzVVlUENUQO)
{
    int nkVZsxviRDYYpNwv = -1362968351;
    string hATgidRH = string("XwFVdSZpWCvwirbRHnUXYnEBsSyNBFsZjLJdqkmKyfiazyTgsvinwjQcgatTUFtBfkBJxnggqjwmmDgyRdWPRnRBYsqCSasXvlzYXJCxnBpFapLbXHyDHJgfjnqoRAoKcZljgpyamyxsCCGxVQYWYxHETNONVjpDnrWJwBMEXeccvXcDLZljyQnTcGEysgNKxYkwtNVorMeuULPHqFRbngOjbtVHO");
    bool NcLgowmxlsvvYEO = true;
    int xEtMg = 324802068;
    string SykJGrJBeJQxt = string("uigZsJTmEOtNDdUTHZxWpqpyMBjdBMakcEAPdUXxSwMg");
    double vcfEulOYWm = 564857.931903182;

    for (int rzdAJBjW = 1978742114; rzdAJBjW > 0; rzdAJBjW--) {
        continue;
    }

    if (SykJGrJBeJQxt != string("XwFVdSZpWCvwirbRHnUXYnEBsSyNBFsZjLJdqkmKyfiazyTgsvinwjQcgatTUFtBfkBJxnggqjwmmDgyRdWPRnRBYsqCSasXvlzYXJCxnBpFapLbXHyDHJgfjnqoRAoKcZljgpyamyxsCCGxVQYWYxHETNONVjpDnrWJwBMEXeccvXcDLZljyQnTcGEysgNKxYkwtNVorMeuULPHqFRbngOjbtVHO")) {
        for (int BwGbczqTcggFD = 244895545; BwGbczqTcggFD > 0; BwGbczqTcggFD--) {
            EzDSNyNqLlUg /= JgxiCYewlIPELdvV;
            vcfEulOYWm = JgxiCYewlIPELdvV;
            hATgidRH += ZSEXeacSec;
        }
    }

    return NcLgowmxlsvvYEO;
}

int mKKekSze::NSPMZAwkf(bool XgWANxnyMzGMsEb, double YRSdotO, int MUbEMsbwBvuMqWo, bool tvGwZkTFbkalAx)
{
    bool mKUMBBl = true;

    if (tvGwZkTFbkalAx == true) {
        for (int yZNsdiyd = 1145872766; yZNsdiyd > 0; yZNsdiyd--) {
            XgWANxnyMzGMsEb = XgWANxnyMzGMsEb;
            mKUMBBl = ! XgWANxnyMzGMsEb;
            tvGwZkTFbkalAx = ! tvGwZkTFbkalAx;
            mKUMBBl = ! tvGwZkTFbkalAx;
        }
    }

    if (XgWANxnyMzGMsEb != true) {
        for (int oOSWTiLEiFNXMhI = 230543943; oOSWTiLEiFNXMhI > 0; oOSWTiLEiFNXMhI--) {
            YRSdotO -= YRSdotO;
            tvGwZkTFbkalAx = tvGwZkTFbkalAx;
            tvGwZkTFbkalAx = tvGwZkTFbkalAx;
        }
    }

    return MUbEMsbwBvuMqWo;
}

double mKKekSze::nuysfeCaoTHOQnG(int RwTobBUmMrc, bool FObzkdLfj, int NKRvXczsXOIc, int tASwMvkdTilFk)
{
    bool JZZYtKwZAmfsSK = true;

    for (int QynFMvkbt = 1243027539; QynFMvkbt > 0; QynFMvkbt--) {
        RwTobBUmMrc = RwTobBUmMrc;
        tASwMvkdTilFk /= RwTobBUmMrc;
    }

    if (RwTobBUmMrc == 1849873117) {
        for (int ZyAShkdKKrat = 218937176; ZyAShkdKKrat > 0; ZyAShkdKKrat--) {
            continue;
        }
    }

    if (JZZYtKwZAmfsSK == true) {
        for (int MuBaBFO = 1113210082; MuBaBFO > 0; MuBaBFO--) {
            continue;
        }
    }

    if (FObzkdLfj != true) {
        for (int PuooeRtAro = 1447198564; PuooeRtAro > 0; PuooeRtAro--) {
            NKRvXczsXOIc *= RwTobBUmMrc;
            FObzkdLfj = JZZYtKwZAmfsSK;
            tASwMvkdTilFk += RwTobBUmMrc;
            tASwMvkdTilFk *= RwTobBUmMrc;
            tASwMvkdTilFk *= NKRvXczsXOIc;
            RwTobBUmMrc += NKRvXczsXOIc;
            NKRvXczsXOIc = RwTobBUmMrc;
        }
    }

    if (JZZYtKwZAmfsSK == true) {
        for (int JEpCLzymnoNw = 1122250504; JEpCLzymnoNw > 0; JEpCLzymnoNw--) {
            JZZYtKwZAmfsSK = JZZYtKwZAmfsSK;
            JZZYtKwZAmfsSK = ! JZZYtKwZAmfsSK;
        }
    }

    return 669525.541476677;
}

void mKKekSze::mRvjtoPK()
{
    double fIGAX = -746082.7220537827;
    int mzLoUdCHKEJaLBoH = 698181106;
    string YbrhIDqkzTT = string("YsfxdXLfUOIPTihSQxrBsLEZfymNvBHMPPYvUVcYsEZqSrCJoyyOtqJtQvoOmObNwlGbYFrwvdogjpFbnMkvlaobzhwsocIozcfsMLIFrRkZwxIJimJvBAblddfeWpaPjvnRjWqVMmcGqkrKFmzOqXPVwyBdutrJKpYABtNPNXtbvlRhsSIGtWRKMFrwTpGOcqnjvCmrRuXMuOMujZfrwt");
    double aPKpgHzwXf = -600027.5110553011;
    string vSvtHi = string("LBklXyOveiqMFrpbdSZjRIFQfQLpFRqPASFqUztyWaZexekPxtVPDcmgBoJRsUjEWHeAQJZPawBrmzvsovbOVJfxBMtKsnhkTFZWzEEuxcAcPMkvVnZbvhezXVWeVnHhJexLKlrEipDZrWLWQRQpslGGJSHkYfQeTsEpHXqucnROHLTScUsrAljgBxswyhewyBBMtJnFLiyAv");

    if (mzLoUdCHKEJaLBoH != 698181106) {
        for (int LNxtyUW = 1673576106; LNxtyUW > 0; LNxtyUW--) {
            aPKpgHzwXf /= fIGAX;
            fIGAX = aPKpgHzwXf;
        }
    }

    for (int ErhxD = 393085182; ErhxD > 0; ErhxD--) {
        continue;
    }
}

bool mKKekSze::dYYnHWLXecOplw(bool wTYCXvDGuPlSjW)
{
    bool KPHpGoImfuNk = false;
    bool cKSPQ = true;
    int ItKkAJE = 1461811840;
    double eTVINlTNZMEDZfbu = 1010458.1413376556;

    for (int nltWYFKG = 497968778; nltWYFKG > 0; nltWYFKG--) {
        ItKkAJE -= ItKkAJE;
        wTYCXvDGuPlSjW = ! KPHpGoImfuNk;
        wTYCXvDGuPlSjW = KPHpGoImfuNk;
        KPHpGoImfuNk = wTYCXvDGuPlSjW;
        eTVINlTNZMEDZfbu += eTVINlTNZMEDZfbu;
        cKSPQ = wTYCXvDGuPlSjW;
        KPHpGoImfuNk = KPHpGoImfuNk;
    }

    for (int JQteQ = 636112372; JQteQ > 0; JQteQ--) {
        cKSPQ = ! KPHpGoImfuNk;
        cKSPQ = ! KPHpGoImfuNk;
        KPHpGoImfuNk = wTYCXvDGuPlSjW;
    }

    if (KPHpGoImfuNk != false) {
        for (int SuUaXRiTzn = 416401428; SuUaXRiTzn > 0; SuUaXRiTzn--) {
            wTYCXvDGuPlSjW = ! KPHpGoImfuNk;
        }
    }

    for (int fNYUqVLj = 2108650800; fNYUqVLj > 0; fNYUqVLj--) {
        eTVINlTNZMEDZfbu += eTVINlTNZMEDZfbu;
        KPHpGoImfuNk = cKSPQ;
        ItKkAJE /= ItKkAJE;
        cKSPQ = KPHpGoImfuNk;
        KPHpGoImfuNk = ! cKSPQ;
    }

    if (eTVINlTNZMEDZfbu == 1010458.1413376556) {
        for (int yppTuDpiRAiq = 1406285018; yppTuDpiRAiq > 0; yppTuDpiRAiq--) {
            KPHpGoImfuNk = KPHpGoImfuNk;
        }
    }

    return cKSPQ;
}

int mKKekSze::oaumZspXCaqNEt(double TlfpwRxyj, int Rfora, double SXrlWxwQl, string WFkqnbKx)
{
    int smjdMcxH = -1244843684;
    int ThDHmKDmtHSGkHz = 2036020778;
    int bBjrL = -1737615076;
    bool PbjvDEQBK = false;
    double prChpT = -705864.5728163604;
    bool REKwHjnidmaBR = true;
    bool PvYiwcQay = false;
    bool GedRpO = true;
    double ETAHZdkR = -980021.6343693348;

    for (int xmOqeaGQa = 1520513464; xmOqeaGQa > 0; xmOqeaGQa--) {
        continue;
    }

    return bBjrL;
}

void mKKekSze::TrQyWR()
{
    bool yHCOmWZglkrvIpyE = true;
    bool paAdhwowg = true;
    double qolSXGmPUYeKxxU = -915166.9238249282;
    double NyeeegqvLDVcuE = -427325.8745625653;
    string NiFkYU = string("HOpVQlXBuBiJzdxkleDCIxEOvTViubrcrNScWzbYlkiGfeKEPEKKsRCANXuUrXCVGqvkcbwT");
    int WSbySAFSnxu = -1151436678;
    double dTHFLNyifz = 100407.47499640971;
    int eJpAYXWvWAGa = 662000648;

    for (int rVefL = 1771914901; rVefL > 0; rVefL--) {
        qolSXGmPUYeKxxU /= dTHFLNyifz;
    }
}

bool mKKekSze::acYIUGpSwI(bool JkDZccCzmCE, bool vgCOOuTQ, bool JYxUAZA, bool lHguuolaPg)
{
    double DbvoJhivRu = -940886.3853764302;
    bool oGrqhNVDQUaZaV = false;
    int JkJLh = 1557292880;
    string XCRMYpJXxfknh = string("ckJewXRXieGdAVCEQWDAfoOToMkXRZlKLjEWGcWNAKkJxyBkDpmDOJvQLkiSPIGophlLGHrHyTQKYfmsvROXOdOyxSTSRLJQHdFpuJoAhtlJKzDPaTCofkYOktbztojTnHczUsUVseuHHRhITsQUzQKK");
    int aDHtC = 1846164689;
    double siImVwELnMpIB = -970414.3507469248;
    bool qxhoYjGHmjjcNMB = true;

    for (int DXEtihAPzL = 793571823; DXEtihAPzL > 0; DXEtihAPzL--) {
        oGrqhNVDQUaZaV = JYxUAZA;
        lHguuolaPg = ! oGrqhNVDQUaZaV;
        oGrqhNVDQUaZaV = ! lHguuolaPg;
    }

    if (oGrqhNVDQUaZaV == true) {
        for (int SoPpRusWNeb = 455193176; SoPpRusWNeb > 0; SoPpRusWNeb--) {
            lHguuolaPg = ! lHguuolaPg;
            lHguuolaPg = ! vgCOOuTQ;
        }
    }

    return qxhoYjGHmjjcNMB;
}

double mKKekSze::HqNdHviEPyXGXvvP()
{
    int rWqnoTjoYuHEPrcV = 854896524;
    bool RaYwclWUxm = true;
    string gfAEcCDeubOdc = string("ZKiWbkooCXDYMbbfBbYwnJHkbkMyrFijo");
    string JXtRssv = string("LsPAoQLJeWEdKFYnlZHcUpwUKIcQbqszHZNkugThERSzVcQaVyHWYuFwStEzxDUuIKrtfRNVhGqVwxRMAxXbMsslqOVnsdJKhRgUHtDZdSNKdlzAHbgkebuAZTFSEzksZcRmykNFJbjFqVOWRlLpOpAumuhVjXSdTPbhuBrJHDrLQHyAMnDxcRoeZVRPonSWEUptmfXwKIuZSrupButJaEVntClsBrRzPcrmmTASDGJHIqiNNXwrGVZ");
    string IffflIfL = string("mfQifoXzycUYVIvSzrlKNHjTzAPvPpPzwcrnKMyQyuKNMWJufwAUuPnptAnXpXDjizsoDplcGvLIDJMzbksKIxHwUyllDahpRtSLJfjCSFWWHTNXALrYCzEUCdgSIMVqZAVayHoSCcjEnoJqaQEpEJDHezIImThNlmWNCHMBwlmZkodoPEsRemysXaEvtzpdLlqQ");
    double OLpfPkVmfVV = 179000.19943084198;
    string rvQnAiDyvnyW = string("wUUivRMidpGoLnkQHkrFVhZGOps");
    double FnlGoJxGsAnu = 238519.45367473108;

    if (JXtRssv == string("ZKiWbkooCXDYMbbfBbYwnJHkbkMyrFijo")) {
        for (int PeSKIoEhrFHTXOI = 355880401; PeSKIoEhrFHTXOI > 0; PeSKIoEhrFHTXOI--) {
            continue;
        }
    }

    for (int cnpxScGAsZdW = 1892181105; cnpxScGAsZdW > 0; cnpxScGAsZdW--) {
        IffflIfL = gfAEcCDeubOdc;
        gfAEcCDeubOdc += JXtRssv;
    }

    return FnlGoJxGsAnu;
}

mKKekSze::mKKekSze()
{
    this->fhLqxRPmf(string("YqAHMMXMqkjJAMiKYPjyOsksFZkiCDWLyfoFqYrNjFflUJcxNFfrkDKZfQocVcGuXYjNCfmUBDxwrStcJHddKZEg"), -457238.20195365977);
    this->xVlsWeob(string("WgRuslrTUaCPzxkzpiflzwYAseyuabYVruFxTeEUlGtJUvtdcipttCzIODRqTINAUXXpWajdKLTzBaritMEeEHtgIfIxLSwNSUJflbvdkNQNPlIXRRGYKsuWfZOyNGwgXXCXyWgFkOEsdsEqvNRjZQNGJuZAzqmyWSCUQnxohankPBwVEZxYjmqGjNpcBZtbIJOimXjRURtl"), string("bqZcnmIyTQxRkDnsNfNlPHNKEXrx"));
    this->oefsypaavezhACD();
    this->WPsMWg(string("cjcuzWvTeNjnMJzYnZknAJpwfAaozSFiYBXetjjOvPhPOABrpEjoQmDuFHSDpaCRwmHxNOZBDpEndzJgqMJqEaPnN"));
    this->xGGYYDLaVqN(61085704);
    this->aRVcqWMTaLJleCM(string("fUQLZjrqpUHuuyEuMtFXgKsaelvyGiLAlEcwTkUSPOFIPfDCmefTPgrdogsLOJZWIwlH"));
    this->BeUCSXO(227182.02749131978, string("OflYPPpSDHtjBiSVBpRpwcRQAvYelwYUrWYWiTwFVFTvBkBjfoVAFJZGdtMZXjHJTyZpMZScalmAPhjTHXoyqmXzrxUoJoEQfhnULSFnCjqqZ"), -252727.17256871404, false, string("okjblWtbznoSkADBFiLMlhARPeAMSjltrEcfOUcSJjsrhXOHMjCbwWwQdmkqvvGeslpTptfIHQNjqPusufKkhAFqBhXglwsQrsMdpGNuHjGNaiiJrXxHiCTYRLOUySpfTOVfO"));
    this->NSPMZAwkf(false, -119603.09008422824, -639979987, true);
    this->nuysfeCaoTHOQnG(-1926504286, true, 1849873117, 110526838);
    this->mRvjtoPK();
    this->dYYnHWLXecOplw(true);
    this->oaumZspXCaqNEt(-515111.80790224293, -1669745531, 433355.6800533481, string("SSsZShtisPULNebPujHNGaNjHZkywxXBBecoCqknFkIKAruEXiouaZLhybhZkMgsjUYfUNUlfaXBcEXzKOqueHbXuRtMVGxAYBSvdaefcnQoviuPjlemKNntIUnmmDSHKjNkcxvjZhHtGMSxpTONtyOZPUNjoNtVKLQPNUJHUbAMehPVurlmIQDPdoGFkZSPMRLdLiEdZdEOXMbWzjIEQTuhYMpVSXXewFBPzHPMZBOPIaBVgvLKz"));
    this->TrQyWR();
    this->acYIUGpSwI(true, false, true, true);
    this->HqNdHviEPyXGXvvP();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oljBTERgWy
{
public:
    string OprItlgjRwbQgdKY;
    string qhvYlzJfVN;
    string kgvDLezkfWkD;
    int ZFTDNvtxgCHdZ;

    oljBTERgWy();
    bool VclRCagYNagvpaJ(string OgjGQvI, bool wLqLYPUluYDAhFEc);
    void EHcHIoIJg(int KRhHSKTkTR, double nsuxgVPAg, string VZIpIrpxO, bool QjvITRV, int YDNJHUkck);
    int rnqqW();
    bool CPQpfjJSPXaGNPi(bool miXVHK, string rtAuzbEI, int rXqwLT, bool XHRyU, int DufePsuyHkymsxas);
    string LJnOqjktibiQw();
    string AOxat(bool HwqfTQTxJ, double gnGCTxGFnqbCU, string fKrIoMVpKimfwqwS, string dvNuwZdYX, double ynpsiSPYxTwjJr);
protected:
    int znKutvcAK;
    int XznDAXvdbm;
    string gkcesNSMaE;
    double yraASjavY;

    double weIKUslFTeXRtBEJ(string AklWELqg, int cuCxIfNmYhkYKSU);
    int JxuJhFJjc(int bPjArtREOebaVog, string OshKIMQ, int xUkZVJOAnoGNQ);
    string bqsrkrP(int DPSDtegetx, string OCnDKamXcDwAUz, string RcAaLzaeripBB, string FEHSqQWMIBs);
private:
    double PkzRGNAVKrdAv;
    string kivwluEsEFGq;
    double nsbCoDQFZmUxUiw;
    double mOgcnaFZB;

    bool KXgeTPQFoT(string SWprekwU);
    void QLYIfTJFU(int krwzDOzxrL, int DQOJt);
    double iBrACtz(double rVSksNjhhvfZBa, string VohvBrJ, double tVOPwkzaVBnrO, bool tYZaW, double mZzexayYiAlXPEN);
};

bool oljBTERgWy::VclRCagYNagvpaJ(string OgjGQvI, bool wLqLYPUluYDAhFEc)
{
    string zyeeOxJLyVfuXE = string("HwRnOAOShGDWpcPRrxNOBpcMiTTTkgTUYYpvNIXvzaqAXWdTLTWizlQIheMXjmANV");
    string ybkTGnL = string("EkhSjEoFMeCLnFXBziIfnTbiMptpIwrbcAINeqzlKbSBakdwxQpljnlXaivlgkVRwfUGEEMTotqVaZTgNgqRuFrZQnOSMiyYUQKpTyxSgzVoVXXkVgigiaMknICOGLFDXBrEPRIZ");
    double QiyEbJSYEIVGAet = -270216.0557848709;
    string RbnmMYcYvd = string("jKrrxBGsyKvtCtKQrCIzzeqsGXudARAbdylTQexkmPGnVtEPifkdyJIOLJmPJpwWWMnJzGRBMKKmIYDxgfRGzaqefSHehKxIDUEboDPOCpzXdrJKmCJxxxYWVYIoYxyChmBBtpgWQsaJGFwLCOpLsNPSGdZRlITdbRJbfYWAKrMUltSgPIVzsBbFBaKOzJWTvSRdSiGQqNytKWEMJRhbtKMq");
    bool bfOKqcY = true;

    for (int DfxtJFxyVO = 1690573608; DfxtJFxyVO > 0; DfxtJFxyVO--) {
        bfOKqcY = bfOKqcY;
        RbnmMYcYvd += OgjGQvI;
    }

    for (int GxGwyRVaoM = 1268834223; GxGwyRVaoM > 0; GxGwyRVaoM--) {
        zyeeOxJLyVfuXE = RbnmMYcYvd;
        OgjGQvI = ybkTGnL;
        OgjGQvI += zyeeOxJLyVfuXE;
    }

    if (OgjGQvI <= string("EkhSjEoFMeCLnFXBziIfnTbiMptpIwrbcAINeqzlKbSBakdwxQpljnlXaivlgkVRwfUGEEMTotqVaZTgNgqRuFrZQnOSMiyYUQKpTyxSgzVoVXXkVgigiaMknICOGLFDXBrEPRIZ")) {
        for (int jFgQUd = 681940634; jFgQUd > 0; jFgQUd--) {
            OgjGQvI += zyeeOxJLyVfuXE;
            zyeeOxJLyVfuXE += RbnmMYcYvd;
            OgjGQvI = OgjGQvI;
            OgjGQvI = OgjGQvI;
        }
    }

    for (int OBhXKyRK = 20161037; OBhXKyRK > 0; OBhXKyRK--) {
        RbnmMYcYvd = ybkTGnL;
    }

    return bfOKqcY;
}

void oljBTERgWy::EHcHIoIJg(int KRhHSKTkTR, double nsuxgVPAg, string VZIpIrpxO, bool QjvITRV, int YDNJHUkck)
{
    bool zhuCHoFyxFAX = true;
    string OUGpNJFBzAL = string("ydXAdQ");
    bool JlfVxrJNGvVGLwVx = false;
    int bnjJvgZF = 886887944;
    int YODTAGJEpzSA = 23251083;

    for (int ZPDwhsXCt = 40860729; ZPDwhsXCt > 0; ZPDwhsXCt--) {
        continue;
    }
}

int oljBTERgWy::rnqqW()
{
    string XZbhghSo = string("RcwwGwYwxqFDuHeDKejYNsANGvWUNWtUNaxRUHmDFkcrgDmffmwZnLYGMYQznWXVLLvNlNRFFVSUs");
    bool dHLPXjuhYtNwQLH = true;
    double DblMeftV = -207785.2693094239;
    bool lngXhR = true;
    double eeiaTZCaCytJnSkN = -42347.52742746121;
    string pySQV = string("CeNEMsCypUjfwuB");

    for (int PNUnbdupAcaMjIc = 586758773; PNUnbdupAcaMjIc > 0; PNUnbdupAcaMjIc--) {
        eeiaTZCaCytJnSkN *= eeiaTZCaCytJnSkN;
    }

    if (XZbhghSo != string("CeNEMsCypUjfwuB")) {
        for (int cQrXPeCmmtV = 1400532175; cQrXPeCmmtV > 0; cQrXPeCmmtV--) {
            pySQV += XZbhghSo;
            XZbhghSo += pySQV;
            dHLPXjuhYtNwQLH = ! dHLPXjuhYtNwQLH;
        }
    }

    return -473274807;
}

bool oljBTERgWy::CPQpfjJSPXaGNPi(bool miXVHK, string rtAuzbEI, int rXqwLT, bool XHRyU, int DufePsuyHkymsxas)
{
    int txjQZylyTaNCXnF = -1502302311;
    int OXZezcpzz = 1422299690;
    string wARhCkOfYZfUPGhm = string("afjvKtgYQVhkqlWTNyBseZZILGsDpqPXjPpAVyeEHOCkHqzZRnerJnNtZaPKBLcXWqdGmCtAizKZrbMonebKGpkUubptqmVtpjUfLGinmdJbZxIRsFiJzNiCZkqHOzuabeepdOhlXIgcKvGknFXUtXYdjMSvJjDWUjVHcjmufOVDxLuJoCVZyFnlsnusiRO");
    bool wFUEHWYNdxup = true;
    string bWqXQ = string("TkduyMdHIbzcmQKRZNTbknCzyATFtznDOProBdQEPilWBXiTRfvDUNTFsfrkDiVsTGfqgjQDvkABgnvxPDEFkcgAAwcRSlhJtpJgFjHGsHNmAIVwKEHUFNbGeAgYxIRMDNMTYPWeaZViCIrJNzkvrxEguNXzvVpcgEwXTySetaTlPWIdmiPqQqcoLXCywhUKeDtmYxbdxxjDFklkPURP");
    int EWRYxmTkKZotOX = 768204957;
    bool fnWdvQkCHlIhK = false;
    int rCRiI = 308052524;
    double nUOyZAOYb = 899522.6603831769;
    int GUXeCe = -645882440;

    for (int FWgshfS = 1844299914; FWgshfS > 0; FWgshfS--) {
        fnWdvQkCHlIhK = ! miXVHK;
        rXqwLT *= rXqwLT;
    }

    for (int OtFtoNHfhrHKQ = 830873015; OtFtoNHfhrHKQ > 0; OtFtoNHfhrHKQ--) {
        txjQZylyTaNCXnF /= DufePsuyHkymsxas;
        DufePsuyHkymsxas /= DufePsuyHkymsxas;
        OXZezcpzz -= OXZezcpzz;
    }

    for (int vBzpkcUfpjPHIC = 2045192211; vBzpkcUfpjPHIC > 0; vBzpkcUfpjPHIC--) {
        EWRYxmTkKZotOX = OXZezcpzz;
    }

    if (DufePsuyHkymsxas < 1215282142) {
        for (int mzSdwGzMWY = 1427970603; mzSdwGzMWY > 0; mzSdwGzMWY--) {
            OXZezcpzz /= DufePsuyHkymsxas;
            OXZezcpzz += OXZezcpzz;
            miXVHK = fnWdvQkCHlIhK;
        }
    }

    return fnWdvQkCHlIhK;
}

string oljBTERgWy::LJnOqjktibiQw()
{
    bool HTSSukRM = false;
    bool QTRabklULlkp = false;
    bool TQcRARV = false;
    string ZnggRc = string("UMnsOfXUoVlEMSsZnlYxfljWDSLHBtEVHspTVbEGtsBdzEcSfqwyFtVkDxyfTyKfnVnCcduKfIlTsoyMA");
    int fINvRpyFE = 1393107197;
    double BXNgHyXSmQQu = 293497.4466844519;
    string iHhzwPKPOaKH = string("liCPrhiSrNigFEbzlMgEuovIyXomEMLzwnsTsuwmkIPLjO");
    bool JiKDGEFT = true;
    int hZThFo = 578438165;

    if (QTRabklULlkp != false) {
        for (int giCUJCVvbVCtjor = 1787080824; giCUJCVvbVCtjor > 0; giCUJCVvbVCtjor--) {
            HTSSukRM = JiKDGEFT;
            hZThFo = hZThFo;
        }
    }

    for (int TxyspttfAcRFm = 1768696908; TxyspttfAcRFm > 0; TxyspttfAcRFm--) {
        iHhzwPKPOaKH += iHhzwPKPOaKH;
    }

    return iHhzwPKPOaKH;
}

string oljBTERgWy::AOxat(bool HwqfTQTxJ, double gnGCTxGFnqbCU, string fKrIoMVpKimfwqwS, string dvNuwZdYX, double ynpsiSPYxTwjJr)
{
    bool uYAnoRcOIkiSdr = true;
    bool waiJLqSOUPjZ = false;
    int RjxbTdIoTvYG = -1482744145;
    string nYXcLVcoAqZ = string("OXugmjWWbQmhQKFPPfbKwDePQwkkvzLkcpqBeHrIEjFkFTrGyvbBYwGmQaMXUuolYQYPqJvsaJOnODibsgcpnfBqUJvNfjfgUXzYuEroOVASPNGtjoMeSXZqAKmyresszzoyLKUmrXVeekKbykBhUmPQbubRrCfRvBZuCDvyDdAbeWlSVifsONwBNGqaDfSwtHkHPIIKeKrfogxvBRxrcZQTDuQRbRUd");
    int ikMzOP = 1165444349;
    string FsyifKRsyhvkd = string("YwmfOslcHlPNEuYNrSSgDRYywLMDEzewElMMfcpcRqKMrfZkYwgPEymeJHugYvXleWHzwPvVwlinqHUHTYVKtGoHcO");
    bool SCbrWJKOKtwvDAX = true;
    string rxIbwkHOdsLkFQ = string("LXuLSERIulpjkpuYcozhWOixITkpgoGjkUUmJPZTNVnIdvRBffPWnwIjUmOJIjRIpMhgOyHGykvsdrIBABBwYQFUeJHbBRRzYLyzPXyEmnrFfNLXzgAkTlmlyPRnhFizrGJYYqnuTFyFBCaGhcfjkOstNNIRJyMJaLxCosEmXdNMINiMZbcGtbfSjbWVzvIsufyOowLfEsqtZKsGjgUm");

    for (int rnUbkvn = 1864882893; rnUbkvn > 0; rnUbkvn--) {
        continue;
    }

    for (int QZrjVcaREFXCqcq = 1480370013; QZrjVcaREFXCqcq > 0; QZrjVcaREFXCqcq--) {
        nYXcLVcoAqZ = nYXcLVcoAqZ;
    }

    for (int WCJePkslWTdd = 121021785; WCJePkslWTdd > 0; WCJePkslWTdd--) {
        continue;
    }

    return rxIbwkHOdsLkFQ;
}

double oljBTERgWy::weIKUslFTeXRtBEJ(string AklWELqg, int cuCxIfNmYhkYKSU)
{
    double mChHVFsQKQKPXBy = -283278.9302363001;
    bool aNfDoQKpUL = true;
    double IUxRfYwfVQVFR = 609962.854415263;
    string TePYZDyyzUeRueGy = string("hscuIUsaPwYCjangvcSEsmmrsxdGrPNgbmfjDyNjIrRvHXatiFZqBqWTJbsaOpXQiwXJFEGyZHqpiIJoEdpDflKYToOIJNIJxvUzCcxybintFdNPDpszdALKUOlYMNcNYQlhuqcxQDYKMaXdAo");
    string PxouqvRIQXuyYjRr = string("ciqEGekrxOCGKrhAmHrXdlMEnbaJrcdGZstSHjTEhoBEmSNTlosuQvkYbcclOlRixfaLTcYzVvuAaWrDZhtBZogolcbjHJvJUDAjcKPbVAApHkPcGKGzevNZEMYkoyBTPDKyiATLOVsTZUOCjrIBdbgOTXUu");
    int eFQJvgFuLAjLuTpU = 813648079;
    double NRfSCHgq = -780119.5082492139;
    int txlTXRwX = -94643748;
    double sgBSPssDshKV = 264557.0856011066;
    double koxrgeFxDSdnsDs = 493281.44637021335;

    for (int ffFoP = 1486258479; ffFoP > 0; ffFoP--) {
        NRfSCHgq /= sgBSPssDshKV;
        mChHVFsQKQKPXBy = koxrgeFxDSdnsDs;
    }

    return koxrgeFxDSdnsDs;
}

int oljBTERgWy::JxuJhFJjc(int bPjArtREOebaVog, string OshKIMQ, int xUkZVJOAnoGNQ)
{
    string TdRvaOWTWMUpf = string("PsIHpyogpPkoUCoHINsEmMoojiHgHedmerpUIkRRcsfAlzDAiOkiiCboVZpHzMAwpVndNrCGsSunnCJhxCHTFvWIiTHuPkXkwgvfGvdXufKSrhKqHghlvWHekOeAJXwFKVLQEfCQtQiIrrsfvcKrooJWWXYKotrMHOSUjvw");
    int OulFRgieokwBB = -465461748;
    bool JBndQWNVM = false;
    double QlhBopU = -284036.3940846042;
    double SQxEkAzsL = 289039.4035117384;
    bool FAOJtjUm = false;

    for (int uOnHWzsiwQ = 532159646; uOnHWzsiwQ > 0; uOnHWzsiwQ--) {
        SQxEkAzsL *= QlhBopU;
    }

    for (int DNOLJCpYAWsnZ = 1285716795; DNOLJCpYAWsnZ > 0; DNOLJCpYAWsnZ--) {
        continue;
    }

    return OulFRgieokwBB;
}

string oljBTERgWy::bqsrkrP(int DPSDtegetx, string OCnDKamXcDwAUz, string RcAaLzaeripBB, string FEHSqQWMIBs)
{
    int QyffLvxL = -1583089186;
    double cKssmsuPmB = 367810.7401529393;
    bool tuAhcFN = false;
    string IJVMCLOrOjAjR = string("gCNJnZQFmnTtqammhgjFmqeDBrqCoIJNixEpIUrdqelYBhxMmqQASwTWNlmgrIjGjlMrHTVTjEDtfObJnjXTBlJQmVUdaLwkiGIWImociMrIjOWBliFpJPfSJsbUqdwpYyyfzMWhkAptYGjFoJyUkZxFLuhMaRmKpEmjhIPMIxvAWrDmgFsWShxSzchMcEPiqLwRpLeUWbNqcPbHCqa");
    string hhhEuIHPet = string("AHzfYvxejOQGmQYXssdMvlqipvUPsMlcRgjtxOozclNFcdClUCEmwrpaMxCKUcTjTQJzslinAsJEVtEogOYVzPVdPeHVmdwVnXCcTvPxGkSJVbPOfDOawguIBhikiamnHopTwbTqJNVWPmsGgGYxIMQufGGCkwrecAYfgIGFDdGFClsLImTzvqfRIeqVpTAWIBBaRWgTbHEAwGRQmQOASpnyWONFvaEBqPOsEmmvcgQRXFAPLOaKHXymJjUyd");

    return hhhEuIHPet;
}

bool oljBTERgWy::KXgeTPQFoT(string SWprekwU)
{
    string TfqUNNlUhoti = string("dDCTwuWeBhlvhzyYAnsJNFzqTFFfXmuUhCbbzvVHZmrRJzjJJLlXZjEgwxNOLGnCZcLFosiGWfmKusJFkMuXoCfhxTWxaKLkjNxPuijeJzrkOqfhUhHfpsafMcliBNSTvNnIhIwmzrBzqsAgTwX");
    bool FcyttPGeMeuybkR = true;
    string tUHMeIUNpdbMDv = string("lAhjlwQgxsVdghVyrcCBsIBmTbnFOirWxBDRMtSjjNNLJyBHxRnCiuUiLJZgAKWKBOEnLrPAFCeBumplfBBOuRoAKVokAjBsHwegReMnpFiDldiKKlSrfjdXvHzWrYnqYfgirBwWiSQCKZhJMXqBRuQmUYbGoOoiBwRwkghSawwWWsWOCUlwLkLcvpzREoITaRralnnGZIuBVkKdpqfCqKSmqdfu");
    double iNHLESY = -714902.6880192703;

    for (int DJaSZlWTy = 966890835; DJaSZlWTy > 0; DJaSZlWTy--) {
        continue;
    }

    if (TfqUNNlUhoti >= string("dDCTwuWeBhlvhzyYAnsJNFzqTFFfXmuUhCbbzvVHZmrRJzjJJLlXZjEgwxNOLGnCZcLFosiGWfmKusJFkMuXoCfhxTWxaKLkjNxPuijeJzrkOqfhUhHfpsafMcliBNSTvNnIhIwmzrBzqsAgTwX")) {
        for (int sGMUe = 1267939412; sGMUe > 0; sGMUe--) {
            SWprekwU += TfqUNNlUhoti;
            TfqUNNlUhoti += TfqUNNlUhoti;
            tUHMeIUNpdbMDv = SWprekwU;
        }
    }

    return FcyttPGeMeuybkR;
}

void oljBTERgWy::QLYIfTJFU(int krwzDOzxrL, int DQOJt)
{
    double hvNoJQku = -536602.801991563;
    string JhFCL = string("rApJLpAfeSWFdYiXCFyWaLnYvREKAYaxqgOnMjnBpFQPNEBqPyXJdJqdLcNkDlqyXhPoVkCvdkIcRgAKtmmmxvWWvqFRmuViWjdkTXzxGsNIoQuBFxelHnpecLgiZHtcNzOeRUsUdUIKOvMPOWPRrfTqvxyNKPkhEzPSplZvHGuaBquUHvB");
    string NItJTXBLDlHPrV = string("FdmvMpmfjYaqxvytCHIzkIUTUhIcWNAEguOBblYjCQClniIBkwhLidWoaJLeCOylaNVLPByVCdlFDwhxVzamEUcQMFefdHcXIzguZqMXZrrmPGOiHkpkEyPpfFXOlHbBmu");
    string LJVGUyy = string("LUnRTcQSByP");
    string WqNIpkesSfN = string("aiAeOZYvFpiUPQFGaJuwpjwHglTdOqiPrEyvXtSmutRlXsyYsbvznefvlBFXRkWOlaLFIBBpnorzaQDPHXpFBWENlVxLnWtwDfUYIwWrkJHIIBdgIBcfKFQqLEavvqRNIeCyLjZMkJVvppognlbZVIdWXOsNRruSmZMcRyMMoMXagQpUrU");
    int AlasuQZQBJHweAD = 2013065128;
    bool wQVdtNb = false;
    int XPTJFVkAlYJ = -778671561;
    bool dDxqDqyZXbM = false;
    double OroBkSwXcmBo = -169129.0086005103;

    for (int MmIRUUjVUVajMW = 1740783476; MmIRUUjVUVajMW > 0; MmIRUUjVUVajMW--) {
        AlasuQZQBJHweAD /= DQOJt;
    }

    for (int yXHnZJQc = 330039848; yXHnZJQc > 0; yXHnZJQc--) {
        WqNIpkesSfN += NItJTXBLDlHPrV;
        OroBkSwXcmBo += hvNoJQku;
        NItJTXBLDlHPrV = WqNIpkesSfN;
        WqNIpkesSfN += JhFCL;
    }

    if (DQOJt <= 2013065128) {
        for (int MnLHKR = 1953670970; MnLHKR > 0; MnLHKR--) {
            wQVdtNb = dDxqDqyZXbM;
            NItJTXBLDlHPrV += NItJTXBLDlHPrV;
        }
    }
}

double oljBTERgWy::iBrACtz(double rVSksNjhhvfZBa, string VohvBrJ, double tVOPwkzaVBnrO, bool tYZaW, double mZzexayYiAlXPEN)
{
    double ieqhCpaMhm = -756447.4549105624;
    int fWjTw = 63194301;
    string dFYMuKEtnfqySf = string("SKRVZMVhxgKYZwNBNfmEnmvwdLRMCcvJPFoSgICcRKjGdUlPQpRABIspXBKQQWQIAgcmLzUCrnfOODPCouKfJLPnrvgyeDIwnPuXwlamLvcQJQZBtAybYNsOHQZrLvXLKBKjAAKrRFSsTyakAtbDUiRcHHofaKiwfuUWVLWYIREceNrylEHXXAqDzrwOVULGIuvBqQePVHKtsbrrUixkNfxf");
    double qLphVo = 32737.23802053868;
    int dxgYrwZCC = -1272046906;
    bool XaWobc = false;
    int mipDEzQyKgIuN = 377982517;
    string wWsxWc = string("MWMpWFQeqnyLDRhDHXIPLxjeBbLadJDFmQewCatONfNAqlyYhBrknJpsGCIsKEGOLiyK");

    for (int dUKeOiTuBmRwgdt = 1245331742; dUKeOiTuBmRwgdt > 0; dUKeOiTuBmRwgdt--) {
        fWjTw /= fWjTw;
        tVOPwkzaVBnrO *= tVOPwkzaVBnrO;
    }

    if (rVSksNjhhvfZBa <= 32737.23802053868) {
        for (int PdxtmPzdiLpvniGy = 1991100355; PdxtmPzdiLpvniGy > 0; PdxtmPzdiLpvniGy--) {
            dxgYrwZCC /= dxgYrwZCC;
            tVOPwkzaVBnrO /= tVOPwkzaVBnrO;
            mZzexayYiAlXPEN += qLphVo;
        }
    }

    return qLphVo;
}

oljBTERgWy::oljBTERgWy()
{
    this->VclRCagYNagvpaJ(string("ZIbKKZnMopAhWshsgmZcItgclvvbIAlmNBZtQDzMQyyLstjGgNadCqljCbvHPmCauBQLeatRwyAsnDpOXBegxcOUjbNEWQJAEjAEVZNGoToZrHCRYRyxrDlRHTtAtCnKDvUcYyChihpxbyicciSvNIKGonRgseVdoeiTJxwPYiFvVXHUcVecqmvWMZOSVSVz"), false);
    this->EHcHIoIJg(1175936914, -232540.80035901154, string("iioEKksiuOiVYUgUToESkfycIDFnWVNlMkHlRVLAtRGllggVTKHByjPycpAIXBWNaeFlqaegWGGBVYRbkHhxSAoIl"), true, 543043803);
    this->rnqqW();
    this->CPQpfjJSPXaGNPi(true, string("IhjMsOqHREoWFOuzVSTWZEzdJgssCVsVLskQrFRPJwcDmxTuVtNdhqWMMRyfUhtxYzSqmGIB"), 1215282142, false, -944751428);
    this->LJnOqjktibiQw();
    this->AOxat(false, 936093.7306365197, string("HUcQvfoaEuELoblpaFtQXdUKRNukylKWpauqrkwXbYyietSghwJvfOmupwKlAiAmApfsVxtoyjgEilcLhoMKaHOXxgKFYKJcXhWYODRkABUyPkvpcxFSUaIBr"), string("PUTGoPxPtgWDLSEgNIeNPCqAtEEUAgrrdVspQggtBOypaGSMffrDTGiQeaEUSwaNvsM"), -759481.117185011);
    this->weIKUslFTeXRtBEJ(string("filkMXXGjpsBYPWGPfbYzmyBTwIMKqNNsdWsLpvXWXecbbQnBTmaRShnGokgdgKKzrqEBBXxgahupKfhTYeoSeVmLdmQenHKEYXeHHyNCWXXMCERCCqRslQLiQzLiT"), 504335085);
    this->JxuJhFJjc(231939930, string("eGPqwkmeUHJjPAenpeuwAhbxGNSjGEEFDzFjvqoLFXCMqrjUOxxPZdtqdduTKUhqvylhAIugmRmlknOhMfPtEhIuSFOcpjSRWVDjfOmxndDqHrlYKusTzFAZAnBVXLqbNOHhbxtFAetISxOSc"), -1677910069);
    this->bqsrkrP(1742509478, string("RRSNRQTiRDfOBchKoiOFbrmLrENkwvpwApHbUJGDhADCvnfeqOQiYLLtPxRIxPgByCofbraiGDLRFRVDOHzptvvCexUTIBfQSwDGJGXlVvJIFNpxHtowSCJfTOSszBYFYOOsWliSMHLGCnuIzPlwtJPZiPtnUxbXYe"), string("qPfRtWofkbMKZnokzvgZQfgnKnOXAvIOrBhNMynPUrgIljheZutSjaxqAqXfZYtuBio"), string("UDPvQYBEEhqyOEbIXDniMB"));
    this->KXgeTPQFoT(string("QpcsDOCbiEmNWcMzDesYEyQKiNMBCZRBospEuHGgnQZCOkUaBaZMbjBPqDMTqRUsWyNKvtAlQbtvKRhlOODNYJobSGGyYTwhmVGrjMxITmsqivWDdIvfsbLMyngMARqrTbHIDewdcYibcFJWJAWpZYvmFKKmnlkCxaXWoGwFDGSeTYgZMtxuhOxayMwogPIuEdwDDVvxsttWi"));
    this->QLYIfTJFU(1120572223, -97950062);
    this->iBrACtz(2065.8215085305333, string("PZCGKxISzbJHiCdVRRWnBNFKptgTPFJWOEwgFhOEBGcjBsCtivQjoKhEINnpXAvKAnhEl"), 70531.74460345655, true, 408737.8996350505);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YOEsAhbLJPsz
{
public:
    bool XetoL;
    int NDRwabDqo;
    int piiTXqcarKcd;
    double LlCHGlLsAcK;
    int YfZlHZcq;
    string fmNoNtG;

    YOEsAhbLJPsz();
    double luosx(int kspuyBV, string vvIozG);
    bool PmyEL(int ApOxW, int ATudzizaBZFXh);
protected:
    double LTYXmmBDgdTiwY;
    string xnNKxwQ;

    string jnhEdRKLCye(double XimLrmBOePinYiZZ, int FUEDpjxRZQ, double QcvCrl, bool PtQsJvPEmI);
    bool WicHPOluFDzfZdg(double tepejty);
    double jZHLlqWBcsqrZV(string lJaHieagZXaoyQ, double PQPnNmGqTk, double nWjdUZZtklxXgIRM, string iKvYtPM);
    int XVAPmDJFkSZxG(bool FxPcQD);
private:
    int owjGOYYotzozw;

    bool ejzui(double BwkAcQbxxg, double dKRobcPUiVMtb);
    bool UssYVLekskzRcqvH(string HQDtT, string YfGKOnkj, bool rSZIKPqMkiPsv, int MkJFZmYWmWMK);
    string wxtHAAANrT();
    void QqyGq(int rXskYFygTnidF);
    double mlwwBRlDbpeua();
    int XgbZLUisjPpCIn();
    double vtVeooWn(bool LljMVUm, int eagbkybUvNNAYFg, string YopdlxiX);
    void PxNpa(int bhBLIVAIqPNf, bool FvkQDJ, int FuWbljh);
};

double YOEsAhbLJPsz::luosx(int kspuyBV, string vvIozG)
{
    string LhWEXayfWx = string("ZnHjeqChurFVlxTENWOBdRNeJvadamaIbFc");
    string HYCeaFiE = string("RGbLmdwLVlmgXxSlQaCGbwWjbTwJiclGqJAjQCVjXDJcEwxcWthkqkeEoNaTggGhPFfiRizkuQPDlpAGEAwUIUbHctGWdWojbxiUHyJykjrnsyIFRcZlcgrAelCxAlrTNsQBmrYuulXloQSEykSjPKJEjKZgsZb");
    string XlpmUFEUh = string("jxQjocdwKpyiUZmoXXZEsVBcRBoshJWPLLkrwNVzMrGevTpLqjwMBihHRmDDyYKlbRIbixIaCTmLUJxdMMjBelVinZ");

    for (int gvAxYvqln = 1612970752; gvAxYvqln > 0; gvAxYvqln--) {
        vvIozG = XlpmUFEUh;
        vvIozG = HYCeaFiE;
        XlpmUFEUh = vvIozG;
        vvIozG = LhWEXayfWx;
    }

    if (HYCeaFiE != string("oXIZIgQbIcCSStWqpVRrDXhzjCADWXNifEXSHXN")) {
        for (int yLQDDPUUOuPX = 985630380; yLQDDPUUOuPX > 0; yLQDDPUUOuPX--) {
            LhWEXayfWx += HYCeaFiE;
            vvIozG += vvIozG;
        }
    }

    return 227970.56514037118;
}

bool YOEsAhbLJPsz::PmyEL(int ApOxW, int ATudzizaBZFXh)
{
    bool rJYtNhprKCZZxFy = true;
    bool oYNXgFEwPWJgaYn = false;
    int BwySdblCIYtrWHa = 1708049122;
    bool MDmWnZIPUMWZZKwg = false;
    bool ZStVAX = false;
    double lTbPNzVS = 202980.0948752011;

    if (MDmWnZIPUMWZZKwg != false) {
        for (int cmzjQfLaMRjCbvzA = 111128645; cmzjQfLaMRjCbvzA > 0; cmzjQfLaMRjCbvzA--) {
            MDmWnZIPUMWZZKwg = ! ZStVAX;
            MDmWnZIPUMWZZKwg = MDmWnZIPUMWZZKwg;
            MDmWnZIPUMWZZKwg = ZStVAX;
            ATudzizaBZFXh = ApOxW;
            BwySdblCIYtrWHa += ApOxW;
            MDmWnZIPUMWZZKwg = ! rJYtNhprKCZZxFy;
            ApOxW -= BwySdblCIYtrWHa;
        }
    }

    for (int BHKiJahAODCFntze = 1638560766; BHKiJahAODCFntze > 0; BHKiJahAODCFntze--) {
        ZStVAX = MDmWnZIPUMWZZKwg;
        ZStVAX = ! ZStVAX;
    }

    for (int qRLSfCje = 957184275; qRLSfCje > 0; qRLSfCje--) {
        continue;
    }

    if (ATudzizaBZFXh == -1363919609) {
        for (int FEVhJ = 1960744969; FEVhJ > 0; FEVhJ--) {
            continue;
        }
    }

    return ZStVAX;
}

string YOEsAhbLJPsz::jnhEdRKLCye(double XimLrmBOePinYiZZ, int FUEDpjxRZQ, double QcvCrl, bool PtQsJvPEmI)
{
    double pLxGSqSdLb = 418537.9736112101;

    for (int ECrGqUMFqNHevlm = 1501238412; ECrGqUMFqNHevlm > 0; ECrGqUMFqNHevlm--) {
        pLxGSqSdLb *= pLxGSqSdLb;
        QcvCrl += XimLrmBOePinYiZZ;
        QcvCrl /= pLxGSqSdLb;
    }

    return string("zwAaiquQ");
}

bool YOEsAhbLJPsz::WicHPOluFDzfZdg(double tepejty)
{
    double aRFClpHcce = -256367.43327584845;
    string bUcfk = string("zLKScOSgXeNFgveBoIes");
    string IPFScSXN = string("yDQayUEjvTFxhLDqAECCSgQNTGGeShVlsm");
    bool kWRKSXJoUEhNuBu = false;
    double gjhznHmyYvJUs = 594608.6254976867;

    if (tepejty <= 594608.6254976867) {
        for (int sjxKtwfOisjx = 1623952886; sjxKtwfOisjx > 0; sjxKtwfOisjx--) {
            aRFClpHcce -= tepejty;
        }
    }

    for (int AzjXXyQ = 1446786047; AzjXXyQ > 0; AzjXXyQ--) {
        IPFScSXN = bUcfk;
        aRFClpHcce -= gjhznHmyYvJUs;
        IPFScSXN = bUcfk;
    }

    return kWRKSXJoUEhNuBu;
}

double YOEsAhbLJPsz::jZHLlqWBcsqrZV(string lJaHieagZXaoyQ, double PQPnNmGqTk, double nWjdUZZtklxXgIRM, string iKvYtPM)
{
    string IEgdjMaTJWP = string("HNCVsgmYQXXAusoOwLZKdMPVGERPCJPyehXxYiyPGQwWlKmFFqDdrGdAtLgpDmguZxFpodvjKHYNyjqAcxYrcFvXXYDedGkHofBgdGPeAXFmAnRmUthUGRzqRwuUdJVptRHFJrVHQpRndlGqhnrIftdQnxQaskpgtTsZbYshngQaFUtLBXKZaRhDXHaPIfSTbVbkmrLkKnbAFlf");
    double efkWUdMuCFEJUX = -374374.2186443911;
    string ssfeagCwoli = string("UMEUTpgWN");
    string dkjphRXsTO = string("zvgSsnSqDkfLQlCViIIaXGfaZbMfvUCiyCFhZBZENaZSElHUvPocsnMxivgeIoPXTIEvfFHGmWkNYAXcREvYAdGpJzLbtZZJoMCUXlfaZKoGYfdzOjAjPWyHilhDCfcQsPzEkvbiDRFKXbtVoDjzkXTEElGENcLxvbgmLYyHJXVDCuSTNWDcBIEFQki");
    int dPFwidBLxVybvl = -2037889372;
    double ZqGPd = 309148.2958772927;
    bool xqdhqgbsYqT = false;
    int mkEfsKdmahw = -393593650;
    double fHyLGLBRspPuebl = -371067.37300794246;

    for (int RynJA = 844865392; RynJA > 0; RynJA--) {
        IEgdjMaTJWP += IEgdjMaTJWP;
        ZqGPd *= efkWUdMuCFEJUX;
    }

    if (lJaHieagZXaoyQ == string("HNCVsgmYQXXAusoOwLZKdMPVGERPCJPyehXxYiyPGQwWlKmFFqDdrGdAtLgpDmguZxFpodvjKHYNyjqAcxYrcFvXXYDedGkHofBgdGPeAXFmAnRmUthUGRzqRwuUdJVptRHFJrVHQpRndlGqhnrIftdQnxQaskpgtTsZbYshngQaFUtLBXKZaRhDXHaPIfSTbVbkmrLkKnbAFlf")) {
        for (int kbPoMea = 254459427; kbPoMea > 0; kbPoMea--) {
            fHyLGLBRspPuebl /= efkWUdMuCFEJUX;
            lJaHieagZXaoyQ = ssfeagCwoli;
        }
    }

    for (int zkZMAKgnX = 636324206; zkZMAKgnX > 0; zkZMAKgnX--) {
        xqdhqgbsYqT = xqdhqgbsYqT;
        IEgdjMaTJWP += dkjphRXsTO;
        xqdhqgbsYqT = ! xqdhqgbsYqT;
    }

    for (int napmONQUN = 785594537; napmONQUN > 0; napmONQUN--) {
        ZqGPd -= nWjdUZZtklxXgIRM;
    }

    return fHyLGLBRspPuebl;
}

int YOEsAhbLJPsz::XVAPmDJFkSZxG(bool FxPcQD)
{
    string yXdhgf = string("oBtQyDuU");
    bool MWSUt = true;
    int tdnQmMzTLYeMbtWZ = -1544141880;
    double ihyXs = 463412.25949017605;
    bool asAuMWmCqpP = true;
    int tKxJcZ = 8369365;
    bool TjmEDZMp = true;
    double jZKVkhkosvnKM = -488480.6348331914;
    double IyGeXRmEjqSPnCs = -744686.9332208988;

    return tKxJcZ;
}

bool YOEsAhbLJPsz::ejzui(double BwkAcQbxxg, double dKRobcPUiVMtb)
{
    string yOJnpfTUXRyUPdpw = string("MqvqtDoFzJZiBLeEsOfXjAZinJihtJjkbTraHjwBITHBfjeWxXfCddsrwUUEqAgRYaHOqpTlNvrIcQGPFrIuIZBpzuiWLRYtnNyBgArRgjWKLXoITXqKFNjagLwJAPCwbDXNCQUMPdZvrXDYVDORKrsMPGxEyyqToJWzSCIvJCubr");
    bool UEwVn = true;
    double YcsXWexwRtkoNKad = -745149.1674352614;
    bool RgoDIRHgSatUwFq = true;
    double fCvyrXvgWz = 917507.0223327348;
    bool VVJyLsoeRwKpXcpH = false;
    bool wSrjL = true;

    if (fCvyrXvgWz < -745149.1674352614) {
        for (int LPSzEEVNAGnIavu = 1921740; LPSzEEVNAGnIavu > 0; LPSzEEVNAGnIavu--) {
            RgoDIRHgSatUwFq = ! wSrjL;
        }
    }

    for (int IhAqaNKlO = 299600137; IhAqaNKlO > 0; IhAqaNKlO--) {
        fCvyrXvgWz += fCvyrXvgWz;
        fCvyrXvgWz -= BwkAcQbxxg;
    }

    if (RgoDIRHgSatUwFq == true) {
        for (int iJUHeSbEdL = 203328452; iJUHeSbEdL > 0; iJUHeSbEdL--) {
            dKRobcPUiVMtb /= YcsXWexwRtkoNKad;
            YcsXWexwRtkoNKad += BwkAcQbxxg;
            UEwVn = VVJyLsoeRwKpXcpH;
            wSrjL = ! wSrjL;
        }
    }

    return wSrjL;
}

bool YOEsAhbLJPsz::UssYVLekskzRcqvH(string HQDtT, string YfGKOnkj, bool rSZIKPqMkiPsv, int MkJFZmYWmWMK)
{
    bool dEjNdVweblzqMRw = true;
    int DFzIxNkUgfoOF = 911398933;
    double UPQyj = -161967.7874026895;
    bool kqMTyxtS = true;
    int zgROqGf = -2123326371;
    bool ICerjts = true;
    bool hbSmblD = false;

    for (int bgZiIrUteddJHx = 1798104941; bgZiIrUteddJHx > 0; bgZiIrUteddJHx--) {
        DFzIxNkUgfoOF /= MkJFZmYWmWMK;
    }

    if (UPQyj < -161967.7874026895) {
        for (int tOuExaoiA = 1893995756; tOuExaoiA > 0; tOuExaoiA--) {
            ICerjts = kqMTyxtS;
        }
    }

    return hbSmblD;
}

string YOEsAhbLJPsz::wxtHAAANrT()
{
    string lHKGUexXrR = string("InHrgJHpVdIkyoVnNzNjPCUCgIgxEGJKGuqcxTLizhLazDVAjMkvazrqNxkMitPaSbinwPmNvextqgKilWtXFuPffLiJSKfoWEFmdbNQLicQrfPOpbHLVFTSfLzTPCZNSXhbEVsfofyPiSljXXViVyVRybTevSwcwpAqg");
    double LKSCeFFaxMVM = -743045.7647236516;
    bool RXZFacMeiKinQ = true;

    if (RXZFacMeiKinQ == true) {
        for (int yBvBdwrjsySquKL = 953142404; yBvBdwrjsySquKL > 0; yBvBdwrjsySquKL--) {
            LKSCeFFaxMVM = LKSCeFFaxMVM;
            lHKGUexXrR = lHKGUexXrR;
        }
    }

    for (int rDwjmBjN = 25145390; rDwjmBjN > 0; rDwjmBjN--) {
        lHKGUexXrR += lHKGUexXrR;
        lHKGUexXrR += lHKGUexXrR;
        LKSCeFFaxMVM = LKSCeFFaxMVM;
    }

    if (lHKGUexXrR > string("InHrgJHpVdIkyoVnNzNjPCUCgIgxEGJKGuqcxTLizhLazDVAjMkvazrqNxkMitPaSbinwPmNvextqgKilWtXFuPffLiJSKfoWEFmdbNQLicQrfPOpbHLVFTSfLzTPCZNSXhbEVsfofyPiSljXXViVyVRybTevSwcwpAqg")) {
        for (int WpCvbYFe = 482536717; WpCvbYFe > 0; WpCvbYFe--) {
            lHKGUexXrR = lHKGUexXrR;
            RXZFacMeiKinQ = RXZFacMeiKinQ;
            lHKGUexXrR += lHKGUexXrR;
            LKSCeFFaxMVM -= LKSCeFFaxMVM;
        }
    }

    return lHKGUexXrR;
}

void YOEsAhbLJPsz::QqyGq(int rXskYFygTnidF)
{
    double FfVQFbLLarVFniA = 588501.1345106417;
    int MTNzhqDa = 1618518483;
    bool zfUWCXZSwUq = true;
    double JVFVlj = 1031008.4589974612;
    string aHoXduiVAQz = string("zHyheZupLfzeQTLAgftQHUiKhAGzdlruNYPMGggsmyegQFVqOdPWfyCaIVkBxotVJtvfsNhEqPLcLOxvgRGeKlNoHYAGAHVdWQIbqyKHmkfPsUrnVRzmNyzReTJqbXWQiWGfxjEcfoeyHxYyqsKlKNrptvmMtStJhTOVOcBDujzKLeZOOmvfRwfDJfSVyDXFrPptTkhDSXvUcaQAwKrYTzquNpu");
    bool cDSAJeynyWMSvR = true;
    bool GbXvjCxemhwKLwAR = true;
    bool nnmLr = false;

    if (nnmLr != true) {
        for (int UFnLMAGffpLs = 1503165814; UFnLMAGffpLs > 0; UFnLMAGffpLs--) {
            MTNzhqDa /= MTNzhqDa;
        }
    }

    if (nnmLr != true) {
        for (int cOLUgSHOhP = 957478885; cOLUgSHOhP > 0; cOLUgSHOhP--) {
            continue;
        }
    }

    for (int cziQUL = 1064667966; cziQUL > 0; cziQUL--) {
        FfVQFbLLarVFniA = FfVQFbLLarVFniA;
        GbXvjCxemhwKLwAR = ! GbXvjCxemhwKLwAR;
        JVFVlj -= JVFVlj;
        zfUWCXZSwUq = cDSAJeynyWMSvR;
        JVFVlj += JVFVlj;
    }
}

double YOEsAhbLJPsz::mlwwBRlDbpeua()
{
    string UsrSqPSAiAPTWBk = string("TvziGJbNLKpWkDOExaNsrcryOxboySoGpoIDfQjLbJreWVqKnXgZQbmcDCBklOZTAnJENgofjCxpWgBhHlNOvbFcHBmXzHTLEyyuNxTHCGTNcUzdDRysHgOgbirBGJpDuVCgVWfLNPKGwehKmHmoGleRIgOdtltBTzQEqWDtvRIvtzIbMyKUuchhJbOBNFqAZbsLEHhDMTRYjRYtmAydwqgreenbRpKtQCGfpTqsKg");
    string kehor = string("XIj");
    bool ojClojqvQAbiQi = false;
    int yCZmnZxve = -604298273;
    int atFwsaaQhFmHK = -1647540020;
    int RdXhXvVKsRb = -1270151108;
    double cxfRYmIG = 85014.4321842833;

    for (int WTtytHtayNdx = 1608416406; WTtytHtayNdx > 0; WTtytHtayNdx--) {
        continue;
    }

    return cxfRYmIG;
}

int YOEsAhbLJPsz::XgbZLUisjPpCIn()
{
    int YDxqslZGFGfk = -944729074;
    bool xdsOHKMxoSoC = false;
    string NOPIXdWoKCdXEzi = string("JvFanlXTaZgdrcsJbICDOlKbgEmzeCDIVnXP");
    double dDRJPgDYimhAKM = -307596.93355667824;
    int GQgzjjjfKQzdOpfu = -1162394243;
    bool ahObBuavurMDlR = false;
    string zxKALFp = string("CZPKtFNvUMEHDjLuCZLcGfeKqIiHZfSyBkHqsuGePsAPyGfgYsAqmygMkScGxzNUyUKdHMJMjTVdirXbgrrHXZpwTIsuvDtbmUqIBghnDszZjOopWgpdEOyPuanDNwXYCJvcWHGMwSeQlqNzyikHpIQpxyfAwhxnhqZgIwCUkAZpxEdtOWOCwIaukKWjwnCUAILaijIMnWquoranxnnFfcqbiPglC");
    string yDwArYQHMfONNj = string("YjBexESvYSLfJQjNEJcAfZQSFRpBxnWNHWxPgnGHIotmvRFspslKaROfgsivjwwfgmBbJLQgjkaNoFC");
    int uSjTEK = -2121696278;
    int EpdlovjmXeGJUEWR = 1733620344;

    if (GQgzjjjfKQzdOpfu == -2121696278) {
        for (int cmJCIcAmPycEfhi = 658832495; cmJCIcAmPycEfhi > 0; cmJCIcAmPycEfhi--) {
            uSjTEK *= uSjTEK;
            uSjTEK *= EpdlovjmXeGJUEWR;
            EpdlovjmXeGJUEWR -= GQgzjjjfKQzdOpfu;
        }
    }

    return EpdlovjmXeGJUEWR;
}

double YOEsAhbLJPsz::vtVeooWn(bool LljMVUm, int eagbkybUvNNAYFg, string YopdlxiX)
{
    int bIdQXP = -1081955613;
    double dfJIykRrQ = -578510.9305482176;
    string YHFirorRTwCO = string("vurPNeTFnPeSXRNqtHMEypimecdMFwgsTFLWWZZRWMVSZeuoWajYNGRVTnyZJdDzehffGnwwSDsccCqtQzYvXxOdMYqfHjtHSOgSjpkwQvcMtgSmRrOhVVHQihKjaEribUdTKdsJMQZafKXovzXpvHuwusqrtdpbLlpKDcyPJEgCxuqFfDtdHhLHvMoRzrIQBvcOCEivyXcfxYydAfmsqVutZyydwLOJf");
    string uJalYxMUjOoIU = string("wwLzSdKEdJeIKtQpNTjDXmQHeRbxfelXHLHeNurjGMFbzwnKURhOOUdSlqLgkENouJVsyNrTEALOulqXgjtvtzHfsLDvFYRLwJiuynRbcZaOvGCaAiVFqJFpzDyFNqsTIngFVIRytBXBcGuRFblnHzVGPCZTxAdMbiGOAYhcKuSTOZmskaWlCBFKmnKZvLfQOZhQJeaePUCnAWLBNufjlShplSlJPhzHIWdzsqFhAKgXVoGfZMujPqJU");
    int QVUrqahVppNzG = -1018489221;
    int sLWSDMGNu = 1295271788;
    double uIpvstMDNRREu = -407063.05358055653;

    for (int dLGrMEOLMyXLTwCg = 1851931453; dLGrMEOLMyXLTwCg > 0; dLGrMEOLMyXLTwCg--) {
        continue;
    }

    return uIpvstMDNRREu;
}

void YOEsAhbLJPsz::PxNpa(int bhBLIVAIqPNf, bool FvkQDJ, int FuWbljh)
{
    string qSYZDzkEMAouXmbY = string("IsNWsBaECzEpLbEfbbAnhCxIgIQJlnTEiFyqGABCTShGyiXAXfBcGgdBqhDbtEAMRZyAhIsdvThqActxVKRfjWhIcNOjdcasmPknAtEBzgrVfHZanmWLDYinmDRDIMPxpaHbzFGDazLJgLu");
    int fzaFlb = 1858207057;
    int SBiGh = 1490791792;
    double TLXOdwVbxe = -14482.612219233846;
    string cMGhpoU = string("vlJwxicxUFmFPADYGjIunhsTkutPpMqRqaFSCrJuiRAfIUpR");
    bool hDgZWwxaz = true;
    bool DPoVfLWHhXzPFGL = true;
    double shSxJE = 197598.38545069163;
    bool byOWlJkIK = false;

    for (int KydQQW = 1113882939; KydQQW > 0; KydQQW--) {
        DPoVfLWHhXzPFGL = byOWlJkIK;
    }
}

YOEsAhbLJPsz::YOEsAhbLJPsz()
{
    this->luosx(-917252603, string("oXIZIgQbIcCSStWqpVRrDXhzjCADWXNifEXSHXN"));
    this->PmyEL(-1363919609, -2075390532);
    this->jnhEdRKLCye(197035.07166184232, -1405263335, 5478.955125253582, true);
    this->WicHPOluFDzfZdg(757178.0465994113);
    this->jZHLlqWBcsqrZV(string("jcCkcibRKVZMPHzpgQwPCDfmcXFbmgZFXNFGDaGfDFLKNPpOjjvQnvWiJmXptQxftZFoFHNbtFYjdsPWTfdlonAvJlwgsyoCKhgezSGjeppJKRyPirHnSskAafiSYwSfaDTjAqamUVVdWKysKmbqURHwfDKxYAXWKSTTJvbLDaxzYhVEEHeGYPxlGkHMYdWCnUCyvrhtCHHuhfYnltKZlOmItXGfchUh"), -650096.7040017069, -637951.5230516766, string("IWeICDMHDvSGOWpb"));
    this->XVAPmDJFkSZxG(true);
    this->ejzui(956321.0578787408, -406460.63334920007);
    this->UssYVLekskzRcqvH(string("QWmZguFgwRYffQvohhiJmLCvfjdavuhArnhVIQtpAGsFpASqFFNHEyJlUmdiWcpxDlXFvfSZYcaPDLlnZSKimhcPFOzjhsfd"), string("HOJNVgGLfuJwUYFEXeENfslpKtwpxEPMDLNolVhcwEmdOgOnJAUWHfaBZzAcNXBFuWtUpWrAhGHsNdtddvkbfYHgRqIrFKVcvmGXZGdAwsJaeSQOWmbpYYyPsqWQTrphAKzQOqueIYerqpzDUAIdOalBzyPHvHpqZSmYqFoulfGQEmaJnblWTANYZhcMkSzSQhfeNefQTsOdkqWo"), true, 731710581);
    this->wxtHAAANrT();
    this->QqyGq(-1283213122);
    this->mlwwBRlDbpeua();
    this->XgbZLUisjPpCIn();
    this->vtVeooWn(true, 245635010, string("VxwWloQBkkVTQUcDEtAxZqrgEQXluvzMQPuBYGnNzfCZWOhHpovfEnBUgFzntGoWqdfgYGaIzoINxRqTqWUKusEWaxDhJBThBrgbbQOJIdQjVdmCQFaNYevrkhQRj"));
    this->PxNpa(782179982, false, -1180990224);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IZnTrXCO
{
public:
    int qewlqzWoV;
    double JbYCrvDDon;
    string dGBAZoFazFne;

    IZnTrXCO();
    int mueLbYJiDjkuYwh();
    bool cnEJqJSdlBeFkId(int NBQapxH, string gXXBb, int AHOOX, int pwcciB, int WIaToAw);
    string eiZrSOYtuTMzVInp(double dUokDKCOXHmfojU, bool euKzKwPSQwYliL);
    string KGCUXs(string OpuHtOyc, string ULhOMzfbJJbMpAT, string UeuwgahROOhu, double nNgBcSoSn);
    double cAxnvame(int WtMWpImmOSvyzSm, bool zTYVw, double qqiJwUsOr, string GOEybiysAOBUHVX);
protected:
    bool BOiPrBKk;

    double cdbCdV(double uxRmDbQSRhwk, int ozAncPOL, int AyhDnbTHBZRb, bool nXZCAymfD, double lcoQqmiPnU);
    string GZenaneLRQsVJh(int jCrnAp, double YyeTXihtQWGp, int KnPDERLofHytvua, bool MEGllKKYrRiPkgAd);
private:
    double QnQFOCvDwQ;

    void YziyJCi(string JWGcjetbi);
    string uEKeHqvAE();
};

int IZnTrXCO::mueLbYJiDjkuYwh()
{
    bool TzdNoRKNaNs = true;
    double SozYMsdeTiZSjFn = 302000.1094000651;
    string cEwuu = string("cDWk");
    int RxtaBNTOymmmnc = 255860967;
    string iNKYzEcrLJqHK = string("oQgNIRednsdUdNpEgKIFCcZscYARvaqWUtJdfPQkuvDwTPSRtDYpFjTBVWgXIgtXqxOMIEiqqgDoowyzPcHjBHcAQBLMbkVvtWPcqgLrbhrecLSLQpFLflpcKfbPwdAmkECuTLeFhiSBfGDjw");
    double PXCioUammdOwN = -484821.26820973103;
    int wxuYxZDiGt = -157046590;
    string gyAqeNxnGBai = string("nsMiAjGn");
    bool JktLjiCJAAKjAq = false;

    return wxuYxZDiGt;
}

bool IZnTrXCO::cnEJqJSdlBeFkId(int NBQapxH, string gXXBb, int AHOOX, int pwcciB, int WIaToAw)
{
    double aLCBebPSkUKuOau = 615263.8430563327;
    bool WnDSSfumJ = true;
    double JRGiu = -885953.5025511417;
    string JoSrFeBGFZBPjK = string("HZPxyZiuegloKwjOUkyXLLoSqaIYIeYrCwGqOtRSjbdcnZKytGOxhsTIvwIgbxzZiVEiVtvqIfggnJMFATnuwSWsytayrKFcvlFNjUXlywysSOfverDbk");
    int DjiTgRfFrhcveVro = -189562613;

    for (int BxJWNhnOqabjl = 103574962; BxJWNhnOqabjl > 0; BxJWNhnOqabjl--) {
        gXXBb += gXXBb;
        NBQapxH -= NBQapxH;
        NBQapxH = DjiTgRfFrhcveVro;
        WIaToAw *= NBQapxH;
    }

    return WnDSSfumJ;
}

string IZnTrXCO::eiZrSOYtuTMzVInp(double dUokDKCOXHmfojU, bool euKzKwPSQwYliL)
{
    string irEBDvBJcIZOh = string("FHcsZgeCxcAGtrhEjYePMJAGLwuNPeaSigutGxtPozdjAlQlDEYCkCkrIdHjpUwIQOeIuUahTiiOhelxDWMhOWtXViuupmPeXlBkWvWGBtXAQlIuyQMisiLrChkigMMohcivvspiajkrOsNEqHzGbHPVBNZyMXkEFEPBWorqTSTbNqIxYgoEXiFomEtyLqwyY");

    for (int CCmvMMpdLeDCSHc = 962214119; CCmvMMpdLeDCSHc > 0; CCmvMMpdLeDCSHc--) {
        euKzKwPSQwYliL = ! euKzKwPSQwYliL;
        euKzKwPSQwYliL = euKzKwPSQwYliL;
    }

    for (int WxiiFM = 127178459; WxiiFM > 0; WxiiFM--) {
        irEBDvBJcIZOh = irEBDvBJcIZOh;
    }

    if (dUokDKCOXHmfojU == 576685.5114110899) {
        for (int fyycodjDJZ = 544951201; fyycodjDJZ > 0; fyycodjDJZ--) {
            euKzKwPSQwYliL = euKzKwPSQwYliL;
        }
    }

    if (dUokDKCOXHmfojU == 576685.5114110899) {
        for (int jUrANiIgkBxLOT = 111642226; jUrANiIgkBxLOT > 0; jUrANiIgkBxLOT--) {
            dUokDKCOXHmfojU += dUokDKCOXHmfojU;
            irEBDvBJcIZOh = irEBDvBJcIZOh;
            irEBDvBJcIZOh = irEBDvBJcIZOh;
            dUokDKCOXHmfojU *= dUokDKCOXHmfojU;
        }
    }

    for (int SqcAdbAFQQBd = 1067980863; SqcAdbAFQQBd > 0; SqcAdbAFQQBd--) {
        euKzKwPSQwYliL = ! euKzKwPSQwYliL;
        euKzKwPSQwYliL = ! euKzKwPSQwYliL;
    }

    return irEBDvBJcIZOh;
}

string IZnTrXCO::KGCUXs(string OpuHtOyc, string ULhOMzfbJJbMpAT, string UeuwgahROOhu, double nNgBcSoSn)
{
    double sTBOvwt = -287367.78870397434;
    int yNwNnZ = 447632985;
    double Uqbwk = -391969.50315451075;

    for (int XgbJZX = 1502535850; XgbJZX > 0; XgbJZX--) {
        Uqbwk *= nNgBcSoSn;
    }

    for (int NrDEynjtACNbI = 1351610925; NrDEynjtACNbI > 0; NrDEynjtACNbI--) {
        continue;
    }

    return UeuwgahROOhu;
}

double IZnTrXCO::cAxnvame(int WtMWpImmOSvyzSm, bool zTYVw, double qqiJwUsOr, string GOEybiysAOBUHVX)
{
    int exJuWcxCYlzeZ = 1431868939;
    string omTryKOQqRtsP = string("KnavrYKReBoerXbhnX");
    string pJwiEMWcv = string("IDebdDTnEekpWtqhhlGzBfYgvuvsCaPNwBFg");
    double HxASDep = -209999.90892821935;
    bool RkwTLHhrkwhIhdxZ = true;

    if (omTryKOQqRtsP == string("DczzprRhkxnkaybrgnOAdZpXKswYqKRQIFvNYvq")) {
        for (int sxdgdvWEDinldK = 563776985; sxdgdvWEDinldK > 0; sxdgdvWEDinldK--) {
            pJwiEMWcv += GOEybiysAOBUHVX;
            GOEybiysAOBUHVX = pJwiEMWcv;
            pJwiEMWcv += GOEybiysAOBUHVX;
            RkwTLHhrkwhIhdxZ = RkwTLHhrkwhIhdxZ;
        }
    }

    if (qqiJwUsOr != -410745.98064594506) {
        for (int JuhwdNumLGf = 158381375; JuhwdNumLGf > 0; JuhwdNumLGf--) {
            continue;
        }
    }

    for (int ccXxf = 816946211; ccXxf > 0; ccXxf--) {
        GOEybiysAOBUHVX += omTryKOQqRtsP;
    }

    for (int xFzWaLdCsQ = 1633822042; xFzWaLdCsQ > 0; xFzWaLdCsQ--) {
        pJwiEMWcv = omTryKOQqRtsP;
        pJwiEMWcv += omTryKOQqRtsP;
    }

    for (int CqswCuqAgoAgBr = 375249662; CqswCuqAgoAgBr > 0; CqswCuqAgoAgBr--) {
        continue;
    }

    for (int YxvBnvskVi = 5757211; YxvBnvskVi > 0; YxvBnvskVi--) {
        RkwTLHhrkwhIhdxZ = zTYVw;
        HxASDep += HxASDep;
        GOEybiysAOBUHVX += pJwiEMWcv;
        omTryKOQqRtsP += omTryKOQqRtsP;
    }

    return HxASDep;
}

double IZnTrXCO::cdbCdV(double uxRmDbQSRhwk, int ozAncPOL, int AyhDnbTHBZRb, bool nXZCAymfD, double lcoQqmiPnU)
{
    double mjfFMhmnFU = 207577.8635440228;

    if (mjfFMhmnFU <= -211938.83024829894) {
        for (int uQuNTquCiEXvi = 833456621; uQuNTquCiEXvi > 0; uQuNTquCiEXvi--) {
            uxRmDbQSRhwk = uxRmDbQSRhwk;
        }
    }

    for (int vYawHnEKOtL = 1424277160; vYawHnEKOtL > 0; vYawHnEKOtL--) {
        mjfFMhmnFU += uxRmDbQSRhwk;
    }

    for (int ZvVJZyb = 1318696991; ZvVJZyb > 0; ZvVJZyb--) {
        continue;
    }

    for (int WtanegR = 566531933; WtanegR > 0; WtanegR--) {
        AyhDnbTHBZRb -= AyhDnbTHBZRb;
        mjfFMhmnFU *= lcoQqmiPnU;
        lcoQqmiPnU /= uxRmDbQSRhwk;
        AyhDnbTHBZRb /= AyhDnbTHBZRb;
    }

    if (ozAncPOL <= -442985689) {
        for (int rggPnFPUAtf = 1205106037; rggPnFPUAtf > 0; rggPnFPUAtf--) {
            continue;
        }
    }

    for (int JfRQIXr = 2018857287; JfRQIXr > 0; JfRQIXr--) {
        continue;
    }

    return mjfFMhmnFU;
}

string IZnTrXCO::GZenaneLRQsVJh(int jCrnAp, double YyeTXihtQWGp, int KnPDERLofHytvua, bool MEGllKKYrRiPkgAd)
{
    double cAfFFiMQrtvi = -466763.0264157728;
    bool nQJwMIe = false;

    if (MEGllKKYrRiPkgAd != false) {
        for (int HfhFMYir = 10474552; HfhFMYir > 0; HfhFMYir--) {
            KnPDERLofHytvua -= jCrnAp;
            cAfFFiMQrtvi /= cAfFFiMQrtvi;
        }
    }

    if (cAfFFiMQrtvi != -22901.5601480322) {
        for (int uolBLzg = 554500487; uolBLzg > 0; uolBLzg--) {
            YyeTXihtQWGp -= YyeTXihtQWGp;
            cAfFFiMQrtvi -= YyeTXihtQWGp;
        }
    }

    for (int SGqeLwiyraIv = 519320312; SGqeLwiyraIv > 0; SGqeLwiyraIv--) {
        nQJwMIe = MEGllKKYrRiPkgAd;
        jCrnAp -= KnPDERLofHytvua;
        YyeTXihtQWGp *= cAfFFiMQrtvi;
    }

    return string("poXKQhfDjXdQehVnOJtqxVMJlbGuqPZcRPqKEvPltvwcqOjDyNyFjIxjKvBFOJuzlvDsKYTLGkseGOreqSKUGgspTOkuudmlYglQyUVZfHdZcdEXMubAxrWpkVDeZJypPtuZqCbGiLCVxgZvneKJgSWtaxQIKrxNDfJWByZdVmjOtAyYUgXndBgQniCyeoKVLatLT");
}

void IZnTrXCO::YziyJCi(string JWGcjetbi)
{
    int IyfHKSOVPMzVg = -410651604;
    double xuegNGZyRJZTg = -492610.8710923808;
    int ZHuVeKb = 1460507409;
    int AJNyXXjyUTNxha = 728433620;
    string eGDbOoEUqhettV = string("DhZSbVXQjBfELBtTkWEwkpCooVptSZJkGMLzZGTFiHQWwcQcnjWdwcrgEhIERFjVepolsDMGRQSMIeVJeTXLflOUQPlvBQBmIeAoaYLzgIDRkgxLEwKYGrigjkYvsfUtUxSTgstSrjSRURGEjtRYbvyLNNwCPPZaLhhFREoxjpkpqoQjlLRqFbulMxgISbGzFmIPIxZjUYHQHFCBjtuTJwtvcGFfckmGGIZ");
    double UYOKxUKlD = 202873.20016435988;
    int mffBBkpbRgAnTB = -8137132;
    string lFVkFOh = string("KfUeuoZADijbUCxNfOgDUrORkUXddqAUbpdSJkNFZYDAEkFAmuU");
    int dAdlvWBafRqDlv = -560592512;
}

string IZnTrXCO::uEKeHqvAE()
{
    bool CIkIkxpHxw = true;
    int QTRsTo = 302617523;

    if (QTRsTo > 302617523) {
        for (int PrphNkGHhiZ = 819361874; PrphNkGHhiZ > 0; PrphNkGHhiZ--) {
            CIkIkxpHxw = ! CIkIkxpHxw;
            CIkIkxpHxw = ! CIkIkxpHxw;
            QTRsTo /= QTRsTo;
            QTRsTo += QTRsTo;
            CIkIkxpHxw = ! CIkIkxpHxw;
        }
    }

    return string("mriTgkJHxwNuZdlnvfkLJeUwqPoLXdvKAD");
}

IZnTrXCO::IZnTrXCO()
{
    this->mueLbYJiDjkuYwh();
    this->cnEJqJSdlBeFkId(-1916962074, string("IhxLqyniKKabfwCMtDHvrmPlCawvnbiZEBybQTwHICMvsCKKGkqCtKmLYCaEoEPNpohVIHGvPdbQWZGbifmcUnFmbSuGLprEvhfFvwYorWVuMsBuSALNYUUFTMvxpqjZVgzeyDWAAsDdmIzoZqNEUBE"), 1695433164, 314948526, -521533158);
    this->eiZrSOYtuTMzVInp(576685.5114110899, false);
    this->KGCUXs(string("TZRmvrWayLuOwkwFt"), string("mofAsCxGSrsNzuQRoeSaNuZrpjNAAOSrbQREGyNlHzbBhUQgcnMXXVvhEQPrOBWEszhleHekCLrmZMYEGixKwuZjwKdfIgBPdbXJBIaGEFTURmbJknjBfflxtYFQamqSRLAlthGdbpaJJaOLYARSsmZiwuJejoxsUFdGsBjTXMWeqnfTzpzUfBiCDOamgainGvyaIifWd"), string("mrDRDMVPLqzgbxLQYaqTYnCEiRBYGLKsxTVoRsxOvuDsFvoJewYNQEpfBKshMRrJMNKAPLCSQgaMWcwWRApieSFCDSOaGbxchiJFbhGJDwhuyFymZMhfSpGegECasLEHGsxqxcjTxThxKkAUsLixjAPeuttTioovxBAcYSRUIWQBHgtQKkEqdwgqIXDpLdgVtKkAqztwtjccGxYdyLurNiKUj"), -753280.9477728951);
    this->cAxnvame(1654420, false, -410745.98064594506, string("DczzprRhkxnkaybrgnOAdZpXKswYqKRQIFvNYvq"));
    this->cdbCdV(195191.17822993235, -442985689, -745036041, true, -211938.83024829894);
    this->GZenaneLRQsVJh(-554336089, -22901.5601480322, -932878199, false);
    this->YziyJCi(string("RO"));
    this->uEKeHqvAE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ijOolylFxAehlA
{
public:
    string gUAmXOe;

    ijOolylFxAehlA();
    void XqgaVeOosvCkUOVt(int DqcPbKJChUvrAfRz, int XhsTfpHFhdQ, int zfQJOxDde, double VcwqdeJcx);
    double vFRKPkGIH();
    int GclQsYKsyDGdVg();
    void LqkwkYhyQDfvGEQ();
    void fNdvQoyna(bool XFOtIynPTQFUFec, string uuzFZlc, bool JCqjjjXyKoTp, int rysVeFBN, double vtxHKkkAJirP);
protected:
    bool vsZgaVg;
    string BVgJPRivt;
    bool GjnINvlY;

    double kvzSurcvZIUsFJF(bool QoBedVrSW, string gRIYp, bool FeBUYqFWafEWYofY);
    bool dBZdeb();
    void KEiKnpqBmQNRt(double EGzKrQnzRXD, int WOJRjICtNO, bool BKJkJDxICdlZ, double fgTrEAtgGYAq);
private:
    bool eEoTKNkYBIL;
    int OENShgaUnSbY;
    double ptiOb;
    double YRZbIrXAZdkPh;
    bool pVloxgsrtrzqw;
    int nkmnFJJrucYHu;

    int JjFnFezCbn(int XoWhSfNXBaPO, string viXjKJ, int GgRBHMgEbtWU, bool ZkCbXvuCLBSw);
    void uzqlIgmlqOpr();
};

void ijOolylFxAehlA::XqgaVeOosvCkUOVt(int DqcPbKJChUvrAfRz, int XhsTfpHFhdQ, int zfQJOxDde, double VcwqdeJcx)
{
    string rqkxkECiiufYq = string("qlCwtYklOFbDpGWYBiVRVtzGbOYmewmdmKMEkdKYMEGudmWxkawcCZNaRB");
    int uzOMCdA = 1268540564;
    double lNPJQpmTmfmwQtL = -878886.5078593665;
    string jVcbUXLSiwVK = string("RYcKGqpdYxSEOsiMnOCiaWlgrKAfRychnLYGIKVXNOxeCdeqVGeDFUfoddJeJrEwNxknNuXHoooGvVqBlcYuaBrwtUeFSSHHbCtNHLXvFWVJzNipqnrZzlhakInxniWQKywDvxYEcmaVJMNgNheviTpzpZNxdYymTALknNspcGGR");
    int oyYSFkeW = 914772355;
    int DwWlYc = 259060996;

    for (int SWkhTdX = 912562416; SWkhTdX > 0; SWkhTdX--) {
        DwWlYc /= DqcPbKJChUvrAfRz;
    }

    if (XhsTfpHFhdQ != 914772355) {
        for (int gjcypakvlStfV = 537151573; gjcypakvlStfV > 0; gjcypakvlStfV--) {
            rqkxkECiiufYq += rqkxkECiiufYq;
        }
    }

    if (DwWlYc >= 914772355) {
        for (int EtSrtNxFcS = 1542423228; EtSrtNxFcS > 0; EtSrtNxFcS--) {
            jVcbUXLSiwVK = rqkxkECiiufYq;
            oyYSFkeW *= DwWlYc;
            zfQJOxDde -= XhsTfpHFhdQ;
        }
    }

    for (int uxiBRJdfBaMOVQ = 712264145; uxiBRJdfBaMOVQ > 0; uxiBRJdfBaMOVQ--) {
        rqkxkECiiufYq = jVcbUXLSiwVK;
        XhsTfpHFhdQ *= zfQJOxDde;
        DqcPbKJChUvrAfRz -= zfQJOxDde;
        uzOMCdA += zfQJOxDde;
    }
}

double ijOolylFxAehlA::vFRKPkGIH()
{
    bool ShJyiAo = true;
    string hdJvdKKI = string("bvzQCRYVAaMCzSKcWqCfwbOQeHjHiEwvxmjUweLCwQIrEhEAUdPtdBCbQWlAzrGhbclCaVcxZAvTVvdiVhrDxEXVuKnAiwiNKUaeXYOWZUzTJCPJxPeEizmLTTGEppYFsERALgAYXsy");
    bool IDnUjmCWqRBD = false;
    string SSUrwMIwy = string("VBOeeacXbhbIjMJRVJBkNiomYUbfSAraCLqUIPfObPXmnVVMTtTZqaLKrAEQwcxRTFUahKeYXtwGCDMmDcKHF");
    bool IYYUIEyJajnFEtj = false;
    bool djiHiBJGeuelkvwA = false;

    for (int CetNlDoMWBc = 2130109123; CetNlDoMWBc > 0; CetNlDoMWBc--) {
        djiHiBJGeuelkvwA = ! IYYUIEyJajnFEtj;
    }

    if (IYYUIEyJajnFEtj != false) {
        for (int KAdTSiO = 500160412; KAdTSiO > 0; KAdTSiO--) {
            djiHiBJGeuelkvwA = ! ShJyiAo;
            IYYUIEyJajnFEtj = IYYUIEyJajnFEtj;
            djiHiBJGeuelkvwA = djiHiBJGeuelkvwA;
            SSUrwMIwy = hdJvdKKI;
        }
    }

    for (int lcBUS = 422382931; lcBUS > 0; lcBUS--) {
        djiHiBJGeuelkvwA = ! IDnUjmCWqRBD;
        IYYUIEyJajnFEtj = IDnUjmCWqRBD;
        ShJyiAo = IYYUIEyJajnFEtj;
        ShJyiAo = ShJyiAo;
        ShJyiAo = ! IDnUjmCWqRBD;
    }

    return 346267.8371844811;
}

int ijOolylFxAehlA::GclQsYKsyDGdVg()
{
    bool jMdwB = true;
    bool lcNfYVnsjRuc = false;
    int XOOGkPAMaYL = 1924939044;

    if (lcNfYVnsjRuc == true) {
        for (int xpCosdZ = 641728444; xpCosdZ > 0; xpCosdZ--) {
            jMdwB = lcNfYVnsjRuc;
            lcNfYVnsjRuc = ! lcNfYVnsjRuc;
            jMdwB = jMdwB;
            jMdwB = ! jMdwB;
            lcNfYVnsjRuc = jMdwB;
            lcNfYVnsjRuc = ! lcNfYVnsjRuc;
        }
    }

    if (lcNfYVnsjRuc == false) {
        for (int rCyVSS = 535063099; rCyVSS > 0; rCyVSS--) {
            lcNfYVnsjRuc = jMdwB;
            jMdwB = ! jMdwB;
            jMdwB = ! jMdwB;
            lcNfYVnsjRuc = lcNfYVnsjRuc;
            jMdwB = ! lcNfYVnsjRuc;
        }
    }

    for (int QCceRR = 1136084150; QCceRR > 0; QCceRR--) {
        continue;
    }

    return XOOGkPAMaYL;
}

void ijOolylFxAehlA::LqkwkYhyQDfvGEQ()
{
    int iXPlYkcnpUNLwsh = 85703851;
    double BuNyjbpMEfBVPvo = 616009.2431124108;
    bool CHRZXQatPs = false;
    double cmQwFNq = 516845.49705506733;
    bool IEzQhuMpcVLxzr = false;
    double mMbLKIXhaany = -105056.73783040393;
    string lvPxbBx = string("HHDmIYYYbmFZcffWUhwBshonOPxZaPEdsuLNMSUazKJOCCUSeaCJQLnjsYOAHMQgpwaMVVmLgNSdfSzzwVbSbgSVfGuWMGappzeXZoiuSaFZMEDxBKuYmyqez");
    int ztnnOwGwnaP = 896313553;

    if (IEzQhuMpcVLxzr == false) {
        for (int AeWHJnuXuxLQoA = 1616924016; AeWHJnuXuxLQoA > 0; AeWHJnuXuxLQoA--) {
            continue;
        }
    }

    for (int gVJtxlAwYbqrcCm = 617860807; gVJtxlAwYbqrcCm > 0; gVJtxlAwYbqrcCm--) {
        ztnnOwGwnaP += iXPlYkcnpUNLwsh;
    }

    for (int qBpOhCiMwFK = 118529433; qBpOhCiMwFK > 0; qBpOhCiMwFK--) {
        BuNyjbpMEfBVPvo *= mMbLKIXhaany;
    }

    for (int CgJkIUFCUNWlWkHd = 1617522862; CgJkIUFCUNWlWkHd > 0; CgJkIUFCUNWlWkHd--) {
        cmQwFNq = cmQwFNq;
    }
}

void ijOolylFxAehlA::fNdvQoyna(bool XFOtIynPTQFUFec, string uuzFZlc, bool JCqjjjXyKoTp, int rysVeFBN, double vtxHKkkAJirP)
{
    double sABoLo = -957592.4003387396;
}

double ijOolylFxAehlA::kvzSurcvZIUsFJF(bool QoBedVrSW, string gRIYp, bool FeBUYqFWafEWYofY)
{
    bool EXMNuIpIpa = false;
    double jItYAIDBxpWFk = 481470.390632595;
    bool JrOegrQUBlwQSL = false;
    string xfcyMmXchsxRfp = string("ixjzcJwOyqnfcaXlctkwbLngtPoSGNNMUkbBblxEnhMfqKQujPmYiuGFJXVXsiwpNUjujxxnZeKHyrIbHddhlXeiDhqTfcvsxIHUpTYpcGeRSnebjhbgSksSDmrmMFIlDIXiMvXjuPBdjhbrKKKNFozMWZuSzkeMyuvBtabRsDAExFKGgtmBexafsViyIhMnWotYgEpLxqEYjPrOaGaGrLAayPtDnZRgz");
    string iHIMMGdKgaeSRk = string("XxKyFhFHodTFrFnlQUeLDOYEsbSrWjxOgAOrImyQgbqSGXFgeadntPeUqdSiDpWpiMguCbDrFdllLWJgSKBWPPssPsrsnneXKqBJaHUnPYzwWYkAmGEZZKWNxljvUWoHYtGHnDFkCUtNrYvpdHeDUhxokbAqECTKiBWmZmKsDAdMKUxFpCSpfDGdbsgdaqBBsfpupEuWWcTkGHjiCtZijRsSkDIDpUzqSyRgBTkiIWNSsgmLU");

    if (QoBedVrSW != false) {
        for (int HsNwMbCjRQPeb = 312096812; HsNwMbCjRQPeb > 0; HsNwMbCjRQPeb--) {
            continue;
        }
    }

    if (EXMNuIpIpa != false) {
        for (int YgixjCOpo = 688496275; YgixjCOpo > 0; YgixjCOpo--) {
            EXMNuIpIpa = ! EXMNuIpIpa;
        }
    }

    for (int YnLWUhdIBB = 775652488; YnLWUhdIBB > 0; YnLWUhdIBB--) {
        gRIYp += gRIYp;
    }

    for (int jWhHxpw = 1730108753; jWhHxpw > 0; jWhHxpw--) {
        JrOegrQUBlwQSL = FeBUYqFWafEWYofY;
        FeBUYqFWafEWYofY = JrOegrQUBlwQSL;
        xfcyMmXchsxRfp = iHIMMGdKgaeSRk;
        QoBedVrSW = ! EXMNuIpIpa;
        FeBUYqFWafEWYofY = ! EXMNuIpIpa;
    }

    if (gRIYp < string("ixjzcJwOyqnfcaXlctkwbLngtPoSGNNMUkbBblxEnhMfqKQujPmYiuGFJXVXsiwpNUjujxxnZeKHyrIbHddhlXeiDhqTfcvsxIHUpTYpcGeRSnebjhbgSksSDmrmMFIlDIXiMvXjuPBdjhbrKKKNFozMWZuSzkeMyuvBtabRsDAExFKGgtmBexafsViyIhMnWotYgEpLxqEYjPrOaGaGrLAayPtDnZRgz")) {
        for (int FjQthebW = 194256222; FjQthebW > 0; FjQthebW--) {
            EXMNuIpIpa = JrOegrQUBlwQSL;
            QoBedVrSW = JrOegrQUBlwQSL;
            xfcyMmXchsxRfp += xfcyMmXchsxRfp;
            EXMNuIpIpa = ! QoBedVrSW;
        }
    }

    return jItYAIDBxpWFk;
}

bool ijOolylFxAehlA::dBZdeb()
{
    bool PhObdRRar = true;
    string IbCeOqqzeUmDea = string("jSvXFuJNlYHyvrtskixcxhwUhdPuXtjdiquKoozsuNHsoOWtjkFjueIBoxu");
    bool VdlbwxUM = true;
    string rRicWErCAVoGShG = string("QLFIoiaPcNPazvGztFUuyuLZeApmWxTGQZUVZGEIeUIYV");
    bool mLiKXteMspqNdJ = false;
    int mLckxJIlP = -1532734488;
    double jwApFPvUVv = 175694.16448985625;
    string tHWqfCZREecCW = string("qRgvGQAwOiOdEuwTBKOEUGGDPgOYaUXyoZnjNRinhNfaDfwDPsdCENJHrrPCPMNCgwUxIdKamxmPhnwGPkMOMcZBIhYVHIlxfOOsNBiDPrE");

    for (int XKxuktWmqHL = 844802366; XKxuktWmqHL > 0; XKxuktWmqHL--) {
        continue;
    }

    for (int ognSZbmFky = 661201820; ognSZbmFky > 0; ognSZbmFky--) {
        mLiKXteMspqNdJ = ! mLiKXteMspqNdJ;
        mLckxJIlP *= mLckxJIlP;
        PhObdRRar = ! PhObdRRar;
        mLiKXteMspqNdJ = ! mLiKXteMspqNdJ;
    }

    return mLiKXteMspqNdJ;
}

void ijOolylFxAehlA::KEiKnpqBmQNRt(double EGzKrQnzRXD, int WOJRjICtNO, bool BKJkJDxICdlZ, double fgTrEAtgGYAq)
{
    int EhzHPYukIQhLRXpK = 1891917443;
    bool hNCvuFlAFq = true;
    string JTjGpAp = string("TbLdBgbbDXFjdBbXgMeORXkrkaVJprJKvDJvNSZJDeIJxQCyvWixJAHwtNXVOPjFbNnKuETXsUhRYdhoEgFIMqkpFfUrkaDJZSFBffEjZTpGNVHpTabzIQwASnQpopCqQVGasfeAfKMfjwracHMEuLbgWyNbFIQErIZptgwMOrtIAAJfVKcKqRkuHVvzmLmoHkrIegbkTmnAAuygdWfvcdXcjllKVnWrmtVvyEdrJhHmrHor");
    string VVrpqSGitiGunWnD = string("LWmDURUnEMuqhbOAXojThCepQLgDDZNcDoovIYPorDUnTJjiSOhowvfiTOIcPiswByHALPMyqIQpYlzPhiti");

    for (int jhAciUaDJ = 15618083; jhAciUaDJ > 0; jhAciUaDJ--) {
        JTjGpAp += JTjGpAp;
        JTjGpAp = VVrpqSGitiGunWnD;
    }

    for (int nbUBBxLHHOJ = 1759747442; nbUBBxLHHOJ > 0; nbUBBxLHHOJ--) {
        BKJkJDxICdlZ = ! hNCvuFlAFq;
        fgTrEAtgGYAq -= EGzKrQnzRXD;
        EGzKrQnzRXD += fgTrEAtgGYAq;
    }

    for (int ohgFWeIxAlrc = 1704092700; ohgFWeIxAlrc > 0; ohgFWeIxAlrc--) {
        continue;
    }

    for (int dIrtnbvYiatH = 749498482; dIrtnbvYiatH > 0; dIrtnbvYiatH--) {
        fgTrEAtgGYAq /= fgTrEAtgGYAq;
    }

    for (int LjtSaUhzR = 1335433255; LjtSaUhzR > 0; LjtSaUhzR--) {
        EhzHPYukIQhLRXpK /= EhzHPYukIQhLRXpK;
    }

    for (int ACtZO = 2112439705; ACtZO > 0; ACtZO--) {
        EGzKrQnzRXD = EGzKrQnzRXD;
    }
}

int ijOolylFxAehlA::JjFnFezCbn(int XoWhSfNXBaPO, string viXjKJ, int GgRBHMgEbtWU, bool ZkCbXvuCLBSw)
{
    bool dsWKXMDjZM = true;
    int PkBwmCCeNtUdvk = -1679735305;
    int RrtwBx = -1756374327;
    string oyNjlWdc = string("CAjGgxwIlekDURXRRFNgjOTn");
    double hefpYedgUyJIRiTB = -615228.2461868428;
    bool haXLJPfAo = true;
    int oBKVrLMCxIUTxH = 1704692851;
    int ppStNww = 406770442;

    for (int BcFZQXbddto = 763937055; BcFZQXbddto > 0; BcFZQXbddto--) {
        GgRBHMgEbtWU += XoWhSfNXBaPO;
        ppStNww -= PkBwmCCeNtUdvk;
        dsWKXMDjZM = ! haXLJPfAo;
    }

    for (int nOGrBdAOkMw = 1317310291; nOGrBdAOkMw > 0; nOGrBdAOkMw--) {
        ZkCbXvuCLBSw = ! ZkCbXvuCLBSw;
        dsWKXMDjZM = haXLJPfAo;
        viXjKJ += oyNjlWdc;
    }

    if (ppStNww == 1704692851) {
        for (int GLAGLHOO = 1794830420; GLAGLHOO > 0; GLAGLHOO--) {
            viXjKJ += oyNjlWdc;
        }
    }

    for (int cVqQtvobdzf = 1973385103; cVqQtvobdzf > 0; cVqQtvobdzf--) {
        XoWhSfNXBaPO /= RrtwBx;
        oBKVrLMCxIUTxH /= ppStNww;
    }

    if (hefpYedgUyJIRiTB >= -615228.2461868428) {
        for (int gRwYBrbtiYLjopkD = 1693425504; gRwYBrbtiYLjopkD > 0; gRwYBrbtiYLjopkD--) {
            continue;
        }
    }

    for (int aqferqbxEm = 1465055543; aqferqbxEm > 0; aqferqbxEm--) {
        continue;
    }

    return ppStNww;
}

void ijOolylFxAehlA::uzqlIgmlqOpr()
{
    double BEQYJsCGTwgsXNkN = 323104.3224873439;
    bool SsXuUhH = true;
    string avsGOsXNNdaU = string("ukmYzdCmuwProVwHXbZrbKHykGuKLaoRlXvXAAppFjmwXhIrVRTZknEogtPXTxhXRYctfmdUMoTSnnmvbzYvEMrzxOhvXkZZuHczIqN");
    double DVqkteQSAIrxEZX = 267584.6051101844;
    int FPcbrR = 1648339557;
    string YXNLypVYMrNVwUx = string("OZxAkMAIOVqSEhprmsULjHKKibuHzyiHAXfhLyilPvtiGFfFDDcRHVtLbICLhJVeDERcCkOzbvdSiVfqfiCkAyEsvQgsnmiRzoOsiMIaUydSMlnidgFQlnvAHehtzqWEVNtSieMVINymJpvnCGtIehXfFOgaCONYwPAdguHkISVIYLDnKK");
    int CXBnsJdpfKEjiv = -1761226272;
    string WKRKG = string("QBIAQzEUlQwyfdeuRxXkHuNdyqKXcsazFjyVArMBnpJkBrdEEixqFytJRQeOARuqEzyfhlpkaKIDHWQtXHsCHSWfyHtUZdlASaHRlyrJiGQRphXfNePqpRqdLaCnOVFmlKcneOHTFVRBJtbKHdXIulSKcMgcB");
    bool VSfTXSHsL = false;
    double OmsaAYFtEhMaSA = 905886.8305887795;

    if (DVqkteQSAIrxEZX != 323104.3224873439) {
        for (int FQWmiUjapQPW = 2027076003; FQWmiUjapQPW > 0; FQWmiUjapQPW--) {
            continue;
        }
    }

    if (YXNLypVYMrNVwUx > string("QBIAQzEUlQwyfdeuRxXkHuNdyqKXcsazFjyVArMBnpJkBrdEEixqFytJRQeOARuqEzyfhlpkaKIDHWQtXHsCHSWfyHtUZdlASaHRlyrJiGQRphXfNePqpRqdLaCnOVFmlKcneOHTFVRBJtbKHdXIulSKcMgcB")) {
        for (int XzUYbOSzkHpwg = 1716492497; XzUYbOSzkHpwg > 0; XzUYbOSzkHpwg--) {
            continue;
        }
    }
}

ijOolylFxAehlA::ijOolylFxAehlA()
{
    this->XqgaVeOosvCkUOVt(-1988156250, -1986857747, -1830296867, 196416.05274841574);
    this->vFRKPkGIH();
    this->GclQsYKsyDGdVg();
    this->LqkwkYhyQDfvGEQ();
    this->fNdvQoyna(false, string("TzfbRYYofTxwttnQXKZWokNovYiXrXVHMwbevRkfyUsaWWksGAvcjXGuotuwXYRKhahSYWaoWxLDLoSUGMQNkJJhZhcTTMZuyLwcZGnRpxiyPxiFboFGEPKzKBaXhMLewArBNyJAFMxuBFxFrTcpTLDOChLXYBlNtrEBxrEvDUtkmTUyBqBpCfOJKwEaiVXaFkWXbwClSnSqBSXKUAiQCAMAxbEUiMewyKyPOcABfChR"), true, -866407558, -692294.7696554259);
    this->kvzSurcvZIUsFJF(true, string("bpXzHlZZXQVPGJjpr"), false);
    this->dBZdeb();
    this->KEiKnpqBmQNRt(485617.6728118099, -1053569873, false, 207235.60803378202);
    this->JjFnFezCbn(-232782906, string("XpKqMixYRiMbzmXleBoWgpKDUUXtyUxpKybDvqZizpSPqoVDsYnTulsNAWwZIxhwuYpeAiQvxiuI"), -1235592729, true);
    this->uzqlIgmlqOpr();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cMdws
{
public:
    double IMFMOR;
    string eTJBOMNCPbCRTv;
    bool CeovvTVais;
    int AJTFHpRgNTsWLUWp;
    bool BDFCKjxMTkOIC;
    string uEuGAKEiBtpYnkaR;

    cMdws();
    string Wqjwq(string UQVBT, string fsqkNsqgvGLzndle, string UzKJPpgZIP);
    void FLRLnyQdDHLz(double GFkFx, double MJkMJaAQhaAiGc, int kCDMFfKmTlpesVV);
protected:
    int uPssgfu;
    bool PnuXikrRWdWKeVyC;
    double jswBvCGLMKWHD;
    int biCZGwHHRMjRGI;
    bool ddbrEQZInmEWlrpI;
    bool RfTBkrkL;

    double OItizWTKQ();
    int mZQRcwSGdTyxZ(double JphYqW);
    bool JfazkEbAwltib(string zuNNOXVctTlv, int QMTuAFVFAqKsjioo, double NtHuboJQUqOKx, int fBFrTCzr);
    string aMXZUp(int gupEjGTp, bool THPWybxTFcEKpYyI, string bFFZdaceiFESz);
private:
    double tGMlhxFgdUaGvy;
    bool LYrbWAyLymhcuRA;

};

string cMdws::Wqjwq(string UQVBT, string fsqkNsqgvGLzndle, string UzKJPpgZIP)
{
    double yqBYqe = 892349.6810181997;

    if (fsqkNsqgvGLzndle == string("jkbhICTzOypMSowdBQvrNzRpptLghTvFrsjhJchsnlCzGNUzWVPVgNeJUXVMjtdUpkQPiCVIYYqlxObqiIFQoMnFVHSfJGnhKtAyMOHmGdGWqYxGJuPZTiDPOcVVgTouqMwztVGPWaJUtWRqtdhmpSGvuxSgWmZprqmrwqvGDrrP")) {
        for (int xLZuJDLYnnkJmroy = 1011969637; xLZuJDLYnnkJmroy > 0; xLZuJDLYnnkJmroy--) {
            fsqkNsqgvGLzndle += fsqkNsqgvGLzndle;
        }
    }

    if (UzKJPpgZIP == string("eqdfYpNmnmQrgwvxYQNbIxePobUlTHUYtPAgVDITSciAyTrdGaXPqaCvKiwfenIJEvTLTJoSXgrJcOlyuVIfszXdeiyMYpUyMVRkxSSWNnOSEAuwZyAYxpYBUHbKWwXmgVSVfDhNvrndtWGIPFBBDnDLSgdbeFpTxbXxZIPHxANpRFUrwkieKdjSdrW")) {
        for (int GNdGjobWA = 376901055; GNdGjobWA > 0; GNdGjobWA--) {
            fsqkNsqgvGLzndle = fsqkNsqgvGLzndle;
            UQVBT = fsqkNsqgvGLzndle;
            UzKJPpgZIP = fsqkNsqgvGLzndle;
            UQVBT += fsqkNsqgvGLzndle;
            fsqkNsqgvGLzndle = UQVBT;
        }
    }

    return UzKJPpgZIP;
}

void cMdws::FLRLnyQdDHLz(double GFkFx, double MJkMJaAQhaAiGc, int kCDMFfKmTlpesVV)
{
    string AgIhW = string("RTEVknvEPUtRmnzCKHlATBtETVytBKEXyLYQjoEhNXJnGzZaeOlwgmsSEkWnmRoZVVIaKhrESgCREuVKKwzthMLpcgGdAiYIAhMHKyqJjPVVHaVSHnmgYclBajEikZqYrLSLIknPFbBRdGxiOSQMm");
    int dWHruqUDMEgE = -1114691305;
    double ehkyxVvwmPZMimJ = -203972.68500472617;
    double rkUdOg = -682824.8912065107;
    double IxNbN = 895140.7288248144;
    string KgaUCjfp = string("tBefSsDyUxzRKHCiuevVEtscqbXcJJfyJmiqIiPQDXJQxEFWraBbmLCsYmUNJhBjuBMwAsabQbIEVrKtnUURXPzDVMyUJwbqnEJeTtDZzWuCySwojNWcWCkwqUlRadhcKLPIdueHLPAHFATJYcRLaOcjnUSzSSvNNqKWWjVJeOiDTwsMRQURcJYUJBWoFocqLlhANTzcziugWXwpergbuDCmvRKxjdjupPdeJVZXoQHiaiTEFuyqXhXpvlzcRqd");
    int vzenYJqSo = 725014048;

    if (IxNbN < -956868.7002632709) {
        for (int qVnVs = 751049707; qVnVs > 0; qVnVs--) {
            IxNbN -= GFkFx;
            rkUdOg /= IxNbN;
        }
    }

    for (int qBYhDwacNTgoKvhQ = 1386301625; qBYhDwacNTgoKvhQ > 0; qBYhDwacNTgoKvhQ--) {
        GFkFx *= IxNbN;
        KgaUCjfp += KgaUCjfp;
        dWHruqUDMEgE = kCDMFfKmTlpesVV;
    }
}

double cMdws::OItizWTKQ()
{
    double GjHyGmL = 504568.4722102277;
    double fxJVsppgDjwKHDIX = 144677.0165958903;
    string ERWQgALyPbuTzPqR = string("ulSsqJzqMAZfibMFgDXjOvuxpMISRzYlFVymNliapTovbVJrzfGrEHJSOtbRoQlIqtFhBcAWfTJhYQMBlrHvBFxZHSpbfhtwEFdGPFeToMlDYAWBuQrTGtwLpKMIfxHVtggsLjigrmHNaSETgAkcIHUydfStCFkXhrOtgGWFSjAGUkGmIDRNeoVXHlTMlUkQxRPhGJQPdbqEJCqvUJqCAsOIHIrygjR");
    string FPbduQDruBW = string("cVIXZIKCUZonckVZEizKIZiGEBNLjmqkhtaIRntYFhyVBxcjnbFDERuSWzymxYjjSQFcpQvzbqQVXklFdUXMopLTmyYBOTQhFqzhbFzAdXUZYNUFhdPRjYWYLXpCJMaBbLhxKpqOWQhQOcmCPjseFJHsIyDJmXTSPbNjrTpkqiptFmEJoSJCjdzmflhFTzTKjtjggMsOLaWdFXWTxuMNbdBuSbmdjjDnQvljUjssqeoYvQXwvxHAwssduJ");
    int UpOBXUV = -1965337691;
    double zGdpULaA = -412710.4101042388;
    double LWnuGd = -819550.5930240819;
    double yhPhcenC = 49645.554258977485;
    string UGZVkgF = string("mEXdwTAUeGeHYELTkNycKlHMwFyhHJKmZWBFDcXodAWlTHoYsZkMDEvZyJjakrWLsxkinCzBfAdwcyruaQSXMQfpDhCJystPWvZCnGfOIpeKMqLyMOazFLDoNsQGCIZkNHhDsoXHSIvcxuSIjGILtLzNqpSXkSKvtszOxdtKvdgYFSQlgabXdAKEjYjrHaRWRYPhdPiMMuTsQuiRuKfNXAcfXIJBZacwYvs");
    string EIUSNUDRvsEFfuCw = string("YGSxOPBQmUxOtUfeUdrFFHQvekoRSgLOQcIfXtJXxMwYNJzbaeaPtGxfLrQwLmaPoZayiRzdGOSYFFrpvMDDcefXJESoFnnJrojUVCUeMg");

    for (int KcfWsj = 1072114172; KcfWsj > 0; KcfWsj--) {
        fxJVsppgDjwKHDIX -= yhPhcenC;
        LWnuGd /= LWnuGd;
    }

    return yhPhcenC;
}

int cMdws::mZQRcwSGdTyxZ(double JphYqW)
{
    string xZGnIqTpHgSXAeC = string("novYAefhYiNHTntrSJMBozNsOXXKKnmcEtcvogDduULnOcQaEzkeEZhReDTFkVhPdwRBFZwfiTFKSpLQQqwaOOdPLyjBqZsBeaohF");
    double sPEjaUXpEmoJEd = -689491.6151063262;
    string gVQTAMkphHxXgZb = string("IXEDMopiygLMbsVxcBIEmQesGvgSLXIqzduiznUJomsvMCdQrGMJmWEyUeAJBiSWMSDstwDUBonFPvFITGArNYTwpmxbXhYteBWqqnxmcpTjLOIjEuxXjljiteGejnVnUKwX");
    int aXApJaiuf = -1215865596;
    string NwUnG = string("PRCaaqrloGFIFROstHzBywosnDWYrpzSEUOvOsQEtUwrBfuXzgWtyaHyJlNIAhILGFNqEfjMrRbphFfiCcbuZMeNFXKbGWrxTBoHHMWByAUlmCTiAiMTKiXXwynPdECutpdliDTPZGbscJKiHFmqSTOJNnzFBIiIPLBEjYHWdzWjc");

    return aXApJaiuf;
}

bool cMdws::JfazkEbAwltib(string zuNNOXVctTlv, int QMTuAFVFAqKsjioo, double NtHuboJQUqOKx, int fBFrTCzr)
{
    int jcktCWYFcyscxc = -1769914239;
    string qRnAaGDRV = string("XEojPxBXwzCCYhRUyhSQbdjwgNAqHKIZrZoSxWNeLiojEIMoLOBMMYTXtULyqheBQpncnGNIaApzXxKXhXCVKFZJbMAptYCcYQAawjEdTRwsASKoutldjUixCIdM");
    string IrsFpcaBHYmiI = string("UgMyEzEQRgAHmVpQUjfOhrObGrGps");

    for (int SrpdpOQcqf = 1524483659; SrpdpOQcqf > 0; SrpdpOQcqf--) {
        QMTuAFVFAqKsjioo += QMTuAFVFAqKsjioo;
    }

    for (int XaLxuNmXQ = 1108004480; XaLxuNmXQ > 0; XaLxuNmXQ--) {
        IrsFpcaBHYmiI += qRnAaGDRV;
        NtHuboJQUqOKx += NtHuboJQUqOKx;
    }

    return true;
}

string cMdws::aMXZUp(int gupEjGTp, bool THPWybxTFcEKpYyI, string bFFZdaceiFESz)
{
    double ywVGQhWsu = -269767.21726717055;
    bool EgkeGdQV = false;
    double xhGsPLjoaV = -654614.0172025026;
    bool xwFJhtsdPZ = false;
    int nfToYt = 1142612779;
    double RIWhEs = 961918.8240224149;

    return bFFZdaceiFESz;
}

cMdws::cMdws()
{
    this->Wqjwq(string("eqdfYpNmnmQrgwvxYQNbIxePobUlTHUYtPAgVDITSciAyTrdGaXPqaCvKiwfenIJEvTLTJoSXgrJcOlyuVIfszXdeiyMYpUyMVRkxSSWNnOSEAuwZyAYxpYBUHbKWwXmgVSVfDhNvrndtWGIPFBBDnDLSgdbeFpTxbXxZIPHxANpRFUrwkieKdjSdrW"), string("SkxTerp"), string("jkbhICTzOypMSowdBQvrNzRpptLghTvFrsjhJchsnlCzGNUzWVPVgNeJUXVMjtdUpkQPiCVIYYqlxObqiIFQoMnFVHSfJGnhKtAyMOHmGdGWqYxGJuPZTiDPOcVVgTouqMwztVGPWaJUtWRqtdhmpSGvuxSgWmZprqmrwqvGDrrP"));
    this->FLRLnyQdDHLz(825669.3953334547, -956868.7002632709, -1110792727);
    this->OItizWTKQ();
    this->mZQRcwSGdTyxZ(943209.8815587463);
    this->JfazkEbAwltib(string("nvCamSaluQPxmCxCdIeuKdTLJVfUEbNjAMKZXeUnGpwxWBECQPKhGTUKfTMwWwylEeJlikcURuivtWpcFnXxYzYdQHgjRtNBWUDwlgofZKmQymsZGBLIiyEoDPnIeXDQUVldOZuxRYcCazTrMRAFvBzLhiJcsJspRgjCoWSjNBGmQUaVdZWwAMuOLeiFjfmdMEQxpDgsbtiInqtWcDtdurZsMUJdiDpJYVsZPaDMhUtyQQklqgn"), 1867093756, -435920.12281124364, -1191891083);
    this->aMXZUp(-721983634, false, string("ahAUIBdNvTiGTAFLNFDCESXdyLFALTNrkJDeOgspBMZyTurKWqv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PtiSurTfEBBPFV
{
public:
    string AMAmwUkxloD;
    int BlzQNpNkTQDeIx;
    int nWloegqTIk;
    int AVaKWZHUvNPWJRR;
    int goHsONGOEVhPmm;

    PtiSurTfEBBPFV();
    int YiZTzjXW(string GHYLPUXTrRgy, double vODBaTQSeGe, double PFDDtZV);
    double taUwkXQw(string zqayTYCHczkzrJ, int NVExrsbigHqjuWy, bool JJxIyH, bool ZywbIiQDBJ);
    int lYCuP(int xskHDcAHhWXWe, double PahvJUcJ, bool vHjnRDbxdBWsTqnD, bool yssRbuWgz, double LnfzyO);
    void uMgdEsYaL(int SoVUQnm, bool nXLaevmGfBlTujP, int AjqSqhB, double ybpAmOuLPbgFDcL);
protected:
    double YPGrTdedGRXj;
    double tkbUfYCqdSRba;
    string SufTXgxqkI;

private:
    string DjIVENqQU;
    double RHFZKkVs;
    bool COwlgqIjfVG;
    string ScGuw;

    string xSziAuwFFptYjGer();
    string xFbZRiwjpqUYrfE(string vxmKBZMvMEiFGf, bool ohxPJrqTtcRm, bool wSjKxqypsXwpCPUY);
    string CDxaKPbLjWiw(bool dYJqFhoGkmpWj, bool SUfGIjFKPV, string cwmDdhrVBqyjQD, double EQtbZwA);
    bool rSaHbdu(int TRRPIDMdiVM);
    string DOSEYUAcGp();
};

int PtiSurTfEBBPFV::YiZTzjXW(string GHYLPUXTrRgy, double vODBaTQSeGe, double PFDDtZV)
{
    double bDUgbHkPnJQIBz = -369329.03938208066;

    for (int MxNCUCWktfHChS = 259543858; MxNCUCWktfHChS > 0; MxNCUCWktfHChS--) {
        bDUgbHkPnJQIBz += PFDDtZV;
        GHYLPUXTrRgy = GHYLPUXTrRgy;
        bDUgbHkPnJQIBz = vODBaTQSeGe;
    }

    if (bDUgbHkPnJQIBz < -461684.13707652886) {
        for (int LJqANSV = 235974890; LJqANSV > 0; LJqANSV--) {
            continue;
        }
    }

    return 1334636753;
}

double PtiSurTfEBBPFV::taUwkXQw(string zqayTYCHczkzrJ, int NVExrsbigHqjuWy, bool JJxIyH, bool ZywbIiQDBJ)
{
    int CdqdjyWwhUTrWn = -1909037601;
    bool aParroleayxb = false;
    bool IKYXHk = true;
    string WzAYv = string("nOSBaFClumsYBmqyAKjPgOgfDkofoJTSHMkzlHqjppYJccnDMa");
    double FriELXrF = 257998.12488079682;
    double dGjZvDc = 719266.0380274917;

    for (int RigJM = 1207659731; RigJM > 0; RigJM--) {
        IKYXHk = ! ZywbIiQDBJ;
        zqayTYCHczkzrJ += zqayTYCHczkzrJ;
        WzAYv = zqayTYCHczkzrJ;
    }

    for (int LyZsOpVjYFAQjjP = 326344388; LyZsOpVjYFAQjjP > 0; LyZsOpVjYFAQjjP--) {
        IKYXHk = IKYXHk;
        IKYXHk = JJxIyH;
        zqayTYCHczkzrJ = zqayTYCHczkzrJ;
    }

    for (int VMCawoxQndziqV = 984954557; VMCawoxQndziqV > 0; VMCawoxQndziqV--) {
        aParroleayxb = ! aParroleayxb;
        CdqdjyWwhUTrWn -= NVExrsbigHqjuWy;
    }

    return dGjZvDc;
}

int PtiSurTfEBBPFV::lYCuP(int xskHDcAHhWXWe, double PahvJUcJ, bool vHjnRDbxdBWsTqnD, bool yssRbuWgz, double LnfzyO)
{
    double EyujnviPxzNrYc = -436437.2355066258;
    double wihwDxfnm = -357064.4170873317;

    if (EyujnviPxzNrYc > -436437.2355066258) {
        for (int AzEpqVyKE = 931592303; AzEpqVyKE > 0; AzEpqVyKE--) {
            continue;
        }
    }

    if (PahvJUcJ < -436437.2355066258) {
        for (int WFYfjwoGkUEFY = 1477704338; WFYfjwoGkUEFY > 0; WFYfjwoGkUEFY--) {
            LnfzyO *= EyujnviPxzNrYc;
            yssRbuWgz = yssRbuWgz;
        }
    }

    for (int cdYPnlbuFlGJIZM = 2134449610; cdYPnlbuFlGJIZM > 0; cdYPnlbuFlGJIZM--) {
        LnfzyO /= PahvJUcJ;
        vHjnRDbxdBWsTqnD = yssRbuWgz;
    }

    if (EyujnviPxzNrYc <= -549996.5180155208) {
        for (int aTZcx = 1325782034; aTZcx > 0; aTZcx--) {
            yssRbuWgz = ! yssRbuWgz;
            PahvJUcJ /= LnfzyO;
            wihwDxfnm -= PahvJUcJ;
            PahvJUcJ /= PahvJUcJ;
        }
    }

    return xskHDcAHhWXWe;
}

void PtiSurTfEBBPFV::uMgdEsYaL(int SoVUQnm, bool nXLaevmGfBlTujP, int AjqSqhB, double ybpAmOuLPbgFDcL)
{
    double GdMRV = 714148.5345056977;
    double kpAwFCq = 331621.08797800104;
    double NHFUMWgreoMDaro = 669116.711489599;
    double uJUJNFYGqmvWYdQ = 947860.6420616067;
    bool pSvju = false;
    string GZVCDPMoRez = string("vBDzhzOibkJRjIlfMYyNfUWPdRMdJMHQmPrbyljWhYMRfaDPGEUIafSqPAWMbcmXcyJTPLyDURqoyGfXZIKpRLjaFANMEvFscUyvFjwvdMjKsbpalFyCDNcYfkBWrWAfgJXTB");
    string jbMai = string("jYoZJeoQrhJLbYcYDFMTvGZCImwmfERvmxYalZmMlbgSRIfSNXBPkCDejSvrdSGNNSkyWTsDzGADkgyFmsIyJXblQyzbacNiHPOoSANTNwLVoOvscxBnetkzifftmckqhtRtmfkZHhlYWCXWNHqXXgHaAUD");
    bool QRAINaRylBWRUkU = false;
}

string PtiSurTfEBBPFV::xSziAuwFFptYjGer()
{
    int jNbxuI = -476859549;
    double gvcAwmTyxT = -912133.2696981839;
    double RbVuXmY = -639052.168196993;
    int JTzluhuBwYr = 1336492762;
    int MqwgDldhX = 1609166012;
    string cfBCLvobNlRfukQ = string("KHdACjVwDSoIyFmUFNXkoddjhSoOyueTJTIRhnqUfUlOcDWdEBxZgSXcsqNPmDFQWQZznwTPVjTSOHChMwMLFMELprIBnvhgLZNjmnsvktCNBnpjUMSwXOCipqXtNOtBxnMvr");
    string IlYGvPJeTqO = string("XbIUwtAbWyELcuvbJOdqqaJPbFvfvAzOXyUxgtCpIEJDWDbzIqfbRXVBWydTfizgDloNHabsBYofGFVXVRxEdIwiGgKniOMsJMRX");
    bool OdBzIkVRHoHL = false;

    for (int qFdwjWrEY = 1069989387; qFdwjWrEY > 0; qFdwjWrEY--) {
        jNbxuI *= JTzluhuBwYr;
        MqwgDldhX = jNbxuI;
        MqwgDldhX -= MqwgDldhX;
    }

    for (int vCjUi = 322485248; vCjUi > 0; vCjUi--) {
        RbVuXmY *= RbVuXmY;
    }

    if (gvcAwmTyxT != -639052.168196993) {
        for (int DoEzSlnOMuWIJRKV = 1518772093; DoEzSlnOMuWIJRKV > 0; DoEzSlnOMuWIJRKV--) {
            gvcAwmTyxT /= gvcAwmTyxT;
            JTzluhuBwYr += JTzluhuBwYr;
            cfBCLvobNlRfukQ = cfBCLvobNlRfukQ;
            JTzluhuBwYr -= JTzluhuBwYr;
        }
    }

    return IlYGvPJeTqO;
}

string PtiSurTfEBBPFV::xFbZRiwjpqUYrfE(string vxmKBZMvMEiFGf, bool ohxPJrqTtcRm, bool wSjKxqypsXwpCPUY)
{
    int VrWLSUB = -1280062829;
    int oaJPN = 734807653;
    int PWphOZMUB = 1061147598;
    bool pVZyI = true;
    int OwkQWNpxBiV = -13951052;
    int NkbNoMRLjQCMrwaa = -1104499910;
    int MEXZcW = -922260806;
    int ahPLxaVVuOv = -1397688126;
    int ZHieIldbs = 9019737;
    bool pFZMKM = false;

    if (pFZMKM == true) {
        for (int gnBlnbVBMSx = 1937941814; gnBlnbVBMSx > 0; gnBlnbVBMSx--) {
            VrWLSUB *= OwkQWNpxBiV;
            NkbNoMRLjQCMrwaa -= OwkQWNpxBiV;
        }
    }

    if (pVZyI != false) {
        for (int lpqvGCiZWuK = 1910560362; lpqvGCiZWuK > 0; lpqvGCiZWuK--) {
            continue;
        }
    }

    return vxmKBZMvMEiFGf;
}

string PtiSurTfEBBPFV::CDxaKPbLjWiw(bool dYJqFhoGkmpWj, bool SUfGIjFKPV, string cwmDdhrVBqyjQD, double EQtbZwA)
{
    int DlhzCUDUE = -1251868469;

    for (int KWBFTwXCTM = 197720558; KWBFTwXCTM > 0; KWBFTwXCTM--) {
        dYJqFhoGkmpWj = dYJqFhoGkmpWj;
        DlhzCUDUE = DlhzCUDUE;
    }

    return cwmDdhrVBqyjQD;
}

bool PtiSurTfEBBPFV::rSaHbdu(int TRRPIDMdiVM)
{
    bool XkUUguqkGaMUC = true;
    string OKXeyfgfbVr = string("ssqdExherEYOhPiGRlOUyhHrVUGIZskCObFFmWEVlnWqodlhekUuiCQhgrZQBxrAjNCfMnsNJDwtNZUIlUpswxuKphuhOqTghliruYkAFmzRCvHxJpyNIXobmItPqErCUGlTXRTnMitoMkODiUtdpEwPEsaFNnTSHWIaesvEfKvpkDfBAPBEyoPnhdqWZZccxiLmNcKeJemgROWCkHezwfSnJTuabYQRtFTTxwlKPLySrRquJGpgAQn");
    string OOdrpEiqJ = string("kByDkzdPkLuduAOBsrwyHJGzKk");

    if (TRRPIDMdiVM != -492854014) {
        for (int NUmjBvQfJB = 1081883053; NUmjBvQfJB > 0; NUmjBvQfJB--) {
            OOdrpEiqJ = OOdrpEiqJ;
            XkUUguqkGaMUC = XkUUguqkGaMUC;
            XkUUguqkGaMUC = XkUUguqkGaMUC;
            OOdrpEiqJ += OKXeyfgfbVr;
        }
    }

    for (int xOhOsuYttTawWs = 1848030170; xOhOsuYttTawWs > 0; xOhOsuYttTawWs--) {
        XkUUguqkGaMUC = XkUUguqkGaMUC;
        OKXeyfgfbVr = OKXeyfgfbVr;
        OKXeyfgfbVr = OOdrpEiqJ;
    }

    return XkUUguqkGaMUC;
}

string PtiSurTfEBBPFV::DOSEYUAcGp()
{
    int uVNhXhzalEa = 1775553668;

    if (uVNhXhzalEa != 1775553668) {
        for (int XvcThULmakpMFuk = 1760191359; XvcThULmakpMFuk > 0; XvcThULmakpMFuk--) {
            uVNhXhzalEa *= uVNhXhzalEa;
            uVNhXhzalEa /= uVNhXhzalEa;
            uVNhXhzalEa += uVNhXhzalEa;
            uVNhXhzalEa = uVNhXhzalEa;
        }
    }

    return string("kHuvBOnjxlnUEhCBnDGsdqRlGqPRWCYgqgReDASmUXjFzEGjznupxidMOfJStEMeZtgGSVWLlTERcIQdmPqntZw");
}

PtiSurTfEBBPFV::PtiSurTfEBBPFV()
{
    this->YiZTzjXW(string("KuEqPYLlkeyxGmGvozEoFHADtXtDITTTsydVhvjMRSHKzclxyhfUMjGUdFhnPjDCKFvmtZbAwttpjRQtcEEjtlfiLgNyyzgramSAyFYBIlVBeFSkGdYuyEjxqkTTreGwwHaAnDxKWqHeD"), -461684.13707652886, 324315.1091857881);
    this->taUwkXQw(string("jbvLBBiuRGSECSBDVmPYowJlGKBZoMmPOMjLwiuOrHYQwtXAdKDVKdTCpNznZuQAnwcWfdYvsHMdCbJopBBSKBGPzqcbpDGsopRqQprZHzDpdnynzgXYCRDY"), 882979638, true, true);
    this->lYCuP(355543263, 785924.5364543195, false, true, -549996.5180155208);
    this->uMgdEsYaL(1622722681, false, 1795867035, -3952.685470588265);
    this->xSziAuwFFptYjGer();
    this->xFbZRiwjpqUYrfE(string("oHcVDZuTOGqpCgqnhUGeTCZvNyBzPqhlEiauWvcnaZmKZQxppwdBIExztuuYHUMwVVEkerzXdEadRhfKemIzhCPDGnaoPRDwyYUzDBjuUnYpqNBCiWgxBJEJGBVLLF"), true, true);
    this->CDxaKPbLjWiw(false, true, string("eLHSVCqTRvolVeZnSvkTHLhBqVqtwyEPDuIpqxicbSmkaZdYnjOOUmmCtVwFTcXRMuuDMnpGJfMDAcUzfxqeHCpHvfinrdhGbAhBtfPdPhaXzsLrvdzSAkpofADlwwQUhbcTPMOlLXcwSljREGfdEjeCZBteOxYjrpRpeVUDjjSyQGxeTGIINHzJJgHEpmFdUfgcucQqHhNoXArQgfTxZpRDdfweEv"), 933113.9997915255);
    this->rSaHbdu(-492854014);
    this->DOSEYUAcGp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xDnjgLiMgX
{
public:
    string jttuGDcTrhR;
    double JlsrKLH;
    double UdawfBRS;
    bool hsXeopSGDfCIE;
    int hrCdFky;

    xDnjgLiMgX();
    double YnBwpq();
    bool HncGAk(string wIBWVdOX);
    void yAwnZzClgN(int sifFygLyyBOi, string qhjZUIekcVVPXP);
    string YqueZdYIclUcDxb(int eKpJCRJqyOCCnDJk);
    int MHDBWkTBixTChy();
    void LncSOaq(string UpKLrxCDPVF, int nCvFJgNcObisZ);
    double MIBNoUh(bool soQPRqBVC, double HJkDVYBqsmHAOLuS, string ejstXFtPbG, string wjonSUhBuFmF);
protected:
    double sSNWrKFXwA;
    string JcXtV;
    double vOgktHtt;
    string tUpePiITcGTNVK;

    bool CcnfP(double KZMavcxTjAB, bool ReBtnrctYltsIC, bool mGYNpXDj);
    string aXInNjmgLnoxHn(string ChywZhGjUKUYrFz, bool hpgTakkwpdsNe, double LgCxJC);
    string HffomZmYImV(string biVGHM, bool AeaGoRehnf, bool RodDqdaRzymp);
    bool tWrVQLnnlol(int AUZzGzmNAk, double alElQMU, string aAfPgdgjDMe, int PJEhNAhptUoD, int eRrqdqNVqnRO);
    void KoOhpczlTFfW(int XbcbKOTwmFGoygs, double SgzHSgfjnfuJvFG, double LxnUpIoNxzbw);
    double kMRJrX(int marzPfkvOTgw, int ezIQAucYJUB);
    void AUyCC(int lAlyOfjyPU, int KiqySdfmNkLnQ, bool GUvrMla, bool zjbzbEiQtftOP);
private:
    string xEHyxgzZAIP;
    int cFEOiPcyzFJIPB;
    double oWSXimdkte;
    double EYlPUiJRSKPxF;
    int LDaPstntrq;

    bool CxGPUDUuEvBP(int ZRpfFLVYCZbsoxIy, double YSoOMCRPWMMJyL, double Ewafu, double jojNdTp, int BrlutnxVaW);
    string JnmeDKKuKwYzKF(string DpzqSPApUdqsev, string EUkBFtTCuTjyBf, string LVrmJjoyAuJC, double eggNKuWXAp);
    double jJdYilUjneRWe(int SgdnsmVkNHucr, double sWvwstP, int jBzOwI);
    string pzJhXAeKSIxLGAYZ(int lszriRmnKMmGN, bool REBtwFFeShg, int ZPjWhlfhQPRG, string WtXTWVCqOzgVyGY);
    int iBVkHkdcCl(double EboFIGqCwc, double RGNHW, bool WJsiwA);
    int CbzNupIBpdSGOtz(int qvbkRf, string GHzbttQwwqYsQI, double ZNckcI, int QWQIZBPMBYrjQu);
    int axtcdfyVrdCjNDu(double MLbZeiZjyAc, string TiihW);
    bool NPmzF(bool VdqazELfrx, bool uNBsjZ, string WQRTAuaPXJnfLWhg, bool ALnPjKBdR);
};

double xDnjgLiMgX::YnBwpq()
{
    string uIghMHzeRX = string("XoPVjyCKLawGiOBLxGFbTaHtlawbvRvTkXPonoRKibfHjaXBeqivXMnejRKahORsMPfMFQUkuIxdjuwSOUoihEKiXoPxVBehFtJCxaWgQEDVnZZhrwBAXexeunBBkbIVkeYJgDWTMnCqBTMZcLGOvJiPfEfWywNZoCznqKACHsjVxAgDtTPaewOuHPKPzyfmPYchMQwAodOjhAWesgAOcAgCXqnyrzUiUYvIezmhoZLmud");
    string MCtPOj = string("LbcIrDULIsoyuFUDIm");
    string HuyLrpDmj = string("SoWdhSYBnEdQxyFfQJeCheqCCiKyGXlmllzggCYlOREIBeRqAcdQhtmpecUGBthSMwDyMoyNyTnKITJTRqsaZtVOsMjAHIQeDeSQMWjhNQJwGoBIrFbSWWYEehlxDmHvLTLFhDXtpqATwQcCQXRJNnLbqHKBZLeswSJUPsoEIwbqTTroPkLuBGkiwUkoMBGjQFIphCwteSUVHyvZjAqqjhiDPNYqFoXlK");

    if (uIghMHzeRX > string("LbcIrDULIsoyuFUDIm")) {
        for (int SiBtVGlPwLMYQ = 1895135157; SiBtVGlPwLMYQ > 0; SiBtVGlPwLMYQ--) {
            HuyLrpDmj = MCtPOj;
            MCtPOj = MCtPOj;
            MCtPOj = HuyLrpDmj;
            MCtPOj = HuyLrpDmj;
        }
    }

    if (HuyLrpDmj < string("SoWdhSYBnEdQxyFfQJeCheqCCiKyGXlmllzggCYlOREIBeRqAcdQhtmpecUGBthSMwDyMoyNyTnKITJTRqsaZtVOsMjAHIQeDeSQMWjhNQJwGoBIrFbSWWYEehlxDmHvLTLFhDXtpqATwQcCQXRJNnLbqHKBZLeswSJUPsoEIwbqTTroPkLuBGkiwUkoMBGjQFIphCwteSUVHyvZjAqqjhiDPNYqFoXlK")) {
        for (int LDPtZ = 1998270313; LDPtZ > 0; LDPtZ--) {
            MCtPOj = MCtPOj;
            uIghMHzeRX += HuyLrpDmj;
            uIghMHzeRX = MCtPOj;
            uIghMHzeRX += MCtPOj;
            HuyLrpDmj += uIghMHzeRX;
            HuyLrpDmj += uIghMHzeRX;
            uIghMHzeRX = HuyLrpDmj;
            HuyLrpDmj = MCtPOj;
        }
    }

    if (uIghMHzeRX >= string("LbcIrDULIsoyuFUDIm")) {
        for (int EPkQuzh = 1560984480; EPkQuzh > 0; EPkQuzh--) {
            HuyLrpDmj += MCtPOj;
            MCtPOj = HuyLrpDmj;
        }
    }

    return 266727.65755711455;
}

bool xDnjgLiMgX::HncGAk(string wIBWVdOX)
{
    bool kqjuQq = false;
    double zBwukrIlum = -606203.2748388173;
    string OyikKjdMWlTJXmW = string("EYKiqtAzuhdxDIjkNRvyPvgRRmnrPhVNmGhYIkYNkupzyYjfWASRPubcTWOpWXzvLROMnjzlKIfMZGhINFSrVbvzBGSTSdJuaRPdDilHRqgMBhLuQjxiRzqeJmJFxtGofqBRBXxZzEwNAxcPJcbsVvlYtCWsXXxTkbfIoDCOcYcVYfCFjpqmvwkCTqVYwiUeXFMPhifPkEnGaGynGYrSLeJLesSbaiOpNdpkMWUyfUfsAdxZCJRlmwcClXTJW");
    bool qMmtmRnEmgDnJ = false;
    double ANWGWqZKnAXsIMT = 866575.5907905448;
    bool sJzCKFnfkvrIiY = false;
    double QVtZcxCNTh = -546353.1511824394;
    int vZzfUfJc = 908867925;

    return sJzCKFnfkvrIiY;
}

void xDnjgLiMgX::yAwnZzClgN(int sifFygLyyBOi, string qhjZUIekcVVPXP)
{
    int LGTlDiJUVUalR = -875518979;
    string aLGoPMVKNWrvjM = string("oZBRojjFziVBkAuojadyWULzqDazACMeTezpPcTqVqSNxGJBniUwfNbdeKlhkXAPUUYiOxlKZXUKGDbgoYpTlAPnEeYExqVuRIUwnJlIxiFEjeKGGOdehOneLnjFCPlZfjVpaTYkzhtkZIqPpIDcuSxEqGSduTiDVs");
    int CThoZZ = -1820222203;

    for (int ipHhTBiTNLjKDp = 239568590; ipHhTBiTNLjKDp > 0; ipHhTBiTNLjKDp--) {
        sifFygLyyBOi = LGTlDiJUVUalR;
    }
}

string xDnjgLiMgX::YqueZdYIclUcDxb(int eKpJCRJqyOCCnDJk)
{
    int tQlVro = 1784393466;
    bool JOMHHpGXymh = true;
    bool jgFiwpOT = false;
    double ZDmLSpO = 107009.4002422103;
    bool ITzGVwKOQHWSYcf = false;
    double FRhFwlj = -483648.82881317736;
    int nFGFuL = 876933339;
    double dmXWjgI = -782267.1775746803;

    if (tQlVro < 1784393466) {
        for (int HGbnbSIFmUjlGd = 171309035; HGbnbSIFmUjlGd > 0; HGbnbSIFmUjlGd--) {
            dmXWjgI += ZDmLSpO;
        }
    }

    if (dmXWjgI > -483648.82881317736) {
        for (int CDxuECuuoDjw = 564074158; CDxuECuuoDjw > 0; CDxuECuuoDjw--) {
            eKpJCRJqyOCCnDJk -= eKpJCRJqyOCCnDJk;
        }
    }

    if (dmXWjgI > -483648.82881317736) {
        for (int cfTWAeHezJSXhKT = 1545750755; cfTWAeHezJSXhKT > 0; cfTWAeHezJSXhKT--) {
            eKpJCRJqyOCCnDJk -= eKpJCRJqyOCCnDJk;
            ITzGVwKOQHWSYcf = ! JOMHHpGXymh;
            dmXWjgI *= FRhFwlj;
            eKpJCRJqyOCCnDJk = nFGFuL;
            FRhFwlj /= dmXWjgI;
            FRhFwlj *= ZDmLSpO;
        }
    }

    return string("enUaOWeeoxIhElQRHVcYcqhbhyAAVtjuFlrDOuDCJMJTmkFvrrTPaNjyyovfqHGAwOJobLI");
}

int xDnjgLiMgX::MHDBWkTBixTChy()
{
    double QDZfZyHRotnX = 33496.34737310378;
    bool saOrNJT = true;
    string lozScKCnk = string("BqIxxpbVBLYYylfJfNIKSdOOWBTDzzqqSQUnCxVXbJgIvHdIvUaVcDgtHGqvfntydeRiIKomBSfKVIXswSMSwfBweaWpSWUpfwqeTfTTsKWvbmgCRHoaFNteufSkSMfowEjktddpYOXBMRDimnKqbZiwOccGKeQaSHcuwxecBUlObjhvEbZAyGOhGknbbHEaDrCXOemJOkuZtdYrIPbADZgpmWyscJFsau");
    bool cmSybUkgZ = false;
    string SsnCnEZWE = string("lWjuKtmeyHvwjbmrXXBysUSMVJRCwERHiSamygjMkyoXmKadjKVEjWPPfbPpcbRGtxTnddTYIvQkSfYCUahdEwwwuntLSSsXWfYgimMbmxjLwsRuQbDdIHIcVJQbqUXFcpTuCbanYQRZlCoXVhGiByyznSGOlHAPnyAFuKxRUlkLeokVuGoquOmYXfuuXwOLegiHfkbfrfXUniAqdOUFccoSKmqmKlHghWclHbNvikBlOFuCZiFGOaDD");
    string zWPTcSZnyqtr = string("NwAWFpQVjHGeeEhQlJoKBNiBAkKmHQKdsWkYlEIeiyXFLKOtCmImzndhnhvqOOgYibrOnKKDgXlPM");
    bool mHnpsnTAMAnwsNRP = false;
    string aeQlFsVRCd = string("DPfqNKibDObfHOdjWDjgzhLEFDEFUofqtpZUUHBIGqXETRQmrkaMWNizhJYGROilrXxFaFT");
    bool zptty = false;

    return 2122803672;
}

void xDnjgLiMgX::LncSOaq(string UpKLrxCDPVF, int nCvFJgNcObisZ)
{
    string lERiblhQK = string("NN");

    if (nCvFJgNcObisZ != 1275024979) {
        for (int qIZhCBPnfZFltdV = 843303406; qIZhCBPnfZFltdV > 0; qIZhCBPnfZFltdV--) {
            continue;
        }
    }

    for (int FoMkJ = 1730387092; FoMkJ > 0; FoMkJ--) {
        lERiblhQK = UpKLrxCDPVF;
        lERiblhQK += UpKLrxCDPVF;
    }

    for (int KYdjEZnZL = 812222848; KYdjEZnZL > 0; KYdjEZnZL--) {
        UpKLrxCDPVF += lERiblhQK;
        lERiblhQK += lERiblhQK;
        lERiblhQK = lERiblhQK;
        nCvFJgNcObisZ *= nCvFJgNcObisZ;
    }

    for (int agQko = 214145962; agQko > 0; agQko--) {
        UpKLrxCDPVF = UpKLrxCDPVF;
    }
}

double xDnjgLiMgX::MIBNoUh(bool soQPRqBVC, double HJkDVYBqsmHAOLuS, string ejstXFtPbG, string wjonSUhBuFmF)
{
    int YCMNvv = -946154120;
    string XjNjHe = string("i");
    int PRGxBMqhEsxcq = -1133351557;
    int gAaKsgoxE = -1389036113;
    double pINrbVExcgUM = 785029.6956297372;
    bool fziPWCacBC = false;
    int PKyupSpGMqn = 1782590933;

    for (int lPxBA = 559603578; lPxBA > 0; lPxBA--) {
        gAaKsgoxE /= YCMNvv;
        XjNjHe += ejstXFtPbG;
    }

    for (int nMvEIKUwF = 1904465214; nMvEIKUwF > 0; nMvEIKUwF--) {
        PKyupSpGMqn *= gAaKsgoxE;
        ejstXFtPbG = XjNjHe;
        ejstXFtPbG += ejstXFtPbG;
    }

    for (int RMFHSpyU = 1024303874; RMFHSpyU > 0; RMFHSpyU--) {
        PRGxBMqhEsxcq -= YCMNvv;
    }

    if (PKyupSpGMqn == -946154120) {
        for (int GBmCtjGsWdYLRyV = 2130878189; GBmCtjGsWdYLRyV > 0; GBmCtjGsWdYLRyV--) {
            XjNjHe = wjonSUhBuFmF;
            PKyupSpGMqn = YCMNvv;
            pINrbVExcgUM *= HJkDVYBqsmHAOLuS;
        }
    }

    if (PKyupSpGMqn <= -1389036113) {
        for (int qGhktqnAXet = 890202648; qGhktqnAXet > 0; qGhktqnAXet--) {
            YCMNvv *= PRGxBMqhEsxcq;
        }
    }

    return pINrbVExcgUM;
}

bool xDnjgLiMgX::CcnfP(double KZMavcxTjAB, bool ReBtnrctYltsIC, bool mGYNpXDj)
{
    int AhiHWfFik = 1647367703;
    int gthEEJcePxfK = -788191737;
    bool mkNyCcViVy = false;

    for (int FGLSjDPKfyc = 2050377768; FGLSjDPKfyc > 0; FGLSjDPKfyc--) {
        ReBtnrctYltsIC = ! mkNyCcViVy;
    }

    if (ReBtnrctYltsIC != false) {
        for (int fborRVtZBJMMb = 357853418; fborRVtZBJMMb > 0; fborRVtZBJMMb--) {
            mGYNpXDj = mkNyCcViVy;
            mGYNpXDj = mkNyCcViVy;
            ReBtnrctYltsIC = ! ReBtnrctYltsIC;
        }
    }

    if (AhiHWfFik <= 1647367703) {
        for (int sJnPEBPFe = 474926550; sJnPEBPFe > 0; sJnPEBPFe--) {
            mGYNpXDj = mkNyCcViVy;
            KZMavcxTjAB += KZMavcxTjAB;
            gthEEJcePxfK += AhiHWfFik;
            gthEEJcePxfK = AhiHWfFik;
        }
    }

    for (int GmEBCxCrQpRAaX = 1619383577; GmEBCxCrQpRAaX > 0; GmEBCxCrQpRAaX--) {
        mkNyCcViVy = mkNyCcViVy;
        ReBtnrctYltsIC = ! ReBtnrctYltsIC;
    }

    for (int SuTMLzMAActUZv = 966837283; SuTMLzMAActUZv > 0; SuTMLzMAActUZv--) {
        ReBtnrctYltsIC = mkNyCcViVy;
    }

    return mkNyCcViVy;
}

string xDnjgLiMgX::aXInNjmgLnoxHn(string ChywZhGjUKUYrFz, bool hpgTakkwpdsNe, double LgCxJC)
{
    bool oMITVXYBbyvsT = true;
    double rOQNH = -39813.84756465501;
    double CXRXIUIGWqQBKdG = -185972.62345338415;

    for (int dbgeWNv = 1953808903; dbgeWNv > 0; dbgeWNv--) {
        continue;
    }

    for (int tWOgSBINFwgOP = 1806307685; tWOgSBINFwgOP > 0; tWOgSBINFwgOP--) {
        CXRXIUIGWqQBKdG *= rOQNH;
    }

    for (int EQdLkcB = 1589148329; EQdLkcB > 0; EQdLkcB--) {
        LgCxJC += rOQNH;
        CXRXIUIGWqQBKdG -= rOQNH;
    }

    for (int Eagji = 708597809; Eagji > 0; Eagji--) {
        continue;
    }

    return ChywZhGjUKUYrFz;
}

string xDnjgLiMgX::HffomZmYImV(string biVGHM, bool AeaGoRehnf, bool RodDqdaRzymp)
{
    string bCiaLVOayz = string("fyaiJuTOJPJwmAIrBOTEpWwvvwbqMuFwVKcLjBZTwIRaKqpejJXVUlpESjuRpDOAenEt");
    double HsOvaoamyTqq = 710208.8571111342;
    string rqZXqxnIoldUEM = string("yEPLCVPmUcdiFNnJLihowxDiwYuxxgAuRJXwqAreajINhqwzGIwddfKzfhWVAHbQlVxhwknWonGPlbCQxyarCAlFSRwANKXganSVFzkhZObJEahGVxw");

    return rqZXqxnIoldUEM;
}

bool xDnjgLiMgX::tWrVQLnnlol(int AUZzGzmNAk, double alElQMU, string aAfPgdgjDMe, int PJEhNAhptUoD, int eRrqdqNVqnRO)
{
    double gLudLkLxaQ = 304822.1397340391;
    bool fIFwduKugHkBkzOJ = false;
    bool CpiWq = false;
    string bNrwbW = string("zpDvITrcchstiTasiYqUBYeHIsogRhXTDUzyOBxdwzDMALvzafVMNhKjVYmFGUHmbuVRUNzPVxwIWTQySTZhmfpWiLsdsPUqfPKtsSbKzTwyAMGwxbrYIzHdGnFGLeC");
    bool WHOOSHW = false;
    bool JSMBhufu = false;
    bool zGYpRnYxGRHPe = true;

    return zGYpRnYxGRHPe;
}

void xDnjgLiMgX::KoOhpczlTFfW(int XbcbKOTwmFGoygs, double SgzHSgfjnfuJvFG, double LxnUpIoNxzbw)
{
    bool ZwHoGjBahmGWOvFm = true;
    int rhePpzpPmwAdJbbA = 1512640614;
    int CcsaKSlGpem = 1952524110;
    int bPdMWWQKgu = -1489154817;
    string RPLlIWstvpwc = string("NrNyxFZfugIEcfQlIXGCkYDaptBBFvDlykSqfDkAxGckWnuEsuvfxVJqHKfGpWczcwPOJdBpWpzJVoJBLfbwElhAgXoslCTXPQGWSBfPCXNudPfcXqNwILvgzfjtqvyWvbprQBHXexMouSKxZjzfyYdNlvzilJZPJhztxzRYKUmSdQoCIjrpKlNJaPKKTEgByVRHvDL");
    double ZlxriDmdSfkAJY = 102307.57978711018;
    string eXqVmMhwuHVq = string("JtTiwmKVUnuYHCENRvxzkUmKNXRTyzGBByZArg");
    int gTEeGOwqEKP = 43760544;

    for (int ULfjtnVfvn = 1284173582; ULfjtnVfvn > 0; ULfjtnVfvn--) {
        CcsaKSlGpem *= CcsaKSlGpem;
        rhePpzpPmwAdJbbA -= CcsaKSlGpem;
        gTEeGOwqEKP /= gTEeGOwqEKP;
        CcsaKSlGpem -= gTEeGOwqEKP;
        gTEeGOwqEKP -= CcsaKSlGpem;
    }

    if (LxnUpIoNxzbw > -392465.6834705589) {
        for (int LzyelcqCZL = 652750697; LzyelcqCZL > 0; LzyelcqCZL--) {
            RPLlIWstvpwc = eXqVmMhwuHVq;
            LxnUpIoNxzbw *= SgzHSgfjnfuJvFG;
            rhePpzpPmwAdJbbA += CcsaKSlGpem;
            XbcbKOTwmFGoygs -= XbcbKOTwmFGoygs;
        }
    }
}

double xDnjgLiMgX::kMRJrX(int marzPfkvOTgw, int ezIQAucYJUB)
{
    double BkBhERosukhScHdY = -196622.75064620018;
    double QLMCHaNziRR = 624961.4926960083;
    int ahERLiDX = -863468429;
    string VusFSMxniFF = string("CXCOYzuqyJwEPoBNHpckTFeoCeAwRHzGrodIChwRuYefrAmsUNuLYvFcwDAG");
    bool gesmdS = false;

    for (int fBTOabbwrhUIpGiv = 335862389; fBTOabbwrhUIpGiv > 0; fBTOabbwrhUIpGiv--) {
        marzPfkvOTgw -= ezIQAucYJUB;
    }

    for (int wgwihcq = 1783585559; wgwihcq > 0; wgwihcq--) {
        ezIQAucYJUB /= ezIQAucYJUB;
    }

    for (int FeSpmF = 532217290; FeSpmF > 0; FeSpmF--) {
        marzPfkvOTgw *= marzPfkvOTgw;
    }

    for (int MSAUthBJSLxO = 1853282925; MSAUthBJSLxO > 0; MSAUthBJSLxO--) {
        ahERLiDX /= ezIQAucYJUB;
        ezIQAucYJUB = ezIQAucYJUB;
        ahERLiDX += ezIQAucYJUB;
        BkBhERosukhScHdY *= BkBhERosukhScHdY;
        ezIQAucYJUB *= marzPfkvOTgw;
    }

    for (int MvCvQQJ = 643307976; MvCvQQJ > 0; MvCvQQJ--) {
        ezIQAucYJUB = marzPfkvOTgw;
        BkBhERosukhScHdY *= QLMCHaNziRR;
    }

    for (int KAVuXrSkXXFk = 1907590631; KAVuXrSkXXFk > 0; KAVuXrSkXXFk--) {
        QLMCHaNziRR /= QLMCHaNziRR;
    }

    return QLMCHaNziRR;
}

void xDnjgLiMgX::AUyCC(int lAlyOfjyPU, int KiqySdfmNkLnQ, bool GUvrMla, bool zjbzbEiQtftOP)
{
    int CrTGHqpkDuec = 2071953116;
    string BcCGIqiFPxhRQaNA = string("NZdQTXkzsQvyILSgLWchJLvXwUtefySKNfOPibCSxCbQnKfmUDIfVLNLqdceDwM");
    bool YoEdbSdnGEckzFP = false;
    string VBxAW = string("fwRxcMAlRKLeNchvbgrNAu");

    for (int oHjsBKPUwhbQwMF = 2115780365; oHjsBKPUwhbQwMF > 0; oHjsBKPUwhbQwMF--) {
        YoEdbSdnGEckzFP = zjbzbEiQtftOP;
    }
}

bool xDnjgLiMgX::CxGPUDUuEvBP(int ZRpfFLVYCZbsoxIy, double YSoOMCRPWMMJyL, double Ewafu, double jojNdTp, int BrlutnxVaW)
{
    string HYjTimUoEzT = string("ReEEWkZDWmtBIiBYztjAkpmenaNekINYRrunLBDVcSTiQOSnxCpjphpNXYbdpdlkjzVvBeIIAOVZdRmrtvyvZFvJxacJaCBLuUALbHBhIEXBTqTGeIFzdGWLxhEnUfyxNCOZaaWeYSYvpbtBTnRFMGkEcvvGszzvrQGapHNQwDYXWnOCyTlKxDMclCWvOjHHVrZQfPnetffNECRZJGzJepJjnKXuvRlyDYccHpyZGcIPUCXVeU");
    int dgmAcumuQFgZFps = -1536439802;
    int oBlYyOw = -1418255267;
    double HwTRupguwMjGotit = 819607.6321173954;
    double FhaZBZTm = -224575.59244317387;
    double dqDkenXc = -849824.9061727051;

    for (int KNJazexSd = 1910048427; KNJazexSd > 0; KNJazexSd--) {
        Ewafu = HwTRupguwMjGotit;
    }

    for (int uAJKEaEXtDC = 1548572397; uAJKEaEXtDC > 0; uAJKEaEXtDC--) {
        dgmAcumuQFgZFps /= dgmAcumuQFgZFps;
        jojNdTp -= Ewafu;
    }

    if (FhaZBZTm >= 29310.27546665825) {
        for (int NYKPHoTf = 1536561482; NYKPHoTf > 0; NYKPHoTf--) {
            oBlYyOw -= ZRpfFLVYCZbsoxIy;
        }
    }

    if (YSoOMCRPWMMJyL != -224575.59244317387) {
        for (int DKYhgAcYr = 1068293988; DKYhgAcYr > 0; DKYhgAcYr--) {
            oBlYyOw *= ZRpfFLVYCZbsoxIy;
            YSoOMCRPWMMJyL /= Ewafu;
        }
    }

    return false;
}

string xDnjgLiMgX::JnmeDKKuKwYzKF(string DpzqSPApUdqsev, string EUkBFtTCuTjyBf, string LVrmJjoyAuJC, double eggNKuWXAp)
{
    int oiyiViv = 1153696728;
    int zyPgGrGHtyrOwXyB = -29474292;
    double HKqbAUNsb = 870726.0240560718;

    if (LVrmJjoyAuJC > string("bRsLzzcKYXFglzvTECljYcFxXzGIhxcLhGGzyCYczQWrGykZgCrUUpFHcYsTRTuCTHWngvbgkQfcAkQOScJwqsleQnTIOFQalwvTnGkRHUhShyEpYrYGBhpMgUlQnZEROSZKKiJJQddbukxdJaixRKAeRulXBAyMKVHkjfgorlvzObdBqgvPGzHiIIyQBpjg")) {
        for (int BiBNeCbp = 526815794; BiBNeCbp > 0; BiBNeCbp--) {
            zyPgGrGHtyrOwXyB += oiyiViv;
            zyPgGrGHtyrOwXyB = zyPgGrGHtyrOwXyB;
            HKqbAUNsb *= eggNKuWXAp;
            zyPgGrGHtyrOwXyB /= zyPgGrGHtyrOwXyB;
        }
    }

    for (int cgZMGfkgmZhzvVXy = 1707002528; cgZMGfkgmZhzvVXy > 0; cgZMGfkgmZhzvVXy--) {
        EUkBFtTCuTjyBf += LVrmJjoyAuJC;
        oiyiViv *= zyPgGrGHtyrOwXyB;
        eggNKuWXAp = eggNKuWXAp;
        DpzqSPApUdqsev = LVrmJjoyAuJC;
    }

    return LVrmJjoyAuJC;
}

double xDnjgLiMgX::jJdYilUjneRWe(int SgdnsmVkNHucr, double sWvwstP, int jBzOwI)
{
    bool wRdTaejXj = true;
    double SlXfBFADangaY = 651026.699932034;
    double aEiZf = 741835.3788695293;
    int FzOubdsoQAqfy = 896371193;
    double HpeLqNVeH = -544299.648055848;
    bool ULiuCtuCSjtE = true;
    bool MkeaHmkuiz = false;
    int fpdmkMTueeDlRP = -1754176321;
    string qXrhbasF = string("fzrxEAhcHcbDfoNAPUzYxjWvdExSyPLMHHpwFVyflZFNJGCCkeJbhLzIgbFoIDUmPatOzlpyHnjLlf");
    bool ZjnAGiwreSevfixK = true;

    if (aEiZf >= 45193.49789937263) {
        for (int vwGVsOEUlB = 1269709488; vwGVsOEUlB > 0; vwGVsOEUlB--) {
            jBzOwI *= SgdnsmVkNHucr;
        }
    }

    for (int NBSyoHv = 1842817821; NBSyoHv > 0; NBSyoHv--) {
        HpeLqNVeH = sWvwstP;
        SlXfBFADangaY *= HpeLqNVeH;
    }

    return HpeLqNVeH;
}

string xDnjgLiMgX::pzJhXAeKSIxLGAYZ(int lszriRmnKMmGN, bool REBtwFFeShg, int ZPjWhlfhQPRG, string WtXTWVCqOzgVyGY)
{
    int lzBjEgSVcgOa = 667490504;
    int huGUyAYxIW = -1227007970;
    string nFLtNwUrJB = string("iVpzvgeptSBubkDdfFLbaqhsxUvBMoAygnjILWzUbNYXBcLpcuMApDyodwdAhIhN");
    bool zixYDJLjPdbPeLHc = false;
    bool jnXBOYiPXWfEmspL = false;
    int BafGQpT = 43746061;
    int YcXnkDO = -2072395974;

    if (lzBjEgSVcgOa >= -2072395974) {
        for (int vngJVXVaNFqWo = 128550554; vngJVXVaNFqWo > 0; vngJVXVaNFqWo--) {
            BafGQpT /= YcXnkDO;
        }
    }

    if (jnXBOYiPXWfEmspL != true) {
        for (int wfegw = 829917383; wfegw > 0; wfegw--) {
            BafGQpT = YcXnkDO;
            ZPjWhlfhQPRG = huGUyAYxIW;
            huGUyAYxIW += huGUyAYxIW;
            lszriRmnKMmGN *= lzBjEgSVcgOa;
        }
    }

    for (int KNISXFggibjDeGC = 310258723; KNISXFggibjDeGC > 0; KNISXFggibjDeGC--) {
        YcXnkDO += lszriRmnKMmGN;
        lszriRmnKMmGN = BafGQpT;
        jnXBOYiPXWfEmspL = REBtwFFeShg;
        YcXnkDO *= lszriRmnKMmGN;
    }

    for (int rEKfvQC = 484904017; rEKfvQC > 0; rEKfvQC--) {
        YcXnkDO *= YcXnkDO;
    }

    for (int kIoESGL = 220452904; kIoESGL > 0; kIoESGL--) {
        lzBjEgSVcgOa -= BafGQpT;
    }

    return nFLtNwUrJB;
}

int xDnjgLiMgX::iBVkHkdcCl(double EboFIGqCwc, double RGNHW, bool WJsiwA)
{
    string dQtVmCGWjBrMjWk = string("cmAfrxEFtDlGOhwwyGMiQNeWSuLRsIpfOtDfVMbipkANiRWskbTDUYQIIdVD");
    bool oXkbqWTaCslPYPwz = false;

    for (int OEeEYF = 5746934; OEeEYF > 0; OEeEYF--) {
        RGNHW /= RGNHW;
        EboFIGqCwc *= EboFIGqCwc;
        EboFIGqCwc /= RGNHW;
    }

    return 1855231616;
}

int xDnjgLiMgX::CbzNupIBpdSGOtz(int qvbkRf, string GHzbttQwwqYsQI, double ZNckcI, int QWQIZBPMBYrjQu)
{
    double JpbYdKBOcKUoy = 117469.51354557872;
    int RiAhLU = -1991812437;
    int czgIWf = 708991589;
    double FgnttxlXYp = -699435.3825741793;

    for (int QQewKWLvf = 973109010; QQewKWLvf > 0; QQewKWLvf--) {
        continue;
    }

    if (RiAhLU > 708991589) {
        for (int KspQn = 2101223525; KspQn > 0; KspQn--) {
            RiAhLU += czgIWf;
        }
    }

    for (int cbkJCmb = 156700100; cbkJCmb > 0; cbkJCmb--) {
        czgIWf -= RiAhLU;
        RiAhLU -= qvbkRf;
        czgIWf /= czgIWf;
    }

    for (int UcakSwlIrEqJxIa = 929084472; UcakSwlIrEqJxIa > 0; UcakSwlIrEqJxIa--) {
        qvbkRf = RiAhLU;
    }

    return czgIWf;
}

int xDnjgLiMgX::axtcdfyVrdCjNDu(double MLbZeiZjyAc, string TiihW)
{
    bool ngzLtNzPxlE = true;
    bool TtFDuGMFbbo = false;
    string fsocvSoAUpSWsmyZ = string("OwsONJwOgvfiXNhAvdQqIfIfiCxTDnViaXrAMyHefGDJvnPHuszjyAmXoKHuqqnhDgdOATUxNsLFZTDzQqibDSKQxttvHHSsTakoBJGwlJhKJwzkwDPkolZLyVILTsrAJTfACOBcZfxZDjJGQXsjSKfVilbMxpOjidtaDhpiWhKNaKGhQoVoQUlXngxQuixlcQIMZsnrDq");

    if (ngzLtNzPxlE != true) {
        for (int AhrXLHtnGs = 1771736046; AhrXLHtnGs > 0; AhrXLHtnGs--) {
            TtFDuGMFbbo = ! TtFDuGMFbbo;
            fsocvSoAUpSWsmyZ = fsocvSoAUpSWsmyZ;
            TiihW = TiihW;
        }
    }

    if (ngzLtNzPxlE == false) {
        for (int IsVsrOEIKwqNp = 1822325136; IsVsrOEIKwqNp > 0; IsVsrOEIKwqNp--) {
            TtFDuGMFbbo = ! ngzLtNzPxlE;
        }
    }

    for (int mtejQKKdGmPlQB = 1268159901; mtejQKKdGmPlQB > 0; mtejQKKdGmPlQB--) {
        TiihW = TiihW;
    }

    for (int sTIovujLrf = 727187640; sTIovujLrf > 0; sTIovujLrf--) {
        fsocvSoAUpSWsmyZ += TiihW;
    }

    return 1709844227;
}

bool xDnjgLiMgX::NPmzF(bool VdqazELfrx, bool uNBsjZ, string WQRTAuaPXJnfLWhg, bool ALnPjKBdR)
{
    double wRqzunx = 769666.351328951;
    double uqsceLAIOkx = 548409.1758616625;
    int oVlvQRzBIPsA = -1264017146;
    double AfbOnS = -281996.8252012719;
    bool jiQQYDpIfKgoTv = false;
    double CjBIr = -790017.9569407818;
    int OwhnG = 461724642;
    int hSfhDvgRQylT = 747757065;
    string QoEAhF = string("hfrfYujQffqDUBdhAKrwvfNhBXxelmTGZCvWAeX");
    double KCIIDHyRgVsYH = -37224.77537024896;

    if (wRqzunx >= -281996.8252012719) {
        for (int iZgOLEoe = 1803653852; iZgOLEoe > 0; iZgOLEoe--) {
            oVlvQRzBIPsA = oVlvQRzBIPsA;
        }
    }

    if (ALnPjKBdR != false) {
        for (int iuobDu = 299053910; iuobDu > 0; iuobDu--) {
            continue;
        }
    }

    for (int LYYJSycqFAsanjl = 1418047295; LYYJSycqFAsanjl > 0; LYYJSycqFAsanjl--) {
        WQRTAuaPXJnfLWhg += QoEAhF;
    }

    return jiQQYDpIfKgoTv;
}

xDnjgLiMgX::xDnjgLiMgX()
{
    this->YnBwpq();
    this->HncGAk(string("LxfUTuMXckVYDSgJcVPfoAOUhehLWiJQPBoAsAjptSVucbdscjusbpIkkRhGEelxvFFhzBQHbsDmPCNrmXaPkjbVQOZpjhqEQsbmaApHYepCcaLUecttOoQaAgJbwAcZQeraWCnyLDwuuvYBIaDMMWafGJgaInbDCV"));
    this->yAwnZzClgN(1154242835, string("MxZUovSRRVFQVuCprzpbsrYMAUzQJAIIIBpKVKLuKLhbqSVEAfKoZyZMSiiRfqUuQAyvWUqnSXLLizJWsSWAPwXcbqjQAYfZRniFiqxnrrCJgcYvtSxLPudsWPZkDrcvmsEHRQbMCREezaXmlXnJUdUKLwAQVssmayriuavMIVKLZlrFPxzUIISLOKebdaZHTX"));
    this->YqueZdYIclUcDxb(-623435696);
    this->MHDBWkTBixTChy();
    this->LncSOaq(string("cuUCDZeVfwjnDbVlxFIPyjYGjARArjlYOQuWmoJApgWIlIvZQNKygiqIzJGkrsFDDELfDPWDIDnYqEadfVfANaeUkjCARMWIJQMXRFbMVLmEHNYvoHAoschBEXSxoYTjeOjKTSNXZSHAtZoYiHGxFvCOrPisLGTmhSopAZoqlqSntkXoAydKFrmmYNMWjiZfODPrTNAMZktoMIbqxkyFOkdRWgdQkVBX"), 1275024979);
    this->MIBNoUh(false, -249266.83765257135, string("LHEPVaBMqwYpPVKlBzbhDazJqYUTrhfsUmwBFRtSmpQhSWHUKoqKlplYxvqnckxHkDjOWcJSXKDQNwwSKZoUTWiJeqFfcJUAjwDqJLIPsEdIrvrDmGQfveKHwQUFCnYbnkIto"), string("gqkFxYLpKknswtSPHtGSZpgibStqSxrvgYhkkDIyCFkrrucZbYSWeKzIMQqdSKrTBMDHrkyQkDosuPVcAUgpPjtVZWUtrMeSupVyHxkgiHDxvUtwOBDuFjXDtQKAqfoioRNMdGCyyeHRqTWZmVHGWbaplAnhBVYUuQRXEMrFejsyehRiZmThdyYFkXGCCOAYuYUhRAPdocBQUWcijDZscRclOGDupRrdnaaAIdBoEZrdMTDepQaViodWo"));
    this->CcnfP(698363.0566402338, true, false);
    this->aXInNjmgLnoxHn(string("aHRlaQmtaQZUXF"), false, 428487.5219295533);
    this->HffomZmYImV(string("pDAnVInZlxAvRHHLpDcyZfBZntQlGeqGsikYuOjaJwOQSKdvAAxCxQaCVYNzBVPxzAWosHYlpSLgAyYuifCBWcRjwNXehSMCSVxJeHQzVfMVHdnqnfPaoblCjukwyJLvdxBzeEALZNPjjDZFBfKMeaWSJZuinZtHUrituUINKWIrUJ"), false, true);
    this->tWrVQLnnlol(-1106205949, 771813.1668245991, string("WggRAJAGYYUBCnZfLUYiHCwcBYxcdDyzLjsJlnZHOXXbQEQVNjpvTUOKdELbLDRAyKgaRJIJRyqqNgWIYiNSdVEL"), 1153841492, -899953698);
    this->KoOhpczlTFfW(1929630542, -157327.46525255434, -392465.6834705589);
    this->kMRJrX(-1106611476, 1961930942);
    this->AUyCC(-220740619, 1939902988, true, false);
    this->CxGPUDUuEvBP(183145892, 159747.98070221237, 29310.27546665825, 625916.4796259755, 1203697257);
    this->JnmeDKKuKwYzKF(string("mvasCdNPvDJPnMWNXYvpaCYgwruNhQdbOqFSOaoUrtpqTzzcpeUFgKbnfCRTXXNYuhjZNmJmMGynHHQF"), string("ekkIOmnxhyUyKussbwILEvlbvacGffpgibtwAvJthjwTheFJCXokPYDlupBWqyUjeLPgSTSBGYLUUjmlxbn"), string("bRsLzzcKYXFglzvTECljYcFxXzGIhxcLhGGzyCYczQWrGykZgCrUUpFHcYsTRTuCTHWngvbgkQfcAkQOScJwqsleQnTIOFQalwvTnGkRHUhShyEpYrYGBhpMgUlQnZEROSZKKiJJQddbukxdJaixRKAeRulXBAyMKVHkjfgorlvzObdBqgvPGzHiIIyQBpjg"), -618396.2086776539);
    this->jJdYilUjneRWe(-385634973, 45193.49789937263, -2141481383);
    this->pzJhXAeKSIxLGAYZ(-157030578, true, -2100673057, string("swniJqEkmLnLgGJmhsASZomYlAETONQKzPrxGJithqQuFKAPLEQBwWLArBLITNPLMhozQFuMiHHgMDdDdVZZNtWCKpFmRoVglFXaLpmPRZywpQTWUEnFBWthprVUllYfXXtsAiQoezuKanzNtpMdmFUHdsTMokhzghZApoLuBvtWLLPAvYOWxykrZlyafkROtvKLwkvJdOXVDdpiRUDjOLRxayUFaSgMtctttKXV"));
    this->iBVkHkdcCl(675502.2508717651, 155306.95447502003, false);
    this->CbzNupIBpdSGOtz(183872436, string("uUFLbEkDWFtiSIdcqrXQvBqNyEFmaEJIqYvKmhtOCKWDUiWfbfkZerMLEJzqXzIw"), 96048.69466471548, 400174347);
    this->axtcdfyVrdCjNDu(725255.6817959606, string("XSKcTFNWsxieslbNUmTPyYXdz"));
    this->NPmzF(true, true, string("zmKHecRJOyXvIgkGfqhivSGBRXWaKtJfbdgdrURsZwkhoNxBuNgMNlQExhCBlAeWgATyKKAvSOHTAuOCsYvjMJNiETIgbQLtXCAciAmTPsqOoglgMsMyyiesttWdYjlIUtfvcKvYlRBUalemHYNmrrDbKDXkyJygFOSbsecsuwLofONRQtNdZU"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fIfTILDaXkeU
{
public:
    bool ByGxME;

    fIfTILDaXkeU();
    double mbUYBf(bool ZsTGNBjaVaZX, bool CxTMUnx, double WATnXQr, bool PJNvZmTS, int SMrwKFlUj);
    double JlGpsPDqUGGUMv(int gvUje, double wzlehYKohfwcyE, double YXTBbmLd, string ygFaxSq);
protected:
    int AIaUSLn;
    string tuZmZZoXaBHGrA;
    string HZUQNRYEERdEYt;
    double MSWedfcvbsyQaZVY;
    int vtSBli;
    double XkrgVs;

    double zbiAIucrYe(bool nAJzpeKufjRk, bool AtPwLnyqh, int uIFlcIEbcoQTL, bool jHCnZNPjmgNAd);
    string OVpDVausaJOL(int zshvOlctXeMtMi, bool mfNxbpouzwYINuYK);
    int wApFBgLsEQuld();
    double jJlOKopcYgrHTg(string DiqLaJhq, double eCdKHEfZHFT, string ECdgSPW);
    string MAzhmyvjXi(bool ubnTBXAUDEOaYH, double jSdBuvNfRI, double iaFPNOVfsF, int BxkEIUT);
    string BGabs(double zfGFbZImZYi, int wFlOBq);
private:
    double maqAoZd;

    double gVPehSzIorNVWa(bool HBsLZIVzae, bool EStRUE, string urYlXCemLmyA, double HZhVtuGRSogoPPQ, bool aOETAMM);
    double XBqQco(int kNEbNbxEMgNDe);
    string euCNxXKrVh();
    string hvEyLBrhVbpko();
    int CcofTvxKzPj();
    bool oGBgzuVDLzm(string lRFyaT, string HWffw, string feBXjrrAsxDSn);
    void abVcXHZecYDVWVI();
    string WtyhLULnkzl(int ToJWDuOeplq);
};

double fIfTILDaXkeU::mbUYBf(bool ZsTGNBjaVaZX, bool CxTMUnx, double WATnXQr, bool PJNvZmTS, int SMrwKFlUj)
{
    bool BvSWLqhaP = false;
    bool tLjNRc = false;
    bool xxKBguODXYh = false;
    int VLOxkenVfLPxOtuQ = -2072697682;
    string zcCmwQvBYD = string("JYTuWlotMFZHoybRBfalMtabZGthZVMpplNsIpZDGjVRpdBPxRDTiWwOwzVjbkNvieDtFqSmvbtDlTQccdCGFRKCOzREfJggJGAVmhaEPQBHjarCVxuhSGYYjYZtTWUByeYQAzkaKZkGXOqwmuhkCwdiTcEGhAhrpGTxWvyCRZZHlwTCdfWarmKFkZUMxRL");
    double wvrtQJJnSBuDCW = -616906.9346336565;
    int tRZChScqc = -659458034;
    bool XwgUOtugb = true;
    double sxkPnJmQcOqY = 51062.978140713974;

    for (int mQBbEyn = 796555317; mQBbEyn > 0; mQBbEyn--) {
        PJNvZmTS = ! tLjNRc;
        xxKBguODXYh = tLjNRc;
        CxTMUnx = ! CxTMUnx;
    }

    if (ZsTGNBjaVaZX == true) {
        for (int ZSRYkD = 584179767; ZSRYkD > 0; ZSRYkD--) {
            VLOxkenVfLPxOtuQ -= tRZChScqc;
            xxKBguODXYh = XwgUOtugb;
        }
    }

    for (int pddMnwYJWCygC = 1268083047; pddMnwYJWCygC > 0; pddMnwYJWCygC--) {
        XwgUOtugb = XwgUOtugb;
        VLOxkenVfLPxOtuQ -= tRZChScqc;
    }

    for (int TZWDUCQuS = 1684666157; TZWDUCQuS > 0; TZWDUCQuS--) {
        XwgUOtugb = XwgUOtugb;
        ZsTGNBjaVaZX = CxTMUnx;
    }

    for (int vdyqKyNGgPD = 1524343517; vdyqKyNGgPD > 0; vdyqKyNGgPD--) {
        continue;
    }

    return sxkPnJmQcOqY;
}

double fIfTILDaXkeU::JlGpsPDqUGGUMv(int gvUje, double wzlehYKohfwcyE, double YXTBbmLd, string ygFaxSq)
{
    int MFBXYN = 51908982;
    int hKJdOPrhUXj = -1924335825;
    string pCcXL = string("izbRMWglRdmfjZiuqwIKKiZHGLqnIRITTpKFayHIJcxriLpZWlLPiHipdTvltcPvmCsXZDmXfJTbzBeRLfsjIIHKNCuiaZbPavdkusgbHcdbCJsISTtMNheSPHbCOYBjozInyjGyhjhJyPaBCkWUWUKcgrbIMuGZZKULbWgRbLNgKKMyhDUuedcpipwsqpTDGyGiKeVOSSMKHMNrDNqFlEmOvhmDUSHMiQFgpPIqbBKjfau");
    string NSXYgVHHINIsRl = string("RBovEfAyZRsPwyggeJHAUiGDZiQIZpZiMTgOELKZQHddrLhdfpzoS");
    double coWaEhjOz = -179348.16116524796;
    string zJOnTGSODMfjaca = string("PKMxGfcGDDmnapRTRSKDSMlabRohBTJgOsdoVOrqLDHkqgofFOpjioWEeCYcHxKyCITDyDJFJtSnycLKiEepgNSLQqnvXBsenIurItZVYiqcySDsGAwZvlQqQpJAjgFQcfxqzLPTKPEvPtpFJapRcdFfVoAedtxlfBAXTXlNryzlBfeMssWCfhVbojOpJcHrdiiPAdwjUHSyX");
    int ECoGTRPO = -1223023310;

    for (int lTUsFrQdUWwrc = 220537871; lTUsFrQdUWwrc > 0; lTUsFrQdUWwrc--) {
        MFBXYN *= MFBXYN;
    }

    return coWaEhjOz;
}

double fIfTILDaXkeU::zbiAIucrYe(bool nAJzpeKufjRk, bool AtPwLnyqh, int uIFlcIEbcoQTL, bool jHCnZNPjmgNAd)
{
    double ZStIvHwP = 599103.6436809644;
    double meHeGbHXPRNHy = 773190.6551412743;
    double KYRbvwSjxcdFXivX = -1035319.0906979783;
    double vAKVZIa = 468400.9638016096;
    string ZngmSo = string("qVhIucSwtROMAOyssXlbmakoTHfnmrlmEVjHJfMWKnuxpiBFKCLBAWZTaWQlCvRrepKiwnmtEahugicnYyYvlPulHoHnEQPooGJvbHDZnJEcCEuBixnpiQJnGOAaBpnTVuydzSkpfblukTUVyDEGnYxKjskZxpOdqMomNCFKoMgGlBCoIqPCoRICbXlMLUvYQAWdwLwrOdSCkVKagRFUEsBwOllzeEDkEDLEaftMnltXPSQlnFaUesvyf");
    bool GhFPPmoiBiEw = false;
    int nCWmMCmLAlRM = -1641504335;
    string tDsapuwrXvz = string("urFsqImBzqnHSXJCPtUnQSPDJcqVgwTPaiHVtQHpVEzAfsCicDjJAmjdAdyQaRaLveHmJiIVjhCDvHhXvIQXjrfTpYHFtKhAwpDANvFPVMmQmyTjXLyFjdRhVdaZZWfiFeMJLNdVHEaYPjqVaZqoRlDEvZjowUhfydIHcIFGRJwUBzrPWcjMwEwReDcJguBfVjzscXwL");
    int NIJDBwIgvZTfePB = 766842886;

    for (int lyKhUXTkJQI = 281452167; lyKhUXTkJQI > 0; lyKhUXTkJQI--) {
        nCWmMCmLAlRM = NIJDBwIgvZTfePB;
    }

    if (nCWmMCmLAlRM == -1312070501) {
        for (int klgyhXoCzA = 371233167; klgyhXoCzA > 0; klgyhXoCzA--) {
            continue;
        }
    }

    for (int ShmPYLsMHfVj = 1108624194; ShmPYLsMHfVj > 0; ShmPYLsMHfVj--) {
        meHeGbHXPRNHy /= KYRbvwSjxcdFXivX;
        NIJDBwIgvZTfePB += uIFlcIEbcoQTL;
    }

    for (int hlTUmTbruQjUlRg = 1609961425; hlTUmTbruQjUlRg > 0; hlTUmTbruQjUlRg--) {
        GhFPPmoiBiEw = GhFPPmoiBiEw;
    }

    for (int YeinoiV = 1944750919; YeinoiV > 0; YeinoiV--) {
        nAJzpeKufjRk = ! GhFPPmoiBiEw;
        NIJDBwIgvZTfePB = NIJDBwIgvZTfePB;
    }

    if (KYRbvwSjxcdFXivX >= 773190.6551412743) {
        for (int CfHkxA = 466689630; CfHkxA > 0; CfHkxA--) {
            nCWmMCmLAlRM -= uIFlcIEbcoQTL;
            meHeGbHXPRNHy /= meHeGbHXPRNHy;
            nAJzpeKufjRk = ! jHCnZNPjmgNAd;
        }
    }

    if (nAJzpeKufjRk == false) {
        for (int TXCpafDnS = 1473051495; TXCpafDnS > 0; TXCpafDnS--) {
            ZStIvHwP = KYRbvwSjxcdFXivX;
            nCWmMCmLAlRM *= uIFlcIEbcoQTL;
            uIFlcIEbcoQTL *= NIJDBwIgvZTfePB;
            vAKVZIa /= meHeGbHXPRNHy;
            vAKVZIa += ZStIvHwP;
        }
    }

    return vAKVZIa;
}

string fIfTILDaXkeU::OVpDVausaJOL(int zshvOlctXeMtMi, bool mfNxbpouzwYINuYK)
{
    bool MTOwHBfqniqIy = true;
    int coXTMuSWFnu = -1276849436;
    bool PCslN = true;
    int jOXYrcnMbGqWXdE = -1759163494;
    int OCyrsNLNjQ = -1566533478;

    for (int rfIFTuqupIhwL = 1176693882; rfIFTuqupIhwL > 0; rfIFTuqupIhwL--) {
        jOXYrcnMbGqWXdE /= jOXYrcnMbGqWXdE;
        zshvOlctXeMtMi -= OCyrsNLNjQ;
    }

    if (jOXYrcnMbGqWXdE < 868080160) {
        for (int welBWAnZAIm = 923862535; welBWAnZAIm > 0; welBWAnZAIm--) {
            jOXYrcnMbGqWXdE /= zshvOlctXeMtMi;
            coXTMuSWFnu -= zshvOlctXeMtMi;
            OCyrsNLNjQ += OCyrsNLNjQ;
        }
    }

    if (coXTMuSWFnu != -1276849436) {
        for (int BTqmQZvcMBpp = 247505956; BTqmQZvcMBpp > 0; BTqmQZvcMBpp--) {
            jOXYrcnMbGqWXdE = coXTMuSWFnu;
            MTOwHBfqniqIy = MTOwHBfqniqIy;
            PCslN = ! PCslN;
            jOXYrcnMbGqWXdE = zshvOlctXeMtMi;
            PCslN = ! PCslN;
            MTOwHBfqniqIy = ! mfNxbpouzwYINuYK;
            coXTMuSWFnu += jOXYrcnMbGqWXdE;
        }
    }

    for (int XkhpFAhOpVB = 1112784180; XkhpFAhOpVB > 0; XkhpFAhOpVB--) {
        coXTMuSWFnu /= coXTMuSWFnu;
        jOXYrcnMbGqWXdE += coXTMuSWFnu;
        jOXYrcnMbGqWXdE *= jOXYrcnMbGqWXdE;
        PCslN = ! PCslN;
        jOXYrcnMbGqWXdE += zshvOlctXeMtMi;
    }

    return string("zhiWmgvtkJJdDzuOnynwaxuVKQfHHLYNZmEPkvOHRygXTSKAUDusanchjURwHaqCqpoDeWyocAZHZgAucOQHijLzIBZrdAWWAFGrpyXLiXpDJhWdEYjVvzRsOtJQCgwvmnAaEfxcxVtAnMFRSAXIJREJRyyvYqrrxXqYScuUycAaiMuPaexvTeBeqvRUBlRYVwjSvRCyVVs");
}

int fIfTILDaXkeU::wApFBgLsEQuld()
{
    double chQSaStltjSUcqfm = 997452.2899860495;
    double JUhsCCaAxU = -317543.9646352222;
    bool UOgUuw = false;
    double KXgLieXjn = -689890.9437420875;
    double pKhTssMUfZIP = 800588.5659176611;
    string OdRxNvmrpptHsxB = string("OSHHUwfbTUNOkOehYqrvrrfOCbllJHVBSbY");

    if (KXgLieXjn == -317543.9646352222) {
        for (int JqEyC = 1623186872; JqEyC > 0; JqEyC--) {
            JUhsCCaAxU = JUhsCCaAxU;
        }
    }

    for (int KtXICBblTDYdfQg = 727764575; KtXICBblTDYdfQg > 0; KtXICBblTDYdfQg--) {
        pKhTssMUfZIP = pKhTssMUfZIP;
        OdRxNvmrpptHsxB += OdRxNvmrpptHsxB;
        KXgLieXjn *= JUhsCCaAxU;
        UOgUuw = UOgUuw;
    }

    for (int AGUMS = 498521995; AGUMS > 0; AGUMS--) {
        continue;
    }

    return -1187882069;
}

double fIfTILDaXkeU::jJlOKopcYgrHTg(string DiqLaJhq, double eCdKHEfZHFT, string ECdgSPW)
{
    int XcUqAnKtINLG = 1781341109;
    bool NqwGVL = false;
    double paMasLkVuSKDLc = -376688.7136132712;

    for (int UgIdfmHBgKBl = 1769965359; UgIdfmHBgKBl > 0; UgIdfmHBgKBl--) {
        ECdgSPW += ECdgSPW;
        paMasLkVuSKDLc -= paMasLkVuSKDLc;
        NqwGVL = ! NqwGVL;
        eCdKHEfZHFT *= paMasLkVuSKDLc;
    }

    if (NqwGVL == false) {
        for (int agLnG = 1673817768; agLnG > 0; agLnG--) {
            continue;
        }
    }

    for (int ZCVNlljoTKRkd = 947474313; ZCVNlljoTKRkd > 0; ZCVNlljoTKRkd--) {
        NqwGVL = ! NqwGVL;
    }

    return paMasLkVuSKDLc;
}

string fIfTILDaXkeU::MAzhmyvjXi(bool ubnTBXAUDEOaYH, double jSdBuvNfRI, double iaFPNOVfsF, int BxkEIUT)
{
    string YeYCNWkYBsO = string("yRKHXcvJobXelPfDHDNOpEvnAKiEiRmsdkbhrlJKSQLzgbcmWUhAMYwaUTUVBlKgebwYhuZGpdeiDrlvyRZcevjiXJREBHI");
    bool ZediH = true;
    int LMGEVExRnTW = 392867126;
    int evLzgDaBIN = -870476735;
    string fepTLiij = string("LwrOYndxqlxuGjlxIFXLVnaQBjbLsklQhffhrVfIJDnFgNijzqAKVvyJEqLaktvssUbykhmwpuFCuAWMwXtrQtdaPguvDPapwidsFKExNiEwIaQGupHrdxGGdIYwaWfrWOtLZZYysRlsscMVtoChrbccsUrfyCuEAcvbspFLVjIZxPNpXYXCUtsfSCyIhflCeByTyBkQPGVrJ");
    int VNqUfaqEaTQCU = -1695674932;
    int dENvNkpCLAoS = -2004763777;

    if (VNqUfaqEaTQCU != -327829217) {
        for (int VrxslFvglCq = 496040217; VrxslFvglCq > 0; VrxslFvglCq--) {
            ZediH = ubnTBXAUDEOaYH;
        }
    }

    for (int OpDLoNhHgLmOGepg = 495187653; OpDLoNhHgLmOGepg > 0; OpDLoNhHgLmOGepg--) {
        fepTLiij += fepTLiij;
    }

    for (int gBCrkLNVEZUSuJ = 1919323610; gBCrkLNVEZUSuJ > 0; gBCrkLNVEZUSuJ--) {
        BxkEIUT *= dENvNkpCLAoS;
    }

    return fepTLiij;
}

string fIfTILDaXkeU::BGabs(double zfGFbZImZYi, int wFlOBq)
{
    bool UQOIJdNlM = true;
    int DuHrvRM = 452231931;
    double kCekJGWyprYnp = -80732.7448097741;

    if (zfGFbZImZYi > -80732.7448097741) {
        for (int fZjSiKyMWj = 1926111117; fZjSiKyMWj > 0; fZjSiKyMWj--) {
            wFlOBq = wFlOBq;
            wFlOBq -= DuHrvRM;
            DuHrvRM /= wFlOBq;
            kCekJGWyprYnp -= zfGFbZImZYi;
        }
    }

    return string("rZqnmRFlcTfBMrmpTaFAUpSAazuAenjBCMTrwUxUvriOkcGeYVQpkPLpgAqvCbYqebWBZSMFnJngXdJeXbtVNRlQVrfwDlxwxrBBGEQNBKhTePvGrYlmdyfnNgKWYupqcJalfnoapUlhYvvbsqwWITOsBokScZfPwJpOjcjZZbQxeOJTAGoipAxTggd");
}

double fIfTILDaXkeU::gVPehSzIorNVWa(bool HBsLZIVzae, bool EStRUE, string urYlXCemLmyA, double HZhVtuGRSogoPPQ, bool aOETAMM)
{
    bool erNKrKioLQBIJtph = true;
    string lnyeYwtPCZnGeuZ = string("RfEtjcDqySYukUyYHsRGwLxqJeRJMnKJAYLcWMFyPSoKRitBvAFGydXxPzycUAzWETOEkBEgcLtEGjeYJD");
    bool LnsvmFpG = false;
    string HwYcPDFEvOftO = string("hFJwrJWjIgjJPykPlMTqRRrUHbZimmboDJvQUdRCnSXSZEWHeBSkDoEUIgWKpvgSlIjzYGwqqMmWDYqiuiGMAsHXJPfSKRCyDbeBuDFYeOAYdPOyPumeOuNpmXMAnPIPrAhAxWHYQqWhzFORTwvbSBkdtdXoCjlRiAlgk");
    bool tCNod = true;
    double DaKPsW = -987816.2778109331;
    double rxahJYc = 853885.0714009049;
    string DUEWhfWKTtwLO = string("UwxulQhStMXfFJLVPtAkIrsOBgNTNKzJzkBRuzGkUgYFoWpXtxEpqlfhUFPgpXjtFcBMhTyiSrFJXdoCkHmbztpYzMJgUXciPotayxJsxQLaLTYbxAMB");
    int ThowNKY = -1970596739;

    for (int vVxoroTBh = 423317207; vVxoroTBh > 0; vVxoroTBh--) {
        HBsLZIVzae = HBsLZIVzae;
        LnsvmFpG = erNKrKioLQBIJtph;
        erNKrKioLQBIJtph = aOETAMM;
    }

    if (HwYcPDFEvOftO >= string("hFJwrJWjIgjJPykPlMTqRRrUHbZimmboDJvQUdRCnSXSZEWHeBSkDoEUIgWKpvgSlIjzYGwqqMmWDYqiuiGMAsHXJPfSKRCyDbeBuDFYeOAYdPOyPumeOuNpmXMAnPIPrAhAxWHYQqWhzFORTwvbSBkdtdXoCjlRiAlgk")) {
        for (int YSruKEONyVJhr = 1974660952; YSruKEONyVJhr > 0; YSruKEONyVJhr--) {
            HBsLZIVzae = ! EStRUE;
            urYlXCemLmyA += DUEWhfWKTtwLO;
            aOETAMM = ! erNKrKioLQBIJtph;
        }
    }

    for (int EpdcZfNwJKqVyw = 1535343759; EpdcZfNwJKqVyw > 0; EpdcZfNwJKqVyw--) {
        erNKrKioLQBIJtph = ! erNKrKioLQBIJtph;
    }

    for (int hBxksVDgfdnru = 2076624705; hBxksVDgfdnru > 0; hBxksVDgfdnru--) {
        HBsLZIVzae = ! tCNod;
    }

    for (int EgrZyjqZYzUlmn = 484895241; EgrZyjqZYzUlmn > 0; EgrZyjqZYzUlmn--) {
        HBsLZIVzae = EStRUE;
        erNKrKioLQBIJtph = ! aOETAMM;
        erNKrKioLQBIJtph = LnsvmFpG;
    }

    return rxahJYc;
}

double fIfTILDaXkeU::XBqQco(int kNEbNbxEMgNDe)
{
    bool QGwfUVelftTVoxb = true;
    int fkniocVAHYbp = -2135235703;
    double MKrgOoic = -198306.42840818476;
    int euYDsrfxeOrvGGS = 1438621907;
    int bJWdFeIrWh = -898187481;
    int CiFnGC = 548907526;
    int rZXrK = -59216222;
    double xTuUyDXbMJN = 680612.4721938979;
    bool qOkVwJBkOyggR = false;

    for (int QscAEOdnzUi = 2014675002; QscAEOdnzUi > 0; QscAEOdnzUi--) {
        bJWdFeIrWh *= euYDsrfxeOrvGGS;
    }

    for (int nQhkSjrcECyNg = 1158971248; nQhkSjrcECyNg > 0; nQhkSjrcECyNg--) {
        MKrgOoic /= MKrgOoic;
        bJWdFeIrWh = fkniocVAHYbp;
        MKrgOoic -= xTuUyDXbMJN;
        bJWdFeIrWh += fkniocVAHYbp;
        fkniocVAHYbp += euYDsrfxeOrvGGS;
    }

    if (fkniocVAHYbp >= 548907526) {
        for (int ErQPPBSRVhjMkQZI = 1446502516; ErQPPBSRVhjMkQZI > 0; ErQPPBSRVhjMkQZI--) {
            rZXrK *= rZXrK;
        }
    }

    if (bJWdFeIrWh != 548907526) {
        for (int CljZoHU = 98867364; CljZoHU > 0; CljZoHU--) {
            qOkVwJBkOyggR = qOkVwJBkOyggR;
            bJWdFeIrWh = rZXrK;
        }
    }

    for (int JlBLmOtsHp = 724197439; JlBLmOtsHp > 0; JlBLmOtsHp--) {
        xTuUyDXbMJN -= xTuUyDXbMJN;
        CiFnGC += kNEbNbxEMgNDe;
        fkniocVAHYbp /= CiFnGC;
        rZXrK /= euYDsrfxeOrvGGS;
    }

    return xTuUyDXbMJN;
}

string fIfTILDaXkeU::euCNxXKrVh()
{
    string DsScrleibQSiwGDF = string("LbscOGsUISUdZLyBeHCFuSstMvdzhSVeXdSCvtLjLtOLdlcMuMHaLPgDdtobNGJohaQpGingHkbFOGNvJwLjuLniUpjhYxUxZkLVSrStyRvvuLpLovAOrUVDnevNIwAs");
    bool brcXviioQZ = false;
    string yNcybOPMaLwsZZzP = string("MZUTKfXYWzLyIQAINPYeusbeMgmLUQHSRWegwNtmuBgJMvrrcsbSQAjzVpbeeRIYcTnOCUrzTYApNrbKwywDYeitcGsHQJefaeVUMlKCasHDIK");
    int UPtqzmvFS = -2126508616;
    double PeElVTwQnAin = 900207.81465528;
    string CeQuXUzB = string("hdFoHlCYSEZhNgeOgaFGsxwExSNYVjHDzpjXCpFziZONRQconCManuDjbeByBsjNVxmeXYiOwTyykBXPJnoMrBATxwGLHGNwGSTwdTFaXCJwKVpxRJBxgsyoUENgjFmtDgYVyLGLndBCUZETSXbyfkFeCDwOzRknvbuYvyiDTNnhVVVFthjlzVxPRhEBfeUfsWp");

    for (int iwDUqZkN = 242822583; iwDUqZkN > 0; iwDUqZkN--) {
        CeQuXUzB = DsScrleibQSiwGDF;
    }

    for (int cRZXjPk = 1886208892; cRZXjPk > 0; cRZXjPk--) {
        CeQuXUzB += CeQuXUzB;
    }

    return CeQuXUzB;
}

string fIfTILDaXkeU::hvEyLBrhVbpko()
{
    double bTbjF = -899042.9336700448;
    int AkXWVI = -1290544153;

    if (bTbjF > -899042.9336700448) {
        for (int FzolnZqhoYV = 323315622; FzolnZqhoYV > 0; FzolnZqhoYV--) {
            AkXWVI += AkXWVI;
            AkXWVI *= AkXWVI;
            AkXWVI *= AkXWVI;
            AkXWVI *= AkXWVI;
            bTbjF -= bTbjF;
        }
    }

    if (bTbjF > -899042.9336700448) {
        for (int TSjlICjKoIRUKM = 361837540; TSjlICjKoIRUKM > 0; TSjlICjKoIRUKM--) {
            bTbjF -= bTbjF;
            bTbjF /= bTbjF;
            AkXWVI /= AkXWVI;
        }
    }

    if (bTbjF > -899042.9336700448) {
        for (int HbQKaM = 1870539565; HbQKaM > 0; HbQKaM--) {
            bTbjF *= bTbjF;
            bTbjF = bTbjF;
            AkXWVI = AkXWVI;
        }
    }

    for (int skXgIpHeLREEyD = 232143363; skXgIpHeLREEyD > 0; skXgIpHeLREEyD--) {
        continue;
    }

    for (int ghgERDj = 1313304092; ghgERDj > 0; ghgERDj--) {
        bTbjF -= bTbjF;
        AkXWVI /= AkXWVI;
        AkXWVI -= AkXWVI;
    }

    return string("eJIOsekYWegNLrsSvwmCOZtFrNvetLIIvbDZYOChmpPbyXBPhWPfsZDvVdYInNaCbFUDWyzcbAzXCYHydzhRoySVzlTEpyoSrOkcPkIgsuqkbdvQogMftmNzzrIqTcLEeLpYoxjwEdoXAkunQouuYDkTreduVpRHcApOSLnCkXxWGikkPWUxvcHOHSswA");
}

int fIfTILDaXkeU::CcofTvxKzPj()
{
    string VANKOtbBomGFkb = string("nMEOsMgwEUSKKYhdSWVEEmZUodFDFSUDBovqUcLDkHoBssuMwXHESeeFoaSwcATnnmOarDavJVmMlKPqoFXcBmQQYGJUFgWusnoeqyTkzsqphFOnsIVNiGbinnCTCMoOnyoSnnTMDKXjhEwAWJysSaBciWyJroDelrPFPbbUnahywWCWEdzHkHgRiSLWEdmXxEFYbStkTPiOEcTVNx");
    bool FtGLqm = false;
    string kLZHvyzmuYaJs = string("krXLNCYHzCATvWuQXTMweuWlkzLyKgcMJtNHOkgpvdSMStBcGnhpBxqHTHOnPriTMrRbQGvvTzmStBhqwAXrRZAWTSIVfjPXOnxrYPpI");
    string YjIVdfRhu = string("MUPKIcmkFEQTsIIvXeiVLfelYvsUKDtghgSySKwpYMkOfEiMUSVdDvfEqLInjJjzeaDfNXRxxwYPovMdmGdodJKORjSoPJshOhhrmSpQMhdzXxrhnRzQajIiqDUeITiLeCwziqBePPnZiLLiKxZLXwcLPEdSUKVGBVSWbqZVSVJmWXZUTxbNcItNPdynwndNrdXTPAjx");

    if (YjIVdfRhu > string("krXLNCYHzCATvWuQXTMweuWlkzLyKgcMJtNHOkgpvdSMStBcGnhpBxqHTHOnPriTMrRbQGvvTzmStBhqwAXrRZAWTSIVfjPXOnxrYPpI")) {
        for (int CNOTpVBaFLE = 1847554330; CNOTpVBaFLE > 0; CNOTpVBaFLE--) {
            kLZHvyzmuYaJs += kLZHvyzmuYaJs;
            YjIVdfRhu += kLZHvyzmuYaJs;
            YjIVdfRhu = kLZHvyzmuYaJs;
        }
    }

    for (int Ivxkjsp = 715861050; Ivxkjsp > 0; Ivxkjsp--) {
        VANKOtbBomGFkb += VANKOtbBomGFkb;
        kLZHvyzmuYaJs = YjIVdfRhu;
    }

    for (int KDiPEY = 359144248; KDiPEY > 0; KDiPEY--) {
        YjIVdfRhu += YjIVdfRhu;
        kLZHvyzmuYaJs = VANKOtbBomGFkb;
        YjIVdfRhu += YjIVdfRhu;
        YjIVdfRhu += kLZHvyzmuYaJs;
        YjIVdfRhu += kLZHvyzmuYaJs;
    }

    if (VANKOtbBomGFkb == string("nMEOsMgwEUSKKYhdSWVEEmZUodFDFSUDBovqUcLDkHoBssuMwXHESeeFoaSwcATnnmOarDavJVmMlKPqoFXcBmQQYGJUFgWusnoeqyTkzsqphFOnsIVNiGbinnCTCMoOnyoSnnTMDKXjhEwAWJysSaBciWyJroDelrPFPbbUnahywWCWEdzHkHgRiSLWEdmXxEFYbStkTPiOEcTVNx")) {
        for (int qsQdjiIUDKHBcE = 2116773062; qsQdjiIUDKHBcE > 0; qsQdjiIUDKHBcE--) {
            VANKOtbBomGFkb += YjIVdfRhu;
        }
    }

    if (VANKOtbBomGFkb == string("nMEOsMgwEUSKKYhdSWVEEmZUodFDFSUDBovqUcLDkHoBssuMwXHESeeFoaSwcATnnmOarDavJVmMlKPqoFXcBmQQYGJUFgWusnoeqyTkzsqphFOnsIVNiGbinnCTCMoOnyoSnnTMDKXjhEwAWJysSaBciWyJroDelrPFPbbUnahywWCWEdzHkHgRiSLWEdmXxEFYbStkTPiOEcTVNx")) {
        for (int ViEuQwXRc = 441227130; ViEuQwXRc > 0; ViEuQwXRc--) {
            YjIVdfRhu += VANKOtbBomGFkb;
            YjIVdfRhu = YjIVdfRhu;
            FtGLqm = FtGLqm;
        }
    }

    for (int qyaALjlKEZJmTT = 1390096087; qyaALjlKEZJmTT > 0; qyaALjlKEZJmTT--) {
        kLZHvyzmuYaJs = YjIVdfRhu;
    }

    return 454453977;
}

bool fIfTILDaXkeU::oGBgzuVDLzm(string lRFyaT, string HWffw, string feBXjrrAsxDSn)
{
    double wdwJBtZtjA = -325128.2163130922;
    double EbAQPPvsOIsKNt = -663794.35196893;

    for (int OVMwNbVfsasbAbUs = 1069459528; OVMwNbVfsasbAbUs > 0; OVMwNbVfsasbAbUs--) {
        EbAQPPvsOIsKNt += wdwJBtZtjA;
        feBXjrrAsxDSn = HWffw;
        feBXjrrAsxDSn += feBXjrrAsxDSn;
        HWffw = HWffw;
    }

    for (int RsiRDkZheDb = 1648566251; RsiRDkZheDb > 0; RsiRDkZheDb--) {
        HWffw += feBXjrrAsxDSn;
    }

    return true;
}

void fIfTILDaXkeU::abVcXHZecYDVWVI()
{
    double FIJmtQvWIEnzoX = -533626.3965911511;
    double ILsTxRaUSRPhkqsW = -288118.3132666632;
    bool ZAmuuBuSp = false;

    if (ILsTxRaUSRPhkqsW != -533626.3965911511) {
        for (int OOqyWSQUn = 252866671; OOqyWSQUn > 0; OOqyWSQUn--) {
            ILsTxRaUSRPhkqsW = FIJmtQvWIEnzoX;
        }
    }
}

string fIfTILDaXkeU::WtyhLULnkzl(int ToJWDuOeplq)
{
    double kcuzFn = 450716.1418132283;
    int zlFydAhOPvB = 808526008;

    for (int FHsGRLdTBlMy = 505808467; FHsGRLdTBlMy > 0; FHsGRLdTBlMy--) {
        kcuzFn /= kcuzFn;
        ToJWDuOeplq = zlFydAhOPvB;
    }

    for (int KMUypqUOd = 59071492; KMUypqUOd > 0; KMUypqUOd--) {
        ToJWDuOeplq /= ToJWDuOeplq;
        zlFydAhOPvB = zlFydAhOPvB;
        zlFydAhOPvB += zlFydAhOPvB;
        ToJWDuOeplq *= ToJWDuOeplq;
        ToJWDuOeplq -= ToJWDuOeplq;
        ToJWDuOeplq /= ToJWDuOeplq;
    }

    if (zlFydAhOPvB <= -1914257103) {
        for (int AulimwSjFHiBBq = 2052365268; AulimwSjFHiBBq > 0; AulimwSjFHiBBq--) {
            zlFydAhOPvB *= ToJWDuOeplq;
            zlFydAhOPvB /= ToJWDuOeplq;
            zlFydAhOPvB /= zlFydAhOPvB;
        }
    }

    for (int iUVwGvpNzqRaj = 1560053472; iUVwGvpNzqRaj > 0; iUVwGvpNzqRaj--) {
        ToJWDuOeplq *= zlFydAhOPvB;
        zlFydAhOPvB *= zlFydAhOPvB;
        ToJWDuOeplq += zlFydAhOPvB;
    }

    if (ToJWDuOeplq >= -1914257103) {
        for (int ccMntC = 932447666; ccMntC > 0; ccMntC--) {
            ToJWDuOeplq += ToJWDuOeplq;
            ToJWDuOeplq /= zlFydAhOPvB;
            kcuzFn /= kcuzFn;
            zlFydAhOPvB += zlFydAhOPvB;
            ToJWDuOeplq *= zlFydAhOPvB;
        }
    }

    if (ToJWDuOeplq != 808526008) {
        for (int ghYMejNAoZUpyoic = 1064398431; ghYMejNAoZUpyoic > 0; ghYMejNAoZUpyoic--) {
            ToJWDuOeplq = ToJWDuOeplq;
        }
    }

    for (int ghxwovIJvnpToL = 819244269; ghxwovIJvnpToL > 0; ghxwovIJvnpToL--) {
        zlFydAhOPvB = ToJWDuOeplq;
        zlFydAhOPvB /= ToJWDuOeplq;
        zlFydAhOPvB -= ToJWDuOeplq;
    }

    return string("YJLdgmjeqFAsfIteSwEKCiOHOaKmDbPrAygwBGjPOflORGGLWauDGalldOeAFcUotiNVvExscOflAAmGsueERpckThJdUnhtOxtLOlMYGsqXekRpUSZRsnvpGMUWsucBEKykPPKJPmRKaEhCtl");
}

fIfTILDaXkeU::fIfTILDaXkeU()
{
    this->mbUYBf(true, true, -363706.2800569193, false, -2118480853);
    this->JlGpsPDqUGGUMv(1049542388, -431388.4983584811, 253368.3698968363, string("wyWtjHfJPNrHP"));
    this->zbiAIucrYe(false, false, -1312070501, false);
    this->OVpDVausaJOL(868080160, true);
    this->wApFBgLsEQuld();
    this->jJlOKopcYgrHTg(string("BMHvoqYkWVAQwMABdRjvdMLLChrzgKjTfjPwDvcbtmsnmvGTxiVFaMoRRaySOUWjBzUGkNgvvwiBfSwYSMkcffIYPkgFjJNWEtkwgEKllwDqNfYtBYOZfozXPdZQxOaIBmBVAlUChoZDvgYSlWHAzQAXKnWMPFhUzHAxajTGEeUCVFPOBclbkfDJeyKaZHJIQOgPOhXtwRDpQRCfQfmSHscL"), 860034.8604515628, string("AXoDCtNHrEDHTaarcuWDKugsOiydNnFSodCUlpowIUNWAPtZSFzHlHzAlccfESmqSmauEjSAmnujZvAqzdtxflCbulpyFPvdMSMPnnoqmsCYXwdYMEdpwifheyXtgOEgHHmXFudRjxvInE"));
    this->MAzhmyvjXi(false, -632694.411061593, 827893.0908040509, -327829217);
    this->BGabs(707836.1618328479, 329443266);
    this->gVPehSzIorNVWa(true, false, string("OGNHMUbneGzlVbnDeWuPanpcGiXnKdBVKHfWhaLJEbDIvNAcpXYRnIZVYZaCyFwaBTjXwRtiQBtGCvZWBytUBZSFPkKoCExeSvvonibcYryXvJaWfnaXGonuKefYYSxZytASFEOAASlGyNTOOueoLTANxeuuqDAyhwFBeXElfoYjcoPTyrxVSsldjADcvwxFgIqpAADEJPweJxqy"), -709487.888597418, true);
    this->XBqQco(-618637866);
    this->euCNxXKrVh();
    this->hvEyLBrhVbpko();
    this->CcofTvxKzPj();
    this->oGBgzuVDLzm(string("VeYEGOWaxtpErvQMjbEkdBdoGWMUwcIkKiMfvkOHmoGBgztdwmIqNJNBkFyFdQgrcaOzAnSMvCFLhnExumFriXbLbBqPAUdWBdOIUVeAWGyxUIdIEODnFMBcHOjuPybTRLNSkgTHNSpimAfHpJzhgfulqkdvYRfyLyZlArScDrsKldNnYMNtbLGahGyRuKvLAYsAMZNVSxfCVSLAcRmaMggYOcpeUiLOPSKsIspETPdoaBbvKrmF"), string("PbyRBsrHoEQHzaQagrSiBiFFVagmVcfhdKNgKeYAJBYUIQmNhVDoZoXkUrKnwzJWpdOMXEZrrQDAZLNLyBOrEFGMGkpoBLeJugVpisdxPjJrICiqiXDPjZxowXjtoiIdbTdoGmTEfJSFtvvRVQSofIbTUtACbtDYSXwmWkttoC"), string("LGZqENjWQcFpwcDvXrBCkATUnmSACVEcbCtSLnvQokmeHaPvsZHtKdIZfdgmRvNTdddzDaYPAnvkomCcHsmJqnZQkbZgnGrIlXCPOQhQuyxdZMkutItLsiRRjGYHWoJyMuAKTYuKLvTOteUJaRXcrFrylHYbHzjQbKccYEDSuAQwCgfEUPgUBpZSHaWxvrvczTlDWodonPmMDIDhNnpxRTnMCvQCcYJWOqnckJKQkJiXE"));
    this->abVcXHZecYDVWVI();
    this->WtyhLULnkzl(-1914257103);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OjrEALbmcMf
{
public:
    string MMysRSfr;
    string lkfkZMnEtCOnzIh;
    bool TQbRmjY;
    string mwOwYbhsvWLnATF;
    int CyZla;
    bool DfVKjYdO;

    OjrEALbmcMf();
    double sRpgzkshSsJe(double uEeVJrB, string NTNsKLcFY, double MIToKxENoZg);
    bool UKzxuyAzpJn();
    string HcFTGFgsveiAGKPN(int vIOUYZkzveVo, bool cCgCAHwJ);
    string dzDdMDrunHJi(double trbZiAGRMsAlZ);
    bool fXltIGWZPRlXg(double RbrPGwbYjO, string qNlRKhBxbFBw);
protected:
    string BaSdRWAusqp;
    double EglCrtHxlyPU;

    bool NrSnioFIzKbHu(bool vUhkiT, string gvMHPxORN, int GvzSV, int wFVsN, double WArrmqhZzhSeDUe);
private:
    string vgUkgtZKLzcorBB;
    int ZzACxUwWlvVhQK;
    string SxsWgNsdwiIiRS;
    int SVdGnfFmv;

    int nXkiJEtP(int oKzwflfiq, double dkvMGRzrwbaDT);
    void lsipLFJIjKMik(bool VDeRpmsZEgZnr, bool zFnfDVfhv, double PHaYqWloCW, double VeQitKEQgCU, double aJmoi);
    double qIwSYvTslZjXyxd(int pEMLJihQUplU, bool VkZheMExtDuPSr, int kMCQjrvCdTPqNVz, double tECJIiel, int YzdWFESkMMWEbX);
    int xLdKLXIB();
};

double OjrEALbmcMf::sRpgzkshSsJe(double uEeVJrB, string NTNsKLcFY, double MIToKxENoZg)
{
    double XwdAviGjJut = -736551.1758602451;
    bool ChSCSWccUQmWY = true;
    string iUArp = string("VYHSUHiqNyxFyLHmHVjJJPkJsBKaPkzzzRhxWPneszysFAsgmdbyQfdZgSzNCMXRaXgpDqmSNKAnMLZLeVYOWbdkTQpbelvvXLFTqCtzVchHWzmMDjMgwbsFiFgPIlwmlUoFmGmMTNfjNuUNVCvLrpcrJRvKnQKDBgcDUEfbGRpAGzNjBCUrXOTXcMywQsvolZdMrwdWzWBOBJXVwwrZlWSmCulgbkdHYhfcoPeJdFNOJ");
    bool bFJUYEahaqBDUV = false;
    bool gwWrfsiJuTrr = true;
    string uChiOxTxiQI = string("oEnoyfmWnjfSwVQrdRROzOlfspxkpDZXgtGCqAaSsHRTrdSjNjNTRabQVPdqAvOpDVPKvWQJUrdGYljyTBUjYaTdqoMemZKGJpaeADmXYXWDOOVAbPfsjNuXJoRTAjTDFEmcxbzrOdprTJlJJxPZLjWYmqDWpquwSnHvnFLfkvzEmmtVTbYjvjSDSMWGpNioezIkcQmtHLMiXImkeSWwIUjrBDKCiawtGiSLIHtBmTWntFmUtrL");
    int QqyTPR = 1001343773;
    bool xuded = false;

    for (int YYqZYeogY = 412526612; YYqZYeogY > 0; YYqZYeogY--) {
        uEeVJrB *= uEeVJrB;
        xuded = ! ChSCSWccUQmWY;
    }

    for (int GEBjiu = 605411919; GEBjiu > 0; GEBjiu--) {
        ChSCSWccUQmWY = gwWrfsiJuTrr;
        ChSCSWccUQmWY = ! xuded;
        MIToKxENoZg /= XwdAviGjJut;
        xuded = bFJUYEahaqBDUV;
        QqyTPR /= QqyTPR;
    }

    for (int jYKse = 463762083; jYKse > 0; jYKse--) {
        continue;
    }

    for (int ZoJpniJBdErjQK = 2105750023; ZoJpniJBdErjQK > 0; ZoJpniJBdErjQK--) {
        XwdAviGjJut = XwdAviGjJut;
        gwWrfsiJuTrr = ! xuded;
    }

    for (int fHEnaxF = 346094839; fHEnaxF > 0; fHEnaxF--) {
        continue;
    }

    for (int uEbsZYAyloAJjE = 948742979; uEbsZYAyloAJjE > 0; uEbsZYAyloAJjE--) {
        continue;
    }

    for (int CuLAmMDaNKmnRK = 1805220578; CuLAmMDaNKmnRK > 0; CuLAmMDaNKmnRK--) {
        gwWrfsiJuTrr = ! bFJUYEahaqBDUV;
        MIToKxENoZg *= MIToKxENoZg;
    }

    return XwdAviGjJut;
}

bool OjrEALbmcMf::UKzxuyAzpJn()
{
    bool XyiiEUqfVJ = true;
    int apXjVSgnrMgnxV = -1175951232;
    string cFRDRSWWDSDW = string("hwAhxHBEemwmQt");
    double qHRbJvpijdi = -263403.78242256044;
    double oUibPxKL = 519949.58062364603;

    if (cFRDRSWWDSDW < string("hwAhxHBEemwmQt")) {
        for (int FdtcdMzRkALJ = 34191660; FdtcdMzRkALJ > 0; FdtcdMzRkALJ--) {
            continue;
        }
    }

    for (int zEhush = 1270099746; zEhush > 0; zEhush--) {
        oUibPxKL += oUibPxKL;
        XyiiEUqfVJ = ! XyiiEUqfVJ;
    }

    for (int tjTNhCOSpvl = 402847553; tjTNhCOSpvl > 0; tjTNhCOSpvl--) {
        qHRbJvpijdi *= qHRbJvpijdi;
        oUibPxKL *= oUibPxKL;
    }

    for (int QcgPqzWNXg = 1802700830; QcgPqzWNXg > 0; QcgPqzWNXg--) {
        qHRbJvpijdi -= qHRbJvpijdi;
        XyiiEUqfVJ = XyiiEUqfVJ;
        cFRDRSWWDSDW += cFRDRSWWDSDW;
        qHRbJvpijdi *= qHRbJvpijdi;
        oUibPxKL /= qHRbJvpijdi;
    }

    return XyiiEUqfVJ;
}

string OjrEALbmcMf::HcFTGFgsveiAGKPN(int vIOUYZkzveVo, bool cCgCAHwJ)
{
    bool pvypVgCrhfZ = true;
    string REmthtmyotYQvjyw = string("SqXYsVbiIivYUzEkGqrTStNqtVEBwrjynYepgoMXbBFWOHsfRJEUOdiYZPKxPFjbEIbojRkAzWyivytnVBdGgedoyplGThtZyaYsbZDTxCgyPXtdffMTlrEaQrlbemHDvJTwzHDyBXeFotwwLcpJBDIMlWvdLDUpgOeicdtIPNcYBMjWTBhNNTHLBwDHGwnbsjsUuepBJYzphmciQvsvncUGVApErSwOdzSvzzkFcbbSX");
    double sobnrFcPjTuAfM = -715405.2485872918;
    int lKCplJfxToUTji = 1835167732;
    bool HBJpwGJnSUOLu = false;

    if (pvypVgCrhfZ == false) {
        for (int xBGpftoEOIhBCKA = 570492759; xBGpftoEOIhBCKA > 0; xBGpftoEOIhBCKA--) {
            pvypVgCrhfZ = cCgCAHwJ;
            HBJpwGJnSUOLu = ! pvypVgCrhfZ;
        }
    }

    return REmthtmyotYQvjyw;
}

string OjrEALbmcMf::dzDdMDrunHJi(double trbZiAGRMsAlZ)
{
    int VRscXimr = 1767045552;
    int bUmZoTJw = -1904196799;

    if (bUmZoTJw >= 1767045552) {
        for (int DyAKysGtvr = 360310711; DyAKysGtvr > 0; DyAKysGtvr--) {
            bUmZoTJw *= VRscXimr;
            trbZiAGRMsAlZ = trbZiAGRMsAlZ;
        }
    }

    return string("diQLzCmBTKqnJJwzXrdvJWdOjSCBcLfDJkHJAXFDUzppTgSmqqQONRjmzpJyqyZVKYMxZBwjjvVhCHCUpjTtukbymgqxOfmrBmPvTjh");
}

bool OjrEALbmcMf::fXltIGWZPRlXg(double RbrPGwbYjO, string qNlRKhBxbFBw)
{
    double YVQkMzl = 192624.4904677214;
    double ZfDnqJYLNKxyUO = -590219.7454243525;
    bool xzEXyKmZr = false;
    double Fkougushic = 204600.51991211614;
    int kQOwDkBsFJIhPG = 553575107;
    int dxOmIvryVCKHMu = 819418183;
    string XQTMNZRlGs = string("NsAALrHd");
    string LiutMSKpNwuMRTG = string("HCpBULTmhgEOHLdlaYJJACVaInDMwYvwuR");

    if (LiutMSKpNwuMRTG <= string("libRSBNYIoYKoquARaWxzBtJzPAWMtApNfrqmjWiWXoFydqZTgXIMjYTwTsFwoYPaJFTbDrafqfIlopSWyaLxapdDbpOQXcOAVVdejCmWOntnzIcjHWqotRjNXllbcayZFckFIfsnKUpqhSlcKHZkLsvbzwGJOQCqrPfPLGmTeuvMnbOpezMQZhHwrsOxuyVRudOsgPzWxUrebupBxsFv")) {
        for (int cNgmHCtAwouGGa = 640372732; cNgmHCtAwouGGa > 0; cNgmHCtAwouGGa--) {
            ZfDnqJYLNKxyUO /= Fkougushic;
            dxOmIvryVCKHMu -= dxOmIvryVCKHMu;
        }
    }

    for (int hMNZDKCiQNJu = 417191475; hMNZDKCiQNJu > 0; hMNZDKCiQNJu--) {
        continue;
    }

    return xzEXyKmZr;
}

bool OjrEALbmcMf::NrSnioFIzKbHu(bool vUhkiT, string gvMHPxORN, int GvzSV, int wFVsN, double WArrmqhZzhSeDUe)
{
    double sXAPw = -203956.49861210477;
    string TWdAS = string("wrgDAiQqFLbTRLKgtqQuecCQwnuKmjnmoRCyddsEJUGBCkTZgXXPefeTRLmUZqXlceLJeFFHiHntRGqmrtaPbhDHwZgFDNUzrSpkiETDeQUQoPXrcBIDidyvvalwDLJfhRHawJWwQAkKxvctxYQaSEdWyXpxqvCaDJEYAnfpzFzdRZHJrerVutifVrlFCAaLDGmBcgQqQTLVVkARpWziljXSMZ");
    int PVMyoMENq = 566649233;
    double gVzNEufrKRDVYK = 989379.9307434729;
    bool XqcdUM = false;
    string cZLNYKrr = string("PtVIhpMRCfGkFaSOFuvcgfdUbfZuGtSECZMdAQbPSIrTbHdkumRujoYnYumfsBQizFZBWpJsMDcqwCDX");
    double VfOwnmzfmAfdc = -196720.86324410522;

    for (int FFNPmqYgSLtvJd = 1838420848; FFNPmqYgSLtvJd > 0; FFNPmqYgSLtvJd--) {
        WArrmqhZzhSeDUe *= VfOwnmzfmAfdc;
        TWdAS = cZLNYKrr;
    }

    for (int isBNnfQ = 1444524321; isBNnfQ > 0; isBNnfQ--) {
        continue;
    }

    for (int PZYCIjjjUY = 1891753582; PZYCIjjjUY > 0; PZYCIjjjUY--) {
        continue;
    }

    for (int LIQTZEcZxxTzAE = 1423283591; LIQTZEcZxxTzAE > 0; LIQTZEcZxxTzAE--) {
        gVzNEufrKRDVYK = VfOwnmzfmAfdc;
        XqcdUM = XqcdUM;
        VfOwnmzfmAfdc /= VfOwnmzfmAfdc;
        cZLNYKrr += TWdAS;
    }

    return XqcdUM;
}

int OjrEALbmcMf::nXkiJEtP(int oKzwflfiq, double dkvMGRzrwbaDT)
{
    double cKGlLAyFnCbir = -393446.0772645974;
    string wWeeLyZURgelzVj = string("sfpLrDNGwYMiEJaiUhCIHLgyMJzxOQgEUBFZPlcXRnEMXwzMYrJgICHbUiHlCCuUjsFRixLMpIOpRiBAQOXjCHlKBIWELhFqLVvgVTPzgCsRCbUgDefaeAIxtebyJLbkEwfLBqNXmqYqcqCanhUlBpbDOVXNFJukVOvJrAlPWkaQAiUewadiqoYUYaiGlkWyJIdEdCUqkgwYZYvYhnQmTcSWYxCpPPCLteAMVcEBHKPiFWctHSYzrUrZYQupy");
    bool HiyFYcwpiYHFTsW = false;
    double dgnHa = -366463.1675797172;

    for (int MBVlQ = 483512458; MBVlQ > 0; MBVlQ--) {
        wWeeLyZURgelzVj += wWeeLyZURgelzVj;
        cKGlLAyFnCbir *= dgnHa;
        dkvMGRzrwbaDT /= dgnHa;
    }

    return oKzwflfiq;
}

void OjrEALbmcMf::lsipLFJIjKMik(bool VDeRpmsZEgZnr, bool zFnfDVfhv, double PHaYqWloCW, double VeQitKEQgCU, double aJmoi)
{
    int iMIixGeiVC = 437576688;
    string TjFcvSsBZVKbxo = string("SSmlDhYpOEoUzPkjyfdJbSEweYZeHbvXOoXmyeKBgdDZoWaUdmhjCzLNOgppkMjbfpCSSioyOIv");
    string OkUUFhJPn = string("EEXGWgbgAwpDzwTuPAUTwJWvpQRwhoPpDWaSwhELqBdAqRWErVveqNVSKHf");
    int LOXaJnAyYbF = 443656629;
    bool pdZOUbJZOxwqq = false;
    double wWIDeAIiHs = 900587.6066154627;

    for (int FTvrbpa = 1821369995; FTvrbpa > 0; FTvrbpa--) {
        wWIDeAIiHs += aJmoi;
        VDeRpmsZEgZnr = ! pdZOUbJZOxwqq;
        PHaYqWloCW += VeQitKEQgCU;
        wWIDeAIiHs *= PHaYqWloCW;
    }

    if (wWIDeAIiHs > 999130.8391101073) {
        for (int XAlgH = 38647494; XAlgH > 0; XAlgH--) {
            pdZOUbJZOxwqq = ! VDeRpmsZEgZnr;
            aJmoi = PHaYqWloCW;
            VeQitKEQgCU = wWIDeAIiHs;
        }
    }

    for (int sRegJ = 1158635272; sRegJ > 0; sRegJ--) {
        PHaYqWloCW -= aJmoi;
        PHaYqWloCW = PHaYqWloCW;
        VeQitKEQgCU -= VeQitKEQgCU;
    }

    for (int SniEnIMLqnXrmJGG = 435445732; SniEnIMLqnXrmJGG > 0; SniEnIMLqnXrmJGG--) {
        continue;
    }

    for (int IwsOAemXYQnjsT = 457133018; IwsOAemXYQnjsT > 0; IwsOAemXYQnjsT--) {
        OkUUFhJPn = TjFcvSsBZVKbxo;
    }
}

double OjrEALbmcMf::qIwSYvTslZjXyxd(int pEMLJihQUplU, bool VkZheMExtDuPSr, int kMCQjrvCdTPqNVz, double tECJIiel, int YzdWFESkMMWEbX)
{
    int KLXXzYYGNPlSPln = -640663481;
    int RTxFtMWlkqCwYbNL = -1012609897;
    double fwwQNsNLGmb = 41566.25108087127;

    for (int PgNGXcQTBslIvDfA = 1647821096; PgNGXcQTBslIvDfA > 0; PgNGXcQTBslIvDfA--) {
        RTxFtMWlkqCwYbNL = pEMLJihQUplU;
        pEMLJihQUplU *= KLXXzYYGNPlSPln;
        YzdWFESkMMWEbX /= KLXXzYYGNPlSPln;
        KLXXzYYGNPlSPln *= KLXXzYYGNPlSPln;
    }

    return fwwQNsNLGmb;
}

int OjrEALbmcMf::xLdKLXIB()
{
    int WiCDkuq = 1578304937;

    if (WiCDkuq != 1578304937) {
        for (int OALPmdbn = 812626136; OALPmdbn > 0; OALPmdbn--) {
            WiCDkuq += WiCDkuq;
            WiCDkuq /= WiCDkuq;
        }
    }

    if (WiCDkuq < 1578304937) {
        for (int XOTgaCFXTqOurh = 178764290; XOTgaCFXTqOurh > 0; XOTgaCFXTqOurh--) {
            WiCDkuq += WiCDkuq;
            WiCDkuq = WiCDkuq;
            WiCDkuq -= WiCDkuq;
            WiCDkuq *= WiCDkuq;
            WiCDkuq /= WiCDkuq;
            WiCDkuq = WiCDkuq;
            WiCDkuq = WiCDkuq;
            WiCDkuq = WiCDkuq;
            WiCDkuq /= WiCDkuq;
        }
    }

    return WiCDkuq;
}

OjrEALbmcMf::OjrEALbmcMf()
{
    this->sRpgzkshSsJe(-1015352.7692192487, string("vQmOzXxqdUzqYOqUbCgIDHbVqQDmggZaFkBkNCtpjyEHftvMsFUPbrBB"), -20701.68515487758);
    this->UKzxuyAzpJn();
    this->HcFTGFgsveiAGKPN(360762193, true);
    this->dzDdMDrunHJi(-107931.26096173683);
    this->fXltIGWZPRlXg(903968.2866514063, string("libRSBNYIoYKoquARaWxzBtJzPAWMtApNfrqmjWiWXoFydqZTgXIMjYTwTsFwoYPaJFTbDrafqfIlopSWyaLxapdDbpOQXcOAVVdejCmWOntnzIcjHWqotRjNXllbcayZFckFIfsnKUpqhSlcKHZkLsvbzwGJOQCqrPfPLGmTeuvMnbOpezMQZhHwrsOxuyVRudOsgPzWxUrebupBxsFv"));
    this->NrSnioFIzKbHu(true, string("hPkoeQOyDOTs"), 1874756944, -1283548931, 111578.33651675272);
    this->nXkiJEtP(529858694, 538071.0793485234);
    this->lsipLFJIjKMik(false, true, -159647.9088774397, 999130.8391101073, 78889.548407946);
    this->qIwSYvTslZjXyxd(529722148, true, -1138651761, -346570.52840668143, 949092030);
    this->xLdKLXIB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Yywxy
{
public:
    double YeNDL;

    Yywxy();
    void LJZWylKbRzXpQxa(double QTFQPXH);
    void GbYeYgBtLVnbfieh(int VrSRtYfBUtDv, double XluOcQOJexJImGHV, double WmGIahAhdIs);
    string zNDKzRW(bool eeoRkU, int eacsXYd, string DQxeNywjDV, bool DtIERTbEvLBKB);
    double ZsvEO(bool sXviurWctok, string MHFaf, int cVLLBeLJSWrEkhxP, bool NRWuUQvPgZTHk, double odNfkumsVgWdii);
    double QokAl(bool vnFriLDrpuLKlrY, double fCyjEnZsAg, string JrlHdaXHoXqjN, int IKpBFX);
protected:
    double ikPCJ;

    int fgLNgLZHZTJl(string sKVhNeOPdMcz, int YQLNfQwYsm, double qAXHxzP, int xSZqrW, double niesUxtsohzzry);
private:
    bool LifzNLSGcBOJxDCh;
    string aDgRBPqnDRK;
    int RbMYlSAFQKpcbcJd;
    bool uYEEMiAyeZ;

};

void Yywxy::LJZWylKbRzXpQxa(double QTFQPXH)
{
    string XZvghB = string("aoLyyozfcHviAJMmjHigqUfHpUAfBNKUqMZylIRbXODYhQYOhWSHRbxbyFeFqnXzVSxqRaqQpTtOeZwecJzvjvYdevaWJtwolyIbRnmpeAnViaSHwrgvCRwUCdSWJjHZvYyMiEpfaICrTaJwgzSoDTgTEBJBumDfvmThrVMyLFqBDJmHmzDqAyqamuKboagMnHeyDiHBGxorX");
    string ddftYyGhi = string("lNbmtikgtSvKUbRUHjNrCcOmrExfTWcunTGhHCASXUdLDpdPZEjEliMowSrWRIycwbERrrKDSJHbEtXnRYcxLmVCaloZdCNlpwTZHbfImHzIKsQzkrhuNLLScTHlLHiJNUvHKfgecsyJaPthZiFWeOPiADKmlHQlVGkoXRLBNcmRSnkYupiBXwhmpYzqHZCEnhnjZmXhtxbqOi");
    int pOdoENMWGpAJkFq = 1492982771;

    for (int hWkZyIKjO = 744965286; hWkZyIKjO > 0; hWkZyIKjO--) {
        pOdoENMWGpAJkFq = pOdoENMWGpAJkFq;
        XZvghB += XZvghB;
        XZvghB = ddftYyGhi;
    }

    for (int ghOBcor = 167482274; ghOBcor > 0; ghOBcor--) {
        XZvghB += XZvghB;
        XZvghB += ddftYyGhi;
    }

    if (XZvghB <= string("lNbmtikgtSvKUbRUHjNrCcOmrExfTWcunTGhHCASXUdLDpdPZEjEliMowSrWRIycwbERrrKDSJHbEtXnRYcxLmVCaloZdCNlpwTZHbfImHzIKsQzkrhuNLLScTHlLHiJNUvHKfgecsyJaPthZiFWeOPiADKmlHQlVGkoXRLBNcmRSnkYupiBXwhmpYzqHZCEnhnjZmXhtxbqOi")) {
        for (int vXqKmjBxMxDmy = 656604204; vXqKmjBxMxDmy > 0; vXqKmjBxMxDmy--) {
            ddftYyGhi = ddftYyGhi;
            pOdoENMWGpAJkFq /= pOdoENMWGpAJkFq;
        }
    }

    if (XZvghB != string("lNbmtikgtSvKUbRUHjNrCcOmrExfTWcunTGhHCASXUdLDpdPZEjEliMowSrWRIycwbERrrKDSJHbEtXnRYcxLmVCaloZdCNlpwTZHbfImHzIKsQzkrhuNLLScTHlLHiJNUvHKfgecsyJaPthZiFWeOPiADKmlHQlVGkoXRLBNcmRSnkYupiBXwhmpYzqHZCEnhnjZmXhtxbqOi")) {
        for (int yHSzypGiFAlORuje = 475091068; yHSzypGiFAlORuje > 0; yHSzypGiFAlORuje--) {
            ddftYyGhi = ddftYyGhi;
            QTFQPXH *= QTFQPXH;
            QTFQPXH /= QTFQPXH;
        }
    }

    if (XZvghB < string("aoLyyozfcHviAJMmjHigqUfHpUAfBNKUqMZylIRbXODYhQYOhWSHRbxbyFeFqnXzVSxqRaqQpTtOeZwecJzvjvYdevaWJtwolyIbRnmpeAnViaSHwrgvCRwUCdSWJjHZvYyMiEpfaICrTaJwgzSoDTgTEBJBumDfvmThrVMyLFqBDJmHmzDqAyqamuKboagMnHeyDiHBGxorX")) {
        for (int VpoXHxfupSybMOe = 1539077615; VpoXHxfupSybMOe > 0; VpoXHxfupSybMOe--) {
            XZvghB += ddftYyGhi;
            pOdoENMWGpAJkFq += pOdoENMWGpAJkFq;
            ddftYyGhi += XZvghB;
        }
    }
}

void Yywxy::GbYeYgBtLVnbfieh(int VrSRtYfBUtDv, double XluOcQOJexJImGHV, double WmGIahAhdIs)
{
    bool cRiCg = true;
    bool mNRbensBlmRVhagp = false;

    if (WmGIahAhdIs >= 629020.3384418437) {
        for (int iymQqwNfaxitV = 711528554; iymQqwNfaxitV > 0; iymQqwNfaxitV--) {
            VrSRtYfBUtDv /= VrSRtYfBUtDv;
            mNRbensBlmRVhagp = ! cRiCg;
            mNRbensBlmRVhagp = cRiCg;
            WmGIahAhdIs *= XluOcQOJexJImGHV;
        }
    }
}

string Yywxy::zNDKzRW(bool eeoRkU, int eacsXYd, string DQxeNywjDV, bool DtIERTbEvLBKB)
{
    int lcBFKtwDSZyXXA = -1487148790;
    int ErZeu = -927850348;
    bool KHHlEHipeTPRDy = false;
    int cTPjsZaqsJL = -101636409;

    for (int DYuDRDdnWrEw = 310295254; DYuDRDdnWrEw > 0; DYuDRDdnWrEw--) {
        ErZeu += lcBFKtwDSZyXXA;
        DQxeNywjDV += DQxeNywjDV;
    }

    if (cTPjsZaqsJL <= -1336746986) {
        for (int xxrwmsVWRgCB = 937711913; xxrwmsVWRgCB > 0; xxrwmsVWRgCB--) {
            eacsXYd -= ErZeu;
            cTPjsZaqsJL = ErZeu;
        }
    }

    return DQxeNywjDV;
}

double Yywxy::ZsvEO(bool sXviurWctok, string MHFaf, int cVLLBeLJSWrEkhxP, bool NRWuUQvPgZTHk, double odNfkumsVgWdii)
{
    double mEkutrqnubBjSr = 1046735.0948866529;

    for (int CFcZtzvxnof = 1456981120; CFcZtzvxnof > 0; CFcZtzvxnof--) {
        MHFaf = MHFaf;
        NRWuUQvPgZTHk = ! sXviurWctok;
    }

    if (MHFaf > string("fxPTyXtsnnmniQfaMLmpZdrBaPutBDhVqFFKIiRfOvzjoungTXvmwjjEJRBQBMQskbewYERxlTFVXkfnHiAjHCgwkCnRplyrhVSzwBqVlVHLGzvUeknGASNAnLFifPjuNrYBapLjWGilALNpnxfkcCdsBXlvmQFDeJiAELzfGbwkfTWvFagHxNoHoVSmXSkUoqBuxBVbkPBnqAubfEEuEjtidfMfCVtXcleoLQ")) {
        for (int ohqqFuTSU = 63548350; ohqqFuTSU > 0; ohqqFuTSU--) {
            NRWuUQvPgZTHk = ! sXviurWctok;
        }
    }

    return mEkutrqnubBjSr;
}

double Yywxy::QokAl(bool vnFriLDrpuLKlrY, double fCyjEnZsAg, string JrlHdaXHoXqjN, int IKpBFX)
{
    bool iXYbSYimKZFPuG = false;

    return fCyjEnZsAg;
}

int Yywxy::fgLNgLZHZTJl(string sKVhNeOPdMcz, int YQLNfQwYsm, double qAXHxzP, int xSZqrW, double niesUxtsohzzry)
{
    string sNtfifJNndDFVLmr = string("ouFTrZbVvnSGUgHIeTUtWnqZUxRHCSOTeDOfIRikKMKiXsECeJmJhMvHwOQYRIzFbdBCjhbxdcRwIMRzXhbTWiTdzTsJGsLtJKIdfmenEAhtCxTuxNheSlcwKITMyIeZdgQQxquNPpBjmlPkEAymVaKqcUrICxjDxwytVI");
    double ySyGRgOyA = 380430.33116278937;

    for (int yKxSdHXJU = 777116622; yKxSdHXJU > 0; yKxSdHXJU--) {
        niesUxtsohzzry /= niesUxtsohzzry;
        qAXHxzP *= qAXHxzP;
    }

    for (int qTvQslEOEzUhS = 1381065096; qTvQslEOEzUhS > 0; qTvQslEOEzUhS--) {
        ySyGRgOyA = niesUxtsohzzry;
    }

    for (int PjPVQnze = 1029393264; PjPVQnze > 0; PjPVQnze--) {
        sNtfifJNndDFVLmr = sNtfifJNndDFVLmr;
        ySyGRgOyA -= ySyGRgOyA;
        sKVhNeOPdMcz += sNtfifJNndDFVLmr;
    }

    if (xSZqrW == 1086636684) {
        for (int duvPDMN = 1018377887; duvPDMN > 0; duvPDMN--) {
            ySyGRgOyA += niesUxtsohzzry;
            xSZqrW = xSZqrW;
            xSZqrW += xSZqrW;
            ySyGRgOyA -= niesUxtsohzzry;
        }
    }

    return xSZqrW;
}

Yywxy::Yywxy()
{
    this->LJZWylKbRzXpQxa(401030.6205070825);
    this->GbYeYgBtLVnbfieh(-13037880, 696217.9586122988, 629020.3384418437);
    this->zNDKzRW(false, -1336746986, string("KbassOReZRhxAOHXsgUmQPsLacrQt"), false);
    this->ZsvEO(false, string("fxPTyXtsnnmniQfaMLmpZdrBaPutBDhVqFFKIiRfOvzjoungTXvmwjjEJRBQBMQskbewYERxlTFVXkfnHiAjHCgwkCnRplyrhVSzwBqVlVHLGzvUeknGASNAnLFifPjuNrYBapLjWGilALNpnxfkcCdsBXlvmQFDeJiAELzfGbwkfTWvFagHxNoHoVSmXSkUoqBuxBVbkPBnqAubfEEuEjtidfMfCVtXcleoLQ"), 485259906, true, 32918.01201103004);
    this->QokAl(false, 335383.00392438716, string("VBgQFekqXumMohzMyrhoiKXKnXhZXOKlaUjMgMrMBgzxEYUreWpNJzJbyGbMuxTvBHKDiHwiJJlsemfwjaLtpxrcmtFDrCRYHmTBMDNGovWizMgTKNLhVYGbPfUemEwXtdLcqjNeZRIqYKbPjMSxdqrGbiRywEYdxRkiGtYPTDkyWArgigtDUZMfppkmNfEoxiWKVPNFkqDIpTiSQCUjcpsrlWUbmqiOBdErOCmsWRBgVRkeMeDJTqVnlXSy"), -1782717009);
    this->fgLNgLZHZTJl(string("YxabzBfMVtEHihcZCQokYujwEtNrWeSzifWnWOYqjrkPdPoyaupPeIZLUZQqYeQTCbBik"), 1086636684, 561789.3445975061, -1704518980, -900178.6372561381);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sMOhVKcvh
{
public:
    double ixsRQH;
    bool aKzlrekquF;
    bool wNvhiEuYxga;
    double UOdUQXgTbHVPsWU;

    sMOhVKcvh();
    string tpieRVXMMdJPQ();
protected:
    double QsDGuTd;
    bool AuxrOJ;
    string lMNwSbdILsijFNVR;
    bool ZmfsFztOPb;
    bool TuaHPeYQwa;
    double GMcmhc;

    bool VjcsDkbhfYEo();
    void UJoqXURoidi(bool DTcpYfS, double OkWZaPKpnba);
    int yDiXOflbbdR(string aOAxduQL, string vJGLaGUbwjbn, double ArHNnvMcdaDalRAh);
    int eRAZmn(string XLbIlU, string EXeMMPULd);
    void pnrbZLQBQwR();
    int RnJHMPSloHKonHb(string hPjHqZvIPFFfIWw);
    string MRyykt(bool xzVNXoUfYD, int HkmaovvXyDRh);
private:
    bool vmLUPnCEycAJ;

    double rznqewwfEfRxH(bool WTNztuWI, bool sGgBR, int hvezYugOldsAZ);
    bool XVPpizyxNfyrts(string DRxbxGcfZxlNwYCp, int yESSH);
    int LWRShLe(int lLTIhVfcsZD, bool lNByh);
};

string sMOhVKcvh::tpieRVXMMdJPQ()
{
    int SbFcCYnBjri = -237333150;
    string FAFzwttlnVUFy = string("zQuMcsXYISUUfJpxbBrDQSPaCyQxBLhsZSQuOdGKTCKYlPHMjflssVyfYhcpqauTWeLjdVncLMvCfkiCuFtfGQeejFENEWXjnPaNVecVsuQhQKXnqVnedyRptEsmgbGoeTKroprtgjxFShzpiNgWOAyTUCzurUsJLCvUHaNWJZceuYAkmPCtEqpOvMGrgrPwywZIKLqgSajzUXbPfoyNglDdFnYDhOJMtMpdJfWl");
    string UMetzFGSo = string("lVKqBWmVZmwtXvjIsPLavIgKZZSebKzhLgwfBUHNrVJGyIGyCpuNnhqsMxXtdQvXzmyhqbthYrjMFcAdugCuQOdsyQjrrmEBoaZDIgaxOOOTrfWgUjLxdNGtJYIoYIOBD");
    double wsOPjPhNxFHEHW = 29806.609946945093;

    if (FAFzwttlnVUFy != string("lVKqBWmVZmwtXvjIsPLavIgKZZSebKzhLgwfBUHNrVJGyIGyCpuNnhqsMxXtdQvXzmyhqbthYrjMFcAdugCuQOdsyQjrrmEBoaZDIgaxOOOTrfWgUjLxdNGtJYIoYIOBD")) {
        for (int snaLNynjx = 1186921157; snaLNynjx > 0; snaLNynjx--) {
            continue;
        }
    }

    if (FAFzwttlnVUFy < string("zQuMcsXYISUUfJpxbBrDQSPaCyQxBLhsZSQuOdGKTCKYlPHMjflssVyfYhcpqauTWeLjdVncLMvCfkiCuFtfGQeejFENEWXjnPaNVecVsuQhQKXnqVnedyRptEsmgbGoeTKroprtgjxFShzpiNgWOAyTUCzurUsJLCvUHaNWJZceuYAkmPCtEqpOvMGrgrPwywZIKLqgSajzUXbPfoyNglDdFnYDhOJMtMpdJfWl")) {
        for (int NgyoOXF = 1238318679; NgyoOXF > 0; NgyoOXF--) {
            FAFzwttlnVUFy += FAFzwttlnVUFy;
            wsOPjPhNxFHEHW /= wsOPjPhNxFHEHW;
        }
    }

    return UMetzFGSo;
}

bool sMOhVKcvh::VjcsDkbhfYEo()
{
    double DuwwABkIn = -1024970.2676234224;
    double kdVSOIscbYzPyE = -92055.57843264674;
    string CgYMQsiE = string("CKxoOTGrHiSqhrtSTTLhXiNknENfSoToLmTrNVnh");
    string TjbdrtcxGFtwrZ = string("HMGfLabmnaomBbqauEPMfDnxYdczNDmaPxnPVlgXysbbgZQAXrvvfJeplkTypznUYGoKbUtDdIyxSmDiccXzKvEefgt");
    string KKgSiFbrdrcN = string("DxpjCeIDiTcBfOuEYRqOJwXHXbZEWAxlTNHDpJpmDGKPUasDZbJxZjOwfcBCnfrArUZBqdaSkEdAjFtLjfYtmkpBkQzIpQItjGMvRsPxyqwLpTdiIVDYcvOwYJXkKppVAuFljvTfaRgpoUxMDpQchNWhakZbmvwPfWErFuZzGwvvdzdNMpxjAHWeUDSrUBURRTIACLsuqDyLyWNuMuumrfKDPnCLAFGzOE");
    string fqFLNiEpW = string("XXuZdvowlaZJIewqxrEERlMfhLfTRCdqVPTSxafqMxIlBUucoJRjbMrgomzKMsqnbZWVKFQ");
    bool syckKbFCqjJ = true;
    int FlrsmNBHbpaLp = -1263861678;
    double gukFeFoUTZzj = -432818.8602491628;

    for (int aegmF = 971333049; aegmF > 0; aegmF--) {
        DuwwABkIn *= kdVSOIscbYzPyE;
    }

    for (int FuGmDbo = 2077220362; FuGmDbo > 0; FuGmDbo--) {
        DuwwABkIn -= gukFeFoUTZzj;
    }

    for (int ApxyKIHj = 992942626; ApxyKIHj > 0; ApxyKIHj--) {
        DuwwABkIn = kdVSOIscbYzPyE;
        fqFLNiEpW = TjbdrtcxGFtwrZ;
    }

    return syckKbFCqjJ;
}

void sMOhVKcvh::UJoqXURoidi(bool DTcpYfS, double OkWZaPKpnba)
{
    string xwCaFq = string("nsJgJUESocWPjTsodaqgSDPgNGEAUVaePlIWnObmzGoqXupbRPwtdaYDtHvBXZoOpzfbHQMqqALIaoFXSWHZePdTXFKRcRzFpGHimIhenoSnHnVLBQywytBnEfhqkdafSnRKgAejfBJddCktOQinMkFQZzzxeCOraIvIhasKTsSjWmPgLYISutwSepwPspfPWWtvaQFBspXTSHePHCAKvDIgZWZw");
    string mAmiMayWc = string("kjkeZfQGThmaVaZeeqrSjEAGhPsxqKqJXytBTDezslXoAXQrOoEGijvIpsgimbUvHxFqYdaBGXplAXTrfszABYWPuhioOOQVIfAJOwAWKGmdmIArlHBjdKzIAxKRPOmdc");

    for (int Rxjzu = 1061757130; Rxjzu > 0; Rxjzu--) {
        OkWZaPKpnba = OkWZaPKpnba;
        mAmiMayWc += xwCaFq;
        xwCaFq += mAmiMayWc;
    }

    for (int SgKeCpCSAnVST = 1466079652; SgKeCpCSAnVST > 0; SgKeCpCSAnVST--) {
        mAmiMayWc += xwCaFq;
    }

    for (int OeJAITXbn = 312535847; OeJAITXbn > 0; OeJAITXbn--) {
        continue;
    }
}

int sMOhVKcvh::yDiXOflbbdR(string aOAxduQL, string vJGLaGUbwjbn, double ArHNnvMcdaDalRAh)
{
    bool tAmbTKYrmLOKyqO = true;
    int KBprUxlU = -1423706367;
    double nyPadGFny = -821503.1817369909;
    string TSEiGbV = string("nokRRKfeEhOAzNWtXvlyIQDwIpGdhQubMIWijLGZtpjHNOXBauQhCcRskJlkSQWuDXQCmKmm");
    bool VXuvSOKKx = false;
    string DqlzcCK = string("gWurorpbWlzjoPITeDpKfRmoeIhJOgULUazRbSzlW");
    string ipWkv = string("UEBPrHFXGmiRKZcfZmiHMgrJzPKfWvRrBEvQpFYxLmdgEVYqhlCnLdvaKsROCgYyfBwfeofrIRGaXnpYOpOMnrYItupJDrcCKzfqzxozYpSrynYPXUvxkRZrZHykFjZUIhVDBSRJuIuMMgvLbjkSZbWhAxWDpoZUwIByUQGQCadkVGZQEhjdIrEKoykpjZTMKdwouNZpaZtnQZRFViqYrmEWsuLBJqpHduiGMLpjQHXRbPbwOZsDCW");
    bool tobxlko = false;

    for (int WKbXHTlS = 994859764; WKbXHTlS > 0; WKbXHTlS--) {
        TSEiGbV = vJGLaGUbwjbn;
        tAmbTKYrmLOKyqO = ! tAmbTKYrmLOKyqO;
    }

    return KBprUxlU;
}

int sMOhVKcvh::eRAZmn(string XLbIlU, string EXeMMPULd)
{
    int jhJPS = -1309531163;
    string SjgKCXX = string("KixdElQEfssRLCEoVfiXwlWpOGpSBeXJwcdlrJmyJdUOJpjrgRogzlHcRXMtVVCCVVbahGcEbUvAhbGNHpXayuuFGKxRcpsgHcFTcwOTTnJjzwCmeNvgwxVhHcaEobPNoRdhvDrdCdYSUwjhO");

    for (int gIjFEiVVyXgYGbD = 72935348; gIjFEiVVyXgYGbD > 0; gIjFEiVVyXgYGbD--) {
        SjgKCXX = EXeMMPULd;
        XLbIlU = EXeMMPULd;
    }

    if (EXeMMPULd != string("KixdElQEfssRLCEoVfiXwlWpOGpSBeXJwcdlrJmyJdUOJpjrgRogzlHcRXMtVVCCVVbahGcEbUvAhbGNHpXayuuFGKxRcpsgHcFTcwOTTnJjzwCmeNvgwxVhHcaEobPNoRdhvDrdCdYSUwjhO")) {
        for (int MDiuttQYeimqpD = 109009575; MDiuttQYeimqpD > 0; MDiuttQYeimqpD--) {
            jhJPS /= jhJPS;
            SjgKCXX += XLbIlU;
            SjgKCXX = EXeMMPULd;
            EXeMMPULd += SjgKCXX;
            XLbIlU += SjgKCXX;
            XLbIlU = XLbIlU;
        }
    }

    return jhJPS;
}

void sMOhVKcvh::pnrbZLQBQwR()
{
    int QMsDISCZbKLG = 1345987910;
    string eHvkhFE = string("eLOaOhAKXQMpacGVcmwRBVSaWCmDYTGFTkAQlVBdvGryCroIhitlEFnyIIfTVQwRvJuFYOwDzbcOZanjGxjuZenUBVcxHSzInWYQhevGqYjEykdPOFjLzDhCxOavyNfFSyoYTMfztcdxmJiJjfXfhkqeMGxbohRAgQjMpmsUhYvxKetZtxfeZHiVYsYVPzcwfnVCodDmHxhBwFyCBgYTRAA");

    for (int bbOTsOrygHn = 1818290530; bbOTsOrygHn > 0; bbOTsOrygHn--) {
        eHvkhFE = eHvkhFE;
        eHvkhFE += eHvkhFE;
        QMsDISCZbKLG = QMsDISCZbKLG;
        eHvkhFE = eHvkhFE;
        QMsDISCZbKLG -= QMsDISCZbKLG;
    }
}

int sMOhVKcvh::RnJHMPSloHKonHb(string hPjHqZvIPFFfIWw)
{
    bool rEQXgTwm = true;
    bool AaIcHBYscLsNIXS = false;
    int JLuAmwjyONx = 964855343;
    double TFModMbw = -715824.4522228788;
    bool WGUjleqsT = true;
    int LpEDXAueBefXmqt = 1184345684;
    string txrdj = string("FxMZvHETjxlvekMggFEhlxZxcPJZJEYWVuCZdLguXFClKEQLqCMcDjZpKxhriracVMeVWlGbtXxemKSkBQhnPHkNqwzEtWXLEdKGjXoAQcnuiDYPfPXDxZGPRUAUxfuyFtRFIoufNKuffbGQDogVWunwHKBxHWerCDBaqtYXSDuWVArgydMaWGucrgTmZYBLiQbJGHEhjmPcegiLTQaEgVivKoXExyJoLcRhpuOXVLfz");
    string ipalz = string("spMGGtUPKubMnnnheJpMzQeutfRymwhGWfv");
    double ZkLzPgtXGx = -421523.935518612;

    for (int gpdPDQqzrE = 1862081617; gpdPDQqzrE > 0; gpdPDQqzrE--) {
        JLuAmwjyONx *= JLuAmwjyONx;
    }

    if (JLuAmwjyONx < 1184345684) {
        for (int OFZoltgTnS = 1111150794; OFZoltgTnS > 0; OFZoltgTnS--) {
            JLuAmwjyONx -= JLuAmwjyONx;
        }
    }

    if (hPjHqZvIPFFfIWw != string("spMGGtUPKubMnnnheJpMzQeutfRymwhGWfv")) {
        for (int yeXmPcV = 1720437389; yeXmPcV > 0; yeXmPcV--) {
            continue;
        }
    }

    return LpEDXAueBefXmqt;
}

string sMOhVKcvh::MRyykt(bool xzVNXoUfYD, int HkmaovvXyDRh)
{
    int wdMPBzkGylGwFOP = 1251548409;
    int kinFCU = 68587103;
    double fXoWpJoQnUjOEoWS = -759898.5151304209;
    string ovCOzxorDFd = string("CrddfPqscZWPttWhTZMegbSRWFMkDUKEQXWNXStlFTcVBJcVGkcnWCDXwBsbPHTXIlLPzaoANeekPCpFMHCvkylYMgubmeJXMrpACBosApIPZqSQUvOLoVXzUTnHSeqNOxAgSWchwNYuvzaTzJczliWkEcPQCBpYRRBcjVWyeelZmBfVNiwKUXGptNvezBETOWRELLVYQVBLTTsvckmmSu");
    double kqPzvrYGHn = 160613.78467352633;
    double MHTFvVI = 582668.5882915708;
    bool JMEfxMAJlpJkcCZu = false;

    if (wdMPBzkGylGwFOP == 68587103) {
        for (int HfzJVtig = 1875195848; HfzJVtig > 0; HfzJVtig--) {
            kinFCU /= HkmaovvXyDRh;
        }
    }

    for (int fGptUSOkQ = 1525778786; fGptUSOkQ > 0; fGptUSOkQ--) {
        continue;
    }

    return ovCOzxorDFd;
}

double sMOhVKcvh::rznqewwfEfRxH(bool WTNztuWI, bool sGgBR, int hvezYugOldsAZ)
{
    string RnMPDARxpp = string("LxVqYkUyKPaHOttUUdgugDaCcCsGpjkVMfvHXaKgEQPOfviXzFhQLdKEZgMRGzmdaABwpDNiEjHiCnWxfdNhqOPwocAwmgwAxnOXdMIapDDLJNnzweRIwJmufUiLoNmTzEXSPlyOddTLgHdYlxCOpekCHnqzMeHUWpJjSYZTjjA");
    int pyBnLNivAXdpEW = 2128541739;
    double EFhwrzrXmHYGdb = -117957.25158285831;

    for (int TPaJxTW = 1932303445; TPaJxTW > 0; TPaJxTW--) {
        continue;
    }

    if (EFhwrzrXmHYGdb < -117957.25158285831) {
        for (int pjNAq = 152098631; pjNAq > 0; pjNAq--) {
            sGgBR = ! WTNztuWI;
            WTNztuWI = ! WTNztuWI;
        }
    }

    for (int nTptScQtebVAG = 95640190; nTptScQtebVAG > 0; nTptScQtebVAG--) {
        WTNztuWI = WTNztuWI;
        sGgBR = sGgBR;
    }

    return EFhwrzrXmHYGdb;
}

bool sMOhVKcvh::XVPpizyxNfyrts(string DRxbxGcfZxlNwYCp, int yESSH)
{
    string zizCyMdU = string("EJPsaXUKvFLfCEWMUzvOqdRmpqCWDkfyUwDRTXVLXZqgVFxBJfHsvtZTBMtcCxHkqGtPffBSyJDMTiSeylTRAQakjQNeKsMQniLgsmiKcvHBpfEAMgpPcgKIAqcogGNlFhrd");

    return false;
}

int sMOhVKcvh::LWRShLe(int lLTIhVfcsZD, bool lNByh)
{
    double KaeqxfTdIFTuxNZ = -531539.3237751832;
    double wQrIUOC = 429570.31041682395;
    double pfHjZCoorYhv = -655878.0720442213;
    double EdgfUL = 43399.324998305034;
    bool oynHV = false;
    string OgYdcD = string("oVkSHmydUZUSsnTfngtxiveWYUDPqIDPHYKqGCtgvOLYVqpusQPaHoGqssuVhDaRvEwffrIhyDMDUXxVKqPAyTKMOotwUJipnGXTJvrAwvxIiexeKILaeiHZBfqlDhSxfoTABMctXTwVQBWUs");
    double qYmlbpZqPkwytVH = 431088.4897176955;

    for (int hhTZsqZx = 314122597; hhTZsqZx > 0; hhTZsqZx--) {
        continue;
    }

    if (EdgfUL <= 431088.4897176955) {
        for (int PZoMXunpwhxVRrD = 1400008751; PZoMXunpwhxVRrD > 0; PZoMXunpwhxVRrD--) {
            lLTIhVfcsZD -= lLTIhVfcsZD;
        }
    }

    return lLTIhVfcsZD;
}

sMOhVKcvh::sMOhVKcvh()
{
    this->tpieRVXMMdJPQ();
    this->VjcsDkbhfYEo();
    this->UJoqXURoidi(true, -562106.1277137292);
    this->yDiXOflbbdR(string("fCjpKAWBxjxRAYCxKUkFQpIuwdOBqBbtsGWjjCkYlECAMhJXITojjFpkLCwhvEsNKufGsXXe"), string("PMkAp"), -1017405.5652391441);
    this->eRAZmn(string("SlJCkqMBfaOgMmLMfwRsIMQJrpMptqPGdmKXGCOtxobwgztTsHzoRfwlowXgFgb"), string("KyPXVXkEvRbepVbRTEzopXbwMpBCUxykgeLzwLzdwGkQnIxqOskvvCkrEeUHrmFgpUeIJOHLZeuPOnukEHjbwpOCzNwdNmVBIcQmaMgKwYETtoAvnlwnWGVNNwWBPPwfuVvPtmKqGKrnKTfwthkNKuuBktNWpvKXZGuAxGVqppBZeNaJnbUrmRNIwCTowEpbIsmhhUZQgqFMVacAwczFIOoYzOEOqXWarvXbSuOt"));
    this->pnrbZLQBQwR();
    this->RnJHMPSloHKonHb(string("bpUAwrtJeUGvbrimSqdxXzIhuxqfIFAZHQxzOgqlNbkMqdHVbJCvPZApcVGxcoRcUtHkVesSVjsOOnhVKnIEyQBesSnadsJnUZhEqCSHHuitKjDHdtrSEYYzhCnSWHqBRnGfzQSLLyZPKYuxkGefyEjqBouRjVvJuhIDaKkteUJrOFvyS"));
    this->MRyykt(true, -317720957);
    this->rznqewwfEfRxH(false, false, 850686645);
    this->XVPpizyxNfyrts(string("LCZJeuFzigsgmTmBXqFFONBrVqFpkeSjSYZnhBaSqLaCAMkIONwQvYWiWXMAFYpKDlsuJNQMlTXTuBtPsgLTVFJIDJdqPzinfOIFaSuTJDiyZEfHbOAbYVslRweSXOYiyRbxQOSahWVAvAyIkcLUmfqmiWbPeBMTJZCbVtpgwVjdgl"), 41071597);
    this->LWRShLe(535859290, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZuebdearMiHaaoAj
{
public:
    double sdbswPIMqLzNbq;
    double LoQxHebtwaP;
    int epICyPBIhh;
    bool FuCdgZKI;
    string RKhOHcwqqEXSz;
    int VRdGNqLjDai;

    ZuebdearMiHaaoAj();
    string WvNuAqErw(int kKKPyUA, bool YdtcdnxDUEdJz);
    double oXYvXfvDkPzIH();
    string rGMEv(double jGidGjvFIvJsN, double GZjOh, string EaPgl, bool oIuRUNySeLQUzTH, double AufaBBUGgk);
    int zpSvtTse(int ihGfxisaBkMM, double FtbCxau, string gxmMKDmTyqiAGPT, int QgYRvLvAHVjdqVrh, int KgOrSGBkdN);
    string tkhTLpefPJ(double rxMms, int YLPyMe, string RsNeR);
protected:
    string pkZfuCwqLaeZ;
    bool zASgWQXVbVOqZUJQ;
    int TxPHMpAMkftXKQ;
    int RbRRcj;
    int LKlZNATHeMkFDDL;
    double QlWyvBpuD;

    bool ilGWxhJrEIa();
    double jTHDBcLhQmWcsLB(int YtNYAC, double SEbtemkdUkCxd, double Pisjl, string rNNKSIlU, string tGkJj);
    int KTxWI(string hnSUm, int OmOMAnfT, bool WEenOL, int rzQIAfcAeylvJQ);
    string KJuqinCvPscuNmwB(bool voaFNxia, double rbXlXXJOuT);
    double wFPKI();
    string wFkscpZstgg(string zuCfheAKiiJLtRQ, double dKVMDiaYXZCcWWR);
    int KAeESQwLVJSM();
private:
    string QgWjGvQDaYzpDfF;
    bool fPPyt;
    double hsiiNchq;
    double cvnXgjq;
    double mLPzHCWBV;

    int EZQQXlx(string yAbXvKBmIE, double SNMoscfiC, bool kbitSMlDNU, int duFBSFIvbJz, string kwLXcvife);
    void yXXJL(double eMoFkOwG, bool YWlQhFywUCItugi, int dJXJXRigOLnZP);
};

string ZuebdearMiHaaoAj::WvNuAqErw(int kKKPyUA, bool YdtcdnxDUEdJz)
{
    string KgrVX = string("XRRxXjEISMIqpiUnxWtGkzKkZfJxCmjwfHpFgjoDXXNlAeTIvUwyyfOrNuJVtysdUlGuecGqFVhTPzjMMxDcExqH");
    int Jmhssj = -990611034;

    if (kKKPyUA > -1211148153) {
        for (int kLPhkPvYfdfJVNHJ = 1709924305; kLPhkPvYfdfJVNHJ > 0; kLPhkPvYfdfJVNHJ--) {
            Jmhssj = kKKPyUA;
            Jmhssj -= Jmhssj;
            KgrVX += KgrVX;
            YdtcdnxDUEdJz = YdtcdnxDUEdJz;
        }
    }

    for (int OBzFNcAULexkPtGY = 914638540; OBzFNcAULexkPtGY > 0; OBzFNcAULexkPtGY--) {
        kKKPyUA *= Jmhssj;
        KgrVX = KgrVX;
    }

    return KgrVX;
}

double ZuebdearMiHaaoAj::oXYvXfvDkPzIH()
{
    double sblDwV = 850831.4777012368;
    string KZhhsSWLNBfRfo = string("HscMjEaIQbJcvxKxAixEHKaBfDzBTudnhkTI");
    string WTfGjrMT = string("JnoFVaFlxtDzQKdNOhNSZtsofXyKEnFyJZSjUfMLucqHUXnXHBBdwhCfePqoWzjBmCHBFyqkdZuCpryFyuwIPYDNmJHRcbpfQjFpuisFpZhoBapXwlNhakSyEhdlDDIkVJMeVujHXGLeHyvEAvucafbpTptCEczyHDDFMblVUzPeIOVnyYGcOuZECUmUeNyTBytDFzTXfSWAuWDWFRKDGbCRobcXYLPBIsLxpmeRuMOSSftCXnfOfkG");
    int wmgGuLYaawjelV = 63853472;
    bool DcImfSTO = false;
    double zuIHmHFrbaZ = 540258.4113135983;
    int vzOmMHjK = 1028556656;

    if (KZhhsSWLNBfRfo == string("JnoFVaFlxtDzQKdNOhNSZtsofXyKEnFyJZSjUfMLucqHUXnXHBBdwhCfePqoWzjBmCHBFyqkdZuCpryFyuwIPYDNmJHRcbpfQjFpuisFpZhoBapXwlNhakSyEhdlDDIkVJMeVujHXGLeHyvEAvucafbpTptCEczyHDDFMblVUzPeIOVnyYGcOuZECUmUeNyTBytDFzTXfSWAuWDWFRKDGbCRobcXYLPBIsLxpmeRuMOSSftCXnfOfkG")) {
        for (int NIQgJUQ = 1999811098; NIQgJUQ > 0; NIQgJUQ--) {
            KZhhsSWLNBfRfo += WTfGjrMT;
            KZhhsSWLNBfRfo += WTfGjrMT;
        }
    }

    for (int EqUDPWBbJ = 1181380151; EqUDPWBbJ > 0; EqUDPWBbJ--) {
        continue;
    }

    for (int FYrHpJnyytSZrv = 2054364274; FYrHpJnyytSZrv > 0; FYrHpJnyytSZrv--) {
        KZhhsSWLNBfRfo = KZhhsSWLNBfRfo;
        WTfGjrMT += KZhhsSWLNBfRfo;
    }

    return zuIHmHFrbaZ;
}

string ZuebdearMiHaaoAj::rGMEv(double jGidGjvFIvJsN, double GZjOh, string EaPgl, bool oIuRUNySeLQUzTH, double AufaBBUGgk)
{
    bool tvFVHnwPm = false;
    bool CmYBwwICndO = false;
    double fbnQmr = 217787.02369924798;
    bool nbBdeix = false;
    string wrCBsAQZhGL = string("fCdOkVPSRlRdxtAWpSCBPmlUDhdJYQoUGzmOuxYTIMhvXeXKwHhohyyNaNztGSLXWnvCNPsZEWXUYtxHvnILHOQPTNSruwYxeWGNgbtLucTsXNOFGcnslQtroJMhaAvAJgxJHFuoMupRBedjugpOURiomLxMVFiSramBzVNTUineeRAwNKuhTJJqnyFpyYjlNkhoFLEBGnfACNWppZqIfjBuBmIeSkVRFkcJqoYlhcuXOpWJlEVwePdg");
    string fWbTznYz = string("ceHWVyIAuQaaqGvAKdbKuldVfIAPVlKAzdDWbAofMBbiLgAhVBPsHkZLMxbXtZdVuxWObswDKhbvICCMlwoklTkICWGPPtHBzzrrYZSqQGVjqpfSvmoWNCADDSgqxFkLPNPnqiZzDaLJHNqzcTYpaIXifTcIwlNDwWjqjVYDXKhMDpnFCXhhEGHYmhwQfPTph");
    double QbNqa = 586494.4877613151;

    for (int XVskpXboStTqLyCi = 151941380; XVskpXboStTqLyCi > 0; XVskpXboStTqLyCi--) {
        QbNqa = GZjOh;
    }

    if (GZjOh < 10837.715507997733) {
        for (int XvOWdIThZejAQP = 1673995893; XvOWdIThZejAQP > 0; XvOWdIThZejAQP--) {
            QbNqa /= QbNqa;
            tvFVHnwPm = ! CmYBwwICndO;
            fbnQmr += jGidGjvFIvJsN;
            fbnQmr *= AufaBBUGgk;
            wrCBsAQZhGL = fWbTznYz;
            oIuRUNySeLQUzTH = ! oIuRUNySeLQUzTH;
        }
    }

    return fWbTznYz;
}

int ZuebdearMiHaaoAj::zpSvtTse(int ihGfxisaBkMM, double FtbCxau, string gxmMKDmTyqiAGPT, int QgYRvLvAHVjdqVrh, int KgOrSGBkdN)
{
    int EgEEri = -89516785;
    bool wJhXVHUIip = false;

    return EgEEri;
}

string ZuebdearMiHaaoAj::tkhTLpefPJ(double rxMms, int YLPyMe, string RsNeR)
{
    int vpUbqzqz = -575775869;
    double HFBQuTXRiaU = 869018.0204842546;
    string VKnkhsCs = string("gXqHTFfSZFIFmLglKIGAXuqpGAjRuOmutCaQNJvEPYfYTNETqkMhfVcSGwyGUEcHNVbbFjLxsJaJqbkurcxgKRNoIQdPEZkWPbjwznFjekTnEUFyiRpOCfnJqaVRiKwwKMrDK");
    string rZzEFYkKGPZ = string("qKLiWKWcNKyebQDptZQjVMGIdLlMeSwjPkVYbbxhLudhkkzHBFKplYKzeiOCJrgvedkXGzBkizxlwdTwmhUUDQZxbMUQvTrObEHiaqLpuyLcHDPRAhJrAwnlukmwxD");
    int kGSTqz = -1717382451;
    double JZiAjTYgcE = -101062.62112625786;
    double Rngjatfi = -159020.54337473534;
    double DMODWCloN = -918221.9861882082;
    string pwNCUGMVYq = string("xQqThHhGpJUFAgDKGsTlwkQYdwUXtnQEqiVfUUWDLXcMTQcQfjsiqDjhbYxoXFZmpdodQjQfxsGoQvOFosRNfwlBamZWtOinmCLVdMUStfXcUP");
    double TSSrBT = 996741.2172237699;

    for (int ROJEkszzARZLP = 1686409850; ROJEkszzARZLP > 0; ROJEkszzARZLP--) {
        kGSTqz = vpUbqzqz;
        DMODWCloN *= TSSrBT;
    }

    return pwNCUGMVYq;
}

bool ZuebdearMiHaaoAj::ilGWxhJrEIa()
{
    int UpwGmynyGD = -617956027;
    string ddmiXXaFAZlHZZKX = string("flUAllNJxJxuhEIpziXocWlABzsGsGApYfmaJtNibgGunOyQGrzJtmTNMYWhbAflMCbuqLqAslKjdWCfdJKLJGbcQnBBJXkdHLFihdZMYgJjlqVIxxBOJinHwSFK");
    int UjZCKW = 1269531843;
    double FztPwcLe = -53370.10842958865;
    string HLHeeLtuD = string("VwOQLYdbotSipNvMCPaRuMPpjxejHtTUTUTIQBQuMrPdLXZcXyPRoeGaMiqjLTEPonWlNjplviTDuEBCfXUKOxJocYHMLkVbAGKoPMiiDviqbgXHdtWsJozjlloKOHNDuBsqEILutMJBNyyUImMwZyzlJKWrWgaEVbTuWOZSGOAuJQWmaXEgTSsOkJwNaFR");
    double MybskvZPvRzJM = -720865.7438065122;
    double pqdbKQdgw = 192965.31116776087;
    bool UpSwbxb = false;
    double ZCPSc = -577074.1868764655;

    for (int JuiVpvJM = 141754767; JuiVpvJM > 0; JuiVpvJM--) {
        UpSwbxb = ! UpSwbxb;
        MybskvZPvRzJM /= FztPwcLe;
        MybskvZPvRzJM *= pqdbKQdgw;
        FztPwcLe *= FztPwcLe;
        UpSwbxb = UpSwbxb;
    }

    if (ZCPSc <= 192965.31116776087) {
        for (int HmhBgIm = 921682583; HmhBgIm > 0; HmhBgIm--) {
            UjZCKW = UpwGmynyGD;
            ddmiXXaFAZlHZZKX += HLHeeLtuD;
            ZCPSc += pqdbKQdgw;
            UjZCKW -= UpwGmynyGD;
        }
    }

    for (int MgcrOPVgUSWPO = 955082610; MgcrOPVgUSWPO > 0; MgcrOPVgUSWPO--) {
        ZCPSc *= ZCPSc;
    }

    return UpSwbxb;
}

double ZuebdearMiHaaoAj::jTHDBcLhQmWcsLB(int YtNYAC, double SEbtemkdUkCxd, double Pisjl, string rNNKSIlU, string tGkJj)
{
    double bpUGILNOtiXcJP = -404208.82461143704;
    double JvMDyUCe = 571077.4673567822;
    double tNItyIDOMfGpRvxe = 60387.69821215077;

    if (rNNKSIlU == string("pjbWyDkvUtPlPAuixVRksDyfctKmHGedeRBKmIEXHKaOyKWgmNZwnoHwaJtPpEVKzYvlpVzRsHeMHIZVqwBZrmPCXAvBbwJYtWdNwXaeyXKgiVNtYcftDUUSgRnngljJYllXyWuZLOqEwMkSEjeRvLYKicKLvkfIdhkNNqevAKftxXuQECwUYtHtbLJNnERbcmVJQcwTOHOezDgQZOHMpCQhOVFxUxQpkszpYaq")) {
        for (int hpVjSryIKvbl = 459374724; hpVjSryIKvbl > 0; hpVjSryIKvbl--) {
            continue;
        }
    }

    if (bpUGILNOtiXcJP != -404208.82461143704) {
        for (int oqkbR = 1635962372; oqkbR > 0; oqkbR--) {
            SEbtemkdUkCxd *= Pisjl;
        }
    }

    if (SEbtemkdUkCxd < 60387.69821215077) {
        for (int OEzxFWLBLZK = 1856199881; OEzxFWLBLZK > 0; OEzxFWLBLZK--) {
            rNNKSIlU += rNNKSIlU;
        }
    }

    for (int oPBkDqB = 440136555; oPBkDqB > 0; oPBkDqB--) {
        tGkJj += tGkJj;
        tNItyIDOMfGpRvxe /= tNItyIDOMfGpRvxe;
        SEbtemkdUkCxd -= Pisjl;
    }

    if (JvMDyUCe <= -404208.82461143704) {
        for (int smxepB = 1862366574; smxepB > 0; smxepB--) {
            JvMDyUCe /= bpUGILNOtiXcJP;
            bpUGILNOtiXcJP += JvMDyUCe;
            bpUGILNOtiXcJP += tNItyIDOMfGpRvxe;
            JvMDyUCe -= SEbtemkdUkCxd;
        }
    }

    return tNItyIDOMfGpRvxe;
}

int ZuebdearMiHaaoAj::KTxWI(string hnSUm, int OmOMAnfT, bool WEenOL, int rzQIAfcAeylvJQ)
{
    double wGmpRBlhYneRV = -670693.7010598846;
    bool rOHEhvCjjyYfj = true;
    bool tKVtZsWpUsIU = false;
    int wVQvTma = -493525819;
    int GjLBKgxabjRIw = -891969052;
    int pHZuUNwkOwHfamun = -808275042;
    bool ahoJdorhiaMZsAHC = false;
    string uRyxOaAjAzPyF = string("UvQiKWozIBqlJePjtBcXOoyUVgUHjBEiMMMkOStgMEGaDksGWEMGmeujHyjepQWvuohlawijqsJgQlqSrWdWuGcrwOlHNSjjXkRjVgEcukNKFPRyQDfAuStndnrZWlzYOMBZCXucZCbdttimsdsVbydQ");
    string MsZapHJ = string("bqZowhjlkv");

    return pHZuUNwkOwHfamun;
}

string ZuebdearMiHaaoAj::KJuqinCvPscuNmwB(bool voaFNxia, double rbXlXXJOuT)
{
    double vFOdrDrfw = 202331.28476235553;
    bool oRshwF = true;

    if (voaFNxia != true) {
        for (int eMzoCKrrNmc = 1562487422; eMzoCKrrNmc > 0; eMzoCKrrNmc--) {
            rbXlXXJOuT *= rbXlXXJOuT;
        }
    }

    return string("qGgGHxzDNvnQjUfjafzZylAAYImGneNGFdMBg");
}

double ZuebdearMiHaaoAj::wFPKI()
{
    bool mKwzkinUhvPxQx = false;
    double bCXEoCJzNx = 61571.30168030173;

    if (mKwzkinUhvPxQx == false) {
        for (int RtEUcfx = 509346420; RtEUcfx > 0; RtEUcfx--) {
            bCXEoCJzNx /= bCXEoCJzNx;
            bCXEoCJzNx *= bCXEoCJzNx;
            bCXEoCJzNx /= bCXEoCJzNx;
            bCXEoCJzNx /= bCXEoCJzNx;
            mKwzkinUhvPxQx = mKwzkinUhvPxQx;
        }
    }

    for (int vRftcsWAZzXUt = 632871804; vRftcsWAZzXUt > 0; vRftcsWAZzXUt--) {
        bCXEoCJzNx /= bCXEoCJzNx;
    }

    return bCXEoCJzNx;
}

string ZuebdearMiHaaoAj::wFkscpZstgg(string zuCfheAKiiJLtRQ, double dKVMDiaYXZCcWWR)
{
    double GxxikykBqCLUGxDE = 1012721.5933713504;
    bool jhyUTk = false;
    bool tNFSs = false;

    for (int zDpofbEGizpt = 149772232; zDpofbEGizpt > 0; zDpofbEGizpt--) {
        jhyUTk = jhyUTk;
    }

    for (int nKGzEfIktImtc = 1480845420; nKGzEfIktImtc > 0; nKGzEfIktImtc--) {
        dKVMDiaYXZCcWWR += dKVMDiaYXZCcWWR;
        jhyUTk = ! jhyUTk;
    }

    for (int iyNgdbsH = 861744863; iyNgdbsH > 0; iyNgdbsH--) {
        jhyUTk = tNFSs;
        GxxikykBqCLUGxDE /= dKVMDiaYXZCcWWR;
        GxxikykBqCLUGxDE -= dKVMDiaYXZCcWWR;
        GxxikykBqCLUGxDE /= dKVMDiaYXZCcWWR;
        zuCfheAKiiJLtRQ = zuCfheAKiiJLtRQ;
    }

    for (int jvQxH = 1209972675; jvQxH > 0; jvQxH--) {
        jhyUTk = ! tNFSs;
        dKVMDiaYXZCcWWR += dKVMDiaYXZCcWWR;
        GxxikykBqCLUGxDE *= GxxikykBqCLUGxDE;
    }

    if (GxxikykBqCLUGxDE > 1012721.5933713504) {
        for (int LefOJEh = 876589669; LefOJEh > 0; LefOJEh--) {
            GxxikykBqCLUGxDE /= GxxikykBqCLUGxDE;
            tNFSs = jhyUTk;
            tNFSs = jhyUTk;
        }
    }

    return zuCfheAKiiJLtRQ;
}

int ZuebdearMiHaaoAj::KAeESQwLVJSM()
{
    string Ppfhml = string("qIFfRGDWMlygMwmFtGZXGcNVrPTACfMwscKOkgnpdOaWFlhebwqivTIYusMmZcnABpEsIytysCxwOGopVGwfhGkVRgrQeDojFabjlRUdURoivbezlWisOmrddLMFEUSJLwRfpmviIoHLpOWoPVMNDCJSyEeHjEKzFcyiSaxicVRithTVzRfWRHrCzplsqCfxknmBTCNJmGldNcBvaTyJTPwxYMPpEmMuHRfVhD");
    bool fFFKGXvzu = true;
    double KlfiUfeCjFLz = 36321.68319486398;
    double BkJNoHftABgd = -216218.13501429601;

    return 1197224823;
}

int ZuebdearMiHaaoAj::EZQQXlx(string yAbXvKBmIE, double SNMoscfiC, bool kbitSMlDNU, int duFBSFIvbJz, string kwLXcvife)
{
    string antIJmtnuZcXvot = string("quFwHxLZMaBhrwuTohtLEPjucAPflBisLnkesweoBlpeACZOhszpCaXIKhWSjzTOwRZWVvAliuJJKQRehwdEHptzzZpfJWSFSdvOkqmtjSPccqHHnwzKpHxSYsjtjbDGfdHGWUfzOyOFMSdffFpKJNuTcjFkBnLxsZkQRpRBEjyKFHSQyfJnTvCPROZNMhBhsnQRbRdBxjlFuXiedXoXLDPUZtIcwaUYLTKJMUXmhiFmybzVmOWUA");
    double mqhzqEwtPin = -296061.3134328509;
    bool neZeIlikadjKsmB = false;
    string sSueZeHtYn = string("uTGJXvuYEhuQjYNDNMEuVAhJeqXDOhITwSDSgtXoSwffOLHqqndZdPtMKFBJQruOcbiDNdFgiZjWmGssPcuugjhQLupAlMyZHGPJSdcbrYyosbUZYBPswDThanIlEswqIWbRNwMcEtigIAsshBPEfauOnemz");
    string sozupuxtNvKFaNLE = string("FreNhaUaxALRvObvEnTKogYKvGNnYAqoPibsqdLUDirAVAmdrOSuMGgiDpWlkdXOHEkBrnSYNmJczabzEPdVcHDIfkZQoBDCmQTWuhSpkYMRtwueetVNJgNLDGxODcvl");
    bool OEOCHx = false;
    double zvgeiLPDC = -623675.5309935926;
    string wQOhsCYnkUHpuFVV = string("dwwZropMzdbUTDQyrcFfmwhXjHCuBgfwvQsEwVwGDadKWwvjKmaEAGnhfGBoccPunlHMbzvLfhaKgqIdcCnHcvglDdPusNxFeyTqEPuPUaCmxYRbkcIBNtmZGQOcgsVJJYqMvWEcEgFBnVRqpOxvvZxTGAlcOCTRpJoCotZnMHfWupHttObdcuLeEYQTRynAppxDUGUsjNbkHOMiGTHlziVyvTBxKZeNcsKutqxJvLxqYcz");
    bool vobUlpOkjEKm = true;
    double AefxKTcy = 222028.0147999757;

    for (int UtygrVTFwLRKa = 1606214844; UtygrVTFwLRKa > 0; UtygrVTFwLRKa--) {
        kbitSMlDNU = neZeIlikadjKsmB;
        antIJmtnuZcXvot = wQOhsCYnkUHpuFVV;
    }

    if (wQOhsCYnkUHpuFVV <= string("ASNhoSPMvgVhhoEPhSdNvJgQefzsshsTtdnWrZRrcpNxovZmwHJLzjD")) {
        for (int yJXNUoTMkqlskZZd = 1276111406; yJXNUoTMkqlskZZd > 0; yJXNUoTMkqlskZZd--) {
            OEOCHx = neZeIlikadjKsmB;
            zvgeiLPDC -= AefxKTcy;
        }
    }

    return duFBSFIvbJz;
}

void ZuebdearMiHaaoAj::yXXJL(double eMoFkOwG, bool YWlQhFywUCItugi, int dJXJXRigOLnZP)
{
    double YPdNZXreYPjWmnbn = 553718.9770238783;
    int ZKgzSZVCw = -1011154228;
    bool RsNwOWSmlqW = false;
    double QApovV = -203343.1913207173;

    for (int xKzlMyxVLv = 759598267; xKzlMyxVLv > 0; xKzlMyxVLv--) {
        eMoFkOwG = QApovV;
    }
}

ZuebdearMiHaaoAj::ZuebdearMiHaaoAj()
{
    this->WvNuAqErw(-1211148153, false);
    this->oXYvXfvDkPzIH();
    this->rGMEv(270712.63009002607, 453198.5575441533, string("byXeNqhylOfzSLhuIWmCQKGCLcqdLCsJqaMSczDoKSLblNFrNwOBBaMnzYbKmrKPvupohjMmgHkhCbPWfkLxnWmngOKJWxTjmzvdwpgrnlMZnKkRdTpTflsnHKnUdEYYGoHPHwkJUdxwDEXNRoNbSqkLPFk"), false, 10837.715507997733);
    this->zpSvtTse(1371060040, 974834.5882985925, string("ryawpsVjQjBLHZEZgTHqUHwQwC"), -1960526574, -1925413118);
    this->tkhTLpefPJ(893778.6901540784, 141608481, string("meojZqdoLjrLYGjqVtXVUgEwUtyMLOZjBQUJYopDZYEoPmJwVyffCGyTxJZsGWgXfAuYFEFWPxgwBCEsNDimAVCtygKEmxdxrTKCFThPJMjysGWJxkqeGaZflMdlDDCdcHFSGnQyeLjbLixVORuWOeCFdeVVaAeqELA"));
    this->ilGWxhJrEIa();
    this->jTHDBcLhQmWcsLB(581996364, 532170.7274121207, -694542.6050997558, string("RzUGfxckzHiAscKJtpIGuCNaWImVuRmKBsgqgboDNUpySKftBwVjQmpwUWmLZfNwARaykvqHzLSYNdePKEilpPFuNWFPtYknvyTKeLzNrtAxlZGFYUmjcClDLlJiOvrgLIOklqbQaASDLcpeiKmSjGRkukL"), string("pjbWyDkvUtPlPAuixVRksDyfctKmHGedeRBKmIEXHKaOyKWgmNZwnoHwaJtPpEVKzYvlpVzRsHeMHIZVqwBZrmPCXAvBbwJYtWdNwXaeyXKgiVNtYcftDUUSgRnngljJYllXyWuZLOqEwMkSEjeRvLYKicKLvkfIdhkNNqevAKftxXuQECwUYtHtbLJNnERbcmVJQcwTOHOezDgQZOHMpCQhOVFxUxQpkszpYaq"));
    this->KTxWI(string("JpcnUqulxrJlbBobAsgQUHTjtKkFhUvkwNqGtzPXOjFRUAbfnPniLpJgpIQhwHOWKpFByGMcAiNJpNurgjCENHIwUSIAoXiVToBrxxOuSGxikukltimiRqVVLyMAQKtDgGAvLZpuNcjHWSFGaPpnBwPVMOZJinPLLpAQyrLZUGEmRoqanrTRTjFu"), 903054979, false, -1513550759);
    this->KJuqinCvPscuNmwB(false, 674556.774197988);
    this->wFPKI();
    this->wFkscpZstgg(string("OlArObIHbaIzORqvWJYTlcVVRzHBAXIScWrGMgQmlfAFCnGmqlZJcjKmhkqUqLXssFfmBTSWdMfLSxXsLKZqUltmINZUfJeJQCRRQaPceCSzSMLXVQAeTYkkPOrvFfDUIcpVLlIeOngrKBrDSBurMCzcpFgFcCrusDmiuMebvSiJxRliWXeFoJYRLKZwcDLbhHTmJgREImhyDkzyiCOWKRzUHIKXsfJimDDVdGiEoSZYUkoyDLzGC"), -513336.51886412036);
    this->KAeESQwLVJSM();
    this->EZQQXlx(string("ASNhoSPMvgVhhoEPhSdNvJgQefzsshsTtdnWrZRrcpNxovZmwHJLzjD"), 558256.1376813625, false, 995495268, string("WxuIGWZEDxBQyccMwdQjRzXoPrbbcNclafgrXdeEKbjglrUqtwVtPXyxplzyiDcupFWJTlWyUCwUZBFaManAXPetqecBMJzechrYRoCWWRZklJNfmMITenkFsgAWlSHdQtrdlcDiBuYaZdvjLqpCwaXHHppIaQQMXyQoosjiKhmZMibmXUFdqCSNzMEppZYrQEmYfgwCNodBeKvFEMOMtWffwvfMlKtNMjTOsjCohZOzXOpchu"));
    this->yXXJL(916105.3137920478, true, -1775895750);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rupkxrorPfnz
{
public:
    double FdLRdFg;
    double hSgQkDgQiqXO;
    int zPQRngcFg;
    bool aTvxrpjTGBiJkNyZ;
    double AQobezDgEI;

    rupkxrorPfnz();
    string MSAKCd(bool kZYkBkJNB, int BapxBB);
protected:
    bool nIQyyypNWGZ;
    string aAqItZHFeS;
    string FVdwJ;

    double BHDgMdE(string zwRUaf, bool tPIpQxN, string RQLvGTXZyOzuHL, int Aazvqkjq, string issLkgUNaybLTfc);
    bool ZtZGoLpywpnZ(double pRpjcwiksjpAMA, bool AvVQTlaBSHGr);
    bool ljcOZE(bool qSQWp, bool fsmgiUSh, bool mVxEjklPgu, bool uUiMkIavbFsCp);
    bool XfrtaEvzBuoYHd(double uDMzcMSdJblbxyS, int NQnOZDgB, string GuhoYdyVK, string FxIjcbVsesaeX);
private:
    string tSGALSHfsfr;
    int cxFoHfuwyOE;
    string FCneTQlhzS;

};

string rupkxrorPfnz::MSAKCd(bool kZYkBkJNB, int BapxBB)
{
    bool gjzJZsS = false;

    return string("VPNBKzameVcYhSsFNrEUaMkCsbKzqculPoGvnwfThkTEaSuYZKvjbyGHyDnTumNVPzZYEfyXZCGnLuqZyyRXNuoKvJXYSxxnrRBGeoipbWagozQpHEmtlMRGdPoadnIBEUGZpsZywpdmJJHTCIgePiWBMhJkgycVfgteeqyCmKPACvEevtPPXy");
}

double rupkxrorPfnz::BHDgMdE(string zwRUaf, bool tPIpQxN, string RQLvGTXZyOzuHL, int Aazvqkjq, string issLkgUNaybLTfc)
{
    string ygZqYewNVNZpoKQr = string("zqYxYPcDHsJZptsPimcxwqcqyUPYXxyEhcZGlbRWGdIsOeVeOovGKkTUenGxigXIyLsjpWoLFQscvwbmWSgHNyrCHEBdPSTOlWunaGQQfaYVynkZjrnrXtAkxXMRuwywVZIDMwVXYFSEzQQmmRDIaUCZQz");
    double GBVkGLLRKHSDtXcy = 1048572.1641412731;
    bool ctQbCi = true;
    string vaZIBETOLlwdY = string("GiqFMlm");
    bool iOzLwVRQeWSlcekQ = false;
    double CDvWGiHLtJE = -979609.9720279586;
    int JEedDyf = 816023758;
    string XzldLLPBkDHHMIev = string("yOzGKioAOLedpFDNRbeWuxWwNWfIlOsZlbyslNUtkwSksaBDnfoRHeEVbMSeRjfnARUNGzjgMFwShjmQfJpszprHPinjAwuUAzuExwatwCTiftcQUIFGKhPLGVGnMGZAkNMrboqPExJQITeqxLGcTiVpxGUTQSVmwIWAgLnLiYNbJYNTKoYzJBUzRHKMkfGZtITxdPKVPhRudsHcCRlPTYxIlCx");
    string bYEcaUNhjKEs = string("UgIUyfaRiobXQvJULOCqwQ");
    bool GssjyzVGYK = false;

    for (int SzHmlTBO = 1833550119; SzHmlTBO > 0; SzHmlTBO--) {
        iOzLwVRQeWSlcekQ = iOzLwVRQeWSlcekQ;
        GBVkGLLRKHSDtXcy /= CDvWGiHLtJE;
    }

    for (int mwMiertQE = 1696560126; mwMiertQE > 0; mwMiertQE--) {
        RQLvGTXZyOzuHL = RQLvGTXZyOzuHL;
        ygZqYewNVNZpoKQr = XzldLLPBkDHHMIev;
    }

    if (iOzLwVRQeWSlcekQ != true) {
        for (int fbFTY = 1688133508; fbFTY > 0; fbFTY--) {
            iOzLwVRQeWSlcekQ = ! tPIpQxN;
        }
    }

    for (int gagBCOW = 269377525; gagBCOW > 0; gagBCOW--) {
        bYEcaUNhjKEs += vaZIBETOLlwdY;
    }

    return CDvWGiHLtJE;
}

bool rupkxrorPfnz::ZtZGoLpywpnZ(double pRpjcwiksjpAMA, bool AvVQTlaBSHGr)
{
    int WxcVxlShJMVT = -554826478;
    int KACumgOgBUSFbLQm = -1543171843;
    bool obGwNJJrlZX = true;
    bool XuBEqwTOWWtKC = false;
    bool MLOkmjWrwnnHB = false;
    double HTcRqyKSat = -298771.38689805137;
    bool vlyprXTGBh = true;
    bool CcmDGOxrj = true;

    if (obGwNJJrlZX != false) {
        for (int cdreMeXKBM = 749557305; cdreMeXKBM > 0; cdreMeXKBM--) {
            CcmDGOxrj = ! obGwNJJrlZX;
            vlyprXTGBh = ! AvVQTlaBSHGr;
            AvVQTlaBSHGr = CcmDGOxrj;
        }
    }

    for (int RAPrXb = 817599334; RAPrXb > 0; RAPrXb--) {
        XuBEqwTOWWtKC = vlyprXTGBh;
        XuBEqwTOWWtKC = MLOkmjWrwnnHB;
    }

    for (int UpPFbTvjPO = 1341843807; UpPFbTvjPO > 0; UpPFbTvjPO--) {
        vlyprXTGBh = MLOkmjWrwnnHB;
    }

    for (int KfbPoKjxPY = 304495445; KfbPoKjxPY > 0; KfbPoKjxPY--) {
        obGwNJJrlZX = ! XuBEqwTOWWtKC;
        pRpjcwiksjpAMA /= pRpjcwiksjpAMA;
        CcmDGOxrj = vlyprXTGBh;
        WxcVxlShJMVT /= KACumgOgBUSFbLQm;
        vlyprXTGBh = XuBEqwTOWWtKC;
    }

    if (vlyprXTGBh == true) {
        for (int OyfCBObNznOTct = 711875318; OyfCBObNznOTct > 0; OyfCBObNznOTct--) {
            vlyprXTGBh = XuBEqwTOWWtKC;
            HTcRqyKSat = pRpjcwiksjpAMA;
            XuBEqwTOWWtKC = ! AvVQTlaBSHGr;
            vlyprXTGBh = XuBEqwTOWWtKC;
            vlyprXTGBh = vlyprXTGBh;
        }
    }

    if (vlyprXTGBh == true) {
        for (int lHYpahQEnvsjWVC = 1161668344; lHYpahQEnvsjWVC > 0; lHYpahQEnvsjWVC--) {
            XuBEqwTOWWtKC = MLOkmjWrwnnHB;
            vlyprXTGBh = XuBEqwTOWWtKC;
            KACumgOgBUSFbLQm = WxcVxlShJMVT;
        }
    }

    return CcmDGOxrj;
}

bool rupkxrorPfnz::ljcOZE(bool qSQWp, bool fsmgiUSh, bool mVxEjklPgu, bool uUiMkIavbFsCp)
{
    int wuxRSSxnB = 1243294363;

    if (wuxRSSxnB == 1243294363) {
        for (int AOVnBoplpwEsfpW = 1127473783; AOVnBoplpwEsfpW > 0; AOVnBoplpwEsfpW--) {
            uUiMkIavbFsCp = mVxEjklPgu;
            fsmgiUSh = qSQWp;
            qSQWp = ! mVxEjklPgu;
            fsmgiUSh = ! uUiMkIavbFsCp;
        }
    }

    if (fsmgiUSh == false) {
        for (int RVYhEDq = 1814635567; RVYhEDq > 0; RVYhEDq--) {
            fsmgiUSh = mVxEjklPgu;
            uUiMkIavbFsCp = fsmgiUSh;
        }
    }

    if (uUiMkIavbFsCp == true) {
        for (int TiaEcKuxtzaDQwiT = 797299116; TiaEcKuxtzaDQwiT > 0; TiaEcKuxtzaDQwiT--) {
            uUiMkIavbFsCp = qSQWp;
            qSQWp = mVxEjklPgu;
            wuxRSSxnB /= wuxRSSxnB;
            mVxEjklPgu = qSQWp;
        }
    }

    if (fsmgiUSh == false) {
        for (int nFswdZypYEN = 535123266; nFswdZypYEN > 0; nFswdZypYEN--) {
            fsmgiUSh = ! uUiMkIavbFsCp;
        }
    }

    return uUiMkIavbFsCp;
}

bool rupkxrorPfnz::XfrtaEvzBuoYHd(double uDMzcMSdJblbxyS, int NQnOZDgB, string GuhoYdyVK, string FxIjcbVsesaeX)
{
    int ACUEmXoy = 474444584;
    string FsfYzGFfRdVIC = string("aEdFlQuQHYWeUjgKFDIjZWINnCIeiJXogALWcSBIbgTVASVujhanxLzWpvFcvlDearPpIGvzhAehbEeeTINKjJJzttGMmDPiICCGrcgkboaMOZJlITECkIybSYsSdRkGJvTunrmaKKruGCvjtOZGNMegGefi");
    bool JFncPpBvmh = true;
    string XDBobvUHveRf = string("uwPDgEOHNkjhNJPIeCTcCoTIGgyoDmawhvzxVAYegASoMDeGwOPqCIlFlcAmCiSICJAullIDqiAfMumdoqYhCtIWAuQZAxfzrqAxDCRaUAVtaPnbluVVbrUjUgFJWNdptLssbQAsrTupHLoJzQHdTvZ");
    string VRLLdaaqWh = string("spfUnVXNYxBXYejJcYjYyVRJnJUabUHVqRXkixghXIwBroPpGeSnnpfkufIWucpeMUKUjCZqrcdoLrrNFcgKUWDqOABtVswaqozwHnRAxCpdTaAAxKyyPyjxKIXlJylVeMaVlGiSCRnerWNhcWEliXWobxePpBFvNOMbcsWHAeyqBMCpIzhrAQfiNh");
    int uyvxrM = -1546133497;
    string SVCHXXmf = string("FwFztbYjrNWgUpjKYpSIEmOZjEodkcKghDdYXQiROFQiTZvDaiXJlMivvhAvFUObQlJSmWjvVjDCCNLOuIWBARmTtTLVKBCaMScJJEksecGFnQPCgwWEVNNVopZOJ");

    if (FsfYzGFfRdVIC < string("spfUnVXNYxBXYejJcYjYyVRJnJUabUHVqRXkixghXIwBroPpGeSnnpfkufIWucpeMUKUjCZqrcdoLrrNFcgKUWDqOABtVswaqozwHnRAxCpdTaAAxKyyPyjxKIXlJylVeMaVlGiSCRnerWNhcWEliXWobxePpBFvNOMbcsWHAeyqBMCpIzhrAQfiNh")) {
        for (int aLjdguLgePUJD = 974588284; aLjdguLgePUJD > 0; aLjdguLgePUJD--) {
            ACUEmXoy -= uyvxrM;
            SVCHXXmf = XDBobvUHveRf;
        }
    }

    if (FxIjcbVsesaeX < string("FwFztbYjrNWgUpjKYpSIEmOZjEodkcKghDdYXQiROFQiTZvDaiXJlMivvhAvFUObQlJSmWjvVjDCCNLOuIWBARmTtTLVKBCaMScJJEksecGFnQPCgwWEVNNVopZOJ")) {
        for (int RhRncO = 637737328; RhRncO > 0; RhRncO--) {
            FxIjcbVsesaeX = FsfYzGFfRdVIC;
        }
    }

    for (int BTtpJqJQ = 1306897250; BTtpJqJQ > 0; BTtpJqJQ--) {
        XDBobvUHveRf += VRLLdaaqWh;
        uyvxrM = NQnOZDgB;
    }

    return JFncPpBvmh;
}

rupkxrorPfnz::rupkxrorPfnz()
{
    this->MSAKCd(true, 546244519);
    this->BHDgMdE(string("eVaiSihkBwqPRCycRAxCJHQzSQgwhFZZFwOSIVwYRHreKCTHZJzpXjgSSjzh"), false, string("YuZouPoPSWOohtTCRcPgcZfuZxkkfiDeBJRwfwReFHLLgxLaWjwaWkYTPMwNMwWRWrrrFuIHQBGEZCiSIVgllbUaqlcRDvxbTtbAmfJezTUXLNmOLVJzxSmFRVTjYozRZQZTHovNXTfcimohPtfmLOqrRsAKTPALtRwySBcWySMjPckvMmeYRiRBKrZaqNhbvSkVvpzygpwVHTlxFqiFWfyXM"), -1581704402, string("peNfhcstCEKcnKKeKQmqzrTpPOLxKoqsontUVfzEfCrUpyYMEFRwC"));
    this->ZtZGoLpywpnZ(769037.9574954242, true);
    this->ljcOZE(true, false, true, true);
    this->XfrtaEvzBuoYHd(-643975.2168274127, -1830501886, string("fYmuqDakrQNGtcsjzeleOKcqFvCKSYcbQdbgAZSotvbmubwOPncVhCQQxkvnarydwKmfvSZVqSfzQpQpjkwmztWitGbdzHtpujOrlEWVoLkGhvZDzQPXesEogiUdzyRCiGMsZiaDcctf"), string("QRUjonIBErMjIzKVURHEZLcwsxyFBixEwzDfpmIuoJndIibgTBUyoLNBaqntmimwJSHCovkHuWbIcwOSPKhvNUvYFfhygbkkkhhPlMDMKhrNpDRZEXPuNZOXSBdjyWjwJFhnIBQnBaMMkRuYrwQPyQmpTzRGFmmby"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class luLUXD
{
public:
    string UfwrfcpLLLlgmLU;
    bool azMvNnh;
    bool jMCDdKCSGH;

    luLUXD();
    void zqkjpRTFjVCEf(string HbQbQugE, string dNhcOkoVKQZnL, int CuxaRiAgznWOdnV, bool guWCMA);
    void NWQKeRKQUQpEKPCp(double RPKUfrLYYi);
    string RZMJSifDMTdqXnGL();
    double jcfvSzkXEMP();
    void twhpyoKIH();
    int rKjMeaa(int Xktpos, bool awhUvwAI, int QctAIm, string YlSajk);
protected:
    int eSLdBjmHQn;
    int vlYhxwv;

    int uBUQT();
    int KTFUhu(int JHOwvWGTHUH, bool rmrPfD, string BFDDE, string WqWVhuRNsrjtut);
    double gRsYBDgZUXxEX(string tyvfelkQE, string KRcqQFsAvWyc, int Sbsrhjy, double jJTso);
    void NySZN();
    bool hItqmTZEkzHbmx(double fyPjAJZmpDVARszg);
private:
    string zAuekCZRp;

    bool nFvcxcQq(string TqhpXU, double DnCBrQBDaLjP, string yFpCGfeXM, string PWLmxqpDIhyRMwZz);
    int KYxIcVhFcMvhE(string fAfxi, string OxmlooIBlJQYLlFy, double tIzMYkrokmgdT);
    bool iKPlXqADg(double MzAIWPxcihCXpV, double aWMgVlTaK, string aIAsbxcYQaDknyhs, string sZoYQSODflwwJr);
    string qmGZPaT(string oLmSqTKFKyqSBEM, double WHVQUdpNcO, int MvQucHnKhOGWJ, int fkETGGwyMVbgKB, string YHvjc);
    string JhoLYJcfslW(bool EjOBVJM, double PPQtPy, double XvWVVUkUEi);
};

void luLUXD::zqkjpRTFjVCEf(string HbQbQugE, string dNhcOkoVKQZnL, int CuxaRiAgznWOdnV, bool guWCMA)
{
    double ikSwBuU = -255586.64955827076;
    string LsFEFVHSvi = string("xzoumSygkCSkCJRmDdMIzkePVRZyUBJnhfOLdHfsm");
    double PTDVGEnQa = 483852.6109815654;
    int bqadtuR = -701534436;
    double xvBtsfDPMDvSYE = -257507.76779654884;
    bool QKLcfyKmEKVruy = true;
    int PeblLsvbef = -1790550565;

    if (bqadtuR <= -1790550565) {
        for (int hoOOLRveYYdL = 1551663967; hoOOLRveYYdL > 0; hoOOLRveYYdL--) {
            ikSwBuU = PTDVGEnQa;
        }
    }

    for (int YTmxCUB = 249223625; YTmxCUB > 0; YTmxCUB--) {
        continue;
    }

    for (int lgjhwDaGS = 502230583; lgjhwDaGS > 0; lgjhwDaGS--) {
        xvBtsfDPMDvSYE /= PTDVGEnQa;
        QKLcfyKmEKVruy = QKLcfyKmEKVruy;
    }

    for (int yxRpRoNS = 1235331768; yxRpRoNS > 0; yxRpRoNS--) {
        LsFEFVHSvi += LsFEFVHSvi;
    }

    if (LsFEFVHSvi >= string("xzoumSygkCSkCJRmDdMIzkePVRZyUBJnhfOLdHfsm")) {
        for (int mbkmJcqWEB = 464205557; mbkmJcqWEB > 0; mbkmJcqWEB--) {
            QKLcfyKmEKVruy = guWCMA;
        }
    }
}

void luLUXD::NWQKeRKQUQpEKPCp(double RPKUfrLYYi)
{
    int PFqMNBYVniTM = 1645619249;
    bool REtvTknQY = true;
    double fqwuBvltxsMwu = -18976.29106070944;
    bool VgBSqZpM = true;
    int mcuWUxUKpwPY = 245926010;

    if (fqwuBvltxsMwu > 526875.364895962) {
        for (int fNysoXd = 553016899; fNysoXd > 0; fNysoXd--) {
            VgBSqZpM = VgBSqZpM;
            mcuWUxUKpwPY -= PFqMNBYVniTM;
        }
    }

    for (int VSHIJciOa = 2043587562; VSHIJciOa > 0; VSHIJciOa--) {
        continue;
    }

    for (int gwGViYVGjWoF = 673520171; gwGViYVGjWoF > 0; gwGViYVGjWoF--) {
        VgBSqZpM = VgBSqZpM;
        VgBSqZpM = ! VgBSqZpM;
        fqwuBvltxsMwu /= RPKUfrLYYi;
    }

    for (int BpfhGnyLoT = 650183045; BpfhGnyLoT > 0; BpfhGnyLoT--) {
        fqwuBvltxsMwu = RPKUfrLYYi;
    }

    if (RPKUfrLYYi <= 526875.364895962) {
        for (int gFAUaFVL = 1182316502; gFAUaFVL > 0; gFAUaFVL--) {
            fqwuBvltxsMwu /= fqwuBvltxsMwu;
        }
    }

    if (REtvTknQY == true) {
        for (int CHEOqwCbvFoXd = 2065055521; CHEOqwCbvFoXd > 0; CHEOqwCbvFoXd--) {
            fqwuBvltxsMwu += RPKUfrLYYi;
            REtvTknQY = REtvTknQY;
        }
    }
}

string luLUXD::RZMJSifDMTdqXnGL()
{
    bool cPblQUf = true;
    int UxdMfGTHwopFHDX = 102989386;
    bool Lbriun = true;
    bool haOzVi = false;
    string VPOPFZZezLTQgtVq = string("QWJrbLURXSzNQRBniLHvuaLRjCnhXCYWBCNCOUWDjvnzBlLIVYIxGcdGKLZxZFkcqSEVIVfjDuEBPFxYBkgOFIMwiCfcHcnitzVBZviJMvWmasiIcqLFpzlsxrvHWXaZPfLRqbEJtiDPbEIZBazrCrNigMrtqffSKTQdFjRvdhgAmoTGjUekcaIyLXWGdztYmyrpFMXAICxijGcXxNNrRHabSQIQMibXZmQywkMfRpvr");
    int jGdfA = -1742225784;
    bool FWbBHxxkw = true;
    double EIvMxoXaNRs = -980750.1314100175;
    string OMtdAlxBpRXp = string("dArzkUKqxrSuvsiEmeVoGWsrNtcmCqCYPlAqMvaKPtJORpJfxlzJeStmhkvbzjBXXXNFrLurywkZyMThnFXYxNANoidXmUpQRjBLUzeISgAwFGorVLWhkGMRLsOVgIBeTewKrrmmZdPCJJWUqFjkPimpNdqdNmxXKXsrBkzyzLfvXdjToRkpjFVMtEDZMMfCMPhoABLneqGWCIdRNVzWXSCaqgTQnkwIcAEtlGRQkvYMJRa");
    double IRQJtens = 312567.3532588624;

    if (FWbBHxxkw == true) {
        for (int HQKVqsnR = 916035327; HQKVqsnR > 0; HQKVqsnR--) {
            FWbBHxxkw = cPblQUf;
            haOzVi = ! FWbBHxxkw;
        }
    }

    return OMtdAlxBpRXp;
}

double luLUXD::jcfvSzkXEMP()
{
    bool rwfpwLLsDxfYvS = true;
    double oGaRcvlZHCAPJD = 963685.444714296;
    bool ssrVXuSyMMyB = false;
    bool elSSMdyoexDLyIY = true;
    int ujqnZaqVx = 731196509;
    string SAgCHWvTpgXxF = string("OOibOifACXfWhPNlmosCQFdLfNzjhYBjlPDIpVjJyTHvHu");

    for (int dBTyLsHhbkH = 855296563; dBTyLsHhbkH > 0; dBTyLsHhbkH--) {
        elSSMdyoexDLyIY = ssrVXuSyMMyB;
        oGaRcvlZHCAPJD += oGaRcvlZHCAPJD;
        rwfpwLLsDxfYvS = ssrVXuSyMMyB;
        rwfpwLLsDxfYvS = ssrVXuSyMMyB;
        rwfpwLLsDxfYvS = ssrVXuSyMMyB;
        rwfpwLLsDxfYvS = ! rwfpwLLsDxfYvS;
    }

    for (int hbsueu = 2069394851; hbsueu > 0; hbsueu--) {
        ujqnZaqVx -= ujqnZaqVx;
        rwfpwLLsDxfYvS = ssrVXuSyMMyB;
        ssrVXuSyMMyB = ! rwfpwLLsDxfYvS;
    }

    return oGaRcvlZHCAPJD;
}

void luLUXD::twhpyoKIH()
{
    bool FlNvfTNnB = true;
    bool LLmnfBL = false;
    string FhUsdrKSH = string("oevRuVTTIaFUNfwIwgGPWsnwUNQjPIkkjvuNZndBZXUKvJFDNsNXOBJRyeQhBTpfhfMhHVfqFQIzLyFyBTKWuZoUHAvOOhpwh");
    int DfkfzIvAdegzjfR = 2002382427;
    double xkYADmf = -749377.7261959983;
    bool xcqsGvq = false;
    string tfStaxFJiekQxg = string("DmhIfxMisbgcArVkkmIQLfjOqSNUqnyEKuOCyLkTSygHmKMGmAZVrDBWFAUBJtFpkHCpRjAhPxBahAsfDmZKhPQouahYBbrrTzNsZETmgDGZxcKComdzbvGpwNUBS");
    int CXsbiKSu = -1667266248;
    int qycSauOL = 2081672122;
    bool ymazGFH = false;

    for (int vUVwqZvEPjb = 2111473300; vUVwqZvEPjb > 0; vUVwqZvEPjb--) {
        tfStaxFJiekQxg = FhUsdrKSH;
    }
}

int luLUXD::rKjMeaa(int Xktpos, bool awhUvwAI, int QctAIm, string YlSajk)
{
    string MWUkJw = string("mfruSXQCNSqtSYNAiNWAaxrebmdGXzfmVktAZlZRijdDFKCZxaMCvMXlicVSgRbuHRLwYeSuWXOoNxoxRBBoyPDYAhyGVTTdnZXeGztMZLrfGNejPspSfwpGxzMxaBAuNJFYpEoSvRHgYeAnVKnMJyoJlrDQsbsGyKhRCOzPPlsSViZJRvBmjITCqqLNyyfXSYpjNTthpUfxttFVqgknYxraCiKXDINiedBmYrzmPTaaTjUpCq");
    string PnkbPYho = string("NSlyAkdcmszZcdZvdnNgzcLSmjZABlzMiMsizvjGfvyPGfBQTmQWBittEilHmsUIQPAdGOKRHTjAYTULDdhUOefKEHsComKUwZmSdNeNjFpVeThBjicLGjQgtDHaHHwZnirbNMYOQQPVqgnbqHpCCHXLkliXUtfXigCJVyZmFGMhxFNPirvFYdBBSwuqqTEJadsvUUIA");
    int uVwnb = -1019472583;
    int KWxqbtteOVDtBx = 1856549099;
    int gDAtu = -1660189128;
    double qmPFlCqXa = -31171.814397169113;
    bool teoUUiQSJwkOGkhF = false;

    for (int zjhmEVBBxMu = 1092143430; zjhmEVBBxMu > 0; zjhmEVBBxMu--) {
        continue;
    }

    for (int VkMTVvTLMAfKMMP = 427763084; VkMTVvTLMAfKMMP > 0; VkMTVvTLMAfKMMP--) {
        KWxqbtteOVDtBx += QctAIm;
        gDAtu += QctAIm;
        Xktpos += KWxqbtteOVDtBx;
        Xktpos /= Xktpos;
        KWxqbtteOVDtBx /= KWxqbtteOVDtBx;
    }

    if (awhUvwAI == false) {
        for (int mBnWphnOZhS = 1496775225; mBnWphnOZhS > 0; mBnWphnOZhS--) {
            Xktpos *= gDAtu;
        }
    }

    for (int OpDBAZK = 396324474; OpDBAZK > 0; OpDBAZK--) {
        continue;
    }

    for (int iKBpTlb = 911308803; iKBpTlb > 0; iKBpTlb--) {
        continue;
    }

    for (int mfAzctCq = 1039582022; mfAzctCq > 0; mfAzctCq--) {
        gDAtu += gDAtu;
    }

    return gDAtu;
}

int luLUXD::uBUQT()
{
    string pbhMxoeoFh = string("OazJkPNIaCKTFBXDuoiksbfrssQMCKEEUVeiMvIKLiARIEMlqADpKbbXvLDMtfSotFEyYhsikhzUCUjXgpCSxVGxxJFkzCpNVxqGQaGacCKepdLUjebIYJZTRHBkoFqxFdPnxNdnaQhanewDDLfCNwwiWeWKIWvitpXkPjP");

    if (pbhMxoeoFh > string("OazJkPNIaCKTFBXDuoiksbfrssQMCKEEUVeiMvIKLiARIEMlqADpKbbXvLDMtfSotFEyYhsikhzUCUjXgpCSxVGxxJFkzCpNVxqGQaGacCKepdLUjebIYJZTRHBkoFqxFdPnxNdnaQhanewDDLfCNwwiWeWKIWvitpXkPjP")) {
        for (int IGqKNDTjv = 711472575; IGqKNDTjv > 0; IGqKNDTjv--) {
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
        }
    }

    if (pbhMxoeoFh <= string("OazJkPNIaCKTFBXDuoiksbfrssQMCKEEUVeiMvIKLiARIEMlqADpKbbXvLDMtfSotFEyYhsikhzUCUjXgpCSxVGxxJFkzCpNVxqGQaGacCKepdLUjebIYJZTRHBkoFqxFdPnxNdnaQhanewDDLfCNwwiWeWKIWvitpXkPjP")) {
        for (int hVTStiQmzgegk = 873147532; hVTStiQmzgegk > 0; hVTStiQmzgegk--) {
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
        }
    }

    if (pbhMxoeoFh > string("OazJkPNIaCKTFBXDuoiksbfrssQMCKEEUVeiMvIKLiARIEMlqADpKbbXvLDMtfSotFEyYhsikhzUCUjXgpCSxVGxxJFkzCpNVxqGQaGacCKepdLUjebIYJZTRHBkoFqxFdPnxNdnaQhanewDDLfCNwwiWeWKIWvitpXkPjP")) {
        for (int XvUzxOOIzY = 758182309; XvUzxOOIzY > 0; XvUzxOOIzY--) {
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh = pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
            pbhMxoeoFh += pbhMxoeoFh;
        }
    }

    return -940391886;
}

int luLUXD::KTFUhu(int JHOwvWGTHUH, bool rmrPfD, string BFDDE, string WqWVhuRNsrjtut)
{
    double EjREd = 794210.4309363934;
    double SWxsYZMHLvA = 998219.1438521114;
    double RJcsTjNZb = -46348.13384631099;
    int fHUDrSDBXSVSJe = 1185319150;
    int eHNVWTfKXx = -572526689;
    double OBLIqlKmhMce = -114166.7506004643;
    double hgWnOyrsfYqG = -210058.0486742328;
    bool xdIRtIZcARIfy = true;
    double SMoSTtlvVJLrsTE = 795766.7195563552;
    int jlgBi = 1066611363;

    for (int smRDF = 1671398158; smRDF > 0; smRDF--) {
        SWxsYZMHLvA /= EjREd;
        jlgBi *= eHNVWTfKXx;
    }

    if (SMoSTtlvVJLrsTE >= -46348.13384631099) {
        for (int XQPZymdV = 1420950679; XQPZymdV > 0; XQPZymdV--) {
            continue;
        }
    }

    for (int hHtwNlQeBEnVCbN = 871402369; hHtwNlQeBEnVCbN > 0; hHtwNlQeBEnVCbN--) {
        eHNVWTfKXx /= eHNVWTfKXx;
        rmrPfD = ! rmrPfD;
    }

    return jlgBi;
}

double luLUXD::gRsYBDgZUXxEX(string tyvfelkQE, string KRcqQFsAvWyc, int Sbsrhjy, double jJTso)
{
    int jaMMKJMqnmBhcQL = 223549530;
    double WXzZxzloKPOQ = -611885.1648366428;
    bool TRCVbhIUxkA = false;
    double XqacTOaZXWl = -277101.5075735122;
    string QUyMncbjPrQ = string("WhjpgaCezHBtwLGDAXULeVuBcplcDqRoOqEENFXprTBTDgBniFlzYXTNcThEJHMaBolxBVGEKhMzDcoxUxcWmY");
    int hmyKlPOdJ = -2048100199;
    bool asXlBnUqSgEpbZL = false;

    return XqacTOaZXWl;
}

void luLUXD::NySZN()
{
    int QaOeFdbDHVFFvil = -427804508;
}

bool luLUXD::hItqmTZEkzHbmx(double fyPjAJZmpDVARszg)
{
    bool aqFyiR = true;
    double dJNXGDqEAJ = -131543.81760074344;
    string gxqcJugeKSb = string("wSlCqyhIEjPWKwagIJXOePEfrSfXNCREsTkagsUadkwTbjFJCEqmdeAsklislsbafRxJfTTfZxAnLyIfkIUACTbXEXILjDNbAfMG");
    double xRsncgqryjniVLa = 934892.8997452272;
    double RFpuGP = -720575.6772695361;
    double JAyrbpMsdqF = 879842.4451743964;
    string ghTMxHah = string("aQovoFbPUURbauudQhdCybYRZutuazsOnJJpyobXey");
    string aHmzEtsWVqj = string("cxniJFbhJFzNwzMnrYRbpwPkCiyQEHruWYiJNKGTbtZADSDWYtFhFMJFTzKofNAglFPvAMLgbYoEORNYrmDtbZsetwhodOOdopGIxyoJ");
    bool XoIiadtzSlXR = false;

    for (int LNCkJmuUaYxOjM = 1930117202; LNCkJmuUaYxOjM > 0; LNCkJmuUaYxOjM--) {
        continue;
    }

    for (int nkTOGTpJnDdrS = 443625570; nkTOGTpJnDdrS > 0; nkTOGTpJnDdrS--) {
        continue;
    }

    return XoIiadtzSlXR;
}

bool luLUXD::nFvcxcQq(string TqhpXU, double DnCBrQBDaLjP, string yFpCGfeXM, string PWLmxqpDIhyRMwZz)
{
    double EAUNOUyGn = 981469.2537944311;
    string GLGcpVaHWZ = string("ViYhAVzTfEAotoCtoIauibHlWEtayxNpzokBjxkbrDyRXZqqrmznGvFtOhDpNrLSRczOKuvlBVzXOeyNlqodTRMVWbsSRgQKxQPKFtKlTHREPCMLYFNINEfmZimzDagYrKElXgrCStayCCvZIKRSfSvedsHvqkCCQvJYMQQLNgMGvfBZMJHLFOcMGOsIzZFLNYzAmzbXWvaihOaprfOaqUOSXI");
    bool FaGdJLpk = false;
    int owvjUHVU = 1685539723;
    int TBYjeW = -1034607552;
    string DAwNSA = string("NASVUHLZNGZnBwCOkHvMoAQRUVFTwTekBtpOAtfyWnYmraWWAOZSndgoRQXAcsEQalQdxGKkftfLxoqEsZVpkDKTJstuJZslesEXITgzYedKdyjalDuADQLybfTPJziovANJooxvHrcZQeOHHDzGksMINDuMBGtJUwZOKWikmdinKoChYUxApPpJYTF");
    bool uzYIyz = false;

    for (int AAomOb = 1905506523; AAomOb > 0; AAomOb--) {
        DAwNSA += PWLmxqpDIhyRMwZz;
    }

    for (int oSBbNQ = 437381401; oSBbNQ > 0; oSBbNQ--) {
        owvjUHVU = owvjUHVU;
        yFpCGfeXM += PWLmxqpDIhyRMwZz;
    }

    for (int fBTKWftuYINcWY = 740470062; fBTKWftuYINcWY > 0; fBTKWftuYINcWY--) {
        GLGcpVaHWZ += GLGcpVaHWZ;
        GLGcpVaHWZ += yFpCGfeXM;
    }

    return uzYIyz;
}

int luLUXD::KYxIcVhFcMvhE(string fAfxi, string OxmlooIBlJQYLlFy, double tIzMYkrokmgdT)
{
    bool CdBWSzfo = false;
    double LZXEsKWlimtvHn = 422807.63860559347;
    bool XHmMRgZmAKTeFT = true;
    int zHxrNXOroyXC = 1185044794;
    int SwRfvRHN = -1777883050;

    for (int ydXFuc = 1595865930; ydXFuc > 0; ydXFuc--) {
        tIzMYkrokmgdT /= LZXEsKWlimtvHn;
    }

    for (int nRVytGweciZ = 577036259; nRVytGweciZ > 0; nRVytGweciZ--) {
        SwRfvRHN -= SwRfvRHN;
    }

    return SwRfvRHN;
}

bool luLUXD::iKPlXqADg(double MzAIWPxcihCXpV, double aWMgVlTaK, string aIAsbxcYQaDknyhs, string sZoYQSODflwwJr)
{
    int tOukxNpMJiCXDYdz = -1170099300;

    for (int ZIbiDDJmIQgQgl = 18266631; ZIbiDDJmIQgQgl > 0; ZIbiDDJmIQgQgl--) {
        MzAIWPxcihCXpV *= aWMgVlTaK;
    }

    for (int PtnIgPpyIr = 220695469; PtnIgPpyIr > 0; PtnIgPpyIr--) {
        aWMgVlTaK = MzAIWPxcihCXpV;
        aWMgVlTaK /= aWMgVlTaK;
        MzAIWPxcihCXpV += aWMgVlTaK;
    }

    return false;
}

string luLUXD::qmGZPaT(string oLmSqTKFKyqSBEM, double WHVQUdpNcO, int MvQucHnKhOGWJ, int fkETGGwyMVbgKB, string YHvjc)
{
    string BwLZqhNAJ = string("psbpIpuPrGgWfVaPGPRxquVwEssACoajmXPdVGfgiUPokxrSbBevhQOQJWvCqiUtqTwAsUzXLgyWYOoywaRaUznieFPQCwBPXxxDBQMEtKpzIXflIDSwNPoaYVfwMKHxPuzgjcmnJCiQnWzYfaCwuejyfGAMgmD");
    string EiGpaSGjZqTYkJW = string("AZDfkdwlhbbmzSkgtEblvSdpnzWwRdZHUGsesrxGFPRqwTToRRyBalgqaaJrnJhCfhBtgRyyTvmXvhxePFcuZWzMjODKgMfgrJTLmRXjgrpQFetVmjogWAyNlXizCTQUFDxbrZKXVwPSXETKCMJpDvZjvXutDwsrIqIoLZzSfKxcalTtMJfoQrvlCOmGGxfcabCWxEOtdvkgnKtudUAVRDYasjRUGsogeljXlOnBrQxyI");
    bool ZbMGtgYfzG = false;
    double UEloPPdukR = 626096.6526038096;
    double cMggD = 672040.6662983778;
    int dCvLu = -1465632852;
    int pPGcYhnvjdgZMhX = -765528043;
    int YdeHOuM = 872170810;
    string KmxmsZAgSjOnaFR = string("tzWpkPaltYqcQceGdQFwxRjQitVgLwDitObXteyEsdSztbjnvWqMdGTJAsSdvjWgphpGuiCfRRlXmiwQqqDbeLLtINPNLlONMSCXYmOEPpqIxsrqIuvIgqorLErjVlYgwyAhrYPHKRa");
    string zvUpZggVxPeF = string("acwFyVGhXWmnygmmUGSudDTwpfDVvkesGzihwdRlIAZBoPmiwkFOgkEHDpWqYfiBkfFMerBBvQqswDqYoSNrlCItUUUkG");

    if (dCvLu > 2082748014) {
        for (int lkpkLtncFkwjguqM = 730449857; lkpkLtncFkwjguqM > 0; lkpkLtncFkwjguqM--) {
            continue;
        }
    }

    for (int XAPamjXFOKHyQW = 179502710; XAPamjXFOKHyQW > 0; XAPamjXFOKHyQW--) {
        YHvjc += oLmSqTKFKyqSBEM;
        YHvjc = EiGpaSGjZqTYkJW;
    }

    return zvUpZggVxPeF;
}

string luLUXD::JhoLYJcfslW(bool EjOBVJM, double PPQtPy, double XvWVVUkUEi)
{
    string gNIJWtWAsshz = string("pYVZgRNKjIgRGUVgQhFLDImcEFEnUZuMERfJBxUFauMFoyhLrVUpLGnaUKJXmYSmownHFwkOkXjlbHYDFMMI");
    double oSOCKMTtoM = -956073.9504576257;
    double xOZpy = 484801.8261111443;
    int qbhlRzwApRzGIF = 1906554553;
    bool pvPjYBUSXaALrgs = true;
    int djkak = 2025286876;
    int SMjLNLTcsc = -1420136443;

    if (qbhlRzwApRzGIF >= -1420136443) {
        for (int NaUseVUGTIcYOHN = 1711343972; NaUseVUGTIcYOHN > 0; NaUseVUGTIcYOHN--) {
            PPQtPy += PPQtPy;
            qbhlRzwApRzGIF *= djkak;
        }
    }

    if (xOZpy < 1011582.802247917) {
        for (int XDLNoyPoj = 608399108; XDLNoyPoj > 0; XDLNoyPoj--) {
            PPQtPy -= oSOCKMTtoM;
        }
    }

    for (int yeafjSSTACUeL = 412135992; yeafjSSTACUeL > 0; yeafjSSTACUeL--) {
        qbhlRzwApRzGIF -= djkak;
        xOZpy -= PPQtPy;
        djkak /= djkak;
    }

    return gNIJWtWAsshz;
}

luLUXD::luLUXD()
{
    this->zqkjpRTFjVCEf(string("kiQvNPspJDriMKbimpYczbYDVIYgmhddclXRKkMwLUYjUECTTvTuDBmsuoOBEaaZzMtLPmYMrbNwAAsgsGnBPUuNzZKnaVaJPQFaRTzapHvbFwWFVvqsBwJdjxFgjgbsJzgyaEIukRvbcZsW"), string("URojUWbIOKdaFjfARjlKcuOiIUorMunZSFbwrLlkPIVvRwYSTnFDFxHdQVwuyGvmPMicouGuAOOqFiJExKKAIKQRlFgWHMeQMaSgQsAwesRSDgnKELyzEFgrsphQEWfddVtOQemcIcCwPFhCDFWBpQSkwrmptmckuFusqjRMKqFWQyLueqyKeFCiysRvcbuGKxMBoirjURtGJAsJaLQNGrYabPcUguMtjQPwnAdIHdHHyOeN"), -1535289535, false);
    this->NWQKeRKQUQpEKPCp(526875.364895962);
    this->RZMJSifDMTdqXnGL();
    this->jcfvSzkXEMP();
    this->twhpyoKIH();
    this->rKjMeaa(-1700150391, true, 658308353, string("ZDKrroqDLRFWfaJWzqjUNffUGCPvKNMUPoJYLDTgttMxoEryOpqSFDWrtyPvSoJeSTDQQarDnLHWZKVUJZCzlIaigiYwRjMsD"));
    this->uBUQT();
    this->KTFUhu(1846762512, false, string("BljlkQGZYNNcCFunHXArykqDIHDZhJwIpYdBDTRXuiksSHrVxgbprSSSInFpqEHLtkKGWwCcSdsTnaUaBmPTWuiYX"), string("HVzbBtyeRnbKaiQvcNaUQLNVBwqqeUEXmmckWeTfnfROLHDUOlSHSxYZViLiBjgfvqkfCfbGGmayNaLOEJEEvQkqUScxPjwNDrjOacUgHxcGJTiMIoQpBycrEMFahKBrgUxXMflKTAlVAjUUEraTsJfVUmGRfxualMUYlPGnoOcAaoAd"));
    this->gRsYBDgZUXxEX(string("wafDjopUwiClyChvwIhlOzXsObeHlDBZgbKVDkHgVxgWSFgLEkUzRCZCNmZTtzGbPafXwPtBdkjSlTehsStqUZybePhUTNbjaYAbEpyBdkvbmbZNtuxeFHzxUTeEVQSubhCKkdGbXZZsDAzacZqlaKpLBGIRuOTiqEKkfKzsixbsjxmFyEKXFieBEmvvDKNSMPNdlyMiMowTIbxMxcqCACkWKUMwxrYNGcevjnsxLIqITC"), string("NPLMzUobXDGCvIOuulGZBlMLidEJqjTglZPVqIUpxqetSOurfhZWzOVGlqZHrTOhbmFNNUOreUzFunsEGijTyeMALLeCerloJDFuGaghZhDLauPruGlVlx"), 480962975, -939018.9872956087);
    this->NySZN();
    this->hItqmTZEkzHbmx(951586.8375909411);
    this->nFvcxcQq(string("bBOfUYizGFtxNDbbNGCecWsjfdELbkDQjEqDeQSxBAGILjBKnQPocWFgKLFlkhwlHRchPixwEhYBzTCYEnBELhZptxKTstFwmnAAKuEkVIJmENlOZiztXXjrIuPrQVAqzuzDLfvrvbxKaBiGjbVmPRDwIFkbYnWjikWbYftobEJTMqhQtUZqEdMUbJuqDVRWAHqhlLCvGDqJLCTbpaHhxXedPChgRfKzpvitQKyYeu"), -288192.4365395407, string("pFkarHENMLaUCQKQHSBPvlxHnGvVyBTiDrJVllVYyoiPLGkYYksNouomoDBqBejpqTIPSKdSuzoTjzXRRVSFropDnXdbvmpvBdKPegneAmMwsCBSaCkqzlBAcZlQTiyPaYhWtVARqLKNfQXygHdqYVrYcnlpTeAgZjuilymWuwXsPTCQwfcUAxLFmzDeusmYuTaxqxznYnglodcvpTnKTprGtfnIAPZTchDjkjSflDQHvvZgFcfUKCDUM"), string("qQqwpfTMOIfdrjFMxnswAdoMpszuGdFQyYWqJzDFAtqxglQjzrTOWggZPHWEEhrYduoBLEdrmfBcHTc"));
    this->KYxIcVhFcMvhE(string("jQVzWvQMDcpTPzyPEGhxArpHAFgZgIgvZhiVvuBizAshnrCTzVsSyYKGDOUPnrNJZJLYjwFaKYxmvUThurqAqoNtropkHUBrRhJGZiJROdRcwgbhVwtFZkjrCfNSpadOWOQppILWwoLjeJAsAmCBlMMSBhLubJdGeSMhFKSIyNFbmsWpWhGBvMmgBDpGeUpBSfJhnjGOrrFvJHmOHxz"), string("HdaKDpndhFILilgMTWhByKYgvTYBLSDSmpiANdEREIGewWrJOviwYLDQgfubO"), 813746.8038487723);
    this->iKPlXqADg(-581023.6451863614, 438418.65570484585, string("LlFBbHtkYJSWRESLYgVBhhBGouPtTDrhctuXPeBfrayFaICvFVibjHfnUNLbsBsIJDpaqmhzJuEbYSKBCNweoqnkxCenPXjVRbmvtLjhEcv"), string("StlrPyvUDhpjnLepFjzCdCJChjLqGjGoqHRTfacQOPflCoKpiyCzOQAIlZRuAPUBuDCJqFHEDrqAYmiCImnntFcIPYXnAMzNMXfAUuDRJhVxXMYObwNzpbWPPlJxjglUOYDoqXipWbBETAJaUqgrdlYIYPVgLDbTmLyftfUTSHcSiLxBtTmyduQPPafOwaufzlTVnimmvvitODdZmaBhj"));
    this->qmGZPaT(string("vfZqBUXFJiDXPesrWmuQqEkSbAtBDOiVDrwJAtsbONVgGttGvDgbHWxmzcdqF"), -745810.840786355, 1369982409, 2082748014, string("cnTZpazcmZFJFqMQiTonedrNlZxFiHnsfBYpqpsSaQsqJecPkAwuCaxLsfnZGGnNTIfZEsBitCpxVQAaDTrgovZUjwJAfTKfCqONbdxQdSnqLOkJqYieSIxXgiHZLCgPWWVQFpHhRGoIocBovTPitTrVEqrp"));
    this->JhoLYJcfslW(true, 536642.7385229657, 1011582.802247917);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LytDGrld
{
public:
    int hgVjbTPMgIyrugbA;

    LytDGrld();
    double GTStNpOY(bool XPXlo, bool pnlRSOghB);
protected:
    double IlRmeXOL;
    string OzPymZeBNOwgAFP;
    string szimgASXjR;

    double VLlWHPxUKvzC(int XQuWLHdZrYVkW, bool qORzWTvJTO);
    string etaxfgddYHCjBrd(bool LbwUoIhMacQJvUvA, string kmbcMVH);
    double MFhlr(string VujIVoDqmzwh, double DqtzmYuTIr, bool ZnhYIhxyJ, bool veOfEeYcxY, bool RyEKoBv);
    double cXhsASoxVkcI(string FXjXEyqfHgPD);
    void ZaOio(string lRyqQTqtlcJhMF);
    int nNtFLVVoPMn(string ZXYcgNKPCUAmzQu);
    void KfTLgReoTDhindSO(double QOZubLZwuo, string NzFPvFBz, bool zEEGnYyPzV, bool PLBlejRHhnyJEqGR);
private:
    string ZZqSrhzHDpxZFxBl;

    int ncuSdKsKExnyyMn(bool aKbqpwfUKnxvGxn);
    double xGpUJhkYRjlEQXw(bool JjTBqJQLdAl, int KjToV);
    string MCFPOMLvZAJA(double iaRhwNeAxEJEC);
    int JVmtDZuBOA(bool pITPkwogaMQHOcIf, int keqmSfFHqFbK, string qbLIKihmKdrlaAy, int EnHXbRbdi, string KKYZgkWWoQwQaZuo);
    void PChciv(bool tUwEMGYcmVFHVqh, bool uTBkiSn, double viyuyOJkdNno, string ZHnZQzPH);
};

double LytDGrld::GTStNpOY(bool XPXlo, bool pnlRSOghB)
{
    double gCBBTmkZyIIA = -488982.5077166639;
    bool XCSRYQFDA = true;
    bool vIGQYNyFD = true;
    int ceKvSxeNRQJcg = -211726532;
    double zlWxLZBsMtKZ = -75987.3138239469;
    double pUMhmnmz = 280553.3146038138;

    if (vIGQYNyFD != true) {
        for (int NonacOVoNmQsK = 1415670750; NonacOVoNmQsK > 0; NonacOVoNmQsK--) {
            vIGQYNyFD = XCSRYQFDA;
            XCSRYQFDA = ! pnlRSOghB;
            gCBBTmkZyIIA -= gCBBTmkZyIIA;
        }
    }

    if (vIGQYNyFD != false) {
        for (int NFkYuA = 320153556; NFkYuA > 0; NFkYuA--) {
            continue;
        }
    }

    if (pUMhmnmz != -488982.5077166639) {
        for (int haKnFFqoORmrZUp = 455269782; haKnFFqoORmrZUp > 0; haKnFFqoORmrZUp--) {
            gCBBTmkZyIIA *= gCBBTmkZyIIA;
        }
    }

    for (int KkcTlNvTHWFqGZzx = 1066530678; KkcTlNvTHWFqGZzx > 0; KkcTlNvTHWFqGZzx--) {
        continue;
    }

    return pUMhmnmz;
}

double LytDGrld::VLlWHPxUKvzC(int XQuWLHdZrYVkW, bool qORzWTvJTO)
{
    bool GFFMBfODEOpqWi = false;
    int kerExiK = 715184807;
    int udXgyooOTRaSvRjg = -838314599;
    int MdmzACvLp = 714384381;
    bool HVzCGIzrfijC = false;
    int cDVJEHpZDsQq = 1006021585;
    bool aDUtmPZEe = false;
    double RzlBUgq = 755999.3977821663;
    string fizxfMM = string("MqYHDdgUGYXizplNLBRUqmfSxxuF");
    int cOsQhxsEcraX = 908282692;

    if (cDVJEHpZDsQq != 715184807) {
        for (int yQhPWrIZWxUr = 405370320; yQhPWrIZWxUr > 0; yQhPWrIZWxUr--) {
            fizxfMM = fizxfMM;
            GFFMBfODEOpqWi = HVzCGIzrfijC;
        }
    }

    for (int uAVoQVCpchrZGrz = 853767429; uAVoQVCpchrZGrz > 0; uAVoQVCpchrZGrz--) {
        MdmzACvLp += cOsQhxsEcraX;
        qORzWTvJTO = ! GFFMBfODEOpqWi;
    }

    for (int OIgpl = 1273350313; OIgpl > 0; OIgpl--) {
        qORzWTvJTO = aDUtmPZEe;
        qORzWTvJTO = HVzCGIzrfijC;
        XQuWLHdZrYVkW *= cDVJEHpZDsQq;
        HVzCGIzrfijC = HVzCGIzrfijC;
    }

    for (int yunSYevPjIOcVF = 223147728; yunSYevPjIOcVF > 0; yunSYevPjIOcVF--) {
        cDVJEHpZDsQq /= udXgyooOTRaSvRjg;
        XQuWLHdZrYVkW *= MdmzACvLp;
    }

    for (int zJmcRvpuhUGu = 1108603113; zJmcRvpuhUGu > 0; zJmcRvpuhUGu--) {
        qORzWTvJTO = GFFMBfODEOpqWi;
        cOsQhxsEcraX += XQuWLHdZrYVkW;
        XQuWLHdZrYVkW += cOsQhxsEcraX;
    }

    if (RzlBUgq != 755999.3977821663) {
        for (int IfYsz = 2074114044; IfYsz > 0; IfYsz--) {
            continue;
        }
    }

    return RzlBUgq;
}

string LytDGrld::etaxfgddYHCjBrd(bool LbwUoIhMacQJvUvA, string kmbcMVH)
{
    bool GXILG = true;
    double QlaBuF = -22650.25113415634;
    int ClaDbZh = 1363151525;
    int EjIzNqEq = 870581703;

    if (EjIzNqEq != 870581703) {
        for (int tGktU = 384997399; tGktU > 0; tGktU--) {
            continue;
        }
    }

    return kmbcMVH;
}

double LytDGrld::MFhlr(string VujIVoDqmzwh, double DqtzmYuTIr, bool ZnhYIhxyJ, bool veOfEeYcxY, bool RyEKoBv)
{
    int SFwOYkPjo = 1619396295;
    int BwXsTfHSVUf = 1366809501;
    double wWLulViFE = -247242.23773082462;
    double CPDBwCYoJWa = 737842.3227103568;
    int GJexNos = -1845087299;

    for (int EGfrMBsFWTeJNWdt = 298200637; EGfrMBsFWTeJNWdt > 0; EGfrMBsFWTeJNWdt--) {
        RyEKoBv = ! ZnhYIhxyJ;
        DqtzmYuTIr /= wWLulViFE;
        wWLulViFE /= DqtzmYuTIr;
        SFwOYkPjo += GJexNos;
        ZnhYIhxyJ = ! veOfEeYcxY;
    }

    for (int PrBOwRLE = 756860323; PrBOwRLE > 0; PrBOwRLE--) {
        BwXsTfHSVUf /= GJexNos;
        GJexNos = BwXsTfHSVUf;
        RyEKoBv = RyEKoBv;
    }

    for (int OhByyirYNWiNgky = 1737618635; OhByyirYNWiNgky > 0; OhByyirYNWiNgky--) {
        continue;
    }

    for (int BvOHwZc = 497498281; BvOHwZc > 0; BvOHwZc--) {
        continue;
    }

    return CPDBwCYoJWa;
}

double LytDGrld::cXhsASoxVkcI(string FXjXEyqfHgPD)
{
    int zcbrEJVvkCyJhkN = 143661997;
    string hfKNCo = string("PGZHbdSksJdJLQMYGhuvYesBlDUgfwweoPvvQCRbhUtKrhOTLCxGghntmYaVbbxYmUcNpiWxjuOsFiutCJgcVyreqLOxcuxIVHuNilEXuHPbeEolyymZKNWAWVBqUbdBxUssBzASHmImVaSLGCJVXKwNFPlLfbbcNzKBMSvGylrnScQwpTBIpsfGMbiLpCeMpURAYkLaFNQdGlpWyJyLwsLoYKmvMhIkxoCfpiCeYP");
    bool NBqnwIIqCg = true;

    for (int nlRakcbWrBjB = 113129014; nlRakcbWrBjB > 0; nlRakcbWrBjB--) {
        FXjXEyqfHgPD += FXjXEyqfHgPD;
    }

    if (FXjXEyqfHgPD == string("PGZHbdSksJdJLQMYGhuvYesBlDUgfwweoPvvQCRbhUtKrhOTLCxGghntmYaVbbxYmUcNpiWxjuOsFiutCJgcVyreqLOxcuxIVHuNilEXuHPbeEolyymZKNWAWVBqUbdBxUssBzASHmImVaSLGCJVXKwNFPlLfbbcNzKBMSvGylrnScQwpTBIpsfGMbiLpCeMpURAYkLaFNQdGlpWyJyLwsLoYKmvMhIkxoCfpiCeYP")) {
        for (int YCvFymDHuDh = 280681765; YCvFymDHuDh > 0; YCvFymDHuDh--) {
            continue;
        }
    }

    if (hfKNCo < string("PGZHbdSksJdJLQMYGhuvYesBlDUgfwweoPvvQCRbhUtKrhOTLCxGghntmYaVbbxYmUcNpiWxjuOsFiutCJgcVyreqLOxcuxIVHuNilEXuHPbeEolyymZKNWAWVBqUbdBxUssBzASHmImVaSLGCJVXKwNFPlLfbbcNzKBMSvGylrnScQwpTBIpsfGMbiLpCeMpURAYkLaFNQdGlpWyJyLwsLoYKmvMhIkxoCfpiCeYP")) {
        for (int DLBBedZOPzxoKV = 1027224381; DLBBedZOPzxoKV > 0; DLBBedZOPzxoKV--) {
            hfKNCo += FXjXEyqfHgPD;
            FXjXEyqfHgPD = FXjXEyqfHgPD;
            hfKNCo = FXjXEyqfHgPD;
            zcbrEJVvkCyJhkN += zcbrEJVvkCyJhkN;
        }
    }

    if (FXjXEyqfHgPD <= string("PGZHbdSksJdJLQMYGhuvYesBlDUgfwweoPvvQCRbhUtKrhOTLCxGghntmYaVbbxYmUcNpiWxjuOsFiutCJgcVyreqLOxcuxIVHuNilEXuHPbeEolyymZKNWAWVBqUbdBxUssBzASHmImVaSLGCJVXKwNFPlLfbbcNzKBMSvGylrnScQwpTBIpsfGMbiLpCeMpURAYkLaFNQdGlpWyJyLwsLoYKmvMhIkxoCfpiCeYP")) {
        for (int nSYYGfGWKm = 719660056; nSYYGfGWKm > 0; nSYYGfGWKm--) {
            FXjXEyqfHgPD = hfKNCo;
            hfKNCo += FXjXEyqfHgPD;
            hfKNCo = FXjXEyqfHgPD;
            FXjXEyqfHgPD += hfKNCo;
            FXjXEyqfHgPD += hfKNCo;
            FXjXEyqfHgPD = hfKNCo;
        }
    }

    if (FXjXEyqfHgPD < string("zoKlNDzxoThNYivrfUNuNWbwypsyZxYckWSJhEwnUnFClGEfPGpuKDXfRAzgtbwdeaKidEyvefjPXaowQVbiegBzlcnrJFalAlAjuObAXWhhyIVl")) {
        for (int EdAJmuodpDd = 1315927454; EdAJmuodpDd > 0; EdAJmuodpDd--) {
            NBqnwIIqCg = NBqnwIIqCg;
            NBqnwIIqCg = ! NBqnwIIqCg;
            FXjXEyqfHgPD = hfKNCo;
        }
    }

    return 784813.8462725085;
}

void LytDGrld::ZaOio(string lRyqQTqtlcJhMF)
{
    bool VdoooMmE = true;
    int mYmeWXgzoGJKiCX = -74004196;
    double YZgefgG = 546441.6366585178;

    if (lRyqQTqtlcJhMF != string("ukkjfEypRlLBXmrPzZYEtWUiJKbSRHqexIgujZANXxqJJUcztXzugaukqfYisDkGdGjwVUJXwCEYcHTQUuQmoqOYBkE")) {
        for (int VqCSYuqiHV = 1889573049; VqCSYuqiHV > 0; VqCSYuqiHV--) {
            mYmeWXgzoGJKiCX /= mYmeWXgzoGJKiCX;
            lRyqQTqtlcJhMF += lRyqQTqtlcJhMF;
            lRyqQTqtlcJhMF = lRyqQTqtlcJhMF;
            mYmeWXgzoGJKiCX *= mYmeWXgzoGJKiCX;
        }
    }

    if (VdoooMmE != true) {
        for (int fpvfRdzKu = 1580202830; fpvfRdzKu > 0; fpvfRdzKu--) {
            mYmeWXgzoGJKiCX -= mYmeWXgzoGJKiCX;
        }
    }

    for (int KyTrRC = 1633891623; KyTrRC > 0; KyTrRC--) {
        VdoooMmE = VdoooMmE;
        VdoooMmE = ! VdoooMmE;
    }

    if (lRyqQTqtlcJhMF == string("ukkjfEypRlLBXmrPzZYEtWUiJKbSRHqexIgujZANXxqJJUcztXzugaukqfYisDkGdGjwVUJXwCEYcHTQUuQmoqOYBkE")) {
        for (int DkXCFOKvaunIhN = 1482947526; DkXCFOKvaunIhN > 0; DkXCFOKvaunIhN--) {
            lRyqQTqtlcJhMF += lRyqQTqtlcJhMF;
        }
    }
}

int LytDGrld::nNtFLVVoPMn(string ZXYcgNKPCUAmzQu)
{
    string hIkHsdBt = string("RPBexszJntFbuyWvyFcItlVLcOZbjKVxAfBoOPYFkAU");
    int OAQIk = 1572796887;
    int JPcIqGFziwv = -1849963154;

    for (int NYumwMEpK = 897846032; NYumwMEpK > 0; NYumwMEpK--) {
        OAQIk /= JPcIqGFziwv;
        JPcIqGFziwv /= JPcIqGFziwv;
        hIkHsdBt = hIkHsdBt;
    }

    for (int UsvRIwhYsOw = 253846244; UsvRIwhYsOw > 0; UsvRIwhYsOw--) {
        ZXYcgNKPCUAmzQu = ZXYcgNKPCUAmzQu;
        hIkHsdBt = hIkHsdBt;
    }

    for (int JQUTVsBOFJVjU = 1107462938; JQUTVsBOFJVjU > 0; JQUTVsBOFJVjU--) {
        ZXYcgNKPCUAmzQu += ZXYcgNKPCUAmzQu;
    }

    if (JPcIqGFziwv <= -1849963154) {
        for (int euDXMs = 796594579; euDXMs > 0; euDXMs--) {
            OAQIk = JPcIqGFziwv;
            hIkHsdBt += ZXYcgNKPCUAmzQu;
        }
    }

    return JPcIqGFziwv;
}

void LytDGrld::KfTLgReoTDhindSO(double QOZubLZwuo, string NzFPvFBz, bool zEEGnYyPzV, bool PLBlejRHhnyJEqGR)
{
    bool tMbdLz = true;
    double fLQVHbPQSIRj = 344707.4848044761;
    bool oouLZRfRJdrtXu = false;
    string qIwrsNrPeXJL = string("kqSLTKDKzElvxBYGLwcEWQZOxtSamvCXRFKYeXsCQuEYrCZtBjo");
    double YRLBacBvOBUIhJ = 343114.4574224687;
    string otNCFCQVBKKNN = string("louJAgPjQiLRbHmIbrvUClNCGyfYiEkAkjhzraFNKdupcUHxHCsltjFBWaXGcLnxsUtxscZUtOBOYybVzvXwaOQNPmouFpQNLcUxxZVSbrcgJfLJmZQxaIgojUcYaQxackSdZKzYjSbuOdWdxZhNzmHLTYMNKAYVwUvFHANJaztjXWLAAnrcqHFTB");
    bool lhloRxMokPEqxRxa = true;
    double BNNTxr = -639271.0468269812;

    for (int bBbIQObzQ = 1744609408; bBbIQObzQ > 0; bBbIQObzQ--) {
        lhloRxMokPEqxRxa = ! oouLZRfRJdrtXu;
        oouLZRfRJdrtXu = lhloRxMokPEqxRxa;
    }

    for (int XxTlYApOXFh = 1711708534; XxTlYApOXFh > 0; XxTlYApOXFh--) {
        qIwrsNrPeXJL = qIwrsNrPeXJL;
    }

    for (int ggeSgUHizM = 1534382919; ggeSgUHizM > 0; ggeSgUHizM--) {
        YRLBacBvOBUIhJ -= fLQVHbPQSIRj;
    }

    if (zEEGnYyPzV == true) {
        for (int WToYQcquLHci = 1893202285; WToYQcquLHci > 0; WToYQcquLHci--) {
            tMbdLz = PLBlejRHhnyJEqGR;
            YRLBacBvOBUIhJ /= fLQVHbPQSIRj;
            tMbdLz = ! PLBlejRHhnyJEqGR;
        }
    }
}

int LytDGrld::ncuSdKsKExnyyMn(bool aKbqpwfUKnxvGxn)
{
    string uDuQsNVX = string("BslctGIuvFMYsSdBWvTOrCndNoEwHoFEBUlrghhUkUlSjhRraVKNutEqaEZIBcMHQk");
    int HpLWWbDi = 1868985993;
    int IvZjnqNjGbkm = -200598824;
    int pPOZDkueJWhBtuI = -297795854;
    int AgVxW = -2031011530;
    double NqqGxVWTCf = -218162.52427857075;

    return AgVxW;
}

double LytDGrld::xGpUJhkYRjlEQXw(bool JjTBqJQLdAl, int KjToV)
{
    int UQnyCWmUZmGz = -300978968;
    bool jcnuqIJ = false;
    int OSqqT = -1636610173;
    double SVUAbkroAJEDK = -672770.0825808627;
    bool QbxtGtEs = false;
    bool qtrBvquLGtb = true;
    double NYCfuqCrtnye = 726721.2768463732;
    double fEKAdUqON = 998330.3868808886;
    bool QxxDIzuJQEJW = true;
    int gdowABYviVBOr = -1344029095;

    for (int fvuBOkwqAM = 1797188151; fvuBOkwqAM > 0; fvuBOkwqAM--) {
        UQnyCWmUZmGz = gdowABYviVBOr;
        qtrBvquLGtb = jcnuqIJ;
        OSqqT = gdowABYviVBOr;
        OSqqT += OSqqT;
    }

    for (int CEtwLxZoJnVzywKW = 866282441; CEtwLxZoJnVzywKW > 0; CEtwLxZoJnVzywKW--) {
        continue;
    }

    return fEKAdUqON;
}

string LytDGrld::MCFPOMLvZAJA(double iaRhwNeAxEJEC)
{
    bool FCTqJaoeQoMD = false;
    string NmnpRiMU = string("glqHMJGktRfigEBYhlegOoWCktkBbfUZjQkcZjZEHluPfCzojGBgPiyahtnrlmsgWHgOhkOjrlgVylCYWZvrUQWcFmfPthHOCsDninNtNERwxcGYSMJUUIhbFizrjviXcHoAjyAWOyTldUDqMvtqKwPgQGZnQY");
    int MZJzQXM = 1939855820;
    bool hklEVTdjC = false;
    double tRtLinMzFzWz = -387343.80279712245;

    for (int WWLonyHpFzf = 696937811; WWLonyHpFzf > 0; WWLonyHpFzf--) {
        hklEVTdjC = FCTqJaoeQoMD;
    }

    for (int DfgSqyUQ = 2078581201; DfgSqyUQ > 0; DfgSqyUQ--) {
        tRtLinMzFzWz = tRtLinMzFzWz;
    }

    for (int ZJOGOfyMKUXIrJ = 1391263231; ZJOGOfyMKUXIrJ > 0; ZJOGOfyMKUXIrJ--) {
        continue;
    }

    return NmnpRiMU;
}

int LytDGrld::JVmtDZuBOA(bool pITPkwogaMQHOcIf, int keqmSfFHqFbK, string qbLIKihmKdrlaAy, int EnHXbRbdi, string KKYZgkWWoQwQaZuo)
{
    int LAGWxPalNow = -888734970;

    for (int eNdXR = 1978886002; eNdXR > 0; eNdXR--) {
        KKYZgkWWoQwQaZuo += KKYZgkWWoQwQaZuo;
    }

    if (KKYZgkWWoQwQaZuo != string("VmCYJlIqdVAyWcTAxhViNOKDqMqaIjwaEtYSEWTUkLUKDusXwPZTjUUmGbfYXVgDPOHesSPNBIewhWBdsqbwgsXopxSgDvBBJMzBIaXEXTtfHiiVLcQCE")) {
        for (int EOecgwU = 1650306593; EOecgwU > 0; EOecgwU--) {
            pITPkwogaMQHOcIf = ! pITPkwogaMQHOcIf;
            EnHXbRbdi -= keqmSfFHqFbK;
        }
    }

    if (EnHXbRbdi > -888734970) {
        for (int qELJjf = 1328887981; qELJjf > 0; qELJjf--) {
            EnHXbRbdi -= EnHXbRbdi;
            qbLIKihmKdrlaAy = KKYZgkWWoQwQaZuo;
        }
    }

    for (int IktCMhYtgVpLREr = 699908689; IktCMhYtgVpLREr > 0; IktCMhYtgVpLREr--) {
        EnHXbRbdi *= keqmSfFHqFbK;
        LAGWxPalNow /= keqmSfFHqFbK;
        EnHXbRbdi -= LAGWxPalNow;
        qbLIKihmKdrlaAy += qbLIKihmKdrlaAy;
        EnHXbRbdi -= keqmSfFHqFbK;
        EnHXbRbdi *= LAGWxPalNow;
    }

    return LAGWxPalNow;
}

void LytDGrld::PChciv(bool tUwEMGYcmVFHVqh, bool uTBkiSn, double viyuyOJkdNno, string ZHnZQzPH)
{
    bool AujirflMpUnwHFj = false;
    string ldtzg = string("NjenOVVOUAXCmDyJHWAKkkEjflMoSUaRZCu");
    double SMTMq = 604505.7411431031;
    double PJKTGOCcmmfgexC = -404790.055355413;
    bool mNVwMC = true;
    double AgvnneteLJSS = -41672.847492364126;
    bool sSxekaZ = false;
    string RXKps = string("WbJPBQCmNURhtXBYmIDnPEaEbCbNfujHJKxDKCnbTwkrSsgsSjnhaXOoFUYCUNprNAQspFFCkDgMauqwIYZQEYuLtDnBETmWaBLlOEIEcS");
    string dUeGMxGcMn = string("csMoTUoxjxXkaOLemPvGKecvgfzzpQbEFWFOaMcUNqRMFLybgRWltjKgvusapGwGjbRgefaXetiozYgFanFDXDEKkKfitBGQryZaUvYlmaizgcmlxVLucuYlEQWYTvpovOqbdCxmEKx");

    if (mNVwMC == true) {
        for (int XXWUGW = 1676197158; XXWUGW > 0; XXWUGW--) {
            viyuyOJkdNno /= AgvnneteLJSS;
        }
    }

    for (int bWFkszRsRwZ = 1546761838; bWFkszRsRwZ > 0; bWFkszRsRwZ--) {
        continue;
    }

    for (int vuuCi = 1308414244; vuuCi > 0; vuuCi--) {
        viyuyOJkdNno += PJKTGOCcmmfgexC;
        AgvnneteLJSS *= SMTMq;
    }

    if (RXKps != string("WbJPBQCmNURhtXBYmIDnPEaEbCbNfujHJKxDKCnbTwkrSsgsSjnhaXOoFUYCUNprNAQspFFCkDgMauqwIYZQEYuLtDnBETmWaBLlOEIEcS")) {
        for (int DWrjIoKg = 724979871; DWrjIoKg > 0; DWrjIoKg--) {
            continue;
        }
    }
}

LytDGrld::LytDGrld()
{
    this->GTStNpOY(false, true);
    this->VLlWHPxUKvzC(692789954, true);
    this->etaxfgddYHCjBrd(true, string("fXEsQOJLQpPCYqSWOpcJXcsFVaGQTYuulWMhCUVwCOISmFXqdyaVEWNCwNiypaDFvIhmYifpNiGTVYBeEthFPdrdmJiPfXZNOjWVESClrdDVrtIJSwLNQgeCCCAbNvbflKnKKDSGOWapLodsCLzEvtfcBb"));
    this->MFhlr(string("IHbPJvMMWcBMXSvAETGmncbirjCtSyisqxZXdQabhosEEehpkfYiCHzZLLvaaWtxLlNsrybcTkOidLGHZBJrhPtXFLgaxuTmQuEsHWdZUKwnpkwvEnpqVHYmpGKsymReCDwkNMxotJFOFNcZvYlwbKNeJfPeiPbijvkrfHqFLWQvyGCJcoAbChYKMLTprEogHcwcrSWGcwDsIDdlJCQHYzb"), 1047569.6076281143, true, true, false);
    this->cXhsASoxVkcI(string("zoKlNDzxoThNYivrfUNuNWbwypsyZxYckWSJhEwnUnFClGEfPGpuKDXfRAzgtbwdeaKidEyvefjPXaowQVbiegBzlcnrJFalAlAjuObAXWhhyIVl"));
    this->ZaOio(string("ukkjfEypRlLBXmrPzZYEtWUiJKbSRHqexIgujZANXxqJJUcztXzugaukqfYisDkGdGjwVUJXwCEYcHTQUuQmoqOYBkE"));
    this->nNtFLVVoPMn(string("STfTmfpoLsSxCqyAnXcwoQCeMddIImFUpJzCHZIudQACmI"));
    this->KfTLgReoTDhindSO(927911.3523267943, string("yjenfQQzDddrFFhKqzAAXJPllJHbcSLPsUCibPYvDIgvVNMYQRQGNuGgGfbIqccOeFkNFFWpxubUrulQTl"), false, true);
    this->ncuSdKsKExnyyMn(false);
    this->xGpUJhkYRjlEQXw(true, -485098670);
    this->MCFPOMLvZAJA(-425366.9724764499);
    this->JVmtDZuBOA(true, 167741002, string("VmCYJlIqdVAyWcTAxhViNOKDqMqaIjwaEtYSEWTUkLUKDusXwPZTjUUmGbfYXVgDPOHesSPNBIewhWBdsqbwgsXopxSgDvBBJMzBIaXEXTtfHiiVLcQCE"), 655817575, string("TBAgXFejegGbjSDFAiqAIewrexMaJuupsuIASkKuATmuAJHzannwTKDHpjuIBrTrpGicKkPsuOaRdQcDwuJhcAxEwoArwjrbpysEQgDCcqWMMuikypfqdfUEpoAm"));
    this->PChciv(true, true, 142697.0722269439, string("YsYPqBwbLrLCZimeaKmMbEjiiWfKXvURvoDvwejKwPhiSqpYOBwycVmeLjygEscbGsInqsTgYPOJBluikJRyQKxtdGrXGwtpyNKZrqKjlttgqIHndKodQoHHdPvqvixsnXZbffRMgjpWqUeErZTCMwzvAsF"));
}
