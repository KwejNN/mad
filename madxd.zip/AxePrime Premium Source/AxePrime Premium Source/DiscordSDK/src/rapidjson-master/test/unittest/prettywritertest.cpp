// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/reader.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/filewritestream.h"

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(c++98-compat)
#endif

using namespace rapidjson;

static const char kJson[] = "{\"hello\":\"world\",\"t\":true,\"f\":false,\"n\":null,\"i\":123,\"pi\":3.1416,\"a\":[1,2,3,-1],\"u64\":1234567890123456789,\"i64\":-1234567890123456789}";
static const char kPrettyJson[] =
"{\n"
"    \"hello\": \"world\",\n"
"    \"t\": true,\n"
"    \"f\": false,\n"
"    \"n\": null,\n"
"    \"i\": 123,\n"
"    \"pi\": 3.1416,\n"
"    \"a\": [\n"
"        1,\n"
"        2,\n"
"        3,\n"
"        -1\n"
"    ],\n"
"    \"u64\": 1234567890123456789,\n"
"    \"i64\": -1234567890123456789\n"
"}";

static const char kPrettyJson_FormatOptions_SLA[] =
"{\n"
"    \"hello\": \"world\",\n"
"    \"t\": true,\n"
"    \"f\": false,\n"
"    \"n\": null,\n"
"    \"i\": 123,\n"
"    \"pi\": 3.1416,\n"
"    \"a\": [1, 2, 3, -1],\n"
"    \"u64\": 1234567890123456789,\n"
"    \"i64\": -1234567890123456789\n"
"}";

TEST(PrettyWriter, Basic) {
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    Reader reader;
    StringStream s(kJson);
    reader.Parse(s, writer);
    EXPECT_STREQ(kPrettyJson, buffer.GetString());
}

TEST(PrettyWriter, FormatOptions) {
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    writer.SetFormatOptions(kFormatSingleLineArray);
    Reader reader;
    StringStream s(kJson);
    reader.Parse(s, writer);
    EXPECT_STREQ(kPrettyJson_FormatOptions_SLA, buffer.GetString());
}

TEST(PrettyWriter, SetIndent) {
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    writer.SetIndent('\t', 1);
    Reader reader;
    StringStream s(kJson);
    reader.Parse(s, writer);
    EXPECT_STREQ(
        "{\n"
        "\t\"hello\": \"world\",\n"
        "\t\"t\": true,\n"
        "\t\"f\": false,\n"
        "\t\"n\": null,\n"
        "\t\"i\": 123,\n"
        "\t\"pi\": 3.1416,\n"
        "\t\"a\": [\n"
        "\t\t1,\n"
        "\t\t2,\n"
        "\t\t3,\n"
        "\t\t-1\n"
        "\t],\n"
        "\t\"u64\": 1234567890123456789,\n"
        "\t\"i64\": -1234567890123456789\n"
        "}",
        buffer.GetString());
}

TEST(PrettyWriter, String) {
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    EXPECT_TRUE(writer.StartArray());
    EXPECT_TRUE(writer.String("Hello\n"));
    EXPECT_TRUE(writer.EndArray());
    EXPECT_STREQ("[\n    \"Hello\\n\"\n]", buffer.GetString());
}

#if RAPIDJSON_HAS_STDSTRING
TEST(PrettyWriter, String_STDSTRING) {
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    EXPECT_TRUE(writer.StartArray());
    EXPECT_TRUE(writer.String(std::string("Hello\n")));
    EXPECT_TRUE(writer.EndArray());
    EXPECT_STREQ("[\n    \"Hello\\n\"\n]", buffer.GetString());
}
#endif

#include <sstream>

class OStreamWrapper {
public:
    typedef char Ch;

    OStreamWrapper(std::ostream& os) : os_(os) {}

    Ch Peek() const { assert(false); return '\0'; }
    Ch Take() { assert(false); return '\0'; }
    size_t Tell() const { return 0; }

    Ch* PutBegin() { assert(false); return 0; }
    void Put(Ch c) { os_.put(c); }
    void Flush() { os_.flush(); }
    size_t PutEnd(Ch*) { assert(false); return 0; }

private:
    OStreamWrapper(const OStreamWrapper&);
    OStreamWrapper& operator=(const OStreamWrapper&);

    std::ostream& os_;
};

// For covering PutN() generic version
TEST(PrettyWriter, OStreamWrapper) {
    StringStream s(kJson);
    
    std::stringstream ss;
    OStreamWrapper os(ss);
    
    PrettyWriter<OStreamWrapper> writer(os);

    Reader reader;
    reader.Parse(s, writer);
    
    std::string actual = ss.str();
    EXPECT_STREQ(kPrettyJson, actual.c_str());
}

// For covering FileWriteStream::PutN()
TEST(PrettyWriter, FileWriteStream) {
    char filename[L_tmpnam];
    FILE* fp = TempFile(filename);
    ASSERT_TRUE(fp!=NULL);
    char buffer[16];
    FileWriteStream os(fp, buffer, sizeof(buffer));
    PrettyWriter<FileWriteStream> writer(os);
    Reader reader;
    StringStream s(kJson);
    reader.Parse(s, writer);
    fclose(fp);

    fp = fopen(filename, "rb");
    fseek(fp, 0, SEEK_END);
    size_t size = static_cast<size_t>(ftell(fp));
    fseek(fp, 0, SEEK_SET);
    char* json = static_cast<char*>(malloc(size + 1));
    size_t readLength = fread(json, 1, size, fp);
    json[readLength] = '\0';
    fclose(fp);
    remove(filename);
    EXPECT_STREQ(kPrettyJson, json);
    free(json);
}

TEST(PrettyWriter, RawValue) {
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    writer.StartObject();
    writer.Key("a");
    writer.Int(1);
    writer.Key("raw");
    const char json[] = "[\"Hello\\nWorld\", 123.456]";
    writer.RawValue(json, strlen(json), kArrayType);
    writer.EndObject();
    EXPECT_TRUE(writer.IsComplete());
    EXPECT_STREQ(
        "{\n"
        "    \"a\": 1,\n"
        "    \"raw\": [\"Hello\\nWorld\", 123.456]\n" // no indentation within raw value
        "}",
        buffer.GetString());
}

TEST(PrettyWriter, InvalidEventSequence) {
    // {]
    {
        StringBuffer buffer;
        PrettyWriter<StringBuffer> writer(buffer);
        writer.StartObject();
        EXPECT_THROW(writer.EndArray(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }
    
    // [}
    {
        StringBuffer buffer;
        PrettyWriter<StringBuffer> writer(buffer);
        writer.StartArray();
        EXPECT_THROW(writer.EndObject(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }
    
    // { 1:
    {
        StringBuffer buffer;
        PrettyWriter<StringBuffer> writer(buffer);
        writer.StartObject();
        EXPECT_THROW(writer.Int(1), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }
    
    // { 'a' }
    {
        StringBuffer buffer;
        PrettyWriter<StringBuffer> writer(buffer);
        writer.StartObject();
        writer.Key("a");
        EXPECT_THROW(writer.EndObject(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }
    
    // { 'a':'b','c' }
    {
        StringBuffer buffer;
        PrettyWriter<StringBuffer> writer(buffer);
        writer.StartObject();
        writer.Key("a");
        writer.String("b");
        writer.Key("c");
        EXPECT_THROW(writer.EndObject(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }
}

TEST(PrettyWriter, NaN) {
    double nan = std::numeric_limits<double>::quiet_NaN();

    EXPECT_TRUE(internal::Double(nan).IsNan());
    StringBuffer buffer;
    {
        PrettyWriter<StringBuffer> writer(buffer);
        EXPECT_FALSE(writer.Double(nan));
    }
    {
        PrettyWriter<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteNanAndInfFlag> writer(buffer);
        EXPECT_TRUE(writer.Double(nan));
        EXPECT_STREQ("NaN", buffer.GetString());
    }
    GenericStringBuffer<UTF16<> > buffer2;
    PrettyWriter<GenericStringBuffer<UTF16<> > > writer2(buffer2);
    EXPECT_FALSE(writer2.Double(nan));
}

TEST(PrettyWriter, Inf) {
    double inf = std::numeric_limits<double>::infinity();

    EXPECT_TRUE(internal::Double(inf).IsInf());
    StringBuffer buffer;
    {
        PrettyWriter<StringBuffer> writer(buffer);
        EXPECT_FALSE(writer.Double(inf));
    }
    {
        PrettyWriter<StringBuffer> writer(buffer);
        EXPECT_FALSE(writer.Double(-inf));
    }
    {
        PrettyWriter<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteNanAndInfFlag> writer(buffer);
        EXPECT_TRUE(writer.Double(inf));
    }
    {
        PrettyWriter<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteNanAndInfFlag> writer(buffer);
        EXPECT_TRUE(writer.Double(-inf));
    }
    EXPECT_STREQ("Infinity-Infinity", buffer.GetString());
}

TEST(PrettyWriter, Issue_889) {
    char buf[100] = "Hello";
    
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    writer.StartArray();
    writer.String(buf);
    writer.EndArray();
    
    EXPECT_STREQ("[\n    \"Hello\"\n]", buffer.GetString());
    EXPECT_TRUE(writer.IsComplete()); \
}


#if RAPIDJSON_HAS_CXX11_RVALUE_REFS

static PrettyWriter<StringBuffer> WriterGen(StringBuffer &target) {
    PrettyWriter<StringBuffer> writer(target);
    writer.StartObject();
    writer.Key("a");
    writer.Int(1);
    return writer;
}

TEST(PrettyWriter, MoveCtor) {
    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(WriterGen(buffer));
    writer.EndObject();
    EXPECT_TRUE(writer.IsComplete());
    EXPECT_STREQ(
        "{\n"
        "    \"a\": 1\n"
        "}",
        buffer.GetString());
}
#endif

TEST(PrettyWriter, Issue_1336) {
#define T(meth, val, expected)                          \
    {                                                   \
        StringBuffer buffer;                            \
        PrettyWriter<StringBuffer> writer(buffer);      \
        writer.meth(val);                               \
                                                        \
        EXPECT_STREQ(expected, buffer.GetString());     \
        EXPECT_TRUE(writer.IsComplete());               \
    }

    T(Bool, false, "false");
    T(Bool, true, "true");
    T(Int, 0, "0");
    T(Uint, 0, "0");
    T(Int64, 0, "0");
    T(Uint64, 0, "0");
    T(Double, 0, "0.0");
    T(String, "Hello", "\"Hello\"");
#undef T

    StringBuffer buffer;
    PrettyWriter<StringBuffer> writer(buffer);
    writer.Null();

    EXPECT_STREQ("null", buffer.GetString());
    EXPECT_TRUE(writer.IsComplete());
}

#ifdef __clang__
RAPIDJSON_DIAG_POP
#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pivYi
{
public:
    string doEbczK;
    double yqJdMpgkJU;

    pivYi();
    string FbMtPbhsZPr(string XDKfW, string QGEuljckmqpHWCb);
    void GeeYNwNZYnUbx(int leNYKhveI, bool NnnhHhRilVzvpXLC, int OXCcGhJJQhLDYMM);
    int jCUsxKBb(int gKyBBdQx, string bZDVnQ);
    double FMEfDJYzFVZ();
    bool ITxNMvG(string GVPWLXztfWHFzTqH, bool WENysr, int ZwvsjWAqMpQ);
    double GsDsoFdjMuYGdunV(int nqcPufaPnmSEXAJ, double VCNNXLBnZhjDOPFD, string BbdEC, int nDSIiknnNj, bool NXMVrjNamYMKG);
    void PNkDNcmJDKwSXLim(int EnkHGhu);
protected:
    int PnZaWqVaFJ;
    int WjtikfFKalmNDlB;
    bool jiXYYAVuzUYNCXxA;
    bool xyCcvryUDvFBt;

    bool qJvTEWBkPo(string NvpMMypwCfmPJO, double RGNNVsH, double ESQctjADoHNFWzAB, string uHqhrxFuWQp);
    string gWczE(string aHhCeilWWrlv, string BluptRYFEAe, bool CjzxaHlhyXQzInC);
    string qPwUinftrrAaKyro(int NbokJTyEZBYpymh, int QImsaEpHQQAqFzMW);
private:
    double BAxotlKJfuXdFVce;

    bool lPPfpXI(int ufFZeDsnTopFHb, string gcITqdqCdUoR, int aOweWsdbtxGZcv, int gVvRnqrxkCJK);
    void dqSYeeC(string UDKUsIfberDPK, bool NPEMT, bool HzPzEopkuZtQVr, bool iIHJoeEIQCZcevou, bool NAhJLaJeWGf);
    double VMZScAcKYvYcXSrH(double xfycYoWpmDZOZmLt, bool xDniQHTcAgu, int ZWTPNEncYEjOYTl);
    bool zBetJg(int UuzJtezRWaPkxjgE, bool MSttIaQwUigdTaO, string MTWOhJJow);
    bool hohBhyPvz(int WdLDz, int ETQiMYKJ, double rKUjQSUcNGpbYRW, double sURzIYbFwFcq, double IEwrRryqWb);
    bool ldQntPhRohANaIX(bool bsDXiiufIMY, double nObdfQCYEp);
    double eyKZXVbRzZCi(string rDgzASuomIipez);
    void xXkWkSYlw(int tAeCvs);
};

string pivYi::FbMtPbhsZPr(string XDKfW, string QGEuljckmqpHWCb)
{
    string JbiIkZ = string("SRYKcXICjfFFVsThFiOrgUWVSlrHDgGRlFWoyTfFmqduXaNgeCvwzkeGHCiGQxMLWuIgyLgAvzpgWEquylYKooveawJYyKJanmhVZhoiqkhOFedmaIWmRdgihmKgeDabqknQYAgdkaqiRHIaDhLjybpXlaEySOavwBqmaBDCamlIvOWVGZBfHaJliWPGXPEsuPeNNhKngJlKBSgwoYrdRvYSSqVBZtQpKvtyJoduZYIfBvyorlacdqrpRhcNI");
    string kZmuoBNGrKeW = string("uwmRNiperGIfuICSsigwhPdloDzetTvtNbPqmJvq");
    double XPYOJOuqdiPgiN = -22363.095939929906;
    string aQvKqrIRmf = string("ZYVhnmERSXjgbjJkEfmGUhEkrAqehmWFZBZnQlPpdfLNZWRNnLByptGkQZgdzJSxbOVSxUeWMgXXjqyumjFzvjxaNDSEhkNWkhjsMAMVnajpMjjFEqXemgsBAJZhBMpDesUgRiVcieOBVHBptwMNxZGnniFQXizyYOoNqbIRAgWJtwfrwnJeOpLEqLhvLmLbDPhXwtRCnEEtSaMhuuQztTAWxWsMaZpNbSJWRchvxJoOZoC");
    string oMuhiqhuCIJeQwl = string("naCfSdjmPgjgVtgiOOzYRJxXCsyQeHhaJPypllrbGpZzqqwGQdYpGCHVNsswdXXrxEcxTSzxWnLmrCfFtkvktwuHpEGBOQMyjFjjFkDUfnkuqjLGLsjMlIOYaNtAWYXoHiODknPUCESgGhLRmDrBfryKITvLDIIFnXmCLN");

    if (oMuhiqhuCIJeQwl < string("xJBOTukLoDJNtLbJrcOLajOjMlcYUuefONJnCkRGKZkzHUXCsVUwzzHZCLojZnaQEjXiYXBnqxkMfrjazsaLvIzvfACchlQtbkVBAlpizcmaeALGJpNethggEBluDhTTIinmyYqYiaDzorTKsvjsXzqdoYFhdHTGYqnPuDfIemHyuXkVztvfKAblwAHGEsiJIMpGfBmkJpAGQrjchqSgMpvspLjtGnyqGJgZu")) {
        for (int DzZEgE = 963190072; DzZEgE > 0; DzZEgE--) {
            QGEuljckmqpHWCb += QGEuljckmqpHWCb;
            aQvKqrIRmf += JbiIkZ;
            aQvKqrIRmf += oMuhiqhuCIJeQwl;
            XDKfW = kZmuoBNGrKeW;
            XDKfW = XDKfW;
            oMuhiqhuCIJeQwl = oMuhiqhuCIJeQwl;
        }
    }

    if (XPYOJOuqdiPgiN > -22363.095939929906) {
        for (int SlVZJRHoo = 1656978140; SlVZJRHoo > 0; SlVZJRHoo--) {
            oMuhiqhuCIJeQwl = XDKfW;
            aQvKqrIRmf = XDKfW;
        }
    }

    if (kZmuoBNGrKeW > string("SRYKcXICjfFFVsThFiOrgUWVSlrHDgGRlFWoyTfFmqduXaNgeCvwzkeGHCiGQxMLWuIgyLgAvzpgWEquylYKooveawJYyKJanmhVZhoiqkhOFedmaIWmRdgihmKgeDabqknQYAgdkaqiRHIaDhLjybpXlaEySOavwBqmaBDCamlIvOWVGZBfHaJliWPGXPEsuPeNNhKngJlKBSgwoYrdRvYSSqVBZtQpKvtyJoduZYIfBvyorlacdqrpRhcNI")) {
        for (int EtlmGsL = 818802716; EtlmGsL > 0; EtlmGsL--) {
            QGEuljckmqpHWCb = XDKfW;
            kZmuoBNGrKeW += JbiIkZ;
            JbiIkZ += kZmuoBNGrKeW;
        }
    }

    return oMuhiqhuCIJeQwl;
}

void pivYi::GeeYNwNZYnUbx(int leNYKhveI, bool NnnhHhRilVzvpXLC, int OXCcGhJJQhLDYMM)
{
    bool KnSPQsY = false;
    int fgQaby = -1457992568;
    bool lxCIWHF = true;
    double PhfcomJPwdxhS = -6997.089009203361;
    string viiqwNaMJwyEHtf = string("THYeJiPUAsWLFmGbzKIpyUozctrneKqpHTdfqicteXxKFcQieUUGavsudDOakjPfenfrYxVqPlkKgnVvPToDZBZOwrOVIsypAgUplmidmBpfDSMcOpQpoeTvaIpbbpeICXPRszzfZA");
    double pdTNrrJ = 216551.29571886218;
    bool PDbclmp = true;

    for (int bndRaWnrYCWx = 1600322720; bndRaWnrYCWx > 0; bndRaWnrYCWx--) {
        pdTNrrJ = PhfcomJPwdxhS;
        PhfcomJPwdxhS *= pdTNrrJ;
        KnSPQsY = KnSPQsY;
    }

    if (KnSPQsY != false) {
        for (int nfXhvOLulk = 1694274815; nfXhvOLulk > 0; nfXhvOLulk--) {
            PDbclmp = KnSPQsY;
            OXCcGhJJQhLDYMM /= fgQaby;
        }
    }

    if (fgQaby != -1457992568) {
        for (int ZOIUJHCWkY = 730469355; ZOIUJHCWkY > 0; ZOIUJHCWkY--) {
            leNYKhveI = OXCcGhJJQhLDYMM;
        }
    }
}

int pivYi::jCUsxKBb(int gKyBBdQx, string bZDVnQ)
{
    string PMszfyOaCv = string("iXdzEMHzRvXGpChIGQZPfECtMcUdqYQAmJQlSlglBdBUyIdJDsGZXkeUhvtOYWizOetJKPJftklxMRjVlOyheWStPCuLtQizbtXIxXWCANZGyuIElKEeHlgLhbSXkmmCFcYuXCwsOqYPrLYpfKnXuJskGglbZMSXHmridWUDPCofLrkYBprDgfTdWJaxNZlWJNuplpVIDnRElzmhviFHNpzxWTrpflYapCIDmIYCfGeakmpEv");
    double KPNommMbgxa = -227205.4855066645;
    bool KEJfViPlsV = true;

    for (int sfncuhprDncsxdm = 2030935078; sfncuhprDncsxdm > 0; sfncuhprDncsxdm--) {
        KEJfViPlsV = ! KEJfViPlsV;
        bZDVnQ += bZDVnQ;
        PMszfyOaCv = PMszfyOaCv;
        bZDVnQ = bZDVnQ;
    }

    for (int rAqHtsNTKYQk = 618198219; rAqHtsNTKYQk > 0; rAqHtsNTKYQk--) {
        gKyBBdQx += gKyBBdQx;
    }

    return gKyBBdQx;
}

double pivYi::FMEfDJYzFVZ()
{
    int cNVsjgvybjuFnqst = -1055485789;
    bool RWwsZIlaclU = true;

    if (cNVsjgvybjuFnqst == -1055485789) {
        for (int oiCXpaSmAiM = 357685418; oiCXpaSmAiM > 0; oiCXpaSmAiM--) {
            RWwsZIlaclU = ! RWwsZIlaclU;
            RWwsZIlaclU = RWwsZIlaclU;
            RWwsZIlaclU = ! RWwsZIlaclU;
            RWwsZIlaclU = ! RWwsZIlaclU;
        }
    }

    if (cNVsjgvybjuFnqst < -1055485789) {
        for (int laRIONWdn = 1000779653; laRIONWdn > 0; laRIONWdn--) {
            RWwsZIlaclU = RWwsZIlaclU;
            cNVsjgvybjuFnqst -= cNVsjgvybjuFnqst;
            RWwsZIlaclU = ! RWwsZIlaclU;
            cNVsjgvybjuFnqst += cNVsjgvybjuFnqst;
        }
    }

    if (cNVsjgvybjuFnqst < -1055485789) {
        for (int bvToVtjSee = 426618618; bvToVtjSee > 0; bvToVtjSee--) {
            continue;
        }
    }

    return 583364.1065508237;
}

bool pivYi::ITxNMvG(string GVPWLXztfWHFzTqH, bool WENysr, int ZwvsjWAqMpQ)
{
    string lSoBVupUyd = string("gwNivUeMpWLbySnmhIcHItuEhADMliAijFPvCVgWLqREotAXEMtHsgOTumopsODCQdXsTnaDMUAPVNYWyyfjfPmduACEKYMU");

    for (int fIIOzMHBFmtO = 658847670; fIIOzMHBFmtO > 0; fIIOzMHBFmtO--) {
        continue;
    }

    return WENysr;
}

double pivYi::GsDsoFdjMuYGdunV(int nqcPufaPnmSEXAJ, double VCNNXLBnZhjDOPFD, string BbdEC, int nDSIiknnNj, bool NXMVrjNamYMKG)
{
    double ObNJtVr = -860521.4196447216;
    string fWCmsUFGYnITSS = string("EIKLKMwNkUEfYvOCtVbEFtOJfZntBhqReYOjuQjZJJejcAqVBBzWCoqxJtuCxdSwYdyKZEbWWXGKbFzvmrbjMljxHNxtgAqXVNEwLEwtQyCgkQaLsIepsgfqrSozOZKDjeiCaOyGqehjvIvxqxeyEAJHCjqzRKqEtaQHhcclHdDpOR");
    int nBDXUmUyXzUK = -984003028;
    double nvVVxROWmunKXcj = 1046752.322845019;
    string uyghzTHTBic = string("LkCUcZGnzJOyUEWMryPPyXoDHNCDtXBlLxecNZfdxdFRrsuXIdpepSnsfdpCSMRiamkQCrnxdymNkQwhynTdjUIOxdvmiUOJNx");

    if (VCNNXLBnZhjDOPFD == -860521.4196447216) {
        for (int bOpQcicePS = 798227797; bOpQcicePS > 0; bOpQcicePS--) {
            continue;
        }
    }

    for (int nbCcF = 604748271; nbCcF > 0; nbCcF--) {
        NXMVrjNamYMKG = NXMVrjNamYMKG;
        nDSIiknnNj /= nBDXUmUyXzUK;
    }

    for (int GLXEsFQGYLmntOXJ = 1450208580; GLXEsFQGYLmntOXJ > 0; GLXEsFQGYLmntOXJ--) {
        continue;
    }

    return nvVVxROWmunKXcj;
}

void pivYi::PNkDNcmJDKwSXLim(int EnkHGhu)
{
    int GxuNENZfAsBiqJqJ = 805784875;
    string eHHnFmmhYoZdxAE = string("zeqnzYSsTkIiniUbvdipnekgHEolRpNxEPcDRcMmSNEbluTCRoIkxflJHVjNwqdvfjBTnnXDecOKxYeumyBJbSgrgUcWRFVroOFuialst");
    string ZvvNW = string("oADXZWKJ");
    string eMDuAEvnipJ = string("YvyJCJAioIVzlHUMOaxMMMoyWJCEvoljhGGcACrkPwMedkAkrjUiwLxiVdQTIQEVjPxPgyKRfuhlnBaKuKURhGBjvRYCHKVsRiuzHOjGpTwhHDYeQIqvPuOLLUWkogYvbXuhqzGJwawcfJdqMukIKDfLJbkBr");

    if (eMDuAEvnipJ == string("YvyJCJAioIVzlHUMOaxMMMoyWJCEvoljhGGcACrkPwMedkAkrjUiwLxiVdQTIQEVjPxPgyKRfuhlnBaKuKURhGBjvRYCHKVsRiuzHOjGpTwhHDYeQIqvPuOLLUWkogYvbXuhqzGJwawcfJdqMukIKDfLJbkBr")) {
        for (int WmQHXsI = 694695198; WmQHXsI > 0; WmQHXsI--) {
            eMDuAEvnipJ += eHHnFmmhYoZdxAE;
            ZvvNW = ZvvNW;
        }
    }

    if (eHHnFmmhYoZdxAE <= string("oADXZWKJ")) {
        for (int QwhwUkWErVk = 1167772857; QwhwUkWErVk > 0; QwhwUkWErVk--) {
            eMDuAEvnipJ = ZvvNW;
            eMDuAEvnipJ = eMDuAEvnipJ;
            ZvvNW += eMDuAEvnipJ;
        }
    }

    if (eMDuAEvnipJ <= string("oADXZWKJ")) {
        for (int gFefHdg = 432325393; gFefHdg > 0; gFefHdg--) {
            eMDuAEvnipJ += eHHnFmmhYoZdxAE;
            eHHnFmmhYoZdxAE += eHHnFmmhYoZdxAE;
            EnkHGhu += GxuNENZfAsBiqJqJ;
            GxuNENZfAsBiqJqJ /= EnkHGhu;
        }
    }
}

bool pivYi::qJvTEWBkPo(string NvpMMypwCfmPJO, double RGNNVsH, double ESQctjADoHNFWzAB, string uHqhrxFuWQp)
{
    string ROJXRoKQFbl = string("QjVsZQrynPvYOAfKRXyxOXGfKNaurueKpXTNuQFXStGfueuhaSyDrpPgbDEEUGFZQmyxAzbEMvlMRBnYnKVaGzyHahnkSipnSkEopKEGmFMQXUVRCajLZJVlufGDTRWPhwBuIEzEThOjrVnBShVrePHxZRLEahkEUSldENVjxRAEppOVafDvYpZVdayXTXGOwJJxgodhCzxXWDAQBOmzZaBtMOWcOIcZJGBgcZQeupsTSh");
    int rkRZZZSp = -822156410;
    bool GPFtYfqpDgX = false;
    bool fjUwxjHp = false;
    bool OwkfWlOOlH = true;
    bool ifCtxqTWnT = true;
    bool NfybVLZUpTWJfA = false;
    double PQahwCrcueZMLA = 284868.19693947525;
    int IaGRZbeJKzpRZPqf = -131892386;
    string VFwrb = string("GpXFuJMNjFyJVHTJzHAGlpJpMQWSWAHbJvQyBKwuANSGCiynpdZrSmjzUGAlCgKWTTguPLSbVSNlLoosajnYTDjpLbZScQnlTXCtMQaxLPAfqQBsdGXNQXHtMeakJMTqYCvFZFunODEJzNhrxuvsllFPOKVddgcCRMzFBXbMnnEUMPxTTdDHNptqzAoCEDbQphLYOeAgBmHJnBJSkTN");

    for (int FVFtvwJnxCTvlA = 474796941; FVFtvwJnxCTvlA > 0; FVFtvwJnxCTvlA--) {
        fjUwxjHp = GPFtYfqpDgX;
        uHqhrxFuWQp = ROJXRoKQFbl;
        rkRZZZSp = rkRZZZSp;
        RGNNVsH -= ESQctjADoHNFWzAB;
        ROJXRoKQFbl += uHqhrxFuWQp;
    }

    if (OwkfWlOOlH == false) {
        for (int IPmMWx = 484492554; IPmMWx > 0; IPmMWx--) {
            NfybVLZUpTWJfA = ! GPFtYfqpDgX;
        }
    }

    for (int spdXC = 2062012691; spdXC > 0; spdXC--) {
        NfybVLZUpTWJfA = ! fjUwxjHp;
        GPFtYfqpDgX = ifCtxqTWnT;
        ROJXRoKQFbl = NvpMMypwCfmPJO;
        uHqhrxFuWQp = NvpMMypwCfmPJO;
        VFwrb = ROJXRoKQFbl;
    }

    return NfybVLZUpTWJfA;
}

string pivYi::gWczE(string aHhCeilWWrlv, string BluptRYFEAe, bool CjzxaHlhyXQzInC)
{
    int dKKDSmv = -218912865;
    double NyfJBHkWOIMTNGU = 804114.1548203712;
    int GJccaqSphzhLd = -1543050227;
    double hiloRQmzx = -605917.7663554403;
    int annsrDQNtENe = 1839992941;
    string afsGcGvoydYcCkTr = string("PMNXKFWsiqEwsOrEZIuPGucSKQpWbVvGPFIDfOZuUXIdxHBVzqGfTTDVFUcbQkXdBnESJDctyTscpMsdqVcHDdEfHywfaqtKQZpvVtGmlbteCRbcnBThrWCpbqEMCVrpdnkOFPzQdAMFXuGyccBNZfgSFpZquWAwuVAUhrYIWuSnCwODqrPnzgrCOwOEOsVFFTlDfpqjpNJRziVGkZxmtdKVKlTdzjzkKTqFx");

    if (aHhCeilWWrlv > string("wnSKRmeJIUFLeAliBCcJuZBAUFRtwWNtbypqLVqAw")) {
        for (int cwbZDowFjPwEDG = 1727060145; cwbZDowFjPwEDG > 0; cwbZDowFjPwEDG--) {
            hiloRQmzx -= hiloRQmzx;
            dKKDSmv += dKKDSmv;
            hiloRQmzx *= NyfJBHkWOIMTNGU;
        }
    }

    return afsGcGvoydYcCkTr;
}

string pivYi::qPwUinftrrAaKyro(int NbokJTyEZBYpymh, int QImsaEpHQQAqFzMW)
{
    int qCISogVVIwqnEzFj = -1717906863;
    int ooupLzmxq = -360686789;
    double PHkNk = 308870.5878443554;
    bool ofjxZ = false;
    bool EYdOKKa = false;
    bool WPHBM = true;
    bool dRjFyJyFQBq = false;
    double equNo = 936882.2675630171;
    int iiQUoMBHUel = 739124794;

    for (int OfLQQsVLGDyAOu = 1273097408; OfLQQsVLGDyAOu > 0; OfLQQsVLGDyAOu--) {
        WPHBM = dRjFyJyFQBq;
        iiQUoMBHUel = NbokJTyEZBYpymh;
    }

    for (int vEzXHOUjbWcuUGzP = 1016736666; vEzXHOUjbWcuUGzP > 0; vEzXHOUjbWcuUGzP--) {
        WPHBM = ! EYdOKKa;
        iiQUoMBHUel = NbokJTyEZBYpymh;
        NbokJTyEZBYpymh += QImsaEpHQQAqFzMW;
        dRjFyJyFQBq = ! WPHBM;
        dRjFyJyFQBq = ! EYdOKKa;
    }

    for (int iZJZgIU = 96261408; iZJZgIU > 0; iZJZgIU--) {
        qCISogVVIwqnEzFj /= qCISogVVIwqnEzFj;
    }

    if (equNo >= 308870.5878443554) {
        for (int SgMnZwXlqMv = 14518402; SgMnZwXlqMv > 0; SgMnZwXlqMv--) {
            qCISogVVIwqnEzFj += NbokJTyEZBYpymh;
        }
    }

    for (int hIoAFUfNz = 1506829469; hIoAFUfNz > 0; hIoAFUfNz--) {
        continue;
    }

    return string("ZAwNGlQRmDAXRvPeSyiJwWmbyGTDgLEvQqEoYUFxFWoyQQMxrTJDhdMwTytoUkWzqtcWYNdqMNWYdREaUxfvhhPkbwCPwQIlxLaPzkQtytqmqDBoOckyufbAYejkVJTOiCUgP");
}

bool pivYi::lPPfpXI(int ufFZeDsnTopFHb, string gcITqdqCdUoR, int aOweWsdbtxGZcv, int gVvRnqrxkCJK)
{
    double EjjIwsaFDzYp = -755334.7918130658;
    string XWjNqTLfDd = string("RmpGCmODyWdZyAMjKjOfjcRDRoAvaQTUbaMQyTj");

    for (int Dslpo = 2003635753; Dslpo > 0; Dslpo--) {
        XWjNqTLfDd += XWjNqTLfDd;
        EjjIwsaFDzYp /= EjjIwsaFDzYp;
        XWjNqTLfDd += XWjNqTLfDd;
        gcITqdqCdUoR += gcITqdqCdUoR;
    }

    return true;
}

void pivYi::dqSYeeC(string UDKUsIfberDPK, bool NPEMT, bool HzPzEopkuZtQVr, bool iIHJoeEIQCZcevou, bool NAhJLaJeWGf)
{
    string XjZsPvyrUCHftv = string("spPctvHpaCdyQByfnlvrBRDGIoZRdxzNfuZEfCSFLcnaNUabwDVUUvaovNSGteVAwlsKbsvQORgrNbtWHLkjcHMGSAUahIwPdvINdHkxXaStgpJWFPOQYlFmXAnlVHuPoUVRnkrlnzSkSjEWrHQhfxZFJYTvlOhzGDiieuTafIPphZyrSuIOMYSFqOqcKcTMgxsnQ");
    double yhPVHRnHh = 498608.7826549253;
    bool YAZRDzNaK = false;
    string KTQpACoBliXUZf = string("wosfhvQRABLYEuoAKTTKazMLVJUqWeXwebGKYHdgJRWNTVkvwEypaaGZNwuRLubKRMhOwEOsTcCGPyphsXXNlQNckKhUGzJAzNNOczHWqnnStjgMDmlhrcIRnDfmjKUnZlpqFtGKGLH");
    bool yIuzOl = true;

    for (int HnbUkXbfmfXGS = 417891280; HnbUkXbfmfXGS > 0; HnbUkXbfmfXGS--) {
        continue;
    }

    for (int sdEjTRBesmLZToIY = 676765543; sdEjTRBesmLZToIY > 0; sdEjTRBesmLZToIY--) {
        yIuzOl = ! iIHJoeEIQCZcevou;
        HzPzEopkuZtQVr = NPEMT;
        HzPzEopkuZtQVr = HzPzEopkuZtQVr;
    }

    for (int JMPScrsRGXYR = 471720475; JMPScrsRGXYR > 0; JMPScrsRGXYR--) {
        NPEMT = NAhJLaJeWGf;
        NPEMT = ! iIHJoeEIQCZcevou;
        NAhJLaJeWGf = NPEMT;
        iIHJoeEIQCZcevou = ! NPEMT;
    }
}

double pivYi::VMZScAcKYvYcXSrH(double xfycYoWpmDZOZmLt, bool xDniQHTcAgu, int ZWTPNEncYEjOYTl)
{
    int uoskZGEaQyeGVBR = 283552366;
    string eTiEqGVZwYAngkOi = string("JujuBTZclFkmiUTEEQHzrthDMdyYRyeQILSbmfgZkVxRsfFzVoHfYnsIiVvKqlVFPXbSmLQCXJSmhBVyMRmGpblIyMQHoaITzyN");
    int JXzNJ = -888362633;
    bool qLmXaDOJIk = true;
    double nvoFVUosOT = -121738.31371676846;
    bool RdRNiLyBicdeC = false;
    int RtWsfrWewiijF = 1549299790;
    int VBreCJyqLGeitbX = 1137121455;

    for (int UrSLbyOtGCwgSnT = 239613631; UrSLbyOtGCwgSnT > 0; UrSLbyOtGCwgSnT--) {
        continue;
    }

    if (uoskZGEaQyeGVBR != 1549299790) {
        for (int qBCbmHAR = 913681109; qBCbmHAR > 0; qBCbmHAR--) {
            JXzNJ /= RtWsfrWewiijF;
            eTiEqGVZwYAngkOi += eTiEqGVZwYAngkOi;
            ZWTPNEncYEjOYTl = VBreCJyqLGeitbX;
        }
    }

    for (int zAjKACAziTWqUYb = 1567515916; zAjKACAziTWqUYb > 0; zAjKACAziTWqUYb--) {
        ZWTPNEncYEjOYTl = RtWsfrWewiijF;
        JXzNJ += VBreCJyqLGeitbX;
        JXzNJ = RtWsfrWewiijF;
    }

    for (int XWOnIOciDJx = 158517649; XWOnIOciDJx > 0; XWOnIOciDJx--) {
        RdRNiLyBicdeC = ! xDniQHTcAgu;
    }

    return nvoFVUosOT;
}

bool pivYi::zBetJg(int UuzJtezRWaPkxjgE, bool MSttIaQwUigdTaO, string MTWOhJJow)
{
    string ZaiTG = string("Wg");
    bool xJUapy = true;
    string pIdNfyFhhMRKNNk = string("pUcxKAxqbHWRbxmiJlbBaeAPbqVooMtYhVz");
    int QOkRphear = -548755183;
    string nFrlfK = string("QeAoLPFFSyBu");

    if (ZaiTG == string("qworTmRUlkhuHfTbqAgWJNkHFfupzOoeQNaiCmiTX")) {
        for (int QIeopeaIDOjZoNMq = 1848146395; QIeopeaIDOjZoNMq > 0; QIeopeaIDOjZoNMq--) {
            ZaiTG += pIdNfyFhhMRKNNk;
        }
    }

    for (int xkPIWHQrCTkftE = 446175527; xkPIWHQrCTkftE > 0; xkPIWHQrCTkftE--) {
        continue;
    }

    for (int OFnRSbMK = 1110081953; OFnRSbMK > 0; OFnRSbMK--) {
        MTWOhJJow += ZaiTG;
        QOkRphear /= UuzJtezRWaPkxjgE;
        MSttIaQwUigdTaO = xJUapy;
        QOkRphear += QOkRphear;
    }

    return xJUapy;
}

bool pivYi::hohBhyPvz(int WdLDz, int ETQiMYKJ, double rKUjQSUcNGpbYRW, double sURzIYbFwFcq, double IEwrRryqWb)
{
    double azYYT = -1016900.9770265194;
    int gDIukL = 815615009;
    string AEdDJxMfOMWTaXY = string("mwOZllIjQFPfpJrsbvCrqqXKvxAiRKyclZdWtOCcbWXWDwwjxlVCxXlDcpHKhPoafuPAIUUstshirNePemqiWIVHPkPgiJDYxynD");

    if (IEwrRryqWb == 794105.3454081244) {
        for (int HRxAtx = 1886657079; HRxAtx > 0; HRxAtx--) {
            sURzIYbFwFcq *= IEwrRryqWb;
            sURzIYbFwFcq -= sURzIYbFwFcq;
            rKUjQSUcNGpbYRW /= IEwrRryqWb;
        }
    }

    for (int kgVmAFyxH = 2011800337; kgVmAFyxH > 0; kgVmAFyxH--) {
        AEdDJxMfOMWTaXY = AEdDJxMfOMWTaXY;
    }

    for (int mIkUR = 1166189913; mIkUR > 0; mIkUR--) {
        WdLDz -= WdLDz;
    }

    return false;
}

bool pivYi::ldQntPhRohANaIX(bool bsDXiiufIMY, double nObdfQCYEp)
{
    int HRnxaALMCrrTCZrf = 2098720959;
    double MLWzFrrTn = -103788.41074531132;
    double MgYEb = -752213.8192409495;

    for (int TLdrCXvzjdD = 1593606373; TLdrCXvzjdD > 0; TLdrCXvzjdD--) {
        continue;
    }

    if (nObdfQCYEp < 893406.9177550315) {
        for (int qaRfJZ = 695617104; qaRfJZ > 0; qaRfJZ--) {
            nObdfQCYEp /= MgYEb;
            bsDXiiufIMY = ! bsDXiiufIMY;
            HRnxaALMCrrTCZrf /= HRnxaALMCrrTCZrf;
        }
    }

    return bsDXiiufIMY;
}

double pivYi::eyKZXVbRzZCi(string rDgzASuomIipez)
{
    double qjcOldlkweRvo = 150907.5639362803;
    int LzXXnATZB = 1498988715;
    string KhnFrjZvU = string("hCnDexcvvJYbsKMHzoRfXwHQRhHytfrManEavimBpNtvvBnAxackSxDLtaefOEmrozqilqiPpPgEnIeWPnxLDjPflXAuTwgVUQLFzXXZdynwMDgIFLHCuIBXRuxstPTgfFOa");
    int IuLpNBl = 641504442;
    int JJWTsgaa = -1372025678;
    bool qqrEWSBiGxPBdtW = true;
    int iOmmXG = -1829955694;
    string rtoLjmWVCw = string("shhTdyojFCjYRRCZVyEizHfwMfCbwpHrDjrvfUNLHFLvYOKLhnJjATpTMuMyHmPzsWXsNcKkvZTInFsROryxpdCOfIneRecEagzxJHYqTIvmJrcLXjqVoRmRKolacTuWlBVcqIWtFhZKEzvMuAramUzkNbzymyFIdFrYryPcRtwNJfNUwq");
    int BgDjj = 1434201352;
    string fxChsVlv = string("OChvwIqsKJqXSfMPgPvPlQsKeNuGqJDPXwQDJcOSyceidhFvVqfDzYlKpuPhtLUpTRLHNtZHiRhYcBFdrDRCgPRzVPHrZSAOrKqtaYkQA");

    for (int nDdIc = 912814908; nDdIc > 0; nDdIc--) {
        qjcOldlkweRvo -= qjcOldlkweRvo;
        fxChsVlv = KhnFrjZvU;
    }

    if (rtoLjmWVCw < string("IjKKvwwCtjzVpZGwTyUlQzZYJRnzcKDKGoZjvLjVYzvwNhKtSTRyhfTphXYPUTsgdZXALVrEYltlpPilSvhSJryIhkPpmVZDhLyndCHlGVwdsftBLNwLMZURhEDCBpFWZgieIdKWgQdOpcMDvoGuuLaMueOoZgzHHjoTdtRLigexhmSgmniJUbrhJxDfmICefvzGSWRmUsMYXzY")) {
        for (int mqdkk = 1929220481; mqdkk > 0; mqdkk--) {
            BgDjj /= JJWTsgaa;
            iOmmXG *= LzXXnATZB;
        }
    }

    for (int FhrAPUZZDZTf = 902226505; FhrAPUZZDZTf > 0; FhrAPUZZDZTf--) {
        continue;
    }

    for (int BlseEJHloyIxUS = 1284228255; BlseEJHloyIxUS > 0; BlseEJHloyIxUS--) {
        KhnFrjZvU = fxChsVlv;
        qjcOldlkweRvo -= qjcOldlkweRvo;
    }

    if (qjcOldlkweRvo != 150907.5639362803) {
        for (int KbwIsKSF = 1687300804; KbwIsKSF > 0; KbwIsKSF--) {
            IuLpNBl /= iOmmXG;
            qjcOldlkweRvo += qjcOldlkweRvo;
            JJWTsgaa -= BgDjj;
            LzXXnATZB += IuLpNBl;
        }
    }

    for (int qMJFIJ = 825713897; qMJFIJ > 0; qMJFIJ--) {
        IuLpNBl *= JJWTsgaa;
        LzXXnATZB += iOmmXG;
        KhnFrjZvU += rtoLjmWVCw;
    }

    for (int MDJOAXaGDtwlgdP = 310029446; MDJOAXaGDtwlgdP > 0; MDJOAXaGDtwlgdP--) {
        IuLpNBl = IuLpNBl;
        rDgzASuomIipez = KhnFrjZvU;
        fxChsVlv = KhnFrjZvU;
        IuLpNBl += BgDjj;
    }

    return qjcOldlkweRvo;
}

void pivYi::xXkWkSYlw(int tAeCvs)
{
    bool OyIAr = false;
    int jFdoyVH = 2039046823;
    int sGZsZnbWiUbpZf = 850889912;

    if (sGZsZnbWiUbpZf != 850889912) {
        for (int MycnwgWn = 1839511809; MycnwgWn > 0; MycnwgWn--) {
            jFdoyVH += jFdoyVH;
            sGZsZnbWiUbpZf = tAeCvs;
        }
    }
}

pivYi::pivYi()
{
    this->FbMtPbhsZPr(string("GzWKYxKaNOfgbJpB"), string("xJBOTukLoDJNtLbJrcOLajOjMlcYUuefONJnCkRGKZkzHUXCsVUwzzHZCLojZnaQEjXiYXBnqxkMfrjazsaLvIzvfACchlQtbkVBAlpizcmaeALGJpNethggEBluDhTTIinmyYqYiaDzorTKsvjsXzqdoYFhdHTGYqnPuDfIemHyuXkVztvfKAblwAHGEsiJIMpGfBmkJpAGQrjchqSgMpvspLjtGnyqGJgZu"));
    this->GeeYNwNZYnUbx(-1335126744, false, -655404190);
    this->jCUsxKBb(-1501178532, string("nsoTWrsO"));
    this->FMEfDJYzFVZ();
    this->ITxNMvG(string("dfcoAiTsPuFfWDDPqEObrrsswFhZgImWsdyteZsvfYALbjjNIeQUjbyLSqXpBofZHjzCDMHjsHhRPYyFVzaoYPOfrvYhIyiKZvfCraaxfMbiWTRxThVryealGanEqChfRuGGhPizixTAdimkNjXmotQKZfsmCfAiZVnjvsYcJsppmvlRZOAyxTQYpkIgeMinvvgsR"), false, -1632269598);
    this->GsDsoFdjMuYGdunV(470271491, -82249.23713516578, string("cOlCQvQZdodqoepwjSqpLlXnhHjQpyDvwfdQjbewrBzSGXJOJXULMgTqnkkXhgmHiNZacDcLUkapgpmlktObgtcZPLrezBHCceBjWkdwDCQLxevdfZbqWgeyrqABXnEZvDuMpBZoZblPcuaYDRpHeSWuXLDXEFILUmBLIHMYNyLGFWXxjVlZflFBkjmizAahWlrilNiQTh"), 1438632382, false);
    this->PNkDNcmJDKwSXLim(393082757);
    this->qJvTEWBkPo(string("crvRzU"), 585386.512144623, -269774.4501479652, string("ctPgydseVmpNmZsBYwyeZjSdibjAYLEEkmyaeHDNQpcPtscPYwPRFRDZVXaXqsIqXCnKKfDuisxLfuYqDTKyvmtZGjHBWWPvLWtJNiMAppTvCiEdIzeKgbSPzVKJqrZXunIrOGrvVfkIgfQDYSkhhXvHgxaOhZAwqRzueBAJSVJIfbABzjhQtww"));
    this->gWczE(string("wnSKRmeJIUFLeAliBCcJuZBAUFRtwWNtbypqLVqAw"), string("QHrjskCfqrfSbCsZDOKhVltTkVQGqdOhjVUvwoSDdLWMmGONACXrhsUGxAzbRBIL"), false);
    this->qPwUinftrrAaKyro(1266933439, 1575187108);
    this->lPPfpXI(1029632213, string("mREuJDjBrkbMprSbTYlYLAyMtRcYZNBJaKxMyWRloQzzONISxuytTbHMAQioIiYLqmieBEJEWecRKsYGgMEeqvLfFwiz"), -1132148724, -151540058);
    this->dqSYeeC(string("FVXlZBsV"), true, true, true, true);
    this->VMZScAcKYvYcXSrH(225572.19427414038, false, -1315624667);
    this->zBetJg(-1076614827, true, string("qworTmRUlkhuHfTbqAgWJNkHFfupzOoeQNaiCmiTX"));
    this->hohBhyPvz(1955982775, -1416250122, 413658.46887447615, 794105.3454081244, 129534.6401423857);
    this->ldQntPhRohANaIX(true, 893406.9177550315);
    this->eyKZXVbRzZCi(string("IjKKvwwCtjzVpZGwTyUlQzZYJRnzcKDKGoZjvLjVYzvwNhKtSTRyhfTphXYPUTsgdZXALVrEYltlpPilSvhSJryIhkPpmVZDhLyndCHlGVwdsftBLNwLMZURhEDCBpFWZgieIdKWgQdOpcMDvoGuuLaMueOoZgzHHjoTdtRLigexhmSgmniJUbrhJxDfmICefvzGSWRmUsMYXzY"));
    this->xXkWkSYlw(-1544737728);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tstzVuU
{
public:
    int FXfXCctxtjeZQew;
    double hqQirkEa;
    bool rXckhoDMtTZdgJRL;
    double DSZPKevcPdsW;
    bool WAmdzW;
    string dGoIu;

    tstzVuU();
    string SCGjmKrJfZ(string ayrlfppwqUk, bool PwJOtKNPTok);
    void UXAQklKzbI(bool ZAOkNstbXWDO, double qovPPWMtWNrC, string eTLXTIdbu, string eYgStlSxWmSBZgSW);
    bool tjNcoKHfXSYfeeAP();
    void vwsVLVu(string WqQkFKJICBZy, int ecfyfIxZax, bool SXXzRCEurbLKuCb, int uFakGOqxL, int orDpJJJAPbcwNG);
    string KcZKX(double FHEXPfTvElHnfF);
    string jeWfhDZOrl(double gcqHhwNXwJ);
    double TfKEpFyIEHGf(double NhSWfojOQFCzD, double qCLdposOVx, int LLaYI, int zsmRlh, string QxprpC);
    int DFpMGnSxNRjKJuX(string UOycUc, bool eIdXSHF, string dQqPCol);
protected:
    bool BFCDrXG;
    bool ygmiFDdwsSV;
    int NCAddCiDylOKZBgg;
    int iDpwGCkmv;

    double GELxX(int IUjtwjbcwB);
    bool BihLcrH(string qcIFWJXqJPo, string dfqOi, bool FRNeEyHY, bool eFUXrWNdNqNKVoZi, double xxdFgMpmvbsKisU);
private:
    bool xBhRHIFLsXeyggUI;
    string hHJldktLr;
    string UjVYssdxkS;

    void YIEsajxRdAs(string LRJzWH, double RUNiEGcPgkMwXjQ);
    void NbGKgCBNt(double gsFOKihQHqYitV, string GyJOW, double RKyxZAyvOMQnNyTb, double CzwOf, string dkQyWlYqtdj);
    string VcthieGDiXtgS(double qMutSg, bool rWGyvUXfhX);
    bool KPReGh(bool OVhdM);
    void vFWKrql();
};

string tstzVuU::SCGjmKrJfZ(string ayrlfppwqUk, bool PwJOtKNPTok)
{
    string yvjrUM = string("bxolqcWkqGBfKeSSusWEtjVgUYbkpyzVQVkyNLoDkMihYYObwafNkBTICpGtpqenmpjQuuVZnaDToDRERNOgkSqXdqAWpyTEnsfKidZkriDQfHNYNYRfOVOzeCVKGGGIHKvONeBZqdMSNhBfDTVqNJsArQHhPkRJOBFZukZpziITaPMUcWXfYahEidkEDVUKaapBOzMNfDsVQcoJtqqVTulNvkqtau");
    bool aqFtskk = false;
    string ateyGysYtgGqihE = string("xDVthmjTNFleIPsuolDAgjsgMiDbTDEOJfmkzrjdHVzDEJPlsjXDnPuPLHOQewQHLLvSpbESmcGBUkyYQkHytPcEkXemwuIIavtZiMTfAKAaQDkxRASkTVGsOHSmzBASVvYvZBWFDFZBUADCITEOKzAXJGNZiiFyFXWGDBkEsvpExxWCqlQiSLedtxNGmlDiLjXqZhPoLyZWpZZOVtEBVpIBubZxynHJlyPIxeJbeDyKGEfb");

    return ateyGysYtgGqihE;
}

void tstzVuU::UXAQklKzbI(bool ZAOkNstbXWDO, double qovPPWMtWNrC, string eTLXTIdbu, string eYgStlSxWmSBZgSW)
{
    int OwZdGwqRUTt = 381561703;
    bool iVVyWx = false;
    int IYpEdEuLIiVY = -754681685;
    string tEXLHFcVbb = string("fRRNErAWmdqmSVDmPFHWokogZmTaiaQzVPSSYwfBQCQnPkBGiTCyvYoXpHbOIeUtMhoKRNQIXHQudeSTipnoaDACSkBKuVaDqirtHpzhFvgUywdCPEauJSVWDwPHzGOUuZloimoYwYUSpksZACeNbwG");

    for (int qdygdhfsBcxtW = 1394974703; qdygdhfsBcxtW > 0; qdygdhfsBcxtW--) {
        continue;
    }

    for (int mCPPq = 1894674237; mCPPq > 0; mCPPq--) {
        continue;
    }

    for (int tQsQo = 1714022034; tQsQo > 0; tQsQo--) {
        tEXLHFcVbb = tEXLHFcVbb;
        ZAOkNstbXWDO = ! ZAOkNstbXWDO;
    }

    for (int YIGmLpb = 780980764; YIGmLpb > 0; YIGmLpb--) {
        continue;
    }

    for (int OnIGtSG = 1057643762; OnIGtSG > 0; OnIGtSG--) {
        eYgStlSxWmSBZgSW += eYgStlSxWmSBZgSW;
        qovPPWMtWNrC *= qovPPWMtWNrC;
    }

    if (eTLXTIdbu == string("TcNzEodwNbYSiCJaBfiNsOLXNiegIKYzq")) {
        for (int ZvhOUTRRG = 1025822810; ZvhOUTRRG > 0; ZvhOUTRRG--) {
            continue;
        }
    }
}

bool tstzVuU::tjNcoKHfXSYfeeAP()
{
    string SLnev = string("kMwkehjRWMffaICOrUEgAbzgVwYTEQFvPAAfaKfxnArtlnpMxuUsPsJtHWQvQCnDhqMaHcXwchfJsOXRWpcSlKSFxMthxZXVoVyAjZVqAlhMyinKQEbTMnbVuKVntsGEOACUozeZfrPldUOuespSoqgAyVFGEUJcuwOcPJxotKXqrIIloJavjNToPfHlBbzNRiGhLiYelAdxyqGaacIJ");
    bool hJuNHOyTBhfvsK = false;

    if (SLnev <= string("kMwkehjRWMffaICOrUEgAbzgVwYTEQFvPAAfaKfxnArtlnpMxuUsPsJtHWQvQCnDhqMaHcXwchfJsOXRWpcSlKSFxMthxZXVoVyAjZVqAlhMyinKQEbTMnbVuKVntsGEOACUozeZfrPldUOuespSoqgAyVFGEUJcuwOcPJxotKXqrIIloJavjNToPfHlBbzNRiGhLiYelAdxyqGaacIJ")) {
        for (int TVrpiQMEaSDJjTIj = 978717674; TVrpiQMEaSDJjTIj > 0; TVrpiQMEaSDJjTIj--) {
            SLnev += SLnev;
            SLnev = SLnev;
            SLnev += SLnev;
            SLnev += SLnev;
            SLnev += SLnev;
            SLnev = SLnev;
            SLnev = SLnev;
        }
    }

    for (int kxbIf = 2109565293; kxbIf > 0; kxbIf--) {
        SLnev += SLnev;
    }

    return hJuNHOyTBhfvsK;
}

void tstzVuU::vwsVLVu(string WqQkFKJICBZy, int ecfyfIxZax, bool SXXzRCEurbLKuCb, int uFakGOqxL, int orDpJJJAPbcwNG)
{
    bool piJAyZJehxjH = true;
    double vxPPqcAJmZz = -280116.9510599415;
    int tzfuWJf = 1208876553;
    string wiiYDWcBapSowG = string("JvyccMhkPrNOAOSslWkLvnWuCVbVlrWAr");
    double TDqmOWlUo = -215573.46625547987;
    string XXzVjvrstAODDTey = string("FCTuSreyXNZQsWBIVFhTUHBRNxaYnysjbOsMlqRsnfXCAyusDjBocQpJKLqwKOWjDMFJmYyRaHbNCEIHHkxAyZTCNYARCjEnthpBdpLJnTcitzZZqGTpzqauFObrzQvcowUmLqOYviLdtTVCzykqTDbOnaHSuJgyRmYhoujRWvbcZmcOnnUnkAOSpXdeTCsLNTF");
    string VaPbTjFVBfQvigro = string("rQHwyomSTFMUFMGRwAnVYxRZjNhNHNpKzPboZriYksJzhOZupfKmtZMPMyMLbcDGWZTZuSIapVSombMKgAGmtDINyesZNAbfcxFGrBKzGKZUnmTgRw");

    for (int QVOgqiULqF = 1935578605; QVOgqiULqF > 0; QVOgqiULqF--) {
        VaPbTjFVBfQvigro += XXzVjvrstAODDTey;
        WqQkFKJICBZy = XXzVjvrstAODDTey;
        tzfuWJf /= ecfyfIxZax;
    }

    for (int SbnykK = 1809807835; SbnykK > 0; SbnykK--) {
        WqQkFKJICBZy = XXzVjvrstAODDTey;
    }
}

string tstzVuU::KcZKX(double FHEXPfTvElHnfF)
{
    double XeQAlKGu = -289497.93348245235;
    int IuYMNfVb = -904935056;
    int RtRRrOzlkUL = 1173167023;
    int tqpozoHVUbKspU = 1075385258;
    bool pqaRFZxVfcttuGnG = true;

    return string("ULXsm");
}

string tstzVuU::jeWfhDZOrl(double gcqHhwNXwJ)
{
    string NblBhVYrQSa = string("EeixYnCkPAKkFlVapTuwHXzbHAAONqKtCcUmbVXMTPdBXrKEonPBINIrQpUfWIaNYkHoQQYQvYrqeaKVvetFDYpggtFwfuidQTRERqzlkKBkGQtWEsNERxkoBAvyOH");
    double ZjUFoaQipOHFZ = -52089.60715421282;
    string llCHn = string("WloHlHWqIPeNwwLYafemGkGzamrLeRpXhGKfXNmndVQMXlHsAiOJmeAsNsBvcwspQogkgViACaUHXikhoMHovoUMrzbdYfWFzSJVNqdwFxpzhPaEMpWvtJzaVNsFxoRNuyETZGkelmOSRtz");
    bool RFKcpmTa = false;
    string pRQNymBu = string("FXwsYiqDGlSJ");
    double CvIzn = -316769.2160674664;

    if (ZjUFoaQipOHFZ <= -316769.2160674664) {
        for (int WyyGSUNMofCh = 2031059937; WyyGSUNMofCh > 0; WyyGSUNMofCh--) {
            gcqHhwNXwJ *= gcqHhwNXwJ;
            CvIzn += gcqHhwNXwJ;
        }
    }

    return pRQNymBu;
}

double tstzVuU::TfKEpFyIEHGf(double NhSWfojOQFCzD, double qCLdposOVx, int LLaYI, int zsmRlh, string QxprpC)
{
    bool xOKqsmlqdnh = false;
    bool rczflrYcQu = false;
    string nCmfxafdqybmqX = string("pKkNJBqbLxnlOYHfYuNcDaKVYMmgTwgeKsLLDjlTxDuViTXbILMKIPAXDNeTwhAPKDgUQvRhiJiOlGNURTwFEeCvgrSQpbJpMbJKmrwBwnwOaWbybCWjWtgpqXXGdZCIUXZhenbrPNcNJdFqHDBAWWzRRGRUIWNTwxLnOoyDDVQDJhOkMbQEHKdgGIORQyAQXLnMxLvd");
    bool cyXffPX = false;

    if (zsmRlh >= 423866251) {
        for (int wmemsTfmiwhW = 1458312794; wmemsTfmiwhW > 0; wmemsTfmiwhW--) {
            NhSWfojOQFCzD -= NhSWfojOQFCzD;
            LLaYI -= LLaYI;
        }
    }

    return qCLdposOVx;
}

int tstzVuU::DFpMGnSxNRjKJuX(string UOycUc, bool eIdXSHF, string dQqPCol)
{
    bool emQvisSxtcmJK = false;
    int YDxNWa = 390130021;
    double KyYjw = 630228.1262804779;
    string vhyFAGutnDFwAwjv = string("cFchNRqmbhZbgwAjDoiAfMmsIosKvtyvrDmQXeHMjwLCjzKgICGIXznxqsyjxtYKyclwjqRkykESAMJndsxFjHpvPylrWseDDXTZwCwyHsyWwwOrfKqJKGHBZHxlXCxZMclKrtlfazaXHSRHJiYJvDuOrBjrijqsIrYKLEHSFKLHTwhyIVCBiMpZgmbqxgSKbfSubiPhnQTYBmVRrJflTvDU");
    double TBmxkiRTbFSDit = 524052.98928814725;
    string RQYnXlvc = string("C");
    int hGvoRtyEVH = 1607277841;
    bool PFAcKCxo = false;

    for (int gSilhiqTfJiS = 660022568; gSilhiqTfJiS > 0; gSilhiqTfJiS--) {
        continue;
    }

    for (int VSNMBnKvFmd = 299228074; VSNMBnKvFmd > 0; VSNMBnKvFmd--) {
        continue;
    }

    return hGvoRtyEVH;
}

double tstzVuU::GELxX(int IUjtwjbcwB)
{
    double GLzNyQCmZetuVPZn = 292694.66245763825;
    string njJWbCaUwlVYpGvg = string("TBJPfLnrQwImfaJXBKZOSJASqJhhnrTNwrKlvWwruXykbaiWLMJozcXhKOqPXHUBwxIMfojCNvlbCEUrVdHimNmdbMnCHeJiRGXtQSsuUNfMGVoUo");
    int xqeLaq = -549547148;
    string cvDMpUBQ = string("rdTtuDEyULTKqdDkeZDQdEgHWaLRrZdDuplYyJmnoDKygDueVVkxTZwLwAxHFXjeMxQSOsQFDwLfZNRnGQDZQDffsqCgTbvGHa");
    bool yfcgrAInaGiorio = true;
    bool qbwMHArkDkQO = false;
    double xqgabfjntcdEq = -476843.38654661033;
    bool RDEutlfYDnHgRF = false;
    double FJceESaJkMI = 584737.7007099247;
    int dfcssNMSBPtxo = -1463709925;

    if (xqgabfjntcdEq <= 292694.66245763825) {
        for (int YtdmUv = 1227771719; YtdmUv > 0; YtdmUv--) {
            IUjtwjbcwB -= IUjtwjbcwB;
            xqgabfjntcdEq *= xqgabfjntcdEq;
        }
    }

    for (int LQzAaQORhclK = 537120223; LQzAaQORhclK > 0; LQzAaQORhclK--) {
        continue;
    }

    for (int gHNfwsxOmbOIG = 1950129343; gHNfwsxOmbOIG > 0; gHNfwsxOmbOIG--) {
        cvDMpUBQ += njJWbCaUwlVYpGvg;
        qbwMHArkDkQO = ! RDEutlfYDnHgRF;
        RDEutlfYDnHgRF = yfcgrAInaGiorio;
    }

    return FJceESaJkMI;
}

bool tstzVuU::BihLcrH(string qcIFWJXqJPo, string dfqOi, bool FRNeEyHY, bool eFUXrWNdNqNKVoZi, double xxdFgMpmvbsKisU)
{
    string siOdEd = string("ZVRpTmbcAmYUXGuWJdhtBeJXQdqNCttRpmJDGkwHgkWYvmIPHanKhoYkJXBzVYVBhdIqCMwAVbibxBnvZkJLpvuukhOJIuLX");
    bool jYyXkgwZXYDIdSkr = false;
    bool tXuzJWySJ = true;
    string fwhaZYHQS = string("uUUabPLWiophpqQNQvhrhWFQZmyqaXdQtMRZgbzhUWiFldOpTUnmLSZTxhSgRSQxwpwNjeiBPNQjpFKjQGRYXKFTeOzVidEDIDyuzjGyNoRup");
    string XxsvTTFLcNhrvi = string("Ay");

    for (int upAdFvrK = 810840784; upAdFvrK > 0; upAdFvrK--) {
        jYyXkgwZXYDIdSkr = FRNeEyHY;
    }

    if (XxsvTTFLcNhrvi == string("LSvCjZpKDyAIhQdprrlhbRIJIBmUrEKiBBujhChYuQaEhkZZgWyHkgUJRzyIldvZfJHsyHnWDQGRunrQLTDpCsDaSuGeikXuAdmEwddDwOYCcFRBVhFHyRLizTQWWBLWQwayCuwjkIyVWFGjoiSitROG")) {
        for (int bablCzhFSkPQjiYx = 1276194241; bablCzhFSkPQjiYx > 0; bablCzhFSkPQjiYx--) {
            XxsvTTFLcNhrvi = qcIFWJXqJPo;
        }
    }

    for (int fVWNdI = 996127952; fVWNdI > 0; fVWNdI--) {
        XxsvTTFLcNhrvi = fwhaZYHQS;
    }

    if (tXuzJWySJ == false) {
        for (int GdAfgIMYK = 1272051377; GdAfgIMYK > 0; GdAfgIMYK--) {
            XxsvTTFLcNhrvi += fwhaZYHQS;
            dfqOi = XxsvTTFLcNhrvi;
            dfqOi += dfqOi;
        }
    }

    return tXuzJWySJ;
}

void tstzVuU::YIEsajxRdAs(string LRJzWH, double RUNiEGcPgkMwXjQ)
{
    double iHRWSRknAGi = -575511.9441948156;
    int rPeFfNXjld = -1567894505;
    double okPQPwQuqvOl = 153370.92404499438;
    int QjoBLrADMm = 335617365;
    bool yaRBk = true;
    bool WeMaI = false;
    int thsrJvqS = -563400512;
    double lvqAk = -404806.3995339779;
    int GEarMINVIPGrB = 693249728;
    double ZeKjaTu = -806677.953782784;

    for (int UvnkBbvKVLOC = 1445791587; UvnkBbvKVLOC > 0; UvnkBbvKVLOC--) {
        thsrJvqS /= GEarMINVIPGrB;
        okPQPwQuqvOl -= okPQPwQuqvOl;
        ZeKjaTu /= ZeKjaTu;
        RUNiEGcPgkMwXjQ = okPQPwQuqvOl;
    }
}

void tstzVuU::NbGKgCBNt(double gsFOKihQHqYitV, string GyJOW, double RKyxZAyvOMQnNyTb, double CzwOf, string dkQyWlYqtdj)
{
    bool jgsDIYkh = true;
    bool tkmSPp = false;
    int rAvJnL = 1131230253;
    int RylYLcrLHJK = -1384856348;
    bool ecbDmhmDcmms = false;

    for (int EHsnqWAiu = 935202264; EHsnqWAiu > 0; EHsnqWAiu--) {
        GyJOW = dkQyWlYqtdj;
        gsFOKihQHqYitV /= gsFOKihQHqYitV;
    }

    for (int DkXbPAFgzyiqqRDZ = 229241557; DkXbPAFgzyiqqRDZ > 0; DkXbPAFgzyiqqRDZ--) {
        CzwOf -= gsFOKihQHqYitV;
    }

    if (gsFOKihQHqYitV > 371695.88067854097) {
        for (int HuBBPzEckkOBwrq = 1440856916; HuBBPzEckkOBwrq > 0; HuBBPzEckkOBwrq--) {
            continue;
        }
    }

    for (int XLUScvQStS = 196643024; XLUScvQStS > 0; XLUScvQStS--) {
        ecbDmhmDcmms = ! ecbDmhmDcmms;
        tkmSPp = ! tkmSPp;
    }

    for (int qzMXZhegwmUM = 367618572; qzMXZhegwmUM > 0; qzMXZhegwmUM--) {
        RKyxZAyvOMQnNyTb /= gsFOKihQHqYitV;
        jgsDIYkh = jgsDIYkh;
    }
}

string tstzVuU::VcthieGDiXtgS(double qMutSg, bool rWGyvUXfhX)
{
    int kCzwiSxcbopARMMj = -284684910;
    int diKOFyPWj = 1942697702;
    double APiZpDxw = -684393.7357640561;

    for (int eHoRDyFpt = 735761490; eHoRDyFpt > 0; eHoRDyFpt--) {
        APiZpDxw -= qMutSg;
    }

    if (APiZpDxw >= 419623.9231796465) {
        for (int yLoVqmSLGeFiVW = 797677923; yLoVqmSLGeFiVW > 0; yLoVqmSLGeFiVW--) {
            rWGyvUXfhX = rWGyvUXfhX;
            kCzwiSxcbopARMMj -= kCzwiSxcbopARMMj;
        }
    }

    return string("TENhQyTsriFMBuCmxBTerXXNLFDTWyFOnoOoITuqCnLIjMEzkvfOntbtqOkarkXWtbVwaNNCyzNQkCDNniFyMAfzIVPSNWLcfEkWwcvccPJJTPLPnnsTdBbDxTIzWOwhIsPPyyauICTRSBkOLOUNCzqGxKRkKxoeCpOcuRpmRoigXItQdredAWONNOCJkfgEtKtVxsDOknxfHxdmngAimazC");
}

bool tstzVuU::KPReGh(bool OVhdM)
{
    int fFMIfXpCFmyVcb = 880230105;
    string fmuyVzWzzrmnD = string("hWkArhfEssDRpDxNEyHeItMAuwViaLdcQUWzsxzmZJGGZhFVifOwThHptsDKyrxFMebETtiixdXwrVwnnwMWJOSDKkgkIAHSBbNtzyzWEO");
    string XcXAMIrTvh = string("uEhxbAwaxeGhfCZjSAVHcIsfGXHSJnkEykhLDPwMAiRaFfKPLKpmWfRyDkJMuUSVfsFOJbwMDmnESmIpMpOXexGLNOIueSecPqjEkrlJCcXLGYQhfgjAYqSJLjWzLyUUntREnkvZCgwMmFAmjQ");
    string ecAgCvcHdrc = string("jwjIuJqDqNSGgRSftxaQIZvPgDorlmcGoPUdNSVAPSvHGdayCywkZnIHZeHHdXNtpYOfCcupEQwMMFnhDjwTHMhgaMwFucDqe");
    int FnLzNduWievnrXyS = -338292266;
    int DuOSdYDnld = -233359675;
    int xkDGOiKuN = -1590714946;
    bool PIDkrc = true;
    bool wMhlNdNjeKpvDMN = true;

    for (int RGzvX = 1477390043; RGzvX > 0; RGzvX--) {
        OVhdM = ! PIDkrc;
        fFMIfXpCFmyVcb -= fFMIfXpCFmyVcb;
        fFMIfXpCFmyVcb = DuOSdYDnld;
        xkDGOiKuN -= xkDGOiKuN;
    }

    for (int UYEVWYSC = 1338862130; UYEVWYSC > 0; UYEVWYSC--) {
        DuOSdYDnld = fFMIfXpCFmyVcb;
        xkDGOiKuN /= DuOSdYDnld;
    }

    for (int mhyldxlOqXoqqgXs = 1870313152; mhyldxlOqXoqqgXs > 0; mhyldxlOqXoqqgXs--) {
        wMhlNdNjeKpvDMN = ! PIDkrc;
        FnLzNduWievnrXyS += FnLzNduWievnrXyS;
        fFMIfXpCFmyVcb += DuOSdYDnld;
    }

    for (int sSdIwMejkXN = 1574381611; sSdIwMejkXN > 0; sSdIwMejkXN--) {
        OVhdM = ! PIDkrc;
    }

    return wMhlNdNjeKpvDMN;
}

void tstzVuU::vFWKrql()
{
    string vETGceBGggBSeJG = string("SQZrGwgNZevGdzaACMmyRDTByxDYffexMeDaPSnfDZnZChKoGfGtpLzjJyjshGHRKZiKxAMyabaKTtzQoBvRemPalktCrzPSEZPOQnNLPmEGguIpqnZyhhWVMMmRuHeFcSzhsmSXIcOYrADMFHgKBYLCiALVSADuVxVhMBksVpMNUSMIZBWofZYVf");
    double LUdkbQchNK = 190509.89589715586;
    double zAjHb = -48376.46899267299;
    bool aPeWULeGvI = true;
    string FLGTHkuI = string("crmefaJudUDEUTZywRwYYVohfqcwKQtcLdTJpWMqtIbLSeIKbJ");
    bool LoBGxawAxTjYdzXY = true;

    if (zAjHb == 190509.89589715586) {
        for (int pApmXcFWeotS = 1510790202; pApmXcFWeotS > 0; pApmXcFWeotS--) {
            aPeWULeGvI = ! LoBGxawAxTjYdzXY;
            FLGTHkuI += FLGTHkuI;
            LUdkbQchNK -= zAjHb;
            FLGTHkuI += FLGTHkuI;
        }
    }

    for (int rGUnmiCndb = 787771920; rGUnmiCndb > 0; rGUnmiCndb--) {
        continue;
    }

    for (int PZdiabbX = 1071412738; PZdiabbX > 0; PZdiabbX--) {
        zAjHb = zAjHb;
    }
}

tstzVuU::tstzVuU()
{
    this->SCGjmKrJfZ(string("boxxbWPWgeIqxojsgESwKWdwlOqJkbWIPdghtjfQZiKnjcPziKXfbFPXQVlkuwJPs"), true);
    this->UXAQklKzbI(true, -292501.68946143525, string("WOdfDQZDqFmQyaRvzpfPyDjHCbELOepPIzLMVcFtoOeRTHnFxcZFTihVrFWVUWQUBKnzbTNrWkrCebgKtGsCKEdBkowjMKMiKGmIx"), string("TcNzEodwNbYSiCJaBfiNsOLXNiegIKYzq"));
    this->tjNcoKHfXSYfeeAP();
    this->vwsVLVu(string("MuApWagyqcIGAixJIOnPRhtMqqpMHcesVUGjiiIEnsCpJUCQsCtwkKhXNqdDaenr"), -493124080, false, -2114986523, -240652588);
    this->KcZKX(522490.0328993518);
    this->jeWfhDZOrl(-504701.1336864231);
    this->TfKEpFyIEHGf(969611.731509336, -32144.527461069327, 1834985011, 423866251, string("SAMjEEcNncxPgPRyqrtvoopLqzjsEvAcqLKPFDJkXTqqtyxPbDrjvLnBcDBIxspakpxOTYKsBzasUfKRtlEerFKYIilzqWUXwSjhEAJRcVyNVRVoISiWl"));
    this->DFpMGnSxNRjKJuX(string("oxnLaELK"), false, string("YemXNaOaxmnNKKHwtvfswxNcdnxfqMAFEdbJUmHpZWRwKvWaMHlSfSvuamhiNSOPrGwgEorffsUMqwjcOyecknKvdPjjPhWNYeJKQjlBdOyRWyVsgkNXqSieNFJyxEQTMPnAPAcudMAoOkugnCYWLskIbUGPPaBidiwBjlPwxHSByTsQOlltrTKuDqizjkGiUkMpVcHLORtLjFfjbjyPVSKdeUWvVcLqkkFNRCeM"));
    this->GELxX(1627875200);
    this->BihLcrH(string("LSvCjZpKDyAIhQdprrlhbRIJIBmUrEKiBBujhChYuQaEhkZZgWyHkgUJRzyIldvZfJHsyHnWDQGRunrQLTDpCsDaSuGeikXuAdmEwddDwOYCcFRBVhFHyRLizTQWWBLWQwayCuwjkIyVWFGjoiSitROG"), string("CaLSTQRDWKVjNpzOahxZXFGkHrFOTnonoxbFCziZAurTMxtZGBVjjjRMhfKSwdrrmtjTANQloqKfHEyPLSpMtSKXhYTQbrKpERgvqASoTYxxYqBwBybiwbwwdtMihNYfuRjbyIDEUyqiJkYsmOQLTtTTqkWswioUNuPBXTWVEQUADDxYhqNtVFvDA"), true, true, -784284.5718492512);
    this->YIEsajxRdAs(string("NCvyLWupfxZAlakiJcUECDZjzoRysFbxviFxJJOWzZvtTwqZeypX"), -1035110.7098290131);
    this->NbGKgCBNt(497111.09142681066, string("FiuMZTlXulgbkDtkDALPeAPnNKBrzcVcJmxUNtCyCRqaRadUwheLahdzvdZVoofXEpuxZKofsdbMpQHivGHhmXIr"), 55832.24378499864, 371695.88067854097, string("GbkZMpMxLSiuBwSBSwsgjzLYOTbeRUrDTazIkYKKPuTWoxGemYtyTRN"));
    this->VcthieGDiXtgS(419623.9231796465, false);
    this->KPReGh(false);
    this->vFWKrql();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zlYixuF
{
public:
    bool DcBACDhxWyB;
    bool GHxQdxjvVDs;

    zlYixuF();
    void xonqgY(string bdOsJzGONdYUQaiQ, string Blybc);
    double cDOVwFRqKRHxXtJ(double QWXHf);
protected:
    int ioHwStmiLJyHY;
    string XNfdkshZKh;
    double kQUNrDs;
    int cygTeKYEeC;

    void YDkQh(bool kJoLQzFEyQGIYnHC, string PzjjaprqvpSj);
    int vihdIUsEP(double USOCBqcAsGEAB, string SKHgbxdzecy, string hfKAdtQTACbLgj, string oysqUZc, int NRCuPUB);
    bool vxAlBaf();
    string vSZXzalFj(int wvgnVnlPDx, int cDgKY, bool UYSkxXJ, int FHshxGjKUIbqec);
    double JtXXGJYNdS(string kIRujvupQwjwO);
    void CMltciBERmZtQvDN();
    int CcDZwT();
    bool kYePNPZwcUY(int YUyunfRYuD, double sPLDTaXBuDXK, double swTMsLGdI, double XBDsLEEXaRb);
private:
    int dOpxAntdCy;
    int kWJeHGUrFvZkv;

};

void zlYixuF::xonqgY(string bdOsJzGONdYUQaiQ, string Blybc)
{
    double udnorHQG = 581157.8564848832;
    string jHqQPdOKgSUHKrV = string("pdEdqVAWiqYiuFEJiefHqjPeqxUvKWsxyXVKXOMgOOJhxKuclZMJTrjelbcAUFnGZwMpFKuRTcsPftuJsJsAqlUOtwdztakrRUWSlIydEzWvDIZYJfkHFuRRrXUFkOziEEyJsiziZOCAEMeXXSyStVVqcCUrRVjDGDeHHnqPzGuXKuITlsIaDPyTaApuVOTpNFmzFHnjXmsfdiTiHeecJLuVgtzdWivRIbUZdySr");
    string rjyBumOFXpNMjMV = string("hBPAfkSzMmNGIZAxNzVnQOJIkGXWUFkZRbpBPomactvUVqcKJekhkYbshSUmJLUpjzkqwzknFfjcLEZkiqoWiusvIgomLKcfSyQClTaNGnsLVdHzTVPOKWCklZyTyUTdBqckFJrpqLANczuGfsfkQliZeCxOGKmwLnngEvIbJlzSVqkyEhLMcEnjTzvgdKMbSHXHTxymsrNjHCxAJmmIlkAXbqFgstKxwzxXvpJNQxSvgEHAYsdKFE");
    bool TSZsNOlIQuikIKQe = true;

    for (int ympZDTasQdYyQr = 1393271995; ympZDTasQdYyQr > 0; ympZDTasQdYyQr--) {
        rjyBumOFXpNMjMV += Blybc;
        Blybc += bdOsJzGONdYUQaiQ;
        bdOsJzGONdYUQaiQ += bdOsJzGONdYUQaiQ;
        rjyBumOFXpNMjMV += jHqQPdOKgSUHKrV;
        bdOsJzGONdYUQaiQ += Blybc;
    }

    for (int HGCdaEX = 1845956068; HGCdaEX > 0; HGCdaEX--) {
        Blybc += bdOsJzGONdYUQaiQ;
        rjyBumOFXpNMjMV += jHqQPdOKgSUHKrV;
        bdOsJzGONdYUQaiQ = rjyBumOFXpNMjMV;
    }
}

double zlYixuF::cDOVwFRqKRHxXtJ(double QWXHf)
{
    bool CRGlmFCkTWnYi = false;

    for (int LbUwiydhIVYlBg = 687175080; LbUwiydhIVYlBg > 0; LbUwiydhIVYlBg--) {
        CRGlmFCkTWnYi = ! CRGlmFCkTWnYi;
        CRGlmFCkTWnYi = ! CRGlmFCkTWnYi;
    }

    if (QWXHf <= 899491.8299372172) {
        for (int BidZiJTn = 160861731; BidZiJTn > 0; BidZiJTn--) {
            CRGlmFCkTWnYi = CRGlmFCkTWnYi;
            CRGlmFCkTWnYi = CRGlmFCkTWnYi;
            QWXHf -= QWXHf;
            QWXHf *= QWXHf;
            CRGlmFCkTWnYi = ! CRGlmFCkTWnYi;
        }
    }

    return QWXHf;
}

void zlYixuF::YDkQh(bool kJoLQzFEyQGIYnHC, string PzjjaprqvpSj)
{
    bool CIFsS = false;
    string dQpDeFEfClFCPzB = string("QOrUrjslOVmcLeJQoLFVOpEvSLJ");
    string eATXiSigBdrvThDS = string("uGnsgqPhmdGaBnaOaYhUSIojtankhGPIkKzhzggzWnQXbWilaVRicyMtPAtdLXaMpXBMOYvwMLTgmkENavbHGihhxAzgKRVMgTcUYBmCQQXJgGJbOYBfqIMbuwNFrmxdhtyKTNbCdDPflLTOwCWxkzXtXAGMfNBaPaqurpQejNdVQZ");
    string velayPUO = string("SIedVAoFpEVrCSNtqBfdPoXpoTjyidKPXNdSFPddXlrdGIYRHUgaHzJIqlqITmqfPQIHgqZNZfAMajPqSPSzDbosFfgKcJgxfClnNjPRiJVdIdaGItadqedqgsSwJfPwkCHohDFzAdtoBL");

    for (int LwsGIMyNNAS = 2053007135; LwsGIMyNNAS > 0; LwsGIMyNNAS--) {
        velayPUO = dQpDeFEfClFCPzB;
        dQpDeFEfClFCPzB = velayPUO;
        PzjjaprqvpSj += PzjjaprqvpSj;
        velayPUO += PzjjaprqvpSj;
        PzjjaprqvpSj += velayPUO;
        dQpDeFEfClFCPzB = eATXiSigBdrvThDS;
        CIFsS = kJoLQzFEyQGIYnHC;
    }

    if (kJoLQzFEyQGIYnHC == false) {
        for (int hRBUPPCW = 55797053; hRBUPPCW > 0; hRBUPPCW--) {
            dQpDeFEfClFCPzB += PzjjaprqvpSj;
        }
    }

    for (int LJkGfpR = 371886496; LJkGfpR > 0; LJkGfpR--) {
        PzjjaprqvpSj = dQpDeFEfClFCPzB;
        PzjjaprqvpSj = eATXiSigBdrvThDS;
        velayPUO += PzjjaprqvpSj;
        PzjjaprqvpSj = PzjjaprqvpSj;
        CIFsS = kJoLQzFEyQGIYnHC;
    }
}

int zlYixuF::vihdIUsEP(double USOCBqcAsGEAB, string SKHgbxdzecy, string hfKAdtQTACbLgj, string oysqUZc, int NRCuPUB)
{
    bool xsQmAjDCuIFA = false;
    double zZjKVpvGFS = 380757.5193901926;
    bool bGKvaDtFgJRbSQTZ = false;
    bool FYqTTvk = false;
    bool SybmASdj = true;
    int svArjIDraM = -734261569;
    bool VNGBqHZzlQ = true;
    string YeysZU = string("zNJCpIzcNtIecOZEqdYVEOOHfyZWWSrJoGycqjGplFbhnjwWEFbbsXjgkAhGVLxMksCAQrDFOTpnbUoRdeSUDtNYpanSFOfWEDPUuraCZgKMdYiTLPCLjSENXkNlHbkurmTbynRTDFGxMeaNIvxBuiABVexxQsPVqcYqNRWVAcrbvaBJFYEKVaSfrmvjSFxXtlbpSCFuCQUUaJUHjjXWRqyKAkyhHqMegQJ");

    return svArjIDraM;
}

bool zlYixuF::vxAlBaf()
{
    double mjQUUPcCpNWtWJym = -343764.37242664915;
    bool LByYOaqbHCYPl = true;
    bool XCjaYxhlktlrg = false;
    int RADIvXJxVWB = -724482249;

    if (XCjaYxhlktlrg != false) {
        for (int GuipMRpdpmGdZTqP = 965901555; GuipMRpdpmGdZTqP > 0; GuipMRpdpmGdZTqP--) {
            LByYOaqbHCYPl = XCjaYxhlktlrg;
            LByYOaqbHCYPl = LByYOaqbHCYPl;
            RADIvXJxVWB /= RADIvXJxVWB;
            LByYOaqbHCYPl = ! LByYOaqbHCYPl;
            LByYOaqbHCYPl = ! XCjaYxhlktlrg;
        }
    }

    return XCjaYxhlktlrg;
}

string zlYixuF::vSZXzalFj(int wvgnVnlPDx, int cDgKY, bool UYSkxXJ, int FHshxGjKUIbqec)
{
    string ykbYOETEA = string("QbwuLAwmiqtcyBkWdgCwFgCBJDtxaMbaDiBPXZyu");
    bool psxasgxm = true;
    double KbLhXjleozxdC = 635674.6958994654;
    double jyooIsg = 352736.8366728857;
    bool HJhFuows = true;
    double rlNtiFLogwfAPVwh = 548239.9388948809;
    bool TklTujNqq = false;
    string aRIjLWhlMw = string("FsihfAKMkxlmHyZqubAPIzJxNeGccXdUStDNoRODrmwhcLsutjEijamhQFgeQOKVlmDnGEXcdctEvHYnRlhuDtzBULAqvhghCeWoPwiwIZbskGgXcGrQkwHTSwHjoEjBKPctNKtAoHdTqyBXBYvCGZIoPYzuRzWiWwqPpfdaLRMLuPzdZowwLFrgTHqjILTqQK");

    for (int AoJBSh = 931011106; AoJBSh > 0; AoJBSh--) {
        continue;
    }

    for (int JMgbjCHCxVHvLL = 971451147; JMgbjCHCxVHvLL > 0; JMgbjCHCxVHvLL--) {
        jyooIsg *= jyooIsg;
    }

    for (int uiSnhtlNRSM = 597299142; uiSnhtlNRSM > 0; uiSnhtlNRSM--) {
        FHshxGjKUIbqec = FHshxGjKUIbqec;
    }

    return aRIjLWhlMw;
}

double zlYixuF::JtXXGJYNdS(string kIRujvupQwjwO)
{
    int GVZWTLvZ = 598600596;
    int iurslYMeS = -1476610634;
    int FlabJLhgxzwcCD = 1806016489;
    int WdOdarepabyhaAhr = 72176796;
    bool PupcYyasad = false;
    int TFeOXTdZprtcvMd = -1890831281;
    bool ZksRmVNEJodDb = false;
    bool GGrCW = false;
    double ppIPwuUcOqAJ = -380404.95328772534;

    for (int gdXfjvUUXvcNA = 1899723100; gdXfjvUUXvcNA > 0; gdXfjvUUXvcNA--) {
        TFeOXTdZprtcvMd /= iurslYMeS;
        GGrCW = ZksRmVNEJodDb;
        WdOdarepabyhaAhr /= FlabJLhgxzwcCD;
        GVZWTLvZ -= WdOdarepabyhaAhr;
    }

    return ppIPwuUcOqAJ;
}

void zlYixuF::CMltciBERmZtQvDN()
{
    int LomFuf = -1750335359;
    string ZTAUHDLreFt = string("PODozjkyPCGeezGjQxJinbRiqfCEZRbXIEiHrOVCaCRULKPLBiGLiZPbIAiPLAbErZmVVkYufSebsgURfwAXCZsuuprgwgrVPWefZRJLAaAhvieOiDxZbHqxnHeSZHBYLAHVnYEeLPhEWOZSbjTXwcgCEuUEeGCeivAkyEWviuVoAJFVGjjgVsEujWSaYAUmZTk");
    int aDbZc = -653518480;
    bool RRjRACfSHtcNR = false;
    double gHqqjI = -314906.17185341526;

    if (LomFuf > -653518480) {
        for (int xJdCGrrAxXJPUo = 1632712551; xJdCGrrAxXJPUo > 0; xJdCGrrAxXJPUo--) {
            RRjRACfSHtcNR = RRjRACfSHtcNR;
            ZTAUHDLreFt = ZTAUHDLreFt;
            ZTAUHDLreFt = ZTAUHDLreFt;
        }
    }

    if (LomFuf >= -1750335359) {
        for (int TeVfv = 1308379226; TeVfv > 0; TeVfv--) {
            continue;
        }
    }

    for (int LuCjKzQhiA = 476535072; LuCjKzQhiA > 0; LuCjKzQhiA--) {
        LomFuf = LomFuf;
    }

    if (RRjRACfSHtcNR == false) {
        for (int ApfXgIrj = 1268482102; ApfXgIrj > 0; ApfXgIrj--) {
            continue;
        }
    }
}

int zlYixuF::CcDZwT()
{
    double UDKSxAgVNnT = -68236.08546010804;
    bool JQlySEVMW = false;
    int mUwBBy = -1466612851;
    string DvNwjMTMWVpbrom = string("oMWwNyozOmiioKrIlpqjgHcLExDAFoZbrwqjdBFZgAUVTyknNbXGDtRCPrQNkZOUhAnxpTFaOgjrMphWJODGSIZdvLHkQTFLaHzMkRBXNnUnKOScfaCwuRLuZBLLduRdaNpb");
    int kfQUFUqRgU = -1660883268;
    double oyNmuULWZAIFYO = 396712.079309329;
    bool iGcppbx = true;
    bool LbeSNUkskTA = true;
    int fOgMC = 603441654;

    if (LbeSNUkskTA == false) {
        for (int MNpSe = 1169896135; MNpSe > 0; MNpSe--) {
            kfQUFUqRgU *= mUwBBy;
        }
    }

    if (fOgMC != -1466612851) {
        for (int zadXjcflffEQ = 1529402567; zadXjcflffEQ > 0; zadXjcflffEQ--) {
            iGcppbx = ! iGcppbx;
            DvNwjMTMWVpbrom = DvNwjMTMWVpbrom;
            fOgMC -= mUwBBy;
        }
    }

    return fOgMC;
}

bool zlYixuF::kYePNPZwcUY(int YUyunfRYuD, double sPLDTaXBuDXK, double swTMsLGdI, double XBDsLEEXaRb)
{
    bool UgWAGsyI = false;
    string BKkDBglD = string("TBlWTNcwQiozTrthrxxQSdVTdgEbamQloauRWqgCIQXGsIEtJHrxLZHgfYZiZkDnueFJLSviIaOCaGgQTRsuGnGdwaDJBqjSIJpdTLzbGBFAcUnuxDdYxItKSeAHGqBmxZvDqIVfefUDripVwEKENrEsUfUmuDlXCIKDhNkeoGaMpFOEETpRnAiUnMegHvWgJqtgNwzjVMzItLyDpMbNyscmZMhtHoLqCObCAALYEeWsYlGaJdfHSFfhraVS");
    string AbWgYpgnH = string("xoRFvjILCgkqYSqYzrvslMfXdJfSNwWLBoxmdhiLrworZzIrD");
    bool MQgsJl = false;
    double VYmOi = 347455.4439897719;
    int YMaiWghSwv = -2084537942;

    for (int uedgVRkYBJrqrsSX = 1913503175; uedgVRkYBJrqrsSX > 0; uedgVRkYBJrqrsSX--) {
        XBDsLEEXaRb -= swTMsLGdI;
        swTMsLGdI = sPLDTaXBuDXK;
        swTMsLGdI /= VYmOi;
    }

    for (int ddSDQrast = 1021054729; ddSDQrast > 0; ddSDQrast--) {
        VYmOi -= swTMsLGdI;
    }

    for (int LjhsqLaM = 1938407371; LjhsqLaM > 0; LjhsqLaM--) {
        continue;
    }

    if (VYmOi < 38617.692490249574) {
        for (int NbvcVC = 696181041; NbvcVC > 0; NbvcVC--) {
            continue;
        }
    }

    return MQgsJl;
}

zlYixuF::zlYixuF()
{
    this->xonqgY(string("uFqbBUSGeDgFaGOuUNjSNzSmLlUKIuzhTpUhocNaTVzPzWlbrXqzbJRxToGXcuSbdinyJubcNcjGOfJmHoOdeXsgBgWYbIeHfVHWtWjOGPMOjOiDOIobVtmTpWLsQXDMLLYOVhBYKDZSJsHBOIOUFVhqWSnxIiPAspPSJWRYLQmQTBCyLvaSFTEyGYCQrffHP"), string("vwMACcgqjfSwvOTKxOcsuWvIzhjaXqiDLysWDHhwGVjYBkgzDipBJFLBkCEBrmEvTSCGGUtcSIHpJmhrzhEFHRcCeBnBIShyhkhXoxTGaZaLaoAwFFyKYLERkByuIUCnhYlmikH"));
    this->cDOVwFRqKRHxXtJ(899491.8299372172);
    this->YDkQh(false, string("VcmuSZdMnDlOgepPYAtCJtkIchfyaznGotmhGEOqpwdaOaofSPvMJmxKluFmkDjueOZyfICBYpqaONlDxuwgdjUQCISQlLbRRgjHzzfOblMZcIUdNaRoURybKcnkWYObRIouCacsnIIuoyVLsPhVLEJWtZABAoTsreTQGTxCmd"));
    this->vihdIUsEP(-575385.9446999285, string("CPmkyKKJEUweD"), string("JyqydgJYMtxyEhlcDsBcmORvOQbQCvqaKxUPWPnXYCFqLwmNWudlrdVNFXRoZKGLLVqzacxfMZOZmhkklgjLvfVJItClDlzPMXgghVEIxuJTllcqJqURkaWcCIhSgvyrJdHAjRBdoarDgxWRqrPTCs"), string("LvhcadUzTCmXTcbBwgxOgpWOIxQLossGBSCJdnlCPgs"), -1541293270);
    this->vxAlBaf();
    this->vSZXzalFj(1821929174, 794486154, false, -1391853267);
    this->JtXXGJYNdS(string("RZioZmhWfislHZQETbKJqfRhktsTPWuOMmpDFKtPtnakEEyNpQwGyswdoxLWtHdeGgBoZHITSIGMIuYsAhmrwXsruHKuuUyBCUHDbkLBndqWgRVMiQAClcxVHWetGnOrQFTHpUdJCgAEcoKlqurmklNABNdbdHmVVCgpFzDNpbZnnaNDSfGnengJFXrrpjpGnsSRJ"));
    this->CMltciBERmZtQvDN();
    this->CcDZwT();
    this->kYePNPZwcUY(-220795162, 38617.692490249574, 490470.04499829205, -31139.57981135961);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gQMLe
{
public:
    bool xVIHB;
    bool OCsIyuZTNtxVfMJ;
    double AxVSxzrQtfkXd;
    string PwRnAZMIzYXwX;

    gQMLe();
    void CyooZfcRywfqTUd();
    bool xuxlxqtwSgA(double kQHeXVujStnTVjCH, int XsCvLuCguFhT, string XbokSXaLlLaUPdA, string JilfhRENBcfco, int fSMhVUsXpwcWG);
    int kaUfA(int gqJzCRGE, bool vdFNYnQXrUCfQpxM, bool VtYPhZtucUN, bool gTrdD, int CQUtnJTIgmmaIg);
    int gYpTJ();
    double MoGbqOR(int cfXkxdldXsvYX, int LkrgGOM, string pUXqGPcpiLDf);
protected:
    double lNNsExzFDk;
    bool rZsfUpywtcGEnaXZ;
    double AuSYSbljZtNYYixq;

    double AHFERG(double rvViqDDTyNv, string PGreMNybLPQQg, int dpaMPi);
    bool jGRkHbee(double IaKVNnsuptC, double SIVmuZ, bool DDKTd, int MvFNk, bool qfPhbZnJW);
private:
    int BneupjpSeAVWSl;
    double OigzHWsd;

};

void gQMLe::CyooZfcRywfqTUd()
{
    double DzgALi = -453924.8561713933;
    int TEoekc = 159585453;
    bool XqLqFd = true;
    double uxIDuRFC = -87617.0378714042;
    double sWVbFDgmjIJI = 370638.66224037745;
    string CvrmAGjtarm = string("NgwEOcQKDcvVcPWGRZMcFmmWUTXmEsXISTiexbdrVnjLdZdZDrFYXdBOIEwRekTNvoRVFZtIwhovTLujmumrdTfldjotUNGNcovFleJbIEuNxlcQBzMFHyvBwSwHQyMVxlEsfvmxEaSBrwkbbaXzREvxfoUxqEFMNBSLA");
    string rmnunPo = string("RyAMKQWSVZswmyFlyWuKjfBsINeVtvqpGnjmEtZaPtEwHoUpfjIfAWthazFFLayCnHqmXXHYwdfIDVnnMzqhMpiaIceOPrFsnOKpNoZoqcklZxBpdBPpTAaGxtDL");

    if (rmnunPo <= string("NgwEOcQKDcvVcPWGRZMcFmmWUTXmEsXISTiexbdrVnjLdZdZDrFYXdBOIEwRekTNvoRVFZtIwhovTLujmumrdTfldjotUNGNcovFleJbIEuNxlcQBzMFHyvBwSwHQyMVxlEsfvmxEaSBrwkbbaXzREvxfoUxqEFMNBSLA")) {
        for (int LSNQhxwwLSxUm = 1362598439; LSNQhxwwLSxUm > 0; LSNQhxwwLSxUm--) {
            DzgALi += DzgALi;
        }
    }

    for (int FpGzFHwWyymBF = 1343148472; FpGzFHwWyymBF > 0; FpGzFHwWyymBF--) {
        continue;
    }

    for (int FQEvqntukRRrJEh = 380484388; FQEvqntukRRrJEh > 0; FQEvqntukRRrJEh--) {
        continue;
    }

    for (int jstGOalVg = 307301803; jstGOalVg > 0; jstGOalVg--) {
        CvrmAGjtarm += rmnunPo;
    }

    if (sWVbFDgmjIJI < 370638.66224037745) {
        for (int vuDner = 1223775074; vuDner > 0; vuDner--) {
            CvrmAGjtarm = rmnunPo;
        }
    }

    for (int OUJEtVRH = 593585783; OUJEtVRH > 0; OUJEtVRH--) {
        CvrmAGjtarm = CvrmAGjtarm;
        CvrmAGjtarm = CvrmAGjtarm;
        sWVbFDgmjIJI *= sWVbFDgmjIJI;
    }

    for (int XBBHvjtTwVILkiG = 415808915; XBBHvjtTwVILkiG > 0; XBBHvjtTwVILkiG--) {
        CvrmAGjtarm += CvrmAGjtarm;
        TEoekc = TEoekc;
        XqLqFd = XqLqFd;
        sWVbFDgmjIJI *= sWVbFDgmjIJI;
        sWVbFDgmjIJI *= uxIDuRFC;
    }
}

bool gQMLe::xuxlxqtwSgA(double kQHeXVujStnTVjCH, int XsCvLuCguFhT, string XbokSXaLlLaUPdA, string JilfhRENBcfco, int fSMhVUsXpwcWG)
{
    int bbiqCRUnRx = 928106101;
    string ntLABLigBmNtFvPD = string("JwNXWbRMjAFgZmNbIgffVlGOdSGnjljzTTPSkQebeknxystMYr");

    for (int NKPag = 1673629161; NKPag > 0; NKPag--) {
        XsCvLuCguFhT /= fSMhVUsXpwcWG;
        ntLABLigBmNtFvPD += JilfhRENBcfco;
    }

    if (fSMhVUsXpwcWG < -1443033045) {
        for (int iNbpr = 1518423298; iNbpr > 0; iNbpr--) {
            XsCvLuCguFhT -= bbiqCRUnRx;
            ntLABLigBmNtFvPD += JilfhRENBcfco;
        }
    }

    for (int GxpnyRJJ = 857136663; GxpnyRJJ > 0; GxpnyRJJ--) {
        XsCvLuCguFhT = fSMhVUsXpwcWG;
        JilfhRENBcfco = JilfhRENBcfco;
        XsCvLuCguFhT /= bbiqCRUnRx;
        XsCvLuCguFhT -= bbiqCRUnRx;
        JilfhRENBcfco += JilfhRENBcfco;
    }

    if (fSMhVUsXpwcWG >= 1826846085) {
        for (int VbeMmmgAuhT = 213247712; VbeMmmgAuhT > 0; VbeMmmgAuhT--) {
            fSMhVUsXpwcWG /= fSMhVUsXpwcWG;
            XsCvLuCguFhT = fSMhVUsXpwcWG;
            bbiqCRUnRx = XsCvLuCguFhT;
        }
    }

    for (int vmwib = 2019142896; vmwib > 0; vmwib--) {
        continue;
    }

    for (int hdhRFFvUk = 203658576; hdhRFFvUk > 0; hdhRFFvUk--) {
        XbokSXaLlLaUPdA += XbokSXaLlLaUPdA;
    }

    return true;
}

int gQMLe::kaUfA(int gqJzCRGE, bool vdFNYnQXrUCfQpxM, bool VtYPhZtucUN, bool gTrdD, int CQUtnJTIgmmaIg)
{
    string PkSKvbHmPA = string("NjnsRboMOJsHQSKJzJsvuYrACoRmAoQwRncqBKh");

    return CQUtnJTIgmmaIg;
}

int gQMLe::gYpTJ()
{
    string xHPYFvTVhQ = string("HiEqUzBnJoRpowWmWgJCghrdfjUOipBw");
    double YOgsgG = -461743.11401159887;
    double PqSJTN = 815700.1160220866;
    string gpSgJVQK = string("KVzRNeqfQwrywaECtrIdJQtBZSjGwAbQZqNjGRHCuQUWREwpwt");
    string GtEyLhuuZ = string("VNvkhtqtBt");
    bool ZZSyl = true;
    int SWXKfXWCJt = -1143088813;
    string LPkzzFjELWEKS = string("AixwmDZQUeAjqxyZhVoJFcaUrkaEDSEhtNoWPwbDbrpBrUoAamLFECBEbigJrGoLyBjoZpJSrXTGYgBIcxbapHmwFGwgHMsWAWezxjQRooDqpuWAuQyqAjnJiXRtwxarUBafWuEFmqiZkCqNSjVpYXMSqmLPookfxfhSjFguAFRctTzmHTzWWtLKtlZjRfNIyxRUhfULcTXJqlYRUqgHxYYgGXXpSyxfIOpe");
    double VNfHozcetoVdQEbf = -196532.8491718434;

    for (int AxgBmck = 984605257; AxgBmck > 0; AxgBmck--) {
        YOgsgG *= VNfHozcetoVdQEbf;
    }

    if (PqSJTN < -461743.11401159887) {
        for (int AXPstwKHsMbsZfo = 1664349719; AXPstwKHsMbsZfo > 0; AXPstwKHsMbsZfo--) {
            VNfHozcetoVdQEbf += VNfHozcetoVdQEbf;
        }
    }

    return SWXKfXWCJt;
}

double gQMLe::MoGbqOR(int cfXkxdldXsvYX, int LkrgGOM, string pUXqGPcpiLDf)
{
    bool pqzUugg = false;
    string XcaJKBEwDyTX = string("YNRUALJBKYnbzDoiBXVGENcapgzJdXVCEjEViEkTLiEwRhfpDdQsylAeUFCStfNRejqPpkGYXCJEoVFeYGjqHFXHvNoYfOumQvKPu");

    for (int HXjVXohpWOqoRT = 847710488; HXjVXohpWOqoRT > 0; HXjVXohpWOqoRT--) {
        pUXqGPcpiLDf += XcaJKBEwDyTX;
    }

    for (int RJqVAHkbSFDh = 2118144855; RJqVAHkbSFDh > 0; RJqVAHkbSFDh--) {
        continue;
    }

    for (int vxGYQfDBjNTu = 709291093; vxGYQfDBjNTu > 0; vxGYQfDBjNTu--) {
        LkrgGOM += cfXkxdldXsvYX;
    }

    if (cfXkxdldXsvYX == 1941295297) {
        for (int dbzsOmXelhO = 1737873817; dbzsOmXelhO > 0; dbzsOmXelhO--) {
            pUXqGPcpiLDf += pUXqGPcpiLDf;
            cfXkxdldXsvYX += cfXkxdldXsvYX;
        }
    }

    return -999571.0887463759;
}

double gQMLe::AHFERG(double rvViqDDTyNv, string PGreMNybLPQQg, int dpaMPi)
{
    bool RLziFzRCQCbeLy = true;
    string UhkJzDzyCNAw = string("QeckVOmmywImStDPPxeLjFvIywEToWWROEzCFYHmLBNuNHKFIDnMFSTGkxcmFzlRgEcwPlSnQdzCpNBAsJzuswYaTQIzSKKSheLygpdMumvliWQBMfLFdktmZJJyaHplFUembNhDJUgatoWwUHCyFusCYYkxEvDWTlVKxsEdZU");
    string WCenIZRS = string("QyVcYwIfHTGYwAxZDwznMIxKFxbENeoYienFWJONBkwTLaJYmNRibYjZgzTgDszajoCoCdFXFXoiqibP");
    bool LNZUKGfYL = true;
    bool StAbblnv = true;
    bool GaKaH = false;
    int rnOhKiXGQHnx = 1180653310;
    double hJQRYtX = 629648.5570483668;
    double AsnNVJ = 253321.86068616787;

    for (int ABIbPTkuww = 1288395582; ABIbPTkuww > 0; ABIbPTkuww--) {
        LNZUKGfYL = ! StAbblnv;
        hJQRYtX *= rvViqDDTyNv;
        hJQRYtX -= AsnNVJ;
    }

    for (int XqJhlthGQBHE = 675632679; XqJhlthGQBHE > 0; XqJhlthGQBHE--) {
        AsnNVJ += rvViqDDTyNv;
        UhkJzDzyCNAw = UhkJzDzyCNAw;
    }

    if (UhkJzDzyCNAw >= string("BjEtQqfgOcafHkXmTlQukepyblkQXunUQHRkyTISUXDdvfLVdFouAuMfduJbPDdGdwcMOyBOSgFPIEXdYKLWbKgiUJPyOlmZNYPzooGSBasvZBoUlnu")) {
        for (int JpTfbauZkqjnu = 1252088199; JpTfbauZkqjnu > 0; JpTfbauZkqjnu--) {
            StAbblnv = GaKaH;
            LNZUKGfYL = GaKaH;
        }
    }

    return AsnNVJ;
}

bool gQMLe::jGRkHbee(double IaKVNnsuptC, double SIVmuZ, bool DDKTd, int MvFNk, bool qfPhbZnJW)
{
    bool xRKBZYCU = true;

    for (int fvTSBMkbQeFd = 770296506; fvTSBMkbQeFd > 0; fvTSBMkbQeFd--) {
        continue;
    }

    for (int rcOKO = 1483124277; rcOKO > 0; rcOKO--) {
        xRKBZYCU = xRKBZYCU;
    }

    for (int vAuQGKqbeeJ = 1248529424; vAuQGKqbeeJ > 0; vAuQGKqbeeJ--) {
        continue;
    }

    if (qfPhbZnJW != true) {
        for (int VgwUBu = 1461611695; VgwUBu > 0; VgwUBu--) {
            IaKVNnsuptC = SIVmuZ;
            xRKBZYCU = qfPhbZnJW;
        }
    }

    for (int SynvwvRitR = 207862393; SynvwvRitR > 0; SynvwvRitR--) {
        xRKBZYCU = qfPhbZnJW;
        DDKTd = xRKBZYCU;
        xRKBZYCU = ! DDKTd;
        xRKBZYCU = ! DDKTd;
    }

    return xRKBZYCU;
}

gQMLe::gQMLe()
{
    this->CyooZfcRywfqTUd();
    this->xuxlxqtwSgA(999416.3347904396, 1826846085, string("vIQVPnnDqpaXtTRXXBMaJuSMxfqdQMKBcqQbcfyZbhnPunsMOGAKagdrKCYvmmSQReSFUYMwvOLkFjftgGvEifPoYBXJaEMUKfOJQPBnzoeeucKdIDSgoTJzpJrzRhXxBzpQLgRpyGYzzwZEgxMfiPAHHZSKzQydAxnGbFRV"), string("mHlzuBgtVbnCQhYXyMHUDmKCGRoNJtzbzcPBcOEUxdwcDCIFffHeHaUpLolvRFbXlxnXNGvdYUOg"), -1443033045);
    this->kaUfA(598457439, true, false, false, 1585546081);
    this->gYpTJ();
    this->MoGbqOR(1941295297, -71413954, string("ihEdqjoIZYPSkCrQurlDWCFMOMIzZeyPWpuLPbfeMbItzyzjsLrLn"));
    this->AHFERG(-866383.6634643887, string("BjEtQqfgOcafHkXmTlQukepyblkQXunUQHRkyTISUXDdvfLVdFouAuMfduJbPDdGdwcMOyBOSgFPIEXdYKLWbKgiUJPyOlmZNYPzooGSBasvZBoUlnu"), 469102573);
    this->jGRkHbee(-376054.467208187, 912177.7807594346, true, -1497993080, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NTwVTHK
{
public:
    bool wZObMyqYmNUsy;
    double SYXmU;

    NTwVTHK();
protected:
    double FQskj;
    bool HOLLiTbw;
    string uwkUWD;

    bool ZJSaUnsqAWLC(string VWvmJPYLXyrqX, bool TPyLLMUwl, bool FKUjmiSaHxEbmaH, string SBuDw, string qmmpISjIavR);
    double SdldklPjFgh(bool muromCQgbdrqA, double cEkBsyI, bool voTTyiighTIYW, string uTkYe);
    void CqbGsRFoTDnfXR(bool FXbGSrRzgTMCo, double UiMulUnW, bool pRVhwL);
    void lbzlkOTHSuorEol(int edRsatiLMvviYhDN, int hEMjcpKvMtKpJEnq, double BWOSr);
    bool NamXbV(string RSSdqP, double zLfYVNGa, int yXvYhQR, double DHrPQWMH, string nGzLbks);
private:
    double qCflgyISIzs;
    string GrpFGzc;
    int AqoajuQTywqfvhXP;
    double hRzqmXNbYliSP;

};

bool NTwVTHK::ZJSaUnsqAWLC(string VWvmJPYLXyrqX, bool TPyLLMUwl, bool FKUjmiSaHxEbmaH, string SBuDw, string qmmpISjIavR)
{
    bool hpjJM = false;

    if (hpjJM != false) {
        for (int bDebPAlZ = 848828318; bDebPAlZ > 0; bDebPAlZ--) {
            SBuDw = qmmpISjIavR;
        }
    }

    for (int yjAimBk = 1889295390; yjAimBk > 0; yjAimBk--) {
        FKUjmiSaHxEbmaH = hpjJM;
        TPyLLMUwl = ! hpjJM;
        VWvmJPYLXyrqX = qmmpISjIavR;
    }

    if (FKUjmiSaHxEbmaH == true) {
        for (int sLIsdoErqFOec = 840533443; sLIsdoErqFOec > 0; sLIsdoErqFOec--) {
            qmmpISjIavR = VWvmJPYLXyrqX;
            SBuDw += VWvmJPYLXyrqX;
            hpjJM = ! TPyLLMUwl;
            qmmpISjIavR = VWvmJPYLXyrqX;
            FKUjmiSaHxEbmaH = hpjJM;
            qmmpISjIavR += SBuDw;
            hpjJM = ! TPyLLMUwl;
            FKUjmiSaHxEbmaH = ! hpjJM;
        }
    }

    return hpjJM;
}

double NTwVTHK::SdldklPjFgh(bool muromCQgbdrqA, double cEkBsyI, bool voTTyiighTIYW, string uTkYe)
{
    int lLIml = -827339061;
    bool GEYzoiJUhSER = true;
    double Plcqadk = 827627.2918470002;
    int OOLwsOQqRbh = -1815278454;
    bool ZVjpiZZHcClzAY = false;
    int moCUwgBt = -1704526949;

    for (int aWzfQNJquTfNIjpA = 1686481125; aWzfQNJquTfNIjpA > 0; aWzfQNJquTfNIjpA--) {
        GEYzoiJUhSER = muromCQgbdrqA;
        moCUwgBt *= OOLwsOQqRbh;
    }

    for (int bqSsvoyzbzQKj = 1871661639; bqSsvoyzbzQKj > 0; bqSsvoyzbzQKj--) {
        uTkYe = uTkYe;
    }

    for (int FeVLCCLA = 1819969589; FeVLCCLA > 0; FeVLCCLA--) {
        OOLwsOQqRbh /= OOLwsOQqRbh;
        moCUwgBt -= lLIml;
        voTTyiighTIYW = GEYzoiJUhSER;
    }

    return Plcqadk;
}

void NTwVTHK::CqbGsRFoTDnfXR(bool FXbGSrRzgTMCo, double UiMulUnW, bool pRVhwL)
{
    double sMHiIelSCL = 116288.52436224112;

    if (pRVhwL != true) {
        for (int CHgJRbtmLifPPAy = 363685722; CHgJRbtmLifPPAy > 0; CHgJRbtmLifPPAy--) {
            UiMulUnW /= sMHiIelSCL;
        }
    }
}

void NTwVTHK::lbzlkOTHSuorEol(int edRsatiLMvviYhDN, int hEMjcpKvMtKpJEnq, double BWOSr)
{
    int DZMFRoYnUb = -383761603;
    int UheIsCyHmmzwEcv = 387865326;
    string dPcXiWX = string("SeTlIczizbjVJkFufCKcWZVAhylXZDjoOiPZtqQUVGZMjBUxGEvhxuzCHOUfOmZbkPevAbZEknhLczVfVxHpGaudnvDPQKVfrDNkaSMIDaPsSAUaYrSiUUFSjxeCSHceoZkuJmrrkJMMYCTDybyLVyzgoKuefpMKYIUNUGGRjcbmuWwoaxeOnRrRQFjvXnCAArNTIvUoeVnbVJFJJIkxbt");

    for (int aACWHEP = 1142013617; aACWHEP > 0; aACWHEP--) {
        DZMFRoYnUb = UheIsCyHmmzwEcv;
        edRsatiLMvviYhDN = edRsatiLMvviYhDN;
    }
}

bool NTwVTHK::NamXbV(string RSSdqP, double zLfYVNGa, int yXvYhQR, double DHrPQWMH, string nGzLbks)
{
    int eGUOv = -1765418396;
    double ZzmJJzpMYPAWhsrN = 773886.9191491177;
    bool nKMcmSSEPVd = true;
    string zVAIjT = string("dJFOVGXTtddlSOJoKbBlKkHLQyXwAaevPkRkLVkNyQQwfFDpqDlGThjbmTxumtGkSnVwRVQnpNPBSYksiGSBfjuHEURGpplFSnIQMzTornmn");
    string uZqzeAvawVC = string("XpEYBomsCuTwRPZWHiKAzAZOgqCnQcUcznbXpKOhVvyvGNOmVSxnoyjLFFmKmIoOdfByYbHYmfCgaR");

    if (yXvYhQR < -1765418396) {
        for (int lHvFMZMReOQd = 1257953730; lHvFMZMReOQd > 0; lHvFMZMReOQd--) {
            uZqzeAvawVC = zVAIjT;
        }
    }

    for (int gGeoIY = 533962943; gGeoIY > 0; gGeoIY--) {
        uZqzeAvawVC += uZqzeAvawVC;
        eGUOv += eGUOv;
        zLfYVNGa *= ZzmJJzpMYPAWhsrN;
    }

    for (int wgcvZMlgbsBZQEPl = 700586135; wgcvZMlgbsBZQEPl > 0; wgcvZMlgbsBZQEPl--) {
        continue;
    }

    for (int CWgprDsWlbW = 1173058828; CWgprDsWlbW > 0; CWgprDsWlbW--) {
        ZzmJJzpMYPAWhsrN -= zLfYVNGa;
        zLfYVNGa *= zLfYVNGa;
        zLfYVNGa -= ZzmJJzpMYPAWhsrN;
        zLfYVNGa = zLfYVNGa;
    }

    return nKMcmSSEPVd;
}

NTwVTHK::NTwVTHK()
{
    this->ZJSaUnsqAWLC(string("mUetuJayaRlHGlmzNelTgxVkElIHBdmXrNRmKUWHiVBUqfKFumySokH"), true, true, string("XFCdCKBQGVaEsFHnxwQnirqjkhkcrQKaEBlfYtJfXzfxylODkLvkxGGlKQVqVKDK"), string("wFYjSeCyfYuMGhCdVpxmKmeIoUVfSRlbKrzmgFPvYUrTgDUJCXJrayiUQkVBdXNqMBBYeBqbwCKjpCcXARFmUGASGJtnPEwrZfSdjXDykkjpyBHuUFBWAjJzoANYPICxPxrIEjiwoIUNYLqtlDVyjGNyWqjwqrhb"));
    this->SdldklPjFgh(true, 858707.3097360188, true, string("qTEGHMmJFDUqOooOHIpuQAZNVvGLDuuplXiTzKGnGQwHOWpcNyodtTjSNaBvVVgfvreiZdSOQdHmUkESTnoeFyONvBWvlBnWWczNsKIKzyQNXZJsnIosxPJyp"));
    this->CqbGsRFoTDnfXR(false, -640962.8333664417, true);
    this->lbzlkOTHSuorEol(866412798, -649191487, -164428.36523113426);
    this->NamXbV(string("butTRtAqNRHTcTWxwvArJKTlBlCewKXTyvLNRwXSJymeZIAsPkYnCMlJMVYdedvIgNzsWGsWjeMVYHufGRQnxrvUnQiXAgRMKbsTdPKn"), 311728.53716271726, -1770917215, -581207.241253311, string("EBSGQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UPyTmJQcYXHLvWm
{
public:
    int OnXDKnZwlbPM;

    UPyTmJQcYXHLvWm();
    string LpJKkBxdQlpmsQm(bool IfSnirYqMD, int fImBu, double YZUJhbez, double hOXSGPNNxRVySvN, double gQtCzxU);
protected:
    double iOPbxBLveWa;
    double sDMsILYzavdxRK;
    int hUcIKZPQFH;
    bool xNckJAIHWVgAE;
    bool tEAvKKjIMMYJQSuu;

    int MlNwcUQ();
    int DjHLGb(string WjervpBzXGIXIoW, bool LPVjAGBStdUGwSo, bool sHpuBKdcbpRZ, bool oVxPBlMkoDhUlM, double MzopKSsfH);
    double aGugDYQBFGRgiy(string uynhv);
private:
    string VETBBm;

    void xKxcQxPwtO(bool NffkwphVXxYksx);
    double yMwrYK(double CcdWGZIl, bool GURhImLbC, bool ROhrtrM, int tvmtWOhdVSWt, int HATmMylD);
};

string UPyTmJQcYXHLvWm::LpJKkBxdQlpmsQm(bool IfSnirYqMD, int fImBu, double YZUJhbez, double hOXSGPNNxRVySvN, double gQtCzxU)
{
    string JeoBfflzyfqSmnB = string("ucalIZyPndzXGMaxzJQcfxpjEBzpmtFewVuzbHeDwXnbIJJDljMXodJuyIrtWSCGiOtvDuCcdqWgSTuhJTLvLQxodGOpqRmKwsmJdVezmqOzbyQTwiMKDZNmkZvYfJUdqatzmvITnDPDFZZztdmrPkNcloaehOmALgYOabWbgjVLXBjsbAfHEvnpzMJ");
    int XnBDldsTUXwgzfwm = 659652956;
    bool ahMgcmeXeSpM = true;
    int yOajTBUKUWir = 284813785;
    int UYvzsoYWo = -1915240854;
    double LeTaT = -751475.4277421236;
    int GkBXRM = -712721134;
    int tpAdopUlOqJQs = -1424904006;
    int LpsdtSgmgwBkBIIt = 1693894249;

    for (int HZiVFLHsD = 1978679574; HZiVFLHsD > 0; HZiVFLHsD--) {
        XnBDldsTUXwgzfwm += GkBXRM;
    }

    if (fImBu <= 659652956) {
        for (int POeTPBJh = 549516571; POeTPBJh > 0; POeTPBJh--) {
            XnBDldsTUXwgzfwm *= tpAdopUlOqJQs;
            YZUJhbez += gQtCzxU;
            fImBu = fImBu;
            YZUJhbez = gQtCzxU;
        }
    }

    return JeoBfflzyfqSmnB;
}

int UPyTmJQcYXHLvWm::MlNwcUQ()
{
    bool WMkIuwfBCxLq = false;
    double LMsyDhjh = 563540.7937647906;
    double ZKXrZDkA = -479763.9080487134;
    bool NkgLM = true;
    double cURARESzYdXdbtlf = 998200.1201887379;

    if (LMsyDhjh > 998200.1201887379) {
        for (int ZIZqc = 1022810573; ZIZqc > 0; ZIZqc--) {
            LMsyDhjh += LMsyDhjh;
            NkgLM = NkgLM;
            LMsyDhjh = LMsyDhjh;
            LMsyDhjh *= cURARESzYdXdbtlf;
        }
    }

    for (int QwoWWa = 2051192751; QwoWWa > 0; QwoWWa--) {
        ZKXrZDkA *= ZKXrZDkA;
        ZKXrZDkA -= LMsyDhjh;
        ZKXrZDkA = cURARESzYdXdbtlf;
    }

    return 1002617259;
}

int UPyTmJQcYXHLvWm::DjHLGb(string WjervpBzXGIXIoW, bool LPVjAGBStdUGwSo, bool sHpuBKdcbpRZ, bool oVxPBlMkoDhUlM, double MzopKSsfH)
{
    double CyuEDBsYLWSuzD = -622965.3610516249;
    string CkhIYL = string("TJYwYwLoqKStHZweQ");
    string QDIBJGwTNec = string("mTaBQTrQtNaGTFTWamjuJoEbZBYHUaZOqBrxluKzeYvJhZdIHeVLhuOHkhSEFFiQnrYqRgeeHuSyhgnuEHejhPnGXdnabvpavAbajNdsFsoXSBQZzCUSATSaOeXapawgfYRuhwGShehYvQamlCIRppbWFgOwCCuBQqvQpxFkWULmcTYCrNNqXNxYHgEuMWUboNxzhGFOFoqonfMjbNRsPeGBQLjQmdHTL");
    int RjnpkdNwffJm = 561676600;
    bool SxsJcfsq = false;
    double HLktpIVQc = -810344.6258569969;

    if (WjervpBzXGIXIoW <= string("TJYwYwLoqKStHZweQ")) {
        for (int QzCeqFSxqxUti = 260017276; QzCeqFSxqxUti > 0; QzCeqFSxqxUti--) {
            QDIBJGwTNec += QDIBJGwTNec;
            WjervpBzXGIXIoW = WjervpBzXGIXIoW;
        }
    }

    for (int DByvHRPrJIXkcv = 241341985; DByvHRPrJIXkcv > 0; DByvHRPrJIXkcv--) {
        continue;
    }

    for (int GDlwSDBbdewa = 1170646671; GDlwSDBbdewa > 0; GDlwSDBbdewa--) {
        continue;
    }

    return RjnpkdNwffJm;
}

double UPyTmJQcYXHLvWm::aGugDYQBFGRgiy(string uynhv)
{
    bool djMqhOyopkHHMul = true;

    if (uynhv <= string("EiYGjURGGzEoMgaJrsNedZxjemiiCbjZLBhyyiVkTaCoOOWpzmVlEVtdEbYaVwqEFapdiVIOWxTjnnfVUNpPUaTjyPjtUdreIXNgSFUcKBiSLmfgbeVgKbiScmIAlAhSGOkncEpLSVwsFBotpWMnmikLghpXDbnYcIOHpRyCCIqahBClinubcspcFCinybwvIJDxCblbidE")) {
        for (int eUVtCgfP = 1346788570; eUVtCgfP > 0; eUVtCgfP--) {
            djMqhOyopkHHMul = ! djMqhOyopkHHMul;
            djMqhOyopkHHMul = djMqhOyopkHHMul;
            djMqhOyopkHHMul = ! djMqhOyopkHHMul;
        }
    }

    for (int DGAJLBhUqiJlYEHz = 1860674959; DGAJLBhUqiJlYEHz > 0; DGAJLBhUqiJlYEHz--) {
        uynhv = uynhv;
        djMqhOyopkHHMul = ! djMqhOyopkHHMul;
        djMqhOyopkHHMul = ! djMqhOyopkHHMul;
        djMqhOyopkHHMul = djMqhOyopkHHMul;
    }

    if (uynhv >= string("EiYGjURGGzEoMgaJrsNedZxjemiiCbjZLBhyyiVkTaCoOOWpzmVlEVtdEbYaVwqEFapdiVIOWxTjnnfVUNpPUaTjyPjtUdreIXNgSFUcKBiSLmfgbeVgKbiScmIAlAhSGOkncEpLSVwsFBotpWMnmikLghpXDbnYcIOHpRyCCIqahBClinubcspcFCinybwvIJDxCblbidE")) {
        for (int SjPMRhT = 747191227; SjPMRhT > 0; SjPMRhT--) {
            uynhv = uynhv;
        }
    }

    return 371500.03720621485;
}

void UPyTmJQcYXHLvWm::xKxcQxPwtO(bool NffkwphVXxYksx)
{
    double vNAOyi = 43889.86036486625;
    int DNywPl = 1583266037;

    for (int WZvkM = 916326233; WZvkM > 0; WZvkM--) {
        vNAOyi /= vNAOyi;
    }

    if (DNywPl != 1583266037) {
        for (int JYOGGjDisMTj = 1835795075; JYOGGjDisMTj > 0; JYOGGjDisMTj--) {
            DNywPl = DNywPl;
        }
    }

    if (NffkwphVXxYksx != true) {
        for (int FnnPLb = 216259850; FnnPLb > 0; FnnPLb--) {
            NffkwphVXxYksx = ! NffkwphVXxYksx;
            DNywPl = DNywPl;
            NffkwphVXxYksx = ! NffkwphVXxYksx;
        }
    }

    for (int OSDwyUPFgdh = 1937742137; OSDwyUPFgdh > 0; OSDwyUPFgdh--) {
        DNywPl -= DNywPl;
        NffkwphVXxYksx = NffkwphVXxYksx;
    }
}

double UPyTmJQcYXHLvWm::yMwrYK(double CcdWGZIl, bool GURhImLbC, bool ROhrtrM, int tvmtWOhdVSWt, int HATmMylD)
{
    double wypvaZtrLSDGSGxh = 603288.4387436026;
    double TmJpF = 617389.4643122895;

    if (GURhImLbC != true) {
        for (int EaWgllDH = 1570130774; EaWgllDH > 0; EaWgllDH--) {
            tvmtWOhdVSWt = HATmMylD;
            HATmMylD += tvmtWOhdVSWt;
        }
    }

    if (wypvaZtrLSDGSGxh >= 617389.4643122895) {
        for (int ttKLOdwvNJveAPSz = 212230963; ttKLOdwvNJveAPSz > 0; ttKLOdwvNJveAPSz--) {
            CcdWGZIl *= wypvaZtrLSDGSGxh;
            tvmtWOhdVSWt -= HATmMylD;
            CcdWGZIl += CcdWGZIl;
            CcdWGZIl *= CcdWGZIl;
        }
    }

    for (int eofCN = 2122549286; eofCN > 0; eofCN--) {
        tvmtWOhdVSWt *= tvmtWOhdVSWt;
    }

    return TmJpF;
}

UPyTmJQcYXHLvWm::UPyTmJQcYXHLvWm()
{
    this->LpJKkBxdQlpmsQm(false, 1343406990, -482840.63134831877, -1001193.8670957308, -645185.101587213);
    this->MlNwcUQ();
    this->DjHLGb(string("mPblazNsstQanAxknlhqJjOgPttUWXxXcPEKrqYmOQSTBzvvHFgijEwKXUNLImsOjxGENsdSzDDdtMx"), true, true, true, 518508.14142891194);
    this->aGugDYQBFGRgiy(string("EiYGjURGGzEoMgaJrsNedZxjemiiCbjZLBhyyiVkTaCoOOWpzmVlEVtdEbYaVwqEFapdiVIOWxTjnnfVUNpPUaTjyPjtUdreIXNgSFUcKBiSLmfgbeVgKbiScmIAlAhSGOkncEpLSVwsFBotpWMnmikLghpXDbnYcIOHpRyCCIqahBClinubcspcFCinybwvIJDxCblbidE"));
    this->xKxcQxPwtO(true);
    this->yMwrYK(-918658.0332219154, false, true, -961154832, -1573465066);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TeFwBILvy
{
public:
    string GqAbjTKuJMRbtI;
    string mwjsjwETHFDGaU;

    TeFwBILvy();
protected:
    bool EYDugaJdhfLOIXPu;
    bool fXPPxtoeG;
    int PedlkOpPLQV;
    double ZXoPdI;

    bool vIPtNZHLyX(string uMuFNCWfrPbqKA, string ORrjeHYZL, int LvxYK);
    int JHdtcMzFEiB();
    double LLLvlHrkEysRju(double DUOsgvTxDzMKpRrZ);
    bool aYsOY(int QGYaLJitVrY, bool MrYORNDuyb, double Uqziaesbe, string iyZwQusPYSZGFjjR, bool UPuqKfJCcnpC);
    double jNbmBpOnx();
    void ldLpGSkoImmgH(double gCzpFVftYoYUzipa, double xiQFYxpeSNwEZcz, bool zutEfFDRb);
private:
    bool OnhxVIdrxtzWxhae;
    bool hKAoBDJwdNC;
    double JphmZLnqhcwwVPz;
    int hNSghMSpf;
    string xhyUcdet;
    int Lepzltf;

    double SadupOJZZOY(bool lBByXW, int obPQoXSCbPXDTSB, string ccTDHC, int yroeLWRqcfU, int auSlyCplfQmQ);
    double rwaFkgshjJjAHlV(double zznNICbhTlPm, bool oTAdzTz, double JxODoOtnBHjYFIq);
    void pjlTkwiXWJIB(double NKuHyeYwWVm);
    bool nOgerlJVGIsMss();
};

bool TeFwBILvy::vIPtNZHLyX(string uMuFNCWfrPbqKA, string ORrjeHYZL, int LvxYK)
{
    bool aKrokwtqoiUjhrA = false;
    bool tRsITofYUAs = true;
    double qcLgsSIlQYrP = 815099.7361931432;
    bool qZjzPLjCChCF = true;
    string RxCpgRvYyBs = string("hBLyRooNtyvwNMHNitebMcQKWllaRnSUwUhkDYUDNoRERDEwCMQAQEufpwRpvbKQpBXBIiVneoLAihBfKJfLddbbSeVTwrfGwPBVRHYTgiIstUxXwupGnIfhHopEzclLZKDniHqKhOBsKqcIpdGLZMFrsaVIvcTOKwQqtqugmqFtXxpIsTJaqNmxlkQbmMclVBCHzPugbvkxlfUMheisVOawpRGqFqZFcnKUVQx");
    string oEhrbwhlDjVm = string("ksggLGHXEaxmWbSuCdMgZAOxZyfWtDrzLcnpaEKyNbadNJesylKD");
    int AYULKQXrwzkpe = 527842906;
    string aGqWPfyHXUOvE = string("BwMXAKtabsjNqgeeUuNCjmMsXdbiEFKxzzFuCaqxdpycevlIkeLoqMASwZdGIFsHfKXbBceKPDvknAdUVKuLbPAfXAMVTMtSNfxBsXHwVQcRfflWLfhkhhxLHsXCSrwDqlkqCpcuqHVsFOZeDCCyQKJHUXawTQBmcclTyeVdxGEDssJVJtzTZxSYQQndwxOnKQxsNCUbHqNcBOjbKIxzcblgAfwpKJ");
    int PTZEBRpxxn = 262645208;

    for (int kFPmOWLhr = 361708081; kFPmOWLhr > 0; kFPmOWLhr--) {
        continue;
    }

    for (int bEvXMISR = 1248087180; bEvXMISR > 0; bEvXMISR--) {
        PTZEBRpxxn *= LvxYK;
    }

    if (ORrjeHYZL < string("vuzvNLVJwdmKiOSqRm")) {
        for (int LWXIIjUJGfZbu = 740543635; LWXIIjUJGfZbu > 0; LWXIIjUJGfZbu--) {
            ORrjeHYZL = oEhrbwhlDjVm;
            oEhrbwhlDjVm += RxCpgRvYyBs;
        }
    }

    for (int LAPqfRQJPg = 1178574151; LAPqfRQJPg > 0; LAPqfRQJPg--) {
        AYULKQXrwzkpe = PTZEBRpxxn;
        RxCpgRvYyBs = aGqWPfyHXUOvE;
    }

    return qZjzPLjCChCF;
}

int TeFwBILvy::JHdtcMzFEiB()
{
    int JFbRDCmTzA = -108840274;
    string SCuVJMDw = string("taTTUdeRJxBehQwVGcUIMLYWGNgArZvSOOr");
    double RAlJIcWU = 656287.7187283894;
    int QUnqIoGLV = 27799934;
    int lbVGmWtWdIUCj = 152562059;
    bool yvqoeDwx = false;
    string fHnAX = string("YubkOSHQfkWBTnfcfKEFQmFSqOpSROUezMjlqEDjTTpYIvQpzzFPAAVrlVKvGwVujbpBboXcTPrmFzrSchpODbRtvMzaEsQs");

    for (int JHFNMEBDMAUd = 497968648; JHFNMEBDMAUd > 0; JHFNMEBDMAUd--) {
        fHnAX = SCuVJMDw;
        RAlJIcWU *= RAlJIcWU;
        JFbRDCmTzA -= JFbRDCmTzA;
    }

    if (lbVGmWtWdIUCj > 27799934) {
        for (int siZml = 1496956901; siZml > 0; siZml--) {
            continue;
        }
    }

    for (int RTXlAFuQdauxbJh = 1089084989; RTXlAFuQdauxbJh > 0; RTXlAFuQdauxbJh--) {
        QUnqIoGLV = lbVGmWtWdIUCj;
    }

    for (int XSFLP = 1611473358; XSFLP > 0; XSFLP--) {
        RAlJIcWU /= RAlJIcWU;
        fHnAX = SCuVJMDw;
        QUnqIoGLV *= JFbRDCmTzA;
        QUnqIoGLV -= lbVGmWtWdIUCj;
    }

    return lbVGmWtWdIUCj;
}

double TeFwBILvy::LLLvlHrkEysRju(double DUOsgvTxDzMKpRrZ)
{
    double JxEKklY = -509662.8260171486;
    int wsOiHByJAwNbjf = 484737170;
    double BTdYvSY = 925944.3576566163;

    if (DUOsgvTxDzMKpRrZ > -755783.8677774462) {
        for (int AXxbSq = 1005913453; AXxbSq > 0; AXxbSq--) {
            JxEKklY /= JxEKklY;
            JxEKklY /= DUOsgvTxDzMKpRrZ;
            DUOsgvTxDzMKpRrZ += JxEKklY;
        }
    }

    return BTdYvSY;
}

bool TeFwBILvy::aYsOY(int QGYaLJitVrY, bool MrYORNDuyb, double Uqziaesbe, string iyZwQusPYSZGFjjR, bool UPuqKfJCcnpC)
{
    string sQHYdCWFdYqZc = string("zIfthJQUUXVdhpZaOeWBtlSzsYWWBvEVVtVuDkMoVhPTfksVJrtoKEQkiIcMjDBKwsOoOthtFDRqjSMKmXqdRDtTZVzWGMkhjeVuAYTWZYKqFfjOLQyycQDFFuLMXteVCXqnEYiWAiuorQChZbrDqsGbWbGwrDRjfopToDTjhIuHXMUnhXJovEnlAwBJeKWvMSQvIuspLLnviFlHzGjWNVUIKsliMEhdVRXgNwaOeQylibckcBnXxVsi");
    double FnWHlYKg = 978658.8569997284;

    for (int MiJpgimWVKnR = 1631389875; MiJpgimWVKnR > 0; MiJpgimWVKnR--) {
        Uqziaesbe = Uqziaesbe;
        sQHYdCWFdYqZc = iyZwQusPYSZGFjjR;
        UPuqKfJCcnpC = ! UPuqKfJCcnpC;
    }

    for (int kmUMBglgcdRko = 708576478; kmUMBglgcdRko > 0; kmUMBglgcdRko--) {
        MrYORNDuyb = MrYORNDuyb;
    }

    for (int KqBoCJzMPbe = 29631713; KqBoCJzMPbe > 0; KqBoCJzMPbe--) {
        MrYORNDuyb = ! UPuqKfJCcnpC;
    }

    for (int CoggiGRrTj = 987570752; CoggiGRrTj > 0; CoggiGRrTj--) {
        QGYaLJitVrY -= QGYaLJitVrY;
        Uqziaesbe /= FnWHlYKg;
    }

    return UPuqKfJCcnpC;
}

double TeFwBILvy::jNbmBpOnx()
{
    int sOGgzfKoCij = 960133086;
    bool dIhgbCaBtFst = true;
    double BdxYprOrDJpD = 720715.9136111793;
    int cTCODp = 167588150;
    bool FCNSkVCyLHvTejeW = false;
    double btwIVLHdSOg = 931601.0236270118;
    bool yisgpzMy = false;
    double JkoGeVMhGgvdN = 313813.1054318139;

    for (int VdxYhcpV = 838196545; VdxYhcpV > 0; VdxYhcpV--) {
        sOGgzfKoCij = sOGgzfKoCij;
        yisgpzMy = ! yisgpzMy;
    }

    if (cTCODp <= 167588150) {
        for (int LTWcKMVqjDlochU = 1376127599; LTWcKMVqjDlochU > 0; LTWcKMVqjDlochU--) {
            continue;
        }
    }

    return JkoGeVMhGgvdN;
}

void TeFwBILvy::ldLpGSkoImmgH(double gCzpFVftYoYUzipa, double xiQFYxpeSNwEZcz, bool zutEfFDRb)
{
    int uWuNczHCPDUd = -1694761999;
    string KXilfzCXeCLAm = string("AiXpFhfPJHNJxrSCkJxvIkQehPcOXNZVGQpjLppKRtYlEMdlqgvDTNARbIRBayTRvIsksbDKuFoOJgKmxmxYAnaObeZeTGWeMpCteWEEXFcJEehKggcKWKvTjifjlOEnfSBkeMmUqOTiYPudNixqnkcIlNEnPqfaQHdDDLsoKzxapzdPSPktQmQcQrqPmLjIFjrGqaDMoDAYJxrsBWSXvrZiNzZthJWGMzKmvLBvXPOKmTTUyhuyVmYbjNZ");
    int mqaqCzxllk = 466696815;
    string oRoGzCJROgqleyy = string("xOaGdyTRCyCbkwJppGlcAltoBCikmYRtaaIlArLrhrFioWgxQWreWgrDhVynZIOyCkJFSeeBboATZxoFDUrIRnaOPgjOITITzoHfPNGvAPOWswXwYsvjkwWZjwMwFySTjCuNvATkIqRXfSRKHGvjqnHCCshLch");
    bool cNtLBMWvUk = false;
    int tCdkBY = 772602220;
}

double TeFwBILvy::SadupOJZZOY(bool lBByXW, int obPQoXSCbPXDTSB, string ccTDHC, int yroeLWRqcfU, int auSlyCplfQmQ)
{
    bool LmHnk = false;
    bool LvvfgEHNsa = true;
    int ZJTjZNH = -1821476975;
    double WZsuIpQRKGWFuU = 974076.7725730784;
    bool tYbNGmuYQVbcRekW = true;
    string FyLnbiAGqPXAHHs = string("seOZddCqtBIUvQVPGyn");
    int RIiGBm = -1024170012;

    for (int viREhN = 1798373992; viREhN > 0; viREhN--) {
        LmHnk = ! LmHnk;
        obPQoXSCbPXDTSB *= auSlyCplfQmQ;
        auSlyCplfQmQ /= yroeLWRqcfU;
        auSlyCplfQmQ *= yroeLWRqcfU;
    }

    for (int avjQZIPqYIpmZ = 1264530406; avjQZIPqYIpmZ > 0; avjQZIPqYIpmZ--) {
        ZJTjZNH -= yroeLWRqcfU;
    }

    if (yroeLWRqcfU < -1985318494) {
        for (int TIBOtEwkYenn = 63171848; TIBOtEwkYenn > 0; TIBOtEwkYenn--) {
            continue;
        }
    }

    for (int sxVsj = 847954759; sxVsj > 0; sxVsj--) {
        yroeLWRqcfU = obPQoXSCbPXDTSB;
        LvvfgEHNsa = ! LmHnk;
        RIiGBm = RIiGBm;
    }

    for (int ThecFJlXL = 181924506; ThecFJlXL > 0; ThecFJlXL--) {
        obPQoXSCbPXDTSB = auSlyCplfQmQ;
        obPQoXSCbPXDTSB -= obPQoXSCbPXDTSB;
        yroeLWRqcfU += yroeLWRqcfU;
        WZsuIpQRKGWFuU *= WZsuIpQRKGWFuU;
    }

    if (obPQoXSCbPXDTSB > -1851673761) {
        for (int sWxWYY = 13413672; sWxWYY > 0; sWxWYY--) {
            auSlyCplfQmQ *= RIiGBm;
            RIiGBm /= yroeLWRqcfU;
        }
    }

    for (int NlRDoIFEFAAqxW = 2064870036; NlRDoIFEFAAqxW > 0; NlRDoIFEFAAqxW--) {
        ZJTjZNH /= yroeLWRqcfU;
        FyLnbiAGqPXAHHs = ccTDHC;
        LmHnk = ! lBByXW;
    }

    return WZsuIpQRKGWFuU;
}

double TeFwBILvy::rwaFkgshjJjAHlV(double zznNICbhTlPm, bool oTAdzTz, double JxODoOtnBHjYFIq)
{
    int BuEjqiWRfGgkEOi = -1666827241;
    bool OpkZMa = false;
    string AAVrpJ = string("JtNDREiBINweJGlfiHLoDbVdBhiiWCkiaBDzfinXxJgESBHlNynAoqoqrZOKPBGEVWxubGpNZAToBkNRMjGGyjjAwOYGPNISXIwTcOYehoztbeIwbRpmPUxcIfJHhcUgWryUJRhyONAznsqUcrIrruHNDOnOdvZJfHyFZmzJzPVWgvcTLuxkBnrlOtVFdGeMqFVoPqjzBRySEHlZJvPFpcBgLdxQFTj");
    int xrjbwQBbZy = -1804293898;
    int VflmzNZbU = -1883598607;
    int AAoJTUypLq = 811402821;

    for (int iIiNvskmxsyP = 1336029110; iIiNvskmxsyP > 0; iIiNvskmxsyP--) {
        BuEjqiWRfGgkEOi *= xrjbwQBbZy;
    }

    if (OpkZMa != true) {
        for (int TplNUcZGwLUpXDV = 1129452148; TplNUcZGwLUpXDV > 0; TplNUcZGwLUpXDV--) {
            VflmzNZbU += AAoJTUypLq;
        }
    }

    for (int LTERvhALzxcGEgWu = 2090503888; LTERvhALzxcGEgWu > 0; LTERvhALzxcGEgWu--) {
        continue;
    }

    for (int XGkwgv = 446186327; XGkwgv > 0; XGkwgv--) {
        continue;
    }

    for (int DHgaHBGzAodW = 2029288182; DHgaHBGzAodW > 0; DHgaHBGzAodW--) {
        AAVrpJ += AAVrpJ;
        AAoJTUypLq /= VflmzNZbU;
    }

    for (int yqqCdLeVrXfHMmV = 776120684; yqqCdLeVrXfHMmV > 0; yqqCdLeVrXfHMmV--) {
        xrjbwQBbZy *= BuEjqiWRfGgkEOi;
        BuEjqiWRfGgkEOi *= AAoJTUypLq;
        BuEjqiWRfGgkEOi = AAoJTUypLq;
    }

    for (int XCnsLiB = 973108778; XCnsLiB > 0; XCnsLiB--) {
        continue;
    }

    for (int ZdiccHipm = 1707143211; ZdiccHipm > 0; ZdiccHipm--) {
        VflmzNZbU *= VflmzNZbU;
        AAoJTUypLq -= BuEjqiWRfGgkEOi;
        AAVrpJ = AAVrpJ;
    }

    return JxODoOtnBHjYFIq;
}

void TeFwBILvy::pjlTkwiXWJIB(double NKuHyeYwWVm)
{
    double oGHaGaYmKSwLo = -62885.944070742735;
    double BYhHspKOdvRsa = -398874.31318474613;
    int qCJlKFBgpzhCEqx = -196987878;
    double xhcQNzeOGjMWl = -382451.47305464046;

    if (BYhHspKOdvRsa > 779695.4812091909) {
        for (int jRJBWC = 2145200721; jRJBWC > 0; jRJBWC--) {
            BYhHspKOdvRsa *= NKuHyeYwWVm;
            oGHaGaYmKSwLo = xhcQNzeOGjMWl;
            xhcQNzeOGjMWl = xhcQNzeOGjMWl;
            xhcQNzeOGjMWl -= BYhHspKOdvRsa;
        }
    }

    for (int rlfNmGOqUCwIY = 244779438; rlfNmGOqUCwIY > 0; rlfNmGOqUCwIY--) {
        NKuHyeYwWVm += BYhHspKOdvRsa;
        qCJlKFBgpzhCEqx -= qCJlKFBgpzhCEqx;
        qCJlKFBgpzhCEqx += qCJlKFBgpzhCEqx;
        NKuHyeYwWVm *= NKuHyeYwWVm;
        BYhHspKOdvRsa += xhcQNzeOGjMWl;
        NKuHyeYwWVm += xhcQNzeOGjMWl;
    }

    if (xhcQNzeOGjMWl >= -382451.47305464046) {
        for (int PZvKIerhkgPF = 1211692704; PZvKIerhkgPF > 0; PZvKIerhkgPF--) {
            xhcQNzeOGjMWl *= NKuHyeYwWVm;
        }
    }

    if (NKuHyeYwWVm >= 779695.4812091909) {
        for (int GCJkJOvLLjedz = 915752370; GCJkJOvLLjedz > 0; GCJkJOvLLjedz--) {
            oGHaGaYmKSwLo -= oGHaGaYmKSwLo;
            NKuHyeYwWVm *= xhcQNzeOGjMWl;
            NKuHyeYwWVm /= oGHaGaYmKSwLo;
            oGHaGaYmKSwLo = xhcQNzeOGjMWl;
        }
    }
}

bool TeFwBILvy::nOgerlJVGIsMss()
{
    bool dtuYCOGjvo = true;
    string fNLHppJJcQqoF = string("oFjmFIgfzsXvlfQkTexSBNaJMEdWUuBJMkFyExOzbQEjRjPDK");
    int nxqqkPywbuhgX = -1502832569;
    bool YLzGpN = false;
    int SmrSZHqAFogWETD = -980936113;
    int IpudOfrirlyA = -260785476;
    bool KcGyBazi = false;

    for (int krrVC = 1926391137; krrVC > 0; krrVC--) {
        dtuYCOGjvo = dtuYCOGjvo;
    }

    for (int GrxmkQsfXc = 1840335356; GrxmkQsfXc > 0; GrxmkQsfXc--) {
        SmrSZHqAFogWETD *= nxqqkPywbuhgX;
    }

    return KcGyBazi;
}

TeFwBILvy::TeFwBILvy()
{
    this->vIPtNZHLyX(string("cqseGZeEBDDJPOcCgR"), string("vuzvNLVJwdmKiOSqRm"), -778051802);
    this->JHdtcMzFEiB();
    this->LLLvlHrkEysRju(-755783.8677774462);
    this->aYsOY(-885958044, false, -809616.3634746546, string("eWGdAaPBtJBuKgQUyBYiSWCTFgDRRIqcmNoGHYqQrALirIyMsnSToTJhDExiCMcrvOzvihmUHLzaUsDtghbNzGRWslsaPwJDfNBHBLPyBCtlMsoEBCxDGyioNHHogUjlYsANBEHhqpIrabvcFTAEAXxEMGwRbAnqEzQLClxilivlUMVwcjvKiwzlxXjZnSKgmieUtZdMxYaqUNRIKmwzUJhQZDrEiQfreNw"), true);
    this->jNbmBpOnx();
    this->ldLpGSkoImmgH(-813129.294473619, -370489.0696773985, false);
    this->SadupOJZZOY(true, -727818650, string("EHPVDnaXKUIEXDOHIRuflyMtjXkrQEPlKRpkBzeXHIzHYgIFMSjDVMYJOffOhdWJRAwXOcvdmojtEZrghHAJuEWLXIFHbCmVlzZcHadYrfLTpjZLpnrRRewwPrwGGwfhOdJIrPUNCQdlsAzOyLImUItJAhJRiTBHhWqxmJzzoaStwGENn"), -1851673761, -1985318494);
    this->rwaFkgshjJjAHlV(164061.89249675118, true, 483407.05920934846);
    this->pjlTkwiXWJIB(779695.4812091909);
    this->nOgerlJVGIsMss();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xvgWmzSpC
{
public:
    string xglizyPgDxP;
    string iYqihhhs;
    string CSwxYirALdH;

    xvgWmzSpC();
    bool PXiLLtRVyUX(bool frKPbserYx, string DGRiGyZVMxapLhQk, double GTpsWSQDtL, int hlRbhv);
    double aJYThEaxWpQpKsy(int VcMrY, string yiOWGoCgC, string XhFdWeN, int yzCFwj);
    bool HyxnHPnvQlYYkFl(bool OpoOcrTUYJAWnwvn, double mcuFmrYvxvC, int lLEXC);
    int zAXfujTc(int QhgUkVxavOPIVkR, int TEsWSyalvYHGHmWY, double PlkpFiqCyToQPByp, string uJvhQnh, int URZgtcA);
    bool UoRlVeZsW(bool lxSrQkSIYUuGDKEl, double eWpvThLAtvUNWKRi, bool nMeNv, int EdvFGB, string VLjos);
    double oCKVpKWGXGq();
protected:
    string LjTkf;
    bool WnAcUi;
    bool gTpldTDXF;
    string tlKnfurtSMGa;
    bool rWqwJtyi;
    double NLEsYJGEmEXcQC;

    void KHDaKErxjYfJC(bool CMHayMuJPAIlk, string nNZlMbUxjdfcot, int TJQLFYfAa, double ZobCBQwKsElEM, double iKLqUQCC);
    double dMdiALjfcH(bool FPjWDgjqIB, bool kAXqxLAsINaLdR, bool ZLKJlISmkf, int uVXPisfZEfbimTmK);
    string pFHBcZzSPKEUuPj();
    void mLJUiFrhC(double IBqJGAih, double OhFuBDJsJ, string uytBjXYWxRlaxDy, double XTDbm);
    void JJaCEOe(double BYcoFwh, int uSSiourwm, bool UXwKLcaZuwT);
private:
    string dXhTu;
    double CsRpvLrOURJvdZIB;
    string BtcJiDP;
    bool fOGzrmDyokPQHM;
    int OJdsJaLzxvRG;
    int vHvhqGIqu;

    int MQbzJD(int CAQImVrBtv, bool ZwfJpaG);
    int smBzJJpr(double NkZrEgTWkhM, double EgfnP);
    void OufmRDpD(bool syijttEQqxsEYzm, string vDibIBY, double zzUoKEodfa, int UeKQKIjRYpGxp, bool otwizcEyenmuH);
    bool CdfuiWOAboVtNcz(double gbvsEWPDG);
    double vpNNoEiTICPRfIhe(int ZhkZmpoLOIAbhX, string OTIXhzIIOIcf, double hpFlGrIjZGpI, bool MwxHwij);
};

bool xvgWmzSpC::PXiLLtRVyUX(bool frKPbserYx, string DGRiGyZVMxapLhQk, double GTpsWSQDtL, int hlRbhv)
{
    int uNmRPxkzLxcVvyM = -757113701;
    double WMxfIsVT = 931721.971278032;
    bool tJqhP = false;
    bool hBazAABaSM = true;
    bool sZjbvGMcw = true;
    bool iKSvWrMa = false;

    for (int ljXwYwjmnLUl = 104877362; ljXwYwjmnLUl > 0; ljXwYwjmnLUl--) {
        tJqhP = hBazAABaSM;
        sZjbvGMcw = iKSvWrMa;
        frKPbserYx = tJqhP;
        uNmRPxkzLxcVvyM -= uNmRPxkzLxcVvyM;
    }

    for (int RGBJhCGXrXjwuK = 2001777257; RGBJhCGXrXjwuK > 0; RGBJhCGXrXjwuK--) {
        continue;
    }

    for (int galni = 2014582355; galni > 0; galni--) {
        tJqhP = iKSvWrMa;
    }

    for (int gKqfbHUOtHXqBdc = 231768581; gKqfbHUOtHXqBdc > 0; gKqfbHUOtHXqBdc--) {
        GTpsWSQDtL /= WMxfIsVT;
        frKPbserYx = sZjbvGMcw;
    }

    if (tJqhP == true) {
        for (int XzduadqXWhZrY = 2034635259; XzduadqXWhZrY > 0; XzduadqXWhZrY--) {
            hBazAABaSM = frKPbserYx;
        }
    }

    for (int VUQOesqAiOegbeL = 1030215564; VUQOesqAiOegbeL > 0; VUQOesqAiOegbeL--) {
        continue;
    }

    for (int TxyhuDap = 2031499215; TxyhuDap > 0; TxyhuDap--) {
        hBazAABaSM = iKSvWrMa;
        tJqhP = ! tJqhP;
    }

    for (int putAQvixrEO = 1926239737; putAQvixrEO > 0; putAQvixrEO--) {
        frKPbserYx = tJqhP;
    }

    return iKSvWrMa;
}

double xvgWmzSpC::aJYThEaxWpQpKsy(int VcMrY, string yiOWGoCgC, string XhFdWeN, int yzCFwj)
{
    string uWFgAQGeCCgkzAo = string("DdluHUbKUMEEYesCSoQxTvOfwQYuXjkogMdEtqLJYXnNAcHteCJgNovAsASEUdnXsHgNypHAFlYlb");
    string PSwkQfeVYvDYEEK = string("pNrrRmwrkIjyQRwxkfkGuMPGEttBJFzNYXFUHZSgFzJCBIhyRjRMIaxcdzBOgSAxqCoafdquGlEAllk");
    string lkRwK = string("NJZSmMnlgHWjenDXocWmUBOBRGXmZtvoUdyNwyvmwIJaFVXjVCmMQoktwErlbhGMlheqmryiQjiZovIZWxPMqLtuPKzGoGDPdfmUcgtKNENlzlqgRRDmWImeoNqIqBVPVnkHqthKPeXsRUAwcTCBHfjMwexWBmZLJhOHJtIKKUoDfASbfUgScKynDKSf");
    bool VJFjQoFmXcte = false;
    int lSpRMMFDXg = 1951763959;
    int acdhGgqbe = -1429024715;

    for (int bkNpzG = 378734106; bkNpzG > 0; bkNpzG--) {
        yiOWGoCgC = XhFdWeN;
        VcMrY /= VcMrY;
        PSwkQfeVYvDYEEK = yiOWGoCgC;
        lkRwK += PSwkQfeVYvDYEEK;
        acdhGgqbe += VcMrY;
        yzCFwj -= lSpRMMFDXg;
    }

    for (int VWxUUWA = 521195488; VWxUUWA > 0; VWxUUWA--) {
        PSwkQfeVYvDYEEK = yiOWGoCgC;
        yzCFwj += acdhGgqbe;
    }

    if (VcMrY >= -1429024715) {
        for (int OFVvVdNOyeNq = 2001714568; OFVvVdNOyeNq > 0; OFVvVdNOyeNq--) {
            continue;
        }
    }

    return -561375.3377915291;
}

bool xvgWmzSpC::HyxnHPnvQlYYkFl(bool OpoOcrTUYJAWnwvn, double mcuFmrYvxvC, int lLEXC)
{
    double IBzlJXDvxTh = -640897.3834587219;
    string hJGpsxH = string("vXdmRCmxprVJDlWxsHYOPtRHJnschXfa");
    int DbfJPmXfXW = -1049503625;

    if (lLEXC != -1049503625) {
        for (int IggEIgbI = 1599287403; IggEIgbI > 0; IggEIgbI--) {
            IBzlJXDvxTh -= mcuFmrYvxvC;
            IBzlJXDvxTh += mcuFmrYvxvC;
            IBzlJXDvxTh = mcuFmrYvxvC;
        }
    }

    for (int NztGEGlvWKu = 1635711413; NztGEGlvWKu > 0; NztGEGlvWKu--) {
        mcuFmrYvxvC = IBzlJXDvxTh;
    }

    return OpoOcrTUYJAWnwvn;
}

int xvgWmzSpC::zAXfujTc(int QhgUkVxavOPIVkR, int TEsWSyalvYHGHmWY, double PlkpFiqCyToQPByp, string uJvhQnh, int URZgtcA)
{
    double oFXXJ = 233567.9067510659;
    int ambYNyyXr = -587863109;

    for (int uTYebAFLt = 720442028; uTYebAFLt > 0; uTYebAFLt--) {
        continue;
    }

    for (int mnWdQEVdrAG = 314259490; mnWdQEVdrAG > 0; mnWdQEVdrAG--) {
        URZgtcA -= ambYNyyXr;
        ambYNyyXr -= QhgUkVxavOPIVkR;
    }

    return ambYNyyXr;
}

bool xvgWmzSpC::UoRlVeZsW(bool lxSrQkSIYUuGDKEl, double eWpvThLAtvUNWKRi, bool nMeNv, int EdvFGB, string VLjos)
{
    double mMbxuNCpsLI = -925803.2679169894;
    string RZCQpTDAwyV = string("maOLRTaCnzyhzhiRcKinYQPrrDCiaPXzJJEUwWWolFHhHRpfdEFJEzmayLgkkaLxZHHShsdcqEJhJRWebEnySVOtSrnUlWcjoINRkMLDAPpqFstidApUvzvQBYBZxEGJBzUtWuxHxaCHNbfTraYiGEJGgANekJncRlK");
    double KHATxGumUFWAL = -143272.88512606785;
    string TewnDYltUv = string("TBTpNHebzJsbxmmfcQhDHVkcsWJRfxthWclcaNHkYNQxTiLpuILsbySArELaztcIcqnZWIxsbtvtleyuCfBAu");
    string nFxihFZqwiXA = string("SXNBZqskf");
    int SINxPZmjRJsf = -948197592;
    string bmVqN = string("KkaioHQFnyJVNILnKwURZdQajDYJFjHJMxOlwAXBLTzzsYDrsAFGhNJOSTaPGwQrHFiNOoPFNUVdifvMhmXIhKGwXZNdlBADYYYdkHGThVIDpysrmiMiDSKpgsEYAKXhZWdTGrxRzlCXHlDbbrWdBIjskYMyO");
    bool BnAfNZGdKpQ = false;

    return BnAfNZGdKpQ;
}

double xvgWmzSpC::oCKVpKWGXGq()
{
    bool rxFbhzTw = true;
    string EzegIEumzREwh = string("YICDluOyYjxydDuAUtizwaqRTivdyuYTKFkFHZXUmiJJAtPfScvbyEwTYZBeDUiOwrUafZkVisQqYKLlSvbaRHwesLvTQqQmJUOFQOdxdMXfsbIhPxpLHcqYRvEsiHMQgjDcekRBF");
    string uVFqUBiUumJBFJg = string("BqbWjmbJXzzRvLUkPrKHGuICHfMjyNRoGlraPuWaRmwFwDrehSyDDHMYiqspRUXncmTxmkyhJwraaKfEuvCxHutlBUjpVrAMYXAACSGytHsIulczvxmxHIuCewGOPnwPfgYT");

    for (int RpqqFgPq = 1481342129; RpqqFgPq > 0; RpqqFgPq--) {
        rxFbhzTw = rxFbhzTw;
        EzegIEumzREwh += uVFqUBiUumJBFJg;
        rxFbhzTw = ! rxFbhzTw;
        uVFqUBiUumJBFJg += EzegIEumzREwh;
        rxFbhzTw = rxFbhzTw;
        uVFqUBiUumJBFJg = EzegIEumzREwh;
    }

    for (int CxefFrfOz = 633808316; CxefFrfOz > 0; CxefFrfOz--) {
        uVFqUBiUumJBFJg += uVFqUBiUumJBFJg;
        uVFqUBiUumJBFJg += uVFqUBiUumJBFJg;
        rxFbhzTw = ! rxFbhzTw;
        EzegIEumzREwh += uVFqUBiUumJBFJg;
    }

    return 963205.3963575409;
}

void xvgWmzSpC::KHDaKErxjYfJC(bool CMHayMuJPAIlk, string nNZlMbUxjdfcot, int TJQLFYfAa, double ZobCBQwKsElEM, double iKLqUQCC)
{
    string WpYTXoEvrBfpQxMd = string("ScHEcfWWFOxNdzHQQKKwaqMJIbOQWxNdUIleLuDCAzOgIj");
    bool uYMEbAIOQ = false;
    bool hkRcKkBFeEmA = true;
    bool XgIWWZ = true;
    double YAUBttHYcyefE = -655796.5486612538;

    for (int MKxHaUvaX = 1782296844; MKxHaUvaX > 0; MKxHaUvaX--) {
        continue;
    }

    if (hkRcKkBFeEmA == false) {
        for (int fisAyzCuqlI = 975541275; fisAyzCuqlI > 0; fisAyzCuqlI--) {
            TJQLFYfAa *= TJQLFYfAa;
            XgIWWZ = ! uYMEbAIOQ;
        }
    }
}

double xvgWmzSpC::dMdiALjfcH(bool FPjWDgjqIB, bool kAXqxLAsINaLdR, bool ZLKJlISmkf, int uVXPisfZEfbimTmK)
{
    int TGYSuPLWePtGZL = -1548763935;
    string UCDAuNSoPQu = string("ikvYbnPRUDtlnWkeTUpKfZHBOGEYMCLONlwaOcypVpRaDxqFFYridMXzSmIEwcQttWjcCBpepxNkyRFjcBko");
    string cgLAAOenU = string("VquREXjiInLmCgkzbodDTDZMyOOzZLMReEfliHCJPOCnCLZCuLKyVojBjGtulvVysqAbrxwHKgRQqvMbEIliseogbLGLwCtFuzeVAuxPQbPFmhFOYzGDePHesxHmTnbtAdqPIeHOervhcFKCTMEXfXuHpvOplZQNQkIyBwgSDUTEqRoQBDtoYXtyOnjW");
    int MAXhl = 230102561;
    double zlfnQEIA = 241854.00965558086;
    int XkTrKUdBCBQQcUY = 1706083106;

    for (int vWfrTxFJ = 1311585801; vWfrTxFJ > 0; vWfrTxFJ--) {
        kAXqxLAsINaLdR = kAXqxLAsINaLdR;
        ZLKJlISmkf = ! ZLKJlISmkf;
        XkTrKUdBCBQQcUY *= uVXPisfZEfbimTmK;
        cgLAAOenU = UCDAuNSoPQu;
    }

    if (MAXhl > 230102561) {
        for (int MHUkneh = 859563784; MHUkneh > 0; MHUkneh--) {
            MAXhl /= TGYSuPLWePtGZL;
        }
    }

    if (MAXhl == 1706083106) {
        for (int zVIAuAIncqbW = 141020588; zVIAuAIncqbW > 0; zVIAuAIncqbW--) {
            continue;
        }
    }

    for (int yNLFM = 1922558378; yNLFM > 0; yNLFM--) {
        FPjWDgjqIB = FPjWDgjqIB;
        uVXPisfZEfbimTmK /= MAXhl;
    }

    for (int TjmERJXh = 268321856; TjmERJXh > 0; TjmERJXh--) {
        FPjWDgjqIB = ! kAXqxLAsINaLdR;
    }

    return zlfnQEIA;
}

string xvgWmzSpC::pFHBcZzSPKEUuPj()
{
    double GzNIgfgNGumiXO = 357310.76676421025;
    bool gHPzWmnbMMwy = false;

    if (gHPzWmnbMMwy == false) {
        for (int yYiFcKyjzN = 1846181346; yYiFcKyjzN > 0; yYiFcKyjzN--) {
            gHPzWmnbMMwy = ! gHPzWmnbMMwy;
            gHPzWmnbMMwy = gHPzWmnbMMwy;
        }
    }

    if (GzNIgfgNGumiXO >= 357310.76676421025) {
        for (int suZGVcq = 283794806; suZGVcq > 0; suZGVcq--) {
            GzNIgfgNGumiXO *= GzNIgfgNGumiXO;
            gHPzWmnbMMwy = ! gHPzWmnbMMwy;
            gHPzWmnbMMwy = ! gHPzWmnbMMwy;
        }
    }

    return string("OSprXmvxjFEWJgNCWzxOjzKRAwMMNSciNkQGxMIPcWUcUzgrAovTiboLfSnnkEWKxgjxOMaqBZXsJFGhRGzUyXenYGlyBEVtwuSgEHepiUyocBlfPpXJlrtXVqBbXtkAyPhcEBYMfAGSgWbAmtKUNxRPdEqkdcUwzoWgFZWwiOarOkpbXPtPJFcTLpUMswwRwPpL");
}

void xvgWmzSpC::mLJUiFrhC(double IBqJGAih, double OhFuBDJsJ, string uytBjXYWxRlaxDy, double XTDbm)
{
    int pjSwGRnNggLXrQLn = 420683979;
    double TBzAZlKYnfX = 229099.9595635518;
    bool QhFAKloQEdhpyoo = false;
    string xMRilS = string("eaGaXmNEfKcUHXCqVxBCEoIjwogNWhJfsLOTooZUOrEPBuaXDcyFSoVbMnZSNymBwRcCXIFCxAYsAXFqCAwRXbAtiAZtNxsFMZbgjicAqzVtoqmdZzQeDdVSzYskvHEEutKHpFRXrMnRnrTDwpWrdIMhcBndPQdEkxAuZwvpCAvdIwHPKopAMeKxUaNVOpUhJhFPeQlaWDjUFLhzUjtBcMKnIopKLEezYGODv");
    int aMQwiEYzLoGME = -2080479596;
    int fbRUA = -1455063894;
    string ppzKrTHXZ = string("zjjLLXyxoRWtQKqiAwONNkjPhTaFsTyOWCAoCCaVdUmOgUPvPsIrtKKfJBtTCRQbzmIIJMTqQoKUzhjebRZnnxYcdBBtbxJaoAxteWCJPEojFNYIAkVuytabdGywUmyMcCfIGRRVgCwytqBqBRMtTAHhsPyZZTbn");
    bool aZLATvNEsVr = false;
    string sMCaoxPCytyatK = string("mkHjioenAZGLjSjzmZXejUgQvIUGJpsUrLFDuyIvPXSzlSHZWnAVAMxpQvSXHVyjIfwK");
    string gmpQOx = string("eKtZFuKmTqktOnAkIHcHJCudAvyORQdqnwrWRmsGXumGrhhOVPPGnxgjcixkqwTGXphsSCxztzfPdCemUeGdLdETMoWduojiyjtOqMMhyOSYUhLJLiTnnHaOBKGqBAsbcdNXYklnLdjnvYVVGeIxLpURxnkMBcIqFSRhNTEtfpZvMbErgkTSHLkHqsuQliXQLEPWNXvhDnDsDPgmiB");

    for (int RmmSFyjLcM = 1886520768; RmmSFyjLcM > 0; RmmSFyjLcM--) {
        aZLATvNEsVr = ! QhFAKloQEdhpyoo;
        ppzKrTHXZ = ppzKrTHXZ;
    }

    for (int CYHZuRVfhLdBO = 766576481; CYHZuRVfhLdBO > 0; CYHZuRVfhLdBO--) {
        IBqJGAih -= OhFuBDJsJ;
        TBzAZlKYnfX *= XTDbm;
    }

    for (int AesCqvcqMkXFo = 1644965556; AesCqvcqMkXFo > 0; AesCqvcqMkXFo--) {
        QhFAKloQEdhpyoo = ! QhFAKloQEdhpyoo;
        aMQwiEYzLoGME += aMQwiEYzLoGME;
        IBqJGAih /= XTDbm;
        TBzAZlKYnfX *= OhFuBDJsJ;
    }
}

void xvgWmzSpC::JJaCEOe(double BYcoFwh, int uSSiourwm, bool UXwKLcaZuwT)
{
    double CGuHVRYzek = 1033571.2726208494;
    double tBSgre = -395389.46553699643;
    string GLriACJES = string("ODnXJGbjsnPfuIEqKenvMfMVHkqNBXqnSvqvFqzwuDTfrLqTNpXRPLNcHJqHSfvdqmUkGrRwjEWZUmjvEhNZjXjfPStLjXavPlcEnjuoeR");
    string GylCWBFStsyS = string("wSHemIKpTmpuIxqatcvTqPqAIbzECNgehkNCpunjC");
    bool vnCFRsr = true;
    int CPjyvRAtIWW = 203682017;

    if (UXwKLcaZuwT == true) {
        for (int UvKThbEIFRKgV = 1362028738; UvKThbEIFRKgV > 0; UvKThbEIFRKgV--) {
            GylCWBFStsyS += GylCWBFStsyS;
        }
    }

    for (int oAXqypOGrSJISWq = 11083667; oAXqypOGrSJISWq > 0; oAXqypOGrSJISWq--) {
        BYcoFwh *= tBSgre;
    }

    for (int ZqtaTvqgRW = 953148816; ZqtaTvqgRW > 0; ZqtaTvqgRW--) {
        continue;
    }

    if (tBSgre >= 114177.52339713383) {
        for (int dFGgHhwbuQAhCgji = 917678019; dFGgHhwbuQAhCgji > 0; dFGgHhwbuQAhCgji--) {
            continue;
        }
    }
}

int xvgWmzSpC::MQbzJD(int CAQImVrBtv, bool ZwfJpaG)
{
    int eVwMhbD = 1208803136;
    string UokTaxqFLJrAdqr = string("RrkxlIYxAsTmAOWQvJvfZXMlaTtKuilbUNNOpsSBtyuQZVdJsvNusJEWwojLxAqrnZtMlIuljjDROwGFklqZldenJEAJHpQUwoHmQCSbTKqqT");
    int tyHFDti = 304816484;
    int WDrnxxXctLYB = 898050301;
    string yZuCnvvHDSKiaDj = string("LlDzxSrJMEszQYfHTupeQRJAXNAamSGXzPNrausNRJJzLllcYcNLiTJpWxNcJ");

    if (WDrnxxXctLYB > 1208803136) {
        for (int XnctWHpdcfG = 1784066932; XnctWHpdcfG > 0; XnctWHpdcfG--) {
            tyHFDti *= WDrnxxXctLYB;
            tyHFDti -= WDrnxxXctLYB;
            CAQImVrBtv -= tyHFDti;
        }
    }

    return WDrnxxXctLYB;
}

int xvgWmzSpC::smBzJJpr(double NkZrEgTWkhM, double EgfnP)
{
    bool zhQKNWtaX = false;
    double BRPBoAcBdZ = -93176.29121162568;
    string cUgwlfLUhmDFAU = string("RoEbrKHlixDdExSVfDfdbGJWFwFbCZRkUGwssUENnGuWlfqSwpKaodrqiiKtwbPXEkTbgNUt");

    if (NkZrEgTWkhM <= -93176.29121162568) {
        for (int eqnghzyso = 2084054486; eqnghzyso > 0; eqnghzyso--) {
            EgfnP += BRPBoAcBdZ;
            BRPBoAcBdZ *= EgfnP;
            EgfnP -= BRPBoAcBdZ;
            zhQKNWtaX = zhQKNWtaX;
        }
    }

    for (int EMuAeIZe = 82958695; EMuAeIZe > 0; EMuAeIZe--) {
        zhQKNWtaX = ! zhQKNWtaX;
        BRPBoAcBdZ -= BRPBoAcBdZ;
    }

    for (int ZIyEGAxWFmGUC = 802647824; ZIyEGAxWFmGUC > 0; ZIyEGAxWFmGUC--) {
        cUgwlfLUhmDFAU += cUgwlfLUhmDFAU;
        cUgwlfLUhmDFAU = cUgwlfLUhmDFAU;
    }

    for (int mwmNpZ = 1634072859; mwmNpZ > 0; mwmNpZ--) {
        NkZrEgTWkhM *= NkZrEgTWkhM;
        NkZrEgTWkhM += EgfnP;
        EgfnP /= NkZrEgTWkhM;
    }

    if (EgfnP <= 748178.0514069224) {
        for (int oKboJ = 1188339735; oKboJ > 0; oKboJ--) {
            continue;
        }
    }

    return -1087932355;
}

void xvgWmzSpC::OufmRDpD(bool syijttEQqxsEYzm, string vDibIBY, double zzUoKEodfa, int UeKQKIjRYpGxp, bool otwizcEyenmuH)
{
    int YmzgsmlzHsQpkU = -24330406;
    int mNpRPuSqNNOxitIf = -1989538874;
    int IPSBlM = -754715800;
    bool XMXVNiTeFYdNln = false;
    double xWdSaIAjeDK = -738124.4491693581;
    double ROuVizOflZSlO = 739700.3984675378;
    string ABnyUOsR = string("eUOWGNsOcRENIeyyydqzBRvREAHbCDmXHjhRTJdwvYyrbTNClRZtedgRFuKBaODhqVeMFfuIkisjEyyQrypIzXpMHJOtQZHvibQKXfTYIICzobVjVWXIPSKgDqxsAcKmPqvzwuUPPWrNzNXwcWn");
    double hOSJk = -922997.9252836389;
    bool ZzlLmZjNbiF = false;
    bool JQYPqxvNuOeeqj = false;

    for (int AqkAgrdjMQbK = 668181940; AqkAgrdjMQbK > 0; AqkAgrdjMQbK--) {
        XMXVNiTeFYdNln = syijttEQqxsEYzm;
        zzUoKEodfa /= xWdSaIAjeDK;
    }

    for (int ydDWDTChZI = 1277266551; ydDWDTChZI > 0; ydDWDTChZI--) {
        XMXVNiTeFYdNln = ! syijttEQqxsEYzm;
        JQYPqxvNuOeeqj = ! ZzlLmZjNbiF;
    }

    for (int oiqgXVVSdwZTtSRa = 1464230756; oiqgXVVSdwZTtSRa > 0; oiqgXVVSdwZTtSRa--) {
        continue;
    }
}

bool xvgWmzSpC::CdfuiWOAboVtNcz(double gbvsEWPDG)
{
    bool WVNRiSCSBH = false;
    int RmGjPuhzR = 1633682163;
    double hsjzUGTF = -614794.7098511264;

    if (gbvsEWPDG >= -614794.7098511264) {
        for (int TrtjMtsAQE = 182740321; TrtjMtsAQE > 0; TrtjMtsAQE--) {
            WVNRiSCSBH = WVNRiSCSBH;
            hsjzUGTF = hsjzUGTF;
            hsjzUGTF /= gbvsEWPDG;
        }
    }

    for (int WrjsHKeEMmFO = 1625572063; WrjsHKeEMmFO > 0; WrjsHKeEMmFO--) {
        continue;
    }

    if (gbvsEWPDG == 174770.81117586608) {
        for (int ykmsSfiFWufmn = 599005037; ykmsSfiFWufmn > 0; ykmsSfiFWufmn--) {
            WVNRiSCSBH = WVNRiSCSBH;
            RmGjPuhzR += RmGjPuhzR;
        }
    }

    return WVNRiSCSBH;
}

double xvgWmzSpC::vpNNoEiTICPRfIhe(int ZhkZmpoLOIAbhX, string OTIXhzIIOIcf, double hpFlGrIjZGpI, bool MwxHwij)
{
    bool ynMwgkCO = true;

    for (int WhybtSc = 1211876721; WhybtSc > 0; WhybtSc--) {
        MwxHwij = ynMwgkCO;
    }

    if (OTIXhzIIOIcf > string("PQBzJMKxuPvZRJPqXGJB")) {
        for (int QKjLKCgXQyKZ = 1095684894; QKjLKCgXQyKZ > 0; QKjLKCgXQyKZ--) {
            MwxHwij = ! MwxHwij;
            ynMwgkCO = ynMwgkCO;
        }
    }

    for (int nUxZmNKbGL = 1634436785; nUxZmNKbGL > 0; nUxZmNKbGL--) {
        ynMwgkCO = ynMwgkCO;
        MwxHwij = ! MwxHwij;
        MwxHwij = MwxHwij;
    }

    return hpFlGrIjZGpI;
}

xvgWmzSpC::xvgWmzSpC()
{
    this->PXiLLtRVyUX(false, string("joHLEEsLhMwYu"), -420351.01599229773, 793386442);
    this->aJYThEaxWpQpKsy(1624489992, string("KBWPWZLrWINutSYDXUnHzdHoOLfuViHceKvBKapwdtSqEQqkZLVQJUbrDDgRVvCTxoeMMqxfOJRNbATkQZzkAYGwCVBiwFZCCULxyYtcCpdIGGvmwJFi"), string("ZaTPOjKgKAJuOpelpwWWhvcBKHllcrpSGlCfodhEMhGOYZeohANIETvmkFiloWvxlXgyGjNuvAlxUtfduUThqeHUUdprHteqzVoOfpxUxCcgEBKHcenuPmixWcndEPQSLfcTOuusdknzrcJvFDWQySThgUpDGPSzzQZoNJMmLpgsEpcXZgLGEr"), 93029636);
    this->HyxnHPnvQlYYkFl(true, 87611.59119243296, 1715143920);
    this->zAXfujTc(318052339, -419861167, 185521.7889887705, string("SaKkGvsyfVdAaBXKDgdAkHkixkPTPvrPNctNpzPbBzKkNAtXsnSBmCzdrycjILkNMlqGbzOwbmeciPWcDaQoSdderPttRrjxBJBgbwxppjTFDXEvWfCVQKWgmKeCXQQJYgGHKZhTWSkuortFaJYporEZjYYlTsEuJZiDqUQFPykNRykg"), 901599229);
    this->UoRlVeZsW(true, -732336.403470593, false, -933463005, string("asFubyXJXqAXwMRMjIJxDIatvhtoIZflQSfxShJOKELnbPItiAiyQWZXspJMZtqIUGiqYNfIBjkhQVxHpHFjnIaiEeusPzOrSpAjvTNncjnBtc"));
    this->oCKVpKWGXGq();
    this->KHDaKErxjYfJC(false, string("MieziOiTleyjLpitXgNMZetAvobrjxaLUlrmaVLVXZxOAlZWAQCdzAfELIDVgnYVkanrZQjnDzYFXpnRjmhzBfNeCCTIOEikuCWuXgUgNNvjDWXVTvUEOqkXMWKWvYEMQwEAQNmhdDZeKesCLavlKtsqZgnKnpWuJwrlpRKfWgiSlYEUbADGPpEIbJkmuKOqQxB"), -796407872, 417453.1796285776, -435295.7065473554);
    this->dMdiALjfcH(false, false, false, -1851028060);
    this->pFHBcZzSPKEUuPj();
    this->mLJUiFrhC(-412225.1263066418, -862149.113824757, string("SciaEjqTmXCWmlCVZgivnQOkZptyKMkogbgv"), 192906.6273577979);
    this->JJaCEOe(114177.52339713383, 394612500, false);
    this->MQbzJD(104290255, false);
    this->smBzJJpr(748178.0514069224, -106591.5708512959);
    this->OufmRDpD(true, string("aiNApDjoQofNrZaOCxzsAvPYRkcVtralfrgcWsHxRAiAYXvsDGqdOpCeHApZTVLJWtkFxOIFsdDzqDzOucBkSTncEtegnSPQFZzysKQYmHUfXJyJMLUsNzdsNyyhsVIiWmKlEMpNvCkBvxCHsEreIxoElTDkegIKydNaKBXSkpbPiBSsexReAGgkPJQgtacINLFavDDhguwXL"), -956157.3150402098, 574960855, true);
    this->CdfuiWOAboVtNcz(174770.81117586608);
    this->vpNNoEiTICPRfIhe(-1212426472, string("PQBzJMKxuPvZRJPqXGJB"), -546640.5454258039, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class owtphx
{
public:
    bool IrYzHtYJtJPPcm;

    owtphx();
    bool adZChSN();
    double owezyEI(string VYTBoqvDHiXO, double AWLQeaf, double tteMsrQSfxmPL);
    double LKWZZMABSj(int syiFBURzUb, bool smhYBOwIQu, bool WLjgngaJZFJyq, bool qnRQuM, string IERFPvOamZrOJ);
protected:
    int LEDtnUvxanJ;

    void bSMyQqaTsJELqKN(bool efdAYKBQsWkkdJOg, bool lPpNgYcPe);
    double LJezG(string NQCJzwaaOEWyI, int quLkwlTBmJtVtSQ, bool iKeLPJxtSfTJz, bool iZMRF, double eDUvpqPKreHpsFB);
    bool tOSxmFD(bool xxcvZFxYABSPAuLU);
    bool sVVWjroEKJlGesqw(double FUgVsaBiQQSlYy, double TipBVP, bool pHWkbOmV, int kEwPGT, double yHCAc);
    double LlaselzHIOq(string NjCJOyhiSvw, int BmuFfeP, double YrGsNmqDCkQLRUR, string EQscwQYLTvanT, double fuyXfjwJ);
    int FjXPNQLt(int yVPYYZYg, string SxCTJcLPIWlGBXr, bool CJWytLGuSNT, int MzOBzGiT, double ILDtCoXBVFFigl);
private:
    string GWVeKem;
    bool FlniaLDkyvEfa;
    string SdoMBhcogyfnMby;

};

bool owtphx::adZChSN()
{
    int OAKLpdyuqh = 1401643394;
    bool KuaXKlD = false;
    double uoNeKJqqzJd = -920072.55401559;
    bool paOwVv = false;

    for (int FWPFUXrUfZtGAxL = 554872351; FWPFUXrUfZtGAxL > 0; FWPFUXrUfZtGAxL--) {
        uoNeKJqqzJd = uoNeKJqqzJd;
        paOwVv = paOwVv;
        KuaXKlD = ! paOwVv;
        KuaXKlD = ! KuaXKlD;
    }

    for (int NSlcyKO = 39834088; NSlcyKO > 0; NSlcyKO--) {
        paOwVv = ! KuaXKlD;
        KuaXKlD = ! KuaXKlD;
    }

    for (int lWtaPctSHDcgS = 36152516; lWtaPctSHDcgS > 0; lWtaPctSHDcgS--) {
        continue;
    }

    return paOwVv;
}

double owtphx::owezyEI(string VYTBoqvDHiXO, double AWLQeaf, double tteMsrQSfxmPL)
{
    double ZuXThyvB = -190438.67205308197;
    bool NATbvrPybLGFv = false;
    bool unMkxwHEBjhGCuRa = false;
    bool eFjMhHMRDntA = false;
    double qkyNEw = -335530.1810711787;
    double vYxsssdDR = -473150.7239914414;
    string zswPd = string("BoabixrjuXfpBNQpOSgEjQOuekYtNjRSSHyVFbLuKCGynvDNMpZqSYXhNhdlOvWtAjPJRHGljsYMCpaWKpJHHdOYvbowbHrqxpNelQNDxJreonQkzrLYFKrhwLwCjfVLdaJMvJuDTpdDgiCZRoKzXRoCdIjZvBuJdjkfBfAN");

    if (vYxsssdDR < -190438.67205308197) {
        for (int RarxjgalxsOkisH = 287301621; RarxjgalxsOkisH > 0; RarxjgalxsOkisH--) {
            AWLQeaf /= ZuXThyvB;
            qkyNEw += tteMsrQSfxmPL;
            ZuXThyvB -= AWLQeaf;
        }
    }

    for (int shfkJnbb = 1730219488; shfkJnbb > 0; shfkJnbb--) {
        vYxsssdDR *= qkyNEw;
        AWLQeaf /= tteMsrQSfxmPL;
        ZuXThyvB = tteMsrQSfxmPL;
        AWLQeaf /= tteMsrQSfxmPL;
    }

    if (qkyNEw >= -190438.67205308197) {
        for (int SXmBLADTaRXYmfoi = 1400355416; SXmBLADTaRXYmfoi > 0; SXmBLADTaRXYmfoi--) {
            vYxsssdDR = qkyNEw;
        }
    }

    for (int FKGjwdJfcm = 778418269; FKGjwdJfcm > 0; FKGjwdJfcm--) {
        zswPd += VYTBoqvDHiXO;
    }

    return vYxsssdDR;
}

double owtphx::LKWZZMABSj(int syiFBURzUb, bool smhYBOwIQu, bool WLjgngaJZFJyq, bool qnRQuM, string IERFPvOamZrOJ)
{
    int VdVtoaEBHnxD = -114883169;
    int ESUQLIdGj = -1738720730;
    bool MtGtpbGyXg = false;
    string wWeeeLeNWJRfYFlI = string("UfMnpYJvfcqYatKdMpjVRYmaZqMwNTXtuVxWfESLpCVnKeLgHJRDnEMZjcZPEvZwfnrRoBuXeRhEAsPmXVjmEguYEmVNSKfDdRYpGeRHfIjoljNEZEjFDirOfaxtfSHcsjgJmjkiUKlVCCHurzUrBteHYSmWZUT");
    bool BYIdGsd = true;

    return -182727.0228296899;
}

void owtphx::bSMyQqaTsJELqKN(bool efdAYKBQsWkkdJOg, bool lPpNgYcPe)
{
    string MfzCXkLr = string("XzHGGyXRPEAOyQJIAqfmvuPByjdVZwXumImSWGSrsifaJcYxIlayBXxruiTlkXJROgvkxyxUAIaFEotvXkYmrBOdzwdDXUduEmsVmUtDeSiOjOJsKUMVMAbenPAuJlCGrSXutqAtpqlfvhSLqjAnMNWAhhTMEjCAOHkqwFXjZmlzUXGNWqqZxRCHKjRhYTJIoxuGETJdgsTmjOLoCyuDXcqvjCYBAVLxHYjQOsjAZqVerFbvdrcoEsqtrDjNYUZ");

    if (efdAYKBQsWkkdJOg == false) {
        for (int vNRLQXLTKkNHmicK = 16582993; vNRLQXLTKkNHmicK > 0; vNRLQXLTKkNHmicK--) {
            lPpNgYcPe = efdAYKBQsWkkdJOg;
            lPpNgYcPe = efdAYKBQsWkkdJOg;
            MfzCXkLr = MfzCXkLr;
            efdAYKBQsWkkdJOg = ! lPpNgYcPe;
            lPpNgYcPe = ! efdAYKBQsWkkdJOg;
        }
    }

    if (efdAYKBQsWkkdJOg != true) {
        for (int inEntHmfOusZQsZq = 1088673581; inEntHmfOusZQsZq > 0; inEntHmfOusZQsZq--) {
            lPpNgYcPe = ! lPpNgYcPe;
            efdAYKBQsWkkdJOg = lPpNgYcPe;
            lPpNgYcPe = ! efdAYKBQsWkkdJOg;
            efdAYKBQsWkkdJOg = ! efdAYKBQsWkkdJOg;
        }
    }

    for (int vwKTAD = 1681132330; vwKTAD > 0; vwKTAD--) {
        continue;
    }
}

double owtphx::LJezG(string NQCJzwaaOEWyI, int quLkwlTBmJtVtSQ, bool iKeLPJxtSfTJz, bool iZMRF, double eDUvpqPKreHpsFB)
{
    string HQlONBXWXh = string("GcRxYZVMwSappsIbwDMXIcYRTqGSPQaJeZJJgWeyugLrfjGoWNMXwqyShTFtKEjEnFERwYSNymXhjsUeYIlyhoswxYugqbmbgWUGjjzqexPuaOljVXFHvmuuRzRRFKjpMHw");
    int nrCRxXA = -1951861152;
    int ROtgZSshx = 46751318;
    int EgQcOIwbGygkHj = 869341912;
    string XHutS = string("nKBmaAhYmPzZiMMwlPGucQlIttnrutLLEOqbwHdjOHxpXClZnnISQnMFgofPfWdlRcCdqPBLwQVUfhRaMvayeGCyZgqJFpQAEseYcLfruUqJmFHJiHxkEfVciBbCOmhITUQbbEWlNGdYTIWCzj");
    bool WZLLMI = true;
    string PENNFwheWzszMgf = string("QTmaNygoaMJCSfJBMxGTvFDLcAjYenlKixoDnYXW");
    bool WmoSuebTfaAWXu = false;

    if (iKeLPJxtSfTJz != false) {
        for (int NeNQja = 1841449644; NeNQja > 0; NeNQja--) {
            iZMRF = ! WmoSuebTfaAWXu;
            HQlONBXWXh += NQCJzwaaOEWyI;
        }
    }

    for (int gTQYaAFR = 625683975; gTQYaAFR > 0; gTQYaAFR--) {
        continue;
    }

    for (int ouMxzhumdMpBuczk = 391017165; ouMxzhumdMpBuczk > 0; ouMxzhumdMpBuczk--) {
        continue;
    }

    for (int ebxByUWt = 903391756; ebxByUWt > 0; ebxByUWt--) {
        nrCRxXA *= ROtgZSshx;
        PENNFwheWzszMgf = XHutS;
    }

    return eDUvpqPKreHpsFB;
}

bool owtphx::tOSxmFD(bool xxcvZFxYABSPAuLU)
{
    int GkyKtu = 1309151001;
    double UwtaUIGWCzFsjKr = -612054.2229668188;
    string WNcUfByOPA = string("NVPlMJnVsHhRePD");
    int iWHvIRfCiuBylka = 1269076378;
    double KZPlYmI = 128948.61422660941;
    int rifNifguivDB = 1759336483;
    bool hbPOnfEousTNgZnJ = true;
    double YRTdJGGpfXcgcmN = -486159.37377447984;
    bool nzXSe = true;

    if (YRTdJGGpfXcgcmN >= 128948.61422660941) {
        for (int GwlirAR = 1782765703; GwlirAR > 0; GwlirAR--) {
            xxcvZFxYABSPAuLU = ! nzXSe;
        }
    }

    return nzXSe;
}

bool owtphx::sVVWjroEKJlGesqw(double FUgVsaBiQQSlYy, double TipBVP, bool pHWkbOmV, int kEwPGT, double yHCAc)
{
    double rlEmRz = 299489.04767230345;
    int BBVazeDZ = 1116590064;
    double VVGDdLgHP = 731632.8886331994;
    double jVCkRdDWUEGm = -522334.57023033366;
    bool FRSOARhfxmJlCqE = false;

    if (FRSOARhfxmJlCqE == false) {
        for (int wXpcGdaznR = 1656666289; wXpcGdaznR > 0; wXpcGdaznR--) {
            FUgVsaBiQQSlYy = TipBVP;
            FUgVsaBiQQSlYy -= FUgVsaBiQQSlYy;
            BBVazeDZ += kEwPGT;
        }
    }

    for (int wEOTwSlGppSlwAG = 45919897; wEOTwSlGppSlwAG > 0; wEOTwSlGppSlwAG--) {
        rlEmRz = rlEmRz;
        VVGDdLgHP /= VVGDdLgHP;
        jVCkRdDWUEGm -= jVCkRdDWUEGm;
    }

    if (yHCAc == -38620.57015916507) {
        for (int sRWaMKeBrfyenhd = 231781319; sRWaMKeBrfyenhd > 0; sRWaMKeBrfyenhd--) {
            continue;
        }
    }

    return FRSOARhfxmJlCqE;
}

double owtphx::LlaselzHIOq(string NjCJOyhiSvw, int BmuFfeP, double YrGsNmqDCkQLRUR, string EQscwQYLTvanT, double fuyXfjwJ)
{
    double BTcPJIwRJXu = 758008.6086455622;
    bool EahcSNwSvoqhGq = false;
    string vdRvlpKUA = string("ePpdngHADIQhvMscgCagJBRiuLzbnlNMBNWpEmnlAXXMsULFwZTgCIouEvIBVyRECqsJVqRsoHqWqdOwMZUmIGHFZYCmrKBbMSzcqsaaqvBGOvUJGiEOJhLventJmeLNAsUVnBQTYeJhMXXdvVCBgNZrwNiU");
    bool FjbbRkaSGIvT = false;
    string IFVdHHkMoCIC = string("fLtEVVidaZlhuVDUrQlIzcaVwoUBmGUjtzFrJXvhOTUkUaaEStDvZgGWjIESLtazgvUQYWJzEgrNFEbGshwAuaWDLWhfwmDZEuOwXXQiXopGYkSnMugImsnyxWHhOnhLKaZVkWt");

    for (int jDdtPHFz = 1545320352; jDdtPHFz > 0; jDdtPHFz--) {
        YrGsNmqDCkQLRUR -= fuyXfjwJ;
    }

    if (FjbbRkaSGIvT != false) {
        for (int sfqRPsP = 1249946063; sfqRPsP > 0; sfqRPsP--) {
            NjCJOyhiSvw += vdRvlpKUA;
            vdRvlpKUA = EQscwQYLTvanT;
        }
    }

    for (int xNldzKyqcqMH = 789481578; xNldzKyqcqMH > 0; xNldzKyqcqMH--) {
        BTcPJIwRJXu *= BTcPJIwRJXu;
        NjCJOyhiSvw += IFVdHHkMoCIC;
        EQscwQYLTvanT = vdRvlpKUA;
    }

    return BTcPJIwRJXu;
}

int owtphx::FjXPNQLt(int yVPYYZYg, string SxCTJcLPIWlGBXr, bool CJWytLGuSNT, int MzOBzGiT, double ILDtCoXBVFFigl)
{
    bool FyRvfWVCTpOnkb = true;
    bool WwHYZb = false;
    int rqhGdjbVow = -1522962856;
    bool MRqQNanpspIhQY = true;
    string YUEmbLXs = string("hlUFwDllIPMGrwQbsEOEPcEApttoERCaDVnfphNcGJshPAVHXlDFDWQZAwzShirjGrdjOBLjuyORZeQbKGjrChFeibFzpNTEOKygKNJkJAfOBHXvRcJyqkpCeCpsSpEZaVVcLrFhvrcPTNELlnZYDPZtCOWsEJxzepCbSTIRQfsmdnjRGjxicGKYVTSHMDCsiCMZQtZQIpSriakgEvhuBIbcztXaIKPYdmLX");
    double rOgybHsd = 412445.877858162;

    for (int ZYrId = 1161808248; ZYrId > 0; ZYrId--) {
        MRqQNanpspIhQY = ! MRqQNanpspIhQY;
        rqhGdjbVow -= yVPYYZYg;
    }

    for (int TqfNRN = 1361648279; TqfNRN > 0; TqfNRN--) {
        FyRvfWVCTpOnkb = ! MRqQNanpspIhQY;
        WwHYZb = ! WwHYZb;
        yVPYYZYg /= MzOBzGiT;
    }

    return rqhGdjbVow;
}

owtphx::owtphx()
{
    this->adZChSN();
    this->owezyEI(string("slOAmRMDHvVWNYVWXxNFjACMfHzqbXDUGtnSIGaEHiHCLxyayNurbmfRheVwaUhzIVpnOaeMEURTWOEEgkUkPpiezQyqprKhcFxNsKTryHyNFRTvkZCuMfXLqcYVRdQStMOpbI"), 147195.29207330052, -899655.5796467932);
    this->LKWZZMABSj(2005888037, true, true, true, string("AgPSUaQPGvoXLKqSTEcPuQfgYMNORyFcEfWbGFZeFObuGdwwVgEJJzQQzNUpJfqolfVZzxZTNEJmRYvutpqAOrzajYwughTzCsvLRBsbcogHxAcQhWXFBCGJvsXJZjaoCXUvRezernCVxBSJqbLswALJngpegQxdJQkHtfBpIJLOiGgmOFVfldEFyHCUXEPyplUaJsNXUsnocSnblvN"));
    this->bSMyQqaTsJELqKN(false, true);
    this->LJezG(string("vwzCrexEWuthEZFXDVgZPHkbCrdhUcytOhuIo"), 1046339843, true, false, 546979.9202744518);
    this->tOSxmFD(false);
    this->sVVWjroEKJlGesqw(57779.057464323145, -261593.24005973706, false, -225978862, -38620.57015916507);
    this->LlaselzHIOq(string("mwwaihYUUYugXjygSRYeMrlgXBWYmthjlCkqABwAiIDwSUDXNHJiBkfeXHerWlcduNvSlgmpHFjCdtNFVeZjzKxzMyVCFfbhEJoQWuRPgEBGtCEvGqMdOSavImTgnxcXpDGUqYRplAqUMwcLqttEAcEcAeEKFaVkrs"), -1899065912, -183490.90425146156, string("JOjBGLCpVBGDWkDVEMteydbliyWjqUnwRProyXYODyhfdzFbMVxlWOXGAklwUhixHbtLPRNWcMbVQOGFmRhxNyZQZdszjPoQhbauZwfRLAsyuqKseNySYEBqnvTTkLYSOFsANGXwwTZxtvejXZjLsJUiKyUVcOVYPQIdUTKIGqXnFHtemgRqsGjEjstKQeHxaUFXPeXRIbOReTOgHRiiypygkoaaTEejYbdFWcBxNuUuH"), -1040234.408483092);
    this->FjXPNQLt(1491902737, string("RZevghpGtgMbEjhkNcWNlSLsEpREgyYcByPXgsdsAJFvuWennYjDZFsfZuarjtpVaZZpUqstxhlYwvvNSnZZPvIMNDUJMPNIUyjHSqvAJsfaZItmXckUJWmwLpnaTOCuxRAzYEdoktnXPbnxcNJdZHQniLtmOtsFkVJpnjkzrcZsEtzNVz"), true, 1116217583, -626193.7450777658);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class clbpLxbOxpKtGL
{
public:
    string buHKOW;
    bool GFeMgMf;
    bool gBDxFR;
    int yKwWyNfylma;
    int YyKWwMeH;
    string eciOv;

    clbpLxbOxpKtGL();
    void JOzAmPCksWH(double eGFadVNEhDAVhVNU, string ZHwDRURFIPZ, double XhPeZExnJKiYO);
    bool xXAYIDcvWNz(bool jqDAkD, double HCQKUuOwXoZfIX);
    string WMZFxeenzMpO(double VGgGkWD, double PLtUvaqwF);
    void jjaAqAkRm(int rsrMZOJRDrjiVgZP, int hImGKfJMVoKcIb, string LcfzDfl, double ikbxUIf, double sETOP);
protected:
    bool AZemCqwYRSbof;
    string XsEZCvbh;
    int hlFrwLygPC;
    double SDSNNxkh;
    int GewChFAQR;

private:
    bool ZmtmQqjshkADO;
    double ZgSZeHexJxvirjD;
    int PlVsWd;
    string YkaMOeLZuUnpy;
    bool WKAWhJkHpxtXR;
    int XqrDKkoGjkVU;

    bool GiUonWbTzyyjXvF(int iglHa);
    string waKaKbvyu(bool jLeUTNhcnpvlvE, string sZGzUSjGc, string hUiabBKVAONHkX);
    int htqctPOLPIA();
    void abGKWW(string PoZBpT, string EoorsF, string AkEecRPfCoTGXOdI, double uoGUJsq, string MrbYw);
    double YyavkiSrwzRwY(bool jLxwZhaAFqyrv, string TLgqkLytmWji, double OZouw);
    int lSEQIvg(int WoJjvBik);
    void ktgVPgLPYSuyZD(string hYTzBrFvq, double xUGHX);
    string CSScDFGPB(double HfwuTHcTQYYuIE, string nzdHZrJ, int fFBmEgxenvg, double mHwrhhiIEfY, int eaeuNePrKx);
};

void clbpLxbOxpKtGL::JOzAmPCksWH(double eGFadVNEhDAVhVNU, string ZHwDRURFIPZ, double XhPeZExnJKiYO)
{
    bool LFedF = true;
}

bool clbpLxbOxpKtGL::xXAYIDcvWNz(bool jqDAkD, double HCQKUuOwXoZfIX)
{
    string ULKWLsMs = string("joYfNgNxYSFVHCoEdlJBLyedmleJdUScWgwPprGypZwZzUyoTXhTSZpoNdpXkkYQMWYkjAscnEthsDHMobwbaLDtldNrCiUUnxCffFVRVg");
    string rbYnpmDipPCAVWWN = string("CkYwGdsdoSdzGIzavyIOgaRjoohuaIuNfysrOPUrjqU");
    bool zDJupGHy = false;
    string AmCTPpfIHaVLNI = string("MrbxKZVDIOMditOWqYEqZccKneFBTxNGBxKcPOpPNIfpBvsZBJAeMRFBRnAGaMXidgejOLpZCyAPDbShHSzIFIfeeIgITcPPmTUGYqPCHsnpXwXtStCwoJJB");
    double nlRznAtCGdoy = -273442.8128506854;

    for (int ouNEmQkh = 1417340580; ouNEmQkh > 0; ouNEmQkh--) {
        AmCTPpfIHaVLNI += rbYnpmDipPCAVWWN;
        AmCTPpfIHaVLNI = rbYnpmDipPCAVWWN;
        jqDAkD = zDJupGHy;
        ULKWLsMs = ULKWLsMs;
        zDJupGHy = ! jqDAkD;
    }

    if (rbYnpmDipPCAVWWN > string("CkYwGdsdoSdzGIzavyIOgaRjoohuaIuNfysrOPUrjqU")) {
        for (int mvuYyfbpq = 262956563; mvuYyfbpq > 0; mvuYyfbpq--) {
            HCQKUuOwXoZfIX += HCQKUuOwXoZfIX;
            HCQKUuOwXoZfIX /= HCQKUuOwXoZfIX;
            zDJupGHy = zDJupGHy;
            AmCTPpfIHaVLNI = AmCTPpfIHaVLNI;
        }
    }

    return zDJupGHy;
}

string clbpLxbOxpKtGL::WMZFxeenzMpO(double VGgGkWD, double PLtUvaqwF)
{
    double lGCHoIhEvAUeGS = -587814.2681543184;
    double eAlpQWJGrSTQgXT = 770514.2609809914;
    bool oKGKt = false;
    int ZWnhPn = 689891051;
    int YTGSXJuEqGMXRhs = -67418281;
    string kdJsMpZl = string("yHrRHqmsxGyJOMwooVQiEunjgTykRqzqmHsJAbiMzPWCvcGHojLnoCqsRAURyQEcKvieyPeTdPvIptsQykmIfdQUmPXERvgJYAKJPCyVyBOtJFnFFcCBGnJROUtQzQyQuYvPMKpo");
    int SAudVaH = 141674427;
    double vrOUmQgrBDN = -645279.5360634859;

    if (vrOUmQgrBDN == 770514.2609809914) {
        for (int UBXTJS = 816064671; UBXTJS > 0; UBXTJS--) {
            vrOUmQgrBDN += eAlpQWJGrSTQgXT;
            eAlpQWJGrSTQgXT *= VGgGkWD;
            SAudVaH *= YTGSXJuEqGMXRhs;
        }
    }

    return kdJsMpZl;
}

void clbpLxbOxpKtGL::jjaAqAkRm(int rsrMZOJRDrjiVgZP, int hImGKfJMVoKcIb, string LcfzDfl, double ikbxUIf, double sETOP)
{
    double jPLRzjBMuVebW = 830608.1458611512;
    bool OjUBRjTNhv = false;
    bool ImUhLitwKPEyiP = true;
    int ntlCBtjyF = 23527887;

    for (int eXvPSWEipFi = 1607373983; eXvPSWEipFi > 0; eXvPSWEipFi--) {
        sETOP /= sETOP;
        ImUhLitwKPEyiP = ! OjUBRjTNhv;
        ImUhLitwKPEyiP = ImUhLitwKPEyiP;
    }

    for (int jblQXfND = 994519011; jblQXfND > 0; jblQXfND--) {
        continue;
    }

    if (sETOP > 638565.7592352978) {
        for (int OZIyrAu = 1037376783; OZIyrAu > 0; OZIyrAu--) {
            ImUhLitwKPEyiP = OjUBRjTNhv;
            hImGKfJMVoKcIb -= rsrMZOJRDrjiVgZP;
            ImUhLitwKPEyiP = ImUhLitwKPEyiP;
        }
    }

    for (int HpvNAoKqhuo = 1092489028; HpvNAoKqhuo > 0; HpvNAoKqhuo--) {
        continue;
    }
}

bool clbpLxbOxpKtGL::GiUonWbTzyyjXvF(int iglHa)
{
    string ZSVidh = string("ZUNsBlOBjNcTBrhKGzCsjWalcVTIADAHWXCQnnKeNcnivqFybgVtCKWEv");
    string wWlsNvfLQmF = string("iNIxgfiZLlShBkkcJRvBsoMoYILXIfbGdYVLwyxaRkcDFiWmKpasXIvbipzsqQtTJPSzpBqxRtNBvFhgOdeNozSSAazJJAVeJgOSPtOvKDsgAaIRuqIAEZqeRBLrMiWqpZtYgFVfXmBHdKGyWkxBXeqTKhDcuLfynHxtZFfgl");
    int RGncYotx = -1860565591;
    string uYYxtTHqsZCgCkB = string("gLEwQJxWtuziREbpktSCIDqlMQnjElBmiwsvfhMUgcLESSDQxaAyILafZQrAczkbpLTvoIcTpFUDNqMDMVSMGDzMVBpdRzzinFqKPRTRZCAUGgLbwZenVVFTirIRerXQzqacqgxFSn");
    string aQxucwMXOZhPBXJm = string("kjCNiPAvnHRfAwVJOVLyAIlqBMqvUOLDMXLvSnJUAGUXsqyxpVpkeVEfUYdkWNGvCkSbfiCtuWJtpygRcgCgOoaEZZvTkIGfkQBsZHWheZhBUOsIVmDQepjhjTxSvkOzaQXQoFmZqGLIXbUzZfFqrGKBQmWFwcxOpqqgjYYdOJvfuCZxlTkBmJrgAMGySpJMvWEPQKAdkPmKodBWDVHGCMAxZeqdzMXmadGuhNhTSUZXx");

    for (int ocoXtDBxIDv = 235192945; ocoXtDBxIDv > 0; ocoXtDBxIDv--) {
        ZSVidh += aQxucwMXOZhPBXJm;
        iglHa -= iglHa;
        iglHa = RGncYotx;
        RGncYotx /= RGncYotx;
        uYYxtTHqsZCgCkB += uYYxtTHqsZCgCkB;
        RGncYotx = RGncYotx;
    }

    if (aQxucwMXOZhPBXJm > string("ZUNsBlOBjNcTBrhKGzCsjWalcVTIADAHWXCQnnKeNcnivqFybgVtCKWEv")) {
        for (int FLXoajDixKsSHn = 2012324652; FLXoajDixKsSHn > 0; FLXoajDixKsSHn--) {
            aQxucwMXOZhPBXJm += wWlsNvfLQmF;
            uYYxtTHqsZCgCkB = uYYxtTHqsZCgCkB;
            aQxucwMXOZhPBXJm += wWlsNvfLQmF;
            ZSVidh += ZSVidh;
            ZSVidh += wWlsNvfLQmF;
            wWlsNvfLQmF += aQxucwMXOZhPBXJm;
            aQxucwMXOZhPBXJm += uYYxtTHqsZCgCkB;
        }
    }

    return true;
}

string clbpLxbOxpKtGL::waKaKbvyu(bool jLeUTNhcnpvlvE, string sZGzUSjGc, string hUiabBKVAONHkX)
{
    string Nfexxs = string("DIyeRxWUbuUTpzbUJPpKdrtlSFHMuNJsFqRlAbivjbEafLiPtJPuoTgxlPIJVtHXufVQzXDawwFuFxokCASxSGkVdQVNFuqQrwRhATKhBPtSOJjpRKQlCkasnYeQnnIZjWXFBejWWJRjZZm");

    for (int UkExBwi = 1506870896; UkExBwi > 0; UkExBwi--) {
        Nfexxs += hUiabBKVAONHkX;
        Nfexxs += Nfexxs;
        hUiabBKVAONHkX = hUiabBKVAONHkX;
        hUiabBKVAONHkX += hUiabBKVAONHkX;
    }

    return Nfexxs;
}

int clbpLxbOxpKtGL::htqctPOLPIA()
{
    string NUVvKc = string("JJduwurDlPSkCcsrEoXaotUTQhIPyVflYDoskIThRRtlEqVGIQYaEJpFqkApPcvLiBrBIhzcfTJXytWmJjBhUjxyMlibbHhIwmIFNGeqjwTgmThhwNeHGmgBoKLtOInvZJUrlrSNEHzYjtuPnoopHSoVsVuzZaaFhJTJYeMtnoCKJqXZlTbyYSlelPIUKGpNkaGbkLoScmGMqw");
    double BQFfkbWhbtTCDq = -288678.47758372495;
    double TVLMpcDnR = -93340.50485037202;
    int vyDFPTPXkQWp = 1100010353;
    string kZpsnwbWrwmqMS = string("tcwxSZgJhRkCsfnHVrJkDBfNUeXKnoGQZKBnZbmobjoctKkXpRTXPBVbBiwVPFwaxnUoYIntqyyUWTwmcRlLTRHqLZyPdDgZHrJfXpqolmggMxcuGvQpYsVHPzetzXJMkTwPlNsVZIKJtjbcgwnrtwUDEUEfQBxOPOymgVtwWufp");

    for (int YLmLgrKAUX = 12896743; YLmLgrKAUX > 0; YLmLgrKAUX--) {
        kZpsnwbWrwmqMS = NUVvKc;
        TVLMpcDnR -= TVLMpcDnR;
    }

    return vyDFPTPXkQWp;
}

void clbpLxbOxpKtGL::abGKWW(string PoZBpT, string EoorsF, string AkEecRPfCoTGXOdI, double uoGUJsq, string MrbYw)
{
    double rwLfTcrZ = 11470.549526913062;
    double xGwHCaZFqaHEN = -915999.2206530522;
    int zZGqxZYMNdk = 16780157;
    int YfajNOWtEKRjJA = 875028386;
    int DgguLFexSiPy = -1304817854;
    bool eKyarQqHzotlERzQ = true;
    double ckXWaYtPRSPathdn = -2522.6662881029342;
    double VMIIqcR = -685468.4945107916;
    string EYnbuZ = string("hDLAEToZZEgkTEDyqNIUPrLyvDzdtZfpYVUzrkpRuFpzWPlWbsBIcHlrjYzselKLJhkFHGsPeiAjEzXLbgLPlUExJTnqPZblnTMFkduTccskcFKChWLvlzRvwcJcTTBhnKUWfoLfrdGOARILvQFhLexGTbJBMXjdiiVoCJVVHhGVOidWBUXEzpXEbDjlWbmtpLeRxGgpmZAWOuqJiQPWuUIoVfxXqTxkZEbILrzaRjbPbfpmYdD");
    string oIHPTyMqC = string("UvXhoEoYDHVEXxPAvmQegMsAOPeppyxHkDurdSasPZlPoXhPZvieHHUNszZzTfdQOBpqHTQZdUaUvyYkaW");

    for (int uhsfJOcCjFpc = 695099033; uhsfJOcCjFpc > 0; uhsfJOcCjFpc--) {
        oIHPTyMqC += AkEecRPfCoTGXOdI;
    }

    for (int hSxwl = 1856287926; hSxwl > 0; hSxwl--) {
        continue;
    }

    for (int XMaHVKOVNgy = 146796539; XMaHVKOVNgy > 0; XMaHVKOVNgy--) {
        uoGUJsq += uoGUJsq;
        xGwHCaZFqaHEN -= VMIIqcR;
        VMIIqcR += xGwHCaZFqaHEN;
        EoorsF += MrbYw;
        xGwHCaZFqaHEN = rwLfTcrZ;
    }
}

double clbpLxbOxpKtGL::YyavkiSrwzRwY(bool jLxwZhaAFqyrv, string TLgqkLytmWji, double OZouw)
{
    int mMrcgyTgqVFTeU = -113477468;
    double NMCCR = -174458.04394363138;
    double jvTkexcLsAbP = 1025454.1145034394;
    bool aJsrdpnCDGkESmB = true;
    double YhAtH = 320654.997796506;
    double SuwEVoNCrY = -797255.5482277732;
    int jFibPInxN = 286661387;
    string WDqgQLLfF = string("znWhjHDxNWaLfhvsrdyNSMQzlXxnBENkTdxOJNKcAANbEfWkFiUtpInvCDnkdUpZvYImRuQwseGTmWNVMKWaUgbDjb");

    if (YhAtH != 1025454.1145034394) {
        for (int wYFyHrcSvm = 915016177; wYFyHrcSvm > 0; wYFyHrcSvm--) {
            jLxwZhaAFqyrv = ! jLxwZhaAFqyrv;
            mMrcgyTgqVFTeU *= mMrcgyTgqVFTeU;
        }
    }

    for (int wtEwVUmH = 950024030; wtEwVUmH > 0; wtEwVUmH--) {
        continue;
    }

    return SuwEVoNCrY;
}

int clbpLxbOxpKtGL::lSEQIvg(int WoJjvBik)
{
    int YBhKyPDrj = -500333530;
    string ZeaycIbteP = string("xcJMFXohHXczlTqyCATtVTvaDRcVVDJlbtLyVABEKyXwgEeFOULPJWHkGEXetsREZQG");
    double SfGbADwR = 818000.550394284;
    bool HjShOYkAYSb = false;
    double gMclTDijAUpPdWg = 877809.9797921936;
    double UMAdMhtAzQxbXuxn = -806287.0015743789;
    bool KUtVNbuwfLSBT = false;
    bool mQkbjlkso = false;
    int yUimdv = 272827606;

    for (int xHXNh = 1875925678; xHXNh > 0; xHXNh--) {
        WoJjvBik += WoJjvBik;
    }

    return yUimdv;
}

void clbpLxbOxpKtGL::ktgVPgLPYSuyZD(string hYTzBrFvq, double xUGHX)
{
    int yfGNkkLG = 1371584546;
    bool LcSozsdMNDBf = true;
    string RBjJLroSKJ = string("nNNUgGDfSOvMmPFuSkicMRMcYIurJTamAcTHWLRUcqVgDHYOOqhWhGMeNAb");
    bool kiZooPARVQho = true;
}

string clbpLxbOxpKtGL::CSScDFGPB(double HfwuTHcTQYYuIE, string nzdHZrJ, int fFBmEgxenvg, double mHwrhhiIEfY, int eaeuNePrKx)
{
    bool lgbBRaQmiOe = true;
    bool bYbTgFDKOGIv = false;
    int GAlIQWVYLzAOYIMU = -285437183;
    int peThcg = -1129458259;
    int MWAJS = -1169743701;
    bool fQKDVnxMj = false;
    string vAPjMTkSYFvV = string("EdApAvNMpBgXNeUAPrtZbquLoVXsjHWOigBDjNglontlgFsUOQQoZJCXvLISeFbtKvmIPZdaGmDQCKmVibygqjlyfgs");

    if (peThcg < -1169743701) {
        for (int VYwuuBQ = 1271329096; VYwuuBQ > 0; VYwuuBQ--) {
            fFBmEgxenvg /= MWAJS;
            lgbBRaQmiOe = fQKDVnxMj;
        }
    }

    for (int lGsZPxlrPoC = 1246096975; lGsZPxlrPoC > 0; lGsZPxlrPoC--) {
        continue;
    }

    for (int IJoKfDVDTSL = 1259531809; IJoKfDVDTSL > 0; IJoKfDVDTSL--) {
        mHwrhhiIEfY *= mHwrhhiIEfY;
        HfwuTHcTQYYuIE -= mHwrhhiIEfY;
        peThcg = peThcg;
    }

    for (int PBKbdXNkxK = 1473883370; PBKbdXNkxK > 0; PBKbdXNkxK--) {
        mHwrhhiIEfY /= HfwuTHcTQYYuIE;
        GAlIQWVYLzAOYIMU += fFBmEgxenvg;
    }

    return vAPjMTkSYFvV;
}

clbpLxbOxpKtGL::clbpLxbOxpKtGL()
{
    this->JOzAmPCksWH(-280838.88452278485, string("dEmFZqZBpOYnRYkXDlNxgRVJzqJbtvUdBhoaZaHkRhNmcjhCdvwIIgl"), -430424.66954388615);
    this->xXAYIDcvWNz(false, 694977.3079518105);
    this->WMZFxeenzMpO(-368394.79059785715, 412707.03442552336);
    this->jjaAqAkRm(1001109462, -1968836503, string("cMJAcwMwWLeYXNSCPOXaauIJYnAYuNHGIQnvrAdtcwWZuDGcymADTeMFscGGxKUgPJjvyZbdgdtBYILYvU"), 665748.5918870516, 638565.7592352978);
    this->GiUonWbTzyyjXvF(-1002825142);
    this->waKaKbvyu(false, string("uibEpdRgWFtZILvBGQeFFSSzXfoGmLqbSnrJkLSbGhpUnLkSELcUUpZYYwTmHxyaIBQBopIFAZRxkdPWdEvwoxHleCJFTWFUwjGJFjYIhuNgYrCiXxEJeEgXASRNvUZmLAyAdYyehArydlqsxfWMsouTafBiqQKxEBAtImfluWzqDMScb"), string("XSaaBEHWveoCIqpdMLszTcYDnrlEaluOUqyGGPwJDzzJaokHuLpKudHgQJiIbyKpmsXoHrHFDWMkcdBUCRoTkCFaToYGQnvDyvVcvCAYgpdPKHRMXTZnPQvOFfsPMAlpgWLJrHhAotUKfUvivhKdhugNNKcJHjucAyFBuPGgqlNNPZCbLtOkzytiON"));
    this->htqctPOLPIA();
    this->abGKWW(string("ZtJcOqalhxOAxlyyVyIL"), string("gickvPEayUUEigsRNbPwPvnfFMnSXsOZUdaagsQdttHdRyZuYdcFClVRNTMPtblxKBHwEylarXGXdzIxyFqEYCgyUuPBFFej"), string("RWVnZAOamfgtTJGjOUnIGOxeTDFBeSWuFrNZEOhWtDfvAFTABFbMRSRFokkPbaeixGrdUnvsVoXHwZphaGARHtGkfviv"), 294239.59446518373, string("SFQYrnKDcaLapRvxroQGGonHWsbcQfUynebZXINWMIfZhCXtrzIzFUhKzaZadAHQFAhRjhkNheKxKEmlnOJjnYZFOIvhROCMOIcsaUByjyAXbICnULbmHkkMjnroTa"));
    this->YyavkiSrwzRwY(true, string("XCTNgEFOQmVVGfiOukWlXONnDMHimgpawlhdkwSLdRdvyyWyFAdRIMAvvIRSPRtHVnDTyFSUvXfUGwgnjqCfFrLABAspjYp"), 511427.1657457545);
    this->lSEQIvg(1807377134);
    this->ktgVPgLPYSuyZD(string("RgfUdQINjAAZlecywZVKRPzWiyEFjRIvPeGdOtVXcbrr"), 422043.504300161);
    this->CSScDFGPB(-236760.5189283194, string("fTrKEmqxbThKtKwnLbhhUDnuIaWOBIcLeqlQDdfBKVEJrChbRGVwqZzACCXzecohSPaOBwKhEmJzvGfJiIurYHBupODVzsAphUyatlZPOgBAWmKJDFQktyEiHkNSQEwwRfyfFkvTkdsBINByTIrSWzUrQGyumPhfdwqgODsVVwcHIgIDl"), 358311311, -571191.4344307788, -1831223729);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QJqixqyMSLZlCrU
{
public:
    string hwpmQGFtxpAfuYQM;
    string tFLeLRsMaPssnd;
    string cVYHooFcQm;
    int jmdDwu;

    QJqixqyMSLZlCrU();
    bool tCyzFnVdRaMM();
    bool VRQpPD(bool LOMNarPCf, int aphkCMjMdLC);
    int JRBZtUEcwaVEpvkH(string DnATMW, string ASMmQ, bool HVEaSoJoaOZkPQn);
    void MhOOT(bool yjEkcB, int LxglJvwTXPqATl, int UXcvCTakQZlPFzDK);
protected:
    int sqngYPXosOAhKPoH;
    bool msCMbFdayCmy;
    string aHZdqumBJEbwVg;

    double nozdwSeRGPGemr(bool sHBAvoVWTuilwu, double ckkxW, string hqPujCyMrFqYdJS, double eKRROWj);
    string fXaUFJJHDmPD(double lgrcvBbnbbecH, int PUmQO, bool ASZUU, string NNHLOHk, bool FagOMkXWiqMuyU);
    bool JVdcS();
private:
    double krYoRSWCbfmCP;
    string IPZVvAEDObScgny;
    string zEMpPOYyZEK;
    string khQpsUGFHCA;
    string EQcQbCHrjidupG;
    bool nIPCenNfIee;

    void gNVdkhFG(int lzuqKGYIr, bool vXmfTGVoSkHX);
    void aIZyHyth(int nXWZqWnIQQbDgB);
    bool gXUULdEIE(string LYPVMplrBoBOyxlO, bool SPTOSTzSNMBZtTYR, string jDZErogm, string ggGyEkWcgaKAcG);
    int upyKvjygYpeZ();
    void eSTVmMJfPjNcN(int KPLDrnkh, double tqSomW, double MonPPbj, int hMgnZpTUQ);
    bool dKULR(double pQfgOuIFSwgdIuRI);
    string lPdjv(string bFFShv, double ufNOMgmJuh, int JEXEy, double WbDUxzEjIRghZDKI);
    bool VSTzFFpuKxE(int EhNceVwstGoPFUMv, int vkfnsag, bool LpFzLYHekSHwMfAl, int dhPBkyVaGM, string WtlbdQmGEl);
};

bool QJqixqyMSLZlCrU::tCyzFnVdRaMM()
{
    bool KWrbAyQyFQVby = false;
    string mDgsVsicVfqmIeve = string("mPwHSecUxhcaQbwNdCkQUVUKzfQCxbDUIWfjPTQRAGKHsdODgtvvNZrDrrnbvXeYGwep");
    int AOZaxuIQm = 1971633803;
    double FEhKEbJTJOZmNWlw = -186349.85996530706;
    bool HsaVDZJmgGOuHqyB = true;
    string ZFxoBBg = string("gfTOEiQziDOtnTjToBBKDAYYGPsogMqjoadVNFwpJpahgjCuOObzmDZreeMhLLFwJoiLSGqgViRNmUzbioONGuwy");
    string OMhnKMKeujV = string("dNEeHtRGDlHtEjjCSUGvsWJklzmrlQfDdnXaCiEkWGBLDKbYBSTozzGcwtXKJXmFVbvBQFJrsmgtyEbwrzoKjjNdAbaxQshwIirpTdPcGqMZtyIIfvuECRULIzWUmcufbiKkEWrJovhavTDvcOtxhJUtdHiCttBDkMWysgHPnTrrXLNJVDFcDvUIzMlCnmFjxoMFWEtAiOiCfZpBoKDvvUotfRwepHtxWWzrfmFGBQtiUkS");
    bool QnNyvQXgxRPuSvu = true;
    bool IjRrUPyZkbuBGz = false;

    for (int CthCnNTuUEqR = 1803145902; CthCnNTuUEqR > 0; CthCnNTuUEqR--) {
        ZFxoBBg = mDgsVsicVfqmIeve;
    }

    if (KWrbAyQyFQVby != false) {
        for (int zicoy = 1601069379; zicoy > 0; zicoy--) {
            HsaVDZJmgGOuHqyB = ! IjRrUPyZkbuBGz;
        }
    }

    for (int ctmdhDrdWnv = 56701218; ctmdhDrdWnv > 0; ctmdhDrdWnv--) {
        IjRrUPyZkbuBGz = ! IjRrUPyZkbuBGz;
    }

    return IjRrUPyZkbuBGz;
}

bool QJqixqyMSLZlCrU::VRQpPD(bool LOMNarPCf, int aphkCMjMdLC)
{
    bool syDEM = false;
    string bHiTn = string("KmvVPhIZmcBIlqKYCWZDqZFCUmzEpparlQNCROJLvKAzklPrynSreBgOygpNbHpKofQrCJXmMnQyxdYbbTJBKbsnnLNGkVMMNEZouakYtQKdIudrpNHiJlJXqmlUpoZoqviRzvCsADUIifATTuTsPTffGbQKJndKGpAfFjNWt");
    string kQaROv = string("TuYlzDHIiLJycaerTEKnuqmtkknZsgkeJEXLMNWVlSGzSrhRlpOkSEczUMjzdJlsadbECgTXUlHcNaopDCdzhhMuxoXalZZllgquclolfmkLxhJSjBSruxLDguoVqNBGrusRTJrAMmWrZExjBFsrzMG");
    int TaiMeYa = 1991190678;
    double vIGGGhCjx = 821632.6881865093;
    int kXuwFNWx = 607499243;
    int lvkpxrJmdl = 656875278;
    bool tSiTJH = false;

    for (int IvBPKJSreFLN = 2106475945; IvBPKJSreFLN > 0; IvBPKJSreFLN--) {
        continue;
    }

    return tSiTJH;
}

int QJqixqyMSLZlCrU::JRBZtUEcwaVEpvkH(string DnATMW, string ASMmQ, bool HVEaSoJoaOZkPQn)
{
    bool fYTWBOYgzSD = false;
    double AkgTSaKuFeHgOr = 431537.8081299233;
    double gpYGcGRYa = -82371.41995741655;
    bool gVRcGCqfqtRW = false;
    double pBgSCYDXjTXEq = -713669.4026237209;
    double rMywnxfjqJogdDBq = -597178.597017367;
    string YrgaRcgPiiYQUeZ = string("nFlmvYajzVDwaJiPsDoEWGBwcGpJNlMMTzixbjdYpYWo");

    if (pBgSCYDXjTXEq >= -597178.597017367) {
        for (int TJZXu = 638935860; TJZXu > 0; TJZXu--) {
            fYTWBOYgzSD = gVRcGCqfqtRW;
            rMywnxfjqJogdDBq += rMywnxfjqJogdDBq;
            AkgTSaKuFeHgOr = AkgTSaKuFeHgOr;
            ASMmQ = YrgaRcgPiiYQUeZ;
        }
    }

    for (int YOcDOXAIh = 727877009; YOcDOXAIh > 0; YOcDOXAIh--) {
        ASMmQ += DnATMW;
        fYTWBOYgzSD = ! HVEaSoJoaOZkPQn;
    }

    if (HVEaSoJoaOZkPQn == false) {
        for (int VaEkek = 198210464; VaEkek > 0; VaEkek--) {
            pBgSCYDXjTXEq += pBgSCYDXjTXEq;
            gpYGcGRYa += rMywnxfjqJogdDBq;
            pBgSCYDXjTXEq /= gpYGcGRYa;
        }
    }

    for (int JrWar = 1381921841; JrWar > 0; JrWar--) {
        gVRcGCqfqtRW = ! gVRcGCqfqtRW;
        gpYGcGRYa = rMywnxfjqJogdDBq;
        gpYGcGRYa -= pBgSCYDXjTXEq;
    }

    return 683441977;
}

void QJqixqyMSLZlCrU::MhOOT(bool yjEkcB, int LxglJvwTXPqATl, int UXcvCTakQZlPFzDK)
{
    int jAzlo = 750793309;
    string NBbOrgFOoil = string("zezmfoanLfSntfcPQkgyyQAHduARStfSHRZGxmVybQaLcVHBfOsWbITvtdtucsLRzCAWOeKeuYcetItmNvEhIuRLAiKhcnpIOKCljousxXONRgandgMTgjwRIbiFgScIAViLbJcyRsKHLrSIJmdmIjXNWLYMiBRNugBWbcknHfdqtxXFrjwEDqMPb");
    bool ssyVSPqRdvjm = false;
    double nVLjYDcQAA = 876150.3165454444;
    int dtobB = 1750576753;

    if (UXcvCTakQZlPFzDK < -309693317) {
        for (int etXyk = 1607948493; etXyk > 0; etXyk--) {
            LxglJvwTXPqATl += UXcvCTakQZlPFzDK;
            jAzlo *= jAzlo;
            LxglJvwTXPqATl += jAzlo;
        }
    }

    for (int sDLDtKMnfhv = 1116961649; sDLDtKMnfhv > 0; sDLDtKMnfhv--) {
        continue;
    }

    if (jAzlo != 1115186688) {
        for (int eVGsXPXZLczVa = 1336026677; eVGsXPXZLczVa > 0; eVGsXPXZLczVa--) {
            dtobB /= UXcvCTakQZlPFzDK;
            LxglJvwTXPqATl -= UXcvCTakQZlPFzDK;
        }
    }

    if (LxglJvwTXPqATl != -309693317) {
        for (int HvRDNqq = 714174440; HvRDNqq > 0; HvRDNqq--) {
            jAzlo += LxglJvwTXPqATl;
        }
    }

    for (int FpmLyn = 644093505; FpmLyn > 0; FpmLyn--) {
        dtobB = jAzlo;
        dtobB *= jAzlo;
        jAzlo -= UXcvCTakQZlPFzDK;
        NBbOrgFOoil += NBbOrgFOoil;
    }
}

double QJqixqyMSLZlCrU::nozdwSeRGPGemr(bool sHBAvoVWTuilwu, double ckkxW, string hqPujCyMrFqYdJS, double eKRROWj)
{
    bool vfDHwFGlQ = true;
    int YtogDcenbKX = -619518262;

    for (int XMMniJ = 992731471; XMMniJ > 0; XMMniJ--) {
        sHBAvoVWTuilwu = sHBAvoVWTuilwu;
        vfDHwFGlQ = ! sHBAvoVWTuilwu;
        hqPujCyMrFqYdJS = hqPujCyMrFqYdJS;
        sHBAvoVWTuilwu = sHBAvoVWTuilwu;
    }

    for (int JeFOHzzMEfHIu = 726487864; JeFOHzzMEfHIu > 0; JeFOHzzMEfHIu--) {
        hqPujCyMrFqYdJS += hqPujCyMrFqYdJS;
        sHBAvoVWTuilwu = sHBAvoVWTuilwu;
    }

    for (int kdlKmRqTZ = 178434971; kdlKmRqTZ > 0; kdlKmRqTZ--) {
        continue;
    }

    if (ckkxW <= -654460.3646923361) {
        for (int gevbdwXMgwQbq = 1580210056; gevbdwXMgwQbq > 0; gevbdwXMgwQbq--) {
            vfDHwFGlQ = ! vfDHwFGlQ;
            YtogDcenbKX = YtogDcenbKX;
            ckkxW /= ckkxW;
        }
    }

    return eKRROWj;
}

string QJqixqyMSLZlCrU::fXaUFJJHDmPD(double lgrcvBbnbbecH, int PUmQO, bool ASZUU, string NNHLOHk, bool FagOMkXWiqMuyU)
{
    bool TRJbybvfI = true;
    int mIcOzbf = -520139471;
    double WmcmySXFjwtus = -1019275.9136302869;
    int ZyMlgxNuBojAiY = 1860832203;
    bool olZcioRrKiag = false;
    bool YTLZoypwXmnCYsLy = true;
    int JvNpMEAZshUhwAW = -2038242234;

    for (int hrNiHuZAsBcWMxH = 729653510; hrNiHuZAsBcWMxH > 0; hrNiHuZAsBcWMxH--) {
        continue;
    }

    if (JvNpMEAZshUhwAW != -2038242234) {
        for (int xAwEAPULBu = 1851259468; xAwEAPULBu > 0; xAwEAPULBu--) {
            continue;
        }
    }

    for (int DdhGHLh = 1889054082; DdhGHLh > 0; DdhGHLh--) {
        FagOMkXWiqMuyU = ! YTLZoypwXmnCYsLy;
        olZcioRrKiag = TRJbybvfI;
        ZyMlgxNuBojAiY *= ZyMlgxNuBojAiY;
    }

    if (YTLZoypwXmnCYsLy == false) {
        for (int YZiKvFMZRaLQd = 1433963690; YZiKvFMZRaLQd > 0; YZiKvFMZRaLQd--) {
            ASZUU = TRJbybvfI;
            NNHLOHk += NNHLOHk;
        }
    }

    return NNHLOHk;
}

bool QJqixqyMSLZlCrU::JVdcS()
{
    double zFqhfgDw = 675498.0029767505;
    int vnBVtgGSYCwRW = 1155347099;
    int iYVfdYHwmItpPp = 2091263857;
    int NztLMqKoVyrSV = 1338296159;
    int SKbpDf = 698892082;
    string GZDWyz = string("ImKMFsDQMoxlQXcIUCEgdLCYujwHDSxFPkjOckhjwqSJkebCyJvMElHNDpAMSGJNcEyAtclrHdOjCyjIzOKjatuOpdG");
    int npCgi = 2007369421;
    double FZBmvam = -602407.2501898439;
    int GCOTYfIBIihIF = -1921407940;
    double BDsgmAXhDBLptFiO = 408197.4337512602;

    return false;
}

void QJqixqyMSLZlCrU::gNVdkhFG(int lzuqKGYIr, bool vXmfTGVoSkHX)
{
    string bPrsqxzV = string("qUudlcDqGUrqTQCmckFRHHTWzcKXSRPlmNDGGLtDECVKUlFQCwMvEmOqncAwYBlABUpSxMXvhWsibsNsgNwqhiWVWIEJlwGLkAYJJPLLSOOrMIsuw");
    string cjrYzftEylupJOI = string("UuyoqvSwiLUtkUvyRIDzSQhQhLpiVOkbDILUkpyTOCQBwNsrJvFb");
    string iJpktACUUshQQdmL = string("bIepiKFTKIudshSGpVBfvtdkysGqSogWLlQxFSWTxDSybGLgASFvnTMrnirqUbNGhWrNGBTIUGSmZBIbsSgWkpfYUPARstghwDbBPXeDu");
    int yxfnTYPsMm = 83708778;
    int lUSpE = 1724949680;
    bool fofaLQCwkMhx = true;
    bool BrxVhOryOwZLX = false;

    if (vXmfTGVoSkHX == false) {
        for (int XYcWaWguYVd = 1714716636; XYcWaWguYVd > 0; XYcWaWguYVd--) {
            continue;
        }
    }
}

void QJqixqyMSLZlCrU::aIZyHyth(int nXWZqWnIQQbDgB)
{
    bool CFSzXpViobfCzz = false;
    int ZBCqqISnHqWpCuy = 2025641791;
    int gesqFkzpIuTHKnZh = -1396391041;
    bool gswLaouhwBKn = true;
    double eJcErb = -719236.149666673;
    int WAnRDLrINSNLRc = 720339492;
    int tGdYmuPBYMX = -52406010;
    bool zPMTuSNquIiVRIPL = true;
    bool PAuyMAcLLitJsh = true;

    for (int SVPeFRtE = 1194951451; SVPeFRtE > 0; SVPeFRtE--) {
        zPMTuSNquIiVRIPL = gswLaouhwBKn;
        tGdYmuPBYMX /= gesqFkzpIuTHKnZh;
    }
}

bool QJqixqyMSLZlCrU::gXUULdEIE(string LYPVMplrBoBOyxlO, bool SPTOSTzSNMBZtTYR, string jDZErogm, string ggGyEkWcgaKAcG)
{
    string sgWWod = string("lXonXVqGJnTsGeUviyPFaMASMAquwLKYXbPLvthQNEDxgryDLXGLyOpOmHsSdzmnODyTfKTSCZnRqgHNxfxslanklJXtzgJVSVLJoVHUEQQOJpihfFMNVgbPlcfiDYMLYfgsZTXNxoZbeiLUwKmJafEQsyITVaaWHtjsQWZ");
    string POlKQKQbRVQeHXF = string("OyZwoeTKLuJQZgkGaopqsCjzSuG");
    string qerEXYAncc = string("RSWHhjqgeOrHQQkNBHjDRvgibwmPBtICXElYaOXKHSDqfHtMKVNwuZpcTgRuBHnjENpFdMpvJKqoEXOTocN");
    double GIlfSUkGuhokHRm = 378711.7330233474;
    double vZamvJr = -985998.6543462186;

    if (jDZErogm == string("RSWHhjqgeOrHQQkNBHjDRvgibwmPBtICXElYaOXKHSDqfHtMKVNwuZpcTgRuBHnjENpFdMpvJKqoEXOTocN")) {
        for (int lbejjQYRyCd = 29039542; lbejjQYRyCd > 0; lbejjQYRyCd--) {
            qerEXYAncc = jDZErogm;
        }
    }

    for (int uEPaDrsLcRdFq = 2066702987; uEPaDrsLcRdFq > 0; uEPaDrsLcRdFq--) {
        ggGyEkWcgaKAcG += POlKQKQbRVQeHXF;
        POlKQKQbRVQeHXF += qerEXYAncc;
        LYPVMplrBoBOyxlO += jDZErogm;
    }

    for (int nLQWfZDRg = 966595258; nLQWfZDRg > 0; nLQWfZDRg--) {
        ggGyEkWcgaKAcG += POlKQKQbRVQeHXF;
        jDZErogm = sgWWod;
        POlKQKQbRVQeHXF = jDZErogm;
        jDZErogm += qerEXYAncc;
        ggGyEkWcgaKAcG = LYPVMplrBoBOyxlO;
        sgWWod += POlKQKQbRVQeHXF;
    }

    for (int poCJbttytKIyM = 1369190372; poCJbttytKIyM > 0; poCJbttytKIyM--) {
        continue;
    }

    for (int EDMlDQze = 79362050; EDMlDQze > 0; EDMlDQze--) {
        jDZErogm = LYPVMplrBoBOyxlO;
    }

    if (LYPVMplrBoBOyxlO == string("cINuVIHIVnBqHZMoMCcOsRyivMrLkqTNNyfqepmVcsFJvSIOIwAUAtyHsONJvAQoXQjFMVzScMTroGrdGRvGZpWOynSDnhoQxtWOqopNHxoUwlAEPeVbXHnWCTXfohQAjpiKZzfEpZBYYDYucIVnkbaJYyLlLkfelebUruvcPiIGtKqDGYmghAsglrcuDWrd")) {
        for (int xWEilyunDYTW = 1749832183; xWEilyunDYTW > 0; xWEilyunDYTW--) {
            sgWWod = ggGyEkWcgaKAcG;
            LYPVMplrBoBOyxlO += LYPVMplrBoBOyxlO;
        }
    }

    for (int mNgjIECHGpBU = 1336351152; mNgjIECHGpBU > 0; mNgjIECHGpBU--) {
        sgWWod = sgWWod;
        jDZErogm = qerEXYAncc;
        jDZErogm = jDZErogm;
    }

    if (LYPVMplrBoBOyxlO <= string("RSWHhjqgeOrHQQkNBHjDRvgibwmPBtICXElYaOXKHSDqfHtMKVNwuZpcTgRuBHnjENpFdMpvJKqoEXOTocN")) {
        for (int HmurMOEgKBxg = 742510413; HmurMOEgKBxg > 0; HmurMOEgKBxg--) {
            continue;
        }
    }

    return SPTOSTzSNMBZtTYR;
}

int QJqixqyMSLZlCrU::upyKvjygYpeZ()
{
    double COQccgzP = 320845.83378462016;
    double DuvXtWAkdoLzp = 346755.87159055384;
    int HtFIimwSnYKdyzG = 1486352545;
    int vUmuRPgfZbBzffKy = 1742243776;
    int tBotaATwTpPYMgL = 1065589199;
    bool OwayJyYXct = true;
    int EhVrXRWzhzZYSuWW = 1129915669;

    for (int MNtgTZ = 1236786384; MNtgTZ > 0; MNtgTZ--) {
        continue;
    }

    if (EhVrXRWzhzZYSuWW != 1129915669) {
        for (int YBcnnCLPozt = 688506581; YBcnnCLPozt > 0; YBcnnCLPozt--) {
            tBotaATwTpPYMgL /= vUmuRPgfZbBzffKy;
            tBotaATwTpPYMgL = EhVrXRWzhzZYSuWW;
            DuvXtWAkdoLzp = COQccgzP;
            EhVrXRWzhzZYSuWW += EhVrXRWzhzZYSuWW;
        }
    }

    if (HtFIimwSnYKdyzG <= 1129915669) {
        for (int SXfWoofnPnZd = 539199498; SXfWoofnPnZd > 0; SXfWoofnPnZd--) {
            HtFIimwSnYKdyzG /= vUmuRPgfZbBzffKy;
        }
    }

    for (int OLJplGuayJD = 1457995225; OLJplGuayJD > 0; OLJplGuayJD--) {
        vUmuRPgfZbBzffKy += HtFIimwSnYKdyzG;
        vUmuRPgfZbBzffKy = tBotaATwTpPYMgL;
        tBotaATwTpPYMgL = HtFIimwSnYKdyzG;
        HtFIimwSnYKdyzG *= HtFIimwSnYKdyzG;
        tBotaATwTpPYMgL /= tBotaATwTpPYMgL;
    }

    for (int FyyTeAD = 1389282601; FyyTeAD > 0; FyyTeAD--) {
        OwayJyYXct = ! OwayJyYXct;
    }

    for (int coKZRSXIw = 957306892; coKZRSXIw > 0; coKZRSXIw--) {
        continue;
    }

    return EhVrXRWzhzZYSuWW;
}

void QJqixqyMSLZlCrU::eSTVmMJfPjNcN(int KPLDrnkh, double tqSomW, double MonPPbj, int hMgnZpTUQ)
{
    int LiZsBZM = 1816918777;
    bool FtaSsTOjKtr = true;
    double iQAKeluWgX = -561424.4742244398;
    double papCWUmAR = 852465.099545546;
    string oMgyvFruDPUadvnv = string("noUqKftGkIYdIwfiPdCHCJxsflLrKEcyMJiCPmriKxZLvLVowkUSKyhcPWxyebqaVoxqrVVnsBHurcf");
    int SXlCpfeH = 1828166099;
    string JyCZppUUcnPuf = string("ktuAjsbgesckqoQwMxrQSdnTNJANJBIBaFWXSqoqlNKmuQlgFQRRNMJxhaAgqlNdsJDxpPPPYszcXpCiSwqxfteZlDZEKriCRscRcqUloezCMsOEFngjPmpRGuVhBxNFMdGSVCuSmOuyVTJeSWxlTfGOsTelABAJYQrdpHguZSPwJSqnWrPnZEgUTDJWq");
    bool bhImxvSMQYAadaq = true;

    for (int WjTdwYLffTamDHj = 2001608680; WjTdwYLffTamDHj > 0; WjTdwYLffTamDHj--) {
        KPLDrnkh *= LiZsBZM;
    }

    for (int yWpheMOrByi = 822102859; yWpheMOrByi > 0; yWpheMOrByi--) {
        hMgnZpTUQ += KPLDrnkh;
        LiZsBZM += KPLDrnkh;
        KPLDrnkh -= SXlCpfeH;
    }

    if (bhImxvSMQYAadaq == true) {
        for (int qbsikdro = 1521137718; qbsikdro > 0; qbsikdro--) {
            continue;
        }
    }
}

bool QJqixqyMSLZlCrU::dKULR(double pQfgOuIFSwgdIuRI)
{
    string fABMQF = string("MXaGgIpRAJKVpRFPUnSjpGqckPKwQYnOrQVqkcbMKvHvkDOFkzdJejxUlSfzLOhXrWxDlVsoiGBneqlVYAIskZIvmQgDBcBYtEkrZlmsOWkzrCQoggJjetbnxEWOrBTHplgelGSpxMWQZsdQzjTIHrAkqzuTRACSnflVskeyMlXRQLxBYHfresVzqKJPxDtFXaflqmVKTbVjGzLiagcoPQfXxHuYQXSyunHQZnkLu");
    int DHOHExOnx = -588960356;
    int WzOaruBWdm = 1073059647;
    string NRzYvth = string("ObvHZx");
    int vPnhznHy = -565985568;
    string wxnKQVzfPu = string("cdQvERSICLvyINDrjKzSpZWEKWroEOLJeOSgOzZtxszwsQGTgmVfHhcOTZqgsLBfOcEfyzUWKXKqWFFcvtzccLgEPBandwQCAQiXLscvcElrjydOvBKFYvLmmvmbfSaJZXFHPhOaMBHAUzvGCAjycloFxZIYaXhxmnmoTxtlLckKCnmLfW");
    int nsMWqmDDPd = 1058391923;

    if (WzOaruBWdm > -565985568) {
        for (int KUZwWFTyWW = 265572593; KUZwWFTyWW > 0; KUZwWFTyWW--) {
            fABMQF = wxnKQVzfPu;
            nsMWqmDDPd /= WzOaruBWdm;
            NRzYvth = fABMQF;
            DHOHExOnx /= DHOHExOnx;
        }
    }

    for (int KnxFTyMb = 1158587885; KnxFTyMb > 0; KnxFTyMb--) {
        DHOHExOnx /= WzOaruBWdm;
    }

    return true;
}

string QJqixqyMSLZlCrU::lPdjv(string bFFShv, double ufNOMgmJuh, int JEXEy, double WbDUxzEjIRghZDKI)
{
    int qJVNOK = 1124269396;
    string tfQcIGajydKoDy = string("pPplaSRvzsjQBvLVaySNHspLSbJHcSxjFYPsmNOQdJCynpttzJsqnDuChsOsidwpwhRftjlJKcOIyZVYaynfrQpioryFhRCnVlIAQaTIDtmCHbRaSeuhGwLAjpJmFKPpIWsAbsovqyTutPptElwnXsztnpXX");
    double LYZiAJlLAJiv = -290460.5032295848;
    int QmuxrhStpQlnb = -1856451792;
    double XJKDSmUraamqKSe = -373687.52951133664;
    string gJYLuFAzZt = string("ORdSlVnSnxGFjFWVpieWOdQTEBImAVuTCPfCvKXBCAKvDVZfzjfQAZJVzvUJCiAVeOFJAmiFjuEXMIIKYfZTXlSrFccrQikGCdS");
    string DNWkARYPVyUBpIXp = string("FmNrLnfWsWUtrYYkWayPlSfXxAwtBrNlKjZEDmWwBtJLyuaNnMSAxBkurduGrPQJbalWnxRJPfsbitHdYBkOOOGLLRgUrTbDdMcFVhgQFluJCKdgqPDBtvMGArcnqFyPDArEviiDKqdAHmRCJkAcloWUoOCplDovLutdkVxLYauaVZfotLrwT");
    string VSnVeAyKnnxg = string("YJAyAoqkmuiuScekKdIjuvfMSrYnDNcqHrGYzNUndNnrYqSemGopFdPXkbCJDXRqvQGKdvvWqDjXOSEcCvnMmLlsDWGXNjkFrUtnXqdBaqKtogihUvFygLQZqphJGn");
    double GKaGAcfbBkW = 809375.222810805;

    if (XJKDSmUraamqKSe < 131974.90413446436) {
        for (int xwfYkxZxNqxwIyv = 2030399554; xwfYkxZxNqxwIyv > 0; xwfYkxZxNqxwIyv--) {
            qJVNOK *= QmuxrhStpQlnb;
        }
    }

    for (int HdleuZtfWwTqbajR = 1775688403; HdleuZtfWwTqbajR > 0; HdleuZtfWwTqbajR--) {
        VSnVeAyKnnxg += bFFShv;
        XJKDSmUraamqKSe *= XJKDSmUraamqKSe;
        JEXEy /= qJVNOK;
    }

    for (int mQIASpoVp = 966589218; mQIASpoVp > 0; mQIASpoVp--) {
        LYZiAJlLAJiv /= LYZiAJlLAJiv;
    }

    if (bFFShv < string("YJAyAoqkmuiuScekKdIjuvfMSrYnDNcqHrGYzNUndNnrYqSemGopFdPXkbCJDXRqvQGKdvvWqDjXOSEcCvnMmLlsDWGXNjkFrUtnXqdBaqKtogihUvFygLQZqphJGn")) {
        for (int vfsUvu = 454470035; vfsUvu > 0; vfsUvu--) {
            qJVNOK *= QmuxrhStpQlnb;
        }
    }

    for (int DMQUyPmRbY = 400499202; DMQUyPmRbY > 0; DMQUyPmRbY--) {
        VSnVeAyKnnxg = bFFShv;
        LYZiAJlLAJiv *= LYZiAJlLAJiv;
        XJKDSmUraamqKSe /= XJKDSmUraamqKSe;
        qJVNOK = QmuxrhStpQlnb;
        VSnVeAyKnnxg = bFFShv;
    }

    for (int SLaOJwBBAWwYvlOr = 2048746318; SLaOJwBBAWwYvlOr > 0; SLaOJwBBAWwYvlOr--) {
        VSnVeAyKnnxg += bFFShv;
    }

    return VSnVeAyKnnxg;
}

bool QJqixqyMSLZlCrU::VSTzFFpuKxE(int EhNceVwstGoPFUMv, int vkfnsag, bool LpFzLYHekSHwMfAl, int dhPBkyVaGM, string WtlbdQmGEl)
{
    string JJoCulnUxe = string("dbWgJLXbpeaEnmawyJUXKZSNZMznccJCEDLzsrPWstMlEpKDoibOvTrouMIDVXoXFzXTGhJWzLcypqJudyoWCbYlwUrrmxwdqSVhRsACSsUmrFv");
    int UiTucc = 1180052683;
    double YqjwFORxsTdAQsCk = -875590.9711646766;
    bool NVxvi = true;

    for (int iSmskuXMqhQeNRdO = 1182146712; iSmskuXMqhQeNRdO > 0; iSmskuXMqhQeNRdO--) {
        WtlbdQmGEl = WtlbdQmGEl;
    }

    for (int orlvBylUaU = 2124259579; orlvBylUaU > 0; orlvBylUaU--) {
        JJoCulnUxe += JJoCulnUxe;
    }

    return NVxvi;
}

QJqixqyMSLZlCrU::QJqixqyMSLZlCrU()
{
    this->tCyzFnVdRaMM();
    this->VRQpPD(false, 178698289);
    this->JRBZtUEcwaVEpvkH(string("FYFRKQOmyIkhzPUzleWVdQxbWfEXTotgYYzxikhfFZFiBbeEdysGHPLpoiGdYzvvhKbiUipYKxYtsuNtcTTuUKSvGvadEVbqgEjRvatlvfGNGaCnnuvwzEslxomhmYaBfeALHtnORexeyXTDGtGCroWDIfusHONU"), string("vewSTikSIjuOdLQZkNkKFavbbllGYrOVcJThTNXgcuAvZPDvMhrMYBRlmVDLSBAUGRJvfpBuZGnIveNowTdIzdFjOCxnldVaPWEEXpDFaPubWqeiRgzdEnElYLdMsYTdsdaGAnmMltiaruOPwpdIyQRdPLnxUswbpiKRaQROqoZjnEasqSCGpOKxcyCpEOlcjppCNUmiZNNtKMNWfHepydMxxYFYGYexILMlBZNUrJUshy"), false);
    this->MhOOT(true, -309693317, 1115186688);
    this->nozdwSeRGPGemr(false, -932152.257432927, string("dmWzBfTbZCOnEMhPoKwSidPgJaiQIqPPalnGKHBFmKMcbbVoJLrKEDQBmbmrwSc"), -654460.3646923361);
    this->fXaUFJJHDmPD(-845023.3971300728, 1581034513, true, string("LQbsxALEZaHgPdXHyqeZsfcguKAekDpGelTvMzlmbhtCVsKMvflYHJBasgzgLRVEWkxPtkrTFgqYWzjgauFRCfOtetStFhEbcizPoPsMirBXKaIPzSYttR"), false);
    this->JVdcS();
    this->gNVdkhFG(-291766630, false);
    this->aIZyHyth(-842513402);
    this->gXUULdEIE(string("cINuVIHIVnBqHZMoMCcOsRyivMrLkqTNNyfqepmVcsFJvSIOIwAUAtyHsONJvAQoXQjFMVzScMTroGrdGRvGZpWOynSDnhoQxtWOqopNHxoUwlAEPeVbXHnWCTXfohQAjpiKZzfEpZBYYDYucIVnkbaJYyLlLkfelebUruvcPiIGtKqDGYmghAsglrcuDWrd"), true, string("nnBxEmPFvvRfDroUndfKJRKbEGqJxuyKYmNMvNeWixkYCFLaHhfAigBSrIDIMZtTFBsIZOPkTVvHEgdayatvbhulGSNzbIDYGivkLqqizeCIpKazHpUGGexHkIjdKjIHrAKdiIxuqpDHrlDxqIQuBKDYwApipvVLsQiiEqWcUFkSOvFAvqiJwkvosJYryUaLbkNFfHLLYTYiwNriMaRvekk"), string("XNEPUdtSCnPLeyhMMKapyavMDMhINgfJUBZnfOBqmdllLgZaazAmcY"));
    this->upyKvjygYpeZ();
    this->eSTVmMJfPjNcN(2096565293, -489660.0365355127, -789639.5006500334, 319289759);
    this->dKULR(-740638.4689531192);
    this->lPdjv(string("cFzrPDuelBZmoHBcFImdpLRqymCewyPzFhVuSgwjxbfPTGOYVQmiHbgpMwfoxKPLdrSNsREktGGIPxJgxBfAMhhknOAqOYpjnppamuufMRkpZXDZzONZzdFUZvPfClsXbhjdNtNPVkyCNKNSyqEttIOOLJbziMjComUwyZiwnngaMeURXyCnMpAjTaGL"), 131974.90413446436, -632679483, -978856.0306966737);
    this->VSTzFFpuKxE(-1696067636, 1800791728, false, -1441022076, string("uMDejsPNZOSXrnvfDKcbgTQThIluzlmwRqTiojMLwrDRflsZhsuRjfuiSpCZCZmCYVitJDowkRqlVQZFdrXNzXlVsKtMRMITwuGhYewQsWJQkXgPtFZyvbjSvLfslqMfpsdk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SlZSMaA
{
public:
    double NomYdIT;
    bool OSOFrI;
    bool VpJxeFIbZ;
    int lOBGG;

    SlZSMaA();
protected:
    int qylFAw;
    int XLTPziN;
    int faAzrqRhDqgmf;
    double VoyWzlhHNsbhzFQk;
    double qaDjajQSkLaeQE;
    string cWcAZopUFKE;

    bool KsLLFqtvbXPQa(double hotwuXxjCLTrYUH, string vZBjnfUBVsPuwGa, bool OWhamKPjHPzspsHA, int BOHQiqYmGaNjkp);
    int WDQUhbsENaZ();
    void IXoCjVJhWmUk(int jaYMo, double xXDKIMCMpAlMaz, bool QEnzXYJKEtdUB, bool hRYGXWWgI);
    bool JgcgPNEVkDnKX(double ObXNvIDQEIvUUPS);
    bool EdqqLcr(bool ogMQZVRVKzzCnzJ, int YcXNHEi, string UPWHHvQraG, bool qIwvh, string ypUDNJeLqku);
    string GeCwv(string aoDMjJBfZdZDwK, string mOtxWaz, double FTdgIChT, double QtKwleINxzC);
private:
    string CZHcfclmKhKCM;
    bool fSTEtr;

    bool jmzwKRyNVu(double xPffEy, double fhKQYUi, string oUjAZn, double EQjMft);
    double QtASWP(int NimZFcAtuPdGMQ, bool VAhuRcEjq, double TKlHiIB);
    void qWMpyL(bool lypizyxQNhRnEiIE, bool gDhPz);
    string XiOrPPfffrgKJMvz();
    bool hsQspGf(bool ZpSthqV, bool hPOMqKqbSvN, double aoouX, int erTZgjCiZKg);
    void ZsBKTHvFOaAGLrPc(double LIgJyH, bool yEUMgBKhFZak, bool fzXWMDniIVh);
    void NUuPGuUV(int UqPuZfZBMjnAd, bool UEAyp, bool MKDvwmTcuKwLISD, bool DvUZqrjlBZzO);
    double NlPefALWE();
};

bool SlZSMaA::KsLLFqtvbXPQa(double hotwuXxjCLTrYUH, string vZBjnfUBVsPuwGa, bool OWhamKPjHPzspsHA, int BOHQiqYmGaNjkp)
{
    double nHPVTnGsiGhb = -777855.8267852876;
    int HwcHXSzSVQcOrMb = 1569146823;

    for (int smpMJxBxPArajH = 101843120; smpMJxBxPArajH > 0; smpMJxBxPArajH--) {
        continue;
    }

    return OWhamKPjHPzspsHA;
}

int SlZSMaA::WDQUhbsENaZ()
{
    int IBQMCZiEGovg = -514054139;
    int HBwaX = 2103890878;
    int hVBWcI = 1720223167;
    double PTkQrxGvC = -560250.4083502655;

    if (IBQMCZiEGovg < 1720223167) {
        for (int mfcHqGqDeMTpsOJZ = 626206896; mfcHqGqDeMTpsOJZ > 0; mfcHqGqDeMTpsOJZ--) {
            hVBWcI -= HBwaX;
            hVBWcI -= IBQMCZiEGovg;
            PTkQrxGvC -= PTkQrxGvC;
            hVBWcI += IBQMCZiEGovg;
            hVBWcI += hVBWcI;
            PTkQrxGvC /= PTkQrxGvC;
            HBwaX -= IBQMCZiEGovg;
        }
    }

    if (hVBWcI < 1720223167) {
        for (int ZzbArzojcx = 1522602318; ZzbArzojcx > 0; ZzbArzojcx--) {
            IBQMCZiEGovg *= hVBWcI;
            hVBWcI *= HBwaX;
            HBwaX -= IBQMCZiEGovg;
            PTkQrxGvC *= PTkQrxGvC;
            HBwaX /= HBwaX;
            IBQMCZiEGovg += hVBWcI;
        }
    }

    return hVBWcI;
}

void SlZSMaA::IXoCjVJhWmUk(int jaYMo, double xXDKIMCMpAlMaz, bool QEnzXYJKEtdUB, bool hRYGXWWgI)
{
    int cqtzLPLsApFNRzD = -858229844;
    string VJfZRYQJegqF = string("kAdrZJNpaZpjsGcVLZEGHRWeISdvKPjjFHgqwEeCrxRTZoJsCKbfEfbACIdtBcnsKJMBqzXfsFRGXOuJLnjIHeAfmCQbRNBNpvwaRaOSwmwVkNdYkVCOeaBaolqSQBiRDgPImFSVqflPzLslgMoOmFNrSFzkavOMfgZdzAXlMghVtidpKRCpCVHBoCcFFfOOqVkkyzZJNxLVnbWqUvwsaeiZNPudz");
    double MKGKHpXyhnesGc = 1038228.1789075189;
    string jmQEfdAE = string("ifahIWBBKRiwtCmKkCebKKHBDwwTgsDzjiccpMAptlQTjiPTPLHobohkNhvelSOKxKjXTMnYyslKeyzaAzfqlPrxaqKCCBQWgYCiHGjuPNwaGdHIGcwnjRLOdRsfAbfcEBBtnYoNFztHytkhzNWlTRoPNYqsGDeAKKfIHRegDMaCiVKLaqBTIQLhMNcHJbiezmgBtVLYpXoPVyZvzWDQkLzAnEmvxDl");
    bool OkWZCmnNr = true;
    string MIsQcK = string("wfgVAVhyGskSwGSqZksAQZimjAXRbdsHhzNLTKAIYHSNEZlKIDMkdprxIOKaYsMalVEuFjBtqBKAvSMAWoHTJGdyxBYSFlSsjRLatLOaPpiIhXAMbGtOTigmoUgB");
    int szPOsbpdpp = -679194488;
    double tPKUisPc = 223139.05352285953;

    for (int youcnHDzgn = 1256934018; youcnHDzgn > 0; youcnHDzgn--) {
        jmQEfdAE = VJfZRYQJegqF;
    }

    for (int QkIzMGvmNiMkEJct = 87809234; QkIzMGvmNiMkEJct > 0; QkIzMGvmNiMkEJct--) {
        MKGKHpXyhnesGc *= xXDKIMCMpAlMaz;
        jmQEfdAE = MIsQcK;
        szPOsbpdpp /= cqtzLPLsApFNRzD;
    }

    for (int IJsKckQpkyjTpA = 397358181; IJsKckQpkyjTpA > 0; IJsKckQpkyjTpA--) {
        tPKUisPc /= xXDKIMCMpAlMaz;
        MKGKHpXyhnesGc *= xXDKIMCMpAlMaz;
    }
}

bool SlZSMaA::JgcgPNEVkDnKX(double ObXNvIDQEIvUUPS)
{
    int BzcRpVQXU = -2078262856;
    int qzEIzIfIBkbNKwh = -1317501813;
    double YFhPIMmd = -718105.3946696181;
    bool CgFUZgtTSThK = true;
    int XxJquwYQhTM = -2126223552;
    string OwhRnuVKLcsBFun = string("sJQVELFnnhjmJxBTPCYWQnqcwYCkpyJXRYTkDVaTSiKfUOqluCwNXMeoKgVfjRViqBDnqilXZlgjqUtkgkrsDevPfhWfVeN");
    double QoFpNv = 503176.5890401262;
    int XkFllTZTYhC = -1500938790;
    bool igbRERLHgxrjYue = true;
    double JHMCXJBRNraPrR = 664410.9459490039;

    if (YFhPIMmd > 117638.15872317976) {
        for (int ghrnymKBlfyQ = 1633172117; ghrnymKBlfyQ > 0; ghrnymKBlfyQ--) {
            XkFllTZTYhC /= XxJquwYQhTM;
            CgFUZgtTSThK = CgFUZgtTSThK;
            igbRERLHgxrjYue = ! igbRERLHgxrjYue;
            QoFpNv /= YFhPIMmd;
        }
    }

    if (JHMCXJBRNraPrR <= -718105.3946696181) {
        for (int dSUQCE = 26793496; dSUQCE > 0; dSUQCE--) {
            continue;
        }
    }

    if (ObXNvIDQEIvUUPS < 503176.5890401262) {
        for (int elqjUrwkImJyP = 195712185; elqjUrwkImJyP > 0; elqjUrwkImJyP--) {
            continue;
        }
    }

    return igbRERLHgxrjYue;
}

bool SlZSMaA::EdqqLcr(bool ogMQZVRVKzzCnzJ, int YcXNHEi, string UPWHHvQraG, bool qIwvh, string ypUDNJeLqku)
{
    bool FgCqpcR = false;
    double YvwZTiTV = -48742.93669572235;
    int migauFA = 1703721947;
    int dhMPqHN = -818341993;
    string MjzspAZUv = string("vTRygcMKRGIlLwmmfVnyQQjDCquRGktefapMtnYnVesKdeUIOuwDqsVaWPEanMrXPIfGleBqsWbQJfOwuJzmsIDSnEiYqJyAOK");
    bool kUuzetbDxPEzf = false;
    bool icaRILRE = false;
    int OVgIgOoENuPOPIBK = -1017018844;
    bool CWgQx = false;
    double YMPquymTyoalao = 588710.2268683105;

    for (int NyJgcZOw = 2139210335; NyJgcZOw > 0; NyJgcZOw--) {
        YcXNHEi *= migauFA;
        OVgIgOoENuPOPIBK /= dhMPqHN;
    }

    if (MjzspAZUv < string("AQsEqCwWYOfVTJJZqHwBawjZwiGAudqiIzKtcHHFBPSqqxmlIrMENuCGSakafHsJUBTENgVlgNgvbnDdeXPabNEN")) {
        for (int NTBPmWONZDjIc = 1633856367; NTBPmWONZDjIc > 0; NTBPmWONZDjIc--) {
            ogMQZVRVKzzCnzJ = ! kUuzetbDxPEzf;
            qIwvh = qIwvh;
        }
    }

    if (qIwvh == true) {
        for (int kfbRGxdz = 135600296; kfbRGxdz > 0; kfbRGxdz--) {
            migauFA *= dhMPqHN;
        }
    }

    if (CWgQx != false) {
        for (int iaaIOQSgNqCdA = 647057161; iaaIOQSgNqCdA > 0; iaaIOQSgNqCdA--) {
            qIwvh = ! CWgQx;
            UPWHHvQraG += MjzspAZUv;
        }
    }

    if (FgCqpcR != false) {
        for (int nvCtwkdVSTObaz = 301635536; nvCtwkdVSTObaz > 0; nvCtwkdVSTObaz--) {
            continue;
        }
    }

    if (icaRILRE == true) {
        for (int kiGtWjlVeNYpww = 1999478534; kiGtWjlVeNYpww > 0; kiGtWjlVeNYpww--) {
            CWgQx = ! qIwvh;
        }
    }

    for (int WNCkCrePsQtdP = 1584520460; WNCkCrePsQtdP > 0; WNCkCrePsQtdP--) {
        ogMQZVRVKzzCnzJ = ! FgCqpcR;
    }

    return CWgQx;
}

string SlZSMaA::GeCwv(string aoDMjJBfZdZDwK, string mOtxWaz, double FTdgIChT, double QtKwleINxzC)
{
    int PiAUatYDqs = -2052624061;
    bool LxRoLUlOdLKN = false;
    string zFnTirozoAUTho = string("RiXvdmdQjSBxyczbotRFConnhmviCRYUyzrJFUEfuBexWSigBOonSvsFoLYCzZtuIalPtkkPNmtmcDwKPJIkiHTjnQKAPZnXZsVubUUrXbMwbReLYnIvlqRGOuEms");

    for (int AsBCfEKckF = 598070219; AsBCfEKckF > 0; AsBCfEKckF--) {
        aoDMjJBfZdZDwK = aoDMjJBfZdZDwK;
        aoDMjJBfZdZDwK += mOtxWaz;
        PiAUatYDqs += PiAUatYDqs;
    }

    for (int aLhdni = 355137208; aLhdni > 0; aLhdni--) {
        FTdgIChT += FTdgIChT;
        aoDMjJBfZdZDwK += aoDMjJBfZdZDwK;
    }

    for (int qGJvMyNbdt = 1760996970; qGJvMyNbdt > 0; qGJvMyNbdt--) {
        PiAUatYDqs *= PiAUatYDqs;
        mOtxWaz = aoDMjJBfZdZDwK;
    }

    return zFnTirozoAUTho;
}

bool SlZSMaA::jmzwKRyNVu(double xPffEy, double fhKQYUi, string oUjAZn, double EQjMft)
{
    int RrOccavYUeJbfXT = 1073107664;
    double QmevkEUroMT = -452941.04749837273;
    bool bdPpmxu = true;
    int XvYOeiNKqtwBqDxu = 921812699;
    string XnGWusg = string("FfMHrIouvwclEdHS");

    for (int iGhXDUk = 212062975; iGhXDUk > 0; iGhXDUk--) {
        continue;
    }

    for (int IwQvhZzoCQ = 807466800; IwQvhZzoCQ > 0; IwQvhZzoCQ--) {
        EQjMft += fhKQYUi;
        QmevkEUroMT -= xPffEy;
        QmevkEUroMT += EQjMft;
    }

    return bdPpmxu;
}

double SlZSMaA::QtASWP(int NimZFcAtuPdGMQ, bool VAhuRcEjq, double TKlHiIB)
{
    double HxDWzfrtlBpS = 476896.4137390067;
    double oHcNfBzcZcFf = 690302.9026427213;
    string KiEQAbKKwPX = string("cFPUKSCrIbwBsGszdQgQQQLPcsfSFlYKGewefScKDEXfFBlYsyYOCxLZuQhHmIspwDxkuCJnsdgoDkmogEONchJmJGPaReSJTeaSFXosMCiUlnurzgSTjqKefsTNTaw");
    int ODZbriwxEhtz = -1652378006;
    double CtsxaSC = 891245.7594942506;

    for (int CIWAruYtHK = 673347040; CIWAruYtHK > 0; CIWAruYtHK--) {
        oHcNfBzcZcFf *= HxDWzfrtlBpS;
        HxDWzfrtlBpS *= CtsxaSC;
    }

    if (oHcNfBzcZcFf > 690302.9026427213) {
        for (int wwRoanaL = 1672941111; wwRoanaL > 0; wwRoanaL--) {
            CtsxaSC /= oHcNfBzcZcFf;
        }
    }

    for (int Xrhco = 2142811751; Xrhco > 0; Xrhco--) {
        ODZbriwxEhtz = NimZFcAtuPdGMQ;
        VAhuRcEjq = VAhuRcEjq;
        TKlHiIB *= HxDWzfrtlBpS;
    }

    return CtsxaSC;
}

void SlZSMaA::qWMpyL(bool lypizyxQNhRnEiIE, bool gDhPz)
{
    bool jJEYq = true;
    bool SfAPF = false;

    if (gDhPz != true) {
        for (int gBYFSVWUJdFNyK = 2146172977; gBYFSVWUJdFNyK > 0; gBYFSVWUJdFNyK--) {
            gDhPz = ! SfAPF;
            gDhPz = gDhPz;
            lypizyxQNhRnEiIE = jJEYq;
            jJEYq = lypizyxQNhRnEiIE;
        }
    }

    if (SfAPF != true) {
        for (int nwPwOj = 44462344; nwPwOj > 0; nwPwOj--) {
            lypizyxQNhRnEiIE = jJEYq;
            SfAPF = lypizyxQNhRnEiIE;
            gDhPz = ! SfAPF;
            gDhPz = jJEYq;
            lypizyxQNhRnEiIE = jJEYq;
            lypizyxQNhRnEiIE = SfAPF;
            lypizyxQNhRnEiIE = ! SfAPF;
        }
    }

    if (jJEYq == true) {
        for (int WscVDdqYClLq = 598831259; WscVDdqYClLq > 0; WscVDdqYClLq--) {
            lypizyxQNhRnEiIE = ! SfAPF;
            lypizyxQNhRnEiIE = gDhPz;
            gDhPz = gDhPz;
            jJEYq = gDhPz;
            SfAPF = lypizyxQNhRnEiIE;
            gDhPz = ! SfAPF;
            SfAPF = ! jJEYq;
            lypizyxQNhRnEiIE = ! jJEYq;
            gDhPz = gDhPz;
            lypizyxQNhRnEiIE = jJEYq;
        }
    }

    if (jJEYq == true) {
        for (int gOxoNKTRQG = 1382946354; gOxoNKTRQG > 0; gOxoNKTRQG--) {
            gDhPz = jJEYq;
            gDhPz = jJEYq;
            SfAPF = ! lypizyxQNhRnEiIE;
            gDhPz = jJEYq;
        }
    }
}

string SlZSMaA::XiOrPPfffrgKJMvz()
{
    bool AqOAuO = true;
    bool tTrEQCWYnHtl = true;
    string cAPxuV = string("YvmDEscUKCj");
    int OXGzKppsQS = -1045724570;
    bool bHDQmvMXIIAHTG = true;
    double lGcCeGtkIm = 911324.6277298537;
    double MkMudyQybw = 953361.5066691389;
    bool eADYiJSS = true;

    for (int EnnQQF = 2067354400; EnnQQF > 0; EnnQQF--) {
        AqOAuO = ! tTrEQCWYnHtl;
        eADYiJSS = ! tTrEQCWYnHtl;
        AqOAuO = ! tTrEQCWYnHtl;
    }

    for (int AmjGIKoHZNWlwC = 1155668095; AmjGIKoHZNWlwC > 0; AmjGIKoHZNWlwC--) {
        bHDQmvMXIIAHTG = AqOAuO;
        tTrEQCWYnHtl = ! bHDQmvMXIIAHTG;
        bHDQmvMXIIAHTG = AqOAuO;
    }

    for (int UVySzPTMgzQWP = 2109427950; UVySzPTMgzQWP > 0; UVySzPTMgzQWP--) {
        eADYiJSS = ! tTrEQCWYnHtl;
        MkMudyQybw /= lGcCeGtkIm;
    }

    if (bHDQmvMXIIAHTG == true) {
        for (int VgqMtHG = 762074468; VgqMtHG > 0; VgqMtHG--) {
            bHDQmvMXIIAHTG = bHDQmvMXIIAHTG;
            MkMudyQybw /= MkMudyQybw;
        }
    }

    return cAPxuV;
}

bool SlZSMaA::hsQspGf(bool ZpSthqV, bool hPOMqKqbSvN, double aoouX, int erTZgjCiZKg)
{
    string ayMwaMnyRJv = string("qtnCCzRigZejIjEPRsbNnpBaycBgBuhQQEZetAcfvhvusBFIgZYKoGWPZZMbViVuHFkvrZAUDlAUZUgJPYqHTPUBXkwWPNzdMXGafIFlXUzSddjsnmydZDrzJEs");

    if (erTZgjCiZKg <= -681327492) {
        for (int LFxRxVLAOJWMF = 206374990; LFxRxVLAOJWMF > 0; LFxRxVLAOJWMF--) {
            aoouX = aoouX;
            hPOMqKqbSvN = ! ZpSthqV;
        }
    }

    for (int TdEwETvQQp = 1433154904; TdEwETvQQp > 0; TdEwETvQQp--) {
        continue;
    }

    return hPOMqKqbSvN;
}

void SlZSMaA::ZsBKTHvFOaAGLrPc(double LIgJyH, bool yEUMgBKhFZak, bool fzXWMDniIVh)
{
    bool poAJYQSpj = true;
    string BeZencRHwM = string("IzBHzcsEeapHKwiqEmAIQkNrEUhOosKwpzccCBIJSibthNGRaGMqUMOxDUExRbJKbEWQAPjCoeivpbeVQClHvyiiFDcbJNOqzMHDokfPZTCshkYfwHhANyfcnxcNkfvxTcfXyocqiSHqssncGgPviAcIYmsJdSSIJVNoSCIlLMKSpkruPomuQJa");
    string uuORA = string("ccrhigJXqPXEmNkHXTlMKtLoYmBNVjwQBUTCUSNNXwpxJAGWWWrBLXPxZxWxOSxTQOHzktJyiexQNCJbSnPIIebUlEqWglWPKcZeUnPzEGuzGh");

    if (LIgJyH != 1034084.6524061563) {
        for (int WsLilULHlCzEWI = 1595815016; WsLilULHlCzEWI > 0; WsLilULHlCzEWI--) {
            fzXWMDniIVh = yEUMgBKhFZak;
            BeZencRHwM += uuORA;
        }
    }
}

void SlZSMaA::NUuPGuUV(int UqPuZfZBMjnAd, bool UEAyp, bool MKDvwmTcuKwLISD, bool DvUZqrjlBZzO)
{
    int LvyYiJhw = 1339202621;

    for (int ayliJwYv = 1360225667; ayliJwYv > 0; ayliJwYv--) {
        DvUZqrjlBZzO = ! UEAyp;
        UEAyp = UEAyp;
        LvyYiJhw -= UqPuZfZBMjnAd;
        UEAyp = DvUZqrjlBZzO;
        MKDvwmTcuKwLISD = UEAyp;
    }

    for (int IOuWXS = 1606810874; IOuWXS > 0; IOuWXS--) {
        MKDvwmTcuKwLISD = ! MKDvwmTcuKwLISD;
        UEAyp = ! UEAyp;
    }
}

double SlZSMaA::NlPefALWE()
{
    double sFwCnCWcVGAuaDs = -657606.0260541335;
    int aDMxMqnqGV = -989788400;
    string bGSAprNY = string("xLJbhXDrCfOZAUwzPHvVVfFiIEtcRIFvSVXQusJBwOBevuYnXKVAhWuYBgyXOIVYmriyPkMFTgCTVeIOnvxXoKzimsWRqhVbYlxqNYF");
    double fdHRLpDAVUNidi = -830036.8014202365;
    bool KtwHuFC = false;
    bool rlBAZvYTnzjOmKaw = true;

    for (int QDtcwIGksSgXEBb = 798462988; QDtcwIGksSgXEBb > 0; QDtcwIGksSgXEBb--) {
        KtwHuFC = KtwHuFC;
    }

    for (int ZwmLI = 1115311829; ZwmLI > 0; ZwmLI--) {
        continue;
    }

    return fdHRLpDAVUNidi;
}

SlZSMaA::SlZSMaA()
{
    this->KsLLFqtvbXPQa(173380.4703251037, string("WrDhtjpesjQioJroXhUqnrUeciEcVIQCeLASkYRQxIFqFtzufxxIwWVxmXDPbdiLrojFcSuhrHYZhHKZJqibXPGLNbEYUDjJuqtsiMXIpXtOWYuCMQHvXXKXkVAbknKteJrmQHQvdFvInwvvjlKjsMaYPoMRgymqBXIPWOiOQpQPevjuxUrgcEtHdcc"), false, -816882838);
    this->WDQUhbsENaZ();
    this->IXoCjVJhWmUk(-730473946, -431307.4126933591, true, false);
    this->JgcgPNEVkDnKX(117638.15872317976);
    this->EdqqLcr(true, 1898914976, string("AQsEqCwWYOfVTJJZqHwBawjZwiGAudqiIzKtcHHFBPSqqxmlIrMENuCGSakafHsJUBTENgVlgNgvbnDdeXPabNEN"), false, string("lGrYArLriHEAVZCBENPvTAJYMxtuYWSTRARSjlKDgzcsZDSHDovNNyabXYHfvUhpzqNjkspfBrYMBywipbMhyQxpKkeRGOvAKhjhoaUpeb"));
    this->GeCwv(string("zwRYbvmQWLBroZukNkqBjTNmcaGTSDJArmPexfyBVJmtHQwchBQQTuPicakVureOhlqARUIHqKuSXBcqOahYlKGgNNtdFpwvUudPFJgYfUIMZAHrHkrfabSjuejVDUZZEXmcLRRTBXMZWdi"), string("HdgrBqPODLLrcmGbkLKyRxlNSWmNUSCFtBzaZOpiFkPnspefmAwGPEVzyNRkqgOxGvKiAcZPHXNJHNmvMLjOguwIkBPaPxlHBkvGGCvbIRJxGdUj"), 867823.3019179652, -751508.390869771);
    this->jmzwKRyNVu(-344701.88331035286, 278507.9668687545, string("jTljiwbvYttcTAwTUKxrtTVTPLkfUqZBclEdjSnianPRJzAOGNHCTcFDNMOoUZjdaMByCNEtWERiNREhtmgTXFVjhDzVJJdZvdmHXqRXZEbUXy"), 552734.9661444701);
    this->QtASWP(-8401894, true, 547886.0242525107);
    this->qWMpyL(true, true);
    this->XiOrPPfffrgKJMvz();
    this->hsQspGf(true, true, 983723.7966995911, -681327492);
    this->ZsBKTHvFOaAGLrPc(1034084.6524061563, true, true);
    this->NUuPGuUV(-67849282, false, false, false);
    this->NlPefALWE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PHWDG
{
public:
    int QtEAzXkUxGTRBo;
    double jzgZvPKcQTkXvk;

    PHWDG();
    bool PJwfpVU(string xnTyfKpb, int RtbKQPGbxHhFHeSn);
    double XsAhLw(int cvAJsrKcOKX);
    double rNQsiPWkVKmhzhp(bool DuBcVcAgJ, string nUaytnHlddsFNyd, int oMtMtwDI);
    void DdRDRuwxCaBjXtjU();
    void tTkCQUO(double kBbWXdUvD, bool gRqKpzLYc, bool jCJyQtgaxrQKM, int quGRygwdYbd, int jexivLaz);
    void SHIZRcZxcI(double phzjaCnxStdGPqPa, double wJgEuDoV);
    bool YzHAIMzl(string CPJaYSElJSnpyjG);
protected:
    double qoVwAPIKfrPpFp;
    int hcvWrCNV;
    double niGRCuTIqUqpin;
    bool CdWgSzGr;
    bool BlEusAt;

    string nbmkeYBjmHuQYPm(int eBUMVOZxYwNkeS);
    double foclSgMvghIVb(double JmllnQLwa, bool sMuQtFTAFLlHj, int mspyhf, double rEYGtvQtQX);
    string CVCHIHVnaFOHq(int aWHnYfEmtSkqIb, int bukEmnOICqaJlLFo);
    string BeschCO(string BdATpYAgsjC, string gcZagxrpV, int AfJXknWULAOTuYT, string ThqQmwSWlRspCfOk);
    string TNsgmcfIpnBIP(bool CiTBvXVygDHaaztl, string vTrjGYQbYOqanz);
    string GNmiXscwcZSQSXJ(bool YLHSpEurKG, int QosSym);
    string PPgdeCfaaaMZgrS(string HynanCjbL);
    string IHaSTjG(bool Nazydok, string xfYUTdlWgapTqcy, bool UTcSLdhFDkytHxuH);
private:
    int xWsQHaZIhGYgONZp;
    string mUypTYKb;
    bool aOAebmHTJsjDd;
    int uxIopcY;
    double ksVhjryTUcbBLY;

    bool yxzlaSGEFlbog(string zxKYJiMHaD);
};

bool PHWDG::PJwfpVU(string xnTyfKpb, int RtbKQPGbxHhFHeSn)
{
    int OKrKUCxYcMIbgy = -1740967345;
    int BeZxA = -2059828858;
    string CwcUvmSdRsGvX = string("mWDTJowJdaYPrZFSXCifQFIRsPuPpAjuKhyAvtrlQdhhSqzGcPfyojcNGHAEKdoidHCmQVeIbAcXLItpZxCMveftGWDAHrgbPOSthaohPAbDaOaivxCivgHXJmywgyJAhCSGhCfTHEPOClcaiu");

    if (RtbKQPGbxHhFHeSn > -1740967345) {
        for (int uCGtKvhD = 716200558; uCGtKvhD > 0; uCGtKvhD--) {
            BeZxA /= BeZxA;
        }
    }

    return false;
}

double PHWDG::XsAhLw(int cvAJsrKcOKX)
{
    string PgBqktKTLlXqh = string("IIWwlpcTqmGVc");

    for (int gVSJMdiak = 1741486784; gVSJMdiak > 0; gVSJMdiak--) {
        cvAJsrKcOKX = cvAJsrKcOKX;
    }

    return 1014849.4924155053;
}

double PHWDG::rNQsiPWkVKmhzhp(bool DuBcVcAgJ, string nUaytnHlddsFNyd, int oMtMtwDI)
{
    int irqFuF = 208298173;
    bool tYGWPtXsV = false;
    double ZvYvIpdgdZg = -106990.45837605865;
    string GlJpckhP = string("sAebDpeDcLuHpvedBxrXgmSyqlPkQDxmgqdPRLEXRwBckyBJFAioLJdRCdmcxJNofBcINdnOfnnCOkvbGpUITSzKiUEyiyCqlHAZvfdJKQWtiZSusOzwGpmoAejxKgkmfcnwKAoZGzwQXBCfJudgXxmdcOFvAomlrAYkoJkyiPiNWhNaIBEJwZaHbbddyfqhCNdVgmwWaxvyMfOttQCABuXGCymriYp");
    double NtQGlGocO = 804762.2378890725;
    int lZkfLNAUHaj = 1315594804;

    if (ZvYvIpdgdZg < 804762.2378890725) {
        for (int xmlrvCdiuyXZFYr = 636942691; xmlrvCdiuyXZFYr > 0; xmlrvCdiuyXZFYr--) {
            oMtMtwDI *= lZkfLNAUHaj;
        }
    }

    return NtQGlGocO;
}

void PHWDG::DdRDRuwxCaBjXtjU()
{
    int tFEdyRRlYk = -1233168156;
    double vMoBl = 378265.4443725708;

    if (tFEdyRRlYk < -1233168156) {
        for (int zCkVHWkQCFrBEakU = 461690694; zCkVHWkQCFrBEakU > 0; zCkVHWkQCFrBEakU--) {
            continue;
        }
    }
}

void PHWDG::tTkCQUO(double kBbWXdUvD, bool gRqKpzLYc, bool jCJyQtgaxrQKM, int quGRygwdYbd, int jexivLaz)
{
    string tofAEd = string("draTwIioWUkHzBWSPLuHbGVMvjElyRAtcDkuqBjpElQppjMEJBTrKcXzDCWCnBzzwEZBCimhyWKTHBLHCXODakVvGTArQWQSihORrfWLFNnkHxhqNCnZxHdCNpfhAkmmElamZrJvIVxbUnjyeUmBKfDiHBCeTXavkiCzpmpidHqVufOdBWs");
}

void PHWDG::SHIZRcZxcI(double phzjaCnxStdGPqPa, double wJgEuDoV)
{
    double QodQYamkd = 268424.8146245981;

    if (QodQYamkd < 6751.718324332274) {
        for (int yNupZwrxKPEC = 1648752878; yNupZwrxKPEC > 0; yNupZwrxKPEC--) {
            phzjaCnxStdGPqPa = QodQYamkd;
            QodQYamkd /= phzjaCnxStdGPqPa;
            phzjaCnxStdGPqPa -= wJgEuDoV;
        }
    }
}

bool PHWDG::YzHAIMzl(string CPJaYSElJSnpyjG)
{
    double UdRKOTjZYTCQ = -125503.35909393978;
    int YrRWJXqyl = 341096910;
    double qXQnMysTRFnzEptq = 964122.5168950813;
    int wEmjxWNUqQpdZh = 778130022;
    bool VKUMTFHbt = true;

    for (int TwnCD = 1808326564; TwnCD > 0; TwnCD--) {
        continue;
    }

    for (int VvArKAQOc = 1372847737; VvArKAQOc > 0; VvArKAQOc--) {
        VKUMTFHbt = VKUMTFHbt;
        YrRWJXqyl -= YrRWJXqyl;
    }

    return VKUMTFHbt;
}

string PHWDG::nbmkeYBjmHuQYPm(int eBUMVOZxYwNkeS)
{
    int uZAgfLvteX = 182510593;
    string BNhxRDstUqRxAk = string("dWZCeQOamZsjxCFsbEQUQqgTlbNFhIQqLCQDiGuWXFerKsdgfdjgZHnNDptTfHgOSOZCSsehrwZLxfojHaJWXxdUndydrLbnpRglF");
    string JfkYYoWVCfjAV = string("CPKIJrdmpTaLfbtzAJQyQjxnTQHXTHKjrcHVghOyBmuRMmEniSRSVlomIycWMCcppXNqEeQYBjmaQifVwVPQCZRUaMvOOsFvTEbSxYoGKKSoYguAATZzkvJHRvqkTUOrtefEmAMkICCImtQEJqQWzENbKYngWrLABepwMzcirrCnLYlsBKsybwbHHWW");
    bool hXfXTnNRSxPDx = true;
    string pwSNGbrVAkaHEi = string("bZTZFYFhSCOYLtYXnnCgWedKvSeHCZJNYmwThtlDQgUjSjxPanWJAskgtzHrsqhdDLseRdxjumuBoPlRbNtUEoecouedaJyIZRJrQcQQsavzRPIxbadjmkRhOyclFWTLDhmgciBVOeXINlnvGMolknluwJJUExSUzfTUfvFBcDBKMVWJGAdXfpeSdOMFNPWnpaeXCPGbncVEzXnptZxPpExIdvczVivmzMPXFvnioQYbKhmJcNBMsW");
    string MKkAyUDtrFPwE = string("Glwyp");
    bool dyIlNS = false;
    double rfXpKogHjLZfD = 25366.45483624421;

    if (pwSNGbrVAkaHEi < string("Glwyp")) {
        for (int HmYqJXWx = 323194509; HmYqJXWx > 0; HmYqJXWx--) {
            continue;
        }
    }

    for (int StjioSXWnSJlcGC = 995304030; StjioSXWnSJlcGC > 0; StjioSXWnSJlcGC--) {
        dyIlNS = dyIlNS;
        uZAgfLvteX *= eBUMVOZxYwNkeS;
    }

    for (int DQWPvA = 605775648; DQWPvA > 0; DQWPvA--) {
        JfkYYoWVCfjAV = BNhxRDstUqRxAk;
        eBUMVOZxYwNkeS -= uZAgfLvteX;
    }

    return MKkAyUDtrFPwE;
}

double PHWDG::foclSgMvghIVb(double JmllnQLwa, bool sMuQtFTAFLlHj, int mspyhf, double rEYGtvQtQX)
{
    string PhjOipOG = string("bmzNZuiVQzClRcIxLFEJButBFLtxspHkmaIZtBZtcZzUYLbXWGncmcPeuaNKeHtApIlVxobvNqgHuOChKSVhPkznFwJBYpmXqYWmKEtlDknyZyPHqGeONpclIqlfbSaBJfZBIYFNXdGnQJsMSmevsPrkDMkJqBstIxNElyDvBgHMvNDqfFITvcYmMtjFTSCHEqTMqywNDqxsrufjaivkbTvPwkczBuuaBtKplvJQqzhburAfChjyXvwQ");
    double MqRzVXRqejSll = -363026.5770195901;
    double MQCdmlzjjWi = -588638.7760801021;
    int nKnPdkAxPLkHxApo = 1573486121;

    for (int tSSbeARP = 919988333; tSSbeARP > 0; tSSbeARP--) {
        nKnPdkAxPLkHxApo += mspyhf;
        MQCdmlzjjWi /= MQCdmlzjjWi;
        nKnPdkAxPLkHxApo -= mspyhf;
    }

    if (MQCdmlzjjWi != -588638.7760801021) {
        for (int SerWzuOGwYVxmtNU = 1410306347; SerWzuOGwYVxmtNU > 0; SerWzuOGwYVxmtNU--) {
            MqRzVXRqejSll *= rEYGtvQtQX;
            MQCdmlzjjWi -= MqRzVXRqejSll;
            MQCdmlzjjWi -= rEYGtvQtQX;
            MQCdmlzjjWi *= rEYGtvQtQX;
        }
    }

    for (int YbtcGCszxbjgyt = 1971843630; YbtcGCszxbjgyt > 0; YbtcGCszxbjgyt--) {
        MQCdmlzjjWi += MQCdmlzjjWi;
        PhjOipOG = PhjOipOG;
    }

    if (JmllnQLwa == -588638.7760801021) {
        for (int IDIVRqWpBiAiz = 902782475; IDIVRqWpBiAiz > 0; IDIVRqWpBiAiz--) {
            rEYGtvQtQX *= JmllnQLwa;
            MQCdmlzjjWi = MQCdmlzjjWi;
            JmllnQLwa = MQCdmlzjjWi;
            MqRzVXRqejSll = rEYGtvQtQX;
            MqRzVXRqejSll /= rEYGtvQtQX;
            sMuQtFTAFLlHj = ! sMuQtFTAFLlHj;
        }
    }

    return MQCdmlzjjWi;
}

string PHWDG::CVCHIHVnaFOHq(int aWHnYfEmtSkqIb, int bukEmnOICqaJlLFo)
{
    int ZfBeiaAWMzstKHQ = -580687814;
    int tAWCzmzZ = -726129515;
    bool vfZvRfw = true;
    double fCoecpaHIzMr = 1030977.9494119553;
    int grSONi = 1805296709;

    if (grSONi == -618199182) {
        for (int RkRAyCGBe = 1522174848; RkRAyCGBe > 0; RkRAyCGBe--) {
            grSONi -= aWHnYfEmtSkqIb;
            bukEmnOICqaJlLFo *= bukEmnOICqaJlLFo;
            vfZvRfw = ! vfZvRfw;
            grSONi *= aWHnYfEmtSkqIb;
            bukEmnOICqaJlLFo /= tAWCzmzZ;
            tAWCzmzZ *= tAWCzmzZ;
            aWHnYfEmtSkqIb -= bukEmnOICqaJlLFo;
        }
    }

    if (grSONi != -580687814) {
        for (int pZJCnwDI = 627126824; pZJCnwDI > 0; pZJCnwDI--) {
            bukEmnOICqaJlLFo -= bukEmnOICqaJlLFo;
            grSONi += ZfBeiaAWMzstKHQ;
            aWHnYfEmtSkqIb = grSONi;
            grSONi *= ZfBeiaAWMzstKHQ;
        }
    }

    for (int qEuklU = 1690472037; qEuklU > 0; qEuklU--) {
        bukEmnOICqaJlLFo += tAWCzmzZ;
        bukEmnOICqaJlLFo /= ZfBeiaAWMzstKHQ;
        tAWCzmzZ /= bukEmnOICqaJlLFo;
        aWHnYfEmtSkqIb *= tAWCzmzZ;
        tAWCzmzZ *= aWHnYfEmtSkqIb;
    }

    if (bukEmnOICqaJlLFo <= 1649320915) {
        for (int nUNRo = 240109330; nUNRo > 0; nUNRo--) {
            bukEmnOICqaJlLFo -= ZfBeiaAWMzstKHQ;
            ZfBeiaAWMzstKHQ += bukEmnOICqaJlLFo;
        }
    }

    if (ZfBeiaAWMzstKHQ > 1805296709) {
        for (int UQeWYGztmJuf = 96714603; UQeWYGztmJuf > 0; UQeWYGztmJuf--) {
            bukEmnOICqaJlLFo = ZfBeiaAWMzstKHQ;
        }
    }

    return string("EyHdCJyuLBQOByUNOuZGcXjIGZlDacstllCOsmqNsSbYEHw");
}

string PHWDG::BeschCO(string BdATpYAgsjC, string gcZagxrpV, int AfJXknWULAOTuYT, string ThqQmwSWlRspCfOk)
{
    bool TSZXzz = false;
    int sIWvT = -1073508100;

    for (int OwOYB = 797893066; OwOYB > 0; OwOYB--) {
        BdATpYAgsjC += BdATpYAgsjC;
        gcZagxrpV += gcZagxrpV;
    }

    if (BdATpYAgsjC <= string("nfzxLTBvoCEpYuiIfxzkNoFzoufCUUCeKYlOHQQbNnlRyQwoLLFurAzKMROWMkfLzqHhZRznHkMuUyiRSbLghOuCZxvXkcFgaDkiJMmUJoptwESScQGaXUkYqBqCHXZycLvTgAJbqaxjxzuXLNFOCSkJmWEPKccdBJSKqJxatRPFFt")) {
        for (int AQHFbKqURXQTkSG = 769533665; AQHFbKqURXQTkSG > 0; AQHFbKqURXQTkSG--) {
            continue;
        }
    }

    if (sIWvT >= -1278368872) {
        for (int TLNaGgAN = 622136059; TLNaGgAN > 0; TLNaGgAN--) {
            gcZagxrpV = ThqQmwSWlRspCfOk;
        }
    }

    if (BdATpYAgsjC >= string("IJlnaTJdojPlqEwqumNVDTTqGNTMcNAEcrIJglxANmNjlBOXfmoyLjfNFYxjauDdOYpZRigKtGL")) {
        for (int MjtTPWP = 188467751; MjtTPWP > 0; MjtTPWP--) {
            BdATpYAgsjC += gcZagxrpV;
        }
    }

    for (int zwSiOSiDfISHr = 523554592; zwSiOSiDfISHr > 0; zwSiOSiDfISHr--) {
        gcZagxrpV += BdATpYAgsjC;
        sIWvT -= AfJXknWULAOTuYT;
    }

    if (BdATpYAgsjC >= string("anWiiWgCpjsWOgd")) {
        for (int YSkeoFctQT = 1976796673; YSkeoFctQT > 0; YSkeoFctQT--) {
            sIWvT *= AfJXknWULAOTuYT;
        }
    }

    if (BdATpYAgsjC > string("IJlnaTJdojPlqEwqumNVDTTqGNTMcNAEcrIJglxANmNjlBOXfmoyLjfNFYxjauDdOYpZRigKtGL")) {
        for (int QpYtvisbrOQtl = 1964427323; QpYtvisbrOQtl > 0; QpYtvisbrOQtl--) {
            continue;
        }
    }

    return ThqQmwSWlRspCfOk;
}

string PHWDG::TNsgmcfIpnBIP(bool CiTBvXVygDHaaztl, string vTrjGYQbYOqanz)
{
    int dIXlkkGhicnUkEOK = 612202704;
    bool GYSYt = true;
    double RDWWXUz = 812002.2261711691;
    string coZIUEPUz = string("ZKEOVUpZyUcxpMcRjyGDGtoKSbclMSHbdpzuoYmnrguUXgyvrhWMFiguxcjkgeozCWGKsWVjACFHIYdNCJviDMLUkDoEuYdbQeBwYaQGYzLYnjipHsOVVAXmoGnpwrAly");
    bool pfOXIJLEVXBTLHK = false;
    double YBrfQLnjS = -60013.585897474084;
    string sKuBAYnEJjbeQ = string("iMlnOGSGsmUrefcbEJAJoEnVoLgbbKdvHBBvwoQBqoJtDGnwOkINheQKFsDDcXJgeSzBrzZNrSFLXkGyMAQeHMwMTmrfKuQxTVjmBzTXzAMjEuejWbgwEEzJhdhzMucnmOIgHLAJDNcQEeYUCaorAXzXJuPXLPWVSssJBpRFUzdpdCmorVIbeYPrum");

    for (int IZEcPJ = 1810722722; IZEcPJ > 0; IZEcPJ--) {
        continue;
    }

    for (int SiBAkzLuwCHN = 1670168473; SiBAkzLuwCHN > 0; SiBAkzLuwCHN--) {
        pfOXIJLEVXBTLHK = CiTBvXVygDHaaztl;
        RDWWXUz -= YBrfQLnjS;
        pfOXIJLEVXBTLHK = ! GYSYt;
    }

    return sKuBAYnEJjbeQ;
}

string PHWDG::GNmiXscwcZSQSXJ(bool YLHSpEurKG, int QosSym)
{
    int uEFuhliVdrHGEZaL = 1808692491;
    double XyawoCrsdDXK = -109477.49346794278;

    for (int NkotsByqflHkTFK = 2131832662; NkotsByqflHkTFK > 0; NkotsByqflHkTFK--) {
        QosSym += QosSym;
    }

    return string("gigKVNfQmdlNYufWQAqZUDUcirpUTulTxRGxEXJwjbEiWNqjZDJlluPfAySOGlCvorlvcvOPtyIxwKqOMgrtMzxVRaOyPFJGoaBqJuWMvKoOBdmbNvDVsXbbBDTFrukqPUpQRLxYZcLlpgkRmyxLiWoPeSokoKXIPKShkJiiELiBsGFbbfgfjVYH");
}

string PHWDG::PPgdeCfaaaMZgrS(string HynanCjbL)
{
    bool dxqEhVv = true;
    string RvQEhaHTHZGsHp = string("FNQIugNwvKqEbEKIVVDEgwdOtPuRtXjcrcrqkommfEPoTSrFxiIhbvduorVkhgNclffTxQYQweqRMgLhnzSEALfelEYrJtJSHOHWZijPZzPYFBzpZvEaHcjOuRLCgluzGqLPrXnmWnRDOGHjMoIDQKVgzVQFszToxosyOFSlVHgmOfScBhLugUnUpvitAsBqigk");
    double ipXSZHNSLWUY = 923257.5733586787;
    double HQhhYCCR = 494237.61150686117;

    if (dxqEhVv == true) {
        for (int eVpAEfYH = 1792571980; eVpAEfYH > 0; eVpAEfYH--) {
            HQhhYCCR -= ipXSZHNSLWUY;
            ipXSZHNSLWUY /= ipXSZHNSLWUY;
        }
    }

    if (dxqEhVv != true) {
        for (int UEOUbUpvpeOlsiep = 57017623; UEOUbUpvpeOlsiep > 0; UEOUbUpvpeOlsiep--) {
            continue;
        }
    }

    return RvQEhaHTHZGsHp;
}

string PHWDG::IHaSTjG(bool Nazydok, string xfYUTdlWgapTqcy, bool UTcSLdhFDkytHxuH)
{
    int SjGSZWgNOed = -384094076;
    int ZJnEnaqskSaSxD = 167704195;

    return xfYUTdlWgapTqcy;
}

bool PHWDG::yxzlaSGEFlbog(string zxKYJiMHaD)
{
    bool ZIRJIcMYTHmwgtD = false;
    bool kNiIfR = true;
    bool xYoyyTgGsfxQvfPy = true;
    int kOXjudeiAbVif = 1109357564;
    int HOhTtE = -510529541;

    for (int OPwyHlPuaIAJQbj = 129555878; OPwyHlPuaIAJQbj > 0; OPwyHlPuaIAJQbj--) {
        xYoyyTgGsfxQvfPy = ZIRJIcMYTHmwgtD;
    }

    if (kNiIfR == true) {
        for (int YfpypnXkfVTTXdJc = 622631317; YfpypnXkfVTTXdJc > 0; YfpypnXkfVTTXdJc--) {
            ZIRJIcMYTHmwgtD = ! ZIRJIcMYTHmwgtD;
        }
    }

    for (int KPGPxqP = 2121788354; KPGPxqP > 0; KPGPxqP--) {
        continue;
    }

    return xYoyyTgGsfxQvfPy;
}

PHWDG::PHWDG()
{
    this->PJwfpVU(string("DpqhnOGGgGhzjgNgjtOBtWqVXbp"), 542588720);
    this->XsAhLw(1117746984);
    this->rNQsiPWkVKmhzhp(false, string("GJanvAvlcrYlodKAreyoguhtLMPMZSukOuexzdavbKzEwnIAGIskrraUzyCxHKGCxfbOGaGKFPEIxkXVbwylGURUvjoBUPMjsKdPoQNDGVlTgovBIPNwzTzLbTVbtlCaSudRNUSTLvHCPZRAhcGxzWKDblHnSElpZBfSMAtbFMdbYjUQsWeNuRuGUnWiAXWxP"), -1129256415);
    this->DdRDRuwxCaBjXtjU();
    this->tTkCQUO(402646.5605369388, false, true, 254395216, -2067709784);
    this->SHIZRcZxcI(6751.718324332274, -527446.3353546334);
    this->YzHAIMzl(string("YGWrIunNJ"));
    this->nbmkeYBjmHuQYPm(-815863825);
    this->foclSgMvghIVb(474150.67214143527, false, -1012511336, -256509.18344915457);
    this->CVCHIHVnaFOHq(1649320915, -618199182);
    this->BeschCO(string("IJlnaTJdojPlqEwqumNVDTTqGNTMcNAEcrIJglxANmNjlBOXfmoyLjfNFYxjauDdOYpZRigKtGL"), string("anWiiWgCpjsWOgd"), -1278368872, string("nfzxLTBvoCEpYuiIfxzkNoFzoufCUUCeKYlOHQQbNnlRyQwoLLFurAzKMROWMkfLzqHhZRznHkMuUyiRSbLghOuCZxvXkcFgaDkiJMmUJoptwESScQGaXUkYqBqCHXZycLvTgAJbqaxjxzuXLNFOCSkJmWEPKccdBJSKqJxatRPFFt"));
    this->TNsgmcfIpnBIP(true, string("nNVijRJtGOswYNOTKXFxGWeizfutwhEMJkQwGyxuyuNcenfOgMCAJSFpMcHWAdhjiyaoghhBgfnArbVPLWEOnZVjKDqmhJLoQsgVnVyiIJggxas"));
    this->GNmiXscwcZSQSXJ(false, 757732616);
    this->PPgdeCfaaaMZgrS(string("kSaaKrfIMbFOasPCsqRDQpMLhotogkuAaGJfsFFApoTjMpZlErD"));
    this->IHaSTjG(false, string("dJSAIyidEiiiRCyUOTxcBHGXfLfZVsnwBgsJLXETZKdOxYXFhMu"), false);
    this->yxzlaSGEFlbog(string("hhRxwObbxRTAAYJLCDMUpoDOxxkQgErjtbmcGNdeTdrjsigmDMLgKZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xzGYvLmgwYEa
{
public:
    int ClGbLm;

    xzGYvLmgwYEa();
    bool AEwiiugrFGizShT(bool MhZEajsvrQ);
    double zqzrHyFuW(double YeKQmOZtwwHu, double poVefwbsp, int gYmnpntJGhECbMJ);
protected:
    bool cahHFqWdmqL;

    double oTMWCYxjBQdVPi(bool pWgIZvuydQShRsM, bool fIElEUSKUujfaO, int miuEEwbdaQGxey, double eKOyUQdgHyY);
    void zNpehNYsOEnugdO();
    bool MemkHqcwQVtgFZ();
    void OCzVryYzeUDy(bool asXuxsoOEEfZUG, bool eeojcs, string VyheyrvzkuzOzPi);
private:
    bool NgmOKelz;
    bool lvDPJWLnvMCdiEM;
    string LVYhDQfTpweQysN;
    string TRJwe;
    double nDXfWZSOOZpE;

    string JKDFOUqFDOunwwW(string VXSrovk, double LqqigWtbZ, string ubeRMCjgfjk, bool SHJRTzFZfpUHn, double EPValUOQNjGFx);
    void IDMrfcvT(double hckqcj);
    void jMelbGRcJ(int ISjfqfKFJWk, int BnYGDEYB, bool JFAqVWQZ, bool WjuBYcKNKAJ);
    int uyMpbNOBpSJuyWr(string dcbHu);
    void YsYzhcb(bool ugZKcwfAzuHWFZtr, string huvUmxWzHrzynDxd, double NGqqyUKcgECzzjJW, double JqWTSwsFm);
    bool anGcjGHjVfUa();
};

bool xzGYvLmgwYEa::AEwiiugrFGizShT(bool MhZEajsvrQ)
{
    bool hHsBszTiIgdYs = true;
    double bFqYyCQY = -79605.93212269752;
    string GZfqGGwSn = string("tbLaYugZsDVwWFlFabHnhbaZWkSdjssqjfrJvenApOQazzyKEbnOAhCwPPvpwnbAqqD");
    bool OgBQeg = false;
    bool VifVuoydO = true;
    bool MEBJpTwOsraRIWYE = true;
    string dsDKrGysQFmOmGe = string("UxfMcGQXbiokrLPosUjYxkaYnhkTlfQTOPDVOADGaSYHdMEmUOgBGkocNpgyoXs");
    int BVOjIWdNa = -228723682;
    string xYnnG = string("ryPrabWIDWr");
    bool nQoGEEIcsaJx = false;

    if (nQoGEEIcsaJx == false) {
        for (int AIgTEgkpA = 1012360439; AIgTEgkpA > 0; AIgTEgkpA--) {
            hHsBszTiIgdYs = ! hHsBszTiIgdYs;
            hHsBszTiIgdYs = ! VifVuoydO;
            VifVuoydO = ! MhZEajsvrQ;
        }
    }

    if (BVOjIWdNa != -228723682) {
        for (int udYdQd = 61962474; udYdQd > 0; udYdQd--) {
            VifVuoydO = ! MEBJpTwOsraRIWYE;
        }
    }

    for (int ShAfDZwFAYs = 475571730; ShAfDZwFAYs > 0; ShAfDZwFAYs--) {
        nQoGEEIcsaJx = ! nQoGEEIcsaJx;
        nQoGEEIcsaJx = hHsBszTiIgdYs;
    }

    for (int zEmNMIMCK = 304363998; zEmNMIMCK > 0; zEmNMIMCK--) {
        nQoGEEIcsaJx = MhZEajsvrQ;
        OgBQeg = ! OgBQeg;
        MEBJpTwOsraRIWYE = ! MEBJpTwOsraRIWYE;
    }

    if (xYnnG > string("tbLaYugZsDVwWFlFabHnhbaZWkSdjssqjfrJvenApOQazzyKEbnOAhCwPPvpwnbAqqD")) {
        for (int MKhoyyVQPgKA = 1154010490; MKhoyyVQPgKA > 0; MKhoyyVQPgKA--) {
            VifVuoydO = VifVuoydO;
            VifVuoydO = OgBQeg;
        }
    }

    return nQoGEEIcsaJx;
}

double xzGYvLmgwYEa::zqzrHyFuW(double YeKQmOZtwwHu, double poVefwbsp, int gYmnpntJGhECbMJ)
{
    double JsQNtBwG = 888336.7727986068;
    int tXLYMhDV = -943666376;

    if (tXLYMhDV == -943666376) {
        for (int rqVBpfKPAwaL = 1694827665; rqVBpfKPAwaL > 0; rqVBpfKPAwaL--) {
            tXLYMhDV += gYmnpntJGhECbMJ;
            poVefwbsp += YeKQmOZtwwHu;
            gYmnpntJGhECbMJ /= tXLYMhDV;
        }
    }

    return JsQNtBwG;
}

double xzGYvLmgwYEa::oTMWCYxjBQdVPi(bool pWgIZvuydQShRsM, bool fIElEUSKUujfaO, int miuEEwbdaQGxey, double eKOyUQdgHyY)
{
    int tNJdsXcpOuaVYJR = 176445423;
    bool VGWJzYAJCTjD = false;
    bool DKQWsVcMw = true;
    int XJGJDrPG = 454008400;
    bool LWvdfmzXq = true;
    string KJkewbUei = string("YIueVitGYudHqsHutsJGJzscvLevITMRPDJAXniEWkLLxRWkAQaUpJblwhqzplJfRmkKXqxlPkJLrLqpqjbYClYEcawXUKYqvvBqmxejDoTdODCnbPutnAyMfXkXBeORzyyNZbiTsVMyeJYegqVuLvdwoFKGpifufwXvbPefNkpqflJFxlwSFtoTCBSyDbCMvvSnvWBqdWHXSUhahVdbYEZMJnFugPzGVBxXecPEBraOXBFmzvN");
    int eNwmgYDEsyk = -134426608;
    double hMfjIyOXLmjBiv = -476792.1689072766;
    string gtHAFdOGSfD = string("jqpBkqqThSNLPALZEKfeFTPOixizqNypiHdhsusnoLGQLssNqLTOoyIteCusbcEEYTzHPxrJlqsIsQkCvyhEslcYwRQoqAHRQvhULngFGVieHAViSKcQODqvTwiyCekRpdXjIzetQFBiOJNvORXMOrphupajIdhWkTdBGGVQWzGEdmtQKKasvgwScECepTqRCfdupkPViiThlyipxaOHzGskqqgHIpsmqxPthD");

    for (int EURGZACWeHx = 372979730; EURGZACWeHx > 0; EURGZACWeHx--) {
        miuEEwbdaQGxey = tNJdsXcpOuaVYJR;
    }

    for (int PicwfVrjGjMBkws = 1834486043; PicwfVrjGjMBkws > 0; PicwfVrjGjMBkws--) {
        continue;
    }

    return hMfjIyOXLmjBiv;
}

void xzGYvLmgwYEa::zNpehNYsOEnugdO()
{
    int wPEhnBwBfNiidCo = 2023403581;
    double BRwHQswgvrswV = -1012141.2425564312;
    int SdulaWIEetUq = 1003670300;
    bool zjsyb = false;
    bool dwYsQgRjTOsVOVQT = true;

    for (int vEMpQCiBrxBPvG = 415544082; vEMpQCiBrxBPvG > 0; vEMpQCiBrxBPvG--) {
        zjsyb = zjsyb;
        wPEhnBwBfNiidCo -= SdulaWIEetUq;
        BRwHQswgvrswV = BRwHQswgvrswV;
        zjsyb = dwYsQgRjTOsVOVQT;
    }
}

bool xzGYvLmgwYEa::MemkHqcwQVtgFZ()
{
    int ZYcXNDiSPGkE = -232681676;
    int IZlVmdF = -194911126;
    string xvmYf = string("tiWANPhoQBqQGyfnCsloeYiHUMuQNTpbhOdmhjHRFlsMbQfVZIxJEKdiMzmmERBaHTqVqPnPlbmspSILPhqhgVowNzqUvcPzohPg");
    string zzjOI = string("niScepnJGqtuHJfXXVktBsIZQyByAxegLcpigQjnSUheoYGGaJBJxwLuKJMDsNqtSuUfunjjiXutfxpNAtNozWykBuocVjnxffGAtjXumRStCVIxQWGMMghLjsfCFsviBQJvxjdkJImdeuaPEVLCzHKCdKaGUAllBAAEaLOIzRBICVoMteaJIBSZHIVQ");
    int IkrekBEAeNnqprD = -499423608;
    int PZtAdBVnElggiv = -1373265201;
    double WINhzNVy = -187163.5625472557;
    bool rgyeBnoJDBzqkeW = false;

    for (int yzylKNhyf = 1794438651; yzylKNhyf > 0; yzylKNhyf--) {
        IZlVmdF = IkrekBEAeNnqprD;
    }

    return rgyeBnoJDBzqkeW;
}

void xzGYvLmgwYEa::OCzVryYzeUDy(bool asXuxsoOEEfZUG, bool eeojcs, string VyheyrvzkuzOzPi)
{
    string nwjuV = string("DZXZRHuKFfKopttjKLiwuOWdxLBjjJcbCaoAvTxTokACwhSJMfbdsNCiMkHyadJktfFcVx");
    bool wxKgLhZaUBORWrtG = true;
    double fHprpPMRUgrnYiD = 552304.2106242862;
    double xgRvfLzEpex = 623085.4468610374;
    double zAkvGvcQf = 71599.08293671638;
    string NRIzTwHUEqsdVDG = string("YreGleMYsibrrsFBNvobxmenqxCKaboqmuxHBcWmIuLhlPYhOK");
    int dVdWCi = -676619739;
    bool IcoCTvCxio = false;
    double KKtaMgtwyKtu = -820078.5870395316;
    string NYyiyakThQINbE = string("KNtKodbYXUaEuEdBAKbkRsXBvHckGpVNDBhBrecfQBlYZyKZChouTCLkgnMuXYJ");

    for (int tKIfpRG = 641257470; tKIfpRG > 0; tKIfpRG--) {
        fHprpPMRUgrnYiD = fHprpPMRUgrnYiD;
        fHprpPMRUgrnYiD -= xgRvfLzEpex;
        NRIzTwHUEqsdVDG += NRIzTwHUEqsdVDG;
        VyheyrvzkuzOzPi += nwjuV;
        wxKgLhZaUBORWrtG = ! wxKgLhZaUBORWrtG;
    }

    for (int wxihaqU = 924500665; wxihaqU > 0; wxihaqU--) {
        nwjuV = nwjuV;
        NYyiyakThQINbE += NRIzTwHUEqsdVDG;
    }

    if (NRIzTwHUEqsdVDG <= string("DZXZRHuKFfKopttjKLiwuOWdxLBjjJcbCaoAvTxTokACwhSJMfbdsNCiMkHyadJktfFcVx")) {
        for (int eRcOg = 776843729; eRcOg > 0; eRcOg--) {
            continue;
        }
    }
}

string xzGYvLmgwYEa::JKDFOUqFDOunwwW(string VXSrovk, double LqqigWtbZ, string ubeRMCjgfjk, bool SHJRTzFZfpUHn, double EPValUOQNjGFx)
{
    bool oMiDcKQl = true;
    bool hZDGGEMXtiGnjuNI = true;
    int aWIVQQVExLfclD = 1887895126;
    double KQAkQm = -742328.2587391137;
    double ZjUYGbBkeKG = -215861.67324170854;
    string aRbFhAibAKJOwWQd = string("mSfyisncXNeNvdSzoGgsqqyhpTBZfWOQQbceuwhDIFznGyrUkqCeWXkYRyoEJmzIMpHlIcFAxNAYBTtQiVxgmJvtlgrNoBtYkvtZjrtHyPNRBCIoajSjDVQHugqZCUOSmIvcVwYjvtCibCntBqiLRSLVfsDeBfcCVWabinHhdrroihPLSPZVlMTboROwXXnOaAfnKMRWVeku");

    for (int ujpTKpqbcAHV = 1870862300; ujpTKpqbcAHV > 0; ujpTKpqbcAHV--) {
        VXSrovk += aRbFhAibAKJOwWQd;
        EPValUOQNjGFx = LqqigWtbZ;
    }

    for (int JvLsEozN = 1364250375; JvLsEozN > 0; JvLsEozN--) {
        hZDGGEMXtiGnjuNI = ! hZDGGEMXtiGnjuNI;
        oMiDcKQl = ! hZDGGEMXtiGnjuNI;
    }

    for (int vneOq = 677546904; vneOq > 0; vneOq--) {
        aRbFhAibAKJOwWQd += VXSrovk;
    }

    for (int zNGZSIT = 536954309; zNGZSIT > 0; zNGZSIT--) {
        continue;
    }

    return aRbFhAibAKJOwWQd;
}

void xzGYvLmgwYEa::IDMrfcvT(double hckqcj)
{
    bool nUBZrbxCuJBJXwzq = true;
    bool ExBZkZauzgEYuW = false;
    bool GVcIAjpeV = true;
    int ZOgvf = 30835261;
    int YIiOXftVCi = -1502810411;
    int QdUngQCZstOMUsU = -1668503194;
    double GFJXKkoEJlSTSv = 901363.3387106139;
    int MshkleQMSLYIgCXv = 967623177;

    for (int zYhBhWu = 1373424239; zYhBhWu > 0; zYhBhWu--) {
        MshkleQMSLYIgCXv += QdUngQCZstOMUsU;
    }

    for (int pyZlIiAPff = 1774831347; pyZlIiAPff > 0; pyZlIiAPff--) {
        MshkleQMSLYIgCXv *= ZOgvf;
        YIiOXftVCi += QdUngQCZstOMUsU;
    }

    for (int EuJPxnwa = 268659562; EuJPxnwa > 0; EuJPxnwa--) {
        ZOgvf *= YIiOXftVCi;
        QdUngQCZstOMUsU = MshkleQMSLYIgCXv;
    }
}

void xzGYvLmgwYEa::jMelbGRcJ(int ISjfqfKFJWk, int BnYGDEYB, bool JFAqVWQZ, bool WjuBYcKNKAJ)
{
    double RCqXX = -444991.71547717485;
    int GWVRTAkV = -1937777832;
    int DvMVrMtFEDx = 66024523;

    if (BnYGDEYB >= -1937777832) {
        for (int zlnheUVUqW = 1754547778; zlnheUVUqW > 0; zlnheUVUqW--) {
            JFAqVWQZ = WjuBYcKNKAJ;
            GWVRTAkV /= ISjfqfKFJWk;
            RCqXX *= RCqXX;
            GWVRTAkV /= BnYGDEYB;
        }
    }

    for (int bOHVynbNSscH = 224713347; bOHVynbNSscH > 0; bOHVynbNSscH--) {
        GWVRTAkV *= ISjfqfKFJWk;
        JFAqVWQZ = JFAqVWQZ;
        ISjfqfKFJWk -= BnYGDEYB;
    }

    for (int DXzOhLo = 2011006725; DXzOhLo > 0; DXzOhLo--) {
        BnYGDEYB -= ISjfqfKFJWk;
        BnYGDEYB += DvMVrMtFEDx;
        ISjfqfKFJWk -= DvMVrMtFEDx;
    }
}

int xzGYvLmgwYEa::uyMpbNOBpSJuyWr(string dcbHu)
{
    string FRnJJKdJR = string("nNBsqsdijFSmXVVzTBfohDPhKvVwGlHAXxpvUAWwkSCpvYWVzkWvLXERUznHXONWABcgVyLWnixSXWyTcDsWGuleIKdtHvEUDpoiVrPlkvdgDjfGNBUEXVKTtlGToRbSiHXMCuGcyWLoWPFWKPwfMnMM");
    string FExlcgk = string("oykZlTQaPEepijQpVFzrokJVwtUQVAGomyIAEnxKdBKVEppHAaYSvZANLMJqtjIeiYJWwCtCzGPiJsiIQpdyCuNxaoLxFStojpkArCRzPJSRqLsEhXIimLSjiuYIYoblWjTxQHHgosZHTghgBzyfuybNqGWGkJCGsXEKQuneZINdVjLXwWSlgItjWssicZEvOiDTrPalduJIDEBQyRkjgMbJlbByoQwViedBsKdlLPchuDWpyjIUTgfKcUK");
    int XlHgNpe = 546691192;
    double pSojwR = 1018106.5392535697;
    double SqJpfXVxcia = -529009.8055491614;
    string eXURqZIo = string("ZbLyTlRpmpOSuFaTqQJYgRwxrmlOOeEWBOTieBqwBwiFbLAqHbqnxiVCLgwcIePDTMfuNGWnAEfJOSIeJAscbnmqRGepg");
    int QWcObharzQvGemq = -992243275;

    for (int llekUk = 1333424917; llekUk > 0; llekUk--) {
        eXURqZIo += eXURqZIo;
        pSojwR *= SqJpfXVxcia;
        eXURqZIo = eXURqZIo;
    }

    return QWcObharzQvGemq;
}

void xzGYvLmgwYEa::YsYzhcb(bool ugZKcwfAzuHWFZtr, string huvUmxWzHrzynDxd, double NGqqyUKcgECzzjJW, double JqWTSwsFm)
{
    double ITGoyEhYypucBoBA = 210650.62615427555;
    string oBwvAWDqiM = string("TiamHlqhrqWoioLVUDmRwoXKCRAUNrsYCUlGHAkIEuaaJniMiSEorRNqdjRtelPqChPKspfmodjXhVKVPvHGqgwhKhUCgzKyVyPMVrUEzVfekEJbPeXKdSGKWrAVgYukVbbAJgUFSjVhFhyZBAtLoqcEcJXDBKdpftridoVeaOOzjKIBThTbGncaGYxCQcrmZkFCYIKZrzUKpMLIkvelwrlSbTAaYmCMcxjehBeyDxxnjkHriBRqLMBpDzM");

    for (int tEMZYRwMdfNElF = 1059386407; tEMZYRwMdfNElF > 0; tEMZYRwMdfNElF--) {
        JqWTSwsFm -= ITGoyEhYypucBoBA;
        NGqqyUKcgECzzjJW -= JqWTSwsFm;
        NGqqyUKcgECzzjJW -= ITGoyEhYypucBoBA;
        JqWTSwsFm /= NGqqyUKcgECzzjJW;
        JqWTSwsFm -= ITGoyEhYypucBoBA;
    }

    for (int urNat = 1865813095; urNat > 0; urNat--) {
        continue;
    }

    for (int nUGRaUhpbf = 2095798572; nUGRaUhpbf > 0; nUGRaUhpbf--) {
        continue;
    }
}

bool xzGYvLmgwYEa::anGcjGHjVfUa()
{
    bool xyJktuululn = false;
    bool OCULFKKa = true;
    double SKEnHz = 84711.3516574646;
    string kAKqSGhfmR = string("emuPokeMYYZgYKmTvShKdVzhiHsOvCwvFDSdIukrYRIhZVuqPOroLAvxOiKcsPKDYZYJqSinydlELWLuPuVwqsPCcgukdnrWozaSsYjvXkjxeAcblQTrabuldfrtsxfzg");
    bool iYJKjUUgicvHslf = false;

    for (int PpUBWz = 414338994; PpUBWz > 0; PpUBWz--) {
        continue;
    }

    if (xyJktuululn == true) {
        for (int fYLAssBmxk = 42191870; fYLAssBmxk > 0; fYLAssBmxk--) {
            xyJktuululn = ! xyJktuululn;
        }
    }

    if (iYJKjUUgicvHslf != false) {
        for (int ZXpWqH = 1909399405; ZXpWqH > 0; ZXpWqH--) {
            OCULFKKa = iYJKjUUgicvHslf;
            OCULFKKa = ! iYJKjUUgicvHslf;
            iYJKjUUgicvHslf = ! xyJktuululn;
        }
    }

    return iYJKjUUgicvHslf;
}

xzGYvLmgwYEa::xzGYvLmgwYEa()
{
    this->AEwiiugrFGizShT(false);
    this->zqzrHyFuW(300384.931192669, -691901.7736749941, 282735299);
    this->oTMWCYxjBQdVPi(true, true, 1795112728, -853078.5860358468);
    this->zNpehNYsOEnugdO();
    this->MemkHqcwQVtgFZ();
    this->OCzVryYzeUDy(false, false, string("ZpXwhiXVNdbVKlfgDuvysFUSGRfzlkNEHgdjjtDRWtCfkFGJXlsuKnZaJxyqxImUXvLanbLOYqOoLlMApgbMqZsBaTAVBRuvYsbkbqppmuSCFWdVRRkKuxdrmSEDbfkarHBWQSrFtjYdJJoYbqGtJAqpvBqijnGKMlgUgrsCQxlFcGI"));
    this->JKDFOUqFDOunwwW(string("ebSdjODpMvtgEWADCsteRrZkpmjfplxVhpOAiFmIbaPZMegcpBXI"), 910007.9765323356, string("aUPfdYnDJyKMVUOREokhPwYihguDwDfxzqZnTopjgLHEvqstGNTlswRDrmSQcSDHcdL"), false, 532182.444103764);
    this->IDMrfcvT(-79788.53227073014);
    this->jMelbGRcJ(-2096458413, -1902511975, true, true);
    this->uyMpbNOBpSJuyWr(string("QzStzjhhzuNCWmqWRMMTSVRgcxoTXilVXDfXroQxRBTfhhHoWTiHPJIOuHwjBByHHmFrZUtyAQqIhzpdMKbKRhwiKtnagVnztkJMOgfUxOngydPoMvPdpaXlolawRElbvZwkJFlhHVGopVGcSiiHeUrlOSNpEGNBpwckDKVKRqOqlanUrTgIPlfQTdLktDOnuDkQZUGfdIWUYHHHTQaBcKBmnucEuzaABvLflwcjhOuZdnEpSSUoVJ"));
    this->YsYzhcb(false, string("gmRqCOcDOFmmaTuKWDmwHPaMaGcjydCDRLZys"), -315221.46317722904, -265130.3992409111);
    this->anGcjGHjVfUa();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rYHExWLsNclEcEV
{
public:
    double PTXGzMayLV;
    double NQmJNxL;
    string bjYif;
    bool ykiNN;

    rYHExWLsNclEcEV();
    string EOwjHbLEwKUbBVTr(double mJmCGGUlzSyZ, int FscGgMdTdEPFBgpO, double Salmkti);
    bool tzGLLqFQceUAbLQ(int PdJTsFWXzIvDgPKr, string JKAYxc, int WHMYSTF, int CUPVslOkuHraATqA, double DwQEqrZedeaYlahb);
    bool PJFkGOvzFcNhw();
protected:
    string BplhaeceoTrcbTr;
    int lPyShxfHdLbXnOlj;
    string XXebyKumok;

    bool CeunpqIiF(string nxumzrPDuPQLR);
    double EoNPeR(double cjuzstKWJcLaWu, bool XPwwmXbXZjmGIRq);
    int IlCsfXyjiyt(string kfcsWewuG, double HlUSJ);
    double mjkDmREw(double BAkvIQrfRLYl, double fdReSi);
private:
    bool amRLcRpfdaTSv;
    string pfZbnDUphM;
    string lZoBcHWocjFK;

    int lnnbdSdTUD(string CfyAlRupVBYQpEI);
    string DrYtOvuWWVP(double mmFRnZgeVafEgvzA, bool belxgyKcAhR);
    int rkyYU(double TflOktvvTAqCaGKI, int kWMDUxGBz, string HUymZXuL, int afgnZIrBnzrZb, int fRJLxXyr);
    void LbWzvnxoTRwkDqIA();
    bool acufgI();
    void jFAPkibSyJmIVQzw();
    double ykhzVVTP();
    double SeNMcXQRRNQTat();
};

string rYHExWLsNclEcEV::EOwjHbLEwKUbBVTr(double mJmCGGUlzSyZ, int FscGgMdTdEPFBgpO, double Salmkti)
{
    string xhnXyzlyQiTt = string("dJzDgIeIObuQOSyNqFzqbzIBhYZriBmZRhqfJYxVJRVKGqRigfTVFGTMHpDNGKbcKhDrNXholwIQHWubPyHzkDHOoTfVczdadXJWYDCBwPOoiOaafMwKyMwbJuJYDVVACvfbYOZCmoTaiBDktLwnzudHVesOUgrw");
    bool ibhlQgXnVH = true;
    bool sgqlXZkNz = false;
    int JYgcTUnErViI = 914969193;
    string FLRymsAudhZqM = string("bZAYxCrQMAFpZnFdlrOIgCCJCphXolbkFnrznJIduLQTQelZkEFiJngrmGkYEmrrcPXNIQcnylYDRwzWHSaCGIJTitZIKZblRHlzsHKBXdqQQFOeIhJfydhWivfXsTUUBMchZMWKFSlfzGdhhnIfnYUHnhUXRjbliYIyzZhVfiFcuPkzheutKtsDYmCMQjfCPZyLyffCTlTKysCdiLjpXhPUeXNyYdaUISRoMkweTOYJBGKjBQDgcQ");
    double hHklz = -376590.37384950294;

    return FLRymsAudhZqM;
}

bool rYHExWLsNclEcEV::tzGLLqFQceUAbLQ(int PdJTsFWXzIvDgPKr, string JKAYxc, int WHMYSTF, int CUPVslOkuHraATqA, double DwQEqrZedeaYlahb)
{
    bool VZuieXd = true;
    string bhbLVzpARcXYXlCQ = string("ntLiZofaOrPTPEbjTUOfifCycwWdpkBPXxooXogoSlPaivovFJiSJblWQwSFLztxKLFlqXmODhQZJNbouYutqYENlFswvYLVOkPkciJwbSBiwDIsryOukAxuEMaDpnonJpmdzjVezFFw");
    int cdLKwvSAkdenaE = 968723473;
    int OpYumTJWoXRJvx = -97015040;
    bool AcaWOvN = false;
    int ONFOdUCYtfHK = 398019657;
    bool FWJhfeVtX = true;
    bool wTEQzJnPQKkpmCRN = false;
    string wCXHqFjJemE = string("mwtpAuXLyNvnvSQsnWbqhJjQmcZFGcdmBEYqTwzGviiKpkaDWTjQTQwEyrRivKSMCqegdWBheymKViYdCnEcUbsfSznzcRzDAfMwGbhDeJckOFdyoLQ");
    bool sAacUSXpCODu = false;

    for (int nsDgu = 1748154523; nsDgu > 0; nsDgu--) {
        continue;
    }

    if (OpYumTJWoXRJvx > -97015040) {
        for (int HkqODFgtTsjZRLM = 1060187738; HkqODFgtTsjZRLM > 0; HkqODFgtTsjZRLM--) {
            continue;
        }
    }

    for (int sTLtG = 1187224199; sTLtG > 0; sTLtG--) {
        continue;
    }

    for (int FpFnYPrnFchhEsI = 1905600527; FpFnYPrnFchhEsI > 0; FpFnYPrnFchhEsI--) {
        continue;
    }

    for (int rOnjKDrea = 293178151; rOnjKDrea > 0; rOnjKDrea--) {
        sAacUSXpCODu = wTEQzJnPQKkpmCRN;
    }

    for (int IHEmCSNDdtFuMKuL = 131283812; IHEmCSNDdtFuMKuL > 0; IHEmCSNDdtFuMKuL--) {
        continue;
    }

    for (int lkgMlqTxCrQWAPan = 137700741; lkgMlqTxCrQWAPan > 0; lkgMlqTxCrQWAPan--) {
        continue;
    }

    for (int yAiLg = 1046717971; yAiLg > 0; yAiLg--) {
        PdJTsFWXzIvDgPKr -= PdJTsFWXzIvDgPKr;
        sAacUSXpCODu = ! FWJhfeVtX;
    }

    return sAacUSXpCODu;
}

bool rYHExWLsNclEcEV::PJFkGOvzFcNhw()
{
    int HixSRaSRA = 1313211563;
    int IdoAd = -2062385761;
    double vmlMjINvu = -682173.9651812502;
    bool MVRPR = true;
    bool StwHMDSFypTb = false;
    double KIaUTtBnTZ = 882657.277412496;
    bool ZIJrmaRCiUpWNbHc = true;

    if (KIaUTtBnTZ != -682173.9651812502) {
        for (int uLowgUjmSHKdcet = 1857584213; uLowgUjmSHKdcet > 0; uLowgUjmSHKdcet--) {
            KIaUTtBnTZ -= vmlMjINvu;
        }
    }

    if (ZIJrmaRCiUpWNbHc == false) {
        for (int mVDZLcudKcPZjw = 1927323340; mVDZLcudKcPZjw > 0; mVDZLcudKcPZjw--) {
            MVRPR = ! MVRPR;
            ZIJrmaRCiUpWNbHc = MVRPR;
        }
    }

    return ZIJrmaRCiUpWNbHc;
}

bool rYHExWLsNclEcEV::CeunpqIiF(string nxumzrPDuPQLR)
{
    bool IQYrCdZ = true;
    int jNiVo = 923806075;
    string eWDmFMkRcU = string("MhxzWlFlGNOuAmMKPJYbZonKRpvmJJowCYHFEkcIUYWUZiDowswdLsiKPRdvulyFtepBsmmmupcRkfacCwrxCbQcVSyeLNCvtkjDjxOLcUtHzwCxEehEZZWDwmNZKCjUfXEyCfamzgVXRSLVsLwBEnlDgvoAaCQnRlFeeAqetjVhVZvtSnRfkzkaXAQWeqmUVKGadUuXAlpQWMPupGjV");
    bool BunGlvIHvg = true;

    for (int wZneqmQoVsWvDB = 795495; wZneqmQoVsWvDB > 0; wZneqmQoVsWvDB--) {
        jNiVo -= jNiVo;
        nxumzrPDuPQLR = nxumzrPDuPQLR;
        eWDmFMkRcU += eWDmFMkRcU;
    }

    for (int UdImLlkEkXBuMD = 1160680902; UdImLlkEkXBuMD > 0; UdImLlkEkXBuMD--) {
        IQYrCdZ = ! IQYrCdZ;
        eWDmFMkRcU += eWDmFMkRcU;
    }

    if (eWDmFMkRcU == string("CaHvJHAxGNwcbnDHBebSjfTLrPWWpusYRWJLRAItgHsGIgHWSxWgivgDUhzBOGYmpNIiiJExrfdJBCdXNMzdZBBMEaRZezTdbBqzvSyPpOplUPtiSxsRMwGjvjWwUVbPAbkMwTFnIHsyLhyKOEaygoniCGUPbuvTLWbdvBfLeWaVBrEZisNQAOhSamXmGZHjrfEVvHvXTVSUBrzpvugdohtPG")) {
        for (int wLtqMsPMHxK = 117462967; wLtqMsPMHxK > 0; wLtqMsPMHxK--) {
            eWDmFMkRcU += nxumzrPDuPQLR;
            nxumzrPDuPQLR = eWDmFMkRcU;
            IQYrCdZ = ! IQYrCdZ;
            IQYrCdZ = IQYrCdZ;
            eWDmFMkRcU = eWDmFMkRcU;
        }
    }

    for (int EWTVGOT = 1605036829; EWTVGOT > 0; EWTVGOT--) {
        continue;
    }

    if (IQYrCdZ == true) {
        for (int plwQTbYK = 1358136217; plwQTbYK > 0; plwQTbYK--) {
            BunGlvIHvg = BunGlvIHvg;
            jNiVo /= jNiVo;
            nxumzrPDuPQLR = eWDmFMkRcU;
            nxumzrPDuPQLR += eWDmFMkRcU;
        }
    }

    return BunGlvIHvg;
}

double rYHExWLsNclEcEV::EoNPeR(double cjuzstKWJcLaWu, bool XPwwmXbXZjmGIRq)
{
    int XGLVN = 1219292710;
    string wOWsauak = string("lykoykvpIaNMnzHKfdmArVpObtuSimmRacxiAyZLjuvGBWUoNkFCnKrnxaSYPToRbSSzSKiYzAFnowkvTkYiowJCuDFlvHdqLlREkvxMdPFNxbCUPZNMcfsQSjWjOVwXYiLjAwJuIUKhbhQTnQlqZdMEpQlgY");
    bool lJLVpmWrG = false;
    bool TdsyWnZC = false;
    string uJAXzfIP = string("YCVIlugDPbCGnwYdxPXjpBIgyCQUvmRyRhaUeNtyCVShfaJLGlradLCzppSnHWgGLcdvlIgwjamcHYZIgizkEcmSLWeSRLfNHwKgYfblOxJHkSlveckhiCRbWsjTLVIqNntOKfuYdVGgCnddchUZOZOiAWbLPRySQEGRlnazzUPCJxFtYPPLdZXklgFwKWQCZi");
    double OBnhjRqAGUB = 980083.5839795966;

    for (int PJOobMexuy = 57338827; PJOobMexuy > 0; PJOobMexuy--) {
        wOWsauak += wOWsauak;
        XPwwmXbXZjmGIRq = ! TdsyWnZC;
        uJAXzfIP = uJAXzfIP;
    }

    for (int CXAFRNv = 488413491; CXAFRNv > 0; CXAFRNv--) {
        TdsyWnZC = ! lJLVpmWrG;
    }

    for (int JiGQwQwF = 652333310; JiGQwQwF > 0; JiGQwQwF--) {
        XPwwmXbXZjmGIRq = TdsyWnZC;
    }

    for (int DjuwGwQiLy = 1621389167; DjuwGwQiLy > 0; DjuwGwQiLy--) {
        uJAXzfIP = wOWsauak;
    }

    for (int DsEtM = 67091100; DsEtM > 0; DsEtM--) {
        continue;
    }

    if (OBnhjRqAGUB <= 980083.5839795966) {
        for (int FowsBlKt = 1060988669; FowsBlKt > 0; FowsBlKt--) {
            continue;
        }
    }

    if (XPwwmXbXZjmGIRq == false) {
        for (int FzYcBbTpyC = 963428535; FzYcBbTpyC > 0; FzYcBbTpyC--) {
            continue;
        }
    }

    return OBnhjRqAGUB;
}

int rYHExWLsNclEcEV::IlCsfXyjiyt(string kfcsWewuG, double HlUSJ)
{
    bool kyDsGpnEI = true;
    int YljBSPtUqHezpVI = 1805981838;

    if (kfcsWewuG >= string("kkrBxlPuDODUMLYTCQXdzaiqAgSDnheentdEhqlwjhUKakRMGwCexQrEgRgmYkSTyqIJrDrKsysfOFDIbpHaQMPKyzTbCGJfkcaHxkDGukKpGywghhQFZsmrWZLTQgRGmTWsCVCgznxrCDWsZRUcUFagSlxIJtZjeOFaUrbOjFgCvMlgJtHutiJNRElZAoFrYBxKvuefzGxqcTOfmhSLrKCPgSPaPSzwxIkbKX")) {
        for (int UrtnyWkUX = 1989541182; UrtnyWkUX > 0; UrtnyWkUX--) {
            HlUSJ *= HlUSJ;
        }
    }

    if (kfcsWewuG <= string("kkrBxlPuDODUMLYTCQXdzaiqAgSDnheentdEhqlwjhUKakRMGwCexQrEgRgmYkSTyqIJrDrKsysfOFDIbpHaQMPKyzTbCGJfkcaHxkDGukKpGywghhQFZsmrWZLTQgRGmTWsCVCgznxrCDWsZRUcUFagSlxIJtZjeOFaUrbOjFgCvMlgJtHutiJNRElZAoFrYBxKvuefzGxqcTOfmhSLrKCPgSPaPSzwxIkbKX")) {
        for (int GDpaZLQmM = 79942418; GDpaZLQmM > 0; GDpaZLQmM--) {
            YljBSPtUqHezpVI += YljBSPtUqHezpVI;
        }
    }

    if (YljBSPtUqHezpVI < 1805981838) {
        for (int XSydwYJoH = 67064115; XSydwYJoH > 0; XSydwYJoH--) {
            kyDsGpnEI = kyDsGpnEI;
            kfcsWewuG += kfcsWewuG;
            kyDsGpnEI = kyDsGpnEI;
        }
    }

    return YljBSPtUqHezpVI;
}

double rYHExWLsNclEcEV::mjkDmREw(double BAkvIQrfRLYl, double fdReSi)
{
    int wEZhUXOqCsqVmeG = -252260187;
    bool vtNcFshIkumijmx = true;
    double yKiPDqK = 487868.65022854775;
    int wpVzAbfn = 780954328;
    bool uPkPsBFubh = true;
    bool mtYHZOCzntS = false;
    double ZeGElVHhjIETUuD = 848325.1800848662;
    int gqGniJNAUwZOUn = 1148301974;
    int cforMsRqNrEximCY = 957468153;

    for (int yXLJuTbpIlUMIU = 39758460; yXLJuTbpIlUMIU > 0; yXLJuTbpIlUMIU--) {
        ZeGElVHhjIETUuD += yKiPDqK;
        wEZhUXOqCsqVmeG /= gqGniJNAUwZOUn;
    }

    return ZeGElVHhjIETUuD;
}

int rYHExWLsNclEcEV::lnnbdSdTUD(string CfyAlRupVBYQpEI)
{
    bool IQAXpzM = false;
    bool BPOpNNG = false;
    int ZMhxZCPgEiEbF = 1058717260;
    bool vFcQRCa = true;
    double zAnddhKTz = -974988.1536829767;
    int sjzZhDjWdWrMbHO = 944407746;
    bool cVbLNMoq = true;
    double RlbllTRD = 492554.57643814874;
    bool ULTOEGM = false;

    for (int XSFnANlhXgaNGOom = 1365923232; XSFnANlhXgaNGOom > 0; XSFnANlhXgaNGOom--) {
        continue;
    }

    for (int UdvOC = 1884601314; UdvOC > 0; UdvOC--) {
        vFcQRCa = ! ULTOEGM;
        RlbllTRD -= zAnddhKTz;
        RlbllTRD -= zAnddhKTz;
        cVbLNMoq = ! IQAXpzM;
        cVbLNMoq = ! vFcQRCa;
        ULTOEGM = ! BPOpNNG;
    }

    for (int tLAHb = 1476691525; tLAHb > 0; tLAHb--) {
        cVbLNMoq = ! ULTOEGM;
        ULTOEGM = ! IQAXpzM;
    }

    return sjzZhDjWdWrMbHO;
}

string rYHExWLsNclEcEV::DrYtOvuWWVP(double mmFRnZgeVafEgvzA, bool belxgyKcAhR)
{
    bool hJSnWucihuJpNuH = true;
    bool BTQCNFe = true;
    double OBfEYkzW = -940120.6713550789;
    bool RPcdiDJwUR = true;
    string wZXsvygpbMcD = string("JnHJAsyzReWIPJxSJYJndgrjGdPcAXqZVv");
    double XvZngmYBiKaG = -563215.2697825383;
    double BHyrY = -121193.42588646212;
    double DMMlsjtVCtES = -217409.30504087073;
    string HlUmtkFBXHAxcZ = string("leJyENevcXaWhBbapgtxMjBrQnippANgtkvYlxxcrRCIQrNORCEbIYoYMoxnkeVfJIytJkdsb");
    double EYQKAf = -499276.86926436285;

    if (belxgyKcAhR != true) {
        for (int YApioCAktEdGz = 673154167; YApioCAktEdGz > 0; YApioCAktEdGz--) {
            mmFRnZgeVafEgvzA = DMMlsjtVCtES;
            EYQKAf -= OBfEYkzW;
        }
    }

    return HlUmtkFBXHAxcZ;
}

int rYHExWLsNclEcEV::rkyYU(double TflOktvvTAqCaGKI, int kWMDUxGBz, string HUymZXuL, int afgnZIrBnzrZb, int fRJLxXyr)
{
    string HezdtXfLgLvEQBr = string("DRwupkqymfPBRvDeEWVEveNNMIKfTlwChagmPckImrVrIyVCyWGpItwyodOdyDAMAwsmprRohBaLtESBhOhkyfkRBpaGFIPEYKfzOOlsVhKlQGSIGpetniaWxrYckNvZvuAubmqJfuWTqfikGQVeCaRLYtGIpKPcloXJEJCVAKwuCpdWsuKyfSbRuKE");
    bool HPBBBp = false;
    bool QdOnxLqghWaFSPE = true;

    for (int ePyhw = 668515936; ePyhw > 0; ePyhw--) {
        QdOnxLqghWaFSPE = HPBBBp;
        HUymZXuL += HezdtXfLgLvEQBr;
    }

    return fRJLxXyr;
}

void rYHExWLsNclEcEV::LbWzvnxoTRwkDqIA()
{
    double erIvIcBNVnx = 448663.4431192469;
    int jaieXVMnDQ = 1196745290;
    string cDGuzHxQNd = string("ENekhhtbPLvJWjlZUWITwPpVrfaUZreFvVpquDrvaHeRRAtDesXJEOjBUFOmrNajBCw");
    string sJTMQmYcdcpWGPRe = string("EdoNOvPsxBzInbXjRADaybiSSBtiFYPLEeKTDTInjaYcWjdqxiPtQyrVCOhZhQYuucSutDqmxyRrdbEYW");
    string FJLwMUNosuFlA = string("xRPtAkKeiTZIuYBDPmHbdayBJeTOSvHusjohDzpdwOILhiWWsTchALmVmeBkaDRsMhZywJfaClbutPGhMKIZZWpSJeCvzCIBicoaLsuJsptWdyUoSeOPGorBAdLuGDPdnquFwPiIZNZDQBbsufQzcPxYeuNvxqzjjbSykByeKrxEaxpQJNSmciBqn");

    if (cDGuzHxQNd <= string("EdoNOvPsxBzInbXjRADaybiSSBtiFYPLEeKTDTInjaYcWjdqxiPtQyrVCOhZhQYuucSutDqmxyRrdbEYW")) {
        for (int ciniWzsoJYOFFga = 812400185; ciniWzsoJYOFFga > 0; ciniWzsoJYOFFga--) {
            FJLwMUNosuFlA += sJTMQmYcdcpWGPRe;
            erIvIcBNVnx -= erIvIcBNVnx;
            jaieXVMnDQ = jaieXVMnDQ;
            sJTMQmYcdcpWGPRe += cDGuzHxQNd;
        }
    }

    if (cDGuzHxQNd < string("EdoNOvPsxBzInbXjRADaybiSSBtiFYPLEeKTDTInjaYcWjdqxiPtQyrVCOhZhQYuucSutDqmxyRrdbEYW")) {
        for (int huKNpQAsYCNf = 430552365; huKNpQAsYCNf > 0; huKNpQAsYCNf--) {
            sJTMQmYcdcpWGPRe = FJLwMUNosuFlA;
            sJTMQmYcdcpWGPRe = FJLwMUNosuFlA;
            cDGuzHxQNd += FJLwMUNosuFlA;
            jaieXVMnDQ -= jaieXVMnDQ;
            cDGuzHxQNd = FJLwMUNosuFlA;
        }
    }
}

bool rYHExWLsNclEcEV::acufgI()
{
    double mKhvc = 205086.28492259822;
    double FehDS = -479375.5183223884;
    double nwSLxsemVzbtLE = -482030.2682168738;
    int TRjEmOS = -2147287205;
    int CILHACd = -1505869410;

    if (CILHACd <= -2147287205) {
        for (int FlgRHGuKiXPdZ = 1197434375; FlgRHGuKiXPdZ > 0; FlgRHGuKiXPdZ--) {
            mKhvc += nwSLxsemVzbtLE;
            nwSLxsemVzbtLE -= mKhvc;
        }
    }

    if (CILHACd != -1505869410) {
        for (int zGeuh = 1976942697; zGeuh > 0; zGeuh--) {
            mKhvc = FehDS;
            FehDS -= FehDS;
            nwSLxsemVzbtLE += FehDS;
        }
    }

    if (TRjEmOS <= -2147287205) {
        for (int jMPRIEQu = 843281370; jMPRIEQu > 0; jMPRIEQu--) {
            FehDS += nwSLxsemVzbtLE;
            nwSLxsemVzbtLE = mKhvc;
            nwSLxsemVzbtLE -= mKhvc;
        }
    }

    if (CILHACd >= -2147287205) {
        for (int rtQDPcxDzUpAYl = 868095469; rtQDPcxDzUpAYl > 0; rtQDPcxDzUpAYl--) {
            FehDS += mKhvc;
            CILHACd *= CILHACd;
            CILHACd = TRjEmOS;
            FehDS += mKhvc;
        }
    }

    if (nwSLxsemVzbtLE >= -482030.2682168738) {
        for (int FCCgoivjWe = 634956622; FCCgoivjWe > 0; FCCgoivjWe--) {
            nwSLxsemVzbtLE -= FehDS;
            CILHACd = TRjEmOS;
        }
    }

    for (int zhOUIadBo = 1008593957; zhOUIadBo > 0; zhOUIadBo--) {
        nwSLxsemVzbtLE -= FehDS;
        mKhvc = nwSLxsemVzbtLE;
    }

    return false;
}

void rYHExWLsNclEcEV::jFAPkibSyJmIVQzw()
{
    int IXpUComDWfJoMxlz = -2115302762;
    int amGuLTwfCGO = 957401348;
    int lMhCrzNnfsGHEMa = -1411607794;
    string Fsedviqazw = string("hAfiZWgnbeFeyOeVKYVHqRcvnNeSQERXNXegIpxBUYGcKmnetEvpqrRcAblKlCWmxHMzFnuenMMnfwucztAgBNChYCpMBUvpoulUnZHKWEizdhkcNlIFiAwMIXPIdwDHSnDEcOBHhnOXmwpLUmmkVFhkgAggnsCPwpIWOgdPPXjoTkQSZxItmwiklGCqjttcDeeZwBIPsLpCTuWba");
    string QwrxkaOIWqi = string("KJDyXIQVRChdNhNqVOYcTTSDOiXbuuPJeBQrfVNnZERrlAgsJroJwwSExGmXYcVCtVBEBziBlAaxbzPJMPKLCLEZdCSdluQDNYoHoFIBo");
    int CMCXwNpMh = 741509580;
    double ErqVZXhgLYWTji = -463430.7992251181;
    string HKJoy = string("auXxMgaBQBatSFhBQCkoqHCrFQyXIFfjNLtLVzQRXJHqXcSXwXLRNnKJesMXFXdiyZjXcRYonMYFzTvVuXdMitcuXpEWEqbzpYqRIsPBjuPkOsMgnBjAiqIkNPOlCambYVVnlBSyzvvMWZLnQJA");

    if (QwrxkaOIWqi >= string("hAfiZWgnbeFeyOeVKYVHqRcvnNeSQERXNXegIpxBUYGcKmnetEvpqrRcAblKlCWmxHMzFnuenMMnfwucztAgBNChYCpMBUvpoulUnZHKWEizdhkcNlIFiAwMIXPIdwDHSnDEcOBHhnOXmwpLUmmkVFhkgAggnsCPwpIWOgdPPXjoTkQSZxItmwiklGCqjttcDeeZwBIPsLpCTuWba")) {
        for (int mafhTvbyqxduB = 1720213678; mafhTvbyqxduB > 0; mafhTvbyqxduB--) {
            lMhCrzNnfsGHEMa -= amGuLTwfCGO;
            HKJoy = HKJoy;
            CMCXwNpMh += amGuLTwfCGO;
        }
    }

    for (int CxJFHDZfUgO = 1328504643; CxJFHDZfUgO > 0; CxJFHDZfUgO--) {
        continue;
    }

    if (lMhCrzNnfsGHEMa <= 741509580) {
        for (int iKmHwSzfhdCcUVO = 601413404; iKmHwSzfhdCcUVO > 0; iKmHwSzfhdCcUVO--) {
            ErqVZXhgLYWTji = ErqVZXhgLYWTji;
        }
    }
}

double rYHExWLsNclEcEV::ykhzVVTP()
{
    int jkXYh = -1910808468;
    double IFqqGfVGLlRpH = -883415.990651444;
    int wpvIQuZoi = 822134436;
    string mIufJPTpSNfNdg = string("MzdPGteGGlfLEXRPwmuGQlHIVXicSbLZruIBiclAgMYrSlDfESnZVVjvJtWgvwPwZNFYrmGjKhsApRQtTXwGfZzYeXnNESbjxrbwIRRotVMyvGaTdmaFokSLcclXgVASDFITXCybaGtAUUWaLmxlaKqKZmNTmhmJBHqcBJwqZRLldxdursTvyacJBpCVgXNkLhFvSaJubwrEHSpwIvomRMev");
    int JOllinIaEbHabyaT = -655528172;
    string alOTkUA = string("AzzFANgnBHkGJeYesGCMwlKMsqFfHbyQhpUFlFxhzAaegfPeUVXBZeEiLbTCNlvvMkuXmqbyqLRagnrvdohvQdHrKjbcCjtfWYgRJjIT");
    string yraCX = string("OvESAtBKiHIZtbskIMdkCTtaCKSzcOkhTyVuOhOwFhRFtXPRBrccdDznqQytgsxPKjIqjUHQlsgUppkARzViwYQDxHHnVtaHpuAgrdVSHvjWJgwathzpvJyMXKGVCthTjdWcGWjRmWQK");
    double ZxvPDZeh = -834928.703495336;
    double oKSLqr = 809809.0449118525;

    for (int nyWiNBCukGf = 878120035; nyWiNBCukGf > 0; nyWiNBCukGf--) {
        JOllinIaEbHabyaT += jkXYh;
        alOTkUA += yraCX;
        ZxvPDZeh = ZxvPDZeh;
    }

    if (yraCX <= string("MzdPGteGGlfLEXRPwmuGQlHIVXicSbLZruIBiclAgMYrSlDfESnZVVjvJtWgvwPwZNFYrmGjKhsApRQtTXwGfZzYeXnNESbjxrbwIRRotVMyvGaTdmaFokSLcclXgVASDFITXCybaGtAUUWaLmxlaKqKZmNTmhmJBHqcBJwqZRLldxdursTvyacJBpCVgXNkLhFvSaJubwrEHSpwIvomRMev")) {
        for (int YbwlUuDw = 162014949; YbwlUuDw > 0; YbwlUuDw--) {
            continue;
        }
    }

    for (int fQodiVgvlcEyl = 668543706; fQodiVgvlcEyl > 0; fQodiVgvlcEyl--) {
        ZxvPDZeh = oKSLqr;
    }

    return oKSLqr;
}

double rYHExWLsNclEcEV::SeNMcXQRRNQTat()
{
    int oWREhOifyWcKJ = -826787459;

    if (oWREhOifyWcKJ < -826787459) {
        for (int EJxaQnevzmWH = 1128260700; EJxaQnevzmWH > 0; EJxaQnevzmWH--) {
            oWREhOifyWcKJ += oWREhOifyWcKJ;
            oWREhOifyWcKJ *= oWREhOifyWcKJ;
            oWREhOifyWcKJ = oWREhOifyWcKJ;
            oWREhOifyWcKJ *= oWREhOifyWcKJ;
            oWREhOifyWcKJ *= oWREhOifyWcKJ;
            oWREhOifyWcKJ /= oWREhOifyWcKJ;
            oWREhOifyWcKJ -= oWREhOifyWcKJ;
        }
    }

    if (oWREhOifyWcKJ <= -826787459) {
        for (int MVZhKEqhTG = 1090402791; MVZhKEqhTG > 0; MVZhKEqhTG--) {
            oWREhOifyWcKJ *= oWREhOifyWcKJ;
            oWREhOifyWcKJ += oWREhOifyWcKJ;
            oWREhOifyWcKJ /= oWREhOifyWcKJ;
            oWREhOifyWcKJ += oWREhOifyWcKJ;
        }
    }

    if (oWREhOifyWcKJ != -826787459) {
        for (int SpGtEeLQQZQg = 1732868753; SpGtEeLQQZQg > 0; SpGtEeLQQZQg--) {
            oWREhOifyWcKJ = oWREhOifyWcKJ;
            oWREhOifyWcKJ /= oWREhOifyWcKJ;
            oWREhOifyWcKJ += oWREhOifyWcKJ;
            oWREhOifyWcKJ += oWREhOifyWcKJ;
            oWREhOifyWcKJ = oWREhOifyWcKJ;
            oWREhOifyWcKJ -= oWREhOifyWcKJ;
            oWREhOifyWcKJ *= oWREhOifyWcKJ;
            oWREhOifyWcKJ = oWREhOifyWcKJ;
            oWREhOifyWcKJ /= oWREhOifyWcKJ;
            oWREhOifyWcKJ = oWREhOifyWcKJ;
        }
    }

    if (oWREhOifyWcKJ <= -826787459) {
        for (int rTboZblak = 586974688; rTboZblak > 0; rTboZblak--) {
            oWREhOifyWcKJ /= oWREhOifyWcKJ;
            oWREhOifyWcKJ /= oWREhOifyWcKJ;
            oWREhOifyWcKJ -= oWREhOifyWcKJ;
            oWREhOifyWcKJ *= oWREhOifyWcKJ;
            oWREhOifyWcKJ -= oWREhOifyWcKJ;
            oWREhOifyWcKJ += oWREhOifyWcKJ;
            oWREhOifyWcKJ *= oWREhOifyWcKJ;
        }
    }

    return 286527.3424935307;
}

rYHExWLsNclEcEV::rYHExWLsNclEcEV()
{
    this->EOwjHbLEwKUbBVTr(618347.9551339743, -2807182, -846133.9852029519);
    this->tzGLLqFQceUAbLQ(-544199035, string("xVcaOfzRKZlGlzNWIEitmAUHRJLkJMMkAlaOOwyLabbNwFDBsEBctPZpQjmXSpVvdHnUfQlVLEVsXpwKAdAFuPVBrxUndfzNBpoAIhpOnSFJKVsZBYprxliuXbVInGZcdGzTYqXTidRGiLLuOgiwrlslRRMRAVTHDawIubTWAqCVWIktIomFnYZkWVoZRKHkcwBSujgFvSckfsjaBBsZbbjGeATyUxLCvwpjNoEGA"), 611946016, -1786970026, -138767.83971421854);
    this->PJFkGOvzFcNhw();
    this->CeunpqIiF(string("CaHvJHAxGNwcbnDHBebSjfTLrPWWpusYRWJLRAItgHsGIgHWSxWgivgDUhzBOGYmpNIiiJExrfdJBCdXNMzdZBBMEaRZezTdbBqzvSyPpOplUPtiSxsRMwGjvjWwUVbPAbkMwTFnIHsyLhyKOEaygoniCGUPbuvTLWbdvBfLeWaVBrEZisNQAOhSamXmGZHjrfEVvHvXTVSUBrzpvugdohtPG"));
    this->EoNPeR(981334.9752054057, false);
    this->IlCsfXyjiyt(string("kkrBxlPuDODUMLYTCQXdzaiqAgSDnheentdEhqlwjhUKakRMGwCexQrEgRgmYkSTyqIJrDrKsysfOFDIbpHaQMPKyzTbCGJfkcaHxkDGukKpGywghhQFZsmrWZLTQgRGmTWsCVCgznxrCDWsZRUcUFagSlxIJtZjeOFaUrbOjFgCvMlgJtHutiJNRElZAoFrYBxKvuefzGxqcTOfmhSLrKCPgSPaPSzwxIkbKX"), -378658.14658761193);
    this->mjkDmREw(701884.2353247437, -47835.90606077281);
    this->lnnbdSdTUD(string("ZptdxhxStmLMuyUbYVAEOeCahIqASWUbYrlBXkSMLcVnrleBFqBzHFWwFBNpntVGETWCahSEzWDrCDgBHyhMLRcmupHUEWTQhZdJHSMjhvMnogUlqakHYgUCTCybkEyERYCVRvezELbQkFvynW"));
    this->DrYtOvuWWVP(-12897.776313529806, false);
    this->rkyYU(-684009.8746606589, -172490454, string("mARUXAYHE"), -698883170, -1614624331);
    this->LbWzvnxoTRwkDqIA();
    this->acufgI();
    this->jFAPkibSyJmIVQzw();
    this->ykhzVVTP();
    this->SeNMcXQRRNQTat();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ghEtvcxV
{
public:
    bool MbjZl;
    double znDtiHHGEjAu;
    int WapmibUqLNK;

    ghEtvcxV();
    string abyvm(string sOMpFETTVtcZXiOZ, int ZIIkgCoXExXcz, int rMwJuBeK, bool HDBkbbWHrnFVk, string NWekvxhYl);
    void XiyQyrLvpHoeyfT(bool ZfBlYQgpsIalbkg, double SvondjygFQNirLT);
    string QmsPaS(int xNlhMUeCwPkcWs, bool uxiHjN, double fGsgA);
    string OBTuntZVbg(bool oMLifSeEnGUIfp, bool mlprLNKuJmeySl, double zcrxDtnaFqa, string mSWZrXFKUX, double roFWDzKb);
protected:
    int kSYxH;
    double RoFdzXgzK;
    double oRIJsJwNKOn;
    double cwuXRPr;
    int Hrfymfx;
    bool aATmAhGNnGeADJ;

    void YIcZRe(double CfjnbgxPyccmanLJ, bool MqMcJCcygWikdAH, int gidrSmiIZMTqsrz, string RPIEqzUoWwZOKd, string utwlXZTjYXiKbsn);
    double YxjXDuIYPtRnk(int dOtWBgIfPHPxNcXX, double LOtFKqhkwdqEsSh, bool tbAKvSSMXv, double ndEgEaGoR, string VXNUtvtA);
    void nGeSRqNRmh(double wRDrLpYEBN, string UcZmMHWp, bool IoLrrhQOImQ);
private:
    double vlzlPDGS;
    double GuoDWgb;
    bool rmifAcaDckFPuT;
    int nSNATsH;
    bool avWknPBGTST;

    int lyqnAlkNRG(int wnhNUsWcIhGSnVC, double PWamClO, double bwNMjoS, double XDXkYrEhpXeniP);
    bool jQVsoyy();
    double xyIcfGf(string LFdhhCw, string TUrZeydQjuYKduGD);
    string YEfTTPoqX();
    void fzDwtrU(double dJyzVbeErIJ);
    double heOwkTXjQzCOKaBW(int GmazpkjZ, string UlvyLIkLX, double HyltVfANL, int CfdwNqnfgsFZ, int uXrHpVDtOyrVG);
    void upFqdu(double ktBtZuYrOLjUDplo, string JSiEmmlpAIOwUG, bool TXOfWgHd, double YnZLajfOCkcY, string NZQCTR);
};

string ghEtvcxV::abyvm(string sOMpFETTVtcZXiOZ, int ZIIkgCoXExXcz, int rMwJuBeK, bool HDBkbbWHrnFVk, string NWekvxhYl)
{
    double uoXRDIb = 1030346.9638656458;
    bool TvababcEU = true;
    string hWSzRKKsjh = string("OzmDSoQYaYHSmuViUhhdvtZpsSkKrYXSmkOZDUCehXIytoPfjaqnPWbOZSzeYLsIjNlJtnecfOJxbmJpfCIWMwWjwKQBnayYywvnyMFUWBeqWgzWUTuRgMHvcxneaNoeNFYAnwjextMucVbytXyNIlIazlaCevTIHYLcQVWKBPqDAWTrdLZlTvnIyxhsCgqHnGtqqLyMTeZkRQFObYcjEJxHXEBHwMlGBYywJxQmfEkpHjMGWenSzesZSUf");
    bool lDYusBf = false;
    int XEDeTqNPOTGpp = 1444174240;
    string vAADCFwHG = string("IvBtpVvpHpfWYezLiTsninRsMsUjmZtMPBnohrLmhrKubXYMHyuQYJjTOJXGXMVTKGMaWlKJuIJpRXWbHzbthYxDixUfvcLueXvWQYekw");
    bool vqnqXxBE = true;

    for (int vZHpsZrgw = 2073584492; vZHpsZrgw > 0; vZHpsZrgw--) {
        NWekvxhYl += sOMpFETTVtcZXiOZ;
    }

    if (rMwJuBeK == 1444174240) {
        for (int RhKkyvSSSzSnJ = 1927031525; RhKkyvSSSzSnJ > 0; RhKkyvSSSzSnJ--) {
            sOMpFETTVtcZXiOZ = hWSzRKKsjh;
            HDBkbbWHrnFVk = HDBkbbWHrnFVk;
            NWekvxhYl += hWSzRKKsjh;
        }
    }

    for (int oPYkYyd = 2135121657; oPYkYyd > 0; oPYkYyd--) {
        vqnqXxBE = lDYusBf;
    }

    return vAADCFwHG;
}

void ghEtvcxV::XiyQyrLvpHoeyfT(bool ZfBlYQgpsIalbkg, double SvondjygFQNirLT)
{
    int iXEVUpWIeT = -1508451194;
    bool fkKemrf = false;
    bool yskPKElGlpaQ = false;
}

string ghEtvcxV::QmsPaS(int xNlhMUeCwPkcWs, bool uxiHjN, double fGsgA)
{
    double dtdBjjsvpIzPfSR = 270175.54930777295;
    double isooFi = -304442.1680334267;
    double kjsKKuhyJqE = 187547.1802419681;
    string GhMEdERYs = string("quztDpHvAcfXWAKtwKSEDdpuIRQoErPosIoOUIaLGwvdYmbKgAydQDsNxAVePyOyAKhIWOwfspEPyBhLyoTokOydpbEngeXzcUUoiManPZpXNzDUlQMmQDeKVGxYU");
    int lgZnFZkMOJRycMVl = 1411960238;
    string mhUaJjioVYGF = string("JNBrAvIwvXNDncYdHPainpLmGTYMiTABLDmUbskIaanwKCjnBwnYbtSvfidxXrSMfTcrfBlvzDdCrMuXwxbRjeVxVo");

    if (dtdBjjsvpIzPfSR > 270175.54930777295) {
        for (int hUJPQesewYZ = 1557873358; hUJPQesewYZ > 0; hUJPQesewYZ--) {
            kjsKKuhyJqE *= fGsgA;
            dtdBjjsvpIzPfSR -= isooFi;
        }
    }

    if (fGsgA > 270175.54930777295) {
        for (int amWxh = 476260406; amWxh > 0; amWxh--) {
            continue;
        }
    }

    if (kjsKKuhyJqE > -796038.7886232462) {
        for (int gqyXRfKzGzK = 110855178; gqyXRfKzGzK > 0; gqyXRfKzGzK--) {
            dtdBjjsvpIzPfSR -= dtdBjjsvpIzPfSR;
        }
    }

    if (xNlhMUeCwPkcWs <= 734999432) {
        for (int XkWDY = 1346091194; XkWDY > 0; XkWDY--) {
            dtdBjjsvpIzPfSR += dtdBjjsvpIzPfSR;
            dtdBjjsvpIzPfSR -= dtdBjjsvpIzPfSR;
            kjsKKuhyJqE /= dtdBjjsvpIzPfSR;
        }
    }

    return mhUaJjioVYGF;
}

string ghEtvcxV::OBTuntZVbg(bool oMLifSeEnGUIfp, bool mlprLNKuJmeySl, double zcrxDtnaFqa, string mSWZrXFKUX, double roFWDzKb)
{
    double tajZeLdqtOOLrI = 882418.1605281904;

    for (int wSMDUKwEQfyHZhLy = 2103655749; wSMDUKwEQfyHZhLy > 0; wSMDUKwEQfyHZhLy--) {
        mSWZrXFKUX += mSWZrXFKUX;
        roFWDzKb *= zcrxDtnaFqa;
        oMLifSeEnGUIfp = ! oMLifSeEnGUIfp;
        oMLifSeEnGUIfp = ! oMLifSeEnGUIfp;
        roFWDzKb -= tajZeLdqtOOLrI;
        tajZeLdqtOOLrI /= tajZeLdqtOOLrI;
        tajZeLdqtOOLrI += tajZeLdqtOOLrI;
    }

    if (oMLifSeEnGUIfp != false) {
        for (int RgcDfR = 1252578167; RgcDfR > 0; RgcDfR--) {
            roFWDzKb += zcrxDtnaFqa;
            oMLifSeEnGUIfp = mlprLNKuJmeySl;
        }
    }

    if (roFWDzKb <= -898297.5245883736) {
        for (int fyxtike = 1364200196; fyxtike > 0; fyxtike--) {
            mlprLNKuJmeySl = mlprLNKuJmeySl;
            mlprLNKuJmeySl = ! mlprLNKuJmeySl;
        }
    }

    return mSWZrXFKUX;
}

void ghEtvcxV::YIcZRe(double CfjnbgxPyccmanLJ, bool MqMcJCcygWikdAH, int gidrSmiIZMTqsrz, string RPIEqzUoWwZOKd, string utwlXZTjYXiKbsn)
{
    double ojJscuclWYQkzDQ = 63827.70624067544;
    bool mFFsXFmvU = false;
    int rgukLnJyHKG = 1218530465;
    string VFnnsH = string("zujAbnkYuhWohKFBNgKfUrSnmjnaVzaCHCUepsGbYHQbpKzJqAVmvlYkoLBbHEHAggAugZeqlWvAjnaPDHZnPGwFjSvUSQVdiaFPkALbsiQkGQUZUbgdCDzLrizKKUzdCnZIlvPntjLKFEyaOcDYpcvwVQdEjZToVaolftTttgJTHjNLEuWdGdmSbzkRAXQVQYQTExvaaPCPDVRUwDb");

    for (int BVKJgxaFUU = 1053174864; BVKJgxaFUU > 0; BVKJgxaFUU--) {
        continue;
    }

    for (int FrIcfWcS = 585837401; FrIcfWcS > 0; FrIcfWcS--) {
        continue;
    }

    for (int zMULzuzWesTvaf = 2128659125; zMULzuzWesTvaf > 0; zMULzuzWesTvaf--) {
        continue;
    }
}

double ghEtvcxV::YxjXDuIYPtRnk(int dOtWBgIfPHPxNcXX, double LOtFKqhkwdqEsSh, bool tbAKvSSMXv, double ndEgEaGoR, string VXNUtvtA)
{
    string UvaZGfx = string("JqnJoIpYSvfVJhCqNhqsZVnqWVxwyUtCXOzb");
    bool SRcFRde = true;
    double dmEXHaozq = -866601.9465736395;
    int eXIRaFPETJDVHI = -553718976;
    double IhFGDUIBeTx = 962804.2577366044;
    double GQitlxQVnZFbqRM = 416626.7541955226;
    bool QjIuyeA = false;
    bool OqXjzbcOK = false;

    return GQitlxQVnZFbqRM;
}

void ghEtvcxV::nGeSRqNRmh(double wRDrLpYEBN, string UcZmMHWp, bool IoLrrhQOImQ)
{
    double VksxqfFYZKrwapK = 1016085.0417219055;
    bool ERpxNJZtO = true;
    double RfWkwxdUXSIWrbkW = -315124.6764190932;

    if (RfWkwxdUXSIWrbkW >= 1016085.0417219055) {
        for (int ccfzYujvvsiCGJDP = 711202000; ccfzYujvvsiCGJDP > 0; ccfzYujvvsiCGJDP--) {
            VksxqfFYZKrwapK /= wRDrLpYEBN;
            RfWkwxdUXSIWrbkW = wRDrLpYEBN;
        }
    }

    for (int BotvYXKTV = 1849277358; BotvYXKTV > 0; BotvYXKTV--) {
        VksxqfFYZKrwapK -= RfWkwxdUXSIWrbkW;
        RfWkwxdUXSIWrbkW += wRDrLpYEBN;
    }

    for (int ILWiRHkVGVnKYbJ = 1482974211; ILWiRHkVGVnKYbJ > 0; ILWiRHkVGVnKYbJ--) {
        RfWkwxdUXSIWrbkW /= wRDrLpYEBN;
        ERpxNJZtO = ERpxNJZtO;
        VksxqfFYZKrwapK /= wRDrLpYEBN;
        IoLrrhQOImQ = ! IoLrrhQOImQ;
        RfWkwxdUXSIWrbkW += RfWkwxdUXSIWrbkW;
    }

    for (int FCWLVMrMKUfTzs = 2098970437; FCWLVMrMKUfTzs > 0; FCWLVMrMKUfTzs--) {
        RfWkwxdUXSIWrbkW += VksxqfFYZKrwapK;
        RfWkwxdUXSIWrbkW *= wRDrLpYEBN;
        VksxqfFYZKrwapK += wRDrLpYEBN;
    }

    for (int HvDanbVzClVugx = 1061128239; HvDanbVzClVugx > 0; HvDanbVzClVugx--) {
        IoLrrhQOImQ = ! IoLrrhQOImQ;
    }
}

int ghEtvcxV::lyqnAlkNRG(int wnhNUsWcIhGSnVC, double PWamClO, double bwNMjoS, double XDXkYrEhpXeniP)
{
    int agkXnYZUyLGF = -417995344;
    int Lneos = 1906726672;
    int wwaOvxNPapwdWhTf = -1525122002;
    int VhKibPkQVLR = -27328240;
    double FYWlDAVgDTwNea = -217390.21583267904;
    int jWblePymrd = 1972084152;
    bool XawJO = false;

    for (int aMsRYWCf = 1091262880; aMsRYWCf > 0; aMsRYWCf--) {
        agkXnYZUyLGF *= wwaOvxNPapwdWhTf;
        VhKibPkQVLR /= jWblePymrd;
        Lneos = wwaOvxNPapwdWhTf;
    }

    if (wnhNUsWcIhGSnVC < -1525122002) {
        for (int usySnMSZnvoq = 76444498; usySnMSZnvoq > 0; usySnMSZnvoq--) {
            wwaOvxNPapwdWhTf = Lneos;
            VhKibPkQVLR *= agkXnYZUyLGF;
            Lneos -= VhKibPkQVLR;
        }
    }

    return jWblePymrd;
}

bool ghEtvcxV::jQVsoyy()
{
    string gPZXglzwhblqSp = string("StUtDLdolMfxMBECLZepRpDfixvamklkRBYTkRSABzeNhGxtWPdyqxGoaaNjUEiOdpXOwJEaPuSkPADVxduALMycXzDONENYKqNDugevQoelOromSaIGSHgCTsDgNzYiuuNZJBQcgBiQagKFvnvVylkIAVWqaISKyalkxqIvURJVBGNAeuieGbnVbctTqmOwEYVhasTBaidNciqWJzbNWjYvGLwtIj");
    double GkgfaMIqjvXRx = -501804.1878768417;
    int lYgMshJXIUlrFyM = 1619813794;
    bool kFZXINVgiGjsRge = false;
    bool GRnSZwdH = false;

    return GRnSZwdH;
}

double ghEtvcxV::xyIcfGf(string LFdhhCw, string TUrZeydQjuYKduGD)
{
    int nSmodQsyz = -413716219;
    int kgRElTxJFIV = 1862867931;
    double BjDSXfIkvqo = -535309.1600857162;
    bool xXeZHjIcfPa = false;
    string iWFosY = string("qUsgLTmHjajCHVgqAyrSQyqdOWtXzIchgpHYHtMwsOdQAUYibo");
    bool ftsIKeVzY = true;
    double MBkQJCezz = 313227.3451765131;

    return MBkQJCezz;
}

string ghEtvcxV::YEfTTPoqX()
{
    double QnjFzjFdkoMNYcmA = 338990.27292878;
    bool thzBB = true;
    int QWrcWePiUpf = -1394907103;

    for (int HzpXDIxhfBZ = 589099863; HzpXDIxhfBZ > 0; HzpXDIxhfBZ--) {
        thzBB = thzBB;
        QnjFzjFdkoMNYcmA = QnjFzjFdkoMNYcmA;
    }

    for (int aymNTHH = 363897001; aymNTHH > 0; aymNTHH--) {
        QWrcWePiUpf += QWrcWePiUpf;
        QWrcWePiUpf -= QWrcWePiUpf;
    }

    for (int rOkaRBTjSDJwT = 604802102; rOkaRBTjSDJwT > 0; rOkaRBTjSDJwT--) {
        QnjFzjFdkoMNYcmA /= QnjFzjFdkoMNYcmA;
    }

    for (int xCsTyeYNiwLOS = 1601783841; xCsTyeYNiwLOS > 0; xCsTyeYNiwLOS--) {
        QnjFzjFdkoMNYcmA -= QnjFzjFdkoMNYcmA;
    }

    return string("tbYlOvbuErZxlWKpVTGfGVTzUihOzVSaKXDVtaqdyMajxFhxuIZQiLaspjDPxRyfpMJULiANvnxvcOCchCZwxNqDnbJdOIFRsRSmxHuHcBwVHIpWXdREirsTsmorAJrqnAdwxNGqoHPhvuhaTKOmmrmHMkpzYYDUkDJsuwSBsQKxhAQwSVxjaoXGbfVjndnJCgoRdRTKMCCiJDXxjSw");
}

void ghEtvcxV::fzDwtrU(double dJyzVbeErIJ)
{
    int xtpnQtUgo = -995791996;
    bool KuSKwDyUHd = false;
    bool CZezFOCbuXAAnEr = false;
    int fQvTZp = -78082403;
    int VgKszgHRZXE = -102328871;
    bool zmmmCPJ = false;
    int yJkfTishajhlL = -1892378466;

    if (fQvTZp == -102328871) {
        for (int oskGETZBCyuffa = 694089084; oskGETZBCyuffa > 0; oskGETZBCyuffa--) {
            VgKszgHRZXE += xtpnQtUgo;
        }
    }

    for (int DXnSlMclgWYZsM = 664849212; DXnSlMclgWYZsM > 0; DXnSlMclgWYZsM--) {
        VgKszgHRZXE *= yJkfTishajhlL;
        xtpnQtUgo = fQvTZp;
        VgKszgHRZXE *= xtpnQtUgo;
    }
}

double ghEtvcxV::heOwkTXjQzCOKaBW(int GmazpkjZ, string UlvyLIkLX, double HyltVfANL, int CfdwNqnfgsFZ, int uXrHpVDtOyrVG)
{
    double BURgyQLNjD = -832013.799030851;
    double kKTwKWFY = -187390.97413785197;
    int nWfobXApRjvL = -1734835081;
    bool GUeRwawlGizrNk = false;
    bool ICsLqgwnykee = false;
    double QkzbWWvclxKMGjK = -207376.05118664572;
    bool yQhfXTOTB = false;
    int oIvThOuHFDA = -1957502904;
    string jBCwky = string("hgXKTrwXZJgVmVtOhHzQ");
    bool WrpQA = false;

    for (int sUlWAS = 1507907429; sUlWAS > 0; sUlWAS--) {
        kKTwKWFY = QkzbWWvclxKMGjK;
        oIvThOuHFDA += uXrHpVDtOyrVG;
        BURgyQLNjD = BURgyQLNjD;
        nWfobXApRjvL += uXrHpVDtOyrVG;
    }

    return QkzbWWvclxKMGjK;
}

void ghEtvcxV::upFqdu(double ktBtZuYrOLjUDplo, string JSiEmmlpAIOwUG, bool TXOfWgHd, double YnZLajfOCkcY, string NZQCTR)
{
    double ZJKZgXIlEVKOxUkn = -3132.0776908116;
    double cyNNLDqUkpYKQSAe = 308102.0364306342;
    int pCijrGfnICwe = -2013795757;
    bool xNvbll = false;
    string YnTNsygbA = string("qkFDgwqYUrugdeRWDioJkRdISHRqiECyfdASGOJnovotHRGJZdZpTgWhHNjGcNuBKLcIYZhrjxCcrcfhGgDmIViCjLODoURkFdxbysOMNkQdLRsShujLNziXrNrPamGfwmIisBeuqybtYRmRIulzGkHctGVJCxNRFlDMKzhhKFZRcsqJURBmnRRSwNutDigZSoBtWKOzXWrsOKDPxJSlHaRIdOFhPinYPSnubvuGEWPFvdcWbbNntUYtTGJ");
    int PljgSlTZliwLheEQ = -515325676;
    int mlLqniAT = -1112666497;
    double ivnLj = 916783.8347606095;

    for (int rLKEZRzhrvKMrg = 168214748; rLKEZRzhrvKMrg > 0; rLKEZRzhrvKMrg--) {
        continue;
    }

    for (int VZGsMbQL = 994582139; VZGsMbQL > 0; VZGsMbQL--) {
        continue;
    }

    for (int aukzoMtzdRg = 692317182; aukzoMtzdRg > 0; aukzoMtzdRg--) {
        JSiEmmlpAIOwUG += YnTNsygbA;
        mlLqniAT *= pCijrGfnICwe;
    }

    if (PljgSlTZliwLheEQ != -2013795757) {
        for (int YFDblXgT = 916326321; YFDblXgT > 0; YFDblXgT--) {
            ktBtZuYrOLjUDplo = YnZLajfOCkcY;
            pCijrGfnICwe = pCijrGfnICwe;
            pCijrGfnICwe -= PljgSlTZliwLheEQ;
        }
    }

    for (int NXcIaV = 1621744662; NXcIaV > 0; NXcIaV--) {
        continue;
    }

    for (int LWlbvXvFYlmdcc = 1595820927; LWlbvXvFYlmdcc > 0; LWlbvXvFYlmdcc--) {
        ZJKZgXIlEVKOxUkn /= ktBtZuYrOLjUDplo;
    }
}

ghEtvcxV::ghEtvcxV()
{
    this->abyvm(string("nQISFStT"), -2055274923, 1257332721, true, string("LoqRPDomaFqhKRXjiTNSQqDwiCgCtIwKhJwbvPmCoudLJPdrDiMECZmvxtObuULUSmUBahqpBcWebtrOjnDHkrjfwtIUNHZUHPMceADbhvmGZEPxawHYOWPeXyhbSckGKdKqTMcsesToeuVefKlVmTBOADZzEhQGQWWWZhYbllxyHJMGmtYAyburtaSGAlXPMESEEAHLLWLHvySGEVJVCDVlIRzyAWPxIWsNp"));
    this->XiyQyrLvpHoeyfT(true, 412768.04498945473);
    this->QmsPaS(734999432, true, -796038.7886232462);
    this->OBTuntZVbg(true, false, -898297.5245883736, string("grgNYxUVJJRMxKESRBCpMbhDiOBiyYrlmvvyazgbh"), -582084.7438658819);
    this->YIcZRe(118094.27364266117, false, -17096005, string("xHpblTNYQCsHlOSxfSJrfjgRsaERQHznOrWAdXeJJFQMcuAiZjVTbGBOCgPjWUdFGcnJKHJpmzIVoesWUhsudYbUTTIGFBFVOmXsrlYFvHtMJCZVRPXjLsmsDSLHvrDqXIUzmWzxXnHYMviNXPBzvZ"), string("NQlrtSZuEgvVzUkEsSFJapGpWiykqpPTxWERBVSLoKdJAVWgcceRSryeUnyMuVRVmAZcUyRPyoyztWDGUVubiSnjccQMPSBSIUxNeYOmHJnEYGwBwffrKyWPzlTkOcPqPKHfvIvrJjOMPvIwYLgQpyzPejYPjEemavSFTPmUpkjzultpKIQRROpVHFTxttLlTZiNKYDRjnikdKvCZluiRKrHfAjKrdPvOpxZJsyeyHcJXKLQwiJJUiYXZFXkNW"));
    this->YxjXDuIYPtRnk(659294187, -131700.75911398014, false, 666341.0627153843, string("ONqfzrlGgTssiNlJR"));
    this->nGeSRqNRmh(-879007.5640307534, string("RYTTydibNYejvUyTjPifVkCfLHHwcqwcqHqFnXwfCCsJnOxkQnbhtdBtIHCSWqftENTOMdQdgXRtxtIPQEUSlgDvcrkuWVxbTKijnJrZmVRRxLQoeJeWGtuUINNDdbhkCfKjThPWadcJrMGpUtlDMHjzwjbExNXpYNVljEKdgga"), true);
    this->lyqnAlkNRG(-547195595, -788007.9962310104, 536197.5050283809, 441161.15442711615);
    this->jQVsoyy();
    this->xyIcfGf(string("CobBIfeEirUorbNoEHBXPeonAbQyvQSILaBCxQoBFjeoguHfEopUYbLqzJjutjdMkypPJxkVhbwzjaTXHcDUkAWaWsvaAtpOgmLyIBzzBjIzQkYngDlWFOOQkzGfZLLyDsrWydeIOipBByHAMPwJGpXJaQNlCJYuODXxcVbTemXlClOSYXviaUjtdEwonfZNbpIMyPYODGEBMXorElUyjffpDu"), string("BqkuvAKkHzBrfpYJGujJMXdeIRjXoNhBpVvhnJAtpDgwDOEZASNJShYAVswMGtCvjZORVIkuUSusr"));
    this->YEfTTPoqX();
    this->fzDwtrU(-1031187.7228257706);
    this->heOwkTXjQzCOKaBW(-1094716690, string("CtxbqkXrXeiWaxLBBnVQjufwUmyqXFZmKcMitsmjdjIkyhCXnSiIjyAUXBJOmvdLLETCkpUfpMyFpvMLELNCwhTsuTPllTXlHLVXCMKpVctuGwapPUJGXOAJVySFpxtKPArAapAZPmseLfocxFFvXaVImNXMaFyEKokIbQGPZclkxqjjBJLbOlMXZQvsQJDmqcRAJWrPtpgNhsRSYleogHrPWVpPZgCLnBHgDBLwTgWFz"), -230024.3932177667, 311653771, -1731716963);
    this->upFqdu(223950.69666919118, string("JJagukFVcKYGtFdIrHICjLhAhoPlsJCAttYeiuwoczvUnCdxuWmuiDADIjedLcnVQavCCAzqWqpjpXFlsxQfGPHyAsEhSpJLcZDngfSvuEyuRRFTXDQXXLqJKK"), true, 37404.80599518765, string("jBVAcDkUGzAkqULbRBnHEmXJipjYOgAZhkhcXgvRdSOyZqyHjFSORLWbtOngttJSNFupDFkNCtDpottPVbYQNfNWLtZzhWeUgFlLyteBVRghQtNFnkZtmwHouGHtenIyLXWTMzvomkkEdqmIilVQGQffCEmOCdmXtOpMXnshrKPaYAYAcIEEjVoIorPJQkUbGzjxrBEMyzRbJSltVGLwDfOFrGvVFIVvqpRVTHkFvEnqXFhW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nAxYJkzSFHITda
{
public:
    bool hqBqnsHMjiyQIEyI;
    int fkSEl;
    string wiZqfCL;
    bool UUrsgFPjMPyJbb;

    nAxYJkzSFHITda();
    void sijmsCQV(bool QoWPLixHoxcNpXKE, bool KtZJwH);
    int QeSPIdCPm(int PWAEJLCacUuWS, double auxHnLUkaBVcGDeR);
    string kesYgLJgJudOAc(bool fqwbwSVNyYoTE, string XzBWPYwT, string fRMPIYsVgWh, double dhOyCxpjkxMFkxD, int tgRTLUlXcLRL);
    void zwcUPlnaYqOLKx(int vKdIxyanA);
    string qmvUFpKvmRbqtr(string VwRgiXn, int eBaTTasfS, string knJEIcKPanp, double mwpIVjmZNeEUMofb, string mIvsETFQqHnLuu);
protected:
    bool pqhSKb;

    bool EtvggrWrxvc(bool YgayMnzVBHxVf, string MIsyXGWg, int zSpZC, bool qnwfkaPjzC, int hYyhmP);
    string vJyiQKDOcgYAkr(bool FOeNJQ, string TnTUafBVeLkh, double QyOnsmTkSDWEWnM, bool IagbWLnklB);
    string dSYIYF(bool dmVKiHhOuCxmLDl, bool JKjbxk, int tbdPujTAW, string VVYgmllI, bool QgPcj);
    bool YkFnFmsZs(bool WjVYjuZogqIYX, double GYwBx, string GFaWMVMqyNVAxSJ);
    bool HEzeGL(bool gzyTQdDnkY, string ahGyJG, int aoEVDXJcjs, bool YGwgJj);
private:
    string sHxHahxvOBwyCejp;
    string qegjLsdH;
    double ktrOpCUcCh;
    bool RmoqHCdokWOOtbX;
    double AyQxdJMzu;

    string CJuSfIoPdWqj(double GOCWVIdZ, double YUyntbkgfg, string DBqEwQpzpne, bool VkxBLAW, int jlcmCOqCbM);
    double JsJmCTCQeaiOt(int aTqfyyVEiyfSfDwM, int ePUKogOaM);
    void YsjaVqtw();
    bool PzbnZrl();
    bool bbxUkVTtPmtXFvxE();
    string EskjebzFvfXdkSli(double lfKuos, string OsBggeCgWeRMxux);
    double AniUFE(int JANSNwmudGmP, string AxeRzfegu, int rpjGDFZLOqvJZ, double PfFaFnhC, string FWfsrGLA);
    bool FGGfTrpCfwoahn(string ETREcltWbdJhR, string KRSsJ, string bejroccJZtWCRCPR);
};

void nAxYJkzSFHITda::sijmsCQV(bool QoWPLixHoxcNpXKE, bool KtZJwH)
{
    int vPcXENJMQFx = 955041915;
    bool KrkCZbE = false;
    bool vYsqVgWkOMR = true;
    double UhodjtRdpZeiyj = -821863.1551412187;
    double rePAD = 528733.7239726402;
    string qAotWJsIJsmFqEKy = string("YiAHLGodagAwMxXPYrIvZOiIEGcTiwGrdPYrMNNGKCsAGNimTtoQjfUObRESFjKQgbTaYJAkzKczXuYzATuKTzIKvVcRBTjMempHvrGBrPcSfEMOsRrGlQLYjJIssQAzJUaoTVRFSvEcXYbDLWaLxwfRxtzODEHbWWXnkfZrIjvMFMduSncIKfctIMXeWOyPOv");
    int LxVsf = -431796188;

    for (int wFqQJQ = 1357220549; wFqQJQ > 0; wFqQJQ--) {
        KrkCZbE = ! KtZJwH;
    }

    for (int mpYiVBkPk = 565364109; mpYiVBkPk > 0; mpYiVBkPk--) {
        continue;
    }
}

int nAxYJkzSFHITda::QeSPIdCPm(int PWAEJLCacUuWS, double auxHnLUkaBVcGDeR)
{
    bool IhBEPDCDuVvb = false;
    string eWshLAWAOGTSw = string("rvEmslRbugpsIyDmEJhrnxQawLhXfQMpnGRpGJsDriNFVcEqevgcFFXfVrCeQRJARlIYFSchmeHTgkkwLOpDhWjRtCfuReOmoEXzGVhtTyhUrPayEEgDMkHNHxCbDgakqaN");
    bool YQdmvp = true;
    int XCriQ = 683548384;
    bool mftos = false;
    string ePJlsTAjZJkn = string("nZUgZnyQVdXVjQNmWLZZcAGtkCwUkfzWhryPIIcaYiRwKwLSkTbTIr");
    bool XHKGFHrA = false;
    bool ahOIXcXXivrF = true;

    if (eWshLAWAOGTSw < string("rvEmslRbugpsIyDmEJhrnxQawLhXfQMpnGRpGJsDriNFVcEqevgcFFXfVrCeQRJARlIYFSchmeHTgkkwLOpDhWjRtCfuReOmoEXzGVhtTyhUrPayEEgDMkHNHxCbDgakqaN")) {
        for (int XHWrsE = 853094277; XHWrsE > 0; XHWrsE--) {
            IhBEPDCDuVvb = IhBEPDCDuVvb;
            auxHnLUkaBVcGDeR *= auxHnLUkaBVcGDeR;
            mftos = IhBEPDCDuVvb;
            ePJlsTAjZJkn += eWshLAWAOGTSw;
        }
    }

    for (int uyMuZZcc = 294282034; uyMuZZcc > 0; uyMuZZcc--) {
        ahOIXcXXivrF = ahOIXcXXivrF;
        IhBEPDCDuVvb = YQdmvp;
        IhBEPDCDuVvb = ! IhBEPDCDuVvb;
        YQdmvp = ! ahOIXcXXivrF;
    }

    for (int PeVpbBbkCuR = 2142600555; PeVpbBbkCuR > 0; PeVpbBbkCuR--) {
        continue;
    }

    for (int QfCtOYPl = 1760956954; QfCtOYPl > 0; QfCtOYPl--) {
        ahOIXcXXivrF = ahOIXcXXivrF;
        auxHnLUkaBVcGDeR += auxHnLUkaBVcGDeR;
    }

    if (mftos != false) {
        for (int cZKtP = 1838905629; cZKtP > 0; cZKtP--) {
            continue;
        }
    }

    if (IhBEPDCDuVvb == true) {
        for (int otigjIIcRVHiDjk = 455952109; otigjIIcRVHiDjk > 0; otigjIIcRVHiDjk--) {
            XHKGFHrA = XHKGFHrA;
            PWAEJLCacUuWS += PWAEJLCacUuWS;
            mftos = ! ahOIXcXXivrF;
            ahOIXcXXivrF = YQdmvp;
        }
    }

    return XCriQ;
}

string nAxYJkzSFHITda::kesYgLJgJudOAc(bool fqwbwSVNyYoTE, string XzBWPYwT, string fRMPIYsVgWh, double dhOyCxpjkxMFkxD, int tgRTLUlXcLRL)
{
    string SvuZChCRrxjnfqEU = string("thhpDNNCvOFVHnlFmEYkIlqZWSrMipPAaagelZNTdHeSqLJNlXvTDnB");
    double KjJMtYmX = -392198.0715165506;
    bool wGZKILqGP = false;
    int krnWHPbPjfqDjFp = 1467899369;
    bool wHDZwLFdjT = true;

    for (int kMQlj = 1272434687; kMQlj > 0; kMQlj--) {
        wHDZwLFdjT = ! fqwbwSVNyYoTE;
        krnWHPbPjfqDjFp /= tgRTLUlXcLRL;
    }

    for (int wVvRRMUledvz = 513408224; wVvRRMUledvz > 0; wVvRRMUledvz--) {
        continue;
    }

    return SvuZChCRrxjnfqEU;
}

void nAxYJkzSFHITda::zwcUPlnaYqOLKx(int vKdIxyanA)
{
    bool ImwJfS = false;
    double hlfAwxBSOUGhLQR = -653947.2185289107;
    double HAZqYPmqUJYPlqnL = -41599.08440354352;

    if (HAZqYPmqUJYPlqnL > -41599.08440354352) {
        for (int oKEhlQZmUpGFD = 1776204705; oKEhlQZmUpGFD > 0; oKEhlQZmUpGFD--) {
            vKdIxyanA /= vKdIxyanA;
            HAZqYPmqUJYPlqnL /= HAZqYPmqUJYPlqnL;
        }
    }

    for (int YBvIdIast = 1753579762; YBvIdIast > 0; YBvIdIast--) {
        HAZqYPmqUJYPlqnL += hlfAwxBSOUGhLQR;
        hlfAwxBSOUGhLQR /= HAZqYPmqUJYPlqnL;
        vKdIxyanA -= vKdIxyanA;
    }
}

string nAxYJkzSFHITda::qmvUFpKvmRbqtr(string VwRgiXn, int eBaTTasfS, string knJEIcKPanp, double mwpIVjmZNeEUMofb, string mIvsETFQqHnLuu)
{
    bool XSyCjwlyjHaROFvv = false;
    double mBkHc = -245745.3372362497;
    bool EObAdKCixtU = true;
    bool ekLcXoDnQN = true;
    string ikpABHlopltBE = string("BhcJbjuBUGXtNneYAXnWIIAfcNjNzRxAfPvpphDhNlUJYQSbzrsZRLueuoLdotMkDtqVUIGebTl");

    if (ekLcXoDnQN != false) {
        for (int iejMxypty = 533299560; iejMxypty > 0; iejMxypty--) {
            mIvsETFQqHnLuu += mIvsETFQqHnLuu;
            mIvsETFQqHnLuu += mIvsETFQqHnLuu;
            knJEIcKPanp += mIvsETFQqHnLuu;
            ekLcXoDnQN = ! XSyCjwlyjHaROFvv;
        }
    }

    for (int ILFkrtxzE = 1169091373; ILFkrtxzE > 0; ILFkrtxzE--) {
        mBkHc = mBkHc;
        knJEIcKPanp = VwRgiXn;
        knJEIcKPanp = knJEIcKPanp;
    }

    for (int ZzLltxqifg = 724206710; ZzLltxqifg > 0; ZzLltxqifg--) {
        continue;
    }

    for (int QIcCaKaTntfLgp = 691517171; QIcCaKaTntfLgp > 0; QIcCaKaTntfLgp--) {
        mIvsETFQqHnLuu += mIvsETFQqHnLuu;
    }

    for (int flwpfiuEigcrO = 1392746109; flwpfiuEigcrO > 0; flwpfiuEigcrO--) {
        mIvsETFQqHnLuu += ikpABHlopltBE;
        mwpIVjmZNeEUMofb -= mBkHc;
        eBaTTasfS = eBaTTasfS;
    }

    for (int bvJTVRkXHih = 658958748; bvJTVRkXHih > 0; bvJTVRkXHih--) {
        ekLcXoDnQN = ! XSyCjwlyjHaROFvv;
        ikpABHlopltBE += VwRgiXn;
    }

    return ikpABHlopltBE;
}

bool nAxYJkzSFHITda::EtvggrWrxvc(bool YgayMnzVBHxVf, string MIsyXGWg, int zSpZC, bool qnwfkaPjzC, int hYyhmP)
{
    bool vVnRSskBOuKtg = true;

    for (int kiVqpKQnrd = 574659530; kiVqpKQnrd > 0; kiVqpKQnrd--) {
        vVnRSskBOuKtg = ! qnwfkaPjzC;
        zSpZC += zSpZC;
        MIsyXGWg = MIsyXGWg;
        qnwfkaPjzC = ! vVnRSskBOuKtg;
        hYyhmP *= zSpZC;
    }

    return vVnRSskBOuKtg;
}

string nAxYJkzSFHITda::vJyiQKDOcgYAkr(bool FOeNJQ, string TnTUafBVeLkh, double QyOnsmTkSDWEWnM, bool IagbWLnklB)
{
    bool PGNixxyUo = false;
    double JoExhkVUtvs = -207021.7512316961;
    int qjCrUSauq = 23889239;
    double TbexIRbjFGvPanAS = 833512.6044157251;
    bool mwbJXZjz = false;
    double ZEHRJqSjPtj = -308437.2507483417;
    string AlPvMPJjSpzHfk = string("pkOLlGXptRSNgkQDUjtlZCZqyEaAyixXBVUaxLPzwBbQDweuNsJKIeIItQFHkdePOsIZxMsDqixQNdFtqlseevZOpDTYCZiWAMAofckTghBoAxlcEHpwzGuEUErFpGykRMCjmEOrjTEetqcqSgGkYJCppidHChsIVAjszupwHSPESoEgcgXNaHbELXVVoUTHlnAyupsSlInONaEJIOHckvfMia");
    int cyetbQdLJl = 1751938886;

    for (int XoNsCVEsLhqXiT = 1197424658; XoNsCVEsLhqXiT > 0; XoNsCVEsLhqXiT--) {
        FOeNJQ = ! IagbWLnklB;
        JoExhkVUtvs += JoExhkVUtvs;
        QyOnsmTkSDWEWnM /= QyOnsmTkSDWEWnM;
        FOeNJQ = mwbJXZjz;
    }

    for (int KIfrnswdhUUqkUX = 1851169783; KIfrnswdhUUqkUX > 0; KIfrnswdhUUqkUX--) {
        JoExhkVUtvs /= TbexIRbjFGvPanAS;
        qjCrUSauq -= cyetbQdLJl;
    }

    for (int SmyhaOfim = 2080990900; SmyhaOfim > 0; SmyhaOfim--) {
        TbexIRbjFGvPanAS /= ZEHRJqSjPtj;
        QyOnsmTkSDWEWnM /= QyOnsmTkSDWEWnM;
    }

    for (int jfLPq = 582258787; jfLPq > 0; jfLPq--) {
        cyetbQdLJl *= qjCrUSauq;
    }

    for (int wxVmAffxsU = 61298063; wxVmAffxsU > 0; wxVmAffxsU--) {
        continue;
    }

    for (int thUlNbFzSvzKgp = 818590761; thUlNbFzSvzKgp > 0; thUlNbFzSvzKgp--) {
        continue;
    }

    for (int wPrhTEUJMQGZYff = 895431493; wPrhTEUJMQGZYff > 0; wPrhTEUJMQGZYff--) {
        mwbJXZjz = IagbWLnklB;
        TbexIRbjFGvPanAS += JoExhkVUtvs;
        QyOnsmTkSDWEWnM = ZEHRJqSjPtj;
    }

    return AlPvMPJjSpzHfk;
}

string nAxYJkzSFHITda::dSYIYF(bool dmVKiHhOuCxmLDl, bool JKjbxk, int tbdPujTAW, string VVYgmllI, bool QgPcj)
{
    bool OOXPIejmJ = false;
    double HNVEKjpKXHfx = -165886.1829209017;
    double KfeAzYbUNF = -934433.2904968385;
    string IPpuhqkUytqoNQi = string("rQnIntAqOAtQTpekLBjsowVBAephOIyufJxIRJhmMoXvwJioqPMrmQksIUBBlJdaiaZcJqbRwYlzAqVrsUwpkmHejQJJdRZVa");
    string hfmkwHjCRD = string("EHQxVpauxktSbIwJtzOfIqgrBrXWsLTQaohFMGqjklXEKpCzsZyvRtRLXRfPgmsMIleZCyRUvLaHBJbRJbqOgvyGXNGnrxQIozwrGEcyjivSmLejIavfWMJFTxkZPnidWKQkCRqxxnqGpHaGAWI");
    bool uRLDAA = false;
    double AMlAAPiZdLJGc = -808529.8082754279;
    string JoaxyebUKhQSsH = string("HowrqilzuEJeKMFRufGkILdTVTFpDCDlWAHzMZNFprpWfSDnWpYkrhRhpIRWYbdBkuMrMCtYozQNcQENETeXzEIOIBHpptRKuWRwgMfHZovTLLBbJmTaVxBmdjkTvwJBqqTHzKtpzkxOvNQrvBtLIXSdPkuzNSnDbAJckXjlgchnklriHVuTCztZvNPLXGhGOCPmDfTgvsslQuOGBNEvnGLGddklBiSknN");
    string vGDJKLrFZxJSt = string("buaFyTlUdVqYCatoPeSaxjtabTWblfrUxKZhNQsthOGvjFiNJMqaJXycHuhYpXTJzFTZuowgGtraFCmeidCEwdpuLzeaEWDOWkPzRFFaVDXqAYqVTpCxiPuAoahEcfELijPzJBevacInuRItYhVpKMKAbrAHCQrOwlSBEnSgAgBeAbiInornnvnkdCbTmfMnxkHWIkMFXVoapKidMQjdZGOAvKZJbRfMyuWlTkljMBlIMJpPnCDudwdaUaEv");

    for (int pVXKF = 39271333; pVXKF > 0; pVXKF--) {
        AMlAAPiZdLJGc -= AMlAAPiZdLJGc;
        OOXPIejmJ = dmVKiHhOuCxmLDl;
    }

    for (int VSUcxUpWepDXrAC = 1553599093; VSUcxUpWepDXrAC > 0; VSUcxUpWepDXrAC--) {
        continue;
    }

    for (int iYaHYIhFIDZ = 1686598294; iYaHYIhFIDZ > 0; iYaHYIhFIDZ--) {
        vGDJKLrFZxJSt += hfmkwHjCRD;
    }

    return vGDJKLrFZxJSt;
}

bool nAxYJkzSFHITda::YkFnFmsZs(bool WjVYjuZogqIYX, double GYwBx, string GFaWMVMqyNVAxSJ)
{
    string RvfgcaEgPvUxb = string("lzZRwOtirWwEljfOQgJjtESXrujiLKfKuNylPxMMcoWgmMwbBLlFSKVvQaJfSvmrMqtTFwRHmPdicIoWSQAYHkzCmXUqaoaBLAdWULsPBWjkoMrdcKLAddCIbcVyoOdlkdAVVjyIuQZSMOtNneiJMf");
    int LnnSAnvKmnWfburE = 1401803159;
    bool gEmsopbiDJi = true;
    string FjGSud = string("SfSzhVLFiLqjAvYTSvZrwTRKXuPsHgtmVDUSDF");
    bool nNuCR = false;

    for (int kBXrt = 1017976949; kBXrt > 0; kBXrt--) {
        continue;
    }

    for (int cymkKJ = 1320287057; cymkKJ > 0; cymkKJ--) {
        nNuCR = ! WjVYjuZogqIYX;
    }

    if (gEmsopbiDJi == false) {
        for (int kDUndsR = 300888259; kDUndsR > 0; kDUndsR--) {
            WjVYjuZogqIYX = nNuCR;
            nNuCR = gEmsopbiDJi;
        }
    }

    for (int iedpirzoNXWgvkcU = 1708522007; iedpirzoNXWgvkcU > 0; iedpirzoNXWgvkcU--) {
        FjGSud += GFaWMVMqyNVAxSJ;
        FjGSud = GFaWMVMqyNVAxSJ;
        WjVYjuZogqIYX = ! gEmsopbiDJi;
        GFaWMVMqyNVAxSJ = GFaWMVMqyNVAxSJ;
        nNuCR = nNuCR;
        RvfgcaEgPvUxb += GFaWMVMqyNVAxSJ;
        LnnSAnvKmnWfburE /= LnnSAnvKmnWfburE;
    }

    return nNuCR;
}

bool nAxYJkzSFHITda::HEzeGL(bool gzyTQdDnkY, string ahGyJG, int aoEVDXJcjs, bool YGwgJj)
{
    double tByxnFV = -45908.59599433168;
    bool UcyptcyK = false;
    double rNNyTs = 1022319.9689251104;
    double nvtzyYIYJMxCt = -445175.01397565636;
    double pVPpH = -122103.37718739253;

    for (int VTUmaVuyeg = 937446215; VTUmaVuyeg > 0; VTUmaVuyeg--) {
        rNNyTs = nvtzyYIYJMxCt;
        YGwgJj = YGwgJj;
    }

    return UcyptcyK;
}

string nAxYJkzSFHITda::CJuSfIoPdWqj(double GOCWVIdZ, double YUyntbkgfg, string DBqEwQpzpne, bool VkxBLAW, int jlcmCOqCbM)
{
    bool kOnLjjIr = true;
    double wEuTFRY = -207712.0971326322;
    int KyMUbZNlVwCapSCW = -1194192249;

    for (int EiYSVRhbCaVw = 2022038052; EiYSVRhbCaVw > 0; EiYSVRhbCaVw--) {
        DBqEwQpzpne = DBqEwQpzpne;
    }

    for (int pbXUBnDScLSS = 579942871; pbXUBnDScLSS > 0; pbXUBnDScLSS--) {
        YUyntbkgfg *= wEuTFRY;
    }

    for (int SQrZAZlTW = 738193806; SQrZAZlTW > 0; SQrZAZlTW--) {
        wEuTFRY -= GOCWVIdZ;
        GOCWVIdZ -= wEuTFRY;
    }

    for (int BdqkCdZ = 1371265975; BdqkCdZ > 0; BdqkCdZ--) {
        VkxBLAW = VkxBLAW;
    }

    return DBqEwQpzpne;
}

double nAxYJkzSFHITda::JsJmCTCQeaiOt(int aTqfyyVEiyfSfDwM, int ePUKogOaM)
{
    bool IKcXlMxmcvUmr = false;
    double zAElJrhhTegla = 306951.38159219566;
    double pYaMInQFvqYOpJbz = 939581.0138144128;
    bool SffywSKquGMvxwfa = false;
    string zmuufFYgD = string("agryHLWATcUxcnryZPWOmtVCJhHsBFihBeDLTqVlnRTvDduWGGldXzSTlDRyLkRKnEyn");
    double fLtjSQaiqtCLxQv = -7752.000168062827;
    bool wTwvClsqU = true;
    string ktOofpRGyB = string("wfuGmzNJScnWQTeacWlAavcgEXwLhOCdDNDdhRXTzDJrplurnrBJ");
    double GwtZsn = -51595.64109198286;
    double KjPRpcJwtOXV = -349764.4569575843;

    return KjPRpcJwtOXV;
}

void nAxYJkzSFHITda::YsjaVqtw()
{
    int aeEiDKLyklj = -1416891357;
    string LOTCmikOawv = string("AsgynvdBTepiYhaoJJbWQiXhjzOaUpudkpKmnRLExssztOtMWhHIJunqsSyeptXeAblpCfGxhhWRgEWhbXdFJQERfyZQbGajqXKnbEekHNpdHodGgSilgGvkrSUcjlLYWvMxpxTeGIOWQJHYqTKAmjhcwtipTKfFGafGDjPUzhRVYxx");
    string CHgBBRP = string("fXZbwKPXCVmByDuVLTWKbSpTfogBVbOodxUMifgHqVLXbvpHuFXLkfUBPjVpIgsuGKzfgiPuWWsZGQTjBtnDeZIgdFJzGZnJfQkerldgFrfHGFXhjzvhNpGInsbFPiHTXHztNZGTHZsLgDVwDNMXQjDPAcULSJelnEvBzOfMpXQtJSrTmyGWNkGvHjAngcSJMthPOiuEjSyRoyAmSFFxadfniuovgRxrXNsAuKSwNUzXmrvUxE");
    double rOEEkTHhl = 673013.824251327;
    double bBnaPlZZZQspQ = -189473.80980199232;
    string eoGShpYeKjZlQSn = string("GAKOdlAsFsqKMwmPpHGFKmuJmIQWAcJSGqryumBcMDSJmNmpdkgimYCpPtZzzDQRqouvoddPVGoMknDUPixeFFFJPnwTaLHIZcpzGNRMJpXVvhBAvrEQOnYRpNyttLigkLjgyyuewdsTsMcdaoUnpWhXzPgfjeAAcwlHWacJqBsNYMJsWmKxSxWrysZtpqCETogigGcgCzEJXrnpKsTWNRRPaBPDMoVirfFgzTdZBcSjYwYPf");

    if (rOEEkTHhl >= 673013.824251327) {
        for (int uhvmqeASd = 398138588; uhvmqeASd > 0; uhvmqeASd--) {
            LOTCmikOawv += CHgBBRP;
            bBnaPlZZZQspQ *= bBnaPlZZZQspQ;
        }
    }

    for (int maszddVKenVPI = 537334850; maszddVKenVPI > 0; maszddVKenVPI--) {
        bBnaPlZZZQspQ -= bBnaPlZZZQspQ;
    }

    for (int zAivxAo = 1169235512; zAivxAo > 0; zAivxAo--) {
        LOTCmikOawv = CHgBBRP;
    }

    for (int wOLibxcKodpuBH = 2017804861; wOLibxcKodpuBH > 0; wOLibxcKodpuBH--) {
        CHgBBRP = LOTCmikOawv;
        CHgBBRP = CHgBBRP;
        CHgBBRP += eoGShpYeKjZlQSn;
        bBnaPlZZZQspQ += rOEEkTHhl;
    }

    for (int HbaXgwsCNG = 2031552432; HbaXgwsCNG > 0; HbaXgwsCNG--) {
        rOEEkTHhl += bBnaPlZZZQspQ;
    }

    for (int AlBaGcUBtH = 1264029741; AlBaGcUBtH > 0; AlBaGcUBtH--) {
        LOTCmikOawv = LOTCmikOawv;
    }

    for (int ixOeUpxQftaatgM = 506034301; ixOeUpxQftaatgM > 0; ixOeUpxQftaatgM--) {
        rOEEkTHhl += bBnaPlZZZQspQ;
        eoGShpYeKjZlQSn = eoGShpYeKjZlQSn;
        eoGShpYeKjZlQSn += CHgBBRP;
    }
}

bool nAxYJkzSFHITda::PzbnZrl()
{
    string Yvuycdqd = string("uaxlcmDLwCtvUQofrJDUonsQqpgbJJndhkvwJhKCLxkKmevpquMPSHczMxnp");

    if (Yvuycdqd < string("uaxlcmDLwCtvUQofrJDUonsQqpgbJJndhkvwJhKCLxkKmevpquMPSHczMxnp")) {
        for (int bSNWM = 1882651445; bSNWM > 0; bSNWM--) {
            Yvuycdqd += Yvuycdqd;
            Yvuycdqd = Yvuycdqd;
            Yvuycdqd += Yvuycdqd;
            Yvuycdqd += Yvuycdqd;
            Yvuycdqd = Yvuycdqd;
            Yvuycdqd = Yvuycdqd;
            Yvuycdqd = Yvuycdqd;
            Yvuycdqd = Yvuycdqd;
        }
    }

    return false;
}

bool nAxYJkzSFHITda::bbxUkVTtPmtXFvxE()
{
    double clOVpHxMqtvCBW = 410920.11375928414;
    string yOzCQRuMbkZILuU = string("TLfSDHknjmAmqDRrQZszJcYExIZDvbAaSdmSvmLGiTdMVlRea");
    int VaEenAKIOe = -1263388423;
    bool rroJNqSp = true;
    bool LByItYyVecnjtnNj = true;
    bool xGoQHiPUry = false;
    int HBqLyZhpnRX = 1580693951;
    double sFhVepxAr = 241538.0445395032;
    int UsYdR = 1379783112;

    for (int HdXLSRrqROo = 1281289529; HdXLSRrqROo > 0; HdXLSRrqROo--) {
        continue;
    }

    for (int XOKuxSrMiLibhN = 1004857157; XOKuxSrMiLibhN > 0; XOKuxSrMiLibhN--) {
        continue;
    }

    if (UsYdR <= -1263388423) {
        for (int niIPfpt = 1597663367; niIPfpt > 0; niIPfpt--) {
            sFhVepxAr /= clOVpHxMqtvCBW;
            sFhVepxAr = sFhVepxAr;
        }
    }

    if (VaEenAKIOe > 1379783112) {
        for (int NNZnP = 454833600; NNZnP > 0; NNZnP--) {
            yOzCQRuMbkZILuU += yOzCQRuMbkZILuU;
            xGoQHiPUry = ! LByItYyVecnjtnNj;
        }
    }

    return xGoQHiPUry;
}

string nAxYJkzSFHITda::EskjebzFvfXdkSli(double lfKuos, string OsBggeCgWeRMxux)
{
    int VSyqYvp = 1891253451;
    double XyUYgmVE = -25660.438684182038;
    double WTjAXNwluW = -13781.081001616685;
    string TSkQfzR = string("QBMhnkJyQxKYpUOhfKfGWkmWHwMTBLtzwZFiiTbVqnPIksLxmGGjwV");
    double RFvFO = 674278.4138033588;

    for (int LSXhBaqtda = 1604770802; LSXhBaqtda > 0; LSXhBaqtda--) {
        VSyqYvp *= VSyqYvp;
    }

    for (int dDSMhdaCOJf = 267438739; dDSMhdaCOJf > 0; dDSMhdaCOJf--) {
        RFvFO -= XyUYgmVE;
    }

    if (lfKuos < -25660.438684182038) {
        for (int niyvX = 1428995137; niyvX > 0; niyvX--) {
            WTjAXNwluW /= WTjAXNwluW;
            WTjAXNwluW -= WTjAXNwluW;
            lfKuos /= XyUYgmVE;
            WTjAXNwluW -= RFvFO;
        }
    }

    for (int tWfnG = 1442952013; tWfnG > 0; tWfnG--) {
        WTjAXNwluW *= XyUYgmVE;
        TSkQfzR = TSkQfzR;
    }

    if (OsBggeCgWeRMxux != string("mpVrnSspgXsOXdMJtwGOWuSAYKEsghcnzDRuJeLmOPoYnMpgsHEazwuCeoaACPTEeNuYPxuzDZQAlzqdDltSRrblOUEIcsCDDIwQUFfPAeWqjYDyKdbSkUtQyJGfuqtaKYdK")) {
        for (int itPsNkJwyjTYEShc = 548620015; itPsNkJwyjTYEShc > 0; itPsNkJwyjTYEShc--) {
            lfKuos -= WTjAXNwluW;
            lfKuos = WTjAXNwluW;
            XyUYgmVE *= lfKuos;
            WTjAXNwluW *= WTjAXNwluW;
            lfKuos -= WTjAXNwluW;
        }
    }

    return TSkQfzR;
}

double nAxYJkzSFHITda::AniUFE(int JANSNwmudGmP, string AxeRzfegu, int rpjGDFZLOqvJZ, double PfFaFnhC, string FWfsrGLA)
{
    string dZLVJKNCViGMdm = string("HfzdRZGgtWEeppiDZKvhlHfVRODxEhrqMdpTXQcelqtpPAtDPMtoujseoU");
    bool EOHjxCVdhq = false;
    int vxDEOrNVqXUL = -504625836;
    bool TIYUVNEvDY = false;

    for (int buCOkAS = 2093986848; buCOkAS > 0; buCOkAS--) {
        AxeRzfegu += FWfsrGLA;
    }

    return PfFaFnhC;
}

bool nAxYJkzSFHITda::FGGfTrpCfwoahn(string ETREcltWbdJhR, string KRSsJ, string bejroccJZtWCRCPR)
{
    string QrIOKgJYbtfkNBAJ = string("qFyDlBbgFUZJShqXpJxBVVjwHMIioSsnnimckTJQgdoDQltvjypeGzwZWzqhOjKiIaoZlmBrGPPqmspSZRxnLBRqJxsaKuMgibxxnoTqSeYznAUzJUEQDWnTwBUXLUfbYDEvFKUoLheDnHOgTjrbdfPMNMqhdvejRIIIyOsAoSbeLsyGKDLEteIwbAFrhrBYZowrLIZOBoBqBpzWaiUGlpDToHBrpXTTigubvwjzMd");
    double tzTBuAdrXRRxpae = 502951.6098456612;

    if (bejroccJZtWCRCPR == string("XmjtIopXBtWttcqjQdbPQVCkQbsgHUWUYphDhPkayjibMYBsThusaAzHrhIsfKTNNCfyemzvugjgAFkpcPwzFPafgCTXRItgvzYDCWgLThUWbYzrBifENUuatqbiEXbtpzGFCkJtRFACMVUBHAKwELMAcqokhJeEnTQnWuMdPAuBAHeTigAKHgoMsDekmhvITlgRfcNPMkxBrxKidkWykVqwTBCEmnzTdodrWWduQNqInMXJuOznQ")) {
        for (int DFLkbMNXv = 1429775817; DFLkbMNXv > 0; DFLkbMNXv--) {
            ETREcltWbdJhR += KRSsJ;
            QrIOKgJYbtfkNBAJ = KRSsJ;
            ETREcltWbdJhR = ETREcltWbdJhR;
            ETREcltWbdJhR += bejroccJZtWCRCPR;
        }
    }

    if (QrIOKgJYbtfkNBAJ != string("uoMfnCuAqGEWIeNXibqXhEmsIAJIWSUdzhhgzuBnuACnhAzgUniHKFuKGZChhHnqcmDTBcLmFYCCHEXIqIPhxUBJsUResXwPlhXgnSXBOqCfJKvYKqlQqAcIpBOOQfXpYHYMjmsibjNZqaOwne")) {
        for (int fqdbBMaAc = 1532933534; fqdbBMaAc > 0; fqdbBMaAc--) {
            ETREcltWbdJhR = ETREcltWbdJhR;
            KRSsJ = ETREcltWbdJhR;
            tzTBuAdrXRRxpae += tzTBuAdrXRRxpae;
            KRSsJ += ETREcltWbdJhR;
        }
    }

    for (int TxySvvNatz = 517446236; TxySvvNatz > 0; TxySvvNatz--) {
        ETREcltWbdJhR += ETREcltWbdJhR;
        bejroccJZtWCRCPR += KRSsJ;
        KRSsJ += bejroccJZtWCRCPR;
    }

    return false;
}

nAxYJkzSFHITda::nAxYJkzSFHITda()
{
    this->sijmsCQV(false, false);
    this->QeSPIdCPm(-553044177, 845624.1018807698);
    this->kesYgLJgJudOAc(false, string("mXhAwHoyYdbLbwrsfHStrXKMzQzCSNeCTxPGFhZnUupLFhjtmWbPnYUcFgUTZBwjwyagjtIUaDhUYfEctAhXtIevddytEJFerRmQshIVdhbeLDWLzOfUslVwjceJGiHNvGkncYOXutDfqBjMoNBCiwclnPNQotxoJmyzJTnMXZkpUKxdvzQXgZwdZsadKKblg"), string("rpdLiwChgLHWFtJYGXQdIthkQqLfHxtupYPKXsAmkrVAUvpoomyiadvTgAqvehBnSPBKNaHcymCaYqdQOoxkyCzYWAUfSallSVyCgjqwHNUXV"), 858506.3062842647, -1396618885);
    this->zwcUPlnaYqOLKx(973084661);
    this->qmvUFpKvmRbqtr(string("hXIpRgnbUxGYCPbLxZXCJmbNBscfOtSIeInxYvrjOcUdSXztoWszwDWTKHMVnFgGZFtTnhcfRtkwMbbtfJRHAnOFJDKQNXXGtobMvwmMjWmgFhyGmibARHXfvtENQgaIBeSbbtjqYf"), -1178488989, string("e"), 855451.2237208232, string("ODocsEJUAVPeAOKCQTomZdhoKXjvOqmAmnqlpRpYZRyznZLnDsNjDovvliFgZCzZVhkyVCjYOBrEhBLkiKWouPXhJYTIUPmCjQejQPaYWfD"));
    this->EtvggrWrxvc(false, string("IYMLhvMBjnuWoLfjYoVjRrOIEOCVVuraFhBgNjikzYvzwGlQunSaoVibCyWzCswDISHuIRsOChSBNvjlveQWfpQzKJsGSgyAxMDTCWTlpPHGVJqpbpkUfzKeNDstsvAyfhiGwt"), -716710978, true, -401562543);
    this->vJyiQKDOcgYAkr(true, string("RLQGeoPdNEOVsgPHRpdQjfW"), -401757.37205725414, false);
    this->dSYIYF(false, false, 1299274144, string("IoZpHWkcqwdiBVMKGNRBOremVsvJaZtkvIxWocJLLyVSgbftJmVfhaBhbVXnLEhYjkqUZpQTitBUHLedItThCZIBQkvNGGahlkwjrggaEowNwoLHBJERezmrHlQXpHXwwxaqToTGflkOQuAQOkAERivCzCenMJMLCfblcYNSoDDCR"), true);
    this->YkFnFmsZs(false, -74756.09098073232, string("NCdzdLQMLODnFDZoYNzwDinfocL"));
    this->HEzeGL(false, string("meJjcdYvCIjYAMNgdiSFRdBGYwqypZAjhvrQyuULdlTamzZRYzfzpwupjtHGZGLarCgUTwBkMswkUGFstrVAwhhNETwYyqPhNOCaAnGbZBsjTqbRyOQRQEOXeetFowfdUMAeFYcogqZWYgZUSejTgEvIRIMupSNVyphUMbVStYofVGiugBF"), -973726416, false);
    this->CJuSfIoPdWqj(-262239.1591846325, -401562.7989824984, string("emUevdrPjXzucoJFXuFkRHJwZdSDKRaNLUKDZC"), true, -107810149);
    this->JsJmCTCQeaiOt(1553283045, 2097356661);
    this->YsjaVqtw();
    this->PzbnZrl();
    this->bbxUkVTtPmtXFvxE();
    this->EskjebzFvfXdkSli(173618.39886367932, string("mpVrnSspgXsOXdMJtwGOWuSAYKEsghcnzDRuJeLmOPoYnMpgsHEazwuCeoaACPTEeNuYPxuzDZQAlzqdDltSRrblOUEIcsCDDIwQUFfPAeWqjYDyKdbSkUtQyJGfuqtaKYdK"));
    this->AniUFE(-1521841128, string("vRxBOsQbbEwITfXMuXaOuf"), 1836395669, -266065.93761162553, string("lTdOSgvWpxzifFIUIJHyXdDWJfOlzRYJuEoTXjmuRSuEPtzpLVrjhXlQwjkwPcuiqqPdigzWaGAgdxUIezrttUlJOmrjsrjeESQjWCexCKXMphQwVydtXCuMyfKOydNvxwlydnrpBEQqFSqItDJHhjyBybSHpnbJagpwykRcjLohSQDVzDWOHQykaHkLWfSweRByrnWkYEfbOFVuzumwBiDTadXskCZxaZIabQCMVzPpCgoHZPNbc"));
    this->FGGfTrpCfwoahn(string("gGZcWlbEGeBaeDcnFeNJqWvRNfwMaCUHkSLMovMKLJzCXhOYyNMCWAjjuoAseBVUQHVifCQtdMXOWQRsDazWbAwEMZbARgJVBBMjHrGTFKcUFJkKKnTAZXvTxDohLeDcMYcYiknQurkclPmiwruFAYPeiZulfhsoOHrTlZiQuKjMdpaiWcvmqEPDvQXOWGfTwuWQJzMdbbjNtkupZNOqnjaFmBEGYwTjfnHBKiCXhRiMjieHCuysGUR"), string("uoMfnCuAqGEWIeNXibqXhEmsIAJIWSUdzhhgzuBnuACnhAzgUniHKFuKGZChhHnqcmDTBcLmFYCCHEXIqIPhxUBJsUResXwPlhXgnSXBOqCfJKvYKqlQqAcIpBOOQfXpYHYMjmsibjNZqaOwne"), string("XmjtIopXBtWttcqjQdbPQVCkQbsgHUWUYphDhPkayjibMYBsThusaAzHrhIsfKTNNCfyemzvugjgAFkpcPwzFPafgCTXRItgvzYDCWgLThUWbYzrBifENUuatqbiEXbtpzGFCkJtRFACMVUBHAKwELMAcqokhJeEnTQnWuMdPAuBAHeTigAKHgoMsDekmhvITlgRfcNPMkxBrxKidkWykVqwTBCEmnzTdodrWWduQNqInMXJuOznQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KgHcANPGtYA
{
public:
    string IzIrigbbtALJIktm;
    string EHHViUD;
    bool lBaROh;
    double VLDCkbxaBe;

    KgHcANPGtYA();
    int aghGxNQwQnhhvT();
    string okAuSpgRwSIJAMZp();
    void rQMGASPObXuv(double BlkwwLuPtgqdlw, int NNZaIRdSpB, int CWeCXxA);
    int fiFXYB(double GHanA);
    string GJjjhCdKjhvrJHC(int zhiTmIL, string YtNrXBXDquHQd, int DFwkSoO);
    string IvQkTmzeFIeCdAwl(double eJpCTIff, int AMdLIxJJ, bool evIWGau);
    void nhJjSDh(int MPwjxqMuSqALJp, double zzViy, string gwTJexuJ);
    double zoSLuidhLTWREQru(int IFCSlwQVHkvi, int zNTXsfindctTZYH);
protected:
    int NyNBsqrJ;
    bool CSkqVAdhgRBq;
    int krhCOAZhbqsUuf;
    double WTNpHvFVnkigGAa;
    double skUNA;

    int zYLzfufjvI();
private:
    double nxARBFNx;
    bool GrPhknTVJZqZqA;
    double SDRbvdrF;
    int uvDvzjB;

};

int KgHcANPGtYA::aghGxNQwQnhhvT()
{
    bool EFyZODnLTq = false;
    bool oFHCBIsFHtQyun = false;
    string GSnltcjLN = string("MoUzxsjPzhVWKUiSpaYIghSHEVQsMGLmaltEISELFQyOIsUmqQiMVEZnqlBZjZfVUtCdUBwyCBeVZILUmCDabtSiwZWejUKzRAPbIDSaiQcmxKUtExDXIczADYxSQFPePeHlcakHPBJXMjiCOADEpnFDjaHOwdhuvSkdCNhNzYelBmEfwzBD");
    bool HPQedlzVIFBuWX = true;
    int fjtvIB = -188288175;
    string WpKAKJTZPYbgxq = string("xosWVNpuRpforCwrWCuHmXT");
    double tmdGBblQyA = -838793.6194482727;
    double ytnuJUnCl = -43044.977036813085;
    int rMHEL = -729729762;

    for (int sMbgUuFwaFVGQTqz = 1975844895; sMbgUuFwaFVGQTqz > 0; sMbgUuFwaFVGQTqz--) {
        continue;
    }

    if (tmdGBblQyA < -43044.977036813085) {
        for (int BxcrUIwdCnmJX = 128099092; BxcrUIwdCnmJX > 0; BxcrUIwdCnmJX--) {
            oFHCBIsFHtQyun = EFyZODnLTq;
        }
    }

    return rMHEL;
}

string KgHcANPGtYA::okAuSpgRwSIJAMZp()
{
    string QIkfKZWVddtXyejV = string("lmiuPOxsUFRubgvWVfwmOLnVAmEarZgaiIGlnDekZbTqWMcbEGlRdvZtROTHdQfWnjxTPKBcypJbWPeBXoOTOsuIhcjvdRupEiDjdVixsFufEplHQmHNxlHWDEeCbdmqatzXNlVoLhPIIWDAQqMVviNAeUFUbHVWnmItPClNSKRPddFWzzrWcMYKLaveJqaPwWXalWkBdPYtdBZCqfDuvHueXJxQVChMlPsw");
    bool inWCfXlR = true;
    bool LVeJsN = true;
    int MTfSlN = -989340722;
    double wYFpKpNFZBwaa = 468419.39933660347;
    double PdcJBtZq = 121909.42515997373;

    for (int emJmqDdO = 48748188; emJmqDdO > 0; emJmqDdO--) {
        continue;
    }

    if (PdcJBtZq < 121909.42515997373) {
        for (int GVQWeMEM = 964470181; GVQWeMEM > 0; GVQWeMEM--) {
            continue;
        }
    }

    return QIkfKZWVddtXyejV;
}

void KgHcANPGtYA::rQMGASPObXuv(double BlkwwLuPtgqdlw, int NNZaIRdSpB, int CWeCXxA)
{
    bool NFFxndKYOWl = false;
    int IYExGwcYYqyULZA = 814236318;
    bool kfODygwKcaiQY = false;
}

int KgHcANPGtYA::fiFXYB(double GHanA)
{
    string bxGfbLnReJZFA = string("YtVxcKhDBdiglFzwjbWnpZqIKXGyTuehVbRIlyMbEbJTrlvKgIJTsBlPhUvebICwrkiWLPbktAAVyMWeRAKStFeZnPIdaJJBgiOBiZnQGLPSicYoBpmeEdXRMOmjzEBOEmVmMVhMofaiOHQwhsznRDspfcLAzGhDJuKpfHphTYZcPlpbsSZWuoZuJrPEujfgUIOkKrFTFVoTGGEYfXYzBsqdHZOOeyhtXHdKGPIgLoGfZSLUKjxWPfV");
    bool QHxMgXgulSNcBs = true;
    bool kSyMDqfuXqv = false;

    if (QHxMgXgulSNcBs != true) {
        for (int FjBEsVHeZ = 2073631097; FjBEsVHeZ > 0; FjBEsVHeZ--) {
            QHxMgXgulSNcBs = ! QHxMgXgulSNcBs;
            GHanA -= GHanA;
            bxGfbLnReJZFA += bxGfbLnReJZFA;
            bxGfbLnReJZFA = bxGfbLnReJZFA;
            QHxMgXgulSNcBs = ! QHxMgXgulSNcBs;
        }
    }

    for (int denTfjO = 2128868654; denTfjO > 0; denTfjO--) {
        continue;
    }

    for (int CIgtXmhJu = 1118418037; CIgtXmhJu > 0; CIgtXmhJu--) {
        kSyMDqfuXqv = QHxMgXgulSNcBs;
        QHxMgXgulSNcBs = kSyMDqfuXqv;
    }

    if (QHxMgXgulSNcBs == false) {
        for (int nOjxG = 1514627632; nOjxG > 0; nOjxG--) {
            bxGfbLnReJZFA += bxGfbLnReJZFA;
            GHanA /= GHanA;
        }
    }

    for (int onffdQ = 1478184042; onffdQ > 0; onffdQ--) {
        continue;
    }

    if (QHxMgXgulSNcBs != true) {
        for (int SoLyh = 77461215; SoLyh > 0; SoLyh--) {
            kSyMDqfuXqv = ! QHxMgXgulSNcBs;
        }
    }

    return -1602513747;
}

string KgHcANPGtYA::GJjjhCdKjhvrJHC(int zhiTmIL, string YtNrXBXDquHQd, int DFwkSoO)
{
    bool cUNzcktICXAwr = false;
    bool qOJxH = true;
    bool cYqLGMtZ = true;
    string ilTfs = string("hpWVyJVoOYQdNNWYUOVemejfaIsmhJtbRGtINYgfbZQudXkrcVdcbPXhItlYukwLSPh");
    bool ahsfEy = true;
    double kfwazkAbRogNsjqH = 347786.4679014244;

    for (int dKVMnQt = 327171240; dKVMnQt > 0; dKVMnQt--) {
        YtNrXBXDquHQd = YtNrXBXDquHQd;
        ahsfEy = cYqLGMtZ;
    }

    if (cUNzcktICXAwr == true) {
        for (int pOJkuxcN = 1115654294; pOJkuxcN > 0; pOJkuxcN--) {
            continue;
        }
    }

    for (int Oyfkq = 357275885; Oyfkq > 0; Oyfkq--) {
        continue;
    }

    if (cUNzcktICXAwr != true) {
        for (int igMweTRCN = 1813085428; igMweTRCN > 0; igMweTRCN--) {
            ilTfs += YtNrXBXDquHQd;
            YtNrXBXDquHQd += YtNrXBXDquHQd;
            ahsfEy = ! ahsfEy;
        }
    }

    return ilTfs;
}

string KgHcANPGtYA::IvQkTmzeFIeCdAwl(double eJpCTIff, int AMdLIxJJ, bool evIWGau)
{
    int UrAeCZYWsAHuf = 303143196;
    string blmjGBiJsmMZmAA = string("rEUQtyhCQClCAOpjYjYOtzTHMEPHnrVQLgrUrBywfFBIUneNIteRuDSfQKBHSIXgXyWqWefxqFNtxL");
    string XePdSoOcbpHHV = string("lJBjNYHgDBGdIquLsDqeAVVqfvvjvhjNmOTOjdwpMnBCaRpzliDYKzZrOmDaHxZhJZSxAQqIOnkGkgxxTPUOBJxwvyhHRhKrhoXxnszuHmOqRzyEyUgWzSxmYBupERhomyolN");
    string YASZakPvUkQVRHmq = string("iysDLV");
    int naphL = 57809244;
    string pVNPVCEpHiDLARu = string("wZEOdiYrnsOTFOCmgZvxesfYsiXkTHElZlMTrrCDCWoxMUAmZYkYFwcerWBJhtQGUqDcZCTrWvrxvrkSgCmEmpfvgMkGBOzaAlATwhUgwmHLKwfopBbZglCdbCmhGmbztZgCHMUJfeHhsFpCpaYAtVEjWixRZaztEFzwzpHFheLsRSuhzFzvpZhZqgoACleVFhXdsApOIz");

    if (XePdSoOcbpHHV != string("wZEOdiYrnsOTFOCmgZvxesfYsiXkTHElZlMTrrCDCWoxMUAmZYkYFwcerWBJhtQGUqDcZCTrWvrxvrkSgCmEmpfvgMkGBOzaAlATwhUgwmHLKwfopBbZglCdbCmhGmbztZgCHMUJfeHhsFpCpaYAtVEjWixRZaztEFzwzpHFheLsRSuhzFzvpZhZqgoACleVFhXdsApOIz")) {
        for (int FxHsnlleDZYyskOe = 304816073; FxHsnlleDZYyskOe > 0; FxHsnlleDZYyskOe--) {
            pVNPVCEpHiDLARu = YASZakPvUkQVRHmq;
            UrAeCZYWsAHuf /= UrAeCZYWsAHuf;
            blmjGBiJsmMZmAA += blmjGBiJsmMZmAA;
            YASZakPvUkQVRHmq += blmjGBiJsmMZmAA;
            pVNPVCEpHiDLARu = YASZakPvUkQVRHmq;
        }
    }

    if (pVNPVCEpHiDLARu < string("wZEOdiYrnsOTFOCmgZvxesfYsiXkTHElZlMTrrCDCWoxMUAmZYkYFwcerWBJhtQGUqDcZCTrWvrxvrkSgCmEmpfvgMkGBOzaAlATwhUgwmHLKwfopBbZglCdbCmhGmbztZgCHMUJfeHhsFpCpaYAtVEjWixRZaztEFzwzpHFheLsRSuhzFzvpZhZqgoACleVFhXdsApOIz")) {
        for (int OdbJLAfjy = 1115907960; OdbJLAfjy > 0; OdbJLAfjy--) {
            continue;
        }
    }

    if (blmjGBiJsmMZmAA == string("lJBjNYHgDBGdIquLsDqeAVVqfvvjvhjNmOTOjdwpMnBCaRpzliDYKzZrOmDaHxZhJZSxAQqIOnkGkgxxTPUOBJxwvyhHRhKrhoXxnszuHmOqRzyEyUgWzSxmYBupERhomyolN")) {
        for (int UUHsoOiBOlUElW = 904813713; UUHsoOiBOlUElW > 0; UUHsoOiBOlUElW--) {
            continue;
        }
    }

    for (int vPRTXhzjRhMTAEX = 736651746; vPRTXhzjRhMTAEX > 0; vPRTXhzjRhMTAEX--) {
        continue;
    }

    for (int XPDPJACSbfKyY = 561125771; XPDPJACSbfKyY > 0; XPDPJACSbfKyY--) {
        naphL -= UrAeCZYWsAHuf;
        evIWGau = evIWGau;
    }

    return pVNPVCEpHiDLARu;
}

void KgHcANPGtYA::nhJjSDh(int MPwjxqMuSqALJp, double zzViy, string gwTJexuJ)
{
    bool domVQFwe = true;
    double QZpqqcVysHe = -941313.8627103881;
    double NJqYQYyEV = -281389.6869693819;
    string feGLhVzdWxxD = string("acPEhmEZDXaGUNkcTUwVApkbLyNktYHRTbbQOsMnlnZjAkkDgfkTEFEqVryzHAAcvIzKosBSaSahJIoADmBKBNFlxAuOHLyYzCfIuqOMqlUG");
    int IPwoqwzfQtbxmDp = -2033727114;
    int JkbYeIUXSXEoNX = 2080448091;

    for (int ggSuNuKHmRWQU = 437835418; ggSuNuKHmRWQU > 0; ggSuNuKHmRWQU--) {
        JkbYeIUXSXEoNX = IPwoqwzfQtbxmDp;
    }
}

double KgHcANPGtYA::zoSLuidhLTWREQru(int IFCSlwQVHkvi, int zNTXsfindctTZYH)
{
    string SYhtWVQO = string("LNqHupNfdIDzkjUnFUYuCFwKryBgIlbWCSUZOvqlljYaKzWgpwfaInznBVZCCzEkwifhkaOsOfEsfggMXGzOFMGTlYDXqhusLXgveEFbIFvXvdWoqhrDWRhnlwtcXRKmBZsAJn");
    string ZbaMjpn = string("NcnKPTPjVUPVzqWZfMpmcGgNfMTgPVAeMKpTSFaWceRIOnllllfQzFoPvPNAnOlnruCymwUmsxkYqjDGqYkVMFaeJiUNFHOzFSyZbVCwpADdHGnARaPXAAMwVPLJDzHUNhaoeDUengFxwiMgWtBcFeZgMdWxzSEnhoYqrvXOVRolaGWdKHJNkPAYEmtypugXcPFZfpjoISNRJdqfICDuuJQmDfJcMFebXvZHVcsxRqRVwkWIgIFkqq");
    int VAEhi = -1148073587;
    string xdjRrAAW = string("bahTkZNNuVsEymZTmDjiwcqDkIHZfOoJiDGwCSLViqjXzYitJRvYEEHELrklXBMBwZJUOvqwgNDROIKFEIefTRwpCdXU");
    double vJiYltKE = 375950.68913845293;
    string lfbJcfJhBYR = string("cDmMdXEzxINMdeuGkAlYYBKaxlYLZvUeQMsOMOYLDgADkhPUcUpkCzBoIHXFkhkJHpsxgAtllBmMcidumgHtoVIrQsKWpeTSaREKovgmZAnWRTAeOTaPCKyivlXLeourBVNIcPdoPTQrauVUMgdfckiJugqddvpjapttAeOZGvCJrazGmLseLGvfcOdxznbySKLuXBYMdzdFIxestvUqnTLaXCkkKecMRIJkTnLXnmYGXreffBmsux");

    for (int VOzmPwqE = 474664857; VOzmPwqE > 0; VOzmPwqE--) {
        continue;
    }

    for (int AfdEQQgfWIC = 363317839; AfdEQQgfWIC > 0; AfdEQQgfWIC--) {
        zNTXsfindctTZYH /= VAEhi;
        ZbaMjpn = SYhtWVQO;
        VAEhi = VAEhi;
    }

    return vJiYltKE;
}

int KgHcANPGtYA::zYLzfufjvI()
{
    string hFNBYvDApKmoKq = string("QfBdXleOcAYCoDVoldSNYWECPCeqvSdcixsKEDpnGoPLjJzxtulDGEVBxOVfThyjgXzNpfiDmQUWaOckxGOGXHGtvtTrvdQPyIkdmGLZXtDRGBOkWuaYFLQKTBFKPbVVYvaAkkjNUAkmLgGxUhgKevejWHwOaggpdAqwQDuNTxTJKHuAZiO");
    string ggyaRbOub = string("LQHfMGVMsbsAJYotRibmGrYnCGPilpaGhayIxYGmEPBgbPJvtRhYcdXOzwDHbjPrGOIgNnwwLuTFsdOjtGgrgSslTuERrkHNcRszNidIlcNLPlWXpvzguoHXzLINUKByQYOUoWdwwZJzUcFSLCfvgbWk");
    double oHmVzNQAWyAmEuS = 759608.8833221636;
    bool WYbAqST = false;
    string nDCKxSxlYPuSWk = string("erPPdEallWyQZQUuIuLFvEAkejYXUiBdcZxcSwMHAYIfDKbiFFfpwpZBeBtXPdnwCJhEtxwmGweCsXUSwAvUaRvOMEcPdaNEhifpAuGRXbuXrlAouyiyAaczelfBsNYqPQhXhZwQWAzaoqvjijnEQdCrYgWYLVEqUkuHqoUfhu");
    bool ztCfbgrxeFUj = false;
    string FSsREEFTvYr = string("VpgvkwKfqWEyxTUCabwyniIEtBREeGepCqDxRDnwpyaafOVoUDFvZTCTZiPwZjWYszwintfWZkxgjDjUtvoezKfYibMNeUuCKlPkfodLGhLUbWvtDZdQvZfHpqHAKTChvtcVhKRgpcIACylIuOFhVjBUBqkTdaBjibTcauTgRRmhpbIROteboHHthMcahAUeIGyGKVbJRzUXxKrw");
    int veKnYdXsDwfxdtMD = 657780445;
    bool eHIWIcKjy = true;
    string OmSGfng = string("ncreAYOtbFBaOJAfpjGvlOZANqkEzYyBHLhyBtWbFaoKXrqIqHUdGMfgVeWGtJGACYtxlQLoqESnjxjqCYtBIyxFkEeIgQNffvcTOOmNxBnpsAruzuzPHzcRRWXMeFQiCjjHTiaFOHezyLEjKDFgPJqKnPLheqxCWzzeNZLeOzzSuguXxgYISynFKFBGoICDPtQXprOOLSXfmVLBrAE");

    for (int jmkvQJSVPb = 887389574; jmkvQJSVPb > 0; jmkvQJSVPb--) {
        ggyaRbOub += ggyaRbOub;
        nDCKxSxlYPuSWk += nDCKxSxlYPuSWk;
        eHIWIcKjy = ! eHIWIcKjy;
        ztCfbgrxeFUj = ! ztCfbgrxeFUj;
        OmSGfng += nDCKxSxlYPuSWk;
    }

    for (int jfazFOohDw = 1754849840; jfazFOohDw > 0; jfazFOohDw--) {
        eHIWIcKjy = WYbAqST;
        hFNBYvDApKmoKq += hFNBYvDApKmoKq;
        nDCKxSxlYPuSWk += hFNBYvDApKmoKq;
    }

    if (nDCKxSxlYPuSWk <= string("ncreAYOtbFBaOJAfpjGvlOZANqkEzYyBHLhyBtWbFaoKXrqIqHUdGMfgVeWGtJGACYtxlQLoqESnjxjqCYtBIyxFkEeIgQNffvcTOOmNxBnpsAruzuzPHzcRRWXMeFQiCjjHTiaFOHezyLEjKDFgPJqKnPLheqxCWzzeNZLeOzzSuguXxgYISynFKFBGoICDPtQXprOOLSXfmVLBrAE")) {
        for (int YXvdSB = 2012021374; YXvdSB > 0; YXvdSB--) {
            nDCKxSxlYPuSWk = nDCKxSxlYPuSWk;
        }
    }

    for (int LhAPmrXJf = 616444040; LhAPmrXJf > 0; LhAPmrXJf--) {
        continue;
    }

    if (ztCfbgrxeFUj == false) {
        for (int fTfWKWcoDuvartO = 2139789975; fTfWKWcoDuvartO > 0; fTfWKWcoDuvartO--) {
            nDCKxSxlYPuSWk += ggyaRbOub;
            oHmVzNQAWyAmEuS += oHmVzNQAWyAmEuS;
        }
    }

    return veKnYdXsDwfxdtMD;
}

KgHcANPGtYA::KgHcANPGtYA()
{
    this->aghGxNQwQnhhvT();
    this->okAuSpgRwSIJAMZp();
    this->rQMGASPObXuv(-383217.1994389447, 1470353473, -709755675);
    this->fiFXYB(-396996.9973665995);
    this->GJjjhCdKjhvrJHC(793607364, string("prgEUEenURilVZGpZKQadKhFpyWaBbGdGSvbkoCdIHVVSSTohigFjzuczWeymzfjosOvaUiWDOQBpVnAyTfdxjUkdgaACthhlySJdpEFDioFzyADHFDNxKULWdDWzTLxImHCGNNAtWMaGpWCoalMAJJUBZXdQMEOvhytZfZXvOsc"), 1052929329);
    this->IvQkTmzeFIeCdAwl(595771.0915168383, -1990914126, false);
    this->nhJjSDh(-2105888698, -971746.1390950665, string("SWsVHaKEqrSmFicTzuEVyatlkidIDxlXJstVGSAPyCJBvcrXUfDnWopONayQUtXkUxQIkHTrXPlGyxfKrWPFCIgdZXakZGTGwFazmatSxGTTQdXbTxYpmnrHloaEUmWcZVQRcSuvRwfQxRMnhMleQiqQdsvINGnAhcbiMhXwPyliTZRmbxQxxVDBNSwxLWKauANsUKYNdGmMALmzZrjJ"));
    this->zoSLuidhLTWREQru(179752323, -1043982951);
    this->zYLzfufjvI();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yqiFF
{
public:
    double TEumPa;
    bool hQMaaGbghrqig;

    yqiFF();
    void sMOHlcTpaQMWbb(string vUavAl, bool HiEIxgry, bool slOicZf, int XjRdPG, int HgxFzHfSXpRAKUN);
    void rjvSGPtRNHyWQa(double WULKVFq);
    double RusDhXL(string yZmQSZMQWWbgKT, int uTOsORWKxzy, bool wViAXjxpHyRZl, double hAIEUpSXt, double covuXZcmDwOqZNV);
protected:
    int SasQKEaP;

    double WuetYwtQCiZ();
    double pfIqQLoJnZ(int uEVcQMGZ, string krvEgCCxRqXcuO, int zOqiADosudIW, double zIoihOiamBlPW);
    double qtAYwljAuZ(int nqPzVUgSLIoGJN, double AcZjIfrbDXYWpV);
    double tlDyNPBrUWsS(int ZxuWrF);
    string NDuSNfJdZYfQzI();
private:
    double NGiovAZvXAb;
    string LjXazKZObGrh;
    int GQwwRpoyWhS;
    double XGqlolQVmSt;

};

void yqiFF::sMOHlcTpaQMWbb(string vUavAl, bool HiEIxgry, bool slOicZf, int XjRdPG, int HgxFzHfSXpRAKUN)
{
    int JIcgcROTSvkvCCT = 570249772;
    string bCIsh = string("tDgKZEYJGarwVdIKmeJqqKKojCMXEfNsDanEPBCEQlkzQDKULCerKesasZqEUWsXFgctWfYiVKjodHQuBGenZgxDvYZbqOzzxWudXfOaxNjagQjwPsEtxPKgnDrgoUuWnYgNbnZvCUmsQSoTItpjUeYslehnrzCqXvcHYAkiWySyHuwzLXdrpyx");
    bool rOaCmTdqQRVi = true;
    double FnztFiuyFZPdduUK = 73307.80271549897;
    int iCERdVFQcwqzuk = 707285139;
    string lUyim = string("USyPxWpnBacjAaKzDYGJIaqKctYxcnrMvAUCQiNwVpLCZYSAHbSxvrFUqFxHCogvfLHTksCxIHJQYezhwgJYUaJOxtlWswerKEqwftJogDpRNpHAnFCuPeTKkJpiHZjRqQmJlEXFOTeVXVuugQeNJmauzpzGMzbJLzBoFFKDulDCGPhKTtjotBvhNuZrfOmRGAIDcErKnJRPjJefrGyxbNLFGLPROUvGSAIlOOSxdFKd");
    double wMlQSzqOIyI = -399337.3831581898;
    double ingkHNLrEdQQJroq = -660442.1151932948;
    string lFxoVxIZAQJo = string("zMekWibpkEznDIsZNKZEqSywgVTmFdPxjDovHoFqpoRkakIHpjErkrcTeLzHhvwHzZqzWClCEfWrKrCGHwpDVpVGYnUFqwbxIFyNCbtpxhnDwReZoodUuMEOuKfHlzqgNtKMdpNyaBGXhooXtbpoJZhtnymTTnugnlAJLoqPcDEeNyqBUuxSGpvBATCYKIshGhXgPpbFC");
    string MqrQAg = string("aPgKQSHuYySzctBaYHopyykNhifRTtBxWkyoDGyhVIpXLoiYjBxNrqIbHZwcQqtevjbCYtTaB");

    for (int qDmyvSq = 1099337306; qDmyvSq > 0; qDmyvSq--) {
        lUyim = MqrQAg;
    }

    for (int QoDZCRLV = 1655045752; QoDZCRLV > 0; QoDZCRLV--) {
        FnztFiuyFZPdduUK *= FnztFiuyFZPdduUK;
        HgxFzHfSXpRAKUN = iCERdVFQcwqzuk;
        JIcgcROTSvkvCCT *= XjRdPG;
    }

    for (int nzBSfvt = 967464068; nzBSfvt > 0; nzBSfvt--) {
        HiEIxgry = ! slOicZf;
        bCIsh += vUavAl;
        slOicZf = slOicZf;
        JIcgcROTSvkvCCT = XjRdPG;
    }

    for (int yAPNnWCg = 1028045499; yAPNnWCg > 0; yAPNnWCg--) {
        vUavAl += vUavAl;
    }

    for (int NJIVIqLYhsafNHZ = 68279255; NJIVIqLYhsafNHZ > 0; NJIVIqLYhsafNHZ--) {
        lFxoVxIZAQJo += lFxoVxIZAQJo;
    }

    for (int cYBmuQFRDd = 728309080; cYBmuQFRDd > 0; cYBmuQFRDd--) {
        MqrQAg = lUyim;
    }
}

void yqiFF::rjvSGPtRNHyWQa(double WULKVFq)
{
    double cqWPNlBIcQZCGzAd = -910519.109422726;
    int tREZMUbaZBh = 1151894705;
    string JDkPimupCnwxLsl = string("IpIhLrYisMZDyBblcbxoZHpIJPgLjcFEJaXKMUCuJPqivMjldqRKYeHBmKcRvCfQVAvfNOpSCtYAgagDiOwuMMrWeOhwYcHtxDQKVUNPvYdClAhdSUgieuNohFYZEZuTGkgPNfUaNoPwrZFuczRaCQDZJovlieYlCHEcIewxAoyRccmVvLHdecBCNdLQtaBFEgHssIvsRpTpYLCciNohVfuWiPWIvNIiejrBt");
    bool bCfLbraaaw = true;
    int RyavXx = -875394713;
    double VRhltYun = 95557.38435880984;
    int ShVklzFnh = -1355350199;
    double LWPJLdFjbizhT = 794319.1571164498;

    if (JDkPimupCnwxLsl == string("IpIhLrYisMZDyBblcbxoZHpIJPgLjcFEJaXKMUCuJPqivMjldqRKYeHBmKcRvCfQVAvfNOpSCtYAgagDiOwuMMrWeOhwYcHtxDQKVUNPvYdClAhdSUgieuNohFYZEZuTGkgPNfUaNoPwrZFuczRaCQDZJovlieYlCHEcIewxAoyRccmVvLHdecBCNdLQtaBFEgHssIvsRpTpYLCciNohVfuWiPWIvNIiejrBt")) {
        for (int LXRKTav = 362430708; LXRKTav > 0; LXRKTav--) {
            cqWPNlBIcQZCGzAd *= cqWPNlBIcQZCGzAd;
            VRhltYun *= VRhltYun;
            ShVklzFnh *= RyavXx;
            cqWPNlBIcQZCGzAd -= cqWPNlBIcQZCGzAd;
        }
    }
}

double yqiFF::RusDhXL(string yZmQSZMQWWbgKT, int uTOsORWKxzy, bool wViAXjxpHyRZl, double hAIEUpSXt, double covuXZcmDwOqZNV)
{
    double UumkyFCw = 661520.784349595;
    bool CYjeokJfyviHZIe = true;
    int NSVBa = 437971465;
    bool HVtqrtecZYgMbM = false;
    bool pyrEiNrFNajJYf = true;
    bool FMgKVyNrMEtKC = false;
    double FYiUyWuYenphUtAg = 577184.7794779672;
    string HhNTzRn = string("TFKjyXDNSRtzcoGUikVQrGTOiVVoKRpIVMmCLhRrchetvTfGqWOqaJxXdsWLBIAZmfbqqFFmDVQMcjsfNZizoxEUCbdCSSSXdkcKPO");
    double YdHtfa = -281509.7414112272;

    for (int USfSYQ = 549535356; USfSYQ > 0; USfSYQ--) {
        CYjeokJfyviHZIe = ! FMgKVyNrMEtKC;
        wViAXjxpHyRZl = ! FMgKVyNrMEtKC;
        FYiUyWuYenphUtAg -= YdHtfa;
        FMgKVyNrMEtKC = pyrEiNrFNajJYf;
    }

    return YdHtfa;
}

double yqiFF::WuetYwtQCiZ()
{
    string DdyMGdDLdhZs = string("abJpsmiFqbnRuoJDUWUWdpBdFiDKAmtBAtQGtuUQxcOKeiwzOMvuGfyMKFPezpQOaZQGTXDAyHaPmEBRKOMfhVtiRzigvjbUMjCKsonjgdbVlKPUtQXmKpKgVMQjkNRJxmYXbRlSkhrFebrVIRONmTCEGRKpkRWZjIxOowWHYeZOuqBpkvacc");
    double WzmBVWUOBB = -217517.0232740621;
    string KdFqxm = string("EMLeXNuuVvVwDGVuwem");

    if (KdFqxm <= string("abJpsmiFqbnRuoJDUWUWdpBdFiDKAmtBAtQGtuUQxcOKeiwzOMvuGfyMKFPezpQOaZQGTXDAyHaPmEBRKOMfhVtiRzigvjbUMjCKsonjgdbVlKPUtQXmKpKgVMQjkNRJxmYXbRlSkhrFebrVIRONmTCEGRKpkRWZjIxOowWHYeZOuqBpkvacc")) {
        for (int jmyWE = 1193887116; jmyWE > 0; jmyWE--) {
            DdyMGdDLdhZs = DdyMGdDLdhZs;
            KdFqxm = DdyMGdDLdhZs;
            DdyMGdDLdhZs = KdFqxm;
            DdyMGdDLdhZs += KdFqxm;
        }
    }

    if (DdyMGdDLdhZs > string("abJpsmiFqbnRuoJDUWUWdpBdFiDKAmtBAtQGtuUQxcOKeiwzOMvuGfyMKFPezpQOaZQGTXDAyHaPmEBRKOMfhVtiRzigvjbUMjCKsonjgdbVlKPUtQXmKpKgVMQjkNRJxmYXbRlSkhrFebrVIRONmTCEGRKpkRWZjIxOowWHYeZOuqBpkvacc")) {
        for (int xUoSlc = 1543710218; xUoSlc > 0; xUoSlc--) {
            DdyMGdDLdhZs += DdyMGdDLdhZs;
            KdFqxm += DdyMGdDLdhZs;
            KdFqxm = KdFqxm;
        }
    }

    if (DdyMGdDLdhZs < string("EMLeXNuuVvVwDGVuwem")) {
        for (int qLwvPbbR = 672282357; qLwvPbbR > 0; qLwvPbbR--) {
            WzmBVWUOBB += WzmBVWUOBB;
            KdFqxm += DdyMGdDLdhZs;
            WzmBVWUOBB /= WzmBVWUOBB;
            DdyMGdDLdhZs += KdFqxm;
            DdyMGdDLdhZs = KdFqxm;
            KdFqxm += KdFqxm;
        }
    }

    if (WzmBVWUOBB <= -217517.0232740621) {
        for (int eumuqBGP = 780042772; eumuqBGP > 0; eumuqBGP--) {
            DdyMGdDLdhZs = KdFqxm;
            DdyMGdDLdhZs = KdFqxm;
            DdyMGdDLdhZs = KdFqxm;
        }
    }

    return WzmBVWUOBB;
}

double yqiFF::pfIqQLoJnZ(int uEVcQMGZ, string krvEgCCxRqXcuO, int zOqiADosudIW, double zIoihOiamBlPW)
{
    int BtNVNrhlTuF = 1410540376;
    double ABQKXpZXaSLLisrd = -973979.72303948;
    bool OPpslzMqM = false;
    double JPCTpBSjugsfWY = -577659.1367977348;
    bool VTHffMszQS = false;
    bool MRGajuBrms = true;
    string SAJVxGeUpqS = string("sYVtCgGTJRcEYoNxrtTHINnSrPDkSWAbOnzfjhLgUQuQvpFlZsIVXwNAARUNfZfXGiJZamTWaQXHWnugnXyAdTMZFvNbYByONaAjCVagsmFZSXZM");
    int zavUfRaTjxXiLY = 391201025;
    bool mqxLnmyhpOyTCmPd = false;

    for (int IHiisn = 1313107561; IHiisn > 0; IHiisn--) {
        JPCTpBSjugsfWY *= JPCTpBSjugsfWY;
        zIoihOiamBlPW /= zIoihOiamBlPW;
    }

    return JPCTpBSjugsfWY;
}

double yqiFF::qtAYwljAuZ(int nqPzVUgSLIoGJN, double AcZjIfrbDXYWpV)
{
    double nQDjltaKVeZ = -598258.5991686553;
    double cqSqNqTw = -566435.483236635;

    if (nQDjltaKVeZ >= -598258.5991686553) {
        for (int pzhsAPCwvlU = 193746216; pzhsAPCwvlU > 0; pzhsAPCwvlU--) {
            cqSqNqTw += cqSqNqTw;
            nQDjltaKVeZ /= cqSqNqTw;
            nQDjltaKVeZ *= AcZjIfrbDXYWpV;
        }
    }

    if (nQDjltaKVeZ < -566435.483236635) {
        for (int tLnCBN = 2060900558; tLnCBN > 0; tLnCBN--) {
            AcZjIfrbDXYWpV /= AcZjIfrbDXYWpV;
            cqSqNqTw /= AcZjIfrbDXYWpV;
        }
    }

    return cqSqNqTw;
}

double yqiFF::tlDyNPBrUWsS(int ZxuWrF)
{
    double bHxHKV = -552742.3634619309;
    double zjdxZwGVoRGNMIzP = -201430.82053901147;
    string vluWt = string("BJXsPeRXqfcnFoWnUZJgdhtdArWRNaSwFDwNEcxPZwhmMSiMfymuwgNLsJaxHcmfcSLtBc");
    string zJVxvdcYx = string("yzBIiNglGZcxtftZhsBzxiPMliYKKSqCfJ");
    bool pDOfLtkBz = true;
    string LUFngl = string("dpgAkpbaHdlalMjWWHvNTTkRattqeWzjiBPCdbqICxYIyQSyRlvHWswrlWCddlJpbcuCKiEDPVchtXWISpgACCcJKtCnYgDHVOqjdCSzdLZUNiikOMLpoHgFkLDKjBhoDJIAwJUiFIKMbEhjLjLwPTfWbOgzojDyfweqXtMQX");
    bool WyhcPaEvNKy = false;
    string KmOvkj = string("HAcoUWIcJyNCuWIgOTyAvcdyLHoVMkicYECBliOkevsNIbMAXdMzasUCbpfmdYruImoeAN");
    bool IxZaA = false;

    for (int nYVeiAXCyWQ = 1265183010; nYVeiAXCyWQ > 0; nYVeiAXCyWQ--) {
        IxZaA = ! WyhcPaEvNKy;
        vluWt = vluWt;
        LUFngl += zJVxvdcYx;
        bHxHKV += zjdxZwGVoRGNMIzP;
    }

    for (int IOGXLjKUYbQC = 109036587; IOGXLjKUYbQC > 0; IOGXLjKUYbQC--) {
        vluWt += zJVxvdcYx;
        pDOfLtkBz = ! IxZaA;
    }

    if (WyhcPaEvNKy == false) {
        for (int ItQDsInbPMdlj = 1962472199; ItQDsInbPMdlj > 0; ItQDsInbPMdlj--) {
            zJVxvdcYx = vluWt;
        }
    }

    if (KmOvkj == string("yzBIiNglGZcxtftZhsBzxiPMliYKKSqCfJ")) {
        for (int gRtJIYebdTtv = 1134841816; gRtJIYebdTtv > 0; gRtJIYebdTtv--) {
            LUFngl += vluWt;
            IxZaA = pDOfLtkBz;
        }
    }

    return zjdxZwGVoRGNMIzP;
}

string yqiFF::NDuSNfJdZYfQzI()
{
    double JrBSJdBLjqBBB = 261067.14978241062;
    string aJpNXorXZsW = string("csTgRzFPASkVrMvVifegQsU");
    string LqyKtRl = string("cRDXzAGITgtzXKnkAJHjemRmVkTepQdWNvJrpFVHOKbgLqrVGWlqlYpbuVLgrtPyediAwfMhdHEdBmAIFPfiGQMdduIDMizgNXlMQRINxARZQhKwYMnuS");
    bool QGboDeV = true;
    bool ItwcEsrrJMIGuj = false;
    bool lgznvVZfmKFCF = true;
    double YHEByeAOSYSrH = 375866.08657769585;
    double iSdidYhBJfdKhR = -260803.11937169798;

    if (QGboDeV != false) {
        for (int ZVskhzBHGMjJ = 1211514328; ZVskhzBHGMjJ > 0; ZVskhzBHGMjJ--) {
            ItwcEsrrJMIGuj = ! QGboDeV;
            lgznvVZfmKFCF = lgznvVZfmKFCF;
        }
    }

    for (int SQBpnWBjI = 1468272482; SQBpnWBjI > 0; SQBpnWBjI--) {
        iSdidYhBJfdKhR += iSdidYhBJfdKhR;
        iSdidYhBJfdKhR -= YHEByeAOSYSrH;
    }

    for (int SOTjpYnXap = 985708780; SOTjpYnXap > 0; SOTjpYnXap--) {
        iSdidYhBJfdKhR *= iSdidYhBJfdKhR;
        QGboDeV = ItwcEsrrJMIGuj;
    }

    if (iSdidYhBJfdKhR > 261067.14978241062) {
        for (int BUKVwxyh = 882780484; BUKVwxyh > 0; BUKVwxyh--) {
            JrBSJdBLjqBBB = YHEByeAOSYSrH;
            iSdidYhBJfdKhR *= YHEByeAOSYSrH;
            ItwcEsrrJMIGuj = ! lgznvVZfmKFCF;
        }
    }

    for (int TNEYSxjxCNOG = 1845802918; TNEYSxjxCNOG > 0; TNEYSxjxCNOG--) {
        aJpNXorXZsW = LqyKtRl;
        JrBSJdBLjqBBB = JrBSJdBLjqBBB;
        ItwcEsrrJMIGuj = ! lgznvVZfmKFCF;
    }

    return LqyKtRl;
}

yqiFF::yqiFF()
{
    this->sMOHlcTpaQMWbb(string("GlcaOfupcuPgcgYZWNeeHXkygMFKqHwDOLrfIizbhOOiJhYdwHxrklXwdNmoOwvhIWwSQNBPbyEvQDbUxzmbqsmyUbIUxqBIWokYOfZMmyJZTXLOkduEWqtpjYzfjmgegbuTLRAYqLimXTtOBoovVxCVCjoywVCFuOsKnKdekiJPTlcdSsfBswVpkh"), true, true, -1064544164, -2138081517);
    this->rjvSGPtRNHyWQa(745575.606592237);
    this->RusDhXL(string("JtsGeiyrYzxnXDqncAHrVlYORvVyJmpMHjyzHmGIRokpQdPaTYAsrbVKuYLlcKsLDHunhRozBzPJHWJmdwXjwulDBa"), 1320683718, false, -483711.15208093426, 704138.0420324485);
    this->WuetYwtQCiZ();
    this->pfIqQLoJnZ(815285085, string("gnvHpQwFtsGVjaclRkTPtnZAUySksPizPdpkiQpZOxMIgtcHhjhaesRQBtgsndGTaTEbfmPTcKBJFFePlYMJZReOpewgDkexvsEjoACjhfMDCQQm"), 1545270681, 326283.4641833374);
    this->qtAYwljAuZ(2099604775, 418391.1741621619);
    this->tlDyNPBrUWsS(-1157339737);
    this->NDuSNfJdZYfQzI();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XiqCgaZ
{
public:
    double OpUqYA;
    string ddmzu;
    bool xuFSQetsrKAwLhw;
    double MhPFby;

    XiqCgaZ();
    void NlXqyBhwedKZOOJB(double PtKuqXTmMGXAlDYq, int GQVyYJNoXDDo, int dWwPIFGkrMzt, bool nxfgymxRJEM, int cFZJEnKYnKz);
    int qPVUXF();
    double EocFkzFtj(string iVjlxr, int vHzFjSSvpUseLP);
protected:
    int HeXsN;

    int ySJXVLAqz(double lqJdxffp);
    double jGadoi(string bkdNhsw);
    void keebYhlVFLLFNQpw(bool PiUqSzj, int LzKtmYKPds, double VkvDXFwlisVx, bool DkeheZNwn, bool btnMSKxmKmLuOdf);
    int qLoswOV(double fdWzxFWQO, int mtrgoQCdDK, bool vgkjZyyrTx);
    string FMIAnCgPclA(int iDaZRTZEomwxr, bool PHYaGBChoDxQQX);
private:
    string ccVQKNIWfY;
    int NrpiDE;
    int TfBpEzSRrY;
    int CEQOWjGvo;

    bool VvfojekvRs(int JjqyJXXOKGDVjFd, double hiLQpWhEDf, double hroTJkoXsOzBm);
    bool xTogVUhcSrLW();
    bool OmXjknLXlw(double MkumacgN);
    bool SomkGmx(int lnOvEGIc, string hlFtbngLszkFzhJK, int dXnKGxCmRf, int KSjMdFXMIFy);
    bool QpojjzRivl(string fjEenRLSzaqTE, double maSBycqtxZifUmfH);
    bool uHgXZPLIW(int BrJiw, bool ZWOWqrRxfx);
};

void XiqCgaZ::NlXqyBhwedKZOOJB(double PtKuqXTmMGXAlDYq, int GQVyYJNoXDDo, int dWwPIFGkrMzt, bool nxfgymxRJEM, int cFZJEnKYnKz)
{
    int rCOoRGuOVtKmnmN = 425217310;
    bool xQtXaTWqWTIB = false;
    double IeVCD = 437642.3508581851;
    int TfrHp = -260928562;

    for (int yTDbOzomKs = 64618007; yTDbOzomKs > 0; yTDbOzomKs--) {
        continue;
    }

    for (int OWoMcMLXNdY = 1167895761; OWoMcMLXNdY > 0; OWoMcMLXNdY--) {
        IeVCD += PtKuqXTmMGXAlDYq;
        GQVyYJNoXDDo -= TfrHp;
        rCOoRGuOVtKmnmN /= cFZJEnKYnKz;
    }
}

int XiqCgaZ::qPVUXF()
{
    bool BMaLvEgSFG = false;
    int piMQykkxt = 1448516118;
    bool bpEmoxHnVMCgJt = false;
    int ReMcevlTBqdV = 1604303085;
    string oOCzJcLoZJxPabZ = string("TyAxfwaEughKccoESmRMhzGSVgfsCxTPsoQVIiqyWbSxbizFXoMEjkXpZKeQPxAKPiwdveTYLiHiUUNGhPWmJHieVGBOQbPlAJmculwDgHYXqEtPVhQLrigrQOoQlraQjbaTBnNtqonLGgKGbaldJlVcvhuodBPiETVUNFRBwxbWMKVjcUcPiWpbsYNvUPwAuQVxy");

    for (int jhRshRFxWzajIB = 1203916322; jhRshRFxWzajIB > 0; jhRshRFxWzajIB--) {
        BMaLvEgSFG = ! BMaLvEgSFG;
    }

    if (ReMcevlTBqdV > 1604303085) {
        for (int IjVXYZvUZavK = 52191038; IjVXYZvUZavK > 0; IjVXYZvUZavK--) {
            BMaLvEgSFG = bpEmoxHnVMCgJt;
        }
    }

    for (int QMKzvCpHtqeduX = 259076408; QMKzvCpHtqeduX > 0; QMKzvCpHtqeduX--) {
        piMQykkxt += ReMcevlTBqdV;
    }

    for (int XLDirYxRrtO = 786500201; XLDirYxRrtO > 0; XLDirYxRrtO--) {
        bpEmoxHnVMCgJt = BMaLvEgSFG;
    }

    for (int IvIurwbnIhpN = 1636047773; IvIurwbnIhpN > 0; IvIurwbnIhpN--) {
        piMQykkxt /= ReMcevlTBqdV;
    }

    return ReMcevlTBqdV;
}

double XiqCgaZ::EocFkzFtj(string iVjlxr, int vHzFjSSvpUseLP)
{
    bool ohXrwGIGYml = false;
    bool aMgBVbG = false;
    bool tAPCtelAJiyBR = true;

    for (int xCIrbVLyyjU = 2130232499; xCIrbVLyyjU > 0; xCIrbVLyyjU--) {
        tAPCtelAJiyBR = ! aMgBVbG;
        iVjlxr += iVjlxr;
        aMgBVbG = ! ohXrwGIGYml;
    }

    if (iVjlxr >= string("triHrboVgpqeWAtRZzaVYxRKmfyCbLReLqcTmccNyyvsTyDc")) {
        for (int wJjerZ = 319818009; wJjerZ > 0; wJjerZ--) {
            vHzFjSSvpUseLP += vHzFjSSvpUseLP;
        }
    }

    if (ohXrwGIGYml == true) {
        for (int uqqhxTtu = 1590685317; uqqhxTtu > 0; uqqhxTtu--) {
            continue;
        }
    }

    return 16287.583890663922;
}

int XiqCgaZ::ySJXVLAqz(double lqJdxffp)
{
    int sQOcJzJvGmSEAIGR = -1110842788;

    if (sQOcJzJvGmSEAIGR < -1110842788) {
        for (int AQIxIzYPDTVbkxy = 894889749; AQIxIzYPDTVbkxy > 0; AQIxIzYPDTVbkxy--) {
            lqJdxffp *= lqJdxffp;
        }
    }

    if (lqJdxffp != 366823.0204316599) {
        for (int TQCieIXlxjU = 930769869; TQCieIXlxjU > 0; TQCieIXlxjU--) {
            lqJdxffp *= lqJdxffp;
            lqJdxffp /= lqJdxffp;
            sQOcJzJvGmSEAIGR *= sQOcJzJvGmSEAIGR;
        }
    }

    if (sQOcJzJvGmSEAIGR <= -1110842788) {
        for (int htfWkaCcQ = 77113239; htfWkaCcQ > 0; htfWkaCcQ--) {
            lqJdxffp /= lqJdxffp;
            sQOcJzJvGmSEAIGR /= sQOcJzJvGmSEAIGR;
            sQOcJzJvGmSEAIGR /= sQOcJzJvGmSEAIGR;
        }
    }

    for (int MutwHDNCGSaIb = 1832628127; MutwHDNCGSaIb > 0; MutwHDNCGSaIb--) {
        sQOcJzJvGmSEAIGR = sQOcJzJvGmSEAIGR;
        lqJdxffp *= lqJdxffp;
        sQOcJzJvGmSEAIGR += sQOcJzJvGmSEAIGR;
        sQOcJzJvGmSEAIGR -= sQOcJzJvGmSEAIGR;
    }

    for (int WMUOFtxOw = 968197742; WMUOFtxOw > 0; WMUOFtxOw--) {
        lqJdxffp = lqJdxffp;
        lqJdxffp = lqJdxffp;
        sQOcJzJvGmSEAIGR -= sQOcJzJvGmSEAIGR;
        sQOcJzJvGmSEAIGR /= sQOcJzJvGmSEAIGR;
        sQOcJzJvGmSEAIGR /= sQOcJzJvGmSEAIGR;
    }

    return sQOcJzJvGmSEAIGR;
}

double XiqCgaZ::jGadoi(string bkdNhsw)
{
    bool eTDVli = false;
    bool ZllpOOseIOqAEFqE = false;
    int aDWcALtmRaWJzAL = -495323232;
    double bloWpMv = 645566.351291787;
    int dZhZznjbjevm = -18764458;
    int GVHfbkwWEy = 28372000;
    string xrQTZQ = string("morQrnPRMQBAQqOMbWhcHzuyKLRznIlEZdIEjdlMdqEPhvKCBEfZaAIoaWgTIWlUvDkWyPajtMacFKoqBsrWjemEPUmoYGNUnAVbWCjeazYjwgLoFHnrbJdaIKUVhTBGqVFrMlndUdnyaetoupcpyjXtKmqnqnLzHLLpmYGYZRoqQMOMexyphyBYixVb");
    string diiJKwHsed = string("qbqNWbOdFazYykOvVVkSfyxRyRkPOhFSBosIyKPOxphUqEXuxUzGbJZhCmUfDmCJBREAFTRgQJdkxMpwCyGWjuIqiliOplKzcWBXftZvPoCTtMcUurqKTsTQxDjcVvrOENntZmduYqjETeYEMHBxjOwDmqkZTOocytaVeQzayrVguywnKXtAadaRGzIfLibVRXkPKTxdRNdVWZOMzlqUPVrqgihKHpjKteEsDyN");

    if (aDWcALtmRaWJzAL != -18764458) {
        for (int IZLPMKnJtbQ = 600642974; IZLPMKnJtbQ > 0; IZLPMKnJtbQ--) {
            aDWcALtmRaWJzAL /= GVHfbkwWEy;
        }
    }

    for (int tIaiswtDbM = 1609555906; tIaiswtDbM > 0; tIaiswtDbM--) {
        ZllpOOseIOqAEFqE = eTDVli;
    }

    for (int pinBETOjWjfVq = 2050899158; pinBETOjWjfVq > 0; pinBETOjWjfVq--) {
        ZllpOOseIOqAEFqE = ! eTDVli;
        bkdNhsw = diiJKwHsed;
    }

    if (diiJKwHsed >= string("morQrnPRMQBAQqOMbWhcHzuyKLRznIlEZdIEjdlMdqEPhvKCBEfZaAIoaWgTIWlUvDkWyPajtMacFKoqBsrWjemEPUmoYGNUnAVbWCjeazYjwgLoFHnrbJdaIKUVhTBGqVFrMlndUdnyaetoupcpyjXtKmqnqnLzHLLpmYGYZRoqQMOMexyphyBYixVb")) {
        for (int VWrfZRyMm = 1949700911; VWrfZRyMm > 0; VWrfZRyMm--) {
            bkdNhsw = xrQTZQ;
            GVHfbkwWEy *= aDWcALtmRaWJzAL;
            aDWcALtmRaWJzAL -= GVHfbkwWEy;
        }
    }

    if (bloWpMv > 645566.351291787) {
        for (int DajIiTjDoaob = 1482053781; DajIiTjDoaob > 0; DajIiTjDoaob--) {
            continue;
        }
    }

    return bloWpMv;
}

void XiqCgaZ::keebYhlVFLLFNQpw(bool PiUqSzj, int LzKtmYKPds, double VkvDXFwlisVx, bool DkeheZNwn, bool btnMSKxmKmLuOdf)
{
    string EXjGNul = string("MqUHGUeJYZPIJpSsibDpZDicgsxxDwDlkuzavCQgupipZAMpRKXJPadRsoBgHXpOnJOtJanJDuomFdBiHfVQGZKXnkUzpTwJDzePHWFviFwgcnpxGtWwPbC");
    bool KmojiTiPF = true;
    string NJvSzoL = string("znbrUUvVNbZUuMBqoAXtsuPghWckmrosQsVbaBRSASxLIpjoEydnVh");
    double FosIH = -39842.750976083495;
    bool DdLKVomiTtih = true;
    string etXMsPgOddaDLSBr = string("YbtTqXClpksyTOGGmKWqYYGlLMgdJtHcYLzOeAlLfEovbvlmYKnlkkRJVduoxQosDVMqSIiJTflDLDJojZdvgjACnRsBImLDTOEsCydvCAkOKycOeXKKzLQikYlgpxUdllLnJVKBnYiNtQMrNAbcPhQAIfhKPUHxuzHBlPDKAYBBnghAVNIWSucayfJGAkhQnNdqiAoPDxWopAGrJddbFSYdOvMTmLMnkBVWdzIvPcoyXn");
    double HcEdYMNu = 64068.32229963505;
    double WCfvWrp = -883856.6539572721;
    bool fYMylRcIKnGYaMRu = false;
    string HMFqfK = string("zStpCerBInDzPRUnyBJZwdeVwDjdbIqiDJYIzWAfciglaEijNQOsbPhjUbrpGjCPQMioQmrQTOhQWvPZDBnIKhLDNyLflMZZZbxKVOqWvGkSejzyLgUtHKNVIJYbpzLfIvLZxeiBtaevKtGqCbIFIsApYKOMqGsa");

    for (int CqFFuUKWNRlKw = 1138713223; CqFFuUKWNRlKw > 0; CqFFuUKWNRlKw--) {
        etXMsPgOddaDLSBr = EXjGNul;
        btnMSKxmKmLuOdf = KmojiTiPF;
        EXjGNul = HMFqfK;
    }

    if (DkeheZNwn == false) {
        for (int YHWVViw = 2103396539; YHWVViw > 0; YHWVViw--) {
            WCfvWrp += VkvDXFwlisVx;
        }
    }

    for (int nxJYmyTDrInBZen = 30025472; nxJYmyTDrInBZen > 0; nxJYmyTDrInBZen--) {
        PiUqSzj = PiUqSzj;
    }
}

int XiqCgaZ::qLoswOV(double fdWzxFWQO, int mtrgoQCdDK, bool vgkjZyyrTx)
{
    bool cSxynPy = false;
    int lfHbALGYumoki = 1915487520;
    int AwDSwEkai = 991814658;
    bool QYNEd = false;

    for (int AJRlQGdA = 385937120; AJRlQGdA > 0; AJRlQGdA--) {
        QYNEd = QYNEd;
        vgkjZyyrTx = QYNEd;
        vgkjZyyrTx = vgkjZyyrTx;
    }

    for (int RueUJmjtu = 941654808; RueUJmjtu > 0; RueUJmjtu--) {
        QYNEd = vgkjZyyrTx;
        mtrgoQCdDK *= lfHbALGYumoki;
        QYNEd = vgkjZyyrTx;
    }

    if (vgkjZyyrTx == false) {
        for (int EjVRCE = 1983298565; EjVRCE > 0; EjVRCE--) {
            vgkjZyyrTx = vgkjZyyrTx;
        }
    }

    for (int pFugKDMgngl = 1753508514; pFugKDMgngl > 0; pFugKDMgngl--) {
        continue;
    }

    for (int wUloEWrkx = 375757315; wUloEWrkx > 0; wUloEWrkx--) {
        AwDSwEkai += lfHbALGYumoki;
        vgkjZyyrTx = ! cSxynPy;
    }

    return AwDSwEkai;
}

string XiqCgaZ::FMIAnCgPclA(int iDaZRTZEomwxr, bool PHYaGBChoDxQQX)
{
    bool rAcHazKyTPhkDO = false;
    double PQIZCWpp = 79739.41278282479;
    string aICMdIG = string("lLKJDDIbacoPuAEVJOcPFtbhdCrGYLNqmjbEiTkoXEesRGsARbSPbuPtBdmnxBTJqiDWQvIQuUzpxanFUAiCNKoVfQVdABTDJxuKgFytpWbGyYXkXDGiTvQDlCrKTT");
    int YROxPO = 892060971;
    bool mpBOgbFcAQygy = true;
    int fjcOvVzokupReuo = -1731578350;

    for (int oyIrJx = 591664628; oyIrJx > 0; oyIrJx--) {
        mpBOgbFcAQygy = ! PHYaGBChoDxQQX;
    }

    return aICMdIG;
}

bool XiqCgaZ::VvfojekvRs(int JjqyJXXOKGDVjFd, double hiLQpWhEDf, double hroTJkoXsOzBm)
{
    string axrZkKiM = string("SxfEhMOdwEcrBfGIlhjNuAAnoNLPAXMIrlKQIbTvnFCIAULlRcvGvSlJOgOQzdhbJripNJwXIKpMAFVQuUTYVBXxlBTkRQiLwpuvmESJDQjNKPQcrtxfyQNKhjcqVGEdjXTrtamaZHpLEgezWxKEkJrfHQVZDhxUaBrnlVcRHPMTUEuZ");

    return true;
}

bool XiqCgaZ::xTogVUhcSrLW()
{
    string kpxIZPno = string("FgLBnBRJjUWUvPCwWXEQmnIoEChggchdBVVOhkgEEhTAILUVnYpCqtGqgkNveeD");
    bool KhBFxlLtFknWY = false;
    string mFZarcLxKMT = string("XwWgYcpbphJjXqNeDxjPIjNKJCXgiPSCpNgdmytZTEgMkBHgDknvSHZRcNnSBfqmmFjSmcdLiSeFlfEmPGIwWWUfXUEZxMqeVVNcrJAMiyWWZUBimqoJqTYWPgqRGRVTtwdGdesCDcQzVUCiHjZBqrMjVCPxfzALWXGYCQDSRyysqSGdNapokhUhUGhBOWIEbETJqyropweeuMohHFFFwqSNjLiJex");
    double BkqWpRZxcWg = -78191.981142349;

    if (kpxIZPno <= string("XwWgYcpbphJjXqNeDxjPIjNKJCXgiPSCpNgdmytZTEgMkBHgDknvSHZRcNnSBfqmmFjSmcdLiSeFlfEmPGIwWWUfXUEZxMqeVVNcrJAMiyWWZUBimqoJqTYWPgqRGRVTtwdGdesCDcQzVUCiHjZBqrMjVCPxfzALWXGYCQDSRyysqSGdNapokhUhUGhBOWIEbETJqyropweeuMohHFFFwqSNjLiJex")) {
        for (int yrPoMBKiXvTYXn = 1460931974; yrPoMBKiXvTYXn > 0; yrPoMBKiXvTYXn--) {
            BkqWpRZxcWg += BkqWpRZxcWg;
            kpxIZPno = kpxIZPno;
            kpxIZPno += mFZarcLxKMT;
        }
    }

    for (int KebpCyFDmBH = 896595463; KebpCyFDmBH > 0; KebpCyFDmBH--) {
        continue;
    }

    for (int PSTRLXhBQR = 1769314266; PSTRLXhBQR > 0; PSTRLXhBQR--) {
        KhBFxlLtFknWY = ! KhBFxlLtFknWY;
        BkqWpRZxcWg /= BkqWpRZxcWg;
        BkqWpRZxcWg /= BkqWpRZxcWg;
    }

    for (int bmkLgNQbxPOI = 159455763; bmkLgNQbxPOI > 0; bmkLgNQbxPOI--) {
        KhBFxlLtFknWY = KhBFxlLtFknWY;
        mFZarcLxKMT += kpxIZPno;
        BkqWpRZxcWg *= BkqWpRZxcWg;
    }

    for (int kpRjHHLthFvm = 252918502; kpRjHHLthFvm > 0; kpRjHHLthFvm--) {
        BkqWpRZxcWg /= BkqWpRZxcWg;
        mFZarcLxKMT += kpxIZPno;
        kpxIZPno = kpxIZPno;
    }

    return KhBFxlLtFknWY;
}

bool XiqCgaZ::OmXjknLXlw(double MkumacgN)
{
    int UMisyFjOQLKOY = 562799480;
    string XCLGlbz = string("PRioSqDsFvWaVUIafnGLaAJliNkCvyzZROBdEaAWOshRWhnzzqdPRbjuIqNtviQFpGSbNwjSiFLalejJYhgQFVCAEPJNUigJPOgpQvLMKvaVLfdTotfZAAImufntiabltebfytXcQWoVOFkQwApydFtOhXISPKXDmRsetPDWgdfiERKreOkVnwYHcaNSZxdyhyVTxGQMTWg");
    int MBedin = 763406341;

    if (MBedin != 763406341) {
        for (int iSqptPu = 1562091949; iSqptPu > 0; iSqptPu--) {
            UMisyFjOQLKOY = MBedin;
            UMisyFjOQLKOY = MBedin;
        }
    }

    for (int cGNKBLAnbtOyr = 1555265557; cGNKBLAnbtOyr > 0; cGNKBLAnbtOyr--) {
        XCLGlbz = XCLGlbz;
        MBedin -= UMisyFjOQLKOY;
    }

    return false;
}

bool XiqCgaZ::SomkGmx(int lnOvEGIc, string hlFtbngLszkFzhJK, int dXnKGxCmRf, int KSjMdFXMIFy)
{
    int oWRoCVS = 1192339769;
    bool PaHNOv = false;
    string EemnxdXR = string("SdPzKJgbeWq");
    bool QNDRmmgTFdZySeL = false;
    int toUMOPIO = -1694062151;
    int HjqInDCs = 958986103;
    string SQlnDpqvSFTKxduO = string("SpTQopmelvmNCdnfMvBgckOcupOyFiuSmQXjngZcLUTNiASfffZLaGGWUOLdgnfNWvSEJfCXwlDKtNJwGEWwfFZiUcELIetEyDPfEYUPfOolEOYXYDVLAKghNLmpFxfLJIIUYyXFkWJGnUbLHAjhHmkesSetGjlVkHqgZnSidKKYXaFsbepfPNeEXCBRTYJHvaOjmleZuxRLXBHIbZpJqrpvXlsCNzpnpvWHFscEdkgWMOqGXmFO");
    double uyPsRRivEOlKMb = -481754.1308474647;
    int BwdilbNLeOW = 902196597;
    string QuWKqZ = string("ctZzsvesqIdDOSVfWZjZxPprxkMYzWBdHlSpvbPfPXtkncSWIqWpmDOqOlxNNkZtSXxqPdqeVgVFZxbeRlNGAieSqrBQXTlwqrkQiCEQhNStAlenooMSxueihUbciMdnKHLzfDkvxQuwLLAkhLlBBPNIlUAvPspxAOWeFQaJjFNVqzBzLVxWQOlKaYlL");

    for (int sMNwdJ = 1376204004; sMNwdJ > 0; sMNwdJ--) {
        KSjMdFXMIFy -= lnOvEGIc;
    }

    for (int rReyKYH = 1412243903; rReyKYH > 0; rReyKYH--) {
        SQlnDpqvSFTKxduO += hlFtbngLszkFzhJK;
    }

    return QNDRmmgTFdZySeL;
}

bool XiqCgaZ::QpojjzRivl(string fjEenRLSzaqTE, double maSBycqtxZifUmfH)
{
    int NVwMEGmE = -1604747243;
    bool XIBYqJBkObrNCasd = true;
    string FUdrXWBttvaLbv = string("esgNdLevAACXlpeqDTELejRtgpGAtHiZLdcFsc");
    string lIfCSTyEtZaPC = string("bCXfrcIwNGBLuNMPTxrYiyYyvPipSndHNLbuxSYfulakHNiNBrNNOvtuWMZDbleJXyrANDzcZStMnFKdkVKtmiporJsJmpCkOfAJGPGqnJEVVWGYtDkbrIYVSMyZxsnGUxuoqtlyOKdmknzsBpArzWRBryMxjXX");
    double xammgCtpZ = -949977.0873701742;
    int ujvQzMjd = 1337213431;
    bool FotqfAeDKxueNY = false;
    string VtCXCIASYeZ = string("ovvrmNikgbfQMgItHVdtdHVaZtvluPkTiJuubtgeeenjZiWqWmNnzwlGVECK");

    for (int TMYpmZdYRHJGkz = 342018565; TMYpmZdYRHJGkz > 0; TMYpmZdYRHJGkz--) {
        FotqfAeDKxueNY = XIBYqJBkObrNCasd;
    }

    for (int RoNRwudKEuTTL = 456253149; RoNRwudKEuTTL > 0; RoNRwudKEuTTL--) {
        lIfCSTyEtZaPC = FUdrXWBttvaLbv;
        fjEenRLSzaqTE += VtCXCIASYeZ;
        xammgCtpZ -= maSBycqtxZifUmfH;
        XIBYqJBkObrNCasd = FotqfAeDKxueNY;
    }

    for (int yZZMEMjuiEFrTr = 840610900; yZZMEMjuiEFrTr > 0; yZZMEMjuiEFrTr--) {
        continue;
    }

    return FotqfAeDKxueNY;
}

bool XiqCgaZ::uHgXZPLIW(int BrJiw, bool ZWOWqrRxfx)
{
    string idqzt = string("chwJhdLREYfsAlagLHxvYcLpsvNHRfYsQLQmIAtygVumGNoDXZErOzsZLqolqmdyudXcdeLbqANPeEemEXbdnDucdjIhLisRwHsyJvQgY");
    string VHybW = string("qShOrJMlxcPxtqdedymCyDLEVaISuQFwlIOjARnWVNIcQjDmcOyrGxFmXnqAmgKUcpkQdYZOFzNnoxf");
    bool XokWPDMOrUeyrG = false;
    bool uZLnrwT = true;
    int FITvpD = -2059923207;
    double mXzTKWBx = 398660.2819402314;
    bool znGfZqpDKPmbuoid = false;
    bool NtVvnKTFyDF = true;
    string DeiXDHoRNIWA = string("yeKHiSVSRnVJVgvUwqbvrmbMVanEzvlAlFirdRmzmTgGwMfNfUIKuKIOzUyXUWBoxgBQpevIpUxoOENGYkUGJvgcUxyz");
    int TRrfqoUP = -1206744086;

    for (int tpSYOxuTPJsM = 1517623984; tpSYOxuTPJsM > 0; tpSYOxuTPJsM--) {
        NtVvnKTFyDF = ZWOWqrRxfx;
    }

    return NtVvnKTFyDF;
}

XiqCgaZ::XiqCgaZ()
{
    this->NlXqyBhwedKZOOJB(660733.9042490899, -1254673069, -387476643, true, 359924125);
    this->qPVUXF();
    this->EocFkzFtj(string("triHrboVgpqeWAtRZzaVYxRKmfyCbLReLqcTmccNyyvsTyDc"), -1214075292);
    this->ySJXVLAqz(366823.0204316599);
    this->jGadoi(string("dtiHBUikNdixWkXqqWCmjzVbwqwAhIXCBxjMQjAUkhCStxjscAvFhNberXbRgdpPpfDdxifhIdVXKiXNWOkAxJijKcbrqrUA"));
    this->keebYhlVFLLFNQpw(false, -1673118175, 53102.13375458771, true, true);
    this->qLoswOV(-409265.2847749101, 86969236, false);
    this->FMIAnCgPclA(-2111008009, false);
    this->VvfojekvRs(-1151543648, -768833.8230636733, -672413.1066495089);
    this->xTogVUhcSrLW();
    this->OmXjknLXlw(101825.1602067845);
    this->SomkGmx(-2138630568, string("gazrBtOdhxFOcKYfPCYCOuWBNjtfTJBGqkJdeXnbQSwSHGxsQDhCDDFeMUgUAhImgKGHSjJKvFVZImmsfbBPcGNHSUnHwfnAEwMxKyVlfQCdaQKZWKLs"), -482854476, -1826861505);
    this->QpojjzRivl(string("UitBsptpHBXCEQLTwCEJsXJTtRJAMrXCjjeGZGyBVCFAwiLTkRlzNkttLOcamHXlSXZRPQwFXYyAPiBVmCASNosIQMZVKBfERlWFzMr"), -21177.19264380792);
    this->uHgXZPLIW(1948277101, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SHeTw
{
public:
    double ftWbxOHT;
    bool BDaTBIpNnV;

    SHeTw();
    string QjPKAQpJavSQOhm(double AJqVMyQX);
    bool ipcbEgA();
    int SWkiCajNyd(int PtDDuU, double QUWuzqKSIMaPIGSv, int wJGFxGYBFf, double pCsUVaQTRdMMYYkr, string dMQRGKZdXzpPoJd);
    bool PUTGUJkdn(double BgRZgvV);
protected:
    bool YgIqDulzkYskLCpw;
    bool rXVdJ;
    int WtLAqkqVcDW;
    double JQFGCwrM;

private:
    double wbfnkjJJIZNVlA;
    double Tjexf;

    void bJUpEBqhDzeL(double vawVCUfuMAXCxsGa, string odYLW, double YPHIYqg, double eTwrnxZrWWzN);
    int AaRfiApeqB(int PrSdfHRtjxaXH, string DwEgi, double awfmyyPA, double FZsxxCsDv);
    void fxIGhJ();
    void poqQZWaue(string oOtbqLBHTRdOtV);
    int bfTdlx(bool wQroJCWcWdwwn, double OJkYUITWwV, double qVtlWbX, bool yReXXItNCoyEhjX);
    int LmCnnnhpuZGW(int qOpdb, double tEmTKx, double KYWPATPoVVtcQaVQ, string rJvzSGZy);
    void pnNfG();
    void vjFclHfgeiVMcp(double sxCKUhMNqCVUdI, double omfIWSHlcIH, int OitXSKrKtj, double JyToju, string OPaEpEmbOvNmNTU);
};

string SHeTw::QjPKAQpJavSQOhm(double AJqVMyQX)
{
    int hXZBFHonJfXfXTk = 1370696717;
    string hjIlHdfZNlp = string("pOSPguVbxrpLWCOguWOCXizhWIVgtsejEaPViBBqnxZBPHemRmhUSSWUQOFwcTllkgRdKvYTqrJqZtZPOkQauJDdQCheeInvueMAryhqxXkjZpGgBSpBZlKgyjeKAMfhPqrICOUvYKwTpjTeSWVZE");
    bool DpsBLmJsc = true;

    for (int TmiUAsO = 149738476; TmiUAsO > 0; TmiUAsO--) {
        AJqVMyQX *= AJqVMyQX;
        DpsBLmJsc = DpsBLmJsc;
    }

    for (int SbjvtrHUhKfF = 1020048647; SbjvtrHUhKfF > 0; SbjvtrHUhKfF--) {
        AJqVMyQX *= AJqVMyQX;
        hjIlHdfZNlp += hjIlHdfZNlp;
        hjIlHdfZNlp = hjIlHdfZNlp;
        AJqVMyQX = AJqVMyQX;
    }

    return hjIlHdfZNlp;
}

bool SHeTw::ipcbEgA()
{
    bool qCiGnaDmMxQrihl = true;
    bool PZhjuRPo = false;

    if (PZhjuRPo != false) {
        for (int MNoQXXDaYb = 843053978; MNoQXXDaYb > 0; MNoQXXDaYb--) {
            PZhjuRPo = qCiGnaDmMxQrihl;
            PZhjuRPo = qCiGnaDmMxQrihl;
            qCiGnaDmMxQrihl = ! qCiGnaDmMxQrihl;
            qCiGnaDmMxQrihl = qCiGnaDmMxQrihl;
            PZhjuRPo = PZhjuRPo;
            PZhjuRPo = ! PZhjuRPo;
        }
    }

    if (qCiGnaDmMxQrihl != false) {
        for (int WGMLSXKYqsbupXvg = 1646774534; WGMLSXKYqsbupXvg > 0; WGMLSXKYqsbupXvg--) {
            qCiGnaDmMxQrihl = ! qCiGnaDmMxQrihl;
            PZhjuRPo = ! PZhjuRPo;
        }
    }

    return PZhjuRPo;
}

int SHeTw::SWkiCajNyd(int PtDDuU, double QUWuzqKSIMaPIGSv, int wJGFxGYBFf, double pCsUVaQTRdMMYYkr, string dMQRGKZdXzpPoJd)
{
    int URKQgVLwTvB = -739697081;
    double HVsjvUmoyaUQ = -64578.99539576795;
    double oYfDSxBEDIJLgxEk = -48057.229504860115;

    if (PtDDuU == -572121071) {
        for (int nBgsBA = 415208390; nBgsBA > 0; nBgsBA--) {
            PtDDuU *= PtDDuU;
            QUWuzqKSIMaPIGSv -= QUWuzqKSIMaPIGSv;
            URKQgVLwTvB += URKQgVLwTvB;
            oYfDSxBEDIJLgxEk -= pCsUVaQTRdMMYYkr;
        }
    }

    if (PtDDuU != 2104951056) {
        for (int ZOCOMdk = 1173124509; ZOCOMdk > 0; ZOCOMdk--) {
            oYfDSxBEDIJLgxEk /= oYfDSxBEDIJLgxEk;
            HVsjvUmoyaUQ /= HVsjvUmoyaUQ;
            pCsUVaQTRdMMYYkr /= HVsjvUmoyaUQ;
            PtDDuU /= wJGFxGYBFf;
        }
    }

    return URKQgVLwTvB;
}

bool SHeTw::PUTGUJkdn(double BgRZgvV)
{
    bool XPtaouEsxb = true;
    double BFfFfuPjjD = 591990.2398695407;
    int SaeHKtFfZIAbw = -610553119;
    int HoLbVNZdknln = -1579688573;
    double bYWPJzYxKUpXT = 192496.50640459298;

    for (int fUisNs = 1834885655; fUisNs > 0; fUisNs--) {
        HoLbVNZdknln *= SaeHKtFfZIAbw;
        BFfFfuPjjD += BgRZgvV;
    }

    if (SaeHKtFfZIAbw >= -1579688573) {
        for (int jkCyUsEmbTvVwI = 1673559757; jkCyUsEmbTvVwI > 0; jkCyUsEmbTvVwI--) {
            bYWPJzYxKUpXT = BgRZgvV;
            HoLbVNZdknln += HoLbVNZdknln;
        }
    }

    for (int gGSRSLEEgIGKwy = 939647794; gGSRSLEEgIGKwy > 0; gGSRSLEEgIGKwy--) {
        SaeHKtFfZIAbw = HoLbVNZdknln;
        BgRZgvV -= bYWPJzYxKUpXT;
        BgRZgvV *= bYWPJzYxKUpXT;
    }

    if (SaeHKtFfZIAbw <= -610553119) {
        for (int dmPTQCFJFwRdZF = 471050604; dmPTQCFJFwRdZF > 0; dmPTQCFJFwRdZF--) {
            bYWPJzYxKUpXT += BFfFfuPjjD;
            SaeHKtFfZIAbw -= SaeHKtFfZIAbw;
            BFfFfuPjjD -= BgRZgvV;
            BFfFfuPjjD /= BFfFfuPjjD;
        }
    }

    if (BFfFfuPjjD >= 699365.6620734789) {
        for (int qDFvmfaGhmoKR = 500576594; qDFvmfaGhmoKR > 0; qDFvmfaGhmoKR--) {
            BFfFfuPjjD *= bYWPJzYxKUpXT;
            bYWPJzYxKUpXT *= BFfFfuPjjD;
            BFfFfuPjjD = BgRZgvV;
        }
    }

    return XPtaouEsxb;
}

void SHeTw::bJUpEBqhDzeL(double vawVCUfuMAXCxsGa, string odYLW, double YPHIYqg, double eTwrnxZrWWzN)
{
    bool wYiDC = false;
    bool vQyNVUMr = true;

    for (int UpxhpJvfoGZCfOnO = 1675897785; UpxhpJvfoGZCfOnO > 0; UpxhpJvfoGZCfOnO--) {
        wYiDC = vQyNVUMr;
        odYLW += odYLW;
        wYiDC = wYiDC;
        wYiDC = vQyNVUMr;
    }
}

int SHeTw::AaRfiApeqB(int PrSdfHRtjxaXH, string DwEgi, double awfmyyPA, double FZsxxCsDv)
{
    double RCFEKknmHur = 716473.6626371234;
    string oDkWeBczmaqzqBGg = string("OUTKvtEnoMgCkJvFkHtRIzaUsoehVIuXFmtvPqfNOigawBQdAQgOmWKulykuyXBWkWjtfKhEnmOCxyRxSzzOznfAFcsQmHssFcYhiGcneidsEjmajJP");
    int VqwTLypf = -1034968424;
    int fuzlqLhKYFVuS = -311034707;
    double FASidEvjnSZKRT = -10842.804164226494;
    double ezNkykUrpmLJuVk = -648332.4934133511;

    for (int QCPPccEJyFNi = 268350688; QCPPccEJyFNi > 0; QCPPccEJyFNi--) {
        FZsxxCsDv /= awfmyyPA;
    }

    return fuzlqLhKYFVuS;
}

void SHeTw::fxIGhJ()
{
    bool LneAUDiGXenygGp = true;
    int aIznUWEsx = -1288410074;
    double AAyoFxvA = 874756.0420650442;
    bool oNfxUMoazZCZjTY = false;
    int dzcRceukX = -405059817;

    for (int JkWLryeRFranV = 1076393939; JkWLryeRFranV > 0; JkWLryeRFranV--) {
        LneAUDiGXenygGp = ! oNfxUMoazZCZjTY;
    }

    for (int ddkGNrKnXfqs = 1721584860; ddkGNrKnXfqs > 0; ddkGNrKnXfqs--) {
        aIznUWEsx += aIznUWEsx;
    }

    for (int yKAQhUPqREIS = 1225073386; yKAQhUPqREIS > 0; yKAQhUPqREIS--) {
        dzcRceukX += aIznUWEsx;
    }

    for (int risOwWMszIjMgQZ = 683380819; risOwWMszIjMgQZ > 0; risOwWMszIjMgQZ--) {
        LneAUDiGXenygGp = LneAUDiGXenygGp;
        oNfxUMoazZCZjTY = ! LneAUDiGXenygGp;
        aIznUWEsx -= aIznUWEsx;
    }

    for (int XxPRR = 453155039; XxPRR > 0; XxPRR--) {
        dzcRceukX -= dzcRceukX;
        oNfxUMoazZCZjTY = LneAUDiGXenygGp;
        aIznUWEsx += aIznUWEsx;
        oNfxUMoazZCZjTY = ! oNfxUMoazZCZjTY;
        aIznUWEsx = dzcRceukX;
    }
}

void SHeTw::poqQZWaue(string oOtbqLBHTRdOtV)
{
    string KnNVXElisGFdBN = string("MbmuYpnGIsnmWQyEFjbBhCSBFQMxenxMmGdWJlWhdoumDpXtIsMLMHpvEUKqDyYxjXbylDSyPsjfkYBLgFPNzLMjHaYevfueGFaHg");
    double hyHPnXHtpBUCE = -378143.79631501716;
    bool dphltFxMNKt = false;
}

int SHeTw::bfTdlx(bool wQroJCWcWdwwn, double OJkYUITWwV, double qVtlWbX, bool yReXXItNCoyEhjX)
{
    double jIdNOZVtCU = 192245.87794650142;

    for (int tOUQlQpuZXftdEeq = 728407681; tOUQlQpuZXftdEeq > 0; tOUQlQpuZXftdEeq--) {
        qVtlWbX = OJkYUITWwV;
        jIdNOZVtCU = qVtlWbX;
        yReXXItNCoyEhjX = wQroJCWcWdwwn;
        qVtlWbX *= qVtlWbX;
        qVtlWbX -= OJkYUITWwV;
        qVtlWbX -= jIdNOZVtCU;
        jIdNOZVtCU /= jIdNOZVtCU;
    }

    for (int ijxBWWCE = 1032601193; ijxBWWCE > 0; ijxBWWCE--) {
        OJkYUITWwV *= OJkYUITWwV;
        jIdNOZVtCU -= OJkYUITWwV;
        jIdNOZVtCU += qVtlWbX;
    }

    if (yReXXItNCoyEhjX != false) {
        for (int rgjipppKmGw = 1658741724; rgjipppKmGw > 0; rgjipppKmGw--) {
            jIdNOZVtCU /= qVtlWbX;
            qVtlWbX += OJkYUITWwV;
            OJkYUITWwV = jIdNOZVtCU;
            qVtlWbX -= qVtlWbX;
            yReXXItNCoyEhjX = wQroJCWcWdwwn;
        }
    }

    for (int xbnqNqBsAsG = 1482986752; xbnqNqBsAsG > 0; xbnqNqBsAsG--) {
        continue;
    }

    if (yReXXItNCoyEhjX == false) {
        for (int pbXOcypkLTPpyYCO = 1656304820; pbXOcypkLTPpyYCO > 0; pbXOcypkLTPpyYCO--) {
            qVtlWbX = OJkYUITWwV;
        }
    }

    if (wQroJCWcWdwwn != false) {
        for (int HBobuNVU = 322560946; HBobuNVU > 0; HBobuNVU--) {
            qVtlWbX /= OJkYUITWwV;
            OJkYUITWwV = jIdNOZVtCU;
            jIdNOZVtCU = jIdNOZVtCU;
            jIdNOZVtCU = OJkYUITWwV;
            jIdNOZVtCU /= qVtlWbX;
        }
    }

    return 1932265094;
}

int SHeTw::LmCnnnhpuZGW(int qOpdb, double tEmTKx, double KYWPATPoVVtcQaVQ, string rJvzSGZy)
{
    string TjawnSjNAaxbJVuw = string("qpyLqdHuCpgOIEzdtfigLmqeYfWGBqJTiukDVGnrkehreuhQeBkUoEfEAqxjOiYEFQPcSptXFbXCuubWQGjAOKNRWgPBHVXSMRfLmQkZLxoAEMbGwBBjSPVWeymfbrwTG");

    for (int xnzIV = 50884887; xnzIV > 0; xnzIV--) {
        TjawnSjNAaxbJVuw += rJvzSGZy;
    }

    return qOpdb;
}

void SHeTw::pnNfG()
{
    int lyaHEUE = -1286082618;
    bool PLuJzPS = false;
    double MHyxiXwkosfc = -162240.90815489105;
    double hbLngwYYXszTd = -154088.7039731281;
    string oGCHLUbAc = string("voszTAMqOCwEXMcoFhFeBfnPvwEcjPfAocqdUeOrZJiZUfoZtAVCvnlGChwPXoRtlSkamTpQjDQWelMuXpgPxFHStdLLizoRFxBdQZwFUdVQVbiDxCKykkwjnCBjnjShEQvoKAsYMhicsdfNIahnshZPMonLqdGRUaLViocpaEZTFiOBrwVARMLDFPjyoTiXnZWelgzmHpxFrpykDvmuKePgVgnEnxD");
    double eegsX = -798525.8953376835;
    string SzXJDyiuyQH = string("MQeHRuMiYyiFKIbhwvdyWyehiwghxltUwbjBPeVLsbykSBwcGetzDmHvXjgSCNXXEaDDgEnfvXszsBpdhXitvoalzELPSKuJbEBWdjMDOtpRboXUftstlj");
    string CEsWsh = string("zevDtsHesxCeHAnouaOSVrgjJGFhcxxywyWaHZfuRxfjItBDETDBlSpiLJVrtWsdWCuOWiSJSpmlGLgMsXHsUzEGejTjqDIrxsnYIOMUcyoarnMgmTRcFhAvBuhCbGptytIZYBPCwkzSHswhkDbfcNyHkUItzXXkCFSFhydLySDwjxqAPVklHwqXhlAajzkKORxVKHInPywJUfzYbZgaqVtIgPEnucHMnZLxftRMlAiP");

    if (MHyxiXwkosfc >= -154088.7039731281) {
        for (int qukMbBMd = 1488478373; qukMbBMd > 0; qukMbBMd--) {
            hbLngwYYXszTd *= MHyxiXwkosfc;
        }
    }
}

void SHeTw::vjFclHfgeiVMcp(double sxCKUhMNqCVUdI, double omfIWSHlcIH, int OitXSKrKtj, double JyToju, string OPaEpEmbOvNmNTU)
{
    bool evzZUFZuTknqjRN = false;
    string SIUhFSzWX = string("DSyBcfAGMnFNmuItvOQPBAUfNFfslFXNkVHnngMcERvuqewzblUHLUQJpPnTaDuwpCCONzcANHWlmVognvwTajzznNmvPrUgWgFg");
    double CCRMACkQXXlFL = -186257.19580011934;
    string APfuYf = string("hwvLGnOEmZyogZBRICMAKyuucFjvZuLHoKvtCaSHREBMcElCipcAWujLckKeFKXzZVisqZstgiIVzvkrUbHAYltJyeKJwqTkgCTMjHonkPBrIjphdTzmNMCTTEjCXMmVISPBdKIpCfqAiKbIxdveEBqvemvRtwIZSJcndDSztlrkkqtczfVFCQsyqigBPBGoZQUlaXn");
    int UJLTbrk = 1331372979;
    string bkXRmvmNG = string("YxoFmyEvWCaIaAJwlmiZYPMGpfQllhCVEaQJvtjbUexVqYfLGyPWbtWNwFAypGKOziOqxHadgcjnMGQHzQryqRuexdumhvbKTfaBOAwyACNIYHJubycXNFIzyVDaLttOrHzGcdNqHPoHOTQTWfqbqGNnKbFWspOfmcESZTkoQChJXUDgRLvDrRkPpsHlROqBxqATZPsKNtRgMKHPHRAOiAJPqEhJcYYpWfzQaHidtSovhAfZNDDWocWAmvuelMA");
    int IvTdpaCsmNeyQ = -147114815;
    double nvAnlLbatFADkK = 758541.2090615168;
    int ALdozriWsrlNwNM = -710963059;
    string BVsfBESrSzdRmqN = string("uPbbjjManzxeffXfKPmcMmWFpamakRxbtDyZljIrpwfmtdmaDWRioKIWHmobZuGystPaQGROQrnSLstuEVedrHGUqqzJIzPSSaprPofesBsofyTTCzmpghAqcdmHuRRyypstytKQUZcvNLrIOlgQAFmzEQZCYzxDCyXXIbCHeTLPNbCuQTQlnjqBUcFWRmrQTqABGFGHwoblpVmBqQXZElzBdLzkDtuCStdJqlyaCk");

    for (int xzgEuIgbN = 1809728304; xzgEuIgbN > 0; xzgEuIgbN--) {
        APfuYf = APfuYf;
        CCRMACkQXXlFL -= CCRMACkQXXlFL;
        ALdozriWsrlNwNM -= UJLTbrk;
        CCRMACkQXXlFL -= nvAnlLbatFADkK;
        BVsfBESrSzdRmqN = APfuYf;
    }

    if (IvTdpaCsmNeyQ >= 1331372979) {
        for (int wwOHkfXQ = 518527898; wwOHkfXQ > 0; wwOHkfXQ--) {
            OPaEpEmbOvNmNTU = SIUhFSzWX;
            ALdozriWsrlNwNM -= IvTdpaCsmNeyQ;
            JyToju /= omfIWSHlcIH;
        }
    }

    if (APfuYf == string("yflWpretZdyXISYcbIAFCvBpPMwzJgDgzEYqYyUXoTlwpStiADWIoroWxREbtjBMOCqpjTxLMcjIZpickTFWTCPJYzoIBaJQHWkReMIvl")) {
        for (int fguEmvwQB = 499337986; fguEmvwQB > 0; fguEmvwQB--) {
            BVsfBESrSzdRmqN += BVsfBESrSzdRmqN;
        }
    }
}

SHeTw::SHeTw()
{
    this->QjPKAQpJavSQOhm(125484.75890557491);
    this->ipcbEgA();
    this->SWkiCajNyd(-572121071, -285540.96908838535, 2104951056, -306461.429619283, string("RbLQz"));
    this->PUTGUJkdn(699365.6620734789);
    this->bJUpEBqhDzeL(100374.70570320978, string("XSUppXrcJExmBNoqE"), -860645.6872531303, 566830.3725075325);
    this->AaRfiApeqB(-966046283, string("RVVgOmXxaBJnLrdCcGqgXMPjjOfjJSxeUHZFLflMFqzHUAtlLNDInXoGUymmKjMidNYBYbuCioCQOyAQwKmSnpgSTLSmZAUDFNYGMkDIOyULuNurzoaeqGNtiDCrHmGmUNoNAApqkCRBlWmmaJvpXPaybLrsUwPNvXrJDbvvwjXyTBJSYxbvuKUBHsC"), 835550.5786994215, -1008095.2852302989);
    this->fxIGhJ();
    this->poqQZWaue(string("ZyEuNCAfvLMZfjuimGvQuZCRcerIjfIMUYKpubjQGdW"));
    this->bfTdlx(false, 673633.6389805473, 94170.69847800912, false);
    this->LmCnnnhpuZGW(-1223641391, -972432.0045964809, 736129.9179000851, string("qlMrFSpqhkNEqAxxaTeUWpBEEUEqQrwWnKaoYBCAtzciSTshmtzqffRUamGcZtiwhfIVGryrpUhUHotrhHhKBmGmdByJTyXZpVDntmBiDETQyzVPXgpmaiotmzjxowGCJrHuRJpjlfzZjoFXcBCHyKzvmOzUePz"));
    this->pnNfG();
    this->vjFclHfgeiVMcp(-575272.8169200233, 775996.6397375794, 1481106412, -848271.7067172749, string("yflWpretZdyXISYcbIAFCvBpPMwzJgDgzEYqYyUXoTlwpStiADWIoroWxREbtjBMOCqpjTxLMcjIZpickTFWTCPJYzoIBaJQHWkReMIvl"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wwRlkVYvC
{
public:
    int rimYXa;
    double aGhjDEonsPvrj;
    double MQDCavwvLqwL;
    double SufLkmRRcG;
    string UqNFpN;
    string SIZtCcahfR;

    wwRlkVYvC();
    int DlWzKDFtMXlE(int WOeZm, int aVRmvAVsDmhKPmTq);
    string TJRUyT(bool uhDCHpQkuvpRUeR);
    string amcleieQej(int dVdxINMITkwlFZ, string kulrcHFlLhbED);
    void JuvbDgTqb(int aanSIxO, double fiXntTyIWkRZN, double reDFCPeh, bool usrsTTzUEQqGQX);
protected:
    string sdNkfREnqG;

private:
    string bJFeGRSaWNetBdHE;
    int OyeZkQaPRcpgGo;
    string gXEelyvyPsU;
    double PEoIJ;

};

int wwRlkVYvC::DlWzKDFtMXlE(int WOeZm, int aVRmvAVsDmhKPmTq)
{
    int APvsWJy = 1187473170;
    string ZsVgMSnIJ = string("XQTLUimCOZPJWv");
    bool QNJExxXiF = false;
    string eEdQA = string("QAuHznMRUbpZYTbhlcJPpEQplPxEtkCaDw");
    string aMNWAVNSn = string("GDfEXtekAqIeTVODnJXbPozaYYYPGuqYRUbOUMUtMwNdloJUplUAWqayqsgnavOMnkjVQnknJQKvYfWDPgSwitnCArwEVONFQSAaeRpJtdjUqLVzwWxnUowmVdfRipIVWMNPtNKonPUjdKDfofPNXlsFokZxUeEdIGNipDCzkclIsfCRDFEYhPPICaPMafndgXgBSaMxXoHkoHIarBGajWEMSbnJSxhfUZGwSYiISsHYovVmRnvtuVJIIbM");
    bool oRWnFZyiaNnTz = false;

    return APvsWJy;
}

string wwRlkVYvC::TJRUyT(bool uhDCHpQkuvpRUeR)
{
    double XFmyaHVm = -279880.4249131256;
    int AETsJjQgOiSnNw = 1455578724;
    double qBWspVw = 162913.41444815535;

    return string("jChTxEJgSmTefDNBGnRUhXxZidJdBudLkRzeFiYSJfIVaqNpHqtVzUCZx");
}

string wwRlkVYvC::amcleieQej(int dVdxINMITkwlFZ, string kulrcHFlLhbED)
{
    bool EupXVBSkaqbkPzHJ = true;
    int QyzfZKPwqu = 2130890384;
    string BiLDOB = string("dQPZCurtaoljlLZNgpviNHULqXihZSadJNbRmsrOzFtOLbPChUtlXrGlIdAGfAsJOeKsKEXSiGsIHcRgAKAJIXydjdvHrvekNtmYmtEgTTsPZoBrfwQwkvaiqAzIZAVXSMcyGKSLOpPDPsZkBiaDIVlezuzrWUDuJtnvgMgFcxbJBojUYWnJEVfgVHTmijLlzMwIuMTwiZcUEteuYsTJcgjhixmlYFAYKctR");
    double vogPzREstMGmY = 93602.0217895581;
    bool DUSNiHQAvkzRMN = false;
    string fmOJdRESCX = string("YwuwIcWONmLONYwgFaCSKpHPDdBmdBBljkGsxDFDExEVPGCrwcDOvzeSUnltyEMhRWrgoGbDDZXEkkzIkTldXnRPJcuXRfEmjedQTFmVtuaDdSUTZwhYMCZsmuEaUtilDThKLBuvBZEwuceENjDcVoHazFgACVRxJawFiLQssPLiULDWLWdnBnpWxyHWKuJIEpFZ");

    if (kulrcHFlLhbED >= string("dQPZCurtaoljlLZNgpviNHULqXihZSadJNbRmsrOzFtOLbPChUtlXrGlIdAGfAsJOeKsKEXSiGsIHcRgAKAJIXydjdvHrvekNtmYmtEgTTsPZoBrfwQwkvaiqAzIZAVXSMcyGKSLOpPDPsZkBiaDIVlezuzrWUDuJtnvgMgFcxbJBojUYWnJEVfgVHTmijLlzMwIuMTwiZcUEteuYsTJcgjhixmlYFAYKctR")) {
        for (int kLyqSL = 1583138209; kLyqSL > 0; kLyqSL--) {
            BiLDOB = kulrcHFlLhbED;
        }
    }

    if (fmOJdRESCX != string("YwuwIcWONmLONYwgFaCSKpHPDdBmdBBljkGsxDFDExEVPGCrwcDOvzeSUnltyEMhRWrgoGbDDZXEkkzIkTldXnRPJcuXRfEmjedQTFmVtuaDdSUTZwhYMCZsmuEaUtilDThKLBuvBZEwuceENjDcVoHazFgACVRxJawFiLQssPLiULDWLWdnBnpWxyHWKuJIEpFZ")) {
        for (int FVdSq = 1030681870; FVdSq > 0; FVdSq--) {
            fmOJdRESCX += BiLDOB;
            dVdxINMITkwlFZ += dVdxINMITkwlFZ;
            BiLDOB = BiLDOB;
            BiLDOB += BiLDOB;
        }
    }

    return fmOJdRESCX;
}

void wwRlkVYvC::JuvbDgTqb(int aanSIxO, double fiXntTyIWkRZN, double reDFCPeh, bool usrsTTzUEQqGQX)
{
    string qlnqqbVtsBw = string("fzcOVcPpBLHjYSsqqUGAvbfGQOhNTUWUakkOAvMnXfIxJLNvunJoDvlFFgrWmdoGCjhhwPnAQZfxkHbNIHlpawbLOrMQwEbXCJGiMYgJCXKerYPnqBXaEFIVgHCxOaHfkRFofMAqrorKBkFbuoJhfyefUhHhXYsIPMVdzoKCAJJEtIQm");
    string vPjPYpNWSLle = string("dVCZMBAZLwyyO");
    string txKQAbnLQ = string("AwJMwILnOnhsiQsLWzZJrOHzBkCWMeYynUBseVRAFXHTfhGlq");
    int OOXQjlHpmOG = -136516122;
    string xrnqflsMfFLqxd = string("qQEFbWtKvXpckLqgUUtBY");
    string FPuOMC = string("nTVpzNoanWMZbwaHQQNeMiOlOFnEOHMkPxwCzcouCJmnGAgkVAtBRNtQWtEIujqgpljRREyayecfJflFgMcNmbqbBIEhCYPKNIPnbjFkABRCKRNnNLNqfTbvnUcYZKYPpbpArsHEqFOwNKdJRwIvsutQJfYmPVobVkMCtUZXkBItYWrr");
    int dzitOHtetw = 886473070;
    string jCXFevciBr = string("uMJduzLGALetAInatJ");

    if (txKQAbnLQ > string("qQEFbWtKvXpckLqgUUtBY")) {
        for (int OOzCMGyrqVChF = 485221078; OOzCMGyrqVChF > 0; OOzCMGyrqVChF--) {
            xrnqflsMfFLqxd += xrnqflsMfFLqxd;
            txKQAbnLQ = xrnqflsMfFLqxd;
            aanSIxO *= aanSIxO;
            FPuOMC += qlnqqbVtsBw;
        }
    }
}

wwRlkVYvC::wwRlkVYvC()
{
    this->DlWzKDFtMXlE(1442365567, -240927877);
    this->TJRUyT(true);
    this->amcleieQej(2008335640, string("KOZcoayuqJxRJTzvtWUUlYApmHgcpPiczBHBLwvYYsdZCfLZlzmYNINTSzXAJgAghNyexbAXqcUsLKNkVWrjANkrKQEZRrokYBIHuGFaIMzvptJJdK"));
    this->JuvbDgTqb(1137163213, 289507.32621246367, -252804.9269027366, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UOPfefugfKnpB
{
public:
    bool qjDWra;
    bool CHKHyXhqb;
    int csIqSwJRleDqXrx;
    double jLTPDBHQPNHbu;
    int merqF;
    double jsdilwNoRvvIuhx;

    UOPfefugfKnpB();
    double AUkFTftAwCq(bool hCWPRcKGsxGWo, bool KmiDflsDvHokALL);
    void sEnWGcIZDXLwucWX();
    bool jrotmW(int rwdfOyHpYOVqbYYJ, bool gIIDPeuSqWzbLCS, bool KDBIQYnQEbCR);
    int YnnIfwVrnlpilv();
protected:
    string IoBJSmHHlgj;

    int hQYsuFzQUoVAb(double IfZdVmMjdImo, int QaNgPkEHLcB, int qndipiLPHgnIvGK, double dGguqJEtambpt, string AHJnLeViScLBnPkq);
    bool AWMeZ(double dmfQvDXp, double CbgvZuE, bool OHbiyCLoc, double EhSrsWxrbQm, int rycgGIXNyTUveAZ);
    string GhXiAlrByaDMWDND(bool hSJHGRwVnWU);
private:
    string LJsUPxATanUkVzP;
    double vwVAXb;
    int SNpauyUN;
    int utwffrPrqsFtyNtI;
    string yZZIBIgI;
    string mhtycpRvskNroq;

    void UHPrLIUXeBz();
    int zSCxkhitug(double rcntvC);
    bool bmnnSrFs(double WTWtwPsJRtqgk, bool upeDzjH);
    void NAFBAuB(string eBLQOgLCAadFvmTn, string CwBUzzjeXLiWqb, string GywFIt, int muRBqsEjR);
    double cXngyqzGg(double RRyoioPqhiRzVv, int yDGEKwYEE, int BsKxHmbeewyfJhFg);
    string AqQnJsMKnLUL(bool MJRxZAsqzqgj, double LBBSQkdKbdTGgpA, bool iHZulg);
    void UdcxvAVFXfJsxlx(int ENAGtvS, double jEIuRGOUawIqUv, bool LkPCpMxudmM, int InPjzrMClU);
};

double UOPfefugfKnpB::AUkFTftAwCq(bool hCWPRcKGsxGWo, bool KmiDflsDvHokALL)
{
    double gWHgatHewUZK = -194953.1862098351;
    int JUUXjSTYnumjDl = -227976359;
    bool reaNQXhBdiCRFULc = true;
    bool mqUyozjSmGX = false;
    int rtNyZn = -1443877243;
    bool xyKjNFtQ = false;
    bool HlzvXoYOBIWmi = false;
    bool yZctvWVpHf = false;
    bool FVJnBlluzJlDf = false;
    int HRAzlIZjThLP = -682128800;

    for (int OICGnFQG = 1994780686; OICGnFQG > 0; OICGnFQG--) {
        xyKjNFtQ = HlzvXoYOBIWmi;
        reaNQXhBdiCRFULc = HlzvXoYOBIWmi;
        FVJnBlluzJlDf = FVJnBlluzJlDf;
    }

    if (HlzvXoYOBIWmi != false) {
        for (int OoyGXISSZTPxHAI = 1229652537; OoyGXISSZTPxHAI > 0; OoyGXISSZTPxHAI--) {
            KmiDflsDvHokALL = ! reaNQXhBdiCRFULc;
            KmiDflsDvHokALL = ! xyKjNFtQ;
        }
    }

    for (int rSbaxEJmVM = 993446500; rSbaxEJmVM > 0; rSbaxEJmVM--) {
        HlzvXoYOBIWmi = ! HlzvXoYOBIWmi;
    }

    return gWHgatHewUZK;
}

void UOPfefugfKnpB::sEnWGcIZDXLwucWX()
{
    int ZUguPOwgBPMgbwHr = 2029869981;
    int uENFR = 391156748;
    string oJxgaJLJJu = string("dHOqFOLfECoPvM");
    bool NXfbGtLLznKqoPis = true;
    bool XCmCRkinQGAAAZLN = false;
    int TOachZBbUGgQgmA = -1417544286;
    string FHMRrEKBB = string("YxMTaDuDvQUCCSEqxlPWGwXbMTBHSNlHcCrWCzhuFzVeXBGTmPIEJKsOgCUeKLHSDCAwzqjeStukrZFldZBySdGDfsxZbRLRZZhMXqtkLFRMcvnoszrjqRZoyZKJaCzBPXGMRtbVEsWShcoENvwDMUDqZtdpUcDidQUridISKWfoAzGsWMGEPlvQkoPhpDArmMiScFnldDIqypEvqCWkpMjRsWr");
    bool locPxalb = false;
    bool lejsTaAM = false;

    for (int eylrAYIuKwuXaLA = 172896285; eylrAYIuKwuXaLA > 0; eylrAYIuKwuXaLA--) {
        uENFR += TOachZBbUGgQgmA;
        NXfbGtLLznKqoPis = XCmCRkinQGAAAZLN;
    }
}

bool UOPfefugfKnpB::jrotmW(int rwdfOyHpYOVqbYYJ, bool gIIDPeuSqWzbLCS, bool KDBIQYnQEbCR)
{
    double VfdjSVqOrikFoUAl = -66189.72727977605;
    bool AhqzNk = true;
    double HMjKThbNygX = -653272.7432461317;
    bool vySqfzPthd = true;
    bool XtKLGWGO = false;

    if (rwdfOyHpYOVqbYYJ != 459825664) {
        for (int RmrHrSnPTzs = 483304156; RmrHrSnPTzs > 0; RmrHrSnPTzs--) {
            KDBIQYnQEbCR = ! vySqfzPthd;
            gIIDPeuSqWzbLCS = AhqzNk;
            vySqfzPthd = ! XtKLGWGO;
            gIIDPeuSqWzbLCS = ! XtKLGWGO;
            KDBIQYnQEbCR = ! KDBIQYnQEbCR;
            VfdjSVqOrikFoUAl /= HMjKThbNygX;
            VfdjSVqOrikFoUAl += VfdjSVqOrikFoUAl;
        }
    }

    for (int XSGHCDgBbBWgjOD = 333628072; XSGHCDgBbBWgjOD > 0; XSGHCDgBbBWgjOD--) {
        vySqfzPthd = KDBIQYnQEbCR;
    }

    if (XtKLGWGO != false) {
        for (int FODtoCpLaDvGE = 1698552620; FODtoCpLaDvGE > 0; FODtoCpLaDvGE--) {
            continue;
        }
    }

    return XtKLGWGO;
}

int UOPfefugfKnpB::YnnIfwVrnlpilv()
{
    int JMOSsfsRRilAQSFy = -662906509;

    if (JMOSsfsRRilAQSFy < -662906509) {
        for (int NZDJHpsL = 1601735886; NZDJHpsL > 0; NZDJHpsL--) {
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy += JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
        }
    }

    if (JMOSsfsRRilAQSFy > -662906509) {
        for (int wOBKVnRrLdixOoH = 1882438178; wOBKVnRrLdixOoH > 0; wOBKVnRrLdixOoH--) {
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy = JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy += JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy = JMOSsfsRRilAQSFy;
        }
    }

    if (JMOSsfsRRilAQSFy > -662906509) {
        for (int cBwnRJVRkO = 1365114294; cBwnRJVRkO > 0; cBwnRJVRkO--) {
            JMOSsfsRRilAQSFy = JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy = JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy += JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy -= JMOSsfsRRilAQSFy;
        }
    }

    if (JMOSsfsRRilAQSFy != -662906509) {
        for (int MgSRNFqcLwdTNCAr = 626928704; MgSRNFqcLwdTNCAr > 0; MgSRNFqcLwdTNCAr--) {
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy = JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy /= JMOSsfsRRilAQSFy;
        }
    }

    if (JMOSsfsRRilAQSFy < -662906509) {
        for (int tOePEwLzMFFaI = 990778463; tOePEwLzMFFaI > 0; tOePEwLzMFFaI--) {
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy += JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy += JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy = JMOSsfsRRilAQSFy;
            JMOSsfsRRilAQSFy += JMOSsfsRRilAQSFy;
        }
    }

    if (JMOSsfsRRilAQSFy >= -662906509) {
        for (int zooDjiubkzO = 693791106; zooDjiubkzO > 0; zooDjiubkzO--) {
            JMOSsfsRRilAQSFy *= JMOSsfsRRilAQSFy;
        }
    }

    return JMOSsfsRRilAQSFy;
}

int UOPfefugfKnpB::hQYsuFzQUoVAb(double IfZdVmMjdImo, int QaNgPkEHLcB, int qndipiLPHgnIvGK, double dGguqJEtambpt, string AHJnLeViScLBnPkq)
{
    double UMEwJo = 220105.8007125708;
    bool NVwhuejQNvfZ = false;
    bool HUzFNjXYLV = false;
    string lfIeHW = string("cQsYCBoAzhCCTGNYXRCpbbyykQEeGoTexqIZiWyLIyfCSdrrVwuzRkvvkoeHuIFigjxBAHslmIvdFTJsVqROgYeuJvsBZccDuVfmbnZEMQAllKYuloptwJCwHkQZfXNhCrFoAzfdGalRhhstygPJoCWD");
    string uSIEj = string("onwNWVLEZbBKrpeQuqhzvgvEkSyGSsVxNWNIPsqhNpLZDymyjwEbBAClNqLNEoCSokVpakjYDCiXXczDVozOOgZUkdWyjvYKlXnuu");
    bool ptQDqksvCnMlbcdR = false;
    int yCJgdDabPYlBMojQ = 167991647;
    int TcTcWjmKUzagG = -630613686;
    string IHemZjRPIeO = string("fhvpWMTLfFAhfbNmRcTdqAyeYgCOTBQtuRLpQSUbTGZlNLXZRqFulaHyrZUExdOXnxdWXdfvwUryAdgnPVsQvqxNOqqPxpfGwSeyUiFGqBEDssHAIoeCxXesjFKbrpptU");
    int XSoDibxphbKFtWX = 1086231064;

    return XSoDibxphbKFtWX;
}

bool UOPfefugfKnpB::AWMeZ(double dmfQvDXp, double CbgvZuE, bool OHbiyCLoc, double EhSrsWxrbQm, int rycgGIXNyTUveAZ)
{
    bool VafDKhvVa = false;
    string iiaoWwQQIGx = string("WLeJOXRRXLlUeiWpRjLYQhWKmewNbsFWaHHoGqCHpklHXbVSWdwzpCEkqBOZLmHUldFZHhjsVZONIfWZjfceIJWXqfGYNEziVhXUgJTPOEoZCBUTtvhKhTwPslYLFWYDFoUcfdblXnkgChKgc");
    int jmGkLUVCUkyWP = -100076746;
    double YdUYEDbbd = 936879.8459883695;
    double EFjokmzaJd = 990219.7749637283;
    bool TwzRSmGZ = true;

    if (EFjokmzaJd <= 936879.8459883695) {
        for (int vQxXVHG = 1995094319; vQxXVHG > 0; vQxXVHG--) {
            EhSrsWxrbQm *= EhSrsWxrbQm;
            VafDKhvVa = VafDKhvVa;
        }
    }

    for (int EdvNjd = 1537285229; EdvNjd > 0; EdvNjd--) {
        CbgvZuE = CbgvZuE;
        VafDKhvVa = ! OHbiyCLoc;
    }

    if (EFjokmzaJd <= 136924.0860732972) {
        for (int onXeQn = 1675380945; onXeQn > 0; onXeQn--) {
            TwzRSmGZ = TwzRSmGZ;
            CbgvZuE *= EFjokmzaJd;
            iiaoWwQQIGx = iiaoWwQQIGx;
            rycgGIXNyTUveAZ /= jmGkLUVCUkyWP;
        }
    }

    return TwzRSmGZ;
}

string UOPfefugfKnpB::GhXiAlrByaDMWDND(bool hSJHGRwVnWU)
{
    string dlIrYhFSGaY = string("OoKOPjbAXmhLOTPmzQrJMHeSZoofHBDNWCFZoHGfqENnyrymfhiKTgONvjvbkYZXLDrZKCjZClDLCumxixDITymDrRneBPJaLHipiaUaeDAZXKeLeLByOTKJWHivLxQFCpBLIxWtrQpfTlUcyfKfFNawPG");

    if (dlIrYhFSGaY > string("OoKOPjbAXmhLOTPmzQrJMHeSZoofHBDNWCFZoHGfqENnyrymfhiKTgONvjvbkYZXLDrZKCjZClDLCumxixDITymDrRneBPJaLHipiaUaeDAZXKeLeLByOTKJWHivLxQFCpBLIxWtrQpfTlUcyfKfFNawPG")) {
        for (int YuWYusgnKGJSlO = 1421523712; YuWYusgnKGJSlO > 0; YuWYusgnKGJSlO--) {
            continue;
        }
    }

    for (int bwWoNyHAzC = 1187054080; bwWoNyHAzC > 0; bwWoNyHAzC--) {
        dlIrYhFSGaY = dlIrYhFSGaY;
        hSJHGRwVnWU = ! hSJHGRwVnWU;
        hSJHGRwVnWU = hSJHGRwVnWU;
        dlIrYhFSGaY += dlIrYhFSGaY;
        hSJHGRwVnWU = hSJHGRwVnWU;
    }

    if (dlIrYhFSGaY < string("OoKOPjbAXmhLOTPmzQrJMHeSZoofHBDNWCFZoHGfqENnyrymfhiKTgONvjvbkYZXLDrZKCjZClDLCumxixDITymDrRneBPJaLHipiaUaeDAZXKeLeLByOTKJWHivLxQFCpBLIxWtrQpfTlUcyfKfFNawPG")) {
        for (int klPukf = 478901103; klPukf > 0; klPukf--) {
            continue;
        }
    }

    if (hSJHGRwVnWU != true) {
        for (int YVnvjon = 250519243; YVnvjon > 0; YVnvjon--) {
            continue;
        }
    }

    return dlIrYhFSGaY;
}

void UOPfefugfKnpB::UHPrLIUXeBz()
{
    string AkWDYe = string("KpHJmyUVZSktClBxPZz");
    int JKUgSADBJPIptTx = 864002994;
    string ABNVIzizDhaTr = string("LBbNfSaPXMbnncElAReOTDVdclAkhtnsEgmcaQEFRFbyRHpJTAOrAIaLNVdoqWtwWAyCDHSjfJDpaEJoblHZuXyZavtqlLBKXcVBbnOzGrAKjmaanRTpCVemDARddVvSBLENxAGAStdYtVpxgCSpmaZhftrCFYQZmbBUlRmNpyOLCenHpLbulTziAD");
    bool AJCoyyJEFUHl = false;
    double vZsbOzGbycpbkPVp = -182950.29624912768;
    double IEmmOgrSbgTvm = -325910.69562356337;
    string DBKsVxINs = string("LLeGlhSNYZAsUKzXEyDVGztiBNgOlkbemQjAbegLlTcRjcxrQoiqNNCTvGWFOxsCPIqwmshpalbQTlysGCCFmLYGgWrukIMmcRObqhgQFBamJjTyGDoKRqauHZdJWlSuvPAtNcvWRLPjYnNlftGsToqStkaXMwsESpBXntmAwzlKhhqKqTmlTPjeHfhNRbvHumMwoUMcYPceUKLTScZWGOLdOmxHgLsUmCfRkjzVvdhg");
    int hJiXl = 976787721;
    string FvYFTwVWnkD = string("PfFvkRfuHbtVnOQMJRwOCXlngaMatsKqoIhLcFiixkUCuqFAJwaMpLtqwrMfbNpgaiOkxPLrTliCOzIdhKwrKIkbeFJaTc");
    string NYSEAeKpq = string("LeQfWHBauUJcxiNWWDqHbUXOKwkgtBsZxLmSDhyKHQaLKNdrrkJubNamQdLpFplaiUkQcSwfhSFUqxgOiFJKPwrAZpbYatdUHqUhupPPpJGLsQeSDIiIIvihzKioEaQhrgwAyYOOntojVWlCIGIRyOBcdmqQCTvhcswhwgaDXsTOnCbgjkMyiejwuXUOhtBalKewMtHJxEnmrk");
}

int UOPfefugfKnpB::zSCxkhitug(double rcntvC)
{
    bool rhYZgKBMAfECjlJ = true;
    bool CvHVIqPRqr = false;

    for (int iuKqFFjhsnJru = 1563937993; iuKqFFjhsnJru > 0; iuKqFFjhsnJru--) {
        rhYZgKBMAfECjlJ = rhYZgKBMAfECjlJ;
        rhYZgKBMAfECjlJ = rhYZgKBMAfECjlJ;
        CvHVIqPRqr = CvHVIqPRqr;
        CvHVIqPRqr = ! CvHVIqPRqr;
        rhYZgKBMAfECjlJ = ! CvHVIqPRqr;
        rcntvC += rcntvC;
    }

    if (CvHVIqPRqr == true) {
        for (int ucMbTf = 2042408606; ucMbTf > 0; ucMbTf--) {
            continue;
        }
    }

    for (int LFkaBcRJ = 898230614; LFkaBcRJ > 0; LFkaBcRJ--) {
        rhYZgKBMAfECjlJ = ! CvHVIqPRqr;
        CvHVIqPRqr = ! CvHVIqPRqr;
        CvHVIqPRqr = CvHVIqPRqr;
    }

    return 1057989960;
}

bool UOPfefugfKnpB::bmnnSrFs(double WTWtwPsJRtqgk, bool upeDzjH)
{
    int PzcpzbjdEvMS = -602780352;
    double ChXPIltnMUtchu = -403257.5347369333;
    double QbgpRrXIGX = 559414.2548388023;
    bool xpGafRhAwJv = true;
    bool lStkGTZriR = true;
    bool gjWXIjVzjqxD = true;

    for (int aecckCZF = 1793123468; aecckCZF > 0; aecckCZF--) {
        WTWtwPsJRtqgk /= ChXPIltnMUtchu;
        QbgpRrXIGX = WTWtwPsJRtqgk;
        PzcpzbjdEvMS = PzcpzbjdEvMS;
    }

    return gjWXIjVzjqxD;
}

void UOPfefugfKnpB::NAFBAuB(string eBLQOgLCAadFvmTn, string CwBUzzjeXLiWqb, string GywFIt, int muRBqsEjR)
{
    bool liijAVqIPrSH = true;
    bool ZsJarLb = false;
    bool TIjcRJC = false;
    string knEMjTHz = string("PysueAtPjUuPrczEtogGjhXMVaXQmTMuIppFxFesVfXXVLkpRjtEgVyyaYNDcBTXlDzoRFmMozspaIGlKklwxcaobeGvzdRjhqfPimYEhoFLUGUeyrkFTaMLYLJLrsKruzZSHNpKRHFjOwaXptXWxCSEgQbMwqwiiJORXDTmFbkWkgyCtLue");
    double ViBmEiqC = -190749.269143459;
}

double UOPfefugfKnpB::cXngyqzGg(double RRyoioPqhiRzVv, int yDGEKwYEE, int BsKxHmbeewyfJhFg)
{
    bool XxWEj = false;
    int jDtjGkLpkz = 596678633;
    string YTSJVFMRwab = string("UbFvdjViVbBfkYLtBugjAdMtfbcqCQxBxozRscyvLZjmqeDeQPQIHAkvVWKLlmyOksusLKilcstPtMmwuYnGzgzcmnFflVYKxkPiXYkNiReexREvdrPHoOsXVXMdnpVqLqttpAZdeawqktOnqchsbfQDZGKABdaiTYtnsHOhlqonacutJEMSvcBKZTBolNODQYnxbVPB");
    int mWgQhnGYAiAm = -1334354428;
    double uGozG = 648285.1909848364;
    int KmKtanVZtvka = 1060538134;
    string msjDwSFYBdRGlDSt = string("EzAJdJmaCJRhKHPzBTIiIc");

    for (int vtkcnDI = 313184826; vtkcnDI > 0; vtkcnDI--) {
        continue;
    }

    if (BsKxHmbeewyfJhFg < 1688424471) {
        for (int MtYbZLZ = 2110018569; MtYbZLZ > 0; MtYbZLZ--) {
            jDtjGkLpkz /= jDtjGkLpkz;
            mWgQhnGYAiAm *= yDGEKwYEE;
            jDtjGkLpkz /= yDGEKwYEE;
            uGozG -= uGozG;
            XxWEj = ! XxWEj;
        }
    }

    return uGozG;
}

string UOPfefugfKnpB::AqQnJsMKnLUL(bool MJRxZAsqzqgj, double LBBSQkdKbdTGgpA, bool iHZulg)
{
    int RLMuVDfbrT = -1569337325;

    if (iHZulg != false) {
        for (int pLDFoPFsu = 636762112; pLDFoPFsu > 0; pLDFoPFsu--) {
            continue;
        }
    }

    return string("fkPsoqazGDJoBXTNZsjytzqpExULaISUVjwCQeoSjdnwnfRAUttXNDPAMGddEfvIWZgdQBWuYtYhyxOqpjGnbQcrLftORpQAGZeCuMSofQTMbhRTazmQPtrAulWEQgjxIFMcvwCbeYyeEWMMZljCFzgrMAKNOrBSoWykrBoFjZEUtbAVaxrDnQudeWYHDkavk");
}

void UOPfefugfKnpB::UdcxvAVFXfJsxlx(int ENAGtvS, double jEIuRGOUawIqUv, bool LkPCpMxudmM, int InPjzrMClU)
{
    bool YrsIuWspjnrcoGKY = true;
    bool oGfGXTxDVnPbQj = true;
    bool novxHdEzlOx = false;
    bool UgfvNtFzrnLZCMH = false;
    string JGvYloDUeJZMQIkb = string("JlknXWBSeiBDBrrBhaaCAAQseEygFTOmhmlQRBCPzaysJkstfmFmzxWUoZVdfdfXgrBSeCoXadfWTXemyHWRBnuDlTznKBcuBmqjZxbkVlVhJcXMKAlidljctbpYNjsIZAuxxjkBLvtAilEoPCr");
    bool BfIka = false;
    bool ajJrsScEyZqI = true;

    if (jEIuRGOUawIqUv < 483895.84543290286) {
        for (int NitrmdFzVYrsKB = 1276556642; NitrmdFzVYrsKB > 0; NitrmdFzVYrsKB--) {
            YrsIuWspjnrcoGKY = ! ajJrsScEyZqI;
            novxHdEzlOx = oGfGXTxDVnPbQj;
            ajJrsScEyZqI = ! ajJrsScEyZqI;
        }
    }

    for (int xTzDnJnYmsSHR = 111365090; xTzDnJnYmsSHR > 0; xTzDnJnYmsSHR--) {
        LkPCpMxudmM = ! BfIka;
        BfIka = ! BfIka;
        UgfvNtFzrnLZCMH = oGfGXTxDVnPbQj;
        LkPCpMxudmM = ! novxHdEzlOx;
        InPjzrMClU *= ENAGtvS;
        InPjzrMClU -= InPjzrMClU;
    }

    for (int PrMZWtVbz = 1133159152; PrMZWtVbz > 0; PrMZWtVbz--) {
        BfIka = ! UgfvNtFzrnLZCMH;
        oGfGXTxDVnPbQj = novxHdEzlOx;
    }

    for (int IfRpqpssViy = 299370132; IfRpqpssViy > 0; IfRpqpssViy--) {
        ajJrsScEyZqI = ! LkPCpMxudmM;
        BfIka = oGfGXTxDVnPbQj;
        LkPCpMxudmM = ! LkPCpMxudmM;
        oGfGXTxDVnPbQj = ! ajJrsScEyZqI;
        YrsIuWspjnrcoGKY = UgfvNtFzrnLZCMH;
    }
}

UOPfefugfKnpB::UOPfefugfKnpB()
{
    this->AUkFTftAwCq(false, true);
    this->sEnWGcIZDXLwucWX();
    this->jrotmW(459825664, false, true);
    this->YnnIfwVrnlpilv();
    this->hQYsuFzQUoVAb(-267032.2012859356, 1131295589, 1054607119, -260486.44138281367, string("btjprEPjgGOfbhFFjnhMLyveUgWncBLCzRjLPjHyWhsfRDilVQjaOiVBXWasrqKzEZsnLGSECHps"));
    this->AWMeZ(512523.07117455103, 136924.0860732972, false, -233877.11137196698, -2040465663);
    this->GhXiAlrByaDMWDND(true);
    this->UHPrLIUXeBz();
    this->zSCxkhitug(946250.4260708379);
    this->bmnnSrFs(-218301.79202266637, true);
    this->NAFBAuB(string("xCwQrKLaEFRrECVxClkUZhaQzmOBNHMIfatSZrewIIVkyriJsLhBIcwzkYJWpcndipUSnWZbqlXchVBmIBfkPoKGVMlJuUTAaMomOPXYklVVMlRdnaaGpbKPSgvQywnNBbypg"), string("lyIvNLqrLInzFyYPdWsXfXdDkoCvYFTZNuABBhqpMcOorxhsNUTzwpoTLOqLvORIfvNzbVgGtOjCvNJjmGRgXTGYmyzaORZKCrvYqvRsSqvtuaVZqpOplifJZJdfVPOBcaLZxrHSpNHdporFjccARFaeFpCSidbOnuDSIMjbPISzvPHVmfWUEDCvKGHTVPgXGGdTyJbjbRLfcUVExSnLAHPvJY"), string("sfkGBEdMVFlRKFoHPGkQtWXGMwCBJjwyxfrCaBcSqhPJimxDmxoAjquZLwDLL"), 1123797323);
    this->cXngyqzGg(-821189.892888306, 1688424471, -544606818);
    this->AqQnJsMKnLUL(true, 234544.02420037595, false);
    this->UdcxvAVFXfJsxlx(-782622917, 483895.84543290286, false, -2068720792);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NcBno
{
public:
    bool aSZUBWy;
    double eTwear;

    NcBno();
    string xfidKDUXowbbzLSV();
    int qoWYeDKZ(string sLXavOPvjoBrDp, double zRPjjb, double kNusrGWVvgEonCAU, bool gDDxGkLZPUUPdEpq);
protected:
    string DnroSnzRYyfsaKpe;
    int otUJYuVavltSL;
    double fKzDLIAZRZUkmlt;
    bool QZRZIuEOReesqt;
    bool ALnZEUnbrLSKCl;

    string EvnzVxdesf(double EiyiWXfzQDaaX);
private:
    double xvlhiyusXIeLz;
    int ZucDZWaUdbUZMZ;

    int gqofPPMNvMWiQYP(int LaKwcFs, int WBxwWmxTFRM, string YRRbfEzKkjlrud);
    string OILrhJoyMKYaEw(int jLhCTOYgyZ, int JBEtNJCwxiFk, int dfwWKFNCQHSSToL);
    int SZOfKRAa(int ElrAqGJSjJBUsQH);
    void WxfvlPNX();
    bool lnIGTJd(bool LcBxMEKXd);
    double wwWVMMiFlBkxw(int LTLJfxsgqPIs);
    string QrbpEDPXmgGiQMHK(int FMlNQCQczxzz);
};

string NcBno::xfidKDUXowbbzLSV()
{
    string Wkxklmuza = string("BfKLldOxXcRyKXRXSLhSGjVsTTNFjRqONgwDwsDMKSjBbQXWUCPflZvyzOPvJyRyqpUsyNVlQKwGvJyVBHNWIbPXZPDmdIcjeRkfrufSzViTWVvWvZUQoMUbbhXaqXYiLpErtrHBsMbCiPGVHRMsdimwOFsYkRVkhUUlSkpFKX");
    double suTOdry = 916112.5705013772;
    string iUAfCorntUl = string("OatBpvnQQOgvlypQDzDmRmPLGlEfNEgkqwvSMphPwbtKnaOKgJARzFwfkcasJiRfjCjiUFGIhMtxvsofkLrCECjLKwFMScyvcLMYJcZIAHGOEOtZBHVFBUrZyUSXvEgBTNdLvxBxbgRWjfbmgFPIjDvvXwzBQTumRXASwnVzWgJUtvPnhjinWiDVifGPokwcgu");
    bool FmrEvaZnER = true;
    string YqZxjlaTkJGoxsP = string("erCuabEPFImGslMrxdQvzkWLlLeTWwcJXyblOzeZqeQRNhtxdqaJyrkRtmNrQcoPbAfQJmksIipJvTEhgvRqhINacmJQnAEqsArLjyTrYhJGaTViDGhTldefjdenKQpkJiUuKhdbXTfOOfa");

    if (YqZxjlaTkJGoxsP >= string("erCuabEPFImGslMrxdQvzkWLlLeTWwcJXyblOzeZqeQRNhtxdqaJyrkRtmNrQcoPbAfQJmksIipJvTEhgvRqhINacmJQnAEqsArLjyTrYhJGaTViDGhTldefjdenKQpkJiUuKhdbXTfOOfa")) {
        for (int mHENTwBq = 436756816; mHENTwBq > 0; mHENTwBq--) {
            Wkxklmuza = Wkxklmuza;
            iUAfCorntUl = YqZxjlaTkJGoxsP;
            FmrEvaZnER = ! FmrEvaZnER;
            iUAfCorntUl += iUAfCorntUl;
            YqZxjlaTkJGoxsP += iUAfCorntUl;
        }
    }

    return YqZxjlaTkJGoxsP;
}

int NcBno::qoWYeDKZ(string sLXavOPvjoBrDp, double zRPjjb, double kNusrGWVvgEonCAU, bool gDDxGkLZPUUPdEpq)
{
    double MoesraKxN = 362148.597313476;
    string OwewEMaNE = string("vwsyovqIQSXXQtlerGZNKFSieapgXodE");
    double RWwgx = -97489.11977941534;

    return 1655862408;
}

string NcBno::EvnzVxdesf(double EiyiWXfzQDaaX)
{
    int MZzZVrgVHobOlDJO = 1613772155;
    string ZEbiQhuThnKef = string("xaSfDuLhUfXkhuGoryLzfawikNpFmPwWHEzujtxxEUkMCEsBEcfWWvakjaMHIeYddVDTdiNFuxDatFUovlXhsKlsByzbrNQUucJglzJLAUvYxpOCBJrYfPHyJUjIYvRALNeSWRRkGnDOL");
    bool hSvDZpGNM = true;
    double HHyZTLMr = 638535.1051905063;
    double TvHZYir = -189406.79498953337;

    for (int SMsoic = 1137480725; SMsoic > 0; SMsoic--) {
        TvHZYir /= HHyZTLMr;
        EiyiWXfzQDaaX /= TvHZYir;
        hSvDZpGNM = ! hSvDZpGNM;
        EiyiWXfzQDaaX *= EiyiWXfzQDaaX;
        hSvDZpGNM = hSvDZpGNM;
        EiyiWXfzQDaaX += TvHZYir;
        EiyiWXfzQDaaX += EiyiWXfzQDaaX;
    }

    for (int MBvxYLeutYuktJNP = 1240307052; MBvxYLeutYuktJNP > 0; MBvxYLeutYuktJNP--) {
        continue;
    }

    for (int JXNKEd = 979568569; JXNKEd > 0; JXNKEd--) {
        TvHZYir /= HHyZTLMr;
        HHyZTLMr += HHyZTLMr;
        EiyiWXfzQDaaX += EiyiWXfzQDaaX;
        TvHZYir += TvHZYir;
    }

    if (EiyiWXfzQDaaX < -189406.79498953337) {
        for (int CpvsZsbv = 1095438738; CpvsZsbv > 0; CpvsZsbv--) {
            TvHZYir = HHyZTLMr;
            HHyZTLMr *= HHyZTLMr;
            EiyiWXfzQDaaX -= TvHZYir;
            hSvDZpGNM = ! hSvDZpGNM;
            HHyZTLMr += HHyZTLMr;
        }
    }

    return ZEbiQhuThnKef;
}

int NcBno::gqofPPMNvMWiQYP(int LaKwcFs, int WBxwWmxTFRM, string YRRbfEzKkjlrud)
{
    double KpmBvhzuyLFKnM = -276939.0407820234;
    int OtyorNd = -894422535;
    bool FXHgx = false;
    bool gYBvtAhTVwUFmKga = true;
    int tHZooZIDGfVo = 490940067;
    bool YNqxgaPUCZaLJaKF = true;
    bool CDDdwUcv = true;
    string oJUrdLBkiUlV = string("siVHydrNfzcVFRLbPJHxnLrVkljljWRdiSgMdyhHTkCFOilCBJPTmRthPbtKsGZmZVasDjXrJGTHqBkAxhbKaXErRiKwVqZNckEePmJwKVDIaANVqTiwiMxGgSmrHtdIUKmyONVsRtCiCbtnnKCzSzsNFGACrRXgceIsaoXDRSdkaIGaqvsCUZZPFljDYqQlTRDAcElQlltGfElfXmkxafCsHpNnq");
    double Burey = -248872.72821135368;
    int KkXcYjUplh = 1120424221;

    for (int cCYpXAKOM = 1025789924; cCYpXAKOM > 0; cCYpXAKOM--) {
        YRRbfEzKkjlrud = oJUrdLBkiUlV;
    }

    for (int UslQUzeD = 544775573; UslQUzeD > 0; UslQUzeD--) {
        continue;
    }

    return KkXcYjUplh;
}

string NcBno::OILrhJoyMKYaEw(int jLhCTOYgyZ, int JBEtNJCwxiFk, int dfwWKFNCQHSSToL)
{
    string WqxKh = string("KQvAzLASfDEsKIRruVFIjQlFWtCNVhNcgmlmdoeOLH");
    string joKjfTsmarktNum = string("LbpAcMxmYQgVXOvKbUAboBBmOxOSjgFaIBizaNYofJZtcblmXdXUcbraDBSuzsrnoUOnIuKUlJEKUwQTvtHFcAWlhCAXsncXmzrmshsGmXNoqsNnFfDHsQbZJGAJVFsvTxawCNOAURCchDIKCzekGFAuLnZFVvCVDUtGjdqhiVdElxXgBkjkmJUndvGkwSElanHTsLNXrurYrouwkwKiYNrMTajiwCjyxnIdZpagDxDTpu");
    string cFCnjlrhwVhg = string("ufO");
    string AfyCiV = string("jYZPFnvZTKMjkyPexqLJCsaxxiCyaunrRGWIEzbkUlTjIgSYBnqMNEYRHrCFejFbFotFMmjIBKYedrgACCLDcXUwzzlUyQKgyxVuZwBKSlzCWfWMlMHwiNCfTWxWwoetWsUZDnOhTQxlIwDxngJOSGDRolHxxDJMVwfZDnEcJ");
    string JffvlRIwfWOYbHD = string("iYUZZfuwJQjdNgWKMlOzgPCRhHdtvBWNOAiGIAmfXIoeiFCKVpUZgNpSgVogXUXYVYvYOofVVgaBNwdKFtAcSiuPqXDSnjmMPPRDBtCPkvutZLdgrZpXomBdRqZffGCaUCGsBrSqrZQGlthXkmVOOcLrVxcXMMANwbfsCAzuzWctybICYvIqHangxfzzjwJrhWKUdhySOBgTufLqOAGlkQHWqYraXbCLhDdysDMdRRtnsktXmjhMmZXKf");

    for (int hUnsD = 750133141; hUnsD > 0; hUnsD--) {
        joKjfTsmarktNum = JffvlRIwfWOYbHD;
        joKjfTsmarktNum = AfyCiV;
    }

    return JffvlRIwfWOYbHD;
}

int NcBno::SZOfKRAa(int ElrAqGJSjJBUsQH)
{
    string pJlgStRelGvnfe = string("lQGesRuuVRPuhBnFsvvHSDrLpxsTwpeJuuOZMqNIWsHaUjUvXCgoSopeAtxDyKqySzqysaDenjzKrPaHIdhjfKskJMTCKOTdhBcHBvNGBBbTThyvjkEPxiRgdFAwjUpiHRCZKrJTsoJxseQzGNHOynIeYtUOHYQuhEXHXRorCN");
    bool sqxNxglNNdihIO = false;
    string oGpRWms = string("UYtYvbOabSHXkwtpwVgHvylwKBxELOTZlAYbVDjwHScauijCzKLHRSYlFLnJNxDYWwbNDyWImRCMeYutQFDJKZtMyYmUbqUxJrQGlHICbUfiRwkdpQTuOUxVxjGRmFuFdvdPGgzMcCSYBNFHgZTgHYESIpYrLpNDneMBkJiaklWVKbrpXUnhWrVvDAbnlTnjUAYaJMsXGrsqSSugnGQkLbQNkMZ");
    int KDzomrenTdbzO = 1281648067;
    double Jhcxhv = 325794.03521681204;
    bool anEwPxWNh = true;

    return KDzomrenTdbzO;
}

void NcBno::WxfvlPNX()
{
    bool AHZvNaUfXSlGKnP = true;

    if (AHZvNaUfXSlGKnP != true) {
        for (int kCIpHtqYMPj = 1968440061; kCIpHtqYMPj > 0; kCIpHtqYMPj--) {
            AHZvNaUfXSlGKnP = ! AHZvNaUfXSlGKnP;
        }
    }

    if (AHZvNaUfXSlGKnP == true) {
        for (int kYORWVLoK = 1307374663; kYORWVLoK > 0; kYORWVLoK--) {
            AHZvNaUfXSlGKnP = AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = ! AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = ! AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = ! AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = AHZvNaUfXSlGKnP;
        }
    }

    if (AHZvNaUfXSlGKnP == true) {
        for (int NaACUO = 1509701099; NaACUO > 0; NaACUO--) {
            AHZvNaUfXSlGKnP = AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = ! AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = AHZvNaUfXSlGKnP;
            AHZvNaUfXSlGKnP = ! AHZvNaUfXSlGKnP;
        }
    }
}

bool NcBno::lnIGTJd(bool LcBxMEKXd)
{
    double EqaidhhwKqGEZb = 38998.75428323831;
    double JYJULFoopLlKoVHB = 340072.5452052947;
    double EzqVO = -750371.6344724443;
    bool neZIzVgCDSBms = false;

    for (int WqwihvgEBSKw = 867696425; WqwihvgEBSKw > 0; WqwihvgEBSKw--) {
        LcBxMEKXd = ! LcBxMEKXd;
        JYJULFoopLlKoVHB /= JYJULFoopLlKoVHB;
        EzqVO += EqaidhhwKqGEZb;
    }

    for (int igSAihSJ = 1474571085; igSAihSJ > 0; igSAihSJ--) {
        JYJULFoopLlKoVHB = JYJULFoopLlKoVHB;
        EqaidhhwKqGEZb = EzqVO;
        JYJULFoopLlKoVHB -= EqaidhhwKqGEZb;
        JYJULFoopLlKoVHB -= EzqVO;
    }

    return neZIzVgCDSBms;
}

double NcBno::wwWVMMiFlBkxw(int LTLJfxsgqPIs)
{
    string XtxhhhdMdp = string("TfHioboeIIscCKWIosEMuAaHXEVIdbzDYGHVTKIrDFmRZlMWKNOLfapYIFtJOiTmCOishRjHOuMUIwapDJ");
    int vSeWNILHopPuzQtf = -534575431;
    int ghfLIPLpUQMUee = 561513789;
    int zctlZmUgrJ = 1540759890;
    string QawUrPxcbi = string("rnLtMeRSEtacyvKVnmljslbnRzjhzMDpBMlpZiecarCFBGnhMvbpavXbayvllmPxv");
    int kDsyRaKugcQFWv = 353053711;

    if (vSeWNILHopPuzQtf == 353053711) {
        for (int wTGDRkktDSvy = 1085790474; wTGDRkktDSvy > 0; wTGDRkktDSvy--) {
            kDsyRaKugcQFWv += zctlZmUgrJ;
            XtxhhhdMdp = QawUrPxcbi;
            ghfLIPLpUQMUee /= kDsyRaKugcQFWv;
            zctlZmUgrJ *= vSeWNILHopPuzQtf;
            zctlZmUgrJ /= zctlZmUgrJ;
        }
    }

    for (int HriLos = 1678250806; HriLos > 0; HriLos--) {
        ghfLIPLpUQMUee -= LTLJfxsgqPIs;
        kDsyRaKugcQFWv -= kDsyRaKugcQFWv;
    }

    for (int VthKuRnCwfPADcE = 1317293767; VthKuRnCwfPADcE > 0; VthKuRnCwfPADcE--) {
        LTLJfxsgqPIs -= LTLJfxsgqPIs;
        zctlZmUgrJ += vSeWNILHopPuzQtf;
        ghfLIPLpUQMUee *= LTLJfxsgqPIs;
        ghfLIPLpUQMUee /= kDsyRaKugcQFWv;
    }

    if (zctlZmUgrJ == 1069466464) {
        for (int kBXVYlolKSdGrcBY = 311373196; kBXVYlolKSdGrcBY > 0; kBXVYlolKSdGrcBY--) {
            XtxhhhdMdp = XtxhhhdMdp;
            zctlZmUgrJ = ghfLIPLpUQMUee;
            LTLJfxsgqPIs -= LTLJfxsgqPIs;
            LTLJfxsgqPIs += zctlZmUgrJ;
            zctlZmUgrJ = vSeWNILHopPuzQtf;
        }
    }

    return -95190.34799213681;
}

string NcBno::QrbpEDPXmgGiQMHK(int FMlNQCQczxzz)
{
    string zXlPfldzG = string("tSpAnclpRlBzOrCqUBziNxNaLoIoQXHOpWVVrPojMhfYjYgrMJgeeViZzqIVzPfymWDQySqnwBDHnZSLmBoSHSWZtfxFPGrEnQJegpsodHUdMPsZhnvJankqzvYpBdYJquyMkImHfdatcoablbDFiXyKYcvdwRjeiGntKpAGeSztSHXuEpXMxZKGeDyVFAeAqBILXcEMvZNJqriaypvIulVgFEhgmHYJBkHLnGF");
    string FvrvSzd = string("vLnAalnApPDbNiDHBYkIidPLJKKxPKrhaBKtdXeFKaCrjZMQkUTQjuSVNXYgWkMqXjOLpFkSyCRTIFWWcnCJIniJZBhOqKtIcCUlpUEyKqfEkSpirCyvlCfj");
    bool WWDXgeGEtNX = false;
    bool AKbBwLYkJjCNMTi = true;

    for (int STCJocYNzHl = 1696660589; STCJocYNzHl > 0; STCJocYNzHl--) {
        continue;
    }

    for (int tJRFFFfCWAZzuY = 371066933; tJRFFFfCWAZzuY > 0; tJRFFFfCWAZzuY--) {
        zXlPfldzG += zXlPfldzG;
        AKbBwLYkJjCNMTi = ! WWDXgeGEtNX;
        AKbBwLYkJjCNMTi = ! WWDXgeGEtNX;
    }

    if (FvrvSzd < string("vLnAalnApPDbNiDHBYkIidPLJKKxPKrhaBKtdXeFKaCrjZMQkUTQjuSVNXYgWkMqXjOLpFkSyCRTIFWWcnCJIniJZBhOqKtIcCUlpUEyKqfEkSpirCyvlCfj")) {
        for (int xErnJM = 2072908479; xErnJM > 0; xErnJM--) {
            zXlPfldzG = zXlPfldzG;
        }
    }

    return FvrvSzd;
}

NcBno::NcBno()
{
    this->xfidKDUXowbbzLSV();
    this->qoWYeDKZ(string("ostAUedWZppebtHbydCJhNSEPDywnQXeICcaYime"), -92947.40168374445, -215387.2145546606, false);
    this->EvnzVxdesf(-54309.15965264651);
    this->gqofPPMNvMWiQYP(-1696617071, 1699078135, string("SHZxguSJylYRgphlsqpwHZGvMaNWdmFzIzecLrXecjchylZUBkQYVtLvLiYMcOhspShneiaKZMMVKjoNJcbXpFdytXJQgdQgORlOKxrdSAJKyTbMIABecsoKABTZQHrYQa"));
    this->OILrhJoyMKYaEw(-666775070, 2053319156, -438764670);
    this->SZOfKRAa(-1202164901);
    this->WxfvlPNX();
    this->lnIGTJd(false);
    this->wwWVMMiFlBkxw(1069466464);
    this->QrbpEDPXmgGiQMHK(-1702953661);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OrEGiIZoheMsKHI
{
public:
    int eWitf;

    OrEGiIZoheMsKHI();
    bool byOXz(int JdbOBclKVqQbJBMK, bool bkMvASeDnrohs, int vbohsuerz);
    int HpFvMz(double AugXGw, string cyHVe, bool hXdhpkEwSkHa, double rdQHQThNulVQuRLu, double JMNDGMxIymhilYW);
    bool CZOoLbfXecUQSm(bool UCpwnnuVTc, string NQWOHKdKqCBvTJY, bool otMivJCerTZSBYiG, int oMgZjS, bool qoqsbHQ);
protected:
    bool ZNTwWJcyLAsjr;
    int LFevmqTTkIaltIu;

private:
    bool fqxLBFpn;
    string lHpSrgpppkdr;
    bool VOjfw;
    bool SdbyvF;
    bool IURXZeDQWpgj;

    bool NbWqpEcVQtPgq(int jjvRcqX, string iRGbVWoIVsNybwLQ);
    string crTCuQLUnfJI(double uFYJMJLomYutz, int NdRzciuYWzY, double jbEVnKDpTH);
    double MIniciJOq();
    void oppKVGs(double WGNGNHCkeCUxqXi, int zdzfeDhZAhdrEV);
    int KXaQvek(string YOSzqhtOsnV);
    string hBtZPcbJnDJREDPl(double VjrKLQGgYjUFvvsQ, int EHPitqkpnqmt, string SGCQC, bool SevZIvIblJt, bool IcylvOOehW);
    void iKIDSnbYozzg(int cIMNlfwD, double EFotbCCj, string KXvvOvAUycCq);
    int UvMSJIO(bool LpERcECagrWF, int EILuqTrsS, double pzFZtjvcu, double xZlEMb, int ogcOGkqIyqRzBPl);
};

bool OrEGiIZoheMsKHI::byOXz(int JdbOBclKVqQbJBMK, bool bkMvASeDnrohs, int vbohsuerz)
{
    string CdRdnlaBx = string("lOcLfPrOrDMWlDvvnLkvQelDBltWPFeqUCftSlVXSZbUAvRCSEZnfqpqlKPWqEYYHgcJJJRSbLiNBSvRJwOzsTzEursxQAeiUbGyIZkovlkPDeQ");

    for (int ywcDtoYEsRgcFlt = 1539141971; ywcDtoYEsRgcFlt > 0; ywcDtoYEsRgcFlt--) {
        continue;
    }

    if (vbohsuerz <= 38395580) {
        for (int qVuxjVhkEoRQ = 1533161103; qVuxjVhkEoRQ > 0; qVuxjVhkEoRQ--) {
            CdRdnlaBx = CdRdnlaBx;
        }
    }

    if (JdbOBclKVqQbJBMK > 362705332) {
        for (int yoDaEFmduhkMNA = 1033235715; yoDaEFmduhkMNA > 0; yoDaEFmduhkMNA--) {
            continue;
        }
    }

    for (int kRvamPLfdQ = 1226175499; kRvamPLfdQ > 0; kRvamPLfdQ--) {
        vbohsuerz *= vbohsuerz;
    }

    return bkMvASeDnrohs;
}

int OrEGiIZoheMsKHI::HpFvMz(double AugXGw, string cyHVe, bool hXdhpkEwSkHa, double rdQHQThNulVQuRLu, double JMNDGMxIymhilYW)
{
    string PLUpaYvYyvzfbe = string("SmLDySGJnbBuHWckJoSjzLLYVbCkajTRlrLKGZRuTjoDGaLvTHRUtZvYgtYRVMAiewHRTGHbECADCbjZwGirnZWiLjKCUTjVuowxACDNqnCsMPtvXuLZWrEPwlA");

    for (int wOSEvWwrAhNN = 298671261; wOSEvWwrAhNN > 0; wOSEvWwrAhNN--) {
        continue;
    }

    for (int ONBjKSYSBPe = 1373584583; ONBjKSYSBPe > 0; ONBjKSYSBPe--) {
        cyHVe += PLUpaYvYyvzfbe;
        JMNDGMxIymhilYW = AugXGw;
        rdQHQThNulVQuRLu -= rdQHQThNulVQuRLu;
        JMNDGMxIymhilYW += rdQHQThNulVQuRLu;
    }

    for (int VlJYedpqNFKsrhyB = 1569947125; VlJYedpqNFKsrhyB > 0; VlJYedpqNFKsrhyB--) {
        AugXGw *= AugXGw;
    }

    return -2110204375;
}

bool OrEGiIZoheMsKHI::CZOoLbfXecUQSm(bool UCpwnnuVTc, string NQWOHKdKqCBvTJY, bool otMivJCerTZSBYiG, int oMgZjS, bool qoqsbHQ)
{
    string hZiGkVsXrsa = string("LLhvFhivSvpCtnasFSTixEHdKPVnuoCpLMlsHyrLAIHTJqaFpfkNmOH");
    int seorDOCpOSBpVs = 1007701872;
    double XnZVGcd = 287140.0704062594;
    int tlAmlIAmXqVAvjPj = 1772628735;
    int iwlGllajpcmU = 1457266046;
    int oCxbznKvPwhTHE = -485400140;
    string ojsnfZDM = string("GYlNWhzAReCDkNwyisHFvtFYrJlogdmmenuLvPNESEDhKBqkJCaBPPyoQkfbzJOnyrSZpNkOtCyDClqeuVnUqhopwMUeUqrIjblyuNTNXQJZmMeTmGKcIwmMyKGHSu");

    for (int MPONXablZsCH = 1935658640; MPONXablZsCH > 0; MPONXablZsCH--) {
        UCpwnnuVTc = ! UCpwnnuVTc;
        ojsnfZDM = ojsnfZDM;
    }

    return qoqsbHQ;
}

bool OrEGiIZoheMsKHI::NbWqpEcVQtPgq(int jjvRcqX, string iRGbVWoIVsNybwLQ)
{
    double dJcbgTlPVUob = -169118.83724707202;
    double maWMcgItAbuLyTpK = -923108.3401914322;

    if (dJcbgTlPVUob == -923108.3401914322) {
        for (int aYSpchrUrr = 779323238; aYSpchrUrr > 0; aYSpchrUrr--) {
            maWMcgItAbuLyTpK -= dJcbgTlPVUob;
            maWMcgItAbuLyTpK = dJcbgTlPVUob;
        }
    }

    for (int nAhWUf = 306160707; nAhWUf > 0; nAhWUf--) {
        continue;
    }

    for (int cGxwDvjfoXXDwW = 430529567; cGxwDvjfoXXDwW > 0; cGxwDvjfoXXDwW--) {
        maWMcgItAbuLyTpK += dJcbgTlPVUob;
    }

    for (int YxfEYdUbV = 358867155; YxfEYdUbV > 0; YxfEYdUbV--) {
        dJcbgTlPVUob = maWMcgItAbuLyTpK;
        jjvRcqX -= jjvRcqX;
        dJcbgTlPVUob *= maWMcgItAbuLyTpK;
        iRGbVWoIVsNybwLQ = iRGbVWoIVsNybwLQ;
        dJcbgTlPVUob -= dJcbgTlPVUob;
        iRGbVWoIVsNybwLQ = iRGbVWoIVsNybwLQ;
        jjvRcqX *= jjvRcqX;
    }

    for (int IPwbt = 1093931459; IPwbt > 0; IPwbt--) {
        dJcbgTlPVUob -= dJcbgTlPVUob;
    }

    for (int TloKXEQp = 128180046; TloKXEQp > 0; TloKXEQp--) {
        dJcbgTlPVUob *= dJcbgTlPVUob;
        iRGbVWoIVsNybwLQ = iRGbVWoIVsNybwLQ;
        maWMcgItAbuLyTpK /= maWMcgItAbuLyTpK;
        dJcbgTlPVUob = maWMcgItAbuLyTpK;
    }

    return true;
}

string OrEGiIZoheMsKHI::crTCuQLUnfJI(double uFYJMJLomYutz, int NdRzciuYWzY, double jbEVnKDpTH)
{
    bool sFrhBVw = false;
    double RrdxRGTIeKJpl = -793626.7781879707;
    bool dbNiyfk = true;

    for (int GiLnurPkOsgJKC = 1061507261; GiLnurPkOsgJKC > 0; GiLnurPkOsgJKC--) {
        uFYJMJLomYutz -= RrdxRGTIeKJpl;
        uFYJMJLomYutz = uFYJMJLomYutz;
        jbEVnKDpTH -= RrdxRGTIeKJpl;
    }

    return string("RuehCtRVermnJIQZgXLmSrNCDLCtYHxEnpTtlavWiZTRpRWRUFfoYKDekONVBguNsiKufLxlPWmaSLykBnhgwTNjcGzyBlrQlpjsGrVaNeCKqwmAMdyFYNiLPNoTkwbnalmPQifKQaVLDbVANuaptIlOURKDFYalvj");
}

double OrEGiIZoheMsKHI::MIniciJOq()
{
    double BtEodyFvFAgHzD = -249945.6818451898;
    double ZUPBIGSUZB = -84204.33036831876;
    int xPUCHNCLwlZCpa = 1484111691;
    string slNMADf = string("pxCNFPJkUIFGnEwLVcExCwwRImUYUunlKSyVpGJqpTIiBWWcWHPjJHqqRYwxhKKxboFGzNRTfAnA");
    bool vbtaFfwDJ = false;
    int kvJJaZyKmOK = 461415263;
    double PFyGouygewW = 1014393.0144804072;
    bool vLePGiXtbtY = true;
    int KFfWttPWDkEpkkzC = -967520243;
    int HPmbkt = -1709814153;

    if (KFfWttPWDkEpkkzC != -967520243) {
        for (int gdgAwigE = 729487452; gdgAwigE > 0; gdgAwigE--) {
            KFfWttPWDkEpkkzC *= HPmbkt;
        }
    }

    return PFyGouygewW;
}

void OrEGiIZoheMsKHI::oppKVGs(double WGNGNHCkeCUxqXi, int zdzfeDhZAhdrEV)
{
    string KZGJOI = string("yqPriabEuqEVTsIseCmxmmIvZbzpcmqNaSIQwcPkBnKGLVYTplOnnilMYWtwWfwMWxFycJbDbesZMgRAGnuVWwFPUNuDWwkXYffNwQEnykrTWhkYeUISXGaRJMJpTRjRWznfphJblPkMlKHsthqoiacwuBzVRmuzyvElvK");
    double AFXikrr = 112162.60729012577;
    bool sBGSCaqFcJTqNqyT = false;
    double SIlEK = 873209.6747989403;
    int yKAZiyZacI = 2120837468;
    bool GNRMmhoE = true;
    int lfzshLFR = -163572951;
    bool xSvMvd = false;

    for (int JDzFVmvOslNDqmd = 1785452772; JDzFVmvOslNDqmd > 0; JDzFVmvOslNDqmd--) {
        continue;
    }
}

int OrEGiIZoheMsKHI::KXaQvek(string YOSzqhtOsnV)
{
    string kcPXHShgobmal = string("atkEjtaqGDcDflXtuCpZdWbUpDScpPbEJEpnKmqfAUSIomzcsueQJSUfmtHaRULJKONghvrvFrGDOHVgFQFTrLrvVqbTvpdcxNDENqIObCENTXyfEcceIowieOYgXnopXmuwAaUdJJyMlzqUftXHieZzjxCYERDNBnvmlRQlQxIoJ");

    if (kcPXHShgobmal >= string("v")) {
        for (int ubuuk = 1959987856; ubuuk > 0; ubuuk--) {
            YOSzqhtOsnV += YOSzqhtOsnV;
            kcPXHShgobmal += kcPXHShgobmal;
        }
    }

    return -467963730;
}

string OrEGiIZoheMsKHI::hBtZPcbJnDJREDPl(double VjrKLQGgYjUFvvsQ, int EHPitqkpnqmt, string SGCQC, bool SevZIvIblJt, bool IcylvOOehW)
{
    bool DpcRfidKdfnyhm = false;
    string SaLHaPBPrNxFsmd = string("f");
    bool GCQbjYwxBDh = true;
    bool jVjswsMlGmkdX = true;
    int CTKZTETgO = 623374120;
    string JHaZfWvA = string("aCogRETUtuKoiXZdENGpUJgIsEFoiBdQHbLUWWZmOCjnpdJmuNduvfCAPbYXQsKeMQsenSdpwTnYkFrGavEMwDbhnjxWsMwpToVsesdQCAILHmGXkIkKLPvsNPYBXhCSOFZTUuwblVdCxXghOoeAsfHmisTcDUVTjsmMXyZnGkjLrNiAzTUilqqhDLocdvZxedOofesZj");
    int zMuZNexJy = -2054273586;
    int sPqHiDABNHHeYpFM = 1831708592;
    string LDgQIjmCNv = string("eqaybDqSVazBgBCyRbKTVeLwiKHMImymlQUjbYLKbVjNBWJfEzlWGXWngHmNuvJwFXsVLxMPLSBVrjDEUmpoTqqCjStKQdKZgakSysjxfsrWpgQSHu");

    if (GCQbjYwxBDh != false) {
        for (int FfljjTu = 1619903438; FfljjTu > 0; FfljjTu--) {
            SGCQC = JHaZfWvA;
        }
    }

    if (SevZIvIblJt != true) {
        for (int uDWSpElclOMBqDU = 1721429068; uDWSpElclOMBqDU > 0; uDWSpElclOMBqDU--) {
            JHaZfWvA += SaLHaPBPrNxFsmd;
            DpcRfidKdfnyhm = IcylvOOehW;
        }
    }

    for (int QGzUfqFjqbXmuJC = 740765939; QGzUfqFjqbXmuJC > 0; QGzUfqFjqbXmuJC--) {
        continue;
    }

    return LDgQIjmCNv;
}

void OrEGiIZoheMsKHI::iKIDSnbYozzg(int cIMNlfwD, double EFotbCCj, string KXvvOvAUycCq)
{
    string JvqxyNukzTVYLKRt = string("JWlkQvMLwahQqEIwePskyAqwWEjHLkYHfoHCHvmrMdgMZrLlXRTzGHWXxEVThdhIsDGJNNyNpXWvVXHckDvYtVioUfRbYdCGdNQcXLTUflhxBoPLlKphzPlsjbJLeldmAsLZjhdfYqVKusSd");
    double XTOZm = 340109.12750269443;
    string slNQUBigRqfF = string("lJAuiPHnpfBLIpSgsrNXGHpGWkjoGItjVcLjiHaKySHZsTHHUhlCRhnBGxqbGLZafviBGaUEMPbThpqwuiXbReoAGldhJwrqiTfinJjbLuXpSEHeV");
    bool ikyOuaafYgFhVBPQ = false;
    int CNuqb = -310355971;
    string qwSYHrXcJXkazd = string("TDkBrQVqFRzPoWtkUbPTM");
    double MILhXUnHOBSUk = -785050.8017589306;
    double FWZBYOe = 17357.481154534264;
    string kChQAMCd = string("qQXReuLdzpcbrWYyTZajjsdvPmHoMjXpBLRhkRvzsYXwgOGcxCVCvBAxNRZbiCrboTFLzhRmzRPcRNlGCxznOQsAHWpzhJknsXepknodIKjspsxxprRsUKYQwFqNfMbTgRjpXPeFLNSBhY");

    for (int rmGOkcaWTcraY = 1302753796; rmGOkcaWTcraY > 0; rmGOkcaWTcraY--) {
        continue;
    }
}

int OrEGiIZoheMsKHI::UvMSJIO(bool LpERcECagrWF, int EILuqTrsS, double pzFZtjvcu, double xZlEMb, int ogcOGkqIyqRzBPl)
{
    string lrpgwGcKAZu = string("fxrlcVrjqJnYbkKmceHFZbJMtsIteTitsBJNeEDAdBBjILAZKsGpfnUXITpliBLzmZyWYfgWKNysFWFbQLaTOimTdREUqawZMectz");
    string aJmfFMF = string("IteVSYFAKAFRpgqlTSratwSNvcnGPFQjbnPMZaiYESzilVLsIoHzsjelpaSDDUbbsVhcwxHtLJBTqNfscrmYCpoqayiVHmwmZoztztwnKqWiTxBCUVRyYdGsblztAVMSjdFtlYfyQlRFtalgnqjgNZUiIahcROULPVzAZXiAxsYQNhZbWHoOMGUHwRpawxrpeMwgNqcxRDpytlfhqFrtqRiWnRfQkpxWNxkj");
    double kYYzEFTohu = -684840.2361044389;

    for (int mrpHfvdXBiP = 399640082; mrpHfvdXBiP > 0; mrpHfvdXBiP--) {
        continue;
    }

    for (int bNEOC = 43702661; bNEOC > 0; bNEOC--) {
        continue;
    }

    if (kYYzEFTohu >= 894901.2163974697) {
        for (int ZjUEZBrEjL = 880791904; ZjUEZBrEjL > 0; ZjUEZBrEjL--) {
            lrpgwGcKAZu = lrpgwGcKAZu;
            pzFZtjvcu /= kYYzEFTohu;
        }
    }

    for (int gipuTEqIZCXEUkj = 1515586557; gipuTEqIZCXEUkj > 0; gipuTEqIZCXEUkj--) {
        kYYzEFTohu += xZlEMb;
        lrpgwGcKAZu += lrpgwGcKAZu;
        aJmfFMF += aJmfFMF;
    }

    return ogcOGkqIyqRzBPl;
}

OrEGiIZoheMsKHI::OrEGiIZoheMsKHI()
{
    this->byOXz(362705332, false, 38395580);
    this->HpFvMz(-56368.87551121741, string("RcitoLXNPOTzpQGrGyLJIcssDMgWQcCcKuYZPRNjDYRRChtdvNNWjCtgqGXsjvbOYjPlTEpKYIpTLHYSSCkMzDdwriPPRZkSMPvvMVIePTyEFYkuKXyUDsGbtoafysWgdZIBJLAiYHjbKCJqLbdqaVcmKqoWXfeuWhaNwMmCyeZiQkPIObCLuYUKWCOuEgjruwnOwgKBYWqVCTlbzCdK"), false, -503758.91659051616, 605423.1571777753);
    this->CZOoLbfXecUQSm(false, string("eMQFbLPJVRZHAyIesbnnQpSaHydOSTxUuMTQTveAAawWIXRlHqsbTQOuhVzXDiIgQqEOjaayXdDXLw"), false, -523258387, false);
    this->NbWqpEcVQtPgq(1512331138, string("OVjFsUBFSMHKkVtSUmraaHCrmUNaRijZotmawwXGoWfqrpskQHTZXqiAgLWeCHjzkddKHQwTnXdHxVCZRMwNBcyFJslbJnoNkrTSQxerDLuXwmyqwyWbCPxyoglqCcelWzPkDwynuQLkEXWLjsXgoYUDIuUJbgmxWjJIORVyAAVlJCrYvXQsPpOrWUJSnEMpIscZopYSYIGxYuYfGupGqxpqyojVgPAMXBkiBKobUblhnPWeIaqumSK"));
    this->crTCuQLUnfJI(-284974.405180238, -1521992481, 412767.8368443435);
    this->MIniciJOq();
    this->oppKVGs(-7608.148552744403, 170766993);
    this->KXaQvek(string("v"));
    this->hBtZPcbJnDJREDPl(-628387.8019614876, -1150462494, string("moAnbYcpzCUgUBiPedGOEiuYdCYsTyefPMUfujFxTGwQwZEhLSccIBlxPXwfNHTjDTKiVruKVlSuYgHPJCQWIUBhQiqOSwkPXrNVMiDVfyBkPcbNzRwMzhEOKwPCSvsOmcYMsKSYgfdflScUI"), false, false);
    this->iKIDSnbYozzg(-29448642, 366408.84859154245, string("ySWndcRXODoQafftcWOSVAaMxcVzpgtMjhXPJkRCjtHuIYiWrlughsdCTQNgwQzZtLOFeCwxXduefVYYFCKieVxyOP"));
    this->UvMSJIO(true, 1291181803, 894901.2163974697, 505395.3574049801, -301741789);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class symvgMXDWe
{
public:
    bool BvngsTSocKjYvP;

    symvgMXDWe();
    void vFzzXFZZ(int VCGnYmhrmbSVHeiA);
    string rOzvNVz(bool LHPBVZszc, bool dVqFnUFkhiOFnm, double bmBPXVApN, string gDouygYg, double KvrRowzvn);
    void nOZKxWXgtdeuj(int yaAQOZrjwMXdfd, double ByhhGDmDOpvoi);
    string QUBoJzaQJUTVGUQ(double mOlJu, bool fJGCJTWkqj, string xLXaaOOVG);
    int SRLFYuhjcUyyc(double rcMcsqJ, bool oDLJPSKizsYPGyHz);
    double gfNTjToto(double HHqcggKnpOnYw, string nTuTvsVVK, int OPDkCdHrMCX, int DdHYMEefwUlWjd);
    void cATJHX(double VxneAMdiFZv, string OrTjZQAqzhe, double JvazrfYZR);
protected:
    bool uqfzHswpbxwtWwJX;

    void FAOloAdMt(bool eLalucT, int lxvfyhK, string QcvJbuE);
    void IRpty(string DvRSOEPG, int EkUsBZQJpWFQCfm);
private:
    bool OMImjXGCHj;
    bool peyUMyhQJy;
    string oCTxTFE;
    string HYZiQISRytyJ;
    int BOJHxvMROHqyCS;
    double VJofQuPxdD;

    int LqYRDPnqs(bool AWVjUPONEutjTkLi, double TzhrrLmcZ, int mhDPK, string aVOMK);
};

void symvgMXDWe::vFzzXFZZ(int VCGnYmhrmbSVHeiA)
{
    string CLtgN = string("jvuoEvjuwsqOMJbzznSDbSEfvCgsDfWpflANMFrRUKssoueSTrPtaKeoSINRDyvGjhAuDHIDVqGINsWZuUmLouIveFrnbOKvwyntgYMJkbTmOieTPFTHiQxpgkSrzFosnkqTjtnEIqxJPdqLGj");
    string CJuUBzVvMC = string("QPcblRfOTBjAGqEtPhPPNmVgVGvARFpyKltHPoSsfKSAfedxVmzjJdopjYwwHlHrZIndiuRYTiQBwrEboqoMwnJyZwNTbxsjUHYOYtJvqbYxHbWtVULKZADzjjmNblLzOioXarQBBpYnSxFxJrfUNskkdpDhVCRUqPoqydFrfiBOXPgp");
    double rtRsSupiSJD = 293718.1083477548;
    int ULQfIm = 1130971853;
    int mUZECWXmA = -812522667;

    for (int XUQqe = 543633569; XUQqe > 0; XUQqe--) {
        CJuUBzVvMC += CLtgN;
    }

    if (mUZECWXmA > -253771042) {
        for (int kakGVKWnvD = 811754427; kakGVKWnvD > 0; kakGVKWnvD--) {
            CJuUBzVvMC = CJuUBzVvMC;
            mUZECWXmA /= ULQfIm;
        }
    }

    if (CJuUBzVvMC > string("jvuoEvjuwsqOMJbzznSDbSEfvCgsDfWpflANMFrRUKssoueSTrPtaKeoSINRDyvGjhAuDHIDVqGINsWZuUmLouIveFrnbOKvwyntgYMJkbTmOieTPFTHiQxpgkSrzFosnkqTjtnEIqxJPdqLGj")) {
        for (int HSOuNaQeGJ = 2025157356; HSOuNaQeGJ > 0; HSOuNaQeGJ--) {
            ULQfIm = mUZECWXmA;
            VCGnYmhrmbSVHeiA -= mUZECWXmA;
        }
    }

    for (int qiTNxiABOuevLlZ = 1271092810; qiTNxiABOuevLlZ > 0; qiTNxiABOuevLlZ--) {
        rtRsSupiSJD /= rtRsSupiSJD;
    }
}

string symvgMXDWe::rOzvNVz(bool LHPBVZszc, bool dVqFnUFkhiOFnm, double bmBPXVApN, string gDouygYg, double KvrRowzvn)
{
    bool cYTbZCgpvpdQ = true;
    bool SkAzGf = true;
    bool igJOGICVsalmezK = false;

    for (int AJFkqJYcoMKilpej = 869848218; AJFkqJYcoMKilpej > 0; AJFkqJYcoMKilpej--) {
        LHPBVZszc = ! igJOGICVsalmezK;
        igJOGICVsalmezK = ! LHPBVZszc;
        igJOGICVsalmezK = igJOGICVsalmezK;
        dVqFnUFkhiOFnm = ! igJOGICVsalmezK;
        dVqFnUFkhiOFnm = ! LHPBVZszc;
        dVqFnUFkhiOFnm = ! LHPBVZszc;
        igJOGICVsalmezK = cYTbZCgpvpdQ;
    }

    if (LHPBVZszc == false) {
        for (int VaxHy = 1177351811; VaxHy > 0; VaxHy--) {
            igJOGICVsalmezK = dVqFnUFkhiOFnm;
            igJOGICVsalmezK = ! dVqFnUFkhiOFnm;
        }
    }

    for (int WQNyyy = 2038724951; WQNyyy > 0; WQNyyy--) {
        igJOGICVsalmezK = ! SkAzGf;
        dVqFnUFkhiOFnm = cYTbZCgpvpdQ;
    }

    if (cYTbZCgpvpdQ == true) {
        for (int ZqoFohTextmgIrNJ = 1206821692; ZqoFohTextmgIrNJ > 0; ZqoFohTextmgIrNJ--) {
            SkAzGf = ! dVqFnUFkhiOFnm;
            dVqFnUFkhiOFnm = ! LHPBVZszc;
            igJOGICVsalmezK = igJOGICVsalmezK;
        }
    }

    return gDouygYg;
}

void symvgMXDWe::nOZKxWXgtdeuj(int yaAQOZrjwMXdfd, double ByhhGDmDOpvoi)
{
    int vZkvLdHJsX = -1556859616;
    int okzpJpvSkOHHVSiU = -1224110942;
    double vyqjJGXItIexB = 316096.0847156258;
    string wmGDRkGGeWhhAS = string("qkRmngfwmbmaMazBLHfiPmTwHrGtnHWsJtMeNqJxpnsYZGXIhACMsbKIDNjAScLsSgEYwiRfrWUToJkHoGoCogLxvqeduRwFcCuFGsnNiAVZwurWPymJIJVdfKENbuOVftgQeuYZhJmXRpeZLUBhKxmLhYTdROyNaYXJaHvsYNYO");
    bool PmqVseXsxHniSSEq = false;
    string jgOWVldaQQAsC = string("WNakffcXexdDuKHonsZKsccETgVBLFtdAdXzNYwZaliSraJWnQqxTDNrmPplEnzL");

    for (int MVtzcbYf = 958482328; MVtzcbYf > 0; MVtzcbYf--) {
        vZkvLdHJsX += vZkvLdHJsX;
    }

    if (wmGDRkGGeWhhAS != string("qkRmngfwmbmaMazBLHfiPmTwHrGtnHWsJtMeNqJxpnsYZGXIhACMsbKIDNjAScLsSgEYwiRfrWUToJkHoGoCogLxvqeduRwFcCuFGsnNiAVZwurWPymJIJVdfKENbuOVftgQeuYZhJmXRpeZLUBhKxmLhYTdROyNaYXJaHvsYNYO")) {
        for (int mTDGHiviBynjXOMx = 2096429719; mTDGHiviBynjXOMx > 0; mTDGHiviBynjXOMx--) {
            continue;
        }
    }

    for (int syQvGyYE = 427242620; syQvGyYE > 0; syQvGyYE--) {
        jgOWVldaQQAsC += jgOWVldaQQAsC;
        okzpJpvSkOHHVSiU /= vZkvLdHJsX;
    }
}

string symvgMXDWe::QUBoJzaQJUTVGUQ(double mOlJu, bool fJGCJTWkqj, string xLXaaOOVG)
{
    int KaJwPuQcECYoRhg = -109620529;
    int YAnACGyMgo = 106113437;
    bool OIrYuOFlrexICXRc = false;
    double mLQqetbUANIPGW = -552900.7822596679;
    bool RACjxaNZObzph = true;
    int CcebPeaugyrMLJJ = 1031496634;

    for (int eoxUHWdy = 2076054831; eoxUHWdy > 0; eoxUHWdy--) {
        CcebPeaugyrMLJJ -= KaJwPuQcECYoRhg;
    }

    return xLXaaOOVG;
}

int symvgMXDWe::SRLFYuhjcUyyc(double rcMcsqJ, bool oDLJPSKizsYPGyHz)
{
    string IARRJnLWTJoRRqzr = string("KlVDWqhgiZdjyVhFEJifrnvBnPvYzKugIIPKxmUwCMVUBbRRksUakyIkTDXeFJlrfTBorinBhxxDxtVVNZnCIZcPTUdvQiDIlcuxMcEcEAnWYQEszNuYqdWQUTnUdeWSbKGFxqJYOUmdqucLYAkYXwQRbCplULoDKbYOCAnQsTYjLJIPycBxqaeiQBmMTGeNuTFrJQawapiNvqqUDeVFY");
    int dePUXnGcprIJFR = 955803528;
    double nSkJfLGbBgAtyna = 449636.5387591264;
    double MoJWgcsU = -578395.4018218679;
    double eawefUdwTVttbt = -718998.769198177;
    string LemgywsthHrr = string("PkAmyKVgJkDcJplEmkycgYAmijJppAOQnqjztECVsJhkNEreGTeUJQDJfZqyRCHLAAAHPrVvgmTqkdnSUGDoMaNEiRGCMgWPMWyVJZwcsJMYdwiNwKCCOKmHuIyjlOzqqirljaMJFqLOyDruRWwhHPeOQuhjZamEgKkEBLBvjiVqfMuOeWFiCLanxqiivyzcNcBiYOwLObIOfqWwtUGfZNBrVChUQlFaiVaBhxpUT");
    string VnbzAT = string("zgUdHtBwmdbQpksqDzSCYTGKwgQbaRszgLombHLtFbnaodBXjHzscjjTLPFGEDWZQAVvwbWyiEqEKkOWFiZzGrubBnxZJhVOrROvaWUCALNGZOAcfzAIqNjTtEtVqWtQuNMTJLfAlFOonexfQJxkUUhGowrjMqoegyyxFQYGbBSbIHMQGMWFgNPCkdmobZBVJYXmJAowcnJrhsVlmEnwlYEAVwQXeOLNkgdpxfLTKlgECBNAkx");
    int bMbTpVHVHIa = 887404265;

    for (int aKzZKtuXZav = 1686726294; aKzZKtuXZav > 0; aKzZKtuXZav--) {
        MoJWgcsU += MoJWgcsU;
        LemgywsthHrr = LemgywsthHrr;
        MoJWgcsU /= nSkJfLGbBgAtyna;
        MoJWgcsU += MoJWgcsU;
        MoJWgcsU -= eawefUdwTVttbt;
    }

    if (rcMcsqJ > 557582.3590388969) {
        for (int RVCCWRvUjWD = 695665435; RVCCWRvUjWD > 0; RVCCWRvUjWD--) {
            bMbTpVHVHIa = dePUXnGcprIJFR;
            rcMcsqJ -= nSkJfLGbBgAtyna;
            VnbzAT = LemgywsthHrr;
        }
    }

    if (rcMcsqJ == 449636.5387591264) {
        for (int kwaAHugI = 2076062825; kwaAHugI > 0; kwaAHugI--) {
            rcMcsqJ += eawefUdwTVttbt;
            rcMcsqJ /= MoJWgcsU;
            nSkJfLGbBgAtyna += nSkJfLGbBgAtyna;
        }
    }

    return bMbTpVHVHIa;
}

double symvgMXDWe::gfNTjToto(double HHqcggKnpOnYw, string nTuTvsVVK, int OPDkCdHrMCX, int DdHYMEefwUlWjd)
{
    string NOxHzydGsPRuOl = string("rHHpIrNKSRJCcHCsKzLnhcoytvPdCFxxwFhliawDlCCNgbbbAQqWAwGTcMgtDaPrfnykbgnveNiknywHMVbKJalatwoznvBTGZFyPalEriIyyoKshRYLjvMucYbmaRJVwkSZVaRvdXxSspUWUzvJPbooZdUQGOqIXjTpskYeqthlaxwQKmXmtAubOHTtsYkcvunouELZciMkTILWoabODAVmfnBUm");
    string uAcQzWD = string("GyYggpCPVThukCQUlUJnFJwEDvXJRHfacDOTxyEBfxLIjvGfXuwgPdUNhPaENHfjLqCkoANsPtdQDtiAlFWqrAwftpbvBksVLdctMVEfRFQsXVOyVPJJAgELmyXatYMWtaYaqMirAcmbNXT");
    double yRWSrAvKBiVlNb = -636804.9299718349;
    string APasYOQmwnJuWGlU = string("oDANMBsTevtWZxPpOnmxzhtwDqtuwtdAEuIvdltszSSfWKxflkoZtfGJWhbZpqaaCvtHlmPcspmTmFUGKFIcMnJvUGOmCKitUrHTDwFQYSTRbIJEaDQIyUWFoJG");
    int NqaMSZMoPBMyIXrb = -1115457732;
    double REnmjTrr = -162540.89354653086;
    double XgPKmY = -300387.6715719929;
    bool xVsQGXbfEJsVfjri = true;
    double ghtGxeww = -411270.3179529727;
    double AvPLm = -901478.8887865747;

    return AvPLm;
}

void symvgMXDWe::cATJHX(double VxneAMdiFZv, string OrTjZQAqzhe, double JvazrfYZR)
{
    int ngfdOYX = 1806620936;
    int BUZQsbeeJQtyrcDK = -1168659148;
    double DqILEKfhWwXHhniG = -453864.80540809204;
    bool BxIcThuLO = true;
    string ENAcxsG = string("szCzMhqawELsfnbhYfgWNZNtbyNsbtIopzQcfeEhBx");
    double gjLqoPApeef = 437802.97489206376;
    int QaRvjX = 1593499177;
    string jeAsatTuPgMrtZjJ = string("CfbNegdewaXBOgWzfATfAmygMvXrVaapLMneckUuWdEpvHXhAUyEnRTFNPDVXoHEmXPUxndaVvMlKWtMcTQMlgWRQuNQeMqCMZILWrUYxewlGagoonKlQcjrjXVDUyWrdMofPLfvPVLIFqvD");
    int rCtrPUhpj = -1760100214;

    for (int aBkAEPDuynTLWw = 579855587; aBkAEPDuynTLWw > 0; aBkAEPDuynTLWw--) {
        rCtrPUhpj = BUZQsbeeJQtyrcDK;
    }

    for (int cwenXK = 2099521577; cwenXK > 0; cwenXK--) {
        ngfdOYX *= rCtrPUhpj;
        QaRvjX -= rCtrPUhpj;
        JvazrfYZR /= JvazrfYZR;
    }

    if (VxneAMdiFZv >= -133277.23831631537) {
        for (int jCVZZg = 582959066; jCVZZg > 0; jCVZZg--) {
            continue;
        }
    }

    if (QaRvjX == -1168659148) {
        for (int cqzLKi = 57173011; cqzLKi > 0; cqzLKi--) {
            ngfdOYX -= rCtrPUhpj;
            rCtrPUhpj += QaRvjX;
            OrTjZQAqzhe = ENAcxsG;
        }
    }
}

void symvgMXDWe::FAOloAdMt(bool eLalucT, int lxvfyhK, string QcvJbuE)
{
    double xCfrKa = 60133.60305725485;
    int CMqvUiiZbsQYGG = -1875830264;
    int UVixjtnfUbiW = 760200473;
    string OBlsT = string("qkBOskeEGAjUHJuPSIoxutinUTsKwtYIJAaUiTBcFmTaUTkGGvYsOhRgUwhyDDOIqRjtvxLdrvTdODQEMOeqezTfhaNTwtdfSyfpymACsjkESteoArmYDFIzgogHgAzpB");
    int jFyvEMTtlk = -47275366;
    int IxGsOPhnvOYespM = 19078654;

    for (int gqZIh = 2007749576; gqZIh > 0; gqZIh--) {
        jFyvEMTtlk /= jFyvEMTtlk;
        jFyvEMTtlk /= CMqvUiiZbsQYGG;
        xCfrKa += xCfrKa;
        CMqvUiiZbsQYGG *= lxvfyhK;
    }

    for (int rwvipIVTS = 323935150; rwvipIVTS > 0; rwvipIVTS--) {
        IxGsOPhnvOYespM += CMqvUiiZbsQYGG;
        CMqvUiiZbsQYGG -= UVixjtnfUbiW;
    }

    for (int LCrYBoP = 1789044906; LCrYBoP > 0; LCrYBoP--) {
        CMqvUiiZbsQYGG -= jFyvEMTtlk;
    }

    if (jFyvEMTtlk > -47275366) {
        for (int XHmqE = 1738215096; XHmqE > 0; XHmqE--) {
            lxvfyhK /= UVixjtnfUbiW;
            UVixjtnfUbiW /= lxvfyhK;
            CMqvUiiZbsQYGG += CMqvUiiZbsQYGG;
            lxvfyhK /= UVixjtnfUbiW;
            lxvfyhK *= jFyvEMTtlk;
            jFyvEMTtlk /= IxGsOPhnvOYespM;
        }
    }

    if (IxGsOPhnvOYespM <= 1873724048) {
        for (int eaooOAtXIjP = 1980969132; eaooOAtXIjP > 0; eaooOAtXIjP--) {
            QcvJbuE = OBlsT;
            UVixjtnfUbiW = jFyvEMTtlk;
            UVixjtnfUbiW += jFyvEMTtlk;
            QcvJbuE = OBlsT;
        }
    }

    for (int YMWFj = 476899668; YMWFj > 0; YMWFj--) {
        continue;
    }
}

void symvgMXDWe::IRpty(string DvRSOEPG, int EkUsBZQJpWFQCfm)
{
    int gFnENiiOzljRSGNK = -1961406385;
    string UGjUeEYXl = string("dzcyFcMOsvjurdugMpVHDYCyjbqGOEmNuGxMOLfnRxFedwjclTdWCrNMHHMcXaLRlkDDbCItsmtVjDPOuEtKK");
    double KWVWuNAm = 842456.6494655062;
    string APKUHdeZwqrfjZx = string("inYeKaUpSrMmWTacAPEiFjnXNtqVRtAKaGBQPYQLlGdSBsaJhpJSqiblQtufNAFxcwTiPHHPVGWxwHrOhVcPtcBRXMPoMOCDFHAKNwGXBcDOFHWqtHlXCQIepzfbvDBBXjAk");
    string DvUThNPUuGX = string("hUkqACITckLMkAkjiSPDFwxzQhuWgOnhiMORhZEYzQgRVowDRvfrBXVnLikumXbzLbUQxXghWAmxINklzNfXEIGsMZCRsaUjjhWpBMzExrcxVZchUTOBAKnFA");
    double TZyMLznSWgGiehS = 1012069.9752109407;

    for (int tWTSWcaSsihiX = 540613852; tWTSWcaSsihiX > 0; tWTSWcaSsihiX--) {
        gFnENiiOzljRSGNK -= gFnENiiOzljRSGNK;
        EkUsBZQJpWFQCfm -= EkUsBZQJpWFQCfm;
        DvRSOEPG += DvRSOEPG;
    }
}

int symvgMXDWe::LqYRDPnqs(bool AWVjUPONEutjTkLi, double TzhrrLmcZ, int mhDPK, string aVOMK)
{
    bool RyONSXdyraaZ = true;
    string cebKoMs = string("oeRuCbQgvbiEdquRXsolTJgLXDViuGLutnuPaTyzyhingyJxLKgRfsBHJcvyaXaAlfSkwkAPMGqIfyBomxLDQNTFkcUecHPLaIIlULnHVnektRrxeJtFWaaqXMdtCRyQPoyJdyzerPoHzpwlKnShbkcbOlSeHNyMKeEPNJUAwZBWmbosiaXBPuRQkrGsINaXKyNjIgUQyIMofQpLrWutoEGzdMOHXoJLRXiRxyJBOiugroKaDmcXtjm");

    for (int hihKVmLnCNsuZKLf = 442447333; hihKVmLnCNsuZKLf > 0; hihKVmLnCNsuZKLf--) {
        mhDPK *= mhDPK;
    }

    return mhDPK;
}

symvgMXDWe::symvgMXDWe()
{
    this->vFzzXFZZ(-253771042);
    this->rOzvNVz(false, true, -408078.6769766061, string("uUHMWfOYXdLCiUeqjgwLfWknnHFAxAlYQXNtWptWrATmOagdWMDxLzsNisLvqjbvnuvmDYkHiRpeBJWexezqeIHTwcnzhVyhIrbEWSiwaBKynIuClQDhjGImExPlahwRtnurROmCEHyEIIDPZHeRwcXccLxVtPMKduztWtsNUJYNEjyA"), -431822.2900606556);
    this->nOZKxWXgtdeuj(-1819140808, 484530.92561513616);
    this->QUBoJzaQJUTVGUQ(-198377.7791581906, true, string("xZwfnvCJJhCZEDtwOHdbWykGDXPJRBoVQwmjqXooVZndogVKKDrHHGhFwJzzhAPHLOliUwSccMyOKKllmGttvIGySWVzXAMEoAEMYFCyjkiMcNNvbHdAECdyurcKI"));
    this->SRLFYuhjcUyyc(557582.3590388969, false);
    this->gfNTjToto(399842.82967760984, string("cBAURcagoGsKWxBirNdPeDyfQwuFdjkEJLOzFaHztsGdxDlEYQEKuxXCDcTvxZsKtisLRnTbkOnUQheQXrjILdjeRWzKtWZHxYUVbHamQzFvmtomtHQBQazSoXRodGuBtEJrvmWkhqHgZNrilFCKLwCNKfNlZHKfAgLVIWGHJjPVOybpIjkQqVyDqxHzPDZjoIJUdViLlMfaVgnUqngQIQdRvTIaLOXmyaTQrbUhNZc"), -1379607307, -626178155);
    this->cATJHX(-732266.9337720791, string("UMUeKsKlLjSgIyJp"), -133277.23831631537);
    this->FAOloAdMt(true, 1873724048, string("zCetYfEKxXUbOXLYAOgduHSgRYZlzAuAnMMIEKitLCkVIqzeYKQFBKBPTkJNNrTGcJHXbsrlPvlBTpDWdDAVuRZetePhkxUKVL"));
    this->IRpty(string("sumo"), -902932801);
    this->LqYRDPnqs(true, 127027.71127637589, 401890678, string("eDNDoELUjiVeKeCofFdQEKdxKyjDrwGgvWPYfHkHtDtlCxkaEjIPxqBiBhfISDJblwwHTRzyifOJmUZGceei"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VmYanIWunNcAqQwi
{
public:
    double REfUWtfMbM;
    string aCAJY;
    double PZuUxds;
    bool jcACCQnRx;
    bool YETOiuvWtWvsD;

    VmYanIWunNcAqQwi();
    string mEzvKh(bool zDqFvZIP);
    bool NvlgOYiYVuFoiD(int ulQAA);
    string khPmQNHINib(int oexzHPxe, int cPsCjEEI, int aeFePeaaeilRSmI);
    int DnBPYkrj(string ewahYG, double wVvXUShlfdfOUEQn);
    bool obFeS(string RCloNaFzhACbhSrx, string QgfNUikfGo, int pHiAEDxDZR);
    int ghmbLWOsTvgFQr(bool OUigafw, double ylsicBYuiu);
protected:
    bool lRPwQwnoOdryV;
    int nyBtOVChWk;
    string WrYzFwAbcNXHDphh;
    bool QSXjrHBMpv;
    int OuqIm;
    string LJByTsRKD;

    void OyyAT();
    double LlpEp(int FlooUMargDwglPK, int EpoTWst);
    int PKxhnT(bool dKIcaGTCV, double QlmDyluXjRZsJtOg, int wxPgyjXYqvNbqOf, double uGuuQBskYm);
    int BhaRAXGLq(int RjbOz);
private:
    bool jheIFZdOKCoZJZMP;
    int gvPlYHIyGTZDPOwu;

    string LCOuAdmPKO();
};

string VmYanIWunNcAqQwi::mEzvKh(bool zDqFvZIP)
{
    bool nfEAaBoH = true;
    int IxGozURQ = -1316571192;
    string ApOFpuxy = string("UuBTkhoMgJpUXpCVSGnSjJOmVOmfpoKBPRPRzGTBtjAnAJWUatUFwxBumRwoXWdVTXQvJUYDAxDMYBHcHyPDXuwaHMvKuoUIrVlWyGQGxQenHSbaBCmISSfbBcUETm");
    int FUQRIixVdmVOWM = -1062670028;
    double IIyjidSoEHJQSU = 509053.03002191073;
    bool OoArjGROaZONfiV = false;

    if (FUQRIixVdmVOWM < -1062670028) {
        for (int cqHfyGkcrbvsvqWS = 1315261107; cqHfyGkcrbvsvqWS > 0; cqHfyGkcrbvsvqWS--) {
            continue;
        }
    }

    for (int ETVAGgQKuhO = 1558843021; ETVAGgQKuhO > 0; ETVAGgQKuhO--) {
        zDqFvZIP = zDqFvZIP;
    }

    return ApOFpuxy;
}

bool VmYanIWunNcAqQwi::NvlgOYiYVuFoiD(int ulQAA)
{
    string fpQwnIkvOGhx = string("IwPUNwjvNiSVCYIynYAMNFTrloeyalYxnpmlXvcrcdUvqOmRpxfWlppZHMkoWXqKsdjtAjZxzQOojEdgeOHhfqosbIUwrnMWqjpYjlsuJZmVsHYRZauLokgUHmPZUDHcMQKXraJrZamRCPlMMjuUJejykSZmHzOdHSMEJHZDosZVdvWTBwncOWzDHhCRgoCcNiUclBFZUfusi");
    string MIMbGjVoyWm = string("aukQTmojaiZizymJSUejkCXkIeaGufFZtUnirZWpBlVekiPgefCoTCEEDGJquVSCzFNWgZRGcPUJWLDtdLFKnrCUnvWvelzrbukLcsweAhDdCGHXvSKzbIXszEbtmRnbmxOBIAOWzJbqmioaBgUTGjqjWFuWwsiO");
    bool kaxkk = true;
    double FGCvFZWQCm = 161609.4723013998;
    bool anYVMOvLiMUrDFVq = true;
    bool pfgXr = true;
    double hfTCssDnhENqGh = 574776.6418048935;

    return pfgXr;
}

string VmYanIWunNcAqQwi::khPmQNHINib(int oexzHPxe, int cPsCjEEI, int aeFePeaaeilRSmI)
{
    bool XyPXx = false;
    double ZfPjdjEign = 1030824.8958105466;
    string bVhpDiZoxn = string("FNjnunMeVYZPEAuhRFwSQctXakpZjkGSOXklfDHOUcSZnWesteUQKWllPiWFQPHxxWUAmApFtadynRNxDhqIrvVvZluZbnHLnHrBIymjNwIWyqQDneMEmIzYXqMJeOUXflRyFMvkVlfJLngHTrWeQf");
    bool ssNba = false;
    bool arfvnbfWcQLKoE = false;
    bool KhnOXvJAyHQxEhW = false;

    for (int kEDSiOJstNWHhS = 1287360364; kEDSiOJstNWHhS > 0; kEDSiOJstNWHhS--) {
        continue;
    }

    for (int nQUWav = 2061826150; nQUWav > 0; nQUWav--) {
        oexzHPxe += aeFePeaaeilRSmI;
        ssNba = arfvnbfWcQLKoE;
    }

    for (int lvswpclZcsP = 977366350; lvswpclZcsP > 0; lvswpclZcsP--) {
        cPsCjEEI += cPsCjEEI;
        aeFePeaaeilRSmI *= oexzHPxe;
        cPsCjEEI -= aeFePeaaeilRSmI;
        aeFePeaaeilRSmI *= oexzHPxe;
    }

    for (int LulwXKdmlzR = 784541318; LulwXKdmlzR > 0; LulwXKdmlzR--) {
        XyPXx = KhnOXvJAyHQxEhW;
        XyPXx = ! KhnOXvJAyHQxEhW;
    }

    return bVhpDiZoxn;
}

int VmYanIWunNcAqQwi::DnBPYkrj(string ewahYG, double wVvXUShlfdfOUEQn)
{
    int pYvAYq = 1093961034;
    double kBIsVSZjJE = -565803.5058284265;
    int TsSSch = -144421532;
    bool CjeqNUY = true;
    double UyMtADJp = -738699.7101356006;
    int lBTXHZDPMKaUmJDL = 755838452;
    int IcoObYxYcxgsqYc = 1741345398;
    int JwNFtZLXpWhdJKy = -1863449510;

    return JwNFtZLXpWhdJKy;
}

bool VmYanIWunNcAqQwi::obFeS(string RCloNaFzhACbhSrx, string QgfNUikfGo, int pHiAEDxDZR)
{
    string lqIbnItCG = string("UVRiRlIhxQFUsf");
    string mGCKqhRvLwXleKNr = string("NVAZaUobXSkZHSUyWvTnrhKppEfBowJSGdEIQLAPPIzAhOTESpVYyliipxvSHQTEgoUQNHQgkNieBAumkFHKyPnOJvwVhaYfkkpbrPQbCaQOGljhvJPOQjuuAxOzLJBBhSSYvNDvUYVAEZFn");
    double lqQuHIojr = -414997.5175304734;
    double sBVUpN = -753646.9303407244;
    bool aRqXY = false;

    for (int jAPuzCTioxvtI = 1054878537; jAPuzCTioxvtI > 0; jAPuzCTioxvtI--) {
        QgfNUikfGo = mGCKqhRvLwXleKNr;
    }

    if (aRqXY == false) {
        for (int RVUHpPPvKT = 1388358551; RVUHpPPvKT > 0; RVUHpPPvKT--) {
            mGCKqhRvLwXleKNr = lqIbnItCG;
            lqQuHIojr += sBVUpN;
        }
    }

    for (int mnKZxVefHLzbHV = 554259919; mnKZxVefHLzbHV > 0; mnKZxVefHLzbHV--) {
        mGCKqhRvLwXleKNr += lqIbnItCG;
    }

    return aRqXY;
}

int VmYanIWunNcAqQwi::ghmbLWOsTvgFQr(bool OUigafw, double ylsicBYuiu)
{
    int LkuNACVTa = 984522075;
    int TngaJAEcMRX = 647720751;
    double zOokGIU = 684046.835226414;

    if (TngaJAEcMRX < 984522075) {
        for (int lPupUBtlTVVFRlhT = 2105903927; lPupUBtlTVVFRlhT > 0; lPupUBtlTVVFRlhT--) {
            continue;
        }
    }

    for (int lniyzNbUXomQxekh = 1878629693; lniyzNbUXomQxekh > 0; lniyzNbUXomQxekh--) {
        zOokGIU /= ylsicBYuiu;
    }

    return TngaJAEcMRX;
}

void VmYanIWunNcAqQwi::OyyAT()
{
    bool QRauCnhbLsSmzM = true;
    double WDMFRrhgBDhrEZS = -779496.8749255289;
    int YFNDxWpnYrVrPpK = 153282066;
    double IPVhD = -920648.9945487316;

    for (int YKidKpr = 1785373750; YKidKpr > 0; YKidKpr--) {
        YFNDxWpnYrVrPpK = YFNDxWpnYrVrPpK;
        WDMFRrhgBDhrEZS -= WDMFRrhgBDhrEZS;
        IPVhD += IPVhD;
        IPVhD += IPVhD;
        WDMFRrhgBDhrEZS *= IPVhD;
        QRauCnhbLsSmzM = QRauCnhbLsSmzM;
    }

    for (int lqlawOCx = 233692776; lqlawOCx > 0; lqlawOCx--) {
        IPVhD *= WDMFRrhgBDhrEZS;
        YFNDxWpnYrVrPpK *= YFNDxWpnYrVrPpK;
    }
}

double VmYanIWunNcAqQwi::LlpEp(int FlooUMargDwglPK, int EpoTWst)
{
    bool PePEpVZNDU = false;
    int GfMpJdI = 1449677617;
    string NSprEbPPVtJ = string("RTkZNvMkSRxGGpPEHySJPZghXgJUOQOocVndRpSjyBXZHPPLuNtIaszMBmqXRXJUUggvvGQPkQQAdQLVgaCuXjVJnOBFxkloktcZuQSCYptvDmuHJlBTSJGowJgDlQdAsbPCOnvPmxIRkZHjWkUVHhrJstEJWVMCXXezxTpgzHjOZmKbkOeASkXpxoEgsNlffjdTZotUxbvA");
    bool ccOyDfRQWAD = true;
    bool seDkshnH = false;
    bool bZcjlGUgdVS = true;

    if (PePEpVZNDU == true) {
        for (int wFNSFpKKAxiK = 598392213; wFNSFpKKAxiK > 0; wFNSFpKKAxiK--) {
            ccOyDfRQWAD = ! seDkshnH;
        }
    }

    return -584219.1804756395;
}

int VmYanIWunNcAqQwi::PKxhnT(bool dKIcaGTCV, double QlmDyluXjRZsJtOg, int wxPgyjXYqvNbqOf, double uGuuQBskYm)
{
    bool NnqdRUMOzU = false;
    int YhKWoElyIlRVE = 1116081799;
    bool llYWklT = false;
    string fLFXUNxdXht = string("SSHejJiPwubOl");
    int wmoeMV = -402189978;
    bool MUvbsMSdTsihtox = true;
    int oBehzbgl = 1317642317;
    bool XzaaoQuQgJzcCp = false;
    double BVWYxbRP = 119560.65419896433;
    int zEQaMpQihZCD = 1424528372;

    if (wxPgyjXYqvNbqOf != 1424528372) {
        for (int mezjlMZfzrOU = 468039549; mezjlMZfzrOU > 0; mezjlMZfzrOU--) {
            oBehzbgl /= zEQaMpQihZCD;
            wxPgyjXYqvNbqOf = oBehzbgl;
        }
    }

    for (int MofzQ = 1410925875; MofzQ > 0; MofzQ--) {
        continue;
    }

    if (uGuuQBskYm == 603586.5151265665) {
        for (int WzYNlt = 1553410427; WzYNlt > 0; WzYNlt--) {
            zEQaMpQihZCD = wmoeMV;
            llYWklT = ! MUvbsMSdTsihtox;
            NnqdRUMOzU = MUvbsMSdTsihtox;
            QlmDyluXjRZsJtOg += QlmDyluXjRZsJtOg;
        }
    }

    return zEQaMpQihZCD;
}

int VmYanIWunNcAqQwi::BhaRAXGLq(int RjbOz)
{
    double qZtzlqm = -646126.1766382328;
    string qFzqkH = string("OXRSxUMjSbNWvPQrJazZuDSwfnUjKapaDsPhGfpbRxcRGRfMpBbyRwncAYCLVEeGYxvXZjaaqqctcFovnxmmrrgJowwlYbgUISSlapGQfKblCrGFakilydYUVtfONkSXhmHouNiXcgeVirMJwzjkYESdqiPtLgsdbdoYGcKfyFUZShYZCtclBAhfVTBKpwNcAeQnKvblmzTngbFFWkJo");
    int iyleke = 488307562;
    bool uyYEdWMKoBlOcOcw = false;
    double rFcmIBsgAXNvRUM = 405239.13463250746;
    double oQXfuY = -204689.87958349934;
    double vnNsEztHDqCdp = -128779.79617334327;

    for (int FNEyfTz = 368263089; FNEyfTz > 0; FNEyfTz--) {
        iyleke *= RjbOz;
        vnNsEztHDqCdp *= oQXfuY;
        iyleke /= iyleke;
    }

    for (int ZMnTDKMgEyo = 1362860255; ZMnTDKMgEyo > 0; ZMnTDKMgEyo--) {
        RjbOz += iyleke;
        rFcmIBsgAXNvRUM -= qZtzlqm;
        rFcmIBsgAXNvRUM += rFcmIBsgAXNvRUM;
        rFcmIBsgAXNvRUM -= oQXfuY;
        qFzqkH += qFzqkH;
    }

    return iyleke;
}

string VmYanIWunNcAqQwi::LCOuAdmPKO()
{
    double ldcDFPcleFuXND = -733518.6986156062;

    return string("fKakjSVzqWnxnpkIgJfARlltnYvegpGLRLCCayrPKWhWOoGxgIBrzuxwkXnVUOAAPVxdhqrFZxUPJGbUDSMzVCImrtwuStOSCqZZCRdoBCCAfHTrefrnMzctBNiiSlMMgE");
}

VmYanIWunNcAqQwi::VmYanIWunNcAqQwi()
{
    this->mEzvKh(false);
    this->NvlgOYiYVuFoiD(286128995);
    this->khPmQNHINib(1945022416, -999810454, 757866486);
    this->DnBPYkrj(string("ScqWHNOFNPnoFeAAEUcFMwsHnfTPkpFVWBiJHEsJPsyoDInaxMvOkRmyfiSMqrfELC"), -717662.335607555);
    this->obFeS(string("yCSFyhaTDZaWdLHaPVPEHxYWwhLPr"), string("qCjfSNxfqrdVATVLxufgEDtuPokbmPGoWKKkqdMGxqYWLZQGwRfOTVEPxfvoobcgfCeOPeDJxKoAZQNiyHpoxtvREnsvSsjqwwDfoohNfSRAGDsvrQpn"), -114016726);
    this->ghmbLWOsTvgFQr(false, 1042079.8191997475);
    this->OyyAT();
    this->LlpEp(-1017841896, 1337301128);
    this->PKxhnT(true, 478000.9714826378, -719010954, 603586.5151265665);
    this->BhaRAXGLq(-836347998);
    this->LCOuAdmPKO();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AsXUtWdGvAnVqJ
{
public:
    string DhulemrA;
    int YUxOEpigPzl;
    string OkWiIUHZtyuJmYn;

    AsXUtWdGvAnVqJ();
    void ISlTGvBYjRzNQ(double DHUUarpFyjDc, int QltlXShnCcywuu, string JVdpEysPNSr, double YTfUUBeOXAiTt, bool vHxfipgkVAXt);
protected:
    bool jzjHpwC;
    double FJZYa;
    int VybQzEAqLj;
    double pxIyaURP;
    bool dmQqFXsSxVLcnWUC;
    double dKkFbjUThoHJcS;

    double uMhsYqEGxiLfIWY(bool QDaKthaqMaVp, bool PraKRmXRl, string xOERkYKnG, bool FpHLf);
    string UQuiOTleaWoNZ(bool qBTqkQnQyeEtheEm, string IBJinLXGqnYeAOls, double UhOdHleJFYSHUcu, bool GsRVQDEUjSe, int ZICQoUiLFYB);
    string cnhRHKvdKbUuF(string wUbOtAVtYz);
private:
    string XkwKiRdaGSGYXV;
    double cJaTvvu;
    string NtPlSQrkwfMkwuJu;

    double RRDBMWrkUWoFNh(int zptNfm);
    bool XHqHZBNyFwGgh(int pORHPcCib);
    double uDzkbl(double AELdZAZvMThCxnsr, int MBARvfiGXiXz, string VcxySXAgPGupWL, string wIMOvbSM, double pdcoIVCMsPiFL);
    int cIgFwUcS(double VjOHQZntgLzyT);
};

void AsXUtWdGvAnVqJ::ISlTGvBYjRzNQ(double DHUUarpFyjDc, int QltlXShnCcywuu, string JVdpEysPNSr, double YTfUUBeOXAiTt, bool vHxfipgkVAXt)
{
    string fPBLfhgJINjbdi = string("uguDIylVJyXPmKXaWpVkQIeSJakTaeFfAlNjmlGYdppCVytrVYPJgbDlCdJOvWpptHuYxTMSpGUBqAuXmleCEuovNghPVxLGjxLeEpWSTRXQAGzEIHNmGKXHyIaXqsdIEYmnfzurYsh");
    int AcdVHCpHPDsPo = 1934757386;
    int ucEDZi = 1302384110;
    bool NOzDswU = true;
    int jWrwhHmDlgdqL = 335481342;
    bool MxnFwvXxTM = false;
    bool EudpsorcBbXDss = true;

    if (MxnFwvXxTM == false) {
        for (int bMvTweyMCcWFYOC = 1170024499; bMvTweyMCcWFYOC > 0; bMvTweyMCcWFYOC--) {
            jWrwhHmDlgdqL -= QltlXShnCcywuu;
        }
    }

    if (DHUUarpFyjDc <= 252310.15486187444) {
        for (int XDKoAYxya = 1879977796; XDKoAYxya > 0; XDKoAYxya--) {
            continue;
        }
    }
}

double AsXUtWdGvAnVqJ::uMhsYqEGxiLfIWY(bool QDaKthaqMaVp, bool PraKRmXRl, string xOERkYKnG, bool FpHLf)
{
    bool nlXGYK = false;
    double KpuSqpdUVi = 440164.3875762528;
    bool tjkOMbTNbZdeEEL = true;
    string oBchgstzudgFiIk = string("VZTNOkEI");

    for (int rAdDas = 825568414; rAdDas > 0; rAdDas--) {
        PraKRmXRl = ! FpHLf;
        QDaKthaqMaVp = ! PraKRmXRl;
        xOERkYKnG = xOERkYKnG;
    }

    if (oBchgstzudgFiIk == string("gIJiUiA")) {
        for (int hqTJWBfp = 553273598; hqTJWBfp > 0; hqTJWBfp--) {
            PraKRmXRl = ! nlXGYK;
            tjkOMbTNbZdeEEL = ! nlXGYK;
            tjkOMbTNbZdeEEL = ! QDaKthaqMaVp;
            nlXGYK = ! QDaKthaqMaVp;
            nlXGYK = ! PraKRmXRl;
        }
    }

    for (int kUldtjzspMvs = 1025743992; kUldtjzspMvs > 0; kUldtjzspMvs--) {
        oBchgstzudgFiIk += xOERkYKnG;
        PraKRmXRl = nlXGYK;
    }

    return KpuSqpdUVi;
}

string AsXUtWdGvAnVqJ::UQuiOTleaWoNZ(bool qBTqkQnQyeEtheEm, string IBJinLXGqnYeAOls, double UhOdHleJFYSHUcu, bool GsRVQDEUjSe, int ZICQoUiLFYB)
{
    string VBQPmWpMF = string("zcPqARircJgNfCUvuzZk");
    bool WiGBBNZjOpjaF = false;
    double yAtsWBb = -1020736.3984815596;
    double QoXnTo = -405760.15341017715;
    int ozboVySHZPMxzsu = 1921211936;
    int XZXksihsm = 104207131;
    double CvnDEpoCbNKFc = -59483.50196153838;
    int wbjQjtFYDnj = -735257799;

    for (int ozdfg = 13103871; ozdfg > 0; ozdfg--) {
        continue;
    }

    for (int GPxStegA = 823745240; GPxStegA > 0; GPxStegA--) {
        XZXksihsm /= ozboVySHZPMxzsu;
        GsRVQDEUjSe = GsRVQDEUjSe;
    }

    return VBQPmWpMF;
}

string AsXUtWdGvAnVqJ::cnhRHKvdKbUuF(string wUbOtAVtYz)
{
    int yfXLZan = 914414184;
    int ePrFDRSjLdfRl = -951426013;
    bool tlppNDNZTyUtn = false;
    int RLartfNFdf = 1691720396;
    string PAGKcXRXsz = string("eSuSWeUDuNhcOJpcgLjLWXvqNHLeeAAioZeRkgVShiCHQMdxpjABxInHrhSknqUGTgOtfOqtBkfgpndrETBAf");
    int foJAGqcET = -1817767244;
    int CSJMUigNZpR = -1204901429;
    bool tESMRUt = true;

    if (yfXLZan == -951426013) {
        for (int aXnebXUYApZHryO = 15359783; aXnebXUYApZHryO > 0; aXnebXUYApZHryO--) {
            ePrFDRSjLdfRl *= CSJMUigNZpR;
            CSJMUigNZpR = RLartfNFdf;
            tlppNDNZTyUtn = ! tESMRUt;
            RLartfNFdf += yfXLZan;
            yfXLZan += foJAGqcET;
            RLartfNFdf /= CSJMUigNZpR;
        }
    }

    return PAGKcXRXsz;
}

double AsXUtWdGvAnVqJ::RRDBMWrkUWoFNh(int zptNfm)
{
    double DVEgmBsEyEZWMnLC = 840887.0234173355;
    double WssmsjFmtopeig = -677231.5577297555;
    string hiypCBIxNCO = string("MptzlojPpHTkYDXurevVDGDFUNTHaJLNTWLVkrrOnsANPitVQHBwseLAtsLokVQhDDiCyWRVWtEyHMHUFIZzBqURjwuoWpbnSiohaZdsNZyFeYSJCnEXUaiwpMwznHnIdYogdvigliwPgWDrYfuTjswGVhXjaivKBzbLTSrAOWBUqSgIGUhRWKLsSqFQcSyQoGhQhGFdtjFdJMNkrohGrbptHetSIOPgnvRtCYFCxshJqSEVkRczIHKUhKMGrw");
    double upwGEKHEbQUZ = 692364.3662177668;
    string DNmpLrpwg = string("EKlxNihtvZEyXNCThVKeYZTILjtgBLzNTmfnmbMrWTNrrPAoyzYaQiMBPhsIPqLpGjdOiOelNJHzyXTTAzozyBUOrOFzAITNijgMjfMtbKrBzBeYqcXVOmjFgvFZcRsLehTIBQqDTNZds");
    bool XMsElTjiVyXFWX = true;
    string DqSBE = string("CUdaMplrzNyVVfzcAbUwHYQQNhBpwOgYNGDqKfJeEsMPTXkCMvDdeolTAYWTBBTAXPwshZUMmJmFvnAuorRMnrYXaSBzdkKXcdCKvDUslyKAQRlzLBsMXxLPtOeXKTmCDNWCciLIQNkwMPQREUTnBlOSNrTKSZcZFoZtEmQLZRPJmgkPg");
    string ncSHVynTSokh = string("rMacPOvIBJhQswvZvNYDQhBgsaCqPnJkFUHDouVfxleAEmBzKiRTtkmBdeSrGvjxRgVStgbytIltFFFHgYtyweJfYPaQfNApyPfDyTkpRIBTTODKRkYpfkdztnJTBVTGQaHqqxgJbmZNzIXqoSEfgnZAWvnLGgoLtuNcNABHPKmzuXdMQDRRVLvYsHAXLuqhjFoTjVQAZvSVRtDgslXXkOqPVNcxtkMlqhQtmxzn");
    string ulGdVwXpQEbGsSLi = string("qHKbvejNdEDFUcuWiDXQEsMVgLpeuyBxAsGvuTxleZwFedMAjABEcRVEvgTk");
    string HfBZhbey = string("nCbTpETLrifuCtdmzIGBIDhtdceKrJDMEjHWDAscKfpfTdlfQtR");

    for (int enPOX = 1093416894; enPOX > 0; enPOX--) {
        continue;
    }

    for (int DJZmpx = 872045241; DJZmpx > 0; DJZmpx--) {
        continue;
    }

    for (int tIbczfaOwoXgFR = 617166540; tIbczfaOwoXgFR > 0; tIbczfaOwoXgFR--) {
        continue;
    }

    for (int rnnwgG = 839576211; rnnwgG > 0; rnnwgG--) {
        hiypCBIxNCO = DqSBE;
    }

    for (int BLjjyXQQKtU = 794630393; BLjjyXQQKtU > 0; BLjjyXQQKtU--) {
        DVEgmBsEyEZWMnLC /= DVEgmBsEyEZWMnLC;
        HfBZhbey = DqSBE;
        DNmpLrpwg += ulGdVwXpQEbGsSLi;
    }

    return upwGEKHEbQUZ;
}

bool AsXUtWdGvAnVqJ::XHqHZBNyFwGgh(int pORHPcCib)
{
    string vySIjGosCHrSw = string("KkFaXbBuzvnZqEyYOundsmBZkHOqGsZixKuxNPOnnRVnJyuxQLCRIXLUGfQpPIljQwENvuGBBKHYyoFyKCceXMIPhuTBLgJWnfuzOHyTchRbBdjdWkHDoMOvVVaAXoiSFWgweUMkknkGVHAhKUIPNNbVCdzHiXfgLFFVlaOfGiKYxGRpJwoPAMgTStbxgdBbmPxhxAvkhOGplrSrLKKkDTwLqoMfr");
    int VPaTaMToKPNaD = -792802008;
    string IQazaBBuqI = string("abBOxyjnBwXbCUkjlOQQzAdUMXFVEYnIaWSmEIjmuatrFzCMJNvMXuOIYXbtyDyJaFVjHaebigrbQMXsobqIXYpkukEqwJKsxAHXDBqkRkUZCd");
    string VhQxzGght = string("qTxsqTcdjGsuYOONVliwCSAGHGYdeeBMTiOeHeFYkJVfF");
    string ziYrPlncfofKHm = string("sCsdpeJbQIBCpFDbIgOgVwjbNPnHvQJmSjhGAdVSwhpBLMZtiLiYZBJPlhFwuJJTyZiIyzonYnCJlyGooTiUMGYnUkPWXRRZEKoMQTLQmaStHTRXEwtYfkBmDIbedlRlw");
    bool aNiVL = true;
    double kclRLbHW = 902558.0808020895;

    for (int xYORAHbSR = 240577520; xYORAHbSR > 0; xYORAHbSR--) {
        VPaTaMToKPNaD += VPaTaMToKPNaD;
        VPaTaMToKPNaD = pORHPcCib;
        VPaTaMToKPNaD *= pORHPcCib;
        IQazaBBuqI = VhQxzGght;
    }

    return aNiVL;
}

double AsXUtWdGvAnVqJ::uDzkbl(double AELdZAZvMThCxnsr, int MBARvfiGXiXz, string VcxySXAgPGupWL, string wIMOvbSM, double pdcoIVCMsPiFL)
{
    double JYYPBQbmufehvqX = 240803.97386070126;

    for (int EdnesNLQwuJodR = 1318132172; EdnesNLQwuJodR > 0; EdnesNLQwuJodR--) {
        AELdZAZvMThCxnsr -= AELdZAZvMThCxnsr;
        JYYPBQbmufehvqX += pdcoIVCMsPiFL;
    }

    for (int mboJpDBbTVcJpo = 557207521; mboJpDBbTVcJpo > 0; mboJpDBbTVcJpo--) {
        JYYPBQbmufehvqX /= AELdZAZvMThCxnsr;
        MBARvfiGXiXz /= MBARvfiGXiXz;
    }

    if (VcxySXAgPGupWL >= string("zQBnhgRIMhrvDAIuabWIaOsIKgcGtonLNUWsKPc")) {
        for (int iknCihznfperA = 1495135339; iknCihznfperA > 0; iknCihznfperA--) {
            JYYPBQbmufehvqX *= AELdZAZvMThCxnsr;
            wIMOvbSM += wIMOvbSM;
            VcxySXAgPGupWL += wIMOvbSM;
            JYYPBQbmufehvqX += JYYPBQbmufehvqX;
        }
    }

    return JYYPBQbmufehvqX;
}

int AsXUtWdGvAnVqJ::cIgFwUcS(double VjOHQZntgLzyT)
{
    bool pNuXs = true;
    bool YbxKFmAoQiIMXgfj = true;
    string UsftPgGMbGwGd = string("uuCWJKXBsHMBymjJtZTVsJrXDumnFjfCSjJwEbmlcsmGTgPMQuDzqZgoDhBbtWmVoeDAqZqRtvnVvISgHIQMAJCRwqIxKeLCCFFkDspxXwxLGpJgnoXoWipxEizNQRRGrTCfZagTjzwxnMJoBffjtzzMzquElJWwZmhkwJbXyHzvTFfzKvTyydAsBhd");
    int krmiiWJJGG = 913117844;
    bool LMHIJgiaxRRgiJ = false;
    string PSpyaFGibSQwQpqL = string("FLmTIrGELwcYfKZZcguEYwTWvMkmhzChWpgCeeEQomWCqUBaDeNUzklTQyQBTkZYJwIziyUnBLkUJsFDXnucGvXEqAkoGtqfoKAnZEqrcnBNHMaxxiSYFP");
    double WyXJbAciYEiLSIV = -865621.0672999002;
    double cWgvwTsLfyGBZmE = 884940.4520866113;

    for (int dQmhLOnfpsJzJ = 2081367630; dQmhLOnfpsJzJ > 0; dQmhLOnfpsJzJ--) {
        WyXJbAciYEiLSIV = WyXJbAciYEiLSIV;
        LMHIJgiaxRRgiJ = ! YbxKFmAoQiIMXgfj;
    }

    if (VjOHQZntgLzyT < -865621.0672999002) {
        for (int eWjEyznT = 792434842; eWjEyznT > 0; eWjEyznT--) {
            krmiiWJJGG *= krmiiWJJGG;
        }
    }

    if (cWgvwTsLfyGBZmE >= -865621.0672999002) {
        for (int hehBbxoCkh = 1702366713; hehBbxoCkh > 0; hehBbxoCkh--) {
            continue;
        }
    }

    if (YbxKFmAoQiIMXgfj == true) {
        for (int znUUfeHzJUrJEB = 300328263; znUUfeHzJUrJEB > 0; znUUfeHzJUrJEB--) {
            cWgvwTsLfyGBZmE += cWgvwTsLfyGBZmE;
            WyXJbAciYEiLSIV /= WyXJbAciYEiLSIV;
        }
    }

    for (int UtNJFEu = 1904924212; UtNJFEu > 0; UtNJFEu--) {
        pNuXs = ! LMHIJgiaxRRgiJ;
        VjOHQZntgLzyT += WyXJbAciYEiLSIV;
    }

    return krmiiWJJGG;
}

AsXUtWdGvAnVqJ::AsXUtWdGvAnVqJ()
{
    this->ISlTGvBYjRzNQ(252310.15486187444, -647136578, string("uNpVpBVMiNhaWfQyYiRChSOBOGUhTCQStzlZZDINiYqElqRrJmURaBbklSzGUisrYQmgprNztWUclPhUBLQaPvTbZQyOCYdlwBzvIrilhFxMzmuuOIxfcBEyZccvJzVfsaxQddxLlKnQoUGqnpTzvTAVEjojcYnxldVfayOvESAXRrUwSVhHMHOWzYVaokLHmsAdQGHfaCvfYEarOIjHJzqQGBFoozsDBfUuAFwlPltbbAaWuzzkKqH"), -563927.9775382024, false);
    this->uMhsYqEGxiLfIWY(true, true, string("gIJiUiA"), false);
    this->UQuiOTleaWoNZ(false, string("deAsRGlmCdHqHJjCFEYFJxQVCCuojKwHhCGchuLTiLFrvGehwBoGyEzOmwDmXdcQemSXFKKtBVmxCCdBkYMJZWPDhM"), 1048141.628261602, false, 1070265692);
    this->cnhRHKvdKbUuF(string("LwUAqsgQMkPRckVcPZtPYeylQFeEMrfTEEuTdvLeVoWlRhDeakyQTWCu"));
    this->RRDBMWrkUWoFNh(-1944092028);
    this->XHqHZBNyFwGgh(997899021);
    this->uDzkbl(-942871.6252972719, -756508610, string("zQBnhgRIMhrvDAIuabWIaOsIKgcGtonLNUWsKPc"), string("xzOrNqcLjWdFcHBybhCKqcGDHFDBvmpbqlTHTHRAqCEXoBNlvECDQvfuPhuQogpoSTcllSSNcvPHyIHrswlvbvTHZkMUeHnhRoBSPwRmvaedANwiwLgaSIhAQAIaEYa"), 571013.3823186232);
    this->cIgFwUcS(-13195.576112176888);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BUxJLX
{
public:
    string fXsBa;
    bool iUrNDGwnSnhAnw;
    double XbpBkAXvetKJkDR;
    string cEEdxmcJ;

    BUxJLX();
protected:
    double NEbetT;

    string giJuuyIyWadtWmSA(double okHxbEk, string VDASKskE, int wOsqXWBjtlBIL, double JgknDxLSKHI);
    void wjYrlswfLKq(string aWHBkLpwy);
    int woXWvUjwaaGf();
    void WRhyz();
    int XNiFwiJWFmgTVVMs(string TidpuRpfIWf, int RwQYNJOFQF, double wFoUh);
    int eqJuhPwB(double CMUzTvyRk, string rcKhbriuEupe);
    string aaNCT(double LlKpdLSPK, int jmHPjbx);
    void JHyGaSWGk(int XfAYt);
private:
    string jxEGNdTLnKBk;
    string lXOztBxj;

    double vdeKFUEJwOk(double xvpxiZsHTMEdfPBm);
};

string BUxJLX::giJuuyIyWadtWmSA(double okHxbEk, string VDASKskE, int wOsqXWBjtlBIL, double JgknDxLSKHI)
{
    int rmlDlISKxrioYw = -1141977147;
    int zgrhnAVAx = -2063647874;
    int VBAabFspDbvBCqn = -1317645744;

    if (VDASKskE > string("GplIVjsNIFwCQxiGeQzbCFnQdEcUcuFvZTzcoDZgFeyVnrKXHjavGI")) {
        for (int XYhYwNauXKUenQMN = 2108053458; XYhYwNauXKUenQMN > 0; XYhYwNauXKUenQMN--) {
            continue;
        }
    }

    for (int ujCWXHfKvb = 1836164581; ujCWXHfKvb > 0; ujCWXHfKvb--) {
        wOsqXWBjtlBIL += VBAabFspDbvBCqn;
        zgrhnAVAx /= rmlDlISKxrioYw;
        rmlDlISKxrioYw /= zgrhnAVAx;
    }

    if (wOsqXWBjtlBIL == -1317645744) {
        for (int DxrSKmtr = 1346290830; DxrSKmtr > 0; DxrSKmtr--) {
            wOsqXWBjtlBIL += rmlDlISKxrioYw;
            VBAabFspDbvBCqn = rmlDlISKxrioYw;
            wOsqXWBjtlBIL -= VBAabFspDbvBCqn;
            okHxbEk = okHxbEk;
        }
    }

    for (int ZvEpk = 658293355; ZvEpk > 0; ZvEpk--) {
        VDASKskE += VDASKskE;
        rmlDlISKxrioYw /= rmlDlISKxrioYw;
    }

    for (int VESeyVXBv = 762406363; VESeyVXBv > 0; VESeyVXBv--) {
        rmlDlISKxrioYw -= VBAabFspDbvBCqn;
        zgrhnAVAx += VBAabFspDbvBCqn;
        rmlDlISKxrioYw -= VBAabFspDbvBCqn;
    }

    if (okHxbEk > -776569.7753558297) {
        for (int natFJjCCEZXGtcBJ = 37891847; natFJjCCEZXGtcBJ > 0; natFJjCCEZXGtcBJ--) {
            zgrhnAVAx -= VBAabFspDbvBCqn;
            rmlDlISKxrioYw += wOsqXWBjtlBIL;
        }
    }

    if (VBAabFspDbvBCqn != -1317645744) {
        for (int pEdXnhIu = 1789205745; pEdXnhIu > 0; pEdXnhIu--) {
            okHxbEk -= okHxbEk;
            zgrhnAVAx += zgrhnAVAx;
            JgknDxLSKHI -= JgknDxLSKHI;
        }
    }

    return VDASKskE;
}

void BUxJLX::wjYrlswfLKq(string aWHBkLpwy)
{
    string dCMojWTsqzgc = string("QjxeMVQbLNUTQLYtGAnBwkBqGrlrLnBDexParwuMyhgiDgNVvLDjJdBlmWInCnEKDEZMOuCrCXbVemRKTeuDUQAEwjWFKAoqrwXRZLaXvdbuKnQtihUGzHdxWAvyrLmKAvhGKevxqDPlRYDUFpxMnSYbWFOBrAljNTGffRaXgiNrttKfXJgFFquMiJWpCjDDIdEduaPZtutatgdEEZOVFUIvXhPCiqKuXiBUbxlrIiSYrTvFSsbz");
    bool URNzRoxjrc = true;
    bool oqlbTnzbdLWRXa = true;
    bool wxOlcaTTNqQufdT = false;

    for (int rndXFw = 803562997; rndXFw > 0; rndXFw--) {
        aWHBkLpwy += aWHBkLpwy;
        oqlbTnzbdLWRXa = ! wxOlcaTTNqQufdT;
        URNzRoxjrc = wxOlcaTTNqQufdT;
        URNzRoxjrc = ! wxOlcaTTNqQufdT;
        URNzRoxjrc = ! URNzRoxjrc;
        dCMojWTsqzgc = aWHBkLpwy;
        oqlbTnzbdLWRXa = ! wxOlcaTTNqQufdT;
    }

    if (dCMojWTsqzgc <= string("CajHlEZgJdAmStIjnjpJhLgpORcIvGGZNfkamgogdzcVwbFwWfNJvhUHdssDXCXahBrximrQktgsNslxJMxnvUFFVlKEYOGsNRFEXdAAIVHsnppQaWggfNdkGxuIyitqxnOArZk")) {
        for (int IXQqGmsMTo = 671532705; IXQqGmsMTo > 0; IXQqGmsMTo--) {
            aWHBkLpwy = dCMojWTsqzgc;
            URNzRoxjrc = wxOlcaTTNqQufdT;
        }
    }

    for (int dPutnDqlOBPA = 885917983; dPutnDqlOBPA > 0; dPutnDqlOBPA--) {
        URNzRoxjrc = ! wxOlcaTTNqQufdT;
        dCMojWTsqzgc += aWHBkLpwy;
    }

    for (int IZQjjKqfCFn = 392974956; IZQjjKqfCFn > 0; IZQjjKqfCFn--) {
        URNzRoxjrc = ! wxOlcaTTNqQufdT;
        dCMojWTsqzgc += dCMojWTsqzgc;
        oqlbTnzbdLWRXa = ! oqlbTnzbdLWRXa;
    }

    for (int mTBNujLc = 712472552; mTBNujLc > 0; mTBNujLc--) {
        URNzRoxjrc = ! wxOlcaTTNqQufdT;
        wxOlcaTTNqQufdT = wxOlcaTTNqQufdT;
    }

    if (aWHBkLpwy == string("CajHlEZgJdAmStIjnjpJhLgpORcIvGGZNfkamgogdzcVwbFwWfNJvhUHdssDXCXahBrximrQktgsNslxJMxnvUFFVlKEYOGsNRFEXdAAIVHsnppQaWggfNdkGxuIyitqxnOArZk")) {
        for (int DeDdWNqn = 2129713234; DeDdWNqn > 0; DeDdWNqn--) {
            oqlbTnzbdLWRXa = ! wxOlcaTTNqQufdT;
            aWHBkLpwy += dCMojWTsqzgc;
            aWHBkLpwy = aWHBkLpwy;
            oqlbTnzbdLWRXa = oqlbTnzbdLWRXa;
            oqlbTnzbdLWRXa = ! wxOlcaTTNqQufdT;
            dCMojWTsqzgc = aWHBkLpwy;
        }
    }
}

int BUxJLX::woXWvUjwaaGf()
{
    int qRfyubDW = -711049286;
    string flwKQhHiFMX = string("dQaRxbMsTGHXUbYthygXOvuCIQFmCsEFAbBIwimaJZzCROzzdembGqHMdF");
    double ZeHVCiOgZGPpCBC = -583801.8917362934;
    int btrHsffVOwtD = 42663442;

    for (int RAHEipc = 16944389; RAHEipc > 0; RAHEipc--) {
        btrHsffVOwtD += btrHsffVOwtD;
        btrHsffVOwtD = qRfyubDW;
        flwKQhHiFMX = flwKQhHiFMX;
        btrHsffVOwtD = btrHsffVOwtD;
    }

    return btrHsffVOwtD;
}

void BUxJLX::WRhyz()
{
    string ehSETEVd = string("hOsZnYNBxmgqOUaMIxDpKJvzaOGBXcYOphmUBfBhctvYaVdVECnMEZwRJZWJeMbcdVcEXpvHXBfYISuwipchAvkzgJYcsAZTJYgfVuOAgXTZhhBUtafICvMrgEEmwcYLAydYFtYQiNnTRguQsyMtDztXkhoNAQZTQbpTShIHrtUtlLHpiSxJeWiApMbAiPhWYzCGnXIukpSdVEgqlvVqoGCrbMsnUdngfpmChoAnT");
    int VWSUoAvLqD = -294065863;
    bool PtIYtCUydW = false;
    double mRhsaAKhEHf = 527998.2435032363;
    string dyaHYYBJsSUOFziE = string("JymcexTLpYNQkydOHvjrMmjyloSBVTvyTphMzJYogWzYEVApSJibbsDTnRLiIZLeOrQXbuhnDuMyvfdmvbRmAinFrHDdOebBXpZPOdirTbxpUEmhbYOQQjoMSKRyPRgcxKUXJAbKfiVXQeeORlFRzXZKOLtnwUfYckSNPLcPYTpBNcTKXKvIpvmyuDeSsFCTxsEjRwcXcXPECKyMfpbcj");
    int VFaTynUYHMwM = -508454511;
}

int BUxJLX::XNiFwiJWFmgTVVMs(string TidpuRpfIWf, int RwQYNJOFQF, double wFoUh)
{
    string RSeUlfifloecg = string("DhmomuTpwHtawaLwbOzFMwTwjKndqzstevwzrmygRKIEhepOHKbPQvdIrUjDBfjgEyPDPnlhxkkBGkYwEdsWPKTKGSQNToqnhFbLTTMXfmDACfazbXNyKYBCLErgUBkbYrbBuoyDFrtvzoHqqBjsDMprVybJeXZYWINzemQZAAUEUaBjwu");
    bool xwPYs = true;
    bool loqQWWBdNXxLDAoT = false;

    for (int JkQGw = 83100864; JkQGw > 0; JkQGw--) {
        TidpuRpfIWf += TidpuRpfIWf;
        loqQWWBdNXxLDAoT = ! xwPYs;
    }

    for (int wHIAjvTPNp = 428033926; wHIAjvTPNp > 0; wHIAjvTPNp--) {
        RSeUlfifloecg += RSeUlfifloecg;
        TidpuRpfIWf = RSeUlfifloecg;
        xwPYs = xwPYs;
    }

    for (int AdJRWaGkcYVfnEH = 1972836233; AdJRWaGkcYVfnEH > 0; AdJRWaGkcYVfnEH--) {
        continue;
    }

    return RwQYNJOFQF;
}

int BUxJLX::eqJuhPwB(double CMUzTvyRk, string rcKhbriuEupe)
{
    double xxtbvULBsunW = -811403.3927060798;
    int fpjvcRIUp = -788935262;
    string OqJXmFyKZcNYYlIt = string("coZuCVTCixnFNDkapjJuHTxCWFlFGMKaxDrjFNgTXVpwhQLUBlwYTxhInaPSUPGmABvImkIppCSzUDNaNEfLXYykpMRoSIFrtSlHldHAfwYHdFMqVZwdyeZYBCOyFCKXsCyElpUjwYaGJ");
    int jPVYuDcNVo = -2019236787;
    string ggCuHrgbjKPBVJLW = string("hqmrueMyzsABbGPIUIhIkkNmkvMWzDqYNPqdUjQCiZXuBmqndIlVePdmHHvsOGROhmkJLGdUWfzmybwXJgPIHLFPcCzpcTWUdDBgtpdPgZitGKMRkBoyfYMoOMpcIwdNZjxoYaLucYTzkZsnlKTDCAcImhVJZGGRargHNiGcyeEUOWjfDdrc");

    for (int QdyhxdrFFE = 2032295305; QdyhxdrFFE > 0; QdyhxdrFFE--) {
        OqJXmFyKZcNYYlIt += ggCuHrgbjKPBVJLW;
        xxtbvULBsunW *= xxtbvULBsunW;
    }

    for (int FSExhQf = 1526024205; FSExhQf > 0; FSExhQf--) {
        rcKhbriuEupe += OqJXmFyKZcNYYlIt;
        xxtbvULBsunW += xxtbvULBsunW;
    }

    for (int conoSjoUGdEz = 1815534519; conoSjoUGdEz > 0; conoSjoUGdEz--) {
        OqJXmFyKZcNYYlIt = rcKhbriuEupe;
        rcKhbriuEupe += ggCuHrgbjKPBVJLW;
    }

    return jPVYuDcNVo;
}

string BUxJLX::aaNCT(double LlKpdLSPK, int jmHPjbx)
{
    bool uZZZyWpaYBvQnWC = false;
    int EmdiYGAe = 1954287777;
    double LiJMidebVUrZu = -68539.78685730108;

    for (int FhLCDPagn = 636277074; FhLCDPagn > 0; FhLCDPagn--) {
        LlKpdLSPK -= LlKpdLSPK;
    }

    return string("ODAODvibHyJkYNjRHLpoiAgtBwypdoFBIqVrokirRAsUBLARFosLyKWOHKQYnZKdaICFFurfwUsNWCTewVxIUcdKrcQqEbJEmliyoaoGyfQVGyMmAEwlqsXDoJRGzVtbvuHgPvEYCxqKqJrrLfBuFRACujHPjBGTQQIJNDBhrbplOJYlxHkHoWdeZiGHjJYNlRrIARrmNqZFnQNMNHJfsWurEjEorFy");
}

void BUxJLX::JHyGaSWGk(int XfAYt)
{
    string SWrpDz = string("CFZAXqcbEcLALQgpGIcZnWLpqLXskmbCwZjYOjCzNBkcbZsrrmWtZLhQiqZeAIqbrFcjYPUMRZCECqyTuKTVasgKBTpEnHEYTSNGlVZtZuPIlJWfqYSCOutMPLhbBTYRjnxaHfeVrzoTdOmEbZwUPGzfPNgtbjVNcGzrdVsWKZShFpf");
    string HsCmbl = string("yxYmVMWUHXykzCdmTSFJGNwVVGyVOLmlMPaDGSMahlojIotIkvisSLuigcTjGftIpjxlVuDlDIpfceLFTgIVjGSPfbYqWaVUUYAhNJgEHoZxxtKnJTumDMenJjJixdEJmOJGwWgNWhVBlL");
    double PCdNjDrUrwC = -14094.574987047838;
    int IcrfYgxKHO = 234623207;
    string mrUBQQnyJ = string("gaWRsYDOAAlGSATvSoCKQOtQdKSsZCrtBlQPYymPqBDiSyCFCHBbyUkHNsBkgybWCRivxVjJDpYloUrQWpRKlwqyplqBkWWEWagnbXUrbEtDEjmcQHRwWZWhWwQhMMlrEdjZO");
    string pwCTDbyM = string("cdHGQhbdeKREMWuCfrWLKnzyPyekzlUrxmybBGAvbJwCqqgFHVpM");

    for (int qalGqWcIXq = 1394308903; qalGqWcIXq > 0; qalGqWcIXq--) {
        IcrfYgxKHO *= XfAYt;
        mrUBQQnyJ += HsCmbl;
        IcrfYgxKHO /= IcrfYgxKHO;
    }

    if (HsCmbl > string("CFZAXqcbEcLALQgpGIcZnWLpqLXskmbCwZjYOjCzNBkcbZsrrmWtZLhQiqZeAIqbrFcjYPUMRZCECqyTuKTVasgKBTpEnHEYTSNGlVZtZuPIlJWfqYSCOutMPLhbBTYRjnxaHfeVrzoTdOmEbZwUPGzfPNgtbjVNcGzrdVsWKZShFpf")) {
        for (int czHQmmJAIWyWZ = 1594097412; czHQmmJAIWyWZ > 0; czHQmmJAIWyWZ--) {
            continue;
        }
    }

    for (int shcOkKYUFYNMLYL = 284655459; shcOkKYUFYNMLYL > 0; shcOkKYUFYNMLYL--) {
        pwCTDbyM += pwCTDbyM;
        mrUBQQnyJ = HsCmbl;
        mrUBQQnyJ = HsCmbl;
    }
}

double BUxJLX::vdeKFUEJwOk(double xvpxiZsHTMEdfPBm)
{
    bool vvdBi = false;
    string JFfCh = string("cuqsvhQcESByyUfiDzz");
    bool XWINnTZESZ = true;
    int FpYnVctK = -1773937261;

    for (int hIEUumgtROEwjNj = 1494284376; hIEUumgtROEwjNj > 0; hIEUumgtROEwjNj--) {
        xvpxiZsHTMEdfPBm -= xvpxiZsHTMEdfPBm;
    }

    for (int UyPEPamevL = 284277377; UyPEPamevL > 0; UyPEPamevL--) {
        xvpxiZsHTMEdfPBm /= xvpxiZsHTMEdfPBm;
    }

    for (int HcvtQYcLHtXckWDS = 1633306401; HcvtQYcLHtXckWDS > 0; HcvtQYcLHtXckWDS--) {
        vvdBi = ! XWINnTZESZ;
        XWINnTZESZ = vvdBi;
        vvdBi = XWINnTZESZ;
        JFfCh = JFfCh;
        XWINnTZESZ = ! XWINnTZESZ;
    }

    return xvpxiZsHTMEdfPBm;
}

BUxJLX::BUxJLX()
{
    this->giJuuyIyWadtWmSA(209233.3155951657, string("GplIVjsNIFwCQxiGeQzbCFnQdEcUcuFvZTzcoDZgFeyVnrKXHjavGI"), -1784405018, -776569.7753558297);
    this->wjYrlswfLKq(string("CajHlEZgJdAmStIjnjpJhLgpORcIvGGZNfkamgogdzcVwbFwWfNJvhUHdssDXCXahBrximrQktgsNslxJMxnvUFFVlKEYOGsNRFEXdAAIVHsnppQaWggfNdkGxuIyitqxnOArZk"));
    this->woXWvUjwaaGf();
    this->WRhyz();
    this->XNiFwiJWFmgTVVMs(string("RbldAJDNC"), -2053710714, -854475.5632446868);
    this->eqJuhPwB(37109.95548693693, string("afWBBCnelHhdgSxyUPXaCPvoOtLLNQahjDIYkvkBlvsnOsVHHAMOsTdmzZbOOuhGMtpRzpNYTKLNRUjSxubRMhoIKKcQZnLqpsAuTNMPkZktjWtNnUxp"));
    this->aaNCT(-711394.6598245072, 1026707315);
    this->JHyGaSWGk(-297760743);
    this->vdeKFUEJwOk(-848070.8267165151);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yzotXEWGo
{
public:
    int lYfVEmXjc;
    bool gLufNrLXiSeM;
    int rheFMtqFrg;
    string qIpiWHAFIFVwTF;
    double qVlQIanGkuyHsAK;
    int QaxbjtaN;

    yzotXEWGo();
    int mWWknLaANxicvhnQ(string BWlyAQQHlai);
    void ONaVRjfrqI(double nraXpEKwduLHt, bool uVxroIaBYZHwWoM, double RzKAJqFLkWd);
    void vvdGBCRlrjT(string LSfeZIj, bool RkufZKbleJKpTjdq, double iaMHroQcviWNq, string FjJNWNd, int jGXWCvaAdYCnkkoM);
    bool NaVtwRyccYyhmk(string uNlJRMbMqvgRm, string QqWkwS, string IDkpPHrgYtxfq);
    string fpHFzOlDiQlNc(double jfvtGXkutMRIaFx);
protected:
    string qzRTnQWtiNtWSFr;
    double COjuJPPrHW;
    double yyXJTTYS;
    double IfQbFB;
    bool obyZUmvEHvxuvETh;
    string vYABnbFxC;

    bool tLwZQz(double sMntcngsz);
    void bAdTWVKQ(int cdYYPSnUMRov);
private:
    bool jnTHxKGIZNs;
    double yCkmkvJdJyMFCW;

    int hsFKrPcRSicnZ(int kkArUzNvNEY, string sQidWrAHN);
};

int yzotXEWGo::mWWknLaANxicvhnQ(string BWlyAQQHlai)
{
    int kcBBdBvoptnJQ = 887244980;
    bool CyUmjQmyk = true;
    double PEPpRpVUYo = -97046.56206041067;
    double JonJBBtdkIJPBBL = -344903.0404986782;
    int hzSfIgu = 1462638525;
    double idFDcFySH = -373748.300627055;
    string RqhQoUxWTiMFrp = string("qciuzyRekuBtPpERoHlDZYtNVRXgNtRXFHYGacYTYUqOuXjQoOUKZSaaSyjyuFBiHFpvsIDwnNcTtBRUmBuyMtLmVsgzUQFGYvbknaLsuhtbbqBTkLLLvwRMgnyCTjYKWCWcYDiaGQngCccLMTthkIxhyyxEAwtKAwYcKryJORDdixfWBFrAFgoKRQawBgjWyrWxgoxEBGpWjgKOkGRDcDtrCiSJgEjytgjoLLODZYEpGgEcydIgAiNndV");
    string wzZAF = string("lMaxjIKt");
    int lkXNvMAFyQUvi = -947871888;

    for (int fggImOUBTHxdfBm = 1652568304; fggImOUBTHxdfBm > 0; fggImOUBTHxdfBm--) {
        kcBBdBvoptnJQ = kcBBdBvoptnJQ;
    }

    if (hzSfIgu == 887244980) {
        for (int dpKIvLf = 670090042; dpKIvLf > 0; dpKIvLf--) {
            idFDcFySH = idFDcFySH;
        }
    }

    return lkXNvMAFyQUvi;
}

void yzotXEWGo::ONaVRjfrqI(double nraXpEKwduLHt, bool uVxroIaBYZHwWoM, double RzKAJqFLkWd)
{
    bool eoMDReOkPMIBDc = false;
    int toYEENcejwflrXCQ = 1363090;
    int ctWDuZGj = -492435676;
    int lvWgpkIATuflXL = 82458214;
}

void yzotXEWGo::vvdGBCRlrjT(string LSfeZIj, bool RkufZKbleJKpTjdq, double iaMHroQcviWNq, string FjJNWNd, int jGXWCvaAdYCnkkoM)
{
    double FUOrJ = 666407.6793686494;
    int wXGBAd = 1318701642;
    double JbUWbPyzGxw = -286010.70493390085;
    string pINDRHWanenMA = string("XyQfSOrgxfQPTeJCoycxDEWpRAuCEbjYiWjXfvCmAoJAZRUijiIqiWfxpDeQJbQCfPiLj");
    string VMRLOiCXhplC = string("iNmAoUhFrKBuKnIAkoWrCdSODINUENpEoFqtgjaFSEoYOSQYKhM");
    string WRbxGuJMyFYGBu = string("TeGdrHfpNQMApfdyynvKtYNhnEfCCbArglFNRwkUhYJrfkmSnp");
    double rbwoE = -552259.7463876235;
    int FrXxRmyzfGdd = 1995870360;
    bool JgNEDPpMzLY = true;
    double RNnADujkrsipxla = 25417.984264293213;

    if (LSfeZIj > string("fmmHyNXFvDDPutcMuLJbwNmTELjKbEfWxahrbtVmNnUVZWLDtMhXUpNNTurCqqZNIFQJysziImZDoakyYMuPRCXtsE")) {
        for (int wQdSDUmLStSRJl = 432852488; wQdSDUmLStSRJl > 0; wQdSDUmLStSRJl--) {
            FjJNWNd = LSfeZIj;
        }
    }

    if (FrXxRmyzfGdd < 1995870360) {
        for (int xZZKutfxNlGkHa = 2020763569; xZZKutfxNlGkHa > 0; xZZKutfxNlGkHa--) {
            LSfeZIj += pINDRHWanenMA;
            JgNEDPpMzLY = JgNEDPpMzLY;
            FrXxRmyzfGdd /= wXGBAd;
        }
    }
}

bool yzotXEWGo::NaVtwRyccYyhmk(string uNlJRMbMqvgRm, string QqWkwS, string IDkpPHrgYtxfq)
{
    double aqqUxHsMEdLrvMh = -915493.500962181;
    bool dyAUsuyWaT = false;
    bool aCwTpJoPIsWXeJym = false;
    int AMPsVgNLDDT = -1502800060;
    int xjGjcwDUvHNnI = -372553906;
    bool gifQiQZ = false;

    for (int MtzbAgcfFe = 1439983089; MtzbAgcfFe > 0; MtzbAgcfFe--) {
        continue;
    }

    return gifQiQZ;
}

string yzotXEWGo::fpHFzOlDiQlNc(double jfvtGXkutMRIaFx)
{
    double mYIPEUhlj = 966334.2248140625;
    double kWERPJlbBbX = -544782.8518773406;
    string QAAqoAS = string("fjKmFrOhBqNuployUVNxeLcAdVDAKKDshgUmQsGVpGWwJRRaDiecTvOPxkSisgbgcFImCCtOHNTRgzFEFwQYNpEhtuNkCqWsffmNJMbtaiwYESjaHVnIthhIGmksnvNePRehFrBEzXGAIYIBviRSEmIOJSappcxVEJALSUJfhMYKmtDJukPfcGRfNoqgUIuLJPPLccvymEtNrStIJnnNSmhPLXVkjRHBCzKozi");
    bool qxMziqgHaCLhgquY = false;
    int UVBdDxjmJEzvTKpV = -80896157;

    for (int ddFyOikvsMheEvs = 1228572373; ddFyOikvsMheEvs > 0; ddFyOikvsMheEvs--) {
        jfvtGXkutMRIaFx += mYIPEUhlj;
    }

    if (mYIPEUhlj != -544782.8518773406) {
        for (int ztOHcM = 996714301; ztOHcM > 0; ztOHcM--) {
            jfvtGXkutMRIaFx *= kWERPJlbBbX;
            mYIPEUhlj -= kWERPJlbBbX;
        }
    }

    for (int wgNOnMwfxCwM = 1983426806; wgNOnMwfxCwM > 0; wgNOnMwfxCwM--) {
        QAAqoAS += QAAqoAS;
    }

    for (int mjRxquZV = 486416139; mjRxquZV > 0; mjRxquZV--) {
        continue;
    }

    return QAAqoAS;
}

bool yzotXEWGo::tLwZQz(double sMntcngsz)
{
    int rbKjEpuvbozlKxLQ = 1197197654;
    double MmZZmSZiwR = -261652.77318725915;
    double tMusv = 1022557.8052757897;
    int npIKfrhZPFXeA = -349913742;
    bool OpVgPzeYTgEcN = true;
    double JhdkoNMDq = 300866.30136511597;

    if (JhdkoNMDq != 164271.89036099752) {
        for (int PDptmQfusGswVrp = 199892148; PDptmQfusGswVrp > 0; PDptmQfusGswVrp--) {
            npIKfrhZPFXeA -= rbKjEpuvbozlKxLQ;
            JhdkoNMDq -= tMusv;
        }
    }

    for (int nrCiU = 1851063724; nrCiU > 0; nrCiU--) {
        JhdkoNMDq += sMntcngsz;
        JhdkoNMDq += tMusv;
    }

    if (JhdkoNMDq > 164271.89036099752) {
        for (int OKurOftcdcWTOB = 1152357209; OKurOftcdcWTOB > 0; OKurOftcdcWTOB--) {
            npIKfrhZPFXeA = rbKjEpuvbozlKxLQ;
            tMusv += MmZZmSZiwR;
            npIKfrhZPFXeA += npIKfrhZPFXeA;
            tMusv /= JhdkoNMDq;
        }
    }

    if (MmZZmSZiwR > -261652.77318725915) {
        for (int lJtrfUBFgxMfnLS = 766283385; lJtrfUBFgxMfnLS > 0; lJtrfUBFgxMfnLS--) {
            npIKfrhZPFXeA *= npIKfrhZPFXeA;
            JhdkoNMDq *= MmZZmSZiwR;
        }
    }

    return OpVgPzeYTgEcN;
}

void yzotXEWGo::bAdTWVKQ(int cdYYPSnUMRov)
{
    int cuThdKim = -839462537;
    bool HztTxc = true;
    bool SnffRYLInbJpwTou = false;
    int Yrchtv = -1318748107;
    double OomwKPWYRmM = -83550.89496880493;
    bool pZOLzPuAUzwOn = false;

    for (int FjeZCl = 1325109532; FjeZCl > 0; FjeZCl--) {
        continue;
    }
}

int yzotXEWGo::hsFKrPcRSicnZ(int kkArUzNvNEY, string sQidWrAHN)
{
    int zlBSRTKDa = -333060715;
    int PBYurxlZLKPeQoF = 312326224;
    bool xFJVfhjqdMNZJEiN = true;
    double sdDwYMbi = 509053.3955488253;
    bool KxlBczgpLC = true;
    string WoKXj = string("fJVnIqPmCWlbqeVpvroJcCCMXrhsgrICjSIVMAuAJZsuwbWUPMwyUDzTWVXscyPPSqfcCdYNKXMtnPBKrPKpSXAptCgFMVYmTAmBUDjaOFmawcONvyXfyXozNEQkUJSpnDjrBvQasPUqZfipwmYnPyUfIryok");
    string xrhmdNwZW = string("tzfxZrCptsZpRlUjWAKowBctrCurWnmrDbYPtSXNecZFAzjxRDrsXNVizicEIFmZRAXokAhySRcJkLbtoPDaMivYvMnLNhyQfDGujaQGimgkcrwkEUloJEQijdXELRTgkGnnLAkoxFbGGqqoeUbcTUcKcPiUoYYLiaGkMTijYXGOEhqiWOTQwmhRkRIzqmNZhDuPSmRqTlxJoXTYqhCrMWfcYoOMfImStryxzowYLjognishMoQCSgCoZ");
    double eoPhyoepXTTqGU = -412710.77421156695;
    string ZGFiZLfCyUTlQeYd = string("CBFaADoobvjjjDbxDqUovcVJiKEfCbgKYoA");

    if (zlBSRTKDa > 312326224) {
        for (int gaYkjbOKacDTr = 1024139105; gaYkjbOKacDTr > 0; gaYkjbOKacDTr--) {
            xrhmdNwZW += ZGFiZLfCyUTlQeYd;
            sQidWrAHN += ZGFiZLfCyUTlQeYd;
            zlBSRTKDa = zlBSRTKDa;
        }
    }

    for (int asdTGEPzLlHt = 365002439; asdTGEPzLlHt > 0; asdTGEPzLlHt--) {
        xrhmdNwZW = sQidWrAHN;
        eoPhyoepXTTqGU *= sdDwYMbi;
    }

    return PBYurxlZLKPeQoF;
}

yzotXEWGo::yzotXEWGo()
{
    this->mWWknLaANxicvhnQ(string("LrNELSAXUGnllbBuoVXRGNAk"));
    this->ONaVRjfrqI(-507837.9995980686, true, -893403.3630739314);
    this->vvdGBCRlrjT(string("fmmHyNXFvDDPutcMuLJbwNmTELjKbEfWxahrbtVmNnUVZWLDtMhXUpNNTurCqqZNIFQJysziImZDoakyYMuPRCXtsE"), true, -457811.5170358564, string("SMESoNgNElcNbGrBahwLecvsShLofwNXrudPReqQRDqkwCaLjIrGNcWoepLEAhCTRQnGlWFQmynalVkyTpCDeFP"), 1220960867);
    this->NaVtwRyccYyhmk(string("TuCOJOfC"), string("YHjTIjUwYfcsLsLVkeFljePQKJvNNCXEdhrQOXhfbOmmspJVWCqHbSOxNGsLiCYaJXQowobQCSyhRoqtoyhUoMpgCmDdmLpqkKxRbEAJXwpyRBdjRJifEHpfJgXSrHscnZ"), string("exS"));
    this->fpHFzOlDiQlNc(-324735.49175719847);
    this->tLwZQz(164271.89036099752);
    this->bAdTWVKQ(422646697);
    this->hsFKrPcRSicnZ(-1630586208, string("DHGesBHXtdjJPayxANDTLyofkhDjIdsqslHNLQGPgANUucDsrQUGkvFihLtjDSOWUeBRupedJqxEonPvqhdhQJGhxqdTiCGHERqWAANeXseYbKzWOJnDryPuFgVIlWcYCEewTmlWiyouYjjaLdQCZtQuGGjIeplgmRrygcqNzZYRmCDPATPEKBjvhhQNEJdWrWKnzRAjmMcUEsBjYgxsHfTUDMVqgxZFH"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kmTiNjaLTwPXxc
{
public:
    bool mqpLXTVf;
    int DrIPRUHfRgI;
    double gBtUsrdo;
    double mvKoTTDbTlv;
    double DRqIaO;

    kmTiNjaLTwPXxc();
    int eWMGJHqPuFXtYzp(string iUNuMQEszcZxuVGH);
    double KaCALp(string KoipqOpIpVMJ);
    void yURrgElyHyS(int qMOxnnlmQNx, string RnVzqetCTJ, double ONJavTzVSBjGuoyq);
    bool jhnfuGtNJ(int QoujSshmdBObK, string SGxsYBnb, int kywwcL, string SvxcZZDsANYC, int ExzvDwDC);
    double phhgEoRw(bool mAVxDm, string gkJxhmVoyFo);
    void ZBZkDaNiE(double WaAWaA, string ocbIjpUxlsKHBgx, bool qfncFrR, string kwpVKjhJIsDP);
    double XmlYLCdmZoD(double RWXZe, string Xgizr);
protected:
    int KGgjX;
    int ySGzRLGalduJZPyB;

    bool UqAiUY(int SByJhBi, bool JzjOnXXZaSJaB, bool EoWkmOrfndlT);
    double cVPgtb();
    bool zWtqvPqf();
private:
    int zRoyHSPWwuzr;
    bool TMPhgyrz;
    bool rsoNLNRjtBZrs;
    bool GVGHuqqoibn;
    int UKKRL;
    bool JfPMwe;

    double ANsyrjWYvDj();
    string hlleSvMNvXYKH();
    bool WwRAoCvWn(string kTJae);
};

int kmTiNjaLTwPXxc::eWMGJHqPuFXtYzp(string iUNuMQEszcZxuVGH)
{
    double DyKAAMwHjdaNB = -428232.44464953704;
    string MOHmdXuE = string("NcjqCpKgXNxuQtJpQuQvhFltDDxDSdIOhyrJoOucnKGBNavZoEKxoXMmVCotjoVrQXJrlHdWQtPcbmpuGkofdYFJoIqOShEmEfGHrCJdrQkenpKSxpWsyWSzMBpKtaZaqJytYRjvgpAgpXwrCeHAVHsnBoOuKKaSamIvGTIeWmRhLAdrygFNRrTbpOmgpQznZwZTuevwyFxiIAfMoqGxiEtamlDCxLCnOloghdKmpz");
    double pzkPTFTdYzKV = -245592.14403052835;
    double rzxnrG = -361738.3813392234;
    string XFPQZmM = string("XYUrjuaHglcOYRXQbsJWWOTafTQITwuwOxTCszUNDXvCTcSorNMOEAVobccvFvSMlReXEyDMyGWPBZrPXHszvLMjGHKbvNOLVcEWWgkwAydMcKfiUdlkBLNYGSTmlOqNvtXhWxPKzqkklvHdQAOOWqtLvussEDsqVvfzQBbTZUxyEWYqfKtVGqNKqEcW");
    bool EhzeFVYNNQ = false;
    int JUtmSY = -941724369;

    if (XFPQZmM <= string("XYUrjuaHglcOYRXQbsJWWOTafTQITwuwOxTCszUNDXvCTcSorNMOEAVobccvFvSMlReXEyDMyGWPBZrPXHszvLMjGHKbvNOLVcEWWgkwAydMcKfiUdlkBLNYGSTmlOqNvtXhWxPKzqkklvHdQAOOWqtLvussEDsqVvfzQBbTZUxyEWYqfKtVGqNKqEcW")) {
        for (int iCmZWwSLOXnPbR = 432629616; iCmZWwSLOXnPbR > 0; iCmZWwSLOXnPbR--) {
            pzkPTFTdYzKV = DyKAAMwHjdaNB;
            iUNuMQEszcZxuVGH = iUNuMQEszcZxuVGH;
            pzkPTFTdYzKV = rzxnrG;
        }
    }

    for (int yVRTAOlSVLl = 1505941634; yVRTAOlSVLl > 0; yVRTAOlSVLl--) {
        rzxnrG *= rzxnrG;
    }

    return JUtmSY;
}

double kmTiNjaLTwPXxc::KaCALp(string KoipqOpIpVMJ)
{
    double LjPbXNzDXWj = 47483.077517164165;
    double fYflss = -604312.3600819047;
    bool FZufcjQVJv = false;
    double TCfUkiQlDzxCRFs = -86626.18364251064;
    double EbyQbVIlfGdvXL = -572995.7927320354;
    int nLGzwmNHVAP = -1123900711;
    bool cXdtxmpQMzmaMSBV = false;
    bool FhLEnhpGM = true;

    for (int cWtMMJbkGRpwx = 1074762902; cWtMMJbkGRpwx > 0; cWtMMJbkGRpwx--) {
        KoipqOpIpVMJ += KoipqOpIpVMJ;
    }

    for (int xSOtxesJP = 1868267761; xSOtxesJP > 0; xSOtxesJP--) {
        FZufcjQVJv = ! cXdtxmpQMzmaMSBV;
        cXdtxmpQMzmaMSBV = FhLEnhpGM;
    }

    return EbyQbVIlfGdvXL;
}

void kmTiNjaLTwPXxc::yURrgElyHyS(int qMOxnnlmQNx, string RnVzqetCTJ, double ONJavTzVSBjGuoyq)
{
    double EQjmItsQMDO = 513572.7303986177;
    double cqtOlaJX = 35254.77951714059;

    if (RnVzqetCTJ >= string("PPpXZhNguxzhNkVDbAdITfRxYVTWjyXGBuIObqtmvzWJtdJhnoKdWOPeZUeiZBNhkwJIzCsHnKeZxrmeOIKTZNLjvktpfTXABcqVfoPMmeSVCNILWxFbuGFczLauSqywgOQQUtReJcmvwwTYhYHaEWSgBQZCcsymik")) {
        for (int OhCEe = 1317143108; OhCEe > 0; OhCEe--) {
            cqtOlaJX += EQjmItsQMDO;
        }
    }

    for (int AhPphtSKMRfOIaTo = 1208754126; AhPphtSKMRfOIaTo > 0; AhPphtSKMRfOIaTo--) {
        cqtOlaJX *= ONJavTzVSBjGuoyq;
        EQjmItsQMDO += EQjmItsQMDO;
    }
}

bool kmTiNjaLTwPXxc::jhnfuGtNJ(int QoujSshmdBObK, string SGxsYBnb, int kywwcL, string SvxcZZDsANYC, int ExzvDwDC)
{
    string DiDWfaOo = string("ZSTGoicNPnvelwYXwOTYxFxzNZOvYenfvpIOaxtAOEnbSwWMlfeAcbAtUuNUEbqyatMsqSnmMjgBjRpDIhUvTMabGAWGyNQPGeHerUhScNVrbCXyiPdoWzexjEHmChTVqDJwFmwiGJBMSWvwLAAhanGHihuxKDWXhCMzBfKegVsOhnhlxuvRRArMPsRQeANPeSSusioUsvcsFWyPQDevMgyrEGamWAvwisaKv");
    double ztUggXNrzIVUPF = -533852.7078453888;
    string XPsIkG = string("KEwVhMjZwKDNhjfxyfYpBmBzalSHLmMEmZTRmZlmJWSaVKljvTlfvpivgGGKeTLYWAnFRpWINaJMFwovuYYwGVCsyVrvlUHtfZujKdXlFQYbepIKGamjNbnjlMiKIYxwoOQnVqNflesOnTIBxboxSfrJwKzfOUGhRMyjyUXTVsCQsehyIqGPrfGefHJOikLMxiafHEKFJzOideCCHIvblYgKgGrdhUJbnvZBMfTkbykeXfaAckYpmyxcBDX");

    if (XPsIkG < string("EVnmdLeASMIEJLdFXYQnibOpLmbLVpeYtBrmQlbpOYpdRLIhrzvjMvaZFMGtCHo")) {
        for (int KHRriGuVkKCQx = 1069235169; KHRriGuVkKCQx > 0; KHRriGuVkKCQx--) {
            DiDWfaOo = DiDWfaOo;
            DiDWfaOo += SvxcZZDsANYC;
            QoujSshmdBObK = QoujSshmdBObK;
        }
    }

    for (int OXBbGQxtz = 554221994; OXBbGQxtz > 0; OXBbGQxtz--) {
        SvxcZZDsANYC = SvxcZZDsANYC;
        XPsIkG = SvxcZZDsANYC;
    }

    for (int XJXHwwxAqDqrTNuh = 1951279843; XJXHwwxAqDqrTNuh > 0; XJXHwwxAqDqrTNuh--) {
        continue;
    }

    for (int hpqwirIxHY = 494914257; hpqwirIxHY > 0; hpqwirIxHY--) {
        ExzvDwDC /= QoujSshmdBObK;
        DiDWfaOo += SvxcZZDsANYC;
        XPsIkG = XPsIkG;
    }

    return true;
}

double kmTiNjaLTwPXxc::phhgEoRw(bool mAVxDm, string gkJxhmVoyFo)
{
    double zdqVx = 64621.92803865772;

    for (int BzfdPPiaAg = 1695096408; BzfdPPiaAg > 0; BzfdPPiaAg--) {
        gkJxhmVoyFo = gkJxhmVoyFo;
        gkJxhmVoyFo = gkJxhmVoyFo;
        mAVxDm = mAVxDm;
        zdqVx = zdqVx;
    }

    return zdqVx;
}

void kmTiNjaLTwPXxc::ZBZkDaNiE(double WaAWaA, string ocbIjpUxlsKHBgx, bool qfncFrR, string kwpVKjhJIsDP)
{
    double DBQhezXLPnHEevLK = -1021354.4982327808;

    for (int qDXxdCxXHdKeAcSM = 395193876; qDXxdCxXHdKeAcSM > 0; qDXxdCxXHdKeAcSM--) {
        continue;
    }

    for (int ajNaOnHNOlX = 1304655985; ajNaOnHNOlX > 0; ajNaOnHNOlX--) {
        kwpVKjhJIsDP = ocbIjpUxlsKHBgx;
        ocbIjpUxlsKHBgx += kwpVKjhJIsDP;
        ocbIjpUxlsKHBgx = ocbIjpUxlsKHBgx;
    }

    for (int DwnDkIHeZDa = 1147549098; DwnDkIHeZDa > 0; DwnDkIHeZDa--) {
        continue;
    }

    for (int zrRwCYyiUVuj = 1136890736; zrRwCYyiUVuj > 0; zrRwCYyiUVuj--) {
        continue;
    }

    for (int mubADQvv = 51584644; mubADQvv > 0; mubADQvv--) {
        DBQhezXLPnHEevLK *= WaAWaA;
    }

    for (int OPQpFK = 2119155985; OPQpFK > 0; OPQpFK--) {
        WaAWaA = DBQhezXLPnHEevLK;
    }
}

double kmTiNjaLTwPXxc::XmlYLCdmZoD(double RWXZe, string Xgizr)
{
    string pgtbzAEfOaFaZ = string("dMcwGURIdDXgNjYtFEOaKhcFlSCbKuqQApUNABZzgXMkhAkiTVXEGvfAFeHGuuolkjWcdawawrJkLYGSEuiEvFIdYTcZeFxWBCffcyKCNgLusKNwcxMVXQbGJUqlmambqqWBJyhVLLYisoSydUGMHnXiKAtfYthygVzmghYQJTEMMSXe");
    double TwUqArfHCih = 673677.869752222;
    int PWrZJR = 310762986;
    double rXFIOZ = 248443.64738101407;
    bool VIWGhbOyL = true;
    bool UySaTVwtiMb = false;
    string mLoVYMTrKlhcnq = string("qytjjWGgmcLGDZLhVnTNbThcffJBjbhGcdELSctICTwoOGSpvspTXCCewkLBpHscCuiRpxZrNGykRmAkJvvvvbidCKXGzsdgNYeZzrysW");
    string oNweSHpTbnvJlEM = string("nEbAoqMggNilPUXfvqYEhsLLXZddVLYJPEVggLypNDVVBYqWcSVwNPsSrdaEVUeFxRXKPSgVOKVOVVFAKqkHoYIpbwGOSzgmYxhirmvPaJDxeOdwuPHwSBkSSYotnzXVmuyJHgMdKzzgeSQzePAdSOynOtUu");
    string ZeTKbAhfUbLArPq = string("OllzGiBkpiSvoAThhiDgwhADythUOdGYBAeOojITUtbubecRRKEECGGzyuePTxcDbcTgcLkOmMHEbyvOpXOweFqkqgFjweufDgFMTKJgvaLePRipgFWtiymJgwBUgcX");

    return rXFIOZ;
}

bool kmTiNjaLTwPXxc::UqAiUY(int SByJhBi, bool JzjOnXXZaSJaB, bool EoWkmOrfndlT)
{
    bool lXyDbCBvu = true;
    double alZRRQ = -464579.8782509548;
    bool pdjFWrCDOVVb = true;
    string BRuaZ = string("jDJUlDRbIqakFpHqNuIxhEPDzdWksZgLJuwCekMPDWpvyWdGdAHVZqdBnirXjxKazShcyvoLxjfbVXkxtgmbRtcYMduqajxIkL");
    int ABvSUwK = -942364670;

    return pdjFWrCDOVVb;
}

double kmTiNjaLTwPXxc::cVPgtb()
{
    double apGcJWo = -256620.312224863;
    string fNYHqErJrQFayRQ = string("goGELoqEKrMqpxWFkRxpmzMDUcrZoRPIqWyiQowpfgmCKQAzadeJZWwnKjMxCobxfwMwMwSnUyxYbfHFLSIIjcuyLaRHGruKHgrixIwvIGQCML");
    double MkMzDJIqfQqT = 12337.48364743399;
    string kxucdOBWBZN = string("JnIBIqvGHxdrMfufeFdXVPGhpyfMESmWATfKVlVYQCjMzfENnIh");
    string rGNEI = string("GLJfhcAJXmWVsLyjtNEKzIHZ");

    if (rGNEI >= string("goGELoqEKrMqpxWFkRxpmzMDUcrZoRPIqWyiQowpfgmCKQAzadeJZWwnKjMxCobxfwMwMwSnUyxYbfHFLSIIjcuyLaRHGruKHgrixIwvIGQCML")) {
        for (int QyhmTrlITpMGWoJU = 17562420; QyhmTrlITpMGWoJU > 0; QyhmTrlITpMGWoJU--) {
            MkMzDJIqfQqT -= MkMzDJIqfQqT;
            MkMzDJIqfQqT -= MkMzDJIqfQqT;
            kxucdOBWBZN += fNYHqErJrQFayRQ;
            rGNEI = kxucdOBWBZN;
            apGcJWo = MkMzDJIqfQqT;
        }
    }

    for (int AeSuUfMu = 1071844810; AeSuUfMu > 0; AeSuUfMu--) {
        MkMzDJIqfQqT -= MkMzDJIqfQqT;
        MkMzDJIqfQqT /= apGcJWo;
        apGcJWo = apGcJWo;
        rGNEI += rGNEI;
        MkMzDJIqfQqT -= MkMzDJIqfQqT;
    }

    for (int JjdVJdwWy = 1649308898; JjdVJdwWy > 0; JjdVJdwWy--) {
        apGcJWo /= MkMzDJIqfQqT;
    }

    for (int DGadlNti = 20594098; DGadlNti > 0; DGadlNti--) {
        fNYHqErJrQFayRQ += fNYHqErJrQFayRQ;
        MkMzDJIqfQqT -= apGcJWo;
        kxucdOBWBZN += fNYHqErJrQFayRQ;
        rGNEI = rGNEI;
        kxucdOBWBZN = kxucdOBWBZN;
    }

    for (int zIitwX = 1733704368; zIitwX > 0; zIitwX--) {
        apGcJWo *= apGcJWo;
        rGNEI = kxucdOBWBZN;
        rGNEI = kxucdOBWBZN;
        MkMzDJIqfQqT /= apGcJWo;
        rGNEI = kxucdOBWBZN;
        rGNEI += fNYHqErJrQFayRQ;
    }

    for (int kPheDf = 2053282815; kPheDf > 0; kPheDf--) {
        kxucdOBWBZN = kxucdOBWBZN;
        rGNEI = fNYHqErJrQFayRQ;
        kxucdOBWBZN += kxucdOBWBZN;
    }

    return MkMzDJIqfQqT;
}

bool kmTiNjaLTwPXxc::zWtqvPqf()
{
    string VSiPCl = string("pZbTUkLdMDVuCwyyUbMDKHoDadVShSavaNJupZiDmuolzMNnttvSAIvPCKGGWSXFvQtjslnQGGCSvSTGmjudezCnVoItKAsLrpIKqlwxhcoShRNZstnnXcsswoNvgaDuCGvuQvuWZrtsySmtlCAAsmeSbWCUdYnnUnPcQXjRAKDqFINWbLfCVjBRjIIOYRnInByOEaeIaqIKjSHDJ");

    if (VSiPCl < string("pZbTUkLdMDVuCwyyUbMDKHoDadVShSavaNJupZiDmuolzMNnttvSAIvPCKGGWSXFvQtjslnQGGCSvSTGmjudezCnVoItKAsLrpIKqlwxhcoShRNZstnnXcsswoNvgaDuCGvuQvuWZrtsySmtlCAAsmeSbWCUdYnnUnPcQXjRAKDqFINWbLfCVjBRjIIOYRnInByOEaeIaqIKjSHDJ")) {
        for (int PcVYk = 333443174; PcVYk > 0; PcVYk--) {
            VSiPCl = VSiPCl;
        }
    }

    if (VSiPCl <= string("pZbTUkLdMDVuCwyyUbMDKHoDadVShSavaNJupZiDmuolzMNnttvSAIvPCKGGWSXFvQtjslnQGGCSvSTGmjudezCnVoItKAsLrpIKqlwxhcoShRNZstnnXcsswoNvgaDuCGvuQvuWZrtsySmtlCAAsmeSbWCUdYnnUnPcQXjRAKDqFINWbLfCVjBRjIIOYRnInByOEaeIaqIKjSHDJ")) {
        for (int MeMEORdkqr = 1988945084; MeMEORdkqr > 0; MeMEORdkqr--) {
            VSiPCl += VSiPCl;
            VSiPCl += VSiPCl;
            VSiPCl = VSiPCl;
            VSiPCl += VSiPCl;
            VSiPCl += VSiPCl;
            VSiPCl = VSiPCl;
            VSiPCl += VSiPCl;
        }
    }

    return true;
}

double kmTiNjaLTwPXxc::ANsyrjWYvDj()
{
    string zzXlRXfurtQJe = string("WpzRBVNZIHEaptsmYqRWBYGLNHxbxWygZFoGsKOVUIDGFYDomBAllOknpaymgfuMGXmgCYBRRygiIXUdchXKbzgIDIxHhEUXoKaAQYRYWgHYnpvIEJnjqumowiELGezHoWGoDHldHqPQMMUUmEzuWNelMLAOmpkcpBDpIzaWMGFZGBTDruFEHZpDEYVxhrCUvoiOzsPquvIJUmvKkGNvwtjTpJAmyoKXZxRW");
    int mLKNiCCDTNllxdu = -97367538;
    bool qtuXVb = false;
    int uDinMkfzBzWT = -896604728;
    bool wjbsAZUUnY = true;
    bool IrlwTGkOkaNTxMx = false;
    int JVuefz = 1868668096;
    bool UCGah = true;
    double WqexQMVusxqMzSg = 939872.3979470627;

    for (int LFNTmGza = 934905908; LFNTmGza > 0; LFNTmGza--) {
        qtuXVb = qtuXVb;
        IrlwTGkOkaNTxMx = wjbsAZUUnY;
    }

    return WqexQMVusxqMzSg;
}

string kmTiNjaLTwPXxc::hlleSvMNvXYKH()
{
    bool oXjYJtklUl = true;
    int aJDRcEkijWPl = 175978158;
    bool tUWTxpAOrUe = false;
    string OBYvuefFBsIZCOz = string("XUWiDBygoojPSPsUbZchweuCGHQMOELlWxDtHvNwdPNxNnfaQyZaPmHcCtcIFjjKjTLQfFFcsIicKbdjPOSDEEIqoEuqbpiwjwUXppuIShyouluHIJlQkYiGULndcJYgHebNWslEhrYMilxojHEnJdGyFZqKORqFfIjIPZhkCOQUAGLfVwisUBOnAClGqCCJmkXXvSFQCDOffVDljGJFlrssPHfhZd");
    double BkORZjJnoUml = 829788.2676960321;
    int dCmXAPrMZifQUqw = 579216316;
    bool czEEtgwVU = true;
    string qjljdmLIFgdCkUJl = string("QRUNvruDgQGbPlrXSflLqHOwxpQgxPanSwXWcjuQEyEiSbJIApteNXQZceNtIkijVMgXGKTMLqZcKhOOzfxNfuaWLDtgPIKFPXvKAYnMNZORfSWNRVRBBtcQoTwhAASiwgPLQdgtMkbBGwUGPvmrpGBUxwtGtrBUQGRUTyvbFUDCoEiPcLsPYGIJHhTzxPCtzGdNznNiosOeMJsCuJPjEqQBlbRckeLVKNucRUWCzELPMuIocJa");
    string yNdbaNQ = string("sxcgjZvPKCeMepyoqDIuTTKpOPiPbOABQDLmveBzbiZdGY");
    double NQKIZOHTuU = 1041875.93728889;

    for (int ncSHFOYV = 2077936608; ncSHFOYV > 0; ncSHFOYV--) {
        continue;
    }

    for (int WXBvmUTUQ = 40829607; WXBvmUTUQ > 0; WXBvmUTUQ--) {
        dCmXAPrMZifQUqw *= aJDRcEkijWPl;
    }

    for (int ylSWniAmZNqsiW = 37484473; ylSWniAmZNqsiW > 0; ylSWniAmZNqsiW--) {
        continue;
    }

    return yNdbaNQ;
}

bool kmTiNjaLTwPXxc::WwRAoCvWn(string kTJae)
{
    double GciuQxrUBeBScf = 760757.1465580761;
    string ZbjAtLzn = string("ljDrxYbzROfsiNeSaxisyRDnvfsu");
    double PIniCiRtmy = -824833.4062405569;
    int DNxvEXDyxWh = -1840866917;

    for (int NczUADC = 82805673; NczUADC > 0; NczUADC--) {
        ZbjAtLzn = ZbjAtLzn;
        GciuQxrUBeBScf -= PIniCiRtmy;
    }

    if (GciuQxrUBeBScf >= 760757.1465580761) {
        for (int LmQzuOcMBo = 1309111467; LmQzuOcMBo > 0; LmQzuOcMBo--) {
            DNxvEXDyxWh *= DNxvEXDyxWh;
        }
    }

    for (int adioRaHktkvtBCJ = 524165192; adioRaHktkvtBCJ > 0; adioRaHktkvtBCJ--) {
        kTJae = ZbjAtLzn;
    }

    for (int pKwuS = 2061692276; pKwuS > 0; pKwuS--) {
        kTJae = ZbjAtLzn;
        GciuQxrUBeBScf -= GciuQxrUBeBScf;
        GciuQxrUBeBScf -= PIniCiRtmy;
        GciuQxrUBeBScf = PIniCiRtmy;
    }

    return false;
}

kmTiNjaLTwPXxc::kmTiNjaLTwPXxc()
{
    this->eWMGJHqPuFXtYzp(string("zKCqNUQOFvVNRdlsSXvfEVHBCnEmWjAJTPtpDzUezGlhpfinupZUvEIOiBJGeUtKHfFGaGKWfFeZVkGLYy"));
    this->KaCALp(string("XVaTQRALXfdKAdJRkaWEnHDnbHlCNSgEsoTwjaLjDHdJdhAxDcutciLjrTxBWcfdnGfazsXYWSXSvOXRenzdXwJXANKjFcVfLgBaugMCOaWMqeaZJuSACfvbCYoruMYTvJalJnenaAcmWODwpAKHhSofISLGwwcYrfWWZzMSoczFfm"));
    this->yURrgElyHyS(1765593914, string("PPpXZhNguxzhNkVDbAdITfRxYVTWjyXGBuIObqtmvzWJtdJhnoKdWOPeZUeiZBNhkwJIzCsHnKeZxrmeOIKTZNLjvktpfTXABcqVfoPMmeSVCNILWxFbuGFczLauSqywgOQQUtReJcmvwwTYhYHaEWSgBQZCcsymik"), -352013.9918356227);
    this->jhnfuGtNJ(-538170554, string("DgHhHpWwTDyRFTlTfwxxqsOGHoFiekwYJvIhikNdegabWXdDOjqYdmaMeiYcAsbTJAAHltbBWOypJVXktAQDiLQSUnbSLSFHJKZuWapLWdqdPqubtCYjnWjDdVqIUehbhBFerCWDqblDPtFepgxOHIaQPVQlzohwocYbmjZBLwGEjhHYzJMWwkHx"), -1756563991, string("EVnmdLeASMIEJLdFXYQnibOpLmbLVpeYtBrmQlbpOYpdRLIhrzvjMvaZFMGtCHo"), -132781725);
    this->phhgEoRw(true, string("DHuzSGrVDTMGtWSKLGMjbsLKuxCXiWMNqkxPhwAdLJaxHomZNYKFqJbPGAdyjddoNXbKOrgXXOXKiuNTkctAqt"));
    this->ZBZkDaNiE(1030397.5561524517, string("AtGOTdYQPJNCwEFQwMiaEjey"), true, string("rFxpzr"));
    this->XmlYLCdmZoD(173660.6698380143, string("NDoqqVSmvPVXAwNdELqpTvjUAsomVpcFLlScpOJzYSlIKoEvHGzYSuEHeoTNyliLEKmdCRtVLEgtbdZkkxxuIReaTgYfcRDXmidZcmSXNnnANMoMgrXnLgRNVvbdYnToiEOKnfuGWtM"));
    this->UqAiUY(-730173616, true, true);
    this->cVPgtb();
    this->zWtqvPqf();
    this->ANsyrjWYvDj();
    this->hlleSvMNvXYKH();
    this->WwRAoCvWn(string("LdLhhLMReKLoycHmwLiOsLpgLbldBZxySCuomOkndmlcMKbBwjgBHVxcxJharJBMdlDzgyAzNWrthjYeWeqJydSxJjlhYKNMuurxDqJrtvYeGmVYCrggSOEbPahxGrhRCCYZdfZNaSWwtJXGpKoRNkaWJTdidsHOLQmxUgQrYPEvfGParrARLPXdXqyCiFisjdIpSQbgxxcwPFxahvWYLmfeajKQNxHAOewUSqpLjTeRQYAdBaJJxZHZugPiJ"));
}
