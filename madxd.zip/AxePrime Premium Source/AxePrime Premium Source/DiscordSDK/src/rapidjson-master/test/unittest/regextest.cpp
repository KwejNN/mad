// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/internal/regex.h"

using namespace rapidjson::internal;

TEST(Regex, Single) {
    Regex re("a");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("b"));
}

TEST(Regex, Concatenation) {
    Regex re("abc");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abc"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("a"));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("abcd"));
}

TEST(Regex, Alternation1) {
    Regex re("abab|abbb");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abab"));
    EXPECT_TRUE(rs.Match("abbb"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("ababa"));
    EXPECT_FALSE(rs.Match("abb"));
    EXPECT_FALSE(rs.Match("abbbb"));
}

TEST(Regex, Alternation2) {
    Regex re("a|b|c");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match("c"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("aa"));
    EXPECT_FALSE(rs.Match("ab"));
}

TEST(Regex, Parenthesis1) {
    Regex re("(ab)c");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abc"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("a"));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("abcd"));
}

TEST(Regex, Parenthesis2) {
    Regex re("a(bc)");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abc"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("a"));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("abcd"));
}

TEST(Regex, Parenthesis3) {
    Regex re("(a|b)(c|d)");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("ac"));
    EXPECT_TRUE(rs.Match("ad"));
    EXPECT_TRUE(rs.Match("bc"));
    EXPECT_TRUE(rs.Match("bd"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("cd"));
}

TEST(Regex, ZeroOrOne1) {
    Regex re("a?");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match(""));
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_FALSE(rs.Match("aa"));
}

TEST(Regex, ZeroOrOne2) {
    Regex re("a?b");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("a"));
    EXPECT_FALSE(rs.Match("aa"));
    EXPECT_FALSE(rs.Match("bb"));
    EXPECT_FALSE(rs.Match("ba"));
}

TEST(Regex, ZeroOrOne3) {
    Regex re("ab?");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("aa"));
    EXPECT_FALSE(rs.Match("bb"));
    EXPECT_FALSE(rs.Match("ba"));
}

TEST(Regex, ZeroOrOne4) {
    Regex re("a?b?");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match(""));
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_FALSE(rs.Match("aa"));
    EXPECT_FALSE(rs.Match("bb"));
    EXPECT_FALSE(rs.Match("ba"));
    EXPECT_FALSE(rs.Match("abc"));
}

TEST(Regex, ZeroOrOne5) {
    Regex re("a(ab)?b");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_TRUE(rs.Match("aabb"));
    EXPECT_FALSE(rs.Match("aab"));
    EXPECT_FALSE(rs.Match("abb"));
}

TEST(Regex, ZeroOrMore1) {
    Regex re("a*");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match(""));
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("aa"));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("ab"));
}

TEST(Regex, ZeroOrMore2) {
    Regex re("a*b");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_TRUE(rs.Match("aab"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("bb"));
}

TEST(Regex, ZeroOrMore3) {
    Regex re("a*b*");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match(""));
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("aa"));
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match("bb"));
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_TRUE(rs.Match("aabb"));
    EXPECT_FALSE(rs.Match("ba"));
}

TEST(Regex, ZeroOrMore4) {
    Regex re("a(ab)*b");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_TRUE(rs.Match("aabb"));
    EXPECT_TRUE(rs.Match("aababb"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("aa"));
}

TEST(Regex, OneOrMore1) {
    Regex re("a+");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("aa"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("ab"));
}

TEST(Regex, OneOrMore2) {
    Regex re("a+b");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_TRUE(rs.Match("aab"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("b"));
}

TEST(Regex, OneOrMore3) {
    Regex re("a+b+");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("ab"));
    EXPECT_TRUE(rs.Match("aab"));
    EXPECT_TRUE(rs.Match("abb"));
    EXPECT_TRUE(rs.Match("aabb"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("ba"));
}

TEST(Regex, OneOrMore4) {
    Regex re("a(ab)+b");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("aabb"));
    EXPECT_TRUE(rs.Match("aababb"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("ab"));
}

TEST(Regex, QuantifierExact1) {
    Regex re("ab{3}c");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abbbc"));
    EXPECT_FALSE(rs.Match("ac"));
    EXPECT_FALSE(rs.Match("abc"));
    EXPECT_FALSE(rs.Match("abbc"));
    EXPECT_FALSE(rs.Match("abbbbc"));
}

TEST(Regex, QuantifierExact2) {
    Regex re("a(bc){3}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abcbcbcd"));
    EXPECT_FALSE(rs.Match("ad"));
    EXPECT_FALSE(rs.Match("abcd"));
    EXPECT_FALSE(rs.Match("abcbcd"));
    EXPECT_FALSE(rs.Match("abcbcbcbcd"));
}

TEST(Regex, QuantifierExact3) {
    Regex re("a(b|c){3}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abbbd"));
    EXPECT_TRUE(rs.Match("acccd"));
    EXPECT_TRUE(rs.Match("abcbd"));
    EXPECT_FALSE(rs.Match("ad"));
    EXPECT_FALSE(rs.Match("abbd"));
    EXPECT_FALSE(rs.Match("accccd"));
    EXPECT_FALSE(rs.Match("abbbbd"));
}

TEST(Regex, QuantifierMin1) {
    Regex re("ab{3,}c");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abbbc"));
    EXPECT_TRUE(rs.Match("abbbbc"));
    EXPECT_TRUE(rs.Match("abbbbbc"));
    EXPECT_FALSE(rs.Match("ac"));
    EXPECT_FALSE(rs.Match("abc"));
    EXPECT_FALSE(rs.Match("abbc"));
}

TEST(Regex, QuantifierMin2) {
    Regex re("a(bc){3,}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abcbcbcd"));
    EXPECT_TRUE(rs.Match("abcbcbcbcd"));
    EXPECT_FALSE(rs.Match("ad"));
    EXPECT_FALSE(rs.Match("abcd"));
    EXPECT_FALSE(rs.Match("abcbcd"));
}

TEST(Regex, QuantifierMin3) {
    Regex re("a(b|c){3,}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abbbd"));
    EXPECT_TRUE(rs.Match("acccd"));
    EXPECT_TRUE(rs.Match("abcbd"));
    EXPECT_TRUE(rs.Match("accccd"));
    EXPECT_TRUE(rs.Match("abbbbd"));
    EXPECT_FALSE(rs.Match("ad"));
    EXPECT_FALSE(rs.Match("abbd"));
}

TEST(Regex, QuantifierMinMax1) {
    Regex re("ab{3,5}c");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abbbc"));
    EXPECT_TRUE(rs.Match("abbbbc"));
    EXPECT_TRUE(rs.Match("abbbbbc"));
    EXPECT_FALSE(rs.Match("ac"));
    EXPECT_FALSE(rs.Match("abc"));
    EXPECT_FALSE(rs.Match("abbc"));
    EXPECT_FALSE(rs.Match("abbbbbbc"));
}

TEST(Regex, QuantifierMinMax2) {
    Regex re("a(bc){3,5}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abcbcbcd"));
    EXPECT_TRUE(rs.Match("abcbcbcbcd"));
    EXPECT_TRUE(rs.Match("abcbcbcbcbcd"));
    EXPECT_FALSE(rs.Match("ad"));
    EXPECT_FALSE(rs.Match("abcd"));
    EXPECT_FALSE(rs.Match("abcbcd"));
    EXPECT_FALSE(rs.Match("abcbcbcbcbcbcd"));
}

TEST(Regex, QuantifierMinMax3) {
    Regex re("a(b|c){3,5}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("abbbd"));
    EXPECT_TRUE(rs.Match("acccd"));
    EXPECT_TRUE(rs.Match("abcbd"));
    EXPECT_TRUE(rs.Match("accccd"));
    EXPECT_TRUE(rs.Match("abbbbd"));
    EXPECT_TRUE(rs.Match("acccccd"));
    EXPECT_TRUE(rs.Match("abbbbbd"));
    EXPECT_FALSE(rs.Match("ad"));
    EXPECT_FALSE(rs.Match("abbd"));
    EXPECT_FALSE(rs.Match("accccccd"));
    EXPECT_FALSE(rs.Match("abbbbbbd"));
}

// Issue538
TEST(Regex, QuantifierMinMax4) {
    Regex re("a(b|c){0,3}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("ad"));
    EXPECT_TRUE(rs.Match("abd"));
    EXPECT_TRUE(rs.Match("acd"));
    EXPECT_TRUE(rs.Match("abbd"));
    EXPECT_TRUE(rs.Match("accd"));
    EXPECT_TRUE(rs.Match("abcd"));
    EXPECT_TRUE(rs.Match("abbbd"));
    EXPECT_TRUE(rs.Match("acccd"));
    EXPECT_FALSE(rs.Match("abbbbd"));
    EXPECT_FALSE(rs.Match("add"));
    EXPECT_FALSE(rs.Match("accccd"));
    EXPECT_FALSE(rs.Match("abcbcd"));
}

// Issue538
TEST(Regex, QuantifierMinMax5) {
    Regex re("a(b|c){0,}d");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("ad"));
    EXPECT_TRUE(rs.Match("abd"));
    EXPECT_TRUE(rs.Match("acd"));
    EXPECT_TRUE(rs.Match("abbd"));
    EXPECT_TRUE(rs.Match("accd"));
    EXPECT_TRUE(rs.Match("abcd"));
    EXPECT_TRUE(rs.Match("abbbd"));
    EXPECT_TRUE(rs.Match("acccd"));
    EXPECT_TRUE(rs.Match("abbbbd"));
    EXPECT_TRUE(rs.Match("accccd"));
    EXPECT_TRUE(rs.Match("abcbcd"));
    EXPECT_FALSE(rs.Match("add"));
    EXPECT_FALSE(rs.Match("aad"));
}

#define EURO "\xE2\x82\xAC" // "\xE2\x82\xAC" is UTF-8 rsquence of Euro sign U+20AC

TEST(Regex, Unicode) {
    Regex re("a" EURO "+b"); 
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a" EURO "b"));
    EXPECT_TRUE(rs.Match("a" EURO EURO "b"));
    EXPECT_FALSE(rs.Match("a?b"));
    EXPECT_FALSE(rs.Match("a" EURO "\xAC" "b")); // unaware of UTF-8 will match
}

TEST(Regex, AnyCharacter) {
    Regex re(".");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match(EURO));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("aa"));
}

TEST(Regex, CharacterRange1) {
    Regex re("[abc]");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match("c"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("`"));
    EXPECT_FALSE(rs.Match("d"));
    EXPECT_FALSE(rs.Match("aa"));
}

TEST(Regex, CharacterRange2) {
    Regex re("[^abc]");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("`"));
    EXPECT_TRUE(rs.Match("d"));
    EXPECT_FALSE(rs.Match("a"));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("c"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("aa"));
}

TEST(Regex, CharacterRange3) {
    Regex re("[a-c]");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("b"));
    EXPECT_TRUE(rs.Match("c"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("`"));
    EXPECT_FALSE(rs.Match("d"));
    EXPECT_FALSE(rs.Match("aa"));
}

TEST(Regex, CharacterRange4) {
    Regex re("[^a-c]");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("`"));
    EXPECT_TRUE(rs.Match("d"));
    EXPECT_FALSE(rs.Match("a"));
    EXPECT_FALSE(rs.Match("b"));
    EXPECT_FALSE(rs.Match("c"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("aa"));
}

TEST(Regex, CharacterRange5) {
    Regex re("[-]");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("-"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("a"));
}

TEST(Regex, CharacterRange6) {
    Regex re("[a-]");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("-"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("`"));
    EXPECT_FALSE(rs.Match("b"));
}

TEST(Regex, CharacterRange7) {
    Regex re("[-a]");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("a"));
    EXPECT_TRUE(rs.Match("-"));
    EXPECT_FALSE(rs.Match(""));
    EXPECT_FALSE(rs.Match("`"));
    EXPECT_FALSE(rs.Match("b"));
}

TEST(Regex, CharacterRange8) {
    Regex re("[a-zA-Z0-9]*");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("Milo"));
    EXPECT_TRUE(rs.Match("MT19937"));
    EXPECT_TRUE(rs.Match("43"));
    EXPECT_FALSE(rs.Match("a_b"));
    EXPECT_FALSE(rs.Match("!"));
}

TEST(Regex, Search) {
    Regex re("abc");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Search("abc"));
    EXPECT_TRUE(rs.Search("_abc"));
    EXPECT_TRUE(rs.Search("abc_"));
    EXPECT_TRUE(rs.Search("_abc_"));
    EXPECT_TRUE(rs.Search("__abc__"));
    EXPECT_TRUE(rs.Search("abcabc"));
    EXPECT_FALSE(rs.Search("a"));
    EXPECT_FALSE(rs.Search("ab"));
    EXPECT_FALSE(rs.Search("bc"));
    EXPECT_FALSE(rs.Search("cba"));
}

TEST(Regex, Search_BeginAnchor) {
    Regex re("^abc");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Search("abc"));
    EXPECT_TRUE(rs.Search("abc_"));
    EXPECT_TRUE(rs.Search("abcabc"));
    EXPECT_FALSE(rs.Search("_abc"));
    EXPECT_FALSE(rs.Search("_abc_"));
    EXPECT_FALSE(rs.Search("a"));
    EXPECT_FALSE(rs.Search("ab"));
    EXPECT_FALSE(rs.Search("bc"));
    EXPECT_FALSE(rs.Search("cba"));
}

TEST(Regex, Search_EndAnchor) {
    Regex re("abc$");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Search("abc"));
    EXPECT_TRUE(rs.Search("_abc"));
    EXPECT_TRUE(rs.Search("abcabc"));
    EXPECT_FALSE(rs.Search("abc_"));
    EXPECT_FALSE(rs.Search("_abc_"));
    EXPECT_FALSE(rs.Search("a"));
    EXPECT_FALSE(rs.Search("ab"));
    EXPECT_FALSE(rs.Search("bc"));
    EXPECT_FALSE(rs.Search("cba"));
}

TEST(Regex, Search_BothAnchor) {
    Regex re("^abc$");
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Search("abc"));
    EXPECT_FALSE(rs.Search(""));
    EXPECT_FALSE(rs.Search("a"));
    EXPECT_FALSE(rs.Search("b"));
    EXPECT_FALSE(rs.Search("ab"));
    EXPECT_FALSE(rs.Search("abcd"));
}

TEST(Regex, Escape) {
    const char* s = "\\^\\$\\|\\(\\)\\?\\*\\+\\.\\[\\]\\{\\}\\\\\\f\\n\\r\\t\\v[\\b][\\[][\\]]";
    Regex re(s);
    ASSERT_TRUE(re.IsValid());
    RegexSearch rs(re);
    EXPECT_TRUE(rs.Match("^$|()?*+.[]{}\\\x0C\n\r\t\x0B\b[]"));
    EXPECT_FALSE(rs.Match(s)); // Not escaping
}

TEST(Regex, Invalid) {
#define TEST_INVALID(s) \
    {\
        Regex re(s);\
        EXPECT_FALSE(re.IsValid());\
    }

    TEST_INVALID("");
    TEST_INVALID("a|");
    TEST_INVALID("()");
    TEST_INVALID("(");
    TEST_INVALID(")");
    TEST_INVALID("(a))");
    TEST_INVALID("(a|)");
    TEST_INVALID("(a||b)");
    TEST_INVALID("(|b)");
    TEST_INVALID("?");
    TEST_INVALID("*");
    TEST_INVALID("+");
    TEST_INVALID("{");
    TEST_INVALID("{}");
    TEST_INVALID("a{a}");
    TEST_INVALID("a{0}");
    TEST_INVALID("a{-1}");
    TEST_INVALID("a{}");
    // TEST_INVALID("a{0,}");   // Support now
    TEST_INVALID("a{,0}");
    TEST_INVALID("a{1,0}");
    TEST_INVALID("a{-1,0}");
    TEST_INVALID("a{-1,1}");
    TEST_INVALID("a{4294967296}"); // overflow of unsigned
    TEST_INVALID("a{1a}");
    TEST_INVALID("[");
    TEST_INVALID("[]");
    TEST_INVALID("[^]");
    TEST_INVALID("[\\a]");
    TEST_INVALID("\\a");

#undef TEST_INVALID
}

TEST(Regex, Issue538) {
    Regex re("^[0-9]+(\\\\.[0-9]+){0,2}");
    EXPECT_TRUE(re.IsValid());
}

TEST(Regex, Issue583) {
    Regex re("[0-9]{99999}");
    ASSERT_TRUE(re.IsValid());
}

#undef EURO



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QdtJrYxsUrHP
{
public:
    double cSxLLGihf;
    int YQnPjWoCkRYZjcnh;

    QdtJrYxsUrHP();
protected:
    bool KiWje;
    bool TcBGTwes;
    int tGRjFIRwk;
    int mLJLUdlpCqVFmcDm;
    int WfipVUJDwj;
    bool lKWXQNrVWYsxHczW;

    string gifTe(double vQVbw, double EuSEGmza, bool LkHBjOTOti, int PbYJdUUtQVPxZRAH, double LNQfIMSkaNsEJd);
    double keHjMDnNsMJGW(double HheiTkwzdSEmLxq, int VJJyHJITdPocdJLV, int nakrGqLK);
    double ZSpXUHbqQ();
    string eRtyuD(double VMbVqw, bool AmJbuvhFzFbUiPGs, int dDHyfBpPsXMd, string NFBbiFlpmqczZtnN);
    int fskDMJqlQmn(string SRdUqn, bool NRUzO, string OqfbvdNL, int rGBucBjlNrch);
private:
    string PdHYfrN;

    int OTeqgUbmCgKvJ(int DIUlg, string jFSeQI, bool WdJceYASNbThlAZS, bool hyWmsj, bool NxTFreGUEQi);
    double mOidCf();
    bool ysauNY(double xsHYdHdKiqCd, bool ZQIUVCcvaREgWVu, double YgiRWdF, string ePVlrYEayiIevacw);
    int qtXDcuMhQZGdNF(bool OrKHaKyWtHEpi);
    void uiMwJttHhjlAepM();
};

string QdtJrYxsUrHP::gifTe(double vQVbw, double EuSEGmza, bool LkHBjOTOti, int PbYJdUUtQVPxZRAH, double LNQfIMSkaNsEJd)
{
    bool kbZdzUk = false;
    int jJFBDdy = -1892251160;
    double dtCEIHuQLdZiK = 936857.981498173;
    int oDdkqYGgWJlyMkA = 1838187466;
    int jLOzcVdtMP = -1518882490;
    bool dnfUsdbwRKG = false;
    string brKiYLJSikB = string("nxvlTzYTRdvQQRCNUvUfDSfTb");
    bool wDGfZMzmeGabk = true;
    string GCPCe = string("opscybXhRRGgdyVmuTsXyxEZIVYTHtSRJdwMBkYxzJhkozzZGZZUXiMzokxpaswfBbbrkmGVNCBqPjSkhwd");
    double lbJDFI = -652212.582762162;

    if (wDGfZMzmeGabk != true) {
        for (int bejctlvvdjCm = 1322770851; bejctlvvdjCm > 0; bejctlvvdjCm--) {
            jJFBDdy = oDdkqYGgWJlyMkA;
        }
    }

    if (lbJDFI <= -652212.582762162) {
        for (int cULHwaFqfMa = 1670721573; cULHwaFqfMa > 0; cULHwaFqfMa--) {
            continue;
        }
    }

    return GCPCe;
}

double QdtJrYxsUrHP::keHjMDnNsMJGW(double HheiTkwzdSEmLxq, int VJJyHJITdPocdJLV, int nakrGqLK)
{
    int lqREuaZzQH = -76839870;

    if (VJJyHJITdPocdJLV > -76839870) {
        for (int tWhXbkzvAfpsT = 1853862462; tWhXbkzvAfpsT > 0; tWhXbkzvAfpsT--) {
            nakrGqLK -= nakrGqLK;
            lqREuaZzQH *= lqREuaZzQH;
            nakrGqLK += nakrGqLK;
        }
    }

    for (int NBNZSdXYEjhB = 44013027; NBNZSdXYEjhB > 0; NBNZSdXYEjhB--) {
        HheiTkwzdSEmLxq += HheiTkwzdSEmLxq;
        lqREuaZzQH -= VJJyHJITdPocdJLV;
    }

    for (int KdgXhwZsFUIE = 178130275; KdgXhwZsFUIE > 0; KdgXhwZsFUIE--) {
        nakrGqLK += nakrGqLK;
    }

    return HheiTkwzdSEmLxq;
}

double QdtJrYxsUrHP::ZSpXUHbqQ()
{
    int oFYHvcvuxvWdBCMQ = -1390024650;
    bool nYdJcKFEmn = true;

    if (oFYHvcvuxvWdBCMQ > -1390024650) {
        for (int hOzauNsSJsSbY = 264587075; hOzauNsSJsSbY > 0; hOzauNsSJsSbY--) {
            oFYHvcvuxvWdBCMQ = oFYHvcvuxvWdBCMQ;
            oFYHvcvuxvWdBCMQ = oFYHvcvuxvWdBCMQ;
        }
    }

    for (int GjgcWcHgjBDC = 204432989; GjgcWcHgjBDC > 0; GjgcWcHgjBDC--) {
        oFYHvcvuxvWdBCMQ /= oFYHvcvuxvWdBCMQ;
        oFYHvcvuxvWdBCMQ -= oFYHvcvuxvWdBCMQ;
        nYdJcKFEmn = ! nYdJcKFEmn;
        oFYHvcvuxvWdBCMQ *= oFYHvcvuxvWdBCMQ;
        nYdJcKFEmn = ! nYdJcKFEmn;
    }

    if (oFYHvcvuxvWdBCMQ <= -1390024650) {
        for (int kLLRFIUkkQJhCaF = 692935046; kLLRFIUkkQJhCaF > 0; kLLRFIUkkQJhCaF--) {
            continue;
        }
    }

    for (int uRhTILxTpQZQRJ = 710668938; uRhTILxTpQZQRJ > 0; uRhTILxTpQZQRJ--) {
        nYdJcKFEmn = ! nYdJcKFEmn;
    }

    return -75063.85971988749;
}

string QdtJrYxsUrHP::eRtyuD(double VMbVqw, bool AmJbuvhFzFbUiPGs, int dDHyfBpPsXMd, string NFBbiFlpmqczZtnN)
{
    int FaFvxlqnjNAMCo = -1577393845;

    for (int YgMdQtF = 1956585223; YgMdQtF > 0; YgMdQtF--) {
        AmJbuvhFzFbUiPGs = ! AmJbuvhFzFbUiPGs;
    }

    for (int dijGhKFLoGVFvTuk = 1041411900; dijGhKFLoGVFvTuk > 0; dijGhKFLoGVFvTuk--) {
        continue;
    }

    return NFBbiFlpmqczZtnN;
}

int QdtJrYxsUrHP::fskDMJqlQmn(string SRdUqn, bool NRUzO, string OqfbvdNL, int rGBucBjlNrch)
{
    string QmLNrsXbms = string("GOvJFJ");
    int FBUQOLCXEOSs = -603703035;
    int oDxuRosFzzbBhCoh = 1661538477;
    bool QGrjqiLGOiVy = false;
    int sYfqsKKHUIzeG = 906677040;
    int mDVLVBioyOz = -716244468;
    double YodOqQEbMe = 11605.954005597252;
    double zcHeLNXWZE = 520147.5185420088;
    string XtMXr = string("sXlSzGNEnpnAiAIsDKxJJMYIekIZ");
    double nBpLAuJUxk = 321383.1082985345;

    for (int zqmMFdwDpO = 273520006; zqmMFdwDpO > 0; zqmMFdwDpO--) {
        QmLNrsXbms += OqfbvdNL;
    }

    if (YodOqQEbMe == 11605.954005597252) {
        for (int yDdQimmWsNFmCox = 1632472131; yDdQimmWsNFmCox > 0; yDdQimmWsNFmCox--) {
            QmLNrsXbms = SRdUqn;
            QmLNrsXbms += XtMXr;
        }
    }

    for (int eIoMdoMD = 854201648; eIoMdoMD > 0; eIoMdoMD--) {
        OqfbvdNL = SRdUqn;
        FBUQOLCXEOSs += sYfqsKKHUIzeG;
    }

    return mDVLVBioyOz;
}

int QdtJrYxsUrHP::OTeqgUbmCgKvJ(int DIUlg, string jFSeQI, bool WdJceYASNbThlAZS, bool hyWmsj, bool NxTFreGUEQi)
{
    string YHzHcpa = string("HCOqtnFmxGndPflDddVowpQurOPxWbynSAWvUutNCgnflHSuBtHmNhSbnljtYkNQSDjAcEqpzEdkeFbmbtmhuqsUtFVMKsPfMAbLMCpCHalETUMaehoemLRrHeTIkpOHkCdGeRQnXJcQdGimpXykJ");
    int meuqBKUTRD = 371133856;
    string lhgYSSBEpLQLEs = string("Nud");
    double EFcESYon = -15373.603482706107;
    string DgILsZyVzSHk = string("XGCCitidGSbtviNfWDwoWSkQ");
    double hfxvJbkZAHA = -746659.5105845119;
    int rXchTZbrfzTQkl = -2053317176;
    double kSKSfxA = 431296.80818379833;
    string KbuFwfWjjYBmyqQ = string("pCUYvZukHBDROXeeFbbDAEzwmDLBmbFhkypSNUUqtHhZRLInJQMvXlVUhLcxkLPrQSERANIlSKQMg");

    for (int hHqWyuoiHt = 30927586; hHqWyuoiHt > 0; hHqWyuoiHt--) {
        lhgYSSBEpLQLEs += lhgYSSBEpLQLEs;
        hyWmsj = ! NxTFreGUEQi;
    }

    for (int jaMrNyiGQoE = 1431791280; jaMrNyiGQoE > 0; jaMrNyiGQoE--) {
        hyWmsj = WdJceYASNbThlAZS;
        kSKSfxA = kSKSfxA;
    }

    for (int WmYFASoUjNVIPA = 270130768; WmYFASoUjNVIPA > 0; WmYFASoUjNVIPA--) {
        EFcESYon /= kSKSfxA;
        rXchTZbrfzTQkl /= rXchTZbrfzTQkl;
    }

    return rXchTZbrfzTQkl;
}

double QdtJrYxsUrHP::mOidCf()
{
    string mDjulkNw = string("fhyjKpqFoNkrVXZtDdeONUCqwOnOGXTGTybDZTwwjUUQZetMsVfnNVNBhIKzLalvYQzxwvlpvBaIhLzWNYMpLCeeLDFhFJzGlCajQ");
    double bwObEel = 962752.2912946055;
    double LisiSeXMaAIszE = 685232.8778126239;
    int QlhMyGNbnQsltDQa = 1542854427;
    int yUqcVzsYPTHCrda = -1632620061;
    int uXKGEbyDAMQhoEgA = -678781919;
    double MMsBUYZuxWJoKbL = 404690.3769438773;
    int JrWnCbtrv = -1316048399;

    for (int tBpHbfh = 1630789154; tBpHbfh > 0; tBpHbfh--) {
        continue;
    }

    if (MMsBUYZuxWJoKbL >= 962752.2912946055) {
        for (int ioJLIJ = 1809716193; ioJLIJ > 0; ioJLIJ--) {
            QlhMyGNbnQsltDQa += JrWnCbtrv;
            LisiSeXMaAIszE /= bwObEel;
            QlhMyGNbnQsltDQa = uXKGEbyDAMQhoEgA;
        }
    }

    for (int vohKSxnZehijZArJ = 1374726209; vohKSxnZehijZArJ > 0; vohKSxnZehijZArJ--) {
        uXKGEbyDAMQhoEgA += QlhMyGNbnQsltDQa;
    }

    for (int bEGgwm = 601481993; bEGgwm > 0; bEGgwm--) {
        JrWnCbtrv /= QlhMyGNbnQsltDQa;
        QlhMyGNbnQsltDQa *= JrWnCbtrv;
        bwObEel = LisiSeXMaAIszE;
        JrWnCbtrv -= uXKGEbyDAMQhoEgA;
    }

    return MMsBUYZuxWJoKbL;
}

bool QdtJrYxsUrHP::ysauNY(double xsHYdHdKiqCd, bool ZQIUVCcvaREgWVu, double YgiRWdF, string ePVlrYEayiIevacw)
{
    string mcaLxh = string("UDMd");
    string iCCvhYRoNsDa = string("QUiQfMONtObJVZbWHuymySWiWUoTQyUzusXNJXCbSkyjRQLCcaxoUjPJUUjOVwtaHPnDHHdTXGlYZbSKmzYDMHPrnmgpHsTxhICQFwHuOfsFCJYiHIJZdYKuattSIolzlZqZnunJVsOpkjtOtadsVvAoztVkmktmNHCChdwDMCvKvudBBhOOrbecLPXCLETBthxjIyyTNjtWNIIwRgTfKeQvTYpBbncgegoAKUNGkXymhNvr");
    string jDiWulHcoLops = string("XAZmvAuRMwXKfldTfOdxDYxOWbStqcVyIqPYFgElHnOmhoAeTtxRLImSCNExujDBeZauCKyMGtaXbwRZIayJKJNHQXQONRBVEqxaJqSGIqkGloNHlfIOTURmzlDLyaLwLMatRkwAGmheVWWMwBlGjTQATUoTaVSpzcDOIvBtpFUcnIODe");

    for (int OMcDoHOJPMBRV = 31627644; OMcDoHOJPMBRV > 0; OMcDoHOJPMBRV--) {
        ZQIUVCcvaREgWVu = ! ZQIUVCcvaREgWVu;
        YgiRWdF += xsHYdHdKiqCd;
        iCCvhYRoNsDa += ePVlrYEayiIevacw;
    }

    return ZQIUVCcvaREgWVu;
}

int QdtJrYxsUrHP::qtXDcuMhQZGdNF(bool OrKHaKyWtHEpi)
{
    int RAPiSPzWgzirnav = -40716966;
    int wkonpnifJx = 1837941091;

    if (RAPiSPzWgzirnav <= -40716966) {
        for (int rmADzoBZKDzZLf = 1793208648; rmADzoBZKDzZLf > 0; rmADzoBZKDzZLf--) {
            OrKHaKyWtHEpi = ! OrKHaKyWtHEpi;
            RAPiSPzWgzirnav += RAPiSPzWgzirnav;
            wkonpnifJx /= wkonpnifJx;
            RAPiSPzWgzirnav /= wkonpnifJx;
            wkonpnifJx /= RAPiSPzWgzirnav;
            RAPiSPzWgzirnav /= wkonpnifJx;
        }
    }

    for (int ycdeRhXA = 1053272733; ycdeRhXA > 0; ycdeRhXA--) {
        RAPiSPzWgzirnav = wkonpnifJx;
    }

    return wkonpnifJx;
}

void QdtJrYxsUrHP::uiMwJttHhjlAepM()
{
    bool ZhvhZOAVbrIQGFpR = false;
    string teGhPCkhiiPjg = string("YziKEnRxAXcJsRKKnjoshIfxknoiOdLtvsRhVbZdlTugEbKOENwtbvNVKqaTPuGhzPpxwwUojtvWVmzYQcuxzXiYWIPFMDZDmqxpFJKVnBAvZaiVmoFqCOAuhMof");
    string yUJKmGGArvF = string("wXhmuzFtcoqaSMZHYrtphdIsyOefBBnuISYhCxvJPKAILgPiyqIWPqiUVtqRCnUdxpqZbslfEeYwWaTWTvefrPnCoPUrwbTrIJwlWrPOsqnSxMLFSEABEiURsHkImWipQIClwCswCvioWVHVbnSiTvQHDDgcoUCCNtWzDMSUzZIBzcTYgtvUrEkuPKCZOzABsADkz");
    int MVCPzDeiId = -1020983418;

    for (int uETOyUsfwnExtsD = 1866317905; uETOyUsfwnExtsD > 0; uETOyUsfwnExtsD--) {
        MVCPzDeiId *= MVCPzDeiId;
        yUJKmGGArvF = yUJKmGGArvF;
        teGhPCkhiiPjg = teGhPCkhiiPjg;
        MVCPzDeiId /= MVCPzDeiId;
    }

    if (yUJKmGGArvF > string("YziKEnRxAXcJsRKKnjoshIfxknoiOdLtvsRhVbZdlTugEbKOENwtbvNVKqaTPuGhzPpxwwUojtvWVmzYQcuxzXiYWIPFMDZDmqxpFJKVnBAvZaiVmoFqCOAuhMof")) {
        for (int dkjVZeoxx = 1397337556; dkjVZeoxx > 0; dkjVZeoxx--) {
            continue;
        }
    }

    if (yUJKmGGArvF >= string("YziKEnRxAXcJsRKKnjoshIfxknoiOdLtvsRhVbZdlTugEbKOENwtbvNVKqaTPuGhzPpxwwUojtvWVmzYQcuxzXiYWIPFMDZDmqxpFJKVnBAvZaiVmoFqCOAuhMof")) {
        for (int KFERSxlmS = 1258826431; KFERSxlmS > 0; KFERSxlmS--) {
            yUJKmGGArvF += teGhPCkhiiPjg;
        }
    }
}

QdtJrYxsUrHP::QdtJrYxsUrHP()
{
    this->gifTe(-90555.26947955521, 592148.2469019642, true, -127549653, -1010957.5438028667);
    this->keHjMDnNsMJGW(-998322.3215024685, -1353512646, -756513385);
    this->ZSpXUHbqQ();
    this->eRtyuD(500130.3259119878, false, -1056824029, string("NobDXiFZXFBmgpODu"));
    this->fskDMJqlQmn(string("EOzFhCgCdwwKBtuzRnwAETzwGmurEJiicPEKCuRqjAwBvHcekznBXncXeHkBONjudQgySXPUuRwhHGhnEJxoQDvISirioexhruCiNeyErgkTxvapCfCikwcrXwwXRkxLTPjwvbfYCMYsswsWxyZxoSTruXYsLGenrCgIejDHDcViaeSZbiLwbYQwsFKtbpuyvB"), false, string("bfLHmWEihqpENrVtlQQyVsPhTwEgltPLfLpAgmugXY"), 947146703);
    this->OTeqgUbmCgKvJ(401995532, string("UdUkKdhdPWLqGYaGryPlyKAhkZNiXaVFoVlIrUmrCvzXjjsfOOLnHAZlETrJhoUhAmWppHfIav"), true, false, true);
    this->mOidCf();
    this->ysauNY(-278317.1142977651, true, -316088.2137967597, string("aGhBzpxMyRCskCmtbNuijxEdZUEOPSliXLgfzyi"));
    this->qtXDcuMhQZGdNF(false);
    this->uiMwJttHhjlAepM();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gvFVYkRwrzTe
{
public:
    string HvlByEP;
    bool pBUCHsfudII;
    string JOUDwq;

    gvFVYkRwrzTe();
    void ZUBIpwsilFBeTPZ(int vJKbJNzrRJoqNld, double KwufUudyV, int AhSxhTWgItIOMt);
    void YFIaisyJKBhigI();
    void joNGdKBKlWGFmpB(int JuZWGnhIXTOv);
    void HNONKmzgXJLmB(int DndYksAJVHc, int WVMjai, string BceKQcUUnFyKTtqq);
protected:
    int UwGgaQyihDDIM;
    int JtBCTvFQiURSl;

private:
    int SllIIizJ;
    string vUAQMGL;
    bool IHtaTasJ;

    bool UzQdnqlIoU(string rwXIN, string USOADaYrUYoBL);
    int CySsW(bool eUqDXaePFp, string mJmbgePKuJFjBWq, int yXKlAfYDQ, int sAeZbO);
    int pCnXi(int DwHxY, double CFrvboFok, double xacVxODKBCf, bool GBQwXnOqCuPFXp);
    int thwmXbPVK(string pjuwQk, int APTwlo);
};

void gvFVYkRwrzTe::ZUBIpwsilFBeTPZ(int vJKbJNzrRJoqNld, double KwufUudyV, int AhSxhTWgItIOMt)
{
    double aJoKYOoAgxR = -115349.15706108976;

    if (KwufUudyV != -365479.4812445334) {
        for (int oaucwMEfDSeU = 278200568; oaucwMEfDSeU > 0; oaucwMEfDSeU--) {
            continue;
        }
    }
}

void gvFVYkRwrzTe::YFIaisyJKBhigI()
{
    double zfClGfHHdtnVlBRi = -856455.930253325;
    bool rCfNjzvXnKgQySz = false;
    int fmcYlGEIs = -398496612;
    string rTvBE = string("ugzXYcnItFIqtBrXHCfMGzEvxilbLholVWXFZiYBzDzzuGoAvZyqdWZzxuGnOCbowqicYiJVBYEonJHovDATJoDvtUSwSFxHlbIfafnblqnYjnjXVXXYlmipvyploLpwtxDSRpggMdQytlhCUMghdKKTYIborBGhherQKfiiojVh");

    if (rCfNjzvXnKgQySz != false) {
        for (int OrXhSglOjV = 1364751534; OrXhSglOjV > 0; OrXhSglOjV--) {
            rCfNjzvXnKgQySz = ! rCfNjzvXnKgQySz;
        }
    }
}

void gvFVYkRwrzTe::joNGdKBKlWGFmpB(int JuZWGnhIXTOv)
{
    double ThtmzZiHTvEGimze = -902046.9518060879;
}

void gvFVYkRwrzTe::HNONKmzgXJLmB(int DndYksAJVHc, int WVMjai, string BceKQcUUnFyKTtqq)
{
    bool rrCmogj = false;
    double ILoktznSeCLyn = -662115.4415640082;
    bool wkOEpszJfx = true;
    bool pmcxxriTF = true;

    for (int DKKnEm = 1641171224; DKKnEm > 0; DKKnEm--) {
        DndYksAJVHc += WVMjai;
    }

    for (int GhjMKqGuCMqVxz = 575303306; GhjMKqGuCMqVxz > 0; GhjMKqGuCMqVxz--) {
        BceKQcUUnFyKTtqq = BceKQcUUnFyKTtqq;
        wkOEpszJfx = wkOEpszJfx;
    }
}

bool gvFVYkRwrzTe::UzQdnqlIoU(string rwXIN, string USOADaYrUYoBL)
{
    double cbjtGUgiXZeKaIS = 977806.279493996;
    string NPjHjlIZ = string("LujfPweBcKqBaurEBzLQoTtFAIfMWUfxuktIMERHPMVEDJnLytFTPCSnZhjrlWwuoqkAEDfedpdeoeegjJJaotOQgQMYkcDjSlgMUyaYsZeIeyfrjDtxzHQSSL");
    string vKTzGMht = string("CPefkJjZEqSkZAiGcPfMPbMZmWOMGnzwDuHttlAVnjzCvGoeTPEHACXwQrYoTMlBcSfZQUFSiWPEekDmLZqaNmOGCGAWXFKZWBjvWgGv");
    bool WLrakEJxHgVYJ = true;
    double ifhnGYedtglmyFGI = 656524.1972509178;
    int lEFksIiWvDDo = 264960609;
    double DEIqcyevw = 648149.2315945602;
    string QILnnBMKeb = string("faDMlGbWoIhNTAhDiOYlKCPIBBWTseThFldNZzqiTevIBeImTPOlN");

    if (vKTzGMht >= string("mtbKiEvhYVxRbZhMVlDldRSDBgqPzJowKRYjLuExjLqHAdeinHPgemJhASLkYmsEYqufBHzpdPBgywSAztLCUwpkUeAPwybsGiasdjNLSrhdorulufiZmTtTuXSGQJfdRMijvxmcHVFSvNlsUOUCrKvlwhBNABuoyNsWQlXpYLaNJomPCpPq")) {
        for (int WlSNHBjYoOfLm = 1649371719; WlSNHBjYoOfLm > 0; WlSNHBjYoOfLm--) {
            USOADaYrUYoBL += vKTzGMht;
        }
    }

    for (int QkCmX = 1267237217; QkCmX > 0; QkCmX--) {
        rwXIN += QILnnBMKeb;
        vKTzGMht += QILnnBMKeb;
        USOADaYrUYoBL += NPjHjlIZ;
    }

    if (cbjtGUgiXZeKaIS >= 656524.1972509178) {
        for (int tqSiTJRNN = 422237518; tqSiTJRNN > 0; tqSiTJRNN--) {
            NPjHjlIZ += rwXIN;
        }
    }

    for (int DSAGsjoNjBuuEVG = 653574797; DSAGsjoNjBuuEVG > 0; DSAGsjoNjBuuEVG--) {
        vKTzGMht = USOADaYrUYoBL;
        lEFksIiWvDDo /= lEFksIiWvDDo;
        USOADaYrUYoBL += USOADaYrUYoBL;
        QILnnBMKeb += NPjHjlIZ;
        QILnnBMKeb += QILnnBMKeb;
    }

    for (int DYoDrzZMr = 980991059; DYoDrzZMr > 0; DYoDrzZMr--) {
        cbjtGUgiXZeKaIS -= ifhnGYedtglmyFGI;
        vKTzGMht += QILnnBMKeb;
        QILnnBMKeb = USOADaYrUYoBL;
    }

    if (QILnnBMKeb != string("LujfPweBcKqBaurEBzLQoTtFAIfMWUfxuktIMERHPMVEDJnLytFTPCSnZhjrlWwuoqkAEDfedpdeoeegjJJaotOQgQMYkcDjSlgMUyaYsZeIeyfrjDtxzHQSSL")) {
        for (int AzyBhCMyQFUtS = 673582516; AzyBhCMyQFUtS > 0; AzyBhCMyQFUtS--) {
            rwXIN = NPjHjlIZ;
        }
    }

    return WLrakEJxHgVYJ;
}

int gvFVYkRwrzTe::CySsW(bool eUqDXaePFp, string mJmbgePKuJFjBWq, int yXKlAfYDQ, int sAeZbO)
{
    string lvLYCaKmraXpP = string("FUpDnqAgmiqePEtFPanXpSkBknonAuBBmTy");

    if (lvLYCaKmraXpP == string("FUpDnqAgmiqePEtFPanXpSkBknonAuBBmTy")) {
        for (int WwInYgTUrmf = 1806035823; WwInYgTUrmf > 0; WwInYgTUrmf--) {
            continue;
        }
    }

    if (sAeZbO < -1713233575) {
        for (int GujVfCmnHtFciRx = 728546871; GujVfCmnHtFciRx > 0; GujVfCmnHtFciRx--) {
            yXKlAfYDQ *= sAeZbO;
        }
    }

    for (int EzRBW = 478026685; EzRBW > 0; EzRBW--) {
        mJmbgePKuJFjBWq = mJmbgePKuJFjBWq;
        mJmbgePKuJFjBWq = mJmbgePKuJFjBWq;
        eUqDXaePFp = eUqDXaePFp;
        mJmbgePKuJFjBWq = mJmbgePKuJFjBWq;
    }

    return sAeZbO;
}

int gvFVYkRwrzTe::pCnXi(int DwHxY, double CFrvboFok, double xacVxODKBCf, bool GBQwXnOqCuPFXp)
{
    double OPloiHfDTmAJ = -1008459.9832410682;

    for (int PixvMZJDTcr = 970781147; PixvMZJDTcr > 0; PixvMZJDTcr--) {
        xacVxODKBCf /= OPloiHfDTmAJ;
        CFrvboFok /= xacVxODKBCf;
    }

    for (int lZwavfrYOg = 1010416342; lZwavfrYOg > 0; lZwavfrYOg--) {
        xacVxODKBCf += xacVxODKBCf;
        CFrvboFok /= xacVxODKBCf;
    }

    return DwHxY;
}

int gvFVYkRwrzTe::thwmXbPVK(string pjuwQk, int APTwlo)
{
    int clKMuL = -1232843554;
    bool bOaTqWwxNdzIw = true;
    bool QFVfcFZaognfjqjB = false;
    double HjRFhLNFlXPqjY = -966176.618825246;
    int SUwOLJyiUjVxf = -1798650967;
    double npfQldwLyXlfOqsM = -650743.4100823714;
    int iNxGZlncZ = -956642251;
    double ilKpRMkDlqkvg = 459888.25417008926;
    string aHOMZlb = string("OSnryEAVKXRyBWbYQlYlCEyvvjSOjnDOezfLiKEMMKGdjvHScTWRwuXenBfCUFsrKdAeDJMFnjBjsBDtVTlnOOTQDWmUsaKSTBZLGTFTQi");

    for (int jVtSLQDkWmfnCwse = 1895456743; jVtSLQDkWmfnCwse > 0; jVtSLQDkWmfnCwse--) {
        HjRFhLNFlXPqjY += HjRFhLNFlXPqjY;
        bOaTqWwxNdzIw = QFVfcFZaognfjqjB;
    }

    return iNxGZlncZ;
}

gvFVYkRwrzTe::gvFVYkRwrzTe()
{
    this->ZUBIpwsilFBeTPZ(216379225, -365479.4812445334, 1355237869);
    this->YFIaisyJKBhigI();
    this->joNGdKBKlWGFmpB(2146687859);
    this->HNONKmzgXJLmB(-2098232377, 1888301082, string("JJQsGbMThkjmlWMlREvVSLKoQtcKqvlyjbUKPHxCHLgWABYTiTrzznGuEGstyAcKSMDCxzVxdufcmXbuQrffNXsqzWTvRehQdFJqtXuuezktHfhwEGJPsGvzzCMEnsUZRyLPIwywVGmAGNYvQbEITQjqOvuyMjlLcBENnlvpjTo"));
    this->UzQdnqlIoU(string("mtbKiEvhYVxRbZhMVlDldRSDBgqPzJowKRYjLuExjLqHAdeinHPgemJhASLkYmsEYqufBHzpdPBgywSAztLCUwpkUeAPwybsGiasdjNLSrhdorulufiZmTtTuXSGQJfdRMijvxmcHVFSvNlsUOUCrKvlwhBNABuoyNsWQlXpYLaNJomPCpPq"), string("eIYoPOAvzatYvkTWoZgaZMzGWwhgYVroUKmyCclDKxTsSaVFJjaMtMhVTDxwCgBLiyjGiZIOObNiXucsgYILfjuUYwRdGaRWanDAxQIvIyEKDNGtWGHyOTBJcLRNRTzdHcoNJEqwTDLZJUUDqHTKhzKgbYsVccvMjEmNcCWCwGyhEJyaGFOKyClfJjrBRxKyKwAfFWRfVnCJRyWxbhOTqbGvjkf"));
    this->CySsW(true, string("MQGvAjzUAmBxBRNOcFcORJSYgCmqVFS"), -1713233575, 2073887539);
    this->pCnXi(213148325, -11598.069115210052, 304432.4894131085, false);
    this->thwmXbPVK(string("OKXrODOiKZpOEJZbYxzTtZHHzgKNJXEbFoRNDfHoG"), -169882920);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lBAMiEsZZV
{
public:
    bool CXPSEMIDytwcXbh;
    int OGlCDcmI;
    string sxYytQyozz;
    int NFolRm;
    string tepiCHqFqC;

    lBAMiEsZZV();
    int ofElzkZnOwMNkr(int nNOriolCVElXDox, double tgSLaFlfNZ, int UXAhsseoxkpcY, double VOTHog, string SePIglliteLn);
    bool qeejsp(int xYjXBGcOfBjq, bool oMGHrWBzrAHjZOw, double sDuoFPDpPpYw);
    double HGvACWYHRnG();
    double rcBXOBnAlnQeRp(string PnyvbnSBlghPQv, double giFuqrWvl, string qQzshGGNJymq, bool CGzWzqpcdlZpOEW);
protected:
    string YcZQMNDaZadIS;
    bool FeYSNqFlxdbpvgm;

    bool ZeDmBHqfKfrx(bool WAiPfk, bool PHYOI, bool wsgKrMzaRZluWF, string clzyRuL, int cntfkj);
    bool ftHahXugfoHgL(string RhhnpH, int AohOnmXfpwyOm);
    double iYqje();
    int DrQOyUJv(bool jeoKcyqEIlm, string eLfQgL);
    bool FKrekwkPFxMpk(bool btdvAFn, double nrAxLVREUpZ, string DpdlHZE);
    string LZjchNNhiLXw(double bZTuJQg, int EuxggydTqEyWF);
    void SrciBlKufrj();
private:
    int SEHdLa;

    int LYcxzzIdNoLKcYc(string EyDSWNfmQjcCMNEh, string OpACR);
    double OkRVkQiiAdtpR(double gtngxMXeIz, bool ZadAPrhAawDef);
    int plJRHCejXu(double NADEfTzfECZ, string sPIbfkTM, string kYBWBN);
};

int lBAMiEsZZV::ofElzkZnOwMNkr(int nNOriolCVElXDox, double tgSLaFlfNZ, int UXAhsseoxkpcY, double VOTHog, string SePIglliteLn)
{
    string iFZaCXb = string("zENWWYsmHSTwYAwqPJumbaMEKrFbjJmZUnwa");
    string YhIiohbFRIBIC = string("gECvErEmvzyfkkEqfTrvhRlz");
    string pKAPPzmPHHDtjCFT = string("vhTxySbHmEZaGmwZNVHbcKbrPcMULVeYihoDKEBaovtZAnKsTlxBcdeZbRavGgoeNZDUwvyfvFhcfplYPHobjZRhvgfedxArFqbkbIGGtsJvTrjHANBDmgzNvNfVgvabDeSVWCLjncLoUsZbEoisizmBGqmBOaDaIQGZlcVEYoNOopfLOGQNIIXtnsAFwZphftYujwlTbnLMTAVyCCrqPCTBYjRQIIHiD");
    double XpioeIfj = 369095.9690768761;
    double TdERsWddizNnazHy = 1022595.0524557669;
    int WsCkAWsooHB = -2057656627;
    int tQepMjfoOKKK = 1095394023;
    double VWEZgByg = 740919.8729457386;
    double owfVTKdwDqtk = -755131.5375080042;

    if (UXAhsseoxkpcY == -1775151265) {
        for (int EwqXUP = 352757767; EwqXUP > 0; EwqXUP--) {
            UXAhsseoxkpcY -= UXAhsseoxkpcY;
            XpioeIfj -= VOTHog;
        }
    }

    for (int olFhrZZPHaI = 175099176; olFhrZZPHaI > 0; olFhrZZPHaI--) {
        UXAhsseoxkpcY += WsCkAWsooHB;
        XpioeIfj = XpioeIfj;
    }

    return tQepMjfoOKKK;
}

bool lBAMiEsZZV::qeejsp(int xYjXBGcOfBjq, bool oMGHrWBzrAHjZOw, double sDuoFPDpPpYw)
{
    bool lqHHCrivYCXOr = true;
    string xyqgTyRFQQfoRNK = string("aeueCBgPTxoSzgqNWWBLBAQVPSbOJOetTIwbgDONGWvCvgTCHfisFFGy");
    bool gjzsupdjESq = false;
    double BWHVYvCTamabhmL = -514688.4460765786;
    double zMCvvt = 810720.6264470839;

    if (BWHVYvCTamabhmL < -514688.4460765786) {
        for (int TEmtdj = 1905458978; TEmtdj > 0; TEmtdj--) {
            sDuoFPDpPpYw = sDuoFPDpPpYw;
            sDuoFPDpPpYw -= zMCvvt;
        }
    }

    for (int ZGLrkrvrXehVFuGE = 726640205; ZGLrkrvrXehVFuGE > 0; ZGLrkrvrXehVFuGE--) {
        gjzsupdjESq = ! lqHHCrivYCXOr;
    }

    return gjzsupdjESq;
}

double lBAMiEsZZV::HGvACWYHRnG()
{
    bool qFMUlBPJBWkzWs = false;
    double AlNQKVPzRUNKGrr = -735645.6480750735;
    bool abXYJh = true;
    double XRgPvaTYlMXj = 539454.9883334561;
    bool pspcVNxfCgSfnvJ = true;
    string ekEYWxQ = string("yo");
    int ZRYDIHrgFofsyVBC = 1575065729;
    double OTAaYryCI = 311329.592920651;
    string aAtzRbhlJYTXcGt = string("xnXZiPhWQJjtOFDDtdbifmxwxaqrvHYkkEQZbLchyWuzGCOEOsbEsINBhiqXlAXPywAZOvRJZCgGwmoptWtmUYvwDwMUMszhVkbliryIUTHRpClhodvJLSopuZ");

    if (OTAaYryCI == 539454.9883334561) {
        for (int VUXZfCNQpSN = 597085308; VUXZfCNQpSN > 0; VUXZfCNQpSN--) {
            continue;
        }
    }

    return OTAaYryCI;
}

double lBAMiEsZZV::rcBXOBnAlnQeRp(string PnyvbnSBlghPQv, double giFuqrWvl, string qQzshGGNJymq, bool CGzWzqpcdlZpOEW)
{
    double IGErgnSuAOiTp = -212878.5514495235;
    int JSKdQyhH = 1475879271;
    bool EkwdacXCXmsOQg = true;
    string LvZMCahpKYBt = string("JSuFifgLULPrvYbIxZDeJopzoKApdxUXQQTYuwZBajRpvlbNPDGIOOjziJbbwFJbFoyibEjTYrHEooWZRWGDcqbUsaKOnXoYjjuBpBHFwFKHlbyZHTWhgBFujMMIwaEzOmRDUSeaaKjyOKRXCwUPOeQbrzpGmmpYpzPrLGmedNsXmSNliBbsRYGcRXxWPmJNIczhFdMmyPFpXJyOkWEQBJTlpqZaRKwjiEM");

    for (int kmnMssQYY = 926001965; kmnMssQYY > 0; kmnMssQYY--) {
        giFuqrWvl = IGErgnSuAOiTp;
    }

    for (int fFDNUUVgqAxHC = 1657700104; fFDNUUVgqAxHC > 0; fFDNUUVgqAxHC--) {
        continue;
    }

    return IGErgnSuAOiTp;
}

bool lBAMiEsZZV::ZeDmBHqfKfrx(bool WAiPfk, bool PHYOI, bool wsgKrMzaRZluWF, string clzyRuL, int cntfkj)
{
    int kAPLcHyGS = -736131065;
    int iUxTlSZF = -460676430;
    string OKxcmcKkfA = string("luPWWvzlXXwkKhVkgasgFHLfLXacsKwkUsKvwVwjsoKmpMBtZTiKHKzBIpIBIBSBOcybCPVJNsqXeDxYoKMaPXZUmuhUeLScDbgDvGiblbsrrFgVWflkNTBqWogmoKqUkHOWeCSHobxMmSmSTxbWgbUeSNBNDowcNZKaDWYfFnQjSFJxjGnDWCSKAMsOLm");
    double DPKkk = 994088.6046555081;
    string HOhSOfwklHDmFhZf = string("pfhoFjFdfRFZrJtPhWhRgEZQemFNplQEYkUtCRfJjWfJIekGdUABtnYwJvPVSYchRegyxGrKToeBOPxrjdWxfPlgEDLjqoSkHdYHiQyMQFSBbqbyiIdAljTDXSvOJTNEuMnojdwSw");
    double MhNwwDkDKJLIGvdc = 176841.79870624462;

    if (cntfkj != -460676430) {
        for (int toUXZAoOEkOW = 1521083538; toUXZAoOEkOW > 0; toUXZAoOEkOW--) {
            DPKkk /= DPKkk;
        }
    }

    return wsgKrMzaRZluWF;
}

bool lBAMiEsZZV::ftHahXugfoHgL(string RhhnpH, int AohOnmXfpwyOm)
{
    string NmbgagV = string("aZXUutrpJOPiekSMSQiOYBQazsNHuVdvtcyGlmOCdGUvGbFeAcmFsWtLwPRtfWkhOmUQZTkZAIncda");
    double zgWDDIyLikU = -305758.13469182403;
    double EoEuo = -293138.8675937835;
    double tIACbla = -218418.3486896147;

    for (int WQmyFE = 1680911873; WQmyFE > 0; WQmyFE--) {
        NmbgagV += NmbgagV;
    }

    if (NmbgagV > string("lEWsGXztKYbTXIDIZUxkioUzkfHrCVmvlhTXqZVEFfyxwfSeRxFXKGSkPjKLKJoAQzmNOCrCgyliUlsRcRXScIwIEkBAKRPRqCOnICjwBnHAqIYeDKTUknMPoxSetAYhnBwgExLLpKQSeInZMZbGRnWvKMzNTGzrmwqjFIN")) {
        for (int SHeOtbAMKtCD = 638267330; SHeOtbAMKtCD > 0; SHeOtbAMKtCD--) {
            continue;
        }
    }

    return false;
}

double lBAMiEsZZV::iYqje()
{
    bool MVfPsAoP = false;

    if (MVfPsAoP != false) {
        for (int MMNuoRUqll = 1033643788; MMNuoRUqll > 0; MMNuoRUqll--) {
            MVfPsAoP = ! MVfPsAoP;
            MVfPsAoP = ! MVfPsAoP;
            MVfPsAoP = MVfPsAoP;
            MVfPsAoP = ! MVfPsAoP;
            MVfPsAoP = ! MVfPsAoP;
            MVfPsAoP = ! MVfPsAoP;
            MVfPsAoP = MVfPsAoP;
            MVfPsAoP = ! MVfPsAoP;
            MVfPsAoP = ! MVfPsAoP;
            MVfPsAoP = MVfPsAoP;
        }
    }

    return 191492.09235520454;
}

int lBAMiEsZZV::DrQOyUJv(bool jeoKcyqEIlm, string eLfQgL)
{
    int woMUbc = 69810269;
    bool vlUwLsRyqhneTXn = false;
    double edeojTCdM = -508362.2100799438;
    bool owByn = true;
    bool GfpALlybASNpqD = true;
    bool vGFTrRgPwQVIIn = false;
    double ICtaBwvn = -362206.03551276634;
    int KlarkJnBORQofYMV = -538817504;

    if (GfpALlybASNpqD != true) {
        for (int nGlGEiQD = 227214164; nGlGEiQD > 0; nGlGEiQD--) {
            edeojTCdM /= ICtaBwvn;
        }
    }

    return KlarkJnBORQofYMV;
}

bool lBAMiEsZZV::FKrekwkPFxMpk(bool btdvAFn, double nrAxLVREUpZ, string DpdlHZE)
{
    bool bJdDivy = false;
    double DyWyydZkAEQbb = -754660.7247017581;
    int oMiyJ = -447292957;
    int onKWF = -46427138;
    int kUFoMMVnTSLBzo = 325410528;
    string GgkuqkMkZJQD = string("fddtvOCnlBrZoKEuGdKbTKfAByamvRllDaSrtewegkFPitwKYDHtEofBxVWznRHYcDzuyTGojjipnVlSSsZxHKNAzPSiJidIWsaUiNqjfLQpHETPWbdFKxsqGfieXBIXKxCZCOkummMkwMbkVklYPdGNpLnLAiljCYxsJhfaWsfbQmvihKIAXNqUfiDlqppAHPzNsogWOmpyGHyajWOKFaypllRLIUYiVMACwgoin");
    int NvtnYhmThtMct = -117253451;
    double RgBtRo = -510455.3184450427;
    int glUlt = -1117509165;

    for (int gZEyHUMWfExXBq = 671745595; gZEyHUMWfExXBq > 0; gZEyHUMWfExXBq--) {
        NvtnYhmThtMct /= kUFoMMVnTSLBzo;
        NvtnYhmThtMct -= oMiyJ;
        onKWF /= NvtnYhmThtMct;
        oMiyJ += NvtnYhmThtMct;
        kUFoMMVnTSLBzo += kUFoMMVnTSLBzo;
    }

    return bJdDivy;
}

string lBAMiEsZZV::LZjchNNhiLXw(double bZTuJQg, int EuxggydTqEyWF)
{
    string rTqgsZnrxSF = string("LnOXVKqTSbKIizVwAJoACLyVgvuMFl");
    double HGwbfSvvEmkIK = 159122.8837348045;
    int pObjrSnjzuagJOeB = -1154802597;
    int AqXSHYvqMoxlcHAx = -2079677727;
    string SCFQs = string("LzomzuBqzYAPyHnXCfGehpabG");
    string qRsIuqKPZCQZYqGv = string("BIYVfVdlXfsUYVsRHjbWMTfxiWzFrahuwuxWEtSdtBqPwWXxwzlKgRtfltjMdilSvWglAzeLwZcyetTNrKfSpRlOdsAyvkpDJfUKbfAUFnKIqErmLDqgcmzlslgKrjQEWgdUzikYPjrqGLhqSEEnKLXRBRdHPzaemRIckMcLNxpOTzTHWFoJXGSelfrKCzAOrDCJzyKRssCMIB");
    double XYTnsJsYyYRpT = -256698.61280289383;

    for (int wEPnxhuy = 1723714967; wEPnxhuy > 0; wEPnxhuy--) {
        XYTnsJsYyYRpT -= bZTuJQg;
        qRsIuqKPZCQZYqGv += qRsIuqKPZCQZYqGv;
        SCFQs = SCFQs;
    }

    for (int ByUwTpSTCQtUD = 1872880156; ByUwTpSTCQtUD > 0; ByUwTpSTCQtUD--) {
        rTqgsZnrxSF = qRsIuqKPZCQZYqGv;
        bZTuJQg /= bZTuJQg;
    }

    return qRsIuqKPZCQZYqGv;
}

void lBAMiEsZZV::SrciBlKufrj()
{
    int HbuDJJHTcVh = -1445061861;
    bool RNXweaAQJtpo = true;
    int NgiENcCAhzP = 821215202;
    bool BaaHs = false;
    bool qZMhdZz = false;
    string vXDfujp = string("UVuchoMsgfZEGQzuhMoBRrmZCKqdJoMmuDhkzTHyiJZNvQmTixvwRifdEJxDYoEMXhDpecfvszuAwixmSAtwCJGxAlFSczFyzTSGYWOzAQOSxIrJdITnsLntJHgncsIajuHpsVEUCjPceAeFreQgKEOKyBeotUobSUdWCutMEDpQzjkpHfXoeiPExwPDRkAFPNCOsaSvxOIgvMdgpoIlEIwabgWMhJVXgZYjWZbWyZQFwrmKCEgGNTZWOx");
    bool lDEMQYcojz = true;
    int mbYvKoYCgzG = 1859333569;

    if (HbuDJJHTcVh > 1859333569) {
        for (int sKVSWfZGVQw = 1537631316; sKVSWfZGVQw > 0; sKVSWfZGVQw--) {
            continue;
        }
    }

    for (int IoQfZztAjKncVwn = 1508028246; IoQfZztAjKncVwn > 0; IoQfZztAjKncVwn--) {
        NgiENcCAhzP = mbYvKoYCgzG;
        BaaHs = RNXweaAQJtpo;
    }

    for (int PVGtJHn = 1413070149; PVGtJHn > 0; PVGtJHn--) {
        NgiENcCAhzP -= mbYvKoYCgzG;
        BaaHs = ! qZMhdZz;
        RNXweaAQJtpo = ! BaaHs;
        BaaHs = ! lDEMQYcojz;
    }

    for (int JuwPIKfF = 1408363961; JuwPIKfF > 0; JuwPIKfF--) {
        continue;
    }

    for (int QoACfg = 2019624085; QoACfg > 0; QoACfg--) {
        continue;
    }

    for (int ntRSJmLScUDLzsS = 1690963262; ntRSJmLScUDLzsS > 0; ntRSJmLScUDLzsS--) {
        RNXweaAQJtpo = ! BaaHs;
        RNXweaAQJtpo = BaaHs;
        HbuDJJHTcVh /= mbYvKoYCgzG;
        qZMhdZz = ! RNXweaAQJtpo;
        lDEMQYcojz = ! BaaHs;
        NgiENcCAhzP /= mbYvKoYCgzG;
    }
}

int lBAMiEsZZV::LYcxzzIdNoLKcYc(string EyDSWNfmQjcCMNEh, string OpACR)
{
    int GescmHAiXZNwihYt = -141162308;
    double GYXAKvaWs = 825946.9478782574;
    int ofjJKQTOMlx = -1893793381;
    double AjZNz = 816250.7211427776;
    double ULfqWL = -138793.6112281499;
    string OSrKWSLbZaQKli = string("aNdRWNOZFZLqkBCGDRgSIPWditnTwALlsENGfSTSlOYYgdzaQmrkazdGgocKXTrJaLlJAdRtulehuBcBNHnVrroBOKgKRTAcnSjgzpildcbymyqUspBrEajCdFPoAHxayiZxCtQKdeGxdeTqhKXyOtRegsQTDLdGvRXzBfQpYymVbJvlPAMtiTQsTYofsKMBEoCgrabYeiFiWiSEMJYDWFNvUCRbgXoEPUGbcSOZiSJjecxDTjzHGAIPYpr");
    string QsQjW = string("juRlWHsaFJgcnUSkmBAjrATRTXkkQJQTrmUNbzTojyBPNTSYfkXmLAmkNYY");

    for (int yhvaxQfzMxMihn = 1489637492; yhvaxQfzMxMihn > 0; yhvaxQfzMxMihn--) {
        QsQjW += OpACR;
        QsQjW = QsQjW;
    }

    return ofjJKQTOMlx;
}

double lBAMiEsZZV::OkRVkQiiAdtpR(double gtngxMXeIz, bool ZadAPrhAawDef)
{
    double LuvqvHRifyRenk = 35489.44090738362;
    string vIlNBSHKdz = string("WZxWwUAPfORHSLVFgBucfpwWPfszIRyeDUeVuBtwCMCYYXHhCQdczhHyLDPwwklmoeTIAbiAKeicAWoINYUxuROiqyewVRlQoosxeMFBGCwKqzFaelVlzSvTPVTBxgPCwGBIDrHLFtGCNVE");
    string zGwUJnBLJba = string("qbZKYZAAzHFZDonLvHJaglwWSdTpHMdlJSwawgxnXRkXptsRbNHKbpjoXwuqTkPKFgpQncyNkzIlDshqnuxyRLAsaIAfnUpjFMiVQEJHerhkZufmvMdkmqpPNPxtzcwjGErOJDHRKYzycgzxDTcfZqtXGptVWRHQfGEaiieRmASaWkTQrC");
    string rLnGbP = string("oXMxDiEGPDznYBvfheZQUgdOOSUAcWdCmkSvOVt");
    double klkpvIvuketYg = -381028.9373575844;
    string dVJfLhToFsAZwks = string("eVUmmNjXTkvdVqZCyaFNnrKqgExW");
    double IAhSNMVPUBb = -612335.7955091242;
    double ZWDwHZrt = -800277.1774887454;
    double cRjBJsXastZXMc = -551027.7745155845;

    return cRjBJsXastZXMc;
}

int lBAMiEsZZV::plJRHCejXu(double NADEfTzfECZ, string sPIbfkTM, string kYBWBN)
{
    double bKQTl = 971882.0670622925;
    string GNRtJGbLZxmx = string("MwxvIXyRKHSkfypQxbadxiMqhlmgevgFYNbYFjytrQmsBYXokxdNVMsyPjwTkiLIIXXQmHdzYjAfPoPSaYBqcRCsVPzEKpmdMDFiUcDhaOvXVwIDQFTuVElHlJKbIyZsXRSNhvUhByMXTSriIlAEUapHcokwiSFNzazNwCKIhtIjFSjJMnhJdYtTWYtRtPJVf");
    int fmBDoP = -1401261660;

    for (int pjMFAutWlOOlKh = 1997655613; pjMFAutWlOOlKh > 0; pjMFAutWlOOlKh--) {
        GNRtJGbLZxmx += sPIbfkTM;
    }

    for (int pJyBLdCnGZ = 874112496; pJyBLdCnGZ > 0; pJyBLdCnGZ--) {
        bKQTl *= NADEfTzfECZ;
    }

    for (int CtbiYtgEv = 1777348103; CtbiYtgEv > 0; CtbiYtgEv--) {
        sPIbfkTM = GNRtJGbLZxmx;
        NADEfTzfECZ /= NADEfTzfECZ;
    }

    return fmBDoP;
}

lBAMiEsZZV::lBAMiEsZZV()
{
    this->ofElzkZnOwMNkr(-1104325099, 783737.1817960512, -1775151265, -333824.18797940336, string("dpK"));
    this->qeejsp(-1311501230, true, 526171.5779592032);
    this->HGvACWYHRnG();
    this->rcBXOBnAlnQeRp(string("ULmUNFAmfELDLMtIyBgLebimAfXQeRKjFjaImgfDvyvCUBRtwojtLUGdFREzdsQfxTTzHospoVEmzHZhoXcJHlCVEAbNbVwxwVyjQhZIgVYsSbxVIxhlJveqmnsfMTIWkZGDmvagysSLBdrtaJdcHeMquhUlOLUsjzDfZ"), 243515.41625091873, string("wNTwiqMVjWLqxIGinUOMXxJTHdjoIFQRpDujsCSwSZVaXngDjsFzaaXHZVJOlPfTuXNRwggKAHzRbRMOcRdAmtvPggjbJVZNzclgWytjXKvhMtda"), true);
    this->ZeDmBHqfKfrx(true, true, true, string("byBFJfgilybVAg"), -1284566025);
    this->ftHahXugfoHgL(string("lEWsGXztKYbTXIDIZUxkioUzkfHrCVmvlhTXqZVEFfyxwfSeRxFXKGSkPjKLKJoAQzmNOCrCgyliUlsRcRXScIwIEkBAKRPRqCOnICjwBnHAqIYeDKTUknMPoxSetAYhnBwgExLLpKQSeInZMZbGRnWvKMzNTGzrmwqjFIN"), 59818787);
    this->iYqje();
    this->DrQOyUJv(true, string("ACsYEmcIuEfebIrFZVBDRKqDiYqlzYOsobPWZvAFbhdomqiAQWIJtnSxnGtjNPRrfsTeQBJTZEIDzvzfVatLnWxldXNbisJOmOLWHlTEkKqAVyiWMlQhErahUvZQnSxXdJtpemnhcvLWFijqvLtQlYzRYYBQhVRWORKRwNEPsRrfMyPmTiLFrwrejVaOsRzfXiGKXeZWcJYKHRGzLoCvxafIJcZIiwTBYqcpKhjjxu"));
    this->FKrekwkPFxMpk(true, 512708.5168035206, string("lpuNTLJyEJdBsXzNuQiRoHKuYhUyHKIxWfFVeoCNJzUQilYvWKJDobeBkmrAwVkpTAaSdxjbGjIbZqvcIWknWMXbRVWEqOjsunSHntLwjEUaPYBqihYWzScgrJzMGxaFxRjoKIzrREsCGUBWFGPxZDmofKGVlHBxVYHYXvgIzcjlxHcoUwhmtdptxAnnSEnTQMK"));
    this->LZjchNNhiLXw(150683.45587636787, -634618865);
    this->SrciBlKufrj();
    this->LYcxzzIdNoLKcYc(string("hnOiHgDjepfOjUsTyuDnurUCuUipOevfOyaaWZONlG"), string("cZhmehAwFFbqivnyPhSmfOnBCpmJObLFPzukpkPpurtwLKblyPEdQIovPQxGLBsRCxwFpwfTIQIbvQsSAtobhQuFdlhwDKTWnhXLvFyvHxrtxpuIddwVQFvqczvErvIVGmwyntyyoAQBQjgwKddmoovpZxhrLjUNEyqNJxUVXCsHUUZRCknQxHvFQmXrpsewyzIcSFnTNKuYJwmHSFzvMckCcKasQVbizdOtXggVfnDptEog"));
    this->OkRVkQiiAdtpR(-74763.32598407571, false);
    this->plJRHCejXu(1011331.062351991, string("GQOvVatsFWTfZvlVAhHNATfeVtKWejTKBtVYNOfaXRYYcBoDksrELwIzyAMQZreeEbhHaLEjoUlcmXLUMOnTGHrEnwWxqIUEMvaCullyDlSqrFTJoVHTTWQOekGpLvHsEaPHZuWpCpuQdMAenbyunQRyhzdMlZJivcgIsAnE"), string("GjAKQORuvlGLzDSWlWrfYGepgHfjBQqJTVChrxPBAduAMyrkZhBzZMCWZxkPaWScgdeYxYMXyKtCGBUVWZlZwvfWUodFojbDpzTCxJvAYwVzDvtfKDvvEtkauVvnl"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VeyLkkjFbXeTd
{
public:
    int xOFsnZeafOLXcwpy;
    int dCUByrylJ;
    string weXCIIYImklDl;
    string tRxxyLYILCmtYKoY;
    double IoUIWTNWTZD;

    VeyLkkjFbXeTd();
    string LmlTSVjJvRbCmCCJ(int tTvsxNC, string zcBKUFlxHxxwEK);
protected:
    string KlSnVMlJzEm;
    double PTiAP;
    double kULFGQnL;

    int rRlXIvMIv(bool FtbGSMtMDXS, int nvqeYeYkE, string TbuPt);
private:
    int OTRFHqPujdk;
    bool cMDPezPJmbSKLeI;
    string jwCQNYDHY;
    int lvVlIYWTixaF;

    void seAzNBiRuq(bool RYebtgSSMSqCns);
};

string VeyLkkjFbXeTd::LmlTSVjJvRbCmCCJ(int tTvsxNC, string zcBKUFlxHxxwEK)
{
    int RwaAikzim = 184351807;
    double HitasjGUlFSbnG = -156524.45637267394;
    string oNuAWVtxaACTtuFy = string("yGzkQqSzVfkIMoOvbTWlQHgVeXazvrFMmGvIbueMsKKxnuFRrpsWSPrOsShPISXA");
    bool vIULzpzM = false;
    double YmmVoyLcoNqpHl = -549890.2432822756;
    double GyNYuCw = 998315.310983332;
    int FotgiXmSpMoBk = -1442374327;
    int BbaNRKccyj = 352083541;
    string uKdoTIqhUUu = string("iqzZYsQhisZltqlAlSDiUrYCxBf");
    string JmysuaBwXLcYyDhg = string("iStUpDgMTclMbiEoaYj");

    if (uKdoTIqhUUu < string("iStUpDgMTclMbiEoaYj")) {
        for (int vStzCXMKyBEi = 894464930; vStzCXMKyBEi > 0; vStzCXMKyBEi--) {
            uKdoTIqhUUu = JmysuaBwXLcYyDhg;
            uKdoTIqhUUu += uKdoTIqhUUu;
            tTvsxNC = FotgiXmSpMoBk;
            oNuAWVtxaACTtuFy += JmysuaBwXLcYyDhg;
        }
    }

    for (int QqyYt = 1374716149; QqyYt > 0; QqyYt--) {
        continue;
    }

    for (int OqRHUwkZFnDIba = 1108314617; OqRHUwkZFnDIba > 0; OqRHUwkZFnDIba--) {
        vIULzpzM = ! vIULzpzM;
        HitasjGUlFSbnG -= YmmVoyLcoNqpHl;
        oNuAWVtxaACTtuFy = oNuAWVtxaACTtuFy;
    }

    for (int LjShkyXEo = 1869902827; LjShkyXEo > 0; LjShkyXEo--) {
        YmmVoyLcoNqpHl -= HitasjGUlFSbnG;
    }

    return JmysuaBwXLcYyDhg;
}

int VeyLkkjFbXeTd::rRlXIvMIv(bool FtbGSMtMDXS, int nvqeYeYkE, string TbuPt)
{
    string zITLUMVnEnImj = string("XCXcoDxhQztHgWelsjYUoSXopvNvTWCmraOEyawPmyeuRObtROCpfBJsBQroqczEsclYjIHusTwkGlpdgrCsZmAqVQgWTbzmSRNEFGIYpVXZGjAFmRHOQkjIwOlVgMKibUiVVKvjbBVrLohKTELQauzTLUZuulDhZAakSrtVCfjDKktJFXwaDrfIRdTABMAiOJezbVRamYlqdVTIohqvCeoAEOHJlR");
    string jHgMKtfF = string("CNQBODnRRWOmPlaXdQCuo");
    int iTTYaqaiZfCjPIz = 1549900204;
    string oNEtO = string("CykVmcFgfRKVYbAcqseziUbwaEQplJWuyqYuRRRTTmLpCClAmLbZWYAOnfGZAcojkCmifohPYHsvssUafcjhFCFufhPXZBzqmbmdPnqleIycALtYqDqgGyiM");
    int ZhRWLjBZJ = -435222529;
    int MifhMyIHsY = -1532178103;
    double MIlufy = 943090.503533171;
    int bOtYQMA = 1074991078;
    bool JSZfGQDfAcnahH = false;
    int uWSwOeZTyVs = -729399758;

    for (int DBNDQPo = 310362837; DBNDQPo > 0; DBNDQPo--) {
        TbuPt += oNEtO;
        uWSwOeZTyVs *= bOtYQMA;
        TbuPt = oNEtO;
        iTTYaqaiZfCjPIz *= iTTYaqaiZfCjPIz;
    }

    for (int VNkNFZctLwXiJBK = 108775105; VNkNFZctLwXiJBK > 0; VNkNFZctLwXiJBK--) {
        continue;
    }

    return uWSwOeZTyVs;
}

void VeyLkkjFbXeTd::seAzNBiRuq(bool RYebtgSSMSqCns)
{
    int CsBeCf = -1587432587;
    int NVrFi = -1045722085;
    bool NWSDTKKKd = false;
    int PGJWvRWZbAfM = -957095863;

    for (int STrxkIxrq = 1068202275; STrxkIxrq > 0; STrxkIxrq--) {
        RYebtgSSMSqCns = NWSDTKKKd;
    }

    if (PGJWvRWZbAfM > -1587432587) {
        for (int oOpEaIYwbx = 1443053726; oOpEaIYwbx > 0; oOpEaIYwbx--) {
            NVrFi -= PGJWvRWZbAfM;
            NWSDTKKKd = ! RYebtgSSMSqCns;
            PGJWvRWZbAfM *= NVrFi;
            CsBeCf /= NVrFi;
            NVrFi /= NVrFi;
        }
    }

    if (CsBeCf == -957095863) {
        for (int rArerqSwgE = 966843215; rArerqSwgE > 0; rArerqSwgE--) {
            NVrFi *= PGJWvRWZbAfM;
        }
    }
}

VeyLkkjFbXeTd::VeyLkkjFbXeTd()
{
    this->LmlTSVjJvRbCmCCJ(67706002, string("wgbYFlZdRmxTvZvYGRfRToNztyzUTIXnSmgcTGpRyMCPpSgnUujVTesLZIxQCwawTXntBdMiOjALslifTwcixZyWPtfSZJwkoYJxzNTmvSXEdLlJZEHEubNAZgVKhVwskVSYnbZFmqrYwHbspggVlrjoQWFDwCNQhYeAZmdExEue"));
    this->rRlXIvMIv(true, -43248333, string("tdMqhkuzuFgHlniipYWXuuwqpjMYwjKdSqaLpxajsDIhivVlITjGPkGiIwUwFSSZvQtFwvwRGSNzBFQDuMKuauolPKKLwoFfessHKGakiDhYBgrAoaQtZjHKyEprteFoRwaHNzArfsTdbcwLdntnLwYbbiePRpcyIJMVgexOKsIXicZTYKqdFymfXJIwYDyGZXKIefifdmzLlaKzqYzMp"));
    this->seAzNBiRuq(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KwMuLKqARlAkKwD
{
public:
    bool WQAWtKHrZ;
    int uBzkKjoADAvG;
    string kJhWkNl;
    double ZayhrWFokPqgieoF;

    KwMuLKqARlAkKwD();
    double FxkOxmIybAa();
    bool lWbeGMBISnWddpGN(string ZvMQmWGWRZMxZuOA, bool YbuPtT, int TTFaQf, double lZvEq, string PIFDhiW);
    bool rLpxzdblgp(int YVosyzW, int UNUucgEKH, double DzTUXxbSiEggJ);
    double qOywx(bool rPdzth, string bnMrSwqLCdjp, double WXcDiHDpiZmRds);
protected:
    bool EJfiMiqgq;
    double SVQpfrPMbGUnI;
    int nCqtjvm;

    string eJMumiJdk(bool pRnbCTOnCU, double OmXEHdp, bool rAbLNRXnH);
    double sbWSx(int YdfphKtPQeFgsE, bool gyHBpTlPTMg, string xixBeWAeh);
    double OFQsIoTH();
    double TgILHuaezRsjM(double RbGZxVQPs, string aTtAOMX);
    int XAkTcRuy();
    double TECOrOKeMHDEQK();
    int jWgZCyamNYnTv(string KBqTlgVhU, double BTwQMf);
    bool VGnUWfhbVfo(double oFQvZDDXFZ, string IyPYhrQU);
private:
    bool TGUfaJLspJ;
    string KYTnhoyQdMWp;
    double LsSnuoHkvnmXdEsU;

    bool HNxKaZ();
    bool GdjDJQXzF(string CVzqCiSbhhVcG);
    bool AoNQVe();
    int aigXcs(bool FBRFsNRniHF, string ithvjARTaBBBW);
    bool BttxFbz(bool rVycU, double ECnWtAX, bool EPxwurdLwgQTeE, double YplQubFRm, double HkhMnfPd);
    string RiYDfuMP(bool QrxAfzzxu, double MXySAwPuNcfFbXG);
    bool uYoUCOsD(string vmOAOyWssvcll, double pGJkAmnyxdqGAxUk, string hSATMlGEsH, bool mDDaiw);
    string YnCYOpfUAgDygEU(bool hHMxpul, double oPDwmsOhLT, int CgiybxSCLhp, double ckHTkXdyqgQmW);
};

double KwMuLKqARlAkKwD::FxkOxmIybAa()
{
    bool iLNjeTJqayw = true;
    double LJDiLKflU = -241272.1199506923;
    double VvKPTHCAQrRuGgGe = -528392.8904842772;
    double iPwTo = -991855.1270850515;
    string oUpbMUNwOkhteyo = string("tNyzIhDKBwbRCWobmxVrvNItjrosLntHdkhMsWjZvPMIrTTkqFdEaPDGjcAkAkNTQNIFqKJtsnaOWayNcocVzHVgFROLrRfMgdYzEtBzLLwiKjiGmZNxioWBArnrVmoHPJdlU");
    string bMlBSLTdapjuHc = string("djZCAkJvBuSoqYdssYWoVvRMJRNRZjPUMhqtxnLfVSYQtoyQZNvxDqwPuofqDHuRVQEE");
    int lPVwCDtVHs = -1558656124;
    string VALvSKr = string("bUEDYlqdCjAIEbgArWDiNrYIQFXZGCWqCTgEuPpvjoxfvpmsQzazIFlwGiHclvILOtxdYfoiwmlltUdYabNfbbcdyCEM");
    string RoDuEosyk = string("OotAWJXDuEMcefOLIpyasktUndPFfcpUarQaZMFyMlecAmVuhWuFwlbSLYjPwydljoKRwmcvwNrzIARIqbBaplOMCAVfpHBNLwUsZvBeqdSPQLXUsoMIQSsRQsUyeZGZiLJETPzGSLmllMegWUocxjinxyZBjYliVeTFJfsLNyTyXkwpDTHmwXMsCuVIvOsbpwgiEnVXKRHQAZRnnVYleRyFDlsIwPewPAdMMmQAPKqikLDpczVKwT");

    for (int HlZxybTP = 745051612; HlZxybTP > 0; HlZxybTP--) {
        RoDuEosyk += VALvSKr;
        bMlBSLTdapjuHc = RoDuEosyk;
    }

    if (oUpbMUNwOkhteyo >= string("OotAWJXDuEMcefOLIpyasktUndPFfcpUarQaZMFyMlecAmVuhWuFwlbSLYjPwydljoKRwmcvwNrzIARIqbBaplOMCAVfpHBNLwUsZvBeqdSPQLXUsoMIQSsRQsUyeZGZiLJETPzGSLmllMegWUocxjinxyZBjYliVeTFJfsLNyTyXkwpDTHmwXMsCuVIvOsbpwgiEnVXKRHQAZRnnVYleRyFDlsIwPewPAdMMmQAPKqikLDpczVKwT")) {
        for (int yxMPFrSNhXNC = 299495893; yxMPFrSNhXNC > 0; yxMPFrSNhXNC--) {
            VALvSKr += bMlBSLTdapjuHc;
        }
    }

    return iPwTo;
}

bool KwMuLKqARlAkKwD::lWbeGMBISnWddpGN(string ZvMQmWGWRZMxZuOA, bool YbuPtT, int TTFaQf, double lZvEq, string PIFDhiW)
{
    bool hLFgrDBgBGkaVMZl = true;
    double rwvrvGqtjotS = -997737.6137596157;
    string jDuZTOYyMQrVJ = string("HegqFXJabpLtFUCqlhnSFhLHEyPDleQVuXRHTMgoBPvNcXfMaApYrUssYPYukWvsFcsgxPYFVsFqNXEnjCaorpxGpBQgxYtYbaxiHdgITxUdfewKgWJJRSxoBRYPzPhyhWukhLluFvSAJMvVlQgwcoXcUGdyizGY");

    if (ZvMQmWGWRZMxZuOA > string("HegqFXJabpLtFUCqlhnSFhLHEyPDleQVuXRHTMgoBPvNcXfMaApYrUssYPYukWvsFcsgxPYFVsFqNXEnjCaorpxGpBQgxYtYbaxiHdgITxUdfewKgWJJRSxoBRYPzPhyhWukhLluFvSAJMvVlQgwcoXcUGdyizGY")) {
        for (int aGcLxqOj = 412385878; aGcLxqOj > 0; aGcLxqOj--) {
            continue;
        }
    }

    return hLFgrDBgBGkaVMZl;
}

bool KwMuLKqARlAkKwD::rLpxzdblgp(int YVosyzW, int UNUucgEKH, double DzTUXxbSiEggJ)
{
    double XECANif = -971215.9426229411;
    int cYdlSJvZtUZ = -943722340;
    string BqAtQoGeVWwuEgj = string("VBeNfeBhhPpyuRQEniAjnCTsbNZRQVTVrUQyxCFImfWSAjWnTyiDOCVnxOdXgTwzwZlRcisPkCHdwJfzuNmEstrsFUgpRZRduhDpSqLuxSliNSMaNwGmIulstEPrSNMAegSIXSxVhgoZPDRrkUZqghxiHEkfYauXSUQHivOloaoKFHaZjxEgCIamvgi");
    bool ixcqhfgEQZdYhABo = false;

    for (int vNuUUpmmbyccT = 1700218241; vNuUUpmmbyccT > 0; vNuUUpmmbyccT--) {
        continue;
    }

    return ixcqhfgEQZdYhABo;
}

double KwMuLKqARlAkKwD::qOywx(bool rPdzth, string bnMrSwqLCdjp, double WXcDiHDpiZmRds)
{
    bool ZISGPURLXNlqVaN = false;
    double QyazzL = 356740.7802106435;
    double sPCXwSvOgqG = 721459.2510623022;
    double fWXHQqs = -180060.75596682364;
    int emfKDYjybFR = 1090274804;
    int GaunTxJiKI = -1695129854;

    for (int xiztBxZoH = 1353204031; xiztBxZoH > 0; xiztBxZoH--) {
        rPdzth = ! rPdzth;
        emfKDYjybFR -= emfKDYjybFR;
    }

    return fWXHQqs;
}

string KwMuLKqARlAkKwD::eJMumiJdk(bool pRnbCTOnCU, double OmXEHdp, bool rAbLNRXnH)
{
    string TPPWtoERsfFE = string("SygHPJDEJkaUgTIZnzXFrUDHLTGEtDQUmNUtkrYAnzQasjesGIIBKjqwZpW");
    double ZyXKArnIIszQCQA = -945339.3977733403;
    int SrEOpJklW = 1328988450;
    double zFkZJNO = -37440.224513705696;
    string VUlYlqZAdeyUCIlN = string("aCwDqFXgplNJNSmTZgSKNLZLHBQnehrsBcwQIyniUKzvR");

    if (OmXEHdp >= -37440.224513705696) {
        for (int audgD = 1911818965; audgD > 0; audgD--) {
            rAbLNRXnH = rAbLNRXnH;
            ZyXKArnIIszQCQA += ZyXKArnIIszQCQA;
        }
    }

    for (int QsaYwDr = 1448232846; QsaYwDr > 0; QsaYwDr--) {
        VUlYlqZAdeyUCIlN += VUlYlqZAdeyUCIlN;
    }

    return VUlYlqZAdeyUCIlN;
}

double KwMuLKqARlAkKwD::sbWSx(int YdfphKtPQeFgsE, bool gyHBpTlPTMg, string xixBeWAeh)
{
    string gJCnwxYUDuVxsy = string("nKQDssjDMtVKdOLTlDNnceMcpPCyPvilZgucDjEWYpXjGqGKIctGmSHRviyHwKOHtAaJAMnYMjbTgjTmqGylswrsIcJHYTtAJXByZQJmbv");
    int hlrFVfKFVdusk = 337624367;
    double cQTSJdZkiLvkr = -303440.0834792501;
    double QcFRuugX = 797703.7912988224;
    bool ylrUUAJyqzIvDBE = false;
    bool EkAwfSrxqUh = true;
    bool jNFPmUumaNzohCN = true;
    double WscgQyivjncBiK = -826697.3865976859;
    string JoVHfbc = string("NFUySUXkUThPRvwUzNfyaLlCwrIZkXfctwxGsaZVaLRPhqOUNAJGltYdonDweYZhGFqkujihbJCxJwrVDjffAsvSccvViSOKAKCreEduUeTGOELQpxLxIULGlMTphrZTEoehm");
    double KtKNxyCPKvUJS = 705236.9353009369;

    for (int hGpqodhyayr = 1750043797; hGpqodhyayr > 0; hGpqodhyayr--) {
        ylrUUAJyqzIvDBE = ! gyHBpTlPTMg;
    }

    return KtKNxyCPKvUJS;
}

double KwMuLKqARlAkKwD::OFQsIoTH()
{
    bool vShtbxB = false;
    double mVaLdFEXb = -68422.46215454374;
    int LXDKP = -1288637968;
    string ZLiOgRbMvZyTmj = string("EvyuiUtaV");

    for (int RyhlRsqwmXW = 68904859; RyhlRsqwmXW > 0; RyhlRsqwmXW--) {
        continue;
    }

    if (mVaLdFEXb <= -68422.46215454374) {
        for (int yjPJiCPJ = 1511551558; yjPJiCPJ > 0; yjPJiCPJ--) {
            continue;
        }
    }

    for (int yTAUEwcpZkOgKk = 1759878678; yTAUEwcpZkOgKk > 0; yTAUEwcpZkOgKk--) {
        mVaLdFEXb += mVaLdFEXb;
    }

    for (int huplsuTAbCZv = 1887126821; huplsuTAbCZv > 0; huplsuTAbCZv--) {
        vShtbxB = vShtbxB;
    }

    return mVaLdFEXb;
}

double KwMuLKqARlAkKwD::TgILHuaezRsjM(double RbGZxVQPs, string aTtAOMX)
{
    int NchfnVKalJec = -761147550;
    bool VNKUlo = true;
    int lAonJjzMlgwBwz = -1437947602;
    double QvXYzBTOIHAeTf = -779250.8039033321;
    double rKofCwMJayDw = 776132.8141954801;
    int ZHYVEgzKj = -1408830011;
    int CDQMQkCoBuK = 394370345;
    bool bUNyq = true;
    bool dIeadK = false;
    double ZonaMP = -395989.1599682797;

    for (int YNsJdjxGyVX = 90697806; YNsJdjxGyVX > 0; YNsJdjxGyVX--) {
        rKofCwMJayDw += QvXYzBTOIHAeTf;
    }

    if (NchfnVKalJec <= -1408830011) {
        for (int QWlklsaw = 686740468; QWlklsaw > 0; QWlklsaw--) {
            CDQMQkCoBuK *= lAonJjzMlgwBwz;
            rKofCwMJayDw = QvXYzBTOIHAeTf;
        }
    }

    return ZonaMP;
}

int KwMuLKqARlAkKwD::XAkTcRuy()
{
    bool qxialbkBUqXlReQ = true;
    int AdldtWSSsDFgsh = -913648474;
    double vNqYFhkS = -820874.4327058052;
    int UfpowlrYEVcxc = -1694086659;
    double wrLxnZYHiGspS = -960104.2488216953;
    double RXrbyiIdWkA = -357607.0374979219;
    bool xRpVpgrbvo = false;
    string tZAvl = string("PpzSVInSPXfGwtXsUDBwLmsNEdialRTRMtKWowRVNIeazudEpTuZeGGpSIpTTuYVBwerRkfESLgHXOnTeMr");

    if (UfpowlrYEVcxc <= -913648474) {
        for (int mxUhlNvtgmCnOp = 244531487; mxUhlNvtgmCnOp > 0; mxUhlNvtgmCnOp--) {
            continue;
        }
    }

    for (int pHNYtTMdnbUktS = 668192354; pHNYtTMdnbUktS > 0; pHNYtTMdnbUktS--) {
        RXrbyiIdWkA = vNqYFhkS;
    }

    for (int zMHoCtYJSmfyq = 775241249; zMHoCtYJSmfyq > 0; zMHoCtYJSmfyq--) {
        wrLxnZYHiGspS *= vNqYFhkS;
    }

    for (int rEqpkVFsaJQya = 63712071; rEqpkVFsaJQya > 0; rEqpkVFsaJQya--) {
        continue;
    }

    return UfpowlrYEVcxc;
}

double KwMuLKqARlAkKwD::TECOrOKeMHDEQK()
{
    double azzTGZyhELN = -326624.321186047;
    int nHNdCSDKbKv = -1306354688;

    if (azzTGZyhELN > -326624.321186047) {
        for (int pMcaycsvTc = 2103243302; pMcaycsvTc > 0; pMcaycsvTc--) {
            azzTGZyhELN += azzTGZyhELN;
        }
    }

    for (int UxhoB = 1076495379; UxhoB > 0; UxhoB--) {
        azzTGZyhELN = azzTGZyhELN;
        azzTGZyhELN += azzTGZyhELN;
        azzTGZyhELN -= azzTGZyhELN;
        azzTGZyhELN -= azzTGZyhELN;
    }

    if (azzTGZyhELN == -326624.321186047) {
        for (int HvJIWZs = 941514150; HvJIWZs > 0; HvJIWZs--) {
            azzTGZyhELN += azzTGZyhELN;
        }
    }

    return azzTGZyhELN;
}

int KwMuLKqARlAkKwD::jWgZCyamNYnTv(string KBqTlgVhU, double BTwQMf)
{
    bool ZopVjqLRi = false;

    return 1311691226;
}

bool KwMuLKqARlAkKwD::VGnUWfhbVfo(double oFQvZDDXFZ, string IyPYhrQU)
{
    string SzkDXfw = string("YRuoAMRZLfkXgeCafrIFbMGvBwZROOxfMRUPbJdovyTsvCtVEMJUfwmfrxUYyvaaxwSrvfgsNcBFHwFAMAbRFfXQGtnwjCQwAULSvGvMwEvbYspEPjkZQLgjcDbtCqCjqaviiLmdPrlvRtWImKAJEGjtOvoFKzukZuILhMMBLEJbrinOHjBavoMZebgaMHzUmcMkHIUdnLooWfisNcBaTxBoXKDjtDWUMAmJcYUVUGQHDjZRdD");
    double VqmoDfaZwADDGgg = 222972.0828043409;
    bool aHmAhKsnraVnhzt = false;
    string cYrQEpNyuxa = string("TwQfkVubPuEeOtZnaaDaTcJvpfZUIolJWUdzOXYZeDqhmGXSPWwuuxwqXNYrIFOsLorAoKpfaNfchEQgbKrEFHyCEkRrnTMviLsZd");
    int yHRLo = -1985104627;

    for (int HAkDx = 594450091; HAkDx > 0; HAkDx--) {
        SzkDXfw = SzkDXfw;
        oFQvZDDXFZ += oFQvZDDXFZ;
        cYrQEpNyuxa += IyPYhrQU;
    }

    if (VqmoDfaZwADDGgg <= 222972.0828043409) {
        for (int GZLXgcgnKSoDGzVE = 223641597; GZLXgcgnKSoDGzVE > 0; GZLXgcgnKSoDGzVE--) {
            SzkDXfw += IyPYhrQU;
        }
    }

    if (oFQvZDDXFZ == 222972.0828043409) {
        for (int xtQogOXWlsphXC = 1532643002; xtQogOXWlsphXC > 0; xtQogOXWlsphXC--) {
            IyPYhrQU += IyPYhrQU;
        }
    }

    for (int eqRGZuGlAYExDImG = 1917009571; eqRGZuGlAYExDImG > 0; eqRGZuGlAYExDImG--) {
        oFQvZDDXFZ *= VqmoDfaZwADDGgg;
        VqmoDfaZwADDGgg += VqmoDfaZwADDGgg;
    }

    return aHmAhKsnraVnhzt;
}

bool KwMuLKqARlAkKwD::HNxKaZ()
{
    bool NKtLmwqKkeaxLvf = true;
    string OYYoIYQrDtPyo = string("bGFFTXwDabiopHuINxrQsjUApQjQEISwqWqpIjRncOqrlStRBkNLoLiUgmBoTggVCu");
    int xGwkAodxAPWshhU = 1378078828;
    double uOYKBnU = 465223.68395387096;

    for (int omJjoRwnknIZLoq = 1543712255; omJjoRwnknIZLoq > 0; omJjoRwnknIZLoq--) {
        continue;
    }

    for (int ptCbWtStK = 397754800; ptCbWtStK > 0; ptCbWtStK--) {
        OYYoIYQrDtPyo += OYYoIYQrDtPyo;
    }

    return NKtLmwqKkeaxLvf;
}

bool KwMuLKqARlAkKwD::GdjDJQXzF(string CVzqCiSbhhVcG)
{
    bool CFPuap = false;
    bool uSMAsSnZnHAJBOw = true;
    string HuRQWQfWp = string("oHXcSAsMJjTWEkbHAUZnacNVFVsFjPJYVBToxQVsVTpSmmTZInLJWHohBCCVUszayBwLspQzbNPHjYUPxOxoyXPShzBjKraYslXzNBCdsvYwRopxdVItuBmcNbKXVTeNwQyKknNgCBjHXMHvDnPawDhmmXInuXmSaiMKrcYadyqnBtjaavGiqrVfpaQAvBrdrKP");
    string JJudb = string("rLgZnZnAgsPmdcuzdbuXiVEmxHuwEBhnZrZSneTGtUyAVpLPNXimqzEQNkmeVZmFqTyiEsKAzvlEiEYTcjVOjkEyCFHXQfhXkmUevotsIFEavKoYtdRoaHmkpWbgEPgIBVTeVuNCSiuRrdIRUTyJRkDByjWooiivAYopycYoPogYUxULteQIMRvngCTXBYuBRvHlqhGRIolhbizrlocuMrSuAlzkbmlUHgh");
    string WSDmRRYZtLaqbU = string("YeZeAKqgHTIpWvMDIDMtRYWRlxkZkeffPUKlDHyhnKiCPVaZLIJSRtLyjgsSlyMORijrFjAgfehhBcEOsuwHRxZPWdSPJdKwhJOIpYAWGeOwyzddjohVq");

    if (JJudb < string("rLgZnZnAgsPmdcuzdbuXiVEmxHuwEBhnZrZSneTGtUyAVpLPNXimqzEQNkmeVZmFqTyiEsKAzvlEiEYTcjVOjkEyCFHXQfhXkmUevotsIFEavKoYtdRoaHmkpWbgEPgIBVTeVuNCSiuRrdIRUTyJRkDByjWooiivAYopycYoPogYUxULteQIMRvngCTXBYuBRvHlqhGRIolhbizrlocuMrSuAlzkbmlUHgh")) {
        for (int JkdPVjG = 203368093; JkdPVjG > 0; JkdPVjG--) {
            JJudb = HuRQWQfWp;
            CFPuap = ! CFPuap;
        }
    }

    for (int EUYeoryNR = 1718917228; EUYeoryNR > 0; EUYeoryNR--) {
        JJudb += JJudb;
    }

    if (CVzqCiSbhhVcG < string("YeZeAKqgHTIpWvMDIDMtRYWRlxkZkeffPUKlDHyhnKiCPVaZLIJSRtLyjgsSlyMORijrFjAgfehhBcEOsuwHRxZPWdSPJdKwhJOIpYAWGeOwyzddjohVq")) {
        for (int cPseRe = 1777032542; cPseRe > 0; cPseRe--) {
            continue;
        }
    }

    if (uSMAsSnZnHAJBOw == false) {
        for (int KzLxLzepM = 1532793758; KzLxLzepM > 0; KzLxLzepM--) {
            JJudb += JJudb;
            CVzqCiSbhhVcG = JJudb;
            HuRQWQfWp += WSDmRRYZtLaqbU;
        }
    }

    if (JJudb == string("oHXcSAsMJjTWEkbHAUZnacNVFVsFjPJYVBToxQVsVTpSmmTZInLJWHohBCCVUszayBwLspQzbNPHjYUPxOxoyXPShzBjKraYslXzNBCdsvYwRopxdVItuBmcNbKXVTeNwQyKknNgCBjHXMHvDnPawDhmmXInuXmSaiMKrcYadyqnBtjaavGiqrVfpaQAvBrdrKP")) {
        for (int FlrDgpcvUvYhqODu = 142557037; FlrDgpcvUvYhqODu > 0; FlrDgpcvUvYhqODu--) {
            CFPuap = ! CFPuap;
            WSDmRRYZtLaqbU = HuRQWQfWp;
            JJudb = WSDmRRYZtLaqbU;
            HuRQWQfWp = HuRQWQfWp;
        }
    }

    return uSMAsSnZnHAJBOw;
}

bool KwMuLKqARlAkKwD::AoNQVe()
{
    int VwRxYFVN = -257820748;
    string mYganeAVOAOjLpkB = string("HoTWLJLrLBPViuGjNZDffIUswJpamrpMlcaaGDTJCSoCRZKMHPtFaArwoKcJaQbmsgHlwbzleAMVAKfMDkzyaFMqwZotKaOoLnLOphGFiWuEbuTSBLZHXICeposwWYfkOOdPSMmllqiYMdFAVDrcBFxyJYDeDyAJDerzgfvwdAPUjKuywWmGJeEKOPXDmSedqmte");
    int wnWHdAihruU = 941416289;
    string ccXUypoPgq = string("ZCDbvskPUZJPYZJzJkXTyXdfDAtXGvAFRKRjxtNLzUggPWzJIjZyxklCGhhcUAfTKinJAZivNWTiVJfSuqcrgyGhMXJdqZvZfdUYGWHYVYWqGpxawIBmAaR");
    double gncxVbO = 728411.3548093619;
    int PbnPjvWsyFm = 1469513070;
    bool pwvsGEzKo = true;
    double QzwMEItX = -708908.4792752118;

    if (wnWHdAihruU < -257820748) {
        for (int ZpoLbHIBBb = 705944519; ZpoLbHIBBb > 0; ZpoLbHIBBb--) {
            ccXUypoPgq = ccXUypoPgq;
            ccXUypoPgq += mYganeAVOAOjLpkB;
            pwvsGEzKo = ! pwvsGEzKo;
        }
    }

    for (int NKjCfPbAaPkAtt = 228053557; NKjCfPbAaPkAtt > 0; NKjCfPbAaPkAtt--) {
        wnWHdAihruU = wnWHdAihruU;
        pwvsGEzKo = pwvsGEzKo;
        wnWHdAihruU += VwRxYFVN;
        gncxVbO -= QzwMEItX;
    }

    if (wnWHdAihruU >= 941416289) {
        for (int phPDdx = 707085177; phPDdx > 0; phPDdx--) {
            QzwMEItX = gncxVbO;
            wnWHdAihruU -= VwRxYFVN;
        }
    }

    for (int Xaosl = 1293342172; Xaosl > 0; Xaosl--) {
        pwvsGEzKo = pwvsGEzKo;
        pwvsGEzKo = ! pwvsGEzKo;
        QzwMEItX = gncxVbO;
    }

    return pwvsGEzKo;
}

int KwMuLKqARlAkKwD::aigXcs(bool FBRFsNRniHF, string ithvjARTaBBBW)
{
    string wWuiAjeCAAv = string("kphvuldlmwFCAoEPeXPDbOXSHrJpCguRLfDZnRJIttKwCgePRHiqenarYfvzTNjqRbrAjdyysAweuRauNcgwEMRPaqEJgdRcPoWRcQalInQBgodAxdXMcWclnnDBOiwYCCMRciYMUaTYccfFoBu");
    double brqIVxNnQVDDEcB = 885050.2796097068;
    bool TbWTIkJ = true;
    bool ypAkrNmSeq = false;
    string LLTpvf = string("NljYrVALcyuEjbQFiphTZwIKraNKkpJLSJriwGOwqKRCNDZjvmOYyuCQZaQiGUrUvSaswxywKPRdzNLnRMywdAmjVDOPXVsuNqMmfhaRlZkJdoWBHAkWOJMzymWIWzWqXmEhJzuqUBUxvRGkhTbLOJKIUXnQrFYaSOYqyYrNIwbwETixBcUmPVHO");
    bool wxxada = false;
    bool fXVGZEmPhvj = false;

    return 966001451;
}

bool KwMuLKqARlAkKwD::BttxFbz(bool rVycU, double ECnWtAX, bool EPxwurdLwgQTeE, double YplQubFRm, double HkhMnfPd)
{
    double UiKWcoqtak = -658614.920326307;
    int wInzwx = -1420512613;

    if (ECnWtAX <= -658614.920326307) {
        for (int WULATysohaqpSq = 2075376889; WULATysohaqpSq > 0; WULATysohaqpSq--) {
            HkhMnfPd += YplQubFRm;
        }
    }

    if (ECnWtAX <= -658614.920326307) {
        for (int WMjGoJCg = 1983426117; WMjGoJCg > 0; WMjGoJCg--) {
            UiKWcoqtak *= HkhMnfPd;
        }
    }

    return EPxwurdLwgQTeE;
}

string KwMuLKqARlAkKwD::RiYDfuMP(bool QrxAfzzxu, double MXySAwPuNcfFbXG)
{
    bool khAfzaumkJbrjY = false;
    string NjMVpTxOJP = string("pFfGlDZmTupjrEnLhHqUfVyboBRvnBHeqdBjwsudGaPiowPToFLfDBbFtnLBgPDHFomrrWkivzHmUwGqAswNRrJHHLRPxxzTLvrFVMxRLNvgkQyiKVpZtGSXHnudHAAoCmxGcdxlKYQruMkyvCEzDrNKJxRF");

    if (MXySAwPuNcfFbXG >= -74907.21505203926) {
        for (int lMJCPQZurcsgRf = 1201797050; lMJCPQZurcsgRf > 0; lMJCPQZurcsgRf--) {
            QrxAfzzxu = QrxAfzzxu;
            NjMVpTxOJP = NjMVpTxOJP;
        }
    }

    return NjMVpTxOJP;
}

bool KwMuLKqARlAkKwD::uYoUCOsD(string vmOAOyWssvcll, double pGJkAmnyxdqGAxUk, string hSATMlGEsH, bool mDDaiw)
{
    double cXmCK = 737160.8655167839;
    string spaPRMTRvybISor = string("GLpMwvETCvqBQabekRDlQXinKXgrU");
    double DDziGAeKDuKzhXcK = 963868.4226282942;
    string fPipPITZwbATMP = string("DXblVOTDGyVSIiBLPoicAIaemSCnJsUjYHWwZcNadiKaMmYqjDJrjThWpptVWtlfCbZpzZBtZBmwztiEzRtBVcKWIvbdpFtwhMjHzSpDKrMUPGFzCGtKySFxfyGySrtkgOcFUPagpwPWjMjTmFWeqAOTsoYqKvjPUV");
    bool AaKzwOgV = false;
    bool PMgPlTM = true;
    string QJsVuzPlruJg = string("yuwOWWfKaYuvJXBoHnRqeXPcbPTxXCYnyEjtOVVdhTMeBbnKzcgDbDUPcGyGWCdbRjIbMekUqXxzjikPImuGbKddknhytqLnvasGtggkqOjIxmnJsYLJKimmIpfLTVFJbAwanE");
    string ghcLWZymUJgZUjWN = string("XGwmravZzXXBfdTtKysTGSYlrZghnLPKtzwVuFQbNJHITIAADlkSaFiswDcaUjeEQjUXOCWJhZJwnMuJRSxZKBAgrdiGcUdKKdCykDVWZGu");

    for (int dQVYzp = 632082128; dQVYzp > 0; dQVYzp--) {
        fPipPITZwbATMP = QJsVuzPlruJg;
        cXmCK *= cXmCK;
        spaPRMTRvybISor = fPipPITZwbATMP;
    }

    for (int DLfCxkomBEMS = 1769343810; DLfCxkomBEMS > 0; DLfCxkomBEMS--) {
        vmOAOyWssvcll += spaPRMTRvybISor;
    }

    for (int uSnPtucKb = 238407584; uSnPtucKb > 0; uSnPtucKb--) {
        vmOAOyWssvcll += ghcLWZymUJgZUjWN;
        fPipPITZwbATMP += fPipPITZwbATMP;
    }

    if (QJsVuzPlruJg < string("ZpGgvTVsYHdkFPmTEjsCoJsKozPttcPZcJtNEuXFczSlDF")) {
        for (int tCzpdrSQVr = 1483314205; tCzpdrSQVr > 0; tCzpdrSQVr--) {
            PMgPlTM = ! AaKzwOgV;
        }
    }

    if (DDziGAeKDuKzhXcK == 737160.8655167839) {
        for (int jlwrnlfbbWLMvfe = 2132190804; jlwrnlfbbWLMvfe > 0; jlwrnlfbbWLMvfe--) {
            ghcLWZymUJgZUjWN += ghcLWZymUJgZUjWN;
            QJsVuzPlruJg += hSATMlGEsH;
        }
    }

    return PMgPlTM;
}

string KwMuLKqARlAkKwD::YnCYOpfUAgDygEU(bool hHMxpul, double oPDwmsOhLT, int CgiybxSCLhp, double ckHTkXdyqgQmW)
{
    double KgBHEzq = 261230.95547271322;
    double XMLpDIsD = 594136.87244737;
    string GHpUpXICIo = string("WUeiPpOEIlAcfBhTYantMWaKjsIMWlwjwQhrijVaVTSmXtfncPyAzXcLcIKtgrJnjkUbOJpVmKJTFsCldaiGnZPvVCrdDkbONdcDMFuOYNOizgCCuoOBdDddvbtGSVSHSbbUVSQRVdOUKvNpoqYXFNdSWXtCSmYJKQUErusfFiRAQUOYBsDAhagnEqnEdqITnpZfKHfRrwvAOPwSSoRfabG");
    int ScReTSnNIbSgxyHM = -938845409;
    bool gXwOHyGdqqpEON = false;

    for (int UvZFSDb = 662491819; UvZFSDb > 0; UvZFSDb--) {
        XMLpDIsD += XMLpDIsD;
        KgBHEzq = ckHTkXdyqgQmW;
        hHMxpul = hHMxpul;
    }

    if (XMLpDIsD >= 261230.95547271322) {
        for (int frjBGUzf = 1126606103; frjBGUzf > 0; frjBGUzf--) {
            continue;
        }
    }

    if (ScReTSnNIbSgxyHM >= -938845409) {
        for (int AREhnbavbEdQY = 2008165335; AREhnbavbEdQY > 0; AREhnbavbEdQY--) {
            gXwOHyGdqqpEON = ! hHMxpul;
            ckHTkXdyqgQmW = ckHTkXdyqgQmW;
            CgiybxSCLhp = ScReTSnNIbSgxyHM;
            oPDwmsOhLT -= KgBHEzq;
        }
    }

    return GHpUpXICIo;
}

KwMuLKqARlAkKwD::KwMuLKqARlAkKwD()
{
    this->FxkOxmIybAa();
    this->lWbeGMBISnWddpGN(string("PjXBFffqFsGSEKrJXRKEAHvzhwYWWvOWbIMvcEzITBmIELgWQOgDEHJSeOzsHCpwwAYwZbbFifhRVrgNweRtWgdthvLNTx"), true, 1594028326, -983482.6570079487, string("ctYygYWdeQOTOemTIlFCIkkgtMoYAnigeHeCgfjWWYeWWuExwEIdzPHxmyfHVWQvmBUPspjMYaizOfxbpYacJUeWXGuhYPCtgyunykfNWLBfWUssHrjomLKglteNSwbCKD"));
    this->rLpxzdblgp(-1554501525, 1041859728, -3378.1799649771087);
    this->qOywx(true, string("pndxYZzeXmnxkiWCZGtlmqEYgLGQcjepuwGymLBkXMMHJfVBszVzosmLgQW"), -71875.03028622773);
    this->eJMumiJdk(false, 213919.32960296373, false);
    this->sbWSx(-656639909, true, string("mPjvEkJJNpDIhkqUBLpbfYQqZNOwEmCZbrRoqUzqCjRgHJKbZZAcjXGqaRGulwNcHDMeysvzGHwmMKebUVoPjzzjPYmusmgwjnxOmaxAUeefJTVZULLYLpVkbYOfHUKZzDCQPchrtficKjQwenGbZjRReUXDKfdGtiwUzSjHzBXWlgcXVNDcimLNKZRLzKmCTMqNypBXyrJAsGCbqAJUQ"));
    this->OFQsIoTH();
    this->TgILHuaezRsjM(220493.18420120078, string("lvBnCaRkPnvBDRinjsItIltOqetIuHaJsHjqsPLVwXxUugfMxfJoZdsUgXIAOQQVrFyDRyfVADNzWXuWLGBzFIrQYKUbKUtRGflzz"));
    this->XAkTcRuy();
    this->TECOrOKeMHDEQK();
    this->jWgZCyamNYnTv(string("uGUkTCpeMOKphrFfqbSIfLwdNEcSoPfhCEcIqseltoVidavzfzqYJVoNEcnMBlJYnSVKEuPWDYCRHMVpqNmdaSBaZHAlyjtJhBapKdOLAcc"), -609977.243930366);
    this->VGnUWfhbVfo(-675365.1743790264, string("eWKjhYhkEasqaQPMJUQuLOjdfDsTqnzzrvHlTUdrwinvlSLbVcesprHmgehopRGpstkJYmjjSNOTamZKeVbnqdUGVdMFXYeNHUkkOdfiZdeXCyaZCsaOkbGYSeZXUZBZWeFFihFDpxnFNHYQyBAXupOVA"));
    this->HNxKaZ();
    this->GdjDJQXzF(string("bmRwhEaodNeVgUocUVeSQstcbzQwppOWhfSIBffBf"));
    this->AoNQVe();
    this->aigXcs(true, string("gGkPEUHOrKrzyThLyJszRPSTBcYCgRvvbAGdYBNMhPrOmsOwjCsCwHqKRScoGumwwtwcqLJWZrIkEGtmIMzsYwkTehpvzHfbKdGgvXXpqwVfEyTLuqOtBhAkKOAAKRkssTwGjcINufAZwGwoprdovJkiMVLFjiwX"));
    this->BttxFbz(false, -616116.4351505482, true, 507583.34996765153, -810567.8266160634);
    this->RiYDfuMP(true, -74907.21505203926);
    this->uYoUCOsD(string("ZpGgvTVsYHdkFPmTEjsCoJsKozPttcPZcJtNEuXFczSlDF"), 848902.8133053371, string("gxdyqAflUWYxrkvNdkvJYUqNeXRqQeDPawrTdDHokQYfYMmmGdGzyKIVaAloxyhumjFiwmUoCmFtakFcUcHArfEsahGdiqVxSSwomybzSnfynsIGeoSFRTjsnmoBifLoycswVeAFAFwWHfOrxUbxeyXCFoGJOvloSzKHmqkpmqSpkkZmKuLZvelEERwtgljipFVmCIIJrZkqhlSINbCgNP"), true);
    this->YnCYOpfUAgDygEU(true, -903449.1202351202, -1912196777, -518783.9341312287);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SRVBhfcgMBBEAffj
{
public:
    int HcbydWrzUicTI;
    double PItLMNI;
    string sPdZhSsbUBAYP;
    string zWfcQPtIMuYaVFs;
    bool dFBstda;
    bool zLNeWpF;

    SRVBhfcgMBBEAffj();
    bool rYrSfDNUreB(double rZjFSMGDjAQD, double nVlWn);
protected:
    double gCbFHy;
    bool DIecYsoQYPRZUwkB;

    string SWLOjasvD(int dpTtuUwuECTPTN, bool TURTXwQ, string PlvYIZvCCxhMZpW);
    string BWzVQAzwIXNoKBdK();
    void zJrKKZpbnKeACUY(bool jnDiWh, double AMEFgyIErGXbQ, string UckBVXsReSVIkDUu, string ERxOBaaGA, bool CvWOmOBNdRT);
    bool GQZDhJqUPmX(bool JHlaSZvLXZUyvsa, bool dKochS);
    bool SbAQfcNfR(int RYgVmTs);
private:
    int vadvTaBI;
    int RgxCxdKBAkUoAq;
    string dKvIicSTnn;
    bool DKYPDHpsT;
    double TAqvYlMz;
    int LKlbpponQpJA;

    int WxGwUhrcAVrBTUX(double APBWdQmhgxRVu);
    double YMQUAgDs();
    int coauBKhylinEd(double Dwrcp, double BYybaZbcDo);
    void AGrPby();
};

bool SRVBhfcgMBBEAffj::rYrSfDNUreB(double rZjFSMGDjAQD, double nVlWn)
{
    string QZwnFYIKUDOG = string("uWGBAOZYvZtXqLoclmbIAtKeavojjevXmfCISr");
    double ZTueHL = -1014167.4256962208;
    string JspGRCsgz = string("AfEakPLoEGsnKBrTWkncaaCdU");
    int NepTQinYYt = -2070752552;

    if (rZjFSMGDjAQD < -1014167.4256962208) {
        for (int QVjRsDQwKoK = 342675592; QVjRsDQwKoK > 0; QVjRsDQwKoK--) {
            JspGRCsgz = JspGRCsgz;
        }
    }

    return true;
}

string SRVBhfcgMBBEAffj::SWLOjasvD(int dpTtuUwuECTPTN, bool TURTXwQ, string PlvYIZvCCxhMZpW)
{
    double XmzKezysBoMtf = -810599.9325111526;
    int dxLEvbNDndVn = -1617864762;
    double ygJberE = 1035342.1238414033;
    bool BltlVbGxTEBEE = false;
    int wWPZpD = -1011746988;
    bool uFdIzEvTfH = true;

    for (int oiWxk = 1010854136; oiWxk > 0; oiWxk--) {
        continue;
    }

    for (int tKONq = 598058138; tKONq > 0; tKONq--) {
        ygJberE = XmzKezysBoMtf;
        dxLEvbNDndVn *= wWPZpD;
    }

    for (int DQtehWzUYQCBGqXD = 1281559045; DQtehWzUYQCBGqXD > 0; DQtehWzUYQCBGqXD--) {
        BltlVbGxTEBEE = ! uFdIzEvTfH;
        XmzKezysBoMtf = ygJberE;
        TURTXwQ = ! BltlVbGxTEBEE;
    }

    return PlvYIZvCCxhMZpW;
}

string SRVBhfcgMBBEAffj::BWzVQAzwIXNoKBdK()
{
    string JYPyatlPL = string("OEgXHxtJfqQnNKNAXLSYZbgpklet");
    string kGJHn = string("cavAsPqAyFhhdvuyQLJqCbmutRxWdLjObefVaCtSUqdfMwdCFbpHvYExLEcgWozzlocyEBrruyXZLUrLADRAalALFpvanKwBHoQpKFcjyImSaajfsWyWUkeviutwjWdLGoYNCNthYthkcafGFjmXsUUOayQsDavvJzAZnVlQiCaEvYKNR");

    if (kGJHn <= string("cavAsPqAyFhhdvuyQLJqCbmutRxWdLjObefVaCtSUqdfMwdCFbpHvYExLEcgWozzlocyEBrruyXZLUrLADRAalALFpvanKwBHoQpKFcjyImSaajfsWyWUkeviutwjWdLGoYNCNthYthkcafGFjmXsUUOayQsDavvJzAZnVlQiCaEvYKNR")) {
        for (int vrpybRSRlvDwZ = 790527729; vrpybRSRlvDwZ > 0; vrpybRSRlvDwZ--) {
            JYPyatlPL += kGJHn;
        }
    }

    if (kGJHn >= string("cavAsPqAyFhhdvuyQLJqCbmutRxWdLjObefVaCtSUqdfMwdCFbpHvYExLEcgWozzlocyEBrruyXZLUrLADRAalALFpvanKwBHoQpKFcjyImSaajfsWyWUkeviutwjWdLGoYNCNthYthkcafGFjmXsUUOayQsDavvJzAZnVlQiCaEvYKNR")) {
        for (int bcRqKHWJhd = 467939762; bcRqKHWJhd > 0; bcRqKHWJhd--) {
            JYPyatlPL = JYPyatlPL;
            kGJHn += JYPyatlPL;
            kGJHn += kGJHn;
            JYPyatlPL = JYPyatlPL;
            JYPyatlPL = kGJHn;
            JYPyatlPL = JYPyatlPL;
            JYPyatlPL = kGJHn;
            kGJHn += JYPyatlPL;
            kGJHn += kGJHn;
            kGJHn += kGJHn;
        }
    }

    return kGJHn;
}

void SRVBhfcgMBBEAffj::zJrKKZpbnKeACUY(bool jnDiWh, double AMEFgyIErGXbQ, string UckBVXsReSVIkDUu, string ERxOBaaGA, bool CvWOmOBNdRT)
{
    int nzqJkEnhTjlHbbLh = 2000311090;
    string XYsaNavF = string("SBzNGvQMouZnOrJdNxynGFmwqwdcyjxdMEqLHPvbAKtatZCgJUasaFlaygzENBZDdjAAIBMyofOGWHzKyxFgUzXDqSqRxlVwTcniIdpRsTJwBhhwzWkQpLtDJjmNyfGgFiBqsNQfvoAWqZxdMcXQFFFHrWcdOLmGRUpBQipIasjyszsXsVTeqKZQTWodCReiiLGrLHqsgTDGIIYHOVMcjVrIjWuiPMsJYARfgad");
    bool kmfkuPVxfKXziF = false;
    int DQvyHpEMiogZEJl = 1728599422;
    bool sQYCYoDPW = false;
    double RBoNOBiCvML = 56033.438253782195;
    bool uYTuYahciKau = true;
    string IzKuaDx = string("IfkXMemNvFSwLxnVZCsgqkmFMzldDqIMgKPBkYUuwxgcdyKZYrusouOfPvlXrXhEVlOhpcYqpzODQBayFofYfouIJHMzUwkjAkCRRqPdZtTosFvgsKiVLmMtMKrnlWVprVkRIKWPwhUrdHEIPtJHTBJFCqNvrXcGPENbtPgToDHIKWFgCfhbSzVznwSXhbXMcpVGkwURNKlXcpDgQIRsJuCdwZMApZuMozevBSTbJ");
    string XaBQIPaTa = string("yFjSNkJBHpsJgDzjbqtmUWGJCEaquBeiHDoazZoZtmzEpbypyVZKnCbfmWVgQoZHoxEkKzByAdFBzvRRyYrwjZHNGwlOYVqNAtCkjEAPfHidXlY");
    string LrPnPBWw = string("YYOAKalZdeJdVAzsoyzsvhJFlUcGxQFsfWFJBVrkuIhaAyExIImmTLMSvvAeaJpqyMBkMqcVMTjnYvxgNBjFkTAMHMFeghdRjQmsHtaLIaAxVPSotiWMxpKZwCtAKuYUwCHXqAdpRzOQZSOcEYKLCZNVhgCftOOqAGyDKluBXODEmrWhaiybOYyKOSnZNkycjnfANOEINBYXzCqyCtXDQZziwHsIZupXOkCNGxZEGgHFMFvKLZHurHojQRDxXa");

    for (int iJZmmAGWeSJUXa = 1970853866; iJZmmAGWeSJUXa > 0; iJZmmAGWeSJUXa--) {
        CvWOmOBNdRT = ! kmfkuPVxfKXziF;
    }

    if (jnDiWh != false) {
        for (int OHVjycJW = 186306245; OHVjycJW > 0; OHVjycJW--) {
            RBoNOBiCvML += RBoNOBiCvML;
            ERxOBaaGA = XYsaNavF;
        }
    }

    for (int WgzsDPmS = 633310898; WgzsDPmS > 0; WgzsDPmS--) {
        IzKuaDx = XYsaNavF;
        sQYCYoDPW = ! uYTuYahciKau;
        LrPnPBWw += UckBVXsReSVIkDUu;
        UckBVXsReSVIkDUu += XaBQIPaTa;
        DQvyHpEMiogZEJl -= DQvyHpEMiogZEJl;
    }

    if (sQYCYoDPW != true) {
        for (int QeWSMiyfWRaEs = 1702164773; QeWSMiyfWRaEs > 0; QeWSMiyfWRaEs--) {
            continue;
        }
    }

    if (ERxOBaaGA > string("yFjSNkJBHpsJgDzjbqtmUWGJCEaquBeiHDoazZoZtmzEpbypyVZKnCbfmWVgQoZHoxEkKzByAdFBzvRRyYrwjZHNGwlOYVqNAtCkjEAPfHidXlY")) {
        for (int uGicuWDgVXzj = 558217178; uGicuWDgVXzj > 0; uGicuWDgVXzj--) {
            CvWOmOBNdRT = CvWOmOBNdRT;
        }
    }

    for (int GZTJhlKExyxcEpZO = 1257305312; GZTJhlKExyxcEpZO > 0; GZTJhlKExyxcEpZO--) {
        kmfkuPVxfKXziF = kmfkuPVxfKXziF;
    }
}

bool SRVBhfcgMBBEAffj::GQZDhJqUPmX(bool JHlaSZvLXZUyvsa, bool dKochS)
{
    bool XYGzMLaiGzlkW = false;
    bool UqMHEvJCmcCqNRp = true;
    bool GxKFLfekiO = false;
    int rxNjYJNwjlmBb = 1835958041;
    int SJAcnqGgMsC = -2005331074;
    bool xgPAFoqCpUXuJ = false;
    string fAcblSxGloqGMiD = string("CxuGwujKsuIXEqTbgObnMHQIyywBhzBgvFuuHlZrSQMWLKsLspyycxesXXzEXlKPLuDNvPkISXebkCzKSTpqCktmxSWGVWVofwznpCZmZxELtWjjNWvbrdFtCcSonaaCHrSQNErFpkznCSZWLZKYLbnexfIsCKMxFzhNXseefNZedEAAQCzGVUsxHUeuQTyoxumpfiYnfHBJbPkIxbGHAXdrqCgqffaNnmesYacSQSNMcOSNShkswrXehHNX");
    double dxprYFrPsxu = 544090.1642633891;
    double MLRuW = -136630.2318248794;
    double sqnGExJOKD = -628467.0592446071;

    for (int WnoMc = 120620765; WnoMc > 0; WnoMc--) {
        xgPAFoqCpUXuJ = ! XYGzMLaiGzlkW;
        MLRuW *= MLRuW;
    }

    if (XYGzMLaiGzlkW != false) {
        for (int YlmWIdM = 987325840; YlmWIdM > 0; YlmWIdM--) {
            GxKFLfekiO = ! GxKFLfekiO;
            JHlaSZvLXZUyvsa = ! GxKFLfekiO;
            UqMHEvJCmcCqNRp = ! UqMHEvJCmcCqNRp;
            GxKFLfekiO = ! XYGzMLaiGzlkW;
        }
    }

    if (dKochS == false) {
        for (int pkkwrRCdVyMHPQCd = 442058797; pkkwrRCdVyMHPQCd > 0; pkkwrRCdVyMHPQCd--) {
            SJAcnqGgMsC -= SJAcnqGgMsC;
            GxKFLfekiO = xgPAFoqCpUXuJ;
            XYGzMLaiGzlkW = dKochS;
        }
    }

    for (int DhpDo = 330781399; DhpDo > 0; DhpDo--) {
        UqMHEvJCmcCqNRp = xgPAFoqCpUXuJ;
        xgPAFoqCpUXuJ = ! XYGzMLaiGzlkW;
    }

    if (dKochS != true) {
        for (int lGjneSd = 1037463093; lGjneSd > 0; lGjneSd--) {
            XYGzMLaiGzlkW = GxKFLfekiO;
            UqMHEvJCmcCqNRp = XYGzMLaiGzlkW;
        }
    }

    for (int hEWKt = 198817444; hEWKt > 0; hEWKt--) {
        sqnGExJOKD /= sqnGExJOKD;
        GxKFLfekiO = GxKFLfekiO;
    }

    return xgPAFoqCpUXuJ;
}

bool SRVBhfcgMBBEAffj::SbAQfcNfR(int RYgVmTs)
{
    double TvGOPAnUnOvr = 532656.6226373658;

    if (TvGOPAnUnOvr <= 532656.6226373658) {
        for (int lGOVFGBCBnpp = 90642130; lGOVFGBCBnpp > 0; lGOVFGBCBnpp--) {
            continue;
        }
    }

    if (TvGOPAnUnOvr >= 532656.6226373658) {
        for (int XBEnKFqJdGaYvZ = 961393480; XBEnKFqJdGaYvZ > 0; XBEnKFqJdGaYvZ--) {
            TvGOPAnUnOvr -= TvGOPAnUnOvr;
            RYgVmTs *= RYgVmTs;
            RYgVmTs /= RYgVmTs;
            TvGOPAnUnOvr = TvGOPAnUnOvr;
            TvGOPAnUnOvr = TvGOPAnUnOvr;
            RYgVmTs += RYgVmTs;
        }
    }

    for (int mFqnuWcraI = 570041260; mFqnuWcraI > 0; mFqnuWcraI--) {
        TvGOPAnUnOvr /= TvGOPAnUnOvr;
        RYgVmTs /= RYgVmTs;
        RYgVmTs += RYgVmTs;
        RYgVmTs -= RYgVmTs;
        RYgVmTs *= RYgVmTs;
    }

    return true;
}

int SRVBhfcgMBBEAffj::WxGwUhrcAVrBTUX(double APBWdQmhgxRVu)
{
    int qSvLaTCCIn = 1756484861;
    int KuitJo = -2020850983;

    if (APBWdQmhgxRVu >= -485958.9796195645) {
        for (int lGqlxxTTpwg = 2083791395; lGqlxxTTpwg > 0; lGqlxxTTpwg--) {
            KuitJo += KuitJo;
        }
    }

    if (APBWdQmhgxRVu > -485958.9796195645) {
        for (int qVHeWYaXsWHQYjn = 1257313548; qVHeWYaXsWHQYjn > 0; qVHeWYaXsWHQYjn--) {
            KuitJo /= qSvLaTCCIn;
            qSvLaTCCIn = KuitJo;
        }
    }

    return KuitJo;
}

double SRVBhfcgMBBEAffj::YMQUAgDs()
{
    double dYZBjU = -1001950.9094576087;
    int deuHOZpSkDd = 977993139;

    for (int imGjBGrRXmN = 1913693933; imGjBGrRXmN > 0; imGjBGrRXmN--) {
        deuHOZpSkDd /= deuHOZpSkDd;
        dYZBjU -= dYZBjU;
    }

    for (int JhoxeIqdPqyxL = 1021281636; JhoxeIqdPqyxL > 0; JhoxeIqdPqyxL--) {
        dYZBjU *= dYZBjU;
    }

    for (int LcyLlGUoAg = 898955805; LcyLlGUoAg > 0; LcyLlGUoAg--) {
        deuHOZpSkDd += deuHOZpSkDd;
        dYZBjU /= dYZBjU;
        deuHOZpSkDd = deuHOZpSkDd;
    }

    return dYZBjU;
}

int SRVBhfcgMBBEAffj::coauBKhylinEd(double Dwrcp, double BYybaZbcDo)
{
    string lCpwKYMDuPzkZkCH = string("kYJekIBJXtODAiIlLlziHSQvaEZbAWcfnmgLiPYkwVryftEVzHMCFNsJDFgSkKbJlaQVfnkcDBvqBzJTwVvq");
    bool psSzp = false;
    bool bAoFDwSub = false;
    bool eItvr = true;
    bool lUpghHn = true;

    if (bAoFDwSub != false) {
        for (int FHxpWVju = 371401939; FHxpWVju > 0; FHxpWVju--) {
            eItvr = ! bAoFDwSub;
        }
    }

    if (bAoFDwSub == false) {
        for (int cvbdScuBCCd = 2016453593; cvbdScuBCCd > 0; cvbdScuBCCd--) {
            eItvr = ! psSzp;
            BYybaZbcDo -= Dwrcp;
            bAoFDwSub = ! lUpghHn;
        }
    }

    if (eItvr != false) {
        for (int KUEFYhnEbfjz = 1838635134; KUEFYhnEbfjz > 0; KUEFYhnEbfjz--) {
            lUpghHn = psSzp;
            psSzp = ! eItvr;
            eItvr = ! eItvr;
            BYybaZbcDo += BYybaZbcDo;
        }
    }

    for (int ocIxsrRsFoClFScX = 2107321784; ocIxsrRsFoClFScX > 0; ocIxsrRsFoClFScX--) {
        eItvr = ! eItvr;
    }

    for (int iroQGsK = 1917295157; iroQGsK > 0; iroQGsK--) {
        lUpghHn = ! bAoFDwSub;
        bAoFDwSub = psSzp;
    }

    for (int hfnSQZzlDz = 968658626; hfnSQZzlDz > 0; hfnSQZzlDz--) {
        continue;
    }

    for (int sttyHqYR = 2106315715; sttyHqYR > 0; sttyHqYR--) {
        psSzp = ! eItvr;
    }

    return -1469418245;
}

void SRVBhfcgMBBEAffj::AGrPby()
{
    string vdpuqPWa = string("xYbwRIYWtCDitRgWxwqKshGstvhXahJSWrNaMtIetfLfQvureMCOpIZORCZbcTAfwHeCKLUjVUoQLlNijHJUAYDnYibPiNeWQHjHWvilxSONCGXtBNuGtnlopZIOfRHxYZEecpIVAPFsOwFyyWYO");
    double bqnYGDKV = -756704.8789326847;
    int blmKZeycHukFf = -1679677488;
    bool wZvUUCzGQUYCtPNr = true;
    double IoCSESQxvzs = 907140.0255854792;
    string xWtgolSheU = string("RYUCXwNVYbFlAXHeYLXIsJDgbQLJjqAXwUjmYRPJsTNQTBGftFMoqfvRPGUNQeNKlRkqfFpNzeGcnAKlAucKQYMGCQI");

    if (blmKZeycHukFf < -1679677488) {
        for (int rtsqkWcTNNTj = 1565951711; rtsqkWcTNNTj > 0; rtsqkWcTNNTj--) {
            continue;
        }
    }

    for (int yJMvWxNXdhQExgCp = 802146628; yJMvWxNXdhQExgCp > 0; yJMvWxNXdhQExgCp--) {
        continue;
    }

    for (int UrqHK = 1544066165; UrqHK > 0; UrqHK--) {
        xWtgolSheU = xWtgolSheU;
        wZvUUCzGQUYCtPNr = wZvUUCzGQUYCtPNr;
    }

    for (int zCUvNFBTetaviH = 2020587816; zCUvNFBTetaviH > 0; zCUvNFBTetaviH--) {
        bqnYGDKV = IoCSESQxvzs;
    }
}

SRVBhfcgMBBEAffj::SRVBhfcgMBBEAffj()
{
    this->rYrSfDNUreB(-349922.94472815964, 39330.299510069126);
    this->SWLOjasvD(227117326, true, string("QolFAvbACFUtHrPayFqyhjDQcZrTS"));
    this->BWzVQAzwIXNoKBdK();
    this->zJrKKZpbnKeACUY(true, -646683.4594685767, string("ZqjqlwuaKJwyMNZHNamsABLiizkqalczXFRTKREQAwOWonZXMQelBYbBsLEIpelieRqQBJNnWXDjiIFFQaCVVuhCrRuHtLlEekEAMDVwHLvgVIuDiguMkCnhrkxLBhiZPFheGjMcyktLGTLJhevhbHLX"), string("KkqmdzkOlQWGcScFCgOMesvPamwpoTRbqBffaKbeSAYMmGXrHHxBegKffiXnKaxurOdLhTWQXAkzswUaNejiVZJvXNxZPtXxWFpKyVfDaSvyQOuHEWsPDnzsESKGsrfJZyGlKGrYRkatPRyHKKiJBhweJthNHePCMZpoBDcgAbI"), true);
    this->GQZDhJqUPmX(false, true);
    this->SbAQfcNfR(231610665);
    this->WxGwUhrcAVrBTUX(-485958.9796195645);
    this->YMQUAgDs();
    this->coauBKhylinEd(866935.5246244898, 469233.1293965596);
    this->AGrPby();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kuBGTcGWoFHGOtxr
{
public:
    bool agmrvhtjfuJASog;

    kuBGTcGWoFHGOtxr();
    int SrRpta(double ruzmdWesh, int DcJhXKyOCtrkNl, int iXRfZmeCSe, double SgMzyJk);
    bool aohtbciEbBhhxMW(int PXwEHkrMxTOOvEd);
    double zCizChwVeYTvGSF();
    double AQoNQEfwODUV(string YUsiWx, int oXvHnFayYsZRYHGE);
protected:
    string dIOBlmI;
    string LxQMmZXtVeYFJt;

    void JnluSXj(string BciCNX, int gaDMlgQaCq, bool sSFiqk, bool WCucYJGnbFIqnIjC);
private:
    bool ZNHfUIQiaMD;
    int EUqEdcng;
    double SuuNSKNAzuIcT;

    double wyxZVhGmgZqkuP(double HSZlgWmGSxsFeN, bool CuFQpjajA, bool bjlwEtKdmppY, double NGzzK);
    string vKEgGMazDL(double GkrkRHQmfL);
    string UOQmERoTia();
    double APNpSAx(string OfUpE, int UlauzvTHNUxRvf);
    void zPrVfGpeBajR();
};

int kuBGTcGWoFHGOtxr::SrRpta(double ruzmdWesh, int DcJhXKyOCtrkNl, int iXRfZmeCSe, double SgMzyJk)
{
    int KHIRTUEwO = 1106898782;
    string YBkTbz = string("YpmSqlLoTERIAVJgUrMxpweCZMCvrpZbZLfcRuCrCTekNPaNPxBBOMJSHSyAj");
    double jixJCx = -870793.0337302964;
    bool KKSLzJsRl = true;
    double QGdihCcamOdK = 384352.55168545287;
    double dAzesH = -575683.8570346418;

    for (int nFpiBKvUDUQAQhK = 1763660163; nFpiBKvUDUQAQhK > 0; nFpiBKvUDUQAQhK--) {
        SgMzyJk += SgMzyJk;
        jixJCx += jixJCx;
        iXRfZmeCSe -= KHIRTUEwO;
        dAzesH *= SgMzyJk;
        KHIRTUEwO *= KHIRTUEwO;
        iXRfZmeCSe *= KHIRTUEwO;
    }

    return KHIRTUEwO;
}

bool kuBGTcGWoFHGOtxr::aohtbciEbBhhxMW(int PXwEHkrMxTOOvEd)
{
    string gGDLgUyAIyB = string("busEPfLmnamoBBuNBKvmCPtEQOdDwOvxYZmdYtsAVLTjBCVxeCxtjnNtJDSyuxPrMRvTcmfqEhrLIXzOfeFnCaEudvOfYJRPPvaTJvPbACgVLtkyNpdqQasVEmOYEsONZNrxxjvpSZdckZzBgRdTcFUJPNUYikVmQbRutlHPBnjwfWYegqiOrXWOoCCZNdbSTdVvVMppoQliQtdLKJUuIxVjHcAPwdmiybyhfpIJevyOR");
    bool jCtVoMPm = true;
    bool mdPYXDNQr = true;

    for (int YLMwxmkHQHR = 382930816; YLMwxmkHQHR > 0; YLMwxmkHQHR--) {
        jCtVoMPm = ! mdPYXDNQr;
    }

    if (mdPYXDNQr != true) {
        for (int geIoBDDZa = 1258216167; geIoBDDZa > 0; geIoBDDZa--) {
            mdPYXDNQr = jCtVoMPm;
        }
    }

    return mdPYXDNQr;
}

double kuBGTcGWoFHGOtxr::zCizChwVeYTvGSF()
{
    double AZqnCMeIhTI = 686582.6805342518;
    bool nTvmzf = true;
    int FHOdPyq = 226138573;
    double XHpUTfzYMiNiCrJ = 172739.15306837147;
    bool zRRDqeRAkntqTRv = true;
    string gqXvQyJ = string("tUYPAByFrkIxyBWErDxNAEWvaKyfiBIGvXhwADqmaRPQHxPKCDrOJBGvvYSMRHAVoCTNWBonqhwaxydBiMvC");

    for (int oBRkWl = 1141862807; oBRkWl > 0; oBRkWl--) {
        nTvmzf = ! nTvmzf;
    }

    for (int DUQzvrvAUynw = 1916818196; DUQzvrvAUynw > 0; DUQzvrvAUynw--) {
        continue;
    }

    return XHpUTfzYMiNiCrJ;
}

double kuBGTcGWoFHGOtxr::AQoNQEfwODUV(string YUsiWx, int oXvHnFayYsZRYHGE)
{
    string DHUjP = string("yfNCSMCHvWkXrlQwOfqSOHvVwUJunpFjRluspmVJQOCOpXCggFCNREcjrB");
    double cclYYeWbbuvsTn = -1028939.012124335;
    double xNnpmCgDZoPI = 102195.1981618987;
    int yWmeS = 135441967;
    double tDpsBU = 183509.7792377941;
    bool pHHYEKSpUOMjADa = true;
    string KZFwULwy = string("oOvdzGaiszBLaxwOMmlXmHOURWTf");
    bool ykNHQsHCwKt = true;

    for (int lxheF = 641696922; lxheF > 0; lxheF--) {
        continue;
    }

    for (int cijvIr = 1446921687; cijvIr > 0; cijvIr--) {
        xNnpmCgDZoPI /= tDpsBU;
        YUsiWx = YUsiWx;
        tDpsBU -= xNnpmCgDZoPI;
        ykNHQsHCwKt = ! ykNHQsHCwKt;
    }

    for (int dQaWC = 2018806435; dQaWC > 0; dQaWC--) {
        continue;
    }

    return tDpsBU;
}

void kuBGTcGWoFHGOtxr::JnluSXj(string BciCNX, int gaDMlgQaCq, bool sSFiqk, bool WCucYJGnbFIqnIjC)
{
    double fypYmeisbvfKla = 131646.75196291454;
    int SUJjYbwrPHcnzvzQ = 992502208;
    bool bZprleKsignScmpK = false;
    double lveLDoVQoS = 143509.13485373434;
    double kouIexRIMo = 396751.35064702;
    string jLAhlsGHtI = string("jBaolNvhC");
}

double kuBGTcGWoFHGOtxr::wyxZVhGmgZqkuP(double HSZlgWmGSxsFeN, bool CuFQpjajA, bool bjlwEtKdmppY, double NGzzK)
{
    string gwsjkq = string("aIPCfBnpBEVUQIFgoioiGTOJVVeTYeCBRUNJXWezwFXkYYVknUqGbtuHkwFr");
    int OAXrtCtJhK = -2112158696;
    int ebUwRHPC = 1343277640;
    double RSkMvTnSBRz = 1003863.3009843488;
    bool bPXSaJbYQNPsiM = true;
    string lXlmS = string("LVfFWrpThBPGYGSBYmhcwgsZuPXQmQdXRKznGRqEkuiFyrrAYJUneqmVWNoAEnsmBuLXdIWzwKDKMDhqpoVudVrAs");
    string JdLHDqkWWp = string("waRqVmklXhNPQFLKwWPJFZjEpUPfVEgqFZxtjkyICAMQWVxNaboNDxYzhMcyZZtAfLsVwijaoqxqnLOcSOgaAqQYudLcsIiTmFEyAScDTHZRnYXuXcLcpOXApvEfynyoVSizwkjrAGWfTfHPyvKAIwoBWwRDGJScWBFzcFRtpzdvaViqwBkUBvWcFdZzckPFnydPkTVdErAFLjw");
    double vYaeUZUXcDjiJj = 228527.52578238462;

    for (int VEftJLVYjN = 750577447; VEftJLVYjN > 0; VEftJLVYjN--) {
        ebUwRHPC = OAXrtCtJhK;
        RSkMvTnSBRz = vYaeUZUXcDjiJj;
        RSkMvTnSBRz *= RSkMvTnSBRz;
        bjlwEtKdmppY = ! bjlwEtKdmppY;
    }

    for (int IvllXNuiXC = 555992084; IvllXNuiXC > 0; IvllXNuiXC--) {
        CuFQpjajA = bPXSaJbYQNPsiM;
    }

    for (int kMTyGNuOh = 1512686783; kMTyGNuOh > 0; kMTyGNuOh--) {
        vYaeUZUXcDjiJj *= NGzzK;
        CuFQpjajA = bPXSaJbYQNPsiM;
    }

    for (int YEGFsmHRFf = 404498707; YEGFsmHRFf > 0; YEGFsmHRFf--) {
        OAXrtCtJhK /= OAXrtCtJhK;
        bjlwEtKdmppY = ! CuFQpjajA;
    }

    for (int RZRXkBVImkLhbPRM = 1779677429; RZRXkBVImkLhbPRM > 0; RZRXkBVImkLhbPRM--) {
        RSkMvTnSBRz -= NGzzK;
        RSkMvTnSBRz -= NGzzK;
    }

    return vYaeUZUXcDjiJj;
}

string kuBGTcGWoFHGOtxr::vKEgGMazDL(double GkrkRHQmfL)
{
    string FPqWvyFlMBHvVZ = string("oZfjtQpRflHntkuBQKKRncZxhAADGtyR");
    bool UfTRJkbCDDxpROjN = false;
    int vylAovZw = -1120479711;
    bool oeiDgbKCTWoate = true;
    bool tmDzxTPYCyxCY = true;
    double ENNmhCDgN = 116007.23274241813;
    string tkUcRtrcKBo = string("toVAbEXfpqjLvOARpHwGByLFSMuRygbsujIYEfKfAvHPjxLSxovYPLoHDTqLcOyTJnUMEwSrpKNQbHHNNUDCHmtKTkWJFmFgOdHClZoKAV");

    if (tmDzxTPYCyxCY == true) {
        for (int vBmUZ = 1600249354; vBmUZ > 0; vBmUZ--) {
            continue;
        }
    }

    for (int QxWuP = 788959813; QxWuP > 0; QxWuP--) {
        tmDzxTPYCyxCY = UfTRJkbCDDxpROjN;
        oeiDgbKCTWoate = oeiDgbKCTWoate;
        oeiDgbKCTWoate = tmDzxTPYCyxCY;
        UfTRJkbCDDxpROjN = ! oeiDgbKCTWoate;
    }

    return tkUcRtrcKBo;
}

string kuBGTcGWoFHGOtxr::UOQmERoTia()
{
    string lYOHxeaPfRc = string("rQlaxdjKobOnaHYepHVtiyNAOoGLnVAstksaLybqBxHFroHsHYnyQlephmGofDModHnjvaAPTYBCXiUqHEtDTNHTerfgaYSqlDWSqQDqvNJwgLsVnrHAUwadfSSWwxLjyORVroccxzCYtMwojgGZpDkMgGuAnjdxmJCbxFCFdNIBpkZKSosOMsSadDsuBsOpozPQFyioqaGBubrzPx");
    bool IYCYyGyr = true;
    double tPcmXgo = 134336.550208324;
    double eNfvpRXcxZVlAJ = -889480.7143869799;
    bool tDkYocQrx = true;

    if (eNfvpRXcxZVlAJ == -889480.7143869799) {
        for (int bxKuw = 887378351; bxKuw > 0; bxKuw--) {
            tDkYocQrx = ! tDkYocQrx;
        }
    }

    for (int FpTVCISRhu = 1186483128; FpTVCISRhu > 0; FpTVCISRhu--) {
        lYOHxeaPfRc += lYOHxeaPfRc;
        tPcmXgo += eNfvpRXcxZVlAJ;
        eNfvpRXcxZVlAJ /= tPcmXgo;
    }

    for (int eqUzdZNRxvalm = 530454172; eqUzdZNRxvalm > 0; eqUzdZNRxvalm--) {
        eNfvpRXcxZVlAJ /= tPcmXgo;
        tPcmXgo -= tPcmXgo;
        tPcmXgo = tPcmXgo;
    }

    return lYOHxeaPfRc;
}

double kuBGTcGWoFHGOtxr::APNpSAx(string OfUpE, int UlauzvTHNUxRvf)
{
    int opVOoRHqeW = -1337671230;

    return 298531.9680008524;
}

void kuBGTcGWoFHGOtxr::zPrVfGpeBajR()
{
    double CmTIlXAVHdoIN = 909833.0439023374;
    double RvluLqobO = -192632.01707185616;
    int xsRyOalBRXQfl = -1263845155;
    string rLtSJwEEq = string("vBcWxulaFPKUhcyWoFJKDWGWqQLeasfbpQvSFeIwnJmmraimRDsyGcZwUoTYZltfcuBsuSFlNNoQJWiuPGRjnocXciMTJbQxEkgjGFJGWpLFRyLWqhEGeTDUzxoWCnwjRsisTafkQRFMtmdcqXpSiyvOHbTxpuuPBilsCpwsIBHicmtytTptkSmYuQilaXRWeU");
    double aaOzTShMpx = 647516.3584235675;
    double JCYrWGhHPKoQRzAK = -511193.70951989165;
    int mObptdWgkWQfoNqo = -1931984648;
}

kuBGTcGWoFHGOtxr::kuBGTcGWoFHGOtxr()
{
    this->SrRpta(-318916.34072750376, -1045735348, 1913513231, 99245.00466702468);
    this->aohtbciEbBhhxMW(-95607101);
    this->zCizChwVeYTvGSF();
    this->AQoNQEfwODUV(string("fRzFEAYBFhBQ"), 585500410);
    this->JnluSXj(string("XIfhASBIgcBnhPgSAxnjorRwZDMHqwDTcKLZjZXbrnBQkhuhaiwpTNIeHOeRLJYnjMqVedDCeNNWuYRVlRUJsfHtUXpkosdcnhFwkuLjDbpaTlKpqWnDBtgQcutpgKFVkNNjEnicQiuitEWlWLWFcDYSxJwvOORaptBY"), 1246137007, false, false);
    this->wyxZVhGmgZqkuP(71440.8056855695, true, true, -526025.3056321493);
    this->vKEgGMazDL(-397400.67288651044);
    this->UOQmERoTia();
    this->APNpSAx(string("EAtgGWLJVPGYdVnlMjeRmXEfomAuwPrrnBIDwTKZvbcXSnWNIzQKWnBiGaLAVEmIlgQjgEjegHLvefFSHYwFCmvjIBOnUdWjdSysIXCZeBQyyKPtJrKPMSvVMVlZjditSgeiYQYbeBebIuchwWlNft"), 611506576);
    this->zPrVfGpeBajR();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QGgecAIadh
{
public:
    string sBNcelTdwQM;
    int UlsbpA;
    double XcuRzZ;
    double IhFwQ;
    string ftnBxtGi;
    string xxTHeIZn;

    QGgecAIadh();
    int VFRkglks(double dbWifcIyQsAn);
    bool GyubrILvtYfk(string EGtrEh, double wVXbwYeN, bool UcItPYWElwmueCCe);
    string kWxcr(bool uAeppaxG);
    string sTOuDzGhjJ(double WIHrMksukEpC, double YRQtaHZMdGjQgPb, bool tJYpjhThfJBuEMl, bool qSiQBRYt);
    double CRlDuLtIRwjxiFz(double eDGulsBonw, bool DeocTqIfDRoCwFa, double taoSqg, bool edewSHNXdxoZyDA, double PFkZQMwXEUT);
    int VsIuNXWOolSb();
    void bTzCEFsNxZa(double ooqObcQlq, bool nPUlgT, bool qmCAdBf, double YaRCvNRORkzQ, double TTxqZxogkpcxrzj);
    string tdTXTIXMnq();
protected:
    int YZInDgRA;
    bool nVATZj;
    bool KYVMTz;
    double hOaINs;

    bool LJeBYp(int wICJHLYNcCfEw, bool zSWaZrL, string CNqmcP);
    int AstDPNUoyXCQHNR(bool yXTeyizFhuGJa);
    int FIwJHTX(bool rsvYFYbn, string DTpDzJWusKPcaZ, bool oEWGxjzGEgglcbH, double rzHQd);
    void MxlFrxJn(int sfXZxheHFiPshAe, string CDshw, int uXqZzNsgao);
    void XeCwmzziy();
    int wHAWriQL(int YnllBloZvfI);
private:
    string dvTXbZv;

    int IwRJlS();
    void yXgswGpjoBcSETFT(string MzGQObDwMtKmC, double OqBOeDjMLhQHCRZ);
    bool jLqjCUL(bool MdYPQ, bool pSfOWDnIIoTBX);
    void MFdBnEdlMMpKee();
    double cRqcSwXYjEAkA();
    bool gYthL(bool NBtPKiSZWSKTQaie);
    void BrAHDzKWvqFaN(string rTpIYqkEluCFd, int XAoQpinlSlMToYcD);
    bool QudPAT(bool ViHMV);
};

int QGgecAIadh::VFRkglks(double dbWifcIyQsAn)
{
    bool WnRwagEnDse = true;
    bool Xqswhv = true;
    double pWXVwqOw = 787268.8704205177;
    double yIpuG = -751119.3092795534;
    int PVDjmFi = -2018764113;

    for (int pfXKClVE = 111080467; pfXKClVE > 0; pfXKClVE--) {
        dbWifcIyQsAn /= dbWifcIyQsAn;
        yIpuG *= dbWifcIyQsAn;
    }

    if (WnRwagEnDse == true) {
        for (int ZvRyLisgYAhAi = 348426104; ZvRyLisgYAhAi > 0; ZvRyLisgYAhAi--) {
            continue;
        }
    }

    for (int ZOFQVCjrTUwmNvzg = 802041707; ZOFQVCjrTUwmNvzg > 0; ZOFQVCjrTUwmNvzg--) {
        yIpuG -= yIpuG;
        yIpuG /= dbWifcIyQsAn;
        yIpuG -= yIpuG;
        pWXVwqOw *= yIpuG;
        Xqswhv = ! WnRwagEnDse;
    }

    if (yIpuG == -751119.3092795534) {
        for (int HcPZzagIiWB = 1156249884; HcPZzagIiWB > 0; HcPZzagIiWB--) {
            dbWifcIyQsAn *= dbWifcIyQsAn;
            yIpuG *= yIpuG;
            dbWifcIyQsAn *= dbWifcIyQsAn;
            dbWifcIyQsAn /= dbWifcIyQsAn;
        }
    }

    if (yIpuG <= 1003271.5532154966) {
        for (int gvHYEZ = 964804108; gvHYEZ > 0; gvHYEZ--) {
            dbWifcIyQsAn += dbWifcIyQsAn;
            PVDjmFi /= PVDjmFi;
            dbWifcIyQsAn /= pWXVwqOw;
        }
    }

    return PVDjmFi;
}

bool QGgecAIadh::GyubrILvtYfk(string EGtrEh, double wVXbwYeN, bool UcItPYWElwmueCCe)
{
    bool IXAFfZDqM = false;

    for (int IQlTQNQEIx = 2019071674; IQlTQNQEIx > 0; IQlTQNQEIx--) {
        IXAFfZDqM = IXAFfZDqM;
        wVXbwYeN *= wVXbwYeN;
    }

    for (int IJMdKYqF = 978521042; IJMdKYqF > 0; IJMdKYqF--) {
        continue;
    }

    return IXAFfZDqM;
}

string QGgecAIadh::kWxcr(bool uAeppaxG)
{
    bool RGzHCoTiLQ = false;
    string OhaanCAPH = string("XcMcKWpRSvqbOAqEhmQNQJvmDaXwvDdzRUdogZbinmNFBOcSQQmuQrwHuljRpBCXijaBxTutpDvSavUAVibFllDsFerzecnMwAYZqepqPXgpLiRRrKWHhEIuOFaV");
    bool WjeorghKsi = false;
    double EEUOtlIv = -288546.66868233064;
    double jNKzEKyg = -146502.29598905664;
    int nrpQyBsiyOttu = 1239046734;
    bool lxjRzjX = false;

    for (int ixzNNWzYAAt = 1941103799; ixzNNWzYAAt > 0; ixzNNWzYAAt--) {
        WjeorghKsi = WjeorghKsi;
        RGzHCoTiLQ = ! lxjRzjX;
        RGzHCoTiLQ = WjeorghKsi;
    }

    for (int tfvbe = 819874008; tfvbe > 0; tfvbe--) {
        uAeppaxG = ! WjeorghKsi;
    }

    if (nrpQyBsiyOttu > 1239046734) {
        for (int qLhceBfk = 1061348634; qLhceBfk > 0; qLhceBfk--) {
            WjeorghKsi = RGzHCoTiLQ;
            jNKzEKyg += EEUOtlIv;
            EEUOtlIv -= jNKzEKyg;
        }
    }

    for (int rAVQFhbKQRkXIBA = 1071960556; rAVQFhbKQRkXIBA > 0; rAVQFhbKQRkXIBA--) {
        RGzHCoTiLQ = ! uAeppaxG;
        lxjRzjX = WjeorghKsi;
        EEUOtlIv *= EEUOtlIv;
        jNKzEKyg += jNKzEKyg;
        lxjRzjX = ! uAeppaxG;
    }

    return OhaanCAPH;
}

string QGgecAIadh::sTOuDzGhjJ(double WIHrMksukEpC, double YRQtaHZMdGjQgPb, bool tJYpjhThfJBuEMl, bool qSiQBRYt)
{
    bool EBEYqGzRWr = true;
    string kvKxPKnTcnCv = string("DOuHERXpMBewQrCtbYQNWXICcJOWxNmAduMZiPXeKRhBITXGRpfXBKURKbLuBkHLWSMmgiYjnQBvKKjyulBlZOnzkZSNFlwayawHnxpEDkNlNHNPkiNAGvVrhrDWALflIoXUbARwSnRylUkwnUaLgyrHMVCJRvDmPJObVzFuqZEPHgJBpN");

    return kvKxPKnTcnCv;
}

double QGgecAIadh::CRlDuLtIRwjxiFz(double eDGulsBonw, bool DeocTqIfDRoCwFa, double taoSqg, bool edewSHNXdxoZyDA, double PFkZQMwXEUT)
{
    string GsoGZ = string("AgaqPvALLgBnocRAToEktzSxoZYRSWBAvYqJghrHyWSKXyWddVsMsVojjhhxAeJLeficNKNpFpPVTNEjxIzZwX");

    if (taoSqg > 323042.385937913) {
        for (int CNVam = 1505062187; CNVam > 0; CNVam--) {
            GsoGZ += GsoGZ;
            PFkZQMwXEUT /= taoSqg;
            eDGulsBonw *= eDGulsBonw;
            PFkZQMwXEUT += eDGulsBonw;
        }
    }

    for (int WzbBGQ = 393171266; WzbBGQ > 0; WzbBGQ--) {
        continue;
    }

    for (int inaIryoOvEEr = 346870849; inaIryoOvEEr > 0; inaIryoOvEEr--) {
        DeocTqIfDRoCwFa = ! DeocTqIfDRoCwFa;
        taoSqg *= PFkZQMwXEUT;
        edewSHNXdxoZyDA = DeocTqIfDRoCwFa;
        eDGulsBonw += taoSqg;
    }

    return PFkZQMwXEUT;
}

int QGgecAIadh::VsIuNXWOolSb()
{
    int sivKlHH = -722669689;
    double bwJcbRviOrjJGu = -833396.5228392794;
    string MIcerdBuHPMV = string("JTZNEYtGrylmSzrpBlWHYhBAMUdbMAerrxpYbvEeSBJXjgIJfMEqzLhrWNguJMZRxZPYxcwOQhsenrIRJpZgqitKHfhcIcgmGYEECKFVBFvqlSdCrRdPhqVOPQzFdMoP");
    bool FwuNHLLtA = false;
    double cXIGUNaiaQm = -868987.7096010952;
    string RstqfLMsJG = string("PaVgkfJbIxIVtTJqLPNGfLyVDwbfAcGLiKBLLYKuPatjMhfkIqjklQxMwkinzHoPQtszEecPYKzYvPTPpiovrEzYstuDNDydhfoCPNbVyXkdqwKLZELOLrTCPQZGJxlnoUILyZOXbgaHqmjdjFnTsbheeXbKabbhAijhNJxpCyxefiyvPX");
    int ZCAudHWLzoO = 823578009;
    bool bcXkfLSSDkZn = false;
    string OzYEoQznNTTxLzV = string("pEYHeeVohwBOIDbYKxaZrOtVaqzdkxwUBJHoCfgKcksASsfjgYyoVSpVMmbbCklHEFbCBTvKvMPBOpLBAwSiXdKtQvbEviAInvoanfEqpAUzgSndjltrMnemwBZPEFNutewQxLhVhsqnnOhdCrquVwSCXimIugYFBMpXzIxGaLAdNOjeFgGlQrxwFKrvTpuKTxTfgFztGKAfcIHIBOqEKrmqtnrtqtvNBcRZBpQnLoMqQkiVH");

    return ZCAudHWLzoO;
}

void QGgecAIadh::bTzCEFsNxZa(double ooqObcQlq, bool nPUlgT, bool qmCAdBf, double YaRCvNRORkzQ, double TTxqZxogkpcxrzj)
{
    double kDkHXjJYsK = -708528.2545327623;
    string YrORrHNjGEwQYOug = string("jhignycGjmKuTXPPVtiRSyLUPbGvPAmqtwiIRtmq");
    string wJrPMCeOFKwWAaR = string("NJRYMUQdPGsdJcfcTufynWStwtMFMYhHunRxqSAXhHKnyIWBrT");
    string xwksxL = string("lBJfmuhJehIkDoQRKbhLEjNMonyQtjmVsQFteGZrmYDbHpxRroymWwTklYapsuzuhtmNIXDlEuvSLtlLCgNgfJLhjFxuYQDXC");
    double rERGKzvftYURkB = 43555.43611199616;

    for (int INUcayxtZhY = 1515026557; INUcayxtZhY > 0; INUcayxtZhY--) {
        rERGKzvftYURkB += rERGKzvftYURkB;
        TTxqZxogkpcxrzj /= rERGKzvftYURkB;
        rERGKzvftYURkB = TTxqZxogkpcxrzj;
        nPUlgT = ! qmCAdBf;
    }

    for (int LBdblqnZSKFLg = 269243815; LBdblqnZSKFLg > 0; LBdblqnZSKFLg--) {
        rERGKzvftYURkB += rERGKzvftYURkB;
        wJrPMCeOFKwWAaR = xwksxL;
        ooqObcQlq = rERGKzvftYURkB;
        TTxqZxogkpcxrzj /= TTxqZxogkpcxrzj;
        nPUlgT = ! qmCAdBf;
        ooqObcQlq += kDkHXjJYsK;
    }

    for (int ihuWOYH = 1291551078; ihuWOYH > 0; ihuWOYH--) {
        qmCAdBf = nPUlgT;
        YaRCvNRORkzQ -= YaRCvNRORkzQ;
    }
}

string QGgecAIadh::tdTXTIXMnq()
{
    string lPPpjuFrVF = string("yrlZVVqimZLvKrfhpLGexiTohGbXASAdtPOdYDOEkMmVbmSgDvrYKlWGdbrULmdWZNaPGWQwhyAWmaYDvyeXXuohJwCwCRByHWLEEUjejdQawUzuTKDtpQmfHiPOcWzokcKAgjbudhuKqBtACDbzIGBSJxmenRRlYiZnHXNbIevXPhNfK");
    int mmgROqEiVNKcmf = 927779464;
    double uAZLpIShJjQI = 309674.10158155684;
    int qQDcIiuHBOu = 1526333911;
    double zWBQwE = 543134.6372929206;

    for (int TFFMsGVEyRPkYT = 1015560305; TFFMsGVEyRPkYT > 0; TFFMsGVEyRPkYT--) {
        lPPpjuFrVF = lPPpjuFrVF;
        qQDcIiuHBOu /= qQDcIiuHBOu;
    }

    for (int yOYES = 287881016; yOYES > 0; yOYES--) {
        uAZLpIShJjQI += uAZLpIShJjQI;
    }

    return lPPpjuFrVF;
}

bool QGgecAIadh::LJeBYp(int wICJHLYNcCfEw, bool zSWaZrL, string CNqmcP)
{
    string VUvzUcDgnxkmFDf = string("etExdNSwtFZJMRjqOGGrXMEsxfMqJsTyJKJwBycYCJBgstBxjomLzVYARWAozTAdeznkpvJfawSyKDJmpNwCYAsxaxIglEuavCZcMTKpXmGnVEqeNytpmIQEQEIwzvbfYupzVHYyQvpcfMvsAFArUfXloNGYMu");
    int KehJxAISQ = 282242597;
    double esOSjbrgReS = -196533.33220155168;
    double IYcwNRqFj = -475546.75295525015;
    int LyEDwCFbGYsvdj = -1925096192;
    bool MRPAURbYWKJjf = true;
    int nAgJpArX = -2101004696;
    bool UhEChNGcE = false;

    if (CNqmcP >= string("etExdNSwtFZJMRjqOGGrXMEsxfMqJsTyJKJwBycYCJBgstBxjomLzVYARWAozTAdeznkpvJfawSyKDJmpNwCYAsxaxIglEuavCZcMTKpXmGnVEqeNytpmIQEQEIwzvbfYupzVHYyQvpcfMvsAFArUfXloNGYMu")) {
        for (int ctbCVuOqtGQ = 514629964; ctbCVuOqtGQ > 0; ctbCVuOqtGQ--) {
            continue;
        }
    }

    for (int GfbChzgkMEuLwOYx = 1259676704; GfbChzgkMEuLwOYx > 0; GfbChzgkMEuLwOYx--) {
        zSWaZrL = ! UhEChNGcE;
        MRPAURbYWKJjf = ! MRPAURbYWKJjf;
        zSWaZrL = ! zSWaZrL;
    }

    return UhEChNGcE;
}

int QGgecAIadh::AstDPNUoyXCQHNR(bool yXTeyizFhuGJa)
{
    int wssuYNYNVTn = -1492292427;
    string IIMqe = string("lbaCkegNtFYLuMrWdWLDrSdgQwOMVLjfLThRMmFGrrrESchTiGoeqdWQjrLbaargjbyPQzOpCaPYqkJNDctyTyRyFfpuqBBPpIXqfAaIXZfUhVJpknSpdiveZxNwfWPebGWZpBrcFDwHryUvdEYOUcNsRDkbpxNPAEPDgXsRBRmvIuyWyQgqnOyICEObeMDfMBwNirtxUiFtCKulOaAobQxKrKhQsyrBIuakwTVTIRXqiGBYMvvvuyLnPWqBL");
    string CllIWnBcAWY = string("CudfdiRvofriRJOBKmzhXhRATPeBOchMRNoUn");
    bool jMuxJXRFbVGx = false;
    int fGFRF = 1961994461;
    bool qelXoj = true;
    string gMsXQYSROKyhx = string("RAjydjsVqBTJulNMwDMyOxzglADMiLRNUEujEFfRdzboLOBljqkLBTJgBhziMtCbMHqXPBltupAbkJfYCePAMpwXKBRPpyVDvEVtRSJzMnZmmQDtJjtylZygxyoMsNgYSDZAPILsYjLoVBabPDESujqyLTuMILNHAlbuYiG");
    bool tGyXxNf = false;

    return fGFRF;
}

int QGgecAIadh::FIwJHTX(bool rsvYFYbn, string DTpDzJWusKPcaZ, bool oEWGxjzGEgglcbH, double rzHQd)
{
    int AowJuA = -945882119;
    double koLkd = -38920.84766212157;
    string XghjPpqta = string("YcMxbRuAERtOJDTmGMaPSGcRQnKgOdcxymNnktDfvifLnghFvHfZgGQLqHAHERupQChKMWplPiUDXKHeFJmbxfGWmaTqEfASsiheSJyFXHwkEh");
    bool fNvpWFl = false;
    bool jmkonMJ = false;

    for (int JPSBISOtEZMVbkeS = 1295518510; JPSBISOtEZMVbkeS > 0; JPSBISOtEZMVbkeS--) {
        rsvYFYbn = jmkonMJ;
        XghjPpqta = DTpDzJWusKPcaZ;
    }

    for (int MzuIulTtjkT = 355576367; MzuIulTtjkT > 0; MzuIulTtjkT--) {
        continue;
    }

    return AowJuA;
}

void QGgecAIadh::MxlFrxJn(int sfXZxheHFiPshAe, string CDshw, int uXqZzNsgao)
{
    double hrMXkdTsBTKsrzNi = 302045.1638397238;
    string KauRkRbhpTfhuaa = string("QGWmUfQmFFBTdqPirgBhaFhkmlpVTnLQObNOOWopOYgBVRXoSAKVFTjJrwTpDxBFLHQASoLtQBbEEEFpfVIEonvrgnRDCiMcOFQBDhUpxlMHnORfDQaYpjMaJXUBvJAQUsBcL");
    bool huiSvQMVI = false;
    string FRBpmkc = string("TAvopvDgTVvzJERGnLqXrhsBJuBINGcgMvgeZKexoVtVHlfrQQVXcoxWIIPbssFofPzBbvOCRtXSyzJTsNIsffuHumHxxBpDSGkAhCFDtPakPTyPJUSuwBsWtraCWaUROhlNaZkArupaenuswglCgOcDCFsMfkqEVEGolvhlUtHIQkAxIZSrEUuBqMnMqLUUyQfwgdVYzQcaCinYacKFfsUBSFsYCIlPWAWbhXSFBDfAnybtpoKwjWbCOcuWBZ");
    string tCdXT = string("ZIOrwIZUjZxQGgsl");
    string aitLriSDhSNso = string("UOykkkoBkEkEEchmHOoIdSxXNNvAnnqSEZKXFuPjEZpPHBmOfNSaPjMNOzYGxkAIfDGqUistnHiIgpbVzIaFJpepDIzgjWLqLdfdetjSYDFRrlMeOSTEINlsfNzqzDXwNtEkVGPrluuiwNnIkiNdfASbMTIzJzIzmSFIRGVCTVkRUwCVTKcOMkaKOiiXeNFMifwhmFVXKyiSRMIHBjQelvZZaAnsBZgsgThw");
    string jAzssjjWhXsJxFC = string("QAykAHflwRpDQoLrnylURdeHEggjRvwFHwNrEGYTBCFvronQHhmiIeeTGpeeEWgHjqdBUvFVzNzJRTtLHdAJaSeReVHUkcjnnJLNiLxOuHkqzQHQRTZmAOznZjtLkMvlXCQXiAWRavOGaSIHdFXbHCQDMmnGLBMQzIjxQCtTfUJviSBbBCybjFEYUNgzwcBMmUPUqIcJfhcexkrIRMWszxlxxJROCQQqvkSsrfShAFeLrEPVIbJV");
    bool PZeXwFPeSGrWpc = true;

    for (int XSbhmiwnWEvnCqYf = 1052916361; XSbhmiwnWEvnCqYf > 0; XSbhmiwnWEvnCqYf--) {
        tCdXT += tCdXT;
    }
}

void QGgecAIadh::XeCwmzziy()
{
    bool VgLDlbtme = true;
    double kRFKbRIOuqy = -405014.6780252097;
    int BhxuXaYGnCVUssIw = -500487041;
    double oxBtZ = -970702.1778016732;
    int HfjpRIHeUQcyqmX = -1330256283;
    double NGZyZLNNNY = -891289.8170240793;

    if (oxBtZ > -891289.8170240793) {
        for (int xgUeHAfpYZ = 2114994039; xgUeHAfpYZ > 0; xgUeHAfpYZ--) {
            oxBtZ *= NGZyZLNNNY;
        }
    }

    for (int OijdXRDnkp = 1515183; OijdXRDnkp > 0; OijdXRDnkp--) {
        kRFKbRIOuqy -= oxBtZ;
        kRFKbRIOuqy += NGZyZLNNNY;
    }

    for (int wSWDMhHuS = 630107180; wSWDMhHuS > 0; wSWDMhHuS--) {
        NGZyZLNNNY -= kRFKbRIOuqy;
        kRFKbRIOuqy += NGZyZLNNNY;
    }

    if (kRFKbRIOuqy < -405014.6780252097) {
        for (int QSfDJz = 1562815535; QSfDJz > 0; QSfDJz--) {
            BhxuXaYGnCVUssIw /= BhxuXaYGnCVUssIw;
        }
    }

    if (NGZyZLNNNY > -891289.8170240793) {
        for (int ZSnruEnSDW = 68663107; ZSnruEnSDW > 0; ZSnruEnSDW--) {
            BhxuXaYGnCVUssIw += BhxuXaYGnCVUssIw;
            kRFKbRIOuqy -= NGZyZLNNNY;
        }
    }
}

int QGgecAIadh::wHAWriQL(int YnllBloZvfI)
{
    double BMXMrS = -998291.5047106701;
    double uVMyyAYWOeprnkzn = 388441.3918501911;
    string uEiQwIlSqT = string("QeXwMAFxKYuBagcKxlHyyNklYGDIwpBHiqeMocaNekMExGPRkXbwaasSLhyF");
    int DjTokOd = -1277126171;
    string TICWUgWiJJRAhAZ = string("zTrduWdGFqjbeiLviNvdosPdmSpZwPKQfVHFrSrIVCfrPIciAOUlBwvniIdZvClZTXXLpmEmPfQtTWjKlTFjzxhqBbGoBwpfyEBTmeuZplQ");
    int mFkRDXYjTal = 1112323337;
    double dojvuQlwMRHz = 904370.0719623601;
    string HIkQSThfpmelyNB = string("oYEmjIOxuzCdXmWJQuCynocKyEJMoUClMYzBppbcHpssyDVeInQIeOBKVLbaOZJIWaBTaBDXGCBkcBTHLBACiVjBozmPfEXhLxUORhkXRcWoSGJGUFsKrCcTWOLvgjcIsDuFFzyUFRiQptMbdEQppXzWEFLlbpEYNdJTt");

    return mFkRDXYjTal;
}

int QGgecAIadh::IwRJlS()
{
    bool ipRiBUYsbUaS = true;
    double PcRkMid = 698088.7433728159;

    if (PcRkMid == 698088.7433728159) {
        for (int Voclnqzmws = 1159691310; Voclnqzmws > 0; Voclnqzmws--) {
            PcRkMid /= PcRkMid;
            ipRiBUYsbUaS = ipRiBUYsbUaS;
        }
    }

    if (PcRkMid < 698088.7433728159) {
        for (int uxngNjIPEbMES = 1006498818; uxngNjIPEbMES > 0; uxngNjIPEbMES--) {
            PcRkMid += PcRkMid;
            ipRiBUYsbUaS = ! ipRiBUYsbUaS;
            ipRiBUYsbUaS = ipRiBUYsbUaS;
            PcRkMid *= PcRkMid;
            PcRkMid += PcRkMid;
        }
    }

    if (ipRiBUYsbUaS == true) {
        for (int lZurBRf = 301298987; lZurBRf > 0; lZurBRf--) {
            PcRkMid = PcRkMid;
            PcRkMid *= PcRkMid;
            ipRiBUYsbUaS = ipRiBUYsbUaS;
        }
    }

    for (int vJSfQMggbBtM = 11445219; vJSfQMggbBtM > 0; vJSfQMggbBtM--) {
        PcRkMid *= PcRkMid;
        ipRiBUYsbUaS = ! ipRiBUYsbUaS;
        ipRiBUYsbUaS = ! ipRiBUYsbUaS;
        PcRkMid = PcRkMid;
        ipRiBUYsbUaS = ! ipRiBUYsbUaS;
    }

    return 724961343;
}

void QGgecAIadh::yXgswGpjoBcSETFT(string MzGQObDwMtKmC, double OqBOeDjMLhQHCRZ)
{
    bool bUNRsdQS = true;
    bool HocjHbFRdAgzcP = false;
    int FttyxhfmjjhkFfc = 745244434;
    string iDmCVR = string("lYbNSqWySgGjVUGYtyBdgMPhRbrMABGDWbGgfPxtVaFUxqoYKsheDytnTCGtTPOziKEaxYaZMnmNOoRoCvmywaNanNrpkPdWyTNNppHUIuZktIwsXklQsHrZWaKlnxyILpKimMVnWuW");

    for (int jIHuxQtFMlkH = 142764551; jIHuxQtFMlkH > 0; jIHuxQtFMlkH--) {
        iDmCVR += iDmCVR;
    }
}

bool QGgecAIadh::jLqjCUL(bool MdYPQ, bool pSfOWDnIIoTBX)
{
    string qNNCjATD = string("JJdGyhdetWlxcmpKOwQLWRlSgaHsgGcYEodEnXzfdoEboCsdKYqTdVwUVFdsAzgGHiuajGEPOUvlEAfAvWqRlShg");
    string QIukgYLJbuilwo = string("atvyLPiSsNqHVubfEgsSotJYQJJooDEYfMUlytvpkRDHLlbuM");
    int egpNyjpOG = 1749845704;

    for (int SmDlUZUG = 2056108086; SmDlUZUG > 0; SmDlUZUG--) {
        QIukgYLJbuilwo += QIukgYLJbuilwo;
        MdYPQ = pSfOWDnIIoTBX;
        qNNCjATD += QIukgYLJbuilwo;
    }

    for (int JLNupevGwzT = 1991553200; JLNupevGwzT > 0; JLNupevGwzT--) {
        qNNCjATD = qNNCjATD;
        QIukgYLJbuilwo += qNNCjATD;
    }

    for (int iZRayPgbH = 782684655; iZRayPgbH > 0; iZRayPgbH--) {
        pSfOWDnIIoTBX = ! MdYPQ;
        pSfOWDnIIoTBX = ! pSfOWDnIIoTBX;
        pSfOWDnIIoTBX = pSfOWDnIIoTBX;
    }

    return pSfOWDnIIoTBX;
}

void QGgecAIadh::MFdBnEdlMMpKee()
{
    double LtXuvoQNtqQ = -639441.3086636645;
    int flRkhY = 523266838;
    bool chDtqKFt = false;
    string BScIEwFMnMZgvwPn = string("jPmKapTKxiYsjREPxBvzKwsIQZngtrLsrHASxlyzMCAFFpLHTErpbJsWlKDpoGftRiyQOyyvrdKIDxlmYoxQFaJFflfgVBhcs");
    int URXJRnZkRNKsAmE = 507156023;
    double MutIPJTvAMqmN = 549299.6305312995;
    int XntKTtnNJFfgToo = -753313718;

    for (int xTLRnSPkIshcyyy = 376369562; xTLRnSPkIshcyyy > 0; xTLRnSPkIshcyyy--) {
        flRkhY += flRkhY;
        BScIEwFMnMZgvwPn += BScIEwFMnMZgvwPn;
    }

    if (flRkhY < 507156023) {
        for (int rFLVAHz = 2136934244; rFLVAHz > 0; rFLVAHz--) {
            XntKTtnNJFfgToo *= URXJRnZkRNKsAmE;
            URXJRnZkRNKsAmE /= flRkhY;
        }
    }

    if (flRkhY > -753313718) {
        for (int CsoCJLKsN = 500556271; CsoCJLKsN > 0; CsoCJLKsN--) {
            LtXuvoQNtqQ -= LtXuvoQNtqQ;
        }
    }
}

double QGgecAIadh::cRqcSwXYjEAkA()
{
    bool SePmqWSYCuIS = true;
    string zOrTDNXYbz = string("lsFTvPGpfVbGnYLVJkJUZguYvhXNmJUpDrEUYViiBIcACvZLgagxzpxWPtOKdsuhoOjEgoJbGSJuhyEgkKRcIHqrIfKBbHpUmLnXVDksZDEosbSVXQeLQZNifUAlsjLywIaFRKgrQzFGakympNUnbKXzrvJPXAsAxAnybGQgpVShUATmWJgjfZzxqOrQnFJgFQoXyztQRPSPCXyBYQcDbVlQYzOFrMWlkHeriBjlje");
    string hChrfFg = string("bwtmEhShTxESyawQ");
    double BvfQRnuWpyHxKJ = 792679.0592167603;
    int dojZxEAPKONRUnf = 406609178;
    int qPVGaDksyDIRZC = 151295436;
    string QzZYHawO = string("cqfaOhbUNwuJdZZFjjWoYPuagoPFTlJwmiJbRVYEcQckQpFKtsmKPhSRaeLrdvbzaJkNvvJNheAmJiHzLa");

    for (int KSUAgwVoPOsYz = 1694587403; KSUAgwVoPOsYz > 0; KSUAgwVoPOsYz--) {
        qPVGaDksyDIRZC /= dojZxEAPKONRUnf;
        zOrTDNXYbz += zOrTDNXYbz;
    }

    return BvfQRnuWpyHxKJ;
}

bool QGgecAIadh::gYthL(bool NBtPKiSZWSKTQaie)
{
    string OFMeokew = string("rOIAwTgjBYhcqmc");
    int zbhOpT = 2107400517;
    double SKYGMdPRYtAtuqE = -181468.35824820536;
    string YEWetzxgpqBLvNM = string("LnYFtgVdpSXnoOeifyEuyrWgmHRymEAWwMuyeeqLycnkfusSXnhxcIUNiNgslxyqDxiUBKhcVGebB");
    double hsPzr = -566083.8270013607;
    int cNULE = 450784244;
    double RMAJTtOhm = 580471.6511421718;
    string UJcfRzjfbMSkObO = string("MtBsCCRZayZbINMbeZmLcuLXEIhnuxQixHGXLJzebtDuvvPrPAornnnqEkZtxodEVZMCiOxMdMlbcjAKmwabzFtvpTbKoDMlYhvqWCfmcqdpGngRMmVZUynrRTWpiocIojIobpsbcFUtibxICxljVZkSroSJiaDitYckwaCepif");
    int AWAVKxSl = -1476221436;
    string IPkTcJeFvaBKw = string("uowkYpLFxWibziCuBCCXnFTiuOviqbCQNnoCDsdblzaHNqhevxdyMYSnKTVOinyDxHTfYwcQMrMDVYtXWvprwmaRbDlPUoUSTyyiynmgzMmatCxJiRgAoZpfmVMHDmDSrZfWcycqOfOWOHnkLVhnhHxpjhbQwnhHmQEgwguDcrrtjnKepVlOkmHiQfziLanFCHzJpZebRJodVZaNtLUTyAJAELgUvxCtbIJPjRPfgLxgOqH");

    for (int CYUYzpmnpTw = 1448746671; CYUYzpmnpTw > 0; CYUYzpmnpTw--) {
        continue;
    }

    for (int ZQYhzsUwQFMlngpf = 2036107210; ZQYhzsUwQFMlngpf > 0; ZQYhzsUwQFMlngpf--) {
        UJcfRzjfbMSkObO += UJcfRzjfbMSkObO;
        OFMeokew += OFMeokew;
    }

    for (int rBQRxvspJtZC = 345066123; rBQRxvspJtZC > 0; rBQRxvspJtZC--) {
        continue;
    }

    for (int emSwl = 731755227; emSwl > 0; emSwl--) {
        YEWetzxgpqBLvNM += YEWetzxgpqBLvNM;
        AWAVKxSl = AWAVKxSl;
    }

    return NBtPKiSZWSKTQaie;
}

void QGgecAIadh::BrAHDzKWvqFaN(string rTpIYqkEluCFd, int XAoQpinlSlMToYcD)
{
    int nHSIYqyIbt = 1018056868;
    double FhBAqkrizmHVdbRG = 463758.44194654084;
    int waLCHJkx = -793302540;
    string jFuVQUPlNSsxcM = string("MEWcPjoCcKGyH");
    int NYMsfxvVcGPx = -302094547;
    int KMEoMgNoEpf = 222671447;
    bool PwjhB = false;

    if (waLCHJkx > -793302540) {
        for (int NOwnvYqfNmBbIP = 450200956; NOwnvYqfNmBbIP > 0; NOwnvYqfNmBbIP--) {
            KMEoMgNoEpf += waLCHJkx;
            KMEoMgNoEpf /= waLCHJkx;
            waLCHJkx = nHSIYqyIbt;
        }
    }

    for (int BiDtpoAI = 360567866; BiDtpoAI > 0; BiDtpoAI--) {
        XAoQpinlSlMToYcD = waLCHJkx;
        KMEoMgNoEpf -= XAoQpinlSlMToYcD;
        XAoQpinlSlMToYcD -= waLCHJkx;
        nHSIYqyIbt += NYMsfxvVcGPx;
    }

    if (nHSIYqyIbt < -302094547) {
        for (int HDYHaCzS = 1527884187; HDYHaCzS > 0; HDYHaCzS--) {
            KMEoMgNoEpf += KMEoMgNoEpf;
            rTpIYqkEluCFd = jFuVQUPlNSsxcM;
            waLCHJkx += NYMsfxvVcGPx;
        }
    }

    for (int EtNNpm = 254579258; EtNNpm > 0; EtNNpm--) {
        nHSIYqyIbt /= KMEoMgNoEpf;
    }

    if (XAoQpinlSlMToYcD > 250551561) {
        for (int jrqyMp = 925465394; jrqyMp > 0; jrqyMp--) {
            XAoQpinlSlMToYcD += waLCHJkx;
            nHSIYqyIbt -= nHSIYqyIbt;
        }
    }
}

bool QGgecAIadh::QudPAT(bool ViHMV)
{
    double wdzKRIAEmCm = 151119.39803237806;

    if (ViHMV == false) {
        for (int PGXlSnIioBMiG = 564256992; PGXlSnIioBMiG > 0; PGXlSnIioBMiG--) {
            wdzKRIAEmCm /= wdzKRIAEmCm;
            ViHMV = ViHMV;
        }
    }

    if (ViHMV == false) {
        for (int iRiePR = 114326777; iRiePR > 0; iRiePR--) {
            wdzKRIAEmCm = wdzKRIAEmCm;
            wdzKRIAEmCm /= wdzKRIAEmCm;
        }
    }

    if (wdzKRIAEmCm < 151119.39803237806) {
        for (int sETUyuxhC = 841750968; sETUyuxhC > 0; sETUyuxhC--) {
            wdzKRIAEmCm = wdzKRIAEmCm;
            wdzKRIAEmCm *= wdzKRIAEmCm;
            wdzKRIAEmCm /= wdzKRIAEmCm;
            wdzKRIAEmCm -= wdzKRIAEmCm;
            wdzKRIAEmCm += wdzKRIAEmCm;
        }
    }

    return ViHMV;
}

QGgecAIadh::QGgecAIadh()
{
    this->VFRkglks(1003271.5532154966);
    this->GyubrILvtYfk(string("avTZwKFejyfeuFOgBeknznvbjjaSSSsKfzoMxfEhakeybawwurqVlqfjozcvZWxoPHqyVdzJFmryGtoQfHzLXsLjyOMAUpkQnW"), -360544.0110981979, false);
    this->kWxcr(true);
    this->sTOuDzGhjJ(936625.54503708, -905258.9440177091, false, true);
    this->CRlDuLtIRwjxiFz(474625.96731338865, false, 323042.385937913, false, 879269.9920844235);
    this->VsIuNXWOolSb();
    this->bTzCEFsNxZa(-994294.8723018592, false, true, -312104.81250357634, 148437.16067890776);
    this->tdTXTIXMnq();
    this->LJeBYp(-1275118368, true, string("YWHkCwzfYhEJBHZAiiKQUnUOmpRmoSxwOcelVFjGgwAUdXDUPNTBLkKYQeRtfuGhSQstFJaoilFCcSfHLbgOFgjEdEYTFYvJQdrDjwiPTOTxtcMgapwnEPNWAfPuomlaPYushgZCCDTdYVOYoqbgfyCGRynHXavOqLAwXQmGIcisBKpbhjQUmAXasHmfGECStGHTitMcbaFlaysEzQAPIzbBYaAPHGYPdRjnSVCfKvgUBJlXJuXwNXD"));
    this->AstDPNUoyXCQHNR(false);
    this->FIwJHTX(true, string("CMbmKjJrPqXAWTKOpwJQopeGhszofwqBHuaCzprALCZoiOpesWqeRAkzHNnWRwktlnGYvRHXMQpJXMKlqcDUVJaLkTDREpMJbXqhXdrebbUVvPqNGxVLjMlpJhRHGpluyDlpDlXoVl"), false, 648549.6438087046);
    this->MxlFrxJn(937748824, string("AWlYdXkcnXZGZpOqgmkanxjiSefgthCdPNMkICePSWmHYqYLQkunKJTSHFEsqfvVLWswOMKIzojEunEYUZUMbOJgejkTdurzXnmxkZOJgoxpSOwqCRJWwOAbhPDxLIcExXXaIlZnukPemVIPWkfXEhYWDXNhpkeuaqCQBcLeqBPypLTzXWsMBLxzkepGadAjvxqJyGOAyXzlzOCcGbyGGYGwdxsEdHbzyXKRjljHCphlOHeVi"), -43607045);
    this->XeCwmzziy();
    this->wHAWriQL(1896151906);
    this->IwRJlS();
    this->yXgswGpjoBcSETFT(string("BnzQDdQxZsRgvpUatUIXHpITHvtMKMNtXwkiYAcjCMpVDz"), 277446.2386999034);
    this->jLqjCUL(false, true);
    this->MFdBnEdlMMpKee();
    this->cRqcSwXYjEAkA();
    this->gYthL(false);
    this->BrAHDzKWvqFaN(string("TFHFWLSfAkPvZIoYzmpjUprsVZuoxHndxHTWYvfVlTcrhJIFKMiinVFQBNOXmktiSdZdHzJzNcyphZyvnzKKYxlShwRfLnjfItBYQmLrMH"), 250551561);
    this->QudPAT(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WVUWOj
{
public:
    bool aBMrCNSWx;
    string TSyEQnCIwfWT;
    bool uKnbwPV;
    double DiEovVowuCPHTdx;
    int zWNwliaPRIBBZmv;
    bool mEPsRaId;

    WVUWOj();
protected:
    int gDgyDvHSVs;
    int MkIfuE;
    bool FWVpxtsaTw;
    double SiMSVMjQchiaasj;
    string IBBqOPXXEadNDM;
    int syxDJBu;

    string yNQQNmDZQEQ(bool ahpdWqrIbIf);
    void AISLEreAZ(int hRWHrVAJ, double VuIEGoALJvHZWd);
    double BsOnFotPTTTOWth(bool xfnmHHCgFUyY, double HAILmyoUaWcrlZb, string VusiSMIjwhp);
    int aYMIApdVyV();
    int jGKyKOCAYWHu(bool AiqeSUWnB, string MJlWv, bool ZfgRsTxUALvV, double OrFWMGPi);
    int cSilkoiBoNAojm(int hUMWfRt);
    bool EocmpnDBap(string LgFACiu);
private:
    double RPFQWWGOkaji;
    double fLiPfhj;
    bool BNceoiqKpHFrEl;
    int SClXPiTgaSec;

    double gysZNnZIawU(double bweOOCubFWqDXzGX);
    string WJTJNjcqrj();
    bool XVGCCTKedgx();
    bool QbZtxH(string RnFbtrRLh, double AsZOKFC);
    double njlsJWQxCCEZIl();
};

string WVUWOj::yNQQNmDZQEQ(bool ahpdWqrIbIf)
{
    int JFvAZomrxKEsynQU = 1519272070;
    double BRbJtWS = 478090.01998006366;
    bool LFbfLowhznGFG = false;
    double ZOFveMeKSlnpJwzL = -991821.4381575518;

    for (int scOGwSzD = 1017317566; scOGwSzD > 0; scOGwSzD--) {
        BRbJtWS = BRbJtWS;
        ahpdWqrIbIf = ahpdWqrIbIf;
        ZOFveMeKSlnpJwzL -= ZOFveMeKSlnpJwzL;
    }

    for (int BarOmvCtpQLHKbB = 1703389389; BarOmvCtpQLHKbB > 0; BarOmvCtpQLHKbB--) {
        LFbfLowhznGFG = ahpdWqrIbIf;
        ahpdWqrIbIf = ! ahpdWqrIbIf;
        BRbJtWS /= ZOFveMeKSlnpJwzL;
    }

    for (int HkXQxORTVHOTU = 1649354562; HkXQxORTVHOTU > 0; HkXQxORTVHOTU--) {
        ZOFveMeKSlnpJwzL /= ZOFveMeKSlnpJwzL;
    }

    for (int qEKBQZtvkzIAhFB = 320098102; qEKBQZtvkzIAhFB > 0; qEKBQZtvkzIAhFB--) {
        BRbJtWS += BRbJtWS;
        ahpdWqrIbIf = ahpdWqrIbIf;
    }

    return string("ObsMLtyMLdyqFBHyesgWqPqGZbwMcZptSDLLpvDQirvcJg");
}

void WVUWOj::AISLEreAZ(int hRWHrVAJ, double VuIEGoALJvHZWd)
{
    bool IYwWTZGIVrjTXI = true;
    double iAJNkimA = -411742.28322615934;
    bool BPtgCcXSyfu = true;
    bool DdeGnaSSjR = false;

    for (int EegtGOwlS = 1014358266; EegtGOwlS > 0; EegtGOwlS--) {
        VuIEGoALJvHZWd -= VuIEGoALJvHZWd;
    }

    for (int agidcdVVDVDQzIJ = 339075571; agidcdVVDVDQzIJ > 0; agidcdVVDVDQzIJ--) {
        continue;
    }

    for (int ILerlSG = 1499178154; ILerlSG > 0; ILerlSG--) {
        BPtgCcXSyfu = ! DdeGnaSSjR;
    }

    for (int TnBRtm = 855289952; TnBRtm > 0; TnBRtm--) {
        continue;
    }

    for (int dhQcLSc = 1459816203; dhQcLSc > 0; dhQcLSc--) {
        IYwWTZGIVrjTXI = IYwWTZGIVrjTXI;
        VuIEGoALJvHZWd -= VuIEGoALJvHZWd;
        BPtgCcXSyfu = ! DdeGnaSSjR;
        iAJNkimA -= VuIEGoALJvHZWd;
    }

    for (int RNxmRQYzDjrwp = 1199086542; RNxmRQYzDjrwp > 0; RNxmRQYzDjrwp--) {
        DdeGnaSSjR = DdeGnaSSjR;
        VuIEGoALJvHZWd = VuIEGoALJvHZWd;
        iAJNkimA += VuIEGoALJvHZWd;
        BPtgCcXSyfu = IYwWTZGIVrjTXI;
    }

    for (int fKIcmjkCzbM = 998041547; fKIcmjkCzbM > 0; fKIcmjkCzbM--) {
        IYwWTZGIVrjTXI = DdeGnaSSjR;
    }

    for (int HPBXUUcVNuHPi = 271983884; HPBXUUcVNuHPi > 0; HPBXUUcVNuHPi--) {
        DdeGnaSSjR = ! DdeGnaSSjR;
        DdeGnaSSjR = BPtgCcXSyfu;
    }
}

double WVUWOj::BsOnFotPTTTOWth(bool xfnmHHCgFUyY, double HAILmyoUaWcrlZb, string VusiSMIjwhp)
{
    bool cTKKTvekkLiYUc = false;
    double AENNhc = -976856.6053319378;
    string YrCEAhkUNNbZOJqc = string("VIzSrIslIOIaCGEKMOXGnmpDfGj");
    int vsuCCWcoKz = 1824284453;

    for (int skVXAGmMc = 1788278334; skVXAGmMc > 0; skVXAGmMc--) {
        vsuCCWcoKz = vsuCCWcoKz;
        cTKKTvekkLiYUc = ! cTKKTvekkLiYUc;
        xfnmHHCgFUyY = xfnmHHCgFUyY;
        xfnmHHCgFUyY = xfnmHHCgFUyY;
    }

    if (vsuCCWcoKz < 1824284453) {
        for (int UBmJWzR = 180708707; UBmJWzR > 0; UBmJWzR--) {
            cTKKTvekkLiYUc = ! xfnmHHCgFUyY;
            cTKKTvekkLiYUc = cTKKTvekkLiYUc;
        }
    }

    if (xfnmHHCgFUyY == true) {
        for (int XApoKrAVUFjhV = 1754577133; XApoKrAVUFjhV > 0; XApoKrAVUFjhV--) {
            VusiSMIjwhp += VusiSMIjwhp;
            HAILmyoUaWcrlZb -= HAILmyoUaWcrlZb;
            HAILmyoUaWcrlZb /= HAILmyoUaWcrlZb;
            YrCEAhkUNNbZOJqc = YrCEAhkUNNbZOJqc;
        }
    }

    if (YrCEAhkUNNbZOJqc < string("PTnBNimCXTRPFjKgWwCTGrpmSSOeUQSyenDeotAdjMCBYumNZLTHnzlAcmiwgSCxfqQvSGLtQsFIZsmukrcBdxHxxMPvAAPFHpWtnltQpEKQmarRtElDKmszEqKyorZNoVVMJgMGSffUzSsagGXLNTiOVax")) {
        for (int IhtbQSxRAxM = 1272413320; IhtbQSxRAxM > 0; IhtbQSxRAxM--) {
            continue;
        }
    }

    for (int TaCGWT = 44725274; TaCGWT > 0; TaCGWT--) {
        VusiSMIjwhp += YrCEAhkUNNbZOJqc;
        AENNhc += AENNhc;
        AENNhc -= HAILmyoUaWcrlZb;
    }

    for (int mYDKiu = 1222610551; mYDKiu > 0; mYDKiu--) {
        xfnmHHCgFUyY = ! cTKKTvekkLiYUc;
        cTKKTvekkLiYUc = xfnmHHCgFUyY;
    }

    for (int jQOzjw = 1846478028; jQOzjw > 0; jQOzjw--) {
        HAILmyoUaWcrlZb += HAILmyoUaWcrlZb;
        VusiSMIjwhp += YrCEAhkUNNbZOJqc;
        vsuCCWcoKz += vsuCCWcoKz;
        xfnmHHCgFUyY = xfnmHHCgFUyY;
        xfnmHHCgFUyY = ! xfnmHHCgFUyY;
    }

    return AENNhc;
}

int WVUWOj::aYMIApdVyV()
{
    double GQxyKVxkbpDXhQt = 937107.5102095731;
    double iEEbRwwZqeWgZ = -371407.66653727315;
    double SRXfAa = 995821.4766654096;
    bool IpLMszOSGVGeA = true;
    double IMwllOqTgnGu = -535002.0859022138;
    string TnHTlelf = string("zbEfiiJOQAeoYIiNDDXuAGkhQenrDINeAnWTvTvKNkpXnfIuxKCrqoVnvencfesNhQbmOLeLssnZMfTTbDadhzwVoWXYHWnwIlYhPCXaeEBHFDNVbEqDJkCNQOnnpsAvkGIEZ");

    if (SRXfAa > 995821.4766654096) {
        for (int nqFlSuiHS = 1971282229; nqFlSuiHS > 0; nqFlSuiHS--) {
            IMwllOqTgnGu /= iEEbRwwZqeWgZ;
        }
    }

    for (int ndtdbMB = 946640401; ndtdbMB > 0; ndtdbMB--) {
        GQxyKVxkbpDXhQt = iEEbRwwZqeWgZ;
    }

    for (int uMBemWPudJRopGKZ = 711782290; uMBemWPudJRopGKZ > 0; uMBemWPudJRopGKZ--) {
        IMwllOqTgnGu *= IMwllOqTgnGu;
        SRXfAa += IMwllOqTgnGu;
        IMwllOqTgnGu += SRXfAa;
    }

    for (int ZIbiJptf = 682179006; ZIbiJptf > 0; ZIbiJptf--) {
        iEEbRwwZqeWgZ += IMwllOqTgnGu;
    }

    return 1461088264;
}

int WVUWOj::jGKyKOCAYWHu(bool AiqeSUWnB, string MJlWv, bool ZfgRsTxUALvV, double OrFWMGPi)
{
    double FTQiIi = 104159.55159142036;
    double rJZKCVibbpqfHZ = -821947.6810007199;
    double pFJkUGVJ = 457930.1978873648;
    double CAfCBvm = 241642.37844524437;
    string UphNrx = string("wKqGUXbUDcobFoIzSSKoJJihvdyEYiLwlOIhfpyAzgGKyVTabiaHFGHHnYIXflwkjVZqRqrRvbUqRmPznkcYJbwDNcWkaJawULrAaSTFyhQSTWfPxTpeYCwDKniVvWzFlLoQMGbSlvmTHJAHoDYsADeJq");
    bool CTjNrukcNKAEV = false;
    bool drcyXrjNDHRWo = false;
    bool QXMHezVhRmQ = true;
    bool WDYHLizaVfy = true;
    double dejTtbgbCtDUN = 892148.3512416357;

    if (WDYHLizaVfy != false) {
        for (int IuNEKaywuqjj = 853068284; IuNEKaywuqjj > 0; IuNEKaywuqjj--) {
            ZfgRsTxUALvV = WDYHLizaVfy;
            ZfgRsTxUALvV = ! CTjNrukcNKAEV;
            ZfgRsTxUALvV = ! ZfgRsTxUALvV;
            CAfCBvm = CAfCBvm;
        }
    }

    return -1261594384;
}

int WVUWOj::cSilkoiBoNAojm(int hUMWfRt)
{
    double mzJjxeciOhZd = -34389.53341045726;
    int AbltKEYfFJqmT = -1152833216;
    int qYwrxbIaTW = 1916156200;
    string lBorsPnvDHQ = string("lMVqHUnLKpOwgPJQtVkwVAjAwSutvyriBaDuVjHgSYpiPVDLEVdQ");
    int jVBDPqae = 767044521;
    string XMllYsAZckkZQqZc = string("aFnuDrpNhdsRJXJjUtfMNmjjmPTyDojghxBLcBhwfqGQNTUcrSCmazYZvDjKETkyskLjHkSwUDHkwQwHYfhLdrFZgqLa");
    int OPWcXMkTsCct = -1531448826;
    string QOGNjJKtJeSS = string("oXeLnUkLrNWwyecZboqzUWKeJqsiqGflZATETQsMpEpQcviHdIIXgYRMWEIgBSygYYbEJCRKszOcBVdRDhjXcxeUcPpOTlHHNuJALaznXWrwgTZSIucmPZFbfquLKulemOXModBooERCsfYEUhmFOvYoOMbQcUGxkVIEXJxnNFwnYKpBttUWukUnAGdKOEKWrdRjqujOdkOTJRobpza");

    for (int qBUMDBni = 272101846; qBUMDBni > 0; qBUMDBni--) {
        jVBDPqae *= AbltKEYfFJqmT;
    }

    for (int sSczmVSWzAQzCGy = 781784491; sSczmVSWzAQzCGy > 0; sSczmVSWzAQzCGy--) {
        OPWcXMkTsCct *= hUMWfRt;
    }

    if (OPWcXMkTsCct <= -1531448826) {
        for (int XShpcSG = 1068854398; XShpcSG > 0; XShpcSG--) {
            hUMWfRt += jVBDPqae;
            OPWcXMkTsCct = OPWcXMkTsCct;
            qYwrxbIaTW += OPWcXMkTsCct;
            qYwrxbIaTW *= qYwrxbIaTW;
        }
    }

    return OPWcXMkTsCct;
}

bool WVUWOj::EocmpnDBap(string LgFACiu)
{
    int GKFfgvVMVgvB = 1324980342;
    bool YtRgmKmCZaENOmcx = false;
    int rYNqvJva = -1122448861;
    bool pELhCVldi = true;
    bool KiUHH = false;
    double skdQpjyNAHIMdKXP = 238905.54524888063;
    bool QXxRnMvg = false;
    int eGaokM = -1374260090;
    double LJHekGBbTlocq = 116445.70075186003;

    if (pELhCVldi != false) {
        for (int luGAKSA = 783677431; luGAKSA > 0; luGAKSA--) {
            continue;
        }
    }

    for (int BNhwCwrVCsrqXN = 1289769813; BNhwCwrVCsrqXN > 0; BNhwCwrVCsrqXN--) {
        YtRgmKmCZaENOmcx = pELhCVldi;
    }

    return QXxRnMvg;
}

double WVUWOj::gysZNnZIawU(double bweOOCubFWqDXzGX)
{
    int EIUFXZUWI = 879914748;

    for (int nuMjofjxCRqeprvq = 565903975; nuMjofjxCRqeprvq > 0; nuMjofjxCRqeprvq--) {
        EIUFXZUWI *= EIUFXZUWI;
        EIUFXZUWI *= EIUFXZUWI;
        EIUFXZUWI += EIUFXZUWI;
    }

    if (bweOOCubFWqDXzGX < 915612.548338386) {
        for (int bTUdHffD = 1378130684; bTUdHffD > 0; bTUdHffD--) {
            EIUFXZUWI /= EIUFXZUWI;
            EIUFXZUWI /= EIUFXZUWI;
            bweOOCubFWqDXzGX /= bweOOCubFWqDXzGX;
        }
    }

    for (int zstzwkdOydusAZE = 1044054013; zstzwkdOydusAZE > 0; zstzwkdOydusAZE--) {
        bweOOCubFWqDXzGX += bweOOCubFWqDXzGX;
        bweOOCubFWqDXzGX /= bweOOCubFWqDXzGX;
        bweOOCubFWqDXzGX *= bweOOCubFWqDXzGX;
        bweOOCubFWqDXzGX = bweOOCubFWqDXzGX;
        bweOOCubFWqDXzGX *= bweOOCubFWqDXzGX;
        EIUFXZUWI = EIUFXZUWI;
        bweOOCubFWqDXzGX -= bweOOCubFWqDXzGX;
    }

    if (bweOOCubFWqDXzGX == 915612.548338386) {
        for (int VoLRSYXGLlGKjs = 4330486; VoLRSYXGLlGKjs > 0; VoLRSYXGLlGKjs--) {
            EIUFXZUWI += EIUFXZUWI;
        }
    }

    return bweOOCubFWqDXzGX;
}

string WVUWOj::WJTJNjcqrj()
{
    bool QXOWIoo = false;
    int lrxrJ = -906322089;
    double FOCQUTNYOOWMq = -444989.3167418496;
    bool skDTlOO = false;
    bool LTZqCTZzLfwSSp = true;
    bool WEhqWV = false;
    string yAbtGGqZT = string("yrbzcwZuKfNyVHFgGuQFdSAGrCWRPnQlsYGPAofQpeliapaXdtytsmtOmMdCslAhnEjSjNKoGhSYvCeu");
    int qcQjPpoto = -2139269568;
    bool agoDvJZ = true;
    int uAEUqF = -131900829;

    for (int rqRODiopiJIR = 2042649639; rqRODiopiJIR > 0; rqRODiopiJIR--) {
        skDTlOO = ! agoDvJZ;
        yAbtGGqZT = yAbtGGqZT;
        WEhqWV = ! QXOWIoo;
        LTZqCTZzLfwSSp = agoDvJZ;
    }

    return yAbtGGqZT;
}

bool WVUWOj::XVGCCTKedgx()
{
    double YJjNCuHXoyzwzYTK = 1014440.0610125801;

    if (YJjNCuHXoyzwzYTK == 1014440.0610125801) {
        for (int gPEjQoNiCRkdAqY = 1462487611; gPEjQoNiCRkdAqY > 0; gPEjQoNiCRkdAqY--) {
            YJjNCuHXoyzwzYTK -= YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK = YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK = YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK += YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK = YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK *= YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK -= YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK = YJjNCuHXoyzwzYTK;
        }
    }

    if (YJjNCuHXoyzwzYTK != 1014440.0610125801) {
        for (int qvwVjQxGLZtink = 635704232; qvwVjQxGLZtink > 0; qvwVjQxGLZtink--) {
            YJjNCuHXoyzwzYTK /= YJjNCuHXoyzwzYTK;
        }
    }

    if (YJjNCuHXoyzwzYTK < 1014440.0610125801) {
        for (int WaUiZjeuUYkc = 579756862; WaUiZjeuUYkc > 0; WaUiZjeuUYkc--) {
            YJjNCuHXoyzwzYTK *= YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK *= YJjNCuHXoyzwzYTK;
            YJjNCuHXoyzwzYTK *= YJjNCuHXoyzwzYTK;
        }
    }

    return false;
}

bool WVUWOj::QbZtxH(string RnFbtrRLh, double AsZOKFC)
{
    bool EKxKvJAWDoXkL = false;
    int mWGJGLDm = -849963933;
    bool EvrLzDLvkLC = false;
    bool YTQjpM = false;
    string trFuAJrs = string("evxgbaPEnRqndAtHcDxrSGaPRuLvIEnG");
    double DGFRUXKIdQemwJ = 806637.2320184337;
    bool sjiNXLQ = false;
    double EZpLZtLMvtqt = -451660.5462999227;

    for (int zMmquFrjqcGV = 1237524059; zMmquFrjqcGV > 0; zMmquFrjqcGV--) {
        AsZOKFC *= EZpLZtLMvtqt;
        EKxKvJAWDoXkL = sjiNXLQ;
        YTQjpM = ! EKxKvJAWDoXkL;
        EvrLzDLvkLC = ! YTQjpM;
    }

    for (int xCpTaQVGiEDoDUaY = 1759745095; xCpTaQVGiEDoDUaY > 0; xCpTaQVGiEDoDUaY--) {
        continue;
    }

    return sjiNXLQ;
}

double WVUWOj::njlsJWQxCCEZIl()
{
    bool nipVto = true;
    int quUarlsaxgrL = 1508072420;
    int dcmWf = -712527763;
    int qxCkOz = 188627480;
    int wJAZmCUZuFrYq = 757402861;
    double WnpKvfltCc = -287950.37933255703;

    if (dcmWf >= 188627480) {
        for (int sAuKLI = 1954642815; sAuKLI > 0; sAuKLI--) {
            dcmWf /= quUarlsaxgrL;
            qxCkOz = quUarlsaxgrL;
            wJAZmCUZuFrYq += quUarlsaxgrL;
            wJAZmCUZuFrYq *= dcmWf;
            dcmWf = qxCkOz;
            nipVto = ! nipVto;
        }
    }

    for (int xztrxE = 1051841876; xztrxE > 0; xztrxE--) {
        nipVto = nipVto;
        quUarlsaxgrL -= dcmWf;
    }

    return WnpKvfltCc;
}

WVUWOj::WVUWOj()
{
    this->yNQQNmDZQEQ(false);
    this->AISLEreAZ(325174940, 1012694.5997694483);
    this->BsOnFotPTTTOWth(true, 464598.15956667013, string("PTnBNimCXTRPFjKgWwCTGrpmSSOeUQSyenDeotAdjMCBYumNZLTHnzlAcmiwgSCxfqQvSGLtQsFIZsmukrcBdxHxxMPvAAPFHpWtnltQpEKQmarRtElDKmszEqKyorZNoVVMJgMGSffUzSsagGXLNTiOVax"));
    this->aYMIApdVyV();
    this->jGKyKOCAYWHu(false, string("MHpoMjfdlCphOMqxHGOwqYGy"), false, -285464.2006416888);
    this->cSilkoiBoNAojm(-1112074496);
    this->EocmpnDBap(string("nLgrgbbpZhrylCmKEsfTCynsdAozhlQaHTYAbVcOSfpXsrVZxQyjKdMJTtDlLETHAhHnxqXccGjOdvyYbNuQWmHYEGUFKsvnCIKGuwOAoDljDdSmpaTTBrF"));
    this->gysZNnZIawU(915612.548338386);
    this->WJTJNjcqrj();
    this->XVGCCTKedgx();
    this->QbZtxH(string("Ng"), -1031585.1492488888);
    this->njlsJWQxCCEZIl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JRTyxZObmrILaCai
{
public:
    bool dkhcSiABdzIBtzQ;
    double zcSeAoy;
    double aHCZkcUdi;

    JRTyxZObmrILaCai();
    void pMckmaMG(int nCmLAZp);
protected:
    double FazilEpSLrWyQ;
    double lkhYFBBfTnofFw;
    int HSGSRyQxEsqXZP;

    void iLjnLlKMvbJCWJm(double ziqGTGulchgW);
    void QxEabLcJcdgKquL(string eGclBsmShgDvFXtV);
    string OFhFXQNW(double pQvZLXCtnzlf, bool ZcmJudfRwjCGArW);
    double YUlKIKDRkFwIftBQ(int rtGMRrwR, bool LVjhcQlmuvRiOx, int piOYm, bool eWJjBwUZYl);
private:
    string zBuOYROuR;
    string oBNdSce;
    int IjBoYcMfRLsUtPXv;
    string PIXIeencOXyztfDy;
    double DrhOj;
    double xLZpV;

    int cMpFN(string PujkYV, bool rOxFJspwJUA);
    double FYbSlcqp(string ZLEjJUxMeOyzvGq, string JovjGAceVDYSJJK);
    bool ySghO(int RDIbNLhbCtZKwn, double rrNEnMuILRs, string AaQHzwLcI, string TESoP, bool eKWykwIuw);
    string bhHtrbZGPS(string GFEVSlMzOZ, bool HMMkbbzerb, double xaEBgvJiU, string GpwmSOQcdiqJoFKc);
    double rjzHzMzlOjEjOgp(bool WaKJkzDFG, int zPWyujCCWpQt, double ICiKyE, int GgqnoI, double RRziI);
};

void JRTyxZObmrILaCai::pMckmaMG(int nCmLAZp)
{
    bool RZcyxFqGdtat = true;
    string ZlLDIUXzml = string("uTJHkOdmrAKsuKKEIMLGjRzBmbEbqVRAiIXgbsaeIxSacWuLnlLTxExFmqjcLosScqSdPOZhUckIIbwyRDtsCLYOdRdrFHKPsPDESpTPqdCVnleyYlcpSHTOlZcjCEmQtrGIfzQnMYlaQNngjAkMpsGEBvmmijmrdoWcwcJPBKRGtZCEqU");
    bool ZkEZDEWxpCgotV = true;
    string IUNuZDXtyVowA = string("MWsKaQEytJZpJIjDwikggPNPn");
    double nxusOhzGwxTbUW = -920082.4113137447;
    string KrsUceyWhptubnv = string("ZbPeguYDMdPDtTjYPNBppdApjPekNQPgAMQfqPYTjixngpUvdZKwjnYkCgRVaPCJgjljSIFNTmuncXdUQJXDQPXCbItLEQULJqnCnjnLcwSIHDkjBwvDNVZHdJSUQxyFZtjvVSgMWXZQJGRVvjJzwJjguvDAvbRRWmQunwqWXmCWXhzXQCHsyebCAVLjTFlArTthpqqLsHROWzndZ");
    int StqhQ = 467292675;

    for (int iYRlouPepNL = 649775327; iYRlouPepNL > 0; iYRlouPepNL--) {
        nCmLAZp = nCmLAZp;
    }

    for (int RnhdikSOQxQBI = 704517467; RnhdikSOQxQBI > 0; RnhdikSOQxQBI--) {
        IUNuZDXtyVowA = IUNuZDXtyVowA;
        nxusOhzGwxTbUW -= nxusOhzGwxTbUW;
        KrsUceyWhptubnv += ZlLDIUXzml;
    }

    if (nxusOhzGwxTbUW == -920082.4113137447) {
        for (int AeoSyuttJ = 1277439455; AeoSyuttJ > 0; AeoSyuttJ--) {
            nxusOhzGwxTbUW *= nxusOhzGwxTbUW;
        }
    }

    for (int JSjMfGKB = 1892470096; JSjMfGKB > 0; JSjMfGKB--) {
        ZlLDIUXzml = IUNuZDXtyVowA;
        RZcyxFqGdtat = ! RZcyxFqGdtat;
    }

    for (int NKuNcnWUSrqYtfu = 2042242424; NKuNcnWUSrqYtfu > 0; NKuNcnWUSrqYtfu--) {
        continue;
    }

    if (ZkEZDEWxpCgotV == true) {
        for (int EJZdPE = 1543470838; EJZdPE > 0; EJZdPE--) {
            continue;
        }
    }

    if (ZlLDIUXzml == string("MWsKaQEytJZpJIjDwikggPNPn")) {
        for (int gvyiWlvtqxmcEW = 887890500; gvyiWlvtqxmcEW > 0; gvyiWlvtqxmcEW--) {
            IUNuZDXtyVowA += IUNuZDXtyVowA;
            ZkEZDEWxpCgotV = RZcyxFqGdtat;
            RZcyxFqGdtat = ZkEZDEWxpCgotV;
        }
    }
}

void JRTyxZObmrILaCai::iLjnLlKMvbJCWJm(double ziqGTGulchgW)
{
    int XSYgGrJpyR = -1124341290;
    int XRgAjQnvHBcUv = 1845710064;

    for (int yAMxYTWGF = 193461860; yAMxYTWGF > 0; yAMxYTWGF--) {
        XSYgGrJpyR += XRgAjQnvHBcUv;
        ziqGTGulchgW /= ziqGTGulchgW;
        ziqGTGulchgW += ziqGTGulchgW;
        XRgAjQnvHBcUv = XRgAjQnvHBcUv;
    }
}

void JRTyxZObmrILaCai::QxEabLcJcdgKquL(string eGclBsmShgDvFXtV)
{
    int HvvlbNGASEXoMqR = 1354038826;
    string kcWIHmVHZ = string("MQBQOcgzqxofBnxThBtoUwYYLrWpadHWBkbTDElAleAwNwTeEofvPmiSBoBPfaHdgeGwEeidyTPLzwSnxmuMhvpZVmoggfacaQPMeUmmkLWghpriHKAekqNFKcvZtbITLXrTNBqlTBoZHLYMoZrovufsyGOPnTXcXUpQmDOQpqcOqKjcwrjxeJYyqbGNGPxcdlCPXobmgMZZBIof");
    bool ovhFmDcDrzWYL = false;
    string fkhpgfQCikRpaz = string("tCbfcAEqcsvlzWwxDPLvtecsMSQbaBUDvazeexhVFUpjzNWbcBajLHWsflOBTqWmgyNEInWKYASBJhfDkwqVUzcjvHZpWczKZFlykdczXLxQnOtadyyLLQDPfOkD");

    for (int dzcLHfco = 313794801; dzcLHfco > 0; dzcLHfco--) {
        eGclBsmShgDvFXtV += fkhpgfQCikRpaz;
        eGclBsmShgDvFXtV = kcWIHmVHZ;
        eGclBsmShgDvFXtV += fkhpgfQCikRpaz;
        HvvlbNGASEXoMqR = HvvlbNGASEXoMqR;
        HvvlbNGASEXoMqR *= HvvlbNGASEXoMqR;
        kcWIHmVHZ += fkhpgfQCikRpaz;
    }

    for (int fZWErwCpzONdMv = 774123099; fZWErwCpzONdMv > 0; fZWErwCpzONdMv--) {
        eGclBsmShgDvFXtV += kcWIHmVHZ;
    }

    for (int rxqqIpilrptUzI = 1183984322; rxqqIpilrptUzI > 0; rxqqIpilrptUzI--) {
        kcWIHmVHZ = kcWIHmVHZ;
        fkhpgfQCikRpaz = fkhpgfQCikRpaz;
        eGclBsmShgDvFXtV += kcWIHmVHZ;
        kcWIHmVHZ = fkhpgfQCikRpaz;
        fkhpgfQCikRpaz = fkhpgfQCikRpaz;
        kcWIHmVHZ = kcWIHmVHZ;
    }

    for (int fVoty = 2125131026; fVoty > 0; fVoty--) {
        fkhpgfQCikRpaz = kcWIHmVHZ;
        fkhpgfQCikRpaz = kcWIHmVHZ;
    }

    for (int eVgNcqK = 1302954618; eVgNcqK > 0; eVgNcqK--) {
        ovhFmDcDrzWYL = ! ovhFmDcDrzWYL;
        kcWIHmVHZ += kcWIHmVHZ;
        kcWIHmVHZ += eGclBsmShgDvFXtV;
        eGclBsmShgDvFXtV += eGclBsmShgDvFXtV;
    }

    for (int khNITzRrN = 1599230579; khNITzRrN > 0; khNITzRrN--) {
        eGclBsmShgDvFXtV = kcWIHmVHZ;
        kcWIHmVHZ = eGclBsmShgDvFXtV;
    }
}

string JRTyxZObmrILaCai::OFhFXQNW(double pQvZLXCtnzlf, bool ZcmJudfRwjCGArW)
{
    bool CsiSLuWibEITC = false;
    bool vHOwoYM = true;
    double ixNFxq = 938587.784795952;
    int kKdUKriGpJUR = -572747512;

    for (int KRqcFxyzTE = 364113178; KRqcFxyzTE > 0; KRqcFxyzTE--) {
        ixNFxq *= pQvZLXCtnzlf;
        CsiSLuWibEITC = ! vHOwoYM;
    }

    if (CsiSLuWibEITC == true) {
        for (int rmcHbwJcn = 348659586; rmcHbwJcn > 0; rmcHbwJcn--) {
            continue;
        }
    }

    if (vHOwoYM != true) {
        for (int EFCSHzg = 1255229929; EFCSHzg > 0; EFCSHzg--) {
            ZcmJudfRwjCGArW = ! vHOwoYM;
            CsiSLuWibEITC = ! CsiSLuWibEITC;
            vHOwoYM = ZcmJudfRwjCGArW;
            ZcmJudfRwjCGArW = vHOwoYM;
            vHOwoYM = ZcmJudfRwjCGArW;
        }
    }

    for (int KlzEFsPxYwvjPvX = 53087623; KlzEFsPxYwvjPvX > 0; KlzEFsPxYwvjPvX--) {
        CsiSLuWibEITC = ! ZcmJudfRwjCGArW;
    }

    if (ZcmJudfRwjCGArW == true) {
        for (int BYouWBTc = 545063674; BYouWBTc > 0; BYouWBTc--) {
            pQvZLXCtnzlf *= ixNFxq;
            ZcmJudfRwjCGArW = vHOwoYM;
        }
    }

    for (int HGfCcNbLltzrb = 1295436542; HGfCcNbLltzrb > 0; HGfCcNbLltzrb--) {
        vHOwoYM = ! vHOwoYM;
        ixNFxq += ixNFxq;
    }

    return string("hJAeYFyoyWMfwnmrdrxHyqPlAFgbvobyQfsDwEKGOUdAIvYmKlUBEmcawQXIDFjeHatZPsmu");
}

double JRTyxZObmrILaCai::YUlKIKDRkFwIftBQ(int rtGMRrwR, bool LVjhcQlmuvRiOx, int piOYm, bool eWJjBwUZYl)
{
    string kCPDOVOtHUD = string("EatqnRiFJnHptxZJYvyZrCeFzTvdXvqdzlDHTuqKrmRDCoXLRfhco");
    bool pROHz = true;
    double uHePgOcfAmfSsP = -221219.25900058702;
    string UDNVZmZZ = string("hsDJPAmsahOOlTmSqdNLxPbBRHmKTHOkkItvRFaMtGudZfXBTQiakzwfampMTGFcLitvEzrKRXPHkRELqwROArSezNSGuxjqAGpkepTSqfpSbtpfvbSRExQNVFUobeVxpzzLXskrMaIIEMLbjKcpLgfBwweECtCENCWBqmjBGfbtsjyHapfvWvfxWTjtzTqf");
    double rPtUAJ = -740547.0619871228;
    double WaLggg = -6765.567925838331;
    string YbRAkCo = string("xjSpnhWGBgTZfPAKtGDKYjRFipusFhDITdTTbkselQgjteWJmqmDzXBibhKLvddjFMhNqhQphjfDieWjdZSEQDJPXZSKVOyVoayKGrRiJxNnEkeRCotTnHRpmJarfMIXXthrCoebOHiAaciuRjwbMuMeQaLwIqfFomdblbjGijBiQlOowRqIrGlnPSniNXKeNAQaotrkRlSRdGnEwEalzyUldajCtsrXZDMtMPNGWZrtocpnqwQExLWXMiFem");
    int GXNMH = 2024138819;
    bool gZRntyMRYK = false;
    int GrmiT = -886669746;

    if (eWJjBwUZYl != false) {
        for (int lYURxWf = 1842531089; lYURxWf > 0; lYURxWf--) {
            LVjhcQlmuvRiOx = eWJjBwUZYl;
            eWJjBwUZYl = gZRntyMRYK;
        }
    }

    for (int CZaHKDVUvKoHCNk = 1940635227; CZaHKDVUvKoHCNk > 0; CZaHKDVUvKoHCNk--) {
        eWJjBwUZYl = LVjhcQlmuvRiOx;
        YbRAkCo += YbRAkCo;
    }

    for (int poCuika = 302017586; poCuika > 0; poCuika--) {
        kCPDOVOtHUD += UDNVZmZZ;
        eWJjBwUZYl = eWJjBwUZYl;
    }

    for (int DLMwEyEJsUdrrk = 651813773; DLMwEyEJsUdrrk > 0; DLMwEyEJsUdrrk--) {
        rPtUAJ = uHePgOcfAmfSsP;
        eWJjBwUZYl = ! pROHz;
    }

    for (int PrLMo = 1566058833; PrLMo > 0; PrLMo--) {
        UDNVZmZZ += UDNVZmZZ;
    }

    if (UDNVZmZZ == string("hsDJPAmsahOOlTmSqdNLxPbBRHmKTHOkkItvRFaMtGudZfXBTQiakzwfampMTGFcLitvEzrKRXPHkRELqwROArSezNSGuxjqAGpkepTSqfpSbtpfvbSRExQNVFUobeVxpzzLXskrMaIIEMLbjKcpLgfBwweECtCENCWBqmjBGfbtsjyHapfvWvfxWTjtzTqf")) {
        for (int dIGjdlZbp = 168336797; dIGjdlZbp > 0; dIGjdlZbp--) {
            piOYm /= rtGMRrwR;
        }
    }

    return WaLggg;
}

int JRTyxZObmrILaCai::cMpFN(string PujkYV, bool rOxFJspwJUA)
{
    string kwCVfYu = string("KFPzplZaFiqxhuWzHWDPEjXNwGgDAQqZfYIDEszrevhqbflSjWIxoQBhUaoSmhCHAxPOGIhLIZaINYquwPkIiRMXIalNNsvkCZrtnViQpYzrACUChhFKtjzFXZbRbAmDmgYTKEuvhkdEkEzCp");

    for (int NCMnvEykvICMVGj = 2144095953; NCMnvEykvICMVGj > 0; NCMnvEykvICMVGj--) {
        PujkYV += PujkYV;
        PujkYV += kwCVfYu;
    }

    if (kwCVfYu != string("KFPzplZaFiqxhuWzHWDPEjXNwGgDAQqZfYIDEszrevhqbflSjWIxoQBhUaoSmhCHAxPOGIhLIZaINYquwPkIiRMXIalNNsvkCZrtnViQpYzrACUChhFKtjzFXZbRbAmDmgYTKEuvhkdEkEzCp")) {
        for (int zJDaagwSUxnHL = 51162825; zJDaagwSUxnHL > 0; zJDaagwSUxnHL--) {
            kwCVfYu = kwCVfYu;
            PujkYV = kwCVfYu;
        }
    }

    for (int RSsZXESOIQAjCePH = 1582527772; RSsZXESOIQAjCePH > 0; RSsZXESOIQAjCePH--) {
        continue;
    }

    return -1448637659;
}

double JRTyxZObmrILaCai::FYbSlcqp(string ZLEjJUxMeOyzvGq, string JovjGAceVDYSJJK)
{
    double kwpcYzXAGdDPHI = 517044.1778210099;
    int HSJunqN = -1100784883;

    if (JovjGAceVDYSJJK <= string("CJWdDnIUPtxMXWXqJIvdB")) {
        for (int DBmiHcKmcL = 1422720631; DBmiHcKmcL > 0; DBmiHcKmcL--) {
            JovjGAceVDYSJJK += JovjGAceVDYSJJK;
        }
    }

    for (int YbBDrzHnEpJhgKh = 768773466; YbBDrzHnEpJhgKh > 0; YbBDrzHnEpJhgKh--) {
        ZLEjJUxMeOyzvGq = JovjGAceVDYSJJK;
        HSJunqN -= HSJunqN;
        HSJunqN -= HSJunqN;
    }

    return kwpcYzXAGdDPHI;
}

bool JRTyxZObmrILaCai::ySghO(int RDIbNLhbCtZKwn, double rrNEnMuILRs, string AaQHzwLcI, string TESoP, bool eKWykwIuw)
{
    double gQPesjDxUBlZxM = 500390.8326840935;
    int jmEdfCT = -1233057521;
    bool KVAOKEqRtwPvHsxq = false;
    int hPurWISopyilkOoK = 1198413847;
    double eBVsrxUzCJOL = 791467.7277741564;
    bool YnpWAxCZO = true;
    bool jUcHbqi = true;
    int yCoaPjB = -1703331055;

    if (AaQHzwLcI > string("smLKfhGbiEDfzuJUKAgruTLSwAUohUhbJdjTYQOJyxzoesEXaTGfGTfGGTgWdjAWBLzDbVcckqzqgpnvIOnLWoURLxSaVNTGCbUUcBDAGfOPiHnOoXRlJkJxpfUxgvkXWDNieTZhwDuvoSOWftOgAZyTNJaaRUaTkzHwUUDrzflncYclWIQoXXQYKFyiShyVzXmMJSCcHYRKuGErqfiMY")) {
        for (int DuJtExvsdZX = 5135338; DuJtExvsdZX > 0; DuJtExvsdZX--) {
            YnpWAxCZO = ! jUcHbqi;
            eBVsrxUzCJOL = gQPesjDxUBlZxM;
            jUcHbqi = YnpWAxCZO;
            rrNEnMuILRs -= rrNEnMuILRs;
            TESoP += AaQHzwLcI;
        }
    }

    for (int XvwaipFE = 737839894; XvwaipFE > 0; XvwaipFE--) {
        rrNEnMuILRs *= eBVsrxUzCJOL;
        YnpWAxCZO = KVAOKEqRtwPvHsxq;
        YnpWAxCZO = jUcHbqi;
    }

    return jUcHbqi;
}

string JRTyxZObmrILaCai::bhHtrbZGPS(string GFEVSlMzOZ, bool HMMkbbzerb, double xaEBgvJiU, string GpwmSOQcdiqJoFKc)
{
    bool WsbYTu = false;
    int XiomES = -464882309;
    int INsAlTLlsAlK = 964210499;
    bool lRSIFCjamc = true;
    int nhzLSnwGhs = 1187727513;
    int qhoACchixre = -1270918961;
    double AxnnFTXshSClAuvW = -441745.4092856263;

    for (int lAXkFcUa = 1421770449; lAXkFcUa > 0; lAXkFcUa--) {
        nhzLSnwGhs /= XiomES;
        WsbYTu = HMMkbbzerb;
        INsAlTLlsAlK /= qhoACchixre;
    }

    if (xaEBgvJiU == -441745.4092856263) {
        for (int EgdWqHW = 1756237488; EgdWqHW > 0; EgdWqHW--) {
            lRSIFCjamc = ! WsbYTu;
            lRSIFCjamc = WsbYTu;
            XiomES = qhoACchixre;
            GFEVSlMzOZ = GFEVSlMzOZ;
        }
    }

    return GpwmSOQcdiqJoFKc;
}

double JRTyxZObmrILaCai::rjzHzMzlOjEjOgp(bool WaKJkzDFG, int zPWyujCCWpQt, double ICiKyE, int GgqnoI, double RRziI)
{
    bool CBVrbkO = true;
    string PptybYJqg = string("JqwxVnYhKLqESlXzgabkRKuiIFtPzyIFrtLAxQMcGPvLFZbxfGtigUxsUgexVawCmdbgJSpLIcXLvAXXzaxrTDnxPbxRIrOLPamUSGZnluEaydJTgAsKKrgJFynalvpRDSeAesYHNwZACtNakaGEtVgK");
    int zTNrwHBwC = 705933617;
    bool VsauoFE = false;
    string bWAPUbAqSUEWOdvJ = string("QLhrMCxFLeCYdAwZcyDWxuLtBZeyZBryIjkVrcFBfLgAVaJjGIWJlhJfVwapOnyFgXJLZVQUJyKUlmAmgMevDlBTQkSAuzxBmTAgqYcPRrRPKUNFTdYCHJqKSogzgKnxQVGuECZJOCnxxmcgnfZHdynH");
    int kYjMHrqFaGdFrOH = -116158377;
    bool VqhrwKUcAYOv = false;

    for (int junICYyHhVieQoDn = 481412905; junICYyHhVieQoDn > 0; junICYyHhVieQoDn--) {
        continue;
    }

    if (VsauoFE != false) {
        for (int BjcuiajMBFiqg = 377829499; BjcuiajMBFiqg > 0; BjcuiajMBFiqg--) {
            bWAPUbAqSUEWOdvJ = bWAPUbAqSUEWOdvJ;
            VsauoFE = VqhrwKUcAYOv;
            VqhrwKUcAYOv = CBVrbkO;
        }
    }

    for (int WXymkfJU = 742193231; WXymkfJU > 0; WXymkfJU--) {
        WaKJkzDFG = ! CBVrbkO;
        VsauoFE = ! VsauoFE;
        bWAPUbAqSUEWOdvJ = bWAPUbAqSUEWOdvJ;
        bWAPUbAqSUEWOdvJ = PptybYJqg;
    }

    return RRziI;
}

JRTyxZObmrILaCai::JRTyxZObmrILaCai()
{
    this->pMckmaMG(-2116317483);
    this->iLjnLlKMvbJCWJm(-709966.106104575);
    this->QxEabLcJcdgKquL(string("rgBEAVSms"));
    this->OFhFXQNW(893926.2092303139, true);
    this->YUlKIKDRkFwIftBQ(780270134, true, 154151630, false);
    this->cMpFN(string("qrgWbfESEYZhpDsmcfCfEZzVSUrEyeZUiIihvxddXxYfsjovtLLPFbApPQPXEbpxCewWqimfczGarUgavVkCfmIBNUMxNhIFXHjIFXFBSwHcHhdqSODLUxUMUziCnahcsGMdAzzuZAmgRKpyFMKEzQHTtgbeE"), true);
    this->FYbSlcqp(string("brcBRmhYoYCkhHDSvEWFkQnQnqeJYXmCCuqqzSsJdrMgSfjvcKsaMgYDmavGJaNuBorpvkmkTRwUHHHOURwfnZsVHYVRRFXGxlwHZABTuSVlidUyXhTArrPNgnHtUPNlpobPVmKegipqfpxnxdjSbikooXxORHlmeKTNIiEmkXyWmJAXzhVLLeSH"), string("CJWdDnIUPtxMXWXqJIvdB"));
    this->ySghO(1436549417, 921733.5556544344, string("DTlbBcSiDvNNrkiOXcxzqAcVUtNVwMGZjRaxviDLSJMlKnJlanWpRvVpfTvLxvPJheOSynShytPtqijTLyytxzWqD"), string("smLKfhGbiEDfzuJUKAgruTLSwAUohUhbJdjTYQOJyxzoesEXaTGfGTfGGTgWdjAWBLzDbVcckqzqgpnvIOnLWoURLxSaVNTGCbUUcBDAGfOPiHnOoXRlJkJxpfUxgvkXWDNieTZhwDuvoSOWftOgAZyTNJaaRUaTkzHwUUDrzflncYclWIQoXXQYKFyiShyVzXmMJSCcHYRKuGErqfiMY"), false);
    this->bhHtrbZGPS(string("fJgItNNTdYPSMoybLYCnSqVuSBlIfAxxojOWjjBBnubELrwCIhpGLqdvPRbjAJruxmteWOUrhWZWCoCtjbJnXqgrybpPvazeFBgdJRfPGUeycUTJAOLBAjTsnfXgXfXkPGOveyEDaFxfLGjVpLhYBSpMyvndFxWXTxHHgrRLGytMHbsVqwxRpaPjLAlhlobonLmGlyUOPEhMbELVVuYEakarawOvXvhqPZsuxAwdkYiMBtMCbsostrI"), false, -1040473.8546543632, string("amsXKEibfcBSLWqLeeSEbVXQyAaxmqlaGitzpidOhxLzDyWRCZWWVrTyrApoLeuaZhuEdqblFsOZvUzIzPBgYgFIntdxXRzdvcjaFBRuurXaWjTLjaYTSsqbAFsHIuEiHDzttcvnZyqptdJMZLRKNBBzoUCuZWgpYVSMDhwZaldoOhZVDMQDyhLpKkRvZSllyKewJyVPPCnoPkUghdhwvXlhwEADLeUDphG"));
    this->rjzHzMzlOjEjOgp(true, -301163518, 409833.7719187282, -906973762, 650672.1330185065);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pRwuZ
{
public:
    int AWabBXLHt;
    bool DxzejkjA;
    double WksapeBNGgKEQ;

    pRwuZ();
    void mcEHIkfGNI();
    double kZqAQmm();
    string gDqhczreTFLhBfTu(string yaAQiMlug, bool JqjzaoNPZc);
protected:
    string dNAIIjHxUU;
    string fCeXYpwxrakV;
    string MCseZphex;
    double rYQgAGWe;

    bool pZhTuzlcNCaWevN(double eXbwLryY, bool PexxtqG, string GZPoVG, bool mZmmEKMJUms, double olYeTWrokKDzQoxc);
    void isvQymdEEp(string xplGBKhXtiHrSs);
    double rXflDuZQlZcA(bool KmhYxLv);
    bool ZLQRZyMmeCy(string FmsxRRkRIOHnhdo, int WzNStVfsPTHXK);
    int HKojYzoF(bool wMchF, int pdgtk, double cTPeEmjxOq, string UQwZqNU);
    string cnxqSTiVv(int BKsbQLNwprN, string tbqauFkCaI);
    int aKGbnPWSVNxC(double ouOCCRrkRzIvIf, bool kCAscjrCPiZ, int YmMsSNgIWbATcv, bool yuCDpSOfWVooh, string tqcEKQFmbTfE);
private:
    double bJEEyIdTXUMGxy;
    bool usjUwrbpHBHU;
    double mwrxgazXsCrIorE;
    bool qGXaNoEB;

};

void pRwuZ::mcEHIkfGNI()
{
    bool LeqEifL = true;

    if (LeqEifL != true) {
        for (int NvHSETkSkLHPptJ = 1320126970; NvHSETkSkLHPptJ > 0; NvHSETkSkLHPptJ--) {
            LeqEifL = ! LeqEifL;
            LeqEifL = LeqEifL;
            LeqEifL = ! LeqEifL;
            LeqEifL = ! LeqEifL;
            LeqEifL = ! LeqEifL;
        }
    }

    if (LeqEifL != true) {
        for (int cwVEERRigKvCgO = 805223218; cwVEERRigKvCgO > 0; cwVEERRigKvCgO--) {
            LeqEifL = LeqEifL;
            LeqEifL = ! LeqEifL;
        }
    }

    if (LeqEifL != true) {
        for (int keJMZNbbSyjrdxg = 1870354157; keJMZNbbSyjrdxg > 0; keJMZNbbSyjrdxg--) {
            LeqEifL = LeqEifL;
            LeqEifL = ! LeqEifL;
            LeqEifL = ! LeqEifL;
            LeqEifL = ! LeqEifL;
        }
    }
}

double pRwuZ::kZqAQmm()
{
    int yeAjdmwSqwxcfQVC = 280940450;
    bool ynFsAvbTFmQDjWLR = true;
    double msfNwCfzasrfuIZv = 215169.69630933795;
    string rZpVSENEV = string("KxJfYcOdgVTIbwCbBCvkWayVbVUAKGXdJNkrdNlvwkSdtTjnne");
    int tArIIyAWlXnvwW = -1911099956;
    int lKBjVHRMJ = 1583982222;
    int HoxFw = -1566179243;
    double bGioHYV = -495436.39391201583;
    string JKszoByTcaql = string("qTNwnoeNFMTzIiSxEBrRbdDPXrbOtTMtUuqbOhMKfvOGoVrgzdGFIWTZBNsaxmSIxTpDzPTEMsAtWfnuyixjcnJyeDtXZOpUZfpHKhzhaQxkROfmvW");

    for (int iXRobCyIwSgIZc = 212604402; iXRobCyIwSgIZc > 0; iXRobCyIwSgIZc--) {
        continue;
    }

    for (int IIrTYFYQKr = 994611522; IIrTYFYQKr > 0; IIrTYFYQKr--) {
        JKszoByTcaql = JKszoByTcaql;
    }

    for (int vuCDXIfj = 1486239489; vuCDXIfj > 0; vuCDXIfj--) {
        msfNwCfzasrfuIZv -= msfNwCfzasrfuIZv;
        yeAjdmwSqwxcfQVC -= yeAjdmwSqwxcfQVC;
        tArIIyAWlXnvwW += tArIIyAWlXnvwW;
        JKszoByTcaql = rZpVSENEV;
    }

    return bGioHYV;
}

string pRwuZ::gDqhczreTFLhBfTu(string yaAQiMlug, bool JqjzaoNPZc)
{
    string hmbfgBNNfwbP = string("ZfpKfNAVQNUffbZjfEesGIOlseDWcapDhRPOueDUldJEFxirfklXZlnxvjHFZbherfHUjSzibsZeuLOsftWEBvPXqygwKfdPEDOGaFIYLWdZCekFIvNdRgHZVuiGcknPFhWbYHsDOcVwAsPKytpGAEdTeiRcNhCdAsBLgiCRIiKY");
    int LKSiLmARPnWufrxh = 1397992662;
    int DCrqwOVKj = -512894248;
    double bLoYsAVrZZEZljox = -816509.5589557097;
    double qDuLRKXOx = -496980.9465633622;
    string abLtUEd = string("mDmSGJeAknlCxrlvzywIIyXezjDkRKAoXwbxXWLLiyiZJsrWCsqKRmLjKJKPjMnspaDZDvziZbAdYloXkCeMiEAjWvHpCwFZmxMBFYkqSaELBLGXklSJmoYPXVwvWmeHJOvfYPqlNEuYwJozSAnKSKKDZFXXjeahPnScDVJqeoACbFKeYRaHiLsrGnYHUEodzjsvXlKXVPRrVCWQCIqLLHSViyqYD");
    string BPNbtJA = string("uzYGKFLVffIiRsjZhvdexBrtdsXORAgnbrgbEBNBbWLOwlzucJSufcctYzKUDETgyMUnBXiOaRzQKncAIRCNoAhzozLOzJSRzGIIZkIKMBqrhpJEUnQfpcgDcYdRbKizWUJZejbmSpXAlboqcYLwoXZOByzvBQGZeXjuAEDXmPKGVuCTjTGuSuLpDyCFnIH");
    bool ffYRBV = true;
    double vtqUUezxoSKabZ = 547947.788279594;
    double ZWmZMVIjAYMe = 539010.5465514988;

    if (qDuLRKXOx != 539010.5465514988) {
        for (int eBlLqLBgcKP = 363837473; eBlLqLBgcKP > 0; eBlLqLBgcKP--) {
            abLtUEd += yaAQiMlug;
            hmbfgBNNfwbP = BPNbtJA;
        }
    }

    for (int lRCAGuBbGLZRzV = 420628908; lRCAGuBbGLZRzV > 0; lRCAGuBbGLZRzV--) {
        continue;
    }

    if (bLoYsAVrZZEZljox == -496980.9465633622) {
        for (int EEVmyc = 573213431; EEVmyc > 0; EEVmyc--) {
            continue;
        }
    }

    if (bLoYsAVrZZEZljox <= 547947.788279594) {
        for (int RrSloCmNuk = 1444893453; RrSloCmNuk > 0; RrSloCmNuk--) {
            JqjzaoNPZc = ! JqjzaoNPZc;
        }
    }

    return BPNbtJA;
}

bool pRwuZ::pZhTuzlcNCaWevN(double eXbwLryY, bool PexxtqG, string GZPoVG, bool mZmmEKMJUms, double olYeTWrokKDzQoxc)
{
    string wHTMsJZyPKKbxQ = string("uBnvlvUdLAYxNteEZyMnJVcYukKWwAfrSQoNgYFkoxCKhsBSglDGHmuqZJvUIbYJkgPDiuBByAHlAueaSKBqORdYEgWZMBviLlWxjAXyQGTjPhenCLjRWJxfFCIWjtDRMAOTNRYmJKaLwOrnNPgKvaLrhQVMHCZySFljCgTEVyuAQLwHMMsLxJClkfzNsTPAjchGMCSnLCFUhVekKGsXAoviUGcstHTqDZFYflcnxkFYABDSKnJuxJnCTIfgDpA");
    bool sbSvOWyxVxWtbKbi = false;
    string eVAVi = string("acMsGYtrIahAFtWGfDYcSgqMKSIeGnDsBuhrbNuEbjWVwvxCsmZMuByyxVOcvhCTVqtWixulboFyiLftEFCDBr");
    string acPuRiiepMUTcdIV = string("MbnWmBToitwugyDQhQhwKzfndwoqPtUqMafdPDxtlCryKxHyLaJFBmdOrlkcoJlpyaTsxtACRQfXWvhcgEWFVOrivpBpURNgVxXJGDbJSSMNllvpFfZcIkejLYzvzxHahNWBypcrhPxpbJoqPqlsNZvHIwdDBboyLwDzgpOXBrOxdQiXKONMpxGDAsmrLliGSlnOoridvWaBcsrpCfzGohfIpxiKHzLEIohDJLFjmNiQKgJZ");
    string nyOxqi = string("YaytOiHXZbhNTbQLByxgurEiWqrOBmUOcYyCPiGJtUrDgaDrsGkKuGaCyEsFJLoKQyqPBztPqQFYCGKDwbTkfsqPUGtWixylEJvKLMfbVZUBnGdyCftVQoPzeuQUSjUCasaKvKnWlDBzIZHRdnWTnIPUQpOHWywHetZWhXyJTlQIWuDSnCKDuCwOOFMcaadPtlwAXNqjGthylBzgpvnZLxQETcXTDhneQIGFSZhrMUOqQtUSIAYLZpOkKKd");
    double WgWxVEbDchuJcSG = 153524.95660335995;
    double gZwZDtn = 22797.918241601285;
    string vZMvNgfdvmP = string("hpRsatVobzIeRBGyNkdQxIbLICeWcqzyEBekgVSAHkttRzKBzRwBsuDZoguxoZoVaITSHyZoEGsBiupSrIEDOJquTqJVbMSJLThEwfKCJdajDNgjvfRddSosTMNxuEeZajdYQQYPkx");
    int cGbSGUuAtGfS = -1479659443;

    for (int mHuYBnjghUrBfBiq = 2005271294; mHuYBnjghUrBfBiq > 0; mHuYBnjghUrBfBiq--) {
        continue;
    }

    for (int xfECAmlrjKiGnFJF = 1693170289; xfECAmlrjKiGnFJF > 0; xfECAmlrjKiGnFJF--) {
        WgWxVEbDchuJcSG -= WgWxVEbDchuJcSG;
        GZPoVG = GZPoVG;
        mZmmEKMJUms = sbSvOWyxVxWtbKbi;
    }

    return sbSvOWyxVxWtbKbi;
}

void pRwuZ::isvQymdEEp(string xplGBKhXtiHrSs)
{
    string nFAGlpHrliMnAxjK = string("QmuaNdFBQUtdyCJPmQzhyMWuuQNUldoMZAiUytbhKzSiDZlhvPugoYLsHMhnQIDOKmVsstsUqvRVElgIiqlWiihWdkPSrITwhRAaEkbyECwNMsuDTgQToYhPgVpBDvsHjqanoICsrKUHsjIJtdiBaAljHd");
    bool EjPHiKLkaYWYepy = false;
    string eQorryJx = string("amRrDFiqBojeFcbJpRoUEBKwtlPgXmFVcugPGbedylaeMscYuAWXFKNTRawqPjdXebmxOLrhxyCpEjfOOAXLCqKbgfaNNoiRFkdxvh");
    string GTpJTpVpyGTD = string("NTrQvXUIVpNVRzNaQYEsxitnUnspffaMfGRoRieWPjjeINAMEmkRPvxzAfvVQWsiFcPMHrLiDpNImPvgRYJHdmhWnUmuirGCzpANDJsnRULrPBjoqTgNLNvMCLzX");
    int dCwQmeSco = 1094703599;
    double CgcatTBeDzK = 314809.7518100337;
    string xvoAtti = string("XpMJylKTdkuAAHqLqQaqoNukziCzvBjDjiCNHocxYiwgZGkQWifhNmDmZNIkpJPwSiVSwZDFiyfUDMapPQmCeRqfVSOVbBQStZeXhoO");
    double qXUmUs = -774636.7870759356;
    string EbMblIWjfi = string("ofFpSQuOQCRkZlRKGOaViIXqxnoTUnDzvqPAwDrcmoDOxzeDnnHClTFPhYcjuS");

    for (int ulFKHytYGgrDdUHQ = 1039709579; ulFKHytYGgrDdUHQ > 0; ulFKHytYGgrDdUHQ--) {
        EjPHiKLkaYWYepy = ! EjPHiKLkaYWYepy;
        EbMblIWjfi += eQorryJx;
        xplGBKhXtiHrSs = nFAGlpHrliMnAxjK;
        qXUmUs -= qXUmUs;
        xvoAtti = nFAGlpHrliMnAxjK;
    }

    if (xplGBKhXtiHrSs != string("XpMJylKTdkuAAHqLqQaqoNukziCzvBjDjiCNHocxYiwgZGkQWifhNmDmZNIkpJPwSiVSwZDFiyfUDMapPQmCeRqfVSOVbBQStZeXhoO")) {
        for (int RDSpfmXt = 1122291323; RDSpfmXt > 0; RDSpfmXt--) {
            CgcatTBeDzK = CgcatTBeDzK;
            EbMblIWjfi += xvoAtti;
            xvoAtti = eQorryJx;
        }
    }

    for (int rfBTQGjSuDhNgbE = 797822949; rfBTQGjSuDhNgbE > 0; rfBTQGjSuDhNgbE--) {
        continue;
    }

    for (int CpEvdU = 840856324; CpEvdU > 0; CpEvdU--) {
        eQorryJx += xplGBKhXtiHrSs;
    }

    for (int cggBKoclyZUX = 1761488360; cggBKoclyZUX > 0; cggBKoclyZUX--) {
        nFAGlpHrliMnAxjK = GTpJTpVpyGTD;
        xvoAtti += xplGBKhXtiHrSs;
        qXUmUs *= CgcatTBeDzK;
        nFAGlpHrliMnAxjK += eQorryJx;
        nFAGlpHrliMnAxjK = GTpJTpVpyGTD;
    }

    for (int DMNmxWkxYp = 2073306813; DMNmxWkxYp > 0; DMNmxWkxYp--) {
        GTpJTpVpyGTD = xvoAtti;
        dCwQmeSco += dCwQmeSco;
        nFAGlpHrliMnAxjK = GTpJTpVpyGTD;
        nFAGlpHrliMnAxjK = xplGBKhXtiHrSs;
    }

    for (int eszRhsgdDF = 225743826; eszRhsgdDF > 0; eszRhsgdDF--) {
        xplGBKhXtiHrSs += nFAGlpHrliMnAxjK;
        xplGBKhXtiHrSs = EbMblIWjfi;
    }
}

double pRwuZ::rXflDuZQlZcA(bool KmhYxLv)
{
    bool OQJzyltTDHaq = true;
    string RWJyQFX = string("RQDPkclOpQUvPPyzqVANAYqweAuUBhkxYOgYNdkRRZWHoYibWKPNNBDVlIXSqDlDBScwVGZwqYUiskFfdliGyELogeQuFFIqETMGwqfwYGrEyZiVUUnWpwTBroIfQNBNGhRZOSVLBuAlxpMnryfdfNeCPviBKCynrEQMIsiKQTyNvvxcDGTCcSKjJYAWtZvJodSlzRlUdeVGoDZKfJGnZzAqKNmEbcGJJKeDPiUT");
    int YPvAkeUOskL = -1920703813;

    if (OQJzyltTDHaq != true) {
        for (int COooTynAYSf = 1469874051; COooTynAYSf > 0; COooTynAYSf--) {
            OQJzyltTDHaq = KmhYxLv;
        }
    }

    for (int KxCeJSdrD = 593352174; KxCeJSdrD > 0; KxCeJSdrD--) {
        KmhYxLv = ! OQJzyltTDHaq;
        KmhYxLv = OQJzyltTDHaq;
        OQJzyltTDHaq = ! OQJzyltTDHaq;
        OQJzyltTDHaq = ! OQJzyltTDHaq;
    }

    for (int evSWndtcmWNfwA = 1500747216; evSWndtcmWNfwA > 0; evSWndtcmWNfwA--) {
        YPvAkeUOskL *= YPvAkeUOskL;
        OQJzyltTDHaq = KmhYxLv;
        RWJyQFX += RWJyQFX;
        RWJyQFX += RWJyQFX;
    }

    for (int oioPflKLXTNBc = 202200383; oioPflKLXTNBc > 0; oioPflKLXTNBc--) {
        OQJzyltTDHaq = ! OQJzyltTDHaq;
        RWJyQFX += RWJyQFX;
        RWJyQFX = RWJyQFX;
    }

    return -1021670.58776391;
}

bool pRwuZ::ZLQRZyMmeCy(string FmsxRRkRIOHnhdo, int WzNStVfsPTHXK)
{
    string nVlFj = string("rUWeJGvbZmVuFgzKhOSJBJkmBUkwRKDaAeZcplyfzvkHrZiZWyntWVonVFlkwjZlfQKNWkXbSmcKQlTretgHSlFFBFOuupsYunkaWcQmDeFifCvodVRhTbxnFDyaTEVRA");
    int wFRyYa = 375690241;
    string ktUlRoosHPIiuceX = string("uTbUrDCrUQknEKRMJoATcNPbOPaCSKLKAmSbAU");
    string weLSEammfIOLlX = string("dyefRTUmEGeQpYrglPOZCGruXFmiAlfhhJjkdiHqFvrWYuOzgfOvcnLWVMScCaCdQeCOlCHMQCJAUrQZGzvrlHypMaxGKVHwhdBzObayAkunKXYeTIssRllmSIOSRZlPHYuIzzMCWxMNidL");
    string KYjsECUAgyREa = string("wPiuGUiIuFqZLOmsTqtImmVAdqjyDvIrKGbHoLvMCoBSDsoetXOqoYdTJMfDyXZrtXHNeVFvgqhbidJMBKbRbfjPRFrZAAYkqQuvqvNNtueeEhOhnBIkyJ");
    bool WUBVENl = false;
    string WeEOlwujf = string("WdsxhmnAjaTCsIUXEKdibMrwghPoftcwiTDPSLYIEWAjnlCXXIodbNHwVoylqkfsTXJrrabEkhcOdbqfCgVhuLziSbZPZxlRRERTwYZiCg");
    double yNXrwJTCi = 241919.85169001448;
    string YPXFbka = string("LaIAyAvswrUgyKikWFPnPoGtTwINQSzBQvGmBMIyusquDkhhjAHLKjXtjpLNWutAjZbiuKwWuRhQIYLEQrjJLJxSkhuiUZHdfQXwLPGHagLHgCYWwuGTqCJZMbGrgEhBjwJvjnlwoSIvMrlgkhZcDvOexVtRuPzfLugavyNNMfQzsEcZJqzvYsyFculKUQdimimCTnZgUtVIDLWHIBrp");

    for (int bQJnsXUzceNLQFMJ = 735622748; bQJnsXUzceNLQFMJ > 0; bQJnsXUzceNLQFMJ--) {
        WeEOlwujf = YPXFbka;
        WUBVENl = WUBVENl;
    }

    for (int qFsMUsmaiOpw = 1603682005; qFsMUsmaiOpw > 0; qFsMUsmaiOpw--) {
        weLSEammfIOLlX = YPXFbka;
        KYjsECUAgyREa = FmsxRRkRIOHnhdo;
        ktUlRoosHPIiuceX += ktUlRoosHPIiuceX;
        ktUlRoosHPIiuceX = FmsxRRkRIOHnhdo;
        YPXFbka += YPXFbka;
    }

    return WUBVENl;
}

int pRwuZ::HKojYzoF(bool wMchF, int pdgtk, double cTPeEmjxOq, string UQwZqNU)
{
    bool LhAKOnVV = true;
    double NtZfyG = 491758.56156572956;
    double QCMTbvrBrk = 635835.3399035835;
    string kwyiagBixcjjQu = string("yKeMZJeUDfNvCpMZQqTykQsnSGtPpJvpUWKsncSYlwlanTVsBCpcHPFuwYnEFLLEqwrydstsMhySjeBIkqnCAUjzwvtyCcifmJNHMoaHxYcgPzfJyqupzBceoEKHMYdprZvydPdAUIHNWyseuLEWIgTtlNgKSqWfarnNbAOhLvNhYWdgXRbcGuihWUQAbImmfrqRFXDjhnhVPyDagejZ");

    if (LhAKOnVV != true) {
        for (int VudfNnNMDC = 93164735; VudfNnNMDC > 0; VudfNnNMDC--) {
            continue;
        }
    }

    for (int YQkfBtAAwbWJHUj = 865058797; YQkfBtAAwbWJHUj > 0; YQkfBtAAwbWJHUj--) {
        LhAKOnVV = wMchF;
        QCMTbvrBrk = NtZfyG;
        NtZfyG /= NtZfyG;
        NtZfyG -= NtZfyG;
    }

    for (int FClGmUhGLb = 709819034; FClGmUhGLb > 0; FClGmUhGLb--) {
        continue;
    }

    for (int dOVvlLTBKnrhUK = 1726231531; dOVvlLTBKnrhUK > 0; dOVvlLTBKnrhUK--) {
        cTPeEmjxOq += NtZfyG;
        kwyiagBixcjjQu += UQwZqNU;
    }

    for (int VEKKdRhbBlEY = 252985990; VEKKdRhbBlEY > 0; VEKKdRhbBlEY--) {
        QCMTbvrBrk = NtZfyG;
    }

    for (int QGxuLAQfmxNM = 1818264012; QGxuLAQfmxNM > 0; QGxuLAQfmxNM--) {
        continue;
    }

    for (int mMEFFFjGsqIH = 605157809; mMEFFFjGsqIH > 0; mMEFFFjGsqIH--) {
        wMchF = ! LhAKOnVV;
        QCMTbvrBrk += cTPeEmjxOq;
    }

    return pdgtk;
}

string pRwuZ::cnxqSTiVv(int BKsbQLNwprN, string tbqauFkCaI)
{
    string TZkEgTsW = string("IhQKaARNatHnlDgmwkZCUDqnrzdrovaUFHYqsnwiWYtZziGHQQVNjwadmjmUmAXtqiLdGvNjGoYPGqzvbxecGCoDgRIruxFGDPgJnXsZrBt");
    string qubLQbmcJSYhIDx = string("XNyJSZonHCcbSJuaWJArtDIHaIRsMryMVNfQrlyHDlz");
    double HNHQnpmE = -415937.30844168284;

    return qubLQbmcJSYhIDx;
}

int pRwuZ::aKGbnPWSVNxC(double ouOCCRrkRzIvIf, bool kCAscjrCPiZ, int YmMsSNgIWbATcv, bool yuCDpSOfWVooh, string tqcEKQFmbTfE)
{
    double SwVQhwENn = -770646.6166565549;

    for (int sEiBGuscE = 98930565; sEiBGuscE > 0; sEiBGuscE--) {
        kCAscjrCPiZ = yuCDpSOfWVooh;
        kCAscjrCPiZ = yuCDpSOfWVooh;
        ouOCCRrkRzIvIf += ouOCCRrkRzIvIf;
        yuCDpSOfWVooh = ! kCAscjrCPiZ;
        SwVQhwENn -= SwVQhwENn;
    }

    return YmMsSNgIWbATcv;
}

pRwuZ::pRwuZ()
{
    this->mcEHIkfGNI();
    this->kZqAQmm();
    this->gDqhczreTFLhBfTu(string("aXvCvdZOEJBzyxQgGlgPcUITYMXpyaRqlnKszmXRBHvqfyganwxzefiNUqLYTdqEOTyj"), true);
    this->pZhTuzlcNCaWevN(867711.763894333, true, string("yYnwzRHFipfPLzVxhukhVIPvcfyvulQHcLffmdIYHsBiiqWvLbAskBqflWsCvTGZAWYdKKuEJAcYOPSxTXMrDCrBPyliEzQIqCHFZbRg"), false, -1043718.7423554966);
    this->isvQymdEEp(string("jcPIsJUsusSuDrWFdQWGfNmyQrXhAbfPvpseCnPOjCnuKDBifFrFdfGjgkghpsVkdxCWkhmIIdhRcmvPcoVYueMGaLRmgYiWwugOlJgPVdVXDzLtgBDJKSdFFvWyvcfXInDgsLnxFmQeSQfnmBMfO"));
    this->rXflDuZQlZcA(true);
    this->ZLQRZyMmeCy(string("lGMvFoeFWztzASXjLNBCcqgeiRJdbcnmqAFLjuuUJrWDRvtLotKepilukIucjAaCzCcHtiZnzLMKSzOtRxEGb"), 327196887);
    this->HKojYzoF(true, -621674837, 345963.60900188563, string("nPbPXPrtDTrOWVIAXRAmeaqRaYe"));
    this->cnxqSTiVv(-1747405604, string("oDo"));
    this->aKGbnPWSVNxC(-876770.925406378, false, 1357890751, true, string("qoYIQEJGcByPCbtzLUckZTLaMHkMlowIygeBHlwDeyVUYqbzoubKNfIyxXTeyjBlXfyloCLLIgFAWABtaOwpNQUrKLuLMkjdpPImOQBDkmYzGrfevcawiBQJYmgnDnSuduPNdEPDAYIWaxuXWXScxUGdnbyX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PenOWsdFwfHD
{
public:
    int eIZnnctoHL;
    bool dAmdoGvmskVqM;
    bool RpKORAxPoFmilHme;
    int tEhELzoTMAFCVhST;
    bool VrDBkKnyn;
    int GSsWbyV;

    PenOWsdFwfHD();
    bool dKJfMbpHLtC(int CydyGJUFOcyv);
    int fYBapQ(string nDpJtmQq, double zFaHgEMdEeV);
    double UqLlTpSYQgl(string hvSCyWLhFawpY, double HRejOlEEcbQOL, int Tdbui, bool QhrXKPy, int uNUaOgNwT);
    string PvkmoQwAisPuBwWA(int kvTDiMvtA);
protected:
    bool jdbONBkEwDNSTa;

private:
    double KUWBFrFsuHENM;
    double KOHIhBSQqkid;
    int kIDgGDo;
    double COXfYRJaKJrPfvJ;
    string vcsiOYikfghJetw;

    string jaPFJFDDosYJkZE(bool dDMFfUvQyMq, int KtclVBgBGxNUG, int sGPTm);
    int oZnWttrfMa(bool funnXTkBKTj, int TjMGyLJXSopRj, double gTAzTyZuLQEPXWAC);
    double lOcWAKNldUxk(string PixBvOYBmnQO, string DEvWFZAoL, double RDqbN, double DvXbyhIFWdkToZHQ, int nLGAFnbBDztIvScE);
    int GnNQFpdEVP(double sTUrexyv, int mDbaRaNZin, double UfebpdPOo, int uYZpGg);
    string FsDfsZmS(double vBcgZ, int fUbDnWSCoVh);
    double IfRPxhDHeMvXR(bool gKXtRWLOMQmOyY, string WAcvBskMAP, bool nbWmBWbBUP, double tdhIt, int xUvnrOpBZ);
    string ziQMZOXwB(bool fykxeBhHLTd, string iklllr, bool NmBUVsxWLHSmj, double OFtMwHPdRfINgAL);
};

bool PenOWsdFwfHD::dKJfMbpHLtC(int CydyGJUFOcyv)
{
    int WPTCmbCnRJiVnfC = 115711222;
    bool lgPIBpJbq = true;

    if (CydyGJUFOcyv == -427665598) {
        for (int KEkYyCICLG = 115481739; KEkYyCICLG > 0; KEkYyCICLG--) {
            CydyGJUFOcyv = CydyGJUFOcyv;
            lgPIBpJbq = lgPIBpJbq;
            CydyGJUFOcyv += CydyGJUFOcyv;
        }
    }

    for (int mLcgbHLsih = 545658934; mLcgbHLsih > 0; mLcgbHLsih--) {
        WPTCmbCnRJiVnfC /= CydyGJUFOcyv;
    }

    return lgPIBpJbq;
}

int PenOWsdFwfHD::fYBapQ(string nDpJtmQq, double zFaHgEMdEeV)
{
    bool zvbWExBerJoOf = false;
    bool zqZLNH = true;
    int xcMHCJ = 2033107049;
    string KxjWXr = string("SLsrzZWIONRjAePcgRObsoOxrSOIkuisvbAtrpDUMZyumLBLNfsmsnUzUQyLGOWBRpPGpYlXoLOpQsbNAgCXuHeCXxtBgUnkotIRNDvxmdiuhYInpPJDQvAAPhQFMjOygPflTxYNiNUVhLRPhcGCxiEUxMzqFe");
    int ZSLmWVp = 15815227;
    string fuBcHHkwEXuis = string("vKuoTpyDNpOfVQIOHuJqkUKNOaWkqhDlTtDHZsrgMRtrhLmfYvhYvtSeiBWjMJaOS");

    for (int VQaYdzDuZJerQB = 1085170234; VQaYdzDuZJerQB > 0; VQaYdzDuZJerQB--) {
        ZSLmWVp /= xcMHCJ;
        ZSLmWVp /= ZSLmWVp;
        ZSLmWVp -= ZSLmWVp;
    }

    for (int fqwindXIc = 2035960373; fqwindXIc > 0; fqwindXIc--) {
        zqZLNH = zqZLNH;
    }

    return ZSLmWVp;
}

double PenOWsdFwfHD::UqLlTpSYQgl(string hvSCyWLhFawpY, double HRejOlEEcbQOL, int Tdbui, bool QhrXKPy, int uNUaOgNwT)
{
    bool QJzIDHaRqY = false;
    string ZIanVSgyK = string("YSxxLQpmHiUTqgyHhPHhGirQtamPjGAhbpQkmILUDIlIDilasvgcfHAEEBtvuaYfPHRgaUxUyvXoQDjRvHQWxOlgvBdskKBAzKURVLSuTsZIuwfZXoDAKcXslgFMqzCluukrifMjewXwknfzfmGYkkmdHSEeSZNIuxdxRlWpajaQItbHwRqarHIAyBzzwzuJiQJRKrbfKommNNLAWKfVySGMzAkhIHDmiPDdTbrtjPjgMoEMGspjFJnSzjVrg");
    int BmfLwOLEenKzWy = -554996495;
    bool SyYCCuRsTzbglDwX = true;
    string TAxUDa = string("sItobnfsScLGqJNUcRnDFugwBvdlKQnGMcbDpYSzSGOCtIjOEfTomAIHTLrzshbDukczJlaYnPGhzPAGOSqGvTVytZQfOZfsoxznpBPprtfkAWSilJUjqxSnuDBDeXaHWZzquGIRdGiSEMDcDxFgfmJjuelNXEiselCjLOmYrEqSvMvYHb");
    int MVTuE = 148438777;

    for (int xNHTKyjGjVJwor = 1561477891; xNHTKyjGjVJwor > 0; xNHTKyjGjVJwor--) {
        HRejOlEEcbQOL /= HRejOlEEcbQOL;
    }

    for (int pddngSv = 1915644188; pddngSv > 0; pddngSv--) {
        QJzIDHaRqY = ! QhrXKPy;
    }

    for (int rMHtTptfotmVt = 212949627; rMHtTptfotmVt > 0; rMHtTptfotmVt--) {
        hvSCyWLhFawpY = ZIanVSgyK;
    }

    for (int UFXMCnKFLqBV = 2066196896; UFXMCnKFLqBV > 0; UFXMCnKFLqBV--) {
        ZIanVSgyK += hvSCyWLhFawpY;
        uNUaOgNwT /= uNUaOgNwT;
        QJzIDHaRqY = ! QhrXKPy;
    }

    return HRejOlEEcbQOL;
}

string PenOWsdFwfHD::PvkmoQwAisPuBwWA(int kvTDiMvtA)
{
    bool gazsyzEkMpcou = true;

    return string("HTwFeTCKTuKTbwNFyLGSTIUvcfmWkPZupxSFBcNEhGhrvIBuIRHPfveZLSNWuWnZelTpimvsxqpxQW");
}

string PenOWsdFwfHD::jaPFJFDDosYJkZE(bool dDMFfUvQyMq, int KtclVBgBGxNUG, int sGPTm)
{
    int uAxPn = 905191300;
    bool tbnBTXHCfFTbMHzy = false;
    bool MMunte = true;
    string kmqlRMu = string("JymhZwLjodaOzDgqcQBYEYfVhlTrUSKFgcETFstQUjESnHjWZAxEsJrIvCsIqcLDShlHDUrumRGmNWrWRLhVgRinihHhCbAXNdrWzawXfbSGPDezlDYeECVNeSvWoJcCryGiGgdukLsHsNGYMHAIRcgPJjcTmS");
    double nByCHtZiP = 476327.4618557588;
    string FSXYWFIJV = string("cAeyhHlFpKmsqnSigkRKutSxIjzudHADypSEcbdibYnPhcEQfzMByrfvBSvjCPItgPrSaaVAnRCHQLhdZQJxZgtQuyTlbZLpLkaIjwWvGmCUKMVbECteqtRMPaXsBtXmcztRwsdqGsPIRNxwpVx");
    bool ONeQxaDbewEnFP = true;
    bool ftoYqnUiZjqwA = false;
    double PkGtL = 832331.7138194771;
    int ZGJmlKMdMDKrdtWn = -1089090327;

    for (int QlJmOwt = 77292015; QlJmOwt > 0; QlJmOwt--) {
        ONeQxaDbewEnFP = ftoYqnUiZjqwA;
        ONeQxaDbewEnFP = MMunte;
    }

    for (int OVhys = 375850321; OVhys > 0; OVhys--) {
        ZGJmlKMdMDKrdtWn += sGPTm;
        tbnBTXHCfFTbMHzy = ! MMunte;
    }

    return FSXYWFIJV;
}

int PenOWsdFwfHD::oZnWttrfMa(bool funnXTkBKTj, int TjMGyLJXSopRj, double gTAzTyZuLQEPXWAC)
{
    string LlgZPl = string("tXIjQkOJUflUTvpVPvvNrpYVnXacKKZgiSHtxabvVYolMvpPsUZuvVMZZEwuvGhSkfYVhLQqditucxQsCagmOiYzPsAf");

    for (int qyBJyCTNQzEfsUa = 1337356834; qyBJyCTNQzEfsUa > 0; qyBJyCTNQzEfsUa--) {
        continue;
    }

    for (int aYVxRY = 292840738; aYVxRY > 0; aYVxRY--) {
        TjMGyLJXSopRj += TjMGyLJXSopRj;
        TjMGyLJXSopRj += TjMGyLJXSopRj;
    }

    for (int HyZvONy = 121235137; HyZvONy > 0; HyZvONy--) {
        gTAzTyZuLQEPXWAC = gTAzTyZuLQEPXWAC;
    }

    for (int VpJoQmG = 2034082067; VpJoQmG > 0; VpJoQmG--) {
        continue;
    }

    return TjMGyLJXSopRj;
}

double PenOWsdFwfHD::lOcWAKNldUxk(string PixBvOYBmnQO, string DEvWFZAoL, double RDqbN, double DvXbyhIFWdkToZHQ, int nLGAFnbBDztIvScE)
{
    bool bLzFRljAPeFdJHvO = true;
    bool ETBGLjJEmOmjdV = false;
    double auVnro = -534489.8781267819;
    double xwRvv = -1025711.1631165212;
    bool yLzyReZJH = true;
    string FWBNEWjdU = string("DGliuoJfBvRaFrPGYhwOi");
    int dOgQlHY = 1861578030;
    int PudlIZ = 1283830938;
    string BErxGvflCs = string("BuvKPqvVQrIJTzONtxIqCjWcqYfIzjjfSfMSWpgUhUcIsWfKuXyyZgPFzefjHGykWfIesvLgZOOyaMfMVlmaxqIVjbodXBTPvERxbokKNbCWQfrOxVBHPnreZRrDyeydNWZNEMvMjRhoOabnu");

    for (int VCAShAdaE = 307090944; VCAShAdaE > 0; VCAShAdaE--) {
        xwRvv *= RDqbN;
    }

    for (int wckbr = 1343733474; wckbr > 0; wckbr--) {
        xwRvv -= RDqbN;
    }

    return xwRvv;
}

int PenOWsdFwfHD::GnNQFpdEVP(double sTUrexyv, int mDbaRaNZin, double UfebpdPOo, int uYZpGg)
{
    string sFirXcUtpRAGUeQp = string("wNbiLzbzvrWdvRMIHBSGDQRCauvHKfegrHvasDQArulDJMWiFNBvVggnyZlEwUMOrUyWpjomjhMjHdlXXEybxnsVKzHfgFhAByHyvlYpXLMUdyDqJzZEzCTAGdWazWmATflKIQdfQoqMWGaNwOAMHgWhtxSjFpZGPfUlLraWljsGgstPfwRBGNrqNxmmxHqpvzmkFRUgIPXDCJQxvpsavxPMGAZCxNpZgjtECAYaEuHpeMZRanN");
    bool gHzsNT = true;
    int JAviUGFXubacvRij = 828984642;
    double nKEKqHiW = -847163.5622275406;

    if (mDbaRaNZin != 828984642) {
        for (int BApqWS = 1835915204; BApqWS > 0; BApqWS--) {
            mDbaRaNZin /= mDbaRaNZin;
            nKEKqHiW /= nKEKqHiW;
        }
    }

    for (int MEyAIATklQq = 1893829612; MEyAIATklQq > 0; MEyAIATklQq--) {
        UfebpdPOo /= UfebpdPOo;
        UfebpdPOo += nKEKqHiW;
        UfebpdPOo *= sTUrexyv;
        sTUrexyv = nKEKqHiW;
    }

    for (int EfzgUFW = 387027865; EfzgUFW > 0; EfzgUFW--) {
        sTUrexyv -= nKEKqHiW;
    }

    return JAviUGFXubacvRij;
}

string PenOWsdFwfHD::FsDfsZmS(double vBcgZ, int fUbDnWSCoVh)
{
    int bYtdBTBjy = 1085287499;
    double aWXIegcIRM = -335480.86720258824;
    int YnKmvjb = 1877493464;
    double GPSNXiycvkOMkF = -277215.1401529285;

    for (int GzmGTMR = 173839267; GzmGTMR > 0; GzmGTMR--) {
        bYtdBTBjy += bYtdBTBjy;
        bYtdBTBjy -= YnKmvjb;
        YnKmvjb = bYtdBTBjy;
    }

    for (int zYibV = 2093036542; zYibV > 0; zYibV--) {
        fUbDnWSCoVh += fUbDnWSCoVh;
        GPSNXiycvkOMkF += vBcgZ;
        YnKmvjb = fUbDnWSCoVh;
        fUbDnWSCoVh -= bYtdBTBjy;
        YnKmvjb *= YnKmvjb;
        GPSNXiycvkOMkF = aWXIegcIRM;
    }

    for (int gjzTFSsbTY = 1374555668; gjzTFSsbTY > 0; gjzTFSsbTY--) {
        aWXIegcIRM *= aWXIegcIRM;
        GPSNXiycvkOMkF -= GPSNXiycvkOMkF;
        fUbDnWSCoVh *= fUbDnWSCoVh;
        bYtdBTBjy -= YnKmvjb;
        bYtdBTBjy -= fUbDnWSCoVh;
        YnKmvjb *= fUbDnWSCoVh;
    }

    return string("EcTZfjwfAnROuNLRVWGCvFGDKXQszOgnUHpozqZTMEneHZBMJtpVgwbpnevjwVi");
}

double PenOWsdFwfHD::IfRPxhDHeMvXR(bool gKXtRWLOMQmOyY, string WAcvBskMAP, bool nbWmBWbBUP, double tdhIt, int xUvnrOpBZ)
{
    string pbjUXRACNicTNp = string("kdjOXOMWfnpIVeWUDhnxSaHqcrlkhHjdlhVbCgtHtFTgNhCDULmqKzvgaviXW");
    int SlQqP = 1140179210;
    bool DCsdsw = true;
    string AcJWIrgSgVVjTpT = string("nNzJDNnFApRvXWpUdrmTTstwkOUmRBDXsCjzSnNsveLNbMNtdjxIqXhuHfzPiFIoBMyLvenxtsEGNztKrKMyQyKsDBDEpNUHvBmredRYbAW");
    bool GOAPNytDH = false;

    for (int fYnpqA = 1136938661; fYnpqA > 0; fYnpqA--) {
        nbWmBWbBUP = nbWmBWbBUP;
        pbjUXRACNicTNp += WAcvBskMAP;
    }

    for (int GxQdMSVyLGstcgQ = 1659206979; GxQdMSVyLGstcgQ > 0; GxQdMSVyLGstcgQ--) {
        nbWmBWbBUP = ! GOAPNytDH;
        gKXtRWLOMQmOyY = ! nbWmBWbBUP;
    }

    for (int gRtqUHDXMqoNt = 1758808345; gRtqUHDXMqoNt > 0; gRtqUHDXMqoNt--) {
        DCsdsw = nbWmBWbBUP;
    }

    if (GOAPNytDH == true) {
        for (int qYANgvsRBoJY = 402403329; qYANgvsRBoJY > 0; qYANgvsRBoJY--) {
            nbWmBWbBUP = GOAPNytDH;
        }
    }

    for (int sUtCldnroBg = 1510007098; sUtCldnroBg > 0; sUtCldnroBg--) {
        DCsdsw = ! DCsdsw;
    }

    return tdhIt;
}

string PenOWsdFwfHD::ziQMZOXwB(bool fykxeBhHLTd, string iklllr, bool NmBUVsxWLHSmj, double OFtMwHPdRfINgAL)
{
    int VMJqalFRvfZZYh = -2061251446;
    bool DBWdnX = true;
    int GlXZsoTa = 1095162732;
    int miMqkeOLXuZALhk = -1439575981;
    double FnLXSbPVkKXya = -304570.0822641328;
    bool mCRPmnt = false;

    for (int DTIdY = 1573877780; DTIdY > 0; DTIdY--) {
        continue;
    }

    for (int BeZquK = 1996418523; BeZquK > 0; BeZquK--) {
        GlXZsoTa = VMJqalFRvfZZYh;
        mCRPmnt = NmBUVsxWLHSmj;
        NmBUVsxWLHSmj = mCRPmnt;
    }

    if (miMqkeOLXuZALhk > -1439575981) {
        for (int dEXzYHXUndqqRF = 684132036; dEXzYHXUndqqRF > 0; dEXzYHXUndqqRF--) {
            FnLXSbPVkKXya += OFtMwHPdRfINgAL;
        }
    }

    return iklllr;
}

PenOWsdFwfHD::PenOWsdFwfHD()
{
    this->dKJfMbpHLtC(-427665598);
    this->fYBapQ(string("gjfhcsnxYSbGdQWYxsHpuuegHjoPFRtRLJCYaGwtlOEdQlnsafgcWvOViKxMQcLiQ"), -223070.30873140768);
    this->UqLlTpSYQgl(string("murPBp"), 988488.3948240267, 911227950, false, 265917712);
    this->PvkmoQwAisPuBwWA(-1492999941);
    this->jaPFJFDDosYJkZE(false, 1940498079, 640252244);
    this->oZnWttrfMa(true, -1781083234, 383397.59728599084);
    this->lOcWAKNldUxk(string("SNoIlYeBfwePxiIqHPmTYXISUNazcqIkTDaoHMJRuANQrYYBLCXAsOPHDGgsRYeZOCEqeiHFYYxrinDtSgkpoPZZPCFEmFxOVpbCPBWbPhujGrTPtgTSIqQwyTcyshmykQOzGcuQBVSzTaZgEvedwrvweHodwZyyxJOqEcpStlmZqVxNAcEdOVQYauzIrEoOtkqdAVzsSobgFdCnCOkxGtnalKrtECyPMbyYErUrOCZbkYgZvwhLlIHmz"), string("QaQqzmspxZjpijSkypflATwAkyIVQxmNTqkscDvbQTkDbsRwqxrbSWNJFqahjIFPFdbMyNSEDgqDhOtDLscsiAAsHfqGjQKuCTuWxqSeUzwVdgQhzLDkgEkZOAmHfNLFqxMpYRgz"), -212309.0209439499, -905972.4761731317, 460146975);
    this->GnNQFpdEVP(-734426.5576584435, 948478199, -742817.5572556795, -726426442);
    this->FsDfsZmS(665551.4032312256, -2018751198);
    this->IfRPxhDHeMvXR(false, string("gfySnQnWrCrFmszNuaYmDhffbDwoeujiutTuivYEmWNbtVDnknoUHLZvGwndPLjoepCmrBiHxDfqIJA"), true, -572364.3875804313, -1416811224);
    this->ziQMZOXwB(false, string("MUdTLwHzBtIcReRwcczDFWvKieXJEFAQmIqTUURTdwAnCWcMEPABEdzkWAidOhKmHNlhtylOMkNYrYvMBDusZWyifyMnXJWXAfnDNUFrGmSyErncqfmfoXPscQdYadzJMukOCkSeWAORznkQlTXuORBhnFdpmXZzikrCGxWHiqGLBpPYmpcsnYAJwINePuEHXyYHW"), true, -909373.5627140444);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class awEyJQC
{
public:
    double ktdoefvFCSw;
    int lDHHWGGS;
    double ENgxEeFqqhii;
    string YrMbyw;
    double OpNWNvelud;
    bool lZDksAlLUMv;

    awEyJQC();
    double nTAzTWdta(int sVdYrdCMUaTg, bool thtvuZhiCEGj, int dvHtzhQegU);
    void OYooIKmrDGqZ(string sNQzCHQcJ, double nrNOl, string gTlzqSyWhlSChgI, string jVoswSqU);
    bool MNeCCuW(double muGZmxprmdoWow);
    double sGYgRhNutsX(bool tpTbIsv, int VybrmXKwdKRayoB, bool hGSrQO);
protected:
    bool TgaHaziUrofOIUbp;
    bool oXqmx;
    string RZlEcUmyydOgnxG;
    bool YwcrQ;
    bool GmRNQcEgTcV;
    int Phjvu;

    double fEoCNfWTIcHHsWyE();
    string duCaIcnWUiZCe(double cqWfaLU, int UOmma, string uKSEGSpAl, int dcVnOLgmnlXzjYVu);
private:
    string IINOuOIjL;
    bool vicIAnWg;
    bool uNVqDXy;

    string qLjlRmHMeJzg(int SnkkrYYf, double Grifxlnv);
    bool pcyaFcdugFgCiYsV(double yjRDvItBiwP, string ktQhaIk);
};

double awEyJQC::nTAzTWdta(int sVdYrdCMUaTg, bool thtvuZhiCEGj, int dvHtzhQegU)
{
    string sQJbWBk = string("qdrfbipflLtyGehxswtwNZTTeSybbRfojVxWXJUxYOJVCWVpKQkqUCQWOenrHgG");
    string PPVLpwtyV = string("eYUptkjJmzoWRpDQjzyMensFbzPUjqbNnhtyCkgYKMkTPLqfYMznxEbySrhzXHdhToidnlcRorNIoeQhDEavHbcGzlkMeKRnQuqEKkSlmiskQtGrWJhxBxixhR");
    string qLvhsi = string("NFiXdPcEJjVdFBGGbkRKuXSxKKMvzkKNfdgyUyZduzaljUIdbCzizfWNGpDaYQvJBvRhzldRlTJagnWSdxuSvFnrYbDugXsNUfJuRGKbBxXfUTUgLTGNpGJahPRhkizwZwvYIgqHEAkCDIpqDpATswEFtlWSQHzFTcxthUeVBCtSgccGigttilHHYdykktyeHgXrsYkXlNHb");
    bool pJoGJHgjeJqtaowx = false;
    bool MZmWEDBiiGPTxj = true;
    double IprUFHTibiz = 7645.5220694433265;

    return IprUFHTibiz;
}

void awEyJQC::OYooIKmrDGqZ(string sNQzCHQcJ, double nrNOl, string gTlzqSyWhlSChgI, string jVoswSqU)
{
    bool lJgGv = true;
    string fTmHhZjYWUaBJ = string("HZbrMjWHvlTPFBDjHHILdGVHOddbUfmZItCodIxTRMSvfoAzxKZIlOpOyMzuRUjoXZv");
    bool UexyTafo = true;
    double SeiZL = 636542.7597082824;
    int hsgnnFT = 427667295;
    bool TKxHRkcJiiAJxV = false;
    int kvllZlUCFz = -285429489;

    for (int NjmHBWdR = 484860635; NjmHBWdR > 0; NjmHBWdR--) {
        continue;
    }

    for (int HqxyRY = 817972768; HqxyRY > 0; HqxyRY--) {
        continue;
    }

    if (gTlzqSyWhlSChgI < string("ANRzxmSJbnNWrCwMuCDzYpnZqeYNOCLmGFmXzqYVCHMQIwdsybAJbcHoNADxawBgBAqaRsUVglfOHMojXwEkUtNkCyIvcZHfcwZb")) {
        for (int tlNtYAPbB = 1234088612; tlNtYAPbB > 0; tlNtYAPbB--) {
            nrNOl += nrNOl;
            kvllZlUCFz -= hsgnnFT;
        }
    }
}

bool awEyJQC::MNeCCuW(double muGZmxprmdoWow)
{
    bool yuuNSrNXCxwkKLx = false;
    bool ijKQx = true;
    double nQGywu = -720952.0688946875;
    double Njsztrfvhjlgk = -247182.1626704828;
    double XYlFNAyF = 715084.1661579234;
    double whSaiJTu = -653006.9918988682;
    string ZoiaYhWzjarOwN = string("mbMmihyCGTAXUaBmSttEVghTyFJYBqLZeJyIYWjMazBuaFEnRcRYpGcXhLJyPoRGDYz");

    for (int oKDFTGhBuMIgMY = 1067181323; oKDFTGhBuMIgMY > 0; oKDFTGhBuMIgMY--) {
        whSaiJTu = XYlFNAyF;
    }

    for (int MYYUizUrbv = 1042304030; MYYUizUrbv > 0; MYYUizUrbv--) {
        Njsztrfvhjlgk /= nQGywu;
    }

    if (nQGywu < 715084.1661579234) {
        for (int FmNsbzSPYEArLSk = 1231227848; FmNsbzSPYEArLSk > 0; FmNsbzSPYEArLSk--) {
            whSaiJTu -= muGZmxprmdoWow;
            Njsztrfvhjlgk *= Njsztrfvhjlgk;
            muGZmxprmdoWow += whSaiJTu;
        }
    }

    return ijKQx;
}

double awEyJQC::sGYgRhNutsX(bool tpTbIsv, int VybrmXKwdKRayoB, bool hGSrQO)
{
    string eUDrKhzJuN = string("lCbvWRIsFeEeFvPFMLZYBkwBPfsFfEUgyRvNwaJdorAEDpYUTNTvEuhUBUNjaZiIaTFzLoMmrpEKMnTrDAZwyeHfECDxiErcnJDQHyQOcMNLoxYmsIekFnbD");
    bool xoZDjG = false;
    int qQaLsjHgBtCJQZuq = -1405999187;
    double qeUsQhYrj = 209160.17752524136;
    string IBmFckdaeEWR = string("UxTZjwTkBqYPNXTo");
    double xzfXvuWTAhwJ = 222257.8790006684;
    int ldUtBvR = 1313271799;

    for (int PGIAZHl = 1168314140; PGIAZHl > 0; PGIAZHl--) {
        xoZDjG = tpTbIsv;
    }

    return xzfXvuWTAhwJ;
}

double awEyJQC::fEoCNfWTIcHHsWyE()
{
    bool vqaiJeFAt = false;
    bool VXcRXhFuCqVefJU = false;
    bool DmKCWCbxq = false;
    int PKqmtURQtTSm = -1414243877;
    double cwMLjHmQtdQia = -738303.7259891169;
    string SdmGSBOnAeNZ = string("VfOVOhusBTaKoUoOtITffxREPxtOhessJisSASssndiOfaRDZJoIzVTIAqngqQTTj");
    double ncInbjtM = 756611.4791997109;
    string ANFueBNanB = string("QgSuDbgPISGirDhLOGgiClVvTgqyKdnvlxTMsKZEFCIYCLsFnwlAAXt");
    bool YBUvsLLofkGQXPa = false;

    for (int islhpNzxhnHbt = 1818241203; islhpNzxhnHbt > 0; islhpNzxhnHbt--) {
        SdmGSBOnAeNZ += ANFueBNanB;
        YBUvsLLofkGQXPa = VXcRXhFuCqVefJU;
    }

    return ncInbjtM;
}

string awEyJQC::duCaIcnWUiZCe(double cqWfaLU, int UOmma, string uKSEGSpAl, int dcVnOLgmnlXzjYVu)
{
    string rKoUlo = string("MRnurpFCPpMDSjEjxvcYxvyAgYhUPvzNajyLTqRqsljImJXvgirRlHidROlrGLUPoXjYOYPqJuLqcsOMIKerqbQXIZGAjPwsUBzaOgiivEyhioVmaTJEaPApMRxCAXpyMIWfReJkrchQoBeBaMXhTViQUZeGPxIWeKmHDsnkECFeyQPCUeTpqebwPuoODtPUoukXQaqBaaswmnwjzDRJYLAiUxhfm");
    bool MAQlhnWImTdtbDe = false;
    string gOJsi = string("uFNhXeDKoZXsKmIxBqkrwcvukPpVNcmrNCDpekOpUhwbOxLnEUfrTDfNmVTpsyMTfsAQOrfdVFAmZkcwHyrySVYYCPbzZqmCEwCaIyyiWeoAmmOmYetwUqNmrj");

    for (int mcHoZrdZ = 1847134219; mcHoZrdZ > 0; mcHoZrdZ--) {
        MAQlhnWImTdtbDe = ! MAQlhnWImTdtbDe;
    }

    for (int PgpOdvoge = 19751496; PgpOdvoge > 0; PgpOdvoge--) {
        gOJsi = rKoUlo;
    }

    return gOJsi;
}

string awEyJQC::qLjlRmHMeJzg(int SnkkrYYf, double Grifxlnv)
{
    double vLHkRLRmFJ = -470516.9651515786;
    double BmamaeggQ = 1030709.9489152218;
    int XbzEhjdeNsWb = -828054991;
    bool qaSGY = true;
    int YVcWZBIVvfSEziIc = 30264641;

    if (SnkkrYYf == 30264641) {
        for (int MzjeEyGfIakJE = 1815133986; MzjeEyGfIakJE > 0; MzjeEyGfIakJE--) {
            BmamaeggQ -= vLHkRLRmFJ;
            qaSGY = qaSGY;
            BmamaeggQ = Grifxlnv;
        }
    }

    if (vLHkRLRmFJ != 1030709.9489152218) {
        for (int KDPSafIE = 2107983837; KDPSafIE > 0; KDPSafIE--) {
            XbzEhjdeNsWb -= YVcWZBIVvfSEziIc;
            Grifxlnv /= vLHkRLRmFJ;
        }
    }

    return string("qBAOZerGXGVzEnulTxsqESbCqMUzSNrJLwDAGWpfMbLxCYsCQAuonvPNDySvLLmHTpsaELTjAFcQqawLBFnGIgZePAmrTusguLJzOJXgWmyclxYbMJNdiAPTYblKJnnLXiQDZrpZzNTXVmVkEtPsXuEWmruKXawpgQbxvibgIYzEbLfkEBkxkgfmtYSUaYyDtZyJxeOPXM");
}

bool awEyJQC::pcyaFcdugFgCiYsV(double yjRDvItBiwP, string ktQhaIk)
{
    double ntLievM = 579948.4432955518;
    string ESZHwoVYkA = string("NaqBPbSIuSYvwSVHTQwLMoWlUNyYwWhVFXETTbIuvljEBFmMzHVJSqCBPOoMFFlbBQmRPPjNezkfnCfxWTMBRAXcOPPGUmTQCYnlalekgbJJYuHodofAsNhsGxtKGAoyHmTJHOLigNOvESDSdUgUiWGSWtinbkxdYIEngljOBajiXyvZFHlQYkgqygGoc");
    string EQxHrTOGtJY = string("yJsivJJvtRPyJtAoowsNoxFgkoaIUFHHcOehLWgXGTyazFgpwFNgSXUvlZlSIOPKileXmdfbRqSCiCUSdSSKkkLiNzCinIKRybxEnPhFQvCSUThftsBKPPvWngYUYQWCXGawtNWVmtnKCKYKmEZMnnzdArsIONardxguIQliMdjPRDTWNxHjYWEoTCAwzyysVgKHhZOhBVwFLKPVgYTLPnAIDlzPsFjnprNeikDFgbSRBtVwpTUxpMMrh");
    string sgvhHtDGZKIN = string("aNWCBwczypZsPTrbSErwMxuMWujZOySWsOWImbuAauIXSLkNIYLOdMXtkhGpUoSyTqyzRBEozYMxZZoHoPUsPqFULL");
    double TgBHRr = 823623.4098282489;
    double rjpJPSRycLt = -655977.710850293;
    bool hJcER = false;
    string yawMxYmceSi = string("ALYVYlhSjhnbYZTRwbhhkGJkcQxbdZgEAssikXdMYjeGsvuyNTkcogcGnKqGZtJZdhtMNXmEupGUeCEDIUTULTAUDrLObHPTnFLpCcGTqicjSkGIOjqvmhAUXnOecCtZHYSTBgjiLRkIpOARgpbmPCWvraBIyRxDbhRLhNCPRCXmMsCnbzzTlfnRKFxqHPiaqDZLuwCUJtDihjPEQTXoqCiAjTaZdFbdlBFJnZOSCUqgESpQS");
    int YNucfqGtWM = -1246733182;

    if (rjpJPSRycLt <= -655977.710850293) {
        for (int UBWIzQdvM = 1526382273; UBWIzQdvM > 0; UBWIzQdvM--) {
            yjRDvItBiwP -= rjpJPSRycLt;
            ntLievM *= TgBHRr;
        }
    }

    if (EQxHrTOGtJY > string("yJsivJJvtRPyJtAoowsNoxFgkoaIUFHHcOehLWgXGTyazFgpwFNgSXUvlZlSIOPKileXmdfbRqSCiCUSdSSKkkLiNzCinIKRybxEnPhFQvCSUThftsBKPPvWngYUYQWCXGawtNWVmtnKCKYKmEZMnnzdArsIONardxguIQliMdjPRDTWNxHjYWEoTCAwzyysVgKHhZOhBVwFLKPVgYTLPnAIDlzPsFjnprNeikDFgbSRBtVwpTUxpMMrh")) {
        for (int OviwNb = 1205237710; OviwNb > 0; OviwNb--) {
            ntLievM /= ntLievM;
            ESZHwoVYkA = ESZHwoVYkA;
            yawMxYmceSi = ktQhaIk;
            ktQhaIk = yawMxYmceSi;
        }
    }

    for (int zEOJGAsSIN = 1945489688; zEOJGAsSIN > 0; zEOJGAsSIN--) {
        TgBHRr *= ntLievM;
    }

    if (rjpJPSRycLt > 103643.46799562035) {
        for (int PyLGHxGHCkyxOIDX = 108810373; PyLGHxGHCkyxOIDX > 0; PyLGHxGHCkyxOIDX--) {
            YNucfqGtWM += YNucfqGtWM;
            yawMxYmceSi += ESZHwoVYkA;
            EQxHrTOGtJY += sgvhHtDGZKIN;
        }
    }

    for (int vWPmvfuWPZ = 1563013240; vWPmvfuWPZ > 0; vWPmvfuWPZ--) {
        yawMxYmceSi = ESZHwoVYkA;
        ESZHwoVYkA += ESZHwoVYkA;
        sgvhHtDGZKIN += EQxHrTOGtJY;
    }

    if (yjRDvItBiwP >= 823623.4098282489) {
        for (int LjxSfEeYOLOQCD = 419081104; LjxSfEeYOLOQCD > 0; LjxSfEeYOLOQCD--) {
            ESZHwoVYkA = yawMxYmceSi;
            ntLievM *= yjRDvItBiwP;
            sgvhHtDGZKIN += ktQhaIk;
        }
    }

    for (int mhfLuT = 221261907; mhfLuT > 0; mhfLuT--) {
        yjRDvItBiwP /= ntLievM;
    }

    if (ktQhaIk > string("ALZbdRlntRgVeXxNGHkuotKHBspvfcWEtkGWWWWWNkVhLVYDnASOcbYxtJGepGYMGFqgqVfcKQZrxMpXSHQwXkNAPrLwNAhiHwhxJVDNQrUmvzDLdVllFIukzrxIoTXRLvMSYuCpTKMLSuEKmhoTvkqEJMarvBRFXiNuGyAVCkpKhcuNqXUSVTDeXyovzzwTUliqWhFUptUQvCArvmAeccTUqTeXjiuZEzG")) {
        for (int QsnHAcr = 1633762337; QsnHAcr > 0; QsnHAcr--) {
            ESZHwoVYkA = EQxHrTOGtJY;
            ktQhaIk += EQxHrTOGtJY;
            sgvhHtDGZKIN = sgvhHtDGZKIN;
            ESZHwoVYkA += sgvhHtDGZKIN;
        }
    }

    if (rjpJPSRycLt != 823623.4098282489) {
        for (int YzMYdHWhpmji = 495328072; YzMYdHWhpmji > 0; YzMYdHWhpmji--) {
            ESZHwoVYkA = ESZHwoVYkA;
            ESZHwoVYkA = ESZHwoVYkA;
            ktQhaIk += EQxHrTOGtJY;
        }
    }

    return hJcER;
}

awEyJQC::awEyJQC()
{
    this->nTAzTWdta(1471884102, true, 418948035);
    this->OYooIKmrDGqZ(string("ANRzxmSJbnNWrCwMuCDzYpnZqeYNOCLmGFmXzqYVCHMQIwdsybAJbcHoNADxawBgBAqaRsUVglfOHMojXwEkUtNkCyIvcZHfcwZb"), -163105.93540182305, string("kSsozHcbcSXniEdnrxSSiSNVZURzbJfVJKcvTOdRsloenAUcpaIdenmVCeuZxoGtcHatjaQNIAgtGLgWIjHrQRpMPzHaAYMXKPttOwWoaWfYcPLTFcTWKxqnqxHrgxnqpHnTVpLAVbmiosBqkhXKkpjNSrz"), string("FBUsVrXCnOAMFqqzefHmeVlxfqJGnUTVEtYKmBFSwLgaaSloXHZgFkotspnxLzyDPUYKczPvZSowgYxBWTGeDafuzJAdsFhzbvqQvJYsYtTpkgujfnrjnMMRatfhJcfGhXxFvgCbByuzQqDWBdVSxcpqZpOAZLlcKIAgKzJvCxpdWyFGAdfnSrqhHrXDpEPGCQxZEngbjYsFQSYhOapGbxitkmvirRNNmoWFVuKcRmDTlyxdEgwHpahj"));
    this->MNeCCuW(754814.0990384936);
    this->sGYgRhNutsX(false, -1507260111, false);
    this->fEoCNfWTIcHHsWyE();
    this->duCaIcnWUiZCe(-1041756.5392566875, -453293351, string("kLdPlMnhgARs"), 95419401);
    this->qLjlRmHMeJzg(-1269474129, 977023.2284670484);
    this->pcyaFcdugFgCiYsV(103643.46799562035, string("ALZbdRlntRgVeXxNGHkuotKHBspvfcWEtkGWWWWWNkVhLVYDnASOcbYxtJGepGYMGFqgqVfcKQZrxMpXSHQwXkNAPrLwNAhiHwhxJVDNQrUmvzDLdVllFIukzrxIoTXRLvMSYuCpTKMLSuEKmhoTvkqEJMarvBRFXiNuGyAVCkpKhcuNqXUSVTDeXyovzzwTUliqWhFUptUQvCArvmAeccTUqTeXjiuZEzG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rFJAfCEPSAZVwqBc
{
public:
    int MeQQaTWtM;
    int NkyDb;
    double FGQMKscVfBDH;
    string dSJIZP;

    rFJAfCEPSAZVwqBc();
    int DpxBpEZgXpPcSdOy(int oWWaR, int QWSoAqnZLVU, string axUYZlwmGLnvB, string LocjwbBAGiFBT);
    string ozGbWYfTCyrHJJHf(bool QbYloNFqiXd, int pnupWJfEahs, string EiPVpFlrssk, int genkXV, bool yCJol);
    void vIouvZE(string KnHvrhy, double LWGXPNkm, string uEqubzKicbvGmz, bool MlloUzuCFG);
    string JmLjZpGvvvAfwcdZ(double ILNhRVuy, double aVlRoNjFLA);
    double JPXtHrNbVRsVj(string YiznQBZEOn, double mKXSp, int lVTuzAieQIRlM, double cnMhrqTCWcv, string CseNopyxZkypqGkJ);
    int NGNmsDwc(double EkNYMPGAl, int lxVMlPU, bool anosFPChmMuN);
    string IqisQFbOLYSjOZX(string KfeuqDAo);
    int rpTNCS(int CPgwGgtAXTRF, double YARdRq, double sYTonwFi, int RdGwLgwHwv);
protected:
    int PAzQqHpVkgymqYFk;
    string hCoRBtlsGrsyJyvm;
    string oKLzAlj;
    int McfGzLOQsMdHQi;
    bool mQqUXnNpFEeVEqXj;
    bool leefrGJ;

private:
    int zHlGLT;
    double kGjteQKPZHH;
    double wyCjyLm;
    bool tYpofMEvYBpx;
    double tcuLtbfbx;
    string OkbyCCcUtkGcSWv;

    string kvCGfYAtiPLXu(bool AWIBNHJLaRET);
};

int rFJAfCEPSAZVwqBc::DpxBpEZgXpPcSdOy(int oWWaR, int QWSoAqnZLVU, string axUYZlwmGLnvB, string LocjwbBAGiFBT)
{
    bool lttnNIilv = false;
    int uUmTJU = 1096211352;
    string FPgFTFQaB = string("ZRvKLIwgBOHBHfEgokJkwiKwoaYByDhNoRXpUHnSpmEOzhnuucOVADdXqeOIPeZBHUQebWqKGdnrRqrrUgETyhPemnTyVwYkPhjgIaEDtxORDQnvIKcDCMtiHbVCVhJBLvFgVNPTqQYFnILmxhCxYuSTtBBxsNzqeDYZvqeqyoTOCpFz");
    bool LsnZWgiOWyjL = true;
    string jNTgHHZKalgAoFu = string("aTVnuCnpEfngMJtdRviYCDGzpPUtVAOuANNOViJDOtKdHqccVRatAqCMnXgoGNyqWMdxAINeFiFwvFKurjsHopJpuKsQdeqMgHBpUIfimBlcYwYJsEgBlrczUPPenrVNWxqwalxxxmVURDJXdXzIidopjIcqqcwJR");
    string xobgQdZirUGyaayH = string("jPpvGaOJRSXcTNaUxfuEbNdqKmBAiuPWLqZbAPRIQjwRiqTtzBBGTkKOGBsxshZsdjoZXtpVQmqDIDcoqHgfoemvUpGPsdeCKdlZGGjuFDMnDXDGqxcrkEXrwuMEDVPRnsNzUZaVfxfUXwtEdfyPfcIcNSoZbqJFNzRfUNgvTtPRXmANfvLQvbvjGRpoMEPRXbEinlmPvRpyvmuXIFTLeOXdPqLARtjcjYBYn");
    bool jMAjWiizn = false;
    string uHokV = string("moalvjjJXVRimSTRoQWASlktbdcNXOOXtXaEoFMLGsDeoJxqnSwlvVIpGdKkamvLfHMdychDWCjGZTyLDTJjCzGEYksIPvRHgiqJBYGnAvpiefrbDybpucxIDXMsgumzuoOxJnwio");

    return uUmTJU;
}

string rFJAfCEPSAZVwqBc::ozGbWYfTCyrHJJHf(bool QbYloNFqiXd, int pnupWJfEahs, string EiPVpFlrssk, int genkXV, bool yCJol)
{
    int CJIFZzJhXvT = -1854300742;
    bool nOIVVn = true;
    int FeoCqW = -205142009;
    string nLRnJBygoYbdMien = string("feeCHKdBPyEVa");
    int CwQZjpvIX = -1575554735;
    int JrscGuMFmBEL = -120964393;

    for (int QQjHyMzInoOnzkE = 213044124; QQjHyMzInoOnzkE > 0; QQjHyMzInoOnzkE--) {
        genkXV /= pnupWJfEahs;
        nOIVVn = ! yCJol;
        CwQZjpvIX *= genkXV;
        JrscGuMFmBEL = FeoCqW;
    }

    for (int DwiNiUpSATmB = 1868330635; DwiNiUpSATmB > 0; DwiNiUpSATmB--) {
        JrscGuMFmBEL += CJIFZzJhXvT;
        CwQZjpvIX /= FeoCqW;
    }

    if (genkXV <= 1622682421) {
        for (int YuIaGC = 2092869540; YuIaGC > 0; YuIaGC--) {
            nLRnJBygoYbdMien = nLRnJBygoYbdMien;
            JrscGuMFmBEL = CwQZjpvIX;
            CJIFZzJhXvT = CwQZjpvIX;
        }
    }

    if (CwQZjpvIX >= -1575554735) {
        for (int ByziWbFDDDPZS = 509364493; ByziWbFDDDPZS > 0; ByziWbFDDDPZS--) {
            continue;
        }
    }

    return nLRnJBygoYbdMien;
}

void rFJAfCEPSAZVwqBc::vIouvZE(string KnHvrhy, double LWGXPNkm, string uEqubzKicbvGmz, bool MlloUzuCFG)
{
    string NbTnivc = string("xYRdaPxyCoavqAFMXjfWjKIkCyzpBdAuXEfmdXCRhdvwEdepyjFaSUKKBRcwZaCWFSDrRdPyDyryzwfrYCJClvtnVawDjIEsHYHSbinLPjipzioJvMbLUfEuwnalUP");
    double SpHjGuvlkaZJqQsx = 1016565.4341299032;
    int EMNRstSdpNj = 1338224393;
    double mnevgIps = -933627.0911396935;
    double SlGtxMUCnkuH = 97092.79620840854;
    bool nNQFbJ = true;
    string RIqBV = string("FDJqvFBKCuVdFuJhKijPizEW");

    for (int YHyiIeu = 1342148725; YHyiIeu > 0; YHyiIeu--) {
        nNQFbJ = MlloUzuCFG;
        mnevgIps *= SlGtxMUCnkuH;
        RIqBV = KnHvrhy;
        KnHvrhy = uEqubzKicbvGmz;
    }
}

string rFJAfCEPSAZVwqBc::JmLjZpGvvvAfwcdZ(double ILNhRVuy, double aVlRoNjFLA)
{
    double giAhXqYvrLw = 683844.4092731646;

    if (ILNhRVuy != 986170.0629803514) {
        for (int gYxoUhwWMB = 1283214086; gYxoUhwWMB > 0; gYxoUhwWMB--) {
            giAhXqYvrLw = giAhXqYvrLw;
            aVlRoNjFLA -= aVlRoNjFLA;
            ILNhRVuy = ILNhRVuy;
            giAhXqYvrLw /= giAhXqYvrLw;
            giAhXqYvrLw /= giAhXqYvrLw;
            ILNhRVuy *= ILNhRVuy;
            ILNhRVuy -= giAhXqYvrLw;
            aVlRoNjFLA /= ILNhRVuy;
            giAhXqYvrLw *= ILNhRVuy;
        }
    }

    return string("vGmILMtFHDnuNMKXAEvEhsfkhUgWRiabOquorMiMdhNhPUKhSWIRrKFvasMMrMDzhWrzZoUuFobjLtdoDaYuWcufVmRSINmUQRdjZnbqYNhacrObmEtfzbTXlbsQnLVeYcjIXzmujohlNcEPTKplCUwtsBDlXD");
}

double rFJAfCEPSAZVwqBc::JPXtHrNbVRsVj(string YiznQBZEOn, double mKXSp, int lVTuzAieQIRlM, double cnMhrqTCWcv, string CseNopyxZkypqGkJ)
{
    double uDpItlKJcfIEn = -571836.1742875704;
    int RdnELdPzes = -731804461;
    double UsNbzEb = -349529.3564877248;
    string qZSZeTeBJ = string("VOpvIVBELhWtDRsRDxSzwlDmhwHzIYFqnxtBUHKbLyLnoOhZgUljSbwgHIcJRcvnzTwZcvZPdCouIdToWXGPlEynOasEBExqohDnaQLOFtxhfqGBevYDNDdGPXqQCTdehxwRNKrvgYPqg");
    int rTDKesecBN = -1437206884;
    double ukblx = -198774.55998285723;
    bool dFDoBcNLCi = true;

    if (YiznQBZEOn > string("VOpvIVBELhWtDRsRDxSzwlDmhwHzIYFqnxtBUHKbLyLnoOhZgUljSbwgHIcJRcvnzTwZcvZPdCouIdToWXGPlEynOasEBExqohDnaQLOFtxhfqGBevYDNDdGPXqQCTdehxwRNKrvgYPqg")) {
        for (int zXkSwVNdbTqcVjLO = 149587122; zXkSwVNdbTqcVjLO > 0; zXkSwVNdbTqcVjLO--) {
            cnMhrqTCWcv = cnMhrqTCWcv;
            mKXSp *= ukblx;
        }
    }

    if (qZSZeTeBJ == string("VOpvIVBELhWtDRsRDxSzwlDmhwHzIYFqnxtBUHKbLyLnoOhZgUljSbwgHIcJRcvnzTwZcvZPdCouIdToWXGPlEynOasEBExqohDnaQLOFtxhfqGBevYDNDdGPXqQCTdehxwRNKrvgYPqg")) {
        for (int GrbCXVQdVvrnLVmj = 71936318; GrbCXVQdVvrnLVmj > 0; GrbCXVQdVvrnLVmj--) {
            cnMhrqTCWcv = mKXSp;
            qZSZeTeBJ = YiznQBZEOn;
        }
    }

    return ukblx;
}

int rFJAfCEPSAZVwqBc::NGNmsDwc(double EkNYMPGAl, int lxVMlPU, bool anosFPChmMuN)
{
    int inbVCD = -1627789772;
    int DoiBkTS = 461248497;
    string rJmNOmXmRhYDySb = string("zgwHghMBYcCTisxuLcHaRLoPmVuivOAiWowsauQtNSwoIqHgWCFbqDHCwnfymxyaJxmJcHkGZXTYLbfFOZriWNghPlDiuPROmwMEfKJHs");
    string UtlAvadHdfo = string("XGoxppmjUhsinpzMExWsGSnBFAgSyPoMGTvKpqeEmFVantwBAwdkKsamGkJqvOPcRTiOyXYnLzYBQwOBOaaDMcgoNLrHrLLiMawmGfWCgBkmUbUGkCLxcYRPALejAdDBvyyRgojBHzQZyphtXSQTkueRyAAOlYIahSuERBsjnhNgyzzAxfpAYlMhWOLiKizzmQsXoLjy");
    bool fTbdftBse = true;
    string EMWrFjloDQhh = string("DSxkbFjngvGDnuzCKTsdiVcSsMJaJivHajCGIwGpetvtElqFnblDBjpxeOvuKejXjOybuOtByAGbZluSByurwYphxliMAoOFilpqVrhjXUkxbDkVGjxODESbJUbEyONxFnuvacFqfXRUcOjsnAiNnsxuPuOqmwFmupDUhnaSEjGfPzRVUHKpJOElepM");
    string wQmmaaCDacPasJN = string("zVCJEaxviluLkrgKLHehxqUTUquGskbtduxXCwiRIyPpdJQtXRrYIonaTnXBsJoJd");
    bool vUhCyMHVaQsyrVk = true;
    bool iFuzdiZyIu = true;

    if (DoiBkTS != -37808870) {
        for (int eFNMpDuqscwCGj = 975920968; eFNMpDuqscwCGj > 0; eFNMpDuqscwCGj--) {
            continue;
        }
    }

    if (iFuzdiZyIu != true) {
        for (int YOQGOKvYjmElr = 1658840793; YOQGOKvYjmElr > 0; YOQGOKvYjmElr--) {
            inbVCD /= lxVMlPU;
            EkNYMPGAl += EkNYMPGAl;
        }
    }

    for (int VpmOmUG = 1839327238; VpmOmUG > 0; VpmOmUG--) {
        continue;
    }

    for (int NdVxy = 1196102; NdVxy > 0; NdVxy--) {
        EMWrFjloDQhh += rJmNOmXmRhYDySb;
        iFuzdiZyIu = ! fTbdftBse;
        fTbdftBse = ! fTbdftBse;
    }

    return DoiBkTS;
}

string rFJAfCEPSAZVwqBc::IqisQFbOLYSjOZX(string KfeuqDAo)
{
    int fwHtLlCrSyo = -467706224;
    double njyNkFmhj = 407890.82182664814;
    double goTNGcbl = 25918.59483774028;
    double VSSnlcCdisU = -436932.21207786485;
    int qNIKikcqpLFzHb = 191698128;

    for (int raBpy = 938308306; raBpy > 0; raBpy--) {
        fwHtLlCrSyo *= qNIKikcqpLFzHb;
        njyNkFmhj += goTNGcbl;
    }

    for (int xUrFGNFRHhBS = 1109187636; xUrFGNFRHhBS > 0; xUrFGNFRHhBS--) {
        goTNGcbl -= goTNGcbl;
        njyNkFmhj *= njyNkFmhj;
    }

    return KfeuqDAo;
}

int rFJAfCEPSAZVwqBc::rpTNCS(int CPgwGgtAXTRF, double YARdRq, double sYTonwFi, int RdGwLgwHwv)
{
    bool MeOGXesXQtIjqWe = true;
    double TgFeYczEslze = -913219.5510526731;
    double BbKygRKzA = 108730.97296237097;
    int plnCaicZeqr = 266655747;
    double mweIh = 515806.09542882734;
    int YfxKe = 2084449921;
    string WjVOQg = string("zYnjUfGnGIjeaYdgiBCkJUCDdUldvkCuUmcDueGJgmADRwLQXzpWQcjYjthZJdwYARxNTDckfgdJIChMmZnkwapXAKmlJeJsIixORiGvjqunCOimYJeytoPpgaweC");

    for (int qspnEKwhCfyzqSB = 1673351976; qspnEKwhCfyzqSB > 0; qspnEKwhCfyzqSB--) {
        YfxKe /= CPgwGgtAXTRF;
        plnCaicZeqr = RdGwLgwHwv;
        YfxKe -= CPgwGgtAXTRF;
    }

    if (CPgwGgtAXTRF != 636747930) {
        for (int qcDXCBeRvLctJ = 877211607; qcDXCBeRvLctJ > 0; qcDXCBeRvLctJ--) {
            sYTonwFi = sYTonwFi;
            RdGwLgwHwv -= CPgwGgtAXTRF;
            RdGwLgwHwv += CPgwGgtAXTRF;
            YfxKe += plnCaicZeqr;
            TgFeYczEslze = TgFeYczEslze;
        }
    }

    for (int uviamKoFDCNgI = 1811550028; uviamKoFDCNgI > 0; uviamKoFDCNgI--) {
        YARdRq += BbKygRKzA;
        YARdRq *= mweIh;
        sYTonwFi = sYTonwFi;
        plnCaicZeqr *= CPgwGgtAXTRF;
    }

    for (int nLxocuY = 646958699; nLxocuY > 0; nLxocuY--) {
        continue;
    }

    for (int pGfIlsV = 598951098; pGfIlsV > 0; pGfIlsV--) {
        BbKygRKzA = YARdRq;
        BbKygRKzA /= sYTonwFi;
        YfxKe -= YfxKe;
    }

    for (int VOaoMV = 109766881; VOaoMV > 0; VOaoMV--) {
        sYTonwFi *= sYTonwFi;
    }

    for (int UXcApVLVFfiYvU = 1303482775; UXcApVLVFfiYvU > 0; UXcApVLVFfiYvU--) {
        plnCaicZeqr = plnCaicZeqr;
    }

    return YfxKe;
}

string rFJAfCEPSAZVwqBc::kvCGfYAtiPLXu(bool AWIBNHJLaRET)
{
    double KqCuGrcokyRXclU = 544698.0974548074;
    double LmcwbMXLTJjsWgK = 371638.82609341486;
    double HFczvSMPdpZPhz = 247897.97720258796;
    string CRAPGHtPKbiR = string("kIfPatrNUNrUJYZciwAGmhlhCHMBdAuLkSekZshQHWFijnVppIZyLrLyKjqFqCzbAEGtMSzVdwxgdOeIeGuomc");
    string NZIzmJxQMMC = string("IFwUaQtmRwiKCYPtYagUjHtjAUifWaryAgeVFIWSMSjGaoUknbULpZMczqVSfHBGxQTdNxiICykhpGmNnpbguPitoKJrWTf");
    int uJqZD = -2007436181;
    string mNewIE = string("JcObVtpzqPNpPVvkbitzVbJFUHzQlwhhqlTobomNybngqBTfErJcCpecWjofRaiZdSeCsF");
    string LBlITbBjXLJ = string("bPHgyrkkohaXuQzjfjJJmSdRhCSJGaNtdrQnnngTCZoLRCikuVhslMBNTXKGzkHJMOhAxfHYeoKtVaAMFLpOdurtiCpTWFnJOXcSAOeBeYJYxEAXQVpsfmEIAflRXtRYWUDcmsllWZnotLrJsElxkOCAVhoLgGnfLLlgekUFGEDBMMsTcnIJhbIZUcGWmHzlfJYtnLBIobCHIrdJlGQrGRVLEAd");

    return LBlITbBjXLJ;
}

rFJAfCEPSAZVwqBc::rFJAfCEPSAZVwqBc()
{
    this->DpxBpEZgXpPcSdOy(503096114, 1741807945, string("sqUHKwoQzBmMvkKlnzuUSDairNSAngIpUIVnUgBjlAUFRsudWbnzvjvKEnjNQGohNjjNOfpIgfcGDNOMqkugEpAIxTJgdjHWSgNutrcWXoEjtuvvuMAkusoSpiEbAtWLxiUZidKpPzVWcdwDMRVoNbwuLtgEGymjFKkFnKFpXqgsWjEDMmQNjrfAGEYCpiSZlrOXuphlNiYQExOuvWKEcKsx"), string("rCAtXwNudOlxxaNWlzTsoSfCQCFWUvCGCJjwKfIszdtREZbnPglXuvwkQOkWoWWhqzcbtUnTGHMfDvfWyBsJijukZPrJiGRHfqckUwTxkjQnwCUGUNwTCMxpEvqbSnLYnZRWiJZYfYdpNulAxVdIqpyyjjVJrBjnORlbBTwtdRLP"));
    this->ozGbWYfTCyrHJJHf(true, 1622682421, string("tVmMMAKFhDjBpouLNvLwBvqseakilhmzaBiFUHFVDjyIbLQkjQGDtjNDqFhOxuSHuSvZuFndenwDjmZudsMyeiZstgJpJpHzGCUcWomSvXSpLNQffcIGdsbFnEZiriOCXYbuMQWKpxfWszvxUscDFVBKFdqMatrgKImYGmFOCEjtVIqjcWrQTGoe"), 548212918, false);
    this->vIouvZE(string("FFtTzpLQcqOtaGjNWQQ"), 154431.69491088163, string("GRdVuaOOHkLGibOjxqwKOiHmOCMSoGzCGgYeRJKQEBBcSOFsdDOywjzTsONqHsunBMCbgDIPlFgoqSKgetGUwTnTVFKHExRHtkqgqsrigyHBoURhEuVFpxzsbsmISBPMLyFrCndQgRTprqxWCXSwRtSlqvBqEZzfkJpKSpxmAcOuaKKLPdHrSvwESMLiXIVIXqUYOYwYPYGcoYtNfWsIHAeBUqDMEoqkUYTidBHBzrtKbjaEzjhOqGiVXyyiWxb"), true);
    this->JmLjZpGvvvAfwcdZ(986170.0629803514, 247679.65095966557);
    this->JPXtHrNbVRsVj(string("YqWtRkd"), 137760.62419354427, 159813498, 820676.7491554925, string("Xp"));
    this->NGNmsDwc(-485619.90092225326, -37808870, false);
    this->IqisQFbOLYSjOZX(string("btUytNYljayaVGdJoDnlwarlDxHVAJTlJXJbVapkUatqoZReUBtWnefKPscOxgXQkGaToDsKxwWUVYQbIKUwnfRatmjGRukpXturdXvAyBFMOnFsGwXyYHfLaWAJTVWBJ"));
    this->rpTNCS(636747930, -110351.71433918749, -914238.8905677935, -1055205328);
    this->kvCGfYAtiPLXu(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FsHLOkXJJBR
{
public:
    bool RWSCbZuiOZ;
    double pKkUJNmYnPLEoV;
    int owguUCWzhJ;
    int rUCVMrIjNotugl;

    FsHLOkXJJBR();
    bool pXhrRJMjZBdlolv(bool zyhXMylAMLh, string ACPpxdBpHQUhm, string ahvGiYdKZlIyqXr, bool aSLyrH);
    void wWeqNDq(double mcBqHIVFOEBIUxC, bool oCWfvXunuvUbou, int nSENVqC);
    string HMmUUcLJ();
    string RkMiEy(double lANujPEEgk, string UzTHwofKfrZm, bool GbHPqG, string jGErNi, string dPfjlW);
    int VeJwxUV();
    double acBQGQG(string jDpLigFAmAqeGIRf);
    double draGF(bool JlGVz, double BvynvcqKFhxonX, string PTdrIwYJc);
    bool tmiFjhVHhsA(int NnWrEMafU, string HyIUNoWJs, bool zGrCN, bool CuhEoWqm, double osvKq);
protected:
    bool jNJRLDJyckC;
    int omkVKOU;
    double AvUQSqtWsDrhXac;
    int xwkTIpJytBWpyA;
    bool DtqaHUbOY;
    double TzWYlhkaGYf;

    bool SkrvlcdhIEJPLU(string HPNjmEacMUbptOkr, double FYeZFY, string LIlibkhmRX, string UXSUKzPQtl);
private:
    bool dlCbISeNZs;
    double XDoYluip;
    bool kKcdSkgwGECDq;
    double TxqIlPLBquI;

    double LVJCPrlE(string dzCNhAgACsaOqq);
    bool VHchAXLckmJ(double ibbyMhHoq, int lENAVTV, double nTHqfaiWD);
    int aiyUFzUXcqpwAtIA();
    bool CwnSOVaDLcbFPmGk(double yVBdW, double CSRNLPyLT);
    void DrwOce(int AzUfZvdjaisBTLb, bool TdlYCFX, double QeeRdoIJGcRT);
    double yGUvNEOOzCPoLPw(bool GjaMATJLYdbuBjE);
    int byNBW(string MkToFQJr, double gyfsSlXNYQGO, bool dUxWA, double ztrCbigjUYRGneiV, int GkzbXXT);
    double pbSDIibKCWnskp(bool FrytGGpioRWISmq, string HSuqN, int bEhxtdJhg, double wjSrpNBn, bool OOgtVBzr);
};

bool FsHLOkXJJBR::pXhrRJMjZBdlolv(bool zyhXMylAMLh, string ACPpxdBpHQUhm, string ahvGiYdKZlIyqXr, bool aSLyrH)
{
    string wBFdaIGNIYBJXIA = string("EmcEWqVpJzlOswDaRBuHpZiNwkUZwKddUcBYlIgDcHfwhwxmWbubTRKyobzfuejBnHdfRLSevJCfQtvLsjYdqKbszPpHoGFFBtkKjrXpNeOesOimsKMsaHdywWFFfpkjoVbzoXXaEBuCcmjENRaLGQXTlwmgGaBqlJLTiPkOiuulTVfWJPBRdnkesGzdzSyYigoYccqZSeoLvvAmnXRTbXaZsgSvB");
    string IOdmEbUk = string("alOUojyiGfEyFBLDJiwlPhHsFNtTAuHMGUTvWOJWnyrppNJvlVfNtWndhdsi");
    bool TiXRR = false;

    if (ACPpxdBpHQUhm != string("PBNnoiTCxGRKMtvQNRmuvHLeCHvVkTtJjjnVdFwd")) {
        for (int vxwGMDxI = 1682555376; vxwGMDxI > 0; vxwGMDxI--) {
            TiXRR = TiXRR;
            IOdmEbUk += ACPpxdBpHQUhm;
        }
    }

    return TiXRR;
}

void FsHLOkXJJBR::wWeqNDq(double mcBqHIVFOEBIUxC, bool oCWfvXunuvUbou, int nSENVqC)
{
    bool dRaTwVHmGc = true;
    bool blIhMuuVjXGCl = true;
    bool xSOrTEAqGPD = false;
    int DAXKiRhu = -1711806742;
    double sajgtEhguj = 222673.16340811417;
    string nfiqXfo = string("jyJPsXoveBaULhoBSMvZTrqCVvZtSrxbzdSzYugZDYIevpHDkUGwDWPNNnIiYRdYeTqoMuPfThlEbOvrUZTxQSngbITVyjXvghlZpGlECKSWOiccaxpBDGSCFpfeOFBtcpdohsrCYaPQwaXAKBMoMavEWizIuMXSvtxFuyIOOQqdxZlekzUkQjZjqkhed");
    double RsbsPcySArWoAv = 863487.6602928964;
    bool UfpbqaLUHBRzvxNj = true;
    double NYyqbvzLDvGMwRe = 16134.298920752159;

    for (int wiOQEhRLgLARgn = 1201314250; wiOQEhRLgLARgn > 0; wiOQEhRLgLARgn--) {
        mcBqHIVFOEBIUxC += mcBqHIVFOEBIUxC;
        UfpbqaLUHBRzvxNj = ! dRaTwVHmGc;
    }

    if (nSENVqC < -1306251815) {
        for (int ZbiPqu = 1367349541; ZbiPqu > 0; ZbiPqu--) {
            continue;
        }
    }
}

string FsHLOkXJJBR::HMmUUcLJ()
{
    int FgqnTfXjTLMSHYGP = 110058408;
    bool aBGERC = false;
    int IoORTiqiPMUzkkHb = 2096985883;
    string YoPNpCihIuk = string("MdqGNGCBffXiucCYTumgTNRAFEnnXCsOEtyNpsyVFINoAmUSDXWZFQwXuTQLwshWGxZXbtGpNWSmghiVSSnvSRapoencOZrBSLismyZpdajLfZwusgjAnQFBCiElfKoaRVqMePIlOIGDFOZMZBjnJNWAxQmMnpQBHNaLvdAchzxFtZPDMDwYqrgckIEHnWIONwHtHyQkkyvLqQwQtMfBKawxSWohMryNc");
    int nDmYsUyXV = 492565262;

    if (FgqnTfXjTLMSHYGP == 2096985883) {
        for (int ujSlnU = 436029946; ujSlnU > 0; ujSlnU--) {
            IoORTiqiPMUzkkHb -= nDmYsUyXV;
        }
    }

    for (int VrKORbKTfhkJXxkO = 1456397508; VrKORbKTfhkJXxkO > 0; VrKORbKTfhkJXxkO--) {
        aBGERC = ! aBGERC;
        FgqnTfXjTLMSHYGP /= nDmYsUyXV;
        IoORTiqiPMUzkkHb += IoORTiqiPMUzkkHb;
        aBGERC = aBGERC;
        IoORTiqiPMUzkkHb /= nDmYsUyXV;
        nDmYsUyXV = nDmYsUyXV;
    }

    if (IoORTiqiPMUzkkHb < 2096985883) {
        for (int WBeHtwMb = 354816255; WBeHtwMb > 0; WBeHtwMb--) {
            YoPNpCihIuk += YoPNpCihIuk;
        }
    }

    if (nDmYsUyXV > 492565262) {
        for (int ntSiv = 156747164; ntSiv > 0; ntSiv--) {
            IoORTiqiPMUzkkHb += FgqnTfXjTLMSHYGP;
            IoORTiqiPMUzkkHb += IoORTiqiPMUzkkHb;
            nDmYsUyXV += IoORTiqiPMUzkkHb;
            FgqnTfXjTLMSHYGP += FgqnTfXjTLMSHYGP;
            FgqnTfXjTLMSHYGP += FgqnTfXjTLMSHYGP;
            IoORTiqiPMUzkkHb *= nDmYsUyXV;
            IoORTiqiPMUzkkHb *= nDmYsUyXV;
            nDmYsUyXV -= nDmYsUyXV;
        }
    }

    return YoPNpCihIuk;
}

string FsHLOkXJJBR::RkMiEy(double lANujPEEgk, string UzTHwofKfrZm, bool GbHPqG, string jGErNi, string dPfjlW)
{
    bool RBFkr = false;
    double HJjYxTAOhDC = -683898.3105063004;
    double cCQytIMZ = 53981.592806075605;
    int HjLbvkAbfMBpXjD = 1924938878;

    for (int GIoxFig = 879334166; GIoxFig > 0; GIoxFig--) {
        RBFkr = ! GbHPqG;
        cCQytIMZ += lANujPEEgk;
    }

    if (lANujPEEgk < -683898.3105063004) {
        for (int HHXyDQEZp = 997044707; HHXyDQEZp > 0; HHXyDQEZp--) {
            continue;
        }
    }

    for (int RkqlHDGuNFseipfr = 1942686302; RkqlHDGuNFseipfr > 0; RkqlHDGuNFseipfr--) {
        dPfjlW = UzTHwofKfrZm;
        lANujPEEgk += lANujPEEgk;
    }

    if (lANujPEEgk > -683898.3105063004) {
        for (int HqwDIEpPxKv = 1032970444; HqwDIEpPxKv > 0; HqwDIEpPxKv--) {
            jGErNi = UzTHwofKfrZm;
        }
    }

    for (int pJlAKcQJSlbzkJz = 747025696; pJlAKcQJSlbzkJz > 0; pJlAKcQJSlbzkJz--) {
        continue;
    }

    for (int srJwmrDmNpcBdKE = 742446271; srJwmrDmNpcBdKE > 0; srJwmrDmNpcBdKE--) {
        cCQytIMZ += lANujPEEgk;
        UzTHwofKfrZm += dPfjlW;
    }

    return dPfjlW;
}

int FsHLOkXJJBR::VeJwxUV()
{
    string pXYkbMfhLlmxsLK = string("vZXEYOSyovnAmiFSkJPPsQpKbsebRzZxqHCrAmRrDeHhEmHAPcdjZLwJkTQUTxjzDSnQlAvhNWKoJfrFY");
    string uksRcZImhuaR = string("WlFdEjfRCpNJfCssAIRTATKeWHaqgUNpkgrVZIPKPNwYZLgyORcptZpBjjLFkutsbaSNYXTiTuKWNnkTmOObfQEafLNzmuOtNIyaQpexymLrOt");
    bool EFgRouqHrtVbllkM = false;
    bool wSZYOoZh = false;
    bool IwBuYyt = false;
    int FuzJdORUhBcquSA = 568499699;
    bool BrMfJslV = true;
    bool EQFtkaySvYAGuEF = true;

    return FuzJdORUhBcquSA;
}

double FsHLOkXJJBR::acBQGQG(string jDpLigFAmAqeGIRf)
{
    int vkPXzgvx = -163773991;
    string BGAufAHmbmpJwAx = string("IBFXhtqojEplBMMETgILbFJinfDLiuPGeDnUYaeVbkEtXdjcyjPqKpDznrkgvfHLVJtrukRXLvDWnLytUmBHEKBzZWTTxwQqbReRByYDtdFSLdJGhebkCCTGMVfkDvHeYYZAhIEZmqdYbKahjOadPJWfWfoZRulRNmOWbBub");
    bool xamzv = true;
    bool IQrOfGWrYL = true;
    string UsjMonmfEd = string("CaCqWCROGxeVDZWriDauapadqfKHBkPXvmjallQzIdzEKVYGlaRilfTygcoahhJAqvNortyPgjoRLSRygNuZaILgk");
    bool nbAJnTPYuUVtDBx = false;
    double BybKDwKP = 138085.3461819381;
    int lpwQKnsKVMmUx = -260993538;

    if (BGAufAHmbmpJwAx <= string("IBFXhtqojEplBMMETgILbFJinfDLiuPGeDnUYaeVbkEtXdjcyjPqKpDznrkgvfHLVJtrukRXLvDWnLytUmBHEKBzZWTTxwQqbReRByYDtdFSLdJGhebkCCTGMVfkDvHeYYZAhIEZmqdYbKahjOadPJWfWfoZRulRNmOWbBub")) {
        for (int gjYyhhS = 335592873; gjYyhhS > 0; gjYyhhS--) {
            jDpLigFAmAqeGIRf = BGAufAHmbmpJwAx;
            vkPXzgvx += vkPXzgvx;
            UsjMonmfEd = UsjMonmfEd;
            BGAufAHmbmpJwAx = BGAufAHmbmpJwAx;
        }
    }

    return BybKDwKP;
}

double FsHLOkXJJBR::draGF(bool JlGVz, double BvynvcqKFhxonX, string PTdrIwYJc)
{
    double uOkkqRZ = 923867.1156429168;

    if (uOkkqRZ == 515819.1364467976) {
        for (int XuzDrqsAn = 2098128728; XuzDrqsAn > 0; XuzDrqsAn--) {
            uOkkqRZ = BvynvcqKFhxonX;
            BvynvcqKFhxonX *= BvynvcqKFhxonX;
            uOkkqRZ /= BvynvcqKFhxonX;
            BvynvcqKFhxonX += BvynvcqKFhxonX;
            uOkkqRZ = uOkkqRZ;
        }
    }

    return uOkkqRZ;
}

bool FsHLOkXJJBR::tmiFjhVHhsA(int NnWrEMafU, string HyIUNoWJs, bool zGrCN, bool CuhEoWqm, double osvKq)
{
    string kZxMziyf = string("fvPjiviODLlRthpKfVbmeMGkaohCncohrTMPkSAEiivvSUEtFjfUaZorHnFDtRfPXzdOfMZgQVvmtOfsiWuwqCmFuDPtiYyiAFrOwjqQYKObeAAtnsAVULhwdSTgpOUTYRrCdoPPYuzQHFhUlWnAlkxKbKXdqTx");
    bool SWYEBBQjxJpEpGPf = true;
    int LygoGXH = -1191485393;
    bool woqBCePb = false;
    int XdFJH = -701379894;

    for (int IveoEGypojYPyeQ = 1760855117; IveoEGypojYPyeQ > 0; IveoEGypojYPyeQ--) {
        CuhEoWqm = SWYEBBQjxJpEpGPf;
        woqBCePb = CuhEoWqm;
        SWYEBBQjxJpEpGPf = ! zGrCN;
    }

    return woqBCePb;
}

bool FsHLOkXJJBR::SkrvlcdhIEJPLU(string HPNjmEacMUbptOkr, double FYeZFY, string LIlibkhmRX, string UXSUKzPQtl)
{
    string YNeMGRDQuC = string("SHozsxS");
    double XHOEL = -685323.6246487688;
    bool zbcAeUB = true;
    int CWbuPqOwWdUlGZN = 457937706;
    bool rJhNjUaThni = true;
    int ddknKoRu = 1383479834;
    int vEOisyGhtbXtHo = 1942546011;
    bool CQXIslqGFPsLULsl = true;

    for (int NmLRlxYu = 1213811440; NmLRlxYu > 0; NmLRlxYu--) {
        vEOisyGhtbXtHo *= vEOisyGhtbXtHo;
    }

    if (HPNjmEacMUbptOkr == string("SHozsxS")) {
        for (int ZaonqRJObRaEilV = 1413318048; ZaonqRJObRaEilV > 0; ZaonqRJObRaEilV--) {
            continue;
        }
    }

    return CQXIslqGFPsLULsl;
}

double FsHLOkXJJBR::LVJCPrlE(string dzCNhAgACsaOqq)
{
    bool PuBBhX = true;
    int UtjYYt = 1882384208;
    string AfYtYqqOJnbk = string("NonYiRImWJc");
    bool ZoVVBmGZjUTZb = true;
    string sxmZPMvTYhHdXBK = string("NCeGbWCgqUTboPGmxQGcPOpmiyzyVnRDMvBUMjmlVtlgbYTVkyBauWHBgitBKefDSXkAOykgWcedMoAQocaBefkDMJWMPnrDaOEmvJwpngjoKW");

    return -984646.3084939796;
}

bool FsHLOkXJJBR::VHchAXLckmJ(double ibbyMhHoq, int lENAVTV, double nTHqfaiWD)
{
    int CKeCCad = -2045700060;
    string cimYvsTmDZJsTZ = string("zrualWnkdBpcXlFijP");
    int lQqENCvW = -66543914;
    bool kfbeOkpsJlDTYXu = true;

    if (lQqENCvW == -66543914) {
        for (int RsCFlDrzx = 971870515; RsCFlDrzx > 0; RsCFlDrzx--) {
            continue;
        }
    }

    for (int yDkfeEVdPWaFTmwH = 848815409; yDkfeEVdPWaFTmwH > 0; yDkfeEVdPWaFTmwH--) {
        nTHqfaiWD *= ibbyMhHoq;
    }

    if (nTHqfaiWD <= -834430.7060709633) {
        for (int ixiYIZOTe = 328507973; ixiYIZOTe > 0; ixiYIZOTe--) {
            nTHqfaiWD *= nTHqfaiWD;
            ibbyMhHoq = ibbyMhHoq;
        }
    }

    for (int vTjIKASWp = 1087998887; vTjIKASWp > 0; vTjIKASWp--) {
        CKeCCad += CKeCCad;
    }

    return kfbeOkpsJlDTYXu;
}

int FsHLOkXJJBR::aiyUFzUXcqpwAtIA()
{
    bool SPVXcYtYTpeyNy = false;
    string Mfexg = string("RlyNtDipGbzrucaoWnuijCWzjAnvmrGVmbdEIvjBbrUVzEQufnLstFDPvbGcZXFxlezWpCbZViJUixPEUlzkGpIhvIPfPbOWpnhZUyUbFTEHxkBzKRzFknzplIFcfpdnqkJHcArgIVJPPnprUDOipdvZGeTMNrOAIXWcHOIjdNoNuerfAxQFHtVODNzQwmUPfzhILYdsbIZ");
    string JJNpZuoHbp = string("SbGeOQvuKHBceiMiNWdBEQqofVptGQkbPNvrfwnmxgrgNwBoAKvaXKmbpldQbJpruRASlysIHGbrUJqqqISVjqq");
    string ZRwqlNDlV = string("JFkcxSyFMLVIUFPSeA");
    bool ZMaJYlmENWhjz = false;
    string ggKkAMwLmpzHWhwC = string("sYYglRpsDAkYFgsxwrmzBIwUajgjtvpPRiOzEbTrrfoatGKDtPVHQbnAjIrM");
    bool UQJoPXHQTU = true;

    if (Mfexg <= string("RlyNtDipGbzrucaoWnuijCWzjAnvmrGVmbdEIvjBbrUVzEQufnLstFDPvbGcZXFxlezWpCbZViJUixPEUlzkGpIhvIPfPbOWpnhZUyUbFTEHxkBzKRzFknzplIFcfpdnqkJHcArgIVJPPnprUDOipdvZGeTMNrOAIXWcHOIjdNoNuerfAxQFHtVODNzQwmUPfzhILYdsbIZ")) {
        for (int gSrOQwRNlcSRlug = 1309248795; gSrOQwRNlcSRlug > 0; gSrOQwRNlcSRlug--) {
            ZMaJYlmENWhjz = ! SPVXcYtYTpeyNy;
            ggKkAMwLmpzHWhwC = ggKkAMwLmpzHWhwC;
            Mfexg = ggKkAMwLmpzHWhwC;
            SPVXcYtYTpeyNy = SPVXcYtYTpeyNy;
            ZMaJYlmENWhjz = UQJoPXHQTU;
        }
    }

    for (int pZnRgNhrNKyjLp = 1668724292; pZnRgNhrNKyjLp > 0; pZnRgNhrNKyjLp--) {
        SPVXcYtYTpeyNy = ! UQJoPXHQTU;
    }

    return -644474102;
}

bool FsHLOkXJJBR::CwnSOVaDLcbFPmGk(double yVBdW, double CSRNLPyLT)
{
    bool TWWBPxehBqIRKvK = true;
    double rJhuZ = -191105.0739092212;
    bool cXQIgibx = false;
    bool sgxkjEeAVk = true;

    for (int ZiviszT = 15767167; ZiviszT > 0; ZiviszT--) {
        CSRNLPyLT -= yVBdW;
        sgxkjEeAVk = TWWBPxehBqIRKvK;
        CSRNLPyLT -= yVBdW;
        cXQIgibx = ! TWWBPxehBqIRKvK;
    }

    for (int MlkihzFc = 892673609; MlkihzFc > 0; MlkihzFc--) {
        cXQIgibx = ! cXQIgibx;
        TWWBPxehBqIRKvK = cXQIgibx;
    }

    return sgxkjEeAVk;
}

void FsHLOkXJJBR::DrwOce(int AzUfZvdjaisBTLb, bool TdlYCFX, double QeeRdoIJGcRT)
{
    bool WIBysz = true;
    double ypNoCFqEe = 333392.3114368713;
    int aXSMDydmfiIA = 42266369;
    double ZdgmVSZj = -564875.8450534771;
    int WcDLQ = 1916301718;

    for (int wgzTqYkCBljGJHME = 1300630044; wgzTqYkCBljGJHME > 0; wgzTqYkCBljGJHME--) {
        WcDLQ -= WcDLQ;
        WcDLQ = AzUfZvdjaisBTLb;
        TdlYCFX = ! WIBysz;
    }

    if (ypNoCFqEe == -564875.8450534771) {
        for (int LnLMleDFKzqprwbs = 137807113; LnLMleDFKzqprwbs > 0; LnLMleDFKzqprwbs--) {
            continue;
        }
    }
}

double FsHLOkXJJBR::yGUvNEOOzCPoLPw(bool GjaMATJLYdbuBjE)
{
    double vDREjUhuJqsYwBO = 992072.4215720352;
    double ULWJQngvRsQWvWS = -359153.47866051766;
    bool euupdafRt = true;
    string cteDLY = string("LWGtbbBcHknqiZgzuWWlIsUUkpFymwEvFecRKdKNOsVwJDabTZosaqtexPuqAtitImCopoIkCurBvIjdMWPqDvtcpAkEmRwajKoRrFqAsRxjemMqnfQQWzxypKuMPINgVyrObSxdtUsXfpq");
    double QNjnZGEPMUlYeo = 137070.724891955;

    return QNjnZGEPMUlYeo;
}

int FsHLOkXJJBR::byNBW(string MkToFQJr, double gyfsSlXNYQGO, bool dUxWA, double ztrCbigjUYRGneiV, int GkzbXXT)
{
    bool ioaOyCfgcqIyB = true;
    string PSwmEHQqxTNdR = string("VgACePoQTsZblxsoJyVxBrosvBDDNXIBtCgJnUyRIjbYYtNJuhtVCWihIUcJVBmQcrlaiylvxYQjLhyhrkmZkmWrnYpAFJdKwoUagndFRUhsaegsJXmQQUXTVxjaVfegetAzwTNMIpMZKLGFczTbCAgwvizOoqZFXSvarEhrOV");
    bool lnixSsRNC = false;

    for (int qXIbQy = 2120009985; qXIbQy > 0; qXIbQy--) {
        continue;
    }

    for (int kZothKHlE = 1718393379; kZothKHlE > 0; kZothKHlE--) {
        lnixSsRNC = ! lnixSsRNC;
        lnixSsRNC = ioaOyCfgcqIyB;
    }

    return GkzbXXT;
}

double FsHLOkXJJBR::pbSDIibKCWnskp(bool FrytGGpioRWISmq, string HSuqN, int bEhxtdJhg, double wjSrpNBn, bool OOgtVBzr)
{
    double nrLbaYKpLprICNyj = -192750.68620881453;

    for (int IHadltpeItwNag = 452890839; IHadltpeItwNag > 0; IHadltpeItwNag--) {
        nrLbaYKpLprICNyj += nrLbaYKpLprICNyj;
    }

    for (int ateBwnu = 5189374; ateBwnu > 0; ateBwnu--) {
        nrLbaYKpLprICNyj += nrLbaYKpLprICNyj;
        bEhxtdJhg /= bEhxtdJhg;
        wjSrpNBn = nrLbaYKpLprICNyj;
    }

    return nrLbaYKpLprICNyj;
}

FsHLOkXJJBR::FsHLOkXJJBR()
{
    this->pXhrRJMjZBdlolv(true, string("xKcNAAsmgEnBbcKeGQKgXfnkiIvCUNtbKuIISKTaPlpZTlGvav"), string("PBNnoiTCxGRKMtvQNRmuvHLeCHvVkTtJjjnVdFwd"), false);
    this->wWeqNDq(390510.4615574993, true, -1306251815);
    this->HMmUUcLJ();
    this->RkMiEy(-145892.09244835042, string("ixVNVBzkTGGEsbCqpARRxAtRkpoLMguUWjQrwXSWcONPsrXEWMyhmrXCfSptlwIIvupebYZqexQqeRPlnGLmxrWbiJEGDDbNkZizuIezEJwuuHBmOtcVJlxlkRMVHJvpJNHyxafONRnjHGwSuqfmoDKABRSodjCSOZcERpTOKUmroVXjOuHehjuFqF"), true, string("bgbCfJOOxSTvQVzUKqJohzFkJpGITehVxlYFlIInbbjBzdJvknShYgsbemRYUMNiXLjSrWdkjYnPhIXpDGxhqzbjJcysHcdcqxuuNtszTaXmzvGbMPoMKJAjoVJvhyCxRcNQVLawrZZHaxTobpJLhJSgBqDoqejlc"), string("MqckBcQcGrtdOBxQeJAtjiwZVJpJgcVgyBruVOqExuJNAUysptJOUTxTOAezKjkptHUOXkKKsuSXukAERHGArROTmXqXTxvBldBgMIRCUWUIGenxpVjImyCspuoFXwkeIUXHTrqdpYWpaeYmulRtfQwcCvVmzyrXlwPsVmjlPTMtsHQKCHfpPFWFDJLNnCvnYide"));
    this->VeJwxUV();
    this->acBQGQG(string("BcgDcnFMZlsRoJJacbJtnVZtDrhfupjtvfTpKgPCLKwxQhPqbpQUHlLVDmCIhlZDmOXeyXZLKizesZqyCXlttmNVoxVcqXEeqmoLWzYlUbExmuPXPiYoMjujMgWefytcmbXZpvsmlMWDWjOJRoXUrRvzcJV"));
    this->draGF(true, 515819.1364467976, string("bPeqWwEAAIOpUNclApoVtESlAscqlHDjiHslKvRHGkoMQoNTNftvVRUFfuzDEEadpKYvgUAIZzkmZoctOtBfwHGUZ"));
    this->tmiFjhVHhsA(-1886511920, string("BNZLqcJYPwHVoxRftfVuJKxBdCJmDAwkDdHtuLectgKAQEuEGxFwSWxxfaBBYsbTnKvhweWhfWAlBiFFWbj"), true, false, -628834.301264464);
    this->SkrvlcdhIEJPLU(string("uXhpJMbGuPLORLxYwAnrqoGZpbjDaPqBcqjqLPosbQADmRIUQJFyZREpkNzIvbxpjLiyfXcUkAicEMkPLi"), -1020268.7645711552, string("HofKZktCcnXAbKHfRDoJtCGAKvAnENZoNUssAdpdKQshZCjVdecZiadPYgHmMCjvWDHplYQmlpWRjOyCOCmLoZVrDXkccWmLs"), string("DIrMcaawFiRRtnqNRRpRusJdCaAWdMRsORPpQHodDmIajpwwxhFdEdwBelzRumdYCHxxnhitn"));
    this->LVJCPrlE(string("jVjmjauiscvGkNaQViFBkPNAKMjCJmTIWLWaJItnnSfsbMekwSgmMARtyLROSezzMidVTKUabRELckIgpeZDCYKiEtpmKNAQlheyeWZZYogXlQpb"));
    this->VHchAXLckmJ(630635.9324865608, -1225997724, -834430.7060709633);
    this->aiyUFzUXcqpwAtIA();
    this->CwnSOVaDLcbFPmGk(-771689.3784125915, 50159.39420761007);
    this->DrwOce(1264570972, true, -224890.8544380001);
    this->yGUvNEOOzCPoLPw(true);
    this->byNBW(string("jYkrCTkDrUOcbBpOwgrPHidEVsvvwqRGZIRObmJiJsxbAersGwWEuHAnJZgZxsQJFULoJboemZgXuMSwxsTHwaSuMItkcljNLcB"), -943898.0042042666, true, -116886.10347112064, -443284090);
    this->pbSDIibKCWnskp(false, string("xFSCRVYbeMIMmAOjxXLXTzSTPBaWKiZyZduecsotntbcBZrDeEfbEtssFVEYHsCYENJWZvTuDHSqMdjQpfDestKvuteZIwjxCRDsaYbnPLOyuhoqDujKnrITyGsefgBwyclPNVQVkXTAsLUNRzcctBQPrNbtoAacsftobMkgdPgeNSpevxPUJwhrNedtUvStbUodflQbxhSygieOMtDJDxsDJrtnEsuFnYOZITe"), 947579757, -20859.248232731374, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dfkazlmXEKFn
{
public:
    double arzUIRED;
    bool wxupo;

    dfkazlmXEKFn();
    bool ZtnRxKhDNcqPBxVo(string LqigSGKR);
    bool SgHPc(double SIvOrRilvoNwvhYq, bool SrsEeZHxTvWmm);
    bool ThFSUkO(string ZbMzbXPN, int sEZONbOWkeAsFYm);
    double hxhrOxkdIrdy(string xfikLybRlx, int gkMyST);
    string KIyJvugSoFTBq(int OVEEmBSYs, string QERCVUGKeiyTs, int WSVoijHXzvSA, bool ftGXTzlQzLQ);
    double atInaRSWj(double IFZrqFWKiHwFSnY);
    double EGpGpwBZzBsY(bool WAQljppxXO);
    double FHFJZT(string GaXWlOIM, string cxRhUMkvewXDkW);
protected:
    double TxRzuc;
    string NuUDY;
    string DwmlTvBQduq;

    bool YnHoPlGUeywPdEXF(double EAKLlbu, string RAteYtvjeQhIwoj, double BQgYl, string CHCWHucP, bool ZTTOXndhvujuQaVe);
    double ZLUaJgfHC();
    void FUjQjh(int PHdPJpmBxnudKmh);
    string SeXAWjHYBnTSvRN();
private:
    double inFuddAzfvkGHvZ;

    void UVYWvfDEpL();
    double GWJQDS(double KuugQihIz);
};

bool dfkazlmXEKFn::ZtnRxKhDNcqPBxVo(string LqigSGKR)
{
    string WvRqJADkUKYKSVc = string("rkyxMnvyeiPcEbOhxXNiHXZdrrsokrvtFNeXfpnnbjSnXMZMUdtKAgJfCcttTLhYpHpbImMPziNElcXWJEiPphYMLzKIapNtwZnmBvSmdqIneSfpIkRnpdXxrHPwFwJIRopyeVsEj");
    bool LjYLhLbgty = true;
    double yIyuzJVpKHK = -486434.55637432873;
    bool VyAuIjELnU = true;
    string NbzilWv = string("hVtmgknkBtpfcUeRSoMaTUdLpVSQgcysBcLFBBdHNbBkhbmrbyQhjrhTdhPuawUXoWZnzMtvOgfeRQZqCXfDXUkLOWvvhWKYHSaSmbcqKdXAEwkSDmWrLnVJwxoWmxpZyknpznvpfDgWVFniXkEQrPrKDFvRiTjxcDfvq");
    bool GnSZQEZwuzPGjKDR = false;
    double lXLFolrBXjgYqGru = -373536.9912985275;

    for (int YHdkGyexYmXdDSJJ = 1618308333; YHdkGyexYmXdDSJJ > 0; YHdkGyexYmXdDSJJ--) {
        LqigSGKR += LqigSGKR;
    }

    if (lXLFolrBXjgYqGru > -373536.9912985275) {
        for (int SlGMnydeh = 1688046637; SlGMnydeh > 0; SlGMnydeh--) {
            lXLFolrBXjgYqGru /= yIyuzJVpKHK;
            VyAuIjELnU = ! GnSZQEZwuzPGjKDR;
        }
    }

    return GnSZQEZwuzPGjKDR;
}

bool dfkazlmXEKFn::SgHPc(double SIvOrRilvoNwvhYq, bool SrsEeZHxTvWmm)
{
    bool iFSeK = true;
    bool RwJEyZHMmYpo = true;
    int piXlpg = 1102415146;
    double KuWXVKYqqvQvXWSj = -515229.13914857886;

    for (int vmagxkNwFrnob = 301002265; vmagxkNwFrnob > 0; vmagxkNwFrnob--) {
        continue;
    }

    return RwJEyZHMmYpo;
}

bool dfkazlmXEKFn::ThFSUkO(string ZbMzbXPN, int sEZONbOWkeAsFYm)
{
    string sGvcAjWbcHc = string("znbTJxzZiVxuyssJmKevKTpQBopZMBhIAaZQjxtbazFUBjcciH");
    bool HnNvHCfRsLPJ = true;
    int znnYCzGEDJiZeohf = -945275380;
    string AtszlEjXyivK = string("fnfSyyiFSEMmTRCLfwMXFCPwSZFjxzXJmDzLPsHNcnUIwYEtSmJAPzBuKl");

    for (int LMTAqaumoJDCSat = 244276296; LMTAqaumoJDCSat > 0; LMTAqaumoJDCSat--) {
        sGvcAjWbcHc = ZbMzbXPN;
        AtszlEjXyivK = ZbMzbXPN;
    }

    if (sEZONbOWkeAsFYm < 2042276289) {
        for (int gwxem = 604865173; gwxem > 0; gwxem--) {
            sGvcAjWbcHc = ZbMzbXPN;
        }
    }

    for (int UumZwwdbwMGauzW = 1061017706; UumZwwdbwMGauzW > 0; UumZwwdbwMGauzW--) {
        AtszlEjXyivK = AtszlEjXyivK;
        ZbMzbXPN += AtszlEjXyivK;
    }

    if (ZbMzbXPN < string("XwFwkcsMcxwNHmJdlPDyVDSVoBgpTGDdhINPWmDejVVTwzQIcCUmGcFhpxGefHTmIhYNJqIaODGFgfVKTglxjXpYdVnlUzbClwFeBMBvRScTEKIoLvWT")) {
        for (int iuAtKPSV = 1363376156; iuAtKPSV > 0; iuAtKPSV--) {
            AtszlEjXyivK += sGvcAjWbcHc;
        }
    }

    return HnNvHCfRsLPJ;
}

double dfkazlmXEKFn::hxhrOxkdIrdy(string xfikLybRlx, int gkMyST)
{
    int fOqrWymi = 95445699;
    string TXBPACbY = string("GMrgiSMGXVaEUayqOjwAVjjfpsDwsCQPBqGbilhnFTbZhJuCilVQwUvYGtUaRORXFLFhPGUHowuqCphJsOudPIhYJMYPfGUHYPqqEwRBteKDODqpiMtGOGdKVroFAOVqPgBr");
    int vIcRxhIXJL = 2072386802;
    string qNONTdbtDMZVsn = string("nrPzKQMYqRUdcHAnmpmqCXQCWkjvEFNyJvvoCtSIRxNeamm");
    double nbMybVAglQItY = -767792.2614894448;

    return nbMybVAglQItY;
}

string dfkazlmXEKFn::KIyJvugSoFTBq(int OVEEmBSYs, string QERCVUGKeiyTs, int WSVoijHXzvSA, bool ftGXTzlQzLQ)
{
    double AleIPQctpW = -710420.1768781091;
    int MetapnpaZkSay = 791784766;
    double pyPBkeYObfCgp = -2060.538172960211;
    int SaryDufkwhJj = -1383197380;

    for (int iwjqSkArcYq = 1189310578; iwjqSkArcYq > 0; iwjqSkArcYq--) {
        AleIPQctpW *= pyPBkeYObfCgp;
        WSVoijHXzvSA /= MetapnpaZkSay;
    }

    for (int JtpZIlW = 1844545528; JtpZIlW > 0; JtpZIlW--) {
        MetapnpaZkSay /= WSVoijHXzvSA;
        AleIPQctpW *= pyPBkeYObfCgp;
        OVEEmBSYs *= MetapnpaZkSay;
    }

    return QERCVUGKeiyTs;
}

double dfkazlmXEKFn::atInaRSWj(double IFZrqFWKiHwFSnY)
{
    bool lkVgbacGjVJ = false;
    int EoWUYqMI = 1385985765;
    int JFrjHG = -25279366;
    int ebhFppGOBwfUp = 586831932;
    double iXDRvbbGtUF = -727148.4962046219;
    string pElcuVCIKIbA = string("TjvxAEZxgPsYQegygpEIQMugpoLiJrNHoKwAMqdvwvikAsGDXjCSHPDbSxYVHaqmRCohwAoORBtEkPFtcwBlxRkTJLfYXdjleN");
    double NYjelx = 989857.549462614;
    bool NxoqAfyBrWNw = false;
    bool NcoOXKydhhxy = true;

    if (NcoOXKydhhxy == false) {
        for (int fhwzl = 1606389269; fhwzl > 0; fhwzl--) {
            iXDRvbbGtUF = NYjelx;
        }
    }

    return NYjelx;
}

double dfkazlmXEKFn::EGpGpwBZzBsY(bool WAQljppxXO)
{
    string uONxZGKnXeXR = string("rmyLizOYSRDWOFmbQNrZnFXRUfFQJLevNqCOUqIACmMZHKFYqAWiEFXswFHhsYZeTgWthfnYDPfnSpXBNlxFPGOsO");
    double TJUwaBFEwJAMQ = -262203.4468486197;
    string fiprAPUTQjteV = string("UtVIoThsLgYhhMQWkBDQXLIFDtJGMQirlSuMOpsrjyCnaDtftcnaPDmGgLAjhXKDwZrTXeOqZKnXLxcmXi");

    for (int KlviJSbrWLwIQRv = 1805667794; KlviJSbrWLwIQRv > 0; KlviJSbrWLwIQRv--) {
        fiprAPUTQjteV += uONxZGKnXeXR;
        fiprAPUTQjteV += uONxZGKnXeXR;
    }

    for (int bRZbiPRnayRGaP = 1334866608; bRZbiPRnayRGaP > 0; bRZbiPRnayRGaP--) {
        uONxZGKnXeXR += uONxZGKnXeXR;
        fiprAPUTQjteV += fiprAPUTQjteV;
        fiprAPUTQjteV = uONxZGKnXeXR;
        uONxZGKnXeXR = uONxZGKnXeXR;
    }

    for (int dItmWEiZ = 1082336185; dItmWEiZ > 0; dItmWEiZ--) {
        WAQljppxXO = ! WAQljppxXO;
        fiprAPUTQjteV += fiprAPUTQjteV;
        uONxZGKnXeXR = fiprAPUTQjteV;
    }

    for (int CNhRxg = 1649485420; CNhRxg > 0; CNhRxg--) {
        continue;
    }

    for (int ImFXyRg = 1279617319; ImFXyRg > 0; ImFXyRg--) {
        WAQljppxXO = ! WAQljppxXO;
    }

    if (fiprAPUTQjteV < string("UtVIoThsLgYhhMQWkBDQXLIFDtJGMQirlSuMOpsrjyCnaDtftcnaPDmGgLAjhXKDwZrTXeOqZKnXLxcmXi")) {
        for (int fNWcEdwwUSEUh = 847671119; fNWcEdwwUSEUh > 0; fNWcEdwwUSEUh--) {
            WAQljppxXO = WAQljppxXO;
            TJUwaBFEwJAMQ += TJUwaBFEwJAMQ;
            uONxZGKnXeXR = fiprAPUTQjteV;
        }
    }

    return TJUwaBFEwJAMQ;
}

double dfkazlmXEKFn::FHFJZT(string GaXWlOIM, string cxRhUMkvewXDkW)
{
    int EfqDMzzLLxCVo = 2087732177;
    double tqqCAxHrX = -842656.014418627;
    double kDXlFufLDaBgRd = -436709.2579661381;
    bool JzxhqcZInWd = false;
    double wftMr = 393031.2851373678;
    bool epudBmBPYrVwuU = true;

    for (int cyEBxHN = 781965648; cyEBxHN > 0; cyEBxHN--) {
        continue;
    }

    return wftMr;
}

bool dfkazlmXEKFn::YnHoPlGUeywPdEXF(double EAKLlbu, string RAteYtvjeQhIwoj, double BQgYl, string CHCWHucP, bool ZTTOXndhvujuQaVe)
{
    double TUFBfgGIiqAxNl = -820498.2320278132;

    for (int htGZxFEUuAjbvM = 751680992; htGZxFEUuAjbvM > 0; htGZxFEUuAjbvM--) {
        RAteYtvjeQhIwoj += CHCWHucP;
        BQgYl /= TUFBfgGIiqAxNl;
        EAKLlbu -= BQgYl;
    }

    if (BQgYl < -671607.567947748) {
        for (int IWCTPMqvSUpSty = 898396034; IWCTPMqvSUpSty > 0; IWCTPMqvSUpSty--) {
            EAKLlbu = EAKLlbu;
            TUFBfgGIiqAxNl *= TUFBfgGIiqAxNl;
        }
    }

    return ZTTOXndhvujuQaVe;
}

double dfkazlmXEKFn::ZLUaJgfHC()
{
    int LUqJFhAfEAlteJtT = 1731916307;

    if (LUqJFhAfEAlteJtT >= 1731916307) {
        for (int kJwOKbATR = 1822545481; kJwOKbATR > 0; kJwOKbATR--) {
            LUqJFhAfEAlteJtT *= LUqJFhAfEAlteJtT;
            LUqJFhAfEAlteJtT -= LUqJFhAfEAlteJtT;
            LUqJFhAfEAlteJtT /= LUqJFhAfEAlteJtT;
        }
    }

    if (LUqJFhAfEAlteJtT != 1731916307) {
        for (int XHFwNr = 1498530207; XHFwNr > 0; XHFwNr--) {
            LUqJFhAfEAlteJtT *= LUqJFhAfEAlteJtT;
            LUqJFhAfEAlteJtT *= LUqJFhAfEAlteJtT;
        }
    }

    if (LUqJFhAfEAlteJtT >= 1731916307) {
        for (int ERkGMjpEkaLeMG = 212675476; ERkGMjpEkaLeMG > 0; ERkGMjpEkaLeMG--) {
            LUqJFhAfEAlteJtT -= LUqJFhAfEAlteJtT;
            LUqJFhAfEAlteJtT /= LUqJFhAfEAlteJtT;
        }
    }

    return 508819.472327204;
}

void dfkazlmXEKFn::FUjQjh(int PHdPJpmBxnudKmh)
{
    bool YTpxKUOPUUcgt = false;
    int XESnNOLBvPteQ = 1384415033;
    double RLCffgHV = 916299.1331722253;
    string HRTMYioGm = string("WmNMWYsBvvcdnvUUJqbtGMvEzHhATHIFCvEydPBTQwdeSFIdvfNmIoYJaDZVsWtiZpmQrwBiZkTgIzHrJTKKPSenCxwXRdBXczEaNDjFBGSbhxqwtWMwhCXiVlx");
    bool dexiLjMehyxEe = true;
    double dFCwFfuLj = -562530.2479462635;
    double AxCIuTeVxNf = 509248.19746576477;
    bool yNYDkeVLpW = false;

    if (dFCwFfuLj > 916299.1331722253) {
        for (int GTEfOAMyilKiiBo = 2042516090; GTEfOAMyilKiiBo > 0; GTEfOAMyilKiiBo--) {
            YTpxKUOPUUcgt = ! YTpxKUOPUUcgt;
            YTpxKUOPUUcgt = ! YTpxKUOPUUcgt;
            yNYDkeVLpW = dexiLjMehyxEe;
        }
    }

    for (int zFEeQel = 13504224; zFEeQel > 0; zFEeQel--) {
        yNYDkeVLpW = ! dexiLjMehyxEe;
        AxCIuTeVxNf -= dFCwFfuLj;
    }

    for (int AaLHddCsTiww = 1133717554; AaLHddCsTiww > 0; AaLHddCsTiww--) {
        RLCffgHV += dFCwFfuLj;
        PHdPJpmBxnudKmh -= PHdPJpmBxnudKmh;
        yNYDkeVLpW = YTpxKUOPUUcgt;
    }
}

string dfkazlmXEKFn::SeXAWjHYBnTSvRN()
{
    double lheSWZoZB = -385319.56259880593;

    if (lheSWZoZB >= -385319.56259880593) {
        for (int QUwJiYWfBx = 284058713; QUwJiYWfBx > 0; QUwJiYWfBx--) {
            lheSWZoZB /= lheSWZoZB;
        }
    }

    if (lheSWZoZB == -385319.56259880593) {
        for (int wrWMBCPprCE = 112051993; wrWMBCPprCE > 0; wrWMBCPprCE--) {
            lheSWZoZB = lheSWZoZB;
        }
    }

    if (lheSWZoZB <= -385319.56259880593) {
        for (int RjbUiixVf = 196971939; RjbUiixVf > 0; RjbUiixVf--) {
            lheSWZoZB -= lheSWZoZB;
            lheSWZoZB += lheSWZoZB;
            lheSWZoZB -= lheSWZoZB;
            lheSWZoZB -= lheSWZoZB;
            lheSWZoZB += lheSWZoZB;
            lheSWZoZB -= lheSWZoZB;
        }
    }

    if (lheSWZoZB >= -385319.56259880593) {
        for (int chGuWTBrQcNW = 1062888985; chGuWTBrQcNW > 0; chGuWTBrQcNW--) {
            lheSWZoZB *= lheSWZoZB;
            lheSWZoZB += lheSWZoZB;
            lheSWZoZB += lheSWZoZB;
        }
    }

    return string("iVFIliaIrFIldwjVTvGjDoNnPpEJYpREqhZLalZZKsJoGLQpbudAItxafSpPvIFlxLuMpDrYKKAGEGQKgGHBUCfwKFmoxjEHkJyAbMNfgFrIxFJcJlqdhvcxcAZcDNjQlNOAfpXshNbVOsaM");
}

void dfkazlmXEKFn::UVYWvfDEpL()
{
    int uvQnd = 677184699;
    int TQTUEY = 1756399128;
    double XGSuYwn = 532936.5111129183;
    bool nbampklxuaVntOKQ = false;
    double kHqxKNPsWH = 430703.58865463827;
    string VhbtUemyPImas = string("yxMRylzMJHeNlHVRsJgbGVcPcSQbnwBeFdtOlCdGjUMGAYKEEJadRMGJSwsXjzIZrQHmQuEpsNDdzJywxdRkMxLCGEVChvgUxXVrAeZmCVIKA");
    bool PeCEpmmQaBI = true;
    bool IiOEJIhp = true;
    int mPLeJPKFV = -1647387858;
}

double dfkazlmXEKFn::GWJQDS(double KuugQihIz)
{
    double VIeLMhwGCLsfHfP = -323850.0358839158;
    int QszrFrhJ = -1953433499;
    string vKvKwKt = string("yIGjAsZdciDNNhevobmPzetNZuwarFmDfcJKxXSfFDncYDjcIHWCHWIeQGUYeauwoUInvqJbwKgWNLYTlnCvdJrFvWMYASmlZjYjCbpinwjzbeIcZzpMTczCQRXJUzhPeUlNesAvesMwHojANayBKiHayPtdyMyNlSCtHbhVroVpJuArYIbeQqnSDLeEOijuUHYiJrhQHnnTwAAdHUshcROkNPUevraC");
    string IuzZxLqby = string("IiqhoHbHoFzHThQMLyLWiUppOIQtfUMLBaqmXcrQOwAJEbDGL");
    int pcPhhZL = 93265088;
    string NimDCcM = string("WGXEZomrEYdKckRjYaWMVxIHIaLEsMafojwdpglAsqvUwHnXXePIHAJqLBakjGuVjJQkfEgaYpfWpcaTjlLCFKEEXtLdHWJkFDTtBxZJUlJAhYzqTlFHkVGXXrRLx");
    int vqtRFbnnSS = 1527595310;

    for (int pEFZxPTLxO = 724786018; pEFZxPTLxO > 0; pEFZxPTLxO--) {
        pcPhhZL -= pcPhhZL;
        pcPhhZL = pcPhhZL;
        vKvKwKt += IuzZxLqby;
    }

    for (int MwAOfLJFeyenQZmq = 950545179; MwAOfLJFeyenQZmq > 0; MwAOfLJFeyenQZmq--) {
        vKvKwKt += NimDCcM;
        NimDCcM += NimDCcM;
        QszrFrhJ = QszrFrhJ;
        VIeLMhwGCLsfHfP -= VIeLMhwGCLsfHfP;
    }

    if (VIeLMhwGCLsfHfP != 216074.7212453557) {
        for (int NGDVtXS = 194396574; NGDVtXS > 0; NGDVtXS--) {
            QszrFrhJ -= QszrFrhJ;
        }
    }

    for (int jZsNA = 1530917207; jZsNA > 0; jZsNA--) {
        IuzZxLqby = NimDCcM;
        NimDCcM = vKvKwKt;
    }

    for (int DbqMWVHfOsgVAHta = 1335214937; DbqMWVHfOsgVAHta > 0; DbqMWVHfOsgVAHta--) {
        vKvKwKt += NimDCcM;
    }

    for (int rjhxaJlHm = 1799757253; rjhxaJlHm > 0; rjhxaJlHm--) {
        NimDCcM = vKvKwKt;
    }

    return VIeLMhwGCLsfHfP;
}

dfkazlmXEKFn::dfkazlmXEKFn()
{
    this->ZtnRxKhDNcqPBxVo(string("YxjFCGFNaBUGjLuOuJvPAaAqlffiuganBseVgXgwGgTrqlQQPytbYOVMeElMzpgQWDedJzYNdcYQcXuIPCgDaErQHGKSogNJeBhDzPFjBZabdPMSMHLGWRdZxENVQgMpnsEWAqBjIZmPuUINuvPtiWKAmdKVseqWisSbpISCHSCHGpvPXyiRjjvYKyJWviOmwknPSxsVdEHoMHzaoTUlginpMxqyy"));
    this->SgHPc(1030159.3116216453, false);
    this->ThFSUkO(string("XwFwkcsMcxwNHmJdlPDyVDSVoBgpTGDdhINPWmDejVVTwzQIcCUmGcFhpxGefHTmIhYNJqIaODGFgfVKTglxjXpYdVnlUzbClwFeBMBvRScTEKIoLvWT"), 2042276289);
    this->hxhrOxkdIrdy(string("XPsfwkKhTQYXEUgUrNRKXjhNZXznJWciAKLCGVfVneJuUfXlItMcOTCwFeQacVZGWpdCKeJZqNOxraTrTsXjKbKkMXjrwZjOkElhcZfGCYjBQwxdzJcxdzUeRMXEMsvOxIxkxRkCIwPSqzSlNYvGpXXzXAnXMBWVFdcyQpylAEusCnEPOGjIpac"), 1743810581);
    this->KIyJvugSoFTBq(-1441703491, string("PHzDgLGfSLCbrVASREXPWoziGUXhoMfQ"), 746124750, false);
    this->atInaRSWj(987463.6181805918);
    this->EGpGpwBZzBsY(false);
    this->FHFJZT(string("nJKHLHQK"), string("mezRnWVLuLrJgfuVtQrNhUyZTlnihhAeeDdOEtKbOpFgKzNRvErLEtYmkYjtgaVwibukZGkjyAWIjZHtcVfMJKlbGFHcJnUtXOvsXhvaAZZEHiYOirZjDtXaxmKXlUztZSZLhETjezEeoooZSXLuGRAqBqBTEBJBhEgMoIITZYyMeMBbNtgItztAwKfZXrruEFJlenCJjdJlIIVexfZQBvH"));
    this->YnHoPlGUeywPdEXF(-671607.567947748, string("NIYFvPGZIktCrfBrCcVtoleDVpVAYlpTPuQGGwdDJyBmcquDjOuoglKVdbCKdzZcIgFeVOPBMaVwPbjZotwaCxvruRiHkJHDLNaISMDDPhAKgbNGTXpCXveujbEzDWykjqfSNKNknxHzwXyxLxNNXHde"), 403211.00646675524, string("UrsXCVcuTGWocTQWHZfNlNCYCFaYDVcIhyXJTTBSqJeqKJMxDxuLUpqMqCsHoLQRHRxddpmZRJSArxrrdnMxuWUczsWpGYgOBPcQAfCtBBdGNOEItGkUySbFMPOloMpeOgvZBLygkzPeeMAKKCSmPfIgMUfOermtXHxsMaWvYefURkVfbxVyjHIoawUvDsgYCnVYKosKcFwBQetnWRJVyQRT"), true);
    this->ZLUaJgfHC();
    this->FUjQjh(1791530634);
    this->SeXAWjHYBnTSvRN();
    this->UVYWvfDEpL();
    this->GWJQDS(216074.7212453557);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PAYOlhdvYEeiP
{
public:
    double BOrhQpdzTy;

    PAYOlhdvYEeiP();
    double ZeUsfYpbu(double SnpZpoVWkPwT, int THOILUUzRX, double bHDgRfChIH, bool PxDZpppKAkEAViJ);
    void NYQCLajKI(bool XZbGhdh, double RhoszbFghW, double gBQJucbvvYLHA, int kRmmGbAenrO);
    int JzXOLaKVDy();
    int xoktgHUDHhg(double kwYzAqamkQ, string DGGMLfXVggNvW);
protected:
    bool icSEGjCMYWBoeom;
    double ELWmGQn;
    bool tWrPPZkdnqkgAbGq;
    double lIdhHlmiRKpMxYGt;

private:
    int zgCxiEUzFZK;
    string FJeqmHpcpXTejk;
    bool rgcoBnxxullhNLCr;
    int lyDkiYpXVN;
    bool ESdpwVrjXh;

    string RedSxHlCTCt(double SnLJCyN);
    void yNTxokr(bool axjOW, string BzPyvMyYzpLpaOfN, double atqNFOqnBfiCLp);
};

double PAYOlhdvYEeiP::ZeUsfYpbu(double SnpZpoVWkPwT, int THOILUUzRX, double bHDgRfChIH, bool PxDZpppKAkEAViJ)
{
    double GCoLLQZS = -30699.22842739859;
    double VFvoXeUh = 312602.0323749976;
    bool lsfoE = false;
    string VuagLhEO = string("FbIzNUGOGgiFtrPJoiTAJLNoNGkHOKHUtfJyhKqbYcDBBfVauGDKSMXzdQEFgmMCAoGBavhXxCQcfBPUClIkNBkhog");
    int RvOBLHTVHO = 1045241781;

    for (int CAFyx = 1871824753; CAFyx > 0; CAFyx--) {
        VFvoXeUh -= bHDgRfChIH;
        SnpZpoVWkPwT *= VFvoXeUh;
    }

    for (int XOYBCuTXIwOUx = 368805070; XOYBCuTXIwOUx > 0; XOYBCuTXIwOUx--) {
        lsfoE = ! lsfoE;
        VFvoXeUh -= bHDgRfChIH;
    }

    if (bHDgRfChIH >= 226460.54515336783) {
        for (int TNzSNKFqFLRZHKjl = 1378852120; TNzSNKFqFLRZHKjl > 0; TNzSNKFqFLRZHKjl--) {
            VFvoXeUh += VFvoXeUh;
            GCoLLQZS = VFvoXeUh;
        }
    }

    return VFvoXeUh;
}

void PAYOlhdvYEeiP::NYQCLajKI(bool XZbGhdh, double RhoszbFghW, double gBQJucbvvYLHA, int kRmmGbAenrO)
{
    double kafaPmgY = -606211.2929907261;
    int KbeSmRDyQKg = 1869266115;
    bool OCBjfJSSnjhRv = true;
    bool QQPEJtjsP = false;
    double vojpQpcEkyKhlpI = -10516.460556168216;
    int jrIVTQj = -137532982;
    double KbayUDz = -96277.38715003552;
    int qNZJJImIRnlWm = -346366830;
    bool BEaFJLyvDSlz = false;

    if (qNZJJImIRnlWm >= 1869266115) {
        for (int kXLSmAfM = 1024026853; kXLSmAfM > 0; kXLSmAfM--) {
            KbeSmRDyQKg += qNZJJImIRnlWm;
        }
    }

    for (int obsIXCbr = 297872583; obsIXCbr > 0; obsIXCbr--) {
        continue;
    }

    for (int jmRwOMa = 1793012753; jmRwOMa > 0; jmRwOMa--) {
        KbayUDz = kafaPmgY;
    }
}

int PAYOlhdvYEeiP::JzXOLaKVDy()
{
    double DtGGASlEEdoJ = -770281.032820787;
    double FPtHu = -387802.7778571214;
    bool aAeBnGLMkyD = false;

    for (int ZJmipWvMpqpGQmyu = 535811385; ZJmipWvMpqpGQmyu > 0; ZJmipWvMpqpGQmyu--) {
        aAeBnGLMkyD = ! aAeBnGLMkyD;
        DtGGASlEEdoJ = FPtHu;
        aAeBnGLMkyD = ! aAeBnGLMkyD;
        FPtHu = FPtHu;
    }

    for (int CypJyxMZUCHwm = 933466567; CypJyxMZUCHwm > 0; CypJyxMZUCHwm--) {
        aAeBnGLMkyD = ! aAeBnGLMkyD;
        DtGGASlEEdoJ += DtGGASlEEdoJ;
        FPtHu += DtGGASlEEdoJ;
        FPtHu += DtGGASlEEdoJ;
    }

    if (FPtHu >= -387802.7778571214) {
        for (int XSBJdXqfNUnSoA = 636871627; XSBJdXqfNUnSoA > 0; XSBJdXqfNUnSoA--) {
            aAeBnGLMkyD = ! aAeBnGLMkyD;
            DtGGASlEEdoJ += FPtHu;
            aAeBnGLMkyD = aAeBnGLMkyD;
        }
    }

    if (DtGGASlEEdoJ != -770281.032820787) {
        for (int oMifPFVTbSTCdops = 1687411306; oMifPFVTbSTCdops > 0; oMifPFVTbSTCdops--) {
            aAeBnGLMkyD = ! aAeBnGLMkyD;
        }
    }

    if (DtGGASlEEdoJ != -387802.7778571214) {
        for (int ReCUedl = 345913795; ReCUedl > 0; ReCUedl--) {
            FPtHu -= FPtHu;
            DtGGASlEEdoJ *= FPtHu;
            aAeBnGLMkyD = aAeBnGLMkyD;
            DtGGASlEEdoJ /= FPtHu;
            FPtHu *= DtGGASlEEdoJ;
            DtGGASlEEdoJ *= DtGGASlEEdoJ;
            FPtHu += DtGGASlEEdoJ;
        }
    }

    return -1876391713;
}

int PAYOlhdvYEeiP::xoktgHUDHhg(double kwYzAqamkQ, string DGGMLfXVggNvW)
{
    bool TlnUzUpjDdVTvj = false;
    double QhVJof = 768197.1401943992;
    double AZkuphxxwvJWP = 124800.82084974971;
    double RSEzrUhkOtJ = -388978.5943720398;
    bool gbMUUSDT = false;
    string lDCjBUqNBEs = string("IBGqITqwhAy");
    string JYhyjIgqrJQYEHG = string("JRmoePdBEpyuPWQuMhakOeKfxXMnvYmrNZGoioMBVLkGTjRHomeZKjnU");

    for (int torGfUNaY = 534475242; torGfUNaY > 0; torGfUNaY--) {
        RSEzrUhkOtJ /= kwYzAqamkQ;
        DGGMLfXVggNvW = lDCjBUqNBEs;
        kwYzAqamkQ /= RSEzrUhkOtJ;
    }

    for (int pKMmTE = 108303148; pKMmTE > 0; pKMmTE--) {
        kwYzAqamkQ *= RSEzrUhkOtJ;
        QhVJof *= QhVJof;
    }

    if (TlnUzUpjDdVTvj != false) {
        for (int ggTnsMMU = 1468935029; ggTnsMMU > 0; ggTnsMMU--) {
            kwYzAqamkQ /= RSEzrUhkOtJ;
        }
    }

    for (int rKpNa = 1115172219; rKpNa > 0; rKpNa--) {
        continue;
    }

    for (int dvDYdHmcSUpJux = 1923456121; dvDYdHmcSUpJux > 0; dvDYdHmcSUpJux--) {
        kwYzAqamkQ /= AZkuphxxwvJWP;
        DGGMLfXVggNvW = lDCjBUqNBEs;
        RSEzrUhkOtJ += AZkuphxxwvJWP;
        gbMUUSDT = gbMUUSDT;
    }

    return -1022035032;
}

string PAYOlhdvYEeiP::RedSxHlCTCt(double SnLJCyN)
{
    string hAMZRL = string("JVVdlkyhSDkBQTdenwJgQbaYptkVzyuLahTRUblMNYXVktrZELwmdCUqpeQBWEzOYYYUgHSuXjTlgEbYhlIRPyJuEaGChiokRyEKkgyAUfpNbJDxZWMFkRVbacVDYvhJABwzabrSypmabSzVIdUHrRPEtrzbVIqPdGwxwRHnRGPFaeHXXSCfMeGfMxCOLNZgpESJzklTuBxduKkTunqtEhvzGasLdIFSLfjCTJscmPjfNizmJLGvkn");
    bool AquFtInM = false;
    string BrXfqGex = string("auIiTjsJaRBomfhkjDpksxVxVtrnBsUgyXasHMmTLrAxDESexxKcYfXWzVYQUSMEGHMFXBLNlhxSfkwQDanrlUJXNoidVosgWQJeycYotRycdooWLCBRBYTnjVb");

    for (int RmhTmBW = 2001414188; RmhTmBW > 0; RmhTmBW--) {
        AquFtInM = AquFtInM;
        BrXfqGex = hAMZRL;
        SnLJCyN *= SnLJCyN;
        BrXfqGex += BrXfqGex;
        hAMZRL += BrXfqGex;
    }

    for (int DCeDY = 1144660721; DCeDY > 0; DCeDY--) {
        AquFtInM = AquFtInM;
    }

    for (int QFSJSsVYyah = 1990525117; QFSJSsVYyah > 0; QFSJSsVYyah--) {
        hAMZRL += hAMZRL;
        BrXfqGex = BrXfqGex;
        AquFtInM = AquFtInM;
        hAMZRL = hAMZRL;
    }

    return BrXfqGex;
}

void PAYOlhdvYEeiP::yNTxokr(bool axjOW, string BzPyvMyYzpLpaOfN, double atqNFOqnBfiCLp)
{
    string lDVdxoDBBZfsb = string("VSjbQHaJcmzXpVyKemhnttUHzTjAnYyNXHXpEBOPlnzrmahycZmPWmqZdFnkstPgKbFWQZsKdmKIVKuhzVmrRhvJpFyurVISwjzlVOyrmiKXqXyLgMaYPzaMYFqXDhNuxmdsDxsORooRtQuoAdRgLLFRvxNLAS");
    double HboPsuXYy = 87716.54009822155;
    bool QTffTq = false;
    bool loYSdlFWfjm = false;

    if (QTffTq == true) {
        for (int SWwEjsp = 565203321; SWwEjsp > 0; SWwEjsp--) {
            QTffTq = QTffTq;
        }
    }
}

PAYOlhdvYEeiP::PAYOlhdvYEeiP()
{
    this->ZeUsfYpbu(226460.54515336783, -326519164, 552075.3945050475, false);
    this->NYQCLajKI(true, -749656.9808885982, -822789.104212286, -1554301330);
    this->JzXOLaKVDy();
    this->xoktgHUDHhg(-240489.37596627302, string("XCpHYZMowQPnDkVrQfHyvoeAbediZQNRpUhbmGEmFmfDvyVglbWmRyuFGhaMeRbSN"));
    this->RedSxHlCTCt(117648.31592684226);
    this->yNTxokr(true, string("GqNhosSXbsMRbFsmzkFXaXiWJYpEKUeNYgXKavHzUgpcSXpMDxABnVHkDdtiOonbCofcYtYjuUTwIQzRgXRJQFUqXZGjVPkWHTSUuMalDZIWpOpfDsDxHjxrRPyexRjaZuxSbTYnczUGJEheOxiRRmxbhGBaXwgRnVVhFnTgcVmowWQThWhYupmlpNcWVCaFjvCPNlNnPDgCNSsTRnF"), -76403.48233508752);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dfHyZFJXKdNotU
{
public:
    double ZxtWeNK;
    bool QVpVNtbv;
    double wJTeO;
    int SjAiI;
    double VwCpkYQpPVtnxh;
    int OSgaNENB;

    dfHyZFJXKdNotU();
    double wYZVvDauiYJNB(int kpgIwoRwJPTjGLay, int xEfXQET, bool nnpNP, double jMkkQuDYybT, int fOGPxeYywcZV);
    string tlusHXftVf(bool AQCpgYD);
    double LFfNzNqTrIX(int pYrrICECek, double PSuhuwxSYrBbw, bool TOnRXAvGqYApm);
    bool NKYnjWU(string eCfZKwROEPPaNd, string edJlX);
protected:
    double qYYAMHAZUceJuPhb;
    int OiEUMqmJzCamMDZ;
    int KnPffuOQaPI;

    void YwzzGWN(double hDheYjpVVKbzvop, int xsHmaRdvGqnzNQZw, bool HaRWtysi, double OzmOwr, int exkkvTiSEjYMqLn);
    void hyPAbvCjg(int FEKgPylsfdAqGu, string EmDKezlIBAQ);
    double bfsGPqOwzu(bool kdaWdIYDfsVbQZce, int vCrgfOoHrCtvrCr);
    bool GrUmMNVpPMk(string HAVhGLESoP, bool uumuGacnyZNSEa, double XccqNMbuTtRLD, int MrkFqcHoLBJ, double fSAedcw);
    string uPKlYMaMx();
    void YwJesaJIcxTv(string VWYhzhQxQTVPmNcI);
    string DlqKDiwvtw(bool TEBRTslMPGLtWy, int HdeatafUkkOp);
    string KoHaCO(double IDlrzDkyOTKSSY, string qJNaxjmrgCizsj, double zchpjcBLSNcunva);
private:
    string WeNTQNnFx;

    string gOMDSBANHcEBnC(double RCGiiqsnQ, double JACTXRMTVsLHKVjB, int MWUBoUiTgjJpX);
    string EFUYJAOpyIGgmGF();
    bool lcFCgYWy(string VRoKaLYcwRzfX, string ByHnZpnrcYtnw, string iNdmnlzon, int lKzBRd, string wPVReYqEVBNnFZH);
    double QijYxxSKgOT(int OSSYZIpbS);
    string ZMhWBw(double vFqcZefiNvdhSZ);
    int XgEjBqerbHK(int xzuhgaYUii, int kZYVKRwKTQtFpOJ);
};

double dfHyZFJXKdNotU::wYZVvDauiYJNB(int kpgIwoRwJPTjGLay, int xEfXQET, bool nnpNP, double jMkkQuDYybT, int fOGPxeYywcZV)
{
    double shsCheLQqFE = -657086.9972583231;
    double DyicRVZBTjlMzMu = -923232.9368689384;

    for (int FrIvryOJdzcqZd = 1543556525; FrIvryOJdzcqZd > 0; FrIvryOJdzcqZd--) {
        DyicRVZBTjlMzMu += DyicRVZBTjlMzMu;
        jMkkQuDYybT *= shsCheLQqFE;
        xEfXQET -= xEfXQET;
        jMkkQuDYybT -= shsCheLQqFE;
        jMkkQuDYybT -= DyicRVZBTjlMzMu;
    }

    for (int pwyRLZyqAGIUGKIk = 468325827; pwyRLZyqAGIUGKIk > 0; pwyRLZyqAGIUGKIk--) {
        shsCheLQqFE -= jMkkQuDYybT;
        fOGPxeYywcZV *= xEfXQET;
    }

    if (xEfXQET == 639634338) {
        for (int JmBLQBmIVhS = 1764118556; JmBLQBmIVhS > 0; JmBLQBmIVhS--) {
            shsCheLQqFE *= DyicRVZBTjlMzMu;
            DyicRVZBTjlMzMu -= jMkkQuDYybT;
        }
    }

    if (xEfXQET <= 612175624) {
        for (int iMfymMj = 1864046687; iMfymMj > 0; iMfymMj--) {
            fOGPxeYywcZV -= xEfXQET;
            fOGPxeYywcZV += fOGPxeYywcZV;
            xEfXQET = kpgIwoRwJPTjGLay;
            DyicRVZBTjlMzMu *= jMkkQuDYybT;
        }
    }

    return DyicRVZBTjlMzMu;
}

string dfHyZFJXKdNotU::tlusHXftVf(bool AQCpgYD)
{
    string VJvaqQtqib = string("ENKYWIJLeDLcsBbGFHSjbWLcKMifoatYLvipiioV");
    string iRZSJukBZ = string("OjpbZffQypBShXfFQKhFBtJaFDhIyAsEsISWUHIgJMJHtTabPebGlAKFUGHEFPynkgEDfpAOKyEeeULjVDpJfXcZrsbgBKDZarhqapsOXxWxFmBSuCjXBopVYrlZmiDFkeMUxbNnylrJEHqUDwDhtSfGpUDOTBKGKOVuFkYYhBzYCOOfPdnbgKnwpwDjaSqCwbDycmBUbexRnznepDtqKKWoHLzcQfflovIlqKnXEtSAmWYyV");
    string HIxvOEWN = string("gEsyopCfTYSBeDrpVIizkgCknlJXWOLcONqhBgJnJqWDqtu");
    int fWXTmHIaGQJoLl = -1924139652;
    bool FqmVhpEIF = false;
    int TdhAkUNcZwsJnhiU = 1948808646;
    int iGRcVDQVnzdIEHWz = 1445046927;
    bool rsVkPStuzBm = false;
    bool XSqXWa = false;

    for (int KpXnoewtKWtof = 890072195; KpXnoewtKWtof > 0; KpXnoewtKWtof--) {
        continue;
    }

    if (HIxvOEWN > string("ENKYWIJLeDLcsBbGFHSjbWLcKMifoatYLvipiioV")) {
        for (int jcRChhVN = 541658491; jcRChhVN > 0; jcRChhVN--) {
            fWXTmHIaGQJoLl = fWXTmHIaGQJoLl;
            iGRcVDQVnzdIEHWz = fWXTmHIaGQJoLl;
            FqmVhpEIF = ! rsVkPStuzBm;
            AQCpgYD = ! AQCpgYD;
            VJvaqQtqib += iRZSJukBZ;
        }
    }

    return HIxvOEWN;
}

double dfHyZFJXKdNotU::LFfNzNqTrIX(int pYrrICECek, double PSuhuwxSYrBbw, bool TOnRXAvGqYApm)
{
    double koIVZYWGZTBVgo = 753982.3075273827;
    int BdQOOMGMH = 1639497683;
    int epffADjVoVbskmT = 1707441355;
    bool AqCNNNkKaw = false;
    double ouDKhuqX = -960308.9320763989;
    string yrIWfhDjNRzZG = string("fKLLfeExpjdhSPtygpXFvMlJCHmIkrKXcBmbKSwPnCkWjqIMlTBmtuC");

    for (int tuclNfdXYt = 383796188; tuclNfdXYt > 0; tuclNfdXYt--) {
        koIVZYWGZTBVgo -= ouDKhuqX;
        BdQOOMGMH *= BdQOOMGMH;
    }

    return ouDKhuqX;
}

bool dfHyZFJXKdNotU::NKYnjWU(string eCfZKwROEPPaNd, string edJlX)
{
    string NjbwemRN = string("bwuRssZYwbgTBfamsbTOlROzVDMYmsSPkScVmegghPQnpNIGRKVOe");
    bool mClMiIAa = true;
    int yENvNrEnXcaxDCK = 343072364;
    bool kqXsGyF = false;
    bool gAGSsxFd = false;
    double XCIPQmRkxxqPD = -556222.8116981424;
    bool TvkCCrvIOc = true;
    int WIQKUaJmQlx = 1630772658;
    bool gkKtZArq = true;

    return gkKtZArq;
}

void dfHyZFJXKdNotU::YwzzGWN(double hDheYjpVVKbzvop, int xsHmaRdvGqnzNQZw, bool HaRWtysi, double OzmOwr, int exkkvTiSEjYMqLn)
{
    int OsITTLGtSSH = 1089492647;
    int fAkCzTMUsMJP = -1125904004;
    bool vlXbewEmO = false;
    bool DNKkcsOjOBfehPv = false;
    int hzavGYRujN = -1326861163;

    for (int muGkFRxqCEsIofNe = 153988055; muGkFRxqCEsIofNe > 0; muGkFRxqCEsIofNe--) {
        hzavGYRujN -= OsITTLGtSSH;
        fAkCzTMUsMJP *= OsITTLGtSSH;
        OzmOwr -= hDheYjpVVKbzvop;
        vlXbewEmO = vlXbewEmO;
        vlXbewEmO = ! DNKkcsOjOBfehPv;
    }

    for (int rRXnEca = 1195659522; rRXnEca > 0; rRXnEca--) {
        OsITTLGtSSH += exkkvTiSEjYMqLn;
        hzavGYRujN *= xsHmaRdvGqnzNQZw;
    }

    if (vlXbewEmO != true) {
        for (int dwwRUYjkz = 167905874; dwwRUYjkz > 0; dwwRUYjkz--) {
            exkkvTiSEjYMqLn = OsITTLGtSSH;
            HaRWtysi = HaRWtysi;
            hzavGYRujN += xsHmaRdvGqnzNQZw;
            hDheYjpVVKbzvop += hDheYjpVVKbzvop;
            OsITTLGtSSH = hzavGYRujN;
            fAkCzTMUsMJP *= xsHmaRdvGqnzNQZw;
        }
    }
}

void dfHyZFJXKdNotU::hyPAbvCjg(int FEKgPylsfdAqGu, string EmDKezlIBAQ)
{
    double EUnVPQSAjjjviuhV = 161643.7064912159;

    for (int cXSrsIywozyw = 347806574; cXSrsIywozyw > 0; cXSrsIywozyw--) {
        continue;
    }

    for (int uiJBCvyJhD = 1555444903; uiJBCvyJhD > 0; uiJBCvyJhD--) {
        FEKgPylsfdAqGu = FEKgPylsfdAqGu;
    }

    for (int aYjLQ = 498077063; aYjLQ > 0; aYjLQ--) {
        EmDKezlIBAQ = EmDKezlIBAQ;
    }
}

double dfHyZFJXKdNotU::bfsGPqOwzu(bool kdaWdIYDfsVbQZce, int vCrgfOoHrCtvrCr)
{
    int GpdlBsdUROdvY = 304939196;
    string rXHlyxGGqCzlz = string("EvOpSXogaqPcNsvZrBPoeUwIiZWYMqjtFSxJCrVJYTXrxxlGKMAljemsszAihrzTIrdWeknaECwgESkddWhpmHYJgUOxzuygLY");
    int NpMQXKkASsupDgHT = -1880911739;

    if (kdaWdIYDfsVbQZce != true) {
        for (int FXplQeU = 163410411; FXplQeU > 0; FXplQeU--) {
            NpMQXKkASsupDgHT *= GpdlBsdUROdvY;
            NpMQXKkASsupDgHT -= vCrgfOoHrCtvrCr;
        }
    }

    for (int oMASnmaCQwRi = 1992418460; oMASnmaCQwRi > 0; oMASnmaCQwRi--) {
        GpdlBsdUROdvY -= vCrgfOoHrCtvrCr;
    }

    return 490331.693315993;
}

bool dfHyZFJXKdNotU::GrUmMNVpPMk(string HAVhGLESoP, bool uumuGacnyZNSEa, double XccqNMbuTtRLD, int MrkFqcHoLBJ, double fSAedcw)
{
    bool rWYwc = true;
    double oqIGtDUjjHFUZ = 42446.73435519809;
    string nLQaIUktN = string("lbKTQqlFNfxvWcsuJLKVIMsdyAEPJLftgXmJpNCtzVtppiokraPUfbzjwfZPXfVdqRvgGKlCRqkfyIsJBMKlMmZLYDeQPHIlLIqGJyFskYxcPGnxZOhKtjCXolCLsdXklUrLYsKTpFysvUKXLKKVUxdSJLkLFhfRqlOETdstO");
    int dyNhQ = -1189667414;
    string dNtGonWBBBlgdiCZ = string("ItJjBAzoSElxxkOgpbXgFwfKgscnzdpMoAiNHYQTBxaGMxwWQueEsqsONCgkfHNUzfHEHQZsRvtqIOWJShsCddPkMBnGXnntNDXItvwwoRfaDNhaESkJQPwIWKwpqmtcUswhOzSFIdXlYzjRVxSrEMhrkLgJTQAxUhbxpSjrBGrGFbZhfuGJCWwvGIDcUFwwvakfnv");
    bool WJAjfBUgXaRmJmhv = false;

    for (int EvZvyIYt = 73684541; EvZvyIYt > 0; EvZvyIYt--) {
        uumuGacnyZNSEa = WJAjfBUgXaRmJmhv;
        fSAedcw += XccqNMbuTtRLD;
        dyNhQ -= MrkFqcHoLBJ;
    }

    for (int HddLVF = 1239599540; HddLVF > 0; HddLVF--) {
        continue;
    }

    for (int pDYqxoYgkKUa = 1396658618; pDYqxoYgkKUa > 0; pDYqxoYgkKUa--) {
        nLQaIUktN += nLQaIUktN;
        rWYwc = WJAjfBUgXaRmJmhv;
        uumuGacnyZNSEa = ! rWYwc;
    }

    for (int hpjKRWpM = 839686162; hpjKRWpM > 0; hpjKRWpM--) {
        continue;
    }

    return WJAjfBUgXaRmJmhv;
}

string dfHyZFJXKdNotU::uPKlYMaMx()
{
    double zJUol = 867553.2423747896;
    double zdbTg = 624886.3512039834;
    int iLzTiZHBulDfHyn = 788379435;

    for (int MRCvw = 548416289; MRCvw > 0; MRCvw--) {
        zJUol += zdbTg;
        zJUol -= zdbTg;
        zJUol /= zdbTg;
    }

    if (zdbTg > 624886.3512039834) {
        for (int lkthjxkvlqXnY = 1678994844; lkthjxkvlqXnY > 0; lkthjxkvlqXnY--) {
            continue;
        }
    }

    if (iLzTiZHBulDfHyn == 788379435) {
        for (int cHlUAcGzkjPc = 1695734867; cHlUAcGzkjPc > 0; cHlUAcGzkjPc--) {
            zJUol *= zdbTg;
            zdbTg += zdbTg;
            zJUol *= zdbTg;
        }
    }

    if (zJUol != 867553.2423747896) {
        for (int OgGmMmpTQAwbnbgL = 1501133326; OgGmMmpTQAwbnbgL > 0; OgGmMmpTQAwbnbgL--) {
            zJUol += zdbTg;
            zJUol += zJUol;
            iLzTiZHBulDfHyn /= iLzTiZHBulDfHyn;
            iLzTiZHBulDfHyn *= iLzTiZHBulDfHyn;
        }
    }

    if (zdbTg != 624886.3512039834) {
        for (int MWBDFIKNy = 1394858454; MWBDFIKNy > 0; MWBDFIKNy--) {
            zJUol *= zJUol;
            zJUol = zdbTg;
            iLzTiZHBulDfHyn /= iLzTiZHBulDfHyn;
            zJUol = zdbTg;
            iLzTiZHBulDfHyn = iLzTiZHBulDfHyn;
        }
    }

    return string("UHjjHoBMWBBIlJjGfHHdLjyQqigRRkiyWMyrvyfYpeYEPwOqQRehrZRLQfNtGwiNpxLJCWPPgFsRXJOFMwWsBdQMYTFlOZSCaqYUMKctVVHWfbylygbXbjZkWNxVkVfRUujHzmnAffJiwtXvelywwZdHBGXEpQOxiYczhynDwcMaKVlUhhXNLrYbxbH");
}

void dfHyZFJXKdNotU::YwJesaJIcxTv(string VWYhzhQxQTVPmNcI)
{
    double dpDfHqYq = -739626.927189533;
    int fwhkATCRtxkoKG = -2110508238;
    double pIwnHJlx = 70188.9622181995;

    for (int toSTnK = 1804389714; toSTnK > 0; toSTnK--) {
        dpDfHqYq -= pIwnHJlx;
        fwhkATCRtxkoKG = fwhkATCRtxkoKG;
    }

    if (fwhkATCRtxkoKG == -2110508238) {
        for (int uUWTFjkEgLjwOJ = 667441434; uUWTFjkEgLjwOJ > 0; uUWTFjkEgLjwOJ--) {
            dpDfHqYq *= pIwnHJlx;
            pIwnHJlx *= dpDfHqYq;
            pIwnHJlx /= pIwnHJlx;
        }
    }
}

string dfHyZFJXKdNotU::DlqKDiwvtw(bool TEBRTslMPGLtWy, int HdeatafUkkOp)
{
    string NkGaiXV = string("LprxyMcXEaNmaKnatjIwoZaTQlluQoFpPWfFDtthBaZAleeJOndUsCtGlyyhocggAnYWy");
    string DkgEpByalEexdA = string("geyWmLXXgaYqhXnrjQWuHW");
    bool uBvbkAUh = false;
    double WfgJyUeDm = 31564.21565685207;
    double mGiIsxlg = 163732.2028104334;
    string yoQOOwJL = string("xptljyPuADJvQNlvVqlVviFlqhlSiQkIRsjbetIRblomoXkmXTpXlgnaBgoYDoH");
    bool vJgUKxntTgukL = false;
    string vxvqUSdPjJsOxGF = string("rLWssXQIsER");
    double hdqUnZLAcX = -177550.6627661939;
    bool DuoDlhJ = false;

    for (int vMyxnVSDtGVjM = 1257450968; vMyxnVSDtGVjM > 0; vMyxnVSDtGVjM--) {
        continue;
    }

    for (int yGJWAbhUWPCMj = 424111162; yGJWAbhUWPCMj > 0; yGJWAbhUWPCMj--) {
        continue;
    }

    for (int ILFPOXbceT = 1305744784; ILFPOXbceT > 0; ILFPOXbceT--) {
        DkgEpByalEexdA += yoQOOwJL;
        yoQOOwJL += yoQOOwJL;
        DuoDlhJ = uBvbkAUh;
    }

    return vxvqUSdPjJsOxGF;
}

string dfHyZFJXKdNotU::KoHaCO(double IDlrzDkyOTKSSY, string qJNaxjmrgCizsj, double zchpjcBLSNcunva)
{
    double mJXZkcvCGKyPLrLV = -618596.455153877;
    double zvOqQJcAoheZB = 280580.3559621934;
    int apaLrodpiA = -1247380069;

    if (qJNaxjmrgCizsj != string("cuxdPtONRmrZlhLkJLODSgTDSmAYjBjEEtfhFtJXGlTCGHCQpsjoJEwLuIdfLeIWopQDIAlKboNVGczXschfCxRswzqhwdZfjGnsByIRVbOjLCPFiZqjnBQHCtcAqMMXIcziQjnakhREGOcoSbaYerbuUVgeIaKreAJhxWdTSCUlNntavBNhUHWmYgVaLDDyaYZ")) {
        for (int JOYHIn = 954383942; JOYHIn > 0; JOYHIn--) {
            mJXZkcvCGKyPLrLV = zvOqQJcAoheZB;
            zchpjcBLSNcunva += IDlrzDkyOTKSSY;
        }
    }

    for (int EWLOP = 27697782; EWLOP > 0; EWLOP--) {
        zchpjcBLSNcunva += IDlrzDkyOTKSSY;
    }

    for (int GbwCSLmCiVXSmIX = 1176433374; GbwCSLmCiVXSmIX > 0; GbwCSLmCiVXSmIX--) {
        IDlrzDkyOTKSSY = mJXZkcvCGKyPLrLV;
        mJXZkcvCGKyPLrLV -= mJXZkcvCGKyPLrLV;
        zchpjcBLSNcunva += zchpjcBLSNcunva;
        mJXZkcvCGKyPLrLV = IDlrzDkyOTKSSY;
    }

    if (IDlrzDkyOTKSSY > 706026.3692108071) {
        for (int LgsksmvLL = 470412500; LgsksmvLL > 0; LgsksmvLL--) {
            mJXZkcvCGKyPLrLV *= zvOqQJcAoheZB;
            zchpjcBLSNcunva *= zvOqQJcAoheZB;
        }
    }

    if (qJNaxjmrgCizsj < string("cuxdPtONRmrZlhLkJLODSgTDSmAYjBjEEtfhFtJXGlTCGHCQpsjoJEwLuIdfLeIWopQDIAlKboNVGczXschfCxRswzqhwdZfjGnsByIRVbOjLCPFiZqjnBQHCtcAqMMXIcziQjnakhREGOcoSbaYerbuUVgeIaKreAJhxWdTSCUlNntavBNhUHWmYgVaLDDyaYZ")) {
        for (int NHGfmQh = 546192898; NHGfmQh > 0; NHGfmQh--) {
            zchpjcBLSNcunva = IDlrzDkyOTKSSY;
            zvOqQJcAoheZB -= zchpjcBLSNcunva;
            IDlrzDkyOTKSSY += mJXZkcvCGKyPLrLV;
        }
    }

    return qJNaxjmrgCizsj;
}

string dfHyZFJXKdNotU::gOMDSBANHcEBnC(double RCGiiqsnQ, double JACTXRMTVsLHKVjB, int MWUBoUiTgjJpX)
{
    double LSwdLAneXaPKUu = 455580.3470687351;
    double KlVBkJfq = -605379.6378985356;
    bool ZMYUYUHFvI = false;
    bool zJkUeYv = true;
    double FYRzvfA = -1003239.4138499182;
    bool zPZJNzG = true;
    double VXJUjKrERVC = 526306.931247324;
    bool GBTaycVgsQ = false;
    int KdtxUO = 1680398064;

    for (int VxoKtYmzrVzNawj = 64764580; VxoKtYmzrVzNawj > 0; VxoKtYmzrVzNawj--) {
        KdtxUO -= KdtxUO;
        LSwdLAneXaPKUu += JACTXRMTVsLHKVjB;
        RCGiiqsnQ += RCGiiqsnQ;
    }

    return string("MLThHhFJBrqwijslovvZWbAasrUdcMEZlsriwYgIphkyZhRhCbnnYOqFvDRngsWfWyyoyEeZXnzsGPYcDGbLHPDQFcwKjYvlKThTAvTAEHmAZkSWDhXSphWtzPXZVKTdAESrIspgTPuONUPWMEfmLhRanVfJGhHkgwhRacwBzHQHHrLskixYrPNQfdhYKlqobhphaVvEdResrqTmKNHFlquNWyqWamBQUzWS");
}

string dfHyZFJXKdNotU::EFUYJAOpyIGgmGF()
{
    bool pKbrbTTp = true;
    string AxUqfLx = string("KAhkJFsWAZxFespAEQjXmSkVCqAhLxxUoLHZlXuDowdwQNSOHnrfAtWbPRkmuriQoVTgWgEhYafLUOYSkCOAeHjtFUGvUaqXzFbMktonWMyFKOsDKYGRjBMJQLLNbcYmnnzkLsUicZRZatVHJqvOreKpVoLWwSBZdeIYYyTGCsAipnqIKxsfBxOHdqwpEMBdmmHNVayGOJtUWOgiBbNvAaiREGauuGUaiLHWSlEy");
    string kJiyp = string("oSzkDZwJsJeCZuePPfZxTotgcIcmxjYrqFGiZiHncBKHtpApCtHSTvzXvcBIZCtWKWSLKKbMXnWzcGicDnovgFIVqHHCWMBWYXlzZbAPDzCzgZUvvzPxIDnIvchtmeVMqcqnLDqusUPVvYLllNAzpgDXwxsUdLbpZweGbASiEJOKvFEaXLOyMLIosheLEbxZWsieHOcnzBWkXexzYnvflwGgeVNOMKrWTKsp");
    bool kJqftddq = false;

    for (int nWhUclL = 1952592889; nWhUclL > 0; nWhUclL--) {
        AxUqfLx += AxUqfLx;
        pKbrbTTp = kJqftddq;
        pKbrbTTp = ! kJqftddq;
        kJiyp = kJiyp;
        AxUqfLx += kJiyp;
    }

    if (pKbrbTTp != true) {
        for (int CqgGCyZLOZA = 317849991; CqgGCyZLOZA > 0; CqgGCyZLOZA--) {
            pKbrbTTp = kJqftddq;
        }
    }

    if (AxUqfLx >= string("KAhkJFsWAZxFespAEQjXmSkVCqAhLxxUoLHZlXuDowdwQNSOHnrfAtWbPRkmuriQoVTgWgEhYafLUOYSkCOAeHjtFUGvUaqXzFbMktonWMyFKOsDKYGRjBMJQLLNbcYmnnzkLsUicZRZatVHJqvOreKpVoLWwSBZdeIYYyTGCsAipnqIKxsfBxOHdqwpEMBdmmHNVayGOJtUWOgiBbNvAaiREGauuGUaiLHWSlEy")) {
        for (int gzEVbYXVknc = 1349235977; gzEVbYXVknc > 0; gzEVbYXVknc--) {
            kJqftddq = ! kJqftddq;
            kJiyp = kJiyp;
            AxUqfLx += kJiyp;
        }
    }

    if (kJiyp == string("oSzkDZwJsJeCZuePPfZxTotgcIcmxjYrqFGiZiHncBKHtpApCtHSTvzXvcBIZCtWKWSLKKbMXnWzcGicDnovgFIVqHHCWMBWYXlzZbAPDzCzgZUvvzPxIDnIvchtmeVMqcqnLDqusUPVvYLllNAzpgDXwxsUdLbpZweGbASiEJOKvFEaXLOyMLIosheLEbxZWsieHOcnzBWkXexzYnvflwGgeVNOMKrWTKsp")) {
        for (int psEurWhZp = 1332770689; psEurWhZp > 0; psEurWhZp--) {
            kJqftddq = pKbrbTTp;
            kJqftddq = ! pKbrbTTp;
            AxUqfLx = AxUqfLx;
        }
    }

    return kJiyp;
}

bool dfHyZFJXKdNotU::lcFCgYWy(string VRoKaLYcwRzfX, string ByHnZpnrcYtnw, string iNdmnlzon, int lKzBRd, string wPVReYqEVBNnFZH)
{
    bool AwPkafdvamaBV = false;
    int WULcLscNbx = -1458458359;
    double CvjUaVKx = -947297.1786791348;
    bool mKCEeFCFDzAYDaL = false;

    if (WULcLscNbx < -1458458359) {
        for (int ecUsx = 273034477; ecUsx > 0; ecUsx--) {
            continue;
        }
    }

    if (iNdmnlzon > string("aooQRxskxnqTcbEgktiDTbGzAtlKmUyXhxpaZsWMnntxNEylStUrjfEHVlXoVGUIbVEtTGScQtyNtxtGdpjGkN")) {
        for (int kzYDfUvrxKAYL = 47192299; kzYDfUvrxKAYL > 0; kzYDfUvrxKAYL--) {
            continue;
        }
    }

    return mKCEeFCFDzAYDaL;
}

double dfHyZFJXKdNotU::QijYxxSKgOT(int OSSYZIpbS)
{
    int GnLDTLSglQRT = 1617305243;

    return -149258.47600152934;
}

string dfHyZFJXKdNotU::ZMhWBw(double vFqcZefiNvdhSZ)
{
    int cDFefo = 1021378371;
    double hRuHC = 25789.00712211265;
    bool MStEVqc = false;
    int ChnRASikP = 2137934210;
    string HItllky = string("dsILVAcHwqJSzoOPCFSEZZFzsrHKnOrzbEsHhbvxjWUhtyVPYPARMieeTZDDivuynvyisLbprMEJMPwIeQypQintlSduahMQnFUOOQTaVVGkgMHbwREZhhXeoXaKFrvWFlaxfDPEuXMJpZdWOwnFAPKAfpJlxftMuvUXCoTqLtfAkzafArzZQxzomVYOjmsztocTMwyNovCnjHxjCnIkRtpwWBOgrNJKuuxoqwhkLXsYkzWRsfwJc");
    string urQskpgZkf = string("mrTzotyZROoVfMgXsHmdSLHQawunWeSpHQBZRzFYgMRoSYPFvOQOXIOERykxpSEvNQgZdARfmSGpJoAfkKWdxbVRknjKABZQiovYflvLIMmYIvpAMLvORqCWqCvOpEWalqBjqbdiEQZYCEramBgoLJUIAASnbCuWwovbDDuClLWTQtIvdMBAjDpE");

    if (vFqcZefiNvdhSZ > 830240.057109786) {
        for (int jVjSomXpqXi = 1086862743; jVjSomXpqXi > 0; jVjSomXpqXi--) {
            vFqcZefiNvdhSZ *= vFqcZefiNvdhSZ;
        }
    }

    return urQskpgZkf;
}

int dfHyZFJXKdNotU::XgEjBqerbHK(int xzuhgaYUii, int kZYVKRwKTQtFpOJ)
{
    string FsAAehsTrRha = string("kHrWmFJYYhpxTxxsZmcqbExJayPAPDzgRZhWPqjbfEZeAjmWUSTthAmRBAqBXFwpGxxCXDoLEUQuKJlKVtLQRAUSSIZNHZkLeIwcgJBDoLAEidtuvDPWNgQhtwzOOwOek");
    string VpTcpwLBWVW = string("SYpNCTzKUWpbyziB");
    bool oMNEr = true;
    int tUwwwHQPDSIWVm = 2048323651;
    int DNkvjmqtTJtCkXeO = 1334543254;
    double HathqtQ = 329584.20870402356;
    string fOkhxoimXjVUfCzB = string("PIHLODRUZwetFtHnTedaCjWoSTNsBzzJFucLEvRyFqlmrb");
    double HSrtyka = 712832.3506774002;
    bool VigzTNQDJBZOVN = true;

    if (HathqtQ > 712832.3506774002) {
        for (int aErZUEFtflsR = 1498738733; aErZUEFtflsR > 0; aErZUEFtflsR--) {
            fOkhxoimXjVUfCzB += VpTcpwLBWVW;
        }
    }

    if (FsAAehsTrRha < string("SYpNCTzKUWpbyziB")) {
        for (int SnnDoYDl = 2041863585; SnnDoYDl > 0; SnnDoYDl--) {
            continue;
        }
    }

    if (tUwwwHQPDSIWVm <= 2048323651) {
        for (int CqpYzyXkuIjHaH = 924228656; CqpYzyXkuIjHaH > 0; CqpYzyXkuIjHaH--) {
            tUwwwHQPDSIWVm *= xzuhgaYUii;
            xzuhgaYUii *= xzuhgaYUii;
        }
    }

    return DNkvjmqtTJtCkXeO;
}

dfHyZFJXKdNotU::dfHyZFJXKdNotU()
{
    this->wYZVvDauiYJNB(612175624, -852067198, true, -117087.32816356824, 639634338);
    this->tlusHXftVf(false);
    this->LFfNzNqTrIX(465281978, -645933.9352625369, true);
    this->NKYnjWU(string("EPSRQTvvBAYEYsbEzpgqepIHhvcWPw"), string("HkiPwqQNdayoe"));
    this->YwzzGWN(66540.30187340986, -1583552507, true, 685636.3742889997, 1164696237);
    this->hyPAbvCjg(-1834329067, string("tXaFWAbwWuYZqMSOXndXgmNOpIyNFjKt"));
    this->bfsGPqOwzu(true, 1609294569);
    this->GrUmMNVpPMk(string("gTqYJPczlYtOzjCGGeCkNTSangdUbodWrSlpWdPwWJdOXDJOUKkmkoButoHgcBniLqBcSPzZLPMZQlSzILdZATMLwQCZHtZGcdQXjOzcZUscTPJXOaRcQbIEXjtgTiHolFhtDRzDLZVshvTAijVBEdgXPilduMQonZaPVPBTOQfHwCqnJbaeFdgABLktRZPdFdBpevggZsQZxnN"), false, 753096.1390500522, 948562370, -885503.0906924);
    this->uPKlYMaMx();
    this->YwJesaJIcxTv(string("TqXVPgLmNzTXZCCZliObNNrmSUBpauMwdNXDBoubwwNoFPPPGcXYQtnOdhlHitgjehHOHOkEhYnIEzckePjsnwTEacplFkIlfwqZvkxDazGSjOfxUTPqdJPdkXmdRbEPtd"));
    this->DlqKDiwvtw(false, -1010148168);
    this->KoHaCO(706026.3692108071, string("cuxdPtONRmrZlhLkJLODSgTDSmAYjBjEEtfhFtJXGlTCGHCQpsjoJEwLuIdfLeIWopQDIAlKboNVGczXschfCxRswzqhwdZfjGnsByIRVbOjLCPFiZqjnBQHCtcAqMMXIcziQjnakhREGOcoSbaYerbuUVgeIaKreAJhxWdTSCUlNntavBNhUHWmYgVaLDDyaYZ"), -40793.08562014816);
    this->gOMDSBANHcEBnC(727428.6368959212, 652111.6205770114, 935604159);
    this->EFUYJAOpyIGgmGF();
    this->lcFCgYWy(string("KCKvmieLDWZGHFFMclYQDmEicDVEqpYxUrfVXzUQjKtxadsmDaawZQOyVXheGJJJtqYQBhZYIJdZUgzjlwYsPZpqDGAjNoBdXNYz"), string("vDuKYDCtfJpmMXFmBuBlmqwViVbRHZx"), string("aooQRxskxnqTcbEgktiDTbGzAtlKmUyXhxpaZsWMnntxNEylStUrjfEHVlXoVGUIbVEtTGScQtyNtxtGdpjGkN"), 1308225868, string("eDeXrnvlfXbMJSOVIpcMgsoNWEAPPVsxuUlMNPMgRowgWMXOpcgNgXIOAylPYknaNjlTCXmgJOQOqdrXRDmKsRRNDpiSDElgpmysgFAeRTKRwBgbBYrquy"));
    this->QijYxxSKgOT(-1033288356);
    this->ZMhWBw(830240.057109786);
    this->XgEjBqerbHK(-1441340772, 1394315665);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QahAiP
{
public:
    string HSmwWeTVhdI;
    double PNDJoYk;

    QahAiP();
    void xduaiGOEUeab(int ZZBuEjUEmgVZqOMk);
protected:
    string kVIRrYrG;
    int dFywA;
    string dHqwwDMsOhVUa;
    double lFlKJXvktDDRCSN;
    string oyKJJz;

    string IZzBgdKJT(bool HWbcmICS, double DtMANxpTlzpinMC, double LYzvNLRVrakDC);
    bool AGHVvSjfGSEaV(int cqwYoUvQA, string BHWgtJ, bool KlXdlWewrXTTou);
private:
    bool ZXXhts;
    string ZXhHimh;

    void TQfzKlwAKL(bool ncocSCGcAfGyta);
    int KDHWFfGurPgbd(string LcmYRIuazKPKSG);
};

void QahAiP::xduaiGOEUeab(int ZZBuEjUEmgVZqOMk)
{
    string fyqdrxShldO = string("KIJuVIOUqpBjXxykvJbnQvqfMaNtReFPUkEJKfBsQHEZDlvvpPtcsjwWnTRIgWyZfTBNVPRNNuFMeWyItdRZQfrmTMrXuBLmNWulklzxshehLwetyjpvOtpgzAcMpWDGwtnKLJSEzXJkIgpHyXYmLkMEjWUESwoDDCdXKPnvGNmgfTAPzjZnHKCCfXrhwjtNkB");
    string mQLfCjKIL = string("lTjlPSdzMYzfGOsBVnVDldaOnWLjbKMvMKrmAyXRLsEVNIJVUMlMONIDgjcQaqIsHtxVAbTIFrKCyYgMjTacbVvJJOGBvNuYWJQRTWEBsizRnqaShHayfUVwZKcCVjL");
    double txzIhHcFB = 558229.4426617484;
    string JfiWjWQO = string("AOPu");
    double vzmSMh = -110565.98010489339;
    double alfDQT = -384296.29961820715;
}

string QahAiP::IZzBgdKJT(bool HWbcmICS, double DtMANxpTlzpinMC, double LYzvNLRVrakDC)
{
    string YYoAh = string("laTNqRbcruufydDApABJzyXrUDanwssFjeNteJQjSRVSTWgmcIWlvKsJVKZayhAfsWhQalxnZqFeMsAUKHiNholmseuULABqUmSjOumyWhfBTSLmfzAWw");
    string mXfTWMeKqDqmdzuk = string("XKGgoUAPLsgrcuKmNGppjrIlyMVNkBJrecVqCRZMMLNJOmajnOrfJxaTkzfnNdtbocWnLVXodnHhKTiueDZFaLUcUtFUbNMZxUkpMoQRPKgMCwIDKV");
    double vJAWOwKaT = -436835.42277649004;
    string TtGkONFmmfGwqy = string("XFVrFNBxsMMRWAApnZtBkMnXTHdvEUblmRIxQPTUKYkLlSwjPeQAnEzQEvjPiqdRzSuAxhXTywNRMgnWcRXjoybbyqWyfTRvATaCIZtGaXWihdWTsxhrLVcFLHpO");
    int tWURsLfyoOgAny = 585483942;
    bool ZnpGqXAvnUmE = false;
    int BgVmrLZzb = -877543686;
    int eKKAcueVo = -146140595;
    int mjrXCqNxCLQFN = -1021318492;
    int vEvqKqkhZCxVXqbB = 523747585;

    if (BgVmrLZzb < -146140595) {
        for (int UZXZhZZFUGg = 191767480; UZXZhZZFUGg > 0; UZXZhZZFUGg--) {
            TtGkONFmmfGwqy += YYoAh;
            tWURsLfyoOgAny *= BgVmrLZzb;
        }
    }

    if (HWbcmICS != true) {
        for (int HrjMrTSsOUKV = 821134785; HrjMrTSsOUKV > 0; HrjMrTSsOUKV--) {
            HWbcmICS = ZnpGqXAvnUmE;
        }
    }

    if (YYoAh != string("XFVrFNBxsMMRWAApnZtBkMnXTHdvEUblmRIxQPTUKYkLlSwjPeQAnEzQEvjPiqdRzSuAxhXTywNRMgnWcRXjoybbyqWyfTRvATaCIZtGaXWihdWTsxhrLVcFLHpO")) {
        for (int gaMTbtXK = 473646776; gaMTbtXK > 0; gaMTbtXK--) {
            eKKAcueVo += BgVmrLZzb;
        }
    }

    if (BgVmrLZzb < -146140595) {
        for (int JqIonUja = 1236317868; JqIonUja > 0; JqIonUja--) {
            continue;
        }
    }

    if (mXfTWMeKqDqmdzuk < string("laTNqRbcruufydDApABJzyXrUDanwssFjeNteJQjSRVSTWgmcIWlvKsJVKZayhAfsWhQalxnZqFeMsAUKHiNholmseuULABqUmSjOumyWhfBTSLmfzAWw")) {
        for (int IfPUYpYmR = 539066236; IfPUYpYmR > 0; IfPUYpYmR--) {
            TtGkONFmmfGwqy += TtGkONFmmfGwqy;
        }
    }

    for (int oqLqAXgLQrJeyal = 1801933151; oqLqAXgLQrJeyal > 0; oqLqAXgLQrJeyal--) {
        BgVmrLZzb = BgVmrLZzb;
        mXfTWMeKqDqmdzuk = mXfTWMeKqDqmdzuk;
    }

    return TtGkONFmmfGwqy;
}

bool QahAiP::AGHVvSjfGSEaV(int cqwYoUvQA, string BHWgtJ, bool KlXdlWewrXTTou)
{
    string aEcYfGe = string("LhihdPgZTKcgVtnyKFsCSmHqesprBkOcKrZrUscNc");
    int HLDfMIEvDXUrlwH = -1473588030;
    bool WoUjoKzQTA = true;
    bool HvfPJLMcGEMj = true;
    string RwbrB = string("AqUwRWfpEvUcimslvDEubstyVMUfnLfJxEbyfcGKgELnGhiKhMrRPEtaosNsqwKVNteHjDtEoldZwCQyAqcppPCMFvJVzkDZcPJTgXKQgXYjhxntVOUvAoCBJJqAevXCDOvugvdheuxQeNIymVuHvbFweHpbZYzsrKdtHMlgqNBRVKDglQQnZjbdweOyBkZrkVHimYmzYvytvSsKDJsfeEkKWEcXRJZLkmTv");
    bool KMiAownh = false;
    string lgfwKRu = string("RyaDKisBPasMiEGExXyOcruROItyYECBxFWLELWOyYbSeMTFfjpRfmVmyQjxdPapVfNdtFwBtxcCarlXFmChhGiGmFzaoAWUixvACgPusaGyWR");

    if (WoUjoKzQTA != false) {
        for (int juQZbG = 927877260; juQZbG > 0; juQZbG--) {
            aEcYfGe = RwbrB;
            BHWgtJ += BHWgtJ;
        }
    }

    for (int kPSFGzx = 145143269; kPSFGzx > 0; kPSFGzx--) {
        continue;
    }

    for (int GkzBIVMPbHKBLObu = 88541950; GkzBIVMPbHKBLObu > 0; GkzBIVMPbHKBLObu--) {
        lgfwKRu = lgfwKRu;
        aEcYfGe += RwbrB;
        WoUjoKzQTA = KlXdlWewrXTTou;
        BHWgtJ = lgfwKRu;
        RwbrB += aEcYfGe;
    }

    for (int dMDKiEuivyNpCE = 762896432; dMDKiEuivyNpCE > 0; dMDKiEuivyNpCE--) {
        KlXdlWewrXTTou = ! WoUjoKzQTA;
    }

    return KMiAownh;
}

void QahAiP::TQfzKlwAKL(bool ncocSCGcAfGyta)
{
    string nYfjgnjscBH = string("HLbUnUtwwFqzTyTCpbqXUUIikbachzuFzmUCnzyHFOvvKkFFavHgcQsEsJwdQkxpnfsQHrOWTzUVfx");
    double mtbwRfdkspYyHO = 976748.2374694833;

    for (int kTuEIkTXIw = 924437549; kTuEIkTXIw > 0; kTuEIkTXIw--) {
        mtbwRfdkspYyHO *= mtbwRfdkspYyHO;
    }

    for (int YVoMiKQXeOHtNbcY = 1927137129; YVoMiKQXeOHtNbcY > 0; YVoMiKQXeOHtNbcY--) {
        nYfjgnjscBH = nYfjgnjscBH;
    }

    if (mtbwRfdkspYyHO >= 976748.2374694833) {
        for (int lOgvcyGTUWrrmj = 630390176; lOgvcyGTUWrrmj > 0; lOgvcyGTUWrrmj--) {
            nYfjgnjscBH = nYfjgnjscBH;
            mtbwRfdkspYyHO /= mtbwRfdkspYyHO;
            ncocSCGcAfGyta = ncocSCGcAfGyta;
        }
    }

    for (int JJMcj = 495268159; JJMcj > 0; JJMcj--) {
        mtbwRfdkspYyHO -= mtbwRfdkspYyHO;
    }
}

int QahAiP::KDHWFfGurPgbd(string LcmYRIuazKPKSG)
{
    bool SHKyKJG = true;
    bool xZGafN = true;
    bool mLqwKLCoaR = true;
    string EkQZXuXs = string("iSlBsBhpFCxohAeZvvpujJLfEXkrCeCnTTNXMKDSNTfldkqLPacifSLruPJlXVKbjJOxYluVuiOMXIErHmbSZMwAclksdhKgmRiOFmLZBNqLQcMMNJzlYIsIlGGRsfAFxiwLrPYicwQvfQsatEFNGFKyFFmsBcfHgkgSsWpdqtnJcXuBQBKUjLaYEjiZqPFMORuwzYFkJHMHDxTNnmYhZdkbPVgRKXc");
    bool UovNmamXDdhtV = true;
    double tQQmmaXRna = -951814.7953650577;
    string PtWIxuNVcIUV = string("ZPgSlPemtNtGMJZggHL");
    double WLeLiiZFBl = -505387.13974716776;
    bool bXXhFSKqrmgvs = false;

    if (SHKyKJG == true) {
        for (int oDtDGKWKntzYvF = 1257690134; oDtDGKWKntzYvF > 0; oDtDGKWKntzYvF--) {
            continue;
        }
    }

    for (int rGOsxhPpb = 763689098; rGOsxhPpb > 0; rGOsxhPpb--) {
        continue;
    }

    for (int VpyHFBHZzaGf = 1756218065; VpyHFBHZzaGf > 0; VpyHFBHZzaGf--) {
        SHKyKJG = ! UovNmamXDdhtV;
    }

    return -230715122;
}

QahAiP::QahAiP()
{
    this->xduaiGOEUeab(-654643827);
    this->IZzBgdKJT(true, -181553.68844909107, -63806.15908219704);
    this->AGHVvSjfGSEaV(-929912715, string("wxKLyTZlTRMtbtOMNgusZAihROmRWSpXiBsGROZOUcAdPMBQbKPVrfGtNcWiAhNRTGeTYUiUeXBSrLZykjSnZsknfJSTIaCZULiFGmpQpDBRlDUTvYFQmuewNqGqBXJEj"), false);
    this->TQfzKlwAKL(false);
    this->KDHWFfGurPgbd(string("ascLArnYdYaYbYWXIHPLNXQSBUMgObHJTZMXZesiXpwgLAdXWrTMcweTVOjFMtVGGRaCeaeYjvJtmjPVZFrXnXzspGHlmTTnVLcivEbsZpzszhYqBOQIxyuRSVitoeGgORMEjxaNHbvppUBTMcUnMddXLDBWKHOGcyLliZwjcDViNgAFmsNJuzZXshBnzfNmvgA"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iXWKbsygYXXKJJ
{
public:
    int YNBeRaPsR;

    iXWKbsygYXXKJJ();
    string GxPMeDg(bool owJkGEnZyeQc);
    int lHdfDKTmSyhnb(string ixDrFB, string wVhqye, string uqhEMcS, int MJpNx, double EAvKiaPhwmXBg);
    double MyNWilGJmc(string RtnlROYBNhB, bool kvZOIBdzMtnE);
protected:
    bool yefpgmja;
    bool uGKjTnL;
    double WELaFeZg;

    int LSOFnNZfKZbFtd(bool ELCgWGiryrE, string POGUoSJlZj, bool tdefYrIso);
    string PSPRJVHYZFqNeDzf(bool POzaApAEDHu, int txtZlYkxRzeFv, bool kZQNniQlSsr, string qKhXqhUanMp);
    void cHEvIsPmpaUBjG(bool vqnvcPGKtffgh, int XvTjUClFjj, int MpMPvmFTY);
private:
    bool aBtpnYYQK;
    bool OJNdBaCUdfXCdxs;
    int pgxkMVEjPoLYGpkw;
    int tKcBrMQqjYDCfm;
    double SrFSBfUnLYIYt;
    int ZJIuTTGwG;

    int srTyYIR(int JFUsZzenxgrh, int xGZmCPule);
    double AMLMmdLGcA(string rnNQEAcsRYc, int sxwQpHo, int KBlvXOqutcSzU, double dQGsQlLtUKBG, string tteOpZllvwnRrH);
    int mbOpIpVABemtTBe(double BYNgj, double lAIFTUSuswfrrh);
};

string iXWKbsygYXXKJJ::GxPMeDg(bool owJkGEnZyeQc)
{
    double pMPGzuV = -327437.1718537278;

    for (int gKCpbfp = 1924840563; gKCpbfp > 0; gKCpbfp--) {
        pMPGzuV += pMPGzuV;
        owJkGEnZyeQc = owJkGEnZyeQc;
    }

    for (int GvJQCGwdCkjDmy = 26290579; GvJQCGwdCkjDmy > 0; GvJQCGwdCkjDmy--) {
        pMPGzuV -= pMPGzuV;
        pMPGzuV = pMPGzuV;
        owJkGEnZyeQc = ! owJkGEnZyeQc;
    }

    for (int fkRfgcJpe = 307336996; fkRfgcJpe > 0; fkRfgcJpe--) {
        pMPGzuV = pMPGzuV;
        pMPGzuV = pMPGzuV;
        pMPGzuV *= pMPGzuV;
    }

    return string("mBazGKpeZlDBqXKTOechMeOyarAghWfbKklcaJXqSZyUBZElTkBZXlhyPLNMXbykjWLZiqRqqqWAEbnmMUSjxlluMLsPiXOhzrFvrMDQcTYQlpXgzYwVsAxUPoNCdQdWXJmWvhAmIkuYnTTnrULjDWUdOWdhyDVnajkFyKjBkzIcSzMTzKbelysxpWkjxldoQiroevoCssVo");
}

int iXWKbsygYXXKJJ::lHdfDKTmSyhnb(string ixDrFB, string wVhqye, string uqhEMcS, int MJpNx, double EAvKiaPhwmXBg)
{
    bool KlxOenT = false;
    int UTqucaxUG = -87193330;
    string StccyCnKovGk = string("faWfolkxeEJNotKnRBJKSJoUYankfozjCsXYfUzxBWPXHMnIzmFVNfjZFOXanIadCQx");
    string cakHAJJzszbMa = string("MAagRQTSzNYUbvBLOeloSFIDGejHPHjeauvUGXZQBGFnNgOftjYtXGEEcZlpsaduKGeMfDvOJfiMaeUDKkcLdvIwlRsIoNFQiWnaRvTKJRsxjnSSKNjnhZjPPcvxCSUHPtEYEGlWShvUolBUcueeCgmljQlEujCrEDSCsDqvLseq");
    int zegfe = -1476488323;
    bool hnWzfpCLJhdbujyV = true;
    double hzYzwxmQSqX = -816941.7590570027;
    int tuxjnpWcc = -1414938471;
    string YUCqXpBdMNzJIo = string("waxsuaLlIMPWzWRirYsrZVSnVtbRbJuTQnTjRLezwEOOOlOJrFChqGXelQtaTefWJYKTJSOIszRbDTjwomHhJDLOIqRAeNBjZaxbBhnPCxJaVPNkpRItxlrIEvl");
    double xjHUGNNfc = 950015.9354446506;

    for (int CpHFtCopsNH = 666529974; CpHFtCopsNH > 0; CpHFtCopsNH--) {
        cakHAJJzszbMa += StccyCnKovGk;
        hnWzfpCLJhdbujyV = ! hnWzfpCLJhdbujyV;
        zegfe += zegfe;
    }

    return tuxjnpWcc;
}

double iXWKbsygYXXKJJ::MyNWilGJmc(string RtnlROYBNhB, bool kvZOIBdzMtnE)
{
    int oSWyUOUvHlAfESz = 1085771245;
    int qTAmapcRyQUOwQtO = -1259060414;
    int BsghxqJfQZM = -722545520;
    string ZtvdhE = string("IUURYVYMPwdIBMuVzrrJnSxjxkgDGiUAphuonfFUVONRgatquvpBxrgTOGZiyGLONydbxCXZYOsUATYvwaUHoFBZUlDYsyfsLDGtrVSwaDUkSmWGmstnCDNLDNNXxXWGAnQQobPWAnfZGSJuTYfRTAqQjVRHAPUzgAivbubIfYjdpAVAqqyqFoUmnhVIOGSDjXazEIphTPfoWfrcwp");

    if (oSWyUOUvHlAfESz == -1259060414) {
        for (int lVjOjmMos = 224353313; lVjOjmMos > 0; lVjOjmMos--) {
            oSWyUOUvHlAfESz /= qTAmapcRyQUOwQtO;
            qTAmapcRyQUOwQtO -= BsghxqJfQZM;
            RtnlROYBNhB += RtnlROYBNhB;
            qTAmapcRyQUOwQtO += oSWyUOUvHlAfESz;
        }
    }

    return -963151.1558098132;
}

int iXWKbsygYXXKJJ::LSOFnNZfKZbFtd(bool ELCgWGiryrE, string POGUoSJlZj, bool tdefYrIso)
{
    string RPbyN = string("byvf");
    bool vzChczj = false;
    string aBREWvjwxKxvqCC = string("FStLeMaCNoy");

    for (int nzVau = 197423328; nzVau > 0; nzVau--) {
        ELCgWGiryrE = tdefYrIso;
        tdefYrIso = ! ELCgWGiryrE;
        ELCgWGiryrE = ! vzChczj;
    }

    return -676499678;
}

string iXWKbsygYXXKJJ::PSPRJVHYZFqNeDzf(bool POzaApAEDHu, int txtZlYkxRzeFv, bool kZQNniQlSsr, string qKhXqhUanMp)
{
    bool CEIDjJnyK = true;
    string CqNbh = string("kgqTOBUbRnirbvdEwqnIwerjXhZlsErctwOgtvIcPpUXyeDWPeLhNNkKMNxYEMmDqgHBjXwNQmuvolLyPdbCwXZPVytcRsmvEvBmNRCkTQNNLWPYWdQyJigEDWGHHIBIkSzpcPvqljzhtaVrYDQvRLHScrShEJrlbkABglTUxgGdvzXnzwXKuSZAvqyYeZqilaBqYrmdeQAztSdqOhjyVBJEaFNLEZuOWyiZflvpWnbEanXVOQRn");
    bool AycuWmTZbozGx = true;
    double IfCeQtCRrV = 324622.3089291056;
    bool tgXLLVazkVUYIeH = true;

    for (int pVcxCQW = 1843752579; pVcxCQW > 0; pVcxCQW--) {
        POzaApAEDHu = ! AycuWmTZbozGx;
        POzaApAEDHu = kZQNniQlSsr;
    }

    if (POzaApAEDHu != true) {
        for (int moDMebWLoZK = 1193277761; moDMebWLoZK > 0; moDMebWLoZK--) {
            continue;
        }
    }

    for (int LvIOsV = 1620199960; LvIOsV > 0; LvIOsV--) {
        kZQNniQlSsr = tgXLLVazkVUYIeH;
        CEIDjJnyK = POzaApAEDHu;
        CEIDjJnyK = CEIDjJnyK;
        IfCeQtCRrV *= IfCeQtCRrV;
        tgXLLVazkVUYIeH = CEIDjJnyK;
    }

    for (int rHwkBMPBh = 1792412058; rHwkBMPBh > 0; rHwkBMPBh--) {
        POzaApAEDHu = CEIDjJnyK;
        tgXLLVazkVUYIeH = ! CEIDjJnyK;
    }

    return CqNbh;
}

void iXWKbsygYXXKJJ::cHEvIsPmpaUBjG(bool vqnvcPGKtffgh, int XvTjUClFjj, int MpMPvmFTY)
{
    double HprtFSPCd = 307829.04538012564;

    if (MpMPvmFTY <= -1421326880) {
        for (int TqnVnSPZvAmcy = 167623355; TqnVnSPZvAmcy > 0; TqnVnSPZvAmcy--) {
            continue;
        }
    }
}

int iXWKbsygYXXKJJ::srTyYIR(int JFUsZzenxgrh, int xGZmCPule)
{
    bool dCYPpkBFbx = false;
    string RkspSstCHOYLd = string("rXeMVOKhnXWbfQxcHCoRvyQCFUPIULQCIQWtvCozOATdoTMMfslRVFIxvGFGNFwBYdBsljeJUVVtemcSdMInkFiharqsIourkhddwRhIPQEUxyMMgdcqDIufwgCAMKDMPJfYwsLlOdEPuggopMCFHIdMYwl");
    string qTInkNpvT = string("SwnTDKzvQclNXXjODzLkqLGvbJSCyhmmlrIcLIizYdhvCSDuICJzcCswfgjObhkpkylYzwTGsrhhQlhK");
    int RSJfGQqR = 2076634019;

    for (int SiMCaDnXlhqi = 2015024385; SiMCaDnXlhqi > 0; SiMCaDnXlhqi--) {
        JFUsZzenxgrh = xGZmCPule;
        JFUsZzenxgrh = xGZmCPule;
    }

    for (int CadXz = 931207495; CadXz > 0; CadXz--) {
        RSJfGQqR *= JFUsZzenxgrh;
        JFUsZzenxgrh *= RSJfGQqR;
    }

    if (JFUsZzenxgrh < -1135969356) {
        for (int TcoaWAeAc = 128906297; TcoaWAeAc > 0; TcoaWAeAc--) {
            RkspSstCHOYLd += qTInkNpvT;
            JFUsZzenxgrh -= RSJfGQqR;
        }
    }

    for (int iMuQaRfcMrU = 737605019; iMuQaRfcMrU > 0; iMuQaRfcMrU--) {
        RSJfGQqR /= RSJfGQqR;
        JFUsZzenxgrh -= xGZmCPule;
        RSJfGQqR *= JFUsZzenxgrh;
    }

    for (int GDQAJuAl = 512468243; GDQAJuAl > 0; GDQAJuAl--) {
        xGZmCPule /= xGZmCPule;
        xGZmCPule /= RSJfGQqR;
        RkspSstCHOYLd += RkspSstCHOYLd;
        dCYPpkBFbx = dCYPpkBFbx;
    }

    return RSJfGQqR;
}

double iXWKbsygYXXKJJ::AMLMmdLGcA(string rnNQEAcsRYc, int sxwQpHo, int KBlvXOqutcSzU, double dQGsQlLtUKBG, string tteOpZllvwnRrH)
{
    bool tzDEFpccUg = false;
    string sbhVfyaGrgxDjGp = string("nhswTbrsEEIkuztGsWyOXwFJHcJmHaGUZZMFbOjhcBrWmiZujXrOTIGyDAArhCQtORkJQWDSERUeAMqrZQQwY");
    string lfTvneIbnLICAdgu = string("MSQLxQwpqwmfmAWJBMkqvpIzKSHGKbmKsKQlfkTOvcAGNuoObNfNJKkFSVbvXelrissaMJXPbmnsaHAOKfBlWHoPxqJeNHaxgxzspsmxnDwOukdgZvcBruFQvJQpALEWqITdfLdOiXMyItZhaEBfwMXImUBpKWDtVXaKgANNqLnpQPhPJddRDuoZdFRbIzzS");
    double VOjxkoYzr = 937538.9532162523;
    double ACmlFgTOyxoWTx = -399992.6327363047;
    int pdQwwOBUMak = 21828917;

    for (int WoxHpbPgS = 1901172090; WoxHpbPgS > 0; WoxHpbPgS--) {
        dQGsQlLtUKBG += dQGsQlLtUKBG;
    }

    for (int MeUDJJGtUyNCaCir = 1371151987; MeUDJJGtUyNCaCir > 0; MeUDJJGtUyNCaCir--) {
        ACmlFgTOyxoWTx -= VOjxkoYzr;
        VOjxkoYzr *= ACmlFgTOyxoWTx;
    }

    for (int ddoTZhVlmPI = 2096223976; ddoTZhVlmPI > 0; ddoTZhVlmPI--) {
        KBlvXOqutcSzU -= sxwQpHo;
    }

    for (int qCuOIYqLrvcviMK = 1147938101; qCuOIYqLrvcviMK > 0; qCuOIYqLrvcviMK--) {
        sbhVfyaGrgxDjGp = sbhVfyaGrgxDjGp;
        tzDEFpccUg = ! tzDEFpccUg;
    }

    return ACmlFgTOyxoWTx;
}

int iXWKbsygYXXKJJ::mbOpIpVABemtTBe(double BYNgj, double lAIFTUSuswfrrh)
{
    string LZHzPCexrFlyAPc = string("HXdsBuMZdeVcWMhQmxdbQhKHeUIYhbVYtdjeXRdkZeZDllexaoiPFkgRVcINaOasrLMOuZLurM");

    for (int sCEGnoYleYr = 61709997; sCEGnoYleYr > 0; sCEGnoYleYr--) {
        LZHzPCexrFlyAPc += LZHzPCexrFlyAPc;
        BYNgj = lAIFTUSuswfrrh;
        BYNgj = BYNgj;
        BYNgj /= lAIFTUSuswfrrh;
    }

    for (int bjqgPeSkJAAM = 836831014; bjqgPeSkJAAM > 0; bjqgPeSkJAAM--) {
        BYNgj *= lAIFTUSuswfrrh;
        lAIFTUSuswfrrh -= lAIFTUSuswfrrh;
        LZHzPCexrFlyAPc = LZHzPCexrFlyAPc;
    }

    return 1763355191;
}

iXWKbsygYXXKJJ::iXWKbsygYXXKJJ()
{
    this->GxPMeDg(true);
    this->lHdfDKTmSyhnb(string("KBBWonfFgNKpbRUjhaZfZysCqbRJQfJeJwvlVMTsskSDXrDuxdjsXcOkmKKTLfjqMOxrEhAOyTePXqHmLXJtrbWePTPGaObaOVUZNYwBbAqmWrALrgfTzlgasG"), string("hKPXneqQYUyFzDoCAAYvMfwwgXXycLguRszXsvNNhrJRgOHxDnpOUydESIoljXHHGwJfQBVSRJdMKpKXRlvPnEpmd"), string("wkPXOdIstrkPGDfxNPmAPEvxEaeFFl"), -1520866946, 209467.28836909556);
    this->MyNWilGJmc(string("hoymLTmWZWvcPuAqcDLRU"), true);
    this->LSOFnNZfKZbFtd(false, string("ZXZPhicztORClNkOwWpWriUAoPOmnpeXPkEEkhALYFrePRpzIxYGTaAa"), true);
    this->PSPRJVHYZFqNeDzf(false, -1204797335, false, string("eWWMvZVCjmsajeDWnZeioocmhgSQKWVNLrlqDIrDascSpPhXqTjFEBAUYtDtToHXUIuOJtGZRTpSFGHXePHdsxciCqMXQgFQphXCvvkuZyqNsLMtTAhyBjomRgdSXHfxDExzYxBXTsiToSeYxtIKrPsRqxmDyWPxWtRXVCiOBloqerlZIzZRUusA"));
    this->cHEvIsPmpaUBjG(false, 1575120528, -1421326880);
    this->srTyYIR(810675768, -1135969356);
    this->AMLMmdLGcA(string("jiHNdLLiTUjoHmdphYemCBaQzMPhpLEBJHSTomuDzFnGJXnJxoiZVUTXMCSzELoyUuBEGQiBSJyrdKeWmiFmiyTyOFVoiqWOPxxjuNQVAbQtTMFgBFRzBkrlifmWFdMSDmmBEijNEuhmQxnULCZpardgZhoOyYhcHZDSWIQAfCPbgoWBLqPhpySLtQbMJworvKrCtYVVXLdDJaXHyLDPJcNfZYiuaHlTdzlgGElRmbpYhsAmaQeZRqDDVQedi"), -681492904, -1448663362, -637387.3456965289, string("EILIE"));
    this->mbOpIpVABemtTBe(210947.90845791964, 866167.0849276871);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XIBuYsZAR
{
public:
    string mhHOHvZHDA;
    bool KYsAZSyIif;
    bool aOPMCpGjwRlJg;

    XIBuYsZAR();
    bool kdoIkqsN(int lOkalzXlrDpFiUn, int ZOkPbC);
    int TDdyESralF(double VnHgutRLCnctDU, double oQTXNaU, string ZxEGcwefh, double yitowSUWHyehF, int YFYRpzoJ);
    string leeMhBefj(string VZQNcrWOV, bool yKNzcS, int Yzpfwndl, int KFXzcSBXjgdMReaa, int LWrsnJuitLOxBcU);
    void IVKvdZbQuRc(double qiwlfVoWRj, int cJYOuJOfpTlDc, string zwirFkOxefY, string TWehncGcmgVQQ, string dWRzr);
protected:
    int LNftD;
    double KAXSZ;

    int WDwtyp(bool SoAwpDbJei, int yCHBHiQ, int mFaZpXJRjm, double HUBMoJw);
    bool sxuYTdnYXcdKIbz(string mmhXhOUcUewiICy, int bxQMddGtgh, string tcAFSVLNRdAw, bool wglpZAsPYhJL, bool CApMb);
    double CIKywNAggZBo(string oyZcRNKh, string kyNUwdl);
private:
    double MzZQjbblNbmj;
    int JpriZMko;

};

bool XIBuYsZAR::kdoIkqsN(int lOkalzXlrDpFiUn, int ZOkPbC)
{
    string QHSrpCx = string("BdACWbSVaQohTZJIdBupEATWlMBPAJXMpqehphAPxaBGZBqmVzmTeKHYbOGiCiDuHtbVTEqUOfBSmjAMxbWSYxMYyPeUUCLoSCzgjTlJjVVVgdbdibQoKNyCuiUEsMbdAgRzjDhtjncIcHseadrSiIZbmxhsPNYDgvDcCoqsWrTzMBsiqLOvyKG");

    if (lOkalzXlrDpFiUn == -768579640) {
        for (int SfenZjT = 1230280388; SfenZjT > 0; SfenZjT--) {
            ZOkPbC -= lOkalzXlrDpFiUn;
            lOkalzXlrDpFiUn -= ZOkPbC;
            lOkalzXlrDpFiUn = ZOkPbC;
            QHSrpCx = QHSrpCx;
        }
    }

    return true;
}

int XIBuYsZAR::TDdyESralF(double VnHgutRLCnctDU, double oQTXNaU, string ZxEGcwefh, double yitowSUWHyehF, int YFYRpzoJ)
{
    string RPDMrvfOeHzAip = string("oObfcSDyjLkcWOfwQaRAlauVAxYjIHFVNQqemmgQXpsdgXCHoKlxBfIukXdvRrHgGogPkxYkavEOCAZNFqr");

    for (int bYbNzSbuJyFKxfF = 674224609; bYbNzSbuJyFKxfF > 0; bYbNzSbuJyFKxfF--) {
        YFYRpzoJ *= YFYRpzoJ;
        RPDMrvfOeHzAip += RPDMrvfOeHzAip;
        VnHgutRLCnctDU += VnHgutRLCnctDU;
    }

    if (yitowSUWHyehF == 269328.8641549898) {
        for (int jUzUpROIULDE = 1969675123; jUzUpROIULDE > 0; jUzUpROIULDE--) {
            ZxEGcwefh = ZxEGcwefh;
            yitowSUWHyehF *= VnHgutRLCnctDU;
            oQTXNaU *= oQTXNaU;
        }
    }

    for (int zEJlyvsQQUbysOv = 521046839; zEJlyvsQQUbysOv > 0; zEJlyvsQQUbysOv--) {
        yitowSUWHyehF = VnHgutRLCnctDU;
        oQTXNaU *= oQTXNaU;
        ZxEGcwefh = RPDMrvfOeHzAip;
    }

    for (int HsElIHKc = 1430541477; HsElIHKc > 0; HsElIHKc--) {
        yitowSUWHyehF += yitowSUWHyehF;
    }

    for (int qbYvsRQpyZAKGcFK = 555189196; qbYvsRQpyZAKGcFK > 0; qbYvsRQpyZAKGcFK--) {
        YFYRpzoJ = YFYRpzoJ;
    }

    return YFYRpzoJ;
}

string XIBuYsZAR::leeMhBefj(string VZQNcrWOV, bool yKNzcS, int Yzpfwndl, int KFXzcSBXjgdMReaa, int LWrsnJuitLOxBcU)
{
    int MeLGeTerJem = 1002562154;
    string marlvgQTAJ = string("rJmTvlQMvqGXxENCwMRIVAHnxZtCryzuwBzsJtremzTgwPjCfJMNfYLBxncnyfWOPVQDvUksHjCfdntMVSWFmDvSJpTEmqGdThtKWmRfcDtMYOEzvuYkjORnNBfYvbFWWbszuJgpKINqWJWAdfXkkLYGzdNBFuIkZDDZyTEVASzyJemmtoaozdnRACpKKATbNHamKHyGGadJimlXE");

    for (int tJlRfytKoSIIrlW = 1080543404; tJlRfytKoSIIrlW > 0; tJlRfytKoSIIrlW--) {
        KFXzcSBXjgdMReaa += KFXzcSBXjgdMReaa;
    }

    for (int INyDGzeCOrSDaYp = 1855643260; INyDGzeCOrSDaYp > 0; INyDGzeCOrSDaYp--) {
        KFXzcSBXjgdMReaa += Yzpfwndl;
    }

    if (MeLGeTerJem > 235098445) {
        for (int wnWPhExkPFjkdmRS = 809734396; wnWPhExkPFjkdmRS > 0; wnWPhExkPFjkdmRS--) {
            Yzpfwndl *= MeLGeTerJem;
        }
    }

    return marlvgQTAJ;
}

void XIBuYsZAR::IVKvdZbQuRc(double qiwlfVoWRj, int cJYOuJOfpTlDc, string zwirFkOxefY, string TWehncGcmgVQQ, string dWRzr)
{
    string bBtSBnOQnqOjirZ = string("hNGdzyEkTuSIFtrNRxkFdLcSeNmLckumghMkPtCTvCSxbKIczxeorBQVcmNQaSKnxEKOAAVwvNybtPxTncThKGgWbkOULeDAmyTGjhhfEcdfYOnmBYqYwTmUtFwCTVxOGBRoubVbXHmWGiJIzCNeXjonYSMfcDbXbrnNYnpPTWwOFojGHBsazKxPCsJgCGSBXPMI");
    string CFYgZl = string("TrDiFNQqDUFkRsFgCOdsEiIybczDEmPuyPDENJpwtsSvsPjYqYWaqHncrOuPwEdREHvOCaVjGliOkwMmNTcTEnHAlozcNYwHSvKZBvEHxGCGEpWvCLWseeSToPLCUJSQVBZHvIeUTiGfHjgEpEsmLJum");
    bool OcqOQa = true;
    double iXUxP = 364312.04334906733;
    string UwjfU = string("TuoqafKBNSZezVhoXjXNaQxlJYMSrkSJPeKkstEiZDkeXuVdgokzOCoVyoCfNdVVrujqhTvvsvdvplIVIUjTfreuE");
    int unzFHTW = 420288157;
    double kpNaEFQWqkzFOTH = -1001196.0690065562;
    string zMJteUpQczrxbfVK = string("RxydZYfAidbSjrvdqOHzwNyTkGfCNplBNLvYxWnRcIweUgRJfbzDWCeeomXrWwuwMYUNUGRCCmwoRlInNUFcleukaHWqGwhiffRYFDHVFIGvhavdkUbSXmgYksilrjhmstYEydMwEqzVEpPZADk");
    int CthaXveM = -939213405;

    for (int whXjEIUzTOsDAoO = 846960452; whXjEIUzTOsDAoO > 0; whXjEIUzTOsDAoO--) {
        dWRzr = zMJteUpQczrxbfVK;
        TWehncGcmgVQQ = UwjfU;
        bBtSBnOQnqOjirZ += UwjfU;
    }
}

int XIBuYsZAR::WDwtyp(bool SoAwpDbJei, int yCHBHiQ, int mFaZpXJRjm, double HUBMoJw)
{
    int RtHYfTLudIXtRpus = -1291508730;
    string JpOtoxnmniiKyjoa = string("RzeyHSDWXuSoTXweFHRRbszHSOCJWPNRWRxZEWRwHtodQVIpkXVMFuWOFJpymfWXHYtXiDXCGxysuKOFFKWBpFetgxVSvmgmiwPkYbebsPjXiBuFIruXQEYvZOUIFqwlfjtcfQxpnbIrofcGCvSfyDScKbSLVhFnjAmIbQFoOcIFylDtLlrdDjhAifdXIXPhoIHswDcExkuMoOOZlOTHgyzSkeXCorTlCFm");
    bool JjDIDwrrqeZmTL = true;
    string bgWTrXkDYAIlYtL = string("VDyNBbOYNXfQMYbvfPKKGfZzlFcvPkrxfOFyjaApUWCWeWSRHyiShAgUcNnTCWrHsiWRsGGpBdRlUdagmIZQZLatOtZOdaHLGGqGFpFmNyoiFhYnInkRklXXyxeHFuugUeMPJsgCXHxpuhamOKeRlLIlQ");
    bool OPeGU = true;
    double MegCLcobAXbFJXVv = -782638.7430387503;

    for (int wfwBOCfJZZptK = 445694198; wfwBOCfJZZptK > 0; wfwBOCfJZZptK--) {
        mFaZpXJRjm += RtHYfTLudIXtRpus;
        JpOtoxnmniiKyjoa += JpOtoxnmniiKyjoa;
        RtHYfTLudIXtRpus /= mFaZpXJRjm;
        mFaZpXJRjm = mFaZpXJRjm;
    }

    for (int TKHdqMtchXaWRNG = 1138807159; TKHdqMtchXaWRNG > 0; TKHdqMtchXaWRNG--) {
        RtHYfTLudIXtRpus *= RtHYfTLudIXtRpus;
        bgWTrXkDYAIlYtL = bgWTrXkDYAIlYtL;
    }

    return RtHYfTLudIXtRpus;
}

bool XIBuYsZAR::sxuYTdnYXcdKIbz(string mmhXhOUcUewiICy, int bxQMddGtgh, string tcAFSVLNRdAw, bool wglpZAsPYhJL, bool CApMb)
{
    bool nChwYfjo = false;
    double yQuNPMdivLmoyef = 130711.72572179428;
    bool yYfcvWH = true;
    string LHtUAoBOUc = string("ztkZqgMBHsPeCWwwTpsjkUxpkVNxjZgQWoBmZACBlKHvknwsFUWiBduyLAgHKNHqziTloreHCIZasDQUrBptZZblMCEqSUxpcFRpigTbpXuwlRRSXvtFpuzovqPFFfdXQpaKRGWsULvfaSiQInLClmepRBoYufqYjfkIhPfzOHGyLxYrI");

    if (mmhXhOUcUewiICy > string("cedMNsViWNhOpJUofYDFDJCDKcsnfKtBsPFCOrfvYlsJTNTulLsOzEUHPrLjzlZDBdQFcVJdhPFMkyuHUwPorDfgLbrZYlsVZrNEzRfwjPultAelJXubzHcLRitPsWkTJGwZaqhXOwUgJALwTvzvVejJZZRVWzCojLQpaXjIxgOjctmgbBkmEzllsYdn")) {
        for (int qqdjoENtjwnwEYbZ = 384283438; qqdjoENtjwnwEYbZ > 0; qqdjoENtjwnwEYbZ--) {
            bxQMddGtgh *= bxQMddGtgh;
        }
    }

    for (int mbZfC = 160371447; mbZfC > 0; mbZfC--) {
        mmhXhOUcUewiICy = LHtUAoBOUc;
        yQuNPMdivLmoyef += yQuNPMdivLmoyef;
    }

    for (int SdDZSKBm = 1460822831; SdDZSKBm > 0; SdDZSKBm--) {
        wglpZAsPYhJL = ! CApMb;
        tcAFSVLNRdAw = LHtUAoBOUc;
        CApMb = yYfcvWH;
        wglpZAsPYhJL = ! CApMb;
        LHtUAoBOUc += tcAFSVLNRdAw;
    }

    for (int KMPxNGRk = 1408321113; KMPxNGRk > 0; KMPxNGRk--) {
        nChwYfjo = CApMb;
        mmhXhOUcUewiICy = tcAFSVLNRdAw;
    }

    for (int TYyBafbHGIqRUOYN = 263964180; TYyBafbHGIqRUOYN > 0; TYyBafbHGIqRUOYN--) {
        yYfcvWH = CApMb;
        LHtUAoBOUc = tcAFSVLNRdAw;
    }

    return yYfcvWH;
}

double XIBuYsZAR::CIKywNAggZBo(string oyZcRNKh, string kyNUwdl)
{
    bool FSkKnHlJCYuPv = true;
    int Durbcinw = -122873225;
    double ApnnLQGiuQV = -675191.7846693362;
    int yAlUhnimIrBAN = 1991681272;
    bool vuRVUluwj = true;

    for (int tdLPpgNehI = 933897725; tdLPpgNehI > 0; tdLPpgNehI--) {
        continue;
    }

    for (int AhZHhlwVJcOAWcy = 1909156239; AhZHhlwVJcOAWcy > 0; AhZHhlwVJcOAWcy--) {
        continue;
    }

    return ApnnLQGiuQV;
}

XIBuYsZAR::XIBuYsZAR()
{
    this->kdoIkqsN(1500143282, -768579640);
    this->TDdyESralF(-194636.2668013676, 269328.8641549898, string("trgdXmgAJYTJNCUIHqxumEsqSOabTwoBCkoQuCKjqrCtJjHvxOzUHdbUbgTrOTeyUgVktILSehEUArZsudRUcPasqhUBQYyELxNexAwrxOySeNPYGdgGEylPuXrUTngGkzryuwGAxOSwsuBDochqNwgcFGndqkByXEjoHGaaCPUZZyQMTGavAcENYziHagdGfveXutGSPMuafRsWlSmtkafZxXFswDXEqNKuNtQMGLAYtuspJzw"), -58920.039751261786, -2109453129);
    this->leeMhBefj(string("VsdeJi"), false, -1048297743, 2019561722, 235098445);
    this->IVKvdZbQuRc(-623093.9523399515, 767059779, string("iCahmtEdaljAdSBkrxFvmwJaSbOLuKXbdDmyGmE"), string("CdlkQfifsBQULWdUKWwfIIqFScjQgurIoQouFxQXyCMfNRvMqAHfdoYcRgXjgdSlYUJeXQ"), string("bNsJbKcdMbxCfMpdSUPxkvBOnqfVuKmcYsfGemiTogKHeTtQTdjY"));
    this->WDwtyp(true, 2127829900, 1528865142, -266140.0812399581);
    this->sxuYTdnYXcdKIbz(string("XhWBMvMqsIYLtXxKGeNPQqkDnmWVmzYxxjHqaxcIjzAGbfCWYVMdWSAWMQRHXTuM"), 142764821, string("cedMNsViWNhOpJUofYDFDJCDKcsnfKtBsPFCOrfvYlsJTNTulLsOzEUHPrLjzlZDBdQFcVJdhPFMkyuHUwPorDfgLbrZYlsVZrNEzRfwjPultAelJXubzHcLRitPsWkTJGwZaqhXOwUgJALwTvzvVejJZZRVWzCojLQpaXjIxgOjctmgbBkmEzllsYdn"), true, true);
    this->CIKywNAggZBo(string("UUUkJYKJWCsMtPRPmQbgqyzZfugkLQie"), string("FlQRDwIvrIDXZiJclliIoOFtMqnUSBvynQtwYrhXrGchcShnKDDaoKwUSZzEenkJg"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tOZWWtFfx
{
public:
    bool DmgzHNgmZfWW;

    tOZWWtFfx();
    int UNuHVcq(double kpfgWCR, int ozwuQGhl, double KSqMfOOEpRb, int PLdkafXzjHAXXNv, int cHcxOpn);
protected:
    double zDllzKNgahMKSTYk;
    double budptVMBv;
    double lZERRcsuMehV;
    string uaVaLFC;

    double kTsMIqdJTNN(string fyKUsTw, double iqoETLgFzjrwC, int oCRZUXTTn);
    bool MYmUgKZmNWs(double KRAjhnFZxAwBVxPK, string VLtGz, double LGTDJqrHw, int TkIzGGvSpu);
    void AzBcv(string dVQRLOnGHTOLTg, string fPdYtPfBnjYIB, int RFOikQmooNQCTn, bool ZMtTmxVaaJigutFB);
    void Vnzlc(bool kvvwp, double qILyi);
    string bHeVcJoNTUwlF();
    bool hSgVhX();
    int DaokiCaZok(double vnhvbgCMXzJfRW, double BIHLXDiWgrHbdAar);
    bool YoErh(bool FeJevlNEHCzoTvWx, string QwNwsBJm, string MQIGWacqPsOdi, bool TerBgYZdZAKhYS, string UypnMBUZWvkqIpaa);
private:
    double GgKPhVHvBdklmrr;
    int KkIfS;
    string nfXjtheiaSzUe;
    bool JIeWymcBQHy;

    bool FqiEybAd(bool AnhEFrnaDDLgZrRt, bool pBGIhRLJs, string OEhegn, double MhdDu, bool wuYFDSsnINC);
    double nNQWqm(int oLmjghTTiBNYV, string dkSgqqQTBDAER, bool NAxyYMam, double CpjNcSjtkEZNA);
    double ZsWkl(string wuAEP, bool cynlngZo, string mVPNVaGxNOcsRiW, double eXXmDlDeZV, bool fZZiea);
    double RAmmzfzsDrUov(int dGodJnJYJ, bool QFfKYvEzNRTzpMhE);
    string wUareJBpYa(int XcQRtmMI, bool AOGhWxLRwJGdQAr, double RkbAYIvCz, int THKPPm, double lwgOIvmIUvtpsQx);
    double AsZjrvGipT(bool mLQDdvOtNASgO, int PDkLvyqyldifWKjx);
};

int tOZWWtFfx::UNuHVcq(double kpfgWCR, int ozwuQGhl, double KSqMfOOEpRb, int PLdkafXzjHAXXNv, int cHcxOpn)
{
    int djSzEin = -789422877;
    double VQWqlWbXPwmHGcKx = -458428.46975050075;
    int WuCHmKFmgHIzo = -133936320;
    int QpaOdQq = -1037090413;
    int iaertrVnVFh = 461834293;
    double BJdjeMcZv = 480045.6835333826;
    string GBZVEPJmXwOEuqPY = string("OfjymYXSaurcXXgJzhMpBcmwkVuWLoczxdniaVKhUCCZrKTGsSigVuYafxrGngtlmlzTODiTIFGbUoQToIXaxWGBAMGRnrfvkrfCgswNbDhKsqGXCfiPQSYXBRxqDdIsIcOvzyUCTGiLOncZbpNoaggAbgmXeZUUNoamGGuRgMpEeQqcpXROUXuRFLreyWxsCWXGXXGFTTrfovKEjOOntklfJyRsEdHWKlcDOhQbJczApeSzIDsCTZIEwhsa");
    int aPotandnNX = -897444851;
    string IGiYobOJVRPOKGTb = string("cEGMjeKkRxZEkDZHioKrCBPOvFzbZFxAieSyXKVSykJoiIQHkVSmGYSwKdGGOXYJqCvAnacwGXbuzuDyfUafTUHdzNNhipUyEjUYZloVxlPygeFCajXnbgvvkQxwozQRyJQdXJKaeXLdVUxcUcUOFXnmSHRsBvMMsSLeEUYvWFrvDfOgpaJWAWSDgeiUUJIFplrNIuVYFFrdmmIoCiadUlfFObptlgykfFmHVVOEenXg");
    double PyDMdBYa = 271480.58469944715;

    for (int NbDiF = 1974153181; NbDiF > 0; NbDiF--) {
        continue;
    }

    for (int DNfWpkEqeXRYJZGS = 1203543347; DNfWpkEqeXRYJZGS > 0; DNfWpkEqeXRYJZGS--) {
        WuCHmKFmgHIzo -= cHcxOpn;
        iaertrVnVFh *= PLdkafXzjHAXXNv;
    }

    if (BJdjeMcZv > -458428.46975050075) {
        for (int EieLhayQgJQR = 447394468; EieLhayQgJQR > 0; EieLhayQgJQR--) {
            cHcxOpn += QpaOdQq;
            QpaOdQq += djSzEin;
            iaertrVnVFh *= WuCHmKFmgHIzo;
        }
    }

    if (PLdkafXzjHAXXNv > 354045752) {
        for (int gjakuHbDBMaLcJd = 1998217361; gjakuHbDBMaLcJd > 0; gjakuHbDBMaLcJd--) {
            aPotandnNX += djSzEin;
        }
    }

    for (int sjNCQNi = 1708122404; sjNCQNi > 0; sjNCQNi--) {
        cHcxOpn += PLdkafXzjHAXXNv;
        KSqMfOOEpRb /= PyDMdBYa;
        QpaOdQq *= aPotandnNX;
        BJdjeMcZv -= kpfgWCR;
        cHcxOpn = djSzEin;
    }

    return aPotandnNX;
}

double tOZWWtFfx::kTsMIqdJTNN(string fyKUsTw, double iqoETLgFzjrwC, int oCRZUXTTn)
{
    bool UnujcjB = false;
    bool rQCEfKA = true;
    int fgZurXjtTzlRxYR = -1711578420;
    string zgDQNJqwvrpFBn = string("BtCIhjcAFTkHzbKFIVutmIWzIzLduwrPSMvPNrHahLCkPpuqwhEfVBAqNsyENblWvMBpewkipfnFox");
    bool GjArIEB = true;
    bool NjMwA = true;
    bool tqoTyqvsFZOEqprk = true;

    for (int UMWAmWGaDNBQNKEs = 1967469572; UMWAmWGaDNBQNKEs > 0; UMWAmWGaDNBQNKEs--) {
        fyKUsTw = zgDQNJqwvrpFBn;
        GjArIEB = ! rQCEfKA;
    }

    for (int ILWOFDO = 1680393241; ILWOFDO > 0; ILWOFDO--) {
        NjMwA = ! tqoTyqvsFZOEqprk;
        UnujcjB = ! tqoTyqvsFZOEqprk;
    }

    return iqoETLgFzjrwC;
}

bool tOZWWtFfx::MYmUgKZmNWs(double KRAjhnFZxAwBVxPK, string VLtGz, double LGTDJqrHw, int TkIzGGvSpu)
{
    int DGcZrmRnJJrxTSR = -900935343;
    bool FAJce = true;
    string QnJLqAOoavYC = string("wiGvnYMdeVSHjRuqyfsBboX");
    bool kZaIjpfGYXV = false;
    double vLkLnpNEqDSHAr = -469627.05167544645;

    return kZaIjpfGYXV;
}

void tOZWWtFfx::AzBcv(string dVQRLOnGHTOLTg, string fPdYtPfBnjYIB, int RFOikQmooNQCTn, bool ZMtTmxVaaJigutFB)
{
    string ruCvRvZEYutjSaAw = string("XbstnNqeeYKzohgbGRGCXxSwWDkoEMZDHvoVnTjtQLgktPidsIgZgBXKBaejAQoGQQnNSXlSrcvLRQScdgyMeOydrLpAmyYmGXJugBrJCvzTOSZaKXUpkhYsPpVKLxSDnKIxlsgGtfECBFueSgQwAKuKoAuVeqs");
    int mcvkRHYI = -144320403;
    string QDXYiOMao = string("fdMZoDLOeUIcHlKAqTtZNnUDYHqFqssdJZxIggTwtfhHDekIqIaovgzQytevpFnckqDIyoqMxoWygtfmpLaDMwxOKOmojfAqEUhMpQgcwEUrwoITdStweJHILACaYOJIdiuQMyltlOErfpaYYPGPkhOtxaUQVhcFeM");

    for (int eetCoSHPFRNT = 419869286; eetCoSHPFRNT > 0; eetCoSHPFRNT--) {
        ruCvRvZEYutjSaAw += QDXYiOMao;
        QDXYiOMao = fPdYtPfBnjYIB;
    }

    for (int rPuQmOlaoxH = 1626699672; rPuQmOlaoxH > 0; rPuQmOlaoxH--) {
        QDXYiOMao += dVQRLOnGHTOLTg;
        RFOikQmooNQCTn /= RFOikQmooNQCTn;
        fPdYtPfBnjYIB = ruCvRvZEYutjSaAw;
    }

    for (int RcaKlYBeaqoKNXho = 881889663; RcaKlYBeaqoKNXho > 0; RcaKlYBeaqoKNXho--) {
        fPdYtPfBnjYIB = fPdYtPfBnjYIB;
        QDXYiOMao = fPdYtPfBnjYIB;
        fPdYtPfBnjYIB += QDXYiOMao;
        mcvkRHYI = mcvkRHYI;
    }

    for (int eEHMYbIYJl = 1863738952; eEHMYbIYJl > 0; eEHMYbIYJl--) {
        ruCvRvZEYutjSaAw = fPdYtPfBnjYIB;
        QDXYiOMao = dVQRLOnGHTOLTg;
    }

    if (fPdYtPfBnjYIB > string("FyMVPkzYLMEaStExThsorYRmFiw")) {
        for (int XXuBhXBhLKeoxnR = 1012792904; XXuBhXBhLKeoxnR > 0; XXuBhXBhLKeoxnR--) {
            fPdYtPfBnjYIB += fPdYtPfBnjYIB;
        }
    }

    for (int yzjMhzKXX = 1496680219; yzjMhzKXX > 0; yzjMhzKXX--) {
        dVQRLOnGHTOLTg += fPdYtPfBnjYIB;
        RFOikQmooNQCTn = RFOikQmooNQCTn;
    }

    if (dVQRLOnGHTOLTg < string("XbstnNqeeYKzohgbGRGCXxSwWDkoEMZDHvoVnTjtQLgktPidsIgZgBXKBaejAQoGQQnNSXlSrcvLRQScdgyMeOydrLpAmyYmGXJugBrJCvzTOSZaKXUpkhYsPpVKLxSDnKIxlsgGtfECBFueSgQwAKuKoAuVeqs")) {
        for (int uNzinPsX = 1785374228; uNzinPsX > 0; uNzinPsX--) {
            ZMtTmxVaaJigutFB = ZMtTmxVaaJigutFB;
            QDXYiOMao += ruCvRvZEYutjSaAw;
            ruCvRvZEYutjSaAw = fPdYtPfBnjYIB;
            ruCvRvZEYutjSaAw += ruCvRvZEYutjSaAw;
        }
    }
}

void tOZWWtFfx::Vnzlc(bool kvvwp, double qILyi)
{
    string BhxvdFM = string("APiAnIFPtiKKsoczPTeIESTZvsCpgeysUcEEUsHjssieUVAOTUahZjsaFYfrdLPYCmuMcgMTOZVEBfQvIQfGngwCujwQJlDgowdLUWKRlVIjNCpBHpoJbpkITZgTIqyHCJpExIeAuNwUNuTyOtuDjAUJxliMrowmIQfHDCQkjxuGvcJJEwQWNNGkcbbJQhPsGadxNBUbAVMXdAKppXHhZFECEPPdSCprfrjpNi");
    bool cCCRjE = false;
    int zwFxlknnlhEndC = -742343022;
    string yMeeHOMcUauNtzw = string("cxZGCvTOcYyItdNxcavBPhSKHTeTzPJUFgAPzEEpQjYGaE");
    string PMiHiZdcMF = string("ncTEjnBInFnZszOSDIVnQkqKDCnfmumAOeTJIsDFMyhYdhHqsdMyYcwPIOgpM");
    string TgzDKdmfarUwI = string("reiFsLaSKTcJvdTkSLvNjGsUWRpVfyJyrZAsMRKnIWhcyiJIOwZGwKcHFGyeUIDCUiyuuzJhgHZOuxnojIleTBKCoUyeTbf");
    string sJvoPAd = string("AfRmswFViZrrThoYwMyuyxTQZNmUkvmNQmFKpxQyVDePLXUwcGSrfryWEugYtcqYvEVxvAlYKaNqbJerNdaEBmiuqUUmCASutLDQxWcEJmpHxAmaMWvD");
    bool lMqmfqkFVoxrQo = false;
    bool tHJZEAlJKkM = false;

    for (int mdbSKHtK = 205986323; mdbSKHtK > 0; mdbSKHtK--) {
        lMqmfqkFVoxrQo = ! cCCRjE;
        TgzDKdmfarUwI += TgzDKdmfarUwI;
        kvvwp = ! lMqmfqkFVoxrQo;
        TgzDKdmfarUwI = sJvoPAd;
    }

    if (cCCRjE != false) {
        for (int bFCqRkzcntkfOBwi = 504319894; bFCqRkzcntkfOBwi > 0; bFCqRkzcntkfOBwi--) {
            lMqmfqkFVoxrQo = kvvwp;
        }
    }
}

string tOZWWtFfx::bHeVcJoNTUwlF()
{
    double teqEvWsEx = -718630.341091513;
    bool KoWBZeRVdsAom = true;
    double VugSOkHPzeA = 123923.85511700845;
    double sBxLhZaccB = -667911.8698593552;
    string KzxVFj = string("zQvYeJJkaaNThNizlEIawrZBwKZOvEWGSNzugFUxSgGTNntuhgQMvnqPfuOucFXFFHO");
    string RGUbf = string("PwMbJsEosVXbTZnbeCIXGVgcyFLhXtTThPwhBxsQWWwtZMyPEIPUJewUMaAKJGWgdhcItLZExEwyRvJazleNoXTAmlhupKjDntmqNBLDwsYDJkcQkIMITUDQhOjmREuHKmCCNsPCxzkZHjyFVOsTIBXKMFYTBEZurbHpvIvOaORtrkDpyTUZqljOQSJJIzhWHOcaTIOPCZrVv");
    double XplwB = -255661.61564359642;
    string ttaQLGPVSam = string("mOnpXHjkQAkDCKTtVZimTpHwvLfQgsnqgYxKNxOjavKFywNDrJjKquDAFPLAebjwybnkkDjC");

    for (int nTLAsBXp = 592098410; nTLAsBXp > 0; nTLAsBXp--) {
        ttaQLGPVSam = KzxVFj;
        sBxLhZaccB = teqEvWsEx;
    }

    if (ttaQLGPVSam <= string("PwMbJsEosVXbTZnbeCIXGVgcyFLhXtTThPwhBxsQWWwtZMyPEIPUJewUMaAKJGWgdhcItLZExEwyRvJazleNoXTAmlhupKjDntmqNBLDwsYDJkcQkIMITUDQhOjmREuHKmCCNsPCxzkZHjyFVOsTIBXKMFYTBEZurbHpvIvOaORtrkDpyTUZqljOQSJJIzhWHOcaTIOPCZrVv")) {
        for (int URihkmocMdltX = 899663168; URihkmocMdltX > 0; URihkmocMdltX--) {
            sBxLhZaccB *= VugSOkHPzeA;
        }
    }

    return ttaQLGPVSam;
}

bool tOZWWtFfx::hSgVhX()
{
    bool oNUAzppcTKmk = true;
    int kNNjbUeSM = -798839132;
    double kFqcUidW = 788963.0657076858;

    return oNUAzppcTKmk;
}

int tOZWWtFfx::DaokiCaZok(double vnhvbgCMXzJfRW, double BIHLXDiWgrHbdAar)
{
    bool CqybaNChp = false;

    if (vnhvbgCMXzJfRW >= 123163.27474827209) {
        for (int KxwcJtZkMcZznSM = 1124795489; KxwcJtZkMcZznSM > 0; KxwcJtZkMcZznSM--) {
            BIHLXDiWgrHbdAar *= BIHLXDiWgrHbdAar;
            BIHLXDiWgrHbdAar -= BIHLXDiWgrHbdAar;
        }
    }

    for (int gmwKraGEN = 941617399; gmwKraGEN > 0; gmwKraGEN--) {
        continue;
    }

    return -850745101;
}

bool tOZWWtFfx::YoErh(bool FeJevlNEHCzoTvWx, string QwNwsBJm, string MQIGWacqPsOdi, bool TerBgYZdZAKhYS, string UypnMBUZWvkqIpaa)
{
    int ASLUdZLWxMqIkuh = -804612693;
    string fOaepazWl = string("XFkLrdrvafSlWYNIMGVYXHyislGgoEhLMspBXgFYjYgtaUtiUiFSrntgZcDFyUVGobpzaKJQQxsZdPZvXzUbvbRTZpndBnAFTiwHOiqftqIAXJDRQowYTcQxXvTjwtGNWVWqWadfTZnZYIim");
    double BMcDDau = 276645.6056400522;
    int QzxSBfF = 1277931159;
    string XmItejds = string("AALrdQwNamyAzdsyjSRnXuiLRImrjGUmepSDtpistcXNbkWmVFwNzmHWOQBbagdPmGkDHQtvnDRyAmufOjQEgLgbudUYeegkBDzXGywmpVRtgEeorfhvlluwYcbcoHNNbfJAvaDjRakmQvYzSKEhqTtAJefjvUyrLJtpdJIjQgRcOb");
    bool RlUOhr = false;
    bool NfxEYFY = false;
    int dzfvd = 1854562290;
    string tdEqmym = string("M");

    if (TerBgYZdZAKhYS == false) {
        for (int gFCwhbnijV = 569835546; gFCwhbnijV > 0; gFCwhbnijV--) {
            UypnMBUZWvkqIpaa += fOaepazWl;
        }
    }

    if (QzxSBfF < -804612693) {
        for (int wFcDujSjUqksOkg = 1667011560; wFcDujSjUqksOkg > 0; wFcDujSjUqksOkg--) {
            fOaepazWl += XmItejds;
            UypnMBUZWvkqIpaa = fOaepazWl;
            RlUOhr = NfxEYFY;
        }
    }

    if (XmItejds >= string("MhGEbAszqYPfKLgptYmdJTHEOLSQZimEtIPsajIdjTiwvVoJSkKbDTzCUZMXDcDtAYjDDHznMvnAlcSQMlcfQgPIBXkYJUJojHXzJWoizIoByLtxAogPDuAhfHDRsXgFuIgtJuX")) {
        for (int JcOSQxSAtWLfj = 1097241456; JcOSQxSAtWLfj > 0; JcOSQxSAtWLfj--) {
            ASLUdZLWxMqIkuh -= ASLUdZLWxMqIkuh;
            UypnMBUZWvkqIpaa = tdEqmym;
        }
    }

    for (int sBCECjN = 703112410; sBCECjN > 0; sBCECjN--) {
        TerBgYZdZAKhYS = ! RlUOhr;
    }

    for (int OUNbdbsdcOTmu = 2022833859; OUNbdbsdcOTmu > 0; OUNbdbsdcOTmu--) {
        continue;
    }

    if (RlUOhr == true) {
        for (int qcFQTKvMit = 2143602115; qcFQTKvMit > 0; qcFQTKvMit--) {
            continue;
        }
    }

    return NfxEYFY;
}

bool tOZWWtFfx::FqiEybAd(bool AnhEFrnaDDLgZrRt, bool pBGIhRLJs, string OEhegn, double MhdDu, bool wuYFDSsnINC)
{
    string bBwAVALYYzLbMNdg = string("IFfyotsfWtjSHDoOXLSYvBElBHAsEivxLePKLBEySvAjuCwuRZlCMHuhAdiFSwSrwFheuMuZXLuYkrVzNgovYiuiJUElsyQxbGsCEjbldTgVVryDEcJGrEAUufjhoMfpqTf");
    int eMrEwfJiadFX = -25972918;
    int bcZNQySrW = -1454513757;
    int RgXlFuPuScakDz = 271838348;
    double FWQkovfCOCvcusPG = 473051.1469714494;
    string OOpMOG = string("GNhTEwpRPpkSMbIBRtXIPWrvblngsPJkioRULMCoTZQAxaVxZiNmoRInsAyJnfwkLwnswfTwSgTxmoFNjohAYleBFFoFHuqHHbzkVqTItDKreIVxRFAUNeTsPtKioVofSTwwVmfGFxEJgcPVHWfAkWkfpQjSLFYuaPXYVmSHgfYTrmLiMh");
    int HmyLLhjrJLyBvTN = -1149656412;
    int MBzpcQeKjar = -267236492;
    string sddznmcoI = string("oqWpUtzGpzUMVyGktoJyVZDYhJjzzIMdMEtiURsJshWXFGGWhtSXnJXIIhmwgxVvHwmPEYkGElAbFMwgVfJgMbNjavLgAEeHZTXVWTbxWwWORMTkdbVyssxSgvottORaxzUezQkTMQJnPRdGHrskXUURCdahVHKbGSzwdOfXrxzrTMZhfemysVVpUWmHMiItuPwJLvuiQQNtblz");
    int TvMQEr = 1156556234;

    for (int noPiPqor = 1706207860; noPiPqor > 0; noPiPqor--) {
        bcZNQySrW /= MBzpcQeKjar;
        TvMQEr /= MBzpcQeKjar;
    }

    if (pBGIhRLJs == false) {
        for (int cEDGAoQCZ = 870425691; cEDGAoQCZ > 0; cEDGAoQCZ--) {
            continue;
        }
    }

    return wuYFDSsnINC;
}

double tOZWWtFfx::nNQWqm(int oLmjghTTiBNYV, string dkSgqqQTBDAER, bool NAxyYMam, double CpjNcSjtkEZNA)
{
    string rDUXzVgBb = string("GHeJRTzxDeQOABwDTaOsnbhlPDcuASKntokxMvQdFaMpoGTINBmIncXTOeDPTCGTAbhbGAWtjFuODgcGlBmPDwTfsHGAzPsgoLMPVwkmpmdttkBsqgbK");
    int gkRag = -1552423822;
    int umbymrJ = 1062081679;
    bool rEwsIJSuOqQWHKM = false;

    if (NAxyYMam == false) {
        for (int wrwWTXWY = 1590943330; wrwWTXWY > 0; wrwWTXWY--) {
            oLmjghTTiBNYV /= umbymrJ;
            oLmjghTTiBNYV /= oLmjghTTiBNYV;
        }
    }

    for (int TbqcWlX = 1280098148; TbqcWlX > 0; TbqcWlX--) {
        gkRag += gkRag;
    }

    for (int ERTHVBLCpehl = 903061182; ERTHVBLCpehl > 0; ERTHVBLCpehl--) {
        continue;
    }

    for (int dQFKtThlcW = 222767954; dQFKtThlcW > 0; dQFKtThlcW--) {
        oLmjghTTiBNYV += oLmjghTTiBNYV;
    }

    for (int vxDGNcS = 247673804; vxDGNcS > 0; vxDGNcS--) {
        rDUXzVgBb += rDUXzVgBb;
        gkRag *= umbymrJ;
        gkRag /= umbymrJ;
        NAxyYMam = NAxyYMam;
    }

    return CpjNcSjtkEZNA;
}

double tOZWWtFfx::ZsWkl(string wuAEP, bool cynlngZo, string mVPNVaGxNOcsRiW, double eXXmDlDeZV, bool fZZiea)
{
    int LgGpQBTZ = -1754886025;
    bool sFZSvsanInybPrL = false;
    int kyfOQGWWuVWd = -925825910;
    string zdBbpYO = string("p");
    int IPCqIk = -1157349114;
    double BTZagSlkeZBykTdU = -259531.5894973658;
    string WFoMXTcgTh = string("azcnBmWGimEQnbEGLneyIxEpKBPPUjQAAmITBayEcUyDjSBWFbugwmEzqecGQXMkgdIoWcknPBjwylRaJUxDLLdcazcexejsKGHVNbmMzEuBlSiuWYmsXGSUxiUTPhWBjLSHbKNjwOXYyPIwdIDRnoxlUuppybXNbPkvmczyhNkwWSwIWngdMhSmseruvCLjfnqfFTLVOhwZRxzdBHjxYaWTZZzzRvHExrwzNyoQHTgxH");
    bool XSDbFWLPiKhzqEj = false;
    string mOTvko = string("bYgSbQfKVegEknBlPFfcUpBSYwOYJIvBrsPhbUYfSpFfzGWgrAatSyzKJQGYogbiDtMqmpflIwoQlgrcjNgqrRPaZiSqTekMzNuZOzaHpCniiQNXCGdDjIssQsNLAABBPwKyrxSWXmkMfIOPXfDRSTUKEGoeFYPUtzcBNikATPXfiL");

    for (int WCxoMngyY = 132825358; WCxoMngyY > 0; WCxoMngyY--) {
        continue;
    }

    for (int tiISfvFCQX = 1706970236; tiISfvFCQX > 0; tiISfvFCQX--) {
        WFoMXTcgTh = WFoMXTcgTh;
    }

    for (int xNSkiYWVSBm = 462379249; xNSkiYWVSBm > 0; xNSkiYWVSBm--) {
        zdBbpYO = mVPNVaGxNOcsRiW;
        XSDbFWLPiKhzqEj = cynlngZo;
        cynlngZo = fZZiea;
        XSDbFWLPiKhzqEj = ! fZZiea;
    }

    for (int zCzhwQBNhA = 371881708; zCzhwQBNhA > 0; zCzhwQBNhA--) {
        kyfOQGWWuVWd = kyfOQGWWuVWd;
    }

    return BTZagSlkeZBykTdU;
}

double tOZWWtFfx::RAmmzfzsDrUov(int dGodJnJYJ, bool QFfKYvEzNRTzpMhE)
{
    string pmwxemmTPKD = string("SHzfAJYFcgaxtDjsTTKsVqKIIVYzXiSPFbtVMcQUrPuaxxiCdAOvCcMOSlRtleLbamVzeNzACuEmovxuRCpnOwAvMgBYLINRuPfPevFIqVtNDguLnQcnRrJEovLGvTqkHteWKQvzLznpGkzZABhMlmUtnjGSHSFsGhgTTplGMaaFXfOwIWiONpPlEynClDUUGclSrvwjrWdQsoizMuxE");
    double idxCJhstTMBpjzuC = 995609.3323852172;
    bool QvhLgQAisQAkTHlu = false;

    for (int RtlzwlHCSkIpkHuW = 1015329239; RtlzwlHCSkIpkHuW > 0; RtlzwlHCSkIpkHuW--) {
        continue;
    }

    return idxCJhstTMBpjzuC;
}

string tOZWWtFfx::wUareJBpYa(int XcQRtmMI, bool AOGhWxLRwJGdQAr, double RkbAYIvCz, int THKPPm, double lwgOIvmIUvtpsQx)
{
    int hwcCrAws = 843682138;
    int PaJAPZD = -1236536784;
    bool AAJoACp = false;
    int tjLdsLP = -1101973597;

    if (PaJAPZD >= -1236536784) {
        for (int DzRntC = 2052709682; DzRntC > 0; DzRntC--) {
            AAJoACp = AOGhWxLRwJGdQAr;
            lwgOIvmIUvtpsQx *= RkbAYIvCz;
            tjLdsLP /= hwcCrAws;
        }
    }

    return string("uQUjxHrkMkuXarQUPiaZVXHnpOHeuyNicyWkchNQtXYJizonkLtIsnzIQmlEPeRRbZaHBlIWOubWnNOiow");
}

double tOZWWtFfx::AsZjrvGipT(bool mLQDdvOtNASgO, int PDkLvyqyldifWKjx)
{
    int oKRVrEdzec = -1356682539;

    if (oKRVrEdzec >= 1487728969) {
        for (int oiemHllmHH = 376209677; oiemHllmHH > 0; oiemHllmHH--) {
            PDkLvyqyldifWKjx *= oKRVrEdzec;
            oKRVrEdzec /= PDkLvyqyldifWKjx;
            PDkLvyqyldifWKjx += oKRVrEdzec;
            mLQDdvOtNASgO = mLQDdvOtNASgO;
        }
    }

    if (oKRVrEdzec >= -1356682539) {
        for (int UtjOGJz = 1633245782; UtjOGJz > 0; UtjOGJz--) {
            oKRVrEdzec /= oKRVrEdzec;
            oKRVrEdzec = PDkLvyqyldifWKjx;
            PDkLvyqyldifWKjx += oKRVrEdzec;
            PDkLvyqyldifWKjx = PDkLvyqyldifWKjx;
        }
    }

    for (int prfwpMxAnYYw = 43428618; prfwpMxAnYYw > 0; prfwpMxAnYYw--) {
        PDkLvyqyldifWKjx *= PDkLvyqyldifWKjx;
        mLQDdvOtNASgO = mLQDdvOtNASgO;
        mLQDdvOtNASgO = mLQDdvOtNASgO;
        oKRVrEdzec /= PDkLvyqyldifWKjx;
        mLQDdvOtNASgO = ! mLQDdvOtNASgO;
        PDkLvyqyldifWKjx -= PDkLvyqyldifWKjx;
    }

    if (oKRVrEdzec < -1356682539) {
        for (int TCDgN = 1175555077; TCDgN > 0; TCDgN--) {
            oKRVrEdzec += oKRVrEdzec;
            oKRVrEdzec += oKRVrEdzec;
            oKRVrEdzec *= oKRVrEdzec;
        }
    }

    return -519453.047252227;
}

tOZWWtFfx::tOZWWtFfx()
{
    this->UNuHVcq(-717554.513947302, 227757908, -1012502.0183140921, -1912702143, 354045752);
    this->kTsMIqdJTNN(string("cVKMJFCgyRbghvcoPrQUYEwyeUpIHPGncEgUFpNKkIvsnWFMyCKJVmjLrlosrTNxbeeSLQFVmsOFSGnlpwhOUUEDncDZzOAHzYptriuERGqfZrlUvGxELJPdsLYIJqTtDtQPVYeMnTgpANbhKwzLJbHPHejMqBhneYyfIMQXhwOFIDRdafurQIMpXNXVIefQpkwLZb"), -520405.49414868694, 1548479792);
    this->MYmUgKZmNWs(-691164.0156896634, string("VkxAMobKbVABnbsPJircvBrjpXNIwTkVOOjHRWsBTWwOFGGwrbmAZgLcJzHGrFvGDfNiVLvCatpNOEuCcuaSPqdrWUXyIXTVbcvbyrz"), -842300.3239499715, -1637182156);
    this->AzBcv(string("FyMVPkzYLMEaStExThsorYRmFiw"), string("zbPAgBIGcuIopEEIHrgNknRAuAClePSlOHnWKazOhoBrBJsLvuFZmDExICAIGMdqzIhrVuTbkUYSpnYMEqczvDXEYotzdAmLXGpQZDNlmTrUMZpcRMfwPPf"), -1464690160, false);
    this->Vnzlc(true, -729751.5565271553);
    this->bHeVcJoNTUwlF();
    this->hSgVhX();
    this->DaokiCaZok(587023.011233558, 123163.27474827209);
    this->YoErh(true, string("MhGEbAszqYPfKLgptYmdJTHEOLSQZimEtIPsajIdjTiwvVoJSkKbDTzCUZMXDcDtAYjDDHznMvnAlcSQMlcfQgPIBXkYJUJojHXzJWoizIoByLtxAogPDuAhfHDRsXgFuIgtJuX"), string("dBuKzgIeudNTrHfgXGSpUpTNeKrnOcFCgMsISnkzrxTdwgfkcgSZhfWLjetXltrzFaLsljGHsRmFyoHzUCXFTjbZq"), true, string("wHsCHBvbXOvZfMmdDYdOGTBDfeoacNjnnTMfxBYDYrWfqdPBhipVRNQRJOAAcshjxAmHTtBWqhtPsUcnGGuHXHXlWbzbheNjmQLlgjBWeJXbVLyrzWgIDCioFRCo"));
    this->FqiEybAd(false, true, string("cBovrODEbCprnYHfaCFThICgKbdkKjVXAQDPmrVWLIxHXLMqJNZYmyuJXMGzaNLgepYQULgiIreDgaiDwBRaRoIMcuWsjqnqUAncbAQkYkDlfFkywceGIwqaFpSLwxYTSrGGEkSfQwrvlMwdtHfXaqjuOVOQqYHiUGtDHrraQyfZmcYTBLcbtIepPDyLHaErJIhMwYcXCRFIKbeJAYHgzZfAUZfEPorAPLOwYgwrTencQ"), -127412.99821490988, true);
    this->nNQWqm(116766785, string("jmceooWPORdJBmmdOrvLbsuVbdJVHqPwyMXEXDwIkZUQfImeaVhOaLsfRhYOkxzXIRSjvsJHfDHgXZZfeNtxrSptrLTIbvHvAzwcVyUApzlNYtmMOLRAjMmIlctQiPaSxIxbmdosMGszzBhxnfAjQqemJwuW"), true, 869640.2955102854);
    this->ZsWkl(string("BjlMvhdlmbCqUnUskyXIEfukoInskNmyleoMllyROruxcZROGtWXkkeoWwnMOthmpyrbyvkcYQrFihENYZFvtHu"), false, string("YNmoDpJVzStjuYtDLNMCTLKvVaYWQGuHRQYBaHcIzdZAbBezkIHZdEWhXrpnlBVWyknozYkIGmnqQHzqKJRdelmAaLhhDZTmKczgahlJHAteIbmzLUpRXXcNNBvpTHDVHPDzdfiKfTNGQjjQrWIMWIlxjzQgJukxkioTQFBlAkAioHrDZCgyiJLXKPkzuYsurCLrlldGCePTXHxYrCbGhhSYXHKzifFYa"), 818863.3639986343, true);
    this->RAmmzfzsDrUov(1299260699, false);
    this->wUareJBpYa(-175504833, true, 534509.7080224165, -1812872720, -680226.6393873885);
    this->AsZjrvGipT(false, 1487728969);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dNgzHueyfzIT
{
public:
    string ZTIAnKGzN;
    string SZncB;
    int eWFDFc;
    bool IWbNjTS;
    int tEWkLIZgluzT;

    dNgzHueyfzIT();
protected:
    bool pRPHoM;
    string dxADkmgFjzWX;
    bool krFXrFZ;

    int UnwzVPFHMjH(string zxJXF, bool nSTOQvtjEczLumAP, bool HyMvj);
    bool SgADKbXGVqzDiKHr(int quIgAyd, bool dRDKBRbuFqhO, double RColhkGam);
    double MlUdmITQUuN(double IIZlERNBW, bool DAhuXazfxVtSkJ, double FhUqobsouxq, double wlVQvk, bool LnvXPnCtJnv);
private:
    string dswJgzyM;

    double xyQCVqtTzv();
    int dKZnBuFekEnV(string SoJOpCcliLmTyeg, string KpOKJWtZRQGMfN, bool LKfzV);
    double jBYTazBPUPAWltL(bool nyNcTCuqysOxIcc, string QFdyFiJAp, double itchVOoGuRrqqe, int UGGVwArEk);
    bool yMJpvx(string CmGTiktrbYy);
};

int dNgzHueyfzIT::UnwzVPFHMjH(string zxJXF, bool nSTOQvtjEczLumAP, bool HyMvj)
{
    int djxZOlLs = -951254241;
    double dYESRDC = 75205.03145518067;
    int wMTqkyVW = 1198926413;
    string EthTcmnKZG = string("PwUyAKIBvPIoIlyKUofSZhhEchLKaVprREeIFLrewNHcbWyAVIjclSnnoZKNhBQLncTWbHNuRnHFnWfwXJzcLDmtQiRfJbPrsZTNliENylyFYjkKvQPSRjWJsDOAewqsrPCYPrXAqGjmVDxhLWOxzsGkrGrSlhaRVcfHlzJaKbLMkkSHIQhFbCqLywUWbbPlzTNtgxOugBOmtlAmftKUIEEnqyEKjHLNPZNqdxgVZGjShExRGG");
    double fQbEfNktGdgKxfw = -488473.50856041216;
    bool zxAjqCGn = true;
    string iwzNLSRcWXLEtc = string("QkMmScESRdIUvSEonxlJBNCEyZbtBcNxjOgLzKsWTgxuoFmlBveFooxBRxSzMZvBhdyNswbkWkBUPfhiCFSyAPzmTAXQAAgFvF");

    for (int djLnwserCYy = 971932357; djLnwserCYy > 0; djLnwserCYy--) {
        fQbEfNktGdgKxfw *= fQbEfNktGdgKxfw;
    }

    for (int khrjTSVMkkgH = 502765274; khrjTSVMkkgH > 0; khrjTSVMkkgH--) {
        EthTcmnKZG = iwzNLSRcWXLEtc;
    }

    for (int pfluUxaITQJEj = 1047164473; pfluUxaITQJEj > 0; pfluUxaITQJEj--) {
        continue;
    }

    return wMTqkyVW;
}

bool dNgzHueyfzIT::SgADKbXGVqzDiKHr(int quIgAyd, bool dRDKBRbuFqhO, double RColhkGam)
{
    int HpnLfsiX = 1761115994;
    string YbtnghnSgv = string("LyrqhmKDIQafXTdkmiHunRWeSypwzuRZjmkkAYAJyKkSICVv");
    bool KWBZBsZXUvYwBD = true;
    double PBZnOgqkNZhmu = -82750.71172160866;
    string CmvBhzreoXRwAFaX = string("haPjjMBYIzgLAFAXkhaMUacUBsgGvLfsZveGxpqJdMXgKYfGSdlCJxFMbaUbcfHKZvhocnSCZxXAuMaUrIFqtpGMqS");
    string VSmaYHEtiM = string("QwLvNRcHJzNLcwWQzWTTZtNumfXnxOxuZjOKPzZIIahgbywNlwZihezlkZlwVbRNdvIJuwCuIsEzBnDYxMIECiKmhcgDjLNncQBYIPlmVUiQnvGLPvAIEfWoCPhpRPklJnZxmbwgYJmEXyClVixyoZeoAinOTjwUEwcBmJAQHHb");

    if (VSmaYHEtiM == string("haPjjMBYIzgLAFAXkhaMUacUBsgGvLfsZveGxpqJdMXgKYfGSdlCJxFMbaUbcfHKZvhocnSCZxXAuMaUrIFqtpGMqS")) {
        for (int CQZxLfQ = 1770819442; CQZxLfQ > 0; CQZxLfQ--) {
            dRDKBRbuFqhO = ! dRDKBRbuFqhO;
            CmvBhzreoXRwAFaX = YbtnghnSgv;
        }
    }

    return KWBZBsZXUvYwBD;
}

double dNgzHueyfzIT::MlUdmITQUuN(double IIZlERNBW, bool DAhuXazfxVtSkJ, double FhUqobsouxq, double wlVQvk, bool LnvXPnCtJnv)
{
    double jyRSlrJXUoFkD = 901195.4282243402;
    string KFEoqQDRAK = string("VglvmKiVdpLcxSoKlEfqYNOUrMARahMMbYVMpTNDycCchDOgNmGyZPVVzyhJuwQinYIzYwrvgreCdGAXupYTuKkORiKjuwKnihpjfMVzxPlrBIxjBgnDYxDEjUVSAOOjWdJYayUYhUksPHSGffIKTOprWNQUnLvxgJcyirMoAHbPJracxoigrNBSJHNvolvO");
    string DYvKPtesiSp = string("ycqmIlMHAMsHnqyyPewnjbEXyIGfkApXBWwkXfhXgHmcvYutZMFfHlbwJjwCLqpWzpodMLAZbUXVlsAaJScORosDwATRdJTpDTixJpduuPJQhQNIVGPeZhaQVeHfrDOvVbxvIaGfEOPhkffrRBVgokfuOPuHBMrLFzWDcBFdTIRkFBTiukFEFqUbsI");
    double rmutAUCkjJgZhl = 271762.1902681878;
    int LSbkIgiOmWscMCNw = 1782336361;

    if (wlVQvk <= 892162.1280796779) {
        for (int bzwDIGnQGhGtG = 971012242; bzwDIGnQGhGtG > 0; bzwDIGnQGhGtG--) {
            LnvXPnCtJnv = DAhuXazfxVtSkJ;
            IIZlERNBW /= wlVQvk;
            jyRSlrJXUoFkD /= IIZlERNBW;
            DAhuXazfxVtSkJ = ! LnvXPnCtJnv;
            DAhuXazfxVtSkJ = DAhuXazfxVtSkJ;
            wlVQvk = jyRSlrJXUoFkD;
        }
    }

    return rmutAUCkjJgZhl;
}

double dNgzHueyfzIT::xyQCVqtTzv()
{
    double SHOVFEthbKVVakgZ = -220087.60433424253;
    double TRmgWC = 431574.7155739979;
    int JLtlHYJaqyNtVMG = 2134262605;
    string CfynRuDOo = string("gziPMjjesHaIliyrpADGksBNRGmezQQGDzeBhUQBlRfYSyhStZwzZJiJZiocxfxGYcCWbNuuzXpTHjLIPrgLFrJJrioGMbRcixUEWYnKPbFoiKCerGkklTxnhqseSnbexeTnCUugajsCROzt");
    string RCeKysAHGCtW = string("BBrMIKBelgMpRvCsoqTlGLmAeTAfCnnijsBDSfuZDnTIbbaPvklwsinQgxMftiTMADVvNIzTKjavmsDQhacVRTYleOt");
    int ZipOPxZ = 1962564919;

    for (int uYvVyeSbsw = 1239947066; uYvVyeSbsw > 0; uYvVyeSbsw--) {
        RCeKysAHGCtW = RCeKysAHGCtW;
        CfynRuDOo = CfynRuDOo;
    }

    return TRmgWC;
}

int dNgzHueyfzIT::dKZnBuFekEnV(string SoJOpCcliLmTyeg, string KpOKJWtZRQGMfN, bool LKfzV)
{
    int seVVuFyXZaaP = -668172607;
    double wKOrMONJvXl = 766824.7864511858;
    string uYXyiFRveXE = string("otuJFIIJwORKxeKrErWGkcdKIuAwNnutNRhQcuYxbzZqTcWW");
    double EoZGMIwXNJKzkly = 122955.51416749928;
    string HTPeiFyOIxvdgEGR = string("ZstQGDlXhArpdPAKmqedvtKBblkvBDVCVFLxEcicnTCKKnPukNUVMnKIIgpdCCLFITjoYcHAklxCvKazyYDfHISkJhLUaTpqSrzVwyAShyGKmsAQGMCdOWfIoQaIwxHhHdmleNbiB");
    bool ulUKKDN = true;
    double nsyiSWzYA = 383779.2585740375;
    int ZnXlWVl = 1661312769;
    string TgWcEe = string("wvSZavsqglBEtaAjjHCdvZdUfRYZwzGVChlounIHNxGlHkPsISJriMkb");

    if (ZnXlWVl != 1661312769) {
        for (int XIEcgQNrpuV = 958148503; XIEcgQNrpuV > 0; XIEcgQNrpuV--) {
            nsyiSWzYA += nsyiSWzYA;
            KpOKJWtZRQGMfN = TgWcEe;
        }
    }

    for (int bYVFkTzGLKmQ = 33787684; bYVFkTzGLKmQ > 0; bYVFkTzGLKmQ--) {
        TgWcEe += uYXyiFRveXE;
    }

    for (int CBWqItCgimdZAxkv = 1338503771; CBWqItCgimdZAxkv > 0; CBWqItCgimdZAxkv--) {
        SoJOpCcliLmTyeg = TgWcEe;
        EoZGMIwXNJKzkly /= nsyiSWzYA;
    }

    if (HTPeiFyOIxvdgEGR < string("wvSZavsqglBEtaAjjHCdvZdUfRYZwzGVChlounIHNxGlHkPsISJriMkb")) {
        for (int ZiBfIO = 507496447; ZiBfIO > 0; ZiBfIO--) {
            seVVuFyXZaaP /= ZnXlWVl;
        }
    }

    for (int vfTyke = 1780429971; vfTyke > 0; vfTyke--) {
        TgWcEe = uYXyiFRveXE;
    }

    if (nsyiSWzYA <= 383779.2585740375) {
        for (int LbxNjOSpsoaynIs = 300319836; LbxNjOSpsoaynIs > 0; LbxNjOSpsoaynIs--) {
            continue;
        }
    }

    return ZnXlWVl;
}

double dNgzHueyfzIT::jBYTazBPUPAWltL(bool nyNcTCuqysOxIcc, string QFdyFiJAp, double itchVOoGuRrqqe, int UGGVwArEk)
{
    string NHuxI = string("NSgZGjrZ");
    double qZCTUaH = -454766.724137702;
    double ScfHlzsxKNpfHF = 36369.919662852946;
    int mCEUxeVJIGc = -2040491753;

    if (itchVOoGuRrqqe >= 36369.919662852946) {
        for (int cbWkMmSqE = 615722054; cbWkMmSqE > 0; cbWkMmSqE--) {
            UGGVwArEk = UGGVwArEk;
            UGGVwArEk -= UGGVwArEk;
            itchVOoGuRrqqe /= ScfHlzsxKNpfHF;
        }
    }

    return ScfHlzsxKNpfHF;
}

bool dNgzHueyfzIT::yMJpvx(string CmGTiktrbYy)
{
    bool BThOQo = true;
    double xsWPnFKbrcatQ = 362033.13790021173;

    if (CmGTiktrbYy > string("CsXjRafZdpSrNtrfIENuTAlugzOqvKUAxgkbVA")) {
        for (int kRFaf = 1124796502; kRFaf > 0; kRFaf--) {
            CmGTiktrbYy += CmGTiktrbYy;
            BThOQo = ! BThOQo;
            BThOQo = BThOQo;
        }
    }

    return BThOQo;
}

dNgzHueyfzIT::dNgzHueyfzIT()
{
    this->UnwzVPFHMjH(string("ZGzComZXoOxSVgsTVmQssPsFgewIlcruEavqXxzafgWavcKxCKRBxHLFARGpvqXjsKAyTIp"), true, false);
    this->SgADKbXGVqzDiKHr(81636180, false, -610055.4193899626);
    this->MlUdmITQUuN(647169.6889586869, true, 32646.773540920025, 892162.1280796779, true);
    this->xyQCVqtTzv();
    this->dKZnBuFekEnV(string("qaHjwGsFqufXmWPKBEBWvXYRRzJhZhJcjzIdTQxHMvclyQcKACrUgWeByRfkXanKBvCLFSnjFTlXNlFGcbVNYQLgeQkXnQFPfyVaGDhutwBnzHimtLMHTqxYMHJaQKPSDDaPIzqP"), string("wRGTyiukOCZvgWlrEnbymHAewhRrOQRpPEARIfmUxpAoemBbogXDhvpgJJETIuYAqZtUFBvTYyApllYsPCkSvJPIpKAZeSQQKRAMTUYfDCXdHXFMCdpbDaRYGtEJBdyJbmLTIXaNZhgDmomxWGTTxsMJZtFxMGTuTYDpjjrNFLRxAElXVKUhPqhcvbqGFxVrR"), false);
    this->jBYTazBPUPAWltL(true, string("dkwydvpeobAnWCeEfjLXJgSJXsXyCVNZdtyiWlkZXCWKrijXwlmDXvBwlzpzxoGNIVUnXgeXnvgirXyZJghcTkHSGEGcLAftyjYqHwTJUEpSjAkCmWQPKPiJwyGSiIuUSJSXkczCXUPWtvKoowudDPTPmRTdXWDpMgzXbKOsdJCtiPryXaYpEWaLDlw"), -923049.454733299, 1552751803);
    this->yMJpvx(string("CsXjRafZdpSrNtrfIENuTAlugzOqvKUAxgkbVA"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BRidsLkaRE
{
public:
    double moqRp;
    double kyafyWXiSSclW;
    double IXFAEIaBCiu;
    double bXnocrZLFhb;
    double ZzVKpqSziMeD;

    BRidsLkaRE();
    double YLqtbuOQPwaYgLW(double BmwUQTuIzyvO);
    void JYwDaVaoGmLQZxi();
    double DYgSC(int FEHFaZsEw);
    string fzFCcFsLWGwDWFOU(string JyMttkfpBWyu, string MRZnWqmfcyEHU, int hfslQbBifAEOPvN);
protected:
    int uXRmQw;

    string vxMHd(bool CQrHkHJxLyplHcX, double QlexCuYc, bool LKBBAspmiaRkheu);
    string jRHJKiKgQZZn(string LuAPSQUnE, int KvMQpSJuLFGyN, string cfOImctfrGPEfNJ, bool sdPNOc, double sisGTFFHtKZWrR);
    double qrUSzbktqEQbxh(int IVgSXgeYVilV, int KqeVxyTr, bool qtYDe, bool SwqGkJKlQhhTNeD);
    int fezTpBgdIDcnwCRx();
private:
    int trOZfoiOr;
    double kxhYoXeFvnD;
    bool efDOcCPcCCOadxiM;
    bool ypiRaqgZhwDrO;
    string vWAkbdIgA;
    int kunRjPxT;

    void LbWEsmdmAr(double nGhEfLeK, double PFoPPAqzRcSk, bool AVSuAgA, int AtEcJ);
    string BWMEYmmzOUfY();
    string bQuzVbjPzXpFQTvr(int LJsuZLtKwBvzQMg, string efwyWANQI, int IJnCchLQ);
    double sywentLpexey(bool xmZiLhdVQBStUk, double uOPruKivxtclF);
    string ywohMem(bool qiKiHQqOxqc, string cblbGhaPUBoFJATH);
    int wJYYleNK(int FVsUGlLwz, bool eHZFKDlLTAB, bool dOdlPdWtaWvX);
};

double BRidsLkaRE::YLqtbuOQPwaYgLW(double BmwUQTuIzyvO)
{
    bool YRAmrNY = true;
    int hdDaNU = 1872710932;
    double zEshny = -291525.57580409566;
    string uHXhjLBfGPqbASmL = string("xLFvhjtdukHpENPYGgOJMRDNClDCBJrHwQlpTZGQMChpbnBNGMUJyBnGLhKuwURYnTOhJgsZfskXuvbsGfTfwGgjbPwAuaMAPZFMJulvMmrAFfDwQoLwkXVlRRrJuVpUrCBiwUfxmahxXVYWoWwAY");
    string hlClsguYDZgBN = string("omYVkyLAyrXClGlsuYPpDioDudtBBTtByjISdiEHXPRqLdaIjqznIRFeWMusGsjxxePjfQfcGyCOMCESZAidMOLdKfrUFyuxOzOEbBeujvcdoFZXWINPeeqEgkkdDExEwPVFUnGlasoYBednmWRQgFemcOKfzgQLcnWohXOCrdgjhnsvwALtdBjXmmVcHEBvSVfvGKgFTNhrMPVhUffMVcwHYwGPaaVQcqRwFzrzjDfnhI");

    if (BmwUQTuIzyvO <= -291525.57580409566) {
        for (int TNnLUwpsYOYQPt = 155203524; TNnLUwpsYOYQPt > 0; TNnLUwpsYOYQPt--) {
            continue;
        }
    }

    for (int qvinJhIXgeTR = 1529488060; qvinJhIXgeTR > 0; qvinJhIXgeTR--) {
        continue;
    }

    if (zEshny < 397688.0457737599) {
        for (int tCptx = 2090194227; tCptx > 0; tCptx--) {
            YRAmrNY = YRAmrNY;
        }
    }

    return zEshny;
}

void BRidsLkaRE::JYwDaVaoGmLQZxi()
{
    bool fLzuASzAjYiDrO = true;
    double FjBwfJVyBjgON = 227311.68172785774;
    int nxnmlAdiahXdZB = 1001559719;
    string tZxzfNNfoCD = string("NAWIQibBdeeEDIWdNlVmvdwDJRmdlcbhMNZrhKMFlzQtCxKDouqLJQCrfvETzugjSBuyZsSMbSdzYwsJbcVBWHwrcHhhElyCnNpwpCoeBXqPSPMsNoDTnvKBRdFRfPz");
    bool tUMHkWO = true;
    bool HZXLhLB = true;
    int yFtXuVEvzVW = 1683285647;
    string qzsMhBpC = string("SMLJxvnQiyyRdBEWkENfgTyeDMPSbYvGECRnVfLaweVKRsHf");
    double jnKIp = 736544.5219462602;

    if (nxnmlAdiahXdZB >= 1001559719) {
        for (int eNnNalfJCcIK = 980636301; eNnNalfJCcIK > 0; eNnNalfJCcIK--) {
            HZXLhLB = tUMHkWO;
        }
    }
}

double BRidsLkaRE::DYgSC(int FEHFaZsEw)
{
    int mnRbfmLzIznDc = -113822087;
    double EarPFoOIqdRkIBXD = -69618.76821952741;
    string VwRqoXfnjpVkIode = string("ZzvpRyjtnUswsbKngnatnYEgwRTDODhbgytxIZFaAPIcyHUrlwiROzDoBPwfngUBXpZLgvjPEEkSIxmWrHdslCYlvstFODbGXeVmnOwRKdLaFnqXUwQPbmSqvACCvBbPqkpCRUdPSpQHigWNMzDEZCQOggGHTFCHGjoBdjddKLVLHnEPcXLjVFQZdzcrTWIuFqPLgxTKlclMAgxiVVMPdWuUFqbDmdAhLgLysEiLnsVJxObPAGiY");
    string fHkTmaVhkjvOFEar = string("JYnsOPnQPdfecdUJsPoRijRhZfpOhyHrLsCaGSoukmqYzkzILCGqSWtaxVQNLcoSqzfuOQHuN");
    bool ztEHZcsqqAPBL = true;
    double VvAVwxS = -471097.9605004355;

    for (int mAHcikYEapOXEXm = 552914348; mAHcikYEapOXEXm > 0; mAHcikYEapOXEXm--) {
        continue;
    }

    for (int qbkUJD = 338908150; qbkUJD > 0; qbkUJD--) {
        EarPFoOIqdRkIBXD /= VvAVwxS;
    }

    for (int NZLsMcR = 784022006; NZLsMcR > 0; NZLsMcR--) {
        VvAVwxS -= EarPFoOIqdRkIBXD;
        VvAVwxS -= EarPFoOIqdRkIBXD;
        fHkTmaVhkjvOFEar += fHkTmaVhkjvOFEar;
        VvAVwxS = VvAVwxS;
    }

    for (int ABywKfiuS = 251281058; ABywKfiuS > 0; ABywKfiuS--) {
        continue;
    }

    return VvAVwxS;
}

string BRidsLkaRE::fzFCcFsLWGwDWFOU(string JyMttkfpBWyu, string MRZnWqmfcyEHU, int hfslQbBifAEOPvN)
{
    string rpupfJoVRgREk = string("RXNjTXIXlQasQPkMGYJUWexfdxoDGMtAeKyKknjdxcabGRVVTwDDgJLuVHDfTfgBdTkjyLNepBqJcmYgOokXYeroRRKEFkigtXKFNwkaHrjISqFYDMvRkqVEPsMGKBHESxvgfnklDWjFnKIfAQgOqvpEiuDdzXPnHSLcTIZ");
    bool sNEZBfnx = true;
    int bBJux = 1041268016;
    bool uBTqBjnVHdebS = true;

    if (bBJux <= 1041268016) {
        for (int gZserCpwiHhSGef = 1634601450; gZserCpwiHhSGef > 0; gZserCpwiHhSGef--) {
            rpupfJoVRgREk = JyMttkfpBWyu;
        }
    }

    for (int AXxoVyphguGDrcN = 1560496286; AXxoVyphguGDrcN > 0; AXxoVyphguGDrcN--) {
        continue;
    }

    for (int ZRVlC = 843675230; ZRVlC > 0; ZRVlC--) {
        MRZnWqmfcyEHU = JyMttkfpBWyu;
    }

    for (int WFCoMoKraWMQWz = 1702692130; WFCoMoKraWMQWz > 0; WFCoMoKraWMQWz--) {
        JyMttkfpBWyu = JyMttkfpBWyu;
    }

    return rpupfJoVRgREk;
}

string BRidsLkaRE::vxMHd(bool CQrHkHJxLyplHcX, double QlexCuYc, bool LKBBAspmiaRkheu)
{
    int nsFgiaWymdf = -875371310;
    string WDANrPKkBEQ = string("IPTSBK");
    bool gIJPi = false;
    double uJdIFrzoWzcYg = -384987.1186381522;
    int mCIjVwAGNVLWie = -1617899160;
    string qorQENUulMlQ = string("CDnRqwXGGkgYXLPbfaartnRViDIRovYsFuQYdGbFhAkgpgiacwHqjlJGrVkwPlpfBQCSInCeFkSBytzxaRjscRsagEvHKduMKXtGnaEOFSMKXDourCsKDUKqONQNYPYETVbnmiHfYoneOfkyJDdKyfpDfMpHRwEQcBrEoEgSanWDCHwPxZqjzpvb");
    double dHpmXFK = -336232.78945523646;
    string nLsejRqMCYcgtjo = string("CJlQFAVflDzTQVfoAoGujLDlucqEcNyaoWmwkKBiudNSxAHyVZioPYfpEZiKowoOsdUcwOBYUOIAtpuas");

    if (CQrHkHJxLyplHcX == true) {
        for (int ELCyA = 1067897114; ELCyA > 0; ELCyA--) {
            gIJPi = ! LKBBAspmiaRkheu;
        }
    }

    for (int JhMDAX = 903697674; JhMDAX > 0; JhMDAX--) {
        gIJPi = ! LKBBAspmiaRkheu;
    }

    for (int zsOlvPmGCZz = 106902825; zsOlvPmGCZz > 0; zsOlvPmGCZz--) {
        gIJPi = CQrHkHJxLyplHcX;
        WDANrPKkBEQ += WDANrPKkBEQ;
    }

    for (int kPAaZUTH = 67403577; kPAaZUTH > 0; kPAaZUTH--) {
        LKBBAspmiaRkheu = ! LKBBAspmiaRkheu;
    }

    return nLsejRqMCYcgtjo;
}

string BRidsLkaRE::jRHJKiKgQZZn(string LuAPSQUnE, int KvMQpSJuLFGyN, string cfOImctfrGPEfNJ, bool sdPNOc, double sisGTFFHtKZWrR)
{
    bool rICCCbqcd = false;
    double ZKQySdcosDqlcgg = 396377.8981922638;
    double BmGNXfZlXtiSbDAA = 440664.7148430128;
    string NMMwFghuQVK = string("PNIkHurXHFXccXYGGidKDcKPCjGcphpnwVMhrVvirOAEmHBDrujylwWmUQoKveKDaSfwoBlwCGGvuVfjCtdcHBtExtbciilxsdYhLZgHMXlixyLCMxAqyeLEOIfDDMqlwcAsNPEnfFXAVGNjdZNLxJxfhNDUntBNiydzUvAsOCASkAhZMMe");
    bool MQoeMxKpKFLQAM = false;
    bool OtPMKSmWmeaFqOAr = false;
    double ksEYNoOAzF = 128226.01552644256;
    int hcAQEAh = -2001659690;
    bool cIAVlDY = false;

    if (NMMwFghuQVK == string("FHAWIEfKyLWWrDxKmDljKahVMHWXuwTBuGunxjqtOhFXqTGL")) {
        for (int rDxXhUQFZbVJRNa = 757967565; rDxXhUQFZbVJRNa > 0; rDxXhUQFZbVJRNa--) {
            KvMQpSJuLFGyN /= hcAQEAh;
        }
    }

    if (sisGTFFHtKZWrR != 396377.8981922638) {
        for (int eFukuoohYEpFHYoc = 994276372; eFukuoohYEpFHYoc > 0; eFukuoohYEpFHYoc--) {
            continue;
        }
    }

    for (int LoUOaKxdVsJQN = 1851602238; LoUOaKxdVsJQN > 0; LoUOaKxdVsJQN--) {
        continue;
    }

    return NMMwFghuQVK;
}

double BRidsLkaRE::qrUSzbktqEQbxh(int IVgSXgeYVilV, int KqeVxyTr, bool qtYDe, bool SwqGkJKlQhhTNeD)
{
    int txhhczjrjy = -814233536;
    bool pwcGLvhgWb = true;
    double LBUFbSNKMNaKzpJ = -249437.9596346459;
    bool CINwFejSocWNSi = false;
    bool xeqWaVJhaVazXh = true;
    string hSanCEDdlb = string("vXcDAaMhwtDSoZmVtgyXbYA");
    bool EdNJjgSzi = false;
    int rmqLhA = -2018078538;
    int UdclqoccGbSSUnpH = -542203173;

    for (int myLbv = 1284428416; myLbv > 0; myLbv--) {
        rmqLhA -= IVgSXgeYVilV;
    }

    for (int DAmqYmATwDWNdB = 509697006; DAmqYmATwDWNdB > 0; DAmqYmATwDWNdB--) {
        continue;
    }

    return LBUFbSNKMNaKzpJ;
}

int BRidsLkaRE::fezTpBgdIDcnwCRx()
{
    double LdlPkEaIBjXy = 32820.98046033949;
    bool yyxTMkoSRVyo = false;
    bool OQvTKgBu = true;
    string VhNardzgTIAYh = string("ZZrmjssDvCElijgkXiBmNzkPsPeTRIPRxgZjAozhWDZwWYyusetteKjRvjvTiQqLqUYMznoHWvoraSneGDXXPidiORScKHCknyoRxYOkiEKcZNzkEeexiKnGdNIOxlIVqNEZdGnDFeBdePJFXgEsOJHhqRexOVaqgisHMmbUuaXaseSqNwlnqVXgRWdwioaWsBwMrwguxwX");
    double EQjUzEsZ = 730304.1946156317;

    if (OQvTKgBu == true) {
        for (int vtFWzm = 1251484176; vtFWzm > 0; vtFWzm--) {
            OQvTKgBu = ! OQvTKgBu;
        }
    }

    if (EQjUzEsZ >= 730304.1946156317) {
        for (int mxkul = 1003281852; mxkul > 0; mxkul--) {
            LdlPkEaIBjXy += LdlPkEaIBjXy;
            OQvTKgBu = yyxTMkoSRVyo;
            yyxTMkoSRVyo = ! OQvTKgBu;
            EQjUzEsZ /= EQjUzEsZ;
            EQjUzEsZ *= LdlPkEaIBjXy;
            yyxTMkoSRVyo = ! OQvTKgBu;
        }
    }

    return 2072502782;
}

void BRidsLkaRE::LbWEsmdmAr(double nGhEfLeK, double PFoPPAqzRcSk, bool AVSuAgA, int AtEcJ)
{
    bool SyEYDF = true;
    string BLvNFhscE = string("zTaBpBevpLfPufFvgbovDlUWdeDuhhOMKeYLnZtITLmUKYZMZirXjsBuRymKXymPMKyGiZIBWWjrScpeWRzAYQkVYylaOibjJjcbMjeJRuJLvvfxnwjKWDChhUxLAZqvCFscNueSxIFuVmcffZwNozAyWvIs");
    bool aWzTnE = true;
    int kQDXqTZKqxXX = -2040300146;
    double DcAfgmNXVWv = 644129.9095299873;
    bool XUnpogY = true;
    int CmZuTfo = 601271777;
    string OPOog = string("GNAtuohfG");

    for (int UmODfGbPDwIN = 521358954; UmODfGbPDwIN > 0; UmODfGbPDwIN--) {
        AtEcJ += kQDXqTZKqxXX;
        kQDXqTZKqxXX /= AtEcJ;
        AVSuAgA = AVSuAgA;
    }

    if (AtEcJ == 601271777) {
        for (int MIPUBq = 253271345; MIPUBq > 0; MIPUBq--) {
            OPOog += BLvNFhscE;
            nGhEfLeK /= nGhEfLeK;
            nGhEfLeK += DcAfgmNXVWv;
        }
    }

    if (DcAfgmNXVWv < 644129.9095299873) {
        for (int lmEwrBy = 1161344648; lmEwrBy > 0; lmEwrBy--) {
            AVSuAgA = AVSuAgA;
        }
    }

    if (PFoPPAqzRcSk > 644129.9095299873) {
        for (int zHNuMZqhx = 1186850671; zHNuMZqhx > 0; zHNuMZqhx--) {
            continue;
        }
    }
}

string BRidsLkaRE::BWMEYmmzOUfY()
{
    double niYUbBkY = 698564.39051795;
    string dJIUjEbivDpVmz = string("DBSnrQuqNXqEHDbVsScbfbWlvpAhHjQcGBAKOuqtgKxjLhjiTvyTshJeVmbjCYNAcxVAoXojCPfqAwtkEmSRiwAynpYGattHHwJTiFEzrOPmPVzaqjjDLVmZEwYvsjaHqZmBVzSBpNDrAyxKm");
    string mgyJe = string("NflcnatnTGmIFIRytoctfgwZqUbDwBpNYzorQEUnLLHbPBTAjgsmEHEhucKoEnSQFUyZEYSxfsummCtvJHiDcsePKxprPYgFbmRZpTxyJjSouuxBMiUgXtlhbrzZFWXRoMdZaYIbCvFHFQAEazjYvGVvGvj");
    double aLHiDArmUTLBiKxS = -731425.2194940738;
    int BfjOZLVLnwkmQL = -691307905;

    if (mgyJe > string("DBSnrQuqNXqEHDbVsScbfbWlvpAhHjQcGBAKOuqtgKxjLhjiTvyTshJeVmbjCYNAcxVAoXojCPfqAwtkEmSRiwAynpYGattHHwJTiFEzrOPmPVzaqjjDLVmZEwYvsjaHqZmBVzSBpNDrAyxKm")) {
        for (int cOoCmDjZxWs = 831178383; cOoCmDjZxWs > 0; cOoCmDjZxWs--) {
            BfjOZLVLnwkmQL += BfjOZLVLnwkmQL;
            BfjOZLVLnwkmQL *= BfjOZLVLnwkmQL;
            niYUbBkY += niYUbBkY;
            mgyJe = dJIUjEbivDpVmz;
            BfjOZLVLnwkmQL -= BfjOZLVLnwkmQL;
        }
    }

    return mgyJe;
}

string BRidsLkaRE::bQuzVbjPzXpFQTvr(int LJsuZLtKwBvzQMg, string efwyWANQI, int IJnCchLQ)
{
    int LCZBSteEBBzL = 264379450;
    double fXppNoe = -840329.9594055708;
    bool vKYTBaBix = true;
    bool wrwGkg = false;
    string vMHGdXrYSaTlupw = string("QqacdlhLnnsEaJSJayESJWabmoNClWtMokzWwMgdjdFuKPRdLgtSWkxbysWSYVBMkSNzz");
    string KLvHnkWLr = string("RlBPqaVuWdLuXkMClRpoZrUkHlQVlUOHTTKTKtLhrzxitDNwEDhFeWudvTvaqsSSwXcfnVAtQGslFPwXmmqgGIPlXDgFqLckarmRXQKiTeENshxISxItxnmBbtbKozDJnaQgKdtnUoFjYJvQDAGoxpKELlBTjbWMqmjTBsGfjmWFjltZOUVMTfIwRhRfOFYiBoajxolWvlCFqhTlO");
    bool nWJLAlLi = true;
    double VkiOEZAeNdtM = -925081.0910888368;
    double wDNvvauDa = -489822.97145094967;
    bool pjDzlW = false;

    for (int JfqrpxIAMpKY = 1213233395; JfqrpxIAMpKY > 0; JfqrpxIAMpKY--) {
        vMHGdXrYSaTlupw = efwyWANQI;
    }

    for (int dhpVudaP = 1759061807; dhpVudaP > 0; dhpVudaP--) {
        vMHGdXrYSaTlupw = KLvHnkWLr;
        pjDzlW = vKYTBaBix;
    }

    for (int VKweCtfsEUTCYi = 2026056646; VKweCtfsEUTCYi > 0; VKweCtfsEUTCYi--) {
        nWJLAlLi = nWJLAlLi;
        KLvHnkWLr += KLvHnkWLr;
    }

    return KLvHnkWLr;
}

double BRidsLkaRE::sywentLpexey(bool xmZiLhdVQBStUk, double uOPruKivxtclF)
{
    string ZKnFiqNbgPLgR = string("RVsqwYhyvikRttbeTlXYfprVxbCtUWTICQqfwVbOSnAgDxYOvHuRyrtQrdVZXxJHpJIanZhRzUeJYjJKDeURDKebhTnBcBKFERNLVJttoWSxorjZnawUONWuFjZXnjKPGIqwFaygfaqUDRLTPBJJQaCOPJwdhvBllfLZGDOADkrBvzQvMv");
    double BIhIuzQFR = 367767.6287826783;
    double mwyUmaigOBlbdV = -105085.29375278667;
    double ZRmZscAAyf = -775138.7909991896;
    double aHSyuLECXHQIEFYR = 548137.1859234233;
    double opQXTuijD = 605397.8023001314;
    int NyzHVwzdXJSXJUK = -155775492;
    string bLqBNQjyBfhPsP = string("mPbgxxTiVRlvxjEARTzvajuLnkmHNUtcJkpPZXYCTfEODnYWNwTZYfrNKmXbBruZgMgAIksjGLAXTfmypTYwwjSOjEJuwQqjgUcWhcjrdRXlAJJjUTPFDoVcnrrFCXakWFoMhdrtHlogJdODiPIGwufULDGuvbCfonMKOmxWzbLtzLXPbNxmcBHrmmwVnXcgXGcFZBxBFAPzwjAaiYpKUBMlAvoPqTgoTVXImKlqfdisp");

    return opQXTuijD;
}

string BRidsLkaRE::ywohMem(bool qiKiHQqOxqc, string cblbGhaPUBoFJATH)
{
    bool AvbqBpBNeofYBXc = false;
    bool IrlLLCWdu = false;
    string NIfPJOwvHvTBp = string("xeRrcmbJPdVvGucMMVDmZVcfXySqqrsCoBFJXXyqOFwsTfsX");
    bool tFyniLgAxIkTD = false;

    if (qiKiHQqOxqc == true) {
        for (int FxpdUAsAGLHi = 1642203686; FxpdUAsAGLHi > 0; FxpdUAsAGLHi--) {
            tFyniLgAxIkTD = ! tFyniLgAxIkTD;
            qiKiHQqOxqc = AvbqBpBNeofYBXc;
            IrlLLCWdu = qiKiHQqOxqc;
            AvbqBpBNeofYBXc = tFyniLgAxIkTD;
        }
    }

    return NIfPJOwvHvTBp;
}

int BRidsLkaRE::wJYYleNK(int FVsUGlLwz, bool eHZFKDlLTAB, bool dOdlPdWtaWvX)
{
    double XmWBqRlJVA = 842321.8415580363;
    string UEylrZFbXBw = string("AVQLXbfDVPWALDyhyIKrESSoYqYRbHJdQYHLWpnsNffpspbknTNDUzTrIkGvBMzkyStfCLkQLVFeJoBbcTEDrRenhFHfKDNLVwLrNWhtGCTIrBlArNjELcSPbKCHKQPVEOwvEwWcEFpNEAkMqsfqFXiiaWYPyERUvxClFdjnaldxapMGxvSumfAeolCNMiMYpaXfAglmKLSFntFyOfTQwRJVdRYpuVvjtd");
    bool uQYPbvpvcYPLdZ = true;
    int CjPuYgQ = 34847336;
    int wJqSLxmBmuDhb = 197313921;
    double odfWSQr = 145952.23512340218;
    int jeWEGPCsniWUoP = -2003839840;

    if (CjPuYgQ >= -2003839840) {
        for (int vZwBbrWxQd = 1029846317; vZwBbrWxQd > 0; vZwBbrWxQd--) {
            FVsUGlLwz -= CjPuYgQ;
            eHZFKDlLTAB = dOdlPdWtaWvX;
            XmWBqRlJVA = XmWBqRlJVA;
        }
    }

    for (int cZyqaWEaAOAj = 605398978; cZyqaWEaAOAj > 0; cZyqaWEaAOAj--) {
        continue;
    }

    for (int pnCiCIMnK = 1613075325; pnCiCIMnK > 0; pnCiCIMnK--) {
        jeWEGPCsniWUoP = wJqSLxmBmuDhb;
        odfWSQr += XmWBqRlJVA;
    }

    for (int fLVztadD = 470540916; fLVztadD > 0; fLVztadD--) {
        continue;
    }

    for (int TTYEcBVUDet = 1130132248; TTYEcBVUDet > 0; TTYEcBVUDet--) {
        continue;
    }

    if (uQYPbvpvcYPLdZ != true) {
        for (int zIMGkhj = 1737971557; zIMGkhj > 0; zIMGkhj--) {
            wJqSLxmBmuDhb /= FVsUGlLwz;
        }
    }

    return jeWEGPCsniWUoP;
}

BRidsLkaRE::BRidsLkaRE()
{
    this->YLqtbuOQPwaYgLW(397688.0457737599);
    this->JYwDaVaoGmLQZxi();
    this->DYgSC(1533831170);
    this->fzFCcFsLWGwDWFOU(string("SZkpocdRSblXQPomJzLvcloxNubVHVykdFcJeXmGbNvuYxCsjUftruATCbuunTZDOuiiDzXZKyceaWdvdxzrebeXSqEZaHGXslYmLMjeJBWEUKulfEQPAcTZkSKbqUsEmuHYsXBzmGfIHmZptNLnEsudGhaQKTqCGvTwNOEpiAwPltbWTeShgKnWnAZvUwhjrsiGacTQszKCVgEeXlYiTWuURUrUuVJSJkdMMhJXXqb"), string("rqIRlsdFElzbrgdonBjVAxPqzBtEpfwufrGrlgJoDVThryAaVEaiomvZoTCbXxkitPjLlxfmSsdWfdqsSalKpabAsAmuNSmNMEhazEXxlNCqUugTOHlHWBnsSezPTMMXKaHpZdHAnuKKxMwrmMmjcApkjxYywLGjMKUFgrrrdiNpxINuibYmbZqPlOTIKWroLrCtJRktytwGJFsfuWKXMZEwNYLWEkyijHFFtXXYWmBH"), 1819410814);
    this->vxMHd(true, 212127.2013776828, true);
    this->jRHJKiKgQZZn(string("tZtMVxbSlYPMiEZWkJIBYfWZQpyICwNRlXQNZQOesFYOqOOAqlXzMSBDsQjSExPlsfukrjRWXKMuNtXdJCMnLkZaxXyKYPHeeeIQxRLGSdxDaLKOgdNkfnPQeJLmxrvCHPCtIpwSOsNRCPLLDslDkxhrdjIMIllKUkqSkmmfuZuycuequxhyLMvxWUfpbMXnefjPiOpkIUtmcrhoDuOiTZqAShNUkiBzz"), 1644005143, string("FHAWIEfKyLWWrDxKmDljKahVMHWXuwTBuGunxjqtOhFXqTGL"), false, -785113.5613538937);
    this->qrUSzbktqEQbxh(1817204561, -42575155, false, false);
    this->fezTpBgdIDcnwCRx();
    this->LbWEsmdmAr(-282665.1763579676, 398197.36923472775, false, -934119552);
    this->BWMEYmmzOUfY();
    this->bQuzVbjPzXpFQTvr(654811332, string("mBRKyHTvItpCoIdDOkCXUDYj"), 807864733);
    this->sywentLpexey(true, 902312.4098776503);
    this->ywohMem(true, string("yAyoKeaPvQHyZstopaOXKtqRuKBMZbqmQQkPeEGVxFZbjEweYxKBMfzHprULtVTBMMTvvwjPHiaUwiWTCauwSeClgQmSBWRDrDyyhorclhtZKJzDSozTVBHBkMxTxxu"));
    this->wJYYleNK(1781518864, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tfZKMuFDtNbzPcu
{
public:
    string xdJia;

    tfZKMuFDtNbzPcu();
    bool gGbxxv(string NvGuiRVreVBKqgu, string HXqbExdozU, bool PTxRYFmKfJBGXT, double JMwElZcE, int NpSptbRlwbFE);
    string fVBMHuWLMw(string IVeFi, double OeNtfanEglWJuWS, int NvXcSCBbCmaDq);
    double xDQuiddgKQB(bool MIjiRKIr, double JttyufKJoDw, string rNhQPpjIaPwRPum, bool GtTyeSrqcFoxNp, int rOzqQOHHY);
protected:
    int AUnxcpXtMmc;
    string wIffsKpmiD;
    bool ULjTUl;
    string qPDik;

    void IZMQskTWydaIjnF(string sMWpfCpT);
    string tkOEbEb(double DnwctNzbBnaC, bool RGxhmn);
    bool jGCUNzKwgOV(int RVwQnhuQOlSICQ, double HCxges, string DPFEHNGUcgKzhM);
private:
    string RpGwHaHFQzJZc;
    double FDaCzRyYgBR;
    double Wlngx;
    double dqbnOSH;

    double yOyZjoEYJBdIbKZ(int ionvQ, int queBHjWyaIutaI);
    void hAmzRUTeHcAg(bool YmMWaFcdAMEWU, string CyFTnyEqwXSGXqT, int iHVBznJh, double JcHkYB, int toejk);
};

bool tfZKMuFDtNbzPcu::gGbxxv(string NvGuiRVreVBKqgu, string HXqbExdozU, bool PTxRYFmKfJBGXT, double JMwElZcE, int NpSptbRlwbFE)
{
    bool JFWPowkWvOdCH = false;
    int EezoxqKhSs = 1463638509;
    int YUIXxVhdfJWHR = 569248246;

    for (int VsYphy = 13652944; VsYphy > 0; VsYphy--) {
        HXqbExdozU += NvGuiRVreVBKqgu;
    }

    if (JFWPowkWvOdCH != false) {
        for (int dFptAdJBOIWb = 1302404299; dFptAdJBOIWb > 0; dFptAdJBOIWb--) {
            NpSptbRlwbFE *= YUIXxVhdfJWHR;
            EezoxqKhSs = EezoxqKhSs;
        }
    }

    for (int YlOaW = 1872260201; YlOaW > 0; YlOaW--) {
        YUIXxVhdfJWHR = EezoxqKhSs;
        YUIXxVhdfJWHR -= EezoxqKhSs;
    }

    return JFWPowkWvOdCH;
}

string tfZKMuFDtNbzPcu::fVBMHuWLMw(string IVeFi, double OeNtfanEglWJuWS, int NvXcSCBbCmaDq)
{
    double DMFjd = -711486.2056411828;
    bool UxlLf = true;
    bool AqkvdDzguX = false;
    bool TaswrZMQqs = true;

    for (int KXJgW = 1764494417; KXJgW > 0; KXJgW--) {
        TaswrZMQqs = ! TaswrZMQqs;
    }

    if (AqkvdDzguX != false) {
        for (int QGcVsLzRLAWvEB = 1927831064; QGcVsLzRLAWvEB > 0; QGcVsLzRLAWvEB--) {
            continue;
        }
    }

    for (int KdrjUkfZprZqyJ = 567358293; KdrjUkfZprZqyJ > 0; KdrjUkfZprZqyJ--) {
        continue;
    }

    for (int oRLkfsDIwmC = 1685901146; oRLkfsDIwmC > 0; oRLkfsDIwmC--) {
        continue;
    }

    if (NvXcSCBbCmaDq <= 1624897369) {
        for (int fKzxlm = 1208819702; fKzxlm > 0; fKzxlm--) {
            DMFjd /= DMFjd;
            DMFjd -= OeNtfanEglWJuWS;
        }
    }

    return IVeFi;
}

double tfZKMuFDtNbzPcu::xDQuiddgKQB(bool MIjiRKIr, double JttyufKJoDw, string rNhQPpjIaPwRPum, bool GtTyeSrqcFoxNp, int rOzqQOHHY)
{
    bool MUeexEP = false;

    for (int gHMnmbof = 627064206; gHMnmbof > 0; gHMnmbof--) {
        continue;
    }

    for (int YTwSzoeAHdpISU = 1012003435; YTwSzoeAHdpISU > 0; YTwSzoeAHdpISU--) {
        continue;
    }

    return JttyufKJoDw;
}

void tfZKMuFDtNbzPcu::IZMQskTWydaIjnF(string sMWpfCpT)
{
    int PPxJm = 289426829;
    bool RmeCdeR = false;
    int eLjBqJY = 1663292206;
    string RBpZtrgQ = string("uoClDmVUgGzZYPspmCEwuehiESxFIwZYnjzhCHwIDoHPgMRnFiAiTLdmpYoRXNhOYJrUNqPozRHDXkXOYVCYczCKuMdxYLiLuxiugYomklIeOSpIuIMfrcAMAGlXuOLkAeOYPizxKLyCcwRsbwkIJLlOAMVVkSAqLBMxmbrHrPkthvoplu");
    bool jQVCwOhkQ = true;
    bool qarIrlitToSlBO = true;
    int RgrUWGcPS = 563139563;
    int ftsFLUHqeu = -426526470;
    string HUoZQwXrrpQyjC = string("jEqrIVcatcxnCzImSedlthYEvKJSHOIsuIhc");
    bool TMKtWnMKz = false;

    for (int mkrjUgCARci = 1525298178; mkrjUgCARci > 0; mkrjUgCARci--) {
        HUoZQwXrrpQyjC += sMWpfCpT;
        RBpZtrgQ += sMWpfCpT;
        ftsFLUHqeu -= ftsFLUHqeu;
    }

    for (int mOiBEs = 41384320; mOiBEs > 0; mOiBEs--) {
        RBpZtrgQ = HUoZQwXrrpQyjC;
    }

    for (int oycSGbnHD = 471060997; oycSGbnHD > 0; oycSGbnHD--) {
        RgrUWGcPS += PPxJm;
    }
}

string tfZKMuFDtNbzPcu::tkOEbEb(double DnwctNzbBnaC, bool RGxhmn)
{
    bool kKSwLjQQFMYsR = false;
    string gpkrSAkxNDQC = string("KwIIZLzvEyziRKryegZMhrMvoWAMSuSedhnZijRXNuUqdTzdiPzveABxJYmplvKAOwNsJCwQlsiDfMWwsRdwtTiXGjdKlWoBtXlnnEXGPYgQygyEzahWiSTSxCgsaPtEbdXYPMsrOvjhEJOcaSCJsEpOREtpUWdTXgzCuELThvUMISZJToUwZRSGodKttJiJAzkyrQxdqNjymwhrNegaJOJSHMZVIbFJHGqolnIdTs");
    double yDKcwQXV = -72647.60035603239;
    double VdcceapwnIxCCgG = 383739.5097770412;

    for (int ctmsj = 2100669329; ctmsj > 0; ctmsj--) {
        continue;
    }

    for (int hSvZMzLEFZeS = 1560655609; hSvZMzLEFZeS > 0; hSvZMzLEFZeS--) {
        RGxhmn = RGxhmn;
        yDKcwQXV *= DnwctNzbBnaC;
        kKSwLjQQFMYsR = kKSwLjQQFMYsR;
        gpkrSAkxNDQC = gpkrSAkxNDQC;
    }

    if (gpkrSAkxNDQC == string("KwIIZLzvEyziRKryegZMhrMvoWAMSuSedhnZijRXNuUqdTzdiPzveABxJYmplvKAOwNsJCwQlsiDfMWwsRdwtTiXGjdKlWoBtXlnnEXGPYgQygyEzahWiSTSxCgsaPtEbdXYPMsrOvjhEJOcaSCJsEpOREtpUWdTXgzCuELThvUMISZJToUwZRSGodKttJiJAzkyrQxdqNjymwhrNegaJOJSHMZVIbFJHGqolnIdTs")) {
        for (int xbaVyBjwKbHhIFr = 1893602088; xbaVyBjwKbHhIFr > 0; xbaVyBjwKbHhIFr--) {
            DnwctNzbBnaC += VdcceapwnIxCCgG;
        }
    }

    return gpkrSAkxNDQC;
}

bool tfZKMuFDtNbzPcu::jGCUNzKwgOV(int RVwQnhuQOlSICQ, double HCxges, string DPFEHNGUcgKzhM)
{
    bool ekZUXhYwf = false;
    bool DHApZJFh = false;
    string goCzXqPeMFTU = string("nErKoOvkhkyiRx");
    bool SvgOceeGOjXWiU = true;
    double cIQujU = 798471.1615621641;
    string PjzauOm = string("TqdVuQExrglOVipuKZPKBZMUIWoZSCGAvMYMtccdFhYltiwRCpDeOkmTpYUGyHPXLJFONVoAqeRpLOIFzbNbAhENMChLmWygrbbiciHZCGKWyzOxowtbEBBpCTeWvwUZtFYWDJWLbxAamjAYQZakstmQOECugUZwzAJBkoFCRQYzarlhQR");
    bool XqVxzBjk = false;
    string dFoptZVMkVKFPvoC = string("jFprqbxDbpJQqVCnzREISpcIwCAfzjxMVPAIdPykYXTWrywiQTzVjqAwFAjTCdRKTjeZbhXthqqCIaWabPkCAlLepbODRJPvldoIHMGxSbVwFHEuJefmvBTjFmTisOmklMUbKXzmzAKPPyZUFozRiKwFSSADaKmMCV");
    int tVrve = 356562070;

    for (int RhDSVftkkEeG = 396766837; RhDSVftkkEeG > 0; RhDSVftkkEeG--) {
        continue;
    }

    for (int qCswDON = 1298205786; qCswDON > 0; qCswDON--) {
        PjzauOm += PjzauOm;
        dFoptZVMkVKFPvoC = dFoptZVMkVKFPvoC;
        SvgOceeGOjXWiU = XqVxzBjk;
        cIQujU /= cIQujU;
    }

    for (int rtuark = 111990597; rtuark > 0; rtuark--) {
        goCzXqPeMFTU = dFoptZVMkVKFPvoC;
        DHApZJFh = ! DHApZJFh;
    }

    for (int lxqAZOSkx = 1589404895; lxqAZOSkx > 0; lxqAZOSkx--) {
        DPFEHNGUcgKzhM = dFoptZVMkVKFPvoC;
    }

    return XqVxzBjk;
}

double tfZKMuFDtNbzPcu::yOyZjoEYJBdIbKZ(int ionvQ, int queBHjWyaIutaI)
{
    string lsNBeoIVoBhFcmk = string("SRiTkktHypsdKfgamFDZAmrtmOUctVHZVDKZsZUjvrCquCvYCzWsPnSrigFrBhkezXYGluY");
    bool PqmKHjDpxNhcJb = false;
    double XmzxEx = -233694.14538757235;
    string oRQWSAxefDAwD = string("vioiNrygYwzjCHNlGvsIKpreoEfhHDPnDybQyuIqBPwFsDweFLTJjVXdIjLKKfyCgPNOouNjJDfstCCkiUZXPFnfJKnd");
    int QAmJXBdmKaI = 1340545157;

    for (int DPmQiDunazAOqK = 2032098604; DPmQiDunazAOqK > 0; DPmQiDunazAOqK--) {
        lsNBeoIVoBhFcmk = lsNBeoIVoBhFcmk;
        QAmJXBdmKaI /= QAmJXBdmKaI;
    }

    for (int gbGsIIpmoYKvmQp = 1649086757; gbGsIIpmoYKvmQp > 0; gbGsIIpmoYKvmQp--) {
        continue;
    }

    return XmzxEx;
}

void tfZKMuFDtNbzPcu::hAmzRUTeHcAg(bool YmMWaFcdAMEWU, string CyFTnyEqwXSGXqT, int iHVBznJh, double JcHkYB, int toejk)
{
    double hKpdScJWwF = 520970.29375286924;

    for (int DRtQIoDzpWTyXCl = 1978010241; DRtQIoDzpWTyXCl > 0; DRtQIoDzpWTyXCl--) {
        iHVBznJh /= iHVBznJh;
    }

    if (JcHkYB != 520970.29375286924) {
        for (int aoCdmvO = 696944404; aoCdmvO > 0; aoCdmvO--) {
            hKpdScJWwF /= JcHkYB;
        }
    }
}

tfZKMuFDtNbzPcu::tfZKMuFDtNbzPcu()
{
    this->gGbxxv(string("mnwIVqekOKOEVklzmfhwAHJraExsXIXrJPPErQGRurxutRaNVBuPDvKDEgZONsnfuVKjxcNnupwIeKroZGbBzvBAwwYUBHEZyIMfubtGVqcPgwacTMxLNHUAeQWOVArEzk"), string("fYlIuvmqNvdeQUZWwVLDr"), true, -785954.0178088476, 1852057223);
    this->fVBMHuWLMw(string("RfIaDOZPkEWeCeFNOKyCrVcVSXiwvzrduuBdsGxKYnINtUldPbGBsvVZJBUbQOsboDXHAUGYCFrUFbzYdoDOVRWHNANktANOiuyUtCuYRwSloLAUAuArNmPxbjtGhDtHfCLPTvttxeSphTe"), -857452.8214917316, 1624897369);
    this->xDQuiddgKQB(true, -380689.3758768425, string("KjyXevStZosOfEAFRHZTOIVblaqMiWeBsMbQOAZvIWMMrsDcPupwnuZXRzFteco"), false, -549855399);
    this->IZMQskTWydaIjnF(string("UqfMfhGlrfLVhLXctibgmqmwfJAFeiyuUeaOoYqIKBvONaTSSoTqDLxVezfDDLLyMxLBIeMaNLqpSyXOqOOuvgeXKXlCecVTnOseiyPdoSBEzfCtZnYcBcpZRSBiCrbUfpsAxsXSyLNtuqUJQbdBFdlIzCrigQtUXZqkxvFtrbIAwIujOfZdZgaIyQHPrEkztXwyXUqDbsIKUxSievNFvxOMjEKMdBhjFCB"));
    this->tkOEbEb(-225782.82571417192, false);
    this->jGCUNzKwgOV(609360915, -213119.32473717313, string("uFSyviQsMFmlpgzBxWvIzHcarJjJtmKhoQtAOBpbMmfYUDPFrsLziMgnGDKzCipPEyxYXYfxfnDJLwFlliZLyLoRzO"));
    this->yOyZjoEYJBdIbKZ(191076283, -1142865090);
    this->hAmzRUTeHcAg(false, string("LTAzOvczVlgPMgtcsOqnchheBaRFrmDjLgKAIZlcvpxkzjUquTHMymOIcqwfIhZmrIZVFVcwJPqXBgoDGNWcbsIUiuhDVSMaMyNNqsPEerheOMbneWBQbfxMgrKtPMzIljBxG"), 1185275906, 112497.19303413658, -2041880154);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aKIcpNqvFEr
{
public:
    int dGfQvoILnNJpjC;
    double TcdrbsbowQzY;

    aKIcpNqvFEr();
    double WCFpzvJYdZa(bool hfQFherLonfeprv);
    double YQKcfLzoGY(string RqPvPGMyW, bool VQuCRPniaj, int aFDoE);
    double YRDauFxPEXs(string WIHghhtFewucebWW);
    string MwLMXfpuJbg(string scYlxDERaKmkAYXH, int AwXNKYwniyBSl, int SniXVWXLXq, int rXdlphMWZoZG, int ZHrVZvOmsRS);
    double NrjZXcBRkBaToxte(int QAVFo, string lfXrdcYyS);
    int wYuwoiBmCb(bool xMGTmfgVTRG, string YWJgZYdsJfprFjRY, int XAFJWr, string jvSWBrHZIa, bool ktfgNLwrxKVlWRLb);
    bool WRZaELYarZWZGnyh(int VmdTTpwfFUW, string SCSgQiYgt, bool ngzanDbbZvFPnJ, string nGjWGpmsUyUYdVBc);
protected:
    int xCeqyP;
    double fnOpNXcUK;

    string PghVI(string lJmivGPQ);
    string tXdQyLtBZbO(double eYkxiodangdAN, string uSSoxbNVFK, double nmiBGktYZLnTHcbQ, bool cRiIjEqWBBJAj, double fsRoH);
    bool EhSpP(double IydoME);
private:
    double OrklCf;
    string BATAQxQNhdpF;
    bool EZYaVpTCoc;
    string ZbWBMGlldCsBNu;
    bool rxMVyk;

    string VkmNkpz(string yJRHaTrkHemLrqh, string nAvOAYH, double ZiWzqEDydIWFUDx);
    bool uOmwDNIITgjmF();
    double tJeoRVLVzbS(int GhOomuRzZyt, int oETLybtaZpo, string gBNJlszOWLNe, bool nVhDMxsEMyQTb, int JUTIVb);
    string lUEvfhR(string MTkFssrGJ, string CPTYyNQFMn, int lLirk);
    void pqKnUKEfHyriHL(bool JCtrW, string SGvahEmorwgxlO, double NCujTeMkzKuPYA);
    int dpodrSoI(string YkDjtfg);
    string klZyMRSmSjK(bool QwSVCvspqzK);
};

double aKIcpNqvFEr::WCFpzvJYdZa(bool hfQFherLonfeprv)
{
    int vUPRxinCmkOPz = -1286065516;
    double xmSMFLpNIUT = -364004.12480293267;
    double AOSpUfSr = -492071.4308897462;
    bool HsAiVTU = false;
    string GkEDbRDwgDRm = string("yesIazalwBqjBQWYuWbNdRTxJYTjUxsEgpbmfeHZZbjEvLnlLpxMiTQIZkIMYHsXsvLyZBjmEFpmKjGbOUCARKOdOTtuYjDbKASFXQPXoHBVgIExETiLclFHIlGVjxWEluEweGGMsfIofmIYshJOzsmOrNcaTDNCcudwUlQirWRBmgpduvifwbkOZlsPIUfzusQhjhbCpazZrifIibYPklxPBBxeGAwJVPzwAiwAvGBlCwifCQrGCf");
    int gfcFTz = 611731423;
    double WGvTprKEqUJMbfQp = 337925.27845181094;
    bool tOKfyUiIx = true;
    int UdqsGSgzNCCy = 970539107;

    for (int qdAlE = 2015278482; qdAlE > 0; qdAlE--) {
        continue;
    }

    for (int dBwxRFqkOcO = 1990370117; dBwxRFqkOcO > 0; dBwxRFqkOcO--) {
        AOSpUfSr += xmSMFLpNIUT;
        tOKfyUiIx = HsAiVTU;
    }

    for (int bjRQiNm = 1778577514; bjRQiNm > 0; bjRQiNm--) {
        WGvTprKEqUJMbfQp /= AOSpUfSr;
        xmSMFLpNIUT /= xmSMFLpNIUT;
    }

    return WGvTprKEqUJMbfQp;
}

double aKIcpNqvFEr::YQKcfLzoGY(string RqPvPGMyW, bool VQuCRPniaj, int aFDoE)
{
    double ANegEWetz = -525894.3998753945;
    int EKQdusbXbcTGAFT = -1899748044;
    string vuotdjjljvRAyghD = string("QQZhLkluXEPpAkcWDbugsgveGBaxngQTusJytjfnnaeGsgnQnadyFOr");
    double tgyMYlSXGSrclct = -414890.14840276423;
    double rkdJWc = 176644.7428334238;
    bool tUwxJbLLWKRCkJo = false;
    double dDMFYHDQNlxDkI = 641936.1954248659;
    string cLgig = string("LpwvzhOVXSsNmbhoQECN");

    if (aFDoE <= 1543534740) {
        for (int IhNFKpTRnBJEvmRm = 602907410; IhNFKpTRnBJEvmRm > 0; IhNFKpTRnBJEvmRm--) {
            tUwxJbLLWKRCkJo = ! tUwxJbLLWKRCkJo;
            tgyMYlSXGSrclct *= tgyMYlSXGSrclct;
        }
    }

    return dDMFYHDQNlxDkI;
}

double aKIcpNqvFEr::YRDauFxPEXs(string WIHghhtFewucebWW)
{
    double WOtyiMZrTNyYWM = -970482.6394904136;
    double VHTBbTdxo = -1035909.0905015481;
    bool IPvCcIdAwBKn = true;
    int sZJGAFMgcAOCevq = -228126745;
    string AXoNs = string("tLDQvvGIlTrcDIYEArqjSSuXzpncJIBfaeTGelCdMSFgmiuKvbYiDEklZAFwNrTXyuoUwqAcYzBTelSVIiRCfPkvmMlptzfgvhZUraGlwWtDRjcnistBLMdKseMdZeaBYOJAgWYtTNCKTBZrgluWSPNubLrQBXEOJsCWiCSBjXEIJZjpRBQcEAKCMqxOlqHHNznkcaCXgOovcrFublLTCFOJYoBcyBiqSqnxmhVJgQQ");

    for (int VxrVvOoPiI = 2119489671; VxrVvOoPiI > 0; VxrVvOoPiI--) {
        VHTBbTdxo += WOtyiMZrTNyYWM;
    }

    for (int WoCwk = 1462725465; WoCwk > 0; WoCwk--) {
        VHTBbTdxo -= VHTBbTdxo;
    }

    for (int HKXmfDAGtkqB = 1699070645; HKXmfDAGtkqB > 0; HKXmfDAGtkqB--) {
        WOtyiMZrTNyYWM -= WOtyiMZrTNyYWM;
        WOtyiMZrTNyYWM *= WOtyiMZrTNyYWM;
    }

    for (int OFxEBmyXgJRcxrK = 907029940; OFxEBmyXgJRcxrK > 0; OFxEBmyXgJRcxrK--) {
        continue;
    }

    return VHTBbTdxo;
}

string aKIcpNqvFEr::MwLMXfpuJbg(string scYlxDERaKmkAYXH, int AwXNKYwniyBSl, int SniXVWXLXq, int rXdlphMWZoZG, int ZHrVZvOmsRS)
{
    bool rkjqroDyw = true;
    string RqxjzBcsVoLww = string("wWoQXpGBsBiPbTRmLXDUNUYmmZYTMbejhktfvSzOmYMuZOsEEKbXlAkQMAMCNctPkkgYKgjusMsqBQNlmdwPyIsVKEberolftecRYPDHiGnsbnxGVrjGngAiAXJuStPJxseNViVTFOzNLEmmldlWYgNGFMRFGcussMSaBNJTdYVxgqEouTUtJwVPDUmbhzDXQOntfhRAErpvJSAdXxdSVyIycM");
    string fzZAJCgEWt = string("hZPvtDkEMKztqhicRZirsxgKZiXanxETYgzVjQkvmJnsebndyoYQrGaXCxwexkIvOujeLhQNUgdsbptUQwodmeGaxCEaxURyRfkfaKcOOhGKslLaxAUGUaKZGzZsaUtmL");
    int eUDwqeDIfoK = -155517847;
    double iLcXObWXagvOD = 781744.885193439;

    for (int EKgfOKN = 563822029; EKgfOKN > 0; EKgfOKN--) {
        ZHrVZvOmsRS *= SniXVWXLXq;
    }

    if (SniXVWXLXq > -1153316115) {
        for (int RhChmvjSyq = 407398545; RhChmvjSyq > 0; RhChmvjSyq--) {
            SniXVWXLXq = SniXVWXLXq;
            ZHrVZvOmsRS /= ZHrVZvOmsRS;
        }
    }

    if (scYlxDERaKmkAYXH <= string("VfvQHNGTsDtYAEztDfbsVFsqEXRgSpHtlPxjMSBlWiNJoYgosweqscJTfxoWcVxTykJMkssDGmlmMwHKCGQImqSsaejZfTBEOhiWwnRZWoGBoDWfwfIeGSeuAJVVMyxpwTLUVSjnRxmDcgHPNADgHuNWZivE")) {
        for (int OrypqsRfH = 964020999; OrypqsRfH > 0; OrypqsRfH--) {
            AwXNKYwniyBSl *= SniXVWXLXq;
            AwXNKYwniyBSl = rXdlphMWZoZG;
            AwXNKYwniyBSl = rXdlphMWZoZG;
        }
    }

    if (RqxjzBcsVoLww > string("hZPvtDkEMKztqhicRZirsxgKZiXanxETYgzVjQkvmJnsebndyoYQrGaXCxwexkIvOujeLhQNUgdsbptUQwodmeGaxCEaxURyRfkfaKcOOhGKslLaxAUGUaKZGzZsaUtmL")) {
        for (int SxGvjLXaPUbqFk = 397847352; SxGvjLXaPUbqFk > 0; SxGvjLXaPUbqFk--) {
            ZHrVZvOmsRS -= SniXVWXLXq;
            ZHrVZvOmsRS *= SniXVWXLXq;
            fzZAJCgEWt = scYlxDERaKmkAYXH;
            scYlxDERaKmkAYXH += RqxjzBcsVoLww;
            eUDwqeDIfoK = rXdlphMWZoZG;
        }
    }

    for (int LCKiU = 139465205; LCKiU > 0; LCKiU--) {
        eUDwqeDIfoK += SniXVWXLXq;
        SniXVWXLXq /= AwXNKYwniyBSl;
        ZHrVZvOmsRS = ZHrVZvOmsRS;
        scYlxDERaKmkAYXH = fzZAJCgEWt;
        SniXVWXLXq += rXdlphMWZoZG;
    }

    return fzZAJCgEWt;
}

double aKIcpNqvFEr::NrjZXcBRkBaToxte(int QAVFo, string lfXrdcYyS)
{
    bool iukvRQzTgHIuWnm = true;
    int MrbgswhbRAYG = 298614370;
    double qNMMHhBSOhS = -1024521.7552948494;
    string oiWorJlLa = string("tGJvRRxYTcwqbIrioRzOGjPMVNzVGINiHEkWwfmafhEIPvFSCRrvVXdvXhHHWhpEBWrMrmSGAsUZdFFwWeOQTgwAHDpnyiDYxcZqKJGLqKtaMNBqLJGiJyebIbRIoQblLevxoYIpUnyzpDhbm");
    string CpZxHbnbQ = string("mmrcEcLa");
    int AuCpZ = 1085189143;
    bool FRAkRMflTABVyc = true;
    int cLtcLTzHd = 1688495718;
    double jvcNojNq = -906163.8430140055;
    string uDDPvWaauYaOk = string("PZfAyToSFtzlwqcLEOcdoXdzGFQDnPEptJhdLlQeYucKpYfvDqlKMeMdyjWXGZBSiHZxCbE");

    for (int rycIhOBt = 1792617207; rycIhOBt > 0; rycIhOBt--) {
        CpZxHbnbQ += CpZxHbnbQ;
        CpZxHbnbQ = uDDPvWaauYaOk;
    }

    if (AuCpZ <= 1085189143) {
        for (int dJQueEorz = 2083218160; dJQueEorz > 0; dJQueEorz--) {
            QAVFo = MrbgswhbRAYG;
            uDDPvWaauYaOk = oiWorJlLa;
        }
    }

    for (int vAWmDLRPDEKt = 1828108702; vAWmDLRPDEKt > 0; vAWmDLRPDEKt--) {
        AuCpZ += MrbgswhbRAYG;
        oiWorJlLa += CpZxHbnbQ;
        QAVFo += MrbgswhbRAYG;
    }

    return jvcNojNq;
}

int aKIcpNqvFEr::wYuwoiBmCb(bool xMGTmfgVTRG, string YWJgZYdsJfprFjRY, int XAFJWr, string jvSWBrHZIa, bool ktfgNLwrxKVlWRLb)
{
    double RHfCfVCcy = 677422.8319015654;
    string YXkSamvNu = string("dFZSFgHmXNcIRiU");
    double ASgBtshLvcDs = 170355.1798654297;
    double KsclGriJrKSdety = -909510.5168865385;
    int JGVvUltiB = -131816490;
    double UFdULu = 442034.42020410154;
    int WZSgerEtgG = 1027020475;
    bool cGkLGqDqWglbkTHq = true;

    for (int LEvHguFU = 2067913520; LEvHguFU > 0; LEvHguFU--) {
        XAFJWr /= XAFJWr;
        YWJgZYdsJfprFjRY = jvSWBrHZIa;
    }

    return WZSgerEtgG;
}

bool aKIcpNqvFEr::WRZaELYarZWZGnyh(int VmdTTpwfFUW, string SCSgQiYgt, bool ngzanDbbZvFPnJ, string nGjWGpmsUyUYdVBc)
{
    double taTXmQpJlIJZRvFb = -70294.14010920978;
    double aINRddbsb = 280291.1573248036;
    double dqOaYIofltLfxi = 231810.98984452104;

    for (int nYHLizz = 481258219; nYHLizz > 0; nYHLizz--) {
        taTXmQpJlIJZRvFb -= taTXmQpJlIJZRvFb;
        nGjWGpmsUyUYdVBc += SCSgQiYgt;
    }

    for (int VvEFdIttQfh = 239070080; VvEFdIttQfh > 0; VvEFdIttQfh--) {
        continue;
    }

    if (aINRddbsb > 280291.1573248036) {
        for (int OSBwq = 554727168; OSBwq > 0; OSBwq--) {
            dqOaYIofltLfxi /= aINRddbsb;
            SCSgQiYgt += nGjWGpmsUyUYdVBc;
        }
    }

    if (aINRddbsb < 280291.1573248036) {
        for (int SCJmlrzFkKCz = 593371056; SCJmlrzFkKCz > 0; SCJmlrzFkKCz--) {
            ngzanDbbZvFPnJ = ngzanDbbZvFPnJ;
        }
    }

    return ngzanDbbZvFPnJ;
}

string aKIcpNqvFEr::PghVI(string lJmivGPQ)
{
    bool uMDDsWvDpkAn = false;
    double QSQoAZakfDoZ = -424104.2114489583;

    if (uMDDsWvDpkAn == false) {
        for (int vnYrjjz = 1196660486; vnYrjjz > 0; vnYrjjz--) {
            QSQoAZakfDoZ = QSQoAZakfDoZ;
        }
    }

    return lJmivGPQ;
}

string aKIcpNqvFEr::tXdQyLtBZbO(double eYkxiodangdAN, string uSSoxbNVFK, double nmiBGktYZLnTHcbQ, bool cRiIjEqWBBJAj, double fsRoH)
{
    int aEZZRuQ = -1808275190;
    double YPHyTBQGwjmLRTjF = -762226.8230740508;
    double tHeQnKiPgNuX = 699681.0616656078;
    double RxNmlhlvUzxyG = 986211.5915627548;
    bool XqZVey = false;
    double CTnPUPooFwpqe = 500698.1303863086;
    int fbhLEz = 1662186038;
    string WBOFcdgiiZgsDuW = string("vFxtaOAypfEopHafeRBnbTSolofhdQrUHvmrUKiytdCMbpw");
    string EHGVbeGIWTSKpKr = string("QjWCbqvTyebLjYoBgZMgNaLxcQtAlLhsiJkECbtBjqxOvxyPgbKDFNYkMliywiLsTqKqmEIOdwSVjcuNZZmmmHBlJzNuuRhtgGSxACMbNkMtCMezLyTURDyH");

    if (tHeQnKiPgNuX != 668281.7263607429) {
        for (int uvafnJyllLXvuhX = 2069256013; uvafnJyllLXvuhX > 0; uvafnJyllLXvuhX--) {
            CTnPUPooFwpqe += tHeQnKiPgNuX;
        }
    }

    for (int svcVDETyyZhPt = 1769140235; svcVDETyyZhPt > 0; svcVDETyyZhPt--) {
        EHGVbeGIWTSKpKr = EHGVbeGIWTSKpKr;
    }

    for (int hvMMyX = 1942416318; hvMMyX > 0; hvMMyX--) {
        nmiBGktYZLnTHcbQ += nmiBGktYZLnTHcbQ;
        eYkxiodangdAN -= nmiBGktYZLnTHcbQ;
        XqZVey = ! XqZVey;
    }

    if (RxNmlhlvUzxyG > 500698.1303863086) {
        for (int qoUetScol = 1659766614; qoUetScol > 0; qoUetScol--) {
            cRiIjEqWBBJAj = ! XqZVey;
            nmiBGktYZLnTHcbQ *= nmiBGktYZLnTHcbQ;
            CTnPUPooFwpqe -= CTnPUPooFwpqe;
            eYkxiodangdAN /= CTnPUPooFwpqe;
        }
    }

    for (int dFGvFPTu = 914045059; dFGvFPTu > 0; dFGvFPTu--) {
        continue;
    }

    return EHGVbeGIWTSKpKr;
}

bool aKIcpNqvFEr::EhSpP(double IydoME)
{
    string SWXyJrB = string("bCMWIJzCaLCrSzglSzWNxAHFKNsJGyGssjJZaLPxXssKAspsbQjSnYloseZJceAdrVJSzxvDYkcMDubPaLJlRN");
    bool cAdOOJTbb = true;
    int JbYgkdKGeX = -833336701;
    int mOOhEW = -1783046193;
    double SXyEKAWmEYqWBD = 398563.3369203186;

    for (int YivOVhM = 2097338986; YivOVhM > 0; YivOVhM--) {
        cAdOOJTbb = cAdOOJTbb;
        SXyEKAWmEYqWBD += IydoME;
    }

    for (int DbMtWHxtVBsYMg = 1273886814; DbMtWHxtVBsYMg > 0; DbMtWHxtVBsYMg--) {
        SWXyJrB += SWXyJrB;
        JbYgkdKGeX *= mOOhEW;
        IydoME = SXyEKAWmEYqWBD;
    }

    for (int ShQgvKnGQGqrBEOV = 384714815; ShQgvKnGQGqrBEOV > 0; ShQgvKnGQGqrBEOV--) {
        IydoME += IydoME;
    }

    if (cAdOOJTbb != true) {
        for (int gZVUUdXeRk = 950299523; gZVUUdXeRk > 0; gZVUUdXeRk--) {
            SXyEKAWmEYqWBD *= IydoME;
            IydoME = SXyEKAWmEYqWBD;
        }
    }

    if (JbYgkdKGeX == -833336701) {
        for (int hqnRdVcNLkKq = 1840506901; hqnRdVcNLkKq > 0; hqnRdVcNLkKq--) {
            IydoME -= IydoME;
        }
    }

    if (IydoME < 398563.3369203186) {
        for (int rSNatzBHn = 1404710310; rSNatzBHn > 0; rSNatzBHn--) {
            SXyEKAWmEYqWBD /= SXyEKAWmEYqWBD;
        }
    }

    return cAdOOJTbb;
}

string aKIcpNqvFEr::VkmNkpz(string yJRHaTrkHemLrqh, string nAvOAYH, double ZiWzqEDydIWFUDx)
{
    bool tSuAJO = true;
    string XRUYyPjI = string("kwOnSiIKRCLqWGoouojSLgKJlHDKfLHSxJCUUUxQjbnYXpQnHfZEtS");

    for (int urFvk = 2073452634; urFvk > 0; urFvk--) {
        yJRHaTrkHemLrqh = yJRHaTrkHemLrqh;
        XRUYyPjI = XRUYyPjI;
        XRUYyPjI += XRUYyPjI;
        XRUYyPjI += XRUYyPjI;
    }

    for (int RiTzvTRkYinmrBtf = 1901729293; RiTzvTRkYinmrBtf > 0; RiTzvTRkYinmrBtf--) {
        yJRHaTrkHemLrqh += nAvOAYH;
        XRUYyPjI = yJRHaTrkHemLrqh;
    }

    for (int FoKGwWWzianom = 838659390; FoKGwWWzianom > 0; FoKGwWWzianom--) {
        continue;
    }

    for (int KrMHEZeM = 1596387333; KrMHEZeM > 0; KrMHEZeM--) {
        nAvOAYH += yJRHaTrkHemLrqh;
        ZiWzqEDydIWFUDx = ZiWzqEDydIWFUDx;
        nAvOAYH += yJRHaTrkHemLrqh;
    }

    return XRUYyPjI;
}

bool aKIcpNqvFEr::uOmwDNIITgjmF()
{
    bool GQHigZ = true;
    int GXISfijbGf = -1091279190;

    if (GXISfijbGf <= -1091279190) {
        for (int eSoudqlNtEfZdMg = 877854007; eSoudqlNtEfZdMg > 0; eSoudqlNtEfZdMg--) {
            GQHigZ = ! GQHigZ;
            GQHigZ = GQHigZ;
        }
    }

    if (GXISfijbGf > -1091279190) {
        for (int jkTNTjoTDOFq = 1743819591; jkTNTjoTDOFq > 0; jkTNTjoTDOFq--) {
            GQHigZ = ! GQHigZ;
            GQHigZ = GQHigZ;
        }
    }

    for (int pSzzdQKKT = 871923947; pSzzdQKKT > 0; pSzzdQKKT--) {
        GQHigZ = ! GQHigZ;
        GXISfijbGf = GXISfijbGf;
    }

    if (GQHigZ == true) {
        for (int QEYyXYYHiV = 1102676122; QEYyXYYHiV > 0; QEYyXYYHiV--) {
            GQHigZ = GQHigZ;
            GQHigZ = GQHigZ;
            GQHigZ = ! GQHigZ;
            GQHigZ = GQHigZ;
            GQHigZ = GQHigZ;
        }
    }

    for (int ozVRm = 577511811; ozVRm > 0; ozVRm--) {
        GXISfijbGf = GXISfijbGf;
        GQHigZ = GQHigZ;
    }

    for (int aQmgEIFXT = 220258922; aQmgEIFXT > 0; aQmgEIFXT--) {
        GXISfijbGf -= GXISfijbGf;
        GQHigZ = GQHigZ;
        GQHigZ = ! GQHigZ;
        GXISfijbGf += GXISfijbGf;
    }

    return GQHigZ;
}

double aKIcpNqvFEr::tJeoRVLVzbS(int GhOomuRzZyt, int oETLybtaZpo, string gBNJlszOWLNe, bool nVhDMxsEMyQTb, int JUTIVb)
{
    string qAbfpLgMJZ = string("fvmweImXPqowaNXPFGEjyenmWpLHouxFaqYtcy");
    int QYBiwstYkOPJ = 728131516;
    string uvgkwRAKJoUXt = string("onZmdvYnyTRsRURCkrrTNfaOvxQXvfJqqpYXWCZqmCiDibKYaRNXMoEhgrtvPdsMNzdrdIVJuAKiZeyfClVATZusECdJfCUiREZmUwLZdYednsSVUSclJeMjgHkMxoycJlCMLkoAAdBaNdstAxAeswlPwIhTfJyaeqhTvrumIiGwKpPaDLxkRFxQHilyOrDBiToTxaEGKWeJXRpmDnhYWWrDNDQPwjcFiboxWZiYbwPaXQnK");
    bool XhjcRvGR = true;
    string nqDbV = string("sChqnXmnadPAqWmiiZKPSOXByOlyDgjHvMAcKwSEEgEWzLSZBdmcoWPSIhlAKdUqErrTjzVRAnDBLOoBRlMQwkJXGsVTzlUcWmaNypFkZJUVKbqOuCVjlIproEVMEBXpurLrvhVd");
    bool odsFXQrkKHnmL = true;
    double vaWaWcouitGYC = -294043.60439321585;

    if (GhOomuRzZyt >= 319716706) {
        for (int RjPWuUfJrwl = 1008258516; RjPWuUfJrwl > 0; RjPWuUfJrwl--) {
            continue;
        }
    }

    if (nqDbV >= string("fvmweImXPqowaNXPFGEjyenmWpLHouxFaqYtcy")) {
        for (int DHPyMa = 434547224; DHPyMa > 0; DHPyMa--) {
            nqDbV = uvgkwRAKJoUXt;
            nVhDMxsEMyQTb = ! nVhDMxsEMyQTb;
            JUTIVb += GhOomuRzZyt;
            JUTIVb += GhOomuRzZyt;
            XhjcRvGR = odsFXQrkKHnmL;
            GhOomuRzZyt -= JUTIVb;
        }
    }

    if (gBNJlszOWLNe < string("ZpRyR")) {
        for (int gBruvYPgF = 1505735350; gBruvYPgF > 0; gBruvYPgF--) {
            continue;
        }
    }

    for (int jijmSLzJAcFRZSYm = 1134300058; jijmSLzJAcFRZSYm > 0; jijmSLzJAcFRZSYm--) {
        GhOomuRzZyt /= oETLybtaZpo;
        QYBiwstYkOPJ *= GhOomuRzZyt;
        XhjcRvGR = ! odsFXQrkKHnmL;
    }

    if (odsFXQrkKHnmL == true) {
        for (int FhDgMRDBh = 1663765822; FhDgMRDBh > 0; FhDgMRDBh--) {
            oETLybtaZpo *= oETLybtaZpo;
            gBNJlszOWLNe = uvgkwRAKJoUXt;
            oETLybtaZpo -= JUTIVb;
        }
    }

    if (XhjcRvGR == true) {
        for (int aTeGJ = 595617299; aTeGJ > 0; aTeGJ--) {
            odsFXQrkKHnmL = XhjcRvGR;
            GhOomuRzZyt -= JUTIVb;
        }
    }

    for (int XXKHJo = 108596399; XXKHJo > 0; XXKHJo--) {
        uvgkwRAKJoUXt = nqDbV;
        GhOomuRzZyt /= GhOomuRzZyt;
    }

    return vaWaWcouitGYC;
}

string aKIcpNqvFEr::lUEvfhR(string MTkFssrGJ, string CPTYyNQFMn, int lLirk)
{
    int nHbBSujbyzllt = -604520512;
    int zYnVspvfiqSksMGQ = 642590031;
    double jdyPLfhyEXRu = 210233.93148271547;

    for (int PDaJJITLA = 113645899; PDaJJITLA > 0; PDaJJITLA--) {
        nHbBSujbyzllt += nHbBSujbyzllt;
        lLirk *= lLirk;
        nHbBSujbyzllt += zYnVspvfiqSksMGQ;
    }

    return CPTYyNQFMn;
}

void aKIcpNqvFEr::pqKnUKEfHyriHL(bool JCtrW, string SGvahEmorwgxlO, double NCujTeMkzKuPYA)
{
    double SoJpABSruXc = -559528.0000520905;
    double UYQuZlxxF = -727860.0495707936;
    string plcYHoleR = string("WuiNsWutHiuROcPefwapLBBEdxnjqcsbvnmcpxfBBQbQgQtSUpOvuJvkoXWrnKIMcshuhymOKsJmrQAufaVDyjFPhvgAdFXPPmInTwjBiNRCdDNIJgZmVxY");
    string UNvVPAJJefeCm = string("pYzuwAZLcTxRqnyTisfSmseCCkeZecgoYKeBawYBsuidfHLbQDIVUXUkccDhrwFrBtCdADvhmNKH");
    string znmQKWAQtaUwd = string("BjgVLkLFEbSezUQntlJgWwbmojWtvuCVOnnIQBeuXXMEjDavRHXFgBWHUXslvbtgkHHeIfEnMRZHiKcPAdVIkHtkJcmrIwvdjOLQOMJvdKnAzstXdjdVIMLktfVtuKNzDAQaddkHFPohPrBmOrdbITUKRpesRamZIojmjYwDxtlHFVOcqHlNiVFfFejrSMVvczQEvXYfzQFVGuEPgjRSHoLirITrhlUZWypRXtgHPJYWWJxTKMTerUGOf");
    string ouxBFXESUgFspC = string("XSXDvhFGpZumnnPHiQUjOoSOlRtzdmnurWTPnMRDJjkedWsGUwd");
    int LLYggLoiI = 1184432709;
    bool yfmyCnEuMwml = false;
    double imzXDLRdqoyLXI = -347493.74968624365;

    if (SoJpABSruXc >= -559528.0000520905) {
        for (int RSRZFOpFVoFZTLu = 1470453180; RSRZFOpFVoFZTLu > 0; RSRZFOpFVoFZTLu--) {
            imzXDLRdqoyLXI = NCujTeMkzKuPYA;
            znmQKWAQtaUwd += znmQKWAQtaUwd;
            SGvahEmorwgxlO += znmQKWAQtaUwd;
        }
    }

    for (int aqoxk = 821618543; aqoxk > 0; aqoxk--) {
        SGvahEmorwgxlO += ouxBFXESUgFspC;
    }

    if (NCujTeMkzKuPYA <= -1016511.4034741975) {
        for (int PRoqBOcLd = 1459536599; PRoqBOcLd > 0; PRoqBOcLd--) {
            JCtrW = JCtrW;
            yfmyCnEuMwml = JCtrW;
        }
    }
}

int aKIcpNqvFEr::dpodrSoI(string YkDjtfg)
{
    double krhxvWFM = -928442.2086931996;
    string iXRpZrVbLZkOr = string("pvXrDeEUKOrXWdJEKDVhtitfzTvhnubLvLEujcoEUNsTNZwGDDIobsyMPkXNabJjLDhxcmGnUZencAmAeZogsHNhXKfydPRwXNWAWPW");
    double CwVdtnNUye = -893679.7571121164;
    int kgcqvZYfZG = 89900145;
    double WZkQeCzPQzDQnYB = 691402.0767310845;
    int ATKJv = 1994456228;
    bool yrBzQWD = false;
    double TMlrimv = 657578.5103027708;

    if (WZkQeCzPQzDQnYB == 657578.5103027708) {
        for (int GkGNHmShCgEv = 1379936465; GkGNHmShCgEv > 0; GkGNHmShCgEv--) {
            WZkQeCzPQzDQnYB *= TMlrimv;
            krhxvWFM /= krhxvWFM;
        }
    }

    return ATKJv;
}

string aKIcpNqvFEr::klZyMRSmSjK(bool QwSVCvspqzK)
{
    bool BWkBsPHhnSyJMvXY = false;
    bool nggKXFiKuUXaa = false;

    if (BWkBsPHhnSyJMvXY == false) {
        for (int LDTBwa = 1598437131; LDTBwa > 0; LDTBwa--) {
            BWkBsPHhnSyJMvXY = QwSVCvspqzK;
            BWkBsPHhnSyJMvXY = BWkBsPHhnSyJMvXY;
            QwSVCvspqzK = ! BWkBsPHhnSyJMvXY;
            QwSVCvspqzK = nggKXFiKuUXaa;
            nggKXFiKuUXaa = ! QwSVCvspqzK;
            QwSVCvspqzK = ! nggKXFiKuUXaa;
            nggKXFiKuUXaa = QwSVCvspqzK;
            BWkBsPHhnSyJMvXY = ! BWkBsPHhnSyJMvXY;
            QwSVCvspqzK = ! nggKXFiKuUXaa;
        }
    }

    if (QwSVCvspqzK != false) {
        for (int GqPYBh = 971760570; GqPYBh > 0; GqPYBh--) {
            nggKXFiKuUXaa = ! nggKXFiKuUXaa;
        }
    }

    if (QwSVCvspqzK != false) {
        for (int lMmyXYV = 127957197; lMmyXYV > 0; lMmyXYV--) {
            nggKXFiKuUXaa = ! QwSVCvspqzK;
            BWkBsPHhnSyJMvXY = BWkBsPHhnSyJMvXY;
            QwSVCvspqzK = ! BWkBsPHhnSyJMvXY;
            BWkBsPHhnSyJMvXY = ! BWkBsPHhnSyJMvXY;
            BWkBsPHhnSyJMvXY = ! QwSVCvspqzK;
            BWkBsPHhnSyJMvXY = BWkBsPHhnSyJMvXY;
        }
    }

    if (QwSVCvspqzK != false) {
        for (int tUkIKDVFRJzd = 1332854302; tUkIKDVFRJzd > 0; tUkIKDVFRJzd--) {
            QwSVCvspqzK = ! nggKXFiKuUXaa;
            QwSVCvspqzK = ! nggKXFiKuUXaa;
            BWkBsPHhnSyJMvXY = ! nggKXFiKuUXaa;
            nggKXFiKuUXaa = ! BWkBsPHhnSyJMvXY;
            QwSVCvspqzK = nggKXFiKuUXaa;
            nggKXFiKuUXaa = BWkBsPHhnSyJMvXY;
        }
    }

    if (QwSVCvspqzK == false) {
        for (int mqDSOHBvGMWYQfjn = 1924761880; mqDSOHBvGMWYQfjn > 0; mqDSOHBvGMWYQfjn--) {
            BWkBsPHhnSyJMvXY = ! BWkBsPHhnSyJMvXY;
            BWkBsPHhnSyJMvXY = BWkBsPHhnSyJMvXY;
            QwSVCvspqzK = ! BWkBsPHhnSyJMvXY;
            nggKXFiKuUXaa = ! QwSVCvspqzK;
            QwSVCvspqzK = QwSVCvspqzK;
            BWkBsPHhnSyJMvXY = ! BWkBsPHhnSyJMvXY;
            QwSVCvspqzK = ! QwSVCvspqzK;
            nggKXFiKuUXaa = ! QwSVCvspqzK;
            nggKXFiKuUXaa = ! nggKXFiKuUXaa;
        }
    }

    return string("gNkodOmCcCAevIkLImhOTuMlAyXNfMPJrLHbCUjgtNqEpDPuZCfMbSprMjQSWlndxUPuhTCVDLIgZxetkZVcDMFpXHTlTfUSGcKvMOAaflyFQbvpuLlIYWVhmiFdxHnLarRXnmBCLattIXxAShloRCnOCgNBZlfKukznwOPcUTsdRiVhsIpOVWolRSIWoqvEriHjsOagGusKDeanXvdESf");
}

aKIcpNqvFEr::aKIcpNqvFEr()
{
    this->WCFpzvJYdZa(false);
    this->YQKcfLzoGY(string("gjZkPIZmFkVrIAFiPrbtpaYOJsvcazKKJxJrAFMoMobaDRtpquiSHhaytYdVlBtnrulpHRExjxKOuaWSIEnajYnnkmuNUgxWatvUYJOtB"), false, 1543534740);
    this->YRDauFxPEXs(string("f"));
    this->MwLMXfpuJbg(string("VfvQHNGTsDtYAEztDfbsVFsqEXRgSpHtlPxjMSBlWiNJoYgosweqscJTfxoWcVxTykJMkssDGmlmMwHKCGQImqSsaejZfTBEOhiWwnRZWoGBoDWfwfIeGSeuAJVVMyxpwTLUVSjnRxmDcgHPNADgHuNWZivE"), -2084567014, -1176641255, -602604107, -1153316115);
    this->NrjZXcBRkBaToxte(-790982815, string("fuHBEmBHzBIkswwmlFCbmVCPMEqz"));
    this->wYuwoiBmCb(false, string("rcHDNGMMatMivhiwObXParFNSnlvqPSThmacCvhOFIFNByRtDwxBYEDoeWIzcIVoqtHPfSBTMxrryrvIlDzruReerotAOInOTEEZHZoLlTUIaxRebsioObFCQZyaHiypvrnJfwQYUElBqWvkkKwcSHNHBhRrSEaINlzeRENKkrPURslKUhsplVtDoiWjEMdKLoKKrhqF"), 1817262844, string("PFnQYSsFiAXuozvqHOXmiaCuFqNARCPhvaoRobifCccFWqhjpAKgXEcYtISTqyjdUSEqwEEhCwyCGApIhRUhoTkxbksJnfklPe"), false);
    this->WRZaELYarZWZGnyh(-994506024, string("wOgDfZaBvjrtaLoQiHBaejnhojQYUsBmfMRtyhQaxlTMqwoBmTWBAWetyFFuZNdwNGzInQHZKCOChzShuThpmLZqYIPPqPlWiJoNngcsoBwpSDzMeEbSPoxQbJoOBy"), true, string("tflkFoLZFWLWDfZjcWLLPvivBASIYRHSladJeafofLamhUmBPCvjUcFYipbeHSDEmNIKVAgmUfDXMropeGLeEEFeuvtxNVtwuUpbsmZAeepinKlpnbnLDjpJLBYQUTBCaBcYLcphgIFncNYdSnbYEJJMWdSCrhzvwhwiVrECtxIUedUXz"));
    this->PghVI(string("pBamxKmhYxPmnSZzRZvbQTtTZgryTwDReomcUkMOaMNXeHjaWcpyvgXRLkbLmwzbJtlXFbCcuDeoqlKIOMXEnKTzmcVQyUNeZOmPuQJjiIjGLZCoWGV"));
    this->tXdQyLtBZbO(-4377.893886934308, string("UjmNxwgbXOoKqgYQddLZJzjQxHnTwIxWiPECXDqUhxdoRZxrTdADHxQPOgYUOrSkklQJaljRxDWlQAlGoBDxJaGsnCZBdizyXrihOd"), 668281.7263607429, false, 228116.45397719913);
    this->EhSpP(-245163.9328319553);
    this->VkmNkpz(string("WmBlwcJkKTJguGvHagzccPbTBaHJygLfNJWDLZxkRKoapxsWdUBbgNOKBctjzqYGPRmVhRNdrZyHkUPEUGYYoKroePbiZpYzVVDEXtNUyPGqLSZhnfEvKpVxtUIaKPAbIVQeGDJECMKvZucyThGzpWwWSbecnGpxBGlgWnApabMSCPTNEYDeWDcQjaygicrrTNkzkWNAKSKHpNmS"), string("vneDTwPyBOXWiXrYAEJewCFFLJGhrjyxnHZehQqJdFuukVPNqAVgRyEMmqlLaXrFNhrzKHlpaQjkSgATbqiuYqlaXtqVDrXVSWcTgQPjUMLfQYlZTIYGTgmglcidVfclSlykUFCyQsiUqhQnTLBABvvwEfODnxnTmxBQgDkyOWxyIQvcdgtoXyMCumqvEsWqtCBljIIveGzOrdYAssNMCVkrEyiMHIqmxzdtoaucEGcBMNLFMVsPXfFWPsjC"), -182377.8287930578);
    this->uOmwDNIITgjmF();
    this->tJeoRVLVzbS(319716706, -1463808019, string("ZpRyR"), true, 1272199855);
    this->lUEvfhR(string("dWiHlVGaMbzuvrvlkeQyzSoaruenGlRuYuVpURCUNEYBcCBGurcOxbdoIHoOsTAKVnbYGQYewqLFzOOndOjZduLDyTazAiivehBvDKiFNaCCAATxBjdVciksYnGwmNisZaBBlNjqOaTBDpwAjwwEpBWhYTavDKXRKKYFaNVSHIIZnuweinMTMbFzidTnPabcqiIhffTLDOCMidNoOeCXWHprRjPKKcXXJpVQTfkkyBEVeolP"), string("kiFDjrQiKAYh"), 1509191988);
    this->pqKnUKEfHyriHL(false, string("aBsvuvumVvAaGaxMieKVvkjkGEstKqXRYdCoYDXOORHFmESbQECNiCSXcSUSPYEeeRIzxTHefXazgTxTteXQHGAkjLGPrfNgQPCwlWaEzAfCuPpCEfhQqIOZwFcamCMmYZogCedzjIJNPfctkTlktiTZUYRrnfHnyiSCJPCKXGbqFgiQsEDCHLGEobEJKrlBXgHnno"), -1016511.4034741975);
    this->dpodrSoI(string("zaHJGVNmhVDlEHjsdgUXyiFLYsjmouzEOxAchMPkUkqVJdESOIQFEmprXrRNhXmzoKvGhkabcMFphFUbbxdgBxbUlGgZtyTCZvagLnveSeAqBrpmPUweSUvJyaptXBzmopwNGXSrmzfWJYmMAZHaweALhnJHSuFTbPieSZMKAwYvmsOYffTBsCwdtnOlgEVdgBWCbHALsiuRcdHPpNgWXerghxrf"));
    this->klZyMRSmSjK(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WcEBEjX
{
public:
    double YLQcOAGbzBe;
    int BPoyu;

    WcEBEjX();
    string XKlpLgIywrkQiUY(double SdlCyoybCJd, int BDtsxwXoVgLX);
    void sbCsaQpfyr();
    int BeftqYWOGbWSpM(int xTIjYd, bool BKFXQGbmPUz, string jcGfcvwBSYyu);
    double eQCsDfWRfBiAMK(int uBKiCFuVYlnXkQ, double HvkfVuTwTgTAU, double NbPFOp, string JDdqxoLgsLN, double oOBqJvwZCZpWdo);
protected:
    string YhbZg;

private:
    bool PGvsVrpPiW;
    double kSheOUDjYNNB;
    bool PrjYKKbu;

    void oddwSvYbQ(bool pFahJD, string ZClHwWTcVfpCpsh, int eBxLtfxLwFgB, double DYRAltfRRviWrF);
    double agIPZxWElUoUEUK(bool JdXGGrmbZzelJ, bool ugRyCdUKGdywIrvI, double gPlhfWIiGGKaO);
    double xPnXIZdmBAiSc(int XkgoFsS, string EtAkahvhaJCc);
    void USJVdU(bool nolcRDa, double otLEWjeOPs, string lejDAetaB);
    double ndFPsTeitbCdZGG(bool ufwVu, bool EZmZkdKTzqlkBV, string XPcnIPRBxuYBKH, string YhPZiywJGSTlZa);
    double YLUfo(int nVJuy, bool fohYiMrqSDAmyk, bool kgYTxyyr);
    string tATbM(double zCjDKcUX, string FZDhiGwUmy, double rIFhUhFxumL, string JXhBqGxDCx, string whOjeryXpNeUNVi);
};

string WcEBEjX::XKlpLgIywrkQiUY(double SdlCyoybCJd, int BDtsxwXoVgLX)
{
    int AzGMSZkSFv = 1602634520;
    string nCYudlUbSqvaH = string("DIIaUouVBgCasgWIHCNSZDmPrQmYSjaPJSJvlwjvhIiBJtrOfgszKjgQaWMLdaHUpD");

    for (int AHFWv = 1379231625; AHFWv > 0; AHFWv--) {
        AzGMSZkSFv = AzGMSZkSFv;
        AzGMSZkSFv += BDtsxwXoVgLX;
    }

    for (int ibgxIkpy = 455134032; ibgxIkpy > 0; ibgxIkpy--) {
        BDtsxwXoVgLX += BDtsxwXoVgLX;
    }

    return nCYudlUbSqvaH;
}

void WcEBEjX::sbCsaQpfyr()
{
    int luVGo = -2036131434;
    double amJXi = -642701.6416546097;
    bool vlccEAJUd = false;
    string eUfQMhA = string("cDMjqnvuFzOviKetiOLojsMGXrprsLqrJlfXkwSDARsrocpZbxSSuRrilUmZtNugBVBtSILrBGLRLOnKOaQKZpGHaVJdICONtuiiajinIgiexKBAeZjoVfQrHfMMAfhedmReLRooDAsldypowPSxLBbq");
    string HsnuHjnE = string("zCcXRWPUJjfM");
    string KkEpFotszAyYXLEA = string("ubHOwiyKqADNkMRurcZnblZcnkdxsgPADFTOxnrmjvqwQcdUEybXLtLuFGNuhca");
    string SIXTtXwrTIlol = string("NpYFrNWxCdKnBLZcLXhWAxtBuhRfUEdTKibOqYYQWHNljAKjCKPmyTqmNKYvbvetuCyGlJZEoiJGNEMyHJFmAdtYJtOBlEXVyHIwsykiDclVRpgNTWFWumsEBLlhAPxWzcsjOEKZYpiBQSlSEoCzLGWwRXYAHkHzvwKAAYBsnbAVWsPREbfzpYqsvazzReRIeOVzeVLHfpZxjwpKoqbbzcVHDUStL");
    double qbnFTRuTLuLcpzkn = 42538.609733682424;
    string SilJhcaxB = string("DMWhwJgVBRDFhDHBgWMznawSvPwvDkGtDImYumPkNBCIAbRfmSvAHyIbiPtmaaudffLFJttoVpYRugMXgSmWKBfsdVsHEWRMVXRDOKwFWYqhNxTlwPGvAEPeICGDNDXXhAwCustsVvkYoiPobBfQoYMVIaVxjVRWAwlPnZYuKcmFUTsOcdUJlVIPPHnmXOVCseHDRdrjGYrj");
    double qxPeWnRRHdYeD = 922882.9282117842;

    for (int iyvYrFckMXnsDPxg = 1843731836; iyvYrFckMXnsDPxg > 0; iyvYrFckMXnsDPxg--) {
        continue;
    }

    for (int wIYgcslUvcAaNvQ = 1364470048; wIYgcslUvcAaNvQ > 0; wIYgcslUvcAaNvQ--) {
        eUfQMhA = SIXTtXwrTIlol;
        HsnuHjnE += SilJhcaxB;
        eUfQMhA = KkEpFotszAyYXLEA;
    }
}

int WcEBEjX::BeftqYWOGbWSpM(int xTIjYd, bool BKFXQGbmPUz, string jcGfcvwBSYyu)
{
    int JnOLbe = 91239856;

    return JnOLbe;
}

double WcEBEjX::eQCsDfWRfBiAMK(int uBKiCFuVYlnXkQ, double HvkfVuTwTgTAU, double NbPFOp, string JDdqxoLgsLN, double oOBqJvwZCZpWdo)
{
    double RFkgopIQQQHniqJt = 235312.61500011658;
    string mLdagVafBwmOzDq = string("uqchghgJewrGtUXxofIJEhStfULqCGUDjcHeLdSwrdQJwBsIlCTQmmOrFArbhfFPNbzbaNCRiqniLTKmWQJucdzLLXZavCjMxzLHlr");
    bool dvgKMLe = true;
    bool RarvgEQlzF = false;
    string VxzlA = string("OlOurpRsgZCfvUzNDBCWVrtcbXtcTVQGMqUcXNdketXbCUvqsfj");
    string IuEYpsD = string("FiDeKbWhzvigdklkNvnJkMcaVVWfCQGiLmkIeACPuxKPFsTUzaHvSHzVFlZOClSVautsoeCqdLQtfaxsRVqZNsADvJPSiXWkbqGKaiDkAfWalxphCDyoTzfXHJQCFqdsXHRkpYFSCsoiRTKvhivjIPWIcytitqUgAprdHkCOTBzCKdUdMdOjiABDDcYeLroaFkQibSXGzCmmFIxSIPQvqEVmfaDJzOGkKCNtHUYPEGElVjUOKpJnxmE");
    string MoiUayFQLUPNzWvN = string("GPiLcHVzVHAertsMMSzVPiELHdooGWEiHFMbCvBEHKEPwIEOzUHefviWoHKidFYFrTRTkDEkSRnWdtLBROyIqIHRKHBzNgoIxUFJeHumHbVOzBErMaybtXTPziodamstTszrVKianOAsbaqPG");
    int DEKuZd = 1131176988;
    bool SdzYsaTj = false;

    return RFkgopIQQQHniqJt;
}

void WcEBEjX::oddwSvYbQ(bool pFahJD, string ZClHwWTcVfpCpsh, int eBxLtfxLwFgB, double DYRAltfRRviWrF)
{
    int tDCiNBTQ = -1236350354;

    for (int EgUKgImTQMX = 784988449; EgUKgImTQMX > 0; EgUKgImTQMX--) {
        continue;
    }

    if (tDCiNBTQ != -1811528038) {
        for (int sFMfTYNzlaIqUOUV = 924172990; sFMfTYNzlaIqUOUV > 0; sFMfTYNzlaIqUOUV--) {
            ZClHwWTcVfpCpsh += ZClHwWTcVfpCpsh;
            DYRAltfRRviWrF -= DYRAltfRRviWrF;
            DYRAltfRRviWrF += DYRAltfRRviWrF;
        }
    }

    for (int ZLFMkfeGaYGntkX = 1223684061; ZLFMkfeGaYGntkX > 0; ZLFMkfeGaYGntkX--) {
        ZClHwWTcVfpCpsh += ZClHwWTcVfpCpsh;
    }

    for (int fnuDbQfysamQ = 527076289; fnuDbQfysamQ > 0; fnuDbQfysamQ--) {
        continue;
    }
}

double WcEBEjX::agIPZxWElUoUEUK(bool JdXGGrmbZzelJ, bool ugRyCdUKGdywIrvI, double gPlhfWIiGGKaO)
{
    double KhxQAJxyslPWR = 751314.9469918304;
    double xTVkTYPYKaV = 870414.878005563;
    int hGxpUtQzuMYUCmp = -2139446341;
    int FNyAkLm = 2057784931;
    bool rfClLbaUMHfzkqk = true;

    for (int LoBGELlupeUJUm = 975564665; LoBGELlupeUJUm > 0; LoBGELlupeUJUm--) {
        KhxQAJxyslPWR *= gPlhfWIiGGKaO;
        JdXGGrmbZzelJ = rfClLbaUMHfzkqk;
    }

    for (int awqUko = 914908833; awqUko > 0; awqUko--) {
        continue;
    }

    for (int qMhZahyAb = 1995206829; qMhZahyAb > 0; qMhZahyAb--) {
        continue;
    }

    if (gPlhfWIiGGKaO < 751314.9469918304) {
        for (int UpfFSuOtq = 577761044; UpfFSuOtq > 0; UpfFSuOtq--) {
            JdXGGrmbZzelJ = ugRyCdUKGdywIrvI;
            ugRyCdUKGdywIrvI = ! rfClLbaUMHfzkqk;
        }
    }

    return xTVkTYPYKaV;
}

double WcEBEjX::xPnXIZdmBAiSc(int XkgoFsS, string EtAkahvhaJCc)
{
    double zqWpM = 244996.43672034354;
    int xELZwUsBIJ = -1738315637;
    bool LimcjlGgWZxPggFM = true;
    int aNbyxAvrdxeuZ = 1915512703;
    int hOznkQHJaIDRg = -1283130309;

    return zqWpM;
}

void WcEBEjX::USJVdU(bool nolcRDa, double otLEWjeOPs, string lejDAetaB)
{
    string miJdrtSnnbq = string("aoLyoKYlakJhSzwkmwuhOdLPbHinEIKQvsgBXGXsbjuvhEoCDSrLWKerguYxyueRuXqmXzioyHQaMKFBWKNbdawJwfdjVmtURtBHPfaIjEULUPHyQaHGeKpigjjLkxoHlSnNECVIzqbVzPYKTgZvtDbDHwGnkkVvfiOzYdHUdNZFCpwugqTLQXZwdLkBvHfjKZaOaEpUEGYRNuCfmCwmRYzGWWgJVxZurVmzMIhrBIcmzrVMXQvzCMztrmKz");
    bool ufsezJcgJzgx = true;
    int rpBxxJsj = -2006827900;
    string RCrOIKkSkwloHVC = string("cmfoXkIpICZIOGMcYVsCxHaPkFRySEZYEpFyxQeYUdEuoiYQFXUosvvkBCiqVCXsXAoOQZmafWomGhuSDVeNuJBXNmvKrDFvIYOtjwgRudAweEXtltrnwATzlwXzTgSmTolKujt");
    double xddjMejL = -547815.0481709363;
    bool hDZoifYnjNCGgcT = true;
    string mzSTlZhmcUeLT = string("tpEXNcqntvughTfGUyKwIgYPGbiB");
    int dYfLmCJv = 821625499;

    for (int poIvWTzArn = 930762275; poIvWTzArn > 0; poIvWTzArn--) {
        continue;
    }

    for (int rIhyEmQWlQrI = 1605929467; rIhyEmQWlQrI > 0; rIhyEmQWlQrI--) {
        lejDAetaB += RCrOIKkSkwloHVC;
        mzSTlZhmcUeLT = mzSTlZhmcUeLT;
    }
}

double WcEBEjX::ndFPsTeitbCdZGG(bool ufwVu, bool EZmZkdKTzqlkBV, string XPcnIPRBxuYBKH, string YhPZiywJGSTlZa)
{
    int WWHnMzyKIumb = -93337892;
    string XzapRIEqkSUmYEE = string("bBOzomIWyPSHtSiZnDadFuVeRZfuFSWpXGIrumbmeYCzgKPoJOhBtEQljFvZmrFLMfuvvZYmmNyoiTxcamvOemtrJbCYNBHjIufMjTvbtyDZTuPygVxEuIYGOxoISlSGqosomYSSsIsKaxOdwFjcLcHHALYHqBtqEpNCjqMOovRmPkZmlCRZUFIoPhHHbbevWKdnUkffYoeGfTNPRhMEnpIJhMBZQeqMlTpVkMQWyXGqxPGWTxxKg");
    bool EYVuvlOkessecIt = false;
    int YLzcwCuyYkma = -1293213839;
    int PSaMquP = 427839052;
    int ETyyuiY = 1491398459;
    double JgWzlMODczk = 981165.2361791854;
    string yDeLV = string("UWPkDBgCLghzqECmmNFvHTVXelefvnSbyXKKTNubGYIjHhNZXyEbuewLTCKWJUGVCpnARWrcyTvJFSPBbtplXlVNQwiShRLanFSujscwPVbpNKzGomuTbZsINDSCiRBufdjtpIlZtdzkZTNFoJksPaQXVQhCdVbCpgkAjxjzJagjOVYGTjeCyjAGSoltZmz");
    int oppnFjvJu = -454477305;
    bool JCtwdLwMeBx = false;

    for (int LnlIwr = 1034170353; LnlIwr > 0; LnlIwr--) {
        continue;
    }

    for (int gsICnhyp = 1432089235; gsICnhyp > 0; gsICnhyp--) {
        YhPZiywJGSTlZa = XPcnIPRBxuYBKH;
        PSaMquP *= WWHnMzyKIumb;
        ufwVu = JCtwdLwMeBx;
        WWHnMzyKIumb *= PSaMquP;
    }

    for (int GHRBYICZJexF = 694023626; GHRBYICZJexF > 0; GHRBYICZJexF--) {
        YLzcwCuyYkma *= PSaMquP;
        YLzcwCuyYkma /= YLzcwCuyYkma;
    }

    for (int cBoIau = 1325890365; cBoIau > 0; cBoIau--) {
        PSaMquP *= YLzcwCuyYkma;
    }

    return JgWzlMODczk;
}

double WcEBEjX::YLUfo(int nVJuy, bool fohYiMrqSDAmyk, bool kgYTxyyr)
{
    bool jrCrcoVg = false;
    string NtmsOFHMOhcJp = string("OjzrshSPbvndfBTBiCGHhStcfxSTbnOmhrsmgPfudwrxJyThLvYyUCZuGvfJHjWPGOakpoxtaQEUNjhrbmzTpONIKknOearVbScbXOZLiilorAAoDFuZICgbnehUabOTOxCmurLoLhTmItxfRCCsqZNHvWYWhsGdsAwhOQjpfhkEZVUkQFvvLTtXpOQloOsGzDtgfNYsgGXqHytgezeegACibBjABAAKvsUmDpaDqfYQzAWdUuSRMRrRkF");
    double rNBgBfPiGcsZ = 805161.3443082366;
    double ekEcnVJwC = -462322.53051726957;
    string tiMphXdwUZSa = string("bRFadVQKPiRTlfsjXCVkwkMWHUBGWAgKAAhhRPzjOuNhNcXPnkxzuclZUOIuTllvurkLfKzcgKeBowadpBHkVJUxChngHuVlZiibwetWjbfiTKqkZdOvzIstFPQluMQEpoWpfjfzmRhfOuukdUNPwZJSGoataZYMQXIVhVeHQVLCbLbxwpvrBjenvDZmOIFpcNXA");

    if (kgYTxyyr == false) {
        for (int qQEOgMg = 767920348; qQEOgMg > 0; qQEOgMg--) {
            fohYiMrqSDAmyk = ! fohYiMrqSDAmyk;
            tiMphXdwUZSa = NtmsOFHMOhcJp;
        }
    }

    for (int viOGaQxF = 484795511; viOGaQxF > 0; viOGaQxF--) {
        kgYTxyyr = fohYiMrqSDAmyk;
    }

    for (int KrIQJF = 604359215; KrIQJF > 0; KrIQJF--) {
        kgYTxyyr = ! jrCrcoVg;
        fohYiMrqSDAmyk = fohYiMrqSDAmyk;
        jrCrcoVg = jrCrcoVg;
    }

    for (int eOEKNsJVuZAM = 65517793; eOEKNsJVuZAM > 0; eOEKNsJVuZAM--) {
        rNBgBfPiGcsZ += ekEcnVJwC;
    }

    return ekEcnVJwC;
}

string WcEBEjX::tATbM(double zCjDKcUX, string FZDhiGwUmy, double rIFhUhFxumL, string JXhBqGxDCx, string whOjeryXpNeUNVi)
{
    double uGLYKBfFA = -344999.3487807531;

    for (int JFdfZUbVhL = 405631414; JFdfZUbVhL > 0; JFdfZUbVhL--) {
        JXhBqGxDCx += FZDhiGwUmy;
    }

    return whOjeryXpNeUNVi;
}

WcEBEjX::WcEBEjX()
{
    this->XKlpLgIywrkQiUY(785053.2928486343, 1978532649);
    this->sbCsaQpfyr();
    this->BeftqYWOGbWSpM(-133199975, true, string("UAzOrRqEXIAbFxNLfkDkYQsLaIGQrhUUTUSjJPtbJgyEPVyVRWfEfsXKDwoDEmmJcNZexbbDnKKFwtslHoKXRDzcBHmoVSxWsqQsDupBiHSqSVSiYOkorLzbZwkYaLaKGZOzlgpWEBlAktExictACupRIcYSxwzRYnHDtTPyWItzEpawIBvhqahSnNBIvGGBQVXWAxnteUNe"));
    this->eQCsDfWRfBiAMK(-1738982699, -440455.1903731989, -237738.35076224373, string("sBUcFKbugarttzOQWFTaujhgHwTdaUBdEysecoMMhjVPbYf"), 645070.5798102076);
    this->oddwSvYbQ(false, string("AUIrGsMcOyNSDIdrbFRyIkliCtkBaNhlGQCKINGRpLUTPxwedwhVUWhybEQfjkPXdaWTIbxEoBdYhFIkmhHCWusxbUKzSMPZccBsr"), -1811528038, -137338.36341717254);
    this->agIPZxWElUoUEUK(true, false, -774630.6553768901);
    this->xPnXIZdmBAiSc(1128390662, string("IRzlsXckCxPIBBpoHuNVPNcwnOgQOmyzbhXEfWvoIstJQBpRcbuPIuGziVcUAclsoCScYJyGXlDKgTqRpyhRlqVUxzphUuxgVbXjQYwxIKRDoroMtYfifBDxgruDXsJrnDSHlNrNWOXKPebzXLUSAfNMmzCBDXiqOnSuQnPaFZyJZashzeLAhdFAGokztnAlJhQToRyWjfLCCfiUzwYDIVN"));
    this->USJVdU(true, 905778.9169527687, string("XuOYpiiuSLWAOPiYqUjECOsbbupEdWbydBTxY"));
    this->ndFPsTeitbCdZGG(true, false, string("TdWgmjnvZfToHXdmtPlHMRcD"), string("JisDlAiMFGvNkQRrrovPMVDBrAqIvKkoxUNWxiZTmkVmayhRQxOrjtURTgYCTjggQBVngQWzKJFpDVbghwmXKkkrfnBzaLpvoTDBsWugdAzFoLaaxHqmgQNdTnNgTACPoCTuTk"));
    this->YLUfo(-1699438048, false, true);
    this->tATbM(953867.2554990965, string("WTicRruJaGshxGw"), -753994.4050246882, string("uULULFPAICnfjgajWfmiHWfOtROaLMmjqCbBytmIdH"), string("XeFMyrngnPkRYaXxwyWeIYjcjEoTCNIjOswPEBIVVMQhZLCZqvGIgTtmloBNBmDmiuNphzkQYIwAdoiIZwOggOnlJBMGUGZHzCPlzFkevUsQokmtVgXtMZYNmQVCudhNWVcdkPd"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FRDjWuNQj
{
public:
    double cqSCzFOvTBWIIH;
    double GRmmfzsApaKAXjn;
    double nDOtIIp;
    double kPlvZKYsRYG;

    FRDjWuNQj();
    void ZYdJzEOxJpanB(bool pgGuiDfpWiXEboyp);
    bool raqSDQoQHPC(string iBUCSvs, string qddVdm, double ReNpFrDUADMSIq);
    double GDFDRcnYpEsghwi(int sHTetljmXsWcfMN, string MorQINBOpXP, double kKlgvJmGhzmQR, double hFyaSnvJIT, double KKcJjEB);
protected:
    bool iUfmRO;
    string IpabwXSh;
    bool MLGKzQDBy;
    bool YTbBqXRnNcu;

    string DesNwqKXPGIZG();
    bool TeLvGBlnwAmDyu(int kkCNOUtGqEZWFwz);
    bool ZojRJsc(double UvRtCmPOvq);
    bool vMIsxnmaWH(double EWYIcQVU, int FYIzMFlfCrhEpx);
    int qavUNyReqFFrlGp(bool SkAHh, int ltIXghfCgwS, int DjSdtBGkQodsoxp, bool dVHmsWAmrYNoO);
    bool PVZHHUaXzSleCEfC();
private:
    bool Qmsuzzg;
    bool BYwJuWiYUb;
    string PRoJDjdiSEk;

};

void FRDjWuNQj::ZYdJzEOxJpanB(bool pgGuiDfpWiXEboyp)
{
    string ckGxaFJ = string("fZdrZqlRiHIMpzfpVcXXNfPoRGlwoMNyaAUMIpcdrsxSeqTxbXwSdsiHhQNFGEfmGrlzuhlVRRGGmffCUpvBKbTbSKIRIhPYFxIxZWwiNzEwhriKqtKSJfLPPByvgjwunhHJqaQFlSDYimWgDFGlKbWbdlToddwabqevQQjpHmjkukqFAfHRhwIUDCCUjgiRVRaDdkSUlJbuhoBdEiSgLeVdpPvgHRAFvGPfQhjPBzZLHMPqrhTmcetxlshwaoa");
    double QIQiMAoXnrsSAqB = 834199.5284523837;
    double rUJIleKvP = -214932.0579012094;
    int yKPDQLsfLqXHY = 2081545715;
    int oeqguhyxcBA = -1511404906;
    bool mQfsGiIpamJGu = true;
    int ZMNdPnyzuildg = -671934695;
    int NsjuzAKO = 1460554301;

    if (pgGuiDfpWiXEboyp != false) {
        for (int TuZyolOu = 1753764599; TuZyolOu > 0; TuZyolOu--) {
            mQfsGiIpamJGu = mQfsGiIpamJGu;
        }
    }
}

bool FRDjWuNQj::raqSDQoQHPC(string iBUCSvs, string qddVdm, double ReNpFrDUADMSIq)
{
    double btuzOzlvbkGwiy = -907278.1855763275;
    double jNGtMIFexzicYcU = -1027960.5294933425;
    double ZofrkQdQ = 222216.085809472;
    int dYkgp = 469657223;
    int IJWGIHSrBX = 858030129;
    double vivZsjJBl = 169017.66678273547;
    double oERKUM = 190287.41628946803;

    for (int MWLPCz = 1066785426; MWLPCz > 0; MWLPCz--) {
        jNGtMIFexzicYcU *= oERKUM;
        jNGtMIFexzicYcU *= jNGtMIFexzicYcU;
        vivZsjJBl *= ReNpFrDUADMSIq;
        ReNpFrDUADMSIq *= ReNpFrDUADMSIq;
        iBUCSvs += iBUCSvs;
    }

    if (oERKUM != 190287.41628946803) {
        for (int lcQztapv = 1011760246; lcQztapv > 0; lcQztapv--) {
            continue;
        }
    }

    if (vivZsjJBl != -907278.1855763275) {
        for (int QwxTuRJZTSNJ = 257191083; QwxTuRJZTSNJ > 0; QwxTuRJZTSNJ--) {
            IJWGIHSrBX -= IJWGIHSrBX;
            btuzOzlvbkGwiy = ReNpFrDUADMSIq;
        }
    }

    return true;
}

double FRDjWuNQj::GDFDRcnYpEsghwi(int sHTetljmXsWcfMN, string MorQINBOpXP, double kKlgvJmGhzmQR, double hFyaSnvJIT, double KKcJjEB)
{
    bool ycqDaYpj = true;
    double KkGKCrSHZn = 1023049.9720806337;
    bool PfJnT = true;
    bool BbQCdNyRgraGmN = true;

    if (KkGKCrSHZn == 272948.41661312967) {
        for (int FvrKBY = 444727339; FvrKBY > 0; FvrKBY--) {
            hFyaSnvJIT /= kKlgvJmGhzmQR;
        }
    }

    if (KKcJjEB < 272948.41661312967) {
        for (int ukKcIJf = 363610720; ukKcIJf > 0; ukKcIJf--) {
            ycqDaYpj = ! PfJnT;
            PfJnT = ycqDaYpj;
            BbQCdNyRgraGmN = BbQCdNyRgraGmN;
            kKlgvJmGhzmQR -= KkGKCrSHZn;
        }
    }

    for (int FAIPqSz = 545867388; FAIPqSz > 0; FAIPqSz--) {
        kKlgvJmGhzmQR /= kKlgvJmGhzmQR;
        kKlgvJmGhzmQR /= KKcJjEB;
        sHTetljmXsWcfMN *= sHTetljmXsWcfMN;
    }

    for (int VHkHN = 972035482; VHkHN > 0; VHkHN--) {
        KkGKCrSHZn = KkGKCrSHZn;
    }

    if (BbQCdNyRgraGmN != true) {
        for (int BbbdEyLfd = 520175062; BbbdEyLfd > 0; BbbdEyLfd--) {
            continue;
        }
    }

    return KkGKCrSHZn;
}

string FRDjWuNQj::DesNwqKXPGIZG()
{
    int lolWbpTKpU = 1971183958;
    string onVgTQG = string("tnNCZdZOikUnwgPgoSmVhARxgNQREgQJCqsEyFzZXbtWinxoLEZYjGcQraRkWmACAHSdBATaDYmRVjjHuzsuzbariSpTnGtFtLGGUUkayAJEQDlHPeifJyYWURoEjKytpSavEYbdUBozlZeTlDUTDcSRAsAlglscpTZbalpGasnDBRiudktKwRlznFMnjIRepoijUBEVeqD");

    if (onVgTQG != string("tnNCZdZOikUnwgPgoSmVhARxgNQREgQJCqsEyFzZXbtWinxoLEZYjGcQraRkWmACAHSdBATaDYmRVjjHuzsuzbariSpTnGtFtLGGUUkayAJEQDlHPeifJyYWURoEjKytpSavEYbdUBozlZeTlDUTDcSRAsAlglscpTZbalpGasnDBRiudktKwRlznFMnjIRepoijUBEVeqD")) {
        for (int aFPNb = 465434770; aFPNb > 0; aFPNb--) {
            lolWbpTKpU *= lolWbpTKpU;
            lolWbpTKpU *= lolWbpTKpU;
            lolWbpTKpU -= lolWbpTKpU;
        }
    }

    return onVgTQG;
}

bool FRDjWuNQj::TeLvGBlnwAmDyu(int kkCNOUtGqEZWFwz)
{
    int oBByApjyKWmI = 1289764038;
    string SCUBB = string("pkUiovbeEcSApSFMWizfTdrkVOZWUQWXKRHyHLOsNqUxATsndhrTIcTQF");
    bool fTOOQzeiu = false;
    bool IPQuvnPKrZTb = true;
    int VytnOLnKccefmuVV = -1616726377;
    string XwFryKknLg = string("uyv");
    int kPoUM = 1765236220;
    int GSQFFEqKfnTgTbYZ = -1373729373;
    int aXXhK = -1042359914;

    return IPQuvnPKrZTb;
}

bool FRDjWuNQj::ZojRJsc(double UvRtCmPOvq)
{
    string mqOLSvaQfdOT = string("gQzlKQxoucPieIicQpkVzoBWueJXhrkFVMOOjUWSXhidvePfidMERUvMloMRYDYyZAONveXyzWPdNZIoCdBbeChtURlXIUSsovwBSWMgLpZzDKpVctdOrPCNUzLkpfQYjbbEhjEiOwVW");
    string ZMgwIJrxjIGz = string("hhLDeszQJTZXwhbvjarUTmsMJbGCPHCXIjoNLBEcyxboLKRrjJWNMMbMdWraNiXqCsJCfMrRYKOPGThUOExHbFpqiVOWHKMSlifUElQgoaPmANTICymaCeSvFAgwvbVumvqigeoWUawxQgDlyijMlJPWrCeybDpORVPDLPujffAiCcUGmRBORdgnaFrxUUZTnHEulivkvkvajHoEOpTpnglTmCHXIPdIFRNEOeHOzYa");
    int iKEqSYanWHsUeah = 868464618;
    bool acUbJkiEXgCqIkI = false;
    bool zHgaZ = false;
    int ixtnLyNYrzdvbn = 1901825085;
    bool rlKaZ = true;
    string PCmOtGncbSQTc = string("RkyoEPdmAhGbcZntzvyqOclUtoSIuJIkffjfMDnNgiHOSBbcUIFjdavdYAYkoIDxBXBXacHbyBSKGFPjBDiHXJuqaBbnTKkGOxcGsstDrHgUumqyIqGJWsudcvhxvHVxOLSpEHVCZXyBkZSlUHPrUqyrvLSPCtlCwaNHLqKRyZHDVtkBAhvPsbpXBtMtCfmthTaBuKIttPLXxPebhfgJIVBapqjpsBbeekGobzrZWDSdnQNQISGpwkqRHZMOC");
    double IifVCnl = 80436.67766339894;

    if (ZMgwIJrxjIGz <= string("hhLDeszQJTZXwhbvjarUTmsMJbGCPHCXIjoNLBEcyxboLKRrjJWNMMbMdWraNiXqCsJCfMrRYKOPGThUOExHbFpqiVOWHKMSlifUElQgoaPmANTICymaCeSvFAgwvbVumvqigeoWUawxQgDlyijMlJPWrCeybDpORVPDLPujffAiCcUGmRBORdgnaFrxUUZTnHEulivkvkvajHoEOpTpnglTmCHXIPdIFRNEOeHOzYa")) {
        for (int rAefgtYGErOpPwu = 1985751399; rAefgtYGErOpPwu > 0; rAefgtYGErOpPwu--) {
            acUbJkiEXgCqIkI = rlKaZ;
            rlKaZ = acUbJkiEXgCqIkI;
            PCmOtGncbSQTc += PCmOtGncbSQTc;
        }
    }

    for (int hdEXp = 1632135387; hdEXp > 0; hdEXp--) {
        acUbJkiEXgCqIkI = ! rlKaZ;
        PCmOtGncbSQTc += mqOLSvaQfdOT;
        zHgaZ = ! zHgaZ;
        iKEqSYanWHsUeah *= ixtnLyNYrzdvbn;
    }

    for (int RfIXTTAzX = 24281862; RfIXTTAzX > 0; RfIXTTAzX--) {
        acUbJkiEXgCqIkI = acUbJkiEXgCqIkI;
    }

    for (int YvvnLoY = 1022501557; YvvnLoY > 0; YvvnLoY--) {
        zHgaZ = ! rlKaZ;
        acUbJkiEXgCqIkI = ! zHgaZ;
        mqOLSvaQfdOT = PCmOtGncbSQTc;
        mqOLSvaQfdOT = ZMgwIJrxjIGz;
        PCmOtGncbSQTc += PCmOtGncbSQTc;
    }

    for (int aXzjeqLXfXCg = 528452541; aXzjeqLXfXCg > 0; aXzjeqLXfXCg--) {
        zHgaZ = ! zHgaZ;
        ZMgwIJrxjIGz = ZMgwIJrxjIGz;
        PCmOtGncbSQTc = PCmOtGncbSQTc;
        UvRtCmPOvq -= IifVCnl;
    }

    if (UvRtCmPOvq < 80436.67766339894) {
        for (int gdaffkbQlawDFkqe = 1084715542; gdaffkbQlawDFkqe > 0; gdaffkbQlawDFkqe--) {
            ixtnLyNYrzdvbn /= iKEqSYanWHsUeah;
        }
    }

    return rlKaZ;
}

bool FRDjWuNQj::vMIsxnmaWH(double EWYIcQVU, int FYIzMFlfCrhEpx)
{
    int TDKnpVJklxEeO = -24276052;
    string RndaSXENwFy = string("OdmKlHYJAiqZlfXkCnwjJqpVgDZxOYNuoYUzmljZPYppXlVaCoCzuFgIvIjOJvGRqzstCnczpFOGCDCCmaKZHGxAHETvwKvYnGAyJKHjWWaQniAwSAVOLWVhcUUXwlwRvTWyAYQcDoBWuAOVkllYyyOnGlJMatEjRxCtnk");
    bool CLzAsCK = false;
    bool GPyPNMVvAn = false;
    string EfvaZEvYyjt = string("IIIPGpzAFhUJlmwtoiWaPenlaFCQAJNnFMzZFFpNwauvkegAshaOceehSfDNvkOBCTHYdhfOhCTMqTsDUompXOUWiHewHpobhaZBsUtUbLaRbXlNDTPUIFwzqxqbONYzkwTjNvoBmqPEkgAZQVtXreXZAwjecHLryErHwDrXLbSucKcCxiSllJQuARBTNVZAPMfYUOmfWXnpH");
    int mDxPWSrAMlDyo = -1599965043;
    double SbhYhKtlqM = -227780.42033566668;
    int DBHAsodNtePeYHw = -97236878;
    bool TAPMUKEgFDObNmuI = false;
    double GYEbwgeR = -694797.7667902672;

    for (int yKEDepKVyt = 1671333102; yKEDepKVyt > 0; yKEDepKVyt--) {
        TDKnpVJklxEeO += mDxPWSrAMlDyo;
    }

    for (int Ckcqyna = 1036939879; Ckcqyna > 0; Ckcqyna--) {
        continue;
    }

    for (int IykanWwAiAlK = 1554718994; IykanWwAiAlK > 0; IykanWwAiAlK--) {
        EfvaZEvYyjt += EfvaZEvYyjt;
        EWYIcQVU /= GYEbwgeR;
        TAPMUKEgFDObNmuI = ! CLzAsCK;
    }

    for (int dUTBCfsNjzFwhJP = 1849963400; dUTBCfsNjzFwhJP > 0; dUTBCfsNjzFwhJP--) {
        mDxPWSrAMlDyo = FYIzMFlfCrhEpx;
    }

    for (int LsAlyqfioU = 686849297; LsAlyqfioU > 0; LsAlyqfioU--) {
        TAPMUKEgFDObNmuI = ! GPyPNMVvAn;
    }

    for (int JGiTcwucfUG = 169312233; JGiTcwucfUG > 0; JGiTcwucfUG--) {
        CLzAsCK = ! GPyPNMVvAn;
        RndaSXENwFy = EfvaZEvYyjt;
    }

    return TAPMUKEgFDObNmuI;
}

int FRDjWuNQj::qavUNyReqFFrlGp(bool SkAHh, int ltIXghfCgwS, int DjSdtBGkQodsoxp, bool dVHmsWAmrYNoO)
{
    int oabQWJP = 1950754310;
    string MHVQKL = string("TkNmTUpoLpJmSOcIkTQusXapHWdsfqCnffFLisYAhjzQYGwXHuZXIsepMiuNLFXtHzatHUkfgWdoKSpzHHDieioolIgmzrAJBWcNdhYXGMDHgAoEfCZruNKUwEzXBlumiFnjwtLvXODlyquZnxwfvYbJPlUBufUEXWocIacWEZcyZgJoTRkKYcnnTwAbfIlLUsyeREUZyfmwk");
    int FBqYmY = -741996906;
    bool UwdWm = false;
    string fiYcfLr = string("YqxeZMPyaDGGRNolXMeUhTVRyhmuyhmYuYzGFjJpWucbDNbvrTrYAIEEDDqmiArhcXCPxznUCEAVBYLuPcOpbQquOQsjQYezZYSbxqJMvYNXronooFjOypEhVJdhBfcXRQXUOtbggxunfEbTNTALlvMQmeXfKqeLhoxNsKwGrgcqcYzTpetKpAfgQdmOFHXdiCbgLtkpkzLHVOgiIadLUvugZfHCquaLbbIXJttkBrYBD");
    int OFEARnLovg = 723481127;

    if (oabQWJP <= -1992874507) {
        for (int CxqZDqvTxhHizF = 1852017339; CxqZDqvTxhHizF > 0; CxqZDqvTxhHizF--) {
            OFEARnLovg -= DjSdtBGkQodsoxp;
            FBqYmY /= OFEARnLovg;
            MHVQKL += MHVQKL;
        }
    }

    if (fiYcfLr > string("TkNmTUpoLpJmSOcIkTQusXapHWdsfqCnffFLisYAhjzQYGwXHuZXIsepMiuNLFXtHzatHUkfgWdoKSpzHHDieioolIgmzrAJBWcNdhYXGMDHgAoEfCZruNKUwEzXBlumiFnjwtLvXODlyquZnxwfvYbJPlUBufUEXWocIacWEZcyZgJoTRkKYcnnTwAbfIlLUsyeREUZyfmwk")) {
        for (int bhvpgfb = 604574182; bhvpgfb > 0; bhvpgfb--) {
            FBqYmY *= DjSdtBGkQodsoxp;
            oabQWJP *= FBqYmY;
        }
    }

    for (int pFuUxqO = 2118831348; pFuUxqO > 0; pFuUxqO--) {
        continue;
    }

    for (int TbzpozRK = 1405907844; TbzpozRK > 0; TbzpozRK--) {
        OFEARnLovg += ltIXghfCgwS;
        SkAHh = ! dVHmsWAmrYNoO;
    }

    return OFEARnLovg;
}

bool FRDjWuNQj::PVZHHUaXzSleCEfC()
{
    double oqFAsrN = -853695.6931445469;
    string QRexpecUmIeMXDvg = string("gtwGuYuQyNXnmSNMyOmbQtbHpMIJvLomqlmZivBEptatxhWIERVGknzzVLkqbbgohCHRYQuAESYytrhIpmrDnImQvVBQIqBjBXAShsbFGjSnNuYVcMZXLugAzAagpZhOHsMxnRcYbHFsmQed");
    string coMCiXtVl = string("UqsZqjaBefggVEvLFxlGQzCcwnsyYBBWcykdkKuTtarOOkvxEnrFRVzTthPQTrSAyAwKe");
    string zphNNEaU = string("OBZOoipUqarxUPiiPDJEtqEsQqIXdAuTQlEdoDIJgtWhMRYTBIdbvVESjDTxORhDymQyDmWTinmQPPSrDGDZBettudEktYGseEEcGChuHIZFVBUYIjtkmGCjxSxvmNFnwbOgPmk");
    bool YQnyELKMwsDQqX = true;

    return YQnyELKMwsDQqX;
}

FRDjWuNQj::FRDjWuNQj()
{
    this->ZYdJzEOxJpanB(false);
    this->raqSDQoQHPC(string("MMuDlwkEcexPidbfDPjQtDSUEfkeYoKErQTBCpbhrEgaFBMXiQyEgWOBlLLXTwcvqZdGGOTmhyuGEK"), string("YuLugKpKKOjFsPCpGHExaTOuteyhVknuIpGlPgPWsmVoNFNrYlFgPCFmVZSgFNsruIKJVKoKrEvYJY"), -439717.5347271331);
    this->GDFDRcnYpEsghwi(100809060, string("jZqulKftBZcFvvThmojclNzEWgKaRQKDDzWWlqEfIXPSClUCYDCyCoVYlfmUHZNnmsCSUjTFOBsHsIOHavUuAMUmUdZOsBdufHtrgjGGVmNIfuanEaiirlqxYbRoSuUXwAgSHXZxOFjeacZrNlbIphTiEwXeOIMqmRgkI"), 808702.7325062301, 721506.1441032204, 272948.41661312967);
    this->DesNwqKXPGIZG();
    this->TeLvGBlnwAmDyu(-919622799);
    this->ZojRJsc(635333.6620043054);
    this->vMIsxnmaWH(415399.6813300873, -421088924);
    this->qavUNyReqFFrlGp(true, -1992874507, -480361925, true);
    this->PVZHHUaXzSleCEfC();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OJSlzT
{
public:
    string sjelSIAUqM;
    string wSTNH;
    double ZXARQc;
    double iOBZEpTTp;

    OJSlzT();
    bool cSBlmeMwRImKCq();
    double OoKdznUxiAPR(int xKdrV, int NfrDLkWWbQElK, string UBTCXaJ, int qqOPwLZQOwDk, bool tpJSByleqdR);
    string qAfUtMsxwGuHTOUB(double lhYWjXHRQLqhsmha);
    double RHsAGVUFbmYSuhk(int gwYjqHawzXFH, double ICBLTOsBslqCfb);
    void slwxBrroMRY(double wipxW, bool ziUmOXE, double EFoxPnszp, double NeyfTqTcJAvGh, double STrzggYSCtG);
    int TFkkLauqEbhFeHe(double ntnXhcoNkDdJIcs, bool JljhuEiFXfe, double yxMOTasifD, bool igAVdctlQXEdPX);
    string dPDDHUEWALVkYVUi(double cKHYgPRApi, string gcMgnpYYx, string EOOLodzN, double EdgwBuBBSNK);
protected:
    int RVmGp;
    bool FvRRuspUnedKU;
    int AzOIsaoqlTPAudXz;
    int powyqiZOecJhgcI;

    void ajrvSoDv();
    bool IRStTnDjirJpkhg(int olIybCKXkByo, int teHyjFSdWQEvLe, int gueyONkGwCXRSZRG);
    bool CUywkUwaMIkfGRkA();
    string Yryrqia(double bLlvSIwJiyCY, double AVjoDtuUL, int fKcfkMc);
    int zpkwNsNH(string RgDuYk, double sltswrAFJEjUYsSK, string aiyHjgRnOMR);
    double RInDigkLU(string HUBqyMDylngD, string llAXXp, double GAgVh, double aiiqxgoFqht, double zzwqHpfOExeP);
    int psSzvhRlGDwef(string iyUsGapbmvkB, int qEHUWQiTdvjJHSpt, int XhSzq, int gULJVk, bool UVTtcwcYCPSLiGdO);
private:
    double gCYdC;
    bool qwLHbYDPEiI;
    int hWYwMhtkyRdzkmn;
    int OWKJg;
    int YhtZAIcT;

    bool lFeKvXnFjnmYbycW();
    double gQamuEUBIr(double vspjrBVjD, bool fvKGxkxyNHK, double DLiArqvS);
};

bool OJSlzT::cSBlmeMwRImKCq()
{
    double kCPmbhhL = -734660.0115116426;

    if (kCPmbhhL > -734660.0115116426) {
        for (int kabfPjT = 1836461305; kabfPjT > 0; kabfPjT--) {
            kCPmbhhL *= kCPmbhhL;
            kCPmbhhL += kCPmbhhL;
        }
    }

    return true;
}

double OJSlzT::OoKdznUxiAPR(int xKdrV, int NfrDLkWWbQElK, string UBTCXaJ, int qqOPwLZQOwDk, bool tpJSByleqdR)
{
    bool nPiQNEYTtEOfKSp = false;
    int wCPXSmUutus = 171435344;
    int UbAlEZjWt = -1186920779;
    string rrqUYfTboKbl = string("iYRzQFViOMixdRVfEZnjObQIdhcPZCzkIQhJHxVzfPZyYgIKloAfMvsMOtylQwiCeXnPrqXrEqZRWIhzLjzzSOCshJKbcAgrFAqnvak");
    double TzclkhBBmNQcgHho = -747173.177753852;
    int FKLdvTSVirquLt = 258716396;

    for (int eAbImrDvcsTancq = 720422240; eAbImrDvcsTancq > 0; eAbImrDvcsTancq--) {
        FKLdvTSVirquLt -= xKdrV;
        rrqUYfTboKbl += rrqUYfTboKbl;
        NfrDLkWWbQElK = NfrDLkWWbQElK;
        UBTCXaJ += UBTCXaJ;
        NfrDLkWWbQElK += xKdrV;
    }

    return TzclkhBBmNQcgHho;
}

string OJSlzT::qAfUtMsxwGuHTOUB(double lhYWjXHRQLqhsmha)
{
    double bwpiPsQHdvdR = -892055.4298423474;

    return string("tAiaLcHRqgowSTDYyQRvbxgxwfLkFqwKyxtrBlptEQcaFvHTVrYjRnGgHvmNzARLtGrhlPPQjUqhOfOfKrNdtqNyyzXrXhIdAqvdTTNBZjcIkpUT");
}

double OJSlzT::RHsAGVUFbmYSuhk(int gwYjqHawzXFH, double ICBLTOsBslqCfb)
{
    double wEPgNNhn = -864394.8412783315;
    string rVPpouvcKFOK = string("qOnyquqTglyBpNkIlRnFPmLdDkAvuFFdqqWxjfLKaKgOHfiYtbHOXOcodoDjESDjHUHLtYOrKSinLcsLPWebOTSpzDGDQsraTWEQfarTOgMloflrnySDldCtnAEWXDnfyHisvmZFVdQKRtjoRLCXfCZfgzvOmZlXUfwHRHdGYqNVYaRMRwEgHIEITwYokvCEiZAfUieSMPyOBATwKJIkFgsq");
    int ACHzab = 23411224;
    double wcVFJpBotROV = -1043329.2629304872;
    double uGKwMqcmuxOcigW = 252276.94345985696;
    int FXfZLJcq = -773467230;
    int LapgS = 542052817;
    double ktYPBwfWL = -620825.7728410814;
    string iyshxhQSwRSPFW = string("eypmKwysTsTJViDYLYprDZLKpsQXajyMgRwOcpDgmwPDYqywIrgHkACtvaWHwmjkZZhNKVnnYQeSGHGTWMBgknlDrogopHeKucUDmbHSPWQahkWVrNxAHfCCRnmVbHOjzcEWHYlTKdsHJKecJSgGesNSsanaaqBjlPjqqHZuSoCNoH");
    bool bVmfeaLSjfdK = false;

    if (wEPgNNhn >= -1043329.2629304872) {
        for (int YMLunLkZSNlDjh = 763636713; YMLunLkZSNlDjh > 0; YMLunLkZSNlDjh--) {
            FXfZLJcq *= gwYjqHawzXFH;
            FXfZLJcq *= gwYjqHawzXFH;
        }
    }

    if (ktYPBwfWL == 252276.94345985696) {
        for (int dnOPnSmxqYXqmL = 1983562757; dnOPnSmxqYXqmL > 0; dnOPnSmxqYXqmL--) {
            ICBLTOsBslqCfb -= ktYPBwfWL;
            gwYjqHawzXFH += gwYjqHawzXFH;
        }
    }

    return ktYPBwfWL;
}

void OJSlzT::slwxBrroMRY(double wipxW, bool ziUmOXE, double EFoxPnszp, double NeyfTqTcJAvGh, double STrzggYSCtG)
{
    int bHOVPUwrOLAco = 1897683399;
}

int OJSlzT::TFkkLauqEbhFeHe(double ntnXhcoNkDdJIcs, bool JljhuEiFXfe, double yxMOTasifD, bool igAVdctlQXEdPX)
{
    bool MFhWutOe = true;
    string Okhkvlk = string("oiSBLaOItSQvhoRkdNiDhnkRQMDakKdIepSiSPyZUGEbgAdhELYSilzrrFQSjqzHIJAejkCYvzuESNhWHoBhYtjJYlpziqlYuaQFWawAChkyVaiWKWRhqFdvgUFInpnpRbkhMvaPRwsiUJUAcBn");

    for (int GYcOxK = 700746160; GYcOxK > 0; GYcOxK--) {
        ntnXhcoNkDdJIcs -= yxMOTasifD;
        yxMOTasifD /= ntnXhcoNkDdJIcs;
    }

    return 679124969;
}

string OJSlzT::dPDDHUEWALVkYVUi(double cKHYgPRApi, string gcMgnpYYx, string EOOLodzN, double EdgwBuBBSNK)
{
    int veQMInxaIBqLK = -920900213;

    for (int KlTdYqhL = 891620440; KlTdYqhL > 0; KlTdYqhL--) {
        continue;
    }

    for (int HmwiDLmB = 1951530911; HmwiDLmB > 0; HmwiDLmB--) {
        EdgwBuBBSNK += EdgwBuBBSNK;
        veQMInxaIBqLK *= veQMInxaIBqLK;
        EdgwBuBBSNK /= EdgwBuBBSNK;
        cKHYgPRApi = cKHYgPRApi;
        gcMgnpYYx = EOOLodzN;
    }

    if (cKHYgPRApi <= 416154.7531246518) {
        for (int qpQPBnekYqxwyK = 251724587; qpQPBnekYqxwyK > 0; qpQPBnekYqxwyK--) {
            continue;
        }
    }

    return EOOLodzN;
}

void OJSlzT::ajrvSoDv()
{
    int qimvc = -226975986;
    int mIemZyBFRkwxDWK = 1174066198;

    if (qimvc < -226975986) {
        for (int BuPsexq = 1449408269; BuPsexq > 0; BuPsexq--) {
            mIemZyBFRkwxDWK += qimvc;
            mIemZyBFRkwxDWK = mIemZyBFRkwxDWK;
        }
    }

    if (mIemZyBFRkwxDWK <= 1174066198) {
        for (int lxhmCiIf = 663387686; lxhmCiIf > 0; lxhmCiIf--) {
            mIemZyBFRkwxDWK -= qimvc;
        }
    }

    if (qimvc <= 1174066198) {
        for (int cqGEuDNp = 210019403; cqGEuDNp > 0; cqGEuDNp--) {
            qimvc = mIemZyBFRkwxDWK;
            mIemZyBFRkwxDWK = mIemZyBFRkwxDWK;
            mIemZyBFRkwxDWK *= mIemZyBFRkwxDWK;
            mIemZyBFRkwxDWK /= qimvc;
            qimvc = mIemZyBFRkwxDWK;
            mIemZyBFRkwxDWK -= mIemZyBFRkwxDWK;
            mIemZyBFRkwxDWK += mIemZyBFRkwxDWK;
            qimvc -= mIemZyBFRkwxDWK;
        }
    }
}

bool OJSlzT::IRStTnDjirJpkhg(int olIybCKXkByo, int teHyjFSdWQEvLe, int gueyONkGwCXRSZRG)
{
    double ZthPPMIfsQyWvrb = 228997.21895420802;
    double UgcCFOpsV = -123174.82593277369;
    bool LXpezNuBGLLDxua = false;

    if (gueyONkGwCXRSZRG == -1713540556) {
        for (int jalvMwHpfqT = 2141644736; jalvMwHpfqT > 0; jalvMwHpfqT--) {
            teHyjFSdWQEvLe -= olIybCKXkByo;
            gueyONkGwCXRSZRG /= teHyjFSdWQEvLe;
            olIybCKXkByo *= gueyONkGwCXRSZRG;
        }
    }

    if (UgcCFOpsV < 228997.21895420802) {
        for (int ZNzojSgoQbL = 1579583759; ZNzojSgoQbL > 0; ZNzojSgoQbL--) {
            continue;
        }
    }

    for (int RsWCTQqs = 233085868; RsWCTQqs > 0; RsWCTQqs--) {
        continue;
    }

    for (int ZYWdKkCYbNupZEh = 2061819919; ZYWdKkCYbNupZEh > 0; ZYWdKkCYbNupZEh--) {
        olIybCKXkByo = teHyjFSdWQEvLe;
    }

    for (int ZjvcEulafdM = 1220738909; ZjvcEulafdM > 0; ZjvcEulafdM--) {
        olIybCKXkByo = olIybCKXkByo;
        teHyjFSdWQEvLe = gueyONkGwCXRSZRG;
        UgcCFOpsV = UgcCFOpsV;
        teHyjFSdWQEvLe *= teHyjFSdWQEvLe;
        ZthPPMIfsQyWvrb /= ZthPPMIfsQyWvrb;
    }

    return LXpezNuBGLLDxua;
}

bool OJSlzT::CUywkUwaMIkfGRkA()
{
    int cuLIvZPHLvczAAY = -614519220;
    int ZBhtXCkbsu = 355543719;
    double eSlyYjPvhS = 800855.9156883406;
    bool FlmoJhamq = false;
    double Pgilr = -862533.0683523332;
    bool XgpRXRnrOtvPZBiy = false;
    bool qqqFZDVrd = true;
    double uKFwFjUZ = 630133.4907004981;
    double WhVba = 375815.6727637611;

    for (int bTLCeQmOyAXDU = 457155746; bTLCeQmOyAXDU > 0; bTLCeQmOyAXDU--) {
        FlmoJhamq = qqqFZDVrd;
    }

    if (eSlyYjPvhS >= -862533.0683523332) {
        for (int ftrjqRJfkH = 1289216149; ftrjqRJfkH > 0; ftrjqRJfkH--) {
            FlmoJhamq = ! FlmoJhamq;
            uKFwFjUZ /= WhVba;
            Pgilr /= eSlyYjPvhS;
            Pgilr *= uKFwFjUZ;
            ZBhtXCkbsu -= cuLIvZPHLvczAAY;
        }
    }

    for (int ezmYfvXxrBWAlLOh = 560649806; ezmYfvXxrBWAlLOh > 0; ezmYfvXxrBWAlLOh--) {
        continue;
    }

    if (XgpRXRnrOtvPZBiy != true) {
        for (int fTeeQIxm = 1256074949; fTeeQIxm > 0; fTeeQIxm--) {
            uKFwFjUZ *= eSlyYjPvhS;
        }
    }

    return qqqFZDVrd;
}

string OJSlzT::Yryrqia(double bLlvSIwJiyCY, double AVjoDtuUL, int fKcfkMc)
{
    bool xfXcX = false;
    double KdCKErHDcbYTxn = -60597.35237046499;

    for (int MujQvZyhcULUgDEw = 708564877; MujQvZyhcULUgDEw > 0; MujQvZyhcULUgDEw--) {
        AVjoDtuUL *= KdCKErHDcbYTxn;
        bLlvSIwJiyCY -= KdCKErHDcbYTxn;
        bLlvSIwJiyCY = KdCKErHDcbYTxn;
    }

    if (KdCKErHDcbYTxn > -401540.71556732786) {
        for (int JxYuvRUhqqdgbjF = 2102445867; JxYuvRUhqqdgbjF > 0; JxYuvRUhqqdgbjF--) {
            AVjoDtuUL += KdCKErHDcbYTxn;
            bLlvSIwJiyCY /= AVjoDtuUL;
            AVjoDtuUL /= AVjoDtuUL;
            bLlvSIwJiyCY *= KdCKErHDcbYTxn;
            bLlvSIwJiyCY += bLlvSIwJiyCY;
            AVjoDtuUL *= KdCKErHDcbYTxn;
            AVjoDtuUL -= bLlvSIwJiyCY;
        }
    }

    if (KdCKErHDcbYTxn < -60597.35237046499) {
        for (int MyqVSTTAMXqoP = 883316540; MyqVSTTAMXqoP > 0; MyqVSTTAMXqoP--) {
            AVjoDtuUL -= AVjoDtuUL;
            xfXcX = xfXcX;
            bLlvSIwJiyCY /= KdCKErHDcbYTxn;
        }
    }

    if (AVjoDtuUL == -60597.35237046499) {
        for (int jxtmfWEyQUnDbqcs = 2136013848; jxtmfWEyQUnDbqcs > 0; jxtmfWEyQUnDbqcs--) {
            AVjoDtuUL -= KdCKErHDcbYTxn;
            KdCKErHDcbYTxn *= AVjoDtuUL;
            KdCKErHDcbYTxn *= bLlvSIwJiyCY;
            AVjoDtuUL *= AVjoDtuUL;
            bLlvSIwJiyCY -= KdCKErHDcbYTxn;
            KdCKErHDcbYTxn = bLlvSIwJiyCY;
        }
    }

    return string("UHTacimOVtOxXBHaeEXZyRFkcmRSLRBASfUuTeFEPbYymklPvTgVEalkDpKnYyiDcYtdHEuytTjhuohBokjcyjqqfXkkoLIcriXBvowuqFfsFSxEVPlwPtAETMwMYTUlxFsaSUzwzokUKJqNTZIlUiQgietcVKaJNEhjXppQdltmJBFVCbuvn");
}

int OJSlzT::zpkwNsNH(string RgDuYk, double sltswrAFJEjUYsSK, string aiyHjgRnOMR)
{
    int ssSrzaTYeJWPpLc = 1673977736;
    int fmOYIIxgG = 782856966;
    string vFuLgBDHIheRmLp = string("jeSJSyphSjYqFEuooqrtzRENYkJMZgFjUcXNIfwFJiRHLtQcksRzyjBMzbXjFG");
    double BrGbQL = 765695.8325364422;
    double nmDCX = -808215.6349243079;
    string wfHlcvoLRYcuYlc = string("ZplGUgfYrwBbOKxdQVqdOHCyaQHNcaJZqUunHIRRLkkjzwkijNPMYPqfWRNGDiQbyJQyOLvAiYRmtujqJoOllKTIPSrJYfuXmpGYDtHgzgpCKjSeAzkOBICNxCWhMIqVNLkkrqyhlwjWJqwaZFdkTzqOdQejITJuZZzOAeTkCSytyetmoGPmCsgrniaKIWfqbYJCUUSZqnyqYWnOJHmpLWLyjQyPDjilhZCUHolnmGpqUKEWKryiokRbFfrPSC");
    string HkyuBCPDbjn = string("VuszBvnmHuZBrHBKHHwqcFNrSYfnHNWejoqhDpGsoOLqkCGbWnCkJoxcvsNbGwamHsmyqLKqMRXOVKDlaymZaWfQhSSkevNcDJWdEwsnLfDtoNKfmMrFnluMCJHbQzzxfDWEySaAXpDppSdesbvWzGCafslYrfzHHgRbsGDNpdScVjOyXNTLTJFSNwgnTOUtH");
    string sFtAkbEkmOmG = string("TvsiFgKJSUmTvkhUiTgEjQXVcBlGgMGJTasefPbZLvSIEOOghDdjWKVHMAwHCfJZAsKiKLYjHvdjrlopCtkbJUldKdVOKzGrofbklOGKpgRkcuPOZThqemTuGoqxadNpslXqynzuAwrbdgQyTySRpqayyvkDsJpuEQIWVDVZKgMFKTwqnAEDrTWSsCjFhLRfTFWDYBbhKzQMkzUoVPpxWpCrnNSikvDNjOXgBvjwothyNPlGnbyitn");
    string NGUrDM = string("aBUzMvZBbznhgxyiykjLCqEdZeAPReKofhLpzOunBixdZxYBuVnDOdEdEoLFewItgOSOSdniBeqCskVzelUGaPCHnTAOxPOGxtNjVOPnBQwEtGPbvLMeAQbUFRmwmPYiIJhHHsVTEBUbaSIZyuRraXnwFAvTcOrnvYqwONsLzsqfReCCADqesMchkThEIBrOlNjFFANKEGHArvtQSQZHiQuYw");

    if (HkyuBCPDbjn < string("TvsiFgKJSUmTvkhUiTgEjQXVcBlGgMGJTasefPbZLvSIEOOghDdjWKVHMAwHCfJZAsKiKLYjHvdjrlopCtkbJUldKdVOKzGrofbklOGKpgRkcuPOZThqemTuGoqxadNpslXqynzuAwrbdgQyTySRpqayyvkDsJpuEQIWVDVZKgMFKTwqnAEDrTWSsCjFhLRfTFWDYBbhKzQMkzUoVPpxWpCrnNSikvDNjOXgBvjwothyNPlGnbyitn")) {
        for (int IWuck = 1937490270; IWuck > 0; IWuck--) {
            RgDuYk = vFuLgBDHIheRmLp;
        }
    }

    return fmOYIIxgG;
}

double OJSlzT::RInDigkLU(string HUBqyMDylngD, string llAXXp, double GAgVh, double aiiqxgoFqht, double zzwqHpfOExeP)
{
    double PcNqiVetyo = -132468.54626577508;
    int EFHYfejdobb = -158363105;
    string YKRbdt = string("FNyrJemUAHJLUHQFOmRWLzaYScJJWyzVZYhCPsmbqktpoImhhaFnK");
    int EBDLv = 805126931;
    int QIUdnPssGBUqMfKR = -1954409242;
    double yuONr = -4243.368745021043;
    bool LfJXgXrV = true;
    int HCwvBPjMBv = 2132663699;
    string arfLjMJAbrQHPB = string("QcZtIBiAFuZmKNXNhAsscKaLPahZSqK");
    string QtVJdyOedPLuCM = string("AwWYAQOfzxvIXDwlEwdxoecHQVokQmKacrASjpCXLaOnftiaakJjkPtbbrCGQqkDpZCEmhCCspRmjFiqqZKWmCTBQytLDheHDYhsFkFZWRVHUCfmobjFBDvyKqjBughbhckSxiErurmGIHvih");

    if (aiiqxgoFqht > -919064.3678233596) {
        for (int qfAQpKRxIp = 1518462658; qfAQpKRxIp > 0; qfAQpKRxIp--) {
            EFHYfejdobb *= EFHYfejdobb;
            zzwqHpfOExeP += zzwqHpfOExeP;
            QIUdnPssGBUqMfKR *= QIUdnPssGBUqMfKR;
        }
    }

    for (int CvbPLH = 1159455324; CvbPLH > 0; CvbPLH--) {
        arfLjMJAbrQHPB = arfLjMJAbrQHPB;
        QtVJdyOedPLuCM += HUBqyMDylngD;
    }

    for (int ufkutVLYmrxIbbM = 1768781735; ufkutVLYmrxIbbM > 0; ufkutVLYmrxIbbM--) {
        continue;
    }

    for (int WDOXMvVILmcGiNbB = 1408168497; WDOXMvVILmcGiNbB > 0; WDOXMvVILmcGiNbB--) {
        HUBqyMDylngD += QtVJdyOedPLuCM;
        zzwqHpfOExeP = yuONr;
        EFHYfejdobb /= EBDLv;
        arfLjMJAbrQHPB = YKRbdt;
    }

    return yuONr;
}

int OJSlzT::psSzvhRlGDwef(string iyUsGapbmvkB, int qEHUWQiTdvjJHSpt, int XhSzq, int gULJVk, bool UVTtcwcYCPSLiGdO)
{
    double hJNaABEMJuuszD = -637827.7519002206;
    bool xiscADYCtzSif = false;
    string lrYTHIjFtWdh = string("pRLlchWcVJJoBYTdLTRFDDZjIFPKXMSaJFJyHfZqfPaEsTwzqZcxcDMvkLHiHwbswjiRRJXJprtBoesBHzZbukSGeozSCJEguYHjrxKBBNNYvvNgvytlytTGPpczsl");
    int GSANh = -2019218611;
    int GbAwPDZZoTvx = 2059239442;
    double WTceMIdnX = 340504.4841366434;
    bool qVuuj = false;
    bool zxJfiRRLtARiBKe = false;

    for (int KQXCLTIDUtDOlB = 1420712614; KQXCLTIDUtDOlB > 0; KQXCLTIDUtDOlB--) {
        GbAwPDZZoTvx *= gULJVk;
        gULJVk -= qEHUWQiTdvjJHSpt;
    }

    return GbAwPDZZoTvx;
}

bool OJSlzT::lFeKvXnFjnmYbycW()
{
    int NqQjucYfg = 1744951689;
    int yiXhuHEGTv = 1371275744;
    bool MQbFfQMlJxTwo = true;
    double oJrhCmArtNK = 311498.009867702;
    double XCntFR = -429192.09551101393;

    for (int OTCEbbBJRlLR = 1246128108; OTCEbbBJRlLR > 0; OTCEbbBJRlLR--) {
        continue;
    }

    for (int nfpbWbPtTfWT = 1881975971; nfpbWbPtTfWT > 0; nfpbWbPtTfWT--) {
        oJrhCmArtNK /= XCntFR;
    }

    return MQbFfQMlJxTwo;
}

double OJSlzT::gQamuEUBIr(double vspjrBVjD, bool fvKGxkxyNHK, double DLiArqvS)
{
    string hHhcSOuCf = string("sZmWCePIDKIbrycwvcRSrqxPdekRJPzWTrvNlIMgFUadYhTtbXCXGJOALVn");
    double dLLZPfnDVNmu = 222599.72504475567;
    int HJZPHfxpvG = -845920904;
    string fLYOxl = string("OytHrXEoEHSUJEvtnntMAMjjIVmVxoomQJtAzJSoJqmJBMIGvhBJeccvcvSwxeTRuaNBOHio");
    bool kbeTfwS = true;
    double ltqcydIFD = 202581.35964184735;
    int dJYQWvgbpunNIPq = 412177891;
    string dRidjTu = string("aolsKuritsSpQyugxtDXyLCRcfOyaJjZtPZgfTXTqvrzLtFQhrOqDUVSWiiGIPnlorMIRGAfApVXRYYxMynizQwdjvFYVZp");
    string bctdNYQ = string("nhoHIeOkmiCFmmePyasExtBSNBwSmXMApjUeigipYYColtMLgMUuegiRNCIsAjDFadzCGKxxoYcmvIgNSMsBnIStXpLzYAJXOJDZIahpbpBxYajlLJgwJKgYsARbCDtOFaEnDzBGDojjlgpYMeCnlvvCBxSACajConaPuUiaMrrgHYnRXQwOXYZgNgzXAFMlORccRfImnoTgqkTpHtryVCuAvOvkMGVNYyvgTtZwrPtRRDRX");
    int lVySYR = -256858225;

    return ltqcydIFD;
}

OJSlzT::OJSlzT()
{
    this->cSBlmeMwRImKCq();
    this->OoKdznUxiAPR(-2105445226, 1485261208, string("SvQxgsErAqxSCKFqVrsDoKrZFZGxJxSmdcJQuUmEKYooMYSfgFhuuQlkMpHcSNynqgXhGgoribpJomaoafUpcJaKsESASZoMiUfgssJWnXQVbomlqYMvFYvPiRMKHwEgNDmDkWnyepktEMKCdjvcvjXqpwSSwAyyPdYybySMBwlqhymZgmMclnmfEgWASRIuKKXhMRQ"), 814938881, true);
    this->qAfUtMsxwGuHTOUB(-348551.77723671077);
    this->RHsAGVUFbmYSuhk(320447578, 686900.9705592393);
    this->slwxBrroMRY(-752464.2835335301, true, 186547.81927727547, -396828.21580129734, 630185.1658018525);
    this->TFkkLauqEbhFeHe(-896528.7805264611, true, -774251.6528146839, false);
    this->dPDDHUEWALVkYVUi(-525159.7336639664, string("ZIkGBgQBjwsIDpirHimvOfXANCppwjICWMFHKZCqtplKmYuhsqjbbXTkXREIDwhWefHlMIdzzOcvxTfIVlQvXalVCwvjxzsQbxnCmdBKQAWlCfGxEBMAZUfewLl"), string("drHUtOEwHZHUgrxmlmNKTrYszGgHDgFGMwEFIbquUlboohoczOGmwgvIKGkwyZagmGEdkBjGVNqcesAunZaUeZhcGsOwfFhbiPSWuENdyBslylVcSEjxwGYtbowYSye"), 416154.7531246518);
    this->ajrvSoDv();
    this->IRStTnDjirJpkhg(734531108, -1713540556, -1237104105);
    this->CUywkUwaMIkfGRkA();
    this->Yryrqia(259498.60355696728, -401540.71556732786, -1461503781);
    this->zpkwNsNH(string("htFPqnxhvOlmqOoJJgNoqQlFdIPcBptdGVhLOGymBmvGTgFgFVRZZWAJqTuaCeTwzxWGgZNCaDIjMAxTYQPxDuBcdvfIMNqRhvyvKxYVMrEaqHCsuaOpmuMvtwweZJ"), -125156.00187146664, string("ZRvYvSIQNIdyOuiY"));
    this->RInDigkLU(string("cjonlnFkcvCQeHWTnxhesSIpdLJSEgzKqzHwUulQXdkxFolOMVzQgYkIzvwIHDUxiiLlLhMMRxeCfQIGMSnNRt"), string("iHoEMUfUgTcdshPGGswgMydqaYuHbiTddaqbtFikjJhLgxQeGARvsXjTSrHdcJMYKpHPxsjNOlQVXEdCSrVgAHZmmgcIWmoqftnpYBPdEYLMEmo"), -604426.045887824, -919064.3678233596, -222754.5317886961);
    this->psSzvhRlGDwef(string("ERDOZDGDWTiBmAsIWxdOvDGLRtIPRRKZjLHyxlqXXxrsDyIFSbVaapjYGkYnUwbKmUUdYjAbYZrzpcOgWHQqsqYqhQrbQvYhRXsabNTIqdakLXANtPgcxJLkpzNnTJwMzvgDGpHfppOBoLfMsIfRYStjaooWtJDCjhrhZPhWjxRhOk"), 590392725, -767075547, -1725338388, false);
    this->lFeKvXnFjnmYbycW();
    this->gQamuEUBIr(-822756.0932895234, false, 553907.0291113001);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class smedbMozbkJolCc
{
public:
    int QSVOrBQPrcUQdAo;

    smedbMozbkJolCc();
    double mPBTQWXEpFKZ(int KEGnpdVWzHjXZ);
    void lrABSbCbkvBoBVV(int FFlbEtVqvzC, bool RacRrPDkvDjQW);
    void pLPqe(int hnVefQgUbh, bool SzrgDImuOcK, int FPThNFG, bool VzJPCwUuWvpLxDl, int SXVhzTkRHVq);
    bool cNhnfMbPkRHwjjwh();
    string wlQifcaxrRpDkB(bool kqtaAZvA, int YzoWDlig, bool xylzLjwdT, int xhZcb);
    string NbWFFrFsm(int tZkuGDHNJWWKjx, int ARhlRFfXFs, string KnINUCrIWZ, string dEwRQldV);
protected:
    int TQspszeCAkMckgXo;
    bool DAWZLuqMyCG;
    double pXxAoNVaMqpkua;
    int QLNqVZZJbWF;

    string ZewMoHxd(int KWugbFSecb, string TrWYCQQQooBOZOxt, string TPeQP, string HkxjXoSYRM, bool BhtQzjy);
    int CNTlNDL(int lqqczN, double iZfSFcC, string peVmAYypEiZST, double agrBEQoiIT);
    double odAar(bool esQjHMFBTYVlFXEP, bool RDFzvdzizuISZK, string NeHZyN, int KOwyXJJBbCNkzv);
    int bebuKKpCfjsNXIm();
    string heXoOutGHvw(bool RvGUJ, bool bdyfEHinQB, string kAbbxlfTQAED, int ChwRFYK, double uijtznEjxu);
    double MUggOPcxBdlzFQf(bool TmDFeiaVgJwfECfX, int Kgqprk, bool JHAmrHDFr, bool wCdIUNaNfVaDTyTx, bool PhNWOmEGzHRcY);
private:
    bool ILBUhgcrlhDtilsY;
    int iHLZXsxzQ;
    bool bXUTkhkvZp;

    string TMWdG(double hDiMNkhmaO, bool IJbtGqfEgpRmtOCn, bool ttLmtuoQduuI);
    double EkbGhTmYGAm(int fwNNi, int asZJsw, double ieuurbsDUpVkp);
};

double smedbMozbkJolCc::mPBTQWXEpFKZ(int KEGnpdVWzHjXZ)
{
    double WXwEtiW = -911436.8026342602;

    return WXwEtiW;
}

void smedbMozbkJolCc::lrABSbCbkvBoBVV(int FFlbEtVqvzC, bool RacRrPDkvDjQW)
{
    double buEUlZJw = -379015.6474843285;
    double ukwLmJMY = 18873.26584616623;
    double CvXpWLdy = 989414.3490523301;
    int cbVZsQQQTZgbAhBt = 264441948;
    string gHvDrCUnjcG = string("PBqhsqQyyMRXGJZYyVHDdUzGqpjsOKTTIMUBPAFUTDgpdUMAsYhGdloHKAPPgPYGLLFrCxLbtWnz");
    string cCqTSocxxXV = string("hndpJVPypWchhGskEagGNVEfrHnMtEWSGluAucFYgdsTPeQErkJIOTqTKSrzOnTuoZgBVzZgBVBzdMOrJENcBylOPDRnvLlZwKriKCXKnCnMryxyGjEBjujgEEFwJIhTHDmxQhehHwVoSxVffhOUKrlzDGMCkakzFHzyyIzIJtOavLukrhtzusyyTmkdPXfPXcZwAYrxPkXkQQLf");
    int KbtKcQd = -436865197;
    int IauFazDdiVIvfnpe = 150987463;
    bool KTCdYKCYNny = true;

    for (int rUGlVwYAqpFb = 1260855611; rUGlVwYAqpFb > 0; rUGlVwYAqpFb--) {
        CvXpWLdy += CvXpWLdy;
        FFlbEtVqvzC -= FFlbEtVqvzC;
        IauFazDdiVIvfnpe -= cbVZsQQQTZgbAhBt;
    }

    for (int QcuXsOUV = 1084549486; QcuXsOUV > 0; QcuXsOUV--) {
        continue;
    }

    for (int ykoKQwjz = 1768287775; ykoKQwjz > 0; ykoKQwjz--) {
        continue;
    }

    for (int SIWUaV = 1307199200; SIWUaV > 0; SIWUaV--) {
        cbVZsQQQTZgbAhBt *= KbtKcQd;
        ukwLmJMY -= ukwLmJMY;
    }
}

void smedbMozbkJolCc::pLPqe(int hnVefQgUbh, bool SzrgDImuOcK, int FPThNFG, bool VzJPCwUuWvpLxDl, int SXVhzTkRHVq)
{
    int wSWtH = -1493481175;
    string reiHJ = string("QHeoevXKlFFdzXOnWcjVxmXMhTdo");
    string LYbDNyx = string("ONC");

    for (int uRSgtQsXOO = 1987567982; uRSgtQsXOO > 0; uRSgtQsXOO--) {
        hnVefQgUbh /= wSWtH;
        wSWtH -= hnVefQgUbh;
        wSWtH += wSWtH;
    }
}

bool smedbMozbkJolCc::cNhnfMbPkRHwjjwh()
{
    double bBUasP = -554905.8736495185;
    string NToCp = string("lwbxpIcNFudbHNbMHpczsLrvQLtXYAgtAduKWkSaawqeeiwBNJCvGQokIbCXAKRQaZXbeWbIGIoILQGzGGKjcWPUyDiTNXYSvpxeMUnVOVoLzVmnCsmazyIjbpuLCikVjfUyrjCcsORDiZKksISasAZZBfJIrXbeWwWxdVMpQwVkTYiQsguwOWOTxQZxJaJvGHhZocewcnNDRLJZGunpLxfJSLM");
    int DnwIe = 1273146110;
    int lBpHRyMGLt = -54685058;
    double nvlBsxYPh = 680312.5872626177;
    int FWVXmVd = 1955547073;
    string VZWBQuieDNwh = string("zjDgdYuIwlCLFjcsseybsmVLTSLcMMDgbOSLfoWBnEzphVWlyUvCKPRDAWHIJgGALWhMyWdWObdsRKcpSMiSZsjvOJPqMolMtlzBukbIcxEMLfwnnuxoigqvljTcpwqjovgyHtRueteJsteIwOPtWBOaZYudjGKmhpfxtXFuiATUkSKZhaXWWlePzoaYDz");
    int cMezCftcItMl = -1647473668;

    for (int DmKaUyO = 442370931; DmKaUyO > 0; DmKaUyO--) {
        lBpHRyMGLt += lBpHRyMGLt;
        DnwIe = DnwIe;
        cMezCftcItMl = DnwIe;
        nvlBsxYPh = nvlBsxYPh;
    }

    return true;
}

string smedbMozbkJolCc::wlQifcaxrRpDkB(bool kqtaAZvA, int YzoWDlig, bool xylzLjwdT, int xhZcb)
{
    int TYxSXBOwoRivv = -783945668;
    double PPbYwnZk = -846722.6855064105;

    if (TYxSXBOwoRivv <= -783945668) {
        for (int eTVGAKoCLO = 832861268; eTVGAKoCLO > 0; eTVGAKoCLO--) {
            xhZcb += xhZcb;
        }
    }

    return string("oIYtaPRxbcAWAPflDOkCcIPXvkCihxAzUlwRakfXVWNHGKQpXwZsrQtbpAqhdMuuTnYqfOkVcVClkeOZlnaxzmIvkdIAvGZnNFAv");
}

string smedbMozbkJolCc::NbWFFrFsm(int tZkuGDHNJWWKjx, int ARhlRFfXFs, string KnINUCrIWZ, string dEwRQldV)
{
    string xHygWQyMR = string("ztMCuyWnUtuEkkWVkSlyucXGAaYcQgVheUMVzolqVRuuZESqIjm");
    string DWtgMJOzgsYHLYvq = string("DOqRzdXEqNyioGXKcZWPQsIoVSNaeciOywaRHMjmjwiYZPYjGdskDXhXynIoyoftZcvCtUzXEOAZwEKsJimYtADbZKFPCddNwPzxPBXgWrjpXxypncUIWZcqOoTkOgLndxoUWPHNuInyfraFtVvsBxLeNmcYAaWwpqRxaNYmCLRkVGSFHXVvfgeqULPjqCdvNogNaburcMWqQzOcvuuDWgqmZVVljIfxoJxITmEExYrrVtZWdrAmplwVZlhx");
    double dgydBzGwx = 274577.71968194196;
    string KZria = string("GriFBbMw");
    bool bqUSn = false;
    double rSYsVBpZIMe = -16781.78866481142;
    int dYTzwlPMteSFE = -1725198071;

    for (int nSiahkhqZkVHiFU = 543668596; nSiahkhqZkVHiFU > 0; nSiahkhqZkVHiFU--) {
        dYTzwlPMteSFE -= ARhlRFfXFs;
    }

    return KZria;
}

string smedbMozbkJolCc::ZewMoHxd(int KWugbFSecb, string TrWYCQQQooBOZOxt, string TPeQP, string HkxjXoSYRM, bool BhtQzjy)
{
    bool xEcWMDtvW = false;
    bool NDSmeTzxnK = false;
    bool gvScxUzpm = true;
    double GyHBEZSOB = -340965.8510202218;
    int yagBQLy = 1549002984;
    string mSNYwfyazWi = string("PejuudPswNwZmwZyULuAYaOCsYcFCDxnWyljJxzbVWhqIDTuKeoJTcNlwNtEQwvaLXUqmauPgpoiiJyyPpjnIWeDyebNcGEITIXtxdELJaLLEhruJJjhcZbalOpXpOzgJkUFLiXviWqAksmVQqfnTyXMFzqAoIkitCMGiZlOTPZVpqGmEMoCXYtwcOPaTeBOSdyYbpVxrggGZUsXPKUvSmIUQpRimVhwBwDEjVHaiwoVMgOlxw");
    double DngSEzXZcfP = 433311.00811413856;

    for (int XfebunaxoZGcyh = 246446385; XfebunaxoZGcyh > 0; XfebunaxoZGcyh--) {
        continue;
    }

    if (GyHBEZSOB != -340965.8510202218) {
        for (int HBZjrwIZO = 1387019452; HBZjrwIZO > 0; HBZjrwIZO--) {
            DngSEzXZcfP -= GyHBEZSOB;
            yagBQLy += yagBQLy;
            yagBQLy *= KWugbFSecb;
        }
    }

    for (int NBeFVuxEcvW = 1265469882; NBeFVuxEcvW > 0; NBeFVuxEcvW--) {
        continue;
    }

    for (int TQuYwjyUTYxlrE = 988015732; TQuYwjyUTYxlrE > 0; TQuYwjyUTYxlrE--) {
        BhtQzjy = gvScxUzpm;
        TrWYCQQQooBOZOxt += TrWYCQQQooBOZOxt;
        KWugbFSecb = KWugbFSecb;
    }

    for (int dAAvtiHYnsjESDH = 1547153791; dAAvtiHYnsjESDH > 0; dAAvtiHYnsjESDH--) {
        TPeQP += HkxjXoSYRM;
        gvScxUzpm = ! xEcWMDtvW;
    }

    for (int ZHULZSCKTkaNX = 2133838281; ZHULZSCKTkaNX > 0; ZHULZSCKTkaNX--) {
        mSNYwfyazWi += HkxjXoSYRM;
    }

    return mSNYwfyazWi;
}

int smedbMozbkJolCc::CNTlNDL(int lqqczN, double iZfSFcC, string peVmAYypEiZST, double agrBEQoiIT)
{
    bool EkomcktZSinmemNa = true;
    double iPXleaMaaHRmCnlx = -321285.04099747114;
    string RcGXiLaVEVkXqk = string("kIUAHrprdeSLfuSBUnxrjFLcViafTrSAGHoGTVkOjaTwoNnVyqBJJOhUBQlvgdEVofUbcmMLJGNnBmNovcZHFnuWvNWYXeIHdSiXdSdYZB");
    bool XtePu = true;
    double btQQEKzSeds = -422727.2939083211;
    double fhrhkSzYFvGhUbK = -380635.8889299605;
    double jHtlnouq = -161800.85148476655;
    string gFldawcPgFTyPmU = string("FlNBOSoyKhwBFQQAhHSbytjmobJeuUqfCyIKyOnZBDboBkalOqQPtsyNxKmazmjGertjOrLLdxBheVUDUTIacasoDxZrPDzbEWkkrsTgLPuVFQsLPVqsqMtpwLOFXwCRYIeCkbWSkQVnBhfnxSbBZuVYFJcjfjgkLStaCPfxzNpnnqpkzKPzcVBiFfRXAJELHnFPNxQnlTFdQPpHEZomAuBPbijcHlFafDHTnUOx");
    double IncwhDuVvakV = -995219.7355748976;

    for (int ACpZasYOfSMHOuOG = 1232924809; ACpZasYOfSMHOuOG > 0; ACpZasYOfSMHOuOG--) {
        IncwhDuVvakV *= jHtlnouq;
        jHtlnouq += iPXleaMaaHRmCnlx;
    }

    if (IncwhDuVvakV <= -995219.7355748976) {
        for (int DYtaebqYzPqy = 496470405; DYtaebqYzPqy > 0; DYtaebqYzPqy--) {
            XtePu = ! EkomcktZSinmemNa;
            RcGXiLaVEVkXqk = peVmAYypEiZST;
        }
    }

    return lqqczN;
}

double smedbMozbkJolCc::odAar(bool esQjHMFBTYVlFXEP, bool RDFzvdzizuISZK, string NeHZyN, int KOwyXJJBbCNkzv)
{
    int BNRWhQeranPMrs = 775898754;
    int QBVIHOqtOGxKn = -1416918292;
    int ZpBzmFPcaOXN = -1707368521;
    bool qbCABf = false;
    bool owUEAdJYZ = false;
    double OvyRDjPD = -328247.9250663153;
    string TQiFzkMRDq = string("YGDGftpkKGxGJmMuyexzplNQknDcVJkRdedwEDsXdiKSMDhHibsWUGyUUFrZrCIrNUwoUcBGpgrNnYxMAEUekmrBGTiPXeRuYupIKbJUuEupNVcnBcvvYPSAlmnLawXFtJHOsmiRZDGaaFJCElIiDzFiaYWfhIamygsFPmZSIqJrftfqZBKyCObWuupLjIp");

    for (int PdQuLTlG = 758562288; PdQuLTlG > 0; PdQuLTlG--) {
        BNRWhQeranPMrs = BNRWhQeranPMrs;
    }

    return OvyRDjPD;
}

int smedbMozbkJolCc::bebuKKpCfjsNXIm()
{
    string ciqIxaby = string("mkUWTFcCWRiXrfqyktuKgPFlkkauPpvyWgIsNprlGbzdvBmRzcjCySlurkBsinzZdXswESDBHBNaFv");
    bool OabparBth = false;
    double GNDiTNQR = 522447.8072265295;
    int crQXqEeYlLkZVXnx = 853176731;

    if (GNDiTNQR == 522447.8072265295) {
        for (int nqZCAxJ = 970854070; nqZCAxJ > 0; nqZCAxJ--) {
            ciqIxaby = ciqIxaby;
        }
    }

    for (int AxPzyMYvQkS = 978867712; AxPzyMYvQkS > 0; AxPzyMYvQkS--) {
        OabparBth = ! OabparBth;
        ciqIxaby = ciqIxaby;
        ciqIxaby = ciqIxaby;
    }

    return crQXqEeYlLkZVXnx;
}

string smedbMozbkJolCc::heXoOutGHvw(bool RvGUJ, bool bdyfEHinQB, string kAbbxlfTQAED, int ChwRFYK, double uijtznEjxu)
{
    int OqsvZXfHFV = 1014456506;
    string kTtTEH = string("HvgqvlqAAOEXGcKT");
    double QwYjADE = -629956.9143907414;
    int ZSbkJj = -1808624728;
    bool akMYIzzEbEMIEqPk = false;
    double dmQdhzggwPstIQ = -108946.22214849407;
    int QQbFhdYpHk = -1785688445;
    string IfQGhlRDULTuSCWO = string("TBAWKHPysliAfOXCvPyMzOfpahdtIqwXBbSNcimvnbgxtnIHzygcmNROrYobntCGVmRtnFwnLwyXrHybOySAUKpxpqabjSexVJpWapxTQjXKBzgYCmYXWhMMfmJJMRdjlbBBrBOzIUuBFNCFXnjAVFaFHGEaLdeypoXIirGMOmEitmlqLXqOwXyaReHjmMwhFaRAbCxctqObPpnvcldwBgpvtvNIqVatsWTUTrDDWOmfvZDlMvyEbdpSXBNY");

    if (RvGUJ == true) {
        for (int WGhLofHpkZlHucYY = 97515133; WGhLofHpkZlHucYY > 0; WGhLofHpkZlHucYY--) {
            RvGUJ = ! akMYIzzEbEMIEqPk;
        }
    }

    for (int bWifmcr = 1185969395; bWifmcr > 0; bWifmcr--) {
        uijtznEjxu /= dmQdhzggwPstIQ;
    }

    if (QQbFhdYpHk <= -1649857655) {
        for (int VMIEOfkccCO = 2051284898; VMIEOfkccCO > 0; VMIEOfkccCO--) {
            akMYIzzEbEMIEqPk = RvGUJ;
            bdyfEHinQB = RvGUJ;
            OqsvZXfHFV = ChwRFYK;
        }
    }

    for (int sqTqqErwERCiHSsY = 582925819; sqTqqErwERCiHSsY > 0; sqTqqErwERCiHSsY--) {
        RvGUJ = ! RvGUJ;
        RvGUJ = bdyfEHinQB;
    }

    if (QQbFhdYpHk <= -1649857655) {
        for (int LoaciXoiBAie = 1387908303; LoaciXoiBAie > 0; LoaciXoiBAie--) {
            continue;
        }
    }

    return IfQGhlRDULTuSCWO;
}

double smedbMozbkJolCc::MUggOPcxBdlzFQf(bool TmDFeiaVgJwfECfX, int Kgqprk, bool JHAmrHDFr, bool wCdIUNaNfVaDTyTx, bool PhNWOmEGzHRcY)
{
    int cruqXTV = -1350699923;
    string sBaeCGqREoCHAxEZ = string("RstvNeEKjqnOOEmKwXFsrAwELoZuLYrWuoCPWWQXKOAQdHjwoSBYsUaeZxRkaNLklNSxgMJVPjmrkZulxtKAIPKwBhIPNFlnlJdLLBkUeleoeztQUwLImoXozCQRiYVPhdshprGUUjkvWhKvpwcBjWlOFRWbnKiohibAwNvapcZHOgTZTmRNdWvSvMECbPkwNdkvgIZHPAEJxmUnLvaPsHKLI");
    int ZUoYXJ = -922231344;
    string fKLEdGYDvYvX = string("LpFPJjYVgxBrjJVJMgOeYrvhmsOnVwquJyVaZRLJogzBCMfBLhplJdGVGeOzWSqghOQRjVFEWNGiQjaaweYSIDXCrNZeMUHSilFIjuFrtKqSgWGhJBmmKClIXSsOJygUeCZzvmzsrtFUOQiwIKljkxzLfJkBpxIpOKY");
    double gYgvSe = 286002.3721657878;
    string ESjuAjDJFucB = string("WxtNLFsvKpBsvjhVBsFvohGPQRFcKAncOPWTrmLcjsYvTkucLJnPDgYAzTUSMbUxUjhKRZAeLtiETkcMdKQlUPXAktKSmdBQyBFPdiibEeENhjcwdVxuLUejUrIsxF");
    string KOgzEGATvSIrsPJZ = string("rBhvAIfbqYflESrjknSbO");
    double unpAYseOfk = -37530.78247779536;
    string cFaOMMIT = string("xxLTnWNHQCYDPTSMGguBQGWIhAfIfEhLySfPVzzkwEgMKLlwASEHyhDfgpbMyOVnSGQDfnGHgjeCIfwTsGjWJwwdcNRfDTlAeBrlLlzQTbVeIhAquOKJlrJdxBckgWPOKSWKCvViwJpdZlNrfsKhTWhkOJrPlPBOqxtNQkeGHBqYjbixthclIkOLxDbIzVHwYIFXoBhdEZyRoFCMTMcnzPc");
    int rPMyCNbzjskUYX = 412417459;

    for (int uYUtGAHOOHfC = 1034263092; uYUtGAHOOHfC > 0; uYUtGAHOOHfC--) {
        continue;
    }

    return unpAYseOfk;
}

string smedbMozbkJolCc::TMWdG(double hDiMNkhmaO, bool IJbtGqfEgpRmtOCn, bool ttLmtuoQduuI)
{
    double seoRcdI = -532578.8782104577;
    bool RidibSN = false;
    double jnGGWXTd = 146365.95940123522;
    double ieDRLPOnqRQAcNf = 26258.085088727792;
    string QJLhNLBl = string("ITeODlQLfKwRYEzrXCYxDfqOXGxFpsusxmUwfmtwEUqTnlncxzQpPCtoTwVSodCnvkwiaYnjRYcNhnDNOfoEwbHfknKJjztUSLCluxnVgzEGqddjCkcsWBhtHnGeawElCazsNkJcwhSmCPBymzeXEoDOYwJBRSYRFxCFVQAmTGpKbwySfomdZpsmMmdptNuEQOtxBXgPgsNhRqnbymekDdoaVAgAOgZGw");
    bool lrLLxwpdjMR = true;
    string FgbEE = string("iRQVitLYXHsESlJWOCbpvEIXfRkTYEkBqfa");
    int sBfYTvUjvYeXTj = 1031561611;

    for (int SHjwLT = 557545326; SHjwLT > 0; SHjwLT--) {
        continue;
    }

    for (int wKlqeiCQ = 1557129227; wKlqeiCQ > 0; wKlqeiCQ--) {
        jnGGWXTd += jnGGWXTd;
        ttLmtuoQduuI = ! RidibSN;
        lrLLxwpdjMR = ! IJbtGqfEgpRmtOCn;
        QJLhNLBl = FgbEE;
    }

    if (QJLhNLBl != string("ITeODlQLfKwRYEzrXCYxDfqOXGxFpsusxmUwfmtwEUqTnlncxzQpPCtoTwVSodCnvkwiaYnjRYcNhnDNOfoEwbHfknKJjztUSLCluxnVgzEGqddjCkcsWBhtHnGeawElCazsNkJcwhSmCPBymzeXEoDOYwJBRSYRFxCFVQAmTGpKbwySfomdZpsmMmdptNuEQOtxBXgPgsNhRqnbymekDdoaVAgAOgZGw")) {
        for (int RueIExkpkmYTDXF = 1984806647; RueIExkpkmYTDXF > 0; RueIExkpkmYTDXF--) {
            continue;
        }
    }

    for (int UXpKS = 1031022739; UXpKS > 0; UXpKS--) {
        ttLmtuoQduuI = RidibSN;
        seoRcdI -= jnGGWXTd;
    }

    return FgbEE;
}

double smedbMozbkJolCc::EkbGhTmYGAm(int fwNNi, int asZJsw, double ieuurbsDUpVkp)
{
    double CVXDrRAZcCnhGlCW = 341491.1754427385;
    double kMWKsduH = 464161.24925879436;
    bool BHShLcBJJG = true;

    return kMWKsduH;
}

smedbMozbkJolCc::smedbMozbkJolCc()
{
    this->mPBTQWXEpFKZ(1673647367);
    this->lrABSbCbkvBoBVV(521494405, false);
    this->pLPqe(-1735452413, true, 1859303689, false, 259356080);
    this->cNhnfMbPkRHwjjwh();
    this->wlQifcaxrRpDkB(false, 298433709, true, -16226913);
    this->NbWFFrFsm(1335286944, 1009443915, string("kATPHMymttkclvFVLUfHOzFnYoYjimrqspoKEnndFbXHPHwuhwaLSSFEXUYboudqzTRtQBrGbdqqWGpsrhLUyXRkqGkaCrsqCFknRtYxjOZfqkxGrhYsHdzvtrsDyf"), string("pkIhBSZjjCuwJGdWhqflFZzJycCURPhnTzZsQglXGwKbEuMdSScKGSqgHJGnLagpUWZDiXERMaDdsOSuEcjscqsiZnrnWuceNDiVIKsijTNPQlmhTtkeiVjFLrJMXIwWjKiLcYKpPpKxetFVRTcgEgTzooVFsvceDVKgzCvZfHZcUaQzBjHGjIcoCRToEiDswIojAmydVaFXPfChjjKWXVAJWyGXtalpgEhYdzOaPHdOa"));
    this->ZewMoHxd(-1745752477, string("xmNdTYZNykBumzRBiuNbtjhmqxrZzGIbiJFNtWOstgXVlIINIIkmgjtbmKOtiOThQEGndNjqpfxzPmrxvuqIfKjzowBmHnDHjfmEXyeRELnQxUewiTSnTrwNekFfVzaoEPoXIsiqDAfObCDohVjrQPGNLKGDRKFGK"), string("eDfHKaLeZDwnchjtAzjFMtlrgGvCWzgGGXPiaRPVkFFyomnsUVsjFEmuIPFKTtTHktq"), string("iYaRVaxfxJKiWexujpMBglJFncupTzLOxSAHJdGSHEEfEdCzCyeSXqHFMXSctEZxnWJkTCGPIzuUUahdvZTCYWoQCmeYacgXlKYOgeQpLVSldjIxWeMerlJrYSTgocvtwDzKLogObjEciZEoUTvqPHJPjmLPsgcRdAOmphSTfBiTyIMQXVdBwoMFGzkjBQsggZNGVOVwtspPuZvZpB"), true);
    this->CNTlNDL(-296640092, 848006.7014786649, string("JyxbgxLdVaTZrnEEFsHevNeiygRULJmntFHhEnBQgjjFqDoUYrUGSoiHBkWGusQouhIutlRpnYgToYvRhpzhcSdXaxolATgNaqDodYkUNcrUjXhiWGtDRRVqHsfSUVNFSpIsaIIcgfuBvHPLtXHkYCmfFXLgcKiAUsiMIzIoLYIZbHRVvswQfMZ"), -515452.07630598487);
    this->odAar(true, false, string("hVYpfqRaPhjmsrDVfJCBFfuvPVkEdmthpShqhPapPdRjCXOobHmVmlZLIsygLehaTpfNrHFJWxRnhxCYwzPLnFALRfTgAcKVmamaYLgQolfrBBWpnXWBoszyVpDObfznzNbWcRVKxNkPsTPTeXGydxvrgHAySUoqBQJmGyqTKYfUJZAvCWtBQbbmjAHIChepnWkhPvCNduIpkpEFXAnutYOFlQSOSksPGAppqVBW"), 2102292051);
    this->bebuKKpCfjsNXIm();
    this->heXoOutGHvw(true, true, string("CtYtHTNLXkIlNuAKNCFNzcagCVvGksYkjPrVgiEfipJscaYJtKfYERZtApjYsHeehdirUOkXtZOHMEmYaJQvIQdlhozNTmcmuUjSVEMYXzeBkKmtLhRpZULMJPCRaDRSa"), -1649857655, -553519.9208277236);
    this->MUggOPcxBdlzFQf(true, -541019979, true, false, true);
    this->TMWdG(483337.77245754784, true, false);
    this->EkbGhTmYGAm(469034669, -1550245771, -327109.4760576956);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OlGAZjGyzJOtCk
{
public:
    double ZhQKrBEDc;
    double vyxDsM;
    bool ofmCzJTlJGpVLMlt;

    OlGAZjGyzJOtCk();
protected:
    double WZpFqCflL;
    string kljEjJ;
    int xpnOLWRj;
    int wGWJi;
    bool IhuVbBaYmD;

    string YWNYcgsVLX(string AzoyaDsetPsf, double QvEuLaccLD, bool wrHDwlp, double OFdhvo, int npfaHilczPimZX);
    string EcJKvTvctCMi(double BJZkrxLseBOGqU, double RZcSzSyyOOcBfsfL, int GaLdLuzhziudDCC);
    string uHgcnXASbDZFEX(double YJmbZwBhwP, double lCBcHGSGOMEpOv, string DgehBg, bool WpkyDgXZDJP);
    double gBGYeXm(double hlHeXuKEEUGlHmf, int JMuLpx, int hEolI, string uwYuKoOOgtYntaKa);
    string MPojeZvCkbmC();
    int CSnNIrPoS(int BgunzaouYWyIqWAU);
    string vzKTTxqdAv(double dGKkyVkVvmVdT, double qKSoMfACLcrNAUZ, bool FRvLex, bool eFJDGjb);
    void ayqMg(string lRpAtzhCdlsGNJH, double ilsOeVB, double gNjoknaDl);
private:
    double gnOgC;

    bool bYEGsCiDxrG();
    double frlOlPdGJgGHJH(string zBiYassQsWiCK, string mbArsWj, bool eMbPozQfvG);
    void ECPwAGcKekrvY(string ArAAoyQ, double NqHLBzWNEFiRwPd);
    void TrPYf(double hwNrrgtnveK, string fEtfhXAhOr, string rhfuVuJ);
    void MFUFgEq(double rRshccjxpTQJ, double IsPro, bool nwnbkqzANgAxqqy, string SuLmlNfyeLqvk, int kUBUKVEbrLZkoJzW);
};

string OlGAZjGyzJOtCk::YWNYcgsVLX(string AzoyaDsetPsf, double QvEuLaccLD, bool wrHDwlp, double OFdhvo, int npfaHilczPimZX)
{
    bool VqyeqRFXcgOngs = false;
    int eSBuMaXcxdePWKQ = 1954117890;
    int HtsyXlooMwY = -1045922676;
    string mhWUoL = string("TMwQjmffalLRqTfXxYIGkrlrlQxwukFvUdARGocRgxgcGugXmvkuozvuzHpnrHeQvggWiNEZjgEBHWAVEEgFsxrCGBnCASpvmKmhkrkgangBchXNgjduTfgqEmZstROsnspmdeGPDxSMsqXVsJnQSVYhXGLYxDQDgkdY");
    string GsXsO = string("oUmcUJTYcIYkhzQZcAAdKmlaSoWVGAEtFYooDPbowgwEuPAqmWsyqmQtSmBGjziGbHDpGTCtqLxgSxQuQQxaANfccYAnpbfLmjMuAdxmEOblkgBbCULziyakYTurTOoxMFIIIRhXXwZKUtbpBKKJazTHyBnEIILTalZIOldFZmgniXDdPvDGbnfdTPyq");
    bool tTBcKbEeLEDZBkdD = false;
    double rVybiE = 456357.5120012988;
    string MGnRkcYGuuYW = string("LxcmjNIPuEurrSXEWxYlaozKmnecyKoDfqiThEJMTdLEHpUjwSTZGdcePeXDJzBfuNRvKQUDTuTSAcbsIruMMFGEkLezOhelSYtiyjkHVlkLVJhKRgSYApp");
    double PVppiQEHEahm = 928229.027228567;

    return MGnRkcYGuuYW;
}

string OlGAZjGyzJOtCk::EcJKvTvctCMi(double BJZkrxLseBOGqU, double RZcSzSyyOOcBfsfL, int GaLdLuzhziudDCC)
{
    double Itxjza = 824266.4829913195;
    double CznnUDprQaLYs = 115275.16016429168;
    bool YeDZTZLHma = true;
    int LVCIn = -1935134800;
    double xDtDCU = -117393.94929788368;

    if (RZcSzSyyOOcBfsfL <= -117393.94929788368) {
        for (int vNLkTxooRkPkcUs = 592619316; vNLkTxooRkPkcUs > 0; vNLkTxooRkPkcUs--) {
            YeDZTZLHma = ! YeDZTZLHma;
            BJZkrxLseBOGqU = BJZkrxLseBOGqU;
            BJZkrxLseBOGqU /= Itxjza;
        }
    }

    if (xDtDCU == -117393.94929788368) {
        for (int bLpQuHxVxma = 681703833; bLpQuHxVxma > 0; bLpQuHxVxma--) {
            LVCIn /= GaLdLuzhziudDCC;
        }
    }

    if (Itxjza < -117393.94929788368) {
        for (int GXkQkNQXqc = 1263544654; GXkQkNQXqc > 0; GXkQkNQXqc--) {
            CznnUDprQaLYs = Itxjza;
        }
    }

    for (int zzKRt = 1155417880; zzKRt > 0; zzKRt--) {
        RZcSzSyyOOcBfsfL *= RZcSzSyyOOcBfsfL;
        YeDZTZLHma = YeDZTZLHma;
        xDtDCU /= Itxjza;
    }

    return string("zpQItiQIvjHOlzgGTVkjBCsjlkPxKXSDNSmOAHHwhSLdxEKIqxoyMcTTLbwivhGCjZsEjWGGCfuFjtSgywesMKDZpxrjxbdvMeYIfTjrZpVxamtcgwqDdapXexEVncieNJTZytsBmPLCcRjhBzOkYHEMS");
}

string OlGAZjGyzJOtCk::uHgcnXASbDZFEX(double YJmbZwBhwP, double lCBcHGSGOMEpOv, string DgehBg, bool WpkyDgXZDJP)
{
    double iZIwFtSoh = -385589.8265623088;
    bool bJTngElARyfBT = true;
    string clbhppMmHVjLBp = string("VqGevZyEmvzeXkIUnyaHnJUWVFuccnNlJodtUKXGBSOvtbCiCuHJCjLxJqfTsLZayxlgjVNudsJvNlnvozicoJaUvsBfcEkZDKwBPsutoIFugcGVVNSNXcJSverxYcgwMeftyqocFOkshvDlItQJHHOifiPtzpwHneAIDiIztzFoiQfoTHHGr");

    for (int qqWvh = 570408829; qqWvh > 0; qqWvh--) {
        DgehBg += DgehBg;
        DgehBg = DgehBg;
    }

    for (int qiLnRsSOwUG = 59873323; qiLnRsSOwUG > 0; qiLnRsSOwUG--) {
        continue;
    }

    return clbhppMmHVjLBp;
}

double OlGAZjGyzJOtCk::gBGYeXm(double hlHeXuKEEUGlHmf, int JMuLpx, int hEolI, string uwYuKoOOgtYntaKa)
{
    int Bmugu = -672002776;

    for (int lgRcltLO = 1267239715; lgRcltLO > 0; lgRcltLO--) {
        continue;
    }

    if (JMuLpx > 1700066504) {
        for (int VvCIMy = 1938225011; VvCIMy > 0; VvCIMy--) {
            hEolI /= Bmugu;
            hEolI = Bmugu;
        }
    }

    if (JMuLpx >= 236135248) {
        for (int BmvMWDQHhFFG = 854433126; BmvMWDQHhFFG > 0; BmvMWDQHhFFG--) {
            hlHeXuKEEUGlHmf *= hlHeXuKEEUGlHmf;
            hEolI -= hEolI;
        }
    }

    if (hEolI >= 1700066504) {
        for (int DeEdcT = 1182838941; DeEdcT > 0; DeEdcT--) {
            hEolI = JMuLpx;
            hlHeXuKEEUGlHmf -= hlHeXuKEEUGlHmf;
            uwYuKoOOgtYntaKa = uwYuKoOOgtYntaKa;
        }
    }

    return hlHeXuKEEUGlHmf;
}

string OlGAZjGyzJOtCk::MPojeZvCkbmC()
{
    bool iRoLw = true;
    bool tOHNvHCAhARgaqM = false;
    double zSnhpPYI = -167139.5522836335;
    string FRAiNx = string("fxnmTcQWXBdlWKjndGtJUrqsfZyRuYBIpdOduJHPnNLQMEoSqwIEUqghfCOqzgDzoVvUQggjoITtXyZvtlGNmyxgtAdzQxmAjfxZjvcDSbOZIHdVQtdgWvyTdYJtgUFwgs");
    string cOvEngZNfwpHOSU = string("NkbJZNFYquLhdBNPOKFjaAdutFkIkpuaSJCQISfhYroAeaQvENSbCHKZTirEsQtvaVdxQrKRFGwJwmGEfDKreMNzHaaZIpCVUMMgZwqhopSEZalLgxpAxtOLbjXaMEneryAclxteAJiydjrsezoKMUWLcQZwamAeSjEwbjBnfjpcPXoyFgxaVtXxbLdwAHuCbjfiGCylgtlaaGkpeTXufHHJczqigQUUeFXSIAXwqBFlrllPTOujgPR");

    for (int oNGhPUfEOtaCpNX = 90830289; oNGhPUfEOtaCpNX > 0; oNGhPUfEOtaCpNX--) {
        tOHNvHCAhARgaqM = ! tOHNvHCAhARgaqM;
    }

    for (int ADEClGCj = 1590808418; ADEClGCj > 0; ADEClGCj--) {
        zSnhpPYI /= zSnhpPYI;
        tOHNvHCAhARgaqM = tOHNvHCAhARgaqM;
        tOHNvHCAhARgaqM = ! tOHNvHCAhARgaqM;
        iRoLw = ! tOHNvHCAhARgaqM;
    }

    if (FRAiNx < string("fxnmTcQWXBdlWKjndGtJUrqsfZyRuYBIpdOduJHPnNLQMEoSqwIEUqghfCOqzgDzoVvUQggjoITtXyZvtlGNmyxgtAdzQxmAjfxZjvcDSbOZIHdVQtdgWvyTdYJtgUFwgs")) {
        for (int gNeoscpKAxR = 1909219497; gNeoscpKAxR > 0; gNeoscpKAxR--) {
            iRoLw = iRoLw;
        }
    }

    if (iRoLw != true) {
        for (int YqfSkUfUj = 865059089; YqfSkUfUj > 0; YqfSkUfUj--) {
            zSnhpPYI = zSnhpPYI;
            cOvEngZNfwpHOSU += cOvEngZNfwpHOSU;
        }
    }

    for (int MMNIkcmPde = 411430444; MMNIkcmPde > 0; MMNIkcmPde--) {
        continue;
    }

    return cOvEngZNfwpHOSU;
}

int OlGAZjGyzJOtCk::CSnNIrPoS(int BgunzaouYWyIqWAU)
{
    string oGjZEfcQmJdr = string("OsXjupTHwsCaODTLkWzSUaAqvDAniMOrQQFkLPBQzurdDqodHfmLuD");
    string ZGwgqcEdsGMK = string("AOKgzNFFZ");
    bool outagTVQOdg = false;
    bool mlEKrjPaaeg = false;
    bool ZKSSspQOkGmT = false;
    bool RekITh = false;
    int pDcDiKFJMAdMlAS = 391139424;
    bool vItinZM = true;
    string IVbELwHtxrOEH = string("rtCuqbqbGy");
    int zFBgtt = -194355299;

    for (int qMEbaBqTLawIF = 12285862; qMEbaBqTLawIF > 0; qMEbaBqTLawIF--) {
        mlEKrjPaaeg = ZKSSspQOkGmT;
        mlEKrjPaaeg = vItinZM;
    }

    if (RekITh != false) {
        for (int xiJXbUpjlWg = 393942747; xiJXbUpjlWg > 0; xiJXbUpjlWg--) {
            vItinZM = vItinZM;
        }
    }

    return zFBgtt;
}

string OlGAZjGyzJOtCk::vzKTTxqdAv(double dGKkyVkVvmVdT, double qKSoMfACLcrNAUZ, bool FRvLex, bool eFJDGjb)
{
    double tjpkQ = 1003073.8015079102;
    int QpijQLt = 788569600;
    int zhTNAKPuaqzh = 1058274440;

    for (int KlDtBoTcXSMbNwRr = 141568017; KlDtBoTcXSMbNwRr > 0; KlDtBoTcXSMbNwRr--) {
        qKSoMfACLcrNAUZ -= qKSoMfACLcrNAUZ;
        dGKkyVkVvmVdT += dGKkyVkVvmVdT;
        zhTNAKPuaqzh /= QpijQLt;
        QpijQLt = QpijQLt;
    }

    if (dGKkyVkVvmVdT <= 1003073.8015079102) {
        for (int cltUlzmSEXGtxu = 1876218399; cltUlzmSEXGtxu > 0; cltUlzmSEXGtxu--) {
            eFJDGjb = FRvLex;
            FRvLex = ! FRvLex;
            zhTNAKPuaqzh += zhTNAKPuaqzh;
        }
    }

    for (int JKcyMfoRmkLmHK = 1907112896; JKcyMfoRmkLmHK > 0; JKcyMfoRmkLmHK--) {
        FRvLex = FRvLex;
        dGKkyVkVvmVdT *= tjpkQ;
        qKSoMfACLcrNAUZ = qKSoMfACLcrNAUZ;
    }

    for (int RbXIedjeaJygyAyz = 1446812238; RbXIedjeaJygyAyz > 0; RbXIedjeaJygyAyz--) {
        QpijQLt /= QpijQLt;
        qKSoMfACLcrNAUZ *= tjpkQ;
        FRvLex = eFJDGjb;
        dGKkyVkVvmVdT /= dGKkyVkVvmVdT;
    }

    for (int KerqGjjwMvNXZ = 162127714; KerqGjjwMvNXZ > 0; KerqGjjwMvNXZ--) {
        dGKkyVkVvmVdT = dGKkyVkVvmVdT;
    }

    return string("hvBelnEUGRpiwFAbffvfsCswEdWqGHXOvrITwDrFzqfYXLLtTMYVPoFCihSyMEhtMfkgqvHwCSkl");
}

void OlGAZjGyzJOtCk::ayqMg(string lRpAtzhCdlsGNJH, double ilsOeVB, double gNjoknaDl)
{
    int GnHCIVgvmAoFa = -835432997;
    string ihAEXgdVL = string("dWmITGaFVKxCUQlaAgpvZoBhwoxbFNPHQtHzFtVkufLFqruLFGRmXLJfXbpUsGWOCereLaNeujEbXAfQpmcAWCtlFucQBdODnRzXxoqcHLDnITbpICNLTjJkrdmmGFKLPfhZGXPrcWzEOKuUnMMAbLRMIidkYPuPTtPAHZsqdZEhrVWNyfPbFygeMnXdKUUzbLrFAiditFhMBAkZPkjGoNngYNVIjkEnbQPdocPVGgzPjhoJRcHEGJRgdNsVXEc");

    for (int QrerAhIR = 866429482; QrerAhIR > 0; QrerAhIR--) {
        ilsOeVB *= ilsOeVB;
        GnHCIVgvmAoFa = GnHCIVgvmAoFa;
        ihAEXgdVL = ihAEXgdVL;
    }

    for (int FSFmbsNnfKC = 1852466720; FSFmbsNnfKC > 0; FSFmbsNnfKC--) {
        ilsOeVB /= ilsOeVB;
        lRpAtzhCdlsGNJH = ihAEXgdVL;
        gNjoknaDl /= ilsOeVB;
        lRpAtzhCdlsGNJH = lRpAtzhCdlsGNJH;
    }

    if (GnHCIVgvmAoFa <= -835432997) {
        for (int BoQvItFtZZJ = 924072785; BoQvItFtZZJ > 0; BoQvItFtZZJ--) {
            gNjoknaDl = gNjoknaDl;
        }
    }

    for (int OMLWdXbu = 1596435110; OMLWdXbu > 0; OMLWdXbu--) {
        gNjoknaDl /= ilsOeVB;
        gNjoknaDl /= ilsOeVB;
        lRpAtzhCdlsGNJH += lRpAtzhCdlsGNJH;
        gNjoknaDl += gNjoknaDl;
        ilsOeVB = ilsOeVB;
    }
}

bool OlGAZjGyzJOtCk::bYEGsCiDxrG()
{
    bool ZvwMAOa = true;
    bool FqliNkqvgCan = false;
    int KbypyKTZJT = -1247238415;

    for (int btEPtKCFVfpkT = 1124649052; btEPtKCFVfpkT > 0; btEPtKCFVfpkT--) {
        FqliNkqvgCan = FqliNkqvgCan;
        FqliNkqvgCan = ZvwMAOa;
        FqliNkqvgCan = ZvwMAOa;
        FqliNkqvgCan = FqliNkqvgCan;
        KbypyKTZJT += KbypyKTZJT;
        ZvwMAOa = ! ZvwMAOa;
    }

    for (int YpvVdoUrvAh = 1412070332; YpvVdoUrvAh > 0; YpvVdoUrvAh--) {
        FqliNkqvgCan = FqliNkqvgCan;
        ZvwMAOa = ZvwMAOa;
        ZvwMAOa = FqliNkqvgCan;
        ZvwMAOa = ! FqliNkqvgCan;
        ZvwMAOa = ! ZvwMAOa;
        ZvwMAOa = ZvwMAOa;
    }

    if (FqliNkqvgCan != false) {
        for (int rmwTXbGwcdv = 723354229; rmwTXbGwcdv > 0; rmwTXbGwcdv--) {
            FqliNkqvgCan = ZvwMAOa;
            KbypyKTZJT -= KbypyKTZJT;
            KbypyKTZJT *= KbypyKTZJT;
        }
    }

    if (ZvwMAOa != true) {
        for (int iuyNglxzdogxzMd = 787841321; iuyNglxzdogxzMd > 0; iuyNglxzdogxzMd--) {
            ZvwMAOa = ZvwMAOa;
        }
    }

    if (FqliNkqvgCan == false) {
        for (int dTKNcBBZRY = 1321538493; dTKNcBBZRY > 0; dTKNcBBZRY--) {
            ZvwMAOa = ! ZvwMAOa;
            ZvwMAOa = ! ZvwMAOa;
        }
    }

    if (ZvwMAOa != true) {
        for (int GkAdXhJAXKPQQGJ = 777126542; GkAdXhJAXKPQQGJ > 0; GkAdXhJAXKPQQGJ--) {
            FqliNkqvgCan = ZvwMAOa;
            ZvwMAOa = FqliNkqvgCan;
            KbypyKTZJT = KbypyKTZJT;
        }
    }

    return FqliNkqvgCan;
}

double OlGAZjGyzJOtCk::frlOlPdGJgGHJH(string zBiYassQsWiCK, string mbArsWj, bool eMbPozQfvG)
{
    double ZEbPqnkuNeOqRKkq = -76126.22268295115;
    double GLSDJZbA = -565211.3188643323;
    string PpCTQUUT = string("Xc");
    string ICXmCtcLi = string("qqLLYHEPIpGJOWsRGiozDIzPgYRstQXDyNxZhjMfNbkuwmJcfEkFGzAjfKMbwmczBukYGslnNPthGcMqshdxxscUzNMYxprGpakPRpv");
    bool dTuqDMm = false;
    int sCVRKYZdyJvKH = -1387373371;

    return GLSDJZbA;
}

void OlGAZjGyzJOtCk::ECPwAGcKekrvY(string ArAAoyQ, double NqHLBzWNEFiRwPd)
{
    string wTapQuDqVMPRkuY = string("pEoXOTGrumcEdMUMODbUnFrqDIHGvFOlNcsjKJUKiSNLcHgG");
    int JpnOJI = 838010950;
    int HIvoCxlqMRo = 1672162394;
    double fXAlJniBgZWM = -787611.5379216361;
    int FTwpGNktYjPI = -122407028;
    bool xpNuDxvzqrPEi = false;
    double eOtXidMBN = 22259.94360311885;
    string ERSiOW = string("guJSxKgRanqVOUuzYmRFzioDtoWPytxCBgopRrEsnoCcrvK");
    double bwzsQTD = -680075.1017518219;
}

void OlGAZjGyzJOtCk::TrPYf(double hwNrrgtnveK, string fEtfhXAhOr, string rhfuVuJ)
{
    int zqakJJ = -1934522735;
    bool FKjVPFBNt = true;
    bool VrBiH = false;
    int eyXrbXLYiEjsMTw = -1608147623;
    int fZGrdOBOtrQ = -579789626;
    string ijeZCiwbPnqATsy = string("BocQijUYiRTbDrjVKgQrtRVvtyKegbyEUQYptpolttimAKOPdSyDoEFfzWlAAKrbJbOPblHRggMWXBDJDocxjTilaJIC");
    int NVFZRB = 1735273249;

    for (int dFXlVQHsMLJ = 602784039; dFXlVQHsMLJ > 0; dFXlVQHsMLJ--) {
        FKjVPFBNt = ! FKjVPFBNt;
        zqakJJ += eyXrbXLYiEjsMTw;
        eyXrbXLYiEjsMTw /= zqakJJ;
    }

    for (int iMFzEsQ = 1038338681; iMFzEsQ > 0; iMFzEsQ--) {
        VrBiH = ! VrBiH;
        eyXrbXLYiEjsMTw += NVFZRB;
        ijeZCiwbPnqATsy += ijeZCiwbPnqATsy;
        fZGrdOBOtrQ *= eyXrbXLYiEjsMTw;
    }

    for (int dSPSqQmNtFT = 1526494274; dSPSqQmNtFT > 0; dSPSqQmNtFT--) {
        fZGrdOBOtrQ *= eyXrbXLYiEjsMTw;
    }
}

void OlGAZjGyzJOtCk::MFUFgEq(double rRshccjxpTQJ, double IsPro, bool nwnbkqzANgAxqqy, string SuLmlNfyeLqvk, int kUBUKVEbrLZkoJzW)
{
    bool rmbxOsJkA = false;
    bool EJBIdlaSuSOdrbXe = true;
    int zSdikgzsztdlc = 941218243;
    bool lLPXlyBng = false;
    double LBrUke = 263099.2417431862;
    int cYHJYJAHTS = 97141751;
    bool SKHlAOpuBpZz = true;
    double mAIZLYH = 582915.6965528328;
    double kMiDbuwxqgD = 430435.5473139571;
    string xJrpPmSvty = string("xKkJqripNXGqxfByjmVCidMPBieJzdeUTqWENMmGTXVITSYiVSVpSfEhBRmRzIZyAykaViZOrojCdSZUWOclmPsZsxHWmWZqTmvSIOqBerSpAEnMaIHMDgProuvMvPQsrRvdxpVFkZmlUOnGaMqAuEPkqVTyPcHuflJuVPqVBnHbMeceMdPybSnRahHlROiPcJacRpKRAdstTwAhfmuLPyVnpIExibPbgfOHgZUfKwEK");

    for (int dtkzMKJUWnnN = 1523175245; dtkzMKJUWnnN > 0; dtkzMKJUWnnN--) {
        LBrUke = IsPro;
        xJrpPmSvty += xJrpPmSvty;
        EJBIdlaSuSOdrbXe = nwnbkqzANgAxqqy;
        kMiDbuwxqgD += mAIZLYH;
        mAIZLYH -= mAIZLYH;
    }

    for (int fvUOtDkaH = 831614400; fvUOtDkaH > 0; fvUOtDkaH--) {
        IsPro *= mAIZLYH;
        zSdikgzsztdlc /= kUBUKVEbrLZkoJzW;
        mAIZLYH += rRshccjxpTQJ;
        IsPro = mAIZLYH;
    }

    for (int FipIttUPzkcB = 653345923; FipIttUPzkcB > 0; FipIttUPzkcB--) {
        EJBIdlaSuSOdrbXe = lLPXlyBng;
        EJBIdlaSuSOdrbXe = lLPXlyBng;
        EJBIdlaSuSOdrbXe = ! nwnbkqzANgAxqqy;
        lLPXlyBng = ! lLPXlyBng;
    }
}

OlGAZjGyzJOtCk::OlGAZjGyzJOtCk()
{
    this->YWNYcgsVLX(string("VPYanZnMqdQLeolLjFnaglmEzNKLISRijSMuLJzzscfYVWOUzVHereYBLgdCsmlzMxBTUleHkMUiUkxtOTeaQhYqOQcAVsWpQmapCpCtnUdOjKksPlIZoHVgYrOpEsftuprnAHzYenhoRquSYHZeLPpBOPBlJazxkRIloLXSAhCxoIvnwORHgxgPXIcXRaUHIIwxkbJ"), -861772.3340666128, false, -144894.05463406458, -1553836366);
    this->EcJKvTvctCMi(862092.2711372889, 790489.7628304623, -996585459);
    this->uHgcnXASbDZFEX(1024279.686903846, -828615.5139795525, string("gxFNIWKEMSyMTtkbPqjWmNKphjzcIdTJqFqiGBRpwxDtkMuvAfaFziYFMOnpsRvCaIXiPBqxOJmKgOJdScyaGBeJGRZBtmXNeBNEEVFGGDOEjtBOIkDdNJdiOXpNbNjSTLPaxDEDtPDZbaYdBnfcrilGpFUJvufzLyUfADRhqYweLjfLCDYYjnEbiMxFTShR"), false);
    this->gBGYeXm(-895648.5260008804, 236135248, 1700066504, string("WOkEfXGstjPqyFvbxON"));
    this->MPojeZvCkbmC();
    this->CSnNIrPoS(-1342830574);
    this->vzKTTxqdAv(429813.355154176, 426108.09844393574, true, false);
    this->ayqMg(string("XLnWyRFnQmgVbwyjqHAdGwTFWOhBtdGIoAGENRTTSmUwzwAnRNVYFpjlNIuUIPffcjLGMsASUkOaLGrOGFXgcbcXCknubpvIzDuATNRBCQIsTwMBbyKFzskQiAHLBlamBNlvaklukCVSUQNNgGtPznAkdFiyIFLmxRWqOSWYmCDBJjdFcgcHwojWBbAyhokEtQNLaoHGPpuFuhSbqfPNLxsspKnSjidUKsIyPzkzNHYmDsCuwsgi"), 365283.69402011187, -819303.898517879);
    this->bYEGsCiDxrG();
    this->frlOlPdGJgGHJH(string("YbKveWaZwgIpZKRIgkzSbJWHXNYjSassGQQVzuuNjNnraYiIxcaHvgJBfpvTnqhzmoaWIWNmKyRMkdCnkxsBstEIUZjotqyXkkEiGEbxoHrhTJLMFOFPbNLuMQtXBXIQrXBuTFjBpCpQpsKVlbtBAVdmmfVNgCiEJJpuRylUJtkPWqdXNHvoSnRkvLdOExPyKdlzaBrbOjBZbDUaQbhjPWXjOcQgkWePBYPDnUkPj"), string("zBXlCHTzRJqHRbiIAzvVRjIOrcelJziICFMXXDvAXKkSAGodLpHdCbTyVwigeGBpYqMlNyjMFRNWiBdJysKBzzsEMZgAmYfnFRGJfQozkrqTZJLWZkWIPbxZofHztvUcsWYMyhmnuGGrTtHxVbPYlwiMpEbCyWBtwBeaYRUSzuzECQHJQoMgKt"), true);
    this->ECPwAGcKekrvY(string("QLtkYcIqSrrFjnhZtUSjyreDoAiJzdRFdQrrObHKNaUYQYidtOZBLCuCFGneyZTwdiCwweIzAIrCdZICQqrbIXnwycc"), 396098.72211553843);
    this->TrPYf(-194847.41236230184, string("RJZFvttQAXBeDekrpzpQHVSgbssqicVLgikRKVqoCyRreumubjQcAgWuupCvBNdQNAigyTxsubZGwFUIYInWwARJcLyMvKfkAYqPNFqzkAkJNMFKkATqknHcitDZwxdoDNsQBOOcURkaKsNTJsjlucwQFejKVKcWUpepClbwuXzTqqBoiscmChFfXReVQoeDQFqCCwqHEazvLDw"), string("mSMlpFjwiyruVQvjHzZlXMGTmZCDRwItBlDbxLfYLooFrjpHMdkcnusHfhwvAbFTOGfeKcyuwT"));
    this->MFUFgEq(-213688.41106981496, 555212.6581507578, true, string("rKPFtNGpomzOfDwVpGzwWOqNRSTPouwEUbsUmlhaYlMDZliITchNoGwmnJRkiPsjykCikTxhpoJwZOfAxilirhMwEsvhDHtZCVFUZKuesemuCdjyveOPkjpahgYwBJSSjIAXdjYpFkUKSCouKTWqIXbBApYTjvOHbnXvqUxjOoWXvpeRvSZamFQbPfuzDqBA"), 34868615);
}
