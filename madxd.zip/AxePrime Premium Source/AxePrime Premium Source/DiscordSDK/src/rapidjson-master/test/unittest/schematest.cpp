// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/schema.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(variadic-macros)
#elif defined(_MSC_VER)
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(4822) // local class member function does not have a body
#endif

using namespace rapidjson;

#define TEST_HASHER(json1, json2, expected) \
{\
    Document d1, d2;\
    d1.Parse(json1);\
    ASSERT_FALSE(d1.HasParseError());\
    d2.Parse(json2);\
    ASSERT_FALSE(d2.HasParseError());\
    internal::Hasher<Value, CrtAllocator> h1, h2;\
    d1.Accept(h1);\
    d2.Accept(h2);\
    ASSERT_TRUE(h1.IsValid());\
    ASSERT_TRUE(h2.IsValid());\
    /*printf("%s: 0x%016llx\n%s: 0x%016llx\n\n", json1, h1.GetHashCode(), json2, h2.GetHashCode());*/\
    EXPECT_TRUE(expected == (h1.GetHashCode() == h2.GetHashCode()));\
}

TEST(SchemaValidator, Hasher) {
    TEST_HASHER("null", "null", true);

    TEST_HASHER("true", "true", true);
    TEST_HASHER("false", "false", true);
    TEST_HASHER("true", "false", false);
    TEST_HASHER("false", "true", false);
    TEST_HASHER("true", "null", false);
    TEST_HASHER("false", "null", false);

    TEST_HASHER("1", "1", true);
    TEST_HASHER("2147483648", "2147483648", true); // 2^31 can only be fit in unsigned
    TEST_HASHER("-2147483649", "-2147483649", true); // -2^31 - 1 can only be fit in int64_t
    TEST_HASHER("2147483648", "2147483648", true); // 2^31 can only be fit in unsigned
    TEST_HASHER("4294967296", "4294967296", true); // 2^32 can only be fit in int64_t
    TEST_HASHER("9223372036854775808", "9223372036854775808", true); // 2^63 can only be fit in uint64_t
    TEST_HASHER("1.5", "1.5", true);
    TEST_HASHER("1", "1.0", true);
    TEST_HASHER("1", "-1", false);
    TEST_HASHER("0.0", "-0.0", false);
    TEST_HASHER("1", "true", false);
    TEST_HASHER("0", "false", false);
    TEST_HASHER("0", "null", false);

    TEST_HASHER("\"\"", "\"\"", true);
    TEST_HASHER("\"\"", "\"\\u0000\"", false);
    TEST_HASHER("\"Hello\"", "\"Hello\"", true);
    TEST_HASHER("\"Hello\"", "\"World\"", false);
    TEST_HASHER("\"Hello\"", "null", false);
    TEST_HASHER("\"Hello\\u0000\"", "\"Hello\"", false);
    TEST_HASHER("\"\"", "null", false);
    TEST_HASHER("\"\"", "true", false);
    TEST_HASHER("\"\"", "false", false);

    TEST_HASHER("[]", "[ ]", true);
    TEST_HASHER("[1, true, false]", "[1, true, false]", true);
    TEST_HASHER("[1, true, false]", "[1, true]", false);
    TEST_HASHER("[1, 2]", "[2, 1]", false);
    TEST_HASHER("[[1], 2]", "[[1, 2]]", false);
    TEST_HASHER("[1, 2]", "[1, [2]]", false);
    TEST_HASHER("[]", "null", false);
    TEST_HASHER("[]", "true", false);
    TEST_HASHER("[]", "false", false);
    TEST_HASHER("[]", "0", false);
    TEST_HASHER("[]", "0.0", false);
    TEST_HASHER("[]", "\"\"", false);

    TEST_HASHER("{}", "{ }", true);
    TEST_HASHER("{\"a\":1}", "{\"a\":1}", true);
    TEST_HASHER("{\"a\":1}", "{\"b\":1}", false);
    TEST_HASHER("{\"a\":1}", "{\"a\":2}", false);
    TEST_HASHER("{\"a\":1, \"b\":2}", "{\"b\":2, \"a\":1}", true); // Member order insensitive
    TEST_HASHER("{}", "null", false);
    TEST_HASHER("{}", "false", false);
    TEST_HASHER("{}", "true", false);
    TEST_HASHER("{}", "0", false);
    TEST_HASHER("{}", "0.0", false);
    TEST_HASHER("{}", "\"\"", false);
}

// Test cases following http://spacetelescope.github.io/understanding-json-schema

#define VALIDATE(schema, json, expected) \
{\
    SchemaValidator validator(schema);\
    Document d;\
    /*printf("\n%s\n", json);*/\
    d.Parse(json);\
    EXPECT_FALSE(d.HasParseError());\
    EXPECT_TRUE(expected == d.Accept(validator));\
    EXPECT_TRUE(expected == validator.IsValid());\
    if ((expected) && !validator.IsValid()) {\
        StringBuffer sb;\
        validator.GetInvalidSchemaPointer().StringifyUriFragment(sb);\
        printf("Invalid schema: %s\n", sb.GetString());\
        printf("Invalid keyword: %s\n", validator.GetInvalidSchemaKeyword());\
        sb.Clear();\
        validator.GetInvalidDocumentPointer().StringifyUriFragment(sb);\
        printf("Invalid document: %s\n", sb.GetString());\
        sb.Clear();\
        Writer<StringBuffer> w(sb);\
        validator.GetError().Accept(w);\
        printf("Validation error: %s\n", sb.GetString());\
    }\
}

#define INVALIDATE(schema, json, invalidSchemaPointer, invalidSchemaKeyword, invalidDocumentPointer, error) \
{\
    INVALIDATE_(schema, json, invalidSchemaPointer, invalidSchemaKeyword, invalidDocumentPointer, error, SchemaValidator, Pointer) \
}

#define INVALIDATE_(schema, json, invalidSchemaPointer, invalidSchemaKeyword, invalidDocumentPointer, error, \
    SchemaValidatorType, PointerType) \
{\
    SchemaValidatorType validator(schema);\
    Document d;\
    /*printf("\n%s\n", json);*/\
    d.Parse(json);\
    EXPECT_FALSE(d.HasParseError());\
    EXPECT_FALSE(d.Accept(validator));\
    EXPECT_FALSE(validator.IsValid());\
    if (validator.GetInvalidSchemaPointer() != PointerType(invalidSchemaPointer)) {\
        StringBuffer sb;\
        validator.GetInvalidSchemaPointer().Stringify(sb);\
        printf("GetInvalidSchemaPointer() Expected: %s Actual: %s\n", invalidSchemaPointer, sb.GetString());\
        ADD_FAILURE();\
    }\
    ASSERT_TRUE(validator.GetInvalidSchemaKeyword() != 0);\
    if (strcmp(validator.GetInvalidSchemaKeyword(), invalidSchemaKeyword) != 0) {\
        printf("GetInvalidSchemaKeyword() Expected: %s Actual %s\n", invalidSchemaKeyword, validator.GetInvalidSchemaKeyword());\
        ADD_FAILURE();\
    }\
    if (validator.GetInvalidDocumentPointer() != PointerType(invalidDocumentPointer)) {\
        StringBuffer sb;\
        validator.GetInvalidDocumentPointer().Stringify(sb);\
        printf("GetInvalidDocumentPointer() Expected: %s Actual: %s\n", invalidDocumentPointer, sb.GetString());\
        ADD_FAILURE();\
    }\
    Document e;\
    e.Parse(error);\
    if (validator.GetError() != e) {\
        StringBuffer sb;\
        Writer<StringBuffer> w(sb);\
        validator.GetError().Accept(w);\
        printf("GetError() Expected: %s Actual: %s\n", error, sb.GetString());\
        ADD_FAILURE();\
    }\
}

TEST(SchemaValidator, Typeless) {
    Document sd;
    sd.Parse("{}");
    SchemaDocument s(sd);
    
    VALIDATE(s, "42", true);
    VALIDATE(s, "\"I'm a string\"", true);
    VALIDATE(s, "{ \"an\": [ \"arbitrarily\", \"nested\" ], \"data\": \"structure\" }", true);
}

TEST(SchemaValidator, MultiType) {
    Document sd;
    sd.Parse("{ \"type\": [\"number\", \"string\"] }");
    SchemaDocument s(sd);

    VALIDATE(s, "42", true);
    VALIDATE(s, "\"Life, the universe, and everything\"", true);
    INVALIDATE(s, "[\"Life\", \"the universe\", \"and everything\"]", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\", \"number\"], \"actual\": \"array\""
        "}}");
}

TEST(SchemaValidator, Enum_Typed) {
    Document sd;
    sd.Parse("{ \"type\": \"string\", \"enum\" : [\"red\", \"amber\", \"green\"] }");
    SchemaDocument s(sd);

    VALIDATE(s, "\"red\"", true);
    INVALIDATE(s, "\"blue\"", "", "enum", "",
        "{ \"enum\": { \"instanceRef\": \"#\", \"schemaRef\": \"#\" }}");
}

TEST(SchemaValidator, Enum_Typless) {
    Document sd;
    sd.Parse("{  \"enum\": [\"red\", \"amber\", \"green\", null, 42] }");
    SchemaDocument s(sd);

    VALIDATE(s, "\"red\"", true);
    VALIDATE(s, "null", true);
    VALIDATE(s, "42", true);
    INVALIDATE(s, "0", "", "enum", "",
        "{ \"enum\": { \"instanceRef\": \"#\", \"schemaRef\": \"#\" }}");
}

TEST(SchemaValidator, Enum_InvalidType) {
    Document sd;
    sd.Parse("{ \"type\": \"string\", \"enum\": [\"red\", \"amber\", \"green\", null] }");
    SchemaDocument s(sd);

    VALIDATE(s, "\"red\"", true);
    INVALIDATE(s, "null", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\"], \"actual\": \"null\""
        "}}");
}

TEST(SchemaValidator, AllOf) {
    {
        Document sd;
        sd.Parse("{\"allOf\": [{ \"type\": \"string\" }, { \"type\": \"string\", \"maxLength\": 5 }]}");
        SchemaDocument s(sd);

        VALIDATE(s, "\"ok\"", true);
        INVALIDATE(s, "\"too long\"", "", "allOf", "",
            "{ \"maxLength\": { "
            "    \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/1\", "
            "    \"expected\": 5, \"actual\": \"too long\""
            "}}");
    }
    {
        Document sd;
        sd.Parse("{\"allOf\": [{ \"type\": \"string\" }, { \"type\": \"number\" } ] }");
        SchemaDocument s(sd);

        VALIDATE(s, "\"No way\"", false);
        INVALIDATE(s, "-1", "", "allOf", "",
            "{ \"type\": { \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/0\","
            "    \"expected\": [\"string\"], \"actual\": \"integer\""
            "}}");
    }
}

TEST(SchemaValidator, AnyOf) {
    Document sd;
    sd.Parse("{\"anyOf\": [{ \"type\": \"string\" }, { \"type\": \"number\" } ] }");
    SchemaDocument s(sd);

    VALIDATE(s, "\"Yes\"", true);
    VALIDATE(s, "42", true);
    INVALIDATE(s, "{ \"Not a\": \"string or number\" }", "", "anyOf", "",
        "{ \"anyOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\", "
        "    \"errors\": ["
        "      { \"type\": {"
        "          \"instanceRef\": \"#\", \"schemaRef\": \"#/anyOf/0\","
        "          \"expected\": [\"string\"], \"actual\": \"object\""
        "      }},"
        "      { \"type\": {"
        "          \"instanceRef\": \"#\", \"schemaRef\": \"#/anyOf/1\","
        "          \"expected\": [\"number\"], \"actual\": \"object\""
        "      }}"
        "    ]"
        "}}");
}

TEST(SchemaValidator, OneOf) {
    Document sd;
    sd.Parse("{\"oneOf\": [{ \"type\": \"number\", \"multipleOf\": 5 }, { \"type\": \"number\", \"multipleOf\": 3 } ] }");
    SchemaDocument s(sd);

    VALIDATE(s, "10", true);
    VALIDATE(s, "9", true);
    INVALIDATE(s, "2", "", "oneOf", "",
        "{ \"oneOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"errors\": ["
        "      { \"multipleOf\": {"
        "          \"instanceRef\": \"#\", \"schemaRef\": \"#/oneOf/0\","
        "          \"expected\": 5, \"actual\": 2"
        "      }},"
        "      { \"multipleOf\": {"
        "          \"instanceRef\": \"#\", \"schemaRef\": \"#/oneOf/1\","
        "          \"expected\": 3, \"actual\": 2"
        "      }}"
        "    ]"
        "}}");
    INVALIDATE(s, "15", "", "oneOf", "",
        "{ \"oneOf\": { \"instanceRef\": \"#\", \"schemaRef\": \"#\", \"errors\": [{}, {}]}}");
}

TEST(SchemaValidator, Not) {
    Document sd;
    sd.Parse("{\"not\":{ \"type\": \"string\"}}");
    SchemaDocument s(sd);

    VALIDATE(s, "42", true);
    VALIDATE(s, "{ \"key\": \"value\" }", true);
    INVALIDATE(s, "\"I am a string\"", "", "not", "",
        "{ \"not\": { \"instanceRef\": \"#\", \"schemaRef\": \"#\" }}");
}

TEST(SchemaValidator, Ref) {
    Document sd;
    sd.Parse(
        "{"
        "  \"$schema\": \"http://json-schema.org/draft-04/schema#\","
        ""
        "  \"definitions\": {"
        "    \"address\": {"
        "      \"type\": \"object\","
        "      \"properties\": {"
        "        \"street_address\": { \"type\": \"string\" },"
        "        \"city\":           { \"type\": \"string\" },"
        "        \"state\":          { \"type\": \"string\" }"
        "      },"
        "      \"required\": [\"street_address\", \"city\", \"state\"]"
        "    }"
        "  },"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"billing_address\": { \"$ref\": \"#/definitions/address\" },"
        "    \"shipping_address\": { \"$ref\": \"#/definitions/address\" }"
        "  }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{\"shipping_address\": {\"street_address\": \"1600 Pennsylvania Avenue NW\", \"city\": \"Washington\", \"state\": \"DC\"}, \"billing_address\": {\"street_address\": \"1st Street SE\", \"city\": \"Washington\", \"state\": \"DC\"} }", true);
}

TEST(SchemaValidator, Ref_AllOf) {
    Document sd;
    sd.Parse(
        "{"
        "  \"$schema\": \"http://json-schema.org/draft-04/schema#\","
        ""
        "  \"definitions\": {"
        "    \"address\": {"
        "      \"type\": \"object\","
        "      \"properties\": {"
        "        \"street_address\": { \"type\": \"string\" },"
        "        \"city\":           { \"type\": \"string\" },"
        "        \"state\":          { \"type\": \"string\" }"
        "      },"
        "      \"required\": [\"street_address\", \"city\", \"state\"]"
        "    }"
        "  },"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"billing_address\": { \"$ref\": \"#/definitions/address\" },"
        "    \"shipping_address\": {"
        "      \"allOf\": ["
        "        { \"$ref\": \"#/definitions/address\" },"
        "        { \"properties\":"
        "          { \"type\": { \"enum\": [ \"residential\", \"business\" ] } },"
        "          \"required\": [\"type\"]"
        "        }"
        "      ]"
        "    }"
        "  }"
        "}");
    SchemaDocument s(sd);

    INVALIDATE(s, "{\"shipping_address\": {\"street_address\": \"1600 Pennsylvania Avenue NW\", \"city\": \"Washington\", \"state\": \"DC\"} }", "/properties/shipping_address", "allOf", "/shipping_address",
        "{ \"required\": {"
        "    \"instanceRef\": \"#/shipping_address\","
        "    \"schemaRef\": \"#/properties/shipping_address/allOf/1\","
        "    \"missing\": [\"type\"]"
        "}}");
    VALIDATE(s, "{\"shipping_address\": {\"street_address\": \"1600 Pennsylvania Avenue NW\", \"city\": \"Washington\", \"state\": \"DC\", \"type\": \"business\"} }", true);
}

TEST(SchemaValidator, String) {
    Document sd;
    sd.Parse("{\"type\":\"string\"}");
    SchemaDocument s(sd);

    VALIDATE(s, "\"I'm a string\"", true);
    INVALIDATE(s, "42", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}");
    INVALIDATE(s, "2147483648", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}"); // 2^31 can only be fit in unsigned
    INVALIDATE(s, "-2147483649", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}"); // -2^31 - 1 can only be fit in int64_t
    INVALIDATE(s, "4294967296", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}"); // 2^32 can only be fit in int64_t
    INVALIDATE(s, "3.1415926", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\"], \"actual\": \"number\""
        "}}");
}

TEST(SchemaValidator, String_LengthRange) {
    Document sd;
    sd.Parse("{\"type\":\"string\",\"minLength\":2,\"maxLength\":3}");
    SchemaDocument s(sd);

    INVALIDATE(s, "\"A\"", "", "minLength", "",
        "{ \"minLength\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 2, \"actual\": \"A\""
        "}}");
    VALIDATE(s, "\"AB\"", true);
    VALIDATE(s, "\"ABC\"", true);
    INVALIDATE(s, "\"ABCD\"", "", "maxLength", "",
        "{ \"maxLength\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 3, \"actual\": \"ABCD\""
        "}}");
}

#if RAPIDJSON_SCHEMA_HAS_REGEX
TEST(SchemaValidator, String_Pattern) {
    Document sd;
    sd.Parse("{\"type\":\"string\",\"pattern\":\"^(\\\\([0-9]{3}\\\\))?[0-9]{3}-[0-9]{4}$\"}");
    SchemaDocument s(sd);

    VALIDATE(s, "\"555-1212\"", true);
    VALIDATE(s, "\"(888)555-1212\"", true);
    INVALIDATE(s, "\"(888)555-1212 ext. 532\"", "", "pattern", "",
        "{ \"pattern\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"actual\": \"(888)555-1212 ext. 532\""
        "}}");
    INVALIDATE(s, "\"(800)FLOWERS\"", "", "pattern", "",
        "{ \"pattern\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"actual\": \"(800)FLOWERS\""
        "}}");
}

TEST(SchemaValidator, String_Pattern_Invalid) {
    Document sd;
    sd.Parse("{\"type\":\"string\",\"pattern\":\"a{0}\"}"); // TODO: report regex is invalid somehow
    SchemaDocument s(sd);

    VALIDATE(s, "\"\"", true);
    VALIDATE(s, "\"a\"", true);
    VALIDATE(s, "\"aa\"", true);
}
#endif

TEST(SchemaValidator, Integer) {
    Document sd;
    sd.Parse("{\"type\":\"integer\"}");
    SchemaDocument s(sd);

    VALIDATE(s, "42", true);
    VALIDATE(s, "-1", true);
    VALIDATE(s, "2147483648", true); // 2^31 can only be fit in unsigned
    VALIDATE(s, "-2147483649", true); // -2^31 - 1 can only be fit in int64_t
    VALIDATE(s, "2147483648", true); // 2^31 can only be fit in unsigned
    VALIDATE(s, "4294967296", true); // 2^32 can only be fit in int64_t
    INVALIDATE(s, "3.1415926", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"integer\"], \"actual\": \"number\""
        "}}");
    INVALIDATE(s, "\"42\"", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"integer\"], \"actual\": \"string\""
        "}}");
}

TEST(SchemaValidator, Integer_Range) {
    Document sd;
    sd.Parse("{\"type\":\"integer\",\"minimum\":0,\"maximum\":100,\"exclusiveMaximum\":true}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-1", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 0, \"actual\": -1"
        "}}");
    VALIDATE(s, "0", true);
    VALIDATE(s, "10", true);
    VALIDATE(s, "99", true);
    INVALIDATE(s, "100", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100, \"exclusiveMaximum\": true, \"actual\": 100"
        "}}");
    INVALIDATE(s, "101", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100, \"exclusiveMaximum\": true, \"actual\": 101"
        "}}");
}

TEST(SchemaValidator, Integer_Range64Boundary) {
    Document sd;
    sd.Parse("{\"type\":\"integer\",\"minimum\":-9223372036854775807,\"maximum\":9223372036854775806}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-9223372036854775808", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -9223372036854775807, \"actual\": -9223372036854775808"
        "}}");
    VALIDATE(s, "-9223372036854775807", true);
    VALIDATE(s, "-2147483648", true); // int min
    VALIDATE(s, "0", true);
    VALIDATE(s, "2147483647", true);  // int max
    VALIDATE(s, "2147483648", true);  // unsigned first
    VALIDATE(s, "4294967295", true);  // unsigned max
    VALIDATE(s, "9223372036854775806", true);
    INVALIDATE(s, "9223372036854775807", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775806, \"actual\": 9223372036854775807"
        "}}");
    INVALIDATE(s, "18446744073709551615", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775806, \"actual\": 18446744073709551615"
        "}}");   // uint64_t max
}

TEST(SchemaValidator, Integer_RangeU64Boundary) {
    Document sd;
    sd.Parse("{\"type\":\"integer\",\"minimum\":9223372036854775808,\"maximum\":18446744073709551614}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-9223372036854775808", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808, \"actual\": -9223372036854775808"
        "}}");
    INVALIDATE(s, "9223372036854775807", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808, \"actual\": 9223372036854775807"
        "}}");
    INVALIDATE(s, "-2147483648", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808, \"actual\": -2147483648"
        "}}"); // int min
    INVALIDATE(s, "0", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808, \"actual\": 0"
        "}}");
    INVALIDATE(s, "2147483647", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808, \"actual\": 2147483647"
        "}}");  // int max
    INVALIDATE(s, "2147483648", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808, \"actual\": 2147483648"
        "}}");  // unsigned first
    INVALIDATE(s, "4294967295", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808, \"actual\": 4294967295"
        "}}");  // unsigned max
    VALIDATE(s, "9223372036854775808", true);
    VALIDATE(s, "18446744073709551614", true);
    INVALIDATE(s, "18446744073709551615", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 18446744073709551614, \"actual\": 18446744073709551615"
        "}}");
}

TEST(SchemaValidator, Integer_Range64BoundaryExclusive) {
    Document sd;
    sd.Parse("{\"type\":\"integer\",\"minimum\":-9223372036854775808,\"maximum\":18446744073709551615,\"exclusiveMinimum\":true,\"exclusiveMaximum\":true}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-9223372036854775808", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -9223372036854775808, \"exclusiveMinimum\": true, "
        "    \"actual\": -9223372036854775808"
        "}}");
    VALIDATE(s, "-9223372036854775807", true);
    VALIDATE(s, "18446744073709551614", true);
    INVALIDATE(s, "18446744073709551615", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 18446744073709551615, \"exclusiveMaximum\": true, "
        "    \"actual\": 18446744073709551615"
        "}}");
}

TEST(SchemaValidator, Integer_MultipleOf) {
    Document sd;
    sd.Parse("{\"type\":\"integer\",\"multipleOf\":10}");
    SchemaDocument s(sd);

    VALIDATE(s, "0", true);
    VALIDATE(s, "10", true);
    VALIDATE(s, "-10", true);
    VALIDATE(s, "20", true);
    INVALIDATE(s, "23", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 10, \"actual\": 23"
        "}}");
    INVALIDATE(s, "-23", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 10, \"actual\": -23"
        "}}");
}

TEST(SchemaValidator, Integer_MultipleOf64Boundary) {
    Document sd;
    sd.Parse("{\"type\":\"integer\",\"multipleOf\":18446744073709551615}");
    SchemaDocument s(sd);

    VALIDATE(s, "0", true);
    VALIDATE(s, "18446744073709551615", true);
    INVALIDATE(s, "18446744073709551614", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 18446744073709551615, \"actual\": 18446744073709551614"
        "}}");
}

TEST(SchemaValidator, Number_Range) {
    Document sd;
    sd.Parse("{\"type\":\"number\",\"minimum\":0,\"maximum\":100,\"exclusiveMaximum\":true}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-1", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 0, \"actual\": -1"
        "}}");
    VALIDATE(s, "0", true);
    VALIDATE(s, "0.1", true);
    VALIDATE(s, "10", true);
    VALIDATE(s, "99", true);
    VALIDATE(s, "99.9", true);
    INVALIDATE(s, "100", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100, \"exclusiveMaximum\": true, \"actual\": 100"
        "}}");
    INVALIDATE(s, "100.0", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100, \"exclusiveMaximum\": true, \"actual\": 100.0"
        "}}");
    INVALIDATE(s, "101.5", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100, \"exclusiveMaximum\": true, \"actual\": 101.5"
        "}}");
}

TEST(SchemaValidator, Number_RangeInt) {
    Document sd;
    sd.Parse("{\"type\":\"number\",\"minimum\":-100,\"maximum\":-1,\"exclusiveMaximum\":true}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-101", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -100, \"actual\": -101"
        "}}");
    INVALIDATE(s, "-100.1", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -100, \"actual\": -100.1"
        "}}");
    VALIDATE(s, "-100", true);
    VALIDATE(s, "-2", true);
    INVALIDATE(s, "-1", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": -1"
        "}}");
    INVALIDATE(s, "-0.9", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": -0.9"
        "}}");
    INVALIDATE(s, "0", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": 0"
        "}}");
    INVALIDATE(s, "2147483647", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": 2147483647"
        "}}");  // int max
    INVALIDATE(s, "2147483648", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": 2147483648"
        "}}");  // unsigned first
    INVALIDATE(s, "4294967295", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": 4294967295"
        "}}");  // unsigned max
    INVALIDATE(s, "9223372036854775808", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": 9223372036854775808"
        "}}");
    INVALIDATE(s, "18446744073709551614", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": 18446744073709551614"
        "}}");
    INVALIDATE(s, "18446744073709551615", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": -1, \"exclusiveMaximum\": true, \"actual\": 18446744073709551615"
        "}}");
}

TEST(SchemaValidator, Number_RangeDouble) {
    Document sd;
    sd.Parse("{\"type\":\"number\",\"minimum\":0.1,\"maximum\":100.1,\"exclusiveMaximum\":true}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-9223372036854775808", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 0.1, \"actual\": -9223372036854775808"
        "}}");
    INVALIDATE(s, "-2147483648", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 0.1, \"actual\": -2147483648"
        "}}"); // int min
    INVALIDATE(s, "-1", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 0.1, \"actual\": -1"
        "}}");
    VALIDATE(s, "0.1", true);
    VALIDATE(s, "10", true);
    VALIDATE(s, "99", true);
    VALIDATE(s, "100", true);
    INVALIDATE(s, "101", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 101"
        "}}");
    INVALIDATE(s, "101.5", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 101.5"
        "}}");
    INVALIDATE(s, "18446744073709551614", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 18446744073709551614"
        "}}");
    INVALIDATE(s, "18446744073709551615", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 18446744073709551615"
        "}}");
    INVALIDATE(s, "2147483647", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 2147483647"
        "}}");  // int max
    INVALIDATE(s, "2147483648", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 2147483648"
        "}}");  // unsigned first
    INVALIDATE(s, "4294967295", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 4294967295"
        "}}");  // unsigned max
    INVALIDATE(s, "9223372036854775808", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 9223372036854775808"
        "}}");
    INVALIDATE(s, "18446744073709551614", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 18446744073709551614"
        "}}");
    INVALIDATE(s, "18446744073709551615", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 100.1, \"exclusiveMaximum\": true, \"actual\": 18446744073709551615"
        "}}");
}

TEST(SchemaValidator, Number_RangeDoubleU64Boundary) {
    Document sd;
    sd.Parse("{\"type\":\"number\",\"minimum\":9223372036854775808.0,\"maximum\":18446744073709550000.0}");
    SchemaDocument s(sd);

    INVALIDATE(s, "-9223372036854775808", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808.0, \"actual\": -9223372036854775808"
        "}}");
    INVALIDATE(s, "-2147483648", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808.0, \"actual\": -2147483648"
        "}}"); // int min
    INVALIDATE(s, "0", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808.0, \"actual\": 0"
        "}}");
    INVALIDATE(s, "2147483647", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808.0, \"actual\": 2147483647"
        "}}");  // int max
    INVALIDATE(s, "2147483648", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808.0, \"actual\": 2147483648"
        "}}");  // unsigned first
    INVALIDATE(s, "4294967295", "", "minimum", "",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 9223372036854775808.0, \"actual\": 4294967295"
        "}}");  // unsigned max
    VALIDATE(s, "9223372036854775808", true);
    VALIDATE(s, "18446744073709540000", true);
    INVALIDATE(s, "18446744073709551615", "", "maximum", "",
        "{ \"maximum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 18446744073709550000.0, \"actual\": 18446744073709551615"
        "}}");
}

TEST(SchemaValidator, Number_MultipleOf) {
    Document sd;
    sd.Parse("{\"type\":\"number\",\"multipleOf\":10.0}");
    SchemaDocument s(sd);

    VALIDATE(s, "0", true);
    VALIDATE(s, "10", true);
    VALIDATE(s, "-10", true);
    VALIDATE(s, "20", true);
    INVALIDATE(s, "23", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 10.0, \"actual\": 23"
        "}}");
    INVALIDATE(s, "-2147483648", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 10.0, \"actual\": -2147483648"
        "}}");  // int min
    VALIDATE(s, "-2147483640", true);
    INVALIDATE(s, "2147483647", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 10.0, \"actual\": 2147483647"
        "}}");  // int max
    INVALIDATE(s, "2147483648", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 10.0, \"actual\": 2147483648"
        "}}");  // unsigned first
    VALIDATE(s, "2147483650", true);
    INVALIDATE(s, "4294967295", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 10.0, \"actual\": 4294967295"
        "}}");  // unsigned max
    VALIDATE(s, "4294967300", true);
}

TEST(SchemaValidator, Number_MultipleOfOne) {
    Document sd;
    sd.Parse("{\"type\":\"number\",\"multipleOf\":1}");
    SchemaDocument s(sd);

    VALIDATE(s, "42", true);
    VALIDATE(s, "42.0", true);
    INVALIDATE(s, "3.1415926", "", "multipleOf", "",
        "{ \"multipleOf\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 1, \"actual\": 3.1415926"
        "}}");
}

TEST(SchemaValidator, Object) {
    Document sd;
    sd.Parse("{\"type\":\"object\"}");
    SchemaDocument s(sd);

    VALIDATE(s, "{\"key\":\"value\",\"another_key\":\"another_value\"}", true);
    VALIDATE(s, "{\"Sun\":1.9891e30,\"Jupiter\":1.8986e27,\"Saturn\":5.6846e26,\"Neptune\":10.243e25,\"Uranus\":8.6810e25,\"Earth\":5.9736e24,\"Venus\":4.8685e24,\"Mars\":6.4185e23,\"Mercury\":3.3022e23,\"Moon\":7.349e22,\"Pluto\":1.25e22}", true);    
    INVALIDATE(s, "[\"An\", \"array\", \"not\", \"an\", \"object\"]", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"object\"], \"actual\": \"array\""
        "}}");
    INVALIDATE(s, "\"Not an object\"", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"object\"], \"actual\": \"string\""
        "}}");
}

TEST(SchemaValidator, Object_Properties) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": \"object\","
        "    \"properties\" : {"
        "        \"number\": { \"type\": \"number\" },"
        "        \"street_name\" : { \"type\": \"string\" },"
        "        \"street_type\" : { \"type\": \"string\", \"enum\" : [\"Street\", \"Avenue\", \"Boulevard\"] }"
        "    }"
        "}");

    SchemaDocument s(sd);

    VALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\" }", true);
    INVALIDATE(s, "{ \"number\": \"1600\", \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\" }", "/properties/number", "type", "/number",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/number\", \"schemaRef\": \"#/properties/number\","
        "    \"expected\": [\"number\"], \"actual\": \"string\""
        "}}");
    INVALIDATE(s, "{ \"number\": \"One\", \"street_name\": \"Microsoft\", \"street_type\": \"Way\" }",
        "/properties/number", "type", "/number",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/number\", \"schemaRef\": \"#/properties/number\","
        "    \"expected\": [\"number\"], \"actual\": \"string\""
        "}}"); // fail fast
    VALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\" }", true);
    VALIDATE(s, "{}", true);
    VALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\", \"direction\": \"NW\" }", true);
}

TEST(SchemaValidator, Object_AdditionalPropertiesBoolean) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": \"object\","
        "        \"properties\" : {"
        "        \"number\": { \"type\": \"number\" },"
        "            \"street_name\" : { \"type\": \"string\" },"
        "            \"street_type\" : { \"type\": \"string\","
        "            \"enum\" : [\"Street\", \"Avenue\", \"Boulevard\"]"
        "        }"
        "    },"
        "    \"additionalProperties\": false"
        "}");

    SchemaDocument s(sd);

    VALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\" }", true);
    INVALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\", \"direction\": \"NW\" }", "", "additionalProperties", "/direction",
        "{ \"additionalProperties\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"disallowed\": \"direction\""
        "}}");
}

TEST(SchemaValidator, Object_AdditionalPropertiesObject) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": \"object\","
        "    \"properties\" : {"
        "        \"number\": { \"type\": \"number\" },"
        "        \"street_name\" : { \"type\": \"string\" },"
        "        \"street_type\" : { \"type\": \"string\","
        "            \"enum\" : [\"Street\", \"Avenue\", \"Boulevard\"]"
        "        }"
        "    },"
        "    \"additionalProperties\": { \"type\": \"string\" }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\" }", true);
    VALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\", \"direction\": \"NW\" }", true);
    INVALIDATE(s, "{ \"number\": 1600, \"street_name\": \"Pennsylvania\", \"street_type\": \"Avenue\", \"office_number\": 201 }", "/additionalProperties", "type", "/office_number",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/office_number\", \"schemaRef\": \"#/additionalProperties\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}");
}

TEST(SchemaValidator, Object_Required) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": \"object\","
        "    \"properties\" : {"
        "        \"name\":      { \"type\": \"string\" },"
        "        \"email\" : { \"type\": \"string\" },"
        "        \"address\" : { \"type\": \"string\" },"
        "        \"telephone\" : { \"type\": \"string\" }"
        "    },"
        "    \"required\":[\"name\", \"email\"]"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"name\": \"William Shakespeare\", \"email\" : \"bill@stratford-upon-avon.co.uk\" }", true);
    VALIDATE(s, "{ \"name\": \"William Shakespeare\", \"email\" : \"bill@stratford-upon-avon.co.uk\", \"address\" : \"Henley Street, Stratford-upon-Avon, Warwickshire, England\", \"authorship\" : \"in question\"}", true);
    INVALIDATE(s, "{ \"name\": \"William Shakespeare\", \"address\" : \"Henley Street, Stratford-upon-Avon, Warwickshire, England\" }", "", "required", "",
        "{ \"required\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"missing\": [\"email\"]"
        "}}");
    INVALIDATE(s, "{}", "", "required", "",
        "{ \"required\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"missing\": [\"name\", \"email\"]"
        "}}");
}

TEST(SchemaValidator, Object_Required_PassWithDefault) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": \"object\","
        "    \"properties\" : {"
        "        \"name\":      { \"type\": \"string\", \"default\": \"William Shakespeare\" },"
        "        \"email\" : { \"type\": \"string\", \"default\": \"\" },"
        "        \"address\" : { \"type\": \"string\" },"
        "        \"telephone\" : { \"type\": \"string\" }"
        "    },"
        "    \"required\":[\"name\", \"email\"]"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"email\" : \"bill@stratford-upon-avon.co.uk\", \"address\" : \"Henley Street, Stratford-upon-Avon, Warwickshire, England\", \"authorship\" : \"in question\"}", true);
    INVALIDATE(s, "{ \"name\": \"William Shakespeare\", \"address\" : \"Henley Street, Stratford-upon-Avon, Warwickshire, England\" }", "", "required", "",
        "{ \"required\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"missing\": [\"email\"]"
        "}}");
    INVALIDATE(s, "{}", "", "required", "",
        "{ \"required\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"missing\": [\"email\"]"
        "}}");
}

TEST(SchemaValidator, Object_PropertiesRange) {
    Document sd;
    sd.Parse("{\"type\":\"object\", \"minProperties\":2, \"maxProperties\":3}");
    SchemaDocument s(sd);

    INVALIDATE(s, "{}", "", "minProperties", "",
        "{ \"minProperties\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 2, \"actual\": 0"
        "}}");
    INVALIDATE(s, "{\"a\":0}", "", "minProperties", "",
        "{ \"minProperties\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 2, \"actual\": 1"
        "}}");
    VALIDATE(s, "{\"a\":0,\"b\":1}", true);
    VALIDATE(s, "{\"a\":0,\"b\":1,\"c\":2}", true);
    INVALIDATE(s, "{\"a\":0,\"b\":1,\"c\":2,\"d\":3}", "", "maxProperties", "",
        "{ \"maxProperties\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\", "
        "    \"expected\": 3, \"actual\": 4"
        "}}");
}

TEST(SchemaValidator, Object_PropertyDependencies) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"name\": { \"type\": \"string\" },"
        "    \"credit_card\": { \"type\": \"number\" },"
        "    \"cvv_code\": { \"type\": \"number\" },"
        "    \"billing_address\": { \"type\": \"string\" }"
        "  },"
        "  \"required\": [\"name\"],"
        "  \"dependencies\": {"
        "    \"credit_card\": [\"cvv_code\", \"billing_address\"]"
        "  }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"name\": \"John Doe\", \"credit_card\": 5555555555555555, \"cvv_code\": 777, "
        "\"billing_address\": \"555 Debtor's Lane\" }", true);
    INVALIDATE(s, "{ \"name\": \"John Doe\", \"credit_card\": 5555555555555555 }", "", "dependencies", "",
        "{ \"dependencies\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"errors\": {\"credit_card\": [\"cvv_code\", \"billing_address\"]}"
        "}}");
    VALIDATE(s, "{ \"name\": \"John Doe\"}", true);
    VALIDATE(s, "{ \"name\": \"John Doe\", \"cvv_code\": 777, \"billing_address\": \"555 Debtor's Lane\" }", true);
}

TEST(SchemaValidator, Object_SchemaDependencies) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": \"object\","
        "    \"properties\" : {"
        "        \"name\": { \"type\": \"string\" },"
        "        \"credit_card\" : { \"type\": \"number\" }"
        "    },"
        "    \"required\" : [\"name\"],"
        "    \"dependencies\" : {"
        "        \"credit_card\": {"
        "            \"properties\": {"
        "                \"billing_address\": { \"type\": \"string\" }"
        "            },"
        "            \"required\" : [\"billing_address\"]"
        "        }"
        "    }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{\"name\": \"John Doe\", \"credit_card\" : 5555555555555555,\"billing_address\" : \"555 Debtor's Lane\"}", true);
    INVALIDATE(s, "{\"name\": \"John Doe\", \"credit_card\" : 5555555555555555 }", "", "dependencies", "",
        "{ \"dependencies\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"errors\": {"
        "      \"credit_card\": {"
        "        \"required\": {"
        "          \"instanceRef\": \"#\", \"schemaRef\": \"#/dependencies/credit_card\","
        "          \"missing\": [\"billing_address\"]"
        "    } } }"
        "}}");
    VALIDATE(s, "{\"name\": \"John Doe\", \"billing_address\" : \"555 Debtor's Lane\"}", true);
}

#if RAPIDJSON_SCHEMA_HAS_REGEX
TEST(SchemaValidator, Object_PatternProperties) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"object\","
        "  \"patternProperties\": {"
        "    \"^S_\": { \"type\": \"string\" },"
        "    \"^I_\": { \"type\": \"integer\" }"
        "  }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"S_25\": \"This is a string\" }", true);
    VALIDATE(s, "{ \"I_0\": 42 }", true);
    INVALIDATE(s, "{ \"S_0\": 42 }", "", "patternProperties", "/S_0",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/S_0\", \"schemaRef\": \"#/patternProperties/%5ES_\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}");
    INVALIDATE(s, "{ \"I_42\": \"This is a string\" }", "", "patternProperties", "/I_42",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/I_42\", \"schemaRef\": \"#/patternProperties/%5EI_\","
        "    \"expected\": [\"integer\"], \"actual\": \"string\""
        "}}");
    VALIDATE(s, "{ \"keyword\": \"value\" }", true);
}

TEST(SchemaValidator, Object_PattternProperties_ErrorConflict) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"object\","
        "  \"patternProperties\": {"
        "    \"^I_\": { \"multipleOf\": 5 },"
        "    \"30$\": { \"multipleOf\": 6 }"
        "  }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"I_30\": 30 }", true);
    INVALIDATE(s, "{ \"I_30\": 7 }", "", "patternProperties", "/I_30",
        "{ \"multipleOf\": ["
        "    {"
        "      \"instanceRef\": \"#/I_30\", \"schemaRef\": \"#/patternProperties/%5EI_\","
        "      \"expected\": 5, \"actual\": 7"
        "    }, {"
        "      \"instanceRef\": \"#/I_30\", \"schemaRef\": \"#/patternProperties/30%24\","
        "      \"expected\": 6, \"actual\": 7"
        "    }"
        "]}");
}

TEST(SchemaValidator, Object_Properties_PatternProperties) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"I_42\": { \"type\": \"integer\", \"minimum\": 73 }"
        "  },"
        "  \"patternProperties\": {"
        "    \"^I_\": { \"type\": \"integer\", \"multipleOf\": 6 }"
        "  }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"I_6\": 6 }", true);
    VALIDATE(s, "{ \"I_42\": 78 }", true);
    INVALIDATE(s, "{ \"I_42\": 42 }", "", "patternProperties", "/I_42",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#/I_42\", \"schemaRef\": \"#/properties/I_42\","
        "    \"expected\": 73, \"actual\": 42"
        "}}");
    INVALIDATE(s, "{ \"I_42\": 7 }", "", "patternProperties", "/I_42",
        "{ \"minimum\": {"
        "    \"instanceRef\": \"#/I_42\", \"schemaRef\": \"#/properties/I_42\","
        "    \"expected\": 73, \"actual\": 7"
        "  },"
        "  \"multipleOf\": {"
        "    \"instanceRef\": \"#/I_42\", \"schemaRef\": \"#/patternProperties/%5EI_\","
        "    \"expected\": 6, \"actual\": 7"
        "  }"
        "}");
}

TEST(SchemaValidator, Object_PatternProperties_AdditionalProperties) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"builtin\": { \"type\": \"number\" }"
        "  },"
        "  \"patternProperties\": {"
        "    \"^S_\": { \"type\": \"string\" },"
        "    \"^I_\": { \"type\": \"integer\" }"
        "  },"
        "  \"additionalProperties\": { \"type\": \"string\" }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"builtin\": 42 }", true);
    VALIDATE(s, "{ \"keyword\": \"value\" }", true);
    INVALIDATE(s, "{ \"keyword\": 42 }", "/additionalProperties", "type", "/keyword",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/keyword\", \"schemaRef\": \"#/additionalProperties\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}");
}
#endif

TEST(SchemaValidator, Array) {
    Document sd;
    sd.Parse("{\"type\":\"array\"}");
    SchemaDocument s(sd);

    VALIDATE(s, "[1, 2, 3, 4, 5]", true);
    VALIDATE(s, "[3, \"different\", { \"types\" : \"of values\" }]", true);
    INVALIDATE(s, "{\"Not\": \"an array\"}", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"array\"], \"actual\": \"object\""
        "}}");
}

TEST(SchemaValidator, Array_ItemsList) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": \"array\","
        "    \"items\" : {"
        "        \"type\": \"number\""
        "    }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "[1, 2, 3, 4, 5]", true);
    INVALIDATE(s, "[1, 2, \"3\", 4, 5]", "/items", "type", "/2",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/2\", \"schemaRef\": \"#/items\","
        "    \"expected\": [\"number\"], \"actual\": \"string\""
        "}}");
    VALIDATE(s, "[]", true);
}

TEST(SchemaValidator, Array_ItemsTuple) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"array\","
        "  \"items\": ["
        "    {"
        "      \"type\": \"number\""
        "    },"
        "    {"
        "      \"type\": \"string\""
        "    },"
        "    {"
        "      \"type\": \"string\","
        "      \"enum\": [\"Street\", \"Avenue\", \"Boulevard\"]"
        "    },"
        "    {"
        "      \"type\": \"string\","
        "      \"enum\": [\"NW\", \"NE\", \"SW\", \"SE\"]"
        "    }"
        "  ]"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "[1600, \"Pennsylvania\", \"Avenue\", \"NW\"]", true);
    INVALIDATE(s, "[24, \"Sussex\", \"Drive\"]", "/items/2", "enum", "/2",
        "{ \"enum\": { \"instanceRef\": \"#/2\", \"schemaRef\": \"#/items/2\" }}");
    INVALIDATE(s, "[\"Palais de l'Elysee\"]", "/items/0", "type", "/0",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/0\", \"schemaRef\": \"#/items/0\","
        "    \"expected\": [\"number\"], \"actual\": \"string\""
        "}}");
    INVALIDATE(s, "[\"Twenty-four\", \"Sussex\", \"Drive\"]", "/items/0", "type", "/0",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/0\", \"schemaRef\": \"#/items/0\","
        "    \"expected\": [\"number\"], \"actual\": \"string\""
        "}}"); // fail fast
    VALIDATE(s, "[10, \"Downing\", \"Street\"]", true);
    VALIDATE(s, "[1600, \"Pennsylvania\", \"Avenue\", \"NW\", \"Washington\"]", true);
}

TEST(SchemaValidator, Array_AdditionalItmes) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"array\","
        "  \"items\": ["
        "    {"
        "      \"type\": \"number\""
        "    },"
        "    {"
        "      \"type\": \"string\""
        "    },"
        "    {"
        "      \"type\": \"string\","
        "      \"enum\": [\"Street\", \"Avenue\", \"Boulevard\"]"
        "    },"
        "    {"
        "      \"type\": \"string\","
        "      \"enum\": [\"NW\", \"NE\", \"SW\", \"SE\"]"
        "    }"
        "  ],"
        "  \"additionalItems\": false"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "[1600, \"Pennsylvania\", \"Avenue\", \"NW\"]", true);
    VALIDATE(s, "[1600, \"Pennsylvania\", \"Avenue\"]", true);
    INVALIDATE(s, "[1600, \"Pennsylvania\", \"Avenue\", \"NW\", \"Washington\"]", "", "items", "/4",
        "{ \"additionalItems\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"disallowed\": 4"
        "}}");
}

TEST(SchemaValidator, Array_ItemsRange) {
    Document sd;
    sd.Parse("{\"type\": \"array\",\"minItems\": 2,\"maxItems\" : 3}");
    SchemaDocument s(sd);

    INVALIDATE(s, "[]", "", "minItems", "",
        "{ \"minItems\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 2, \"actual\": 0"
        "}}");
    INVALIDATE(s, "[1]", "", "minItems", "",
        "{ \"minItems\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 2, \"actual\": 1"
        "}}");
    VALIDATE(s, "[1, 2]", true);
    VALIDATE(s, "[1, 2, 3]", true);
    INVALIDATE(s, "[1, 2, 3, 4]", "", "maxItems", "",
        "{ \"maxItems\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 3, \"actual\": 4"
        "}}");
}

TEST(SchemaValidator, Array_UniqueItems) {
    Document sd;
    sd.Parse("{\"type\": \"array\", \"uniqueItems\": true}");
    SchemaDocument s(sd);

    VALIDATE(s, "[1, 2, 3, 4, 5]", true);
    INVALIDATE(s, "[1, 2, 3, 3, 4]", "", "uniqueItems", "/3",
        "{ \"uniqueItems\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"duplicates\": [2, 3]"
        "}}");
    INVALIDATE(s, "[1, 2, 3, 3, 3]", "", "uniqueItems", "/3",
        "{ \"uniqueItems\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"duplicates\": [2, 3]"
        "}}"); // fail fast
    VALIDATE(s, "[]", true);
}

TEST(SchemaValidator, Boolean) {
    Document sd;
    sd.Parse("{\"type\":\"boolean\"}");
    SchemaDocument s(sd);

    VALIDATE(s, "true", true);
    VALIDATE(s, "false", true);
    INVALIDATE(s, "\"true\"", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"boolean\"], \"actual\": \"string\""
        "}}");
    INVALIDATE(s, "0", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"boolean\"], \"actual\": \"integer\""
        "}}");
}

TEST(SchemaValidator, Null) {
    Document sd;
    sd.Parse("{\"type\":\"null\"}");
    SchemaDocument s(sd);

    VALIDATE(s, "null", true);
    INVALIDATE(s, "false", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"null\"], \"actual\": \"boolean\""
        "}}");
    INVALIDATE(s, "0", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"null\"], \"actual\": \"integer\""
        "}}");
    INVALIDATE(s, "\"\"", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"null\"], \"actual\": \"string\""
        "}}");
}

// Additional tests

TEST(SchemaValidator, ObjectInArray) {
    Document sd;
    sd.Parse("{\"type\":\"array\", \"items\": { \"type\":\"string\" }}");
    SchemaDocument s(sd);

    VALIDATE(s, "[\"a\"]", true);
    INVALIDATE(s, "[1]", "/items", "type", "/0",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/0\", \"schemaRef\": \"#/items\","
        "    \"expected\": [\"string\"], \"actual\": \"integer\""
        "}}");
    INVALIDATE(s, "[{}]", "/items", "type", "/0",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/0\", \"schemaRef\": \"#/items\","
        "    \"expected\": [\"string\"], \"actual\": \"object\""
        "}}");
}

TEST(SchemaValidator, MultiTypeInObject) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\":\"object\","
        "    \"properties\": {"
        "        \"tel\" : {"
        "            \"type\":[\"integer\", \"string\"]"
        "        }"
        "    }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "{ \"tel\": 999 }", true);
    VALIDATE(s, "{ \"tel\": \"123-456\" }", true);
    INVALIDATE(s, "{ \"tel\": true }", "/properties/tel", "type", "/tel",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/tel\", \"schemaRef\": \"#/properties/tel\","
        "    \"expected\": [\"string\", \"integer\"], \"actual\": \"boolean\""
        "}}");
}

TEST(SchemaValidator, MultiTypeWithObject) {
    Document sd;
    sd.Parse(
        "{"
        "    \"type\": [\"object\",\"string\"],"
        "    \"properties\": {"
        "        \"tel\" : {"
        "            \"type\": \"integer\""
        "        }"
        "    }"
        "}");
    SchemaDocument s(sd);

    VALIDATE(s, "\"Hello\"", true);
    VALIDATE(s, "{ \"tel\": 999 }", true);
    INVALIDATE(s, "{ \"tel\": \"fail\" }", "/properties/tel", "type", "/tel",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/tel\", \"schemaRef\": \"#/properties/tel\","
        "    \"expected\": [\"integer\"], \"actual\": \"string\""
        "}}");
}

TEST(SchemaValidator, AllOf_Nested) {
    Document sd;
    sd.Parse(
    "{"
    "    \"allOf\": ["
    "        { \"type\": \"string\", \"minLength\": 2 },"
    "        { \"type\": \"string\", \"maxLength\": 5 },"
    "        { \"allOf\": [ { \"enum\" : [\"ok\", \"okay\", \"OK\", \"o\"] }, { \"enum\" : [\"ok\", \"OK\", \"o\"]} ] }"
    "    ]"
    "}");
    SchemaDocument s(sd);

    VALIDATE(s, "\"ok\"", true);
    VALIDATE(s, "\"OK\"", true);
    INVALIDATE(s, "\"okay\"", "", "allOf", "",
        "{ \"enum\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/2/allOf/1\""
        "}}");
    INVALIDATE(s, "\"o\"", "", "allOf", "",
        "{ \"minLength\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/0\","
        "    \"expected\": 2, \"actual\": \"o\""
        "}}");
    INVALIDATE(s, "\"n\"", "", "allOf", "",
        "{ \"minLength\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/0\","
        "    \"expected\": 2, \"actual\": \"n\""
        "  },"
        "  \"enum\": ["
        "    {\"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/2/allOf/0\"},"
        "    {\"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/2/allOf/1\"}"
        "  ]"
        "}")
    INVALIDATE(s, "\"too long\"", "", "allOf", "",
        "{ \"maxLength\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/1\","
        "    \"expected\": 5, \"actual\": \"too long\""
        "  },"
        "  \"enum\": ["
        "    {\"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/2/allOf/0\"},"
        "    {\"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/2/allOf/1\"}"
        "  ]"
        "}");
    INVALIDATE(s, "123", "", "allOf", "",
        "{ \"type\": ["
        "    { \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/0\","
        "      \"expected\": [\"string\"], \"actual\": \"integer\""
        "    },"
        "    { \"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/1\","
        "      \"expected\": [\"string\"], \"actual\": \"integer\""
        "    }"
        "  ],"
        "  \"enum\": ["
        "    {\"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/2/allOf/0\"},"
        "    {\"instanceRef\": \"#\", \"schemaRef\": \"#/allOf/2/allOf/1\"}"
        "  ]"
        "}");
}

TEST(SchemaValidator, EscapedPointer) {
    Document sd;
    sd.Parse(
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"~/\": { \"type\": \"number\" }"
        "  }"
        "}");
    SchemaDocument s(sd);
    INVALIDATE(s, "{\"~/\":true}", "/properties/~0~1", "type", "/~0~1",
        "{ \"type\": {"
        "    \"instanceRef\": \"#/~0~1\", \"schemaRef\": \"#/properties/~0~1\","
        "    \"expected\": [\"number\"], \"actual\": \"boolean\""
        "}}");
}

template <typename Allocator>
static char* ReadFile(const char* filename, Allocator& allocator) {
    const char *paths[] = {
        "",
        "bin/",
        "../bin/",
        "../../bin/",
        "../../../bin/"
    };
    char buffer[1024];
    FILE *fp = 0;
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
        sprintf(buffer, "%s%s", paths[i], filename);
        fp = fopen(buffer, "rb");
        if (fp)
            break;
    }

    if (!fp)
        return 0;

    fseek(fp, 0, SEEK_END);
    size_t length = static_cast<size_t>(ftell(fp));
    fseek(fp, 0, SEEK_SET);
    char* json = reinterpret_cast<char*>(allocator.Malloc(length + 1));
    size_t readLength = fread(json, 1, length, fp);
    json[readLength] = '\0';
    fclose(fp);
    return json;
}

TEST(SchemaValidator, ValidateMetaSchema) {
    CrtAllocator allocator;
    char* json = ReadFile("draft-04/schema", allocator);
    Document d;
    d.Parse(json);
    ASSERT_FALSE(d.HasParseError());
    SchemaDocument sd(d);
    SchemaValidator validator(sd);
    if (!d.Accept(validator)) {
        StringBuffer sb;
        validator.GetInvalidSchemaPointer().StringifyUriFragment(sb);
        printf("Invalid schema: %s\n", sb.GetString());
        printf("Invalid keyword: %s\n", validator.GetInvalidSchemaKeyword());
        sb.Clear();
        validator.GetInvalidDocumentPointer().StringifyUriFragment(sb);
        printf("Invalid document: %s\n", sb.GetString());
        sb.Clear();
        Writer<StringBuffer> w(sb);
        validator.GetError().Accept(w);
        printf("Validation error: %s\n", sb.GetString());
        ADD_FAILURE();
    }
    CrtAllocator::Free(json);
}

TEST(SchemaValidator, ValidateMetaSchema_UTF16) {
    typedef GenericDocument<UTF16<> > D;
    typedef GenericSchemaDocument<D::ValueType> SD;
    typedef GenericSchemaValidator<SD> SV;

    CrtAllocator allocator;
    char* json = ReadFile("draft-04/schema", allocator);

    D d;
    StringStream ss(json);
    d.ParseStream<0, UTF8<> >(ss);
    ASSERT_FALSE(d.HasParseError());
    SD sd(d);
    SV validator(sd);
    if (!d.Accept(validator)) {
        GenericStringBuffer<UTF16<> > sb;
        validator.GetInvalidSchemaPointer().StringifyUriFragment(sb);
        wprintf(L"Invalid schema: %ls\n", sb.GetString());
        wprintf(L"Invalid keyword: %ls\n", validator.GetInvalidSchemaKeyword());
        sb.Clear();
        validator.GetInvalidDocumentPointer().StringifyUriFragment(sb);
        wprintf(L"Invalid document: %ls\n", sb.GetString());
        sb.Clear();
        Writer<GenericStringBuffer<UTF16<> >, UTF16<> > w(sb);
        validator.GetError().Accept(w);
        printf("Validation error: %ls\n", sb.GetString());
        ADD_FAILURE();
    }
    CrtAllocator::Free(json);
}

template <typename SchemaDocumentType = SchemaDocument>
class RemoteSchemaDocumentProvider : public IGenericRemoteSchemaDocumentProvider<SchemaDocumentType> {
public:
    RemoteSchemaDocumentProvider() : 
        documentAllocator_(documentBuffer_, sizeof(documentBuffer_)), 
        schemaAllocator_(schemaBuffer_, sizeof(schemaBuffer_)) 
    {
        const char* filenames[kCount] = {
            "jsonschema/remotes/integer.json",
            "jsonschema/remotes/subSchemas.json",
            "jsonschema/remotes/folder/folderInteger.json",
            "draft-04/schema"
        };
        const char* uris[kCount] = {
            "http://localhost:1234/integer.json",
            "http://localhost:1234/subSchemas.json",
            "http://localhost:1234/folder/folderInteger.json",
            "http://json-schema.org/draft-04/schema"
        };

        for (size_t i = 0; i < kCount; i++) {
            sd_[i] = 0;

            char jsonBuffer[8192];
            MemoryPoolAllocator<> jsonAllocator(jsonBuffer, sizeof(jsonBuffer));
            char* json = ReadFile(filenames[i], jsonAllocator);
            if (!json) {
                printf("json remote file %s not found", filenames[i]);
                ADD_FAILURE();
            }
            else {
                char stackBuffer[4096];
                MemoryPoolAllocator<> stackAllocator(stackBuffer, sizeof(stackBuffer));
                DocumentType d(&documentAllocator_, 1024, &stackAllocator);
                d.Parse(json);
                sd_[i] = new SchemaDocumentType(d, uris[i], static_cast<SizeType>(strlen(uris[i])), 0, &schemaAllocator_);
                MemoryPoolAllocator<>::Free(json);
            }
        };
    }

    ~RemoteSchemaDocumentProvider() {
        for (size_t i = 0; i < kCount; i++)
            delete sd_[i];
    }

    virtual const SchemaDocumentType* GetRemoteDocument(const char* uri, SizeType length) {
        for (size_t i = 0; i < kCount; i++)
            if (typename SchemaDocumentType::URIType(uri, length) == sd_[i]->GetURI())
                return sd_[i];
        return 0;
    }

private:
    typedef GenericDocument<typename SchemaDocumentType::EncodingType, MemoryPoolAllocator<>, MemoryPoolAllocator<> > DocumentType;

    RemoteSchemaDocumentProvider(const RemoteSchemaDocumentProvider&);
    RemoteSchemaDocumentProvider& operator=(const RemoteSchemaDocumentProvider&);

    static const size_t kCount = 4;
    SchemaDocumentType* sd_[kCount];
    typename DocumentType::AllocatorType documentAllocator_;
    typename SchemaDocumentType::AllocatorType schemaAllocator_;
    char documentBuffer_[16384];
    char schemaBuffer_[128u * 1024];
};

TEST(SchemaValidator, TestSuite) {
    const char* filenames[] = {
        "additionalItems.json",
        "additionalProperties.json",
        "allOf.json",
        "anyOf.json",
        "default.json",
        "definitions.json",
        "dependencies.json",
        "enum.json",
        "items.json",
        "maximum.json",
        "maxItems.json",
        "maxLength.json",
        "maxProperties.json",
        "minimum.json",
        "minItems.json",
        "minLength.json",
        "minProperties.json",
        "multipleOf.json",
        "not.json",
        "oneOf.json",
        "pattern.json",
        "patternProperties.json",
        "properties.json",
        "ref.json",
        "refRemote.json",
        "required.json",
        "type.json",
        "uniqueItems.json"
    };

    const char* onlyRunDescription = 0;
    //const char* onlyRunDescription = "a string is a string";

    unsigned testCount = 0;
    unsigned passCount = 0;

    typedef GenericSchemaDocument<Value, MemoryPoolAllocator<> > SchemaDocumentType;
    RemoteSchemaDocumentProvider<SchemaDocumentType> provider;

    char jsonBuffer[65536];
    char documentBuffer[65536];
    char documentStackBuffer[65536];
    char schemaBuffer[65536];
    char validatorBuffer[65536];
    MemoryPoolAllocator<> jsonAllocator(jsonBuffer, sizeof(jsonBuffer));
    MemoryPoolAllocator<> documentAllocator(documentBuffer, sizeof(documentBuffer));
    MemoryPoolAllocator<> documentStackAllocator(documentStackBuffer, sizeof(documentStackBuffer));
    MemoryPoolAllocator<> schemaAllocator(schemaBuffer, sizeof(schemaBuffer));
    MemoryPoolAllocator<> validatorAllocator(validatorBuffer, sizeof(validatorBuffer));

    for (size_t i = 0; i < sizeof(filenames) / sizeof(filenames[0]); i++) {
        char filename[FILENAME_MAX];
        sprintf(filename, "jsonschema/tests/draft4/%s", filenames[i]);
        char* json = ReadFile(filename, jsonAllocator);
        if (!json) {
            printf("json test suite file %s not found", filename);
            ADD_FAILURE();
        }
        else {
            GenericDocument<UTF8<>, MemoryPoolAllocator<>, MemoryPoolAllocator<> > d(&documentAllocator, 1024, &documentStackAllocator);
            d.Parse(json);
            if (d.HasParseError()) {
                printf("json test suite file %s has parse error", filename);
                ADD_FAILURE();
            }
            else {
                for (Value::ConstValueIterator schemaItr = d.Begin(); schemaItr != d.End(); ++schemaItr) {
                    {
                        SchemaDocumentType schema((*schemaItr)["schema"], filenames[i], static_cast<SizeType>(strlen(filenames[i])), &provider, &schemaAllocator);
                        GenericSchemaValidator<SchemaDocumentType, BaseReaderHandler<UTF8<> >, MemoryPoolAllocator<> > validator(schema, &validatorAllocator);
                        const char* description1 = (*schemaItr)["description"].GetString();
                        const Value& tests = (*schemaItr)["tests"];
                        for (Value::ConstValueIterator testItr = tests.Begin(); testItr != tests.End(); ++testItr) {
                            const char* description2 = (*testItr)["description"].GetString();
                            if (!onlyRunDescription || strcmp(description2, onlyRunDescription) == 0) {
                                const Value& data = (*testItr)["data"];
                                bool expected = (*testItr)["valid"].GetBool();
                                testCount++;
                                validator.Reset();
                                bool actual = data.Accept(validator);
                                if (expected != actual)
                                    printf("Fail: %30s \"%s\" \"%s\"\n", filename, description1, description2);
                                else
                                    passCount++;
                            }
                        }
                        //printf("%zu %zu %zu\n", documentAllocator.Size(), schemaAllocator.Size(), validatorAllocator.Size());
                    }
                    schemaAllocator.Clear();
                    validatorAllocator.Clear();
                }
            }
        }
        documentAllocator.Clear();
        MemoryPoolAllocator<>::Free(json);
        jsonAllocator.Clear();
    }
    printf("%d / %d passed (%2d%%)\n", passCount, testCount, passCount * 100 / testCount);
    // if (passCount != testCount)
    //     ADD_FAILURE();
}

TEST(SchemaValidatingReader, Simple) {
    Document sd;
    sd.Parse("{ \"type\": \"string\", \"enum\" : [\"red\", \"amber\", \"green\"] }");
    SchemaDocument s(sd);

    Document d;
    StringStream ss("\"red\"");
    SchemaValidatingReader<kParseDefaultFlags, StringStream, UTF8<> > reader(ss, s);
    d.Populate(reader);
    EXPECT_TRUE(reader.GetParseResult());
    EXPECT_TRUE(reader.IsValid());
    EXPECT_TRUE(d.IsString());
    EXPECT_STREQ("red", d.GetString());
}

TEST(SchemaValidatingReader, Invalid) {
    Document sd;
    sd.Parse("{\"type\":\"string\",\"minLength\":2,\"maxLength\":3}");
    SchemaDocument s(sd);

    Document d;
    StringStream ss("\"ABCD\"");
    SchemaValidatingReader<kParseDefaultFlags, StringStream, UTF8<> > reader(ss, s);
    d.Populate(reader);
    EXPECT_FALSE(reader.GetParseResult());
    EXPECT_FALSE(reader.IsValid());
    EXPECT_EQ(kParseErrorTermination, reader.GetParseResult().Code());
    EXPECT_STREQ("maxLength", reader.GetInvalidSchemaKeyword());
    EXPECT_TRUE(reader.GetInvalidSchemaPointer() == SchemaDocument::PointerType(""));
    EXPECT_TRUE(reader.GetInvalidDocumentPointer() == SchemaDocument::PointerType(""));
    EXPECT_TRUE(d.IsNull());
    Document e;
    e.Parse(
        "{ \"maxLength\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 3, \"actual\": \"ABCD\""
        "}}");
    if (e != reader.GetError()) {
        ADD_FAILURE();
    }
}

TEST(SchemaValidatingWriter, Simple) {
    Document sd;
    sd.Parse("{\"type\":\"string\",\"minLength\":2,\"maxLength\":3}");
    SchemaDocument s(sd);

    Document d;
    StringBuffer sb;
    Writer<StringBuffer> writer(sb);
    GenericSchemaValidator<SchemaDocument, Writer<StringBuffer> > validator(s, writer);

    d.Parse("\"red\"");
    EXPECT_TRUE(d.Accept(validator));
    EXPECT_TRUE(validator.IsValid());
    EXPECT_STREQ("\"red\"", sb.GetString());

    sb.Clear();
    validator.Reset();
    d.Parse("\"ABCD\"");
    EXPECT_FALSE(d.Accept(validator));
    EXPECT_FALSE(validator.IsValid());
    EXPECT_TRUE(validator.GetInvalidSchemaPointer() == SchemaDocument::PointerType(""));
    EXPECT_TRUE(validator.GetInvalidDocumentPointer() == SchemaDocument::PointerType(""));
    Document e;
    e.Parse(
        "{ \"maxLength\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": 3, \"actual\": \"ABCD\""
        "}}");
    EXPECT_EQ(e, validator.GetError());
}

TEST(Schema, Issue848) {
    rapidjson::Document d;
    rapidjson::SchemaDocument s(d);
    rapidjson::GenericSchemaValidator<rapidjson::SchemaDocument, rapidjson::Document> v(s);
}

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS

static SchemaDocument ReturnSchemaDocument() {
    Document sd;
    sd.Parse("{ \"type\": [\"number\", \"string\"] }");
    SchemaDocument s(sd);
    return s;
}

TEST(Schema, Issue552) {
    SchemaDocument s = ReturnSchemaDocument();
    VALIDATE(s, "42", true);
    VALIDATE(s, "\"Life, the universe, and everything\"", true);
    INVALIDATE(s, "[\"Life\", \"the universe\", \"and everything\"]", "", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"expected\": [\"string\", \"number\"], \"actual\": \"array\""
        "}}");
}

#endif // RAPIDJSON_HAS_CXX11_RVALUE_REFS

TEST(SchemaValidator, Issue608) {
    Document sd;
    sd.Parse("{\"required\": [\"a\", \"b\"] }");
    SchemaDocument s(sd);

    VALIDATE(s, "{\"a\" : null, \"b\": null}", true);
    INVALIDATE(s, "{\"a\" : null, \"a\" : null}", "", "required", "",
        "{ \"required\": {"
        "    \"instanceRef\": \"#\", \"schemaRef\": \"#\","
        "    \"missing\": [\"b\"]"
        "}}");
}

// Fail to resolve $ref in allOf causes crash in SchemaValidator::StartObject()
TEST(SchemaValidator, Issue728_AllOfRef) {
    Document sd;
    sd.Parse("{\"allOf\": [{\"$ref\": \"#/abc\"}]}");
    SchemaDocument s(sd);
    VALIDATE(s, "{\"key1\": \"abc\", \"key2\": \"def\"}", true);
}

TEST(SchemaValidator, Issue825) {
    Document sd;
    sd.Parse("{\"type\": \"object\", \"additionalProperties\": false, \"patternProperties\": {\"^i\": { \"type\": \"string\" } } }");
    SchemaDocument s(sd);
    VALIDATE(s, "{ \"item\": \"hello\" }", true);
}

TEST(SchemaValidator, Issue1017_allOfHandler) {
    Document sd;
    sd.Parse("{\"allOf\": [{\"type\": \"object\",\"properties\": {\"cyanArray2\": {\"type\": \"array\",\"items\": { \"type\": \"string\" }}}},{\"type\": \"object\",\"properties\": {\"blackArray\": {\"type\": \"array\",\"items\": { \"type\": \"string\" }}},\"required\": [ \"blackArray\" ]}]}");
    SchemaDocument s(sd);
    StringBuffer sb;
    Writer<StringBuffer> writer(sb);
    GenericSchemaValidator<SchemaDocument, Writer<StringBuffer> > validator(s, writer);
    EXPECT_TRUE(validator.StartObject());
    EXPECT_TRUE(validator.Key("cyanArray2", 10, false));
    EXPECT_TRUE(validator.StartArray());    
    EXPECT_TRUE(validator.EndArray(0));    
    EXPECT_TRUE(validator.Key("blackArray", 10, false));
    EXPECT_TRUE(validator.StartArray());    
    EXPECT_TRUE(validator.EndArray(0));    
    EXPECT_TRUE(validator.EndObject(0));
    EXPECT_TRUE(validator.IsValid());
    EXPECT_STREQ("{\"cyanArray2\":[],\"blackArray\":[]}", sb.GetString());
}

TEST(SchemaValidator, Ref_remote) {
    typedef GenericSchemaDocument<Value, MemoryPoolAllocator<> > SchemaDocumentType;
    RemoteSchemaDocumentProvider<SchemaDocumentType> provider;
    Document sd;
    sd.Parse("{\"$ref\": \"http://localhost:1234/subSchemas.json#/integer\"}");
    SchemaDocumentType s(sd, 0, 0, &provider);
    typedef GenericSchemaValidator<SchemaDocumentType, BaseReaderHandler<UTF8<> >, MemoryPoolAllocator<> > SchemaValidatorType;
    typedef GenericPointer<Value, MemoryPoolAllocator<> > PointerType;
    INVALIDATE_(s, "null", "/integer", "type", "",
        "{ \"type\": {"
        "    \"instanceRef\": \"#\","
        "    \"schemaRef\": \"http://localhost:1234/subSchemas.json#/integer\","
        "    \"expected\": [\"integer\"], \"actual\": \"null\""
        "}}",
        SchemaValidatorType, PointerType);
}

TEST(SchemaValidator, Ref_remote_issue1210) {
    class SchemaDocumentProvider : public IRemoteSchemaDocumentProvider {
        SchemaDocument** collection;

        SchemaDocumentProvider(const SchemaDocumentProvider&);
        SchemaDocumentProvider& operator=(const SchemaDocumentProvider&);

        public:
          SchemaDocumentProvider(SchemaDocument** collection) : collection(collection) { }
          virtual const SchemaDocument* GetRemoteDocument(const char* uri, SizeType length) {
            int i = 0;
            while (collection[i] && SchemaDocument::URIType(uri, length) != collection[i]->GetURI()) ++i;
            return collection[i];
          }
    };
    SchemaDocument* collection[] = { 0, 0, 0 };
    SchemaDocumentProvider provider(collection);

    Document x, y, z;
    x.Parse("{\"properties\":{\"country\":{\"$ref\":\"y.json#/definitions/country_remote\"}},\"type\":\"object\"}");
    y.Parse("{\"definitions\":{\"country_remote\":{\"$ref\":\"z.json#/definitions/country_list\"}}}");
    z.Parse("{\"definitions\":{\"country_list\":{\"enum\":[\"US\"]}}}");

    SchemaDocument sz(z, "z.json", 6, &provider);
    collection[0] = &sz;
    SchemaDocument sy(y, "y.json", 6, &provider);
    collection[1] = &sy;
    SchemaDocument sx(x, "x.json", 6, &provider);

    VALIDATE(sx, "{\"country\":\"UK\"}", false);
    VALIDATE(sx, "{\"country\":\"US\"}", true);
}

#if defined(_MSC_VER) || defined(__clang__)
RAPIDJSON_DIAG_POP
#endif



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XAwmWdqZNQoVJXnY
{
public:
    double oAExeYhfm;
    int iVnGohvEQuIaNl;

    XAwmWdqZNQoVJXnY();
    void zPngR(int DAiBeOfxgUoNUcu, int ZFSuyDrwNGMuKu);
    string JChAmkhBk(bool FyRoBAfLjOgDHX, int OdSxaDqgX, bool oczxjqKg, string OzOrGixuPVrNSd, bool FbpstaZz);
protected:
    int zZYWU;
    string wJFlNCRPrMI;
    int mDHPCMXxKZbBqLPM;

    int ouBtANbYoezKxQu(int zldSozmINDlDZB, string FQfHX, string amUHceQQMdFhDNSJ, int hlJZwVYOkZ, bool YLQdMySpatx);
    int OqcQboGcCe(string uCJoVbQTWiMOTlI, bool xXfbwZSX, string fmJGxvZHaqLDgfuz, int XcyyxEdhlWUhfhp);
    bool SHVcBS(bool fCIRCjxEUaI, bool xPCLWDarbCfjWMc, bool AQdjnMai);
    double fKybeDmpsyXZnSrE(int POxORFt, int pAwMugdVlzpJNCKi, int NefoUlOTlPZMC);
    int IhigdNRerGzOgacl(bool BBJCwPP);
private:
    string fIARBVggGfwL;
    string jozHOTcRZrI;

    string fJTIBwU();
};

void XAwmWdqZNQoVJXnY::zPngR(int DAiBeOfxgUoNUcu, int ZFSuyDrwNGMuKu)
{
    int YjcZbPLzh = -1282799098;
    string tncwdUUxTW = string("SZiTowBxGvBVtnCgTbFRdQMZkRWcpGiCwZmBXIfERmTTWCQ");
    string RZuQgZ = string("LrlymDizxAItdeDYCl");

    if (DAiBeOfxgUoNUcu < -1772339080) {
        for (int feaDV = 166423064; feaDV > 0; feaDV--) {
            ZFSuyDrwNGMuKu -= YjcZbPLzh;
            ZFSuyDrwNGMuKu *= YjcZbPLzh;
            DAiBeOfxgUoNUcu *= ZFSuyDrwNGMuKu;
            DAiBeOfxgUoNUcu /= DAiBeOfxgUoNUcu;
            ZFSuyDrwNGMuKu = DAiBeOfxgUoNUcu;
            DAiBeOfxgUoNUcu -= ZFSuyDrwNGMuKu;
        }
    }

    for (int KmbvEwDhRrEJfcM = 289430704; KmbvEwDhRrEJfcM > 0; KmbvEwDhRrEJfcM--) {
        DAiBeOfxgUoNUcu -= YjcZbPLzh;
    }

    for (int UMGgFQrLLpDL = 33599101; UMGgFQrLLpDL > 0; UMGgFQrLLpDL--) {
        DAiBeOfxgUoNUcu *= ZFSuyDrwNGMuKu;
        DAiBeOfxgUoNUcu = ZFSuyDrwNGMuKu;
        RZuQgZ = RZuQgZ;
    }
}

string XAwmWdqZNQoVJXnY::JChAmkhBk(bool FyRoBAfLjOgDHX, int OdSxaDqgX, bool oczxjqKg, string OzOrGixuPVrNSd, bool FbpstaZz)
{
    int kzYnZWVWVwkwnea = 2025764846;
    string IAjTOuvkpNzukN = string("henHoODLOIrGbmwfNJAzVaVKXnIKEAQdEexVhgMOtZxiywCrxHOwAvSZoiULgjjLGvyzNb");
    double FFeQHXm = -639259.3454039693;
    double AJwOqEXezV = -837187.0047253028;
    bool xjOlkZllODuSVj = true;

    return IAjTOuvkpNzukN;
}

int XAwmWdqZNQoVJXnY::ouBtANbYoezKxQu(int zldSozmINDlDZB, string FQfHX, string amUHceQQMdFhDNSJ, int hlJZwVYOkZ, bool YLQdMySpatx)
{
    string wSuQZAtWInOHaRqf = string("yELRWYeJijtVftPtjvUEGAIYYODgyjYxKppSMmyLnaLalrWfXMPLWAJJhLxtwVRXYIDtrmpRUTKCqMyHgNzHQZnmYEsLUZhfWGLteZxgxrefNnIvRjRaJvXfjZmwIlCCrqOVCkbzlECpxSUiEIkleSDSEb");
    string TBXkVkpqK = string("IbAQAuieOQGJDMGdhRCfeYmIYEKrqPtIvgVywCMofTHGKmODIioQwHwCBrrmjGWJJCismxXxEXtLvnUqXplsRHsopZrRxVcpmEoQsZwtCmtasQHtWRYpmHexIpLRsKXTTezVvjpfPRGVmKSczZcCoaUvztmVsmaIfhnBhQwybXgUYp");
    double ErXMfY = 442042.5131966702;
    int EPKJICbX = -275657830;
    string uEfmXtzQkVgGJ = string("RPiNiDfdcBPJQqVoLPDbXBcYxaOdamIpUSmKDlXUzMQodtJhPwwigYPaeKUUNJRKHTjHBzJOWsKtkrJLioRNUFWVOStVEBGbwObWhsrfAIWaQJyXunReUkwsVVaYInKvYeEWylvgiarITGrFrzPMXh");
    bool MdLCUeOVkPVBflz = false;
    bool wQfmzI = true;

    return EPKJICbX;
}

int XAwmWdqZNQoVJXnY::OqcQboGcCe(string uCJoVbQTWiMOTlI, bool xXfbwZSX, string fmJGxvZHaqLDgfuz, int XcyyxEdhlWUhfhp)
{
    string MaqdUG = string("RlRStdRhCWktPMheQKjXRYvuSAvoLPWSH");
    int ACzboKBIaYhaxw = 1960587948;
    string PyKEILYiEyD = string("FdJAqtBTHhgNWTpyspSiANCQDIgafNYUzuXDdkNaTxmUArSmVldhbTacgsmdgLmabXwmVoBpxKQsGHtDAjuUAUofcKREpPWQKwPjWYINwydtxSnFDtNREmpMbjnSIdPclWNSUcrBwVhJqUBCOGJEP");
    int aSuTbcw = 428864769;

    if (fmJGxvZHaqLDgfuz == string("vxlZbnvEjaTsXigYpjWjfZJfzgCKwFkgPXWllbxVtTYuGqtAvuCv")) {
        for (int knDACsvEytwi = 1482110210; knDACsvEytwi > 0; knDACsvEytwi--) {
            fmJGxvZHaqLDgfuz = fmJGxvZHaqLDgfuz;
            PyKEILYiEyD = PyKEILYiEyD;
        }
    }

    if (fmJGxvZHaqLDgfuz > string("vxlZbnvEjaTsXigYpjWjfZJfzgCKwFkgPXWllbxVtTYuGqtAvuCv")) {
        for (int hdDGMplskeHiVLfO = 1805084611; hdDGMplskeHiVLfO > 0; hdDGMplskeHiVLfO--) {
            MaqdUG += fmJGxvZHaqLDgfuz;
            XcyyxEdhlWUhfhp -= XcyyxEdhlWUhfhp;
            PyKEILYiEyD += MaqdUG;
        }
    }

    for (int eFfJzE = 1905884781; eFfJzE > 0; eFfJzE--) {
        MaqdUG = PyKEILYiEyD;
        MaqdUG = uCJoVbQTWiMOTlI;
        aSuTbcw -= ACzboKBIaYhaxw;
    }

    for (int aRoVtEXv = 243825656; aRoVtEXv > 0; aRoVtEXv--) {
        fmJGxvZHaqLDgfuz = PyKEILYiEyD;
    }

    for (int RtkGMAyvD = 1805035016; RtkGMAyvD > 0; RtkGMAyvD--) {
        MaqdUG = fmJGxvZHaqLDgfuz;
        MaqdUG = MaqdUG;
        MaqdUG += PyKEILYiEyD;
        uCJoVbQTWiMOTlI += PyKEILYiEyD;
        ACzboKBIaYhaxw /= XcyyxEdhlWUhfhp;
    }

    for (int HecTRao = 349153269; HecTRao > 0; HecTRao--) {
        uCJoVbQTWiMOTlI += fmJGxvZHaqLDgfuz;
    }

    return aSuTbcw;
}

bool XAwmWdqZNQoVJXnY::SHVcBS(bool fCIRCjxEUaI, bool xPCLWDarbCfjWMc, bool AQdjnMai)
{
    bool mlToq = false;
    string RXFWq = string("lcWmMGLVqYYPUIJunDBqeXWypVaMfkXwFHGrEawVH");
    string iuNIXtgI = string("zFTDbixYbRaKpPyhtpmlLiffQsrAixiYFPiaUxujUnjsbiUOvcOuYzHrGaCCxATrsddhACVXROAuzafbPqJPbGkfsgDJMesSXEPAnmADRuU");
    int luHRT = -879532791;
    string nDzEMlELqtKz = string("SYHYufNNPBQEDNUchaXoyXNkHufbpvgeCGpaLbdW");

    for (int vUufvFxEvMiBXZuh = 1173716048; vUufvFxEvMiBXZuh > 0; vUufvFxEvMiBXZuh--) {
        mlToq = ! AQdjnMai;
        iuNIXtgI += nDzEMlELqtKz;
    }

    for (int dDkLPqWzuQIHgj = 49919981; dDkLPqWzuQIHgj > 0; dDkLPqWzuQIHgj--) {
        fCIRCjxEUaI = AQdjnMai;
        fCIRCjxEUaI = xPCLWDarbCfjWMc;
    }

    for (int BBNTjCXGQcqlu = 1932279920; BBNTjCXGQcqlu > 0; BBNTjCXGQcqlu--) {
        nDzEMlELqtKz = RXFWq;
    }

    if (mlToq != false) {
        for (int oFTIIU = 1273511170; oFTIIU > 0; oFTIIU--) {
            RXFWq += RXFWq;
            AQdjnMai = ! xPCLWDarbCfjWMc;
            fCIRCjxEUaI = ! fCIRCjxEUaI;
        }
    }

    for (int VuqmodR = 1118980505; VuqmodR > 0; VuqmodR--) {
        xPCLWDarbCfjWMc = ! xPCLWDarbCfjWMc;
    }

    return mlToq;
}

double XAwmWdqZNQoVJXnY::fKybeDmpsyXZnSrE(int POxORFt, int pAwMugdVlzpJNCKi, int NefoUlOTlPZMC)
{
    int wXxOZU = -1539133710;
    string auBokvvohLPD = string("hSghfpUCGKlxXIjjMHNsZiQloPiGNpMrvZmBTKPMuLmmKiNtrUZASVlfTreeOiYfWrUDjaQnGf");
    string NGJjmckDN = string("GUjkydNXukSBvAaMwQADzidChWTqFjpQGRUWnBfpJTmtxDdwlhHnZWRoqyVFdJldgDenkdATXFmamJtfZkhOvVZLiZsvcQVcUTTTNnHzNMCPVAKGhmoONwZNciZSO");
    double HUXbEreIUgHX = 785064.5412925716;
    double TfcnSoopZUMFOUz = 689961.6982950981;

    if (wXxOZU < -1539133710) {
        for (int XUHTYy = 1023811292; XUHTYy > 0; XUHTYy--) {
            NGJjmckDN += auBokvvohLPD;
            NefoUlOTlPZMC += pAwMugdVlzpJNCKi;
            wXxOZU /= wXxOZU;
            auBokvvohLPD = auBokvvohLPD;
            auBokvvohLPD = NGJjmckDN;
        }
    }

    if (POxORFt > -1539133710) {
        for (int IHzNDdL = 1727752462; IHzNDdL > 0; IHzNDdL--) {
            continue;
        }
    }

    if (auBokvvohLPD != string("hSghfpUCGKlxXIjjMHNsZiQloPiGNpMrvZmBTKPMuLmmKiNtrUZASVlfTreeOiYfWrUDjaQnGf")) {
        for (int buqmNNZPTJavJ = 685483348; buqmNNZPTJavJ > 0; buqmNNZPTJavJ--) {
            continue;
        }
    }

    for (int pmftzwCmkbE = 1808067235; pmftzwCmkbE > 0; pmftzwCmkbE--) {
        wXxOZU /= NefoUlOTlPZMC;
        wXxOZU += wXxOZU;
        POxORFt *= POxORFt;
        wXxOZU = pAwMugdVlzpJNCKi;
    }

    return TfcnSoopZUMFOUz;
}

int XAwmWdqZNQoVJXnY::IhigdNRerGzOgacl(bool BBJCwPP)
{
    string RHNfrggZ = string("zunkcrzDQlQXgIfVEauNZwhduyUmkKmQODpiTFYqSUCQstkDzWwzcSqnZjbyqHJECkZjnvCGOaQxXadBCrZEoDdykpsZoDdPgtLloKTrAJfaXvjJehOXEpwGOwitIjFAGuybgsdMzzNSKheLjLwiYaJfvjMTyVOKCMxyFsBETljnVimV");
    double fsLDI = 173104.8776794284;
    bool dZemPHDyUqrTkqOF = true;
    double WVTHJv = -219586.22071959462;
    double izqSL = -1031795.4922112935;
    bool ABDSuCTBEQUfz = true;
    bool bmfScdBtOEJZqUcL = true;
    string UHzTzAz = string("mBtTRZzKQekqwrAljymMfFsbXDnPaXiBMvSOpRxMVxiPJBwEClrtmaJrypjmccvgOhaqryVvKsdDjIeXnPgIfKoRCMjzveBSGfXbdpNtmuqgdxRvhleBEnLDAEfUiGXX");

    for (int LsVLapdb = 1385500555; LsVLapdb > 0; LsVLapdb--) {
        ABDSuCTBEQUfz = ! dZemPHDyUqrTkqOF;
        WVTHJv /= fsLDI;
        fsLDI += izqSL;
        BBJCwPP = ! BBJCwPP;
        BBJCwPP = ! bmfScdBtOEJZqUcL;
    }

    for (int JfhIrF = 317518066; JfhIrF > 0; JfhIrF--) {
        ABDSuCTBEQUfz = ! ABDSuCTBEQUfz;
    }

    for (int lMaDRIjEwMJz = 1220940974; lMaDRIjEwMJz > 0; lMaDRIjEwMJz--) {
        RHNfrggZ = RHNfrggZ;
        RHNfrggZ += UHzTzAz;
        bmfScdBtOEJZqUcL = bmfScdBtOEJZqUcL;
        bmfScdBtOEJZqUcL = BBJCwPP;
    }

    for (int sEZBE = 955254762; sEZBE > 0; sEZBE--) {
        continue;
    }

    return 1025487664;
}

string XAwmWdqZNQoVJXnY::fJTIBwU()
{
    bool YoKbKcsAzuYsxAO = false;
    int nQGDk = -1662226734;
    bool cTLnAfTgiVLtA = false;
    string ZThJecDfQYkEmAzT = string("ozThZwdugtEjfbPCNTkcQvgOhvUAIGWWRGIIETUTgkoOXaJgTAtYdFOgDGnVmoZKRDcgfPZXBERZgDiOMZCoHqeOVUYJeEfpqxqQtYTzHEHMbvsfYGbSjpmzpONiKWZwLBYaWVAlPYbRxu");
    string uVwPhHmioW = string("qpumAzHelYIPlmOTRmpoKuzTpLwibuRyKngxEqvfoxctJEdnjqrzRltGMcdAetfZsbpYcEqpLIXfTUFbqbMvhSIerkxpHrRaIeLfqQvIEVDVITIVgjhAHxTfGWiOmDcVkWKNedWjNCuFvNwlnGdQSpnejhPtLGIchcxoUYiuWbvXitLoDvuvRcUIbkTandSpKEMvSEzvkFle");
    double FDIbYGMt = -605489.0588288346;
    double NWPwLOJzpMDc = -219183.9714995612;
    double GtoPbrkwGaPNIDP = -97161.26117538262;

    for (int FfmGIHyNZVit = 1169530156; FfmGIHyNZVit > 0; FfmGIHyNZVit--) {
        continue;
    }

    for (int IjEnjfMPrUeDXWRZ = 37834835; IjEnjfMPrUeDXWRZ > 0; IjEnjfMPrUeDXWRZ--) {
        continue;
    }

    if (YoKbKcsAzuYsxAO == false) {
        for (int ioFIjC = 73794680; ioFIjC > 0; ioFIjC--) {
            GtoPbrkwGaPNIDP /= NWPwLOJzpMDc;
            ZThJecDfQYkEmAzT = ZThJecDfQYkEmAzT;
        }
    }

    for (int NvOcVDjIbVelgy = 1638530465; NvOcVDjIbVelgy > 0; NvOcVDjIbVelgy--) {
        GtoPbrkwGaPNIDP /= NWPwLOJzpMDc;
    }

    for (int ACrRYEkBdWkiMgB = 5571411; ACrRYEkBdWkiMgB > 0; ACrRYEkBdWkiMgB--) {
        cTLnAfTgiVLtA = ! YoKbKcsAzuYsxAO;
    }

    for (int nFMadxDslngjC = 1847021846; nFMadxDslngjC > 0; nFMadxDslngjC--) {
        ZThJecDfQYkEmAzT += ZThJecDfQYkEmAzT;
        GtoPbrkwGaPNIDP += NWPwLOJzpMDc;
    }

    return uVwPhHmioW;
}

XAwmWdqZNQoVJXnY::XAwmWdqZNQoVJXnY()
{
    this->zPngR(1532143733, -1772339080);
    this->JChAmkhBk(false, -2013349652, false, string("phLQZcUZEXMRiNPmnqqXAOfqnyYMCIYxaFVZaPHZrEJByejoqVAaOrgMttIkPpmuULwdSvwNimCSpDmcYyAbGQhbqKQJyqsrKcOnnvLSlNArHYMoeprSRwKXKyGrmhyiKfiSVXbmSnyuLARhHVcGhitoCMMSDuKFTwAGhupiZozYQzZbMBtFwzsQvLjdYHXrTGZoxvdNoGkDcTyDlXpPBXIvimaFYahImqQFqaFEIWYZRwGgXMT"), false);
    this->ouBtANbYoezKxQu(322466345, string("XBDznIiAkzijlrfPaXtiJjytrtKKeMIHdnyNalXATDVGZyVBHnjYrwOZMDJtz"), string("ovlbjBMWISfflIjLxTZiGjDqFUAitwQcWwQJWtiIczzvpvKjhLvMvqlbFAaMVfnRqAyweoqXVUVaPpTjAYwTzKCtzCxKzHjojBZaRtqZoSfyBjvudWVEqvArSYGxVyOvVNCxmgBnlpqcpgmVYyBEflnZcIzSDoddufqZLKBBVSbHLTplTReaEVGpIkxJqxzbtcGkFXuxjljtaEGT"), -1145072570, false);
    this->OqcQboGcCe(string("edbaefelNqthHPEsTGRInykBmboaxnVWSJeHAXPVgmqDHFuEjaYLPRXImgaZcIijehtPgSbHbdDTqebYcPnUEpuaHDkpEAQceavYiwhjdGINFTAekZRnKVaaiEmWdUkobPaokBDKCtaJkCaokmJwkMsCXGhRRADUrLyEUBVAAQYCOFxwrjiSkdeMKwzJkHuFWlIoYELvrR"), false, string("vxlZbnvEjaTsXigYpjWjfZJfzgCKwFkgPXWllbxVtTYuGqtAvuCv"), -46839720);
    this->SHVcBS(false, false, false);
    this->fKybeDmpsyXZnSrE(-1482100332, 1388661950, 443555756);
    this->IhigdNRerGzOgacl(true);
    this->fJTIBwU();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SfDoOR
{
public:
    double zeoWYzTvjrfjj;
    int wUnEKj;

    SfDoOR();
    bool itAUkj(double wbNCfQd, double WZFZKWzta, bool SmdOkmiUCzBRDX, double OeEMxXMiXyIhVf, int lKZWvQypBNhKGi);
    double GpQZvjnWbbsYp(int dOvClPyDoW, bool AEUsv, string uonmgfRywNTBp);
    string ZrjIBBG(double zormOvXOpmxc, int QeaXyEENjiC, double sokEhd, bool FcOGoIXQzfXXV);
    int XKostOCPRMLJwF(bool IzDaOK, int ZinXpGEzS, string MabuC, bool KuFxRBaWtctc);
    double DyNfZaqIpb();
    void hkzxbguYcew(double YOeusnzmkg, string bcKHvtupIVDrpfuN, double uLIulO);
    double cuVztBoXrek();
    void BcbbUKFtiUdDmHqH();
protected:
    double EyUlPIAnsNwEV;
    bool BYVNhiuBVDXK;
    bool NXVSirI;
    int wfPMBDiytVy;
    bool YoHVPRprBWShs;

    double JctSwbcqMCrgr(string kauARF, int irTfRQnfllIOMdZ, int VwfyBlFi, bool oewtLxcNiouXe, bool XztedKQPjuuKBEXF);
    bool jTTAfyExigULq(int cXgKYXmJos, bool hCbtflbEi, string gcsZbTRsJfzZYx, bool oJQIz);
    int mRNlhBhGkJsbUXc(double FmXuUq, int SmfzwqyH, double GUbyOm, double kfcGQcqNdphz, int VvrEHrqUED);
    int dbULhslAQE(int rCZRoFITGeuTb, string LGPnkMYjUwfDv, int EniOE, int tPJzH);
    double nBspsXkaCDohRyw(double wLtvHmdwOabEx, string FsQScURRq);
private:
    bool GWnAatbOsqz;
    int yZlwiJhdMWDmrULm;
    string shCTnGQtKym;
    int HNcMjkcyNPzJV;
    double RPlpIXCQPePHqbh;
    double TUCdOmk;

    void aIZeSGUG(string ruVWzxjOldn, double GqYgzIEoDCGuB);
    void smQuKlQFWJoe();
    bool LWkjDggUWH(double bnWcywKVcOfIb, string CiNSJgP);
    int OBEZGhIykx(int CPPZhWlOltwbuzey, bool hvWcfXleSSXQr);
};

bool SfDoOR::itAUkj(double wbNCfQd, double WZFZKWzta, bool SmdOkmiUCzBRDX, double OeEMxXMiXyIhVf, int lKZWvQypBNhKGi)
{
    int VoOpsODvV = 993310052;
    string DdkgISRJWOkKKdT = string("PfpcwMqsHSpRWmBhPDaNpFvHpfAaEAeAbJvkDMoSlBQGAIBijjFVbhQoTcLZYflXkuvWEhakrXvPNXCVDpFaVOhAhohnECqYtEoSDiowsDcYeVAmGdGmqYzOuUQdqiFAECyWAGjCyHurLGZQPKnbwLIztOCEBoIt");
    int GLkdwnsBOoYxe = -1374953379;
    bool UzvGKQgz = false;
    int VlgjGg = -333287053;
    double hQrSEnwGLEblwk = -972309.8809540806;
    string mkmQqjOaYwQEc = string("WRFKOelGkjnQTDtUepyUplEiMEBNxkFeAVRAVmLhploaUFZRqlsYohfdMfittDOYHgfQoNLBzYTMIfmNSYo");
    string nYZsj = string("LhZLzHKFAqcWzYSeoRCbxdnSYIYlCNxaehAsxgAOlVLrqdwTcwoGrguGPdMDBtpTXZAwbqeJAsffGWBASboxwDMrCIifYDqipfZCvVWXlmgaotkzZuOlmSrtkDCIlExi");
    int BHWseH = 1522920641;

    for (int KzSQZ = 1055430480; KzSQZ > 0; KzSQZ--) {
        continue;
    }

    if (wbNCfQd != 193678.46456240118) {
        for (int FZgGJA = 2020439771; FZgGJA > 0; FZgGJA--) {
            VoOpsODvV = VoOpsODvV;
            wbNCfQd -= OeEMxXMiXyIhVf;
        }
    }

    for (int ITonYwvPwsV = 1940543379; ITonYwvPwsV > 0; ITonYwvPwsV--) {
        OeEMxXMiXyIhVf = hQrSEnwGLEblwk;
        wbNCfQd += hQrSEnwGLEblwk;
        GLkdwnsBOoYxe *= VoOpsODvV;
    }

    if (VoOpsODvV < -333287053) {
        for (int LmEtUNVxAgfj = 1393264746; LmEtUNVxAgfj > 0; LmEtUNVxAgfj--) {
            GLkdwnsBOoYxe *= VlgjGg;
        }
    }

    return UzvGKQgz;
}

double SfDoOR::GpQZvjnWbbsYp(int dOvClPyDoW, bool AEUsv, string uonmgfRywNTBp)
{
    int UOvWjJuAfoym = 1495924745;
    bool TdWLvpobHZMpIq = false;
    string ScZJpzISkiKJcO = string("ZfuIGpgchOtfaxXMRfUOtzgZjGLMLuXPUAUVaUmmFABUyRCvxUVmFFtckhMwOVXZLWzmmJgDKGrxXwtSERNfTbsbGabdXBqXKMCAceyHOShxrumdPW");
    double UGYVhvPq = 588107.2421929556;
    double WOFkEsWDvlr = 632021.6997912145;
    int FjAcRvxD = -196355720;
    string saPYWKkdotdv = string("ZMkKOzwYMgieiRLBAKWiocoexbYtWpZWZYpekfEUjGFnkKNMaaCAVtZFudFriKAxVHNkZBMTQuEgRYIhOwBDxscQsGKODX");
    string fxAMnaEOYmFW = string("NSFCdCvXpGvJRNJdoymMbswJWjbqCFtuoXrmaUflSbGtKAaNuZrxHKppUBUuPSHfYEMzyBMRkguhCiWKhzePyvfQyKvtWAGclIHQAnnrCLOGlknWLrwaYXXShNYfVHOwNFKcWjiWONwOaKQQwExqcfTTiwzxlWhJHGQfQqdOdJKAByjyXJsTQNtuCIDKTKdUJqUoUnxEOKVZNitNxhGumOJXIqmFHpRHZCizgEEHhIcQMeZuBAldlEzBwX");
    int uEKsLyMcswsQFE = -746971076;
    double zqVtlKCgkKE = -586247.2390344093;

    for (int vAPfzCAySPj = 1590424542; vAPfzCAySPj > 0; vAPfzCAySPj--) {
        continue;
    }

    return zqVtlKCgkKE;
}

string SfDoOR::ZrjIBBG(double zormOvXOpmxc, int QeaXyEENjiC, double sokEhd, bool FcOGoIXQzfXXV)
{
    int FrHCp = -176288673;
    int GUCemMOnkktyjNcM = -1902362988;
    string pLGLFFdLeEgcGl = string("BbZLedqkwPHhTdYCivUQUTLgclFyiWkiUUUXtrzppVzjxqYhIRvKqYWzoMAEaPoRrBAGEHAkdaVHnvmvmHUAaVRIdY");

    if (QeaXyEENjiC >= 930479125) {
        for (int DfEoalLgTjpil = 1324143045; DfEoalLgTjpil > 0; DfEoalLgTjpil--) {
            GUCemMOnkktyjNcM *= FrHCp;
            QeaXyEENjiC /= GUCemMOnkktyjNcM;
        }
    }

    for (int YdqgOVbajmmx = 235617932; YdqgOVbajmmx > 0; YdqgOVbajmmx--) {
        pLGLFFdLeEgcGl += pLGLFFdLeEgcGl;
        FrHCp *= QeaXyEENjiC;
        QeaXyEENjiC = FrHCp;
        zormOvXOpmxc *= sokEhd;
        sokEhd = sokEhd;
    }

    for (int dkCecjoxIgfHer = 1720297287; dkCecjoxIgfHer > 0; dkCecjoxIgfHer--) {
        continue;
    }

    for (int jptRIL = 1056763478; jptRIL > 0; jptRIL--) {
        continue;
    }

    return pLGLFFdLeEgcGl;
}

int SfDoOR::XKostOCPRMLJwF(bool IzDaOK, int ZinXpGEzS, string MabuC, bool KuFxRBaWtctc)
{
    string RRNiBgkrppDms = string("JRHKhBTeDwHVpsVTSVlwSEjDSesGQg");
    int zlsIwRTnZNsYW = -2052912029;
    int kYSADTjmTwzKt = -351926368;
    int XcIEVmdu = 1541947178;
    double GpEejju = 739772.6437541383;
    bool hfThzKZHzIgLyvyI = false;
    double eLkGpyxJC = -62080.886712414234;
    double ujHbJsrvGN = -153514.92049299885;
    bool uVfDhbPNRcwgZFEw = true;

    if (MabuC > string("JRHKhBTeDwHVpsVTSVlwSEjDSesGQg")) {
        for (int vVvDvHCj = 1594163272; vVvDvHCj > 0; vVvDvHCj--) {
            ujHbJsrvGN *= eLkGpyxJC;
        }
    }

    for (int MYQuQgChIMVnqPxg = 240331826; MYQuQgChIMVnqPxg > 0; MYQuQgChIMVnqPxg--) {
        zlsIwRTnZNsYW *= kYSADTjmTwzKt;
        KuFxRBaWtctc = KuFxRBaWtctc;
    }

    for (int PdWGDTvv = 1809953219; PdWGDTvv > 0; PdWGDTvv--) {
        IzDaOK = hfThzKZHzIgLyvyI;
        kYSADTjmTwzKt -= ZinXpGEzS;
    }

    for (int AOSkekGKAac = 201667998; AOSkekGKAac > 0; AOSkekGKAac--) {
        uVfDhbPNRcwgZFEw = IzDaOK;
    }

    if (eLkGpyxJC == -153514.92049299885) {
        for (int PeghEt = 760536925; PeghEt > 0; PeghEt--) {
            zlsIwRTnZNsYW *= ZinXpGEzS;
        }
    }

    return XcIEVmdu;
}

double SfDoOR::DyNfZaqIpb()
{
    string XCfZBVN = string("DUdGfXlFPezJNajolXNaZFqLtProzZNAHPspdvxfPGwaIwFqEzyJUzeDRRJCGzznapDKJHvRAENfZJTVQvetTMxvJmNxDWknQvLJKKavAsHQvRWMAQfvWYuYVIcdeIKgQGIlSRzOrXCUpGikpEyQkrRhWHkzsZwdrrrvJSxsjdmreMMxantkODPlxSxfvDCgYNDvXcugTeCsuNThjuwpYsmbHLaKpmoCfgDCOUbley");
    int bgmOoRmiBe = -1536859747;
    int kcOvcEPyzx = 247713222;
    bool mDeXkx = false;
    bool MHaFZnu = true;
    int mOCWFmjiyB = 1982024734;

    if (bgmOoRmiBe > 1982024734) {
        for (int BFfdFGyfTuculHlT = 379995064; BFfdFGyfTuculHlT > 0; BFfdFGyfTuculHlT--) {
            mDeXkx = MHaFZnu;
            bgmOoRmiBe += bgmOoRmiBe;
            kcOvcEPyzx -= kcOvcEPyzx;
        }
    }

    return -1042004.1338472678;
}

void SfDoOR::hkzxbguYcew(double YOeusnzmkg, string bcKHvtupIVDrpfuN, double uLIulO)
{
    double GmJKbTyRDknj = -968932.7885526174;
    double xgyPVsxVNvcpHaes = -791713.6190864544;

    for (int CGgZVy = 731874046; CGgZVy > 0; CGgZVy--) {
        xgyPVsxVNvcpHaes /= YOeusnzmkg;
        xgyPVsxVNvcpHaes = xgyPVsxVNvcpHaes;
        uLIulO *= xgyPVsxVNvcpHaes;
    }

    if (GmJKbTyRDknj != -201661.78950316724) {
        for (int kdbrlChQenSADpbw = 2023929632; kdbrlChQenSADpbw > 0; kdbrlChQenSADpbw--) {
            continue;
        }
    }

    for (int jviXhqQi = 461388967; jviXhqQi > 0; jviXhqQi--) {
        GmJKbTyRDknj -= YOeusnzmkg;
    }

    if (YOeusnzmkg >= -201661.78950316724) {
        for (int lOcMhIQrvLIiAT = 547939463; lOcMhIQrvLIiAT > 0; lOcMhIQrvLIiAT--) {
            YOeusnzmkg = GmJKbTyRDknj;
            uLIulO *= YOeusnzmkg;
            GmJKbTyRDknj += uLIulO;
            xgyPVsxVNvcpHaes += GmJKbTyRDknj;
            xgyPVsxVNvcpHaes *= YOeusnzmkg;
            YOeusnzmkg -= uLIulO;
        }
    }
}

double SfDoOR::cuVztBoXrek()
{
    double SegSue = -724647.8195811008;
    bool fsyravr = true;
    bool cdiff = true;
    bool gacFoLgbEkRAy = true;
    bool sVXvvuEuh = false;
    double BTgNoJwDHy = 318060.07402084355;
    string xMqwjrgKFeiOhwTX = string("dFbWkinJqsQaUoJBnQJGVEwYLShsCktfgxGqhGIZZPfgOTaujiJDHgTdwjdfRahmzuLBKCsIaEnXBbIRcBzCwOiONEjUVojTgTlXNBITDbRKEIIphYqFHXTDSWFOgVwdguKFLZTPGOGZraLYsbukdAYqVdajNcjRjNoUhLbXrKKuHPoGEctunQBPMJxymkfcArEplNKZJbzPAXxTAN");
    int bHXQTZLdOqtrDkh = -540519679;

    for (int oQarPQoeCWsuutCv = 1327651057; oQarPQoeCWsuutCv > 0; oQarPQoeCWsuutCv--) {
        gacFoLgbEkRAy = cdiff;
        fsyravr = fsyravr;
        cdiff = fsyravr;
        BTgNoJwDHy -= BTgNoJwDHy;
    }

    for (int Hdoknz = 1142911544; Hdoknz > 0; Hdoknz--) {
        sVXvvuEuh = ! cdiff;
    }

    return BTgNoJwDHy;
}

void SfDoOR::BcbbUKFtiUdDmHqH()
{
    int EsDqLKfkBPtXQ = 1937218591;
    string cSmoj = string("jUKIXtJDNxbEXRHSWFBvwJYmVTOMuUlHjNraeKccYtGxIxdklLiXtJqycDHSQdpwNBWgNumQMdjgugSYsuaFuwZJVHRtdFLoSXNnjThphQjFvmGBuMNamHatUZVcNHtsxzgZgiGNuFGlTvh");
    string mZwkqdQdTkO = string("EYCmNQDfAkmrDjAaoKwWXMBjhPxJwAFuVlCkQtSSupiLzNGdKkNjPyinFiPCCJfjexCKIQyTxYUNnVqMUDgnWwjewbXOqNltSpZYoUhEfMrmxLCmuDvzrMnlnJeTjMVELjWWJAoTHXHcixZecLHspAFZVreYeYTwkEzYCrdYuibeYpHnIbeOIuaUZTavxlHtPyRkRCQnwPLIAYtwKQNBPcoCNeOlUftuSWlAaGDPUz");
    bool yEqBk = true;
    double epMrCKTtUmgKyk = -390709.3493264134;
    int cQDUmvcIryrNiF = -994399112;
    double dSvDeNKmAVhE = 145718.10800695195;
    bool LtlwLyJqgLp = false;
    int oMWkgU = -99196389;

    for (int FLGGPSFftn = 1027559001; FLGGPSFftn > 0; FLGGPSFftn--) {
        continue;
    }
}

double SfDoOR::JctSwbcqMCrgr(string kauARF, int irTfRQnfllIOMdZ, int VwfyBlFi, bool oewtLxcNiouXe, bool XztedKQPjuuKBEXF)
{
    double zALGJMheRi = -532925.8729521035;
    bool MWZTKLHilyUXbR = true;
    string WTlDJkAakTg = string("lYnvlIRyPBwHJfMlpVLCwBVTzgTuyRBpZtyjKrZOQsGULZQAkZjFFmrQX");
    double iawYCtpzkWe = 682235.2435300029;
    string FRutaqCw = string("LVfMlxNDGtQkeJNayMHBGZqCyktExekRHMjqXXZQxXzHVeCfEsUfcTxMLMmnatxjVHzTUoGhUdLBlgpKYNVjSiwAMAkYSDNBzNlaDlrCbKphSTxdLKAKSJnawmSSVdOxiaDfELXzOABAJExUgLKYqnRPiJgprTCejkLjHLVQeqlRPhmxRESpMPIwTdIyGEqeroKtZnNOSIIcPxquC");
    bool PaPfmdQYSU = true;
    int CPQdhzLtRoOFLCMg = 1427315292;
    string KtvbQRCnzU = string("bGiWdLBJFxDJSndpINPjxTDtvgWNTxaSzZtkzorwhThFPykPyzKeGENntDiazVrGenVdRzzgrbEWSSOLCUiDEhviYTvewIglRLFReqdaqclqKZzazDVbPoXoqCJmUItkwoVUdhQyZjSlzIvGGzXroiPwzJPmHDKkKAhYOZXslkPIERruKMsNlbSfdACALNtFXnxXNWltzMEDlcTnMKPrSBrSeODXzEzlijOSKrCu");
    int LGRVykQx = -1460814071;

    if (KtvbQRCnzU < string("lYnvlIRyPBwHJfMlpVLCwBVTzgTuyRBpZtyjKrZOQsGULZQAkZjFFmrQX")) {
        for (int wfTbeGGtsFXayw = 466750734; wfTbeGGtsFXayw > 0; wfTbeGGtsFXayw--) {
            XztedKQPjuuKBEXF = oewtLxcNiouXe;
            oewtLxcNiouXe = ! oewtLxcNiouXe;
        }
    }

    for (int obbEdMlZPnrtPBSV = 1484363145; obbEdMlZPnrtPBSV > 0; obbEdMlZPnrtPBSV--) {
        continue;
    }

    return iawYCtpzkWe;
}

bool SfDoOR::jTTAfyExigULq(int cXgKYXmJos, bool hCbtflbEi, string gcsZbTRsJfzZYx, bool oJQIz)
{
    bool ROGIaCYOmF = true;
    int zMwhDXfPhjYdGps = -1400974047;
    string gEsWQEnFUz = string("OWYtwQrPVNSInKPRMfDPwRHxA");
    string AqmxMYpzEPDf = string("b");
    string nfZnaSxPVREYMUK = string("AaAHPzAohEVRHpROwyTsHmJvuuQVsZtHouxqwbLqATWoKARXTBUInHnikesSOyCOFzBfXVvlPMojVgZKTVLGSPVJaLRTCnxwWdlNZiMFksyWlIGmrzQunWtRWgQ");
    int Clrogez = 898688919;
    bool IuCXmXNOFEoDrCF = false;

    if (gEsWQEnFUz <= string("AaAHPzAohEVRHpROwyTsHmJvuuQVsZtHouxqwbLqATWoKARXTBUInHnikesSOyCOFzBfXVvlPMojVgZKTVLGSPVJaLRTCnxwWdlNZiMFksyWlIGmrzQunWtRWgQ")) {
        for (int hZPVKhnMGLU = 1607053137; hZPVKhnMGLU > 0; hZPVKhnMGLU--) {
            continue;
        }
    }

    for (int zwNGHQNstjtN = 783577595; zwNGHQNstjtN > 0; zwNGHQNstjtN--) {
        nfZnaSxPVREYMUK = AqmxMYpzEPDf;
        Clrogez /= cXgKYXmJos;
    }

    for (int Sttcnr = 1159662866; Sttcnr > 0; Sttcnr--) {
        gEsWQEnFUz += gcsZbTRsJfzZYx;
        IuCXmXNOFEoDrCF = ! ROGIaCYOmF;
        hCbtflbEi = ! oJQIz;
        ROGIaCYOmF = IuCXmXNOFEoDrCF;
    }

    return IuCXmXNOFEoDrCF;
}

int SfDoOR::mRNlhBhGkJsbUXc(double FmXuUq, int SmfzwqyH, double GUbyOm, double kfcGQcqNdphz, int VvrEHrqUED)
{
    bool OGNxolYWhgcyMyjg = true;
    bool yAYFWaObJSARow = true;
    double CggBUiluzDvlXV = -1023821.8103763296;
    string CWXVXuGImUjfNH = string("YVBMsGkYacBAAsiIUqOxddTxGqiqGuAKrGMKKyiyEuVZXATxKPNZkqrZFMurbEQAEsUpGJcZoiNEfQdpIPoehmHSHUmFQSgRPhVeWrhOOWahyPUASDUrJikczwDwQUnxirLYAwIkxUPkYalzbgGueLjhCEbYvcXmiRotWtBUuKKZlfPVDklGFnbJJQPdECtxwsfKBykwCxojgXIqziHQFriaWOnvVfzkRoZlwwsXieep");

    for (int zbfQU = 1407276601; zbfQU > 0; zbfQU--) {
        OGNxolYWhgcyMyjg = ! yAYFWaObJSARow;
        SmfzwqyH /= SmfzwqyH;
    }

    for (int BRDotnbgXlUkPF = 2034961012; BRDotnbgXlUkPF > 0; BRDotnbgXlUkPF--) {
        kfcGQcqNdphz -= CggBUiluzDvlXV;
        FmXuUq -= FmXuUq;
        FmXuUq += FmXuUq;
    }

    for (int RIzDOhYO = 375382026; RIzDOhYO > 0; RIzDOhYO--) {
        CWXVXuGImUjfNH += CWXVXuGImUjfNH;
        kfcGQcqNdphz = GUbyOm;
        SmfzwqyH += SmfzwqyH;
        yAYFWaObJSARow = ! OGNxolYWhgcyMyjg;
    }

    for (int ZVMSbefYHo = 1283989870; ZVMSbefYHo > 0; ZVMSbefYHo--) {
        VvrEHrqUED -= VvrEHrqUED;
        yAYFWaObJSARow = OGNxolYWhgcyMyjg;
        FmXuUq *= CggBUiluzDvlXV;
        kfcGQcqNdphz += GUbyOm;
    }

    return VvrEHrqUED;
}

int SfDoOR::dbULhslAQE(int rCZRoFITGeuTb, string LGPnkMYjUwfDv, int EniOE, int tPJzH)
{
    bool SsQFxJtUs = false;
    int MnfftlQvsdG = 1196214213;
    string atDabbeffVsZmT = string("UuEhJcPIFbpODVHtBiVvyVWrjyHFYCtLrQSauWqtHtgupItZzyoXaKELrGPkCVzzGPWBPCvZnsLimlmlnVgSwfTnteKOHUjxaqG");
    string SSZqViPRbVwqEU = string("ssaWBmXeYlHSJOJF");
    int tMDYXDiWONAkL = -828071521;
    double pbcFRWNqOinuEDiu = 76205.32546963164;
    int YXBYsDlrd = 454081651;

    for (int oHXOvBjtz = 40887676; oHXOvBjtz > 0; oHXOvBjtz--) {
        EniOE *= EniOE;
        tPJzH *= rCZRoFITGeuTb;
        atDabbeffVsZmT += atDabbeffVsZmT;
        SSZqViPRbVwqEU = LGPnkMYjUwfDv;
    }

    return YXBYsDlrd;
}

double SfDoOR::nBspsXkaCDohRyw(double wLtvHmdwOabEx, string FsQScURRq)
{
    double UyVIxPuSB = 1003039.0381953106;
    int YhrTJ = -436635839;
    string KtSlMndXkKkaUFY = string("lvIDscFTubMzj");
    bool IlIwRXRBR = false;

    for (int HcOIw = 1520420727; HcOIw > 0; HcOIw--) {
        UyVIxPuSB -= wLtvHmdwOabEx;
        YhrTJ -= YhrTJ;
    }

    return UyVIxPuSB;
}

void SfDoOR::aIZeSGUG(string ruVWzxjOldn, double GqYgzIEoDCGuB)
{
    string PgLckZeGExPgwhvO = string("RYgQJBUVxUjqhsvzSusSk");
    bool BlzuuqLwkkC = false;
    int aLnfGuXN = 1588844333;
    double jwxcUEuBUgrMqXz = -555414.4648419528;
    double dteFKEyMZiS = -810384.1447425704;
    string JXRlVus = string("JZdxZYUmAPkzbeIzSChlouafTOobaorAUiVzqHUYPJaPJSdTJZNEmrQzEzzSzorKTjvRlbYnnRIIUzTljLDXWVtPGHrSZpVyDhajdLXtElDPUFSDYSRbdANReVwlKdMWOScholvzVlRPVOFghGnrmpVLaDcuUcMinasHkwddCFQQYShFxuRnpmdyeQbuyvxdiGEowLrMFXAPLPecRNleAVAolhByLztQZYvCcURLshvzOW");
    string aCaoqKDaiP = string("GQiIERthRwtGbiETaPnBChldScJgTLhajDwuoedfBRbKdNCYdOTlqjcLQwO");
    int sRmRUnlNay = 238723264;
    string vnYAIDOyWypFlimC = string("OVNsKclMsPonuWdAxtdZemJqmaQukCiXGnuvMCramWChzpjZufOTbcLWNNnYJLEOLBDoElzbjmsiCQudJnQwqnacxREmRoKjtnPywHH");

    if (jwxcUEuBUgrMqXz < -810384.1447425704) {
        for (int IWaDtpEoVidvSbCN = 1722555837; IWaDtpEoVidvSbCN > 0; IWaDtpEoVidvSbCN--) {
            ruVWzxjOldn += JXRlVus;
            PgLckZeGExPgwhvO = PgLckZeGExPgwhvO;
        }
    }

    for (int CXbKcEcZtAYip = 433158353; CXbKcEcZtAYip > 0; CXbKcEcZtAYip--) {
        continue;
    }
}

void SfDoOR::smQuKlQFWJoe()
{
    int RcowoGEov = -136676904;
    string nterpFQ = string("IErxTVZhSlAGIgfdLcviypZcOZkYSklyvxtVoL");
    string FwBHaW = string("eITleDfZNYkgZvTvJZvgrOLOzeKkCsXOATNiTcBHjUcHuokQWlBqIWMTgUf");
    double MstlEOpvbr = -600443.4099739647;
    string AQGYoWpBSxDF = string("DqtljWSDXPhfcSSXmuDRrGDhDMhGRoyoQdMMwFXfKwJ");
    int VzWztZk = -1416748670;

    for (int oaIvpz = 1480776726; oaIvpz > 0; oaIvpz--) {
        nterpFQ = AQGYoWpBSxDF;
        VzWztZk -= RcowoGEov;
        RcowoGEov -= RcowoGEov;
        AQGYoWpBSxDF += FwBHaW;
    }
}

bool SfDoOR::LWkjDggUWH(double bnWcywKVcOfIb, string CiNSJgP)
{
    int xtknWurgGruPlkL = -1241402840;
    double WsAKpDeSQo = 26734.267885326346;
    int VAdAU = 1377781794;
    bool ZFsYshRAMbVb = true;

    for (int xCESkXEL = 1361952589; xCESkXEL > 0; xCESkXEL--) {
        bnWcywKVcOfIb = bnWcywKVcOfIb;
        bnWcywKVcOfIb -= WsAKpDeSQo;
        VAdAU *= xtknWurgGruPlkL;
        xtknWurgGruPlkL += xtknWurgGruPlkL;
    }

    if (xtknWurgGruPlkL == -1241402840) {
        for (int xKuMNG = 1932688559; xKuMNG > 0; xKuMNG--) {
            WsAKpDeSQo *= bnWcywKVcOfIb;
            VAdAU += xtknWurgGruPlkL;
        }
    }

    if (WsAKpDeSQo > -747593.1558949379) {
        for (int ekRutUXeOU = 1223020240; ekRutUXeOU > 0; ekRutUXeOU--) {
            bnWcywKVcOfIb *= bnWcywKVcOfIb;
        }
    }

    for (int ZpRSun = 1042911276; ZpRSun > 0; ZpRSun--) {
        CiNSJgP += CiNSJgP;
        bnWcywKVcOfIb /= bnWcywKVcOfIb;
    }

    return ZFsYshRAMbVb;
}

int SfDoOR::OBEZGhIykx(int CPPZhWlOltwbuzey, bool hvWcfXleSSXQr)
{
    double QFbXp = 873790.6949668495;
    string eIgCIyLJGVujMIHJ = string("iukZLSbHxbziFAWogNFrvWQTbEoTNaVpHfnhumSbYVeNGhZoWBbGIKFiPFUzBVzbAzSIMWCmjBnknFskBQpOhkenVGzDwAyWIXjfxAATBtSazyCPhvwIRZrIoQxrzVaTLPzxcDFOotEgvVeGQAFNDDctiLnTuUmkXgHoRYNTxvYwqfnbMJl");
    double nEhNdwHlCjxvzuGM = -509970.5319813339;
    double GvVseXPoEtWJNBg = -26721.866989118644;
    bool LmjBJ = false;
    bool pveBtkCkZlukpxj = false;
    double pCeRioAtxV = 1005848.4185857207;
    string tPBVY = string("wRaDxaZG");
    int AfwtyvQ = 1621508107;
    bool CITmyhXSMeNlAEI = false;

    for (int EECxRYJmK = 1033145024; EECxRYJmK > 0; EECxRYJmK--) {
        hvWcfXleSSXQr = pveBtkCkZlukpxj;
    }

    for (int KKoCtvlog = 1211893197; KKoCtvlog > 0; KKoCtvlog--) {
        QFbXp = QFbXp;
        nEhNdwHlCjxvzuGM += nEhNdwHlCjxvzuGM;
        LmjBJ = ! hvWcfXleSSXQr;
        QFbXp = pCeRioAtxV;
        GvVseXPoEtWJNBg -= pCeRioAtxV;
        nEhNdwHlCjxvzuGM = nEhNdwHlCjxvzuGM;
    }

    return AfwtyvQ;
}

SfDoOR::SfDoOR()
{
    this->itAUkj(21614.19950984035, 193678.46456240118, false, 336714.83801204246, 693203173);
    this->GpQZvjnWbbsYp(-971771820, true, string("aANbpbKsgKcAfDHKVJIOBPabXYlvmGAtUFTyHckYneMqXNVigiwlyCKqQHfdzNlJzGvvWvEIaTbOJdCCtKEDOtogDmnQTgiNArZJKaiVefecuuxbBFxmBGTVzKKBsBrnqwKFGlfQmsdwgDZweMnyVFYcmrgnwYUVLxGXXMFHglveQnKmbOXAAJKauxDvtJiqQtQNPRZuGIyuUrbpTXgpHpfzpklHaqEJxWJkEFkFkPIwZxWpgHrC"));
    this->ZrjIBBG(-479510.1846792395, 930479125, 482791.46512470866, false);
    this->XKostOCPRMLJwF(false, -1448594560, string("qFOseKwgdUTDKUxyvOwQtDOLbQzTGVdtCvWkOktTCpHhhZMOkpPMDgLjDkXPDyYkcHKliClfjsbUBrHQKTrmnvQzvhhUBHxkMbnZPdLEECXuoDyeHbcsdsCcSdyfPGhsMLZRDDGyWSDGzCfYCLTzqZUNwvUfwdZbgHeYE"), true);
    this->DyNfZaqIpb();
    this->hkzxbguYcew(354345.5930122727, string("OlXNuiWkQKhNzVTvOesYzyWOjIDvDlqtLPAmTbjHljYSojJLzrXEpZzHZFWrhPvKOyzNFtQWuozvJVwsbjGyZePgfcjglNGXFfrleRJCiQqPaIpnCYriPqslLUiaRhnlQftUrGaEdooRAJAlldOrcmKyrsztmWtjuSGeFmFjxOwCQoETIrxghScmEBkmvqHkSZEmMU"), -201661.78950316724);
    this->cuVztBoXrek();
    this->BcbbUKFtiUdDmHqH();
    this->JctSwbcqMCrgr(string("UbtrSOrgpJHwBGUoXjbJhCZLuVIxvFvuiLEEmiXJUwNXpFRKxfLEwUSEPZgUkJwXDDiYuvxFGYjIxmMJfehSHOoKSjcVLn"), 427048858, 499382834, true, true);
    this->jTTAfyExigULq(724338842, true, string("eEhtWGnVfDlTPSGBQkzpYUhfmZjCalmvIatPNZJtMmPTgKWLNArakDErXMElUxUHeKsFQzOggxlNbWbQXAZMuGuiygjICpIGYSpQqVwwGEpLEAgknCBKFIHMuwjGhfYKoTGECsbdCiRSRwGCtXuAkYpBqHxUXQHwgVENxzvbQmk"), true);
    this->mRNlhBhGkJsbUXc(153723.93846920942, -1397850, 682361.7168016838, -600619.8054462352, -1011408363);
    this->dbULhslAQE(-92415946, string("gIAqZSwevzzsQZhhoCrIooKkldGRzZyUFjgXkMFlAbXzLiGEMvJAuBAkPzblQrvKfaPabaSfr"), -341985833, 1576544204);
    this->nBspsXkaCDohRyw(44258.64034530608, string("iNkGAJvvPGtsJizQSneKChALsIJzVSQtUHUbXiFFAkYDRcplCUlaawESMgzSKWSaSBRGcliLqEPVbhYKXKYWaCHtuytVNiBhpBcktgrsADadhaLbdmQMHmhhpvIAWWDKsLhzhDflHbKeRAuAeKHXcMRreUUiUUADHnQutXLQDQPOKDZdnRviDPNRHNPppAbMWyhKTzOvpTxHpCyQeDTKkgXTmzxZxWYWSFnEhvcmqSZQz"));
    this->aIZeSGUG(string("mhHcvkbqNGCrSNAlRLXzuZUNkGkGGCNrDvcKExtgOYFafHOjkScfOStCNSCtcKMxKuEszlFFwz"), 576233.0856912986);
    this->smQuKlQFWJoe();
    this->LWkjDggUWH(-747593.1558949379, string("zReHtDsELWTOefWaKyFClFDgcvPbSHvmHgbeCvzCVjMjASZWilRVdEcIMSRnjMWtryZbkgKyNHSkXkfJIRJjCoIUfqByEUgxgrJHMcOhSgpIBsKZyIvTYoyNXxjBwFqcMYfJBtytDUpXiAXAAgKABulzTVuSeVlKmhzmhewUVxSLxxwykCZZwsMvPhNEddNHTnrD"));
    this->OBEZGhIykx(215771799, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jySYpugnRFEtnm
{
public:
    int vUiwpTyFiHTDyNi;
    bool XYPZgD;
    bool WzkeFwzi;

    jySYpugnRFEtnm();
    int awsFuWgzj();
    bool BacLxrOGNJTOiefx(string UYblaLiTYk, double FOfsgvv, int GNode);
    bool ExdBjNlE(string apMmA, int oehBnKEUeFvq);
protected:
    int LQZBTdWvEgiMKsJ;
    double MQDXQUkBEjHJwmEs;
    string WlpdZiUyCenP;
    int tJywMXAwyTJ;

    bool xFkYhsga(string fswwyOPLZL);
private:
    bool kAsaIUtfey;
    double HSnIjdJWQWHQHC;

    double WKREmACwKfqnNrtO(double IsyEvQ);
    bool fCjIppWyGtEW();
    string TkujPIZjN(string KfJhWhZeeoisrNM, bool IlzWMNPcMMHTLkWU, int xorJXJhQoKMumenO);
    double MfvDMKk();
    void FabImwqhzIXwg(int oJvvoczouv, bool URhxcyHXz);
};

int jySYpugnRFEtnm::awsFuWgzj()
{
    int fvFQcoPfZw = -1227976124;
    string PROzlKUlbf = string("zyJyrYVprXbQrzCBuAHNTHfSuyLXfOIRRRHEQiqMspmJvpklUMTcYoFAWGXKHiqVvQHAizodRBsbpjqoazCyedaFoilGWFFdVSAYarsuLibXiYeNRWgWbty");
    string bnzzwTLkAwGtp = string("FxlOpQkHwwWAgEzPxQSDNmBWXvLGjdkbSmnnzYLlLeHHogqFEVkeGaGpyfroVqjXtWgHFclKWCVzDDrtPEmrYLTNLnvVVewkdWPMWFdWRSUWbpHdCxeLBAhmNQqTAlHaUVgEoXOsIvezBJUhvfSPHbvdSAMtUjpnDeHNMIkrqHiUZXhdsqwmbDQKpJvexZUdIpiFgBbrwBNcgKGJCnIYKUrcYwAOMckXHDnKuVfMoIKbf");
    double nApuXGvVTRIoIB = 325194.24067095213;
    bool HErGszVfqSSuElYO = true;

    for (int UyVUapbbtPqgIHz = 1680646125; UyVUapbbtPqgIHz > 0; UyVUapbbtPqgIHz--) {
        nApuXGvVTRIoIB += nApuXGvVTRIoIB;
    }

    if (HErGszVfqSSuElYO != true) {
        for (int DGQnvUpw = 1651598031; DGQnvUpw > 0; DGQnvUpw--) {
            bnzzwTLkAwGtp += PROzlKUlbf;
            bnzzwTLkAwGtp += PROzlKUlbf;
            bnzzwTLkAwGtp += PROzlKUlbf;
        }
    }

    for (int ErHfxxZzCt = 1774226726; ErHfxxZzCt > 0; ErHfxxZzCt--) {
        continue;
    }

    for (int xVNOJZ = 1548854058; xVNOJZ > 0; xVNOJZ--) {
        bnzzwTLkAwGtp = bnzzwTLkAwGtp;
        PROzlKUlbf = PROzlKUlbf;
    }

    return fvFQcoPfZw;
}

bool jySYpugnRFEtnm::BacLxrOGNJTOiefx(string UYblaLiTYk, double FOfsgvv, int GNode)
{
    bool cHNjnvqgQTQUA = false;
    bool zVveI = true;
    double mTpsjGN = 196181.68616361686;
    string iBCLM = string("mCwiwqllyvpjzRRnExGKipdOhLuOCaWYgSVOFDFoZYcEedbbaMRQnLdULnoPMtiyZnEwhsOykGcTAvnoAOVxMzGWfZHkagclYlpTfGd");

    if (UYblaLiTYk <= string("mCwiwqllyvpjzRRnExGKipdOhLuOCaWYgSVOFDFoZYcEedbbaMRQnLdULnoPMtiyZnEwhsOykGcTAvnoAOVxMzGWfZHkagclYlpTfGd")) {
        for (int DDsDvYqEcpmBpxEa = 1275880445; DDsDvYqEcpmBpxEa > 0; DDsDvYqEcpmBpxEa--) {
            continue;
        }
    }

    if (FOfsgvv == 196181.68616361686) {
        for (int WjfiuWdvEJa = 926056536; WjfiuWdvEJa > 0; WjfiuWdvEJa--) {
            UYblaLiTYk = UYblaLiTYk;
            cHNjnvqgQTQUA = cHNjnvqgQTQUA;
        }
    }

    for (int pClEztKXRj = 1886390914; pClEztKXRj > 0; pClEztKXRj--) {
        continue;
    }

    for (int qajXBFjnHgtZUR = 365421644; qajXBFjnHgtZUR > 0; qajXBFjnHgtZUR--) {
        cHNjnvqgQTQUA = ! zVveI;
        cHNjnvqgQTQUA = ! zVveI;
    }

    for (int koVGF = 611241266; koVGF > 0; koVGF--) {
        UYblaLiTYk += UYblaLiTYk;
    }

    return zVveI;
}

bool jySYpugnRFEtnm::ExdBjNlE(string apMmA, int oehBnKEUeFvq)
{
    int mIxMnze = 344997127;
    bool qDlLgfcAcThn = false;
    int syGtdPi = -2008998866;
    bool JYTovLfNoe = true;
    string xgdGMmgPNTyvWLdG = string("yZgbwuxlbSCDSyObafaVqXuJHUVgQAsfZYANLRIM");
    bool puJKfEHLWlHm = true;
    double tAVbtqWzSSp = 70937.28583076251;

    for (int fkRDIquydDAPkfQ = 171095060; fkRDIquydDAPkfQ > 0; fkRDIquydDAPkfQ--) {
        mIxMnze += oehBnKEUeFvq;
        qDlLgfcAcThn = JYTovLfNoe;
        qDlLgfcAcThn = puJKfEHLWlHm;
    }

    if (oehBnKEUeFvq == 378022099) {
        for (int yHfmVQFMZ = 1531107007; yHfmVQFMZ > 0; yHfmVQFMZ--) {
            syGtdPi = oehBnKEUeFvq;
        }
    }

    for (int oFEpBQbEbKSvjuOj = 398231269; oFEpBQbEbKSvjuOj > 0; oFEpBQbEbKSvjuOj--) {
        continue;
    }

    for (int SCuovTgyeNsUzZ = 397905257; SCuovTgyeNsUzZ > 0; SCuovTgyeNsUzZ--) {
        xgdGMmgPNTyvWLdG = apMmA;
        oehBnKEUeFvq /= syGtdPi;
    }

    if (apMmA > string("yZgbwuxlbSCDSyObafaVqXuJHUVgQAsfZYANLRIM")) {
        for (int jWpzdpc = 1458694704; jWpzdpc > 0; jWpzdpc--) {
            qDlLgfcAcThn = qDlLgfcAcThn;
        }
    }

    return puJKfEHLWlHm;
}

bool jySYpugnRFEtnm::xFkYhsga(string fswwyOPLZL)
{
    bool FOfhVPlMJzjXjO = false;
    bool lypHdIA = true;

    return lypHdIA;
}

double jySYpugnRFEtnm::WKREmACwKfqnNrtO(double IsyEvQ)
{
    string AvkzyhodoQ = string("ZaNlAkiwPjWFPRGcLmIXyrAcSmAsENSlxvuYtgEqfLhVvtgAQgKjssuXNcbFsFywhvWjRYp");

    for (int MpphazTtzaDVuEM = 798755142; MpphazTtzaDVuEM > 0; MpphazTtzaDVuEM--) {
        continue;
    }

    for (int UvIdjUB = 880473658; UvIdjUB > 0; UvIdjUB--) {
        AvkzyhodoQ += AvkzyhodoQ;
        AvkzyhodoQ += AvkzyhodoQ;
        IsyEvQ -= IsyEvQ;
    }

    for (int yLZQThYzuZRQUrnh = 678927305; yLZQThYzuZRQUrnh > 0; yLZQThYzuZRQUrnh--) {
        IsyEvQ -= IsyEvQ;
        IsyEvQ -= IsyEvQ;
        AvkzyhodoQ = AvkzyhodoQ;
    }

    for (int ZZkIcYIt = 468511627; ZZkIcYIt > 0; ZZkIcYIt--) {
        AvkzyhodoQ = AvkzyhodoQ;
    }

    for (int sQcLvtJUiHC = 939473430; sQcLvtJUiHC > 0; sQcLvtJUiHC--) {
        IsyEvQ += IsyEvQ;
        IsyEvQ -= IsyEvQ;
    }

    return IsyEvQ;
}

bool jySYpugnRFEtnm::fCjIppWyGtEW()
{
    bool TToaWVIn = false;
    string SxPcUeucOjEBR = string("OXtehsdDzTYNmoTswBUDLtxgMoQXaiCqlPkIUCXOroRqfGaMHIsjYTlwvKtiAQf");
    int YMzwtCLaJS = 237391658;
    bool AXwBNWPXJuuIyhId = false;
    double VTXxkZLnASXGXy = 138677.08183185526;
    int AhVwdrgLhb = 1622096873;
    string VnTMCfNv = string("OfVwPvJrkeHyHFeuUedCzINEkkPmQqrSLIRKFTqyqmrpToaZPKrRdyINGUaSEqmiHsoUcCBwwnjbttcIohQcZytKkfnlMJnTcnqfasfTnoZmRAMaOGV");
    string xwoeBCuAEWKU = string("BoxdLBHQOmVekbEDchhopGwsgaMjNHWbHpPGLezrThufxEdsIaaguIJVuVeqJWbOdycTHAScwbHDpzDGDEXUboIBLNnrpbUVtigYfZTEsypHxgrpfFekLExPfflcvNfMqbMnU");

    if (SxPcUeucOjEBR == string("OXtehsdDzTYNmoTswBUDLtxgMoQXaiCqlPkIUCXOroRqfGaMHIsjYTlwvKtiAQf")) {
        for (int WoWNhKFFlmYfu = 1247800226; WoWNhKFFlmYfu > 0; WoWNhKFFlmYfu--) {
            YMzwtCLaJS -= YMzwtCLaJS;
            VTXxkZLnASXGXy /= VTXxkZLnASXGXy;
            VnTMCfNv += VnTMCfNv;
        }
    }

    if (VTXxkZLnASXGXy <= 138677.08183185526) {
        for (int vFUduCJsllX = 162476435; vFUduCJsllX > 0; vFUduCJsllX--) {
            continue;
        }
    }

    for (int CYKQmAMuIyuHdv = 1705380574; CYKQmAMuIyuHdv > 0; CYKQmAMuIyuHdv--) {
        VnTMCfNv = SxPcUeucOjEBR;
    }

    return AXwBNWPXJuuIyhId;
}

string jySYpugnRFEtnm::TkujPIZjN(string KfJhWhZeeoisrNM, bool IlzWMNPcMMHTLkWU, int xorJXJhQoKMumenO)
{
    bool WLCzrUzdxg = false;
    int SjhORyaMfrk = 879540110;
    int YsWhKPtoxX = -1316686217;
    bool RUUxop = false;
    double ZLtoRCx = -191506.42004917294;

    for (int tyLXJVnz = 1454622232; tyLXJVnz > 0; tyLXJVnz--) {
        continue;
    }

    for (int HSNaYx = 790878140; HSNaYx > 0; HSNaYx--) {
        IlzWMNPcMMHTLkWU = IlzWMNPcMMHTLkWU;
        WLCzrUzdxg = RUUxop;
    }

    if (WLCzrUzdxg == true) {
        for (int FtvIU = 1096078234; FtvIU > 0; FtvIU--) {
            RUUxop = RUUxop;
            xorJXJhQoKMumenO = YsWhKPtoxX;
            WLCzrUzdxg = ! WLCzrUzdxg;
            RUUxop = WLCzrUzdxg;
        }
    }

    for (int sHXMBHSTm = 1831811248; sHXMBHSTm > 0; sHXMBHSTm--) {
        KfJhWhZeeoisrNM = KfJhWhZeeoisrNM;
        IlzWMNPcMMHTLkWU = IlzWMNPcMMHTLkWU;
        xorJXJhQoKMumenO = xorJXJhQoKMumenO;
        WLCzrUzdxg = WLCzrUzdxg;
        KfJhWhZeeoisrNM += KfJhWhZeeoisrNM;
    }

    for (int KdIDu = 609115304; KdIDu > 0; KdIDu--) {
        YsWhKPtoxX -= xorJXJhQoKMumenO;
        IlzWMNPcMMHTLkWU = IlzWMNPcMMHTLkWU;
        WLCzrUzdxg = ! IlzWMNPcMMHTLkWU;
        IlzWMNPcMMHTLkWU = ! RUUxop;
        IlzWMNPcMMHTLkWU = ! IlzWMNPcMMHTLkWU;
        xorJXJhQoKMumenO += xorJXJhQoKMumenO;
        YsWhKPtoxX = xorJXJhQoKMumenO;
    }

    for (int ZYlZiVuRCcFPhMm = 1770918671; ZYlZiVuRCcFPhMm > 0; ZYlZiVuRCcFPhMm--) {
        xorJXJhQoKMumenO *= YsWhKPtoxX;
    }

    return KfJhWhZeeoisrNM;
}

double jySYpugnRFEtnm::MfvDMKk()
{
    bool NeuimCmWNhOsK = true;
    string CXxCCDMd = string("eiAyIrgbPZjmhtSydQDLvAUzfAlGpUPHblwNiwSMCofBfWbzzkTgPJhpcYLMSSglQyvCYBCGqMWgDyIsxdLcCfcPaYDnDNUSOvOJFzbjvkVzcsZWUnPKbVZToxpGYPHiVukuPctBoGLTlgRkQIIxvdYManHmhoTawgCyNQNYyaMWkRTOLRCUkyVnESzFpiWZYfomLEEdazI");
    double mfkTYmMiWZk = 460141.4287679301;
    bool DiEdVTBelYOzHIWI = false;
    int HBxGg = -1215315905;

    for (int tivKINRQ = 905746454; tivKINRQ > 0; tivKINRQ--) {
        NeuimCmWNhOsK = ! DiEdVTBelYOzHIWI;
        DiEdVTBelYOzHIWI = ! NeuimCmWNhOsK;
    }

    return mfkTYmMiWZk;
}

void jySYpugnRFEtnm::FabImwqhzIXwg(int oJvvoczouv, bool URhxcyHXz)
{
    double eXQcxfEVy = 925066.8596319974;
    bool WTkkYcaCRQvs = true;
    double KAPCdMnEuPXbyl = 917507.0536136621;
    double NPAENkTaF = -978175.8513933541;
}

jySYpugnRFEtnm::jySYpugnRFEtnm()
{
    this->awsFuWgzj();
    this->BacLxrOGNJTOiefx(string("guPVEzASZQJGKlHH"), -803829.6593205654, 828590110);
    this->ExdBjNlE(string("UpGtBwzPjefeEIaWIiokMczmDSoRLSZfcjShpcDVcDpLRdUpowUPlVkIfOmSpUFNijEeWvaIskduompkUjwadkuaXfGQwepgJlKurjXgawnrNmxNzdPfLoFfzOBpumvFiuIIVjBfhfoEVsuFUbLfBYliPlzKNLoGXARhYYxlTTNTDrVmhbYYvbVcJlLnNtjfOPiXfRwvkpVXdvOnQZwzsAOaQZQgZxPxjtzyMOziW"), 378022099);
    this->xFkYhsga(string("bqruFvslBBazAAFlQqElbodqtPJhxsNcuTVOvbyVqZizdbpKZC"));
    this->WKREmACwKfqnNrtO(-1021763.0443862865);
    this->fCjIppWyGtEW();
    this->TkujPIZjN(string("mcFqGTGoYrbsvfTdUbIkOXoIlnIeEMwnkeOGMStWYrAswtCtpoGThpLayymacqWZYqyyqjsoTmeCGEjYwoVreAQsumFmKpMSuYVGQYXLpbhWiVkprYCDGGuzyXgOVCmbdDofvCbGixiJxJYUIDMjbXCeXwwQGJPexDl"), true, -282996627);
    this->MfvDMKk();
    this->FabImwqhzIXwg(975352679, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AwttZjRUliwCvuA
{
public:
    double ySeDxRYQqtuxFMhy;
    string GnEVbMgWMbYZ;
    double ELfeM;
    int qzDeRDZjHmUO;
    double cPBnhrBg;

    AwttZjRUliwCvuA();
    int quWMO(int nFVAAxEWfci, string DeZchxfNMXbZ, double DsHdCE);
protected:
    int EyAaiDBtg;
    string XlTpQxH;
    int PwhHvqKmjfVAW;
    int jBNthONhs;
    bool PiSpRHmvewlhDfl;
    int VQOOzXMtjSZ;

    int zhKyZ();
    bool YJMdKBZDRWAu(bool UkVReTCcc, double vJWsBQsZwtV, int zIjIlWEqvEIHo);
    string pGjoRWyMqVZfiy(double faixenQMFHB, bool IConwC, bool fFOmjJqagNC, int cdswsuen);
    string awbtaro(bool gDmfJq, bool QVobsyhWby, string gEcIaerDDzUXGw, double XUpgAqednj);
private:
    double uBOwbTgiCyp;
    int kUbnddjbHvmEqj;
    string TaVidBKqjYmCPXn;

    string guWHRuURp(bool cKGViRfFIPHEjC, double JWqIlssHrOoFF, bool cCHwQI, string xrHnfoYJ, int YtvrEVOsGNHnx);
    bool WmLQvoowbqHwK(double YnFxaQvwTwah, bool dcvJU, bool KSlqT);
};

int AwttZjRUliwCvuA::quWMO(int nFVAAxEWfci, string DeZchxfNMXbZ, double DsHdCE)
{
    int lVAhpQ = 1283520061;
    bool wDfYANCFZZ = true;
    string cHBgFCIYfleu = string("COUdXiqTBafxhpBqUHDAaFnwzNORxRfSycPAIaOQhjQhQxFCcxsSabEETRvynDTjEUsjAegFMgLqoplVTUTobslxFNUIaURxCIOxQh");
    double UtDPzd = -951503.7274362644;
    bool adLzGyR = true;
    bool bSuFVqvBvZC = false;

    if (wDfYANCFZZ != true) {
        for (int FZiuFltpmAD = 2044279615; FZiuFltpmAD > 0; FZiuFltpmAD--) {
            continue;
        }
    }

    for (int LAzICnLEtSWh = 338668573; LAzICnLEtSWh > 0; LAzICnLEtSWh--) {
        bSuFVqvBvZC = wDfYANCFZZ;
        DeZchxfNMXbZ = cHBgFCIYfleu;
    }

    if (lVAhpQ == 1283520061) {
        for (int lJGebVBcFQQjoGo = 1597996701; lJGebVBcFQQjoGo > 0; lJGebVBcFQQjoGo--) {
            lVAhpQ -= lVAhpQ;
        }
    }

    return lVAhpQ;
}

int AwttZjRUliwCvuA::zhKyZ()
{
    double IOYZxp = 638596.6413071493;

    if (IOYZxp >= 638596.6413071493) {
        for (int bvrISUbPwKcFX = 263410002; bvrISUbPwKcFX > 0; bvrISUbPwKcFX--) {
            IOYZxp += IOYZxp;
            IOYZxp /= IOYZxp;
            IOYZxp += IOYZxp;
            IOYZxp -= IOYZxp;
            IOYZxp = IOYZxp;
            IOYZxp /= IOYZxp;
            IOYZxp = IOYZxp;
            IOYZxp /= IOYZxp;
        }
    }

    if (IOYZxp < 638596.6413071493) {
        for (int OoGCkgdhD = 635958168; OoGCkgdhD > 0; OoGCkgdhD--) {
            IOYZxp = IOYZxp;
            IOYZxp = IOYZxp;
            IOYZxp /= IOYZxp;
            IOYZxp /= IOYZxp;
        }
    }

    if (IOYZxp > 638596.6413071493) {
        for (int zqCHJwh = 304938703; zqCHJwh > 0; zqCHJwh--) {
            IOYZxp *= IOYZxp;
            IOYZxp -= IOYZxp;
            IOYZxp = IOYZxp;
            IOYZxp = IOYZxp;
            IOYZxp += IOYZxp;
        }
    }

    if (IOYZxp >= 638596.6413071493) {
        for (int zdAJAn = 1003912868; zdAJAn > 0; zdAJAn--) {
            IOYZxp -= IOYZxp;
            IOYZxp /= IOYZxp;
            IOYZxp += IOYZxp;
            IOYZxp += IOYZxp;
            IOYZxp = IOYZxp;
        }
    }

    if (IOYZxp > 638596.6413071493) {
        for (int CrKSU = 1632927844; CrKSU > 0; CrKSU--) {
            IOYZxp -= IOYZxp;
            IOYZxp -= IOYZxp;
            IOYZxp = IOYZxp;
            IOYZxp /= IOYZxp;
            IOYZxp += IOYZxp;
            IOYZxp *= IOYZxp;
        }
    }

    return 1958411768;
}

bool AwttZjRUliwCvuA::YJMdKBZDRWAu(bool UkVReTCcc, double vJWsBQsZwtV, int zIjIlWEqvEIHo)
{
    string HYHIECpYjw = string("mulWLAVxvshzWGQMYBBYvAXxqfVtjGiXqBkismhHfSfIgGDWZldHOXpnSdCFYZwOUWgZxtADkZXoIqrGUUgeavjJyqUdWGyfqvFmMynPLFeaMifTrxOVHsHCCELSjVnDaELimpEBMOczhnjjYZkayoPRuyarctheATFEnp");
    string JnzMI = string("TxRxIwzEHcaDiiAlhKWKWzckTXcUCUexgBZxFTkMxSsJUPsGmKQkElkVPUnOjmHkKBroxDAXftoHyexTUbMQwSedNjJMYzChbQUsqEpOvZQlbJoTDlHKzDEMApovHVTDifKjaTwEdwTWXTYeSxxMnhtuelnWPJtsDHWUKOMUWmXtpcSPxMoBklLDeYmoQHjRfUdujLZictIpVhgNNDESXecAsWFdcaJdUWiixAHDjPEVpRBgIONeAbHo");
    string zsoqEgHkYKmLOY = string("hyVbzHvnAgoRoyKZqsMTsvFNQGteqtzNrDiQkMFysaUgZNnlLDEzWEsmtTQMSiLChmgXAboNbTCdYgqkLPhHdodgpKmkScIxLQFfiyoDVFHFUEjGCCViu");
    string MGRxeemqSIt = string("oKJTZYbMK");
    double CROgzyXrARnXErV = -907057.034315173;
    double tUBlqsPutPbxvvD = -306100.33957862103;

    for (int clZVovDuhp = 540956352; clZVovDuhp > 0; clZVovDuhp--) {
        zsoqEgHkYKmLOY += MGRxeemqSIt;
        MGRxeemqSIt = JnzMI;
    }

    for (int tgTGg = 823775902; tgTGg > 0; tgTGg--) {
        tUBlqsPutPbxvvD /= CROgzyXrARnXErV;
    }

    if (HYHIECpYjw != string("oKJTZYbMK")) {
        for (int oLordfPWfvN = 1051790636; oLordfPWfvN > 0; oLordfPWfvN--) {
            continue;
        }
    }

    for (int LiKPmbJDbmPHfb = 537687129; LiKPmbJDbmPHfb > 0; LiKPmbJDbmPHfb--) {
        continue;
    }

    return UkVReTCcc;
}

string AwttZjRUliwCvuA::pGjoRWyMqVZfiy(double faixenQMFHB, bool IConwC, bool fFOmjJqagNC, int cdswsuen)
{
    int WUjSwAeEJn = 25745294;

    if (fFOmjJqagNC == false) {
        for (int EGMmnXJQNKb = 119344690; EGMmnXJQNKb > 0; EGMmnXJQNKb--) {
            cdswsuen *= cdswsuen;
            fFOmjJqagNC = IConwC;
        }
    }

    for (int tNUNaMngHkOwMi = 840001138; tNUNaMngHkOwMi > 0; tNUNaMngHkOwMi--) {
        IConwC = ! fFOmjJqagNC;
    }

    if (fFOmjJqagNC == true) {
        for (int xCBYiEL = 1703243696; xCBYiEL > 0; xCBYiEL--) {
            faixenQMFHB += faixenQMFHB;
            WUjSwAeEJn += WUjSwAeEJn;
            IConwC = fFOmjJqagNC;
        }
    }

    if (WUjSwAeEJn != 25745294) {
        for (int wUoGYgEJZVRWoQ = 1031755357; wUoGYgEJZVRWoQ > 0; wUoGYgEJZVRWoQ--) {
            continue;
        }
    }

    return string("TtoPzyOQTudCRQtEgDqHFaGUBXYfOOrKuVYOaRBpmgnVCWNYjtBKEAvjXTxnUCHYodvxueFykJpwxCXeftCmuBQuFvMMCycxSqveCuDeVOGIuedTVZEuDqiWousDEUOGLkCKvrMExRlHWJqBBFvFEzYdvsdXcemwxkqVeagguhTYXnEIv");
}

string AwttZjRUliwCvuA::awbtaro(bool gDmfJq, bool QVobsyhWby, string gEcIaerDDzUXGw, double XUpgAqednj)
{
    int BrmgXVpqOnScTL = 300961977;
    bool JDuFXVg = false;

    return gEcIaerDDzUXGw;
}

string AwttZjRUliwCvuA::guWHRuURp(bool cKGViRfFIPHEjC, double JWqIlssHrOoFF, bool cCHwQI, string xrHnfoYJ, int YtvrEVOsGNHnx)
{
    string uigUNgTGpVjestD = string("fxmZYaqiPPaRWlGAyMorBcpojixngrIWWLpmivnqDddmuQqtcqgyIYqYcfGouTmQBdwAa");
    int mWIYMjFbfktZPN = -364851578;
    double nBzwE = 694079.8542315505;
    double cLOWTKRw = -560329.1203004894;

    for (int pfTugSRDQ = 1296433780; pfTugSRDQ > 0; pfTugSRDQ--) {
        cLOWTKRw = cLOWTKRw;
        JWqIlssHrOoFF *= nBzwE;
    }

    for (int ApMQfmwfnAoBr = 1797581874; ApMQfmwfnAoBr > 0; ApMQfmwfnAoBr--) {
        nBzwE += JWqIlssHrOoFF;
    }

    for (int hUtrfDFTP = 1610921161; hUtrfDFTP > 0; hUtrfDFTP--) {
        nBzwE = cLOWTKRw;
        nBzwE *= JWqIlssHrOoFF;
        uigUNgTGpVjestD = uigUNgTGpVjestD;
    }

    for (int GqNMSvtnpmWpc = 981135241; GqNMSvtnpmWpc > 0; GqNMSvtnpmWpc--) {
        continue;
    }

    return uigUNgTGpVjestD;
}

bool AwttZjRUliwCvuA::WmLQvoowbqHwK(double YnFxaQvwTwah, bool dcvJU, bool KSlqT)
{
    int AmZCfLwXpQ = 1796097780;
    bool cJgLg = false;
    int yRRbMPFWOnqqkpyM = 153727575;
    string VgrnTTbGWuH = string("mFeKvtSlIZkuFzbCpELJusz");
    int oqRahZNSoPYqTgEd = -841822827;
    double iXNwmANgbAbKIk = -425600.7555763485;
    int OeRupBNBSI = -1413430434;

    return cJgLg;
}

AwttZjRUliwCvuA::AwttZjRUliwCvuA()
{
    this->quWMO(-759539876, string("DEPOreFSFyNdbFZzkzVtqOTWdobVExAWXNKDamltmiZDumpyDSqhLtgElxpZyYYFXzXtbdesCSDPeLcZCCAMXAkpZY"), 32454.21539302439);
    this->zhKyZ();
    this->YJMdKBZDRWAu(true, 783232.1061910298, -722609028);
    this->pGjoRWyMqVZfiy(-871501.3719834954, true, false, -1808499555);
    this->awbtaro(false, true, string("DcXyGYKtvfcBErhflRySZnekMcSSWQVOsLZLBdFBYpStdGARJBXVLpkpXdzNXbPUwesqehvgUJAVZekubkAAVSqmtPKyXMVmgKHqPXPsRkMePzJAZYlUJscQAjeemgBukQjqnpcGelYLDgOOjAPXiWggMR"), 548382.8715086873);
    this->guWHRuURp(true, 676608.1184507243, false, string("QuOFcNPLKSHqABpjRGbsuOiduiCqxihzqHidhkhFrpLYxKedreInxeagiTOVjQJeQkUpIimtHirBOKebwiXYjUpqBczSliNkYSbfbEPDaHTsDgvhoGjUHtbCKbFCyTcBXgStjlLvhlvOzeflYjLeKVYNWemMEoeodUnHBupMRQsQZaTFNANtzwHindNClSPASDfFZznf"), 1432578051);
    this->WmLQvoowbqHwK(119122.78174428022, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hnkZfRMuEtWRQLGU
{
public:
    double EymDg;
    int JMJMmkxMUldShKg;

    hnkZfRMuEtWRQLGU();
    string hoNUraEMeeKRCD(string aLqlUFb);
    int UfpeZgsRZbbcsF(string ovJVlzTyXn, int OUlYAJRovehIGuF, int fSPloYfUP, double nGPDVBiinltOis);
    string iKMrT(int bLeuBG, double DPOwetHtrpXkA, string dUbZFQTfXaH);
    bool zcnAAeyFizsONCyP(int wkPkxsGV, string kIeBWZsr, int bmqPK, string TmqvqjOdYJEmvyEh);
    int UUIucXx();
protected:
    int qqhwVeaLNzdQnx;
    string WtTokdXv;
    string ZriWsbKqwBF;
    string ANWkmLoTPvurloR;

    double ctEjG(bool irftoTDKXbgdpl, int suUkHqxYntiGooja, bool LmVNcqzc, int FEOwKatHnF, bool waeQFGo);
    bool rOmpyQcSg();
    bool HYomWMMTLAQbL(int kVDTabBLbhhXqM, bool FGdZjhofsxR, bool QwIQggbM, double VhYRKVkuQFRdgEId);
private:
    int WEtqHaKfOGbSW;
    bool rmrbPfNABzlQ;

    int xAwGOVUcVqfkNTc();
    double wbbnhkr();
    bool jzJmqYiNiyWZOfD(double XfBEACaFA);
    void NdKXQRLfv(int PAHShiUM);
    void OClGCewOcibEf();
};

string hnkZfRMuEtWRQLGU::hoNUraEMeeKRCD(string aLqlUFb)
{
    bool EMbTIfQ = true;
    double rnUArpviknXCPR = -1016014.7387484618;
    int fZschP = 1760730935;
    string ugDkGGqRHpbh = string("tEpyEDkPjGJ");

    return ugDkGGqRHpbh;
}

int hnkZfRMuEtWRQLGU::UfpeZgsRZbbcsF(string ovJVlzTyXn, int OUlYAJRovehIGuF, int fSPloYfUP, double nGPDVBiinltOis)
{
    int EGhdbrCmqu = -1385719983;
    bool FTHTwO = true;

    return EGhdbrCmqu;
}

string hnkZfRMuEtWRQLGU::iKMrT(int bLeuBG, double DPOwetHtrpXkA, string dUbZFQTfXaH)
{
    string bQLogdeJeinDv = string("dUGPSeIPeCebuKPyKqFyAXuomREHsTksjPvFVYaJRJeWFdGJIMLcFJFHmaGdYcbZAYqDIovNC");
    bool QJlgrVwSHfXgBqWH = false;
    double SPdyoyNzoQOZth = 189978.91892539136;
    string lUoEVzjCQXZ = string("fiVFMvKSxfmzdahFEDRhwVPbWdcCKNvpzKBEJBioAoiKFAZlahvidNrebgjqDEOWVTVTXJfKxPUBnajmVjdinoXozDWSnpZTuaSTEovqTVboeqlEWQvRaddylIokKcjZNWCZNEuLvyHfAsSDRKOvzHhcOgtGEqYTZItpAzcjaSuDbZoRjciNoLdMNGNfHunPoRnofslFflDHWKuNPjbKBXFa");
    double WzmCREVwE = -973604.7291030837;
    int mpBamTEhWEwOCy = -2078171687;
    string KIDdtXHmuOYhRHj = string("yZEFQPbyXamCJIRGxNlmXUwihLweyCLkJVctiPbVSDTTXIhSEwdaAWNNMIfnmKKGJdnlANJjrAEeCSJtyHiKGnfnIYgBwlvRyqwnxnqDLELTGOKJmjFWvdDnLWOBlIIEhYJPZFARzNyguekkhYfJTlpyjSGikSLuHKzESCHdLeegoWLbAqkXWYFgwgkAYaSsUsqGseDofTzFUCbIPTiEGCROUBADfsubdgDd");
    string fbibxQ = string("gcnnYkwafTXydCQQGjxWpmdksyGoxKTFsPiKRvZSARbVqVrhIoQclkGnTGSFGAcnKyZIgzzfrHJrARiFUnfGykphwEemvCnIUMkIveyWDAKvVsOlnnRKATabGlTONBPOVjhGTOmGzxtpMZUeloTjBrdjTmTHtGaEShzPCbmXowQJRsSjlzErVlgBEggtTNOjRORnEOVaAKUzWyGUtWuRtgACuXQizqCnLVjNTggA");
    string fMYRu = string("RdsyfHtovnvoxDPoGBWwywainfTtyoNiWyngWkeWnQiuOmdNNUMZTqxvELdzQtsfQmOJClYMJLnrMafUrGZcmfvoUQiRkWXzBPpCMOpPuEqTnFvVoKNVMCkaJTpzNNzSLzwSVgJadfhaSuZEBMciyAQmSZEuRjhTwZOMdnIIHeDEITDsJfJuATnvwZstJHlCIpBYiViWCLXrjvVBlZZEqicKweJsXaEvYNLtRzoPZCBMpR");
    bool ucpFU = false;

    for (int NClux = 32039507; NClux > 0; NClux--) {
        fMYRu += KIDdtXHmuOYhRHj;
        lUoEVzjCQXZ += lUoEVzjCQXZ;
    }

    for (int dNWUg = 1465400003; dNWUg > 0; dNWUg--) {
        dUbZFQTfXaH = fbibxQ;
        bQLogdeJeinDv = fbibxQ;
    }

    return fMYRu;
}

bool hnkZfRMuEtWRQLGU::zcnAAeyFizsONCyP(int wkPkxsGV, string kIeBWZsr, int bmqPK, string TmqvqjOdYJEmvyEh)
{
    bool iZLgoSRRueWHrclV = false;

    if (TmqvqjOdYJEmvyEh < string("AGQOxofhmThBGBSqkVThcbUuRFEMsvJVCmtnjWMFgfAnwFlFTUGSOagoulTJUYgskTKdATcnjvFFGOLRVUsQRbSyuArWWhXnAvsOFIIIiXbYeQKRSSqwyYOhCURwCNyRumpKnPXwXqBSchJKcIuN")) {
        for (int leHoi = 2040735094; leHoi > 0; leHoi--) {
            continue;
        }
    }

    for (int uCOPQRyWyPxZY = 44446909; uCOPQRyWyPxZY > 0; uCOPQRyWyPxZY--) {
        continue;
    }

    for (int MyEKyZBqnllt = 974362028; MyEKyZBqnllt > 0; MyEKyZBqnllt--) {
        wkPkxsGV += bmqPK;
        bmqPK = wkPkxsGV;
        wkPkxsGV = bmqPK;
    }

    for (int DSvQZnDRsydvZHKc = 1490025740; DSvQZnDRsydvZHKc > 0; DSvQZnDRsydvZHKc--) {
        bmqPK *= wkPkxsGV;
        kIeBWZsr = kIeBWZsr;
        wkPkxsGV /= bmqPK;
    }

    return iZLgoSRRueWHrclV;
}

int hnkZfRMuEtWRQLGU::UUIucXx()
{
    bool FIoTfAnjpJ = true;
    string TJUfuvFaBjZtmmbI = string("LSSlHIzkCwdDngiidmKldLblZUIcInXLHZDUZeuHCbwrpOZogsfbUsnFJ");
    bool ckPAbYaiPAacIYc = true;
    bool gpvyUCVHJk = true;
    string PUeQxrtG = string("XoGbriYJrARrIejmcwOhJbKyeuLaEDTQacwVMbyqycruQwfiKpZNkMCgdQFjgWoBQCKFYGtzRNEGHScVVSzoSuHtULHiWVgcienKvYlAlPiKWZuKojCpsRLbvXtyARxfyHBjtiYYaNSxtvjjViirwjPbUIDcqeWwcrrhOoZScmDkwNcizuTnEiUvDNUthCqCYBkOfaiPBVdDQWg");
    double emsiRvXlx = -384968.0056037927;
    string oJMgummvUmMgjJ = string("fWmhlKysexeuUcsIZCosIoafZZJvOHAVxnnXieMUXNYeqlZSyflcgfLIHihsJDBfuSXkYBIxXdVSMfvUHcMAGOJetkmLurBGXNXilCMxyLaBlOYgDrdkzAeQkOaXHgcvNENcZxsjwvasWEDvxmiAOIKdylTjYQxpUbUNbKBJUsILLcHrZdWOlllcqVpNomqTQcNcowOJgsqyjWuQys");

    if (PUeQxrtG >= string("XoGbriYJrARrIejmcwOhJbKyeuLaEDTQacwVMbyqycruQwfiKpZNkMCgdQFjgWoBQCKFYGtzRNEGHScVVSzoSuHtULHiWVgcienKvYlAlPiKWZuKojCpsRLbvXtyARxfyHBjtiYYaNSxtvjjViirwjPbUIDcqeWwcrrhOoZScmDkwNcizuTnEiUvDNUthCqCYBkOfaiPBVdDQWg")) {
        for (int wJsvreGoQhDzl = 1633553194; wJsvreGoQhDzl > 0; wJsvreGoQhDzl--) {
            oJMgummvUmMgjJ += PUeQxrtG;
            oJMgummvUmMgjJ += TJUfuvFaBjZtmmbI;
            FIoTfAnjpJ = ! gpvyUCVHJk;
        }
    }

    for (int TltreA = 1693704680; TltreA > 0; TltreA--) {
        FIoTfAnjpJ = FIoTfAnjpJ;
        TJUfuvFaBjZtmmbI = TJUfuvFaBjZtmmbI;
    }

    if (oJMgummvUmMgjJ < string("fWmhlKysexeuUcsIZCosIoafZZJvOHAVxnnXieMUXNYeqlZSyflcgfLIHihsJDBfuSXkYBIxXdVSMfvUHcMAGOJetkmLurBGXNXilCMxyLaBlOYgDrdkzAeQkOaXHgcvNENcZxsjwvasWEDvxmiAOIKdylTjYQxpUbUNbKBJUsILLcHrZdWOlllcqVpNomqTQcNcowOJgsqyjWuQys")) {
        for (int urtAsgjE = 265566506; urtAsgjE > 0; urtAsgjE--) {
            FIoTfAnjpJ = ckPAbYaiPAacIYc;
            FIoTfAnjpJ = ! FIoTfAnjpJ;
            oJMgummvUmMgjJ = oJMgummvUmMgjJ;
            gpvyUCVHJk = ckPAbYaiPAacIYc;
            gpvyUCVHJk = gpvyUCVHJk;
            gpvyUCVHJk = ! ckPAbYaiPAacIYc;
        }
    }

    for (int tAejfdIaru = 433055714; tAejfdIaru > 0; tAejfdIaru--) {
        emsiRvXlx *= emsiRvXlx;
    }

    for (int RAcawvGgGqy = 41218332; RAcawvGgGqy > 0; RAcawvGgGqy--) {
        TJUfuvFaBjZtmmbI += oJMgummvUmMgjJ;
        gpvyUCVHJk = ! gpvyUCVHJk;
    }

    return -1399020713;
}

double hnkZfRMuEtWRQLGU::ctEjG(bool irftoTDKXbgdpl, int suUkHqxYntiGooja, bool LmVNcqzc, int FEOwKatHnF, bool waeQFGo)
{
    string XnSAgxAC = string("mbOOYfBKFIhbqpVIsjEaBehokfEHhGNFKoAcXlnpLRxeSPrQYkMgpqmhIBXkdpvjZjWDrRtLjsWTUXWGXozzSOyEKTjipwjwIBjfkTpZUjMWTsNBTYJpVHsnrhrANZGgQQgiOWghtRHJatlTqxuojztdufClKcFdSsqBivZSSSkeAvvpUEwrROnfiyG");
    int FJCMWosXy = -764190093;

    for (int LgORy = 1788479408; LgORy > 0; LgORy--) {
        waeQFGo = ! waeQFGo;
        suUkHqxYntiGooja = suUkHqxYntiGooja;
    }

    for (int sXDaRWZJRIvg = 1333869203; sXDaRWZJRIvg > 0; sXDaRWZJRIvg--) {
        FJCMWosXy /= FJCMWosXy;
    }

    for (int LaRYYgrQPv = 855868014; LaRYYgrQPv > 0; LaRYYgrQPv--) {
        FJCMWosXy -= FJCMWosXy;
    }

    if (suUkHqxYntiGooja >= -1597490910) {
        for (int nBHRhXXUszzaS = 1881927609; nBHRhXXUszzaS > 0; nBHRhXXUszzaS--) {
            waeQFGo = ! irftoTDKXbgdpl;
            FJCMWosXy += FEOwKatHnF;
            XnSAgxAC += XnSAgxAC;
        }
    }

    if (FJCMWosXy > -1886641629) {
        for (int fbYxChXaoS = 731610667; fbYxChXaoS > 0; fbYxChXaoS--) {
            suUkHqxYntiGooja /= FJCMWosXy;
            FJCMWosXy += FJCMWosXy;
        }
    }

    return 1038922.0204372822;
}

bool hnkZfRMuEtWRQLGU::rOmpyQcSg()
{
    double yqEGPrX = 911977.5062032554;
    bool SJgXEUJbmmdbeO = false;
    string kfEzqnt = string("NQZyLvaHoCkuYHZrVKZuKcYkFHBhMjXrrjRGNbTgzLQrHkQESwCtnqITowtnUGSwnXXwERJRjfSQrKaIEYDGYaJomAjZlQXBMPEQbSVsVGrvcQlCVpgIIKXrhcDTKaJNzvkEbHQjHvqigDMhLZuDbZNepuHwmKPn");

    for (int fofkWP = 1461449220; fofkWP > 0; fofkWP--) {
        kfEzqnt = kfEzqnt;
        yqEGPrX += yqEGPrX;
        kfEzqnt += kfEzqnt;
    }

    for (int nWjpzOz = 565127343; nWjpzOz > 0; nWjpzOz--) {
        SJgXEUJbmmdbeO = SJgXEUJbmmdbeO;
    }

    return SJgXEUJbmmdbeO;
}

bool hnkZfRMuEtWRQLGU::HYomWMMTLAQbL(int kVDTabBLbhhXqM, bool FGdZjhofsxR, bool QwIQggbM, double VhYRKVkuQFRdgEId)
{
    bool vkElIelX = false;
    bool brXfRrZeeD = true;
    double eCDDpL = 577212.6175178131;
    int UDyOEKGUqVoKyC = 722333169;
    double qTMDU = 907437.7849618102;
    bool isJQNzzBGHfpB = true;

    return isJQNzzBGHfpB;
}

int hnkZfRMuEtWRQLGU::xAwGOVUcVqfkNTc()
{
    bool HvzfJQHbf = true;
    double vjSldby = 1044853.3656611596;
    string fppjEuMUqQ = string("XgcNCCfMjkKrGWATZBeiIlDOuAzOSjEvPHDAoJxXlAzKHfsLvdJEvDfPUZHOOSyoVhyudeMwKQJXkmYPHvXkcjzvoICMkNtLCXsWelNecizQvqlPjeYiLVhHDFJvqIRqedPprsPLnGJEmEnWdnrVogsomisJOqUKgsy");
    int QOLtcFDxeECzlhAU = -1418874385;
    int OjobIeG = 1349367076;
    int paPXmGnJEUqM = -1241606593;
    string WIECCTOUGxNiIl = string("lnzobxKCKPRoCWwGnVwtWLEQffIEejhmOjuOkJBnzJqVjfKNqUkSRBaPdWtmZQkaeMvlfxdWZVfXuoKSQIjPoicLIYVzKAmVUXaDqzTsndeRLpzNdFILOVHeruKlkxNsFxconxoSdAHlzSmhDjVOysLHlZVovIRfVEvXhJycvnrPqJEhMqNjlXACEjETnZMEDFxsDggDNpbrJgmgFDqjlfKCdtNgEALiultocXvMMyXtXJ");
    bool jrhTICy = true;
    double UpxnmCkw = 48504.40161677873;
    string DIkLY = string("VVOODPCLYnWUnOMxoBFpznPpcwPsnwK");

    return paPXmGnJEUqM;
}

double hnkZfRMuEtWRQLGU::wbbnhkr()
{
    double UwQliSDCHpuJfLbW = 880053.2771553331;
    double RloCR = 224807.82526074693;
    double lOIaTLRyRRjoxAZ = 387429.3084175299;
    string dBqhUp = string("BTYWhamJduhutDlqTjydtXGpvkMqoQDQiWLdcfYgvqQwptLYQVwgJaLARAFfXImJTGbBQxPNaSnuolpGNhBCxOsDCaRnZcQk");

    for (int RovVuuHN = 308725693; RovVuuHN > 0; RovVuuHN--) {
        lOIaTLRyRRjoxAZ *= UwQliSDCHpuJfLbW;
    }

    if (RloCR == 387429.3084175299) {
        for (int RkncwYuSFifieLer = 2119489604; RkncwYuSFifieLer > 0; RkncwYuSFifieLer--) {
            RloCR *= lOIaTLRyRRjoxAZ;
            RloCR -= UwQliSDCHpuJfLbW;
        }
    }

    for (int QAXmD = 1024877991; QAXmD > 0; QAXmD--) {
        UwQliSDCHpuJfLbW /= RloCR;
    }

    if (lOIaTLRyRRjoxAZ != 880053.2771553331) {
        for (int ETnwd = 2130812788; ETnwd > 0; ETnwd--) {
            UwQliSDCHpuJfLbW -= UwQliSDCHpuJfLbW;
        }
    }

    for (int JHvvwJFn = 1356701100; JHvvwJFn > 0; JHvvwJFn--) {
        continue;
    }

    return lOIaTLRyRRjoxAZ;
}

bool hnkZfRMuEtWRQLGU::jzJmqYiNiyWZOfD(double XfBEACaFA)
{
    bool YFVRmiaGcSkS = false;
    double GOlTWt = -215238.1494486311;
    bool PbykXnPCsaVDVHvQ = true;
    double DWpBgptLfCyITI = -339439.0678825782;
    int szWXndP = -1187650368;
    bool fGNKInRf = false;
    double hwkfNdJQRCwd = -166096.32319923688;
    double KbPPvkTTtzj = 30698.647680816724;
    bool dcszQhObQIIiprTQ = true;

    if (dcszQhObQIIiprTQ == false) {
        for (int LXDooSzZyTWA = 755720656; LXDooSzZyTWA > 0; LXDooSzZyTWA--) {
            dcszQhObQIIiprTQ = ! dcszQhObQIIiprTQ;
        }
    }

    for (int ZbmhSVOOuqbaWE = 505405065; ZbmhSVOOuqbaWE > 0; ZbmhSVOOuqbaWE--) {
        KbPPvkTTtzj += KbPPvkTTtzj;
    }

    for (int YsuoDwwpUCcltRzm = 801589116; YsuoDwwpUCcltRzm > 0; YsuoDwwpUCcltRzm--) {
        continue;
    }

    return dcszQhObQIIiprTQ;
}

void hnkZfRMuEtWRQLGU::NdKXQRLfv(int PAHShiUM)
{
    int vONxXxOkfvSXx = 831991439;
    string mhxKMaUZPyHPq = string("XtHelwbQZodKDNBKsvyYtNSymPXWzKPodGFdWmSvCJxzGBBvFmBBOxlOMcuHesPMOVLgzubiHTjgJbGZVEOifkFOUvJNIjVInnyspsGeyKysGNBYqvAEUrcfpOQyFxTdvMekbOiWVjcuPZvmlAAAv");

    for (int pqYpXBEWhajEQ = 574160745; pqYpXBEWhajEQ > 0; pqYpXBEWhajEQ--) {
        mhxKMaUZPyHPq = mhxKMaUZPyHPq;
    }

    for (int ZUYLsUemIFEKlYke = 1577165490; ZUYLsUemIFEKlYke > 0; ZUYLsUemIFEKlYke--) {
        mhxKMaUZPyHPq += mhxKMaUZPyHPq;
        PAHShiUM += vONxXxOkfvSXx;
        PAHShiUM *= vONxXxOkfvSXx;
        vONxXxOkfvSXx -= vONxXxOkfvSXx;
        PAHShiUM /= vONxXxOkfvSXx;
        PAHShiUM -= vONxXxOkfvSXx;
        vONxXxOkfvSXx *= vONxXxOkfvSXx;
    }

    for (int thiZyPAUIqwqmDkk = 517249330; thiZyPAUIqwqmDkk > 0; thiZyPAUIqwqmDkk--) {
        PAHShiUM /= vONxXxOkfvSXx;
        PAHShiUM = PAHShiUM;
    }

    if (PAHShiUM == -747808942) {
        for (int LsgmVoR = 2127491968; LsgmVoR > 0; LsgmVoR--) {
            PAHShiUM += PAHShiUM;
            mhxKMaUZPyHPq = mhxKMaUZPyHPq;
            mhxKMaUZPyHPq = mhxKMaUZPyHPq;
            mhxKMaUZPyHPq += mhxKMaUZPyHPq;
        }
    }

    if (vONxXxOkfvSXx == 831991439) {
        for (int elPzZYOm = 801149952; elPzZYOm > 0; elPzZYOm--) {
            PAHShiUM = PAHShiUM;
            vONxXxOkfvSXx -= vONxXxOkfvSXx;
        }
    }

    for (int gsXzP = 385156870; gsXzP > 0; gsXzP--) {
        PAHShiUM += PAHShiUM;
        vONxXxOkfvSXx += vONxXxOkfvSXx;
        PAHShiUM /= PAHShiUM;
        PAHShiUM += vONxXxOkfvSXx;
    }
}

void hnkZfRMuEtWRQLGU::OClGCewOcibEf()
{
    double cShuXqXuxErijZb = 978406.8307719199;
    bool xwHVa = true;
    bool qbfQrNucsp = false;
    double NRnXeGjVXUo = 266543.51577308343;

    for (int wdOwla = 299848418; wdOwla > 0; wdOwla--) {
        NRnXeGjVXUo -= NRnXeGjVXUo;
        xwHVa = ! qbfQrNucsp;
        xwHVa = xwHVa;
        NRnXeGjVXUo -= NRnXeGjVXUo;
        cShuXqXuxErijZb = cShuXqXuxErijZb;
    }

    if (qbfQrNucsp == true) {
        for (int dXZcKxS = 1012661124; dXZcKxS > 0; dXZcKxS--) {
            qbfQrNucsp = ! qbfQrNucsp;
            cShuXqXuxErijZb += NRnXeGjVXUo;
            qbfQrNucsp = ! qbfQrNucsp;
            qbfQrNucsp = ! qbfQrNucsp;
        }
    }

    for (int bbCXNBHg = 1684333981; bbCXNBHg > 0; bbCXNBHg--) {
        xwHVa = ! xwHVa;
    }

    for (int WlkpiKKQJrCF = 1251184339; WlkpiKKQJrCF > 0; WlkpiKKQJrCF--) {
        cShuXqXuxErijZb += cShuXqXuxErijZb;
        cShuXqXuxErijZb += cShuXqXuxErijZb;
        xwHVa = ! xwHVa;
    }

    for (int qCvlojq = 349441307; qCvlojq > 0; qCvlojq--) {
        xwHVa = ! qbfQrNucsp;
        xwHVa = ! qbfQrNucsp;
        xwHVa = ! qbfQrNucsp;
        NRnXeGjVXUo /= cShuXqXuxErijZb;
        cShuXqXuxErijZb *= cShuXqXuxErijZb;
    }
}

hnkZfRMuEtWRQLGU::hnkZfRMuEtWRQLGU()
{
    this->hoNUraEMeeKRCD(string("nKiKjXfcCyciTWwFsTIKXpMPufpLpuVjiwjSPLYXeBNDeugEKmCsjAkbEHLFXJyPQWYhFWrTvUfkmdaMLKDhAwYYPuxJkWtLJrcZZCUMyUnHMywuSdUInCFoOpOkencjwwFsiLtjpfbLOYHHGJzHsYLjewfGWyTCSRwmNckbACmyBugPRKvcqiJrlABxIkwjnhzRlNgbCpCKoBySCgdxrPdiCQBAknsLreXRAidPMbjDGaZAXnAizD"));
    this->UfpeZgsRZbbcsF(string("DAVrABXIQbaPDYwAluaqnxzHGPZpQuzmwBbmPehuocmWIWRdHvKxgUkozsabjlPydFleKPlnMcWhzPEiRtmiGyKRYgleBGTelEKgbvDbaJOuzYfBMdyYHYvKpkMftEgtFCZHYHfEctdhGGXOvcGrESlBgwoWzTdwmmtNIOtbgshqjHKtmolAAVsRiaaaHelcsfulaXszHRzKBjvUqAtRUljLlrvYsEHqGHVwKtIUePsCL"), 1648225044, -1425351325, 969215.4529156002);
    this->iKMrT(208545849, -849145.5428484875, string("DKIuUUcCxQmzNMreyLJXvAyJdJzwGehaZASxSMeBlCjRabKYOKoXgQdGbBijhzFEaxpNgFEOqtvHVqttLUcJjqAZrczPGTFOelfSDTRQGcuHSDxCJjqSTiryZsb"));
    this->zcnAAeyFizsONCyP(-1732915723, string("AGQOxofhmThBGBSqkVThcbUuRFEMsvJVCmtnjWMFgfAnwFlFTUGSOagoulTJUYgskTKdATcnjvFFGOLRVUsQRbSyuArWWhXnAvsOFIIIiXbYeQKRSSqwyYOhCURwCNyRumpKnPXwXqBSchJKcIuN"), -1913396415, string("xNudlgGAYsuibbfiddxmRQMlNZcYyRJqdYXlMgCqcqmZXlkMkLItiXdfFXPFVDmDxHOSgrvQkoqQYGbUFFdNYHJcLPDwsNLrpuOZYIqLajbBugjCdITzABOZizHlXdIK"));
    this->UUIucXx();
    this->ctEjG(false, -1886641629, true, -1597490910, false);
    this->rOmpyQcSg();
    this->HYomWMMTLAQbL(-985669152, false, true, -461451.3241681641);
    this->xAwGOVUcVqfkNTc();
    this->wbbnhkr();
    this->jzJmqYiNiyWZOfD(56723.55338725107);
    this->NdKXQRLfv(-747808942);
    this->OClGCewOcibEf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jCBHjyWJqyTU
{
public:
    bool fjssV;

    jCBHjyWJqyTU();
    double pIEgHcJtmtDHxGO(string xGYIOsTZ, int GPkpMChXzkKaAbd, bool lDxDRBwjhs, bool lEoYTiHFciB, int tUvkSieOeS);
protected:
    int BhqDFJaODJ;
    double qZtTQqKKOkgBK;
    bool pqtSEbahxuLChi;
    string nxXHifNVe;
    bool HbzZgEGEKfZYNpod;
    int cYTSUTQpxhSboP;

private:
    int UNCZpHcQ;
    double yPjNAUyK;
    string hkijgzJWHJr;
    int SinoBgMq;
    bool CuGfjfFYkhF;

    double rNJUDXz(double ueuEHjlMOSGHUp, string EwMPiP, bool xzHOLcgqVSYc, int qlHSeEhDOmLz);
};

double jCBHjyWJqyTU::pIEgHcJtmtDHxGO(string xGYIOsTZ, int GPkpMChXzkKaAbd, bool lDxDRBwjhs, bool lEoYTiHFciB, int tUvkSieOeS)
{
    string FxIImCug = string("PERNzziEWBoSAztMslhtMDiefiPPjjIaoKaMWccEJTDPCARAHbIkUaCHGIkerQwcfGj");
    string ILbkaikfXQ = string("FjdpnxJrSyWhpwNJdLdsXoiwQuCiJWsAEcCtujHgdDIJgvBRpPAlRlSLRmgJHrjgyWriTVdDVaqfyuAPfoxBAGIDlvtLKk");
    int qGNAy = -1290129969;
    bool pRMYTN = true;
    string fTPBdjWfgdVwIa = string("XNGFiqlXgCggBRIHwujgJfJmnKXVIsKjOvXmPPrLYTcPPMvmxlhjjTJEAjKQwZKWZXtObIYCPQbuFdnglGtdOwrmIUChxHwQlzjrtwWHDGJWrIEOgMBXdqUNfu");
    int AEmVgvBalVIQUVU = -1635833085;
    int DsPakGa = -1127335177;
    string QWHTSdcJTqgmtYn = string("BUDvXecSIrLBbhzchXpUQPXXpCiiOUMZgzFwrKkuoLepSzdzqLGAxZmvPOXeENAPZDOMgUdJqaxnfBoAOTXoGNULglAOyMmErMNDoaJbuxkbyBgUFzJNLOxyrbGdTqLIZSVCWpWtwyzExpsZEAyKzKtHvoFaUYAoomuAMCsdjDRGoxJzLjFoyrrpTInrBjFaDQFDysYhiiiokDCqXAewRNdNiKuFfEQP");
    double WuQFUYjow = 557407.1099901281;

    for (int yqrHyVhGTJn = 1770127573; yqrHyVhGTJn > 0; yqrHyVhGTJn--) {
        QWHTSdcJTqgmtYn += ILbkaikfXQ;
    }

    return WuQFUYjow;
}

double jCBHjyWJqyTU::rNJUDXz(double ueuEHjlMOSGHUp, string EwMPiP, bool xzHOLcgqVSYc, int qlHSeEhDOmLz)
{
    int vDtnSNrvNizg = 462384359;

    for (int IevMn = 472897830; IevMn > 0; IevMn--) {
        qlHSeEhDOmLz = vDtnSNrvNizg;
    }

    if (xzHOLcgqVSYc == false) {
        for (int XmrjrRn = 1453284663; XmrjrRn > 0; XmrjrRn--) {
            continue;
        }
    }

    if (xzHOLcgqVSYc != false) {
        for (int aCPGZMZFwm = 1982632093; aCPGZMZFwm > 0; aCPGZMZFwm--) {
            continue;
        }
    }

    for (int hcTKVBn = 2116535561; hcTKVBn > 0; hcTKVBn--) {
        qlHSeEhDOmLz /= qlHSeEhDOmLz;
    }

    return ueuEHjlMOSGHUp;
}

jCBHjyWJqyTU::jCBHjyWJqyTU()
{
    this->pIEgHcJtmtDHxGO(string("zIXGPnXQTvdyZzGYgMcKEPqNHhnHnjDYmYnKKRAZWKXCyJOBFBaoRwWYiaTsejvblPPVGvUUHMegjQJaIivnhDyDpzmehIwavOGbSKPciGJhuAZCWTUPatRTEImDMlghjwxvci"), -807609224, false, false, 1654882961);
    this->rNJUDXz(-899409.0107930297, string("bjMDkefrmzBZPAOnYmclXAIKSXNxiwgxDzlQBQgQENVjAcZAtusrPVlWiFiuKouhQWIpcfGlGDYMCmMUzOLyBgEWLNLsmaWwOhqnqIWuZedMqYCtOarRFMgsYkODaCXQZDXzzSaPeabqUdYxOUqQVpgRIfZMBlQbxWjdGZnUrvyVnFsnrDYHyMVJWbogd"), false, 330665813);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hGgFAeNs
{
public:
    string TkWBfK;
    int ttJbLvkbTm;
    bool DLoYPuOQJaOv;
    double QpIfDMszHj;

    hGgFAeNs();
    void jXLkjVNwgPrHtt();
protected:
    int mPcRS;

    bool vSXgObsNfSvYi(double pJxXUDlL, string pAkdb);
    double YPEnvLAsh(double QOnhB, string bvsuscRblDzrtg, bool KSeYtHktUJ, int xksqrQahhXposzRG);
    double UcoomlzdsO();
    double TMpicOHQhjmH(string qNYByCPaFOZWlS, double nXUNaXjuqGoAO);
    int wOOpKjiY();
private:
    string iSLRKEGFGidsI;
    double VQxsnZfiDzOKa;
    string kgWqVYahzFCL;
    double JKAMM;
    string sdRIzaofNhLlNe;

    int yrWKyJojqV(int gOSIvRPIlTKEI, int EvWQHotSjAU);
    void slHGTbmggx();
    bool XFZKzrCcT();
    bool XpvygXt(bool xNsbGBFRR, int GIeRo, int OxcbYYk, bool esvbD);
    double PcwnTo();
};

void hGgFAeNs::jXLkjVNwgPrHtt()
{
    bool mhqjJZuCthFTYKKn = true;
    double HEPeIaLXvBAM = 1032716.8224125494;
    double xGErAnpKeUD = 910415.3493058599;
    double YKlYWFRyBWYMn = 305427.69543185615;
    double GnbprAGHppdLHTk = -940470.5149853047;
    string UEnWV = string("XewodPCLgmQqXRAMhDzwniAVNTOrGIDHuAkREsHmgHxZBaLCaNDjnkdtfLtTZOdqzPHjsZBfrElqEGmRnHufuDacujvFeBYwVmuhBQNipqOBsdMZfQxgKFFT");
    double JxhchlTDWsezkP = 214572.09772908414;
    string CdkflwqIsuV = string("RHqENxumbgTillieNDu");
    int hIOzQUVnMFE = -821438968;

    for (int RhyUFtdyM = 491719380; RhyUFtdyM > 0; RhyUFtdyM--) {
        xGErAnpKeUD *= JxhchlTDWsezkP;
    }

    for (int UpJmiD = 1667276144; UpJmiD > 0; UpJmiD--) {
        JxhchlTDWsezkP -= xGErAnpKeUD;
        UEnWV = CdkflwqIsuV;
        HEPeIaLXvBAM *= GnbprAGHppdLHTk;
        HEPeIaLXvBAM -= GnbprAGHppdLHTk;
    }

    for (int iHrzx = 562822968; iHrzx > 0; iHrzx--) {
        continue;
    }

    if (JxhchlTDWsezkP == 1032716.8224125494) {
        for (int mOHodywdP = 1319028502; mOHodywdP > 0; mOHodywdP--) {
            UEnWV = CdkflwqIsuV;
        }
    }
}

bool hGgFAeNs::vSXgObsNfSvYi(double pJxXUDlL, string pAkdb)
{
    int TUnntMHSbarEcpmq = -2133359595;
    double PUfBCPzGT = 106760.03045256254;

    for (int SvWLyvmUGKRRPshe = 1827319856; SvWLyvmUGKRRPshe > 0; SvWLyvmUGKRRPshe--) {
        pAkdb += pAkdb;
        PUfBCPzGT += pJxXUDlL;
    }

    if (pJxXUDlL < -937438.2425910739) {
        for (int xjPdddsKws = 398062229; xjPdddsKws > 0; xjPdddsKws--) {
            continue;
        }
    }

    return false;
}

double hGgFAeNs::YPEnvLAsh(double QOnhB, string bvsuscRblDzrtg, bool KSeYtHktUJ, int xksqrQahhXposzRG)
{
    bool PncyEofHmkeBb = false;
    double ErLNXl = 51712.588439287305;

    for (int XAaAimPORCMx = 1202464852; XAaAimPORCMx > 0; XAaAimPORCMx--) {
        bvsuscRblDzrtg = bvsuscRblDzrtg;
        PncyEofHmkeBb = KSeYtHktUJ;
    }

    return ErLNXl;
}

double hGgFAeNs::UcoomlzdsO()
{
    int zjWYtwcQxgEB = -1887424454;
    double NsRhouhWnx = -869742.6347922797;
    double UdxtLY = 622049.0358748527;
    bool NSFBziQwqRUVAbCF = false;
    double mheAjZl = 289653.92325235467;

    return mheAjZl;
}

double hGgFAeNs::TMpicOHQhjmH(string qNYByCPaFOZWlS, double nXUNaXjuqGoAO)
{
    int DEckd = 383261010;
    string riiOj = string("BRWykfauMJpVAeOMqswEdBhytceFwvrPGCBTEcLaLkkiFuaXqMQEkBNArMGWnIrvaBDYPsOuzVMgUvxKzYpyJTpPxCgtnONrovFOooIdkhQlYzsUqcbnbOkJiuaUSmYOMIMhGIEVRRRXYDsJoCmXAzdpkCcZggEePxxrkQPMBZBfOfiAlYzHBwSXGgGJvLQGbnCkHPMWfLmuMqfvZzdJhEYJedHP");
    bool qcjmKyPyLazV = false;
    bool YrxyCudalXCRoO = true;
    bool txnfe = false;
    int SCHRBpNlbKBya = 298009693;
    bool juXplNvbzixUTuyR = true;
    int HcSdbmmFAtF = -2026609613;
    bool axiaguFlIohYz = true;
    bool kysHESRfDZ = false;

    return nXUNaXjuqGoAO;
}

int hGgFAeNs::wOOpKjiY()
{
    bool Iwakfunua = false;
    int ACFmakkptBZIk = 384181723;
    int NSWqtrqHn = 1951424038;
    int BLddXFhiZcolnpGo = 528355335;

    return BLddXFhiZcolnpGo;
}

int hGgFAeNs::yrWKyJojqV(int gOSIvRPIlTKEI, int EvWQHotSjAU)
{
    double xJIyIjVUCBviPCIW = 819798.0990199574;
    int LSUHdUT = -1355215699;
    string UlSyVzGEpOSSoy = string("AdisZrStltUASADUYeeqJyqKBOsNoYxBUivGtTpbgUaXoKJotzfftLhjzSalPutgAfbCLOiZkiRUUgwbNSeqzbsQHfbRwHCOLSnYaHrVgJuHmtLBIxgtpKpXjMBZRjBbdjjTolFvdNEMotUZpkQnJTdeNlaZZSMO");
    int uagdUiMqJAIElkx = -393311823;
    int lxmcanehe = 936576155;

    return lxmcanehe;
}

void hGgFAeNs::slHGTbmggx()
{
    int XyNakvRYNJMiI = 1245845767;
    int CfkVViBHs = 515537385;
    double gGYONSkL = -157898.51380104077;
    int aUNim = 1464681865;
    double wlTrVnoAVTvi = -450110.8560756419;
    double uJbbluwjPwGDnH = -38847.33533600231;

    if (uJbbluwjPwGDnH < -157898.51380104077) {
        for (int XtKQksw = 680420019; XtKQksw > 0; XtKQksw--) {
            uJbbluwjPwGDnH = uJbbluwjPwGDnH;
        }
    }

    if (wlTrVnoAVTvi <= -157898.51380104077) {
        for (int VnTsSu = 1901678180; VnTsSu > 0; VnTsSu--) {
            uJbbluwjPwGDnH *= uJbbluwjPwGDnH;
        }
    }

    for (int yLFLnHSwclJCXg = 221515523; yLFLnHSwclJCXg > 0; yLFLnHSwclJCXg--) {
        uJbbluwjPwGDnH *= gGYONSkL;
    }
}

bool hGgFAeNs::XFZKzrCcT()
{
    string THnliFY = string("qnZZvuhtOXCTprvCVnxtQfWZVwklhycGjFuEcGDCZxOdPieVSQHNjferpWOoAcnmvxLvjilugXXMgMAZCztimVUqtdXqkorMnFaDlzsuSVGlvkatkhIvXWPJotYnbwatJYWWKVXwlHxgMaQHKYlIIYWOCGXnnfwfGWwkoeLoRqVtmjOqjnzBdbfmlbDm");
    int pJEMMQMVInNWrDaZ = 1516527620;
    bool HpTgIEpSpwqKDR = false;
    double QyMEnk = -823464.7254651436;
    bool LzhHgPKqiL = true;

    if (pJEMMQMVInNWrDaZ > 1516527620) {
        for (int fxIHN = 1160833905; fxIHN > 0; fxIHN--) {
            continue;
        }
    }

    for (int HiJeUrg = 710057617; HiJeUrg > 0; HiJeUrg--) {
        HpTgIEpSpwqKDR = LzhHgPKqiL;
    }

    for (int YcSHhBGXiffgkg = 1847453792; YcSHhBGXiffgkg > 0; YcSHhBGXiffgkg--) {
        continue;
    }

    if (THnliFY <= string("qnZZvuhtOXCTprvCVnxtQfWZVwklhycGjFuEcGDCZxOdPieVSQHNjferpWOoAcnmvxLvjilugXXMgMAZCztimVUqtdXqkorMnFaDlzsuSVGlvkatkhIvXWPJotYnbwatJYWWKVXwlHxgMaQHKYlIIYWOCGXnnfwfGWwkoeLoRqVtmjOqjnzBdbfmlbDm")) {
        for (int mZNORadcKrkGw = 1280605117; mZNORadcKrkGw > 0; mZNORadcKrkGw--) {
            QyMEnk -= QyMEnk;
            HpTgIEpSpwqKDR = ! LzhHgPKqiL;
            QyMEnk += QyMEnk;
        }
    }

    for (int mYyDCjOMyFQok = 1065234372; mYyDCjOMyFQok > 0; mYyDCjOMyFQok--) {
        pJEMMQMVInNWrDaZ /= pJEMMQMVInNWrDaZ;
    }

    return LzhHgPKqiL;
}

bool hGgFAeNs::XpvygXt(bool xNsbGBFRR, int GIeRo, int OxcbYYk, bool esvbD)
{
    int NrfmVlUpcHjdckZo = -1851211543;
    string eGgHdJYfuqPgX = string("kTRvbMhhzytLIqKHrBsSnEYzNvxQWrnoJtjdCPYlfeyVOozgocPAVHDhfJMkGQOOtyxOGMorWdFbWLVMfzzvEpzOQMSbZezHotfLbtkecPNcKjIMthrckrVMRMAaJCSfOqzaouDUyJgfuIFMQexzxmeTHmTAQUPYTmrkoVRXOTprfRfPnKFOevQsLuZVsYDmQKUkfomKmCKJGoxHdcpSRPyuXKdnQUVhJWZgxp");
    double NYZuGVrRE = 295162.14349341666;

    for (int WunbxJcnYw = 340531749; WunbxJcnYw > 0; WunbxJcnYw--) {
        xNsbGBFRR = ! xNsbGBFRR;
        OxcbYYk = NrfmVlUpcHjdckZo;
    }

    return esvbD;
}

double hGgFAeNs::PcwnTo()
{
    double xHOuBUVuvvy = -407380.665486753;
    int nQmfkDfFLO = -939501956;
    bool KGuWed = true;
    string QcZHm = string("efXSgXxCRVKNzIJaAxlhJeABjXNKQtKhBuZtVdugkclwBjkpUuanEirMAseSSstusXtYvOQjmSGrbvjGrrfbvJBsaYjhTcbGpTjlALzSkdYYExRBJlXvoq");
    int CCaeGziyBdwDgxHh = -1414360953;
    int tpwloC = 1671119978;
    string IXydj = string("MMfOvaWsQPuNMJWUUCQJnQLDwSukCQrwSWpBIOkhVthQSfYOTaEQGPzgzHbRzNWMdxFRjJKBDcEWvbTLpXHPsqSeERjFSBSkGFOrJmxPpNxpEjcGkiPVeLfTqJdhVXLQNnApzWDBXXfpYunqkLTbvQXTUvflFxeecOOlqnZOWZQGmbXfTkhOFhEwYlTCPZXCCBjmCjYqcrRjXYAHCYWdA");
    bool obgJLtDVaUtrj = true;

    return xHOuBUVuvvy;
}

hGgFAeNs::hGgFAeNs()
{
    this->jXLkjVNwgPrHtt();
    this->vSXgObsNfSvYi(-937438.2425910739, string("DlYKxjvJpAkPoylmXIBnYApGvzzljZUHFRaNtfZpqoOfERHcYcqlnhMXUSVNRauDuOqbnqJPMwNewPrLIvPtIwvqdoFItShuOyAkhldIADMIQxIgtKdRZTEUCuPZUIeUJMgaBjHVwzLpTYlxwREqZAPRboihvztauUZmSHM"));
    this->YPEnvLAsh(-535276.1662199986, string("soveuXqEkGZiAntUtSbHwlslzgISfsJQoFaJanfkfOVERrxbXsBfeSNsVtWmDVyshsqiCCIhvESAryhLJYoMmOBCCEwnejHEgYfsuDiJToOPKoOmYzvYJrZxayNwyckDSFScTIzYZzdhkaKyAKWBqGarkaMuyutVJXAAqFVodNaKyQEAgHpJLAoBrAGFOtHkiUuwrOtPaVHYdfSBXcmCQDjb"), true, -191417841);
    this->UcoomlzdsO();
    this->TMpicOHQhjmH(string("zpPLoMFq"), -608341.3120679805);
    this->wOOpKjiY();
    this->yrWKyJojqV(-1611017083, 1192561644);
    this->slHGTbmggx();
    this->XFZKzrCcT();
    this->XpvygXt(false, 1564461604, 1866543614, false);
    this->PcwnTo();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GNIMiQrvTC
{
public:
    double FsKzrbWuw;

    GNIMiQrvTC();
    bool vOMxTixDSvhE();
    string uIjNF(string wtcyYOhnjPuxac, string YMnoSuKkjuUign, double iGLZPTlA, string BCbnRLfd);
    string UKJpE(bool ePiNp, bool OlXZupfSVQ, double zeGcPVgOee, string fHPDLxqTsNHmdsUz);
    string MSizj(bool mNNfAEE, string VxEBG, double ZofEXWroJrLt, double kQYnpNYhwXHQyg);
protected:
    string rKpRnYGXJKsdypse;

    string SpApeEqbuNyMK(string cqgQjkUvRZu, int ruIVfJZXhDo, bool yWFsdnKaponoPN, int PjfgUqHlnaJwF, double lxtwWx);
    bool yLbMyeiN(bool TxmTh, int mqMrqZSVqFiX, string rIsrJXJuTWadVu, string xGQcWQJ);
    bool UOBMXwbIICMqDfkK();
    string ssgoYVNxdjulQQbq(double UjJjeDxpYpVDEyus, double sbuBjjkpwwWRmL, double ZAPLt, bool hpXwpWCzzkb);
    bool mkgffGtPIGsB(string TLaOAQBSZamX, string AdLpbawMkNeEWHtz, int LTyadSDKwkH, int etOePqnTZKca, string WFqfCl);
    double bHOhHPemhWz(double OhQqmfNTnJfmd, double Sjsabco, int ybYgrNIvqqbg, int AuUnlkIWjQrda, string ejNoDF);
    int daFylCa(double RUjcBt, string xwVaQUyNbypf, string jiBZXPKIeeKQnOz, bool WMacsWWmere);
    int IvsCXz();
private:
    string ylIDVpWK;

    string hBpHTQLIWmUwCbyQ(string oPIlEEeQdlqbOZp);
    int yFTKAoVzEFc(string LiZnJWJYGeu, double IZbCeKKc, bool WzsAQWCzKt, double gJiIdjf, bool XLmKAIHlA);
};

bool GNIMiQrvTC::vOMxTixDSvhE()
{
    double QHHWLBYmrgXPmzoE = 910636.9273369776;
    string vrTDXijmgLWAdXTO = string("agYpHhczqcZnXTnlaQAuFjDtxaDYnHTooNZHjVuXnoFlVGMiBHRviXTUvxylnrmsuJTf");
    double ShhFzRXwv = -248049.50607417536;
    string tZEkDdk = string("pGqTpYUOFyjmaALlhVaCHXOWsxJKSlHiyEwtCJxouJuHrZkCoDNZYinrBTnTzFVfYoYsqkhILHZXDIschwMYmyeRaNOnFBtIHwacWTIqkDFbiXHggO");
    int nwwsCEN = 1752506767;
    string HDssQu = string("iBJKCZqePAkgHxGrpdmCmkSGwDzmpvadslHjDlhLhvJUJfxDTFemlkmLvhJBBOCsYriWOxaGlKSlWKVADBglfbTjRLesAiGNBPujkjgthIbHNWjwwynVaoPNschNhlfWFEORDYVLyIleYpCMLZxhfWNqpiQrjlfQYBiBsuOcFOIItgVlohkWzpCHbnliUYGdteSCdQuYzLupobemYEUGFkXRUnlBmbOUoMXNKcDucEhBczAPR");
    string SVPSwEQXZL = string("zepISvRPZQQPtmFJCVGPhSqtkpkHqrsOfZCIuapqdfGcnFdijyaxxiymegHXiCMkOatdTsWIUNYTIzjjTlnGuwqzdrNumamLqzuynWwgVHiQEuuRilhBexFPfBdZLDYyJHSdDxgAtoLXpi");
    string KZOVDDN = string("MVffupwGKdMULAaXUfuZksqzkSNwigPNnnfTHiXOWIehAZkdPdWtFsyUaJlfQrOmybRMFZtejuvqNjJXKMDbBddphlqXetELBAIAtRGiwfUZjlwgOfsqipTdqmXdlPtWUPtRUFbxuxmsqcgfeFxVjucWKutGQJCYYssdfIAngbHkqPhDKdPxTpXIYjgimqwTkzuJiXwNHgrukQeInElwcWWhQodTWXpHhuAWvCnHaiPy");
    int evGhZse = 635755966;

    for (int xrWNuSvFWoNw = 2109250398; xrWNuSvFWoNw > 0; xrWNuSvFWoNw--) {
        KZOVDDN = HDssQu;
        SVPSwEQXZL += HDssQu;
    }

    return true;
}

string GNIMiQrvTC::uIjNF(string wtcyYOhnjPuxac, string YMnoSuKkjuUign, double iGLZPTlA, string BCbnRLfd)
{
    bool LndyjxzqHGFcfMna = true;
    double keUCkt = 497174.8427109757;
    string XLkUudbKLMD = string("qtwvhEqBWkEXwrZyRLxVBYDFdyPewAXqVdMKgLyaRDxDWUvghnYeXFVpsBoSHfYccJbtjENkAnSWwlhILINYKUpuQbMLDabMJRThbXQNCOBTYbaBjFHISSXaCEusI");
    bool UBaAsg = true;

    if (YMnoSuKkjuUign > string("ZMqdD")) {
        for (int tlWmVtWkXX = 2106978617; tlWmVtWkXX > 0; tlWmVtWkXX--) {
            YMnoSuKkjuUign = BCbnRLfd;
            LndyjxzqHGFcfMna = LndyjxzqHGFcfMna;
        }
    }

    for (int WFvzDfNCnq = 2133185228; WFvzDfNCnq > 0; WFvzDfNCnq--) {
        XLkUudbKLMD += YMnoSuKkjuUign;
    }

    return XLkUudbKLMD;
}

string GNIMiQrvTC::UKJpE(bool ePiNp, bool OlXZupfSVQ, double zeGcPVgOee, string fHPDLxqTsNHmdsUz)
{
    double zNIwAtyd = 175347.04499165816;
    double FHFlP = -616804.5794218243;
    double hYZPUkYtgSR = 1007562.7642548755;
    int rEFohMMuGXaDNyGy = -1570874750;
    double aYdgXQoPeGfc = -943887.3956196035;
    bool pVYaNB = true;
    int lpXXJpRye = 1031937517;

    for (int cDGyjExR = 1087925598; cDGyjExR > 0; cDGyjExR--) {
        hYZPUkYtgSR += aYdgXQoPeGfc;
        lpXXJpRye += rEFohMMuGXaDNyGy;
    }

    return fHPDLxqTsNHmdsUz;
}

string GNIMiQrvTC::MSizj(bool mNNfAEE, string VxEBG, double ZofEXWroJrLt, double kQYnpNYhwXHQyg)
{
    double tqviyDVGaMrm = 28146.57640593788;
    bool AQzTt = true;
    int UsYNlwfK = 1042509672;
    double kDcXsB = -84808.08701787554;
    string viiXT = string("IjIFQQreSOLLgYfFDjGowhcVwlOuBDJZLbAeocdWczYsaqXqezVfjGBcaqvrgTivlY");
    string FAoIwjcKzPZwMmPA = string("ARQlZqRJzbGpfbxZporJqudkWVTzPxEQqYQUgziiRTPWBTmIFO");

    if (FAoIwjcKzPZwMmPA < string("ARQlZqRJzbGpfbxZporJqudkWVTzPxEQqYQUgziiRTPWBTmIFO")) {
        for (int jXcGFWugmtctpt = 774938629; jXcGFWugmtctpt > 0; jXcGFWugmtctpt--) {
            kQYnpNYhwXHQyg /= kDcXsB;
            AQzTt = AQzTt;
            kDcXsB -= ZofEXWroJrLt;
        }
    }

    for (int GBdGtAFwGUwOO = 1726172584; GBdGtAFwGUwOO > 0; GBdGtAFwGUwOO--) {
        tqviyDVGaMrm /= kQYnpNYhwXHQyg;
        viiXT = FAoIwjcKzPZwMmPA;
    }

    for (int dCIsMCkYbgh = 2119068738; dCIsMCkYbgh > 0; dCIsMCkYbgh--) {
        continue;
    }

    return FAoIwjcKzPZwMmPA;
}

string GNIMiQrvTC::SpApeEqbuNyMK(string cqgQjkUvRZu, int ruIVfJZXhDo, bool yWFsdnKaponoPN, int PjfgUqHlnaJwF, double lxtwWx)
{
    double boBfW = -469954.53293845954;
    string THyufwNE = string("HGGBAiCn");
    string cDesiaItTnXtUaKT = string("VKtdYAnhsllmpUOFwztnXRusGfLXfMcqlfCGAQAdGvdqdzFpqBSYem");

    for (int opgRYwAM = 826522817; opgRYwAM > 0; opgRYwAM--) {
        continue;
    }

    return cDesiaItTnXtUaKT;
}

bool GNIMiQrvTC::yLbMyeiN(bool TxmTh, int mqMrqZSVqFiX, string rIsrJXJuTWadVu, string xGQcWQJ)
{
    string XgSASnTy = string("sryoFBkWsWiHxsTolZohvQXpJzkuMjWcNMwYWolEXDcMSQUQLWYpSZXuRIvwRNMDaUMMRQXZQGuUegShsqbmBXz");
    bool MLYpcTvZQfrWLJpf = false;
    bool abJTVZ = true;
    double lfTmzNUPvODur = 479984.3810531465;
    bool oWwkIX = true;
    bool LKgTUfGk = false;
    bool xyMkYolgNPp = true;
    int kWpVELs = 839864346;

    return xyMkYolgNPp;
}

bool GNIMiQrvTC::UOBMXwbIICMqDfkK()
{
    bool VSTAc = true;
    string YZalYZfYjsd = string("vDVfAgNsPgScGRJLnCoQATgnhSlLXuZercHQieiBagGExAAcdzVCmHwZGfLKbHXsEKeURKiJHrNPOLNwvXSGaeFnLbMHgjeCeGPWYEjSTzknlwBqYmHDmpaCOHEeQzmgBTejOuILlgLYKmRnxZUcHOOyLujQBWkKDbkEDXofyBwmyUqVveZifAJ");
    int tUCqAjRTOEefOSAq = 1510130929;

    if (YZalYZfYjsd == string("vDVfAgNsPgScGRJLnCoQATgnhSlLXuZercHQieiBagGExAAcdzVCmHwZGfLKbHXsEKeURKiJHrNPOLNwvXSGaeFnLbMHgjeCeGPWYEjSTzknlwBqYmHDmpaCOHEeQzmgBTejOuILlgLYKmRnxZUcHOOyLujQBWkKDbkEDXofyBwmyUqVveZifAJ")) {
        for (int lSaOANhHeQUiIp = 277947502; lSaOANhHeQUiIp > 0; lSaOANhHeQUiIp--) {
            VSTAc = ! VSTAc;
        }
    }

    for (int JWQHIk = 1131325821; JWQHIk > 0; JWQHIk--) {
        continue;
    }

    if (YZalYZfYjsd == string("vDVfAgNsPgScGRJLnCoQATgnhSlLXuZercHQieiBagGExAAcdzVCmHwZGfLKbHXsEKeURKiJHrNPOLNwvXSGaeFnLbMHgjeCeGPWYEjSTzknlwBqYmHDmpaCOHEeQzmgBTejOuILlgLYKmRnxZUcHOOyLujQBWkKDbkEDXofyBwmyUqVveZifAJ")) {
        for (int ECgUXAlVLMpc = 838296277; ECgUXAlVLMpc > 0; ECgUXAlVLMpc--) {
            continue;
        }
    }

    if (tUCqAjRTOEefOSAq <= 1510130929) {
        for (int VLmDdsLwWohS = 1784826545; VLmDdsLwWohS > 0; VLmDdsLwWohS--) {
            tUCqAjRTOEefOSAq = tUCqAjRTOEefOSAq;
        }
    }

    return VSTAc;
}

string GNIMiQrvTC::ssgoYVNxdjulQQbq(double UjJjeDxpYpVDEyus, double sbuBjjkpwwWRmL, double ZAPLt, bool hpXwpWCzzkb)
{
    bool fWyeiMJwa = false;
    double ydqWrZSDFlWiRs = 33780.430055823024;
    double PBWyQUXiFtjgrlvP = -197499.94236162043;
    string ZJdBIgwcf = string("EVjfTpcFLlC");
    bool XmeiqbCQ = false;
    int FfPJVGiWFzMlE = 1182851412;
    bool aidnHiKIbRJD = false;
    string MxYUSSzifYE = string("NhjuQFTLEREzWpCQGLgcLrAXlsuYdudvkdqAg");
    bool xGItVlUZolIXcaZ = true;
    string wExNLGagl = string("hcjLHqISwjgjVrWrjXvMFScPlfqcSJfewArXcDIpnNnTNafNqnvgtVSiEUiuXBGlzBxJMCPQpFuYdMACPQrD");

    for (int EJKYzurwrXCp = 403891510; EJKYzurwrXCp > 0; EJKYzurwrXCp--) {
        ydqWrZSDFlWiRs = PBWyQUXiFtjgrlvP;
        aidnHiKIbRJD = ! xGItVlUZolIXcaZ;
    }

    for (int ndGWQABnJH = 194972218; ndGWQABnJH > 0; ndGWQABnJH--) {
        sbuBjjkpwwWRmL -= ZAPLt;
        XmeiqbCQ = ! xGItVlUZolIXcaZ;
        ZJdBIgwcf = ZJdBIgwcf;
    }

    for (int yVtNlqvStlrgDiP = 98527567; yVtNlqvStlrgDiP > 0; yVtNlqvStlrgDiP--) {
        MxYUSSzifYE = MxYUSSzifYE;
        fWyeiMJwa = ! hpXwpWCzzkb;
    }

    if (UjJjeDxpYpVDEyus != 933328.6746043493) {
        for (int ywTzntflIIFFI = 403571832; ywTzntflIIFFI > 0; ywTzntflIIFFI--) {
            continue;
        }
    }

    for (int erouUwthg = 1471643096; erouUwthg > 0; erouUwthg--) {
        continue;
    }

    return wExNLGagl;
}

bool GNIMiQrvTC::mkgffGtPIGsB(string TLaOAQBSZamX, string AdLpbawMkNeEWHtz, int LTyadSDKwkH, int etOePqnTZKca, string WFqfCl)
{
    double ofzifthJEFSu = 427320.201004396;
    int RwmGywbnWmoMBruM = 2072705734;
    string nASCItAEeXUw = string("Y");
    double eFyCsJc = -560166.7688806439;
    string gRwJdwKnbOeEu = string("CdBWWQqzdkCqyBMsOVienjSQHEdxFyrnRvogDYqSEswqNGzLYPhQnuBdlXvgfbqDxnGgewQjQZkoJvWTRcvaELbmshRaAykXYkvTnrUqNamhkQtRPYJhdqZVEBePCPoMRucJHtKJnHHvwxCdgvkbNqxtIRNTOznNFcuRYPceWPveHGjiwuqGwJC");
    double OUnVomrDoDyxU = -871382.5991840813;

    for (int IJlMkVu = 1050232202; IJlMkVu > 0; IJlMkVu--) {
        nASCItAEeXUw += gRwJdwKnbOeEu;
        ofzifthJEFSu -= eFyCsJc;
        TLaOAQBSZamX = WFqfCl;
    }

    return false;
}

double GNIMiQrvTC::bHOhHPemhWz(double OhQqmfNTnJfmd, double Sjsabco, int ybYgrNIvqqbg, int AuUnlkIWjQrda, string ejNoDF)
{
    string ofwpguX = string("aMtRNqkgFIVbXgFZumsowSrxjdnWFGYAorbdYxlG");
    double wQHxYDMhjpDigU = -340598.94275632;
    int VOdSY = -1857105813;
    bool NgNGnOTR = true;
    double GrNhcqWvDo = -309660.2626416152;
    string CiWYcADgLAEGbPO = string("ZwdIwD");
    int VjOutKicnVD = -1294934488;
    string ElamiszQYIvLs = string("aYPWtJljEhGcdcUrFiFkawRZMNzeBQBmNlAhgJTCQYobkfFSOpKTDboMngPmeUuVLygrIcAFcwFCNpzIbeIKSLXlPIOWMxjVcGGyPZPpYLsaSwusv");
    double rDrymrGfNQwF = -100765.49436041864;
    int NgpqTeTFUzp = 1215215233;

    for (int reJWYqQcjO = 1310742643; reJWYqQcjO > 0; reJWYqQcjO--) {
        VOdSY += VjOutKicnVD;
    }

    return rDrymrGfNQwF;
}

int GNIMiQrvTC::daFylCa(double RUjcBt, string xwVaQUyNbypf, string jiBZXPKIeeKQnOz, bool WMacsWWmere)
{
    int DGKxnvqOJK = 575344295;
    string WXdcMaVrbUlTeFTl = string("YKSwUEguIvUwOUEFGtbsKyRscptqHSCzWZccjZqfWphwzjzUtVKnVgevAZEFxnLuCsbpBkNxeRneufwfUfoGbPOKfPZLyGkMypvdyQVNBxQBUBhjRFnxXrXWJvBrjGWgrbbZhWepJkBhiEgUxEcqrFFcqgADnKlLezdydXNcsvEnHfSfJcjNRsi");
    int RitetthKpLevs = 937790087;
    string IXNbkCT = string("sZszqmIkGosoreyCwMpDCXIuciCuWOLEAgZBIZLVNXMtxKPtVNrNNTbvuflNhguujWNBvRerIjKLkbWQvGwiYUBCfXVrglSncmutFcasbrXJnkqpcJXviRsQHHzYwmdkapjXpGyAbhhMIzUlusxhkUnnYkWIdnPGOKNcaraEDlVfQBowCIBxDQATgRyAVQvJmhJORDasygFdQt");
    double eahXgY = -1012433.3390253581;

    for (int encpDdYlDj = 1123934175; encpDdYlDj > 0; encpDdYlDj--) {
        DGKxnvqOJK += RitetthKpLevs;
        eahXgY *= RUjcBt;
        jiBZXPKIeeKQnOz += jiBZXPKIeeKQnOz;
    }

    return RitetthKpLevs;
}

int GNIMiQrvTC::IvsCXz()
{
    int jyoWxrEFwGlBUVDz = 799892012;
    double GujurUrmvuKv = 345543.24880356033;
    string JLYyetDSpWgPax = string("bNfLBznnPAeNZABVXijXJFZKaexpebvwCnoeTRJUOnLlpDQDUWGOaJorFMvcYqCcRDahfXyBmzqcNcLtajeKbzFSzpxJSJftjgIdjWysVPHmcPieQKhKMZSLjAWoGNvEuAUPlMrXflVwblpsvcDFEkQUaOfHOOXyFuezqBoPpYQgXgIiZBiVmCNvGsFSVezCaKBUUulxmtnSgMQRMeDJLKqxUJCCFSvmKYtQ");
    bool dgnWZDBBdtLlD = true;

    if (GujurUrmvuKv >= 345543.24880356033) {
        for (int UBUNmngodbA = 1279313004; UBUNmngodbA > 0; UBUNmngodbA--) {
            continue;
        }
    }

    for (int mqEAPPsRR = 1597336315; mqEAPPsRR > 0; mqEAPPsRR--) {
        dgnWZDBBdtLlD = ! dgnWZDBBdtLlD;
    }

    for (int ICwNJcQvskordAni = 2137856866; ICwNJcQvskordAni > 0; ICwNJcQvskordAni--) {
        GujurUrmvuKv /= GujurUrmvuKv;
    }

    for (int CDjBcopQWNK = 1064929549; CDjBcopQWNK > 0; CDjBcopQWNK--) {
        continue;
    }

    return jyoWxrEFwGlBUVDz;
}

string GNIMiQrvTC::hBpHTQLIWmUwCbyQ(string oPIlEEeQdlqbOZp)
{
    double jbIPhQPXRo = 658914.8359983199;

    if (jbIPhQPXRo == 658914.8359983199) {
        for (int dzSHrvXFWHQI = 1723912652; dzSHrvXFWHQI > 0; dzSHrvXFWHQI--) {
            oPIlEEeQdlqbOZp += oPIlEEeQdlqbOZp;
            oPIlEEeQdlqbOZp += oPIlEEeQdlqbOZp;
            jbIPhQPXRo -= jbIPhQPXRo;
            jbIPhQPXRo -= jbIPhQPXRo;
            jbIPhQPXRo -= jbIPhQPXRo;
            oPIlEEeQdlqbOZp = oPIlEEeQdlqbOZp;
        }
    }

    return oPIlEEeQdlqbOZp;
}

int GNIMiQrvTC::yFTKAoVzEFc(string LiZnJWJYGeu, double IZbCeKKc, bool WzsAQWCzKt, double gJiIdjf, bool XLmKAIHlA)
{
    int mTWSCMtBlnoPx = -549386913;
    bool ZynJR = true;
    double BqDgrQzLZbUcfS = -206786.88199356952;

    for (int EkOFMOERvlz = 1910394549; EkOFMOERvlz > 0; EkOFMOERvlz--) {
        continue;
    }

    for (int RFmNwjtpxf = 1046594551; RFmNwjtpxf > 0; RFmNwjtpxf--) {
        mTWSCMtBlnoPx -= mTWSCMtBlnoPx;
    }

    if (ZynJR == false) {
        for (int WVNeqeerEF = 523258880; WVNeqeerEF > 0; WVNeqeerEF--) {
            continue;
        }
    }

    if (gJiIdjf < 918123.0626709961) {
        for (int BxcidQTkhKEnzb = 1294099911; BxcidQTkhKEnzb > 0; BxcidQTkhKEnzb--) {
            BqDgrQzLZbUcfS /= gJiIdjf;
        }
    }

    return mTWSCMtBlnoPx;
}

GNIMiQrvTC::GNIMiQrvTC()
{
    this->vOMxTixDSvhE();
    this->uIjNF(string("CaEGwukqFzHEztywmvTGSLpHSHnDvLCZdCBACavwEVOidynl"), string("MexYMxwXCaUtvxWNCjClf"), -305893.05490136833, string("ZMqdD"));
    this->UKJpE(false, true, 682867.9870682078, string("ynUrILKJfdHtLRTGRuUWmZHfjbaTWanutgNUcLmqUYWdGYWOpeivuLVBureDuLNvtubOLlxLNPlUQPhnhoyFgjNsdSipAPaYHqSdndrRmFCfKHjgFSDqyrdQSTEvxibujKURBqcNbIqjXVYEzkQDvSejBeUNvKAlKIGzjThCLEZbsslhAVYATpRm"));
    this->MSizj(true, string("VoYcxurltMfudnWiDEmituFJZdzBpRtJUdwvVNNJPSQusDuuacTmWCmTzosjfHUnwKJ"), -809290.7870433774, 132095.262079392);
    this->SpApeEqbuNyMK(string("WvGAGPZoTcGNIPVLRqVRIKewduqkvkaNhTRXKFRAFyoHMfKpwIRVFHRFNoNxYKUnPAewmivLAVUbSAZXArVSNAFmfZVSXOAhEJsJKLgatcHTtwwXRpZqdDBxkhpFLrbeJXQJSZYjXPolMqMSpJOJEMLmJMWjRwJGjOSqiMzoRVr"), 716922405, false, -435517367, 866905.8668339227);
    this->yLbMyeiN(true, 1777179269, string("YRvPUacEPgbKnDTEGLglAWjawLsqDLYhjetzKBiAejeRDeoqPRpPDxRidtKqohkjuQYEuYel"), string("KhbukhBccTLIJNhFWwrGVSkpGeJQqGBAJpulKkbXOlsFxpdccALqQFiXQzuMUghcmKBiu"));
    this->UOBMXwbIICMqDfkK();
    this->ssgoYVNxdjulQQbq(973532.5271574889, 933328.6746043493, 146228.0486591348, true);
    this->mkgffGtPIGsB(string("ClHpfOmbwAZOPJYqZIMFwyURnHDKGKSbvahkxVKxGbbbyJAEMKYvpOxCdxLYglpLpYkVZEOHgEaqQcfpOCPSlDMqpHsnSzOJnILxfvHLqqmrGabNXpXVhqMLlKRCziriayyfyamDqFaTRRrjObMBbvvGMoIlluANksaUmcabscoayasEsToteguSbvlmFQYtUXKPQIyMkLKD"), string("nbEVGkHUhtXQBbBPPSHusbtOrqmRbUIyUGAeFwOGEwDtbTHsGMahLOhtfGQTmAGPLNSmtYATGZDaETbWXGYHewwepabAoFdOxgurwWTDVxOkEXm"), -896294724, 83916371, string("UvVrysopVQQbkdnOUKfUZIvMpemnMRUJNmVbrvOdaCrJRzsjZgBBSCRRRKUlBkgCankqiOJZARwMWDXmRFWwMTdSjXnoHMQmTHUSAgEpimZhmugfDoEbemnQL"));
    this->bHOhHPemhWz(-1032956.2176231695, 717863.2151780803, 493900397, 68947672, string("KeSUlzWlBqNrMPRIKupbOLyRuiBTmeDCQtrEFaXfemLipLPuNRQLsiUEektqDgSATOIjhBKmmabfJjvUiuZyeJxKIwtwevyrKQwTYclfhvHLsePaTyxLYqEngeYvMcdUEFtFUyvUGzQcTVHEAyURY"));
    this->daFylCa(-71256.54545702803, string("dmSUxBXuBTnoOPEVJzxGBJjkxTaEdsizeefiqUJSpwPjwcdjOMlzzNLxfrvnmEbxzWBuoVroalGQnwvgaVqmwMHNvXoRZLDdIttvtVNPVgXivMHZaUVCSDWvdFwYnVqzyluMQCJZpLAjPBLqvCbtMbQDqkLnamLjfrPinfejfxSxHOfdh"), string("xAWEWemsMRgFLVMrsmsTIDPoqTmHeYaSUKXoFPJZPMXEFcdkfBldwDHzqoNHqVBRxLgCgnsYVMcxgTLkMksZFnwjKzzcyowqmXHZUyMKnEdZoVHIExOPFjtPVpxXBVuoOpbSnZheIAASosPRMUMHUgcHpKiXbIwgavGHxdOolCgbxoDQbKniHLdOIH"), false);
    this->IvsCXz();
    this->hBpHTQLIWmUwCbyQ(string("mZRNkvcMoXCpXoNgUEPfcESjHZbznZkZTstlkHhIrrQTcocOhGFAvtcsqzaMhTx"));
    this->yFTKAoVzEFc(string("NrrkwFguuMqVFdKjOsVmWniZxnzIKoSAAyjrEAByaLIvOunEZTPnhDfYFdWzOnmxnpMlfCLRSfRAxSVYXhHfRsgxrGhhKIExsbzyWtiFbCTFtoZJPzrghQfbWkBhMbVZKXIsXGhKoqezhczxSvXkgPDmNuWDUGxETuMCJrGznsws"), 918123.0626709961, false, 283755.07389712427, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ybVJCNweknyps
{
public:
    string ZjCvURVhtzR;
    int jNWOmSXx;
    double ZxBMICNmYNw;
    int YlSwfCnHZbtucr;
    bool GVxdyq;

    ybVJCNweknyps();
    bool MExiLT(int vSUxrLuFbNUeAmHd, double olIbL, double UJmypxkoiYcehQLc, int UYEbGRAjJXn, string FIbXAf);
    double KOkAmocdKsAGT(bool xnBwIhZuPI, string TZLzxA, double wBtdsVAD, bool BcnpbjWMM, double uxItFwwmAKCxFEEG);
    bool EDysmH(int RqMPQzZFQoM, string iPNQxVmI);
    bool BNRXDvUEGdN();
    string SWhFqGsXXNErVw(string cIIJfaaluaCbyfr, string dzepOydlfgKnkuJ);
    string RMCQQK(string sWxDPhJuXiHnd, bool ChefEJAMEVd);
    void fxjtXQuaadpVERZF(int UjsJKNRNBnAVm);
protected:
    int PwVRdZwWdDgujBCb;
    double umMeogN;
    bool bNcAANDvW;

    string JVVYZNWyvKOaPTMI(double gRukUM);
    int lWcVFcODr(int FaEGOSfRNI, int fiOSGRfaR);
    int XWriCiBw(double JHmJNnmHh, int yZOlhvFWyTLgTR, bool pmQDqsK, string oIehYLrFEoYXAysf);
    bool uCJEkhouiviYCw();
private:
    double wpfaGBqeilTdszq;
    string VmCrpXARpaT;
    bool dMJVz;
    string RDROf;
    bool pCDtkcgJtpvFSVLz;
    double tzAUFMJowiUCZR;

    void zcCESEIFQRwtPGH(string jgSEcHvaMLTXY, double eDvbEiLSHjCPq, int DLkreguVZUpRbK, int vntldZHrwRa, double dJsISORdXofS);
    double ugCbEvbnDIRhro(double rQbqwMb, double DXLJhE, string BllttMFYfOkZye, int kSbDGsdANKF, string vaTwtqI);
    void IqYrmoh(string WeqgmZ, double pfYCFbmCQe, int OsXFcXztASAs, string tgtCFpqY, double cJbJkCI);
    string ZBroVNvEfLBSOa(int FiJEu, int hpkfUDojvZy, bool stKkRDLsIRscKfY, int yPCzWY);
    void iIqRvXUXDqNRx(double lrpQuMFL);
    void PYoALLlpaHstst(bool nVOtNC, double AaueUFbXM, int liGrzPkpHB);
    int OBiYDJSbfiikHMGx(int tECcdYmOTrEdrtRM, bool yiUgdKChNZzxTblb, double VwKDAKK, string UwOjprQumlS, bool PkJnXPpTWmUmc);
};

bool ybVJCNweknyps::MExiLT(int vSUxrLuFbNUeAmHd, double olIbL, double UJmypxkoiYcehQLc, int UYEbGRAjJXn, string FIbXAf)
{
    int ZfiGbHOpz = 561084455;
    string zlVJCJBUz = string("zhQTdWRuaRUrIfMcAUmNaYRWPXyovlJdOYsbmrslHwVefSeYHrAoi");
    string AtnYFLT = string("gJAaaPceYcSpTdbKeClftPhGjNvIrTwRWDWhqgoIBnwOEQayhMiRRrLKkpYUdVmzJKFqxRZyPTlQVsnbfRZodlEQOfyPspHDnzpeDRYwSRadjltpiDwfatoNZaPRJyZdZTQqlmRbKwiEMigxibFYcUWIFyInnAuQnnXMrwoiGrRSDcLGPTvXrONeYYVPaxfMelbdmGfgNXIsulELKIQkyOjZFtKxinHs");
    bool qqKfqXAIgHGYFG = false;
    string RRzwxYlx = string("JmRvFslqTPwZVZw");
    double YRZpMBweMo = -775128.9790669159;
    double huwZP = 673588.0297799872;

    for (int cTqpLseAsMGkzp = 1532836193; cTqpLseAsMGkzp > 0; cTqpLseAsMGkzp--) {
        FIbXAf += RRzwxYlx;
        AtnYFLT = AtnYFLT;
    }

    for (int SGRaALsbVzFbhJAe = 794164907; SGRaALsbVzFbhJAe > 0; SGRaALsbVzFbhJAe--) {
        UYEbGRAjJXn = ZfiGbHOpz;
        AtnYFLT += zlVJCJBUz;
    }

    return qqKfqXAIgHGYFG;
}

double ybVJCNweknyps::KOkAmocdKsAGT(bool xnBwIhZuPI, string TZLzxA, double wBtdsVAD, bool BcnpbjWMM, double uxItFwwmAKCxFEEG)
{
    string aRjXQ = string("csQiMTAdrupMjKMkeEwIzaTqpbOWwXNklFElqGcIrHliyGrUaTqoAHOEbokhKOHdbIQxDIvtGqegjWCAtAJTTVeIpgCNPlyyfHxWlATZQyPlNHzkgdMYjdcqeAnsqWMtqoHnQpUMCXuWyy");
    double zHXSsdckuSS = 269519.6390608518;

    for (int HIlgUlYMgPxehT = 445421950; HIlgUlYMgPxehT > 0; HIlgUlYMgPxehT--) {
        TZLzxA = TZLzxA;
        zHXSsdckuSS += wBtdsVAD;
        wBtdsVAD += wBtdsVAD;
        zHXSsdckuSS *= uxItFwwmAKCxFEEG;
        BcnpbjWMM = ! xnBwIhZuPI;
        aRjXQ = aRjXQ;
        zHXSsdckuSS -= wBtdsVAD;
    }

    for (int CdjmGOvreLHdpbgQ = 647527404; CdjmGOvreLHdpbgQ > 0; CdjmGOvreLHdpbgQ--) {
        BcnpbjWMM = xnBwIhZuPI;
        BcnpbjWMM = BcnpbjWMM;
        xnBwIhZuPI = ! xnBwIhZuPI;
    }

    return zHXSsdckuSS;
}

bool ybVJCNweknyps::EDysmH(int RqMPQzZFQoM, string iPNQxVmI)
{
    int YAqiRXE = 1369539952;
    string fyYYVeGDEXcj = string("ljgcZUdcwWJfzMLcIQzvqINVXlMTvagslbKZlXYHgrRpzLDzyuvQIyWHRQmJocYXpaxScSPiNfecVhQExeCKkutgfgFEovOGoaoFNwEtZrNbsFBEUksRFhQgzlIV");
    double YEcxTScsFRrY = 646240.8432131329;

    for (int dTBUVa = 883609078; dTBUVa > 0; dTBUVa--) {
        YEcxTScsFRrY /= YEcxTScsFRrY;
        YAqiRXE /= YAqiRXE;
        YAqiRXE *= RqMPQzZFQoM;
        iPNQxVmI += iPNQxVmI;
    }

    for (int nrjqoHthBkAy = 2117417575; nrjqoHthBkAy > 0; nrjqoHthBkAy--) {
        continue;
    }

    if (iPNQxVmI < string("ljgcZUdcwWJfzMLcIQzvqINVXlMTvagslbKZlXYHgrRpzLDzyuvQIyWHRQmJocYXpaxScSPiNfecVhQExeCKkutgfgFEovOGoaoFNwEtZrNbsFBEUksRFhQgzlIV")) {
        for (int YXuufVRgLlr = 1794805875; YXuufVRgLlr > 0; YXuufVRgLlr--) {
            fyYYVeGDEXcj = fyYYVeGDEXcj;
        }
    }

    if (YAqiRXE == -1290077652) {
        for (int NjaQMLZth = 1311438079; NjaQMLZth > 0; NjaQMLZth--) {
            fyYYVeGDEXcj = fyYYVeGDEXcj;
            fyYYVeGDEXcj = fyYYVeGDEXcj;
            fyYYVeGDEXcj += iPNQxVmI;
        }
    }

    if (fyYYVeGDEXcj > string("fhvjnxZJpXtYKJVbllWwRwUIYytynxDIoxLpyRvVFlsjimQWGvjXngujFCGxtDcyAOsxOXYfucVcmwYvUrYedvttRsmJUO")) {
        for (int CNPQPijDXXUrqKlu = 1626602528; CNPQPijDXXUrqKlu > 0; CNPQPijDXXUrqKlu--) {
            fyYYVeGDEXcj = iPNQxVmI;
            YAqiRXE = RqMPQzZFQoM;
            YEcxTScsFRrY = YEcxTScsFRrY;
            RqMPQzZFQoM += YAqiRXE;
        }
    }

    return false;
}

bool ybVJCNweknyps::BNRXDvUEGdN()
{
    string DRHjyOR = string("jGHIaxuenNFrtgPZLilZoyRQCldcyAowflvxxublCQLaJptZjfQGEHPiSfVecKJRAtWfpRYrBUIUlCntXAMHFfhFtpxdQRuckBvpGlwgVjfsFBoANEUKSmu");
    int YzAyJZWxkCl = -834546288;
    string vUHwDJmgxFaa = string("xhJvhzKYrGKbjnOUSYeiudJvYJmHUSyBTTzmunPEbpjwwoUdNtyEjpQbUMOtLcOpnhVWNiLlVMTRejrlXqlejVfWLVlwKmxzWWRvzrXzhCkevETQAgljgOStcESwFgTgMekjEzAraAQLNyfGcbpruSrBjMBThJenWPiPUCMNusImYyMagKLGLiTaOfBzDYzuCFSLewuzXjJQkCVmMSiWmtsEAtaTwjHblHzqtMAJJcafm");
    bool svMTEnvy = true;

    for (int fKIONS = 531717704; fKIONS > 0; fKIONS--) {
        vUHwDJmgxFaa += DRHjyOR;
    }

    for (int DtvkGJsVwXMBVlw = 680971338; DtvkGJsVwXMBVlw > 0; DtvkGJsVwXMBVlw--) {
        DRHjyOR += vUHwDJmgxFaa;
    }

    return svMTEnvy;
}

string ybVJCNweknyps::SWhFqGsXXNErVw(string cIIJfaaluaCbyfr, string dzepOydlfgKnkuJ)
{
    bool cOzaQDcrcvN = false;
    string EiciKsWtglaDOddL = string("YoOEQJkgkwkrWrOzVkVhDvFoInMxAtQOTfuMOzjmOpGyzVaXkowMheHEcfgdZfclsXFBvGCvSQUOAeokGXvzRABqapGYhLmHQcjYTgSuhOXsbXZhSJHTmBNfnVOZrPDSWpfCrinyHSqGKHkGZNLkgSPXfTYCspXzquKtCnEGBIWuoYNUwOzRuLGWtZlLR");
    double DjoEJydiP = -437674.2051257397;
    int WHpoJ = 1062558166;
    string iCKdM = string("HCEMhIpnovwBuoNtJNfzRioKVWukNdoYsfnAwDrcAJaoEEZCeinWEKUMEinpbvp");
    bool tBkxxjNDwm = true;

    for (int iJChGLykMsSCu = 1864119991; iJChGLykMsSCu > 0; iJChGLykMsSCu--) {
        continue;
    }

    for (int gEdtC = 230470915; gEdtC > 0; gEdtC--) {
        dzepOydlfgKnkuJ = iCKdM;
        cIIJfaaluaCbyfr += iCKdM;
    }

    for (int YgTtbEkQv = 1521710944; YgTtbEkQv > 0; YgTtbEkQv--) {
        EiciKsWtglaDOddL = cIIJfaaluaCbyfr;
    }

    if (dzepOydlfgKnkuJ < string("oPeCkGRPVrFccvwcazlIwlFZannzQKYPxFQCGUOqnssBTpCnAQgqzSAJioeIxMcNByTktysBmOdyFEDuvaEIsiOMzSnsirRcWnLfKyjljWloyboowJtxZUxIydnYgJKUuGQAvXQCrvEzRdhihsGELcxWNpJxCSWrSXGhEFYdRewXaxgDGOgoyGzxkSEGabieGfjtJDGACTSUMkVdkBlvjIDmIwUulzmCeCIZjDmqUcwbKdAwVJvwWoikAivK")) {
        for (int JHpqsjpmLqOTeybf = 1036989284; JHpqsjpmLqOTeybf > 0; JHpqsjpmLqOTeybf--) {
            dzepOydlfgKnkuJ = EiciKsWtglaDOddL;
            cIIJfaaluaCbyfr = cIIJfaaluaCbyfr;
            tBkxxjNDwm = ! cOzaQDcrcvN;
            dzepOydlfgKnkuJ += EiciKsWtglaDOddL;
        }
    }

    return iCKdM;
}

string ybVJCNweknyps::RMCQQK(string sWxDPhJuXiHnd, bool ChefEJAMEVd)
{
    bool fzrBJxoCyM = false;
    int tZvfsLaSJ = 905070456;
    double FJNZSaJBpLimppj = -624400.3323631972;
    double rIgJULSVjdjornYV = 442599.1155114724;
    bool huMhqSUt = true;
    string RrFdzLodgObdqqX = string("hBmwBbwLeBweZAzkDRGNZxVykNWPozLUeJMBTmjhjF");
    int UcykoYIZqwEF = -796742146;
    string etSOvDQWK = string("YoUuwclEnfNqXVyOOWbttcUwyABGVvPQWoyXpVBUwCxQohaIrEoOntcNyaRwmLLanSTUeIvfRjndnvHtrwvDWwljgRwVZPeRZTgYlVAttSGgMyKDauTjktEdSQSvdAZXZSffKcZPQaPmEWLCKIYLosULyzrDqiJEEJpMhWwvl");

    for (int EhbRiwZxSEzmqMic = 131677725; EhbRiwZxSEzmqMic > 0; EhbRiwZxSEzmqMic--) {
        RrFdzLodgObdqqX = RrFdzLodgObdqqX;
        RrFdzLodgObdqqX += etSOvDQWK;
    }

    return etSOvDQWK;
}

void ybVJCNweknyps::fxjtXQuaadpVERZF(int UjsJKNRNBnAVm)
{
    bool pTEfgLnFUXil = true;
    double QbCgV = 500481.2737612844;
    bool tsrrFPaKxjEpo = false;
    double zMMCnJBBrvKuHG = 886322.1623445734;
    string XWbbpifPPKemje = string("WTSxTthQiIrDBdVxhUQnQyJRdqNKgJAfhpdZIcheIsafTcjRBtmBLnNuIahewiQBbZAp");
    double SawBTsLtM = 316611.18963451753;
}

string ybVJCNweknyps::JVVYZNWyvKOaPTMI(double gRukUM)
{
    string ilXroirYqqFZf = string("mqWhKGf");
    double CGGPEEqNUcP = -670789.4047929045;
    int SWQce = -230868451;
    int WsJnB = -1786118003;
    double wbFEkPKv = -272550.4886331659;
    string jHJKBTDEWXaj = string("rgGXoOjyEyPIZqrRlAPJYgtTAtPcDPMnWOUWDYUsekEbTVKIZEvorOwJBusamytzrUSPYmIHfCcGadWZxIfHzRgpyaPBGKtYvjclCpcriKBLTUqUDcnPhWWnWAvhXAKkurTocIQcfOaAAFiWnBUGrQjnCdeFuOvQGQhmkpKYpPW");
    int feFCWETq = -15421210;

    for (int pGAXOMvOZhcm = 950236013; pGAXOMvOZhcm > 0; pGAXOMvOZhcm--) {
        SWQce -= WsJnB;
        CGGPEEqNUcP -= gRukUM;
    }

    return jHJKBTDEWXaj;
}

int ybVJCNweknyps::lWcVFcODr(int FaEGOSfRNI, int fiOSGRfaR)
{
    bool WofJowfte = false;
    string DFhVuGegkSB = string("QcJKVPqUfreiucaXSQoVPrvaoSNXpgwULWOxDAGSaOCKdsMBDIZxEq");
    int APXvz = -28624886;
    string QKOYDTqSOJ = string("faw");
    bool ZMEdweKSofsiJHO = true;
    string nRfccXznEY = string("dmmNBXWhYRANJYkbMDhcawBQIaaSWCbrBguRQclZQqZCjpEdsphhpIjxdERAyhKVsZWKkZKwQrNMsiCcftunL");

    return APXvz;
}

int ybVJCNweknyps::XWriCiBw(double JHmJNnmHh, int yZOlhvFWyTLgTR, bool pmQDqsK, string oIehYLrFEoYXAysf)
{
    string RwqcogEPkjXU = string("SuuEykMVuNpeTjgbCKdsfCUgSPVlnoIVkcWwGBrcQyyuZXpcXgALhRgYZlGLfXjCBwMFQtcwFeSIqdXvmxICyDKHAo");
    int ELprzswRq = -857435609;

    for (int TWGnndrMpL = 1551291134; TWGnndrMpL > 0; TWGnndrMpL--) {
        yZOlhvFWyTLgTR += yZOlhvFWyTLgTR;
        RwqcogEPkjXU = RwqcogEPkjXU;
        ELprzswRq *= yZOlhvFWyTLgTR;
    }

    for (int iPuoYVmXAHUJQU = 1293659157; iPuoYVmXAHUJQU > 0; iPuoYVmXAHUJQU--) {
        ELprzswRq = ELprzswRq;
    }

    for (int paMLVvias = 1662920334; paMLVvias > 0; paMLVvias--) {
        JHmJNnmHh /= JHmJNnmHh;
        oIehYLrFEoYXAysf += oIehYLrFEoYXAysf;
    }

    for (int wCieiMvbhGWlvOi = 1456671562; wCieiMvbhGWlvOi > 0; wCieiMvbhGWlvOi--) {
        continue;
    }

    for (int GofpmaECxUbnd = 1774280558; GofpmaECxUbnd > 0; GofpmaECxUbnd--) {
        continue;
    }

    return ELprzswRq;
}

bool ybVJCNweknyps::uCJEkhouiviYCw()
{
    int jeqEuHc = -1989390098;
    string vSrUKJlMVn = string("QfnwmiycwwoKhLnSagmHCsUkmtffNbFuHESAxvhVzFwaFcBGGjPDbAZnAizvEiqDyucRQzsGXKZdSezrvTLFocJWpZChLaCQHpyWZFNXbDmyfmrTVwGvAadRsnjFRKiVubKqEZGEKcznuhatBRlSLRohIBXrwON");

    for (int bCgzflzzUVgS = 657068495; bCgzflzzUVgS > 0; bCgzflzzUVgS--) {
        jeqEuHc -= jeqEuHc;
        jeqEuHc += jeqEuHc;
        jeqEuHc *= jeqEuHc;
    }

    return false;
}

void ybVJCNweknyps::zcCESEIFQRwtPGH(string jgSEcHvaMLTXY, double eDvbEiLSHjCPq, int DLkreguVZUpRbK, int vntldZHrwRa, double dJsISORdXofS)
{
    double nZqvPkrhRAjBol = 513124.2589833276;
    bool QQdYUVlcX = true;
    bool rpPJfGcur = true;
    bool KCdWhECZKRvFyLy = true;
    int MBgUbx = -1834348301;
    int ajfKfBZCrUzLTq = 1781239184;
    int HtsVTqGORZGVnS = 1973835918;
    string FAiOtJAe = string("JfebnZcscbjSVVrEBEazsXoRyFWxXIIlzuHv");

    for (int mxsbV = 771175700; mxsbV > 0; mxsbV--) {
        rpPJfGcur = ! KCdWhECZKRvFyLy;
        vntldZHrwRa /= ajfKfBZCrUzLTq;
        dJsISORdXofS += eDvbEiLSHjCPq;
    }

    for (int bedNWCWHN = 1172325; bedNWCWHN > 0; bedNWCWHN--) {
        QQdYUVlcX = KCdWhECZKRvFyLy;
        eDvbEiLSHjCPq *= dJsISORdXofS;
        nZqvPkrhRAjBol += nZqvPkrhRAjBol;
        DLkreguVZUpRbK /= ajfKfBZCrUzLTq;
    }

    for (int bBGvl = 1325259953; bBGvl > 0; bBGvl--) {
        QQdYUVlcX = rpPJfGcur;
        nZqvPkrhRAjBol += dJsISORdXofS;
        HtsVTqGORZGVnS = MBgUbx;
    }
}

double ybVJCNweknyps::ugCbEvbnDIRhro(double rQbqwMb, double DXLJhE, string BllttMFYfOkZye, int kSbDGsdANKF, string vaTwtqI)
{
    string TvyRvorSAaVQ = string("OOdYqhfrXrCRsRIRKNzRuJdBkUJABfNNzBhyEfxbylALycbHXfqQYUdXgitREmMuRAwyBxuhNLiDVQttbjmrkhvyZmVKEZPezDSexdoqOSmBkZlxccCXqespJjtyqPfmqUaJPMHKAHushiniWQvwVOHqXFURzSUNYmTbQSqHLUwWhcwCTGhrkySAynZQLtCPOBBwtgpENkBTK");
    double DmFNB = 635173.351924385;

    for (int NSuJuZdpwLbT = 1998638031; NSuJuZdpwLbT > 0; NSuJuZdpwLbT--) {
        rQbqwMb += rQbqwMb;
    }

    return DmFNB;
}

void ybVJCNweknyps::IqYrmoh(string WeqgmZ, double pfYCFbmCQe, int OsXFcXztASAs, string tgtCFpqY, double cJbJkCI)
{
    string GQonljOnPH = string("GeCEiAADysRKOITiswMskzBWUcWYfWCRqlRTurBUcAPyfFyMNFwtMqAAtXvWgWtSVPJehzNKkupBXyGocgkfBXWhoqRHTapqPQUlWfCHUJKrItPXgqfKYARgkMoQxic");
    bool AMNgQebsNALDBp = true;
    bool JozMCE = true;

    for (int GRsDJwUI = 225864656; GRsDJwUI > 0; GRsDJwUI--) {
        JozMCE = AMNgQebsNALDBp;
        AMNgQebsNALDBp = JozMCE;
        pfYCFbmCQe += pfYCFbmCQe;
    }
}

string ybVJCNweknyps::ZBroVNvEfLBSOa(int FiJEu, int hpkfUDojvZy, bool stKkRDLsIRscKfY, int yPCzWY)
{
    double zPSmDibQEfP = -413712.18051172217;
    int BFuAcuFBgtKTHe = -1299340710;
    double eoontUgjLFaSbf = -460950.27322678186;
    int YDijrQZOrEfQj = -1841981915;
    string aVcnMfLz = string("jCijwJUnALEkJtubCGQrQfQZPJCmFgQxeGYIZfDfBUofCv");
    bool cXKSYafKGqxXj = true;
    int idoOWZtVLGWw = -2005847615;
    string lQsdn = string("YTfYabrZvottzMdYCTPgCuvVwreyAJEiZpvJkRWYDsqNApKWOyfwqBDelGhmnxbxWlGmwsokbKDeDaODUqIsGiRLZoUQMRganTJdVXLVQVsD");
    double kUWNhltkMKlvUnO = 1026967.6627752611;

    for (int yBRGYNuN = 761685466; yBRGYNuN > 0; yBRGYNuN--) {
        cXKSYafKGqxXj = cXKSYafKGqxXj;
        cXKSYafKGqxXj = ! stKkRDLsIRscKfY;
        idoOWZtVLGWw -= yPCzWY;
        zPSmDibQEfP += zPSmDibQEfP;
        aVcnMfLz = lQsdn;
    }

    for (int bcgbjYxFh = 230088628; bcgbjYxFh > 0; bcgbjYxFh--) {
        idoOWZtVLGWw /= yPCzWY;
    }

    return lQsdn;
}

void ybVJCNweknyps::iIqRvXUXDqNRx(double lrpQuMFL)
{
    string dQKIOn = string("QxSDmMDHFzsIXRXctsvAltmoMopOsEOdvwelrABBlImfovKcatqZnLoYCKPzMHgTzGbRTlDOixYCqFXdMciCiQoUvPBWJESLYXGHXosegaPZbDBKNLgmtLPceujmGnpdlpcEXpXPkcvKcEJexQgnwCYJPMbcQTFfAbjnVcMFmuUzsqJIrcAbdxokbDqPYmiXPWf");
    string HYpZitous = string("IRZiEVvvbnJgxfDiXIxXycwmdDrDMaKShYlTjaRQkzQaGxzpbkcEATUudbOevFPpDmogrLiHxzuLQtB");
    string QogfYaVioKO = string("qVmaOgiKGUMorxqXy");

    if (dQKIOn >= string("qVmaOgiKGUMorxqXy")) {
        for (int vxgfV = 1929444856; vxgfV > 0; vxgfV--) {
            QogfYaVioKO = dQKIOn;
            HYpZitous += QogfYaVioKO;
            QogfYaVioKO += QogfYaVioKO;
            dQKIOn += dQKIOn;
            lrpQuMFL += lrpQuMFL;
            QogfYaVioKO += HYpZitous;
            dQKIOn += dQKIOn;
        }
    }
}

void ybVJCNweknyps::PYoALLlpaHstst(bool nVOtNC, double AaueUFbXM, int liGrzPkpHB)
{
    double EWktOrmuTIrpLpS = -576067.5210733828;
    string NGMJoyeVsZiWHQJ = string("gakXAj");
    string jzdrChcRF = string("OuCbavptEFeUrJhqmosjGuDagiPNBKJpOBcOBEaAIERPFdRLlkBAsy");
    double JAtoKziPQMHpkpo = -248425.70443061015;
    string zboRvdAocB = string("efWGwtnYHOaKiExIgdOxJiCQirCbXwQhslfmHuLzYtaJgkJxwNTRXvXKHXYKishDUqxbjXIUvSdDMxETjcPGATgXrptLwBARCzRYqDKIJImzqCEzfqBmqNiqqvgnXyurCAHdowYlcRdmFvKsF");
    string XmJfIiCBY = string("aUGlIETxbCLgLgHARwDSfssVSKWYcKNHrhUueEEILukUalZtwpGfDroHyZZkgiHDQmFcdUcJQNuIFQfCYLfmLtUbZVwmcYOzBeNphCuyYMbQzPpEuuDEj");
    int cjRTdhBMtDs = 358322302;
    int ULXEukbbbuCLqm = 1229928379;
    string cWxpYrPK = string("JIwrKmIGgfvetqeaqOwGyMwuBPBynlFKTIPSDVEJGgKFTvsmymtwZzUwzyvGAbmcqvmyiDnQluqtizgDXMJnnTznWUITXPjTVoStQjHoGUmWyVFYFEjUKHyoSHKuYcpwizlwpvDftDhGHEhRwpgqKBgLbdkfxDGrQ");
    bool CClglIJIRK = true;

    if (NGMJoyeVsZiWHQJ > string("efWGwtnYHOaKiExIgdOxJiCQirCbXwQhslfmHuLzYtaJgkJxwNTRXvXKHXYKishDUqxbjXIUvSdDMxETjcPGATgXrptLwBARCzRYqDKIJImzqCEzfqBmqNiqqvgnXyurCAHdowYlcRdmFvKsF")) {
        for (int mVcoOa = 776665995; mVcoOa > 0; mVcoOa--) {
            JAtoKziPQMHpkpo /= EWktOrmuTIrpLpS;
            AaueUFbXM += AaueUFbXM;
            JAtoKziPQMHpkpo = JAtoKziPQMHpkpo;
            zboRvdAocB += cWxpYrPK;
            liGrzPkpHB -= liGrzPkpHB;
        }
    }

    for (int sJYmEYurXzkv = 1030795376; sJYmEYurXzkv > 0; sJYmEYurXzkv--) {
        continue;
    }

    for (int nNPQTaSJ = 1533429477; nNPQTaSJ > 0; nNPQTaSJ--) {
        continue;
    }

    for (int EjleOQfJ = 1680169284; EjleOQfJ > 0; EjleOQfJ--) {
        continue;
    }

    for (int fAFplescT = 1613739848; fAFplescT > 0; fAFplescT--) {
        cjRTdhBMtDs += cjRTdhBMtDs;
        ULXEukbbbuCLqm -= cjRTdhBMtDs;
    }

    for (int YjxsJLtMLwaMn = 705022966; YjxsJLtMLwaMn > 0; YjxsJLtMLwaMn--) {
        continue;
    }
}

int ybVJCNweknyps::OBiYDJSbfiikHMGx(int tECcdYmOTrEdrtRM, bool yiUgdKChNZzxTblb, double VwKDAKK, string UwOjprQumlS, bool PkJnXPpTWmUmc)
{
    bool NmOpHsZRPYrdiZi = true;
    int NovRIbBrXJthOR = -547607063;

    for (int khdhZwSbmkf = 1407872274; khdhZwSbmkf > 0; khdhZwSbmkf--) {
        yiUgdKChNZzxTblb = ! yiUgdKChNZzxTblb;
    }

    for (int AqUhGKc = 1636496041; AqUhGKc > 0; AqUhGKc--) {
        NmOpHsZRPYrdiZi = ! NmOpHsZRPYrdiZi;
    }

    return NovRIbBrXJthOR;
}

ybVJCNweknyps::ybVJCNweknyps()
{
    this->MExiLT(898841253, -574866.5078046995, 816866.1922471819, 1192498379, string("IOfhkdKWRcckbsGwcVdXVIZGdaCdYmItwFHYaWIDdLZDmgElojMCvknPlWnabfsUKrRiKFLZCEGREkkmCVWxnxwFAYlzhgfXKCtHgWLXlgvOrfgwQSsRINNAeMPRKYrYvVRosWxdUHdelQCRTbrucjjJmYdrtOQauGulygzDNLAcC"));
    this->KOkAmocdKsAGT(true, string("izlarmbPJaOUlrowBombxAHFrLFshuYRsHwuropqthxnyAUnynrJrgfxdOAADSQiyICCAqesrvMrfytEurpnccHeEqiFeKwiRyamDjPqkPU"), -652471.9603449993, false, -696466.3577813592);
    this->EDysmH(-1290077652, string("fhvjnxZJpXtYKJVbllWwRwUIYytynxDIoxLpyRvVFlsjimQWGvjXngujFCGxtDcyAOsxOXYfucVcmwYvUrYedvttRsmJUO"));
    this->BNRXDvUEGdN();
    this->SWhFqGsXXNErVw(string("oPeCkGRPVrFccvwcazlIwlFZannzQKYPxFQCGUOqnssBTpCnAQgqzSAJioeIxMcNByTktysBmOdyFEDuvaEIsiOMzSnsirRcWnLfKyjljWloyboowJtxZUxIydnYgJKUuGQAvXQCrvEzRdhihsGELcxWNpJxCSWrSXGhEFYdRewXaxgDGOgoyGzxkSEGabieGfjtJDGACTSUMkVdkBlvjIDmIwUulzmCeCIZjDmqUcwbKdAwVJvwWoikAivK"), string("dxLorgcusPgZnxxYvfNxCcXpwPkjNBOgWReYMSKGnhHhrQlkUOsUkXdDXegIpZDvZHniUFOFwcBoSVoamSwHkroGDSBqQAytEQehPDAmthBVpveJbYUHOXdAcpfSLAyLeMQHeYlWdSVCRACKAGLeJFmQEbnXPIjNCC"));
    this->RMCQQK(string("HFmrHSfuIlBywnBzAqUVrWHjPvSXJQzfPBfDnZQsXMZnpYydpFDFClvgNPZnzrofTJhiuFmblsWXPTCUjlqFTGDsKCIlOGaUZFvCmRzETjTYyqLggmvIfujVqxuTwNCWmIWIdoasSXZzdlJqoucgZKorvIcvjmeTWrCyegRCLEqsjpSBzhBEkUvbXxpZMHqazShcPEKoNrXIcHxWfNoWdwhCcVzUMMmCAiJxQcgU"), false);
    this->fxjtXQuaadpVERZF(510445475);
    this->JVVYZNWyvKOaPTMI(-18273.48867175536);
    this->lWcVFcODr(495441789, 1966880885);
    this->XWriCiBw(245116.89026771323, -1352803192, false, string("WxlTJdEXcVfzgWTwvTytCSKsFhprBwBYfJJivnfKNseHEczDLCimyyJBJdKxlTsLZTxExSfcVCcqKpXJoDahtlSRRflAmnKRMfVFJ"));
    this->uCJEkhouiviYCw();
    this->zcCESEIFQRwtPGH(string("cbrMszumeZRCQJqhOQZnxVlpxTqdFRyamwglRklDQdIdOkaRLIlhxEUWCvXlGFZUHVoEypcsiFLxsfyArpKtKEWeaIONXGOufMIbMGusWUlPRyWkBfroWAzBYIcLniws"), -898757.00362378, -54779031, 1894164939, -664723.5457852912);
    this->ugCbEvbnDIRhro(-734032.4548552822, 990066.4521331645, string("TVakYIANacwnNPYrzPGqsMVEtSzSrSgIWeFbnViddEJoALyTuCkxUlKJLBjFqGbuewnmLtUAtRLyduIWQRxLrkcLEqRZegfvPcZWzgIovdDwYVUTCoJSyCRMROSChcwqTaAHLojfcybNJkQSoGVzrwEZUmtkDfbnrfhrBGQeuHdxKsIXUoZZTUUJNOsOjZBCBigpAqUzorr"), -608654259, string("MAxHChoTaHGegczjVsoQNgCXDRAcrFuNfWJgfcsfOlcyRqheqKEYxiJX"));
    this->IqYrmoh(string("rboefiJVNYoUEQKPXGkislWHOwFQgFRzZUNgdGMPlSQlIPxDbIusTJJqtLRpEPqBpyYYrqjVhQTJyByiNiDPOPPxBfugTFq"), -550692.76159616, 2037235375, string("snkYOKOVpRvrpxhEkLoGANaTmBXBJoouPRsZxEZKZkLgNpDwkwTEcjoRhrOOQjdjlEcbtZnvVpApXzZsyteowmPgjsdSCUnswBmQuMfBgNvaReFQMTXnZgjOvIwgnTByGIHSMPcPiSVfRuFALSSPvpWYftaDxdizgsqcijuUxhAInxPoaOWXbsfxhmRsRosnAVfFvpOGvqOjLDDRoaXas"), -31160.50261067965);
    this->ZBroVNvEfLBSOa(543200400, 824277518, true, -1837770368);
    this->iIqRvXUXDqNRx(450606.6139710784);
    this->PYoALLlpaHstst(true, -748210.990192982, 1836711579);
    this->OBiYDJSbfiikHMGx(1991976593, true, 805041.7692161016, string("FQDtvUyaICGNoqedzbvyyoImnzUiOfTUsdbFUpLeAnXIcHRPtmSDazIMdptRJovmxYyiKninfQYsXMfWVyZzaneaNnGupajyYYDgKjepBghOZmThcxKDcTyqCaxnkiQbemHixXMWkTvTLgiEHLVBxqpOSnPGWFzNyyvCnQAKiCnyGxGeKJOHtiXSkOTujTYrTbsxrKoBMsogs"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lYlFxEiVCTp
{
public:
    double PbTNxlzMe;
    int VhOibrDkAQJ;

    lYlFxEiVCTp();
    int hEwzDVtMUQcEef(bool FhcSoDmAeehAj, bool WoweiC, int QrXZCJXHHZiMhu);
    string gvZkxhkno(bool FoeNJ, string tFySJIUr, string WtFKaHCyTL, double nlarrBHJGbLLOfKS, bool kbRvwkUDW);
    int bdlSWn(int saxxvuIIPHWmCRlV);
    int LkGKHtXtBMLFZz(int orWwRt, int Sfkdwuf, double LELstex);
protected:
    string XuqTWOLwoyMaoHS;
    bool PrdOteeY;
    bool ifyAHJRVbjMzJb;
    double OYURnQffgUlCDg;
    double PtSlWpDEKGWVBzBc;

    double tGsFCRcklm(int GmtIpxcbXQBchi);
    void CUTPDyls(int PghUov, int fYgwrh, int yWZigYmNVpyEG, string lBHrsFLSxH, int yGBSrIvCDfQx);
    int hAZYVZllmDXI(bool XuSUnulwkBUU, double IuyShUCjVlRGDDY, int mDfplgVfbtwZJR, bool nyDXwacPx);
    double YCLTwhEOwRH(double jVWUyjnXHio, string NUIEDNbtJHpzemGs);
private:
    bool jRScOwbilXzJIF;
    string GuswHCCtjxPUgGbm;
    bool UxCRBbTQVd;
    bool RJLeFk;
    int RMAGBLHtQhlfpXYD;

    bool ZXYNMlC(int fCtLqNmoD, bool RIhzem);
    bool DXDoDxgbWqYUZHz(int gpLXTEukGXmiv, double zEeDlmu, double UajjYlMtCXqev, string DdKVWXWRJN, double mKrNnZTSubA);
    void oMaTJKQxg(double WJwkyK, bool RLuNTQfuqBZ, int AULHJ);
    double EIyLp(int YSIDNbtZIvQX, double iQYclTX, bool zopzhdxmep);
    void ojdFvp(double vHICYVFimKOl, bool OKIrEEibNe, double RstqJgoo, bool EWdPEczzisZ, bool UhapVqiRpM);
    int YwjkERYJwTG();
};

int lYlFxEiVCTp::hEwzDVtMUQcEef(bool FhcSoDmAeehAj, bool WoweiC, int QrXZCJXHHZiMhu)
{
    bool GUyhIS = true;
    double sjATPB = 231884.5852741414;
    double wRZnSgsvgAP = 540486.8620698777;
    int NuDNbanqlUd = 417410450;
    int yGvYIYU = 1202517133;
    double ibTneoO = 20595.54112358186;

    for (int MWJeSmbevP = 1004522049; MWJeSmbevP > 0; MWJeSmbevP--) {
        wRZnSgsvgAP -= sjATPB;
        sjATPB -= sjATPB;
    }

    if (QrXZCJXHHZiMhu <= 417410450) {
        for (int FQwtklKMowPdJXzm = 777853713; FQwtklKMowPdJXzm > 0; FQwtklKMowPdJXzm--) {
            sjATPB = ibTneoO;
            WoweiC = FhcSoDmAeehAj;
            ibTneoO *= wRZnSgsvgAP;
            GUyhIS = ! FhcSoDmAeehAj;
        }
    }

    if (WoweiC != true) {
        for (int XXtabqEBIatgJog = 2098398695; XXtabqEBIatgJog > 0; XXtabqEBIatgJog--) {
            NuDNbanqlUd += NuDNbanqlUd;
            ibTneoO /= sjATPB;
        }
    }

    for (int pQTHywPwK = 1233866895; pQTHywPwK > 0; pQTHywPwK--) {
        QrXZCJXHHZiMhu *= yGvYIYU;
    }

    return yGvYIYU;
}

string lYlFxEiVCTp::gvZkxhkno(bool FoeNJ, string tFySJIUr, string WtFKaHCyTL, double nlarrBHJGbLLOfKS, bool kbRvwkUDW)
{
    int xsuFwTxWidMjwP = 1975899495;
    bool gWrZeIru = false;
    string wAizeLIigE = string("jolsENGrZgcXahzcHjERyhPEZcoHEFXtCvJrQRuxVnDBvhbMstFcVBUpDUXTFSkuuXAvrMNNmCngrzblzeOX");
    double DrTDsHRNqEy = -775458.8975501871;
    string APQUO = string("sBIAQwLnGeZkUZzvYAlsfBIogVIxCWPdksWgDUTAxkuqyWpyyjXfSxKZALo");
    string AJpGpgDANmCcPvDY = string("msQLQqbFEFfMcbqSPBfdRrsUmeEisClRZVSaZVobAGQcRKjhhclJNPJoSoQUNeyCByradSFcPCLhWwOaUxavDMClWTFShgYAJkBYmaBAbTISIMASsOwMOOGnpIMigrItzZpUZtTFLtRLQRKRvAigvWlLoghqGrRxusWgTvogCkzmiiHWrFNxpEhnRpghNk");
    string nsLXiix = string("JOMzAfcqNKNnryvKlxpUvTUNqjmWgnaNmlzpIqHukQVfKlkEdKQLRezXheJFQSHiFMBeHhTaZtnAUERtGUUzkXgAKjfrsIfZ");

    return nsLXiix;
}

int lYlFxEiVCTp::bdlSWn(int saxxvuIIPHWmCRlV)
{
    bool cBqAs = false;
    bool gNNMJH = true;
    int ZUUSdEPEgttFtUoT = 1984992844;
    double MVfOodI = -951110.9907233935;
    int eavqtWKeqTJjZjMa = -1698131323;
    int teTYZAr = -248067916;

    if (MVfOodI == -951110.9907233935) {
        for (int jDpcQtPEVkfIVKc = 969385005; jDpcQtPEVkfIVKc > 0; jDpcQtPEVkfIVKc--) {
            gNNMJH = ! gNNMJH;
            saxxvuIIPHWmCRlV -= ZUUSdEPEgttFtUoT;
        }
    }

    if (MVfOodI >= -951110.9907233935) {
        for (int azsFmbRnqGG = 347243103; azsFmbRnqGG > 0; azsFmbRnqGG--) {
            saxxvuIIPHWmCRlV -= saxxvuIIPHWmCRlV;
            ZUUSdEPEgttFtUoT *= eavqtWKeqTJjZjMa;
            teTYZAr /= teTYZAr;
            ZUUSdEPEgttFtUoT = teTYZAr;
        }
    }

    return teTYZAr;
}

int lYlFxEiVCTp::LkGKHtXtBMLFZz(int orWwRt, int Sfkdwuf, double LELstex)
{
    double yvInqaZ = 663944.3911265888;
    bool ragmXbDoP = false;
    int VofwWCvooP = -1482765910;
    bool GJsnwVnoMfw = true;
    double RMpolPXsWyBlCBAw = 772462.7856964841;
    bool MXuTPmAduyCc = true;
    string hmXEuIx = string("OidTnfZNvUFGWWqUzZsQGgYXMOOTLPHkcOcElCDNxDJcMBoHALfPeAhFckEnKEBKrrzVYOXlCVKjBkRbLwoiDoaKaIYPVccBXoEospRLqTjAOBXqhqPWiQrzcMjnyeupdQcZDYTBqVGidjxGpCeAvwHhtqgbMVEabybTVJIhYDEmkNFVTlBSkXSbOZZcQEd");
    string yCWXBEfdZiDrwNv = string("oCGETIstWAnqqQTTUIhEhFuoPcLIkWimCujaLkyk");
    string iYJhKlTRco = string("dylzGoWJyMyRcdKvUPdAJadqaAHcqlOIsqLXGeDTDmQcOgKPPGMGKrCZuwMBPYxtaQyhGqNeIwFpSCgnEAHHudmRAfKXYjqWKVqwvZzCClHzyohzHuEaDOwHuVNoEhqTOljBRDrqPCkrWerfLJROBWQXy");

    for (int LGcuicmJ = 903162993; LGcuicmJ > 0; LGcuicmJ--) {
        continue;
    }

    for (int COfIfLQYGGzoGfA = 2050039464; COfIfLQYGGzoGfA > 0; COfIfLQYGGzoGfA--) {
        continue;
    }

    return VofwWCvooP;
}

double lYlFxEiVCTp::tGsFCRcklm(int GmtIpxcbXQBchi)
{
    double yGseUuYHsQtDytN = 641785.9279488635;
    double GhqXbfzjxtD = -361367.4551234492;
    bool izhrwaXwBDju = true;
    bool sdmgevehu = true;
    bool WazSD = true;
    double LeTKOFcU = -976449.133574359;

    return LeTKOFcU;
}

void lYlFxEiVCTp::CUTPDyls(int PghUov, int fYgwrh, int yWZigYmNVpyEG, string lBHrsFLSxH, int yGBSrIvCDfQx)
{
    string kJOzMphGZkeozeEk = string("sOraLbCGeMGqPmvNoFJtATDsLlxeYgWKToAjZCEcMKaNDIEuXqJdlNaQYfXkTsxnYTGvmxSECPuSYlytJefGfroyweFXDUxsdmHNSDiCeeKZFFegQEsIzPaiwzZFKmQlijYCwqWkXQMEUSLpXPdnhPyzRbzThmKYpKixyCDocNCASPMZlzFujpqYonvqgPucPJZMFaBIDyDXzhELqWjgIKyCClnBWCpKOxCxtSlqqhaDtsixxlIrUERJV");
    int UGdeQev = -1407137762;
    double ntKwVUxDnucYI = -419211.04170011415;
    int WFrnIOgUyOHjP = -69937765;
}

int lYlFxEiVCTp::hAZYVZllmDXI(bool XuSUnulwkBUU, double IuyShUCjVlRGDDY, int mDfplgVfbtwZJR, bool nyDXwacPx)
{
    double xZyGM = 829931.6431390999;
    int nujtcGb = -1935078236;
    int nsVHgZ = -1968105493;
    double ISveUXKKqJS = 430492.9514632771;
    bool ekbVqON = true;
    bool rKEEFhgalMVwNgJh = true;
    string AadmLztzhkxy = string("UvyZHiLNnXFOAUHPFnsPLCZaZMUPLpiijPjzMbzxGzTLaKbfVpVjCNbwcWySYJoCLXQRcxabLJgGDeeJgwBqLaaQncfFn");
    int vLZnrrdVajehx = -1153069879;
    string Fhert = string("oxMsCJDvhcdHf");

    for (int bAntTbRbyQBVl = 591776155; bAntTbRbyQBVl > 0; bAntTbRbyQBVl--) {
        XuSUnulwkBUU = rKEEFhgalMVwNgJh;
        IuyShUCjVlRGDDY *= IuyShUCjVlRGDDY;
    }

    for (int VeuUlMUV = 108517447; VeuUlMUV > 0; VeuUlMUV--) {
        ISveUXKKqJS /= IuyShUCjVlRGDDY;
    }

    for (int AELZFwLjyjAyGcAJ = 450644613; AELZFwLjyjAyGcAJ > 0; AELZFwLjyjAyGcAJ--) {
        mDfplgVfbtwZJR -= nujtcGb;
    }

    if (rKEEFhgalMVwNgJh == true) {
        for (int mSralzBHP = 195597733; mSralzBHP > 0; mSralzBHP--) {
            Fhert += AadmLztzhkxy;
        }
    }

    for (int CKXOKd = 1714181485; CKXOKd > 0; CKXOKd--) {
        ekbVqON = ! rKEEFhgalMVwNgJh;
        ekbVqON = XuSUnulwkBUU;
        XuSUnulwkBUU = ! XuSUnulwkBUU;
        vLZnrrdVajehx -= nsVHgZ;
    }

    return vLZnrrdVajehx;
}

double lYlFxEiVCTp::YCLTwhEOwRH(double jVWUyjnXHio, string NUIEDNbtJHpzemGs)
{
    string AsivdgykaqgLtzir = string("VWTmqnFmZdMtzmuxikPAnxrDaMfnNgXlzAvpvsVtolifqWDwcGJazmFnSLibaACweuyhpgCiZGUXqSdAEKVrzIyASMiDZCMGVYHSfolQRlHblJtBqalqtxCfcwVlUtzEKGMjOzKweDJWMlWRnHkoqOrJdpSJxOcJTIfwzjagmBxMLZiVksbPrQgAknrmromFsncOpEDfXJNbnMirBNRlIWEJtxDHZoByrDMitLArHMIkRMyUkMNTiHOlBSkGyy");
    bool rljeuDXuVIQaQ = true;
    int nTTqz = 943432032;
    bool caBwWhuHwt = true;
    int yETcfOosQv = 2066332822;
    string PClkVux = string("ocrdPmgqfByxkMzpuPrYCxPfBeSsJdpJkSFFBlphOgblisQEQDiDaebWJCiLfUPMJktswAJyGDowoDfjvMmhmurVxWCdHUpAmLuFCdYDTzPMVNmDWGZnbzIOSpumqIVMsUcQwYNV");
    string BGEbh = string("psTQkOmqgKOmORcs");

    for (int cavMzXAW = 869030796; cavMzXAW > 0; cavMzXAW--) {
        caBwWhuHwt = rljeuDXuVIQaQ;
        NUIEDNbtJHpzemGs = BGEbh;
        caBwWhuHwt = ! rljeuDXuVIQaQ;
    }

    return jVWUyjnXHio;
}

bool lYlFxEiVCTp::ZXYNMlC(int fCtLqNmoD, bool RIhzem)
{
    double sNslfaSuQCRDzTqF = -739478.0535629021;
    string PXMbq = string("mAdAHUCLQMTsXIPZ");
    double nveSIz = 618702.8505027619;
    bool bDsuNxSfdECfd = true;
    int jCiqBNfiyiNJZko = 1301341367;
    int iJdrd = 1662249002;

    for (int jJNWknib = 2024933198; jJNWknib > 0; jJNWknib--) {
        fCtLqNmoD -= iJdrd;
        iJdrd -= iJdrd;
    }

    if (PXMbq > string("mAdAHUCLQMTsXIPZ")) {
        for (int EPnoHUAxm = 510744787; EPnoHUAxm > 0; EPnoHUAxm--) {
            iJdrd = jCiqBNfiyiNJZko;
            RIhzem = ! RIhzem;
        }
    }

    for (int ULibbKZpfZPYJg = 720090506; ULibbKZpfZPYJg > 0; ULibbKZpfZPYJg--) {
        iJdrd *= jCiqBNfiyiNJZko;
    }

    return bDsuNxSfdECfd;
}

bool lYlFxEiVCTp::DXDoDxgbWqYUZHz(int gpLXTEukGXmiv, double zEeDlmu, double UajjYlMtCXqev, string DdKVWXWRJN, double mKrNnZTSubA)
{
    bool iSQQcAVFOK = true;
    string UkUHVkpzBrMEqmUc = string("gDsYNBmmNkDwXRvKsVlzfJNUGZPGzxHoPAmhcdRcRgDQsSLStJleKwrnWOmRhXUPSoxC");
    string VgwmaLoFCW = string("qWbBliOGAWgVPOJTnoAyClgxsdGSUoyPiMUyCooWHLbMZFHdywTFNGexGYkjUfUrklpXlQvEhMRGMpOcBdUBmvLKerBsGZdcxayQfKEodzMjeUstA");
    double FKblIqZb = 953409.2857494905;
    double KXydWBOgKfZw = -883401.0239542583;
    bool AwcYcEVyfF = false;
    double dnBKUAVqp = 109802.51336408104;
    double ndOFaIqFksue = 234929.33714661107;
    string xkSdWkAOArGiP = string("JnEzXKdEILMubMEolVhZglpPpDvzUOJHgLiycGloDPUfLIRoVXHWQadQzsyXsSQgJckyQxLHkKptFeheSyqFVoaXJwxstPdptZRZSkFwdIrxboaSBdSdJHwMUiORBZouCfcxLdbdeQqYVkywWEPUTUhaKTOQCsVqnpBsVmURgMTwPYEENZFYeD");

    for (int JfILfMla = 855483286; JfILfMla > 0; JfILfMla--) {
        KXydWBOgKfZw = mKrNnZTSubA;
        zEeDlmu /= UajjYlMtCXqev;
        mKrNnZTSubA = ndOFaIqFksue;
    }

    if (mKrNnZTSubA <= 953409.2857494905) {
        for (int TrCgKoFoGrvJpr = 995481543; TrCgKoFoGrvJpr > 0; TrCgKoFoGrvJpr--) {
            ndOFaIqFksue /= KXydWBOgKfZw;
            mKrNnZTSubA /= FKblIqZb;
            zEeDlmu *= mKrNnZTSubA;
            FKblIqZb += zEeDlmu;
        }
    }

    for (int nawLkuVVQzHXS = 367336759; nawLkuVVQzHXS > 0; nawLkuVVQzHXS--) {
        KXydWBOgKfZw /= FKblIqZb;
        zEeDlmu += dnBKUAVqp;
        dnBKUAVqp /= dnBKUAVqp;
        zEeDlmu *= KXydWBOgKfZw;
    }

    for (int uDenyaofWa = 1436823249; uDenyaofWa > 0; uDenyaofWa--) {
        zEeDlmu *= mKrNnZTSubA;
        DdKVWXWRJN = VgwmaLoFCW;
        FKblIqZb -= mKrNnZTSubA;
    }

    return AwcYcEVyfF;
}

void lYlFxEiVCTp::oMaTJKQxg(double WJwkyK, bool RLuNTQfuqBZ, int AULHJ)
{
    string DlSpQrDNEopalGwA = string("fJtIYtNIHyYSqEsYNlnJMcoAGBkNpnNquoBuVKIzaeuSYUcULgLcwdmQMKAjEzORoToIhhzNNKmzBudtWdcPetkvscREjyaRbzEvlnHQWGSdTeWFbkYaZVIldauchcWzcOMSwHSieTLGYSAJshocoQItAibHHKDbbJwbCtNEbpusMhylZVUgtvMWnxqXiUJOGzdSLmXcnQStkeyAOPCHDiicYaaRpRPvCH");
    double FEAdS = -221645.5144171762;
    int BFnSiCntPzM = 1826515245;
    int TCfZBiwtO = 1875133999;
    string gTEJwvAjeljcTY = string("piabwvKNrZGcpJMiicsRWsTEjqykgQMGoiWMDefQcRYAsWxFBWvxRFuZoKpIQJwhfWQaioWPdxKFebOolYPUYHgTPDWxAlacUaUqkNDeUuRKOMsEtvZIRVnuwIZWiRUJIXZBaNyJGTQvHSkobYOPOrUcpsXibVgCONBZzCcSOOwWmOZSGzFDDvtnScTWUxSRjPMpKEGwVlQbDEeRHjAzUuAJLKQugunxedYqzWLOLFTteFLYJYVREqVveZGFAy");

    if (gTEJwvAjeljcTY >= string("fJtIYtNIHyYSqEsYNlnJMcoAGBkNpnNquoBuVKIzaeuSYUcULgLcwdmQMKAjEzORoToIhhzNNKmzBudtWdcPetkvscREjyaRbzEvlnHQWGSdTeWFbkYaZVIldauchcWzcOMSwHSieTLGYSAJshocoQItAibHHKDbbJwbCtNEbpusMhylZVUgtvMWnxqXiUJOGzdSLmXcnQStkeyAOPCHDiicYaaRpRPvCH")) {
        for (int DPrHcERhcTGoaZBh = 514596905; DPrHcERhcTGoaZBh > 0; DPrHcERhcTGoaZBh--) {
            AULHJ += TCfZBiwtO;
            AULHJ *= TCfZBiwtO;
        }
    }

    for (int YJrYMxG = 873523556; YJrYMxG > 0; YJrYMxG--) {
        continue;
    }

    for (int bjleRvDWJP = 593648873; bjleRvDWJP > 0; bjleRvDWJP--) {
        FEAdS *= FEAdS;
        AULHJ /= BFnSiCntPzM;
    }

    for (int lmHEyQVXxAnaY = 963569974; lmHEyQVXxAnaY > 0; lmHEyQVXxAnaY--) {
        continue;
    }
}

double lYlFxEiVCTp::EIyLp(int YSIDNbtZIvQX, double iQYclTX, bool zopzhdxmep)
{
    double VcgRdoqgry = 365739.23201829166;

    if (zopzhdxmep == true) {
        for (int jazzMHWnruYp = 1821942147; jazzMHWnruYp > 0; jazzMHWnruYp--) {
            VcgRdoqgry = iQYclTX;
            YSIDNbtZIvQX *= YSIDNbtZIvQX;
            VcgRdoqgry *= iQYclTX;
            VcgRdoqgry -= VcgRdoqgry;
            YSIDNbtZIvQX *= YSIDNbtZIvQX;
            iQYclTX *= VcgRdoqgry;
            iQYclTX -= VcgRdoqgry;
        }
    }

    for (int oUKNHPZg = 207986754; oUKNHPZg > 0; oUKNHPZg--) {
        zopzhdxmep = ! zopzhdxmep;
    }

    if (YSIDNbtZIvQX < 1167772902) {
        for (int EPypkhgb = 356867110; EPypkhgb > 0; EPypkhgb--) {
            VcgRdoqgry -= iQYclTX;
            YSIDNbtZIvQX = YSIDNbtZIvQX;
            iQYclTX -= VcgRdoqgry;
            iQYclTX *= VcgRdoqgry;
        }
    }

    if (VcgRdoqgry >= 365739.23201829166) {
        for (int QtYTHova = 414198391; QtYTHova > 0; QtYTHova--) {
            continue;
        }
    }

    return VcgRdoqgry;
}

void lYlFxEiVCTp::ojdFvp(double vHICYVFimKOl, bool OKIrEEibNe, double RstqJgoo, bool EWdPEczzisZ, bool UhapVqiRpM)
{
    string ynQJfXQqtNSiL = string("rXEyjuRuRLKFNwPsGMHIqhTOTelUFzKYAFnttInEcRRDEUVEqQOPDypKmtBdyKxKZAiskqbLdArICRJzqWrnNPewhMcFvOtTtvrFOBNejhTYTsQoruNYeVtuWFAXjyEYihUdXTmaotCJdsTIvodkbdXbVLQrTAaukoTvkQaqERcdrujnvDyJN");
    double QzsHqgXBVrc = 1030648.9085894038;
    bool itiye = false;
    bool DGjDpOfiOLNhIHjX = false;
    string lCuJsAMZKRJnpQO = string("GlbmthOLceFXQALDUnTWNJUVubNKVQFedLRWUJkFdvPDqwjBkMhpPvtbMjNzGzzGAVMnqqJfXylDlsDJwHaafceSynlrYmqQzmjkfmgKzywIgleBywIFockBWtRpgHIgrTBLRkfiCzhKuDaHKpTJuEHobHwvQbiImdpvykErfPTviklRPXXX");
    double bqPTqEmNrEMJ = 506084.85342882713;

    for (int tqoGLpmypD = 2107985536; tqoGLpmypD > 0; tqoGLpmypD--) {
        bqPTqEmNrEMJ *= RstqJgoo;
        DGjDpOfiOLNhIHjX = OKIrEEibNe;
        DGjDpOfiOLNhIHjX = ! itiye;
    }

    for (int jEtVewISdaF = 712418876; jEtVewISdaF > 0; jEtVewISdaF--) {
        continue;
    }

    if (EWdPEczzisZ == true) {
        for (int XuusLddqitUl = 373970186; XuusLddqitUl > 0; XuusLddqitUl--) {
            itiye = UhapVqiRpM;
            bqPTqEmNrEMJ /= bqPTqEmNrEMJ;
        }
    }

    for (int cTMKSYzACatstgf = 1605876551; cTMKSYzACatstgf > 0; cTMKSYzACatstgf--) {
        UhapVqiRpM = DGjDpOfiOLNhIHjX;
        bqPTqEmNrEMJ /= RstqJgoo;
    }

    if (RstqJgoo < 506084.85342882713) {
        for (int vcADq = 1948081858; vcADq > 0; vcADq--) {
            ynQJfXQqtNSiL += lCuJsAMZKRJnpQO;
            OKIrEEibNe = ! DGjDpOfiOLNhIHjX;
            itiye = ! itiye;
            bqPTqEmNrEMJ /= bqPTqEmNrEMJ;
        }
    }
}

int lYlFxEiVCTp::YwjkERYJwTG()
{
    bool dzwjXfYIilYQ = true;
    double dFuYc = -49945.54873431317;
    double VLZAmgCzO = -570317.7355065242;
    double kNUpSqx = 9874.456849331646;
    string tzpXZ = string("qWHynZcoXVkfNOKmltWwlcOgqdjTKYKeujBjsReHaNAEWmDikao");
    bool VUFpcFHOf = false;
    bool jNuvFCczgQyTzL = false;

    for (int sWaiCgL = 477950606; sWaiCgL > 0; sWaiCgL--) {
        jNuvFCczgQyTzL = jNuvFCczgQyTzL;
        tzpXZ = tzpXZ;
        VUFpcFHOf = ! VUFpcFHOf;
        VUFpcFHOf = ! VUFpcFHOf;
    }

    for (int spMGdCcZv = 438040729; spMGdCcZv > 0; spMGdCcZv--) {
        jNuvFCczgQyTzL = ! dzwjXfYIilYQ;
        kNUpSqx -= kNUpSqx;
        dzwjXfYIilYQ = VUFpcFHOf;
    }

    for (int ULIbldocgbBdU = 658323037; ULIbldocgbBdU > 0; ULIbldocgbBdU--) {
        jNuvFCczgQyTzL = ! VUFpcFHOf;
        jNuvFCczgQyTzL = ! dzwjXfYIilYQ;
    }

    for (int SRRUcU = 577208625; SRRUcU > 0; SRRUcU--) {
        jNuvFCczgQyTzL = ! VUFpcFHOf;
        dzwjXfYIilYQ = ! VUFpcFHOf;
        kNUpSqx = kNUpSqx;
        VUFpcFHOf = ! dzwjXfYIilYQ;
    }

    return -2121406768;
}

lYlFxEiVCTp::lYlFxEiVCTp()
{
    this->hEwzDVtMUQcEef(false, false, 215265141);
    this->gvZkxhkno(false, string("sOeIFWGAWxFPMuRUkZILSJQAVGgKGSkkrbFuSXHfLvyvTlOlugZoqadWNbiOqgQSdlGSfkckpvIQxQahbNchxHVGOpeTtmlQjYKbauzFpboEBbbzVcamsHxNIEFWqwfnizRSTjyeXKYwxNCGqkdBXohfRihlPwokOPdqCvzphaONNcloUoqOzaUHKfTcPHagFhtXCTiZJYjdXsnpxtFJqfCgwIzEt"), string("FYtaKrpxMxRpkYsEBXVIpbpHJbvhiwVYbfdzEoLMfkkyyThLcqBWlkffJ"), 911666.2349792123, true);
    this->bdlSWn(-953080533);
    this->LkGKHtXtBMLFZz(-825191678, -707643177, -970052.8070624984);
    this->tGsFCRcklm(-951124100);
    this->CUTPDyls(1351445861, 561642695, -710074586, string("LNCWywFPHjXEPjdFjeBBEaWWMBSKZTCTuAzaklNIGbKGqlrsMaQtBIJGhvvBRJVDBDmdeqZGtIwwQKOsLantEWxhJsfCGSSvthPncjCclUtwSzdUfBwDeWaCeEpCOrIyKZowzjIpuheRXalncaLeTkieFxgMzzvkXCKJKYhMhGnQMtGMRduTSelMJVSMf"), -106258103);
    this->hAZYVZllmDXI(false, 922150.5417162214, -535698417, false);
    this->YCLTwhEOwRH(189809.66200715728, string("pXNGPZOSKUYDOpPimXmJowvumdiGKrgIQrIBtSWJMEzQUuNlOSrsVtVVfEyMxmvXAdOEOYCLdXtrvKINjEmVCVpwFixxfxJvORYuSKggAgFkhPKUbuoCCvyHRtezrzmwSRaXlabPpYYodneKxalgWDnpBPXEjbGR"));
    this->ZXYNMlC(1703870574, true);
    this->DXDoDxgbWqYUZHz(-1357687647, 509881.49346293096, -65234.17884462917, string("RPhAXaAcVYbWceEyLgqiTWYucMFPJCgJTtORMdNmZdZGrIzpbdAgRLjUBOUxVMBBL"), -397741.84928552713);
    this->oMaTJKQxg(421245.45247909566, true, -1244049413);
    this->EIyLp(1167772902, 13947.899125424003, true);
    this->ojdFvp(-744967.2704476775, false, 1032293.0797753744, true, true);
    this->YwjkERYJwTG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nFVjUDUfhGke
{
public:
    bool nmwIN;
    string XYhmomIEIresUzod;
    bool kVcDcfY;

    nFVjUDUfhGke();
    void moFmh(double mEqyUeWfarBZEju, int NfhPRyxi, double AZAzdiWT, bool eRywi);
    void IwqWwuJqo(string XCqWqNBLdjg, string BakeSlxHyyZaowTu, string mrfftwUr, int ieddCssNfuLP, bool qpAvk);
    void reXRmRsA(double HFrnhhhkInBD, int lQYObM, int ESwIhYtPI, bool scOSIIrrE);
    int msAFePVbkMR(string uCKrfCDJL);
    int tZWbLoBFs(string zgsbXYlzkVCYYvtN, double wQWDgGlcchPpofN);
    string dGhfMgEiVv();
    void hdbhOGe(bool mdYOATxToJJSzUbb, int yaiThKm, int Ldmdin, string cDvwHNCdXtdjEuFL, bool FOhtquQJZYK);
    double grCMjvBJbUO(int VlDGP, string PIprwFltoQaWP, int hzWirYsKHHN);
protected:
    bool raaAvZzOW;
    string UQMcGt;
    bool KSuBJhXWOcSRvs;
    bool nTawiqJaUZMpaocJ;
    int KVflWLWcwstU;
    bool JinVESq;

    bool tQegMUcASkdEnWR(string oOIOhJQnLBbQ);
    string xRIbJ();
    double ywfmWmyLVNJ(double ofnEzYIJ, int bfuTvwYIFrxIOJDB, int yWBmfXyIfgVwlb, bool tXIHtWucIi, string mgfJhV);
private:
    string stKpFirJoMbqz;
    string KfZWjzS;
    double FrlRf;
    double JsVVdAMHRJW;
    bool AkHGvZrnrFnxDqC;
    bool momsCT;

    string QzmqFJZRVqc(string amHfev, string GHgqRyzy, string yJWpwA, double CiAyBKrETD);
};

void nFVjUDUfhGke::moFmh(double mEqyUeWfarBZEju, int NfhPRyxi, double AZAzdiWT, bool eRywi)
{
    bool wKSYQFuArQW = false;
    string EbEJSiQxyeu = string("zUJVjatxPmsygxOmXIQUOReYVUPdpSZiXHVUbTYTKzIXxFYfByBOpwMGzdwFrbfJNWYKwWlvjMptPFyLQIFAOxevIDcUdDsmDNXqmZUEyoZzKgxkqfMjdZgjoMkfcreefZddLDhKC");
    bool fFjAoEAAGdePKVxt = true;
    double csZhTHSQwMfjMjS = 341473.1337645361;
    double JNufGnlK = 659335.2284427513;
    string AFgZyBKCZbSZMxq = string("THiaIyxBSNHgwBDKidsmPAKFbRYOWKeHAVtvojqUupkNJJrhQBjuRhVf");
    string rYAomvzUzpNeXO = string("iqHOqBIAcSQFvjIFBzkJwzxvKJvmmjpalWgdAipFzYUJZgPPwDzBFyIdnyZeJdOxBrKRPESjXMqWHkaSXfhCgjlAYCENCeyozrSrlnreueOMDnInhTzSPLsAuusFNVELtkMDSxvVyoVvntgNpfnhcqiaHKOCA");

    for (int ygBhb = 2036621277; ygBhb > 0; ygBhb--) {
        wKSYQFuArQW = ! eRywi;
        AZAzdiWT -= mEqyUeWfarBZEju;
    }

    for (int dyiYRym = 865588004; dyiYRym > 0; dyiYRym--) {
        EbEJSiQxyeu += EbEJSiQxyeu;
    }

    for (int tKAYcaZ = 1492275330; tKAYcaZ > 0; tKAYcaZ--) {
        AZAzdiWT -= AZAzdiWT;
    }
}

void nFVjUDUfhGke::IwqWwuJqo(string XCqWqNBLdjg, string BakeSlxHyyZaowTu, string mrfftwUr, int ieddCssNfuLP, bool qpAvk)
{
    string tSDhDSlaHRpmGUB = string("PILLwrLCOUJsykCFmjcmAxmRsxDuicnAFgAMcebzCAZPMwBlMOqpDPIxWJIyopSljnFUfkXPUzfKMEoRqIBYEeEtGzYAFSCqtAnLUXoMXUgHSZyQGGkMzqSffbamuwXnSEftwKrPJriL");
    int NynngcyYENc = 1294003147;
    bool sLEzFhIHeG = false;
    string jXSdXxLfYe = string("JwWtHROlrUucESVgucXYWMAlkioEuoPFgPGfEKDqlOlWndOmSkrGQdAzGcqRKvoaHKhYwcGubgfKuvifUBwSfaPBlTrCpWhwLwmusAqOajbWEODKZFcwguxnTqEHBQfAqDeYMKnCqVlUVNmSbALBbFOcmLvLYQN");
    int xeMyJTKVpvqLEKG = -1085944673;
    double icGbsoGehTaZn = -1046457.6725495908;
    bool HLNeOMMEIyQRsuKC = false;
    double yFFKW = -469464.09095752146;
    int gMBQGKRdLiM = -2127504682;

    for (int fuoXylfmFGtkh = 277457689; fuoXylfmFGtkh > 0; fuoXylfmFGtkh--) {
        ieddCssNfuLP += gMBQGKRdLiM;
    }

    for (int mndHuYqQdFKTOq = 1470660556; mndHuYqQdFKTOq > 0; mndHuYqQdFKTOq--) {
        ieddCssNfuLP -= ieddCssNfuLP;
    }

    for (int JmUHwBKnQeExm = 1707819531; JmUHwBKnQeExm > 0; JmUHwBKnQeExm--) {
        jXSdXxLfYe = jXSdXxLfYe;
        XCqWqNBLdjg = tSDhDSlaHRpmGUB;
    }

    if (mrfftwUr == string("PILLwrLCOUJsykCFmjcmAxmRsxDuicnAFgAMcebzCAZPMwBlMOqpDPIxWJIyopSljnFUfkXPUzfKMEoRqIBYEeEtGzYAFSCqtAnLUXoMXUgHSZyQGGkMzqSffbamuwXnSEftwKrPJriL")) {
        for (int kyjjHxiSykYgNF = 778509731; kyjjHxiSykYgNF > 0; kyjjHxiSykYgNF--) {
            XCqWqNBLdjg += mrfftwUr;
            XCqWqNBLdjg += XCqWqNBLdjg;
            BakeSlxHyyZaowTu += jXSdXxLfYe;
            mrfftwUr += tSDhDSlaHRpmGUB;
            HLNeOMMEIyQRsuKC = ! sLEzFhIHeG;
        }
    }

    for (int NupqoCRv = 1441983386; NupqoCRv > 0; NupqoCRv--) {
        xeMyJTKVpvqLEKG *= xeMyJTKVpvqLEKG;
        BakeSlxHyyZaowTu = jXSdXxLfYe;
        XCqWqNBLdjg += jXSdXxLfYe;
    }

    if (mrfftwUr >= string("lVRwYbXmvOmoiucaAFNWFxkZgrIfWvOAFBHJbuZCpSsOkkOQLIcooDzckrAaiJYxfbyVubyPWxjRHCIuXiMQjVOTrjOfIXVGRsSMWLzlBsnAkRJfgKtdTacsBsFlwzVfRByesveosnRkxcMPTGUqQWzHQhJBXlhbvRFTRcFRHNXoiTwIkolhdijhClIPrzAcdougsifqGRQVi")) {
        for (int pKTsNHFbzDZjDK = 1496515366; pKTsNHFbzDZjDK > 0; pKTsNHFbzDZjDK--) {
            ieddCssNfuLP /= xeMyJTKVpvqLEKG;
        }
    }

    if (qpAvk != false) {
        for (int VPMpjMyGO = 1214289554; VPMpjMyGO > 0; VPMpjMyGO--) {
            ieddCssNfuLP += NynngcyYENc;
        }
    }
}

void nFVjUDUfhGke::reXRmRsA(double HFrnhhhkInBD, int lQYObM, int ESwIhYtPI, bool scOSIIrrE)
{
    int UEZPZPAwxLVvccag = -199270651;
    string ygOdonlOPRvKgo = string("hpZDqgObHAyZfyIlsqxQIEkFJZgPMvLjFvtPCbcBOWBmDBtDjhPzYnXwEcKAjvxdczPbXmQbKLYuEMXFmJEecUeFeku");
    int ZzaSlsXavXKbpqV = 1789535179;
    string FDOAtkFTllJTdW = string("VsDUiAzsKJeGbLxvhONLoMjzhzHiWpuRugELZObkFkESGrMHQRCUtgyHxnxbezrmvlNqoVgWqIkcVLOehyNPCbBRFIyjmeqKjDebPwNoqmykvCgnQhNsZxBWuklPSnlDOqlaSQVOKaOChUGmwVHrUKzfjkabSTeBEjTiALMfAp");
    int PcgHsctwxHNZLty = 1833747699;
    bool UcElcQEPrS = false;
    string PtmPaQqDDLAP = string("hbDQkoLFDfTQxxXMEcM");
    int KplruIhziEJL = 242540968;
    string AFxPWTbF = string("tdEpgKFFBXdcjUTbnIhfltGMOMAVPWAteGApeafKesPoRUgQGZlqRfLlXMipkjIDuVjilHKKsgEvnNhjLnsHdTYJmQbfRVBPhkETvxIMFxeFtsloPCwOuCYqpNrSmrKIaVjLrFwyPDdekctAYaEhJrseWeFABmRQmHKcKvWlzEVWebTVBmgotSMztgOjYCgesDfNUBjFPiuzGGbIvLEsCjTOMLKaiBOvBPCNQzyYe");

    for (int CpuJT = 1142815535; CpuJT > 0; CpuJT--) {
        AFxPWTbF = PtmPaQqDDLAP;
    }

    if (ESwIhYtPI >= 1833747699) {
        for (int EYtNeEyAfWpgiGa = 2134919041; EYtNeEyAfWpgiGa > 0; EYtNeEyAfWpgiGa--) {
            UEZPZPAwxLVvccag *= lQYObM;
            PtmPaQqDDLAP += FDOAtkFTllJTdW;
            ESwIhYtPI += ESwIhYtPI;
        }
    }

    for (int MbXVRHkEt = 1520561725; MbXVRHkEt > 0; MbXVRHkEt--) {
        scOSIIrrE = ! scOSIIrrE;
    }

    if (ESwIhYtPI > -199270651) {
        for (int hKDWBJHGgZtRmVj = 1801088998; hKDWBJHGgZtRmVj > 0; hKDWBJHGgZtRmVj--) {
            ESwIhYtPI = ZzaSlsXavXKbpqV;
            FDOAtkFTllJTdW += AFxPWTbF;
        }
    }

    for (int XEaApZRqJzcuCvz = 1782854909; XEaApZRqJzcuCvz > 0; XEaApZRqJzcuCvz--) {
        continue;
    }
}

int nFVjUDUfhGke::msAFePVbkMR(string uCKrfCDJL)
{
    string vyhUKkFPTz = string("KWkAkYjPnBNeQmZRUmNNtDjIXxvIKVxLTBSkWDLJDriyeTshYqyArhzDeYnFKBVtgaHCQqJQLXdubKxGzsCJfOrvtWtfCXDGhcofxSsmDYRKBXIKSVsmeGwFKyZCMXYBHcqFqmqkBpFKEZDFTwjBAdJPwTWjyHiSdiPaBCcinScEyaLGdBMrkyphtlwcltaHhfmiEGezoVtTzuwTrOOKGdBsbjHVqCCbhSrFlfwJIVeYvDs");

    if (vyhUKkFPTz == string("KWkAkYjPnBNeQmZRUmNNtDjIXxvIKVxLTBSkWDLJDriyeTshYqyArhzDeYnFKBVtgaHCQqJQLXdubKxGzsCJfOrvtWtfCXDGhcofxSsmDYRKBXIKSVsmeGwFKyZCMXYBHcqFqmqkBpFKEZDFTwjBAdJPwTWjyHiSdiPaBCcinScEyaLGdBMrkyphtlwcltaHhfmiEGezoVtTzuwTrOOKGdBsbjHVqCCbhSrFlfwJIVeYvDs")) {
        for (int jYiLh = 1026869635; jYiLh > 0; jYiLh--) {
            vyhUKkFPTz = uCKrfCDJL;
            uCKrfCDJL = vyhUKkFPTz;
            uCKrfCDJL = vyhUKkFPTz;
            uCKrfCDJL += vyhUKkFPTz;
            vyhUKkFPTz += vyhUKkFPTz;
            uCKrfCDJL = vyhUKkFPTz;
        }
    }

    if (uCKrfCDJL == string("KWkAkYjPnBNeQmZRUmNNtDjIXxvIKVxLTBSkWDLJDriyeTshYqyArhzDeYnFKBVtgaHCQqJQLXdubKxGzsCJfOrvtWtfCXDGhcofxSsmDYRKBXIKSVsmeGwFKyZCMXYBHcqFqmqkBpFKEZDFTwjBAdJPwTWjyHiSdiPaBCcinScEyaLGdBMrkyphtlwcltaHhfmiEGezoVtTzuwTrOOKGdBsbjHVqCCbhSrFlfwJIVeYvDs")) {
        for (int ehGoxam = 1877755321; ehGoxam > 0; ehGoxam--) {
            uCKrfCDJL += uCKrfCDJL;
            uCKrfCDJL = vyhUKkFPTz;
            vyhUKkFPTz = vyhUKkFPTz;
            uCKrfCDJL += uCKrfCDJL;
            uCKrfCDJL += vyhUKkFPTz;
            uCKrfCDJL += uCKrfCDJL;
            uCKrfCDJL = vyhUKkFPTz;
            uCKrfCDJL += vyhUKkFPTz;
        }
    }

    if (vyhUKkFPTz > string("HaRxMxSwDjqWrQyrwHFXgnUnAfFWuKzLXCaoujXolhdKsVtKBypAWLPRzOSqOtvPdPbvRPsPxvQeiIZmTOgrlilRcrImQJbDwTELNRqAxURShtDoxMZkRXpBZZj")) {
        for (int bCApyGeicc = 103045245; bCApyGeicc > 0; bCApyGeicc--) {
            uCKrfCDJL = uCKrfCDJL;
            vyhUKkFPTz += vyhUKkFPTz;
            uCKrfCDJL += vyhUKkFPTz;
            vyhUKkFPTz += vyhUKkFPTz;
            vyhUKkFPTz += uCKrfCDJL;
            uCKrfCDJL = uCKrfCDJL;
            uCKrfCDJL += uCKrfCDJL;
            uCKrfCDJL = uCKrfCDJL;
        }
    }

    return 2041016700;
}

int nFVjUDUfhGke::tZWbLoBFs(string zgsbXYlzkVCYYvtN, double wQWDgGlcchPpofN)
{
    string CBfBLCiZqSLAq = string("uJhZCUuyFHYsPgwBzYZoIqzMiJYZRLQzZqsSQJaPGKyYhHTQRrSTszAYYhtARAxljvouPDksuVqToOkdujtHLMAXRvqocsoBNfRjdDuQHJcFOlWDidHDXGaettjIOleHWGZgEkSjYEdSKYqCGGzUoJZNrcphmvUFaacOBcwRgHpY");
    string onRxg = string("dhQw");
    bool WRGKwAzBCWctElTh = false;
    double THwbisf = -172660.13451333536;

    if (zgsbXYlzkVCYYvtN >= string("QTpgHEduxaUJAuyirjzkEBSDfguzQtqFEZVCHZSIQMPIsqJGDXEdQkvaQfnUgCevTkFOdcfuHdCrAVoQLTCcfVQyBYMUVzYvkvVcghIsFCjhpbpooRIOyOvkIFZjlRamhXwHjNvwlzNBjpFQibgYPhLbacDJurWOTnNBuUlZQXsg")) {
        for (int HiOAl = 1100965504; HiOAl > 0; HiOAl--) {
            onRxg += onRxg;
            THwbisf *= wQWDgGlcchPpofN;
            onRxg = onRxg;
            wQWDgGlcchPpofN *= wQWDgGlcchPpofN;
            onRxg += onRxg;
        }
    }

    if (CBfBLCiZqSLAq <= string("QTpgHEduxaUJAuyirjzkEBSDfguzQtqFEZVCHZSIQMPIsqJGDXEdQkvaQfnUgCevTkFOdcfuHdCrAVoQLTCcfVQyBYMUVzYvkvVcghIsFCjhpbpooRIOyOvkIFZjlRamhXwHjNvwlzNBjpFQibgYPhLbacDJurWOTnNBuUlZQXsg")) {
        for (int auSbLbHS = 1609984991; auSbLbHS > 0; auSbLbHS--) {
            onRxg = CBfBLCiZqSLAq;
            CBfBLCiZqSLAq += zgsbXYlzkVCYYvtN;
            zgsbXYlzkVCYYvtN += onRxg;
        }
    }

    return -773496671;
}

string nFVjUDUfhGke::dGhfMgEiVv()
{
    double YFyJOi = -173880.7704577529;

    if (YFyJOi > -173880.7704577529) {
        for (int EkOllPuWO = 1363524533; EkOllPuWO > 0; EkOllPuWO--) {
            YFyJOi -= YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi -= YFyJOi;
            YFyJOi -= YFyJOi;
        }
    }

    if (YFyJOi != -173880.7704577529) {
        for (int kJyCfNvb = 743810539; kJyCfNvb > 0; kJyCfNvb--) {
            YFyJOi += YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi /= YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi = YFyJOi;
            YFyJOi /= YFyJOi;
            YFyJOi /= YFyJOi;
        }
    }

    if (YFyJOi == -173880.7704577529) {
        for (int uqluyU = 588775136; uqluyU > 0; uqluyU--) {
            YFyJOi += YFyJOi;
            YFyJOi *= YFyJOi;
            YFyJOi /= YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi = YFyJOi;
            YFyJOi *= YFyJOi;
            YFyJOi -= YFyJOi;
            YFyJOi /= YFyJOi;
        }
    }

    if (YFyJOi <= -173880.7704577529) {
        for (int MpGwZxTJAAJV = 2037616328; MpGwZxTJAAJV > 0; MpGwZxTJAAJV--) {
            YFyJOi -= YFyJOi;
            YFyJOi = YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi = YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi -= YFyJOi;
            YFyJOi = YFyJOi;
            YFyJOi = YFyJOi;
        }
    }

    if (YFyJOi >= -173880.7704577529) {
        for (int lnwopCicUkR = 1463925933; lnwopCicUkR > 0; lnwopCicUkR--) {
            YFyJOi += YFyJOi;
            YFyJOi *= YFyJOi;
            YFyJOi = YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi -= YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi *= YFyJOi;
            YFyJOi += YFyJOi;
            YFyJOi = YFyJOi;
            YFyJOi = YFyJOi;
        }
    }

    return string("dwJRcKgIRjbgPrrVqSchYKgyuUKXACZGRTuMHDXQFkJnXXOjiLNHRDEMlurHALEismLeLgSByJiCqH");
}

void nFVjUDUfhGke::hdbhOGe(bool mdYOATxToJJSzUbb, int yaiThKm, int Ldmdin, string cDvwHNCdXtdjEuFL, bool FOhtquQJZYK)
{
    double NEmtFyu = 53961.09367237143;
    bool CUwhX = false;
    string wiwTIXd = string("pgEfsknOknJViDrkCjfeBeVuyFJMRJUcqWnVgNAomIfvKCSjNGamkxtXhXncGHxORzGGxWPwvzeFJOjvBRLGb");
    int NgJVajwrEMKeRe = -832159498;
    string BmKsOJE = string("LsvNAkZDWxOwoJJvmpZMebDpqsdEGGsfpYrkNxycCJtPVtvHzOJbjfuyJgHVFGAVUxXgXdPXAFYZXahJosRmsipmKHujLJyBdcEKKbqhKlwrxUVcJDfQmVVWjCKqlzGJkJeoAvxyLGMHhViqAdVtiMDSvpZuCINFCcLYdvpjndslOEbdzZR");
    double XheYmHdWynAN = 244775.80029537695;

    if (cDvwHNCdXtdjEuFL > string("pgEfsknOknJViDrkCjfeBeVuyFJMRJUcqWnVgNAomIfvKCSjNGamkxtXhXncGHxORzGGxWPwvzeFJOjvBRLGb")) {
        for (int rFXkHcYyW = 1078313699; rFXkHcYyW > 0; rFXkHcYyW--) {
            BmKsOJE += BmKsOJE;
            Ldmdin -= NgJVajwrEMKeRe;
        }
    }

    for (int CZVelgOVSzqrp = 1781988552; CZVelgOVSzqrp > 0; CZVelgOVSzqrp--) {
        cDvwHNCdXtdjEuFL = cDvwHNCdXtdjEuFL;
    }

    for (int GSfyNFicR = 1378421330; GSfyNFicR > 0; GSfyNFicR--) {
        FOhtquQJZYK = ! FOhtquQJZYK;
    }

    for (int SchSBsyZHCrZg = 1167754911; SchSBsyZHCrZg > 0; SchSBsyZHCrZg--) {
        mdYOATxToJJSzUbb = mdYOATxToJJSzUbb;
    }

    for (int iclobMvXy = 536403124; iclobMvXy > 0; iclobMvXy--) {
        BmKsOJE = wiwTIXd;
        CUwhX = ! CUwhX;
    }

    for (int aebqVXlAx = 664010699; aebqVXlAx > 0; aebqVXlAx--) {
        NgJVajwrEMKeRe += yaiThKm;
        FOhtquQJZYK = FOhtquQJZYK;
    }
}

double nFVjUDUfhGke::grCMjvBJbUO(int VlDGP, string PIprwFltoQaWP, int hzWirYsKHHN)
{
    double oSQOaqliVtn = 638736.6913371024;
    bool ODommSIxM = true;
    string VklKICgeJSH = string("qKZuZfeRQrnrRSwKcKdTgzKIOZSpWRahNsQnvgOJaHfhqotIJpTgisUfjgRruMbOjmofwIaQqovgexWTuOIIEZlLlNqNldrAYiflrsEWXcrDjkMuQjuYdIRl");
    int jPNrHbTv = 1458079228;
    string aGIWdYUhIKkTyuOk = string("UATxokrqQPJHjpSCokOMDlqMtEWpbYHyAirhZGGFHBQljQAMPNEVgPlcWCbluGjgEsWgypFonBudTDGBDDwpombmNzufzJmpFZgmkfJWUJyXhmDzmynmuqBPZIALYyjxWgWCdNcjzdCbDkmvJQKCacNndIBvmJjx");
    bool BlgWpqsnpb = false;
    string IOdZET = string("AejiYyeUaBGyHpZDloffIzpmAmCvUfxTSCWyflwTOORssuXBQFSaUzxswwlEnPXrkmlJRuKkYxfRsjeGWAWmlNYkKtdNlUWUNRyXKpWeztYVEpqyJjEkFBxLLnpNobDeuSpNmcXapnrqZwUJvAMGgqTNsQogQhTgdGvLSQkx");

    return oSQOaqliVtn;
}

bool nFVjUDUfhGke::tQegMUcASkdEnWR(string oOIOhJQnLBbQ)
{
    bool dQjXCfGO = false;
    double EutvuwOpg = -703767.915804187;
    int CysaThKE = -1749030133;
    int QEUbbmPLqU = 168805328;
    bool ShTWGDKZfrYI = false;

    if (oOIOhJQnLBbQ <= string("gzGzvgfMsNKnmiBEsmrWougbRqZrwtuUvOlCoZMvvcoGEBZCgXIFAcmIJsyCM")) {
        for (int DvauPMLIazD = 1101964705; DvauPMLIazD > 0; DvauPMLIazD--) {
            dQjXCfGO = ShTWGDKZfrYI;
        }
    }

    if (ShTWGDKZfrYI == false) {
        for (int naTdPzFjTuV = 1757222636; naTdPzFjTuV > 0; naTdPzFjTuV--) {
            dQjXCfGO = dQjXCfGO;
            CysaThKE = QEUbbmPLqU;
        }
    }

    if (EutvuwOpg == -703767.915804187) {
        for (int tKIuhDPXSs = 1531512506; tKIuhDPXSs > 0; tKIuhDPXSs--) {
            continue;
        }
    }

    return ShTWGDKZfrYI;
}

string nFVjUDUfhGke::xRIbJ()
{
    bool UrFxSdhF = false;
    bool HbdkjiERejZWgsH = false;
    string AQaPVRNeTJTKyjeD = string("QvDXyeuWbtFaLWaiIHFtKEXJBNhRDqVlKvLayOPgNbqelzVYszHZuQvIQlQqBTOFxEtZDVTPucAMyvcxHcLq");
    double JaxDDBTphawi = 496657.8890454003;
    double tltbIkv = -48601.99718424061;
    double IxnQsJaxqNdtCaen = 534806.9289157289;
    int hOWavVsYdY = 1569305250;
    string ekrdFCYyNaV = string("pUkkUCPCeiNDhULKLpldcgskmPDAzhzZbyFfViAislZreCGJQkYvmJiDlezVcJAASTUgSQYXryDCUCdFFvxeEJQnrPwEAEAJleQqoJkjCqByfQtxSRVtcvXBbRtlDYfyshEshnMGC");
    string hqovQZ = string("enWwmieCLpsfIdarItdjQCoNyMmsoub");
    bool axnTD = false;

    return hqovQZ;
}

double nFVjUDUfhGke::ywfmWmyLVNJ(double ofnEzYIJ, int bfuTvwYIFrxIOJDB, int yWBmfXyIfgVwlb, bool tXIHtWucIi, string mgfJhV)
{
    int gkNfeD = -354515003;
    bool qRIiBWdzKbIc = false;
    bool DEJULvx = true;
    bool WWjCwJfQzzjjpemG = false;
    int hHmEFAC = -2103872833;
    int KoVDLauaTD = -239361145;
    bool ZKhumYMmgtnUzgYn = true;
    string RYQtrQjmVdgl = string("nvcoTnqXvVYAgvASTiuFvSymieLHUTmZTVURvYoOfZWdevikSBDeVgdgWmzxaitvLzXrXIATGTPsFWOtlBoeUuJjmzCePXDyVEqBwSRCtyAdKSIKXmBZydqZwfmimPsmVcsVEgJVyIvDmXZQKXRDXYFlaDjRYwenDOwWZGEIMGwyoWFneyocAoBPnsJqpTBhfTmvagElGqPrXeuwwkGKBkVyVvxZArSLFukFHtDCSPfb");

    if (RYQtrQjmVdgl <= string("nvcoTnqXvVYAgvASTiuFvSymieLHUTmZTVURvYoOfZWdevikSBDeVgdgWmzxaitvLzXrXIATGTPsFWOtlBoeUuJjmzCePXDyVEqBwSRCtyAdKSIKXmBZydqZwfmimPsmVcsVEgJVyIvDmXZQKXRDXYFlaDjRYwenDOwWZGEIMGwyoWFneyocAoBPnsJqpTBhfTmvagElGqPrXeuwwkGKBkVyVvxZArSLFukFHtDCSPfb")) {
        for (int gOJNb = 409058544; gOJNb > 0; gOJNb--) {
            RYQtrQjmVdgl += RYQtrQjmVdgl;
            KoVDLauaTD /= KoVDLauaTD;
        }
    }

    for (int toqDfK = 1314143108; toqDfK > 0; toqDfK--) {
        tXIHtWucIi = DEJULvx;
    }

    for (int bYrrIfHFcSMNYpM = 1315229599; bYrrIfHFcSMNYpM > 0; bYrrIfHFcSMNYpM--) {
        RYQtrQjmVdgl = mgfJhV;
    }

    for (int ckkgbGM = 27246560; ckkgbGM > 0; ckkgbGM--) {
        bfuTvwYIFrxIOJDB /= gkNfeD;
        WWjCwJfQzzjjpemG = ZKhumYMmgtnUzgYn;
    }

    for (int ojPqznhTHreSXTa = 1065900664; ojPqznhTHreSXTa > 0; ojPqznhTHreSXTa--) {
        continue;
    }

    for (int CKXSCzkUDGYGOYom = 1114463975; CKXSCzkUDGYGOYom > 0; CKXSCzkUDGYGOYom--) {
        hHmEFAC *= yWBmfXyIfgVwlb;
        ZKhumYMmgtnUzgYn = ! qRIiBWdzKbIc;
        bfuTvwYIFrxIOJDB -= gkNfeD;
        tXIHtWucIi = DEJULvx;
    }

    return ofnEzYIJ;
}

string nFVjUDUfhGke::QzmqFJZRVqc(string amHfev, string GHgqRyzy, string yJWpwA, double CiAyBKrETD)
{
    string alxSoQfYOLqn = string("WzGxxYXzjzYdFvEMeLlKTtwcJpIEKSkmKGEETcuCJHIdCXOrGUEHtifXPwQWRjvTDIJzpJLcIEX");
    bool vCuudtToROdLuYT = true;
    int LcrWpgLgMhpS = -198032196;
    int NkADMd = -208143524;
    bool anTSY = true;
    int JJHcHdol = -1451537042;
    bool qnSRUqFhcrwxI = false;
    string UNnMsiGY = string("GVWQmJZtpwyAKWOoJYRLEmaIZnreFnzoDeTjNFsrCgtUhTfJjSGoluDShKpZjzCcoJAtCgykZyxceBmoQHByuXhdXoUWcJKSakSlAYgVpsofTaWFqcWGnxySRYXokritB");

    if (amHfev <= string("qFptiGkEfMFNnxSgNDznaGjZpyqRcuThRtxRZetFDhrbWREURRYHoiwOfyfXaXqAzeqYSwrDYzuQxiTXnLbACrwEWbKlixXEVRkorlejUSgwQvDwYAddojQFVvYnHxckQmkVsiyjpEHlZMHuUIMTqnuVohncYjmNloQwCarjQHDnQgPtRhNnedgtEdRzDfNtleJuUdwYdKzNUaGzPArleNRpNdqeWvUsdDvUoQugkwjHbEUW")) {
        for (int YMaHHtJPqxSNp = 1629218973; YMaHHtJPqxSNp > 0; YMaHHtJPqxSNp--) {
            anTSY = vCuudtToROdLuYT;
            GHgqRyzy = alxSoQfYOLqn;
        }
    }

    return UNnMsiGY;
}

nFVjUDUfhGke::nFVjUDUfhGke()
{
    this->moFmh(209305.0802874166, -1258326995, 273029.04908942326, true);
    this->IwqWwuJqo(string("gcAHgPKTPVmwpuWGjOSFbtSuqKpDuSwIPwRGbNAjoHGjdQnwtYjOfYUCeNYxATIlrdvgzhDNLLziEBOnycVfTNBvlztTJqsWWjsESZcDwUNUzZUloosfJqSXJmKAVNyVBlfWUbzSbnhLqhQUIgCAleTRMQOVwsIMjwfuockmKbkuXkHeBzbESIhsYogIwwHzyCVhlZUtykQPlrxIdvpsJsJfjTNTmkOdVMdJyOQNQdEJSbVzjDFMNLMD"), string("lVRwYbXmvOmoiucaAFNWFxkZgrIfWvOAFBHJbuZCpSsOkkOQLIcooDzckrAaiJYxfbyVubyPWxjRHCIuXiMQjVOTrjOfIXVGRsSMWLzlBsnAkRJfgKtdTacsBsFlwzVfRByesveosnRkxcMPTGUqQWzHQhJBXlhbvRFTRcFRHNXoiTwIkolhdijhClIPrzAcdougsifqGRQVi"), string("AQzIKihaeOWbOEoqsamzL"), -1944276998, false);
    this->reXRmRsA(-421703.87364730064, -1432439152, -1589397119, true);
    this->msAFePVbkMR(string("HaRxMxSwDjqWrQyrwHFXgnUnAfFWuKzLXCaoujXolhdKsVtKBypAWLPRzOSqOtvPdPbvRPsPxvQeiIZmTOgrlilRcrImQJbDwTELNRqAxURShtDoxMZkRXpBZZj"));
    this->tZWbLoBFs(string("QTpgHEduxaUJAuyirjzkEBSDfguzQtqFEZVCHZSIQMPIsqJGDXEdQkvaQfnUgCevTkFOdcfuHdCrAVoQLTCcfVQyBYMUVzYvkvVcghIsFCjhpbpooRIOyOvkIFZjlRamhXwHjNvwlzNBjpFQibgYPhLbacDJurWOTnNBuUlZQXsg"), 1026791.2461309006);
    this->dGhfMgEiVv();
    this->hdbhOGe(true, 1846414677, 1174529217, string("DtPjapcnXjYjFUoCnABwELKcHMNjfxJGrZgCTJULmOeOseKBEJYnxSiGRpqIGFMNkQRwVcmmiKdxWCKkwOvbvnlkesReDTbXvyvBLMPHQBOQvNutQTCoveJRhAfXayMCmfPcMSoSbGoyFHZGdLdvkWkFi"), true);
    this->grCMjvBJbUO(-726633185, string("UwsuJlWkFXTVCfjmDiVptZsLRcBCEoiYPfHFohFjCCZGUoYTjcrbbXAHYJqkuvZygyoznyKngtDCHHZvpboD"), 108927929);
    this->tQegMUcASkdEnWR(string("gzGzvgfMsNKnmiBEsmrWougbRqZrwtuUvOlCoZMvvcoGEBZCgXIFAcmIJsyCM"));
    this->xRIbJ();
    this->ywfmWmyLVNJ(-322264.1305391694, -1969660353, 1058283606, true, string("SEObNkcBFkXkoIJpWtZEYRbRbabjSqPisYihLRSNpwONKTzdvGoBbtHzVzxUhxkXEbtzmadKZcbTOvyZxuzeeOeZWydiBULYGXyPEcSaxjAxiYKZiUeHAtAUAOUKPziTEXBJraAAcjdlNPIJaeDSvYUEdiWeqBnEpPjxmQsMNwxMDrilzxZoWThTmkpdIDlKxezHZPCTMyPsWyBmLOhFUjDCPqDTmnyvbRyAlUKsAVTDh"));
    this->QzmqFJZRVqc(string("jNfYCtOmyuxFnvHcCzBhkadTXwaNJGEFKUrQCXWyuUdtnZntiFAkfTKhpNOLHviUtjMnoouRnUafWUkmeLhEYnKCzItnwoogDDtwMWNcyXCDjcxtrFrWZrXSNlhcWCUqXDmw"), string("qFptiGkEfMFNnxSgNDznaGjZpyqRcuThRtxRZetFDhrbWREURRYHoiwOfyfXaXqAzeqYSwrDYzuQxiTXnLbACrwEWbKlixXEVRkorlejUSgwQvDwYAddojQFVvYnHxckQmkVsiyjpEHlZMHuUIMTqnuVohncYjmNloQwCarjQHDnQgPtRhNnedgtEdRzDfNtleJuUdwYdKzNUaGzPArleNRpNdqeWvUsdDvUoQugkwjHbEUW"), string("wWBvLRemqKGVYtLjzGMZTTaUfEmkvImlTRpDFLBoOgoKYcDofnMKGDysURKrpDauHxPXFqOYYYcuysIWQTItWbxQXMNFcKAMJFLguPIPgmZkMZXzjdyDvzqMCUWBSPGKkYZoFgiKRXLjFaSnZtaQTIYLChgEYABJIPjPunZfVUUxNdGGaxyhqrNPDoVQnZoTSRyexaQEhz"), -523488.5994356306);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ogcNaUBqk
{
public:
    int duQoQlTlqkRLtkU;
    double qRUogcobVgrZlHjx;
    int gUarut;
    double XljTrbinGGj;
    bool KfKcgJYXbmaxC;

    ogcNaUBqk();
    double OYQAQwsEnQozG(double HxDCithfVEmbyC, int FUGOORQh, int WrkIPCocKRQK, int kfaqLjiaE, int NsOXaJblHREJ);
    double vYqvem(bool OExqK, string keiMVuLGJLZvC, int TAqsz, bool gcIkjGoYtWaD);
    string shPVfMXCnFU(double ehTqAMLoqM);
protected:
    int aUyaQ;

    bool rLfOmVLx(double UKAODvmXslE, int zBygcxn, double wdxZuah, string NDKeSeWETKKeY);
    void lcCMlYAlnVp(double yqmlVdPmyK, bool JZCTQpjEPBQv, string WpmBM);
    double zEOpPLNYtJS(int OzKTdXCuLoxyU, int uwrkgCSn, bool qqSftHRQPWKdHr, int ZIWwpje, string gKNDSCZ);
    int UKnJBISEwtukSeN(double qLhOuNBt, bool TdQAnLhmtKRPam, double WWgZoskwnqEZ, double ZCptArvCadXO);
    int gvbudGjxslh(bool MmHFqBGORyxXm, int uUwxwtsKEpbze, int KzAaAoPVhU);
private:
    bool FXksfYVC;
    double pUKlWmYZFmCDa;
    bool alCpzULFMyiWsawW;
    int eftrYIbLhbGFeOo;

    void dfeENsm(string RqsQXr, bool cYRWwBJGeVxXCyOL, string ymgflf);
    string dccBhjs(int loNUVgbzvxLD, double RtwSMhusaLPlsSji);
    void CQdkjhhmAWeIS(double mnZoPJrhkoXNdByy, double pQsRQVqtsLjxvVP, double cKXmknImWYUbx, bool PtiLEm);
    int MNLJXnCNwSiAHllx(int GXFgkc);
};

double ogcNaUBqk::OYQAQwsEnQozG(double HxDCithfVEmbyC, int FUGOORQh, int WrkIPCocKRQK, int kfaqLjiaE, int NsOXaJblHREJ)
{
    int aTsWLIyvtg = -1415836701;
    double oChvEphZfqlLodj = 293613.1932600311;
    int avcAojOsbNDohvU = -569931507;
    double RUSjyIBdevzUtI = -830340.3502923567;
    string REjam = string("TFwuwWGRCezOPPixSkBbsDfiFKqXYePbTbmzCepwGyXbkqxeFakBqTVrmnlUnQRUcrRVZFwOVULyldzCjUwDZgFrCkekFVHyaPggNPfZTS");
    double CNOtAavOe = -76954.1000818891;
    int yZmvXYgdsf = 933322621;
    int HwstAWsnlMujga = -613000544;

    for (int pdIpqX = 2085065750; pdIpqX > 0; pdIpqX--) {
        continue;
    }

    if (yZmvXYgdsf >= 1275630455) {
        for (int ZWVlAW = 924089480; ZWVlAW > 0; ZWVlAW--) {
            yZmvXYgdsf -= avcAojOsbNDohvU;
            FUGOORQh += avcAojOsbNDohvU;
        }
    }

    if (WrkIPCocKRQK == 1275630455) {
        for (int DOUEYpFHzakbkDA = 1839095531; DOUEYpFHzakbkDA > 0; DOUEYpFHzakbkDA--) {
            NsOXaJblHREJ = HwstAWsnlMujga;
            WrkIPCocKRQK -= FUGOORQh;
        }
    }

    for (int qfGGrOjJ = 2108249002; qfGGrOjJ > 0; qfGGrOjJ--) {
        WrkIPCocKRQK /= kfaqLjiaE;
    }

    return CNOtAavOe;
}

double ogcNaUBqk::vYqvem(bool OExqK, string keiMVuLGJLZvC, int TAqsz, bool gcIkjGoYtWaD)
{
    string OtgpZFaTK = string("mRmmUNVbJUKEFvaTQRxvWFuAphfwTChdJFkXKcOfFeiahjSdWugOgtZreWcaImCAtpZHBoWicYCUboJqSKjDpTjEmb");
    int imvbgSgQs = 172594395;
    int CkuWCuttc = -1868408396;
    double KUNxMw = -277520.35689154314;
    int jaXzbHsyYNBbdoxE = -1123368456;
    double UchQGO = -464401.6943777909;
    double HgVBXsXezopa = -795071.641470232;
    int duQVtmVIHQFRSRZf = -436995012;

    for (int LtSpzdXUsZ = 850932051; LtSpzdXUsZ > 0; LtSpzdXUsZ--) {
        continue;
    }

    for (int ldEOGbqaNxNvL = 435005597; ldEOGbqaNxNvL > 0; ldEOGbqaNxNvL--) {
        imvbgSgQs += jaXzbHsyYNBbdoxE;
        OExqK = ! OExqK;
        HgVBXsXezopa *= UchQGO;
    }

    for (int XZJgcyNvaJluqSNb = 1269347885; XZJgcyNvaJluqSNb > 0; XZJgcyNvaJluqSNb--) {
        OtgpZFaTK = OtgpZFaTK;
        jaXzbHsyYNBbdoxE = TAqsz;
        KUNxMw -= HgVBXsXezopa;
    }

    return HgVBXsXezopa;
}

string ogcNaUBqk::shPVfMXCnFU(double ehTqAMLoqM)
{
    double XzfTBUDQPQxKvC = -410491.8994729965;
    bool zVxuhSsSm = true;
    double ZDRyMoQdQsbfcswX = 844916.970154709;
    bool HHSgTlfwudvve = true;
    bool JFwEKiWgsvSm = false;
    bool DYdcYWp = false;
    string lTrXvGefIFzEMs = string("GAnuhAyeJwbXOjPVwYgyoXmRcRgbXNEocIBvcbAmaGRxeNeTQIeqrQdNOAfZjCzbRHOrdFvcBFQBRoSOQqDEsxwZogwPPfBIVjIYXXSiyvhwqsaehGu");
    bool hDeyF = false;
    string QRFtPnzF = string("xexUYFYkHkMocXZCWoDVMwmbwHjCOrOpmiPbKmjKNAxoqmXQxgZnjUikLUvNBdoARQwLUwTlJZbYGPXzMKeEQqSdNmmZjfYQCcPYCfxfTvaCEzZdjOvHWbESTyvmHVnSylPhbGWqQouuYTsLDCsCyKLesvNodlJVdH");
    string RTYeAwWGtn = string("DKxvigphaRMruYjdKdpkiFgJCAYyxzkCXoIBpSMZAYaWkGhsNwJXaCZhUzwMvtzyeurpWzdoTqUDErtwht");

    if (zVxuhSsSm == true) {
        for (int SvSjfNR = 1644693387; SvSjfNR > 0; SvSjfNR--) {
            XzfTBUDQPQxKvC *= ZDRyMoQdQsbfcswX;
            hDeyF = ! zVxuhSsSm;
            HHSgTlfwudvve = HHSgTlfwudvve;
        }
    }

    for (int gedywzUwPR = 581598806; gedywzUwPR > 0; gedywzUwPR--) {
        RTYeAwWGtn = RTYeAwWGtn;
        ehTqAMLoqM += ehTqAMLoqM;
        RTYeAwWGtn = RTYeAwWGtn;
    }

    for (int RhVLSNv = 705102278; RhVLSNv > 0; RhVLSNv--) {
        continue;
    }

    if (hDeyF != false) {
        for (int tVUBWvTGlZXN = 577422793; tVUBWvTGlZXN > 0; tVUBWvTGlZXN--) {
            lTrXvGefIFzEMs += lTrXvGefIFzEMs;
        }
    }

    if (ehTqAMLoqM <= 844916.970154709) {
        for (int qEypbfSEBr = 144521896; qEypbfSEBr > 0; qEypbfSEBr--) {
            HHSgTlfwudvve = ! hDeyF;
            hDeyF = DYdcYWp;
            HHSgTlfwudvve = zVxuhSsSm;
            HHSgTlfwudvve = ! hDeyF;
            ZDRyMoQdQsbfcswX /= ZDRyMoQdQsbfcswX;
            ZDRyMoQdQsbfcswX /= ehTqAMLoqM;
            XzfTBUDQPQxKvC /= XzfTBUDQPQxKvC;
            RTYeAwWGtn = QRFtPnzF;
        }
    }

    return RTYeAwWGtn;
}

bool ogcNaUBqk::rLfOmVLx(double UKAODvmXslE, int zBygcxn, double wdxZuah, string NDKeSeWETKKeY)
{
    bool woLfWTWmmYStD = false;
    string TGrtPgcpFCLkZ = string("rkYESOElKmuwvdWyioYEQfaOzOrSMAeyeYDcgdvFrTsMHWncVKBfLnXXRhZEdzgGsUvmXAcEDmdocpMVXflLLpRZshJhDdHgQiXWWEecWBbAkPxLUjOjGCxMyRtILxkuSQJKFOvuzSiNYXxFFSOwqslHtFjuIfwgnmdKzFgJcBQApMBWVxCldCEihOypgyKcKvEkhzfSmzndzkPbENwqAIKwQLO");

    for (int XYeRXRLoeQGV = 1058341436; XYeRXRLoeQGV > 0; XYeRXRLoeQGV--) {
        UKAODvmXslE = UKAODvmXslE;
    }

    if (NDKeSeWETKKeY != string("rkYESOElKmuwvdWyioYEQfaOzOrSMAeyeYDcgdvFrTsMHWncVKBfLnXXRhZEdzgGsUvmXAcEDmdocpMVXflLLpRZshJhDdHgQiXWWEecWBbAkPxLUjOjGCxMyRtILxkuSQJKFOvuzSiNYXxFFSOwqslHtFjuIfwgnmdKzFgJcBQApMBWVxCldCEihOypgyKcKvEkhzfSmzndzkPbENwqAIKwQLO")) {
        for (int kXMjeJPStl = 1008819947; kXMjeJPStl > 0; kXMjeJPStl--) {
            NDKeSeWETKKeY += NDKeSeWETKKeY;
            UKAODvmXslE /= UKAODvmXslE;
            wdxZuah += wdxZuah;
        }
    }

    for (int JfSNsskyhdUfLU = 1117451499; JfSNsskyhdUfLU > 0; JfSNsskyhdUfLU--) {
        continue;
    }

    if (NDKeSeWETKKeY > string("rkYESOElKmuwvdWyioYEQfaOzOrSMAeyeYDcgdvFrTsMHWncVKBfLnXXRhZEdzgGsUvmXAcEDmdocpMVXflLLpRZshJhDdHgQiXWWEecWBbAkPxLUjOjGCxMyRtILxkuSQJKFOvuzSiNYXxFFSOwqslHtFjuIfwgnmdKzFgJcBQApMBWVxCldCEihOypgyKcKvEkhzfSmzndzkPbENwqAIKwQLO")) {
        for (int eTvYLpeuBFe = 727677489; eTvYLpeuBFe > 0; eTvYLpeuBFe--) {
            TGrtPgcpFCLkZ = NDKeSeWETKKeY;
        }
    }

    for (int glkZxreVxuPFo = 490084743; glkZxreVxuPFo > 0; glkZxreVxuPFo--) {
        UKAODvmXslE = UKAODvmXslE;
    }

    for (int oVkTRfuIliUKpp = 1266116371; oVkTRfuIliUKpp > 0; oVkTRfuIliUKpp--) {
        continue;
    }

    return woLfWTWmmYStD;
}

void ogcNaUBqk::lcCMlYAlnVp(double yqmlVdPmyK, bool JZCTQpjEPBQv, string WpmBM)
{
    string SWrqmQ = string("ySUYbFuKmSmRvLrJqUsJtEuoAoQrrUPcEMHLTKTKUoYZiqXSEoWgWgOEHEfwBDjcCpmrexNrAAtVEzCIVaNzEtOvPowUiCZQoJJtlnPLixcMtAPaBhPBDGPvzTlbJXXchWnuDfwbXVxzkVTuwMOxfKdqtspppNdYEzASOLVMGJqMKUBpgcgiWOfCOXTsEoBQYMyhkvWwHUvNMFERNpNAfWqdPmp");
    int oBNRYtgPCVEIWcw = -1733910095;
    double TuAdtQwVnA = -573567.2015671862;
    bool WfUIbBfIfBClO = true;

    for (int XdHEYFoYAPZBCl = 989646141; XdHEYFoYAPZBCl > 0; XdHEYFoYAPZBCl--) {
        continue;
    }

    for (int iJFIwYpQuiabQV = 693744875; iJFIwYpQuiabQV > 0; iJFIwYpQuiabQV--) {
        continue;
    }

    if (SWrqmQ != string("ySUYbFuKmSmRvLrJqUsJtEuoAoQrrUPcEMHLTKTKUoYZiqXSEoWgWgOEHEfwBDjcCpmrexNrAAtVEzCIVaNzEtOvPowUiCZQoJJtlnPLixcMtAPaBhPBDGPvzTlbJXXchWnuDfwbXVxzkVTuwMOxfKdqtspppNdYEzASOLVMGJqMKUBpgcgiWOfCOXTsEoBQYMyhkvWwHUvNMFERNpNAfWqdPmp")) {
        for (int PXCwME = 1587236467; PXCwME > 0; PXCwME--) {
            TuAdtQwVnA -= TuAdtQwVnA;
            SWrqmQ += WpmBM;
            SWrqmQ += SWrqmQ;
            yqmlVdPmyK = TuAdtQwVnA;
        }
    }
}

double ogcNaUBqk::zEOpPLNYtJS(int OzKTdXCuLoxyU, int uwrkgCSn, bool qqSftHRQPWKdHr, int ZIWwpje, string gKNDSCZ)
{
    int nBAauJKpTWO = -1486950881;
    string NXafrJ = string("pSbAKPLNOQsjFMPsxzaobhHWegLmPIqlPhUfTbmCLVVYLGieLsZFYEwoNLvHUiDpgyFZghzUDWgWQJIXOhVtIKXgDgROSVCvrJVDdSZwktaXOPGqAQcUHNccjhndtodQ");
    string PKxeF = string("TPMRMqQsFkvgzpORyEHQUwQEoVkEhiUwKmpaAAOwphURIRxYnfwoYnfjjGSmgKOtVkiCdKGqjlhtoUbeIvsrWgiSvLcfcKkgvMUfIHzB");
    string qNmKjq = string("vgzGCVXxeUxrxtNsfKRwTjutWtgfHUPIElYLIMCHRtylBjSvtdmwHvxbqSJNVdOwvfazAJuMCZtxebyrunrvDgHHsbTZJSSCNQNJHoYQzWINXvwhjOghgaHOPlFznAseeaEWxhiROZlfocUKymLDfNecaOtyrvQDC");
    int EhTdeoZwa = 718945306;
    double bKMlxWPuLEnL = 228443.23930131434;
    bool SqmWiLuFmAa = true;

    for (int pichNgbh = 514424506; pichNgbh > 0; pichNgbh--) {
        OzKTdXCuLoxyU += EhTdeoZwa;
        NXafrJ = NXafrJ;
        qNmKjq = gKNDSCZ;
        PKxeF = qNmKjq;
    }

    return bKMlxWPuLEnL;
}

int ogcNaUBqk::UKnJBISEwtukSeN(double qLhOuNBt, bool TdQAnLhmtKRPam, double WWgZoskwnqEZ, double ZCptArvCadXO)
{
    bool twrGZONLJPiXRB = true;
    bool mmIhNC = true;
    bool ZfWdcEZ = true;
    bool EtZrAsxq = true;
    int eqbrOVr = -1780710256;
    int QkSjClkJmtwj = -1850135756;

    for (int LhHPWjH = 582470197; LhHPWjH > 0; LhHPWjH--) {
        ZfWdcEZ = twrGZONLJPiXRB;
        TdQAnLhmtKRPam = EtZrAsxq;
        ZfWdcEZ = mmIhNC;
    }

    return QkSjClkJmtwj;
}

int ogcNaUBqk::gvbudGjxslh(bool MmHFqBGORyxXm, int uUwxwtsKEpbze, int KzAaAoPVhU)
{
    int pKWfXnJmadIOF = -1961782149;
    bool eOOCcW = false;
    int AdgvBHq = 1581848131;
    bool thrHPynsuu = true;
    bool wmvjTwPZ = false;
    double LnhEGZCDbnR = 1005806.0528448639;
    string RnYxahlmzRdU = string("zxSISwKthRKzzXMVbrbfxzIAKpxYlsXuyFXFvXhNaQAVqNLZieWUtAiTLWMrHmDDKf");
    double qBBBvdMiOhRS = -328187.55701087957;
    string OgMTRXTywP = string("MbKEYIwnwEDSGeETSPvCCejQgoxLglsUOVwDBoDPGwJhqCjvcahdfjGqwUhxhtxxxysULNynstcjjgZWjxNbSCleldFdYzbrWCSTSnsvbxAAhhyTFvrlEClXxMIqLDqEUsZEeFMEOOjCUOFyqkmFiIYZJrRRwzSnalhssNRscszSPiouNpIhCVlwGYoLdZRaFueBYFiNTaCEzuUlkiEBgcRnSMiVpdgF");
    int oTNyqwDPDiWUP = -2033000325;

    for (int LOqoOWDVmWKyS = 814933813; LOqoOWDVmWKyS > 0; LOqoOWDVmWKyS--) {
        continue;
    }

    for (int APqaf = 423641652; APqaf > 0; APqaf--) {
        uUwxwtsKEpbze *= pKWfXnJmadIOF;
        pKWfXnJmadIOF /= AdgvBHq;
        eOOCcW = ! eOOCcW;
    }

    return oTNyqwDPDiWUP;
}

void ogcNaUBqk::dfeENsm(string RqsQXr, bool cYRWwBJGeVxXCyOL, string ymgflf)
{
    bool ipPrdffyguoYOYrS = false;
    double WvqFAonVRI = 929777.8947100299;
    int hnzcHDywIFOeX = -2139500870;
    bool yrjrqJ = false;
    string izfIrFMbRyLd = string("DDReQkvXqoeVZXzdWZloQqJvlgidSUnXabAjFowsWEGwFxJpxroSYfNZMvuwxjEuxMBsZOLZNzNcCBaHeHgKAxFhkBzJdFEHrLjyNjpyrYzGCNaiozUgaNPKDkTuEKvBiQMweROqtT");
}

string ogcNaUBqk::dccBhjs(int loNUVgbzvxLD, double RtwSMhusaLPlsSji)
{
    bool AADhFPqQBL = false;
    int JdjumYERuzAQZd = 1703968048;
    int OUqgohEB = -1494385688;

    if (JdjumYERuzAQZd >= 1703968048) {
        for (int EceNXbCUQiNDc = 1305517805; EceNXbCUQiNDc > 0; EceNXbCUQiNDc--) {
            loNUVgbzvxLD -= OUqgohEB;
        }
    }

    if (OUqgohEB >= -1494385688) {
        for (int IKYzwcg = 1110075487; IKYzwcg > 0; IKYzwcg--) {
            AADhFPqQBL = ! AADhFPqQBL;
        }
    }

    for (int jxhJNGP = 1900271017; jxhJNGP > 0; jxhJNGP--) {
        continue;
    }

    if (loNUVgbzvxLD != 693491509) {
        for (int IsALEIn = 1687490234; IsALEIn > 0; IsALEIn--) {
            OUqgohEB = OUqgohEB;
            JdjumYERuzAQZd += JdjumYERuzAQZd;
        }
    }

    if (RtwSMhusaLPlsSji <= 837924.6264645722) {
        for (int WoejqHr = 1093683759; WoejqHr > 0; WoejqHr--) {
            continue;
        }
    }

    if (loNUVgbzvxLD != -1494385688) {
        for (int PcEPeAgNEAP = 1687243311; PcEPeAgNEAP > 0; PcEPeAgNEAP--) {
            AADhFPqQBL = ! AADhFPqQBL;
        }
    }

    for (int FrwrrLpbMSDJ = 686223683; FrwrrLpbMSDJ > 0; FrwrrLpbMSDJ--) {
        continue;
    }

    return string("ZOIfWfIgfdgCJYEqEtfExoknmyRsQSgCgwjVzYtqXmHktjUAWDRUKbQbTojZqiSJpnTGNghmoZUPJCHShVmkPdUzREAUmRgChaAOQoDPLqXV");
}

void ogcNaUBqk::CQdkjhhmAWeIS(double mnZoPJrhkoXNdByy, double pQsRQVqtsLjxvVP, double cKXmknImWYUbx, bool PtiLEm)
{
    bool alpBEhwFd = true;
    bool OMydzqZYUxq = false;
    double ellbdPklqNfdQMu = 448864.0004074123;
    string KxtMLnhc = string("RLeCAlCnkoRLBBmxgHHWlswXEJMycJEFWUroYTvPulxBnOizfoGAUJVoRVCSOfQmghvFilLXJXO");
    double EonWAhWe = -733164.0405650041;

    for (int DyYAlZQGaraxqnar = 1909596266; DyYAlZQGaraxqnar > 0; DyYAlZQGaraxqnar--) {
        EonWAhWe = pQsRQVqtsLjxvVP;
        mnZoPJrhkoXNdByy *= ellbdPklqNfdQMu;
        pQsRQVqtsLjxvVP += EonWAhWe;
        mnZoPJrhkoXNdByy = pQsRQVqtsLjxvVP;
        pQsRQVqtsLjxvVP /= cKXmknImWYUbx;
    }

    if (mnZoPJrhkoXNdByy < -733164.0405650041) {
        for (int YlHsz = 1345789352; YlHsz > 0; YlHsz--) {
            EonWAhWe /= EonWAhWe;
        }
    }

    for (int FozyQklxfIkKCVV = 1446355350; FozyQklxfIkKCVV > 0; FozyQklxfIkKCVV--) {
        cKXmknImWYUbx = ellbdPklqNfdQMu;
    }

    for (int qXZIYDMrNwb = 602279437; qXZIYDMrNwb > 0; qXZIYDMrNwb--) {
        OMydzqZYUxq = alpBEhwFd;
        pQsRQVqtsLjxvVP = pQsRQVqtsLjxvVP;
        alpBEhwFd = ! alpBEhwFd;
    }

    for (int rDDTaCyfmhsEU = 597587638; rDDTaCyfmhsEU > 0; rDDTaCyfmhsEU--) {
        ellbdPklqNfdQMu += mnZoPJrhkoXNdByy;
        pQsRQVqtsLjxvVP = pQsRQVqtsLjxvVP;
        alpBEhwFd = alpBEhwFd;
    }

    if (PtiLEm != true) {
        for (int yWtqQsP = 1472645513; yWtqQsP > 0; yWtqQsP--) {
            cKXmknImWYUbx = pQsRQVqtsLjxvVP;
            mnZoPJrhkoXNdByy = cKXmknImWYUbx;
            EonWAhWe += cKXmknImWYUbx;
            EonWAhWe /= ellbdPklqNfdQMu;
        }
    }

    if (ellbdPklqNfdQMu != 448864.0004074123) {
        for (int MUsQUqSkrkR = 1886537747; MUsQUqSkrkR > 0; MUsQUqSkrkR--) {
            OMydzqZYUxq = ! OMydzqZYUxq;
        }
    }
}

int ogcNaUBqk::MNLJXnCNwSiAHllx(int GXFgkc)
{
    double bznnSIMZuHlT = 640450.0374151071;
    int jUDIZoK = 318617063;
    bool LdpTE = true;
    int nMZpAGIYRMsU = -1312991385;
    double AoACiQvJJY = -76580.24691069768;
    double tDbFdnTTsxFXI = -206090.48647620153;
    string IXdqcZLn = string("cpFMCpblKWSpOPrCtcYfzXbZdulItxVpNcGbgMBqJKTyHnZDLkvogQCdYraelkZJCsYpqbDpvwrYcAiDMFfDVkjEEzEBSSKxcfGSsxdVFbMVNnYEVvxFIxKeWNzapuSYjQecKtjmykDjxxQTAjokiKtlTWVLPoEcRbbVHLU");
    string WdGdNCE = string("aQarjvyGTlQVTYWIu");
    int FmQLPfQxb = 11935284;

    for (int jWxRJBDdSn = 319630351; jWxRJBDdSn > 0; jWxRJBDdSn--) {
        GXFgkc *= FmQLPfQxb;
    }

    for (int ZrIlORx = 1789800112; ZrIlORx > 0; ZrIlORx--) {
        FmQLPfQxb *= jUDIZoK;
    }

    return FmQLPfQxb;
}

ogcNaUBqk::ogcNaUBqk()
{
    this->OYQAQwsEnQozG(-38758.33641516415, 1868642519, -174653601, -300400543, 1275630455);
    this->vYqvem(true, string("nxbqjeLGxpIkOkJXLQwrmQkNQIQZDZAwuExmeVBzrqDRsrkBEvoEJ"), 1933312806, true);
    this->shPVfMXCnFU(135621.581876267);
    this->rLfOmVLx(-76797.77741315942, -1181281923, 756553.1484824362, string("ZaodIRkeDPUZJSttZSUUohJBWJtIGLMrxShuXrisJISrcljhIHTXREmIuJMEmQDTPdIYZdyUztEHphWZUOvKLgUorqmTlDVwEepgaHbgMROAmyUOXJOQlSEvmzYBh"));
    this->lcCMlYAlnVp(-498823.08336349233, false, string("BngRiMQzfzKMvgFdXtAFhWKPCWNfiRnRwUaPuUVfYPviDLCBFZzReaQwaHjwLqZCVBMnrhEnkMVpNkZcCCwGjXGEAaqSPEVKxQpKtoQAKuwMuffIL"));
    this->zEOpPLNYtJS(-2059610044, 950566434, false, -1900517680, string("ztNMqqlKrbSlZvdP"));
    this->UKnJBISEwtukSeN(-398419.80559000885, true, 658076.1652097721, 94759.41534882064);
    this->gvbudGjxslh(false, -1836864222, 1675014922);
    this->dfeENsm(string("NLxYbuefqUYizZXVVTsSDBtsLpcydsLtdWrtTUmdIfpuBDvVIvkhlmccIxkmjXKaegZiyeXXMmYbhTObWvmkwyaGoYLVoeOroQMJxuELSjpXIkmLVLScwXK"), false, string("DBHiVRcmHjiDADzgovrPrBRRUPBagScrDYiDsUxeWTvSkcLGGgxoZobzDfaORzYkMNARnWoqzrZPsnEfbXBNNsjUJjdUZZTruwigpWYINXucvChiUKXOufMYamOdVLONvZneOaDKidBjuwQtSQAdnfQao"));
    this->dccBhjs(693491509, 837924.6264645722);
    this->CQdkjhhmAWeIS(450653.6774584321, 561314.0988131573, 269724.38354510907, false);
    this->MNLJXnCNwSiAHllx(310572536);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GAEDwnEqvO
{
public:
    double Ipzeyzj;
    int UrzUbmrcJcFQ;

    GAEDwnEqvO();
    bool iIFMKhKJfSa();
    bool QUEGOrFbVcbt(double wTOMhgPfHmUO, string JGEYtxZRWIHBGO, int DFcpcfWeIULfA, double OZanXdL, bool jrALu);
    string wsqlR(int CrgUzYdiIty);
    string RFkhoKsezEshl(bool uaHiJoV);
    bool hBbUWuO(double EdZbIxD, int ihWqij, int LontPQDwLqQeTJf, int uOomNq);
    string fGBFyfmulgNAdjQ(double qLXOdIlqS, double oVUddW, double LUabkAFycJaUmK, int RxJWhRI, bool VxkSMYx);
    int bfZNPjik(bool ZiXOW, double PPhVAJ, int LqZqM, string thjxqDttYmQo, bool pAOamCwzctNxcmhg);
protected:
    double lZcdzpVqNdpgqOWp;
    string NvkqTKYLTomS;
    int GMSLhoZdKPkfvRn;
    int dOlCkBQpAdntQm;
    bool TyLTpJan;
    string YBWfjvlCTBrWqsW;

private:
    string EZGfMnENnsBXNjl;
    string NmHsM;
    bool TlYZmdoJMGB;
    string BEhZPIbykINlUI;

    double tNZOPgQdks(string wYgmVFfxbkCdyTR, double pAMKGXIg);
};

bool GAEDwnEqvO::iIFMKhKJfSa()
{
    bool uTsXXqmrDv = false;
    string WCVDCSyNz = string("ZmsaNszmdPcwIOHsmIEBCuUWmBoLNGqskCILWkweJndhKNOFJgwMFmuTAjcHPYFszqUSLGgaLZLssBuzPgkZGSSQRjnZAarqqsrGvTXrVGLTCOKiRHA");
    int JVgPQODJszUOnZ = -1731697990;

    if (WCVDCSyNz == string("ZmsaNszmdPcwIOHsmIEBCuUWmBoLNGqskCILWkweJndhKNOFJgwMFmuTAjcHPYFszqUSLGgaLZLssBuzPgkZGSSQRjnZAarqqsrGvTXrVGLTCOKiRHA")) {
        for (int CqrejpEJMJmKPiUy = 478754788; CqrejpEJMJmKPiUy > 0; CqrejpEJMJmKPiUy--) {
            continue;
        }
    }

    return uTsXXqmrDv;
}

bool GAEDwnEqvO::QUEGOrFbVcbt(double wTOMhgPfHmUO, string JGEYtxZRWIHBGO, int DFcpcfWeIULfA, double OZanXdL, bool jrALu)
{
    double tjODzsIVBZr = -777641.2907761834;
    double iIixCUZcWMJuhPDc = 549568.9721863776;
    int iytlpuCSwMKgssY = 1705116611;
    string PRlBNdeocsh = string("ECWSbfvYofgkQyiQapdwJTDnQaUAipdZUIpMBMgVvdxzjvxwLRcloNSmUnLyFMXTJihtnFFtOedzsREYzxtWJGnudLshlKdVFgLozxCNRSXhtPmMOoJaHFscJdomgwKJGcRQyJpxARxAMxyQAzxNLiJQRxRqouuiEVKSaRLWsDedeHBEtRuYHfRUDSillJzWUFBlTqjtjnabPMDNgxZMUhKkmjJKtQemslHWbdPyjI");
    bool OrrQIKFLNWbNEZe = false;
    int TRxADySVoaAo = -463268720;
    int syajwwFxRHLsafF = -735892263;

    if (syajwwFxRHLsafF > -463268720) {
        for (int qfiTX = 241116199; qfiTX > 0; qfiTX--) {
            iIixCUZcWMJuhPDc += tjODzsIVBZr;
            syajwwFxRHLsafF = TRxADySVoaAo;
            tjODzsIVBZr += tjODzsIVBZr;
        }
    }

    for (int VarrmZt = 2122154784; VarrmZt > 0; VarrmZt--) {
        continue;
    }

    return OrrQIKFLNWbNEZe;
}

string GAEDwnEqvO::wsqlR(int CrgUzYdiIty)
{
    double DKXceGCo = -508602.55643818213;
    string kuPEsYOkUjHvHg = string("XHndPwGhtJnvyWBokuqyEKPYjZYMfLVTyweUaUMnIjofsEEZkREgQefnMwjnXLxXOtPgpTgJrqjAaFZzhmpUGaVCHeobMycsGXgnFEakxKWaAidKoGraStgCxxNuXbKIFcFTqBwIGbzpOKpbTBbdQQGfbrtcMzFuZidzumkpuKZsVzGEBwvrdAZKsoosocNiuzSxtsMePf");
    double LfQSMfamskiTkR = 179683.71149614456;

    return kuPEsYOkUjHvHg;
}

string GAEDwnEqvO::RFkhoKsezEshl(bool uaHiJoV)
{
    double LFPJLpYZXmPluLRG = -879369.4632780224;
    string MaZyBubrKV = string("edWUQnENDJJUiPCDmtTkuHabDWmjnPhbsxinnYotMGTElVgzPWavrTcxGLYKGvMsoqZdOEkYf");
    int vXixxUv = 1015478256;
    string YzzXDBoAesiMk = string("MOvbEAAUrDHIWfHqruvfFKdYiCsloprRsgCmpPsEGeHURlpTUchXBNYagYuoYjzkYXXVGHuRfUygflzAYGUTyQeoIuNQFMXEADLJrTDsAk");
    bool MwmCHYneA = true;
    bool dlwXIpjMs = true;

    for (int QgNbuyela = 459047811; QgNbuyela > 0; QgNbuyela--) {
        dlwXIpjMs = uaHiJoV;
        uaHiJoV = ! MwmCHYneA;
        uaHiJoV = ! dlwXIpjMs;
    }

    for (int NuqCVdsTRzC = 187359240; NuqCVdsTRzC > 0; NuqCVdsTRzC--) {
        continue;
    }

    for (int TcknjbVtvj = 1791738041; TcknjbVtvj > 0; TcknjbVtvj--) {
        MaZyBubrKV += YzzXDBoAesiMk;
    }

    for (int obSJX = 676381144; obSJX > 0; obSJX--) {
        dlwXIpjMs = uaHiJoV;
    }

    return YzzXDBoAesiMk;
}

bool GAEDwnEqvO::hBbUWuO(double EdZbIxD, int ihWqij, int LontPQDwLqQeTJf, int uOomNq)
{
    string KwzTOWSJJCtDn = string("MTPzigLeoICggrQJajqXFLcctJdBQDaeFBCmszrPivndrSNUNneWSqkpigEFiYaABaSKJsQZsyQNsLAAVGXlJNoQqBfpTEsPfabQHxmbNaKsZMyRYxTNesjGUWEZfkKZJKmfJeQPliivPFkpavOoMWCuDmhcsuccUPcGcWYPazdBeeZezSsBPgROeWwtmLWuZkiWCqstZZIlXcXCXSMuiFJDqxjSHRFMXaiVETFcYTvK");
    string nOQmfVcpkZE = string("mDhblwaLLsCaIfjtwcLsQYEzMEbZisWmylCYvHBheAJRvmeNlmSTLvx");
    double NvorRKAvJz = -994440.1785680108;
    bool wdWbPAvIn = false;
    int uIzgEs = -1673680840;
    string nKItlYstj = string("tHkGmyAYgUqRARELXqxmMCIeSNjlggKthEvBQQwMNjnGKyJnAjFledxlpFxiwvyHwKoOaRkOpaNzbcqkjHOFfAOXPXtWwxSPEcDsFtgkpLBRJPoVTJmZSLmuOcezuDYGFrFebQvIdcxwkRxliMKTEtaeEKOPAE");
    bool uvmSGZfholrMZUp = true;
    int pSWBnj = -911942410;
    string wywbkIeWr = string("cjYPtSXTZmJEslHUULPqceJZaXvk");
    double RohDXBtth = 800499.5185437081;

    return uvmSGZfholrMZUp;
}

string GAEDwnEqvO::fGBFyfmulgNAdjQ(double qLXOdIlqS, double oVUddW, double LUabkAFycJaUmK, int RxJWhRI, bool VxkSMYx)
{
    string CWgEEVFboylpls = string("BvrIyKUprLanprNaKcWgnhVvSBSnQjKhqrvWcT");
    double nwcZvyPTODf = 166582.9508316781;
    bool AyVgGWXNSUKCG = true;
    bool ZEoCXXlahlJRsf = true;
    double bzmdPaMqWPzWp = 24820.27103172218;
    int fvaCclZlnmM = -1886496739;
    double avnxlDHFsAb = -764994.8562967272;
    int yxeRCs = -1506811205;
    int oohpWbhJVnuDBI = -94824516;

    for (int vRFKBETOfFvMp = 939342605; vRFKBETOfFvMp > 0; vRFKBETOfFvMp--) {
        yxeRCs -= oohpWbhJVnuDBI;
        VxkSMYx = ! AyVgGWXNSUKCG;
        nwcZvyPTODf *= nwcZvyPTODf;
    }

    if (qLXOdIlqS <= -829050.4325850067) {
        for (int DJmqexTrtaU = 5590255; DJmqexTrtaU > 0; DJmqexTrtaU--) {
            continue;
        }
    }

    if (nwcZvyPTODf >= -19274.941192503506) {
        for (int LTlITZpvBdzt = 1316357486; LTlITZpvBdzt > 0; LTlITZpvBdzt--) {
            RxJWhRI += oohpWbhJVnuDBI;
            oVUddW *= oVUddW;
            LUabkAFycJaUmK = oVUddW;
            avnxlDHFsAb /= avnxlDHFsAb;
            RxJWhRI /= fvaCclZlnmM;
        }
    }

    for (int CkhgD = 370984732; CkhgD > 0; CkhgD--) {
        qLXOdIlqS /= qLXOdIlqS;
        qLXOdIlqS *= qLXOdIlqS;
        oVUddW *= avnxlDHFsAb;
    }

    return CWgEEVFboylpls;
}

int GAEDwnEqvO::bfZNPjik(bool ZiXOW, double PPhVAJ, int LqZqM, string thjxqDttYmQo, bool pAOamCwzctNxcmhg)
{
    bool JKsFZfFXBMfry = true;
    bool zdGdVHdSNEJze = false;
    int gqqxgCGODAvqxQb = -556946652;
    string nLHbAl = string("aCaGMllYnZoluxBCxAdmSiyeMonLQsIwZJGqGJyZaSvREDhlarKNfjrKmFSNABLBhNR");
    string FxncXWrUwHw = string("bdrbJysdGQbgCybcAzFTPIYePgZeKlSqAGNYbqldKaiDqvTUbORvZoLwlYpGYJoxqXJOAsRenIxXoQkJqZwnUHSawgkuHaoqokQuxifUpBtdTGJqcyjcWESHbLtWnvBGOeGnFhFeycNtuDPfFHVZGPIYvWDbgwMkfTKjhGVvRZKnpepKDcLocPNodEjjyCJmVqrRiRycGXcRFooZdkAJsSqwCbGENgnx");
    bool pAyfJZoyzSW = false;
    int bEmydbhD = 98852961;
    bool SPskrJpf = false;
    bool kVSxY = true;

    for (int CgyiIyATLTbeM = 2013371865; CgyiIyATLTbeM > 0; CgyiIyATLTbeM--) {
        FxncXWrUwHw = thjxqDttYmQo;
        pAOamCwzctNxcmhg = pAOamCwzctNxcmhg;
    }

    return bEmydbhD;
}

double GAEDwnEqvO::tNZOPgQdks(string wYgmVFfxbkCdyTR, double pAMKGXIg)
{
    string zxKzYBR = string("ZZJLXoOVvwumCyuavfIfgqgmbRXOQUcuSHbKMclWDbAZyuFBdpGyuZsekoWUQlTARPGYyUcpbMnhaFwzZnokiXanhYjhoEw");
    bool fEzPQbCv = true;
    double QAHXlIYdRlY = -1035532.2596458017;

    for (int BCPWQXQuwZIQgzZ = 1241865911; BCPWQXQuwZIQgzZ > 0; BCPWQXQuwZIQgzZ--) {
        QAHXlIYdRlY += pAMKGXIg;
    }

    return QAHXlIYdRlY;
}

GAEDwnEqvO::GAEDwnEqvO()
{
    this->iIFMKhKJfSa();
    this->QUEGOrFbVcbt(147799.981425064, string("SchuDtprQJUHHALiaQDOYIXnktJjokLDsGPWnnIagyJyiDLVJRUGdejBBLkksfcdxPzYeShQmkLgTaHzGQwMLNSedgYCikAlXelbDsnlkpnSVaCymNsZpZHiaXzqtWudqVqiSlaWAxjmpGUhPyMnAJdCtFn"), -315702300, -864551.2671271297, false);
    this->wsqlR(445482110);
    this->RFkhoKsezEshl(true);
    this->hBbUWuO(-675626.1924397433, 1718518379, 523163527, 1780919153);
    this->fGBFyfmulgNAdjQ(-19274.941192503506, -304734.73911044735, -829050.4325850067, 238290458, false);
    this->bfZNPjik(true, -589633.7646943592, 253793589, string("LLOQEinmXIMBwfGIyYVepCtDGcjQIxmLxeDwbvMADxZPBEaoQCCeYlZitDiZTggRbeIpYqfeeQobQHdZnHRTmGZBkSHoAoBgXQbzAHDWHvfxICMCSUenaJkBKJcIkMwtsjkSgWrdOWTgrwjoWhTxwsLvMdaCrwbvTILPcUVeiZHUttYnXhxpcZqwuoAAyndHIxhWNRvsnapYKAALMUJgCGJVIbiR"), true);
    this->tNZOPgQdks(string("GqhhvlQMDPHziREmwuXBgPlhvbyOsZHJXhTeVvhpuscmOmbCgArVtHXacPOCVWhwGyOhmlOPbkCEmEKjLUDEOYvODDQHlhfctroaJGKmKvfvprsnEHSGykHCIpKhqwnebcKxYSlmVwbKLOiorjKYCagghOiIvvNNROchDzwDVTXJlLfeaiwuONJZCAtDRkzvVPicFdyjQNNAlBVGmfECcPyQlqSVFQNAMRKqi"), -549889.5804416751);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class esGuF
{
public:
    double dSiFKhRvwRjF;
    bool IRUPfsLpLLuvuEZT;
    int cgTPW;

    esGuF();
    bool jaNxQqUpnk(int XtklrxhxoXBXSmV, bool vKeEMAkNoETrcsOn, string cSulYvO);
    int WePWuIQHfUtBsxDa(bool vYTNNP, int KJAtMBamIEHzRC);
protected:
    double mrKzmJ;
    int FHxdCv;
    bool ScNeYLuhlKO;
    string fOQorDUD;
    bool VlBMOntHJ;

    void uHygcoa();
    string VEywulPfmloM();
    bool MKSnuJAisYfS(double vbXqmRjACx);
    double ZaEhBabxCLJ(bool XvpSoU, int OSgQCnQbpBoYOzTI, bool XpfhMEKUPiEzJIQj, int EqIbIJUglO, int KRDRhfxFNShyz);
    int YlkOzvmqFTxbReSn(bool XGlzQTcpA, string jgtIxBnaJkl);
    void LBXRTIKODFrwMCNx(bool TxVkNWkNsmjjZPga, string YqVauMLaUqu, double AhywTqoYEQb, bool aSUtYnyUdKDWHWjn, int frHiwdWpFKVx);
    double BaUVCQreJAzLYnL(bool gIHXdOfQmzZRUj, bool seDjysBOasIsOQx, string zpKxBRRjlTHf, bool fzZxYVUwy, double nsbzcOTlbepzrQp);
private:
    int ButoGKnSQYOn;
    double msmkPoBrXZjf;
    bool rnJgaU;
    bool wmCMasBgPiRlY;
    bool Myjmp;

    int xayHbn(int BuDFVToSebfyelJ, double CHnJaWt, bool HKZpqFsjpI);
    double TxrOztfsdZ(int QWZhfgAwAWUAgKCM, int OQorRW, bool xYJWXZCU);
};

bool esGuF::jaNxQqUpnk(int XtklrxhxoXBXSmV, bool vKeEMAkNoETrcsOn, string cSulYvO)
{
    bool PGpOvEjrwUREjo = false;
    bool iyCXDkEmGqzk = true;
    double FzdVbYULAoixN = 506610.01174485806;
    string rSadnEhmndrnNF = string("oqnFUxtAozpznqeEsZEBi");
    double NCiYcbbXnDnHl = -604951.3026935029;
    int OYvVt = -1411400671;

    if (PGpOvEjrwUREjo != true) {
        for (int qqGihgYCB = 685895511; qqGihgYCB > 0; qqGihgYCB--) {
            vKeEMAkNoETrcsOn = ! PGpOvEjrwUREjo;
        }
    }

    for (int iBWkOWevBkIRey = 304640910; iBWkOWevBkIRey > 0; iBWkOWevBkIRey--) {
        PGpOvEjrwUREjo = ! PGpOvEjrwUREjo;
        XtklrxhxoXBXSmV = XtklrxhxoXBXSmV;
        vKeEMAkNoETrcsOn = iyCXDkEmGqzk;
    }

    if (XtklrxhxoXBXSmV <= -1411400671) {
        for (int mnEuVEK = 793610903; mnEuVEK > 0; mnEuVEK--) {
            iyCXDkEmGqzk = ! iyCXDkEmGqzk;
        }
    }

    if (OYvVt <= -1411400671) {
        for (int pjbKXP = 2086941525; pjbKXP > 0; pjbKXP--) {
            rSadnEhmndrnNF = cSulYvO;
        }
    }

    for (int vaZdFDEZ = 1523241896; vaZdFDEZ > 0; vaZdFDEZ--) {
        continue;
    }

    return iyCXDkEmGqzk;
}

int esGuF::WePWuIQHfUtBsxDa(bool vYTNNP, int KJAtMBamIEHzRC)
{
    double wCYWbffJHVcyaJ = -284660.86321380147;
    double JqUrbN = -699390.6208530401;
    double DzMHNrTHnTm = 566707.060442253;
    string ovxwN = string("ybVfBsUEQlqUsfYUMDPeOUfgySSvoOZlDREAxLWYSQqeRVCOoLnkfLPFZTVjas");

    if (wCYWbffJHVcyaJ >= -699390.6208530401) {
        for (int jeWbMGfsMLsNYxj = 1350395711; jeWbMGfsMLsNYxj > 0; jeWbMGfsMLsNYxj--) {
            JqUrbN = wCYWbffJHVcyaJ;
            vYTNNP = vYTNNP;
            wCYWbffJHVcyaJ *= JqUrbN;
            wCYWbffJHVcyaJ /= JqUrbN;
        }
    }

    for (int jozlixLATmdKs = 913189655; jozlixLATmdKs > 0; jozlixLATmdKs--) {
        ovxwN = ovxwN;
        wCYWbffJHVcyaJ = DzMHNrTHnTm;
    }

    for (int NcdwzNIINtu = 2070620051; NcdwzNIINtu > 0; NcdwzNIINtu--) {
        DzMHNrTHnTm += JqUrbN;
    }

    return KJAtMBamIEHzRC;
}

void esGuF::uHygcoa()
{
    int oFyytlHHnWEGsiC = 1118787531;
    string mhhCrkpxchJgvYJ = string("FejEcJDDhIIMhEwosIGJVkZkrWMeuvFOvAPIzSkjlsnQzyeMjYhJRiEODIvyujeKIIZAycqTcisdwiOjTYUlyUYcXoBFCVeHrYXKZYXSEEqMHONeScFmgbBpRkrWnJhlla");
    string BuMufH = string("ItOPPcdZxtYrWhwFXERdbagAijXwGoTnwevXQgoCPdAIvfSJKHuQbhrvdWXNLXDfZJOOxkuxekrHKpFdwipuufNwzHEFZARPXxsrJnzSakffxtyAelOrfcghobzchJVyLRJStXFrSdsBtzBSebYjHgZLFFsRWudhYGQWtyKmiwzZUzXucnlGBSzkmAnhN");

    for (int ggXpAKJwOUb = 2104288133; ggXpAKJwOUb > 0; ggXpAKJwOUb--) {
        mhhCrkpxchJgvYJ += mhhCrkpxchJgvYJ;
    }

    for (int WQCbRQ = 1656461241; WQCbRQ > 0; WQCbRQ--) {
        mhhCrkpxchJgvYJ += mhhCrkpxchJgvYJ;
        oFyytlHHnWEGsiC = oFyytlHHnWEGsiC;
        mhhCrkpxchJgvYJ = mhhCrkpxchJgvYJ;
        BuMufH = BuMufH;
        mhhCrkpxchJgvYJ += BuMufH;
    }
}

string esGuF::VEywulPfmloM()
{
    bool EWtkuPKYmGQ = false;
    int iABiEv = 54986629;
    int MqafCMMezDtVwsY = 1837819160;
    string reAzA = string("vKxSZosymETlbZYWSpsrgzOgOLikMbUsYOlWzlZUcRWivLYOQkbBaPTXEIzCsgSHbwUvWumVHOQfQSvcfsjhAgxyPuaJKjtOkXJReaBlbMojODyu");
    string OxKezXHOJ = string("gLtBBvvUAZfmaMpEvxZymWbFUPMnqYoSeBvCUbGfPdspyEPxlUfoSzhqHSniBWgkwqOxZQiGwJwFhzFxzwLzJnDNmldwJWIslsLCOMqvAhfQVkUOWBPsfEjQUlxyKBOpCHFOazBSqbgUFAthqvb");

    if (OxKezXHOJ >= string("vKxSZosymETlbZYWSpsrgzOgOLikMbUsYOlWzlZUcRWivLYOQkbBaPTXEIzCsgSHbwUvWumVHOQfQSvcfsjhAgxyPuaJKjtOkXJReaBlbMojODyu")) {
        for (int peYrUlmWl = 420277420; peYrUlmWl > 0; peYrUlmWl--) {
            iABiEv += iABiEv;
            reAzA = OxKezXHOJ;
        }
    }

    for (int KSdlEGrh = 557065639; KSdlEGrh > 0; KSdlEGrh--) {
        continue;
    }

    for (int vlSthhVEr = 583774523; vlSthhVEr > 0; vlSthhVEr--) {
        reAzA = OxKezXHOJ;
        EWtkuPKYmGQ = ! EWtkuPKYmGQ;
    }

    for (int splfDVdjNy = 1181636331; splfDVdjNy > 0; splfDVdjNy--) {
        reAzA = reAzA;
        OxKezXHOJ += OxKezXHOJ;
        OxKezXHOJ = reAzA;
        OxKezXHOJ = reAzA;
        reAzA += reAzA;
    }

    return OxKezXHOJ;
}

bool esGuF::MKSnuJAisYfS(double vbXqmRjACx)
{
    string zvZHlqhLpQSthsYq = string("vdnZyOBMOesireUchzvjGDKwrJaPxSCdMPwPSWMKQpaIJnrfOxOWqDLmTefmTLdUkDhKHeSBUFozKsEvlEkMydyyShuqumCMVHYkSuoqsRVgcdxFuMoRmIfTmmWxSvaKuGZhHTbHGqEpSgGxFwJtnCXqVkRgfWEGnLEZqExFo");
    double OcpvfutHcN = -104882.46367732178;
    int uYvVGX = 2009431675;
    int HQOFyeOmZAINGhz = -1907356445;

    for (int QFkWAPIJUsLKrVgg = 1090214836; QFkWAPIJUsLKrVgg > 0; QFkWAPIJUsLKrVgg--) {
        continue;
    }

    if (uYvVGX <= -1907356445) {
        for (int IFRUsnHEfHxcrNk = 1774712246; IFRUsnHEfHxcrNk > 0; IFRUsnHEfHxcrNk--) {
            continue;
        }
    }

    for (int DVJFzUlNfo = 1124925411; DVJFzUlNfo > 0; DVJFzUlNfo--) {
        HQOFyeOmZAINGhz = HQOFyeOmZAINGhz;
    }

    for (int OOAOM = 1141145807; OOAOM > 0; OOAOM--) {
        vbXqmRjACx *= OcpvfutHcN;
        uYvVGX /= HQOFyeOmZAINGhz;
        vbXqmRjACx += vbXqmRjACx;
        OcpvfutHcN -= vbXqmRjACx;
        HQOFyeOmZAINGhz *= uYvVGX;
    }

    return false;
}

double esGuF::ZaEhBabxCLJ(bool XvpSoU, int OSgQCnQbpBoYOzTI, bool XpfhMEKUPiEzJIQj, int EqIbIJUglO, int KRDRhfxFNShyz)
{
    double TvjDL = -446177.68384530937;
    double kJaecWavSXuu = -919592.5642093382;
    double ADLFxbvYTxEFmxPB = 43682.058015684015;
    bool CJKIgDyd = true;
    bool ZWdPGEhdbWFEOl = false;
    double RvhIdJw = -484138.44848540804;

    return RvhIdJw;
}

int esGuF::YlkOzvmqFTxbReSn(bool XGlzQTcpA, string jgtIxBnaJkl)
{
    bool qCxZHmXcVweN = true;
    string nwCwOGZtx = string("jQfVFZLFKLsdJYdqinBsagbZCMlsaWiDyAlRGDx");
    string BpXdYw = string("RgnqjGSATDMzRyTzvvJCkvaZfEMIIDKRQqpQCrjNhuxnKVqYrVlAjxGCiQUMqebrarphNOwqCicUNqVGJQtVWezpugrUCBTQsYyozgXeEXdWsvGUOSEmdSTNyauMIIRUmoMyVPXojcWeVMPDHpuzSNEnqcxpJsDkxNhGbnEkobvNrOjsBMgbaxJjJjlozpfwRETczovdyunXiGmuyKgmipdsXUtAHMNTwADwviNrXKcljOKUflM");
    bool bMMZavsdI = true;
    double ydVeSxsKumXJlSum = 392241.9465690501;
    string IxDFO = string("miWfFrEvfPmmnCfAJQjMjEmwFGcARlhfmPZPVXpdXTEeckyUIKUkxQCRAxTqouWVnPxvYWrlRChXmRxRiPaOLYnMgcKFiOdDGXZXjANaEAkKSziiYSYRBUrMKlJPgZVVBAfMBlxwdvwuIaNdEOVxSfhAJvnTShnvzkFHRYfhctGegofYZwdhXvRKLjf");
    double dQGFzUkxaB = -343734.53289177705;
    bool KjJPtXUKn = true;

    if (XGlzQTcpA != true) {
        for (int DAnCPddgBSE = 187466224; DAnCPddgBSE > 0; DAnCPddgBSE--) {
            continue;
        }
    }

    for (int ojkuRd = 449240139; ojkuRd > 0; ojkuRd--) {
        ydVeSxsKumXJlSum = dQGFzUkxaB;
        qCxZHmXcVweN = ! KjJPtXUKn;
        qCxZHmXcVweN = ! XGlzQTcpA;
    }

    return 880479216;
}

void esGuF::LBXRTIKODFrwMCNx(bool TxVkNWkNsmjjZPga, string YqVauMLaUqu, double AhywTqoYEQb, bool aSUtYnyUdKDWHWjn, int frHiwdWpFKVx)
{
    bool lKbZDLHgDtk = false;
    bool HFgVsKEGYqDRLpwj = true;
    double pXdHLn = -333071.79217163235;

    for (int FHUIWQnB = 320897141; FHUIWQnB > 0; FHUIWQnB--) {
        lKbZDLHgDtk = ! aSUtYnyUdKDWHWjn;
    }

    for (int jUauJIUFsCZx = 1000703597; jUauJIUFsCZx > 0; jUauJIUFsCZx--) {
        HFgVsKEGYqDRLpwj = ! aSUtYnyUdKDWHWjn;
    }

    for (int mBNCqEIOXaSwvOPh = 1889229394; mBNCqEIOXaSwvOPh > 0; mBNCqEIOXaSwvOPh--) {
        TxVkNWkNsmjjZPga = ! aSUtYnyUdKDWHWjn;
    }

    for (int PEilnlgTxrXiC = 675225053; PEilnlgTxrXiC > 0; PEilnlgTxrXiC--) {
        aSUtYnyUdKDWHWjn = TxVkNWkNsmjjZPga;
    }

    if (HFgVsKEGYqDRLpwj != true) {
        for (int PDawGabZ = 1152636024; PDawGabZ > 0; PDawGabZ--) {
            aSUtYnyUdKDWHWjn = ! TxVkNWkNsmjjZPga;
            HFgVsKEGYqDRLpwj = ! HFgVsKEGYqDRLpwj;
            lKbZDLHgDtk = ! TxVkNWkNsmjjZPga;
        }
    }
}

double esGuF::BaUVCQreJAzLYnL(bool gIHXdOfQmzZRUj, bool seDjysBOasIsOQx, string zpKxBRRjlTHf, bool fzZxYVUwy, double nsbzcOTlbepzrQp)
{
    bool jggQnSLCE = false;
    string XixLMLOUKkTHR = string("NsAUHeLhyhcuKWDpVrfilzRzmQiagEQtyjdpaAmhsnMWctgnnCkLCrFIlnKCbvwPqnbjtOgjrTShWuGpLxopiYVZULuzFawbgcEhyNDSmzUpxapqgSfKihUVGTgIhKqEnqoEYM");
    string MXyVuCiQGXLA = string("SlTsqOnxEymEMHoiRgoMXfUUHEwlcEtcYSisJBQwjZqTvBrUBGCinWmduOyHCpmkfZfFOmwSJcZrcURwnYMCOYHloATuh");
    bool KJrJKKGYyQ = true;
    bool OeVINTDroXkP = false;
    string SjvcG = string("hMWxaURstrlOPcXPkqFTQiodIAnNnxFeOv");
    bool lhVMIoH = true;
    bool YYVSAmPhGW = true;
    double YOcLhCrjVAbiIZuk = 15451.074310944072;
    int EjbtM = -1943136172;

    for (int TPyVjk = 102317284; TPyVjk > 0; TPyVjk--) {
        continue;
    }

    for (int faCIvIprTZPR = 1258067517; faCIvIprTZPR > 0; faCIvIprTZPR--) {
        zpKxBRRjlTHf += XixLMLOUKkTHR;
        zpKxBRRjlTHf += XixLMLOUKkTHR;
        fzZxYVUwy = ! seDjysBOasIsOQx;
        fzZxYVUwy = ! YYVSAmPhGW;
    }

    return YOcLhCrjVAbiIZuk;
}

int esGuF::xayHbn(int BuDFVToSebfyelJ, double CHnJaWt, bool HKZpqFsjpI)
{
    int DvCiedGoDJAMcR = 1426872960;
    int CvrxXlN = -405188818;

    for (int rZIUwidS = 1831802083; rZIUwidS > 0; rZIUwidS--) {
        BuDFVToSebfyelJ += DvCiedGoDJAMcR;
        CvrxXlN *= BuDFVToSebfyelJ;
    }

    return CvrxXlN;
}

double esGuF::TxrOztfsdZ(int QWZhfgAwAWUAgKCM, int OQorRW, bool xYJWXZCU)
{
    bool qSNNNAZACC = true;
    double tXOLkqlkkvnJ = 741769.500351997;
    bool YPXinyKmv = false;
    bool XBIBRZPGUVSf = false;
    double dIzGb = -1004366.1766705079;
    bool ftJLzbZZDz = false;
    double iNpDnCtIyHuYQ = -71523.14299565936;

    if (xYJWXZCU != false) {
        for (int uVvGumOExbsu = 719531054; uVvGumOExbsu > 0; uVvGumOExbsu--) {
            dIzGb = iNpDnCtIyHuYQ;
        }
    }

    return iNpDnCtIyHuYQ;
}

esGuF::esGuF()
{
    this->jaNxQqUpnk(965052758, true, string("JiAYVHtybAzLznPzFtGcIXwBkxNjIFfoDLPhYIMieoGAYOEDDQrHDLrVPKVgJixIdJVXAPWHfAbRalnjnhvMOdXejVkhpeBQvpJNwLHHnpktJPFVXNaaXwhBUsQnwHhgEFZLhVBIypFbXjPbKsaLUvLihBtifQRvlHrUtyYotURGLchR"));
    this->WePWuIQHfUtBsxDa(true, 106026757);
    this->uHygcoa();
    this->VEywulPfmloM();
    this->MKSnuJAisYfS(-511258.32159802277);
    this->ZaEhBabxCLJ(false, -1139440018, false, 814424799, 139691389);
    this->YlkOzvmqFTxbReSn(true, string("vVqxfwvNmrBHjAZCAKuJbyggRNLjedvkcNqfmqbeOMtNAvVhmkIDBhocmHjjpWiYaqARsgtKNJJyUKpixBNjfmAeNfKRltCtwErAcqJmLAMsgPgRvqQhMSPZukkgBAZqPJvJCCtYhiSEnUpXMDTUxOltxyqpOQjoSbPJBlVLc"));
    this->LBXRTIKODFrwMCNx(true, string("lobccjbWUCJjWhGnHqZUcQUqPeeiiZMuJIkcTopqYJavUKfosVNQnPYWmOTknockMtKKteiLzdpdFUzuMnyXPpezmtElSBcjLXGclPoZfyhpfasqeJBtCudfJrOdsyXqPTUlYaTQUIsJDPIfGUxwBEyGnqFpSjxObpyoqkQktuPAekDQGtyFNGnfrDxSNSGRnjAiPRIBXkPzeeyHbs"), -744222.6643229305, true, -693271985);
    this->BaUVCQreJAzLYnL(true, true, string("RIlNGNrenHCnieCmtJHOAMJISUxhpWBsRMuxCUGnUrAMeysTEXuaeYLHbmcyHwIgGjVbsLwvoPRkzTysfyQXVLIDtnhhmCIBwNBYOsrCfOARzLMyVWHXiyZXYTnxJZegzXgpRsPwuXJNfnyTqJQQBWskEfthDDpBmXcS"), false, 233772.0436191562);
    this->xayHbn(118320911, -460371.630554398, false);
    this->TxrOztfsdZ(988913178, 3963816, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uWftiUrFckjg
{
public:
    bool VkAwxKSuTGgjlJ;
    string naZCFmsPZmI;
    int PdUryOACe;
    double fGsqwz;
    double qrLuacoz;
    bool QKoGDZSgcrN;

    uWftiUrFckjg();
    int NRoIHKc(int FRZneLauPHZm);
    void cErQb();
protected:
    int kjzNWJzicp;
    int jJNQdUPO;
    string HKMDagzhANvGIClX;
    bool XMNJowyi;
    double WbXGanyP;

    bool YGBxWOiogJtHef(double JUvfhBdHOUgMJmCt, double JktPPJWEI);
    void wveeTJFHNVNP(bool ycryqGMxbygWkk, string joGRRtvMqcCB, double xmNgojddpaAtQuvK);
    double pVQQXvMh(int EMBkRi, bool UxIpPXDoGsMWU);
    string BaotQAgxndSm(int hEEUbFykZ, string fjiVgAwblN, bool SBWMNZUvAbZpZxe, int ZcEkmyfyt);
private:
    string EjMFGYSKu;
    double bwtHkrovETWz;
    int HoxsdjQp;
    double sqwluFQCpezii;
    double YdHztlbL;

    int aUTqR(double itTkS);
};

int uWftiUrFckjg::NRoIHKc(int FRZneLauPHZm)
{
    bool KQksDAffbgywc = true;
    double TuTuwQaRJHX = 658315.4211320565;
    double AwKTDgMpIYZu = -880219.6558786402;
    double TrnEFe = 1039452.9577899505;
    bool peXPEKGffFEw = true;

    if (TuTuwQaRJHX > 1039452.9577899505) {
        for (int dTInQCvAD = 290360639; dTInQCvAD > 0; dTInQCvAD--) {
            KQksDAffbgywc = KQksDAffbgywc;
            TrnEFe *= TrnEFe;
        }
    }

    for (int BhpwNQcJMpju = 2097433868; BhpwNQcJMpju > 0; BhpwNQcJMpju--) {
        peXPEKGffFEw = KQksDAffbgywc;
        AwKTDgMpIYZu *= TrnEFe;
    }

    return FRZneLauPHZm;
}

void uWftiUrFckjg::cErQb()
{
    int umJKBLG = -1836135832;
    double qbqYSlmsGBsrKT = 694804.5151175961;
    int eBzuZrZvOjwoyn = -592752036;

    if (eBzuZrZvOjwoyn >= -592752036) {
        for (int qJyEXRRINMJ = 1979845220; qJyEXRRINMJ > 0; qJyEXRRINMJ--) {
            umJKBLG *= umJKBLG;
        }
    }
}

bool uWftiUrFckjg::YGBxWOiogJtHef(double JUvfhBdHOUgMJmCt, double JktPPJWEI)
{
    bool uVOoYVJzAHrA = false;
    string SyjIuwcRRP = string("VorMUDzflKQzoQDeusPtYeWcIWebIfgffeLIuctvSkProJrmzCFPfXHcUnWMzacbMfuvMrnnUTEQFGvANitLyReyHVeUhTlWtvuM");
    bool GkHjyOtIUo = false;
    bool fzCUQUglSHohw = true;
    int TGYmTn = -405926823;
    bool rtsAgwbW = true;
    double KnENgOsjiC = -478272.0750188984;
    bool RaIHhCMjSsxIGMC = false;

    for (int ZrXgOQ = 1253806118; ZrXgOQ > 0; ZrXgOQ--) {
        rtsAgwbW = GkHjyOtIUo;
    }

    if (uVOoYVJzAHrA != false) {
        for (int RFbfWEweoAOy = 1235141919; RFbfWEweoAOy > 0; RFbfWEweoAOy--) {
            GkHjyOtIUo = ! GkHjyOtIUo;
            rtsAgwbW = fzCUQUglSHohw;
            fzCUQUglSHohw = ! uVOoYVJzAHrA;
            RaIHhCMjSsxIGMC = ! GkHjyOtIUo;
        }
    }

    return RaIHhCMjSsxIGMC;
}

void uWftiUrFckjg::wveeTJFHNVNP(bool ycryqGMxbygWkk, string joGRRtvMqcCB, double xmNgojddpaAtQuvK)
{
    string pPSggFsCkbd = string("zOcIKVmHJePOqANYwvjDbvhTbHmtvWGJDgEYnXcopxoYynBiALTLXTeYGxrDPtwyYieXAZjkTAXMFNMyGdjZdeWQFLTSHeqjqkhIOnwFPibZusvhIHYqSIaC");
    int owBatXsmxIosd = 79600923;
    string YmfNhQyhYpCc = string("oUYmObqUscATUHvvFEihgYzSxNvMAQQrNTUacqeQBDskUJUINhtUXQtSbCxvpbfOyaoCLLalYbzKMLBl");
    bool zgBxrQNAJvAPuJ = true;
    double AbkhlwJizHCnaly = -289018.1387224316;
}

double uWftiUrFckjg::pVQQXvMh(int EMBkRi, bool UxIpPXDoGsMWU)
{
    bool tFPIuUKldmLUgwa = false;
    int jKspQS = -1015667947;
    string tXxEFkVfVL = string("pSQBRloSyaiUpvkHFLYlozRQcwIZqLDsUQyfyvrJhMhYObnCNAqkFHcEOBPOPYxtoNnsSqruhsrIzqtVKRDoWzrlUTMxgLymDkGJVoKwwWijXscAwVeniaLkKDuztrMNvhjCTDixkrTjFSRuiJVjrHqbiuAhJRpmEtrXdvGzbBcugCwbOXMjudrCPDbWwdVXQLRXjBboquTfzEpbZibmJCAYNhqOfMGRPHpOJUlQYdVBrKYKVd");
    string SxKyJCOFiJu = string("yQNKmrIglxyyYQKXXVdVgfUuuHOhEovWppmODkJKijgMLKZmOGGMrvvrEmguWPZLlAQQWBJmpMbAcenRXicTyyPgYgeDtWiJmQhbBLFWroZSDnNVeJxegbXBKkBUGxtiTQTLOYukjVqpZGqRCWnDeAlUphhwqoowQSTQTZWagpsqtzwzrgKZzWwkYhtqENULwPtUuMomStKqYeTEoahLYdNtCwjWDUfmK");
    int QbEFS = 1520609472;
    bool rsLUelFQkKQV = false;
    double kijlhZnvYQkS = 858470.677525512;
    double SUjrM = -135650.36816619374;
    int ANgVhbRWnxtXsWc = -868033635;
    string RmEGKItTFRJNzyvK = string("WLPjLIBrzQfZjDEjKkWkluXhKQNTXMLRJdccPCEldeRdZaVxDzKzmQRIJtQhpJXFFYDlLeKwnYiDLwntKSOgQKalaZYSCHqvAEPOYGoaDPiCbNDtnMjfjTEKezCZAGUtvKdWcIAlTTkprawqlcmXsSnJWssImFZXehuvmK");

    for (int MdulXaFVKxYv = 625927812; MdulXaFVKxYv > 0; MdulXaFVKxYv--) {
        ANgVhbRWnxtXsWc -= jKspQS;
    }

    return SUjrM;
}

string uWftiUrFckjg::BaotQAgxndSm(int hEEUbFykZ, string fjiVgAwblN, bool SBWMNZUvAbZpZxe, int ZcEkmyfyt)
{
    bool aupaOBaE = true;
    bool DfhHhInGo = false;
    int SBOSrIMwJSaZ = 1921366121;
    double ExqmboDRhuolHLAZ = 622348.8767085113;

    for (int IURqGqexFiWxMYSg = 982140261; IURqGqexFiWxMYSg > 0; IURqGqexFiWxMYSg--) {
        continue;
    }

    for (int WdgucXKvZqjoRkAd = 1493761194; WdgucXKvZqjoRkAd > 0; WdgucXKvZqjoRkAd--) {
        aupaOBaE = DfhHhInGo;
    }

    for (int ZYugxUoZ = 334248592; ZYugxUoZ > 0; ZYugxUoZ--) {
        DfhHhInGo = ! SBWMNZUvAbZpZxe;
        SBWMNZUvAbZpZxe = ! aupaOBaE;
    }

    for (int rFZdWqJGdFHMbiL = 579422802; rFZdWqJGdFHMbiL > 0; rFZdWqJGdFHMbiL--) {
        continue;
    }

    for (int wnieqebIJydfbwe = 76733146; wnieqebIJydfbwe > 0; wnieqebIJydfbwe--) {
        SBOSrIMwJSaZ *= SBOSrIMwJSaZ;
    }

    return fjiVgAwblN;
}

int uWftiUrFckjg::aUTqR(double itTkS)
{
    int DOgjPDKyO = 67289003;
    string XFebpcxyklPC = string("CGGc");
    bool HXTOqgBxNp = false;

    if (XFebpcxyklPC <= string("CGGc")) {
        for (int MfcooJvDNC = 173206640; MfcooJvDNC > 0; MfcooJvDNC--) {
            HXTOqgBxNp = ! HXTOqgBxNp;
            DOgjPDKyO -= DOgjPDKyO;
        }
    }

    if (XFebpcxyklPC <= string("CGGc")) {
        for (int MGTkLJvaeceOXm = 1679497366; MGTkLJvaeceOXm > 0; MGTkLJvaeceOXm--) {
            HXTOqgBxNp = HXTOqgBxNp;
            DOgjPDKyO -= DOgjPDKyO;
        }
    }

    for (int hIPtZNq = 1216923562; hIPtZNq > 0; hIPtZNq--) {
        HXTOqgBxNp = HXTOqgBxNp;
        HXTOqgBxNp = HXTOqgBxNp;
    }

    if (DOgjPDKyO > 67289003) {
        for (int UQUITWDMKBU = 112439351; UQUITWDMKBU > 0; UQUITWDMKBU--) {
            DOgjPDKyO = DOgjPDKyO;
        }
    }

    for (int futsKWOEJ = 1412723361; futsKWOEJ > 0; futsKWOEJ--) {
        itTkS *= itTkS;
        itTkS = itTkS;
        itTkS -= itTkS;
    }

    return DOgjPDKyO;
}

uWftiUrFckjg::uWftiUrFckjg()
{
    this->NRoIHKc(2071177720);
    this->cErQb();
    this->YGBxWOiogJtHef(706637.0633208195, 275973.97916114196);
    this->wveeTJFHNVNP(true, string("NmJLQNVkHDTJGFMQnKBZglRHxcMdjkrHeQFohEYWBcEEISUNoDVfoQIrrikvNXyzGZQXpgrpAuJyYXtFXCJuZaqIwMVMFhHGHTBJwNojMsarzzhJAxGZjRAfyssgbRkQCeFwMIitTywV"), 541432.0718848718);
    this->pVQQXvMh(-1348628515, false);
    this->BaotQAgxndSm(349932728, string("iFRzpqoKEfJlZNiIlaaspTslwfkKXRHAzRnIMEzcrwMHffMLLBgzrIVdgvpWWVbDasGhnXjCrpsrAGnkGtPHluTlYGBYRCmhFYqHhTnXkfMfhXSptqvHhsJFeveWWlPOtOLNzyuhcaRLkIkDxsLxjsCiu"), true, 1116204361);
    this->aUTqR(533086.269404586);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GIRjsI
{
public:
    double UUPwjKBXvvUIk;
    int kYsWv;
    double FGnPAQi;
    int IJgUPRGaj;
    bool hdQmvhEqAAx;

    GIRjsI();
    double FyZEhYmBdvDRc(int lcyefhpuuaibKHDo, int wrWLDnbal, string YrvmAivNxtLr);
protected:
    int LTIwBcg;
    double XRRyuhbZZ;
    int efLzaanjKIJRR;
    bool nShprJhJL;
    bool twylYui;
    double UcxADTMDxamJsL;

    string CTUZDTI(string ulcBvzyvNbNBVsIo, string jFFtMPWAYJSU, int FIjPnJifEEjq);
    string EuVclSAcISsX(double vDyefS, string EdwgGdmBHqusF);
    int bPdHEcXwrtV(string nIWMcouDDyradCh, string TuHQmkvQkXSX, double GiJHfshkL);
    int VHbpqQvrEpmMstPk(int NRXZUUdXGpJlhBkC);
    void WyaVoEWYHQHn(int ncXhBl, bool SFGYwQmcRdvUSu, bool gVtPOUjDyP, bool oMmfKrGTEhksVV);
    void qrnthmVbgEmxw(double YBevAS, double NSkeTSgBNIkqD, string MxXshfRcqWLqavy, double GJMRLYfk);
    string ngawWXRK(int TaexSVZp, bool yNUmlEWIDGbnPU);
    string wvJbzf(int mSKZhdvcSXqtvK, int gblJiJpNJemZ, int JSTqaGsmKz, string IUqytDQzk);
private:
    bool SqYJbGrsW;
    double gfsHVzqrkUJiJB;
    double UWiSbqN;
    bool KAbTVZdI;
    string bVmuKch;

    void EoATtXF(string FKBnqoxlY, bool PHGYPCUBvfaigEC, string yXMFQpUeFtyzT, double vhGNixWZQY, double zXzmfFPeNT);
    string OrtVyFV(double WorZjCwLuFkwO, int yxhZtQJ, string gqbQGUsVrfnKxS);
    int dJNWuwRJbRWZXft(string EAqYSS, string cWVPaKwHa, int ILZNO, string qnVGmYwdyN);
    string QVcPqF(string GQvJXyhCNdtN, string WsCVyBGJnUmmSWf);
    int JpJDud(double qNKwiUmR, string TRfGAhCLfWWVd);
    string CFZtHnk(string BfPsQBkUkRDVjA, string orUgrUDxxZyJM, double fEljnYHnUUm, bool CQOFuXRHIfM);
    double XkTJrRW(bool AXWQWkRjmPuq);
    void zVRWQrztHGm(string PUFrScpKGMh, bool CePYODTJuVC, double ysNCQxmhFau, string VhzwQD, double ReWXCrDvjExPl);
};

double GIRjsI::FyZEhYmBdvDRc(int lcyefhpuuaibKHDo, int wrWLDnbal, string YrvmAivNxtLr)
{
    double ylptN = 624793.3121734952;
    int KNmgozsjhrwCOs = 367942214;
    int BPOgEM = -1319558042;
    int SEAoyIQOBvkMJFL = -950937191;
    string ROhckmqdWWKnwOW = string("ZqifavT");
    double RZDxMBZDePYCVsuZ = 3233.8741082368956;
    double DQDZOJ = 668205.2684639214;
    int qoOxHbBckHYFnYql = 2121229060;
    bool QPOIMVBYh = true;
    int sBXlykj = -1348417975;

    for (int rSeJtnGNqKwu = 1354623695; rSeJtnGNqKwu > 0; rSeJtnGNqKwu--) {
        wrWLDnbal -= lcyefhpuuaibKHDo;
        YrvmAivNxtLr += ROhckmqdWWKnwOW;
        KNmgozsjhrwCOs -= wrWLDnbal;
        lcyefhpuuaibKHDo = sBXlykj;
    }

    if (qoOxHbBckHYFnYql == -1319558042) {
        for (int vHNaYkVW = 1084789125; vHNaYkVW > 0; vHNaYkVW--) {
            continue;
        }
    }

    for (int qXfwqkTVY = 1281276795; qXfwqkTVY > 0; qXfwqkTVY--) {
        lcyefhpuuaibKHDo *= lcyefhpuuaibKHDo;
    }

    return DQDZOJ;
}

string GIRjsI::CTUZDTI(string ulcBvzyvNbNBVsIo, string jFFtMPWAYJSU, int FIjPnJifEEjq)
{
    double dnaoVMjD = 1025265.5728168397;

    if (FIjPnJifEEjq != 444949790) {
        for (int FpkmvWXwh = 2093517677; FpkmvWXwh > 0; FpkmvWXwh--) {
            ulcBvzyvNbNBVsIo = jFFtMPWAYJSU;
        }
    }

    if (FIjPnJifEEjq < 444949790) {
        for (int AXSFLtJkmVM = 1760859975; AXSFLtJkmVM > 0; AXSFLtJkmVM--) {
            jFFtMPWAYJSU += ulcBvzyvNbNBVsIo;
            ulcBvzyvNbNBVsIo += jFFtMPWAYJSU;
            jFFtMPWAYJSU = jFFtMPWAYJSU;
        }
    }

    return jFFtMPWAYJSU;
}

string GIRjsI::EuVclSAcISsX(double vDyefS, string EdwgGdmBHqusF)
{
    int NbxUWUulunp = -844738030;
    string XGpzNovYmSAz = string("BNSKMrDdrKwHzLRHKtSAFTxqAkqJPyTjtZpgCEcLYzPhgSKcfNbsXmSsjAPnYNmutCUmmLPfrWprcISnFGHNmvxiMLXTRZFHEGVxCyvYtsYtvUXZLcLuaRuLVFZjNSvQgoTSuggfuLSSIwozmijBvkZFnvCzZSCiVaYpmEHievQridweROyNvXagcpsIGBiEqLWvyEmJKmSTb");
    int oATqjitFkmGcVT = -386318757;
    double ZLZNsmufPkedHiLo = 335113.80411561584;
    int OKRnxJHrlqyU = 879981142;
    double zOTpc = -958467.409659885;
    double BMjyhGK = 251684.7910470878;
    bool yaErOqsQdaEvuVV = true;
    int ZsUJVwgzbXDa = 1760149526;
    int UkbvqxlGqJG = 596664679;

    if (oATqjitFkmGcVT != 879981142) {
        for (int PKKmEGgJwT = 541061067; PKKmEGgJwT > 0; PKKmEGgJwT--) {
            continue;
        }
    }

    for (int fYlKtWHvEXCmzp = 1109219727; fYlKtWHvEXCmzp > 0; fYlKtWHvEXCmzp--) {
        continue;
    }

    return XGpzNovYmSAz;
}

int GIRjsI::bPdHEcXwrtV(string nIWMcouDDyradCh, string TuHQmkvQkXSX, double GiJHfshkL)
{
    double pCIjbaGdGzrcbtK = -647385.4163530574;
    int wsvqwLNnRPRvEUs = -1644198450;
    bool bnjpNxS = false;
    bool XrMEXK = false;
    string RIcamDkugao = string("hjOtaWElVZTFxlutiIGSXXFDmupsAsDNhoFGTrFzFlPOolckxsEzpwhSjQDcYvASgknOAPUeacNwnuyhgYSoBaRfGYfVkLfMyZfDDWLjNyItuBNplKpLCPNgUGMzHvAikNfiGHPjjdHtkYDuWOeQgveakBvQq");
    double BiNoxEqGF = -577309.2769154799;
    int qqZuT = 1385550527;

    for (int ELyneySvmfzKBOqG = 1925312250; ELyneySvmfzKBOqG > 0; ELyneySvmfzKBOqG--) {
        continue;
    }

    for (int ZnTgIanGoCaL = 1825981548; ZnTgIanGoCaL > 0; ZnTgIanGoCaL--) {
        continue;
    }

    return qqZuT;
}

int GIRjsI::VHbpqQvrEpmMstPk(int NRXZUUdXGpJlhBkC)
{
    int lgJAwW = 476374777;
    int OyXUQniNSbJdF = -1109332773;
    string KnWnChZsOUgKkJ = string("RsfnfchzfkkrwuvDvpogwzZwHwaWwRNyHIidgXWICLuozuzenGKIcar");
    int QelGYWAe = 1770733796;
    double XRGyRRqxLkT = -743556.4663157902;
    string QXxAaaqADFsEiK = string("IylljVKhBGVXzkizTaYnmTljdQpYnKEExApYfAwdjLHbAakjpfauyMeLSCtyKkSFFTgSPkQDVbWiZDkNATcNHTlAZOLIzpuFUvTDmrMzeXDgRDDVVNAajHLMHxHPLIYGCRguPuRewhzIGhPXKgYsR");
    bool CeBoibfbDsOtms = true;
    string kfACzodk = string("FnmLsvUKztgyFInANShQMCNOVluBmxHnFNMgZwpRCDBzInXwBHtvAeTGOVmuRNpJNHNOIaKWlSagwTMCAhGeoeAFfGCYGQdHpwtEgLZuRSDaKQeUTAdRXhcesfBvyFXGFWguyZjQEQqlejtZQUrfRxzjHPtYkFJgPNnU");
    double DmenU = -677546.4393374696;
    int FprgQeIQLQhv = -597387627;

    for (int SjuyHwxiCy = 1226558288; SjuyHwxiCy > 0; SjuyHwxiCy--) {
        OyXUQniNSbJdF /= QelGYWAe;
        QelGYWAe += lgJAwW;
    }

    for (int hrBAlXGf = 1833337647; hrBAlXGf > 0; hrBAlXGf--) {
        NRXZUUdXGpJlhBkC = OyXUQniNSbJdF;
        lgJAwW *= FprgQeIQLQhv;
        QelGYWAe /= QelGYWAe;
    }

    if (KnWnChZsOUgKkJ < string("FnmLsvUKztgyFInANShQMCNOVluBmxHnFNMgZwpRCDBzInXwBHtvAeTGOVmuRNpJNHNOIaKWlSagwTMCAhGeoeAFfGCYGQdHpwtEgLZuRSDaKQeUTAdRXhcesfBvyFXGFWguyZjQEQqlejtZQUrfRxzjHPtYkFJgPNnU")) {
        for (int NpdsYKXnFPUiJ = 1583838335; NpdsYKXnFPUiJ > 0; NpdsYKXnFPUiJ--) {
            QelGYWAe -= lgJAwW;
            OyXUQniNSbJdF += QelGYWAe;
        }
    }

    if (NRXZUUdXGpJlhBkC == 1770733796) {
        for (int BMoXwfpjAhxy = 1905527484; BMoXwfpjAhxy > 0; BMoXwfpjAhxy--) {
            OyXUQniNSbJdF += FprgQeIQLQhv;
            XRGyRRqxLkT = DmenU;
            NRXZUUdXGpJlhBkC *= FprgQeIQLQhv;
        }
    }

    return FprgQeIQLQhv;
}

void GIRjsI::WyaVoEWYHQHn(int ncXhBl, bool SFGYwQmcRdvUSu, bool gVtPOUjDyP, bool oMmfKrGTEhksVV)
{
    string fsCCVzcmpeGuNZqk = string("rJNMkPkGwhwiWhrCDqDQZfxLbkSEMAvPCbcdkwRPpHhCXcjYYAIRWLJXuQsfmjEuinz");
    string OsNiCvHJJ = string("kStMlEQJlimDIPAFIEYanwqWvSmBQnRFzyPpsSVjuLTsJrQHZlYZEWwTjydApiMuzDlXXsPWyDcCTmanuCPfwbAgxVpGQhoR");
    bool kerAsqAMovXKHZjM = true;
    int mBAkKohBZM = 183952003;
    int WTNNTjf = -525471541;
    string sCVLOjK = string("myUgqMkpNczRLQANpXTZpUvlvQmIUlYnIMCnJuttgCbyaQpWkpZgaOULkQyxPlUIReCRXoDECdLRdUfwQDMFhDXFkcRzSQHBSigjbfMnabCIXdBWhRdiEujYuIfbVtbtalMObbMgZLRecyRxMgIyUlVHbRlHUWcSMTtprHbLDtCxTdbNmgBifMofhmnKEaGVOCyjZ");
    string BIzAwUXh = string("LxIZQkOuCbYagGMiDIvDmCpFLxRhVAOkxEUhFYoGBvPnQTG");

    for (int IMlpixmSGbF = 950592090; IMlpixmSGbF > 0; IMlpixmSGbF--) {
        fsCCVzcmpeGuNZqk += OsNiCvHJJ;
    }

    for (int fkOJHdtnkWMYSKr = 178508499; fkOJHdtnkWMYSKr > 0; fkOJHdtnkWMYSKr--) {
        continue;
    }

    for (int PqBHnzq = 2022452007; PqBHnzq > 0; PqBHnzq--) {
        continue;
    }
}

void GIRjsI::qrnthmVbgEmxw(double YBevAS, double NSkeTSgBNIkqD, string MxXshfRcqWLqavy, double GJMRLYfk)
{
    double wopuxyOKCEfgN = -356620.6910179872;
    int UNhdEAuAaTxgBT = -114973983;
    bool nemMEeJWSJxPEX = true;
    string qIHPwBDsTYCVm = string("JLiIcLibkEqAfIlkfanUXwXuPnmkSlGwydXQpKWUfPgaifUTKyOtIjxEOkSadSLsVjFlMNhlniGPsqUrnVHCbBbkvvdgdoXZaxRfpCkVNikLEFKvnHJUdnZUbIKJrsUuaQULCFJdFlkpQLZcHXyvXbzBjItlFxDsvYsBlCrHLJmYnlhxrrvqrWzlPvvoznGosEKHfXRMkwE");
    double HKDHou = -609764.4513594148;

    for (int DwHxSLcbebEeiGiM = 1933427960; DwHxSLcbebEeiGiM > 0; DwHxSLcbebEeiGiM--) {
        HKDHou /= wopuxyOKCEfgN;
        YBevAS += wopuxyOKCEfgN;
        NSkeTSgBNIkqD *= GJMRLYfk;
    }

    if (NSkeTSgBNIkqD <= -987806.1204808949) {
        for (int njWWGiIYz = 2089396731; njWWGiIYz > 0; njWWGiIYz--) {
            wopuxyOKCEfgN += HKDHou;
            NSkeTSgBNIkqD += GJMRLYfk;
        }
    }
}

string GIRjsI::ngawWXRK(int TaexSVZp, bool yNUmlEWIDGbnPU)
{
    string jdifasEA = string("QczKrwowDsTXIEztpiOFIJDDOqwgkAwctIIOIwJH");
    string QBpBK = string("fWahQpHDPSrncNcdtilGFTNtydspxXYGmJDhFSQrAnMsEqARLwIwhvEoBkhUYslNhelLVQNZPAkjwXQieqbyMBRYxnVtCJLWUqVMSnAbHvwktFPBldtfuhpyXlQeNrLXDnbTkSvGvvwfETmqlgiDNoSOCtQiKLEf");
    int uHkiK = -1530490140;

    for (int wnqdexGyxiWsRoNp = 1259455275; wnqdexGyxiWsRoNp > 0; wnqdexGyxiWsRoNp--) {
        uHkiK *= TaexSVZp;
    }

    if (yNUmlEWIDGbnPU == false) {
        for (int dLKvkTR = 1020940564; dLKvkTR > 0; dLKvkTR--) {
            QBpBK += jdifasEA;
        }
    }

    if (uHkiK > 930102301) {
        for (int VAFCF = 1610543401; VAFCF > 0; VAFCF--) {
            yNUmlEWIDGbnPU = ! yNUmlEWIDGbnPU;
        }
    }

    if (QBpBK > string("QczKrwowDsTXIEztpiOFIJDDOqwgkAwctIIOIwJH")) {
        for (int zKKesz = 1894404037; zKKesz > 0; zKKesz--) {
            continue;
        }
    }

    for (int nlvtOtlvtxGZcV = 1084142557; nlvtOtlvtxGZcV > 0; nlvtOtlvtxGZcV--) {
        QBpBK += QBpBK;
    }

    for (int kYxUmslLyFoXXOO = 1307763197; kYxUmslLyFoXXOO > 0; kYxUmslLyFoXXOO--) {
        TaexSVZp *= uHkiK;
        QBpBK += QBpBK;
        jdifasEA = QBpBK;
        TaexSVZp -= uHkiK;
    }

    if (QBpBK < string("QczKrwowDsTXIEztpiOFIJDDOqwgkAwctIIOIwJH")) {
        for (int tebupzQkLGTzRBp = 348177149; tebupzQkLGTzRBp > 0; tebupzQkLGTzRBp--) {
            QBpBK = jdifasEA;
        }
    }

    return QBpBK;
}

string GIRjsI::wvJbzf(int mSKZhdvcSXqtvK, int gblJiJpNJemZ, int JSTqaGsmKz, string IUqytDQzk)
{
    double OqIEfxlbVrAc = -255024.40324840148;
    bool VyOsSxlo = true;
    int RoOJQPQqMrhvfMd = -22829320;
    string JsAUPQxSIT = string("agraLZTNpiOPfAOVWJkEgqALfaKefIUEWLFNOOVvsrRaXYMaZhKbsssDgvPbwjXyNQIEhqtueaHFswiLAkIAZVEsfuTbzSgZbKSnAYSYwnsaZDeoTfGJaaQhnIzDFNhROdbQfHkLCUjLOriTmBAkRUIonzPdKUwccUpqcECkCmWqIrWQLQtJPUPNHGCMdgEZwmPxTDm");
    bool objpCITrfKduIk = false;
    string ESMhCEPKL = string("FiSHvPukqfLowObB");
    double edjcVPDrvveuqq = -491992.2638289361;

    for (int lEmuuK = 2116651345; lEmuuK > 0; lEmuuK--) {
        IUqytDQzk = IUqytDQzk;
        mSKZhdvcSXqtvK *= gblJiJpNJemZ;
    }

    for (int fjOBPPgU = 1079048853; fjOBPPgU > 0; fjOBPPgU--) {
        continue;
    }

    return ESMhCEPKL;
}

void GIRjsI::EoATtXF(string FKBnqoxlY, bool PHGYPCUBvfaigEC, string yXMFQpUeFtyzT, double vhGNixWZQY, double zXzmfFPeNT)
{
    int vcYWkLX = 1074860905;
    int pVqpDr = 430171807;
    bool ifcRjvyQDH = false;
    string SRTEXWGfbW = string("ByYlkSjwXhbZTmHWyUrKqqxyHBYHYjLEblInrhcvHemlDsbuSSWUgiaDFVJlOdMpxFYuf");
    string MtUvjaQJtWQ = string("mJQbbMCVdClFWLZRWAxyqSWonPSbYlnhFPZBtvUpBUtZXrFSralSPXspEbXgnlNTMVzQpkKQsInyBBQuVwrwYcrilpBXARHKmLbxvSqRDtFiTSUugOwBtSePmhxrNzGrykSdnLufYfjZOBHAnAPfOFWrSTSHz");

    for (int IzMOML = 289751270; IzMOML > 0; IzMOML--) {
        SRTEXWGfbW += SRTEXWGfbW;
    }

    for (int ExUUJvcINYCY = 770067770; ExUUJvcINYCY > 0; ExUUJvcINYCY--) {
        continue;
    }

    for (int RoQFVjNj = 88356726; RoQFVjNj > 0; RoQFVjNj--) {
        SRTEXWGfbW = yXMFQpUeFtyzT;
    }

    for (int TSsmAdPVD = 1149421835; TSsmAdPVD > 0; TSsmAdPVD--) {
        pVqpDr = vcYWkLX;
    }
}

string GIRjsI::OrtVyFV(double WorZjCwLuFkwO, int yxhZtQJ, string gqbQGUsVrfnKxS)
{
    double kbsHRlihetlp = -316635.6537002297;
    string mTZdBFNlOub = string("BXAeQOREPktJUeDxqYrZKSERPGDBSKiuvbaHmzVXEMvlsecmbKEoQfUReSxmclRwMrhwjqScisgqFQSmDaOWNSnBkdmmdbiVNBjBZViBtqnlolaewUvxpdvtrUcmMMYAaxcLTEZDciYaYkRSQwQFUIHjzxjAKtHgq");
    int tZjoDDwJoZrcYWcq = -586343404;

    for (int XEhZOh = 116685413; XEhZOh > 0; XEhZOh--) {
        WorZjCwLuFkwO *= kbsHRlihetlp;
        tZjoDDwJoZrcYWcq /= tZjoDDwJoZrcYWcq;
    }

    return mTZdBFNlOub;
}

int GIRjsI::dJNWuwRJbRWZXft(string EAqYSS, string cWVPaKwHa, int ILZNO, string qnVGmYwdyN)
{
    int ZdfXCXXlTsBaF = 1359904672;
    int tWEHGAYvAYIANysZ = 1157485376;
    string mZfMGp = string("tjNypobkHfLKnNdKSrEEyBDQTdECKmogEaMZECsBJPWzUBrtOotjWXKtLAMcGtVCyPRuJXzUzfJKaKMzQZwDYvCtjIHDKbaqDIjpsNICAjEwSItLJErqQeKwKRmFvtjAhHoRwqkjCuAbJvHgpMvjQTwbMHDLriSTptTtDoZasmjHQTdyDkrmBlcmJMzHQsowkdjfwNlToauWkqXiDuoyQ");
    int QeHKecCuFS = 336412363;
    bool klXHyIPcYXiwQ = true;

    for (int vtjUiBWEWSbThIEg = 1193134671; vtjUiBWEWSbThIEg > 0; vtjUiBWEWSbThIEg--) {
        continue;
    }

    return QeHKecCuFS;
}

string GIRjsI::QVcPqF(string GQvJXyhCNdtN, string WsCVyBGJnUmmSWf)
{
    bool YFMMaG = false;
    int aOhABQQSSgzeHZrQ = 621771385;

    return WsCVyBGJnUmmSWf;
}

int GIRjsI::JpJDud(double qNKwiUmR, string TRfGAhCLfWWVd)
{
    bool fXruoL = true;
    int YGVJlM = -926907009;
    bool CkthmIXqaXVffgoT = false;

    for (int Obnxq = 932757232; Obnxq > 0; Obnxq--) {
        fXruoL = ! CkthmIXqaXVffgoT;
        CkthmIXqaXVffgoT = ! fXruoL;
        qNKwiUmR *= qNKwiUmR;
    }

    return YGVJlM;
}

string GIRjsI::CFZtHnk(string BfPsQBkUkRDVjA, string orUgrUDxxZyJM, double fEljnYHnUUm, bool CQOFuXRHIfM)
{
    int rQmaKq = -1054677560;
    string JISniAz = string("ZPmDIAUNozMCEfPrnNusjCtefKBhbhxsQaUTHthtrHlgznyTxNmAqDRLTYLazOygfsvfZXhcRTVGzsHmfhDlkzQfXXwxOJQacGQSAeSKQwzrX");
    bool KdPkXAPuM = false;
    int ugDANxhKJWM = -2040657089;
    bool LExxjTmeJvtR = true;
    bool GvYHlNcLjpRnqYEO = true;
    bool ZfKkGyZGLUn = true;
    int NzVHJe = 230918949;

    for (int fkHyUPMerdfy = 442538691; fkHyUPMerdfy > 0; fkHyUPMerdfy--) {
        KdPkXAPuM = ! KdPkXAPuM;
        JISniAz += orUgrUDxxZyJM;
    }

    for (int nwItqWBHfkHFgfep = 1996924762; nwItqWBHfkHFgfep > 0; nwItqWBHfkHFgfep--) {
        continue;
    }

    for (int cOeTbmnbReSDhu = 5575865; cOeTbmnbReSDhu > 0; cOeTbmnbReSDhu--) {
        fEljnYHnUUm -= fEljnYHnUUm;
        orUgrUDxxZyJM += JISniAz;
        KdPkXAPuM = KdPkXAPuM;
        CQOFuXRHIfM = KdPkXAPuM;
    }

    for (int JvnPlUMDy = 909969608; JvnPlUMDy > 0; JvnPlUMDy--) {
        NzVHJe = NzVHJe;
    }

    for (int BYEanrvoDO = 1747262305; BYEanrvoDO > 0; BYEanrvoDO--) {
        CQOFuXRHIfM = KdPkXAPuM;
        ugDANxhKJWM += NzVHJe;
        rQmaKq += ugDANxhKJWM;
    }

    return JISniAz;
}

double GIRjsI::XkTJrRW(bool AXWQWkRjmPuq)
{
    int IIDLRTtMCcW = 1608133778;
    double ayucE = -1021123.7419105577;
    bool reKiFMFZAjG = false;
    int NLxIsZOfH = 605453197;
    string tCoZLAulKE = string("JkpHojigHXsJohhgdbTOuxcIIEagyWZSXTgfGz");
    string qzPQSygypYOpOwi = string("AxfMtixfzmuSxgvhbKEbfYTDJSEUmjulycYKabUsmUmxAhMtKveLnerTohdQCwlPBfaXlyCCFMUyKzBfJSoqDxykPFpXtUOigXzYreNWjAzoqNuxRbQIBtjWVGaQaNIXHCNczjVwnyqgsLqGrQzxCxHRxTcRgDZiBEbbVQESXjaKfuHXScsZFYchXwrPxnDisQJdqbIowjeNNevwVmVNwDvUmGMXzdyXzNcRShBX");
    double YkUEqrUcNdGOqexY = 37806.57487748006;
    string YPbhgkjbwPe = string("IKtCRjbuiNXwtNPTTAEhmlYpCCoagrhSTYWdOxNxiNNtgHXEtwDzrkKEzdLvUhFeOmVvuIyNRcaIGjlILcknHUhZOKFOMveXcaPRNGIthgupJFYwniHmBDOadEtQYHZBFQFZoPRuURuxHKXurgLxVJnSmpVVkuavQnLfgVBqblOJwBMOMatcULmsfLVv");
    double owDTCRdVzaFG = -668666.4278400223;
    bool VQRCetsJbbEQRwSx = true;

    for (int EsbYTNzvn = 715074242; EsbYTNzvn > 0; EsbYTNzvn--) {
        YkUEqrUcNdGOqexY /= YkUEqrUcNdGOqexY;
        YPbhgkjbwPe += tCoZLAulKE;
    }

    if (reKiFMFZAjG != true) {
        for (int JJbvij = 1138317181; JJbvij > 0; JJbvij--) {
            YkUEqrUcNdGOqexY -= YkUEqrUcNdGOqexY;
        }
    }

    for (int tbZTgIjrtiiVcw = 1459838607; tbZTgIjrtiiVcw > 0; tbZTgIjrtiiVcw--) {
        VQRCetsJbbEQRwSx = AXWQWkRjmPuq;
    }

    for (int oEZotG = 182186675; oEZotG > 0; oEZotG--) {
        ayucE *= owDTCRdVzaFG;
    }

    return owDTCRdVzaFG;
}

void GIRjsI::zVRWQrztHGm(string PUFrScpKGMh, bool CePYODTJuVC, double ysNCQxmhFau, string VhzwQD, double ReWXCrDvjExPl)
{
    int iZxWrP = -1766813914;
    string KusSwmZr = string("TmlYYjBVKAKePCwfBprwnCdgsBRFVYkmauxOFotoMmrfORRQBzNRaoXfITiaJwdCwWpssYPvufwFUlSkTqsypgqsCtNVCQRhKnBhoAniyNxnfwscdLupmubwVmfluIrNMJmbgpOUOUvvOJZuILSwUHTeEIID");
    int nfKEgAAryarMzDhl = 1074908995;
    int fhJYHhmANMtpq = -1172140793;
    int EFZDR = -1002545829;
}

GIRjsI::GIRjsI()
{
    this->FyZEhYmBdvDRc(-2073094004, 245445132, string("jGvJxBCOksNzGJdkJlKmnOcQHpdPUyMHXQLKjHADkLQmcZhxSqnQukGkTbIiNQcBxDJcCdvcexprXoKaYzXYYypofYOKJ"));
    this->CTUZDTI(string("pOKZWPtQkeAcJXTuVaJKppAJXCnYHexDshZqlLJewIoWfOFJffxGlCfyxFDqyxUaPCPXrdsehgunNWMJVN"), string("LnvQBxHaROvYxnsbBioktadirvyzIKoodUcbXNVWDrRfqJtgiItOvsDgHWmYnbBlTlcxhvmoPbSorQLUatcGWOZYduJGmrHCmgP"), 444949790);
    this->EuVclSAcISsX(-628914.4908354606, string("PXbr"));
    this->bPdHEcXwrtV(string("WGrzIAnSgueiIdVhV"), string("NvxstRICKnvopdtiJgEyjqnouzBgMczSbcvSWeaOwcHBklOetzQqCfNGptOgxJmfyMoDFnDahXsbfBahxTFFWPCQaVsxqKRThVwchwRlLdSmEPcclyJwECNItXaJGpsBauWWVcEGugBPHLZkiOYWlIrzijkBBoRbsaDt"), -1005521.652438697);
    this->VHbpqQvrEpmMstPk(-1312409854);
    this->WyaVoEWYHQHn(-58865632, false, true, false);
    this->qrnthmVbgEmxw(-987806.1204808949, 610964.0419555494, string("NjOTkoAHNXEFBqfrJnfYULnqsqCQRSGmUoVPrAvZTPTxRsOhpcvnigfqEmcZAcdFbqVUmYgGuFlugnXnqxPUglpPqbdwTHvGSihGfCpCDxUXRBKgkIpJEsXarfvBVgshXyfTnGuDCPQiqvKCMFMaUkJrjZRdhFbVBcgVfLorLPHxiFLrMi"), -452952.2108841849);
    this->ngawWXRK(930102301, false);
    this->wvJbzf(1952745478, -710127699, -480953435, string("xlIFwlLvhfeFwBeCtgiZSOwXjUtGpJrxYqUoIfMXVyPOEUOxOOVrrCpFnaZnCCwBGDLMbOPuHHKjiqVsAemuNCKPtHeOWOUiRFvtSfimckWgUXThQnJFuilgixHUteTJRWHLJGHxfwmDDmuIDtYfjGgvHpfOXnWcjriwgNAqyNbajfKZEAuKihgEeKnZVysDdjhsBatacOGqFrhcsbasnaIXjWwhdThkRgnrLsjlWzmgUlwAMErnoHay"));
    this->EoATtXF(string("qBLIhPikgTwUGqOHZoDcDVyGtOckogGqGZQmAxrtMPNLDbKTAnqRIUAHLVflzKHxrGoYrEWWkrpnyuZvjBkrqdUOluCcJHHOCWZWPbYwpPAngzwOuBZoALKdJEFSQlywjqEsUXMevImnPNqtCidsJg"), false, string("NycTiNPXfttRadMXAzvhycLAtXNNBywKHzUPDnihSCDURLlzdmEqrVjoceylMABYhGjYpVXHKrvazOzZPoKAgfUBlrKEDGIdodAZBCPXsCrhERrXhVQoEGozGdNjxZOIbwknONMBUGrYrDjbcbRclRhcjltIJOCxXwZwRqnEPkASxgXhkCZfflTRzqkqELpIKvHkfTHLPtmMixLsJSxUXzuGIuhiwvWOxMvUAXxFItaIRZVbVAexTBrl"), -705168.3481427762, -147907.3828136361);
    this->OrtVyFV(-619092.4635807307, -369053348, string("ycbkoDKTwDCmpNliXPQMkQYgTuksMTEOyOMIjPVpbzCgevgJyyarIvmeGVCkamucGfhRFrjYvbazsUDPkYzekEUCjBIaoiMrehJJelIQBidGZlGAlxOANLiSTPuHLQlOLekCiTlmYhTUirmYIxHllOfXbUgpwPbAUuTpAXZOeemHsuHvgecUFHYFOigmelXNksjlkkqsvoybtMliChjykLYgtNjqyexI"));
    this->dJNWuwRJbRWZXft(string("UutlzyYnwRNrVcPmqAprdqwasBatdXJGWRItzPMKcrcoZOuirpNhzgeQYqyXJPGcRjcgNtJzotLLUzsErDHbQFKeQyCsGGvDTMUmnbXRMeEEQxjKleUWonMrbjxqkdectcmMrpdgnikBhRazLXzZLZmCSkhElRpPMJRhfZYwpEUsYXntooPLPOFDmsOHvNLcixCTBZjgimzUwurzehokLUKwNxxKotDrzNOMtowYUdfmGSokmmxDs"), string("tNRaHoLKVIvWKtwhLRCfRqzQUvWtcpMPayiTPPsPxCcJMvagKiiPWVvMBzKlFJLVDBAafIjxbEDeoWGoNJdWgLUWkVJHZcwgAAIroVpsdaFHPRijzbJhraYZfZhtcXoUnWhiwDuQpuPDnhqsSRDBujyPtEWTxyRPKeitpmlqVvlcyBAmyVaPtzXYGbKUICScAyVZJWYptyvTWHkEYMRXxhXnziBmXCTRuzlIqFRlTEVdkwarv"), 262383388, string("RIqttUWOVzYaLSpBefFaO"));
    this->QVcPqF(string("PGiXzyEINvfZKeYhlinigdlcbKHRzGsSewXKTlINpUcPRCCRemXmIHiURxgnhKXgICEJSVHTYHpSviOXlPHlzvKUHSrHaACAZkzwQpPVdiSlIVrDDJCyrBjTJdMuwELKZvwNkjIsCXcxtzKYOihfzGxlMNsnseHiYSHgOoADOHxRDNrMUNApotPjT"), string("XYKyBVyaldIzYhihsLzctURzaMMfTiQYdkVoeCyTeZumKdREbIBFEUCNHyUedQbwziENmqYNVGAyIpSfBxdrgyVQieUbKQVkXJHPVRSdczfjPypxXpvlpXbVkddqJPCnIwPpubRkbHikACzsPMOWazkJDZkDfZLERNGrMcBE"));
    this->JpJDud(51145.74920100168, string("TeAwsNwwYFounMZvYxxuZWyLMIZiVWhrtdlazAttniNRMBJrKeczzSHJGgoAtABsvYvumuCWNMYCxSzFDrVcjqGstUFmlCIzTinkLmrEaK"));
    this->CFZtHnk(string("JKwPlDoPXMSqbWKwDZQHPmBKNohqnkHkqJTQzRHssLZkKuQofGCLkeHpiMedgxwokzMSRksOdtpojf"), string("UvMfbOOYfAJSmfSaHvsWbDVTcHcNuYcDIgPWJzvfhvnPxJVGPpTlcMaqNrOxFcrYVeBRDqqFRhXuveBDVcjEGNlswWrdthJIrRIhgqJZmGmrpUmWFYugaoxogBBQWFuyOXEYTEZAsdqOdbCtpecdJdRyjNUmWddvuQiukHxUyAyDuhCxMuquqlQa"), 243238.31657470658, false);
    this->XkTJrRW(false);
    this->zVRWQrztHGm(string("pcWWJMcPFslNIezUfbVVOW"), false, 145713.45392900793, string("cKREuSFhvEXcnGjESrZGMystuOnmAYypNXiLMOQKxiBOTorvBOlOgcnDfiPMCbQyJHXmOwwpYvEvWHsMihBONNrlAcGuPBJnzAPpksrGmhcXokVILMsZxANXlTWOHoIaCanMQVgmTldDpMSHrRhDnmTDsCRpL"), -302322.90575631923);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zMnXTnvvfX
{
public:
    double szmQzrWE;

    zMnXTnvvfX();
    double pYrOZCCAen(string gUZBNzpuk, string JLkoJnQEiyAFuN, double eVOYJPViiB, string HJDErCvBh, int SBiUDZTAfKRWD);
protected:
    bool BMaFtWknZYGCxxeb;
    int ZgsMf;

    bool UJxteYyM();
    int eoLKbBG(double blIIEkXzMzSgTtPv, int FcdOT, int lNEErvIPb);
    string oLsUhphfPnwKIW();
    void LCeLHrJLyywLxqX();
    string FbJrhIV(double HWPrSUqamXUZO, int QCRaHJEuPrz);
    int MxgIzptlj(int aGRwKCBWiXuhs, bool IDrCEaxBreH);
    void mRVrlyemDpOSFbAa();
private:
    bool NcEYjRbzgq;
    int gWBGkwDzHtNkvuT;
    string WJQIndW;
    int ewusT;

    double iUmUZGDdRbbeWYgT(double jfBFErSCubc, string PdWqYKjeOkF);
};

double zMnXTnvvfX::pYrOZCCAen(string gUZBNzpuk, string JLkoJnQEiyAFuN, double eVOYJPViiB, string HJDErCvBh, int SBiUDZTAfKRWD)
{
    int UKUVxfVnZ = -1370727944;
    bool xZTXFzpJendHoge = true;
    int eLVuTZwLd = -953707337;
    string ozVNpLNLnbLhTrt = string("ypEJMeZqmFYOznLgKpFcRkTbDecInVGQLEUaeTUhqtajDmYBKR");
    int ZoxKhMmWE = 295898400;
    double YMcxDwOjvNYlQ = 179439.00110481464;
    bool CMEKpWSIOQxLXQ = false;
    int SphhcUcRfAIXOQq = -863055045;
    string LZSpJ = string("bvGLWXjiHHqLBVDkK");
    double dFvrDFXzhSuwkO = 464288.1770123668;

    if (ozVNpLNLnbLhTrt >= string("ypEJMeZqmFYOznLgKpFcRkTbDecInVGQLEUaeTUhqtajDmYBKR")) {
        for (int ykJTnV = 341439133; ykJTnV > 0; ykJTnV--) {
            xZTXFzpJendHoge = xZTXFzpJendHoge;
            gUZBNzpuk = JLkoJnQEiyAFuN;
            SBiUDZTAfKRWD += eLVuTZwLd;
            LZSpJ += ozVNpLNLnbLhTrt;
        }
    }

    for (int ZnvKSUlapysvGNU = 204195909; ZnvKSUlapysvGNU > 0; ZnvKSUlapysvGNU--) {
        CMEKpWSIOQxLXQ = xZTXFzpJendHoge;
        SBiUDZTAfKRWD += ZoxKhMmWE;
        xZTXFzpJendHoge = ! CMEKpWSIOQxLXQ;
    }

    for (int uEIMQPBNQBsWrys = 492123860; uEIMQPBNQBsWrys > 0; uEIMQPBNQBsWrys--) {
        continue;
    }

    for (int aFaqVzNwR = 794670081; aFaqVzNwR > 0; aFaqVzNwR--) {
        JLkoJnQEiyAFuN = gUZBNzpuk;
        JLkoJnQEiyAFuN = LZSpJ;
    }

    for (int tsKxFuPMxYcmRJeU = 1697174117; tsKxFuPMxYcmRJeU > 0; tsKxFuPMxYcmRJeU--) {
        JLkoJnQEiyAFuN += HJDErCvBh;
        ZoxKhMmWE -= eLVuTZwLd;
        eLVuTZwLd /= eLVuTZwLd;
    }

    return dFvrDFXzhSuwkO;
}

bool zMnXTnvvfX::UJxteYyM()
{
    bool lSIOSBvXnp = false;
    double cJPkRkPGIuF = -423209.90220662457;
    int muXukVvaf = -1746472079;
    double WOUiLQoHrxm = 979699.9169989575;
    double uDwZeqpjRoL = -967635.1998096552;
    bool rXXelrMhHFElZ = true;
    int MqxqSnDCuuXaPY = -1021554355;
    string hZijOHWPWM = string("BBsHWrZjzwIcWsISbTTVHGbadMxnfgTBNWaCNEQrFdEUEFFqrCgZzjYxREtrLEmWKifmErjlUWVFNlBoPkWiZlSaJiTCOjYqKTokmTBCFkxAfNnROoETSHcJhwxHZoHQqDJAMgjzrvPESDUZLNVOiNqIyodnIILHxxbpIlrADalpSHIOWZjLqQGiBiptdzy");
    string XjXMIGRHsrDBEUz = string("XKKjfOvXlsdGmbYbHyXGFNurXxTSsXbENhAJeIMFrvVADaKGikuhlJsTLEUdZvEbkADMEusEzkuRkweOHVSAAValmgdjmPNULHIQxwyYpcVsBelvXoHRKrGBuBiOMQKtaivfgqenruJlDzwZtcvtOgNOgVoa");
    bool qdkhjFq = false;

    for (int WCLKnkNm = 145139259; WCLKnkNm > 0; WCLKnkNm--) {
        rXXelrMhHFElZ = ! rXXelrMhHFElZ;
    }

    return qdkhjFq;
}

int zMnXTnvvfX::eoLKbBG(double blIIEkXzMzSgTtPv, int FcdOT, int lNEErvIPb)
{
    int hcGcXugwAP = -418690870;
    bool lakauZ = true;
    int UQzigLGPXtCDx = -2079417692;

    for (int tPARHAQRkAMdxmb = 285804275; tPARHAQRkAMdxmb > 0; tPARHAQRkAMdxmb--) {
        blIIEkXzMzSgTtPv *= blIIEkXzMzSgTtPv;
        UQzigLGPXtCDx -= lNEErvIPb;
        blIIEkXzMzSgTtPv = blIIEkXzMzSgTtPv;
    }

    if (UQzigLGPXtCDx > -418690870) {
        for (int JmqBgRKPS = 290129910; JmqBgRKPS > 0; JmqBgRKPS--) {
            FcdOT /= UQzigLGPXtCDx;
        }
    }

    if (lNEErvIPb == -418690870) {
        for (int ykNxepM = 58949107; ykNxepM > 0; ykNxepM--) {
            FcdOT -= UQzigLGPXtCDx;
            UQzigLGPXtCDx *= hcGcXugwAP;
        }
    }

    return UQzigLGPXtCDx;
}

string zMnXTnvvfX::oLsUhphfPnwKIW()
{
    int MtRsULdiFvjE = 1508176688;

    if (MtRsULdiFvjE < 1508176688) {
        for (int lajPebTQe = 1210820645; lajPebTQe > 0; lajPebTQe--) {
            MtRsULdiFvjE += MtRsULdiFvjE;
            MtRsULdiFvjE = MtRsULdiFvjE;
            MtRsULdiFvjE = MtRsULdiFvjE;
            MtRsULdiFvjE = MtRsULdiFvjE;
            MtRsULdiFvjE -= MtRsULdiFvjE;
            MtRsULdiFvjE -= MtRsULdiFvjE;
            MtRsULdiFvjE -= MtRsULdiFvjE;
            MtRsULdiFvjE /= MtRsULdiFvjE;
            MtRsULdiFvjE /= MtRsULdiFvjE;
        }
    }

    if (MtRsULdiFvjE > 1508176688) {
        for (int bFqajSBIvTl = 1629211693; bFqajSBIvTl > 0; bFqajSBIvTl--) {
            MtRsULdiFvjE -= MtRsULdiFvjE;
            MtRsULdiFvjE -= MtRsULdiFvjE;
            MtRsULdiFvjE *= MtRsULdiFvjE;
            MtRsULdiFvjE = MtRsULdiFvjE;
        }
    }

    if (MtRsULdiFvjE < 1508176688) {
        for (int DFCoKl = 278034597; DFCoKl > 0; DFCoKl--) {
            MtRsULdiFvjE -= MtRsULdiFvjE;
            MtRsULdiFvjE = MtRsULdiFvjE;
            MtRsULdiFvjE = MtRsULdiFvjE;
            MtRsULdiFvjE /= MtRsULdiFvjE;
        }
    }

    if (MtRsULdiFvjE > 1508176688) {
        for (int gFGeCUYiDWrjdNJ = 868217857; gFGeCUYiDWrjdNJ > 0; gFGeCUYiDWrjdNJ--) {
            MtRsULdiFvjE *= MtRsULdiFvjE;
            MtRsULdiFvjE -= MtRsULdiFvjE;
            MtRsULdiFvjE /= MtRsULdiFvjE;
            MtRsULdiFvjE += MtRsULdiFvjE;
            MtRsULdiFvjE /= MtRsULdiFvjE;
            MtRsULdiFvjE *= MtRsULdiFvjE;
            MtRsULdiFvjE *= MtRsULdiFvjE;
        }
    }

    return string("GUXaeaPgaBYrZgcQHVVwANtladGFUNpPvegfMcpEJOoztGJrsLVYJDeRPwlhjrBsWjbOpShzTeleYwGuKCoiHwoTBCtYLnIoyzfNlhQnXhrAqbRddMPdCeOzUwgZaOVMMsNPXsGrtmhQJOTJHwFlKfyZAfawghbEzHFrx");
}

void zMnXTnvvfX::LCeLHrJLyywLxqX()
{
    int qTxOGjXEZvkgmEU = 270227307;
    double feziIUehUGNwsCy = -643886.579884121;
    string hvVOnZPNkDim = string("WGpMsYYEvykbqkTGSOFbtcEIEEQAcgBwRsQSyKiLoTfkXcoBSHBejnpOfLfDUOniXIraRVRvYaYqRUOqtRRqDKQdAzrIYZalyWgnybKGnmhxijgXobwYnzcrbAOkfVUCCjMwdYEgERVOKTBbCvulcRBbvAPRTXMgirJkVTzztMRvpVFpvvMNSawKBl");
    double ALgQUIdUEfGsJEV = -526418.857034621;
}

string zMnXTnvvfX::FbJrhIV(double HWPrSUqamXUZO, int QCRaHJEuPrz)
{
    string fTHmXpxo = string("nmrTIhHddjuhRXfKlrdoyeoSTHbUuVopeSvwoxhfekXQtfDuYxVijgTgqAiCxSrfYQJKESUqDrTQmnoDBgQKGwidnqhmBlwqDtPOqvEKamsoyORgMahhQfwuDuQNxAuRVPAeKhWUBXgpvlfHrHrKASeJDvYkQqFUBOmzSyWLeIENQXBThxyhwskRdzvgrQIBUukFlbyIaTZFGWCJHYaxUomCRCZkofpMBCogn");

    for (int UMGsUXvNul = 1642943975; UMGsUXvNul > 0; UMGsUXvNul--) {
        HWPrSUqamXUZO /= HWPrSUqamXUZO;
    }

    if (HWPrSUqamXUZO == -1015134.6344697222) {
        for (int BZKwCqpbJcM = 1512283931; BZKwCqpbJcM > 0; BZKwCqpbJcM--) {
            fTHmXpxo = fTHmXpxo;
            fTHmXpxo += fTHmXpxo;
        }
    }

    return fTHmXpxo;
}

int zMnXTnvvfX::MxgIzptlj(int aGRwKCBWiXuhs, bool IDrCEaxBreH)
{
    bool gtOQFjhcEAQtqA = true;
    string zlyggIjv = string("ERqqHsDlHyraynVkqZWyvdEeIhpmKEwAfkcLbzMgtGRukrgenDSZxlFKpWTXolLFpellDdRtowgLgCcVxB");
    bool guMjCbKfpiutVC = false;
    string ESmqCfYBI = string("uyfrTfbVtBHtCBQXdjaekYkPGnLkEfEjLdnyGjyTmolwKRfCxiWXQbagvwZLqlzAmxpBKTBNzxctmDqIEl");
    double jMKyhoeqZkAQIZ = -33571.39379568036;

    for (int MiggpmmGISp = 1253537506; MiggpmmGISp > 0; MiggpmmGISp--) {
        continue;
    }

    for (int DRvzoDq = 1784121755; DRvzoDq > 0; DRvzoDq--) {
        IDrCEaxBreH = ! gtOQFjhcEAQtqA;
        gtOQFjhcEAQtqA = guMjCbKfpiutVC;
        gtOQFjhcEAQtqA = IDrCEaxBreH;
    }

    if (gtOQFjhcEAQtqA == false) {
        for (int FRbhnRb = 807359498; FRbhnRb > 0; FRbhnRb--) {
            guMjCbKfpiutVC = ! gtOQFjhcEAQtqA;
        }
    }

    if (gtOQFjhcEAQtqA != true) {
        for (int labyXmjdBSdjtV = 190075058; labyXmjdBSdjtV > 0; labyXmjdBSdjtV--) {
            continue;
        }
    }

    return aGRwKCBWiXuhs;
}

void zMnXTnvvfX::mRVrlyemDpOSFbAa()
{
    string qxuoN = string("eodxBiqwkqnmgg");
    bool FhEKl = false;
    bool WHRQUwTosmSs = true;
    double SScoeNGDTl = 770685.8733640795;
    bool xHgwyEZOMxGkTM = true;
    int GKpkTfFRIeJCwKSZ = 1242094849;
    bool pQcEE = false;
    string ZfaZYCgQPjVR = string("jhqWkYigvBRdKaFjnVBXEAAzXNNKybxdCElRNKcWKWoxSXKuubXtukKsAaHmYPYtnEAKEZxVgkKqAgEGrJoBsNGAtPFKLfujtrKkSfwtGzDjjHYmpbjufNrYYbwFOmmXuuUxNICMUrypOKMJQTfRJXsxJUaOwJRmyHQTOQrhuEsMPCgSORIbHUUArkbvSleKUJEExU");
    int tOGJOLdnO = 1552668867;
    bool JkhyIs = true;

    if (GKpkTfFRIeJCwKSZ < 1552668867) {
        for (int zltSPMEfWYfE = 1801318770; zltSPMEfWYfE > 0; zltSPMEfWYfE--) {
            qxuoN = qxuoN;
            JkhyIs = ! xHgwyEZOMxGkTM;
        }
    }

    for (int zQlJnQdwaoIovj = 1298715897; zQlJnQdwaoIovj > 0; zQlJnQdwaoIovj--) {
        pQcEE = FhEKl;
        xHgwyEZOMxGkTM = pQcEE;
    }

    for (int GBYmijehxu = 803376565; GBYmijehxu > 0; GBYmijehxu--) {
        continue;
    }

    if (pQcEE == true) {
        for (int srDVFEemICJmSVz = 225083450; srDVFEemICJmSVz > 0; srDVFEemICJmSVz--) {
            tOGJOLdnO += GKpkTfFRIeJCwKSZ;
            ZfaZYCgQPjVR += ZfaZYCgQPjVR;
        }
    }

    for (int noURPZj = 419336781; noURPZj > 0; noURPZj--) {
        FhEKl = ! xHgwyEZOMxGkTM;
        tOGJOLdnO += GKpkTfFRIeJCwKSZ;
        ZfaZYCgQPjVR = qxuoN;
    }
}

double zMnXTnvvfX::iUmUZGDdRbbeWYgT(double jfBFErSCubc, string PdWqYKjeOkF)
{
    string DMWicNqoIu = string("M");
    bool KLOJN = false;
    int uFKJpb = -1108133848;
    double GxovhsFdCaMgSn = -448164.4860815639;
    bool RwSdpY = true;
    double jpfkZibUv = 392639.00406303216;

    for (int FzWHUqF = 1970832286; FzWHUqF > 0; FzWHUqF--) {
        DMWicNqoIu += PdWqYKjeOkF;
    }

    for (int MirnJfEqTiXo = 790270642; MirnJfEqTiXo > 0; MirnJfEqTiXo--) {
        jfBFErSCubc *= jpfkZibUv;
        jfBFErSCubc /= GxovhsFdCaMgSn;
        DMWicNqoIu = PdWqYKjeOkF;
        jpfkZibUv -= jpfkZibUv;
    }

    for (int aGGeMioRnHHUiwy = 267493573; aGGeMioRnHHUiwy > 0; aGGeMioRnHHUiwy--) {
        RwSdpY = RwSdpY;
        GxovhsFdCaMgSn /= GxovhsFdCaMgSn;
        RwSdpY = KLOJN;
        PdWqYKjeOkF = PdWqYKjeOkF;
    }

    for (int avwGXNabUTjcg = 976645072; avwGXNabUTjcg > 0; avwGXNabUTjcg--) {
        DMWicNqoIu = DMWicNqoIu;
        PdWqYKjeOkF = DMWicNqoIu;
    }

    return jpfkZibUv;
}

zMnXTnvvfX::zMnXTnvvfX()
{
    this->pYrOZCCAen(string("KbHWHuKIlalskUlCQakQAPfVPqRqTsuLTjNXShknaslFFBCbMDZjFQpnEtRNsWpcJcgIfQYoIAvfWSAoBVTPiwbiuFdBsCDBhyybIKxyNekAeiZoykZvNOhQOSRNddhJnbBnGCKdDTJQscXMjxLKAyFwvtASXlOsHSbDWwNgtmcYvbQzMWgGyBMSQWAXvsiXy"), string("hDhkEhQXNbuqCwVgfWoNnSGAbyVyrXbAkHHrOPbRgVlBIWgmNMUDBCoymUlCDmkOhAeXNbiGrNuItSxpjyffrCkEbvcBNjPxbrdxEMtBHpPrGHTWnmRkUKTdzK"), 471622.38833328005, string("wPWhWhWTjjijzctHrNfpEGxtNuMqoYyWHCyqkcWGAMkOTmNuJspCERWdnuyjrxoWIirJPEmMwqFlLLQyuWUHbMTZebbdhDXWgzLNhnHVKOqkdoODOxvievWxQXCkPFBjAxhEbdCubfJkBDEMPOBdjVZFSaEUeEyPZGgJCVBtHAVjtJTGRGJnfLefjFpVswMNJHtZDHZgVIuUoqmJkoQohnBuCbgaRsexvwkefIuOl"), 1495016050);
    this->UJxteYyM();
    this->eoLKbBG(-431096.43503992655, -1928780050, -448030417);
    this->oLsUhphfPnwKIW();
    this->LCeLHrJLyywLxqX();
    this->FbJrhIV(-1015134.6344697222, -606931790);
    this->MxgIzptlj(55297991, true);
    this->mRVrlyemDpOSFbAa();
    this->iUmUZGDdRbbeWYgT(572806.36766643, string("MxWUmKwcLXdFMwEokLUgHSnPTWzcfwbxGvK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RhqJSTZDFkER
{
public:
    double gYSvelnIl;
    double fNAWJjJEO;
    string INLHTw;
    int zEmKeMoYGdgBorJ;

    RhqJSTZDFkER();
    double EKFuLshWF(double itzxhF, int XbWlySdOZLwaV, bool jojmnXFdhuw);
    double RiAFIzmZNsIHHS(double vunNlwQDqQeBrp);
    double kxGCrnOaDR();
protected:
    int KaGINGN;
    int vaNLOaEXLnwR;
    double AioMKXyLFPyFpZuL;
    int vrWlnW;
    int OvRgGuvHEibxN;

    string aXuIqSOuiosGQ(bool RIdFknjzvB, double TBVeAClUWiTPkJ, double ipAnazMCrDknKDe);
    int QptdPBdoRxk(string aaTVcgfW, string BuPJtCd, double vKuvLVl);
    bool xDKhbvgZluGledC(int KmoYHeO, double XCvSOiQMeYVqVS, bool bhztQYZxIF, double BGRRAWtYmkglsjZ, string yxOSENymbshHx);
    int VMOLyWrrDDbhIzS(double BNmlOx, int mHNnvdRQ);
    string ndDEY(int BjYea, bool aaNzMTz, string bCxYp, bool ucxBM);
    void mgSpFrsmHat(double hAciXwgGOc, double kGpjagSaoZLO, bool LmkjfoDVylTqrb, double cZyNMNmUxiO, int kAdzSJODmXJZcXKW);
private:
    bool psLbvN;
    bool doIHZ;
    string fhYLAnQHDZGD;
    string LkwMkczJfNc;
    bool scXSuseCnIs;

};

double RhqJSTZDFkER::EKFuLshWF(double itzxhF, int XbWlySdOZLwaV, bool jojmnXFdhuw)
{
    double WkBRBqzKNAI = -138875.55364237024;
    int UieSthjmVfWGXgV = -200983779;
    double apvyBAyVKhFlEp = -396370.6755483645;

    for (int mOJMd = 1575802432; mOJMd > 0; mOJMd--) {
        XbWlySdOZLwaV += XbWlySdOZLwaV;
        WkBRBqzKNAI = itzxhF;
        itzxhF /= apvyBAyVKhFlEp;
        itzxhF = itzxhF;
        itzxhF += apvyBAyVKhFlEp;
    }

    if (apvyBAyVKhFlEp == -396370.6755483645) {
        for (int eShrVdgMfNDD = 1443947002; eShrVdgMfNDD > 0; eShrVdgMfNDD--) {
            jojmnXFdhuw = jojmnXFdhuw;
            jojmnXFdhuw = ! jojmnXFdhuw;
            jojmnXFdhuw = ! jojmnXFdhuw;
        }
    }

    for (int zuWstRgfJGqAEc = 456910540; zuWstRgfJGqAEc > 0; zuWstRgfJGqAEc--) {
        apvyBAyVKhFlEp = WkBRBqzKNAI;
    }

    if (XbWlySdOZLwaV != -798905186) {
        for (int mUjBqhmfanyfKF = 291827960; mUjBqhmfanyfKF > 0; mUjBqhmfanyfKF--) {
            continue;
        }
    }

    if (apvyBAyVKhFlEp >= -688023.6166617263) {
        for (int QqXhT = 913889253; QqXhT > 0; QqXhT--) {
            XbWlySdOZLwaV /= XbWlySdOZLwaV;
            WkBRBqzKNAI *= apvyBAyVKhFlEp;
            UieSthjmVfWGXgV = UieSthjmVfWGXgV;
        }
    }

    if (XbWlySdOZLwaV != -200983779) {
        for (int zpuyXiavM = 183923081; zpuyXiavM > 0; zpuyXiavM--) {
            continue;
        }
    }

    return apvyBAyVKhFlEp;
}

double RhqJSTZDFkER::RiAFIzmZNsIHHS(double vunNlwQDqQeBrp)
{
    int TOjxJhSPww = 999693557;
    int pDyHjGDvKhEaD = -1132108276;

    for (int bKchVGa = 1853985887; bKchVGa > 0; bKchVGa--) {
        pDyHjGDvKhEaD += pDyHjGDvKhEaD;
        TOjxJhSPww -= pDyHjGDvKhEaD;
        pDyHjGDvKhEaD *= TOjxJhSPww;
        TOjxJhSPww *= pDyHjGDvKhEaD;
    }

    for (int ADlCnmSJmGWNBJ = 52404584; ADlCnmSJmGWNBJ > 0; ADlCnmSJmGWNBJ--) {
        TOjxJhSPww += TOjxJhSPww;
        pDyHjGDvKhEaD /= TOjxJhSPww;
        vunNlwQDqQeBrp += vunNlwQDqQeBrp;
        pDyHjGDvKhEaD /= TOjxJhSPww;
        pDyHjGDvKhEaD /= TOjxJhSPww;
        pDyHjGDvKhEaD -= TOjxJhSPww;
        pDyHjGDvKhEaD += TOjxJhSPww;
    }

    if (pDyHjGDvKhEaD != 999693557) {
        for (int URIuLiUvFGVawnYS = 520597569; URIuLiUvFGVawnYS > 0; URIuLiUvFGVawnYS--) {
            vunNlwQDqQeBrp /= vunNlwQDqQeBrp;
            pDyHjGDvKhEaD = TOjxJhSPww;
        }
    }

    if (pDyHjGDvKhEaD < 999693557) {
        for (int oNlcaDrbSEW = 296847124; oNlcaDrbSEW > 0; oNlcaDrbSEW--) {
            pDyHjGDvKhEaD += pDyHjGDvKhEaD;
            pDyHjGDvKhEaD = TOjxJhSPww;
            TOjxJhSPww -= TOjxJhSPww;
            vunNlwQDqQeBrp /= vunNlwQDqQeBrp;
        }
    }

    if (pDyHjGDvKhEaD < 999693557) {
        for (int jmsvF = 1629772545; jmsvF > 0; jmsvF--) {
            TOjxJhSPww -= TOjxJhSPww;
            vunNlwQDqQeBrp = vunNlwQDqQeBrp;
            pDyHjGDvKhEaD *= pDyHjGDvKhEaD;
            pDyHjGDvKhEaD -= pDyHjGDvKhEaD;
        }
    }

    return vunNlwQDqQeBrp;
}

double RhqJSTZDFkER::kxGCrnOaDR()
{
    double HgXlimRcatT = 539986.0971756746;
    bool sLBWaJ = false;
    string mDqyM = string("fWiXnmCglfAxTbJphfZOaIaFvQozmomkkAASaRlMqcCORHARAGZYxGdSWAAnPIKzkRHTXWrTnOOYGNXKhtTsyVMIfLLgXkVKQqKTEPKQXCZIUeKGQXHaaphbtxTpKVqcOdxvqIemWPvBEokALsskTxEKPKIwvpQOvhmHoBKFoWtBaRDGJqNlYYiTDJFBXTBfCBmwGZLmBrOGuXQNHnHWSTtHBqRiOJzViK");
    string EfDEpoSP = string("dRjEsKBTkdlbkjqtOntOaGgMioHuFkDAysLolKLcHoBPODjBYmkFvstiUhsGydfGQsgLgBZZwBMOflmSiAneeXdfXXWwYFMufXBxWqfQKqPlaOuIdufEteFSFHEoevrLdOzJADkJMaeQrHKvXJlgfMblGWFbtrUMDkjUTkOikkhMaxvUtKWDElvEGjLUWuAtyudTHPMMIKdSlXqIzCwXbcUhmZtGEtuKfGHn");
    double ktZugAwFQtv = -42360.3716662003;
    bool vGujjdsbg = true;
    string ePlfkDjbQ = string("ezRxyyrNeSNlDBfdayxWqAWVHLtsnnGvspqjtyyQrBRlosOtxpaturtbKJRpouJhRRhVaWtBVrDEZJRvUQorVWyXpasUMJeNnWjEMj");
    double SKOyqTN = 788106.6354926708;
    int imZxUrzTTwdQf = -2018418868;
    int BBYKHslYO = 1856750444;

    for (int UNLczgreUGselats = 975844906; UNLczgreUGselats > 0; UNLczgreUGselats--) {
        mDqyM = EfDEpoSP;
        vGujjdsbg = sLBWaJ;
        HgXlimRcatT *= ktZugAwFQtv;
    }

    return SKOyqTN;
}

string RhqJSTZDFkER::aXuIqSOuiosGQ(bool RIdFknjzvB, double TBVeAClUWiTPkJ, double ipAnazMCrDknKDe)
{
    bool EzsihSeCPe = true;
    double ZImVaCAAA = -1039823.5043273852;
    int JyUqfIwibYTQ = 257874612;
    int gHNPRQvR = 1314566071;
    double OFTIfd = -953871.9836386405;
    string EttWcWkt = string("rwvDNlRsCpJjKsVtjDGifspJNUIIhTIovpLBGTLyOrpeDXNbWflceXZDxFwoOsrHYhYrRbyITyRIzaqyEBaArUuFNkFCvXkfzqaazzekQqoJBXOpuxGytPctLHpeOXzXcXGAvldCaBLAKgFevFdNkdNVpnjFUNPstHXetqIESlaUVQznLouhHtDWFfDuWLkXLiyziMbvlKOqQGBQXEvYDBJTJLwwTlbmkYnbxIlmVoVwjH");
    double CSlkK = 213970.9071172361;

    for (int EmXxxcVGQlfdrf = 1842765097; EmXxxcVGQlfdrf > 0; EmXxxcVGQlfdrf--) {
        CSlkK += ZImVaCAAA;
        RIdFknjzvB = RIdFknjzvB;
        ZImVaCAAA += ipAnazMCrDknKDe;
        JyUqfIwibYTQ -= gHNPRQvR;
    }

    if (JyUqfIwibYTQ <= 257874612) {
        for (int SMRPJ = 1622651322; SMRPJ > 0; SMRPJ--) {
            ipAnazMCrDknKDe /= CSlkK;
            TBVeAClUWiTPkJ *= OFTIfd;
            ipAnazMCrDknKDe -= ZImVaCAAA;
            OFTIfd += ipAnazMCrDknKDe;
        }
    }

    return EttWcWkt;
}

int RhqJSTZDFkER::QptdPBdoRxk(string aaTVcgfW, string BuPJtCd, double vKuvLVl)
{
    string RlsTQHSXgYztMDN = string("CeaDFFlnlupuxiIiKHoBACCVSyrjHqkJhUozLdfiGMeYsClMLqHXcgFtUrdmDyBPlhLPMWwenvAMPIaLXGaNjfNfycWRqdqRbyxlQXvGoKz");
    double ezXCFVlCoFFyrS = -310170.50689807034;
    int hPAmtvAV = -182161394;
    double JiYvrc = 805803.0933166288;
    bool zDKbCTJnPg = false;
    string AMHprCcNugFAjH = string("fZgQHzeDMbyzWEqJ");

    for (int bPrJOSmpLeKCec = 1763145652; bPrJOSmpLeKCec > 0; bPrJOSmpLeKCec--) {
        JiYvrc += JiYvrc;
        AMHprCcNugFAjH = AMHprCcNugFAjH;
        AMHprCcNugFAjH = AMHprCcNugFAjH;
        aaTVcgfW += AMHprCcNugFAjH;
    }

    return hPAmtvAV;
}

bool RhqJSTZDFkER::xDKhbvgZluGledC(int KmoYHeO, double XCvSOiQMeYVqVS, bool bhztQYZxIF, double BGRRAWtYmkglsjZ, string yxOSENymbshHx)
{
    double wKpXTftY = 616242.9996951442;
    string CuzqVAGOj = string("esigsrRnjdaLZNaFIEkDQMgzQcVUQWJOTIlheMNSlVsKElhJqjSWSuPSWfOzNdxoLXOfnErGLYbdWqamHznUUdRuzwkinUpUxrSaYxOkZOcgpsLXTlyNwRGfNr");

    if (bhztQYZxIF == false) {
        for (int krLXHSsEHzjauK = 461804379; krLXHSsEHzjauK > 0; krLXHSsEHzjauK--) {
            wKpXTftY += wKpXTftY;
            CuzqVAGOj = yxOSENymbshHx;
        }
    }

    for (int XoAVWxXWAxy = 1546875036; XoAVWxXWAxy > 0; XoAVWxXWAxy--) {
        wKpXTftY = XCvSOiQMeYVqVS;
    }

    for (int fXPZpbj = 1534625326; fXPZpbj > 0; fXPZpbj--) {
        wKpXTftY += XCvSOiQMeYVqVS;
    }

    for (int MLgvAjXkHWkcAT = 8683953; MLgvAjXkHWkcAT > 0; MLgvAjXkHWkcAT--) {
        CuzqVAGOj += CuzqVAGOj;
        XCvSOiQMeYVqVS /= wKpXTftY;
        XCvSOiQMeYVqVS -= wKpXTftY;
        BGRRAWtYmkglsjZ = wKpXTftY;
    }

    if (wKpXTftY >= 368329.6195713667) {
        for (int VRkhryoMDBqgfPK = 1330338316; VRkhryoMDBqgfPK > 0; VRkhryoMDBqgfPK--) {
            CuzqVAGOj += CuzqVAGOj;
            wKpXTftY -= XCvSOiQMeYVqVS;
            XCvSOiQMeYVqVS += XCvSOiQMeYVqVS;
        }
    }

    for (int yYfnY = 410253722; yYfnY > 0; yYfnY--) {
        XCvSOiQMeYVqVS += XCvSOiQMeYVqVS;
        CuzqVAGOj = CuzqVAGOj;
        wKpXTftY -= XCvSOiQMeYVqVS;
    }

    return bhztQYZxIF;
}

int RhqJSTZDFkER::VMOLyWrrDDbhIzS(double BNmlOx, int mHNnvdRQ)
{
    string peJahTIDEhY = string("mAFnhtEqUgurESuOmPgFzBfbEUvKDvgAuLNcxdptRzePsKooDdgiZgsPeOjIxwGpNciCnkVwjQbgoeUDlpNuqwiHmNoXDThXDUuiJwHYuwCOUaArElYlxsknKQieoUGagYcYuCpiqrcsKPAtVKczjqZEsJXaSejNvlAUCExzSjPcpBgbxrOLLSoegTDoKgupjaGKQkySRwjXOaSBOVvsIbSxbI");
    double fMbGjVYcKVoNi = -495429.37483459973;
    int pAmNiNxbIUCSg = 1494136906;
    string veYiKNsfwFX = string("xSxSPZOmhgExRfoBphfNlxaYaoHDWeSisRANqIGhwjTBLmtsRaeYxRbyWdlMywyIardejOSMdnetHSvbOGfoGNDmQFwYeXrrVMvVQRkZykcylZyDBIDMqPJUsvfioGYlnphfYqqUGYSncVzYIWDzrtgVcivFpvvPQyhzvmhVh");
    string AbJLCUOBbGO = string("qujloNeqXjPeRDIrRzizZJGkDflPeuKQaCgAufTEhIzMdZoyPpPsJbHlEFzdKHbFpBURJyphBYweUjBidsEdPprgaPurcaJHveZosieufIwRwFtPiwWHCZhdEtUVXjsmhZfMxMqGlqCIWflUasHdiRoeTOFHMVHYhNiXwKmNnAaqZQOdYATyMIQChKABzQcQAMDuXETqIdwSDQNePJHacKugusuKPKqfgvWmWiqeIl");

    if (AbJLCUOBbGO != string("xSxSPZOmhgExRfoBphfNlxaYaoHDWeSisRANqIGhwjTBLmtsRaeYxRbyWdlMywyIardejOSMdnetHSvbOGfoGNDmQFwYeXrrVMvVQRkZykcylZyDBIDMqPJUsvfioGYlnphfYqqUGYSncVzYIWDzrtgVcivFpvvPQyhzvmhVh")) {
        for (int ktenCk = 1264489572; ktenCk > 0; ktenCk--) {
            pAmNiNxbIUCSg = mHNnvdRQ;
            pAmNiNxbIUCSg -= mHNnvdRQ;
        }
    }

    for (int ZIFOCuXM = 76263548; ZIFOCuXM > 0; ZIFOCuXM--) {
        AbJLCUOBbGO = peJahTIDEhY;
        BNmlOx *= BNmlOx;
    }

    for (int pcWPqYHGMrXU = 1546357274; pcWPqYHGMrXU > 0; pcWPqYHGMrXU--) {
        continue;
    }

    for (int yilcDxs = 759767403; yilcDxs > 0; yilcDxs--) {
        mHNnvdRQ = mHNnvdRQ;
    }

    return pAmNiNxbIUCSg;
}

string RhqJSTZDFkER::ndDEY(int BjYea, bool aaNzMTz, string bCxYp, bool ucxBM)
{
    bool rNjCMeDQmNKG = true;
    double cShgxnwe = -525135.4941060378;
    string rOFjcHers = string("gwPZDVXMCaYkr");
    string krbblIQXiISGl = string("nazvWufvuLOXcnQmUtfyKDIZZyvXkoUSOtbqDzhqrqcnAFWAQKhZZFALJnZvzlkrxjATquyhloECIZONJWhEyFDQDJciAYnTPQWBZTGZvqlnNbakVwwVGjLAzTvqoclvZTxKbihyyouOSFWwfNXNnKJQCwORmHsxzNLjtnXSCVZDTwShFffTzRCpSOVinRiQwjbLgfDiBwNJhoCnugnytrWkUyXjVwnKpFWxngjMTsEarxOofgbnrJJtAili");
    double bLXMMfmlbd = -666768.2317936704;
    double guTJFNZugiDm = 531629.6290474534;
    bool bynxEJzOJrb = false;

    for (int yJgpGPffEclNQ = 395333252; yJgpGPffEclNQ > 0; yJgpGPffEclNQ--) {
        rOFjcHers += krbblIQXiISGl;
    }

    if (rOFjcHers < string("nazvWufvuLOXcnQmUtfyKDIZZyvXkoUSOtbqDzhqrqcnAFWAQKhZZFALJnZvzlkrxjATquyhloECIZONJWhEyFDQDJciAYnTPQWBZTGZvqlnNbakVwwVGjLAzTvqoclvZTxKbihyyouOSFWwfNXNnKJQCwORmHsxzNLjtnXSCVZDTwShFffTzRCpSOVinRiQwjbLgfDiBwNJhoCnugnytrWkUyXjVwnKpFWxngjMTsEarxOofgbnrJJtAili")) {
        for (int YXaTVlZIgd = 974884872; YXaTVlZIgd > 0; YXaTVlZIgd--) {
            cShgxnwe += cShgxnwe;
        }
    }

    for (int zcHjBkYDRHLrbt = 1056138287; zcHjBkYDRHLrbt > 0; zcHjBkYDRHLrbt--) {
        continue;
    }

    return krbblIQXiISGl;
}

void RhqJSTZDFkER::mgSpFrsmHat(double hAciXwgGOc, double kGpjagSaoZLO, bool LmkjfoDVylTqrb, double cZyNMNmUxiO, int kAdzSJODmXJZcXKW)
{
    bool PcIQsGl = true;
    double kFUor = -745534.0219876809;
    bool yxtoCFk = false;
    string ySoUxEf = string("rmtVlUBdodOKcHUYqlGiQWSEXJMOKQpBeGePhWaifWtqbizUANNOvKmzNdCYpFTlLaGVZtvVXaaSivZiqbysLhZevstyxSAnuKysRCCbXpQLgzDGtaHaHNhvUrFsJtEnnzsqrqevcBEnCr");
    int IAAXtxzNQhrSNTfF = 1319265694;
    double aNNXWCnXCEcBwd = 708248.6882652584;
    double xWXZndbeTTEGZpuL = -767361.2534505854;
    double JoHhVIo = 430011.5039676754;

    for (int ySCpQczKiThLB = 937962087; ySCpQczKiThLB > 0; ySCpQczKiThLB--) {
        kFUor *= kFUor;
        PcIQsGl = LmkjfoDVylTqrb;
        LmkjfoDVylTqrb = ! LmkjfoDVylTqrb;
        cZyNMNmUxiO = cZyNMNmUxiO;
        cZyNMNmUxiO *= kGpjagSaoZLO;
    }

    for (int WEPvuaPCrXAz = 1658138593; WEPvuaPCrXAz > 0; WEPvuaPCrXAz--) {
        continue;
    }

    if (JoHhVIo > 708248.6882652584) {
        for (int pCKTPkfOnHin = 81139303; pCKTPkfOnHin > 0; pCKTPkfOnHin--) {
            JoHhVIo += aNNXWCnXCEcBwd;
            xWXZndbeTTEGZpuL /= kFUor;
            aNNXWCnXCEcBwd *= xWXZndbeTTEGZpuL;
            xWXZndbeTTEGZpuL *= aNNXWCnXCEcBwd;
        }
    }
}

RhqJSTZDFkER::RhqJSTZDFkER()
{
    this->EKFuLshWF(-688023.6166617263, -798905186, false);
    this->RiAFIzmZNsIHHS(-726206.2902844668);
    this->kxGCrnOaDR();
    this->aXuIqSOuiosGQ(false, 599017.8023717976, 34257.286366301254);
    this->QptdPBdoRxk(string("nNmhELnKolpyjDLkFrjeuvWFbFbOFyvsEEpuoDSjXXjTgacHaXkCgFlahWQgSdHmmPEXDdXFuzuQdnvGCitAuZXHlMUx"), string("HhAZIlWbZheCWKaxfdGnlzrvqfFlPKHtxNdFgZbBzUXmyBspTIsXYDINGtaQTIMuQgOxODHXwOhdGFtcUeuyMAokHPRnBzIRQhmCfxxFwjQZSdXyrnEbnkGkzZJPXZycTzoIHLuMymbUmMvQBJnTlq"), -862264.0533054036);
    this->xDKhbvgZluGledC(-1072275917, 368329.6195713667, false, 869535.015134964, string("vyhSpRYgYlHMalcpqsZoKKtQkmhtqICVfpMMRiLfstJqzMifuWRpaPBDShElxCmklzauySsvyVbdZzagTMYxgfZwXIzyOZOIHzHYuNOrslXNjwUsCIiuNAVbWXeOQDowTHFVqhOQDoQteaUvtOOWKntQdQWcGZdDXTbzFQPmlwDZBviDBCYpIMSXCJICkiNtrQBGdBxMYxFRXjropbFdKMP"));
    this->VMOLyWrrDDbhIzS(-9602.134019905883, 1352018446);
    this->ndDEY(-606488712, true, string("WzmDtYpMwzoHSlGTRgIDSoSVOPHNpOQBkXCNSPjrStJTISZaBalQHLdTCgMtoEcqPXzfnKwMerGCHOnSfJNqyeAfBMNldbKCWLlHvNZWKiTQeGXRFlbXjCfUeZBOpVmdJQKrJIRLIWroizQGtSdumpVqnjXYfCJvbhbLdlMcYejYjYOppoALAGBXUyfZ"), false);
    this->mgSpFrsmHat(-55128.79850830482, -118105.48093668203, false, -597884.2532830846, -1331996775);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IVsfCWwiNgwmlR
{
public:
    double UuCHp;
    int jwmQju;
    double vucHQsh;

    IVsfCWwiNgwmlR();
    bool bCOaLwMYybKjt(double vwxOAy, bool zoSjuICjIPmDRGc, int sIdCBfxLUItDLD);
    bool bpJiFLYpEVfrdZ(bool krLPBCmcpb);
    double BVBXQtxzLDbV(string cWRngJ, bool OxBulSuCa, int ZkrtjDsPd);
    string nazEEzxHbG(int OkLioXzeJ, bool TCrYvgg, string eAjgZXxKJlcXi, bool FkxqNCZcf, bool kNQAXZrxvanYDA);
protected:
    double pyakkcy;
    string cgEKLqivsQKFsXA;
    double kZjEvPXvENnZSVJ;
    double qVQgWXb;
    bool sixtjJlRTsXCbGx;

    bool GKjSJOXUh(double AscqEzMBrUEdyvk, string wFORTwgmRxBPifHc, string UNhfPqoxhGupeeb, double BHtaw);
    string LqMKrZjPSL(bool UqDTfvWzy, string GOgNuIDXUyIyDkTH, bool bNOKWenbzaSb);
private:
    double AkSCAmlQlVV;
    string NkKLPRWcJBAu;

    string lNEQqDQd(double keZnRNCZwdbbO, int yaFcr, double BktJCjqaT, string KNsTKTQS, int RhiMR);
};

bool IVsfCWwiNgwmlR::bCOaLwMYybKjt(double vwxOAy, bool zoSjuICjIPmDRGc, int sIdCBfxLUItDLD)
{
    bool VGKSdzTknGFbom = false;
    double ajupkXIrzaFrO = 688058.84673971;
    string sdEfxqW = string("tATUVcHPVDAtqBMoBkeUIVgNeBWfqEsOnHxzlFNqnilIeeYhinknIkOwfs");
    string FIjIabvCh = string("CygrHIUCCuXoIPpgzvWFAdJudnOKDqgzNFoaZrNRhLjePlZoBEqzqPJHcHNxkUWKFTbARSNzeHKSWgdAZIUbBpcOtyWqxBLFmGVzCOFlbyaNlBKnDdWNbkirunHTiwOADMfDjLAKwokrqfhzKpODWosVJiUtSWlAPgyMXFLiwqamhGEmcMoorPWXFKMjJNeOfkMErJ");
    int iOeAmgFaltu = 240635491;
    bool nmjqy = true;
    double bTydPlnCWoN = 688871.1091829361;

    for (int tyEtDq = 869541941; tyEtDq > 0; tyEtDq--) {
        bTydPlnCWoN /= bTydPlnCWoN;
        FIjIabvCh = sdEfxqW;
        bTydPlnCWoN -= vwxOAy;
        VGKSdzTknGFbom = nmjqy;
    }

    if (zoSjuICjIPmDRGc != false) {
        for (int gKuBzcddtv = 1566762992; gKuBzcddtv > 0; gKuBzcddtv--) {
            continue;
        }
    }

    return nmjqy;
}

bool IVsfCWwiNgwmlR::bpJiFLYpEVfrdZ(bool krLPBCmcpb)
{
    double AITYhbA = 216786.5159529868;
    double pUFpioolsitKJzd = -746892.9815165879;
    double IsmaVzjV = 390680.05386835826;
    string PTcsThTbiVmsW = string("WtTSaIgoELNwUSleCmQLfkXeRQUMpfECQNgGlzhkVYsTEbnzkzUtCDbrRxQiynlpDRhpVpOxldgcRJVUOCDXfOnndcsleifczlUQQcvTetVuOLMGROSkmBWSAuapDDCLMPHdUMyhjMoosjXhAdRTmT");

    if (IsmaVzjV != 216786.5159529868) {
        for (int IbIwGCfQ = 1824556249; IbIwGCfQ > 0; IbIwGCfQ--) {
            AITYhbA -= IsmaVzjV;
            AITYhbA = pUFpioolsitKJzd;
            AITYhbA += pUFpioolsitKJzd;
        }
    }

    for (int lfkaRbYYZiUdl = 1002263118; lfkaRbYYZiUdl > 0; lfkaRbYYZiUdl--) {
        pUFpioolsitKJzd = IsmaVzjV;
    }

    return krLPBCmcpb;
}

double IVsfCWwiNgwmlR::BVBXQtxzLDbV(string cWRngJ, bool OxBulSuCa, int ZkrtjDsPd)
{
    double aqMoq = -439855.72499260283;
    string HgnYWWCGPfVOlLYV = string("fgNQgGwfEDAqBeslbpFoWFvXwGJMVQehxMkPDZGzVwqWbwcLbOqJWmULYoPfXzIAnNtdQVYVBWKJksxDSWVuvtiyzKkCRlqIlveErLNCzRPkBcSuGixlpKxqSgYzpklLfsuZoTYrNTVoRHBgiIrPazrOoCUm");
    bool bDbeOhPdNHv = false;
    bool DdQvwUIE = false;
    string FgdmQpCHPp = string("wnRoRNEDdnCdaqJbEtLsueWgPojUhkjaWjssDZIhTPwqyaThdTzqZihFbqOzVvpetEzSDlJDbARKAcBVBNEzIgFglSVRjzJZRjyMYTJwuKIdV");
    int BfnXtigjTLGneaog = -1301920228;

    for (int BRQZkDDHUiHh = 1636399694; BRQZkDDHUiHh > 0; BRQZkDDHUiHh--) {
        DdQvwUIE = ! bDbeOhPdNHv;
        BfnXtigjTLGneaog -= ZkrtjDsPd;
        BfnXtigjTLGneaog *= BfnXtigjTLGneaog;
    }

    if (DdQvwUIE != false) {
        for (int wDIimtQxqxlGBPC = 2033026505; wDIimtQxqxlGBPC > 0; wDIimtQxqxlGBPC--) {
            FgdmQpCHPp = HgnYWWCGPfVOlLYV;
            OxBulSuCa = ! DdQvwUIE;
        }
    }

    for (int wLJBEM = 618484440; wLJBEM > 0; wLJBEM--) {
        OxBulSuCa = DdQvwUIE;
    }

    for (int qxdrQbDldcFiAGlu = 1367989738; qxdrQbDldcFiAGlu > 0; qxdrQbDldcFiAGlu--) {
        continue;
    }

    for (int wMQOwHu = 1086269725; wMQOwHu > 0; wMQOwHu--) {
        OxBulSuCa = ! DdQvwUIE;
    }

    return aqMoq;
}

string IVsfCWwiNgwmlR::nazEEzxHbG(int OkLioXzeJ, bool TCrYvgg, string eAjgZXxKJlcXi, bool FkxqNCZcf, bool kNQAXZrxvanYDA)
{
    string hpnRZxXcSWCq = string("JoRIkutAXLpWkFduRauSzbnPlCPoKLMYXXzWxEGeGrcgIjKzjKYAMaPPjeYmioQbcyceUkOYDTjVzVSRGuSsBOxALzJYepVImUVLGMeffpFAukvDQwhbTnMDFplFsDfbmCdXwLBdhEVWcnBLCYkXPcXpXhBVsebCClAHdrFcjKfFeeOTSTv");
    string TraYsV = string("lTxyPpUIledXGuQcQrXeDPDLBhLQHsLQvedtvToscPAdXchbQcSKoUfKPgcxoKCjusOEklbNWmpExoJINropKTfgaRpSTXZUJJnNtmXLuKLGeabkGtekwjIFzPEOENZbStLtZLVtOXHgmubaWvp");
    double gqTKECcNxwPL = 686048.1516920124;
    bool GSUEV = true;
    bool xHvgSh = false;

    for (int KNSJfSNp = 396810362; KNSJfSNp > 0; KNSJfSNp--) {
        TraYsV = hpnRZxXcSWCq;
        xHvgSh = ! kNQAXZrxvanYDA;
    }

    return TraYsV;
}

bool IVsfCWwiNgwmlR::GKjSJOXUh(double AscqEzMBrUEdyvk, string wFORTwgmRxBPifHc, string UNhfPqoxhGupeeb, double BHtaw)
{
    bool djdLEvPV = true;
    string UEbkfXXPqtbIBWBH = string("tWEGEIoIIwIelSfIHDUniGVjYxtVGeuAKWhAPTJpgLPJdreGvqBTZSCLNjyflbxKKawNLwdDEHlXTaylUGvebwTwlFtOCnTXOdKFHtlNMCdbpaoePgxfrTRdeTBGHRFzpJzXJfGuUdbCMUrXBFMVbAPeAUkAikBQcZpzJdFHtxloDGEdYRTskYKdHfJJFpfglTVGxdSfHwUPrZyrLfieGXVYCeiUwpeqiCFBuNfHIoFxhpiolpGhDZAHx");
    int OiJHEfiaTOAR = 348803462;
    int WtIii = -1942630296;
    bool VHGLiEbgHTe = true;

    if (djdLEvPV != true) {
        for (int vNmiIyOEVzYcBgTf = 40151584; vNmiIyOEVzYcBgTf > 0; vNmiIyOEVzYcBgTf--) {
            continue;
        }
    }

    for (int FIqzGGh = 2145502641; FIqzGGh > 0; FIqzGGh--) {
        continue;
    }

    for (int BgziPV = 1809883188; BgziPV > 0; BgziPV--) {
        UEbkfXXPqtbIBWBH = wFORTwgmRxBPifHc;
        wFORTwgmRxBPifHc += UNhfPqoxhGupeeb;
    }

    return VHGLiEbgHTe;
}

string IVsfCWwiNgwmlR::LqMKrZjPSL(bool UqDTfvWzy, string GOgNuIDXUyIyDkTH, bool bNOKWenbzaSb)
{
    int MCOWWPxd = 558126642;
    double yQKNyTvTvkOJAP = -338942.1939173274;
    string skLZlGeUqcG = string("MzBGfFbD");

    for (int kwTcZqOmiOtoFEEw = 82653143; kwTcZqOmiOtoFEEw > 0; kwTcZqOmiOtoFEEw--) {
        continue;
    }

    for (int oGYaLhgYNJ = 1651719705; oGYaLhgYNJ > 0; oGYaLhgYNJ--) {
        continue;
    }

    for (int SXvCP = 1643962640; SXvCP > 0; SXvCP--) {
        bNOKWenbzaSb = bNOKWenbzaSb;
        skLZlGeUqcG += skLZlGeUqcG;
        MCOWWPxd *= MCOWWPxd;
        skLZlGeUqcG = skLZlGeUqcG;
    }

    if (MCOWWPxd == 558126642) {
        for (int fOpXJPdNixGSyKWT = 1391013592; fOpXJPdNixGSyKWT > 0; fOpXJPdNixGSyKWT--) {
            continue;
        }
    }

    return skLZlGeUqcG;
}

string IVsfCWwiNgwmlR::lNEQqDQd(double keZnRNCZwdbbO, int yaFcr, double BktJCjqaT, string KNsTKTQS, int RhiMR)
{
    bool EarGoJDM = true;
    string onCVADvMJwKLL = string("FOaqjNPNCrSHNrRcdnEGAkjjkeRCOdJsFNqbCKKXCFwTcuvLvTBHMOjBCJnElpdUDtpxFeNsFeJghQEFsTvJSxnFfkkTVVWzXObHUmGWnU");
    double tPgVEJdwBkWASp = -951934.6930927733;
    double mmzjic = 692231.4109076461;
    double MnwuBClxMc = 983033.7804885941;
    string bQtDP = string("PzTeHTjJRIdYFEWNIsYKzCKkbCUsLCWYLwCorXWdNwjaOtNMxFmgcx");
    string oHAoMEkDqOiU = string("hJVjPGRhQYRZZFhaLWOkjrFZCmwFIsfTnoXSweNsIyZxmiXSsGmwwwfpQrZLenIrUXRjBZPCdXzCYoGcxWFFzIiKnNoHvztHVGUeCCSsHxlAhvbXlg");
    bool JpYnrSoHP = false;
    string rDDAcOAgOEvTku = string("tYtBOfxtOdVKqMFXabxvHPWbqWwuuhHrBwFqhLLqxjZVIehWXrxRu");
    double OtJINYNKSRJas = 334771.99985915725;

    for (int NSEUXyjmiYZZZ = 575064704; NSEUXyjmiYZZZ > 0; NSEUXyjmiYZZZ--) {
        continue;
    }

    return rDDAcOAgOEvTku;
}

IVsfCWwiNgwmlR::IVsfCWwiNgwmlR()
{
    this->bCOaLwMYybKjt(274233.49621534237, false, -671102458);
    this->bpJiFLYpEVfrdZ(false);
    this->BVBXQtxzLDbV(string("yDNpKbeXPdCHfoUJrmKtSfGZrYTecvATnEUvaWQWBErTWBczYYjzPKfEKLJvdygSTCTSrH"), true, -2073462410);
    this->nazEEzxHbG(-1956662425, false, string("XfgvfcZVfrpWQaavmZRucEvWoZRCRWUfDKjNqseiyeScKkkFlHsRcbuZdUuWiYGwYAbVwUpBtVqoUnXdQ"), false, false);
    this->GKjSJOXUh(-556208.1369765273, string("dbTqeUSpKKEhXscKQCecrFtqrAAELDOAbWSJBcFnOsXZepvElYADDNMETjevbixTvhsroxCov"), string("PrZCQroujcBdTQrNQxsoxHGXRIkgdJxTWwhOLvcmZPMrcxFbXkcYyTPorjMdnaMEsisCSsTnPnyOzpJHIsXzouNEGYwpEfOlbmNDAeFKfjxKIGlzhsWJLYtnaSJRHuavZaYzGzmGfMtPfeeohipwygBAyMjNAFOdKJctGnVViolWDXPDeKySvOjmkRfUZEBAsemHAvGJVGeogZJmHzYhcmuAigddfvEoExcZUXmKnyWlDveDqVdADASaTlCqN"), 231142.36774933626);
    this->LqMKrZjPSL(false, string("rEcAlzDuMAhgDfNaWnYaPTSBoQZSmcVDVPYcfTewJsLDiYnyFnhjxePOKLooscbAyBiaYhrkChJaOOeDHbatAbhbCJikJUvzpJeLLbwIUMiaDOMwDbxLpYpeUrxlDJFqUwfwkxhhxsJFYKwfLWPSsboXZyx"), false);
    this->lNEQqDQd(-818958.484443936, -395122298, -225912.2106506959, string("xOJpfUFcKHkFSyBoOngyZWNLWZbtkLhLigcYdSCnbYpIzrSKgSLPYLorYsQlOOhGixGzOCEcadJPYAYKKgIGgUPYRZnaGDspByLsOIoxtvBOtaWbGNpWskPDFCAZrbwMzsFDdAVlqGcvyryIhxffyc"), -318885325);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zTeeAz
{
public:
    bool oMFUAzzDUSRtSxy;
    string YApobtvjcFm;

    zTeeAz();
    int xXkOgTTURdgxrX(string XKYMaNk, double iYdpASTYEIRHKr, string euozlPfAqKctUpOj, double dqhazcbqZQ);
    string vIHZKRTZC(bool AWPhgKkR, double PpOabdebUdvCOeR, int zGJmpc);
    double SAaaCLseCndty();
    int wyAQsUrpNOQpALLb(string JfwLFOsfbvP);
    void oMnCi(int WNGBzFe, string RyKFbkLVpucIyq);
protected:
    double ELAztw;
    int QAaxEExBFcq;
    int sTDjd;
    bool TRdWUQJeH;
    string jytyUSbiwsxQ;
    string cMYcPjfw;

private:
    string QwgqGaXNknM;
    bool XDDEHJANxNwB;
    int vsIjDfg;
    string WLYQBBo;
    bool rVhAlI;
    int vlBsJmekCnAew;

    double UCqStMyXB();
    string ucuOR(string CYETZU);
    string zbQzSPAXpwxjqAde(int PJXLLOfPBJBnHU, string bHdfy, string ERUKw);
    void ahyNErVqiuO(double cCzAy, string MrKopmaP, string WYbmxISkpznyNTT);
    int FxAxuQNCkmbPmW();
};

int zTeeAz::xXkOgTTURdgxrX(string XKYMaNk, double iYdpASTYEIRHKr, string euozlPfAqKctUpOj, double dqhazcbqZQ)
{
    string Wvssr = string("AkKsGYaYSGXtldXohJzdazjFPquyZtgcBaONZDCTKFHNqZtFLgBEGdUWtGgCjPLnA");
    double qPCvO = 969870.5807678357;
    int rzXhAF = 11915925;
    int szRaBVj = 1775782185;
    string kSKRaGa = string("UPOIjIUPzytiVHTijPXfBmXcqVWOuzYXPBFIcSRTYdKsQg");
    int gFcbh = 1165004771;
    double msBOVjg = 235488.0949896258;
    string TBnVwgi = string("ZIjZLhSgWcDbzpWglrLWFDfDNfmNFyFTRCipGSebWXeMkHUVoLgLSUrqwWXsIlUSRycgHuAUYCLtgvULWbYPgUmDJtipfGneZAX");

    for (int menTZpfcopqHqCJ = 1140018323; menTZpfcopqHqCJ > 0; menTZpfcopqHqCJ--) {
        gFcbh -= gFcbh;
    }

    if (kSKRaGa != string("vHfVhBUsTfLLRgbIwtCUdCpNezyWfjusSESkqtEEBiKfogueROEjwIElAxdbetNLTvzhDfEdtY")) {
        for (int inbqxZPwlUMsGTlY = 1224019842; inbqxZPwlUMsGTlY > 0; inbqxZPwlUMsGTlY--) {
            iYdpASTYEIRHKr *= qPCvO;
            TBnVwgi += XKYMaNk;
            XKYMaNk = euozlPfAqKctUpOj;
            euozlPfAqKctUpOj = TBnVwgi;
            szRaBVj = gFcbh;
            kSKRaGa = euozlPfAqKctUpOj;
        }
    }

    return gFcbh;
}

string zTeeAz::vIHZKRTZC(bool AWPhgKkR, double PpOabdebUdvCOeR, int zGJmpc)
{
    double UmbOR = 544705.5842291247;
    bool MUycUWeTZxuabV = true;

    if (zGJmpc < -1967928619) {
        for (int fkFsIgyEe = 131513238; fkFsIgyEe > 0; fkFsIgyEe--) {
            PpOabdebUdvCOeR -= PpOabdebUdvCOeR;
            PpOabdebUdvCOeR *= UmbOR;
            AWPhgKkR = ! AWPhgKkR;
            MUycUWeTZxuabV = MUycUWeTZxuabV;
        }
    }

    return string("LZfGXksjFBIGVswqlCNjOeGjJxxiRKmpfrefKIwCOjUYUszGhUpSBJtdvdmwIeOXTScGgFkkxNsaWzlWsbWbuMvugmaWtImtjkbUQbNqRHewdAyAbgpJQmawXVK");
}

double zTeeAz::SAaaCLseCndty()
{
    int lIZdkMzynl = 509856405;
    string vBrBiPB = string("kJYnYTiNYZEooHEBMHbUwomKqGaEdKQsZGkrYZJMDEoyBpjGViYokrtbUXeCzeynOscavysWVquqekoQKXwLSUFNadlLVhzFknniBzXAEPJYjoVeTcPQAiUenyMdCKHQcwsJjkMewAbetCAKkbjmxIUlWIwLakrAESufAONWbqsLllSafffzjPDbpRgRFydrueyVYErJsFYrrWopBoUfhcyuZQWpnFgGCrwrfSccLXTOYeTdDlNCaZbha");
    int giGGJRSXJNLPDAJN = 63480860;
    int PlSpKuIuiFmIFyy = -277089349;

    if (PlSpKuIuiFmIFyy <= -277089349) {
        for (int wdWhwvGKX = 942421003; wdWhwvGKX > 0; wdWhwvGKX--) {
            vBrBiPB = vBrBiPB;
            PlSpKuIuiFmIFyy -= giGGJRSXJNLPDAJN;
            giGGJRSXJNLPDAJN += PlSpKuIuiFmIFyy;
            giGGJRSXJNLPDAJN = lIZdkMzynl;
            lIZdkMzynl /= PlSpKuIuiFmIFyy;
        }
    }

    for (int hUJznXgrfcxUxbOu = 1624653134; hUJznXgrfcxUxbOu > 0; hUJznXgrfcxUxbOu--) {
        lIZdkMzynl *= giGGJRSXJNLPDAJN;
        PlSpKuIuiFmIFyy += giGGJRSXJNLPDAJN;
        PlSpKuIuiFmIFyy += PlSpKuIuiFmIFyy;
        PlSpKuIuiFmIFyy = giGGJRSXJNLPDAJN;
        lIZdkMzynl -= lIZdkMzynl;
        lIZdkMzynl -= PlSpKuIuiFmIFyy;
    }

    return -497977.82757611014;
}

int zTeeAz::wyAQsUrpNOQpALLb(string JfwLFOsfbvP)
{
    double VFPKAhoN = 440148.1660719278;
    bool fCqKNhyIK = false;
    int hHrMcRsdniUhKG = -746686114;
    int UOrjXSZQE = 434664675;

    if (hHrMcRsdniUhKG < -746686114) {
        for (int MXWWTK = 1711495808; MXWWTK > 0; MXWWTK--) {
            fCqKNhyIK = fCqKNhyIK;
            UOrjXSZQE = hHrMcRsdniUhKG;
            UOrjXSZQE -= UOrjXSZQE;
            hHrMcRsdniUhKG -= hHrMcRsdniUhKG;
            UOrjXSZQE += UOrjXSZQE;
        }
    }

    for (int eHBXfDQCEuCcwHaQ = 223068514; eHBXfDQCEuCcwHaQ > 0; eHBXfDQCEuCcwHaQ--) {
        hHrMcRsdniUhKG *= UOrjXSZQE;
        UOrjXSZQE *= UOrjXSZQE;
        UOrjXSZQE += UOrjXSZQE;
        JfwLFOsfbvP += JfwLFOsfbvP;
    }

    return UOrjXSZQE;
}

void zTeeAz::oMnCi(int WNGBzFe, string RyKFbkLVpucIyq)
{
    double MQNdGvrdAqJKkcm = -739959.7057936831;
    int HrcQPWfnLX = 1444865735;
    double puGNodwAnKbgw = -881301.498803192;
    int DWpvsIopxYWf = 1685266967;
    int VRFqBiOjkJkb = -1701622086;
    int aiYpADijT = 671501960;
    string xjiDgG = string("TvKNGGsiLmELBkjdYQxcrLlmJocoxfFcXFBftQfugeNOZYwfDtwEcyADOKMCYfXAkryiMTwRGmcboKJRePvZJgKimOkFAfZKLGZyaEsKytAoMnbMSrskgrexUaepIviUXMuIZFXIpOIiLICndYNWxtUzKOGbVuhZshbHrPHTnAXPpdjbVcyrAaGNZLlLxFIlMBGIcOtkxMAfIBNnEUeuyaYxxEQtUqPZCeXuLWpGyTrTCazTcTuPYBYkIr");
    bool hZxnUYWIsI = true;

    for (int vUmUyPdaYNwDoc = 2095444479; vUmUyPdaYNwDoc > 0; vUmUyPdaYNwDoc--) {
        continue;
    }

    for (int aDeUjlAfm = 2008719797; aDeUjlAfm > 0; aDeUjlAfm--) {
        VRFqBiOjkJkb = aiYpADijT;
    }

    if (WNGBzFe != 1130680489) {
        for (int CpuNPIAIOFSN = 1671531967; CpuNPIAIOFSN > 0; CpuNPIAIOFSN--) {
            VRFqBiOjkJkb *= aiYpADijT;
            HrcQPWfnLX += aiYpADijT;
        }
    }

    for (int HUSoKmWYR = 64962027; HUSoKmWYR > 0; HUSoKmWYR--) {
        DWpvsIopxYWf -= aiYpADijT;
    }

    if (WNGBzFe != 671501960) {
        for (int OGRLUWft = 201662880; OGRLUWft > 0; OGRLUWft--) {
            xjiDgG = xjiDgG;
            aiYpADijT = aiYpADijT;
        }
    }

    for (int gqUxhjPBmLpGO = 1205974541; gqUxhjPBmLpGO > 0; gqUxhjPBmLpGO--) {
        WNGBzFe -= DWpvsIopxYWf;
        RyKFbkLVpucIyq += RyKFbkLVpucIyq;
        puGNodwAnKbgw /= MQNdGvrdAqJKkcm;
    }

    for (int QEVAbxXJWqkjD = 1232196100; QEVAbxXJWqkjD > 0; QEVAbxXJWqkjD--) {
        HrcQPWfnLX -= aiYpADijT;
        VRFqBiOjkJkb /= VRFqBiOjkJkb;
    }

    if (WNGBzFe != 1130680489) {
        for (int FDdkmfXKX = 420856465; FDdkmfXKX > 0; FDdkmfXKX--) {
            VRFqBiOjkJkb *= VRFqBiOjkJkb;
        }
    }
}

double zTeeAz::UCqStMyXB()
{
    string YBTxGoJcn = string("SFlqjtSoMnSCJBQpHVtdcEBpikZXEtWRJFXOupSQCjOZFPsaMGrhITcFuPWQyrjHLGGBiEPZMwRANiaMCnjnQQIGVPMjWHARImrzKzWZghiNEJTRVYJThUvUktIfXFqZKqOOganeWccPfjyDYhkcnHJFOZxvcGdhMiBdwsUqWdEsbU");

    if (YBTxGoJcn == string("SFlqjtSoMnSCJBQpHVtdcEBpikZXEtWRJFXOupSQCjOZFPsaMGrhITcFuPWQyrjHLGGBiEPZMwRANiaMCnjnQQIGVPMjWHARImrzKzWZghiNEJTRVYJThUvUktIfXFqZKqOOganeWccPfjyDYhkcnHJFOZxvcGdhMiBdwsUqWdEsbU")) {
        for (int KPHkXarCCwnpI = 111778432; KPHkXarCCwnpI > 0; KPHkXarCCwnpI--) {
            YBTxGoJcn = YBTxGoJcn;
            YBTxGoJcn += YBTxGoJcn;
            YBTxGoJcn = YBTxGoJcn;
            YBTxGoJcn += YBTxGoJcn;
        }
    }

    return -718023.7750567275;
}

string zTeeAz::ucuOR(string CYETZU)
{
    bool vzrZniw = false;
    string KBNVjGlXbi = string("LOPUesrRWsXjeFNjYJgobQOcuAUXKXkLjwKfrJOeYwKHbcqvfjAdmLwdwBQJPoIezFdAHhPWHZOnqixUPbtifjVwSUdfEHwwsHRzKVEboiwZErVdAfAvWkwOpaQxNKzTYHzFyngUUgcVXEVTdKnH");
    bool iJdaGdvBCQErHZKd = false;
    bool pezmXWcYSXaquUP = true;
    double zCDYdUfXq = 492079.1602734094;
    bool VwGhiOuhofYUHYg = false;
    double wKjQrH = -404969.22047644627;
    double MreqQAvuhEaQZZNm = -659454.4124651821;
    bool ZFbAiPSoUpYsoyPI = false;
    double GfKTHAbMOdMmaRIa = 805144.5586603085;

    if (ZFbAiPSoUpYsoyPI != false) {
        for (int QaRzCBTeYwUWLRxG = 238030737; QaRzCBTeYwUWLRxG > 0; QaRzCBTeYwUWLRxG--) {
            VwGhiOuhofYUHYg = iJdaGdvBCQErHZKd;
            ZFbAiPSoUpYsoyPI = iJdaGdvBCQErHZKd;
            GfKTHAbMOdMmaRIa /= wKjQrH;
        }
    }

    if (pezmXWcYSXaquUP != false) {
        for (int zMSMedHjIsgJj = 1806930657; zMSMedHjIsgJj > 0; zMSMedHjIsgJj--) {
            zCDYdUfXq = GfKTHAbMOdMmaRIa;
        }
    }

    if (wKjQrH >= -404969.22047644627) {
        for (int bJCpDUK = 1755659436; bJCpDUK > 0; bJCpDUK--) {
            VwGhiOuhofYUHYg = pezmXWcYSXaquUP;
        }
    }

    if (CYETZU <= string("LOPUesrRWsXjeFNjYJgobQOcuAUXKXkLjwKfrJOeYwKHbcqvfjAdmLwdwBQJPoIezFdAHhPWHZOnqixUPbtifjVwSUdfEHwwsHRzKVEboiwZErVdAfAvWkwOpaQxNKzTYHzFyngUUgcVXEVTdKnH")) {
        for (int HJjhMCltHRE = 2102554358; HJjhMCltHRE > 0; HJjhMCltHRE--) {
            continue;
        }
    }

    for (int xGUqKfOtsKz = 1173972580; xGUqKfOtsKz > 0; xGUqKfOtsKz--) {
        iJdaGdvBCQErHZKd = ! vzrZniw;
        KBNVjGlXbi = CYETZU;
    }

    return KBNVjGlXbi;
}

string zTeeAz::zbQzSPAXpwxjqAde(int PJXLLOfPBJBnHU, string bHdfy, string ERUKw)
{
    double yyfIzxpwgoryudps = -348663.349124583;
    double ZxbDwTwC = 655384.2264349164;
    int muImFRDqdBmtzJ = 1022438879;

    for (int QhxNj = 1015348176; QhxNj > 0; QhxNj--) {
        ERUKw += ERUKw;
        bHdfy += ERUKw;
    }

    for (int cabehviymBmdRz = 613302300; cabehviymBmdRz > 0; cabehviymBmdRz--) {
        ZxbDwTwC *= yyfIzxpwgoryudps;
        ERUKw = ERUKw;
        ZxbDwTwC -= yyfIzxpwgoryudps;
        ZxbDwTwC *= yyfIzxpwgoryudps;
    }

    for (int bNeTIjnUfUXjy = 265836732; bNeTIjnUfUXjy > 0; bNeTIjnUfUXjy--) {
        muImFRDqdBmtzJ /= muImFRDqdBmtzJ;
        PJXLLOfPBJBnHU /= muImFRDqdBmtzJ;
        ZxbDwTwC = ZxbDwTwC;
    }

    return ERUKw;
}

void zTeeAz::ahyNErVqiuO(double cCzAy, string MrKopmaP, string WYbmxISkpznyNTT)
{
    int EkcyZADtezyiGPTo = 166646857;
    string yYULVQdetWnu = string("uRJOKaZuOwuSOOVFWiKdPNkhlnjzfXakFfkJVECZiivzxkITcinszFqciEDKJUdYBVLQspMYFZEoDeplvfgvMYbHApoJyUPmaZrjjkypJYbEEMfOGTafQ");
    bool uznMs = true;
    string TXdAleNYMsb = string("aCtfEVBSbKHlhLhQJOUvdeccRyYdDZwAAfjdjPYJtRVndDvDFgKogcSffYinCPMRsfLXtmGyzMRJIONUYiaguMpdVjnlwmmtgmUHMRKnfPWDxMQPqmpUgzDMoUYXFsxiAskmotDSrMwVdkNylHWAQOPhdnnCBgQZcyZYcyOWvOZVPYmSlccCqoWKzMCRvQILIWaRAyYCYRpieqYml");
    bool uyNVuaXC = false;
    int PBULwzyYCCZJoT = 1320654037;
    double QtYJWQkeOsyuvE = -699388.6211800184;
    bool ypKxzMmzq = false;
    string fpPvQIzwnczUtVbr = string("hDFKjMrPmZfMHDyPjxTmumOWEizTvcyuhOofEpRYtfUmmPXEeLchXWiBGQTrmbNCiIXoiMLHUvGDKwcnScTmmbSeWTmusbLmenYUsgHVnDOTPHFNhIgXUCwXGaYtTxRXgQQdnmOJNsxWLhXZjAugLNSYHFDPiIOpkqhLPwWUGsBSAnOdJRRDnnOcEotRoGeQSdgxcTOxUVuXenhByLyCtCneCdEXR");
    double JvuWRzuzLaUHgtHL = -936964.6540318455;

    for (int SnSQl = 1267252159; SnSQl > 0; SnSQl--) {
        uznMs = uznMs;
        MrKopmaP = TXdAleNYMsb;
        cCzAy /= QtYJWQkeOsyuvE;
        QtYJWQkeOsyuvE = JvuWRzuzLaUHgtHL;
    }

    for (int YaffGvb = 1173303024; YaffGvb > 0; YaffGvb--) {
        TXdAleNYMsb = yYULVQdetWnu;
        fpPvQIzwnczUtVbr += MrKopmaP;
    }

    for (int yHzFAimlrdqcnfUS = 53134594; yHzFAimlrdqcnfUS > 0; yHzFAimlrdqcnfUS--) {
        fpPvQIzwnczUtVbr += fpPvQIzwnczUtVbr;
        MrKopmaP += fpPvQIzwnczUtVbr;
        WYbmxISkpznyNTT += yYULVQdetWnu;
    }

    for (int ABuoQNBcilw = 542749596; ABuoQNBcilw > 0; ABuoQNBcilw--) {
        fpPvQIzwnczUtVbr += yYULVQdetWnu;
        MrKopmaP = yYULVQdetWnu;
    }
}

int zTeeAz::FxAxuQNCkmbPmW()
{
    string scvbG = string("ZJMOxmlHAewYpOLAaZGFilojFTMYzGzmmIbxQDFMdVzfgXuGfxpdDmKUnaDmiYOIRcaUtDwuvPHUwHYDjjXDhxDDECzUcXefZsKzVaLJitPonJpGYPteGVxXuIPGwIlfgITUAnoXFdfLXxjkvykucJoZMWBNhvOtTACLwZxtVtIQTjBxQNGifiLyZUfSvIBejLbbYgHJfIyJZfkYjEicld");
    double VvascnuISe = -760866.8385103677;
    double MKMrMPyAA = 666699.7082460397;
    string cZUTRbujqTV = string("TLwJyMNQCkbubprtDgldcBwHdbzLvAmzTdZxMeTPVVZTcpygTHRErBmfUGfXQkEbLQoQLKCakttuzGTUdxnTbtaoSzBuxMuXTYTYfKWATDVcaGUiXcwhVwzlDPdUqPWsNGlhjZcIEtmdXAXeKpsJcrxMWqqGwZPMSTNqsQQwLpFpBlcnhSxPeUbKEcHxXEAKQZZPTFvYHjAnvyfdhIWOFyjaTAApnsOPKrVuWLohQxxkJhgbWlmPThaXkGt");
    int dRSrlj = 1309152632;

    for (int ROZgXqpQOphT = 2097517519; ROZgXqpQOphT > 0; ROZgXqpQOphT--) {
        VvascnuISe = MKMrMPyAA;
        MKMrMPyAA -= MKMrMPyAA;
    }

    if (scvbG <= string("ZJMOxmlHAewYpOLAaZGFilojFTMYzGzmmIbxQDFMdVzfgXuGfxpdDmKUnaDmiYOIRcaUtDwuvPHUwHYDjjXDhxDDECzUcXefZsKzVaLJitPonJpGYPteGVxXuIPGwIlfgITUAnoXFdfLXxjkvykucJoZMWBNhvOtTACLwZxtVtIQTjBxQNGifiLyZUfSvIBejLbbYgHJfIyJZfkYjEicld")) {
        for (int JGLnRPgcPvBRVOq = 584558346; JGLnRPgcPvBRVOq > 0; JGLnRPgcPvBRVOq--) {
            dRSrlj *= dRSrlj;
            cZUTRbujqTV = scvbG;
            scvbG += scvbG;
            cZUTRbujqTV = scvbG;
            scvbG = cZUTRbujqTV;
        }
    }

    for (int wNhQUrrY = 1469394421; wNhQUrrY > 0; wNhQUrrY--) {
        VvascnuISe *= VvascnuISe;
        MKMrMPyAA *= VvascnuISe;
        MKMrMPyAA = VvascnuISe;
    }

    return dRSrlj;
}

zTeeAz::zTeeAz()
{
    this->xXkOgTTURdgxrX(string("ULTsEgoUkDbNuxaBFALbrtFCpXkvRvrdjPmbpZhJaYFQbnugSFvVzKpgJonvefhUCOVpbCwHbNYMTrnvGDqnInxGKnhCHnMoSXJQQCuvpFcEMGbqxvopMvKbJmjtppKtlUYvERTOzFPExKjEfjunEuKGBEQVBAOldAJBqAFMTofxdfrIArHbUFDwJJcvpfmaHtgKJW"), -660508.5844875904, string("vHfVhBUsTfLLRgbIwtCUdCpNezyWfjusSESkqtEEBiKfogueROEjwIElAxdbetNLTvzhDfEdtY"), -1014599.929615885);
    this->vIHZKRTZC(false, -519029.4836290426, -1967928619);
    this->SAaaCLseCndty();
    this->wyAQsUrpNOQpALLb(string("UtTyFzaxPDEMGoZWnseJVNNQGVxJCfUHwolaFBYAmdPrXjmivICYyrZROAyLHqmHgUaRAFPBQ"));
    this->oMnCi(1130680489, string("dhWQkzIZbDssZrzyNOkhLViMtNhUZjZwQiwClFtzhxMnSrIhWvaSDUftwCVoFnBjJPKwqwEQscKjWNEhUZfTbJNUOx"));
    this->UCqStMyXB();
    this->ucuOR(string("GCckURUtqsDDZbXPPfQsLwJrBLImkUlesWoubaExgAUywzOIeeODstOpZVqfcvKInhsVkvvFJmkMMPCZaZhQtdIDrRYMOkCpuVCMvoopfgSQnuoPqHvlhCuGjzUblUhCWgIgLAwtjdtaaCzylnBaLgqjKpvkJRUbHXPdzAEcJKbPRxDlcQOUqclbaXaWKid"));
    this->zbQzSPAXpwxjqAde(521908115, string("WQMZdQOLmz"), string("HenSMyZLMAyRcOoQjIIzMNSgFkvjRHogjyPkpUxLBsSEuraffjtnfbxvGErjsVxSPPRkLauxemrPLyUumBImmgKnsnoQJFfgQyMccVTAND"));
    this->ahyNErVqiuO(220929.154572714, string("fFIpUqbfRPpYnqhlmzdghwjmkfNxytOWBLjsaAQdcNxfpmtTvRTXqoNLfiRWewuqVGzChwnrYfsPqUxII"), string("LWMPsCmctXtZAwZnSMdOPNxwbccvplhQyVoglnonvFOxdEYFAuovLFsjgTWq"));
    this->FxAxuQNCkmbPmW();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IQvBjhCCGfFJve
{
public:
    bool zAAYMDh;
    double jeyQEChQloC;

    IQvBjhCCGfFJve();
    int Bncja(int bFylLG, string tMikEobiG);
    double ZPcvH();
protected:
    bool HmCOQAGnQ;
    int gJQZwpHlsZuhBZKa;
    string vsUcfKJg;

    bool MUcdCIk(string ymnCUyfa, double oxlpiGmXBUSo, int vKMEHHudVjEZV, int LynPLx, string GxeYyNvvMI);
private:
    bool rrdljYLsOrQylUHn;
    bool vdrVh;
    double oKCvIFqyDU;

};

int IQvBjhCCGfFJve::Bncja(int bFylLG, string tMikEobiG)
{
    string gtFfizO = string("QYqtbccQOnZNMwTOCYihFVdFIjqyteezeKbPiVndEmcyrsOImeQseRmbyxIwkWbyouUHIvgeGXzcHVezOYlITGcCBWUokkltQYIfQhvZYWjIYbEhtlYcmBRWYcwTtIrUBULPhfvRRHLpMLYJWaUMPatWIkOIChupqitUQJqJFrxqtBlgIncJbhfWpRfJbNXlECoJUAjXnrVODpBhEUnGEFiiQGCpcHixZluQm");
    string eCkyKEDyPqEx = string("oQXDrnwbfPZlDjkkHqqwCsCLjndDmSgJMOyFwaMzEQJoEuPxDMHOYAwyeXzbDepUnaYunEUvkOrFgLRLblEUGHKbUZKCLstsMmYSSAMzPgdFUYMigQiGKPuvXEQUe");
    string fVhINRQjpCKz = string("zlAEphJhHyHEmIGXLoFLTnWYOWYjWJqNSZXpsPBvcKZoGdRrZzrkIykCzUhKUlhHEecSLOwoGqwKqkGxXvAOCCGmUHVLSkUbVChHBWpTwvJjOVOioWGGetaCSpUOIGZhvl");
    bool oXPibt = false;
    double mETmOaT = -10132.029196209065;
    double PlUglh = -590471.4217748926;
    int PyYPmiLWsrQoH = 1324194840;

    for (int YfTqeeQX = 341075397; YfTqeeQX > 0; YfTqeeQX--) {
        continue;
    }

    if (PlUglh >= -10132.029196209065) {
        for (int JssOtwN = 331714198; JssOtwN > 0; JssOtwN--) {
            bFylLG -= PyYPmiLWsrQoH;
            mETmOaT = PlUglh;
            gtFfizO = fVhINRQjpCKz;
        }
    }

    for (int FgwGiAe = 1958896217; FgwGiAe > 0; FgwGiAe--) {
        gtFfizO = tMikEobiG;
    }

    return PyYPmiLWsrQoH;
}

double IQvBjhCCGfFJve::ZPcvH()
{
    int ATDdyBftWeRaOlQ = -1871572339;

    if (ATDdyBftWeRaOlQ != -1871572339) {
        for (int hgwAApgRVIe = 166534041; hgwAApgRVIe > 0; hgwAApgRVIe--) {
            ATDdyBftWeRaOlQ = ATDdyBftWeRaOlQ;
            ATDdyBftWeRaOlQ /= ATDdyBftWeRaOlQ;
            ATDdyBftWeRaOlQ = ATDdyBftWeRaOlQ;
            ATDdyBftWeRaOlQ = ATDdyBftWeRaOlQ;
            ATDdyBftWeRaOlQ = ATDdyBftWeRaOlQ;
            ATDdyBftWeRaOlQ *= ATDdyBftWeRaOlQ;
            ATDdyBftWeRaOlQ = ATDdyBftWeRaOlQ;
        }
    }

    return -1007097.9943719038;
}

bool IQvBjhCCGfFJve::MUcdCIk(string ymnCUyfa, double oxlpiGmXBUSo, int vKMEHHudVjEZV, int LynPLx, string GxeYyNvvMI)
{
    bool FcEJFoD = false;

    for (int kzRhZoRwatdmD = 1100237467; kzRhZoRwatdmD > 0; kzRhZoRwatdmD--) {
        LynPLx += vKMEHHudVjEZV;
    }

    if (ymnCUyfa <= string("AGSJDwOVwyjikQpudlWDFYxHZmjpzlKCUWngGAOnvDRbLLtGLGSWlRINSVopPquuWxjlvFcuWbOqOQkBvBOTbIxfTUyMRUJktGbxefTcuoLbXtPzSWmaTxrcG")) {
        for (int RtZlmffERURgZ = 1582498598; RtZlmffERURgZ > 0; RtZlmffERURgZ--) {
            ymnCUyfa = GxeYyNvvMI;
        }
    }

    return FcEJFoD;
}

IQvBjhCCGfFJve::IQvBjhCCGfFJve()
{
    this->Bncja(967195521, string("sBFaoueuPlEEbHqbroPTSwmeQjevnDFKWGmzXBI"));
    this->ZPcvH();
    this->MUcdCIk(string("xUJGjyedfogvAibNJvNzjSulnioEcukzzvypRpErGmPydsNigMZQmlawcnFziPNuVnfLYgHaYjelMnWsSIHgwnTEuoDskgbZmFgAYVGfbtXWWKuXCseeoCsEnPfieBroYPLDZBduopaGPAqkHLyuaBZiZQdSTVJCmUOFqcPYBgEnhJHhKdusSUNfkzMHVrXmZyWuOpTCxuWUBSCdo"), -278695.8642571631, -317842982, 1790535764, string("AGSJDwOVwyjikQpudlWDFYxHZmjpzlKCUWngGAOnvDRbLLtGLGSWlRINSVopPquuWxjlvFcuWbOqOQkBvBOTbIxfTUyMRUJktGbxefTcuoLbXtPzSWmaTxrcG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UtPmsNAVadnlqS
{
public:
    string ZYKMsYTIX;
    int sLYYYomCApxWTBV;
    int QKpXEMX;
    string dFcyhrfvCHf;

    UtPmsNAVadnlqS();
    double pXZMqJiJRRv(bool gLBfpleqry, double qtyigSjvmR, string EymJj);
    string lMnLJArg(int AYIVovzENWcTcg, string wJxJVwtxYesyqNc);
    string RKjlE(string TggzDEBqkm, int WOPlOhXi);
    string tdzulqrKm(double yrqzZxJRaR);
    string zPtnRZqiom(double BWFobKGT);
    bool xaLhQwzoRQPv(string dEhleNfoocFCws, bool YCoDEGPdFLe);
    void pMrEQWEklInF(double LsrTFJd, bool iPlNfFpajk);
protected:
    int JTrtSTTcONVb;
    double sJzQdWrtdzJ;
    bool JZAXdPikgzWLTU;
    string KnHTuOTivr;
    int HkvnYXIJGYYQsF;
    string dCnOQMxihdT;

    string QKlRrcaCKc(bool tRGgiqjlDuj, string zGalC, bool cPYREvoytFGF);
    double HlFdkonh(string mZNitBmKsIdlU, string MmGwQUBe, int IewMCxwOG, string avBeWLpQmN, bool drQWLjiw);
    double vIFNyqvNFMEbva(double chAIgVckEmlpajrM, double TYiTg);
    bool gmrSzNSNqrB(int keBXJg, bool rmFQIhOLoJono, string IQZfmSxAvVoEox);
private:
    bool pOfwakhl;

    bool QfuFQMGEQlLxkVHU(double EKqyKzkm, bool FQMnvaoOiFtsLhY, int yPGLcotSU, double WiFlKuSErYHfJtw);
    double jmPWRaLLsjKki();
    string ZwoWjrS(double CsBqMD, bool DoKKUWCUNR, int eSiMyMlpnkgEFyJc, double PBkfFWgxL);
    bool dfndndQvJKpIy(double KYCLqReTFlFlgW);
    string KFovWvhWqccKXc();
    string WCzZYY(int ZOElXfH);
    int kfWoPzNdSccZasfT(int PFUAZtcCSvIaBWmu, bool xDAhCwIGHKtCKun, string OcDCYkzOfUi);
    bool wovqmoSFNJ(double ErfXtoreTEiyIA, string Dycwjrzjgxrdn);
};

double UtPmsNAVadnlqS::pXZMqJiJRRv(bool gLBfpleqry, double qtyigSjvmR, string EymJj)
{
    double sLkOxb = -211689.28582607003;
    double jiEevX = -864366.2739705396;
    bool vFLbDEklYVUSwI = false;
    bool jNrlRk = true;
    string CkHQarbQYijFYK = string("MxkAGNOUyiCrKleRFHJxIKLzbPgDFbZEfjJfepBuWGSYuynoLQCeCXjrasttWYknjCtEGSAoAJtpQNrBlNCrlfDEOXgNWUxzNIGKQjvglXJonPrvUtzKaQSLWfvrtBjcBirrSXbEMsPtLhWCWnulMrQBQwGFtRADqiZfEybVqzrZtHbGGFwLKRpIX");
    string Rimynk = string("BVFomuqDAwZSFDngwEhaeUldlNBNgIqkrHOvZSmnoZsoAMLWldHayVUjIPgPWZmvefGJeAfcAwzwcOMb");
    string LJTJMhmRGtFLQiy = string("zfvHnoeLAYepKMYOedcOFXlNdRLtHVCILorQxLzdYzIHelBqNPEgPNlxKievNXnIxLynlLjjneSdRybOvcbcmFoUhqflgSrGDoAbUCsHSsbiwXXatEgQJbbZVSzRXBIFdKdyznYpJLYBuYxfDvyNmVxIXgHnMvrKHvIrGgrLvzAljFcoaWqfiCHUwhTEESNuKjaLOVodRfYdnpeSxMZpSbBYNWiEmrHDXQpkLANWuicsNnKEfht");
    int DEJRdcyn = 679890805;
    int WwJnygzCjqzus = -1291794796;

    return jiEevX;
}

string UtPmsNAVadnlqS::lMnLJArg(int AYIVovzENWcTcg, string wJxJVwtxYesyqNc)
{
    string FZLEjGm = string("ifPWTxzekVnnNDyQMfOIY");
    double QWkgPtcNIIpkIg = 78122.91172119523;
    string glXdSwKeoJNaq = string("LhMMGYXHGlOogXUiIRaqDvnhfLQXZEGPnsCxMZeidPjREgXAnDWiRYUAugdgZJfnwaUkyRsrwqXbUZfSenbWgrynCIDKtqTpXPqsZKWfPCYBrbDsDCUIOXKADAraLRcrFXctbmBCrccChKoXeFenShbKzCkPYcMfeKNaPtBlJ");

    if (glXdSwKeoJNaq < string("LhMMGYXHGlOogXUiIRaqDvnhfLQXZEGPnsCxMZeidPjREgXAnDWiRYUAugdgZJfnwaUkyRsrwqXbUZfSenbWgrynCIDKtqTpXPqsZKWfPCYBrbDsDCUIOXKADAraLRcrFXctbmBCrccChKoXeFenShbKzCkPYcMfeKNaPtBlJ")) {
        for (int sQYisZmVQgi = 2007201685; sQYisZmVQgi > 0; sQYisZmVQgi--) {
            continue;
        }
    }

    if (glXdSwKeoJNaq < string("ifPWTxzekVnnNDyQMfOIY")) {
        for (int qNNxOcWxI = 271195557; qNNxOcWxI > 0; qNNxOcWxI--) {
            glXdSwKeoJNaq = FZLEjGm;
            FZLEjGm = FZLEjGm;
            FZLEjGm = wJxJVwtxYesyqNc;
            glXdSwKeoJNaq = wJxJVwtxYesyqNc;
        }
    }

    for (int SrmqUIqjUxfMbAPX = 1627546237; SrmqUIqjUxfMbAPX > 0; SrmqUIqjUxfMbAPX--) {
        FZLEjGm = wJxJVwtxYesyqNc;
        FZLEjGm += glXdSwKeoJNaq;
        wJxJVwtxYesyqNc = FZLEjGm;
    }

    for (int BjJjiGlVtCgDI = 80903221; BjJjiGlVtCgDI > 0; BjJjiGlVtCgDI--) {
        continue;
    }

    for (int CXsiZqmSbAoiqvA = 2055347001; CXsiZqmSbAoiqvA > 0; CXsiZqmSbAoiqvA--) {
        glXdSwKeoJNaq = wJxJVwtxYesyqNc;
        FZLEjGm += glXdSwKeoJNaq;
    }

    return glXdSwKeoJNaq;
}

string UtPmsNAVadnlqS::RKjlE(string TggzDEBqkm, int WOPlOhXi)
{
    string PSvaxQQLGOG = string("QSiIpuBfOMtWKnWpeXGqnpAMHtIBuQgzJxMnYhYkZsIvPGzqPRZtcoUEkLgaCPPImzIuWcWgwzbw");
    double LHWlXQrpPMLwP = -480080.00090497173;
    string mGwkNg = string("cDkxdHtTSqwhAoeSyRwmfG");
    int wasnGR = -1289760598;
    int pjyTCwsU = 1557406153;
    bool XduSjn = false;
    bool cRosfTGFfybb = false;
    string pDqMaIh = string("alaRqxsnrgIvVvSViZYuMEGcgPJvVNyzWMeWleePiijovTduAvsiePEWXNvuIUPqzOqSMoJjEFimeDedggxdNgwQvdenABGTCoUsRUEjEQvfnJzTZjdSWBDzeDQSNGzWMAwWBWOorClxEfdInnPZKjNLDCyroAcnvZpgzAHRLTblaxUqCJtvQbJHbZGHeAgGAeQxfHtRIxTVroPWYUAaxhjnaaCaCXNKAZMjTUEFXrVuEwmbLOMbEptcJ");

    if (mGwkNg > string("QSiIpuBfOMtWKnWpeXGqnpAMHtIBuQgzJxMnYhYkZsIvPGzqPRZtcoUEkLgaCPPImzIuWcWgwzbw")) {
        for (int kPHbGJkM = 848912706; kPHbGJkM > 0; kPHbGJkM--) {
            pjyTCwsU += WOPlOhXi;
            pjyTCwsU -= WOPlOhXi;
            wasnGR /= WOPlOhXi;
            pjyTCwsU *= wasnGR;
        }
    }

    for (int EsIiNIHdh = 861009430; EsIiNIHdh > 0; EsIiNIHdh--) {
        TggzDEBqkm += TggzDEBqkm;
        mGwkNg = mGwkNg;
    }

    return pDqMaIh;
}

string UtPmsNAVadnlqS::tdzulqrKm(double yrqzZxJRaR)
{
    int zGpydttQyQyLy = 1003396337;
    bool YnGQaLfwLD = false;
    int FGwSrmukcoQXJWYh = 894128954;
    bool UDkYxORNeTKn = false;
    string SdQspDLRjF = string("ApPqtyYxKXnGFznmvNedGmRjcDYuCObJckKnBSuHkIfZKFcSDUJZIuyKdwOZawtYXsiLgYnFoYDGcqxaHIRafdlizngUCqHuIRViDyTbIItPmZtuaXAkXQNZWmqALYjQhBxPVP");

    for (int Aejfi = 602555928; Aejfi > 0; Aejfi--) {
        FGwSrmukcoQXJWYh /= FGwSrmukcoQXJWYh;
        YnGQaLfwLD = ! YnGQaLfwLD;
        yrqzZxJRaR = yrqzZxJRaR;
        yrqzZxJRaR -= yrqzZxJRaR;
    }

    for (int TcQTPXHBJ = 3255464; TcQTPXHBJ > 0; TcQTPXHBJ--) {
        zGpydttQyQyLy += FGwSrmukcoQXJWYh;
    }

    return SdQspDLRjF;
}

string UtPmsNAVadnlqS::zPtnRZqiom(double BWFobKGT)
{
    double efxbdCBOegnf = -898728.5498611188;
    bool WJmoyI = true;
    bool PnPwhbrct = false;
    bool DEnkRJnvXjSnHcW = true;
    string zRfeUky = string("fJBCkORwrPstYdDiJakmpxDeprCNTcZsSRvYrjDjRiXiKKHpeXbCRQszzgIETcoNRccGqhQDvMQBQkCuwXnpqDIUYkDTXMFOvAANUSnFGqwEhZRnuLNhBuSSyqnShUgZqdmxnAfNfDqKnULJkCKbqJZaFCTCCFEmZtPQTffYRxHsEgKHPwdmwzyxzsmExbMqsXYklFWM");
    string fFidIfG = string("pmKzPwbhNeAYVPQuCAWbQAVSjaATyW");
    double dVnvOFXZ = 492965.97341816407;

    if (efxbdCBOegnf >= 492965.97341816407) {
        for (int TNoCDw = 1154292773; TNoCDw > 0; TNoCDw--) {
            BWFobKGT *= BWFobKGT;
        }
    }

    for (int vzXRUe = 282576423; vzXRUe > 0; vzXRUe--) {
        PnPwhbrct = WJmoyI;
    }

    if (efxbdCBOegnf >= -898728.5498611188) {
        for (int NnIrgXBGEM = 1403444356; NnIrgXBGEM > 0; NnIrgXBGEM--) {
            DEnkRJnvXjSnHcW = ! WJmoyI;
            efxbdCBOegnf += dVnvOFXZ;
        }
    }

    if (DEnkRJnvXjSnHcW == false) {
        for (int ETBOFnv = 1314864894; ETBOFnv > 0; ETBOFnv--) {
            efxbdCBOegnf *= BWFobKGT;
            dVnvOFXZ *= dVnvOFXZ;
        }
    }

    return fFidIfG;
}

bool UtPmsNAVadnlqS::xaLhQwzoRQPv(string dEhleNfoocFCws, bool YCoDEGPdFLe)
{
    string mklEeZjWUu = string("bgJJPyMgsAjiKwXtuDMtiMdJYhqMVSMSCgMfyaEdxlDCwRXKQElfkVFHeopsDkkxwPSPXzxtPDFKPMqpRdWTqyxPGbzfEulxUwGTNavyPoyPkREjFKVIPiXlRSFjRsnD");
    bool pEQJwpvejOWZigC = true;

    for (int ojHMdMdniu = 168882844; ojHMdMdniu > 0; ojHMdMdniu--) {
        mklEeZjWUu = dEhleNfoocFCws;
        pEQJwpvejOWZigC = pEQJwpvejOWZigC;
        mklEeZjWUu = dEhleNfoocFCws;
    }

    if (YCoDEGPdFLe != true) {
        for (int AysutCdaAOmkrZk = 541970857; AysutCdaAOmkrZk > 0; AysutCdaAOmkrZk--) {
            pEQJwpvejOWZigC = YCoDEGPdFLe;
            pEQJwpvejOWZigC = YCoDEGPdFLe;
            mklEeZjWUu += dEhleNfoocFCws;
            mklEeZjWUu = dEhleNfoocFCws;
        }
    }

    if (pEQJwpvejOWZigC == false) {
        for (int cqSGuSaPKbcW = 1485569509; cqSGuSaPKbcW > 0; cqSGuSaPKbcW--) {
            pEQJwpvejOWZigC = ! YCoDEGPdFLe;
            pEQJwpvejOWZigC = pEQJwpvejOWZigC;
        }
    }

    return pEQJwpvejOWZigC;
}

void UtPmsNAVadnlqS::pMrEQWEklInF(double LsrTFJd, bool iPlNfFpajk)
{
    string sVEDp = string("dmpnBVEwywiHjCdzeAUMCyodnQKZGCzbplbHwIbZDJSaotAtjqtvSdQNNtGRVhhAnwvaaOPoyDObYEEpESfeqYPOUmiOVJzigAQKgXMMyloFONdzbcYteIPfciU");
    int GtvieF = 797117258;
    int sLKmMMsQMUPz = -982147164;
}

string UtPmsNAVadnlqS::QKlRrcaCKc(bool tRGgiqjlDuj, string zGalC, bool cPYREvoytFGF)
{
    string CBnnsZiVejHuXZ = string("IKoCbnnvfgkbCZcnRioDuiu");

    if (tRGgiqjlDuj == true) {
        for (int VBzUwycRHMoc = 797474730; VBzUwycRHMoc > 0; VBzUwycRHMoc--) {
            cPYREvoytFGF = cPYREvoytFGF;
            cPYREvoytFGF = tRGgiqjlDuj;
            tRGgiqjlDuj = ! cPYREvoytFGF;
        }
    }

    for (int uVSqwhrA = 537649394; uVSqwhrA > 0; uVSqwhrA--) {
        zGalC += CBnnsZiVejHuXZ;
        CBnnsZiVejHuXZ = CBnnsZiVejHuXZ;
    }

    for (int woVvln = 1012968580; woVvln > 0; woVvln--) {
        zGalC = zGalC;
    }

    return CBnnsZiVejHuXZ;
}

double UtPmsNAVadnlqS::HlFdkonh(string mZNitBmKsIdlU, string MmGwQUBe, int IewMCxwOG, string avBeWLpQmN, bool drQWLjiw)
{
    bool trsEygoGuXsNAAVp = false;
    bool PlVAzPgWep = false;
    int SiUiZlWAkJyu = -79546387;
    double AqbVAoBfJCIB = 622198.8523504195;
    double PNYeDaBTIF = -846717.1808417372;
    double JbGrq = 327795.9585412382;

    for (int atumqKvTraXcIKSW = 173317925; atumqKvTraXcIKSW > 0; atumqKvTraXcIKSW--) {
        mZNitBmKsIdlU = mZNitBmKsIdlU;
        trsEygoGuXsNAAVp = ! trsEygoGuXsNAAVp;
        avBeWLpQmN += avBeWLpQmN;
    }

    if (SiUiZlWAkJyu >= 1269152549) {
        for (int mhRuFXMjfmdvqCEl = 1015079380; mhRuFXMjfmdvqCEl > 0; mhRuFXMjfmdvqCEl--) {
            continue;
        }
    }

    return JbGrq;
}

double UtPmsNAVadnlqS::vIFNyqvNFMEbva(double chAIgVckEmlpajrM, double TYiTg)
{
    double BkUVOA = -87359.39569357678;
    double OQwaL = -540650.7691363769;
    double XiZVHDdzQzyZCTYg = -1001425.4970768938;
    int jkKhGUD = 1644044694;
    bool BfpjrLxHdPLXH = false;
    int unymKeZoaRXaMK = -316998290;
    bool qlrWbysT = true;
    int gInRRtAMvr = -1783903416;

    for (int ZMYNNwYeIXCryUn = 130732725; ZMYNNwYeIXCryUn > 0; ZMYNNwYeIXCryUn--) {
        TYiTg -= TYiTg;
        jkKhGUD -= unymKeZoaRXaMK;
    }

    if (XiZVHDdzQzyZCTYg == -87359.39569357678) {
        for (int aYIxXuulxaEgomYq = 1110453928; aYIxXuulxaEgomYq > 0; aYIxXuulxaEgomYq--) {
            gInRRtAMvr /= unymKeZoaRXaMK;
        }
    }

    for (int DXPdSLHYvJ = 266022546; DXPdSLHYvJ > 0; DXPdSLHYvJ--) {
        chAIgVckEmlpajrM -= BkUVOA;
        TYiTg /= OQwaL;
        OQwaL -= XiZVHDdzQzyZCTYg;
    }

    return XiZVHDdzQzyZCTYg;
}

bool UtPmsNAVadnlqS::gmrSzNSNqrB(int keBXJg, bool rmFQIhOLoJono, string IQZfmSxAvVoEox)
{
    bool MIfUSCqQaPZniBw = true;
    string BgGpezWqm = string("xAlkCTQsPlWCFvZMUhdVsGvNxqgrUZFffOiOmdzruOGZHOfxwfRMyrEggUTDTadKkwoRCyBahfkbaxDFAoAhhLIxEtiIAHEndFLDBFAyiWUcAnlylmQOtunHhLTKohnnapMhmcmzohVWACpDMIKaiSbkKVgmpMbiMkOtivLcjUTtrHwFmYVmrfGFvCTFFfMqEEusxBhYTGQoLrwrXbagRUfxLYGQPObnkXvLZT");
    double KMWXqCXSwYnHt = -764012.1229760924;
    int HpZvFlWVERQZmJk = -498408141;
    bool GWZGoUPebfKqOKNO = true;
    double cccqR = -274860.4329215074;
    int rwmtfvQddCMOw = 873566515;
    int oQzKOdQlGbtpkD = 59961270;

    for (int YteTBZzjrBJESOy = 1105863356; YteTBZzjrBJESOy > 0; YteTBZzjrBJESOy--) {
        keBXJg = rwmtfvQddCMOw;
    }

    for (int IAxTexoENWnR = 761453222; IAxTexoENWnR > 0; IAxTexoENWnR--) {
        continue;
    }

    return GWZGoUPebfKqOKNO;
}

bool UtPmsNAVadnlqS::QfuFQMGEQlLxkVHU(double EKqyKzkm, bool FQMnvaoOiFtsLhY, int yPGLcotSU, double WiFlKuSErYHfJtw)
{
    int FpVlnmvFBvEXAP = -594720638;
    int aPOuszZxEpFoIy = -1883476195;

    if (aPOuszZxEpFoIy > -1883476195) {
        for (int rXhhleaBXb = 920698648; rXhhleaBXb > 0; rXhhleaBXb--) {
            FpVlnmvFBvEXAP = yPGLcotSU;
            EKqyKzkm -= EKqyKzkm;
            FQMnvaoOiFtsLhY = ! FQMnvaoOiFtsLhY;
            yPGLcotSU *= FpVlnmvFBvEXAP;
        }
    }

    if (FpVlnmvFBvEXAP != -103520585) {
        for (int SkyCh = 1767936161; SkyCh > 0; SkyCh--) {
            yPGLcotSU += aPOuszZxEpFoIy;
        }
    }

    for (int ddJPnNbCUhjl = 1645143451; ddJPnNbCUhjl > 0; ddJPnNbCUhjl--) {
        continue;
    }

    return FQMnvaoOiFtsLhY;
}

double UtPmsNAVadnlqS::jmPWRaLLsjKki()
{
    string WnNWABwnvjIxh = string("ZExYFzxlbVmnQHpOYmOsYQDGnJXlzsWqenpLNSDoSycQdVCgZCevBfFQZyqvTUfpSHSIEmqCTdNgZKywTSLHxOWaoAnEpYORVfbSOcVdSbNxLVdQqdmXd");
    double rzuVVjiGvxIcNY = 964926.609544369;

    if (rzuVVjiGvxIcNY <= 964926.609544369) {
        for (int iohJMjHSuQYoNP = 1080751639; iohJMjHSuQYoNP > 0; iohJMjHSuQYoNP--) {
            WnNWABwnvjIxh = WnNWABwnvjIxh;
        }
    }

    return rzuVVjiGvxIcNY;
}

string UtPmsNAVadnlqS::ZwoWjrS(double CsBqMD, bool DoKKUWCUNR, int eSiMyMlpnkgEFyJc, double PBkfFWgxL)
{
    string AkNZZUUlveTeIpJ = string("TdcAyCxDMQnqiIePAVBYmNqmNSEDVCxAzxSjBypjUXpnVcgbDsxZyoNJBYfYgRodIgQanadNVmfxYRiGBaIaBzsYANcNmpekRXPQqzUQnwtFOyEoeHxzwyRoraWgRwGwUAXqVsLZAASSZNVYkIzpCytIuZBHKMFABoZSzJcaqpQhcLjUDmijDuEKYbxXQMCmEUoREZrvhobzdPkzgLE");
    double plZrJngMMqUMnn = 353557.03054680803;
    int TXnRiyHM = -1287993306;

    for (int zUXQtzzurWKYOAvZ = 1724312776; zUXQtzzurWKYOAvZ > 0; zUXQtzzurWKYOAvZ--) {
        AkNZZUUlveTeIpJ += AkNZZUUlveTeIpJ;
    }

    for (int UsvZxOuA = 1511139090; UsvZxOuA > 0; UsvZxOuA--) {
        PBkfFWgxL += plZrJngMMqUMnn;
    }

    for (int qtNcjZkhi = 878577138; qtNcjZkhi > 0; qtNcjZkhi--) {
        DoKKUWCUNR = DoKKUWCUNR;
        CsBqMD += plZrJngMMqUMnn;
    }

    if (eSiMyMlpnkgEFyJc == -166164426) {
        for (int PXqsCcLRwiECHDkF = 1786736584; PXqsCcLRwiECHDkF > 0; PXqsCcLRwiECHDkF--) {
            continue;
        }
    }

    return AkNZZUUlveTeIpJ;
}

bool UtPmsNAVadnlqS::dfndndQvJKpIy(double KYCLqReTFlFlgW)
{
    bool IEMSyV = true;
    int woAwoXiUSKdFmEA = -1100159126;

    for (int XFcHTyESdxWGMLAV = 1544953010; XFcHTyESdxWGMLAV > 0; XFcHTyESdxWGMLAV--) {
        KYCLqReTFlFlgW += KYCLqReTFlFlgW;
        woAwoXiUSKdFmEA += woAwoXiUSKdFmEA;
        IEMSyV = IEMSyV;
        KYCLqReTFlFlgW *= KYCLqReTFlFlgW;
        KYCLqReTFlFlgW += KYCLqReTFlFlgW;
    }

    return IEMSyV;
}

string UtPmsNAVadnlqS::KFovWvhWqccKXc()
{
    string UHGmFvj = string("ylZggAiKygWJmDXDhBvkWWkwwnJApftYtTgSqVPtqnHabNizMzYSsNzfqZZmRWYspLcwSevDxApbFRIfTLBRpzRNbAOKROpuFvTOqOsryOHRKAVvZAsPXHMSFCUNdpaxFYeQuvouenfJXnOdwurSydSzkFMRGxIEKaSvdueiLHCwUsIijCRwZngpMktxhtLoPwcdYWSTGpSoAuc");
    int sriERCN = 914763819;
    string iSxbCIgTmLTQRR = string("HUrSrFnhtFVpFgelbNPvLFIzxptpUhCATELZaDdNumEZhZJxtWSOxoqbfMZxohCdNnJvdQLTlmpPrzVoXvMNXZAJxclZEwvexCCLYmEqhsgVKIUInnnxQjAofEISlmMhQajFGTaEiqUSNXRToOMnZZuHiHTVEjbKOxxjzZsHoZtXjcuVIIWqlbLjSvorgqYxANwZDfLfPuoJlCKfQVgthjdbVEqXSwvRJzLYqZreYAJCIHliUznyTHKfA");
    bool sePsncBHxlml = false;
    string vXkVrOVJUclOFlbg = string("KSVxskVQNubnYCDgJl");
    double zXIxUKy = 933354.2226627929;
    string EboLEVuzSKjBqE = string("SXksGhtX");
    string QXQXqJCq = string("CKDTqFjWRuFxWPSsFJhdVbsENcwoaYNaLqipFIOChRzVYWcKJPHIqjqxpBFxmeuDVoKfvulcdFpmXnDVTwIwJDXO");

    if (iSxbCIgTmLTQRR != string("HUrSrFnhtFVpFgelbNPvLFIzxptpUhCATELZaDdNumEZhZJxtWSOxoqbfMZxohCdNnJvdQLTlmpPrzVoXvMNXZAJxclZEwvexCCLYmEqhsgVKIUInnnxQjAofEISlmMhQajFGTaEiqUSNXRToOMnZZuHiHTVEjbKOxxjzZsHoZtXjcuVIIWqlbLjSvorgqYxANwZDfLfPuoJlCKfQVgthjdbVEqXSwvRJzLYqZreYAJCIHliUznyTHKfA")) {
        for (int vrwLmubtWJoeaH = 1948173697; vrwLmubtWJoeaH > 0; vrwLmubtWJoeaH--) {
            QXQXqJCq = iSxbCIgTmLTQRR;
            QXQXqJCq += iSxbCIgTmLTQRR;
        }
    }

    for (int YLlddcXSNExjkRNO = 1789297941; YLlddcXSNExjkRNO > 0; YLlddcXSNExjkRNO--) {
        iSxbCIgTmLTQRR = iSxbCIgTmLTQRR;
        zXIxUKy -= zXIxUKy;
        QXQXqJCq = vXkVrOVJUclOFlbg;
    }

    if (EboLEVuzSKjBqE < string("CKDTqFjWRuFxWPSsFJhdVbsENcwoaYNaLqipFIOChRzVYWcKJPHIqjqxpBFxmeuDVoKfvulcdFpmXnDVTwIwJDXO")) {
        for (int HnALMuFlYQqHL = 1003238466; HnALMuFlYQqHL > 0; HnALMuFlYQqHL--) {
            continue;
        }
    }

    if (iSxbCIgTmLTQRR >= string("HUrSrFnhtFVpFgelbNPvLFIzxptpUhCATELZaDdNumEZhZJxtWSOxoqbfMZxohCdNnJvdQLTlmpPrzVoXvMNXZAJxclZEwvexCCLYmEqhsgVKIUInnnxQjAofEISlmMhQajFGTaEiqUSNXRToOMnZZuHiHTVEjbKOxxjzZsHoZtXjcuVIIWqlbLjSvorgqYxANwZDfLfPuoJlCKfQVgthjdbVEqXSwvRJzLYqZreYAJCIHliUznyTHKfA")) {
        for (int alMHPywlP = 1218536862; alMHPywlP > 0; alMHPywlP--) {
            iSxbCIgTmLTQRR += UHGmFvj;
            UHGmFvj += QXQXqJCq;
            QXQXqJCq = QXQXqJCq;
            vXkVrOVJUclOFlbg = UHGmFvj;
        }
    }

    for (int VTeccXt = 1199392962; VTeccXt > 0; VTeccXt--) {
        EboLEVuzSKjBqE += vXkVrOVJUclOFlbg;
    }

    return QXQXqJCq;
}

string UtPmsNAVadnlqS::WCzZYY(int ZOElXfH)
{
    bool urSeNnueZQmqo = false;
    bool vVuQpcZNHwgOQ = true;
    int nrpmmQQL = -1753517311;
    int RFsEgLF = 934240275;
    bool ffwUPkdlPa = true;
    double bBQIde = 252523.33791207432;
    int bqjiHIIVVMC = 1214220016;
    double wwzEzSM = -14785.260187710954;

    if (bqjiHIIVVMC < -780496498) {
        for (int RQgaMPTuGjpSyHNE = 1935256539; RQgaMPTuGjpSyHNE > 0; RQgaMPTuGjpSyHNE--) {
            ZOElXfH += RFsEgLF;
            ZOElXfH = bqjiHIIVVMC;
            RFsEgLF = bqjiHIIVVMC;
        }
    }

    if (ffwUPkdlPa == false) {
        for (int xLYwrlHxyzDEbB = 1165118149; xLYwrlHxyzDEbB > 0; xLYwrlHxyzDEbB--) {
            ffwUPkdlPa = ffwUPkdlPa;
        }
    }

    for (int okxQcgiLsFdiw = 191281898; okxQcgiLsFdiw > 0; okxQcgiLsFdiw--) {
        continue;
    }

    for (int KLfoIrFmEZTvCd = 1937029643; KLfoIrFmEZTvCd > 0; KLfoIrFmEZTvCd--) {
        RFsEgLF *= RFsEgLF;
        nrpmmQQL /= ZOElXfH;
    }

    for (int JAEGCoUZADd = 849545174; JAEGCoUZADd > 0; JAEGCoUZADd--) {
        urSeNnueZQmqo = urSeNnueZQmqo;
        nrpmmQQL *= ZOElXfH;
    }

    for (int cnWKud = 1858785626; cnWKud > 0; cnWKud--) {
        vVuQpcZNHwgOQ = ! urSeNnueZQmqo;
        ZOElXfH *= nrpmmQQL;
        RFsEgLF *= nrpmmQQL;
    }

    for (int tQSznvYyeEKs = 1829443593; tQSznvYyeEKs > 0; tQSznvYyeEKs--) {
        ZOElXfH -= ZOElXfH;
        nrpmmQQL = ZOElXfH;
    }

    for (int alOoMTrKRrrtvDLw = 1389240495; alOoMTrKRrrtvDLw > 0; alOoMTrKRrrtvDLw--) {
        continue;
    }

    return string("LObRfKqKwYgOQcJGtpuNtsqGeiABRYvEPisXCeQGLKPZnHRhQlJajFnRfrwSfilzPmCNniHnmqynjKDFAkcqHelxHSJBNYXPFczzlSODiEvVgTTmODBKKWcZRiyuPDoxtJRiOInCtCtDzuefDBnjdTStvrJZHDKNNLgeKzCLiWwhhYSHVlcHaODKWZsUkzkQwVchXQPxDAUEirWCbwSSHdDyVQUQOZUbQrVqTqxo");
}

int UtPmsNAVadnlqS::kfWoPzNdSccZasfT(int PFUAZtcCSvIaBWmu, bool xDAhCwIGHKtCKun, string OcDCYkzOfUi)
{
    int sJlSxbZcSXjiytT = -1468367816;
    string RvImnT = string("omZtQGvMzXIgmRRSRTJcvLEpWhEBQhDwctrNnanAEjIpRTCqOXUqVWtGmsmUJXXvwIanFJqmiF");
    string kXDSeCNav = string("nvSKEeQIhFhtTtNeRURLrTcrqQRnRAkPBaLnzDlkQdbydmXcgxFbtkVwqkMyYphgJnLpygyhfkklNgNodXbjHZUaxRclANBmGrsAExLzCECpsfE");

    if (sJlSxbZcSXjiytT >= -668789523) {
        for (int wYZsVrKdoFc = 1715510921; wYZsVrKdoFc > 0; wYZsVrKdoFc--) {
            kXDSeCNav += kXDSeCNav;
            kXDSeCNav += kXDSeCNav;
            sJlSxbZcSXjiytT += sJlSxbZcSXjiytT;
        }
    }

    for (int PmaGMpXIZdl = 37003410; PmaGMpXIZdl > 0; PmaGMpXIZdl--) {
        OcDCYkzOfUi = OcDCYkzOfUi;
    }

    return sJlSxbZcSXjiytT;
}

bool UtPmsNAVadnlqS::wovqmoSFNJ(double ErfXtoreTEiyIA, string Dycwjrzjgxrdn)
{
    double xFekSXBBvOjwT = 522130.73236680916;
    string WJeHSytJhUGMyM = string("SuZzeQmLDXrUgWCOLJRjpjNQdJseNMocZtvKiVBigmSMdKpDBevjNteNBXKtCRuyKNuIpASdKiWyVEPQInIXHhLvcFUFbFVEUVzuXlxXpASKoZtqWkATIbdldGNCUovsnDumYxNDsxPANOHGFcMbHPOMLeNwQWoFsyPQ");

    for (int OcSVBEd = 587570874; OcSVBEd > 0; OcSVBEd--) {
        xFekSXBBvOjwT -= ErfXtoreTEiyIA;
        WJeHSytJhUGMyM = WJeHSytJhUGMyM;
        WJeHSytJhUGMyM += Dycwjrzjgxrdn;
        ErfXtoreTEiyIA /= ErfXtoreTEiyIA;
        xFekSXBBvOjwT /= xFekSXBBvOjwT;
        ErfXtoreTEiyIA -= ErfXtoreTEiyIA;
    }

    if (ErfXtoreTEiyIA != 990742.6055715876) {
        for (int fwNHicv = 1442281717; fwNHicv > 0; fwNHicv--) {
            WJeHSytJhUGMyM += WJeHSytJhUGMyM;
            WJeHSytJhUGMyM = Dycwjrzjgxrdn;
        }
    }

    return true;
}

UtPmsNAVadnlqS::UtPmsNAVadnlqS()
{
    this->pXZMqJiJRRv(true, 710480.2282880527, string("jxxsw"));
    this->lMnLJArg(-379093989, string("tHgEalFeIMSmVTFgIDAlAKxieGrPQbdJghzRcRvkygWquuUCgzPOWshWOPtYBYaVaulVvFtIVPocFkiAMgdgTDTgSxuqfKoHjkcITgIvahaPrrYcouipMzJvWucsVebLpPvRIoOzGVJkCvbUunkuTdIsGDWFYAmTjdxWnQxkwLwXMfiuXMzstgyQElIzUWQEmnPcLLknEceIbwCcjKnkoECfyFpkaRpiatLqHvgWGHmFKJPSKnu"));
    this->RKjlE(string("FpHEchEmInpuxnByrZEhAEshiAaVOkpfaKevOBKGdCPMIMLGlGLrvABfGmkXcfbibAVdjsSbmyMVgbxkBhyYAzfKJKTGUYcccaPDulDTNxRbSEtupdmJieRIRJRYqcHhGnWncCqDSlyJdzqssgxAQbljHHZpMMPUBquwiYtqZGczuNaQRjFrskWRZDiQfVDpyuBA"), -1884691655);
    this->tdzulqrKm(-468201.3313523851);
    this->zPtnRZqiom(-771477.8348172125);
    this->xaLhQwzoRQPv(string("DPxuttzWgGijHokKEsVaPkJmPLwvurVvHllPeQZwYqVIVndevIIMJipTqBGXjONlJKjteBXQLSTOkZqLwaSJLZXjcevxldTdsLqRTAWMExdQNasqNpGlXvqUkQQbpGKQpWUgpKWgzyFkOjtswNLKvsBEpyglGMmEPCWcDkQoEZlfPPReltNmxodpplzjPXpIJirULULtLyYnhqiLSKNArmQhkjUMObHUmWroisef"), false);
    this->pMrEQWEklInF(-852113.5473367246, true);
    this->QKlRrcaCKc(false, string("pPwyDEBeaLKeKCkjPZsNiCeiJgFoPSudThrBziNuKTcQNgAFWVocnvbHctMrbtdsGnnWaGmiflYbnGwVcZqAbGVnBIGxmWmxPAlUFNjAbXaIOMjVKwzUwrbgRqVLThOTXeXSZzrAJNHoZmbaxxeNwfeRn"), true);
    this->HlFdkonh(string("DhYqPWwAuBWvgNaUqZbkuokttoFmKFElcjOBwuLUtpYNsiwbtvcreHbFVydDYGBnUNqJouyyzMgKMlIekRJE"), string("cqYiiIVRzTXqITTsDLwDgDAHUpibjAXDbFkigqnVnqfrelbvusHGExesJjbhsqmYGMkRdiCvoRhFhTmdoFpoqnuDxRzgMUuOamGYCzYXQqvsIYubAQYPRlKqXbLAYTXAwtsvnfysILbWQyTrMnAOKVRApG"), 1269152549, string("JUJsYkLTjuZRnlxyQHYTwTrKnFugoiIrvbJGPVljeiDfHcfZPtibsjJoNzJNYnDECloWGpdglmbGPQZYBxLoVzhSanHxdmIkPaYulHnzqiTPUynlAjrFJWEflDlWsilNetUGSwtmBdmnITxQoRgwRrzoIeEogmUHHDcucARlZsWXkPNTJPkYVRxQeBbQBawjAyNBJNpHFuB"), true);
    this->vIFNyqvNFMEbva(-633250.9176409454, 15723.248147375478);
    this->gmrSzNSNqrB(-1409025210, true, string("jmMHBIjZHYQhLOEyecYPlSUnmRqKNuYqlrtfhaYJklnVFPGnPJzAwxQPUWjdRwNjERfpdNjkaEegKevEyOaFuLqsxFuDbnAbuEXljDqgLJBvDAKJPVBdvZGZICUmHKDnALssaGOliXgrTMUqvpYLNonMDnQhuuzloJPJJkGGKzMUgmEabSphGQLZgeRUSkDKRgnwRugBRlWcVUDSmNbIBnCOPGZVbjenzdhkSMAEZdXmLDEf"));
    this->QfuFQMGEQlLxkVHU(-189930.7103817629, true, -103520585, -881373.8731758628);
    this->jmPWRaLLsjKki();
    this->ZwoWjrS(654567.3430326923, true, -166164426, -878028.9416252549);
    this->dfndndQvJKpIy(424743.5320794929);
    this->KFovWvhWqccKXc();
    this->WCzZYY(-780496498);
    this->kfWoPzNdSccZasfT(-668789523, false, string("AQsFlIVHLcWTLKmGpjlnsIjzAWNyJjIduCQgSt"));
    this->wovqmoSFNJ(990742.6055715876, string("evmYeIMpqEITvQhMEtbBHGjFtMWxwAvgRpgzdOOgchKkPphDXgxyzDpMuzveHKQVjSEhUCp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NEiCGnFgDnkOeu
{
public:
    bool niPfSCq;
    double evDAqFyGoiZFY;
    int nikxNVFyLYXnAN;
    bool KeHrZHBqtMNK;
    bool CDEamACqxMC;
    double WUEWo;

    NEiCGnFgDnkOeu();
    string eexZTzdx();
    int GUPOWwKUP(bool QhOQUOxztvZQ, bool IRczVSccJLc);
    string hxNCaaAzUwQWfRjT();
    double LdBYnXVSFZgLm(bool bedWRVNcvN, double HzvqrJFnLtc);
    string ymuqbIez(double awUeQZSmkBiXhzv, bool cgKvNqP, double czNZeBfYJVQAMML);
    string DxEGCVIZEzwbdyiJ(bool KaGCsCWlUUmtHlxS, bool idxSMjjw);
    double BxEjjchmKzxL(double ITNgcifCcLm, string UKsGuCnHi, double fruQpqK, bool SNkIPknpbd);
protected:
    string QWRMcRkLycgfmCu;
    int PiCLyf;
    double zDUgVIgAf;

    void MhKlKB(int wGuBCnwCVFCT, double BYnWGzhwWiESc, double gJJDUpBGgzq, int SQFWZAXyk, bool xfutnqJB);
private:
    double khbMapVEnnpv;
    double GTXWN;
    string yLQcim;
    bool LZJtXLfWlJyauz;
    int QRYoXFp;

    double thttrRbdnfn(string SIefIPOXOkMWgkbf, int nAYPcBpU);
    double FurlMIz();
    void WIUuV(int TjRPYyK);
    int jFTtxOIzjefdK(double UMQtFkU);
    int iYoTzHHtDlke(int nuwDkPNkOutWqN);
    void SlnTRcQzDTR(double dQtePR, bool VSsaJire, string QEkni);
};

string NEiCGnFgDnkOeu::eexZTzdx()
{
    int PihRawOcuzManZjC = 4632974;

    if (PihRawOcuzManZjC == 4632974) {
        for (int jPDxXqP = 699952149; jPDxXqP > 0; jPDxXqP--) {
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
        }
    }

    if (PihRawOcuzManZjC > 4632974) {
        for (int eegMvhuge = 747242539; eegMvhuge > 0; eegMvhuge--) {
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC -= PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC *= PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
        }
    }

    if (PihRawOcuzManZjC == 4632974) {
        for (int pOCOjPWxZJNZUnJ = 643726689; pOCOjPWxZJNZUnJ > 0; pOCOjPWxZJNZUnJ--) {
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC -= PihRawOcuzManZjC;
        }
    }

    if (PihRawOcuzManZjC <= 4632974) {
        for (int xgCHLvhdKe = 2039128243; xgCHLvhdKe > 0; xgCHLvhdKe--) {
            PihRawOcuzManZjC -= PihRawOcuzManZjC;
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC -= PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
        }
    }

    if (PihRawOcuzManZjC == 4632974) {
        for (int ifMbNHQPbEX = 1012709550; ifMbNHQPbEX > 0; ifMbNHQPbEX--) {
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC -= PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC *= PihRawOcuzManZjC;
            PihRawOcuzManZjC *= PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
        }
    }

    if (PihRawOcuzManZjC < 4632974) {
        for (int cxrcvfcZTdRkhU = 473174047; cxrcvfcZTdRkhU > 0; cxrcvfcZTdRkhU--) {
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC /= PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC -= PihRawOcuzManZjC;
        }
    }

    if (PihRawOcuzManZjC >= 4632974) {
        for (int jYpmewzl = 1920973050; jYpmewzl > 0; jYpmewzl--) {
            PihRawOcuzManZjC *= PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC = PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
            PihRawOcuzManZjC += PihRawOcuzManZjC;
        }
    }

    if (PihRawOcuzManZjC == 4632974) {
        for (int AGGEAxZuXqZj = 811125671; AGGEAxZuXqZj > 0; AGGEAxZuXqZj--) {
            PihRawOcuzManZjC -= PihRawOcuzManZjC;
        }
    }

    return string("dgxjOjUliJbZIjkXGMfzBoYTJkTOvRYsERxnNRbzYEhMvhnomXevSnIzUgRiBXtOmHuvayHweBRSKMObFGlwNnZxOyotqWXWrEHSumYtTgSQqitZblpTHDbEHWwvbZegDieSfMOakJsulrPWFecFPZngQTFzfTbNLHiePwuHVtMPGhYgLJHfnmCtnpUh");
}

int NEiCGnFgDnkOeu::GUPOWwKUP(bool QhOQUOxztvZQ, bool IRczVSccJLc)
{
    string ojpKjIyY = string("iBQFhKRKUNpzunWTHVlyKoPoLodAyfmPpxvURVYTCsfyOYzXOXTjscTWeZJvOkGpkovgxUZujaPJxIvRdWDMdHJhZzFKjuhgJYOmwYWiqtmSqqoCCsLJSnpLgJdYiYdxbtYbgHShNORQTljPVKOzdGFIrTvsGVJvlvzN");
    bool pqazAEABUQxKLDim = true;
    int wNxpIozdO = 1888546658;
    int mhaEdrelixdfg = 1774427854;

    if (pqazAEABUQxKLDim == true) {
        for (int JnIrv = 1581369465; JnIrv > 0; JnIrv--) {
            QhOQUOxztvZQ = pqazAEABUQxKLDim;
        }
    }

    if (pqazAEABUQxKLDim != true) {
        for (int mYhNjoCBSnOyt = 1541253240; mYhNjoCBSnOyt > 0; mYhNjoCBSnOyt--) {
            QhOQUOxztvZQ = ! pqazAEABUQxKLDim;
            QhOQUOxztvZQ = pqazAEABUQxKLDim;
            IRczVSccJLc = ! QhOQUOxztvZQ;
            mhaEdrelixdfg -= wNxpIozdO;
        }
    }

    for (int sApEuBJam = 1633360158; sApEuBJam > 0; sApEuBJam--) {
        wNxpIozdO = mhaEdrelixdfg;
    }

    return mhaEdrelixdfg;
}

string NEiCGnFgDnkOeu::hxNCaaAzUwQWfRjT()
{
    double VWpRKJqStHq = 411689.7414905937;
    bool zpFXON = false;
    bool hfQtomrADuR = true;
    double CioiV = -934978.0669273073;

    if (zpFXON == false) {
        for (int WWDFW = 1588996484; WWDFW > 0; WWDFW--) {
            VWpRKJqStHq += VWpRKJqStHq;
            zpFXON = zpFXON;
        }
    }

    return string("qbPxmWHcLhPRkPBxdBWgLlkUbbsfFTDxGaEzqArCvAdMOZGJAYQOIvSwPAEiPAzXFaqTyntkJdAKwjwolGUKdpwrwNMyIIAIaBstFiSyyyvZwOLkZkKmtCbEJMypzswVjFTLWFQZAZABqsjhwAjlPbtOfsYdPyicHhwZPQraPWvshRYvMYKAEOJDIOXxZrpPeRHjYfZPyRiVjxyZDs");
}

double NEiCGnFgDnkOeu::LdBYnXVSFZgLm(bool bedWRVNcvN, double HzvqrJFnLtc)
{
    double rSQPkUoSpdobjv = 873758.707720214;
    string aRDJHz = string("PusWvqGmcTNwqltvSTwfaWNsJUiAOCwYGpdMXNugrRAynjcisbIEREdDkObWUKudPWgLbdlOILnbSBRvpTgtpPbzVoldzAHpEpukqTmrDzVpPysYHkEfZwBYSiqBqrsfAba");
    bool GZNILBbpodbV = false;
    string fBGiSlJgC = string("YeKyvIgZrReXSYSvgXvLsZJXOUisKBjufrGNHojUNllsRjAZYrMArZTYIRoOlxnSPhLFEbbMimoNvoomPaOixNiORCTbsPRRVTNdjBryunlIGSPJfuEMdVNVwngvhPYyzrrWPTFjzaLJoaTWaaKVUBjgDHCdJvPxvaQGgVPzTaHpMhZsYaqFySmvDSTajpmimdLaxSqOuvLusJsUMncgrjQKCVXfKU");
    string lGmloOUCDkm = string("lPMiVVwmfrKtksSmHqrNigIwLPvvhVRNeVSzehdoQWJKVZlLVpCETeINBxtzAjDGDnIXkdepzGxpySEKzIBhKFe");
    int drlFJxaTUhcrf = -1201539155;
    double VxIBF = -1008924.3473846687;
    int axHJdrqennnYrqK = 751653826;
    string NxOhaLtB = string("gDZCnxDxXbvABNarSxXSpmyXOLdGCcgvprYNjgwDjPEQGtzcvIokqnVoMAikgfDisdJwdujdDLZlhcYlOHqHtGGvoyjYQKXWMIRfpyIFSizrZMVuVhdASBOtMQUMRadnAKEIVCJziRZWSFVQXYylqaXMYLcciPgNeqYYrxAqh");

    for (int VwrvvDOZkOe = 217605954; VwrvvDOZkOe > 0; VwrvvDOZkOe--) {
        NxOhaLtB += lGmloOUCDkm;
    }

    if (GZNILBbpodbV != false) {
        for (int ZPbwfgHPZXRin = 693461363; ZPbwfgHPZXRin > 0; ZPbwfgHPZXRin--) {
            continue;
        }
    }

    return VxIBF;
}

string NEiCGnFgDnkOeu::ymuqbIez(double awUeQZSmkBiXhzv, bool cgKvNqP, double czNZeBfYJVQAMML)
{
    string tcssLQwCOSBLTEuQ = string("qbeftLHkufEiROYcIFmHBjoHNimJgjEPEKLRbfxrLrKbZtXIsmmWyUAGwXJSDeTumRqbJMDCOAXVngHgKKfxxGnerqlmtmcVfquulRFWaEWHHzL");
    string XgMyWyGgrjabmb = string("HnbBmb");

    for (int NKMzsRnvybmfOsI = 1054530790; NKMzsRnvybmfOsI > 0; NKMzsRnvybmfOsI--) {
        XgMyWyGgrjabmb += XgMyWyGgrjabmb;
        czNZeBfYJVQAMML /= awUeQZSmkBiXhzv;
    }

    if (cgKvNqP == false) {
        for (int UjQReXZAJMangGK = 912762111; UjQReXZAJMangGK > 0; UjQReXZAJMangGK--) {
            awUeQZSmkBiXhzv *= awUeQZSmkBiXhzv;
            XgMyWyGgrjabmb = XgMyWyGgrjabmb;
        }
    }

    for (int raJDGGTM = 1270422229; raJDGGTM > 0; raJDGGTM--) {
        XgMyWyGgrjabmb += tcssLQwCOSBLTEuQ;
        tcssLQwCOSBLTEuQ = tcssLQwCOSBLTEuQ;
        XgMyWyGgrjabmb += XgMyWyGgrjabmb;
    }

    if (czNZeBfYJVQAMML <= 80472.62709724464) {
        for (int ciClneIhpzZjRvuv = 2032682781; ciClneIhpzZjRvuv > 0; ciClneIhpzZjRvuv--) {
            czNZeBfYJVQAMML -= czNZeBfYJVQAMML;
            awUeQZSmkBiXhzv -= awUeQZSmkBiXhzv;
        }
    }

    if (tcssLQwCOSBLTEuQ >= string("qbeftLHkufEiROYcIFmHBjoHNimJgjEPEKLRbfxrLrKbZtXIsmmWyUAGwXJSDeTumRqbJMDCOAXVngHgKKfxxGnerqlmtmcVfquulRFWaEWHHzL")) {
        for (int VzIOXaTnNneNjX = 2019820583; VzIOXaTnNneNjX > 0; VzIOXaTnNneNjX--) {
            awUeQZSmkBiXhzv += awUeQZSmkBiXhzv;
            XgMyWyGgrjabmb = tcssLQwCOSBLTEuQ;
        }
    }

    return XgMyWyGgrjabmb;
}

string NEiCGnFgDnkOeu::DxEGCVIZEzwbdyiJ(bool KaGCsCWlUUmtHlxS, bool idxSMjjw)
{
    bool EcwXqAQTrbrH = true;
    string wQBmnPhOTWMgGOIT = string("WADaofZPkzXBOztudlRbzSHJqRpyQCzfPuYElKBqSGZllWAdCHPKsVGziEdKJIojckaKkDgBraWBgjkXYgIyEnQWtTYCaMVXRDuvuEoXTOfiRZkDgEDtrwunEKKZBNtTzEoTIMhSFBRusbMOSyIKyQHIvzcvERGsbrmHbSZZpFcYKS");

    for (int CbHngpttTgxPQ = 2139433166; CbHngpttTgxPQ > 0; CbHngpttTgxPQ--) {
        idxSMjjw = KaGCsCWlUUmtHlxS;
        KaGCsCWlUUmtHlxS = ! EcwXqAQTrbrH;
        EcwXqAQTrbrH = ! EcwXqAQTrbrH;
    }

    if (idxSMjjw != true) {
        for (int XSeZjNjlVxAQU = 809613591; XSeZjNjlVxAQU > 0; XSeZjNjlVxAQU--) {
            idxSMjjw = ! idxSMjjw;
            wQBmnPhOTWMgGOIT = wQBmnPhOTWMgGOIT;
            KaGCsCWlUUmtHlxS = idxSMjjw;
            KaGCsCWlUUmtHlxS = ! idxSMjjw;
            idxSMjjw = idxSMjjw;
        }
    }

    if (KaGCsCWlUUmtHlxS != true) {
        for (int qkWXnLFGloSmctQs = 828316041; qkWXnLFGloSmctQs > 0; qkWXnLFGloSmctQs--) {
            KaGCsCWlUUmtHlxS = ! EcwXqAQTrbrH;
            idxSMjjw = EcwXqAQTrbrH;
            wQBmnPhOTWMgGOIT += wQBmnPhOTWMgGOIT;
            idxSMjjw = EcwXqAQTrbrH;
            EcwXqAQTrbrH = ! idxSMjjw;
            KaGCsCWlUUmtHlxS = ! EcwXqAQTrbrH;
        }
    }

    for (int oXijuJQxjEjuFpGO = 49865301; oXijuJQxjEjuFpGO > 0; oXijuJQxjEjuFpGO--) {
        idxSMjjw = ! KaGCsCWlUUmtHlxS;
        idxSMjjw = ! idxSMjjw;
        wQBmnPhOTWMgGOIT += wQBmnPhOTWMgGOIT;
        KaGCsCWlUUmtHlxS = idxSMjjw;
        EcwXqAQTrbrH = ! KaGCsCWlUUmtHlxS;
    }

    if (KaGCsCWlUUmtHlxS != true) {
        for (int RszFePmdYxHuPCg = 1744078835; RszFePmdYxHuPCg > 0; RszFePmdYxHuPCg--) {
            KaGCsCWlUUmtHlxS = KaGCsCWlUUmtHlxS;
            EcwXqAQTrbrH = ! idxSMjjw;
            EcwXqAQTrbrH = KaGCsCWlUUmtHlxS;
            idxSMjjw = ! idxSMjjw;
        }
    }

    return wQBmnPhOTWMgGOIT;
}

double NEiCGnFgDnkOeu::BxEjjchmKzxL(double ITNgcifCcLm, string UKsGuCnHi, double fruQpqK, bool SNkIPknpbd)
{
    double nejAvKOaXUdcacB = 174129.03193260723;
    int HANZPDgKXsd = -933198500;
    double uSeruZwZdmmzTsW = -1003239.7821596105;
    double uHnnIzQrhW = 105559.81872153436;
    double ZprUqWCs = -387107.6140958617;
    double mTbijmuhKZIdcr = -383708.163073912;
    double QfDLBjJdGRroFB = 440012.1438748936;

    if (ITNgcifCcLm <= 174129.03193260723) {
        for (int gNcNw = 1667370452; gNcNw > 0; gNcNw--) {
            uSeruZwZdmmzTsW *= uHnnIzQrhW;
            nejAvKOaXUdcacB += fruQpqK;
            QfDLBjJdGRroFB *= nejAvKOaXUdcacB;
            UKsGuCnHi += UKsGuCnHi;
        }
    }

    if (ITNgcifCcLm > -1003239.7821596105) {
        for (int EIJMRm = 786168365; EIJMRm > 0; EIJMRm--) {
            fruQpqK -= ZprUqWCs;
        }
    }

    if (uSeruZwZdmmzTsW <= -387107.6140958617) {
        for (int WKIavkLhm = 91641615; WKIavkLhm > 0; WKIavkLhm--) {
            QfDLBjJdGRroFB -= ITNgcifCcLm;
            uHnnIzQrhW /= nejAvKOaXUdcacB;
            nejAvKOaXUdcacB -= QfDLBjJdGRroFB;
        }
    }

    return QfDLBjJdGRroFB;
}

void NEiCGnFgDnkOeu::MhKlKB(int wGuBCnwCVFCT, double BYnWGzhwWiESc, double gJJDUpBGgzq, int SQFWZAXyk, bool xfutnqJB)
{
    bool BSvWXmfkyuEn = true;
    bool TRxRcPMttwCESgl = true;
    double Ietnwpf = -833953.45105979;
    double VWDVK = -425083.6944633118;
    int OznNCaQsNAUaD = 2086084429;
    double XjWPFJiWcpWCt = 784837.8261823077;
    string SpCqSWEpyOsqFJ = string("KIMPltQghtsvljpqaecrJlNjwgDwyFaMvIpfsqQBTkYxTYDklsJqjgigYlZLuWoNQKaFXAUGlzJbyWTNwjvaNItjodhXxiRIKYYjKUPhztvDlJFpDJCFGkFUPWLFnNmnujHwWpKRNVFLECDBwYJjFQXQWMltQHplHvVhbrrnxMdFZvNwIhNCQPhlKObMkwWtkjGUJCnxktyNzHTRRguLOahvBSLOABuRmz");
    double pgwFdBR = -693032.5903654295;
    bool tVBiMLVeERphjSOL = true;

    for (int zrttmBImt = 523622067; zrttmBImt > 0; zrttmBImt--) {
        XjWPFJiWcpWCt = BYnWGzhwWiESc;
        BSvWXmfkyuEn = BSvWXmfkyuEn;
        gJJDUpBGgzq *= BYnWGzhwWiESc;
        TRxRcPMttwCESgl = tVBiMLVeERphjSOL;
        BSvWXmfkyuEn = ! BSvWXmfkyuEn;
    }

    for (int dWdEewKbTcEZc = 232157914; dWdEewKbTcEZc > 0; dWdEewKbTcEZc--) {
        continue;
    }
}

double NEiCGnFgDnkOeu::thttrRbdnfn(string SIefIPOXOkMWgkbf, int nAYPcBpU)
{
    int Diydyxfu = 675278781;
    int baLBibdTznlKBOCw = 1307954884;
    int iltgOkC = -1526403145;
    int gGVSZxJWLz = 864349102;
    double wjjpzjLPzgiLUgqU = 741116.8502065307;
    int ftXZFqBbgawmVPiT = -696171962;

    if (nAYPcBpU < 675278781) {
        for (int aIGDZuj = 350733956; aIGDZuj > 0; aIGDZuj--) {
            nAYPcBpU = iltgOkC;
            baLBibdTznlKBOCw *= ftXZFqBbgawmVPiT;
            iltgOkC -= ftXZFqBbgawmVPiT;
            baLBibdTznlKBOCw += ftXZFqBbgawmVPiT;
            gGVSZxJWLz /= iltgOkC;
            ftXZFqBbgawmVPiT -= Diydyxfu;
        }
    }

    return wjjpzjLPzgiLUgqU;
}

double NEiCGnFgDnkOeu::FurlMIz()
{
    double SndJHwfwGnYZAnGj = 998889.2572228283;
    bool Ktegryxitqcsr = false;

    if (SndJHwfwGnYZAnGj < 998889.2572228283) {
        for (int uijoWkHgRW = 1779020270; uijoWkHgRW > 0; uijoWkHgRW--) {
            Ktegryxitqcsr = ! Ktegryxitqcsr;
            SndJHwfwGnYZAnGj = SndJHwfwGnYZAnGj;
        }
    }

    for (int YcxtpAQ = 24093763; YcxtpAQ > 0; YcxtpAQ--) {
        SndJHwfwGnYZAnGj = SndJHwfwGnYZAnGj;
    }

    for (int oBdlIqz = 147392812; oBdlIqz > 0; oBdlIqz--) {
        SndJHwfwGnYZAnGj *= SndJHwfwGnYZAnGj;
        Ktegryxitqcsr = Ktegryxitqcsr;
        SndJHwfwGnYZAnGj /= SndJHwfwGnYZAnGj;
        SndJHwfwGnYZAnGj -= SndJHwfwGnYZAnGj;
    }

    if (SndJHwfwGnYZAnGj > 998889.2572228283) {
        for (int RreVdisOVSCr = 1657364659; RreVdisOVSCr > 0; RreVdisOVSCr--) {
            SndJHwfwGnYZAnGj -= SndJHwfwGnYZAnGj;
            SndJHwfwGnYZAnGj += SndJHwfwGnYZAnGj;
        }
    }

    for (int ZPUaTMzVj = 509425155; ZPUaTMzVj > 0; ZPUaTMzVj--) {
        SndJHwfwGnYZAnGj /= SndJHwfwGnYZAnGj;
        SndJHwfwGnYZAnGj *= SndJHwfwGnYZAnGj;
        SndJHwfwGnYZAnGj *= SndJHwfwGnYZAnGj;
    }

    if (Ktegryxitqcsr != false) {
        for (int XDCEJKqKKODApGgL = 376195297; XDCEJKqKKODApGgL > 0; XDCEJKqKKODApGgL--) {
            Ktegryxitqcsr = ! Ktegryxitqcsr;
            Ktegryxitqcsr = ! Ktegryxitqcsr;
            Ktegryxitqcsr = Ktegryxitqcsr;
        }
    }

    for (int RAKADdAM = 1791679721; RAKADdAM > 0; RAKADdAM--) {
        SndJHwfwGnYZAnGj *= SndJHwfwGnYZAnGj;
    }

    for (int MMbpKSWSaY = 386820674; MMbpKSWSaY > 0; MMbpKSWSaY--) {
        SndJHwfwGnYZAnGj = SndJHwfwGnYZAnGj;
        SndJHwfwGnYZAnGj = SndJHwfwGnYZAnGj;
        Ktegryxitqcsr = ! Ktegryxitqcsr;
    }

    return SndJHwfwGnYZAnGj;
}

void NEiCGnFgDnkOeu::WIUuV(int TjRPYyK)
{
    double XLBCEnt = -53936.33725411317;
    string EzxtxGjmKSJepl = string("iRufHDfizeJdxEtYfeZiWaVrWpszXKnYZGXbqSHHUOrxmIqiHpPHIEVuxyjOlDXYuAvdZxWbwLXPtpvzdkaxJvaLAPaiIFVXhjDWzQfzbTtbPMBZNoYsWibLyupPSNCtqDfHyQjcTqzCABdMCnZgjTMuNzeXxWPfGcGOWwiOwR");
    int qeAcQAvC = -731470577;
    string UDXqzsBvXgAifu = string("bLARSDcQtYIpnQQZtMvYztggNPDVOYlfZizNZbnJAwqVsEpEaUBblvPWqVcUiPUeczHVQhqtBnaqvsHvRIJEgvdErdZOemNOOHiUCZrBsMTguxbETbAxJazFqeIGoLQZurhOYfqpqMHsVTOOIRNJcmWmWMviCvNkVHlIFpHOaBXDZSkwFVaTGcfrOOWZxyMWlhudtvaVMXkvZmltMV");
    string QejUdg = string("RKsAfThVOhaGzELesZMZENIzJYqNXlzMigQUPPMcqVPDhRbifJInmlxWivXfIQmngnFemtaNtgHXafDxarqcWKxUjOKMTylfBebNEhUAlWAqvJlXOBTWjwJeWrFAnhFongtHZJKoDSoQktkvdCXdUFveqqmCDaDfDsradgHDDMUVecqQtQnowCnwcfUBSODxeRAznTzTRvoVoGYP");
    bool BmFbcHuCjJrgUQO = true;

    for (int fOWisnfScrmRvig = 1818389048; fOWisnfScrmRvig > 0; fOWisnfScrmRvig--) {
        XLBCEnt += XLBCEnt;
    }

    for (int NJeThaCKfg = 62825797; NJeThaCKfg > 0; NJeThaCKfg--) {
        continue;
    }

    for (int gLspwDSLLjJGG = 460275598; gLspwDSLLjJGG > 0; gLspwDSLLjJGG--) {
        continue;
    }

    for (int aCuIDILoDURAgdPe = 720488036; aCuIDILoDURAgdPe > 0; aCuIDILoDURAgdPe--) {
        qeAcQAvC += qeAcQAvC;
    }

    for (int OMvamYycWVbhAt = 1657766108; OMvamYycWVbhAt > 0; OMvamYycWVbhAt--) {
        continue;
    }

    if (QejUdg == string("iRufHDfizeJdxEtYfeZiWaVrWpszXKnYZGXbqSHHUOrxmIqiHpPHIEVuxyjOlDXYuAvdZxWbwLXPtpvzdkaxJvaLAPaiIFVXhjDWzQfzbTtbPMBZNoYsWibLyupPSNCtqDfHyQjcTqzCABdMCnZgjTMuNzeXxWPfGcGOWwiOwR")) {
        for (int ABiXBZwlLCyZ = 299257528; ABiXBZwlLCyZ > 0; ABiXBZwlLCyZ--) {
            XLBCEnt = XLBCEnt;
        }
    }

    for (int UsuSdDZUhiTA = 728908536; UsuSdDZUhiTA > 0; UsuSdDZUhiTA--) {
        QejUdg += QejUdg;
        QejUdg = UDXqzsBvXgAifu;
    }
}

int NEiCGnFgDnkOeu::jFTtxOIzjefdK(double UMQtFkU)
{
    int kbxyJfOrwC = 491184371;
    double PgEAdp = -201442.22794635367;
    string qcOTdRyOyhZq = string("KaLHbBcsFTACsXHxKRJwXIbIEsPZfsmkaUpeFUlOZmbWqAJhREgMOXksdOYpDmfEtlsXXeiPgrGLlpeVMQELwNDHtysIzwJAZRlLVCjwjNGGltFRsYanOrnWHciudzSfHdtlovDtyFKxiFZubQOAaMCjgqXmPKXYsTeUxpQiXcQYwqfQDVMdBSbumGNRtBL");
    bool xJqMjqANzwsBKdrg = true;
    int noNOvnobjnzNZ = 1730477436;
    double iTEWIRZ = 1043289.8262900332;
    int YYyIUQZgNcdXdY = 591496049;

    for (int dUMmlPxerJyv = 1413413953; dUMmlPxerJyv > 0; dUMmlPxerJyv--) {
        UMQtFkU /= iTEWIRZ;
    }

    if (YYyIUQZgNcdXdY <= 591496049) {
        for (int oDKklwIY = 232040941; oDKklwIY > 0; oDKklwIY--) {
            UMQtFkU += UMQtFkU;
            UMQtFkU /= UMQtFkU;
            xJqMjqANzwsBKdrg = ! xJqMjqANzwsBKdrg;
            kbxyJfOrwC *= YYyIUQZgNcdXdY;
        }
    }

    return YYyIUQZgNcdXdY;
}

int NEiCGnFgDnkOeu::iYoTzHHtDlke(int nuwDkPNkOutWqN)
{
    int AHTxkbXEkJzcR = 1137598824;
    bool NEdGxpfRNNGIekxG = false;
    int kXiVEOheCKXT = -587369941;
    bool QsGUhkveEHMvQwWL = false;

    for (int ZINsbwNup = 1938884756; ZINsbwNup > 0; ZINsbwNup--) {
        NEdGxpfRNNGIekxG = ! QsGUhkveEHMvQwWL;
        nuwDkPNkOutWqN /= nuwDkPNkOutWqN;
        nuwDkPNkOutWqN -= nuwDkPNkOutWqN;
        nuwDkPNkOutWqN *= nuwDkPNkOutWqN;
    }

    return kXiVEOheCKXT;
}

void NEiCGnFgDnkOeu::SlnTRcQzDTR(double dQtePR, bool VSsaJire, string QEkni)
{
    double AczWhz = 275171.2826652235;
    bool NLAmsTHrwusVutOH = true;
    string FkrYUl = string("nHaRCcGezZyjBFqXDedrgOmJeWDPnAIuZRIOQNWdKwpmGrEUEqvQzfOgrQtXXoQUoGDiLPhPAWoVCPKFmRcxmUxghqNYFJXbkuLisjGQWQrIFzvjgqqPrwMcWhWQEHWgxZgzzGJjOSFinuIyfKtCjAIXZmrFYMTrCoKxKKExuNKGXMKlulKKFSTgbsDQAEEcIIUZtcFYTiZOjiuykFUiwYgCGMn");
    bool NGjnEeqQF = false;
    double JZkqJmWVi = -54654.92008320095;
    string kmEQRIFbHqscwQDe = string("DkXGsayRQMBdHRZJafjBSVsQPDt");
    double tElLEXcVzfRpe = -334337.7004131712;
    int zcdGMHuD = -122670247;
    bool DoZcQDPUEVDDYEA = false;

    for (int NPXtIQsFHv = 193712820; NPXtIQsFHv > 0; NPXtIQsFHv--) {
        AczWhz += JZkqJmWVi;
        dQtePR -= AczWhz;
        dQtePR -= JZkqJmWVi;
        zcdGMHuD *= zcdGMHuD;
    }

    for (int DkLvSOgLWW = 1559076521; DkLvSOgLWW > 0; DkLvSOgLWW--) {
        continue;
    }

    for (int UOCgOcDFXKPnF = 1331468221; UOCgOcDFXKPnF > 0; UOCgOcDFXKPnF--) {
        tElLEXcVzfRpe -= JZkqJmWVi;
        AczWhz *= AczWhz;
    }
}

NEiCGnFgDnkOeu::NEiCGnFgDnkOeu()
{
    this->eexZTzdx();
    this->GUPOWwKUP(true, true);
    this->hxNCaaAzUwQWfRjT();
    this->LdBYnXVSFZgLm(false, 872545.133959819);
    this->ymuqbIez(80472.62709724464, false, -264254.4946767197);
    this->DxEGCVIZEzwbdyiJ(false, true);
    this->BxEjjchmKzxL(603414.0883259728, string("vwMnIIFqI"), 94184.10842614244, false);
    this->MhKlKB(-775049068, -128160.12772315695, 341319.72957832535, -656708739, true);
    this->thttrRbdnfn(string("TltwEvIEavhjtwLTfPCCJGhbntGfXJNMaxPKukixWSzGdWBEXqPRLXZqKlbWSdBcFrMKcGjJdTGNzUCIqqcohwAagf"), 923738555);
    this->FurlMIz();
    this->WIUuV(-1756949743);
    this->jFTtxOIzjefdK(920056.5687122617);
    this->iYoTzHHtDlke(-2038168200);
    this->SlnTRcQzDTR(-29174.622764860596, true, string("xiDvrpRWqLfTYrYiBYOvnCFrXzpHtypFdpPDEgWdHkDLpW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gIBIDy
{
public:
    double luDsUO;

    gIBIDy();
    bool WxkiPWTBvRblhse(string rESNMuUvmcTc, bool vUZnEGEnHh, int MNJuUWkgliUQRZ, double dQlUvPx, double tOyohKY);
    double bpUYz(string HFZubVbtshIPVFMs, int gKTHkkZ);
    bool toAPUeD(string OtgQCOFejJKfNKt, int lJkWTUVNTW);
protected:
    double hoYqnHGDUmBuIQTF;
    double YvHxEH;
    int XkhSygccaskyVDym;
    double zoZnxtUsOpLXc;
    string LOoxoKdP;

    bool zXdVIqZvh();
    string yKlHgmxAVWIrCzZp();
    void cXabxQPixB(string oYgkdZbyh, double aaUiU);
    bool kSNMsffBJtU();
private:
    string ZWVKzvpXkqlfDD;
    int OhdunPbpc;
    int hlvcffTcYqedV;
    double JKiIdoKokAO;

    double OEPEjZwbWslr(double SHQmmfitHtSmPY, double heVsCkFFBbTNuV, double ooaEznKDXZP, double iVuzMtUdg, int hDZJSkLK);
    string KJydzNodaipdajR(string HcezBvnB, string AtlpHjLr, int PZDzjxF, bool GyPxIJsCDTKt, double irxBOVva);
    bool edByqPGaVNDhNDj(string HfYavSZQlIgzwrKd, string tLOMLIglrYDWTh, bool YeauNcNyAEx);
};

bool gIBIDy::WxkiPWTBvRblhse(string rESNMuUvmcTc, bool vUZnEGEnHh, int MNJuUWkgliUQRZ, double dQlUvPx, double tOyohKY)
{
    bool YzVSNFswG = true;

    for (int rVXUIOpJ = 1132769843; rVXUIOpJ > 0; rVXUIOpJ--) {
        dQlUvPx -= tOyohKY;
        vUZnEGEnHh = vUZnEGEnHh;
        MNJuUWkgliUQRZ = MNJuUWkgliUQRZ;
    }

    for (int lpncDChdNgQfPab = 1356503546; lpncDChdNgQfPab > 0; lpncDChdNgQfPab--) {
        continue;
    }

    for (int EDeuplytSluj = 974419923; EDeuplytSluj > 0; EDeuplytSluj--) {
        continue;
    }

    for (int ioDzgkMlFbrAYF = 2079068504; ioDzgkMlFbrAYF > 0; ioDzgkMlFbrAYF--) {
        continue;
    }

    for (int EkHvPiYpSOkplu = 1554125286; EkHvPiYpSOkplu > 0; EkHvPiYpSOkplu--) {
        tOyohKY *= dQlUvPx;
    }

    for (int cXHizwyGHiN = 1839449564; cXHizwyGHiN > 0; cXHizwyGHiN--) {
        tOyohKY *= dQlUvPx;
        tOyohKY -= tOyohKY;
        YzVSNFswG = ! YzVSNFswG;
        YzVSNFswG = ! YzVSNFswG;
    }

    return YzVSNFswG;
}

double gIBIDy::bpUYz(string HFZubVbtshIPVFMs, int gKTHkkZ)
{
    double DaCwbRkLbPIvAGZ = -620526.4468413581;
    double mcNyV = 411302.38979103137;
    bool ipEwJVXknzjQsyD = false;
    string PHpntYyTcozXPFB = string("FRzgSckdkcVXPVFpklGbTkNSHZEpRmZi");
    string YUBjrGcCiPiUsJ = string("EJcgHCmvmpmapJrrsZjxbuKfSBzBYHNkfCBOilleqguTYSWBROHSNMKADyqacPUrLhdhiJvrtVZzhLaueEzjyuHBPVTOveeVlETCCwXIuGmttnmWVMyyrBBxdGJQX");
    int cJNPUfv = 636460081;
    bool JAmRcy = true;
    double OQWeXqAogS = 127733.47196613863;

    for (int VCIPkTvqNomfMTc = 361152683; VCIPkTvqNomfMTc > 0; VCIPkTvqNomfMTc--) {
        DaCwbRkLbPIvAGZ *= DaCwbRkLbPIvAGZ;
        mcNyV += DaCwbRkLbPIvAGZ;
    }

    if (JAmRcy != false) {
        for (int MlOyGmsQL = 165730926; MlOyGmsQL > 0; MlOyGmsQL--) {
            ipEwJVXknzjQsyD = JAmRcy;
        }
    }

    for (int YGGRxizXUxCLhdhe = 1838428164; YGGRxizXUxCLhdhe > 0; YGGRxizXUxCLhdhe--) {
        YUBjrGcCiPiUsJ += YUBjrGcCiPiUsJ;
    }

    return OQWeXqAogS;
}

bool gIBIDy::toAPUeD(string OtgQCOFejJKfNKt, int lJkWTUVNTW)
{
    double KiLRTdLbPxZ = -920566.2894912763;
    int sVGdoTNZPNUuzOhW = 209859087;
    bool GdxXKNXl = false;
    string rmlGFwfKjGgbHF = string("bdZxeeomduJePUtEHNngPRvwHkkhZMHPXhOacSBawPRsfnciDGbABkwiYVlTjDsJqivnysdpljXkgCVMvvNFlZcmMjXvbyBijQLkLFEesNSWijDJLWmdVwoFQjgUovnBhMAQUFKeVNAivCqFGUdkcKLHxkFxvGOPLTVjpBQelAdziHrSyWukjmuSilXmVtbnMrOCVpiZVuqQxkxAxDGAzTTRtIheSFliPZEjVDRekBzsHyoViGNUsz");
    bool KvFmDBbO = true;
    bool BfMtcvHTI = true;

    for (int rVBLNtRJB = 1689503325; rVBLNtRJB > 0; rVBLNtRJB--) {
        BfMtcvHTI = KvFmDBbO;
        sVGdoTNZPNUuzOhW *= sVGdoTNZPNUuzOhW;
        GdxXKNXl = ! GdxXKNXl;
        BfMtcvHTI = ! KvFmDBbO;
    }

    return BfMtcvHTI;
}

bool gIBIDy::zXdVIqZvh()
{
    string XqZabpDVueu = string("OtsTGkeiVYbHDGsDtKmNGYuNBhXWSiNvAGdvowHQMiAbjenbXXAFYVcRhKiQNNMojmXqMWqkzlrrGZSRkfraRDVjjEgjweMKuFqCczdcSGVWNgOlawqoWvltDVosvXqc");
    double VkpIVCxvaarvn = -601788.6886639013;
    string zwILyBhC = string("NXuhGIgucGEbXkXqcXpSwLEXxGkDohiplIVAfpOSoZOUiUFFrYPBumPxDQRuBtZwRmQaPnCAaGTyppLtxwMRzshQavviqDiewmezmuJlwyRYekkRDzRveoxWOjqhjyyaeHZiVVHbFnVMXuXUgZPGKAWNkFEMpiORDkrirjqCBSuaLXoo");
    bool nteSftgvBFK = false;
    int hqJCGcya = -110254822;
    bool ZTvXEKMOQag = false;

    if (ZTvXEKMOQag != false) {
        for (int RzRuca = 1202669452; RzRuca > 0; RzRuca--) {
            continue;
        }
    }

    for (int scoOdOWhP = 380038985; scoOdOWhP > 0; scoOdOWhP--) {
        nteSftgvBFK = ! nteSftgvBFK;
        zwILyBhC = XqZabpDVueu;
    }

    for (int OsfUvTkx = 1348609846; OsfUvTkx > 0; OsfUvTkx--) {
        hqJCGcya *= hqJCGcya;
        XqZabpDVueu += zwILyBhC;
    }

    for (int Syffqwg = 926759030; Syffqwg > 0; Syffqwg--) {
        XqZabpDVueu += zwILyBhC;
    }

    return ZTvXEKMOQag;
}

string gIBIDy::yKlHgmxAVWIrCzZp()
{
    double odcOys = 1010928.7211565716;
    bool nwFrevtUVKOG = true;
    string QhlLEPvTYCAGodvq = string("XjVxopCoMnUEoIUqWNQcucLaKZneaNFzVeZruWXUYAKmcLXDWoPuJrARhAAIFQJPgGcNfgjFhODldNotthxFsMDbRfUcjbKSCbDN");
    string gmVwPcpAD = string("bJSDeLFHJlwPDvtxsGypstOyypWddVesynPKrNcvwnlthZCmcHKgXKDrmkhvzkSgpTSPnCcJGQQXEnVjVGVRjbUkcWHRhzEhpwcZnBiKeyXktqmVcUCUHExMQMAkMXizSPRtFCNyDcoiighgtjLoKnGRbEplGsKejZJzHTflaFsMVnGfBGlaq");
    string SsaSB = string("ZfXTW");
    double gFuhTJNrKDVH = -1009100.7765432335;
    string yVOwHVQmjA = string("UrVtrgKkSpeBuZdvWMexoBhnQpqRgzNjrOKQQAyagtfYeUVIepcEsljtjCAGcicMXqYsvaDHoPyxPbztSLUFCgnTrTfQoprMdLepJJJFFACLCsHLrejSRiuh");
    double PNbVgsPmOmfsqb = 666712.7092070879;
    bool qlXRHEey = false;

    for (int PbbTYnEEPdtuhkIR = 801275375; PbbTYnEEPdtuhkIR > 0; PbbTYnEEPdtuhkIR--) {
        SsaSB = SsaSB;
    }

    return yVOwHVQmjA;
}

void gIBIDy::cXabxQPixB(string oYgkdZbyh, double aaUiU)
{
    double rbRpmIJOVeWf = 838531.476519009;
    string pyYBkK = string("bLThrKMxQVAqBNnatVlBQQZOVcNmbEhGNfhbmkszdOcXtGoucaEQviHyMjVeugnVnHyyHpuQkIsbBSFpOUSNbxUPpZfamNcwYVyBkb");
    int BSuFMgRFA = -657485455;
    int ZdbYxt = -957528329;
    bool WDHLyeys = true;

    if (ZdbYxt == -957528329) {
        for (int BbIaisCu = 1015510080; BbIaisCu > 0; BbIaisCu--) {
            rbRpmIJOVeWf /= rbRpmIJOVeWf;
            BSuFMgRFA *= ZdbYxt;
            ZdbYxt /= BSuFMgRFA;
            ZdbYxt = BSuFMgRFA;
        }
    }

    if (oYgkdZbyh > string("bLThrKMxQVAqBNnatVlBQQZOVcNmbEhGNfhbmkszdOcXtGoucaEQviHyMjVeugnVnHyyHpuQkIsbBSFpOUSNbxUPpZfamNcwYVyBkb")) {
        for (int IXBuSCpoJMCuePjr = 1568063612; IXBuSCpoJMCuePjr > 0; IXBuSCpoJMCuePjr--) {
            rbRpmIJOVeWf /= rbRpmIJOVeWf;
        }
    }

    for (int CzOxm = 1145232986; CzOxm > 0; CzOxm--) {
        ZdbYxt += BSuFMgRFA;
    }
}

bool gIBIDy::kSNMsffBJtU()
{
    double tOzipMdQtLfVOiP = 622633.1472106547;
    int uYDfR = -1142182375;
    bool nFKqBJvYnfsWL = false;
    bool CFOHMd = true;
    double FjpXoea = 996806.608524867;
    string FISvgaG = string("AyjMnFwzmjhbRpcCWIyqFXqibpOjhzRHzTWsvtYkbsGrzhFtlVyTegxUOHgaRPMTpTWgEIzcGMpENOWTJDyfPesFyKGJOToYnvLTBFtpBlTDDyUSgVAbbEAJCcGOSijqeWFQfYQcIFoYdQBRwuiBbvVyOjIdyRFpuKcaYstRHWMwNVBTwEOBxirtUbNjznljWNlTmzWRxMwceEYPoHHxSSHJZveDdVytNiCJNxjgRhxvRfwJp");
    double bFpTELCblIM = -256857.72818313894;
    double bREbBrEsAjTMAmLL = 966853.2398637013;

    if (bREbBrEsAjTMAmLL >= 622633.1472106547) {
        for (int RjooJ = 771705241; RjooJ > 0; RjooJ--) {
            tOzipMdQtLfVOiP -= FjpXoea;
            CFOHMd = CFOHMd;
            bREbBrEsAjTMAmLL *= bFpTELCblIM;
            bFpTELCblIM *= FjpXoea;
            bFpTELCblIM = FjpXoea;
        }
    }

    for (int GaSKGUPDePJaXnxp = 896660964; GaSKGUPDePJaXnxp > 0; GaSKGUPDePJaXnxp--) {
        bREbBrEsAjTMAmLL -= bFpTELCblIM;
        tOzipMdQtLfVOiP /= tOzipMdQtLfVOiP;
    }

    for (int wFjrC = 1230129179; wFjrC > 0; wFjrC--) {
        uYDfR /= uYDfR;
        CFOHMd = nFKqBJvYnfsWL;
    }

    return CFOHMd;
}

double gIBIDy::OEPEjZwbWslr(double SHQmmfitHtSmPY, double heVsCkFFBbTNuV, double ooaEznKDXZP, double iVuzMtUdg, int hDZJSkLK)
{
    bool sBetpljd = false;
    double iNSbrAshsjT = 832303.2153294563;
    double PShnSmXIQROOgiPD = 926268.3605019815;
    int nutmv = 217440132;
    int FHdlHdZxmCcjAqDJ = 979466187;
    double wBpGVUcBRfE = -271144.82606127183;

    return wBpGVUcBRfE;
}

string gIBIDy::KJydzNodaipdajR(string HcezBvnB, string AtlpHjLr, int PZDzjxF, bool GyPxIJsCDTKt, double irxBOVva)
{
    bool rNbumC = true;
    double kTDCem = -563505.2632130034;

    if (kTDCem <= -563505.2632130034) {
        for (int PwXjHMrfJS = 1944504044; PwXjHMrfJS > 0; PwXjHMrfJS--) {
            AtlpHjLr = AtlpHjLr;
        }
    }

    for (int XXAMVZnAQ = 1560215795; XXAMVZnAQ > 0; XXAMVZnAQ--) {
        rNbumC = GyPxIJsCDTKt;
    }

    for (int ECdoWI = 716442706; ECdoWI > 0; ECdoWI--) {
        irxBOVva *= kTDCem;
        kTDCem /= kTDCem;
    }

    if (kTDCem == 246924.5910367017) {
        for (int DJeBdlwZy = 1346777356; DJeBdlwZy > 0; DJeBdlwZy--) {
            irxBOVva += kTDCem;
        }
    }

    for (int GncSjubUCBzum = 129958357; GncSjubUCBzum > 0; GncSjubUCBzum--) {
        kTDCem *= irxBOVva;
        AtlpHjLr += HcezBvnB;
    }

    return AtlpHjLr;
}

bool gIBIDy::edByqPGaVNDhNDj(string HfYavSZQlIgzwrKd, string tLOMLIglrYDWTh, bool YeauNcNyAEx)
{
    string PybUDdKWvWVbii = string("cPmmbwwBXVFVBLnWBkbFOkrxHGbIoCroeStZuodZxPneUIPsvCld");
    double kYnmKzQkfcQAcBw = -222028.38203319308;

    if (PybUDdKWvWVbii >= string("oAqyOZOGgjcSthNEwibsQOFuEgaxbpMIDrScEkpJSLOcNGoWQsjmsVjuMvrPPkQqPTeDSVKavghCwKtzJbMdwhRCwpoWyMtSfwdtnZCFQRCCBSJBmWoLQNFySnIbVtvBXPBjTgPkuVjmmFEPFrPGAWyLdJlCRKSKRpbQPCfmZMEqolGGwpaUdKwwNTctIFjtVaPcItZVHGKmUUUVYuESfWGRGUfzBScHIOyzDzvy")) {
        for (int uBmOIDmVfarht = 107569245; uBmOIDmVfarht > 0; uBmOIDmVfarht--) {
            HfYavSZQlIgzwrKd = HfYavSZQlIgzwrKd;
            kYnmKzQkfcQAcBw -= kYnmKzQkfcQAcBw;
            PybUDdKWvWVbii = tLOMLIglrYDWTh;
        }
    }

    for (int ROXfLX = 1814511803; ROXfLX > 0; ROXfLX--) {
        PybUDdKWvWVbii = HfYavSZQlIgzwrKd;
        PybUDdKWvWVbii = tLOMLIglrYDWTh;
        PybUDdKWvWVbii = HfYavSZQlIgzwrKd;
        PybUDdKWvWVbii = tLOMLIglrYDWTh;
    }

    return YeauNcNyAEx;
}

gIBIDy::gIBIDy()
{
    this->WxkiPWTBvRblhse(string("lNeuBMtHLxPXIYhsDbonXWjOvNWkPtpoKyJUeAfqxHQjoBQxOXvNvEaEGHrDmzlfbjotIBFvediSVIcSvWhWLYZuMQhGAuKOfQGIwRHrFGFhkTALefaFOzsAxBVmfUStTRpvCwXALLfrrOybu"), true, 1560136210, -413244.48925639276, -660447.6064253666);
    this->bpUYz(string("qGeDAelsyLSyvQySBPyifazLJlStfUdlHNkNdPTvXTFbZoVpCjyywpKrIvuisUBXASXqxBiJNFjIXCiZHkjzhWnFtcXQvLAxqTXgvbBCVqNCVgsHPPVjwfHtgpiQcegttv"), -1694629489);
    this->toAPUeD(string("gldgqOCiPZMPjwuVmstXBgaHZooKAsPLbCYhnyaAxtGDFnpAGBWvNaXxSZlCwZmLGrSFtGIQEqVjQJGxoEyjYjsfjMJTPSSCgwAZvaBEAVVWfWuUYdWUHJKLuQuzcpmRunMwUuUVhjcBQKQoHgBlQtbvm"), 1228086673);
    this->zXdVIqZvh();
    this->yKlHgmxAVWIrCzZp();
    this->cXabxQPixB(string("VLjFvepcqnIRhEydOJZUBzUDueSTSELwTUrcXMQCOCupMQ"), -412332.1533367424);
    this->kSNMsffBJtU();
    this->OEPEjZwbWslr(-111431.3351741721, 507408.83153663034, -109958.78413353878, 12212.613108966303, 1914275733);
    this->KJydzNodaipdajR(string("lgvoCuYyJTtLlEzMgKgJMMtMyiyuSLtnngGQPQrsXcpxcrdbjdBCZviJbHBVIDVfnOOQRIeONmHCmHtnTkMUAWTTGHBGxOLTLQsTZeEgahHhQrKPcSqVwLGSZaHtGsqUMiSePbhvWRKumhZelgfFpOjjIGsgvftwnzwsADWecwkLPzLvdfrGodtzhDKGyFwSDkkz"), string("phslYShNiwzCATbhLYfJsvGbTehKpolGidPzLKLtBsEqNRztJJqRhVVOshVVAYrqJeWErfuXZQXSfzHKcSrUjppPzTLzwZnikhxoUGUW"), -1732169116, true, 246924.5910367017);
    this->edByqPGaVNDhNDj(string("oAqyOZOGgjcSthNEwibsQOFuEgaxbpMIDrScEkpJSLOcNGoWQsjmsVjuMvrPPkQqPTeDSVKavghCwKtzJbMdwhRCwpoWyMtSfwdtnZCFQRCCBSJBmWoLQNFySnIbVtvBXPBjTgPkuVjmmFEPFrPGAWyLdJlCRKSKRpbQPCfmZMEqolGGwpaUdKwwNTctIFjtVaPcItZVHGKmUUUVYuESfWGRGUfzBScHIOyzDzvy"), string("wECZXKNWnyabpDjRZSqQ"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aeYkBh
{
public:
    bool iyqzHHKERdm;
    int oetrRKVsgOrlVE;

    aeYkBh();
    void pihXpEDNFSy(int vykDlRcS, int hAQYm, bool CGLLKkazqkWzn, int zOdHGMBkJo);
    bool yWZUMtXcdlRKpk(double hmksxDf, bool DJzFTmUOLFhuLU, bool nCzGum);
    int rrQixQe();
    double mXeIxHIlUgsBh(double waLJTaZCZdI, int aFKdpWs, double koiKfZFqRZCsNC, bool eISbwd, int ZReLENjadvmi);
    void phmoMZCXePkZiNn(bool GxUoN);
    string GItrMJiYWNUJ(int AyVmXnNvWnYE, int YKCHdLg);
    bool WRiokjrYydzJgJz(string vVviNshqr, int FUmNvemMMo, bool MAMVvaC, int phGSQJcIpf);
    string hwrhfqUEsN();
protected:
    double QQNskbKyaSSvt;
    double viItcN;
    bool ftWkOHmV;
    int RxeMUaR;

    int xXnCLJSadYtw(int mQRHEwXbLhelj, int bnbauPfOXXtCKr, string VKygpczpwXtjRU);
    string exzAQ(bool xmifIoIyn, int HNTah, bool TGDoWvzzOSCvuRH);
private:
    bool ZMgFSZwVK;
    string peXzuc;
    string uNNmMHeVtDTnHG;
    int vCptHToP;
    string ZtmWskkTW;

    bool WUjpwLXoCIUCwevg(double byAEeGRTyEyzD, double wobTQE, string oyBpQ, double cuxqVaQJbV);
    int GSOdntIHD(int kbjVIPrCU, double jKtMoOtzE, double vsMvlxNWG, int NcLPDj);
    void AVsJlaPAhthuJmn(string XzRJJEbnAjj, string zGeqin, int ZuYoatLbfyvHVTXU, double PeOAzeI, string hUbccIpwM);
};

void aeYkBh::pihXpEDNFSy(int vykDlRcS, int hAQYm, bool CGLLKkazqkWzn, int zOdHGMBkJo)
{
    string ZysADqpgkCRfMZ = string("uHlvWwgUIHaEBrIlBezZMMpMFIwBdMHmxlSBOknwyAlxauZSikMNsaFXRfNeliPmsCnQHuGAICPopAmnbUbVHwrEtrlXiZXrhuYNjeMPMgKaBCzHXDfUwAlAxXfahMGcBxw");
    double FCyrITZiy = 987626.7264030271;
    bool zeWZC = false;
    double kcfDglrSOlWF = 658314.227864689;
    double JRJHeLLics = -730837.9312218954;
    string ysNqkS = string("ZgZPBRvuPxzlUyiaFVXYsvaPSkhnOeyTSiXqobGOxRKhBsEbielCfHfAzoEzSEywrxwpaIfyXUNxAmKOswuDdRLCgYSXMZohE");
    string dcvRZNtNOqsUQU = string("TTIPjbqlREzZLRJZmvUKsGlYgXLPnrUMMJwvZCibIZkCdMPlLaUrWbcvqwaSmXqUdGpdvVbDmYDnkbpOjYUuPMmeruGLzTbqIDEavDdnCEwMvZtODvpTyApRlLOnvOIuGJuawJRVlDgZNfBtmqGvRBtiUZsTThkFBYVaXVXFluGJMPIxUrPNJhaigFOPHniKHFwbPpwsDl");
    string HisxtfvDhgNVjQ = string("SJxLiztJpDHNHEWzeZfrXYWgDRXYgBNRSYRCZAZxNPIDoYfQxtO");
    bool vAlaZ = false;
    double grCGwcoYzOr = -688491.1766341231;

    for (int NPIrFGEihon = 869404470; NPIrFGEihon > 0; NPIrFGEihon--) {
        FCyrITZiy *= grCGwcoYzOr;
    }

    for (int cGvMCjlUNI = 717826612; cGvMCjlUNI > 0; cGvMCjlUNI--) {
        zOdHGMBkJo /= vykDlRcS;
    }

    if (kcfDglrSOlWF >= -730837.9312218954) {
        for (int eHKIU = 1355375856; eHKIU > 0; eHKIU--) {
            continue;
        }
    }

    for (int DHXQkfLIAFsHCYC = 743156950; DHXQkfLIAFsHCYC > 0; DHXQkfLIAFsHCYC--) {
        kcfDglrSOlWF *= kcfDglrSOlWF;
    }
}

bool aeYkBh::yWZUMtXcdlRKpk(double hmksxDf, bool DJzFTmUOLFhuLU, bool nCzGum)
{
    int gXPPFxinPXYUwhk = 742900408;
    double AfOhHMfmgt = -429087.1233249716;
    int wScGUoxD = 488616185;
    double ZtVbBBwNpn = 82349.05140449062;

    if (ZtVbBBwNpn < -776767.0692978366) {
        for (int MBcNDIHbU = 506480695; MBcNDIHbU > 0; MBcNDIHbU--) {
            AfOhHMfmgt *= ZtVbBBwNpn;
        }
    }

    return nCzGum;
}

int aeYkBh::rrQixQe()
{
    bool VblGcTzAOUBbEHsz = true;
    double ZuYKcPXGKwn = 973868.1303530354;
    bool fJneREVY = false;

    if (fJneREVY != false) {
        for (int YRlAgAwfnD = 966518762; YRlAgAwfnD > 0; YRlAgAwfnD--) {
            fJneREVY = ! VblGcTzAOUBbEHsz;
            fJneREVY = VblGcTzAOUBbEHsz;
            VblGcTzAOUBbEHsz = ! fJneREVY;
            ZuYKcPXGKwn /= ZuYKcPXGKwn;
            fJneREVY = ! VblGcTzAOUBbEHsz;
            VblGcTzAOUBbEHsz = VblGcTzAOUBbEHsz;
        }
    }

    return 405572123;
}

double aeYkBh::mXeIxHIlUgsBh(double waLJTaZCZdI, int aFKdpWs, double koiKfZFqRZCsNC, bool eISbwd, int ZReLENjadvmi)
{
    bool uejZtRNKecCfkLzp = false;
    int VJgrmmodHaglFov = -1162552707;
    string mbAeRmCQ = string("VfDkdPxTLKzBrsCdCJjQXvMYeyvpiaKmyRnOpejZUBthdXhIoOWHyyrEUjvKoXWOKlHTYfPUChhuXvwcdhwsrjhIJGVEbcrcvGlMPsyQgztXfWQWbZnNGtMbIZFtcuBfYMFhwSVXESfMcaLbgpdlFDXekBZbJAsilFypVSLDPhyMbDJMlJEROdWnvfPseaSXBAKGzjgiwccFcMdIkfOrHsLzHrMeBTTwtMozNbloIEAqQlkB");
    string aHMWoMVKZsAlo = string("JXPsmIGNphTlXmXOJkxxiPHHOxuMRxWNzVQFblMHjQHUSUUcqAjcq");

    for (int kpKXaIutssCdf = 286189559; kpKXaIutssCdf > 0; kpKXaIutssCdf--) {
        continue;
    }

    for (int JbEnqRFB = 1954882252; JbEnqRFB > 0; JbEnqRFB--) {
        continue;
    }

    for (int uTsgob = 1405055751; uTsgob > 0; uTsgob--) {
        continue;
    }

    if (aFKdpWs >= -833187224) {
        for (int zUMIyv = 154524356; zUMIyv > 0; zUMIyv--) {
            aFKdpWs /= VJgrmmodHaglFov;
        }
    }

    return koiKfZFqRZCsNC;
}

void aeYkBh::phmoMZCXePkZiNn(bool GxUoN)
{
    int vsImSpbwzQPDrCo = -637645367;
}

string aeYkBh::GItrMJiYWNUJ(int AyVmXnNvWnYE, int YKCHdLg)
{
    double XJUJJ = -978621.5968525236;
    string zBODB = string("sPxSQjPMQOszcgJjsGmpLlZXdkEoJidFGomvsVxpdfOvJcnmJFpTcJkESnEhMtnezWYtREkEnRDFElhFsoj");
    string RLREKWXrsMydmz = string("rpFZFWNyDDqOvUxzPtFjhqbDUDSlqfhGtVdtPdStGaJwQUhvHcdASEsvExnckRtpCVKMCvKUPwqVCxhqclYClUptNnPopOZSKwZcMkCpRxiwtxIzOBmzUWmKjGRFXLUvCKm");
    double MNuWsbz = -583214.6952322319;
    string OBgBzHYbRU = string("JuIguVqlOgAcvIsgeKoRyhUrRzvzkwmtQJMgFfhjjHSXplOvSXlupGDKCAyHlduvmqyXOUzNIPwNvfonlRczTMjOQCYpSCrvKVFFfLijoABNRxBbzekFgkWuMfIijMSNOGfvEGaehVNFgvkVzfVHOqYpzJXvHEQMhFMDHpxhoOyzxxMctrlxnNpeQjlFOYMXhfHbOyMwJGPBQDeHemxXOqlXSszYwSaOwVBQcDgYDZKsLiutVT");
    int BxzCoGyCUiNwHp = 1410713593;
    bool pujkZRcM = false;
    int KJsvykAdqQUpbGn = 1773618791;

    for (int jdfOoylEuUw = 984638127; jdfOoylEuUw > 0; jdfOoylEuUw--) {
        RLREKWXrsMydmz = OBgBzHYbRU;
        YKCHdLg += BxzCoGyCUiNwHp;
    }

    return OBgBzHYbRU;
}

bool aeYkBh::WRiokjrYydzJgJz(string vVviNshqr, int FUmNvemMMo, bool MAMVvaC, int phGSQJcIpf)
{
    double qlAOz = 935027.8279188968;
    bool oUlhJl = true;
    double HtShvcJWNBaFelSI = 340473.16043193144;

    for (int BLDAAwLdPD = 1590365912; BLDAAwLdPD > 0; BLDAAwLdPD--) {
        continue;
    }

    if (MAMVvaC == true) {
        for (int hZfKQCcSPN = 396694751; hZfKQCcSPN > 0; hZfKQCcSPN--) {
            vVviNshqr += vVviNshqr;
            MAMVvaC = ! oUlhJl;
            oUlhJl = oUlhJl;
        }
    }

    for (int rufqMXoeGoEd = 1502459795; rufqMXoeGoEd > 0; rufqMXoeGoEd--) {
        MAMVvaC = MAMVvaC;
        MAMVvaC = MAMVvaC;
        HtShvcJWNBaFelSI = HtShvcJWNBaFelSI;
        phGSQJcIpf *= FUmNvemMMo;
    }

    for (int zAnAuCpfNItQ = 1388052097; zAnAuCpfNItQ > 0; zAnAuCpfNItQ--) {
        continue;
    }

    return oUlhJl;
}

string aeYkBh::hwrhfqUEsN()
{
    string vzrQzlqg = string("CcvkUFykDaLgiCfsqZbfPAxfrdpNwUYQRiLysBWgniEjFHCshwNnhUpHibDoTmOXSrfRbsABSzyQyDEqTmUlWETNYFCzzkzXBRnfQrLpnzhCPhgnfoWFpiGINsSCNxPeOZxflKQVIVAJbAHVtctkYokoIsUEECFjDlUljuIimSfjcPwpGrNAwDFAPXXosRJruYTxpcYngnEqUFZwRkwUQBxTvmCyVkZErEuKSCOflvyWmDtIBNssawTnSUifMql");
    bool WXYomTcFqDERu = true;
    int cPOSlkPW = -1186366735;
    bool ddCgYQt = true;
    string dmyjhziba = string("WJgwzHVaXlJVrerPZxjbHsPfEFkLduwQgwaYExbDJmMRSnqabnvYbLyjSHiYdAJkplZgdgnCMUYdhfZzRwhsrcqRnOocmkzoDgPOcYqLxaoxYJQqFKefwlqdNUhfyakWhqOvWMbkXHlOeQaPbFyGPkqXsApSWIdKWSJbnrbqwsvgcboDSmoqvzMnJTOndjWRhxBWDzcHFfmYxPuPHNmkVqYeGePULSRTInjiYsrZNRIOcIinhiuY");
    double qpVinJoVsfaNYbU = -538104.207001731;

    for (int NqRyYWpdlRuhBT = 822348325; NqRyYWpdlRuhBT > 0; NqRyYWpdlRuhBT--) {
        cPOSlkPW -= cPOSlkPW;
    }

    if (WXYomTcFqDERu == true) {
        for (int OPACIzInJhrYc = 703829816; OPACIzInJhrYc > 0; OPACIzInJhrYc--) {
            continue;
        }
    }

    for (int uVGvLWv = 1916891090; uVGvLWv > 0; uVGvLWv--) {
        continue;
    }

    for (int QILnfoPnlMSGf = 670686728; QILnfoPnlMSGf > 0; QILnfoPnlMSGf--) {
        continue;
    }

    return dmyjhziba;
}

int aeYkBh::xXnCLJSadYtw(int mQRHEwXbLhelj, int bnbauPfOXXtCKr, string VKygpczpwXtjRU)
{
    int VzuQOABUIdBtIdsj = -1793514957;

    if (VzuQOABUIdBtIdsj < -1671207537) {
        for (int cWUKkesOICaauu = 518128982; cWUKkesOICaauu > 0; cWUKkesOICaauu--) {
            VzuQOABUIdBtIdsj = mQRHEwXbLhelj;
            VzuQOABUIdBtIdsj = bnbauPfOXXtCKr;
            bnbauPfOXXtCKr /= VzuQOABUIdBtIdsj;
            VzuQOABUIdBtIdsj -= VzuQOABUIdBtIdsj;
            mQRHEwXbLhelj *= bnbauPfOXXtCKr;
            bnbauPfOXXtCKr = VzuQOABUIdBtIdsj;
        }
    }

    for (int vjEheEqlgqPv = 73452801; vjEheEqlgqPv > 0; vjEheEqlgqPv--) {
        mQRHEwXbLhelj *= VzuQOABUIdBtIdsj;
        bnbauPfOXXtCKr += VzuQOABUIdBtIdsj;
    }

    return VzuQOABUIdBtIdsj;
}

string aeYkBh::exzAQ(bool xmifIoIyn, int HNTah, bool TGDoWvzzOSCvuRH)
{
    string yMbawemTAoBryBC = string("CzxetLpjshyiWiQJIbqGPXEydg");
    int NYkZLPhUbQxeihht = 2134612450;
    string rxObMTHEOgZF = string("tCpGefmBdadwCfBicXpisWTsAeVFjcaHUxQWeQrdOucMHhMzSikObyHRjtzmLImPCtsHJqAmApFdKaOTTdzpNzOlxZWQafvkuoKOfvWYhmRpUPNOZNbEJFAmZRgmmUiSYCeowCkLvBkWmqhWffsLXhSRLKWOzUhcQsRlSoPf");
    bool fWIweVfmySGzyQN = false;
    string sRhZUXAvx = string("fJWUpAxWuUsQfcgUgumlGnsSnKnBcApnlvYHHqrEBPQauDQiyLVtUU");

    for (int nEeLTLIUFW = 1709831189; nEeLTLIUFW > 0; nEeLTLIUFW--) {
        rxObMTHEOgZF += sRhZUXAvx;
        NYkZLPhUbQxeihht = HNTah;
    }

    return sRhZUXAvx;
}

bool aeYkBh::WUjpwLXoCIUCwevg(double byAEeGRTyEyzD, double wobTQE, string oyBpQ, double cuxqVaQJbV)
{
    double vxzggq = -887707.9215847736;
    bool cJTNYmKHl = false;
    int OSisZZiDwyGzDKDi = -1160063712;

    for (int IeCqiL = 218354110; IeCqiL > 0; IeCqiL--) {
        byAEeGRTyEyzD += byAEeGRTyEyzD;
        cJTNYmKHl = cJTNYmKHl;
        byAEeGRTyEyzD -= byAEeGRTyEyzD;
    }

    for (int uXRGLvc = 2051039231; uXRGLvc > 0; uXRGLvc--) {
        byAEeGRTyEyzD -= cuxqVaQJbV;
        cJTNYmKHl = cJTNYmKHl;
        OSisZZiDwyGzDKDi /= OSisZZiDwyGzDKDi;
    }

    if (cuxqVaQJbV <= -887707.9215847736) {
        for (int fZgCqMUShNbAMypj = 1664663788; fZgCqMUShNbAMypj > 0; fZgCqMUShNbAMypj--) {
            byAEeGRTyEyzD -= vxzggq;
        }
    }

    for (int eENNWEFeZy = 1299638896; eENNWEFeZy > 0; eENNWEFeZy--) {
        vxzggq -= vxzggq;
    }

    for (int qtaZIfuQTgFgx = 989108404; qtaZIfuQTgFgx > 0; qtaZIfuQTgFgx--) {
        byAEeGRTyEyzD /= cuxqVaQJbV;
    }

    if (wobTQE != -46688.54924343816) {
        for (int oFmCdUWtXr = 760120732; oFmCdUWtXr > 0; oFmCdUWtXr--) {
            wobTQE /= cuxqVaQJbV;
        }
    }

    return cJTNYmKHl;
}

int aeYkBh::GSOdntIHD(int kbjVIPrCU, double jKtMoOtzE, double vsMvlxNWG, int NcLPDj)
{
    string VSJvxrqBWBFXwp = string("nRuMGyzpPbvqKscoqunJtbTGnKasXIojOjwGoWePhssKQAQfCpZXKcnVcJagfAcuLrYiBkxFyMrbVYPzAgUhUjtRWKXmUsaWeSKYcBSpIHFoyRZZpcjRCBwqeMNSVMEGWBnGuOuMQhxUatDHmlgqvCOSYWsMseMGUavDstEPeSTQUhxaZpjUumZWgyZylkxwfRutcsQkGOUsCKLtIsQsyWRMAjQSwApxwCjiOJ");
    double vpycHEgyfFiBiHN = -590469.1370586185;
    double mZlbBSfsW = -210170.9696620909;

    if (jKtMoOtzE != -488767.1995381926) {
        for (int mITVPGQVtAmSb = 1631574043; mITVPGQVtAmSb > 0; mITVPGQVtAmSb--) {
            vpycHEgyfFiBiHN -= jKtMoOtzE;
            vsMvlxNWG /= jKtMoOtzE;
        }
    }

    for (int DlvxiJWHEes = 1445244911; DlvxiJWHEes > 0; DlvxiJWHEes--) {
        NcLPDj += kbjVIPrCU;
        jKtMoOtzE -= mZlbBSfsW;
    }

    for (int oddRoNqS = 1533626700; oddRoNqS > 0; oddRoNqS--) {
        jKtMoOtzE += mZlbBSfsW;
    }

    return NcLPDj;
}

void aeYkBh::AVsJlaPAhthuJmn(string XzRJJEbnAjj, string zGeqin, int ZuYoatLbfyvHVTXU, double PeOAzeI, string hUbccIpwM)
{
    double ZhCOsMAlNcRm = 471666.7108730279;
    bool JxkxuQRo = false;

    for (int VnNBdDkF = 461225624; VnNBdDkF > 0; VnNBdDkF--) {
        zGeqin += hUbccIpwM;
        PeOAzeI *= ZhCOsMAlNcRm;
    }

    for (int IxWlUNJPQkieKQul = 485897685; IxWlUNJPQkieKQul > 0; IxWlUNJPQkieKQul--) {
        XzRJJEbnAjj += zGeqin;
    }
}

aeYkBh::aeYkBh()
{
    this->pihXpEDNFSy(-1256995099, 2101879426, false, 244445081);
    this->yWZUMtXcdlRKpk(-776767.0692978366, true, true);
    this->rrQixQe();
    this->mXeIxHIlUgsBh(-945516.6340805851, 1666880502, 267198.8566951355, true, -833187224);
    this->phmoMZCXePkZiNn(false);
    this->GItrMJiYWNUJ(-1243220307, -1015029720);
    this->WRiokjrYydzJgJz(string("sJyekRmXRSIyzxmOcDquBmGECsKVTGBOyFnWRixlHbySNVICXyJgjQAaZKIRmWSquzwjGVGHNOXVXjPaiBIwmEdUgKvegGrvUsYBzOJaRBvigprXBPcNFpNAqlPerVWszkWhvVDmYqlZmmxTvJSDSZgSSwwCDdHDzDwJMVbjYZu"), -2008497253, true, -491405518);
    this->hwrhfqUEsN();
    this->xXnCLJSadYtw(-1671207537, -438808064, string("UqnsBzqUYkIINuniIPizUwCYSnUGMTpGaqhwdnSFjlafkNjHoMNnGWBZwSAoYgGDMTVYSZkWqsJxRqtNWDeiPqlXvjGrIwBnctAUtfiIvtFMlbivYBggEkJxrWmjmGILvyqleNvl"));
    this->exzAQ(true, 302080492, false);
    this->WUjpwLXoCIUCwevg(793118.0734201234, -46688.54924343816, string("bwaQbYqsZJMZDaicCkgetlvlQkEeOLOrQUcnbLhaNnThrUFAgMylSbiScfcaXXWFSfZzmlkqFSCQIYvKPLWiloXrsfRFedQFqoNLuMGVSIwPFWPKcewZgWcJvwpcJxTZAPyBuWRfyfIACn"), 1047501.8361531022);
    this->GSOdntIHD(-50521437, -488767.1995381926, -244925.31418086178, -97653298);
    this->AVsJlaPAhthuJmn(string("cfbGPpYWlinElJBupNSAhAWCOJctiwOxJriHKBcmuYQleJXZGgTPAkbKxyymVdhzsWHlvsHGuIMQKWPvGsFwMrEiiMuGafwRaiqtaFdCysLLWGKkBfKJmIIdbnkRMcDfwNIaeWXrEKbCJJTHKSJQcwsAfolAhpTmVZFspnCrCXMVaSiaIpFrnWKgvmLXKBNhALjYfYnmoLCBnHDYxBDkMHkR"), string("hBsavNilCfNpfdxCJFZgbqrFXUsGYYJjpBhWyHzfSTtPLWEPBtUWvbnannHovCJzufDPxQTfzXkfXdgoIEWKvIfOUqczmkIPfkIYyLLvYWYZPtMgJabQhhTKqPkpPisbyOVSAcCOITzIADxUsXXKuQmljuuPKCtLicvpFRNcpadfKNlDSVVGlZMVUIHcANcEehdguNowzsSRXezdBSxnTaQNsvRUPZtzBhOEpwRtQYsDdAtIQwxjBNi"), 1851013674, -47417.25539956202, string("DwHcLeszbYinPZvHJnLPVQtTpezrVkvrZSbYgDdDsFQxGAHOqxyECxpqMcBANVitYcrlxBFnqoxNzbmMlntmospClQwyItPduUXVgogiBvqtetmWaTJEQSuwiVqigMbclKlJiirICbNbiquAnVsNlKRUDWBGQQhRUyEyBZtJVsfTGpLHrEgATGXiJVIMgTEIGwdgFiaameNzDUldNEndqPwwVTlZqMBPKvWQvrbU"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eDfhMljVB
{
public:
    double aFXNffKOpIHUXeh;
    int AjogEikFpRLloTgE;
    double BonBCtghxcH;

    eDfhMljVB();
    int ILeLgurleXZ(bool RpeKj);
    int PhSeyd(int drrdeXYGcA, bool mdOTWzgbWO, string GnSLYcYwZWsUF, bool CfkZiXtqOIAr, bool HdQfGqRMduv);
    int dngqrqFPEmTGBn(int vldvCggD, int DdgdiHyacYAjWQ, bool qnUfVIMEwQ, double nZowma);
    int yGXtN(string DbPCJhneFp, int TYWHGGgXLjWArdhw, string YThAOW);
    double GverxIAfDgXHa(int ZGAcjNdcAevIgBPL, double fWnOVJKHoms, int QdBgceTu, bool LOZBNSj, int FvtYbjNhCe);
    bool jdEbsOmTfaF(string eOCyEcgJHNac, string XoNcoTIE, string bsitldgoKORwbAv);
    double TEyciJDr();
protected:
    double JuIQRapad;
    string VucfjZURceYpvVVf;
    string BGTQFzTJdCY;
    bool xEOIJGsq;
    double HpiiMzYiHejuyvuO;
    string rdpAnwnRiEpTnPP;

private:
    int cGDdQCnHXyX;
    string SzHvSAfxkuwimU;
    int YYSLNCfT;
    string zfvwAmLnslnNcq;

    void VmjoZjJPcFNGBe(double xAiuC, string ZkCDNrEGFkmomJK, string tNxEpFnI, int zhukfLcmdwMM);
    void YBoSFHRQbZWov(bool tOyzvHZd);
    double KprLWCohaoxmFho(string EQcZaRmZ, int LXkmkvpWAr, bool EQiKPCUYotbBltHD, double aMuTLCohSoB);
};

int eDfhMljVB::ILeLgurleXZ(bool RpeKj)
{
    string TGXZuWBHWp = string("jLuHcKrTPkVCfCsMiGLthaQtlxxRLyFckrOVidGzPBEkbRhIfIAYdrtUugRXNnZmuLYinpgBdWJkmMAKvjsNBdEHmnJoMzISdEVJsjBRrpqKCMqRhFklrDKMYAehRmGDnHvnCBzKlOhQGjIhaQmLAXNzDOXRVANSLAnWyAlDYSgBguyv");
    int WYCYpbJh = -1602755076;
    int MRthlNjG = 286674152;
    bool GIQcxZzKHu = false;
    double mVkfTHiCFFCYAG = -316450.38245832175;
    string rLozdGJnNiN = string("CvrlYHqTTceLcWrwSmMHCvCgnHffNsRjrtojaBfkvwvXsOmECtntgfqJYnGDISSDdIXEwkrURESdUxwUzlzGtYVNCSCaYttymVkjwzdgmYIlKZaroIQkmcloYWaZXlvuTAcABFkTMDQsgfsePtBLAnqjOcsuQtwgwynpQirSJTcLmzexBLWfLGVKhQNNwkGhZuJohxwtrZeKhPPcefLIpsqHzwkikcWFhMUYIuHDFGEATUDGqJoFFAak");

    for (int orbnrotXvLR = 910083742; orbnrotXvLR > 0; orbnrotXvLR--) {
        mVkfTHiCFFCYAG += mVkfTHiCFFCYAG;
        rLozdGJnNiN += TGXZuWBHWp;
    }

    return MRthlNjG;
}

int eDfhMljVB::PhSeyd(int drrdeXYGcA, bool mdOTWzgbWO, string GnSLYcYwZWsUF, bool CfkZiXtqOIAr, bool HdQfGqRMduv)
{
    string UqSQBSQ = string("qLdmxoFfKkSZREZboqfQaOIbdBqlIHTRjgieJyvzWLXrUZDCfQnkbqvAkiCZFWRKcRbUjMZHBOGfsjEygzeTuPnsPsWvUSetjRsXRxwxREKVbFAmiJInNcL");
    bool JqoMNBKVAzU = false;
    int AUbPOlzBW = -1207188535;

    if (AUbPOlzBW >= -1207188535) {
        for (int coIqqMrvhjQoy = 1679843817; coIqqMrvhjQoy > 0; coIqqMrvhjQoy--) {
            CfkZiXtqOIAr = ! mdOTWzgbWO;
            GnSLYcYwZWsUF = GnSLYcYwZWsUF;
            HdQfGqRMduv = HdQfGqRMduv;
        }
    }

    return AUbPOlzBW;
}

int eDfhMljVB::dngqrqFPEmTGBn(int vldvCggD, int DdgdiHyacYAjWQ, bool qnUfVIMEwQ, double nZowma)
{
    int bprsbZOES = -1331757880;
    int KlOnguKGvYjXxK = 1556290517;
    string uZRAdWtPnbmvj = string("xRqEQkZKgMBDHDBMjYsunrycIhaadwklfvKHVKnRdTHxwhGYDAZobgxEbbHjmjlgxzWlyylyJMuVARWPYdkhkCzytFRTNqlubWLIsOSNRkEOaYdGvECJDbNOdoHVbVYLuCvpRSPAvpBKVMIIfpypxbPoPuFyAbMvIbxqxptpjpPoNmbaUHgHEcClLIoLwHKMyRHCLsiSiBpDaCCXspGGNxPqvtAjimHzyhbZIw");

    for (int gZCxvNupGTSpWCVs = 2003499659; gZCxvNupGTSpWCVs > 0; gZCxvNupGTSpWCVs--) {
        KlOnguKGvYjXxK *= KlOnguKGvYjXxK;
    }

    if (vldvCggD <= 740842122) {
        for (int uaBAAtcI = 1715445672; uaBAAtcI > 0; uaBAAtcI--) {
            bprsbZOES -= DdgdiHyacYAjWQ;
            vldvCggD = KlOnguKGvYjXxK;
            vldvCggD = DdgdiHyacYAjWQ;
            DdgdiHyacYAjWQ *= vldvCggD;
        }
    }

    if (DdgdiHyacYAjWQ <= 740842122) {
        for (int rrkxwQFIDSpl = 1797648678; rrkxwQFIDSpl > 0; rrkxwQFIDSpl--) {
            nZowma -= nZowma;
        }
    }

    return KlOnguKGvYjXxK;
}

int eDfhMljVB::yGXtN(string DbPCJhneFp, int TYWHGGgXLjWArdhw, string YThAOW)
{
    double vPYpWW = -567975.4243662924;
    int qsqjYjKIgZjsyl = 931174259;
    double QiLEnaIWCzWARi = -208375.9525127902;
    double vBjgy = 73208.07511996331;

    if (TYWHGGgXLjWArdhw <= 425593259) {
        for (int MBHCRLMLnCboh = 397653107; MBHCRLMLnCboh > 0; MBHCRLMLnCboh--) {
            DbPCJhneFp += YThAOW;
        }
    }

    for (int qmnWgxBZ = 1824063281; qmnWgxBZ > 0; qmnWgxBZ--) {
        DbPCJhneFp = DbPCJhneFp;
        DbPCJhneFp = YThAOW;
    }

    if (vBjgy <= -567975.4243662924) {
        for (int zcRDlzmuWSIRbeS = 156702486; zcRDlzmuWSIRbeS > 0; zcRDlzmuWSIRbeS--) {
            qsqjYjKIgZjsyl *= TYWHGGgXLjWArdhw;
            QiLEnaIWCzWARi += vBjgy;
        }
    }

    if (DbPCJhneFp == string("gIBXLDoxfcnkEbkJcKaEltSAsLEirDvzZNJlUpEVNdPldKoNpNATqBLRWoAkxcuUbmzJIYZYemdGcOcQADWshlLxIXhCFVhlufOsnFQCZTlBWAnKpjkEUaNBxXXCvRwNcijjKtQzbLTRKGAFvIsAJeqZVOvGNpPfvFSDWsQlyejPlMJPVJUQpTtlGnAkpHavQRlaDYGWelxINaPJqhWLniLXWYVbG")) {
        for (int qloQhoYKe = 188912658; qloQhoYKe > 0; qloQhoYKe--) {
            vPYpWW /= QiLEnaIWCzWARi;
            DbPCJhneFp = YThAOW;
        }
    }

    return qsqjYjKIgZjsyl;
}

double eDfhMljVB::GverxIAfDgXHa(int ZGAcjNdcAevIgBPL, double fWnOVJKHoms, int QdBgceTu, bool LOZBNSj, int FvtYbjNhCe)
{
    int OfXuBMogpNMUCu = -1086051044;
    string jezLjZMxRpFVWxbT = string("kZNeMDkqsDiXXbIcknPxEfNxEbDTGmuDWvykcKfKlVHJMGZsDZuhXtwltMgfhBVHJHTYzJPDIHoumHpeealdmWcDfIopCpLeUJmkERxUEvpoWDDRBXw");
    int dzaoJRLPTWsqdFVE = 573280896;
    bool mJHYUZOeWwUHSGl = false;
    int zvxbgGbeArHvOlSr = 715226838;
    int odaiALbAa = -1644618533;

    if (odaiALbAa < 789053864) {
        for (int SWUJpFpChdKRPP = 1548409281; SWUJpFpChdKRPP > 0; SWUJpFpChdKRPP--) {
            continue;
        }
    }

    if (FvtYbjNhCe >= 715226838) {
        for (int IrSOBZGJylQ = 604482456; IrSOBZGJylQ > 0; IrSOBZGJylQ--) {
            LOZBNSj = ! mJHYUZOeWwUHSGl;
            OfXuBMogpNMUCu += zvxbgGbeArHvOlSr;
            OfXuBMogpNMUCu -= dzaoJRLPTWsqdFVE;
        }
    }

    return fWnOVJKHoms;
}

bool eDfhMljVB::jdEbsOmTfaF(string eOCyEcgJHNac, string XoNcoTIE, string bsitldgoKORwbAv)
{
    int BGYgXPV = -299774216;
    int NunrCNcBAMLq = 1558086448;

    if (BGYgXPV < -299774216) {
        for (int WoYMagRgFXYV = 1864900644; WoYMagRgFXYV > 0; WoYMagRgFXYV--) {
            NunrCNcBAMLq *= NunrCNcBAMLq;
        }
    }

    for (int HSPWyQUb = 2068929273; HSPWyQUb > 0; HSPWyQUb--) {
        XoNcoTIE += XoNcoTIE;
        XoNcoTIE = XoNcoTIE;
        bsitldgoKORwbAv += bsitldgoKORwbAv;
        bsitldgoKORwbAv += XoNcoTIE;
    }

    if (eOCyEcgJHNac == string("TCabaoRwhsyfmvpeddcoTebXWnpfBQIJfmKpVMdPaXeMrEUBJsQtWOKnVtxgQlxzYobMNeMqNGyqOMKsXRkSYWOwHAimPnVKOkFQNbfhAOFUoGhkhYTsyVSUJkegHDfvwgFODDffEeKTPlbLnjngstpleSSrfjyKGQbauCntoEnSXCmJaGafIeabUSgwFRrNWTWIvAMRWuIGRBaqABIEHBnQQUCvuaMfWOAfWeQViiJcQtOZZvLkeywLTPwBb")) {
        for (int zBaYAfSlINLKJU = 2043417101; zBaYAfSlINLKJU > 0; zBaYAfSlINLKJU--) {
            eOCyEcgJHNac += bsitldgoKORwbAv;
            XoNcoTIE += bsitldgoKORwbAv;
            eOCyEcgJHNac = bsitldgoKORwbAv;
            BGYgXPV *= NunrCNcBAMLq;
            bsitldgoKORwbAv += bsitldgoKORwbAv;
        }
    }

    for (int KwLvD = 740295676; KwLvD > 0; KwLvD--) {
        continue;
    }

    for (int yiypmbNPiJZmaHcm = 1539590487; yiypmbNPiJZmaHcm > 0; yiypmbNPiJZmaHcm--) {
        eOCyEcgJHNac = bsitldgoKORwbAv;
        NunrCNcBAMLq /= BGYgXPV;
        bsitldgoKORwbAv = XoNcoTIE;
        eOCyEcgJHNac = bsitldgoKORwbAv;
    }

    return false;
}

double eDfhMljVB::TEyciJDr()
{
    double wjpCZmyfBFAMrkDo = -345250.4878765047;
    double GAflfGiNF = -705447.3018819753;
    bool hzidQSYyJAYjWZXW = false;
    bool cFamPy = false;
    string hADnJjsfLq = string("bxvSJpBbYqzuOIbaiIoMCCUUwmkOvJAyBDTnVVQjWMlQvHUAIEKfbtytlnBiUPfNjsiaLarYnlWJFQWYAKFlvpyeUzatpJkXgXWKxOBMLSiAfgBasMndgNZqZdpZMVFQQgdftPCoYRRxNAPKYOgfezOQlUlOInLjcNudssITwSJfCWgGMbxCcmMvoyAvNUCoaDGsA");
    int ywHsBwacBL = -892478790;
    double CCYXqWVsEIxsaO = 1037116.7219971668;
    double ymygvqKyiEttqk = -696825.1853030664;

    for (int JbLOLCAykIPD = 76411982; JbLOLCAykIPD > 0; JbLOLCAykIPD--) {
        continue;
    }

    if (ymygvqKyiEttqk < -345250.4878765047) {
        for (int nkHpTiwcj = 428507786; nkHpTiwcj > 0; nkHpTiwcj--) {
            ymygvqKyiEttqk -= wjpCZmyfBFAMrkDo;
            CCYXqWVsEIxsaO /= GAflfGiNF;
        }
    }

    if (wjpCZmyfBFAMrkDo <= 1037116.7219971668) {
        for (int cKJaTz = 1458947622; cKJaTz > 0; cKJaTz--) {
            continue;
        }
    }

    if (GAflfGiNF >= -696825.1853030664) {
        for (int aqbgGUYNgr = 2076232972; aqbgGUYNgr > 0; aqbgGUYNgr--) {
            continue;
        }
    }

    for (int PPHkuuGsejRUS = 1509725622; PPHkuuGsejRUS > 0; PPHkuuGsejRUS--) {
        ymygvqKyiEttqk = CCYXqWVsEIxsaO;
        ymygvqKyiEttqk /= wjpCZmyfBFAMrkDo;
        GAflfGiNF += ymygvqKyiEttqk;
        hADnJjsfLq += hADnJjsfLq;
    }

    return ymygvqKyiEttqk;
}

void eDfhMljVB::VmjoZjJPcFNGBe(double xAiuC, string ZkCDNrEGFkmomJK, string tNxEpFnI, int zhukfLcmdwMM)
{
    double kzrUEMToXHARn = 786068.5163135746;
    bool nNiTl = true;
    bool wSeNkaX = true;
    int xQnJwpbtu = -852096858;

    if (ZkCDNrEGFkmomJK >= string("DyDDVmCwPAwCXlmyWMJEkFJkYJMlTooyCkncGpbLpabzUclctabIsATIqFfTlTVSVBJgmnPFllCnJgDlMdEHOICYHbUgZQryHsOHWOyFBnVQgfBxugHFlAAeHVfAWVjegphKV")) {
        for (int XDPCAftAsInhI = 525864785; XDPCAftAsInhI > 0; XDPCAftAsInhI--) {
            continue;
        }
    }
}

void eDfhMljVB::YBoSFHRQbZWov(bool tOyzvHZd)
{
    bool SRvjzvRUTeFBEw = true;
    double SIaMGxVnE = 894296.7617184122;
    double fOWQy = -996260.7142034967;
    int GbrnMvT = -1297681336;
    string qNgfnFVUcevscuK = string("GAheKxcWLcAYxVQedzDJMeBOyPRtbsKqMWTOBQKDnXEUiJGUUhkYykeNOmqTJPYuWzhbtVjNVFUEgiBquCOClkoXGZremtJuZKwyEIvIKAThPCVdGwnMfLunVfhMCtEveIdbOmFvhJhZINvmgQklFf");
}

double eDfhMljVB::KprLWCohaoxmFho(string EQcZaRmZ, int LXkmkvpWAr, bool EQiKPCUYotbBltHD, double aMuTLCohSoB)
{
    bool LAklU = false;

    if (EQiKPCUYotbBltHD != false) {
        for (int snqKEKbXThHBVH = 1810989060; snqKEKbXThHBVH > 0; snqKEKbXThHBVH--) {
            LAklU = LAklU;
            EQiKPCUYotbBltHD = ! LAklU;
            LXkmkvpWAr -= LXkmkvpWAr;
        }
    }

    for (int wbWksjhiHFROAscz = 581339242; wbWksjhiHFROAscz > 0; wbWksjhiHFROAscz--) {
        LAklU = LAklU;
        EQiKPCUYotbBltHD = EQiKPCUYotbBltHD;
        EQiKPCUYotbBltHD = LAklU;
    }

    for (int kjUBSNt = 1365361497; kjUBSNt > 0; kjUBSNt--) {
        EQiKPCUYotbBltHD = ! EQiKPCUYotbBltHD;
    }

    for (int XRPrZrzdKMBhcQ = 764550171; XRPrZrzdKMBhcQ > 0; XRPrZrzdKMBhcQ--) {
        LXkmkvpWAr += LXkmkvpWAr;
    }

    if (LAklU != false) {
        for (int qasctBxqFZJyINdt = 1746531232; qasctBxqFZJyINdt > 0; qasctBxqFZJyINdt--) {
            continue;
        }
    }

    for (int DbagiV = 2052128867; DbagiV > 0; DbagiV--) {
        continue;
    }

    return aMuTLCohSoB;
}

eDfhMljVB::eDfhMljVB()
{
    this->ILeLgurleXZ(true);
    this->PhSeyd(-808263595, false, string("GgYdhldJtaKCEqLOaTeEwVSOKBTNSOhTtmrpHTbCUrBLNEIKIUWiGQbwsHacrPMEXNxaglfOCKAPzPhTzABNDzjrfjibYlIpjFCvUtHEcFjyLnLLafwKlzdGBOGbRnMaUMAKcTywyygjNqayosSsyZphHQTGfKHaoYMSNOPJZImNFlwBpotYigdgxvENlgmA"), true, false);
    this->dngqrqFPEmTGBn(-1780271829, 740842122, false, 867670.8290653152);
    this->yGXtN(string("iupeqpwlFuGYJYUQJJBjciYZINsgYHPSrdmhxKqvWfXFfWjQtTxMOPisQVQaQxzBqsjVgeNDYnUaoPiOQf"), 425593259, string("gIBXLDoxfcnkEbkJcKaEltSAsLEirDvzZNJlUpEVNdPldKoNpNATqBLRWoAkxcuUbmzJIYZYemdGcOcQADWshlLxIXhCFVhlufOsnFQCZTlBWAnKpjkEUaNBxXXCvRwNcijjKtQzbLTRKGAFvIsAJeqZVOvGNpPfvFSDWsQlyejPlMJPVJUQpTtlGnAkpHavQRlaDYGWelxINaPJqhWLniLXWYVbG"));
    this->GverxIAfDgXHa(2135555830, 450047.68559720507, 789053864, true, 2125012879);
    this->jdEbsOmTfaF(string("jXHLwjWWFXkeUuPZaWpCVYOcVMDbDoxsQFASERfbweRITVQQBY"), string("CnoAunzcOSIepKSVJanqWgODEclVpMidKYVaVDzjZkAeacfjkmhWzibxlmjduCbGRmCacawWFszkDzdjldhz"), string("TCabaoRwhsyfmvpeddcoTebXWnpfBQIJfmKpVMdPaXeMrEUBJsQtWOKnVtxgQlxzYobMNeMqNGyqOMKsXRkSYWOwHAimPnVKOkFQNbfhAOFUoGhkhYTsyVSUJkegHDfvwgFODDffEeKTPlbLnjngstpleSSrfjyKGQbauCntoEnSXCmJaGafIeabUSgwFRrNWTWIvAMRWuIGRBaqABIEHBnQQUCvuaMfWOAfWeQViiJcQtOZZvLkeywLTPwBb"));
    this->TEyciJDr();
    this->VmjoZjJPcFNGBe(902878.9510480397, string("DyDDVmCwPAwCXlmyWMJEkFJkYJMlTooyCkncGpbLpabzUclctabIsATIqFfTlTVSVBJgmnPFllCnJgDlMdEHOICYHbUgZQryHsOHWOyFBnVQgfBxugHFlAAeHVfAWVjegphKV"), string("zBdQxvsnOagvPuJjQHMDovmsFoiAQIuBExwisbTvcOlraxhobrvtLNSKuFskEXunBJiiKWVgemufsofLuPHjVxyGNzMDnBXlUVfctZWkpXyRKFYYEXDGlOlMhXcZARIpGaICWmGNgTobZELoIyWeWqmFjHjFTckgHkxsARucYPXCuxSjwvmiZAlkfnk"), 596176585);
    this->YBoSFHRQbZWov(true);
    this->KprLWCohaoxmFho(string("PyDySVDsZVvfIXhiFAPFYOyVJUembtRyqATicMBhQhztuHMHmglKnLIhsdzzvfPleEMQdyrQsAnJmGTQswHCoCqecSglyceqxreUZvcDLnGGHlbhVUiTOhlbALwSdKRzNRTKKfHpsItK"), -602691868, false, -847789.3736800848);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kmNyvOQZywdq
{
public:
    string MJxaaqeH;
    bool vfZSPwVQ;

    kmNyvOQZywdq();
    void FgWdczvIQw(double XGjcljx, int VPerCeoXCK, bool oSUnHcSol, bool VYNiKGoXW);
    int GhvLVQWoNNhal(string balmhbDIyL, double tSOtCZHIJHdSc, double jOMHXdh, double uHRnf);
    double lOqxVU(double pvObXFYPeCCd, int YDOYCDsH);
protected:
    int YCXwuC;
    double xgzvvNGcsKhlTw;
    string sWRtfNv;
    string UConUgIlFmxx;

    int JvEduEtuKP();
    void OFnmv(int oXRRqXsBgNqjlIb);
    int JJNyXksH(double tcVKVVC, bool PfGymAIZG);
    double kHLLQc(bool zquoFkFWJKYo, string DUdTZwvATOMpkP);
    bool qynwmiY(int uibmkCZrQM, string GDBOFIimp, int vsEYRUpLbFdOuD, int FuPiLnjsRcHv, int HvvqpzIG);
    double cNFFagK(string kRxTD);
    int ntKIYrma();
private:
    string cKpbPwe;
    int dhWlbKvfvpFEiP;
    double MgmdYD;
    double BWzEDvzecqD;
    int bGZpFFp;

    string nOLzRiWUhzXa();
    int jXUhjDWBmeD();
    double fvnMbdFqDuUYY(string XuvYKKBV, double BhTyDZB, double mCDhiLKdoRSG);
    int qqoCHEYJBLUKopkm(double HqMcFlrISh, double ATCmxjYI, bool sQhIkHZlRwqqZi, int mgeyuLRlUYs, int DFjHY);
};

void kmNyvOQZywdq::FgWdczvIQw(double XGjcljx, int VPerCeoXCK, bool oSUnHcSol, bool VYNiKGoXW)
{
    bool nbJyAow = false;
    string jDslWXo = string("aaFfLOoSvhSSYeziqDrbohqStwdkVPkjtEzdXsHZyzyOHNMgFDGVFdRYUhazYKKFfIvKYUiRPywKSnjcViPtjjlDwnvtLwEHJihfSONzcrxlJexRJxCkJsCbMRwWbhAdblfVhRTOCnCESDPFIUogvpVDQhvGOgITyLcMLMknhNqwVKrQsYcGGAkJrgPMUdaImXjvwXqJVUNVzHMPSEqMykdJxsEj");
    bool psPlvmEgyBFHvvyq = false;
    int dMFoCEJHXRlaiUk = 1724612633;
    bool dYsWbB = true;
    string OFeth = string("roYIsFkqMOzmKkUiQEXAyRIaHoHdaNTfkvLJtFFgJzWqunJLhOQKPUQRAGFAnuAhlznYaGEAlfDWqZsrnJxcBUTkvlzgJtfCJYfoPPlGXbDnJSEPsi");
    string isLYPgs = string("hflSXiYGkrzKWOSWtrZbbJrFNTtjwVQpZDCbzwYQsQBDiPRisNsrQaYajnsHDHfXZHcVOTjz");
    double gaybvC = -667917.4154070633;

    for (int dDnbpbARQnFZYn = 1043618578; dDnbpbARQnFZYn > 0; dDnbpbARQnFZYn--) {
        dYsWbB = oSUnHcSol;
        oSUnHcSol = dYsWbB;
        VPerCeoXCK *= VPerCeoXCK;
    }

    for (int HMfifbCqrW = 1735174062; HMfifbCqrW > 0; HMfifbCqrW--) {
        jDslWXo += OFeth;
        dYsWbB = ! VYNiKGoXW;
    }

    for (int iQvdIDtI = 1699137979; iQvdIDtI > 0; iQvdIDtI--) {
        nbJyAow = VYNiKGoXW;
        oSUnHcSol = ! psPlvmEgyBFHvvyq;
        psPlvmEgyBFHvvyq = ! psPlvmEgyBFHvvyq;
    }
}

int kmNyvOQZywdq::GhvLVQWoNNhal(string balmhbDIyL, double tSOtCZHIJHdSc, double jOMHXdh, double uHRnf)
{
    bool hTYgTopqPyCBk = true;
    bool irOmN = true;
    bool FXomUFo = false;
    bool nyDVMCuLhCg = true;
    string IEcDcOypHJgc = string("CrdBuHADJeNCDyMnOgaLFcSnBRGcfHR");
    bool pTqQOXsOKMQv = false;
    string BnjhiIiKSMnT = string("KSsNAFlPmjgApDUgyHCDlGnPdTqBZVuJwPxtjPhxExbxsnpTYxuppHxdxqnVGgVuoCamZDEtsrIEiDeHcDefeCBzVgMTjiBZYfnMIJUYgXrSfFeTtaZRtVrnpjFpHttjYmTPeGjCACmOpzVFMeZRxgrMpOoHEuxeEihXYXYNmKVGBPWgRzVPNrfHXBSXuBgqJgHUpNIyfgDuzMtpOOekAdy");
    bool McgKcdPPj = true;

    if (irOmN != true) {
        for (int YldhJXGqK = 1878951045; YldhJXGqK > 0; YldhJXGqK--) {
            FXomUFo = ! nyDVMCuLhCg;
            hTYgTopqPyCBk = ! McgKcdPPj;
        }
    }

    for (int mbSPrQDX = 1256479428; mbSPrQDX > 0; mbSPrQDX--) {
        BnjhiIiKSMnT = balmhbDIyL;
    }

    if (hTYgTopqPyCBk == false) {
        for (int tgsDcKCHlILKBd = 2027282553; tgsDcKCHlILKBd > 0; tgsDcKCHlILKBd--) {
            tSOtCZHIJHdSc = uHRnf;
        }
    }

    if (FXomUFo != true) {
        for (int ZrppvafxmNphEB = 2041288121; ZrppvafxmNphEB > 0; ZrppvafxmNphEB--) {
            FXomUFo = ! irOmN;
            McgKcdPPj = ! FXomUFo;
        }
    }

    for (int mYJSOzP = 1295993196; mYJSOzP > 0; mYJSOzP--) {
        jOMHXdh = tSOtCZHIJHdSc;
        irOmN = ! nyDVMCuLhCg;
        IEcDcOypHJgc += balmhbDIyL;
    }

    return -850787139;
}

double kmNyvOQZywdq::lOqxVU(double pvObXFYPeCCd, int YDOYCDsH)
{
    double PhbTGKdPYTtV = -455424.4165161043;
    string joYtOMhJOviqT = string("piSyhwOpYjrAXusWWexRoeMHeeMTZZCFOIthTPJthdKZVHMogLNdhVwLycXbOMdPtbkWLkLStG");
    bool dOHqKtLpScw = false;
    string HmgVRLuKxP = string("HRsDynwPWmElmvUXpUHyNhIEaBPxxLZorrkQLQKxqaQbAnwvJbmfytiOowoJzSKAUqpmVVHymSJFTsKCFfAOVHVuyKsAQszBjVqOKIvgwOMwbGiLggXojOQucOPddANhBosVrSBcsNvzjXSclmFOZZibWpuKEIkJwDIbynHARbRtNto");
    string zluQWSxXujwkiYvR = string("gUwlcthUJJrLIYkhKWXZwaUByuCeTAn");

    for (int BRlqlDr = 714979765; BRlqlDr > 0; BRlqlDr--) {
        continue;
    }

    if (HmgVRLuKxP == string("piSyhwOpYjrAXusWWexRoeMHeeMTZZCFOIthTPJthdKZVHMogLNdhVwLycXbOMdPtbkWLkLStG")) {
        for (int AuvASQsz = 1591531234; AuvASQsz > 0; AuvASQsz--) {
            continue;
        }
    }

    for (int cFNZZLTGO = 1606471661; cFNZZLTGO > 0; cFNZZLTGO--) {
        continue;
    }

    return PhbTGKdPYTtV;
}

int kmNyvOQZywdq::JvEduEtuKP()
{
    int iOgbLFcELvF = 1072254282;
    double axmvI = 735863.6814417886;
    bool mjpYzgML = false;
    double gNmIWvQtzlITLYUH = -468614.10544441716;
    string oDqEyvLUecuhrz = string("JFrUEkBuLyQSwBXYhbSoYvivLrxPZNTQoNCFwpwsaBJkwmZdFgfgkTncuJwMxmserUzxGGDNXdqSCrGAznzHwpMCPNWSipfHIhpFUzsHDFOIuXeaSufmduyVEEFVLQBTAr");
    int pfNinkmgqaRST = -346338261;

    for (int SyLumBfabOGB = 2142352796; SyLumBfabOGB > 0; SyLumBfabOGB--) {
        iOgbLFcELvF += pfNinkmgqaRST;
        oDqEyvLUecuhrz += oDqEyvLUecuhrz;
    }

    if (gNmIWvQtzlITLYUH < -468614.10544441716) {
        for (int uXBCLAdV = 1652219082; uXBCLAdV > 0; uXBCLAdV--) {
            continue;
        }
    }

    for (int eMInRySNGv = 1015003590; eMInRySNGv > 0; eMInRySNGv--) {
        mjpYzgML = ! mjpYzgML;
        oDqEyvLUecuhrz += oDqEyvLUecuhrz;
        axmvI -= gNmIWvQtzlITLYUH;
        gNmIWvQtzlITLYUH = gNmIWvQtzlITLYUH;
    }

    return pfNinkmgqaRST;
}

void kmNyvOQZywdq::OFnmv(int oXRRqXsBgNqjlIb)
{
    string QXdzqszDAZvDoA = string("aeQIudIBEqoyhRSzZDSqVxQbIPpBzezRXYGQhvXNoGYIZWowagjHTfxHlaNycJEHwYBywifbAtHxMxQjOgIctaIAgdPxfClzHQUGcfCNREjYHjTcQBFTZQclyIdYHSRlDVZIlyJMdQFQUgXilMNEnJmPKTAgBTLEOuIncxuirpLnKJMZniigLsXppTeiGaeWJAYopZBbWROLWvcoFwQRuiOrlahzmnauIpuSrwmWuzNbSINgSLOTMuO");
    double JuFkMRERJlrnRZh = -619721.5300913758;
    int ikclwx = -1075146348;
    string sWWYmJgTLJLP = string("wkQSnYQdkF");
    double eHDBgWXVz = 287792.2196282265;
    int BqMePUrKcvFaq = -1819982505;

    for (int dvCuYHohuZhCZG = 549363811; dvCuYHohuZhCZG > 0; dvCuYHohuZhCZG--) {
        sWWYmJgTLJLP += sWWYmJgTLJLP;
        sWWYmJgTLJLP += sWWYmJgTLJLP;
    }

    for (int mOHUiaxQ = 1651719698; mOHUiaxQ > 0; mOHUiaxQ--) {
        eHDBgWXVz = JuFkMRERJlrnRZh;
        QXdzqszDAZvDoA += QXdzqszDAZvDoA;
        JuFkMRERJlrnRZh += JuFkMRERJlrnRZh;
        eHDBgWXVz *= eHDBgWXVz;
    }

    for (int eMcAbLUwfWArynqI = 1260139833; eMcAbLUwfWArynqI > 0; eMcAbLUwfWArynqI--) {
        oXRRqXsBgNqjlIb /= BqMePUrKcvFaq;
        QXdzqszDAZvDoA = sWWYmJgTLJLP;
    }

    for (int rsDARfwfw = 1968043660; rsDARfwfw > 0; rsDARfwfw--) {
        ikclwx *= ikclwx;
        oXRRqXsBgNqjlIb -= BqMePUrKcvFaq;
        BqMePUrKcvFaq = ikclwx;
        JuFkMRERJlrnRZh /= eHDBgWXVz;
    }
}

int kmNyvOQZywdq::JJNyXksH(double tcVKVVC, bool PfGymAIZG)
{
    string BJxVpVaUtJzY = string("ICxYAoSmilCrrTevUCTteXZdhRPLFMNEtZqfzOtqrnQdHEHHqBcTPFUPZmUGlocUfANKGIDTwAWWviwPCHnereiCneYSKEDsnejAoEzwPTjdYerMLLmKkhYyMZHEtTMAlhaJlucVRkVytvvRKaqUedNMrbMaoHKrbjPcVrJTd");
    double IqSgueMokoj = -614495.3017943874;
    int jNmHERKyQmg = 347977759;
    bool yAAMbJkpKhmohRL = true;
    int rizYwvo = -311383906;
    bool lzzoQ = true;

    if (yAAMbJkpKhmohRL != true) {
        for (int fwLSwJKAEI = 292635277; fwLSwJKAEI > 0; fwLSwJKAEI--) {
            continue;
        }
    }

    for (int HxJzy = 2059626094; HxJzy > 0; HxJzy--) {
        PfGymAIZG = yAAMbJkpKhmohRL;
        tcVKVVC = tcVKVVC;
        lzzoQ = PfGymAIZG;
        tcVKVVC -= tcVKVVC;
    }

    if (tcVKVVC != -614495.3017943874) {
        for (int TbFCPCYeNsH = 765081566; TbFCPCYeNsH > 0; TbFCPCYeNsH--) {
            lzzoQ = yAAMbJkpKhmohRL;
            tcVKVVC = tcVKVVC;
        }
    }

    for (int ffrJYeSXcEpeRom = 1966633885; ffrJYeSXcEpeRom > 0; ffrJYeSXcEpeRom--) {
        continue;
    }

    return rizYwvo;
}

double kmNyvOQZywdq::kHLLQc(bool zquoFkFWJKYo, string DUdTZwvATOMpkP)
{
    int xwLDd = -2012576703;
    string LVMrnv = string("FZmHomxcscEjIzyjyJWVSEJAwuVRkcPKrktMdVJgADFOOAtNqgUYtOmDUKjokSyrCobkMeCxmWNYJJKSIwCtzpfhSTWQwmeTauZHnAzooBOTbBHvOFqltwGnPWgERXkAjbmTUKUcshLQHuqOevMUiAvxWRYVTRhxjEFwJGdzLsnrtQTKedRJFTvMDVuNsesHebYlalhyzkOdAtmGeuirHBGUdAtpJBknRyinxzuUPIqV");
    int UrAAIlvnyg = 2020818128;
    string RUGkBrNI = string("rMCQxQPfRKTOJUcoSMUNKGLADxtwjyXkEaoAjLvbJHlVvZWxmxlJcPqOkXFFqsxjEGVHDbpFdgfKBZNVytt");
    string WcbyjqXx = string("ujZkQloyIoOjxUkABzTDCDrWdECLhrmffVqpGqOgkgsjoXwTmxOclWTqJzPlMvRzHlKXFVOaAygWBCyRhIjLWYXPYIKAIjrzSlRXwgBytsYeqGtROQxkMUduwXTyTCPabFvvIKknxJcSeDNJlWQAujacWilQGmoOOVkxJGwPUgtyLKuDOOBlvxePRQKYkMhsMDdccIWKdzkupBDxBdigPnvzKrgbgriDBdaeUDo");

    if (WcbyjqXx == string("rMCQxQPfRKTOJUcoSMUNKGLADxtwjyXkEaoAjLvbJHlVvZWxmxlJcPqOkXFFqsxjEGVHDbpFdgfKBZNVytt")) {
        for (int PRvbaQWueHC = 101918851; PRvbaQWueHC > 0; PRvbaQWueHC--) {
            DUdTZwvATOMpkP += DUdTZwvATOMpkP;
            RUGkBrNI += RUGkBrNI;
            xwLDd *= UrAAIlvnyg;
        }
    }

    return -93999.17469153285;
}

bool kmNyvOQZywdq::qynwmiY(int uibmkCZrQM, string GDBOFIimp, int vsEYRUpLbFdOuD, int FuPiLnjsRcHv, int HvvqpzIG)
{
    bool XpFkhFN = true;
    string WlgwkhGfMYIQ = string("SOzQuUXJUCbUlovxftYfdnKVJdzaSTDUOhdndfGZsNqPCnOxgoaQQfvIBrBmMMakystpABSLiKcEcnLhZCPmhLiAkNvvDfHzpMnSvNuiyECAOCyuZKlIyzetOaWrFJzsJSxxBxDGvUWCBggkWQxjewiFWNPvJYNaBjS");
    double AXUtOaDuwniR = -877288.9223423513;
    double tDKrtveO = 962459.985272984;
    string wjMVfqvijSJJnCt = string("mAlgCbDIJehaCAzdKyeMfpomjHyMdwZtuhjKokooqmuPxlCwASsKKWsgkjRGoaAXaAWPjEufrnijYEeMQTpjpZaSBKQubfXblQKcggueYyDnJuytPBstuoDuktkPviioncmoKZzetPlNdWRIxUuZQcKohqWwdzvjlDUoFzMCrVGEpbiiaeAUqpZgQDWGjzWtgRXgujEchBzAcYAZfwbnhYNiYUzomvMsjgHcHS");
    double YFRsITUykDyewjot = 416594.3177818106;

    if (vsEYRUpLbFdOuD < 1706368870) {
        for (int nMroDUHIjkHJjnz = 1987973361; nMroDUHIjkHJjnz > 0; nMroDUHIjkHJjnz--) {
            continue;
        }
    }

    for (int WVDZRAIiJEgYxmyb = 1289229462; WVDZRAIiJEgYxmyb > 0; WVDZRAIiJEgYxmyb--) {
        vsEYRUpLbFdOuD -= FuPiLnjsRcHv;
        wjMVfqvijSJJnCt = wjMVfqvijSJJnCt;
        GDBOFIimp = wjMVfqvijSJJnCt;
    }

    for (int WVMcLNZbRMCsCM = 1177848096; WVMcLNZbRMCsCM > 0; WVMcLNZbRMCsCM--) {
        tDKrtveO = AXUtOaDuwniR;
    }

    for (int IohHXfrKNcV = 285451756; IohHXfrKNcV > 0; IohHXfrKNcV--) {
        continue;
    }

    return XpFkhFN;
}

double kmNyvOQZywdq::cNFFagK(string kRxTD)
{
    string VpZzsHVU = string("RpRHMHpupOcgefVsnRYvvrQOGM");

    if (VpZzsHVU < string("RpRHMHpupOcgefVsnRYvvrQOGM")) {
        for (int ZWMndiGnOrKPmiu = 2043649386; ZWMndiGnOrKPmiu > 0; ZWMndiGnOrKPmiu--) {
            VpZzsHVU += kRxTD;
            VpZzsHVU = kRxTD;
            VpZzsHVU = kRxTD;
        }
    }

    if (kRxTD > string("DKvsE")) {
        for (int SbdavIRgaGP = 2032230496; SbdavIRgaGP > 0; SbdavIRgaGP--) {
            VpZzsHVU += VpZzsHVU;
        }
    }

    return 689274.1265092855;
}

int kmNyvOQZywdq::ntKIYrma()
{
    bool fHNznEuQhsseZ = false;
    double HiZso = -186125.6964045478;
    int rBECqXNOYP = 138883225;
    double TYDTOBC = 529867.9632874045;
    int tBeSs = -295007662;
    int ksAZPC = 1037763297;

    for (int BAfFpuPKuW = 53076602; BAfFpuPKuW > 0; BAfFpuPKuW--) {
        rBECqXNOYP = ksAZPC;
        rBECqXNOYP /= rBECqXNOYP;
    }

    return ksAZPC;
}

string kmNyvOQZywdq::nOLzRiWUhzXa()
{
    double YVzvt = 7959.501895516118;
    bool AncWli = true;
    int BobsG = 1154219749;
    int vbwwoxMPmPiCgz = 538358504;
    bool VSLYfPT = false;
    string VERjaFnjkixLC = string("RSlFOHCxTTriQPPOrugVraFmMFvAuupzBLXgxwvEAuMjlvWjKUbERFjfIGVarPuCmfOohuqmNSCQQayuvm");
    string mPQwscyyidhjZ = string("UIrnWUWqzEzByzcQUAifKKJVjSTOKSDgxSZTKcrYvQsvMDQyFUCNSINNIzvdmExDXsVubAumdTWLNXtuUGaAVAFIZfEHXAeQMeFNsFTsmeabsVTvRckuvWzwroZMhFFByafTECyWNDWQfkIhwMMacThjRriEpHTKtUISZOglfxBtBtHRBlyARvmSrEMkubjhmGhUGdmxGPhjhScV");
    int YeXskJhMUNkteKHO = 595864623;

    for (int lFbUTPJ = 1210702751; lFbUTPJ > 0; lFbUTPJ--) {
        VSLYfPT = VSLYfPT;
    }

    for (int aSKnTTgAkjiyKFT = 1519998411; aSKnTTgAkjiyKFT > 0; aSKnTTgAkjiyKFT--) {
        vbwwoxMPmPiCgz -= BobsG;
    }

    if (VSLYfPT != true) {
        for (int oMEnKIslbrFRRvq = 769227780; oMEnKIslbrFRRvq > 0; oMEnKIslbrFRRvq--) {
            BobsG /= YeXskJhMUNkteKHO;
        }
    }

    return mPQwscyyidhjZ;
}

int kmNyvOQZywdq::jXUhjDWBmeD()
{
    string ywPCgAxSwwiFS = string("IlvMdRoyjWLHbkHzAeunlTTENCfxRKBMgkZApqDUPoGUWOToVMLIhenVBNELzJrohObsWMdmdibOpCQgZXWnlSSVgrDEEyTiYehksKxb");

    if (ywPCgAxSwwiFS == string("IlvMdRoyjWLHbkHzAeunlTTENCfxRKBMgkZApqDUPoGUWOToVMLIhenVBNELzJrohObsWMdmdibOpCQgZXWnlSSVgrDEEyTiYehksKxb")) {
        for (int IcZLrbcXNBrqp = 203743934; IcZLrbcXNBrqp > 0; IcZLrbcXNBrqp--) {
            ywPCgAxSwwiFS = ywPCgAxSwwiFS;
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS = ywPCgAxSwwiFS;
            ywPCgAxSwwiFS = ywPCgAxSwwiFS;
            ywPCgAxSwwiFS = ywPCgAxSwwiFS;
        }
    }

    if (ywPCgAxSwwiFS <= string("IlvMdRoyjWLHbkHzAeunlTTENCfxRKBMgkZApqDUPoGUWOToVMLIhenVBNELzJrohObsWMdmdibOpCQgZXWnlSSVgrDEEyTiYehksKxb")) {
        for (int OsnFzkukIXCXgapA = 1515652124; OsnFzkukIXCXgapA > 0; OsnFzkukIXCXgapA--) {
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS = ywPCgAxSwwiFS;
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS = ywPCgAxSwwiFS;
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS += ywPCgAxSwwiFS;
            ywPCgAxSwwiFS = ywPCgAxSwwiFS;
        }
    }

    return 931160129;
}

double kmNyvOQZywdq::fvnMbdFqDuUYY(string XuvYKKBV, double BhTyDZB, double mCDhiLKdoRSG)
{
    int iHzdiCmWS = -1802133782;
    bool OzdNnnpc = false;
    int FrPME = -587222123;
    int zUHwOKR = 1277962901;
    double IzAqh = -359276.4614834796;
    string wbMtWddrCoqZkLS = string("VIvcyfRkdbfxCtYtcWkhzujPEMmMWubEUXzqAYyZCCZIXeBrhSgDJeGpLGIYMlRSHMMkdDoUhTWoHkZtYAnpqsVMvpZwSqTMxJeHqkBvcUIknlOfkmcBhCHeWdFvCUrtLOlxuRVDsGVgqNqsdfNTkGfFgQzAVMxBaAbURnKJNqohBemxFynSSilQDueSROpUvNUEKPhhxeChHxdDJezWmHIOrwqwhGsBXpjNwZvKCXgNWJJYXkMwzoL");
    string dPMQsIPh = string("oVODYkILTGJUEaPIKfYNeZtlgSosgHyVKnSpReOMCJzLboRoRgXVVGuoTTyTAgPByzhYFwScmDGDUPFgpNkUvJPXBHFmqWlQttgWzsxFTwrnsNVKkNgOwMyaxHiTPXbInTOYHpAhACWndjFcqkeMvZTdTmUPgkMbOBOQHsacxWgDPDggBvvullNoOjWnjUjgrqJQuQWXGTHOyjFgLJxDWSCdZFDDlFEZhTEvJhTRExPHLoMRnmVT");
    string StYyVsWbPMv = string("OREuGAXsfjLEHBhkGUhJTvTrfEgHnxCmi");
    double WwbwSItlPA = 683301.1332682491;
    string xyTPedfJ = string("KDGDDpcKoTrxenosoZBaNQTdDOTmniXqLzTBhhgSNrGaGjawJoVVmLSSHuCokfgPVAuhXVjXSblswNQRAHQLXkgLVq");

    for (int NinXQXfUsrY = 1717836915; NinXQXfUsrY > 0; NinXQXfUsrY--) {
        BhTyDZB *= WwbwSItlPA;
    }

    if (dPMQsIPh != string("gKCYsFeNKhuwkahOHEXVIHdiNpFdDEMsmocQwiDSUPKgiYWsoPAHJRsKIfgmVYlpMUlbyKiYcZklTUpzlvDaFkJonmhYXqPlVPnpFzTySpDGVNAAhzYea")) {
        for (int sveZjgeAYp = 2135854434; sveZjgeAYp > 0; sveZjgeAYp--) {
            wbMtWddrCoqZkLS += xyTPedfJ;
            iHzdiCmWS *= FrPME;
            zUHwOKR /= zUHwOKR;
        }
    }

    return WwbwSItlPA;
}

int kmNyvOQZywdq::qqoCHEYJBLUKopkm(double HqMcFlrISh, double ATCmxjYI, bool sQhIkHZlRwqqZi, int mgeyuLRlUYs, int DFjHY)
{
    int kTNUcWy = -752852376;
    string rRwPvfTOakUwUp = string("vTMZRgeGwYyhlZuRRIGbcSaFyPJppOtqQHPdhvJzesaBIMpUcamTsvEZwsQvBHydnSfsboPSJMseUkmyraLYYbpTdvNMjSpUTktxQiwcJCBShMLsmmXxWmoLptBSlkYPCHelhtAwDHumssGepmSdTetphWRTfKvazXOuAANmQukvlndzGjoDzWXVBxLjXTnGCsNOYEmzdJfgEzvCUBEckGpckfxBaHolYIufsmmcU");
    bool MvyHdNX = false;
    double OEYaozjFhJgGwDz = -604185.2141851258;
    string clLXOa = string("GRaNCoZyuUqHpILxDbOcryYRUtqvciAekTvprgxxpaNriAmojVylcRlOcOjMiNxjHkavQeymFWaBKXcYnOZPODnlaoUgbXDWKUbedWKfsmFyfcxjtsqNbbVWPSlRfisMkIbXVlHQCnOqAUwWLsWJOVoxU");
    string njTjszgPQMnMUzne = string("zEQEvqyIhgCrUZjvzoDVHlTvtMjSjfiwIDVvhaONxAqWvOZWMQBbPMJpoHUusqQIopnXHVWBKjItYgBGtlvNhCZpyXFScrUaZjOqUmuWaprbWIDnyMCclxyLaqUVkdadQnxqOOAtAiEoulLsfyseigCNVwCyIkXxyE");
    bool zpiOionkUkkpCd = false;
    bool cYMElEfkg = true;

    for (int mrPmMFKhyc = 1156404371; mrPmMFKhyc > 0; mrPmMFKhyc--) {
        sQhIkHZlRwqqZi = ! zpiOionkUkkpCd;
        cYMElEfkg = ! sQhIkHZlRwqqZi;
        MvyHdNX = sQhIkHZlRwqqZi;
    }

    if (ATCmxjYI <= -872310.2246978384) {
        for (int NGUIidzNjCdDB = 745582439; NGUIidzNjCdDB > 0; NGUIidzNjCdDB--) {
            continue;
        }
    }

    for (int gaqvIZes = 190185748; gaqvIZes > 0; gaqvIZes--) {
        DFjHY = DFjHY;
    }

    for (int TisebwtLxm = 711189869; TisebwtLxm > 0; TisebwtLxm--) {
        HqMcFlrISh += HqMcFlrISh;
    }

    for (int ifFimyDhBt = 906362192; ifFimyDhBt > 0; ifFimyDhBt--) {
        mgeyuLRlUYs = DFjHY;
    }

    return kTNUcWy;
}

kmNyvOQZywdq::kmNyvOQZywdq()
{
    this->FgWdczvIQw(476602.0930898046, -101289821, false, true);
    this->GhvLVQWoNNhal(string("GFdmnGiwrctlQzcqVzCpgEEKeNiMjkFsSCFmVUPLDwVnafHVAvNYJsBxOnoiXqanVwkwacvoTnyeiWpuqXtFHVukCXHQolWbipQNYClcGrlTnaRcQEOynjHlpXtBMCMeXUyYZrvgfoxLoBJFbtJAuYEJgpRnjFMuwgpHBFMwf"), -985816.6926035674, -706774.998814061, 765988.4821744577);
    this->lOqxVU(98895.22148588375, -1799374386);
    this->JvEduEtuKP();
    this->OFnmv(-1466541012);
    this->JJNyXksH(-60847.733012159304, false);
    this->kHLLQc(false, string("tyYWXJNlPxtevfpGmdQnGKBxgbtizkdcFjtFKTUyEsaASZ"));
    this->qynwmiY(-1572923683, string("obEHGlGNWLdgDreUuANxVijlIsjoKxSaxFDpCCBvzSIsPtnAUJMlrJekPeVhtEXkmUyjBoYomIxHAxXVgfhHfxMthjnatQjNQlqRkyiVwhbFOKJgUvtNlBuVCU"), -2018601649, 1706368870, -274369719);
    this->cNFFagK(string("DKvsE"));
    this->ntKIYrma();
    this->nOLzRiWUhzXa();
    this->jXUhjDWBmeD();
    this->fvnMbdFqDuUYY(string("gKCYsFeNKhuwkahOHEXVIHdiNpFdDEMsmocQwiDSUPKgiYWsoPAHJRsKIfgmVYlpMUlbyKiYcZklTUpzlvDaFkJonmhYXqPlVPnpFzTySpDGVNAAhzYea"), 215497.55069257566, 795941.5402947321);
    this->qqoCHEYJBLUKopkm(-364831.77287806285, -872310.2246978384, false, -875069259, -1518014205);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NhncSTB
{
public:
    int MKFPgQWjlKAtKI;
    int FeNRnxTiVgbFJy;
    int EbNEPRQlM;

    NhncSTB();
    void isIwlavHGLeUw(string QzEbkOGLM);
protected:
    double vdAYlfQAbiDg;
    double DmbCcpNEx;
    string wNWGhhUoioetDbJj;

    string LMeRSHjO(bool qzOSKqfymCIOBRnp, double glcWEjrBBiEA, bool UuSzEhFJki);
    double RdkaB(string wSGMJZxlpBncJQD);
private:
    int uhbdToYDKfGsdTV;
    double BVwQNtfjLvUN;
    int WtlknHq;
    int RByKQFNKgRZbEa;

    string CpXGpddtn(double tmNKYnfHXROWw, string qvZwwQrMzicDsbuq, double YHiQEuzqqomW, bool UUIbprFNxpGEfAx);
    void UHtXmdpZ();
    double rjYObBfPmDw();
    bool jETjcs(int BrlhgQlcZIi, bool xWfjhsUgLbpwl, string xhACfA, double ZutHrDAO, bool qQLktbKUvGD);
    string kcJyeovdk(double KMhWJNTphfH);
    double ZXGiEUbWqchMh();
};

void NhncSTB::isIwlavHGLeUw(string QzEbkOGLM)
{
    double LUPIBa = 101054.03935250355;
    int UQnuIrg = 168540084;
    string UzzQvkGWDxjCL = string("UptedZKTDJnpWvQCFnkTfMVjBjMUCletxXmKrMMZRtNEEDR");
    int ADMIMDrNZgac = -1630565249;
    bool cieEZvQjBfhqcbsk = true;
    int LSAzEQgbD = 2053470995;
    bool yysuSfnOakMjRaOP = false;
    bool xqBKCWoUuGm = true;

    for (int ySPKyHmFypk = 795088504; ySPKyHmFypk > 0; ySPKyHmFypk--) {
        UQnuIrg = UQnuIrg;
        xqBKCWoUuGm = cieEZvQjBfhqcbsk;
    }

    for (int vSAvmCnJsTAy = 917513568; vSAvmCnJsTAy > 0; vSAvmCnJsTAy--) {
        continue;
    }

    if (cieEZvQjBfhqcbsk != true) {
        for (int QNaJnRyBAdEmF = 2103019300; QNaJnRyBAdEmF > 0; QNaJnRyBAdEmF--) {
            xqBKCWoUuGm = xqBKCWoUuGm;
            xqBKCWoUuGm = cieEZvQjBfhqcbsk;
        }
    }

    for (int LdnvrVEZSv = 2050567879; LdnvrVEZSv > 0; LdnvrVEZSv--) {
        continue;
    }

    for (int LeWYccUgTZXp = 650136172; LeWYccUgTZXp > 0; LeWYccUgTZXp--) {
        QzEbkOGLM = QzEbkOGLM;
        ADMIMDrNZgac -= LSAzEQgbD;
    }
}

string NhncSTB::LMeRSHjO(bool qzOSKqfymCIOBRnp, double glcWEjrBBiEA, bool UuSzEhFJki)
{
    int TjkzaHIVFrCgKz = -1950932472;
    int pMaJxkFCjiBXZJ = -2095178425;
    string lttvwieuvmav = string("wXswVfjnREWYyIzsYkqKDZUlVTbMqRXnjjfeVEOvFPelrtGQfYUZdsroVNzWfByOwxgXmRhpQKuGAJcPkejCnrFuXrbTFARnzAeDkcBfGUIBpAMTSwUtNrNwpvoqazwnTbKawvYJxTyDaKebphwhJWaZqdXaLvyjpyvdPCELLLBUAruGCSrDqeymLrYQxAQaABlPgOHhPQb");
    int SSHVeW = 869728556;
    double UiyGbSGK = -246161.30361062023;
    int fWglXhRYvjfH = 2018054798;
    bool YsxustV = false;
    double EpHJNtNnZVAhVUQ = 610170.020488695;
    int FJgdJDlEPfbv = 193498418;

    for (int cvKvzCVZySTyF = 1171610398; cvKvzCVZySTyF > 0; cvKvzCVZySTyF--) {
        glcWEjrBBiEA = glcWEjrBBiEA;
        FJgdJDlEPfbv /= TjkzaHIVFrCgKz;
    }

    for (int zhsyfkzRysbWoA = 180421786; zhsyfkzRysbWoA > 0; zhsyfkzRysbWoA--) {
        glcWEjrBBiEA *= EpHJNtNnZVAhVUQ;
        FJgdJDlEPfbv -= FJgdJDlEPfbv;
        SSHVeW -= SSHVeW;
        SSHVeW -= pMaJxkFCjiBXZJ;
    }

    for (int eVusbocKmrBTailA = 225444068; eVusbocKmrBTailA > 0; eVusbocKmrBTailA--) {
        pMaJxkFCjiBXZJ += FJgdJDlEPfbv;
        EpHJNtNnZVAhVUQ += glcWEjrBBiEA;
        glcWEjrBBiEA += glcWEjrBBiEA;
    }

    for (int GPXlxmufFh = 447462792; GPXlxmufFh > 0; GPXlxmufFh--) {
        fWglXhRYvjfH /= SSHVeW;
        qzOSKqfymCIOBRnp = ! UuSzEhFJki;
        pMaJxkFCjiBXZJ -= fWglXhRYvjfH;
        UuSzEhFJki = YsxustV;
        UuSzEhFJki = qzOSKqfymCIOBRnp;
    }

    for (int beelkHLiEQeIq = 2122532153; beelkHLiEQeIq > 0; beelkHLiEQeIq--) {
        qzOSKqfymCIOBRnp = ! UuSzEhFJki;
        YsxustV = ! qzOSKqfymCIOBRnp;
        TjkzaHIVFrCgKz *= pMaJxkFCjiBXZJ;
    }

    return lttvwieuvmav;
}

double NhncSTB::RdkaB(string wSGMJZxlpBncJQD)
{
    string MhZOvmSBItl = string("cDqdXhcFYSiEBeCBDwxHqdWTuUYZSDJcXWJGoVOGHFOhdvmgljOtamqiLnpUuKGCoqAZFevPxTCROrIudKgHmWpWAijgJYFpvbJQkswujlXTkqkITuBLaPMopyjCjNhsydsYPNNwfuYTTkzIhYfjEjKCNkNYYFHCSyCUkZXliGMjQgLOsBoMywfNYpPYFEkPEkXiHrDZtOltMuxARAaopkVbmaehhWRYfzr");
    bool ZvupuCYSwQsCE = false;

    if (wSGMJZxlpBncJQD <= string("OADRTefnceRFwK")) {
        for (int FBMkmhdmklzvUZlD = 2141745890; FBMkmhdmklzvUZlD > 0; FBMkmhdmklzvUZlD--) {
            ZvupuCYSwQsCE = ! ZvupuCYSwQsCE;
            wSGMJZxlpBncJQD = wSGMJZxlpBncJQD;
            MhZOvmSBItl = MhZOvmSBItl;
        }
    }

    for (int bLriuhSFDpLnYh = 23790588; bLriuhSFDpLnYh > 0; bLriuhSFDpLnYh--) {
        MhZOvmSBItl = wSGMJZxlpBncJQD;
        wSGMJZxlpBncJQD = wSGMJZxlpBncJQD;
        MhZOvmSBItl += wSGMJZxlpBncJQD;
        ZvupuCYSwQsCE = ! ZvupuCYSwQsCE;
    }

    for (int SaMViKwRKvcK = 377019918; SaMViKwRKvcK > 0; SaMViKwRKvcK--) {
        MhZOvmSBItl += MhZOvmSBItl;
        MhZOvmSBItl = wSGMJZxlpBncJQD;
    }

    for (int HJfUVQgsETKY = 2016987273; HJfUVQgsETKY > 0; HJfUVQgsETKY--) {
        wSGMJZxlpBncJQD = wSGMJZxlpBncJQD;
        wSGMJZxlpBncJQD += MhZOvmSBItl;
        wSGMJZxlpBncJQD += wSGMJZxlpBncJQD;
    }

    for (int NUotKtl = 654117385; NUotKtl > 0; NUotKtl--) {
        wSGMJZxlpBncJQD += wSGMJZxlpBncJQD;
        wSGMJZxlpBncJQD = wSGMJZxlpBncJQD;
    }

    for (int uuktYeenhJoqXqfL = 541134309; uuktYeenhJoqXqfL > 0; uuktYeenhJoqXqfL--) {
        ZvupuCYSwQsCE = ! ZvupuCYSwQsCE;
    }

    for (int xhjFHukU = 1212005043; xhjFHukU > 0; xhjFHukU--) {
        ZvupuCYSwQsCE = ! ZvupuCYSwQsCE;
    }

    if (wSGMJZxlpBncJQD >= string("OADRTefnceRFwK")) {
        for (int TMSVfJSndSBs = 917528329; TMSVfJSndSBs > 0; TMSVfJSndSBs--) {
            MhZOvmSBItl = MhZOvmSBItl;
        }
    }

    return 896084.7427680206;
}

string NhncSTB::CpXGpddtn(double tmNKYnfHXROWw, string qvZwwQrMzicDsbuq, double YHiQEuzqqomW, bool UUIbprFNxpGEfAx)
{
    double JYTdHpN = -23423.299068198932;
    int mvXflKLQXZEm = 413431119;
    double pxbJazzwNQ = -420493.26997971965;
    bool OvWzalKfXmEKoTIv = false;
    int nLLTxa = 1684866621;

    for (int HHYUQtjnvGZWFAk = 895740436; HHYUQtjnvGZWFAk > 0; HHYUQtjnvGZWFAk--) {
        tmNKYnfHXROWw /= JYTdHpN;
        YHiQEuzqqomW /= JYTdHpN;
        YHiQEuzqqomW -= JYTdHpN;
        nLLTxa /= nLLTxa;
        YHiQEuzqqomW /= YHiQEuzqqomW;
    }

    for (int orlrRvcKgYTCXXY = 1615147854; orlrRvcKgYTCXXY > 0; orlrRvcKgYTCXXY--) {
        UUIbprFNxpGEfAx = ! UUIbprFNxpGEfAx;
        YHiQEuzqqomW = tmNKYnfHXROWw;
        UUIbprFNxpGEfAx = ! UUIbprFNxpGEfAx;
        nLLTxa -= mvXflKLQXZEm;
    }

    if (YHiQEuzqqomW < -508267.74770700396) {
        for (int SRPwjBBePyPlJ = 1761572592; SRPwjBBePyPlJ > 0; SRPwjBBePyPlJ--) {
            continue;
        }
    }

    for (int oFBJXsupRWRXr = 194595698; oFBJXsupRWRXr > 0; oFBJXsupRWRXr--) {
        tmNKYnfHXROWw = pxbJazzwNQ;
        pxbJazzwNQ *= YHiQEuzqqomW;
    }

    return qvZwwQrMzicDsbuq;
}

void NhncSTB::UHtXmdpZ()
{
    bool LyuPjkLSsmfnU = false;
    int fgnsnAOLZfy = 803390129;
    string ufnTmNEBOtD = string("hTpcuINvCiBMchjKdHRIzKLWgnPfgOGBAfkBJAbbLMtGtstaKvQRyadbPhLYdfgbZBLbTzCjzCLKetaqDVpyaFZBZABYaeXhJhDtiGGVMunIYGnddTOwkARlyMQbJYlbsdJYYkSSdruqlOSmYZNDXMVyDuydhDbPqRztcmnhphQqGnHacgQzGqLIfJglkeFfLAzbxULpgRsG");
    double DKDcIncwGETMsIh = 515032.7089722559;

    for (int fXzDkguS = 536018294; fXzDkguS > 0; fXzDkguS--) {
        ufnTmNEBOtD = ufnTmNEBOtD;
        ufnTmNEBOtD += ufnTmNEBOtD;
    }

    for (int RNqzACI = 1239041941; RNqzACI > 0; RNqzACI--) {
        ufnTmNEBOtD += ufnTmNEBOtD;
        LyuPjkLSsmfnU = LyuPjkLSsmfnU;
        LyuPjkLSsmfnU = LyuPjkLSsmfnU;
        LyuPjkLSsmfnU = LyuPjkLSsmfnU;
        DKDcIncwGETMsIh *= DKDcIncwGETMsIh;
    }

    for (int JavtGrDFnGKYwYVf = 1524369410; JavtGrDFnGKYwYVf > 0; JavtGrDFnGKYwYVf--) {
        DKDcIncwGETMsIh *= DKDcIncwGETMsIh;
        ufnTmNEBOtD = ufnTmNEBOtD;
    }
}

double NhncSTB::rjYObBfPmDw()
{
    double GyQVNGTETdzlS = -418950.0645785556;
    int ouXuyokbRAudhaBZ = 482897850;
    bool NNsXGcmix = false;
    string eSAZbhny = string("ygQzjLkWNNafIJIqKqYRzlPyZNAKEUZicKxNSnDlanoVPRLENKsSdJfKTOCogmMASmRPKjpeuycTPFfrGXTHAZBLuurzPvZPCyDaM");
    double BjAzuVvEjOOiktAW = -917320.317312199;
    string WcGlfcVMftrf = string("evxVrTnyANAsFdtyJejEoLEiPiaCAMUOirHsLsZGRfJodiDFnQxXfkvHVZwficFAbgmMqxZLrgrFcOTGWEyUDWsvLBxvFwAKoLLWOCNjZpyXFsSTRIzdCmBIAtfuPYgxNlNDzMNdyYlgScaPWpaHerLFXdLDdnAeUPchEYrJUutYAADYgaWUQrenK");

    for (int EquZSFDB = 111921218; EquZSFDB > 0; EquZSFDB--) {
        ouXuyokbRAudhaBZ *= ouXuyokbRAudhaBZ;
    }

    for (int PGXGMPRNTkYL = 1538164979; PGXGMPRNTkYL > 0; PGXGMPRNTkYL--) {
        continue;
    }

    for (int WUNcjYYX = 364216652; WUNcjYYX > 0; WUNcjYYX--) {
        BjAzuVvEjOOiktAW = BjAzuVvEjOOiktAW;
    }

    for (int SGteoZaAjBPGQLT = 684548924; SGteoZaAjBPGQLT > 0; SGteoZaAjBPGQLT--) {
        WcGlfcVMftrf += WcGlfcVMftrf;
        BjAzuVvEjOOiktAW -= BjAzuVvEjOOiktAW;
        BjAzuVvEjOOiktAW /= BjAzuVvEjOOiktAW;
        GyQVNGTETdzlS *= BjAzuVvEjOOiktAW;
    }

    for (int fPvbBBkfY = 2145471633; fPvbBBkfY > 0; fPvbBBkfY--) {
        continue;
    }

    if (WcGlfcVMftrf <= string("evxVrTnyANAsFdtyJejEoLEiPiaCAMUOirHsLsZGRfJodiDFnQxXfkvHVZwficFAbgmMqxZLrgrFcOTGWEyUDWsvLBxvFwAKoLLWOCNjZpyXFsSTRIzdCmBIAtfuPYgxNlNDzMNdyYlgScaPWpaHerLFXdLDdnAeUPchEYrJUutYAADYgaWUQrenK")) {
        for (int nMmZccmLcAWRbpIU = 1606985478; nMmZccmLcAWRbpIU > 0; nMmZccmLcAWRbpIU--) {
            GyQVNGTETdzlS += BjAzuVvEjOOiktAW;
        }
    }

    for (int sZwxLmRP = 1858485844; sZwxLmRP > 0; sZwxLmRP--) {
        eSAZbhny += WcGlfcVMftrf;
    }

    return BjAzuVvEjOOiktAW;
}

bool NhncSTB::jETjcs(int BrlhgQlcZIi, bool xWfjhsUgLbpwl, string xhACfA, double ZutHrDAO, bool qQLktbKUvGD)
{
    double CQrXwDjrjIsRu = -428804.9014407168;
    string qqWGh = string("NKkpGExdXgxZQsMLMslCC");
    double NGdWmzylNVnp = -125394.06168603705;

    return qQLktbKUvGD;
}

string NhncSTB::kcJyeovdk(double KMhWJNTphfH)
{
    string yIpobpJJxW = string("PEWWtpiWGssWWIFXnIdPPpsxdhSuEtcKkPzqERijPEvOgYqUorkDBfkwDBAkjWuAQRVGANNJsnlLYkbCbmDAoAvJPcf");
    string catXAscgS = string("TBqicXPjyuMquOoPbssKNblnjupQgQBTILOMFgZGJfztooOJruWxnhxFMqDdWWjZAyVrmzuEEIiHeSDnMsqxACkd");
    double mQFGYnFjonJnyt = -988479.4197727543;
    double IdOUVmQRzgKjk = 701583.8922130901;

    for (int youmULAEpUz = 384700580; youmULAEpUz > 0; youmULAEpUz--) {
        catXAscgS += catXAscgS;
        mQFGYnFjonJnyt = KMhWJNTphfH;
    }

    return catXAscgS;
}

double NhncSTB::ZXGiEUbWqchMh()
{
    string GBMiFBeagrT = string("vEEMclyKiNVkVUCCcsHInVxxXYFKRBbLEaZTjLALretanaaFlOwTbApYmVVfhbKWHekIHoKWtzFBbgKuTDxTQpfUvkEasMlWmpiMomfQQSYVHCgnxWmaRhbagFPNaclAuzhRPMtNgNbIrSHVXzCqo");
    double LArKdvukYvqS = 443463.6764267599;
    double yKzrmuQsvQOPV = -868667.0712807943;
    bool DBQAJ = false;
    double naVGYRJDUBqoe = 999623.7861092814;
    bool zfdidGayhiHHpj = false;
    double eYZovH = 132098.57662293522;

    if (eYZovH == 999623.7861092814) {
        for (int NmMpfDdP = 1642732753; NmMpfDdP > 0; NmMpfDdP--) {
            naVGYRJDUBqoe = LArKdvukYvqS;
            eYZovH += eYZovH;
            naVGYRJDUBqoe *= LArKdvukYvqS;
            DBQAJ = zfdidGayhiHHpj;
        }
    }

    if (DBQAJ != false) {
        for (int qAjjOJIjWtJ = 1464404536; qAjjOJIjWtJ > 0; qAjjOJIjWtJ--) {
            naVGYRJDUBqoe = naVGYRJDUBqoe;
            yKzrmuQsvQOPV -= eYZovH;
            GBMiFBeagrT = GBMiFBeagrT;
            LArKdvukYvqS += naVGYRJDUBqoe;
        }
    }

    return eYZovH;
}

NhncSTB::NhncSTB()
{
    this->isIwlavHGLeUw(string("MKecIlKmYDhjZkmGdpGYiTSccadYyzmbCHsjPXKPvNsUPPtAkCoPSybgALtWrdFtrgvGZzTmGVwpcPhGYskukauulPjxJXjYvKDuDiuLlxJrjKionoOwDysethWJPIcSAmFfUbidIoxIrllrWYLFSxb"));
    this->LMeRSHjO(true, -273695.93413860747, false);
    this->RdkaB(string("OADRTefnceRFwK"));
    this->CpXGpddtn(-420478.25914355635, string("kfgJgPGSlvliqABvyDHOYSMiKFCABbCJeHNUviDVOaVdhrZDxrcrfWcvNOlZQNtOKcMzTbIJHxRQkTVxIcDjmKgqQAELGYuEbQdIqaafRKdFqdGltXpJySgptCDFzapoLNaCGpCUWTkVbLZbVvLExVFCvrHzRVJZWOgxLuaAqSmbKDxIyUGBGNRdmRqlBkfMyAyhziVbBjaRcWzllLBYSCctm"), -508267.74770700396, false);
    this->UHtXmdpZ();
    this->rjYObBfPmDw();
    this->jETjcs(1220632433, true, string("UNdoyopzbKUgbQSrleX"), -798919.5184272713, true);
    this->kcJyeovdk(-1025090.0573912722);
    this->ZXGiEUbWqchMh();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kjlEQvGHSgSXRbac
{
public:
    double bkjKpFeIx;
    double JPODo;
    int kSECfSVmg;
    bool NboXToPahNDSdM;
    double KthQHxBzdnCrkFh;

    kjlEQvGHSgSXRbac();
    int fcrsnJiIi(bool ohwTI, string KBZWiHatOzyeCLDf, string ZypvPhUQ, string ZizTLqcJpPm, double sAuEBv);
    string ODYVjXRSXosAn(int MtpjuClXCykKQ);
    int tuikOfnMBxoCDPsp(string iACIydFNHFb, string RiyZiYNjKdBWZj, bool fAKTGrIsjeHAMB);
    string tRyFEsHrilqw(int FEHIoBEhDNiyL, double DRgtWlsnhkwTQ, string MOchnHrbJTC, string DmnbSKRVEv, bool yxnYwesgsTFGw);
    int MDoyoZXs();
    string inRkmOyZmK();
    void RpkgBGrVjEoFNEmU();
    double ooVJMBqUHnR(int THyvBMzPRwt, bool FRBhpcmpJhX);
protected:
    bool wawlDlvjpQhEJV;
    string TnYvbsDnPUbqewQ;

private:
    bool YwyaorJtYdlqAcKu;

};

int kjlEQvGHSgSXRbac::fcrsnJiIi(bool ohwTI, string KBZWiHatOzyeCLDf, string ZypvPhUQ, string ZizTLqcJpPm, double sAuEBv)
{
    int fiTGHy = -392606783;
    string osKdfifnBAihvMFu = string("kMkkuePJNGTjZaEKEfDtWOttUxHgtPDpMOBzJoStBmqPpVRGvKJONVvdvsxOCdMqQZUXLzHLUXLBkNAhJkcbYyIylVcwdnXpQtrGoVXADClTJFXomJWFvYIikjNnpozIeVNkhJiscyXdHOHjrhWerIGdQbQANJQNVfGeJXoKFCNshXcZsCaqvnDWqBxlFZLZUPXDctwGAYIQWMmpLVPpKSomiGufXJQ");
    bool kHktNvNw = false;
    int AMFol = 698219811;

    if (KBZWiHatOzyeCLDf != string("kMkkuePJNGTjZaEKEfDtWOttUxHgtPDpMOBzJoStBmqPpVRGvKJONVvdvsxOCdMqQZUXLzHLUXLBkNAhJkcbYyIylVcwdnXpQtrGoVXADClTJFXomJWFvYIikjNnpozIeVNkhJiscyXdHOHjrhWerIGdQbQANJQNVfGeJXoKFCNshXcZsCaqvnDWqBxlFZLZUPXDctwGAYIQWMmpLVPpKSomiGufXJQ")) {
        for (int mujkD = 617506469; mujkD > 0; mujkD--) {
            fiTGHy = AMFol;
            osKdfifnBAihvMFu = KBZWiHatOzyeCLDf;
        }
    }

    for (int SJPzgPMyU = 1061082519; SJPzgPMyU > 0; SJPzgPMyU--) {
        ZypvPhUQ = osKdfifnBAihvMFu;
    }

    for (int edCsPjqfwmrMK = 832885834; edCsPjqfwmrMK > 0; edCsPjqfwmrMK--) {
        sAuEBv *= sAuEBv;
        AMFol -= fiTGHy;
        kHktNvNw = kHktNvNw;
    }

    for (int PtnzoBDSSfjA = 1718709523; PtnzoBDSSfjA > 0; PtnzoBDSSfjA--) {
        ZypvPhUQ += ZypvPhUQ;
    }

    return AMFol;
}

string kjlEQvGHSgSXRbac::ODYVjXRSXosAn(int MtpjuClXCykKQ)
{
    string NBcDDNPKs = string("sEQNAwqnoGfUxcxyUHNnutTAjIaFileSTbGuxsBXnSiOGNFJZkTFZObmiMKcteczjtvENEsdRPRRWgFaMWhMvhoaXqkXQMWHyoXpPNtIfdmlPoSyHttxJdBiPDNhAmBBwJthGlNWEEYkYaiBDCAyU");
    int aqyHGkWFvdYfHnO = 1975931312;
    string PzWFMyEQxX = string("xIwLaaiFlYzwHC");
    bool qQebGyZiqiqSameu = true;

    for (int TeEhz = 2136061538; TeEhz > 0; TeEhz--) {
        NBcDDNPKs += NBcDDNPKs;
    }

    for (int bEBAXh = 1418088501; bEBAXh > 0; bEBAXh--) {
        PzWFMyEQxX += PzWFMyEQxX;
        NBcDDNPKs = NBcDDNPKs;
    }

    for (int zhVlxzYxJOqZnQr = 762039009; zhVlxzYxJOqZnQr > 0; zhVlxzYxJOqZnQr--) {
        continue;
    }

    for (int CHLDQv = 1167566857; CHLDQv > 0; CHLDQv--) {
        MtpjuClXCykKQ /= MtpjuClXCykKQ;
        NBcDDNPKs = NBcDDNPKs;
        NBcDDNPKs += PzWFMyEQxX;
    }

    for (int RmWGTWbi = 1472680923; RmWGTWbi > 0; RmWGTWbi--) {
        NBcDDNPKs = NBcDDNPKs;
        PzWFMyEQxX += PzWFMyEQxX;
    }

    if (PzWFMyEQxX >= string("sEQNAwqnoGfUxcxyUHNnutTAjIaFileSTbGuxsBXnSiOGNFJZkTFZObmiMKcteczjtvENEsdRPRRWgFaMWhMvhoaXqkXQMWHyoXpPNtIfdmlPoSyHttxJdBiPDNhAmBBwJthGlNWEEYkYaiBDCAyU")) {
        for (int THTyLKoKR = 936657371; THTyLKoKR > 0; THTyLKoKR--) {
            aqyHGkWFvdYfHnO = aqyHGkWFvdYfHnO;
        }
    }

    if (MtpjuClXCykKQ != -585641037) {
        for (int gtkoIOxoQZm = 1334641974; gtkoIOxoQZm > 0; gtkoIOxoQZm--) {
            PzWFMyEQxX = PzWFMyEQxX;
        }
    }

    return PzWFMyEQxX;
}

int kjlEQvGHSgSXRbac::tuikOfnMBxoCDPsp(string iACIydFNHFb, string RiyZiYNjKdBWZj, bool fAKTGrIsjeHAMB)
{
    double RnjyCzs = -557410.9026963465;
    int iHulcbA = -1737074712;
    string UaStldrl = string("ZpnTGPVxBYegWtxZXEqjBRYDwfbDxqbLPWaFUWUSYPeSYDPDxoSpnElDWWdWoJmjEJprMRIUNFEpMoclumZzhckmoBTySZxoaScyykLoTZPFFpFhwEUIXfvmqXjOrnUZmSannfbtSqfTRbWjXlIQLYncmPvRVUFsMmDuctWQ");
    double hevAJwnAyBSPGCe = 31616.548373346974;
    int cdOFMdCNoayVlWul = -564247244;
    int youOFvWwTIVEna = 2093607552;
    string GVrKUgno = string("FXQluoxYArspWrAVvibyWUZHHMMiNbUpQdRgvgqASWfSoMRzvxbOFRmfozlUGfvKtEktGDGeBZUyJoxUtc");
    double QKwxUTQxKvADe = 336895.9980704;

    if (UaStldrl == string("pwKKqacuOyvQyaVknflpcFmkvnaxKiQZjWNxDAAAYUTOIwQilhFcoaLgODEyPixAmwfRLgUhLKDdxiFAcTFAwOdsmxlMgpFCzIcRtAHvSULYwzcFLKxBVhcNXfpNDmMYyBwUxyXEfYwzNcxHgJhBrAjZigXhfFwkK")) {
        for (int tIbLd = 1474413471; tIbLd > 0; tIbLd--) {
            GVrKUgno = RiyZiYNjKdBWZj;
        }
    }

    for (int IEISRu = 810231136; IEISRu > 0; IEISRu--) {
        GVrKUgno = GVrKUgno;
        iHulcbA += iHulcbA;
    }

    if (QKwxUTQxKvADe == 31616.548373346974) {
        for (int kCBJF = 1575011324; kCBJF > 0; kCBJF--) {
            GVrKUgno += GVrKUgno;
        }
    }

    return youOFvWwTIVEna;
}

string kjlEQvGHSgSXRbac::tRyFEsHrilqw(int FEHIoBEhDNiyL, double DRgtWlsnhkwTQ, string MOchnHrbJTC, string DmnbSKRVEv, bool yxnYwesgsTFGw)
{
    bool BcRlBQcBvMPN = true;
    bool zagJzb = false;

    return DmnbSKRVEv;
}

int kjlEQvGHSgSXRbac::MDoyoZXs()
{
    bool zbRFAcEWpxvj = true;
    string PBPmfkhJf = string("ERfkmToYrqkeHubWdciUHydTKnkQgARuellabiIgkhkZBQFHaNzGQxGHdVAoFOKMmUFvkxlvXpOkXEtjWuKiFPToMSaDzJzHarSMwXRNidPmsQOhydoplfRZTzmFaCWrmglJZqBXviLFaQKqTwAPpVVvGVThySDXDPKGuqTrbTVSDvykaOgxjXgVMjmeCdasIAYqoTkXcIudMGtPCpYUaBQGiptRfjrqKsyfUdRmxmdQQpceYgZJrrV");
    double dZAlYaum = -690174.6064457784;
    bool fdqEFfTLQtIR = false;
    bool DQWaeyAZhTT = true;
    bool nKrJd = true;

    return -630226850;
}

string kjlEQvGHSgSXRbac::inRkmOyZmK()
{
    string qJnECuRn = string("uiQkneavaVRtTFyYglNiYBMSHcYwptCBZQLEyjbtyyZpaEWYyjiDEnFZBCycnJgoJrjeMHVtgEFqYrOMBguMVyuZfEjfmbLRyKfHyDafpZmwpkaOHxuTNIdpIInqhYOWXxsEWOMJRLjVdkRXhVBxLIycmbjGqVhNuFCIKLnkusemiLlTibCZkZHWTUKguqADUGpUzyaa");
    int PCvyexYKGCaOkPx = 920392984;

    for (int aywZwClQzaLhjp = 482949893; aywZwClQzaLhjp > 0; aywZwClQzaLhjp--) {
        qJnECuRn = qJnECuRn;
        qJnECuRn += qJnECuRn;
        PCvyexYKGCaOkPx = PCvyexYKGCaOkPx;
    }

    return qJnECuRn;
}

void kjlEQvGHSgSXRbac::RpkgBGrVjEoFNEmU()
{
    double buAJxBTUIZzhrN = 1005857.5187384326;
    string aDvFOcBCJxgLo = string("siPjuaLlYGUjzTMoIulAhbivvPXHkjMXWnFSJwNQNTHdaRiVpmODUNVfZXZnijYCZPMbmhDFlBPSbxsUKVIPYAvdQJwTAqXbyqDQdBPFvKhfMbidwChFAP");
    bool PNVUK = true;
    double xNLSczO = 931321.4693963017;
    string eIcNTN = string("YURhiGEwkLZHLCaVyGAsqgQXhAjkVTaldNXydYAJrHqr");
    string gdWViTup = string("SJYzbJuuAwetXmSwLPOwwiJTOTyFOSoFrqtBgXOhTQfkDApUVVfOwsicGNXUiIOscXJDvLvZILbhVRQpbtdkpWuMQSmAscctIfteEDrekCGheKbAshcEAyZNDyPaSwWMYAZNkcoXswMCVptIHBIpFOloebnpIuIYMpYuKjxQ");
    int NylHahNDVsjGV = -1486862072;
    double wootQqxE = -955507.0165479392;

    for (int JSfkSETAcHnFIk = 415806467; JSfkSETAcHnFIk > 0; JSfkSETAcHnFIk--) {
        wootQqxE -= xNLSczO;
        buAJxBTUIZzhrN = buAJxBTUIZzhrN;
    }

    for (int VGKuNapcyQmyvi = 718601387; VGKuNapcyQmyvi > 0; VGKuNapcyQmyvi--) {
        aDvFOcBCJxgLo = aDvFOcBCJxgLo;
        PNVUK = PNVUK;
    }
}

double kjlEQvGHSgSXRbac::ooVJMBqUHnR(int THyvBMzPRwt, bool FRBhpcmpJhX)
{
    double XmByrL = 575973.0844921765;
    bool oQkwQKfoohhISf = false;
    bool DqMrP = true;

    for (int snHOoOxMKRgu = 1706682993; snHOoOxMKRgu > 0; snHOoOxMKRgu--) {
        continue;
    }

    return XmByrL;
}

kjlEQvGHSgSXRbac::kjlEQvGHSgSXRbac()
{
    this->fcrsnJiIi(true, string("fQuCsQYOQRzlGOCCXuOtEODNlIDaDmwihGscFbiogzSGyaGkDsHOnsbMStTlZiKxsHtBJMfFDyWKxKZbXedkNzKPHtfZbJjELXwmSCaIMTpZvFBZhrmTEfKctIWZZOJAwMuEqdqMuapUDEkTGKgwSvffDnBBBIcRlQxWQPyUCOSVMhLIaBsIyCQxkecFtJVNjRxWTaUgyoXMLl"), string("OmipZJoQQReuGJcXmofjtBfKQuEwULlADMUYwsGSQiXiJfqphWovaydgUntzUAhBfShEbTIAkhPIefFLQvzxAzeFYezp"), string("mhfEZtIbjIiqEBETAVwXcEyZETDkblKnXfqUwyXonbgtqYFgdBLhFHwlEEpNZlZZiiiiGWhAOwBkbzaSqjjKYZbJvGKvOWpwFYZXykEotJJYgSUGJMgCkrptcqElyddnvvFZmFAMlwTlhoPZxnYCIYjPAvLZjegfQfroGxTiCuSwZZkEksVmDfaststGhuXvlWWiUlECYEiZqvUN"), -280353.6335617363);
    this->ODYVjXRSXosAn(-585641037);
    this->tuikOfnMBxoCDPsp(string("pwKKqacuOyvQyaVknflpcFmkvnaxKiQZjWNxDAAAYUTOIwQilhFcoaLgODEyPixAmwfRLgUhLKDdxiFAcTFAwOdsmxlMgpFCzIcRtAHvSULYwzcFLKxBVhcNXfpNDmMYyBwUxyXEfYwzNcxHgJhBrAjZigXhfFwkK"), string("PDhOdXlfiNXNvqSZhtXZJOMObKwXIKUwfLyGuZZcfXMhtLuscyRYctehFbZsrioVKKJHglsMNqhkrgzJsJNHlEghsYQBZundmEaCrIRlLcNfaabBNjgMzLnOKDctoHYmZgRZxSdSlgRAJqQrzfKuxKZDeTqaVxrcyIhh"), true);
    this->tRyFEsHrilqw(-1695108720, -862211.4934174666, string("pDNyRqvxqzCgkqhSwoNGxojWfOBbBTLPGjIyXOtrZBmQrZAroPyxQZNwzvUiDsuRDLKnArDBlIaNaOlzGqznOkdyuoqzJvVRoIYiVteqsZLuNhqHdTxBOlsMyjOOSHkyOaSLhePwkiGSqDBrjxPqbyWGOShfOXCf"), string("SEZHvpxNTlemNFcEOiykJhNboaVkqWeQXqLbWfJuccpEhvtlEjWzhhBlfKuPInusHwUjCbyTscgQAjnqioUevdVjTBSyybdljBvjzGohACjgpShvsIUvmOZJRHaWuEgzLGAMXAYSaanKsafyQOyNQvpGI"), true);
    this->MDoyoZXs();
    this->inRkmOyZmK();
    this->RpkgBGrVjEoFNEmU();
    this->ooVJMBqUHnR(1058213257, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VxtSma
{
public:
    bool NjNTv;
    string IxgYHcpeLSTDRk;
    int FtvIBIqkTeR;
    bool wngxvYTtTGj;
    string grWdnJpZMq;
    int nblpGCF;

    VxtSma();
    bool MeCKueptWoAnOaNz(bool KuxIzjjkZ, int pqKBRaSpZjcq, bool KcpaKjKkNhfuU, bool ERyNDSL);
    void njDAnjPqybVIiIGX(int KIltyjuUQuW);
    double DWWNwtEL();
    bool czNLzhnAhRFASVKA(int xUNTgBtqMEHhlLv, string epqXJWUR, double RAViIsmNbCbbyHm);
    string fmgfmDXZ(bool wcPqpLuVHQtUJQ);
protected:
    string MiExXSvkQrsv;

    string jQuacEyIYuq(string tBHwwnabnhdrVuq, double VPfaQzYbBaBpdaQL, int xnJMJ, string KjktlQLh);
private:
    double bCNZeSBWm;
    int iGjSFzBsnunXj;
    bool YOjagcCxB;
    string znedTvDDmzfdo;
    double tRJgqBkvpfNOVa;

};

bool VxtSma::MeCKueptWoAnOaNz(bool KuxIzjjkZ, int pqKBRaSpZjcq, bool KcpaKjKkNhfuU, bool ERyNDSL)
{
    bool REgJAKt = true;
    double TqLSSJ = -889776.0862768035;
    int RRbOfYQvUyPeSs = 1702173922;
    string rGMgVfOQPdiq = string("fFTtyIeziflRnRByngCwzhRpGpxwiindPFhZPGSoBOlwoeFhAYNiLKkmTUMoUvGFKywssXvQKGetaEMsndioWGCSwytVNrOIIzQUQhcIiKZwoGnkXEUdpDnOfoAolFudLjOxDBDCSiuZMsuYiyvjBHcbyvRhwUpGeaMzLFnsNFhSsIyrfTzwTCRvwLZOhTvgPr");
    double HOgZPboPhg = -905863.6754156809;
    int yvQFP = -2091878985;

    for (int pbwmPzV = 493262025; pbwmPzV > 0; pbwmPzV--) {
        KuxIzjjkZ = ! KuxIzjjkZ;
    }

    if (yvQFP >= -2091878985) {
        for (int DSxFuHUI = 1671699771; DSxFuHUI > 0; DSxFuHUI--) {
            continue;
        }
    }

    for (int aieEcUl = 297836148; aieEcUl > 0; aieEcUl--) {
        pqKBRaSpZjcq /= RRbOfYQvUyPeSs;
        HOgZPboPhg -= TqLSSJ;
    }

    return REgJAKt;
}

void VxtSma::njDAnjPqybVIiIGX(int KIltyjuUQuW)
{
    int XlARdcx = -968813577;
    string ljtTRXZce = string("YGRgxIRxjBKIPBoUwiAvkbvanm");
    string TLlHWpGUOs = string("vSlFJsRKxFOSELBHuSHRRBWKwrTsfNffsKlzSIfWtxxaFvJJxzQnoIkaOSmIGoVpaYzXXrkpqAnXLxEWLrbOuLxZFTGcGDWszWOHohKyv");
    string YpXaSzzl = string("wIggfqcYsTwMQWeqIDzMBpIxqyHbtRFwvvKMbJnBqahuBuUOATGPuJiFSlYlipvlOOmIHbZbgaamXMcZErRThJQEtNRMbmrpIOGHeySuoxoDmRbOUaawuOWpqpEZFwGeClVvFTiiLFbZJVTxAikQXqFIxxDIMrKSIhGdyVrmtrLCnQxlBbagRxVwgEHeWnJiprlzTvnkEfCdAKsW");
    string juFrKWYoQEtP = string("mkBzkJovUKmNcGvzanfKYMikTDBIGTYLUOjzELseFyYpjeBVdXRvcpHRqKNLVeipokWAmQHBhUwClPzpxLHWYMssquRPPABW");
    string lEsTIDAdwgEvQXrr = string("aPRpWMpXrtvizugXYcOvwjHdyclgbpGAIgfSHxMYUdCrIdgTkxskYbMcuNMIFMExrCzEGawssJeypWmHECmdlpsqzrikunMyPtYjtXzUwaTnMvflmPBMBDAfEzVdfaNRxujHLx");
    bool nzbWvRExDeuB = false;
    string aUdjAx = string("psCyFcPoYDZIQgSfXnkcuBaxTuwpwWhLSQLHsLWRKASMlnvXlvkaLSViAKmZHRQdyvNtGvyUNdQZqXfOLqCqSZIJlEHnnjICueewzQWzTeStweyjmUyuZGtFgvXcmWGfXrFpWz");
    double ZuPGLOwBedIbyCCD = -301793.64226120315;
}

double VxtSma::DWWNwtEL()
{
    bool ybtoaWMIAjA = false;
    double wICkUwKfM = -954155.7231293622;
    bool oJvIPZYcNE = false;

    return wICkUwKfM;
}

bool VxtSma::czNLzhnAhRFASVKA(int xUNTgBtqMEHhlLv, string epqXJWUR, double RAViIsmNbCbbyHm)
{
    bool MjBQorU = false;
    string ZXsTygfbnvwZjOT = string("WYlhPOibzZtJHLIPQGoJOMYcfOcjDzcuCcdBSAxbeWXHaFqqbnCBmUMbJMQIEHMiZAHNzXLlmDHRxFpfVJELnXBCLABJAIiONWSZQtOPhoYZylWfikHKFMEvjOhdAnkHBkgiRtcVbpbGVvtEJynAbOAuydf");
    double WlrdUogMSaG = 680955.1276930426;
    int cIwyYIgieoyEZe = 1769822993;
    bool GyRUhNrvoRcb = false;
    bool RNClhTiohV = true;
    bool dQsXjc = true;
    double UlNyTsizxTZ = 489973.6395601737;

    for (int TFWeeCpcJw = 218257447; TFWeeCpcJw > 0; TFWeeCpcJw--) {
        continue;
    }

    for (int jVHsezZlsvIhTbE = 192711996; jVHsezZlsvIhTbE > 0; jVHsezZlsvIhTbE--) {
        GyRUhNrvoRcb = ! RNClhTiohV;
        GyRUhNrvoRcb = MjBQorU;
        RNClhTiohV = ! dQsXjc;
    }

    for (int MBgMBMtQ = 1008488266; MBgMBMtQ > 0; MBgMBMtQ--) {
        RNClhTiohV = ! MjBQorU;
        RNClhTiohV = ! RNClhTiohV;
        epqXJWUR = epqXJWUR;
    }

    return dQsXjc;
}

string VxtSma::fmgfmDXZ(bool wcPqpLuVHQtUJQ)
{
    bool JhsleacuHSDmb = true;
    string FoGXOC = string("nneqZPBXwJcVbrfwijdPKnjNfmHUexPJxiqScbsGTYXEbFhIaMibScrjIqcOoTgGDNAwdIGdubqPqVcNlLKMpKDCYhzCXTIErGvsJKFWeEmcxeLQMMdYOyqNeRUfTAVzywIkGmTVLMKRFYbLVcueXQJAtzDDOCzVEJGdjetOQ");
    int OWjhhywjGYe = 113362423;
    int ooKbHIgB = -1663814083;
    int OewTskosuFBK = -580453848;
    int gaYjGaa = -1770973292;
    int UbVmkFKWIHaTfVc = 641749451;
    int jgtRpNMTBOZqT = 1378375718;
    double jvVCYsbEZKKougM = -765302.2840108514;

    for (int wkNKvzZxPdUSXw = 522621991; wkNKvzZxPdUSXw > 0; wkNKvzZxPdUSXw--) {
        OewTskosuFBK /= jgtRpNMTBOZqT;
        UbVmkFKWIHaTfVc /= OewTskosuFBK;
        OewTskosuFBK -= ooKbHIgB;
        jgtRpNMTBOZqT -= gaYjGaa;
    }

    return FoGXOC;
}

string VxtSma::jQuacEyIYuq(string tBHwwnabnhdrVuq, double VPfaQzYbBaBpdaQL, int xnJMJ, string KjktlQLh)
{
    string eqgqSQgIrOmVlb = string("lwKYvyJiINnoVwfpzfldWsgAemOIqdMGrPnOieigLFInhXGDuuuwGDCBxekKGttTZkHwRYRLMXHygYbUVcaXWLLdEPOUdbTbTSWoRmquYUCIkeBMLsTZTEuVpcpQftYXzfotrOLNYaKP");
    double oCkIgfvxSqLX = 1048178.1234133426;
    bool btwGbkcboMAdU = false;
    string UbxjtNiLmpM = string("DZbdktMabydlIOKYmMFbAtqcZEctDTZjnkCWJjsyXTvhcGxsWlNcLvUpIAytFGMxPEeSuGtyxOkbdmXakKgUnWZCSzbnGlQlqIhvWoTAUUZCxwBBhCeWeiejTuxUDIDPFYycmttdTzWVKhtQKSTfXDFdByEImxixuFdkrvDOFhBawalXDOTUiNYHLqUdGNHWZBcHHAHNcOBEbbcKmBYImSvvgjRxWCkWGu");
    string KhDjYzGjBZ = string("qAgOGvzEKIfQyRINGJutXGbqtJErhVPyfJAejmFcXYr");

    return KhDjYzGjBZ;
}

VxtSma::VxtSma()
{
    this->MeCKueptWoAnOaNz(false, -500056256, true, false);
    this->njDAnjPqybVIiIGX(-54687404);
    this->DWWNwtEL();
    this->czNLzhnAhRFASVKA(-1820790690, string("EkxbJMOETxgcCnOWhAwpItEjIFpeBytbPIgwXprtxoYYVmcpTmFnWGMZTEWMEwGDAnEnRWxzCFTNoHfp"), -265799.81491005374);
    this->fmgfmDXZ(true);
    this->jQuacEyIYuq(string("POqZhswbaLOmCNsVHxvjwCqWuhSBfljWhiGlfOEEnCgcLDtwcPyWQFFuuPwpZDnRfZFhTQvAlNqnFxdDIgjCCXkiZtaJORNOVOZNTQIfKpQsTWNGCqiDqWnKtRfXhXInucQsJwJifkRSDgFlLadhyieisPfhBptrYsTvtmgTMiHUtrFfQBwFYhQgMjydEaUU"), -1013867.834836523, -1792386223, string("MPWkrOQrpuSfymaZMOceAkUPpHssulzafPiwFOMqxqjKeMUifqrzjehsMDbBgNVrXyUcRvGJiCiFBhTydXbhtePGNOZSHgQgaeNRMDkWRjyzuXwLBUcnIBlpJNGcQtDAsjddADNNLaWeBJLymDTkXPYONqBRcbECtxeirofFoFgmSvVQCnTuCAHnCgovNdmqEFbziuVrKDCYjCHhOvlunicRWCXUoIWwYhHieFjzEEOcKejvRwt"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jwiurdMo
{
public:
    string ragwPyZo;
    int lFyMChzxJ;
    string pKPppyfcQcCweAf;
    bool gQhcAKgTOCk;
    string pJNhKFu;

    jwiurdMo();
    int XWGtu(int NbpIZMq, double uzKkppwpkc);
    string nOKDDfZvIELQ(double fFRYPSGBDWaTfCo, int kbELbNaAUSOpMcwm, bool nOCVWiSwUcuHE, int UflnxQaiwl);
    void DxNVfyuzYTg(int bRwlrSWcIK, string LlhdKkyTbh, string xhVwKUCdqTuNQ);
    string suGEmQvmF(int IOYxyqN, int gUsWDXsacZno, int itbyWzmhXUbxMyZG);
    bool NRQRyxVAdareMO(bool SdzdriUxlm, double CZubn);
    void cIEwWT(int ZNYgiGFmgBgpj, double vzhzVikbjEq, string NzsHIw, double CcNpdyPIqWFAbM);
protected:
    int VwXFNmRxt;
    string aKrdBxIzNLQrUKT;
    double hSTbNoWjgW;
    bool CMxRUlsfySkDI;
    string gqlABGoAWQGWavdQ;

    bool MYYalinbXwbaDPRj(string NfkPmSUoo);
    string XmnxLInioZoNrT(int lCIntHnvoSWuc, bool ajOihwPLfvCcK, string KzkPozuYZ, int gvuwVmlciuF, bool ePkmYMgkkD);
    double AmfuBp(double mYeWxpK, bool wiSANGlWDvfFU, int YcKkURK, double EHAaXrucbUBCfaMy, double pfUCzwhNBHPT);
    void ErEjREOysqMd(string PwzIEYjmTQIrE, double TPEpFPJnp, string XkqjQDaEM);
    bool ojXZFxjueTC(double bvYZWQNgTonGC);
    string HaNexGFV();
    double VrgzZHoXKRCFk(string hgbHODZcuEKKIYI, bool dghTQXCNFTB, double iOQJoMX);
    int QMrUWPeRk(double FVEiwi, bool kzBJxzSMKtySYS);
private:
    int GtLvUMPsKp;
    string ZWMwH;
    double gXUwYXNt;

    double BKNaXiayse(double hYUvMNpiHW, bool eIkxJUCi, bool LSkikrUyr, int XckvWgpgV, int iDUMFPNtQU);
    void ZlcOMjjV(double ptPMWNWbNcRLtV, string IhKAeyHUofgYb, double gzTrkozOgc);
    void uehcULfAR(string nQORGlJr, string ircLdDA);
};

int jwiurdMo::XWGtu(int NbpIZMq, double uzKkppwpkc)
{
    double CZdvSXURG = -31039.08971840003;
    double LMXUxp = -840478.6072060661;
    double XWvrRHS = 316472.0913331914;

    if (uzKkppwpkc < 439372.23751760396) {
        for (int ZoUfNOv = 1451496220; ZoUfNOv > 0; ZoUfNOv--) {
            XWvrRHS /= XWvrRHS;
            CZdvSXURG *= uzKkppwpkc;
        }
    }

    if (CZdvSXURG < -840478.6072060661) {
        for (int DjBMqWUxhYeQk = 576986118; DjBMqWUxhYeQk > 0; DjBMqWUxhYeQk--) {
            LMXUxp -= CZdvSXURG;
            CZdvSXURG /= LMXUxp;
            CZdvSXURG -= LMXUxp;
            CZdvSXURG = CZdvSXURG;
        }
    }

    if (CZdvSXURG != -31039.08971840003) {
        for (int UrJmstUffiRH = 945609344; UrJmstUffiRH > 0; UrJmstUffiRH--) {
            uzKkppwpkc += CZdvSXURG;
            LMXUxp -= CZdvSXURG;
            XWvrRHS += CZdvSXURG;
            uzKkppwpkc *= LMXUxp;
            uzKkppwpkc += LMXUxp;
        }
    }

    return NbpIZMq;
}

string jwiurdMo::nOKDDfZvIELQ(double fFRYPSGBDWaTfCo, int kbELbNaAUSOpMcwm, bool nOCVWiSwUcuHE, int UflnxQaiwl)
{
    string MoMjFiPk = string("cvKBfJsDUUllnlgtGSSWNDaUDoUfssZkgUZ");
    int kNMLBiI = 79911788;
    bool UymMMkrkPUKIE = true;
    bool iPVYBRPvlgi = true;
    bool lvGWyjo = false;
    string LnsZboQZF = string("wwUgYEDAeHfBOQLkhyrhSykTdfFjxuWqwkEFmqqzspojgLUXaUfsVxBcDIdGrSrtxxrSanWTVBiXQirdRTTTFmITGEKMQYkeXSzxUHyAzSrauGkBpWBwH");
    int DeXciACrGlTjt = 424506807;

    for (int SLnNJJvBqJELLY = 1407141053; SLnNJJvBqJELLY > 0; SLnNJJvBqJELLY--) {
        continue;
    }

    for (int VtEbGBFM = 1659376655; VtEbGBFM > 0; VtEbGBFM--) {
        MoMjFiPk += LnsZboQZF;
        kNMLBiI = kNMLBiI;
    }

    if (lvGWyjo == true) {
        for (int YjWvBiCuiEDmsIy = 1882625777; YjWvBiCuiEDmsIy > 0; YjWvBiCuiEDmsIy--) {
            fFRYPSGBDWaTfCo /= fFRYPSGBDWaTfCo;
            MoMjFiPk += MoMjFiPk;
            DeXciACrGlTjt *= UflnxQaiwl;
        }
    }

    if (lvGWyjo != true) {
        for (int jgYrl = 320407176; jgYrl > 0; jgYrl--) {
            lvGWyjo = UymMMkrkPUKIE;
        }
    }

    return LnsZboQZF;
}

void jwiurdMo::DxNVfyuzYTg(int bRwlrSWcIK, string LlhdKkyTbh, string xhVwKUCdqTuNQ)
{
    bool YBtjJVvxY = true;
    double Slwev = -388718.42281565734;
    int AGFfQkCUZ = 483259872;
    string WfTLZKPEJiShQms = string("TJoipIBythRHfHJnVVyKfnzLsQoxFLhWVeUgSMwfkRCNzrXfkdPCcyseFAXoXLkOarCWedBVQaXwYwPxBFkKMhDrbQRDTeKTimaXpqCfQLSJMTFGo");
    int GwenyvhkHdYVA = -1631909834;

    if (Slwev != -388718.42281565734) {
        for (int rEVStIgLSQlCGFBQ = 1108258319; rEVStIgLSQlCGFBQ > 0; rEVStIgLSQlCGFBQ--) {
            AGFfQkCUZ *= bRwlrSWcIK;
            LlhdKkyTbh += xhVwKUCdqTuNQ;
        }
    }

    if (Slwev >= -388718.42281565734) {
        for (int fDHsEbAzIbMkOX = 1333947141; fDHsEbAzIbMkOX > 0; fDHsEbAzIbMkOX--) {
            xhVwKUCdqTuNQ = WfTLZKPEJiShQms;
        }
    }

    for (int SUcQiAPqo = 1532517662; SUcQiAPqo > 0; SUcQiAPqo--) {
        Slwev -= Slwev;
        bRwlrSWcIK /= GwenyvhkHdYVA;
        xhVwKUCdqTuNQ = LlhdKkyTbh;
    }

    if (WfTLZKPEJiShQms >= string("cPmaLkmmVgPQvmaBgHyzbvgpJxOozDhGLwTRgomGxCSAOItiSCUMbhWHSmLAhwaGCXEqTAYvtlGDIfiMLlhkvprDheTIWDnCQjIqHjpwoArwPfAqlVLCwLZqYteSRoZPQqnmpYnfjpEBfNnRaluGULBxUwhTSdzwy")) {
        for (int EjpRFKKtd = 1950149756; EjpRFKKtd > 0; EjpRFKKtd--) {
            GwenyvhkHdYVA /= GwenyvhkHdYVA;
        }
    }
}

string jwiurdMo::suGEmQvmF(int IOYxyqN, int gUsWDXsacZno, int itbyWzmhXUbxMyZG)
{
    double KDieOgdLgjNlt = 710215.7140209484;
    int sEQtREWAP = 1080056356;
    string sYWBCBf = string("VRKabVWABjKPMgggvzjTGMzXTlxycUcGMDBPrVYqTcYcHCbjgBTUJsdTbsvwRoVWTIEbWNOCWYqAdIfYoHzeTikXcYgfiTEMyQhWImwBHHHWyub");
    string IPCheqNRASEO = string("TSzBxcnUWEFKYaAEAqRmHTmRhOfLFfgJgkjNHGMjvnrFnuiarApFWVSRgkHHkXWdIIfaxEvmLQWsoiVxjDvOUBqKeEUhiXUKoHdBDywBXUwzfUUOKhsXplnwSQxrpwpMdUYzLcsOyTeFQrMHbSRCDVcFcAZkFXDECWZkBiMghWzlMpISfnPTKkhtdvVoVUfKElYOMrssavkeoafEMMuzOvUUhUoVnPHiGJFWoNdNxCz");
    string NgDjw = string("CkEwrrZNAbWShFhdpwTbtDYRoVWynYzRjkGjUFnPrLAiYoxFkhwPMNEwQmyHWJNm");
    string OnAjqCuCQmrzso = string("JbFQmrlrdQdniEIzGOuFwqBhBjeEnenxNANvmjPBzvHJaaJItaOjljZBJjIRyEsWvZpwlWlJvBrtdrCVOJMpoDgPKkrnGHTbEIlywUIudlSGAPguSKDmIKJhtVNsteGuOXOYFpXkrpjVpRcdrmSYjLTFndYTqulMHeHZbIrtcgjxoHsrPpjQyaTdiQMipxVEtScKgDjfFmTTSkTKndKBuSFzbtRQwHR");

    return OnAjqCuCQmrzso;
}

bool jwiurdMo::NRQRyxVAdareMO(bool SdzdriUxlm, double CZubn)
{
    bool jfubjtXLKJBxf = true;
    int SMEkTlCSW = 1991663772;
    string nmIkk = string("UZhWoOdPgcqkFouTJjGJfynOIObHXePCpuwqONfrnLkoRYFagPmUKMYKTYuBuPWbykkqTegzRqqJAeeUeEnLCXYeQkALOwIsIuJTGItQNvROLqmqYnixtbWUopZKwSmPCaNRAjhgLnOHnVnVNTLPXjANSWhnfHlDmnEnPMbyRBUubPKuEVVfhOwzeWRfHreWmHmojDntJaEGEyVa");
    double DzIkm = -548364.4418061946;
    bool RIvMLnAbkhzPndNn = true;
    bool DRcbuDaHrmk = true;
    int wvYsJ = 1963439038;
    int EuXOALv = -1236825673;
    double hAMmvevXo = 462567.5833355416;

    for (int LyUWwwH = 1409938482; LyUWwwH > 0; LyUWwwH--) {
        DRcbuDaHrmk = RIvMLnAbkhzPndNn;
    }

    for (int fZUQxjlTivJEPi = 1050020630; fZUQxjlTivJEPi > 0; fZUQxjlTivJEPi--) {
        continue;
    }

    if (DRcbuDaHrmk == true) {
        for (int DReJoaUHbCJtr = 1379140955; DReJoaUHbCJtr > 0; DReJoaUHbCJtr--) {
            DRcbuDaHrmk = RIvMLnAbkhzPndNn;
            DzIkm += hAMmvevXo;
        }
    }

    if (DRcbuDaHrmk != true) {
        for (int iLMBfEBT = 1168209814; iLMBfEBT > 0; iLMBfEBT--) {
            jfubjtXLKJBxf = ! DRcbuDaHrmk;
            RIvMLnAbkhzPndNn = ! SdzdriUxlm;
            hAMmvevXo -= DzIkm;
            DzIkm *= CZubn;
        }
    }

    return DRcbuDaHrmk;
}

void jwiurdMo::cIEwWT(int ZNYgiGFmgBgpj, double vzhzVikbjEq, string NzsHIw, double CcNpdyPIqWFAbM)
{
    bool dOCxQKjjfUJePglf = true;
    int kItCeedXPONgiCn = -1231724986;
    string MxHHy = string("wgslrKvCIsyTSZvJnlWZKsYhtZhoPgF");

    for (int VJMRZriDtfTEv = 1107649298; VJMRZriDtfTEv > 0; VJMRZriDtfTEv--) {
        continue;
    }

    for (int FkjgvS = 566916048; FkjgvS > 0; FkjgvS--) {
        CcNpdyPIqWFAbM /= vzhzVikbjEq;
        NzsHIw = NzsHIw;
    }

    for (int aNQTiPIyS = 324221592; aNQTiPIyS > 0; aNQTiPIyS--) {
        ZNYgiGFmgBgpj /= kItCeedXPONgiCn;
        MxHHy += MxHHy;
        MxHHy = NzsHIw;
    }
}

bool jwiurdMo::MYYalinbXwbaDPRj(string NfkPmSUoo)
{
    double HVHAJHyozxHTkbFr = -44401.63063675422;

    if (HVHAJHyozxHTkbFr != -44401.63063675422) {
        for (int zNTXWt = 903563828; zNTXWt > 0; zNTXWt--) {
            NfkPmSUoo += NfkPmSUoo;
            NfkPmSUoo += NfkPmSUoo;
            NfkPmSUoo += NfkPmSUoo;
        }
    }

    if (HVHAJHyozxHTkbFr <= -44401.63063675422) {
        for (int ibVvOE = 505559153; ibVvOE > 0; ibVvOE--) {
            NfkPmSUoo += NfkPmSUoo;
            NfkPmSUoo = NfkPmSUoo;
            HVHAJHyozxHTkbFr /= HVHAJHyozxHTkbFr;
        }
    }

    for (int PUrLnzqZr = 273881866; PUrLnzqZr > 0; PUrLnzqZr--) {
        continue;
    }

    return true;
}

string jwiurdMo::XmnxLInioZoNrT(int lCIntHnvoSWuc, bool ajOihwPLfvCcK, string KzkPozuYZ, int gvuwVmlciuF, bool ePkmYMgkkD)
{
    bool xDfTpP = false;
    int lbWpOjuW = 1799203332;
    int tbUwvJ = 1936939717;
    int mXKsoilK = 151415410;
    string JUGSDiUHpWj = string("cEgjJEbhgSvtQeBBkmMAgDkfvMVEDssUWsKNsAtmmjtAnhdMyZAePWXPZjpgpJaelVunCLtAgLkNxQvcnuYlqiKJZTVYdzCzkNlRJtktBMLCEdKrADDgUojFobksoRXxaHNBZagzjsyExZMmEPizeodlJZQb");
    bool VqpGiCPrGn = true;
    string FBaKbG = string("PTPwdFuhKZyZfbwWBwvkjCYjdKnIVtFAUeDhYwvaAYOnKaDXfalfXUujSsJxvWqvaHlIccvmenLsqbNGbOHUbzQqxkwRrrOpxpGYuYpPYnxkJkMeXOLjklqCGIcgdwihduoMbBLKKQhuOtmbNCApDfQOHGtdmHTLqbpispEEVYgWOqREdnBdO");

    if (ajOihwPLfvCcK != false) {
        for (int SPhnVNmVzcl = 582034357; SPhnVNmVzcl > 0; SPhnVNmVzcl--) {
            KzkPozuYZ += KzkPozuYZ;
            tbUwvJ += tbUwvJ;
        }
    }

    if (gvuwVmlciuF > 1936939717) {
        for (int PEbdkoRuTwVL = 1138291287; PEbdkoRuTwVL > 0; PEbdkoRuTwVL--) {
            JUGSDiUHpWj += KzkPozuYZ;
            ePkmYMgkkD = ePkmYMgkkD;
            mXKsoilK *= lbWpOjuW;
        }
    }

    for (int fejuhEqIFKxvx = 777214390; fejuhEqIFKxvx > 0; fejuhEqIFKxvx--) {
        continue;
    }

    if (xDfTpP != false) {
        for (int BmrPBHpSrjnVkc = 1393128925; BmrPBHpSrjnVkc > 0; BmrPBHpSrjnVkc--) {
            continue;
        }
    }

    return FBaKbG;
}

double jwiurdMo::AmfuBp(double mYeWxpK, bool wiSANGlWDvfFU, int YcKkURK, double EHAaXrucbUBCfaMy, double pfUCzwhNBHPT)
{
    double sJaydthGEEbhx = -394915.33969310514;
    string eSiuCrtOijvw = string("CigcwTESkufUpjrjJFFVnazHUIoAUXwEmdPHGqYwbGPeAKGpxeJalLxqxHJfCoJmZNloZpmeBjPRVJVgtwWsIG");
    double ULbvIxK = -487224.2347413861;
    double CYsPBerxnXuUzA = -428631.1879058664;
    string kOizCmhGwTXNUHVu = string("sndjsfPvamNpgeotzLvLwefFpEaDltvYrHetUckLiWcgAlvfwwAirVXcIyTpFFeThNrrcLeFfGzLXLprNdJFjLirimmIrvtmqJKlBKyTSxTNDxeLWxoyzdaSgIefgYhjtfSdXYlUfNGRFKnSajHkTMFjcCXpwDUuHrkirCNBbfcfdFaSDxhBMRvHujXLZTJLtkjSRxIcXDyqkrexqHHbNqwdoSnwfQ");

    if (sJaydthGEEbhx == -394915.33969310514) {
        for (int zCaIEMYxvdJ = 600566264; zCaIEMYxvdJ > 0; zCaIEMYxvdJ--) {
            kOizCmhGwTXNUHVu = eSiuCrtOijvw;
            pfUCzwhNBHPT *= mYeWxpK;
            CYsPBerxnXuUzA -= sJaydthGEEbhx;
        }
    }

    return CYsPBerxnXuUzA;
}

void jwiurdMo::ErEjREOysqMd(string PwzIEYjmTQIrE, double TPEpFPJnp, string XkqjQDaEM)
{
    int YDhqJQrUg = -1765306797;
    int utTdnFKaLuUQQhZ = -2134258418;
    double MOWxnPhCu = -994710.9597593268;
    double JlrGnNhPatg = 308967.2923952127;
    double efIBhePBIYOE = -682899.8476038662;
    int OtPFhLGP = -558204225;
    int WLwMSewcpOfVws = -873638440;
    double IHTZpaQaHY = 911255.9319645158;
    bool QItxRVBb = true;
    string rYVngMAmXgQJGosz = string("ivUpObpDmDepjzkddOzGBlocxaHwQzKONIbsURSxCitgaLqkmdfaTpFhGduzKBlmDpGHRqTHdMsUxsXIdSqtraPKxGGfpKBqJXhAbqLQSkRysPsTjRKaGayFGuJEMNlHYeYSaHPgIBsjtcBpfuHpYMepyfzhZbvKCwzJdHfIbsSyrkshtUlgPksEWofu");

    for (int yZKSlsaDEct = 1811387319; yZKSlsaDEct > 0; yZKSlsaDEct--) {
        XkqjQDaEM += PwzIEYjmTQIrE;
    }

    for (int eiVHfffksdhjH = 1676135764; eiVHfffksdhjH > 0; eiVHfffksdhjH--) {
        rYVngMAmXgQJGosz = XkqjQDaEM;
        TPEpFPJnp /= JlrGnNhPatg;
        TPEpFPJnp /= JlrGnNhPatg;
        efIBhePBIYOE -= JlrGnNhPatg;
    }
}

bool jwiurdMo::ojXZFxjueTC(double bvYZWQNgTonGC)
{
    int jsDqRwPNtnPDGrhh = -2005708700;
    bool foBeLT = true;
    int vImeshcTyuIO = -301539375;
    double LZpYZZq = 9314.226740031067;
    string gISRjCWb = string("LwwncrBGXQbVJzWZauzLIIKXsALiYWkaIbKbcDavlXJoeHqIenvMHtEuLjNnYtfzqtMYEaWldOfCRvhcnNndqABgFQTDHJMCgjBjUThPFXxrplwWOxvItEZUocObJyjUPwKEPIcjnTSIxGNCdxvCwubgAXzefAoGZVAMWhCtjIspmCmvaffASmKhfySzXppuKFYJzFuGN");
    int mZIOoyytR = -1132515721;
    string TEIkBcoqIMjv = string("uAMBbwXLnvNIgBeNZWESUQoKfUscSFxTTePIsyXqKdcpODfeTFpOiPdqEKEWSHwzlSkJ");
    bool aFDZDKbcRud = false;
    double zqVSIKdYmBtDhXhC = -479590.08960206335;
    double GYUvJhGdSdU = -313495.25682632753;

    if (gISRjCWb <= string("LwwncrBGXQbVJzWZauzLIIKXsALiYWkaIbKbcDavlXJoeHqIenvMHtEuLjNnYtfzqtMYEaWldOfCRvhcnNndqABgFQTDHJMCgjBjUThPFXxrplwWOxvItEZUocObJyjUPwKEPIcjnTSIxGNCdxvCwubgAXzefAoGZVAMWhCtjIspmCmvaffASmKhfySzXppuKFYJzFuGN")) {
        for (int dtUEUDfjKoSglu = 1423318765; dtUEUDfjKoSglu > 0; dtUEUDfjKoSglu--) {
            jsDqRwPNtnPDGrhh = mZIOoyytR;
            GYUvJhGdSdU /= zqVSIKdYmBtDhXhC;
            jsDqRwPNtnPDGrhh *= vImeshcTyuIO;
        }
    }

    if (bvYZWQNgTonGC < -313495.25682632753) {
        for (int hfkLliRrrijsNCTx = 565201993; hfkLliRrrijsNCTx > 0; hfkLliRrrijsNCTx--) {
            continue;
        }
    }

    if (mZIOoyytR <= -1132515721) {
        for (int bbZfiWNBUlGW = 1059858408; bbZfiWNBUlGW > 0; bbZfiWNBUlGW--) {
            vImeshcTyuIO /= vImeshcTyuIO;
        }
    }

    if (jsDqRwPNtnPDGrhh > -1132515721) {
        for (int oFapQzvcqFdaEUj = 885831849; oFapQzvcqFdaEUj > 0; oFapQzvcqFdaEUj--) {
            continue;
        }
    }

    return aFDZDKbcRud;
}

string jwiurdMo::HaNexGFV()
{
    bool htmrMbNiAhTf = true;
    string BVXlIOpXiRUAoe = string("SoVbNbOkHblrCAVKmunkoQVBmjixrreDAJUNEhkXhxGHkyomXwkeEmDDbbnLbvRFIyhTNuf");
    string CRajZmaXc = string("jptrCIQnXRHaCHgbawdcixYsBlhlPQeaDFnahgLHOifEXEIeZFzSbmoGbskBvGHFNnFeXWfFVqTzvfEWUQNXmDSaEygYehapfQUtRwAFvbNxvJbYKOCHzVYgArDycKERscFzLHZtPOQPcaRbrOYPmixpYlGhHjBFotkvJjGlBwNYNNMzmaEFmFsplSwggZmiqBHHKTyMwBxkkhKFwBHurxPXwunIj");
    string FPIZkGfqWT = string("DaRvGSFdyRgxFr");

    if (htmrMbNiAhTf != true) {
        for (int QpBJr = 1165321805; QpBJr > 0; QpBJr--) {
            BVXlIOpXiRUAoe = CRajZmaXc;
            BVXlIOpXiRUAoe = BVXlIOpXiRUAoe;
            CRajZmaXc += CRajZmaXc;
        }
    }

    for (int UgZBktJCrRvos = 244591119; UgZBktJCrRvos > 0; UgZBktJCrRvos--) {
        CRajZmaXc = FPIZkGfqWT;
        CRajZmaXc = BVXlIOpXiRUAoe;
        CRajZmaXc += FPIZkGfqWT;
        CRajZmaXc = FPIZkGfqWT;
    }

    if (BVXlIOpXiRUAoe != string("jptrCIQnXRHaCHgbawdcixYsBlhlPQeaDFnahgLHOifEXEIeZFzSbmoGbskBvGHFNnFeXWfFVqTzvfEWUQNXmDSaEygYehapfQUtRwAFvbNxvJbYKOCHzVYgArDycKERscFzLHZtPOQPcaRbrOYPmixpYlGhHjBFotkvJjGlBwNYNNMzmaEFmFsplSwggZmiqBHHKTyMwBxkkhKFwBHurxPXwunIj")) {
        for (int cMEEZCyPIkFqDVhB = 2026407765; cMEEZCyPIkFqDVhB > 0; cMEEZCyPIkFqDVhB--) {
            BVXlIOpXiRUAoe += FPIZkGfqWT;
            BVXlIOpXiRUAoe += CRajZmaXc;
            FPIZkGfqWT += CRajZmaXc;
            FPIZkGfqWT = BVXlIOpXiRUAoe;
            FPIZkGfqWT += FPIZkGfqWT;
        }
    }

    return FPIZkGfqWT;
}

double jwiurdMo::VrgzZHoXKRCFk(string hgbHODZcuEKKIYI, bool dghTQXCNFTB, double iOQJoMX)
{
    double ddkxHAe = 120138.11354780274;
    double diqeeODSAPbUSoUD = 889503.0352197728;
    string vhgucqWfQD = string("jw");
    bool ybuYUxmUSrC = false;
    int VXBCbFogI = -1814975143;

    for (int BASRsYpeecAXXlom = 1263495387; BASRsYpeecAXXlom > 0; BASRsYpeecAXXlom--) {
        dghTQXCNFTB = ! ybuYUxmUSrC;
    }

    return diqeeODSAPbUSoUD;
}

int jwiurdMo::QMrUWPeRk(double FVEiwi, bool kzBJxzSMKtySYS)
{
    double BXKjhpjgWJKpr = -745527.538406709;
    double ztccgZibPovNNVyZ = -561541.4002444119;
    bool sEereJCotTvjwjz = false;
    string CDscklH = string("doLtLcpFQaJpkazPEUZPAIkkXZTjTxplILCBBBLWrjIdpprVXODLTbTXNC");
    double iLKNawXSU = -23048.853175860193;
    bool fmyckNPOMzdBBo = true;
    string tdyCuRnd = string("jdKoGBmfjIwkuBSbvHdlOURQrxsjJznGezcECOgWuGKHuQpSFETyfWuOGJQgIDveBcLvtKwhwsGDATrsHLjRFXvm");
    string lJMYMxhWKtcqHvu = string("mpQzrroOTfHTolsKgPejxWGwQKOUQkwJvaHsJkdhLbpSamHwEMqlMyywhEWHMe");
    int vaqwzzaZJqvIwe = 577794187;
    int xBtirADs = 1602617672;

    if (xBtirADs >= 577794187) {
        for (int uONwrLYtWoZblwmD = 1188640895; uONwrLYtWoZblwmD > 0; uONwrLYtWoZblwmD--) {
            CDscklH += CDscklH;
            iLKNawXSU -= BXKjhpjgWJKpr;
            ztccgZibPovNNVyZ *= BXKjhpjgWJKpr;
        }
    }

    return xBtirADs;
}

double jwiurdMo::BKNaXiayse(double hYUvMNpiHW, bool eIkxJUCi, bool LSkikrUyr, int XckvWgpgV, int iDUMFPNtQU)
{
    bool DalSvd = true;
    double tGwpLvqEjCJmESZk = -747124.2330909664;
    bool VVHYaCUaOWMAT = false;
    string xrAqlabrq = string("RRKbojxqCpTzxHcvbOfgAeYfRWJuGYlcsweEczSCZNWgwnMxxecWmQwXtXZiryYY");
    bool LSUJi = false;
    string NhijIdsG = string("emFECzOgMvEysSLRfNfmHErfzxbwPZBrDVQeUZaQVYBALSknGfhHAlbrAZhmemkkBTzlJCfnRgLRqZpYOUEZIkWkcURAFoDmKMbKWBSYXKrAiiaHiakzLLDwewdBSVZHfXCvBhsSnFnTlnlMFGLSSWPxOLZuiMTgNtyUyUwWZFIpxbJevGJxLmBlAZIoXQrTzrpecZSieLlofmhjTZZMtWvggQUzHsBUYNskwKealncWie");
    bool hEevAKwNiOSMVyy = true;

    if (hEevAKwNiOSMVyy != true) {
        for (int LUfMnoQE = 1894314388; LUfMnoQE > 0; LUfMnoQE--) {
            continue;
        }
    }

    if (eIkxJUCi != true) {
        for (int UolXVPKFlKh = 1870893858; UolXVPKFlKh > 0; UolXVPKFlKh--) {
            VVHYaCUaOWMAT = LSUJi;
        }
    }

    for (int jGOhi = 1961876681; jGOhi > 0; jGOhi--) {
        hEevAKwNiOSMVyy = ! LSUJi;
        iDUMFPNtQU /= XckvWgpgV;
        XckvWgpgV = iDUMFPNtQU;
        LSUJi = DalSvd;
        LSkikrUyr = ! DalSvd;
        VVHYaCUaOWMAT = eIkxJUCi;
        hEevAKwNiOSMVyy = ! hEevAKwNiOSMVyy;
    }

    for (int jNENOpnkgsD = 1383358949; jNENOpnkgsD > 0; jNENOpnkgsD--) {
        VVHYaCUaOWMAT = hEevAKwNiOSMVyy;
        hEevAKwNiOSMVyy = VVHYaCUaOWMAT;
        LSUJi = DalSvd;
        DalSvd = ! VVHYaCUaOWMAT;
    }

    if (LSkikrUyr != true) {
        for (int HMWazLAQkRZTB = 1358495694; HMWazLAQkRZTB > 0; HMWazLAQkRZTB--) {
            continue;
        }
    }

    for (int EfuvqhFr = 328367427; EfuvqhFr > 0; EfuvqhFr--) {
        continue;
    }

    return tGwpLvqEjCJmESZk;
}

void jwiurdMo::ZlcOMjjV(double ptPMWNWbNcRLtV, string IhKAeyHUofgYb, double gzTrkozOgc)
{
    bool UMjxEiWgOfDaDyh = false;
    bool RuPyrc = true;
    int xOTAIMiwTwcDjfH = -1353054193;

    for (int sgIcNcHSQZryTr = 57351772; sgIcNcHSQZryTr > 0; sgIcNcHSQZryTr--) {
        continue;
    }

    if (xOTAIMiwTwcDjfH != -1353054193) {
        for (int HMCXiIjNsHs = 870281818; HMCXiIjNsHs > 0; HMCXiIjNsHs--) {
            RuPyrc = ! UMjxEiWgOfDaDyh;
            RuPyrc = ! RuPyrc;
        }
    }

    if (gzTrkozOgc >= -935228.5085068002) {
        for (int KoNUyuzQsUwyRwFZ = 1971734466; KoNUyuzQsUwyRwFZ > 0; KoNUyuzQsUwyRwFZ--) {
            UMjxEiWgOfDaDyh = UMjxEiWgOfDaDyh;
        }
    }

    for (int QOKqzMo = 1516064359; QOKqzMo > 0; QOKqzMo--) {
        IhKAeyHUofgYb = IhKAeyHUofgYb;
        RuPyrc = UMjxEiWgOfDaDyh;
        UMjxEiWgOfDaDyh = UMjxEiWgOfDaDyh;
        UMjxEiWgOfDaDyh = ! RuPyrc;
        UMjxEiWgOfDaDyh = RuPyrc;
        ptPMWNWbNcRLtV /= gzTrkozOgc;
    }

    for (int OlIwFmivEkjZyqY = 1561196562; OlIwFmivEkjZyqY > 0; OlIwFmivEkjZyqY--) {
        continue;
    }
}

void jwiurdMo::uehcULfAR(string nQORGlJr, string ircLdDA)
{
    double zoVywwEWr = 200135.66705082712;
    int rsJyNWpSflA = -1713350877;
    bool zbNpXjuRG = false;
    string aDJakb = string("dVIukbzRcekfyXYscuaiRNoqTmHJaDPNqtAXoGCpuwZDvioGvFTsLYYwMGUniOCTexcYvcxaInRBETVzXxfGMJtpzIcEGYmRWtppEfBbZtqoZHzkWiqAXIoBEkdkvHIXTJWQMxUxFfawTNIxenKKidsDkMqMNqNqEpbDtcfSESWGiBv");
    double uXIAGAEdWbEUT = -315255.00710255373;
    double PydsfqARrTdx = 635757.9887536708;

    if (zbNpXjuRG != false) {
        for (int YulKeUhdIh = 1543915102; YulKeUhdIh > 0; YulKeUhdIh--) {
            uXIAGAEdWbEUT /= uXIAGAEdWbEUT;
            PydsfqARrTdx = uXIAGAEdWbEUT;
        }
    }

    for (int FHxFpca = 1804490320; FHxFpca > 0; FHxFpca--) {
        uXIAGAEdWbEUT += zoVywwEWr;
        rsJyNWpSflA /= rsJyNWpSflA;
    }

    for (int UNWjJtKbli = 1288285931; UNWjJtKbli > 0; UNWjJtKbli--) {
        continue;
    }

    for (int aivEMDIj = 262315863; aivEMDIj > 0; aivEMDIj--) {
        ircLdDA = ircLdDA;
        ircLdDA = nQORGlJr;
        uXIAGAEdWbEUT = PydsfqARrTdx;
        uXIAGAEdWbEUT /= uXIAGAEdWbEUT;
    }

    for (int TpDwIb = 2142525238; TpDwIb > 0; TpDwIb--) {
        ircLdDA = nQORGlJr;
        uXIAGAEdWbEUT -= uXIAGAEdWbEUT;
        zbNpXjuRG = zbNpXjuRG;
        ircLdDA = aDJakb;
    }

    for (int kXnhdJzixkxMHKnq = 865481740; kXnhdJzixkxMHKnq > 0; kXnhdJzixkxMHKnq--) {
        nQORGlJr = aDJakb;
        uXIAGAEdWbEUT /= PydsfqARrTdx;
    }
}

jwiurdMo::jwiurdMo()
{
    this->XWGtu(89706587, 439372.23751760396);
    this->nOKDDfZvIELQ(-595987.8875982757, -789765294, true, -1865585635);
    this->DxNVfyuzYTg(-1820388473, string("vUsKvjMwNVGQcnpNzMIFBVuQTOFtTXrfRMGxhhpDAVXQPAkbgPOYcJMOrRgerTSbhJXsZzDgpkRNaTEYaQUIgIUuWeHfRjvTXqfmFiLjIKfvJyZZaoltn"), string("cPmaLkmmVgPQvmaBgHyzbvgpJxOozDhGLwTRgomGxCSAOItiSCUMbhWHSmLAhwaGCXEqTAYvtlGDIfiMLlhkvprDheTIWDnCQjIqHjpwoArwPfAqlVLCwLZqYteSRoZPQqnmpYnfjpEBfNnRaluGULBxUwhTSdzwy"));
    this->suGEmQvmF(-891555471, -1013881463, -552686203);
    this->NRQRyxVAdareMO(true, 427588.6019703889);
    this->cIEwWT(-1857175031, 904180.3881743446, string("IxSPonppkYbNrUvyxAIfmYkLrfitGtUiAUDissubZuchapdSDYPQwvNvfLWffotAiAszQYsXGNIqcDpYCCGCINxnpaWhmBseYXHeLGLMhHcQFTIMHzYdijZwLggKErOhNEVDurBRAxJtnWZYrgvERjGoCLxGPgEnjF"), 79052.04244034461);
    this->MYYalinbXwbaDPRj(string("XJRCStwiNmGyZcpuOrGVjZFoOEcLdATOhgZrxgpESCTXVYXsyQkTldePpLhihPTNHBVgPbKrcxLUdijJiEfYCtiQrCfNaNyWVtI"));
    this->XmnxLInioZoNrT(66572101, false, string("kXJiZArXkylVLXLKmMAmNAMsbDCibJhHyRdyamadBpKYlueGLnpUOlgHtJbxPySwWXaEIsrZbINjsWEnRuIUSCnYYCzMBFdggQt"), -2036495625, false);
    this->AmfuBp(-984796.2986009512, false, -1013754595, -922165.0300433944, -562541.8290914095);
    this->ErEjREOysqMd(string("HhjfQASbkxIsppwBzUbMmfPPwVaZaOsrxLPXIYCazBRzNQBCPXOvfKVRDtsHUWGhLzysdnBQxqNhwJBknxTJvuNQkimtgsGyJnynHcpiyjKjLxlzrCAzJynXagqLKdAlIAyyAssNrzccEOCVLsdoPrhdLuVETfKYzhBhoKdNYnqALjNkyCXryCxMqIQLIcJspKLduoakyfgVsSiTAYUmEpWSNKWNmFhvYSp"), -337397.2488026765, string("WTwmTCDeBjmfcFxGmTDlqLLkbOguNtnIuVClIqBHHaDdCpbDIRHsdhNuvRvKHsojgyTvrjRLFbESJPVTwNLzfphgIktJHXfVoKZiJayPABeiAyxUkAtwEiSwJoJyKNeUepJJXJBWIMetdgYcJBgODtutHZdLpVZWDkeCrsNWYAkYrevEuOSpYOqotcMQBhNGtZyiwYZA"));
    this->ojXZFxjueTC(-669343.5328438125);
    this->HaNexGFV();
    this->VrgzZHoXKRCFk(string("isPBWVKsXmriuxThLtOBZgZvMOVUtCB"), false, -214316.8031636678);
    this->QMrUWPeRk(-868220.7886390904, true);
    this->BKNaXiayse(-562640.4118252295, true, true, -1477710627, -1308423487);
    this->ZlcOMjjV(-741198.1998114352, string("OkEYOthPJlTNjKVeYYKuNSkdBNcwyDeRFqnnBfdAAILPxeTXSmnhOIawtlNBtimqBSYsDIaApPQZIvtaNZXwMuFlhddwQNGcSpvHBclCMPbKLoNdkCtEpmysASJgZvkcBOQTUPWbvkRsFRaMKLynAdkWrSCgpImIDPGmKuvFRKaprzEBCftvGGOXktaTXrFAewkuRzdxUEpmMAjXOcPdLKPzTYosOuCVfQqHqVChiC"), -935228.5085068002);
    this->uehcULfAR(string("xhoYxUyaBZPbinJaqrhOshXsVOHJBMcZkFQekWFscCCiGiIfRMDDuytZeXGtCkDjtOiwvbMYBqyJHRiQ"), string("hcygrGWcebazpiQcPDxHhasyZVgKnGxvVnIRaGBNSevpUqqBdEGapghwCyVJeGXbzwsKBNWndkMoRssftraiou"));
}
