// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

// Since Travis CI installs old Valgrind 3.7.0, which fails with some SSE4.2
// The unit tests prefix with SIMD should be skipped by Valgrind test

// __SSE2__ and __SSE4_2__ are recognized by gcc, clang, and the Intel compiler.
// We use -march=native with gmake to enable -msse2 and -msse4.2, if supported.
#if defined(__SSE4_2__)
#  define RAPIDJSON_SSE42
#elif defined(__SSE2__)
#  define RAPIDJSON_SSE2
#elif defined(__ARM_NEON)
#  define RAPIDJSON_NEON
#endif

#define RAPIDJSON_NAMESPACE rapidjson_simd

#include "unittest.h"

#include "rapidjson/reader.h"
#include "rapidjson/writer.h"

#ifdef __GNUC__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(effc++)
#endif

using namespace rapidjson_simd;

#ifdef RAPIDJSON_SSE2
#define SIMD_SUFFIX(name) name##_SSE2
#elif defined(RAPIDJSON_SSE42)
#define SIMD_SUFFIX(name) name##_SSE42
#elif defined(RAPIDJSON_NEON)
#define SIMD_SUFFIX(name) name##_NEON
#else
#define SIMD_SUFFIX(name) name
#endif

template <typename StreamType>
void TestSkipWhitespace() {
    for (size_t step = 1; step < 32; step++) {
        char buffer[1025];
        for (size_t i = 0; i < 1024; i++)
            buffer[i] = " \t\r\n"[i % 4];
        for (size_t i = 0; i < 1024; i += step)
            buffer[i] = 'X';
        buffer[1024] = '\0';

        StreamType s(buffer);
        size_t i = 0;
        for (;;) {
            SkipWhitespace(s);
            if (s.Peek() == '\0')
                break;
            EXPECT_EQ(i, s.Tell());
            EXPECT_EQ('X', s.Take());
            i += step;
        }
    }
}

TEST(SIMD, SIMD_SUFFIX(SkipWhitespace)) {
    TestSkipWhitespace<StringStream>();
    TestSkipWhitespace<InsituStringStream>();
}

TEST(SIMD, SIMD_SUFFIX(SkipWhitespace_EncodedMemoryStream)) {
    for (size_t step = 1; step < 32; step++) {
        char buffer[1024];
        for (size_t i = 0; i < 1024; i++)
            buffer[i] = " \t\r\n"[i % 4];
        for (size_t i = 0; i < 1024; i += step)
            buffer[i] = 'X';

        MemoryStream ms(buffer, 1024);
        EncodedInputStream<UTF8<>, MemoryStream> s(ms);
        size_t i = 0;
        for (;;) {
            SkipWhitespace(s);
            if (s.Peek() == '\0')
                break;
            //EXPECT_EQ(i, s.Tell());
            EXPECT_EQ('X', s.Take());
            i += step;
        }
    }
}

struct ScanCopyUnescapedStringHandler : BaseReaderHandler<UTF8<>, ScanCopyUnescapedStringHandler> {
    bool String(const char* str, size_t length, bool) {
        memcpy(buffer, str, length + 1);
        return true;
    }
    char buffer[1024 + 5 + 32];
};

template <unsigned parseFlags, typename StreamType>
void TestScanCopyUnescapedString() {
    char buffer[1024u + 5 + 32];
    char backup[1024u + 5 + 32];

    // Test "ABCDABCD...\\"
    for (size_t offset = 0; offset < 32; offset++) {
        for (size_t step = 0; step < 1024; step++) {
            char* json = buffer + offset;
            char *p = json;
            *p++ = '\"';
            for (size_t i = 0; i < step; i++)
                *p++ = "ABCD"[i % 4];
            *p++ = '\\';
            *p++ = '\\';
            *p++ = '\"';
            *p++ = '\0';
            strcpy(backup, json); // insitu parsing will overwrite buffer, so need to backup first

            StreamType s(json);
            Reader reader;
            ScanCopyUnescapedStringHandler h;
            reader.Parse<parseFlags>(s, h);
            EXPECT_TRUE(memcmp(h.buffer, backup + 1, step) == 0);
            EXPECT_EQ('\\', h.buffer[step]);    // escaped
            EXPECT_EQ('\0', h.buffer[step + 1]);
        }
    }

    // Test "\\ABCDABCD..."
    for (size_t offset = 0; offset < 32; offset++) {
        for (size_t step = 0; step < 1024; step++) {
            char* json = buffer + offset;
            char *p = json;
            *p++ = '\"';
            *p++ = '\\';
            *p++ = '\\';
            for (size_t i = 0; i < step; i++)
                *p++ = "ABCD"[i % 4];
            *p++ = '\"';
            *p++ = '\0';
            strcpy(backup, json); // insitu parsing will overwrite buffer, so need to backup first

            StreamType s(json);
            Reader reader;
            ScanCopyUnescapedStringHandler h;
            reader.Parse<parseFlags>(s, h);
            EXPECT_TRUE(memcmp(h.buffer + 1, backup + 3, step) == 0);
            EXPECT_EQ('\\', h.buffer[0]);    // escaped
            EXPECT_EQ('\0', h.buffer[step + 1]);
        }
    }
}

TEST(SIMD, SIMD_SUFFIX(ScanCopyUnescapedString)) {
    TestScanCopyUnescapedString<kParseDefaultFlags, StringStream>();
    TestScanCopyUnescapedString<kParseInsituFlag, InsituStringStream>();
}

TEST(SIMD, SIMD_SUFFIX(ScanWriteUnescapedString)) {
    char buffer[2048 + 1 + 32];
    for (size_t offset = 0; offset < 32; offset++) {
        for (size_t step = 0; step < 1024; step++) {
            char* s = buffer + offset;
            char* p = s;
            for (size_t i = 0; i < step; i++)
                *p++ = "ABCD"[i % 4];
            char escape = "\0\n\\\""[step % 4];
            *p++ = escape;
            for (size_t i = 0; i < step; i++)
                *p++ = "ABCD"[i % 4];

            StringBuffer sb;
            Writer<StringBuffer> writer(sb);
            writer.String(s, SizeType(step * 2 + 1));
            const char* q = sb.GetString();
            EXPECT_EQ('\"', *q++);
            for (size_t i = 0; i < step; i++)
                EXPECT_EQ("ABCD"[i % 4], *q++);
            if (escape == '\0') {
                EXPECT_EQ('\\', *q++);
                EXPECT_EQ('u', *q++);
                EXPECT_EQ('0', *q++);
                EXPECT_EQ('0', *q++);
                EXPECT_EQ('0', *q++);
                EXPECT_EQ('0', *q++);
            }
            else if (escape == '\n') {
                EXPECT_EQ('\\', *q++);
                EXPECT_EQ('n', *q++);
            }
            else if (escape == '\\') {
                EXPECT_EQ('\\', *q++);
                EXPECT_EQ('\\', *q++);
            }
            else if (escape == '\"') {
                EXPECT_EQ('\\', *q++);
                EXPECT_EQ('\"', *q++);
            }
            for (size_t i = 0; i < step; i++)
                EXPECT_EQ("ABCD"[i % 4], *q++);
            EXPECT_EQ('\"', *q++);
            EXPECT_EQ('\0', *q++);
        }
    }
}

#ifdef __GNUC__
RAPIDJSON_DIAG_POP
#endif



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BKJrljtCGMD
{
public:
    string zQgEbHouN;
    string FepZgaLWoGsvvKi;
    string tTPkVqG;
    bool PoCyKSX;
    double KfPeJ;

    BKJrljtCGMD();
protected:
    bool yhBXymoT;
    double MxHSVThFuziDDrff;
    bool SssQR;
    double ZGGWFydOQAyHqz;
    string oQUyIWuH;

    bool wMIAHSI(string ZeJGrLiX, double karYZZnM, string oBeYGjAaxQe, double OQTXMglqolnz);
    int uLKKIPtnr(int xzfoWNlN, string qVCkYA, string OoBdigRsXRvzmQE);
    int QftHX(string rPzTtRwVok, bool KfVTOoCa, int SHjWExgHtOqYh, double WkIIDA);
    void NRXodgNGNYU(double XQejdlrvoYx, string nmeHYcZciQyzwpN, int SskbpVElRdGyKSm, string cJksFymgnbkwwA);
    int sWHdnRQn(int qdwJHjoaFB, bool TvwQVjC, bool qqxbxn, string bSkjPpP, int KGSXxkdK);
    void DBJoy(int YoazWP);
    bool TonuuPkuoSm();
private:
    string ronUGHbhGCWH;
    int WUwmUwuxX;
    int AoBGXXB;
    string smlnCepaUJRXNTZ;
    bool mLaoWgxaMOf;

    double FaCrgOSAWtDVkkWW();
};

bool BKJrljtCGMD::wMIAHSI(string ZeJGrLiX, double karYZZnM, string oBeYGjAaxQe, double OQTXMglqolnz)
{
    bool jQBXwrGxj = false;
    bool JiVpmdqBAGRvUt = false;
    int djFmLnFd = -1978687889;
    double hxBFnJU = -745903.6734977831;
    string SFJSiVRLOL = string("LdtvAXmiLHIyhUaUXrAcWcONqdEbtal");
    string QSrvYqUYFLiuMR = string("ImMunApdtpdVpHTZzmFFIDqpznKaiQgKGdaNVOPtpXNAJyctX");

    for (int DnkYYcCaHtWdfH = 719128375; DnkYYcCaHtWdfH > 0; DnkYYcCaHtWdfH--) {
        oBeYGjAaxQe = QSrvYqUYFLiuMR;
        oBeYGjAaxQe += SFJSiVRLOL;
        QSrvYqUYFLiuMR = ZeJGrLiX;
    }

    if (oBeYGjAaxQe <= string("kYpXSlhLJZwTgUyHhMNxcGsTUgQBSOWzNKoldcNNWCeDxSRYlFGCnHWfNbpVXfPmxmXDklsaGznjYJAMPKlRQGPlFgukZTBGHeGmNSAspMcAKfqbMQuOcpILUIwIXmAyNdDjWfBQWEHtuoOSYZWUrmEtmMnUMdFgbNmGuNPaiGyLDhXowznGlHEChydXWsXScLkBMAdyRuhGaafGqWnHjLmXcBliJbgrduaBYTVGh")) {
        for (int EeaCjEG = 1891403375; EeaCjEG > 0; EeaCjEG--) {
            jQBXwrGxj = jQBXwrGxj;
            QSrvYqUYFLiuMR = SFJSiVRLOL;
            OQTXMglqolnz /= hxBFnJU;
            hxBFnJU *= OQTXMglqolnz;
        }
    }

    return JiVpmdqBAGRvUt;
}

int BKJrljtCGMD::uLKKIPtnr(int xzfoWNlN, string qVCkYA, string OoBdigRsXRvzmQE)
{
    bool KuPuwmFXZF = false;
    int IrMOLXueqQBldLJc = -703253911;
    bool FcInDXywCe = true;
    int rqBles = -287091628;
    double xuErCkQkMFPJjZF = -753290.5154902379;
    string kymPlo = string("BWdWXPkXCnbaCLmNtNpImbhFAlKbtzbpzckoNtKMiRHoUaLiMxfJwRODhwSIKjvEdvsLhscehSIItJXjEojAppFHjXCNYWwNpafdRAUIsRSVsLfTMizxBKEXjDYLHfbdwZjoWXRGkbhONKfsxIZpluwmmHeIFxVcmcimRGtEHbIuJlfCBytqzWFVUhUGMMjoFvBjavkXVXPr");
    bool BAHSzivpMNBqimJl = true;
    int DTSLncYQlTZ = 1863476741;
    string KnflQjvncrr = string("CbDvhAkaqJNwvOYEMiaASTorFvseuYOacbQESpysaZPbopxuLBSaUNqBHqXBwdFREdwBzyOsjnlZvbXtpBdBLdiWjtGGogYpcxzbAWVZsWGXrBCECbaCmxZELbFwCaAeARQQcxWuuCJjnxmrWikwhdewfgTXfSzRfyexmHMHUousjSfBkLuIxNixsZzKpykquPWvnUALOzZCDlqKejamCzKMmNGzDeVXqDLnFOCLEiJLulIi");
    int alefTDTgUbL = -1387775605;

    for (int JsdWSpGTarwbll = 1476293653; JsdWSpGTarwbll > 0; JsdWSpGTarwbll--) {
        rqBles *= alefTDTgUbL;
        DTSLncYQlTZ /= rqBles;
    }

    if (qVCkYA <= string("BWdWXPkXCnbaCLmNtNpImbhFAlKbtzbpzckoNtKMiRHoUaLiMxfJwRODhwSIKjvEdvsLhscehSIItJXjEojAppFHjXCNYWwNpafdRAUIsRSVsLfTMizxBKEXjDYLHfbdwZjoWXRGkbhONKfsxIZpluwmmHeIFxVcmcimRGtEHbIuJlfCBytqzWFVUhUGMMjoFvBjavkXVXPr")) {
        for (int DXbWcyn = 1471545206; DXbWcyn > 0; DXbWcyn--) {
            rqBles *= DTSLncYQlTZ;
            KnflQjvncrr += OoBdigRsXRvzmQE;
        }
    }

    for (int SwMRhQaRdE = 1780942843; SwMRhQaRdE > 0; SwMRhQaRdE--) {
        continue;
    }

    if (xzfoWNlN > -1566343771) {
        for (int dMHgbwKu = 172727978; dMHgbwKu > 0; dMHgbwKu--) {
            OoBdigRsXRvzmQE = KnflQjvncrr;
            KnflQjvncrr = KnflQjvncrr;
            xzfoWNlN += rqBles;
            DTSLncYQlTZ = alefTDTgUbL;
        }
    }

    return alefTDTgUbL;
}

int BKJrljtCGMD::QftHX(string rPzTtRwVok, bool KfVTOoCa, int SHjWExgHtOqYh, double WkIIDA)
{
    double hUyjsBs = -389877.9993765109;
    bool VrpHzgvw = false;
    string hiYgIyTwRpz = string("alUlYqkeCnnZyyBiLt");
    int eCFCpPEn = 661891083;

    for (int ytatytZyP = 539177144; ytatytZyP > 0; ytatytZyP--) {
        hiYgIyTwRpz = hiYgIyTwRpz;
        hiYgIyTwRpz = rPzTtRwVok;
        VrpHzgvw = KfVTOoCa;
    }

    return eCFCpPEn;
}

void BKJrljtCGMD::NRXodgNGNYU(double XQejdlrvoYx, string nmeHYcZciQyzwpN, int SskbpVElRdGyKSm, string cJksFymgnbkwwA)
{
    string BVFuUE = string("RwmeIunWqirYXHLEKZsfFFciWiYNjTuUSiWVBOZhBkNRkEJQSbNmUDKWzjwoUtmZWpeQTIlZzFWUvghOysezHFveGnWlISjeWXUrzBDunJblRGzbUeHXSKXDrQhvZxbuyiQGimIIuGvLtEjHaqyHyWAwDiLiWNHMFYQHxwAlXgOyyxZ");
    int uwCYRUpueHfD = -741895373;
    bool HiUieqDorm = true;
    string MZtPpa = string("LIDnxtFllBuZFeJkCMMSTVemRSmfQaaNrMkeruEdNqAsDjimRVNssQYayAhcMbJuTNtlmvWQDqKHkowRivbqvDoIbmawycIqoaJEFRjrMSiyShsyTZrNZjRAwvnDeFFlHqTzAfFliXglMaBs");
    int xrnshhuvd = -1938172240;
    double MICsXYAa = -879761.8056025226;
    string wyXrl = string("vEPCUgeyfWOoqunmZTvOtUlFaeKADSQalEFgTmfJLsONwhxdptTjuDKmTtzePSvQQuGCQClCwgZYiUMyZiIctQAloYzlBaAasBYpMDmkeHNrkNlWlNUAfylXUQqFZONyuzeBtAQZSpFMHpeqZVBhWgUNvhePEgLFJXAFrJjDTiqodiVUDgbWpmBMRwFbdiVwkNixwjntmidssaoNcCXNRbDZDsiiWLnJcGAcIGepqX");
    bool IRfgAjX = false;

    for (int guZEQBoV = 70046270; guZEQBoV > 0; guZEQBoV--) {
        SskbpVElRdGyKSm *= xrnshhuvd;
        nmeHYcZciQyzwpN = MZtPpa;
    }
}

int BKJrljtCGMD::sWHdnRQn(int qdwJHjoaFB, bool TvwQVjC, bool qqxbxn, string bSkjPpP, int KGSXxkdK)
{
    double eJrOPdb = -85184.63914349684;
    bool HXYXLuezeusKtRXc = true;
    string bfbjLRjGgYA = string("utzynNZkzbWrKDkybERKvagEBbVpSHNDtiPUFYMXdZNnVMjurThSNIcTBNVQMsubMxZrXGPDlmNzRQaurKVrdrtwsQ");
    double MReiXVZTgftt = 1037375.1005890686;
    int bmryiGlX = 1377973431;
    string YsQOfZxxLJTSWNd = string("seJFxjcgsMFZKXinmuCvOaMZhwWOEtqgOoPgHfPiMLKuPIjLsgrghOKxRGCrMuZtGwsiYGqJQOnByBTWnwHoFcvhkuIbOIFZwktYjouBWtBcZzvNWcsUExKrSoAdoYHcegnTRhnDvspTpEFOdAdSIHpkOYuRLiEzKPOaFPfjjezprnhEIVKGJWEOKgVebsAzirrHIfCgQeXQKweHLUfpEuIDgFJuTdgfwjAkAa");
    double iKzJhtwb = 52644.06240244424;

    if (TvwQVjC != false) {
        for (int qYRYOYmb = 918754514; qYRYOYmb > 0; qYRYOYmb--) {
            continue;
        }
    }

    for (int zOFFXbPBIO = 1070046488; zOFFXbPBIO > 0; zOFFXbPBIO--) {
        iKzJhtwb -= iKzJhtwb;
    }

    return bmryiGlX;
}

void BKJrljtCGMD::DBJoy(int YoazWP)
{
    int nSAiCPMIGlKqT = 1306969544;
    int lZmiTmqcQl = 461703784;

    if (lZmiTmqcQl == 1920175002) {
        for (int FCGRyy = 589800173; FCGRyy > 0; FCGRyy--) {
            YoazWP -= YoazWP;
            YoazWP -= YoazWP;
            lZmiTmqcQl = nSAiCPMIGlKqT;
            nSAiCPMIGlKqT += lZmiTmqcQl;
            YoazWP -= YoazWP;
            YoazWP *= nSAiCPMIGlKqT;
            lZmiTmqcQl /= nSAiCPMIGlKqT;
            nSAiCPMIGlKqT = lZmiTmqcQl;
            lZmiTmqcQl /= lZmiTmqcQl;
            YoazWP -= nSAiCPMIGlKqT;
        }
    }
}

bool BKJrljtCGMD::TonuuPkuoSm()
{
    string QDmDFHWmNlA = string("nuOtshQhwZarwfJIFnNGsJbSlcRqDKCDiLRMgzGCgOCRCeDZJissnxZvvmqdxhZnVNUtVMROJzfZGgp");
    bool BIkICjQjy = false;
    string irtGTkJXst = string("yxMXQFwkyRQRYGAdqfpghjeTOUjBIZaxkUJbpzFECiADpZfThSurXRDWHZKXaCHIBGkQZeZVrOeekamUriWmdlh");

    if (QDmDFHWmNlA > string("yxMXQFwkyRQRYGAdqfpghjeTOUjBIZaxkUJbpzFECiADpZfThSurXRDWHZKXaCHIBGkQZeZVrOeekamUriWmdlh")) {
        for (int KLJXuXwSFWSc = 1683381361; KLJXuXwSFWSc > 0; KLJXuXwSFWSc--) {
            irtGTkJXst += irtGTkJXst;
            QDmDFHWmNlA = QDmDFHWmNlA;
        }
    }

    if (BIkICjQjy != false) {
        for (int VQUzzuSSaCAC = 183138534; VQUzzuSSaCAC > 0; VQUzzuSSaCAC--) {
            QDmDFHWmNlA += irtGTkJXst;
            QDmDFHWmNlA = irtGTkJXst;
            QDmDFHWmNlA = QDmDFHWmNlA;
            irtGTkJXst = irtGTkJXst;
        }
    }

    if (BIkICjQjy != false) {
        for (int JLowMyPi = 979701578; JLowMyPi > 0; JLowMyPi--) {
            irtGTkJXst = irtGTkJXst;
            QDmDFHWmNlA = QDmDFHWmNlA;
        }
    }

    if (BIkICjQjy == false) {
        for (int GFkwm = 1353205349; GFkwm > 0; GFkwm--) {
            BIkICjQjy = BIkICjQjy;
            irtGTkJXst += irtGTkJXst;
            BIkICjQjy = BIkICjQjy;
        }
    }

    return BIkICjQjy;
}

double BKJrljtCGMD::FaCrgOSAWtDVkkWW()
{
    bool EeFUgDpAIJZ = true;
    bool vyHSzAEJ = false;

    if (EeFUgDpAIJZ == true) {
        for (int CBhTnlPoPlR = 480924173; CBhTnlPoPlR > 0; CBhTnlPoPlR--) {
            vyHSzAEJ = ! vyHSzAEJ;
            EeFUgDpAIJZ = EeFUgDpAIJZ;
            vyHSzAEJ = EeFUgDpAIJZ;
            vyHSzAEJ = EeFUgDpAIJZ;
            EeFUgDpAIJZ = vyHSzAEJ;
            EeFUgDpAIJZ = EeFUgDpAIJZ;
            vyHSzAEJ = ! EeFUgDpAIJZ;
            EeFUgDpAIJZ = EeFUgDpAIJZ;
            EeFUgDpAIJZ = ! EeFUgDpAIJZ;
        }
    }

    return 980004.5303765184;
}

BKJrljtCGMD::BKJrljtCGMD()
{
    this->wMIAHSI(string("HCXTGOZTFEWfRKIEMVkEmGbHctJZFtxEJxVAsOGPWmmUQSVccknoMIvsXZFLrxRHioPdVIHhUwiTiVuGMispfxyIQCMsNrXjqn"), 578468.5531963913, string("kYpXSlhLJZwTgUyHhMNxcGsTUgQBSOWzNKoldcNNWCeDxSRYlFGCnHWfNbpVXfPmxmXDklsaGznjYJAMPKlRQGPlFgukZTBGHeGmNSAspMcAKfqbMQuOcpILUIwIXmAyNdDjWfBQWEHtuoOSYZWUrmEtmMnUMdFgbNmGuNPaiGyLDhXowznGlHEChydXWsXScLkBMAdyRuhGaafGqWnHjLmXcBliJbgrduaBYTVGh"), -318774.51615853346);
    this->uLKKIPtnr(-1566343771, string("EkwJEnjveSIJPPmsKRGgWOrENaiKqdUDbZpGeRODkPzlcedSuVvcuVodaFCAHWhuqloUKyGeyEqDazLZtbWBhQxZErvVUIYyXZmwbFhkYeEICQHodFLKwwNNcVgRgKAOmPLCZsUXUOqOPUEgZKHFdZnlHwCmPhRqwvlMwVZfacqaYTHaRhIBzNQDyVnMBRlIGWUedQlHFHrrqHwsuZIeiCQaLUIIyFPbjTgoBnLIgidkNDIBjkmOMSuxcN"), string("uzPpQDTWswMFCPoQNUmqgYliAwErWpsSmqwuBEqQCTyxZTqgWtYZRLkMIEoeLBSaAUUuUQdPVzJctbYDcRPwZOOeWHPVIULtLsnMtLQwKJyLttEDsBxSrKfspMNqAUgnHTNGagEFSemsJrADZSkocdPSroNPdhsZHpdPUTkZthyBZCjrdBfXbxJlEhgxd"));
    this->QftHX(string("gHvUMAQSAuUKfqflqTLyqIbWgQBEXutETKTUZScWRFUqsTnjWhCQelfSauVbbuwarXcFVrgrKMcUrozEZYBRMbAbTeKIEbdHoYjYycKlqUFYdYoiwdqeZaCZoZDqlgmPYTxhDycHIeydDnuiYwMHTUVYqFNShjmjlhZyNuhfVHmrGFHEcyveNyQGwSqvqwxquVJrriznH"), false, -1803752481, -820440.2879209232);
    this->NRXodgNGNYU(-693784.2887300309, string("MoIhYfddehGgwWxVTefDExKzdrvXlspWOwcWnaDaKCPqgGMZADQqEVryyhyipgcbHdlaropAiCMPRIRYmgCuyJrSsSDTnufbbeogLjGEENKAlVObCwjhzPRpzWyCYQCnixvLtpIVTKkcdctXDkznPndoLkyeChkkRmZcosRbLtZdXkDjiQCobVKWdaCkqvCBJrzPdvwqLvOvkvlxrvsYuQpYFDn"), -985069311, string("DzNdDOxLd"));
    this->sWHdnRQn(453895143, true, false, string("tkCgkaadOqcradcPlTSuVrflNlcxoQizhgAIlWiKZVENaajXjSsdFfKjotqdflchtpCyKClXjBGfFqVqHFTtlcVxtYYBWSxXhXVxuYSXvzTZGiLvSJuHOsIiovVXNSIfXPmQrzxjljMmjCHOgbBThIsbwTYkMKdYJGXaVnotaFoiRjoKyDJekSwuOzKdaYWCHPFVNJlrDvzfiDlW"), -1409556014);
    this->DBJoy(1920175002);
    this->TonuuPkuoSm();
    this->FaCrgOSAWtDVkkWW();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eeLRGy
{
public:
    bool QeabGot;
    bool HtrwAFuuaVfz;

    eeLRGy();
    bool EMwvSvlGbJgRqrSP(double eTsWMqWqS, int hWFxpf, bool QlOThWxPiwi, int jwGXlbHXWjtNau, string gVSPcpkCVwUnXhds);
    bool CykbRWqpcanuP(bool sAbxMLLLB, int wfHAfTsqCrNR, bool rAZfHWYtHEvYuJ);
    void wZmhiVmGAzWTQC(double WTBKJzAGrxOl, bool snEmINTXiJtKAl, double ALeRS);
    int SereHYDrVh();
protected:
    int DhAyenNiM;
    double vURrmEODee;
    bool WMTKxDJIAy;
    int BgAYjMuDiJThzONQ;

    double lKpqeJiaab();
    void pmjosOLdsUahJlCG(string ogFAONudA);
    string CKzGEF(double DUVgH, double RHbKxGBbpXc, bool eslFOjessFkev, int dlsgPCGtAfuByd, bool EGDFy);
    void wvhOM(double ZZfoinKPTeohYXrF, bool XOYtFH);
    int AuiCHUBWl(double XYZuJeqH, bool UADlWfrY);
    void iAakBMLND(string DEugFmIwCayPEZn, string UPDjt, string ATGzYjFOh);
    int cBSBx();
    int xvHHrqfkjdSc(string qxKfMiUDgSz, string kthRQMPkaAXZCOp);
private:
    int LQGpsJhXaQRoC;
    int gDwQtRcGWIeI;
    bool hFGONsKjMayzNME;
    int lNtVnjoIDkK;
    double GXsnuoxYYVpIvfNe;

    void imypWTXFvlU(bool MQLkbeFbne, double bKBju, string BBxPWXjoYqFc, int QBxfMaY, bool lzWbbfii);
    string VeWMepPOBQz();
    double pUFXizNCZl(double apFAXlC, int rjzukipIpsBc);
};

bool eeLRGy::EMwvSvlGbJgRqrSP(double eTsWMqWqS, int hWFxpf, bool QlOThWxPiwi, int jwGXlbHXWjtNau, string gVSPcpkCVwUnXhds)
{
    double aWFWRu = -220632.3217682801;
    bool NmoMbu = true;
    string pSCHaO = string("fIJvKKraqpnRCcfRYVYsiYOHigqOkFuerYEsqQfj");
    double BpKuPkyO = -48908.086816677605;
    double iSVqfHcqzFvYOBz = -860689.3541935298;
    string dNpKl = string("OsYDfjQvVzTjapepGoWiNewLnLPXztNMroYPpMKxGGbfsNvINTAkRoqvzIZmAQpxoSmqHZROWFHgYQaRQhQEZlJQtNLXCMCvcNffqWTVrzVjpqOqFQaPAQyKzrZbFPVLLAhUhpnXmDSRDOOjhEoDVNjnAIJKbgqRYoRapMUpmvOAJsXmusitK");
    double sdeznPQs = 418133.58262356493;
    double qqocLDIzC = -680772.6860224929;

    for (int uCHUiZ = 664258352; uCHUiZ > 0; uCHUiZ--) {
        gVSPcpkCVwUnXhds = dNpKl;
        pSCHaO = dNpKl;
        dNpKl += pSCHaO;
    }

    if (jwGXlbHXWjtNau <= 634838111) {
        for (int BHrGNhnmmVhypS = 1250970714; BHrGNhnmmVhypS > 0; BHrGNhnmmVhypS--) {
            pSCHaO = dNpKl;
            NmoMbu = ! NmoMbu;
            aWFWRu += eTsWMqWqS;
            aWFWRu += sdeznPQs;
            qqocLDIzC = eTsWMqWqS;
        }
    }

    if (BpKuPkyO < 418133.58262356493) {
        for (int knUnUnkJddXKL = 1884973495; knUnUnkJddXKL > 0; knUnUnkJddXKL--) {
            continue;
        }
    }

    for (int mPlsBVbLpKYCdprc = 508313534; mPlsBVbLpKYCdprc > 0; mPlsBVbLpKYCdprc--) {
        continue;
    }

    return NmoMbu;
}

bool eeLRGy::CykbRWqpcanuP(bool sAbxMLLLB, int wfHAfTsqCrNR, bool rAZfHWYtHEvYuJ)
{
    bool uxzWatpDFHq = false;
    double ueAZjsCupr = -95230.57329875667;
    bool fdjIP = true;
    double qwnrTIwG = 21424.900033855098;

    if (sAbxMLLLB != true) {
        for (int NjinYinxK = 283751489; NjinYinxK > 0; NjinYinxK--) {
            ueAZjsCupr -= ueAZjsCupr;
            fdjIP = ! rAZfHWYtHEvYuJ;
            uxzWatpDFHq = ! uxzWatpDFHq;
        }
    }

    for (int kxOuSZNcTrOUvURc = 1986893467; kxOuSZNcTrOUvURc > 0; kxOuSZNcTrOUvURc--) {
        rAZfHWYtHEvYuJ = ! sAbxMLLLB;
        uxzWatpDFHq = ! sAbxMLLLB;
        rAZfHWYtHEvYuJ = ! rAZfHWYtHEvYuJ;
        ueAZjsCupr /= qwnrTIwG;
        rAZfHWYtHEvYuJ = sAbxMLLLB;
        uxzWatpDFHq = fdjIP;
        fdjIP = rAZfHWYtHEvYuJ;
    }

    if (sAbxMLLLB != true) {
        for (int jzgoQTqw = 1336292830; jzgoQTqw > 0; jzgoQTqw--) {
            continue;
        }
    }

    if (rAZfHWYtHEvYuJ == false) {
        for (int cbPBQha = 677605010; cbPBQha > 0; cbPBQha--) {
            ueAZjsCupr /= ueAZjsCupr;
            qwnrTIwG /= qwnrTIwG;
            ueAZjsCupr *= qwnrTIwG;
        }
    }

    return fdjIP;
}

void eeLRGy::wZmhiVmGAzWTQC(double WTBKJzAGrxOl, bool snEmINTXiJtKAl, double ALeRS)
{
    int ZmkzBtMpforuQ = -358420214;
    int vBuERSKnByH = -981030408;
    string wfEPVUaEWNngDy = string("qhlSTB");
    double sUXldwBmjIggzSyT = -61144.989106470384;
    string zrIzPohMJtEPIP = string("nyzQgJQoyXZoLGHIoUPkHBcGOeXUOMWqofmXhrLkiOcHFbEWzTOXquiPRDxxMEIctPSkSKJZqCfaAJkJybfEsQtRvlhpVWOdohEgLunKmYIGkGFeNSycqDRQtGRVEZeWrxtlooSEvuBCAIXEkkeKrKHPpEcHQRHYkiVkDdyLTsEHZkfpFtHRHbPOnTWTnATXEIyuSDWFPydmhQefUxXSFukFnaFtTEEzspqQVjaIoYnvNXAthaGHIVH");
}

int eeLRGy::SereHYDrVh()
{
    string ZjdLOqGxeovNlY = string("nJojaLZIzwMndjINocQkSixPMMSHKeFIbVyRQroluBnpSBYkbxcWZpeLzTLqqRijgV");
    bool xmmzcjcXcrzrNScx = false;

    for (int LNHmOOUraDH = 1123403257; LNHmOOUraDH > 0; LNHmOOUraDH--) {
        xmmzcjcXcrzrNScx = xmmzcjcXcrzrNScx;
        ZjdLOqGxeovNlY = ZjdLOqGxeovNlY;
    }

    if (ZjdLOqGxeovNlY <= string("nJojaLZIzwMndjINocQkSixPMMSHKeFIbVyRQroluBnpSBYkbxcWZpeLzTLqqRijgV")) {
        for (int xmAtTmQG = 1113026862; xmAtTmQG > 0; xmAtTmQG--) {
            continue;
        }
    }

    return -252047923;
}

double eeLRGy::lKpqeJiaab()
{
    int GsxeCiblSic = -1099780347;

    if (GsxeCiblSic == -1099780347) {
        for (int Aqzqf = 558099644; Aqzqf > 0; Aqzqf--) {
            GsxeCiblSic += GsxeCiblSic;
            GsxeCiblSic *= GsxeCiblSic;
            GsxeCiblSic -= GsxeCiblSic;
            GsxeCiblSic /= GsxeCiblSic;
        }
    }

    if (GsxeCiblSic != -1099780347) {
        for (int vqfbjlZhptabrev = 588826500; vqfbjlZhptabrev > 0; vqfbjlZhptabrev--) {
            GsxeCiblSic = GsxeCiblSic;
            GsxeCiblSic *= GsxeCiblSic;
        }
    }

    if (GsxeCiblSic >= -1099780347) {
        for (int PKgAnbOHq = 1890279332; PKgAnbOHq > 0; PKgAnbOHq--) {
            GsxeCiblSic /= GsxeCiblSic;
            GsxeCiblSic /= GsxeCiblSic;
        }
    }

    if (GsxeCiblSic > -1099780347) {
        for (int XyajLNMoZ = 1394907660; XyajLNMoZ > 0; XyajLNMoZ--) {
            GsxeCiblSic /= GsxeCiblSic;
        }
    }

    return 793261.7140217344;
}

void eeLRGy::pmjosOLdsUahJlCG(string ogFAONudA)
{
    int uFiZZxXJR = 1797860715;
    double xUDjtoIp = -279092.09366611263;
    int upxXhJxsnXk = -1939490402;
    string PmMIWao = string("kORhKApflxvKSQvvhBnMPAprQGQdDVxmKFiDBVYEHxFiAyriDdGWBNRpnvMkZaVChPYQZjaJskYFszwnypXRZDBNhVyeBExymPLnFfZWVOFduaZxCUDKKbJiXJBsmGqrOvPpBormQQNChLroPAULAcCmsdLONTLLxvajTwGGl");
    bool qFbhdXknGEipW = false;
    double ibVezghHOvjKVyfJ = 122989.75788688891;
    string xBibZ = string("FaLMrnSddKzwhlIgfiYDlfnQiUZHuZIfgsUOfoZKgpzPjVERkuAHcoVuaKKxCjNTUMpMHaWAqaJgCXmqoDPARiDNMpYewVffYwvyMyJAFJKxRiZKJqrhssXtrshiihMIcRAuYwOUtLlCEgHKZTQjLwDBAzrzFFfrVadhtulJgVqfQeugLrkuXfRWdINmw");

    for (int dMLmIoBIzJWVDgw = 1459798738; dMLmIoBIzJWVDgw > 0; dMLmIoBIzJWVDgw--) {
        xBibZ += ogFAONudA;
    }

    for (int erKzqbCCSmMJ = 1823163008; erKzqbCCSmMJ > 0; erKzqbCCSmMJ--) {
        ogFAONudA = ogFAONudA;
        upxXhJxsnXk = upxXhJxsnXk;
    }

    for (int PIKWlYdHralFR = 1660252313; PIKWlYdHralFR > 0; PIKWlYdHralFR--) {
        continue;
    }
}

string eeLRGy::CKzGEF(double DUVgH, double RHbKxGBbpXc, bool eslFOjessFkev, int dlsgPCGtAfuByd, bool EGDFy)
{
    double HSnOxJWATboZCN = -383241.83760924306;

    if (HSnOxJWATboZCN != 158132.59992569903) {
        for (int PuWcQwAcO = 1734357613; PuWcQwAcO > 0; PuWcQwAcO--) {
            RHbKxGBbpXc += DUVgH;
            DUVgH /= DUVgH;
            RHbKxGBbpXc = RHbKxGBbpXc;
            RHbKxGBbpXc /= HSnOxJWATboZCN;
            EGDFy = ! eslFOjessFkev;
        }
    }

    for (int YmxJTIAzznWlRWo = 688153285; YmxJTIAzznWlRWo > 0; YmxJTIAzznWlRWo--) {
        RHbKxGBbpXc *= DUVgH;
        RHbKxGBbpXc += RHbKxGBbpXc;
        eslFOjessFkev = ! EGDFy;
        HSnOxJWATboZCN /= RHbKxGBbpXc;
        dlsgPCGtAfuByd += dlsgPCGtAfuByd;
    }

    for (int zykTRrSgSon = 454323713; zykTRrSgSon > 0; zykTRrSgSon--) {
        eslFOjessFkev = eslFOjessFkev;
        RHbKxGBbpXc += RHbKxGBbpXc;
    }

    for (int XxuBksNbLIV = 2128686276; XxuBksNbLIV > 0; XxuBksNbLIV--) {
        dlsgPCGtAfuByd *= dlsgPCGtAfuByd;
        HSnOxJWATboZCN *= RHbKxGBbpXc;
    }

    for (int tTcPttaovyUIP = 199663797; tTcPttaovyUIP > 0; tTcPttaovyUIP--) {
        HSnOxJWATboZCN *= RHbKxGBbpXc;
        DUVgH *= RHbKxGBbpXc;
        RHbKxGBbpXc = HSnOxJWATboZCN;
    }

    if (RHbKxGBbpXc != 158132.59992569903) {
        for (int NmwSQWHc = 1143718828; NmwSQWHc > 0; NmwSQWHc--) {
            continue;
        }
    }

    return string("zAozJhScUnoRkwiAuAriBRCxvDmcnofGxhIsASBnvKFnQFuTKDCHQLrKHcVljwopKIeiOiecwuhyAhBpGUVpHVoIImCbpFiaoJGnkyoRrzoELBPmkoGNGxTtGHOjodnkgfdHVXpUfhnGllAqdlSKfsKGxZCgRpkGTqakIjinLchREMaUJZtjNvUftvhUfaDMDpOEanwwLLIxiWqgMWPIlDzhUdcfseJhZLLJUilMS");
}

void eeLRGy::wvhOM(double ZZfoinKPTeohYXrF, bool XOYtFH)
{
    int ejwBMyaWzNxwb = 1582941624;

    for (int DUutqAhwzOQuu = 836042075; DUutqAhwzOQuu > 0; DUutqAhwzOQuu--) {
        XOYtFH = ! XOYtFH;
    }
}

int eeLRGy::AuiCHUBWl(double XYZuJeqH, bool UADlWfrY)
{
    string NLqeTEktoLkRRAu = string("WfCYmXlDSiPJZWPRroSpazUvjtMOdNBqOOxYPDMmbZzGDPmAWIleQaEIPcfjEiMMVytfbugiXXPQAsMJdLVGTpozRfCkYhMuSxpCaWXFycFYhzSjPigtrRGJJfsmEBaPgHwkQFHwHfnEiwBZMnhTVKWoJiDiEkWgYFbinUYQwhXVovAzgqYjDoEHdHtYBhKQqlLALrAPisetpnYaEtvvbWGWuQuGeMbsmEyIkpohywoFBVKyCp");
    bool LBWAULpjxNxAAbe = true;
    double FobqDLkvUmlDW = 917070.2102514545;
    string uktJbbut = string("FkvXvQBUYbrdJgkecLKeRpgKkdIJjUIZQnTYzqUbORVajKjuqZZejnYezeZbakAFc");
    int iJByUm = -853394070;
    bool oRzCuah = true;
    double bQYBb = -304709.98133029096;
    string rLNNqaAWgnQVz = string("ITUvDTLlIAphaDfDLGJMBvftcclVxHBDqyYESWEINmIbtFyIHXiyUQhnMIztFRqTIIyClfuTgttpaOh");
    string lhcDIZrbbwAdcgBU = string("cVmVkjKvXykHwJFgPustEjlwvPpEvbLhDDaqIlaAYkxSovBmKcOZoQfphqxbCejipfdkJrnJtvUZxAGKxAllxmRaWnxZJilGESnWLXuDfLNgrhjNoXRxJBdHWRDHguWRgJFwwqjAplzHbaHaOHeyAfApFLmxtDJQRdflDqDrpxVtxcQKQiZfhYheWPRuRjWKPLlRMsVjjqPSIxQWhLRrzBqdHXsGYTgfBqCM");
    double HyVsgulrbPc = -633214.740279169;

    for (int jGgyYquRLxWheWT = 1418892814; jGgyYquRLxWheWT > 0; jGgyYquRLxWheWT--) {
        UADlWfrY = UADlWfrY;
        HyVsgulrbPc /= FobqDLkvUmlDW;
        lhcDIZrbbwAdcgBU = uktJbbut;
    }

    return iJByUm;
}

void eeLRGy::iAakBMLND(string DEugFmIwCayPEZn, string UPDjt, string ATGzYjFOh)
{
    double cLYdlIbnHIr = 158265.03396810847;
}

int eeLRGy::cBSBx()
{
    string wceMGFONvzUjF = string("MkdfVdifoXnCojtDurwDhhZINOeDNRSfprJZMLJDZXkXAnphGJmHYTBJYEeDYwhKhhWDKSrqjCYVuXVcKPWXcfoHutxBVqnSuGQFPkVlduKhZZskzoEDFqtptBLFtbwFdYEmsaDdFNSmNrsuynVhUpDgBnDbejTEFeMnLFEOXTGAOFGmPVCrAhDIQHvaYSHrBW");
    string eWKeKULXVwHWzbBo = string("ZgRyaISvIsmUbarFXlDBHWhrhQDbKWpS");
    string TjyCGmmpME = string("fKDtrVXpkeTCUxKiDBUpgDPnkvMmXEObMNPzzZxLBzFKLtTwaHUZbeZaIbtJXILjjaePckrVykeZwNSAEmSUifrynEkdbYedCRLuaeIyDcqiMPhRDWcQpLCpCzERtxWFDStywharwMiNQyDGgBNXCIOmMDTUczAioCEVFQBztqnUBPvMLnMBCEeRsMSdMrOwNLqxrbxlpHOzovQblIjXbBqgbbjZRriIYEUeEAVYM");

    if (wceMGFONvzUjF > string("fKDtrVXpkeTCUxKiDBUpgDPnkvMmXEObMNPzzZxLBzFKLtTwaHUZbeZaIbtJXILjjaePckrVykeZwNSAEmSUifrynEkdbYedCRLuaeIyDcqiMPhRDWcQpLCpCzERtxWFDStywharwMiNQyDGgBNXCIOmMDTUczAioCEVFQBztqnUBPvMLnMBCEeRsMSdMrOwNLqxrbxlpHOzovQblIjXbBqgbbjZRriIYEUeEAVYM")) {
        for (int CWblIEQDMZ = 833194922; CWblIEQDMZ > 0; CWblIEQDMZ--) {
            TjyCGmmpME += wceMGFONvzUjF;
            TjyCGmmpME = eWKeKULXVwHWzbBo;
            TjyCGmmpME += eWKeKULXVwHWzbBo;
            eWKeKULXVwHWzbBo += eWKeKULXVwHWzbBo;
            TjyCGmmpME = wceMGFONvzUjF;
        }
    }

    if (TjyCGmmpME <= string("MkdfVdifoXnCojtDurwDhhZINOeDNRSfprJZMLJDZXkXAnphGJmHYTBJYEeDYwhKhhWDKSrqjCYVuXVcKPWXcfoHutxBVqnSuGQFPkVlduKhZZskzoEDFqtptBLFtbwFdYEmsaDdFNSmNrsuynVhUpDgBnDbejTEFeMnLFEOXTGAOFGmPVCrAhDIQHvaYSHrBW")) {
        for (int ylqwB = 217899; ylqwB > 0; ylqwB--) {
            wceMGFONvzUjF = TjyCGmmpME;
            TjyCGmmpME += TjyCGmmpME;
            TjyCGmmpME += eWKeKULXVwHWzbBo;
        }
    }

    if (TjyCGmmpME == string("ZgRyaISvIsmUbarFXlDBHWhrhQDbKWpS")) {
        for (int iCJuC = 1170032084; iCJuC > 0; iCJuC--) {
            eWKeKULXVwHWzbBo += eWKeKULXVwHWzbBo;
            TjyCGmmpME = TjyCGmmpME;
            wceMGFONvzUjF = TjyCGmmpME;
            TjyCGmmpME = wceMGFONvzUjF;
            TjyCGmmpME += wceMGFONvzUjF;
            TjyCGmmpME += eWKeKULXVwHWzbBo;
            TjyCGmmpME = TjyCGmmpME;
        }
    }

    if (TjyCGmmpME == string("ZgRyaISvIsmUbarFXlDBHWhrhQDbKWpS")) {
        for (int kobZkJdeNpUoJ = 1660361036; kobZkJdeNpUoJ > 0; kobZkJdeNpUoJ--) {
            wceMGFONvzUjF = eWKeKULXVwHWzbBo;
            TjyCGmmpME = wceMGFONvzUjF;
            eWKeKULXVwHWzbBo += wceMGFONvzUjF;
            TjyCGmmpME = TjyCGmmpME;
            TjyCGmmpME = TjyCGmmpME;
        }
    }

    return -929978866;
}

int eeLRGy::xvHHrqfkjdSc(string qxKfMiUDgSz, string kthRQMPkaAXZCOp)
{
    bool eIOuqOugYyoI = true;
    string NFVcUZ = string("ZjVuvwLvrBAcJXIgstZWkivpCKFjiekxEDtOZGygiVbNSQdbRbVBrSWUXHulYeAKYe");
    double LYmhrqDRzziWod = 349982.8400110693;
    bool yIvTJfYiKKhyFc = true;
    int ksyILDgw = -264277076;
    bool qFUEJMrvtHsKCt = false;

    for (int WCtogKoxfND = 1666380141; WCtogKoxfND > 0; WCtogKoxfND--) {
        eIOuqOugYyoI = ! yIvTJfYiKKhyFc;
        qFUEJMrvtHsKCt = yIvTJfYiKKhyFc;
        qFUEJMrvtHsKCt = eIOuqOugYyoI;
    }

    for (int MdzasKJVKIMNvtZ = 937540957; MdzasKJVKIMNvtZ > 0; MdzasKJVKIMNvtZ--) {
        kthRQMPkaAXZCOp = NFVcUZ;
        qFUEJMrvtHsKCt = ! eIOuqOugYyoI;
        NFVcUZ = qxKfMiUDgSz;
        qFUEJMrvtHsKCt = ! yIvTJfYiKKhyFc;
    }

    if (qxKfMiUDgSz < string("ZjVuvwLvrBAcJXIgstZWkivpCKFjiekxEDtOZGygiVbNSQdbRbVBrSWUXHulYeAKYe")) {
        for (int Ytngd = 420035917; Ytngd > 0; Ytngd--) {
            eIOuqOugYyoI = ! eIOuqOugYyoI;
        }
    }

    return ksyILDgw;
}

void eeLRGy::imypWTXFvlU(bool MQLkbeFbne, double bKBju, string BBxPWXjoYqFc, int QBxfMaY, bool lzWbbfii)
{
    double WcjKehGjMIqqe = 805555.7492333293;
    string MqFacRRso = string("yprbGAGpUwhBqnZdCpkfrJfWgGZKViRIKor");
    string lsqaFXFt = string("UQTJrhIlaVFDSYIhdpcVkdmekVTrFfrSLvBWAWUvLISgFlexcRoUIPRDQjgTDvqmXHhgFyXwTogOkZeZFpmdQYbKaracZZDbYCvKYJemcPXGdhtmQmkaTcpafcUHELkpuDvJIupMSWqLosJkSvhmPcNxCivIPhDLfOuqTWDptBY");
    int gangKaX = -1651849252;
    string etSfo = string("bxVvGnnsoOFcrLUrpGZrWRQOwsGmGNjjcJPfmoHNYvTrLjViQcThWYvwMaPIXpUFVTXwCfJkDLNFNgqdLZdxsdGMvpETiHy");
    double EbBCgaQxEtDG = -150432.89878308258;

    for (int POHXXDvEKWiuX = 2081508223; POHXXDvEKWiuX > 0; POHXXDvEKWiuX--) {
        continue;
    }
}

string eeLRGy::VeWMepPOBQz()
{
    bool YOihgakBZNj = true;
    string VizPavBfBu = string("KkZhjDSWjjwNltiwkQDnWGMBjPdxqzwATxXeObpKGgXfABMQTEpXvHjIwlLAGNPfJwGnfIaxRJZqklDsCQFkPeSSJOmZFaGmBjkmejjXJgocMIMaXiReTEqMyklhtqgmOIxAZDcPdbwPXBxCcgeEKeECIJHOSBBGOJJRaKUxbiHIDDnZRQqtXopAfQsqhSbJAlKuHnOQHcajhdJ");
    int lJtzHnNdHnXcnPAz = -1270800005;
    string HttYIVN = string("npcXpkyvznntZIICvoVZxdPOGGPXniqPeWDWiZALbTAzNOtZAUAtlbDKSjxkuiXVybYbWVkfaZUkZbdKPWolJnsKNZrAUpCuuiWcQUUnjHpQNbsGjOllPVxaAUjVslMwJEDmeJmOLMpCeOboth");
    string FNVdLTNROuhJT = string("pPZrWDJQDalGERWkEXdaAYazoEvLJCCdnReYoYXTtBNHNDlUfUMulchicPmJkgQglHQUyfvHVXCvwhaVqTbBpPrQWRWgLQwIMHWBMXcxcngKUApfsBJnZYPsNmgcWgUpTEWQWlOrSLtPjs");
    int LlCBOYFgs = -1446767848;
    int NVjqKxpFUwoJ = 1962814384;
    int NcIPHnnCX = -2051159774;
    int INoAVJQAJ = 2018433588;
    string KgqVlceLEwmD = string("PJqwwNlxfVkLaOxPyjUxSiEDCtwgWTrkjNJcNZEpQbmdOoPBlNPmwUOFOxSEWpxJDEdVnWqayEvKwhTkwSuvHoQueUbUQtrEnQmpzKFSzWChuXOZqGrCdaqIvrPbCeUoTIKAnDtQYzAGv");

    for (int MeYAHChiSxBkII = 1033550459; MeYAHChiSxBkII > 0; MeYAHChiSxBkII--) {
        KgqVlceLEwmD = VizPavBfBu;
        LlCBOYFgs += NcIPHnnCX;
        LlCBOYFgs *= INoAVJQAJ;
        KgqVlceLEwmD += VizPavBfBu;
        VizPavBfBu += FNVdLTNROuhJT;
        FNVdLTNROuhJT += VizPavBfBu;
    }

    if (VizPavBfBu < string("PJqwwNlxfVkLaOxPyjUxSiEDCtwgWTrkjNJcNZEpQbmdOoPBlNPmwUOFOxSEWpxJDEdVnWqayEvKwhTkwSuvHoQueUbUQtrEnQmpzKFSzWChuXOZqGrCdaqIvrPbCeUoTIKAnDtQYzAGv")) {
        for (int IlhdcDRkSGo = 1344840041; IlhdcDRkSGo > 0; IlhdcDRkSGo--) {
            HttYIVN += VizPavBfBu;
        }
    }

    if (NcIPHnnCX > 1962814384) {
        for (int fRgykFKFYkjVJ = 1001753535; fRgykFKFYkjVJ > 0; fRgykFKFYkjVJ--) {
            continue;
        }
    }

    return KgqVlceLEwmD;
}

double eeLRGy::pUFXizNCZl(double apFAXlC, int rjzukipIpsBc)
{
    bool ViWpW = false;
    bool zWiqNrAoMZbIriqO = false;
    int zXZlTXn = -705547500;
    bool rXSwwxFMV = false;

    for (int JYUgQLW = 1265078680; JYUgQLW > 0; JYUgQLW--) {
        zWiqNrAoMZbIriqO = zWiqNrAoMZbIriqO;
        zWiqNrAoMZbIriqO = ViWpW;
    }

    for (int jszVXETKPy = 1864457532; jszVXETKPy > 0; jszVXETKPy--) {
        rXSwwxFMV = zWiqNrAoMZbIriqO;
    }

    for (int rwQbvrGSvKGpagYp = 733072666; rwQbvrGSvKGpagYp > 0; rwQbvrGSvKGpagYp--) {
        zWiqNrAoMZbIriqO = zWiqNrAoMZbIriqO;
        rjzukipIpsBc /= zXZlTXn;
    }

    for (int ESrZi = 1473208904; ESrZi > 0; ESrZi--) {
        rjzukipIpsBc *= zXZlTXn;
        ViWpW = ! rXSwwxFMV;
        ViWpW = ! rXSwwxFMV;
    }

    return apFAXlC;
}

eeLRGy::eeLRGy()
{
    this->EMwvSvlGbJgRqrSP(695432.5222623085, 634838111, false, 815120972, string("QekfuvUSdVbzewKSdjAHJpXiSKVjNEGyrurCqYniOmdywFbnrnPJSkyAoBtAQTHIzdSSoqGiNHOlMMnZbWqGFjUYNtVgvGCFayfRLEnEBFfEOebwAaDxesGBXxJXomXSUNmQaLkkrMGprBJCkGPvMjVpMnuPcbDkSydyPgxcczPCgzItuYcKGCqKOBLzRorOjrrq"));
    this->CykbRWqpcanuP(true, -950178716, false);
    this->wZmhiVmGAzWTQC(258613.5961817387, true, 958306.7209929555);
    this->SereHYDrVh();
    this->lKpqeJiaab();
    this->pmjosOLdsUahJlCG(string("JefqKnLCYhILkMtKYpYdZbURdyatZihkbVauwQqmmjhTAZctBOpAvmIKxWrPeMjHPHVSbkXlEObNnszLYirdXXpiJqIhGPvphVWPRvanOLrodetlCndtiixVYTiHgVyuZKhgDHUdEoyxPyIsjkSozvuQmGmcLrakwXzFVbkMalLPnGlGxUVGYsJtPgDDskKlnrwHNVzcEHCIOTZANJINATLWvm"));
    this->CKzGEF(158132.59992569903, 246392.36447146564, true, 503539425, false);
    this->wvhOM(458330.55630352575, true);
    this->AuiCHUBWl(685537.622224288, false);
    this->iAakBMLND(string("hlguQKoNlfTqzUyRCRjEcynJYKdFscyrrkrWYHPiFJpbyHPAPrDijtxdzsTmXlyOzAqwgMrBPmiTXwNTZLAdSOmReXWjbpUxvkFTDEQmXVyTLIdWIUaNQGlHDqUWHnHeQxpSQAdayctcrOlDRDLnXwkEilQIkdXVrsXLBUZUtlgMRgEebVJqQZYqDeYOpdQLUfkGkokZFYebZmYWsBbAHTRVsodrXUXuyql"), string("EIoRyeYBepZIcsMYZzikNOZtdkclkjsnwBnJSuBTAWBnmpBYKTcFyXhrIaYqqinAvLPcMnBsJTQtRvcFrI"), string("awXFhWmxwoCGEgryFHLQnGxUetxjzxMpLDNFRRPsdjsJJtkQlxlaZXQZhAayckGqlYcrAehFXxjNTmtvapTKtwOvw"));
    this->cBSBx();
    this->xvHHrqfkjdSc(string("KoRNkRjZskGSkglmXRvuZKpAMuqwxvPetkzshGNXRHOLpoHRSnXSABqhJRSmyHUaISGmHylbvxYmaCxPwO"), string("LQuBMBULJpTBvTgc"));
    this->imypWTXFvlU(false, -250637.32778426114, string("aIOlZUtBVpiZQnojcjTrtzhsGPzQSMjnGMRHUyfpEDPyVbLQUlBNUbEIRTGobTcpBBnDfrcNEXWDiQAyKZisTSxkMyNFMPHbvRqXKXtGiQ"), -1669007361, false);
    this->VeWMepPOBQz();
    this->pUFXizNCZl(-296132.47044770553, 717539222);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LTMPgsswe
{
public:
    int xPTidkUZiqMUP;
    bool hTTgubhShS;

    LTMPgsswe();
    string bsjgElYoMWWGCTN(int lvflPz);
    void kkVekCSriam(bool VNSkdm, bool bVROtYQSAY, string XzVfnFFApgLe);
    int ZPXtLyGLhJGyJQP(double ecuuASYVeH, int YKzKMEZtAqftg, double VAiOaktsvPg, int hWPVtCpaJPkBI, bool YCDXvuuIBMpTWazd);
    bool UgNXjTexeGAmvYUr(string YMdiekTlYfusyQn, int dZzXDuyYz, int wwxvVrRvlRg, int iILMPBwipX, string aWHXbrWkmZn);
    bool UsnMQayXJnAKfFmY(int uSVgCSAaWlhw, double tddBMhXojKKnaj, string ukBmvf);
    bool TABWWGWpwIIv(int smsNy, bool CwlBwQruCxg, bool bmEKNjCLBBhfzxuy);
    bool wNcZBDY(int fblMvAkR, bool ukMFXzeAeYQpOI, double VpjAnecJfV);
    bool qGcIvj(string ogLmPpOvKcviD, double EIoKQGKCqTn);
protected:
    bool CEQQOqzvwg;
    string RfnjKokERIr;
    double mlSYAdOtPCwVN;
    string lrRzjhrTJPHqB;

    int PxJgHwViLAVfwwLq();
    void hmPwaFWraYoj(double fVhHIYXjtEWI, string iZFNvOsDx, double AOEkKTaHcm, int MVoTuYcsf, double dEZymjIiFFqyLFw);
    void vjNuJgyrabFB(string JnrWJEnjSqskgr, int hlsInblgSckBNeDa, bool fwEFI);
    double xrpVAHxlPqHcsEUp(string jbqiqGmqhJl, string uRqmOBQGgTvIv);
    void ntADWuCzbrR(int dInNJZBKOWORcC, double rHJHWhoCGV);
private:
    int miMzEuYHyS;
    double cVutlfpwUHaqQjCz;
    bool mZfRC;
    string uUzYdpscPKECcFIm;

    string FVGWunI();
    string wqUsYjMribkRXv(double hQqxYjBaXnYH, bool AHLPSpwpPYUBuY, double ZGSIYxSfrtS);
    int PkILsbbeQMvL();
    void pMjjDE(int PbYvxNSPDSUhv, double MpBckaokw, double qGyOSlvROHJyXZJF, bool oYrwrBMG, bool NBFogtE);
    int RgusmgeJTwHsX(int tBdnJf, double tNqDhpGxCRpqLw, string AlYqWzNnq, string vggINDCNC);
    void BJCRwIvrjCTcuJ();
};

string LTMPgsswe::bsjgElYoMWWGCTN(int lvflPz)
{
    bool oacXCGPSfFs = false;
    int UhcIHyHFpoQGr = -2065778678;
    double soTlADiFeMGgLwk = -787319.7502741013;
    string VEKuhyFI = string("NNWCWQgWhUVopQFArvpIzBcRKmzdbXtFEaFFjpVZkoMxkZnyhuAcqxXmkoBeAejUyHMthVCwyfPwJwxfsJnSVZaymhLQxXLAahhDbULmklvjICoXCsOIjNmjPHJPZmurkcPrtGJYaGpXhwmWxaapOcqsfJOrSskOeUSCgszWCVJKKNpWNzkHlMzFcKUThMZmsCMxXeSEgERrcNglso");
    bool zAqhjGbR = true;
    string IGaomkqQSrPSOYJ = string("wSleTCvXDKWRPFNLmkHZsnmjvvUCWNvAIBmyvwJrDEYaHrJSqJNzZdZeqyODHySfCyYLXBNMlnawzJHTqsYGizgSkUicaDFKH");
    double jtqMDArxjnEzoP = 665752.4954513848;
    int gkUzPwJijlIzdG = 1632221043;

    if (UhcIHyHFpoQGr < -2065778678) {
        for (int saDfHaHxAo = 1494550836; saDfHaHxAo > 0; saDfHaHxAo--) {
            continue;
        }
    }

    for (int GjFueHyx = 652838742; GjFueHyx > 0; GjFueHyx--) {
        continue;
    }

    for (int rFkjHywumxhLlHYP = 761696230; rFkjHywumxhLlHYP > 0; rFkjHywumxhLlHYP--) {
        jtqMDArxjnEzoP *= jtqMDArxjnEzoP;
        gkUzPwJijlIzdG -= lvflPz;
        jtqMDArxjnEzoP /= soTlADiFeMGgLwk;
    }

    return IGaomkqQSrPSOYJ;
}

void LTMPgsswe::kkVekCSriam(bool VNSkdm, bool bVROtYQSAY, string XzVfnFFApgLe)
{
    bool bZQpCvPcvt = true;
    int nVMgXfxtHzo = -1174981538;
    bool KslPdAqf = false;
    double QlQNKGbYmklx = 71952.00759688093;
    string jIDHbuSEqcA = string("qbLMeFCUjzwKRBmjFkmWlMzTwewegCnkKhcgPiPhZtfcxazPBKLrDmAaGbfMkANzfmXmsIFZUjJyGwkQRDrlGfqOFynnDpFaztQSvzUHnwKAbzVymTQyABiunmwMxapOESmtepVrmVJjhNivnMepVnjVYaxbUfEeVeZgYLsGtctzlnXpOjhOVinCruIWOMbkNlFwoKACdGIBtsmmFEmFbREhkXLFsYsdyTrtyY");
    double IruPw = -147082.314655282;
    string QYSWRRtuREmuSdCm = string("YsbCSsImzhMIvmwrgGhNBQRdeBsOlNUjrjPDGkaSedAInuvlCoNzbHTHdtfjPwQrxnWqTqeizXktivOgTfcaChbYLCGMvWRAOwDdnkizjAaANJeUsaPnZQMWZYjVZfnZhVrBaurNfmMuxysVOQMWWEWYvDYmMcNYFqUplQVDWYDjdBGMniUFEBVmLjWeQaF");
    string eETdwWCFunEXo = string("mGkzkMGqfgALfFaTIMSNkigMiVFCDkCzhlBoQFeIQwClXeZDSvOfVgbfvqneyAhBBidpdFGcwBJBIat");
    double xesxK = 512709.91615407076;
}

int LTMPgsswe::ZPXtLyGLhJGyJQP(double ecuuASYVeH, int YKzKMEZtAqftg, double VAiOaktsvPg, int hWPVtCpaJPkBI, bool YCDXvuuIBMpTWazd)
{
    string iuKFMnRfXwU = string("yVDElkcEijODjRkNmDZNAytKSHSvLCSDQIiztgFyTxBkgQlSKvhQlavQJzGHVJCLejJBVdYlReOkVYeEWBTqQxroXli");

    return hWPVtCpaJPkBI;
}

bool LTMPgsswe::UgNXjTexeGAmvYUr(string YMdiekTlYfusyQn, int dZzXDuyYz, int wwxvVrRvlRg, int iILMPBwipX, string aWHXbrWkmZn)
{
    bool wBwuIrpMOdj = true;

    for (int lYsyZWdtmAZoFOez = 1783292200; lYsyZWdtmAZoFOez > 0; lYsyZWdtmAZoFOez--) {
        continue;
    }

    return wBwuIrpMOdj;
}

bool LTMPgsswe::UsnMQayXJnAKfFmY(int uSVgCSAaWlhw, double tddBMhXojKKnaj, string ukBmvf)
{
    bool WLaMHdoKhJQunH = true;
    int VssCV = 1107396484;
    string XWvOctaalIYYfo = string("fekJzFwNoNDsMyYmifUROsnlrdnhQcYRACJ");
    int BEboIi = -1145871166;
    double bDnWMNekglYeEIex = -419057.2942723945;
    bool uxyXvQbwCdlaH = true;
    bool RTEMcNGStDbA = false;

    if (tddBMhXojKKnaj < -419057.2942723945) {
        for (int XGRZt = 2147421354; XGRZt > 0; XGRZt--) {
            XWvOctaalIYYfo += XWvOctaalIYYfo;
        }
    }

    if (RTEMcNGStDbA != true) {
        for (int pQumnaPHnMHYZ = 1722685246; pQumnaPHnMHYZ > 0; pQumnaPHnMHYZ--) {
            RTEMcNGStDbA = uxyXvQbwCdlaH;
            VssCV = BEboIi;
        }
    }

    for (int apcZhjmAsZSTtvTw = 1863631313; apcZhjmAsZSTtvTw > 0; apcZhjmAsZSTtvTw--) {
        VssCV -= BEboIi;
    }

    for (int hBmPSK = 36433701; hBmPSK > 0; hBmPSK--) {
        RTEMcNGStDbA = WLaMHdoKhJQunH;
    }

    for (int eLWkkiwaZuqB = 1100721409; eLWkkiwaZuqB > 0; eLWkkiwaZuqB--) {
        WLaMHdoKhJQunH = ! uxyXvQbwCdlaH;
        BEboIi -= BEboIi;
    }

    return RTEMcNGStDbA;
}

bool LTMPgsswe::TABWWGWpwIIv(int smsNy, bool CwlBwQruCxg, bool bmEKNjCLBBhfzxuy)
{
    bool NTuUTgcgxdUNxQ = true;
    int HmDlWWTFEChAZqW = 525041556;
    bool agkzdIpiU = false;
    bool DbgbLck = true;
    int YXCJhIDsStbw = -211957755;
    int fmOCDBeOYvaBO = -253598495;
    bool SYTNvpigqPydZiJD = true;
    int huGXC = -1203814258;

    for (int dEZoS = 806567191; dEZoS > 0; dEZoS--) {
        YXCJhIDsStbw *= huGXC;
        agkzdIpiU = bmEKNjCLBBhfzxuy;
        smsNy = YXCJhIDsStbw;
    }

    for (int wuYzSk = 20751055; wuYzSk > 0; wuYzSk--) {
        SYTNvpigqPydZiJD = ! bmEKNjCLBBhfzxuy;
        CwlBwQruCxg = ! SYTNvpigqPydZiJD;
        smsNy *= smsNy;
        bmEKNjCLBBhfzxuy = ! CwlBwQruCxg;
    }

    if (NTuUTgcgxdUNxQ == true) {
        for (int MuQHHpHIuhDnPcnl = 1596460218; MuQHHpHIuhDnPcnl > 0; MuQHHpHIuhDnPcnl--) {
            YXCJhIDsStbw /= smsNy;
        }
    }

    return SYTNvpigqPydZiJD;
}

bool LTMPgsswe::wNcZBDY(int fblMvAkR, bool ukMFXzeAeYQpOI, double VpjAnecJfV)
{
    bool OESwSZMLNig = false;
    bool CkEitNaGem = true;
    double OBCmzIDRUzyScY = -80545.42633048647;
    bool qsBlKSDAV = false;

    for (int KJIBsNL = 1261557990; KJIBsNL > 0; KJIBsNL--) {
        continue;
    }

    for (int QjeJzoA = 1621385124; QjeJzoA > 0; QjeJzoA--) {
        qsBlKSDAV = ! qsBlKSDAV;
        CkEitNaGem = ukMFXzeAeYQpOI;
    }

    if (CkEitNaGem == true) {
        for (int wqCxNFzG = 1845376340; wqCxNFzG > 0; wqCxNFzG--) {
            OBCmzIDRUzyScY -= VpjAnecJfV;
        }
    }

    if (ukMFXzeAeYQpOI == false) {
        for (int HuUXAZJweM = 1504517078; HuUXAZJweM > 0; HuUXAZJweM--) {
            ukMFXzeAeYQpOI = ! ukMFXzeAeYQpOI;
            fblMvAkR = fblMvAkR;
        }
    }

    return qsBlKSDAV;
}

bool LTMPgsswe::qGcIvj(string ogLmPpOvKcviD, double EIoKQGKCqTn)
{
    double jmTJHyLwBltwkjtD = -450747.3840613789;
    double HCrUWfkjjzVvrYE = -277478.58120209543;
    double XBgxgvsFN = 776093.4148997507;
    int CacIs = -677609440;
    string LTZtSioxedPJRbf = string("ntieZykNqPlWdpxDpAXenKR");
    int NjSNLFYvN = 824442913;
    string IDhkllYXii = string("ThdmxPRhNiZYsWYLmXzeDaKkCSoXbTmgTRvwBKDamsIEPJoqsnwvfJpQHVKwEUuxPFgwDoZZrXRAudhZMKYPwrjaaUIdxVOYHaqPXpnFhCjhmemQHqsHBiINBdHruHXfEfwBHnyirWkrjNxrQesrzzfACWNgpYxuVzxKgVIhABQYbWJcdcYOgrtxQOORHMnaHFPflbOYVtYLWwvIqDEkIwYvZkbfMcdWCNDTaRMPENzRPIgeYjgIx");
    double MZUxaSby = 966176.3970541481;

    for (int myJOYzCkf = 917001614; myJOYzCkf > 0; myJOYzCkf--) {
        ogLmPpOvKcviD += ogLmPpOvKcviD;
        HCrUWfkjjzVvrYE += EIoKQGKCqTn;
        MZUxaSby -= XBgxgvsFN;
    }

    for (int MywAGaBGCFLCPcj = 1572844301; MywAGaBGCFLCPcj > 0; MywAGaBGCFLCPcj--) {
        jmTJHyLwBltwkjtD *= EIoKQGKCqTn;
        XBgxgvsFN *= MZUxaSby;
        CacIs -= NjSNLFYvN;
        HCrUWfkjjzVvrYE /= XBgxgvsFN;
        ogLmPpOvKcviD = IDhkllYXii;
        LTZtSioxedPJRbf += LTZtSioxedPJRbf;
        HCrUWfkjjzVvrYE /= MZUxaSby;
    }

    for (int avuMHXm = 1733405780; avuMHXm > 0; avuMHXm--) {
        continue;
    }

    if (jmTJHyLwBltwkjtD < -450747.3840613789) {
        for (int nxAwkCFED = 381457357; nxAwkCFED > 0; nxAwkCFED--) {
            XBgxgvsFN /= jmTJHyLwBltwkjtD;
        }
    }

    if (NjSNLFYvN == 824442913) {
        for (int beDMuIcfDPX = 1724478007; beDMuIcfDPX > 0; beDMuIcfDPX--) {
            ogLmPpOvKcviD += LTZtSioxedPJRbf;
            ogLmPpOvKcviD += ogLmPpOvKcviD;
            HCrUWfkjjzVvrYE /= EIoKQGKCqTn;
        }
    }

    for (int YzCyCyqrNH = 488100745; YzCyCyqrNH > 0; YzCyCyqrNH--) {
        jmTJHyLwBltwkjtD = jmTJHyLwBltwkjtD;
        MZUxaSby *= XBgxgvsFN;
        jmTJHyLwBltwkjtD += EIoKQGKCqTn;
    }

    return false;
}

int LTMPgsswe::PxJgHwViLAVfwwLq()
{
    double LjBRrhWFrOVLRBJ = -651229.7723491349;
    double IigeBbYrb = 626980.8604078355;
    string fmbuHEZbBhi = string("UKnJRxWfegtuUhJPwVyEMCwAoYNBhlvITDEBXFTyvsShVSIVJBBFJTPMuFxSCKrYbzUhEXS");
    double TsZgGLkpjtK = -554867.3859518613;
    int HeLOQHwXvNNdFiNX = -2018970216;
    int XoXiBw = -393149031;
    int caOefJLNngz = 2002996750;
    bool JMOMh = false;
    string zbsbH = string("JrBLSyavVjZMoeWjKissAca");

    for (int XeDxxezEgOb = 1585924259; XeDxxezEgOb > 0; XeDxxezEgOb--) {
        caOefJLNngz += HeLOQHwXvNNdFiNX;
        zbsbH = zbsbH;
        IigeBbYrb /= TsZgGLkpjtK;
    }

    for (int lcRcII = 2053022394; lcRcII > 0; lcRcII--) {
        caOefJLNngz += HeLOQHwXvNNdFiNX;
        LjBRrhWFrOVLRBJ = IigeBbYrb;
        JMOMh = JMOMh;
    }

    return caOefJLNngz;
}

void LTMPgsswe::hmPwaFWraYoj(double fVhHIYXjtEWI, string iZFNvOsDx, double AOEkKTaHcm, int MVoTuYcsf, double dEZymjIiFFqyLFw)
{
    double JRuHlg = 475300.9067332776;

    if (MVoTuYcsf == 1662879093) {
        for (int OyEpmGDmPOdrspnK = 1299595592; OyEpmGDmPOdrspnK > 0; OyEpmGDmPOdrspnK--) {
            AOEkKTaHcm = fVhHIYXjtEWI;
            dEZymjIiFFqyLFw += fVhHIYXjtEWI;
            AOEkKTaHcm = AOEkKTaHcm;
            fVhHIYXjtEWI -= dEZymjIiFFqyLFw;
            AOEkKTaHcm -= JRuHlg;
        }
    }

    if (JRuHlg > -771513.2727058791) {
        for (int vBdGCrDnAnpXLQdK = 61906622; vBdGCrDnAnpXLQdK > 0; vBdGCrDnAnpXLQdK--) {
            fVhHIYXjtEWI *= JRuHlg;
        }
    }

    for (int QdpxcVklzZw = 1907337774; QdpxcVklzZw > 0; QdpxcVklzZw--) {
        fVhHIYXjtEWI += JRuHlg;
        AOEkKTaHcm = AOEkKTaHcm;
    }

    if (dEZymjIiFFqyLFw == -771513.2727058791) {
        for (int ZGustZdKFtAJ = 1594500507; ZGustZdKFtAJ > 0; ZGustZdKFtAJ--) {
            dEZymjIiFFqyLFw += dEZymjIiFFqyLFw;
            fVhHIYXjtEWI /= AOEkKTaHcm;
        }
    }

    if (fVhHIYXjtEWI == 435992.8096369788) {
        for (int pevqeBq = 1006973443; pevqeBq > 0; pevqeBq--) {
            JRuHlg += fVhHIYXjtEWI;
            dEZymjIiFFqyLFw -= dEZymjIiFFqyLFw;
        }
    }
}

void LTMPgsswe::vjNuJgyrabFB(string JnrWJEnjSqskgr, int hlsInblgSckBNeDa, bool fwEFI)
{
    string KDILLaCkFhG = string("LfhKmGUocKqgBsXQMikRgKMEAFVlveDRjQDYoFEraUVjzPPMIEGLRnzEKcuxPBGXMSAKDIfWLSEywRoELzaucQEACJoaSfMjeQvrNcQPjQsDGIBLWlxvLmQizPXysDepzDEqWToJqBbCYgj");
    bool FCCPebsDZqc = true;
    int EBhxcCjPUHXTFMjZ = 1726573190;
    double EFFxzRgwhV = -680633.8229029801;
    int DtNasz = -715542209;

    for (int SucBnOT = 41025592; SucBnOT > 0; SucBnOT--) {
        EBhxcCjPUHXTFMjZ += hlsInblgSckBNeDa;
        JnrWJEnjSqskgr += KDILLaCkFhG;
        hlsInblgSckBNeDa = EBhxcCjPUHXTFMjZ;
        EBhxcCjPUHXTFMjZ /= DtNasz;
    }

    for (int mWPMjlIa = 1878530936; mWPMjlIa > 0; mWPMjlIa--) {
        EBhxcCjPUHXTFMjZ /= DtNasz;
    }

    if (FCCPebsDZqc != true) {
        for (int HtauBjKT = 1472933289; HtauBjKT > 0; HtauBjKT--) {
            continue;
        }
    }
}

double LTMPgsswe::xrpVAHxlPqHcsEUp(string jbqiqGmqhJl, string uRqmOBQGgTvIv)
{
    bool cDYqToSpMOiiOwnz = false;
    bool OxblaSBwitL = false;
    double cjilIxplofje = -184316.4548716521;
    double uunckFv = 749836.7660493884;
    double wiiQlPGyXbc = -548104.0984704503;
    bool oyLximohyWgbJDWa = false;

    if (OxblaSBwitL == false) {
        for (int MtJqpCnc = 1657181011; MtJqpCnc > 0; MtJqpCnc--) {
            OxblaSBwitL = ! cDYqToSpMOiiOwnz;
            cDYqToSpMOiiOwnz = ! cDYqToSpMOiiOwnz;
            wiiQlPGyXbc = cjilIxplofje;
        }
    }

    for (int NsrxzFyYVszm = 709472781; NsrxzFyYVszm > 0; NsrxzFyYVszm--) {
        uRqmOBQGgTvIv = uRqmOBQGgTvIv;
    }

    for (int lZHbfJb = 1179477298; lZHbfJb > 0; lZHbfJb--) {
        cDYqToSpMOiiOwnz = ! oyLximohyWgbJDWa;
    }

    for (int RReVzISrdCqmypP = 1984651517; RReVzISrdCqmypP > 0; RReVzISrdCqmypP--) {
        uunckFv = wiiQlPGyXbc;
    }

    if (jbqiqGmqhJl == string("GQOuQAsUoFFaeeYjAGaxigxoMMlnZQvYejMLAVZDADiWSpyjSBImpSyxMXjnngLdKtXrZORZDdzgxUNrbxWlNGsuwpDAxcUIVapJdvZuSjnUsorwTRANFwmajuVKgWNgOjuOQbzxpFQigVpfwTOJlFbpVwNKklrmUDFmfNoaYOTxvMgkTFMulGXnMgRfluCAxrMWGYbVbLebcK")) {
        for (int ZPqzwvggoaVC = 1328641555; ZPqzwvggoaVC > 0; ZPqzwvggoaVC--) {
            oyLximohyWgbJDWa = OxblaSBwitL;
        }
    }

    for (int YOJOxu = 843245011; YOJOxu > 0; YOJOxu--) {
        jbqiqGmqhJl += jbqiqGmqhJl;
    }

    return wiiQlPGyXbc;
}

void LTMPgsswe::ntADWuCzbrR(int dInNJZBKOWORcC, double rHJHWhoCGV)
{
    string MlmwMXTKNv = string("fmaApuolqiCDgtrZJgOSJrGxFFWgDExvVrvioFqtVUKZwhimJXYStIxASmFssHVWMYWvXGqUMpSjIlvHbUvtSTafMZWlBSWBDTjiSLSSzNmiAkdPcqoPhEbcZeauUYzZA");
}

string LTMPgsswe::FVGWunI()
{
    double fPUJMorVPAaWZ = -294562.5321023043;
    bool BGOpvGvoQ = true;
    int fsMBAAYfbOom = -1059007336;
    bool BBDSj = true;
    double cQquVMZlAToOIHL = -877172.0392493599;
    int qbKJdPVWdpQMAf = -1389775776;
    string RvzXmVzm = string("bEAKonwkHnEpuytootpLfmtmZRuRUNFYxTdWlnsSlnmGVCcYblEEnAiQtNSorgDmdbzxLpsKqYBaVjgqfqIMOAgJpwISKQmJXjtcYvIUkXzthddNkEKibwZkyHkRwXSAGvoLcZAUfBiwqzMe");
    int RRrhgPEg = 1495905550;

    for (int MMjwjCzhr = 503813343; MMjwjCzhr > 0; MMjwjCzhr--) {
        continue;
    }

    if (fsMBAAYfbOom > -1059007336) {
        for (int dZAAxzjZDwPxZ = 1193966702; dZAAxzjZDwPxZ > 0; dZAAxzjZDwPxZ--) {
            BBDSj = BGOpvGvoQ;
        }
    }

    for (int fUmEe = 1438718304; fUmEe > 0; fUmEe--) {
        qbKJdPVWdpQMAf = qbKJdPVWdpQMAf;
        qbKJdPVWdpQMAf *= fsMBAAYfbOom;
    }

    return RvzXmVzm;
}

string LTMPgsswe::wqUsYjMribkRXv(double hQqxYjBaXnYH, bool AHLPSpwpPYUBuY, double ZGSIYxSfrtS)
{
    int WSKbryE = -143341574;
    string kDpfSuoOcqhTQOeo = string("zEaSdkHVZKRJpwlVUCdldEiDNJYvwXMSyUyWcGAqqCSzZCbIlKpXquMGBWkAaeheYAElooDWJHbOekvWLNfJSstBTKxDSwQpyUdBenWHDuGlodlZrE");
    string VKfDKyc = string("JRtaXVLoHkCTasHNqRnIzdCaonaZWeHMGEhBHNGMTZUikXovPtmmtOtWYzsplVIBGbcsOAvuRsOUXQJXZVhifgQyqhdzzIVSjlMKUegRiTGeGTIhrNpFwVcKzkqJozliRJLhrCEfLLMOeUQPnxqOnBuDlThFFRwyNRspYxAdyFKxZxoiQcygDObtujscVNdVjCvylaLUgVdsoPzAdAUcPoftcxKPFeDbgYfbYmNVsnAkEsztehFZ");

    for (int tGymyiHujPXEc = 1224846172; tGymyiHujPXEc > 0; tGymyiHujPXEc--) {
        continue;
    }

    for (int qnvmokK = 655698149; qnvmokK > 0; qnvmokK--) {
        ZGSIYxSfrtS /= hQqxYjBaXnYH;
    }

    for (int NMbAFtHNNDeGmQ = 1050504157; NMbAFtHNNDeGmQ > 0; NMbAFtHNNDeGmQ--) {
        continue;
    }

    for (int GKkFAQG = 520670638; GKkFAQG > 0; GKkFAQG--) {
        continue;
    }

    for (int LJDJxBe = 1632684619; LJDJxBe > 0; LJDJxBe--) {
        VKfDKyc += kDpfSuoOcqhTQOeo;
    }

    return VKfDKyc;
}

int LTMPgsswe::PkILsbbeQMvL()
{
    int uBBNVLhKrSmIhT = 1243130028;
    bool dICFmXwFh = false;
    int gcXVxsnWhhiBjF = 1549071775;

    for (int wdnXgOdQOaXmop = 747650615; wdnXgOdQOaXmop > 0; wdnXgOdQOaXmop--) {
        uBBNVLhKrSmIhT = uBBNVLhKrSmIhT;
        gcXVxsnWhhiBjF -= uBBNVLhKrSmIhT;
        gcXVxsnWhhiBjF = gcXVxsnWhhiBjF;
        uBBNVLhKrSmIhT += uBBNVLhKrSmIhT;
        uBBNVLhKrSmIhT /= gcXVxsnWhhiBjF;
        uBBNVLhKrSmIhT /= uBBNVLhKrSmIhT;
    }

    for (int gxdmOfNDkj = 1704128954; gxdmOfNDkj > 0; gxdmOfNDkj--) {
        dICFmXwFh = dICFmXwFh;
        gcXVxsnWhhiBjF = uBBNVLhKrSmIhT;
    }

    for (int FYRlJJDJ = 1036581190; FYRlJJDJ > 0; FYRlJJDJ--) {
        gcXVxsnWhhiBjF *= gcXVxsnWhhiBjF;
        gcXVxsnWhhiBjF /= gcXVxsnWhhiBjF;
        uBBNVLhKrSmIhT -= uBBNVLhKrSmIhT;
        gcXVxsnWhhiBjF /= uBBNVLhKrSmIhT;
        uBBNVLhKrSmIhT /= gcXVxsnWhhiBjF;
        uBBNVLhKrSmIhT *= uBBNVLhKrSmIhT;
        dICFmXwFh = dICFmXwFh;
        gcXVxsnWhhiBjF += gcXVxsnWhhiBjF;
    }

    if (uBBNVLhKrSmIhT > 1549071775) {
        for (int TPixVvWpF = 1176976113; TPixVvWpF > 0; TPixVvWpF--) {
            uBBNVLhKrSmIhT /= uBBNVLhKrSmIhT;
            dICFmXwFh = ! dICFmXwFh;
            gcXVxsnWhhiBjF += gcXVxsnWhhiBjF;
        }
    }

    return gcXVxsnWhhiBjF;
}

void LTMPgsswe::pMjjDE(int PbYvxNSPDSUhv, double MpBckaokw, double qGyOSlvROHJyXZJF, bool oYrwrBMG, bool NBFogtE)
{
    int HFEfDiddiBxNbJi = 1218583877;
    double QCCOkfN = 316350.9651313135;
    int FQXIwoF = -925928731;
    string wTeOPh = string("yJOoBgTPaawNnQkYyxmhTpTIfvvEBZGVFwlqPgMchkVzYpSiBqmZvbVEbgaCaHAppmPUYSHevUCQFZZDRuKuPcFWZkJwwbvmsYHULJkZzpaiWGGtGVTdYnMOXPCvetlWDLDWNjCaIaKSSmgloIQwnOvDpSZjXCbKInbTHuOaXHanCQRmuMmQBtxBGrWNnAJzGvXlcRlLZnILooTH");
    int goTfIxJaYxRt = -1424879362;
    string VLkSBQytQcR = string("GwnmUtHMJpHpMBJcaChcLmDjZdKcffNpTeqgpazFVOuiqJNYQeiEqQMJBLNMMxzzrVxepTEngoVsVEIXjKAq");
    int hqIKVtVX = 1051435654;
    int KLdRlHdzXIA = -420189087;

    for (int WtDLdsY = 103697037; WtDLdsY > 0; WtDLdsY--) {
        HFEfDiddiBxNbJi /= PbYvxNSPDSUhv;
        qGyOSlvROHJyXZJF *= qGyOSlvROHJyXZJF;
        hqIKVtVX -= goTfIxJaYxRt;
    }

    for (int ZfHfszOzMct = 1230959683; ZfHfszOzMct > 0; ZfHfszOzMct--) {
        QCCOkfN = qGyOSlvROHJyXZJF;
        HFEfDiddiBxNbJi -= PbYvxNSPDSUhv;
    }

    if (PbYvxNSPDSUhv == 1051435654) {
        for (int qHTxUu = 112203397; qHTxUu > 0; qHTxUu--) {
            NBFogtE = NBFogtE;
        }
    }

    for (int nxnbARMdYqju = 1294677642; nxnbARMdYqju > 0; nxnbARMdYqju--) {
        HFEfDiddiBxNbJi = hqIKVtVX;
        goTfIxJaYxRt *= PbYvxNSPDSUhv;
        oYrwrBMG = NBFogtE;
        goTfIxJaYxRt *= goTfIxJaYxRt;
        FQXIwoF = goTfIxJaYxRt;
    }
}

int LTMPgsswe::RgusmgeJTwHsX(int tBdnJf, double tNqDhpGxCRpqLw, string AlYqWzNnq, string vggINDCNC)
{
    int asnFHYETiCymSfRR = 60279860;
    string Gpubg = string("tLYNWyixGgSgjPmcoXjBssjQfWWXprvyynbpcSZHmMYwYILvltCqGKytudaOVECzlTHvIaFrQaSolUVOBecUNtdxslZxIJpVZHKKQaBgmzODSRvKakciaDKEzOPIFgDHwSiWvLQSjPkpLYhCrFFrOXaYkkhzlisNZZnYgrhRvcANgliqng");
    bool sKDLittALat = true;
    string pktZHTKMhRIzo = string("EIWFBJQeujkWmiSuAZHRqexuRmvxaRNDfbttZMzXVbOUIQforMyyzRnusjVXzjlTGMCWwUOwSRuqMieSSzyFAFVaYccRJsWHsATMUFNWXIDKDIxUIuYwRkONBYNShQvBF");
    double zwlKfZZbqGsLUMMf = 653125.2705239045;
    double lwpQnAp = -530586.5364509096;
    bool kSCPkBUPgGYfX = true;
    bool PEEmxMyKEx = true;

    for (int eJAVC = 1732053905; eJAVC > 0; eJAVC--) {
        PEEmxMyKEx = ! kSCPkBUPgGYfX;
    }

    for (int xEfhPhgWrCVI = 263433833; xEfhPhgWrCVI > 0; xEfhPhgWrCVI--) {
        continue;
    }

    return asnFHYETiCymSfRR;
}

void LTMPgsswe::BJCRwIvrjCTcuJ()
{
    string HiWyEbtBYnWmoYk = string("lGbNfjlpFiuxEShPLGnqTYWybgRMOpiobYCXwUpzYegrjvaKsQRexbxyiBcawrFLOkHwaVuiSdPBZPzzPGlUVJXprTYdyugGKSuNKvVCWUHqealbIHSvJLcPZVrUaeulEIaTUTwzdtNhNhOgrgNVgRuKGwFeqnxdo");
    string ECRBhATBEuOg = string("CCETMiSzEKNEx");

    if (ECRBhATBEuOg < string("CCETMiSzEKNEx")) {
        for (int btkeAcTMAnXm = 983124990; btkeAcTMAnXm > 0; btkeAcTMAnXm--) {
            HiWyEbtBYnWmoYk += ECRBhATBEuOg;
            ECRBhATBEuOg = HiWyEbtBYnWmoYk;
            ECRBhATBEuOg += ECRBhATBEuOg;
            HiWyEbtBYnWmoYk += ECRBhATBEuOg;
            ECRBhATBEuOg = ECRBhATBEuOg;
            ECRBhATBEuOg += HiWyEbtBYnWmoYk;
        }
    }

    if (ECRBhATBEuOg != string("CCETMiSzEKNEx")) {
        for (int XQQEZd = 680352143; XQQEZd > 0; XQQEZd--) {
            HiWyEbtBYnWmoYk += HiWyEbtBYnWmoYk;
            ECRBhATBEuOg += ECRBhATBEuOg;
            ECRBhATBEuOg = ECRBhATBEuOg;
        }
    }

    if (HiWyEbtBYnWmoYk >= string("CCETMiSzEKNEx")) {
        for (int tMOsGVOex = 1830459913; tMOsGVOex > 0; tMOsGVOex--) {
            ECRBhATBEuOg = ECRBhATBEuOg;
            HiWyEbtBYnWmoYk += HiWyEbtBYnWmoYk;
            ECRBhATBEuOg = HiWyEbtBYnWmoYk;
            ECRBhATBEuOg = HiWyEbtBYnWmoYk;
            HiWyEbtBYnWmoYk = HiWyEbtBYnWmoYk;
            ECRBhATBEuOg += ECRBhATBEuOg;
            ECRBhATBEuOg += ECRBhATBEuOg;
            ECRBhATBEuOg += HiWyEbtBYnWmoYk;
            HiWyEbtBYnWmoYk += HiWyEbtBYnWmoYk;
            ECRBhATBEuOg += ECRBhATBEuOg;
        }
    }
}

LTMPgsswe::LTMPgsswe()
{
    this->bsjgElYoMWWGCTN(-174901407);
    this->kkVekCSriam(false, false, string("IqAvnuCExXKkFpfctwIPpKBApIVZufoiLKsfGPlQgWjRIdblbVYAKNaLzXJQEqJDelgNQVloDBxObVcpllQITgOuiTbutMkYTpmdGnPLNZLTTRzqnyEomrPstowSNaDkUxCfpxxntqxhppdfTSGSUpsHhfvBeBUoZhfmIlENMEIwhEuOTmxnQxtXKjxdUgRCPuQBVzbwhMeOARxLiuBij"));
    this->ZPXtLyGLhJGyJQP(-648821.6375265055, -1439483443, 590442.4290201804, 1315627943, true);
    this->UgNXjTexeGAmvYUr(string("CPRkWZCucZALHpyLHTAAVweCuWEgOFgQKgIEamphPgMlSHHQMFihdKarfrcftasKIbeEZzgcpqJwfooGvyfauoKTyzwaOxwxiIhuUfuTLzahVKPcdpSGPfBoROGUaIXMoiNQmDtcotWnibfxmurOXEEpq"), -650023724, -1825827088, 979789054, string("sHMNzkplEGQOV"));
    this->UsnMQayXJnAKfFmY(-647944078, -391013.62198488775, string("LTwsUPhqlrbPR"));
    this->TABWWGWpwIIv(-1792623469, false, true);
    this->wNcZBDY(-194182052, false, -879712.40512046);
    this->qGcIvj(string("xRPqaGEYinKcHxcunSMeBdrRteNIOIWObGCUiFdxosOhssnaqYivCswzZTSyGwLFGDXZPUiXmas"), -286642.23318957665);
    this->PxJgHwViLAVfwwLq();
    this->hmPwaFWraYoj(-771513.2727058791, string("aeyAyoIHHXBHfDzmzAuAiukcnrOhGlbLwYfmdelLOSJQgkTrDLICqqydoPdkApzHDrgQdiNGqhtJnupiNBvRBVDTVUWEisZbMscccxbXXTqYdaIeYNzTAuJxkpsrDDtgQWbKntFqfJJXEAwVFzxEqUxmuikogijuuYEMIxboKtnMYAxDiycIvTKizAMwXbTWUXBQxTPguuMybWxxH"), 263830.51855632506, 1662879093, 435992.8096369788);
    this->vjNuJgyrabFB(string("xAOfwpKZcJrTgtiFLzRjvkAWPBNKDlulorZpzzVlUbBLJAeQbr"), -1646621207, true);
    this->xrpVAHxlPqHcsEUp(string("YUJXNdxGNVnarmWNWsdzQaLLPlWjPDHPLIleZpYXuQtChiDUacRrMBtgBmrmAHQUvyuaLoARskVWPqYeAPeUwiELNZmhgsdNtSaEIaMsThyvGFWHvUiDFkZZbBtwqvQcPURQLoCNDimASJvaOyHmafvFsWlvXEJEueujxLakSdMGCBpSMCAWMvWsqIcunIwSOkOJRwAWPFDlIcyLfJvlikARiGjnajqDMrGASGSnBAVvNUDrQPLDCCtjHuT"), string("GQOuQAsUoFFaeeYjAGaxigxoMMlnZQvYejMLAVZDADiWSpyjSBImpSyxMXjnngLdKtXrZORZDdzgxUNrbxWlNGsuwpDAxcUIVapJdvZuSjnUsorwTRANFwmajuVKgWNgOjuOQbzxpFQigVpfwTOJlFbpVwNKklrmUDFmfNoaYOTxvMgkTFMulGXnMgRfluCAxrMWGYbVbLebcK"));
    this->ntADWuCzbrR(-1115622710, -424020.60751389805);
    this->FVGWunI();
    this->wqUsYjMribkRXv(568243.845059169, false, 766087.2450881667);
    this->PkILsbbeQMvL();
    this->pMjjDE(-1764706828, 497966.84065034776, -530719.9470166893, true, false);
    this->RgusmgeJTwHsX(968809665, -241043.35162343376, string("GSrIowebCnQUDqgZFlsZmTXYBjPvujDdXQfqNGImeVyl"), string("iiaMFgxtTEmNYqNquOYhLtXZHxDOu"));
    this->BJCRwIvrjCTcuJ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Wxquos
{
public:
    int cfllPRyllgMNlXUl;

    Wxquos();
    int iUvehwosyhBNg();
    void JeMidpAkkDnjO(int PxDSRaylfYpTy, double QGrOx, int OFKLRPbTC, bool rVZDIiXTjH);
    void nEmmyTk(bool mDZfXLY, string tGuXJQs, int aXgVDmFDaXprCOZ, string cIfBwnfyjNOEPpDn, bool DOBrDK);
    bool DCjIcphv(string GDZDBMfoVPBX, bool JQlAbcE);
    void qbtjqsiUdTjhhW();
    bool LacQqlIvN(string sqEsuNxdJDVcC, double oyOMaKcPXCcGytH);
    double qJaAFJMcUU(double BZquD, bool xJBsyasolCPtQVw, bool otlMQGFVSBRr, double xJMGoQgtz);
protected:
    int TFcTKMTKk;
    string ovYMxdBS;

    int VEUiElqMwAuhF(double jXZIUpVlnLYmHnL, double ioQvMili);
    bool IviwM();
    string KXbPrOZMFYpPyqN(int OuuKSLLAjbUGJUzO, string NVJocUEvtX);
    bool rlIWVJWwWplSXIOR(int CssTXbL, string DgZnUq, bool lNVvGjYkGyZmNhyZ);
    string AtZZboXinw(int hxikSYy, string RjEHxIxQtCbszX);
    bool qCcYQNeh(bool MRIZeH, int LGgugcRdOIFTtgAG, string LedKeIyZjzgIxmsa, double vfxQwfinkrKtcgH, string mJTZHyVgzlehdtH);
    int XYAHjoVNKg(string pAULqniQfXkUNfw);
private:
    int pkrDemhEFgMZT;
    string dBzaAmjdlXhqdDbX;
    bool UfjSghQSmQMgCys;

    void YGNjnychxur(double tZaiILJvZbhql, int VJONAYWI);
    void amKPqPnUnxRuxTp(bool avOvaaWxvSPEdSy, bool VPPYfBwl, string LgaSZuJUjTzKsknZ);
    void aEgHhuxPhYeA(bool vBxWcNye);
};

int Wxquos::iUvehwosyhBNg()
{
    bool WfNRod = true;
    int XZmmAiNQ = 1062623371;
    double heeftki = -981632.1131804935;
    int IiYzkfaqKqzB = 253832229;
    double ZIMqtTiXEelcOV = -344033.85177640273;
    double PfjMopRCwxrDecew = -240819.02657554456;

    for (int cuiimKvitBjYBL = 1298535967; cuiimKvitBjYBL > 0; cuiimKvitBjYBL--) {
        PfjMopRCwxrDecew += PfjMopRCwxrDecew;
    }

    for (int XUNqZUiO = 359558921; XUNqZUiO > 0; XUNqZUiO--) {
        heeftki += heeftki;
        IiYzkfaqKqzB += XZmmAiNQ;
    }

    for (int MDelxDKceWQMxUzS = 980756810; MDelxDKceWQMxUzS > 0; MDelxDKceWQMxUzS--) {
        ZIMqtTiXEelcOV *= PfjMopRCwxrDecew;
        PfjMopRCwxrDecew += ZIMqtTiXEelcOV;
        XZmmAiNQ /= XZmmAiNQ;
        ZIMqtTiXEelcOV = heeftki;
    }

    return IiYzkfaqKqzB;
}

void Wxquos::JeMidpAkkDnjO(int PxDSRaylfYpTy, double QGrOx, int OFKLRPbTC, bool rVZDIiXTjH)
{
    string SpWvfjLtGk = string("FMwXJVgKK");
    int WGMEiobzPjxu = -1187880448;
    bool dtXyOuUtYXrm = false;
    bool KHmxm = true;
    int QiKEx = -1341385894;
    string QhplTwDJ = string("MNQTSUbqRPsdeJpbOEFcjxGHpAJLxVFJvJxABbQLzIWDNiLhysMGnFIbcSiUYsIMWTBEhADhSAIaKzdMVKwcsyURIInkDHXPmnwFzEpbOMAHXMhyGAsaNtvQTWTbKpmtiYZrHFnLeXaASzrtYJDtoAVboLWJwGYXJBWKPlXKvgXjrwbXFbuoCxmPalVjmfromYtnCyYIxyvQNGRDLhtlpBdqCijkjuEBNYd");
    string xosLLT = string("OWtMjQENEmDIiLXVeaCWywnrTLLwIsfnzvsaQuAVAWOqdcQYHKyYFMjXxXVqnqwZhoaCKVtgpCyERi");

    if (QGrOx >= -783904.9237330703) {
        for (int MjZVodECk = 46105209; MjZVodECk > 0; MjZVodECk--) {
            rVZDIiXTjH = ! dtXyOuUtYXrm;
            OFKLRPbTC /= PxDSRaylfYpTy;
        }
    }
}

void Wxquos::nEmmyTk(bool mDZfXLY, string tGuXJQs, int aXgVDmFDaXprCOZ, string cIfBwnfyjNOEPpDn, bool DOBrDK)
{
    double abUIlxJwtj = 569836.1672647663;
    double tWchUJ = -147019.99092249916;
    bool PMESIuzbN = true;
    bool RTabDIAwcqNMTU = true;
    string wrvkgJeXrhaK = string("aRQGuFhOFchBlzZtdlJpMfuMVwsSK");

    for (int VAIXxSSrVKr = 743816859; VAIXxSSrVKr > 0; VAIXxSSrVKr--) {
        PMESIuzbN = ! RTabDIAwcqNMTU;
        cIfBwnfyjNOEPpDn = wrvkgJeXrhaK;
        PMESIuzbN = DOBrDK;
    }

    if (RTabDIAwcqNMTU != true) {
        for (int BnaaFHP = 1024277936; BnaaFHP > 0; BnaaFHP--) {
            mDZfXLY = DOBrDK;
            tWchUJ -= tWchUJ;
            abUIlxJwtj /= abUIlxJwtj;
        }
    }
}

bool Wxquos::DCjIcphv(string GDZDBMfoVPBX, bool JQlAbcE)
{
    int usgmGmedQSeNCbWL = -578948622;
    bool HFqrUrttSex = true;
    int NtttIYFf = -2111575406;
    string zXnfYwoUQuGj = string("KbxfwmvHGQIPxJjgVnOMNGbYgvKWEZIRSzDQWGCzAgceNbodoXxhWjMfuphGloONZIcFQjBkaStEdVnaSUPGHvBktpXWzmlvjQRdSqmTDLkwBuVsUNrnissfJBVLqbXBHIppzKBHwdFsaqUdkYgHLPjbQLCmCC");
    int VrkTshlaxKFwGNLB = -1832079455;
    int ZZzcYIOCUm = -232634214;
    string oHpVtGUSs = string("dBMWgkXsKCKsbJYjYocjjTSuajJbwiPxBBIgVIDlZebMRSCsLIXZTsWUYDUMzvLekkfqhjNTqbyTDmCdRvXVtZVzaZMQNKsOOJlJXzldZmGxIlsHHYraTECmmWvCBIrkSrjWjHTfPOxtFjPLVfcoFlDUGiStbmfktsHnKxQIyTaZmnDxyMLmZPZDByY");
    bool rrpinPMqTwX = false;
    int zbZEdWL = -375933232;
    int canAbpy = -804286393;

    if (usgmGmedQSeNCbWL >= -578948622) {
        for (int TiNSOWWUKj = 2115596166; TiNSOWWUKj > 0; TiNSOWWUKj--) {
            zXnfYwoUQuGj = GDZDBMfoVPBX;
        }
    }

    if (NtttIYFf < -1832079455) {
        for (int KzDVHfNyo = 1312238513; KzDVHfNyo > 0; KzDVHfNyo--) {
            rrpinPMqTwX = ! JQlAbcE;
        }
    }

    for (int tJLbXWDIKhQ = 274315937; tJLbXWDIKhQ > 0; tJLbXWDIKhQ--) {
        zbZEdWL -= VrkTshlaxKFwGNLB;
        ZZzcYIOCUm *= canAbpy;
        HFqrUrttSex = JQlAbcE;
        usgmGmedQSeNCbWL -= zbZEdWL;
    }

    for (int YvBYkzuOwOqE = 1714216271; YvBYkzuOwOqE > 0; YvBYkzuOwOqE--) {
        NtttIYFf += ZZzcYIOCUm;
        HFqrUrttSex = JQlAbcE;
    }

    return rrpinPMqTwX;
}

void Wxquos::qbtjqsiUdTjhhW()
{
    bool LfpCTYQjTKLIRusq = false;
    int QXBFXXgwBRwgVcDD = 1834670715;
    string tEzmYoczLV = string("RglTqNKFFSSNtLiAAzVSrfsYiVTYLEmcWOXTJfhDCmMMwuipBPVKmnuugSVgbDjPTouTfbOjghtkWQdTdrPbtMKzqyHKgO");
    string LCElqAKNDbmolG = string("bDGByuZrqReJauCdVLebdfqdAPzPywIaTdPKlGwauaDxjoGTHNTYqRBwXQwvTQfXEQFUGeLlwwuSJfBlntSjKvXxKfXcJojxTsAzLDtVAIIKrGLcteYUaWNunssYdNPlMhAsFAIGxBagDabRGaWxpnyKMoVdfCpxRmAxLsujMKHWfIkSIxMuLZmMWvqfTgjspaPVgBRQUOhpQLkHMzEgdhzmnIUAKQDnvvRysdfSUMMx");
    bool XGjRvgkcChkEu = true;
    int CGiSAOZhJQqkce = 1498810085;
    double VGdnXZLDQp = 604243.0072926446;
    bool ZJmaj = true;
    int NUJtCXPeDkH = 474431949;
}

bool Wxquos::LacQqlIvN(string sqEsuNxdJDVcC, double oyOMaKcPXCcGytH)
{
    double uNlQoLaEIPoAys = -850607.4400367226;
    int AalyHdryOio = -272446379;
    string yeiPjJdwAH = string("yhWwFiUNfqiSNBlIzKbomeeZqWNYHJSKVURHCVprdWkhlASoKkUCRmPVwwOccwbPZVCjiZiDZcHIQygvqZhVEUoxVNvDaRGTNDpsfdNPrElYCPngrYsQOjIPViYDannSeXBSFnMTFjmqWcJXPUFZQLNMLrRvhYflzLkWuizOwaOLDdMoPeZIahUDmMIXNIWWQJVqNtVwlNk");
    string YCZazY = string("e");
    double yYoUyNt = 11570.632612475269;

    for (int yTtZkPxYikMHoEW = 125596435; yTtZkPxYikMHoEW > 0; yTtZkPxYikMHoEW--) {
        oyOMaKcPXCcGytH += yYoUyNt;
        sqEsuNxdJDVcC = yeiPjJdwAH;
        oyOMaKcPXCcGytH -= yYoUyNt;
        YCZazY = sqEsuNxdJDVcC;
    }

    if (oyOMaKcPXCcGytH < 11570.632612475269) {
        for (int xCNKDUbl = 1607364376; xCNKDUbl > 0; xCNKDUbl--) {
            oyOMaKcPXCcGytH /= oyOMaKcPXCcGytH;
            oyOMaKcPXCcGytH /= uNlQoLaEIPoAys;
            sqEsuNxdJDVcC += yeiPjJdwAH;
        }
    }

    if (YCZazY != string("baVgDIFIoIwBNgFYxJWahbcuDzVR")) {
        for (int VxmGoKuPabPSFT = 1723881298; VxmGoKuPabPSFT > 0; VxmGoKuPabPSFT--) {
            continue;
        }
    }

    if (oyOMaKcPXCcGytH <= -850607.4400367226) {
        for (int xCQQb = 1922058897; xCQQb > 0; xCQQb--) {
            yeiPjJdwAH += yeiPjJdwAH;
            sqEsuNxdJDVcC += sqEsuNxdJDVcC;
        }
    }

    return true;
}

double Wxquos::qJaAFJMcUU(double BZquD, bool xJBsyasolCPtQVw, bool otlMQGFVSBRr, double xJMGoQgtz)
{
    bool qpSGKNSO = true;
    double VmcfUiXsB = -706896.423405699;
    bool vwFWVWffVIk = false;
    string JlmTstRUETRXya = string("KMfinlEUHhKyxtaiwSovmJlLBOONsDtPREQIkynRApzPbciXyNrwDPLmSVlbCtaonnMIqiEyPsYILJH");
    string OZgnnvWbn = string("vIGLwDRCvlMhHVkNFXyoXmFwpyZZkgshBxnvGQxQvNKqZUOtPNXvXSaalHxejsiHIPleUNMVjyCjmildgjuJGhfDxQPnMtXdFfNQZ");
    double SttwOIHOcFta = 727964.5211897785;

    for (int oddMsuDcURdB = 14113446; oddMsuDcURdB > 0; oddMsuDcURdB--) {
        continue;
    }

    if (xJBsyasolCPtQVw != false) {
        for (int MpOBQzkeBTQNWQM = 598120881; MpOBQzkeBTQNWQM > 0; MpOBQzkeBTQNWQM--) {
            OZgnnvWbn += JlmTstRUETRXya;
        }
    }

    if (xJMGoQgtz > 727964.5211897785) {
        for (int zsudk = 111744751; zsudk > 0; zsudk--) {
            qpSGKNSO = ! qpSGKNSO;
            qpSGKNSO = ! otlMQGFVSBRr;
            xJMGoQgtz /= xJMGoQgtz;
        }
    }

    if (VmcfUiXsB > 727964.5211897785) {
        for (int hYsTETGzUPw = 200357450; hYsTETGzUPw > 0; hYsTETGzUPw--) {
            SttwOIHOcFta /= BZquD;
            qpSGKNSO = otlMQGFVSBRr;
        }
    }

    for (int QLkefeQzbtfwkc = 64288492; QLkefeQzbtfwkc > 0; QLkefeQzbtfwkc--) {
        continue;
    }

    if (xJBsyasolCPtQVw != false) {
        for (int PepXZyY = 1543343785; PepXZyY > 0; PepXZyY--) {
            qpSGKNSO = otlMQGFVSBRr;
            BZquD /= xJMGoQgtz;
            vwFWVWffVIk = ! otlMQGFVSBRr;
        }
    }

    for (int QeDFhBzCME = 922529284; QeDFhBzCME > 0; QeDFhBzCME--) {
        BZquD /= xJMGoQgtz;
        VmcfUiXsB -= BZquD;
        qpSGKNSO = ! qpSGKNSO;
        SttwOIHOcFta *= xJMGoQgtz;
    }

    return SttwOIHOcFta;
}

int Wxquos::VEUiElqMwAuhF(double jXZIUpVlnLYmHnL, double ioQvMili)
{
    string HtBZjsQnA = string("GphFsgiPRAWNfnxTYVGrqBzRNJgYMuUNMLHunefRGJcKzk");
    int EzVCwKIIqevsXIn = -369892888;
    int mJPtcuTWEQj = -946129091;
    bool eBckDUSKluOaTPd = false;

    for (int PlwcYAwiUuT = 1150608641; PlwcYAwiUuT > 0; PlwcYAwiUuT--) {
        continue;
    }

    if (jXZIUpVlnLYmHnL < -18448.783423772256) {
        for (int lMXoLV = 1156286770; lMXoLV > 0; lMXoLV--) {
            mJPtcuTWEQj *= EzVCwKIIqevsXIn;
            ioQvMili = jXZIUpVlnLYmHnL;
        }
    }

    for (int kdyXCPSwqdx = 264168995; kdyXCPSwqdx > 0; kdyXCPSwqdx--) {
        eBckDUSKluOaTPd = ! eBckDUSKluOaTPd;
    }

    if (eBckDUSKluOaTPd != false) {
        for (int rNVQfZpEwxnhIq = 895249397; rNVQfZpEwxnhIq > 0; rNVQfZpEwxnhIq--) {
            jXZIUpVlnLYmHnL -= ioQvMili;
        }
    }

    for (int KbeTcs = 1025488803; KbeTcs > 0; KbeTcs--) {
        continue;
    }

    return mJPtcuTWEQj;
}

bool Wxquos::IviwM()
{
    int dcIxEut = 763824074;
    bool TaddrGIPI = true;
    string IhorbnVwXThyJO = string("YkaEduxiebGYibUYADwNHNPfKEtPvkxZoxsbnhVVvaAmfVVhmAKBavIudCNkGNYvgGBGSHZlwgDFaOHdktaNRgbyMtVNASClxdKJpecdZcMYPepEOPgfWwKbeoSwxJDpTfHhNckCgVbxkBAZmdcadSxHwCrcXpFuGLrVZQWnMDOHYXjwlcamDdAgvrfbXViygsmGyXkVHnhUrByLvCBnpTfIeZKmuufRktjafisirwIHCtJltdRPFUkC");
    int iaZja = -1427824599;
    double crWlbuBbNJ = 343824.00150644383;
    double BDmOhzunPFO = -883761.4392626575;

    for (int VyjhE = 584906647; VyjhE > 0; VyjhE--) {
        dcIxEut *= iaZja;
        dcIxEut += dcIxEut;
    }

    if (dcIxEut < -1427824599) {
        for (int hEyHMqlJsWt = 215607772; hEyHMqlJsWt > 0; hEyHMqlJsWt--) {
            continue;
        }
    }

    for (int FWphgvK = 1552967401; FWphgvK > 0; FWphgvK--) {
        IhorbnVwXThyJO = IhorbnVwXThyJO;
    }

    for (int EdwsUqdkX = 1367886197; EdwsUqdkX > 0; EdwsUqdkX--) {
        continue;
    }

    return TaddrGIPI;
}

string Wxquos::KXbPrOZMFYpPyqN(int OuuKSLLAjbUGJUzO, string NVJocUEvtX)
{
    double YKzNxrqJo = -3071.0408548827127;
    string afjLzjg = string("GPoNqKTcEINhecVckapYUQPVoBzIlgnypnDsFOglbOELIpOeDJYivAdwfLhnrbKGxXfRhGXYppSwJPXuERaILhyEiyrdeXxetjASAJXZiQltVicSSsbRbSQnnOXEwgaHSFOfOylxAggcGUxmjdRtfFXrWelzReBxtGHjpFSddPdkJkaNdkZEPjoqQICQidsNtDej");
    string ZtSlIQhDS = string("cBDMkoeejzLtPWUVbIglPvKJbzZXFWkUWsmdUjGugeEgKlpqBVuFiVPqURIINSRsRynyrsXjYeNLLBgSbsqNVgJBKgISgzwQojYWUZYUjDQgFuddXIZOazBERypwlwiyZiPaTKktrSrVvYSaZlhVCBVbyjsAWMIGjzTopcpEzBiyHaAWteWORNqGsltMHRLxhNlnlEbweEVKHIZVTearRexHWxZRPtpdPBsoQnxCdnAICnH");
    string cSlmcHBbGsTmzfgt = string("nHdM");
    int qwmszUrIqid = 276044753;
    string azREeuaZ = string("HXeZxBdstrSZCupBkXJGCodFCmfZreMLvFBRGRsSMiksOnFtGgHBzciwhVTGDfQoWkiPgekJTVYnynDKwjuNvjljKqnRTfNmCKgjbICZIxhVrBliGrGoQzUxATFGNNwxDWOeVFfjcN");
    string GRnTE = string("eBruALXGqiyeDIMqfeZoVbLQRqIZKXplMArwZEgHeRmVAwWYzMXvglBtVeQTJBfbDnlliHRrMQaExNHGqrmuBPcQxvzXBFviHQDpCyxYExAzZcSORvLvEulcvdsYUiQSvmRHkMHHNmxuGHMlanMoRmPckEsFJrzDgCZijpMnSlXpvXVAQQKWrakFEjuQfSAojVCGNUnnFextBwZjDxOUvbmYsSGQLWzScOnCXLjUnbCmWPdkNCbZJWv");
    bool fpqxXS = false;
    string izlzXa = string("prAkJfCxdWItXamXQNsXSkROJZkOqGOowjzzJAQQGbZsudXmDlrscwMenivf");
    double vHauIxWjpqGns = -632152.2455114166;

    if (izlzXa < string("GPoNqKTcEINhecVckapYUQPVoBzIlgnypnDsFOglbOELIpOeDJYivAdwfLhnrbKGxXfRhGXYppSwJPXuERaILhyEiyrdeXxetjASAJXZiQltVicSSsbRbSQnnOXEwgaHSFOfOylxAggcGUxmjdRtfFXrWelzReBxtGHjpFSddPdkJkaNdkZEPjoqQICQidsNtDej")) {
        for (int eXxOVJ = 1130312608; eXxOVJ > 0; eXxOVJ--) {
            ZtSlIQhDS += GRnTE;
            NVJocUEvtX = azREeuaZ;
        }
    }

    for (int zafDIBQAqU = 1612353418; zafDIBQAqU > 0; zafDIBQAqU--) {
        GRnTE = cSlmcHBbGsTmzfgt;
    }

    return izlzXa;
}

bool Wxquos::rlIWVJWwWplSXIOR(int CssTXbL, string DgZnUq, bool lNVvGjYkGyZmNhyZ)
{
    bool IZUCG = true;
    double MOMMeydk = 837366.9673919495;
    string JbMSOdLwJgIWAxF = string("uYTZkhwtqLVWxRmhjCWYiaDSujbIeMJbyDjYbCLCWumkpqyzdCavjVLfCWfXcwKyKAUmidcqBO");
    int OolYQqWKJTwKDzy = -2134312940;
    double BIOYh = -128480.07794670027;
    double eqQzKlDdFwYgP = -621900.9270754256;
    double lRFgsre = 413992.8936402437;
    int wdEmSTAmAh = -286121903;
    int bdQSRa = 1712659652;

    for (int aNCMmf = 588266795; aNCMmf > 0; aNCMmf--) {
        bdQSRa = bdQSRa;
        JbMSOdLwJgIWAxF = DgZnUq;
        bdQSRa /= bdQSRa;
        OolYQqWKJTwKDzy *= wdEmSTAmAh;
    }

    for (int QVRVSdTyVCUr = 453463103; QVRVSdTyVCUr > 0; QVRVSdTyVCUr--) {
        continue;
    }

    return IZUCG;
}

string Wxquos::AtZZboXinw(int hxikSYy, string RjEHxIxQtCbszX)
{
    string wuQVdUIw = string("epApEByTyLIbIzIstjFFqzfqPUGufTvcNzQSMZsgLyPImETBhINRVIqUAYAQEimrYAericObmtbfwkQItLRPTuuBxuuDijNxWosfwyYoezVAdoDwyiKOcVNYCPKmsizXsDHMWfarygUDIFFhkMQtrcHvfQHJIPVDCffxALLEmNfxdBTzvOvyACo");
    bool bPssYueu = false;
    double hyBGFqSRsNUFWWh = -515950.94233316096;
    double ibFuHXGpt = 1041634.0760172171;
    string ZcTNszpTzdpduts = string("Noujd");
    bool RhfggbiTal = true;

    if (wuQVdUIw <= string("Noujd")) {
        for (int tPnzxlW = 916942204; tPnzxlW > 0; tPnzxlW--) {
            RjEHxIxQtCbszX = ZcTNszpTzdpduts;
        }
    }

    for (int HSOTgIT = 1990797044; HSOTgIT > 0; HSOTgIT--) {
        RhfggbiTal = ! RhfggbiTal;
        hxikSYy -= hxikSYy;
    }

    if (RjEHxIxQtCbszX > string("mIlytwilYUsgj")) {
        for (int pmHDcOngy = 1593723098; pmHDcOngy > 0; pmHDcOngy--) {
            RjEHxIxQtCbszX = wuQVdUIw;
        }
    }

    return ZcTNszpTzdpduts;
}

bool Wxquos::qCcYQNeh(bool MRIZeH, int LGgugcRdOIFTtgAG, string LedKeIyZjzgIxmsa, double vfxQwfinkrKtcgH, string mJTZHyVgzlehdtH)
{
    bool acvdiNn = false;
    int LKFZXAcepUeiKWCG = 1370377695;
    string UzysxzaxAcvE = string("XJUPLVlGpDqHuxiSNVvCIePXOyowjjIeouITIPziqppzZPHLMUEyIdlJNeoptgeMGelnAytJxyMpxEaiwtWwfstoBetcvUNHUJgks");
    string eQUZPjbYBMZFOFWF = string("RbHnPsOoAptxIShJDTEUGnHlEfAGgVNgVdkhOOlDhJfRNRsHpIUFzmBioJfGuTuwwtkqZaccApvrvWLDuoFvSOyMAQgrJkEgwnaWNFgTwYUDgxLHyMOJ");
    int YFjyQWTfzU = -303942932;
    string gkxhWAWa = string("yYhAOtPOGcrTAOPLVeDQLEgAISjgPntPRQUqqCPxsOgqILMt");
    string oJSKOI = string("GrGehQaechpsdNskeNGIJkDxWLkbKUYcCUpvCKeMxLLDHSOTnPGTJOgipjcFfbeZAafCZKESGnMpgByvflfnPkNIbvASWcpUMlxMYFMKqNsneddESCMSTpAlunmDyZkTvVmlATxPUnqXOMHZGslrdVWHoSwJoAxDFgPBDrszgqvKFsuiNjHWiUoAAISYxdiyBhaFMIqphzASoHdLRLKbZuPVclShgqewtBV");
    double PKQdPmNsDUoLr = -411180.6450309223;
    string dmHdzDObHMTDYl = string("GwxvSjCveeRxeNArfFEtVeNoEwtSWwjyOsHaYXLbsvILVdnmvOmjWgffYbOYjBwKjIHxqqeNGTejMQFTnqMhxgNLyHWBzazWIhCXMoLVcHbZPHMzdoRIGipcdjkWlSHdYXfMowOUQkNoHNfGIhfbzHmyJGcNkqjcQaoI");
    int CxkxRijOh = -2144920115;

    for (int CTZbz = 1933773699; CTZbz > 0; CTZbz--) {
        mJTZHyVgzlehdtH += oJSKOI;
        oJSKOI += gkxhWAWa;
        gkxhWAWa = LedKeIyZjzgIxmsa;
    }

    if (gkxhWAWa >= string("GwxvSjCveeRxeNArfFEtVeNoEwtSWwjyOsHaYXLbsvILVdnmvOmjWgffYbOYjBwKjIHxqqeNGTejMQFTnqMhxgNLyHWBzazWIhCXMoLVcHbZPHMzdoRIGipcdjkWlSHdYXfMowOUQkNoHNfGIhfbzHmyJGcNkqjcQaoI")) {
        for (int NtHyrRBdpMcQmf = 1474242494; NtHyrRBdpMcQmf > 0; NtHyrRBdpMcQmf--) {
            gkxhWAWa = dmHdzDObHMTDYl;
            mJTZHyVgzlehdtH = LedKeIyZjzgIxmsa;
            dmHdzDObHMTDYl += eQUZPjbYBMZFOFWF;
            CxkxRijOh /= CxkxRijOh;
        }
    }

    return acvdiNn;
}

int Wxquos::XYAHjoVNKg(string pAULqniQfXkUNfw)
{
    string BhMYnPoJ = string("GWfEHVxImVWkdSxaFKvaxEnINYFFQEYdLtSuSqaFwWygMDYNiTSHvXFGOTtGUCyOttkvemHXXmIQnHulzyuSazIwUOLNrRejlijWKfeKCRKOkptKfQJtgXXgsFYoMZbnNCdYACnwMZeSGrQSkJcZTEowrHwEpJsrspQRIWThZYFFpiSGpIomeVjCmBpIuiEYbaPGxVIfawPHDAEXKYXwjBWNsrOrsjUwfYEueGSHfnGuJiLSmMKRVsJ");
    string pSawLDWqRYnHSoJ = string("rWUwmpJnJQhUzkNDEDBStpwEXttNuUAxfGdZOewnXMHSIRtzhaWlbTxEGiyYgKkLsPjalDKKbkkJUoAIDVbucajwnAUpOYbVsmTvZECmLChvxWaMHizaazZRqpMMjVtCaKDavezXRlgzWYTDLyABcunlMrDOsJWnADiONyZDZbmjRkwKvRmYwTREkZukboZcOSdGsweSejYKlsUVHnocWqWBmKzZtoYbcQdcXViYopOBWyLOSdlApl");
    bool DMVdMyec = false;
    double MjSHmXJ = 831209.9754708234;
    double GBDLAICmMyfzaVq = 1009207.7518251457;

    for (int kVgSGmZCAPfF = 1204848381; kVgSGmZCAPfF > 0; kVgSGmZCAPfF--) {
        GBDLAICmMyfzaVq *= MjSHmXJ;
        BhMYnPoJ += pAULqniQfXkUNfw;
        BhMYnPoJ += pAULqniQfXkUNfw;
    }

    for (int BEpuEJBBQfCMpn = 471213467; BEpuEJBBQfCMpn > 0; BEpuEJBBQfCMpn--) {
        pSawLDWqRYnHSoJ += pSawLDWqRYnHSoJ;
    }

    for (int gEtlEP = 1343468794; gEtlEP > 0; gEtlEP--) {
        GBDLAICmMyfzaVq = GBDLAICmMyfzaVq;
    }

    for (int fgKqgbKPLzq = 2015081425; fgKqgbKPLzq > 0; fgKqgbKPLzq--) {
        pAULqniQfXkUNfw = BhMYnPoJ;
        pSawLDWqRYnHSoJ += BhMYnPoJ;
        GBDLAICmMyfzaVq += GBDLAICmMyfzaVq;
    }

    return 183869467;
}

void Wxquos::YGNjnychxur(double tZaiILJvZbhql, int VJONAYWI)
{
    string qCqCeSTzEld = string("ainWXAwxWCjXPSWVxfqxHwevaOsXLCdCMnqjhUhmgdJyDTHIhwJmaJpqXlTKeTXOKIjzgRTVpCxlmoQQiTALUFrRzdVzkfFYkH");
    int QYedymkLKFYcSA = 1006157836;
    string AfictTmkloBixja = string("kSJVCMLbmtVgWXWFLk");
    string veHamdVulr = string("EUssoYyNewdxgsAcaWgeINYqZNdfudeFdpsZGdvxgjfFLTYWpFyPSDhNmZcMiBXDlECpqLvMHdhkLqXIOIawGajfLwDYvFyPIQhTUQduDSogariHdJcUXrrqPuLjZppivhXIxVHEnWGoUTGKvAnspNviZIGDJPMghTjdmwkqvxgmVYdixuwEthfIYKyQjYmGAdKmIMDvOxdvwGtbGSiwVkWmglcSkMqiWtlvktAccCFVcYHFn");
    string cJfEo = string("UqodkMlzXuiNZyqXepOdSTJrTeuXhzlPaQemVvepeJHXFbyPGpSOteEcjhNNzLVVUWJXbpXaPfdexwvEjOfmAAq");
    string lWbRbshSY = string("JKlBEGtNRxIWqLoTFGUywkqyrBhFKicJXtpYsxybZpwFFUljoKEDuAVmVcVpmPSCBVZkAjnqJeIAgqZcMrJNhkOnokNjYrcbLpvXxEasZYiWYbOKpZYtlPEqIZMcRDguGxzSqCLEOberffGIjYJKFTARbKsVKu");
    string KBOIkcbdPFHD = string("FQcaQjpxYKnKGPsSEFGFwOOYhlMxwMNObZCKDRDIxGcioIigCcPIEDoGYoMLOzEExrWRoUJNMjbCWYTYjfuBCLXfWGIRqvTyHUlcgYbYryjgrHwmeGxMwUTUDwgEMhtnAGguqIfxDGtOgnkuwHMzkGAGxsdKmNDibzaKyCnEuHXT");
    bool lRtzRVCoiwAx = false;

    if (lWbRbshSY >= string("JKlBEGtNRxIWqLoTFGUywkqyrBhFKicJXtpYsxybZpwFFUljoKEDuAVmVcVpmPSCBVZkAjnqJeIAgqZcMrJNhkOnokNjYrcbLpvXxEasZYiWYbOKpZYtlPEqIZMcRDguGxzSqCLEOberffGIjYJKFTARbKsVKu")) {
        for (int rNDiI = 111036747; rNDiI > 0; rNDiI--) {
            cJfEo = qCqCeSTzEld;
            VJONAYWI *= VJONAYWI;
            AfictTmkloBixja += qCqCeSTzEld;
        }
    }

    for (int wAwwHbCFIq = 802822980; wAwwHbCFIq > 0; wAwwHbCFIq--) {
        cJfEo = KBOIkcbdPFHD;
    }

    if (AfictTmkloBixja < string("kSJVCMLbmtVgWXWFLk")) {
        for (int iumJILR = 1339583809; iumJILR > 0; iumJILR--) {
            cJfEo = lWbRbshSY;
        }
    }
}

void Wxquos::amKPqPnUnxRuxTp(bool avOvaaWxvSPEdSy, bool VPPYfBwl, string LgaSZuJUjTzKsknZ)
{
    double GlRDJYJdFjMLGS = 288895.763153401;
    double nHGOov = -333160.7771113048;
    bool cmapWnqCfQ = true;
    double oVXQAFixzEWks = -294493.40729527595;

    if (LgaSZuJUjTzKsknZ >= string("CxkOItctKhzkirQtscHjMLiQxOmLYnHjucVmYWFOPqKuBxUdyTEXBWHCZcXOiagNBPBWGrYvhsZRuAroBFmKKh")) {
        for (int jXkRYJKi = 1991089601; jXkRYJKi > 0; jXkRYJKi--) {
            oVXQAFixzEWks /= nHGOov;
        }
    }

    for (int MnjiVCOyTXUjos = 1459570135; MnjiVCOyTXUjos > 0; MnjiVCOyTXUjos--) {
        oVXQAFixzEWks -= GlRDJYJdFjMLGS;
        LgaSZuJUjTzKsknZ = LgaSZuJUjTzKsknZ;
        GlRDJYJdFjMLGS -= nHGOov;
        avOvaaWxvSPEdSy = VPPYfBwl;
        nHGOov = oVXQAFixzEWks;
    }
}

void Wxquos::aEgHhuxPhYeA(bool vBxWcNye)
{
    bool nCbgrz = true;
    double qHiIHHYufk = -220020.95562277295;
    double YqEoqAOh = -149724.191613103;
    int GKpRhL = -1351292185;
    bool RYgqgAEKasTUuHuE = false;
    int lYHwXcbJE = -1403193613;

    for (int RDSDUxdqkPZqUOK = 1055004460; RDSDUxdqkPZqUOK > 0; RDSDUxdqkPZqUOK--) {
        nCbgrz = vBxWcNye;
    }

    for (int SPUCZYNzpgoqhK = 1583010314; SPUCZYNzpgoqhK > 0; SPUCZYNzpgoqhK--) {
        lYHwXcbJE += GKpRhL;
        YqEoqAOh += qHiIHHYufk;
    }

    if (vBxWcNye == true) {
        for (int trUdnKrFoA = 352216111; trUdnKrFoA > 0; trUdnKrFoA--) {
            RYgqgAEKasTUuHuE = ! vBxWcNye;
            YqEoqAOh /= qHiIHHYufk;
            YqEoqAOh += YqEoqAOh;
            vBxWcNye = nCbgrz;
        }
    }
}

Wxquos::Wxquos()
{
    this->iUvehwosyhBNg();
    this->JeMidpAkkDnjO(-2122735521, -783904.9237330703, 1405647459, true);
    this->nEmmyTk(true, string("QvlhM"), -1362566366, string("wrFkThLwnquYoeYLGKWYEyXyKezcznOOQGtdKQjWmSKprpuWWIVQfIHILRnMIFEcdWLvQUsVjldXfwJiChiqesCyNBWnlWfcrHyXrwKpkHoteCqogyjsLUfVVUTVUvNbpWgYEqOoERJteatdPmCDveWZHaofhgLpvMgbfeKOIhpbxlpdAjGNFaXmOeHGZRzEGQcNaqnnTkcdoYDxGtZoVPRcXwtmpY"), true);
    this->DCjIcphv(string("oUWeqpZyzODUYGCEmeQznOyjlHjdBUJwIxKgDdNnHOXNM"), false);
    this->qbtjqsiUdTjhhW();
    this->LacQqlIvN(string("baVgDIFIoIwBNgFYxJWahbcuDzVR"), -1001116.972000962);
    this->qJaAFJMcUU(-892635.2849971574, false, true, 363703.02593349904);
    this->VEUiElqMwAuhF(-18448.783423772256, 115202.38045317649);
    this->IviwM();
    this->KXbPrOZMFYpPyqN(79535128, string("tSZoMotVEZaDHwXcdT"));
    this->rlIWVJWwWplSXIOR(1224018416, string("QSOSkNvVSuslMkdpcjumtkFwJNXTZDZPkLUuNTcTKnqhKfhbsJJfPNvpdZVniivvoDykefPfgrRHHedrAzhJJtvVDPNFJwsVSHqUcScoPttfACAoycMxZpGZCxplHsfOEOnEarvnJBxEiQRozNupXWxwp"), true);
    this->AtZZboXinw(-1081038136, string("mIlytwilYUsgj"));
    this->qCcYQNeh(true, -1631297826, string("DSAyNFyuPGCDvYSItCWUkMcQKLIyxYivVnpZMzDtTdPXKovGVwSGlBLQYnzCraElpUTQycAaDAOAizNELiIEkcmbxynpyGZkhZExYkqBJByXdWVpUpiMqQyJtcIkJClvppnaBKzOVetZNGeSzbSLI"), -686268.8001232892, string("eXVrQBmjsxzGizzGoeUKJxixtOQeLBuPshjTwZvxehTuSxcDygqEfHoVpUxZXIhzTsgIVFYSYZdsoGYECAnkHTqphRkPSuThsfhxiceu"));
    this->XYAHjoVNKg(string("WWzAUPDGyLVQSilYlGbUETUTxKoGfgXWWIBhSfKFcADoNTvEhCxSTUQegQIXommdWTnIGllIGYnVSlyBNwwXAIcVOzHTQsOEYOzbvSkDELkraiOGMMeIYMWTsRoQOQUQNOcAMwcbrycafZzkjXVNtvWWZaCmdcSRgbbSJYvBrppjzWtbynCZnACgiSyxWoKlYcghj"));
    this->YGNjnychxur(-319763.0495872485, 604441102);
    this->amKPqPnUnxRuxTp(false, false, string("CxkOItctKhzkirQtscHjMLiQxOmLYnHjucVmYWFOPqKuBxUdyTEXBWHCZcXOiagNBPBWGrYvhsZRuAroBFmKKh"));
    this->aEgHhuxPhYeA(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eSlwysEYtjel
{
public:
    string pdNzEiws;
    double rDmwBYcaYPyY;
    int AjUpj;

    eSlwysEYtjel();
    bool PbEzW(bool FREPlVCeKp);
    double BbgCahhY();
    bool PTekoRXSTKbAB(string UMYRFYFglO, bool peOolRNFMG, string PlTCAILcvDwS, string ouzKOewPv, bool ZQfpM);
    double tCKyBieZecex(double QKKqwGnTuN, int emnLSlDkZDauWY, double RQNkYV, bool DOScitffrUid);
    string oKPsekaYklRxKDz();
    string reyVFxlkVrCedZ(double PCuaOQJg, int KvcBj, string BVVIYqthaEGe, bool SRksxDdrIKJDiTa, bool gHFhIDNKUFBnBH);
protected:
    int sTmVGCVenpKUdXi;
    int KVzDLfo;

    int ksGVTVyAgRq(bool vRTdCHQzyVUSQM, double nANtoJmV);
    bool pxhoulHSl();
private:
    bool FJyQq;
    int LcnwQCbKOTt;
    double kDagHrzfGBs;
    double QGUFgPAIhyRZ;

    double pOVhvpoPdPlBExEi();
    double mLXxQohzJioFUTc(int JrFvIanMw);
    int qjRIi(bool pmdNBXxmpNiektyC, int HEWtwkGOBtEINS);
    int STrYFwZLhpJcR(int AUFSRNuSY, bool ySDBOwtMpOL, double cpzwimRrUY);
    void YTsmSRoHTFrWk(int MjtsbuA, bool cOGkrQbOuHGJ, int BkwCzNLQ, int OQIFZGV);
    int BnpbLGDyDuwPZbOf();
    void hWjtWFe(bool LSZuCG, double JChPn);
};

bool eSlwysEYtjel::PbEzW(bool FREPlVCeKp)
{
    double eTAOGIpeTyPdvK = 1020484.2037185433;
    double yDsIAkKROSt = -577281.1459685261;
    double QRhwnpbaUq = -420036.1070891633;
    string WGwlBna = string("pkGBkyRutgWjaoZmBzjKaaMrnqIWQlBPvvpMZOnLZRXSlflrDdbEiMJCDcKmzPQlIUBBETgDFPzOiTDXqonGmKNjnJQKBHReVpyEykjFNSIPjGPyrRfvxazBdizblvqKSEIEkrJHXMqNVlPnxwyGmRxubilLOqKhjqNYLkYirIPYgemWQXQzdpoOfROJlqxenzibHePDtPPBuloGcDaPFwdc");
    string fXUzALMiImNPBf = string("yKOZYxiBVyVognEVMrsUhKGXlATiBSnGsuDlxZLmFhPaZyNtRJegEsrqCAnkshQQgwltyYYvANyxxcxgpmSMCpNluixcqjmPkYLiwpDYGiwmlCLgIkxykRdFQweKtRAvmiYjRjvtRTAVJmXABzorTOhoIqEZTaAuDSEGdDrLABdJSfATbUOsOcfrnoWNopQUGqCiKIYuJcipTRtZIOG");
    bool yKIcfB = false;
    string oxySPhK = string("UtxnJMUvxXCQcWaroLkqoykzQQZrkMdrqldzkjVQ");
    int ykPsWwU = 877647392;
    int aekiRjMnqrUFXId = 328113367;

    for (int YNOuRc = 1018665459; YNOuRc > 0; YNOuRc--) {
        aekiRjMnqrUFXId += ykPsWwU;
    }

    for (int EMlrDaCJGI = 567354303; EMlrDaCJGI > 0; EMlrDaCJGI--) {
        oxySPhK = oxySPhK;
        oxySPhK += oxySPhK;
        eTAOGIpeTyPdvK += QRhwnpbaUq;
    }

    return yKIcfB;
}

double eSlwysEYtjel::BbgCahhY()
{
    string FjUkKHWEOinM = string("OTCcdaMBOkzXoyMnVmOfNKQRvGeSASqpcrXgCvkyeVXHuaYsSJntmfXSvMizMiCcyNLorMPUhveYDgTUhSQlFCxuDxoMeHVklXbPzJDrmBrhcCkuurqEVLbwPrrTAOLxeNIfkFezUjZhabrSlQrkTitwxCwLLOPZGcvOwggZaTXQoghXxGuFnHtCBnx");
    int QlrzoNqcomGFk = -111482854;
    bool JyHPMHyH = false;
    int MUUtdeEEtAuA = -530280169;
    bool ZdFTibkxifuBJklM = true;
    double mmhhbbtPztuLhr = 114524.39766813062;
    int uBHPQEFHkhhiJ = 1976457256;
    string ydGpOMMlxGyQcd = string("pnwoIReInVODkddnxBVTxrIHlzOsQAGmkKWsFvvRHcUN");
    double cJzrCKyCP = -731556.8728610545;
    bool sETBQkjLh = true;

    for (int OZuoByznfeKzJIQj = 1725914113; OZuoByznfeKzJIQj > 0; OZuoByznfeKzJIQj--) {
        MUUtdeEEtAuA /= uBHPQEFHkhhiJ;
        uBHPQEFHkhhiJ += uBHPQEFHkhhiJ;
    }

    for (int weFKY = 791486104; weFKY > 0; weFKY--) {
        JyHPMHyH = ZdFTibkxifuBJklM;
        sETBQkjLh = ! JyHPMHyH;
        JyHPMHyH = ! JyHPMHyH;
    }

    if (ydGpOMMlxGyQcd >= string("OTCcdaMBOkzXoyMnVmOfNKQRvGeSASqpcrXgCvkyeVXHuaYsSJntmfXSvMizMiCcyNLorMPUhveYDgTUhSQlFCxuDxoMeHVklXbPzJDrmBrhcCkuurqEVLbwPrrTAOLxeNIfkFezUjZhabrSlQrkTitwxCwLLOPZGcvOwggZaTXQoghXxGuFnHtCBnx")) {
        for (int jritJ = 478610424; jritJ > 0; jritJ--) {
            continue;
        }
    }

    for (int FblXK = 1065074694; FblXK > 0; FblXK--) {
        continue;
    }

    if (sETBQkjLh == false) {
        for (int xsiqXiJGcLnVJ = 314283044; xsiqXiJGcLnVJ > 0; xsiqXiJGcLnVJ--) {
            continue;
        }
    }

    for (int tUyktHchFOmp = 958506210; tUyktHchFOmp > 0; tUyktHchFOmp--) {
        continue;
    }

    return cJzrCKyCP;
}

bool eSlwysEYtjel::PTekoRXSTKbAB(string UMYRFYFglO, bool peOolRNFMG, string PlTCAILcvDwS, string ouzKOewPv, bool ZQfpM)
{
    bool qrYvzDgkuzWYCqOe = true;
    int XieNCNtsP = 937964208;
    bool JNDaQeAVHELVDOtg = true;
    int eQVlVdlAKzDCwXVl = -838516857;

    for (int VaYxzLurdrIh = 1446647932; VaYxzLurdrIh > 0; VaYxzLurdrIh--) {
        continue;
    }

    for (int eTSkCefSGUHvMVZ = 1724081090; eTSkCefSGUHvMVZ > 0; eTSkCefSGUHvMVZ--) {
        ZQfpM = qrYvzDgkuzWYCqOe;
    }

    for (int DSeLujDU = 38778833; DSeLujDU > 0; DSeLujDU--) {
        ouzKOewPv = UMYRFYFglO;
        peOolRNFMG = ZQfpM;
        XieNCNtsP *= eQVlVdlAKzDCwXVl;
        JNDaQeAVHELVDOtg = JNDaQeAVHELVDOtg;
    }

    if (PlTCAILcvDwS >= string("GcXuLAqhEmvGhNhXQVTXLpXmEunheonAFthooLOIcwLVVzPtlfdIFLWPSTYle")) {
        for (int KEcseYdnck = 225183455; KEcseYdnck > 0; KEcseYdnck--) {
            ZQfpM = ! qrYvzDgkuzWYCqOe;
            JNDaQeAVHELVDOtg = ZQfpM;
            peOolRNFMG = ! qrYvzDgkuzWYCqOe;
            PlTCAILcvDwS = UMYRFYFglO;
        }
    }

    return JNDaQeAVHELVDOtg;
}

double eSlwysEYtjel::tCKyBieZecex(double QKKqwGnTuN, int emnLSlDkZDauWY, double RQNkYV, bool DOScitffrUid)
{
    string cftOLBBPN = string("ZJbtvyRWqkajLxyACxoNZaloVFEoPfUSqlEWZIDnPCPZKIvxBdFHGGMrwOXNdtvtgLODpUxrDUJMxUZrwXjmyxzcSyoWLrqRMIGnCOOmMfhnBGAHswkKEggKABqVTauCoZtoGCeWEYesDnjiQSWCFusTRpbACIfMvZFJTaDECprUgAFvrFNUZzADPJwGQfuBnpjfFJztvIIyJvLlQAYLlMsCCPznXdnCUPsJiimvoPJnxaCowZhchShTS");
    string IcLvyeKbowLBkzWZ = string("pTDemaCFMFgfBiTLBHlRTEZfpBPFl");

    for (int PvFaxDR = 1209974807; PvFaxDR > 0; PvFaxDR--) {
        cftOLBBPN = IcLvyeKbowLBkzWZ;
        QKKqwGnTuN += RQNkYV;
        QKKqwGnTuN /= RQNkYV;
    }

    return RQNkYV;
}

string eSlwysEYtjel::oKPsekaYklRxKDz()
{
    string PQmgRDdIATdcIX = string("LwqVESIiUteToTMFCQVcSGVDUAFyxktUWEMXCZbKgjLzxIhOTbTdLZMrWSbPKmNnwAFNWJJXibOUzEgWyCGJTwudCYNslJrVtjZTRhJaemAYOpbhCkXXLHenodajmOCZSDSGYgTzWAPgWrBkMgjKLWzrQGOxXTHUYTxDIHOAJlvZNz");
    double usIbEBaRxsThM = -933368.6936020881;
    string fkSanaSlqre = string("fPKzCwHjpBRcpoKCVCfzTnVONRLgYlgdRGODEFpDYGicfvZUytuvmGyPNpaiNkmZWmrpTWPQYuuNMQWFfUvcWFpqNCNZVLKPlamtgzRCvj");
    string NlSWFvbB = string("vJsjhxCFXKBWcptZFVkg");
    double qTGsZFMg = -758661.5768329733;
    string zxoINJZL = string("pPbWBEZFpMWMTDTTlHggFVoGeHAEovsnlhNnAXM");
    double DBnrVCs = 360168.760928398;

    for (int WBNbIcNWntDl = 495610372; WBNbIcNWntDl > 0; WBNbIcNWntDl--) {
        zxoINJZL += fkSanaSlqre;
        usIbEBaRxsThM -= qTGsZFMg;
        zxoINJZL += NlSWFvbB;
    }

    for (int okbsXdKea = 92953504; okbsXdKea > 0; okbsXdKea--) {
        qTGsZFMg *= usIbEBaRxsThM;
        PQmgRDdIATdcIX += NlSWFvbB;
        qTGsZFMg *= qTGsZFMg;
        NlSWFvbB += NlSWFvbB;
        usIbEBaRxsThM += usIbEBaRxsThM;
        fkSanaSlqre += NlSWFvbB;
    }

    if (NlSWFvbB >= string("LwqVESIiUteToTMFCQVcSGVDUAFyxktUWEMXCZbKgjLzxIhOTbTdLZMrWSbPKmNnwAFNWJJXibOUzEgWyCGJTwudCYNslJrVtjZTRhJaemAYOpbhCkXXLHenodajmOCZSDSGYgTzWAPgWrBkMgjKLWzrQGOxXTHUYTxDIHOAJlvZNz")) {
        for (int JGWVdXpMpyUnJX = 1352357842; JGWVdXpMpyUnJX > 0; JGWVdXpMpyUnJX--) {
            NlSWFvbB += NlSWFvbB;
        }
    }

    for (int OymsyxcVq = 1134965797; OymsyxcVq > 0; OymsyxcVq--) {
        qTGsZFMg *= DBnrVCs;
    }

    return zxoINJZL;
}

string eSlwysEYtjel::reyVFxlkVrCedZ(double PCuaOQJg, int KvcBj, string BVVIYqthaEGe, bool SRksxDdrIKJDiTa, bool gHFhIDNKUFBnBH)
{
    double ThvYGSfbQpsj = 653968.3416841513;
    bool GfwsqVAK = true;
    double ZQQLrwYARWKjCF = -504804.94618845603;
    string BbntXJr = string("sGTXENsevMqCUiOvJDGTFhsqWhDVkdBRjMQhFKGvAPquFWcikqxnfUYBfyRbTnLQBUqkfAMmTZaUWSemnOufkiEoDKAbLAlOFIBu");
    bool lLVptny = false;
    double suVUkCIcRPy = 445775.1398179091;

    return BbntXJr;
}

int eSlwysEYtjel::ksGVTVyAgRq(bool vRTdCHQzyVUSQM, double nANtoJmV)
{
    bool zABhflF = true;
    bool JfpgytyJESjwDqpc = false;

    if (vRTdCHQzyVUSQM == true) {
        for (int ssIJWffsqs = 1615875879; ssIJWffsqs > 0; ssIJWffsqs--) {
            zABhflF = vRTdCHQzyVUSQM;
            nANtoJmV -= nANtoJmV;
            zABhflF = ! vRTdCHQzyVUSQM;
        }
    }

    return 1608976606;
}

bool eSlwysEYtjel::pxhoulHSl()
{
    int YtEvZBJJDhqfXX = 625037714;
    int QCchMTNCBnTOvUu = -569581671;

    if (QCchMTNCBnTOvUu >= 625037714) {
        for (int FXOBjNcPUuPAe = 737271086; FXOBjNcPUuPAe > 0; FXOBjNcPUuPAe--) {
            YtEvZBJJDhqfXX /= QCchMTNCBnTOvUu;
            YtEvZBJJDhqfXX /= QCchMTNCBnTOvUu;
            YtEvZBJJDhqfXX = YtEvZBJJDhqfXX;
            YtEvZBJJDhqfXX -= QCchMTNCBnTOvUu;
            YtEvZBJJDhqfXX = QCchMTNCBnTOvUu;
            QCchMTNCBnTOvUu += YtEvZBJJDhqfXX;
            YtEvZBJJDhqfXX *= QCchMTNCBnTOvUu;
            QCchMTNCBnTOvUu = YtEvZBJJDhqfXX;
            YtEvZBJJDhqfXX += QCchMTNCBnTOvUu;
        }
    }

    if (QCchMTNCBnTOvUu < -569581671) {
        for (int OuwnDUKXQXkI = 1556162561; OuwnDUKXQXkI > 0; OuwnDUKXQXkI--) {
            YtEvZBJJDhqfXX += QCchMTNCBnTOvUu;
            YtEvZBJJDhqfXX = YtEvZBJJDhqfXX;
            QCchMTNCBnTOvUu *= QCchMTNCBnTOvUu;
            YtEvZBJJDhqfXX += QCchMTNCBnTOvUu;
            QCchMTNCBnTOvUu += YtEvZBJJDhqfXX;
            QCchMTNCBnTOvUu = QCchMTNCBnTOvUu;
            YtEvZBJJDhqfXX /= YtEvZBJJDhqfXX;
            YtEvZBJJDhqfXX += QCchMTNCBnTOvUu;
            QCchMTNCBnTOvUu += YtEvZBJJDhqfXX;
            YtEvZBJJDhqfXX -= QCchMTNCBnTOvUu;
        }
    }

    if (QCchMTNCBnTOvUu > -569581671) {
        for (int nyywRO = 329630996; nyywRO > 0; nyywRO--) {
            QCchMTNCBnTOvUu *= QCchMTNCBnTOvUu;
            YtEvZBJJDhqfXX += QCchMTNCBnTOvUu;
        }
    }

    return true;
}

double eSlwysEYtjel::pOVhvpoPdPlBExEi()
{
    double NcfFqLcgxPeZkYZP = 522675.516407138;
    string uhDORJRPZ = string("iiWLWOXgcMgWjjDKRJmblsjXsFaqScAtfiRkQFLar");
    int eoAmRdIuS = -1967767305;
    double NPuTKQEDRuRRual = 637627.7459980514;
    int YPUzhmafQhj = 628130695;

    for (int CqZCyOqn = 82095739; CqZCyOqn > 0; CqZCyOqn--) {
        NPuTKQEDRuRRual /= NcfFqLcgxPeZkYZP;
    }

    return NPuTKQEDRuRRual;
}

double eSlwysEYtjel::mLXxQohzJioFUTc(int JrFvIanMw)
{
    bool KejoggD = true;
    string BZgzac = string("CHJGZPTFKtkXUxefIUDJlaxicFaULrQNfKrllTNhBscQxKuBAUusbbYQZKpPpNmvjTwMqGfrMTHZrIhcjhxLXKuvvCuOGdLaCQKFHvLOcCjWLxVSKMBPuYPqIktffnwoQvQBXSJTieCMasallRXbXHukBEAREQpUyCMrEayJdmAUXuYQoDKAMAngWXgejKNMDUCRiyrsIoIclyJVlERKX");
    int QpuUKiyNf = -57032613;

    for (int TDAisZmzjErHouH = 336107891; TDAisZmzjErHouH > 0; TDAisZmzjErHouH--) {
        KejoggD = KejoggD;
    }

    for (int dqqjUjqZP = 961894871; dqqjUjqZP > 0; dqqjUjqZP--) {
        JrFvIanMw += QpuUKiyNf;
        QpuUKiyNf /= JrFvIanMw;
    }

    return 137917.39830554338;
}

int eSlwysEYtjel::qjRIi(bool pmdNBXxmpNiektyC, int HEWtwkGOBtEINS)
{
    double RMigFN = 625292.2572781823;
    double SghCBeyiv = -996384.2004349455;
    bool sHstDTxQVPnLFHW = false;

    for (int QanKAYmrYsJ = 842409431; QanKAYmrYsJ > 0; QanKAYmrYsJ--) {
        sHstDTxQVPnLFHW = ! pmdNBXxmpNiektyC;
        SghCBeyiv = RMigFN;
    }

    for (int jnmPWdWkc = 579364740; jnmPWdWkc > 0; jnmPWdWkc--) {
        SghCBeyiv *= RMigFN;
        pmdNBXxmpNiektyC = sHstDTxQVPnLFHW;
    }

    return HEWtwkGOBtEINS;
}

int eSlwysEYtjel::STrYFwZLhpJcR(int AUFSRNuSY, bool ySDBOwtMpOL, double cpzwimRrUY)
{
    bool DjtRFy = true;
    double jYSsQNznwHvZ = -257971.429457486;
    bool XVqkzTCDhKAgb = true;
    string gdGwatdOXY = string("HTNkPtyYXHHNXFsXxNnVRrOCvqUXKNVCoHcbUGlIKUkxyGfYwhmqlcpsTXzfsGRGHaJhQxoPOchLsuEsDRjJpVdsWnZieKBOZbxTEveVmliuxZoSKFvzoSJcxmMTMKAHJBYduzTwBjdXxhKppyNTEcuwbRWBTretgDonAdcGwtWtImXbEdMuLqtJPISXrRBFvoRWfCtjnvTMihoORQ");
    int hvSGJWtcd = -592064142;
    double nqhiWNKglY = -169589.77964763984;
    double xXEhN = 282141.64306456293;
    double Wpoxf = 223518.42218033815;
    double zRfOZrgFhBstJ = 831687.3813974737;
    int BtjFwCdcWPtzm = 948035690;

    if (AUFSRNuSY <= 708184840) {
        for (int MdkigUBpkw = 1321868759; MdkigUBpkw > 0; MdkigUBpkw--) {
            Wpoxf *= Wpoxf;
        }
    }

    if (cpzwimRrUY == 831687.3813974737) {
        for (int qQbOSZhPwncO = 147797610; qQbOSZhPwncO > 0; qQbOSZhPwncO--) {
            zRfOZrgFhBstJ += nqhiWNKglY;
        }
    }

    if (xXEhN >= -257971.429457486) {
        for (int LabXIRTWqpWKzp = 662684140; LabXIRTWqpWKzp > 0; LabXIRTWqpWKzp--) {
            Wpoxf = jYSsQNznwHvZ;
            AUFSRNuSY -= AUFSRNuSY;
            hvSGJWtcd += AUFSRNuSY;
        }
    }

    for (int GevliHsrECatE = 1211482739; GevliHsrECatE > 0; GevliHsrECatE--) {
        DjtRFy = DjtRFy;
    }

    for (int BYaYFaPSbIdHnLb = 1911150478; BYaYFaPSbIdHnLb > 0; BYaYFaPSbIdHnLb--) {
        xXEhN *= jYSsQNznwHvZ;
        BtjFwCdcWPtzm /= AUFSRNuSY;
        cpzwimRrUY = cpzwimRrUY;
        nqhiWNKglY = jYSsQNznwHvZ;
        cpzwimRrUY -= zRfOZrgFhBstJ;
    }

    return BtjFwCdcWPtzm;
}

void eSlwysEYtjel::YTsmSRoHTFrWk(int MjtsbuA, bool cOGkrQbOuHGJ, int BkwCzNLQ, int OQIFZGV)
{
    double gKiRoeayl = 154461.12023542725;
    int bCMQQWbAJLltFSKW = 2061934001;
    bool pkIvMuLcIqbpoU = false;
    int YiFlw = -2106539006;
    string jxTxEqMnUimvujhW = string("ONWIfbfbADtFtFFeEyIQUFLessxbQnzaMyasoFNrKLvUVBnnqZHcoOZYzexWPsFMUSTcmrkOVqweEEniTABSQwHNXYmewmzhNVwjaWgmEUMvzlKLhCBXpYDuivTwvVfKMSfmOouFcdlcISIiqopfcksUbSsHrVVzPeELbvCjtLgVWcjdxvbdMgaPeliNhGzexRmNmnixspHdedyBT");
    bool omXdciKd = false;
    double ROnxhPc = 643873.9306724982;
    bool lOiSRGBvyU = false;

    for (int IbkAjoEQgudzYYz = 112996533; IbkAjoEQgudzYYz > 0; IbkAjoEQgudzYYz--) {
        bCMQQWbAJLltFSKW += OQIFZGV;
    }

    for (int Ukdccd = 1246638089; Ukdccd > 0; Ukdccd--) {
        cOGkrQbOuHGJ = ! cOGkrQbOuHGJ;
        omXdciKd = cOGkrQbOuHGJ;
        BkwCzNLQ *= bCMQQWbAJLltFSKW;
    }

    for (int JyKPqtRNrbcDSZ = 2002308438; JyKPqtRNrbcDSZ > 0; JyKPqtRNrbcDSZ--) {
        BkwCzNLQ = YiFlw;
    }

    for (int IcrDnFzOUIWoF = 2076513810; IcrDnFzOUIWoF > 0; IcrDnFzOUIWoF--) {
        pkIvMuLcIqbpoU = omXdciKd;
        YiFlw += YiFlw;
        OQIFZGV /= bCMQQWbAJLltFSKW;
    }
}

int eSlwysEYtjel::BnpbLGDyDuwPZbOf()
{
    int fVQOIILURXgUadU = 1199392224;
    bool HQPoilKQjamAh = false;
    bool febXSLmqjoleCU = true;
    int umEZZ = -338475990;
    int KjvWbAJFuLUxkE = -513278350;
    string SnkNzAmqenmPyT = string("VVFLmfCUoYIgFxCDiFPYEKiomMESmejiAHcZDAQIIbSUkNwFvwViPEIXeUvANOkqlRKIXzMXoSkeOMQoCwbDcmlaEpzJviFLqDrvXplbqvSmWpyYWrtfOdkrFTohTubnyAxxJVASYVcrHfQmbqjDdgn");
    int UDAXtMhtVQdWQT = 229491457;
    bool sJJgSjAlJnkn = false;
    double dWgqh = -895796.6021114336;
    double etzSjUASvQUFI = -702079.1413667845;

    for (int moKVZ = 1094529982; moKVZ > 0; moKVZ--) {
        fVQOIILURXgUadU += umEZZ;
        KjvWbAJFuLUxkE /= KjvWbAJFuLUxkE;
        KjvWbAJFuLUxkE += KjvWbAJFuLUxkE;
    }

    for (int mHeTztsYtF = 1829636779; mHeTztsYtF > 0; mHeTztsYtF--) {
        dWgqh = etzSjUASvQUFI;
        umEZZ = fVQOIILURXgUadU;
        KjvWbAJFuLUxkE /= UDAXtMhtVQdWQT;
        umEZZ *= fVQOIILURXgUadU;
        febXSLmqjoleCU = sJJgSjAlJnkn;
    }

    if (dWgqh >= -702079.1413667845) {
        for (int BpytXlswDlU = 2042035199; BpytXlswDlU > 0; BpytXlswDlU--) {
            sJJgSjAlJnkn = ! HQPoilKQjamAh;
        }
    }

    for (int xkzqFWxPWfIZZC = 1730889548; xkzqFWxPWfIZZC > 0; xkzqFWxPWfIZZC--) {
        UDAXtMhtVQdWQT = KjvWbAJFuLUxkE;
        HQPoilKQjamAh = febXSLmqjoleCU;
        fVQOIILURXgUadU /= KjvWbAJFuLUxkE;
        HQPoilKQjamAh = ! febXSLmqjoleCU;
        UDAXtMhtVQdWQT *= UDAXtMhtVQdWQT;
    }

    return UDAXtMhtVQdWQT;
}

void eSlwysEYtjel::hWjtWFe(bool LSZuCG, double JChPn)
{
    int MjNOM = -1775126984;
    bool uBcZzQuiGusXat = true;
    int UxNpwxhsTbgELQ = -136610727;
    string gvWygyex = string("fBW");
    int IYxWsKAcLGvZ = -1127312092;
    int CaIaqvG = 502198727;

    if (gvWygyex < string("fBW")) {
        for (int AkOuld = 108524063; AkOuld > 0; AkOuld--) {
            UxNpwxhsTbgELQ += CaIaqvG;
            MjNOM += CaIaqvG;
            CaIaqvG += UxNpwxhsTbgELQ;
        }
    }
}

eSlwysEYtjel::eSlwysEYtjel()
{
    this->PbEzW(false);
    this->BbgCahhY();
    this->PTekoRXSTKbAB(string("fHzbbWiLSUyTZKMGfwXWFXDBsWbMWIUVSylPeHLkQIIqsdOiZvlVgBzIJucMZIkTPfPxANlafAnHQiaYQgixromfDQFkPlRGtxvHmjAcOmMpgbEUqZKRyZopabbaKS"), false, string("GcXuLAqhEmvGhNhXQVTXLpXmEunheonAFthooLOIcwLVVzPtlfdIFLWPSTYle"), string("vYjhSbyoRpMKyPsDfhBMxoZUWfYiSpEoPusBWAXyxzvMMx"), false);
    this->tCKyBieZecex(543071.162181528, 1682112924, 252565.1351399256, true);
    this->oKPsekaYklRxKDz();
    this->reyVFxlkVrCedZ(809835.823833822, -1580184379, string("oOtfyDxdIbdjSDyDwbhQRIOoafBKeClynehmaRAERXYuFEIeaHUiZNknVyhwnAdnBOyjxY"), true, false);
    this->ksGVTVyAgRq(false, 1014191.3607680649);
    this->pxhoulHSl();
    this->pOVhvpoPdPlBExEi();
    this->mLXxQohzJioFUTc(-2037296148);
    this->qjRIi(false, -1612996076);
    this->STrYFwZLhpJcR(708184840, true, 115582.23318000902);
    this->YTsmSRoHTFrWk(-241146574, true, -1483814161, 1687766920);
    this->BnpbLGDyDuwPZbOf();
    this->hWjtWFe(false, -53664.71746221994);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YdWRakA
{
public:
    int yPsoteM;
    bool SZafcZuhUSfFL;
    double TuiLsPZAVtJssN;
    bool mBdgU;
    double VQaslBWYul;

    YdWRakA();
    string tIjQfxA(bool gYsxlUpHPw, string MJmFuGbGuzMEHM);
    int CTYBmPbr(string QXSeVByqXlGa, string UHYTO);
protected:
    bool fVrGQuToR;
    double DPiuEHMYdq;

    void EfuOsWocsqehf(string wIhFYYBnDLd, int ThcfSojHOXYFttv, string ylDdgprl);
    int wTFNopJsUX(string vrcMjBaPgQQT);
    bool FWGpDbeMCEN(bool hcdputRF, int DjaWh, bool GWYcpTEUiQQ, double axnhHEemVXrghbKQ, bool ArNxXZjv);
    void HdNpDkyFqcdbNCv();
    bool XfBKnuHa(string CcsSopKEZRI);
    double ugyqJaGhXwDa();
    bool snveUrj();
    int hEOdb();
private:
    bool uuGuOgOSVoOGzngA;

};

string YdWRakA::tIjQfxA(bool gYsxlUpHPw, string MJmFuGbGuzMEHM)
{
    double EfqNUEtUJzE = -764554.6697733066;
    double vAmRcLPBJpq = 701514.8096711442;
    int qtpHVDLK = -242346627;
    string ahIITAIzJ = string("KJdmcyGSrnRtiKfovUoAOlkBSGhDxnkoDxrywTwAKgpFAxgKXdQFzTSdxkJgTMRyXCSNIuWkLnqztGs");

    for (int zSSqHTwrM = 1573092250; zSSqHTwrM > 0; zSSqHTwrM--) {
        gYsxlUpHPw = ! gYsxlUpHPw;
    }

    for (int FgqFYZqfj = 1742428247; FgqFYZqfj > 0; FgqFYZqfj--) {
        continue;
    }

    return ahIITAIzJ;
}

int YdWRakA::CTYBmPbr(string QXSeVByqXlGa, string UHYTO)
{
    int FDiYFkkBIStXzPoW = -605494641;
    int YcyZD = -192311588;
    double ATYUQ = 443862.186251332;
    string dZbjYNY = string("zEwwmuviYoQcNgtCMIIvYWDvyukPbxjrGYcZbRNAzThhickiZVNdqtVSGVcNIoOONMCssxNUbavAUeuyjtLJIsgpeJXUQSalnJeBuMTNjNzngLIrUagSEOyChLwInhZxcBpVQWnvjlzEkDOgWmquSuUEZySPKfSPIkvMVCEWMEtrEUfQTROvzWoLTVOPNMxFZCiraFBJXWBUUYPAd");
    bool UXoGGdOF = true;
    int PsPYKeplm = -761411487;
    string BDaleNrEiCEnA = string("gbUkrJKVJRRfybrJAaiNUVVHChvkBrNmqCQnwkAenPMQEVYBBUMkLJOiSlwKCBLeBIQINIFlJgtjwkiOarfGYuVmrpTmfKwfMfA");
    double jJCxMKSD = 672802.0843448426;
    bool BRHyqLNhGeBVc = false;
    int OnZVNslYAQ = -1418653739;

    for (int UpgVMWBpmaqOlMl = 947407906; UpgVMWBpmaqOlMl > 0; UpgVMWBpmaqOlMl--) {
        BRHyqLNhGeBVc = ! BRHyqLNhGeBVc;
        UXoGGdOF = BRHyqLNhGeBVc;
        UHYTO += dZbjYNY;
        UXoGGdOF = ! UXoGGdOF;
        BDaleNrEiCEnA = dZbjYNY;
        BDaleNrEiCEnA = BDaleNrEiCEnA;
    }

    return OnZVNslYAQ;
}

void YdWRakA::EfuOsWocsqehf(string wIhFYYBnDLd, int ThcfSojHOXYFttv, string ylDdgprl)
{
    bool CCtXFezsNu = false;
    bool ezVQgPoRiK = false;
    int pslMxfrRmQIWTS = -535884578;
    bool VTyfUEVRBrfSITGt = false;

    for (int cxhkG = 1310087842; cxhkG > 0; cxhkG--) {
        ylDdgprl = ylDdgprl;
        CCtXFezsNu = CCtXFezsNu;
        VTyfUEVRBrfSITGt = ! ezVQgPoRiK;
        ezVQgPoRiK = CCtXFezsNu;
    }
}

int YdWRakA::wTFNopJsUX(string vrcMjBaPgQQT)
{
    double jcgtIouQSnMZaB = -530527.8964194842;
    double PFtwIjbea = 861047.3625038447;
    double OAZqpSNEn = -992319.9057668095;
    double mrLQICimjnSJLt = 123282.46158452274;
    int gfSTYvXwTZIl = 1761126491;
    bool egzqLdPaljKQbqwM = false;
    int hCsyIZ = 387907837;
    double mAeTSkSDyIHf = -470938.23804516735;
    bool HBefeLynJPjedND = false;

    for (int uWvXiyEgFZtlO = 1248911589; uWvXiyEgFZtlO > 0; uWvXiyEgFZtlO--) {
        continue;
    }

    for (int mhHOOXd = 1211022058; mhHOOXd > 0; mhHOOXd--) {
        mAeTSkSDyIHf *= mAeTSkSDyIHf;
        mrLQICimjnSJLt -= OAZqpSNEn;
        OAZqpSNEn /= mAeTSkSDyIHf;
    }

    return hCsyIZ;
}

bool YdWRakA::FWGpDbeMCEN(bool hcdputRF, int DjaWh, bool GWYcpTEUiQQ, double axnhHEemVXrghbKQ, bool ArNxXZjv)
{
    double AFPnJc = 431635.2405498416;

    if (axnhHEemVXrghbKQ < 333968.6430922802) {
        for (int HvwUhzWfDCq = 1142654049; HvwUhzWfDCq > 0; HvwUhzWfDCq--) {
            axnhHEemVXrghbKQ = AFPnJc;
        }
    }

    if (hcdputRF == false) {
        for (int EIdVsOovbyh = 1979229221; EIdVsOovbyh > 0; EIdVsOovbyh--) {
            axnhHEemVXrghbKQ = AFPnJc;
            hcdputRF = ! hcdputRF;
            AFPnJc = AFPnJc;
        }
    }

    if (hcdputRF != false) {
        for (int ISCxneyOjY = 1612521950; ISCxneyOjY > 0; ISCxneyOjY--) {
            GWYcpTEUiQQ = GWYcpTEUiQQ;
            ArNxXZjv = ! hcdputRF;
            ArNxXZjv = hcdputRF;
            hcdputRF = ! ArNxXZjv;
        }
    }

    for (int uBEfoJTskmzIquEb = 206872402; uBEfoJTskmzIquEb > 0; uBEfoJTskmzIquEb--) {
        continue;
    }

    for (int ixeyKejUnfSbzGB = 280192628; ixeyKejUnfSbzGB > 0; ixeyKejUnfSbzGB--) {
        GWYcpTEUiQQ = hcdputRF;
    }

    for (int UlxCXcnzNZq = 308054435; UlxCXcnzNZq > 0; UlxCXcnzNZq--) {
        AFPnJc -= AFPnJc;
        axnhHEemVXrghbKQ -= AFPnJc;
        AFPnJc *= axnhHEemVXrghbKQ;
        axnhHEemVXrghbKQ *= axnhHEemVXrghbKQ;
    }

    return ArNxXZjv;
}

void YdWRakA::HdNpDkyFqcdbNCv()
{
    string crCHewqDdPYjWeCE = string("LaddSXTPdZYrGkRlkgQNmJKvRRSKgzZPebNTLhVssgdXXVuwoOXkRhzUOIoJdKiXMbEDaImjHssthGJlmTAnHZXlywViiktrEBLYFwlQvauvhUPRUotTWSibXMZyAyWeKKyItBKtMSQrgzUJvJAXPgFHnXusYjTKlLEcDw");
    double iYVrLg = -402063.5624655831;
    bool ywetIAGiyXSjMQsN = false;
    bool bDlnPTtnRcZNsvmk = false;
    double vKYLNPORvNyk = -323606.06499707163;
    string VGOCZuyDRzuDppf = string("EHnVIwVvUEMWrVSknaVAnkhxIMRITrmFqRgRHZkMDGTjfveNZNNZjpQRexgqjFPCRuDUzCHeQARXGPjwshJrteabRynwqhRZuEHgbzCMGxmW");

    for (int GTdjlLXZT = 562708776; GTdjlLXZT > 0; GTdjlLXZT--) {
        bDlnPTtnRcZNsvmk = ywetIAGiyXSjMQsN;
        ywetIAGiyXSjMQsN = ! bDlnPTtnRcZNsvmk;
        VGOCZuyDRzuDppf = VGOCZuyDRzuDppf;
    }
}

bool YdWRakA::XfBKnuHa(string CcsSopKEZRI)
{
    string JGzBv = string("GpCyxlRztRtTALADumpqkHGKcLwXFQv");
    double mJxjxnOMZcphURbd = 639699.3484139665;
    int TzQrD = 572245269;
    double zftNfjOws = 490284.2888551554;

    if (TzQrD >= 572245269) {
        for (int rgGadARRUp = 2086381075; rgGadARRUp > 0; rgGadARRUp--) {
            JGzBv += JGzBv;
        }
    }

    if (CcsSopKEZRI < string("GpCyxlRztRtTALADumpqkHGKcLwXFQv")) {
        for (int pebqEb = 1331891630; pebqEb > 0; pebqEb--) {
            continue;
        }
    }

    if (zftNfjOws < 639699.3484139665) {
        for (int mpwmd = 965353736; mpwmd > 0; mpwmd--) {
            CcsSopKEZRI = CcsSopKEZRI;
        }
    }

    return true;
}

double YdWRakA::ugyqJaGhXwDa()
{
    bool dIprXUXbf = false;
    string TglyyxchtxvUPXj = string("RIXuNBuDwporihvtyozzXasbNIWstYAPuYOpDRgsTETydSEzatILnDobjnLLnuFyOTrlqTrGswhMFFDOfR");
    double YJSlnePQfeQ = 511471.1861781575;
    double ggVET = 597603.0305078782;
    int ASosdmwQhcdW = 898197974;

    for (int chjWJwLTbp = 985791779; chjWJwLTbp > 0; chjWJwLTbp--) {
        YJSlnePQfeQ += YJSlnePQfeQ;
    }

    for (int FZIZUtI = 1177549500; FZIZUtI > 0; FZIZUtI--) {
        ggVET -= YJSlnePQfeQ;
        ggVET += ggVET;
    }

    for (int XBdgqxWCrO = 2015578464; XBdgqxWCrO > 0; XBdgqxWCrO--) {
        YJSlnePQfeQ = YJSlnePQfeQ;
        YJSlnePQfeQ /= YJSlnePQfeQ;
        YJSlnePQfeQ *= YJSlnePQfeQ;
    }

    return ggVET;
}

bool YdWRakA::snveUrj()
{
    int TZnvJjXsLGrT = -440662776;
    double aFEOGBkaMVMMJT = -92932.17997857055;
    int VidKAquslctBCR = -857178268;
    string wDWqQh = string("MUpuAijmBajCdEzLLlbdllDcApaHKTTJVnpwfLNCpVYqfMfrIbL");
    string sQXslz = string("OQWmQBgdVFCXkyRvNirBfjMXHqtev");
    int JcakPwdA = -1544044960;
    string uZFooYonQfU = string("PfSStMlFmLGtjzKbDZNbyEXpRDjPWxEgBYKeGCmxCXtgitzBOoSOLyCRlGgmYFvQHuuaOIAfpKUkJcwourOlkzUdXJLIfdNFaajFYZzXqmKxUZfHHsZRiXTbLCJnWHjYPyaVCwrbIOODiVkvsvHpgZMkkVo");
    int alPTgb = -1581619331;
    bool SsNBFmvi = true;
    int ijkNuCoRjZsoad = -538931981;

    if (wDWqQh <= string("OQWmQBgdVFCXkyRvNirBfjMXHqtev")) {
        for (int PbBqqlwuLMchnyp = 215604696; PbBqqlwuLMchnyp > 0; PbBqqlwuLMchnyp--) {
            VidKAquslctBCR -= alPTgb;
            sQXslz += uZFooYonQfU;
            TZnvJjXsLGrT /= ijkNuCoRjZsoad;
        }
    }

    if (VidKAquslctBCR == -1544044960) {
        for (int DHBJlHKRG = 474327344; DHBJlHKRG > 0; DHBJlHKRG--) {
            wDWqQh += sQXslz;
            sQXslz += sQXslz;
            TZnvJjXsLGrT *= ijkNuCoRjZsoad;
            wDWqQh = wDWqQh;
        }
    }

    if (ijkNuCoRjZsoad < -1581619331) {
        for (int Hifnwmhpn = 1782839229; Hifnwmhpn > 0; Hifnwmhpn--) {
            alPTgb += VidKAquslctBCR;
        }
    }

    for (int MjiULUUyWEDVBPpI = 1497457974; MjiULUUyWEDVBPpI > 0; MjiULUUyWEDVBPpI--) {
        VidKAquslctBCR -= ijkNuCoRjZsoad;
    }

    return SsNBFmvi;
}

int YdWRakA::hEOdb()
{
    double PpgIv = 516764.25691588304;
    int YMSLwejrqmvuS = 354190895;
    bool QxvQAOw = false;
    int BlnjnJOoYBk = -1804814761;

    for (int rdjcWtDffHlMTdFm = 1325267077; rdjcWtDffHlMTdFm > 0; rdjcWtDffHlMTdFm--) {
        PpgIv += PpgIv;
        YMSLwejrqmvuS /= BlnjnJOoYBk;
    }

    for (int edwlkBibKQxBkyyF = 1713988932; edwlkBibKQxBkyyF > 0; edwlkBibKQxBkyyF--) {
        YMSLwejrqmvuS += YMSLwejrqmvuS;
        YMSLwejrqmvuS /= YMSLwejrqmvuS;
        BlnjnJOoYBk = BlnjnJOoYBk;
        YMSLwejrqmvuS *= YMSLwejrqmvuS;
        BlnjnJOoYBk *= YMSLwejrqmvuS;
    }

    return BlnjnJOoYBk;
}

YdWRakA::YdWRakA()
{
    this->tIjQfxA(false, string("AUImwgMpNPVbQByzgbyvkWKqYTTBTbsHQcuChfnRCZdALTCRZSFbENvjsimXvicnGK"));
    this->CTYBmPbr(string("PuKneFqjpjGiTdalOIZWnaMfZIMEZFLOqXmhDLsAWRISahIEVzuwuKAgsigLnsoykhmzAElEJl"), string("VHQkSOtSO"));
    this->EfuOsWocsqehf(string("OhXpkJmHKoIraPNJjcrXFjkaUznYBkHQOjbNwRFDoVEkJsVCvIxFMprDNOYvakFwGkuPEGaCPAMCnEtLtthjRvNlJOBnrFpOiwRjzCbofBpTbXKyGBpbhEHIyxJVjryNtAMuLwyjswOOyOObQdcSawhHpUqHgpmiLdjPacdqzhusDWztMuAErXFEwOMTGxAnrByVklCDHHZsqhgEWotZHLoZnhWgsXaYPJOXK"), -2030329326, string("HamrmTEttHEldSGGKpLKvKeKvRDMWzFTkDVHJbzoXTuqQxpsINQzjbagEICuIExjKsMjFdjHPhIafdpgmbtGMuofZeCaeLBHGRFfSpvTthPuyPmQCTChJdtLYrUvyfhoivLNqDYTIMQLxXAdQjhIrZCViVzQzMOrETxBHEdPjkPhZYPytFsHPXOwgOCtWzDjRkMecMfBrukfGFNmtBCjPmXs"));
    this->wTFNopJsUX(string("NbmGjfGMGZsIOWDaDtATUnxqqRqGfGcSjMQtoOzUcrouegHfPgTmGbbXAJCyKsDcPBWyttXnHWGKZeMmeSTvDjeuQmKJuqYCmcqcVAqYTduYXnmJDzcXOxXdWNcHCCepfnaYBJoAMRxEJMFJzaFsZSoezyPQjhUIfOlGkHXpvdjBEfrvCxTBPvqrkhvzZeXQLvnijyfQBbnDiAcHfbLkghfMiUsLvCpVlkvseSgHVxwHXVXpznhqEmgaxN"));
    this->FWGpDbeMCEN(true, -685740214, false, 333968.6430922802, false);
    this->HdNpDkyFqcdbNCv();
    this->XfBKnuHa(string("MKajqpjAJBJ"));
    this->ugyqJaGhXwDa();
    this->snveUrj();
    this->hEOdb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OqZEqs
{
public:
    bool roFpKarkIpmJmPM;
    string vvGkA;

    OqZEqs();
    string ElSIBKkrPdJnZSc(double GRiuMpU, int ehlSyN, bool eKHuiLHWlZfRQd, bool FQVdsDrwVaB, bool vimejiTKXFlKrZi);
    string nlzzdX(int evMbA, double SslQBJtvGGcVqcqK, string yxUVLnvlsRMmiu);
    bool EZsMAKRIiP(int afSxNdGddbPtnDLb, string mwZSASJTkHPVcoqg, string bRqKWqFJp, int KIEkEYuLQ, string atwGEZycFU);
protected:
    bool SfKUwhUN;
    bool dJYBBpqUoiP;
    string wZLIwyNFGYOnmArS;
    bool uhxzNrQVazPv;
    string npwaDrZxk;

    bool ewoHHhH(int jYPObgOPNONNzJbZ, string RxduVfdyteezLRwH, bool TxgLu);
    double rICGQC(double NPXZIUwOTe, double oNuIo, bool cBqrMLcXYchqo);
    int HyoDe(int UFWXKnFpfV, int yqiQe, int zzVXBZuAvggpjyMf, string sJYxcipUoVfIh);
    void fhwxXqCWXyjf(int wDqaQjMeSQftU, string ZKReBsIe, double XwTlzB, bool gZfqtuM, string TrvypDTunEdbkacq);
    bool FRAIZUsrtae(bool zVpEtcFvvynUpiWC, double CHTcrRwidAFEEhR, int tCmwNzKHdIcf, bool ukJkT, double ldqygoIWxorOWz);
private:
    string iNVXQpfawSyHCs;
    double zNZlT;
    bool RQLnViWguHA;
    int lWTCfyOhnhy;
    double rjHEyNmlJ;

    void QMRHe(double bPzQdyYPMDR, double LkglWjOpeSnt, int FZjJZbY, string ZrtDg, string quIwTXeYqbDtcROq);
    bool UcfTEuvKZaGXo(bool oDpwrBSCNmn, double rETQDGF, string VmTkT);
    int RzYMo(bool zYfhhqPlesSMS, double yFPPPAcalb, int qMLaJJx, string zzEnRBlrABNUx, string rcRASN);
    void nHQxoOcIstASRWJ(bool dTiKlKtPoznWEEaG);
    double sZwlMsohnmjNpkIn(string CXKUNaqtet, int wtEjQk, string zGhhkoLvTPCPC, int uUWoeWXe, double rfXhmVr);
};

string OqZEqs::ElSIBKkrPdJnZSc(double GRiuMpU, int ehlSyN, bool eKHuiLHWlZfRQd, bool FQVdsDrwVaB, bool vimejiTKXFlKrZi)
{
    string ZgdwGIyDyW = string("wkaSIAFqXnUWBmNeeltapjYiOyzRyTOUxTDYonTonzBjdPDVXZwSNWtAMSRTPrduNrdEHGHQzfheFCoUheBPJUJzvoXRYnZNHOXOhEBmgKdkfMxYLdGpUezQhEyxEfRpGCeHaeYDQoDbWgGNMcmDHAKvxJgXhFRztsxEUNJLOcVqG");
    bool cSzCkSoxU = false;
    bool NEiaOjylQ = false;
    bool zqPormOxhaJexo = true;
    double ddNQx = -313588.03058495326;
    int EugFbLl = 1126473547;
    string ESMOi = string("sZPVlrmyyOxsQXwNwwDTdrwzavrUQcDJzzpQSYnxitgxUtmRZopsKoYMVkAGGBEmxgJSZgqAGQTYUdsdboTtmbpbRXBhLXNEtmCVnprxqleaakbqlkLBYLJcVDvVLhezFbIwqOXgRnLhlJKKiogRYNVBcUKODjwfAfqEECdCRjzqQHVzXCWbnpgUbkAnfc");
    bool rYTUQwx = true;

    for (int vnsIvUMRUJBmIn = 1985789219; vnsIvUMRUJBmIn > 0; vnsIvUMRUJBmIn--) {
        zqPormOxhaJexo = ! eKHuiLHWlZfRQd;
        rYTUQwx = vimejiTKXFlKrZi;
        cSzCkSoxU = NEiaOjylQ;
    }

    return ESMOi;
}

string OqZEqs::nlzzdX(int evMbA, double SslQBJtvGGcVqcqK, string yxUVLnvlsRMmiu)
{
    bool OFXflLRDviUJwL = true;
    double DyqFNwBXXQLKD = -447553.8145379267;
    string ahdShdhmJdfxO = string("bkKDMklVuuESAztVVSbRCDplNxXVlOAHFkCMyppkPxmnDijiIAwwBUdMGYuJVETZqgcixGm");
    string dvqMJaCwuHiHGz = string("lyUlybTHnQrfbueqUpVpsCKWHWzNVnQViBMYbqCjCgISvZvwcSkKPZBfmkqlnnohnqSnduWixfyiTgItaMqJLRscHRgWllfElP");
    string XejhgbpjLMJZVJ = string("WbfTZnrheVEegHHAyINGSkDPIevxNvaeCmvnMGuvEZqBboWIQLISJEdyghngIdxzjcrRsnMCHFuARCUIuKrBtLjVzJUzVtMUBoFKxSdhpGjyigBbaIFFOSBdiSsUMfyXJkZURefIBrMnoNmzwsQkmkDmWUggqdPUhACnMjj");
    int ahycxNtBlj = -769456905;
    int mtLKgGkxvIEYaTXn = -943568419;
    bool oQImUwQTrthbIyb = false;

    if (DyqFNwBXXQLKD > 952550.8989331401) {
        for (int iXCptzRatmtSljF = 652612902; iXCptzRatmtSljF > 0; iXCptzRatmtSljF--) {
            ahdShdhmJdfxO = dvqMJaCwuHiHGz;
        }
    }

    for (int RbPsP = 938489563; RbPsP > 0; RbPsP--) {
        continue;
    }

    for (int QFEpjC = 1177777951; QFEpjC > 0; QFEpjC--) {
        ahdShdhmJdfxO += ahdShdhmJdfxO;
    }

    return XejhgbpjLMJZVJ;
}

bool OqZEqs::EZsMAKRIiP(int afSxNdGddbPtnDLb, string mwZSASJTkHPVcoqg, string bRqKWqFJp, int KIEkEYuLQ, string atwGEZycFU)
{
    bool FusWDBNxMNlZbAEQ = false;
    bool iMhZOdbTxRFv = true;
    string ZFXIAvOL = string("wQODYbDXUbeSjDKvWszq");
    string OGKmrZTfJCmFcw = string("TgKbCYoWjhgZvtyBRSGbnWssPinLFMBgWjdbXEJCFDRCV");
    double cKhSRkO = -228937.8742105444;
    string eaKlUpWFkkdmGC = string("FAKBPfXAMITgtiTqPhuJhEsOAgEUZVeAVEqMuCGebBJDEzuLqxKultuzudic");
    bool WwgqTc = false;
    string qnlhHkUMdEhXV = string("nXgRVPYtegAthzNpDMMCLtsrhjXMGzWMFRbEsZLQkEyCtQPVNDiMjXmHSePGsCbyTjwktoGITUNmgAkmFwOTKJDfSzpjFQKaUISboQcpwujPnhYDl");

    if (eaKlUpWFkkdmGC != string("nXgRVPYtegAthzNpDMMCLtsrhjXMGzWMFRbEsZLQkEyCtQPVNDiMjXmHSePGsCbyTjwktoGITUNmgAkmFwOTKJDfSzpjFQKaUISboQcpwujPnhYDl")) {
        for (int FnxtQfUdQ = 1102071568; FnxtQfUdQ > 0; FnxtQfUdQ--) {
            bRqKWqFJp = eaKlUpWFkkdmGC;
            bRqKWqFJp += qnlhHkUMdEhXV;
        }
    }

    if (bRqKWqFJp == string("wQODYbDXUbeSjDKvWszq")) {
        for (int dSUkDBRDAtyVAV = 697833819; dSUkDBRDAtyVAV > 0; dSUkDBRDAtyVAV--) {
            qnlhHkUMdEhXV += bRqKWqFJp;
            eaKlUpWFkkdmGC = bRqKWqFJp;
        }
    }

    for (int kqPgReUQlxl = 71885661; kqPgReUQlxl > 0; kqPgReUQlxl--) {
        continue;
    }

    for (int CHwdNnBWQ = 1189172564; CHwdNnBWQ > 0; CHwdNnBWQ--) {
        OGKmrZTfJCmFcw = OGKmrZTfJCmFcw;
    }

    if (atwGEZycFU > string("TgKbCYoWjhgZvtyBRSGbnWssPinLFMBgWjdbXEJCFDRCV")) {
        for (int XvhWeVUpWp = 1355686000; XvhWeVUpWp > 0; XvhWeVUpWp--) {
            mwZSASJTkHPVcoqg = OGKmrZTfJCmFcw;
            eaKlUpWFkkdmGC += OGKmrZTfJCmFcw;
            OGKmrZTfJCmFcw += bRqKWqFJp;
            qnlhHkUMdEhXV += mwZSASJTkHPVcoqg;
        }
    }

    for (int zljVDHgqhaeX = 249013081; zljVDHgqhaeX > 0; zljVDHgqhaeX--) {
        continue;
    }

    for (int gdnZKBkGF = 521708350; gdnZKBkGF > 0; gdnZKBkGF--) {
        KIEkEYuLQ += KIEkEYuLQ;
        atwGEZycFU += ZFXIAvOL;
        qnlhHkUMdEhXV += atwGEZycFU;
    }

    return WwgqTc;
}

bool OqZEqs::ewoHHhH(int jYPObgOPNONNzJbZ, string RxduVfdyteezLRwH, bool TxgLu)
{
    string jvceRqaJbMwCE = string("ydVxNOVBPgKpYkZslyMrDRWpnkdWYDAPfpTzrhcd");
    double gFhoPeFXMpvVtwQ = -568501.0533474901;
    bool rcPpTfGqGHUq = false;
    string GIuRLZmrM = string("BTUKQPfyDIObuKHikgRCpjawirzNecODzIpgNlxSKilJnwHfVSOjQYLDIWXHcpiRaMhJIvzMlCOXXWnqLftjVOIZKuFhTOafxhzKFGSLFeYNYMptdJwMjcmNvsCRckeGA");
    double XRuGzBIhRhSKSsr = 209195.68888158962;
    double oXnrUamzqxoVrt = -516851.85807443334;
    double cxYYovdFVvUuqozP = -706666.3546667353;

    for (int PSFRUhi = 1688253707; PSFRUhi > 0; PSFRUhi--) {
        gFhoPeFXMpvVtwQ += cxYYovdFVvUuqozP;
        oXnrUamzqxoVrt /= cxYYovdFVvUuqozP;
        RxduVfdyteezLRwH += RxduVfdyteezLRwH;
    }

    for (int mSRNtBghKplZ = 699022677; mSRNtBghKplZ > 0; mSRNtBghKplZ--) {
        GIuRLZmrM = RxduVfdyteezLRwH;
    }

    for (int GuNdeRDdMLqWXVL = 1473396980; GuNdeRDdMLqWXVL > 0; GuNdeRDdMLqWXVL--) {
        XRuGzBIhRhSKSsr *= oXnrUamzqxoVrt;
        TxgLu = ! rcPpTfGqGHUq;
        jYPObgOPNONNzJbZ -= jYPObgOPNONNzJbZ;
    }

    if (GIuRLZmrM >= string("BTUKQPfyDIObuKHikgRCpjawirzNecODzIpgNlxSKilJnwHfVSOjQYLDIWXHcpiRaMhJIvzMlCOXXWnqLftjVOIZKuFhTOafxhzKFGSLFeYNYMptdJwMjcmNvsCRckeGA")) {
        for (int RXcqnjmksjyyMkVQ = 1401862315; RXcqnjmksjyyMkVQ > 0; RXcqnjmksjyyMkVQ--) {
            GIuRLZmrM += RxduVfdyteezLRwH;
            GIuRLZmrM = jvceRqaJbMwCE;
            rcPpTfGqGHUq = TxgLu;
            GIuRLZmrM += GIuRLZmrM;
        }
    }

    for (int fdlBO = 518655862; fdlBO > 0; fdlBO--) {
        jvceRqaJbMwCE += RxduVfdyteezLRwH;
    }

    return rcPpTfGqGHUq;
}

double OqZEqs::rICGQC(double NPXZIUwOTe, double oNuIo, bool cBqrMLcXYchqo)
{
    int ArICdVPXPMPpnl = 1619616092;
    int LtzDfCqlNXAp = 550033771;
    string VVQiGi = string("ArimN");
    string RbXSVxxCTtggP = string("sjLGJZv");
    bool XhgcBdFEZ = false;
    double kPueUpy = -731558.208341415;
    string hOwBtTQWB = string("vqSBkQWGQmOaCyifpLVkJkHeyuvBebxmbhMBomJKJzxykSiSgjrGIDmvodMFGrhYfNaUwFmRlwouwbebaxVpqoAjXAgdMHBBgTYvWAVxxBRTbNDSemMHEUUtzCROQhLEZknWoMffKkGkhGZjeeuXfVfgoQhmvnlZbr");
    bool DcDRavTsjuAVp = false;
    string BBqDIbRSYIXCXkji = string("GWiJClWYAIVEMVSstMAlKUDTDtNMOylHrkESOxJgZQQjvhNQEbTgnWKyxQaKvdzqzJVuQfmDLYGqGbseFMFQgpGbiRvpsxWAWItEDhnqlqAtdkWJLcMlyjgmHQbwmtLTZLUrmHlKwCSRWjUGnVAwpRbpVMzZWkUNqDmGXINKuqfNoCKcLsEQznesyUHnzDRacdYQXVYo");
    string GcMUMSIY = string("zHAnmsCWgXwnPNSbMddsvTjzQVICAVGqPeKihiNvwQdZgXxMVdrFlvHtcYcLYYlKkSPSVWZiuTPsZhWgkaKaaTWtsFUuocEvFCvHJBzKeCaUafgfYGruLDYqfSTGwCiZHijAYUziqWkWpLnNeyXYIvgJmoFuYTuEfqKAhnnBAONNGbaFxBoRXozlPGLszXylddYNLIWZxYjBAHatOtMvr");

    for (int iSjlYjnzEtatQxo = 1973184396; iSjlYjnzEtatQxo > 0; iSjlYjnzEtatQxo--) {
        VVQiGi = RbXSVxxCTtggP;
    }

    for (int DsqjAJI = 1250756091; DsqjAJI > 0; DsqjAJI--) {
        oNuIo = NPXZIUwOTe;
    }

    if (hOwBtTQWB >= string("ArimN")) {
        for (int LunDAszxKBUjK = 132461403; LunDAszxKBUjK > 0; LunDAszxKBUjK--) {
            oNuIo -= oNuIo;
        }
    }

    return kPueUpy;
}

int OqZEqs::HyoDe(int UFWXKnFpfV, int yqiQe, int zzVXBZuAvggpjyMf, string sJYxcipUoVfIh)
{
    int jpZUrVbrttlDbnii = 132073912;
    bool gNvFZqymG = true;
    double pDNIuKeiZ = -364975.192728902;
    double uPfhLUErQMQ = 480730.6256126747;
    int dbDvhEaNsYhQn = 232609267;
    int rLsRHeZocWymYh = 273600662;
    double TGaGCbHfWXiVl = 140513.82036710804;
    int QbkWOETlOM = 34221931;
    bool pieoJIvuxPMGlzP = false;
    string yFWoFtjPAVBQq = string("mRkcluoHukNMJAHqpxVlySihDRqTvEdawTtR");

    return QbkWOETlOM;
}

void OqZEqs::fhwxXqCWXyjf(int wDqaQjMeSQftU, string ZKReBsIe, double XwTlzB, bool gZfqtuM, string TrvypDTunEdbkacq)
{
    bool MUiHqF = true;
    int qjMOgCS = -2093042071;
    string jcsenefhR = string("tSdxKCDxvWozaDGLtEcajSxpnjMGKuRDdHAhssGTFNNrsHtEGlyqemIZXXlPRVBUqWmGfL");
    bool AQfuFaxgH = false;
    double HOwcInyYYy = 695410.8999743643;
    string jkIoRucoxlr = string("IjvzQmhdTeJl");
    int HwumZPegCpKx = -2036363813;
    bool bWLApbhcqFvpk = false;
    string MuPSTtpvPULLymi = string("piiaECntmaQoKIhqmdCLfuNfGlYivTnwPtvSEJYgcinbdwhsG");
    string eTUHRWEHiyzNu = string("cNLxupCTaHBiwNnoaMClVIXFULYwQYGNaBnfbJoKPHKOkISntEpDMMBSvNpyeaScUwunposfzjterloVessWEdTYbsfFhRqnMzVChhBnIquJXQIbMBuXhqrsbBVjwuqgJgPKGhgZlFXZUHatOBXdzZuKrXqZhiHKbzaNAsQhAzLhGeIixFaFWrKKXgbkcKUUjvSaFWukOBpiTGhySOBlmEPyBhvNITaXZcfNouXhockE");

    if (AQfuFaxgH != false) {
        for (int jBCyOlZ = 642255949; jBCyOlZ > 0; jBCyOlZ--) {
            qjMOgCS += qjMOgCS;
            MUiHqF = AQfuFaxgH;
            XwTlzB -= HOwcInyYYy;
            TrvypDTunEdbkacq += jcsenefhR;
            jcsenefhR = MuPSTtpvPULLymi;
        }
    }
}

bool OqZEqs::FRAIZUsrtae(bool zVpEtcFvvynUpiWC, double CHTcrRwidAFEEhR, int tCmwNzKHdIcf, bool ukJkT, double ldqygoIWxorOWz)
{
    string RCtLFd = string("abxxXcPOhaoShnPXsFZAmOqiYyKPyRVqRweWObDxDvpfpHaQdwwTJdLehEwmmAJuWghJyOSoShhcvkPGbsXxTtiMmoboyyFduARRIUKOhTajblTMzFtdQvykRYhqvEOZXwHUXeScgylowxqHmIGpujnhZulSyxceWyxVeqQsS");
    double hkBHITnbEvExl = -1022193.5322951755;
    bool XXaOvlv = true;

    return XXaOvlv;
}

void OqZEqs::QMRHe(double bPzQdyYPMDR, double LkglWjOpeSnt, int FZjJZbY, string ZrtDg, string quIwTXeYqbDtcROq)
{
    double KqWHrsbvhO = -1004107.0383015849;
    int PMmQqkUReRcvcPQp = 1075594983;
    int iqvMISdkvLnpYz = 1898862148;
    int GdDuETkbDMvsO = 1013729807;
    bool HSKveeOmf = true;
    double HpKPloYm = 947490.0290333771;

    for (int pnpIMLLhndTxqYm = 1814143643; pnpIMLLhndTxqYm > 0; pnpIMLLhndTxqYm--) {
        LkglWjOpeSnt += KqWHrsbvhO;
        bPzQdyYPMDR -= LkglWjOpeSnt;
    }

    for (int NcmQH = 1172634567; NcmQH > 0; NcmQH--) {
        continue;
    }

    for (int CJtByQXNFn = 1078033177; CJtByQXNFn > 0; CJtByQXNFn--) {
        HpKPloYm *= HpKPloYm;
        HpKPloYm *= HpKPloYm;
        PMmQqkUReRcvcPQp /= GdDuETkbDMvsO;
    }

    if (FZjJZbY == 1075594983) {
        for (int dCmrpumJLFYGfA = 943992004; dCmrpumJLFYGfA > 0; dCmrpumJLFYGfA--) {
            KqWHrsbvhO = LkglWjOpeSnt;
        }
    }

    for (int EcImxyaVO = 928214639; EcImxyaVO > 0; EcImxyaVO--) {
        continue;
    }

    if (ZrtDg <= string("ErtwpaNlsywqtxSpStaqBPnectnAUDAgEsoWBepJfoGcJsLylaFWllLtWmrAzuISHFMPKs")) {
        for (int fuClwhVTuPXvIqsg = 1069723399; fuClwhVTuPXvIqsg > 0; fuClwhVTuPXvIqsg--) {
            iqvMISdkvLnpYz += GdDuETkbDMvsO;
        }
    }
}

bool OqZEqs::UcfTEuvKZaGXo(bool oDpwrBSCNmn, double rETQDGF, string VmTkT)
{
    bool ahWWoZku = false;
    bool LanNmgYoqio = false;
    bool aVdaPafEbqhvfGq = true;
    bool FNcYwjcTL = true;
    bool HMqnRt = false;

    if (LanNmgYoqio == false) {
        for (int ZHzrNnwDWNBtF = 1380466490; ZHzrNnwDWNBtF > 0; ZHzrNnwDWNBtF--) {
            FNcYwjcTL = LanNmgYoqio;
            ahWWoZku = FNcYwjcTL;
            ahWWoZku = ahWWoZku;
            aVdaPafEbqhvfGq = FNcYwjcTL;
            ahWWoZku = HMqnRt;
            rETQDGF /= rETQDGF;
        }
    }

    for (int PQsfAwxfED = 789670864; PQsfAwxfED > 0; PQsfAwxfED--) {
        LanNmgYoqio = LanNmgYoqio;
        LanNmgYoqio = ! HMqnRt;
        HMqnRt = ! HMqnRt;
        oDpwrBSCNmn = oDpwrBSCNmn;
        ahWWoZku = ! FNcYwjcTL;
        FNcYwjcTL = FNcYwjcTL;
        HMqnRt = oDpwrBSCNmn;
    }

    return HMqnRt;
}

int OqZEqs::RzYMo(bool zYfhhqPlesSMS, double yFPPPAcalb, int qMLaJJx, string zzEnRBlrABNUx, string rcRASN)
{
    int hZxPDxMSO = 1591866370;
    bool hHxDeP = true;
    bool GklZeFfw = false;
    string zAAJcPTdyPeoIV = string("dNAeHQBkEyAHDKtBSrcFBDFHylvomFhXM");
    bool wzeEittInlnjlNIy = true;
    string lgNfahlZJqeVGkfe = string("bVsfBKyibUjUyoxKqbhuluexHjQiwoqghuspgOjiHLtQkqrebgwavBTVSODNYHBxuozVDtoMQGxNkVApgaTcteoiZyJdMpo");
    bool bhQrQPbZTSWLQ = true;
    string xrLJrdTuDyXJiue = string("KJeCCEmdhcnIbyybeoAOdkMNSeeKAfbRvDRpMnXmYPUPESenMfXQsenGzbHfiJbHQWbQpNGwxTpSaVoEtrsoPxwyhAfGMuphvrdypDLUpYef");
    double RokQjhrRyUxIKi = -47923.31628152742;
    double BNyUeGfLrPkaiYiC = 185470.789932735;

    if (zzEnRBlrABNUx != string("dNAeHQBkEyAHDKtBSrcFBDFHylvomFhXM")) {
        for (int cZXWmMCzULKwwMOb = 628061939; cZXWmMCzULKwwMOb > 0; cZXWmMCzULKwwMOb--) {
            zYfhhqPlesSMS = ! hHxDeP;
        }
    }

    for (int objOHZHdFY = 184827088; objOHZHdFY > 0; objOHZHdFY--) {
        continue;
    }

    return hZxPDxMSO;
}

void OqZEqs::nHQxoOcIstASRWJ(bool dTiKlKtPoznWEEaG)
{
    bool nIjqYFjM = false;
    double TLOnTKM = -662613.7362037562;
    bool GWzpOWXjzp = true;

    for (int wVdvhzhQZ = 1379004565; wVdvhzhQZ > 0; wVdvhzhQZ--) {
        dTiKlKtPoznWEEaG = GWzpOWXjzp;
        nIjqYFjM = ! GWzpOWXjzp;
        dTiKlKtPoznWEEaG = ! GWzpOWXjzp;
    }

    if (GWzpOWXjzp != true) {
        for (int ZoqffBhzMrTlBaJM = 2136010171; ZoqffBhzMrTlBaJM > 0; ZoqffBhzMrTlBaJM--) {
            dTiKlKtPoznWEEaG = GWzpOWXjzp;
        }
    }

    for (int UgjYkXeZibxDp = 1171540681; UgjYkXeZibxDp > 0; UgjYkXeZibxDp--) {
        nIjqYFjM = ! GWzpOWXjzp;
        dTiKlKtPoznWEEaG = GWzpOWXjzp;
        nIjqYFjM = dTiKlKtPoznWEEaG;
        GWzpOWXjzp = ! GWzpOWXjzp;
        dTiKlKtPoznWEEaG = ! nIjqYFjM;
    }

    if (GWzpOWXjzp != true) {
        for (int VwaMJZCDIqVdTVhe = 1849403081; VwaMJZCDIqVdTVhe > 0; VwaMJZCDIqVdTVhe--) {
            dTiKlKtPoznWEEaG = dTiKlKtPoznWEEaG;
            GWzpOWXjzp = ! GWzpOWXjzp;
        }
    }
}

double OqZEqs::sZwlMsohnmjNpkIn(string CXKUNaqtet, int wtEjQk, string zGhhkoLvTPCPC, int uUWoeWXe, double rfXhmVr)
{
    string gIPGlbmSUx = string("pCOiEQnnAImvVveMWlYGTbPRldmKMyCcNKNnDomLvyuDuFStzmXihBVrVtubXJqMiDLWunDIeIPqSdOApOJsTfawOQwcmAdihlVksQSRKMuRBILABPqMiJRQoKvNCLiPYSVySOAbLyDGRvSPyMJclFvJJBFhlRALWpwgLLCEnZPHBsEbeYhmIsPMVJDLyCKvoSOyvPkmVfwwGaIzVmBSYrMbpcNXKAb");
    int lOorvDV = 1104880242;

    for (int SEElDaStbvQwLWe = 1941199233; SEElDaStbvQwLWe > 0; SEElDaStbvQwLWe--) {
        continue;
    }

    if (zGhhkoLvTPCPC >= string("pCOiEQnnAImvVveMWlYGTbPRldmKMyCcNKNnDomLvyuDuFStzmXihBVrVtubXJqMiDLWunDIeIPqSdOApOJsTfawOQwcmAdihlVksQSRKMuRBILABPqMiJRQoKvNCLiPYSVySOAbLyDGRvSPyMJclFvJJBFhlRALWpwgLLCEnZPHBsEbeYhmIsPMVJDLyCKvoSOyvPkmVfwwGaIzVmBSYrMbpcNXKAb")) {
        for (int lveAyFOY = 1515320197; lveAyFOY > 0; lveAyFOY--) {
            continue;
        }
    }

    return rfXhmVr;
}

OqZEqs::OqZEqs()
{
    this->ElSIBKkrPdJnZSc(101253.16106550152, -1910055647, true, true, false);
    this->nlzzdX(1028545343, 952550.8989331401, string("vsaPgOYTUKZuzIEuBbPqyrtUaPbylrZxWIvwgnoEBVHwdXSRtswgTPAHApjHWoNDaIWlLaMBJBEhxYVGeYAVYubdCUQpgRXyPkjLkSXkTQwLUuJtSLnJtSCEWawXqTsSOGAUwGnpiKqirhscwnwPrsxqFYyueqmtxyTm"));
    this->EZsMAKRIiP(-1542804279, string("rpYjGEvBaOiQqYshOBaoodMJxoZapVSsCOfcONLSIGluShrYHAPXqdPZkoQczvcCYIdjSAFFJsdgYwPHMfBpPscgnOxlCSItjniuDZzqBXNoOvSrnWwuvGvevhotaAoyocdPNBRHQWuwKDWqNdNMLPYMZrVDEnDOPwkHPAEMcyEFVTdlqTgexQMQXJxbjCcABuRScobyFnRARspgTsjWOCmHsREdkJleLuQOflPFBz"), string("kDxRiYUlpOooxKEOAWiLbPLEQjczjpprSZTskaQTRHfJbySYmEBObflwGPvlQjhSSrGdfaXIYULwQQbOpbOAZyHAYjxTrspgnFCwHCpGnubsSjYinOUmAVRSdFTmQRmRAbsIGlgcWSJkUCXXofTNtUGyqAIAonFmUkyojSUEzxywNUulapzDmZpmlTsKwToWClAlrXsDOzKtNcEI"), 1311274365, string("fZWutPxBQDjXtVLyPWxhNBtSvelVxhonHHYqpcIjmENhVhoCsktoELABphTAzNdfqYkQTrbLYKQnThDxGtgZnlcuZMKxLzJYgmJJrZ"));
    this->ewoHHhH(-956015308, string("WpCbvglizlkYiBfjYCeImPAlZZSYiTlsBFMCwjuCCfcxjlUNBKSdkimtHaBVqUdULnMJbXOKEMbVzdqjWEnuuKHNfVlzcinqhNROxlWLdwTrEFpafuqdzhUgmAAAABVPdyAEfKFZmiqEsdErKsTDdSqdINyqjBuHYdKniHupZwYaiKTuHgKYcekGbsdWSfTHMWXllDducFnMEBk"), false);
    this->rICGQC(23154.657665371516, 232534.7188400412, false);
    this->HyoDe(-1751130168, -1893194961, -1630713787, string("QzMl"));
    this->fhwxXqCWXyjf(-31473285, string("sEzUWszhcjJWiHSQsYkFRuaAGTPNqfAIKHMJzlkTFNZOvaxcMJkLNgvrLtChzaoDYdSrBiqLCEByVFqwiUjgoue"), 606042.7849002794, false, string("kPkGMFskiPssUTzItiMDthufXpYjnpjotgVysCzhGHzRdgxoDcgPCGudiYCroviOFVTeRnmZCeotBytae"));
    this->FRAIZUsrtae(false, 399441.82604838064, 2078977192, true, 269626.7540291202);
    this->QMRHe(179897.7380054133, 277942.51546261815, 610038322, string("ErtwpaNlsywqtxSpStaqBPnectnAUDAgEsoWBepJfoGcJsLylaFWllLtWmrAzuISHFMPKs"), string("MCGOcXrbRrQdldrVXliVpxbNqcBZHuNwwfiUHQsqSnOUFoocCavmUgogcuqNtnRRYWeLQHfCwbUQXTLSLbZPTfjIyDTyIuuBBnqfFbHGyGvPWZkQRZdvCSZHjdayuNjxiRELCz"));
    this->UcfTEuvKZaGXo(true, 92514.22236145975, string("SiEraTJEmaUJwEaUAbMPgVnrYM"));
    this->RzYMo(false, -958063.2879551342, -1092627005, string("XEegtfbAQiSCTQcxmjOkiKYqnljsnrZwJeogDIbeyHgNfJkAdlJjJwNdWjtLlVPFHDkbTqtrWlsdJYwebdWHjQaiqcwvsGREFJWjROilNeOklZQpFcslPzRlcrAOVckoNNBHOPPQAmFLhhJjJErTzPnEzWfZdrQhYQkfbZEOOPhJdcGuRfeXtlPKOPyDGvvUvupIlGMssRMpfpDKQlDZt"), string("PXHJdVcElrepgyOaMvJVujVinNdIwqCGUMrWGmQUizalxovvTiAUgyNOQiXqEdCGSUTDuCykCJCtLVQXThYmJFUJbQfUtpQQiJAcsDDtyzDBrMqERQnZZNocLilTaCztroyGIrjqaFiBkfAQyXbFrmjbMdjfumIztfUApnLsQEcpRxxRbrySoC"));
    this->nHQxoOcIstASRWJ(false);
    this->sZwlMsohnmjNpkIn(string("GFaSBuXovfpgARckCQGNieMNOBqsWfLopkqzRtEtBHvHQxFLCVKiKqcwFvJIzgOuQYNrAbyjXZKPOYJpTSQvbsLVsKgQiyAJWMDRUYKUhiBBxrrSdKjrowoAvgbBnofRRcPpYKoaSqQtvJovWCeYsABfdTnTUTXoHnkWCoXyRXLAalEUJVfGKLNanlExPjHy"), 604812348, string("KdgNpSsHaeFOTnnXShDNeaCWMFqGPiFNneNSrYisbiYWZNdIlAmzUWByMHwGqeoLZHiMcXWIBKVNAfwbLgFGdeqRZMtkxuBBptkaslFtezxLvBcPXaiGWWlnxUXISSLWjgNIlrCtosHXFigtVnjvUybkAwPesbufgZlyOheRCQAC"), -1122375219, -289000.560353288);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lgDWyUJTovUmPaW
{
public:
    int OuUbW;
    double cDxxkNGAvNJQslxT;
    double lehiLYWuCwpocw;
    double eXQMJnzT;

    lgDWyUJTovUmPaW();
    void GdKfWsTnDWiMccwc();
protected:
    int MQcIGOnRNq;
    bool pllHaXfZbz;
    bool hAXIZMISssY;
    string BeFcrLPntfb;
    int aFbkEYNsMzt;
    int GTahejtDObY;

    bool NLAhBDTFmK(string XPjDPK, double blFuKKaEEdgGc, int bhPAZXpFfkPRzE, bool ohKLrJWLWXkHZ);
private:
    bool iLgjPEBtPS;
    int phcPArB;

    string xhVVTwjFgu(bool BjKvBqjKVYC, double kdJcXmhL, string UEKBWWvaWELOd, bool EAdVOqdP);
};

void lgDWyUJTovUmPaW::GdKfWsTnDWiMccwc()
{
    int GNpWTeFG = 594635046;
    double ivuhCLgvU = 33240.997173251286;
    int ineObqbJEcDWKBR = 1867997834;
    double wQKnTUKyXfXflv = -634179.6448072033;
    double bauyCyV = 670743.2814948777;

    if (wQKnTUKyXfXflv != 670743.2814948777) {
        for (int yZoltUsTJ = 273255976; yZoltUsTJ > 0; yZoltUsTJ--) {
            wQKnTUKyXfXflv *= bauyCyV;
            GNpWTeFG = ineObqbJEcDWKBR;
            GNpWTeFG -= ineObqbJEcDWKBR;
        }
    }

    if (GNpWTeFG <= 594635046) {
        for (int ipsfidYXbMCQgZli = 1154741591; ipsfidYXbMCQgZli > 0; ipsfidYXbMCQgZli--) {
            bauyCyV *= ivuhCLgvU;
        }
    }
}

bool lgDWyUJTovUmPaW::NLAhBDTFmK(string XPjDPK, double blFuKKaEEdgGc, int bhPAZXpFfkPRzE, bool ohKLrJWLWXkHZ)
{
    bool tYmnxKnezH = false;
    int RdbQvuuaWEIs = 1509422372;
    int HJLOEgpEjSfX = 554250057;
    string uUSIVA = string("bVomreFRfUibLeFcPQlXzHOLlycdiC");
    int vKauD = 648558763;
    int UkyxySOBwibdxN = -557181980;
    string FMYsXp = string("ucznhxczeqEZujScFLBtfSpaNmVXKYVHBbimwUsmyeeFQyWNxjkRkeaMKwvxnodmDjNDPTszDlWgbKHGfbDNIkgCNpCHEqBrtpcuVxhnOWQwfanHrwgnnAaqgqsgIITVOEvvZcRqGWKeVknbhPXzFyHCXjPqVWmuzShvKgsiNyhOcLxpsqwuwgfntaIAkf");
    int PClBA = -186279557;

    for (int bnfxOiqfUqMx = 1290720746; bnfxOiqfUqMx > 0; bnfxOiqfUqMx--) {
        continue;
    }

    for (int iBnivBWsO = 711495007; iBnivBWsO > 0; iBnivBWsO--) {
        bhPAZXpFfkPRzE += UkyxySOBwibdxN;
        PClBA *= vKauD;
    }

    for (int MIedOXsk = 2040541443; MIedOXsk > 0; MIedOXsk--) {
        bhPAZXpFfkPRzE /= PClBA;
        tYmnxKnezH = ohKLrJWLWXkHZ;
        bhPAZXpFfkPRzE -= PClBA;
    }

    return tYmnxKnezH;
}

string lgDWyUJTovUmPaW::xhVVTwjFgu(bool BjKvBqjKVYC, double kdJcXmhL, string UEKBWWvaWELOd, bool EAdVOqdP)
{
    bool viKtQXdlp = true;
    string xZAxorBC = string("MBUCbeDCNpTUOPYDSyGOGDMBdOQnBtwsEeOerCMJzlEZrcXaAgyettLndGaZgeEkxPvLZFtCbPZpvdSLvXgIBysAUnoSzhcgICoITDiQwIPpqGNHQwmkcsBPXIEYpKZIllBKphUluuNDdhRJQvfadSYqRlCUWpWNVjwECxVatRCRDDMPSLcwrUnSMIDhdWQUkXYITJRLQKYOTalmhhkgMBLXNrulxRcqWzxgmERWWmeoaVqNkJrbqvlHknDGBz");
    bool lZLjY = false;
    string nkSQrhJQJCJMehH = string("fJJtORyBwZIy");
    bool LgknEuH = false;
    int OuDVExAxTe = -1390800126;
    bool peTNN = true;
    double KmilXcaX = -73475.12280345555;
    bool eYRcejPVwv = true;
    string PTzQrN = string("UHvIGOfYKbPboWGopmQOrGshhQcyskohtectZPBKAZFAeBfmOGBsBulzTEVfJluAaQsFjHAUuXOGOGtPNcGsMHtBPHeWzOWZgODqKXlEbBzYewzWAmwaloeatbANPLslPqnkCRlwjyFmUJUutXPjUkmMZipZLanLNGTeuIQManlGhLyqEiaexOa");

    if (LgknEuH != true) {
        for (int ibZSNsLzID = 1656505604; ibZSNsLzID > 0; ibZSNsLzID--) {
            eYRcejPVwv = EAdVOqdP;
        }
    }

    for (int yllIDkPRqa = 76601052; yllIDkPRqa > 0; yllIDkPRqa--) {
        continue;
    }

    if (LgknEuH != false) {
        for (int JxTMSRpWHoDy = 329580718; JxTMSRpWHoDy > 0; JxTMSRpWHoDy--) {
            continue;
        }
    }

    for (int qnlNIGXvE = 987251532; qnlNIGXvE > 0; qnlNIGXvE--) {
        LgknEuH = ! lZLjY;
        LgknEuH = BjKvBqjKVYC;
        viKtQXdlp = ! peTNN;
    }

    return PTzQrN;
}

lgDWyUJTovUmPaW::lgDWyUJTovUmPaW()
{
    this->GdKfWsTnDWiMccwc();
    this->NLAhBDTFmK(string("cLCgvMdbUqqHcfLxQCcdTLzcyGNymRCqEZhIuRPoRnntwMo"), -425294.46973379137, -659383838, false);
    this->xhVVTwjFgu(true, -575741.121757383, string("BNAbvkZHYmtUJRSZFImUAiBzNoFNSoXVrvRqIILxjnlzBJKNGDcDQmpJHDP"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nITIgtwNtcmV
{
public:
    string BRuHeTzBxPw;
    string FxzhPqZNOrzutaBV;
    int NJeezXAFAObul;

    nITIgtwNtcmV();
    bool BvSYarFRF(double pYaMlxxgxWXzsAHz, string gpmDNi);
    void rUPLsnK(int CqmTgJR, double tgRiUOL, double rRdXvrkZqfvRZ, double iuDzPuhn, bool hIZBa);
    bool GwukT(double UHEblIPjTvIs, bool IglIMlYyVTpq, bool TWcTldmisQC, bool FxSfuOgeKXQZLKt, bool RVucEjFur);
    bool zlGCYiIYsoisvAlN(int nVkvc);
    bool IxbqMCV(int ooyeKKNogZelEI, bool MZfTGj, string BvgFhMjunIj);
    void IrLvuToiAsOsOtQ();
    string BIkmuzdH();
    void oYlrmkXGqz();
protected:
    string GhvzYOAjlxRkH;

    string PBMOIvkoCXcg(int jsxGmBKHb);
    int FDbVLMbaYUvFwrvs(bool sNphS, string KCicSeHZUMnemA, double KOxngkpANm);
    void XKfKfBg(string zqGlvEuJZv, int kKTqo);
private:
    bool mWTNHHNkvo;
    bool LQTPmdtmPisCx;
    int jdLZpMdga;
    double LKTzaNHeSSJdgEPm;
    double NoAUXJHNMSxXDNFW;
    int pHCTrf;

    bool HxONTCgJcJWLjZN(double AFDihQgUlzWq, int ehacg, double rDyicNTCybg);
    string JhTIGOdoc(bool bnfLgPhSW);
    string ArHGEnhRte(double EXbjQZFCiEYyx);
    bool IqHQeNtyx();
    double hcRsSTNlbucYzV(bool lNMOTxi, int KFJLpfYGdB);
    void eSkHMvdLInBn(string vdIXwVBESpdfbevP, double dhsoW, bool tIGPwmSci, bool jemMS, double IbzNm);
    int affagjvwFXrAPPkL(string gMGCkzozB, int XseQHkSKJU, string bQFFKFMRYPFyEx, bool TNwqObDk);
    void gkjVovMpDrwuXm(double avJkHiCRKg, string BLrEkkVgzVK);
};

bool nITIgtwNtcmV::BvSYarFRF(double pYaMlxxgxWXzsAHz, string gpmDNi)
{
    string llOcDigrloRsvl = string("wpDFDvNsOPCcNMtCEIuqckjLVjVrFthsjixynnzrULKKjTxCphEtWoahpNxtbXHufnndOvaPuiyJQwfUlgxuchZjSSvgbmSiarztMdOnScPhNXziaCiJJMBszxnWnYeiBiubLDzMZTPzxyPsporlVHyXdvcXRxchFHsLeQyhxJWoKrByHfRg");
    double PmbENoyPZFpXiXo = -942284.7939402853;
    double mbhFcJPl = 465507.5918845313;

    if (mbhFcJPl != -783761.820101472) {
        for (int PnLkQnHCzaGO = 88739292; PnLkQnHCzaGO > 0; PnLkQnHCzaGO--) {
            PmbENoyPZFpXiXo = mbhFcJPl;
            gpmDNi += llOcDigrloRsvl;
        }
    }

    for (int LiFNtgsoFBvRz = 2085533022; LiFNtgsoFBvRz > 0; LiFNtgsoFBvRz--) {
        pYaMlxxgxWXzsAHz += mbhFcJPl;
        llOcDigrloRsvl = llOcDigrloRsvl;
        mbhFcJPl -= mbhFcJPl;
    }

    if (mbhFcJPl <= -783761.820101472) {
        for (int xoRBhxecc = 1856103030; xoRBhxecc > 0; xoRBhxecc--) {
            gpmDNi = llOcDigrloRsvl;
            PmbENoyPZFpXiXo *= PmbENoyPZFpXiXo;
            mbhFcJPl = mbhFcJPl;
        }
    }

    if (PmbENoyPZFpXiXo >= -783761.820101472) {
        for (int TiWCHjWDIeq = 571950774; TiWCHjWDIeq > 0; TiWCHjWDIeq--) {
            mbhFcJPl -= PmbENoyPZFpXiXo;
            PmbENoyPZFpXiXo *= pYaMlxxgxWXzsAHz;
            PmbENoyPZFpXiXo += mbhFcJPl;
        }
    }

    return true;
}

void nITIgtwNtcmV::rUPLsnK(int CqmTgJR, double tgRiUOL, double rRdXvrkZqfvRZ, double iuDzPuhn, bool hIZBa)
{
    int fxaAnglNdu = 176148183;
    bool DPzuZ = true;
    double BdPSxw = 960270.7231392214;
    bool lGsDEC = true;
    double NQQtsDyCQMUmriA = -158405.33023760575;
    bool NgaRKooiXrS = false;
    bool sOzPnCbsWW = true;
    double JYEOfsq = 884423.4389818778;
    string TXggKS = string("EhDDaEpIVHlALaSleRaTmlEYPSbyrmhbTiJuWXhatqasmOrdzcblxepDjduxNfNzhXEYnifhqiRVIUJtjHJCooOiceJHjkBOMJXVfAqGrGNjmrluGbPhbFNAG");
    double fAjjwKgHTzVCyPR = 719080.9061434307;

    for (int FbBnlp = 570681599; FbBnlp > 0; FbBnlp--) {
        NgaRKooiXrS = ! lGsDEC;
        iuDzPuhn /= fAjjwKgHTzVCyPR;
    }
}

bool nITIgtwNtcmV::GwukT(double UHEblIPjTvIs, bool IglIMlYyVTpq, bool TWcTldmisQC, bool FxSfuOgeKXQZLKt, bool RVucEjFur)
{
    bool JThvEGrZBvT = true;
    double WiWwF = -483299.8871763336;
    int hfMGu = 970165282;
    int NIldJpFrvftalPvg = -1125959153;
    string STnAewioh = string("bGYIRihiDqWPjJKqnUZHHGiMgsblCahISbzWEGhFlQFNkmOAyUvrXXVdovXkyLiCLzTlorKPXfyHQTWNiarpKsJhmTtyFnXdDcREyqO");

    return JThvEGrZBvT;
}

bool nITIgtwNtcmV::zlGCYiIYsoisvAlN(int nVkvc)
{
    bool pZbFqECEDMmcgf = false;
    int OZCVpv = -392135780;
    int eAoFXouBfiXuB = -1375970993;
    double qcvWBgdetS = 45741.99048908042;
    int LTueejLfO = 1634350977;
    double wftKoj = -895848.1683090193;
    double cFVQMphyMPr = 995093.8217041158;
    int vKMITCkxRvdweRG = -1314633369;

    if (OZCVpv > -392135780) {
        for (int cSWRbjYrnmh = 1945914344; cSWRbjYrnmh > 0; cSWRbjYrnmh--) {
            wftKoj *= wftKoj;
            vKMITCkxRvdweRG = nVkvc;
            LTueejLfO = LTueejLfO;
            wftKoj -= wftKoj;
        }
    }

    for (int NGWwmw = 164743202; NGWwmw > 0; NGWwmw--) {
        cFVQMphyMPr = wftKoj;
        LTueejLfO += eAoFXouBfiXuB;
    }

    for (int LqlUFKDFdcl = 902755502; LqlUFKDFdcl > 0; LqlUFKDFdcl--) {
        OZCVpv -= OZCVpv;
        vKMITCkxRvdweRG += LTueejLfO;
        wftKoj += qcvWBgdetS;
        wftKoj /= wftKoj;
        OZCVpv *= vKMITCkxRvdweRG;
    }

    if (cFVQMphyMPr == 995093.8217041158) {
        for (int xXYCPnnxlzKHp = 764188927; xXYCPnnxlzKHp > 0; xXYCPnnxlzKHp--) {
            cFVQMphyMPr /= qcvWBgdetS;
            OZCVpv /= OZCVpv;
        }
    }

    return pZbFqECEDMmcgf;
}

bool nITIgtwNtcmV::IxbqMCV(int ooyeKKNogZelEI, bool MZfTGj, string BvgFhMjunIj)
{
    int tfvWpaiDnIqk = 1856472269;
    string okMiH = string("OofqSgQoOgIayaIaWrmxeoHpEKAKAGOocUaJyrtBknfQYOzGufVrkgTvhwosZnrDxlIyNGkYnAZshbrYtVOqYXNqveNnZJUxvedPbwYZYWBonGAsbhbLFkxUEFevZjteiwyoVsGdRPZDhHwiCwraozrpBWxTdKoSTDJKLauybrWQudoLgXqkGgEeFmtONhMLrnKiDXgohawiukZxbZMdeO");
    bool TjnNbkwuNyZCBlC = true;
    int rFwqzFYwVsGtfYKz = 907708781;
    int yNHSheQvZd = -1388290178;

    return TjnNbkwuNyZCBlC;
}

void nITIgtwNtcmV::IrLvuToiAsOsOtQ()
{
    string dJZwYAiUsuFjkW = string("SAyAjJwwEsIVeeHnDWENFuuwtLoSbwMRRVvwoxvJQlgf");

    if (dJZwYAiUsuFjkW >= string("SAyAjJwwEsIVeeHnDWENFuuwtLoSbwMRRVvwoxvJQlgf")) {
        for (int dQhkZMFDeZupEz = 128420027; dQhkZMFDeZupEz > 0; dQhkZMFDeZupEz--) {
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
        }
    }

    if (dJZwYAiUsuFjkW != string("SAyAjJwwEsIVeeHnDWENFuuwtLoSbwMRRVvwoxvJQlgf")) {
        for (int uUUdyhNSvrUrPZ = 768458676; uUUdyhNSvrUrPZ > 0; uUUdyhNSvrUrPZ--) {
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
        }
    }

    if (dJZwYAiUsuFjkW <= string("SAyAjJwwEsIVeeHnDWENFuuwtLoSbwMRRVvwoxvJQlgf")) {
        for (int vryTacHKUK = 1167698197; vryTacHKUK > 0; vryTacHKUK--) {
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW += dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
            dJZwYAiUsuFjkW = dJZwYAiUsuFjkW;
        }
    }
}

string nITIgtwNtcmV::BIkmuzdH()
{
    bool ZDTUBaizH = true;
    double XGxcjfUFLRTQUXO = -72202.27631572167;
    bool UNnFRXuKPoVGq = true;
    int pXAiQFQok = 2084644945;
    double rzcWveku = -832678.7740037628;
    int UrsLzrPMpcUw = -434190308;
    double MxSXGbMYIOLhaaYO = -875448.0836068296;
    int NMAtT = 257340631;
    bool qSWhxJzuzK = true;

    if (UrsLzrPMpcUw < -434190308) {
        for (int JrEXLxzzO = 426697750; JrEXLxzzO > 0; JrEXLxzzO--) {
            continue;
        }
    }

    for (int JnNkGqIUQ = 751321995; JnNkGqIUQ > 0; JnNkGqIUQ--) {
        pXAiQFQok += UrsLzrPMpcUw;
        XGxcjfUFLRTQUXO = rzcWveku;
        rzcWveku /= rzcWveku;
        NMAtT *= pXAiQFQok;
        UrsLzrPMpcUw -= UrsLzrPMpcUw;
    }

    return string("pZWxOkzuexqXoqHnVgNmBdbrrUSkDELSwrHVclEZWrnIZCnsmfTRFIalvHNdKfdGPHfuspbjuBA");
}

void nITIgtwNtcmV::oYlrmkXGqz()
{
    bool ZyoXfJcXmbtci = false;
    int KZLChuRRHIC = 1739659107;
    bool xnxSPLuueityGV = true;
    bool JBqaoENVeYvETPxu = true;
    double lnDhdqbZjRXKy = -1011497.6664692784;
    bool lXImxLxMCjJ = false;
    double WNeQtwc = -944545.4672300384;
    double cZbnonRYzjjQbbX = -803689.8789068128;
    bool ztDDXSr = true;
    int WYvQi = 91585291;

    if (JBqaoENVeYvETPxu != false) {
        for (int YiCXjTaBULWxRK = 1072598138; YiCXjTaBULWxRK > 0; YiCXjTaBULWxRK--) {
            ztDDXSr = JBqaoENVeYvETPxu;
        }
    }

    for (int MyYhoFbi = 1355831902; MyYhoFbi > 0; MyYhoFbi--) {
        lXImxLxMCjJ = ! JBqaoENVeYvETPxu;
        lnDhdqbZjRXKy /= lnDhdqbZjRXKy;
    }
}

string nITIgtwNtcmV::PBMOIvkoCXcg(int jsxGmBKHb)
{
    double zpizjJBlVbO = -692935.7056778761;
    bool DihgMTAFWM = false;
    double SwrNRVykl = -163554.22606451967;
    int tZtUuSHUJB = 19348450;
    int rLwBGvpPKsocxJ = 355827337;
    int FcIYuIhqSb = -692757144;
    double CvjNNcLUWtB = 721867.1262000696;
    bool ZNGqk = true;

    return string("KsQpoNYRnUKPGDfvVEjwcumCKuDfBTTrFMpYUJyDQSboFnCrnuLHNOisiVIXNmhqPWcmEZBuisHesdhSZtdYqVhnASXgeyfLqNSZcOQBDFoXgUaAEMpcydYdPbIxUIbHgIAinJqCpiM");
}

int nITIgtwNtcmV::FDbVLMbaYUvFwrvs(bool sNphS, string KCicSeHZUMnemA, double KOxngkpANm)
{
    int WopxYMCNO = -257619957;

    for (int EwJbyUAjGVOIYCP = 1192018228; EwJbyUAjGVOIYCP > 0; EwJbyUAjGVOIYCP--) {
        WopxYMCNO -= WopxYMCNO;
    }

    return WopxYMCNO;
}

void nITIgtwNtcmV::XKfKfBg(string zqGlvEuJZv, int kKTqo)
{
    double FHVMa = -953846.8147692237;
    double sXSZDOQw = 556611.6103266261;
    string RvWazKt = string("INNzBTZmcofXjJkgpPGbkghTvhiVtAqCBLEvePwQcrqgnCchXFSllZvEHmMMEQqNcYMORSiEderAldmSmModLWqtYHUDDsgSeijxNZFviTDHQHCumckwdZIxdTfJKEilmOeVPVElnjeBDHDRzcluEwWzmKjtfOTPWOoOgkgtETBBqocbR");

    for (int hWwklPl = 1874426996; hWwklPl > 0; hWwklPl--) {
        RvWazKt += RvWazKt;
        FHVMa = sXSZDOQw;
        FHVMa /= sXSZDOQw;
    }
}

bool nITIgtwNtcmV::HxONTCgJcJWLjZN(double AFDihQgUlzWq, int ehacg, double rDyicNTCybg)
{
    bool eRAzg = true;
    int ywhIztcVYE = -416137482;

    return eRAzg;
}

string nITIgtwNtcmV::JhTIGOdoc(bool bnfLgPhSW)
{
    string CJkqaohGqFx = string("QGteGjlHiPfHJlrfdEdlMVdLvYhSIOROQaxes");
    double RCTwNLBz = 117350.15663289117;
    double PgMLmJAZ = -541449.3362823161;

    return CJkqaohGqFx;
}

string nITIgtwNtcmV::ArHGEnhRte(double EXbjQZFCiEYyx)
{
    bool kNnYe = true;
    double hzXvsSTHd = 227635.8191683811;
    double xiBvYw = 111734.32909563034;
    int BWDpzed = 154278618;
    bool LKZSGQcGq = false;
    bool aeKbDReCCpHQrZoA = false;

    for (int zkLqb = 1765725152; zkLqb > 0; zkLqb--) {
        kNnYe = ! LKZSGQcGq;
    }

    for (int jSegkeKQhEZPI = 1168005019; jSegkeKQhEZPI > 0; jSegkeKQhEZPI--) {
        LKZSGQcGq = ! aeKbDReCCpHQrZoA;
        LKZSGQcGq = aeKbDReCCpHQrZoA;
        LKZSGQcGq = LKZSGQcGq;
        hzXvsSTHd *= EXbjQZFCiEYyx;
        xiBvYw /= hzXvsSTHd;
    }

    for (int SpEWExxmfPama = 1653753053; SpEWExxmfPama > 0; SpEWExxmfPama--) {
        kNnYe = aeKbDReCCpHQrZoA;
        EXbjQZFCiEYyx += xiBvYw;
    }

    for (int ORXfEUuQzz = 728172478; ORXfEUuQzz > 0; ORXfEUuQzz--) {
        xiBvYw = xiBvYw;
    }

    return string("IswRBDTiOqvpeANIDvjIkMeGFqOCaWugGfuXxKHtXUQAmQCmqCoDbnuakUEYUztesPXcRhJMIpCdjlHUYgbOyjjTDqEsYLxVmUHJmiqMTVrrStYDmEAdLHczwDVHyKMdRcdnCxxHuFsIHRElOtukQNiqcATqlyZDwHsHhaiVAWYhzMVLotSfABCNmvwqjfvEbefHloBZfsbIlwdIjwPHZTYv");
}

bool nITIgtwNtcmV::IqHQeNtyx()
{
    double HPGeOJopNt = 498502.7709327337;
    double iAfnpCpAqyl = -725149.1716604488;
    double BpKsa = 485051.63307320507;
    double NQVszWAtdy = 905024.993793795;
    int khDOtbxaFf = -1458580116;

    if (khDOtbxaFf != -1458580116) {
        for (int KVvrgW = 1495815473; KVvrgW > 0; KVvrgW--) {
            NQVszWAtdy = HPGeOJopNt;
        }
    }

    for (int KvnFXSqi = 325405421; KvnFXSqi > 0; KvnFXSqi--) {
        iAfnpCpAqyl /= HPGeOJopNt;
        BpKsa -= BpKsa;
        NQVszWAtdy += NQVszWAtdy;
        iAfnpCpAqyl = NQVszWAtdy;
        NQVszWAtdy += iAfnpCpAqyl;
        khDOtbxaFf += khDOtbxaFf;
        HPGeOJopNt += NQVszWAtdy;
    }

    if (BpKsa != 905024.993793795) {
        for (int cBuTZINyBbya = 577385005; cBuTZINyBbya > 0; cBuTZINyBbya--) {
            NQVszWAtdy = HPGeOJopNt;
            HPGeOJopNt += NQVszWAtdy;
            BpKsa = NQVszWAtdy;
            iAfnpCpAqyl = iAfnpCpAqyl;
            BpKsa = BpKsa;
        }
    }

    return false;
}

double nITIgtwNtcmV::hcRsSTNlbucYzV(bool lNMOTxi, int KFJLpfYGdB)
{
    double GpikfWFDUXo = -559018.6707900248;

    for (int mJCSibgp = 1181513565; mJCSibgp > 0; mJCSibgp--) {
        GpikfWFDUXo -= GpikfWFDUXo;
        lNMOTxi = lNMOTxi;
    }

    if (lNMOTxi == false) {
        for (int jXGuGcxUpEM = 1224300783; jXGuGcxUpEM > 0; jXGuGcxUpEM--) {
            GpikfWFDUXo /= GpikfWFDUXo;
        }
    }

    return GpikfWFDUXo;
}

void nITIgtwNtcmV::eSkHMvdLInBn(string vdIXwVBESpdfbevP, double dhsoW, bool tIGPwmSci, bool jemMS, double IbzNm)
{
    int ZPlzhgn = -1749671423;
    string UXkvuAsK = string("uKhDjcuGhgZfAZCsAjyIiMcjQHJdzmIsHsNHjMUWEBVCcudTnXDzlUDAHrWQYjzfymuqumvPsLpHkmnhLfQgFTNuCiPDNEJuFaGJzJqqfvUq");
    double BfxpUfTZDxS = -636779.8895305608;
    int IZpesyaVLuzWGecT = -1210623221;
    string UMiJdMpCNroHX = string("xhWGnZKPQSUgGpfSJSgjHFUBMxaUqFiybNQWtFEPiJFzxMHyEuTWkcphkNrSJqoyrjiiTuEXAkqDIbjupStmUveMcfrNMfojnzBqtuZXVXzsivBeuJCtXOHHjzpCqqFfVrAhaJsANifswGRMCuWDAAkuKOPvTgliWyYxDLNEHJYYsmFTxHMnXYfnGgrDZOkCuzInhiCabMAkyHYYlQQgqUVNbw");
    bool JngaxFS = true;
    string aahAkEkgMLGrw = string("oLuBuKFufyCuNfKAedUGIuhIhRdtnsgRyLvTBZECPYmSphbHVrBHuYgNaibMctFtqwrnnbfNOKwQWjVfiSIuadliYEAwMisUnwyn");
    int VxhhWOmxjy = 2143922466;

    for (int QxbcPZz = 1784755209; QxbcPZz > 0; QxbcPZz--) {
        jemMS = jemMS;
        jemMS = tIGPwmSci;
    }

    if (JngaxFS != false) {
        for (int BzCxXOSW = 1002741711; BzCxXOSW > 0; BzCxXOSW--) {
            continue;
        }
    }

    if (aahAkEkgMLGrw <= string("oLuBuKFufyCuNfKAedUGIuhIhRdtnsgRyLvTBZECPYmSphbHVrBHuYgNaibMctFtqwrnnbfNOKwQWjVfiSIuadliYEAwMisUnwyn")) {
        for (int VuCCyLVxohY = 939849365; VuCCyLVxohY > 0; VuCCyLVxohY--) {
            UXkvuAsK = vdIXwVBESpdfbevP;
        }
    }
}

int nITIgtwNtcmV::affagjvwFXrAPPkL(string gMGCkzozB, int XseQHkSKJU, string bQFFKFMRYPFyEx, bool TNwqObDk)
{
    int iqNLJpfl = -854007005;
    bool kHykqhCWX = false;

    if (bQFFKFMRYPFyEx == string("YbRnsZANQoZOOGFsQockmZDKmQZVnQiRYenqJLAlFGiqvaqIVJFWuz")) {
        for (int DTJAOcPKQOHSPRb = 1502547505; DTJAOcPKQOHSPRb > 0; DTJAOcPKQOHSPRb--) {
            XseQHkSKJU += XseQHkSKJU;
            TNwqObDk = ! TNwqObDk;
        }
    }

    for (int OqKYbLlJL = 786202473; OqKYbLlJL > 0; OqKYbLlJL--) {
        XseQHkSKJU += XseQHkSKJU;
        XseQHkSKJU = iqNLJpfl;
    }

    for (int pWurJiNW = 1235678875; pWurJiNW > 0; pWurJiNW--) {
        gMGCkzozB = bQFFKFMRYPFyEx;
        bQFFKFMRYPFyEx = gMGCkzozB;
    }

    return iqNLJpfl;
}

void nITIgtwNtcmV::gkjVovMpDrwuXm(double avJkHiCRKg, string BLrEkkVgzVK)
{
    string SsOXqTmZO = string("PvPgogWezUWBfQhuQzKtDEcnySjtPfpTiOvOzqCTfWNriWZxGmXjhEEwiZnLaaNSxctv");
    bool buwEQp = false;
    bool JNulomObfRnG = false;
    string VhABgigRNjzK = string("vUTVLGeyRmZvkLIYGubeFUrePCCENdDdrlJTMaRuWkMzvBXlmqyvpQhpqHfzrOjSMBxqtmxpYhzpRXHUukMvbjRqelpoJhRWtZSdrlPCFFOQxMItcWqirwkoCunSnwzGmReIdfWAkVmHSrlvoYZmkvVjtIxCKAazvPeZgoFivRufJQPAZMnnwOYEZfHqPVzlSnKnocZjFcBqeegQhpqLxCyofjTYKPMQZjWUoouIsKQkodXtpWtzOL");

    for (int SUnnDFVb = 866013245; SUnnDFVb > 0; SUnnDFVb--) {
        BLrEkkVgzVK += SsOXqTmZO;
        buwEQp = ! JNulomObfRnG;
        buwEQp = ! JNulomObfRnG;
    }

    for (int agijdA = 1791880649; agijdA > 0; agijdA--) {
        JNulomObfRnG = buwEQp;
        VhABgigRNjzK = SsOXqTmZO;
        JNulomObfRnG = ! JNulomObfRnG;
        BLrEkkVgzVK += BLrEkkVgzVK;
    }

    for (int VZmXPhVdHyD = 1404017199; VZmXPhVdHyD > 0; VZmXPhVdHyD--) {
        JNulomObfRnG = buwEQp;
        SsOXqTmZO += SsOXqTmZO;
    }
}

nITIgtwNtcmV::nITIgtwNtcmV()
{
    this->BvSYarFRF(-783761.820101472, string("xxJdFLNGaRrzqKpIaKocxzfJftyQqbFNtMBlyYTueXqBXwTaZVqnTEIEnjwyVCAWhjAGeVRDENeXaxOnoUDZhFfRFFPQparLhsZRkQLajPOjplWqwpKaUIMtxUMJCiHiMWVkypuYayaWXZnXSilzblHgJxRIThSKtMgdnExIBgGKHNCzLjGeTMSHOzFpyEtSOJPgPcKJsCrcklY"));
    this->rUPLsnK(-390685921, 110803.45894650818, -333707.50518131425, 835690.7708139116, true);
    this->GwukT(-839418.3432893237, true, true, false, false);
    this->zlGCYiIYsoisvAlN(228854868);
    this->IxbqMCV(-1684306755, false, string("lHyyuathZQnMeAmzdcoTevgjMQLiUlSbONGTTmgkWdlBtnXaZfxJkcIicfSJBpEaXXHnjkOykCLGNeLIKiaYzSlkLlVgmkixdsafwlBDNkdyFOmfmmWMEfuFrlNtRBxFiFwxRSitQsOpndbcICixprJACbeaQSXLLguxOCaNMDZhaLTtNcJWTPRIBCidSAFmvkwNoFCLIqNjOItBCrIDSvrGhXsCScfAtHdbcCYrpLzomnopkXtv"));
    this->IrLvuToiAsOsOtQ();
    this->BIkmuzdH();
    this->oYlrmkXGqz();
    this->PBMOIvkoCXcg(-912053334);
    this->FDbVLMbaYUvFwrvs(true, string("gXeNKgQMoJwFaTnNMKsmisgsxewLPDjZIpXMShJAarsGWjqquMumicDcNacNePofaYGqLSjAZuyAdmlUFqhZAXSdekDoyNSKKBENPOPwpzMFtWAKDTfGzAwZRKHMXRBJMuDjmYlcgdpYsEyuTltTeQfFxSzF"), 568494.2996165493);
    this->XKfKfBg(string("VFIsblGRLSSXqtEqelFAzuJrgYJnlxYAUzqEpeBDmbYHUwLzwdWfKXYOuUzRtbHUxPlemuxeke"), 1947595581);
    this->HxONTCgJcJWLjZN(-665811.1748499046, 1073240911, -175073.0986145102);
    this->JhTIGOdoc(false);
    this->ArHGEnhRte(-54015.505726786025);
    this->IqHQeNtyx();
    this->hcRsSTNlbucYzV(false, -1787498826);
    this->eSkHMvdLInBn(string("doeIbVqNNfBWxMsoRT"), -482851.6000460102, false, true, 889708.7140381222);
    this->affagjvwFXrAPPkL(string("xnhHzwVVYkmZadTVZhzucSgFQDEQwmNzpXSNyiUJdqDalTSLRpUpzeHYLqkUJdVYxC"), -1030576144, string("YbRnsZANQoZOOGFsQockmZDKmQZVnQiRYenqJLAlFGiqvaqIVJFWuz"), false);
    this->gkjVovMpDrwuXm(303788.48700045596, string("LxtKqFwSbbARylCJnjeFiNyDauKBSzTQpxnzlWoorhIzHgUEoCQYxuojkOzVjEDchzvNVHnpdDtfkSKpwPQztEIHtuqhNoJumIPIBZjiUXdYXJSLtMSEBViZqdCctUUcFLaaQmXCmpbTQsGTosLWAvqZzQuapkRVzgjngKESJaBhZJHZitkkZzFxFffnMfVXftWimdQpXzerlDOWsBGMcLHWSKQGTBJASC"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jcAVlCizRXuezJH
{
public:
    double eHEHujeYomBR;
    bool mXGAVAOQpf;
    double MlUcAvDh;
    string rbOGmSaQWWbk;
    bool FTtWqqYyns;
    int UYTlq;

    jcAVlCizRXuezJH();
    bool tlUPycunfIIGUj(string KkIVFnFdHXqgV, bool arMApG, double WwAvPDttQ);
protected:
    double VmVQiHxzFdb;
    bool BfQjQaouRcJGs;
    double wiKvwRTe;
    bool sWZbItfqC;
    double pychcRRw;

    void bHzzaDfxgBxvq();
    int mkIXwVXpSqhCg();
    bool uFWpGtFwHGQfXryM(int UMoeyiZHlVqptUPJ);
    string efkbgJD(double JEefgxPS, double iKxcsV, int pwoQhXjZVb, double JMLpuJOE);
    bool ovYhcjGEDlDvVqq(double katYG, string OwpLlvXn, int iftIYApETALWm, int CBivCOT);
    int cutNNcDIeDBP(bool TqoxKyJq, bool eepNWsV, bool ZYvcfVx);
private:
    bool zuVccPXFSTKYNV;
    int DmTyolMsF;
    bool tcDrCyaDlSgSX;
    double qOMywhotMM;
    int mPdqAuC;

    double TfWKvbn(string aGldwLHApuW);
    int HgPhfNiYYd();
    bool yxaeSzy();
    double KIIzho(double ZCBRypvhlNZgNaH, bool hqwPFQldrGkcTG, int wZLmbQYXNpfP, bool wEzScSiLjNMDmo, double ebuyqtYU);
    string gdqeMmJYbNh(double KFAdIdunTzeb);
};

bool jcAVlCizRXuezJH::tlUPycunfIIGUj(string KkIVFnFdHXqgV, bool arMApG, double WwAvPDttQ)
{
    string sOPnQriTPbui = string("dMNpfzzRHbYhMYJUGyXFxuyaNMKGYdjobianShIdftJWkJveugixQgIv");
    bool iZJjKrHVUhNyQJsH = true;
    string lELYptMH = string("dyoSOXPoMKNCddoaxGWpCIxWjhjufvaeOnqoktoaPHZZCAPCqpsjiVzIIBnBDVfYRdcFcZcjHvybNDXKsHtnwJeOHaOvtQhFjoiJckzZnHPquqgzLCcvktQnxBZhUMdGzfDLjmgUEDEJvlZYoToP");
    double tVcmFda = 567926.0836303055;
    double eXsnQONOhXzPaPvN = 67356.48498553014;
    int eAfpsWgUafk = 1906268915;
    bool wymNLlYNHfj = true;
    bool KcWKadGye = true;
    double TWBQlaEjgCj = 114767.04613853082;

    for (int KTFHAULW = 467794971; KTFHAULW > 0; KTFHAULW--) {
        continue;
    }

    return KcWKadGye;
}

void jcAVlCizRXuezJH::bHzzaDfxgBxvq()
{
    string bXNoERttO = string("yhKeSoAVaVkTnsfNUCfUxXfFNPpgDdrtfFKrFNCzLmntIyrdUhGFGzHWZmAYffqrwoeLNmcFOkqZIeJKJpMzMwNkwmbmAwtdZgkVBpK");
    string UHuEcHNBoffl = string("sVJIYvGxixTyRQluqBhqvpUTghbMSGRNRKbeSVwCuoMdYTqyzEvsPxsxHTagDFBbIXlbJrZOjXKlfgQNnvcEILOzefUsxrAEiztutcqgYMlZAGaPJhnYUZbYtd");

    if (bXNoERttO <= string("sVJIYvGxixTyRQluqBhqvpUTghbMSGRNRKbeSVwCuoMdYTqyzEvsPxsxHTagDFBbIXlbJrZOjXKlfgQNnvcEILOzefUsxrAEiztutcqgYMlZAGaPJhnYUZbYtd")) {
        for (int khEYKMxYl = 1601735014; khEYKMxYl > 0; khEYKMxYl--) {
            bXNoERttO += UHuEcHNBoffl;
            bXNoERttO = bXNoERttO;
            bXNoERttO += bXNoERttO;
            UHuEcHNBoffl = UHuEcHNBoffl;
            UHuEcHNBoffl += bXNoERttO;
            UHuEcHNBoffl += UHuEcHNBoffl;
            bXNoERttO = bXNoERttO;
            UHuEcHNBoffl += UHuEcHNBoffl;
            UHuEcHNBoffl += UHuEcHNBoffl;
        }
    }
}

int jcAVlCizRXuezJH::mkIXwVXpSqhCg()
{
    double abRIfk = 946140.5520238563;

    if (abRIfk < 946140.5520238563) {
        for (int UddsbaYRJcWHk = 9119472; UddsbaYRJcWHk > 0; UddsbaYRJcWHk--) {
            abRIfk -= abRIfk;
            abRIfk *= abRIfk;
            abRIfk /= abRIfk;
        }
    }

    if (abRIfk == 946140.5520238563) {
        for (int GMdtcnLTcMgZGjAa = 2108537593; GMdtcnLTcMgZGjAa > 0; GMdtcnLTcMgZGjAa--) {
            abRIfk -= abRIfk;
            abRIfk -= abRIfk;
            abRIfk -= abRIfk;
            abRIfk -= abRIfk;
        }
    }

    if (abRIfk <= 946140.5520238563) {
        for (int AQjdXHqxWFxCqufD = 653105130; AQjdXHqxWFxCqufD > 0; AQjdXHqxWFxCqufD--) {
            abRIfk *= abRIfk;
            abRIfk *= abRIfk;
            abRIfk += abRIfk;
            abRIfk *= abRIfk;
        }
    }

    if (abRIfk <= 946140.5520238563) {
        for (int NMpnj = 726867801; NMpnj > 0; NMpnj--) {
            abRIfk /= abRIfk;
            abRIfk *= abRIfk;
            abRIfk -= abRIfk;
            abRIfk *= abRIfk;
            abRIfk /= abRIfk;
            abRIfk -= abRIfk;
            abRIfk /= abRIfk;
            abRIfk = abRIfk;
        }
    }

    if (abRIfk != 946140.5520238563) {
        for (int eOyNchUnri = 1934277933; eOyNchUnri > 0; eOyNchUnri--) {
            abRIfk /= abRIfk;
            abRIfk += abRIfk;
            abRIfk = abRIfk;
            abRIfk += abRIfk;
            abRIfk *= abRIfk;
            abRIfk += abRIfk;
            abRIfk *= abRIfk;
        }
    }

    if (abRIfk >= 946140.5520238563) {
        for (int tdnOnraVwuk = 1342874481; tdnOnraVwuk > 0; tdnOnraVwuk--) {
            abRIfk *= abRIfk;
            abRIfk = abRIfk;
            abRIfk *= abRIfk;
            abRIfk *= abRIfk;
            abRIfk -= abRIfk;
            abRIfk /= abRIfk;
            abRIfk += abRIfk;
            abRIfk = abRIfk;
        }
    }

    if (abRIfk >= 946140.5520238563) {
        for (int VBJfhycgDEg = 774133397; VBJfhycgDEg > 0; VBJfhycgDEg--) {
            abRIfk /= abRIfk;
            abRIfk -= abRIfk;
            abRIfk /= abRIfk;
            abRIfk = abRIfk;
            abRIfk += abRIfk;
            abRIfk *= abRIfk;
            abRIfk += abRIfk;
        }
    }

    if (abRIfk != 946140.5520238563) {
        for (int rbnLFEKJHuZL = 1270160725; rbnLFEKJHuZL > 0; rbnLFEKJHuZL--) {
            abRIfk += abRIfk;
            abRIfk -= abRIfk;
            abRIfk /= abRIfk;
            abRIfk = abRIfk;
            abRIfk /= abRIfk;
            abRIfk += abRIfk;
            abRIfk *= abRIfk;
            abRIfk *= abRIfk;
            abRIfk = abRIfk;
            abRIfk *= abRIfk;
        }
    }

    return -84823631;
}

bool jcAVlCizRXuezJH::uFWpGtFwHGQfXryM(int UMoeyiZHlVqptUPJ)
{
    bool DEZOnjnoX = false;

    if (DEZOnjnoX == false) {
        for (int HmIFNyJmRIFaSA = 1822323846; HmIFNyJmRIFaSA > 0; HmIFNyJmRIFaSA--) {
            DEZOnjnoX = DEZOnjnoX;
        }
    }

    for (int vDrDHvlLuino = 1434187926; vDrDHvlLuino > 0; vDrDHvlLuino--) {
        DEZOnjnoX = ! DEZOnjnoX;
        UMoeyiZHlVqptUPJ -= UMoeyiZHlVqptUPJ;
        DEZOnjnoX = ! DEZOnjnoX;
        DEZOnjnoX = ! DEZOnjnoX;
        DEZOnjnoX = DEZOnjnoX;
    }

    for (int QWlWhZiZq = 2016557596; QWlWhZiZq > 0; QWlWhZiZq--) {
        continue;
    }

    return DEZOnjnoX;
}

string jcAVlCizRXuezJH::efkbgJD(double JEefgxPS, double iKxcsV, int pwoQhXjZVb, double JMLpuJOE)
{
    int WDaJuqmCueVVNzu = -1014811489;
    bool ilTeNUWBBpSkBTk = false;
    string HaUUvR = string("wrSbyBSGXESCdwOqacJxrMHTImuINhCIOSgrVbyYyWyeCqGyHYtzgyIWYURLflBiLfNHfpAATMsnTnwBGDpDWoahvDlkhgjFxQMdFsvyhQyLXnahoogIbFkRauwWxtTOYmsZAogkoSKNUXdSdegqsjgZGxCW");
    bool lnwVWwPRLDS = true;
    bool vzmxKTRJcYd = false;
    bool flUhDWOuhTurJqex = true;
    bool ROJHUI = false;
    int ofUzSYtKTtiXdUv = -275806441;

    for (int nPUlxro = 156651597; nPUlxro > 0; nPUlxro--) {
        continue;
    }

    if (iKxcsV != 1029041.1950753088) {
        for (int kKmMv = 1489756668; kKmMv > 0; kKmMv--) {
            continue;
        }
    }

    return HaUUvR;
}

bool jcAVlCizRXuezJH::ovYhcjGEDlDvVqq(double katYG, string OwpLlvXn, int iftIYApETALWm, int CBivCOT)
{
    double ZskPZgQuV = -667897.0144428425;
    int shMXcqIH = -365535568;
    bool wvPPqxoKonNziE = true;
    int bQJRhoN = 1967946792;

    if (wvPPqxoKonNziE != true) {
        for (int wQHVOx = 1217910825; wQHVOx > 0; wQHVOx--) {
            continue;
        }
    }

    for (int hVYBukxCoIp = 1245665289; hVYBukxCoIp > 0; hVYBukxCoIp--) {
        shMXcqIH -= bQJRhoN;
    }

    for (int KInAPnDQrLvUykhG = 1857347552; KInAPnDQrLvUykhG > 0; KInAPnDQrLvUykhG--) {
        iftIYApETALWm /= iftIYApETALWm;
        shMXcqIH -= CBivCOT;
        CBivCOT += iftIYApETALWm;
    }

    if (wvPPqxoKonNziE != true) {
        for (int HurPUNRRotNCPTf = 1430491216; HurPUNRRotNCPTf > 0; HurPUNRRotNCPTf--) {
            wvPPqxoKonNziE = wvPPqxoKonNziE;
            bQJRhoN *= CBivCOT;
        }
    }

    return wvPPqxoKonNziE;
}

int jcAVlCizRXuezJH::cutNNcDIeDBP(bool TqoxKyJq, bool eepNWsV, bool ZYvcfVx)
{
    double ccmrAsnDcEiw = -341350.9264575075;
    string apVSgk = string("PdZtvjoqfxeefzsCkFdWqWrNlYLxKgBCJJEsknbgWzcrNCnwPoCnvGVKkwXTqneWCEGUpilDZaTZlUDmvEPSdGNQYsDOVQrXCMekSBcvqPRGPieGfgXFjXZZgLONIeRmlwxxzqijISMcoinGHRDivztxvzfZDdAjHlonBvEhwluRvLNfLWDbDWNk");
    bool IQwSfuvWsO = false;
    double whDGSxQRnX = 680305.2926450496;
    int fXrnLFM = 1168611042;
    string FnoQTqhlYTYVLJ = string("AmXTzfKeeQGJXUOZTgCfJTCuoTSXyxrAlRewFJWslndjqzxDycBfVWaokEbNTabMGlBJLGhELZdHiElfuOBIKZeZCWkcCTPfIrkfxmWJymwesafGLVNQBbNxhzkEkNtkXeQLpKtTYWKcqLJmJIvSOokmvBkyWqvvuNkzJYbVtSolqmvkyvJivbYGMxWZbEnyHKnncDkVEZXBxUQmjPPUqkkBQyv");
    double ldBszfPkOAefK = 789680.8110432731;

    if (TqoxKyJq != false) {
        for (int mLWipKYEJk = 1427381242; mLWipKYEJk > 0; mLWipKYEJk--) {
            IQwSfuvWsO = TqoxKyJq;
        }
    }

    if (eepNWsV != false) {
        for (int wwapkvHCaM = 591855880; wwapkvHCaM > 0; wwapkvHCaM--) {
            ldBszfPkOAefK *= ccmrAsnDcEiw;
            IQwSfuvWsO = ZYvcfVx;
        }
    }

    if (IQwSfuvWsO == true) {
        for (int ZBFVxUyKZxxSkV = 623447069; ZBFVxUyKZxxSkV > 0; ZBFVxUyKZxxSkV--) {
            ldBszfPkOAefK -= ccmrAsnDcEiw;
        }
    }

    for (int UtvLMKfOi = 23208517; UtvLMKfOi > 0; UtvLMKfOi--) {
        eepNWsV = ! ZYvcfVx;
        ldBszfPkOAefK += whDGSxQRnX;
        ccmrAsnDcEiw += whDGSxQRnX;
    }

    for (int VtoSkYAmogHkdvE = 2033263772; VtoSkYAmogHkdvE > 0; VtoSkYAmogHkdvE--) {
        ZYvcfVx = eepNWsV;
        ldBszfPkOAefK /= whDGSxQRnX;
        IQwSfuvWsO = ! ZYvcfVx;
    }

    return fXrnLFM;
}

double jcAVlCizRXuezJH::TfWKvbn(string aGldwLHApuW)
{
    double eBAbBn = 141995.49940823513;

    return eBAbBn;
}

int jcAVlCizRXuezJH::HgPhfNiYYd()
{
    bool SCuVpLfJnHG = false;
    string bjeCWKcsnVLMiIl = string("CzToGCljNfUoWRRafVeaMORqLACcOhgguzxjkZIZlTHucbZXJvVCDKgrXqklba");

    if (SCuVpLfJnHG == false) {
        for (int eiCAqwjbRQOZ = 1705991073; eiCAqwjbRQOZ > 0; eiCAqwjbRQOZ--) {
            SCuVpLfJnHG = ! SCuVpLfJnHG;
            SCuVpLfJnHG = ! SCuVpLfJnHG;
            bjeCWKcsnVLMiIl += bjeCWKcsnVLMiIl;
            bjeCWKcsnVLMiIl += bjeCWKcsnVLMiIl;
            bjeCWKcsnVLMiIl = bjeCWKcsnVLMiIl;
        }
    }

    return -537258571;
}

bool jcAVlCizRXuezJH::yxaeSzy()
{
    bool OJSCWTRcqoEdFEnK = false;
    int hNmSd = 1552662473;
    int umubZ = -471046974;
    int iYvfeJLu = 1158875180;
    bool YXQrZfwya = true;
    string yQzITpRU = string("OnftGFUYNivNKunbCeQSkpWfPrjzAiMbBFoTHtnkCEDeeIFLAUijfTUaQLnuaBltlizyLImfpHIMSYbIABTKroWoelmIKzbxWMORNVnwvoxoFQSFWIRbRJBqErblhpyWKKTMeiIDSAqJzgPBsYtaiVzBexnOVuPMZDOYbOboqBnnKctSpsStLGVlnrdZjmbwxsbGnJdOuDjymnFvuGVUNThwGVYfbWluEaXQXtvtpVIboAYvomjTRhcUXI");

    for (int KkvwSiHwNu = 1804895198; KkvwSiHwNu > 0; KkvwSiHwNu--) {
        continue;
    }

    for (int JfcXQanySsd = 2045943118; JfcXQanySsd > 0; JfcXQanySsd--) {
        iYvfeJLu *= iYvfeJLu;
        iYvfeJLu = hNmSd;
        umubZ -= iYvfeJLu;
        iYvfeJLu += umubZ;
    }

    if (hNmSd != 1552662473) {
        for (int VLAcORGTDlUc = 809853042; VLAcORGTDlUc > 0; VLAcORGTDlUc--) {
            iYvfeJLu = hNmSd;
            OJSCWTRcqoEdFEnK = YXQrZfwya;
            hNmSd += umubZ;
        }
    }

    return YXQrZfwya;
}

double jcAVlCizRXuezJH::KIIzho(double ZCBRypvhlNZgNaH, bool hqwPFQldrGkcTG, int wZLmbQYXNpfP, bool wEzScSiLjNMDmo, double ebuyqtYU)
{
    string WoAhFB = string("ItfnciVhzutNtRehruRfarWzuUWWuhnonuRg");
    string eGzLkk = string("FknufykUyfuyCoQtPbDGEYdXzZxZMUkRDEdFIqlZPtWqSzrjtcLwPMAjfUDslWvlapmMGPDovZboaueSVQutDJewPKzIaFRIbgJritgCQQYoPdrULMUE");
    int LtQXNrVp = 30498022;
    bool DrvEFbbEYW = true;
    string VtjFieQohylTRYzu = string("DIdyCqLsDXCtCweZpdcYeYqiKrwChUFrejylsWLKdirpWUQTcXXlDnyrpBFeOasFKBFUsmCDcccfDBnigrOUQqFFRiIdihRpbpTMtndBIzHTHVvIArJtTAnUgBPtDGVrNdiPbqOVPhnHaOJmHjukXdYNkfDMuiaDuAtHtJPhepZHtcZrmphkdDwlTzWUcntHijCOSYySBGMEGuLlzqZTbAbdSQOKVxhJJIshTXpkwfDU");
    int unNcCfi = -1474316645;
    bool TllFHQE = false;
    int JXOKiaKa = 222412107;
    double GGxuaRb = 729208.4500484094;

    for (int xEWrEwkdsFSc = 1129879393; xEWrEwkdsFSc > 0; xEWrEwkdsFSc--) {
        LtQXNrVp /= LtQXNrVp;
        wZLmbQYXNpfP -= JXOKiaKa;
        wEzScSiLjNMDmo = ! DrvEFbbEYW;
        VtjFieQohylTRYzu = WoAhFB;
        eGzLkk = eGzLkk;
    }

    return GGxuaRb;
}

string jcAVlCizRXuezJH::gdqeMmJYbNh(double KFAdIdunTzeb)
{
    int tfzeGFAQmPKteNb = 94745425;
    int MvXohPDKvDDbiDbA = -449477672;
    double TOxjxDokrdRJxhYO = -530014.6164108054;
    int rHTrlRFcbpcggLr = 1192007414;
    string geSYQM = string("MmNcIoTsokRLhVJIxAXqmLzOknwohmcVGuPlfOcvUsCKmxZzKnWaFXCcxkfCbQAuyabjLGLYwuNDjGkAsXRmrjxWwDQrcknJfhIf");
    bool VlFCSDyuTSskfAmd = true;
    bool LzLff = true;
    int FlriqkzSOPlHk = 2137146925;
    double MPlOPuHVpvMvAd = -636895.0460416613;

    if (KFAdIdunTzeb >= -900284.5409685035) {
        for (int QcfYvQU = 1529692616; QcfYvQU > 0; QcfYvQU--) {
            MPlOPuHVpvMvAd = KFAdIdunTzeb;
        }
    }

    for (int MgzAWtc = 1472078198; MgzAWtc > 0; MgzAWtc--) {
        tfzeGFAQmPKteNb = tfzeGFAQmPKteNb;
        MvXohPDKvDDbiDbA += rHTrlRFcbpcggLr;
        KFAdIdunTzeb -= KFAdIdunTzeb;
    }

    return geSYQM;
}

jcAVlCizRXuezJH::jcAVlCizRXuezJH()
{
    this->tlUPycunfIIGUj(string("ZMlkUzPMPDJBzzJCFHaKVZszvAZmemcyYucuCLpVyKnOgbgqWGYZAMADNSTMVDoiaQDSSVlXavcBicNbCguOFBBJqPZelKChdMJyUlYRhWBKrkFIIuKLWQTGOiibzwZWfSiCrTnkWQWuBxSaeznXxaesjObnNFfELXH"), false, -1036915.5900806874);
    this->bHzzaDfxgBxvq();
    this->mkIXwVXpSqhCg();
    this->uFWpGtFwHGQfXryM(998686019);
    this->efkbgJD(-978687.1405347717, -27634.66557773613, -150184230, 1029041.1950753088);
    this->ovYhcjGEDlDvVqq(-714887.6376777579, string("wlyrqheuivwqOzDKfhlWlqYLgLDawSttEfqpIOhYUiGukgQHzWwjiZHRHPhmDoIA"), 1032627889, 1452338245);
    this->cutNNcDIeDBP(true, false, true);
    this->TfWKvbn(string("eRBMVsQqVZxrDBLJMWiaHYsDwGQPZQGzzpgmdnrBxXNsKJijGggPxgyAnbzSXmLSUaxfuKdyvnWvOUcxlYYCxqcaWvoME"));
    this->HgPhfNiYYd();
    this->yxaeSzy();
    this->KIIzho(-442517.7529507045, true, 313103509, false, 108775.74489225696);
    this->gdqeMmJYbNh(-900284.5409685035);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FkuxZJqiUjROUTP
{
public:
    int NiItTcYOOOCEm;
    double IGjMEAyIza;
    string nBKVbxhJwmRtBxM;
    int nWaktevVpxT;
    int pHZfUXLrTQ;

    FkuxZJqiUjROUTP();
    double fgwSGbVzQAihpszN(string epvCDhyPQ, bool rzZBq, string uhhJIzjMaFb);
    string ZUTLbzfdLNeCDB(string ZSzYHNlUUfJcmOzH, string nLyHHOARcTaqwOVY);
    void CGvIVNmtfdx(string jjHZbNz);
    string HApbRKZ(string HXOJOkh, string AQmlTMUsP);
    int LJUYjTVXEpx(int HJpUDjjMOjB, double jjoKShaXkfdvI);
protected:
    string pFEKvDRCpYu;
    string SBqmU;

    bool ppESkTYWKDoZ();
    string SkQxPm(string lsKecHzVelquVzfA, string rcuFF);
    int itxEzVjtLHi();
    string yoCDUYv();
private:
    int JeodOSo;
    bool piVyYnNzxMVEVtBE;

};

double FkuxZJqiUjROUTP::fgwSGbVzQAihpszN(string epvCDhyPQ, bool rzZBq, string uhhJIzjMaFb)
{
    string QOHXVF = string("sGKKeexERlnl");
    int lCuxAYgRiR = 993968423;
    int orksR = 230118220;
    int euaDj = 1572421400;
    double yXtyenTvSyhY = -352498.0738348426;
    bool YbWLxXnbUK = false;
    string oevAaTNTYAZVnU = string("sIENYlqxTdjMMAjmGrilJmuMovhPYswDxVMmMvNsjHjPpejMHSZHoLjRyVgLMcyfQrumomiJUcwFFwOySGmeMWEOZdgFlGpiQDwbudzTMEucKzubfaXqmVbthtgfdWqqhMJYYVJxHMSJFPpjNxPisfMkzZgkmflkkWETQOToKyAaGveMoclTrtHpxWgDEUPVsWSYmUUFNtJbWvJgVeAaXc");

    for (int ADHIaAacSI = 812800217; ADHIaAacSI > 0; ADHIaAacSI--) {
        continue;
    }

    if (QOHXVF <= string("sGKKeexERlnl")) {
        for (int KeLzbyPzfzFYaZu = 338859663; KeLzbyPzfzFYaZu > 0; KeLzbyPzfzFYaZu--) {
            oevAaTNTYAZVnU = QOHXVF;
            QOHXVF += QOHXVF;
        }
    }

    for (int BGUuSdi = 898062547; BGUuSdi > 0; BGUuSdi--) {
        QOHXVF = oevAaTNTYAZVnU;
    }

    for (int xsPvjDTBsjqHDub = 319732639; xsPvjDTBsjqHDub > 0; xsPvjDTBsjqHDub--) {
        uhhJIzjMaFb += uhhJIzjMaFb;
    }

    if (lCuxAYgRiR < 230118220) {
        for (int LLPvzoI = 84403081; LLPvzoI > 0; LLPvzoI--) {
            QOHXVF = QOHXVF;
            oevAaTNTYAZVnU += epvCDhyPQ;
            rzZBq = ! rzZBq;
        }
    }

    return yXtyenTvSyhY;
}

string FkuxZJqiUjROUTP::ZUTLbzfdLNeCDB(string ZSzYHNlUUfJcmOzH, string nLyHHOARcTaqwOVY)
{
    bool CMaairQtGyPdadC = true;
    bool kKUIPGlhQSUGcH = true;
    string tGuGDcRQtNUM = string("hvmzSshROcRJtZtgoaScumINZwGirrmkQPINYacEnWzpAMkjgiJZPFdwFSnyvOBDlzByRxnROOHuCNVdyhYCbQsDHdEhXsvUHyrHyShrdIMdQeBppzbSrBCfpTjfjmXDMfFDHWzRh");
    double gTBungqTzdCrS = 610264.4459395974;
    int mAxrhGo = 1350704013;
    int IRnBbCq = -1439316463;
    int OSfIiedu = -989375931;

    for (int ajqfiNY = 999369487; ajqfiNY > 0; ajqfiNY--) {
        ZSzYHNlUUfJcmOzH = ZSzYHNlUUfJcmOzH;
    }

    for (int ctAwqxmeNlKPG = 947714029; ctAwqxmeNlKPG > 0; ctAwqxmeNlKPG--) {
        ZSzYHNlUUfJcmOzH = tGuGDcRQtNUM;
        kKUIPGlhQSUGcH = ! CMaairQtGyPdadC;
        tGuGDcRQtNUM += ZSzYHNlUUfJcmOzH;
        IRnBbCq = IRnBbCq;
    }

    for (int CRexhkOxIMB = 298060067; CRexhkOxIMB > 0; CRexhkOxIMB--) {
        gTBungqTzdCrS += gTBungqTzdCrS;
        mAxrhGo -= mAxrhGo;
    }

    return tGuGDcRQtNUM;
}

void FkuxZJqiUjROUTP::CGvIVNmtfdx(string jjHZbNz)
{
    int stOTaUCUQY = -551152469;
    bool sSZqGBNAxqfLfwac = true;
    double tWlAgDFNRBnVM = -902127.7291574192;
    double ysEvrOz = 497866.96003727044;

    if (ysEvrOz < -902127.7291574192) {
        for (int WRcqnN = 1684580214; WRcqnN > 0; WRcqnN--) {
            sSZqGBNAxqfLfwac = ! sSZqGBNAxqfLfwac;
        }
    }

    for (int VcnUrlpmG = 630128769; VcnUrlpmG > 0; VcnUrlpmG--) {
        ysEvrOz /= ysEvrOz;
    }

    for (int CEmgObuPsOERnRX = 1298234787; CEmgObuPsOERnRX > 0; CEmgObuPsOERnRX--) {
        sSZqGBNAxqfLfwac = sSZqGBNAxqfLfwac;
        tWlAgDFNRBnVM -= ysEvrOz;
        ysEvrOz += ysEvrOz;
    }

    if (jjHZbNz >= string("RkqFoqNgRNFpOOZDPDKNOytzbrbViizmNwdshzsMUzVQysRDdihNeyszswWBEFVXvcPRbPZRSPQXCOfBwucLxrYkLSAxBtzuINoKZQTRMFQWKmQpSREtOmtxxoedjMNAWFgAhDBrSTomNTGUrDAXdqloBwpzQAYGnYtFDSrNwEimLViOhDnyd")) {
        for (int csZVYJrEEv = 855898306; csZVYJrEEv > 0; csZVYJrEEv--) {
            stOTaUCUQY += stOTaUCUQY;
        }
    }
}

string FkuxZJqiUjROUTP::HApbRKZ(string HXOJOkh, string AQmlTMUsP)
{
    string wvcyqnwx = string("HSzjCbBeFSGwMehasaeMwbgySoSWGtAYlBqClJsJvukCC");
    double GAqPDyGPiZSPn = -79834.03223061158;
    int iFGrQTX = -210734111;
    bool UACtyMzzo = true;
    int aVMlgvrWkZmErM = -1570558487;

    for (int iErTTqZK = 383487651; iErTTqZK > 0; iErTTqZK--) {
        wvcyqnwx = wvcyqnwx;
    }

    return wvcyqnwx;
}

int FkuxZJqiUjROUTP::LJUYjTVXEpx(int HJpUDjjMOjB, double jjoKShaXkfdvI)
{
    string SxEELcMo = string("aLSQeZOawdwCzEmnRPngDqInQRHNBhHsAFinLynJVfpHRHyvXnJpkJXZVpQJZBIvhCAFHJLnWGIBOiiNZN");
    int UnfCTYsZjMzHWWh = 554572572;
    string Cwmlte = string("YbYzjNClOUuWBDboQMFVNxSgECCvuxFyubhhtLjSNkAqjrEdaNWeUzAziQqJoSLAnUaMsWrVXCKOgJKHFhicTKXDcVZFsQtSpsZmVpaDFVdxgntVF");
    double UzIZQh = 105585.03247854002;

    for (int qSmQewqutOdW = 1630704227; qSmQewqutOdW > 0; qSmQewqutOdW--) {
        UzIZQh = jjoKShaXkfdvI;
        UnfCTYsZjMzHWWh -= HJpUDjjMOjB;
        jjoKShaXkfdvI -= UzIZQh;
        UnfCTYsZjMzHWWh = HJpUDjjMOjB;
        Cwmlte = Cwmlte;
    }

    for (int zuXlNUpSPlf = 1508592244; zuXlNUpSPlf > 0; zuXlNUpSPlf--) {
        UnfCTYsZjMzHWWh /= UnfCTYsZjMzHWWh;
    }

    for (int dIrRfzbwwmSmZBia = 222158848; dIrRfzbwwmSmZBia > 0; dIrRfzbwwmSmZBia--) {
        continue;
    }

    for (int QcCqdqE = 2059742165; QcCqdqE > 0; QcCqdqE--) {
        HJpUDjjMOjB -= UnfCTYsZjMzHWWh;
        SxEELcMo += SxEELcMo;
    }

    for (int bLfOt = 1368438071; bLfOt > 0; bLfOt--) {
        Cwmlte += SxEELcMo;
    }

    return UnfCTYsZjMzHWWh;
}

bool FkuxZJqiUjROUTP::ppESkTYWKDoZ()
{
    int CLHzS = 749865461;
    double SiNhIRlfKf = -262489.9234977796;
    bool qZRywSw = true;
    string wWKbJbwCJjyxDH = string("lQgHpdddPyQwRrxcgKMmwUYXHTaPYnVKGIASMNzHSlXsXWylAyAfROGjbzpbYKTMrlFQDXAZKLjNAELTekZIxsaIrdUGdldhTkrIamGzerfGAHaCQSKUWOMczPYTzcBeLNhTMIplWmIkLosMVOVpKIbQNQPLSarnGKyoVRqkbJxFTwSWjMoSrgvPVYoylvfXfwxbczJrZOLgcpfsbuNFaEDFRycsfuIqUVqdqJkcySWSm");
    string ymhGAYkZlPQ = string("jEzyCgJLHpcNWWoNBdbvtENhZksusxxdjzRVgMNcUbBufpMcCBnuwUHPHqOZxVLhWTbKfnSHqOODAIYRvoGGptfMxQgoXYPvOROSDxUNaaHOZhxrvLAIluPZLNvU");

    for (int VUizIsVYBqe = 1008389494; VUizIsVYBqe > 0; VUizIsVYBqe--) {
        SiNhIRlfKf -= SiNhIRlfKf;
    }

    for (int Mvakxrwrwxa = 613886389; Mvakxrwrwxa > 0; Mvakxrwrwxa--) {
        continue;
    }

    return qZRywSw;
}

string FkuxZJqiUjROUTP::SkQxPm(string lsKecHzVelquVzfA, string rcuFF)
{
    double KplpP = 331694.8937997865;
    bool hrwCUh = false;
    int tETshifvMVItzLX = 650228630;
    int uYqWkqLvevaWLHK = 1542782980;

    return rcuFF;
}

int FkuxZJqiUjROUTP::itxEzVjtLHi()
{
    double bXtQMyloTIZNFCS = 1968.0902439554366;
    int tGvKHJubSYaxUxeJ = 2047127074;
    int YPecfrQawRQ = 745279984;
    int reiggEcGDGaoTJ = 112535896;
    bool VzUSuCSSGmDm = false;
    double KPsCFjmAzfEix = 881753.7314729389;

    return reiggEcGDGaoTJ;
}

string FkuxZJqiUjROUTP::yoCDUYv()
{
    string tiDUagOiru = string("ROeYGCYXMZLzlIyXHSkRrhpKcXFOznjQrGyXHaJWGrWGABqwhfQrkrGgLqlcaWjKrZnwbASWMQMFyZiLkGZWbjXNTibymndaNtxgDMVmTdfqijxUmkcdnMWVsCDAiKTCdIfNndAGYohOIZqoZDdPGBlf");

    if (tiDUagOiru >= string("ROeYGCYXMZLzlIyXHSkRrhpKcXFOznjQrGyXHaJWGrWGABqwhfQrkrGgLqlcaWjKrZnwbASWMQMFyZiLkGZWbjXNTibymndaNtxgDMVmTdfqijxUmkcdnMWVsCDAiKTCdIfNndAGYohOIZqoZDdPGBlf")) {
        for (int GawYBhNSHTQzE = 1781561276; GawYBhNSHTQzE > 0; GawYBhNSHTQzE--) {
            tiDUagOiru = tiDUagOiru;
            tiDUagOiru += tiDUagOiru;
            tiDUagOiru += tiDUagOiru;
            tiDUagOiru = tiDUagOiru;
            tiDUagOiru += tiDUagOiru;
            tiDUagOiru = tiDUagOiru;
            tiDUagOiru = tiDUagOiru;
            tiDUagOiru = tiDUagOiru;
        }
    }

    return tiDUagOiru;
}

FkuxZJqiUjROUTP::FkuxZJqiUjROUTP()
{
    this->fgwSGbVzQAihpszN(string("itfMLbATFvLftnUiXnwnwJsOvliyhEtINninmgynHubvjPLKNDhhpbaMoMcTwukwZTrKyHMpGYkyfwccnCeKLVdodcjzVIbRvaJhiIEDtCRUdiFGsibaXzltcdZubOwuXFEMBtwshsQUGAWKMiLoagnpdWjZEtPVjHLVQptgCaXzUfqgjo"), true, string("SJwhmfSkJQtRAOBsEmmOJuxVimwoOaxDIQoLuekskdibJKQlVliyjWWuEfWIxGhMPefFrPRkzsVXhcXxqdKelUbcIhIuBdpzTLrXDwQnRRgicSGmnuYPYjVlfbYFfWmEBzSROoawWoEofBncWDSvbOHbSDgnxOMRZnpMDsGyoImZtanMXdzxOUzlwVAWDsSlIJamSQGthESvsylMBByA"));
    this->ZUTLbzfdLNeCDB(string("GBtythDiyVloVeiGTDsyZWUietqcsoNFlXPAOMAxBYIMMXymgGyrdGscfkKReVKewzPprfXrZfuMSrKSQRvvMPqkXtJHMHCG"), string("ZqvDISdQadaoCLCpIMefiHPjdDXKMMtQXakdqOxyRHKnlYZkzjNbKswWfFwpTZPxobBjSANjKiOJNvLkQFJjSkAaMFgTJCOQjbFfVURMaiFqMovyldAPzVneBrxCEAJBhHLsxfCiNdmabIJuVosDBmUhSxmvvKluFSNxngjIMhRSRGviMeRaEOMfafswUlIrYnHyZuOqJUByskePUbiQdNyKw"));
    this->CGvIVNmtfdx(string("RkqFoqNgRNFpOOZDPDKNOytzbrbViizmNwdshzsMUzVQysRDdihNeyszswWBEFVXvcPRbPZRSPQXCOfBwucLxrYkLSAxBtzuINoKZQTRMFQWKmQpSREtOmtxxoedjMNAWFgAhDBrSTomNTGUrDAXdqloBwpzQAYGnYtFDSrNwEimLViOhDnyd"));
    this->HApbRKZ(string("CaWOBOMehhEr"), string("MfjSIjnIkOehmnBx"));
    this->LJUYjTVXEpx(-862726277, 342636.6469176423);
    this->ppESkTYWKDoZ();
    this->SkQxPm(string("dmuOcVNkUyhrUYZXvYPbVUWeVGVzFmLSRVTshCUSaQPNBdtkarpNSbIb"), string("ByypWrSoFSOJJJmVyTnmfHNTHynyPbslwTNAzbnBLiJBvGZqwKdsoKehtNTACNcFRDRKznkrOEWjCeYxTrMlydWQhlSgCbRgUhtxSDQBrYeLxrOhejCLNdgxiLbPUTTfkqTptEjGVUmAcIzyIEOsuQcdnLFhfTlsGWvLhPMfrILHyLcuRJGytnRTVEishygHkaxUYEyciEcKPx"));
    this->itxEzVjtLHi();
    this->yoCDUYv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NRxAFVZREFERHDq
{
public:
    bool jrwaSoefRtGHeUw;
    string BgoJYYCwP;
    int cAucnTZvV;

    NRxAFVZREFERHDq();
    string IiWrdl(string OzMhtixfrLhIzs, string DQDPPHL);
    bool fCsNVRSfl(bool HIWjybn, double PmUyyxeSi);
    bool nrADeSYJSBwz();
    int yVZinLv(int lWAtAUmJeSoh);
    int UewicUlSxFB(double jRyxvSxdPzZfNJ, bool BQsXbDAL, int sEgQNOwHN, double INrJhoORShjNFhxy);
protected:
    double GJtrhht;
    double DFcceIqIRVGz;
    int iVUrlgxBioY;
    int VaAUMnvshxXwsWgk;

    void IFfcijXai(int AqOqx, bool vfdvXivy, bool UhysHnevrj);
    void awOyZK(double bXLuzecD, int QUhDyTvzHJgwPS, string xvfXt, bool eYhcgIpJxWjez);
    int czoZMPxuVMrZ(int JhcpxfQ);
    int yXbsGMi(bool mFKGHYdiHua, int fLXMjdYw, bool OmVOcGvaZX);
    double gCeMpnmLPJN(double arkQWM, double CwXMetqsgxbnOV, double UaFsdBDoljI, string atJNJvygYWeIT);
    bool gqOStBCNq(bool ZhGuTcY, string xSVXYQsjANJ, bool pGADZxgAKQa, bool Yesohsz);
    void PoesOnaBjJjn(string SVVQbfCRr, string FonBImjrb, int kFBZlZupsI, int nuTxeJSxt, string PbLkyudmdUorYeb);
private:
    string YjKzTOr;

    double ZNbJXqWsdysQ(int qZCsWpGeqcU, bool dzzMGvQnKM, string QKYSit);
    double xLlCAsOtMEMVwQsn(bool bUEWL, double bwPytWshpnRRLt, int hXGZZr, bool PNdSjXAF);
};

string NRxAFVZREFERHDq::IiWrdl(string OzMhtixfrLhIzs, string DQDPPHL)
{
    string afOnYrbAPJ = string("ylAzdcSkYRifcjBLtwahjpZnWDjGcfNuhUcmbBZqgWqbgVbHvUCmaIYqTsbEREWhkSxZySEodbOFQTOhsxdiokFdMQfyyWYlSyczTeqABgBOUyKlWCGPwybhEoBReeeEqYzbXmDeunQrXyWxfCAZFD");
    int sgYzpr = -821678614;
    bool OFQuaEXUQyYGUOvS = false;
    double NQBpaaZZSM = 56277.62389041573;
    bool tkEtn = false;
    bool CpoRJmYESQmzQm = false;
    double yjEuvvrJALQFAc = -315322.6135394159;
    string ycdNh = string("LpMXjGVCUAhDPtDDJNrEdjdBDmEfrChRCQsRwGmtuuBWQHviEJgjogiiIkZPFlzSuMNnxwMhIdZlSGXfvEVntvHyOnwIGYfcVhbzRNuPzoxNfcoriquznxyaQGIVnWlzWHZNcIvbcDGrhnoRVnapnXdqtJzShuoWWWjIYHjaKyiwfZlSNlgEDZOihaVsFjnYYWQzZNEjVfYzTLXaIfFSmHFXOkIvdB");
    bool nPAMDUEpbZrPgIxb = false;

    for (int eYqezwckpqtYso = 734915984; eYqezwckpqtYso > 0; eYqezwckpqtYso--) {
        OzMhtixfrLhIzs = ycdNh;
        DQDPPHL += afOnYrbAPJ;
    }

    for (int sTxHed = 1389367091; sTxHed > 0; sTxHed--) {
        continue;
    }

    return ycdNh;
}

bool NRxAFVZREFERHDq::fCsNVRSfl(bool HIWjybn, double PmUyyxeSi)
{
    bool XMZpRmPZgsdFBukw = false;
    double NnSdDjrhGdTyFmO = 544578.3081152036;
    int trbEr = 810191450;
    int ktJyVTmW = 1367512259;
    int nUEsN = 1866447264;
    double nsvdiTBr = -530188.4281523082;

    for (int ZQPXDq = 338925903; ZQPXDq > 0; ZQPXDq--) {
        trbEr -= trbEr;
        nUEsN = nUEsN;
        trbEr *= ktJyVTmW;
        ktJyVTmW = nUEsN;
    }

    return XMZpRmPZgsdFBukw;
}

bool NRxAFVZREFERHDq::nrADeSYJSBwz()
{
    int naTnlLNuWht = 1303685325;
    double UjaDJsb = -284007.5518364359;

    return true;
}

int NRxAFVZREFERHDq::yVZinLv(int lWAtAUmJeSoh)
{
    bool KsQUCzxVKJMFbVc = true;
    bool oISemBBZymecTbA = true;

    return lWAtAUmJeSoh;
}

int NRxAFVZREFERHDq::UewicUlSxFB(double jRyxvSxdPzZfNJ, bool BQsXbDAL, int sEgQNOwHN, double INrJhoORShjNFhxy)
{
    string pXPZeHYnSAXbDyxm = string("GkbbpeAWjRVychNbbCYpljTiod");
    double MMHsnsrhfH = -737749.8797762765;
    string jPHMkIDZsB = string("mlvFDqIJIslioLIStLhuFxQctpyFzDRzpEnwyokAYoZfnLJFqYFyTWMbuyrZbJWuBXUeRwARwClTpQwaGEmZWEvZvcHXufMZMTyqZDQjKKaVOGrNOtMSkrjSucegHIMvmMOZKAFnnQLsauhrTJNgbOXYTJeASBMsywUnAPZgXaPoThFqJHmigPtzZqMCqeYwU");

    if (INrJhoORShjNFhxy >= -169430.0938957747) {
        for (int aeWjtj = 1983339553; aeWjtj > 0; aeWjtj--) {
            jPHMkIDZsB = pXPZeHYnSAXbDyxm;
        }
    }

    if (jRyxvSxdPzZfNJ < -737749.8797762765) {
        for (int pIxlXHJnBVtAWb = 363653606; pIxlXHJnBVtAWb > 0; pIxlXHJnBVtAWb--) {
            continue;
        }
    }

    for (int YVCNxM = 2132994022; YVCNxM > 0; YVCNxM--) {
        pXPZeHYnSAXbDyxm += pXPZeHYnSAXbDyxm;
    }

    for (int zPcWdtrLym = 1945600898; zPcWdtrLym > 0; zPcWdtrLym--) {
        continue;
    }

    for (int YzofwO = 1999235707; YzofwO > 0; YzofwO--) {
        INrJhoORShjNFhxy /= INrJhoORShjNFhxy;
    }

    for (int mkBMSzBK = 1724978127; mkBMSzBK > 0; mkBMSzBK--) {
        pXPZeHYnSAXbDyxm += pXPZeHYnSAXbDyxm;
    }

    return sEgQNOwHN;
}

void NRxAFVZREFERHDq::IFfcijXai(int AqOqx, bool vfdvXivy, bool UhysHnevrj)
{
    bool SbhqJUzw = true;
    double ailwAWNa = 665864.1822826375;
    string sXJgUiRkMOSts = string("mnJWlruijALcEVWMWFLdIVAUhQXBfrFDkpnXPOPGmfuLZPNONlPnFuAjBstTweaZczxEKTVnnUBmjJwIyLOHKz");
    string YHTJVIaoJpeowNEC = string("prMxKEEdqEWKvzxPxAvwGuXErXVpFokwFbdHoqfqgktfjYsMPLShQQdidRyqlh");
    string SyYbloODFNy = string("mwkcOtMDhDVFwQVkBfnuuOzszrEBTQGMKJtq");
    double uTCCPNcSW = 796186.2142902655;
    bool gznfdHgP = false;

    for (int WgsotFHH = 668299560; WgsotFHH > 0; WgsotFHH--) {
        YHTJVIaoJpeowNEC = sXJgUiRkMOSts;
        uTCCPNcSW -= ailwAWNa;
    }

    for (int KUUMNFGJDyJGa = 657551883; KUUMNFGJDyJGa > 0; KUUMNFGJDyJGa--) {
        sXJgUiRkMOSts += sXJgUiRkMOSts;
        vfdvXivy = ! gznfdHgP;
        UhysHnevrj = gznfdHgP;
    }

    for (int krjTiMtOPoqF = 742061451; krjTiMtOPoqF > 0; krjTiMtOPoqF--) {
        continue;
    }
}

void NRxAFVZREFERHDq::awOyZK(double bXLuzecD, int QUhDyTvzHJgwPS, string xvfXt, bool eYhcgIpJxWjez)
{
    int wynZuwrhj = -264591304;
    string ItslaFoApESDFL = string("AkUmtEVdAXnAjKGWrLlPQnpslkfbhoWJUvLKiGCIBpZwvHcwWhCjVbJwGgptZnQXfEoDBtPerYiScMAErWtrnWMdWIiSxejYowNPDVDmqDwHWEwsIklAUeZulMXXBEbFRbabBLDckaSbJogCHULKSncHPJ");
    bool DKCUGTDdq = true;

    for (int PvItKmFoP = 1785396377; PvItKmFoP > 0; PvItKmFoP--) {
        bXLuzecD = bXLuzecD;
        xvfXt = xvfXt;
    }

    for (int GzOFOME = 718199912; GzOFOME > 0; GzOFOME--) {
        eYhcgIpJxWjez = eYhcgIpJxWjez;
        QUhDyTvzHJgwPS -= wynZuwrhj;
        wynZuwrhj -= wynZuwrhj;
        QUhDyTvzHJgwPS *= QUhDyTvzHJgwPS;
    }

    for (int OxmyKBjG = 1961564865; OxmyKBjG > 0; OxmyKBjG--) {
        eYhcgIpJxWjez = eYhcgIpJxWjez;
    }

    for (int HAsTCoZjXyNsaFYv = 2086614598; HAsTCoZjXyNsaFYv > 0; HAsTCoZjXyNsaFYv--) {
        DKCUGTDdq = eYhcgIpJxWjez;
    }
}

int NRxAFVZREFERHDq::czoZMPxuVMrZ(int JhcpxfQ)
{
    bool rUTtCVeIPOVUE = true;
    bool vJrkeXf = true;
    string WBrXpR = string("TBIwhabvQbmLwKoZNbhiVuQKSokuDOArXvDWlTqJydQuTZTgNExHfLsPcguCRfsfqpIPPDsZYaeSJTmyMtvbJEyAdERuXmDYYHTtmvckxhHFKiDdmFr");
    string bCnkbe = string("wZWBNJdoKmRtgjkKgPwhZpulkmwiWvNRrnRKqGjqMMDCUYRktNXLUXJWuOKPHtDdoKCnNbzFLGzGmBeNZBNgpLqlhVujpohsGHuGTWINQpEjmnaRvVWOFoquGNCbtdYIQomydVYjnZkApXIxyjBfIByaoydOxsRrgakaxOaFbjxM");

    if (bCnkbe >= string("wZWBNJdoKmRtgjkKgPwhZpulkmwiWvNRrnRKqGjqMMDCUYRktNXLUXJWuOKPHtDdoKCnNbzFLGzGmBeNZBNgpLqlhVujpohsGHuGTWINQpEjmnaRvVWOFoquGNCbtdYIQomydVYjnZkApXIxyjBfIByaoydOxsRrgakaxOaFbjxM")) {
        for (int ZAyxodLQ = 1533861582; ZAyxodLQ > 0; ZAyxodLQ--) {
            rUTtCVeIPOVUE = rUTtCVeIPOVUE;
        }
    }

    if (JhcpxfQ == 1956743949) {
        for (int LcacYpCrZQQoWj = 1620378085; LcacYpCrZQQoWj > 0; LcacYpCrZQQoWj--) {
            JhcpxfQ = JhcpxfQ;
        }
    }

    for (int FsGcM = 653959576; FsGcM > 0; FsGcM--) {
        rUTtCVeIPOVUE = ! rUTtCVeIPOVUE;
        bCnkbe += bCnkbe;
        WBrXpR += bCnkbe;
    }

    return JhcpxfQ;
}

int NRxAFVZREFERHDq::yXbsGMi(bool mFKGHYdiHua, int fLXMjdYw, bool OmVOcGvaZX)
{
    double mWOCJysoqCexv = -628836.6102534721;
    int niIhPNNKg = -1730827118;
    bool rqLJcM = false;
    double yJygwbbL = 821895.8173174002;
    int lutQFYqvUXytgQ = -206955193;
    string vrkFAO = string("xiXhtMMfQLlXTTSnDCYXObjSBuqBNjuLTzvMuNEskfITxyNYgkknEwLOEScrsfAHXMxyhYdRjISWSMTpqpssQnnSjUYkeXdhNXwZsjhaSsWheINdQGpkbWzmpeacnxtJZWAGVyeuhUVONBpJsJaGqFMqgVsaKOuPOhHFNzDWzqRnpnuPEJloD");
    int AjmZfluhkocAqS = -1222034782;
    double Gvuco = 340518.7389239473;

    for (int LQdQANeRbajmYzR = 2046253931; LQdQANeRbajmYzR > 0; LQdQANeRbajmYzR--) {
        AjmZfluhkocAqS += lutQFYqvUXytgQ;
        OmVOcGvaZX = OmVOcGvaZX;
    }

    for (int fXTRIS = 857494411; fXTRIS > 0; fXTRIS--) {
        lutQFYqvUXytgQ -= AjmZfluhkocAqS;
    }

    if (yJygwbbL != 821895.8173174002) {
        for (int wXKmXZDbCh = 2012096818; wXKmXZDbCh > 0; wXKmXZDbCh--) {
            AjmZfluhkocAqS -= niIhPNNKg;
        }
    }

    for (int AKWgX = 1666802604; AKWgX > 0; AKWgX--) {
        lutQFYqvUXytgQ += niIhPNNKg;
    }

    return AjmZfluhkocAqS;
}

double NRxAFVZREFERHDq::gCeMpnmLPJN(double arkQWM, double CwXMetqsgxbnOV, double UaFsdBDoljI, string atJNJvygYWeIT)
{
    int cHJjjFohhUJT = 2139553695;

    if (arkQWM <= 840287.8293224678) {
        for (int ikUGMyfYZeb = 419366028; ikUGMyfYZeb > 0; ikUGMyfYZeb--) {
            CwXMetqsgxbnOV += UaFsdBDoljI;
            CwXMetqsgxbnOV += arkQWM;
        }
    }

    if (UaFsdBDoljI < 840287.8293224678) {
        for (int TtKZcRRMjO = 1791832834; TtKZcRRMjO > 0; TtKZcRRMjO--) {
            UaFsdBDoljI += arkQWM;
            UaFsdBDoljI *= UaFsdBDoljI;
            UaFsdBDoljI -= UaFsdBDoljI;
        }
    }

    return UaFsdBDoljI;
}

bool NRxAFVZREFERHDq::gqOStBCNq(bool ZhGuTcY, string xSVXYQsjANJ, bool pGADZxgAKQa, bool Yesohsz)
{
    string HXolWPL = string("NUquCRlTKwTEJfUdNTiNaHWVnGbpxojHnbJUhalhrtVqkhaSNYoJveQYuSlqsaJpGAQNQfpJzYgOezfZPizcONsVdPSLLMpdQCrHJiTacoAHwvHTOeOmHTDoLePwfmBvNoGjJDdSTkFtjRxtMQFhEseaPXzuVdnAVKnMmBWYlXpmiSRjquMeajVBRiJgxgadgfPooGoEiqOAzzitiqmKDAMQJhPymcOZuMLoLCvDdMeIRtTbxSnRrRTf");
    string QUkCziShakAY = string("pTLFcKPNZToYwxSakfLCnXUQXXzAeQshHUuhgAxvmMwgsTYfCRNQqutrBZHpNloFoIEcdYXegbenWdvEKYxGBalCetcokr");
    int VanASsjbqUYSgpBX = 130359447;
    int eCwoAtgxwU = 1679993860;
    int qBQmrb = -400797606;
    double NTMNATsigFSDD = 323707.6006981063;

    if (QUkCziShakAY > string("NUquCRlTKwTEJfUdNTiNaHWVnGbpxojHnbJUhalhrtVqkhaSNYoJveQYuSlqsaJpGAQNQfpJzYgOezfZPizcONsVdPSLLMpdQCrHJiTacoAHwvHTOeOmHTDoLePwfmBvNoGjJDdSTkFtjRxtMQFhEseaPXzuVdnAVKnMmBWYlXpmiSRjquMeajVBRiJgxgadgfPooGoEiqOAzzitiqmKDAMQJhPymcOZuMLoLCvDdMeIRtTbxSnRrRTf")) {
        for (int nqMITnBWxYG = 1121018939; nqMITnBWxYG > 0; nqMITnBWxYG--) {
            QUkCziShakAY = HXolWPL;
        }
    }

    if (QUkCziShakAY > string("cKYcuokwdsGnlZWvuIAHpMVtujdmrEWiMrhHDzwYwIDgIGnXHzoogDYmFPsWivskeVddyKZGjNIkCmiSDCdzQYtplUZCXsuGdunXIvJiNXxziLtoWgFZRhhpiKXwOuEKEhUxJnnmTvWTzOjYPMVaDZjffeblBdgYKaiieQhtaEeHZpciFVvjmqsNLwBKunzicnfLdOtRfUKgNOCfyRKaoesDJiqueIPEesjJeyfl")) {
        for (int aWsPSxAOTJDIoegw = 1376300414; aWsPSxAOTJDIoegw > 0; aWsPSxAOTJDIoegw--) {
            xSVXYQsjANJ = xSVXYQsjANJ;
        }
    }

    return Yesohsz;
}

void NRxAFVZREFERHDq::PoesOnaBjJjn(string SVVQbfCRr, string FonBImjrb, int kFBZlZupsI, int nuTxeJSxt, string PbLkyudmdUorYeb)
{
    string kQMJll = string("naCGrFUYQoGkXIRVMbSCMzBiWFpKLQJMPgSXjQIxmimWRSltkOJYxaorHPgTnCUKRzAKcPsGGLtagrCExVIVybEMCZFFClLjRQHvsPMtpSNBdgMtGuCGNpGbcHLqQBKgvy");
    string KoiGjwqoaJhf = string("VtmzgpdnSALCruHmmVQBtHPcnVBZhaUS");
    string EEIJIawrmAR = string("BXKSNKaoWKWuJOysrRbFcFJUqEMvALBWovapqCavBnAsTqNNrQtmrVUAJijemUXiaDyRkBfWjdsBTaFwwCktHzJGJqafQvNYRCRwGfaJDhExWwTEfmIhjBmdYxEYjYlpVNaVeUDyGPnUFFKgoMnHfEZdzVCNDZowuo");
    double BekrZHhabZkf = -98494.33648086982;
    int DsZAQwgcOHRiyNY = 74300615;
    string WTPjJVl = string("BLynJCDDDxCXmKUTKtSuUVaQynbxIRciXvpwIxclDsDVedDuEzZFyHBqTJCDKWnFJhighMUkKQOgKGhLaLwPDrmKzghatpzQYlzPflKImNITliZGdJaBDEPUvYTXEDUOMjiROGSitoJEhpGtDkmfveudUMranhXIzWLycgcGWDkClVQeKSIGFDBRCmyiEzWorbFgPcBfgwHkn");
    bool CIADspa = true;
    string xuotgRaNES = string("rBLlWUVeobvtltyNcSuWsvSdelhJxIkEoktbCBzrsgZmOpuXmeUZuLUeAvOWsSlhpEzxVhLtlFETeXZgIQFjOFbconrruIQBlGQexBrCOUXROnPcsQOOVUkeXAsvLBsjFkNmIjBCKXBHHSmG");

    if (PbLkyudmdUorYeb == string("qXePYHXHwDrdxZoadJQjIvHckGFnrCTPaSZiCSBOHbrdzspPZrDMCxQanyTMMdklQgJgsoqkpQrtHChadnVUmYABxcrMWXrFxPHkMNkCdMsLeeUpQZDdMTooNrFalHKqivKazIAXoBQGffjwMdSDBtvVjqERQAzWKAfHKHzelfCzAejIbhfjEDKERlHlToDEJZRxaWbyXuGsWTKnOIJyKxdRlBMpJeyaWgjfTgdUPKWTfas")) {
        for (int NPEbYDln = 1211582967; NPEbYDln > 0; NPEbYDln--) {
            KoiGjwqoaJhf = SVVQbfCRr;
        }
    }

    if (WTPjJVl == string("naCGrFUYQoGkXIRVMbSCMzBiWFpKLQJMPgSXjQIxmimWRSltkOJYxaorHPgTnCUKRzAKcPsGGLtagrCExVIVybEMCZFFClLjRQHvsPMtpSNBdgMtGuCGNpGbcHLqQBKgvy")) {
        for (int mqOKgK = 908676200; mqOKgK > 0; mqOKgK--) {
            WTPjJVl += FonBImjrb;
            FonBImjrb += xuotgRaNES;
        }
    }
}

double NRxAFVZREFERHDq::ZNbJXqWsdysQ(int qZCsWpGeqcU, bool dzzMGvQnKM, string QKYSit)
{
    double XszGBGJEtpohLVVN = 322601.07613242825;
    double kFHaBFrFQjreH = 17205.335308775306;
    int HYSPMgkplArFuws = 82992762;

    for (int ysDgTax = 818081443; ysDgTax > 0; ysDgTax--) {
        kFHaBFrFQjreH = XszGBGJEtpohLVVN;
    }

    for (int zrfnjntPOCaRWXg = 941319868; zrfnjntPOCaRWXg > 0; zrfnjntPOCaRWXg--) {
        qZCsWpGeqcU /= qZCsWpGeqcU;
    }

    if (HYSPMgkplArFuws > 1889215580) {
        for (int yimdpmMesiPl = 388936766; yimdpmMesiPl > 0; yimdpmMesiPl--) {
            XszGBGJEtpohLVVN += kFHaBFrFQjreH;
            HYSPMgkplArFuws /= HYSPMgkplArFuws;
            HYSPMgkplArFuws /= qZCsWpGeqcU;
        }
    }

    return kFHaBFrFQjreH;
}

double NRxAFVZREFERHDq::xLlCAsOtMEMVwQsn(bool bUEWL, double bwPytWshpnRRLt, int hXGZZr, bool PNdSjXAF)
{
    int jOAuyuTknESlLMhH = -520143339;
    bool xxtkZUEdsoSQWPa = true;
    string osqZDbqvj = string("KoATnvDrEDNusruIyNjdZOPTgu");
    int DFcGuksFnU = 441517598;
    int UWxGjJush = 1051940366;
    bool crugcfqMog = false;

    if (osqZDbqvj != string("KoATnvDrEDNusruIyNjdZOPTgu")) {
        for (int EYIvsIE = 1884724932; EYIvsIE > 0; EYIvsIE--) {
            continue;
        }
    }

    return bwPytWshpnRRLt;
}

NRxAFVZREFERHDq::NRxAFVZREFERHDq()
{
    this->IiWrdl(string("HhWTVAjhbbmkmxFRvGtOVEhfv"), string("YtPgdbVNFesEaiTeARZdLbvMcCvZmgZtZfZGVENwSZQsISmyFIcugtmjqwNvBUFbBrjeRVyeTClBfsUCThUBbLElpaEkpyzAXDHpgamEQJUKnUEmHmlGEkBYOxmtJcUlRETCxPwsVfsjjqUZrbMIVayzCljPLKewjuPlVQxsJhLuHstViqRIClncGybM"));
    this->fCsNVRSfl(true, -628631.7073051517);
    this->nrADeSYJSBwz();
    this->yVZinLv(-1821207886);
    this->UewicUlSxFB(-169430.0938957747, false, -448988817, -944936.1618308118);
    this->IFfcijXai(-1353147751, true, true);
    this->awOyZK(-30674.66168713985, 2123850979, string("wKNQUvubImnbbzeIvigIgyfhFINpbSHblyRJgmNHKbzsigmJIZtAKtutNNxalYqsFQbaxYiyEPNoXfutelknCLHHtNRWZsFHHDrFuItTyXQhgWVWrZIargGzt"), false);
    this->czoZMPxuVMrZ(1956743949);
    this->yXbsGMi(true, -1544545529, false);
    this->gCeMpnmLPJN(-336329.5973405246, 840287.8293224678, 652017.9574723036, string("WkILwQYTxRQqTldORJhimRGUopTciCUKwByvbAeNoGWsXePLkMdFSUhEGoxsbPWUitxZaZzivsVTdTVkTR"));
    this->gqOStBCNq(false, string("cKYcuokwdsGnlZWvuIAHpMVtujdmrEWiMrhHDzwYwIDgIGnXHzoogDYmFPsWivskeVddyKZGjNIkCmiSDCdzQYtplUZCXsuGdunXIvJiNXxziLtoWgFZRhhpiKXwOuEKEhUxJnnmTvWTzOjYPMVaDZjffeblBdgYKaiieQhtaEeHZpciFVvjmqsNLwBKunzicnfLdOtRfUKgNOCfyRKaoesDJiqueIPEesjJeyfl"), false, false);
    this->PoesOnaBjJjn(string("WahlyrhBowgbRscvnKIAgwZPHabaYWteCpmCNJrYfCHjIsjRcyjAIMcJlzqxkftZDPzuCHxDSEIksBBOyQdXPpNVHXfOvFrQUUqPpzdwOQuqrCNmrwtPyshWO"), string("AChsOjllzwiSpgPCfWFvAyPZVpYLOFHsjfnWIZTQoBwoyAiLQcGncDKTWlWitkFGnOLsGsGcjhjksnNUSevjrmGPKcexvssimMIK"), -1295268686, -350961830, string("qXePYHXHwDrdxZoadJQjIvHckGFnrCTPaSZiCSBOHbrdzspPZrDMCxQanyTMMdklQgJgsoqkpQrtHChadnVUmYABxcrMWXrFxPHkMNkCdMsLeeUpQZDdMTooNrFalHKqivKazIAXoBQGffjwMdSDBtvVjqERQAzWKAfHKHzelfCzAejIbhfjEDKERlHlToDEJZRxaWbyXuGsWTKnOIJyKxdRlBMpJeyaWgjfTgdUPKWTfas"));
    this->ZNbJXqWsdysQ(1889215580, true, string("EGuWcWAQnPdCBRNEyiiQNykrkPdlyOCRDPQRKzlpzWnKlEzXqFKehXMEpiqeLsVgtMxaFGhfDrmjYIrBKjeYAJiY"));
    this->xLlCAsOtMEMVwQsn(true, -54644.577843148545, 512853404, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class giKXzjsAVEc
{
public:
    double HXMSerPFXVQbNCMH;

    giKXzjsAVEc();
    string NbANTlmvQ(string mJYTFe, double tygzYCAMRBpvOB, bool gmOJfgmhZuy, bool IkowtGJjAQlnN);
    void StqlkhUqYDG(int jhWeiaIKcIjsCCAy, string VIZFSvgqGFdqoh, bool FKHbIsVyM, string DIoglaSJPW);
    void eIGSJHI(bool Lcrcr, double ycNQFV);
    bool cETELDyosDLm(double QVfPmNBMLUM);
protected:
    double QDgUmmMx;
    string JPElWMne;
    bool hCrgZpr;

    void bLwJjcn(string ppZYqmmQqySsRm, int CqHdp, int dXvYTxPNOhnacI);
    void nQXJI();
private:
    bool PylIFGANVUxcv;
    int jVlBDfyfvqUTmbk;
    string gTfjvUGhEKm;
    string gzNELojzZVjNi;

    bool XEjnndLLgDWj(bool tkwAEYtT, string KJDCpRo, int rNGSeRPgFOAmIHt, bool wmjDUxkU, double VAsSUc);
    void JzauOfOZz(bool ebYbERctYWShuGJV, double cVsoEzoSJFKn, bool DwOzaCApOFIobEg, int KfdawO, double ScTSXuYmKwCmuDYR);
    string wtbKkgChn();
    double tajymBqSLYLi(bool Hczsg, string OSaZkwHIGREUW, bool rjvcuiNT, bool HfpllgVNGq);
};

string giKXzjsAVEc::NbANTlmvQ(string mJYTFe, double tygzYCAMRBpvOB, bool gmOJfgmhZuy, bool IkowtGJjAQlnN)
{
    double vHAWDseUpPd = 171532.5316594452;
    double fjAlyHCsQv = -1003227.8524435909;
    double uIRJVLGtQFVJhj = 929257.8915097691;
    int NBxLNnqPMclzcFOC = 979723560;
    double PQRfsdfgoqPGFNRq = -75531.32497431301;

    if (uIRJVLGtQFVJhj > 929257.8915097691) {
        for (int JUFACpElHm = 831791240; JUFACpElHm > 0; JUFACpElHm--) {
            continue;
        }
    }

    return mJYTFe;
}

void giKXzjsAVEc::StqlkhUqYDG(int jhWeiaIKcIjsCCAy, string VIZFSvgqGFdqoh, bool FKHbIsVyM, string DIoglaSJPW)
{
    bool BxjfhZ = true;
    bool ifKZhmBSA = true;
    bool PlsoGubcLSzyh = false;
    bool SjbkPTlOErVYilxk = true;
    double BXklOiuqpbMIVdM = 916053.8622505671;
    bool LRkgzGEtmyDNJ = true;
    bool oYcMVkXWdWzY = true;

    if (SjbkPTlOErVYilxk == true) {
        for (int xJZfXHtTmRXu = 1478920746; xJZfXHtTmRXu > 0; xJZfXHtTmRXu--) {
            LRkgzGEtmyDNJ = ! ifKZhmBSA;
        }
    }
}

void giKXzjsAVEc::eIGSJHI(bool Lcrcr, double ycNQFV)
{
    bool CcelgtqmLhbNsf = true;
    string ZnBAARjz = string("UEWfyAqDwMvUgmGPlRHVgfcxSAlfBYhZSFJmzZMcVhzFOcBIdfsYzhJIAtuGrQIWgDEcfifeyqdTQYnnYVSgfnJuyfvDuBARSaTIOIXBxeQLhfOFqscrrxkiEoPRQ");
    bool njpNUkH = true;
    bool igxielv = true;

    for (int AtdfEACJeWs = 459196257; AtdfEACJeWs > 0; AtdfEACJeWs--) {
        njpNUkH = igxielv;
        igxielv = ! igxielv;
        njpNUkH = ! njpNUkH;
        igxielv = ! igxielv;
    }

    for (int gdAoSkQwX = 1341867168; gdAoSkQwX > 0; gdAoSkQwX--) {
        ycNQFV /= ycNQFV;
        CcelgtqmLhbNsf = CcelgtqmLhbNsf;
    }

    if (CcelgtqmLhbNsf != true) {
        for (int tuBBvs = 1444720845; tuBBvs > 0; tuBBvs--) {
            continue;
        }
    }
}

bool giKXzjsAVEc::cETELDyosDLm(double QVfPmNBMLUM)
{
    bool eZWwpj = true;
    string CDwHTExwskEtyLVW = string("jzPgmJXSwTkyBZqfOBfMaOCaUENEsHGmnUQiodBhJSkjWIHSQvTgCBrTptnzCKfZtaJkDuUNetatOHOOWRYbEssEfoYTrHadceqUKZwyYGXbkMZjvJZYTwRWzDdCSAEVMnHMCthlKgtVQQphklvALQpZsEeKpthrYvomSaUOdNfARdsawnYkNZqB");
    string bgkYVVmEZcGLwpg = string("ipyLhJLEVQVFhTYqtxdgyJXbCnLszIqdfvCpvHKYtvBtcbvKxYKIYSSmGqLTQvqLNmtoXFDiCeeAUpHmopOcrXpPSECnygzPAqnCdVMzJRzttauHDRQEyiiBhXcGdsEVNfiktBnUqoacsDzVtRUZLPVwlJHuNgGjfXyOZwbYXgbbUYLSSpgoHZeSqQCQmlmlrUEFAmsGtMrkXJnFXVlojqQnDjKgrUZaxhyOimqefzVriuOuflPcOGYIj");
    string ZMDlO = string("BcjoemgwaqfPIMWieDcjSgnPnufHOmKMujdlZxJCQMHUsUnuKOYWSWawluafAaPAKTtkkQCnRhhITbLYLzAwRAUNJwnuPqOwUPrkbOUmMMYYgErxAEduMBdqPlpTubsViNWJDxZcESDBQAtZBmCZwqnCTrGxMobLsMMTJXXWSohnx");
    string oFktXPAPSSgCQ = string("dFZsOyvFSTOlIjTALAlWbErMXrqoewmOUCkysickrYdwrGDThFrzYuEPGJSUdLXaRYyoiUhotfdSRBETeOUyNJGUjtQBserW");
    string NIDsbCdmlKNxjhX = string("hnUSkLBRMGHhVlilzfxEZVWWHnXdrdfdPonGyCYWnTvnCPIiCiCZvAPaeHqCOVWBRxciczcEhZXjyZtAjnvCkhQKUKcCbmNGuXxxsBXxIjIhKLzOyLiVR");
    double qjRZA = -986361.971118454;

    for (int SNRGmI = 383668457; SNRGmI > 0; SNRGmI--) {
        NIDsbCdmlKNxjhX += bgkYVVmEZcGLwpg;
        bgkYVVmEZcGLwpg += CDwHTExwskEtyLVW;
    }

    if (oFktXPAPSSgCQ > string("ipyLhJLEVQVFhTYqtxdgyJXbCnLszIqdfvCpvHKYtvBtcbvKxYKIYSSmGqLTQvqLNmtoXFDiCeeAUpHmopOcrXpPSECnygzPAqnCdVMzJRzttauHDRQEyiiBhXcGdsEVNfiktBnUqoacsDzVtRUZLPVwlJHuNgGjfXyOZwbYXgbbUYLSSpgoHZeSqQCQmlmlrUEFAmsGtMrkXJnFXVlojqQnDjKgrUZaxhyOimqefzVriuOuflPcOGYIj")) {
        for (int lmrbku = 1878231549; lmrbku > 0; lmrbku--) {
            ZMDlO = ZMDlO;
        }
    }

    for (int aRYinpRWReQ = 865076217; aRYinpRWReQ > 0; aRYinpRWReQ--) {
        bgkYVVmEZcGLwpg += ZMDlO;
    }

    for (int UXFbwxsqP = 2673479; UXFbwxsqP > 0; UXFbwxsqP--) {
        bgkYVVmEZcGLwpg = oFktXPAPSSgCQ;
        NIDsbCdmlKNxjhX += oFktXPAPSSgCQ;
        qjRZA *= qjRZA;
        oFktXPAPSSgCQ = bgkYVVmEZcGLwpg;
        bgkYVVmEZcGLwpg += bgkYVVmEZcGLwpg;
    }

    for (int BIwxTuqh = 201598617; BIwxTuqh > 0; BIwxTuqh--) {
        NIDsbCdmlKNxjhX += NIDsbCdmlKNxjhX;
        oFktXPAPSSgCQ = NIDsbCdmlKNxjhX;
        QVfPmNBMLUM *= QVfPmNBMLUM;
    }

    return eZWwpj;
}

void giKXzjsAVEc::bLwJjcn(string ppZYqmmQqySsRm, int CqHdp, int dXvYTxPNOhnacI)
{
    int logZXy = -24474246;
    string MZWxN = string("YQSOKgwMFrmtKNaaWVUQTigTs");
    double RVgeBGsiXW = -1032145.3516272049;
    double VhjOYIZeObztLIo = -421124.9620172226;
    int HnYowqYmkcp = -1319658587;
    int mXeed = -361025432;
    double BsuXpzV = -435977.077020722;

    if (ppZYqmmQqySsRm >= string("lOwbLNNdDwXnhGSpkyTEyXwtZGWIirCaYRpxvjlxrgjqdmcY")) {
        for (int xwNoqjCVKinfqF = 1287885513; xwNoqjCVKinfqF > 0; xwNoqjCVKinfqF--) {
            logZXy = mXeed;
            CqHdp /= dXvYTxPNOhnacI;
        }
    }

    if (HnYowqYmkcp >= -1319658587) {
        for (int bOilZuOf = 441756072; bOilZuOf > 0; bOilZuOf--) {
            RVgeBGsiXW /= RVgeBGsiXW;
            VhjOYIZeObztLIo += BsuXpzV;
        }
    }

    for (int nLtkJK = 1703156818; nLtkJK > 0; nLtkJK--) {
        VhjOYIZeObztLIo = RVgeBGsiXW;
    }
}

void giKXzjsAVEc::nQXJI()
{
    bool jVFni = false;
    double ZgJcdfGwADqVVH = -208529.15006653473;
    bool rBEEVZWoBHqCJT = false;
    double XTGKnti = 323640.9056633672;
    double CQFZBXl = 542994.1113321098;
    string jyyRrP = string("WuJyOVcLcvBNMaVYGTuoUcjroFomemDcbBVNyDNBIVOUrWHqKCxrSnHWhuOWkhZvx");
    string xloNUnxDzDZVfM = string("MjxnlUdBJ");
    bool aMXPS = true;
    string krvNyvjKv = string("bfZqHsuavCyqFrIixQQAlGjRRFTxItQGAfEVJCguGmizWXdMcUwbBIWs");

    for (int ghtsvWrXzD = 184094150; ghtsvWrXzD > 0; ghtsvWrXzD--) {
        continue;
    }

    for (int sKjZtpcwgO = 1539156199; sKjZtpcwgO > 0; sKjZtpcwgO--) {
        aMXPS = ! aMXPS;
        CQFZBXl *= CQFZBXl;
        CQFZBXl -= ZgJcdfGwADqVVH;
    }

    for (int bAIVoKyipcpuV = 1653890214; bAIVoKyipcpuV > 0; bAIVoKyipcpuV--) {
        jVFni = rBEEVZWoBHqCJT;
    }

    for (int IDcnUHuPE = 1665737504; IDcnUHuPE > 0; IDcnUHuPE--) {
        jVFni = ! jVFni;
    }
}

bool giKXzjsAVEc::XEjnndLLgDWj(bool tkwAEYtT, string KJDCpRo, int rNGSeRPgFOAmIHt, bool wmjDUxkU, double VAsSUc)
{
    double qothWhUNsGCXUqwB = 920016.6168342636;
    string gYUiOwOBvvCm = string("dtMCMjwC");
    string IhhOFdfE = string("XLZrVkHXzsyLEsVMBVuWyjZFDhJKFjssthEfbJWUQPhqdwqlZlPNSdepkGxgXJXboDUytDecvafMuYueDHPalJJueREKRNvHiVuMOUorXDHOLasxQMudGwJkHexLPonlmK");
    double JvaRJBhtRGUGD = -452715.0552727567;

    for (int oFjBZaS = 451373022; oFjBZaS > 0; oFjBZaS--) {
        VAsSUc -= JvaRJBhtRGUGD;
    }

    if (JvaRJBhtRGUGD > 920016.6168342636) {
        for (int IPhkeMvh = 342934451; IPhkeMvh > 0; IPhkeMvh--) {
            tkwAEYtT = wmjDUxkU;
        }
    }

    for (int xSYhbzDX = 1810548382; xSYhbzDX > 0; xSYhbzDX--) {
        VAsSUc += JvaRJBhtRGUGD;
        wmjDUxkU = ! wmjDUxkU;
        VAsSUc /= qothWhUNsGCXUqwB;
        tkwAEYtT = wmjDUxkU;
        gYUiOwOBvvCm += gYUiOwOBvvCm;
    }

    for (int HHlbMQBKv = 647153342; HHlbMQBKv > 0; HHlbMQBKv--) {
        KJDCpRo += IhhOFdfE;
        wmjDUxkU = ! wmjDUxkU;
    }

    if (JvaRJBhtRGUGD != -452715.0552727567) {
        for (int tXUVkgOwEFUOwCF = 1026297132; tXUVkgOwEFUOwCF > 0; tXUVkgOwEFUOwCF--) {
            wmjDUxkU = ! wmjDUxkU;
            IhhOFdfE = IhhOFdfE;
            wmjDUxkU = ! tkwAEYtT;
            VAsSUc -= qothWhUNsGCXUqwB;
        }
    }

    return wmjDUxkU;
}

void giKXzjsAVEc::JzauOfOZz(bool ebYbERctYWShuGJV, double cVsoEzoSJFKn, bool DwOzaCApOFIobEg, int KfdawO, double ScTSXuYmKwCmuDYR)
{
    int AHYNIifvH = -1854099493;

    for (int LxNPVUUtaXZzabUq = 1534922741; LxNPVUUtaXZzabUq > 0; LxNPVUUtaXZzabUq--) {
        ScTSXuYmKwCmuDYR /= ScTSXuYmKwCmuDYR;
        AHYNIifvH -= KfdawO;
        KfdawO += KfdawO;
    }

    for (int pLkAZ = 561967780; pLkAZ > 0; pLkAZ--) {
        ScTSXuYmKwCmuDYR += cVsoEzoSJFKn;
        DwOzaCApOFIobEg = ebYbERctYWShuGJV;
        AHYNIifvH /= KfdawO;
    }

    for (int WxEEEP = 1463364331; WxEEEP > 0; WxEEEP--) {
        AHYNIifvH -= KfdawO;
        AHYNIifvH -= KfdawO;
    }

    for (int jGipjBbWIMozC = 518328246; jGipjBbWIMozC > 0; jGipjBbWIMozC--) {
        continue;
    }

    for (int SupGylsblHogr = 1131766521; SupGylsblHogr > 0; SupGylsblHogr--) {
        continue;
    }

    for (int hTPeFoasWcqoO = 334034539; hTPeFoasWcqoO > 0; hTPeFoasWcqoO--) {
        ebYbERctYWShuGJV = ! ebYbERctYWShuGJV;
    }
}

string giKXzjsAVEc::wtbKkgChn()
{
    int lhxLMbiorbxJma = 1647127985;

    if (lhxLMbiorbxJma == 1647127985) {
        for (int kQQRpy = 1703164731; kQQRpy > 0; kQQRpy--) {
            lhxLMbiorbxJma *= lhxLMbiorbxJma;
            lhxLMbiorbxJma /= lhxLMbiorbxJma;
            lhxLMbiorbxJma /= lhxLMbiorbxJma;
            lhxLMbiorbxJma += lhxLMbiorbxJma;
            lhxLMbiorbxJma -= lhxLMbiorbxJma;
            lhxLMbiorbxJma *= lhxLMbiorbxJma;
            lhxLMbiorbxJma = lhxLMbiorbxJma;
            lhxLMbiorbxJma *= lhxLMbiorbxJma;
            lhxLMbiorbxJma -= lhxLMbiorbxJma;
        }
    }

    if (lhxLMbiorbxJma <= 1647127985) {
        for (int XgAlzgucBLEQU = 4879373; XgAlzgucBLEQU > 0; XgAlzgucBLEQU--) {
            lhxLMbiorbxJma -= lhxLMbiorbxJma;
            lhxLMbiorbxJma /= lhxLMbiorbxJma;
            lhxLMbiorbxJma += lhxLMbiorbxJma;
            lhxLMbiorbxJma *= lhxLMbiorbxJma;
            lhxLMbiorbxJma += lhxLMbiorbxJma;
            lhxLMbiorbxJma -= lhxLMbiorbxJma;
            lhxLMbiorbxJma += lhxLMbiorbxJma;
        }
    }

    return string("PhFTzdRXiAstqqdnljoRxLVoEqgeqNtscKyTGqjFYNFFsAnNXMgRVlGZIonHLYGYHljorngojwfU");
}

double giKXzjsAVEc::tajymBqSLYLi(bool Hczsg, string OSaZkwHIGREUW, bool rjvcuiNT, bool HfpllgVNGq)
{
    int sMOCTproQUCSCBX = -757015592;
    int ixiHwagZRhX = -1276111730;
    double IoIIBfNFYxqGumz = 294379.7864856496;
    bool ZPtVHW = true;
    bool coTlrhNrtvanau = false;
    double uDglB = 764022.5234619426;
    string NbEzCFaQFbOWMJ = string("eQQXiskbDQKsRJulLzmvvqJmhZpMRtgPTzftUcXKRaydxBHtAADliMAofqzSATmgZehbeheXMovlNtgANWCuHWOshWyOgvjhKmoUWzeHxRFSvhHzxEdKKKbQnjpBEqXSRwJDGfEPSWhVIAMAPgjvYaEBsSJGJfUqHeRhEWObstUyTiFlLdjcBiqJekCmntopmRXucNWpIXNZEDPzmDFLXvlu");
    bool VylhtxsvWCRfeP = false;
    int ggKlePpJydqyz = -63633189;
    double CRouXen = -848460.8242267055;

    for (int gmCFJZk = 1433808997; gmCFJZk > 0; gmCFJZk--) {
        IoIIBfNFYxqGumz += IoIIBfNFYxqGumz;
    }

    for (int oUXCybniUOAlBmid = 531443916; oUXCybniUOAlBmid > 0; oUXCybniUOAlBmid--) {
        continue;
    }

    for (int QWIgrcpXlaVEMhT = 1025488263; QWIgrcpXlaVEMhT > 0; QWIgrcpXlaVEMhT--) {
        ixiHwagZRhX -= ggKlePpJydqyz;
        ZPtVHW = rjvcuiNT;
        sMOCTproQUCSCBX = ggKlePpJydqyz;
    }

    for (int KuYXKYWGuSNkqHKE = 936940939; KuYXKYWGuSNkqHKE > 0; KuYXKYWGuSNkqHKE--) {
        ZPtVHW = ZPtVHW;
    }

    if (CRouXen >= 294379.7864856496) {
        for (int cJoYyvhICVSeGTU = 28864190; cJoYyvhICVSeGTU > 0; cJoYyvhICVSeGTU--) {
            rjvcuiNT = HfpllgVNGq;
            uDglB /= uDglB;
            HfpllgVNGq = ! Hczsg;
        }
    }

    for (int UzTXlSYUQroDQ = 972036809; UzTXlSYUQroDQ > 0; UzTXlSYUQroDQ--) {
        continue;
    }

    for (int cMNStGM = 1067046192; cMNStGM > 0; cMNStGM--) {
        continue;
    }

    return CRouXen;
}

giKXzjsAVEc::giKXzjsAVEc()
{
    this->NbANTlmvQ(string("frEpYDGJxvyHWcEEduDXlbALSXtdhDrtKQiPeWlIBqdnTJjqczVvabplNEemunGyDggqnbWsGzRbWtxRTrDoiGStZTpORHYuTkHbEVkbzGfiocplSUCfcYBjkUSjvGWBDfvaQJjPUVusTYvksAFmFJAOEHNSqYWstsNMVeFtbfOOhnMtZbnqTvdztRfmAoOOGPMMGpdRThSCWw"), 869597.3905268217, true, true);
    this->StqlkhUqYDG(325113227, string("BXdFLGkiVCPlJCrubujQlNDPFarMJyZRaPghoKNbRnUdfWKyrVVMptzWBrmIOLPFVjaPlcJTttKykvrKvwFecibnAK"), true, string("dCOmmNhCwBKmRLDzebhapiWmMQNpVXcbvFyANuafGw"));
    this->eIGSJHI(true, -25242.0933444607);
    this->cETELDyosDLm(-769580.7096173934);
    this->bLwJjcn(string("lOwbLNNdDwXnhGSpkyTEyXwtZGWIirCaYRpxvjlxrgjqdmcY"), 1717576120, -1356003521);
    this->nQXJI();
    this->XEjnndLLgDWj(false, string("SzxlCNQBqgyKxSGIkZkAEBwetNjAXXgqaBcWJexkhSXAUiwHFEhbVVFwtZWTYbdvfZGyTKiVExBdZFaltyAQjKQJrjZNeNNiMRfhiLaSxycVohqXpzWUYmHdqPnXlBgblFgzbVoIqJSJOaKiPEXqnXWvBwMhsXcosTuiRCaWSlbuiqxMSrydhqRQdfIixWEyYaVryfOszkSyb"), -2099976402, true, -876381.2330499118);
    this->JzauOfOZz(true, 934365.9833053147, true, 771372195, 580904.3830794063);
    this->wtbKkgChn();
    this->tajymBqSLYLi(true, string("RIyulpLJwDmjBxDEqluzEgwTGVlImbYjpocgCpEaZAMPpYLoaxuOhyZGviBBwginUFq"), false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ebVkBTvVxsJwC
{
public:
    int Umckc;
    int dErEMUQqscWs;
    double RhWrl;
    double SFUkZJlSzNtLyfE;
    string JjjwSTY;
    int dNdATnOtCnQAxM;

    ebVkBTvVxsJwC();
    string zMHXY(string mbjgvFTprbXBcrf);
    double eOFiVlup(bool XTbiRN, string chhBNNyXRIgW, double qiGvrA, string gxiwMIWznWaeirSK, string iSPKHMeJDaiC);
    int HKsCMX(bool acTIcGQQJ, string CaDkLifKnQ, bool xBGLxpN);
    int SXwwsnf(string FAgBCCWhRln, double KtbQmauIhd, string JhDmIee, string ywdsgzAfI);
    void eGjXikTFXN();
    bool DpAddhxvfeeTNjHk(bool oNWITFCjaQdHxnh, int YoJkSEVO, bool VOMETdvgSYUKZ, int xOSro, int BEmtvVUqDWM);
    int qIHJmqjXIXczB(bool oyvNBDmifTc, int VBiqzClBxeqccdq, double upWumvxvZWICU, int EJYBiewyQqvZG);
    bool EAqzNZhsoBdsIGb();
protected:
    int rKofJT;

private:
    int dIZoxGpUQbEq;
    int vPDgHJPsghdpfjFi;
    string eJtsAUfdRcozL;
    bool sHFWshVzyutwoQSd;
    bool lJyQu;
    bool MFVeGQJbfbNEd;

    string scIgVwANjHEtgTvv(bool jHzChCMuoAONMrl, double ZcdVreGrXxrnbw, double GKACV, bool jbJQeKxFswEhz, string YDBfkaseenE);
};

string ebVkBTvVxsJwC::zMHXY(string mbjgvFTprbXBcrf)
{
    string DfferIp = string("onOrqBoKLwXhgahMRYHZhmFteiaqNFryfjcxGFoGPLCOmEsltNzlNjRxcvwSfPqVdASzyvTAQpotAmRmRPLtyKCLSXCiEzaYEzioHbVoEJuLYlWFrdFmBATrCJBlOeUvCSIdGlRUsmBEILRZBRqllBQtkROCwTICyyadOtbOXQTTNYyuGGixObWaLMTrtnIHcAPaKzzotUprFwqAGWMPmVBsfvHLKPzEWBGdqVWPYRQtlBJptbmA");
    string VmyoSH = string("lUkqfyGYijhRMPdjtEMiAGUFZGunnfygnpjptxJrEWJgepWDaZBOYdnWLHnOHrDDpPwU");
    string HzBuEwQF = string("cjAzsVWuTTwZuNDeZmBIumNPmePGIzowlrdjXKiwYmFqGtmqRIqqgzKqnhdbfbxUgrlJxOrOWcDKvkTVVOrVoaCVSIAGZlvuqaQTKwZdhGsfLBimhkrYNfaNHFDoN");

    if (HzBuEwQF == string("onOrqBoKLwXhgahMRYHZhmFteiaqNFryfjcxGFoGPLCOmEsltNzlNjRxcvwSfPqVdASzyvTAQpotAmRmRPLtyKCLSXCiEzaYEzioHbVoEJuLYlWFrdFmBATrCJBlOeUvCSIdGlRUsmBEILRZBRqllBQtkROCwTICyyadOtbOXQTTNYyuGGixObWaLMTrtnIHcAPaKzzotUprFwqAGWMPmVBsfvHLKPzEWBGdqVWPYRQtlBJptbmA")) {
        for (int BcfzNELWbLo = 2045505809; BcfzNELWbLo > 0; BcfzNELWbLo--) {
            HzBuEwQF = HzBuEwQF;
            mbjgvFTprbXBcrf = VmyoSH;
            VmyoSH = mbjgvFTprbXBcrf;
            VmyoSH = DfferIp;
            HzBuEwQF += HzBuEwQF;
        }
    }

    if (mbjgvFTprbXBcrf >= string("oDJolLKvivEEYPpmMurvbNYIyyGTMvnkXbgltddFhsqrvXxQOVWagLHonhYergVgISPyvnZzsWZUFToFCeWripxzxIpJjVClmjfeFDzEQpCtvsQUBDFRZPgcHnRTseKBqILkzEUFbkoyqIhvLxtYsfpWVyaDQaqHEKnAtuhgMThKrEToUdWEplUQljJvykQyZqlOKecmFuEDsrluPdTnmEHEclEXKnjPTxZrKFIjVtwEkg")) {
        for (int QpznQ = 194141444; QpznQ > 0; QpznQ--) {
            VmyoSH = VmyoSH;
            HzBuEwQF += mbjgvFTprbXBcrf;
            DfferIp = HzBuEwQF;
            VmyoSH = DfferIp;
            DfferIp += HzBuEwQF;
            HzBuEwQF += VmyoSH;
            HzBuEwQF += VmyoSH;
            VmyoSH = HzBuEwQF;
            VmyoSH = mbjgvFTprbXBcrf;
        }
    }

    if (DfferIp == string("cjAzsVWuTTwZuNDeZmBIumNPmePGIzowlrdjXKiwYmFqGtmqRIqqgzKqnhdbfbxUgrlJxOrOWcDKvkTVVOrVoaCVSIAGZlvuqaQTKwZdhGsfLBimhkrYNfaNHFDoN")) {
        for (int byQDOzUYRrnKteOS = 1144948942; byQDOzUYRrnKteOS > 0; byQDOzUYRrnKteOS--) {
            mbjgvFTprbXBcrf += DfferIp;
            mbjgvFTprbXBcrf += mbjgvFTprbXBcrf;
            DfferIp += HzBuEwQF;
        }
    }

    if (VmyoSH >= string("onOrqBoKLwXhgahMRYHZhmFteiaqNFryfjcxGFoGPLCOmEsltNzlNjRxcvwSfPqVdASzyvTAQpotAmRmRPLtyKCLSXCiEzaYEzioHbVoEJuLYlWFrdFmBATrCJBlOeUvCSIdGlRUsmBEILRZBRqllBQtkROCwTICyyadOtbOXQTTNYyuGGixObWaLMTrtnIHcAPaKzzotUprFwqAGWMPmVBsfvHLKPzEWBGdqVWPYRQtlBJptbmA")) {
        for (int mHzggdSz = 1622967419; mHzggdSz > 0; mHzggdSz--) {
            HzBuEwQF = DfferIp;
            DfferIp = HzBuEwQF;
            mbjgvFTprbXBcrf = VmyoSH;
            HzBuEwQF += HzBuEwQF;
            mbjgvFTprbXBcrf += mbjgvFTprbXBcrf;
        }
    }

    return HzBuEwQF;
}

double ebVkBTvVxsJwC::eOFiVlup(bool XTbiRN, string chhBNNyXRIgW, double qiGvrA, string gxiwMIWznWaeirSK, string iSPKHMeJDaiC)
{
    double tiUMiI = 456620.3577149365;
    int xmAUAgjErjz = 757419576;
    bool LQFPrebXswyyvHs = true;
    double StLLYkh = 1003230.826525183;
    int AGegJuwEXimd = 377612155;
    double RapdrAuAapG = -275509.18854303216;
    double ujWLJGUNQ = -795315.1197066269;
    string TQLDJ = string("ckkNGr");
    string sjijhqOTp = string("RiOprWbSVbbfEAmRtuapcEwOIAXgXHLYNaoIdRVKXKOfMixnHLuFDgOQepoNbyporLAdDdAbsXxSNOcJjgEZiwdePEOdZXZHRUKYHJDjnJoAhI");

    if (tiUMiI < 996331.3304606) {
        for (int AuSsfjPPxXX = 1817598229; AuSsfjPPxXX > 0; AuSsfjPPxXX--) {
            continue;
        }
    }

    for (int FgBwlDBAMkzNGYPZ = 1395773068; FgBwlDBAMkzNGYPZ > 0; FgBwlDBAMkzNGYPZ--) {
        gxiwMIWznWaeirSK = TQLDJ;
    }

    for (int xdVfx = 1764029725; xdVfx > 0; xdVfx--) {
        continue;
    }

    for (int xhfRea = 371177008; xhfRea > 0; xhfRea--) {
        iSPKHMeJDaiC = sjijhqOTp;
        LQFPrebXswyyvHs = XTbiRN;
    }

    for (int WTjxvtpKrfOFU = 1270321888; WTjxvtpKrfOFU > 0; WTjxvtpKrfOFU--) {
        continue;
    }

    return ujWLJGUNQ;
}

int ebVkBTvVxsJwC::HKsCMX(bool acTIcGQQJ, string CaDkLifKnQ, bool xBGLxpN)
{
    bool LXRcNRF = false;

    for (int zlSHlqmYDywBomGB = 183511926; zlSHlqmYDywBomGB > 0; zlSHlqmYDywBomGB--) {
        xBGLxpN = LXRcNRF;
    }

    if (xBGLxpN != false) {
        for (int iSFqsCl = 1647243327; iSFqsCl > 0; iSFqsCl--) {
            xBGLxpN = LXRcNRF;
            xBGLxpN = LXRcNRF;
            LXRcNRF = xBGLxpN;
            LXRcNRF = ! LXRcNRF;
            LXRcNRF = xBGLxpN;
            LXRcNRF = ! xBGLxpN;
        }
    }

    for (int dGMmpJBMMlIszRD = 936581878; dGMmpJBMMlIszRD > 0; dGMmpJBMMlIszRD--) {
        LXRcNRF = LXRcNRF;
        LXRcNRF = ! xBGLxpN;
        xBGLxpN = ! acTIcGQQJ;
    }

    if (acTIcGQQJ == false) {
        for (int XvrZoKbpVton = 871628986; XvrZoKbpVton > 0; XvrZoKbpVton--) {
            LXRcNRF = xBGLxpN;
            xBGLxpN = LXRcNRF;
            xBGLxpN = ! xBGLxpN;
            acTIcGQQJ = ! acTIcGQQJ;
        }
    }

    if (xBGLxpN != false) {
        for (int pZkzPbwlXZqXnBB = 453742189; pZkzPbwlXZqXnBB > 0; pZkzPbwlXZqXnBB--) {
            LXRcNRF = xBGLxpN;
            LXRcNRF = LXRcNRF;
        }
    }

    return 2074160149;
}

int ebVkBTvVxsJwC::SXwwsnf(string FAgBCCWhRln, double KtbQmauIhd, string JhDmIee, string ywdsgzAfI)
{
    bool kDcnTWiORGUfjqz = false;
    bool BchiWiTxAu = false;
    string RnzmUMYHuLLdUBR = string("ydXrlsjDFiuZeBgJaWlJlwOMFTeXClMbrIihsNJTVWhoEWvYaygGEVmPyRYyoHqBQrVtCrfNVPUFcNZTsngsXUWuTaUbKCbEIgNUocMzEygBONRwFYpcdzJJnkuNJaKlLocyFJMe");
    bool DHBHSMCHfCzVlTmf = false;
    bool ueoZr = false;

    return -1461205606;
}

void ebVkBTvVxsJwC::eGjXikTFXN()
{
    string EnEXbwexeD = string("SAMrjkbLFrsIHeCACxNyqQSfmvAPuPLGvjGAuabRoUPegGBWloKoUgZvLOpKaGMhuYSYfWBjRavEsrFWLMSuMmqyhAVZibcnETXodtqPiwTABRlHQeYokhtHJHeXUWvCPscAWmAUlgAHgIGrYNgKdMHLEHUvPLlauhxQpgqaWTDbNOlDjyXRquYmDJxyCDUmlzLPqVUGzsKfygIy");
    double ywcfGAsyuzGDulvx = -794517.9969463905;
    string hOszPO = string("qIZwuxAkQKWNuaebhtVhJGKvbKbBRBnchIpAAKPLCBPzYfEKlXBnHfefiydfUJiGbdhjSkPRuOuRIMqupxErHtjASIhSNWaxc");
    string cETiTmEgaZwKt = string("RwmJklyMOevwQhvklBJrlhWmcSWaqyMxlGDBIrKuIDyNxiZVWgAMaXkkeKiWRtlcPyHBhuMaJDgukxtgKJze");
    bool jemKFXaH = false;
    int dEpnCPUw = -147791048;
    double vUepKPXmNXhT = 720638.2263688862;
    int kIfCYO = 2041940602;
    bool gLPdPKFlC = true;
    string HShSDSoz = string("XhvCACaXKrMRlJvaVQNqSxNMcWnQfDiIWnbKZfyumtXEoTvQYDwZQpnVLJVjskzUZpkzFsja");

    for (int WRwKAiw = 1838974328; WRwKAiw > 0; WRwKAiw--) {
        dEpnCPUw -= kIfCYO;
        hOszPO += hOszPO;
    }
}

bool ebVkBTvVxsJwC::DpAddhxvfeeTNjHk(bool oNWITFCjaQdHxnh, int YoJkSEVO, bool VOMETdvgSYUKZ, int xOSro, int BEmtvVUqDWM)
{
    int ibCwzYwS = -2000145073;
    double qeFnVikSanPebWoE = -37551.27431936313;
    int IVDyHOClNcWXiq = -518952513;
    string mkJgkxoleQfdlx = string("VcDRtOVkpQlYKejjGclrVJJsckSflrtdUZPlLqfirmyVBJyulOwmCJswFhpjMwLopcXMEGeuTXKkUZaLMnAOTsCWQZjhPNKwkPzcAWNmQGBSpPiBOwNnxJQGhdyHggYLOTpoaVdguZaLdDDCSpGDyaQZFIjvCXQAcRXefuFyDsrbdWpECrTjoeAXOAeOfcODSjbHhocG");
    string sIxNlkxQzrOHHZ = string("HmaFZvUepqWDXmGlAYSRNQlAKAcktNRfTEGXWjJRXJlKlRBsSJH");
    int YsDwD = -1943936576;
    string AYSOpZlIMQAv = string("HeVTmGheEZCpGAdWQxXeIUXRIoSIWMoIIZLkHQQOadds");
    bool RjpKuJAwcl = true;
    int bQfYkJVbIMeja = 1127193079;
    string TZdGM = string("TdSyQttwixpiqtaVmyieONDkTCkijIombEyRvdubCFDttJpKWZmNjjmjLgTneZCYSMlRauLnDQsvxUGCoRRCaqztfrDBwfWWqePLUgsJRjJZPjYbVYXAjOlMDrSOsDNesUIlRryXeogfoiIhqdplFFSaAqkmeaILbOafmEuQEYTpcuoDh");

    return RjpKuJAwcl;
}

int ebVkBTvVxsJwC::qIHJmqjXIXczB(bool oyvNBDmifTc, int VBiqzClBxeqccdq, double upWumvxvZWICU, int EJYBiewyQqvZG)
{
    int lfwVpGpqDzauYOFE = 277350062;
    string DUwxECULZk = string("UZILMAEXksxHavZuBrztcyTOdHqwXoeXfyJcCSiqcTmFWw");
    double dRkmVPZeelbz = 620290.2170059028;
    string YyaPgRuUxLG = string("mq");
    double lbmSTnGS = 518323.4508364627;
    bool bEeVez = false;
    double GMzcmxGqWN = -482014.69095321733;
    double DWyeoGogNeU = -405207.7799776213;

    for (int swfIcTBjKWVrjG = 446696205; swfIcTBjKWVrjG > 0; swfIcTBjKWVrjG--) {
        dRkmVPZeelbz /= upWumvxvZWICU;
        upWumvxvZWICU = DWyeoGogNeU;
        DWyeoGogNeU += lbmSTnGS;
        EJYBiewyQqvZG += EJYBiewyQqvZG;
    }

    for (int oWEnpWeNMkhbVF = 884687712; oWEnpWeNMkhbVF > 0; oWEnpWeNMkhbVF--) {
        continue;
    }

    if (YyaPgRuUxLG > string("UZILMAEXksxHavZuBrztcyTOdHqwXoeXfyJcCSiqcTmFWw")) {
        for (int XsDZCnFhGGbKgB = 741277468; XsDZCnFhGGbKgB > 0; XsDZCnFhGGbKgB--) {
            DWyeoGogNeU += GMzcmxGqWN;
            YyaPgRuUxLG = YyaPgRuUxLG;
        }
    }

    return lfwVpGpqDzauYOFE;
}

bool ebVkBTvVxsJwC::EAqzNZhsoBdsIGb()
{
    double pcgojMmLTQeaeWtm = -706111.6377417741;

    if (pcgojMmLTQeaeWtm == -706111.6377417741) {
        for (int oqYFLWYtkdoqgr = 1838149528; oqYFLWYtkdoqgr > 0; oqYFLWYtkdoqgr--) {
            pcgojMmLTQeaeWtm /= pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm += pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm /= pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm += pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm *= pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm *= pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm = pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm /= pcgojMmLTQeaeWtm;
        }
    }

    if (pcgojMmLTQeaeWtm != -706111.6377417741) {
        for (int IwesKAjnKqc = 85246830; IwesKAjnKqc > 0; IwesKAjnKqc--) {
            pcgojMmLTQeaeWtm /= pcgojMmLTQeaeWtm;
            pcgojMmLTQeaeWtm += pcgojMmLTQeaeWtm;
        }
    }

    return true;
}

string ebVkBTvVxsJwC::scIgVwANjHEtgTvv(bool jHzChCMuoAONMrl, double ZcdVreGrXxrnbw, double GKACV, bool jbJQeKxFswEhz, string YDBfkaseenE)
{
    int yFPVWfPTaJL = -1840648582;
    int xdmhIbRfFiM = 872517775;
    bool ceXFV = true;
    int zrcNhesuxihlMmBS = 982239232;
    int PZwxywTEGusFn = -479757616;
    double UkMylGBLfYLyTT = -661171.1119530075;

    for (int faTCn = 32169433; faTCn > 0; faTCn--) {
        zrcNhesuxihlMmBS += xdmhIbRfFiM;
    }

    return YDBfkaseenE;
}

ebVkBTvVxsJwC::ebVkBTvVxsJwC()
{
    this->zMHXY(string("oDJolLKvivEEYPpmMurvbNYIyyGTMvnkXbgltddFhsqrvXxQOVWagLHonhYergVgISPyvnZzsWZUFToFCeWripxzxIpJjVClmjfeFDzEQpCtvsQUBDFRZPgcHnRTseKBqILkzEUFbkoyqIhvLxtYsfpWVyaDQaqHEKnAtuhgMThKrEToUdWEplUQljJvykQyZqlOKecmFuEDsrluPdTnmEHEclEXKnjPTxZrKFIjVtwEkg"));
    this->eOFiVlup(false, string("NsWplBTMhiIpAkZD"), 996331.3304606, string("hQJIHQyWPZkTFFdxdZksCIwBuNVEfpIvHNEbrRrNcgDCzXjwaKoIrmSJVTqPYhGHppzHEPwwQMtYOOXWeggcazEgwpfksekiBAxNChzmByJHPAlWmcFmxGsFQLnflXsVoEKQcVCVegxGC"), string("khCHpXARaBIXHqzVWnUWXmBOmEVEWORvoZfOTPnhLrAkPqfRFbOwefHEPWkhlYKszkkrUFtXwufnUkNlgJGjtLvWyFiRysdBqvKEWhFMkSpuABSenkLtlRDqMFGluJVwaXzeyEiHshQnpgSTjHyHvoFwrKqlvRqebCRIqxrlsvYTTANJcLijtCjKQ"));
    this->HKsCMX(true, string("JgMjUdJwJBewSdIllEPXZPFCXjdoAHAftHGLKKqTdUR"), false);
    this->SXwwsnf(string("Tlvz"), -500365.0496159339, string("vHuyMDohyBrSzzsjZVvwbumdioTZHfAhNElCDffhbnmpdsmrmCcowYyFMkPDQPSqTrwpwZTjNYjtkuAXGEVyiqKEZjDxgAFuCEjtDUdwqHAoPbGVMyXGxxVtbhNqQVfHkeuPgQNXjapeYZgXapIdmLlMHLKdeKJQWfoSgUFvFTGDcOgDgbiATNSqtR"), string("KPmMGEAhFEJgeCYfszcuncOkdmhgXcFiofsgmKikbgrPWoopCjlwQelOowhpLyltrhwFiCRuNElhkocjsPLrOEeaykbFcbzyfRBrpDyWHnOfCTuADGkavGyhAcIffousCPWcEeOwJNskohITnugzWUrPQDGENawBmbjfJzrdRiKbtOQAoDLQGjOYgyVCWWnQBByewMwbnRGYwgIERbIIrTwDcBVuRSoTocUvtOHdaweaHSn"));
    this->eGjXikTFXN();
    this->DpAddhxvfeeTNjHk(false, 1303664421, true, 1717331812, -1569746287);
    this->qIHJmqjXIXczB(true, 1227296328, -371851.97564250184, 1690839736);
    this->EAqzNZhsoBdsIGb();
    this->scIgVwANjHEtgTvv(false, 1044559.4671002987, 756565.4161665891, true, string("KNYsGBkDhozJHMOuQGYGkYCNPXuXRiTnSOXhEKLDmQCXXasPMmgBimQfBXujDYxhAoRwNeOgizPRtBkHdXPTFbNmKyzndcQXbTKIAJiWjpJRjhSEQuofxYZVzQXtfZWsEtSrobVXYXfGfctn"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RZbyaAsUeD
{
public:
    bool jYQLLffwDVaHLgpT;
    double avxzDzaFfGA;
    bool UNZtMPyJREilhzxO;

    RZbyaAsUeD();
    void xBvdCUWvYZoqgCvO(int zqCKV, string zxPIEa, double MZadcwMUjo, double jDCnriX);
    bool FVvewARt(string ZyxPnaTnEJXTkkwk, int XYyXqjmUGfQ, int EwkPj, int UuisrjQVFYqv);
    void DQpSIyu(bool SHbbiaqhPktAZkPg, double vKVPaTvBP, bool HzYeJnJhN, string HfkwwJuMhQGV);
    int vDVhYZfVYZbAc(int DUkXhscEDl, double DiBKQoKq, bool iFjeMLeYVAaWuV);
    double jUdPnnMsfpvzxHt();
protected:
    bool omBlHpYH;
    int OwKqCjyXFD;
    bool OzMmvAZKVDr;
    int EpSTtXKz;
    int jDtQd;
    string nvxBXhzKvoeEc;

    double FbluesYpdhTxeaSC(string SrHddypflEGwVNe);
    string fWgFOHulElhU();
    string fmQFoTwMo();
    double hyOne(int QXmudmiudrQS, double eAFbAZumskpUMNej);
    bool wOWSNDwikIi(double qJQFy, int EfCCvAnwLzes, bool nycrVEX, string ZBUQyMY, double TRzwyo);
    double qTfPfSGa(bool ybTGUZN, int MXTnSYJg, string AddTcW, string VIiBi);
    double ABjOtfnMJyk();
    double FHPTuYgMgUHBu(int DfScrFSFppMQbGJw);
private:
    bool ZdMiXRdgG;
    bool TpWbBcenq;

    string pzfSrzjXil(double MdhSYSqME, bool gvwCi, int VFAkL, bool saJAZQfmCQUhc, int rDcROtauLlmWHs);
    string gYsLmNSjWmcfp();
    bool KRAsLYtdu();
    void eXRFnXuRvbHs(int aNxyMKIg, bool fKZwhgso, double ignRD, string AtrMpMFDXqcYj);
    string cFmMvLYwZClvNgU(int CcPzwyVPKDiJcb, string PzZAcwfiVybM, double qirZbFmpzYgSKQf);
    bool iTTUXCZ(bool trAzorAj, int btEKyefECSphBGWJ, double LydaS, int jxizq);
};

void RZbyaAsUeD::xBvdCUWvYZoqgCvO(int zqCKV, string zxPIEa, double MZadcwMUjo, double jDCnriX)
{
    string UpEcwQjlPNOJ = string("xGgHMmrTsAPBbwnHZSyxWAAMoMaVgckgtRmLgTaIjjEoYiYCXTpafHzzlFzkvPqIMWMxIjHuaKYGXCGMgSKQoMPHTZXrFwpqWDs");
    string HzDPeWEqBXPj = string("OVAFKPUoKotnjMvuovTnRFuwWnVWkJXcrsJOhsUghFKGmnFsIHohWVUWUHttRDFbeXwIWgAvlLaRpRFNEFpSqfRxEWhchLszfpXsIFbNhVPfCtfFKSfbMPnOOMcOlSyaKMCiijbZLLgViSuOzRhtmTlCyeXxGCUpDtuzufsyoTHdndSYwlnlqtUExDOEaxfMEasZvxnhkvDfxFWZaZdFqhDQExDcdLZmEpmVoJLSqNJoNqRobDdrbyGjaSTe");
    int BAHPUcFH = 658012968;
    double nLIIRQtXXQrFb = -397774.2229805966;
    double hznzjCzPEWB = -591900.0526384702;
    int uxNgS = 1828459090;
    double lYQSZQjHjxySYm = -145809.44339620604;

    for (int hEBUEijUra = 1640252081; hEBUEijUra > 0; hEBUEijUra--) {
        hznzjCzPEWB /= nLIIRQtXXQrFb;
        zqCKV += zqCKV;
    }

    for (int AyUyyOHce = 346332376; AyUyyOHce > 0; AyUyyOHce--) {
        UpEcwQjlPNOJ = zxPIEa;
    }

    for (int TrkvMXAbDyH = 824579614; TrkvMXAbDyH > 0; TrkvMXAbDyH--) {
        hznzjCzPEWB *= MZadcwMUjo;
        BAHPUcFH *= uxNgS;
    }

    if (hznzjCzPEWB != -269965.70007648604) {
        for (int einNxw = 1004794215; einNxw > 0; einNxw--) {
            hznzjCzPEWB -= lYQSZQjHjxySYm;
        }
    }

    for (int cRaCCacWxj = 391813046; cRaCCacWxj > 0; cRaCCacWxj--) {
        uxNgS /= zqCKV;
    }
}

bool RZbyaAsUeD::FVvewARt(string ZyxPnaTnEJXTkkwk, int XYyXqjmUGfQ, int EwkPj, int UuisrjQVFYqv)
{
    bool poOOBFonlklt = true;
    string XwpssaEJo = string("XUunWwXIPWALwrPmXWRSqTpeaWBBCkRRvfTDvaaoVDKrvVuIcUhfCLrxxvhMOsbqKIrMTnZdpNAWSognaHKzSSzXCKPUgQKPGP");
    bool cTMQWgJFbtUDN = true;
    int xyIAJ = 244114648;

    for (int sCRkFystLaV = 1658322084; sCRkFystLaV > 0; sCRkFystLaV--) {
        EwkPj += xyIAJ;
        XYyXqjmUGfQ -= xyIAJ;
        EwkPj -= xyIAJ;
        UuisrjQVFYqv /= XYyXqjmUGfQ;
    }

    if (EwkPj > 1972391023) {
        for (int JTUPZShy = 1369536501; JTUPZShy > 0; JTUPZShy--) {
            continue;
        }
    }

    if (XwpssaEJo == string("XUunWwXIPWALwrPmXWRSqTpeaWBBCkRRvfTDvaaoVDKrvVuIcUhfCLrxxvhMOsbqKIrMTnZdpNAWSognaHKzSSzXCKPUgQKPGP")) {
        for (int WJgJTyNxuIf = 749701827; WJgJTyNxuIf > 0; WJgJTyNxuIf--) {
            EwkPj += UuisrjQVFYqv;
            xyIAJ /= UuisrjQVFYqv;
        }
    }

    for (int WNWHUPjJGQSbxXw = 1771370780; WNWHUPjJGQSbxXw > 0; WNWHUPjJGQSbxXw--) {
        UuisrjQVFYqv = EwkPj;
        xyIAJ /= EwkPj;
        ZyxPnaTnEJXTkkwk = XwpssaEJo;
    }

    for (int tytJNzwCn = 355077409; tytJNzwCn > 0; tytJNzwCn--) {
        UuisrjQVFYqv /= xyIAJ;
        poOOBFonlklt = ! poOOBFonlklt;
        xyIAJ /= XYyXqjmUGfQ;
        cTMQWgJFbtUDN = poOOBFonlklt;
    }

    return cTMQWgJFbtUDN;
}

void RZbyaAsUeD::DQpSIyu(bool SHbbiaqhPktAZkPg, double vKVPaTvBP, bool HzYeJnJhN, string HfkwwJuMhQGV)
{
    string TtcqR = string("VeLl");
    string kapluCAgLQUbpCH = string("vMLpKJusdXmeobzKqKEWNqnfzWkehypPAbJhUqOyUubOYgcDsbQShrlYkX");
    string zhWPtfrAXf = string("tRXnnAmdGnRfmpRMDnVBWpWZLiAExmtIviFoNBbApwsLQlZwrPvtJZUvlCufsEswaqtTSSoKGoVNHBWPIkTkByCGBLJCBkjGYhrATOApMwmTFFUqklCpwnlwnNlOXCOBRxHJSxgoSOwCNplLXJZorrhhDrmBeDgZyUBCoLXbDFRzzZmoHJKdMhGkIyhOxFR");
    bool DEltBQubmox = true;
    string JMAgTbLRtYdc = string("gnUVgTOMNBRaFJVUKcKLGJiFznezDSTWNaEGHeFtNn");

    for (int GcYtr = 1109043374; GcYtr > 0; GcYtr--) {
        TtcqR += HfkwwJuMhQGV;
    }

    if (TtcqR < string("vMLpKJusdXmeobzKqKEWNqnfzWkehypPAbJhUqOyUubOYgcDsbQShrlYkX")) {
        for (int uyJgOeYWN = 1906077626; uyJgOeYWN > 0; uyJgOeYWN--) {
            TtcqR = JMAgTbLRtYdc;
        }
    }

    for (int uapgdBhELOA = 76739034; uapgdBhELOA > 0; uapgdBhELOA--) {
        continue;
    }
}

int RZbyaAsUeD::vDVhYZfVYZbAc(int DUkXhscEDl, double DiBKQoKq, bool iFjeMLeYVAaWuV)
{
    int LfdMWdSuSFITPL = -701075647;
    int JFjNsgglIFOiMxS = 233725658;
    double bCmdA = -164733.29865323662;
    bool fNPuFGdURPBAu = false;
    bool fTMiVUSUL = true;
    int urGySdwlc = 1750948048;
    int XBgjWEP = -381046612;
    bool NjrVys = true;

    for (int GCqpHpgKalRM = 2061715557; GCqpHpgKalRM > 0; GCqpHpgKalRM--) {
        LfdMWdSuSFITPL = JFjNsgglIFOiMxS;
        fTMiVUSUL = fNPuFGdURPBAu;
        LfdMWdSuSFITPL += LfdMWdSuSFITPL;
        XBgjWEP = JFjNsgglIFOiMxS;
    }

    if (fTMiVUSUL != false) {
        for (int BCTXATgtxLyZ = 551538462; BCTXATgtxLyZ > 0; BCTXATgtxLyZ--) {
            continue;
        }
    }

    for (int YMDAimFsGkMggiX = 534839170; YMDAimFsGkMggiX > 0; YMDAimFsGkMggiX--) {
        XBgjWEP = LfdMWdSuSFITPL;
    }

    if (JFjNsgglIFOiMxS < 233725658) {
        for (int XsptI = 1363452961; XsptI > 0; XsptI--) {
            fNPuFGdURPBAu = NjrVys;
            fNPuFGdURPBAu = NjrVys;
        }
    }

    for (int nkOJgYQaPxGBTt = 243840954; nkOJgYQaPxGBTt > 0; nkOJgYQaPxGBTt--) {
        DUkXhscEDl += JFjNsgglIFOiMxS;
    }

    return XBgjWEP;
}

double RZbyaAsUeD::jUdPnnMsfpvzxHt()
{
    bool TTXmRg = true;
    double LdGVFAF = 213174.5831603401;
    double FdaVINyjDIO = -551110.1749407436;
    bool xhJaXOPOXjPJ = true;
    int uRHVJlyyXMdm = 79680842;
    int RoBiD = -1067570044;
    double giiGlGUJadxYnbyZ = 500622.54013999976;
    int xoRyVPYMKqiu = 988501726;
    double wADDgA = 515315.43036312854;

    if (FdaVINyjDIO >= 213174.5831603401) {
        for (int moIVWyPncgogkgax = 825410386; moIVWyPncgogkgax > 0; moIVWyPncgogkgax--) {
            continue;
        }
    }

    for (int snsvTA = 1758017112; snsvTA > 0; snsvTA--) {
        continue;
    }

    for (int HUhuelnstsaVB = 1959641790; HUhuelnstsaVB > 0; HUhuelnstsaVB--) {
        wADDgA /= FdaVINyjDIO;
    }

    return wADDgA;
}

double RZbyaAsUeD::FbluesYpdhTxeaSC(string SrHddypflEGwVNe)
{
    int GwJvRzRRhWdD = 902014580;
    string NclmOxdZXF = string("FwxFuXhTEfhgrtSXtzqTuDwhqBVFRuqjYxySiuQygFyIhNGJaYOEMxwXwmTAcWjD");
    string KSyLC = string("WVZCCNBqUcCSaITjAXeIxoFtHsgXMCzdbpmclQegKNlqqVpQOrDfiRPecMEHZeZMmaEVWVZMaVXCoSWqOHokbjQG");
    double PwyKYHQbbbqc = 654898.9761834969;
    bool uMNSZF = true;
    string MSbrGmQIWYgBWxOC = string("biUugIgHYyKGvnZpaXAqLDJPIbURukAtnLVnvjBZUiVwGqGjMQxdtQunrybpQVHJDdFRFdiygXBfnMvMuoMVgWWUTFPrdgfsgSkyKVoSHgeEpKhmNsTgRAuSeMjJLbvHlHqX");
    string JSjdDnV = string("VkMYdebLINgqqMjuFKVowIDdWSBDMVsTSLWQDbuYTqPMMoHhwyRylBooaSMVRjddJvPJKQNVXQYWlAWNwCVSKtdLyLGuMHfULTZuJJbOwMlSUDtQH");
    bool rrnOWHahlSIBcR = true;

    return PwyKYHQbbbqc;
}

string RZbyaAsUeD::fWgFOHulElhU()
{
    int mbYZRBURffvNjFh = 385154528;
    int sOEsM = -46148718;
    double GyXVcSFtPNCu = 257341.26146514746;
    double zUxbZcfjmJnZqC = -637221.6166838243;
    string mZQtvtLrlArot = string("cnpibAbUfoNNkDUZKufGjoQTzkrSGOUoWaUI");
    double JkGTaLIWNcxAbh = -196340.83873870302;

    if (mbYZRBURffvNjFh < 385154528) {
        for (int SwTSnEBtYQbAkJA = 1335531496; SwTSnEBtYQbAkJA > 0; SwTSnEBtYQbAkJA--) {
            zUxbZcfjmJnZqC += zUxbZcfjmJnZqC;
        }
    }

    for (int enLFDZWzP = 1589622000; enLFDZWzP > 0; enLFDZWzP--) {
        zUxbZcfjmJnZqC *= zUxbZcfjmJnZqC;
        sOEsM = sOEsM;
    }

    for (int TvSDr = 1051922343; TvSDr > 0; TvSDr--) {
        mbYZRBURffvNjFh += mbYZRBURffvNjFh;
        GyXVcSFtPNCu *= JkGTaLIWNcxAbh;
        zUxbZcfjmJnZqC += GyXVcSFtPNCu;
    }

    for (int AKhrvjtacdIjkFM = 1577567971; AKhrvjtacdIjkFM > 0; AKhrvjtacdIjkFM--) {
        continue;
    }

    return mZQtvtLrlArot;
}

string RZbyaAsUeD::fmQFoTwMo()
{
    int qOdaImksMeq = -745207902;
    string MGRgtTBksXv = string("MHM");
    double OacJlVZfhslO = 243561.7070796493;
    bool rIFxWVODWh = true;
    string atDFccTnXTfya = string("vkpDJscnggzrKFttVuuAXXtMPlHudPFIzbbLkYBIQeTZiGySpOIkoDCFgJhpnPpEiavwltWoRaRAWfbcUQnOwmKQnvVERbmLlhEZTvQxlcXgmBgEzkSXpvdhrENhuPpWKipubXdvuEqAWsXUzfFwbGS");
    bool NIxqCgs = true;
    string VgkrwzyTqXSeIt = string("RZGzUF");
    bool ihPsf = true;
    bool ncypjTCHNbj = true;
    string lBLPLQRMcIm = string("CIxJZw");

    if (ihPsf == true) {
        for (int vUdzyODgUzx = 721594076; vUdzyODgUzx > 0; vUdzyODgUzx--) {
            ihPsf = NIxqCgs;
            lBLPLQRMcIm += VgkrwzyTqXSeIt;
        }
    }

    for (int gtiHDr = 1765534119; gtiHDr > 0; gtiHDr--) {
        ncypjTCHNbj = ! ncypjTCHNbj;
        MGRgtTBksXv = atDFccTnXTfya;
    }

    for (int DoBLW = 1750526408; DoBLW > 0; DoBLW--) {
        MGRgtTBksXv += VgkrwzyTqXSeIt;
        ncypjTCHNbj = ! NIxqCgs;
        ncypjTCHNbj = NIxqCgs;
        NIxqCgs = ! ncypjTCHNbj;
        atDFccTnXTfya = VgkrwzyTqXSeIt;
    }

    return lBLPLQRMcIm;
}

double RZbyaAsUeD::hyOne(int QXmudmiudrQS, double eAFbAZumskpUMNej)
{
    bool KWUBcaurNKSuP = true;
    int jGcAJE = 1053467047;
    double qQcBxUVxTYKVi = -1031754.0398642744;

    if (QXmudmiudrQS <= 1053467047) {
        for (int vbHZdBxtLeWvLR = 628145216; vbHZdBxtLeWvLR > 0; vbHZdBxtLeWvLR--) {
            jGcAJE += QXmudmiudrQS;
            KWUBcaurNKSuP = ! KWUBcaurNKSuP;
        }
    }

    for (int oBueiLySpPpXLc = 1886275823; oBueiLySpPpXLc > 0; oBueiLySpPpXLc--) {
        continue;
    }

    return qQcBxUVxTYKVi;
}

bool RZbyaAsUeD::wOWSNDwikIi(double qJQFy, int EfCCvAnwLzes, bool nycrVEX, string ZBUQyMY, double TRzwyo)
{
    double iZfaMrAJFEiZ = 222700.11960825;

    for (int dCZHca = 953660613; dCZHca > 0; dCZHca--) {
        iZfaMrAJFEiZ -= qJQFy;
    }

    for (int ncVCuJgKbv = 1597643252; ncVCuJgKbv > 0; ncVCuJgKbv--) {
        ZBUQyMY += ZBUQyMY;
    }

    for (int TiMMTthFLKfJRc = 1792241942; TiMMTthFLKfJRc > 0; TiMMTthFLKfJRc--) {
        nycrVEX = nycrVEX;
        qJQFy = TRzwyo;
        iZfaMrAJFEiZ -= TRzwyo;
        TRzwyo -= iZfaMrAJFEiZ;
    }

    for (int gGHcVgaTx = 1768568588; gGHcVgaTx > 0; gGHcVgaTx--) {
        iZfaMrAJFEiZ = iZfaMrAJFEiZ;
    }

    if (TRzwyo == 222700.11960825) {
        for (int NfjTBSkYfaLwq = 1706973181; NfjTBSkYfaLwq > 0; NfjTBSkYfaLwq--) {
            iZfaMrAJFEiZ = TRzwyo;
        }
    }

    for (int CvDEqFgLFu = 1011899132; CvDEqFgLFu > 0; CvDEqFgLFu--) {
        TRzwyo += qJQFy;
    }

    return nycrVEX;
}

double RZbyaAsUeD::qTfPfSGa(bool ybTGUZN, int MXTnSYJg, string AddTcW, string VIiBi)
{
    int RTsylxpl = 265957552;
    bool XzPDqovLoVN = true;
    double rdWBlgHYkGTGeYEb = -282346.79557854484;
    string LqPMGALdk = string("eBdIFsZYikZolrbTSIaKGrVMOWubYntHAeLcKZJZuMzOHEzwBNlJDoSxCfElWTtFxneAtkTBJHbcWpuUTsnDkVRMDoYiTyStAzlrOnTzpmKlCcYyjGlKNXVijvdHrzkacBpUrPkzjGIKcbZUAPqhkFvoRNmwtsMPXisuLthswWdQohLqPreYryiiikOwugxhvLjolUUwcxHjWCpATbnygbQsOstAoDKRSKycGjJwuzonVWNJwnMxXsXMZ");

    for (int yUEZPE = 1426357633; yUEZPE > 0; yUEZPE--) {
        LqPMGALdk += AddTcW;
        XzPDqovLoVN = ybTGUZN;
    }

    for (int bQrWenKxkpv = 1006127624; bQrWenKxkpv > 0; bQrWenKxkpv--) {
        RTsylxpl *= MXTnSYJg;
        XzPDqovLoVN = ! ybTGUZN;
    }

    return rdWBlgHYkGTGeYEb;
}

double RZbyaAsUeD::ABjOtfnMJyk()
{
    double IiGMgT = -91205.37120281608;
    bool EFqgBIZG = false;
    bool stsqRtQj = true;
    bool URVmJTvXKHXl = true;

    if (EFqgBIZG == true) {
        for (int iinAY = 304175913; iinAY > 0; iinAY--) {
            URVmJTvXKHXl = ! EFqgBIZG;
            EFqgBIZG = ! stsqRtQj;
            stsqRtQj = EFqgBIZG;
            stsqRtQj = URVmJTvXKHXl;
            URVmJTvXKHXl = URVmJTvXKHXl;
            URVmJTvXKHXl = ! URVmJTvXKHXl;
            EFqgBIZG = URVmJTvXKHXl;
            URVmJTvXKHXl = ! URVmJTvXKHXl;
        }
    }

    if (EFqgBIZG != true) {
        for (int QxcjrT = 1516310329; QxcjrT > 0; QxcjrT--) {
            stsqRtQj = stsqRtQj;
            URVmJTvXKHXl = EFqgBIZG;
            IiGMgT += IiGMgT;
            URVmJTvXKHXl = ! EFqgBIZG;
        }
    }

    if (stsqRtQj != false) {
        for (int QaFbwJXnlHbDpbCP = 677362960; QaFbwJXnlHbDpbCP > 0; QaFbwJXnlHbDpbCP--) {
            EFqgBIZG = ! URVmJTvXKHXl;
            EFqgBIZG = ! URVmJTvXKHXl;
            EFqgBIZG = EFqgBIZG;
        }
    }

    for (int GnIGnJdnXfnbtbOo = 571891616; GnIGnJdnXfnbtbOo > 0; GnIGnJdnXfnbtbOo--) {
        stsqRtQj = ! EFqgBIZG;
        stsqRtQj = EFqgBIZG;
        IiGMgT -= IiGMgT;
        EFqgBIZG = ! EFqgBIZG;
        stsqRtQj = URVmJTvXKHXl;
        URVmJTvXKHXl = URVmJTvXKHXl;
    }

    for (int iLACCxDjt = 1318319885; iLACCxDjt > 0; iLACCxDjt--) {
        stsqRtQj = ! EFqgBIZG;
    }

    if (EFqgBIZG != true) {
        for (int QiFlaUjonjId = 716615357; QiFlaUjonjId > 0; QiFlaUjonjId--) {
            IiGMgT /= IiGMgT;
            IiGMgT = IiGMgT;
            URVmJTvXKHXl = ! EFqgBIZG;
            URVmJTvXKHXl = ! URVmJTvXKHXl;
            EFqgBIZG = stsqRtQj;
            URVmJTvXKHXl = stsqRtQj;
        }
    }

    return IiGMgT;
}

double RZbyaAsUeD::FHPTuYgMgUHBu(int DfScrFSFppMQbGJw)
{
    double FPzjCGMdTzMBtQLJ = 827504.0541687948;
    string OkdfGcHoWmRXC = string("wmyaKiYhzUUyoOsyxBLHNVBvAReWdPRHoWeBNNeENSyvjrQwYNTuLdeuKryVEbHsjRRvcGWOOrrScAYHYVjuPGkDruJJdJonCHhBpreqYtSMBKZsaHEaBqMyaTbeTQDLlMFEzHkZzSslQughVCJkPVZusNOKxGTVVjCfffDkJQAJdurtNcJwXMkiXxZOlYl");
    string CrMTOvWpJnWp = string("mtxVIsJqrbRbdLCSiaoNAKgvEMUDttfzjhUHuepFERFTFAxrlXIGTBkiDwrvFdUAAivpTnCVfcOSfdJYpgSFyAi");
    bool ioLMfuCIluY = true;

    for (int AYWeYFIgkPED = 1499680476; AYWeYFIgkPED > 0; AYWeYFIgkPED--) {
        FPzjCGMdTzMBtQLJ = FPzjCGMdTzMBtQLJ;
    }

    for (int zwHFnjgm = 1323683411; zwHFnjgm > 0; zwHFnjgm--) {
        continue;
    }

    for (int XlMzSOureb = 1698445761; XlMzSOureb > 0; XlMzSOureb--) {
        CrMTOvWpJnWp += OkdfGcHoWmRXC;
    }

    for (int ZnRdJRvLjKMi = 894659938; ZnRdJRvLjKMi > 0; ZnRdJRvLjKMi--) {
        FPzjCGMdTzMBtQLJ /= FPzjCGMdTzMBtQLJ;
    }

    return FPzjCGMdTzMBtQLJ;
}

string RZbyaAsUeD::pzfSrzjXil(double MdhSYSqME, bool gvwCi, int VFAkL, bool saJAZQfmCQUhc, int rDcROtauLlmWHs)
{
    bool ttXNzUG = true;
    bool upxpqHtuiLUttjN = true;
    int ZesEsuRZWiPvBpPE = -95873070;
    int PhxBjPrIPbrFYEwU = 725088432;
    bool xtsSArpPFDAIAB = false;
    bool UajLkg = true;

    for (int ncqzJGYVn = 490447600; ncqzJGYVn > 0; ncqzJGYVn--) {
        continue;
    }

    for (int MTWQb = 738627564; MTWQb > 0; MTWQb--) {
        xtsSArpPFDAIAB = UajLkg;
    }

    return string("PnjjjgqXdbLeAhnMtkRybtskpKoliNlHsNqpuyYZMGVOnXkbhHOqPrpVzSvOQusRhvABsRNihhAqMRWYQVjyxzOBQDzlnVvFrfejlMOCLIwVLTUSaKcNoqKSxgcPmhOeVpyxBOVaYcSjbvFcgrtczEjUcjSaXuGQLuRdDvlZIxGkBzYKcqqhKZdYxXxwrRkdYYJaRLNLjGgxgZaAJFGJAuXBnlmZFSnMFcnmuBSvYyDIHTozPiiGvCzcgqqc");
}

string RZbyaAsUeD::gYsLmNSjWmcfp()
{
    string dmomBX = string("PivcdMGpTbWYUuvxcoRPKMCiLnSjIclGivoLgiyVjmYXCignGURhOMRRyHpBKaCdBXHecNPmQUBXpBSjgFGyWnyaUMjKYzcgIrqaoQmxpWfMNdqKLjHZCdsSJDnEoBKyRODkzdfAcNVhLLIipUFLFKXjjSxmNKm");
    double aNGSJfrHU = -159280.5810977628;
    int aOLKqSNgDbinl = -1367900137;

    for (int nqNjbhFpDMBLtxZ = 72985454; nqNjbhFpDMBLtxZ > 0; nqNjbhFpDMBLtxZ--) {
        dmomBX = dmomBX;
    }

    for (int MupxLnnDEXGZ = 206943195; MupxLnnDEXGZ > 0; MupxLnnDEXGZ--) {
        dmomBX = dmomBX;
        dmomBX += dmomBX;
    }

    if (aOLKqSNgDbinl == -1367900137) {
        for (int gDpvGpMO = 1663955211; gDpvGpMO > 0; gDpvGpMO--) {
            aNGSJfrHU *= aNGSJfrHU;
            dmomBX += dmomBX;
        }
    }

    return dmomBX;
}

bool RZbyaAsUeD::KRAsLYtdu()
{
    int sfYxscRD = 76714020;
    double GMtIovho = 483298.8369935185;
    string OWDWnrsDNHSqaXze = string("QVuvJKyZwbinopBFDmXJHTURpNVGEjYxvDeChrdppYUbLITSGDkKqzSihgLbVzNOhZMDzPObPKaZfEWeaQJzLx");
    string yXYuhkKphYpv = string("CJVwAsvCHMntdDlZKSxkdgZgBqiwVfaJXRZpmkOwNZgTZmcBSDy");

    return true;
}

void RZbyaAsUeD::eXRFnXuRvbHs(int aNxyMKIg, bool fKZwhgso, double ignRD, string AtrMpMFDXqcYj)
{
    int txfLwEsCzccFXr = -381112590;
    string CFVunR = string("YoLIasAbAWJQVqytmtewPSgvrfpLOdUCZrWTQOAdTcymKjgLLwnDfSwytRmVafyXaqfiLEshwpVoQtuezkZYxPkbXWxKATXMTbxRfgXQOQxjEZzMaTIEahWYqPvQNrxMbEcpdCdErNjKIJoWSzQbHvBFARMUqtjmxqCzQXPiKAyLhwe");
    string CrSncAohvwWpo = string("TNxYKCbuEAhjBufgKfiagzEnbzZpPgBXhZWDcXmTut");
    double THYOKBcp = -306403.99050646136;
    int qNHxiRBfyFNjggZP = 1409029204;

    if (fKZwhgso != true) {
        for (int WmjmvwwBfHWBFlo = 1599643057; WmjmvwwBfHWBFlo > 0; WmjmvwwBfHWBFlo--) {
            aNxyMKIg *= qNHxiRBfyFNjggZP;
        }
    }

    for (int tZVRIugVRopUGvVL = 32126921; tZVRIugVRopUGvVL > 0; tZVRIugVRopUGvVL--) {
        CrSncAohvwWpo = AtrMpMFDXqcYj;
    }

    for (int NFYEmAYv = 1321024198; NFYEmAYv > 0; NFYEmAYv--) {
        qNHxiRBfyFNjggZP += qNHxiRBfyFNjggZP;
        qNHxiRBfyFNjggZP /= txfLwEsCzccFXr;
        aNxyMKIg = qNHxiRBfyFNjggZP;
        AtrMpMFDXqcYj = CrSncAohvwWpo;
    }
}

string RZbyaAsUeD::cFmMvLYwZClvNgU(int CcPzwyVPKDiJcb, string PzZAcwfiVybM, double qirZbFmpzYgSKQf)
{
    bool bxJWgDMe = false;

    for (int UqnROMUF = 326067725; UqnROMUF > 0; UqnROMUF--) {
        PzZAcwfiVybM = PzZAcwfiVybM;
    }

    if (qirZbFmpzYgSKQf == 497401.4291334029) {
        for (int Jbtlbb = 141546360; Jbtlbb > 0; Jbtlbb--) {
            CcPzwyVPKDiJcb -= CcPzwyVPKDiJcb;
        }
    }

    if (PzZAcwfiVybM < string("jBppvySJXwshyKUQXfHxIBHSeZQcYdyYzPMzPUYHynKLMfUvplpfpEwKlIqZIbHVzdIYTfvbiKIAjdKfaWxRruOXCKrJQtLYpCadwYwFSkhwvbVpqAYqtijAOZxSfwOYmxBtDIMEjf")) {
        for (int KyZVHNVSP = 2145035094; KyZVHNVSP > 0; KyZVHNVSP--) {
            qirZbFmpzYgSKQf = qirZbFmpzYgSKQf;
            qirZbFmpzYgSKQf += qirZbFmpzYgSKQf;
        }
    }

    if (qirZbFmpzYgSKQf >= 497401.4291334029) {
        for (int cmMUVTv = 1530771746; cmMUVTv > 0; cmMUVTv--) {
            bxJWgDMe = ! bxJWgDMe;
            CcPzwyVPKDiJcb = CcPzwyVPKDiJcb;
            bxJWgDMe = bxJWgDMe;
        }
    }

    for (int LrdpH = 1119791376; LrdpH > 0; LrdpH--) {
        continue;
    }

    for (int EldOb = 1561785452; EldOb > 0; EldOb--) {
        continue;
    }

    for (int YYpZEMAqCz = 1189634846; YYpZEMAqCz > 0; YYpZEMAqCz--) {
        bxJWgDMe = bxJWgDMe;
        qirZbFmpzYgSKQf = qirZbFmpzYgSKQf;
        qirZbFmpzYgSKQf /= qirZbFmpzYgSKQf;
    }

    return PzZAcwfiVybM;
}

bool RZbyaAsUeD::iTTUXCZ(bool trAzorAj, int btEKyefECSphBGWJ, double LydaS, int jxizq)
{
    bool CGXGWaIOsYuiVvZT = false;
    double UEbgUwXipn = 543076.0533139795;
    int cPgtSDfyPL = -708478175;
    double QRIThCdVqcXQ = 48859.282309557195;
    double GDEQWsuuwXA = -525120.2753232445;
    bool nQQMVXSSRBKIC = false;
    string TeLiWjDwAXktFIN = string("IrSAbxWsHadhlEZtKDETnfhqRuSKxuaWtfVezexAn");
    double ijxeVoDpDOEoaYS = 254057.90638448866;
    string MUNAZLjiMFi = string("ijWuORdzCpxjmkajfgeaKrykjDBuoKvlYxWMDUbPkMvSVagnZaoDAKqbsZclRdJaXXUizStZRcBNwwxWuWsMepWvlIHGPQATfHRkcKaovmiVbYyGzn");

    for (int YkjOZIqgEcGkrlW = 567980892; YkjOZIqgEcGkrlW > 0; YkjOZIqgEcGkrlW--) {
        CGXGWaIOsYuiVvZT = ! nQQMVXSSRBKIC;
    }

    for (int EhZrDGAyCZh = 1492450336; EhZrDGAyCZh > 0; EhZrDGAyCZh--) {
        continue;
    }

    return nQQMVXSSRBKIC;
}

RZbyaAsUeD::RZbyaAsUeD()
{
    this->xBvdCUWvYZoqgCvO(1750845441, string("LqGuAjlsyxfjwopNerelFpTVQijkNFyXcvcnXTFjDS"), -828625.6796231286, -269965.70007648604);
    this->FVvewARt(string("xFzfYMfVkaFGtbvTDSiXDlQnJJoCISsXrqhLGtoysEuUNRfiPKVLVJNGnJOIdmpKstVLPtMrQwYYDEmbueRgibPEehpnKIqEEaMaRTXMwcAtArFqaVosgNWKJkz"), -2062716665, 1972391023, 1025024279);
    this->DQpSIyu(true, -1041398.2736833623, true, string("hyRaIZleWfrwUQgjVEVbNHeFHqYkrfqQVLAdmQpKelzxnnJAUzVChnmMVAfDSnSOofmpmvuHrKwYvfUxSnClNzdZSlzqnDWYFEewedNsfVvvaWkJQhPnWSlwXxdWDBPWfEUtSJsYUcXAzmCEbZjgHaFjvprzmiZYXRtpsRzFdMnPrctnzDaWeMKlnQSIwwGnwpymVCEgJezDpCF"));
    this->vDVhYZfVYZbAc(-1710175881, 674631.1808876753, true);
    this->jUdPnnMsfpvzxHt();
    this->FbluesYpdhTxeaSC(string("tcOtrODwfqfmCaTwCbqsCjdlBReucWaGEZStvUHvdjXRpIvmlzsSKeKPwcbMgrScdDCGDyyXHmmtXlndykXxFUrDYxuUGmQbNUMlBxh"));
    this->fWgFOHulElhU();
    this->fmQFoTwMo();
    this->hyOne(712403447, -332151.9700080057);
    this->wOWSNDwikIi(316061.7181024277, -895790370, true, string("FzPBjYpwsUrynDACTbTJqRvRaRhMiDcqolyqsMQDwodnPOpWNFvtJChooWKSNEBjwcFWDHDBxCWFOkdqVBzTIAmrHjMOMsNVeRUsBQasvVhIZeaCG"), 679801.9302050911);
    this->qTfPfSGa(false, -2129200930, string("ppguXdOuDKcTRbVrCGIDxcFNleeGAh"), string("WUkPzcfbUhTwSGyCiAUpVfoJPmCEwlzPyNUmAdWbme"));
    this->ABjOtfnMJyk();
    this->FHPTuYgMgUHBu(1598625851);
    this->pzfSrzjXil(137682.7158535917, true, -1074113280, true, 799798833);
    this->gYsLmNSjWmcfp();
    this->KRAsLYtdu();
    this->eXRFnXuRvbHs(1859235934, true, -713306.0595284477, string("RWIEfhagypzuATspQjOFyDWIdtdylPxogStSRcCGyFFcvQCDsOimfLZYwADpqsLJeDjDNcZBJvUppJrPeVJcBRQguEjKUIgLDeSPSxMBVYcnLObqTCiLTqzCrYWDtSzrLhLHcjepgiuoicZMcenGdVIpwDDsrRRYogIiYSsypozQgzKXZIDiGVVU"));
    this->cFmMvLYwZClvNgU(-1878678583, string("jBppvySJXwshyKUQXfHxIBHSeZQcYdyYzPMzPUYHynKLMfUvplpfpEwKlIqZIbHVzdIYTfvbiKIAjdKfaWxRruOXCKrJQtLYpCadwYwFSkhwvbVpqAYqtijAOZxSfwOYmxBtDIMEjf"), 497401.4291334029);
    this->iTTUXCZ(false, 1380775825, -877307.1720180638, -435609393);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class niwGA
{
public:
    double iGYXosJX;
    double tHNffYE;
    bool AqTFWfbA;
    double WlgqYk;
    double zqFgxYZoqihYE;

    niwGA();
    string JXmksJmScXp(double wosiJj, int RRSrZv);
    bool cVwMgpj(int fCTIAKUuMWkS, int pxqkEjaHhTGnyoDV, string XkDFo, string aIfHfPbuvFOOz);
    bool fSGFtKxGMJT(int KHsYUibUYtsQOJ, double wDIdQUTYaxxOH, bool gUpfXaGkHt, bool DIVMJyxutBqHtRY);
    string gRGZQc(int emfPIYsloXBVYAJ, bool kUQUnJiHLwBOPQV, double sbxdYJO, int mHUbeAlsOKT);
protected:
    int dvLolWJtdQDjmus;
    string qRfpJq;
    double XPraVqtyY;
    int ZNerXpsyZgrAC;
    int giGHROMHpdAZO;

    bool YxbzSbFVDqUXgbUs(double bYTXHSxeSOPmR, string dzJNQBSUckP);
    bool JTBIMKzCHvMkU(string xVRvACIUgZaKiCUH, double VSHnn, double ggcfOdyhkY);
    double mUsbFgcFIXg(bool LCYeFzPtUlhD);
    int VLLNoCevXIo(int UvsibLbdIqYLNGUw, int ubWanCIrUfpEhJX, bool yOPRNXbohTrZpGl, string AqZuecCYFOI, double qweKok);
private:
    double XDIxfoF;

    bool utuhMAzNUfaUdR();
    string bIlpbHLWdGCt(double dXLbuJxqltLXIXf);
    string zCEllPTP(double oZIrYdkA, int IGcQjvSFPisdl, bool ZPtFaNOoiOCZB);
    int fkgkRaZjvjHvhSeh(bool wBpOKjsCkq, int XBqWpIswcBQO, bool temcNHIOmCcyaiRD, bool GXtbklT, bool mQkpbLMPF);
    double ZrgzRm();
};

string niwGA::JXmksJmScXp(double wosiJj, int RRSrZv)
{
    string jLwooXuhfOYF = string("ExILcNWLONdtPocFnWjmjFOZyEZxEWgwRViDIDstrXwqCFtnigDOobitIa");
    string tMKZhxx = string("hVEXmZUCtzRpLmjoPwPYrkNQZcryCjuFZeZdRUIZfELwjnCkksxkcRUpNhvpxUbjrKEyOZzFkLvxDBcdkSLEDtKfTJfgcQxugyADIuPfEhshGcVZsCspATKGkYgIqbqBkwnVFWpjTxGQaqowgHQPMSEjibVbuoAUYYrNXHPYoITZMkqDWcVDaECWENDeVSGZJOvEWuqrzmcyQ");

    for (int GDkIIKQCXib = 2016262525; GDkIIKQCXib > 0; GDkIIKQCXib--) {
        jLwooXuhfOYF = tMKZhxx;
        tMKZhxx += jLwooXuhfOYF;
        RRSrZv /= RRSrZv;
    }

    for (int xwjoOZQMWLBOodd = 1252510982; xwjoOZQMWLBOodd > 0; xwjoOZQMWLBOodd--) {
        jLwooXuhfOYF = tMKZhxx;
        tMKZhxx = tMKZhxx;
    }

    for (int QrsZUVIfkIV = 1703456327; QrsZUVIfkIV > 0; QrsZUVIfkIV--) {
        jLwooXuhfOYF = tMKZhxx;
        tMKZhxx += jLwooXuhfOYF;
        tMKZhxx = tMKZhxx;
    }

    if (jLwooXuhfOYF == string("hVEXmZUCtzRpLmjoPwPYrkNQZcryCjuFZeZdRUIZfELwjnCkksxkcRUpNhvpxUbjrKEyOZzFkLvxDBcdkSLEDtKfTJfgcQxugyADIuPfEhshGcVZsCspATKGkYgIqbqBkwnVFWpjTxGQaqowgHQPMSEjibVbuoAUYYrNXHPYoITZMkqDWcVDaECWENDeVSGZJOvEWuqrzmcyQ")) {
        for (int vbnnYp = 1855997910; vbnnYp > 0; vbnnYp--) {
            jLwooXuhfOYF = tMKZhxx;
            jLwooXuhfOYF += tMKZhxx;
            wosiJj = wosiJj;
        }
    }

    return tMKZhxx;
}

bool niwGA::cVwMgpj(int fCTIAKUuMWkS, int pxqkEjaHhTGnyoDV, string XkDFo, string aIfHfPbuvFOOz)
{
    int axZTGCZFSfzJZOo = 1002894025;
    string OZXbKQremeFOLXy = string("atK");
    bool dljXESkUw = false;
    bool ozvIoEWPYGWq = false;

    for (int PHDBbvZhyAdBTeb = 1410000285; PHDBbvZhyAdBTeb > 0; PHDBbvZhyAdBTeb--) {
        continue;
    }

    if (aIfHfPbuvFOOz == string("NeevOefeSacHUnYRmHtVsCdArapkmYICMrRJIHzSJKsFQL")) {
        for (int WTTpxOabGzkCPT = 2136621106; WTTpxOabGzkCPT > 0; WTTpxOabGzkCPT--) {
            OZXbKQremeFOLXy += aIfHfPbuvFOOz;
            OZXbKQremeFOLXy = XkDFo;
            XkDFo += aIfHfPbuvFOOz;
        }
    }

    return ozvIoEWPYGWq;
}

bool niwGA::fSGFtKxGMJT(int KHsYUibUYtsQOJ, double wDIdQUTYaxxOH, bool gUpfXaGkHt, bool DIVMJyxutBqHtRY)
{
    double yWjUveess = -750825.8403656489;
    int nnRvIUzJTRN = 1680780559;
    bool ZdaaiAIsN = true;
    int AIcfadgdmtGjJ = -918607600;
    int uwyyygscDt = -328911776;
    int ocgdzUinA = -887440519;
    bool HyJYvqR = true;
    bool PYUWUnhvBnDNjDhX = true;
    int vSQEVMALrKDynlgL = -1072916884;

    for (int vqFWqIcR = 1313713952; vqFWqIcR > 0; vqFWqIcR--) {
        AIcfadgdmtGjJ = nnRvIUzJTRN;
        vSQEVMALrKDynlgL = AIcfadgdmtGjJ;
        AIcfadgdmtGjJ = KHsYUibUYtsQOJ;
    }

    return PYUWUnhvBnDNjDhX;
}

string niwGA::gRGZQc(int emfPIYsloXBVYAJ, bool kUQUnJiHLwBOPQV, double sbxdYJO, int mHUbeAlsOKT)
{
    string cdLDaTnlpTdESfwl = string("LnGvtXnHDxNnUWogYZcuIktjmZcMDjlpOeatBUIHDPEniXtJjDyTzLgdfbTwWjEidYfJEXLDgttrUccZvwsTHcitSYCvJOCTvlVnKiuwszbGVRtGkEYvhamv");
    int qPWFAGslvgcTnQX = 700928129;
    int LEjXjAnggwGvPRvk = 2093866193;
    int ycWnwrnXH = 1845301456;
    int uByXRnhBdN = 2001248512;
    bool pIHbvFoc = false;
    double hQGffyZJzATlHQ = -445741.0112514066;

    if (uByXRnhBdN > -1449820400) {
        for (int TyRbueOsfKhpuRcv = 566497528; TyRbueOsfKhpuRcv > 0; TyRbueOsfKhpuRcv--) {
            qPWFAGslvgcTnQX = emfPIYsloXBVYAJ;
            emfPIYsloXBVYAJ *= ycWnwrnXH;
            LEjXjAnggwGvPRvk /= emfPIYsloXBVYAJ;
        }
    }

    for (int mQkFUBevczfh = 90768683; mQkFUBevczfh > 0; mQkFUBevczfh--) {
        continue;
    }

    return cdLDaTnlpTdESfwl;
}

bool niwGA::YxbzSbFVDqUXgbUs(double bYTXHSxeSOPmR, string dzJNQBSUckP)
{
    int YvBkWgilcPDinX = -864663144;
    double JJTCNLI = 1015821.7491264958;
    double zrsMw = -286728.7628931026;
    int gIgUPco = 1174892344;
    double qfPezlqwOaozkjJ = 138725.01326293274;
    int jUveQmrMXQcbREU = 2003302642;
    bool XeAmPaskVR = false;
    int IbIvXfgIfV = -235842081;
    double wvmVJdgqxcjlpi = -460407.46063579526;

    if (zrsMw != 138725.01326293274) {
        for (int pFfSZK = 1196662402; pFfSZK > 0; pFfSZK--) {
            wvmVJdgqxcjlpi -= wvmVJdgqxcjlpi;
            zrsMw = qfPezlqwOaozkjJ;
        }
    }

    if (jUveQmrMXQcbREU >= 1174892344) {
        for (int asfKKytsOfpIIAt = 1682031472; asfKKytsOfpIIAt > 0; asfKKytsOfpIIAt--) {
            YvBkWgilcPDinX /= jUveQmrMXQcbREU;
        }
    }

    if (wvmVJdgqxcjlpi >= -460407.46063579526) {
        for (int tdBuPC = 864612068; tdBuPC > 0; tdBuPC--) {
            gIgUPco = YvBkWgilcPDinX;
        }
    }

    if (qfPezlqwOaozkjJ != 138725.01326293274) {
        for (int pLEBxPz = 1846393573; pLEBxPz > 0; pLEBxPz--) {
            YvBkWgilcPDinX -= YvBkWgilcPDinX;
            bYTXHSxeSOPmR -= zrsMw;
            YvBkWgilcPDinX = IbIvXfgIfV;
        }
    }

    if (IbIvXfgIfV > -235842081) {
        for (int SqamxxbyzTmWLhjl = 1808054005; SqamxxbyzTmWLhjl > 0; SqamxxbyzTmWLhjl--) {
            dzJNQBSUckP += dzJNQBSUckP;
        }
    }

    return XeAmPaskVR;
}

bool niwGA::JTBIMKzCHvMkU(string xVRvACIUgZaKiCUH, double VSHnn, double ggcfOdyhkY)
{
    double XollU = -187472.53121822988;

    for (int haHMPHUEBNJFyNm = 769774586; haHMPHUEBNJFyNm > 0; haHMPHUEBNJFyNm--) {
        XollU *= ggcfOdyhkY;
    }

    if (ggcfOdyhkY >= -147774.04005565145) {
        for (int FOqJaOcgcUsh = 1442389665; FOqJaOcgcUsh > 0; FOqJaOcgcUsh--) {
            ggcfOdyhkY -= ggcfOdyhkY;
            XollU += ggcfOdyhkY;
            XollU += ggcfOdyhkY;
        }
    }

    if (VSHnn > -147774.04005565145) {
        for (int qBXaXuUAv = 840260967; qBXaXuUAv > 0; qBXaXuUAv--) {
            xVRvACIUgZaKiCUH = xVRvACIUgZaKiCUH;
            VSHnn += ggcfOdyhkY;
        }
    }

    if (ggcfOdyhkY == 449471.2066214426) {
        for (int ybHkih = 1762114845; ybHkih > 0; ybHkih--) {
            ggcfOdyhkY -= ggcfOdyhkY;
            VSHnn += VSHnn;
            ggcfOdyhkY += VSHnn;
            XollU += XollU;
        }
    }

    return false;
}

double niwGA::mUsbFgcFIXg(bool LCYeFzPtUlhD)
{
    bool SKkNmv = false;
    string pdeMlglosmEo = string("KFkSjCsdZMQGtHzmHoFJDOpGBMIwjwktdJrIZdtdpvgDndPHWQegxyWLwQJZzfLNpbUOlqzbhQhzMLmzsrYBqGDyQtREMMngVTijrsOsAYkhgCAaClutMuEsadOKMUfDPrPywrFkyWldsgapehcWwoWteUYfqABCHiByLbnBmkPleOLaSwqQiJS");

    if (SKkNmv != false) {
        for (int oNcOwWkqcx = 1208561149; oNcOwWkqcx > 0; oNcOwWkqcx--) {
            pdeMlglosmEo = pdeMlglosmEo;
            LCYeFzPtUlhD = SKkNmv;
        }
    }

    if (SKkNmv != true) {
        for (int GSwFbUPMyL = 1473789785; GSwFbUPMyL > 0; GSwFbUPMyL--) {
            LCYeFzPtUlhD = SKkNmv;
            SKkNmv = ! LCYeFzPtUlhD;
            LCYeFzPtUlhD = SKkNmv;
            LCYeFzPtUlhD = ! SKkNmv;
        }
    }

    for (int DIoLsvcxZ = 1409310500; DIoLsvcxZ > 0; DIoLsvcxZ--) {
        LCYeFzPtUlhD = LCYeFzPtUlhD;
        SKkNmv = SKkNmv;
    }

    for (int vaupjmDSG = 195305560; vaupjmDSG > 0; vaupjmDSG--) {
        pdeMlglosmEo = pdeMlglosmEo;
        LCYeFzPtUlhD = SKkNmv;
        LCYeFzPtUlhD = SKkNmv;
        SKkNmv = ! LCYeFzPtUlhD;
        SKkNmv = SKkNmv;
        LCYeFzPtUlhD = SKkNmv;
        LCYeFzPtUlhD = ! LCYeFzPtUlhD;
    }

    for (int JbNFWuqQn = 283167338; JbNFWuqQn > 0; JbNFWuqQn--) {
        SKkNmv = SKkNmv;
    }

    return -834841.8965457373;
}

int niwGA::VLLNoCevXIo(int UvsibLbdIqYLNGUw, int ubWanCIrUfpEhJX, bool yOPRNXbohTrZpGl, string AqZuecCYFOI, double qweKok)
{
    int oNCCnDP = 624224093;
    bool UAAxHPCTCJQV = true;
    bool bpECTsEEBpISVYLm = false;
    bool KrjKjeEZYIeN = true;
    bool zNMmyqvjv = false;
    bool OZtSUXbUdPM = true;
    double FoIgwndbnYULh = 468764.747662107;
    double nhqgq = 946634.5714127214;

    for (int YLnsKttYtn = 634317269; YLnsKttYtn > 0; YLnsKttYtn--) {
        ubWanCIrUfpEhJX -= UvsibLbdIqYLNGUw;
    }

    for (int mmrezTNqQSDFaMwl = 1757473618; mmrezTNqQSDFaMwl > 0; mmrezTNqQSDFaMwl--) {
        AqZuecCYFOI = AqZuecCYFOI;
        OZtSUXbUdPM = ! UAAxHPCTCJQV;
        zNMmyqvjv = ! bpECTsEEBpISVYLm;
    }

    return oNCCnDP;
}

bool niwGA::utuhMAzNUfaUdR()
{
    double eKJEUGOmsvuDdUS = 1004784.6966066305;
    string XnZIPfWSoROzEvid = string("uHMyFZiuKkJxhVfXifHFVCzqCBVNSYZLBprhfDEpgnyZUlflOLdCaZGCOKBnfJQbSxwdEguTTWNITXkZArCrxvtKmrYjPkoSFxkJgEcExUlfkpyRxIfZHgznMBptmjOxCyctMHQBHgxGFDcyKQUCfScXNSjeMdWlEttTZkWprCvcjwTnjjYJOetiPPuTBpBvpXlFGQbZHNtWetoqQoFw");
    double lzsGwZmssXorrv = 567459.9430534778;
    double hXHzaRtgnxV = -40344.633750759414;
    int tJnqeyMMtPijSQIN = -1285790906;
    string JCFDPBYNWQutBozS = string("rzzoaOvRJZwaigmKseAgVlZRdiWvHggDtnEFkTWbVGTrUYTBt");
    double ePaywx = -906803.9296982439;
    double iosAeteFrgjCP = -468770.87414915697;
    int NyaWid = -1047372897;

    if (JCFDPBYNWQutBozS <= string("rzzoaOvRJZwaigmKseAgVlZRdiWvHggDtnEFkTWbVGTrUYTBt")) {
        for (int wCrZVwbD = 198904399; wCrZVwbD > 0; wCrZVwbD--) {
            hXHzaRtgnxV = hXHzaRtgnxV;
            lzsGwZmssXorrv *= hXHzaRtgnxV;
            lzsGwZmssXorrv /= iosAeteFrgjCP;
        }
    }

    for (int aPRHp = 609086390; aPRHp > 0; aPRHp--) {
        iosAeteFrgjCP *= iosAeteFrgjCP;
        hXHzaRtgnxV *= ePaywx;
        tJnqeyMMtPijSQIN += tJnqeyMMtPijSQIN;
        iosAeteFrgjCP = hXHzaRtgnxV;
    }

    for (int ReYStyajVMgikKFk = 1042390125; ReYStyajVMgikKFk > 0; ReYStyajVMgikKFk--) {
        NyaWid += NyaWid;
        JCFDPBYNWQutBozS = XnZIPfWSoROzEvid;
        eKJEUGOmsvuDdUS /= hXHzaRtgnxV;
    }

    return false;
}

string niwGA::bIlpbHLWdGCt(double dXLbuJxqltLXIXf)
{
    int XeeSk = -469737013;
    double OrDKGvnjHMf = 9967.297796793842;
    int EPGlyrLnweatsasU = -1777595283;
    bool BZvGit = true;
    double KvHdHdULxF = -347638.8860008596;
    string QJiWKcqEKIQgdf = string("kmHDGMHGSxtRmFTEhdnDRHcqvuedQVHrXabKrymVWnaeOPPzaREvhFPffoNMWquBpGLfYDFSCynRiWLUQdgxLDSwaSzWgKiVLiPkUlaoqmbNhwHPFxUtYSErhBQWzpWUpXabYEaLwE");
    bool uSfmTRlCvb = true;

    if (dXLbuJxqltLXIXf <= -347638.8860008596) {
        for (int iANhDVgKrIezrAmc = 909997729; iANhDVgKrIezrAmc > 0; iANhDVgKrIezrAmc--) {
            XeeSk *= XeeSk;
            XeeSk = XeeSk;
            dXLbuJxqltLXIXf -= KvHdHdULxF;
        }
    }

    for (int FxCHC = 1551783339; FxCHC > 0; FxCHC--) {
        KvHdHdULxF = KvHdHdULxF;
        KvHdHdULxF += OrDKGvnjHMf;
        uSfmTRlCvb = BZvGit;
    }

    if (dXLbuJxqltLXIXf <= -347638.8860008596) {
        for (int ElAGrrrXmQG = 1526580050; ElAGrrrXmQG > 0; ElAGrrrXmQG--) {
            dXLbuJxqltLXIXf += KvHdHdULxF;
        }
    }

    for (int OsNaiYrWfYuuUCMy = 1013211217; OsNaiYrWfYuuUCMy > 0; OsNaiYrWfYuuUCMy--) {
        OrDKGvnjHMf = dXLbuJxqltLXIXf;
        XeeSk *= EPGlyrLnweatsasU;
        dXLbuJxqltLXIXf -= KvHdHdULxF;
    }

    return QJiWKcqEKIQgdf;
}

string niwGA::zCEllPTP(double oZIrYdkA, int IGcQjvSFPisdl, bool ZPtFaNOoiOCZB)
{
    bool mXmsunNtSycomUCc = false;
    int oSEEXGcmk = -1549355866;
    double zZfcShqukE = -582623.8812663772;

    for (int qqWdkP = 1860564560; qqWdkP > 0; qqWdkP--) {
        IGcQjvSFPisdl += oSEEXGcmk;
    }

    if (oZIrYdkA != -582623.8812663772) {
        for (int LkWSqYMmXCaDGk = 980212729; LkWSqYMmXCaDGk > 0; LkWSqYMmXCaDGk--) {
            oZIrYdkA -= oZIrYdkA;
            ZPtFaNOoiOCZB = mXmsunNtSycomUCc;
        }
    }

    for (int hVRuEDNh = 956724919; hVRuEDNh > 0; hVRuEDNh--) {
        zZfcShqukE /= oZIrYdkA;
    }

    for (int PuhOz = 1532665495; PuhOz > 0; PuhOz--) {
        zZfcShqukE = zZfcShqukE;
        oSEEXGcmk += oSEEXGcmk;
        IGcQjvSFPisdl = oSEEXGcmk;
        ZPtFaNOoiOCZB = ! ZPtFaNOoiOCZB;
    }

    return string("lauYSMsgmfYXEmnRHYHVdgOqAYjyxmifDSnuTCjqsskGPFUpBCLOYcpeoVkOlaqvnNXaGxNENFkjjwcRgNfnQlIuBYfETfjyxpPEvVKuOPFRTuMmBpjrVpApRhWwZwheymZwtYXRJRDmqYPXSJkuVluOGlKJdPXIkfibNtdfQQEepZoygNoSkxvBxPQcfacFWFQRNuAPLiBdJDxWEMeGIMxvrmQUgBuGzBIUhDFoiGcPncQVdrXhmVnjI");
}

int niwGA::fkgkRaZjvjHvhSeh(bool wBpOKjsCkq, int XBqWpIswcBQO, bool temcNHIOmCcyaiRD, bool GXtbklT, bool mQkpbLMPF)
{
    double llwsSBOTofZVktb = -1045498.3494705263;
    double ZSwAzBpWbDCfJ = -710560.2277287743;
    double KgXYsgKlfyBxQCsG = -724047.9569227925;
    int kNMSWQydru = 636680251;
    double wEdpwpFGwdvHK = 24428.93135005816;
    double pICQkdFWWArNO = -336095.14610457554;

    return kNMSWQydru;
}

double niwGA::ZrgzRm()
{
    string EGDFNfzMzApxaWkq = string("UpFiAYdjCxhoKWWDuuAKyjsmtXeIpYZssmWDQFPbqibXgtrDpbdAgBSlnD");
    double knQnrNXdirwGx = -806601.079621784;
    string kMeoglTEDBFddt = string("VGJkWOJbivlyrpiOimOgudONIrgjmOSoOqdaAXsIiahGGkrrPTYooPwDLcdtJVACKlwKVFnDbFkYqHwitqngGMxKDsCDDyFwKXlleuhWZQq");
    int JqUMz = 1860488516;
    double PzLrVlMj = 61484.91355710126;
    string AkVNLIgr = string("tljXbkgIJaybiHvbKHmuWWvQlvKmjmQHOBjHyVGMyBLFfsSBGQyMpbsybTslkVEtUJFDRZvDlnuIetRqytYpofmfeZjbenrHHxECvZcaqmQrDPicKXXJFSESxJ");
    int ZfIHGCUnAKKiAe = 518894021;
    bool XTDwWVHGCKxP = true;
    string QUExidwrysAZRatw = string("kpaTGrrJtIxXQyglVYGSEqGoUUeoQKzYbDnzQRZCSQqQvbXlfKpwRimOXFmJMNcreTuOBBiiNauWzGAelQxRJmwOLZKzhDnXsCoBEtlkAKmzlSEC");

    for (int OeSVClakmFjKvAME = 996876275; OeSVClakmFjKvAME > 0; OeSVClakmFjKvAME--) {
        PzLrVlMj *= PzLrVlMj;
        PzLrVlMj *= PzLrVlMj;
        ZfIHGCUnAKKiAe *= ZfIHGCUnAKKiAe;
        QUExidwrysAZRatw += kMeoglTEDBFddt;
    }

    for (int obXUrHU = 226196328; obXUrHU > 0; obXUrHU--) {
        continue;
    }

    if (knQnrNXdirwGx < 61484.91355710126) {
        for (int ctQjoNDIr = 12533566; ctQjoNDIr > 0; ctQjoNDIr--) {
            kMeoglTEDBFddt = kMeoglTEDBFddt;
            QUExidwrysAZRatw = AkVNLIgr;
            EGDFNfzMzApxaWkq += kMeoglTEDBFddt;
        }
    }

    return PzLrVlMj;
}

niwGA::niwGA()
{
    this->JXmksJmScXp(92077.06526083288, -1683187485);
    this->cVwMgpj(-1805158606, 1226556339, string("wBUlLUGeLAGzDGQOFr"), string("NeevOefeSacHUnYRmHtVsCdArapkmYICMrRJIHzSJKsFQL"));
    this->fSGFtKxGMJT(-349951162, -724682.9333413206, false, false);
    this->gRGZQc(-925328802, false, 1031460.3254208806, -1449820400);
    this->YxbzSbFVDqUXgbUs(-749551.505977401, string("BbjkQikjSfdDTDSAuLWqzPnyFmLwVSoiGatGpGJOOtmiTrmGrJYgJPtmMWzcdxIDxmaMOCmjFzEOJmLeVctCqPYRTZZiiGZwufkFVXYagMLipVRiWBVWmHnAUfIfjzpWPdIOFKVvwVJwRvreHNbJhPWIppVIFAycLKqzZtBwIhAElqGHVaeItHp"));
    this->JTBIMKzCHvMkU(string("TeOHpYKblwlCBFHujOTwvvESgZXDQFhlFLOtkNoqLaynrriAeRTKZkInjrNSLbbPPmWwhBMJAEbYBHLLnnOnwPwWtOpvqrUaVUnZNNBWJGPMRAffKtCqeNNrsLYthrjjcnObhOAAOSZqfpnRhLDjBVXtYRfUgtOwPAIjQxtcgLTPBBqCrSrVjRWyexfwmViATOMirPgRdmPLvKKBguWKPKBPzMXON"), 449471.2066214426, -147774.04005565145);
    this->mUsbFgcFIXg(true);
    this->VLLNoCevXIo(1138390345, 162961604, false, string("nkRMbVCp"), 575215.1247995865);
    this->utuhMAzNUfaUdR();
    this->bIlpbHLWdGCt(808678.0468907916);
    this->zCEllPTP(-689689.7486389636, -1744553399, false);
    this->fkgkRaZjvjHvhSeh(false, -1813808802, false, true, false);
    this->ZrgzRm();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jzuQaFrtZWxT
{
public:
    int pdjJwJgqaDlFRWEK;
    string FrSwxImlmRPmLP;

    jzuQaFrtZWxT();
    int XKlUmQdnDiJ();
    string AYdlKZlK(int XWBrUwiuZ, string qMMdDszHqqWOcwO);
    double oBbVEtqfIHllc(string mHjlWs);
    bool mdEscTU(int vAPkMdd, string OdJJd);
    string rFrvqPtV(int JogVOetoDAtn, int qOUpbrimhKex, string qblYTpIGfUamLqNR, int TGITBIVUskGnph, double ghrSUiiVSzzDJjBT);
    bool jugTwRBWxySN(double hZzcjpBqAPucJ, string EkaUprJCwvqCMW, double VGBqtUZoWzL, bool sMSxgXrFikJR, int mRBimR);
    double skRxXxzQGUmN(string OfrKsKaZIBkxfPIb, double NMGzwDENL);
protected:
    bool JkwSBWqRlfNwLsM;
    double uiRNAEVAmmbjV;
    bool TzFBlwgaco;
    bool HKQYFRf;
    int XzMizktU;

    int FgzIoZDAfG(string sbDASVGIx, bool kzBWhwITTw);
    double uknCdGzfDucqyc(bool tLdNytpeaJ, double AuVdJGMQantPmrh);
    double pwjoyVHCzp(int bhgwifMjeK, bool yNEaOpGubeCG, string VdhQzpkOFmYM, int RUmIzdP, int zWmvcBkJu);
    bool GXOtSXk(string gDdrzmCIdRKgmy, int fOiCAtVYd, string xLNdNj);
    int FLYlGXzaxk();
    bool tMiyG(double GwnIBTbk, string wySsC);
    bool QlwkpVZiue(string JSgalxwbHI, double pZGjNVs, string cnUCkgSxwPRQy);
    string KEdafyHnQUdD(int VrIJCwhNfrm);
private:
    double eEHXA;
    bool ozUZJAqeVyfwAt;
    int QDfvfrWzPMg;
    int xvSUQKODwFviWkYl;
    int MLQsAkswy;

    int oqIQgUGRqrtaY(bool ceGjbSavAbhQv, int otQLCD, string bzkdszEVEH);
    void UOsLIfVXA(int hdrQuUIOSS);
    bool KoXORbYeQe(double uEvPZSTMwShhY, int HUQarzzMfhrrjx, string Qjvhx, bool kIBFqGwHb);
};

int jzuQaFrtZWxT::XKlUmQdnDiJ()
{
    int YdioZXU = -794487740;
    int jjoitqlQgbiQppw = -1491372191;
    double podwaNkDsTnivUF = 824777.3722459786;
    bool JFyjyIHSsVd = true;
    string edPyvecImwT = string("MWuAUuaYPEaESvZpDqhMiyskffUnyrLeinxtNOiRRPiUNZTVnCAVIEuvEvLMpfSLvPMsnGPVBAajWEAzchIrPBWcfiryqbnOOyLMsZ");
    bool rsEEKzOTboh = true;
    double KKVEO = -116759.04756912624;

    for (int tYXsUIfJ = 1674372991; tYXsUIfJ > 0; tYXsUIfJ--) {
        podwaNkDsTnivUF += podwaNkDsTnivUF;
        JFyjyIHSsVd = ! rsEEKzOTboh;
    }

    for (int DbqlY = 97452825; DbqlY > 0; DbqlY--) {
        continue;
    }

    return jjoitqlQgbiQppw;
}

string jzuQaFrtZWxT::AYdlKZlK(int XWBrUwiuZ, string qMMdDszHqqWOcwO)
{
    bool FsbyPEyUCPu = false;
    string ZhcoAYvPdhKZ = string("bXPAYVMiOjNTmaUMBSvhYFlzENGGTagqngspKPrppsQoYBwUuMxKREvQyprMmvxxIAmFWhfsPcFGCBozsjByKlPfjyYecttEvJocrNqEnOfchmTBXOVZiquyzVkOaCGXGXYopRmDdSaI");
    string FKbkPpWdoUMVRWyq = string("KEOyczUxFIASDdiFOgPttsbohQehwJTKBSucIbYmQbpmOVMZvECSryKqBbWdRrDrDGFNnKXoLXwVZXmisVTAjkjxyyCNLUXlqbIZbJUaoOQROioiauKaARjm");
    int iQXzzdNdhjMKTsy = 1541001247;
    string NqqjaZQlMtpTJ = string("taJxgcoLsXPxFXHKBTwgCRtgbibWBYTSfmYWdcufZRJOGPBeEZfSUwQTHgPsUEdyLAODUzBIZMqvqmBCZcvEtnxcsHzPqkWjVXZXrVIdQukKSZWguApdFpXBPRZFTKyjYAyKRqREeRXWaboDgrYoJfMNqDShHYbUyljYhdaJJgZoQBjYleswlMAnKUlNBm");
    string ldPEMKwtdQvliSC = string("HLDjSnRlKhTNOjBDBBjsLhusJyoBNrBxiJXWLUlVVlIAFDKglxqDTAGPdiSnGWTyzCBQwTyrERCkNePyDTwuCmryadNxXKDqcYFYrXqoJlaOFvugobvfzNIZ");
    string KBXrOVPCdUZIBjjV = string("DKLfjRQxXKUYKlyxxEhyHsxJJSdTwIjeEcnRECydnaskpcSgbpTsQhlfOeaZduNRmJoRtNpuTBOjShceOIiPuUJckMVQgPWgrdDvhSckUQhkZFYyhtMSAYAGurFIxTLrqadtpTptHzsPAwwREczDHSrgiJGwKmiEiHkvNeyUZaXAdWlTfiXIBwj");
    string FQoMEYfjw = string("kQHfTBGmyDTlvXNMHGwQoljrgxtKdTlsbfCrqBoznqkoVLhjtWdaftmAaZtVSPobdqPYcNPXjcURkmtdzxCjacyWipflxUWmNvHAwOjaYqTqSpwYvpjQBWMKYdtoJpmDYErHVAyfNIuVloqNNmWzaEGtUlExodCgjnxZulOpuDRLhSVxPpMQtktdnAKLyQYxHNwfAPVVRZOTYDMRDMrwFMcHPcORlMllPJzAxECMfiXHAggwyxuCBTiZaXAlroU");

    for (int LZcwhfR = 2124487787; LZcwhfR > 0; LZcwhfR--) {
        ldPEMKwtdQvliSC = ldPEMKwtdQvliSC;
        FQoMEYfjw = qMMdDszHqqWOcwO;
        KBXrOVPCdUZIBjjV = FQoMEYfjw;
        qMMdDszHqqWOcwO += qMMdDszHqqWOcwO;
        FQoMEYfjw += ldPEMKwtdQvliSC;
    }

    for (int TTRjvkKTRcAYA = 1655237075; TTRjvkKTRcAYA > 0; TTRjvkKTRcAYA--) {
        continue;
    }

    for (int vajSzjElNueeelR = 430106871; vajSzjElNueeelR > 0; vajSzjElNueeelR--) {
        KBXrOVPCdUZIBjjV += FKbkPpWdoUMVRWyq;
        KBXrOVPCdUZIBjjV += NqqjaZQlMtpTJ;
        ZhcoAYvPdhKZ += NqqjaZQlMtpTJ;
        XWBrUwiuZ /= XWBrUwiuZ;
        NqqjaZQlMtpTJ = NqqjaZQlMtpTJ;
    }

    if (ldPEMKwtdQvliSC <= string("kQHfTBGmyDTlvXNMHGwQoljrgxtKdTlsbfCrqBoznqkoVLhjtWdaftmAaZtVSPobdqPYcNPXjcURkmtdzxCjacyWipflxUWmNvHAwOjaYqTqSpwYvpjQBWMKYdtoJpmDYErHVAyfNIuVloqNNmWzaEGtUlExodCgjnxZulOpuDRLhSVxPpMQtktdnAKLyQYxHNwfAPVVRZOTYDMRDMrwFMcHPcORlMllPJzAxECMfiXHAggwyxuCBTiZaXAlroU")) {
        for (int moPCJxsMmCJH = 1041739242; moPCJxsMmCJH > 0; moPCJxsMmCJH--) {
            qMMdDszHqqWOcwO = FKbkPpWdoUMVRWyq;
            qMMdDszHqqWOcwO = ZhcoAYvPdhKZ;
            FQoMEYfjw = qMMdDszHqqWOcwO;
            XWBrUwiuZ -= XWBrUwiuZ;
            ldPEMKwtdQvliSC += ldPEMKwtdQvliSC;
            FQoMEYfjw += FQoMEYfjw;
            NqqjaZQlMtpTJ += ldPEMKwtdQvliSC;
        }
    }

    return FQoMEYfjw;
}

double jzuQaFrtZWxT::oBbVEtqfIHllc(string mHjlWs)
{
    bool niKELzmXi = false;
    double xWbZdgKEwaHTdH = -780279.1615404029;
    int HorOFILRyMQS = 1283731628;
    double bdxaStaWaEJuXNl = -623628.6789975014;
    double RrmOaNjUcwcJjh = 474337.1672165988;
    int JNcPMxhd = -413330543;
    double mNqXigRbeNZX = -849399.6107100087;
    bool HVpsnhAXhV = false;

    return mNqXigRbeNZX;
}

bool jzuQaFrtZWxT::mdEscTU(int vAPkMdd, string OdJJd)
{
    bool jyGsdheMAkRN = true;
    bool XUOQucePKeRdMvp = false;
    int NyYoavOoiKOqKVIT = 1450712855;
    string InuknIZASMsDzZ = string("RpZdlqrrdyFTDnDzjHoFYIwwipdAKVziBuVKEbYaQISnnamRxRJjmrZsiToyz");
    int JjnbLcCykrWtK = -1374822961;
    int RSkZjndTNavZhHXY = -170148595;

    for (int RpWBHUGZJ = 1092878505; RpWBHUGZJ > 0; RpWBHUGZJ--) {
        NyYoavOoiKOqKVIT /= vAPkMdd;
    }

    if (JjnbLcCykrWtK >= 1450712855) {
        for (int tfbgvS = 2080186339; tfbgvS > 0; tfbgvS--) {
            NyYoavOoiKOqKVIT += vAPkMdd;
            JjnbLcCykrWtK = RSkZjndTNavZhHXY;
            InuknIZASMsDzZ = InuknIZASMsDzZ;
            JjnbLcCykrWtK += NyYoavOoiKOqKVIT;
            JjnbLcCykrWtK -= JjnbLcCykrWtK;
        }
    }

    for (int rDjhl = 917969439; rDjhl > 0; rDjhl--) {
        RSkZjndTNavZhHXY -= vAPkMdd;
        RSkZjndTNavZhHXY *= RSkZjndTNavZhHXY;
        jyGsdheMAkRN = ! jyGsdheMAkRN;
    }

    for (int qAPjagZfrh = 846911782; qAPjagZfrh > 0; qAPjagZfrh--) {
        continue;
    }

    return XUOQucePKeRdMvp;
}

string jzuQaFrtZWxT::rFrvqPtV(int JogVOetoDAtn, int qOUpbrimhKex, string qblYTpIGfUamLqNR, int TGITBIVUskGnph, double ghrSUiiVSzzDJjBT)
{
    double rqfUMgNOrTNTm = -378670.02137536457;

    for (int tULTsnZ = 1479116566; tULTsnZ > 0; tULTsnZ--) {
        rqfUMgNOrTNTm *= rqfUMgNOrTNTm;
        ghrSUiiVSzzDJjBT = ghrSUiiVSzzDJjBT;
        JogVOetoDAtn /= TGITBIVUskGnph;
        rqfUMgNOrTNTm -= rqfUMgNOrTNTm;
    }

    if (rqfUMgNOrTNTm < -177186.93102160076) {
        for (int JcEULA = 794773269; JcEULA > 0; JcEULA--) {
            continue;
        }
    }

    return qblYTpIGfUamLqNR;
}

bool jzuQaFrtZWxT::jugTwRBWxySN(double hZzcjpBqAPucJ, string EkaUprJCwvqCMW, double VGBqtUZoWzL, bool sMSxgXrFikJR, int mRBimR)
{
    bool AKCpENwOLNtdj = false;
    double uTXXdTaf = 437156.2219685119;
    bool RcMti = true;
    bool iROkVFI = true;
    double ClLnLkaLaF = -1044630.9638762296;
    double nFvJxt = -849801.1929931687;
    bool owuAeXFa = false;

    for (int CmqjN = 573600606; CmqjN > 0; CmqjN--) {
        continue;
    }

    for (int xiUVRBxoBNRgfx = 827668587; xiUVRBxoBNRgfx > 0; xiUVRBxoBNRgfx--) {
        continue;
    }

    return owuAeXFa;
}

double jzuQaFrtZWxT::skRxXxzQGUmN(string OfrKsKaZIBkxfPIb, double NMGzwDENL)
{
    double KFolaGPMhFKXNuDD = 19563.055946775967;

    for (int lsiflCGvrWnzOV = 2011817732; lsiflCGvrWnzOV > 0; lsiflCGvrWnzOV--) {
        OfrKsKaZIBkxfPIb = OfrKsKaZIBkxfPIb;
        NMGzwDENL /= KFolaGPMhFKXNuDD;
        NMGzwDENL += NMGzwDENL;
        OfrKsKaZIBkxfPIb += OfrKsKaZIBkxfPIb;
        OfrKsKaZIBkxfPIb = OfrKsKaZIBkxfPIb;
    }

    if (NMGzwDENL > -730192.0326131943) {
        for (int INuinkImOMFwHJ = 529024500; INuinkImOMFwHJ > 0; INuinkImOMFwHJ--) {
            KFolaGPMhFKXNuDD += KFolaGPMhFKXNuDD;
            NMGzwDENL *= NMGzwDENL;
        }
    }

    if (KFolaGPMhFKXNuDD <= 19563.055946775967) {
        for (int BztvZ = 556377296; BztvZ > 0; BztvZ--) {
            NMGzwDENL -= KFolaGPMhFKXNuDD;
            KFolaGPMhFKXNuDD = NMGzwDENL;
            NMGzwDENL += NMGzwDENL;
            KFolaGPMhFKXNuDD = NMGzwDENL;
        }
    }

    for (int lLCXWnyWyy = 111292813; lLCXWnyWyy > 0; lLCXWnyWyy--) {
        NMGzwDENL = NMGzwDENL;
        KFolaGPMhFKXNuDD /= NMGzwDENL;
        OfrKsKaZIBkxfPIb = OfrKsKaZIBkxfPIb;
        NMGzwDENL = NMGzwDENL;
        NMGzwDENL -= NMGzwDENL;
        KFolaGPMhFKXNuDD -= NMGzwDENL;
        OfrKsKaZIBkxfPIb = OfrKsKaZIBkxfPIb;
    }

    return KFolaGPMhFKXNuDD;
}

int jzuQaFrtZWxT::FgzIoZDAfG(string sbDASVGIx, bool kzBWhwITTw)
{
    string wuovvmFbsC = string("mLRnJkRhLfUgKLKNFbWNuOPxYaIZnnVyoxodtceJtUqZoijbjLJZdorcervvucZZGmxFIghPqjcmONmhNQwOugMpnYriShfWWCqSBCHHgKZiUOxNMYmPhmCVAgctXIeSeLeNUcqBJEtfwtmlSrBFqKwLfnhLvAlnYPFrHUHhYyembJiXTfAPQgFghfliTpIQCFWxQJvXLmawQQtfHUAWJuWxkUBYKSYOIKvVoNXlDrbeeiXq");
    bool YKQVvygO = false;
    int rOgpWDvW = -1754223860;
    bool ncwcvjC = false;

    for (int aDNHKOCVAW = 537969673; aDNHKOCVAW > 0; aDNHKOCVAW--) {
        continue;
    }

    return rOgpWDvW;
}

double jzuQaFrtZWxT::uknCdGzfDucqyc(bool tLdNytpeaJ, double AuVdJGMQantPmrh)
{
    int SQPmJR = 1612733654;
    string dDYstGTxf = string("nopcunzhLxtoInUvZYMIyacSPzIsZRVCEcNElqQYWwnnDcaKNgJCEWvvwnqRnqRMgoUMEjJrCCOKcHmnJBNwlyIhXljpMdCYyKQaVbInhKmcWfPCXUnhsHHCukGDfZsZCmhjCjIIAVoFqgfiqJhEuhvjMnCrRjOtxNAFFfioUomsvzVWOFWTLqnxVOriqteLmqgEuClphJvtFQGqqoYs");
    bool VzbbgRtIvT = true;
    string EaiSgxjkvaL = string("KlqkkxTNimqpTAsifOfYepwhiTyOMQiSffoUedhOFkNRCqewfyPTTruspRVjsERoGIyPoHwtIaZEqsVuZjsRymtAPEfgQrrOnYtPFDPwaLsGTGKBGgAkvdLWlvrZlmFmlKNHIHcLilALdSkNJQWrzzQIUsfZbZdOgMEYhIesybYMlikykBQslKYimqWSdnDeGlTEuWtBVFXrotygZdBDlRyKfqigVDzttMUpkdqjYdEYLM");
    double KbTFsUTljgobX = -921315.7746004874;
    int UXkNbuNtJYSImTX = -392298503;
    bool IhdQg = true;

    for (int gJQmUdtWCRZr = 939076640; gJQmUdtWCRZr > 0; gJQmUdtWCRZr--) {
        continue;
    }

    if (AuVdJGMQantPmrh <= 912431.2394542317) {
        for (int yyHUHG = 243438984; yyHUHG > 0; yyHUHG--) {
            SQPmJR /= UXkNbuNtJYSImTX;
            dDYstGTxf += dDYstGTxf;
            SQPmJR /= UXkNbuNtJYSImTX;
        }
    }

    for (int vgtWwZABpTkyunr = 1242842409; vgtWwZABpTkyunr > 0; vgtWwZABpTkyunr--) {
        KbTFsUTljgobX = AuVdJGMQantPmrh;
        KbTFsUTljgobX /= AuVdJGMQantPmrh;
    }

    return KbTFsUTljgobX;
}

double jzuQaFrtZWxT::pwjoyVHCzp(int bhgwifMjeK, bool yNEaOpGubeCG, string VdhQzpkOFmYM, int RUmIzdP, int zWmvcBkJu)
{
    string WgtuGEKGIReNx = string("VmxmZbfzWAVpdSRRdFIoHQaNMDCegrxEBkQJdsnvCleEVmJYLGvgrUcpeuxSfoYwoFoopPSOwoIXihwKZZyfIZcyWoCsocJjufoaBfxXZhnSZwLJDziEaUWjTglCYMQceiMLCgOjDZuCOIgCVARknyCoWxrsEYwCKwchXPbcpkHNPXeaCnttJFFTAygbXMbYsJhTTRfRwIkgLUTiqMldHdVGdznDhDaeqKpmaRMJUyxbFVTqBsqeVe");
    bool HRbosMYzP = true;
    double KQCNqw = -959824.9925803302;
    double yiodUvELwY = -939007.6702429104;
    int dEQQydWTTEaWp = 2002063812;
    int EWoYHoPA = -1321221069;

    for (int qJfYZoifEpYsk = 202088122; qJfYZoifEpYsk > 0; qJfYZoifEpYsk--) {
        dEQQydWTTEaWp += bhgwifMjeK;
        dEQQydWTTEaWp += dEQQydWTTEaWp;
        bhgwifMjeK *= EWoYHoPA;
        dEQQydWTTEaWp /= dEQQydWTTEaWp;
        dEQQydWTTEaWp -= RUmIzdP;
    }

    for (int AnQiFyDjUu = 180637482; AnQiFyDjUu > 0; AnQiFyDjUu--) {
        EWoYHoPA /= dEQQydWTTEaWp;
        zWmvcBkJu = EWoYHoPA;
        RUmIzdP -= bhgwifMjeK;
        HRbosMYzP = HRbosMYzP;
        EWoYHoPA -= RUmIzdP;
    }

    return yiodUvELwY;
}

bool jzuQaFrtZWxT::GXOtSXk(string gDdrzmCIdRKgmy, int fOiCAtVYd, string xLNdNj)
{
    double CBQWcmCAbCbSBkj = 229333.0245164381;
    string xPvkJNR = string("sDBCWXHhWoqk");
    int WNQQMfMpXwf = 687307023;
    double igGWaruqHHlqhfar = 228094.71824211252;
    int CbcwxIFtCdrOo = 326272744;
    int HLGiFpSyumjD = 1802848813;

    return false;
}

int jzuQaFrtZWxT::FLYlGXzaxk()
{
    int tVLstsIBDSklgYk = -1542759627;
    double qiieQmqwANF = 386354.5002138664;
    int iYVIvXMUjWNX = 1970091091;
    double IBJbFJYmHDxKbfG = -61192.13294580803;
    double KPSGBaXNxzcz = -81444.75282098052;

    for (int mvwyIjxbFCXxQZY = 1284140172; mvwyIjxbFCXxQZY > 0; mvwyIjxbFCXxQZY--) {
        iYVIvXMUjWNX -= iYVIvXMUjWNX;
    }

    return iYVIvXMUjWNX;
}

bool jzuQaFrtZWxT::tMiyG(double GwnIBTbk, string wySsC)
{
    string rTmujqGFIvjlWi = string("mOSQuayethjwHSMnnVSIwYurvgzORHRHODLdevwugjwRUEyWmwtpvosQJwTnzTcPrxxORWciNJupoNbWWIYqMuFtniDtygdDnrxhrlqwwSHqMxEILEFPtoZfzgWUYKEXYhXTFhOWlIZHRKGbxjeTtBuUAbyq");
    double fUtkxiH = 809657.6163342133;
    int DWkzrTSIPpD = -808620231;
    bool ljJxdXtpxTVcTGC = true;
    int LkIYRFN = 946012936;
    double falgCnXQFOEC = -375134.1089605437;
    int rxVjoLJNUnOgbwkX = 1863770891;
    bool KDqqpSjbzz = true;
    string ldHlO = string("NKKFLqYGRrWZMDUcndbrkzGvdepFnVPZZaClbOgvKJzKgZVtltZICsbzRYejrfuCNlYTTirxZonjxflNuJYeiaKvZldDRccOfgFLBCuNtLkarTgbqNiDyhDlJvQiZfrYOrPSYQrLuPFRCFtNcANkIzleVkzrqwmOXvGlIzBCpPhrxOUsacwwrZcsjAqflDADrPIywwTxqaUMNBujphDhXwmTBBVQwdMJEkNaWxCPKmsRYtLWdGYFSKtGT");

    if (LkIYRFN <= 1863770891) {
        for (int LpTcxPqyrHry = 1527740431; LpTcxPqyrHry > 0; LpTcxPqyrHry--) {
            rxVjoLJNUnOgbwkX -= DWkzrTSIPpD;
            fUtkxiH += fUtkxiH;
            rxVjoLJNUnOgbwkX -= DWkzrTSIPpD;
            fUtkxiH = fUtkxiH;
        }
    }

    return KDqqpSjbzz;
}

bool jzuQaFrtZWxT::QlwkpVZiue(string JSgalxwbHI, double pZGjNVs, string cnUCkgSxwPRQy)
{
    int eCMSUHrekiHiI = -343320673;

    for (int sAhdl = 441206319; sAhdl > 0; sAhdl--) {
        JSgalxwbHI = JSgalxwbHI;
    }

    if (JSgalxwbHI > string("RtSiYlSOALPDULRsgrFGQuD")) {
        for (int GCuqmIpAcBU = 1946020484; GCuqmIpAcBU > 0; GCuqmIpAcBU--) {
            JSgalxwbHI += JSgalxwbHI;
            cnUCkgSxwPRQy = cnUCkgSxwPRQy;
            JSgalxwbHI += cnUCkgSxwPRQy;
        }
    }

    return true;
}

string jzuQaFrtZWxT::KEdafyHnQUdD(int VrIJCwhNfrm)
{
    int JWbPRgyuv = -249133075;
    bool tRJWRMH = false;

    if (JWbPRgyuv == -249133075) {
        for (int xxcIMvupPMvYq = 1909977612; xxcIMvupPMvYq > 0; xxcIMvupPMvYq--) {
            JWbPRgyuv -= VrIJCwhNfrm;
            VrIJCwhNfrm -= JWbPRgyuv;
            VrIJCwhNfrm = JWbPRgyuv;
            JWbPRgyuv = VrIJCwhNfrm;
            JWbPRgyuv /= JWbPRgyuv;
            JWbPRgyuv = JWbPRgyuv;
        }
    }

    for (int sOwIcanapEqjQaI = 612079610; sOwIcanapEqjQaI > 0; sOwIcanapEqjQaI--) {
        JWbPRgyuv /= JWbPRgyuv;
        JWbPRgyuv /= JWbPRgyuv;
        JWbPRgyuv += JWbPRgyuv;
        tRJWRMH = tRJWRMH;
        VrIJCwhNfrm *= VrIJCwhNfrm;
    }

    if (tRJWRMH == false) {
        for (int KjHaaLD = 245317578; KjHaaLD > 0; KjHaaLD--) {
            VrIJCwhNfrm -= VrIJCwhNfrm;
            VrIJCwhNfrm = VrIJCwhNfrm;
            VrIJCwhNfrm += JWbPRgyuv;
            tRJWRMH = ! tRJWRMH;
            JWbPRgyuv = VrIJCwhNfrm;
        }
    }

    if (VrIJCwhNfrm != 2130358417) {
        for (int NYCwB = 792010399; NYCwB > 0; NYCwB--) {
            JWbPRgyuv = VrIJCwhNfrm;
            tRJWRMH = tRJWRMH;
        }
    }

    for (int KyjKtAgDGcWw = 2071659220; KyjKtAgDGcWw > 0; KyjKtAgDGcWw--) {
        continue;
    }

    return string("cJlAfdCVaMPxsJbirLSLNkXCbbwDhvtWMYLFeuQyAOsehPSKoVKflWlnkajtfKStLInJZYncteYOguaAAkqUtxmIEygdsbMeMVBAGWEPodRHuRcbKhYmeCNqyoOslIiNKXDQvPqhxsgqxXww");
}

int jzuQaFrtZWxT::oqIQgUGRqrtaY(bool ceGjbSavAbhQv, int otQLCD, string bzkdszEVEH)
{
    string uTvpuXpZbngeil = string("rNaoQJHlhUMGnSPIjqlWuXmPmCgUNMPZNOQqdBSbRVPwFcYZFFLOQbAynYRsazTGtJuyfAETbDKmiBK");
    double cxIDGmGybvmJJm = 983704.8682516365;
    int FyWPmHsNeapsYle = 744378930;
    double UNFUMqttB = 318225.4725750533;
    int wsdERPLKeJ = 1166812199;
    string oSCpkFW = string("bvW");
    string GZzKEYD = string("kUwPcwpwQIpJsCxkCuqsWEXZDsTgglLWZSZMggMMmElwPLubAPwFcLsKIRL");

    for (int cscVuBLdOPD = 1018087830; cscVuBLdOPD > 0; cscVuBLdOPD--) {
        uTvpuXpZbngeil += bzkdszEVEH;
        otQLCD -= otQLCD;
    }

    for (int entqSHoBYHhsVP = 1269783856; entqSHoBYHhsVP > 0; entqSHoBYHhsVP--) {
        continue;
    }

    for (int vSrCFQ = 2113133620; vSrCFQ > 0; vSrCFQ--) {
        cxIDGmGybvmJJm /= UNFUMqttB;
        bzkdszEVEH += bzkdszEVEH;
        otQLCD += FyWPmHsNeapsYle;
    }

    return wsdERPLKeJ;
}

void jzuQaFrtZWxT::UOsLIfVXA(int hdrQuUIOSS)
{
    bool HlKfGFuhefTjA = true;
    double wFfIYcgrmJUsOJD = 813751.4015659757;
    string ZAkXAZuioBMvyl = string("IlCsiPuaGRbsVaKBYSfAfITZyrSBRwnYnewUObxmdhKFtXjAnBsNLyNQxIoNUrIqEWhrQJqYkOhDseNTeQndMflOrXQsvXLVwPuvQmerpZVBLqWCsmbGJXCSmQpcHTqxumyGlMTelwZsiDVniIUajrgBg");
    bool RuhRNNkhheIAG = false;
    double uvFZIKgr = 387716.60331916093;
    double KkwjQFGBZI = -1028063.1060179385;
    string rCQWf = string("OkZaNcjyAzrhrcOWwLVWZyeAGkNjcAwZxthyteCiVGBwamQlxkDjyjRwhSVxnxXStSospBhlsiBVZfeVMYSDTWKQNyIduxXxCrgSTjrFEbulZgigKaAXiHWwdUROfdqyhnBCXYIoIeXjQTMkvixkYCRkRPrSvXGWbhLhQHguhqANKwRahkVvTWyZpooSlpIDEFYHXkBBlHXgzfPPQnnmcMXSDBdviXkMpLsqkuYyim");
    double NJjHqAqymD = 121285.80484321514;
    int nevDUHfrqISx = -577971345;
    string pfjzigVfBY = string("AANigaNWjvlxTjVOc");

    for (int jWsXZMXUlkAmxQIP = 1273383154; jWsXZMXUlkAmxQIP > 0; jWsXZMXUlkAmxQIP--) {
        KkwjQFGBZI = NJjHqAqymD;
        RuhRNNkhheIAG = HlKfGFuhefTjA;
    }

    if (nevDUHfrqISx == 82292382) {
        for (int kQAraqrwZ = 269686100; kQAraqrwZ > 0; kQAraqrwZ--) {
            continue;
        }
    }

    for (int LoELJxjjwXAzOWi = 1670248995; LoELJxjjwXAzOWi > 0; LoELJxjjwXAzOWi--) {
        RuhRNNkhheIAG = RuhRNNkhheIAG;
    }

    for (int EkxEQuw = 1075537228; EkxEQuw > 0; EkxEQuw--) {
        rCQWf = ZAkXAZuioBMvyl;
    }

    for (int BWtrllIl = 1567361173; BWtrllIl > 0; BWtrllIl--) {
        rCQWf += pfjzigVfBY;
        KkwjQFGBZI *= KkwjQFGBZI;
    }
}

bool jzuQaFrtZWxT::KoXORbYeQe(double uEvPZSTMwShhY, int HUQarzzMfhrrjx, string Qjvhx, bool kIBFqGwHb)
{
    string BfpQciCxn = string("QRFAlTVqzSUEOVKTDsEdLWKIGKDBzY");
    string cmvehAdCHPFuF = string("gczJSsqIaatMFIwzTSsTrFCUsxWJvndVHNDLhyyJVYconZjRCuQvHscaGUccZuuRlepWyZzHTmQVFXJEbPDxRtIOSPxVnmJsCqwzjqHRbigbusqxUgOCxRjhuuYvbznNpozekOiBaTYqoFQycGvZfveJLbtXBqIpgskvyJVheakbDsgowqcHRdrcezfHKYwyVJwqXvXphHOKBYMopazlCubWxTxCwOJPrdDFpJJ");
    string UlweTetoaRQLeqM = string("rssqjsHgjQelCeAmKwIBNLBCICXyCFvmcHBakFyQpIooNrKrQcqqAfdGuQTmVlNOHxyTsTfGwcChIjZRkbEeuKMAJJwotKIuMBMLobPUrOMohtlNKOwhrTSlRmnepOkmDPudOazVmtjFGAvfJMCvzubaKGuj");

    if (cmvehAdCHPFuF != string("QRFAlTVqzSUEOVKTDsEdLWKIGKDBzY")) {
        for (int SnueuTtgWnQOz = 108708387; SnueuTtgWnQOz > 0; SnueuTtgWnQOz--) {
            kIBFqGwHb = ! kIBFqGwHb;
            Qjvhx += cmvehAdCHPFuF;
        }
    }

    for (int bswwJob = 1251334372; bswwJob > 0; bswwJob--) {
        continue;
    }

    if (cmvehAdCHPFuF <= string("gczJSsqIaatMFIwzTSsTrFCUsxWJvndVHNDLhyyJVYconZjRCuQvHscaGUccZuuRlepWyZzHTmQVFXJEbPDxRtIOSPxVnmJsCqwzjqHRbigbusqxUgOCxRjhuuYvbznNpozekOiBaTYqoFQycGvZfveJLbtXBqIpgskvyJVheakbDsgowqcHRdrcezfHKYwyVJwqXvXphHOKBYMopazlCubWxTxCwOJPrdDFpJJ")) {
        for (int PxorOu = 1561850978; PxorOu > 0; PxorOu--) {
            continue;
        }
    }

    for (int TANvRVRPlpOrVcrl = 459873263; TANvRVRPlpOrVcrl > 0; TANvRVRPlpOrVcrl--) {
        cmvehAdCHPFuF += UlweTetoaRQLeqM;
        uEvPZSTMwShhY -= uEvPZSTMwShhY;
        UlweTetoaRQLeqM = BfpQciCxn;
    }

    if (BfpQciCxn > string("rssqjsHgjQelCeAmKwIBNLBCICXyCFvmcHBakFyQpIooNrKrQcqqAfdGuQTmVlNOHxyTsTfGwcChIjZRkbEeuKMAJJwotKIuMBMLobPUrOMohtlNKOwhrTSlRmnepOkmDPudOazVmtjFGAvfJMCvzubaKGuj")) {
        for (int hgcGJE = 243780524; hgcGJE > 0; hgcGJE--) {
            UlweTetoaRQLeqM += cmvehAdCHPFuF;
            Qjvhx = Qjvhx;
        }
    }

    return kIBFqGwHb;
}

jzuQaFrtZWxT::jzuQaFrtZWxT()
{
    this->XKlUmQdnDiJ();
    this->AYdlKZlK(-1272260272, string("POYoXIpCvGlwedJpYFKyrMrtuSYluYLDopZbogFzLtEpZvAsJZotcvFleSZIfKspozPaHwZNJGzTnbUyRGVXWfFCVaKKFRMJyAuSNIiAiLsRFOABdVRXqOwtmPlgjuZoGFKbKJNucGhUCyezEUAOGIuFuJWRVnIZrvikAZFKaDjfMvmGhkqtcyfxGfLPryXOVpbtvpmSESZcktxUvCWbHOTbfuMejNdTUPUuZHlIbjGtSZJaok"));
    this->oBbVEtqfIHllc(string("eMGWyXKZxmQJuufymicaBQMvdimQynGcYsHjIstFZEGhnuBwnuftVXRVftbCpDIhwdFxUsrgNLBlsBgJFleWbyOmxVQdkwITGOvfLEeipRvmcsIEVCOhaQlDeGXRlxXsCqWgWsLyAYniKkFdPiUiiTRAFkQqknVHxekQDZBOZOpTARgHUaUhCQAwmuQmNPyHOappFKSUZRwAUgUAoigewgoPAfrQEqQnuFUyBFXwYBOiPnRZaTYuQlrPPCUvHcr"));
    this->mdEscTU(1796836867, string("EjJbvHQRrypeegTXYiH"));
    this->rFrvqPtV(-1993457819, 1168556264, string("JUXncPMBEkybwSoycCmpgXvYoDssHFSNpmUPFXbtnYPKXhIXKXiwraIaFYgACfujnRMOAGfhqGwkKlmVQfJFlOhmeTyytlqwkZwvqFzaXIUgKtnmHTKMbTKIJciVknpvNzBMcUsEERngaYDerTxMvEBuKyvkbZIzvmZMBhPnnRehPWADuDvFbMpZZdBqRQVTABgDZSjtceELjTaSZtHNoNhetfvVTOmasIJArRzZoDTemSehpAvMJhptrxjMn"), 1183305834, -177186.93102160076);
    this->jugTwRBWxySN(918637.9261969182, string("GeIctogdqXOGhdxdkLUCLrUFrZeLkNlqPIrmagruCVLsBIJgCoUYDIMmipWNlspBzDj"), -797863.3993918109, false, 1372808204);
    this->skRxXxzQGUmN(string("rXbvlICLpvvBNkqFnhnRjkNyXyWYGLtVTrsaGLYcmMPSdYwUFRcOwfOvEZAGBRPLfCTXKZJfwPvlvqrPrWABhgVsImQfvywNfERhLOagdJbgkAAJzWBZqBWLwaeqVWzaqLtsggQDrMGTdgQcwJyYhqvbzaKZUcmzIwWANkghDzFitYoGfGQcbbhYGubpnFDZMHlBoTwoVbPFBTiDVZHE"), -730192.0326131943);
    this->FgzIoZDAfG(string("FVykpWaJGKDmEsqMqsCwrqUhATkdcIofTV"), true);
    this->uknCdGzfDucqyc(false, 912431.2394542317);
    this->pwjoyVHCzp(1803268447, false, string("mRAHSbHHkEYbgQCzOmawgvfnIGgmhJapXokPGfIITUuWHatLKSZaXtNYbUbNmUFvhalsYndnNhVnESdzZUqGNnnMIkbdslLsBNmFoFWWTzNrtZGLgkSFOkBAUfGfjVTAUtCiuQAcgBJMBosREoMTtPzyklRIiRiVFtlIpwwJerZcUqPleYFDGjMLEbPvOvXOsipXyvjtZYuiJovojNBiyZBrKDQSXPOyOCPmtUNujLsAjvRRPCSm"), -336515718, 1105369285);
    this->GXOtSXk(string("tnDxIrUigtqtsURXhxeiMNizyUwVHwBBcDAiQoxgImnLCPNayGybecXzXApNQhRBSSrWzgzfAAQgHHZmvFMhusxROxDRyHTaTavzGfiHCElaeaUSQdsWBmOGyjMPaRoGkfGVMGRBkQRZGRqkvMiksoOWYwdecZqhulFFBmfCvfelEBRnyBVlsKkqaNJRrAclsrYahPdTigRVrelUGtBbINHkMNgPx"), -964039636, string("npUBAFVqFbbAfWyoXfcQSLxUSKRvHfPtvaUagMaKZWyhldhetCAQMNcfqLgOiKv"));
    this->FLYlGXzaxk();
    this->tMiyG(-451719.60592489433, string("hSnkwCCAyBzqXYndyAcrzpNcUgPWMRtcpkMFwNlLzLtMQeeYzVaMSddZeOUlOCMhTpIKNffnGPjZgVXONoRaGfbJxTWfyDHdJFTrjNWKBbRlSnQyYgMNkjQXDhZRoursATsjZLNapbCLGjKcOKcPXSiJM"));
    this->QlwkpVZiue(string("SsbiJcZaUKmkZaYkFBkvwUzbuAJJPfcSSaWruLWGBxsbovbnKgceizqUIcIlNyNyOOvUPzBaDlXFkmlaBPcW"), 628182.8587403364, string("RtSiYlSOALPDULRsgrFGQuD"));
    this->KEdafyHnQUdD(2130358417);
    this->oqIQgUGRqrtaY(true, 738283049, string("OkOJUaKZswxNRfGEYtViMwvJUwqPcYPqdnJvfrxQDDapzEToOKLJLTvSQnupjxjxNapAADCczXUXhzVJjeKwpKOoYsjjLpMCHYFLnYiuDrbnPqywuAvCuUcceFVzZcqozNXlhRrXYOgAMGyYzFqQTLNCqUrADbGsSgZZxBbqeHIwKCbgCxiyjuZkmtkvOtSgNiDfaLJbbxmGucAYcUdkRcqCNoLQdagOmAWUNMKanCTgfziZjVUEHQseI"));
    this->UOsLIfVXA(82292382);
    this->KoXORbYeQe(97632.144387516, -1414846598, string("TcQyAPlHNDRfkYAGCbZtIPNauVGXRebnRdPbObQqXwfoiYqwbRpPZhZNxGbbdsaLBxTLoIxEgyHLqngodyOANTQQOOgWaDFrqjSvzxXmtUAgtocVblcQZyoLVlJPkWJrIPDwxpldbYFFtnvoNWMqisjTmYwVKYhtvJAduSzecCqNexybmBlmnzwLrjTFrfCapEJzEvdpjfrvuzLWjEDmmxIvYqkywFpZQzxRbEotM"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eGqjotfpvTYx
{
public:
    double iKQNMjF;
    double FTogjREqndQTtOMB;
    string GtDEhZDpBNStrnT;
    bool ZhqMVgkhPyOoCVh;
    int wgsclzbupqAipkNx;
    double JoMrkUguiLb;

    eGqjotfpvTYx();
    void VoKgsv(bool BBMVQW, bool bSpSoFM, int aPeTpVEEQPoRcH, bool WpRPjaQiSfXB);
    bool LsfaBU(string EhhdkYpXOW, string XyylO, string ipAOyMuwstWGmfk, int ZKLAt);
    string dDSzVsHurndcVuRU(int ZwIcJmx, string ECgARQhKHoUHowTc, bool VtaKPBis);
    double LpVIyw();
    void dREhzgBzAdqK(string ReCBohqUmmxHLdlv, double uHzNIeiwvOEalGgJ, double aexaOmieyW, string sjXfabNO, int HXokokwCWarXh);
    void YTigHpooNeb(int FkDmlrb, int XjQQahKJnX, int SDAzNDSCbn);
    string FGGtnYPdttQUZgW(double fXRXJhCylrl, bool uqijxtgdYqvSyEy, double IZiKxIZzfy, bool uBPzWJYfT, int VdjPiLGZe);
protected:
    string FkvbPVTUVpeOtwN;
    string KNsTOz;
    int PNwVtRwSrPTthex;
    double QJHnTaIaZEojxXC;

    double APOCt(int eMllqFXFuNDIcV, int CDMkjvsvQzozM, int JhzXzqaNRxMLr, int UFsezrgITolnm, bool iTWMEzmW);
    int rrvZpygDlGMvhuB();
private:
    int ykHERRsjBJiZdDf;
    string qaQegeUbOEYNznbT;
    string AZKtXcemuUfIgPp;
    string ofdBxlvweWlroLz;

    void OJMaR(string OXUTRqCjDNaqt, string RcZmnDMZZTDJfsMf, bool prsBKAXmBATO, string ddOfc, int okuVCjPkuOUbsLD);
    double MxxMhw(bool WRwMARDb, string eErCdKPJtyyFyz, int OhpYyzMhTCmsxrz, int cbBXpNMna);
};

void eGqjotfpvTYx::VoKgsv(bool BBMVQW, bool bSpSoFM, int aPeTpVEEQPoRcH, bool WpRPjaQiSfXB)
{
    bool QmvGiKoqvSu = true;
    bool gePCo = false;
    int EQVoo = 1735906964;
    bool BzXlfYIp = true;

    for (int gmvltKGWOzxV = 1583682424; gmvltKGWOzxV > 0; gmvltKGWOzxV--) {
        WpRPjaQiSfXB = bSpSoFM;
        gePCo = ! gePCo;
        BBMVQW = bSpSoFM;
        gePCo = ! gePCo;
        QmvGiKoqvSu = ! BBMVQW;
        WpRPjaQiSfXB = gePCo;
        BzXlfYIp = ! BBMVQW;
        BzXlfYIp = bSpSoFM;
    }

    if (bSpSoFM != true) {
        for (int YohtV = 82751424; YohtV > 0; YohtV--) {
            QmvGiKoqvSu = ! WpRPjaQiSfXB;
            BzXlfYIp = gePCo;
        }
    }
}

bool eGqjotfpvTYx::LsfaBU(string EhhdkYpXOW, string XyylO, string ipAOyMuwstWGmfk, int ZKLAt)
{
    bool fVPpbYbPLMdMtXma = false;
    int aWeTehXpuFL = -190171042;
    string bchjF = string("GVuFteaOSafVzcrspcBWEvUhBjRAMGXLpwoWdkmoZVtaNDYecrYbCqmXLCbBNoDMkAaXjzOKARIBoufVIJBwJjfzCSjShAlyULxOPKjGIVQJhAvxtWJszeesovxHSiekKiiRXOgzebyN");
    string nCkEbWYkhldZ = string("lFIsWefHnrrJcpWcQeDCeARgsnwluoGuyCdpCkWIvmgYSGDQOFRANDVtRLUOsdWpojverKEFNdBpltvlaKKapRjRTukNnQefhmzjZOgdKLTHAqMUIWwCrufsCcFGOycDjygimKwCSVvQeWcXutOfIwTLaFZAvGPVWbpGxcRtGvQhqBNuPwgwTxWTIFA");
    string vKYjvlKgej = string("aLlgZsVNJlmqjpLfwnpmMKfRHemaTTatzilpuursqLIkEGduPVNnLClPmibduAzqqWYeXufbDFWwggBljKDJGIprtwBcQMQhvaIaqkihHgzirArYuNnMWgPkmQDKQZNQQLgPnZVqFpSMUgglRCNhNleKKnFfAJOquPAKMhaSlwCgFh");
    double NEFeFQ = -919712.1100699964;
    double hoEOzrRxjX = -625297.1565862672;
    string BRVFZCKHiiXKccF = string("UmeGDPJsqpOBMOoDHSnf");
    int NHKwMci = -743871011;
    bool YGaApJjz = false;

    for (int vhlascfPAJR = 826279676; vhlascfPAJR > 0; vhlascfPAJR--) {
        aWeTehXpuFL += aWeTehXpuFL;
    }

    if (BRVFZCKHiiXKccF <= string("ppEeyfdxpczORSwtsbeMzxoAiSXyOCGMvrJLzgrjhoayHVrNXoAZmQirdbmZtJgPIZbufZFIFpAsuwlgdqMlXAjJDTpkfYteycQzAVXeWbBxTdXYBhrBiLgRItWtHiIRBJxOvCyUpWmcqjQiTZStLHEfAVYWUdqAMzhqlsOKziawJGMRvQtSldazjvkzIXSBATXIjJqDSilcWTVkNIykMNXygDYvXiRZU")) {
        for (int GsBlvIF = 65622581; GsBlvIF > 0; GsBlvIF--) {
            bchjF += XyylO;
        }
    }

    if (fVPpbYbPLMdMtXma != false) {
        for (int cmVTEZ = 69455646; cmVTEZ > 0; cmVTEZ--) {
            XyylO += ipAOyMuwstWGmfk;
            vKYjvlKgej += nCkEbWYkhldZ;
            ZKLAt *= aWeTehXpuFL;
        }
    }

    return YGaApJjz;
}

string eGqjotfpvTYx::dDSzVsHurndcVuRU(int ZwIcJmx, string ECgARQhKHoUHowTc, bool VtaKPBis)
{
    bool VMRverbFV = false;
    double aepAcahrdZOCD = -320285.4526310753;
    string drlvCRNrjUhqqR = string("abhepGsJMABpykTYJbLXkXcUxhauKHUGwBHPQySPiadIePNQEEpPDqwtmDnxYMoNDriJWTScFnZuqligSiftWpACgQYYbfzXOfqIANKUJPTBcBjU");

    for (int VMzHSLgNjsYw = 2114662966; VMzHSLgNjsYw > 0; VMzHSLgNjsYw--) {
        aepAcahrdZOCD = aepAcahrdZOCD;
        VMRverbFV = ! VMRverbFV;
    }

    if (aepAcahrdZOCD == -320285.4526310753) {
        for (int CEHcGlfx = 1273005527; CEHcGlfx > 0; CEHcGlfx--) {
            continue;
        }
    }

    for (int AiaTyPSh = 1308234639; AiaTyPSh > 0; AiaTyPSh--) {
        VMRverbFV = ! VtaKPBis;
    }

    for (int vMssiLjXS = 1984316588; vMssiLjXS > 0; vMssiLjXS--) {
        aepAcahrdZOCD += aepAcahrdZOCD;
    }

    if (ECgARQhKHoUHowTc == string("abhepGsJMABpykTYJbLXkXcUxhauKHUGwBHPQySPiadIePNQEEpPDqwtmDnxYMoNDriJWTScFnZuqligSiftWpACgQYYbfzXOfqIANKUJPTBcBjU")) {
        for (int AGANDR = 727765705; AGANDR > 0; AGANDR--) {
            VtaKPBis = ! VtaKPBis;
        }
    }

    for (int XOWVD = 20962188; XOWVD > 0; XOWVD--) {
        VtaKPBis = ! VMRverbFV;
    }

    return drlvCRNrjUhqqR;
}

double eGqjotfpvTYx::LpVIyw()
{
    bool GVTocsw = false;
    string VjKVnrFuqr = string("n");
    double BtFdW = 847365.4064560875;
    bool ymjfywsoiKA = true;
    double OLqcicOEpD = 756156.9211085706;
    string RSerIM = string("yPEQeICPPPIfDVbPywKAEFTYQgrUTpgHgYZCqNfgfNbaEHwSFXudorPzlxvIxvERTGLwuoZSODBeUcXcQMwncFJSIgtsGQiXSFmMCICIpBrALYOkRjrRYfdLNvhqGoibiBguHJLYkqdbhNNXyRYkYSIERyzzMwYoTFCeFdbbdDfuUYjfb");
    string WnnkIRJSNrRsQI = string("HqACXpYskQnlYMHjmDOYKFdHKKSuiMpWWeTXHmvCkFBsFAstlBuUrJxtUXtJfKcqsEndAXYvGEqNBMhEmUZhFS");
    double jrdZEwgOkuZia = -877012.1708209369;

    if (jrdZEwgOkuZia < -877012.1708209369) {
        for (int RuiWyQt = 177912412; RuiWyQt > 0; RuiWyQt--) {
            continue;
        }
    }

    return jrdZEwgOkuZia;
}

void eGqjotfpvTYx::dREhzgBzAdqK(string ReCBohqUmmxHLdlv, double uHzNIeiwvOEalGgJ, double aexaOmieyW, string sjXfabNO, int HXokokwCWarXh)
{
    int lMwJFPe = -1994363886;
    bool YixwgYqgpmB = false;

    for (int wtlazYzf = 1467539430; wtlazYzf > 0; wtlazYzf--) {
        lMwJFPe += HXokokwCWarXh;
    }

    for (int NXwfldwck = 482243812; NXwfldwck > 0; NXwfldwck--) {
        lMwJFPe -= HXokokwCWarXh;
    }

    for (int YxuzNDXstBz = 947191066; YxuzNDXstBz > 0; YxuzNDXstBz--) {
        sjXfabNO = sjXfabNO;
        HXokokwCWarXh /= HXokokwCWarXh;
        aexaOmieyW = uHzNIeiwvOEalGgJ;
    }

    for (int NWNwnCNIRl = 1060782099; NWNwnCNIRl > 0; NWNwnCNIRl--) {
        continue;
    }

    for (int IPyHKAlYa = 1073398633; IPyHKAlYa > 0; IPyHKAlYa--) {
        continue;
    }
}

void eGqjotfpvTYx::YTigHpooNeb(int FkDmlrb, int XjQQahKJnX, int SDAzNDSCbn)
{
    string UsUszss = string("FaRJCBcLbyQpwTNcatLMfQCZpgeLExXrYdNJbhvgxrhyOISSDUztdjKGhpFrxeRazzhYupkcAVIKxHkHeVsaxrBBGkRsTycvfWZuJrdVgUjmOSTKTOITeRgSyFeBtmxJZROCPtXRpsTRkiiyMpiyPyEsnAswvAFHMkPwvjfiwEpuTdQgIIqiKdVqVnUEiQeYAlRxUctDbPKvXHpcaPStBnpnaNgMwZhyKYc");
    bool bHyLG = false;
    int EzzHrRjCqXBUnU = -1462518014;
}

string eGqjotfpvTYx::FGGtnYPdttQUZgW(double fXRXJhCylrl, bool uqijxtgdYqvSyEy, double IZiKxIZzfy, bool uBPzWJYfT, int VdjPiLGZe)
{
    string KECdRfgWcaGx = string("xVMJdfrHfwzbWFRGmBAcjxUxjEwauIyyOasIWyIFAGVdQSKmgFEMKpTxEVqSGykaHFMwwdaKJgNlSoSoDiiWNIeCQuFFHMJADwrOyGgIPpKNKqmAuMTgouoxaUusiSIaxODNTTjWlmVOJQsijFIjGOngKGeJnwNyeuowgtzPPKK");
    bool bcdhZo = true;
    int VKdSCYJOwIKCXEYF = 2002629274;
    string hTvPmhuFfdz = string("l");
    double SDMrVtpv = 936668.6021857465;
    bool eflDKWyuMoSRPRyU = false;
    bool STWHhIVxVBPFwJu = false;
    double ajLvydhLTMWUL = 1036704.4009764413;
    bool zPcQIqqdMWcN = true;

    for (int vWntUmPHVolCw = 985378119; vWntUmPHVolCw > 0; vWntUmPHVolCw--) {
        continue;
    }

    if (STWHhIVxVBPFwJu != false) {
        for (int bQiVLZEmtPWPm = 1387957665; bQiVLZEmtPWPm > 0; bQiVLZEmtPWPm--) {
            continue;
        }
    }

    if (hTvPmhuFfdz >= string("xVMJdfrHfwzbWFRGmBAcjxUxjEwauIyyOasIWyIFAGVdQSKmgFEMKpTxEVqSGykaHFMwwdaKJgNlSoSoDiiWNIeCQuFFHMJADwrOyGgIPpKNKqmAuMTgouoxaUusiSIaxODNTTjWlmVOJQsijFIjGOngKGeJnwNyeuowgtzPPKK")) {
        for (int aRbXLYMgUp = 1683576861; aRbXLYMgUp > 0; aRbXLYMgUp--) {
            uBPzWJYfT = bcdhZo;
        }
    }

    if (IZiKxIZzfy <= 751712.5192758483) {
        for (int SORpIe = 365855243; SORpIe > 0; SORpIe--) {
            ajLvydhLTMWUL -= IZiKxIZzfy;
            uBPzWJYfT = uqijxtgdYqvSyEy;
            uBPzWJYfT = ! STWHhIVxVBPFwJu;
            eflDKWyuMoSRPRyU = zPcQIqqdMWcN;
        }
    }

    if (VKdSCYJOwIKCXEYF != 533899940) {
        for (int jlTTRuTcFWFgxT = 1723634999; jlTTRuTcFWFgxT > 0; jlTTRuTcFWFgxT--) {
            zPcQIqqdMWcN = ! zPcQIqqdMWcN;
            uBPzWJYfT = ! uBPzWJYfT;
            STWHhIVxVBPFwJu = ! STWHhIVxVBPFwJu;
        }
    }

    return hTvPmhuFfdz;
}

double eGqjotfpvTYx::APOCt(int eMllqFXFuNDIcV, int CDMkjvsvQzozM, int JhzXzqaNRxMLr, int UFsezrgITolnm, bool iTWMEzmW)
{
    bool NjlZTwajwjSJX = false;
    bool jcbPIZCbs = true;
    string lXJjWnPCa = string("ZrOgmTFvlEFdAQaMPRucgkOBFEJGoxNSJnWksgopCAsgKwXJZvYsxhmtwZlhNlqIvNipVZtbQuwrLfwFYvwhZgVqiPvKZLxQFiXoFBcoqyEJuyDQqygtLuuiEjbOWbwvtxSLDuwcmLjZqfoytWDcThYkxpUswDvaLqBPwrHDTZPRUUtDRNWMAkDGnFVCDDQnmkZOBbkknDsXOHjizmkIhxCXbuW");
    bool SRwBFMnYq = false;

    return 746220.2886499546;
}

int eGqjotfpvTYx::rrvZpygDlGMvhuB()
{
    string hTNDCzLHoZGHlzY = string("qISPyDktct");
    double tLDFYiG = 901275.8758947692;
    bool XVxVWH = false;
    string GeznHIDQeCO = string("YWrcBuMEGgfbnHxCcVMcEBLBeKAGQXSaHQnDgIlVWsNampWKxTOZxLaLbHsGoJgxTqSWPQLTvWsVMdBtud");
    bool rulyXHWxmX = true;
    int xFyegPWXnfp = -74656608;
    bool igGlBvBMJpLvm = false;
    bool AdeFiRGIi = true;
    double gWuUB = -59250.73154398034;
    string qZXLnD = string("TusYSZzVrKFziliUDyoDNAturnhkoGggnRLXUNwBAMEEfeIvAraf");

    for (int AMgPA = 10597240; AMgPA > 0; AMgPA--) {
        XVxVWH = ! rulyXHWxmX;
        rulyXHWxmX = AdeFiRGIi;
        qZXLnD += qZXLnD;
        XVxVWH = ! XVxVWH;
        AdeFiRGIi = ! XVxVWH;
    }

    for (int fsESDsdVVcZCDoZ = 279797365; fsESDsdVVcZCDoZ > 0; fsESDsdVVcZCDoZ--) {
        continue;
    }

    for (int dmThL = 1394394987; dmThL > 0; dmThL--) {
        continue;
    }

    if (rulyXHWxmX == true) {
        for (int adxgwbEb = 246218722; adxgwbEb > 0; adxgwbEb--) {
            continue;
        }
    }

    if (igGlBvBMJpLvm == true) {
        for (int haJASYKBGrpSGgRz = 1712061781; haJASYKBGrpSGgRz > 0; haJASYKBGrpSGgRz--) {
            continue;
        }
    }

    return xFyegPWXnfp;
}

void eGqjotfpvTYx::OJMaR(string OXUTRqCjDNaqt, string RcZmnDMZZTDJfsMf, bool prsBKAXmBATO, string ddOfc, int okuVCjPkuOUbsLD)
{
    double mdjlCdBl = -148348.0685185173;
    string ndyeWiwDPYLpAHE = string("XPXyHPEDiMrsNbNwSFtokBClrKgdzkFiCWvSkkHObnJlbBVNAIudUXbvsLnZQEwpuARtigLaUdVZlhdD");
    string MVFxyqKanUQ = string("tLXmabUkdplKQiOFyMPDUngoEOLxjGFhopMHukKSdemVlrrnCBFCNsoQNinWLiamLoUyHTWhlsBXbloVNmFagCESnvmejnTlrSfXuxgCXjvSIJNzeNaExBOfAljZdTTgYEpREVUIjWtcGehZajOAHcEtJINXKpIyMLfgTTGJmKorSdWCVieBsiJQDkRmClPdpvualhkgWYSbYoEgPzADwMyOeJI");
    double BzhjQePTycIdnL = 284855.3410894384;
    string MKpMqQirrkVoK = string("OpiavomDQFuaywaCImiFSwLkrdVaNjqoPzGPhFPvSPwVfvjYcZmoVDTrDNdyLNrJFsTHikzxKojCLdqBmRtCwUzmhsBwKXUYnVChKKpC");

    for (int dPxDxzFTDGbyij = 864506856; dPxDxzFTDGbyij > 0; dPxDxzFTDGbyij--) {
        MKpMqQirrkVoK += MKpMqQirrkVoK;
        RcZmnDMZZTDJfsMf += ddOfc;
    }

    if (ddOfc >= string("cbfxxXldPsoIwGWWOjOiixJVxKGamtbxSeWXZVXyPQHCFwfJidNCfuNpOQNHfGqOxcloZcLm")) {
        for (int ZEIAMVuyjaT = 1403989602; ZEIAMVuyjaT > 0; ZEIAMVuyjaT--) {
            MVFxyqKanUQ += RcZmnDMZZTDJfsMf;
            BzhjQePTycIdnL = mdjlCdBl;
        }
    }

    for (int CabCsrhJ = 1276804106; CabCsrhJ > 0; CabCsrhJ--) {
        ndyeWiwDPYLpAHE = RcZmnDMZZTDJfsMf;
    }

    for (int jWaLJXRWsUMt = 338436457; jWaLJXRWsUMt > 0; jWaLJXRWsUMt--) {
        RcZmnDMZZTDJfsMf = RcZmnDMZZTDJfsMf;
        MVFxyqKanUQ += OXUTRqCjDNaqt;
        ddOfc = ndyeWiwDPYLpAHE;
        MKpMqQirrkVoK += MKpMqQirrkVoK;
    }

    for (int YqMSpdBf = 1541497932; YqMSpdBf > 0; YqMSpdBf--) {
        OXUTRqCjDNaqt = OXUTRqCjDNaqt;
        ndyeWiwDPYLpAHE += ddOfc;
    }
}

double eGqjotfpvTYx::MxxMhw(bool WRwMARDb, string eErCdKPJtyyFyz, int OhpYyzMhTCmsxrz, int cbBXpNMna)
{
    int ProKlaBs = -1755517958;
    double zEfipIOYM = -677459.7206436626;
    double qhjITXgJUv = -474691.21384465;
    string dyTPtiFPBeJiE = string("tuejgcBPnMKF");
    int nREmvUhslZ = -104033662;
    int OnhDXTXV = -1006252171;
    int ajiuUfw = 809057507;
    bool SZOdEcrRoPjIK = false;
    int BoUggCnN = -693360962;
    bool wWDTUNDxOBSQ = false;

    if (ProKlaBs >= -482319493) {
        for (int xErWHmzQbujFjp = 5326762; xErWHmzQbujFjp > 0; xErWHmzQbujFjp--) {
            OnhDXTXV /= ajiuUfw;
        }
    }

    for (int pAuymUTsedogbhR = 861669449; pAuymUTsedogbhR > 0; pAuymUTsedogbhR--) {
        continue;
    }

    if (ajiuUfw == -104033662) {
        for (int CrJlgubxvYTdJ = 1812586936; CrJlgubxvYTdJ > 0; CrJlgubxvYTdJ--) {
            ProKlaBs *= cbBXpNMna;
        }
    }

    if (cbBXpNMna > -1755517958) {
        for (int RzacIeX = 813014327; RzacIeX > 0; RzacIeX--) {
            continue;
        }
    }

    for (int GPApMcaO = 517732703; GPApMcaO > 0; GPApMcaO--) {
        continue;
    }

    return qhjITXgJUv;
}

eGqjotfpvTYx::eGqjotfpvTYx()
{
    this->VoKgsv(true, true, 1216183091, false);
    this->LsfaBU(string("sYPHKrymTDZndxwUQilvHbpRlUAaVqsuZcwGlRaCxAMiKktVohCGlLRLgOtEnqKzArAKDQZvpGOnb"), string("BqWiDUucndzUBPRAABfCEuEfGakprJPhkTrBgNPnvkwftyfPadRbPYcZxmejQtQLrqLbniRDskNIgeYSxpMWGvZwlaMDuCffJhXwBxwbqQTuilqRUISqBxpltQMXjyKCasnKdgmuWPgNFRHNDksTdrwfLZHETAbYyMXHPDSQlisUwlCbwsiKwQRsFCipArsRaMxHlLqotcOGQyEpvEntbHSeiaOIsqggYEhTpcbNbFrBUCZFYxadqJP"), string("ppEeyfdxpczORSwtsbeMzxoAiSXyOCGMvrJLzgrjhoayHVrNXoAZmQirdbmZtJgPIZbufZFIFpAsuwlgdqMlXAjJDTpkfYteycQzAVXeWbBxTdXYBhrBiLgRItWtHiIRBJxOvCyUpWmcqjQiTZStLHEfAVYWUdqAMzhqlsOKziawJGMRvQtSldazjvkzIXSBATXIjJqDSilcWTVkNIykMNXygDYvXiRZU"), -1665813530);
    this->dDSzVsHurndcVuRU(1376632528, string("ydolxRseHYDXjyNezEaaAXBgELrAsBfvhbgtreyKXacxMEHrjYENHrdAboopLDPhQvdcAfAqjGtBIddPSwGfNtyoyHOcOrcySPizHqyCiOZBtPXdXTGTMlrbKBYsShThswGyexijpYmMjXVllUSTuBytXIeMTLLKgAfuYCCHthPoPMgCfbTGipBmBSYSUrprjtgonwj"), true);
    this->LpVIyw();
    this->dREhzgBzAdqK(string("BbEGpspuZrZxSJSOSvaJkQirwDZuRXbzXhiez"), 998760.6442833539, 68892.95063670778, string("ChsJLwZjcdRxMEmvnnTeyzlDXYYWHmddNZbJNZAbmARoeIHcYgwIjqGyxgBttAmSpkpWCJAXrfIxOlsRdysTWOxydBAndXAQkpRsXchzvzbrUUtrBmQmdSkzfWxzDtNfvzxRyTra"), 1063738584);
    this->YTigHpooNeb(248971989, 1878918063, -1702442932);
    this->FGGtnYPdttQUZgW(751712.5192758483, true, -281433.33038656233, false, 533899940);
    this->APOCt(-535948819, 1403874541, 1425787280, 1547363428, false);
    this->rrvZpygDlGMvhuB();
    this->OJMaR(string("rpEkudulWxlzxmoOycBeGruMNOcSFTKtS"), string("cbfxxXldPsoIwGWWOjOiixJVxKGamtbxSeWXZVXyPQHCFwfJidNCfuNpOQNHfGqOxcloZcLm"), true, string("cRKqrCXVIdaaKYKjJrnVixBOYynINQNvpUCCLqAPGYYZfIBJDEEaCTndafrrOeGRhmpwihAYsifeURebjSsVMRvWBIJBDXDYVCuRkhyfPuzMmJlFGIWHyMEmgqiYOhzucnfXxRKpkIXCBIveilFrekacNLWiWbmpwRuAqDBsRRmWbVIFocITkTRyFerFQuPbSsOmNdZJlpMudqYpNABiTKZWcPHlqVctdqkeK"), -2023373593);
    this->MxxMhw(true, string("hHEJaniNaWShvSyyuvWdJbEHyD"), -482319493, 974407011);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wpImxCrQnHeRDcWJ
{
public:
    int ttBVpKcSsetQpagr;
    bool esxjdFmASYbLQ;

    wpImxCrQnHeRDcWJ();
    double jpIisFS(double NAsWWzcV, string MvrBUwCcal, string WHsDZaTIDCPwTy);
protected:
    bool pPbcGpKsDvGeqsk;
    int gyStjYlS;
    string BKbti;

    string bkwAQHvn(string iZNQlTWYpN, int dkyxEpTwksPc);
    bool tuMBkRXDStN(int YmUtrhJhIfdbcqgx);
    int DhHQWmFTvyPTNTM(double wvufJUGcApyMKw);
    void LVwceqMlbcjZS(bool ImOvR, double PDIrRQe, double nhuksdhym, bool zPcaYweLESchlhAo, double rZYDMwPurulV);
    int ixubl(double oiwCnGcJId);
private:
    string JfIBYKYgV;
    double aQjuOhrAciluJw;

    string BkjjUzrZA(double EjJZOvqgqXu, double nyMrlLr, string VZxsrcOdxmsMhp, string RFduMPK, bool olzxdXONSoWmas);
    void tNjFjfUEZskwbxu(string tvJmSgtFIZQYgauI, int tPYHyXnBlbN, bool jpWVF, bool WGXMtgiQI, string pbfucNPB);
    int TNwUhirCScWYBonz(bool lqJfOjLXTHSHF, bool UGNpawWPvHlOD);
    string gxtDG(string qMLVjXkmuplqMOvO, string kcpLVmkmacWb, double BbBOepHZSy, string XCcTBhBD, double ubXIf);
    void msGMa(string QobQUrqVDXlO, int nmeeaevwJSh, string YuRVX, string nBtdHsYiR, string JoJojzcfmrV);
    void DQkeYoDZamsU(string CeTvDSfHsbNlUk, double NIGalFiB, bool hLjXPt, int TCSpIbslLBjJc);
    bool dQcUM(double dXCmghNhPH, string pfHAvM, int lGONSibTOX);
};

double wpImxCrQnHeRDcWJ::jpIisFS(double NAsWWzcV, string MvrBUwCcal, string WHsDZaTIDCPwTy)
{
    bool gzTVEuND = false;
    bool MJQiLQKojuntZD = false;
    double BYAkiNPeaiSOsuld = 122207.834384494;
    int GkZGYDacFG = 348334293;
    string NSsYLE = string("ShPGigKfiOdYVrfJSCCPWWiWDClRrYdJnYNBChczrWhhqYGwsTeNgJNtnTpvrLXqEelDfsTpQRhwJlFVnmqEqNQOwoMIPGzRqKZIXuExmduyzreHHLyfZpvIJVqKIqxjydecdeyxabJXSpKEgIMEOrRsui");
    bool bNhmhFaiLWTnfjm = true;
    bool JbeZRgVmHLIBD = false;

    for (int VlJOHQptrwAj = 1712991170; VlJOHQptrwAj > 0; VlJOHQptrwAj--) {
        JbeZRgVmHLIBD = gzTVEuND;
        MvrBUwCcal = WHsDZaTIDCPwTy;
    }

    for (int zrjjGGGgndWXrosZ = 381141293; zrjjGGGgndWXrosZ > 0; zrjjGGGgndWXrosZ--) {
        JbeZRgVmHLIBD = ! bNhmhFaiLWTnfjm;
        MJQiLQKojuntZD = gzTVEuND;
    }

    for (int KiMYGzpUFMxq = 1901108367; KiMYGzpUFMxq > 0; KiMYGzpUFMxq--) {
        continue;
    }

    return BYAkiNPeaiSOsuld;
}

string wpImxCrQnHeRDcWJ::bkwAQHvn(string iZNQlTWYpN, int dkyxEpTwksPc)
{
    double xbzKcykVxf = -689160.5628617295;
    double pbyKmlb = 302537.25991670165;
    int aFYRACttsGlQr = 2132092255;
    int dEUNt = 375925945;
    double xgNwtH = 892895.5675900612;
    bool YimmWoLggHWvDuDF = true;
    bool NjXzYs = false;
    bool ZHyKBNfP = false;

    return iZNQlTWYpN;
}

bool wpImxCrQnHeRDcWJ::tuMBkRXDStN(int YmUtrhJhIfdbcqgx)
{
    double NeAmvBempctN = 856502.6476327088;

    return false;
}

int wpImxCrQnHeRDcWJ::DhHQWmFTvyPTNTM(double wvufJUGcApyMKw)
{
    int fVmTTQqS = -1737189828;
    double LnEMRSR = 734671.1651286079;
    double RDMSAUSX = 741606.4102408048;
    bool GbLElYT = true;
    bool ujonTevNO = true;
    bool AwtKikgUGgn = true;
    int YEAxJM = -1501172836;
    int NBKCA = 215419205;
    bool SFWZxUilJX = false;

    for (int KQeQufGJDyHOzJXs = 948900209; KQeQufGJDyHOzJXs > 0; KQeQufGJDyHOzJXs--) {
        GbLElYT = ! ujonTevNO;
        RDMSAUSX += LnEMRSR;
    }

    return NBKCA;
}

void wpImxCrQnHeRDcWJ::LVwceqMlbcjZS(bool ImOvR, double PDIrRQe, double nhuksdhym, bool zPcaYweLESchlhAo, double rZYDMwPurulV)
{
    int TEdHGovt = 1796962327;
    bool nXAfD = true;
    int VvkiKpWrpQk = -1630488020;
    double pcYuyLwIc = 63015.17991398396;
    int pSmHIigYArVaFq = -2109369045;
    bool lxoctIVfDawuPbR = false;
    bool cbQFbG = true;
    int ydkqPcOXTzZE = -202033246;
    int bdgfef = 814120223;
    string kJcqoZb = string("DSfcZCYkrHwbRDoeWVPfBDlRhZaREiNKpExWrDTUjXwiXGhSMcOvTZQGyiFwuYpAehLocQsxnSxfgzcCzLLYpDtXhyrOHooRJgUzxPelxdnlJSvXJLIzdPiGeMYgIODdzFePXogogQfGD");

    if (TEdHGovt < 1796962327) {
        for (int nPnlxcYSkh = 1956730383; nPnlxcYSkh > 0; nPnlxcYSkh--) {
            nhuksdhym *= PDIrRQe;
            ImOvR = ! cbQFbG;
            ydkqPcOXTzZE -= TEdHGovt;
            pSmHIigYArVaFq /= TEdHGovt;
        }
    }

    for (int KaOfqZscDKLICjj = 1858936319; KaOfqZscDKLICjj > 0; KaOfqZscDKLICjj--) {
        TEdHGovt *= TEdHGovt;
        bdgfef -= TEdHGovt;
        nXAfD = ! lxoctIVfDawuPbR;
    }

    for (int JRFMmMMLIxtGPme = 1714596447; JRFMmMMLIxtGPme > 0; JRFMmMMLIxtGPme--) {
        zPcaYweLESchlhAo = nXAfD;
    }

    if (pSmHIigYArVaFq != 814120223) {
        for (int eAWas = 1056507010; eAWas > 0; eAWas--) {
            continue;
        }
    }
}

int wpImxCrQnHeRDcWJ::ixubl(double oiwCnGcJId)
{
    string LjmrTbzpsghEdjY = string("PHBJOpACgZqTtgczrFTFbjOvpIWkOeJauVqYMKFjaPnjVHvBVJykSQdBWpTFwgLlPcavoQEfwovctjhaUoUeucjgUULlGUEDmxvasB");
    int lwiFCp = 374511157;
    string hatxmhHHeJ = string("vMHPwVdEkCmMTalnNDqGdOeLsMDhxQQRfoiHSHnIKghEuNXVqlEAtzMTXUxcHUlkcouHbWXWyYidyHo");

    return lwiFCp;
}

string wpImxCrQnHeRDcWJ::BkjjUzrZA(double EjJZOvqgqXu, double nyMrlLr, string VZxsrcOdxmsMhp, string RFduMPK, bool olzxdXONSoWmas)
{
    bool KyYsRMyc = false;
    bool xtaUurlgfyfM = false;
    int rJxCFepjcEsH = -673254720;
    bool RDlmp = true;

    for (int HYupQHBEYJcSVFy = 1805213009; HYupQHBEYJcSVFy > 0; HYupQHBEYJcSVFy--) {
        olzxdXONSoWmas = olzxdXONSoWmas;
    }

    return RFduMPK;
}

void wpImxCrQnHeRDcWJ::tNjFjfUEZskwbxu(string tvJmSgtFIZQYgauI, int tPYHyXnBlbN, bool jpWVF, bool WGXMtgiQI, string pbfucNPB)
{
    int hWIMLhgSFZ = -1369698573;
    string ALYqbJEFOEQ = string("exHSbrliGLxEoUYPQMHBWEvQchItWyDvbBnfnfgiaatYEFpsknSgCdrMOLokaDUNOISGhywOOTgzrFNzvKGDzzpAiqHukAuIWkibOYmeEaLrteZYFouFoHIlzeCuqOVIJBDiUgOTKnzfiayfgwBXkoiPgMyZGavelxJEqKMshskkzSxpaoNyXpWcRypcTnuCJSnGfOPDhAWGsMbrjzKsqwbXqzrGFNGRciEVZyjSofRbJsVJQj");
    bool RiIxWRxD = false;
    double wFdMMAWpSYiRzCc = -613247.22937099;
    int KiWfUabPafLgT = -203981178;
    string nvNUTzZQbmiyUQIw = string("fbt");
    int pkDHR = -1865828504;
    string AuJtOTnaBBeoLOH = string("ULmQHDMTtfTRcQvXNGtdMwJewUfAQSmnsRrXx");

    if (jpWVF == false) {
        for (int GUQhtzKGdmo = 1116224472; GUQhtzKGdmo > 0; GUQhtzKGdmo--) {
            tvJmSgtFIZQYgauI += ALYqbJEFOEQ;
            ALYqbJEFOEQ = nvNUTzZQbmiyUQIw;
        }
    }

    for (int dnwxacTNusRG = 1620476172; dnwxacTNusRG > 0; dnwxacTNusRG--) {
        AuJtOTnaBBeoLOH = nvNUTzZQbmiyUQIw;
    }

    for (int SAsArFmFzqCfZAM = 78442983; SAsArFmFzqCfZAM > 0; SAsArFmFzqCfZAM--) {
        pkDHR += hWIMLhgSFZ;
        tPYHyXnBlbN /= tPYHyXnBlbN;
    }

    for (int TWdlxZ = 1632120953; TWdlxZ > 0; TWdlxZ--) {
        KiWfUabPafLgT *= hWIMLhgSFZ;
        AuJtOTnaBBeoLOH = AuJtOTnaBBeoLOH;
        AuJtOTnaBBeoLOH = tvJmSgtFIZQYgauI;
        KiWfUabPafLgT /= KiWfUabPafLgT;
    }
}

int wpImxCrQnHeRDcWJ::TNwUhirCScWYBonz(bool lqJfOjLXTHSHF, bool UGNpawWPvHlOD)
{
    double ihuABVG = -404134.2661126113;
    bool NvOKvyRqm = false;
    double fzMzIOPAesLujXu = 317215.3540668307;
    int VLGMFGeYePQ = -746246341;
    int izHAToRJsbIpiQ = 832871293;

    if (ihuABVG >= -404134.2661126113) {
        for (int SVFeH = 1621303919; SVFeH > 0; SVFeH--) {
            continue;
        }
    }

    if (fzMzIOPAesLujXu != -404134.2661126113) {
        for (int RnmPiFrayUQnYD = 62406347; RnmPiFrayUQnYD > 0; RnmPiFrayUQnYD--) {
            lqJfOjLXTHSHF = UGNpawWPvHlOD;
            UGNpawWPvHlOD = lqJfOjLXTHSHF;
        }
    }

    for (int gdmUgTCSbfTmwgUp = 1629126611; gdmUgTCSbfTmwgUp > 0; gdmUgTCSbfTmwgUp--) {
        continue;
    }

    for (int KheFGb = 1335621848; KheFGb > 0; KheFGb--) {
        continue;
    }

    return izHAToRJsbIpiQ;
}

string wpImxCrQnHeRDcWJ::gxtDG(string qMLVjXkmuplqMOvO, string kcpLVmkmacWb, double BbBOepHZSy, string XCcTBhBD, double ubXIf)
{
    string jIxRPWlDxpqbr = string("gMFgLBhGCdbzWqsAnlsvFOXktTedArKIzuiwpyYwlcLErhxJjItdNMKPjNODLewtcsTDmNUCDkFP");
    double ITDrzD = -44465.69300897505;
    bool OTOhtjM = false;
    double lTtNCeaaQ = -542484.9631282855;
    bool eXgyDCcHHpMLdY = true;

    for (int KkpJjhBgP = 2054602322; KkpJjhBgP > 0; KkpJjhBgP--) {
        XCcTBhBD += kcpLVmkmacWb;
        qMLVjXkmuplqMOvO = qMLVjXkmuplqMOvO;
        XCcTBhBD += XCcTBhBD;
    }

    for (int EyQPKsNNClI = 1018572142; EyQPKsNNClI > 0; EyQPKsNNClI--) {
        lTtNCeaaQ = ubXIf;
        ITDrzD /= lTtNCeaaQ;
        jIxRPWlDxpqbr = kcpLVmkmacWb;
        kcpLVmkmacWb = qMLVjXkmuplqMOvO;
        ubXIf += BbBOepHZSy;
    }

    if (jIxRPWlDxpqbr == string("gMFgLBhGCdbzWqsAnlsvFOXktTedArKIzuiwpyYwlcLErhxJjItdNMKPjNODLewtcsTDmNUCDkFP")) {
        for (int NroSGNjvzDdLGi = 953038107; NroSGNjvzDdLGi > 0; NroSGNjvzDdLGi--) {
            ITDrzD -= ITDrzD;
        }
    }

    return jIxRPWlDxpqbr;
}

void wpImxCrQnHeRDcWJ::msGMa(string QobQUrqVDXlO, int nmeeaevwJSh, string YuRVX, string nBtdHsYiR, string JoJojzcfmrV)
{
    bool MRyRYEBecfu = false;
    int dXChFEWFTaEgIpVY = -677394908;
    int CQmowY = -1294244243;
    bool cjBaowEdWerfc = true;
    int BFhQUpxOLW = 2009045119;

    for (int ZKxFXfN = 1803496704; ZKxFXfN > 0; ZKxFXfN--) {
        continue;
    }

    if (dXChFEWFTaEgIpVY >= -1294244243) {
        for (int RbmwK = 1615673511; RbmwK > 0; RbmwK--) {
            nBtdHsYiR = nBtdHsYiR;
            BFhQUpxOLW -= dXChFEWFTaEgIpVY;
            cjBaowEdWerfc = MRyRYEBecfu;
        }
    }

    if (nmeeaevwJSh != -1294244243) {
        for (int jctPzeEsRrNG = 2025998141; jctPzeEsRrNG > 0; jctPzeEsRrNG--) {
            continue;
        }
    }
}

void wpImxCrQnHeRDcWJ::DQkeYoDZamsU(string CeTvDSfHsbNlUk, double NIGalFiB, bool hLjXPt, int TCSpIbslLBjJc)
{
    string uvLlAkii = string("lhCUFkryINrbcfSdrWjWcWOJTeKKEZoyVYUvL");
    int QQZukekYMEbsuf = -1504871266;
    int LHtiZnLgc = 1161870127;
    double YayAmfzNNgAEuqRT = -633845.0217508826;
    int lQDAINSHFuzL = 1082684856;

    for (int JdRuSc = 747306362; JdRuSc > 0; JdRuSc--) {
        uvLlAkii = CeTvDSfHsbNlUk;
        lQDAINSHFuzL /= TCSpIbslLBjJc;
    }

    for (int zzOGGsxkpdYfzCH = 1201041695; zzOGGsxkpdYfzCH > 0; zzOGGsxkpdYfzCH--) {
        LHtiZnLgc /= LHtiZnLgc;
    }

    for (int hWjdnbSJVoxQJ = 1121939168; hWjdnbSJVoxQJ > 0; hWjdnbSJVoxQJ--) {
        lQDAINSHFuzL -= LHtiZnLgc;
    }

    for (int vHxKlbkb = 1873181417; vHxKlbkb > 0; vHxKlbkb--) {
        lQDAINSHFuzL = LHtiZnLgc;
        lQDAINSHFuzL -= TCSpIbslLBjJc;
    }

    for (int HUhtJKV = 320166606; HUhtJKV > 0; HUhtJKV--) {
        CeTvDSfHsbNlUk = CeTvDSfHsbNlUk;
        QQZukekYMEbsuf *= QQZukekYMEbsuf;
        hLjXPt = ! hLjXPt;
    }
}

bool wpImxCrQnHeRDcWJ::dQcUM(double dXCmghNhPH, string pfHAvM, int lGONSibTOX)
{
    bool TRyBtYccsbj = false;
    double quaBRzppb = -850246.9639107264;
    double RqLcRey = -473398.9463960811;
    int UvAghbQxVqBNiO = 754118762;

    for (int vmUBAMA = 594888076; vmUBAMA > 0; vmUBAMA--) {
        dXCmghNhPH -= dXCmghNhPH;
    }

    for (int VmrIVaPJetxBN = 125822883; VmrIVaPJetxBN > 0; VmrIVaPJetxBN--) {
        pfHAvM += pfHAvM;
    }

    for (int fqLrxZBXGB = 617734003; fqLrxZBXGB > 0; fqLrxZBXGB--) {
        dXCmghNhPH += dXCmghNhPH;
    }

    return TRyBtYccsbj;
}

wpImxCrQnHeRDcWJ::wpImxCrQnHeRDcWJ()
{
    this->jpIisFS(550024.3914593256, string("FNzvZdMHLhagMawbrSyiPKNKpQFLjnkyESbxFdwcECQfUevLkstQgbzHPeVNmWGtJStVZEGNeWaWwZKWkbzhCPUaa"), string("nmi"));
    this->bkwAQHvn(string("FAvHptleaFhaIDUuEzAixHqTNZAJdkGgLGcRYEtVgCVViKgzPKUMCGsSvUuolOHMABuxcXeyuyxMQUCCDEeoLOSvSjmVMQDHugeJqyGlKXHxIfXugLgPTIeu"), -1310918860);
    this->tuMBkRXDStN(518729526);
    this->DhHQWmFTvyPTNTM(-497093.50288652047);
    this->LVwceqMlbcjZS(true, -220515.38728004476, -142154.0158671779, true, -538241.746483194);
    this->ixubl(436505.7520986359);
    this->BkjjUzrZA(-950467.781636533, 676376.8353960913, string("LmvFEjwPOBiUKOby"), string("PLtsHWklKOKScxpvlFuiPQsVuGZBIWdPqHrMZHBYXuDwKsrqURjUvSdRsYTpRVthSTQqMeeGDhKXZteDDyYGDStoZUoyaCJvBMCSkdEIivqVXkhzfxWkhwSXMbM"), false);
    this->tNjFjfUEZskwbxu(string("DlOJkibqWQRTTcfuCCBAvzayvIuCcHHebOlNjmrfLvfDLBXotyBKQQsKlmWwzyUOSLrXZWZCLmJWTofimlwuUBJnCKAILibcAMNCVkitDMfVgtorAqkAiNKsYRAufectzLXBpNLcICfRdccqnhdACxqsIjXSmocqhLZuUnUlBnQACEOySgZBoFrDKsZqIypvFXLRx"), 278100755, true, false, string("XrTDTmDtNRraaKztezBmlxJunRSBvFLPmSmRdKrfdwiTHwJZmPhToXmUpekgUPtWkJzEFRhowimXfBCboeNOfQOUJLXdOcKnGdsfsYvzKgHiSfDfjjerCKqNbzCDfyBNorWLuwRuATViWJnnQiyonh"));
    this->TNwUhirCScWYBonz(false, false);
    this->gxtDG(string("DpmlXGzZbPOTGWJwACNprrggXXyuJIGwciqSohRgejZisFvjEFOukFxKIZrnBLtDodOiDeqKRzsYEWIHEKNviGkspmjQeRjdQbyBeapCnhmKYNMIDLPwFcCMhHVxx"), string("fiyjDMaPPkLfsQwrRZdZhKCvGEYrVjUFHtzixgpwCwaqmCw"), 622544.7225967327, string("vyznqYRBCcxdraiCPsXROVBKNACXkkrBNraRHwabfcCyFPogSKZwiYLLiFccQdTLvEIYnzPGZShegMeJWSkeKlGXqSgiF"), 413713.31374806253);
    this->msGMa(string("WoHQXtSAbVOxzIzhuDveuDqHyaOBNUwRBbxDNUMVwAWkmDmnUhocqkeimBSFqgKCWApiqSNCbWfNFdmKlaAFhZkTaUHriQZobAHjXdZvWBjDDcnRvTMHgnjiNQedQkLcjnSJKgrDixKROWmmmfdOU"), -1657508029, string("aAnZSEmHxtCaQzQKqVxooTvAjbUqgcFNiBCMbUKLsLVFLoKTpfNCdCJqZvSBoBldTmbNYeLkOQyqhMozrcLpAbYiMTFgCzyGNIXEFNSMVzzydpNkAjuaAmSWCOABvIzZNrALFCXUoKZoWYGdRuiKKQFiPPbjwpYIvodcOblpkHWBIDoMEvzrZOPpJWqwzTcCAazpXSmqQBwclZkQLTfvKEJhyh"), string("HpPRBTQfviyXoMjCkaJDhNInNTmzthZKzBsdcYCkjUYFTtYKPGoZnDZcnCjwOStDbMIgpXbjICtmhNRFtlWwTWNClhjxmMxGfWINaekRAiyTFEtBgWIETEQdogOuvvKfLxjgXGpkrVIflIlGfMSYMVpHUpMMVbSorgCTYuKNbFnDrPvdkGwMdgpGxAcjCEUAVfDEPUOYUqtCUrgmONSq"), string("gSnPZXOuM"));
    this->DQkeYoDZamsU(string("mAzszqVnSbsTZSuRdZXMLkoUiECPqFabQmRvtTkgDqQcemdZnNoHeTxaHkIGyIVsoNphgsMiJwbgyYNMBmlNwllugfK"), -1005622.3771312216, true, 1203360381);
    this->dQcUM(581132.5110747276, string("kywnyFKvcDLWuKWGmOwlfXLToriJgSaXVCGCCtPSTcOidpprfRQAIZnwqkItwjVzfHjCEugeWZNKctzKSRtMIqYVMpQLPwPSdJOctemrvu"), 394145280);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XVYkiqMy
{
public:
    bool VpcTLLbQYuwZI;
    double peaJpIPPrgb;
    bool qPzFwHZasRfOJhd;
    string sRbhalqWETkSFKq;

    XVYkiqMy();
    double GxdxDu(string PFwnJA, bool aQKxpGwIj, bool ipciDiDxcWzYxJU, int olpSjEIcyaWu, double SadrJPeBQRpQGdEl);
protected:
    string EkwQVy;
    int kaXUOIFr;
    string iQNcWaMmzpQXmfnM;
    int mUeIsKKaRRFoo;
    int sYJOyNMcIZCSzsw;
    double oHPbvyI;

    bool zZNjBI();
    int xTPnTGUMmBMCvfRd(int ZyoWOYB, double pHFbrthKyCtsYrIk, double pCsBSCszLgYy);
    string FzhfcnwldltYjB(int NrWDp, int PkXSZPROQ, string lvtptvduCpNiUWTe);
    void TBqwFeiKOpjgSdz(string hDeidPqFJlE, bool KxYOy, double uTxjuqavvSbw, string MQupRzvOskyYovEf, string PGsXOyJugGbURof);
    void XiRPYHzQ(string MXyAAgZHMeo, bool gVKFFYjv, int EAKRecCOiUMeJCYR, int bYMHFLOBYAudI, bool mSiJuZRYPVw);
    double mEJaZqcA(int IeIiYcwbQlB, bool ddeqBJJrHnKkU, bool TrzaGRaQo, double QTqZwjZHLgymXtzE);
private:
    double sccGAFkuLLaYyz;
    string OuXOZSGd;
    int KGAwRoVxuefCwAW;
    double RFSgOpJy;
    bool VxTSOyjbA;

    string DLBflt(string acjFRLG, double iGXgHZOPogsoZKsp, bool uLuzZVvhYEmKnhT);
    double SWeWAOJ();
    double RGaHUeIpOQ(double UOnjKolD, bool umNpcrPuU);
    int JitimkDgnyAlnHr(bool krNJLFnr, double BUStdtnkp, bool IszDTfyYMXcdWt, string gVnmbaphNTDQF, string VHXvryKLaiTCf);
    string OtczuDoTWEB(string GFUfj, double ujtbknGn, double qpRWaTfKu);
};

double XVYkiqMy::GxdxDu(string PFwnJA, bool aQKxpGwIj, bool ipciDiDxcWzYxJU, int olpSjEIcyaWu, double SadrJPeBQRpQGdEl)
{
    int xOiXmVgnRymFAlr = 1214590147;
    string FouRmfFgmDT = string("cYbzzISitqPygAHhhsKJLKVdxucBwXiSBsHXlTVUjuOdtHVuXBHEQfwIlTdeWz");
    int UkgJcEicNrLp = 330565177;
    double iGbfFZFnhqxj = -251943.21049607938;
    bool FwyNsJ = true;
    double noATk = -189699.7008916836;
    int tMbvK = 466560260;
    string bJVWJSvUIqLhNp = string("gkBFTkemdoihSGHtBkJSfgoKqEAUbgOOBx");
    int DxHHOOjCJyPQwZS = -630644275;
    double jidWx = -548469.5078746136;

    for (int eOkKJXXcw = 1272438346; eOkKJXXcw > 0; eOkKJXXcw--) {
        jidWx -= noATk;
    }

    for (int srFjnpdDds = 2105650246; srFjnpdDds > 0; srFjnpdDds--) {
        continue;
    }

    for (int hoZdKtHmtWxzBYU = 789527245; hoZdKtHmtWxzBYU > 0; hoZdKtHmtWxzBYU--) {
        continue;
    }

    if (UkgJcEicNrLp <= 1214590147) {
        for (int XBkUmadJSuT = 1459232200; XBkUmadJSuT > 0; XBkUmadJSuT--) {
            noATk -= SadrJPeBQRpQGdEl;
        }
    }

    for (int GgqvKScJIAhldM = 657962318; GgqvKScJIAhldM > 0; GgqvKScJIAhldM--) {
        continue;
    }

    for (int ncJGzXFNib = 764472849; ncJGzXFNib > 0; ncJGzXFNib--) {
        continue;
    }

    return jidWx;
}

bool XVYkiqMy::zZNjBI()
{
    string IdUoJIQEUdftAB = string("bCpCaPhtJSXZEbmPZJItZVHPMFKacigXyxnrlnDZJJf");

    return true;
}

int XVYkiqMy::xTPnTGUMmBMCvfRd(int ZyoWOYB, double pHFbrthKyCtsYrIk, double pCsBSCszLgYy)
{
    int OjqoLQBNlGfQ = -16034885;
    string EjzRoA = string("VVmareZyElFURsWZomrhIzFtOOXHMfWISKLqMzjEpHDIFHKAYokMcOIlPhQFcKwoZfOdLayRFKCJeiKvuaShDQdnXeuYNPcBGJyIZstodwWslUYUtzLVaEUuPPbFmpuCnsORSgUELxoQmWQznFITzkUHMqLnLtIpZqLJjztxypqeNlqjhWdQGTiryaMOoTd");

    for (int WQwwvEaOVcMDj = 458212712; WQwwvEaOVcMDj > 0; WQwwvEaOVcMDj--) {
        EjzRoA += EjzRoA;
    }

    if (ZyoWOYB > 631278322) {
        for (int pJkHqjGhKJAYJYVQ = 1137108487; pJkHqjGhKJAYJYVQ > 0; pJkHqjGhKJAYJYVQ--) {
            ZyoWOYB /= ZyoWOYB;
            OjqoLQBNlGfQ /= OjqoLQBNlGfQ;
            pCsBSCszLgYy -= pHFbrthKyCtsYrIk;
            ZyoWOYB = OjqoLQBNlGfQ;
            pHFbrthKyCtsYrIk -= pHFbrthKyCtsYrIk;
        }
    }

    return OjqoLQBNlGfQ;
}

string XVYkiqMy::FzhfcnwldltYjB(int NrWDp, int PkXSZPROQ, string lvtptvduCpNiUWTe)
{
    string WssfntqJWzjSgfJ = string("HIVNJHRv");
    string TZKPDorG = string("ZKMlPprEhOvIKYCULZHPyctsPPyNjzJQxwrzHjmXlEzIHmNiXXgBosFfiysjUEGFRkQDAIWBZTNfiLtenMDKCLbsnzFfSTEWwRNiQCMbPzfHBjHmmeMYezxCkCDVinoAYuaHCBAmqJljEuBVkRdaLTITywLEHgTrYNsabddugnXEPAhSGHAWfqpsLJDFQyTOCFwYkewBIEVDeMEoXLdMCcMlnqyWZenHXbHQoAQrwSWSQKycVnF");
    int edORlMw = -1264070344;
    string SiwmeXJQ = string("fmFSyGVXevAb");

    if (PkXSZPROQ == 1384863870) {
        for (int ebqGkL = 571697247; ebqGkL > 0; ebqGkL--) {
            SiwmeXJQ += TZKPDorG;
        }
    }

    return SiwmeXJQ;
}

void XVYkiqMy::TBqwFeiKOpjgSdz(string hDeidPqFJlE, bool KxYOy, double uTxjuqavvSbw, string MQupRzvOskyYovEf, string PGsXOyJugGbURof)
{
    double pYecoHbgeQ = -385246.6994913293;
    bool fDEhFPhULmYgMXK = false;
    bool JHjLQmglNu = true;
    int fsqdqvVmffU = -915984790;
    double AevsMCNCs = -903897.7524419279;
    bool rKKYOQGmxzm = true;
    int EkxMAIvKWOxyyA = 246511619;

    for (int ovyWCHYqxjfiF = 1959625154; ovyWCHYqxjfiF > 0; ovyWCHYqxjfiF--) {
        rKKYOQGmxzm = ! KxYOy;
        hDeidPqFJlE += hDeidPqFJlE;
    }

    if (AevsMCNCs != -625127.2893617747) {
        for (int tAulEEte = 852896367; tAulEEte > 0; tAulEEte--) {
            AevsMCNCs /= pYecoHbgeQ;
        }
    }
}

void XVYkiqMy::XiRPYHzQ(string MXyAAgZHMeo, bool gVKFFYjv, int EAKRecCOiUMeJCYR, int bYMHFLOBYAudI, bool mSiJuZRYPVw)
{
    string jwufIo = string("iUEjSjpLwtFrpUYWaHXWyYLXWTwVvTFESgcwUEzuPUixJLxEjXvgDVYeLhDFWfwOqYXLGH");
    bool ISaXYxIr = false;
    double OlavXyNrfK = 120353.81526240153;
    double hMngjWA = 510559.49260974;
    string rWHGjF = string("xyoCdlkigcXukJbpNrOdHUvHTkjkmkoBpfIXALfjhEketmTfhrIFiaFpfwJkyouOiOJatfPZgbbCfObplCCsxAiJtOjCyJlwxsZIdALxezZsBpFrKNAchAyrhjleMjMvdhSHTKRlkcwhFTBeVcexYoPohkezcsDGRxAlmtWkoXymVovQOMkFdKOxwXzqmVhHRDBuVxYZcTtgFSLQjAiMUwLNmIWLE");

    for (int ZvCGejQWK = 1987137466; ZvCGejQWK > 0; ZvCGejQWK--) {
        continue;
    }
}

double XVYkiqMy::mEJaZqcA(int IeIiYcwbQlB, bool ddeqBJJrHnKkU, bool TrzaGRaQo, double QTqZwjZHLgymXtzE)
{
    bool nsCyac = true;
    bool sPfgDInmrFgBdhy = false;
    int QnsCLdQ = 1209036275;
    bool dePdue = true;
    double IdGqW = 606715.6738559803;
    string TBUJjx = string("BjmJbLpFSTkgIYlkoOBNBRhBHJpejJWoQBDOyXPtrZTkDLJWHoapytXZCXFavAJdEPUQSESMwfViHDwMshBTclMOrVZEDnryhXObksXOBzEDyG");
    bool VfvRKFPVxxq = true;
    string SSvqGYfZumNN = string("LtRwpy");
    string ifpEDlMnqyRP = string("gLCpxvMvDVUfmJKeigBzoeJRIhKUgJATqcqp");
    string GamvNmWE = string("KosxjsLYtzdSREWH");

    for (int iPhEb = 2048573602; iPhEb > 0; iPhEb--) {
        continue;
    }

    return IdGqW;
}

string XVYkiqMy::DLBflt(string acjFRLG, double iGXgHZOPogsoZKsp, bool uLuzZVvhYEmKnhT)
{
    bool hoMUGh = true;
    string ZQnsPMVzkVBbo = string("wvXYwxTKvWvMtjaBvRQMxRLpXNZfQpuecmmaocnsOnNsXIEMkIIEfMMmrtBISSSlNzMWeLvalEvAwguemnywTmgZBHasmgYZRjcbSrzyPBLZTQpyjGUXCmzYQMWUfbzozsfwddmbOQUhgEznsKaVcngDeYHTjkStsMtexXzJLKsOTwKRcaFGJmzGkGGrxypUCfoBbpnYRKCwwRhzRWHtxjQLpylxrjfAcVSqChur");
    double cAqFgGdYn = 472922.6765630202;
    bool kRzQNwPo = true;
    string UKFpSxoRvLkCHrC = string("uPmQNsOiFepomfAqSMkavyMzjqQUqOOnRCxERUFPrfVyXetCgeCJWCEqeblQuAmwOCKHzQPHdjqhiBcoCrmmCmfFgFKeYybZkmoXgOfdwQHZQzLoeYMxQprQcQTUtgHroSowhgKTCsEcemxeAZsDzIjyyqkPTSuuIgcoFBwDevtOTlcbaCuoMmvYeByZJpBiUorAJERwXOnxnAdf");
    int qeLYHDOO = -2055914028;

    for (int mcZPADxBFH = 1463126076; mcZPADxBFH > 0; mcZPADxBFH--) {
        ZQnsPMVzkVBbo = acjFRLG;
    }

    for (int ptbuVCzP = 2031451812; ptbuVCzP > 0; ptbuVCzP--) {
        continue;
    }

    if (ZQnsPMVzkVBbo != string("uPmQNsOiFepomfAqSMkavyMzjqQUqOOnRCxERUFPrfVyXetCgeCJWCEqeblQuAmwOCKHzQPHdjqhiBcoCrmmCmfFgFKeYybZkmoXgOfdwQHZQzLoeYMxQprQcQTUtgHroSowhgKTCsEcemxeAZsDzIjyyqkPTSuuIgcoFBwDevtOTlcbaCuoMmvYeByZJpBiUorAJERwXOnxnAdf")) {
        for (int KaFuYWex = 505203293; KaFuYWex > 0; KaFuYWex--) {
            hoMUGh = ! uLuzZVvhYEmKnhT;
            kRzQNwPo = ! uLuzZVvhYEmKnhT;
        }
    }

    if (iGXgHZOPogsoZKsp <= 472922.6765630202) {
        for (int XaMptQX = 2010436011; XaMptQX > 0; XaMptQX--) {
            uLuzZVvhYEmKnhT = ! kRzQNwPo;
        }
    }

    for (int IpCKdEAu = 524160231; IpCKdEAu > 0; IpCKdEAu--) {
        cAqFgGdYn -= iGXgHZOPogsoZKsp;
    }

    return UKFpSxoRvLkCHrC;
}

double XVYkiqMy::SWeWAOJ()
{
    double ijOIoniJpRHPNgAY = 319707.1978363683;
    double wfTKnxakMIGcf = -715188.5813851155;
    bool HXepebCxWlXLsw = false;
    double ILUhLyTkTz = -192703.87254994505;
    double FmmmnjEuOdHk = -855293.246957878;

    for (int nzfCxjvkEdJ = 1320108597; nzfCxjvkEdJ > 0; nzfCxjvkEdJ--) {
        ILUhLyTkTz -= FmmmnjEuOdHk;
        FmmmnjEuOdHk += ijOIoniJpRHPNgAY;
    }

    return FmmmnjEuOdHk;
}

double XVYkiqMy::RGaHUeIpOQ(double UOnjKolD, bool umNpcrPuU)
{
    string UyVhHak = string("kzzFtTRjolaSCvKulmphHjtKnrQcsnoPGEhfcJ");
    int rCopf = -1045432503;
    int hGsaICzyXRg = 2075270;
    int lGbuZlqnRJFNtBGU = 1913928489;

    for (int waQAipARZL = 1751233927; waQAipARZL > 0; waQAipARZL--) {
        continue;
    }

    return UOnjKolD;
}

int XVYkiqMy::JitimkDgnyAlnHr(bool krNJLFnr, double BUStdtnkp, bool IszDTfyYMXcdWt, string gVnmbaphNTDQF, string VHXvryKLaiTCf)
{
    bool eTcKLpEkzeNGNL = false;

    if (krNJLFnr == true) {
        for (int XaLqjGCQFSccBPp = 1472453191; XaLqjGCQFSccBPp > 0; XaLqjGCQFSccBPp--) {
            IszDTfyYMXcdWt = ! IszDTfyYMXcdWt;
            IszDTfyYMXcdWt = ! eTcKLpEkzeNGNL;
        }
    }

    if (IszDTfyYMXcdWt == false) {
        for (int nXICnaPSIqKy = 464683934; nXICnaPSIqKy > 0; nXICnaPSIqKy--) {
            krNJLFnr = krNJLFnr;
        }
    }

    for (int KbizFC = 1372681259; KbizFC > 0; KbizFC--) {
        krNJLFnr = ! IszDTfyYMXcdWt;
        VHXvryKLaiTCf = VHXvryKLaiTCf;
        eTcKLpEkzeNGNL = ! krNJLFnr;
    }

    for (int KZrXwSlisSqL = 1438917850; KZrXwSlisSqL > 0; KZrXwSlisSqL--) {
        krNJLFnr = ! krNJLFnr;
        BUStdtnkp += BUStdtnkp;
        VHXvryKLaiTCf += VHXvryKLaiTCf;
        krNJLFnr = eTcKLpEkzeNGNL;
    }

    if (BUStdtnkp != 796382.1942975398) {
        for (int vTwGeODFPiphH = 1043895273; vTwGeODFPiphH > 0; vTwGeODFPiphH--) {
            continue;
        }
    }

    return 1216136818;
}

string XVYkiqMy::OtczuDoTWEB(string GFUfj, double ujtbknGn, double qpRWaTfKu)
{
    double xzpcGL = -240198.7999576975;
    double JFGTFO = 792727.3278579657;
    double VdKXAxI = -835407.3824527762;
    bool URsQjkawLBucEtYU = true;
    int eqAiCsexjMHkSYF = 731001726;

    if (qpRWaTfKu == 792727.3278579657) {
        for (int tZPeRNBKkVDt = 1146691422; tZPeRNBKkVDt > 0; tZPeRNBKkVDt--) {
            VdKXAxI = xzpcGL;
            JFGTFO /= qpRWaTfKu;
            VdKXAxI = ujtbknGn;
            ujtbknGn *= JFGTFO;
            ujtbknGn = VdKXAxI;
            ujtbknGn /= JFGTFO;
            qpRWaTfKu -= JFGTFO;
        }
    }

    for (int fbAWrWP = 1526330066; fbAWrWP > 0; fbAWrWP--) {
        continue;
    }

    return GFUfj;
}

XVYkiqMy::XVYkiqMy()
{
    this->GxdxDu(string("kMvmhLgeXtksDsHOdcxHRhrrTivJpkCfNEUPJmQzTivJuuKPQPHxmvtzidicDXGmnJguZuyNZxlRZZKKIPplEffbbsAeQCHPoZokLnxLsHjprhzR"), true, false, -1720063441, -787978.6548454178);
    this->zZNjBI();
    this->xTPnTGUMmBMCvfRd(631278322, -267031.37167446554, -182263.36459639375);
    this->FzhfcnwldltYjB(564330953, 1384863870, string("DsElrorxSAngrlVWzsETrqxucEQWbJhgmWjRiUxDiLXpFmSzwWWmZPLHjpUFEFZsQQLcOiWGVRTJmlUFrgMedWuKAhpVIGDLSPKGVRjvXgWxlVgLQhNWmbLWrIQTmncwlBkMjkyDRSJdsaJuHMMmnuwmFspHWsrlosMYUKuAVPRXbGRiITorwGWBnHyMpHieKkBOFIVGx"));
    this->TBqwFeiKOpjgSdz(string("KVYANVhCyBRLAjLGTMSBanqDdCAEzfxMlzFUjbyinrSUXHlxplIQtCKeZUbSUHpWdBYgjHDYmFyczvGMocmBhwMDNoQhadkmwmwLeguiKPLjkfbKDbBSmuJPsejSvvqvGUmyzvhnBrwTRqpSrTeilWDcuCh"), false, -625127.2893617747, string("AmrZEGAEcAnjDoBOlDej"), string("kcDWxQKmrfngQZXqrtFCBFLGniVLgmItpLQiiHSNUNKmbqojdBxRPdoIuxACeVAXkBUnstfqpYvZchpSuRMiWLHAzVTmBanmOQSdFLpsMoirqDrNVLYqoMboRNlghZDQvJejQdkCvKKAmLXDTCkfYYWyLDQcSqRXPLokihZ"));
    this->XiRPYHzQ(string("AChqhvDBfoFyQKDfWjgcskLvCcxSWphctQIEWFfZNqSxDKaVlRaDbcSPpVgQuZWgjsTWKFxfNZMYtBJDYDgUtVVGetJFubqiqNedatjGufoUluLGKjWzqbXDETpfbUDSlhhfBmriHigFPAuVsPNSEKAWvtYabHmHkk"), true, 1274742126, -180238643, true);
    this->mEJaZqcA(-191440120, true, false, 782624.9620476804);
    this->DLBflt(string("jMYAoJMjBbsrCwzsbNidVkriOukEcpJLFixdhzSAXAHqrRQxavdtEXsjRXBkjpDNIdkPkmlFudEwbFpkVEUcEqymPfNefwuPgOaEfEYPzUVmtzGfetBMgwyBtojbkEMZwBEsAffBwZxwtayZSPcF"), 211116.19656138626, true);
    this->SWeWAOJ();
    this->RGaHUeIpOQ(-71327.51351996385, true);
    this->JitimkDgnyAlnHr(false, 796382.1942975398, true, string("vqYhneucNHUsNrSIgUqqqwFxiICnVo"), string("RRcYJdOjoQCmaCGIQpjFLNUwBEPCpbrxKwwxQYMQSwVhelJVAirMgPQtUXAkwgTiDcTjyJykdHZzseZhqnDggVkfxGlhidtsLBsVxVOEkPbLKHioqpgLAtWZcGE"));
    this->OtczuDoTWEB(string("KVsIqnDAnrXrFuKbTrWcKMMUYESvKjvxFTjGXpQeTakWUcCKITHICBVYULifftwFVbALJIrrDOKexDOJzQaWvmCZiYvNuSNhPSQRIoibdSthRxmVDadnebNZNykqEJlppkA"), 620954.9355589139, 696154.5487809496);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class reCZlURHkGpvTrl
{
public:
    string YwKDzEgz;

    reCZlURHkGpvTrl();
protected:
    int NOUCmzKHJmUPBeuE;

private:
    double UPzqPNBw;
    string qiURaaZWpiYkqOQy;

    bool sueVSOneFwZKG(bool ZiAwZu, double zWokkhwyWUSG, int kCrzQjcC);
};

bool reCZlURHkGpvTrl::sueVSOneFwZKG(bool ZiAwZu, double zWokkhwyWUSG, int kCrzQjcC)
{
    double VjXMogBsg = 624907.6299032005;

    for (int CqqjfDtaH = 825514458; CqqjfDtaH > 0; CqqjfDtaH--) {
        zWokkhwyWUSG *= VjXMogBsg;
        VjXMogBsg *= zWokkhwyWUSG;
    }

    for (int eqOmP = 500998071; eqOmP > 0; eqOmP--) {
        zWokkhwyWUSG *= zWokkhwyWUSG;
        zWokkhwyWUSG *= VjXMogBsg;
        VjXMogBsg = zWokkhwyWUSG;
        zWokkhwyWUSG -= zWokkhwyWUSG;
    }

    if (ZiAwZu != false) {
        for (int QgyGCo = 315447080; QgyGCo > 0; QgyGCo--) {
            VjXMogBsg -= VjXMogBsg;
            zWokkhwyWUSG = VjXMogBsg;
            ZiAwZu = ! ZiAwZu;
        }
    }

    for (int bhMcHf = 1063041180; bhMcHf > 0; bhMcHf--) {
        VjXMogBsg /= zWokkhwyWUSG;
        zWokkhwyWUSG /= VjXMogBsg;
    }

    return ZiAwZu;
}

reCZlURHkGpvTrl::reCZlURHkGpvTrl()
{
    this->sueVSOneFwZKG(false, 799740.243271367, -765381234);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KOtTfGtpvEnQWaW
{
public:
    double vUiomVXtCYrJGObX;
    double LdhwQLhafgQpZ;
    bool avglLR;
    int heevK;
    string WhSPtQFpI;

    KOtTfGtpvEnQWaW();
    double DXNJuxgYQaoiI(double gQCXFr, double kbYmriaqKVR, double CRaNLIxpDO, bool RYtreNDSVhqvqL, bool ZlhFsLKwMu);
    void AHOKrshXOF(string jLiGeZlDBlJu, bool Rysydjh);
    string kYZDtl(int TtfIGFeAtSUeZGXw);
protected:
    bool aTorXp;
    double uumcVnrmgAVX;
    string EYRAFoci;
    string lfOBDgCV;
    double maMObvfwxIQ;
    int EvUrmTOPPtmL;

    void FmCra(int lsOonsADAdj);
    double yhSzcZT(int hiRotByXZflCeafs);
    void ftaiukrjUQduCu(string HLSsJVgWkXVbmojv, string lXRWSQDI, double vffVuZn, string BZGxaEhPjM);
    int adDxCvuHMtHaq(double qUVmxD, string oxkCVZ);
    bool rGBgzhnK(int pGkurjIwGVk, bool wLqxy, double qmLZbxlIHgsgk);
    void oxHjPlqSCsZA(int AMXsluBNkDeQOq, string gpjRJh, int VsNgQEsTVRqGHZDW);
private:
    bool DnHxUQLQlnybipd;
    string CFAZnMYRKoqx;

    double psoNpX();
    void hghTWruabYdm(string VtOmgZlWQwAU, string NWoqxU, int jNvQaArXRAMLtRcD);
    void rsFNuXMrXTC();
    bool UeNNTmSXzO(int zpguQXzzHW, int FGxDfTKOQIBYAM, string HJZWXYw, int XIIvQ, double WYueZfEZGPyyXGt);
};

double KOtTfGtpvEnQWaW::DXNJuxgYQaoiI(double gQCXFr, double kbYmriaqKVR, double CRaNLIxpDO, bool RYtreNDSVhqvqL, bool ZlhFsLKwMu)
{
    double vgCFXBNozYPjKr = -422509.6056885649;
    double jeETcxdAkG = -104445.9414075211;

    if (kbYmriaqKVR == 375798.89321545773) {
        for (int LiXtrXjLs = 1415588894; LiXtrXjLs > 0; LiXtrXjLs--) {
            CRaNLIxpDO /= CRaNLIxpDO;
            ZlhFsLKwMu = ! ZlhFsLKwMu;
        }
    }

    return jeETcxdAkG;
}

void KOtTfGtpvEnQWaW::AHOKrshXOF(string jLiGeZlDBlJu, bool Rysydjh)
{
    double AkhSTHUOy = -453660.63046059967;
    int xVMrAKB = -1418558801;
    int jmdwMJ = -382313273;

    for (int YoBbDGEvq = 1485606556; YoBbDGEvq > 0; YoBbDGEvq--) {
        jmdwMJ /= xVMrAKB;
    }

    for (int XezBeZmBe = 1491921155; XezBeZmBe > 0; XezBeZmBe--) {
        Rysydjh = ! Rysydjh;
    }

    for (int FvIuUwtfgZZOHSK = 745150583; FvIuUwtfgZZOHSK > 0; FvIuUwtfgZZOHSK--) {
        xVMrAKB *= xVMrAKB;
    }

    if (jmdwMJ >= -382313273) {
        for (int GFHFdAdFygH = 2009721030; GFHFdAdFygH > 0; GFHFdAdFygH--) {
            xVMrAKB += jmdwMJ;
        }
    }

    for (int izPBgW = 992199521; izPBgW > 0; izPBgW--) {
        jmdwMJ -= xVMrAKB;
    }
}

string KOtTfGtpvEnQWaW::kYZDtl(int TtfIGFeAtSUeZGXw)
{
    int bQAwKm = 1838344996;
    string VpFEHerkU = string("gDMtwXPfZIjvjQxzkZjIyVIUBODmqPmVKpYffIAsCaILYVyxEkvKDpLULGTdKmQWVpzqvmIwdInQRihuYWiRbyAMhTRweGetrJfeCCujsZluuZXBNQdZyuNoHUXxwFNeQyFfVMRDZCEzIFamKQoXpYpfWqFELpAjomPqcuIkXzZFYsGXaoxsQYhhMLcNziLCFujdCYelbZPLRmsBrBnPxbPwEtBzYwumczvXaECCYoOvsn");
    double aGtcARqyvXZb = 541912.980702334;
    bool bfMGihhmLzNJMh = true;
    string CMccNQDGOeL = string("AbBhJGtbrFfaaruWOdIyWXhovsDVsbxJAhiPismibSAaCRRwgRhFoOvQyTjlFxPTShmWsNHKhCcPiOYAqzbwrPKVBjsoIjdNwVnsXgEUFffiDqOOzKkehHdeSnbDttZACxfdYRoAeHgWQrjpcGqiMFDjTQXHAmRVMeKQvEdwSGLcXGVycJKblxPegTExoVyuJMCzlbbleHHohkjpbuGVprdHLlrTfIbVRrUZUIJuDAApmzBKJjvA");
    bool fBCRw = true;
    int knsvpbsYpPZtfKX = 2001913096;
    string PbGXVYbHtJA = string("juJOlfTKvp");
    bool TjixxOgdJFK = false;

    for (int MFXJzvNYeX = 1578549632; MFXJzvNYeX > 0; MFXJzvNYeX--) {
        continue;
    }

    if (bQAwKm >= 1838344996) {
        for (int rZTDiWZiGShqv = 2129103602; rZTDiWZiGShqv > 0; rZTDiWZiGShqv--) {
            TjixxOgdJFK = ! TjixxOgdJFK;
        }
    }

    return PbGXVYbHtJA;
}

void KOtTfGtpvEnQWaW::FmCra(int lsOonsADAdj)
{
    double RHWgKBo = 66404.1525116567;
    string pwkIez = string("BzvDGNGxHGXhSoRJLGHBRHdabKqxUxSqnTNmMcqDKquwALhMXeiFfErSsoWwlMbkFlYCFIxHHUhooWlIoJjJNxZGEDwhCiMvlMCZVOYQRXkBxbGDIebdsIHiMslovdKPlPAnayGGKIbEuTIXsr");
    bool uHCsEZYfK = true;
    double UdvzfjiQpQvwF = 722784.1697137066;
    bool WiDmKvAMZIgy = false;

    for (int pOnACHiYRJ = 1751975824; pOnACHiYRJ > 0; pOnACHiYRJ--) {
        WiDmKvAMZIgy = uHCsEZYfK;
        pwkIez = pwkIez;
        UdvzfjiQpQvwF += UdvzfjiQpQvwF;
    }

    for (int ERgLkERfLaawdD = 187246747; ERgLkERfLaawdD > 0; ERgLkERfLaawdD--) {
        WiDmKvAMZIgy = ! uHCsEZYfK;
    }

    if (RHWgKBo == 722784.1697137066) {
        for (int ZgwRNv = 1875526208; ZgwRNv > 0; ZgwRNv--) {
            continue;
        }
    }
}

double KOtTfGtpvEnQWaW::yhSzcZT(int hiRotByXZflCeafs)
{
    int dlbeydrq = -1868325739;
    bool pJgZDysJ = true;
    double RIBcJ = 592930.8605289079;
    bool PSExZF = true;
    int LMXzEIudqyW = -645176005;
    int SAJiOBIbZy = 174526528;
    string mpjPKEdsRTKLCV = string("VFLnTUESMFFuvJkAlOspcueGqugOGLqwhjTMJLZAOudDRxqiMzeeeXYqcPsURzeBxVuQqayOOcxotmkkyLoRKnYezhUpFjYAUgbsQAvsyEwwyvBxhQbEyRSWEIorvzxEdUkkYLyhGxrYcVeJvSzOTkdXclgkUDHrwPLrMYOqahpTLAhEoCXSntvehlakPLFCYgHlEeWrewPCeEBwDgyDmRsJYvwtgkHDD");
    bool pPkSvtMkiz = false;
    int zvdlKE = 972258036;

    return RIBcJ;
}

void KOtTfGtpvEnQWaW::ftaiukrjUQduCu(string HLSsJVgWkXVbmojv, string lXRWSQDI, double vffVuZn, string BZGxaEhPjM)
{
    double CKyOYAXWQK = 362978.97464377;
    string hOtGZRqMlNuJMf = string("FaLBYDgyVtjHRMBnoEvWLMzKJjeSjrQNBIHstxFHatnkTkwYvpKVCySammLqPCYKUVZnmNQvYZULOgLeDAcHgGWxJEtutnlghIGLuqIWfmTqDpeMvNVKczYFrbEFVeWabCjGnIvWAICDTkgkLyVeBhFKtSuxaqREPTQMxdAsFQvMwVQhAsVVdzEXHoZLlFCvbn");
    double izbipWbkDmNZw = -290604.1320917254;
    string pEjxbVTsrwsgsnz = string("LfAAEUEmAKgMkUlprxdqpaClZVkJcFROhTaURvuzqiinmjQVnloijwrKYYEZdLGWtBgbkgPYyZaVLvNEVRKCNLESUjLzEXebacAYCetsCiBgLnEOOmQnXqhHcItFnhLHlikXKYKwEmILJVimwIsSwTtuXzSHZvaKgTAQBidjrcmGMxMumNLCozjYmGEhZsYzevNkESpTtHVMkjiUbCfOup");
    double gTflNeEoZyADwhPX = -780795.8686290999;
    int zhxsDrqxfLECXFeL = -882632853;
    double NKbWMjdFOppn = -771768.8176820327;

    if (zhxsDrqxfLECXFeL > -882632853) {
        for (int oybTsHDFJ = 66132983; oybTsHDFJ > 0; oybTsHDFJ--) {
            lXRWSQDI = pEjxbVTsrwsgsnz;
            CKyOYAXWQK /= vffVuZn;
            gTflNeEoZyADwhPX += vffVuZn;
            lXRWSQDI += hOtGZRqMlNuJMf;
        }
    }
}

int KOtTfGtpvEnQWaW::adDxCvuHMtHaq(double qUVmxD, string oxkCVZ)
{
    bool LANxEf = false;
    string zMkZmEfqUjSK = string("lFfKdtLvEBArSrQMJvcpSDwbfNJpkEjHnTIGcYlxOPfLzIsdXElOUWCVgnrVtYhrbYFrsSNffsyukwKrFCBtFIAUNlqTtlbhbvGYN");
    int CFBjkiCRxKXbX = 923424712;
    double FraljEpLzo = 488376.0435187878;
    int GrregM = 776023207;
    double ZnWCFgIbjA = -569102.5004187005;
    string ylIxN = string("tJmttqLEcHxTVfJKvLZBDAyCvvpafwGKFLNubTKRRajIhIBvwqLzSR");
    string UzyfWugdcKPmz = string("yeH");
    bool eqOVTRJuwq = false;
    int svSbRyJDkDNHQJ = 933706445;

    for (int oBbvzRnkiEeXyH = 42223486; oBbvzRnkiEeXyH > 0; oBbvzRnkiEeXyH--) {
        oxkCVZ += zMkZmEfqUjSK;
    }

    return svSbRyJDkDNHQJ;
}

bool KOtTfGtpvEnQWaW::rGBgzhnK(int pGkurjIwGVk, bool wLqxy, double qmLZbxlIHgsgk)
{
    double PNXeQuYIddlVyDx = -797770.3407602522;
    int ryaPejgMQwwipug = -2022942427;
    double SzvaMDCgrygPr = -286734.83904927305;
    double CLVInsZ = 1015105.3412612273;
    double mHEdBPIC = -491380.40081092884;
    double FDyIBStHU = -736034.5463626076;
    string ADFJkAszONreOT = string("aHxxijfWnmlAOVKOHbONywLFnVHqdZFwzqctodLiUKewlx");
    double SsvOnweqteBJzC = -630261.2714711182;
    string rlzaLPfSKt = string("FizLiXXQoDgshiTFjxXkYlfvruloishTSQyTZxsEZFMkuBOLSEOuNSBAwEdDyPonAnbSxQjFgOkBKpOYwTwEncEqcttfyILtbleSRgcwEcehOOPAbKmFxKbprVKhfRRWjduzOwdYMBsJKllCqESgSSuLjJYiMdLhwRpVdjaHCAYyLBnbYxxWCPsNibGKVBCMciqlMpRDEfTrgEWFqPpmtgVfRcyxTBBuLaaoRsHCQdAWS");
    string lHCSOzkooJxB = string("lvCMeShqwXdvozmwal");

    if (PNXeQuYIddlVyDx <= -286734.83904927305) {
        for (int VPiNLtMdHnE = 19307467; VPiNLtMdHnE > 0; VPiNLtMdHnE--) {
            mHEdBPIC += qmLZbxlIHgsgk;
            mHEdBPIC *= CLVInsZ;
            rlzaLPfSKt += rlzaLPfSKt;
        }
    }

    return wLqxy;
}

void KOtTfGtpvEnQWaW::oxHjPlqSCsZA(int AMXsluBNkDeQOq, string gpjRJh, int VsNgQEsTVRqGHZDW)
{
    bool YxxcwFiTsKrKest = false;
    string kIghIwUKowJV = string("yUdeU");
    bool jfjKVOcP = true;

    for (int saZrbE = 190119824; saZrbE > 0; saZrbE--) {
        YxxcwFiTsKrKest = ! YxxcwFiTsKrKest;
        gpjRJh = kIghIwUKowJV;
    }

    for (int HovjXf = 1368687698; HovjXf > 0; HovjXf--) {
        continue;
    }
}

double KOtTfGtpvEnQWaW::psoNpX()
{
    string ZGauMmyLDtLxfEXa = string("DjxQEAuGdwpIpmLzktXmmOpSkhPNQxjaBNSQxjZmckR");
    int VErKNxJ = 642080329;
    bool ebIzbSmtO = false;
    int gVCwctQcqglC = 663289173;
    int mdVHqddGPhkwvbAS = -1146374451;
    string MUgluggWP = string("SlGZVbVgoVqtTGGjUbEtvMuuSRdJZjLTWKfOAwkhwQRTKxGXCcGZDLfYFNcX");

    for (int RWmOh = 1330504559; RWmOh > 0; RWmOh--) {
        mdVHqddGPhkwvbAS = VErKNxJ;
        mdVHqddGPhkwvbAS /= VErKNxJ;
    }

    for (int gvNPzQfefvVzl = 1132923732; gvNPzQfefvVzl > 0; gvNPzQfefvVzl--) {
        VErKNxJ /= mdVHqddGPhkwvbAS;
        gVCwctQcqglC += gVCwctQcqglC;
    }

    for (int dhMqoZWmR = 1814851896; dhMqoZWmR > 0; dhMqoZWmR--) {
        continue;
    }

    return 4153.650251979989;
}

void KOtTfGtpvEnQWaW::hghTWruabYdm(string VtOmgZlWQwAU, string NWoqxU, int jNvQaArXRAMLtRcD)
{
    double KTiASvagaAvuad = 407174.13352972793;
    int PaLrofbU = -239146066;
    double PHLhoxlJEBn = 135471.43805588424;
    bool PYsjwPqyPqwocQ = true;
    int RAfBMAiPhPa = 877959803;

    for (int INYlB = 118451326; INYlB > 0; INYlB--) {
        RAfBMAiPhPa /= RAfBMAiPhPa;
        RAfBMAiPhPa = RAfBMAiPhPa;
        jNvQaArXRAMLtRcD = PaLrofbU;
        KTiASvagaAvuad += KTiASvagaAvuad;
    }
}

void KOtTfGtpvEnQWaW::rsFNuXMrXTC()
{
    int lasTKAnP = -77525395;
    int cQNHgnev = 1939455902;
    double yNaVJ = 91718.09630225746;
    int iAsonrdZUn = -1170493200;
    double RnCLn = 446541.96646636043;
    bool NncJkLgTtNnJyiFT = true;
    double sRJktwiMmmdyRL = 964548.1966576981;
    double wEENQqi = -660417.3467130316;

    for (int CgqzRyMNM = 297099269; CgqzRyMNM > 0; CgqzRyMNM--) {
        iAsonrdZUn = cQNHgnev;
        iAsonrdZUn += iAsonrdZUn;
    }

    for (int MOIbqjcrZ = 1540971726; MOIbqjcrZ > 0; MOIbqjcrZ--) {
        yNaVJ -= sRJktwiMmmdyRL;
        RnCLn += RnCLn;
        iAsonrdZUn = cQNHgnev;
        wEENQqi /= RnCLn;
        yNaVJ /= wEENQqi;
        wEENQqi += wEENQqi;
    }
}

bool KOtTfGtpvEnQWaW::UeNNTmSXzO(int zpguQXzzHW, int FGxDfTKOQIBYAM, string HJZWXYw, int XIIvQ, double WYueZfEZGPyyXGt)
{
    bool HnRcea = false;
    double dcDOTX = 529325.8270877011;
    string EACiXr = string("qZwIfOKFVUovpOKOqHUcZNGBcEpBnFLvThlkowCxspfTopWNxkMydRXcQtMwwHGqPmxPElgQwPTZBlliNhmMYvJQmesitcadCAkIGpgBtCzRvIbCOqigPQkiwwlgdZLfeUwkRPZi");
    bool BCLMwJg = true;
    double bozZa = 533197.6602322126;

    for (int NVeKbDtle = 2075615615; NVeKbDtle > 0; NVeKbDtle--) {
        HnRcea = ! BCLMwJg;
        bozZa *= WYueZfEZGPyyXGt;
    }

    for (int wuDgube = 347001766; wuDgube > 0; wuDgube--) {
        continue;
    }

    for (int zXRRlNQSaX = 881050610; zXRRlNQSaX > 0; zXRRlNQSaX--) {
        XIIvQ *= XIIvQ;
        HJZWXYw = HJZWXYw;
        FGxDfTKOQIBYAM /= FGxDfTKOQIBYAM;
    }

    for (int ocmBea = 561066697; ocmBea > 0; ocmBea--) {
        continue;
    }

    if (bozZa < 533197.6602322126) {
        for (int MquQlgTOOivfNG = 313115352; MquQlgTOOivfNG > 0; MquQlgTOOivfNG--) {
            WYueZfEZGPyyXGt = dcDOTX;
            WYueZfEZGPyyXGt = bozZa;
        }
    }

    return BCLMwJg;
}

KOtTfGtpvEnQWaW::KOtTfGtpvEnQWaW()
{
    this->DXNJuxgYQaoiI(-16467.09478266454, -1028982.4549124474, 375798.89321545773, true, false);
    this->AHOKrshXOF(string("XKQFiypSYAOhkVjkQiewemiOllGNHdDWiyahIrqrBzbaeQHFGzniNoJnVeSiTwyBRQDFBQDOtyDb"), true);
    this->kYZDtl(-622276352);
    this->FmCra(-1532378381);
    this->yhSzcZT(-805005587);
    this->ftaiukrjUQduCu(string("zRtKroiSgTiCjbvgDnTxOEmKzjKtAnzbsCyzBPGAcdYiDfsRwztwlJGNOnIqIqR"), string("kmBemPoeujljSGmiAyKwxXwTn"), 24455.595135482257, string("MfzQxGbdUtoeZVAOEm"));
    this->adDxCvuHMtHaq(1036544.4604314264, string("hGYEwonvvnXZkXZRmXCcnjdTqicNuhsiQNVCwuQKQNHhKvmkEtqHFxPVUeHGgUdUPzsktUGnwfXFelBWCDTzyFJJpLLNvRghytrJBtiopiuyPHRXvmUwWvOzhblhva"));
    this->rGBgzhnK(1763261999, true, 269312.68596098444);
    this->oxHjPlqSCsZA(2312437, string("pqAIdFPTRrowLQygxWLZvGcmFBSQpslOBpqNsxBbXz"), -1107648862);
    this->psoNpX();
    this->hghTWruabYdm(string("arcdSCZmPlBPwYCNVpaGDuCuWKggJjsfBaSGCqKqzsqCfadyYrKFdXFyCCHPKRWERArxDICpCPlQcgptnIYIkJeRCqrIa"), string("UPEklsszscjuJVhpdQuZWFflvguXEZorLjaPDataNyydglQYqdanVDApovHujCWWzMqqJUaVHkfQQHaHiMwFxTNBYOCnCUhOvKRoUJKZrvXdnLWoYfIjwVUFaMvUSBUShlQifKsEnuxcqESPhNRhLgIrohveDTmkJtQyoXWbMpYwCahwjcsSWeARbpTRaTmGXTvNOwRivXHKAsbNdpKKhNAVfUKQfCaghSiFdTrRTfuXCn"), -1328468980);
    this->rsFNuXMrXTC();
    this->UeNNTmSXzO(-174664962, 2049294946, string("TtGYCuavcqJTxXrNyvFXBTTInkdpLfpTfXJKjnhEpRxVDiFNmQXeNgBoIbPtgWobnzGVIVlAftvIxdMJnSNSTtuHzelLLjoUNNxhpplaLOvfXyRgsgZpFPccjEEjPZgOCiZcQiClUwsCPRstnXNTAqbcwjGydmfKbDk"), 307874083, -526896.5358676391);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ErHfwgzywkyUSTT
{
public:
    double aXROoFUYGe;
    string sXNlWDpAFwO;
    string noIetyKzNHlyDq;

    ErHfwgzywkyUSTT();
    int OxQoPlyktzdWH(int KxjlKYgWEy);
    string AroqwSFiMN(bool uSCOSTaQKSIoxlXB, string nGrvzeGnc, double cXbrT, double gSTDFXpLUSUZR);
    double fndAIbXPIHJnkd(int wHieCUurBQg);
    void PNKjQDjvDRvHMTLf(string oaGWTKBDkg, int QDiBaQ);
    double JkqPeDxtySolMN(int WHspsWKWGhavBQq);
    double TApBgfzMBftaWLVk(int AUJJpITdDHOQ, bool LdETmIlHCaogj, string RwWRfVPAnLflFK, bool aVHGpWSNp, bool JrtCDmHZ);
    void JDyAl(int ciOCaXgQyBqFmms, int TfQBZbtgjmtbSc, string zRROAgTtjErc);
    void TYSXVdBQVPG(double yTiAeaKLDLKF, string fqLVY, double fuvuvjqPqeYywPca, bool XVMnpUXhDHNBSEd, double RpBGKOQPUu);
protected:
    double OMbdVwlQuwZcqxq;
    string ugZSf;
    int JZdfSprYsqrtaTMx;

    double NTPxopOK(string eqRYbYSRIXYO, double fPMcb, string UMqiJiFOfuqS, string TurDveNQAhBzvvC, double FubnQWkW);
    bool yaVHFHjloHDBkV();
    int WgtJqJgE(int dNtdB, string QkYLZIXdJovETSG, double zdvovvCCZOnc);
    void jQJxlMVs();
    double NyozylcZouLBM(string klOYrTKoCjdTWmo, bool BBpgiyd, bool eJFdQmENHfeZ);
private:
    int raScreN;
    string uPyVOQFeGC;

    void YNOogvT(double wmvgtUfAFlT, int QnONANLaOAw, bool XWYgA, double eZbhHp, double zpRtHdKcnkRkdMYo);
    int QZIxgkGl(bool mUhKhBOmzuqppNq, int kfgEVWqXzFqEixRM, double QNAJMajnAkwsGB, bool swLIn, int aoruBXKYTZMNG);
    void xYdQOrt(double sQxSDmTa, double slIdbkYlFDjBTI, bool sTXYiWLR);
};

int ErHfwgzywkyUSTT::OxQoPlyktzdWH(int KxjlKYgWEy)
{
    double xNerBHkJ = -394927.6632219017;
    double QfzZbbNEksST = -920389.6118835488;
    int tetptGZ = -112597064;
    int SfKdIBAAwZoIv = 1499201787;
    double IqYWaHekFHbt = 456722.4454446371;
    double ZiCiikUlUEt = 980299.0206693205;
    string qBYiRhvML = string("sWJaAAYFZNKGpCOIhOTltOACzhbGApenPlXSBrlTwzaUWJcVjwgEQMfbToAVaWTIsSnRVXtHlOglGglraNNFKsnfCTphmJDZ");

    for (int GvnJC = 1837718575; GvnJC > 0; GvnJC--) {
        continue;
    }

    if (ZiCiikUlUEt != 456722.4454446371) {
        for (int PebcvRbtUDjXz = 1732425623; PebcvRbtUDjXz > 0; PebcvRbtUDjXz--) {
            continue;
        }
    }

    return SfKdIBAAwZoIv;
}

string ErHfwgzywkyUSTT::AroqwSFiMN(bool uSCOSTaQKSIoxlXB, string nGrvzeGnc, double cXbrT, double gSTDFXpLUSUZR)
{
    int LVbJNbNWsE = -1648646295;
    int vRvoHdSaWLe = -1781937437;
    bool RIQwnJhW = false;
    int iMaykyjCKL = 937006995;
    string fwDjavQyHosHieb = string("jWgPqMdvcBkfsLGLCOwnlZiPwfAvYkWPVgCNxXdjChNAdJCYaMvSVcvKCdTobYypO");
    double CWyChGghdCRRejA = 654708.4498523303;
    bool odKykz = false;
    string xfHZooTxPKT = string("ivGfBoYdiIwLfEpWjrNXvMwZBKOaNRUziDLzbqZZFOygVGidKBrLVHbhJaNHaaWHqyFqiLqhPsaJYSndEdbyMEALRoGkQRThAgYDIoyyoCLZKtttupZuPZTLlDZGovStIxcbTNNTH");
    bool MgDdIPoBrdpgon = true;
    string TseovWA = string("ldWbREfYzPmCoJElbbEFlkrbftAlXqZLpirbnfcIsWhGG");

    for (int kmLFJt = 1515024463; kmLFJt > 0; kmLFJt--) {
        cXbrT /= gSTDFXpLUSUZR;
    }

    if (iMaykyjCKL <= -1781937437) {
        for (int TgKYKNgcbE = 1272859116; TgKYKNgcbE > 0; TgKYKNgcbE--) {
            vRvoHdSaWLe *= vRvoHdSaWLe;
        }
    }

    for (int dOgWnbBconj = 2053091852; dOgWnbBconj > 0; dOgWnbBconj--) {
        MgDdIPoBrdpgon = RIQwnJhW;
    }

    for (int wqAIlkZfg = 992745710; wqAIlkZfg > 0; wqAIlkZfg--) {
        RIQwnJhW = uSCOSTaQKSIoxlXB;
        fwDjavQyHosHieb = TseovWA;
    }

    return TseovWA;
}

double ErHfwgzywkyUSTT::fndAIbXPIHJnkd(int wHieCUurBQg)
{
    string xojvyigTbfelYdZ = string("LRfpXiGObjzWBqrhUuydAOixozcrICZMxEQWwpBxgXFPOWzBOAVfUtKdQUpMXkLulzqkRrbsVkvCCklYwjTJpJBquokgywbPnwzHSmRDFbzbzJaKIoIzIZBRtncsMoJMiZCpAgnTbVkHiBNtsDgxOIKGTTRYTDbdblDnJGcyTtYtIcGtfcBpZinlIvsGoJTOMsKTv");

    if (wHieCUurBQg <= -281738730) {
        for (int mxNjFZsL = 1899633920; mxNjFZsL > 0; mxNjFZsL--) {
            wHieCUurBQg *= wHieCUurBQg;
        }
    }

    return 156327.14701616735;
}

void ErHfwgzywkyUSTT::PNKjQDjvDRvHMTLf(string oaGWTKBDkg, int QDiBaQ)
{
    string jyaZB = string("DhowrmrUiViafukghfECGneNEXgDhVgVlgpStfcJmHVhZhz");
    bool FvUTXU = true;
    bool CVKlFhYdXjUW = true;
    double WRtOnjNGkPIuRGLj = 563747.8188974023;
    bool wLMmzBB = true;

    for (int dQUzDzMzignRnNp = 327939036; dQUzDzMzignRnNp > 0; dQUzDzMzignRnNp--) {
        continue;
    }

    for (int NKGbbrrHYTk = 1769402756; NKGbbrrHYTk > 0; NKGbbrrHYTk--) {
        CVKlFhYdXjUW = CVKlFhYdXjUW;
        CVKlFhYdXjUW = FvUTXU;
    }
}

double ErHfwgzywkyUSTT::JkqPeDxtySolMN(int WHspsWKWGhavBQq)
{
    int jsbrKpMnTb = 1289468467;
    bool cxDqsMBwdChWX = false;

    for (int EtntkFauy = 1725696297; EtntkFauy > 0; EtntkFauy--) {
        jsbrKpMnTb *= jsbrKpMnTb;
        WHspsWKWGhavBQq /= jsbrKpMnTb;
        WHspsWKWGhavBQq -= jsbrKpMnTb;
        jsbrKpMnTb -= jsbrKpMnTb;
        jsbrKpMnTb -= WHspsWKWGhavBQq;
        jsbrKpMnTb /= WHspsWKWGhavBQq;
    }

    return 941932.0766076341;
}

double ErHfwgzywkyUSTT::TApBgfzMBftaWLVk(int AUJJpITdDHOQ, bool LdETmIlHCaogj, string RwWRfVPAnLflFK, bool aVHGpWSNp, bool JrtCDmHZ)
{
    double OFzVTrbau = 998881.323426902;

    for (int nRbeVIJFWVKwbRq = 26069513; nRbeVIJFWVKwbRq > 0; nRbeVIJFWVKwbRq--) {
        LdETmIlHCaogj = ! LdETmIlHCaogj;
    }

    if (RwWRfVPAnLflFK < string("cTixEOQqLyaloLqpvEinxyYoKrdSWtKqHOcBbWzVLBHNANOkORPXtlmNiDDWewYjRQLDWCnwwRKpbOnnCpNTxDVEBtazbcAiJDRaxYbjuOrYOrJUIhzqqEwRtssGmBTnrmNZgBPTbQjYEudEEYnICfAeCDSXdBAeWdspbwcVuWyJZiGvHKrkzvK")) {
        for (int dqTPAr = 1074609456; dqTPAr > 0; dqTPAr--) {
            JrtCDmHZ = ! LdETmIlHCaogj;
            RwWRfVPAnLflFK = RwWRfVPAnLflFK;
            LdETmIlHCaogj = LdETmIlHCaogj;
            LdETmIlHCaogj = ! aVHGpWSNp;
        }
    }

    return OFzVTrbau;
}

void ErHfwgzywkyUSTT::JDyAl(int ciOCaXgQyBqFmms, int TfQBZbtgjmtbSc, string zRROAgTtjErc)
{
    bool LCfFQKRBa = false;
    int eQnGFdeBwjhqeEfR = -661933070;
    double LXvYQvVqhufvP = 109187.49354287113;
    string zLFQYonYxAAHxxXy = string("MYPEInRqTRdZJnPVoXbfkerEcQnEsQNsvYDzUDolUFPemlSuRUUMtInXgAhLFdxlxdqtEWBZRzGVCOtohpXTTbZydEyLqgHImmTnKGdamCmIStkcDoSVrLOKpHiHFeykTxDqPPmfkTQtzNDrpdIfAkVNnpbAVZB");
    string xmuqM = string("LhijvicjWqeEHoDngjOAzFtzPFryrbfbnkgefHopFgUxxXiQgpmJjThpjgcAvNXEJMdNqlnFgMXcrktReCtTvoOHwguegIHIClxhMUZVhqqvhKrefqonYEGgDtYfjXUoLFtsJbCnzhhtCfkPbwkvSEFsLvvDbPRnKjGOGikJRcTFydnpHVUfMsAcygdLRVKpDMgYuuctTzANNEkazWiMqeDiTYaVkWgYdoecHwyvFynMCFkVs");
    double yvmwqmbNrjfnerMh = 1028115.5917703337;
    int qIshoTgKd = -1070420965;
    int GkelknrNGqRd = -2056050331;
    int uIVDRlolHT = 1756183108;
    bool iZSmzIzk = true;

    if (eQnGFdeBwjhqeEfR <= 1634767010) {
        for (int LxenqqDdIFFOyry = 1372693922; LxenqqDdIFFOyry > 0; LxenqqDdIFFOyry--) {
            uIVDRlolHT -= TfQBZbtgjmtbSc;
            uIVDRlolHT = uIVDRlolHT;
            qIshoTgKd -= TfQBZbtgjmtbSc;
        }
    }

    for (int SkDXxYcyxEKMwM = 632703408; SkDXxYcyxEKMwM > 0; SkDXxYcyxEKMwM--) {
        uIVDRlolHT /= qIshoTgKd;
        yvmwqmbNrjfnerMh -= LXvYQvVqhufvP;
        qIshoTgKd /= eQnGFdeBwjhqeEfR;
        LXvYQvVqhufvP *= LXvYQvVqhufvP;
    }
}

void ErHfwgzywkyUSTT::TYSXVdBQVPG(double yTiAeaKLDLKF, string fqLVY, double fuvuvjqPqeYywPca, bool XVMnpUXhDHNBSEd, double RpBGKOQPUu)
{
    double yUTrPEMrL = 544320.0146882305;
    bool fHpPuqpMhXsih = true;
    int aezzakMtph = -192843828;
    string XGbOUyCuCizc = string("YjaiXYfqHtJOTjojclrqbiWTeCUKQgsFPtzlCrVoYbaOIOTJrXxvSZXTrAxnVOYAMDLVqezxsOChJvcIdIqSItbjHejhmGoAaFlxuRRTgpOThWovvuevovehuxPXMhdFxsMMsOIalCpenNhVTRNrAJbehArbqnNdVEKTWikDfc");
    bool pWvHV = false;
}

double ErHfwgzywkyUSTT::NTPxopOK(string eqRYbYSRIXYO, double fPMcb, string UMqiJiFOfuqS, string TurDveNQAhBzvvC, double FubnQWkW)
{
    bool JGbbusFgPUVop = true;
    double YUZOKZ = 37079.44012792389;

    for (int BgxvcsUlCqGQV = 1798919182; BgxvcsUlCqGQV > 0; BgxvcsUlCqGQV--) {
        eqRYbYSRIXYO = TurDveNQAhBzvvC;
        FubnQWkW -= FubnQWkW;
        FubnQWkW /= FubnQWkW;
    }

    for (int yPszTvYdOHeLEaQ = 1458387712; yPszTvYdOHeLEaQ > 0; yPszTvYdOHeLEaQ--) {
        YUZOKZ *= YUZOKZ;
        FubnQWkW *= fPMcb;
        eqRYbYSRIXYO += TurDveNQAhBzvvC;
        fPMcb -= fPMcb;
        YUZOKZ *= YUZOKZ;
    }

    if (eqRYbYSRIXYO <= string("rjzxMYbokKimqFsrJkWnQUSOFQzibPmaPRRUESVSrCjjSiyhrqBqpeSVyKYEurTpgcKbkKlvyTyKuSQLWpLOnIdtsacOZLUjteqkfhllfOiCTcBPKmPejxyPptGzyBeKETakuEhzUAZzE")) {
        for (int bpAFTweX = 1334011034; bpAFTweX > 0; bpAFTweX--) {
            TurDveNQAhBzvvC += TurDveNQAhBzvvC;
            fPMcb /= FubnQWkW;
            JGbbusFgPUVop = ! JGbbusFgPUVop;
        }
    }

    if (fPMcb == 261929.03242851238) {
        for (int Tmrkwv = 1020009713; Tmrkwv > 0; Tmrkwv--) {
            YUZOKZ = YUZOKZ;
        }
    }

    if (JGbbusFgPUVop != true) {
        for (int LQATpc = 436939157; LQATpc > 0; LQATpc--) {
            fPMcb /= FubnQWkW;
            eqRYbYSRIXYO = eqRYbYSRIXYO;
        }
    }

    return YUZOKZ;
}

bool ErHfwgzywkyUSTT::yaVHFHjloHDBkV()
{
    bool RZokbtutCLC = true;
    int rBBBPKs = 1171627369;
    int IxBBQLzUNH = 1044064847;

    if (IxBBQLzUNH > 1171627369) {
        for (int GfmSmVCTnxohi = 1514298908; GfmSmVCTnxohi > 0; GfmSmVCTnxohi--) {
            IxBBQLzUNH -= IxBBQLzUNH;
            rBBBPKs = rBBBPKs;
            RZokbtutCLC = ! RZokbtutCLC;
            rBBBPKs *= IxBBQLzUNH;
        }
    }

    if (IxBBQLzUNH != 1171627369) {
        for (int ErzuesJhtVt = 229519214; ErzuesJhtVt > 0; ErzuesJhtVt--) {
            continue;
        }
    }

    if (IxBBQLzUNH < 1044064847) {
        for (int LPhLQbw = 594668586; LPhLQbw > 0; LPhLQbw--) {
            RZokbtutCLC = RZokbtutCLC;
            rBBBPKs *= rBBBPKs;
            IxBBQLzUNH -= IxBBQLzUNH;
        }
    }

    if (IxBBQLzUNH >= 1171627369) {
        for (int omIoGnFVdYxA = 287281647; omIoGnFVdYxA > 0; omIoGnFVdYxA--) {
            IxBBQLzUNH /= rBBBPKs;
            RZokbtutCLC = ! RZokbtutCLC;
            IxBBQLzUNH *= IxBBQLzUNH;
            IxBBQLzUNH -= rBBBPKs;
            rBBBPKs *= rBBBPKs;
        }
    }

    if (IxBBQLzUNH != 1044064847) {
        for (int OmKjwmhAPrddnYP = 107723932; OmKjwmhAPrddnYP > 0; OmKjwmhAPrddnYP--) {
            rBBBPKs *= rBBBPKs;
            IxBBQLzUNH = rBBBPKs;
        }
    }

    return RZokbtutCLC;
}

int ErHfwgzywkyUSTT::WgtJqJgE(int dNtdB, string QkYLZIXdJovETSG, double zdvovvCCZOnc)
{
    double ZzIGVNgAU = 546820.0385995044;

    for (int xCgwnRnhrGm = 1060616122; xCgwnRnhrGm > 0; xCgwnRnhrGm--) {
        zdvovvCCZOnc = ZzIGVNgAU;
    }

    if (QkYLZIXdJovETSG <= string("BCahkMPPmMosWbsnaPjVPWIJWkmm")) {
        for (int gTbBAVACiEuJXNT = 756187280; gTbBAVACiEuJXNT > 0; gTbBAVACiEuJXNT--) {
            dNtdB /= dNtdB;
            dNtdB = dNtdB;
            ZzIGVNgAU *= ZzIGVNgAU;
        }
    }

    if (ZzIGVNgAU >= 568674.9085213448) {
        for (int LImLOF = 543739999; LImLOF > 0; LImLOF--) {
            ZzIGVNgAU -= ZzIGVNgAU;
            ZzIGVNgAU += ZzIGVNgAU;
        }
    }

    for (int lPXoDFLFfLxUKir = 1276889625; lPXoDFLFfLxUKir > 0; lPXoDFLFfLxUKir--) {
        ZzIGVNgAU += zdvovvCCZOnc;
    }

    return dNtdB;
}

void ErHfwgzywkyUSTT::jQJxlMVs()
{
    bool nXLeEuFMyfvgDpcQ = true;
    bool SLzkwvTQf = true;
    int FIPEjEcjvxmyHwF = 1412673717;

    for (int KnrWpWbszNZtCRP = 458618338; KnrWpWbszNZtCRP > 0; KnrWpWbszNZtCRP--) {
        continue;
    }

    if (SLzkwvTQf == true) {
        for (int yqiXlpcsY = 1081831724; yqiXlpcsY > 0; yqiXlpcsY--) {
            continue;
        }
    }

    for (int RIZpXphHgjYn = 572576082; RIZpXphHgjYn > 0; RIZpXphHgjYn--) {
        FIPEjEcjvxmyHwF *= FIPEjEcjvxmyHwF;
        nXLeEuFMyfvgDpcQ = ! nXLeEuFMyfvgDpcQ;
    }
}

double ErHfwgzywkyUSTT::NyozylcZouLBM(string klOYrTKoCjdTWmo, bool BBpgiyd, bool eJFdQmENHfeZ)
{
    bool qecgOtjpsjQsac = true;
    double gPecBtXylHy = -831443.5838879099;
    bool LuWMtUtHm = true;
    bool MvgVj = false;
    bool OwqCPCFNzFu = false;
    string aPsLGPrv = string("rTCJXJQOVzpORiuNotaycyIvgrwmTrMfHOkXExOmKNrPipmeaJzzWyOoiPDBzgqwbXjheSptmvDzqwuPjtWcBqAeshVxJcnYLYcPVjAhWWPGKWPNdaUwGvIknlgafREvwlUhYOinCccyoVIVRaTzTogboxdftowxikuLbvFScrqQcjiLaKTuAJdlfbFEUCFiRXqhRhXC");
    string TXdPsLCDl = string("kzSScrKEcdWkNDJcthzbZyjfuFGOxXdDegUhWMoNqDbeZEMAloDlmMWehRFfphdnpFurNpGmlJxPJtnUMPRuoXXoylSxWaDfmYepIdtM");

    for (int rljmqHfOhgT = 2122487440; rljmqHfOhgT > 0; rljmqHfOhgT--) {
        eJFdQmENHfeZ = ! MvgVj;
        MvgVj = ! BBpgiyd;
        eJFdQmENHfeZ = ! OwqCPCFNzFu;
        qecgOtjpsjQsac = BBpgiyd;
    }

    if (LuWMtUtHm != true) {
        for (int OzzXxmoyrHcEJ = 2019145596; OzzXxmoyrHcEJ > 0; OzzXxmoyrHcEJ--) {
            aPsLGPrv = klOYrTKoCjdTWmo;
        }
    }

    if (aPsLGPrv < string("EZZYToCGaCOqNPlAvZeIhFWGXkXXnLJjVAWlCezYnOTgfJNPiDkITlJzkttmGvnKSXBsQXeitN")) {
        for (int tkdubg = 2064807547; tkdubg > 0; tkdubg--) {
            continue;
        }
    }

    if (klOYrTKoCjdTWmo <= string("kzSScrKEcdWkNDJcthzbZyjfuFGOxXdDegUhWMoNqDbeZEMAloDlmMWehRFfphdnpFurNpGmlJxPJtnUMPRuoXXoylSxWaDfmYepIdtM")) {
        for (int rtKkXZUXeIMiEWC = 2134720340; rtKkXZUXeIMiEWC > 0; rtKkXZUXeIMiEWC--) {
            MvgVj = LuWMtUtHm;
        }
    }

    return gPecBtXylHy;
}

void ErHfwgzywkyUSTT::YNOogvT(double wmvgtUfAFlT, int QnONANLaOAw, bool XWYgA, double eZbhHp, double zpRtHdKcnkRkdMYo)
{
    string diDik = string("VlIuCRnDTuOKWfPCNHFTNbELZRhRgRqOZKpvydDWIfIcDXTwiVHrAeEnulbmmljMtrmpiurhpduSyQkUOpzDDNBufOeUsDdfCaYZyOnfXYLpRJTxlYtNNcrHJURlynWNtbhDsMlOARxjtYnyHBymqjAhEVoOSHEYUkLZOESgn");
    double qmhzAeeMqkiz = 172371.1766597061;
    bool GcSytWZMtQv = false;
    string gpuoxBwTqh = string("hTlzReubbGJmkcgvAtWzVZHRHCXCRjieyPDoeMpiEqnKMIyqMYHRNSxSlJPxYqyXtiqOkREHJfoaIrIsyQLXjNlGifUdYAVYubBuaeJduhXvK");
    string MuvmdCOHoWlYiD = string("lmqvKdHQLAGfOtnfRmbztFnQkeKSotQtByeUSzogZlSHgPyMLfrYgDsUgLTBPmoWCbolambMMemVnVnOCDWgPxyNBHsTYWgytZGkBwCPTQfcWDHvqnAnjKgdzdVKRBbyPjhVjlLEpnBIFWjDgtlymQNPTtNcOgAYtEWMPWDuXUwVwiJSBQplSSaCryvxnKbWReSKDw");
    bool lQFblaCsew = true;
    double JafrHF = 961068.234514363;
    int GXZmytDNASZuYPID = -533964640;
    double jzsjiIRI = -765020.0180264637;
    string CyylQdZfxupVRus = string("QtHIh");

    if (MuvmdCOHoWlYiD != string("QtHIh")) {
        for (int PwPlyNCfHSH = 1958092047; PwPlyNCfHSH > 0; PwPlyNCfHSH--) {
            jzsjiIRI += eZbhHp;
        }
    }

    if (JafrHF <= -927101.7149662134) {
        for (int uIDMLqBIkxFhqOhT = 77014499; uIDMLqBIkxFhqOhT > 0; uIDMLqBIkxFhqOhT--) {
            continue;
        }
    }

    for (int PmLgzGfGG = 1963583327; PmLgzGfGG > 0; PmLgzGfGG--) {
        wmvgtUfAFlT += zpRtHdKcnkRkdMYo;
        JafrHF += jzsjiIRI;
        qmhzAeeMqkiz *= wmvgtUfAFlT;
    }

    if (gpuoxBwTqh < string("lmqvKdHQLAGfOtnfRmbztFnQkeKSotQtByeUSzogZlSHgPyMLfrYgDsUgLTBPmoWCbolambMMemVnVnOCDWgPxyNBHsTYWgytZGkBwCPTQfcWDHvqnAnjKgdzdVKRBbyPjhVjlLEpnBIFWjDgtlymQNPTtNcOgAYtEWMPWDuXUwVwiJSBQplSSaCryvxnKbWReSKDw")) {
        for (int oXlbpWBKB = 726277955; oXlbpWBKB > 0; oXlbpWBKB--) {
            eZbhHp -= qmhzAeeMqkiz;
            qmhzAeeMqkiz /= zpRtHdKcnkRkdMYo;
            lQFblaCsew = XWYgA;
        }
    }

    for (int wcpQKZUsfc = 160562804; wcpQKZUsfc > 0; wcpQKZUsfc--) {
        XWYgA = XWYgA;
        JafrHF *= zpRtHdKcnkRkdMYo;
        qmhzAeeMqkiz -= JafrHF;
        QnONANLaOAw = GXZmytDNASZuYPID;
    }
}

int ErHfwgzywkyUSTT::QZIxgkGl(bool mUhKhBOmzuqppNq, int kfgEVWqXzFqEixRM, double QNAJMajnAkwsGB, bool swLIn, int aoruBXKYTZMNG)
{
    double vTFebJRF = -67192.28408448609;
    bool AuhqtEXJlzg = false;
    string ejZINEgzzBXnjntN = string("HulsKbOfFOzzpCUGxkHWvUSPiydhbARqviPhZkMGcMsDHYmvPaeeURYRSamEtYuvtYfUQjztJJblMIyZhOFtjYXNxecwFeVrRPlzGtSBtarCyCGtdpO");
    string cAmAfrefeYpMw = string("MhcdhrlOPsoqqiBBMinJyklutWSeECTamXdekWNIkLBzyWxkTfoveiyfOTezwZzKOwysqncmsrSXhFfEruiNftjoeDDWVsdKVooHzZSqqVvcotvDWpEsjfVNVHrwtpDXCbceAOYPKOoBFpuLoZrjIndFFUkeoAKDttbeUsdNNVajgzydfmTTeYeeYRoPWonxQSTRl");
    bool BJQereBuTO = false;

    for (int waUysKMvuspqran = 1697443919; waUysKMvuspqran > 0; waUysKMvuspqran--) {
        continue;
    }

    for (int UjekaANZbSSyRDMa = 393701630; UjekaANZbSSyRDMa > 0; UjekaANZbSSyRDMa--) {
        cAmAfrefeYpMw += cAmAfrefeYpMw;
        aoruBXKYTZMNG = kfgEVWqXzFqEixRM;
        ejZINEgzzBXnjntN += ejZINEgzzBXnjntN;
    }

    return aoruBXKYTZMNG;
}

void ErHfwgzywkyUSTT::xYdQOrt(double sQxSDmTa, double slIdbkYlFDjBTI, bool sTXYiWLR)
{
    double ZjUBfHlzWfbhoMQ = 756500.8502756656;
    string ImmGLZRvbFfZWMB = string("vpJsdaeJwSFnUPluURdNWBSSpnyWoDVoLjYDLjzQjYilRdkisNGknSQZhqBeASCdbVYVyuWos");
    double OvSydeK = -633775.9907502495;
    string kBhmNUudmr = string("iWNmHNZUFGJYcvogwFxRuZlYXpoTuCaKOIytDcEWJzlOcgaPKOpjEH");
    int itnZxMBQ = 2060676594;
    string WnPvhrBsdCF = string("HOvaffEOUigbpnkShooUpOhsNumebMVwcbtiSUMfNJrjAUJfLlyuTnmggOvLacoNQtjOSSeIXwIRHMsHyOASPQPNYfmxtXYRgVeOnDpnrAanEwNuXvOROeFVbfmJKSckTmDWHelchSaolIYZJMpTanHAnxwhRYWgNCEMuMmYYSumRz");
    double KqpwMKZExlM = 1016045.923609112;

    for (int GFuFcu = 137950137; GFuFcu > 0; GFuFcu--) {
        continue;
    }

    for (int hHnCuGWQDDewAhXL = 1423889242; hHnCuGWQDDewAhXL > 0; hHnCuGWQDDewAhXL--) {
        KqpwMKZExlM /= OvSydeK;
    }
}

ErHfwgzywkyUSTT::ErHfwgzywkyUSTT()
{
    this->OxQoPlyktzdWH(2064069202);
    this->AroqwSFiMN(false, string("rxHYsFttGheNKrDEYmyAgfXrVCZDZuDCpiMfyWukRirCQjafWLPeuNSTzIEJTSitJKlLdEiLegODNHszIaXjoxBvCNMJLneDVLqvzihJaIZOuMPimpYKVNtARnZJfrsEJnDAxanLBaRqTLIUdkWStRoxzMsUxnLSapulDuFAVCMURuyFIcfDewCaUttPEIdBJQOkiY"), -879286.967335376, 1024274.6241592972);
    this->fndAIbXPIHJnkd(-281738730);
    this->PNKjQDjvDRvHMTLf(string("ffDgiqIIviVtGshIRINzwVIJxLHWGBnwrguQkucrMILiyxIobAtftapdeZAQgqKflGhnahMoigt"), 1309161833);
    this->JkqPeDxtySolMN(1535132844);
    this->TApBgfzMBftaWLVk(-171300895, false, string("cTixEOQqLyaloLqpvEinxyYoKrdSWtKqHOcBbWzVLBHNANOkORPXtlmNiDDWewYjRQLDWCnwwRKpbOnnCpNTxDVEBtazbcAiJDRaxYbjuOrYOrJUIhzqqEwRtssGmBTnrmNZgBPTbQjYEudEEYnICfAeCDSXdBAeWdspbwcVuWyJZiGvHKrkzvK"), true, true);
    this->JDyAl(1634767010, -767357874, string("TvifSpUcBbJhAtzGLIqhfVTCesNStXBzPKTIuhYsSYePFQFMIgfjSvmuUuObcgCREBFztBGdYCSYpDKpVRNHHVobfnvuUUDqRtNiljYwYJmulEuPoVOcliDvpaEfaBWsqHpMBEDtTlqmPTtHHONJxpmivbxwBKxTWNEaXhkGpGi"));
    this->TYSXVdBQVPG(-960959.9789112365, string("jpnhMdcJYZfnZGjvqFgBgpsqpCxinmpQLejWMGorHZLOMhUMmvzesNpPkEQkSPhlUMFgWRagDWPpVwzHmHXNyQdFESuWknVrkAtbbsLcnQEDIKhEAdDxdNBQmGeXNNFVnnoZPkcVQRhepFiogGPWDxFXQzhFvcAvboMFiYQIuCTMFJvozoAs"), -693741.5845556473, false, -281611.1038404685);
    this->NTPxopOK(string("gmiEakA"), 261929.03242851238, string("rjzxMYbokKimqFsrJkWnQUSOFQzibPmaPRRUESVSrCjjSiyhrqBqpeSVyKYEurTpgcKbkKlvyTyKuSQLWpLOnIdtsacOZLUjteqkfhllfOiCTcBPKmPejxyPptGzyBeKETakuEhzUAZzE"), string("BlqwbSyGmDdYdxsKiXHkxbgHydnQIRjezXFtDcczPQZJOwggZeELQPqOMuKWQFJaqbPEOsHhvvMuGcSMCVfCkUgvfzUZkHrkTFozUpPdoGiWYSOvbkZmBVXIBLzmFFHQGINKGungitRVGcYDzOrhcZIqrlBLNwuaUgCPchDSjMuSAOspjqvZWhNJvAPHALwhhhoGbqRyGKNEiFsRjDYplfWOLAJeTHjyFpZDwJngSxHvi"), -723642.6724913063);
    this->yaVHFHjloHDBkV();
    this->WgtJqJgE(-1089782204, string("BCahkMPPmMosWbsnaPjVPWIJWkmm"), 568674.9085213448);
    this->jQJxlMVs();
    this->NyozylcZouLBM(string("EZZYToCGaCOqNPlAvZeIhFWGXkXXnLJjVAWlCezYnOTgfJNPiDkITlJzkttmGvnKSXBsQXeitN"), false, true);
    this->YNOogvT(-1009822.2439386732, 1096338301, true, -927101.7149662134, 460551.29466387624);
    this->QZIxgkGl(true, -595750564, 278153.3662930458, false, 1856318099);
    this->xYdQOrt(-567453.2146804751, 236992.62041520205, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hXPWesFyxgd
{
public:
    int CjpnLqxspkwPz;
    string DZplMqvWRF;
    int agoeBMPYfpAlUrx;
    int QdOpvAdlsRxcA;
    bool IphwwmySbxkq;
    int yBeKaErplrkS;

    hXPWesFyxgd();
    void HLKfHjTMeY(double smCEefMyVBzyj, double qaiqOjmfzcG, int CmlJUdaJ);
    void vXzgqLZ(string ocHctHkXUansKrNV, int ruFFtv);
    bool DSfzFAogBMzkzDK(double SyBagYCXcqwLHmR, int rpNVxOwOv, double xszxnOrDsTgevs, int KEBCbEaFs);
    double mOVwtd(double ScgpGImpUkxQPFV, double Lnmrjct, string ugFGayrChyR, string VHzafzcDsmxvcVif);
    bool dLDLlJ(bool GrStVayBTaa, string OehPgl);
    int bSaICd(double mSnhoFDjRJAfWfZ, int jtcwpmpsWiRZSJmc);
protected:
    int YXIGeAVCSQh;
    bool RMlBU;
    double ibHoYhcQnk;

    int INbeFLhixG(double GfMTyFAdOKdlPOpA, double SSbdCExstG);
    void tdyjeMiWJiDlxpYC(double NHkvIqjbnS, bool CNNdlgAFvQGgO);
    int MPCKZvD(bool HqxURdtuxS, int ZSqSo, double ghBRnWns, string yEeuczbMmSi, double MbxkyZ);
    string lKqQvEZrOGqTRPpp();
    int QjTlwwMK();
    bool xwhezzwgqdDWl();
    bool wZbYovlPQgwIbE(double GgpSS, double AHZsEoqXBIptP, string ReuWpGiKcx, int luGegtMjGRecRiD);
private:
    double kXVzpvZuGP;

    void UCzvnqyCYoNUv(int ptlITTrkZmgtocS, int gmIQGmtLz, bool jhBtEIUOwKS, double piRphADFd);
    string oqJjfvNoV(int nBcLxcBR);
    int jPyxOfPtr(int ALncf);
    string WAydzKzKWf();
    int nHWwhgTn();
};

void hXPWesFyxgd::HLKfHjTMeY(double smCEefMyVBzyj, double qaiqOjmfzcG, int CmlJUdaJ)
{
    bool pujvtNkP = false;
    int AazffReEAoNvXCpQ = 65875387;
    int SHaqschzp = 884398160;

    if (CmlJUdaJ >= 884398160) {
        for (int iWJmGSQXXQ = 296108763; iWJmGSQXXQ > 0; iWJmGSQXXQ--) {
            continue;
        }
    }

    for (int pKacojkeu = 623675714; pKacojkeu > 0; pKacojkeu--) {
        CmlJUdaJ /= SHaqschzp;
        SHaqschzp = CmlJUdaJ;
    }

    for (int WOHkrZVKTU = 255403768; WOHkrZVKTU > 0; WOHkrZVKTU--) {
        AazffReEAoNvXCpQ -= SHaqschzp;
        pujvtNkP = ! pujvtNkP;
        SHaqschzp += CmlJUdaJ;
        CmlJUdaJ *= AazffReEAoNvXCpQ;
    }
}

void hXPWesFyxgd::vXzgqLZ(string ocHctHkXUansKrNV, int ruFFtv)
{
    int oxKyf = -809152409;
    int rgceTfPGALNJo = 1911466610;
    double sYorJrKRnmEZd = 515562.99116620613;
    double qiEoCPySJju = 680325.8944551648;
    string kFjDVduM = string("TaUNwuYJHLclVgABfCWIAzgCZGKnSMkWwzHNsjfEQddsCvrOBObyazsOmafJXsVMlBRjAiJHapKfbRVYqrFWHZlBXSbJrDomBHDQrzGsxPE");

    for (int zejhvJFbOrfPFjax = 125935339; zejhvJFbOrfPFjax > 0; zejhvJFbOrfPFjax--) {
        ocHctHkXUansKrNV += kFjDVduM;
    }

    for (int QuzyonpMbQSK = 2108648722; QuzyonpMbQSK > 0; QuzyonpMbQSK--) {
        oxKyf -= rgceTfPGALNJo;
    }

    for (int dgONdFDqHMi = 1619972604; dgONdFDqHMi > 0; dgONdFDqHMi--) {
        continue;
    }
}

bool hXPWesFyxgd::DSfzFAogBMzkzDK(double SyBagYCXcqwLHmR, int rpNVxOwOv, double xszxnOrDsTgevs, int KEBCbEaFs)
{
    double BHtBfRXFXkjr = -460666.73515886534;
    double iRlqTXzOJB = 419464.756128957;
    int zPukoLEpy = 1032605241;
    int oqYPuQrAQgV = 670298;
    double FIvNgdYSXTD = 500153.77317298483;
    bool RkgWl = true;

    if (xszxnOrDsTgevs > 500153.77317298483) {
        for (int fRKPm = 829806869; fRKPm > 0; fRKPm--) {
            rpNVxOwOv -= rpNVxOwOv;
            oqYPuQrAQgV = KEBCbEaFs;
        }
    }

    return RkgWl;
}

double hXPWesFyxgd::mOVwtd(double ScgpGImpUkxQPFV, double Lnmrjct, string ugFGayrChyR, string VHzafzcDsmxvcVif)
{
    double UOSRnonbjhQdstb = -208005.13040126636;
    bool jumYL = false;

    return UOSRnonbjhQdstb;
}

bool hXPWesFyxgd::dLDLlJ(bool GrStVayBTaa, string OehPgl)
{
    string KskiJkMSonbhaQN = string("nFDImjQyTiPgQjxpdmYeaYbakxsEWRgSCSuDinPiCXzHiOpLEPedHzCcDMmTvwQTAaoVCmiCFVhaUsqLqbKBMzHjztabpdHzLaKHXBVCCpqpkPoZW");
    bool tzWepqTi = false;
    string ajKbnS = string("WyaeTPbIyLNVvHQBSaTimEhhXtfmrxOTnwJOaWRURunYLhYYzXyHBFqcQNlUAxtSemawzYFNdoQFtWuLzAlsUhXkyPHEWjYogwmCDFiMMyxmIPkjEkhtWqjvebUUBDrcsqmQJIPkiRoIJkwWBsKTGVMfAaxmjEIwiPeOFeqMWUKAEbr");
    int BEMqr = 248796217;
    double WDcZAx = -954425.1561161984;
    int FYtJazUyeRHlMjqx = -5313901;
    string zNPgXgziewiz = string("hviiutXkKyzsbjxgUEcpuSIpEhclHAdLtDyLsPoybWSaUYcSQmZxZwaCxYawnxmsiWQgkjSngPsdOZmIXTuinsGNrKaQOICuc");

    return tzWepqTi;
}

int hXPWesFyxgd::bSaICd(double mSnhoFDjRJAfWfZ, int jtcwpmpsWiRZSJmc)
{
    int oicBj = -583113651;
    double GGbIAkniUkeyIdLb = 688145.6360991318;
    int ysmkugCPOQ = 1048076495;
    int PAuKiuzGJP = 1784942140;
    int SHfzAMTwOkp = 117298096;
    int ErhBBkj = 823100920;

    if (oicBj <= 117298096) {
        for (int eZBkLsfThoYg = 218853154; eZBkLsfThoYg > 0; eZBkLsfThoYg--) {
            ysmkugCPOQ -= ysmkugCPOQ;
            PAuKiuzGJP *= jtcwpmpsWiRZSJmc;
            ErhBBkj = oicBj;
            PAuKiuzGJP *= PAuKiuzGJP;
            ErhBBkj = ysmkugCPOQ;
        }
    }

    return ErhBBkj;
}

int hXPWesFyxgd::INbeFLhixG(double GfMTyFAdOKdlPOpA, double SSbdCExstG)
{
    string hyjRvdwdKRowU = string("AUWClhqDNiZYrrnLIOiAchEnXjEErxStYTssFDmTXQekJLhCMnM");
    double UhEsiMLhN = -416114.35139411583;
    string ZIyPVQNf = string("LEtUCuApDOIyFeoEoApPpWYjeitGKzSFwwcZOaREllrVwJOjWJMnGUGCRgZRTKIEZXuJTxNBRlNgHzPjeFRgziifNJBfLVHAdVzvEXCGAUsZibNHydRAmXxkaNvDJJSEAVMAjEIXOenHelXGnUCEyqNwpRhqyrADPhVaFVebWMszvTwyupkdmZgOPFiJFqqrtbqReLlvLruLSNUXvzUKfGufyvVTzEmXrIPglpeva");
    int oqFClXnXBysvud = 2122864112;
    string SSVjkcvRoIRIZUBX = string("eFufRHOhYmBYawbvYSGATmeAWFBdqbIKRollxwsDCFSPveyJwsAClfTIKDeUvkEtVXYrJKLBcCKUvnewekVVgkoVNYkWbBdgDUwrHTVyTkXrnpvcBJEjoWVZOMmIepUODwUfxRAJhRRgWAsRjvUPKEDVlImEbgtgRToGjcKFjojDrtCvRWIFGOzFeqIbkVoyaspOPBKDkRDnOUJalLaaCKmWqzrXnaWvkBaGfWg");
    int zuMlxUpswZHUMUHQ = 666848599;
    string EKSER = string("VPPlU");

    return zuMlxUpswZHUMUHQ;
}

void hXPWesFyxgd::tdyjeMiWJiDlxpYC(double NHkvIqjbnS, bool CNNdlgAFvQGgO)
{
    double iGjfNxVE = -679660.2911540384;
    int FWrUdqIVIgbuFeL = 230796338;
    int DdvqhSfWNsFExUaI = -1501207051;
    bool xrhkEBHBmN = false;
    int GyFjpzrcDEu = -1319797126;
    string jOXmLKYWhdnkmjF = string("eFQKHpnDCuwZttUvSYmrFIRpqgLolLHbBDevttyrUCLsRQjOPQyOjMLfppHRErasBqLJoYLrClswDynimxdOJGXXirGBqzloILVXOqEDJUWgWYmczPXoALuERXcIsjyYzctEjvQtdZvdUZirkYkRNDqybqnNPtoELFFXMLhDmTDsHLMgOyXgvkzUzEVzTnrmrNyhgCzhCIYjhihBkOGcAtMkeKVpssgIwlWvGtT");
    int VShNswcHpNUj = -1489701282;
    string JsHMWyTbtSz = string("EOWcUbvjKWaBDyCraZvmZUGUpskvIpQKiRmjwWGcMJorQxeYMgm");
    string wWvefbgmvdJxHRB = string("CMjygAFqBWsGBzLmJxFoRMJJOyIlGGPhTWHzqxWWqdxlFXmnChCCgVmFEBWaFXlsHWDBRUlQdgKcjfkWZasDrnpHVKLjBSRJVYkhavHTPfwqIsNrboZkQIon");
    string cVdtuAIYEVm = string("pxtSEvISbBoKeEHHUkleBUjITEfxZiUQFZQwpJqloEyXfjOtvmJtfqmXsOr");

    for (int dtcuf = 1289585565; dtcuf > 0; dtcuf--) {
        GyFjpzrcDEu -= VShNswcHpNUj;
        cVdtuAIYEVm = JsHMWyTbtSz;
    }

    for (int jXmDTFwr = 1364620477; jXmDTFwr > 0; jXmDTFwr--) {
        continue;
    }
}

int hXPWesFyxgd::MPCKZvD(bool HqxURdtuxS, int ZSqSo, double ghBRnWns, string yEeuczbMmSi, double MbxkyZ)
{
    bool lnXKJOBLVPf = false;
    double EoyueYXl = 344252.7407120946;
    string sokcxYOYs = string("mRSknChFOIStXsHvlXAWjqmgCLsCqiQvMAUKxNNqNAONAcIbCFvTXWFSwXNXrOiDIZkxvJAOkMLnXPKpfIgGgjIlAWzMkRZQFlYIcWyTCEriEgNElDigDRhDUJtpjAgkVPBBsbWjNiOWmpVvMCRFXCWmHULYwZgAMUHxrkzhxQBRmESg");
    double FmbCstygtwxuDT = 1044381.057668563;
    bool GcgLSuOgaRwAMMax = true;
    bool njyGXdpmXNEXHEyZ = true;
    string wBnLyGaaNyHEhMZQ = string("VdGpBNrFTKgMALrBxhjXeshxrzTuUbtdWiJfNIPKnpOrTcCoWHOtxiftiHNswEFZRXNzyiZYJIcakRNKtXNywCHaqkYtTGBPFSCqgtkTKyIlhyuXWgKjpCDHzJfGFMCEIglzxwChVKYlxfzYgCpUDLEDAvCIkXgfoWmInlDCOlzNYMYYyNCnATktpOShjMkQzKjqqZxHtlSNJTpXILfMsdtCAXFFQUzpsEbemJzXeAymSodQHBCqhcYtHMUOytL");
    string FwxMkEwXffuID = string("jUhfQgKRgLFQiBPWmrOKxTDGtJxCAGJFbyfTohhgAyenHtNKmhjTZZWnxrIYXGoDlcTbKKqtGnWHLCaNENIc");
    double aiQOQaMk = -930643.5546298254;

    for (int wTjXZJSD = 1027100538; wTjXZJSD > 0; wTjXZJSD--) {
        FwxMkEwXffuID = FwxMkEwXffuID;
    }

    return ZSqSo;
}

string hXPWesFyxgd::lKqQvEZrOGqTRPpp()
{
    string SShPoZSfxlnUWiaD = string("eUgGRaqKVItzGVXgYwJMGKlrQVOLEzFTVhFPpxoXfihzcNDonUFPwiESFxoBwQOjOyyzlkJacWTMTNxSZPpHtYrLrNoIVYvYkNAYDNbFkmXeOVPRoAsAciKnOMMRuskFxkZoSVBwToCTABrAipdRLSkGxJVAiwjGl");
    string wrkKTVao = string("qgFmKdPQxTTwrTRuMRorPyLUyrPEXsyUjyHZwzRSwFOgjrxXaSqqXUGsFpvmcwXXcQedlQoWdtvmhsHlJGnlEyoPGDInyLhcPzfOCXQdaVBtRCWcTfhICNPXiZWJTqKgkXIpxvHXksAgKQRknwjmjsZODGJGIjwnETQlgDmbMewSwRoSBbJkQGcDI");
    int hGdHp = -1433768795;
    double TWeOYHETsWN = 593688.1884224184;
    double NsGqjrDwwkaxy = -292871.00408516935;
    int NmxoHB = -808356423;
    double bCLaS = 573547.122549061;
    string jcRmr = string("PYyJLrWdcKKvIMcocPiYXzVFlXdyNWauWwKJdRgJBorbGDZSPWcpujWnQzYkIRFEoesWMHXsgDUJdIApchSTMghlUDyiyXVAGmdivRJnehHEZrBRreEtNGOFacQnJnWLMUKsHmFitsGgYjONOagEuLquPlhJJSFoCNMgpRntGKAIJvPcwXSuXClVRPyBTpKuUOEJwhOabqzDhrJLTnIXixtBBjRjlFRVQKGS");

    for (int nsWfvmqQNxVNcJ = 1111122869; nsWfvmqQNxVNcJ > 0; nsWfvmqQNxVNcJ--) {
        jcRmr += jcRmr;
    }

    if (TWeOYHETsWN < -292871.00408516935) {
        for (int ZUHEshMl = 1651768872; ZUHEshMl > 0; ZUHEshMl--) {
            continue;
        }
    }

    if (wrkKTVao > string("qgFmKdPQxTTwrTRuMRorPyLUyrPEXsyUjyHZwzRSwFOgjrxXaSqqXUGsFpvmcwXXcQedlQoWdtvmhsHlJGnlEyoPGDInyLhcPzfOCXQdaVBtRCWcTfhICNPXiZWJTqKgkXIpxvHXksAgKQRknwjmjsZODGJGIjwnETQlgDmbMewSwRoSBbJkQGcDI")) {
        for (int zJhCjWzArP = 809218942; zJhCjWzArP > 0; zJhCjWzArP--) {
            continue;
        }
    }

    return jcRmr;
}

int hXPWesFyxgd::QjTlwwMK()
{
    string IAMaqAMmv = string("GkdJOIeJGQkbOhNlaGepgbqNeEHgwHWQqyAmcAPKTshjOBjHzRvzwjZaONvnpAEpglDeppwowjFlyRgOlrkqOLBFThXkCCsTsNsSgNONVeDOOPtFckiOirXOxZBQGTTHxwDivTFnJhNlSUZfuQeDzncPycCjQupcB");
    string KdGtqemlGABUXfZE = string("DMAevLNYEPQFnYnuhtOzJRAmDIfjRwCZJUuSICMvMBvQaOXbYNGsutZxENFszinpbhnKzePCbuLcrdxHRZwEXBYDcBnBwDTJYrCIOreHFIqPfDYEzgkvFAHRJgSRTLViuOHwyYVxCaanyTSTAebjptkAa");
    string grDvYks = string("gVEXoAlyzHSJrNWdZZuWymmJrarYtdLpXGIfgTpKGfbIzKqHFXEGNzYQcIbFgGGvLgAbOyAgiFhYoKOaVCBXNcgrUBRbpriPPYYQhWrJTkVcgHMHQnneoNysOgiSVFqNPgKillFntuDgLNPRiekjfkeWQhDJhOFYxWXGfkPJbIFnFWCllzLThrlbLRmlEneqtgBkKqIyatbMZWDSVTXAfSSiwfukAgzOYCHWwjiRpnBlrkzbtligjOCVFrUMWpV");
    int llPTZUJ = -585908209;
    int SIaScW = -108370488;
    int PXJWcDZGG = -1337373097;

    if (KdGtqemlGABUXfZE >= string("gVEXoAlyzHSJrNWdZZuWymmJrarYtdLpXGIfgTpKGfbIzKqHFXEGNzYQcIbFgGGvLgAbOyAgiFhYoKOaVCBXNcgrUBRbpriPPYYQhWrJTkVcgHMHQnneoNysOgiSVFqNPgKillFntuDgLNPRiekjfkeWQhDJhOFYxWXGfkPJbIFnFWCllzLThrlbLRmlEneqtgBkKqIyatbMZWDSVTXAfSSiwfukAgzOYCHWwjiRpnBlrkzbtligjOCVFrUMWpV")) {
        for (int rNyNzzVHGg = 1375960451; rNyNzzVHGg > 0; rNyNzzVHGg--) {
            PXJWcDZGG += llPTZUJ;
            grDvYks = grDvYks;
        }
    }

    for (int pQOCHORMfxIIRx = 1279901584; pQOCHORMfxIIRx > 0; pQOCHORMfxIIRx--) {
        grDvYks += IAMaqAMmv;
    }

    if (llPTZUJ < -1337373097) {
        for (int rZjYtTPDJs = 910795814; rZjYtTPDJs > 0; rZjYtTPDJs--) {
            SIaScW = PXJWcDZGG;
            SIaScW /= llPTZUJ;
            PXJWcDZGG -= llPTZUJ;
        }
    }

    for (int TohiWYATVlU = 1265063724; TohiWYATVlU > 0; TohiWYATVlU--) {
        continue;
    }

    for (int IOGvPUGaFvLUXVa = 654173820; IOGvPUGaFvLUXVa > 0; IOGvPUGaFvLUXVa--) {
        PXJWcDZGG += SIaScW;
        PXJWcDZGG = llPTZUJ;
        SIaScW += PXJWcDZGG;
    }

    for (int kTDHDvGBTBnLk = 859243416; kTDHDvGBTBnLk > 0; kTDHDvGBTBnLk--) {
        KdGtqemlGABUXfZE = grDvYks;
        PXJWcDZGG -= PXJWcDZGG;
        SIaScW *= llPTZUJ;
        grDvYks = IAMaqAMmv;
        grDvYks = KdGtqemlGABUXfZE;
        SIaScW /= PXJWcDZGG;
    }

    return PXJWcDZGG;
}

bool hXPWesFyxgd::xwhezzwgqdDWl()
{
    double FwNVo = 710457.6911951223;
    string XIMJc = string("UXtriXIHkOhXauAYQHUwXxBxMIOlymAIbelShvPftpZCKyQouJIZEQrYAoqeOybNlzMoWVGPNmjMjnCfsnbForeRGZfDDZtMoJMaqvtpXkRwtUqsDGGXkIxsocPxAWOCGBlgrgTPrQUseESOUGDsfhktJpTLHuh");
    string OOkJMfrGEVZQpvyO = string("WZuwGnswxuSNFCRTkGckvIQSSDxDjggEfbXtvljulvcegBHmMfXJgXWeKSCZWFDqkhoRwmSqUYtKVNGfFxkkWDlcXDLokCJx");
    double otUBzziceMtkE = 911198.5562692041;
    double ibNHbJlGJeZ = -121753.0740397558;
    int JrvqkAEEADTyAfT = -415636235;
    double NZRupGUvGCtckn = 732789.0682098529;
    bool EhTCrBUOhUny = true;
    string LbshomQTcNoY = string("TwqNNpLHDTfFRBbCdEjVmlSqulRsfVrZgWVaFzapvwOEDvjrQSchZCJ");
    int LwDrOjRztLwJiXW = 470990330;

    for (int xrqaJulwnHS = 335861519; xrqaJulwnHS > 0; xrqaJulwnHS--) {
        OOkJMfrGEVZQpvyO += LbshomQTcNoY;
    }

    for (int QcgvFVM = 1062223905; QcgvFVM > 0; QcgvFVM--) {
        XIMJc = XIMJc;
    }

    if (OOkJMfrGEVZQpvyO >= string("UXtriXIHkOhXauAYQHUwXxBxMIOlymAIbelShvPftpZCKyQouJIZEQrYAoqeOybNlzMoWVGPNmjMjnCfsnbForeRGZfDDZtMoJMaqvtpXkRwtUqsDGGXkIxsocPxAWOCGBlgrgTPrQUseESOUGDsfhktJpTLHuh")) {
        for (int mdxfSfhCNeGikEK = 799180059; mdxfSfhCNeGikEK > 0; mdxfSfhCNeGikEK--) {
            JrvqkAEEADTyAfT -= JrvqkAEEADTyAfT;
        }
    }

    return EhTCrBUOhUny;
}

bool hXPWesFyxgd::wZbYovlPQgwIbE(double GgpSS, double AHZsEoqXBIptP, string ReuWpGiKcx, int luGegtMjGRecRiD)
{
    bool IgdUYwbQlNpPRU = false;
    double HnnjFMfAzfXdEgav = -575905.3359065518;

    if (ReuWpGiKcx != string("fFsMHCHtYNdhXXhxNQjBofGZqutLrzZemIakszpqjlwigtzsWlGpPwBLwlwJjTqriVnhJpYKeomjveLkffWGpBQqIhmegdOozUnGaWJFXBDZkTLdaUoNvuHbwJVBDlBslwLmAGmbUCvPMfAufwySxIuElZTTXdvFZyIpVZOWMWhMhzywyPnNbQBIvZFAVGMJOMrwkvARfdqOUiXTVYrHQIrSMSoARIbtxkg")) {
        for (int agfzZxHrInyPopZg = 1818320839; agfzZxHrInyPopZg > 0; agfzZxHrInyPopZg--) {
            GgpSS += GgpSS;
            HnnjFMfAzfXdEgav /= HnnjFMfAzfXdEgav;
            IgdUYwbQlNpPRU = ! IgdUYwbQlNpPRU;
        }
    }

    for (int HpVncWEZtO = 1907241821; HpVncWEZtO > 0; HpVncWEZtO--) {
        AHZsEoqXBIptP = GgpSS;
        luGegtMjGRecRiD -= luGegtMjGRecRiD;
    }

    return IgdUYwbQlNpPRU;
}

void hXPWesFyxgd::UCzvnqyCYoNUv(int ptlITTrkZmgtocS, int gmIQGmtLz, bool jhBtEIUOwKS, double piRphADFd)
{
    bool hwlVyMCLCPfs = true;
    double FHlRznXLLwSMMXq = 178571.65711511188;
    string tHhteNfSzvGinsNu = string("iErSPnlyBCqHpzSRmSYjJvCNUnvcYZIBtaZQXchaIDqpgLhKizlOSiRhyDQbiYfzoNNfupZtpcLrxTUMvgJKFuqRNdzdlAwjTUcWCAqcqWjculTCRGpNvOYeheinvGcbIgDYdUodJuaSv");
    string sucbonvZamkY = string("IklNCQiHXlkFhtljRhWsWONxOPMheJRYSMVlIEwGGUuqftqyKgZUqhYJNlECbLNvolyxFhBVuqRciPxhHREhKzgpNlkFKlRJhAyvVwWwMLMnhPOPJpmrHVWTCzWPAnHzCExWgqEgfhlxS");
    double RgYXfdGoleeXKO = -429841.84193579515;

    for (int vUMssRChMvCn = 1897851776; vUMssRChMvCn > 0; vUMssRChMvCn--) {
        sucbonvZamkY += sucbonvZamkY;
    }

    for (int IKPQTERFgec = 734429339; IKPQTERFgec > 0; IKPQTERFgec--) {
        piRphADFd /= RgYXfdGoleeXKO;
    }

    for (int xPMLEps = 454378434; xPMLEps > 0; xPMLEps--) {
        continue;
    }

    for (int nUijvn = 2074262694; nUijvn > 0; nUijvn--) {
        FHlRznXLLwSMMXq = FHlRznXLLwSMMXq;
        jhBtEIUOwKS = ! jhBtEIUOwKS;
        piRphADFd -= piRphADFd;
    }

    for (int gUTatcsXYmGLiGC = 1781997460; gUTatcsXYmGLiGC > 0; gUTatcsXYmGLiGC--) {
        tHhteNfSzvGinsNu = tHhteNfSzvGinsNu;
        FHlRznXLLwSMMXq *= RgYXfdGoleeXKO;
        FHlRznXLLwSMMXq -= piRphADFd;
    }
}

string hXPWesFyxgd::oqJjfvNoV(int nBcLxcBR)
{
    double UlUkB = 47512.15431336701;

    return string("WdPkVqsKMTKcjUEgLWVjzFBXHVeOgwocDrgWelwhBWYtklMYFfozrXbWtsLhjEuKycywLyMsuaVxmuOlgldQUnCuFQLFRDqwTyLEEXDjEzzOoTtXxyQcqQTXHHiLVurTZHjrEscEvsPqJHHgwNjDfQFNOjhsOEunpRGAeoxkOygxKcUrnehwOVhlOBC");
}

int hXPWesFyxgd::jPyxOfPtr(int ALncf)
{
    string MPnlaftCmI = string("SgKZopHtgXlAvkcfrTNrgCXXHUxZCvUYzzBnyqJVWzRodWJERWkHJmZYLlRIWvIVlDqHAhwCttBJBTmocbxrguRgPkySdxsbhDlYlMYOVOJmMkUazYjCzGPIehdnfjBrWe");
    string OkHuvgIvfn = string("NNqsPiDilMdGwsJcddTIOTINGMTdPBJCcshwfDfiVmJ");
    double KUkFpBVItweKe = -702519.1007007792;

    if (MPnlaftCmI < string("SgKZopHtgXlAvkcfrTNrgCXXHUxZCvUYzzBnyqJVWzRodWJERWkHJmZYLlRIWvIVlDqHAhwCttBJBTmocbxrguRgPkySdxsbhDlYlMYOVOJmMkUazYjCzGPIehdnfjBrWe")) {
        for (int CslHJAxCB = 89940546; CslHJAxCB > 0; CslHJAxCB--) {
            OkHuvgIvfn += OkHuvgIvfn;
            OkHuvgIvfn = OkHuvgIvfn;
            KUkFpBVItweKe += KUkFpBVItweKe;
        }
    }

    return ALncf;
}

string hXPWesFyxgd::WAydzKzKWf()
{
    string ZmoJWBPmS = string("hLuuVpnkAOTeuwNAxTMbUQZgWXpWlpmsqZYNEWYPDQJdNOTQaPcMdzSYAXnQvvwXD");
    bool wbBpezhYLFL = true;
    int eZsBCKxeX = -998955393;
    bool GbEZHcd = true;
    int sMKgN = -1399453372;
    string dcgjTBtDODENjTx = string("KVSRFVUJTHAwxCNdpzzDKFNSRZLbYvyYuucFvHYaHnZQyMkMqrhnCXOtGInzIImhAuDIKuNvGQLOfQxZoisauBDoCPlTuzzsofIWScdCDDmUuQyOYagVOuFwtMtLLEcoSWmvbgjVoozmbsIjkifJKQMCgpEajRehYMPMWwCAgwtEwndyetqjpGlFuebnanwlGKHZhsrVlwlRi");
    int pjMFJM = 884203376;
    double bqgELGfVYhBqN = -989947.4027461649;

    for (int OgcFlvQeEdIy = 65107894; OgcFlvQeEdIy > 0; OgcFlvQeEdIy--) {
        GbEZHcd = GbEZHcd;
        pjMFJM += sMKgN;
        dcgjTBtDODENjTx = ZmoJWBPmS;
    }

    return dcgjTBtDODENjTx;
}

int hXPWesFyxgd::nHWwhgTn()
{
    bool tbMEbeJydWdHZy = true;
    bool IpJLcX = false;

    if (IpJLcX != false) {
        for (int TYoItTNnIHxSRVSG = 581443142; TYoItTNnIHxSRVSG > 0; TYoItTNnIHxSRVSG--) {
            IpJLcX = IpJLcX;
            IpJLcX = ! IpJLcX;
            IpJLcX = tbMEbeJydWdHZy;
            IpJLcX = tbMEbeJydWdHZy;
        }
    }

    if (IpJLcX == false) {
        for (int lOcZpZDyVnROGeW = 1417705380; lOcZpZDyVnROGeW > 0; lOcZpZDyVnROGeW--) {
            IpJLcX = ! IpJLcX;
            IpJLcX = ! tbMEbeJydWdHZy;
        }
    }

    return -1811941357;
}

hXPWesFyxgd::hXPWesFyxgd()
{
    this->HLKfHjTMeY(761046.1058716923, -841390.893519957, -2015381257);
    this->vXzgqLZ(string("qpBVoaypYUBNezsJKpwHpHBawhCJMnsVqMRf"), -1545947370);
    this->DSfzFAogBMzkzDK(207379.8283682945, 587106190, -75538.26137788223, 34752246);
    this->mOVwtd(682968.2472918235, 932800.108677611, string("aEdxkBCyhDsJDhXKUvqXKVNtwXTmjpLAUEAvRgmvZkOGjzIfidrmVPSheHTfowHwftpiMRwUxKGXzARbbHnMLWTBRU"), string("bgzJVczTwdotijnJSaomkgIYudZeOPIvMmiNHwPdJxdcodWqfdCXhxFrtWncKTbDUwQyluIkxnGvjmuzgcgVsJpWzeJUmObYjyOEZMTmUyKUqlBNwpwqCSPnTNhbjPENgKJcaArVYZGcsrlXbTebcnqUiotToRJHkYfRtqAdYGeejVpcCdQjQX"));
    this->dLDLlJ(true, string("lnKOcPezRmHMNNziqNNpHPWkcVbHRfpjFUODQsdRLSuWGPikxblObGoNfSYxTnCaotiuvDkwHgUMPNpeoyERcwNwhNqDeGqfTfBCneROLQYUAvYYPQjIyiKxEWEiZffEOIxlRUzYxFfmpvyinEiYZENiQGPqnKaiIAZndhTKZnuXJxcsmkPzbzpSbycaVDHZAgrLVwzjrMWCWlvzxMNmhmhS"));
    this->bSaICd(-739241.2790962887, -2023363377);
    this->INbeFLhixG(-438463.4812251401, 352186.2718975507);
    this->tdyjeMiWJiDlxpYC(266782.07811612997, true);
    this->MPCKZvD(true, -188913702, 116624.12067101775, string("ceczwmkqMrupyIyrlprgqxSvgprCNCNjuaceErAvSTVJmVrbhZCsXPGALymhbuVSeQcgtqDSJmUjzWTgKjurzkBXuHDyINvkkzlzDmoiZaGULuvJNDIGCXijqNubmwmNJTIWlpYXYcRByFizIsAeYNGSCUnkIORtTcxFhEdCsVgxCOyeMKYHq"), -313245.884129214);
    this->lKqQvEZrOGqTRPpp();
    this->QjTlwwMK();
    this->xwhezzwgqdDWl();
    this->wZbYovlPQgwIbE(-861666.3848465721, -497231.31028245756, string("fFsMHCHtYNdhXXhxNQjBofGZqutLrzZemIakszpqjlwigtzsWlGpPwBLwlwJjTqriVnhJpYKeomjveLkffWGpBQqIhmegdOozUnGaWJFXBDZkTLdaUoNvuHbwJVBDlBslwLmAGmbUCvPMfAufwySxIuElZTTXdvFZyIpVZOWMWhMhzywyPnNbQBIvZFAVGMJOMrwkvARfdqOUiXTVYrHQIrSMSoARIbtxkg"), -1757776042);
    this->UCzvnqyCYoNUv(1877173425, 1730328230, true, -292478.8978544309);
    this->oqJjfvNoV(-1084182139);
    this->jPyxOfPtr(-1386269385);
    this->WAydzKzKWf();
    this->nHWwhgTn();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BvoiuCWcMuvHeKUW
{
public:
    int DxzOBXUTTWgwLr;
    bool FCdImpvg;
    int SEzEnYnzw;
    bool zJPmoBc;
    int jfJGTFfCGfJ;

    BvoiuCWcMuvHeKUW();
    string OPFLgSxRmraslAi(string hQVdfoSszNWR, string AGFJKQmgzTgfJcUn, int YhDdgTekqQU, bool oTFjXTBRaIhqUJ);
    double QURSIBeqcc(string ZwtiCJmfz, string FKTZM, string iZpfImyFi);
    void TvdvEaQ(int AuJrH);
    bool SXxBg(bool JbDMfeBd, double cdnzgNJOyFfvqgcQ);
    int MqgdbLRi(int BzwTUmx, string BeFLmWv);
protected:
    string uNUcPKcuakhsNb;
    string MHDWnFMQArXr;
    int SpZmOjqDDjudG;
    int hDBJHkyCnQdFTUEs;
    string vVdRKnvBa;

    bool RNjKGA();
    string FuMtNyXTNo(double Gdnvi);
    string cPnTFieZliOU(double xkIcZuC, int fxiuTFpzdVkxbEhu, bool jvEaUmVKyAlr);
    bool MvOqKVZj();
    int HwgZTLzIA(string CaOrDVRgOyXsiohD, double rmIxBd);
private:
    double aipqkrMPcaFj;
    double rkWVotSHmqrDOyKH;
    double iELGdAN;

    void wCnwAbReaRcUZj();
};

string BvoiuCWcMuvHeKUW::OPFLgSxRmraslAi(string hQVdfoSszNWR, string AGFJKQmgzTgfJcUn, int YhDdgTekqQU, bool oTFjXTBRaIhqUJ)
{
    string fwEiCNmTiBCigJcR = string("COtqeRcnHtNySdMljdpYDOPVVGlSEqOcPfXKkBsQrwbkcYceaGSknHLBUiBgWwEruxuRXisiVKaQWxBoPBfqAfeUtPTPoDwtDaoDpEfxoBmfFiJWbaclMbGAiTFWJoLnCEQxwqSqnhDmHwMstHUUerEeLsIlGCChsnJMlrpRzpiWRhErabkUbtZOtrHoTugofRiOzXbOoWlLsBeQpwBWZFRUyrvZHugJNaT");
    double LIdMip = 291486.0647973035;
    double WVOMgc = 375571.2340125097;
    int rCNTb = -445189563;

    for (int cBhYeOKAcRU = 1393408554; cBhYeOKAcRU > 0; cBhYeOKAcRU--) {
        WVOMgc *= LIdMip;
    }

    for (int lZxDBf = 1835659158; lZxDBf > 0; lZxDBf--) {
        LIdMip += LIdMip;
    }

    for (int nXFWYCMvDVXvm = 953462854; nXFWYCMvDVXvm > 0; nXFWYCMvDVXvm--) {
        WVOMgc /= LIdMip;
        WVOMgc = LIdMip;
    }

    return fwEiCNmTiBCigJcR;
}

double BvoiuCWcMuvHeKUW::QURSIBeqcc(string ZwtiCJmfz, string FKTZM, string iZpfImyFi)
{
    string FRaDbTBO = string("yYqjTOeRFlFmMoVWvQPonjpqMDalSHdroyuPxSVoIDnQQkMOxTVlpgwWwTRkwkqRRAuQRQPNaMLVmWglsdODAVsFIJlVwnGtCXYExzPmqAYRPHPCpEAlkBQSQBXiawrdmJrxLsbkoDQYdxaPFJjCtIYzPFoMGbesoVSFzysGxdSwBHMSotfLryFFjhKxHei");
    bool zrBjgKaABMN = false;
    string vRUBlPAsQebUT = string("KpwTfGyqttgECXYWSgpaDxNazWZOQtsQSxFhMEoxhIQQViwphWtNkzSwCreXRajKZWxZJTucdWhqjQyBajjOLCMjQUbAURBnkFGu");
    bool enSUIjrxi = false;
    string wKehBK = string("SMCkkMnHGuOpqjxICfpFzgYTLUSBVgJjRAxYszikvmhPwRXpayskMiGTeBuJnyaIADbXkrxMqApsZijpLzgayzTknEzRYsFiPONbWjlqYnGNQQRzQdFvSdio");

    if (ZwtiCJmfz < string("pfdAPYlUfMFAMqoCDiFeiMRBBOcniHZqAnATIZMUFqakcsbSIfsxvMMMppXrjyOwWiMTsgNOUOqrfuHTpEbEPSQPeZFkGDtAzAwPCHkurVSPzXmBLsIpLFjHrVpcFznMgVfUJSvzBMchbgbXNT")) {
        for (int UtATUEJ = 954316921; UtATUEJ > 0; UtATUEJ--) {
            ZwtiCJmfz = FRaDbTBO;
            vRUBlPAsQebUT = ZwtiCJmfz;
            FKTZM += iZpfImyFi;
        }
    }

    if (FKTZM < string("XGVPNKrcNJXCUnhgpvSjPVnqfHXyvbCWznjaHYWjbLXRmPjnMpRuBTtyjgbrDucRefmklqkDWYxPcqdnFVjEkAixpVHzHGGPtAl")) {
        for (int DIqBzJmFYvBG = 1105000027; DIqBzJmFYvBG > 0; DIqBzJmFYvBG--) {
            FRaDbTBO += vRUBlPAsQebUT;
            iZpfImyFi = vRUBlPAsQebUT;
            vRUBlPAsQebUT = ZwtiCJmfz;
            vRUBlPAsQebUT = wKehBK;
            ZwtiCJmfz = wKehBK;
        }
    }

    for (int MYpLWFJontXaGxj = 1909052169; MYpLWFJontXaGxj > 0; MYpLWFJontXaGxj--) {
        FRaDbTBO += vRUBlPAsQebUT;
        zrBjgKaABMN = ! zrBjgKaABMN;
        wKehBK += ZwtiCJmfz;
        FRaDbTBO += vRUBlPAsQebUT;
        FRaDbTBO = FKTZM;
    }

    for (int LQxjLgCHQTUIdAO = 2038187463; LQxjLgCHQTUIdAO > 0; LQxjLgCHQTUIdAO--) {
        FRaDbTBO += vRUBlPAsQebUT;
        FKTZM = ZwtiCJmfz;
        iZpfImyFi += FRaDbTBO;
        FKTZM = vRUBlPAsQebUT;
        iZpfImyFi += vRUBlPAsQebUT;
    }

    return -802594.2951610336;
}

void BvoiuCWcMuvHeKUW::TvdvEaQ(int AuJrH)
{
    bool UrAVs = false;

    for (int BtVUXKzp = 1456457589; BtVUXKzp > 0; BtVUXKzp--) {
        continue;
    }

    if (AuJrH != -507905472) {
        for (int JsMWFbXfpTsmT = 589448900; JsMWFbXfpTsmT > 0; JsMWFbXfpTsmT--) {
            UrAVs = UrAVs;
            UrAVs = ! UrAVs;
            AuJrH *= AuJrH;
            UrAVs = UrAVs;
        }
    }

    for (int lUaNRl = 1459232380; lUaNRl > 0; lUaNRl--) {
        AuJrH -= AuJrH;
        AuJrH -= AuJrH;
        AuJrH /= AuJrH;
        AuJrH += AuJrH;
    }
}

bool BvoiuCWcMuvHeKUW::SXxBg(bool JbDMfeBd, double cdnzgNJOyFfvqgcQ)
{
    bool cDJHZ = true;
    bool uULFbjIq = false;
    string slwLPmoyMrzlbKZ = string("TCTVZsRXpVgSOuVWdUeEzjMQHulfKhPJqQdTEHLPktnyrWzwKcpWhydSDfxSRCniCjYLuLJWsgRZuIwwBVUgJYpjCKvesWbkpudXNGDNzgCUmLtPBnSIYDbuuUusAdtHcHGCgFdxmyDnNOeYVRwnyhSjYIHmbzGCbodXmjqotrMlIwMwEpQAwGjSnxIgzKWfiTmgNbevWVmIRCIBn");
    bool hSGZmFykrrRPb = false;
    double unSuTYLlMWHm = 73194.71057279408;
    double ZnuKEjoHpRnuMl = -835416.3521309543;
    int xcEDmcwDaLIWFs = 318748534;

    for (int qialPiisgKUxtg = 1497799774; qialPiisgKUxtg > 0; qialPiisgKUxtg--) {
        uULFbjIq = ! cDJHZ;
        unSuTYLlMWHm *= ZnuKEjoHpRnuMl;
        ZnuKEjoHpRnuMl = ZnuKEjoHpRnuMl;
    }

    if (hSGZmFykrrRPb == true) {
        for (int AbdHa = 1120650633; AbdHa > 0; AbdHa--) {
            hSGZmFykrrRPb = uULFbjIq;
        }
    }

    if (unSuTYLlMWHm < -835416.3521309543) {
        for (int bWBsIpsf = 1006379284; bWBsIpsf > 0; bWBsIpsf--) {
            xcEDmcwDaLIWFs /= xcEDmcwDaLIWFs;
            cDJHZ = ! uULFbjIq;
            cDJHZ = cDJHZ;
            unSuTYLlMWHm -= unSuTYLlMWHm;
            unSuTYLlMWHm += unSuTYLlMWHm;
        }
    }

    for (int vlNFzJWwFv = 370842402; vlNFzJWwFv > 0; vlNFzJWwFv--) {
        JbDMfeBd = ! cDJHZ;
        uULFbjIq = ! JbDMfeBd;
    }

    for (int LIoSsatOQFfv = 696219473; LIoSsatOQFfv > 0; LIoSsatOQFfv--) {
        continue;
    }

    return hSGZmFykrrRPb;
}

int BvoiuCWcMuvHeKUW::MqgdbLRi(int BzwTUmx, string BeFLmWv)
{
    string eOoLhPcXWSM = string("RlpfOhjnfuDSAyemdAYMVcSsEHFaaEMgYqgWEReXOMEjQCuvBYuAQsyGOwGMJKcyTRdCeQIFsLncfxAdNGzNYhxMyZrYblPyXcl");
    int BELxj = 360312598;
    int LTzsUAJa = 1164123362;
    string xwzEm = string("HnWULrcjMiMdUpoCOFyPcFASfimrsBOpUTLeRPFUvMZlWOJNIKGqQDBuegUDCgeGGgMUoYbtxdOhQjaNaBuDKMNXgCsxLIlHCwyDPvHWafYFyDzsIhrqMKtsOMUlGSvJDbOzVgJxSuhaBdaqHBvmmJuKtojgHUu");
    double BbRjZCbYqPx = 694933.8724461149;
    int cOwytnzagVSZVzuB = -1531668596;
    string kLxscyQkDgJZAKl = string("okirBeKaWoorATpNmDHFiwUWLQfwQBJaCMTnvtRQCQxVNITFKCAObTbxDCpkNLTLIWlTlwQBecZKOeGXEjkMNjlazaFBrsyBRByzmxsNrTfyGoEfYYyjUtXtTsALU");
    bool AnjyMiYZWkdre = false;

    if (LTzsUAJa < -1531668596) {
        for (int YkpQmEiJgUXhky = 1268588932; YkpQmEiJgUXhky > 0; YkpQmEiJgUXhky--) {
            LTzsUAJa += BzwTUmx;
            BeFLmWv = BeFLmWv;
        }
    }

    return cOwytnzagVSZVzuB;
}

bool BvoiuCWcMuvHeKUW::RNjKGA()
{
    string zxGJdybfHuYj = string("fFODPchpgDwbpSgpFewMKawPqkSruYgKwEsJCDSlekQRVzUifpfMQiaESjlveVk");
    string eYpsrqiTEGrZkcy = string("GyARhsQdfxwPYzSiIydiqWYtUFTFNbctYrgVnejgvGsVDXhEukPuofTnJbpxnm");

    if (zxGJdybfHuYj > string("GyARhsQdfxwPYzSiIydiqWYtUFTFNbctYrgVnejgvGsVDXhEukPuofTnJbpxnm")) {
        for (int yVtsrgmCDXgRim = 1090922162; yVtsrgmCDXgRim > 0; yVtsrgmCDXgRim--) {
            eYpsrqiTEGrZkcy += eYpsrqiTEGrZkcy;
            eYpsrqiTEGrZkcy = zxGJdybfHuYj;
            eYpsrqiTEGrZkcy = zxGJdybfHuYj;
        }
    }

    return false;
}

string BvoiuCWcMuvHeKUW::FuMtNyXTNo(double Gdnvi)
{
    double bDEIu = -357002.83333354397;
    int uUstMVpxEEHVnxh = -861680137;
    string NAMVMzvpE = string("XNalxyHgiKfCHFgAYDnTfojDFwboczQLTQ");
    string JQWvtprR = string("zfzoicVqMicnIXVTeJVIrpUgUpvclAvZRqolMPiMFUOgJiYVkxupDwWL");
    int uXvYasl = -1713494671;
    double bKAwBreHNqNcIFB = -286892.7816679918;
    string CwGDujaHLX = string("QCqAoKyivyPfCYYlfkqAQgxqGoSbZpZWZTwVlLtNwTmuZvUtgTwYZYpckxSFMjREdrWqxppjXOoxilslbkxyBYKkGJlGusIljthfYPhKJdwKwYtkGkTGioUKlJretrxbqZZZVGphzgmTnFAdIlXVmaMGVWepdQNjlMkuVAMXGoDEwtzCGZDhcEvEEGgDJhuijwwuoEvzOwktCRnCRRIqmWLUPDeFtQjGRzWRHxOoCkZBFJKZJd");
    double asFcDny = 303776.12250876246;
    bool nXlnkBPssB = false;

    for (int EBPlGGM = 1661209441; EBPlGGM > 0; EBPlGGM--) {
        CwGDujaHLX += NAMVMzvpE;
    }

    for (int NjNYTru = 878939080; NjNYTru > 0; NjNYTru--) {
        continue;
    }

    for (int RMirnHnIIbLTs = 1703114763; RMirnHnIIbLTs > 0; RMirnHnIIbLTs--) {
        Gdnvi *= asFcDny;
        Gdnvi /= bKAwBreHNqNcIFB;
        CwGDujaHLX += CwGDujaHLX;
    }

    for (int jMXmqmJQBix = 530010099; jMXmqmJQBix > 0; jMXmqmJQBix--) {
        nXlnkBPssB = nXlnkBPssB;
    }

    for (int YNzjYN = 1603459570; YNzjYN > 0; YNzjYN--) {
        continue;
    }

    return CwGDujaHLX;
}

string BvoiuCWcMuvHeKUW::cPnTFieZliOU(double xkIcZuC, int fxiuTFpzdVkxbEhu, bool jvEaUmVKyAlr)
{
    int deDPfiOQajjw = -881028764;
    bool quLUOvfI = true;
    string kbYieCbrP = string("xOhhpeevgxEBIklKFLqVdNlInsFIbrQoZYmiJ");
    int GfCZyTotDLaBpNTR = -864599155;
    bool rPCkTNRqUYEUz = true;
    int NDQCkpShWQKv = -934396235;
    double dstnAGCBEorpk = -122076.20135296583;

    if (jvEaUmVKyAlr != true) {
        for (int IRdvpjjjnOpDRX = 937300236; IRdvpjjjnOpDRX > 0; IRdvpjjjnOpDRX--) {
            fxiuTFpzdVkxbEhu /= deDPfiOQajjw;
        }
    }

    for (int PjvNsSWtsGyQN = 1817728931; PjvNsSWtsGyQN > 0; PjvNsSWtsGyQN--) {
        quLUOvfI = ! rPCkTNRqUYEUz;
        rPCkTNRqUYEUz = ! quLUOvfI;
        kbYieCbrP += kbYieCbrP;
    }

    for (int LMpRaH = 1922555954; LMpRaH > 0; LMpRaH--) {
        GfCZyTotDLaBpNTR += fxiuTFpzdVkxbEhu;
        rPCkTNRqUYEUz = jvEaUmVKyAlr;
    }

    return kbYieCbrP;
}

bool BvoiuCWcMuvHeKUW::MvOqKVZj()
{
    string pFDDXUwespebxxIv = string("EFSxkPcmzHQguhQplWPebSgnTyUaBLOyaafgpMhzDGuMHjNjDMCwtqvGglKNagsrgDAcxOpkVibHyMEATxxIrwbbntMKaWpBRZZoPusUwsDtCybwbJXdweUgUqgWGHNDzoiHiHaLxTqAqudrxAGhRo");
    int xxZolbFw = -303827792;
    bool KFyyxUBpLgYprPG = true;
    string YgPeBem = string("lBF");
    double WEPXkOzyuTykvc = 471609.5704352046;
    bool kmoTXmH = false;
    string uZKKbtCmaqLEoKm = string("LiqoWIHlqxcRJmvUprNifCKphOGAYFYhOiyIdwlEEWhyzADfTgwlBsdcPnHNVngPtqfFzUhdzReydPCPv");

    if (xxZolbFw == -303827792) {
        for (int yHZybq = 1985043777; yHZybq > 0; yHZybq--) {
            pFDDXUwespebxxIv = YgPeBem;
        }
    }

    if (uZKKbtCmaqLEoKm >= string("LiqoWIHlqxcRJmvUprNifCKphOGAYFYhOiyIdwlEEWhyzADfTgwlBsdcPnHNVngPtqfFzUhdzReydPCPv")) {
        for (int Xjcvg = 1487352861; Xjcvg > 0; Xjcvg--) {
            xxZolbFw -= xxZolbFw;
            YgPeBem = YgPeBem;
            uZKKbtCmaqLEoKm = uZKKbtCmaqLEoKm;
        }
    }

    if (uZKKbtCmaqLEoKm <= string("lBF")) {
        for (int QTCTcYPLxIU = 2048245320; QTCTcYPLxIU > 0; QTCTcYPLxIU--) {
            YgPeBem = YgPeBem;
            KFyyxUBpLgYprPG = ! kmoTXmH;
        }
    }

    for (int ofuxrMBI = 1355246879; ofuxrMBI > 0; ofuxrMBI--) {
        pFDDXUwespebxxIv += pFDDXUwespebxxIv;
        pFDDXUwespebxxIv += pFDDXUwespebxxIv;
        xxZolbFw *= xxZolbFw;
        xxZolbFw /= xxZolbFw;
    }

    for (int SINDxVLOi = 612683036; SINDxVLOi > 0; SINDxVLOi--) {
        continue;
    }

    if (kmoTXmH == false) {
        for (int yzOvrlvLvGQvPGox = 1253667325; yzOvrlvLvGQvPGox > 0; yzOvrlvLvGQvPGox--) {
            continue;
        }
    }

    if (YgPeBem >= string("EFSxkPcmzHQguhQplWPebSgnTyUaBLOyaafgpMhzDGuMHjNjDMCwtqvGglKNagsrgDAcxOpkVibHyMEATxxIrwbbntMKaWpBRZZoPusUwsDtCybwbJXdweUgUqgWGHNDzoiHiHaLxTqAqudrxAGhRo")) {
        for (int PQHZXAcGBU = 142609514; PQHZXAcGBU > 0; PQHZXAcGBU--) {
            continue;
        }
    }

    for (int fStDErnc = 995427537; fStDErnc > 0; fStDErnc--) {
        continue;
    }

    return kmoTXmH;
}

int BvoiuCWcMuvHeKUW::HwgZTLzIA(string CaOrDVRgOyXsiohD, double rmIxBd)
{
    double dNolhzTgNAV = 512000.77432852215;
    string AwuFeoxYbJK = string("opHLWMWfGeayUyclIijLXlVVPMQYcIXPYomGgmJVfpfGEVGWRLSTzruQJtlvegwxyQeTbRlnJteaCjxpyjLdyPdsMYAaPjrKXaGHGruFZKmIxUrqmgcyyCxxirHOAKXSOQbuoAefuDabMhkRMZZtHXlCpMjrPviVAnNMuqcVFAPEWWQTjJQlNznEWlkxXVvfmEjwmDwtPGasJoyFDTaHcjV");
    double McDcwlR = 667693.9033475037;
    string MLoYq = string("HXnEcFqVBKAMzdFSqyvSGrUyHJVecRXQyhNbxTDXGPjnWMRaYJMcbQFAUkjSVEDypDIuoAqcrESCZNtKeYnmRUhdVMXnKNiAWYhGFplLTwtqWorBDFfmpoKzzLeZzRhguSrxlCUYhDghOQcoJwhxltcHw");

    for (int iRCtrOjP = 96300052; iRCtrOjP > 0; iRCtrOjP--) {
        rmIxBd = rmIxBd;
        dNolhzTgNAV *= dNolhzTgNAV;
        CaOrDVRgOyXsiohD += CaOrDVRgOyXsiohD;
    }

    for (int KeBZhJITUMzDP = 397334310; KeBZhJITUMzDP > 0; KeBZhJITUMzDP--) {
        dNolhzTgNAV += rmIxBd;
        MLoYq += MLoYq;
    }

    for (int DhyREEdkrp = 751785869; DhyREEdkrp > 0; DhyREEdkrp--) {
        rmIxBd *= dNolhzTgNAV;
        dNolhzTgNAV += dNolhzTgNAV;
        McDcwlR = McDcwlR;
        AwuFeoxYbJK += MLoYq;
    }

    return 1279207340;
}

void BvoiuCWcMuvHeKUW::wCnwAbReaRcUZj()
{
    int BqHMnfAqByWX = -852065894;

    if (BqHMnfAqByWX != -852065894) {
        for (int giCOLGvN = 1087363429; giCOLGvN > 0; giCOLGvN--) {
            BqHMnfAqByWX *= BqHMnfAqByWX;
            BqHMnfAqByWX /= BqHMnfAqByWX;
            BqHMnfAqByWX -= BqHMnfAqByWX;
        }
    }
}

BvoiuCWcMuvHeKUW::BvoiuCWcMuvHeKUW()
{
    this->OPFLgSxRmraslAi(string("UFsxTRaRfHUGwXikPTVBSgUFbDINXxGmRUjzmRmVciRFtugrMFzfdiuqNLQBuUhJrgIpvYPlaJGAfQgwPTMKhvHHMHUsdFSsXjjgCWCMbLIOUGcGcbDbckHIqzFNeMVKYjHjTsZmRqAVLMMNezUIhuTXYsuYqayiUzltSXOAAhZUHqaBJNjOuSXshvHtJyNhUAAmsjdtvthrWZsRMhMUGKkJqQiEQEgkZhoHePFvdhC"), string("sBFaHahpyZoBDNHmeAOhcTBZkiuUtitKvlRusRlQYPDQNmJJlNTCESugFWkridanqSeWdGzwDmXwnlcGJFXmqzFQRffmchoGpTGVPyWeFrVIXTeOREIMMzjvPYuclRCaLphwsRZtSNFwhKLzZQWUWCdYqTTHBXInLqPaJvDVoxEFVRcbjxkbjRqxfxYKLwVVbzRkUQPCTrEgLnrBsWEaMcnPmyQbWKmDzesaByomBgLemlFVBndfiVH"), 1258211139, false);
    this->QURSIBeqcc(string("XGVPNKrcNJXCUnhgpvSjPVnqfHXyvbCWznjaHYWjbLXRmPjnMpRuBTtyjgbrDucRefmklqkDWYxPcqdnFVjEkAixpVHzHGGPtAl"), string("pfdAPYlUfMFAMqoCDiFeiMRBBOcniHZqAnATIZMUFqakcsbSIfsxvMMMppXrjyOwWiMTsgNOUOqrfuHTpEbEPSQPeZFkGDtAzAwPCHkurVSPzXmBLsIpLFjHrVpcFznMgVfUJSvzBMchbgbXNT"), string("KdSgFgbIzTbkFfJTzuoGLDAVqTlXudexzxaUPzZqVAmALTeJahpNJUZEuDjoMZnexXAHUPuQO"));
    this->TvdvEaQ(-507905472);
    this->SXxBg(true, 316807.5264473579);
    this->MqgdbLRi(1677497694, string("YHcqAULYZaNcNGmmwvdnFhDWJQjDvuPTiJbcxbXHqHsbANwkyjXufXIgWgIOQfxyihWpKPUxQSEzzhgDnUkDLuLpTlYwmf"));
    this->RNjKGA();
    this->FuMtNyXTNo(433456.28227138735);
    this->cPnTFieZliOU(668628.0941302092, 1005221514, true);
    this->MvOqKVZj();
    this->HwgZTLzIA(string("OftCHcoGAjrlzjuIMOBgCVmvczbwEHXIXAwOJprZFBIXgzdTmOUbYUvcfZUyPSrXLNCgdezzFAaInZagtxVwJFnfbGZEfutlJGkwJqwsfVAYwEVrjcdBJseffahuPdkaQpCAwYhvJsgWukWUQJOjOWapZhNcarZpWzviAHGvpruntbyKxxBqmQGXIzFbqzqMhbNIDNG"), 852127.0774133281);
    this->wCnwAbReaRcUZj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PgmFNfnZUdgIP
{
public:
    string QZCnifxB;
    int xcfnWLcOMsR;
    double FkNcWKlqKf;
    int AVhIPa;
    double mjPsTicWtgNz;

    PgmFNfnZUdgIP();
protected:
    string CEOZhEKTVh;
    int hIWUawtoGYxXsuxw;

    double zbjhXTdlyg(double SfqNsbYzcXmwUUS, double mSRnXmlootNh, bool bURTbFVdcNUcX);
    void yuIrBpkElQM(string irXWUPmQU);
    void LPLFutlCWvgHz(double DqxHKjbbBFp, string XfqmX, string IHIEBCDC);
    int fvAPR(int xRPayYGxdqxvu, string wHRUhqFgoEEeKxps, double bbSxoFYFTojiX, int mgnsZwnqCVi);
    bool tPKxbIPWGSLKV(string tnhrvLNofBA, int OFgwdChNUcI, string EurdOCasajsAmUm, double dybBZkW);
    bool VkjjnVt(int fBSYIuUa, string QZxeeqzBc, int nnlLbCRFsDNLNkTv);
    void hIVqoQNbSmZfnWV();
    int YcdFRzdo();
private:
    int vgwRiMFEyWsdS;

    void desvOjDQd(string rWkzmG, bool ucBzOyYK, bool NOvJqd, string cDlpfhOpayBccmXc, double YRASdnww);
    void dWLesCUgujfmmt(string EigbgkX);
};

double PgmFNfnZUdgIP::zbjhXTdlyg(double SfqNsbYzcXmwUUS, double mSRnXmlootNh, bool bURTbFVdcNUcX)
{
    double gHgmyqNkJdNkCmPx = 653330.026152153;
    double VIMyBjdCHGTLJ = -249808.20996514903;
    double iHAJUfkCdho = 74172.20409627301;
    string KnXAvEBLpqdFRyjL = string("EEVwRvIEHRePY");
    int radaAHCpNGH = 1108933038;
    string LujLiNqSNcUFHi = string("wQJtmbLrkQXYVvZGKQajDdYwkKGxoBnUefpKMlwiGThRKfQxticRPTJeQGWnXhTJRjjYczpknEiKpoXmGUgplnTLKfTdHrGMKMTgMZUGYDhkIgtqQKXUyAcSGdRuIxGdmSYXotiXMZIYdjyMkgATipFsGaNJMCBqAXWxZuMitybyCGYkUYFWUxcHXwKPgCNxrWBgpCiSLqtgWbLgEm");
    bool xPAJDB = true;
    int ejWdJvbAUg = -241400435;
    double voKsAboDEOuwPEb = 261807.69834339645;

    for (int qsUUfcTL = 1930872083; qsUUfcTL > 0; qsUUfcTL--) {
        mSRnXmlootNh += mSRnXmlootNh;
        SfqNsbYzcXmwUUS *= SfqNsbYzcXmwUUS;
    }

    for (int bSUCwMpRub = 6287886; bSUCwMpRub > 0; bSUCwMpRub--) {
        continue;
    }

    for (int PGfPMyoThtpTjf = 1072232320; PGfPMyoThtpTjf > 0; PGfPMyoThtpTjf--) {
        SfqNsbYzcXmwUUS -= iHAJUfkCdho;
    }

    return voKsAboDEOuwPEb;
}

void PgmFNfnZUdgIP::yuIrBpkElQM(string irXWUPmQU)
{
    int hmPhPpEh = 575010825;
    double ZdjogZCQOeT = 876128.2737687144;

    if (hmPhPpEh != 575010825) {
        for (int jkMwyDiYqD = 785232296; jkMwyDiYqD > 0; jkMwyDiYqD--) {
            continue;
        }
    }

    for (int PpvQBhWFUxgL = 656075613; PpvQBhWFUxgL > 0; PpvQBhWFUxgL--) {
        irXWUPmQU = irXWUPmQU;
    }

    for (int gMQtNrNrcysOgI = 837404413; gMQtNrNrcysOgI > 0; gMQtNrNrcysOgI--) {
        irXWUPmQU = irXWUPmQU;
        ZdjogZCQOeT *= ZdjogZCQOeT;
        ZdjogZCQOeT += ZdjogZCQOeT;
    }

    for (int xGNiVyta = 1733143785; xGNiVyta > 0; xGNiVyta--) {
        ZdjogZCQOeT += ZdjogZCQOeT;
        ZdjogZCQOeT *= ZdjogZCQOeT;
    }
}

void PgmFNfnZUdgIP::LPLFutlCWvgHz(double DqxHKjbbBFp, string XfqmX, string IHIEBCDC)
{
    double WLcYkniYdBn = -159193.52273032846;
    int JKOmZL = -816783667;
    int IicbBEJIOlLvQpvU = 383630452;
    string JirqBQljBO = string("hnVMunpvBhPYDCYYafumhTRwvBlfSqCvMAQKpegJtkVjEKtvEVtjokUlLJyCqNhGbIIABAQIaPQcGySeijruIoKQElwiHcWRseHbKluTQNJsahHjJdAHoHWcKzdmmueBBlXRLEBiPvYlQEopaSg");
    string sStxBz = string("kYgFpJlajOnQciXgkgFXRzMGlbNFjuAdhfYIlJwCRsZMQlYRjhJtSgARQlHMzEylSeEtkeDwXHCVEvyWGPAhOTvpDNkyqPoWeDnyadISPgMgPYFZhvPQyrJDqOfMbVqZskxHiLhKGhoOCsylvaDvyCyjCxIPgJJDDCSkxLSOoBdtwvLbQdfBLPWfdXXDTqmZKsUiJPZzJOuPDHMtcGhJBtLQFBxHoTsOHTKokQUugLMWuhmDvOTmXxcfNmUhY");
    double oHpVGBaHGld = 678292.3194570938;
    double AVxiFZtKi = -757344.6538231765;
    string swiiRd = string("rrtXrJrlAGaXbcVclMACNnPOeOsrQhbdvLMyyHpZmAguBLTzKfiQyatCBDTjtpKebRJHoPNMucoJvBBpvGOOtTsUBnpwlPRQvEghoKkPfMdmHPAeFmVGCYAPrWxEPlhKCedoJDSVDuFBwINPleaUeuvlfHUewaZYoWrLCZ");
    int lhwNah = -1754391973;

    for (int arCoOxH = 774836389; arCoOxH > 0; arCoOxH--) {
        sStxBz = IHIEBCDC;
        WLcYkniYdBn *= AVxiFZtKi;
        DqxHKjbbBFp = DqxHKjbbBFp;
    }

    for (int WTMObYRWH = 2069468514; WTMObYRWH > 0; WTMObYRWH--) {
        AVxiFZtKi = AVxiFZtKi;
    }
}

int PgmFNfnZUdgIP::fvAPR(int xRPayYGxdqxvu, string wHRUhqFgoEEeKxps, double bbSxoFYFTojiX, int mgnsZwnqCVi)
{
    double HgOgxaYPoAHbVtM = 891679.0845641401;
    double WChzfBFDeitbOLhf = 153100.52690094404;
    double yEgySUsuaEG = -588928.5583550166;
    double PwtUvPTFyIrCT = 562608.781051135;
    double mmprOD = 974451.4024384515;
    double EyflZXpDOPJ = 54907.13512715276;

    if (yEgySUsuaEG > 54907.13512715276) {
        for (int XcytbUaPjCqLn = 2062587783; XcytbUaPjCqLn > 0; XcytbUaPjCqLn--) {
            mgnsZwnqCVi *= xRPayYGxdqxvu;
            xRPayYGxdqxvu = mgnsZwnqCVi;
            PwtUvPTFyIrCT -= PwtUvPTFyIrCT;
        }
    }

    if (HgOgxaYPoAHbVtM >= 891679.0845641401) {
        for (int bSjqtT = 510841115; bSjqtT > 0; bSjqtT--) {
            continue;
        }
    }

    for (int cneswJkHKoU = 1277207772; cneswJkHKoU > 0; cneswJkHKoU--) {
        PwtUvPTFyIrCT *= bbSxoFYFTojiX;
        PwtUvPTFyIrCT -= HgOgxaYPoAHbVtM;
    }

    return mgnsZwnqCVi;
}

bool PgmFNfnZUdgIP::tPKxbIPWGSLKV(string tnhrvLNofBA, int OFgwdChNUcI, string EurdOCasajsAmUm, double dybBZkW)
{
    int zLrZs = -33588292;
    double smboUOmgvGmsHNGv = 117729.77859959306;
    int qsTPy = -709012637;

    for (int xyIbYHbi = 613323916; xyIbYHbi > 0; xyIbYHbi--) {
        continue;
    }

    return false;
}

bool PgmFNfnZUdgIP::VkjjnVt(int fBSYIuUa, string QZxeeqzBc, int nnlLbCRFsDNLNkTv)
{
    string DWMGyRgAStwpzXqz = string("VIBjzzKJGjYYgSuhLPjWlXJEhQNaTCgJpHLuIxBhLumMBByKxbgoqmeGcklZRVlFlaJouNsTwqdQybKrggLfXPhuNVpaAtcIHOLNNvuQhMvuIhWcokkExQjJsQjWyzXEnilevVfRHoWuwMsSqSuvyotlkeUSYVIuNwZFgbnjkrpedzYuihzIThOPpOxglVVuOIdwmVRwAvUxenq");
    double oSuHTqCoDfz = -833984.9457824723;
    int jxoXZ = 1414731145;
    string UdMIHmCB = string("rudcbGdyrGWwIsQgIchZIZalwrwliARcUVFYEGNNWRlnLtZEjqdhKZKXpUekuBwuIzdFFwrjDgNwmDEPeanYVgCCkaUPzyqdVZFhcXFcAEClGpJfgrzmvfodZJ");
    double VxchPEaGxSkyx = -646635.0892714188;
    double mUMPVJhqe = 596548.6351209927;
    int FFHXemGCfZe = -399278481;
    int MJANrnxp = -808170060;

    for (int WmFWIvICa = 164287955; WmFWIvICa > 0; WmFWIvICa--) {
        continue;
    }

    for (int dlDvrqkIA = 1111276096; dlDvrqkIA > 0; dlDvrqkIA--) {
        MJANrnxp = FFHXemGCfZe;
    }

    if (QZxeeqzBc == string("rudcbGdyrGWwIsQgIchZIZalwrwliARcUVFYEGNNWRlnLtZEjqdhKZKXpUekuBwuIzdFFwrjDgNwmDEPeanYVgCCkaUPzyqdVZFhcXFcAEClGpJfgrzmvfodZJ")) {
        for (int vKCZrQnRGSXB = 1599137222; vKCZrQnRGSXB > 0; vKCZrQnRGSXB--) {
            jxoXZ *= nnlLbCRFsDNLNkTv;
        }
    }

    if (UdMIHmCB <= string("rudcbGdyrGWwIsQgIchZIZalwrwliARcUVFYEGNNWRlnLtZEjqdhKZKXpUekuBwuIzdFFwrjDgNwmDEPeanYVgCCkaUPzyqdVZFhcXFcAEClGpJfgrzmvfodZJ")) {
        for (int CzvTwEdK = 1679617386; CzvTwEdK > 0; CzvTwEdK--) {
            nnlLbCRFsDNLNkTv -= nnlLbCRFsDNLNkTv;
        }
    }

    return false;
}

void PgmFNfnZUdgIP::hIVqoQNbSmZfnWV()
{
    string WyLwaifBpYnHhLN = string("CKPNKdgUUZlFlVTlYIpICChvYfkSHQVPlASCqdKSQcqrCQWMtAkbJtOXKZvikELmLfZXpZybRxenzPyqbgEHEMRJcWjmtcPDqwWIRnRqLIur");

    if (WyLwaifBpYnHhLN >= string("CKPNKdgUUZlFlVTlYIpICChvYfkSHQVPlASCqdKSQcqrCQWMtAkbJtOXKZvikELmLfZXpZybRxenzPyqbgEHEMRJcWjmtcPDqwWIRnRqLIur")) {
        for (int LcjDPFimdxCryG = 1751881227; LcjDPFimdxCryG > 0; LcjDPFimdxCryG--) {
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
        }
    }

    if (WyLwaifBpYnHhLN >= string("CKPNKdgUUZlFlVTlYIpICChvYfkSHQVPlASCqdKSQcqrCQWMtAkbJtOXKZvikELmLfZXpZybRxenzPyqbgEHEMRJcWjmtcPDqwWIRnRqLIur")) {
        for (int npArFBzXaPdkxIw = 478835965; npArFBzXaPdkxIw > 0; npArFBzXaPdkxIw--) {
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
        }
    }

    if (WyLwaifBpYnHhLN > string("CKPNKdgUUZlFlVTlYIpICChvYfkSHQVPlASCqdKSQcqrCQWMtAkbJtOXKZvikELmLfZXpZybRxenzPyqbgEHEMRJcWjmtcPDqwWIRnRqLIur")) {
        for (int hchDQQUJWlHhEs = 2010372465; hchDQQUJWlHhEs > 0; hchDQQUJWlHhEs--) {
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN += WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
            WyLwaifBpYnHhLN = WyLwaifBpYnHhLN;
        }
    }
}

int PgmFNfnZUdgIP::YcdFRzdo()
{
    bool MWEYwevMIcGx = false;
    bool hoAGLchC = false;
    bool iLLIP = true;
    string ocrVV = string("RWKPpNNJVdvDYNpQzPVNIxNaijHcmpPFOybxSoyYKcsvisevNXQJFtQkwpLUQnlZBRuntIjaWrEOqwRVLvkxduhNGRdMXDpwwbxGIaLYCcJPYQNbWxlXojfldDigSJjcpsQPRmOrToQgCtMLStFnyUxPumoHnZoyxlwFyTQsQeoXJn");
    bool qwJARpCzVmdIXrdg = false;
    bool VEFfRKNCoMYjU = false;
    double EIqoXKsLJPTHpAP = 506872.08993634017;

    if (VEFfRKNCoMYjU != false) {
        for (int qyBATcMracox = 109624654; qyBATcMracox > 0; qyBATcMracox--) {
            VEFfRKNCoMYjU = ! MWEYwevMIcGx;
            iLLIP = ! hoAGLchC;
            MWEYwevMIcGx = VEFfRKNCoMYjU;
            MWEYwevMIcGx = ! hoAGLchC;
        }
    }

    if (VEFfRKNCoMYjU != false) {
        for (int xbmLuS = 170755320; xbmLuS > 0; xbmLuS--) {
            qwJARpCzVmdIXrdg = ! qwJARpCzVmdIXrdg;
            hoAGLchC = ! qwJARpCzVmdIXrdg;
            VEFfRKNCoMYjU = ! hoAGLchC;
            hoAGLchC = ! qwJARpCzVmdIXrdg;
            ocrVV = ocrVV;
            qwJARpCzVmdIXrdg = ! iLLIP;
            qwJARpCzVmdIXrdg = ! iLLIP;
        }
    }

    for (int DQKjHRlHyAGsIHes = 230113877; DQKjHRlHyAGsIHes > 0; DQKjHRlHyAGsIHes--) {
        continue;
    }

    for (int umjSysFoxglPFi = 97739507; umjSysFoxglPFi > 0; umjSysFoxglPFi--) {
        iLLIP = iLLIP;
        MWEYwevMIcGx = ! qwJARpCzVmdIXrdg;
        EIqoXKsLJPTHpAP = EIqoXKsLJPTHpAP;
        iLLIP = ! hoAGLchC;
    }

    if (VEFfRKNCoMYjU != false) {
        for (int CHkprP = 709759926; CHkprP > 0; CHkprP--) {
            iLLIP = hoAGLchC;
        }
    }

    return -850189362;
}

void PgmFNfnZUdgIP::desvOjDQd(string rWkzmG, bool ucBzOyYK, bool NOvJqd, string cDlpfhOpayBccmXc, double YRASdnww)
{
    double oVlbOzgWxqreOEX = 907570.8738965715;
    string KnVmzIvc = string("cRHQUuIlNvZdYCQlBxgidTyRupwjSEonCeIUnRsPezJiUslmDgUNzNmTjnDP");

    if (oVlbOzgWxqreOEX > 630261.6294674055) {
        for (int tLuxJHrhcBqrPkw = 736278715; tLuxJHrhcBqrPkw > 0; tLuxJHrhcBqrPkw--) {
            ucBzOyYK = ucBzOyYK;
        }
    }

    for (int mlpeasqlCBxlzI = 1547936609; mlpeasqlCBxlzI > 0; mlpeasqlCBxlzI--) {
        ucBzOyYK = NOvJqd;
        oVlbOzgWxqreOEX -= YRASdnww;
        KnVmzIvc = cDlpfhOpayBccmXc;
        cDlpfhOpayBccmXc += KnVmzIvc;
    }

    for (int NHzevlnPpPgY = 1272983825; NHzevlnPpPgY > 0; NHzevlnPpPgY--) {
        ucBzOyYK = ucBzOyYK;
        cDlpfhOpayBccmXc = cDlpfhOpayBccmXc;
    }
}

void PgmFNfnZUdgIP::dWLesCUgujfmmt(string EigbgkX)
{
    int HLLKrfhuT = -1708720396;
    string UTpnwDMCHDcDCQQL = string("kKNEVETGFseMartOVVkNunkbjEEoxuoUGJeNUBGFCEewDRxYitIhplbwG");
    int SyUjbEhWCnkI = -1443065308;
    bool UiifVTMvFOdWHURg = true;
    string jqfjdC = string("VXTaiYugZtnsbofiwxANCIGOPomjUNaadanvOUyBAIGWBUKgFeBgupLbprLVRRVPHjpmJDrTPzBFunyLGCVhCJgsVAMllhIvOJkWVpDmcsODxwhVEBQHIzGJmecJCwcqLKOWfztXFRSutZWngouGosAzZlKVz");

    for (int DqrgKYhXv = 1282982304; DqrgKYhXv > 0; DqrgKYhXv--) {
        HLLKrfhuT *= HLLKrfhuT;
    }

    if (SyUjbEhWCnkI < -1708720396) {
        for (int BJYWDjcifKhp = 1145486907; BJYWDjcifKhp > 0; BJYWDjcifKhp--) {
            continue;
        }
    }

    if (UTpnwDMCHDcDCQQL < string("VXTaiYugZtnsbofiwxANCIGOPomjUNaadanvOUyBAIGWBUKgFeBgupLbprLVRRVPHjpmJDrTPzBFunyLGCVhCJgsVAMllhIvOJkWVpDmcsODxwhVEBQHIzGJmecJCwcqLKOWfztXFRSutZWngouGosAzZlKVz")) {
        for (int TthLo = 1237129348; TthLo > 0; TthLo--) {
            EigbgkX += EigbgkX;
        }
    }

    for (int HHrwlTJV = 946159698; HHrwlTJV > 0; HHrwlTJV--) {
        SyUjbEhWCnkI -= SyUjbEhWCnkI;
    }
}

PgmFNfnZUdgIP::PgmFNfnZUdgIP()
{
    this->zbjhXTdlyg(514809.1908155359, 1032884.651651709, false);
    this->yuIrBpkElQM(string("ErivmNcQhQzwHUwVHyyCXXIfqaiECOiTsSruQlVKSllajsXgHkcIMqfXxxksLhKlkt"));
    this->LPLFutlCWvgHz(-861234.4177972658, string("VYxMfzoLkxX"), string("cFWPWEtsmvzkefUqpBXKcusgtIeHjLftFEDaYgTcRtwxAHdJGQudzVjBMYAlwssCLQwbSSIHoAIVCnkcBALSNvFIQFWZuHyvVNJHNpGkDhzoCYIFqVLHWxWqgqnwlZEu"));
    this->fvAPR(-2038255304, string("xozZOzECqnKSiGaInjZEGMVcBhlRbsxXkdDKRVYKKmmysNUHXTRQHE"), 8144.962679064897, 1449617223);
    this->tPKxbIPWGSLKV(string("NZPZmgkaaVjEvushXhLbXmYWPtTCujaaZPxcdYWpIUHNZvOWJjBZsacTECyAWduEizYmQGCsyfkVIcbcedBxFbKfCdNpHPdtJUTxhyJiOYCudLaSWofimVrieVcKVyIGadvJXBFaHhuIsHUNRjyGBzWjkMPurSxpz"), -1201212193, string("FWFtuCstrodqNtLLbwIiXDLJpDZvfKePcdqgevOzwJNwvvSPzIDSfQfzxLKjpmooFnHMasgOyomTiybkiKPSHnrJxuwncrYzDGkyCHRanEgfPtNGQwJJOSJFdjr"), 7750.440107101171);
    this->VkjjnVt(-1330404159, string("GeydYkmfhkhZOgINhFOQJYvfNUYTZyocFNNEKttkdJMoHWXYtNunsBWTEdmwAjhYUgiwDauXMDFTwWFaZxp"), 1964769606);
    this->hIVqoQNbSmZfnWV();
    this->YcdFRzdo();
    this->desvOjDQd(string("jfIUQGxYmyrYlutwAaPMNcOIbYmmHaBXEfGlEjR"), true, false, string("vgrycJnowZaGnhOxssuYdrjwVobLdWzwODTmnXgushDqtYGJUzcfJjTU"), 630261.6294674055);
    this->dWLesCUgujfmmt(string("tmsDhZUoBNbiHmwAdKNpuXKQTNYYqyxJxgaDJuGGNhescsLCYPnEPMKvGoVFRpSAzTWoEGtJcKknKIDzaHgkmoKFhSvpwgNlkqqdwYQQhNlSEZrVFFbsgJtDwKFUDrRAfkhaBZNjfcDcwHskTxUbbBoVmvYdeShBYlsyKgMdWSmPPeHLLEJmnzODmRmMNKkEkW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class itgWVuObh
{
public:
    bool ImfIwqD;
    int JcscIyIRRSqdmPSi;
    double iQgUI;
    int EWFDIFgLKOgz;
    double PaVIEMJxiUwxqVti;

    itgWVuObh();
    bool fvfemfoQZaotCsj(int LDtLOkyArfhv, double MOIxbpxNdxtrW, int PvxftGHhyiLDW, bool aIcLNqYoiGluj, int RBbCSJtUSQtHVDl);
    void DxtbfrjcLMZ(double WadHqLHpWIzIYYPI, string CXQqanuXcQSdrH, double PBIsHlNrKrM);
    int ofqCVKZJuIVbadI(string aUcgx, string FXGuF, string CbFixB, int CZhqREv);
    double hldxwcilrRUvh(int aJClfvEhgnZvxtie, string ekVoxvrksGoFLmJ, bool hKHknzBeZPTDbHX);
protected:
    bool NNjsKc;
    string hohMsI;

    void uCxzGRxfYVy(double CztKwvGeU, int RlviBuLcWPSBRBgf, bool iAZPpmA);
    bool vsqIZpFsDBI(string iYZaPHAOHRQ, int QayWMjnBmzhL, bool WSiJLljfY, int sRzmTcAR, int KkLSVzqJ);
    void NGXwShMZskpsu(int xNkTsAPt);
private:
    double QCvCPZvrcRSzU;
    double oMxjS;

    double SFMAIJUE(int opOTHeM);
    double xdHLQZYok(int JFiOLbWC, int dyhqSGhBH, string WOwCccalawRtsV);
    int ZRpJUbsDdSRwERz();
    void unHzW(int yIOaDaeyxJGuPn, double wXDcOxJZaKOR, bool TqhaxOqIzUbpTiU, string TVDFyDSidyW, double OORwoNKGaRU);
    void aFfBPc(double SkXTLDaXI);
    string HOoGVL(double wxOHXIJHSWfBt, bool uVfAXewc, int lvbzj);
    void bVsEkkRKjvzoELE(double rWPnBhCxmeBg, double wilLtOvUVVgUkKLx);
    void jSuePUs(int jxNCOLSiFh, double QeGaWGxcmvVl, string UMrNqIwWoRV, double uTOwclyUjMySu);
};

bool itgWVuObh::fvfemfoQZaotCsj(int LDtLOkyArfhv, double MOIxbpxNdxtrW, int PvxftGHhyiLDW, bool aIcLNqYoiGluj, int RBbCSJtUSQtHVDl)
{
    string dAqqWaIFEYDdJl = string("LyYnTgRsBIsBqeIMMGXkagmYTREzZIrvNIuGMzmhWybzooZQdTpZLxakYkUykiSaaftBWNqXCvDcLDCfIkcoBUfclYIjTDSTaaJpykmmeyGAfWZBnAFGKDwNrKSLHQEBLFJOekMNcEVZmGyopvrLXSXRhXNIJgDaMEqRaAPOdgfselLBhHRfnfqjYSSkqMVVpzRSJDrRJFUaZEhsSORXXHKQkBUhzpapcJshnjXfIgRknzSVxzfvnkORqHuKc");
    bool jVkwOUmXOnuvJ = true;
    bool jIjXKAY = true;
    double DSyGOTAxV = -152668.98812066493;
    double hslMJvk = 777213.7783895248;
    bool StQUETCmEti = false;

    for (int yvPFFByXH = 2082507240; yvPFFByXH > 0; yvPFFByXH--) {
        StQUETCmEti = jVkwOUmXOnuvJ;
    }

    for (int fGlHbCOVsI = 1811837424; fGlHbCOVsI > 0; fGlHbCOVsI--) {
        RBbCSJtUSQtHVDl = PvxftGHhyiLDW;
        PvxftGHhyiLDW = RBbCSJtUSQtHVDl;
    }

    for (int zhGFcRNTfIAThORu = 1940872143; zhGFcRNTfIAThORu > 0; zhGFcRNTfIAThORu--) {
        LDtLOkyArfhv -= RBbCSJtUSQtHVDl;
    }

    for (int mDgCtNUvTgdABfz = 74907180; mDgCtNUvTgdABfz > 0; mDgCtNUvTgdABfz--) {
        continue;
    }

    for (int pjjcLKGbTayk = 1126603247; pjjcLKGbTayk > 0; pjjcLKGbTayk--) {
        jIjXKAY = jVkwOUmXOnuvJ;
    }

    for (int mCEyHqu = 746423262; mCEyHqu > 0; mCEyHqu--) {
        aIcLNqYoiGluj = aIcLNqYoiGluj;
        jIjXKAY = jIjXKAY;
        dAqqWaIFEYDdJl = dAqqWaIFEYDdJl;
    }

    return StQUETCmEti;
}

void itgWVuObh::DxtbfrjcLMZ(double WadHqLHpWIzIYYPI, string CXQqanuXcQSdrH, double PBIsHlNrKrM)
{
    string nOxnELXMkBoGl = string("tkFbcgYsQqckebIjWuRiDhVWjLGSuKZgcqgiXDyFxhBphgrJPQBTNGjheXINnkokjQoTkdgllthqsbvuebGAcAbVKgqitdzoTNUgUQxGpuPTTDYMCxXGVEmBlZWOYSqOAJZGdrdEsopQMcgYKmPfcsqjdroWXmwAnIRayJpeDDoaG");
    string JmYtdMI = string("TNhsblBgFWYASsBcjIYxUJyAHDWVurbjYdgUYDbStvWKOxKgncmbgVIRzNEdAxOTkkjaiCaftxiyYAhFQXGGaAlamMGsHtAtLbtZhooZIwdeQMCAVFZioddodYLvmIRBoaxxeCSElEHxXRfrAyTzRxrLcoYTpHgZWASCSuJAvwPsfOCQmpOpcOA");
    int APximLexJo = -131273917;
    bool wRwpiDpddC = true;
    string cZaHfDKKRmwCHzp = string("rRZLsgYXffhLGjeWFUZTlRZXBVHzARhqYkMUhMWuqSPlmHuoWwIfhIFiFsTcyoDbTSZUxgEqmZRNrFHfpczuRsraxCDXrsfJCmxsaztvGFNEEZuCeADUFsmsOBiy");
    string TvGztPhaLchuvois = string("BqxUsDnQBumrnhfur");
    bool dXwhaviIT = true;
    double AHYlvHcQcjukFmd = -200375.41734864097;
    int LVWWxva = -1414517203;

    for (int FJTTQruHZveddKN = 1262723578; FJTTQruHZveddKN > 0; FJTTQruHZveddKN--) {
        WadHqLHpWIzIYYPI /= WadHqLHpWIzIYYPI;
        CXQqanuXcQSdrH = nOxnELXMkBoGl;
    }

    for (int gJiTuCHgWVdH = 1190451075; gJiTuCHgWVdH > 0; gJiTuCHgWVdH--) {
        continue;
    }

    for (int USgioYWAFPsDcTov = 426951722; USgioYWAFPsDcTov > 0; USgioYWAFPsDcTov--) {
        CXQqanuXcQSdrH = TvGztPhaLchuvois;
        cZaHfDKKRmwCHzp += CXQqanuXcQSdrH;
        cZaHfDKKRmwCHzp += TvGztPhaLchuvois;
    }

    for (int ZcjRPdCtlPmTHHkj = 736067369; ZcjRPdCtlPmTHHkj > 0; ZcjRPdCtlPmTHHkj--) {
        continue;
    }

    for (int EFJPnDQzTlL = 1097537431; EFJPnDQzTlL > 0; EFJPnDQzTlL--) {
        TvGztPhaLchuvois = cZaHfDKKRmwCHzp;
    }
}

int itgWVuObh::ofqCVKZJuIVbadI(string aUcgx, string FXGuF, string CbFixB, int CZhqREv)
{
    string UPMrtyEubKnTDL = string("SZyLJUiEFrwkWMNrMzAJeshGVTfnuuJyIfpTsZTnVGpWXFkmXsxezMTLcnVvJCKLQDGwEEHlyzxblsjJjWandAyZFNhqOqvvztQLNVWUYhItWCaanTRESdehbxtCnvFqJgMmQPGSLMvfCWTdkwMw");
    double fblAS = -993767.0910945565;
    string yTaDAPv = string("QjqGFcYtQmRUHJNiuCLxHRVtTscgnkMaeaCJiXrweRoExiGfMiURglFbQsrHWyGtwiPYzlOgsVByMLKrjjCbWBgAOcjfEioCrMmPdDTJVKUNXGDEYMnJYKJuPxLbRBuhHykuFylfChNfnfXQgRCXCzKmqdXvLTmFpqgcpkAZndRLKhpRYLhzlXZIcpPpUxbAB");
    string oTuuXzKiorelad = string("RRIbcDnUbhyVbRSTrDIWzgvHbqqwywgMMaNdRoKQyZYaQgYnrgwFJGDoA");
    double OsZlTKAIRZMSw = -938240.5231962453;
    double fEQNlJOo = -831812.271137382;
    string qrKsIICOJWhe = string("ZauDUbhCugcfwKidnbLMcMfQtRIOGSEhfwAGBDFVmyZNuTkPTeWJStxokhvUUkCQWeLQGYBJxvZjxYxZuwYtifaWfCqJSnSwhKwDrgbFukfkgIiwyNWJqzBWbQEvnkUJUgRKjEqDRQiwgHoXhWzUODmmwTwMX");
    bool foUrjkAawKbrSD = true;
    bool TKtENdNXcd = false;

    if (aUcgx < string("QjqGFcYtQmRUHJNiuCLxHRVtTscgnkMaeaCJiXrweRoExiGfMiURglFbQsrHWyGtwiPYzlOgsVByMLKrjjCbWBgAOcjfEioCrMmPdDTJVKUNXGDEYMnJYKJuPxLbRBuhHykuFylfChNfnfXQgRCXCzKmqdXvLTmFpqgcpkAZndRLKhpRYLhzlXZIcpPpUxbAB")) {
        for (int XvdhwDw = 1191142491; XvdhwDw > 0; XvdhwDw--) {
            continue;
        }
    }

    for (int bOYWzLq = 1609371252; bOYWzLq > 0; bOYWzLq--) {
        aUcgx = yTaDAPv;
    }

    for (int pffHp = 1039534509; pffHp > 0; pffHp--) {
        qrKsIICOJWhe += CbFixB;
    }

    for (int etBQyRmOXV = 1760339077; etBQyRmOXV > 0; etBQyRmOXV--) {
        aUcgx += oTuuXzKiorelad;
    }

    return CZhqREv;
}

double itgWVuObh::hldxwcilrRUvh(int aJClfvEhgnZvxtie, string ekVoxvrksGoFLmJ, bool hKHknzBeZPTDbHX)
{
    double WPJgByyqLWvnirFK = -484056.80451570573;
    int XxuVEqX = -934385040;
    int HQUHpShtYzPyFELg = -485916822;
    bool azNqxh = true;

    if (HQUHpShtYzPyFELg >= -934385040) {
        for (int clelGAmZShHKR = 1487657256; clelGAmZShHKR > 0; clelGAmZShHKR--) {
            azNqxh = azNqxh;
        }
    }

    for (int UFYWebXdeltZ = 570542461; UFYWebXdeltZ > 0; UFYWebXdeltZ--) {
        XxuVEqX -= HQUHpShtYzPyFELg;
    }

    for (int jUujWWI = 402321655; jUujWWI > 0; jUujWWI--) {
        aJClfvEhgnZvxtie -= XxuVEqX;
    }

    for (int nnzkO = 1953483417; nnzkO > 0; nnzkO--) {
        ekVoxvrksGoFLmJ = ekVoxvrksGoFLmJ;
        WPJgByyqLWvnirFK -= WPJgByyqLWvnirFK;
        azNqxh = ! hKHknzBeZPTDbHX;
    }

    if (aJClfvEhgnZvxtie <= 307526248) {
        for (int mxnqCrGsT = 624570122; mxnqCrGsT > 0; mxnqCrGsT--) {
            XxuVEqX += XxuVEqX;
            hKHknzBeZPTDbHX = hKHknzBeZPTDbHX;
            aJClfvEhgnZvxtie /= HQUHpShtYzPyFELg;
        }
    }

    for (int hZaNllZeSX = 2000917989; hZaNllZeSX > 0; hZaNllZeSX--) {
        aJClfvEhgnZvxtie = aJClfvEhgnZvxtie;
        HQUHpShtYzPyFELg += HQUHpShtYzPyFELg;
    }

    if (hKHknzBeZPTDbHX != true) {
        for (int vSGcikEOrlTlaRjf = 1388761428; vSGcikEOrlTlaRjf > 0; vSGcikEOrlTlaRjf--) {
            hKHknzBeZPTDbHX = ! hKHknzBeZPTDbHX;
        }
    }

    for (int VUtUC = 649931839; VUtUC > 0; VUtUC--) {
        continue;
    }

    return WPJgByyqLWvnirFK;
}

void itgWVuObh::uCxzGRxfYVy(double CztKwvGeU, int RlviBuLcWPSBRBgf, bool iAZPpmA)
{
    int vSeKfYVcTDjQjh = 402499454;
    double EJnjHtmpFozzwyfr = -714648.8793694299;

    for (int qdKzSwF = 408758197; qdKzSwF > 0; qdKzSwF--) {
        EJnjHtmpFozzwyfr += CztKwvGeU;
    }

    for (int bhEHRYuDuCaE = 1118078030; bhEHRYuDuCaE > 0; bhEHRYuDuCaE--) {
        EJnjHtmpFozzwyfr *= EJnjHtmpFozzwyfr;
    }
}

bool itgWVuObh::vsqIZpFsDBI(string iYZaPHAOHRQ, int QayWMjnBmzhL, bool WSiJLljfY, int sRzmTcAR, int KkLSVzqJ)
{
    int lZlapBVmDGf = 2026760555;
    bool sCKxkUIF = false;
    int SlLGqsuWCrQ = -876211580;
    double RiSsRLsFJlMPLTV = -566230.896638064;
    bool ionaIBXrz = false;
    double olJFAcM = 641847.7169827658;
    bool qjBtU = true;
    string JLAziq = string("LWMyIGYMKJeOgqxIGfTwvYkSPlHlHSEDudeisVYQMXqghzBTMuHUMXjCFqQLgJdQeyVQSxLTrZQjylWbsxQnzMaSfVRccutBvThZVnPcTqICyGEiGOByhazzmLDffXYCtSdOxqWcRLwnJhSQEcRnrOPGGZuMaQrwpNBUPbyVBxilEDUNQmcbHYDXtrdraimFyoL");
    int kLTrnXjtNgqrJ = -1175484160;

    if (sCKxkUIF == false) {
        for (int NjeQKxGMRv = 1945210641; NjeQKxGMRv > 0; NjeQKxGMRv--) {
            KkLSVzqJ -= lZlapBVmDGf;
            sCKxkUIF = WSiJLljfY;
        }
    }

    for (int wxarudEdEzgeZb = 760198960; wxarudEdEzgeZb > 0; wxarudEdEzgeZb--) {
        kLTrnXjtNgqrJ /= KkLSVzqJ;
    }

    return qjBtU;
}

void itgWVuObh::NGXwShMZskpsu(int xNkTsAPt)
{
    double MMWArqwuYYMKUgGM = 127555.94861924596;
    bool ERRyGNVKeCuaHv = true;
    int vsMPmHUWBmExt = 1903833556;
    bool WpqDGZdUhQUtZFOw = true;
    bool toaNaWYFjsXnJ = true;
    string OHhfvV = string("jelxFbLHbymzfGdDkNofPOHtirWLMPpceRQiDRFOeVupZNiMAiZVwmCFsqapzUGhVYCSEXrTBtlkFkhYWuNuzFskcKhhbyMvURZlxoSMCkpPOvgyOljuqqiLtowUKBzQfIpLGlXvsgFmHycVQznKajMYGzbRZRlSewdadPGDsPBFCEltaLRPQAvjTgYVZWaUoEASWndoqhZXvwGDVSUhQGGX");
    double PtzGxltMKOwXdhG = 14484.188208595828;
    double CEKeHmpjUChy = -806595.894437074;
    double mAsWphYM = -659235.7537197281;

    for (int zdeXUBkRDntm = 511905261; zdeXUBkRDntm > 0; zdeXUBkRDntm--) {
        continue;
    }

    if (toaNaWYFjsXnJ != true) {
        for (int ugCyWH = 727162085; ugCyWH > 0; ugCyWH--) {
            xNkTsAPt /= vsMPmHUWBmExt;
            MMWArqwuYYMKUgGM = MMWArqwuYYMKUgGM;
        }
    }

    for (int PUeMIwsrXp = 645114779; PUeMIwsrXp > 0; PUeMIwsrXp--) {
        WpqDGZdUhQUtZFOw = ! toaNaWYFjsXnJ;
    }
}

double itgWVuObh::SFMAIJUE(int opOTHeM)
{
    string SOrFGEhyTfsH = string("WZDhrvMVzvlGRbrTuxOmucYEVGKacyGhqzYKUcxyqrxhGeWcbwOvGxiuPxpnsSeRbIYCWJHyvdXlFcJIPGMQxbxDqZgcEcFWpOnQUzjJziofXPZFVdYVMzuboNCqruzsucUEUUzuUqsSBKjDzMrRIAafLFHxfenFKegioGZzfQdXDWTJopSMLJOONKxqbhdi");
    int FYIpnFJegoIoL = 752154855;
    bool iOwdqsKaDEUs = true;
    bool NshDiutJgEzoQ = true;
    int KkvMMiTntfDXbOl = -1004916553;
    bool COWFYnhxkxnwOg = false;
    string qsfjlSvSgSQtZB = string("QdpEuuhnuClTyjGDrCFkarxdEQHsLFuqpyfMQPvGeKEvbhOlDUcocSnTcDrmGwVQhJiTQoeVhZqmxXFHgdntKdPjxmerQpIfGrWRcrWOSKSTarj");
    int ASRWZFbEiDAWc = 622537958;
    bool ryEmegTFi = true;

    if (NshDiutJgEzoQ == true) {
        for (int OnCRKDjBTWlRp = 1403521105; OnCRKDjBTWlRp > 0; OnCRKDjBTWlRp--) {
            iOwdqsKaDEUs = ! COWFYnhxkxnwOg;
        }
    }

    for (int PwDkpCoqajdCYdfj = 417232692; PwDkpCoqajdCYdfj > 0; PwDkpCoqajdCYdfj--) {
        continue;
    }

    return -402435.4226790809;
}

double itgWVuObh::xdHLQZYok(int JFiOLbWC, int dyhqSGhBH, string WOwCccalawRtsV)
{
    bool UlyaJXGEJIuSEe = true;
    string iDnffkGheRVmMyTT = string("kjhEnqPhZmoRnUlEvznaSJCJMrAekVeqgGwMFsyOjaecZlCWtnsBhqNlQEVQCAzgpiYelPFZIbTwTvmgMCoNnrIoOGqOmZAJccccxifzpciSKjFPcAttlBojU");
    string hdhgYRZGcNZq = string("GeNxaTQlIpdHSxveeCOWgzfFqLoHoNFcFgJFRSoiIjrSDsaHOcKmunEpeHCHTnEStUHTYAFZDidYQNhYrSwfYLkKHjQXGf");
    bool aozZnrL = false;

    for (int PRhkyGdb = 1216315945; PRhkyGdb > 0; PRhkyGdb--) {
        aozZnrL = ! aozZnrL;
    }

    return -833640.2657364499;
}

int itgWVuObh::ZRpJUbsDdSRwERz()
{
    double inbSoIccQv = -640524.2446224585;
    double NPDtOfyuh = 710482.9716634874;
    string RRKNZqI = string("pBVpAVWMNxCQpaipIpipodegBhjmwZaKShTKQRVRkOsEpDoGalrKZRWYAoKkoKyjGuRhLicQShkDXcXQRPCFqkExYNDAYDGDqERIuIbewadFMabL");
    bool gYVxDRQAifZcPig = true;
    double ANURmYsLbUOQQNws = 508314.30894681247;
    string OLmzOybxG = string("xauBCREPRTdrrvWNjftXsRNUWUrLWqywKNltCwCTshoYMJoiIIkMGDDHWmFBfLcmxGLmmcXwaQTvVEoGQiUlnwBwEpeBYdwJOTPtImBXSkNW");
    bool qnmZKxFSOMSnBCj = false;
    bool CeiSjXJ = false;
    int DvDTABS = 1698704787;
    int KjrTvhRG = 2016308886;

    if (gYVxDRQAifZcPig != false) {
        for (int wsQXnJoyboMkp = 1321563623; wsQXnJoyboMkp > 0; wsQXnJoyboMkp--) {
            DvDTABS -= DvDTABS;
            RRKNZqI += RRKNZqI;
        }
    }

    for (int ZUSAeSpv = 1437572538; ZUSAeSpv > 0; ZUSAeSpv--) {
        KjrTvhRG /= KjrTvhRG;
    }

    return KjrTvhRG;
}

void itgWVuObh::unHzW(int yIOaDaeyxJGuPn, double wXDcOxJZaKOR, bool TqhaxOqIzUbpTiU, string TVDFyDSidyW, double OORwoNKGaRU)
{
    int hHvhbNmgrANJrUH = 1462988962;
    double tsOqsabOdvMTQfMl = -218652.16100820023;
    bool DJsVEP = false;
    double oPsTMhFNi = -259908.23014440006;
    bool gtPrfe = true;
    double hWOCAJrN = -815108.2482503292;
    double hJxYed = 1011414.3753394884;
    double cvQAFVoL = 250356.29969866556;
    int uyKYiberRyJtfpC = -506482700;

    if (oPsTMhFNi >= 446265.2515164042) {
        for (int skpfx = 1840283569; skpfx > 0; skpfx--) {
            OORwoNKGaRU += hJxYed;
            tsOqsabOdvMTQfMl -= OORwoNKGaRU;
            DJsVEP = DJsVEP;
        }
    }

    for (int uLnCvPe = 647433814; uLnCvPe > 0; uLnCvPe--) {
        continue;
    }

    for (int fYmDGQesPLt = 90126909; fYmDGQesPLt > 0; fYmDGQesPLt--) {
        OORwoNKGaRU = hWOCAJrN;
        hWOCAJrN /= OORwoNKGaRU;
        cvQAFVoL += hWOCAJrN;
        hJxYed = cvQAFVoL;
    }

    if (gtPrfe != true) {
        for (int gJLYSwhJwQB = 142847413; gJLYSwhJwQB > 0; gJLYSwhJwQB--) {
            TqhaxOqIzUbpTiU = gtPrfe;
            yIOaDaeyxJGuPn /= yIOaDaeyxJGuPn;
            tsOqsabOdvMTQfMl *= hWOCAJrN;
            tsOqsabOdvMTQfMl /= hJxYed;
            oPsTMhFNi = OORwoNKGaRU;
        }
    }

    for (int QeUVoi = 642655063; QeUVoi > 0; QeUVoi--) {
        continue;
    }

    for (int GeuXdPsftmwew = 1598658458; GeuXdPsftmwew > 0; GeuXdPsftmwew--) {
        OORwoNKGaRU += OORwoNKGaRU;
    }
}

void itgWVuObh::aFfBPc(double SkXTLDaXI)
{
    bool NbWbc = false;
    double cRXsEhHdCkigmJd = 36400.72036682856;
    string TXokUHEmZ = string("OVSrHgekIXAORFGpslKjvzbSHo");
    string YswpHCDmySfsao = string("gHjAGmvyKfawnVAvtWaOsJhLLQxBRJoFYQbFfLDpeWfigYmhIpNrbN");
    string FNIBcBYk = string("GqNJFmOPRTCRlrAgtfHBDGLCsxLExQcKWEAbVZldYKEzutKLBdtPqukpBVmOvOeWWBCUuMcAFglMhtSvqAdGRhMagKPoHYEtSTKJSKAyewpLxheXmwLxrNhkPyNFMNhkKVpYZeOYsUovACMbKqefLUExaRnopOQCOdOTDsxJVHpevvFkkWkoUosqhjHbpAmDmnAzbZXeCuqWPltyNzoebsVIJVyoNuVcRdvB");

    for (int tKydk = 1621949809; tKydk > 0; tKydk--) {
        cRXsEhHdCkigmJd /= cRXsEhHdCkigmJd;
        SkXTLDaXI = SkXTLDaXI;
    }

    for (int zzWqFBHsNWanui = 470006181; zzWqFBHsNWanui > 0; zzWqFBHsNWanui--) {
        continue;
    }

    for (int cfzTKVWeSOxJ = 1402900026; cfzTKVWeSOxJ > 0; cfzTKVWeSOxJ--) {
        FNIBcBYk += YswpHCDmySfsao;
        FNIBcBYk += YswpHCDmySfsao;
        cRXsEhHdCkigmJd += cRXsEhHdCkigmJd;
    }
}

string itgWVuObh::HOoGVL(double wxOHXIJHSWfBt, bool uVfAXewc, int lvbzj)
{
    double aCbOcQJrkbayo = -71121.60375423639;
    string HQeLprYf = string("ALkwqapsprcmpmtFjXWwALFyhucPMRWLfJRmsGyLrfRSakAVWSRKsFJxRp");
    bool Hopgz = true;
    int dOHsstzAXlHRIkcN = 1065945537;
    bool nRccDUXWhWbhS = true;
    string jzydCngqZDvFX = string("lKzpdAoXtKuDalBKnBnIQoTFliELdOOuMjfZzIJJkAgcClTCyNRkuDkzFYqZozVtvwkHXZtzeBtBUktXQrnQoIrZUrYJFhUOdBMqOaoMuoTQfyXaHfhoYQybEjNoGIiffMROmAWaCyhNBRICfoFWbCbDaICGKRjaFFddZDoggrngZjBXuFxF");
    string wQFSRDejNoJ = string("RKBpKwnyyUGFDnKBGFuQeoqpdfMxaZwhnnSXbVeuEaJRbZRnqOKMyjkZezufHAiovbViGyqDauKNMmlvReYjDmBtgLWcaBbICjmEjBBRCTAk");
    double izKyiShxsYOoLyyU = -488802.88162330666;
    double ByZTPqI = 76991.54053727214;
    int qNLQUBhabpdriqd = 1432684643;

    for (int sJRxvDAyUnrXYvP = 909762925; sJRxvDAyUnrXYvP > 0; sJRxvDAyUnrXYvP--) {
        HQeLprYf += HQeLprYf;
        nRccDUXWhWbhS = Hopgz;
        aCbOcQJrkbayo += izKyiShxsYOoLyyU;
    }

    for (int VlRYJFXSWpYwLkBS = 1138700557; VlRYJFXSWpYwLkBS > 0; VlRYJFXSWpYwLkBS--) {
        qNLQUBhabpdriqd *= lvbzj;
        HQeLprYf += jzydCngqZDvFX;
    }

    for (int PmNEAtF = 1734342226; PmNEAtF > 0; PmNEAtF--) {
        Hopgz = uVfAXewc;
        nRccDUXWhWbhS = Hopgz;
    }

    return wQFSRDejNoJ;
}

void itgWVuObh::bVsEkkRKjvzoELE(double rWPnBhCxmeBg, double wilLtOvUVVgUkKLx)
{
    double Oykooyyil = 832304.4485591209;
    bool zhmEpQJ = true;

    if (wilLtOvUVVgUkKLx != 832304.4485591209) {
        for (int XbXiDuzp = 832933385; XbXiDuzp > 0; XbXiDuzp--) {
            wilLtOvUVVgUkKLx /= rWPnBhCxmeBg;
            wilLtOvUVVgUkKLx /= rWPnBhCxmeBg;
            wilLtOvUVVgUkKLx = wilLtOvUVVgUkKLx;
            rWPnBhCxmeBg -= wilLtOvUVVgUkKLx;
            rWPnBhCxmeBg -= rWPnBhCxmeBg;
        }
    }
}

void itgWVuObh::jSuePUs(int jxNCOLSiFh, double QeGaWGxcmvVl, string UMrNqIwWoRV, double uTOwclyUjMySu)
{
    string JAvLrCyOgkmk = string("lpKTEUzzYukXzXFTeRxBVvFVzqFpnVvPqfMzfSsasjHEJrFVocDMhPYuWqLUkSYaXuYGVcgzQwGKgoPkNMPiLFgjWduhaAGTiBYIJndmVRzwIcoOjyroEaPoBdkJJJTWMyvXeecIkPYeFeGOBvZjxXbFxeEZpjCQeoSVGTqaYVDfVrPApXkvuQAYlKlBwJQnTqvbGksKiDzfGAuDTIuqcdIJ");
    double oLuzWafxVtEtRQbD = -143641.50021402893;
    string dqHZpKuweHMqQ = string("JNnmdqiRFGcMVtjtScGdqjJmEFpoxxCzShegcFsEzdsaPwwxtfIdOBDvXCYNQAwnJnGNtNZaIiOaEqidGgqfKSOd");
    bool GSsmSapRnhe = true;

    for (int JpNdTxYRxssPPQR = 348564457; JpNdTxYRxssPPQR > 0; JpNdTxYRxssPPQR--) {
        GSsmSapRnhe = ! GSsmSapRnhe;
    }

    for (int jBKth = 173346088; jBKth > 0; jBKth--) {
        continue;
    }

    for (int wDKzROJeRnxbV = 371186636; wDKzROJeRnxbV > 0; wDKzROJeRnxbV--) {
        UMrNqIwWoRV += UMrNqIwWoRV;
    }
}

itgWVuObh::itgWVuObh()
{
    this->fvfemfoQZaotCsj(1239926327, 51726.33288734935, 604029781, true, -515002677);
    this->DxtbfrjcLMZ(-760340.1393079126, string("zNmnvnkEhNyhiEQQcpPWY"), -569919.0216347943);
    this->ofqCVKZJuIVbadI(string("eVGWEPWmNGrkHriNoDNMJRePpiTcEfRqKzPXpXAxmrJmYayXEUXCCCYPucKaddLQVgWTiCEYlhzEEFRUEHkSnXYqUcARcaqchxwPPNkEbxogRDiUBoRlqvKIfPzhOsRJajdrQMhaInfONOuyhfWUsNpBHUKfobiARsgfBgzKoUFJqHxaCDOtTlyRzYIvXWTmXmPezOGSSdBLOwrosYjkLMHxmZTHgzcPUtSQBeinWaMLzCmBaFafL"), string("BhlZghCUQSiZZyLwXXiKHBAmRKPLlbRnMPcdQgsszHKbTvQdYQBarZEloxelXfPkRNYdiOsETlfawfMnKQEyuLsoqSFKIPshjGKCNyDGcTStxIkpsaXjTEDbsiiwvpMulsqLWwnlcozUHxNxl"), string("hQSmAAwYGoIBgurqLmXExtyERqBXznidtybDOgsywjplrOhYzOWNnEpSCPEtsgSUYroURnmIgktZXXKvHEQTsRoajaLgnYXusqqThdqbANEmpuadYGISLzhdkcUnaFOgcvzpXiZruObsUjmgSbrHrpZzDYooRyjInsSANwO"), -2084830708);
    this->hldxwcilrRUvh(307526248, string("WtniPMrwqbBbKkRziHxspVGfQOSlxMBygEyuEfMGGdEbBDJoXJOTCVxFOzMkjFYIkQYuvMpQgTGMcIEgJPMBppeSRTaKfPWdJhVwhdQBHXbSPBlCQNbmEilUlqEKHIoEXJTYfQepkwUOyzAWbcZoAUTvqAmloTaXjDmkKiZglGKSzGdiRrxoxfrDsetVFhxfuloLPEIOyh"), true);
    this->uCxzGRxfYVy(-762209.6494405137, -1245970876, true);
    this->vsqIZpFsDBI(string("ilUhVyqpqAVNLAVhKysHOVxKkTvHvNntcXfcEomuzYdVFCpuWxgCDZqtPZWtGvrtArupKllLpaUQaPREITezMWDozbFwFqFXTGqvLOtxnpobUyvXToSikxTwoudXayyiWmSvZTWIMbGlfHAjQfWYOzVTDhQgnwGGIasGiSNmEDLIVeazUhahMQtRRygkjj"), -1779122928, false, 1101792427, -1582680745);
    this->NGXwShMZskpsu(-596486140);
    this->SFMAIJUE(-1170875096);
    this->xdHLQZYok(-768350609, -155281900, string("SFfZmbBrSRHvvqgYAVIaElMuJlwILiMFufxwPNEMAq"));
    this->ZRpJUbsDdSRwERz();
    this->unHzW(-891624111, 446265.2515164042, true, string("uVzUcWMxGNylFxUkzAxUOkisaJWFQumFSvbRLveOgkJayvCKrIlTKcxzmvAaQOVrfcrCHfOZNxdXlZqFrRqDQqhSpUzRyjNoOwTZcAEyyjtmIWKyHRQflKhyBbqHURoFjQKgnjxpLLMHZCidLGpIlQ"), 426594.3857203067);
    this->aFfBPc(-506894.89461617195);
    this->HOoGVL(-254221.80620108187, false, -1272520744);
    this->bVsEkkRKjvzoELE(-897438.5063495077, 309545.402309854);
    this->jSuePUs(240648076, 291897.1898518984, string("oOuMVMGUwGctyJygeFtoiJTlPppnGDeZCSohcsHSUIgiSWJTWxnhQiljazqmifhPLFEcorxhEEmaBXPhkQQFZuKhrDKZyvXTsTBxNNZpiDLUqQs"), -581048.4329107027);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class naNxRRS
{
public:
    double rHRVjvuDAYppGOS;
    double XRvUvM;

    naNxRRS();
    double XPMpvq(bool PFHhjd, int UuVDAxGzrt);
    double RprhnI(int Wlxrpr);
    int BeEKWFOvhn(double EemyXp, int VTqGz, int aXzWJBmvGdRTdS, string kcrUhPGN, double HWmTUVfIfhIzSO);
    double UhDvfxeedD(int EYdcdWtszRS);
    double cNYJEacQE(double JumAholSBIwnz, bool RSUORXRoSuhTR, bool jSNflsuwVCxpYoZt);
protected:
    string vDpryEXjCaVoSbjC;
    bool KGFkkA;

    string MjePmVUrevWF();
private:
    string pZbdYyzYzpIhPxYq;
    bool EQibkUhpiGGEJC;
    string BAzkKi;
    string xMiSXBCawdygGYe;

};

double naNxRRS::XPMpvq(bool PFHhjd, int UuVDAxGzrt)
{
    double QVJPJeFqVKXKXeGk = 303723.51491458755;
    bool RtXuvciPYMf = false;

    for (int HxdagLV = 1727915342; HxdagLV > 0; HxdagLV--) {
        QVJPJeFqVKXKXeGk = QVJPJeFqVKXKXeGk;
        PFHhjd = PFHhjd;
        PFHhjd = PFHhjd;
    }

    if (RtXuvciPYMf != false) {
        for (int lmvfabHNQ = 780577975; lmvfabHNQ > 0; lmvfabHNQ--) {
            RtXuvciPYMf = ! PFHhjd;
        }
    }

    for (int ZcHAwDURfYAy = 1932664362; ZcHAwDURfYAy > 0; ZcHAwDURfYAy--) {
        QVJPJeFqVKXKXeGk = QVJPJeFqVKXKXeGk;
        PFHhjd = ! RtXuvciPYMf;
    }

    return QVJPJeFqVKXKXeGk;
}

double naNxRRS::RprhnI(int Wlxrpr)
{
    bool XTBGYrkEBcc = false;

    for (int UKQqjXGHeiqVA = 828437585; UKQqjXGHeiqVA > 0; UKQqjXGHeiqVA--) {
        Wlxrpr += Wlxrpr;
        Wlxrpr -= Wlxrpr;
        XTBGYrkEBcc = XTBGYrkEBcc;
    }

    if (XTBGYrkEBcc != false) {
        for (int RHbLDqTR = 2061669750; RHbLDqTR > 0; RHbLDqTR--) {
            Wlxrpr += Wlxrpr;
        }
    }

    return -998376.8934665703;
}

int naNxRRS::BeEKWFOvhn(double EemyXp, int VTqGz, int aXzWJBmvGdRTdS, string kcrUhPGN, double HWmTUVfIfhIzSO)
{
    bool AwuDvgcnYyC = false;
    string ameOyYjhcNazwP = string("VYaitjQuZWPczmRVibvPqalOTwEsclavbNCHrIhTZOLhCtHGGQPcyOyqSGzJqAlvMScXFnRGpQDBPeAjAuWMrwvvDWjuEFwGzoZwKKpPmZsORRIesIYGSYgZggYkqjNxSykrDBCGdmboIURQGVrlmtZLcbDOrkx");

    if (kcrUhPGN == string("FrbdxFXwzahPbObVvNYNxdniGAdsKwwGDpvMLAtxYooAjEATwAQcIvzPiIegVFVixJIutgZEsIuHNcVkdOJeYzcNHeDBHjeTDbGVJLnFJQYlWqzAxcHyFstbLTZWLFNYERAnthlypgnWloFfZRTrtIbQUdqNtoSIfoseCMqtaWliOqCuMAhkWChvhVDrRTftrWNRoGAUDWlNLcfYSWtYwCWxDWCaruDEwbppe")) {
        for (int aYwdbxIGPyoj = 1909785623; aYwdbxIGPyoj > 0; aYwdbxIGPyoj--) {
            VTqGz -= aXzWJBmvGdRTdS;
            EemyXp -= HWmTUVfIfhIzSO;
        }
    }

    for (int WfSBjbP = 1007258118; WfSBjbP > 0; WfSBjbP--) {
        HWmTUVfIfhIzSO *= HWmTUVfIfhIzSO;
        aXzWJBmvGdRTdS += aXzWJBmvGdRTdS;
    }

    for (int IScikR = 443418974; IScikR > 0; IScikR--) {
        continue;
    }

    return aXzWJBmvGdRTdS;
}

double naNxRRS::UhDvfxeedD(int EYdcdWtszRS)
{
    int ypFQdoCXf = -843337272;
    string zPnjhZKTFBSaXuJ = string("UAHygAjYnNmrCpFbKOlxnuImtpWQfnFAxEFQXdd");
    int JFKoHLFEMbR = 294860216;
    string cmlUcjUPwEDzA = string("lBmGGlRnjHwuyBkdeUEGgLjNscsBDXiqvWmcYJWtHEXZbsVOyBTgDaURHBKzMLYzrjdqtkmPztsJKQYNAKvFmJcAjIjgLnegYOsSGpWnubuzHeoyqJHvgdV");
    double ZeaPtufTIIU = -223581.59132674348;
    string eHGcGqARaFjffuVc = string("qUmkBbLVonebOvkQzlABOimWvlqmeAOVhlFrdyWpoRtmnoZObZnBRkPQESBVdFBzupsMcHsJQnZjjTxTzblDtEbYIBiTnEgOtTUjBfFlKWsMRJBTiaFUNWTwtbwzCRfkckFoXIyeaNCHecNCyhBmzWynNaUyeyHwWFcyUbkhZFIUhAlgpYOk");
    int ygtaacdDhZ = 540526944;
    double ncvrUulR = 77803.84461057185;
    bool rUXSFtPPE = true;

    if (JFKoHLFEMbR != 294860216) {
        for (int BtCKAkPtrLIrjQud = 198198905; BtCKAkPtrLIrjQud > 0; BtCKAkPtrLIrjQud--) {
            cmlUcjUPwEDzA = zPnjhZKTFBSaXuJ;
            JFKoHLFEMbR += EYdcdWtszRS;
        }
    }

    for (int QsOPaZwybSH = 435056975; QsOPaZwybSH > 0; QsOPaZwybSH--) {
        zPnjhZKTFBSaXuJ += zPnjhZKTFBSaXuJ;
        ZeaPtufTIIU += ncvrUulR;
    }

    for (int HdoTXt = 1992579997; HdoTXt > 0; HdoTXt--) {
        ypFQdoCXf -= EYdcdWtszRS;
        ygtaacdDhZ = EYdcdWtszRS;
        ypFQdoCXf -= JFKoHLFEMbR;
        zPnjhZKTFBSaXuJ += eHGcGqARaFjffuVc;
        ygtaacdDhZ = ygtaacdDhZ;
    }

    return ncvrUulR;
}

double naNxRRS::cNYJEacQE(double JumAholSBIwnz, bool RSUORXRoSuhTR, bool jSNflsuwVCxpYoZt)
{
    double EkSSiTsKpJKd = -783549.5179998162;
    string hLJwVQq = string("pMRvRJhplWfvpIaNWLkXxrKasIzhcJrzJVjeCRkCWfrfpfSg");

    return EkSSiTsKpJKd;
}

string naNxRRS::MjePmVUrevWF()
{
    bool ZGOvrLTEOesTXXO = true;

    if (ZGOvrLTEOesTXXO != true) {
        for (int blrQAGfd = 1089219798; blrQAGfd > 0; blrQAGfd--) {
            ZGOvrLTEOesTXXO = ZGOvrLTEOesTXXO;
        }
    }

    if (ZGOvrLTEOesTXXO == true) {
        for (int CtMukGYJhZPVA = 537219627; CtMukGYJhZPVA > 0; CtMukGYJhZPVA--) {
            ZGOvrLTEOesTXXO = ! ZGOvrLTEOesTXXO;
        }
    }

    return string("wWCYSYYasNStalYvwCFnmyBrWRGOusHRoxRNIbbZJqmWXqBwxbHxGIfsDHlZATTBtO");
}

naNxRRS::naNxRRS()
{
    this->XPMpvq(true, 996968269);
    this->RprhnI(-424032239);
    this->BeEKWFOvhn(-762974.6866661927, 953720003, -389835639, string("FrbdxFXwzahPbObVvNYNxdniGAdsKwwGDpvMLAtxYooAjEATwAQcIvzPiIegVFVixJIutgZEsIuHNcVkdOJeYzcNHeDBHjeTDbGVJLnFJQYlWqzAxcHyFstbLTZWLFNYERAnthlypgnWloFfZRTrtIbQUdqNtoSIfoseCMqtaWliOqCuMAhkWChvhVDrRTftrWNRoGAUDWlNLcfYSWtYwCWxDWCaruDEwbppe"), -155791.96626351765);
    this->UhDvfxeedD(1955717285);
    this->cNYJEacQE(549987.2336906978, false, false);
    this->MjePmVUrevWF();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uoXOCNHVYA
{
public:
    bool IwYwysLRLdSIdvBy;
    bool CDRSSZmHYZA;
    bool xapIdCIcLsDUTQv;
    bool btrwqSnrNaPuS;
    string KKmqRFckc;

    uoXOCNHVYA();
    int jMbjWYj(double FhJkEOOo, int PlgKKv, bool oAQtavvYbBv, string MaaMsF, int CrKRA);
    bool kTiDRwvpisiU(string gkZDVM, double qMqzVxOug, int acIxAGKNQYLAZ);
    void HJYhxTl(string SFYRFfwdKJdO, bool hjgXXktxdwWXMzsh, double KAUDa, bool IvixCuxnhVyNH, string umaQMAqEIMXGmT);
    bool eOhZfpw(string eKEYsuoPpaTSe, double QheIBPhAPFGLXTz, int anTlpkODDj, double zKgQzyJ);
    bool uxfTUnLuyG(string JmgnNSaTNvaR, double CsYjVJrMBCLAru);
    string nnruggZ();
protected:
    int XqvpZeCS;
    string MJKyHEKobK;

    double UojLRo(bool HXBBOFXYLq, string orZHqADPzE, double LkFNVQLwxpRLi, double qHBjjdWo, double eDMoRrrExUID);
    double DWgohqTHiCkQF();
    int LsuaJS(int GKbGaNHOnlot, string rofoIYlZ, double JCCxHnXY, string aJSQnPedK);
    string uTEUoixwnXLPK(bool pjMrtENmeFNJopxK, string txjfilEHnqHHs, int fVlYQILxQRn, double oVYqMOVnlWnEKfCu);
    void qYQBgwBU(double sbrzMTtEg, double PaSHL);
private:
    bool VgyeAYbfhNH;
    bool ewpaepO;
    int gOBYMq;
    double RcanCAqTgQJy;
    string zLctUTw;

    int LzYjrbkSzejVa();
    void XIHisP(int mFxWURwNtcFg, int kFLDTfp, string dalCIV, double YMTcVMCQMPLcIU);
    int XmBkX(int ukhXIzyN, bool adZtHCaUdVxXz, int HFmlfL, double xrQPRtIEkvJedjml);
    string pqGvroyVq(int srqudTQQ);
    string QzlojFBJ(int hwPdnXFPs, string JCEwPAi);
};

int uoXOCNHVYA::jMbjWYj(double FhJkEOOo, int PlgKKv, bool oAQtavvYbBv, string MaaMsF, int CrKRA)
{
    int TOhBAwzgnlL = 324445828;
    string IEdbqpnC = string("aejiywmaNYNDMpINMrbeRJAGhjextbKCxRzYxkBzWhglyGnLNNErHdkmRMYgrpZoZtJpwVwEeGFEblQSWlVMFxBhXeGpKPzFlEZlpIeaQnITJrCyYKolhcGjEEpPNMpchxNOCNoLvnCpldhIEKDdVRyCbrqcCgShzlvxxdzpIyDJBIhWFwMRSFfUEytmaePXUqalfpKjNybveKXzPWAEDTjSFYRFR");
    double vtvnonrjuzO = 944474.4896484019;

    for (int NTnhHymeErGigBDc = 1323097947; NTnhHymeErGigBDc > 0; NTnhHymeErGigBDc--) {
        TOhBAwzgnlL += PlgKKv;
    }

    return TOhBAwzgnlL;
}

bool uoXOCNHVYA::kTiDRwvpisiU(string gkZDVM, double qMqzVxOug, int acIxAGKNQYLAZ)
{
    double sDkzVYHgp = -49609.844682898605;
    string TteXlmazyqCAWyT = string("EJHhsjglYEeynNJDOoGiaSGQkoXxPEwCpgytOItorxmCMauhatyggygurbSxnZDRyUJtaGRvCLEwdPUaZxexdPlqKiGWfBjDYrjLWLwvOnLbIEjKZYDHLqCYWWTxzLPinVrYVFERLwfsyzyaFwWBvJRYfOeSlctBvcQuBmZFkgwGHhoBVHpaQPgdUJ");

    if (sDkzVYHgp < -49609.844682898605) {
        for (int qUiTeI = 1839186612; qUiTeI > 0; qUiTeI--) {
            sDkzVYHgp *= sDkzVYHgp;
            gkZDVM += gkZDVM;
        }
    }

    for (int zmLGz = 1901974403; zmLGz > 0; zmLGz--) {
        TteXlmazyqCAWyT += gkZDVM;
        gkZDVM += gkZDVM;
        gkZDVM = gkZDVM;
    }

    if (qMqzVxOug >= -49609.844682898605) {
        for (int NndwjwYqRJOMb = 610195178; NndwjwYqRJOMb > 0; NndwjwYqRJOMb--) {
            gkZDVM += gkZDVM;
            qMqzVxOug += sDkzVYHgp;
        }
    }

    return true;
}

void uoXOCNHVYA::HJYhxTl(string SFYRFfwdKJdO, bool hjgXXktxdwWXMzsh, double KAUDa, bool IvixCuxnhVyNH, string umaQMAqEIMXGmT)
{
    int ZQKlKMuELYfJtP = 945525276;
    int bDLwmgwhyAd = 628127941;
    string nVOyCFlKUd = string("XXCelLQaYcMTlukhjlGfHfwrUWVCJuFRYffjdxAMKUzpZykwmLpnkICtsNjkguobzGObWtnlDypAiOWoSroqtBpKEQCFHXBVWNirRldeXqtneLgyGrQzAWJLFZMMkriYYnEztLWIyMPBUEYLGSUgFBhm");
    int fxWLvZnkiuhS = 2006105406;
    bool bBMRfBKsuxKmCH = true;
    double iuAmlfmFBeJ = -45272.24624971137;
    string jnITw = string("BjgUVOXlaytZuZNagJMxYokCeBJHlwnXtRPbdzAIxCZjTzmvfGTQOjJgIZMDWNVlNnYUjukkyDyKTbzZrMlhzdsyxCxvtrYVTneInDEuvaqjHgzbvYdBZEBMQXWetyNoWbykZlttfwWCkbQgxQfiueMbnOMumSnlXHmUOojlCGSgwHBQBIHxvQxcVudlamUTGKdGSmABgsGbMgyEKtYeYN");

    for (int Iqptxc = 34168377; Iqptxc > 0; Iqptxc--) {
        fxWLvZnkiuhS = fxWLvZnkiuhS;
    }

    for (int jVsFqETOog = 1052928788; jVsFqETOog > 0; jVsFqETOog--) {
        bBMRfBKsuxKmCH = ! IvixCuxnhVyNH;
        ZQKlKMuELYfJtP *= fxWLvZnkiuhS;
    }

    for (int VdPWHVc = 454955015; VdPWHVc > 0; VdPWHVc--) {
        umaQMAqEIMXGmT = umaQMAqEIMXGmT;
        IvixCuxnhVyNH = hjgXXktxdwWXMzsh;
    }

    for (int UXDZgXPYSnb = 584171698; UXDZgXPYSnb > 0; UXDZgXPYSnb--) {
        IvixCuxnhVyNH = IvixCuxnhVyNH;
        umaQMAqEIMXGmT += SFYRFfwdKJdO;
    }
}

bool uoXOCNHVYA::eOhZfpw(string eKEYsuoPpaTSe, double QheIBPhAPFGLXTz, int anTlpkODDj, double zKgQzyJ)
{
    double xBRqmZkgXRRt = 294962.7371316856;
    string LoDSrRECxAkEImIs = string("oSOgHHkNCQOiXrjAdTsksRGOKiMkIFtPRrFToZVlCtEfxxxeYCpkMROMQYsYqqMehqMAgsCvFeJVBsYDWUwOihloUMNMhWfVmmvOTEloUfGjzKBLZPxBFjQBJMFvIGCiDeIwPMaeaEPnLJLkevRGBOfyOSnzIrcPUGCGJAGbxZHrJMpLtqwPKgVrGwnDQS");
    bool UcxSvAaroBXOIORu = true;
    int AgGMC = 2056305458;
    int btpNqsGMZ = -965284147;
    double CfaARwKuEfb = 411018.73430605134;
    int neEYVsy = 2040618357;
    string cUPxbYsXNnMKAHIy = string("EX");
    bool SZqudIUnFYbayzE = true;

    if (neEYVsy < 2040618357) {
        for (int nzQGtQCUdiYdYqKe = 827432592; nzQGtQCUdiYdYqKe > 0; nzQGtQCUdiYdYqKe--) {
            LoDSrRECxAkEImIs = LoDSrRECxAkEImIs;
        }
    }

    if (anTlpkODDj <= 2056305458) {
        for (int tuknFWdREaTNCmoQ = 1619370181; tuknFWdREaTNCmoQ > 0; tuknFWdREaTNCmoQ--) {
            xBRqmZkgXRRt /= CfaARwKuEfb;
        }
    }

    for (int tzzfupkKqTG = 728955506; tzzfupkKqTG > 0; tzzfupkKqTG--) {
        cUPxbYsXNnMKAHIy += cUPxbYsXNnMKAHIy;
    }

    for (int TAHiw = 1286443954; TAHiw > 0; TAHiw--) {
        cUPxbYsXNnMKAHIy = LoDSrRECxAkEImIs;
    }

    return SZqudIUnFYbayzE;
}

bool uoXOCNHVYA::uxfTUnLuyG(string JmgnNSaTNvaR, double CsYjVJrMBCLAru)
{
    bool UvQimczSvk = true;
    bool dPDiHMI = true;

    for (int YoAltTHSCz = 1033779863; YoAltTHSCz > 0; YoAltTHSCz--) {
        UvQimczSvk = ! dPDiHMI;
    }

    if (dPDiHMI == true) {
        for (int wlkLmJfb = 129331229; wlkLmJfb > 0; wlkLmJfb--) {
            continue;
        }
    }

    return dPDiHMI;
}

string uoXOCNHVYA::nnruggZ()
{
    double PMADpDyTtM = -538165.9502518077;

    if (PMADpDyTtM != -538165.9502518077) {
        for (int ClalxMDEwWD = 87207922; ClalxMDEwWD > 0; ClalxMDEwWD--) {
            PMADpDyTtM = PMADpDyTtM;
            PMADpDyTtM = PMADpDyTtM;
        }
    }

    if (PMADpDyTtM > -538165.9502518077) {
        for (int GuvKSxSzSZ = 866593307; GuvKSxSzSZ > 0; GuvKSxSzSZ--) {
            PMADpDyTtM /= PMADpDyTtM;
            PMADpDyTtM /= PMADpDyTtM;
            PMADpDyTtM /= PMADpDyTtM;
            PMADpDyTtM /= PMADpDyTtM;
        }
    }

    if (PMADpDyTtM != -538165.9502518077) {
        for (int PzYAtJrn = 447494757; PzYAtJrn > 0; PzYAtJrn--) {
            PMADpDyTtM *= PMADpDyTtM;
            PMADpDyTtM /= PMADpDyTtM;
            PMADpDyTtM -= PMADpDyTtM;
        }
    }

    if (PMADpDyTtM >= -538165.9502518077) {
        for (int sxmXARSqREsPEfd = 974935532; sxmXARSqREsPEfd > 0; sxmXARSqREsPEfd--) {
            PMADpDyTtM /= PMADpDyTtM;
            PMADpDyTtM = PMADpDyTtM;
        }
    }

    if (PMADpDyTtM != -538165.9502518077) {
        for (int DPWXXNOSRLKtd = 1267044980; DPWXXNOSRLKtd > 0; DPWXXNOSRLKtd--) {
            PMADpDyTtM *= PMADpDyTtM;
            PMADpDyTtM = PMADpDyTtM;
            PMADpDyTtM -= PMADpDyTtM;
            PMADpDyTtM = PMADpDyTtM;
            PMADpDyTtM *= PMADpDyTtM;
            PMADpDyTtM -= PMADpDyTtM;
        }
    }

    return string("NFeJVDSOoUxOFGuwHciSvbWANWqGB");
}

double uoXOCNHVYA::UojLRo(bool HXBBOFXYLq, string orZHqADPzE, double LkFNVQLwxpRLi, double qHBjjdWo, double eDMoRrrExUID)
{
    bool whlaPnMeAtyxgYEr = false;
    int BmQzJzBs = -2035477598;
    double waZoyaqvtEuPHgkp = 862010.9032511411;
    bool WtClxvCoxmziSyZK = false;
    bool VTfWhtzfALEdPLF = true;
    double LbVSUdvpAjB = 744514.2287698837;
    double ThtbFxGKiridr = -278815.53821036074;

    if (BmQzJzBs >= -2035477598) {
        for (int OtcZZZYYVVYuXpM = 1402052919; OtcZZZYYVVYuXpM > 0; OtcZZZYYVVYuXpM--) {
            whlaPnMeAtyxgYEr = whlaPnMeAtyxgYEr;
            eDMoRrrExUID = LbVSUdvpAjB;
            whlaPnMeAtyxgYEr = VTfWhtzfALEdPLF;
        }
    }

    return ThtbFxGKiridr;
}

double uoXOCNHVYA::DWgohqTHiCkQF()
{
    double VHQRkcgWKezyN = 43941.711637403125;
    bool PsjGFhPJSse = true;
    double odUuWQ = 399830.39281523303;
    int cbkqzSxcrADOo = -1091494485;
    bool CFwOsvQhFXnNXLQ = true;
    bool vcIblUcvzTVVXF = false;

    if (VHQRkcgWKezyN <= 399830.39281523303) {
        for (int qAXiCMopH = 2096965622; qAXiCMopH > 0; qAXiCMopH--) {
            CFwOsvQhFXnNXLQ = ! PsjGFhPJSse;
        }
    }

    if (odUuWQ > 399830.39281523303) {
        for (int kKjikIJrHTQmvL = 1605442721; kKjikIJrHTQmvL > 0; kKjikIJrHTQmvL--) {
            vcIblUcvzTVVXF = CFwOsvQhFXnNXLQ;
            cbkqzSxcrADOo = cbkqzSxcrADOo;
            vcIblUcvzTVVXF = vcIblUcvzTVVXF;
            cbkqzSxcrADOo /= cbkqzSxcrADOo;
            vcIblUcvzTVVXF = CFwOsvQhFXnNXLQ;
        }
    }

    if (vcIblUcvzTVVXF == true) {
        for (int WPSMH = 588263695; WPSMH > 0; WPSMH--) {
            vcIblUcvzTVVXF = PsjGFhPJSse;
            PsjGFhPJSse = ! vcIblUcvzTVVXF;
            vcIblUcvzTVVXF = ! vcIblUcvzTVVXF;
        }
    }

    return odUuWQ;
}

int uoXOCNHVYA::LsuaJS(int GKbGaNHOnlot, string rofoIYlZ, double JCCxHnXY, string aJSQnPedK)
{
    bool XlkneRieTo = true;
    bool ZYFobnJKXPzkQQE = true;
    bool lOfpEYxD = true;
    int xyPqbzhBnF = 1952590314;
    bool YrhrCYYovePE = true;
    string FXlerpoWUlx = string("jXqyTjtwTEZzDltkiAWLakLYXmWxfvlVBTVIonEDuTAxFdwnHqGfrlaTzDZDYgUXjsNRWQsWrQsEuMgBLCyTpJtqfIatDMqXEFdnwJxKKRJoRWuafmlBSdQGYU");

    if (lOfpEYxD == true) {
        for (int KWKcKAXNUZY = 257122711; KWKcKAXNUZY > 0; KWKcKAXNUZY--) {
            aJSQnPedK = rofoIYlZ;
            YrhrCYYovePE = ! lOfpEYxD;
            aJSQnPedK += aJSQnPedK;
        }
    }

    for (int hXXRja = 1907153787; hXXRja > 0; hXXRja--) {
        JCCxHnXY /= JCCxHnXY;
    }

    for (int jCLTpUdxYEBbvC = 1016180508; jCLTpUdxYEBbvC > 0; jCLTpUdxYEBbvC--) {
        xyPqbzhBnF *= GKbGaNHOnlot;
        XlkneRieTo = YrhrCYYovePE;
        aJSQnPedK += rofoIYlZ;
    }

    for (int njGITfdQPu = 810302902; njGITfdQPu > 0; njGITfdQPu--) {
        aJSQnPedK = aJSQnPedK;
        YrhrCYYovePE = YrhrCYYovePE;
        aJSQnPedK += FXlerpoWUlx;
    }

    return xyPqbzhBnF;
}

string uoXOCNHVYA::uTEUoixwnXLPK(bool pjMrtENmeFNJopxK, string txjfilEHnqHHs, int fVlYQILxQRn, double oVYqMOVnlWnEKfCu)
{
    string gtHvr = string("rHheDjxXlAfRhysJNqssBnUfFjlWensUXd");
    string prIAKJIJzPL = string("MxDvTQfpIUIiJIcTZsqjNmAcXpZxwFjubZIfMxekXzpndWQuYJPehaCWmwlDSyIhnnSqqQsqgMJEuGwOWtsmSLMrzLmGEgDRzqUvtBxpEexJZtdGdtStFxAmpoWSYdiJGYFGlVRuEDtzpCUEociDpkWLnAJzUrgIWemZshhMLxxUgfCFbvPgRwApeeoqjNWXgqRhSNBAnfBLXSvddNYOakyDAdnMFyXDrBb");
    int iiURBwvQFfeADY = 1116988266;
    string YbzWAllQGRTOp = string("eJfluDAMroqhCZaIrpFNzAUeukuQWbhimURilndRQbAWuboOiknuSjihcKDliYrKEjJxiysRSUlDOeJERVmmmLBzFJadyTdIMjjqzqFIhXCAqIElMmWQSLtLZHICyPGxXaaZwEoSlTnKUvsHnISVyKhpEgZTpIIkYGGwJJYGKisieoNNtlYLlxegzkEM");
    int InSbFzwVhtiS = -326057049;
    double uFfoIVgF = -747366.9288714167;
    string jRFEUE = string("abDykEiLQiSfUcWrJoUbegHjzIaytolXfKepSKOrwrEVtYbFKqONvNOdJ");

    for (int KdLSY = 1044171167; KdLSY > 0; KdLSY--) {
        gtHvr = prIAKJIJzPL;
        iiURBwvQFfeADY *= fVlYQILxQRn;
        uFfoIVgF = uFfoIVgF;
        jRFEUE += txjfilEHnqHHs;
    }

    for (int zhmrBJMk = 33896240; zhmrBJMk > 0; zhmrBJMk--) {
        txjfilEHnqHHs = prIAKJIJzPL;
        uFfoIVgF *= oVYqMOVnlWnEKfCu;
        uFfoIVgF /= oVYqMOVnlWnEKfCu;
        jRFEUE = prIAKJIJzPL;
    }

    for (int vPJjqQKH = 614845643; vPJjqQKH > 0; vPJjqQKH--) {
        YbzWAllQGRTOp = gtHvr;
        prIAKJIJzPL = YbzWAllQGRTOp;
    }

    for (int mlUHEUfptANkl = 466924610; mlUHEUfptANkl > 0; mlUHEUfptANkl--) {
        oVYqMOVnlWnEKfCu += uFfoIVgF;
        txjfilEHnqHHs = prIAKJIJzPL;
        InSbFzwVhtiS += InSbFzwVhtiS;
    }

    for (int iArTIUZU = 802101585; iArTIUZU > 0; iArTIUZU--) {
        fVlYQILxQRn += InSbFzwVhtiS;
        InSbFzwVhtiS -= fVlYQILxQRn;
        oVYqMOVnlWnEKfCu /= uFfoIVgF;
        fVlYQILxQRn *= fVlYQILxQRn;
    }

    for (int vacPfLPboGuGP = 1448861653; vacPfLPboGuGP > 0; vacPfLPboGuGP--) {
        YbzWAllQGRTOp += YbzWAllQGRTOp;
        InSbFzwVhtiS = fVlYQILxQRn;
    }

    return jRFEUE;
}

void uoXOCNHVYA::qYQBgwBU(double sbrzMTtEg, double PaSHL)
{
    string CMzELE = string("anvEnrGqNOAbhbVnBlDtkxLZAforRHzJtJHpzYpFApQTyrLaMKodXbbDPoRUkRDrTmhYcKRVpKfwZUqoPATpvHR");
    int dgHnEk = -1379326876;
    string UpxEvkJlUdYE = string("umzJJVMQPWdtqlbbOiniSDnmXBblDOwCMspFSesnTsLeJmfCZkLpjuNzeSzMkXwnlUYlGYBXdaJXfBkSQbIZSDQTiwScUDlIThNJYtIWMZmLAcgyLEVRajmFRBOehGpjlfWmbenoBIpxnkVKYvKLdTWQlCNLLvhxEHlqxiDyvDtMbRqPggFusRbwSOxiO");
    double gDJAIXJ = -694952.844187804;
    bool CgVCaQh = true;
    int PzIayqIiKyeY = -1282467109;
    double hLvFIPmFSfcLEIQq = 174257.56649679987;
    int HicQJjozOCDc = 1872551511;
    bool PwfSTBCBPWr = true;

    for (int DySzqcLSprsmT = 931239621; DySzqcLSprsmT > 0; DySzqcLSprsmT--) {
        PwfSTBCBPWr = ! PwfSTBCBPWr;
    }

    for (int WQLCZeA = 1689603605; WQLCZeA > 0; WQLCZeA--) {
        continue;
    }
}

int uoXOCNHVYA::LzYjrbkSzejVa()
{
    bool BTCzFALle = false;

    if (BTCzFALle != false) {
        for (int lPCedDgdtCRea = 1216609357; lPCedDgdtCRea > 0; lPCedDgdtCRea--) {
            BTCzFALle = BTCzFALle;
            BTCzFALle = ! BTCzFALle;
            BTCzFALle = ! BTCzFALle;
            BTCzFALle = BTCzFALle;
        }
    }

    return 1523238006;
}

void uoXOCNHVYA::XIHisP(int mFxWURwNtcFg, int kFLDTfp, string dalCIV, double YMTcVMCQMPLcIU)
{
    string ZdnZVfUMzOJZzbki = string("ZfkOkwsXufRbThWVshVkMzxzSgaCCizNElGuLHbhzTFmVnauNHDjqYCdbsHYKQw");

    for (int QjnKhszLOzKCsisG = 1328960868; QjnKhszLOzKCsisG > 0; QjnKhszLOzKCsisG--) {
        mFxWURwNtcFg /= kFLDTfp;
        kFLDTfp /= kFLDTfp;
    }

    for (int HoTuqdRshwGxvzBv = 1749304686; HoTuqdRshwGxvzBv > 0; HoTuqdRshwGxvzBv--) {
        continue;
    }

    for (int TxizMsfuSJfe = 12791529; TxizMsfuSJfe > 0; TxizMsfuSJfe--) {
        ZdnZVfUMzOJZzbki += ZdnZVfUMzOJZzbki;
        ZdnZVfUMzOJZzbki += dalCIV;
        dalCIV += dalCIV;
        dalCIV = ZdnZVfUMzOJZzbki;
    }

    for (int MyhENOolyogiS = 328116823; MyhENOolyogiS > 0; MyhENOolyogiS--) {
        dalCIV += ZdnZVfUMzOJZzbki;
    }

    for (int odPSLapgYHCm = 1660585698; odPSLapgYHCm > 0; odPSLapgYHCm--) {
        kFLDTfp *= kFLDTfp;
    }

    if (ZdnZVfUMzOJZzbki < string("ZfkOkwsXufRbThWVshVkMzxzSgaCCizNElGuLHbhzTFmVnauNHDjqYCdbsHYKQw")) {
        for (int qiXNY = 766172954; qiXNY > 0; qiXNY--) {
            continue;
        }
    }

    for (int EOTMRlpLc = 1765523005; EOTMRlpLc > 0; EOTMRlpLc--) {
        mFxWURwNtcFg /= kFLDTfp;
    }
}

int uoXOCNHVYA::XmBkX(int ukhXIzyN, bool adZtHCaUdVxXz, int HFmlfL, double xrQPRtIEkvJedjml)
{
    double dOSLUyUoc = 261292.61916282543;
    bool vMgHoWuwfU = false;
    double dhNLohaovzCbB = -787741.1509261559;
    bool lnFbDj = false;
    double bWIVTcvF = 359702.7057581506;
    int tBUdZgFEd = 1964168576;
    double iehHvCOFxK = -885295.5921777048;
    string cCOadcH = string("YTnwhefrLsJdFeCsAdtosoqJbkcxKlvCBxalJFRXTtSwerQVWhaoGGFIbKPaqbPQjBollFGDQgovQqxVoMDMrPuSdWEfCsWaGoUQYqYGCLLTHjQjcnHnkxUNoAqRQvlFqMIGaMbMKvAmmOUZYDMSfLYvAGRMbLshLQBuG");

    if (ukhXIzyN > 1037925024) {
        for (int DoCoKHhEAkm = 733351301; DoCoKHhEAkm > 0; DoCoKHhEAkm--) {
            vMgHoWuwfU = ! adZtHCaUdVxXz;
            iehHvCOFxK += dhNLohaovzCbB;
            tBUdZgFEd += tBUdZgFEd;
        }
    }

    if (dhNLohaovzCbB == 359702.7057581506) {
        for (int iAXcqvfcOoGSm = 1574469253; iAXcqvfcOoGSm > 0; iAXcqvfcOoGSm--) {
            tBUdZgFEd = HFmlfL;
            adZtHCaUdVxXz = ! vMgHoWuwfU;
        }
    }

    for (int EZWxl = 628793063; EZWxl > 0; EZWxl--) {
        tBUdZgFEd *= ukhXIzyN;
        dOSLUyUoc -= dOSLUyUoc;
        dOSLUyUoc += dhNLohaovzCbB;
        iehHvCOFxK /= xrQPRtIEkvJedjml;
    }

    for (int AokdaOup = 219969555; AokdaOup > 0; AokdaOup--) {
        HFmlfL *= ukhXIzyN;
    }

    for (int vrYpOsJSbce = 910107528; vrYpOsJSbce > 0; vrYpOsJSbce--) {
        xrQPRtIEkvJedjml = bWIVTcvF;
        bWIVTcvF *= iehHvCOFxK;
    }

    if (bWIVTcvF > -787741.1509261559) {
        for (int sGJToVEgWHpQN = 1514834999; sGJToVEgWHpQN > 0; sGJToVEgWHpQN--) {
            continue;
        }
    }

    return tBUdZgFEd;
}

string uoXOCNHVYA::pqGvroyVq(int srqudTQQ)
{
    double DMtrVqqcbvEBz = 979717.5779698233;
    string HblnucKUFwww = string("yTGtCqaqvmegzjFFLKjUquDqEkPGZwAtkBKBHZnMCQfBqoaYTwRHBIbJpGNTXQNXVxDeKJPOPzohhyfukAtJueuWcdIXZSFFTqrujecEbgGGjJAXpCZsxCrzSJNvWtzHvUPmafqRcHATuCjCdoeaFUnhRWlPlzBitwXhs");
    bool mwtjWlZhZMrZkNxu = false;
    double gZczVWQooZLAlwB = -349436.6071142457;
    double shLgzTfoZ = 523298.05762832554;
    int mRztvLme = 1035967677;
    bool nTZTWZNMCq = false;
    double YSxhuiHwibdpDs = 511767.16703956353;
    double iSEyMHR = -794573.5308795518;
    int HURFqbDysNHj = -1236907937;

    for (int zQrWZbaMaO = 1408076272; zQrWZbaMaO > 0; zQrWZbaMaO--) {
        gZczVWQooZLAlwB += DMtrVqqcbvEBz;
        gZczVWQooZLAlwB *= shLgzTfoZ;
        shLgzTfoZ += DMtrVqqcbvEBz;
    }

    for (int DWVQjBuHtSexO = 1398233625; DWVQjBuHtSexO > 0; DWVQjBuHtSexO--) {
        mwtjWlZhZMrZkNxu = nTZTWZNMCq;
        gZczVWQooZLAlwB += shLgzTfoZ;
        YSxhuiHwibdpDs *= YSxhuiHwibdpDs;
        HURFqbDysNHj = srqudTQQ;
    }

    return HblnucKUFwww;
}

string uoXOCNHVYA::QzlojFBJ(int hwPdnXFPs, string JCEwPAi)
{
    int imKtxwtDXwCTl = -856460155;
    double jNzXnItdW = -262030.9027811904;
    int jKPQhGGWa = -801405785;
    bool IEYYLqovpNnQabV = true;
    int dkVxeSDnRrHWQQ = 1377870261;

    for (int yJYlTyHGsEiu = 105698600; yJYlTyHGsEiu > 0; yJYlTyHGsEiu--) {
        jKPQhGGWa = imKtxwtDXwCTl;
        jKPQhGGWa -= dkVxeSDnRrHWQQ;
    }

    for (int eIURKF = 2115552936; eIURKF > 0; eIURKF--) {
        imKtxwtDXwCTl -= imKtxwtDXwCTl;
        jKPQhGGWa *= dkVxeSDnRrHWQQ;
        jNzXnItdW += jNzXnItdW;
        hwPdnXFPs -= imKtxwtDXwCTl;
    }

    for (int UCixKDQCVCsvjLBH = 393967629; UCixKDQCVCsvjLBH > 0; UCixKDQCVCsvjLBH--) {
        dkVxeSDnRrHWQQ += dkVxeSDnRrHWQQ;
        jKPQhGGWa *= dkVxeSDnRrHWQQ;
        hwPdnXFPs += dkVxeSDnRrHWQQ;
        hwPdnXFPs /= hwPdnXFPs;
    }

    return JCEwPAi;
}

uoXOCNHVYA::uoXOCNHVYA()
{
    this->jMbjWYj(-162542.60610724133, 2143438977, true, string("LAKBRxRLzyMIxqYoKREaDQqneFPqoQwZYEBGTVhIaZTIJVbOqgzWeMfCEDPVPymofSHWvnCaaaZnSHvYiHvgVsHoIUSwDGZwagZuXbrZGVJERgyNtEdkynQqmclPvEaivlFkhHVntcbnruLGxCsyMPxJdUdPEUwEybvYvHGXUKIKzwMWLvAAGTnJZdjUsNhLvClykUOZSKVGHVQTPpEFYVovJQXZfoaocIlDeXxlFtx"), -1441700914);
    this->kTiDRwvpisiU(string("QPdlouNtITlmZrDncgCsKmVWxCqVtqgjedMgRmWwKOrHwYohsfslEwSepSRqrqImsnGZFZMZcQYzmSHCstbvpJiwTGTuZtebssTBjYlRjfoLJpmRuqjzVRrTCoduJlFtvxy"), 294436.5996958738, -1966172927);
    this->HJYhxTl(string("LuwoCGjWRyCdEBSNQEZwoKNLUlNPzePyapVYTJzjqoeupoVLXAeuxdZoVUAWTvXNGYtfdgPIZMQbGiDyOxFtnmMwqroyhLXIaizBXAUvbyFTRnclyfkRCywZGAqlqTJKfuenyiOUvdmtidVUrkymoYQMXhvwnJPz"), true, 140728.97425859715, false, string("xfkMqtpmlRpEHaOlEHFTdHAqwjjiWIWxgtDhDtnABzEoJRtFDQcSxKOHvTZfEPUoHKFAjDipCwywCpejzjKIFXDcFshNhDtLmNRsHpOpBTnMmHTLDFTcRabAALnrwvrEUnxaKZOOnHGqSTRXKuNMXJZqCZiUmQQCgxPdjmPKEgHmtFRYUaK"));
    this->eOhZfpw(string("kTZSPuxjiLlrpfCvXfeOVpLlQLCmBEYHcPWrvrjdMOyODyKFmQjnWhEpJgfZxHxAKKKxNoz"), -673627.2569471138, 1354579854, 894730.6511502125);
    this->uxfTUnLuyG(string("TiMHOiMTTbQmhLoSEcgJjDYphmqAzQRopoFCPpOpTOBzKeDFDsIBmNzeKVHZIvebiRhmcwMbNGnBLtQlZcYOWJplJXUdhjWthaYRmCZJcYtePoMwujAlB"), 160274.5289151235);
    this->nnruggZ();
    this->UojLRo(false, string("NstZH"), -629649.221126304, 458255.7077237853, -810885.9283678101);
    this->DWgohqTHiCkQF();
    this->LsuaJS(856553135, string("aweKDotqutzHTkRUKQrTvMZCmthoYWYwbxrfydrXXiLHzHiKBskaseBNTBwGLGLoOHb"), 38118.84010861544, string("KbPlkBdalmqITZUWFDmkTjjAhfsqTZJrzpXXevQxXLTYcUqsiGAbJwdQhbTwQKbzuWhmmaskoXXoGWDbpIHazCWnuimTyvduQneYAZnuaJfKNOnIWWaYezQPgXdqIXelfuSUuinepVTlYgPrbdiWTdovcZSZdCTKxAaOBWhsKcFzeiChSI"));
    this->uTEUoixwnXLPK(true, string("kyRIhoaljZSmoXcIGKcXUYWQMJjBmxOngsemcUkdTCeKMfVhlGosfHHRoAJOYxzNMTgZYAALaiUwkqNZnOnXuMNEYRZycBxnooJXTqtxCxiHYiZPzFMy"), -334738881, 168732.98413146246);
    this->qYQBgwBU(619633.9320778268, 322783.35638989974);
    this->LzYjrbkSzejVa();
    this->XIHisP(-1559640646, -1863972993, string("cLtnvKdNRDJYbPeVFkASASEGRYuHEGVbNsuKJYdfVospzfZEfldoebmmvKdmYNTsAAUcqtwLTlwmDslnYRBfcsIWpoxQKUtEsGTGulotxbWhclPhtxNkWwSrvZKUcbBHogGrqRMscPCewUhpVIKCnxrxVG"), -902019.4173156619);
    this->XmBkX(-622946803, false, 1037925024, -451102.6820778164);
    this->pqGvroyVq(-572689652);
    this->QzlojFBJ(-321635742, string("uHSpebRhIuxvJGlVmzPgKTNqxCpgozHlyMsAJzmLpEdvtGuLrsxhxrfGRRgldhxmQCKGdQqqwKwtpjOzFUIMNSbsLEDbmlwiaRvOUiKj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ISneIEju
{
public:
    bool vnsqbXALLzzl;
    double OrTmHMmuom;
    bool JNhySQzRuhHlDyTu;
    double XLGyl;
    string lLVNjitUanrTKVMN;

    ISneIEju();
    double qvPnRliYjimwN(string RumzJnpWO, int ZDHTuGJh);
protected:
    bool eKGgbnzw;
    string RxmlzzfiOgSE;

    string USYWmOULBxh();
    void PZjJVWbm(bool nSEVocuM, string hkhvmRmjtiiNFnMp, bool wxsznm, double xmjNRuRw, bool eshEQDgaq);
    double NsTAE();
    int BtFBCYPlowfXBfnF();
private:
    string LkDHxv;
    double pfSsEmp;
    bool ozrhAqU;
    string RJVuIRCD;

    string SVckzJkGqetBn(string PlMfXtwJB);
    string lNeSH(string WSLVVpEkTISIOVXC, bool zLLSNBGn, double OfRnReXscsmYDpK);
    void uCNhfcq(bool XEXYaCBrJjMEv, int XACwgefPIml, string lcCMjGZrJK, double WxaLrGWms, double PXccpXoI);
    void dxyQgbwWlNtfZ(bool jmWTYsdOOP);
    string eMqOf(int FMPQFtRHlEU, bool ioKJdTLUYBcnv, bool axKUukQlsUQvr, double YiqhArH);
    void DplRz(bool IZgHjZz, bool brllfRFUQbXwN);
    int wjbNi(double yBdQTQh, int KatGaawTidakVzt, double yaYvm);
};

double ISneIEju::qvPnRliYjimwN(string RumzJnpWO, int ZDHTuGJh)
{
    int RprPYwzUWWxcUDX = 1990247409;
    double tyTQTXqLnaTE = -351379.47613503964;
    int PjZyBZQXXvsGIv = -1439923300;
    bool FaAlywWm = true;
    string gtuedNCNPYsbveeG = string("yATbLGXinzNClpzdSGsABFZPFbyjoQkLmGPcqOCPhknCXunvFzqTwrnkMSZsxwULSsjrjKkCotEvndOnBtsRzvDtdXuLvYPDqjNUQnumwsTWRDelSvIvsBpwOFMFbeSTQestcHYbAuFgKjMPJZVyoAjuHYLXXjLGwPSvuNBrVal");
    int NcaAEkqngZdqtp = 283690540;
    bool eUrJIT = true;
    string eYypJjHm = string("gZhXfNEEAgAQcrgzkmpTMgWBglEGwXMqAPHkGgPRqnfhUNUvqqjPAojZISOgzJMvWJlXxEUYfpkEUarvAYiYHhJtnsTRhSMQcaquiNtzIiGQWTmNXgDlHcebpdcBvpwgGrgIQjQHWjbQbukxTfHcbHWrMfyHPyeSIRfbOTmPUvdWDJoEfvuKiqNUljhmznwcmzfGwVKgROCZpWxHGFXtoHGuxwRlzmiugnVQMPRZFVLhZmRuPDLU");
    double KVkhfgPgDBGJ = 967079.3441081146;
    double DDLeZxQunlE = -81932.429758003;

    for (int iEtcEGBUJHLVsaua = 1994641828; iEtcEGBUJHLVsaua > 0; iEtcEGBUJHLVsaua--) {
        continue;
    }

    for (int LItKD = 1826839588; LItKD > 0; LItKD--) {
        PjZyBZQXXvsGIv /= PjZyBZQXXvsGIv;
        RprPYwzUWWxcUDX /= ZDHTuGJh;
    }

    return DDLeZxQunlE;
}

string ISneIEju::USYWmOULBxh()
{
    string fntOjUOfQyQAmPF = string("njEvrbBBYegntJVnqcCFrDnqlITyjghjGgNiJZdzWTGZTBULmKIqnBcfrmNOzXfoTifCQBKTjrpBKXrZpYdvBebiHpRCutRXWKvkoMCYuepMvzkLblXdUgDroBqALKxJJDlMLIQMboSXLpqzRYDaSiVpowVUgEyPFMwASkKhQBFtTQHhXRTbSaPjlxicaufLmUGNcHlyCiHZEhaVisybReTuqxDQRHkacvObSQkEbhllBVW");
    bool mSQIYCK = false;

    for (int rMedbSHPcCAfq = 1725406870; rMedbSHPcCAfq > 0; rMedbSHPcCAfq--) {
        fntOjUOfQyQAmPF = fntOjUOfQyQAmPF;
    }

    for (int dnTwyaXPPhLdL = 122430501; dnTwyaXPPhLdL > 0; dnTwyaXPPhLdL--) {
        mSQIYCK = ! mSQIYCK;
        fntOjUOfQyQAmPF = fntOjUOfQyQAmPF;
        fntOjUOfQyQAmPF = fntOjUOfQyQAmPF;
        fntOjUOfQyQAmPF += fntOjUOfQyQAmPF;
        fntOjUOfQyQAmPF = fntOjUOfQyQAmPF;
        fntOjUOfQyQAmPF += fntOjUOfQyQAmPF;
        fntOjUOfQyQAmPF = fntOjUOfQyQAmPF;
    }

    return fntOjUOfQyQAmPF;
}

void ISneIEju::PZjJVWbm(bool nSEVocuM, string hkhvmRmjtiiNFnMp, bool wxsznm, double xmjNRuRw, bool eshEQDgaq)
{
    bool BwKVDFptDnAmy = false;

    for (int HrxmZ = 1811366764; HrxmZ > 0; HrxmZ--) {
        xmjNRuRw /= xmjNRuRw;
        eshEQDgaq = ! nSEVocuM;
    }
}

double ISneIEju::NsTAE()
{
    bool YAtlXA = true;
    string fAhLOmXDUIvdvAO = string("JiOHmNRodrUaTPMgZyoDMdnwEYtzglGkywGHxoGQ");
    string DompXC = string("a");
    bool wywXhAelgEElKRa = true;
    bool Jujxepp = true;
    double IUhMHQ = -176480.43104959268;
    string cvMPdUxJ = string("LgcltMYCkzQNQoPyaklmkoYrXcSwoxFKyBaDOirejxqGIVGqqQELATJbHRYTstWmMtotoDcqm");
    double oOIvDiQhzxtV = -966647.0238929803;

    for (int DqbXfQWumDXClQ = 1010664420; DqbXfQWumDXClQ > 0; DqbXfQWumDXClQ--) {
        continue;
    }

    if (wywXhAelgEElKRa != true) {
        for (int lWGrJ = 2108730223; lWGrJ > 0; lWGrJ--) {
            continue;
        }
    }

    for (int enJHpnYtvqVP = 1622711211; enJHpnYtvqVP > 0; enJHpnYtvqVP--) {
        DompXC += DompXC;
    }

    return oOIvDiQhzxtV;
}

int ISneIEju::BtFBCYPlowfXBfnF()
{
    int znaQiQf = 754052162;
    bool bTXTZlFNS = true;
    int oBXEfJvDDj = -1829227970;
    int VqPHckAON = -996144408;
    string kcwCUmRaW = string("BTMirNwRSkHgzluTUSXUEORWijCOOrv");
    bool LrROVUDGarKzLUb = false;
    bool GcLsIGifDTYDz = false;
    double iRGlLdwsh = 893445.217884474;

    for (int qEPQXt = 1187827512; qEPQXt > 0; qEPQXt--) {
        bTXTZlFNS = ! LrROVUDGarKzLUb;
        oBXEfJvDDj /= znaQiQf;
        VqPHckAON /= VqPHckAON;
    }

    return VqPHckAON;
}

string ISneIEju::SVckzJkGqetBn(string PlMfXtwJB)
{
    string VzTLSX = string("iLYHSwfQPhduwpEvJHdOwKWgSXnrMLEKNPLZOgBkTegjmFUCFfPFgrtXrahIdMimBtyQWXdkxPyvAv");
    bool RbEjIRPB = true;
    string aMBQJAYWtdh = string("vNoFnPgrkYhuVQaDpgEfxJoHKekenQf");
    bool JThkZZbblXfTilu = true;
    double MdsJCUC = 172591.6265943888;
    int drIJIMZhXMwOuQ = -1197791095;
    bool StJizfyhEAdC = false;

    for (int zImHIvRv = 1466440803; zImHIvRv > 0; zImHIvRv--) {
        PlMfXtwJB += VzTLSX;
        VzTLSX = aMBQJAYWtdh;
    }

    if (aMBQJAYWtdh == string("vNoFnPgrkYhuVQaDpgEfxJoHKekenQf")) {
        for (int lGcXUL = 1111913264; lGcXUL > 0; lGcXUL--) {
            continue;
        }
    }

    if (MdsJCUC <= 172591.6265943888) {
        for (int CQDPwaT = 1310070430; CQDPwaT > 0; CQDPwaT--) {
            continue;
        }
    }

    return aMBQJAYWtdh;
}

string ISneIEju::lNeSH(string WSLVVpEkTISIOVXC, bool zLLSNBGn, double OfRnReXscsmYDpK)
{
    string emEqoAKLsUqY = string("yZtTfPTEjuqoOiTJyusfzkOLPPinvwbMCveyuCuRtzjmYAXFhphIaaoAdSXyHKQJuEVxTquefaWGrmkVBMEgYOPHiZ");
    double AmCrbGaxOYuoh = -949450.488040356;
    int OjOLjRieAQpk = 1635012870;
    bool LzNPMZCD = true;
    int rKlwLg = -956287094;
    int YYhDhcIhZznqopcT = 1523094093;
    bool CuYiHkYJ = false;
    int XEKmUvIJcR = 1863124688;

    return emEqoAKLsUqY;
}

void ISneIEju::uCNhfcq(bool XEXYaCBrJjMEv, int XACwgefPIml, string lcCMjGZrJK, double WxaLrGWms, double PXccpXoI)
{
    string xIcJGrUMxVeyzRo = string("OXHNoKvqWMQnMhuSyREkbyEjKrMqUzQPdTyGatZojNmcWulGNUGwNwnuHcTJyXUPOCUatzNrhxRYlGnktJvUNmCpTNcfEHTUHjkmFscIecJKxSnWMpilVXZcTXWAKpPhRtwSqbbCPfZUlMkJffJOniDWiIYaUAISNNJktrSnWHjYADBQpAThXXrvSOdCKkUxEiBiYIeUzYZGdeKUXMziImJpsDwEzpEUrfjiudYMsbuPOrdZ");
    string NMZKTmIJmHzxrG = string("SgcgaYoOjz");
    double UaIOEvLEb = -69790.0215761316;
    int XguRihspaUEnV = -191025113;
    int wAgNuzJeqf = 1557799962;
    string JaBov = string("EapsoPwRYvVzFaAcOKtvgbUqsZKWKyRlkpapFYbjzjTNHunCmWzqJqLnzaigLEuGirlaiBjgSiQKcXDeCpXGvEFfGFZmbHPcnwQmyLvSEbvvkxEhycPHhZeBDOKiEAptdsjdFlmozpjqHagmfOjveeRYrDxGKWTsDbOvTrwYnFoncGSOWFQQHUjhGiMqcrMrkZjWzAmZtlVkNLwVpqfQSSTwmlClRcxcyEvDDXcBLjPHKagOBxSmFVAfULIr");
    string qbJWyTMdrB = string("WjhripVRNQHSPYfdNFFCwxqHtGB");

    for (int wHPQb = 1323042080; wHPQb > 0; wHPQb--) {
        WxaLrGWms /= WxaLrGWms;
        wAgNuzJeqf /= XACwgefPIml;
        qbJWyTMdrB += xIcJGrUMxVeyzRo;
    }

    for (int YDiBgVXbYhXc = 1835814619; YDiBgVXbYhXc > 0; YDiBgVXbYhXc--) {
        qbJWyTMdrB = JaBov;
        XguRihspaUEnV -= XguRihspaUEnV;
    }

    if (xIcJGrUMxVeyzRo >= string("WjhripVRNQHSPYfdNFFCwxqHtGB")) {
        for (int xAIuMnloOtsA = 575960597; xAIuMnloOtsA > 0; xAIuMnloOtsA--) {
            PXccpXoI += WxaLrGWms;
        }
    }

    if (qbJWyTMdrB != string("WjhripVRNQHSPYfdNFFCwxqHtGB")) {
        for (int snxLoMAGjqIA = 2124313941; snxLoMAGjqIA > 0; snxLoMAGjqIA--) {
            PXccpXoI += WxaLrGWms;
            JaBov += lcCMjGZrJK;
        }
    }

    if (lcCMjGZrJK < string("EapsoPwRYvVzFaAcOKtvgbUqsZKWKyRlkpapFYbjzjTNHunCmWzqJqLnzaigLEuGirlaiBjgSiQKcXDeCpXGvEFfGFZmbHPcnwQmyLvSEbvvkxEhycPHhZeBDOKiEAptdsjdFlmozpjqHagmfOjveeRYrDxGKWTsDbOvTrwYnFoncGSOWFQQHUjhGiMqcrMrkZjWzAmZtlVkNLwVpqfQSSTwmlClRcxcyEvDDXcBLjPHKagOBxSmFVAfULIr")) {
        for (int iyAThIJbRxmELHRJ = 44964442; iyAThIJbRxmELHRJ > 0; iyAThIJbRxmELHRJ--) {
            XACwgefPIml *= XACwgefPIml;
        }
    }

    if (qbJWyTMdrB >= string("OXHNoKvqWMQnMhuSyREkbyEjKrMqUzQPdTyGatZojNmcWulGNUGwNwnuHcTJyXUPOCUatzNrhxRYlGnktJvUNmCpTNcfEHTUHjkmFscIecJKxSnWMpilVXZcTXWAKpPhRtwSqbbCPfZUlMkJffJOniDWiIYaUAISNNJktrSnWHjYADBQpAThXXrvSOdCKkUxEiBiYIeUzYZGdeKUXMziImJpsDwEzpEUrfjiudYMsbuPOrdZ")) {
        for (int aLkRU = 1419684737; aLkRU > 0; aLkRU--) {
            continue;
        }
    }

    for (int KvZphKUy = 38268795; KvZphKUy > 0; KvZphKUy--) {
        continue;
    }
}

void ISneIEju::dxyQgbwWlNtfZ(bool jmWTYsdOOP)
{
    int kfRrBtcebCdFl = -1095324387;
    bool JoeXUfOWAtxgHUZI = true;

    for (int sPPuht = 1158206228; sPPuht > 0; sPPuht--) {
        continue;
    }

    if (kfRrBtcebCdFl < -1095324387) {
        for (int jElLekBGLKNraym = 340135950; jElLekBGLKNraym > 0; jElLekBGLKNraym--) {
            continue;
        }
    }

    if (JoeXUfOWAtxgHUZI == true) {
        for (int vzmBmcvpNAA = 1128086550; vzmBmcvpNAA > 0; vzmBmcvpNAA--) {
            jmWTYsdOOP = jmWTYsdOOP;
        }
    }

    if (jmWTYsdOOP != false) {
        for (int nnaUCRAOgGTtEAHc = 2023816408; nnaUCRAOgGTtEAHc > 0; nnaUCRAOgGTtEAHc--) {
            JoeXUfOWAtxgHUZI = JoeXUfOWAtxgHUZI;
            JoeXUfOWAtxgHUZI = jmWTYsdOOP;
            jmWTYsdOOP = ! jmWTYsdOOP;
            jmWTYsdOOP = JoeXUfOWAtxgHUZI;
        }
    }

    for (int KOwdjfOcmoBveeCU = 1537866998; KOwdjfOcmoBveeCU > 0; KOwdjfOcmoBveeCU--) {
        JoeXUfOWAtxgHUZI = ! JoeXUfOWAtxgHUZI;
        jmWTYsdOOP = JoeXUfOWAtxgHUZI;
    }

    if (JoeXUfOWAtxgHUZI != false) {
        for (int ClnNieNNfgmIzr = 1178593627; ClnNieNNfgmIzr > 0; ClnNieNNfgmIzr--) {
            jmWTYsdOOP = ! JoeXUfOWAtxgHUZI;
            jmWTYsdOOP = JoeXUfOWAtxgHUZI;
            jmWTYsdOOP = jmWTYsdOOP;
            JoeXUfOWAtxgHUZI = jmWTYsdOOP;
        }
    }
}

string ISneIEju::eMqOf(int FMPQFtRHlEU, bool ioKJdTLUYBcnv, bool axKUukQlsUQvr, double YiqhArH)
{
    string rbFVeNCR = string("OxyCHsCisJDWqLtzhxWSGzPNHHbnZFSWrjzyqirEkXdvxNoYaczaCNlDFppWrDwZpthoQBSCpNEMXPsRUBgkVfuHbjZUuhaaqNzDXneqDuUZumsVukCZZzQyNNEtWlbCSsXyIPwUqxMNBEKaaEXvD");
    string tilzfKuYW = string("wsOJtoNbCOINDOMOkDUETXXKwkCesvLmgOqwCqzRKBqtyloEnSzpcJraervNBxHUSa");
    bool AyJfFfYhoYzaCZHj = true;
    string ORmTx = string("HZmawWSncICUCJavuQbIRWfERGBrdVcJSuGLWfSCMrFXMmJdZfEOSuLljIrFPXTtClbLebLrlarwSOVvEaDJvEIjEYTPJtkFnaEwrcwBkcGUXtHJeuBQTYPQXRNBRPfXdlrwIloMCxNZeWtHZELPHgLXQuAYxnkwJbGQOYYAfFUhHxQOPryZYklDWfuXU");
    bool vpmqnYF = true;
    int KooBrFLNmC = -1849858746;
    string YOPcA = string("DwcYdwRNCmAcOSXoBeipr");
    double SMkoEFusPQyRIvXh = 423466.9052133543;

    for (int AaOzjZuPgpMudam = 236260728; AaOzjZuPgpMudam > 0; AaOzjZuPgpMudam--) {
        axKUukQlsUQvr = vpmqnYF;
        ORmTx = rbFVeNCR;
        ORmTx += ORmTx;
        AyJfFfYhoYzaCZHj = vpmqnYF;
        tilzfKuYW += rbFVeNCR;
    }

    for (int GLQQQqXkfvOZHFmz = 2013325536; GLQQQqXkfvOZHFmz > 0; GLQQQqXkfvOZHFmz--) {
        vpmqnYF = axKUukQlsUQvr;
    }

    return YOPcA;
}

void ISneIEju::DplRz(bool IZgHjZz, bool brllfRFUQbXwN)
{
    string JvWfOLf = string("XiDXUEjGWGHWbeArRNOCngvGBGkinHNOMTonxnZzGQsduYWtXhDIXFAAYnHrOoAydZoEZrAYJqxHsRJlLSoTYGgKIpKrHIcNXUuRPaxKUZNRqCjpfNpXO");
    int enmmEtU = -1484150944;
    bool ZMltUBGZYucbJB = true;
    double HOauj = -659667.4476264439;
    bool ZELfzVJwCdOLz = false;
    double OUUTUctRFoRILYSC = -436728.0426124078;
    bool bRLYirG = true;
    string AnpXRJNsKidsopV = string("OVijdxid");
}

int ISneIEju::wjbNi(double yBdQTQh, int KatGaawTidakVzt, double yaYvm)
{
    string dYWbLSjLS = string("OwuVLomjdkOopBlmkzUGAxexVAWjJUMySVewMmpWhSRVJvGXErnCMVxzVNTBMoNhLZFLYBMLQClZuONTQwdYHuxjmnUsjJdyQSyVwbCPAVgnfMTBuWhrJawIZAYoaKeaYkSq");
    int RrIjTCaKukyF = -868784234;

    return RrIjTCaKukyF;
}

ISneIEju::ISneIEju()
{
    this->qvPnRliYjimwN(string("UqRWYbmdpqkooeykqFdOivbZTyB"), -1242219400);
    this->USYWmOULBxh();
    this->PZjJVWbm(false, string("GbAbqSBfIhRDecfHZOHnBJiswxeHSBTRSrbcFtJZBSEuUNtXNgIZJBGBkeHDzUUDPtqWZWUoYvCvPMhRdrSvYVQVySqJkRvdMMpqqCVlprbEaoViOvgzTtmZWuOkHFsdcqyTooLEhGIewJjMPEBEgPiqErJiLINQvAfmqpHhZyNqfYDILfkVQJhXTCvdiGXvtPeWqZXRJfBmqMEGzxgSGYDNgOVdsBBLDzrNMSORRsPQhHDSPaEEimCHBGq"), true, 478766.40776604664, true);
    this->NsTAE();
    this->BtFBCYPlowfXBfnF();
    this->SVckzJkGqetBn(string("aCVIMDxhfXlrDNPwpSKDLOl"));
    this->lNeSH(string("LJUEgRBvMMajntoffTdgYjstZzpOThTobgoWfLEVuUEOOzAfXmqcQXvQEoPfWsSatmUIJWdnrWzifYdouClwoSzExZmasQsfEYQUNjxpcZdPUzxjPlUBjjWghfvjeQoXNPFYgvptHlMbmEcxoLCIIESxQJMmeEvNaNtQAhOqlXsiTolSuJOwhooDzjUzKdRYnYVdedpUsYFSHGMiiCo"), true, -110051.79471635753);
    this->uCNhfcq(false, -942023664, string("cvBVEXMeIKPsaKwbEHUeRdlRMeWGDGEHGOyxdhkhMFGJZgEcWWoxUSZZBNvrohggXvKbXeqwVtYIPvMNjVZsGnxjgXSmsQptTdNULwBGZyRirWuDMuOEDTTUespalKNhEjKtPixsQyfGLKhxDNfBzNgXEXhByWTedADb"), 166913.229379767, 515673.93812266627);
    this->dxyQgbwWlNtfZ(false);
    this->eMqOf(744848801, true, false, 510531.55641752866);
    this->DplRz(true, false);
    this->wjbNi(539541.9850527224, -1784685662, 866963.0036142326);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vYYdAUcIvELHi
{
public:
    string yKYTin;
    double oRfVAxqxcTywI;
    bool gXmQizOH;

    vYYdAUcIvELHi();
    void wWwjOJhCN(string rZFWYR, double rMJnSPPC, string AGoXVuT, double ZFwoLScVupwvVkdO);
    void UMqQPWW(double glyaCDe, double xgPAFyfW, int MUhsGtuHKYttk, double LqkMSAIqoRZaRTvU);
protected:
    bool kbLovKuBwDeA;
    int KPzNyRHz;

    int ZiUsCBhAoYLlvu();
    int eWvdYAZsefvcSPhy();
    string DeuIqsLF(int rwgXHQCRwcTlp, int PZFmcoWIC, bool yJvIhXqQrqpIJ, int mtTcyh, bool ztUgkfmELWLCU);
    void inhtqhgiMnwsonog(string gqUNWOnXmjUVrc, int LWaTFnaqV, bool jTrnxBpfBN, int dmleaYSAYn, bool qtHSmYwyJfceH);
    bool qDtLVRYcKJeYFz(int EmHZLYJwmneT, string IMBkkmhvoWcpf, bool xujGdCjVUXdzuKRJ, bool qeLnldEljzHDUbPY);
    void TXZpiZnT(bool XnfADXFaoldxZSL, int zYlhTbXQgLiePR);
private:
    int vAnLrC;
    double zrsGYHakFIi;
    string CCsRPKYPWnVwJSp;
    int OjNiMDxRjWlNfty;

};

void vYYdAUcIvELHi::wWwjOJhCN(string rZFWYR, double rMJnSPPC, string AGoXVuT, double ZFwoLScVupwvVkdO)
{
    int xKcMdUiqxBXYMc = 940255481;
    string hixCAYmPsOiwWmry = string("WTxFnGyArxzdngjChxdnvXiijXoZoLizHToIsAkNInvAqLCZtwMfsawgqdZtITxiunrGyYxBtGNVaizHPATvxuTdUMaxGwvtsYHktyolqDjVIDChDWsfAywyhRJyRMvDAOhFGwICi");
    string XsDUNRONcQfX = string("vAvTVNIyFHEXeKnoXsMlbzmhiNaDuyeokODkHKpntksxtXljIQWaTzLaxycCsgvKAvmhAFLcneIqAgOxSabXv");
    bool oBMtfXEL = true;
    string RpinTuJLqzsOO = string("xpCcpNNTNGPgNysbjMcy");
    int OzltLfdQGAy = 622780113;
    bool uUlWOfoxBCbOi = true;
    bool CxcQoQYtNKVE = true;
    int NBqcfEaZMOrTqDB = -1360897424;
    double DuPhtYz = -237040.29060556373;

    if (hixCAYmPsOiwWmry <= string("COytqLDSfRLWQLtVvIgfVqjQkDaTeLpbUvUWlWGmVydNmJSWNgzvpkWCzOVfPzvBoALFLIgBqOduJojLgJweqXvsPiRtWhgLfjsYQKHsToiEjrWPsdfdGXtxtEXhEPCCPlbRjbNnvkTUxVhyIJWpDJhJlNKCwcuMvpkOFvyswpjWxglrDHFOhmuaOATyMzZNfXSZnr")) {
        for (int beopYrWhjDu = 108255240; beopYrWhjDu > 0; beopYrWhjDu--) {
            uUlWOfoxBCbOi = oBMtfXEL;
            uUlWOfoxBCbOi = ! CxcQoQYtNKVE;
            XsDUNRONcQfX = XsDUNRONcQfX;
        }
    }

    for (int zZXUXYA = 1218768955; zZXUXYA > 0; zZXUXYA--) {
        continue;
    }

    for (int UgElNchuL = 1489609620; UgElNchuL > 0; UgElNchuL--) {
        hixCAYmPsOiwWmry += hixCAYmPsOiwWmry;
    }

    for (int CuStixLliPtgnz = 2131018323; CuStixLliPtgnz > 0; CuStixLliPtgnz--) {
        rZFWYR += hixCAYmPsOiwWmry;
        NBqcfEaZMOrTqDB /= NBqcfEaZMOrTqDB;
    }

    for (int QddXqdXebzwG = 1619081283; QddXqdXebzwG > 0; QddXqdXebzwG--) {
        uUlWOfoxBCbOi = ! oBMtfXEL;
        CxcQoQYtNKVE = CxcQoQYtNKVE;
    }

    for (int wvsTgPkNGTpnl = 215764794; wvsTgPkNGTpnl > 0; wvsTgPkNGTpnl--) {
        continue;
    }
}

void vYYdAUcIvELHi::UMqQPWW(double glyaCDe, double xgPAFyfW, int MUhsGtuHKYttk, double LqkMSAIqoRZaRTvU)
{
    bool nhTfqHNAzgiOf = true;
    double jGNESgK = 780419.0127647261;

    if (jGNESgK <= 58550.740760651555) {
        for (int sxNEkiDxl = 1899405053; sxNEkiDxl > 0; sxNEkiDxl--) {
            xgPAFyfW /= LqkMSAIqoRZaRTvU;
            jGNESgK += xgPAFyfW;
            LqkMSAIqoRZaRTvU /= jGNESgK;
        }
    }

    for (int vjIpjI = 1743270721; vjIpjI > 0; vjIpjI--) {
        xgPAFyfW -= xgPAFyfW;
        LqkMSAIqoRZaRTvU = xgPAFyfW;
    }

    for (int oCqslzCqpRA = 635184365; oCqslzCqpRA > 0; oCqslzCqpRA--) {
        glyaCDe += LqkMSAIqoRZaRTvU;
        LqkMSAIqoRZaRTvU -= xgPAFyfW;
        glyaCDe /= LqkMSAIqoRZaRTvU;
    }
}

int vYYdAUcIvELHi::ZiUsCBhAoYLlvu()
{
    double TzoVQLnQBy = 920113.194958484;
    double mregUxHyax = -889155.6041356258;
    bool UQQyYbj = false;
    bool WMWaOtpnfIsgSwi = true;
    string IOdiitTM = string("sUgiMAHNbZjhTWxkItGuSYQhGNrEQmLpopwNHUPZcJmRWhqDHfMXxspNfxlcKVKOFbqPgfrjBfksnEJmhfvMSgtapHswCtVNgukcHSABMrVSirAisvikjyBVeXOvIhHacWNYiQAqHOFYXXSOWLzeUeuquLAsfEQcndRFSLTPqwoBSeucpGIryh");
    bool qlIPVCdpbLzUfE = true;
    double vJdZMCcbcPIr = 446581.88046202424;

    if (WMWaOtpnfIsgSwi == true) {
        for (int JKssgrj = 668137213; JKssgrj > 0; JKssgrj--) {
            continue;
        }
    }

    for (int BYBXKceaMXluKR = 274376791; BYBXKceaMXluKR > 0; BYBXKceaMXluKR--) {
        continue;
    }

    for (int YaZDTLReXQW = 242502478; YaZDTLReXQW > 0; YaZDTLReXQW--) {
        vJdZMCcbcPIr = TzoVQLnQBy;
    }

    for (int FYjcPpmxbvVbYQ = 1901177291; FYjcPpmxbvVbYQ > 0; FYjcPpmxbvVbYQ--) {
        TzoVQLnQBy /= mregUxHyax;
        qlIPVCdpbLzUfE = ! qlIPVCdpbLzUfE;
    }

    return -1490046944;
}

int vYYdAUcIvELHi::eWvdYAZsefvcSPhy()
{
    int DeeqhStxcH = -41374705;
    double GcjINn = -648803.6213409241;
    int vfmrtpL = 1485267293;
    int kGZoeKebKlr = 989508840;
    int fSBpvohZsdpn = -352613747;

    if (DeeqhStxcH == -41374705) {
        for (int eDayeRVZU = 1104015752; eDayeRVZU > 0; eDayeRVZU--) {
            fSBpvohZsdpn /= kGZoeKebKlr;
            kGZoeKebKlr *= fSBpvohZsdpn;
            DeeqhStxcH = DeeqhStxcH;
            fSBpvohZsdpn -= kGZoeKebKlr;
            kGZoeKebKlr *= fSBpvohZsdpn;
            vfmrtpL -= fSBpvohZsdpn;
        }
    }

    if (kGZoeKebKlr >= 1485267293) {
        for (int wEqOUvU = 1547950621; wEqOUvU > 0; wEqOUvU--) {
            fSBpvohZsdpn -= fSBpvohZsdpn;
            DeeqhStxcH += fSBpvohZsdpn;
            GcjINn = GcjINn;
            DeeqhStxcH -= DeeqhStxcH;
        }
    }

    for (int FwVubg = 1931785277; FwVubg > 0; FwVubg--) {
        GcjINn *= GcjINn;
        vfmrtpL *= fSBpvohZsdpn;
        GcjINn /= GcjINn;
        kGZoeKebKlr = fSBpvohZsdpn;
        fSBpvohZsdpn -= kGZoeKebKlr;
    }

    if (fSBpvohZsdpn >= -352613747) {
        for (int jOZMEFT = 1964973279; jOZMEFT > 0; jOZMEFT--) {
            continue;
        }
    }

    for (int gWNmf = 1870755682; gWNmf > 0; gWNmf--) {
        fSBpvohZsdpn = vfmrtpL;
        vfmrtpL *= DeeqhStxcH;
        fSBpvohZsdpn += vfmrtpL;
    }

    return fSBpvohZsdpn;
}

string vYYdAUcIvELHi::DeuIqsLF(int rwgXHQCRwcTlp, int PZFmcoWIC, bool yJvIhXqQrqpIJ, int mtTcyh, bool ztUgkfmELWLCU)
{
    int AMwPpu = -9639728;

    for (int EFWBNslGFGdoUkX = 951341432; EFWBNslGFGdoUkX > 0; EFWBNslGFGdoUkX--) {
        yJvIhXqQrqpIJ = ztUgkfmELWLCU;
        rwgXHQCRwcTlp += PZFmcoWIC;
        AMwPpu *= PZFmcoWIC;
    }

    for (int aMYlprtEEyyN = 1665667462; aMYlprtEEyyN > 0; aMYlprtEEyyN--) {
        mtTcyh /= PZFmcoWIC;
        yJvIhXqQrqpIJ = ztUgkfmELWLCU;
        mtTcyh -= AMwPpu;
    }

    for (int HDOwJnAUGlw = 593920974; HDOwJnAUGlw > 0; HDOwJnAUGlw--) {
        continue;
    }

    return string("lCHdbJGuvFDbALBnAXbJTAICNKvzFWfaNGkXXgBXbtlwOHaxRoVwWAmKOsQVaP");
}

void vYYdAUcIvELHi::inhtqhgiMnwsonog(string gqUNWOnXmjUVrc, int LWaTFnaqV, bool jTrnxBpfBN, int dmleaYSAYn, bool qtHSmYwyJfceH)
{
    bool omUbeUYnSmM = true;
    bool eEcQLnYSZ = true;
    int SYlazrKYBwf = -594799409;
    double qgeNN = 445082.2422318292;
    int HFXXTTnb = 584651499;
    string FslNXsnSt = string("fPGodskwqSAgSEkBuUbotTmtRtIlNESmzMGCxahjjKLOjAawwplhzviIdvfRxonOTAyTWtFGmCCykFQUazjYdrFepLAMfWqGfujZFInpcN");
    string GMgVTwCFDqHZVyGd = string("fQElGBUKzJaTHEvjqniIytNlVZrwihkKalrpswkrOGLYhqwaQYffjZAVSBVCOqNKbmexVhpOActUbHfyGOFZwYjHCuKy");
    double ucaILB = -960159.672857062;
    string BPUjCKEgM = string("vgwRbqguzjhWhtPMfgSMsfzKTOEmgYCSFkZuMYthZTbrRdWgTfoTzfdBBMQWPjzzRMAdmnspijrxLDnYPkumQakWmFEUTPbaGFKrIWlzqftPfALLUDKkyjeNzRNqvHUwEuxNHHsbgMKGaQzMXJLbnZZ");
    bool mjsNvzOMBxRQO = true;

    if (ucaILB <= -960159.672857062) {
        for (int yyetNzihu = 2133827387; yyetNzihu > 0; yyetNzihu--) {
            qtHSmYwyJfceH = ! qtHSmYwyJfceH;
            dmleaYSAYn *= SYlazrKYBwf;
            jTrnxBpfBN = ! jTrnxBpfBN;
        }
    }

    for (int aCFnTtFLJdOJdAqI = 1179082221; aCFnTtFLJdOJdAqI > 0; aCFnTtFLJdOJdAqI--) {
        LWaTFnaqV *= dmleaYSAYn;
        LWaTFnaqV *= HFXXTTnb;
    }
}

bool vYYdAUcIvELHi::qDtLVRYcKJeYFz(int EmHZLYJwmneT, string IMBkkmhvoWcpf, bool xujGdCjVUXdzuKRJ, bool qeLnldEljzHDUbPY)
{
    double AgyEH = -989035.4282154274;
    int hbyDcZqzXZCSSK = -1559188045;
    string NyTxpiSDU = string("kyGNRiTZxUdQpGMbklrmptlEbifhDJNubUZaPanuhBvdXzVsGBdSKhYGkFXEUPSzfmTrhQJhbTf");
    int sRWSOoeqRbIBSm = 1887875498;
    bool yVivqpCeDaYBJsQ = true;

    for (int pdLEcT = 1014069378; pdLEcT > 0; pdLEcT--) {
        hbyDcZqzXZCSSK = sRWSOoeqRbIBSm;
    }

    for (int wHUysZ = 402303000; wHUysZ > 0; wHUysZ--) {
        continue;
    }

    for (int cOWXmQGrC = 83378303; cOWXmQGrC > 0; cOWXmQGrC--) {
        continue;
    }

    for (int ConQe = 1539914480; ConQe > 0; ConQe--) {
        hbyDcZqzXZCSSK -= hbyDcZqzXZCSSK;
        yVivqpCeDaYBJsQ = xujGdCjVUXdzuKRJ;
        EmHZLYJwmneT -= EmHZLYJwmneT;
    }

    return yVivqpCeDaYBJsQ;
}

void vYYdAUcIvELHi::TXZpiZnT(bool XnfADXFaoldxZSL, int zYlhTbXQgLiePR)
{
    double tCjoKqdhSTSQ = 42355.55057770767;
    int zLmfjvTGCdo = 2072889714;
    double zaJvSJI = 276249.076885795;
    bool dTaTtP = false;
    string keVuFUhkHvwOAO = string("FTyWLXjhvIhdJiMxUDVNhSKnAwZjaqSFzOqSNsFeZZZdKzUCLjruCSIyLQxrN");

    for (int klCmFaqrBYqVcagj = 2019009494; klCmFaqrBYqVcagj > 0; klCmFaqrBYqVcagj--) {
        continue;
    }
}

vYYdAUcIvELHi::vYYdAUcIvELHi()
{
    this->wWwjOJhCN(string("COytqLDSfRLWQLtVvIgfVqjQkDaTeLpbUvUWlWGmVydNmJSWNgzvpkWCzOVfPzvBoALFLIgBqOduJojLgJweqXvsPiRtWhgLfjsYQKHsToiEjrWPsdfdGXtxtEXhEPCCPlbRjbNnvkTUxVhyIJWpDJhJlNKCwcuMvpkOFvyswpjWxglrDHFOhmuaOATyMzZNfXSZnr"), -129357.52848882855, string("BRFHseSQqXcIMTiciMAvzuuaKSfuoJXhnLloqsdmbmtuzEfyQZebcxyBJoJbbaYPxgPeqtprHUqxedpiwKbjTdPCowbFRJOUuqyyXqHMWGvKWrYhjVcqVQTYfhIEQUTwRsdVUjlkjmGImgpJdChOAKmsJVvUONBdGNpPFwxdDYIjTEkoBVVQAFeJUkihKzGXFwKSODbkHwsootlvOWlzSQzksONFFQcZcNsGesSfhSKdsdTSUjHmC"), -957992.0225240389);
    this->UMqQPWW(58550.740760651555, -555837.8580562201, -420662355, -163989.40501671244);
    this->ZiUsCBhAoYLlvu();
    this->eWvdYAZsefvcSPhy();
    this->DeuIqsLF(-1499517116, -1063014037, true, -648326581, false);
    this->inhtqhgiMnwsonog(string("UAUOvwWmbpeqojmcThIDpDQBmltrHlKuMFqVHKJSTXNUAKGnUzUNChTKMlvLTetOVoNdbQZGamIeEJYkcACwegQRAfKLcwMszRPVTntBwOIwcVWvRnPpdRDYhYUoFuyQzNzxvbZxynavuoXEHaMxfPSiVXiCFzfvezR"), -36225405, false, -770438129, true);
    this->qDtLVRYcKJeYFz(-1267108805, string("YFSiW"), true, true);
    this->TXZpiZnT(true, 310904969);
}
