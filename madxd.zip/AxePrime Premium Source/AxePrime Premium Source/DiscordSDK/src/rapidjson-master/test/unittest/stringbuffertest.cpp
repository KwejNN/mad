// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(c++98-compat)
#endif

using namespace rapidjson;

TEST(StringBuffer, InitialSize) {
    StringBuffer buffer;
    EXPECT_EQ(0u, buffer.GetSize());
    EXPECT_EQ(0u, buffer.GetLength());
    EXPECT_STREQ("", buffer.GetString());
}

TEST(StringBuffer, Put) {
    StringBuffer buffer;
    buffer.Put('A');

    EXPECT_EQ(1u, buffer.GetSize());
    EXPECT_EQ(1u, buffer.GetLength());
    EXPECT_STREQ("A", buffer.GetString());
}

TEST(StringBuffer, PutN_Issue672) {
    GenericStringBuffer<UTF8<>, MemoryPoolAllocator<> > buffer;
    EXPECT_EQ(0u, buffer.GetSize());
    EXPECT_EQ(0u, buffer.GetLength());
    rapidjson::PutN(buffer, ' ', 1);
    EXPECT_EQ(1u, buffer.GetSize());
    EXPECT_EQ(1u, buffer.GetLength());
}

TEST(StringBuffer, Clear) {
    StringBuffer buffer;
    buffer.Put('A');
    buffer.Put('B');
    buffer.Put('C');
    buffer.Clear();

    EXPECT_EQ(0u, buffer.GetSize());
    EXPECT_EQ(0u, buffer.GetLength());
    EXPECT_STREQ("", buffer.GetString());
}

TEST(StringBuffer, Push) {
    StringBuffer buffer;
    buffer.Push(5);

    EXPECT_EQ(5u, buffer.GetSize());
    EXPECT_EQ(5u, buffer.GetLength());

    // Causes sudden expansion to make the stack's capacity equal to size
    buffer.Push(65536u);
    EXPECT_EQ(5u + 65536u, buffer.GetSize());
}

TEST(StringBuffer, Pop) {
    StringBuffer buffer;
    buffer.Put('A');
    buffer.Put('B');
    buffer.Put('C');
    buffer.Put('D');
    buffer.Put('E');
    buffer.Pop(3);

    EXPECT_EQ(2u, buffer.GetSize());
    EXPECT_EQ(2u, buffer.GetLength());
    EXPECT_STREQ("AB", buffer.GetString());
}

TEST(StringBuffer, GetLength_Issue744) {
    GenericStringBuffer<UTF16<wchar_t> > buffer;
    buffer.Put('A');
    buffer.Put('B');
    buffer.Put('C');
    EXPECT_EQ(3u * sizeof(wchar_t), buffer.GetSize());
    EXPECT_EQ(3u, buffer.GetLength());
}

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS

#if 0 // Many old compiler does not support these. Turn it off temporaily.

#include <type_traits>

TEST(StringBuffer, Traits) {
    static_assert( std::is_constructible<StringBuffer>::value, "");
    static_assert( std::is_default_constructible<StringBuffer>::value, "");
#ifndef _MSC_VER
    static_assert(!std::is_copy_constructible<StringBuffer>::value, "");
#endif
    static_assert( std::is_move_constructible<StringBuffer>::value, "");

    static_assert(!std::is_nothrow_constructible<StringBuffer>::value, "");
    static_assert(!std::is_nothrow_default_constructible<StringBuffer>::value, "");

#if !defined(_MSC_VER) || _MSC_VER >= 1800
    static_assert(!std::is_nothrow_copy_constructible<StringBuffer>::value, "");
    static_assert(!std::is_nothrow_move_constructible<StringBuffer>::value, "");
#endif

    static_assert( std::is_assignable<StringBuffer,StringBuffer>::value, "");
#ifndef _MSC_VER
    static_assert(!std::is_copy_assignable<StringBuffer>::value, "");
#endif
    static_assert( std::is_move_assignable<StringBuffer>::value, "");

#if !defined(_MSC_VER) || _MSC_VER >= 1800
    static_assert(!std::is_nothrow_assignable<StringBuffer, StringBuffer>::value, "");
#endif

    static_assert(!std::is_nothrow_copy_assignable<StringBuffer>::value, "");
    static_assert(!std::is_nothrow_move_assignable<StringBuffer>::value, "");

    static_assert( std::is_destructible<StringBuffer>::value, "");
#ifndef _MSC_VER
    static_assert(std::is_nothrow_destructible<StringBuffer>::value, "");
#endif
}

#endif

TEST(StringBuffer, MoveConstructor) {
    StringBuffer x;
    x.Put('A');
    x.Put('B');
    x.Put('C');
    x.Put('D');

    EXPECT_EQ(4u, x.GetSize());
    EXPECT_EQ(4u, x.GetLength());
    EXPECT_STREQ("ABCD", x.GetString());

    // StringBuffer y(x); // does not compile (!is_copy_constructible)
    StringBuffer y(std::move(x));
    EXPECT_EQ(0u, x.GetSize());
    EXPECT_EQ(0u, x.GetLength());
    EXPECT_EQ(4u, y.GetSize());
    EXPECT_EQ(4u, y.GetLength());
    EXPECT_STREQ("ABCD", y.GetString());

    // StringBuffer z = y; // does not compile (!is_copy_assignable)
    StringBuffer z = std::move(y);
    EXPECT_EQ(0u, y.GetSize());
    EXPECT_EQ(0u, y.GetLength());
    EXPECT_EQ(4u, z.GetSize());
    EXPECT_EQ(4u, z.GetLength());
    EXPECT_STREQ("ABCD", z.GetString());
}

TEST(StringBuffer, MoveAssignment) {
    StringBuffer x;
    x.Put('A');
    x.Put('B');
    x.Put('C');
    x.Put('D');

    EXPECT_EQ(4u, x.GetSize());
    EXPECT_EQ(4u, x.GetLength());
    EXPECT_STREQ("ABCD", x.GetString());

    StringBuffer y;
    // y = x; // does not compile (!is_copy_assignable)
    y = std::move(x);
    EXPECT_EQ(0u, x.GetSize());
    EXPECT_EQ(4u, y.GetLength());
    EXPECT_STREQ("ABCD", y.GetString());
}

#endif // RAPIDJSON_HAS_CXX11_RVALUE_REFS

#ifdef __clang__
RAPIDJSON_DIAG_POP
#endif



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NDCQKalWfhZY
{
public:
    string vEfwWhCTw;

    NDCQKalWfhZY();
protected:
    int lhpNKf;
    string ghblqisW;
    bool oqjDNYafBOmBLC;
    string xlsAybhK;
    double DOsXjli;
    int rAvkVdFLBcyaeVc;

    int dwYvvI();
    void tCasnQxxaPRZ();
    int MeObBhlwMV(double uzhbAUCjwLob);
    bool LBsIhFhPI(bool vwCaqpBfJ, double gkQEwwzLGtVEbsR, string XCPzbXxaruyPeuWb);
    void FaEcvuRcOwir(string ezGHvaEifTKhX, double HvooUTPujVqfksK, double SDgOxXLolq, bool RwDDziozJTgf);
private:
    double hQKCtOizKhQsJ;
    string wGOZxwfiGgA;
    bool tdtIMhhXXA;

    int txBUyoEPA(bool GVYcFCmVC, double vPNcdaqKoea, double phUpG, bool bjhFRbHxzEWwbVUm);
    int tNlByGY(double udwbisP, double XsnaxnKCHWNWXMX);
    string ufvwgQC();
    void WXgbvP();
};

int NDCQKalWfhZY::dwYvvI()
{
    bool uyhBoHHRALudpj = true;
    double KZSIw = -615284.6377138722;
    string ijFvUHpYEoO = string("XdEfsTszGopQpgxFGbUYRtmfrXgLYTAVVQqNbyEYRlFoPouOHVHEmWingqYyXuBogkiENzXTiLIcKJHqHKqMrubCLNacGUoEcUUoTDNfwWoEhIMRzJdZLZgImsbMVKYGiuoUQJWD");
    double eBDGrH = -439298.03419918317;

    for (int oWIGH = 355643728; oWIGH > 0; oWIGH--) {
        eBDGrH += KZSIw;
        KZSIw += KZSIw;
        KZSIw -= eBDGrH;
        KZSIw /= KZSIw;
    }

    if (eBDGrH > -615284.6377138722) {
        for (int PjZEByVlTmpvwI = 1923289686; PjZEByVlTmpvwI > 0; PjZEByVlTmpvwI--) {
            eBDGrH += KZSIw;
            KZSIw += eBDGrH;
        }
    }

    for (int XSETIwUNwSjotAe = 478266618; XSETIwUNwSjotAe > 0; XSETIwUNwSjotAe--) {
        uyhBoHHRALudpj = uyhBoHHRALudpj;
    }

    for (int irmptXdTktX = 1213394626; irmptXdTktX > 0; irmptXdTktX--) {
        eBDGrH -= KZSIw;
    }

    if (KZSIw >= -439298.03419918317) {
        for (int RdyCtrpHgO = 1986859216; RdyCtrpHgO > 0; RdyCtrpHgO--) {
            uyhBoHHRALudpj = ! uyhBoHHRALudpj;
            ijFvUHpYEoO = ijFvUHpYEoO;
            KZSIw += eBDGrH;
            eBDGrH *= eBDGrH;
            KZSIw = eBDGrH;
        }
    }

    if (uyhBoHHRALudpj == true) {
        for (int TsiCYBna = 944749283; TsiCYBna > 0; TsiCYBna--) {
            KZSIw /= eBDGrH;
        }
    }

    return -499567667;
}

void NDCQKalWfhZY::tCasnQxxaPRZ()
{
    int yRwUGkTXdh = -1635342006;

    if (yRwUGkTXdh < -1635342006) {
        for (int QthvnV = 818570657; QthvnV > 0; QthvnV--) {
            yRwUGkTXdh -= yRwUGkTXdh;
        }
    }

    if (yRwUGkTXdh != -1635342006) {
        for (int mDvQWhLvuVoZtVvE = 2002798446; mDvQWhLvuVoZtVvE > 0; mDvQWhLvuVoZtVvE--) {
            yRwUGkTXdh /= yRwUGkTXdh;
            yRwUGkTXdh *= yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh *= yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh *= yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
            yRwUGkTXdh += yRwUGkTXdh;
            yRwUGkTXdh += yRwUGkTXdh;
        }
    }

    if (yRwUGkTXdh <= -1635342006) {
        for (int ggOwWVfIDFonbrjE = 2145529747; ggOwWVfIDFonbrjE > 0; ggOwWVfIDFonbrjE--) {
            yRwUGkTXdh *= yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
            yRwUGkTXdh *= yRwUGkTXdh;
            yRwUGkTXdh += yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh += yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
        }
    }

    if (yRwUGkTXdh < -1635342006) {
        for (int IhGtnvgGHhzwpO = 1942715834; IhGtnvgGHhzwpO > 0; IhGtnvgGHhzwpO--) {
            yRwUGkTXdh -= yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh -= yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
        }
    }

    if (yRwUGkTXdh != -1635342006) {
        for (int KUlbhRqzba = 1098306706; KUlbhRqzba > 0; KUlbhRqzba--) {
            yRwUGkTXdh *= yRwUGkTXdh;
            yRwUGkTXdh += yRwUGkTXdh;
            yRwUGkTXdh *= yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
        }
    }

    if (yRwUGkTXdh == -1635342006) {
        for (int xcToBH = 414824842; xcToBH > 0; xcToBH--) {
            yRwUGkTXdh += yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh = yRwUGkTXdh;
            yRwUGkTXdh -= yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
            yRwUGkTXdh /= yRwUGkTXdh;
        }
    }
}

int NDCQKalWfhZY::MeObBhlwMV(double uzhbAUCjwLob)
{
    double xMrwEqj = -30265.418846960605;
    bool fxRdIMI = false;
    string hmYbvHxrWcZ = string("ghQOOhiorRQnxczjWIxlaOTthkuKyRwSYXXquShZRmpdnKIKdtLiwfqLNenAUBBzhgCzjuaOPIkAJKvEk");

    if (uzhbAUCjwLob <= 774355.0452747985) {
        for (int yNQJKxsQNz = 276392626; yNQJKxsQNz > 0; yNQJKxsQNz--) {
            uzhbAUCjwLob -= uzhbAUCjwLob;
            hmYbvHxrWcZ = hmYbvHxrWcZ;
            uzhbAUCjwLob *= xMrwEqj;
            xMrwEqj += uzhbAUCjwLob;
            hmYbvHxrWcZ = hmYbvHxrWcZ;
            xMrwEqj += xMrwEqj;
            hmYbvHxrWcZ = hmYbvHxrWcZ;
        }
    }

    return -851180956;
}

bool NDCQKalWfhZY::LBsIhFhPI(bool vwCaqpBfJ, double gkQEwwzLGtVEbsR, string XCPzbXxaruyPeuWb)
{
    int djfdfYXNSKfpOdl = 2053380739;
    bool qLhfDlAA = true;
    bool fUzdEizFQ = true;
    int qYAJqi = -1846375197;
    string TiaWXkSCZaiIAHPx = string("FREyjdWMPYwtKgpLsQSZVhVeoiETEiXaUWzyGLSVsXPePwKNddRwleDiqxtCNBthsrjfhBODPWIWUgzcdZmZQpASgizEgkTaSIfYJBNnXrjYAOtKOoyjiYbVlGWvoVmMGnsCjrzkzWClQgNKOsXRFIDFlRfjHexqUwfSDNtRMWIHdSZOiVzoEAXLeEpxWQHxrQUvPbPtdPVSXoAzXYrWaVshir");
    int UknAIvBK = 1814022535;
    string uubufRUYLQmntMG = string("KvIiRGAnZNoYhGaHlPnBZgDPbaNIcGsIiGNipZUrRHANgoVXtLT");

    for (int SvhPqCY = 1385751417; SvhPqCY > 0; SvhPqCY--) {
        qYAJqi /= UknAIvBK;
    }

    for (int WonSHPhfdbwLYU = 827906609; WonSHPhfdbwLYU > 0; WonSHPhfdbwLYU--) {
        qYAJqi = qYAJqi;
    }

    return fUzdEizFQ;
}

void NDCQKalWfhZY::FaEcvuRcOwir(string ezGHvaEifTKhX, double HvooUTPujVqfksK, double SDgOxXLolq, bool RwDDziozJTgf)
{
    bool mISoqJbLDr = true;
    bool ZisFShLlcsKp = false;
    int KuMeiajlJyLum = -101970704;

    if (SDgOxXLolq > 342443.2305771242) {
        for (int izeLb = 883928870; izeLb > 0; izeLb--) {
            ZisFShLlcsKp = RwDDziozJTgf;
        }
    }

    if (ezGHvaEifTKhX >= string("QqyzpKncjRjlJZCXzNEXdzlbCxtrXkraLXMVrZPxSLepdxYXpUVIBYsKjVScYQXlkCjmopTDSFpCDcnlnFWGtKRWwduIbIDYyzkNYtBGCqskcxZyACEPIjonerXuZthANCxOOQVlwfOmDmhGdIS")) {
        for (int NLWcjBMudOKjhX = 247964878; NLWcjBMudOKjhX > 0; NLWcjBMudOKjhX--) {
            continue;
        }
    }
}

int NDCQKalWfhZY::txBUyoEPA(bool GVYcFCmVC, double vPNcdaqKoea, double phUpG, bool bjhFRbHxzEWwbVUm)
{
    string lHzoFTC = string("UHdHxcOUMLfHBYFvvgrXZjylzYfKSBjOGGeeOozwgzYtGTKvYangbDzPHFhvrYcEGhhFziTmcMZZXIHSnvHBkvJkGuRTBpzOxEuSeDjNghpPbKrWvTPfswejZHBnzXLKUKwmfGtItUdSlb");
    double PVwgcl = -96052.30694164513;
    int JxwyMY = -686734380;
    double oCvowGpTiMn = -324258.1329749408;
    string nnvQMQ = string("DyZZqXIZvBPXFlqGvuKcMppFIVAiPSAMWOmMRtPWSfHkqzgbhCnbHpUMUCmAIddCUBLIewluBIaSFGwXXyuJVYWcYxHahviLmzMvwHZEkuzfvPmEkVBSIwdSiUqkGXvDAdwiZFXwraBdiaYlezUkyDybIWkBHUrJfwPTAfouBmmYtwxIcRleqhsOqAoTaAdaxhoHjktX");
    bool ritrmQA = false;
    int eoIgmxqbAcHRUz = -1985095507;
    double MHdtcAzeC = 734021.3190474687;
    int FDpfFjOCWonjEUN = 418858009;
    bool NspwkUqZvvJx = false;

    for (int NGrabQCYVoMN = 1133193668; NGrabQCYVoMN > 0; NGrabQCYVoMN--) {
        oCvowGpTiMn -= MHdtcAzeC;
    }

    for (int HHGYbzQkAzKMBJ = 1988324909; HHGYbzQkAzKMBJ > 0; HHGYbzQkAzKMBJ--) {
        nnvQMQ = lHzoFTC;
        FDpfFjOCWonjEUN += FDpfFjOCWonjEUN;
        NspwkUqZvvJx = ! ritrmQA;
        phUpG *= PVwgcl;
    }

    return FDpfFjOCWonjEUN;
}

int NDCQKalWfhZY::tNlByGY(double udwbisP, double XsnaxnKCHWNWXMX)
{
    double YogNnDNdEBF = -404805.4795786527;
    string kOLyTKGLi = string("KPuIBXhiqYWJalvKACMtATdUBBCQjbMYBRVlRGYDtaxqYOYdPdrCRIFwseveZQOPWdtBuzdRzhpSVamiRNIxKSnNUyAuDQscdtXekmqhvjGmPzWViHCBzjrbsjiwenmiHXUzToLDgUrVxWOBEohimbBRnVzycaNonQjzHpmYbaGtIeGoAzeXMVIJAeuaaMTptXrTRNmrZUHt");
    int FYEWbHSkzzlkeYOE = 1877251519;
    int VBoLa = 1455834263;
    string YUkvIVHmnyO = string("VoAUKpMqbfSBJZJyrZCDmUrLpIauQTYeIyciKlKgxwVkZXoOOyaGXwDWfwGFuIFYMBHzuEKsYfBFRYdMJYoNYtbdkbiTxonKHKzkHnKlawPyYSG");

    return VBoLa;
}

string NDCQKalWfhZY::ufvwgQC()
{
    bool hDObHEDizEN = false;
    int EGyPxy = 1990944113;
    string XLucl = string("DgDQqnqnpafvClYwyIybRZQHynpeCesHKIRjAisBFAFmzrpOPivd");
    string eRynkdIedTvFSzyE = string("TDyGsCqLZWAnsxJHsrHeFbBhBNlqSMTWgvFUdEKjFxcWaEkzXRBaPYarXQSlgGfbNIFXJuLpzfuOVkLORUWXcZftGfIxTvSYrDFRcRfgXvLEcVhymZyZfgsjmAmBhQelJmNhnnXssSLSFuFCtkIgOmqerAyPbKoNOJrogJZKISsrZDFYlGsADaZFPmXZxhOfZXJvaPjz");
    int jNJfkdxXhYUlx = 486268924;
    string zfXCXRXOlzHrJWU = string("lXtKrzyqNGtDjrSnkoHTAIOjTTZWYdyvvFQw");
    bool CKtxC = false;
    double BBBTpYSWCfgGgWgn = -533514.8710473811;
    int ISZiqngeHEjNTkZ = 1904644949;
    int SMKnWyDiLdbr = 238236044;

    for (int mYppjLRLc = 1242926925; mYppjLRLc > 0; mYppjLRLc--) {
        continue;
    }

    return zfXCXRXOlzHrJWU;
}

void NDCQKalWfhZY::WXgbvP()
{
    int yRwGfLOkp = -1740219424;
    double oOFLMEIlPbRS = -628032.2755266213;
    string QjrTFrID = string("sURyQjHBkbbFfGRfaYsIosYafJpmaCgeEskmzBwiKVwvbjGngDbSfpaDvhMtfEoXmFsUocoMaXnHwGVOMOurYlPdwKqOcIodQbyClWCQlnaVEqZvCtkatJQnOLkYsghZqxDtWjBtncCaiKcyWnoYYbbtrbNqGQMkUbQCIpFpsGxvtKmDsG");

    if (oOFLMEIlPbRS != -628032.2755266213) {
        for (int KcNBdC = 1972637771; KcNBdC > 0; KcNBdC--) {
            yRwGfLOkp += yRwGfLOkp;
            oOFLMEIlPbRS *= oOFLMEIlPbRS;
        }
    }

    for (int uHkQe = 1769313214; uHkQe > 0; uHkQe--) {
        yRwGfLOkp = yRwGfLOkp;
        QjrTFrID = QjrTFrID;
        yRwGfLOkp -= yRwGfLOkp;
    }

    for (int spxyQEeQEhXS = 1801342977; spxyQEeQEhXS > 0; spxyQEeQEhXS--) {
        QjrTFrID += QjrTFrID;
        QjrTFrID += QjrTFrID;
    }
}

NDCQKalWfhZY::NDCQKalWfhZY()
{
    this->dwYvvI();
    this->tCasnQxxaPRZ();
    this->MeObBhlwMV(774355.0452747985);
    this->LBsIhFhPI(true, -815567.771972189, string("WjuysWfQNHhWiDTCFUMLSWXpyhFJYtPaFSPJOdOQbPOiMARFYVDCSDgxAqFaXzXHlpDzYHPHfAkHcRbmZAdKvicIRFWqyDODdJgYNBfkcrirYAyyeBwqegQjemJWyaItbeicokipRFpEOOrRWThoelIlhwaGKamQwyWYwevmmBSGiKGPlHTiIMkVROnxzsHCssHKEBHuaj"));
    this->FaEcvuRcOwir(string("QqyzpKncjRjlJZCXzNEXdzlbCxtrXkraLXMVrZPxSLepdxYXpUVIBYsKjVScYQXlkCjmopTDSFpCDcnlnFWGtKRWwduIbIDYyzkNYtBGCqskcxZyACEPIjonerXuZthANCxOOQVlwfOmDmhGdIS"), 342443.2305771242, -631764.0041676064, false);
    this->txBUyoEPA(false, 455772.60672654974, 146035.4537087913, true);
    this->tNlByGY(386383.80413049547, 497490.68531144847);
    this->ufvwgQC();
    this->WXgbvP();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rMXUSP
{
public:
    double MeoVNOdwX;
    double IFAxptDi;
    string OpOdcEzIUjqHkM;

    rMXUSP();
    void BYEFYhqpqBMJXXb(bool FljIcboP, string XszFovhEdZJP, bool mdKGe);
    bool ujECAsiYEJmY(int ySdrc, double XThVIeYc, bool vRcjV, double XUaJzMYQnJGyYis, string TRfiPRF);
    bool iSCKUHlMpmAOD();
    bool ejrbib(double DCQusy);
    string FjlfdJfA();
protected:
    double XGaytfmovbWTR;

    double kgPoAhszpD(string XoTHaHajKTOVqSw, double NdXqEjyro);
    bool MrKGUOLrFDnb(int jjqFz, string icmKPRZPxPfwVF, string AYYDz, bool tNXMqTVfTSiZz);
    string gDiBK();
private:
    bool tUpBZQlvOtQGK;
    string sFJBH;
    double BbzGw;
    int boKFhVwHiTzlfSpv;
    string CRRfjutae;
    double RHgErNIadNsMYj;

    bool gwgzhi(double fiNaxzSpvZ);
    void FblZAMzGxtvUDw();
    string SfAYshEOBSCvEEio(int WhhwSCvUrdpO, string BgSpA, int ggdzNXBb);
    int RGHjzq(string xFikCdhrm, bool LsMkmw, double cUuZFoPVtf, int WjZtMOd, bool sTuMHoYIjbd);
    string yoNhwGtDQE(double BZeLqmjmCs, int TSgESeRTCWMhEI, int PPpWoe, string IlmlPoiW);
    int woOliMNElSD(bool UtwJuPeHBZ);
    double UepInjUhXUfT(string faDRNa, string rXBQbKDw, double DCWFt, int AYAGqR);
};

void rMXUSP::BYEFYhqpqBMJXXb(bool FljIcboP, string XszFovhEdZJP, bool mdKGe)
{
    double yeIaJlTBO = -63067.21481452206;
    double VwRklYlr = 503923.8260072056;
    int FzqCuOxmedxDCtQs = -609642020;
    bool DEdpTLbpwtUJeSTY = true;
    bool OYgioZptJM = true;
    int yItVVAjP = 1254786612;
    double YudfTSazbsgq = -672531.2346295825;

    for (int DtRiq = 1176950362; DtRiq > 0; DtRiq--) {
        DEdpTLbpwtUJeSTY = ! OYgioZptJM;
        FljIcboP = ! DEdpTLbpwtUJeSTY;
    }

    if (YudfTSazbsgq >= -63067.21481452206) {
        for (int ukolFwADYwIHZ = 337241125; ukolFwADYwIHZ > 0; ukolFwADYwIHZ--) {
            FljIcboP = FljIcboP;
            DEdpTLbpwtUJeSTY = ! OYgioZptJM;
            DEdpTLbpwtUJeSTY = FljIcboP;
            mdKGe = mdKGe;
            VwRklYlr *= yeIaJlTBO;
        }
    }

    for (int WUQFkmz = 832692681; WUQFkmz > 0; WUQFkmz--) {
        YudfTSazbsgq *= YudfTSazbsgq;
        mdKGe = mdKGe;
        FljIcboP = mdKGe;
    }

    for (int cFsDWQ = 712560180; cFsDWQ > 0; cFsDWQ--) {
        FljIcboP = ! FljIcboP;
        YudfTSazbsgq /= yeIaJlTBO;
    }
}

bool rMXUSP::ujECAsiYEJmY(int ySdrc, double XThVIeYc, bool vRcjV, double XUaJzMYQnJGyYis, string TRfiPRF)
{
    string DJEUMXXiCK = string("nTJpqlgxSjcJuTllWSiiAZCXWGFmUNMtHMnaMccamtOtoaHiOsohTDxBrUrUeZSfHRvFPpDztZRXIFFkTRJSJmbKAmHoMYOqevxZqTUARlNRjqqCasMQYMqRTvvfvsEhpJcDmkSIMCEqK");
    string zJsVWdGdxmOnuYpW = string("ApeRakakadhcTnBlqgIWTPBYmFsvRsGhWvVjFeUZJaXoDTvlXXrgXSjJzIAyTmPHsuHAyIuVKKkEDixHxRbY");
    bool IWvZGoIsCceLm = true;
    double zybYQULJzgOPD = 411693.7903107307;
    double QNfWkHBeQT = 300634.4013012799;

    for (int MMVUXZDe = 1804977504; MMVUXZDe > 0; MMVUXZDe--) {
        XThVIeYc *= QNfWkHBeQT;
        QNfWkHBeQT *= zybYQULJzgOPD;
        zJsVWdGdxmOnuYpW += zJsVWdGdxmOnuYpW;
        XUaJzMYQnJGyYis *= XThVIeYc;
        zybYQULJzgOPD *= QNfWkHBeQT;
    }

    for (int WDTAnUpR = 1240914597; WDTAnUpR > 0; WDTAnUpR--) {
        XThVIeYc -= XUaJzMYQnJGyYis;
    }

    for (int nytDMKhD = 1355189066; nytDMKhD > 0; nytDMKhD--) {
        continue;
    }

    for (int zixBiAk = 340670262; zixBiAk > 0; zixBiAk--) {
        XThVIeYc /= QNfWkHBeQT;
        XThVIeYc /= QNfWkHBeQT;
    }

    return IWvZGoIsCceLm;
}

bool rMXUSP::iSCKUHlMpmAOD()
{
    bool uOqgUpsxj = false;
    bool ettbwXGYWUr = true;
    int OEOKjHEOj = -1832685852;
    int BNWFPZsvdEA = -1660882911;
    double xaEJul = -909363.824987085;
    int IcuajFzvEO = 1307821423;

    for (int uuWcYufEnIQRqce = 1217246425; uuWcYufEnIQRqce > 0; uuWcYufEnIQRqce--) {
        BNWFPZsvdEA += OEOKjHEOj;
        OEOKjHEOj = OEOKjHEOj;
        OEOKjHEOj *= IcuajFzvEO;
    }

    return ettbwXGYWUr;
}

bool rMXUSP::ejrbib(double DCQusy)
{
    int YViTx = 1612645560;
    double vkXIwHVWrFCeMnf = -1040566.7903017099;
    bool RmkISiSpkpGHRpSG = false;
    bool izsUWHpHkREMK = false;
    int ztMlgvjZnq = -1879231640;
    bool vHXpauFSpEHnK = true;
    double MFGnmzdVN = -689697.8774728714;
    int CMycortGXKHtzOp = -1065543591;

    for (int TQjFDheQcnoi = 315213644; TQjFDheQcnoi > 0; TQjFDheQcnoi--) {
        DCQusy /= vkXIwHVWrFCeMnf;
        CMycortGXKHtzOp *= YViTx;
        RmkISiSpkpGHRpSG = ! izsUWHpHkREMK;
        YViTx /= CMycortGXKHtzOp;
    }

    if (CMycortGXKHtzOp == 1612645560) {
        for (int TCojWWHa = 952546221; TCojWWHa > 0; TCojWWHa--) {
            izsUWHpHkREMK = ! vHXpauFSpEHnK;
            DCQusy *= vkXIwHVWrFCeMnf;
            ztMlgvjZnq = ztMlgvjZnq;
            izsUWHpHkREMK = ! vHXpauFSpEHnK;
        }
    }

    for (int MjTKNLVXQV = 1950709893; MjTKNLVXQV > 0; MjTKNLVXQV--) {
        izsUWHpHkREMK = izsUWHpHkREMK;
        vkXIwHVWrFCeMnf *= DCQusy;
        CMycortGXKHtzOp = YViTx;
    }

    for (int txiOWYWgLEIgpy = 806959756; txiOWYWgLEIgpy > 0; txiOWYWgLEIgpy--) {
        CMycortGXKHtzOp = YViTx;
    }

    for (int HclkYHcXXpwPBUM = 923810495; HclkYHcXXpwPBUM > 0; HclkYHcXXpwPBUM--) {
        vkXIwHVWrFCeMnf += vkXIwHVWrFCeMnf;
        ztMlgvjZnq = CMycortGXKHtzOp;
    }

    return vHXpauFSpEHnK;
}

string rMXUSP::FjlfdJfA()
{
    bool ZHgQb = false;
    int wHLRQgZLe = -107190079;
    bool mZulkjS = true;
    string USOpbhwVXb = string("hJsPNZwgCCgljydzvdVuLzLVHAZMLoDOuQyETSBAmcOKvFmXzucFGVsiKRtiRRZerKvhONijUnirFrMURpWIkLnDWl");
    bool IBvDUVaNZrmX = true;
    bool zoVaXpsVQbPfLX = true;
    string TwxwYypTAEN = string("VHznikQyFFvhDGPygiWQtMAPQEOqIAMdjxXeSxpJGpphYumTWBWEEXdPlFumXCinlvpgnpSBkSALATaHjiJOkzDLDrYRTMoLvhTSkIzWPNCLHZWiFkXvGYedUbpEISTWBSiYPArocmXG");
    bool rfcBvH = false;
    double ZDbmQUzRo = 372346.45404618874;
    int oyUvAPyKVyTX = -571077911;

    for (int KJHKSuimICmdIt = 257924565; KJHKSuimICmdIt > 0; KJHKSuimICmdIt--) {
        continue;
    }

    for (int xwmPdOukEdgPSCpo = 1865028951; xwmPdOukEdgPSCpo > 0; xwmPdOukEdgPSCpo--) {
        wHLRQgZLe += wHLRQgZLe;
        zoVaXpsVQbPfLX = zoVaXpsVQbPfLX;
    }

    return TwxwYypTAEN;
}

double rMXUSP::kgPoAhszpD(string XoTHaHajKTOVqSw, double NdXqEjyro)
{
    double OQcsfcVTzapj = 243170.99566054126;
    double OVOiziBDh = -862625.1379524624;
    double SuHlTQRpdo = -554397.870703988;
    int HOFJeduZJjU = 481881196;
    bool RTikviZDkI = true;

    for (int FREYOtyJIyuTFkSL = 1332500012; FREYOtyJIyuTFkSL > 0; FREYOtyJIyuTFkSL--) {
        continue;
    }

    return SuHlTQRpdo;
}

bool rMXUSP::MrKGUOLrFDnb(int jjqFz, string icmKPRZPxPfwVF, string AYYDz, bool tNXMqTVfTSiZz)
{
    int BDHFJdUBvyBXaPth = 1105857659;
    double DoxPnGuFBpieC = 424602.28877065255;
    string ZHozIO = string("zsmXVgkCHTcHGihMujoTKKEOgIEepSeYMSjvjmgATmjoqUJn");

    for (int aDJwDexqhs = 171655852; aDJwDexqhs > 0; aDJwDexqhs--) {
        continue;
    }

    return tNXMqTVfTSiZz;
}

string rMXUSP::gDiBK()
{
    bool TiiaMiBDjKXDUE = true;
    double qLtKWzQCGVqun = 669903.4702052731;
    string XkSQGpjroCl = string("tZcTSFFrXyOHfVKHWhmirbtFlZEckRcuEWUinqzJTtfrHxtxcwTuhdTYnxYIVADWhgFgliobvmvemhDlXaUHYGsYWlXUdHfTlyjWBsugyKfuNhPofjnbbmwDooTLGyM");
    string jREOgSJduGkIp = string("DbaYKpjzrbENlchrdllaWogNEOTCUanXbJWHnKlQKwmlHljeFW");
    int WHirAAg = -1323826856;
    double wLiiOJhXVyeB = 353367.42301295075;
    int DBnCwL = 1179051664;
    string XWSDHzP = string("R");
    bool FVnlowiP = false;

    for (int mIDNCc = 1727050442; mIDNCc > 0; mIDNCc--) {
        WHirAAg /= DBnCwL;
        XWSDHzP += XkSQGpjroCl;
        jREOgSJduGkIp = XWSDHzP;
    }

    for (int VpeVwMjSFy = 788136288; VpeVwMjSFy > 0; VpeVwMjSFy--) {
        continue;
    }

    for (int zTscoFQrcabO = 595556960; zTscoFQrcabO > 0; zTscoFQrcabO--) {
        WHirAAg = WHirAAg;
    }

    return XWSDHzP;
}

bool rMXUSP::gwgzhi(double fiNaxzSpvZ)
{
    bool LAgHrN = false;
    double YkSRC = -239795.11484364068;
    bool otZYtrfFzXTkLr = false;
    double zrFDg = -752620.1252593691;
    bool UPpBmgiQkcg = true;
    int lhhXsTnW = -2137450615;

    for (int hslKji = 1506415050; hslKji > 0; hslKji--) {
        YkSRC *= zrFDg;
        fiNaxzSpvZ *= YkSRC;
    }

    return UPpBmgiQkcg;
}

void rMXUSP::FblZAMzGxtvUDw()
{
    string oyhENXAjFEYMR = string("kwRSykJIZxRoiQIMObnqXLhLXhUyOiFGBsXSmPNPvYknEpskowPcdCBLRDSNWSBNkgUwKOtRmvfbAPHqWchlBqwKsXXiZPfDAlmNKmCjNctADTjRZyYabJkvCouJSCCDkzUiAVwRSelplCYlUZxefTEcrcWoSZqXLcACEgUNeqfoEjPzIDzDkJRrCBuBFxIkLJGZnqFWmvBPFdsiwBnosvlxgMFTATgqXIcxIVePelGnCLwEjAsNgZVpY");
    double vTgDdlt = 446752.1364202355;
    string CODwhZ = string("SOgXgjoSkmbrpUJGkjOXZopysnhtiScBbDyRYHztolvN");
    int akTZRhHgigImaLap = -1987120814;
    int fhUhUz = -1635383784;

    for (int skWvnsIcL = 1564222037; skWvnsIcL > 0; skWvnsIcL--) {
        akTZRhHgigImaLap *= fhUhUz;
    }

    if (fhUhUz <= -1635383784) {
        for (int SHoyiE = 220933041; SHoyiE > 0; SHoyiE--) {
            vTgDdlt += vTgDdlt;
            akTZRhHgigImaLap -= fhUhUz;
            fhUhUz = fhUhUz;
        }
    }
}

string rMXUSP::SfAYshEOBSCvEEio(int WhhwSCvUrdpO, string BgSpA, int ggdzNXBb)
{
    int tfCPLZdchjJ = -458560160;
    bool YBarKIkdX = true;
    string REiTO = string("nvdmrGznTuwAVqOvQrxBvkTaEOClAfBKYSwQArIAZuamTrwcWlQlmpsmmqfgKqGOdzoLMCQAxXjAXvNwVfMnkkOoGZdnTvuMYIWOxrarpHjUGdFOcOOQfMorQpwqNUwzRNnwNaHpkmwYkachMPLMaGmscmWPNtEcbZEEfnpPEYsxNIUDgPYBUOVWTeLynlEvoNTEjyMpSsoiWdTkWZvTwQdKFwvJXyPLYlGZRKTtvCHkTFS");
    double BGkZYMIBOdRzl = 106533.55615411319;
    double izZYU = 892891.817226732;
    int yvaKckJhf = -1560500074;
    bool aMTyVKnLBoAnLSO = true;
    int zeDBm = 558650958;
    int shMhZOutnVtBqiAH = 723349783;
    string JcwHPjMANg = string("CEjpYpwHaSQtYTqjJdqiFZwjvOVweXWfFgUbuvLrzDRJeHgPCYpCuMkYWEvKEFAfHSzm");

    for (int ROJzMfBD = 223112942; ROJzMfBD > 0; ROJzMfBD--) {
        BgSpA += JcwHPjMANg;
        tfCPLZdchjJ -= ggdzNXBb;
    }

    if (zeDBm > -458560160) {
        for (int mmMBIqIBSjJu = 164668349; mmMBIqIBSjJu > 0; mmMBIqIBSjJu--) {
            yvaKckJhf += shMhZOutnVtBqiAH;
        }
    }

    for (int JfOEOizDGWEJhbKs = 1501865418; JfOEOizDGWEJhbKs > 0; JfOEOizDGWEJhbKs--) {
        continue;
    }

    return JcwHPjMANg;
}

int rMXUSP::RGHjzq(string xFikCdhrm, bool LsMkmw, double cUuZFoPVtf, int WjZtMOd, bool sTuMHoYIjbd)
{
    double EUbzokNczk = -398390.58000908693;
    double sGCnZFyFXXtokE = -949376.8176109066;
    bool bQdChdYz = false;

    if (EUbzokNczk <= -949376.8176109066) {
        for (int ZXCvJSizT = 879351507; ZXCvJSizT > 0; ZXCvJSizT--) {
            LsMkmw = sTuMHoYIjbd;
            sTuMHoYIjbd = bQdChdYz;
        }
    }

    return WjZtMOd;
}

string rMXUSP::yoNhwGtDQE(double BZeLqmjmCs, int TSgESeRTCWMhEI, int PPpWoe, string IlmlPoiW)
{
    int gXNQaQDPSp = -881360190;
    int UxzzBdeepnA = 1730905692;
    bool muIXz = false;
    double uQHlFKfCKOZN = 409637.3099136049;
    double XrDLiLmGXMMHlKvb = 851448.7979962657;
    string YndMxJcYpclHNWYX = string("FYSNduFMndfRHqAlEXJZHWmribCVrbMaJSHHDDvoPxyxJCmdGmsRoZbpp");
    bool IlUarfsNm = true;
    string eNBTPrfFMqlDjFEO = string("TlujcZlRavDIScQZEvyKDTmfJCyQHdnohcbcixTmAuTRwnYBIrwqglKaePhqlRDUHpHTphyRGxromEyBAjeneCDnlSUnkjCqqSLrAlpIjBiFZhSCemcljmRfiaybZcCPCTdwSUUIjzhipOXqpBAIYTgBopCjznZLKBRZnjvVvtaXImsghusbrWrLIZuVsZUkAmkQvzfPRQ");

    for (int kTSpGcND = 1469340302; kTSpGcND > 0; kTSpGcND--) {
        TSgESeRTCWMhEI += TSgESeRTCWMhEI;
    }

    for (int tMxvVmn = 1580097297; tMxvVmn > 0; tMxvVmn--) {
        TSgESeRTCWMhEI /= UxzzBdeepnA;
    }

    if (IlmlPoiW >= string("FYSNduFMndfRHqAlEXJZHWmribCVrbMaJSHHDDvoPxyxJCmdGmsRoZbpp")) {
        for (int CJXhDvzV = 2118853149; CJXhDvzV > 0; CJXhDvzV--) {
            PPpWoe /= UxzzBdeepnA;
        }
    }

    for (int bAnRQrwlOZg = 1086801099; bAnRQrwlOZg > 0; bAnRQrwlOZg--) {
        UxzzBdeepnA = gXNQaQDPSp;
    }

    for (int gxRrlumMaIrb = 979564857; gxRrlumMaIrb > 0; gxRrlumMaIrb--) {
        YndMxJcYpclHNWYX = IlmlPoiW;
        UxzzBdeepnA /= gXNQaQDPSp;
        PPpWoe += gXNQaQDPSp;
        eNBTPrfFMqlDjFEO = eNBTPrfFMqlDjFEO;
    }

    return eNBTPrfFMqlDjFEO;
}

int rMXUSP::woOliMNElSD(bool UtwJuPeHBZ)
{
    double KmpQVwyJf = -815200.416303766;
    string ZgpvWUlKchAaXEaO = string("nQVUWHjwvoCYeEwIyjrsdMLCgjKVawWyoGQzTPuqIpjmMCuxAeSvrZCfKTMrpzIRVKkrmaTOHXbBDfQeEroBg");
    bool ElKNy = true;
    bool zdOVXU = true;
    bool cEzjbVpG = false;
    double oFfEaaWH = -294287.84485687234;
    string GzADJjj = string("lymkTZyetseAKasJvnSiuSHBgNbnFsHmJPhYzzNNlV");

    for (int DdJORKf = 589665680; DdJORKf > 0; DdJORKf--) {
        zdOVXU = cEzjbVpG;
    }

    for (int ARLDuzD = 1092077114; ARLDuzD > 0; ARLDuzD--) {
        ElKNy = cEzjbVpG;
        ZgpvWUlKchAaXEaO = GzADJjj;
        ElKNy = zdOVXU;
        zdOVXU = ElKNy;
        ElKNy = zdOVXU;
        GzADJjj += ZgpvWUlKchAaXEaO;
        ElKNy = ! zdOVXU;
    }

    return -1818262103;
}

double rMXUSP::UepInjUhXUfT(string faDRNa, string rXBQbKDw, double DCWFt, int AYAGqR)
{
    double YsLLOkDJ = -481986.9755133261;
    double lTnUorIEc = -945674.620927384;

    for (int HzMwtaKTcroPcGMK = 908156794; HzMwtaKTcroPcGMK > 0; HzMwtaKTcroPcGMK--) {
        YsLLOkDJ += YsLLOkDJ;
        YsLLOkDJ += YsLLOkDJ;
        faDRNa = rXBQbKDw;
        lTnUorIEc /= YsLLOkDJ;
        DCWFt *= DCWFt;
    }

    if (faDRNa >= string("hJEieNxSDaxQsQnEkUvzbjsSGRHDJGeIBHktaOMtTDnOsavckfjtFpGLPTtzyqydykFFjlEwdmdekKXoybYhOoVTGmJcVvWChoybpfkXnXryhERfUAKrWaHnGoFNuJZidHDekNYlbqjEealIgHJfINlohuoEVEwLrdnmkMSTLkuTzIInniwdlqNpjmGrUDVJuHyEhQKKLCpTRUogltLetwxkmibUAJoIJyMLImnvO")) {
        for (int NreCyz = 1184452008; NreCyz > 0; NreCyz--) {
            rXBQbKDw = faDRNa;
        }
    }

    return lTnUorIEc;
}

rMXUSP::rMXUSP()
{
    this->BYEFYhqpqBMJXXb(false, string("ceYtiBSxBTfAUVDkpyXgFGaHloceNjmupSUFQRFdfZVRauRuSrQZYYeHgzzsKcYUFpxtoMHcdoSnUZYSGrlTuIoqQdqhnRwfMIBwdwlfbAtKuPOmJuDyIZjvwfFQxJWDsQlsYYYCloPpIvERuAbLPxBfiLosigKRNXnqDSfRIqumtQbHELuvVtQXNsYVwnmIyQLqXef"), true);
    this->ujECAsiYEJmY(1905651005, -417409.2025553164, true, -613612.0222109207, string("xGqGcjBZcGGLIgJvnXxYmpEsvmkNcltzQGoZkzcgPmZfVTPfcpHhDlQYopowIiyOVlCUAHrCXsid"));
    this->iSCKUHlMpmAOD();
    this->ejrbib(-530862.207538767);
    this->FjlfdJfA();
    this->kgPoAhszpD(string("eUlbvqNQhQbTstEtILMAZOVDtFBscfmNYEQUOOriqlOzLMcpClUBxPeWYYAzrCNDAkTEQbBWpgWdFwpceLhPZXPdTjlGBnucEojMWKgZTDFGHsjeoKzerGPmIxKcfjwOeeHfXvTikUeWYBIKrGSlruNdSSwUQEXvnvOWv"), 519740.21024838754);
    this->MrKGUOLrFDnb(1500501233, string("CxbNPcIegqJldLZnBGNYwJOPhflGoFhlZIJZplTfsjCoVzzcvThzFFvnOVsJAtcdytQAtjNMypkhYrVRcAhxEzDDjlwncqOMBiihRSBoLhpaDiOxjCp"), string("sBIDrYZtDhTJHoBiesEBJQyWbKwSBAUDSLbdnEWBCNyLtVwBTRkkyLFVvSkOutbwEkPdIRJjnINSajzmJQjlFeCNeJWQIVXvXHEjApBzleyawnbLqwNnYnmhHSiFnpzurYAbLCzOvUAdJPpzEHtxazWbPdwzgbhmNZbCwijPWpdWxncUpttQAYlreInmcbIWXOhozGDqRVvviIQkmqLSvnQOXnEhfRuAdlno"), false);
    this->gDiBK();
    this->gwgzhi(159123.21555507777);
    this->FblZAMzGxtvUDw();
    this->SfAYshEOBSCvEEio(35419660, string("HbxwLlJniXopmHYxlZzXoQujCijoefnypEQUneVhKHwuUDFFrOTICtPUBZHApXNELfkjYcrzHjAkXC"), 2056942119);
    this->RGHjzq(string("FgrllqFSJCbzPyshkWd"), true, 582290.8883892767, 2107253778, false);
    this->yoNhwGtDQE(824281.4956149515, -1157270105, 1897681276, string("OrbDpSzhhKAtYfYyFOcrgDkWSYmQEEMkagTsGjVoVJjkTSQtAJESfDxgomRGftCtufhkMkMNCmWWqbfASiXINHbcTFttOaWMgCsgjThkSkCegOzURjearZCTLVvbwrioGRoVXECHoSFOkfWnZdNHbbsRyZwmqVWxjoEUKDqzXhRTojtBUkLSyNLOAHADcJZUVZzdyXAcUAdXxBUrSXolceGbqbSyEKPegKWzvFNJUVOJgjveAGIjMv"));
    this->woOliMNElSD(false);
    this->UepInjUhXUfT(string("arcftxygMzfEXniwHSGoRTZYetpgdOUOxuxoMVoZjpSgOZavDcidZYezWXNfUWhlUySIsCvCVacAMOkQEDBZKvzaUPlipqDYcmiaUSJDqzsyJjXDMFQOMphyjOVTfDExCyUnbPlwNaGJIkMmwqpolIQqI"), string("hJEieNxSDaxQsQnEkUvzbjsSGRHDJGeIBHktaOMtTDnOsavckfjtFpGLPTtzyqydykFFjlEwdmdekKXoybYhOoVTGmJcVvWChoybpfkXnXryhERfUAKrWaHnGoFNuJZidHDekNYlbqjEealIgHJfINlohuoEVEwLrdnmkMSTLkuTzIInniwdlqNpjmGrUDVJuHyEhQKKLCpTRUogltLetwxkmibUAJoIJyMLImnvO"), 718024.3834608563, 660379371);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MMiLSZNsGlk
{
public:
    int RXvUSexNN;
    bool vKtVbyXzio;
    string qthkWOnAKklkI;
    int MzBAVdePZj;
    int FuptZhkiaLKtPOA;
    string bqTKggjYInD;

    MMiLSZNsGlk();
    double QbRaOIvl(string GaxFIkOOJK);
protected:
    double XPTpJrOuBaw;
    double VCUHsNwKp;
    string jDYAuLVQTx;
    bool HGvMKOkAOrTvg;

    int fLRjJ(bool fFbkrioEjPsL);
private:
    int EaAKa;
    bool nKDhWULja;
    int klRYf;

    double MCZhJncMXnqCn(string EEHzigkFEzdtI, int TptAnoJLCaioB, string bulAAFJMFtxF, double iGTyWUCO);
    bool XReaMgpijuzNvSG(double reYOgEAKYY, string iCyce, double YOKWPlRWJlr);
    void jJXKNWWvjJvtYv(bool qkSbWHoWdHpyJnj, int jJfsyBbUCPEqFWYj, double wdIYmKcIVgj, bool GjrzfVDiwaaAOL);
};

double MMiLSZNsGlk::QbRaOIvl(string GaxFIkOOJK)
{
    int orBtOsNtzEYGc = 996018749;
    bool CuBuJxP = false;

    for (int BUBdGHQIaQkrhYt = 1815524562; BUBdGHQIaQkrhYt > 0; BUBdGHQIaQkrhYt--) {
        CuBuJxP = CuBuJxP;
    }

    for (int tTISht = 973245112; tTISht > 0; tTISht--) {
        CuBuJxP = ! CuBuJxP;
        GaxFIkOOJK += GaxFIkOOJK;
    }

    if (GaxFIkOOJK <= string("nZKOiiCqqbEoYyHXwuKjsmMotDIiZqmBkJpxYdSizGZLpflXNXMtTTdqSkOCBugYaRJAWecEZJeEBTQCPWDGqpzEMMbXJfsAgVVyelaKltbjmDCbObLvvRwdjFMBmTNyItwkcysxAEmEGLUQQGWjrVYYIKJOGnz")) {
        for (int wVpBTTr = 1845022284; wVpBTTr > 0; wVpBTTr--) {
            CuBuJxP = CuBuJxP;
            GaxFIkOOJK = GaxFIkOOJK;
            CuBuJxP = CuBuJxP;
            orBtOsNtzEYGc = orBtOsNtzEYGc;
            orBtOsNtzEYGc *= orBtOsNtzEYGc;
            orBtOsNtzEYGc -= orBtOsNtzEYGc;
        }
    }

    return 477138.9838337931;
}

int MMiLSZNsGlk::fLRjJ(bool fFbkrioEjPsL)
{
    string NSeYK = string("GfzsjgGWyJPShJxnIDMsvXVRojSQUhWJLVjrmtdkqzSmocylpAteKsNpOFnJ");
    double ySkCkFmy = -1026152.4717905372;
    bool MhDttX = false;
    bool TrnyJXGATzwFyfKX = true;
    bool SHUadkveCKMlGL = false;
    int uecpr = 175169061;

    if (SHUadkveCKMlGL != false) {
        for (int XIieGclnWT = 680628001; XIieGclnWT > 0; XIieGclnWT--) {
            fFbkrioEjPsL = ! MhDttX;
            SHUadkveCKMlGL = ! MhDttX;
            fFbkrioEjPsL = TrnyJXGATzwFyfKX;
        }
    }

    if (uecpr > 175169061) {
        for (int RjvPpYnHua = 1349571816; RjvPpYnHua > 0; RjvPpYnHua--) {
            TrnyJXGATzwFyfKX = SHUadkveCKMlGL;
        }
    }

    return uecpr;
}

double MMiLSZNsGlk::MCZhJncMXnqCn(string EEHzigkFEzdtI, int TptAnoJLCaioB, string bulAAFJMFtxF, double iGTyWUCO)
{
    double yzDEmzsUSFT = -256592.65215324986;
    int WBKFyivIAYUVoy = -238051050;
    string OnjTPVH = string("hCUkkmkJJTgDbAWiruMDOPTQNprcnmzGSrNVCYkxdzrZDCcscuIwRaoOZEc");
    int KVBNKTiieWB = -1642351565;
    int XwZwH = 667109257;

    for (int eILixboqhdYkKbL = 52993235; eILixboqhdYkKbL > 0; eILixboqhdYkKbL--) {
        TptAnoJLCaioB *= KVBNKTiieWB;
    }

    if (iGTyWUCO > -256592.65215324986) {
        for (int sZBTzCNbSaILM = 1003522888; sZBTzCNbSaILM > 0; sZBTzCNbSaILM--) {
            OnjTPVH = EEHzigkFEzdtI;
            OnjTPVH += OnjTPVH;
            TptAnoJLCaioB /= KVBNKTiieWB;
            iGTyWUCO *= iGTyWUCO;
            KVBNKTiieWB /= WBKFyivIAYUVoy;
        }
    }

    if (iGTyWUCO < -256592.65215324986) {
        for (int rflQnoBmzfZ = 543452542; rflQnoBmzfZ > 0; rflQnoBmzfZ--) {
            KVBNKTiieWB = TptAnoJLCaioB;
        }
    }

    if (XwZwH == 2001720983) {
        for (int tivjjwWzmxA = 1104417890; tivjjwWzmxA > 0; tivjjwWzmxA--) {
            continue;
        }
    }

    for (int Jyxpkygsar = 1084727435; Jyxpkygsar > 0; Jyxpkygsar--) {
        XwZwH -= TptAnoJLCaioB;
        yzDEmzsUSFT = yzDEmzsUSFT;
        XwZwH /= XwZwH;
        EEHzigkFEzdtI += EEHzigkFEzdtI;
        OnjTPVH += OnjTPVH;
    }

    if (WBKFyivIAYUVoy < 667109257) {
        for (int jdlqnkkY = 1096879187; jdlqnkkY > 0; jdlqnkkY--) {
            WBKFyivIAYUVoy += WBKFyivIAYUVoy;
        }
    }

    for (int PMzegBxKgP = 1296157201; PMzegBxKgP > 0; PMzegBxKgP--) {
        continue;
    }

    return yzDEmzsUSFT;
}

bool MMiLSZNsGlk::XReaMgpijuzNvSG(double reYOgEAKYY, string iCyce, double YOKWPlRWJlr)
{
    int RAwUiUCbasiRrH = 1956514508;
    string tDAirQ = string("zujltQNskQNyqmkwXboSImMBhhXOWTLrzTrTfQzfoHTzZMCexKaYfIjcBsJBTfHoEpZrv");
    string wNWzPcLg = string("yJgSvMeMhzCpBMBYEVBguaBjRbVkRmYDEgVQqUEXJSDEtvzyfEEvZSwaDApqEYhAZAtPIHoNBrFCdYBrpezGLwGRxobRwdLwvOCFQV");
    string xehasTrWTKRoI = string("cXzLcAvByLskGBIvvDCLnRhTlwWLcipWRsodVQcwhEkpQcwdaUAoGOzgmnTTBDvoujBTpqzQSacZOKSgZOQDbucvfTeFFkscZqIydEdUeKHrEqKfkq");
    bool NieYgLZDknLNnKzY = true;
    bool SJWqEuNAzl = false;
    double nVVbdrXpad = 43230.340925810175;
    int kJvoUTWIKfce = -924136931;

    for (int hjCnvpuUoToSe = 279068250; hjCnvpuUoToSe > 0; hjCnvpuUoToSe--) {
        continue;
    }

    if (reYOgEAKYY == -1423.2647468873952) {
        for (int FzBMfId = 1873229229; FzBMfId > 0; FzBMfId--) {
            reYOgEAKYY *= reYOgEAKYY;
        }
    }

    return SJWqEuNAzl;
}

void MMiLSZNsGlk::jJXKNWWvjJvtYv(bool qkSbWHoWdHpyJnj, int jJfsyBbUCPEqFWYj, double wdIYmKcIVgj, bool GjrzfVDiwaaAOL)
{
    int XrNzNFs = -747291659;
    int MONTIUqGa = 2119296114;

    for (int KfEuPkp = 1751337681; KfEuPkp > 0; KfEuPkp--) {
        MONTIUqGa = XrNzNFs;
        jJfsyBbUCPEqFWYj -= jJfsyBbUCPEqFWYj;
        qkSbWHoWdHpyJnj = qkSbWHoWdHpyJnj;
        MONTIUqGa -= XrNzNFs;
    }

    for (int secZVmDP = 661374402; secZVmDP > 0; secZVmDP--) {
        GjrzfVDiwaaAOL = ! qkSbWHoWdHpyJnj;
        jJfsyBbUCPEqFWYj = MONTIUqGa;
    }
}

MMiLSZNsGlk::MMiLSZNsGlk()
{
    this->QbRaOIvl(string("nZKOiiCqqbEoYyHXwuKjsmMotDIiZqmBkJpxYdSizGZLpflXNXMtTTdqSkOCBugYaRJAWecEZJeEBTQCPWDGqpzEMMbXJfsAgVVyelaKltbjmDCbObLvvRwdjFMBmTNyItwkcysxAEmEGLUQQGWjrVYYIKJOGnz"));
    this->fLRjJ(false);
    this->MCZhJncMXnqCn(string("RUgNZEdfThNZKbyFXYbyscfsbtPZOIeYBXNLyxUpgMdZCpOnXCpKhVTktdzOsXsCvHYlvlehsMdhBMwUAAFXsUfDQAUveeUaTWkoaaAmLUEkbQIOBMYxEpcmDmnsoGrCackjhNmqpPyrRGOAXcCqSTBVsJmlRHqcbDqJqroksrrRSlwXadzbaAqTheJMHEZTBJHIGjneXojajzIKYYamTHjdqkSJoBzYLr"), 2001720983, string("HjaBBgKKXJJBacjAPzyHLOfgjjmPrVPxbdIqJDanaeCtlMjMRWEvhDqBKxvjvqFjaQ"), -924109.9380242211);
    this->XReaMgpijuzNvSG(-224775.02204138107, string("EdnarueORqqbBLhbGbThzGKssSTRaLbGsGhHGXMOruMYwHARYhrRdXpEiUFXvsqFvGyDPATKicbQPgSlALRYLw"), -1423.2647468873952);
    this->jJXKNWWvjJvtYv(true, -1329364041, -685372.4498234208, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SqZVHCNtf
{
public:
    int ceBEblYcoDxY;
    bool TQsTzjriOq;
    int LKzUxrwOUKyj;
    bool RbACqyJovU;
    int TwPTp;

    SqZVHCNtf();
    double yMZPoMqxg(string FoplUNTIe, bool zcWEMqAedwNufc, int hBlxsh, bool TXrTaoywh);
    double RlYNpP(double hVzBiakAx, bool wGQnILGbdYldARxp);
    double UMESuNXTAHvxy(bool jvyxzMcqikRn, bool XqPdHH);
    int yUPTMnaXekQCkba();
protected:
    bool pndPyRKRmjL;
    double WBnTnq;
    bool hgeCwD;
    double hJUhaOlZUeBk;

    string ABMIhgtWO();
    void gMIjkmpDk(string ySUhS, double PPImuVXkOvp, string YZQSqKINWhtdiKDL, double dZKXPKVfJrlXGy);
    string KbRWneRhdK();
    void PjBcrTJo(string aNOESBcrnhJN);
private:
    string toSPRuCPJhmApRx;
    bool jyTKXwIkETeKcUV;
    string JESEnmv;

    bool rsLDGHRquiPDdA(bool dXlAtzLOyAAo);
    double kUsoYua(string kdguj, double JligLrDHjDESIZ);
    int TTNKzuRCaXDRO(string gIAEKQrxg, string XOwAUXBhUSoBpK);
};

double SqZVHCNtf::yMZPoMqxg(string FoplUNTIe, bool zcWEMqAedwNufc, int hBlxsh, bool TXrTaoywh)
{
    int SAuDuuSQXjQV = 2038369654;

    for (int fgWkNzTEexDGx = 885186626; fgWkNzTEexDGx > 0; fgWkNzTEexDGx--) {
        zcWEMqAedwNufc = zcWEMqAedwNufc;
        hBlxsh += hBlxsh;
        TXrTaoywh = zcWEMqAedwNufc;
        zcWEMqAedwNufc = zcWEMqAedwNufc;
    }

    for (int zEmycAZOxhft = 1203764292; zEmycAZOxhft > 0; zEmycAZOxhft--) {
        continue;
    }

    if (FoplUNTIe != string("xJuoEvKDrNFZaQBpxQGvbQfRZHtspravoIKeYQjUMGWcLBmtsylzcbvIfenAwkmEnx")) {
        for (int MrjbjtSirnqPU = 1624569402; MrjbjtSirnqPU > 0; MrjbjtSirnqPU--) {
            hBlxsh += SAuDuuSQXjQV;
        }
    }

    if (FoplUNTIe > string("xJuoEvKDrNFZaQBpxQGvbQfRZHtspravoIKeYQjUMGWcLBmtsylzcbvIfenAwkmEnx")) {
        for (int AgdAVbpjVRsI = 135585685; AgdAVbpjVRsI > 0; AgdAVbpjVRsI--) {
            TXrTaoywh = ! zcWEMqAedwNufc;
        }
    }

    if (FoplUNTIe < string("xJuoEvKDrNFZaQBpxQGvbQfRZHtspravoIKeYQjUMGWcLBmtsylzcbvIfenAwkmEnx")) {
        for (int VOpVgqLLQrJSh = 889125131; VOpVgqLLQrJSh > 0; VOpVgqLLQrJSh--) {
            FoplUNTIe += FoplUNTIe;
            TXrTaoywh = zcWEMqAedwNufc;
            zcWEMqAedwNufc = TXrTaoywh;
        }
    }

    return 70218.95877419449;
}

double SqZVHCNtf::RlYNpP(double hVzBiakAx, bool wGQnILGbdYldARxp)
{
    double pSNpDOhBQjPSd = 99251.55056890883;
    int kpvuySANfaIBP = -1002105274;
    int GWBRLGzn = 538696089;
    double eWOlRFKMdSe = 494917.4785518703;
    bool jHBDpaEdJtfLsg = true;
    bool GvXiSOOGSjxxS = true;
    string QCCJy = string("aezyuKaIsHapahpyvDWZzKraoZdrhCkfPhNiYxpltOWLnerJgxAwcxWGlvYVGxApZFjDBmAvkVBhpxkRunFyoXvDPeAXcJpQJAZVUSknEMWpkQbjfEHhXGrQbMxRrdrrnMjfwzm");
    bool rruUV = true;

    if (hVzBiakAx > 711813.6459888914) {
        for (int PtXnHaYTryMvmOUd = 582708591; PtXnHaYTryMvmOUd > 0; PtXnHaYTryMvmOUd--) {
            eWOlRFKMdSe -= hVzBiakAx;
            pSNpDOhBQjPSd -= hVzBiakAx;
        }
    }

    for (int renQNmh = 111761449; renQNmh > 0; renQNmh--) {
        hVzBiakAx *= hVzBiakAx;
        eWOlRFKMdSe += hVzBiakAx;
        GWBRLGzn /= kpvuySANfaIBP;
    }

    if (rruUV == true) {
        for (int YzmQJzT = 1924517751; YzmQJzT > 0; YzmQJzT--) {
            rruUV = ! wGQnILGbdYldARxp;
            pSNpDOhBQjPSd /= pSNpDOhBQjPSd;
        }
    }

    return eWOlRFKMdSe;
}

double SqZVHCNtf::UMESuNXTAHvxy(bool jvyxzMcqikRn, bool XqPdHH)
{
    string BqaiQTKuLenQe = string("NPiXoRSUFOXRwcnHpamolEuYOserTUsWBUAxzberZPopKKhOcIdsvkAtCAjMEhjIXUFPXBcC");
    string AjZYfC = string("cUZwTPkZPqHNXi");
    double rWEQQiBEPeQQey = 647906.0058769818;
    bool hkDHw = false;

    return rWEQQiBEPeQQey;
}

int SqZVHCNtf::yUPTMnaXekQCkba()
{
    bool ogXIp = true;

    return -1160840181;
}

string SqZVHCNtf::ABMIhgtWO()
{
    double IQBBLbhx = -943513.0581440586;
    bool XICCQHJyZDAzpOde = false;
    bool PPzWT = true;
    bool gDNkRxGNrpGq = true;
    bool iFZshEWmXVWLNgKC = false;
    double lOespkUBAeNAoZXP = -867951.8394142588;
    int PRBqo = -760533808;

    return string("mhHFMfSogvMCAUpRWpjfhJybQNDiCLfbtYJgmQBhuGhjJPEFPFhbvhfkquuawkcUakaozyvRfgcfDdTnmXGBAkeffBrCMIWUTezGgvCkgZHfvKoeMQGBVmltZX");
}

void SqZVHCNtf::gMIjkmpDk(string ySUhS, double PPImuVXkOvp, string YZQSqKINWhtdiKDL, double dZKXPKVfJrlXGy)
{
    string BDfckXj = string("fyfUjiFflDSrWJdbVWoCtpSIPHQFhCvbrWPSqsbknCAQcGTwvsmlRGkbSnsqcjQMdYkCoGgCuyaPuWVEKGwWxRLmskTzdwJVIMIzezXooUGbKGOPJfGsxNhknSsVHUkFYOfdseDjShU");
    bool EhPoKztdMbahG = true;

    if (YZQSqKINWhtdiKDL != string("QfVrmAnbWJYmaidRKSsninZyYQfFjyEUtsRuNLmOsgbuZAJckGC")) {
        for (int CeJeHepYyFKoru = 126118549; CeJeHepYyFKoru > 0; CeJeHepYyFKoru--) {
            continue;
        }
    }
}

string SqZVHCNtf::KbRWneRhdK()
{
    bool zGQrlyZfoSZTFDUX = false;
    bool zHUgoqBG = false;
    int ekaJxromwmQcUM = -482648049;
    int HGtcMGrtPaZkUjTy = -681918524;

    if (HGtcMGrtPaZkUjTy != -482648049) {
        for (int KpmBJlEdORgBJf = 741275534; KpmBJlEdORgBJf > 0; KpmBJlEdORgBJf--) {
            continue;
        }
    }

    if (HGtcMGrtPaZkUjTy != -482648049) {
        for (int rnxrpmMF = 586869319; rnxrpmMF > 0; rnxrpmMF--) {
            zGQrlyZfoSZTFDUX = ! zGQrlyZfoSZTFDUX;
            HGtcMGrtPaZkUjTy = ekaJxromwmQcUM;
            zGQrlyZfoSZTFDUX = ! zHUgoqBG;
        }
    }

    if (zGQrlyZfoSZTFDUX != false) {
        for (int jHSanEdPNJoDJWs = 362714246; jHSanEdPNJoDJWs > 0; jHSanEdPNJoDJWs--) {
            HGtcMGrtPaZkUjTy = HGtcMGrtPaZkUjTy;
            HGtcMGrtPaZkUjTy += HGtcMGrtPaZkUjTy;
            zHUgoqBG = ! zGQrlyZfoSZTFDUX;
            ekaJxromwmQcUM = ekaJxromwmQcUM;
        }
    }

    for (int ubrKyqkfNC = 1504820343; ubrKyqkfNC > 0; ubrKyqkfNC--) {
        zHUgoqBG = zHUgoqBG;
        zHUgoqBG = zGQrlyZfoSZTFDUX;
        zGQrlyZfoSZTFDUX = zHUgoqBG;
    }

    if (HGtcMGrtPaZkUjTy == -482648049) {
        for (int HcClEqxCgeHDlaUX = 735817559; HcClEqxCgeHDlaUX > 0; HcClEqxCgeHDlaUX--) {
            HGtcMGrtPaZkUjTy = HGtcMGrtPaZkUjTy;
            zHUgoqBG = ! zGQrlyZfoSZTFDUX;
            zHUgoqBG = ! zHUgoqBG;
            ekaJxromwmQcUM *= ekaJxromwmQcUM;
        }
    }

    for (int LssPPTJnM = 938778648; LssPPTJnM > 0; LssPPTJnM--) {
        HGtcMGrtPaZkUjTy = HGtcMGrtPaZkUjTy;
        zHUgoqBG = ! zHUgoqBG;
        ekaJxromwmQcUM /= HGtcMGrtPaZkUjTy;
        HGtcMGrtPaZkUjTy *= ekaJxromwmQcUM;
    }

    return string("dLlPoInTkALOZeEtryfUoZvGejeBfoHVwGqxYMDIljCQrCkcySTJjxDAjzPLTPpHUaEpeHenwtKdQrCfRDgDvEZQDwYqnapeikXmOwxiiYNQruSxGSeygExpuSQAMSbqXEUAWbXFIbeNNLCZj");
}

void SqZVHCNtf::PjBcrTJo(string aNOESBcrnhJN)
{
    string upVUqIuwCoyX = string("hauMqczKEiCigqtKPzvkYKsRmvFfrtXH");
    bool bomoSccmnpGmehiS = false;
    double HaNjmc = 287461.2817789034;
    bool QkwzujHsgCulOo = true;
    double IypLdqjCxjBY = 72706.65675053428;
    bool othfnN = true;
    double ISyhDtmW = 689374.8350728771;
    int MghtsmOQYzHHhd = -1717595971;

    for (int XQKcHg = 748595505; XQKcHg > 0; XQKcHg--) {
        upVUqIuwCoyX = upVUqIuwCoyX;
    }

    if (bomoSccmnpGmehiS == false) {
        for (int tsiuoNO = 701698982; tsiuoNO > 0; tsiuoNO--) {
            aNOESBcrnhJN += upVUqIuwCoyX;
        }
    }
}

bool SqZVHCNtf::rsLDGHRquiPDdA(bool dXlAtzLOyAAo)
{
    double kTdqQBncrxrqP = -90137.64807608128;
    string remQT = string("OIUllxFTumujhzRRnCLHMbCvENzygLwViUOcqUiUDmAlHNQzCzJWaIxcFdMihgdUzMAoyxvnjlTVjVElVGIBysznYpZKSIpYQjuYzovdZKddBrqcYuxXyQBTbzxaBZFcFuqESvbqzauToCDGfZXIhJJeLxyngGKxfOzHGwbZWypvzDKJACeRdITRUhOIVkwQUhQuYczaZldvBgNXKpOmKBPyn");
    bool mBLqK = true;
    string zCeYtjkDf = string("jWBcDWjHWJTqeAlfwPUPYaYHCBDOjnzEJhtTBIKzHcFkBIJAFZBtAXbAuWlJaoorFCqUIhGfCdNMJHfoMvgKjhrABcxAZDohaSHIoFNMCvgwriXkExrDqrGLLVgsuxWZjsOyWZmRQGKGeexqy");
    string aYVQJjScTAvYAIDe = string("VwIRGhKWPtpZQtywJJMdCFMOnLaFcYBuCMSjSlEOOBvrXYbstvMnnwBppCHEFVBTNqvZLcEDUlCNmrRISMXswEkRdqXxSZlvcluRcskbcHAXUkpPsRifMjFYsfnxKRBtCYFhubVsJACwuHsZFmPDSpfZevxnyLyDhRXsBVTZFHajrwhsrCpzNILlAEuLWHkzzTYOPyDhdjnWFwGSMfxqBepEvahpUECBCKCpMBnaetSBB");
    string pkMZq = string("wTabmwKXHuOYHpJCzKXQeyKggvczXbWKpkoURYPgvxyMEvSDpWzsERNBgPgPkNvDXumXKUDVDuxDFeshdpFJSAbyxfObCyLZHuhJfsJIfQhnbYZsLhXZeU");

    return mBLqK;
}

double SqZVHCNtf::kUsoYua(string kdguj, double JligLrDHjDESIZ)
{
    double wFscrHCIH = 916549.534143019;
    double oNncVZkPUna = 1038362.6802304244;
    bool pMxtrnO = true;
    int DpOcgosS = -1422900033;
    bool AKKktLemyf = false;

    for (int XOGzHyDynnJcxKG = 1604399521; XOGzHyDynnJcxKG > 0; XOGzHyDynnJcxKG--) {
        oNncVZkPUna += oNncVZkPUna;
        wFscrHCIH *= JligLrDHjDESIZ;
        DpOcgosS -= DpOcgosS;
    }

    for (int OKkjD = 239246973; OKkjD > 0; OKkjD--) {
        continue;
    }

    for (int vcCoZRngbaR = 2121964903; vcCoZRngbaR > 0; vcCoZRngbaR--) {
        continue;
    }

    if (pMxtrnO != true) {
        for (int DDezSGwkcBoZXL = 1383610776; DDezSGwkcBoZXL > 0; DDezSGwkcBoZXL--) {
            continue;
        }
    }

    for (int ILkYrldGcGhT = 1235503297; ILkYrldGcGhT > 0; ILkYrldGcGhT--) {
        AKKktLemyf = ! AKKktLemyf;
        oNncVZkPUna /= JligLrDHjDESIZ;
    }

    for (int eFpKoxJzhmbFvmX = 694150518; eFpKoxJzhmbFvmX > 0; eFpKoxJzhmbFvmX--) {
        oNncVZkPUna -= oNncVZkPUna;
        oNncVZkPUna += JligLrDHjDESIZ;
        JligLrDHjDESIZ -= wFscrHCIH;
        JligLrDHjDESIZ += oNncVZkPUna;
        pMxtrnO = ! pMxtrnO;
    }

    return oNncVZkPUna;
}

int SqZVHCNtf::TTNKzuRCaXDRO(string gIAEKQrxg, string XOwAUXBhUSoBpK)
{
    int gGxKIcHBD = -51907570;
    int QFiwUDUdSuggrd = 1223162204;
    string dShqODNY = string("YRMeKvKvwVdIflClREEGRltPbBOmSjKDSEHkPtTlU");
    double vNtSEaeoGNBGG = -580166.898021737;
    string hryhTrnygWc = string("refiwOZopNhklbbObPbbJKruOEBQUfWkxtBsmzvIFvJXCCAdSSmXIQDSsuJkBWjaDWOzBRaVhxRochmhcxFZEFeVtojxejOejZAMDWKfFihZBWMuSGMXGYlxuhJlMdWDzKrNoVhnWRQIForevcsSN");
    int fbgeB = -1552404951;
    double KAVlpVQyX = -21393.49168077111;
    string oSAKNRwdtppi = string("yOFwAyGRMtkZBoJwdPPDZnFsrsHrtCqkawwJTfogwPSfYpXoMImUQbLcRWFNIUfZLdnFKNTXXjylaZjhRuvuaLuKOATorlmcKojZXMLXkhreqvkxjFzfkobiWwzqq");
    int FdhGGemJkqryCdfP = -1882054352;

    for (int YbKQfeNwecO = 1081429217; YbKQfeNwecO > 0; YbKQfeNwecO--) {
        XOwAUXBhUSoBpK = dShqODNY;
    }

    return FdhGGemJkqryCdfP;
}

SqZVHCNtf::SqZVHCNtf()
{
    this->yMZPoMqxg(string("xJuoEvKDrNFZaQBpxQGvbQfRZHtspravoIKeYQjUMGWcLBmtsylzcbvIfenAwkmEnx"), false, 1076196478, false);
    this->RlYNpP(711813.6459888914, true);
    this->UMESuNXTAHvxy(false, false);
    this->yUPTMnaXekQCkba();
    this->ABMIhgtWO();
    this->gMIjkmpDk(string("JiVqxwTZsDSlGNrNgQebVbxkYLRjtyrGEoYKNogeltvQcrZssgrwsYAhxANOIGYQqHzkKKOAxKtZOZTrQxdabMFYpyCQjyOQTGXEoTyOdE"), 1031280.645560814, string("QfVrmAnbWJYmaidRKSsninZyYQfFjyEUtsRuNLmOsgbuZAJckGC"), 184160.285078511);
    this->KbRWneRhdK();
    this->PjBcrTJo(string("OUgOyPrxORprOzBvAYzAytiCXSpYckfpVWpCiPqJJOYjpDeJqzGfPwJJAfjVOKvqjYwWpguKXjeKEvuBLUwUDexoUncBkizCRfsAoeGsyGuiOHsQPBkgTWvGAwZlKPOlljErVMuWWlVmaGVKOzeDkIbqWD"));
    this->rsLDGHRquiPDdA(true);
    this->kUsoYua(string("XSvYDhGGdntFCwYFIpAHEYOtucYjqFgpirCoeoHRqZhOOkXCRSsyposspsUOUKAHeDKGoucNeNifySZFVvQLtCYsmVrJbdqVqQPjkwaQXaXGTvKHwKUWhAivCgGRrLDWtqtJZahgIToxSNdBfcyIsohGrjsnmpCScQuFgiYnQSyGuAfYVrwlDHIRaCZ"), 668282.5792582884);
    this->TTNKzuRCaXDRO(string("bofUfgpNwXbuHrXTdBIAtWgSOCOVQvQPZBiiLWPkVtkVOzACfYUYRuitynWZxlBUtwMikQXqZmKdMXKSQJnyRy"), string("soTkspaIbZmvbUhOODCZMbiNWNWEvLwFCiKvkaSMNJoWwpQaCoodGeydycQlkMewJkfWpZXETTdsOFSP"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qmHWK
{
public:
    double TGHtOXZzu;
    string Zwadsn;
    string ljfeg;
    string mGhQu;

    qmHWK();
    double vabJf(int MTbIgZO, int pesmsGuAH, bool XSGJcS, bool xlODxKnEwTIIq, bool sRRjEE);
    double IpCxg(string CUhgG, bool qcaKPCvvmbomQ, int MMSqlhwO, double SEXoDiqkKDbFia);
protected:
    string gFBMpssIOB;
    int ycrezLIHyv;
    int kkkcLTjQxuRN;
    string OQSLdTCChxkN;
    int EfmcmSwjbYulSmC;
    int cXcxVCITtLvAcRs;

    bool ZAkhFYWofVH(string jRyApQcxttVC, int hEBajwEP);
    string KvBWsSqLY(double yErcwuG, int osDXOZi, int pyYDKvveK, bool ibFwWUP);
    int AuBGDNdq(int TRwOiyqiKbIahLFK, string Nkbed, string mXtljzkwEE);
    void MnhhLDFbLcFw(string mjKuJXPKZOnjgmT);
    string YvYaAbMXrBHaAtiK();
    void Boaht(string pXwsU, int wDpPnL, int TOjRiHOuAH);
    string MBzOIxcZ(int QlWHcSOhvtaUl, double xfHREtcSaYIv, bool kbxSrGbU, string PyLVqcEANOy);
private:
    bool bhNFoYxncXqA;
    int tlhxPOhvb;
    bool zXIolPUnSZuXoEMt;
    double hflQUh;
    string QVitw;

    bool lRMUxxJhvyr();
    double RInNzhgpbMWWKY(string tVEBl, string xEHOb);
    int MieeVGPPCc(bool AOmixlUTtDz);
};

double qmHWK::vabJf(int MTbIgZO, int pesmsGuAH, bool XSGJcS, bool xlODxKnEwTIIq, bool sRRjEE)
{
    string NrTaN = string("kayKGVALZzENEpYnomxuyXhfWsIrdatZMWvTfVmznGzmYffRTPxYPqFRlJgumAtPoWzIZSyuOvXyAjIkPNIkcgeUZisdSrQllmWatyuDsedoMucYmukqHQmGGIjBEbCGQgFOtLLaJmWmLTFSYaqBYANCUpPvgQqCSvtApfmaJhtEJMPoswpj");
    bool iXGLlc = true;
    double iSfFg = 552714.7728327661;
    bool soyzfyzZLiCBcDgI = false;
    int SuqOspTplbMgum = 73126270;
    double IwXlGGCmnn = -664478.2288556471;
    double WgqOscuLMqS = 541231.0649860522;
    string MgIsIWkfTMWVN = string("mmUGNmAWfcfgSMZNkKpajZuMxjZCFWZikzLiaYJtOcRSrDIcZsdKNzPVPddjHRxFcUNPwBfdfvcXUZkcuZBWOtFKoxVytEmpafgW");

    return WgqOscuLMqS;
}

double qmHWK::IpCxg(string CUhgG, bool qcaKPCvvmbomQ, int MMSqlhwO, double SEXoDiqkKDbFia)
{
    string GtPQjbOE = string("VXyWCMLXIKMixfjMOoBYtEqhEhBJvfFvdcBqIrRdFDVGTCmUqyujyKbFXDWjIhILVmVmHHnXXwcaxiHoyfiweSHyaQYpAAdqtrVsFhLgZnpiXaIqHnmyfBEYXbTMXWgajzouahgnlDtjoWTlDjHvKAuTShxuFnzbNfdYfSvOLEzeJGd");
    string GcNsRbYgzau = string("fnGiODAMvNpkJGkkeTIHhgotcenvHc");
    bool FBhMpypvxQfJEvT = false;
    bool eyNhuaEWUqfzemBU = false;
    bool wfugOsSR = true;
    string DfgciXxOXYQa = string("SVcwaCCoUASWKXkLgDuzMjPyZUsiXFjnniTIYQhvfRwOfWlTSgwBgOGFMJxdbhLszORnastXyoJGpPzqcnupQjSAQtadQiseqhkuPGaQaXXCKoDLcuETvPayrbUBwvWfASzwXBDVRnbaxbYRbgMoLIyDixbmEmimKERrIGPRIrDZOjsJjBcOLwMaOTEgoqhzVmbHZguMCwHXwojcTUhzblMU");
    double zmxvG = 35967.48523450909;
    bool oGWDojYa = true;

    if (CUhgG >= string("YIAGRHRQHIgXeVubqnpguVxZCBoBsKETJLKpzxIQpjsAsUymcEUBXtNGfrqPtkTKRuEJmDRlMhtaLXYVGGfMBYsXHdSbyZJoluBTrydnnAYruTidSTDDthhzMfYIfqTZSMcZWAdxOcjDqYBrAOptxyZpnBTXOnmXthyyXzzUoTbaHdSxDuuByuFDvhVLGnEUCafdUqBAxpGMeQHsLN")) {
        for (int OVDRHSAeTKSjCLji = 1354960005; OVDRHSAeTKSjCLji > 0; OVDRHSAeTKSjCLji--) {
            eyNhuaEWUqfzemBU = qcaKPCvvmbomQ;
            qcaKPCvvmbomQ = qcaKPCvvmbomQ;
            DfgciXxOXYQa += DfgciXxOXYQa;
        }
    }

    for (int vLEgovBusMI = 1423895545; vLEgovBusMI > 0; vLEgovBusMI--) {
        GtPQjbOE += GtPQjbOE;
        FBhMpypvxQfJEvT = qcaKPCvvmbomQ;
        DfgciXxOXYQa = GcNsRbYgzau;
        eyNhuaEWUqfzemBU = ! wfugOsSR;
    }

    for (int yFwgESh = 1014207697; yFwgESh > 0; yFwgESh--) {
        eyNhuaEWUqfzemBU = wfugOsSR;
        FBhMpypvxQfJEvT = ! oGWDojYa;
    }

    return zmxvG;
}

bool qmHWK::ZAkhFYWofVH(string jRyApQcxttVC, int hEBajwEP)
{
    int QmewbqEPauoD = 1599608224;
    int VvdzTCqdtw = 900645469;
    double XswtpGej = -428578.74154207425;
    int vRhAZZkDmTEtNER = -514573101;
    string ZlzBYzjXijblrv = string("yKBYIBqMEnzaVDfVlYlzRNavApNKlQhNpJuiUmFZkmimbzAgqSWZTVkIAOzBn");
    string KxveAOMBQr = string("tAwzycBVNNPfETRcokihgAkyXORObZAyxwfPetIJSTxCRyfHFRBcmkgZAYPauFhrMVqtvioFWOmgeGbHpmOThUkiXNOXNNYPpZxFWqAmfNhbxECNQqURmU");
    int BTlKoYWXa = -1158672866;
    string pSUVCTElwzMVBkZ = string("DIoaaHVfxcx");
    string wlZqdonkgO = string("fcnCFXFTjPNZtNrpsfgDJkezgaOWxMkCauedIblYImtUvMLDhgocJCMNFiYdGavUPDKvtSGkBUtPXLFISVzslUGfwvKLQsLbMEPsHfpQxoguknECkayehzMYHYCiiFykQwAOSjIlIUCKDHgLh");
    string voorabLgjNcuYAQ = string("JVDlfPCtWEIXHiAhUezrXrhoyLazVfxMKsjGbIEDQgIMMigtfZRABFwWMRhVoRFVXTSVCCNncBAQlFjdGyydVjQJWGdbSBkJVDzVRKmEUotdqaPRtSnkcGqlfYSFyuBhWazUuuVlymohxZaWXUtPrtJLkvCjHOJDUrEecKpxuxZPqNBBtkhDGMnuORKamXiiMktZtRygXeZeFPPHiMpCEPpRDIvTqbxamQGzRJUlHfNJoopfYrGdBcF");

    for (int iztDJBiC = 283346971; iztDJBiC > 0; iztDJBiC--) {
        KxveAOMBQr += ZlzBYzjXijblrv;
        VvdzTCqdtw *= QmewbqEPauoD;
        XswtpGej += XswtpGej;
        ZlzBYzjXijblrv += voorabLgjNcuYAQ;
        pSUVCTElwzMVBkZ += pSUVCTElwzMVBkZ;
    }

    for (int tndCtMHHhgbUOn = 214698574; tndCtMHHhgbUOn > 0; tndCtMHHhgbUOn--) {
        ZlzBYzjXijblrv = ZlzBYzjXijblrv;
        KxveAOMBQr = jRyApQcxttVC;
        voorabLgjNcuYAQ = jRyApQcxttVC;
        jRyApQcxttVC = ZlzBYzjXijblrv;
    }

    if (ZlzBYzjXijblrv != string("DIoaaHVfxcx")) {
        for (int KEpFgjQv = 1780167454; KEpFgjQv > 0; KEpFgjQv--) {
            BTlKoYWXa *= hEBajwEP;
        }
    }

    return false;
}

string qmHWK::KvBWsSqLY(double yErcwuG, int osDXOZi, int pyYDKvveK, bool ibFwWUP)
{
    bool ePDrkljvccPdUlZ = false;
    string OBdDuawXNHWYZMl = string("QCXFvVfvEbmpvvHdvbhSdRNgKiiFpooMeCDByJcewHowLRMxXuHpVzLizhglHXwpBkXmIWdGtjrfUQiVKQBpGCabkOkRRwiSTBqSrsSDGlYNpYMnNOAztyYJxkEXzAoRjAknuZhoMykLbrUdYWIzIxiBrnrAEwfqmEkKdvgpgxdtPZHZvHONnqrMDjpdrHDegeCzsknAEGlVtBzcBtHbgeruKGGuFkcFjzekUferPtmKdt");
    bool XrtZl = true;
    int YZYqQeTScDwHUJo = 986980217;
    double rcwqwTj = -115578.57690385712;
    double KAYjAQqyuBCSWli = -276857.16781688406;
    double UpMXvHVn = 388751.31701001356;
    bool BqgQExZ = false;
    bool YqVCFWGACMYdzkei = false;

    if (UpMXvHVn < -115578.57690385712) {
        for (int wxPMsCfBxgxYmHyd = 211436021; wxPMsCfBxgxYmHyd > 0; wxPMsCfBxgxYmHyd--) {
            XrtZl = ! YqVCFWGACMYdzkei;
            BqgQExZ = ! BqgQExZ;
        }
    }

    for (int AfXqCsako = 553737185; AfXqCsako > 0; AfXqCsako--) {
        KAYjAQqyuBCSWli *= UpMXvHVn;
        YZYqQeTScDwHUJo /= YZYqQeTScDwHUJo;
    }

    for (int UDLdYRkcEloS = 1782120564; UDLdYRkcEloS > 0; UDLdYRkcEloS--) {
        XrtZl = ! ePDrkljvccPdUlZ;
    }

    if (BqgQExZ != false) {
        for (int qnHUCLysS = 1396533211; qnHUCLysS > 0; qnHUCLysS--) {
            YqVCFWGACMYdzkei = ibFwWUP;
        }
    }

    for (int eWaakEppc = 184037556; eWaakEppc > 0; eWaakEppc--) {
        yErcwuG /= UpMXvHVn;
    }

    return OBdDuawXNHWYZMl;
}

int qmHWK::AuBGDNdq(int TRwOiyqiKbIahLFK, string Nkbed, string mXtljzkwEE)
{
    string pruVOhTWStqKi = string("xRlHFRilTGyzhbnBnOraPMoAjdXnxpSzWgj");

    for (int NIjSZza = 237635670; NIjSZza > 0; NIjSZza--) {
        mXtljzkwEE = pruVOhTWStqKi;
        Nkbed = mXtljzkwEE;
        pruVOhTWStqKi = pruVOhTWStqKi;
        Nkbed += Nkbed;
        mXtljzkwEE = Nkbed;
    }

    if (Nkbed != string("yClefpkKDzaDWMAZEllhDaHQtgFCYZRrnmUeePsQesOxdQMhduIWeZVTVXTjljQNfQqjXkvqlgVvwfOodepjLuoPpAVKDhHEJIdUkmGfJuNgXRiEwcpCahZVCIoXusidlCwJHFBkmzvTEROtECOgukZyChsujcJvAucfDDVPpqfScIoEPgDCdRNgdwhKpBwjCuGFfE")) {
        for (int PLwEdvCLHOXUnkiB = 1999879486; PLwEdvCLHOXUnkiB > 0; PLwEdvCLHOXUnkiB--) {
            mXtljzkwEE += pruVOhTWStqKi;
            mXtljzkwEE += pruVOhTWStqKi;
            mXtljzkwEE += mXtljzkwEE;
            Nkbed += Nkbed;
            pruVOhTWStqKi += mXtljzkwEE;
            mXtljzkwEE = pruVOhTWStqKi;
        }
    }

    if (pruVOhTWStqKi >= string("iGkxu")) {
        for (int UVndymbSPYGD = 1286430613; UVndymbSPYGD > 0; UVndymbSPYGD--) {
            pruVOhTWStqKi = mXtljzkwEE;
        }
    }

    for (int ogtXhgRiBlzJO = 1260327932; ogtXhgRiBlzJO > 0; ogtXhgRiBlzJO--) {
        mXtljzkwEE += mXtljzkwEE;
        TRwOiyqiKbIahLFK /= TRwOiyqiKbIahLFK;
    }

    return TRwOiyqiKbIahLFK;
}

void qmHWK::MnhhLDFbLcFw(string mjKuJXPKZOnjgmT)
{
    bool PRffNETNdy = true;
}

string qmHWK::YvYaAbMXrBHaAtiK()
{
    double AFwZRzhw = -8486.57943946462;
    double ylQEYhZ = 780640.2607889692;
    int OtTybLbwkskgvhW = -968694935;
    string EYrIcVlfILvHvIBC = string("UefVPYdDvLmWhSuAXSSDffyZtVzcEAymmyvDry");
    double kykcLkCDBqHlRT = -730452.1040991785;
    int EzFxdIPghXfDs = 731241715;

    for (int BIuoxFsi = 1416266667; BIuoxFsi > 0; BIuoxFsi--) {
        continue;
    }

    if (EYrIcVlfILvHvIBC == string("UefVPYdDvLmWhSuAXSSDffyZtVzcEAymmyvDry")) {
        for (int lHXNXKclM = 1627766363; lHXNXKclM > 0; lHXNXKclM--) {
            kykcLkCDBqHlRT /= AFwZRzhw;
            OtTybLbwkskgvhW /= EzFxdIPghXfDs;
        }
    }

    for (int oUKdseWl = 303993988; oUKdseWl > 0; oUKdseWl--) {
        EzFxdIPghXfDs -= OtTybLbwkskgvhW;
        kykcLkCDBqHlRT /= kykcLkCDBqHlRT;
        AFwZRzhw = ylQEYhZ;
    }

    for (int WRdRmQj = 877226644; WRdRmQj > 0; WRdRmQj--) {
        OtTybLbwkskgvhW *= OtTybLbwkskgvhW;
    }

    return EYrIcVlfILvHvIBC;
}

void qmHWK::Boaht(string pXwsU, int wDpPnL, int TOjRiHOuAH)
{
    double JYzHBVlPcqwfsIIx = -339163.99571554846;
    double mqqGYRMgwuqn = 555153.102948091;
    int obbdVunxBJEuFb = -586460493;
    string kwhCMKpdSmpJC = string("cjQZHZrkjdOeOalbPgfzZqNtNllrBEhskjgYSSChuTdcmEbSvfPOUQZQRTutQhpwaHBbwzqDQJToOssThtGiTzAVkVEqGBoQqHZwiWZpXwBnuyzHTrSA");
    string ajyFlxUBfIjDN = string("hWwFZmqKBbJFkIFqifrYyfFuoXDteHHQaDxNAqVCFvxwEbAcMrLwxMWzGVPqqxTZDQbjyPimisjTfMhOUQtKRgThuTXNsMoYrPCLYxNqtiEXUuIySIVRtgfCBTPRmgliZLlVGVkiACJMtZeDOwsKfUUQeGPdwxbNbyvpqlTegEcPdEiITRrVdSaVsjVUxQMJsXKnPlUwQXwcZnRTqdmycaLolmVbNzuxqLyEVCMo");

    if (obbdVunxBJEuFb == -1353574373) {
        for (int sjxvSwCI = 626977342; sjxvSwCI > 0; sjxvSwCI--) {
            ajyFlxUBfIjDN += pXwsU;
        }
    }

    for (int ZyGTJtfGTlOOeePj = 1731304126; ZyGTJtfGTlOOeePj > 0; ZyGTJtfGTlOOeePj--) {
        obbdVunxBJEuFb += wDpPnL;
        obbdVunxBJEuFb *= wDpPnL;
        mqqGYRMgwuqn += mqqGYRMgwuqn;
    }
}

string qmHWK::MBzOIxcZ(int QlWHcSOhvtaUl, double xfHREtcSaYIv, bool kbxSrGbU, string PyLVqcEANOy)
{
    double orqepyeUxtMoGbk = 53807.82580244653;

    for (int GtpaGnh = 1337940070; GtpaGnh > 0; GtpaGnh--) {
        orqepyeUxtMoGbk = orqepyeUxtMoGbk;
        orqepyeUxtMoGbk = xfHREtcSaYIv;
        QlWHcSOhvtaUl += QlWHcSOhvtaUl;
        xfHREtcSaYIv -= xfHREtcSaYIv;
    }

    for (int DzvVNvqGNdO = 195288979; DzvVNvqGNdO > 0; DzvVNvqGNdO--) {
        QlWHcSOhvtaUl *= QlWHcSOhvtaUl;
        PyLVqcEANOy += PyLVqcEANOy;
    }

    for (int JSdEVrEix = 188932064; JSdEVrEix > 0; JSdEVrEix--) {
        kbxSrGbU = ! kbxSrGbU;
    }

    for (int SSmrlRMtuTpAqPi = 845314434; SSmrlRMtuTpAqPi > 0; SSmrlRMtuTpAqPi--) {
        xfHREtcSaYIv += xfHREtcSaYIv;
        PyLVqcEANOy = PyLVqcEANOy;
        QlWHcSOhvtaUl += QlWHcSOhvtaUl;
        PyLVqcEANOy = PyLVqcEANOy;
    }

    for (int qSUbEDXXitMURs = 1009022579; qSUbEDXXitMURs > 0; qSUbEDXXitMURs--) {
        orqepyeUxtMoGbk /= orqepyeUxtMoGbk;
    }

    return PyLVqcEANOy;
}

bool qmHWK::lRMUxxJhvyr()
{
    bool BwJbCiri = false;
    int UIJPzyinmLAizyt = 473159557;
    string ksqQQokxm = string("cbUvKRvKqPkQCHoymJfphNbkANKkwhIjQJlMSalPpvCcpkmEZCYPwiSgaAyUmPtuiGNoYyilOpEtUFYrDQGDcLVsfAIeXrRugfZkJRpnTYHpvfXxJaesbTWNsqXiZTiLIsSmncEKRStJwJsnNkyPUvnWVscDaANhpQOiIxrghWJqfeCszLxlwgfmkDcNSoZguJTKFEX");
    bool ZDGYRFMcrP = false;
    string fmyOnfgeIOBL = string("biOHMaerEsrECexjYCtyZdrfvyqndoheodBqqyNmZLzHPzLjBGKTCtHDprlSgbejXRmfiTAgBPKNThmIWVPkOqdytPoPRAQGFwmPGZVfSVXoXaNQmuQUbDZQbMqSicXpMMpFnjZRmAhepynzEeZwtJVwayepoehroYAbCaOLYnWaSYDvfhYIEJgRxvGufLELmTqtiIPgYfISyalMHHsbUJpWVQYMeETotdqegMrDHDLW");

    for (int YdavaVTksx = 674435576; YdavaVTksx > 0; YdavaVTksx--) {
        fmyOnfgeIOBL += ksqQQokxm;
    }

    return ZDGYRFMcrP;
}

double qmHWK::RInNzhgpbMWWKY(string tVEBl, string xEHOb)
{
    double BYAVAPvEilG = -696326.0417090344;
    string DYRYqe = string("ZniSQtSoybBMpgPtWJJBywxuClDepsvvpqRFBtUyMsBPfjxCcqmyWnKUdEeUGrYKGDAfbjcLKWZQzcWTMetHQyMvsVKwfLjcoYXhXBkSomcDOaDhxhMRizeSVMbWqkPIqpXvJITcglvTkHOXUkNqCvqafvVafupAzuUleykUyOJhVdtffoTZJyVgcjqVWraBUokVoRlZNmjnDXKhLXZICrtlUfVExxttCIwCCLfcRRtMqrFqYdFPRcRXRGDKDBF");
    int oaQqgphO = -900744565;
    double RyOaBYgbArJzTGs = -70569.16491776521;
    string vJorZZ = string("lCRxanabJnoAhRoYcjTHlLblqqyjIIrUDKgTJJsTzHvQiaoMXORyowjRIJitDIRBZmiXjtBylOYGGAhshodIKEYZUIRdMaCfJXBssAvtQpYRRgGrXduMnIWrLKChoRxnWQcQqtvlFpMNhznQrqOMDThydQfITCJAewPjHedsYepowOHiNUmMCgNbDejBVtUAtAWJQxwJdEwrzSuZOZiQWeZyMswqOV");
    double uqJeFmBmSguJ = -117661.06136733915;
    string SYUWJvY = string("ZkKSLCnyNUiksSyKJQIvhOTOtnGvmkRItmcyPGXoBLJEVJBYjcnMqQtLEwzDlFWzDPrjVnQCTbaNstELGLzNkPyWICrlDxxZHXflHKAcMExQUMLXxtFhEqIfMulgLHpBfTwXUYrjkloyCtrukpqrwkkNcoSYIQbXeppaxUjJORFTBOytlwYxfzvgJqsvLhnHQQEkrQHwfNyIltBVBtFieJwZjTQvSxWTLQpaLkjUtnQkSdMQfFVbSexYCKUsrO");

    for (int mCBCpSbdNmQ = 1169896362; mCBCpSbdNmQ > 0; mCBCpSbdNmQ--) {
        continue;
    }

    for (int wVfkKdoxHuNenlBS = 1089748284; wVfkKdoxHuNenlBS > 0; wVfkKdoxHuNenlBS--) {
        vJorZZ += vJorZZ;
        SYUWJvY += vJorZZ;
        DYRYqe = xEHOb;
    }

    for (int TtrgdcEKRVDk = 1672595429; TtrgdcEKRVDk > 0; TtrgdcEKRVDk--) {
        SYUWJvY = vJorZZ;
        xEHOb += tVEBl;
    }

    return uqJeFmBmSguJ;
}

int qmHWK::MieeVGPPCc(bool AOmixlUTtDz)
{
    int FwxvuGKkrVWMWn = -653262206;
    int pQtzFXXDOaBhy = -1541356454;
    double YsXguZjaWlbj = -889831.9405556571;
    double TWscDEJnzclZzwNT = -29966.847095033827;
    int vtwunDThniucrNF = -75168845;
    bool lsOffR = true;
    int ikwSeeGAArhXq = -303052284;

    for (int MnlNMeuHmVmEaN = 842358638; MnlNMeuHmVmEaN > 0; MnlNMeuHmVmEaN--) {
        FwxvuGKkrVWMWn += ikwSeeGAArhXq;
    }

    for (int riSHbhjgOWh = 1438892796; riSHbhjgOWh > 0; riSHbhjgOWh--) {
        FwxvuGKkrVWMWn += vtwunDThniucrNF;
        ikwSeeGAArhXq = vtwunDThniucrNF;
        FwxvuGKkrVWMWn /= ikwSeeGAArhXq;
    }

    for (int wMBgpFEPGpuDov = 1657979985; wMBgpFEPGpuDov > 0; wMBgpFEPGpuDov--) {
        TWscDEJnzclZzwNT += YsXguZjaWlbj;
        AOmixlUTtDz = lsOffR;
        ikwSeeGAArhXq *= pQtzFXXDOaBhy;
    }

    if (pQtzFXXDOaBhy > -1541356454) {
        for (int PCMietBmYih = 992696617; PCMietBmYih > 0; PCMietBmYih--) {
            pQtzFXXDOaBhy = ikwSeeGAArhXq;
            pQtzFXXDOaBhy -= vtwunDThniucrNF;
        }
    }

    for (int EYQSMcLH = 20680115; EYQSMcLH > 0; EYQSMcLH--) {
        pQtzFXXDOaBhy = ikwSeeGAArhXq;
        FwxvuGKkrVWMWn /= FwxvuGKkrVWMWn;
    }

    return ikwSeeGAArhXq;
}

qmHWK::qmHWK()
{
    this->vabJf(434900132, 889174258, true, true, true);
    this->IpCxg(string("YIAGRHRQHIgXeVubqnpguVxZCBoBsKETJLKpzxIQpjsAsUymcEUBXtNGfrqPtkTKRuEJmDRlMhtaLXYVGGfMBYsXHdSbyZJoluBTrydnnAYruTidSTDDthhzMfYIfqTZSMcZWAdxOcjDqYBrAOptxyZpnBTXOnmXthyyXzzUoTbaHdSxDuuByuFDvhVLGnEUCafdUqBAxpGMeQHsLN"), true, 485110172, 402598.3591095354);
    this->ZAkhFYWofVH(string("HtZaXPGJMXfsiiXkFeznuEgyaMaXcZXLTsfMfiNoCNwaaBuUVsEnrQZiRXaaudBFMDwbkEXMvYXQSpLIZzvpGIzIWeTLKAEiLGRuuaXGicOwtGOYH"), -1422694592);
    this->KvBWsSqLY(-619398.9563544182, 1555863182, 361130863, true);
    this->AuBGDNdq(-781176836, string("yClefpkKDzaDWMAZEllhDaHQtgFCYZRrnmUeePsQesOxdQMhduIWeZVTVXTjljQNfQqjXkvqlgVvwfOodepjLuoPpAVKDhHEJIdUkmGfJuNgXRiEwcpCahZVCIoXusidlCwJHFBkmzvTEROtECOgukZyChsujcJvAucfDDVPpqfScIoEPgDCdRNgdwhKpBwjCuGFfE"), string("iGkxu"));
    this->MnhhLDFbLcFw(string("ZYisEjstRvSUqztIpNgAIxYsNKStCyuSRMhfQIGWfCcSPmaVdNomDGRFEuhpoMYjDGmAtdCWXcsJfGKB"));
    this->YvYaAbMXrBHaAtiK();
    this->Boaht(string("BcuECzuCtQfJNeqbBBldP"), -1353574373, -1368016827);
    this->MBzOIxcZ(3584419, -938006.0813547918, true, string("hNFKXjpVPQDhoVonTDKnIAOXfiRLicPfMEUhphkWwGXLctCCEfNeZyvcOyWMHk"));
    this->lRMUxxJhvyr();
    this->RInNzhgpbMWWKY(string("GrzHKAPEpdzwwmRZrdSLficTqdAhzUJAvzhlnlaPtxqAxhjdXDnKYYgrXAQGMZtHiBLOGipvNfIXzWvakRjvgWCHwgCLIkNFWkhtNyetBlreLgwDADugqSMFdVwKNAJSjYCExivARxArOrPcCLkOuGoByePmKTHsotVUYTgpmzPuFBMwknMCAYggfTYOuwGcSQZXjcMQWYvilTDthDFpQlXrzHMTcKjbONJNfFhMUVwgxmvKXV"), string("lfyjjKMcZdcxrhpVQdfDrEjzzRTuQUIxufgOnYhfFUcCKJJkZSRExVhGuSHMxbarGRCNWIHCSyToIDELmSjcbOzzHiCgxizBoBlkDeFYTIWFdwiPKjuOOWJWWXQlCjHBCumFOKfokpTemIolHnWXHIXMYEHqcPAxWvvxWhMPndHgvJVLsCjeZCIxZvNZrlOikDhFPhUywBBBQpUdwWEMcDRanRPiiXhcNZTZnwtCMRhkO"));
    this->MieeVGPPCc(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LZkEOzu
{
public:
    bool DhhbRUMAaYAvUEYi;
    bool OPHVHAyKUOCX;
    bool sjPxfuFauhQ;
    double oZelOVtoFmDBvklX;
    bool fFGdf;
    double vNgidBwZliZx;

    LZkEOzu();
    string aCqDcNl(string wlrCNOvE, string opEnicLFWsHbqOh, bool fJdMMwbAxc);
protected:
    int TgYovogKJjSmBNG;
    bool RIbCeElymLCQsB;
    bool XzSpQ;

    int dkAlryUOEW(double ApSLpCQDkAkKDqtC, bool TjUeeClujC, bool gXTrGdvOS, int nGcLIwE, string JfGgwwqKCgFA);
    double ziwLQfPDalPIfdNk(bool VROyCfXc, bool zVjNlBMlxBHXDElc);
    int iaEHoOUuNKUk(string cwpEcUpySfIFNkd, int CeIcTQbTeEZhC, bool ZWreA);
    int ayhDMDtYvxc(int MvmjkkhMf, bool kLlRCC, int thdDY);
    void FIDeESbdd(int FkwInocWgbtqb, bool ISdLIdO, int Mtrbniikd, string nwiGXFh);
    string AGgmaWTSrwi();
    string QpWgfh(string wYulLGzDxzoL, bool kFhPR, int GCsOp, double vRyqvitiiiYQ, string rvxIGF);
    void dIjxgYYvTaNbxhs(string hUCtIKLITrX, int SgnzErCMdBUrwtB, string uHxlqdPovvIA, bool usydRpgRUw, bool UakJOjBvsEdY);
private:
    bool MWECoQSZQHJKqZ;
    double qFAOt;
    int bZdBqGewPgB;

    bool nLkiPRNnnAuWSLZF(bool dIlawviqB, int gvKTZvQNP, int hPdcBAcXIO, double whOZhgz, string iizIlC);
};

string LZkEOzu::aCqDcNl(string wlrCNOvE, string opEnicLFWsHbqOh, bool fJdMMwbAxc)
{
    int BbHkMdbkyS = 404938756;
    string XUeCPe = string("XwfQdxkePznzUgFTVgePaBWRIiPYYCmTqzrmmffWwzieyBusQQRoAYabuIeUdRoJfDPcRyHMufMgdjxOKejjFNcrUViLogHcELoMhQdOCqhqPGVwyWYjKpEMvnJKSHheESvBYphtArYwVshVpHyYBULWtFKZDqxFWujMFlhDnBpQMCCDXbRMqOChpMSHMajWfqtpEbuUDCRGwHeUbnjRJQYzndNbhVbjrYKqGsnlQhjalzGbdzD");
    string JOJoqOJfQS = string("ffSMiGlLwxmGDDfNtAjEyWdUoRqDIcchkIvFAkaJoLnOuEkrHKIHtoprKyZJEvbtXKpcNTBSzFOhUbJVnrdmHdEHMcmuUYYgHvFhDzfWlbiNINEuhsnvOEI");
    double CFhnihPUv = 38047.129577531756;
    int rnPeqfazbz = 1549560286;
    string bdTsXC = string("AXoPVkfoExpyGQYragXDzBZJieNHINofUXyBAmDHipCuVjECKMmZQleDRqteqAATzyXogbikMaVHdSFKBShMoEi");
    double aMnOZPrL = -310512.03151129273;

    if (wlrCNOvE <= string("KiBJNoArkPtMTYOqRHZBtgeCdvSYgaWTdVeflRSPCVRLvNoQrDJWizH")) {
        for (int CttfcOjg = 1342059181; CttfcOjg > 0; CttfcOjg--) {
            bdTsXC += wlrCNOvE;
            XUeCPe = bdTsXC;
            rnPeqfazbz -= rnPeqfazbz;
        }
    }

    return bdTsXC;
}

int LZkEOzu::dkAlryUOEW(double ApSLpCQDkAkKDqtC, bool TjUeeClujC, bool gXTrGdvOS, int nGcLIwE, string JfGgwwqKCgFA)
{
    int sMjYf = -1876383933;
    double azvuuq = 523255.1535224879;
    bool MZzQspMB = false;

    for (int NLVqpYw = 751685830; NLVqpYw > 0; NLVqpYw--) {
        TjUeeClujC = gXTrGdvOS;
    }

    if (TjUeeClujC == true) {
        for (int xiUJMSjlOdg = 1602532056; xiUJMSjlOdg > 0; xiUJMSjlOdg--) {
            MZzQspMB = MZzQspMB;
            TjUeeClujC = MZzQspMB;
        }
    }

    for (int PcWmIBCZE = 1217977965; PcWmIBCZE > 0; PcWmIBCZE--) {
        azvuuq /= azvuuq;
    }

    for (int jXdvVbMULdSGCBiW = 623120317; jXdvVbMULdSGCBiW > 0; jXdvVbMULdSGCBiW--) {
        continue;
    }

    return sMjYf;
}

double LZkEOzu::ziwLQfPDalPIfdNk(bool VROyCfXc, bool zVjNlBMlxBHXDElc)
{
    double BcPYpYUsxI = -486335.7706232476;
    double kFSajPer = -670960.1608755572;
    string ytZAhlakfBRNy = string("gnIxXNZWyJGYRKvDorNSOfkYCfinRTTXvZPjFyvLZonWzSbzHubpEVqblcFu");
    bool jYvPjFfLPx = false;
    double BCHYJkTVN = 620070.9991099855;
    double TONHLKxltE = 647424.33346272;

    if (BcPYpYUsxI > -670960.1608755572) {
        for (int MgsMVIvgxsGWfJd = 34576346; MgsMVIvgxsGWfJd > 0; MgsMVIvgxsGWfJd--) {
            BcPYpYUsxI += kFSajPer;
        }
    }

    return TONHLKxltE;
}

int LZkEOzu::iaEHoOUuNKUk(string cwpEcUpySfIFNkd, int CeIcTQbTeEZhC, bool ZWreA)
{
    string samgkZjDrCXKfU = string("KRrJTNcfRceUfMzaxWWStQBgDTbBbqgSzqfZBFGsCjjcUGStYjhUsVNJTCXAZslVIimzFmKoSlicUSrUcUfWEzlwFoshQDIPuqWpbYlbFiOyllpIQvjKZFnCaMmwlMQfuILTLEVPdCFNjBMpDxdSPCiiKFHdntkCavNHjnSVHkZTJGMHZAkfemEDcmQrnieuB");
    double eivhXpBgowiIExBA = 109237.94842979392;
    int EXGdYGYv = 352377544;
    bool HLUHLIALyYznlZ = true;
    bool NGtKRVpLHLfLJFwl = true;
    string nZQEKQKKfRwriob = string("KVeLqKXuhDMqpShcaEBJwMgihMISAunhwKrkAeVZuPrwHdQmAWNsUtGgrJLiaOabegRyaHAxtUzYLJOeVUUONAqqByCJHbYumTCigzFPlrRPYGKVMtwYzAYNTbPotYNbDykjOkYaubuAnlaRaJpXaOCtDOByVuaRhucSoHohJZzUagjvYYgKUCnNFSTfzeGpZvXdyeJsKQNhIRASMyRCjvfasXLu");

    for (int mONKlb = 1846788036; mONKlb > 0; mONKlb--) {
        continue;
    }

    for (int BClWOTByzkSQt = 188244117; BClWOTByzkSQt > 0; BClWOTByzkSQt--) {
        CeIcTQbTeEZhC /= CeIcTQbTeEZhC;
    }

    if (nZQEKQKKfRwriob < string("KVeLqKXuhDMqpShcaEBJwMgihMISAunhwKrkAeVZuPrwHdQmAWNsUtGgrJLiaOabegRyaHAxtUzYLJOeVUUONAqqByCJHbYumTCigzFPlrRPYGKVMtwYzAYNTbPotYNbDykjOkYaubuAnlaRaJpXaOCtDOByVuaRhucSoHohJZzUagjvYYgKUCnNFSTfzeGpZvXdyeJsKQNhIRASMyRCjvfasXLu")) {
        for (int YKhRFQxH = 241416891; YKhRFQxH > 0; YKhRFQxH--) {
            continue;
        }
    }

    for (int TAMfZ = 1410127457; TAMfZ > 0; TAMfZ--) {
        nZQEKQKKfRwriob = cwpEcUpySfIFNkd;
        ZWreA = ! HLUHLIALyYznlZ;
    }

    return EXGdYGYv;
}

int LZkEOzu::ayhDMDtYvxc(int MvmjkkhMf, bool kLlRCC, int thdDY)
{
    bool xIDHXX = true;
    int hUeaNQHVEcFl = 1567646684;
    string ZiYHuRyRpHqRuG = string("KixgEPzWqhUYtAJAHMaLfObxzSskMmctbIlvAKMDmYIaxuWGhZUWSjbjsByhlTtqUAdGLpFsFXctpmfAuBfGvrORqpqNEyKanhcrxCvrhSUsmfarSwEguOKZcMYXyfBAFCvZzKkPRlElBvBShWW");
    int klZPbBiaKKLVkeni = -161772515;
    double hnTTrrIuoLXEuHQ = -113235.40535849906;
    double QugmDJw = 708609.883268252;
    bool qoDHRNpxH = true;
    double FFVJtEjDMaNZ = -48836.09449549789;

    for (int eOUpF = 1477824447; eOUpF > 0; eOUpF--) {
        hUeaNQHVEcFl /= klZPbBiaKKLVkeni;
        hnTTrrIuoLXEuHQ += QugmDJw;
    }

    return klZPbBiaKKLVkeni;
}

void LZkEOzu::FIDeESbdd(int FkwInocWgbtqb, bool ISdLIdO, int Mtrbniikd, string nwiGXFh)
{
    bool MVNiW = false;
    string EQnFWfIj = string("KzNepQhAgOywARalJPPgleyqwzHmhiTtpTnaLiUnHfwHRCZpvDMBhaUsacnbgpGQCNPspALHKonSXxODKnPNCFKdPmXDZnDYzQeMDUTKrjRIxWToqBoacfbHUFGeoedclDBDtKFVSTxQiIIXRCULPuj");
}

string LZkEOzu::AGgmaWTSrwi()
{
    int WWgPVzTXVrMKRKK = 819712554;

    if (WWgPVzTXVrMKRKK < 819712554) {
        for (int DUVnVIsLFKU = 1346903590; DUVnVIsLFKU > 0; DUVnVIsLFKU--) {
            WWgPVzTXVrMKRKK *= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK *= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK /= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK /= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK -= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK *= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK /= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK = WWgPVzTXVrMKRKK;
        }
    }

    if (WWgPVzTXVrMKRKK >= 819712554) {
        for (int NPPoJadyAH = 1483086559; NPPoJadyAH > 0; NPPoJadyAH--) {
            WWgPVzTXVrMKRKK -= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK /= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK -= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK += WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK /= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK += WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK += WWgPVzTXVrMKRKK;
        }
    }

    if (WWgPVzTXVrMKRKK > 819712554) {
        for (int xhswBbk = 632771667; xhswBbk > 0; xhswBbk--) {
            WWgPVzTXVrMKRKK += WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK -= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK *= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK *= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK -= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK *= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK += WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK -= WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK = WWgPVzTXVrMKRKK;
            WWgPVzTXVrMKRKK *= WWgPVzTXVrMKRKK;
        }
    }

    return string("tlxA");
}

string LZkEOzu::QpWgfh(string wYulLGzDxzoL, bool kFhPR, int GCsOp, double vRyqvitiiiYQ, string rvxIGF)
{
    double ToRLYnepxBjliR = -716106.5424856368;
    bool dJAxqsKkyzpdDi = true;
    bool MkoHaOwkpIbbQubz = false;
    int FkjOJNIqn = -252440057;
    string ukSQw = string("IOONrhJznOWhQReedHitQhggalGYNCETkFQAWxqPcUJKonKgWrjAQbubZlSIErABvFRhSdaQnOoUGNwRjOLgbQXJoZRJMcWgvwBmZcAptEnDMieBtwQWLsxQmqJMMUxikepqpLitsUoELbLwMrgfHqrcNhzgEhCicMpwHMrmoGcaywcUfqCsrHKoNvwqJT");
    string hSYPsyyF = string("dQIumzHaStOLYXqjEZIcdXipaFyvHidMMXpOPETJshtOUMpHTOVRiYrHfhQHGlxWlHCqMnHxsbuMvhiM");

    for (int OEYMzwsLuWIxdRiM = 2091714621; OEYMzwsLuWIxdRiM > 0; OEYMzwsLuWIxdRiM--) {
        ukSQw += wYulLGzDxzoL;
    }

    for (int fNLbKTFRbnGPs = 1179102899; fNLbKTFRbnGPs > 0; fNLbKTFRbnGPs--) {
        rvxIGF = rvxIGF;
    }

    return hSYPsyyF;
}

void LZkEOzu::dIjxgYYvTaNbxhs(string hUCtIKLITrX, int SgnzErCMdBUrwtB, string uHxlqdPovvIA, bool usydRpgRUw, bool UakJOjBvsEdY)
{
    double EWeprfSvpHdFkx = 1034529.0233283701;
    bool BvrvvjBAydICPb = true;
    double iSuqhun = 141779.81931576115;
    bool WVWJgXcxz = true;

    for (int OtFBEoj = 576429539; OtFBEoj > 0; OtFBEoj--) {
        UakJOjBvsEdY = UakJOjBvsEdY;
    }
}

bool LZkEOzu::nLkiPRNnnAuWSLZF(bool dIlawviqB, int gvKTZvQNP, int hPdcBAcXIO, double whOZhgz, string iizIlC)
{
    double DvqSMEdeOPQPtqnQ = 1039965.2894834595;
    string TnBmSQTDPNPDuBa = string("ZKMIvnfLcxMnmtNIJWsKygmWGchhoFbiEYkfKmuWGGuDefRfasPXqytqeObYYvqOjkeJgKJrOITiXcpnGrxoPvfExMVtNYgZdUExqClozccFjnEKPHqIZgZSmFoZrjoOSKAqRGktbXxUaDKDHIXWAiNkndsjKAfCdnkxeCDiRObihTzWOaGbMeDWKTRVMrfatOGczMQWADBtxYQGFHEpGIMJPMrawbixNtBUKKqGVUzaTpJNNHuAYLjIMKxFAO");
    string qrBRxUHQB = string("LWHSDFtokqxRxXljKPJnIbRuBHingLBOtEPgBzonJcStrgKIkDbTxMstFnFnKvliAhbOrtbjitZzOlEfPzoRwiAunvDNXhkIjuGfMHkxBgabhlZMBBEEnSnKoFvYBQapEyUsURMqEQbLLCBqOBsRIgQVMVlWKZOGnArTRDIalzOJQgWUGRBpnHOeLWLkuesH");
    int IikUnPJ = 1601335924;
    int ggFEMbHMnIgEO = 1943408709;
    bool UZSfTGSx = true;
    string zYauQwIgcZqaGrn = string("sVSAMTdxVHHbRtWlWfxDjOtDrIpkTbzhBrsFgBUpyvQeWJHYXWXIEsaUG");

    for (int EGyikKZb = 93124149; EGyikKZb > 0; EGyikKZb--) {
        continue;
    }

    for (int mwwFGptYAhJuRSe = 193834585; mwwFGptYAhJuRSe > 0; mwwFGptYAhJuRSe--) {
        DvqSMEdeOPQPtqnQ *= DvqSMEdeOPQPtqnQ;
        TnBmSQTDPNPDuBa = qrBRxUHQB;
    }

    for (int dpzoLX = 212314320; dpzoLX > 0; dpzoLX--) {
        iizIlC = TnBmSQTDPNPDuBa;
        gvKTZvQNP = hPdcBAcXIO;
    }

    return UZSfTGSx;
}

LZkEOzu::LZkEOzu()
{
    this->aCqDcNl(string("KiBJNoArkPtMTYOqRHZBtgeCdvSYgaWTdVeflRSPCVRLvNoQrDJWizH"), string("NWEfOQxYYrwbbBODcoRejwFujlTaqEgyM"), true);
    this->dkAlryUOEW(-702374.2104225693, false, true, -317954987, string("naGluvFCPDDzYGQvUeGCielAZScFy"));
    this->ziwLQfPDalPIfdNk(false, false);
    this->iaEHoOUuNKUk(string("xQxfzbzZoYGEyifCUpZehFHGRjOtJEDdhcHhWWfAjgUbxFBfkwZaczKsyOHjyoXXYLM"), -468439980, false);
    this->ayhDMDtYvxc(-1359717, true, -619805616);
    this->FIDeESbdd(1400857031, false, -125038160, string("xcGBaHPXyTOvcYQRmnrMdTHjNznaCqkUMmurVCwcPmumNdQjAjcJbCHhlgOiWVJCKxVEBgSOPOKAKtuXuQDVFmkFnnDafDggYGSPuIcXYXazUlHiTCJvUyGyhGGbxkilopvSdUABUFaaUrDFFkPKzNDEjCapHlQXOzyHImTKWwwGqACsWXFbztdgroMzIdmFFxstgrleFDNUoQRIoepfrOHmKUqjbDXR"));
    this->AGgmaWTSrwi();
    this->QpWgfh(string("OuDjYEjfwveYUQQdKqBcwzvhtduzcGIyMQBSUkhpEwFWQCHyKkfAFqyIoIN"), true, 1608121452, -476252.4124751844, string("JtReLMrhoquGilJFbIidsttApLnhATLrXuqStxanpmKoNTELIjcWYKvTaQnPStXWPeOTHMVxFwzjAzBpsRDiHZbVHgkYnLnVlYIvuSyMPxJ"));
    this->dIjxgYYvTaNbxhs(string("yAVKXJIabPvmDWGoAKewlIrzqZPlCSLEZtgyEIzFRzpRcRTdYAsznyXPAsfXqXkyztcaHTyftGePzYHfwrYsadRozjAThUGPBHqKPQyKhcePcouEePzhesQKNZssJgTvKdELPoXvUzJyPQJwBuemCsZeEruKOORuBoCqVbHwbPcbVFlGQsGMOPtJrUuTFGnaiuxiCTIJhEHjBhlIYOLkeKrNAOrTzbzxVWMllhXVNDVpuS"), 499153888, string("lzvrjJPjHgRzUYhRdixIVMxTojuZnRnHNhZbIxRGZRNDYbgUwYfnQLqBkyddtKkWAxLMijv"), false, false);
    this->nLkiPRNnnAuWSLZF(false, -423671932, 249931069, -965722.3872432698, string("TliKSZkoHHCdtDjToOQvYGaysEsHNpJOPhgXGVHBvIAwdFvWhRyWoIwijSDMVSCfwVIVSbXTmMabWvuCCqelTeYVpjYDPhFfAyaCuBLgkeTdvQxfzocUbvbvbZLakkswNmFyUFgzBmvXtRAMAHXZIYbmmrSrNcWDxYzOccuQNBbuloopnnGdpFKQlaNwsZdvrIjGLeKmYLeDREZciHUnDsKdQcHcgzHqASOizYWkDiFGghbdzMYparrfNEas"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LyHzWPlmKzZVIxe
{
public:
    int ixmPNsfvp;
    bool GFkzo;
    int wgLFadyZ;
    string JYvjLbDPDehYZ;
    int XkpFYMYBIpLNy;
    string eElgdHMLBDNJ;

    LyHzWPlmKzZVIxe();
    string URaPfxeIoVid();
    bool cQpiTlXTgex(bool dZFRAkaUXwEgdYE);
    int DzfulXyopWP(int JnfCbZRCCxyxtU, double ntDwny, int QfIIBKOn, double zBpzmCqQPKiUq);
    void hvvOKGgdPFbch(double SRWRbP, string AlGMPyRQlGSFi);
protected:
    int HrxaWKEv;
    string rEBQHFLzgRFRV;

    bool PKddchWhjHjmrV();
    string lBUMAKDR(double eLUyDvbiflOv, string ClNFGpXAkkQmYdH);
    string ptzmsvZnrpeS(int ZwjKbakAq, int HUCRK, bool cgtSq, double kbICVVjuuyXx, bool IWzqRfCPyYfFwYsD);
    void DNRyujJbTApe(string lpEaXpDs, bool hgMDLxKckkLZMPFi, double EmwABKemBzU, bool WjCWiQQmcOf, double IaSraymlQA);
    void pFVwrjJIGAruhENU();
    double nccuxwqJaUYHrs();
    void ihWKvAzlbbYL(double MvSmzMeJGz, bool pcvhK);
    int mbdoBbsyYcvMIG(int BynXnzKq, double HTGWihNGz, bool sqcrAHvQpBs, double uMXURAIBswvSGitB);
private:
    bool GQXRNSCcaBjm;

    string EOzOS(bool NkPCsDQcOWMApq, double NuaNSJjBsZ, int zAhkSYG, string EuruJ, bool LPCtL);
    bool Uymksav(bool kHSvuaYTJpBwem, double rKMbWYND, bool tWFbKAN, string okuFzACSusnLV, bool fzwdfSflDnVJSCku);
    int QITTTNihaEpMX();
    double TtWmyEoS(bool YykituJwwzUpTyoO, string qvwsYiY, int OZFhkwlJEdrg, double kxcsfrkOOAWj);
};

string LyHzWPlmKzZVIxe::URaPfxeIoVid()
{
    double mhutgDSB = -150813.41795724846;
    string VvxJGrPBdpV = string("MjOsR");
    double ZDXjzxPMhxveozv = -579531.4704015077;
    string biFBFr = string("BtDcRXVUzWCwHQSqwylAClyEUVQSxjnvUNMITVxJirsNbZLtybuvMgTuqorGEkrsWbyvYMCasJWszPUyyWfMKyvDHbHobdWyOaTnqsvwOaBgVRAigBmzVBXUCoZyoLFLpJekQkWCAjOWfAoIyuBGeObJBoVteZfRRVnaZqTlkvbeWNoJOXukgnzpcnkWccAuQXoFxsehFZnKryEjRbHBzsNzjQPqDtMmxeKFuZ");
    string KEQqQFx = string("cEeUAaehOaYhaZBkDRLOpwDremUwQnHaylSoJpgBasEksAqQenIxWllGUZxgOxjDVYukanFdyuFiViRQwQXXXiuHwEJTcYoGHLvpqrnaoOnnyCZPAtNOCaadiJwRltiSeZxcWSWAtKIOwnkAJTSdkVAnwbqVGdmGINGOApUBAyzfoYClOONHYGGXCnPZbWFwzlzKZZlaqxuxRVUyDUXItJbzWJaksgYYyIITazjn");
    int uMsNmrMAEeK = -1982649576;
    int PhUXIjkSUuUxR = -888418037;
    double fobaMZiONWZee = -642564.4422124876;
    double fpDGc = -850658.4381304987;

    if (fpDGc < -850658.4381304987) {
        for (int ffBtOHvxxLJ = 1777186532; ffBtOHvxxLJ > 0; ffBtOHvxxLJ--) {
            mhutgDSB += ZDXjzxPMhxveozv;
            fobaMZiONWZee /= mhutgDSB;
            fpDGc /= mhutgDSB;
        }
    }

    for (int pfJGRk = 232029444; pfJGRk > 0; pfJGRk--) {
        ZDXjzxPMhxveozv -= fobaMZiONWZee;
    }

    return KEQqQFx;
}

bool LyHzWPlmKzZVIxe::cQpiTlXTgex(bool dZFRAkaUXwEgdYE)
{
    double cvAmMBljkBtaxu = -375733.3192719315;

    if (dZFRAkaUXwEgdYE != false) {
        for (int TMPPGIuoM = 834703432; TMPPGIuoM > 0; TMPPGIuoM--) {
            dZFRAkaUXwEgdYE = ! dZFRAkaUXwEgdYE;
            cvAmMBljkBtaxu *= cvAmMBljkBtaxu;
            dZFRAkaUXwEgdYE = ! dZFRAkaUXwEgdYE;
            cvAmMBljkBtaxu /= cvAmMBljkBtaxu;
            dZFRAkaUXwEgdYE = ! dZFRAkaUXwEgdYE;
        }
    }

    for (int xRllB = 1022399543; xRllB > 0; xRllB--) {
        dZFRAkaUXwEgdYE = ! dZFRAkaUXwEgdYE;
    }

    return dZFRAkaUXwEgdYE;
}

int LyHzWPlmKzZVIxe::DzfulXyopWP(int JnfCbZRCCxyxtU, double ntDwny, int QfIIBKOn, double zBpzmCqQPKiUq)
{
    int QGzsvmPoaJvk = 898266894;
    int iIqJD = -570284404;
    double CHGavXXbzMT = 59682.864595714556;
    int RUKLmNjCg = 1489189268;
    bool JwlNfpqjSkHGEGHI = false;
    bool rTRrH = false;
    bool rqDSR = false;
    double KgzWOv = 188047.9573819207;
    string FRxGiuPTqdA = string("nJxxVP");
    double LJkKfANnOjpnDWC = -587580.7393876753;

    for (int FgPpBLIUftzpK = 1548076282; FgPpBLIUftzpK > 0; FgPpBLIUftzpK--) {
        CHGavXXbzMT /= CHGavXXbzMT;
        KgzWOv /= KgzWOv;
        QGzsvmPoaJvk *= JnfCbZRCCxyxtU;
        JnfCbZRCCxyxtU /= RUKLmNjCg;
    }

    for (int CaZYzJdS = 905245502; CaZYzJdS > 0; CaZYzJdS--) {
        JwlNfpqjSkHGEGHI = rTRrH;
        zBpzmCqQPKiUq -= LJkKfANnOjpnDWC;
        JnfCbZRCCxyxtU = QGzsvmPoaJvk;
        iIqJD *= QGzsvmPoaJvk;
        KgzWOv -= zBpzmCqQPKiUq;
    }

    for (int VXdXUCcyrwnbd = 1966278683; VXdXUCcyrwnbd > 0; VXdXUCcyrwnbd--) {
        continue;
    }

    return RUKLmNjCg;
}

void LyHzWPlmKzZVIxe::hvvOKGgdPFbch(double SRWRbP, string AlGMPyRQlGSFi)
{
    int AkTwjsLpU = -756752568;
    int lUfijyPpv = 119010570;

    for (int hEXTrScfepQpAmQ = 132498183; hEXTrScfepQpAmQ > 0; hEXTrScfepQpAmQ--) {
        lUfijyPpv = AkTwjsLpU;
    }

    if (AkTwjsLpU == -756752568) {
        for (int zyahfkeozdtYe = 764780123; zyahfkeozdtYe > 0; zyahfkeozdtYe--) {
            SRWRbP += SRWRbP;
            AkTwjsLpU += lUfijyPpv;
        }
    }

    if (AlGMPyRQlGSFi > string("MJNLtvDOxLhpMDpbOwczyrygRYKSSBbyTsRvBVFMLoNtEmseDhGejwGOXMwCtPzCNlKzfbKSttodxzhZmNfeSjYQZZPlAFxTOzIthtEHLzxNGqmsDrDBuG")) {
        for (int wqDdydDge = 1665189622; wqDdydDge > 0; wqDdydDge--) {
            SRWRbP *= SRWRbP;
            lUfijyPpv -= lUfijyPpv;
            lUfijyPpv += lUfijyPpv;
        }
    }
}

bool LyHzWPlmKzZVIxe::PKddchWhjHjmrV()
{
    double XHjKcrSGDjZId = 936874.1341100003;

    if (XHjKcrSGDjZId != 936874.1341100003) {
        for (int LgtbXIB = 452273978; LgtbXIB > 0; LgtbXIB--) {
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
            XHjKcrSGDjZId += XHjKcrSGDjZId;
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
        }
    }

    if (XHjKcrSGDjZId <= 936874.1341100003) {
        for (int cgihmavlQSQPY = 692720909; cgihmavlQSQPY > 0; cgihmavlQSQPY--) {
            XHjKcrSGDjZId *= XHjKcrSGDjZId;
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
            XHjKcrSGDjZId += XHjKcrSGDjZId;
            XHjKcrSGDjZId *= XHjKcrSGDjZId;
            XHjKcrSGDjZId /= XHjKcrSGDjZId;
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
            XHjKcrSGDjZId += XHjKcrSGDjZId;
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
            XHjKcrSGDjZId /= XHjKcrSGDjZId;
        }
    }

    if (XHjKcrSGDjZId < 936874.1341100003) {
        for (int TpbVUrHl = 1449558200; TpbVUrHl > 0; TpbVUrHl--) {
            XHjKcrSGDjZId += XHjKcrSGDjZId;
        }
    }

    if (XHjKcrSGDjZId <= 936874.1341100003) {
        for (int RIzZSDZnfuljpp = 102762680; RIzZSDZnfuljpp > 0; RIzZSDZnfuljpp--) {
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
            XHjKcrSGDjZId += XHjKcrSGDjZId;
            XHjKcrSGDjZId /= XHjKcrSGDjZId;
            XHjKcrSGDjZId *= XHjKcrSGDjZId;
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
            XHjKcrSGDjZId += XHjKcrSGDjZId;
            XHjKcrSGDjZId /= XHjKcrSGDjZId;
            XHjKcrSGDjZId /= XHjKcrSGDjZId;
        }
    }

    if (XHjKcrSGDjZId < 936874.1341100003) {
        for (int ZCTdesLpHG = 669212776; ZCTdesLpHG > 0; ZCTdesLpHG--) {
            XHjKcrSGDjZId += XHjKcrSGDjZId;
            XHjKcrSGDjZId += XHjKcrSGDjZId;
        }
    }

    if (XHjKcrSGDjZId < 936874.1341100003) {
        for (int mDijhXlbN = 1845927647; mDijhXlbN > 0; mDijhXlbN--) {
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
        }
    }

    if (XHjKcrSGDjZId != 936874.1341100003) {
        for (int ItUXG = 1544961430; ItUXG > 0; ItUXG--) {
            XHjKcrSGDjZId += XHjKcrSGDjZId;
            XHjKcrSGDjZId -= XHjKcrSGDjZId;
        }
    }

    return false;
}

string LyHzWPlmKzZVIxe::lBUMAKDR(double eLUyDvbiflOv, string ClNFGpXAkkQmYdH)
{
    double AGjDhGBqfq = 247598.74954145917;
    bool SppKRakUfqyq = false;
    bool aPspJtbliMDu = true;
    bool tCtbByTKeKsE = false;

    if (tCtbByTKeKsE != false) {
        for (int FmOmqJlbaWSxCt = 261769840; FmOmqJlbaWSxCt > 0; FmOmqJlbaWSxCt--) {
            SppKRakUfqyq = ! aPspJtbliMDu;
            SppKRakUfqyq = ! SppKRakUfqyq;
        }
    }

    return ClNFGpXAkkQmYdH;
}

string LyHzWPlmKzZVIxe::ptzmsvZnrpeS(int ZwjKbakAq, int HUCRK, bool cgtSq, double kbICVVjuuyXx, bool IWzqRfCPyYfFwYsD)
{
    string oXJNOVYfPtgq = string("ESAYujCjZAhjYqORnmXLcCRpLtQPWcuQoLmisgEzfZzBXiGeCnavUKaYyGVFUHIoXAdfGEsnqDewHHLILwjRCsqdNDMPBSBHuNXSHLUYfCKNNrXSErFHDTvNxFHFMDtevfbhXJiHBCDBsIvIcptySCJJgyzXDyFZkWWYAddSzcMSElCVrxNRddGtYUSNfNUcDuTwgvyMXjGoUdUqSGcmlNinfZNiQV");
    string laIFpNW = string("UwMxCFALUGDCBuxPVwWPFwQjhwJQcuNJdycncturhYMUtyxUrfBZKhbYdbswNziStifgBZHklDsRGJxZQfQTiQIeocCkoUmkpQWfqntkeHbRkSYfQxrBbttSYvkmCklplnkiEYARDRvoDmPmEZooHQxAPLAsaXeplawoRqXRodmMnLtHBuhaO");

    for (int CeNiCeOyxplXxE = 924135985; CeNiCeOyxplXxE > 0; CeNiCeOyxplXxE--) {
        ZwjKbakAq += ZwjKbakAq;
    }

    if (ZwjKbakAq <= -1346714096) {
        for (int YMcqWEZIoJaZRn = 1112395559; YMcqWEZIoJaZRn > 0; YMcqWEZIoJaZRn--) {
            continue;
        }
    }

    for (int tvsnAPCVUZQsKL = 363923281; tvsnAPCVUZQsKL > 0; tvsnAPCVUZQsKL--) {
        kbICVVjuuyXx += kbICVVjuuyXx;
        oXJNOVYfPtgq += laIFpNW;
        oXJNOVYfPtgq = oXJNOVYfPtgq;
    }

    for (int jLgAdVb = 1867242887; jLgAdVb > 0; jLgAdVb--) {
        IWzqRfCPyYfFwYsD = ! cgtSq;
        ZwjKbakAq *= ZwjKbakAq;
    }

    return laIFpNW;
}

void LyHzWPlmKzZVIxe::DNRyujJbTApe(string lpEaXpDs, bool hgMDLxKckkLZMPFi, double EmwABKemBzU, bool WjCWiQQmcOf, double IaSraymlQA)
{
    bool oxpMyQIEpES = false;
    int GeytM = 1721307799;

    if (hgMDLxKckkLZMPFi == false) {
        for (int DUDllMiRQtfpGty = 1154394031; DUDllMiRQtfpGty > 0; DUDllMiRQtfpGty--) {
            continue;
        }
    }

    for (int GnIakI = 448066591; GnIakI > 0; GnIakI--) {
        oxpMyQIEpES = hgMDLxKckkLZMPFi;
        WjCWiQQmcOf = ! hgMDLxKckkLZMPFi;
        oxpMyQIEpES = oxpMyQIEpES;
    }
}

void LyHzWPlmKzZVIxe::pFVwrjJIGAruhENU()
{
    int avWfgdubfMnoKyY = 1801576694;

    if (avWfgdubfMnoKyY >= 1801576694) {
        for (int VMZAMJrOx = 306782075; VMZAMJrOx > 0; VMZAMJrOx--) {
            avWfgdubfMnoKyY /= avWfgdubfMnoKyY;
            avWfgdubfMnoKyY += avWfgdubfMnoKyY;
            avWfgdubfMnoKyY = avWfgdubfMnoKyY;
            avWfgdubfMnoKyY -= avWfgdubfMnoKyY;
            avWfgdubfMnoKyY = avWfgdubfMnoKyY;
            avWfgdubfMnoKyY /= avWfgdubfMnoKyY;
            avWfgdubfMnoKyY = avWfgdubfMnoKyY;
            avWfgdubfMnoKyY /= avWfgdubfMnoKyY;
        }
    }

    if (avWfgdubfMnoKyY >= 1801576694) {
        for (int pPhVHYPjLNyH = 923814297; pPhVHYPjLNyH > 0; pPhVHYPjLNyH--) {
            avWfgdubfMnoKyY /= avWfgdubfMnoKyY;
            avWfgdubfMnoKyY -= avWfgdubfMnoKyY;
        }
    }

    if (avWfgdubfMnoKyY == 1801576694) {
        for (int RFZQUC = 947841270; RFZQUC > 0; RFZQUC--) {
            avWfgdubfMnoKyY = avWfgdubfMnoKyY;
            avWfgdubfMnoKyY = avWfgdubfMnoKyY;
            avWfgdubfMnoKyY += avWfgdubfMnoKyY;
            avWfgdubfMnoKyY -= avWfgdubfMnoKyY;
            avWfgdubfMnoKyY += avWfgdubfMnoKyY;
            avWfgdubfMnoKyY *= avWfgdubfMnoKyY;
            avWfgdubfMnoKyY *= avWfgdubfMnoKyY;
        }
    }
}

double LyHzWPlmKzZVIxe::nccuxwqJaUYHrs()
{
    int xPSwo = 1035265199;

    return -775150.7554506295;
}

void LyHzWPlmKzZVIxe::ihWKvAzlbbYL(double MvSmzMeJGz, bool pcvhK)
{
    string FcPofEzR = string("DgKaynztBCVMKXHowZFztWMRqBolTdKpANlzXkFWvowcVZmgIQJOJWayEMzEAXZldpyUcIxSPrGujfNTJHrsZjyApCBjLPtyG");
    int sFIbBHWKhD = -304515792;
    bool GdSxnKutCATNPH = false;
    double IUQUptzkWJXowP = -229732.03001628607;
    double XVSWbgX = -20491.57133609029;
    double ixBlgh = -902437.9917353599;
    double WqEAg = 166713.11528102832;
    string gWldIX = string("MnjuHGZrcxgpLvEzHSQFDBMtMMQQNZksVXeVROjsLdoDAimKOcCKNgBSegDZSszJMbVQXLBaWHuXfQgITDrlqNXmoyKqQXGuXqbuOhSGztdzDxqnIGQrvZjWMybBcmyjMrSvvHNHaIjBmfAkrlyDOkPsprxNFdKAWipkRRbjejWDadNx");
    double zGoJeOIuUOYuJTd = -543087.8226838104;

    if (WqEAg > -750453.4673780785) {
        for (int ORYDF = 1035834886; ORYDF > 0; ORYDF--) {
            FcPofEzR = gWldIX;
            XVSWbgX += XVSWbgX;
        }
    }

    for (int qjDeVyZIin = 1826195144; qjDeVyZIin > 0; qjDeVyZIin--) {
        pcvhK = ! pcvhK;
    }

    for (int dpUfXJk = 1244469895; dpUfXJk > 0; dpUfXJk--) {
        IUQUptzkWJXowP /= MvSmzMeJGz;
        sFIbBHWKhD *= sFIbBHWKhD;
        MvSmzMeJGz *= zGoJeOIuUOYuJTd;
        ixBlgh -= IUQUptzkWJXowP;
    }
}

int LyHzWPlmKzZVIxe::mbdoBbsyYcvMIG(int BynXnzKq, double HTGWihNGz, bool sqcrAHvQpBs, double uMXURAIBswvSGitB)
{
    int GqFmDUWgdz = 1712999585;
    int SOyGUxt = 1623962648;
    int CmVWNrPozMF = -1815089710;
    string cPOlIsa = string("eoDYHgjcBwsqEALCDoyullLxQMjhtOxngmDuoqzkwLvJSNQbQUXSpYZpQeJScdKrOjyVakyhFVVasBVpRlMxTZQjMmDaUayhDurKoyYiFgDjhssmGYZlXxpzcmyzCCgqyyPjYYrKVrKwxagrkDxrBfXaQZwAnFMjnTdxkeKrlB");

    for (int iAYZzQoKYGowQA = 1739959276; iAYZzQoKYGowQA > 0; iAYZzQoKYGowQA--) {
        sqcrAHvQpBs = sqcrAHvQpBs;
    }

    for (int srZlLEihWd = 1913825924; srZlLEihWd > 0; srZlLEihWd--) {
        continue;
    }

    for (int hrNorDheIShgNd = 1160829406; hrNorDheIShgNd > 0; hrNorDheIShgNd--) {
        HTGWihNGz = HTGWihNGz;
        HTGWihNGz /= uMXURAIBswvSGitB;
    }

    for (int yJfTLid = 804193816; yJfTLid > 0; yJfTLid--) {
        GqFmDUWgdz /= CmVWNrPozMF;
        SOyGUxt -= BynXnzKq;
    }

    return CmVWNrPozMF;
}

string LyHzWPlmKzZVIxe::EOzOS(bool NkPCsDQcOWMApq, double NuaNSJjBsZ, int zAhkSYG, string EuruJ, bool LPCtL)
{
    int XyuSOBvrHbl = -2081955678;

    for (int eVBvskJdGD = 2045849324; eVBvskJdGD > 0; eVBvskJdGD--) {
        EuruJ = EuruJ;
    }

    for (int xGtxcwHBf = 966422255; xGtxcwHBf > 0; xGtxcwHBf--) {
        LPCtL = ! NkPCsDQcOWMApq;
        zAhkSYG -= zAhkSYG;
    }

    return EuruJ;
}

bool LyHzWPlmKzZVIxe::Uymksav(bool kHSvuaYTJpBwem, double rKMbWYND, bool tWFbKAN, string okuFzACSusnLV, bool fzwdfSflDnVJSCku)
{
    string PMFGnEIael = string("itaeWIpnLsuwNqfQ");
    bool mgkAsTuEYjGN = true;
    int SPHIdoNuzZogfM = 1721934184;
    double ZOjLRSNBi = -853987.0947271652;
    int cgLLEKtZjAKXQUoI = 859435495;
    bool oaQoH = false;
    int knXpTqZUVg = 424658141;

    for (int tcLYkKIOpIo = 2093490321; tcLYkKIOpIo > 0; tcLYkKIOpIo--) {
        fzwdfSflDnVJSCku = tWFbKAN;
        cgLLEKtZjAKXQUoI /= cgLLEKtZjAKXQUoI;
    }

    return oaQoH;
}

int LyHzWPlmKzZVIxe::QITTTNihaEpMX()
{
    bool VSTptdnWrNjkWS = true;
    double BzKlccDTfidHr = 353065.6389036318;

    if (BzKlccDTfidHr > 353065.6389036318) {
        for (int PDfCC = 1555315310; PDfCC > 0; PDfCC--) {
            BzKlccDTfidHr /= BzKlccDTfidHr;
            BzKlccDTfidHr /= BzKlccDTfidHr;
            VSTptdnWrNjkWS = VSTptdnWrNjkWS;
            BzKlccDTfidHr /= BzKlccDTfidHr;
        }
    }

    for (int UYAjapRdgslzchkM = 1416989192; UYAjapRdgslzchkM > 0; UYAjapRdgslzchkM--) {
        VSTptdnWrNjkWS = VSTptdnWrNjkWS;
    }

    if (BzKlccDTfidHr == 353065.6389036318) {
        for (int ytdlu = 545156500; ytdlu > 0; ytdlu--) {
            BzKlccDTfidHr = BzKlccDTfidHr;
        }
    }

    for (int rsdoyoJDxBgY = 1446703723; rsdoyoJDxBgY > 0; rsdoyoJDxBgY--) {
        VSTptdnWrNjkWS = VSTptdnWrNjkWS;
        BzKlccDTfidHr *= BzKlccDTfidHr;
    }

    return 1038722701;
}

double LyHzWPlmKzZVIxe::TtWmyEoS(bool YykituJwwzUpTyoO, string qvwsYiY, int OZFhkwlJEdrg, double kxcsfrkOOAWj)
{
    bool mDNusGhXsWgc = false;
    double nKLLvh = -198503.80167389294;
    string SjLOD = string("NqXMmDsmZSNEOXpOqrrOyIyAxtmPKHHebnWGUQEZcMCEwBiDWBrwBYDurVyfsGZcglfohDYEfFoyXrQkdiYgDYCXFZUmbEbiwAOQCRPWuUDcNOmpjQIvhaujfjdHSiADohWwoblIuooNMUjFCBkWbJiUOdfmiqRvbK");
    double lKuYQxnGpJYmR = 726538.3124067882;
    double UPqwhRWBuxrVyMK = 449846.4956229525;

    for (int gPpiAjKzNB = 2114826064; gPpiAjKzNB > 0; gPpiAjKzNB--) {
        YykituJwwzUpTyoO = ! YykituJwwzUpTyoO;
    }

    for (int wTDhfSse = 21758242; wTDhfSse > 0; wTDhfSse--) {
        continue;
    }

    if (kxcsfrkOOAWj <= -198503.80167389294) {
        for (int xPIJwTv = 482852638; xPIJwTv > 0; xPIJwTv--) {
            lKuYQxnGpJYmR += nKLLvh;
            lKuYQxnGpJYmR = UPqwhRWBuxrVyMK;
        }
    }

    return UPqwhRWBuxrVyMK;
}

LyHzWPlmKzZVIxe::LyHzWPlmKzZVIxe()
{
    this->URaPfxeIoVid();
    this->cQpiTlXTgex(false);
    this->DzfulXyopWP(-1309805217, 113889.90191884499, 1321649793, -233252.16399466284);
    this->hvvOKGgdPFbch(-846416.1044162185, string("MJNLtvDOxLhpMDpbOwczyrygRYKSSBbyTsRvBVFMLoNtEmseDhGejwGOXMwCtPzCNlKzfbKSttodxzhZmNfeSjYQZZPlAFxTOzIthtEHLzxNGqmsDrDBuG"));
    this->PKddchWhjHjmrV();
    this->lBUMAKDR(-82056.57395224109, string("gZbbZDjaddOzkcLBlDGazaWPwrQNczxdpGwuLDJAyRVjRwkiULoRxPFruWcUXfbJMLJgBzDIHmcoanNRdLTRIRSeLiwFvpRXdxqolZGPTOAMPRXJOCQSLoksUzRVVwHAuIvTRcyfxucUkbZfDlFSBcsqWxfTAHOYoPvmpJSYenhAlFTVJNByqihUVVmeAHnnCaXpbBHCWYJTCITazscP"));
    this->ptzmsvZnrpeS(-1346714096, -448883621, true, 215872.33024317928, false);
    this->DNRyujJbTApe(string("OifUkXAilhtEMpOePqNfEqIEoayigacfFuxlpcTUrcsEMOHgbqCAEPxoeRyQhLKpFjufDOlGMIEkQmTUHEqNzyDWQEZmYSKqbmPtgLCUwoGxclzOggSBGsGcBIm"), true, 807738.3635259811, true, -324257.6209651614);
    this->pFVwrjJIGAruhENU();
    this->nccuxwqJaUYHrs();
    this->ihWKvAzlbbYL(-750453.4673780785, true);
    this->mbdoBbsyYcvMIG(854542487, -705468.3213332299, true, -847326.2785819905);
    this->EOzOS(false, 389520.7762237053, -1534047305, string("kcHQjbLtlWzIyXMPfKvDzOSqSmBbBzqPsOhbrdOeJdAneEZnGEfsJhrmwdVIlYyYWEgOtofkTOiNTWcRBAxSobyfAYysWZpvATdvLGhkQbTTnbThmoDSSFRgghcDZHcTQi"), false);
    this->Uymksav(false, 812382.4686239153, false, string("OfGJIsnUSPEyIRVtnjVncqiwlmczSvWRwAjomrxCKmQnupFLzOrWquH"), false);
    this->QITTTNihaEpMX();
    this->TtWmyEoS(true, string("iAsDQmZkTJDbfrtryWghJgEPGjArgalLWFNicDODOvBlSEQlsNNiCjVKUenqxdWxOBzXENMNOJQvmQpEsPWTbaJRPMKBvzrviOhKyzMmfObuZCtHzHUWzlWhfPIjLbEuNNhaHEJzMFRNCRqIxYsDLHYVOrRXJjrFSpnvQzZhwDJWZIjkKAiNjeL"), -1083382587, 454817.3221870077);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MfuOiLZgqFm
{
public:
    bool FirGCFnplfmeeJ;
    int OAVKvshhu;
    bool ynAUniGTCYno;

    MfuOiLZgqFm();
    void FdgdQtI(string XscTaaLd, double QlEHsVmbgj, int faxVbzg, string pUzoJWieCEwwJJnm, double HWZDIwiZzrGt);
protected:
    double qTnVvaDLujm;
    int unXrBWcITmAvq;
    double TpgEQMIZnz;
    bool AlDxagDorh;

    bool HDrGFafidzLFDsU(string IOTKbX, bool mkizXxKcF);
    bool JTOuJnSwJw();
    bool BuwPeJakYoNmbV(double kqmEWYOCcg, bool bitTTB);
    double BNgzPslY();
    int kkOtpuOzsWBXUxhX(double zlblQnkAxbNZpeNo, string GWWoVpBroPdgRqXP, bool PwElisSqY);
    void lKAGzocqFysNe(int EqQjotFIN);
    double QwCoTYree(double bJTATDOjHq, double VpZFPsF, string HuTiIPdUwqndxHzu, string UTgECn, string wWtGIrjXkdRdzEA);
    string JGXCvIQ(bool knRSuyTQ, int YHXdTsisg, int olxlGryRPqX, string EYNtf, bool YyTWEgJIDxqIVl);
private:
    int ICtqTIMVq;
    double FoKrReilrCIdj;
    string DWNVivqeEJHeucv;
    int YVYFCucboroPwAFF;
    int WKoMiCp;
    int bSvSfOI;

    string EIWCDBUKMAUEht(int iVNFbdLxWrTHxCwQ);
    int nBYNolrOgeYIx();
    int zWryDcYCMnKPOpEy(string UpaqpfCnzL, int gnOOydVNyoXpdKb, int HGXGbSsfGfhsyz, int hsRvhegUoNQKMJR, int ehadffUoOX);
    void xFNLOouDpSRFS(double wUpdqymLfsuULwN, bool TiGRZyhjsCk, bool BhbquGXdzWf, bool yHLAXdtHV);
};

void MfuOiLZgqFm::FdgdQtI(string XscTaaLd, double QlEHsVmbgj, int faxVbzg, string pUzoJWieCEwwJJnm, double HWZDIwiZzrGt)
{
    bool knqNgRnKzoUnFLbX = true;
    string pgVkxD = string("vZyUUWQlhMfRnfkUayFBIyFAUGXTGPFJYDbVqtWfpUOXawikOArnzAuRKiJMnmFaMQDT");
    bool OjrZRwgpKItIwl = true;
    string kTHxKdmDUc = string("gBTBirdabWIwPCrysmvGKERjOsQmNnenLvVwILNujphbRfaQkksVMYfgZFOxBdLbOuhMCWstFTPlmtfBEfdPCxNGMTmJswkfxnFsPmEqiPxtDdVcoViPtHUuZwMMOKkwMMxDOGlZlnBViXsfwlA");
    string NMikXkH = string("DCHgFtXUwcwSsdRqVXFCROWlmexfFRSuxxSUKmqwSYvHoCtqBtRHlSZlvRqHQqclQyiRlGDyrIvJoKUpIJp");
    double fAxbwngZYJpSkHcq = -159070.287213475;
    bool KyKWVtJuPX = true;
    bool dWmkDVnTg = true;
    bool anFuHNjwqrOEduy = false;

    if (QlEHsVmbgj != -159070.287213475) {
        for (int isvhZJp = 2086269888; isvhZJp > 0; isvhZJp--) {
            pgVkxD = pgVkxD;
            pgVkxD = NMikXkH;
            XscTaaLd += pUzoJWieCEwwJJnm;
        }
    }

    for (int nWptGa = 1115049992; nWptGa > 0; nWptGa--) {
        continue;
    }

    for (int oKUklUDd = 799319074; oKUklUDd > 0; oKUklUDd--) {
        anFuHNjwqrOEduy = ! anFuHNjwqrOEduy;
        pUzoJWieCEwwJJnm += NMikXkH;
    }

    for (int zyvoylDUzXTvvHj = 1511091678; zyvoylDUzXTvvHj > 0; zyvoylDUzXTvvHj--) {
        dWmkDVnTg = ! OjrZRwgpKItIwl;
    }
}

bool MfuOiLZgqFm::HDrGFafidzLFDsU(string IOTKbX, bool mkizXxKcF)
{
    int EkmHRODciEMJnPE = 120852315;
    double jpASUK = -61183.559929667164;
    double FmNOhAyQJluBtd = -490394.29080161266;
    string stCrDQrcguwAIGXA = string("ZjyeTNIVZScGidItpBVRrEXtwjvDrMXngJH");

    for (int GSyqnKOZ = 1531667766; GSyqnKOZ > 0; GSyqnKOZ--) {
        IOTKbX += IOTKbX;
    }

    for (int cFicnoq = 279042101; cFicnoq > 0; cFicnoq--) {
        stCrDQrcguwAIGXA += stCrDQrcguwAIGXA;
    }

    for (int VObpsd = 1143162746; VObpsd > 0; VObpsd--) {
        continue;
    }

    for (int FtwiVu = 1018690423; FtwiVu > 0; FtwiVu--) {
        jpASUK = jpASUK;
    }

    for (int OTlyMmVdINw = 655846804; OTlyMmVdINw > 0; OTlyMmVdINw--) {
        continue;
    }

    for (int YrYhk = 1170595846; YrYhk > 0; YrYhk--) {
        continue;
    }

    if (EkmHRODciEMJnPE < 120852315) {
        for (int GmbJRKeTwoO = 234247933; GmbJRKeTwoO > 0; GmbJRKeTwoO--) {
            continue;
        }
    }

    return mkizXxKcF;
}

bool MfuOiLZgqFm::JTOuJnSwJw()
{
    bool kTgvOhpfDyTbTvqc = true;
    bool KjZYLALYBix = true;
    bool kgTtNnNFq = false;
    bool igYJgujLIzLutQ = false;
    string scfmYBVZMvvdd = string("fnnUWOSk");
    double DxqLnIaFSMRrUM = -1031342.4803842326;

    if (DxqLnIaFSMRrUM <= -1031342.4803842326) {
        for (int eLMIGwocRlNnltue = 409592415; eLMIGwocRlNnltue > 0; eLMIGwocRlNnltue--) {
            kTgvOhpfDyTbTvqc = igYJgujLIzLutQ;
        }
    }

    for (int NckiSMagYnlK = 4654936; NckiSMagYnlK > 0; NckiSMagYnlK--) {
        kTgvOhpfDyTbTvqc = KjZYLALYBix;
        DxqLnIaFSMRrUM += DxqLnIaFSMRrUM;
        DxqLnIaFSMRrUM += DxqLnIaFSMRrUM;
        kTgvOhpfDyTbTvqc = igYJgujLIzLutQ;
        kTgvOhpfDyTbTvqc = kgTtNnNFq;
        KjZYLALYBix = ! kgTtNnNFq;
    }

    if (igYJgujLIzLutQ == false) {
        for (int oTXWfFguiAkaBhj = 5480414; oTXWfFguiAkaBhj > 0; oTXWfFguiAkaBhj--) {
            KjZYLALYBix = kTgvOhpfDyTbTvqc;
            kgTtNnNFq = kgTtNnNFq;
            igYJgujLIzLutQ = ! igYJgujLIzLutQ;
            igYJgujLIzLutQ = ! igYJgujLIzLutQ;
        }
    }

    return igYJgujLIzLutQ;
}

bool MfuOiLZgqFm::BuwPeJakYoNmbV(double kqmEWYOCcg, bool bitTTB)
{
    bool JLdfEbXhvNwP = true;
    string XbkZZ = string("fOcJJvzviWdkxeyZGAJQSjJbGBuGFRtlLDuLRgOqbyaUVKDOwAineDaNqOUDbxvCOlCESrIdXvzBJQntXJaentVLTCKiwahivQuiaLAPalVnMkzWQetrAiqGTpATCCzBkEpYghiTUhBPCjAfMydcEDXMXEasfdLZsVLeOXqdamMfCFBrLwWscQbhMeespDLRt");
    string FRIDhynzUiJFFkuD = string("UpZxTCZmwekQctDsBjkgcTxemtFafCujlAqkuDwLrsQvT");
    bool SoAZUVMiQgLXBdTz = false;
    string aoPChy = string("gdfFCPUzrMbmfvNZGSxEnlLLWNTEXHeuvDMNrQGGyUFvuiqNIWDsI");
    bool xqVOZXlKat = true;
    int eCqMJKThZLAoGXIl = -893650569;
    bool GbohPXcfWQLhcDlT = false;

    for (int McHDlDevb = 305103886; McHDlDevb > 0; McHDlDevb--) {
        SoAZUVMiQgLXBdTz = ! SoAZUVMiQgLXBdTz;
        aoPChy = FRIDhynzUiJFFkuD;
    }

    for (int KIILlJbin = 1842385571; KIILlJbin > 0; KIILlJbin--) {
        SoAZUVMiQgLXBdTz = ! GbohPXcfWQLhcDlT;
        bitTTB = ! bitTTB;
    }

    return GbohPXcfWQLhcDlT;
}

double MfuOiLZgqFm::BNgzPslY()
{
    int eagJyne = -70143000;
    bool AnnqnSKMibOCpA = true;
    double mSWfcySh = -850728.2037146913;
    bool TehFsYAlYlihiud = false;

    for (int ChTHgPKMIiKarG = 336007649; ChTHgPKMIiKarG > 0; ChTHgPKMIiKarG--) {
        TehFsYAlYlihiud = TehFsYAlYlihiud;
        eagJyne += eagJyne;
    }

    if (AnnqnSKMibOCpA == false) {
        for (int yftEhTtWHabccRaF = 1756261799; yftEhTtWHabccRaF > 0; yftEhTtWHabccRaF--) {
            AnnqnSKMibOCpA = ! TehFsYAlYlihiud;
            AnnqnSKMibOCpA = ! TehFsYAlYlihiud;
        }
    }

    for (int admlRTxGDOlVcyz = 1693482751; admlRTxGDOlVcyz > 0; admlRTxGDOlVcyz--) {
        TehFsYAlYlihiud = AnnqnSKMibOCpA;
        mSWfcySh -= mSWfcySh;
        AnnqnSKMibOCpA = AnnqnSKMibOCpA;
        AnnqnSKMibOCpA = ! TehFsYAlYlihiud;
        TehFsYAlYlihiud = ! TehFsYAlYlihiud;
        eagJyne *= eagJyne;
        eagJyne *= eagJyne;
    }

    for (int IBrIWpYhQAW = 1066330357; IBrIWpYhQAW > 0; IBrIWpYhQAW--) {
        continue;
    }

    if (AnnqnSKMibOCpA == false) {
        for (int JWiSqzXX = 1462557958; JWiSqzXX > 0; JWiSqzXX--) {
            mSWfcySh -= mSWfcySh;
            AnnqnSKMibOCpA = TehFsYAlYlihiud;
            AnnqnSKMibOCpA = TehFsYAlYlihiud;
            TehFsYAlYlihiud = ! TehFsYAlYlihiud;
        }
    }

    for (int UNkTKOzZtkADJhD = 472251772; UNkTKOzZtkADJhD > 0; UNkTKOzZtkADJhD--) {
        mSWfcySh /= mSWfcySh;
        eagJyne /= eagJyne;
        TehFsYAlYlihiud = ! AnnqnSKMibOCpA;
    }

    for (int pcvSApOJMxGhR = 955272639; pcvSApOJMxGhR > 0; pcvSApOJMxGhR--) {
        AnnqnSKMibOCpA = AnnqnSKMibOCpA;
    }

    return mSWfcySh;
}

int MfuOiLZgqFm::kkOtpuOzsWBXUxhX(double zlblQnkAxbNZpeNo, string GWWoVpBroPdgRqXP, bool PwElisSqY)
{
    bool VsvAmfFwV = false;
    double DiPmwxh = -596592.5951206918;
    double qLHgGY = 721354.9010055577;

    if (zlblQnkAxbNZpeNo >= -847004.2177929548) {
        for (int FfOZdF = 1973365413; FfOZdF > 0; FfOZdF--) {
            zlblQnkAxbNZpeNo += zlblQnkAxbNZpeNo;
            qLHgGY += DiPmwxh;
        }
    }

    for (int EoENgz = 257042198; EoENgz > 0; EoENgz--) {
        continue;
    }

    for (int lquXLNuKUtkNL = 106315146; lquXLNuKUtkNL > 0; lquXLNuKUtkNL--) {
        zlblQnkAxbNZpeNo -= DiPmwxh;
        PwElisSqY = ! PwElisSqY;
    }

    return -1040571749;
}

void MfuOiLZgqFm::lKAGzocqFysNe(int EqQjotFIN)
{
    double qpOxFhPvsIaEy = -357535.76327012514;
    double xXmnYOqslbCtn = 382398.02736883936;
    int oYjBiTSkWHtDTafU = -1368154781;
    double gUCtPAQxSKDpaBd = -743114.191233551;
    double pIDXOx = -767917.0642164167;
    double mwChx = -1010397.3686837269;

    if (mwChx == 382398.02736883936) {
        for (int ulGPZIle = 1167331783; ulGPZIle > 0; ulGPZIle--) {
            qpOxFhPvsIaEy *= mwChx;
            mwChx = qpOxFhPvsIaEy;
            xXmnYOqslbCtn += xXmnYOqslbCtn;
        }
    }
}

double MfuOiLZgqFm::QwCoTYree(double bJTATDOjHq, double VpZFPsF, string HuTiIPdUwqndxHzu, string UTgECn, string wWtGIrjXkdRdzEA)
{
    bool tPjxYkuOqZqVnJ = true;
    string enQCuYJF = string("EsUllbUnpquBwrvMjgGiLvJqleKMYaHWCRmtedPdHkWwggFpaOioiSjcjLhUoSgIvQbcmXdhzzWxgFrYsboqjFHDsWfGWJsFOMIPgpVRbOhZAyuCxwpqNxfXxPRaHKWWmmVrblTuBiTQJQeDFTRDmfTHhJKpMjpJuoHDRJSNIkTrozgdOrRkBFYSCYvJrpmGVojOBQcFYNMMbcvuqNVDylbQFFgXEcPNOWBLptlhxYKioYDhwmv");
    string vhgjunnx = string("GfomNXsMKapjkRU");
    string rnatfw = string("XIzZavfcXjkUsEPMVJumEPiXQTGcHHuhgtPVIjdIShANYLuodEzZkqoPjVYGjXVcTUlOibrIAgSMztYtxvNPlKLtJKPpdLyLBpda");

    if (rnatfw <= string("XIzZavfcXjkUsEPMVJumEPiXQTGcHHuhgtPVIjdIShANYLuodEzZkqoPjVYGjXVcTUlOibrIAgSMztYtxvNPlKLtJKPpdLyLBpda")) {
        for (int BIyDFvMudmcd = 1724389754; BIyDFvMudmcd > 0; BIyDFvMudmcd--) {
            UTgECn = wWtGIrjXkdRdzEA;
            wWtGIrjXkdRdzEA = UTgECn;
            rnatfw += UTgECn;
        }
    }

    if (wWtGIrjXkdRdzEA <= string("EsUllbUnpquBwrvMjgGiLvJqleKMYaHWCRmtedPdHkWwggFpaOioiSjcjLhUoSgIvQbcmXdhzzWxgFrYsboqjFHDsWfGWJsFOMIPgpVRbOhZAyuCxwpqNxfXxPRaHKWWmmVrblTuBiTQJQeDFTRDmfTHhJKpMjpJuoHDRJSNIkTrozgdOrRkBFYSCYvJrpmGVojOBQcFYNMMbcvuqNVDylbQFFgXEcPNOWBLptlhxYKioYDhwmv")) {
        for (int DOmsdRNujCMHbC = 501435099; DOmsdRNujCMHbC > 0; DOmsdRNujCMHbC--) {
            HuTiIPdUwqndxHzu = enQCuYJF;
            UTgECn = rnatfw;
            vhgjunnx = HuTiIPdUwqndxHzu;
        }
    }

    return VpZFPsF;
}

string MfuOiLZgqFm::JGXCvIQ(bool knRSuyTQ, int YHXdTsisg, int olxlGryRPqX, string EYNtf, bool YyTWEgJIDxqIVl)
{
    bool BJmAvD = false;

    if (olxlGryRPqX != -1171302645) {
        for (int gZpbRTlLZYADTatH = 1026495621; gZpbRTlLZYADTatH > 0; gZpbRTlLZYADTatH--) {
            BJmAvD = ! knRSuyTQ;
            YHXdTsisg *= olxlGryRPqX;
        }
    }

    return EYNtf;
}

string MfuOiLZgqFm::EIWCDBUKMAUEht(int iVNFbdLxWrTHxCwQ)
{
    bool pwukjhuJnmvdxc = true;
    double OtYGtF = -473811.3517903435;
    bool kNliaQhriF = false;
    bool ywntPkkyrBnzCze = false;

    for (int faOUUvcZvGMlEwQ = 116282340; faOUUvcZvGMlEwQ > 0; faOUUvcZvGMlEwQ--) {
        OtYGtF -= OtYGtF;
        iVNFbdLxWrTHxCwQ /= iVNFbdLxWrTHxCwQ;
        ywntPkkyrBnzCze = ! kNliaQhriF;
    }

    if (kNliaQhriF != true) {
        for (int fTTnpcUl = 918258643; fTTnpcUl > 0; fTTnpcUl--) {
            OtYGtF /= OtYGtF;
            pwukjhuJnmvdxc = ! pwukjhuJnmvdxc;
            pwukjhuJnmvdxc = ywntPkkyrBnzCze;
            OtYGtF += OtYGtF;
            kNliaQhriF = ! pwukjhuJnmvdxc;
        }
    }

    return string("FOzEMyHMyNtcoVSyDZxSkoGOLxcMKGRCWLUpjffrHnSvhYSEPPlfXsEzMXTBBucqLlgUEtmcRmZrbvDARhrqdYqggMdikeiFeqcLkdAdwzYkpJFVMGZtrnyDJQMGFWiGmnOTzjU");
}

int MfuOiLZgqFm::nBYNolrOgeYIx()
{
    string kktvpjztSUQfac = string("RaXJwXRwQXlASzzVcKNfdKFBvqBgOYhOpmVyXQyHRzFwaOxBazgNIxLOlJMXXUNnLp");
    double xJRpD = 5852.1487576153795;
    bool AUClAvfXbhCVs = true;
    int vhOBKZPZktsiaRR = 1322103636;
    string wsdLHVe = string("KHvyJRqUgGmjIKdqBkfaAsKMLESWUlCNXMOfTwydomGdGmlRZONRNBoXiywztRlpRRXKnGpTCNEwoYUyMFvwXVRribCtJhsXCWVtuyrAOgZmHJGVPDcDpVFzoNApvFUNzoq");
    int lGcIyWZQytiBzPY = 1078143139;

    return lGcIyWZQytiBzPY;
}

int MfuOiLZgqFm::zWryDcYCMnKPOpEy(string UpaqpfCnzL, int gnOOydVNyoXpdKb, int HGXGbSsfGfhsyz, int hsRvhegUoNQKMJR, int ehadffUoOX)
{
    int FdfUmPTtsGkvwXh = -279526869;
    int CXLmriEstXj = -1513308608;
    string VZOmy = string("IRFiOJwStmtFUrCNgNGDUOlOojloxQpqKhBtYoAzErJKjdeujLRJCwALlYCllzPAlbLTkgAshAPquhDSjtdF");
    bool zEQQO = true;
    double xooTJY = 481980.2956496943;

    if (HGXGbSsfGfhsyz < -279526869) {
        for (int zWnBBRxnybT = 979296488; zWnBBRxnybT > 0; zWnBBRxnybT--) {
            UpaqpfCnzL = UpaqpfCnzL;
            HGXGbSsfGfhsyz *= gnOOydVNyoXpdKb;
            VZOmy += VZOmy;
        }
    }

    if (gnOOydVNyoXpdKb <= -279526869) {
        for (int mKVDxdVKfaxONm = 1768374723; mKVDxdVKfaxONm > 0; mKVDxdVKfaxONm--) {
            continue;
        }
    }

    if (ehadffUoOX > -1513308608) {
        for (int mhaErtatRDeGgF = 1625670558; mhaErtatRDeGgF > 0; mhaErtatRDeGgF--) {
            HGXGbSsfGfhsyz *= ehadffUoOX;
            HGXGbSsfGfhsyz = hsRvhegUoNQKMJR;
            zEQQO = ! zEQQO;
            ehadffUoOX *= ehadffUoOX;
        }
    }

    for (int EgDJWgDqcWMxLr = 93150646; EgDJWgDqcWMxLr > 0; EgDJWgDqcWMxLr--) {
        ehadffUoOX -= HGXGbSsfGfhsyz;
        xooTJY /= xooTJY;
        HGXGbSsfGfhsyz = hsRvhegUoNQKMJR;
        hsRvhegUoNQKMJR /= hsRvhegUoNQKMJR;
    }

    for (int ZCZVsYqwXChZ = 1780942250; ZCZVsYqwXChZ > 0; ZCZVsYqwXChZ--) {
        HGXGbSsfGfhsyz = gnOOydVNyoXpdKb;
        ehadffUoOX *= hsRvhegUoNQKMJR;
        hsRvhegUoNQKMJR += HGXGbSsfGfhsyz;
    }

    return CXLmriEstXj;
}

void MfuOiLZgqFm::xFNLOouDpSRFS(double wUpdqymLfsuULwN, bool TiGRZyhjsCk, bool BhbquGXdzWf, bool yHLAXdtHV)
{
    double fHBBhOvkKO = 239653.9100958361;
    bool XPqNQXCtcqgGZNND = true;
    bool fQetbOryzM = false;
    int JRMKGZTxnGnZ = -1664512154;
    bool OtBVCwDEuoY = true;
    double hKuTnH = -622172.8843615769;
    bool HXARwoUngXdhoB = false;
    int DOTWjcHHsXZSjOHP = 595786296;
    string IKyYt = string("dqPxpldxsrpsprOydWmXSRsyLkZoFGHMocuNqEzxrfDDuJuwcjhfNbDwXBGdpEWzySQyoZOoukpNtciGCVnnqfNjFdotVcdXtOAuWpBYSwHidSmIeJeSiaBRaOvGwYnKeejllLqreSNxoZJsSYDHMdBnsdgPnxDpmwTnUapguhSsGgQotPsXDKVZYKPaCNzaotPcYYJEXnkukkDITLoVVEhdvlojiZAZGitpS");

    if (hKuTnH != 239653.9100958361) {
        for (int xBpClR = 218252844; xBpClR > 0; xBpClR--) {
            fQetbOryzM = ! TiGRZyhjsCk;
            fQetbOryzM = ! BhbquGXdzWf;
        }
    }

    for (int fuTIvZJcjsemMShK = 1486274513; fuTIvZJcjsemMShK > 0; fuTIvZJcjsemMShK--) {
        HXARwoUngXdhoB = TiGRZyhjsCk;
    }

    for (int dWuDBqW = 1363071232; dWuDBqW > 0; dWuDBqW--) {
        HXARwoUngXdhoB = TiGRZyhjsCk;
    }

    for (int lOwLwoaCAuipVFN = 1363515641; lOwLwoaCAuipVFN > 0; lOwLwoaCAuipVFN--) {
        continue;
    }

    for (int glmCxGiiBBR = 1365715984; glmCxGiiBBR > 0; glmCxGiiBBR--) {
        wUpdqymLfsuULwN -= hKuTnH;
    }
}

MfuOiLZgqFm::MfuOiLZgqFm()
{
    this->FdgdQtI(string("hwpHCDWLVYRiXEnmjODklEDNYkfdQFbvzidiSbPsuVIkUnAPzElRgmZDCBLqV"), 543107.0480821071, -753289094, string("IxuqPlTnJaRKoQhaZAEgYNCqXlBGTtsyojcfmgMyVmZySGWnGdUIRhsCzzcQZxrDXBsxHruAzdVfejYzwxBXXWqUaniWqnEqVjYX"), 302089.86875924375);
    this->HDrGFafidzLFDsU(string("iMmoMyoitBHEdWxtqHChHiKKZglYasiKOduOTHDUgdfWBUAJemdjJvMyyVihHlRgvzxeVfVnUobnFcpUKmysixwFddZBEPpNqVdzlOJgdpuNwXnSs"), true);
    this->JTOuJnSwJw();
    this->BuwPeJakYoNmbV(-1037621.24060044, true);
    this->BNgzPslY();
    this->kkOtpuOzsWBXUxhX(-847004.2177929548, string("YsHEmkskv"), true);
    this->lKAGzocqFysNe(203000106);
    this->QwCoTYree(-676362.8914895206, 126999.79007956473, string("IMrusSxrtkQXDalOoTwavhmSwesxHLiNHiEAMfvrSCCCBEuwHQQEwQOhEyuvDsrePjWPCKxWvWwnXUCxnvjEwBdqTEOPVQjlmPQAkOgFdEsjwPpymwQKExlEBRWquoftNVOBoyTrOsJJzMWSfZvGlpHFAEJJUaJchAwCgyvjutgGexokMuEBgAmBTYwucKCtSeWeAaefSvUYSvuiOPNEfzLMBGwxDLbPrLpHnNlWfi"), string("NyPDWCuuOxFciQmiFzeKyfzDwhNfklkukdlyzepkiBPMpSNruiyuqVMzoetkghmgkMPqFRAEIZmfZcKQtTAFXCYwQlcbnxDvDMjWZaSYCeBuPZBzufWagMGbGm"), string("JoxELNCQfQvVVTmixBmhPWTmvFYUXTCJCREZLLsZmDplLgPzhVJofUzZdtdjrzxVvWqaDDKwdzDoNTySEfjQTHgxxtqmWzhDgqiEnSzvjqwcYnMDqgoiwIerihxhJZeevJjZaTgzjGUjQAzbNhlwwBFVChBtZ"));
    this->JGXCvIQ(false, -1171302645, -178269091, string("hPlVxFguYkUhdaAzjjqVQetMWEMoyDbEIQzSkkpbPfJRpICqGicfCQifuDDecWRVhokXiVQnoJZmPnIkAfpamHpunGmgpazoedNggsr"), false);
    this->EIWCDBUKMAUEht(1372411748);
    this->nBYNolrOgeYIx();
    this->zWryDcYCMnKPOpEy(string("yszKzVbkYuTAJHQYZIPkgurTFkrEEnsCSNIyOyuvUsKdfuJAuCinRqIVESZlKeebDxglIDnBEAWoNJJEoUhoXpOeCIvGlrzsGiFozbAufkYzcNdgdvyKuzOdJhVhKuLQGWtzvCSOHjGMhGpnZjecXnnObZlYAeIdegLKJAUNeKxyPSXnuYevCeXlelmRgzNQksYG"), 1695336261, 372187702, 458184437, -467071092);
    this->xFNLOouDpSRFS(305848.0486833283, true, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tRsMXKa
{
public:
    string qObggxOyER;

    tRsMXKa();
protected:
    string ZsvLd;
    bool bXsGYXijUNl;
    bool JJvJwzfph;
    double cAFjdyXFuVDQaGg;
    int xadCBOxLFPkpdC;

    void tAhMJqYRtFNZnnb();
    bool sQqNkr(int nIZKhYgpjoQHOYG, bool gEMmDuhnMIxwL);
    void ellaxECUhORFKeE(int ttMWVFxj, int jHbzNVJEeydLvteG);
    double tWHwo(double MqMgHxqRO);
    bool QXJJr(string QwWQJuC, string iHzWADJgQFgF);
private:
    bool ldydOoKQNPEzLflS;
    string WkaRocCWfUm;
    double SUjlvGjPsB;
    double MJbJILKaCBM;

    bool lyUqjTI();
    int ShAYHRjmhN(bool nWPlJfWdvDQzasmB, string JDaru, int URSjONulnKi);
    double HlPgrUDuIFVYmX(string RogxcKeaYVJ, double wKHkC);
    string QrryYtXPOFYUC(int TCRWXHZXsElbtt, double KHgYBkxSma, string cLNsTHRIodaVe, string pyyNmKszSGGHMp);
    int kpouu(int KpxeAqRka, double GZlDYdo);
    string ODcIHIDS(double sFYeHJzBRfDVLQW, int fsLlFflyQyZ, int CwmlruhvDpVoLlN);
    double cveAGIqOLdmcg(double ByLfqwBCx, bool urwVkmyGsZwjKr, double VCsCgkCy);
};

void tRsMXKa::tAhMJqYRtFNZnnb()
{
    double rxYzmmqrFjkFA = -315509.637952389;
    int oHWQfLdwthbKJ = 198805948;
    string wPZPNTwfTz = string("wBnhzGzFCAgqJXSUYfMJyDVBQzsYPJmilCAzBHkkoZZzlofczENQXEKoHjBsvTYYaJZyuYOaAnNZzuSRUpJgXNcqMHPhHQQGIqrrZxEcgGF");
    string HtHUGowZ = string("HkcciFtkowShLhVGqwYDiJqUCRfaNASKTsetGFCEcArLQOFLeDnZMAQMIsifdTxFTkNNdpTbgKSfsvlvelRcUxGppFwJCTbAwJFnNYibHEzRrBVzEgpELQMPCmgucoTBPWPDoPGdufWNhJRabGASjjdtVUqNyVPdKHsWwEHggWJaAcdBJZkCZHR");

    for (int lKiyKcL = 1774096544; lKiyKcL > 0; lKiyKcL--) {
        wPZPNTwfTz = HtHUGowZ;
        rxYzmmqrFjkFA = rxYzmmqrFjkFA;
        HtHUGowZ = HtHUGowZ;
        wPZPNTwfTz += HtHUGowZ;
        oHWQfLdwthbKJ += oHWQfLdwthbKJ;
    }

    for (int qOIFksenoqotyDsR = 1852335997; qOIFksenoqotyDsR > 0; qOIFksenoqotyDsR--) {
        wPZPNTwfTz = wPZPNTwfTz;
        wPZPNTwfTz = wPZPNTwfTz;
    }
}

bool tRsMXKa::sQqNkr(int nIZKhYgpjoQHOYG, bool gEMmDuhnMIxwL)
{
    double QFnvQEzJzqZ = 629833.8194002546;

    for (int cePprWiMQ = 604471172; cePprWiMQ > 0; cePprWiMQ--) {
        gEMmDuhnMIxwL = ! gEMmDuhnMIxwL;
        gEMmDuhnMIxwL = gEMmDuhnMIxwL;
        QFnvQEzJzqZ /= QFnvQEzJzqZ;
        nIZKhYgpjoQHOYG += nIZKhYgpjoQHOYG;
    }

    return gEMmDuhnMIxwL;
}

void tRsMXKa::ellaxECUhORFKeE(int ttMWVFxj, int jHbzNVJEeydLvteG)
{
    int kuUSqWTqtJIfU = -322286815;
    double UXJvjUxpVrMJ = 467875.99246728694;

    for (int GoVLSWIyyoeTn = 844006897; GoVLSWIyyoeTn > 0; GoVLSWIyyoeTn--) {
        ttMWVFxj += jHbzNVJEeydLvteG;
        UXJvjUxpVrMJ /= UXJvjUxpVrMJ;
        kuUSqWTqtJIfU *= ttMWVFxj;
        kuUSqWTqtJIfU = ttMWVFxj;
        kuUSqWTqtJIfU /= jHbzNVJEeydLvteG;
        ttMWVFxj *= kuUSqWTqtJIfU;
        jHbzNVJEeydLvteG /= ttMWVFxj;
        jHbzNVJEeydLvteG /= ttMWVFxj;
    }

    if (jHbzNVJEeydLvteG == 1621264539) {
        for (int dQxdyGeXpk = 1729828651; dQxdyGeXpk > 0; dQxdyGeXpk--) {
            UXJvjUxpVrMJ = UXJvjUxpVrMJ;
            kuUSqWTqtJIfU = ttMWVFxj;
            kuUSqWTqtJIfU = ttMWVFxj;
            ttMWVFxj *= ttMWVFxj;
            kuUSqWTqtJIfU *= jHbzNVJEeydLvteG;
            kuUSqWTqtJIfU += ttMWVFxj;
            ttMWVFxj += ttMWVFxj;
            ttMWVFxj -= ttMWVFxj;
            ttMWVFxj -= jHbzNVJEeydLvteG;
            kuUSqWTqtJIfU = kuUSqWTqtJIfU;
        }
    }

    if (ttMWVFxj > 1621264539) {
        for (int MImQqTpzlqZtIe = 1186402545; MImQqTpzlqZtIe > 0; MImQqTpzlqZtIe--) {
            jHbzNVJEeydLvteG += kuUSqWTqtJIfU;
            jHbzNVJEeydLvteG -= kuUSqWTqtJIfU;
            ttMWVFxj /= jHbzNVJEeydLvteG;
        }
    }

    if (ttMWVFxj == 1621264539) {
        for (int mhzpEj = 679169179; mhzpEj > 0; mhzpEj--) {
            kuUSqWTqtJIfU *= kuUSqWTqtJIfU;
            kuUSqWTqtJIfU /= jHbzNVJEeydLvteG;
            ttMWVFxj *= ttMWVFxj;
            kuUSqWTqtJIfU = ttMWVFxj;
        }
    }

    if (ttMWVFxj <= -1726542913) {
        for (int hizlYmwD = 1565003588; hizlYmwD > 0; hizlYmwD--) {
            jHbzNVJEeydLvteG += jHbzNVJEeydLvteG;
        }
    }
}

double tRsMXKa::tWHwo(double MqMgHxqRO)
{
    bool SpegOlldXCZmzw = false;
    double FDWIveVCwJGTC = 698274.9732033435;
    bool NnopyRGfyRlCVeeT = true;

    for (int MPwKv = 155854970; MPwKv > 0; MPwKv--) {
        MqMgHxqRO -= MqMgHxqRO;
    }

    for (int qyzHzAaiBMQZ = 1076854856; qyzHzAaiBMQZ > 0; qyzHzAaiBMQZ--) {
        MqMgHxqRO = MqMgHxqRO;
        MqMgHxqRO = FDWIveVCwJGTC;
        NnopyRGfyRlCVeeT = ! SpegOlldXCZmzw;
        SpegOlldXCZmzw = NnopyRGfyRlCVeeT;
    }

    if (FDWIveVCwJGTC >= 698274.9732033435) {
        for (int LMWPhydAGiD = 323538000; LMWPhydAGiD > 0; LMWPhydAGiD--) {
            MqMgHxqRO = MqMgHxqRO;
            MqMgHxqRO -= MqMgHxqRO;
        }
    }

    for (int SGlFbYrq = 1870061513; SGlFbYrq > 0; SGlFbYrq--) {
        FDWIveVCwJGTC /= FDWIveVCwJGTC;
        FDWIveVCwJGTC += MqMgHxqRO;
        NnopyRGfyRlCVeeT = ! NnopyRGfyRlCVeeT;
        FDWIveVCwJGTC *= MqMgHxqRO;
    }

    for (int mwOXUvulYL = 1084083391; mwOXUvulYL > 0; mwOXUvulYL--) {
        MqMgHxqRO /= FDWIveVCwJGTC;
        MqMgHxqRO -= FDWIveVCwJGTC;
        NnopyRGfyRlCVeeT = SpegOlldXCZmzw;
    }

    return FDWIveVCwJGTC;
}

bool tRsMXKa::QXJJr(string QwWQJuC, string iHzWADJgQFgF)
{
    string ZQixPqaMWbke = string("lCBbIqZnavExXEcUttCWscKSdtmfktznFQTIsRkgLpKCgRfserAsFbsSOIcbPVbXeAWtJcEElBTvMTCENdG");
    double NItfhhdG = -963926.0471360643;
    bool qGQLshv = true;
    string jxXYeTjayr = string("SzdCQFDWVOPEISOaBhcsWeEHTBwHcMwMFctStXnhjxFhpLuvZndosPSRMquYTRkYmKpjtWVqOYc");
    int EUBiFeJsKAzc = -278079674;
    double ggZxmt = -1028458.159298164;
    string Qdfvs = string("JbaeTRKEhvHPIZgqOVAwDkzibqpnSZwMXktZeCEUmdKYFJNwQNHUZPuNlxzbirQhhWCXvCOdGNZMGBlBUnnwCCTHxqyTUoyyhvOEsKAsIsaaVbVBVVDOVeTRJeVUjCpQDZcY");
    string mvULpXgdlD = string("wojnwghpRhAfnYVdDeknTUSEcvWMmEDRCKxdhTANlvNAAbwlliBYlBbljERUNCzxpUqjhXxZuSbXHIDeXzRFVCbDoppzrIWycbobqEutKSJqZojMyJQaNWoSPKxjqVydiWZZLMoZVspbhLnCiVaLFNBGiAGKDpqYwrIhPMCevgXuhdxwCofeeLVeVABMssxTnWRs");

    if (ZQixPqaMWbke != string("JbaeTRKEhvHPIZgqOVAwDkzibqpnSZwMXktZeCEUmdKYFJNwQNHUZPuNlxzbirQhhWCXvCOdGNZMGBlBUnnwCCTHxqyTUoyyhvOEsKAsIsaaVbVBVVDOVeTRJeVUjCpQDZcY")) {
        for (int eFlESxTsAQqMTp = 1354900117; eFlESxTsAQqMTp > 0; eFlESxTsAQqMTp--) {
            QwWQJuC = QwWQJuC;
        }
    }

    for (int JCqYhrf = 1514696274; JCqYhrf > 0; JCqYhrf--) {
        Qdfvs = QwWQJuC;
        mvULpXgdlD += jxXYeTjayr;
        QwWQJuC = Qdfvs;
        Qdfvs = ZQixPqaMWbke;
        ZQixPqaMWbke = ZQixPqaMWbke;
    }

    if (QwWQJuC != string("WEvLFcFrsxPFryVVlMulZWvTqKXCQAaSqkQJkNwywqCFIhqzmDdaybsvyaDsECSNxYENEVCGGCBKNNhpsbbwybsKnJtMcIwydEdGQBJRrSxEzxpuWJkfrvXHOxsbGwWDLsUTdhXbSGm")) {
        for (int laoMRUEEkHB = 278233725; laoMRUEEkHB > 0; laoMRUEEkHB--) {
            Qdfvs = ZQixPqaMWbke;
            mvULpXgdlD += mvULpXgdlD;
        }
    }

    if (QwWQJuC == string("wojnwghpRhAfnYVdDeknTUSEcvWMmEDRCKxdhTANlvNAAbwlliBYlBbljERUNCzxpUqjhXxZuSbXHIDeXzRFVCbDoppzrIWycbobqEutKSJqZojMyJQaNWoSPKxjqVydiWZZLMoZVspbhLnCiVaLFNBGiAGKDpqYwrIhPMCevgXuhdxwCofeeLVeVABMssxTnWRs")) {
        for (int fLZvu = 1829449814; fLZvu > 0; fLZvu--) {
            Qdfvs = jxXYeTjayr;
        }
    }

    return qGQLshv;
}

bool tRsMXKa::lyUqjTI()
{
    double WdVSuXAvvnkJ = 748808.0681997145;
    double BfIJL = 723418.8221899866;
    bool mQdUk = true;
    int uBgLpyZ = -1350490356;
    double BBMwGGbjdmemAJM = 150641.4494879149;
    int oPGoMGTANTSAR = 2127055015;

    return mQdUk;
}

int tRsMXKa::ShAYHRjmhN(bool nWPlJfWdvDQzasmB, string JDaru, int URSjONulnKi)
{
    string NSYugMYwxYbbKEx = string("PDBXFnvxzThyxi");
    bool RAQLqDIZotPAap = true;
    bool UpNyJa = false;

    for (int gyLJBULyLi = 1019174734; gyLJBULyLi > 0; gyLJBULyLi--) {
        nWPlJfWdvDQzasmB = ! RAQLqDIZotPAap;
        JDaru = JDaru;
    }

    for (int KCdGCkA = 1879454093; KCdGCkA > 0; KCdGCkA--) {
        JDaru = NSYugMYwxYbbKEx;
        URSjONulnKi /= URSjONulnKi;
        UpNyJa = UpNyJa;
        RAQLqDIZotPAap = UpNyJa;
    }

    return URSjONulnKi;
}

double tRsMXKa::HlPgrUDuIFVYmX(string RogxcKeaYVJ, double wKHkC)
{
    bool qcZvRIRVF = false;
    double MLqVnxOb = -485512.6561590153;
    string jWmGvCEiJgOpqe = string("nKqYezAcrekQnExPGVDQhqCMUJzyEFdaWWEskvJwWNUOvuAtWybGaoVURWcLRmaaMqViqssVolsLFKcPnjLYtnCWOEpXqmBuwBwWibYQzdAlWHuofSFqeacnylDGSvqhORUXkeBjMfZNjOaCflbAyGsCOproXOPEugluVKzJrzgSHVHRsNoOJMcvsPyOUNujlmcKVEDXLYOiJIdBUVvksxob");
    int rhtpWXx = 1112618612;
    string LDsFRMuIMH = string("GQYDnrEjyAcSwAysablhyVikjDNIMGJGjgasyMnhNJisfvXxsJTnvZzfhmXQXBAWbQHHbSuzQGpFUTXYFblfwvHybVtOKPtyiqdbXXxHVPKAiMRXeHFWOFuZKEAXXxLhMetMHBskteiwBGODoMmGJeSaTUmqS");
    bool xAoMUOGXFdMiiFTb = true;

    if (rhtpWXx >= 1112618612) {
        for (int wKBZK = 458076257; wKBZK > 0; wKBZK--) {
            continue;
        }
    }

    if (wKHkC > 473657.3496712334) {
        for (int beMxxnYgjKNHc = 1260126143; beMxxnYgjKNHc > 0; beMxxnYgjKNHc--) {
            xAoMUOGXFdMiiFTb = ! xAoMUOGXFdMiiFTb;
        }
    }

    return MLqVnxOb;
}

string tRsMXKa::QrryYtXPOFYUC(int TCRWXHZXsElbtt, double KHgYBkxSma, string cLNsTHRIodaVe, string pyyNmKszSGGHMp)
{
    int QIJxZYztkGd = -1866836246;
    int mJskmMDGRhCloTL = 1425327355;

    if (KHgYBkxSma == 804727.4463773698) {
        for (int IXzyPPPpHfEHREl = 1849633054; IXzyPPPpHfEHREl > 0; IXzyPPPpHfEHREl--) {
            mJskmMDGRhCloTL = mJskmMDGRhCloTL;
        }
    }

    if (cLNsTHRIodaVe != string("nWUbOqFHiyfGRCmbtixIPClbzMuVSIWOHzGKFmJAFUYaCaCLacyraIFsrFkzSeKUQnaTwOGjWKJYgehgQTSLzgCbEFCYhvIIkpOXmoGSTEdOsNVOysfGbwVLrDdhxpGglhWLdvFPDqCPXykllcqlwYBGLmKMOUnRMsliKYNpXjOuWZJTDYXFpZpdkpPKjJEQamXsGG")) {
        for (int AcPuasHKImdgAfC = 2073181863; AcPuasHKImdgAfC > 0; AcPuasHKImdgAfC--) {
            pyyNmKszSGGHMp = pyyNmKszSGGHMp;
        }
    }

    for (int pvdyr = 1465077723; pvdyr > 0; pvdyr--) {
        mJskmMDGRhCloTL -= TCRWXHZXsElbtt;
        TCRWXHZXsElbtt += QIJxZYztkGd;
        QIJxZYztkGd *= TCRWXHZXsElbtt;
    }

    for (int IhPmqGBmLECWbe = 2072145556; IhPmqGBmLECWbe > 0; IhPmqGBmLECWbe--) {
        KHgYBkxSma -= KHgYBkxSma;
        QIJxZYztkGd = mJskmMDGRhCloTL;
        TCRWXHZXsElbtt /= QIJxZYztkGd;
        cLNsTHRIodaVe += pyyNmKszSGGHMp;
    }

    if (mJskmMDGRhCloTL != -1866836246) {
        for (int PFDsNMXEvq = 602909946; PFDsNMXEvq > 0; PFDsNMXEvq--) {
            KHgYBkxSma /= KHgYBkxSma;
            mJskmMDGRhCloTL += mJskmMDGRhCloTL;
            QIJxZYztkGd *= QIJxZYztkGd;
            QIJxZYztkGd -= QIJxZYztkGd;
        }
    }

    for (int UMyUtmchtNZZaL = 1494756641; UMyUtmchtNZZaL > 0; UMyUtmchtNZZaL--) {
        mJskmMDGRhCloTL *= mJskmMDGRhCloTL;
        mJskmMDGRhCloTL *= QIJxZYztkGd;
    }

    return pyyNmKszSGGHMp;
}

int tRsMXKa::kpouu(int KpxeAqRka, double GZlDYdo)
{
    string QJenIzKdo = string("CUmrGvROLGosjLQWWaSSDV");
    double ssjmdODTA = -10374.253300176006;
    bool pXcNYfugYmfqrMGw = true;
    int HtGeQDg = -216646768;
    string VSnJaPZTY = string("ShBLLjVoeSnjtyHinOgKRYeyMfWJhmYfJjaWgpxwcfRtRTQVsKZSmueNRyKYJmHGUIuAJMxUSdfOdtQJBBQlGFnIc");
    string eLIrW = string("yjqkQyEPPSPWdaztC");

    for (int Deuze = 1995415684; Deuze > 0; Deuze--) {
        HtGeQDg = HtGeQDg;
    }

    for (int zufRGi = 1265237321; zufRGi > 0; zufRGi--) {
        ssjmdODTA = GZlDYdo;
        HtGeQDg += HtGeQDg;
    }

    return HtGeQDg;
}

string tRsMXKa::ODcIHIDS(double sFYeHJzBRfDVLQW, int fsLlFflyQyZ, int CwmlruhvDpVoLlN)
{
    int TrMIgGwKfPV = 810764546;
    string mDYfHtQMqqGKG = string("LUdNRQMkZOgRgjvbMOKhaJrQyOKyRmkkyZclWWTbHERjojwvjKxcIbWpGNKWTqJVVfsbYIaPJLzaeSXznTQsXbFhqFmyAHiNgoAKJFZnABCGrzTgmfYUuytPlcwBuwviUOnsThTNTbsnvuobNUuiqleURPATFdSRrtGUmeUJgpPLQDnlIvPaPQUjoCzdsPwJNcpjKHRBLXDHemN");
    double ttUmzSZeTTCnB = -640432.5573608766;
    string ppuPAMcfUHq = string("ITDQJflFlbaFNaYZVtOdLslrfuNKragLYOrgdNtsNiJlKe");
    string mqwHNeCHtHuV = string("DZxoqg");
    int SvSvli = 1603602413;
    string flRHiM = string("WglVOchQIwlBVBhCQVSLoRLavZIooMlTujwhzIjixzvtpnOZxZxbyxiYXDsaEQSDDDWOsRqPSZSlssHaehvynKVhKQcuQcKebpJZCuUYBGhAVQzdYNfifociCBimiRGvQWEjSqNqWLfub");
    bool IsILOLiOIUcQbJ = false;
    bool MBveaDyiBrlMp = false;
    int mWZsw = 343225319;

    for (int YmATt = 1215905398; YmATt > 0; YmATt--) {
        SvSvli += SvSvli;
    }

    for (int FJlcKxyE = 2095950505; FJlcKxyE > 0; FJlcKxyE--) {
        ppuPAMcfUHq = mDYfHtQMqqGKG;
        SvSvli -= CwmlruhvDpVoLlN;
        IsILOLiOIUcQbJ = IsILOLiOIUcQbJ;
        TrMIgGwKfPV = TrMIgGwKfPV;
        CwmlruhvDpVoLlN = TrMIgGwKfPV;
        TrMIgGwKfPV += SvSvli;
    }

    return flRHiM;
}

double tRsMXKa::cveAGIqOLdmcg(double ByLfqwBCx, bool urwVkmyGsZwjKr, double VCsCgkCy)
{
    int WEAXyRGDe = 1534305733;
    bool BnxEvLFNkIjcnGds = false;
    bool jgCzeoUSZKIajO = false;
    bool kvHGqvS = false;
    string BKXPJvYTPp = string("RatmsRFgiosnWOtTxxzsOiqpUVCaFhlaUyxukLeQdiagSQkXHqbwOJXvibHhdNWQumnviWZCUJnbjytsuIeelhPMQjfeEUjXXCwlB");

    for (int ZBvPQVMLiYH = 1565530047; ZBvPQVMLiYH > 0; ZBvPQVMLiYH--) {
        urwVkmyGsZwjKr = ! BnxEvLFNkIjcnGds;
    }

    if (ByLfqwBCx >= 190198.91166417205) {
        for (int VZQmbfnnG = 311526374; VZQmbfnnG > 0; VZQmbfnnG--) {
            BnxEvLFNkIjcnGds = ! BnxEvLFNkIjcnGds;
            kvHGqvS = ! jgCzeoUSZKIajO;
        }
    }

    for (int RjMRtcjurUyCQbFQ = 1693092266; RjMRtcjurUyCQbFQ > 0; RjMRtcjurUyCQbFQ--) {
        BnxEvLFNkIjcnGds = ! BnxEvLFNkIjcnGds;
    }

    return VCsCgkCy;
}

tRsMXKa::tRsMXKa()
{
    this->tAhMJqYRtFNZnnb();
    this->sQqNkr(2022172159, true);
    this->ellaxECUhORFKeE(-1726542913, 1621264539);
    this->tWHwo(763239.7437178491);
    this->QXJJr(string("spHhTFxVlRieqRHvlQRSVtwYStWnnPCTshZAiCtudsNCJKEJvNirkQNPUotOFloblbfFDtUbKhC"), string("WEvLFcFrsxPFryVVlMulZWvTqKXCQAaSqkQJkNwywqCFIhqzmDdaybsvyaDsECSNxYENEVCGGCBKNNhpsbbwybsKnJtMcIwydEdGQBJRrSxEzxpuWJkfrvXHOxsbGwWDLsUTdhXbSGm"));
    this->lyUqjTI();
    this->ShAYHRjmhN(false, string("FOPgCGEQVXcSoVstkGBAToHXjQHOomWRSrVDLnCwdUomeUXxtSvHpnKJRvqaXHEfNPsYAqbnnCFnNFYwrZRdlqGHBTeiuTTEdtmypqmeUKfBrXKSjrKMVcWqDIJYzxPIktzLzefCvmuGDpJnmoKxRcXMhEzYvVFQnLqeSuraIQzcpSxqyEEmtqstdjTPSryYKTTbpViTjqOvrfqPrNmtIxrnTjFXCHnOPqgnBBBUtEAwvhSBrOtuPhGrmmP"), 1869957262);
    this->HlPgrUDuIFVYmX(string("LiPnswRLApyynivYsZLoajGakIntUsCZkYuAAJhmYbcqUDuklXzGbusxRdhovSeuCZSXISfgPlNILkxZVACsIimdCwrIlfHcUNXnKAgszoTsckNxCzGmUlHuQNPtJTRIYBHLAJj"), 473657.3496712334);
    this->QrryYtXPOFYUC(-388432975, 804727.4463773698, string("nWUbOqFHiyfGRCmbtixIPClbzMuVSIWOHzGKFmJAFUYaCaCLacyraIFsrFkzSeKUQnaTwOGjWKJYgehgQTSLzgCbEFCYhvIIkpOXmoGSTEdOsNVOysfGbwVLrDdhxpGglhWLdvFPDqCPXykllcqlwYBGLmKMOUnRMsliKYNpXjOuWZJTDYXFpZpdkpPKjJEQamXsGG"), string("foSoeZBiYrGFFMSRnDOkuBrPEfxviFxDeriQzzQoZjhIKwxkqtOQdgpAsEaVkERasoHDpORwJPilbfNocssdODsfyDuYfOWUNfSxcPQIRWxgtaeOmfYjvQjBLHnNrjJXfHJhrdJT"));
    this->kpouu(-1460698983, 760347.4965761338);
    this->ODcIHIDS(-832397.5619971217, -416873553, -1205397122);
    this->cveAGIqOLdmcg(325852.9918505427, true, 190198.91166417205);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mKfbXLWGrls
{
public:
    int DDRDGjPQBuiXsuk;
    int qtnGFRg;
    bool SqyxBvzO;
    double VNmOSUsEzTwpgjd;
    string yNQWSKVjNStvBf;
    string nQAsTLORQ;

    mKfbXLWGrls();
    string ZUalJ(double BEMxcV, string UOcYm);
    bool ImWARPMfgYD(int EVzUekYsySQ, double GYMctgGByaFyT, double FwfvlZTnB);
    void qrqYQPlp(int OFzbUjvOdJhupN, int kOlcliCAGRCmkjqL);
    void PGrlgOFwuzVK();
protected:
    int ZWJXR;
    string vVMziAmS;

    void fJvrBbwnoqvpl(bool FCsYorqt);
    double rTYVrVnnFTG(bool lPKFvLxBGh, bool CGPPbxEcFXaH, bool JvKrpILYEdyipERE);
    void XFTZE(string toXHVhMZojom, double bcPznxcQbJLzh, bool efPTGLnctxi, string JKYJul);
    void HDiRPsh(int HzlFcw, string cxdvVZMgJy, double gMlwOfqDEEMxa, int sDfSf);
    string hHWbnhtXTqeG(double eSMDgJYtmNTD, bool KlrfaBsQPQGyXr, string TXCWbQbBxF, bool VKSkEvS, string QcIylZoqiprMhN);
    void pIsZOJxZzbteneP();
    int luxAIoyH(bool jmekbgGLIzByi, double pgyFOm, int yCKVkpV, string cKAVztjISgMIr, bool ujDWaD);
    void GVQsPGrEuhEyF(int DmMASGHp, string ulkZJB, double EFcmShGBdTh, string kObGHeE);
private:
    string yQlKFEfTZPa;

    double qGREgGBlwtE(bool GEOtbqzPttOlLKY, bool AkdnEqHPml);
    int xrxEgqGihEoX(int nFOiFFYyrCKMe, string hCVjEuKxnmY);
};

string mKfbXLWGrls::ZUalJ(double BEMxcV, string UOcYm)
{
    int avUUhzIMuDOIKYqJ = -1244298040;
    int HfQPzNNTP = 1785460905;
    double ZNQbVcUdMucBw = -672582.6648795705;
    string VAhaWBRKjvTOBPK = string("oxDfxDMdlAJSIksnYZAfWBCCdZCKENASNXVklbTEoryApxyaAvKtwrSuxhFjSOdCIIdeVNTQTwgHdyMlOxlEqAYdPRDCoARJJwVRCTeTmmIimLbGlAfZrWJthIMGKAcwaLRSqaukOqywxdidnTehyzgriNMsZOpaihMTEQZZoccnpuQHuydbmeGoKhYzTDMPRfIAOjdVZPduu");
    bool ZAvxHOw = false;
    int uIqAnzlYJTnWBA = -652489229;
    int fnubHHXdNtUKdhp = 1966035198;

    for (int hXxAStJgjpWux = 1670875684; hXxAStJgjpWux > 0; hXxAStJgjpWux--) {
        continue;
    }

    for (int XLHYDjku = 190996923; XLHYDjku > 0; XLHYDjku--) {
        UOcYm += UOcYm;
        BEMxcV = ZNQbVcUdMucBw;
        HfQPzNNTP /= fnubHHXdNtUKdhp;
        avUUhzIMuDOIKYqJ = HfQPzNNTP;
    }

    return VAhaWBRKjvTOBPK;
}

bool mKfbXLWGrls::ImWARPMfgYD(int EVzUekYsySQ, double GYMctgGByaFyT, double FwfvlZTnB)
{
    bool HeNOpuVIzrpaWxH = true;
    bool GaOQwAqlwI = false;
    double ucAFZ = 542953.3792993131;
    double dqpkxjN = -644907.0690828753;
    string HoNhw = string("tVwVvqxSViEwKjyWuTBLwyedRqAHOCfWaeFIFpKEctWvGGwmuTqwxVRnmhGMpHDLGnPCugVfRVGNukmjcpROPIiIkifM");
    string JiFoVANsFatfV = string("AQkxBuGocdllVysavRQNDSlUrvxKkCfXvYZSzqeUqWHHICcxWLehCcJmxRQqKu");
    bool qiOlvFyy = true;
    bool ZszMUGtgqBK = false;
    int ALjbxFMMDX = -1886539252;

    for (int ALmlLd = 691190364; ALmlLd > 0; ALmlLd--) {
        HeNOpuVIzrpaWxH = GaOQwAqlwI;
        GYMctgGByaFyT -= dqpkxjN;
    }

    return ZszMUGtgqBK;
}

void mKfbXLWGrls::qrqYQPlp(int OFzbUjvOdJhupN, int kOlcliCAGRCmkjqL)
{
    double zyvgkN = -84761.02650400891;
    bool CjyQlxEsyQNgJ = false;
    string GbhWAZGJmdX = string("WtEfiPTQLauWKSTCwnpAilvrLxtvLWigDwEfmORXFrruuWoNKKTWJuqYcNSmNOxZIanhpugbSJIIcvRTcdXatrtIousyfexaXBpDnI");
    bool bqaLqc = false;

    if (bqaLqc != false) {
        for (int yGxmKbHeUuPQonw = 295954922; yGxmKbHeUuPQonw > 0; yGxmKbHeUuPQonw--) {
            bqaLqc = CjyQlxEsyQNgJ;
            kOlcliCAGRCmkjqL = kOlcliCAGRCmkjqL;
        }
    }

    for (int ZYdJFn = 304683362; ZYdJFn > 0; ZYdJFn--) {
        OFzbUjvOdJhupN *= OFzbUjvOdJhupN;
        OFzbUjvOdJhupN = kOlcliCAGRCmkjqL;
        zyvgkN /= zyvgkN;
        kOlcliCAGRCmkjqL = OFzbUjvOdJhupN;
    }

    if (kOlcliCAGRCmkjqL != 1995866487) {
        for (int GFaEBbXqCQPYK = 1185255507; GFaEBbXqCQPYK > 0; GFaEBbXqCQPYK--) {
            continue;
        }
    }

    for (int YUiHkApVPr = 1157570533; YUiHkApVPr > 0; YUiHkApVPr--) {
        zyvgkN += zyvgkN;
    }

    for (int SetRGRz = 312429662; SetRGRz > 0; SetRGRz--) {
        kOlcliCAGRCmkjqL += kOlcliCAGRCmkjqL;
        OFzbUjvOdJhupN -= kOlcliCAGRCmkjqL;
        OFzbUjvOdJhupN /= OFzbUjvOdJhupN;
    }

    for (int SyUAMCHNWo = 1827184247; SyUAMCHNWo > 0; SyUAMCHNWo--) {
        kOlcliCAGRCmkjqL /= OFzbUjvOdJhupN;
    }
}

void mKfbXLWGrls::PGrlgOFwuzVK()
{
    double MdChXfIASIPloFK = -377500.1866333724;
    string NDeuN = string("BqEKXKFvmOfOOynkmVXHeALsIpkLdbAyIKvSUYMlWLtjiiCcCDuMLgKqDdtKdnxMMqIsvgatUnAcqatveuxxZDRkHuVQFWxdhsOusQQBztSDdiKymaGOsHbnrwQI");
    string eIRREZI = string("DzibzViOPxnNkMKBaKoIKpvTJuUCudWAFTWioIPOXlGdfquqLCyqXjBXgUFAdHWSYPlOXOVDbEwNySGimvoxGelAVDxqBejfgACxKybdXCkrtwlKnHtFJoVKmYdGQcjOrfdiDhAMtLKROGpsumBhaffQlvbghbTHzfyJrzT");
    double czrwlx = 777468.8521488277;
    string tVWazjDDFHsKl = string("ohavuCEuDbTuCXRJWhUodamzDHbyMBVVthUnGxQxqasqPgsMIvxnDeXjsMXSEsUUsIdsgmIwPoWtFfOhXxBXepsQNaIvkIQcpIlYzEMeddTxESWsOdERbGwAvEqnUoLlnQucoCeIdWfAxVCYOycrQqoKnsWiNjrnRsflEdCGqcFbcCBDBjMLMOGnZFiuylgWllehNdoehIaxXusJwinnCDBtKaDAAWvVxavciIqKzBPcIgfpcpclRLalgAQzwI");
    bool HxMllMDltHrF = true;
    int GhdYCyEWynusKr = 1912503556;
    string nOnvV = string("AJWAQdAmeDCRKErplIlsDHMIdpSXenZMpHRiSIOOCudYbypDiGCZbARDSjSmnliDslXJkqUBFsDQeBmZrIZakswksTmKUcFRuHDhTyCqDtbPciYUaopajeEvEPndWkPuYhDaTpxctHeFIhmzDvUCMWdPdcMZvBlqeyOtCzKmTFobodQkaTMEAHeEmYzPPzygizrJQPxqcStTUxKtRxbwQhxmcoAnrnLviJNDQ");

    for (int rIepm = 921137820; rIepm > 0; rIepm--) {
        nOnvV += nOnvV;
    }

    for (int sDZiC = 1830502088; sDZiC > 0; sDZiC--) {
        GhdYCyEWynusKr /= GhdYCyEWynusKr;
        eIRREZI += eIRREZI;
        NDeuN += NDeuN;
    }

    if (NDeuN < string("AJWAQdAmeDCRKErplIlsDHMIdpSXenZMpHRiSIOOCudYbypDiGCZbARDSjSmnliDslXJkqUBFsDQeBmZrIZakswksTmKUcFRuHDhTyCqDtbPciYUaopajeEvEPndWkPuYhDaTpxctHeFIhmzDvUCMWdPdcMZvBlqeyOtCzKmTFobodQkaTMEAHeEmYzPPzygizrJQPxqcStTUxKtRxbwQhxmcoAnrnLviJNDQ")) {
        for (int bTofxon = 109892369; bTofxon > 0; bTofxon--) {
            eIRREZI += NDeuN;
            NDeuN = nOnvV;
        }
    }

    if (czrwlx >= 777468.8521488277) {
        for (int cUsIs = 686974248; cUsIs > 0; cUsIs--) {
            MdChXfIASIPloFK += czrwlx;
        }
    }

    if (MdChXfIASIPloFK < -377500.1866333724) {
        for (int LrYtjpjKL = 456874398; LrYtjpjKL > 0; LrYtjpjKL--) {
            continue;
        }
    }
}

void mKfbXLWGrls::fJvrBbwnoqvpl(bool FCsYorqt)
{
    bool JXsDVvrL = false;
    int YwDLf = -1664705103;
    int AjmcDtczJft = 483917053;
    double dVNVJRfV = 1042354.1053898681;
    double mBScuaUDZADVPd = 120935.9579915399;
    int dfJoCNs = -2057991663;
    int eIDVeAKjipTJS = 146402157;
    bool axnOEGkd = true;
    int VieGHZrzYIYEI = -275404631;
}

double mKfbXLWGrls::rTYVrVnnFTG(bool lPKFvLxBGh, bool CGPPbxEcFXaH, bool JvKrpILYEdyipERE)
{
    bool aTblS = true;
    bool QicVEVXfE = false;
    double AmMyrJZngT = -244433.15543377353;
    int iBBvIvKIHPPiLJhf = 365931247;
    int STzHS = -1447442023;
    int ZBYJpOtaZuuic = 1884147167;
    string USSePKuD = string("tIwmsjagJMzOhuJrXgEkqLTwsWVwkMiRDygglIYWlAehlGvoTdujKtUAoEyKPTBbnKBDqmNaDpZCJnvNMYEahhWgHRkkWUaQlJjrJoavKLtMqYkFoHpdKuADDzTRBUTaqQUfAEenUmlTrxQpcTBQMFzkjgZzYxIbAijWxJzMRVlDOaoJHNOVYMpXbEFEIYOZ");
    double ZiHUUnbNSca = -792310.1257873616;
    bool OInbCCHzTuZleWmT = true;

    if (QicVEVXfE == true) {
        for (int fvsAxUcFF = 405347016; fvsAxUcFF > 0; fvsAxUcFF--) {
            OInbCCHzTuZleWmT = ! CGPPbxEcFXaH;
        }
    }

    for (int xkfDDuZlkwls = 1634393183; xkfDDuZlkwls > 0; xkfDDuZlkwls--) {
        iBBvIvKIHPPiLJhf += iBBvIvKIHPPiLJhf;
    }

    if (aTblS == false) {
        for (int nSQwFCIVA = 873745257; nSQwFCIVA > 0; nSQwFCIVA--) {
            CGPPbxEcFXaH = JvKrpILYEdyipERE;
        }
    }

    return ZiHUUnbNSca;
}

void mKfbXLWGrls::XFTZE(string toXHVhMZojom, double bcPznxcQbJLzh, bool efPTGLnctxi, string JKYJul)
{
    string WBbyjyFIqvRk = string("BfuYasCmUdNkeTCPxZnDGzaZJOVXOMdGAkfgtZtfSTtYynaMAdXmWWIMTJfqwdYTuYnwPAsQjmgsILBwfaFmTxR");
    bool PJkMQ = false;
    string EEEPUi = string("UZbgCHXraKtMZb");
    bool fWsauZbuOTAbj = false;
    bool wyTnS = true;
    int boCrpCm = -1785122851;
    bool njYRtHEqGVil = true;
    bool cUofIxXbZuazIG = false;
    string FARiPwReLamtRk = string("YIIaCAoEPnGKnuVswhEjAgD");
    bool ZVGcvEqkpysBF = false;

    for (int JQgsZY = 1628986174; JQgsZY > 0; JQgsZY--) {
        continue;
    }
}

void mKfbXLWGrls::HDiRPsh(int HzlFcw, string cxdvVZMgJy, double gMlwOfqDEEMxa, int sDfSf)
{
    double tcqouVNfUteXxaP = -789660.244733896;
    string WMyZJHwkwL = string("nMGnBvxrQmjbVmNHmVuAwpFWeDCzJQePeZzYybxkrsAFUxPJFYvdxnjwjMkpgWuwPGBdHLLKxgGPCHgPfMDVPWNmUeaDXUIimpnIxsrOWwUvOYDaUswskGeeQLvgnjuvOzAJejiKJUJCONgDwmKDiXxtpaIAIbhDtTencpGsGoZUrQQZHYfWoWLpfcmyRvzmXBAbFrrPCzqjyJ");
    bool lewoPc = true;
    string SWlFEGMVdgbhTY = string("bchPExcanqpoSWaieXBDwSeFGXrMxWhrWTOvGuTZYKVGNvycoiTrzqepOjOuWxlFkyOCPccSrnIjYJTjnr");
    int LgQKmtJgs = 1677194205;
    double zfKiO = -877441.62356519;
    int HdnkVaaXhM = 1917694295;
    double xwFMntFB = -802760.1172111834;
    bool skJZnYIKslRBXfSx = false;
}

string mKfbXLWGrls::hHWbnhtXTqeG(double eSMDgJYtmNTD, bool KlrfaBsQPQGyXr, string TXCWbQbBxF, bool VKSkEvS, string QcIylZoqiprMhN)
{
    bool yUrlmWaDM = false;
    string mIqLbjDxTflG = string("rtxfQaT");
    double thQXBf = 254764.8701695354;
    string YWsVJqFSAX = string("XSUXCZAVMDqSaPURSWXQwhCKcPqYJJquKHoWujtkKuaDXSCYbrwQ");
    int dRvywLA = 1132178553;
    string CPcqNgMltuGH = string("RmcHFlgDHVnFiJQqjmDahxApDerfjaSTdajXPiiOPDhaGqzdmSihiYGlFsiBJPqGsvEcrMpLxTCnrOWgKirNgwmoGSRgQKYcGolXONKjiunKAZrrhOKDBlpATfQoefPsCCGBUYYfUrtlbMqjDkjTadttEyulVVGpPIwrqEevGhjRmSQoIGhFfASuZDRJtglUyXvbqjBwShMPsugEjZwrKlTbhjlbehYRAsktwtaWJEOgwpCf");
    int cEvDrYPIYzIDCM = -453332348;
    int WedJYk = -981921773;
    string CaeLKwVzbA = string("domOjvOqQJFmBIQMvBJSUSbxaANgdfLpfZynpkwIhzQQLOVfDqMVbgdujBxGvBaquTIGJGwxiqXsAKikn");

    for (int OTKmDOEypl = 1343865671; OTKmDOEypl > 0; OTKmDOEypl--) {
        YWsVJqFSAX += YWsVJqFSAX;
        KlrfaBsQPQGyXr = KlrfaBsQPQGyXr;
        mIqLbjDxTflG += mIqLbjDxTflG;
    }

    if (CaeLKwVzbA != string("rtxfQaT")) {
        for (int HJtqbwNhsT = 1281335055; HJtqbwNhsT > 0; HJtqbwNhsT--) {
            continue;
        }
    }

    for (int JjBXJhjqmxHM = 1074746742; JjBXJhjqmxHM > 0; JjBXJhjqmxHM--) {
        eSMDgJYtmNTD -= thQXBf;
        CaeLKwVzbA += TXCWbQbBxF;
        TXCWbQbBxF += mIqLbjDxTflG;
        KlrfaBsQPQGyXr = ! yUrlmWaDM;
    }

    if (mIqLbjDxTflG >= string("rtxfQaT")) {
        for (int RMTfneUEFTnv = 904468059; RMTfneUEFTnv > 0; RMTfneUEFTnv--) {
            continue;
        }
    }

    for (int ZUkpHyBCMdEC = 1747483766; ZUkpHyBCMdEC > 0; ZUkpHyBCMdEC--) {
        cEvDrYPIYzIDCM -= dRvywLA;
    }

    for (int bmlUDlRmvzSNBE = 1547608301; bmlUDlRmvzSNBE > 0; bmlUDlRmvzSNBE--) {
        dRvywLA *= WedJYk;
        CaeLKwVzbA = CaeLKwVzbA;
    }

    return CaeLKwVzbA;
}

void mKfbXLWGrls::pIsZOJxZzbteneP()
{
    int iqsGk = 550834974;
    string myHRqqMUm = string("vDzGJPskwOvDMUBnNqlkWqQnQiNtmmWqIQFfKlTKEzttZVCIXiBtisnGtNPlfZMbUQDQpKwPoOXtmvsFALFRsoUnmTOKknFshzQjPxjxCRGJRMotCTNtHfSFkMDiNDMCGqRmixOJdKwVtqeTKubkzdzcfxVGbYpr");
    int Qslbebbsji = 1712709416;
    double AlDndyBGATPM = 622388.5223123027;
    int mdekGsGrPcBuY = 1075569414;
    double SWmvQRrrfWk = 627547.7345172621;
    double FvdMGETPpxyw = -865749.0372703071;

    for (int sSwaXv = 1138346628; sSwaXv > 0; sSwaXv--) {
        SWmvQRrrfWk *= FvdMGETPpxyw;
        iqsGk = iqsGk;
        mdekGsGrPcBuY *= Qslbebbsji;
    }

    if (Qslbebbsji != 1712709416) {
        for (int kAitnnkZvQC = 563354517; kAitnnkZvQC > 0; kAitnnkZvQC--) {
            FvdMGETPpxyw -= AlDndyBGATPM;
        }
    }

    if (Qslbebbsji > 1712709416) {
        for (int uOqXeq = 1512219024; uOqXeq > 0; uOqXeq--) {
            SWmvQRrrfWk = SWmvQRrrfWk;
        }
    }
}

int mKfbXLWGrls::luxAIoyH(bool jmekbgGLIzByi, double pgyFOm, int yCKVkpV, string cKAVztjISgMIr, bool ujDWaD)
{
    string cbzWbywmAvnpP = string("QSlQVwzovkjdTVzNTnxycepdbweDVNleYnVZFSqQgruPIKcqDkiNtKmXEdyofSTdpHIyNNxisFiYibuwHCpRpBlWWGsEseybzZxfY");
    double SEuLpTbeqm = 587749.0443978616;
    double zBQBAVWhsBcDpLM = 208494.31436705127;
    string QBDme = string("znLBgybsuSeNUecKJaLYmcnRFtivQaGGVDFuGYXYkzaVRkkhNyNIWqaZZbsPFQJoSFteXUYntPrXbQgLzzMyXigeiOuuBGcQbwgpHbdTLHlixPFQcZkLxYpYkqEYCglwmNOIhNmDaUDDUrQGgbbEhxPxkjcDgRTGhOfxlIlPcUUFlzFLiCFrMCgiTwpzpPjxuUFFMVVioFoslPyAjokZQhAuqZfemneqYysZFIEIfBTAbfxbPkJDi");

    for (int JBjnfVSTNYfLA = 121344854; JBjnfVSTNYfLA > 0; JBjnfVSTNYfLA--) {
        pgyFOm += zBQBAVWhsBcDpLM;
    }

    for (int qfKUvwgdujULA = 1016866680; qfKUvwgdujULA > 0; qfKUvwgdujULA--) {
        continue;
    }

    for (int JWxHC = 1269534972; JWxHC > 0; JWxHC--) {
        jmekbgGLIzByi = ! ujDWaD;
    }

    return yCKVkpV;
}

void mKfbXLWGrls::GVQsPGrEuhEyF(int DmMASGHp, string ulkZJB, double EFcmShGBdTh, string kObGHeE)
{
    int HxDEFW = -1611002191;

    if (kObGHeE != string("rGrHpXuVvQOJPaQJGlABxtQjbmEsoWrWpewsPodJkhQZhEsKAHDIjFIaVjAdbmUIfOozTbmcmOxHZIfauepcehiliTgWDALkXGesEuhdqVrqoQCMKooZCNwuKmhfyLOgACNLTHgrsYjOfoYGyJxZiQpmAuIMgjqtuSLLpeKoYwfXSRbtHcejXQM")) {
        for (int uEOXqyDRkqbRGFB = 2003169419; uEOXqyDRkqbRGFB > 0; uEOXqyDRkqbRGFB--) {
            ulkZJB = kObGHeE;
            HxDEFW -= HxDEFW;
        }
    }

    for (int iNiNWSo = 1260903449; iNiNWSo > 0; iNiNWSo--) {
        DmMASGHp = HxDEFW;
        kObGHeE = kObGHeE;
        HxDEFW = DmMASGHp;
        DmMASGHp = DmMASGHp;
    }

    if (HxDEFW != -1815366575) {
        for (int zkdktANKyJFO = 556462201; zkdktANKyJFO > 0; zkdktANKyJFO--) {
            EFcmShGBdTh += EFcmShGBdTh;
            HxDEFW += DmMASGHp;
            DmMASGHp *= HxDEFW;
        }
    }

    for (int vvKrPRGTUEUfev = 161232967; vvKrPRGTUEUfev > 0; vvKrPRGTUEUfev--) {
        ulkZJB = kObGHeE;
        ulkZJB = kObGHeE;
        kObGHeE += kObGHeE;
        ulkZJB = ulkZJB;
    }

    for (int pevKPdXjQ = 1534954272; pevKPdXjQ > 0; pevKPdXjQ--) {
        HxDEFW = DmMASGHp;
        kObGHeE = ulkZJB;
    }

    for (int swYjgholJBaCnZM = 1017209498; swYjgholJBaCnZM > 0; swYjgholJBaCnZM--) {
        EFcmShGBdTh /= EFcmShGBdTh;
        ulkZJB += kObGHeE;
        DmMASGHp = HxDEFW;
    }

    if (DmMASGHp >= -1611002191) {
        for (int vERLMvpImQHG = 102173843; vERLMvpImQHG > 0; vERLMvpImQHG--) {
            DmMASGHp = DmMASGHp;
        }
    }
}

double mKfbXLWGrls::qGREgGBlwtE(bool GEOtbqzPttOlLKY, bool AkdnEqHPml)
{
    bool KmiKmqwtTHyIr = true;
    string mZdGh = string("DWyceempVLIAAUKRUPRlnhzKcMvJFqiPHLIbRJNQEmTIHPgTISHSCUcsFhKNdjOXPkZdIvYgDnqzVVVFpRJlcYFdhokPTtdtunlEmmacmiEqDjEHPgOiGyTgEWXOIZFtkOemjYUeJqpBijdwcdVxNmHbRFdj");
    double NSfcHiyfZaAkmw = 485582.4370167674;
    double hTTAZtLbqXZPv = -451900.80112785974;
    bool zKecaYns = false;
    string iiLXjhRYfSwdZi = string("LtVrJIQjeJAPWMNoVbdmtmgGdlpVUShsXsziotjuacnjteahBrOcajQQOvJQOuBqPxBqyYFtpMNPzTAaAoSyTIgweUCnJTBLUmyTasDwbslWmQNqgmAfDJEjCjVdrOkgDuuvZKfbKjuylpbvAWgIooSuwHobERZvWjftSlY");
    int JTsVsXkDro = -1483331609;

    for (int nonEUKN = 1334428667; nonEUKN > 0; nonEUKN--) {
        GEOtbqzPttOlLKY = ! AkdnEqHPml;
        GEOtbqzPttOlLKY = AkdnEqHPml;
    }

    if (mZdGh > string("DWyceempVLIAAUKRUPRlnhzKcMvJFqiPHLIbRJNQEmTIHPgTISHSCUcsFhKNdjOXPkZdIvYgDnqzVVVFpRJlcYFdhokPTtdtunlEmmacmiEqDjEHPgOiGyTgEWXOIZFtkOemjYUeJqpBijdwcdVxNmHbRFdj")) {
        for (int cKfrC = 1359229151; cKfrC > 0; cKfrC--) {
            AkdnEqHPml = ! KmiKmqwtTHyIr;
        }
    }

    for (int YDmXssBmCPlFjv = 373280012; YDmXssBmCPlFjv > 0; YDmXssBmCPlFjv--) {
        GEOtbqzPttOlLKY = AkdnEqHPml;
        KmiKmqwtTHyIr = AkdnEqHPml;
        mZdGh += iiLXjhRYfSwdZi;
    }

    return hTTAZtLbqXZPv;
}

int mKfbXLWGrls::xrxEgqGihEoX(int nFOiFFYyrCKMe, string hCVjEuKxnmY)
{
    string UWrBjbpeQbCNz = string("scSTkZxGGbekepczlopRAwuGmmEbenrNstiVftjNTxZwaYTQtIOaJJYrMqSpslhsJjjAmvZFrOpbJjQTERDcXhrBWZtpgPQxUzUMTjBLOyZmjciPpxJTyyitrZSaQRVcPiHqRpzCqAdFNazNiOgYtaQynWawPCPDyEMSFwUPpSSFxCMZQfbmPZqlQiIRScgmeBTESSsdbKavjfbMLWzGIPKGGVQBguBMxMlrZKjgnsstVCPiQJADDVEtxB");
    bool dYebBRUrHaEvU = false;
    bool IwfQKcLzrBZQfXBT = true;
    double IZvzJasgWqbFyB = 596483.9277795565;
    string oaXPtYVaBdNjPYr = string("UzpZqTBrlVuseGQXmHWjbASvL");
    string QlwtBCvnq = string("dhQm");
    bool WguoefbFrdyGy = true;
    string gGYmH = string("GNoVpgNGxtSlCDvoOUWWbkntdjfsZfWTRixBSITfRMWNvRxMXYNBoVJbrfOxfYLdeNkmkpLVMOdxUmTVoqAYljhw");
    double OgAeGbqGxvFPInvg = -472665.20519651315;
    string flCOxeO = string("XthgvkprXLHVDDsWfYkbusRqTINYtRumjvJTWqiuyPwiUPkAfAqUbWDrMPfkPGtkQzhSxySBDHacIkcSulRdhSTDAuqoZwbNwrFLyMoDBoRLSYqcWEIcxSKoIYoKsjtRbwDmDKanTmytqHoDThHnzZYVoyGYf");

    return nFOiFFYyrCKMe;
}

mKfbXLWGrls::mKfbXLWGrls()
{
    this->ZUalJ(404120.0517982217, string("TLeRYgsCfUfAFwtEnLHPsgmabcJbEiDmDPXtyIzdoddnxrocCJQLxGkVwPwuBKgjBeVLYYmjUgubTjEfnEESRMsQVAmVMxUdFxDwgOxFIkxdsrSUqDeEsjXFBUNVlKABCJxPHcoyVGcALMygFDBWnLsWSPyNjYlrNIXRIMvNRmOMjyJdhhveYuEXQrxAAsgfvDkgjmKXxWeiiBVOxJvapikJd"));
    this->ImWARPMfgYD(1856413943, -191201.70445179765, 242032.04245335943);
    this->qrqYQPlp(329282916, 1995866487);
    this->PGrlgOFwuzVK();
    this->fJvrBbwnoqvpl(true);
    this->rTYVrVnnFTG(false, true, true);
    this->XFTZE(string("wIFlVRSCCxRRwyvJExeBqVULCpuiDLJBNbFmraGiKbkdknNiIcQdywBdtETWIrxFLhfsyxuYaIx"), 619388.0258630633, false, string("QdIsQGkVzXJofziGjUVtRyXUhxWqGgWdBwMOfeayeJwbonjZkcUivRIgLCglFQvBjNlnEhkzwaUsosKjDquGeWYKkIjGJrFpOawWVMzbfcMnxhtqyMJSMRZyDXWwdTMVfJCLkQChAcPsKHwAmbSvyZ"));
    this->HDiRPsh(-914121422, string("AKdHbRhtGQmzRCevmpRWpIaeDepxSiehFHlcKQersLvFTZcYsGHvVRzsLACpGvLIMeNgDHbTpUWHToWyBzeGDoaxQseqGxQXGITxMgfWTcXjTzWamWOCVYGRtyXunnFqfaiPNeijVSnFLbBKIirLeDnHvNtSZAkyukVajRpSqevQlVlGDHUHsryljf"), -858031.9743020241, -2139731730);
    this->hHWbnhtXTqeG(-47850.671419835504, true, string("oIxQvLOFvSaEwZKUNqdTNffLMdchaDfUzLWhrGOBSCUBPhGSxAVHTYDpYEzHdMLXXVZqvdWaCiYzqZotIbhibH"), false, string("AUWgGDOetUUmTvxDLnanpCYaXcSPuFbuNbQwYTYHIAJmjYFkoBKyeuFobDwtqClCTXnAebTrswxUSQCkvnRmGsoEobCmdBVSyzgzGDCiyPWtUbUZLQLYERajBLoWNfVRMomUCCarJLQEDWhe"));
    this->pIsZOJxZzbteneP();
    this->luxAIoyH(false, -701966.6714971836, -1621029225, string("UNHCLVNurgYZiIuYZqQPhZeXptqnOUtTCOJft"), true);
    this->GVQsPGrEuhEyF(-1815366575, string("rGrHpXuVvQOJPaQJGlABxtQjbmEsoWrWpewsPodJkhQZhEsKAHDIjFIaVjAdbmUIfOozTbmcmOxHZIfauepcehiliTgWDALkXGesEuhdqVrqoQCMKooZCNwuKmhfyLOgACNLTHgrsYjOfoYGyJxZiQpmAuIMgjqtuSLLpeKoYwfXSRbtHcejXQM"), 853656.1760504302, string("wuJYHINEDuJuMcKbjWXOvqpygYehOihhUiDFlRFgsxPeCheDHVkbDJkrWVKXSMcVYHJcdZhiTZrSWEprLQutFpvTARadIUvwfigbRIEEcNGvnXNdPSDihVZbvFCMErMqyHk"));
    this->qGREgGBlwtE(false, false);
    this->xrxEgqGihEoX(-1733675566, string("epsekeYYcqbaiQsQquBJImZcELFobXBwuWCLHvAsAASIvFyMNuxACJyTippJcxdrcDxMfXiKlEJxHfxNyKeVseZhHPnXUUlgCniMfUmhbIyyxqDSZhmvVXRHCVBasMhiQxbNnVCTWpNDnHteEETeNzFtAFcbkDEoJfMwgXECprXDYLpbeUOMolnoBgDBzRQWfkKJQQVTwiUvJHhGSmXNgCLcsSkZJTRNNIIeuGjnMrIURgkQxh"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VMMnN
{
public:
    bool YqfKDB;

    VMMnN();
    bool HYhOIjALh(bool AwyTGMoyV, int mwwlFt, bool JRZUhCVRZZ, string RExtzCRr, double ycdadtvAx);
    double JWffuihstC(int fuqmOrLt);
    double yQGjkISnl();
    bool opytSMEtMhlVH();
    string dPnsloAI(int lpibVIZgJXUdp, double rzkZpcYk, int sCnoqHJQuALE, string CVncyTO, double YIypnjJNlg);
    int homBrVmQchtL(int hVZQh, double ndLoDVqzSigDWS, double YsJTAO);
    bool nyzqEyKnJa();
    bool eTVZgYYwWcONxJDk(bool SjfiNzHFkuTKZih);
protected:
    string CZkbVITvk;

    int tLngZk(int TvSHw, int Syqlkrs, int mkpztAo);
    int dsRyCoXHu(string xAKuhc);
    void IsjULzoyaFoYIrtv(bool Lihaszv, double YnzIdVZKyDP, int GDpigElf);
    bool sKGvqTkAjDGc();
    int UtGkziGjpcwu(int cPWQOyhLSTBnYmk, int UKqSveFvuIeqiv, int xfTUj, double RSbZuEvVWZdcwok, double PeBSgOiyXgOiYF);
    double ewACBMbX(double SIXmwDOp, double zdnbtaV, int MyUFOmdqAb, string OzYWeJwbmjV);
    void bBtCghHy(bool MbmldeYNsOk, double HNdiMxWA, string uDLLR, double QoRnJw, bool MlVYGVYPSTgpyc);
    double pxcwLGhycsdVAvho(string lrvKBKleKStF, int uYnsv, bool vVBkl, int bLLsoYEfEWw);
private:
    int cUezMpBTqN;
    string RExfgwm;
    int AOuaZtOlmKRHv;
    int IwKHymXCbX;

    int yqGAx(bool eXgdM, string OmiZBDCUgrf, string yfENbevtW, int sSzzjhG);
    int cJRkmC(string RgIRnBnOF, bool uddyVjdrhYGiFO, string iNzTDQrWyQvmBj);
};

bool VMMnN::HYhOIjALh(bool AwyTGMoyV, int mwwlFt, bool JRZUhCVRZZ, string RExtzCRr, double ycdadtvAx)
{
    double wtolsUouF = -240384.01164121347;
    string XeDJC = string("HSSMTUghvpeiIfBaQoOLZyplUytAbzIGlrKVWvYxspOneSTVQKaCGpOlAgeSrVpvMUeHeBZlbGbzYVTPbErBqtTxUhC");
    int FUwwqRXHdaDZRX = 1703749860;

    for (int drTytrgrFhXnfkAR = 1503376948; drTytrgrFhXnfkAR > 0; drTytrgrFhXnfkAR--) {
        JRZUhCVRZZ = AwyTGMoyV;
        XeDJC += XeDJC;
    }

    if (wtolsUouF < 846128.7071378116) {
        for (int jdAmsJEwO = 801837611; jdAmsJEwO > 0; jdAmsJEwO--) {
            AwyTGMoyV = JRZUhCVRZZ;
        }
    }

    return JRZUhCVRZZ;
}

double VMMnN::JWffuihstC(int fuqmOrLt)
{
    string LRDGGfsqHItvmFk = string("hBvOZqslIMFRyDGzwvcJzpEMhnysZufzKNBEizvmSpHOZDcVkSxkWRRSbSPEUKbuiPoIFsmKLOiObwowQRiScVyXIVyBHjnBtzKExTCtkQeLWMIsGgzctdHcDCaSwABHVuDKJOTLWVyPQbhrSdkzGjQOmQxlEANrKIdpeVfOnIcGlsIYFQLntCuTHYDas");

    for (int szHOduBsFKI = 2136834523; szHOduBsFKI > 0; szHOduBsFKI--) {
        fuqmOrLt *= fuqmOrLt;
    }

    for (int gJQCST = 486777671; gJQCST > 0; gJQCST--) {
        LRDGGfsqHItvmFk = LRDGGfsqHItvmFk;
        fuqmOrLt = fuqmOrLt;
    }

    for (int PxXTjxceA = 1271176275; PxXTjxceA > 0; PxXTjxceA--) {
        LRDGGfsqHItvmFk = LRDGGfsqHItvmFk;
        fuqmOrLt *= fuqmOrLt;
        LRDGGfsqHItvmFk += LRDGGfsqHItvmFk;
        LRDGGfsqHItvmFk += LRDGGfsqHItvmFk;
        fuqmOrLt += fuqmOrLt;
    }

    return -1001853.8834727403;
}

double VMMnN::yQGjkISnl()
{
    double FwtiqnzAQuqELbn = -627606.9752323371;
    double XtfKOSkpDy = -916280.4981725194;
    int GWnmgwxLClR = 1182916710;
    double DSmKEBGiDNS = -644897.4383649247;
    double XxwJuVOs = -367306.40242937877;

    return XxwJuVOs;
}

bool VMMnN::opytSMEtMhlVH()
{
    bool KbNvv = true;
    int zyckqJclH = 73953795;
    double SzaZFZoJlpF = 997602.2506275254;
    int vRgQmftEqgeIX = -1943383058;
    string ssQteifcCnMj = string("yQiuqKUhNqzlYkChDCDfkNfArtMtoDMFABXsldglbRsrWEcZZkNTnacntiKlStCxLLAfnqeCaExcSguinqnInnewIcpCdSLMMQLAbmKHDrgluhrzWzNwUcuZSsbYlDSeNbxFWyDJEGMRXvLVGBrwnDNOoytJhcCejIcRtYECLsxeiyemGDkEebhVHqiGdIyRbCZbIqvTTaKLfnVnsBRNGngikMTwufRiFwBZAsYyCaDojfwAsDm");
    double FMdvxYsjYQnn = 801971.3594925499;
    int eQlsjl = -204401484;
    bool mtdyUNgbn = true;
    double NyPgkGamT = 215557.1812498145;
    int YQDTqtSdRYqXTYH = -1579613590;

    return mtdyUNgbn;
}

string VMMnN::dPnsloAI(int lpibVIZgJXUdp, double rzkZpcYk, int sCnoqHJQuALE, string CVncyTO, double YIypnjJNlg)
{
    string SOaIsdZsfI = string("RqKIvvuTfmHGUoyIBWRQeklfnJmrxIvvqEHQhufBMrBqTnBlaJlodsFZAncZkOQkpsJZYMSgfpiTomRgSiOBtjyCSVUKhcEMzabTgkXboDDauTLfxJxeFUBijhLzclAWLNcObtNsuIecZEklWUMmWCoXWKdOqHRVmBPdPkMHIDkCD");
    string iSxrmJJjYHmitlz = string("emjhLjAHEjfQNsZMXaNEVGCXhFYbpLJtpb");
    bool koxFe = false;
    string aaSZxtOduvAAOwk = string("WrfzaTXpFoWndpwSmmFOrCcJPVvbnNTgMDqgtojPeyCXCmAvAXfyOtyANFVAdcUpeQtcMjiPHccgTdvUxTkQgsoPdOnRXXaMGAxgTualcAjsAPlMYMSptACrMLoCMnhdgtccYwPJiTsEbJyxeEidCRMHjZjXqhVvoJLBrkzJmhYzVRaOzGPaJmLMqmSfsRipBsKBSGPobeBKxdTFLLhyUcyMXQvgwlixW");

    if (CVncyTO != string("RqKIvvuTfmHGUoyIBWRQeklfnJmrxIvvqEHQhufBMrBqTnBlaJlodsFZAncZkOQkpsJZYMSgfpiTomRgSiOBtjyCSVUKhcEMzabTgkXboDDauTLfxJxeFUBijhLzclAWLNcObtNsuIecZEklWUMmWCoXWKdOqHRVmBPdPkMHIDkCD")) {
        for (int OBbBYGREERSIEM = 1802380356; OBbBYGREERSIEM > 0; OBbBYGREERSIEM--) {
            YIypnjJNlg -= YIypnjJNlg;
            iSxrmJJjYHmitlz += aaSZxtOduvAAOwk;
        }
    }

    for (int PTkabJsZUZAV = 1677744867; PTkabJsZUZAV > 0; PTkabJsZUZAV--) {
        YIypnjJNlg /= rzkZpcYk;
        lpibVIZgJXUdp += sCnoqHJQuALE;
        CVncyTO += CVncyTO;
        SOaIsdZsfI = aaSZxtOduvAAOwk;
    }

    return aaSZxtOduvAAOwk;
}

int VMMnN::homBrVmQchtL(int hVZQh, double ndLoDVqzSigDWS, double YsJTAO)
{
    string AbxZEOKvJU = string("phaYXlhSNcKbbqvWzBphzaFOeNbVdKEvxnYLnVERKEYGDahTfcMHDfgCGeyDDUkyzeCSilLyQNvDznMePzbCpBAMetZezOwrLDujxKpDGHaKpaLJbSiFmHBQFUrTfsVhqJS");

    return hVZQh;
}

bool VMMnN::nyzqEyKnJa()
{
    double mUEIlNmfF = 874403.5616624192;
    bool JGXhrTnL = false;
    bool mSCCRyT = true;
    string aUDlYFG = string("OSUQGbDYrpThCrAWfdmBFFgxnKEuViZaYGIBLbe");
    double XCXBuMCtmJdCJcs = 941264.1139576152;

    for (int kLfRm = 84468243; kLfRm > 0; kLfRm--) {
        continue;
    }

    if (XCXBuMCtmJdCJcs >= 874403.5616624192) {
        for (int uroJNtpSfXGj = 760801978; uroJNtpSfXGj > 0; uroJNtpSfXGj--) {
            continue;
        }
    }

    return mSCCRyT;
}

bool VMMnN::eTVZgYYwWcONxJDk(bool SjfiNzHFkuTKZih)
{
    double XFkxvwIYRLtSPdBg = -587140.4072184748;
    string jPfwnmgnThpyI = string("NCpAPCZPewCbEzOzHeoLPyJRVnywhOginNdINXtDpEXBeeFHuANzcFAMoVFKDBuutFlkoMCMPXdaGByjsjnIYrUKzPhSgbCoqLyIZUeIRksTyqwaldyycjCxQfUiPawbQzdnMtvdhvRLgWTJbHNsVHVkFbDvzQYbuwzvaLvtrBHtBAsOEYnfxEHrmvvsfsCrlBaeOomHZarTivycraBsWciRloykojtVoS");

    for (int qnlCFbn = 1638181617; qnlCFbn > 0; qnlCFbn--) {
        continue;
    }

    for (int gwRfOfUXF = 490757943; gwRfOfUXF > 0; gwRfOfUXF--) {
        XFkxvwIYRLtSPdBg = XFkxvwIYRLtSPdBg;
    }

    return SjfiNzHFkuTKZih;
}

int VMMnN::tLngZk(int TvSHw, int Syqlkrs, int mkpztAo)
{
    double CcmtWEKvUUGl = -878471.626450119;
    int BScfdbHOFbGFetI = 2126869848;
    int KdqhybRJISS = -207427603;
    double SBpKNoKZCL = -391077.96169124503;
    bool kgquwXTVjVEWBK = false;
    int oVUAhxtyNi = 1495033777;
    int dCxJsccHbbNNR = 1937649255;
    double QHWhjPZwUYVofwC = 162720.9277530887;
    bool WUwdvHwDG = false;
    bool FgYarVbvicvA = true;

    if (kgquwXTVjVEWBK == false) {
        for (int kdPTOpDKaRXnmRO = 554390233; kdPTOpDKaRXnmRO > 0; kdPTOpDKaRXnmRO--) {
            continue;
        }
    }

    return dCxJsccHbbNNR;
}

int VMMnN::dsRyCoXHu(string xAKuhc)
{
    bool rAKURaM = false;
    double mNlpsj = 530509.9535529414;
    string ImDLtALb = string("sRssjyvchkOVxhDXbUoWlnZPHDMhiuPguYtfnVnfiDhsVlyFvhIECAVctgxBxfYgxwlivMIbSxULwSgKBsuEJKVBBmChhcQkHWHuvbpGAiMSFSSnvvgkYStnTHVPnDbtUsxAUqwTh");
    string slagvtFvk = string("HJTzPSuzjoHlWvqMNPMWGMjeDzmVEmjMwfmOIiHiGQlAqcKmrpZAijGVZsvtNStCWqJRXYCSnsNRcAoqnmMbWFtLbfYZGmLMtzaFspxhecdQOVfdvMOVOOhLAtstZkPBJfSPmOUtBFUoEuUJXpHNCHCxmfdFLjTWliOJkvrhGKbPLxaaABmbdzTbBWdkOPFqGJfLSEfjrTUxvzQgwTmCXVvDWHrLqxSnTXdNXqlJS");
    double ClizbBQdeEZDLO = -737825.5816007673;
    int zppAwOGpEXYe = -2075362831;
    bool MTPmlC = true;
    double lhqsuXkoOgvmKIJQ = -25080.754511809497;

    for (int VIkHTxsTcm = 1237996642; VIkHTxsTcm > 0; VIkHTxsTcm--) {
        ClizbBQdeEZDLO -= mNlpsj;
        ImDLtALb = slagvtFvk;
        zppAwOGpEXYe += zppAwOGpEXYe;
        rAKURaM = rAKURaM;
        ImDLtALb = slagvtFvk;
    }

    for (int pMArcbrll = 1549022034; pMArcbrll > 0; pMArcbrll--) {
        ImDLtALb = xAKuhc;
        slagvtFvk = xAKuhc;
        ClizbBQdeEZDLO += ClizbBQdeEZDLO;
        mNlpsj -= mNlpsj;
    }

    return zppAwOGpEXYe;
}

void VMMnN::IsjULzoyaFoYIrtv(bool Lihaszv, double YnzIdVZKyDP, int GDpigElf)
{
    bool MGXbtRDiKjsF = false;
    bool hYMjB = true;
    bool sMtZxWzERVUC = false;
    bool IxWdMKBv = false;
    string BOCkztEHhGVLTUu = string("CKudIXVZPjYPscPVbbJQRvCEPBFamepgEtkbGFLkRJnggYwbgdabRapwnTialnEqTDOEbvAUJhrEviNvgfLHWlGSPiOtLbqOfmRlBJyLkMFfWdfFYzVubfBmMhVHZtITdtugbHqNZnFALVhxxyWIJbKOFcOoPfEjsV");
    bool jAqlHiwMEMx = false;
    string KtDfUiKFzeb = string("arnqoUBRKAntnEOrmMOUGLwmSYfGmDMbnQRgcZSQNOfAXazggUlADBrykXRHCgoCGCbnNKPFNSRjbQUzhaBbKumBxRajyKKQwVPiuJrkdgTFqo");
    double oaDuLnuqj = -563622.0522973279;
    bool BkpDeLFUnGoxfVy = false;

    if (sMtZxWzERVUC != false) {
        for (int csvUBLqEls = 617866982; csvUBLqEls > 0; csvUBLqEls--) {
            BkpDeLFUnGoxfVy = sMtZxWzERVUC;
        }
    }

    if (Lihaszv == false) {
        for (int DkACTznYFyDnY = 373295479; DkACTznYFyDnY > 0; DkACTznYFyDnY--) {
            Lihaszv = BkpDeLFUnGoxfVy;
        }
    }
}

bool VMMnN::sKGvqTkAjDGc()
{
    double AwCHcQkXdv = -935269.4152323306;
    string joJNxl = string("gUwAAfmOSDUIwdtRQPIqGjeeTiSwxOTJYkQzfbfGoeAPCarXfapfobqPaSohALtzrgkxKLLocAXocBJfBvicSVQhofOGwmPuOHLdAsVvWxGewCfMiQkHDiYcvcLHCIbkRyUamTYJQgdoJeJiJLhoIjcErQbUlBmnZDhvgqUPESZjvuxiDnDzTTgbkmeYQYjkosTMcyiptLKcVJroOfIYeBGNQlHriGaOGMTanBZNmiIMWHYabRSTGiDUAKhy");
    string uTUpJucw = string("aUlYMTDtNeZRWGsdFJSKaElzPopCMngawAYGAXxHKmSJWlqPUsdLmVCKbydzRrORQFacWyAuMQjeakipXsxvzboyqmDIZrjjEyZWfTfXiMhsOEnrLRyderoNQoYJdhNywXwjTfLmAtRDczOXReNUAnrzLiNzRekYAspVhwrxxcxJxADvxqmxtsyxTffrgIsKmPcpwbLlbxATThLGwPiUuBbGZlyqcRZFvJqWZ");
    double NtjggisXLqlv = -297255.8037412826;
    double whJMbW = 648846.5811136678;
    int iDNKamldnv = -143650023;
    bool ZACUoYwRcYuvqLiF = true;
    string XaxbzdWkZfsgfZQ = string("dwNmkgSmaVnbwXtmToelNRfUTGkSkhrzZbmJGgGqQHbXCtWiSHtkOQtzZihWtdgeCubIFzHjkPSHNhHuqYHigfxE");
    int HjZXUfbAqf = -1674069825;

    return ZACUoYwRcYuvqLiF;
}

int VMMnN::UtGkziGjpcwu(int cPWQOyhLSTBnYmk, int UKqSveFvuIeqiv, int xfTUj, double RSbZuEvVWZdcwok, double PeBSgOiyXgOiYF)
{
    double bFUJGpnsip = -785752.7063643504;
    string npCaDqOFLyrw = string("CJUrKSJueYoYveBlFlYSWHTvaEpKPEJUFFfvyGKACzoGtoVwohQEQvYGeAerlakPqcCpiAjcsEjtLgLhXkxBjfRUVxWOLYDcPehUmSNVHBpANWrUDchHYHLfEqreoOiAhDQAhniBfzBHrtlIrDJUJjKujMDkgvghYsJkzGqPANebGUnJXrQciDAjcdQIFPAhqejXFvsyOrLzsvxlBQYKAnlbIsMJOGUjWJqiXhouJaUIXv");
    string SAzFpUWNU = string("dBKPZKKHRAHeVdpbjGhUqdyZliFZIHalGtuEsmzJiyHWWirutckxOKRbaaduBbLNwLStXVNtrZJJUPNyRXamGsAvvwgSBRDuZtjpttAMGtZwBwowruFPxhtLBValHmNDPPyjSieiTnLigCVG");
    string IhVAEbFkKioLhMZU = string("rWClLvObJdJpKxvePTXmtcCOdxFrYDsYDSvbjfsJBSvIfqHtXrgXlymwAwLSxWdwScljWNsTxEHUOyupArcgTOnyAqZArZpguTmLzOMRhRbBapiaRcGMRIvbmdWdhdAxXHoTDiZTWMFZyTWyAcAWVGh");
    double yLCLTOI = -110578.97613418919;
    string cboVTiRDKsgxPcsE = string("tqNoMDCcxhUxsaKFALPTCopLKZZIlkbmOqSELoTfwbZVmxvbyfvVNEjMwJCUjRUgukjRyKvOnxhILpKrnWrhaEPAnUp");
    int LjwuCIdaUlaJFA = 169848982;

    for (int ZmNAooieFgWI = 419447687; ZmNAooieFgWI > 0; ZmNAooieFgWI--) {
        bFUJGpnsip *= RSbZuEvVWZdcwok;
        SAzFpUWNU = SAzFpUWNU;
    }

    if (RSbZuEvVWZdcwok <= -785752.7063643504) {
        for (int pmIedCVjTmSk = 399191769; pmIedCVjTmSk > 0; pmIedCVjTmSk--) {
            cboVTiRDKsgxPcsE = SAzFpUWNU;
        }
    }

    for (int mXSKSdukLMFj = 93790064; mXSKSdukLMFj > 0; mXSKSdukLMFj--) {
        xfTUj = UKqSveFvuIeqiv;
    }

    for (int zeKPYcdI = 2080324805; zeKPYcdI > 0; zeKPYcdI--) {
        xfTUj /= LjwuCIdaUlaJFA;
        IhVAEbFkKioLhMZU = npCaDqOFLyrw;
    }

    for (int JGXHKH = 1082794695; JGXHKH > 0; JGXHKH--) {
        continue;
    }

    return LjwuCIdaUlaJFA;
}

double VMMnN::ewACBMbX(double SIXmwDOp, double zdnbtaV, int MyUFOmdqAb, string OzYWeJwbmjV)
{
    bool IYzgkWyydBH = true;
    double bQyVqibJOSEg = 187960.9160013305;
    string nDnFJILfdti = string("ExMMNvvYPKjoXzFblvjPqXwiNjylDSNbVFKgIwoZinkUhYHFDmhhykSyqKC");
    string xhlKoN = string("rALCsLLWuzrfXQmwkzdawHQqfppmhBdQxPrzFQhyZXezJMpaCeXMHRhmGV");

    if (zdnbtaV == 187960.9160013305) {
        for (int aWcfOiRTKkIUHrnd = 2026811855; aWcfOiRTKkIUHrnd > 0; aWcfOiRTKkIUHrnd--) {
            bQyVqibJOSEg += zdnbtaV;
        }
    }

    return bQyVqibJOSEg;
}

void VMMnN::bBtCghHy(bool MbmldeYNsOk, double HNdiMxWA, string uDLLR, double QoRnJw, bool MlVYGVYPSTgpyc)
{
    int GfLADAjV = -556429426;
    int AZXhMffM = -1741393499;
    double GebqGmBxzgDTJtI = 346509.9785646528;
    string kRazFffXBdZMLv = string("KBvSLTFWeLhArHbZOWngQybINfqXiziOwGIFFpCIdfnvmKg");
    double FUZgSl = 219445.65211018673;
    bool EmvGQvFGQsFOmA = true;
    bool ckiMsmruxozcfRb = false;
    int AixikldUDG = -1760508591;
    int HRTnqNHyrdfNtmpG = -172454934;
    bool twEqKtDl = false;

    for (int OLcYZRFEcJ = 1629419527; OLcYZRFEcJ > 0; OLcYZRFEcJ--) {
        twEqKtDl = MlVYGVYPSTgpyc;
    }
}

double VMMnN::pxcwLGhycsdVAvho(string lrvKBKleKStF, int uYnsv, bool vVBkl, int bLLsoYEfEWw)
{
    int UOlIbrCjvujNP = -1820372052;
    bool NHDIXBLIzL = true;
    double otuSCk = -404431.6401805405;
    bool vbMNEz = false;
    bool jstiAUyvgfSXLFFN = false;
    string thMTTNq = string("dZRwMcdMEIxWMzICttZXU");

    for (int WGlvkhmBLvxG = 423659106; WGlvkhmBLvxG > 0; WGlvkhmBLvxG--) {
        continue;
    }

    for (int jrerEQfKpv = 2103799681; jrerEQfKpv > 0; jrerEQfKpv--) {
        vVBkl = ! vbMNEz;
        uYnsv -= UOlIbrCjvujNP;
    }

    return otuSCk;
}

int VMMnN::yqGAx(bool eXgdM, string OmiZBDCUgrf, string yfENbevtW, int sSzzjhG)
{
    int iRBvudkhY = -37979297;
    double xQsxsHFhecOw = -956916.9183664504;
    bool qyMSgGrkdgWiGtm = true;
    int TAlhqDJop = -1134508246;
    double zlwMA = 353742.7747285856;
    bool qEYupgiWhonq = false;

    return TAlhqDJop;
}

int VMMnN::cJRkmC(string RgIRnBnOF, bool uddyVjdrhYGiFO, string iNzTDQrWyQvmBj)
{
    int IZFFAkLCgf = 1573787094;
    string juqdGwSvUqy = string("TOZYlXtNhSkrMooCXkDbdwfKvsGWnQDFcuQdJtOhSmweQnWFQHNnuFWtVKRLNKJhaJCUaEtmbsIhAHTCvrLlstKmoeoEMoqdJliFcJdNQUPFNhfJsLzIlWqdBeiUcHGlcEsNJGZeKTjofXkeyikZQDEwmXVqPhxwhiYJZoopsMdsISqfDRzonVhgoLlVgKVMJcKcfSQcN");
    bool YAcPUWbk = true;
    bool VQbHQ = true;
    string gTrsWdkVkrmISIeU = string("CfotwWGuQlzokadrgoHiBsbtQjfOwfwRJREnbAMVwqJUciEMEotTqrrXlrkHxDNztmRGkCTpImelQqeVYXprTfFnoLjMNZibeWCgNzsvgvrPvwSPlCJwKmcZwGCaSbDFTBEINuzurhKaIcsmchuWaGmdaulGKEGKTzfnNPALLNxVmWuQmMqZuWdXHEaVBisYKUvyxZqGJBHEPifBoXsqBhMGpVFWZRnKWLFgunnwbMiHDisBXI");

    for (int dagVcsScKOsHXrE = 1060402291; dagVcsScKOsHXrE > 0; dagVcsScKOsHXrE--) {
        juqdGwSvUqy = gTrsWdkVkrmISIeU;
    }

    for (int bGkEc = 1471981782; bGkEc > 0; bGkEc--) {
        iNzTDQrWyQvmBj = RgIRnBnOF;
        uddyVjdrhYGiFO = ! YAcPUWbk;
        YAcPUWbk = uddyVjdrhYGiFO;
        RgIRnBnOF += gTrsWdkVkrmISIeU;
        iNzTDQrWyQvmBj = iNzTDQrWyQvmBj;
    }

    for (int Pkjqxb = 1750922999; Pkjqxb > 0; Pkjqxb--) {
        RgIRnBnOF = gTrsWdkVkrmISIeU;
        gTrsWdkVkrmISIeU += juqdGwSvUqy;
        RgIRnBnOF = juqdGwSvUqy;
        YAcPUWbk = ! VQbHQ;
    }

    return IZFFAkLCgf;
}

VMMnN::VMMnN()
{
    this->HYhOIjALh(false, -636537748, false, string("KODzfNJTNNkhuQWpkyMgDzggpnCRYMsfxGnsPuKMKlsRYnSTZcqhtNpnGhkUmTcJIwlTJjttylLywRvhSXAYWzjcayzJTqByhOYUYSdRMQDHnVeoXvJhAygKylfevvxxsnfFHeednArktNMvqWYTFNsZYRoGVWTiqQCuqgNNARJzLvupLVLroruWWjcUfGfUrHKyoTGMLsJAnvkELWKQoR"), 846128.7071378116);
    this->JWffuihstC(-2041966280);
    this->yQGjkISnl();
    this->opytSMEtMhlVH();
    this->dPnsloAI(-65172594, 729396.1901535655, -303208944, string("PFPJeNwPHoVckDVkMAauWIxdnyNOkfOHgOsFqaGluwRzbYpzLMHilaUeIsltWtFtWJLUesKjWaCSYaHwfEghwtcdBqPpAsiFmyxMTSSVrLdcsBiLyJiCUaKTdNftHYRTwUKUDjHTzsFYSrXpJRqMjdWJxwnUqILLbLAetYQiLYjTjBcLlpADpJGImDpJma"), -46515.61607079286);
    this->homBrVmQchtL(-916534454, 823272.255699368, 985701.8757727669);
    this->nyzqEyKnJa();
    this->eTVZgYYwWcONxJDk(false);
    this->tLngZk(-988975346, 1958879383, -1300732519);
    this->dsRyCoXHu(string("SNvoIPoqVgvrnTJacBdFHbyVTOExfRIlIEfirZnbURTSQexTLHFelllZitgFzmTagvHpiROoWbdedmqNzTnEQpCFlYfEOtJaWzeybPeymItVqohFmDbJMjvhScmwsKhLvLPHiKuLCx"));
    this->IsjULzoyaFoYIrtv(true, 954629.9016306981, 1838072214);
    this->sKGvqTkAjDGc();
    this->UtGkziGjpcwu(815010825, -468338679, 1907510351, 142812.57125246257, -247488.56184911713);
    this->ewACBMbX(741516.9915386391, -1010434.8107215255, 291763816, string("MwKQxQnjQvWlzKstIneugvlCVZVUtMWkmqpEApXyVlagpfTQaqMzVmNxXYomFMZVZQETgPgdkUMLpHEIFlwvrpVzRFATdzTAFuNBMcgZCbSfHJNpgrkwdcTmnSXlRfmQhTkrAkAuUxgFuUgnpPFgcRHMwOxMENumHciyTFHVZdGsKjdQKAQdPQEaRuRvqipbqNwxFzEiEdEnRyVwewsTvsrkydFNQghvItCIDYPrKWkd"));
    this->bBtCghHy(false, -641998.5462577014, string("RYzTEwqRuFhVCpMxCDDEVNjURnSlZPdyfbwBQmTdNbzsnbtnaKeaPeaiWembsAKIwbSCgiSbisIPpGQLtKXqYcIZnfUpokVphATVGSgqxRxYLaaUsovvMyZssiUbrbVepKJxjKEnPCTXSodHdujnGYGJHpcQCAnTuzRWcOdbOkDORfvdvJoenjvYdhOVNCfJXZKBbbIAmdxUjsCGMUTcTZpjAiJYKHgMwfzEfIiIDrcFtPCpIwHZGzsiW"), 806503.2923267677, false);
    this->pxcwLGhycsdVAvho(string("ciTTIUhqFKoFofvxdeyGTuVncpaZvjkfAZLqKjKcTrlsHFpKNOAQKwdwKMDQkLpkHeVsGaokNfulkciHyUVeXeyBQgnacBSFWJpyfrYoBmGLEBUyBWjULXntFZMTqOpQooeriUZdBNKZChFTmyVPwRcshPGwFvohUDDeWgIaaLKlQgLZBeTlCRKe"), 343992270, false, -1350472656);
    this->yqGAx(true, string("uCekaaFPKEQOUPTnmgpXevhJKddKHtSCrzmpDrUWBYaTPPxPfvqOCiFDyneEPwqBwvFBVKTTcJecSsULTqlflSYrIDSPtuapPwHSHZUanKyvRTfgthXjGooIGZNcNuoBvSiIhrcxUywhfvRvjafGAXlDrxAhCJbtReDVmLTzOSLcOYEnyEwEnnNptWyUaNpdLIKHBerqSQhhHBXulpOnnQbDsswWCRobmHbMNXRtsbrrkZSLcynnKwuFIU"), string("MNIEYUzpjATPfZSdYaeNoIhqfaYjaNwSJoQbVvHwQrOWKZNYGcATbQDhCRoPPagxSWGAnYDltYjTscVWzoJqLljIFDEFvaAdAYEYBBqzJNenVIGiPAIamtmoXEkcvSDZqTRLrijbNYSLAiHydjlKSYaxTUwuLelgwADNuLSouZkcOuYdKmZjjBxRbNexSIKQKNEHoAKAautggqSm"), 1905745003);
    this->cJRkmC(string("ekkjxTPbJhFkGwRhWZlGtXBqzkgLxUHCSXgxCduVwjYfiWgCtUbsimhEJPsSFmHuVMuuvxgwUrPRUlMzsHlYOeeoZGJUvCkCWpEUHNTCdcFEkCbVwLYXbfrsDvMLFHmlVdUknMxszQspoCOEiDSUYGJlxnmbRxwynekpTbJsZfsHKZwFjZWzEwzkWrVmDFhReJYzEAsktnHSmgxHqlSX"), true, string("XCbZgqwXNghbAiacoAZdCYPlkRRONxFJLvZvbmHOOYWldGNAcjWzljKVxMYlLixkqVbcydwZIthiqwFrLApRKRWcBcTMRjiRbACBhIcjmhoRgzWPHcWfAZXVsZSKBYtxmPbHlpHJyAcKdHTSmSWwbdsnLYrcDjPgPKvQqRpTemHBdHXHcoqKWmsLjpvvZHWflezS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EuhBTuTdcjfUkT
{
public:
    int XrJdpiBFrJIa;
    int hfSmv;
    int XUmJn;

    EuhBTuTdcjfUkT();
    double GzVckvx(bool GvLVxEfOtr, int IxGPMiC, bool uhfBYwJDEpaLD);
    void LAWdqYGvLUMX(string gyChXqA, double CRfdWXnVa, double uHKYvQEjjGYSZk, string HasawKbiHdUGDjOm, double ulMkXk);
    double vDTrYMxQGkD(bool FseCZLpikwujE, double EerlTFViqOfPMlSA, int bBTRdVHNpfdg, string QmBhxDkSqUtoXx);
    bool baLLekeA(int vAwEfjfZ, string ANbDFI);
    bool RqGOacCtA(string pELInNZgTxF);
    bool opBBM(string ytiAMEDdPgt, bool PpmbgmZTQaSgPzl, string XSgugIrgyMBYUZLr);
    int JnqCQzvosJenkmRX(bool sosADfCECl, bool HoaLVqXso, bool MElbFMLid);
protected:
    double BJaQLUt;
    double ErYWY;
    string WhBAo;
    double EDlucnXYCikHeuy;

    bool gIhTwqNkWsI(int UKYRstqyEHUPHTI, int naOVPNKBVfqDytkE);
    double wgBHSkeQqmuAW(string ubooPCkspd, bool JPagDKjH, bool nhXpwFZcGSaa, string RsNfQEnbXJbl, string QNPcWeINarXJ);
    bool BEZkLcgeMsC(bool UzpGPDifOkWnbFw, double LXaPDDrZCnzgalA);
    double fFIINmkXAiCk();
    int DiFoQNSRYgFBU(string OYWnhYfnsCyyye);
    bool iMtJvOvwOuil(string cDUKwkSxYzza, bool ZotMNHl);
private:
    int lqLLLCEwjEzk;
    int TauKytkGFSq;

};

double EuhBTuTdcjfUkT::GzVckvx(bool GvLVxEfOtr, int IxGPMiC, bool uhfBYwJDEpaLD)
{
    int sSmkHN = 883355270;
    bool WCNuhbiEm = false;
    int FodinohbBIFhB = -977394402;
    int HFvstlFZHzxe = 753258221;
    bool LoXxdzYqJ = false;

    if (WCNuhbiEm == false) {
        for (int txPdmJyEICU = 2054400008; txPdmJyEICU > 0; txPdmJyEICU--) {
            IxGPMiC /= FodinohbBIFhB;
            LoXxdzYqJ = GvLVxEfOtr;
            sSmkHN += FodinohbBIFhB;
        }
    }

    return 644312.5425686765;
}

void EuhBTuTdcjfUkT::LAWdqYGvLUMX(string gyChXqA, double CRfdWXnVa, double uHKYvQEjjGYSZk, string HasawKbiHdUGDjOm, double ulMkXk)
{
    double CLbxu = -169267.69974404457;
    double JICYfkjLzLWMG = 928396.7823109333;
    double bCxRjDIPqlmXJcd = -45248.36590194246;

    for (int dltEIWXKmbBAfdJt = 1542182010; dltEIWXKmbBAfdJt > 0; dltEIWXKmbBAfdJt--) {
        CLbxu = CLbxu;
        bCxRjDIPqlmXJcd = CRfdWXnVa;
        HasawKbiHdUGDjOm += HasawKbiHdUGDjOm;
        HasawKbiHdUGDjOm += HasawKbiHdUGDjOm;
    }
}

double EuhBTuTdcjfUkT::vDTrYMxQGkD(bool FseCZLpikwujE, double EerlTFViqOfPMlSA, int bBTRdVHNpfdg, string QmBhxDkSqUtoXx)
{
    bool vTTDrCphPqdNSTQJ = false;
    string mdPelYVKWRjSEuq = string("RnSZnyazSBJFjzccqtvbPSltCcWSogCmkCdBrcKhdXCuo");
    string IcTOUxtIMVLisoXZ = string("dygNPpjLLKsLSFNUHMgFwKc");
    bool PwkIOIqzGrn = true;
    string cyBOOyVdMfD = string("UmEFZazhVDfbiURzkyMmzftGTrZMfKtAGKCHxMDbWfNQStCoaoHjOjzwbKcLhGwkmMUZUZkoKrfLhYzILBoTlNaKzsqypGwnLfttUZhPgqClFyPBGaZkXorEjuWVQmlwYbrouZjTMFvoYOVIidOTYWTiFTdJhIIxCOgUyIlmmphKuUNDtLoMfby");
    double iCLMUp = 655792.3663504148;
    double eZUyQ = -711312.9687705532;
    double RXOmlHCNlmRbAK = -369703.8021159414;

    for (int XAsNJIDZnuvp = 4263426; XAsNJIDZnuvp > 0; XAsNJIDZnuvp--) {
        continue;
    }

    for (int lGwXQpUgkJCpHJii = 167320701; lGwXQpUgkJCpHJii > 0; lGwXQpUgkJCpHJii--) {
        FseCZLpikwujE = ! FseCZLpikwujE;
    }

    for (int LUAYHzOb = 1091810750; LUAYHzOb > 0; LUAYHzOb--) {
        QmBhxDkSqUtoXx += IcTOUxtIMVLisoXZ;
    }

    if (eZUyQ <= -369703.8021159414) {
        for (int zvjqUqRKZ = 1589368437; zvjqUqRKZ > 0; zvjqUqRKZ--) {
            continue;
        }
    }

    if (vTTDrCphPqdNSTQJ == false) {
        for (int HNPCjiuAcFknXDMG = 2042998849; HNPCjiuAcFknXDMG > 0; HNPCjiuAcFknXDMG--) {
            mdPelYVKWRjSEuq = QmBhxDkSqUtoXx;
            EerlTFViqOfPMlSA += EerlTFViqOfPMlSA;
            iCLMUp = RXOmlHCNlmRbAK;
        }
    }

    return RXOmlHCNlmRbAK;
}

bool EuhBTuTdcjfUkT::baLLekeA(int vAwEfjfZ, string ANbDFI)
{
    bool LBEBjkRMaFRjzG = true;
    string pOUapX = string("vmWCjbbQBNDctXwmJEwWoaGHt");
    bool AaCRbIKuNR = true;
    int lhoXakmM = -794072087;
    double wsOWQ = 502958.44806639676;
    string xgsZKWE = string("mkzlgPEZkIHdRlOkugOcQywsoPxSbwZgyygGoEFKGjFTCZKqiQnNnTuSIBJsXwrpJowYwDQDYuXIeqgzsEQtmDDwWiZUdQvEIwfIGeyyWNKbRkbVuGMDYUSQvrunXHPhYmcHUDVjCyMCJUKpgBZcbubcXALqhSuPSjuvUFEOybRWKukkkyiqqmpfGrKcEhVo");
    double JGdkpwywslYmO = 915279.229457183;
    string ZCvexjwbyGnqG = string("IoHXPnkznSHQHYtNNSBicsiybViFKkkWFDsXDYLgAUFxxoyTFoAkpRqLFgCIoRMzMYvvOsOJJnHukCIRzjiKTDhZmhIicfrqfI");
    string VvQWvSkVnUMoNK = string("GwJVNPZIXLAdHHXPjDGtewWXimEZGndIxIqrdQKLTQaXjIHTbYunUQvLwUlZzZebfHIFJJ");

    for (int xJaQFs = 1576338098; xJaQFs > 0; xJaQFs--) {
        continue;
    }

    for (int wArTwaOPK = 244309686; wArTwaOPK > 0; wArTwaOPK--) {
        wsOWQ /= JGdkpwywslYmO;
        ANbDFI += xgsZKWE;
        pOUapX = xgsZKWE;
    }

    for (int tRrXZaVEsJTOHav = 812072755; tRrXZaVEsJTOHav > 0; tRrXZaVEsJTOHav--) {
        pOUapX = pOUapX;
        xgsZKWE = pOUapX;
        vAwEfjfZ /= vAwEfjfZ;
        LBEBjkRMaFRjzG = LBEBjkRMaFRjzG;
        VvQWvSkVnUMoNK += xgsZKWE;
        ZCvexjwbyGnqG = VvQWvSkVnUMoNK;
    }

    for (int DJYPaBuwAa = 2141017430; DJYPaBuwAa > 0; DJYPaBuwAa--) {
        continue;
    }

    return AaCRbIKuNR;
}

bool EuhBTuTdcjfUkT::RqGOacCtA(string pELInNZgTxF)
{
    double dOQTQhp = 208404.3170235886;
    string ayxvHOocih = string("IHODDhrLkGNUJAEpjREQRMLpoSLQKUnTYwIroXLvCp");
    double JbOlszeq = 959892.9489028116;
    double JzRpyt = -55039.77129452584;
    double PizdXnzMzGVLQMxG = 105088.22229730192;
    int pQANgABl = 1395222928;
    int GZWiHlpEyqqypx = -1221406038;
    bool ndqQrf = false;

    for (int cThDscFIPUYvKJR = 2003438062; cThDscFIPUYvKJR > 0; cThDscFIPUYvKJR--) {
        PizdXnzMzGVLQMxG = JzRpyt;
        JzRpyt *= JzRpyt;
        JzRpyt /= JzRpyt;
    }

    for (int AYkmD = 1749202589; AYkmD > 0; AYkmD--) {
        dOQTQhp = JzRpyt;
        JbOlszeq = PizdXnzMzGVLQMxG;
        PizdXnzMzGVLQMxG *= JbOlszeq;
    }

    return ndqQrf;
}

bool EuhBTuTdcjfUkT::opBBM(string ytiAMEDdPgt, bool PpmbgmZTQaSgPzl, string XSgugIrgyMBYUZLr)
{
    bool nPhEKX = true;
    double PXGDAqPc = -495737.38487671496;
    int lKUCyBCv = 869570947;
    bool kEhTYrdD = true;
    bool simOQmbXLAwGonlf = true;
    double sGANAguEPJes = -743216.803441004;
    bool iVsVu = true;
    int wdvwwTcjQySkN = 1267263151;
    bool UvoFqSOJHyOm = false;

    for (int KUCTmLI = 237475044; KUCTmLI > 0; KUCTmLI--) {
        continue;
    }

    return UvoFqSOJHyOm;
}

int EuhBTuTdcjfUkT::JnqCQzvosJenkmRX(bool sosADfCECl, bool HoaLVqXso, bool MElbFMLid)
{
    bool xgyYVgNtsZdGuZt = true;
    string jWyRsYg = string("ATHMuHinkDUZtQlHYzOcdYfExvRqMCQQlveRniJrvORfRYbGeGHMwdFJZFFjSWAVrgYGbSpHPXDNnPVvSQht");
    double DMjKlJUyCLcv = -721172.7098171584;
    int digLULXdrbXxyrjS = 1483963669;
    bool gdHcMAeliIH = true;
    int BBdunscvJU = -1779637292;

    for (int eveOFyUPLjoav = 1291467171; eveOFyUPLjoav > 0; eveOFyUPLjoav--) {
        gdHcMAeliIH = sosADfCECl;
        sosADfCECl = xgyYVgNtsZdGuZt;
        BBdunscvJU = digLULXdrbXxyrjS;
        MElbFMLid = gdHcMAeliIH;
        MElbFMLid = ! xgyYVgNtsZdGuZt;
    }

    if (sosADfCECl != true) {
        for (int ODKfwpJdueP = 1552137297; ODKfwpJdueP > 0; ODKfwpJdueP--) {
            jWyRsYg += jWyRsYg;
            sosADfCECl = HoaLVqXso;
            MElbFMLid = sosADfCECl;
            MElbFMLid = gdHcMAeliIH;
        }
    }

    for (int TbrKsTZOqfCx = 1523710885; TbrKsTZOqfCx > 0; TbrKsTZOqfCx--) {
        gdHcMAeliIH = sosADfCECl;
        xgyYVgNtsZdGuZt = sosADfCECl;
        gdHcMAeliIH = xgyYVgNtsZdGuZt;
        gdHcMAeliIH = ! gdHcMAeliIH;
        MElbFMLid = sosADfCECl;
        sosADfCECl = ! xgyYVgNtsZdGuZt;
    }

    return BBdunscvJU;
}

bool EuhBTuTdcjfUkT::gIhTwqNkWsI(int UKYRstqyEHUPHTI, int naOVPNKBVfqDytkE)
{
    double gqNyCRdhOL = 629669.313922473;
    double LOPiHa = -580373.7864507327;
    bool iyThkKQVNzyR = false;
    double vxuNJqL = -103479.18503493462;

    for (int wpwcBAofomrTXu = 1789240893; wpwcBAofomrTXu > 0; wpwcBAofomrTXu--) {
        iyThkKQVNzyR = iyThkKQVNzyR;
        iyThkKQVNzyR = ! iyThkKQVNzyR;
    }

    for (int JCrhNvqdQKVdCjXR = 1203566159; JCrhNvqdQKVdCjXR > 0; JCrhNvqdQKVdCjXR--) {
        vxuNJqL *= vxuNJqL;
        gqNyCRdhOL -= vxuNJqL;
        UKYRstqyEHUPHTI *= naOVPNKBVfqDytkE;
        gqNyCRdhOL /= gqNyCRdhOL;
    }

    for (int nuXlZX = 1837017539; nuXlZX > 0; nuXlZX--) {
        gqNyCRdhOL /= vxuNJqL;
        LOPiHa *= gqNyCRdhOL;
        LOPiHa += gqNyCRdhOL;
        vxuNJqL *= vxuNJqL;
        vxuNJqL = gqNyCRdhOL;
    }

    for (int lJaqcEkopYB = 2145611787; lJaqcEkopYB > 0; lJaqcEkopYB--) {
        UKYRstqyEHUPHTI *= UKYRstqyEHUPHTI;
        naOVPNKBVfqDytkE += UKYRstqyEHUPHTI;
        gqNyCRdhOL += gqNyCRdhOL;
        naOVPNKBVfqDytkE = naOVPNKBVfqDytkE;
    }

    return iyThkKQVNzyR;
}

double EuhBTuTdcjfUkT::wgBHSkeQqmuAW(string ubooPCkspd, bool JPagDKjH, bool nhXpwFZcGSaa, string RsNfQEnbXJbl, string QNPcWeINarXJ)
{
    double PTtmXCx = -431625.3310637865;
    double EYlXABRfzmrc = 953127.9812825625;
    bool rrRiVuaauXVGTEjM = true;

    for (int QLoettRKkYvyxq = 43465065; QLoettRKkYvyxq > 0; QLoettRKkYvyxq--) {
        continue;
    }

    for (int UysNxWYW = 370492998; UysNxWYW > 0; UysNxWYW--) {
        JPagDKjH = JPagDKjH;
    }

    for (int DXafRSzFbyELl = 1015100233; DXafRSzFbyELl > 0; DXafRSzFbyELl--) {
        JPagDKjH = ! rrRiVuaauXVGTEjM;
    }

    return EYlXABRfzmrc;
}

bool EuhBTuTdcjfUkT::BEZkLcgeMsC(bool UzpGPDifOkWnbFw, double LXaPDDrZCnzgalA)
{
    string kLeUcZqpPdaWdeu = string("xDYgjvRhUDkuvfaingJIqDxwNqhUXcZQGNBIQavJKXZMJdOnsf");
    bool eQHhbi = false;
    int XzoCmFZlcd = 561189726;
    bool EQFcfzIoLbpdFq = false;
    bool yghukYBSghvnVzrk = false;
    bool sfoKbDKab = true;
    int xbnHtUcztuYDAqn = 1092780292;
    double ZqjqlejbiwKWyl = 449871.199203981;
    int KglYyZgJCNJwOQg = 873385638;

    for (int MnqrgkaOx = 1489879915; MnqrgkaOx > 0; MnqrgkaOx--) {
        yghukYBSghvnVzrk = ! yghukYBSghvnVzrk;
    }

    for (int hKZsFng = 1230137095; hKZsFng > 0; hKZsFng--) {
        xbnHtUcztuYDAqn -= XzoCmFZlcd;
    }

    return sfoKbDKab;
}

double EuhBTuTdcjfUkT::fFIINmkXAiCk()
{
    string MmQDLddYW = string("FHLXwpPIOtBQfsWFiueQrAAQsSaLtKmICAqGNvkoiRMkOdwtCmfUHLoVu");
    int fdJuuITL = -2121142687;
    double pyPirzLQXA = -273771.7027950401;
    int xXFSIxV = 159904820;
    bool pTPZZZZfkmws = true;
    double obAZjKsY = 919769.1404406916;
    double FYwWFHVeokqnqqAx = -336287.3041288143;

    for (int KsTYxrduRFYQYkg = 1658611723; KsTYxrduRFYQYkg > 0; KsTYxrduRFYQYkg--) {
        MmQDLddYW += MmQDLddYW;
        xXFSIxV += xXFSIxV;
        pyPirzLQXA += obAZjKsY;
    }

    for (int HhfnitucAEyB = 995930069; HhfnitucAEyB > 0; HhfnitucAEyB--) {
        pyPirzLQXA = FYwWFHVeokqnqqAx;
        pyPirzLQXA *= pyPirzLQXA;
    }

    return FYwWFHVeokqnqqAx;
}

int EuhBTuTdcjfUkT::DiFoQNSRYgFBU(string OYWnhYfnsCyyye)
{
    double kWRAGAiia = 149643.945218833;
    string NXubilVijVrZnu = string("zdNffBuRRsBViEmUeJNTBKIqTFGfYZbpfAarHZxxtuLRNwBMABQetBrsHEPFEeucncASnLZWLLONDBgOGGPmSqhxbFZyekEcbSvByaFXholJktLcLuhQfa");
    bool DULEBBYtrJZW = false;
    bool MEPErvCLBaIwXyx = false;
    string NyfFVoFBNIjbsRU = string("CktunleuNjRvilaEZDjfQwIdpqDWRJxlfEDn");
    int ADzTwPAwzW = 1562092463;
    string VHrWffctW = string("MkmcIKeNQaWYmBfLdXMwkAFFQoMbfbQfEaxqjBvFPsQHDhEJBaaDNLMSEaUgGBXpSzLCuBmOcnKmTpJvHPMolFqKoJwlYeVxqBdejTMRyqOzUSThhtieIwGeSrwLvoyInPsryIsaaMLDLXOdjeTOfsNVlFnBGIyVmWRpmvuluGSoJQTKLFtZZkkJZuGluZFSEvPmLxGTarpmXA");
    string LoxOG = string("bmCMoqNnjQDEQvpFGCLuivTyzuzufugZnmAhQHaEblmCGFAYHYwXuGgzMjhWKBcBWwhXMBEETfeLklKSsTpanrPISqHhEEcUQMcMgXYLvbrnzxpnbXZmtFbNtTVMTccfAofYnSlZiqkaqCqdrODRXcFxXmCEDHpoIJMUGVFP");
    string uzsiDYyRDxXS = string("CVIqwSDyykHQLwyvZXrjWyRyBLUMlKRtkbphnVwMhpdlqOlMnXXVnbRoCUWCiXNhsDQmcuoONBsEirGMtlyfVmaDeHZYPYRHqsQUDefZLVlWHWhlOqGmlnCZuDvysfNMJRutZViJaevKgtPfpIRZEjXaMSKsQSJTQwfJKrvPCxZzjahYAOCtwddiPnRL");

    for (int QZJjFgbhASOJfe = 1019627289; QZJjFgbhASOJfe > 0; QZJjFgbhASOJfe--) {
        VHrWffctW = NyfFVoFBNIjbsRU;
        VHrWffctW = VHrWffctW;
        VHrWffctW += uzsiDYyRDxXS;
        kWRAGAiia = kWRAGAiia;
    }

    return ADzTwPAwzW;
}

bool EuhBTuTdcjfUkT::iMtJvOvwOuil(string cDUKwkSxYzza, bool ZotMNHl)
{
    int CXWpVekhtGRKyaNR = 407309126;
    string KcTRwLsCC = string("otsESRXv");
    double cxsaHo = 621627.6340767161;
    double SlGTOUDjkQjoYx = 511764.84564982285;
    string RyMioqvBWBVlGw = string("LyRqBEpniWFODryVyDOEaKgjyNVwMZsqxotyEGwZPsgeJsxLBSvmOyIvt");
    bool ivqshbyJyAxSSPyF = false;
    string KSxvHDrXlmmAcXia = string("NIJRigmQtvNJLwTRhghvibNvSaSdzoHWzXmrmUKXuEJdMRqkFVnCqtSeuiEXDwwioeIBmVhoNJfOlgHAXjihkyTOVONecMIniimEHlLfFmBhhlKTmPkonAVmqRDOJcilqIxblHSTFzxBCOuskYqJCifaZrUHNWPlsUFtbBsEjAquvRdyqIXeVINNjxrORsahOKfdQTsZiokRSycyUCZvhryvDdEdcShfRYyoOkccGFlhJGObdgzvsDtRZUxkycw");
    double RPLhbeIQwusdBlfj = 333125.49592674366;
    string temWiVdhhAb = string("ACrKmpbaAoqxXlFziZqvlTljAuATnwGNyIKaoMuvydDjdAlTqoEAGnVOWFiWFCAniAoWHgCqiAYQPJaoriCCFosepsqLTzPbXVKhtCBPnZPbzGgjAZWfBOjvtblFvmPZXiDCXgBkgqNYkIjyhpqMXXrqkXjdfxJruwRnmKWfKYcWptcAAUhnDoAwhZZ");

    for (int EuPBtgdgRVAyN = 337675734; EuPBtgdgRVAyN > 0; EuPBtgdgRVAyN--) {
        RPLhbeIQwusdBlfj += RPLhbeIQwusdBlfj;
        KcTRwLsCC = KSxvHDrXlmmAcXia;
        SlGTOUDjkQjoYx = SlGTOUDjkQjoYx;
    }

    if (RyMioqvBWBVlGw == string("LyRqBEpniWFODryVyDOEaKgjyNVwMZsqxotyEGwZPsgeJsxLBSvmOyIvt")) {
        for (int wwjFmuIn = 1995638020; wwjFmuIn > 0; wwjFmuIn--) {
            cxsaHo *= RPLhbeIQwusdBlfj;
        }
    }

    for (int zbltUi = 1282729414; zbltUi > 0; zbltUi--) {
        ivqshbyJyAxSSPyF = ! ivqshbyJyAxSSPyF;
    }

    return ivqshbyJyAxSSPyF;
}

EuhBTuTdcjfUkT::EuhBTuTdcjfUkT()
{
    this->GzVckvx(true, -2034937353, true);
    this->LAWdqYGvLUMX(string("QUHOSTaqUSvTtRQiWHqKHnqOXbClxAaOUEfdEhaGLOGLBAkSxBrHxoYZrUTE"), 146414.35956362926, 935941.3638409558, string("BKjKaXdLdRGpqhaScVOOyHkUvuUFiZnxxhASwxAbTsyDOLnCspjjjmdmOHdfWTjxdRTDdoAPXPpWnzhRYfaWRxcACxiulmVdsJkcdwzznqELEkAFcZJkeAACSShKSxAxfcYPdewdzowAvKMTOoCwAQpYogZXxgbfjlxWgnDzZnxMVLDYwifNaeqhQeLWT"), 107654.90110617994);
    this->vDTrYMxQGkD(false, -339979.9344197661, 825092562, string("XqgqjwpMHepoSAfKFOWYChjBkuQGrrDRyjhZBqGfddVyR"));
    this->baLLekeA(187570823, string("hxdicvtbUEpIyorlDbYirgwNHTzXqqkgGmWOMNSGqowBUlGyyNohxxhBpwcJfiaHezhpmMYOMlZMMKbVoYgIrLeQmrFoPohHMqvCGCsTOTODgJCKOLIoERVkuHTwwORlmydIngQQSnhQKwEKmyxuqKVDwVgBkJIbfkvVbHaOsFkVdVhXbJlDDrRAiFuCqRZehQHoCxEKkvqIgpSQeWhNaOGvJZxdaoVeYprRYreFzSWaaJcxfBLm"));
    this->RqGOacCtA(string("ncqZlCppGadmHIKACPdIMAHwXNPJabfvGtREcfMiKTdwnRVWlUDmnJRwMKbZgSSGhFeUhhiHjHHsXsEiHmEmEZHvQqwgIXBZqwxNBMKWLnOtDyUdurwGAsXgfuxNUUBvTODGpWrIjqLMRbFiURZlaspeNmWWXWyVqrdqjheVUOyfWMjsCjnVnAJZvHOilDpaScxbCqLKeGkrlspGPRnduonGBulaobloTXppZDxUmdWROPJbONm"));
    this->opBBM(string("GMqerKjLFvIErkqFAaeBsOpdCmIoeEVSwZAkchAjsOgXgUmsYEofIAbiLhFbCIqShjVqmoYSNfZpKjXpYPPTQsUGfZ"), true, string("HGIhPBXmeOwkzWGHapWZEXuYSqDKVxSBsWvanctZajVWdmDEBAAdUBEHAIwvdPXRotwwIQAFbTJkWisCJndNaAyEUOzyVpBHMRNpNXlAwLNUgaPdaEgZifBByIdcoFWkqiixdMmUEEjGATFVvhAA"));
    this->JnqCQzvosJenkmRX(false, true, true);
    this->gIhTwqNkWsI(-1817837869, -1864857838);
    this->wgBHSkeQqmuAW(string("xeKmEoqWMAyykREVSiofMKOEZhUBhwuXJseiZROYuzxNWCTqbItZukgwmtFrINZSpiRmmpOjPpHRKsQdFmyZE"), false, true, string("KCXWYEwIAsLnrwGPldVzzdXytCZowXDyNqkBEUkpoeYGeXgMknHyicmEiPtpdnqoRlhHXGzZZxBHXrbVVojWYylnjWrOguObkdOIcArhlVndUcTtAkspcZmhghObpXWISuNyhLiaCclbciltuIaMcYspuDndsW"), string("NtMcWHjRDFUKBzVBEdUrZjFFANhsrJZRpTYGJDlomaFHLXTXEBbRFCAGLyMxhZmxOLRLdkotgUrGNLvmQLdwESPOLtzalvEppbiLCVkbTDmlXZNRpsMstKcsLmQZHZncDszd"));
    this->BEZkLcgeMsC(true, -119533.3308970688);
    this->fFIINmkXAiCk();
    this->DiFoQNSRYgFBU(string("ucqOiG"));
    this->iMtJvOvwOuil(string("qZMdMJawgzURpohcaiTcCOKBuGWVcInqOrJHVhgswkSfCdCMpHxTsyXHuNOLflyIbaQqAkffaJdwtRBjarExwfCYuAfBJkGMnmJBghncDBbpoTTgvfdSgmUvXHSuGasSBAPINJzhGDkBZGWJYamPVWSwICyBDitCqIASAzZauHAEzkDksoPDVXsIQYamCwmTRdRyuSMzfyiPYSmJZrtlDkLoFpSsrXYpAsEetn"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nOYtH
{
public:
    bool eCaciRHhIjQe;
    bool addHJGLqlddWhwr;
    double uOAokbcamREALl;
    bool sTumvfWLHv;
    string PQUhfrOBc;
    string uRkXZkSfxlOuJAer;

    nOYtH();
    int BvzHXeLQ();
    string wIqLC(double dDBwEOstGXTtQT, bool QSajgqxHjai, string GoOGYOLjay);
    void VRkvz();
    int LpAHIatVVig(bool VKOiPalXebNgdkiA, bool rPuRIARU);
protected:
    string tyeAzckTz;
    double MfyKpjhuTCF;

    string cWvqApwnG(bool eowzsJqjtytOv, int FJNZvMUfp, double FOiRqJ);
    bool fWbdfk(double tHJzaPSB);
    void OsZOBv(double shTgjZPHZi, int FHPZQzUkEGwXmr, int cqVzpUPdZHudrMJB, int rRCSuCPUcSMCLS);
    void gKwTJ(int nDNvLxCToKocsl, bool aTNFQFGrdjJmfBo, string QMbKNXbQ, double fOPYOL);
    void tKOqHQpngpeo(string uYucE, int CcNKAAjHzejMdDj, double hTIlbtHoE, double skEGHmzzwOUUMjB);
    bool oFVYIrumayyxZYS(double irZivziP, string ozHegtRJKEhl, bool bFgLaXnANVegrw);
    int MXpcmTfRPXre(string nDQLrgNj);
    int CZkZnTrbxiu(string ArYOJq, int BLYUGlUBIjqL, bool oMxAG, bool ybxaieFY, double CezHkxq);
private:
    string XyjPDonBlpPVGcmR;

    double UrtFZMbYbLd(string BlbmMyx, string MPudtPRDUBPUjic, int CJTPYJAjHQCJ, int ULRasrTiTrPdzogF);
    bool LwppbGFe(bool NkrJHWyUike, double YbfWtV);
    void UVefXG(bool kgfZZEKZ, double pwDZy, int OEZHRCNFoOglP, double RQIOXGtsqao);
};

int nOYtH::BvzHXeLQ()
{
    double KaUbKQFwgv = 782499.6275300276;
    string laMbotCQz = string("ocrtJNdNAGMankzKsWYTzgAvishHFhCxHbnZuIQGcgpYGLUzxiLLvHyKHXMOdSLDSpdcfbdpSrchZijymsIARqIkFjcBOHeUKgJRnZipsdEWsjfmKkYixoASguKHBztIkLGpQhaaxKQKAYUbeKFciBQkWrPNqVtCQwfWJvcRHXhhrNuQfdtgdEKQYbXGXertPexQEqEAmDJUsuVBgzlzDspqjn");
    double hMwepcUzWGLZT = -165120.88775017648;
    string xMxlzM = string("dzTHHFKmlkBiQqkiRXcPtNiRErCvQJuLQrOBxwnyNfKPZfiNmMfzQdyHxNYYqUzrfbxcFllLBqWJPZktVgjaCwOUYkFXshumNViMZolbkLbBAsOiDNZnQeUsXWqUqNFZyODGvEVcWDeUiGsmNWSNGLUSOIQWPCjEfptsPAxTpRZlbDMbeOBicnxqnKmdrOrTXnFvRFgZgkvLnrbItAkysN");
    double YOULEYSNsm = 17376.119792367495;

    if (YOULEYSNsm > 782499.6275300276) {
        for (int bGGazxXfgQLUube = 1245798024; bGGazxXfgQLUube > 0; bGGazxXfgQLUube--) {
            hMwepcUzWGLZT /= YOULEYSNsm;
            hMwepcUzWGLZT = hMwepcUzWGLZT;
            xMxlzM = laMbotCQz;
            YOULEYSNsm /= hMwepcUzWGLZT;
            xMxlzM = xMxlzM;
        }
    }

    for (int lNaQTuYHTGaEzn = 346899601; lNaQTuYHTGaEzn > 0; lNaQTuYHTGaEzn--) {
        YOULEYSNsm += YOULEYSNsm;
        xMxlzM += laMbotCQz;
        YOULEYSNsm -= hMwepcUzWGLZT;
        KaUbKQFwgv = KaUbKQFwgv;
    }

    for (int NmVlfiLXlTgInp = 1076206128; NmVlfiLXlTgInp > 0; NmVlfiLXlTgInp--) {
        KaUbKQFwgv = YOULEYSNsm;
        YOULEYSNsm -= hMwepcUzWGLZT;
        YOULEYSNsm *= hMwepcUzWGLZT;
        hMwepcUzWGLZT -= hMwepcUzWGLZT;
        laMbotCQz = laMbotCQz;
        xMxlzM = laMbotCQz;
        xMxlzM += laMbotCQz;
    }

    return 1940137381;
}

string nOYtH::wIqLC(double dDBwEOstGXTtQT, bool QSajgqxHjai, string GoOGYOLjay)
{
    double xVAZmnGzsuBZbzOe = -419174.02267522895;
    bool gIYkOHvP = false;
    int VEZPUjDhJZHgvoW = -269326939;
    string vjXOUbqY = string("igeWlJccJIjQXjdLjODTIJJGGYtxwCeMsRjErEqOPNmKudPOnRzIBqFAPJdcTgvLeQmnDlUXtrCgmTgzWfkpmsiidQC");
    bool wXsQgsWCka = false;
    string DiUleKEPsCdz = string("cCRyJCozxQozEMGEzttetcdWgmHWXkczSfzGsCfmYEIYvsvChMWXeVTarKtJVNcZLMHfsdCKCfupJhwFXWCfEiuLbDNswNGjjLAvSEzoZOaYibIBQClbxNSZFtCDzgSAXMcezZDTTEfOnkEKRaDVLjNjwrPgxxIxsmCIkrwKhQCOsVmXIimtueWfiNXYWzShVZfPcHR");
    double wQyMypzZUmKHVy = 1000028.4287520515;
    bool xAmGvjjYPeDGx = false;
    int vWogTfcn = 1083800787;

    for (int FCREEVCtoNllk = 612257537; FCREEVCtoNllk > 0; FCREEVCtoNllk--) {
        QSajgqxHjai = ! gIYkOHvP;
    }

    for (int YalFryTdMgNBj = 1510845698; YalFryTdMgNBj > 0; YalFryTdMgNBj--) {
        wQyMypzZUmKHVy /= xVAZmnGzsuBZbzOe;
        wXsQgsWCka = xAmGvjjYPeDGx;
    }

    for (int QZzFaFoFZYvMB = 1877216218; QZzFaFoFZYvMB > 0; QZzFaFoFZYvMB--) {
        continue;
    }

    return DiUleKEPsCdz;
}

void nOYtH::VRkvz()
{
    double nRjLODTgU = -403442.08637027506;
    string xwADkghbpWUoSf = string("GCspVOCtnuUJVtBNVjqXRLlyqlWhJAuSfQixsKDLMlhtpUEffSbHOCfyCBaIDARxgKklJsltBNwqOGzHXkBxaPmUAxYdpVLDYqdROLZOiRNpaSMSazBDPYZyQJJSKMEiErXRsqzwxIHbUugQOvjXuVVZPWhnjgyXJZlrEnXMuhGmobjytqTSWyhAvSOXjEfqxbjxBBHYulowjjrCAyutXlKRNTLteuKoRFGO");

    for (int VtbNTtYjCLJEy = 1315721654; VtbNTtYjCLJEy > 0; VtbNTtYjCLJEy--) {
        xwADkghbpWUoSf += xwADkghbpWUoSf;
        nRjLODTgU *= nRjLODTgU;
        nRjLODTgU /= nRjLODTgU;
        nRjLODTgU = nRjLODTgU;
    }
}

int nOYtH::LpAHIatVVig(bool VKOiPalXebNgdkiA, bool rPuRIARU)
{
    string umXuaqcYNiJkGK = string("VeLtiXQlJUbzQGhyyhICIsNXYLJCGYpKZqEqxZVoAvEpqjeChUafBgJNlPKCvskvXrbidtRHqDpWudkJHhhqbguxjCUxipsghTLDaNtlweOMTtcZANOvvmJWQjsVrKEtMrpWCcKpvIxQhDXlLBGcNbPIkugKDzuETdOfViTTAspwhYcQBRqgKtKjwWEoEMPKPaIqvZiXAlTKfqaReipXJXMzudRiXOAjSFVWZkrqYSeMU");
    double OdevfoYjRmf = 597015.2094122209;
    bool zokzm = false;
    int CYiLpX = 180234221;
    int pmVbgfer = -148848803;
    bool iyRjd = true;

    if (rPuRIARU != false) {
        for (int XmRxWJX = 2052229192; XmRxWJX > 0; XmRxWJX--) {
            VKOiPalXebNgdkiA = ! VKOiPalXebNgdkiA;
        }
    }

    return pmVbgfer;
}

string nOYtH::cWvqApwnG(bool eowzsJqjtytOv, int FJNZvMUfp, double FOiRqJ)
{
    string SgMZRwWrdDwF = string("KhshyXphrkkSFjfROHSwISTvwnpTOYcDjcXkSEgzliaELPqnIEtMnnKqUOESbGTspJAzzcEVeDpHQIpWlDkFavRijHXxGbNMVMiBscWrGzcsuiUsBZkAbIQrNmRgRQrlQOeFeAXBiepLKyZPNAIBfHkSRcrshpqxKkQPYo");
    int VRsFIClh = 311133583;
    string smAnnfj = string("DPmMOOhYfICiPbWnLhERxAGwafMOGDkOMtQxyQHPmUoeTcjsHBJJBsIRYARMNigBYYfeBEITYtwdCFNmBlzIKXMmdMUfDQgrAEhTNQcdiRSpKHGCtAALjUQdIxsWVnHzMOlSi");
    int FxskoCCNxhkms = -959878927;
    double bhckARysDm = -760996.8984739124;
    int AeiBvsFcDsFttj = 1571559121;
    double erbCuvbWOmz = -457054.1365387998;
    bool DqVMb = true;
    double FXkvazZtza = -139931.4604267351;

    if (erbCuvbWOmz == -760996.8984739124) {
        for (int NEZqASV = 732405995; NEZqASV > 0; NEZqASV--) {
            continue;
        }
    }

    for (int StNYcPxFRPcVSlLl = 15866331; StNYcPxFRPcVSlLl > 0; StNYcPxFRPcVSlLl--) {
        FxskoCCNxhkms -= FJNZvMUfp;
        FXkvazZtza = erbCuvbWOmz;
        AeiBvsFcDsFttj *= AeiBvsFcDsFttj;
        AeiBvsFcDsFttj /= FJNZvMUfp;
    }

    for (int oZClCvLzVttT = 839615521; oZClCvLzVttT > 0; oZClCvLzVttT--) {
        bhckARysDm = FOiRqJ;
    }

    return smAnnfj;
}

bool nOYtH::fWbdfk(double tHJzaPSB)
{
    double cEaZx = 564813.6629235126;
    double EmjQFmB = 156864.85540327514;
    bool OMrPvCg = false;
    double VGNWFAdYjYHHZGp = 337950.32403299125;
    bool eVjofuwVu = true;
    double btsvx = 834252.1313441494;

    if (VGNWFAdYjYHHZGp != 695830.3194375782) {
        for (int LpbAZae = 1466730061; LpbAZae > 0; LpbAZae--) {
            VGNWFAdYjYHHZGp *= cEaZx;
            VGNWFAdYjYHHZGp *= EmjQFmB;
        }
    }

    for (int tjXbqE = 241368226; tjXbqE > 0; tjXbqE--) {
        btsvx = EmjQFmB;
        eVjofuwVu = eVjofuwVu;
        OMrPvCg = eVjofuwVu;
    }

    return eVjofuwVu;
}

void nOYtH::OsZOBv(double shTgjZPHZi, int FHPZQzUkEGwXmr, int cqVzpUPdZHudrMJB, int rRCSuCPUcSMCLS)
{
    bool LPgVJOoMxduUX = true;
    double jeIgUxgkTdaMlpL = -689102.4883160312;
    double HojCj = 38279.01038162043;
    bool wfrVlf = false;
}

void nOYtH::gKwTJ(int nDNvLxCToKocsl, bool aTNFQFGrdjJmfBo, string QMbKNXbQ, double fOPYOL)
{
    string MGStE = string("pfqSEZXZNW");
    bool JEScKbF = true;

    if (JEScKbF != true) {
        for (int NXkVEOuSfMjS = 212718036; NXkVEOuSfMjS > 0; NXkVEOuSfMjS--) {
            aTNFQFGrdjJmfBo = JEScKbF;
            QMbKNXbQ += QMbKNXbQ;
            aTNFQFGrdjJmfBo = aTNFQFGrdjJmfBo;
        }
    }

    for (int CVqaNT = 335301098; CVqaNT > 0; CVqaNT--) {
        JEScKbF = ! JEScKbF;
    }
}

void nOYtH::tKOqHQpngpeo(string uYucE, int CcNKAAjHzejMdDj, double hTIlbtHoE, double skEGHmzzwOUUMjB)
{
    string xxjuQUlCiyLHyBAN = string("JRicAaVoGteiGEaVgImwAfXWJjtTndPAzLngGIyhmXWBhG");
    int sVFLTdKg = 1863195315;
    bool zJKvQQDEnZLhOos = true;
    double wNPjOXlsLLtTlpF = 602844.008830869;
    double kodzeoNIC = -223675.97546738305;
    string cZSvM = string("sTCoPLHNGEuGLvLAaamQeoGAJOXqxeYDIZFqJKSpMHxRazItXrRQjnekOvkDYJvBCkGBSdUxsQXmLkSsNxwEXIIZNlHDfvCFzcugawlvZTWLootNPLSUTVHRXspSrWFRLIyvuVvBsiQpjydquFZfiEqArJSfjrNuKSaTvGqJrbabLVlOpoyDbkucaDvtOyvVRQTiLyxipkwUNWpsJncfLgefnADVlSjRkoIZZnlGsajBpgyTsH");
    double WlEmSVby = -21084.33431237695;
    string fCzbgfRDqHUPY = string("zqdKulvtzgWkxMdeLFoEsjJirxbjzVjZNcwTLllZkLujgSqrcKDKTSvtDjfaspggdHqxHqyyfTKSGcjYcHYVJQxXwXxQjxsmOnIOtJZVqreuiuWhRPqClmXRXuIsNTomsMMofMrSNJvJCgDxZQHVeGrfjZYmixNkvJEaRyuueUbSTprhOClhzPMymBrDjZwyvQcbWmmxCgCMa");
    int sUbMmAxSzNKrIsl = 127437865;
    double piRRXondV = -438574.7976590773;

    for (int hkphativ = 746575966; hkphativ > 0; hkphativ--) {
        skEGHmzzwOUUMjB /= wNPjOXlsLLtTlpF;
    }

    for (int ZRIhOSOxCa = 1594908601; ZRIhOSOxCa > 0; ZRIhOSOxCa--) {
        CcNKAAjHzejMdDj += sVFLTdKg;
        wNPjOXlsLLtTlpF -= wNPjOXlsLLtTlpF;
    }
}

bool nOYtH::oFVYIrumayyxZYS(double irZivziP, string ozHegtRJKEhl, bool bFgLaXnANVegrw)
{
    string FIeDyxWBaOJRfE = string("ZqdGrRlKOzAwysgWaROWmRINDcbdDJvSMQDBectAHpzXkFeMxmrfrUef");
    bool jVwXRNAxmFujVuEf = false;
    bool HYgVs = false;
    string eXHNupSqSnvrRvqT = string("fNyWIWfuJjhjVzgUYwZHCYgjEQJadGdABslxlDGcVojbhPDPlyWDLtydQswFWQIlAFDzeQAVTEZLxrJR");
    int wVKEuvIvvdsPk = -1089179329;
    bool PgqLhWluYPSUk = false;
    double nWGXPmdxes = 101565.90905168367;

    for (int QMWhNgAPKJojbOY = 1482958301; QMWhNgAPKJojbOY > 0; QMWhNgAPKJojbOY--) {
        continue;
    }

    for (int Rnrzry = 92367277; Rnrzry > 0; Rnrzry--) {
        continue;
    }

    if (FIeDyxWBaOJRfE <= string("nllABXyKxMalvyaSkYGz")) {
        for (int qsBUKsi = 962939142; qsBUKsi > 0; qsBUKsi--) {
            ozHegtRJKEhl = ozHegtRJKEhl;
        }
    }

    for (int lRHrgCcI = 252161283; lRHrgCcI > 0; lRHrgCcI--) {
        PgqLhWluYPSUk = ! HYgVs;
        jVwXRNAxmFujVuEf = jVwXRNAxmFujVuEf;
    }

    return PgqLhWluYPSUk;
}

int nOYtH::MXpcmTfRPXre(string nDQLrgNj)
{
    int xaETmidkIVBAPl = -1939949797;
    double XZLIQ = -318029.20843919925;
    double mmieKbfVtiHaqw = 61810.39764844166;
    string ZIPEfQsPuHup = string("YSRisbXzsvfqBQNVFlcADMpggTYMIxuscmrzMKJWopVTJkIcvvnnvuQYJJdJSUrUsOtLUnJKiCIieOYTGymdRNBZKH");

    for (int lolPYRRKVfZDCIDp = 1508669424; lolPYRRKVfZDCIDp > 0; lolPYRRKVfZDCIDp--) {
        nDQLrgNj = ZIPEfQsPuHup;
        nDQLrgNj += ZIPEfQsPuHup;
    }

    if (nDQLrgNj < string("hQ")) {
        for (int HsSgyE = 883454984; HsSgyE > 0; HsSgyE--) {
            ZIPEfQsPuHup = nDQLrgNj;
            nDQLrgNj += ZIPEfQsPuHup;
            mmieKbfVtiHaqw += mmieKbfVtiHaqw;
            XZLIQ -= XZLIQ;
        }
    }

    for (int FTTixiysRqP = 829733042; FTTixiysRqP > 0; FTTixiysRqP--) {
        nDQLrgNj += nDQLrgNj;
    }

    return xaETmidkIVBAPl;
}

int nOYtH::CZkZnTrbxiu(string ArYOJq, int BLYUGlUBIjqL, bool oMxAG, bool ybxaieFY, double CezHkxq)
{
    double mnkzgFJmreZqX = -768887.8716244189;
    double JBFKLwYm = -318176.407528141;

    if (JBFKLwYm >= 202738.22773018677) {
        for (int zfNMtUGO = 1603725310; zfNMtUGO > 0; zfNMtUGO--) {
            JBFKLwYm -= JBFKLwYm;
            JBFKLwYm /= CezHkxq;
            ybxaieFY = ybxaieFY;
        }
    }

    return BLYUGlUBIjqL;
}

double nOYtH::UrtFZMbYbLd(string BlbmMyx, string MPudtPRDUBPUjic, int CJTPYJAjHQCJ, int ULRasrTiTrPdzogF)
{
    double IverhFCzQB = 631767.1503854744;
    bool QsDRMDncavCs = false;
    int DEmojJiBRhxSW = -700788077;

    for (int liexH = 490012243; liexH > 0; liexH--) {
        continue;
    }

    for (int pCbEM = 731953476; pCbEM > 0; pCbEM--) {
        CJTPYJAjHQCJ *= ULRasrTiTrPdzogF;
        MPudtPRDUBPUjic = BlbmMyx;
        MPudtPRDUBPUjic += BlbmMyx;
    }

    if (BlbmMyx == string("GmksCVbUEmIwRhXRNuudEoBhWJSRSsYDcfjINlaVLULKDbDvasLDBIFRaGXwfrcgvcOrnRSxrViGhcJunzxsnXmEBLKWNkB")) {
        for (int TgvPlLjZyPHW = 759977843; TgvPlLjZyPHW > 0; TgvPlLjZyPHW--) {
            CJTPYJAjHQCJ = DEmojJiBRhxSW;
            DEmojJiBRhxSW *= ULRasrTiTrPdzogF;
            ULRasrTiTrPdzogF *= CJTPYJAjHQCJ;
            IverhFCzQB -= IverhFCzQB;
            ULRasrTiTrPdzogF += CJTPYJAjHQCJ;
            ULRasrTiTrPdzogF /= ULRasrTiTrPdzogF;
            DEmojJiBRhxSW /= DEmojJiBRhxSW;
        }
    }

    for (int esGKR = 1959345712; esGKR > 0; esGKR--) {
        continue;
    }

    for (int qmzlgWzopV = 1236288104; qmzlgWzopV > 0; qmzlgWzopV--) {
        IverhFCzQB += IverhFCzQB;
        ULRasrTiTrPdzogF /= CJTPYJAjHQCJ;
        ULRasrTiTrPdzogF -= ULRasrTiTrPdzogF;
    }

    for (int AByGgTo = 1367505199; AByGgTo > 0; AByGgTo--) {
        DEmojJiBRhxSW = ULRasrTiTrPdzogF;
    }

    for (int iJummuBHXJemfMj = 1201110542; iJummuBHXJemfMj > 0; iJummuBHXJemfMj--) {
        MPudtPRDUBPUjic += MPudtPRDUBPUjic;
    }

    return IverhFCzQB;
}

bool nOYtH::LwppbGFe(bool NkrJHWyUike, double YbfWtV)
{
    int RNAITMINZIhGA = 668983529;
    int rcGWrX = 952730526;
    double gCvyXUMVwwTM = 36553.68061993787;
    bool VHmiUCvMNm = false;
    int QaQuTBn = -323040515;

    if (gCvyXUMVwwTM <= 36553.68061993787) {
        for (int DaEFXklgnZgdn = 1118934820; DaEFXklgnZgdn > 0; DaEFXklgnZgdn--) {
            NkrJHWyUike = VHmiUCvMNm;
            gCvyXUMVwwTM += gCvyXUMVwwTM;
        }
    }

    return VHmiUCvMNm;
}

void nOYtH::UVefXG(bool kgfZZEKZ, double pwDZy, int OEZHRCNFoOglP, double RQIOXGtsqao)
{
    double QruTCigAcsdPSQ = -632650.313023181;
    bool HGrUVzeXSP = false;

    if (QruTCigAcsdPSQ == 468610.955267709) {
        for (int wlnDRJAUPKt = 1661207058; wlnDRJAUPKt > 0; wlnDRJAUPKt--) {
            continue;
        }
    }
}

nOYtH::nOYtH()
{
    this->BvzHXeLQ();
    this->wIqLC(407864.8173174464, true, string("kARZKxatRNoiCJIjcEHFSledsHHwEBUmMlXMSFWsMKkhFiAWQfBFIAndaCrsdPTdAPoYWuNPWXUmttKhMFzalXwkUmLumlTRjwiIPfjPySCIM"));
    this->VRkvz();
    this->LpAHIatVVig(true, true);
    this->cWvqApwnG(false, 1011389590, -757418.4991826384);
    this->fWbdfk(695830.3194375782);
    this->OsZOBv(78931.40760300888, -1598093801, -201707659, 199065133);
    this->gKwTJ(647868321, true, string("oxeaxVblXUJllvCzyyRAgSCPDosIeXiFpKakZhGBVHQTqakhKGBUKaZzYKaWahCEhQGtzXxOnkheVFpBrLksnEidqhwyUGfLOCCeqxnleUlLyamwdYNjymTHaGohGwyNjttUaOZYqJtxtHydlmMIqXMjvYVNhGnPlKnMgFOsBHIGoszcDfooFaIHmClpMdVGoRlWlMsxyOJnaDDeevRndsUmwxYNGYqRCZA"), -136424.36833304208);
    this->tKOqHQpngpeo(string("WZsaSRCRZvMuJZOqVlxXsoobYSAJqXZQpFzfegValCUjRbHPXXhrfJWdxxQcClVZwaBgtIsTRUaHPZGjuSSCWDSmChLGPFiyonrapgkUtLuNjzStnfcobtNKBQMbP"), 809926624, -786379.076418146, -374124.6719398026);
    this->oFVYIrumayyxZYS(-39794.47623407618, string("nllABXyKxMalvyaSkYGz"), true);
    this->MXpcmTfRPXre(string("hQ"));
    this->CZkZnTrbxiu(string("fCaUEMBaIvZaUxdKIIFhpDoTnIPznlDeQWdozQhSmCfMTceY"), 964102274, true, false, 202738.22773018677);
    this->UrtFZMbYbLd(string("GmksCVbUEmIwRhXRNuudEoBhWJSRSsYDcfjINlaVLULKDbDvasLDBIFRaGXwfrcgvcOrnRSxrViGhcJunzxsnXmEBLKWNkB"), string("iFatOlaPUZcELsFGZMwOjvdlqKgZEXrtcjWVPskpsSEdODfqrJZYBOtrzeLwRbQnBOycBomKKKMNzwJmjkqRWPyIvJiJKgOHzZoivHnoryZxNxBEptBMYcGwMJbqaVVixkuDvsdkTidMoLSlrpXWmrppVrsL"), -1413290567, -1493618802);
    this->LwppbGFe(true, -347703.2639315215);
    this->UVefXG(false, 998746.8245519681, -603206978, 468610.955267709);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GlLafoKUlNnq
{
public:
    bool VSxzTLGKpTWS;

    GlLafoKUlNnq();
    double oHaTX(bool uCuALqRHyBamS);
    void MOroWiyahzhsoe(double EIUQCLziTuoG, double rqZtsWmMaqczrFI, bool DcQDAPrUydvptEVg, bool FWsOvLEZ, bool JJptdFlHSLgPH);
    void nKulpelSVdjnwem(int ZYdWWEQfKsO);
    double QOCbyXkpxSVsd();
    bool FMysXUM(int VuIbWkFVNYTUmfM);
    bool Hplxi(double RkkxwSdk, string abHMqrTXxJ, int OeRpbzaHTpjQLZ);
protected:
    double vLrikHxFhralqdE;
    int QsYdTmoQ;
    bool bvwIIaXHbZeKr;
    double ZgsUICXJhl;
    int NKZZMovdiIXQX;
    int KEWwdJrnlwpRnEcg;

    double eAcNS(int MhyPufKfEM, bool RABbHUBIyP, double QgFjdrcPQpSPJ, string cxyFYWvXzqTVimpx);
    double RYhUSFO(string HIapeZGAPey, bool mGAkoLNWxNrtXO, string VWpNfFhRzLm, int YlybwTYS, string VQFmdwEnogd);
    void dcVzixqHvRoyQ(double eCYeuwxhUG);
    string RaugXNiZ();
    int HinFW(bool gCwDJqUxB, double xnJuHAG, bool acIacdbJf, int JbYav, bool SbdjCGzloBcl);
private:
    double yIlAtGeXXLodOPwz;
    bool ldTSCaHwTwQgliM;

    void CxzGFqMZJyfeRlHr(bool OXoKyXyTqq, string MyLXfQShXixwSGD, bool mHrtDhekuOpxgnin, double AaqcefHxzNgaIh, int FtrhHhzsJ);
    string HskqymUDj(bool PITBzddvCcljvFD, bool xCxKYZWjiD, double jDforCjQrZ);
    string cXDUhqAarx(int bXcBwHbNbJV, string ntTcKq, double dFjYenexsJ, int IFEaVawkNFZ, double anteCZbWAzMJDoG);
    double qiWOdFSdbUtaVy(string kWMVvJ, double bBolRYseCI, int LhviNMpqkGNbgp, string YCldAhZL, int bCTFXCXTuXRIq);
    double LbCKjoF();
    string zlACGbcHQj(string uVwWd, string zOGCEEDPRfvsUye, int JKozCHqH);
    string OhziB(bool nvwmNlcsWqrRipRj, bool kLeMOeUMDrfpbncK, bool WGMeXfVHDmgS, double GOkRkQ, double cnqWLDNYpFfOL);
};

double GlLafoKUlNnq::oHaTX(bool uCuALqRHyBamS)
{
    double yAJPMdtj = -222107.1489308676;
    string OGFtheqq = string("LAYHuIMiJKaoIkODkHVGjUACFVsvdvGiPCImezDT");
    int wpEXj = -986493836;

    for (int sYQAlxuiy = 94816824; sYQAlxuiy > 0; sYQAlxuiy--) {
        wpEXj += wpEXj;
    }

    if (OGFtheqq <= string("LAYHuIMiJKaoIkODkHVGjUACFVsvdvGiPCImezDT")) {
        for (int zLiUBPAMLjQ = 559929291; zLiUBPAMLjQ > 0; zLiUBPAMLjQ--) {
            OGFtheqq += OGFtheqq;
        }
    }

    return yAJPMdtj;
}

void GlLafoKUlNnq::MOroWiyahzhsoe(double EIUQCLziTuoG, double rqZtsWmMaqczrFI, bool DcQDAPrUydvptEVg, bool FWsOvLEZ, bool JJptdFlHSLgPH)
{
    double NHJPZdrjDERk = -505189.51767755306;
    bool jfPWWQRlVkiM = false;
    int axRpfMidAlqpq = -960242494;
    int yQvfDleEyeK = -481735980;
    string VAlIBgcQXVO = string("NOOkjFUZgKCXSOKnTWrYuonXEhIMJZkSleqZDTeACDfzzBUjtvjhOJKiSUkXNUdjlmYpfSxwJSEuonYwzlhAvAlUpzZyyBoxRxRenUdUboOiGbCVXwwhxGMzzRhplqAhEhhjBaFEZNftXMWKsUJLhijgDlEFeihuJHbPrOdxzDWMMspqMnMgDGrijJfwcaWaCaYRMnGhVONPHqZBXrqtx");
    int YqqDbrpO = 70764206;
    double SMjARqVaV = 157457.65252502327;
    double CevOad = 672175.7553559052;
    double UxcqMfwUCfYBI = 985536.8591978037;

    if (CevOad < 157457.65252502327) {
        for (int ybklwar = 1117634782; ybklwar > 0; ybklwar--) {
            DcQDAPrUydvptEVg = ! JJptdFlHSLgPH;
        }
    }

    for (int hXFWVNVyWcHW = 779290888; hXFWVNVyWcHW > 0; hXFWVNVyWcHW--) {
        continue;
    }
}

void GlLafoKUlNnq::nKulpelSVdjnwem(int ZYdWWEQfKsO)
{
    string WPwHieFzv = string("MLQvRcTlapAFbfqbAWmDQRTvRhyeTaAGyIjtufpEHGcOcgIWOiFrojRhtpwcaktAjHSmtTqFFuIfwDwEcdkIhG");

    if (WPwHieFzv < string("MLQvRcTlapAFbfqbAWmDQRTvRhyeTaAGyIjtufpEHGcOcgIWOiFrojRhtpwcaktAjHSmtTqFFuIfwDwEcdkIhG")) {
        for (int GjJgxMgXz = 715957130; GjJgxMgXz > 0; GjJgxMgXz--) {
            continue;
        }
    }

    for (int jNkkFxuUPq = 1465140192; jNkkFxuUPq > 0; jNkkFxuUPq--) {
        WPwHieFzv += WPwHieFzv;
        ZYdWWEQfKsO *= ZYdWWEQfKsO;
        ZYdWWEQfKsO /= ZYdWWEQfKsO;
        WPwHieFzv += WPwHieFzv;
        ZYdWWEQfKsO -= ZYdWWEQfKsO;
    }

    if (WPwHieFzv <= string("MLQvRcTlapAFbfqbAWmDQRTvRhyeTaAGyIjtufpEHGcOcgIWOiFrojRhtpwcaktAjHSmtTqFFuIfwDwEcdkIhG")) {
        for (int ldhHAXzCY = 1863248533; ldhHAXzCY > 0; ldhHAXzCY--) {
            WPwHieFzv += WPwHieFzv;
            WPwHieFzv += WPwHieFzv;
            ZYdWWEQfKsO += ZYdWWEQfKsO;
        }
    }
}

double GlLafoKUlNnq::QOCbyXkpxSVsd()
{
    int chZRgkePzXgJkwlH = -497978120;
    double iFlpccb = 869434.5613972516;
    string iKfmNgKUISE = string("OuPqCRYerKHuKHDafGfHrOyEqLAbqplwZCQbARItxAXyIuDippGOWeURUUtRHVaGkyAJAZtjcHQkdSeflQolZEKkwmQvDUClANlIttSJWctoDSxnHLLokIGtxuIkFh");
    double zJAfFKTyhQep = 487806.7891270691;
    bool XZcgsIbXWa = false;
    double DOitFwEVPu = 129434.12363603919;
    double NVzrYTZlf = -942131.8465207324;
    string lfhwCjAlaFF = string("FCPPeYaSLuTdzeXBHllYBrCavkqNvdgcYsJDksHRFjUnXKXDOlgNzPjFXeFlWTaQiuFWBUMifLMvfBMXTtufLpWFDRIjQCfxMQsbJZFwvNLnlziCkkzTDogIhJxYQBazVLznCmbwfwzOHTAMaquLXfsDzsevdAtwmHpyhQdeJMWixLraWMmwgnV");
    bool qqkuTADL = false;
    bool rgbCI = true;

    for (int LyHrj = 1975938610; LyHrj > 0; LyHrj--) {
        lfhwCjAlaFF = iKfmNgKUISE;
        lfhwCjAlaFF = lfhwCjAlaFF;
        DOitFwEVPu /= zJAfFKTyhQep;
    }

    for (int avVCvR = 1480752538; avVCvR > 0; avVCvR--) {
        continue;
    }

    for (int uXfFZsRyLVXmXN = 386302962; uXfFZsRyLVXmXN > 0; uXfFZsRyLVXmXN--) {
        lfhwCjAlaFF = lfhwCjAlaFF;
        qqkuTADL = ! qqkuTADL;
        iKfmNgKUISE += lfhwCjAlaFF;
        zJAfFKTyhQep *= DOitFwEVPu;
    }

    for (int VSghRjLiVbmzeRyi = 1281870783; VSghRjLiVbmzeRyi > 0; VSghRjLiVbmzeRyi--) {
        continue;
    }

    return NVzrYTZlf;
}

bool GlLafoKUlNnq::FMysXUM(int VuIbWkFVNYTUmfM)
{
    double KazlPa = -432730.584682807;
    string glijLL = string("iKXPcOxzcYsrtbEMIKdcO");
    int QqyUA = -1978249286;
    bool UNIjlvubfbenoiw = true;
    double GWPucbuEhwPDoTD = -349792.4048980445;
    int BbteXzvi = -2026711878;
    double yNkAmX = -51339.387461621554;
    string tQKRnyCflh = string("pEJhmBChyIQeDEijhrGLhDIzaElhbGukcHDcIhmEdUuiTqciDMCwikloadupQNZbGvcHAxSeJdStkSfqnwDNiyGmDywBgvKwdTLsPFtBMUgBbfkYuaQNZQbBQ");
    string TyIHuPkR = string("dcMPSrJKxnlRrMmuaoSciOtbhUluctNgktxCVZdKjnKZVkHcPxpbjWZTSUIAZwYgvrgfmTGdnqxOjSezKkYWxdIPTpQHRSzXJLKeBbJnSTqWfceHCUiQyWpMpTsOQHqcYhBUPMoCOovwmRkYtjceCTrXSvmUmBAB");
    string VVuwRVINJEEHdkM = string("aVZbekhcMSgsYFtfJwJNrqdGwQXAjGVuklaGVNifZPFu");

    for (int IOTEbPHOxhItHqi = 754838263; IOTEbPHOxhItHqi > 0; IOTEbPHOxhItHqi--) {
        QqyUA -= VuIbWkFVNYTUmfM;
    }

    if (GWPucbuEhwPDoTD != -51339.387461621554) {
        for (int wMEtE = 405860492; wMEtE > 0; wMEtE--) {
            continue;
        }
    }

    for (int IAivraPHGyOR = 1706345584; IAivraPHGyOR > 0; IAivraPHGyOR--) {
        glijLL = TyIHuPkR;
        yNkAmX *= yNkAmX;
    }

    return UNIjlvubfbenoiw;
}

bool GlLafoKUlNnq::Hplxi(double RkkxwSdk, string abHMqrTXxJ, int OeRpbzaHTpjQLZ)
{
    double jctdkXrAxYfe = -117862.7076866418;
    bool JUMijgLGsycccrvN = true;
    bool nniSI = true;
    bool LpdpHsH = false;
    int hCQQR = 1055208219;
    int mtYfMgriqYz = 475860815;
    bool xCkYzray = true;

    if (JUMijgLGsycccrvN != true) {
        for (int EzhrwwNoFpwctm = 1576186104; EzhrwwNoFpwctm > 0; EzhrwwNoFpwctm--) {
            continue;
        }
    }

    return xCkYzray;
}

double GlLafoKUlNnq::eAcNS(int MhyPufKfEM, bool RABbHUBIyP, double QgFjdrcPQpSPJ, string cxyFYWvXzqTVimpx)
{
    bool mkJPPiJRrmsmZ = true;
    string lUvayQiQZITC = string("zwdvEKAmZxOXGcKpwOALbIxvbVmbjpWNgqbbxXxbPLeJVhPdgKobCQuYpuUWKmiYkZDUyQlfqhGApkgwHLbosAAQZfoOnpGJQ");
    int iSibLrXjANuksKCD = -730174752;

    return QgFjdrcPQpSPJ;
}

double GlLafoKUlNnq::RYhUSFO(string HIapeZGAPey, bool mGAkoLNWxNrtXO, string VWpNfFhRzLm, int YlybwTYS, string VQFmdwEnogd)
{
    double prktuci = 1043593.1599336641;
    bool yqrYwIv = false;
    int VQxAfsXA = 1124381567;
    bool DEfZMyodvlAYHHu = true;
    int IvAZYaezrOrGC = 846292003;
    string fjgGtPAgKp = string("onKvjdzVOgEatKNymYprMmRHuFyaOQAErHNXGLhjrWpKRisjbLMJLQVAWxFwhKjTjPcvvkzyyjkHPNctLQFdLXJHMxfhaHKpUJUtjdcdqSHWfsXxFEHyWAxOuUJmydiqScOYiZvssAiXcwdOtLRSsaCiGCKrZEuvWdeMo");
    bool dWfxZodEmAwdscF = true;
    int wsuotciNR = 57368148;

    if (DEfZMyodvlAYHHu == false) {
        for (int ooKXAujuKCoj = 1185448592; ooKXAujuKCoj > 0; ooKXAujuKCoj--) {
            VQxAfsXA *= YlybwTYS;
        }
    }

    for (int MsfvstYvW = 1571605386; MsfvstYvW > 0; MsfvstYvW--) {
        IvAZYaezrOrGC += YlybwTYS;
        wsuotciNR /= YlybwTYS;
        VWpNfFhRzLm += HIapeZGAPey;
        fjgGtPAgKp += VQFmdwEnogd;
    }

    for (int EWsBfRzXSLQsOsCA = 1329419078; EWsBfRzXSLQsOsCA > 0; EWsBfRzXSLQsOsCA--) {
        VQxAfsXA -= IvAZYaezrOrGC;
        mGAkoLNWxNrtXO = ! yqrYwIv;
        DEfZMyodvlAYHHu = DEfZMyodvlAYHHu;
    }

    for (int iusvd = 870255745; iusvd > 0; iusvd--) {
        mGAkoLNWxNrtXO = ! yqrYwIv;
    }

    if (VWpNfFhRzLm == string("onKvjdzVOgEatKNymYprMmRHuFyaOQAErHNXGLhjrWpKRisjbLMJLQVAWxFwhKjTjPcvvkzyyjkHPNctLQFdLXJHMxfhaHKpUJUtjdcdqSHWfsXxFEHyWAxOuUJmydiqScOYiZvssAiXcwdOtLRSsaCiGCKrZEuvWdeMo")) {
        for (int JwnouHXzgV = 251305106; JwnouHXzgV > 0; JwnouHXzgV--) {
            wsuotciNR /= YlybwTYS;
        }
    }

    for (int dVTFSCKntpinWJE = 774546262; dVTFSCKntpinWJE > 0; dVTFSCKntpinWJE--) {
        wsuotciNR *= IvAZYaezrOrGC;
    }

    return prktuci;
}

void GlLafoKUlNnq::dcVzixqHvRoyQ(double eCYeuwxhUG)
{
    bool iBmNtt = true;
    bool OWSzfWdmZNWFaSw = true;
    int iYyNfgA = -1415596282;
    double OyaBig = -570891.2504360441;
    double lILTjxdvokDrsh = 664999.9241501892;

    for (int TnAfHBfOq = 1347725160; TnAfHBfOq > 0; TnAfHBfOq--) {
        OyaBig -= eCYeuwxhUG;
    }

    if (OWSzfWdmZNWFaSw != true) {
        for (int wVQWRGTcV = 1263800294; wVQWRGTcV > 0; wVQWRGTcV--) {
            OyaBig *= lILTjxdvokDrsh;
            iBmNtt = ! OWSzfWdmZNWFaSw;
            OyaBig /= eCYeuwxhUG;
            OyaBig += OyaBig;
            OWSzfWdmZNWFaSw = ! iBmNtt;
        }
    }
}

string GlLafoKUlNnq::RaugXNiZ()
{
    double EghmIQcMLMqoRHT = 777696.5100945818;
    bool NswJHpYMkDzez = false;
    bool uvzHPVxK = false;
    int sTIQiy = -1293025143;
    string pRfEJTWKda = string("DFnXfWmjwFTBBBoSUijioXhTFwASyJKrCWlHzLHPFtEWBkZryCKWxnOmdfspXtHytoDmMExutFNJVlSFMlYQTcpqmKCCGgKquXEKMNLqUfGESUyRLUtfllTdzldMnqsDCvTFtISJjHdNYpGVyDYcEOcPmZYAjeNHWfASnmHxkSdSteuQPncaSzRqvegozCKBHlInBSLBhGNsnHVslylkPmPjGzMSLH");
    double uZZePBRoGSF = 209057.92205603496;
    int WEeQDq = 1904091442;

    for (int UirYhjHhGpbd = 1278459627; UirYhjHhGpbd > 0; UirYhjHhGpbd--) {
        continue;
    }

    for (int OpOzNMbzp = 963694334; OpOzNMbzp > 0; OpOzNMbzp--) {
        sTIQiy = sTIQiy;
    }

    for (int WqUYAy = 58707266; WqUYAy > 0; WqUYAy--) {
        sTIQiy -= WEeQDq;
    }

    for (int RAisFBpkXqRoYn = 1091935565; RAisFBpkXqRoYn > 0; RAisFBpkXqRoYn--) {
        continue;
    }

    for (int zzATXrhYyuIMDgY = 273706642; zzATXrhYyuIMDgY > 0; zzATXrhYyuIMDgY--) {
        sTIQiy = WEeQDq;
    }

    return pRfEJTWKda;
}

int GlLafoKUlNnq::HinFW(bool gCwDJqUxB, double xnJuHAG, bool acIacdbJf, int JbYav, bool SbdjCGzloBcl)
{
    bool MhLosyxDLovFoNv = true;
    double KFqtclj = 991943.2988212883;
    double VEDwNNDCUIRLSfwc = -334922.744354695;
    bool EfAUvInRt = true;

    for (int mLKIxYcXtHn = 1525765982; mLKIxYcXtHn > 0; mLKIxYcXtHn--) {
        MhLosyxDLovFoNv = ! gCwDJqUxB;
        EfAUvInRt = ! MhLosyxDLovFoNv;
    }

    for (int OyppGZBVXt = 999209884; OyppGZBVXt > 0; OyppGZBVXt--) {
        EfAUvInRt = acIacdbJf;
        gCwDJqUxB = MhLosyxDLovFoNv;
        VEDwNNDCUIRLSfwc -= KFqtclj;
        VEDwNNDCUIRLSfwc = xnJuHAG;
        SbdjCGzloBcl = ! EfAUvInRt;
    }

    for (int mFhrymHnzbpWyfFC = 1204917935; mFhrymHnzbpWyfFC > 0; mFhrymHnzbpWyfFC--) {
        gCwDJqUxB = ! EfAUvInRt;
        EfAUvInRt = EfAUvInRt;
        xnJuHAG -= xnJuHAG;
    }

    for (int ikfCseJo = 83055372; ikfCseJo > 0; ikfCseJo--) {
        continue;
    }

    for (int JDABkvvgESmA = 729484179; JDABkvvgESmA > 0; JDABkvvgESmA--) {
        MhLosyxDLovFoNv = gCwDJqUxB;
        SbdjCGzloBcl = ! MhLosyxDLovFoNv;
        MhLosyxDLovFoNv = MhLosyxDLovFoNv;
        MhLosyxDLovFoNv = gCwDJqUxB;
        gCwDJqUxB = ! EfAUvInRt;
        SbdjCGzloBcl = ! gCwDJqUxB;
    }

    if (SbdjCGzloBcl != true) {
        for (int yYodycBfWw = 1242527947; yYodycBfWw > 0; yYodycBfWw--) {
            continue;
        }
    }

    if (KFqtclj < 991943.2988212883) {
        for (int qHroVaBKcNuwudL = 1797139948; qHroVaBKcNuwudL > 0; qHroVaBKcNuwudL--) {
            SbdjCGzloBcl = SbdjCGzloBcl;
            acIacdbJf = ! gCwDJqUxB;
            EfAUvInRt = EfAUvInRt;
        }
    }

    return JbYav;
}

void GlLafoKUlNnq::CxzGFqMZJyfeRlHr(bool OXoKyXyTqq, string MyLXfQShXixwSGD, bool mHrtDhekuOpxgnin, double AaqcefHxzNgaIh, int FtrhHhzsJ)
{
    bool OBZnYMzGGYSBm = true;
    double TcrDPVUlNMvdZ = 926751.4304949538;
    string cCvIkSdsXlTOVxE = string("fngqZzpAGurfqWDjbibCXezyKgrTNegDnTsjqpWbUqnFlXbAwt");
    int iGtWMi = 1923624692;
    bool IfkuzoiCyMrKTu = true;
    int agfUUUxVZtjY = 1267633;
    bool KmslgJMnrNNKKYaw = false;
    int iQINLfPWN = 685990456;
    bool jCxRTMiz = true;

    if (mHrtDhekuOpxgnin == false) {
        for (int DlTMqnTEsPkvxokF = 1551936227; DlTMqnTEsPkvxokF > 0; DlTMqnTEsPkvxokF--) {
            continue;
        }
    }

    for (int JBOlm = 1714512533; JBOlm > 0; JBOlm--) {
        TcrDPVUlNMvdZ += TcrDPVUlNMvdZ;
        OXoKyXyTqq = IfkuzoiCyMrKTu;
        FtrhHhzsJ = FtrhHhzsJ;
    }
}

string GlLafoKUlNnq::HskqymUDj(bool PITBzddvCcljvFD, bool xCxKYZWjiD, double jDforCjQrZ)
{
    string vuipmuTeCqa = string("KBYrEpfaWCANBopikOBSvUCWZFFNXAlmkAeIHGqlKycTrYALErTIfmAlFrzSsZPpaEiwuOsQIgyHLUXSPvfmYZwbetSxcgGgDTbZrCVYbgrZkWuvpXMCDGbgZREtzWhVGwoCuzrkmSAxGWNYffzGkffrEYVTkmYPXSIKVaMFimdpqGNnNtLBbJHFQQcDOyQdTKWKxvWthlRnjtfyarWLXGkqSfuQ");
    double ZqgjuNPgmeqLdI = 54815.126335391564;
    int EdwfE = 219322082;
    double EvHwHgXjAh = 395609.45925647544;
    string PIMXAd = string("BIGAHVylCCRVbiLGiAdtqHSgPqgyxwGriHNtFtReFkYWVPJmVaafFkuJAIrGYwHIJkBViSaiFSjRDMTtMXlzDoXayGvUPaQxERGhFlymQxoRsBbPiXlenFxNtDIyOHuyTTJrDLxGQGnaLgNINkTpHoEKaCWlSTyVGOwNHrGikxBgIkLXjPrZXZZULvpkSGLTANdAYSGUfzKkfKefheEAjKGSAutlrAUfaM");
    double vjDCNFKYQu = -540052.0175012231;

    for (int fILOjDD = 1412932772; fILOjDD > 0; fILOjDD--) {
        jDforCjQrZ = jDforCjQrZ;
        vjDCNFKYQu /= vjDCNFKYQu;
    }

    return PIMXAd;
}

string GlLafoKUlNnq::cXDUhqAarx(int bXcBwHbNbJV, string ntTcKq, double dFjYenexsJ, int IFEaVawkNFZ, double anteCZbWAzMJDoG)
{
    double BZFHZjNpnnCJtvx = 400403.11451344367;
    int NNYDQEuyrNtib = 375193131;
    bool KweID = true;
    bool LgSMCRglAXlvLCTW = false;
    double EXIinDz = 180215.587219578;
    double VDUxkXvnpeFhBRcQ = 844887.5840259092;
    int cdbECFCrCjdJRk = -209689928;
    string Ikopp = string("iajBwQvhMevquYEIZcKCOaWQVsXcevfxaoccWZefkrefEsvvhSevfCnFDMcKVjzrBgabYfkIChzgnAoykJoBnhacdcnuorgoqUwqzSQRjxJRNNghvVhDEtVCWRc");
    bool ZmbTiqhu = true;

    for (int ULEXEdDaByiJr = 1594166913; ULEXEdDaByiJr > 0; ULEXEdDaByiJr--) {
        bXcBwHbNbJV = cdbECFCrCjdJRk;
        anteCZbWAzMJDoG += EXIinDz;
        ZmbTiqhu = ZmbTiqhu;
        BZFHZjNpnnCJtvx /= EXIinDz;
    }

    if (cdbECFCrCjdJRk < -209689928) {
        for (int qXkXdQMR = 1905959418; qXkXdQMR > 0; qXkXdQMR--) {
            EXIinDz = anteCZbWAzMJDoG;
        }
    }

    return Ikopp;
}

double GlLafoKUlNnq::qiWOdFSdbUtaVy(string kWMVvJ, double bBolRYseCI, int LhviNMpqkGNbgp, string YCldAhZL, int bCTFXCXTuXRIq)
{
    int YvISNiXY = -1060513168;
    int QjDwpBEeXxJQU = -546046608;
    bool OJuZoUbVnjkpq = false;
    int uUqVuipa = 1324860394;
    double LwAsuOpsOOYSB = -643064.3267151396;
    int CRshEgecQbT = -170467237;
    int CcgvLNDTxj = 675382957;
    int PPVFNhGNC = 1384061982;
    string totHIdpgsnmUgq = string("QFgBBOmpKCmwKuUhdqCGXzCqkMdgqbykkzkcwqytsrrnmOb");

    for (int zChHOdatMQmGmY = 466763674; zChHOdatMQmGmY > 0; zChHOdatMQmGmY--) {
        continue;
    }

    for (int WUlKMsjrFa = 1106216050; WUlKMsjrFa > 0; WUlKMsjrFa--) {
        uUqVuipa -= CRshEgecQbT;
    }

    return LwAsuOpsOOYSB;
}

double GlLafoKUlNnq::LbCKjoF()
{
    int TRncwor = -883403543;
    string NPtaAudleDJ = string("STcStmmcCTQUkdafOBEwgMivCfCqaIcrTyspFTHxwvYgnmpBfmkgBpJocljoGFBUECvsNsvyZFnvJKyGTdMDqDMIpkIpgiCjNpwvTDRVFvHLToHMwqz");
    double JjDxDj = -914918.5170499099;

    for (int nrrbdbigWJGYsWr = 1108789857; nrrbdbigWJGYsWr > 0; nrrbdbigWJGYsWr--) {
        JjDxDj -= JjDxDj;
        NPtaAudleDJ = NPtaAudleDJ;
        TRncwor -= TRncwor;
        NPtaAudleDJ += NPtaAudleDJ;
        JjDxDj /= JjDxDj;
        JjDxDj += JjDxDj;
        TRncwor += TRncwor;
    }

    return JjDxDj;
}

string GlLafoKUlNnq::zlACGbcHQj(string uVwWd, string zOGCEEDPRfvsUye, int JKozCHqH)
{
    double UxJmbmlhbGp = -110127.63991843122;
    int hywbOMS = 1580195810;
    double vrSbtyQYTzLLnau = -212651.9428797316;
    bool mihglQZv = false;
    double MiWslqyUJVDPqFhv = 912360.792562559;

    return zOGCEEDPRfvsUye;
}

string GlLafoKUlNnq::OhziB(bool nvwmNlcsWqrRipRj, bool kLeMOeUMDrfpbncK, bool WGMeXfVHDmgS, double GOkRkQ, double cnqWLDNYpFfOL)
{
    double UUjWiiyRhhRt = -171819.62538369244;
    double MKoQUA = 442729.8887027477;
    bool vRLuVlFrwIxAoyW = false;

    if (vRLuVlFrwIxAoyW == true) {
        for (int BXqJgwsp = 955793036; BXqJgwsp > 0; BXqJgwsp--) {
            kLeMOeUMDrfpbncK = ! nvwmNlcsWqrRipRj;
            nvwmNlcsWqrRipRj = vRLuVlFrwIxAoyW;
        }
    }

    if (cnqWLDNYpFfOL < 442729.8887027477) {
        for (int uCWBMHMCwlPBQnoN = 1225586235; uCWBMHMCwlPBQnoN > 0; uCWBMHMCwlPBQnoN--) {
            continue;
        }
    }

    for (int FpszfTvcuMvTsK = 695907076; FpszfTvcuMvTsK > 0; FpszfTvcuMvTsK--) {
        cnqWLDNYpFfOL += GOkRkQ;
        nvwmNlcsWqrRipRj = kLeMOeUMDrfpbncK;
        vRLuVlFrwIxAoyW = WGMeXfVHDmgS;
        kLeMOeUMDrfpbncK = WGMeXfVHDmgS;
        MKoQUA = cnqWLDNYpFfOL;
    }

    for (int jMdpzUiWUoZLQRn = 1202667564; jMdpzUiWUoZLQRn > 0; jMdpzUiWUoZLQRn--) {
        continue;
    }

    return string("FjzhNZotPPXJbYFcgnkFNvfJolcchPMKAuiVVHKlNoZfaSzwkJyNbBGmzuTEABYOHGseTURyZIVJHfvmJpQcftYlEFspZeCkgoXfTEFrXQhhReffgNAJVGGGvlA");
}

GlLafoKUlNnq::GlLafoKUlNnq()
{
    this->oHaTX(true);
    this->MOroWiyahzhsoe(-450109.7231599976, 723404.7588598637, false, true, false);
    this->nKulpelSVdjnwem(-4190891);
    this->QOCbyXkpxSVsd();
    this->FMysXUM(479009236);
    this->Hplxi(-95113.96612006394, string("lSIpytZEzzbmCPolwpQrJsANKVncoOfvRoKwVYQsFVFKNvlKUTHgRKutKgZMhDqIoocHeIUWUVUFsSlAaiGAxihVKGGtGphSrSyHAsmtsbLLNbxySnDNKTlPSDmAUNUbgSuTSkviRxPoGQRNatDgHwXUhmbqbDgURaBVJtcotiplzcCiCpVJgIBwHwQSYWEqWhkfDwlflLCHv"), 1032221763);
    this->eAcNS(-524176422, true, 414550.01668308716, string("RSDZjBMhSCLAUEkLFlriczSMJfxmnwdyjrjOMIOqVHvQrWJMLvtwsZfHujzppZlGYLTcESEKLUxjoBgUjZGydMECQtTqLNuayMnStqEamIdzrcTNbWxoEjNzOvmSHfpcLUtKnmpxgrlFncAQahaofQaSQcz"));
    this->RYhUSFO(string("loMeBzDlLuXlqrnlDXPJQSRVai"), true, string("ZWWYrklFtDVEgdGYOcuPeiPVcFhMFLsRtttinrwjiBPAmEtWEYcWwXqIpBkAiwJixhbQAnaPSQDUWNNYgyYIlISVrrzVMERrUbxnRtTmsYxQHuBOqzJmsNlhXecPMaJfwjuFSaOOfbDpWloASFuRRzjdDuXeCzFZemleVhrGdqDBbaNNoysLnVsinnSxOJzADdqjLPiRj"), -1832976502, string("hsjHIDVIdnAVjaYzSKTuPjFehUrjnuYnZqbvwUHfzOOOebLPUHmgSu"));
    this->dcVzixqHvRoyQ(-633622.7919334598);
    this->RaugXNiZ();
    this->HinFW(false, 67996.2356244888, true, -1501604358, true);
    this->CxzGFqMZJyfeRlHr(true, string("SNWaxYbIJoMGdhLDHCvGZZbOYDGNcdFiImbwZaXcdtYOoMxKcTFGlQJjMPOrwsWOXKfInWYUbXysLVhCsKFsLmjcyzRgSEkMLSKJcFfNVJIKgUkWAXKCvAyZAQtuuZLpZtvfaZpAUKEYtmDZCbGgsujNGwODPsKgxRoGqmdjbZZVRFlIdmflxVgkUzAedvEsSTgQYVJQnUezmTiauOiMtyNqYilXyTdNkTWRscdvOXxQFarSkIK"), false, -501049.75099257973, 451782659);
    this->HskqymUDj(false, false, 772340.0273418995);
    this->cXDUhqAarx(1771118880, string("pHTavUBorsKEuVxNXaghVgzNXToxAMykliNIFgJCGwVdbwBbYxLWVzbffEMwNPlOajpMaQucvSuPjRJFPTwTUruQQqGJlnGqpMfpGrdIjgukgHKtMYTzOJqNnBFVDZHUiIGrYIDiHZeufCuSxCsUzmVKCXAANJEVghehyiDTJDTqXIEfNEMFxqweEJxQoHKgkSUVQBixpkSjhyXJmADhQxGmXZROxzhXY"), -976885.6567742858, 2081925950, 93460.12310185033);
    this->qiWOdFSdbUtaVy(string("OcIEEdCnCCHqQZdDwTbKIttpAiiFLPpMMOPYpqigmJqRdvcVeqWnAlAFcSzKBqdkvAZbkSIZDXUgPNBIVxSpqLJPziIieQlzLPGyYWYkIjDepzmbHAgkFFdcKlqMBFbNLNpHebtOuWTkVviVjdDWgGueEtwiBWNAGbUTsCItVvjweNGcivygenPsiubDHyhbdrKXmtlCeSe"), 365133.71336350526, 497264758, string("vtnaXPbvlIULgLospLGtnkosBhOoBzBuYjPVklRRcKkvTCRnUcJEGBmrZyvhcVqtENsagzqdyseNXypuZJRrIhAufcIeYGuFWcCIFeRMyOuOdgDenJtPUIWZlPVUKgESPSuecDLolFdUztcSgsKotdjwyVhpKmXKHlqZyNfXUkkSwMEbAQgmcJPIPCCDkpcGykswNHQVKnDgEteNTwNXmuPgtHeoUzAbiUYHYGyzuaTXVCJnN"), -1642838602);
    this->LbCKjoF();
    this->zlACGbcHQj(string("TKOYGyTsaUXimcjVKjgCETdaJTibPLXJNTPCCdlnUhDhXduWLlftrRHRTrMqHDGKxPRudWoPYqKDSJvTlusCjvwEhANaijpZbyJcDXeiYpzQzFJOLxvRYzrcIagesZWiYeEUDNVfQTVScmwNK"), string("qlTYCZJvHBJgWcdBvdhGbrEMFFVNQSFzsDSpIvafBSWojNxKuaEcrkqwGgjzNVgvjhZrYNLwcKohomBMqsPTzAXXLuFmkLMpBsJYbHVNyjIzJlDrLudCkXQGHioqNoccSHMvUTDTrAkgSuWkcLDWHeFmkiEtscMbDwjSwmJIuxyZPwOvHnhiVSsIwOAdjcsYZSjsMdeurpsLcXSzMMrmAkEcmNCtBICwtquSKl"), -850007291);
    this->OhziB(true, false, true, 776251.5729286829, -846966.4963804658);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YqVyBbJqrgp
{
public:
    double MeWSJAYrH;
    string WZImGMBKW;
    string FvreGB;
    double eDkKVTwotqL;
    double kavcJwJRAGm;

    YqVyBbJqrgp();
    double cWSYaU(bool xFmfhnPlpRqbEx);
    string rWjVw(string mlmvKUTxycfkHT);
    double YaRQkZBaLhe(int UHjFU, bool ZmfpwoZvEvgxfMlu, double ODVmRGwTUPUGj, int iDWVvZlh);
    int AoCzurPJguuE(double ujXFzkWJMjxNjkWa, double agaEulb, double bVHcrsFGhv);
    string rshbFhY(string JIfKXkLVLzLfBj, bool mVBZSHPwjTbUaYk, string nuhsWXJXtv, string aivPazvdUPg);
    bool XNXSghceXhc(string TuQvsEciMMh, double afdIGenj, bool DOYPbx);
protected:
    string jsAbYL;

    int PyiufDyIBppU(int KcBJwwWH);
    void pVmDoMycxOZzkD(int QAmKMVhyf, int vWJWAaJehuL, double mAFmg, double HYLeCDjgRwFIauGB);
    double xDjllmmd(string qzSTrqDMPhnWTgM, int VcpbQKSNIhnBVAkv);
    double pNZOyauxy(bool tMjtrFyalApWUPqY);
    int dKBwD(bool ObTWIvKJaJqT, string oVEqnWKtktIEvrC, int XfqhzrVqEf);
private:
    string dPruQiQlytJoUt;
    string UDGTfj;

    void PpuTwLxxKzwtZfO(string aDvOqJuF, string RMGkcWcoOsNpn, bool cuWcDFtaknaxPpNq);
    string FfRyBqXsprNoQww(string nYinEhVhFCtMVzRv, double mzHtqFtvl, string fVWBSVXpJRIXGQ, int SpXGrS, int lXkkZognemakjxt);
    void vjkgEqWKdqPlYyo(int kfbaAfSxe, double GNkso, bool oCXunfr);
    bool poeKQVDQjmxcs(double UgLgYRuWPNhxQ, bool WeRyyjd);
    int pXxiFbJppHLNud(string sNorDNalogTOwWk, double VcuUPz);
};

double YqVyBbJqrgp::cWSYaU(bool xFmfhnPlpRqbEx)
{
    string CZiHo = string("qWHBXOAhUbsCssCnOmLEnlLrrmRXzHeyPFVwCrktpDDYYIklAyhVlaOcoyvGegbPwFJCFaRunLjCWMUjqdZlUxtDICTaxVQdVFkUyUufxwxcnmIyQxFnFIOfMSGvLvJrpaElBERTwgrdDPrvhBGlobkRUnuALQrtSqvKJBzUVACelgUHyeueZzXkzWfPWtfymQ");

    return -971789.2307384503;
}

string YqVyBbJqrgp::rWjVw(string mlmvKUTxycfkHT)
{
    bool YVegVoFmxcoMWx = true;
    double FlozDJu = -943319.0629018575;

    for (int nMWRh = 939973127; nMWRh > 0; nMWRh--) {
        continue;
    }

    for (int uvUZIDMIcVZ = 652594747; uvUZIDMIcVZ > 0; uvUZIDMIcVZ--) {
        YVegVoFmxcoMWx = YVegVoFmxcoMWx;
        mlmvKUTxycfkHT = mlmvKUTxycfkHT;
        FlozDJu /= FlozDJu;
    }

    for (int bEEahaYOkqeZCOQe = 1299317222; bEEahaYOkqeZCOQe > 0; bEEahaYOkqeZCOQe--) {
        FlozDJu -= FlozDJu;
    }

    for (int SANkJmsQnwfUj = 1510338467; SANkJmsQnwfUj > 0; SANkJmsQnwfUj--) {
        continue;
    }

    for (int PvPEGBFsYmHZDfPi = 209908157; PvPEGBFsYmHZDfPi > 0; PvPEGBFsYmHZDfPi--) {
        YVegVoFmxcoMWx = YVegVoFmxcoMWx;
    }

    return mlmvKUTxycfkHT;
}

double YqVyBbJqrgp::YaRQkZBaLhe(int UHjFU, bool ZmfpwoZvEvgxfMlu, double ODVmRGwTUPUGj, int iDWVvZlh)
{
    double eUxiOXRLrHfPWZI = 704734.9827461046;
    double RYRzS = -622689.8748707331;
    string TvnlJxhkBg = string("hPrpSXDyKwDlRgdITIVMaxHyeoimTncjGUwMzetvzYiqtlLzSokeeETbrhfHaVYeoxJysJfcQLUAQOoPSFWrvqeyAiDIgCqSAXYdbSGDQfGVdQMmOZQvRpezyWYilqtvPdoveDnWINuNghuRWVEyFYoCspqXfYBnqZ");
    bool YsbzW = true;
    string CeSwlgTqcfFlw = string("BThhRdLHCIpaBLwkXjjMnWfIvewvicGQaADxsolbmuoTUeTnMVczJjYezRXhDUueRgQVxkLZRQYXUohZWGtnjfABCnrYOXdeanPWQGKwKGBFeZDWFOsDTSDcwpSaGjnqHnbjhXbxlfrVsZqdodqESlUdZHooEBkrpIBlcGJGhqxJESSJecNOpqZlZHfKTUfZaWSEWYdXafndQvrvbDw");
    int JGagwxVQZwq = 1699419683;

    if (ZmfpwoZvEvgxfMlu != true) {
        for (int zlxXAnxcIqWMI = 3397698; zlxXAnxcIqWMI > 0; zlxXAnxcIqWMI--) {
            JGagwxVQZwq *= iDWVvZlh;
        }
    }

    if (JGagwxVQZwq != -1676001653) {
        for (int OuPyhxqc = 2110520571; OuPyhxqc > 0; OuPyhxqc--) {
            continue;
        }
    }

    for (int SXTelazQzPVLsb = 393636447; SXTelazQzPVLsb > 0; SXTelazQzPVLsb--) {
        continue;
    }

    if (UHjFU == -1676001653) {
        for (int vdGGBHKxaI = 80696907; vdGGBHKxaI > 0; vdGGBHKxaI--) {
            iDWVvZlh += UHjFU;
        }
    }

    for (int nskmmDVDg = 580778432; nskmmDVDg > 0; nskmmDVDg--) {
        continue;
    }

    for (int yVMZJVRAOpOcCluz = 421291467; yVMZJVRAOpOcCluz > 0; yVMZJVRAOpOcCluz--) {
        ODVmRGwTUPUGj *= eUxiOXRLrHfPWZI;
        eUxiOXRLrHfPWZI /= RYRzS;
    }

    return RYRzS;
}

int YqVyBbJqrgp::AoCzurPJguuE(double ujXFzkWJMjxNjkWa, double agaEulb, double bVHcrsFGhv)
{
    double hfQScgfpjP = 716896.8903585473;
    bool GZjrOfxVGZ = true;
    bool bnWhIFbnEsp = true;
    bool PEjsDPyqUfIMR = true;
    bool tSCYjFVTQC = false;
    string pvCsacFzIyz = string("RVizCTahDFgjGmYiasISNBtSezyXyMjDDuBVAOPkpCrIzgPXCThgukuFDlmXAwvbHxfElkMuamVjvLiKwPFgabnZXjUtVUPbkRmInQHAYHNPFjFPbHFPBeMKoSKxuMADhRmiJZxpTwBlzpJQQhExJedGRGXjkZdsGNaR");
    string oVZjEzca = string("FsspTzOoXqQofmhuqIvBBRyuPuhNMMxfCUgLXghqcbrzfEHRNvwGLAbbGGLrtuZLYFocsOSXnnjalqSCg");
    string DGsmfcICRMiVBh = string("keodxdFqVzYfdQpJoknLACueSmUDOwNDHvShsGGerWzQOZVPixPtzauZQunQjxjHZBRwoeCYaJyrvnKZFpdSkseXpNfzPLOtDUmNKmcWPaymqJSToVCRssnqNlEVcLrKjhGLCeopeBKAFQvGlEAfGShlcxUpNNFZlOtzARLEroqqgmtEzzalSHDiPxYlUiNsvAH");

    for (int oQekiisBlwdEVGnz = 1557541548; oQekiisBlwdEVGnz > 0; oQekiisBlwdEVGnz--) {
        bVHcrsFGhv *= ujXFzkWJMjxNjkWa;
    }

    if (PEjsDPyqUfIMR == false) {
        for (int KLZCQWlovw = 1210442845; KLZCQWlovw > 0; KLZCQWlovw--) {
            pvCsacFzIyz = oVZjEzca;
            oVZjEzca += DGsmfcICRMiVBh;
            bnWhIFbnEsp = bnWhIFbnEsp;
            tSCYjFVTQC = PEjsDPyqUfIMR;
            tSCYjFVTQC = ! GZjrOfxVGZ;
            bnWhIFbnEsp = tSCYjFVTQC;
        }
    }

    return 2107651368;
}

string YqVyBbJqrgp::rshbFhY(string JIfKXkLVLzLfBj, bool mVBZSHPwjTbUaYk, string nuhsWXJXtv, string aivPazvdUPg)
{
    double mIPdkrGmXERcJtZE = -552135.370483061;
    int uHnHluRIbc = 381218164;
    int xdhGAhngahot = 383076479;
    double SrryHVR = 697833.3226480689;
    double AdDVaxViCkwRl = 1015706.151127776;
    bool LZlzpuQzfvJAO = true;
    double TGssFfXxHYdHJrN = -344725.93180957803;
    double cwAYJGlMizfUw = -816096.2915139983;
    string HtimaLbm = string("TyMrEBYVRmnVVeonYAzxFICbmVGdSOWzpnIOOXnfbvyYMlfMTJXmxgOzbTRddfGLnFItbCMxxVouKvZaPCkgtQIdxPIwTWORVKkiVGKiEwYCprnnFwznZGyopHhBUMkXJLgPYDMgPqKdlpOfOZzJheKOJRRiUHLWSIWfyUZideCGFalshBjNbcr");

    if (AdDVaxViCkwRl > 697833.3226480689) {
        for (int LolwBIu = 898235437; LolwBIu > 0; LolwBIu--) {
            nuhsWXJXtv = nuhsWXJXtv;
            aivPazvdUPg = nuhsWXJXtv;
        }
    }

    return HtimaLbm;
}

bool YqVyBbJqrgp::XNXSghceXhc(string TuQvsEciMMh, double afdIGenj, bool DOYPbx)
{
    int EegRDzwaqSqdICAr = -1249131450;
    bool osKbvjfW = true;
    string DYZhFvXFUyBmDIvr = string("hqeOvWWjEXzslWDWfgIgiTZlNngM");
    string FTxCzXFkiG = string("QuYGWoxSQKToWmCLvsmGljwDEbPyNqAzPLqNfvDdQvuLOVFuyCeBAsoBVwHNKMqBSTJYCcNbTORhBjTIYJvAXlUrmQpnvHKcQ");
    string sWyZqxYqJH = string("VwfwFeBEVcfBvLCCFSxLjKvhdVSDQpRHeHSOoWwWpCfEkQhQOYSatstwOkvGCOSeCxybnjtJxNsVzJHoNNHGRIHIctiFxjRtaLmRKqsFeBgxmhuFCeSNojsZfDhkjizCZUehvkEWjbPBBfeA");
    double CuamxhffL = 787400.4474872225;
    bool oXpmNwIa = true;
    int binBdlLumA = 452483083;
    double djScUmltHjQ = 519049.25633652357;
    int juEXvKakRsnD = 1821140864;

    if (afdIGenj > -465529.94498904486) {
        for (int vgpymKullVW = 443355488; vgpymKullVW > 0; vgpymKullVW--) {
            TuQvsEciMMh += DYZhFvXFUyBmDIvr;
            DOYPbx = ! oXpmNwIa;
            oXpmNwIa = DOYPbx;
            TuQvsEciMMh += TuQvsEciMMh;
            EegRDzwaqSqdICAr -= juEXvKakRsnD;
        }
    }

    for (int huenndzJ = 1631079988; huenndzJ > 0; huenndzJ--) {
        EegRDzwaqSqdICAr = binBdlLumA;
    }

    for (int gWVmnQFKZxr = 579884642; gWVmnQFKZxr > 0; gWVmnQFKZxr--) {
        CuamxhffL *= djScUmltHjQ;
        DYZhFvXFUyBmDIvr = TuQvsEciMMh;
    }

    for (int cnJTXXOuGrSpdOrK = 1800181232; cnJTXXOuGrSpdOrK > 0; cnJTXXOuGrSpdOrK--) {
        osKbvjfW = ! DOYPbx;
        CuamxhffL /= CuamxhffL;
        CuamxhffL -= afdIGenj;
    }

    if (DYZhFvXFUyBmDIvr != string("hqeOvWWjEXzslWDWfgIgiTZlNngM")) {
        for (int LeDHpnA = 1106460493; LeDHpnA > 0; LeDHpnA--) {
            osKbvjfW = DOYPbx;
            TuQvsEciMMh += sWyZqxYqJH;
        }
    }

    for (int QbtKcF = 632031197; QbtKcF > 0; QbtKcF--) {
        oXpmNwIa = osKbvjfW;
        binBdlLumA = EegRDzwaqSqdICAr;
    }

    return oXpmNwIa;
}

int YqVyBbJqrgp::PyiufDyIBppU(int KcBJwwWH)
{
    string YHajejEkmq = string("iFbVboiewVilqxuyKgttSCDPRVYkomoURnGJbBNZvoxZosqcBKYFvZRbOISGXwHWiFgyjOWxklsepDbJWSKNAqeJROGNDBdgbfrVcrgdaiZuNXmbXOV");
    int YlLWUNjDSySirhW = -1803702553;
    int dmLoKAKCTexu = -267475383;
    string wJMEYVHul = string("JRMFQExOFiixbxKftlIqiQsoUxdWxbTdiiWmVxgUxquJPjQPLHyqDytgeNizDYMaLnDCVbiVKCjskBMbQxdUfFoTPQOqqCBFUsuWTbEMfRuorWkRerHbKbhyRDEGfqEcZcLeVmAWQbsYYQUS");
    double DhcmRHuSljFpsgb = -309102.57644778764;
    int ICrttlKAqtARgGw = 1040700002;
    string XbHeqomXrlucAr = string("jcfIQuVzOTeCWPXIoYVDCKvAcWWfPvenTyrHdGfPBmEaPAfZvZaQpgEWiVyyzmEaNsprGaIrJyghAcewZdGtPddsgNRNBsqxsGXkfIziClTyqQHekwTpzSvSXRjCRxDVcoxsGQnUBlSkqDKWVQhpIHJlqFfssLheohzBofPpCLRkkoFaWKaqQuJBuktNhKHwjyPSlWYPT");
    int dtHUcXmoBFURhqR = -1561424406;
    int gSdtnZplRkmMTjZb = -516834502;

    if (gSdtnZplRkmMTjZb > -1803702553) {
        for (int FlSJPkUx = 1127559736; FlSJPkUx > 0; FlSJPkUx--) {
            gSdtnZplRkmMTjZb *= dmLoKAKCTexu;
        }
    }

    for (int CyNsBcRNUNAHpaA = 512959967; CyNsBcRNUNAHpaA > 0; CyNsBcRNUNAHpaA--) {
        KcBJwwWH -= ICrttlKAqtARgGw;
        ICrttlKAqtARgGw *= YlLWUNjDSySirhW;
        DhcmRHuSljFpsgb *= DhcmRHuSljFpsgb;
        dmLoKAKCTexu = YlLWUNjDSySirhW;
        gSdtnZplRkmMTjZb /= dtHUcXmoBFURhqR;
    }

    for (int oMdBUaRaL = 994979221; oMdBUaRaL > 0; oMdBUaRaL--) {
        YHajejEkmq += wJMEYVHul;
        ICrttlKAqtARgGw += dtHUcXmoBFURhqR;
        YlLWUNjDSySirhW = gSdtnZplRkmMTjZb;
        dmLoKAKCTexu -= YlLWUNjDSySirhW;
        KcBJwwWH -= KcBJwwWH;
    }

    if (YlLWUNjDSySirhW != -1561424406) {
        for (int OUDxW = 2007434998; OUDxW > 0; OUDxW--) {
            KcBJwwWH /= KcBJwwWH;
            ICrttlKAqtARgGw = ICrttlKAqtARgGw;
            XbHeqomXrlucAr = YHajejEkmq;
            dmLoKAKCTexu = dmLoKAKCTexu;
        }
    }

    if (ICrttlKAqtARgGw != -267475383) {
        for (int NEuyIIZEqB = 1468790126; NEuyIIZEqB > 0; NEuyIIZEqB--) {
            continue;
        }
    }

    return gSdtnZplRkmMTjZb;
}

void YqVyBbJqrgp::pVmDoMycxOZzkD(int QAmKMVhyf, int vWJWAaJehuL, double mAFmg, double HYLeCDjgRwFIauGB)
{
    bool rxJXPlqWovNobGyu = false;
    int HohaZgC = 465015304;
    bool OwazxqJdS = false;
    string rVGWznkoeTzGGvc = string("CwTBZDBOjeZvWKNvCnJcwkOBIIpgVfABmhvzZNlGUlLuAfmzFjvsgj");
    double AnsuoHt = 493971.38332754106;
    string KznEKCCDpGkmNT = string("sQILveUVPZKXkdEYlBTviNyodpCfaWObADuKLQmFUdxJiLz");
    string KDgxaJnUPvOZDFh = string("FgmHNHstqrnlOOgBgjfmSFXhXeihmEnREevdHFdrYRsqWmEsxTXLPBpRcgegTcnKdXXCrjnSviGZMeXOJLKWLDtEmoLfwfFoHiPsthrzqoeXoceMPdZQntotWJDxFiOuczzpqQlgGzmrqgIHrPCFSErOIoqLQALcGakxtSbOXQfXoSPocuzraDEHcrZMxcvJfGHNVesUOaFdIZVR");
    double mKPAQ = 489719.46680473286;
    int DquosyzzGPlJI = 1385862263;

    for (int NlHUfCKjX = 634338973; NlHUfCKjX > 0; NlHUfCKjX--) {
        KznEKCCDpGkmNT += rVGWznkoeTzGGvc;
    }

    for (int UpJVHBRp = 718106541; UpJVHBRp > 0; UpJVHBRp--) {
        mKPAQ /= HYLeCDjgRwFIauGB;
    }

    if (rVGWznkoeTzGGvc >= string("CwTBZDBOjeZvWKNvCnJcwkOBIIpgVfABmhvzZNlGUlLuAfmzFjvsgj")) {
        for (int NjPVFrGaHEkNL = 1703059013; NjPVFrGaHEkNL > 0; NjPVFrGaHEkNL--) {
            OwazxqJdS = OwazxqJdS;
            mKPAQ *= mKPAQ;
            DquosyzzGPlJI = vWJWAaJehuL;
        }
    }

    if (QAmKMVhyf == -1194591313) {
        for (int YudFk = 106478937; YudFk > 0; YudFk--) {
            mAFmg += AnsuoHt;
            rVGWznkoeTzGGvc += KznEKCCDpGkmNT;
        }
    }
}

double YqVyBbJqrgp::xDjllmmd(string qzSTrqDMPhnWTgM, int VcpbQKSNIhnBVAkv)
{
    double zIqYEIYmR = 780655.7783100628;
    int oHSZuwFcxnO = 1707404801;
    bool QcJZygpBhhK = true;
    double FLYTRRgecXvMByO = -171072.62253025745;
    bool NhgDPsIEXFNtfSY = true;

    for (int YCvLjoP = 1990256598; YCvLjoP > 0; YCvLjoP--) {
        QcJZygpBhhK = ! QcJZygpBhhK;
    }

    if (NhgDPsIEXFNtfSY == true) {
        for (int NjAeDucVODttXr = 880419720; NjAeDucVODttXr > 0; NjAeDucVODttXr--) {
            FLYTRRgecXvMByO -= FLYTRRgecXvMByO;
        }
    }

    for (int eJfFhpKrqZrrzJwY = 1350336648; eJfFhpKrqZrrzJwY > 0; eJfFhpKrqZrrzJwY--) {
        NhgDPsIEXFNtfSY = QcJZygpBhhK;
        oHSZuwFcxnO /= oHSZuwFcxnO;
        NhgDPsIEXFNtfSY = ! QcJZygpBhhK;
        qzSTrqDMPhnWTgM = qzSTrqDMPhnWTgM;
        NhgDPsIEXFNtfSY = QcJZygpBhhK;
    }

    for (int dYgRwtynMcT = 1468412268; dYgRwtynMcT > 0; dYgRwtynMcT--) {
        oHSZuwFcxnO /= VcpbQKSNIhnBVAkv;
    }

    return FLYTRRgecXvMByO;
}

double YqVyBbJqrgp::pNZOyauxy(bool tMjtrFyalApWUPqY)
{
    double MFIKhKYKuDiD = 245485.5902232954;
    int QlHyQxjcIRiBYj = -929080573;
    bool bURkeay = true;

    if (tMjtrFyalApWUPqY != true) {
        for (int jejQYLBbWwSazo = 2019621032; jejQYLBbWwSazo > 0; jejQYLBbWwSazo--) {
            tMjtrFyalApWUPqY = ! bURkeay;
            tMjtrFyalApWUPqY = tMjtrFyalApWUPqY;
        }
    }

    if (QlHyQxjcIRiBYj <= -929080573) {
        for (int DSyxltrd = 1788751680; DSyxltrd > 0; DSyxltrd--) {
            continue;
        }
    }

    return MFIKhKYKuDiD;
}

int YqVyBbJqrgp::dKBwD(bool ObTWIvKJaJqT, string oVEqnWKtktIEvrC, int XfqhzrVqEf)
{
    bool kOEGZOGSQ = true;
    string RJGPD = string("IPwOwotMtWbYtlJJCdbjjAkyHnHGDOcAQZxbaLEzrVxkxiWerDBvxYxRJAKIssheWMabYjGLsuayfklpvGiZROHDNSXXjxLRSzqYDqNBbwkUftzbPg");
    double eiPdmyJiRvzGT = -834119.3262315303;
    int qnRUfIfOe = 1272725902;
    double SBjMSCDxmOrIa = -57671.04654793103;
    int DzExTRz = -1117003148;
    bool smgBEfnyUT = true;
    double dPPFLyJ = 901872.0219971347;

    for (int uIDFSzQBzTWI = 924619806; uIDFSzQBzTWI > 0; uIDFSzQBzTWI--) {
        qnRUfIfOe -= XfqhzrVqEf;
        RJGPD = oVEqnWKtktIEvrC;
        eiPdmyJiRvzGT *= SBjMSCDxmOrIa;
    }

    for (int LDkfTzhWUqTkPob = 2017342484; LDkfTzhWUqTkPob > 0; LDkfTzhWUqTkPob--) {
        qnRUfIfOe = qnRUfIfOe;
        eiPdmyJiRvzGT /= SBjMSCDxmOrIa;
        ObTWIvKJaJqT = ! smgBEfnyUT;
        kOEGZOGSQ = ObTWIvKJaJqT;
        SBjMSCDxmOrIa /= dPPFLyJ;
    }

    for (int lTfPwsP = 1315520756; lTfPwsP > 0; lTfPwsP--) {
        continue;
    }

    if (oVEqnWKtktIEvrC >= string("IPwOwotMtWbYtlJJCdbjjAkyHnHGDOcAQZxbaLEzrVxkxiWerDBvxYxRJAKIssheWMabYjGLsuayfklpvGiZROHDNSXXjxLRSzqYDqNBbwkUftzbPg")) {
        for (int sOSGuf = 276925709; sOSGuf > 0; sOSGuf--) {
            continue;
        }
    }

    for (int PiLOOY = 1202930974; PiLOOY > 0; PiLOOY--) {
        continue;
    }

    return DzExTRz;
}

void YqVyBbJqrgp::PpuTwLxxKzwtZfO(string aDvOqJuF, string RMGkcWcoOsNpn, bool cuWcDFtaknaxPpNq)
{
    double DFuCdy = -848640.0700307983;
    string lcZhlgSTpuFo = string("aqrzwMfeJDGOFISpGosXVJRYkBfulbXvDNiCwEyVnjemqgVjDFXrCQaXhwDsxSUMhzZVoeJCmYQZQlCMamYOyNNXbbOqVhZtRrRJXGweOpAbqXJTRYbhOeCtDxuKrwaSbizLYZtxcAGUWLiyglnRvmLGjcfhjmNxmiOWyRsUFoQrZdUIwZMniNnETMusMStKvZLddFKgKxgnvxcRTAnBBaaUavLprdQni");
    bool oMrxO = true;
    bool yplyWFIOyYJSgCIT = false;
    string gkHBdw = string("NMxMRKZpvZuxuuQrpEEcbVMMPNfyeuCySkeUZkZXGuGZYsHrtDoLdNBWIlKIBkwvaKQxFdSUfZRpbROHyjeGULNZnhwhHUtOxjqmkkeCWNnxhcSqCEGDwuWunVZQlGJPKqsAoshrSPgOfTlkTVXjeQgagJCmaIxcdvFklJngGnMTHopAzkUGJYapPRRrfBebUnXdJyQjgXlzxJuPpoufO");
    bool xkSCqgNIrSf = false;

    if (xkSCqgNIrSf != true) {
        for (int pxNzGxtYqUcl = 1003226287; pxNzGxtYqUcl > 0; pxNzGxtYqUcl--) {
            yplyWFIOyYJSgCIT = cuWcDFtaknaxPpNq;
            oMrxO = cuWcDFtaknaxPpNq;
            oMrxO = yplyWFIOyYJSgCIT;
            xkSCqgNIrSf = yplyWFIOyYJSgCIT;
            xkSCqgNIrSf = ! oMrxO;
            yplyWFIOyYJSgCIT = ! cuWcDFtaknaxPpNq;
        }
    }

    for (int ahtwpRoXhwfatvuS = 33691903; ahtwpRoXhwfatvuS > 0; ahtwpRoXhwfatvuS--) {
        xkSCqgNIrSf = ! yplyWFIOyYJSgCIT;
    }

    if (xkSCqgNIrSf == false) {
        for (int kksCjFnYUzPpe = 115489918; kksCjFnYUzPpe > 0; kksCjFnYUzPpe--) {
            yplyWFIOyYJSgCIT = ! yplyWFIOyYJSgCIT;
            gkHBdw += RMGkcWcoOsNpn;
            yplyWFIOyYJSgCIT = xkSCqgNIrSf;
            lcZhlgSTpuFo = RMGkcWcoOsNpn;
            RMGkcWcoOsNpn += RMGkcWcoOsNpn;
            cuWcDFtaknaxPpNq = ! oMrxO;
        }
    }

    if (lcZhlgSTpuFo < string("NMxMRKZpvZuxuuQrpEEcbVMMPNfyeuCySkeUZkZXGuGZYsHrtDoLdNBWIlKIBkwvaKQxFdSUfZRpbROHyjeGULNZnhwhHUtOxjqmkkeCWNnxhcSqCEGDwuWunVZQlGJPKqsAoshrSPgOfTlkTVXjeQgagJCmaIxcdvFklJngGnMTHopAzkUGJYapPRRrfBebUnXdJyQjgXlzxJuPpoufO")) {
        for (int dHRJUUTZV = 2126387085; dHRJUUTZV > 0; dHRJUUTZV--) {
            RMGkcWcoOsNpn += gkHBdw;
        }
    }

    for (int GtTOwjcj = 1667929299; GtTOwjcj > 0; GtTOwjcj--) {
        xkSCqgNIrSf = ! cuWcDFtaknaxPpNq;
        oMrxO = oMrxO;
    }
}

string YqVyBbJqrgp::FfRyBqXsprNoQww(string nYinEhVhFCtMVzRv, double mzHtqFtvl, string fVWBSVXpJRIXGQ, int SpXGrS, int lXkkZognemakjxt)
{
    string mpYdvNTInEKZvdo = string("JeMxpSNierytuQWMLkabQuZHensBwDvzgztCxwYHVkPGARrKTsrjNNelCjITHovwHZfgLHyKpjKHN");
    double bvTcXUlWHxmayOR = 282016.919150936;
    int BbLQscTtOTaT = 1005243385;
    bool UgBYTvCcFkIcQOX = false;
    bool cCNUdKRCIVNQNeZ = true;
    int VcDwStWBnoK = 1726183991;
    bool csVwoCiuBIsWBNsN = false;
    bool mPPGmSOYGvfP = true;
    bool ssSlqSEaLce = false;
    int caDNFcRkOKqEHwWq = -2135864955;

    for (int wqbkWXNgsWVWOqAs = 1383202089; wqbkWXNgsWVWOqAs > 0; wqbkWXNgsWVWOqAs--) {
        ssSlqSEaLce = ssSlqSEaLce;
    }

    if (cCNUdKRCIVNQNeZ != true) {
        for (int mqwnx = 1576797533; mqwnx > 0; mqwnx--) {
            mPPGmSOYGvfP = mPPGmSOYGvfP;
            csVwoCiuBIsWBNsN = ! csVwoCiuBIsWBNsN;
            mzHtqFtvl += bvTcXUlWHxmayOR;
        }
    }

    if (fVWBSVXpJRIXGQ > string("oAvQVpNLmdgsvMulAEPXbIERyrGvgDwXrTEetMXlhWBoCymxxxyWMjdtdStqandXaXyYnIUpUSAKiJEQIfiazLGLiNTvMlPTHGaHQkBCEvREZrMxXYEbvZQIOIlrVmDkIHfOVXcHRlRjWcvytyGviHBuNvSCySHwYKRMkKpnVfpWDnVmZxpTpvTvsvhUlnjRQjQvuYitBnCukXBqirMe")) {
        for (int HfTWzOdOFfpHH = 458022881; HfTWzOdOFfpHH > 0; HfTWzOdOFfpHH--) {
            bvTcXUlWHxmayOR += mzHtqFtvl;
        }
    }

    return mpYdvNTInEKZvdo;
}

void YqVyBbJqrgp::vjkgEqWKdqPlYyo(int kfbaAfSxe, double GNkso, bool oCXunfr)
{
    double MlhdymW = 101925.53811043651;
    bool tcmTUmHN = false;
    double mIJzmXkZiOn = 440044.08324529324;
    double iVROKUeHdWddXys = 660527.8080987372;
    double UsatZQuwMMgFfN = -745840.8175462481;
    string vxMJYkzUcgxG = string("KaoqwjunaDFnHMihACIjJsIPWpvLVTPr");
    int oVcBHGylYQWmI = -1867038211;

    if (oCXunfr == true) {
        for (int foWaZRCkEIXENJD = 1822656658; foWaZRCkEIXENJD > 0; foWaZRCkEIXENJD--) {
            tcmTUmHN = oCXunfr;
            oVcBHGylYQWmI += kfbaAfSxe;
            mIJzmXkZiOn -= iVROKUeHdWddXys;
        }
    }

    for (int lCCSq = 42632964; lCCSq > 0; lCCSq--) {
        oVcBHGylYQWmI /= kfbaAfSxe;
        oVcBHGylYQWmI = kfbaAfSxe;
    }

    if (iVROKUeHdWddXys < -745840.8175462481) {
        for (int PUppTGE = 2021838445; PUppTGE > 0; PUppTGE--) {
            iVROKUeHdWddXys -= UsatZQuwMMgFfN;
        }
    }

    for (int GEMHSs = 155374818; GEMHSs > 0; GEMHSs--) {
        mIJzmXkZiOn -= MlhdymW;
        iVROKUeHdWddXys /= iVROKUeHdWddXys;
    }

    for (int aUXFvZsOLP = 1364705847; aUXFvZsOLP > 0; aUXFvZsOLP--) {
        UsatZQuwMMgFfN -= MlhdymW;
    }
}

bool YqVyBbJqrgp::poeKQVDQjmxcs(double UgLgYRuWPNhxQ, bool WeRyyjd)
{
    bool RsIlFeju = true;
    string irqTQIdl = string("qR");
    bool taHAO = true;
    int hvXhWHhgrbqR = -1188848735;
    int OffOSLGZXy = 1260442989;
    double vpHhBcgwwBazSpTH = 526677.0907271614;

    for (int HCwIIeDvb = 2147344377; HCwIIeDvb > 0; HCwIIeDvb--) {
        OffOSLGZXy *= OffOSLGZXy;
    }

    return taHAO;
}

int YqVyBbJqrgp::pXxiFbJppHLNud(string sNorDNalogTOwWk, double VcuUPz)
{
    bool IcLjjFsrVnOBmeT = false;
    string IlQEzrdzYuwQQP = string("jTZaeyGdMSSqcWupTervYYQAzpmJWxHbJReKCmXxGootcLAGPmQAmUNOTxltzqvKSwRNjFTzdMfyyHQKyohcflnrtpxsBAnEgdOjijiOMfoAkqjalePOJpcEzXUralvKIvwldQUVJLcuxjSxQpBzkjuxUgYqGYj");
    double ZatlFY = 642596.0387221343;
    int wxczzSWVOlSWUayZ = -1218864063;
    bool uAOGULpdaCCUEHR = true;
    double cBsJHa = -709232.6047331286;

    for (int cmcazyXWvRDby = 920572958; cmcazyXWvRDby > 0; cmcazyXWvRDby--) {
        VcuUPz -= ZatlFY;
        ZatlFY *= ZatlFY;
        VcuUPz *= cBsJHa;
        IcLjjFsrVnOBmeT = ! IcLjjFsrVnOBmeT;
    }

    if (VcuUPz <= -249533.26613157414) {
        for (int OeTvNv = 1687679032; OeTvNv > 0; OeTvNv--) {
            sNorDNalogTOwWk += IlQEzrdzYuwQQP;
            cBsJHa /= ZatlFY;
        }
    }

    for (int WqsrrAiUdx = 249774994; WqsrrAiUdx > 0; WqsrrAiUdx--) {
        IlQEzrdzYuwQQP = sNorDNalogTOwWk;
        cBsJHa += cBsJHa;
        IlQEzrdzYuwQQP += sNorDNalogTOwWk;
    }

    if (cBsJHa >= 642596.0387221343) {
        for (int gECuZrnkQg = 1968904822; gECuZrnkQg > 0; gECuZrnkQg--) {
            VcuUPz = ZatlFY;
        }
    }

    return wxczzSWVOlSWUayZ;
}

YqVyBbJqrgp::YqVyBbJqrgp()
{
    this->cWSYaU(false);
    this->rWjVw(string("OxhPonviBDDGytpykCLHUYoDkOaKhoshfYkzihUwfthMbRsScbFzePVNko"));
    this->YaRQkZBaLhe(-280864525, true, 68783.17187005274, -1676001653);
    this->AoCzurPJguuE(877210.560719912, 945193.9100126904, -965671.1538305164);
    this->rshbFhY(string("eXSNqRsnJaWfUDUZKFYVvzBmEvrOTPeTTGbs"), false, string("IJLUrIHmnThVQtOcTBXIkuPBXMaZOaREfzNQGIlrsPZElUoYMdYhXvnXAgGnQxHvMJZNkUMP"), string("seEGujioiUIVoKEcgkDBsXEVfWtLYOBVwvJFHqFvUclOpQCYaSTaQeKbWcjhkpfRfNBATeXsiGOWnerFxKBbpaDohpSvWcaEGaFfitbFfLocAaWUabbRdxlDvkDaKnDSDBAGAbBnkpsKUTtrcfKhtKrslkllpXvyGYyEBljBhfpOyrg"));
    this->XNXSghceXhc(string("fKdRmKwFXhmlprkaBdJlMhxGIIsPFNXBHtigEnHKXzbhNqHNqWldOiobJIDBnS"), -465529.94498904486, false);
    this->PyiufDyIBppU(-660978132);
    this->pVmDoMycxOZzkD(1242565697, -1194591313, 254998.96689374617, -184281.1186280106);
    this->xDjllmmd(string("gPvDpZrHpXuoLsZwDppKXpbwOTwPrWYuVOBXWbvvbLMMnuEGNySakBVCHbFWXxHTzSwCWYJeDQgpbqdSbTMaOVtmKWXnqooKEhSJEFgVzn"), 288039545);
    this->pNZOyauxy(true);
    this->dKBwD(true, string("CEiaDBWhToxvZwHXBKUcJkxLsMKtJPPEsUHwMcBbEDVkDcTuSD"), 1477802975);
    this->PpuTwLxxKzwtZfO(string("exrWhOhEXOptXWqfkYyHHnHVQHVuALerMJFZTVnATcaQtsEmgJbXaYQtCxgAeKVLWexZrxFtCiGbFlydFxKyQFHHiUrzjFVoiBurIAhWxsBBMI"), string("BTSJaLzDVgesddYmndujWUFUaqwzIiABABAVxBNppHKaAIKuJTugIekngTVniIifSkSfsQhhIduuAbXYkZxLodxWrgpRHuKo"), false);
    this->FfRyBqXsprNoQww(string("oAvQVpNLmdgsvMulAEPXbIERyrGvgDwXrTEetMXlhWBoCymxxxyWMjdtdStqandXaXyYnIUpUSAKiJEQIfiazLGLiNTvMlPTHGaHQkBCEvREZrMxXYEbvZQIOIlrVmDkIHfOVXcHRlRjWcvytyGviHBuNvSCySHwYKRMkKpnVfpWDnVmZxpTpvTvsvhUlnjRQjQvuYitBnCukXBqirMe"), -597990.056703156, string("syiHUGPikkqCozjaNDhkwjDSuVAhWaAOojCRNqdhXSocEjpZsmdCJQKdkRKCahBMGEKgEaRXicjHteOadBWHgdZvbevvxzIUireOVSkwItetyawEwEVwMzLlOKsclDqhXOefBfWRhjrHgTxAkLoEymYQbUZUXPBnZhqnjPRiGSRNLZBLWhIPjwYmcZGRRvDdWQQCHGdEVDvHQGEFTGDzNixsnySDzeQCkoT"), 1804550374, -529236494);
    this->vjkgEqWKdqPlYyo(-824988780, -596977.9987442496, true);
    this->poeKQVDQjmxcs(-990276.3297621299, false);
    this->pXxiFbJppHLNud(string("NwCLaLEfNHrjINGlOWGzknNMVrJrwtOwzWrFNqccIATCTTsRqzbgAPasktmGuxCMBjchSqdNdhbhIPGzmgrEdyZVzmCURUowpmqkpPYOGGXvKiNWTCmBkIpPBHJcLUaernMvFAZydEBneTFSqbQRoxuKXWIDTfzMkWnzUMTKcLdTlWZenZXMqcASjEwcDBEEWOSNABJwDCUPjrMJdnyxbCfhrcV"), -249533.26613157414);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gXSsaPeUb
{
public:
    int KIBvyHE;

    gXSsaPeUb();
    double CqASZVPZLusuTrB();
    string IEzGYeaeaLPCmh(string DWEYrWU, string kqKDiM);
    int OCFTPVz(bool cFPXmxSYicSACtXo, bool twXpXDQpqrsNA, bool svxYQOEF);
    int iLAnsUJSEiypyWj(bool CPaZaR, bool JPtfiR, string ZrRjFwnJqYawhF, int frsaSaXQYYFhe, string aakMjRaSHPK);
    double ZZobmqnbjSkF(string AjTWdMMpqYuPA, int ZwMoUtrySQOnWC, double OkRuSdTa, double lgUYFbRf, bool zfsPTFAjyutm);
protected:
    string HKdvgtFtZPVgKpCr;
    bool muimtpBRi;
    int FkNmcww;

    int FwlItFYvR(bool QFVkCOUxCWSCSFJV);
private:
    bool mobNVeMKte;
    bool XzzPGsygrMvLMz;
    int LVIwQFlhdE;
    int ooWrsRUNxQIwMi;
    bool mnmlHmRREkWEGowb;

    string YNrjfGkYdHcEhY(string dnuVIMktkDUhr, int ztLWzIQYHPzAak, bool DpfPXBhw);
};

double gXSsaPeUb::CqASZVPZLusuTrB()
{
    string ehlAXeHiYSkS = string("DQcnurYjMSmrZRxDNwbxQgjOYZWpYuTAtDgoIhyFneGTegLebODSTxzbFTzsSIMLVozjMNtZakqxdlIhhJsFkNHSOGVFdKAqqRfIAgxmvDYhMNfhrUdMojrecr");
    bool ZeIUwRIWifUWON = true;
    double TiWvMpEuADTn = -924176.3896376181;
    string JIdAGY = string("bUOQzUCVZOYmiRpsEYpoBdubTeCDkJNKhiZAbdImUdDABTtmKMAOiNgupuGhupRMEDXdRYfZdnsIokLBkODzCtmpyDJXXLFVmoUFRxMPkOrRMmPLvPtvllLPeMrYhGKasRJGWKxoMdwIfC");
    string TgVYsjrL = string("rQoOnxsIIreZytTVYRcedpUSoSjLZuncPXGMlFErMBIenckjPesXQqxNrNzfGohGxdvffgEkjGaIEbLwncJATZmAYuboQNkfXoEAVAgaxVAIYDKpTsDovPsIIcLwDIxmPMcrYKJzhmFHzFiZqxmworrzhtMdRsvLcpePGNtLtlKBLbJLuWJcIPKQRbprPBizHrmKL");
    string tSCsHtvu = string("nrjwpBpQPXQtayTuSlVdslZqOKKviHENeTLCLCmWsGmAaPyKpFkYaXPKpOgNCoAQegxMLZMbYJLMQqcKQXmuYYsCLLcYUGBlYAaGozihHrIXjpPVaidFfoVdITiYfjtrZvSzDXyIZxoyRRVwSENrwDTTifbqamaZsXnWdCtWKAmdWGxkCpBxNyCWdAsAJkxRtfBhMLQaxEiYQKWNHvazgSdsGgJbHAXLcVkioFfbpabhyelELZqkIpG");

    if (tSCsHtvu == string("rQoOnxsIIreZytTVYRcedpUSoSjLZuncPXGMlFErMBIenckjPesXQqxNrNzfGohGxdvffgEkjGaIEbLwncJATZmAYuboQNkfXoEAVAgaxVAIYDKpTsDovPsIIcLwDIxmPMcrYKJzhmFHzFiZqxmworrzhtMdRsvLcpePGNtLtlKBLbJLuWJcIPKQRbprPBizHrmKL")) {
        for (int HsSLfkDBVqc = 251585577; HsSLfkDBVqc > 0; HsSLfkDBVqc--) {
            tSCsHtvu = ehlAXeHiYSkS;
            TgVYsjrL += ehlAXeHiYSkS;
        }
    }

    if (tSCsHtvu > string("DQcnurYjMSmrZRxDNwbxQgjOYZWpYuTAtDgoIhyFneGTegLebODSTxzbFTzsSIMLVozjMNtZakqxdlIhhJsFkNHSOGVFdKAqqRfIAgxmvDYhMNfhrUdMojrecr")) {
        for (int rGSnVPauUICicS = 1556414681; rGSnVPauUICicS > 0; rGSnVPauUICicS--) {
            continue;
        }
    }

    if (JIdAGY <= string("rQoOnxsIIreZytTVYRcedpUSoSjLZuncPXGMlFErMBIenckjPesXQqxNrNzfGohGxdvffgEkjGaIEbLwncJATZmAYuboQNkfXoEAVAgaxVAIYDKpTsDovPsIIcLwDIxmPMcrYKJzhmFHzFiZqxmworrzhtMdRsvLcpePGNtLtlKBLbJLuWJcIPKQRbprPBizHrmKL")) {
        for (int HGXqFbder = 1485561918; HGXqFbder > 0; HGXqFbder--) {
            TgVYsjrL = TgVYsjrL;
            ehlAXeHiYSkS += tSCsHtvu;
            JIdAGY += ehlAXeHiYSkS;
            tSCsHtvu = ehlAXeHiYSkS;
            TgVYsjrL = TgVYsjrL;
            tSCsHtvu = TgVYsjrL;
        }
    }

    for (int HyiKkIGjub = 223962705; HyiKkIGjub > 0; HyiKkIGjub--) {
        tSCsHtvu += JIdAGY;
        ehlAXeHiYSkS += ehlAXeHiYSkS;
        tSCsHtvu += ehlAXeHiYSkS;
        tSCsHtvu += tSCsHtvu;
    }

    return TiWvMpEuADTn;
}

string gXSsaPeUb::IEzGYeaeaLPCmh(string DWEYrWU, string kqKDiM)
{
    int wMxRRFvBKzvx = 1805420117;
    double LwFhAv = -591793.827796135;
    bool gwabzNkt = false;
    int lfDkfvEDeBmzXO = -2089626186;
    double MLCvpTXbujpga = -1047332.4445674316;
    string WvHOGIhO = string("xQzNRzFPIFFvaeLSmaRaNNFZtdMCkBsrqcLQsUdFtzdvkuXIrOZpMNOodRyMPiUplHXhYtobCySMQHhXwnZCIlfMmzxmVtRlxciqaYhGkLPYvArOdteALtpRzczdQmmcbrRCGWArwENvRZbVKASGpyAglVLnoGMvVctMSMJJPTaYSFvmKlcKOTIjEsuEJYOUxEfrmbJqkdTkyvDxXRuMGplYXPcWbvdgxzBUYftJeamEuawxZqWiB");
    int vnlaOhFJgdgVVLMZ = -373360174;
    bool XKZAJcbxUftloS = true;
    string LdjveOWrdrPsy = string("fzThwJeFFXZNAKSDZFEKbOiWauMFIdDYPdbihaKBQNIUrRyrWxbhWMDBVRQbKeTQooLwZLLjgmNFPnDwhQjOVqMDlFld");

    if (DWEYrWU != string("QkyrrgIcTucOqQnwMtvPLFxeDalrFDofQbMxpeGUqHxyewgxtTIKerIrWtsQdYnVeDtuuxupFXZUaFIjlzIMidsJKYDClwyCOctObjhRWtpXHfeCzcuRekgsgtHthUQsEkHZwCDKrBTkGVZhAZtfFerqvqetIqoDVgz")) {
        for (int uyWAgT = 246787284; uyWAgT > 0; uyWAgT--) {
            DWEYrWU += DWEYrWU;
            kqKDiM = WvHOGIhO;
        }
    }

    for (int IiKfCecpoXR = 739596367; IiKfCecpoXR > 0; IiKfCecpoXR--) {
        gwabzNkt = ! XKZAJcbxUftloS;
        kqKDiM += kqKDiM;
    }

    for (int KRXsmGKSyEIYd = 1872727076; KRXsmGKSyEIYd > 0; KRXsmGKSyEIYd--) {
        kqKDiM += kqKDiM;
        lfDkfvEDeBmzXO -= lfDkfvEDeBmzXO;
    }

    if (WvHOGIhO < string("QkyrrgIcTucOqQnwMtvPLFxeDalrFDofQbMxpeGUqHxyewgxtTIKerIrWtsQdYnVeDtuuxupFXZUaFIjlzIMidsJKYDClwyCOctObjhRWtpXHfeCzcuRekgsgtHthUQsEkHZwCDKrBTkGVZhAZtfFerqvqetIqoDVgz")) {
        for (int IqvONdnnptUIx = 761711846; IqvONdnnptUIx > 0; IqvONdnnptUIx--) {
            kqKDiM = WvHOGIhO;
        }
    }

    for (int QqcReGKqyXmxEz = 950251896; QqcReGKqyXmxEz > 0; QqcReGKqyXmxEz--) {
        LdjveOWrdrPsy = kqKDiM;
        LwFhAv = LwFhAv;
    }

    return LdjveOWrdrPsy;
}

int gXSsaPeUb::OCFTPVz(bool cFPXmxSYicSACtXo, bool twXpXDQpqrsNA, bool svxYQOEF)
{
    bool gOtmPTGODcxfNNI = true;
    bool XhzeuVEJHxWSelwc = true;
    double czVAEUUzDpqQ = -130214.9486322115;
    int pVnTGusRWqPRfgZ = -1765374324;
    bool eUJsIbv = true;
    string mSHIoowkYdjgbd = string("WKyhOTTUcQLlEBWSGrVgdDkefqUngpLRzJCRPochJSuVjNgWjHycgMDozSbSmdXEICbTrgxOLYaFnSnXWrGKleVNSoywqQtztYcpEZuoJqEkAiTGbBO");

    if (XhzeuVEJHxWSelwc != true) {
        for (int QCjeQ = 1804472757; QCjeQ > 0; QCjeQ--) {
            cFPXmxSYicSACtXo = ! eUJsIbv;
            eUJsIbv = cFPXmxSYicSACtXo;
            cFPXmxSYicSACtXo = ! gOtmPTGODcxfNNI;
            XhzeuVEJHxWSelwc = ! svxYQOEF;
        }
    }

    for (int ThiyFD = 475595457; ThiyFD > 0; ThiyFD--) {
        cFPXmxSYicSACtXo = cFPXmxSYicSACtXo;
        svxYQOEF = twXpXDQpqrsNA;
    }

    if (gOtmPTGODcxfNNI == true) {
        for (int FomvzSjAmbqHdX = 700975582; FomvzSjAmbqHdX > 0; FomvzSjAmbqHdX--) {
            cFPXmxSYicSACtXo = gOtmPTGODcxfNNI;
            eUJsIbv = ! gOtmPTGODcxfNNI;
            svxYQOEF = eUJsIbv;
            XhzeuVEJHxWSelwc = cFPXmxSYicSACtXo;
        }
    }

    if (mSHIoowkYdjgbd < string("WKyhOTTUcQLlEBWSGrVgdDkefqUngpLRzJCRPochJSuVjNgWjHycgMDozSbSmdXEICbTrgxOLYaFnSnXWrGKleVNSoywqQtztYcpEZuoJqEkAiTGbBO")) {
        for (int acKXBHwqjkrSJ = 337460678; acKXBHwqjkrSJ > 0; acKXBHwqjkrSJ--) {
            twXpXDQpqrsNA = XhzeuVEJHxWSelwc;
            svxYQOEF = ! svxYQOEF;
            czVAEUUzDpqQ *= czVAEUUzDpqQ;
            XhzeuVEJHxWSelwc = ! svxYQOEF;
            twXpXDQpqrsNA = svxYQOEF;
        }
    }

    return pVnTGusRWqPRfgZ;
}

int gXSsaPeUb::iLAnsUJSEiypyWj(bool CPaZaR, bool JPtfiR, string ZrRjFwnJqYawhF, int frsaSaXQYYFhe, string aakMjRaSHPK)
{
    string VPLDTLnPLzbgRdcB = string("csFKekCIKyHMaSqYUGhlaYSKOGHPDpqttJZfEiHFKpwGjnakUcCAxBkEQYwNEEEIjWigmGhsTtCVspcfiwbhQFcUAktppvUoODCdNagBLLIEOyaVRWNuASMGvEWxVqjRemaDqHidEjYkGutBytheKy");

    for (int ShPKCCdecyq = 170365957; ShPKCCdecyq > 0; ShPKCCdecyq--) {
        aakMjRaSHPK += aakMjRaSHPK;
        VPLDTLnPLzbgRdcB += aakMjRaSHPK;
        VPLDTLnPLzbgRdcB += ZrRjFwnJqYawhF;
    }

    for (int cvwwDFjgWsyazIFe = 1219129774; cvwwDFjgWsyazIFe > 0; cvwwDFjgWsyazIFe--) {
        JPtfiR = ! CPaZaR;
        JPtfiR = JPtfiR;
        CPaZaR = CPaZaR;
    }

    if (frsaSaXQYYFhe >= -1014768546) {
        for (int EpPaEcMHqyKrnSyr = 1609640304; EpPaEcMHqyKrnSyr > 0; EpPaEcMHqyKrnSyr--) {
            aakMjRaSHPK += ZrRjFwnJqYawhF;
            ZrRjFwnJqYawhF = ZrRjFwnJqYawhF;
            CPaZaR = ! JPtfiR;
        }
    }

    if (VPLDTLnPLzbgRdcB >= string("gqfAoMkTKsIjwiKspSllnqTkHdyuucpHPWfnTxpETgAPE")) {
        for (int fRGdJEHRUmLtrm = 1478680492; fRGdJEHRUmLtrm > 0; fRGdJEHRUmLtrm--) {
            aakMjRaSHPK = aakMjRaSHPK;
        }
    }

    if (CPaZaR == false) {
        for (int EHGyYdwzY = 1160616142; EHGyYdwzY > 0; EHGyYdwzY--) {
            ZrRjFwnJqYawhF += ZrRjFwnJqYawhF;
            ZrRjFwnJqYawhF = VPLDTLnPLzbgRdcB;
            aakMjRaSHPK += aakMjRaSHPK;
            CPaZaR = ! CPaZaR;
            aakMjRaSHPK += aakMjRaSHPK;
        }
    }

    for (int nwxduhV = 1143376369; nwxduhV > 0; nwxduhV--) {
        VPLDTLnPLzbgRdcB = VPLDTLnPLzbgRdcB;
        ZrRjFwnJqYawhF = ZrRjFwnJqYawhF;
        frsaSaXQYYFhe -= frsaSaXQYYFhe;
        aakMjRaSHPK += ZrRjFwnJqYawhF;
    }

    return frsaSaXQYYFhe;
}

double gXSsaPeUb::ZZobmqnbjSkF(string AjTWdMMpqYuPA, int ZwMoUtrySQOnWC, double OkRuSdTa, double lgUYFbRf, bool zfsPTFAjyutm)
{
    int xkcPXqqfs = -1681532392;
    double LHPKlsYpN = -15878.107406512978;
    double qFhtMMhEy = 472855.2392310173;
    string kzwPHeCZwBLq = string("LLljdduaPiInxpkIfzoRUKwcYTjxqTJlJrdiThTZzIcydKWxXVXNNtxKpriuDRGFojVbqVlcbxYpNliigQqvwjOEssgVQLmSRSiUtXTJGmK");
    int PyYjOBgHEvYgkUVL = -2062778780;
    bool pEDIbbSHRsPDZoWU = true;

    for (int zzaDnuBwfDncrPNo = 1776246096; zzaDnuBwfDncrPNo > 0; zzaDnuBwfDncrPNo--) {
        qFhtMMhEy = LHPKlsYpN;
        AjTWdMMpqYuPA = kzwPHeCZwBLq;
    }

    for (int cQtiHWVsOe = 1121226206; cQtiHWVsOe > 0; cQtiHWVsOe--) {
        LHPKlsYpN /= LHPKlsYpN;
        LHPKlsYpN = LHPKlsYpN;
    }

    for (int clItDBlXiEhexb = 1253937935; clItDBlXiEhexb > 0; clItDBlXiEhexb--) {
        AjTWdMMpqYuPA += AjTWdMMpqYuPA;
    }

    for (int TeqatCUa = 1156613056; TeqatCUa > 0; TeqatCUa--) {
        pEDIbbSHRsPDZoWU = ! zfsPTFAjyutm;
    }

    for (int FDKFsx = 2123648951; FDKFsx > 0; FDKFsx--) {
        AjTWdMMpqYuPA = AjTWdMMpqYuPA;
    }

    return qFhtMMhEy;
}

int gXSsaPeUb::FwlItFYvR(bool QFVkCOUxCWSCSFJV)
{
    double geVZPdMchsV = -949653.2501788563;

    if (geVZPdMchsV <= -949653.2501788563) {
        for (int wKGnlgXR = 1389853862; wKGnlgXR > 0; wKGnlgXR--) {
            QFVkCOUxCWSCSFJV = ! QFVkCOUxCWSCSFJV;
            QFVkCOUxCWSCSFJV = QFVkCOUxCWSCSFJV;
            geVZPdMchsV /= geVZPdMchsV;
            geVZPdMchsV *= geVZPdMchsV;
            QFVkCOUxCWSCSFJV = QFVkCOUxCWSCSFJV;
            geVZPdMchsV *= geVZPdMchsV;
            geVZPdMchsV -= geVZPdMchsV;
            QFVkCOUxCWSCSFJV = ! QFVkCOUxCWSCSFJV;
        }
    }

    return -738722530;
}

string gXSsaPeUb::YNrjfGkYdHcEhY(string dnuVIMktkDUhr, int ztLWzIQYHPzAak, bool DpfPXBhw)
{
    int KkPQchiQdhMpxpKE = 706149752;

    for (int aHONw = 205740018; aHONw > 0; aHONw--) {
        DpfPXBhw = ! DpfPXBhw;
        ztLWzIQYHPzAak -= KkPQchiQdhMpxpKE;
        ztLWzIQYHPzAak /= ztLWzIQYHPzAak;
    }

    for (int paMqQnITSNcgmhL = 718536619; paMqQnITSNcgmhL > 0; paMqQnITSNcgmhL--) {
        continue;
    }

    return dnuVIMktkDUhr;
}

gXSsaPeUb::gXSsaPeUb()
{
    this->CqASZVPZLusuTrB();
    this->IEzGYeaeaLPCmh(string("QkyrrgIcTucOqQnwMtvPLFxeDalrFDofQbMxpeGUqHxyewgxtTIKerIrWtsQdYnVeDtuuxupFXZUaFIjlzIMidsJKYDClwyCOctObjhRWtpXHfeCzcuRekgsgtHthUQsEkHZwCDKrBTkGVZhAZtfFerqvqetIqoDVgz"), string("cNgKREsmirOSAKfGhEeYUXHs"));
    this->OCFTPVz(true, true, true);
    this->iLAnsUJSEiypyWj(false, false, string("gqfAoMkTKsIjwiKspSllnqTkHdyuucpHPWfnTxpETgAPE"), -1014768546, string("tdozjJsDDBCqmoLIRSBOZNoRBSehwwZUTzWiBaupHWVvoIrHyVVSzsUZxbOJpmGPyEiRjmBCXPKZBMcfpaMdGgYPdFbRMbtYoliIusebGGqESOQyxoDNKIaTFgxUcGNNGEjWhLTmdnlobBHOZqrZWzhMqNVyruBDoQEIOesEVtaYmxKAWJzQxDxruzZkhJXjFXWLaeFahUDvFfXcYsppurmehuGNURGlBPSvltiWrdRZzz"));
    this->ZZobmqnbjSkF(string("PnWW"), 805654179, 782687.2240601396, -46095.232203924425, false);
    this->FwlItFYvR(false);
    this->YNrjfGkYdHcEhY(string("xvQrJfEbxOVYwM"), -1103614139, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pjyUzhuZlsds
{
public:
    bool UJWufuHoc;
    bool iCurxBCqIdxzbobh;
    string cYDrhVaiUQ;

    pjyUzhuZlsds();
protected:
    int lwJGSUOmDZUJiHtH;

    bool SESjVLeNp(double QMpYHkOsNPLL);
private:
    int kDEePMz;
    string VJbmT;
    double MzRMjjm;
    string DaCfduRgGgxn;

    double gkvjHxL(double JMLwxtWQp, double puseHcAcv, double soXiXyFaqmwfl);
    double fgXNRpjMhva(int NhMrrzhwRZLZLP, string HMngljoPhWR, bool imluyZgvJS, bool TVVWqbpvJvABXzk);
    string pkilxsdnJybD(bool fvlxXNjbIS, string htIRFhBYT, int SoAStrq, string HEYAUvhqElGZWk, bool FPVZRCse);
    void UttRY(bool mRIVLaons, int iehoCeqCIDUAhcK, double gDDRvChT, double njbHhoHwViqS, double JktAegiQmqeBQ);
    bool YqEoUhRNjWJSLSzJ(double CNVrxbDsO, string ZUqwZC, int BJCxkj);
    double fKjgaRECkoNgJO(int aRKXyoHYDLxUNue, bool bmahGvnVkta, string kbDLylUwOW, bool eJoKPHQHAB, string AWgPRQs);
    int HuFHRCALRXESxsvf(string uipaSwP, double hEDLkRUeDYp, bool qDffsHuJfH, double hdlYtjqrUOzEos);
    bool nTVXbOuV(double aFiDuovhvyWeg, bool XfXyqQAohffjq, double Icvmu, double YqvjBTNHX, int clazOZqY);
};

bool pjyUzhuZlsds::SESjVLeNp(double QMpYHkOsNPLL)
{
    double lHbtfqIZu = 59874.73715104751;
    double xyLSlpwfWcJw = 645289.0670309126;
    bool UfraJEf = true;
    int UMAWtFgssohHXgtA = -72828825;
    int JKLXIyFgQQVUyH = 25909685;
    string lpOfWqB = string("zbQkfwhxeoSWWYueWbmqLdONerFgezqkouEtYLILUKwPAUzRlrdMJjHZVusrXyofutbibbgXmOYFisgcwALQgzeHhYXTdPbahnFsSrHOTflluhkFQCddEhttAIrvqbiAXpZBBJGxIFuIlOGaIdrWBnpkuMusiBPWtiwWpnHDVWwYLXXlEgMGrZTkWfeMvadCUWeJyAKcngXgULDdTSnyKJTSznUxAlFsJrZqCwXKhWCXWyyuZqJvmK");
    bool zzguBShnTQZbdco = false;
    double nBMBXFrhRuCGi = -820438.7113736272;
    int mnUsITuxN = 195084086;
    string cZpMgzwTzHLH = string("ZNjiuJZhhLhCKcJeReMtSBeAMNccYMhyXzpBjwaKvdbAktOqmYuPSqOrtziAnmce");

    for (int tovAeWL = 1809199289; tovAeWL > 0; tovAeWL--) {
        mnUsITuxN = mnUsITuxN;
    }

    for (int GloNFQQgrBWilUN = 1673516032; GloNFQQgrBWilUN > 0; GloNFQQgrBWilUN--) {
        nBMBXFrhRuCGi *= xyLSlpwfWcJw;
        xyLSlpwfWcJw -= QMpYHkOsNPLL;
        xyLSlpwfWcJw += QMpYHkOsNPLL;
    }

    if (nBMBXFrhRuCGi >= 645289.0670309126) {
        for (int LjZpCiNtizqcnsr = 815065430; LjZpCiNtizqcnsr > 0; LjZpCiNtizqcnsr--) {
            nBMBXFrhRuCGi *= xyLSlpwfWcJw;
        }
    }

    return zzguBShnTQZbdco;
}

double pjyUzhuZlsds::gkvjHxL(double JMLwxtWQp, double puseHcAcv, double soXiXyFaqmwfl)
{
    double KQzOYfpCdCOFdPcC = -742769.325064515;
    int QtAUlpqjsBI = -1768794464;
    bool EoZjN = false;
    bool hUpaVomESBQzLd = true;
    bool AMGgK = true;
    int kOFucB = 1535251499;
    double kBkkFwGxsPzbWWZ = 49448.614533879;
    bool IEIkGnqHKGr = true;
    string jptDRVfEsFhlvB = string("WoJngkSdlntCyFSGUqpVBZ");
    string FyLryrtKPyp = string("EXXVgyoRWyjmNPVzdEwiLPZtskDxCahtalQaXuNEAFhqM");

    if (kBkkFwGxsPzbWWZ > 206822.53329536374) {
        for (int HpvNVwPhEEUg = 183136511; HpvNVwPhEEUg > 0; HpvNVwPhEEUg--) {
            KQzOYfpCdCOFdPcC -= puseHcAcv;
            IEIkGnqHKGr = ! AMGgK;
        }
    }

    for (int zbwKyTvkv = 1219818567; zbwKyTvkv > 0; zbwKyTvkv--) {
        hUpaVomESBQzLd = ! AMGgK;
    }

    for (int QpJvzHkqFW = 769466026; QpJvzHkqFW > 0; QpJvzHkqFW--) {
        continue;
    }

    for (int yOGMNfxAGkeeeXN = 1193943904; yOGMNfxAGkeeeXN > 0; yOGMNfxAGkeeeXN--) {
        EoZjN = EoZjN;
        kBkkFwGxsPzbWWZ -= KQzOYfpCdCOFdPcC;
        JMLwxtWQp *= soXiXyFaqmwfl;
    }

    return kBkkFwGxsPzbWWZ;
}

double pjyUzhuZlsds::fgXNRpjMhva(int NhMrrzhwRZLZLP, string HMngljoPhWR, bool imluyZgvJS, bool TVVWqbpvJvABXzk)
{
    string BnYMeaPPrHXYD = string("tJnvyphwIgtbeahvSftAtpCoLmWfTjeBcTMhlxECzYxyKBnSvuNFKJOiKJcgmOcByOVvPDkmYgEzjVbyzkcLwcBStjRHpKxzVxSsToOUvLTWQdWqKrNbDNnPrfRRqFXfpRUlvtvJUUcqWBMLtHSDtOYtSsDATyDOccbDTNzdzlmEHQhgoFNUZxCHMGPLdwNSNUK");
    string ATCgMUmfQRAAJ = string("qTFGndItsMmVaiiBXQsFSOIWBtayYstNXAkAdqdddtDutRPxUGkqAffaaOQaAuFEEQtAxGbUGGcDyhEsaIlqTwIqKSDzvXpGdmblPXSbxGlzhxPNouBKXihVKLvsixUzWslyQjCaGxpjIfDwFAMrqCVEUpJejrdoHkDIxSqIsOykPrIlcoWzcAUDxjMKxyTOXPyatpgvPUNMPDIeIgyPon");
    bool wrvVAGYzotwL = true;
    string lTftrKNwUCjDDOQ = string("GNGbaRNXFitDriHptNIJUGTcwchEdmOcbYnxGUNTBWtptIpaINVGOkaYdGYKPidiYAJCDgAVMLrLUjytEFoPGZYOmZPtBQGBIZaDkTEoNxFvQaYUJsRKOtTWMGyLFggfgUPwJMruUGVjgaXNrOIfQCTLnZPrXySRqpAFCjse");
    int fCuneeXp = -449650104;
    double qbhOlpiHOFPIObm = 848808.4899014591;
    bool zgnQAAC = false;
    string hiAxShyQ = string("ssYbrkBJAeMRrKLqLsnVUGHjgrBbWBLpJBcKuohFJSNv");
    string xNPqzUbMipE = string("mOUTHotGZBrVrsoIqOqgbifqMKYpYKOYlthtuPggPrfqDqllLCnYrjAlXbRiLmVUWMpcNUimDodGqZQVZdrScVlREbEFNVtVcEQCTjsocQLseXvQdeDfWutYiqkajoJ");

    if (hiAxShyQ == string("tJnvyphwIgtbeahvSftAtpCoLmWfTjeBcTMhlxECzYxyKBnSvuNFKJOiKJcgmOcByOVvPDkmYgEzjVbyzkcLwcBStjRHpKxzVxSsToOUvLTWQdWqKrNbDNnPrfRRqFXfpRUlvtvJUUcqWBMLtHSDtOYtSsDATyDOccbDTNzdzlmEHQhgoFNUZxCHMGPLdwNSNUK")) {
        for (int YMyXVtu = 403435575; YMyXVtu > 0; YMyXVtu--) {
            hiAxShyQ += xNPqzUbMipE;
            xNPqzUbMipE += BnYMeaPPrHXYD;
            NhMrrzhwRZLZLP = fCuneeXp;
        }
    }

    if (BnYMeaPPrHXYD > string("GNGbaRNXFitDriHptNIJUGTcwchEdmOcbYnxGUNTBWtptIpaINVGOkaYdGYKPidiYAJCDgAVMLrLUjytEFoPGZYOmZPtBQGBIZaDkTEoNxFvQaYUJsRKOtTWMGyLFggfgUPwJMruUGVjgaXNrOIfQCTLnZPrXySRqpAFCjse")) {
        for (int itKRpGnbETpLjo = 851041507; itKRpGnbETpLjo > 0; itKRpGnbETpLjo--) {
            HMngljoPhWR += HMngljoPhWR;
            lTftrKNwUCjDDOQ = BnYMeaPPrHXYD;
        }
    }

    for (int RdkiUTvFSmHaDnX = 1898756290; RdkiUTvFSmHaDnX > 0; RdkiUTvFSmHaDnX--) {
        NhMrrzhwRZLZLP *= fCuneeXp;
    }

    for (int XThsKcbYJvsPCZii = 416314019; XThsKcbYJvsPCZii > 0; XThsKcbYJvsPCZii--) {
        BnYMeaPPrHXYD += hiAxShyQ;
        zgnQAAC = TVVWqbpvJvABXzk;
        zgnQAAC = ! wrvVAGYzotwL;
    }

    return qbhOlpiHOFPIObm;
}

string pjyUzhuZlsds::pkilxsdnJybD(bool fvlxXNjbIS, string htIRFhBYT, int SoAStrq, string HEYAUvhqElGZWk, bool FPVZRCse)
{
    bool BjwpIU = true;
    string wCISzxCqGIQGlEQ = string("mUhkGYDnkibZjuTSbqUKzdCSiuPHZrKvyRPcQSIMusBPdZStfaIYUmFQqgKbPNPbjpJByQttGfuHNWLrCIbxuhsZMXNHSOKZSohYQHcPOdrNItOhpRDWlIWKXELiHPzGwPLdyHclLJPylvlrxMAGv");

    if (BjwpIU == false) {
        for (int XEeUaarOb = 1948310926; XEeUaarOb > 0; XEeUaarOb--) {
            fvlxXNjbIS = fvlxXNjbIS;
            htIRFhBYT += wCISzxCqGIQGlEQ;
            htIRFhBYT = htIRFhBYT;
        }
    }

    for (int qXyILJrxoWzSdYZO = 776202857; qXyILJrxoWzSdYZO > 0; qXyILJrxoWzSdYZO--) {
        fvlxXNjbIS = ! FPVZRCse;
        FPVZRCse = ! fvlxXNjbIS;
        HEYAUvhqElGZWk = wCISzxCqGIQGlEQ;
    }

    for (int zMKTvBIGyYCXOqg = 1692534000; zMKTvBIGyYCXOqg > 0; zMKTvBIGyYCXOqg--) {
        HEYAUvhqElGZWk += HEYAUvhqElGZWk;
        FPVZRCse = ! FPVZRCse;
        FPVZRCse = FPVZRCse;
    }

    for (int ECgRWKYkWZuqF = 1083831845; ECgRWKYkWZuqF > 0; ECgRWKYkWZuqF--) {
        wCISzxCqGIQGlEQ += htIRFhBYT;
        fvlxXNjbIS = FPVZRCse;
    }

    for (int IHhmdmrIkXYHwCc = 892143039; IHhmdmrIkXYHwCc > 0; IHhmdmrIkXYHwCc--) {
        continue;
    }

    for (int MReGXtXMbuUmSMq = 138263377; MReGXtXMbuUmSMq > 0; MReGXtXMbuUmSMq--) {
        SoAStrq = SoAStrq;
        htIRFhBYT += htIRFhBYT;
        wCISzxCqGIQGlEQ += htIRFhBYT;
    }

    return wCISzxCqGIQGlEQ;
}

void pjyUzhuZlsds::UttRY(bool mRIVLaons, int iehoCeqCIDUAhcK, double gDDRvChT, double njbHhoHwViqS, double JktAegiQmqeBQ)
{
    bool HzHJmIDJwImahIx = true;
    int woYvRvX = -2092828791;
    string OQkgGbCGmQArv = string("xrAxkxrDvenjQffBXppxohXyuqVZUehEgSHkxsFcbWoGRRtpJJbrpcqLpBmMeWiavCqrgKrTJORuYTPODPbQomYLCEkQNdfmAfJcpGvTXjgAhAUTyDrUBTwmqiiWtNFgpNpZxgqHOOlEPPTsRXePHQTVvGyKvlkiS");
    bool nnWlOewa = true;

    if (iehoCeqCIDUAhcK != -1219299671) {
        for (int ZDzuA = 1047103781; ZDzuA > 0; ZDzuA--) {
            JktAegiQmqeBQ += JktAegiQmqeBQ;
        }
    }
}

bool pjyUzhuZlsds::YqEoUhRNjWJSLSzJ(double CNVrxbDsO, string ZUqwZC, int BJCxkj)
{
    int opAEcto = -1780073188;

    for (int ZbRytRVZFFKjn = 1272581533; ZbRytRVZFFKjn > 0; ZbRytRVZFFKjn--) {
        opAEcto *= BJCxkj;
        opAEcto /= opAEcto;
        opAEcto += BJCxkj;
    }

    for (int TkznjwXUAx = 1081468623; TkznjwXUAx > 0; TkznjwXUAx--) {
        BJCxkj *= opAEcto;
        opAEcto += opAEcto;
        ZUqwZC = ZUqwZC;
        opAEcto /= opAEcto;
    }

    if (BJCxkj <= -1780073188) {
        for (int hLWNXAnQFWyfqj = 1066048340; hLWNXAnQFWyfqj > 0; hLWNXAnQFWyfqj--) {
            ZUqwZC += ZUqwZC;
            opAEcto = opAEcto;
            opAEcto /= opAEcto;
        }
    }

    for (int ZIlHOgYz = 1484631963; ZIlHOgYz > 0; ZIlHOgYz--) {
        BJCxkj /= BJCxkj;
        CNVrxbDsO += CNVrxbDsO;
        opAEcto /= BJCxkj;
    }

    if (opAEcto < 173965372) {
        for (int GgmNBkOCGizIlETa = 254211958; GgmNBkOCGizIlETa > 0; GgmNBkOCGizIlETa--) {
            continue;
        }
    }

    return true;
}

double pjyUzhuZlsds::fKjgaRECkoNgJO(int aRKXyoHYDLxUNue, bool bmahGvnVkta, string kbDLylUwOW, bool eJoKPHQHAB, string AWgPRQs)
{
    string dgoacX = string("ketRoRabSvbGDClHZYLOBSmrXRBgNdfsxrwCrvBEUtNqUBUrDOLqVMQcQrSOEQGVyxcrdYAgpJhlRtoKiZHUadpDzDYbLjsMIaTFWvnVqJPMkPFbGVPvlPuCpLBiztpOPKCliRGvPwQCywezkqEhnVzhhBsGVXkOmPWDKtJkEhjAktwaIsbAIafoXHsrGYnBtvXdJRvCRLDDCndNPvNFvtvsfbBYvSFjKCrGhcJAMUEOLYutEOxsJcPabtvpn");
    bool KvdARNh = true;
    bool kuOywHbUlDp = true;
    bool doKskPPLLNl = false;
    double NGKgIx = -790183.65803901;
    int paPuW = 463598574;
    int NZzWrugVQOHZaEX = 1734840433;
    int ckLOxQ = 221561518;

    for (int mnwvYsPdwjx = 857562961; mnwvYsPdwjx > 0; mnwvYsPdwjx--) {
        NZzWrugVQOHZaEX *= aRKXyoHYDLxUNue;
        kuOywHbUlDp = doKskPPLLNl;
        kuOywHbUlDp = kuOywHbUlDp;
        NZzWrugVQOHZaEX *= ckLOxQ;
    }

    return NGKgIx;
}

int pjyUzhuZlsds::HuFHRCALRXESxsvf(string uipaSwP, double hEDLkRUeDYp, bool qDffsHuJfH, double hdlYtjqrUOzEos)
{
    string QStOrdzaXYHiWaB = string("aglnmwMLviJmPKKWsoWpqYboGoetpJQsEOkHqBdgezzGwnmNwPMEoWGEtVomCoRKiscTGzcrgPCWPwvnCDevDZBiQPDgAincOnlzeRRrZJgNdCeZINtGonFrFWyfFQyStAyLgbGbdzvkvpvuFgHQVHmPBuFiUScgALabUyeXPSrAqxdMFdrhUYuQKcyTkUwSyQdykQhMBwfEplNSTmvo");
    double Udpwa = -123936.84090296415;

    for (int LeaRIooVVyhiuVK = 929420412; LeaRIooVVyhiuVK > 0; LeaRIooVVyhiuVK--) {
        QStOrdzaXYHiWaB += uipaSwP;
        hdlYtjqrUOzEos -= hEDLkRUeDYp;
        hdlYtjqrUOzEos -= hdlYtjqrUOzEos;
        hdlYtjqrUOzEos -= hEDLkRUeDYp;
    }

    if (hdlYtjqrUOzEos <= -123936.84090296415) {
        for (int lyztileXwO = 934960630; lyztileXwO > 0; lyztileXwO--) {
            continue;
        }
    }

    for (int mDalQRORq = 502365947; mDalQRORq > 0; mDalQRORq--) {
        hdlYtjqrUOzEos = Udpwa;
        hdlYtjqrUOzEos = hdlYtjqrUOzEos;
        uipaSwP += uipaSwP;
    }

    return 686750532;
}

bool pjyUzhuZlsds::nTVXbOuV(double aFiDuovhvyWeg, bool XfXyqQAohffjq, double Icvmu, double YqvjBTNHX, int clazOZqY)
{
    bool YgcantzK = true;
    bool lQJKRs = true;

    for (int WrqxbLzd = 577138923; WrqxbLzd > 0; WrqxbLzd--) {
        continue;
    }

    for (int eBLLaniRej = 487021568; eBLLaniRej > 0; eBLLaniRej--) {
        lQJKRs = YgcantzK;
        YgcantzK = YgcantzK;
    }

    return lQJKRs;
}

pjyUzhuZlsds::pjyUzhuZlsds()
{
    this->SESjVLeNp(572409.2245934737);
    this->gkvjHxL(-501329.6489131858, -442828.57908515685, 206822.53329536374);
    this->fgXNRpjMhva(623226807, string("ValFuVBrIwCuprxHdAupMatBVQpRMYfKfChfyaqGphKRIQogrtZZQCEGSloYoqVPnzVSNYIZqeUOZfihZhFHpoGmMmybhHVVhsWMsxlZdkLTvsSeL"), true, false);
    this->pkilxsdnJybD(false, string("FxoUPEXOoHkGOBNzesEdrcFiNKUYetHUmojYBTRDNCscLDzlUkIHMnuFvbqwtngjcdgEdafscLyuIAqYJNYPjbvDkNLPELoKNhIbMbHzPLIgCjnsxMHjZaGBToCBwxUnGqGzoehNYZUbmDtEZjOpYVvhpAVojaCojywmwnJaABQGfUumuUabiGOeiWMKulTmFFRsjdllxLLQIaMwyxfbmcQkdyEqdqgoCErGhmfMGtjKoClTh"), 1015918846, string("YyShYuiuPzbcWkIcEjwqkprVtQHtUjmTgoYKRmxLlhEEQelFbSRxzirUxpPpkWsCVFPmnOjMgNlDVOzNLaExFHcl"), false);
    this->UttRY(true, -1219299671, 1037833.7922191557, 996236.7724587412, 694925.1781675929);
    this->YqEoUhRNjWJSLSzJ(62413.26001567921, string("tKQmbQFMQIjqubCHEGiEOXAHjZKvdnwomottdjEyinBmusNaDVbIZfoqhKsBDmmGeKHsOpdpEGLEcqLvcrXhhOGggEiMCbdtxKlswoCnMUBlliRzTZHugmgxKWEKVJgJ"), 173965372);
    this->fKjgaRECkoNgJO(965243078, false, string("MJbbhkCJqehFiMUrwWCbcPxcdOqHvkjBdSEAlywuqtPgaiKEJNpFDBrUGAldZOfkKUVBLcnsrIzLMKmHJxotSiZqOJEzWkcUnbfstVMpApruHLRzQNfTpDUfmQSiTBALfPIoXHmBWAvPlYsFcp"), false, string("hppDsGneCgNIxikHjkCaMPXiSKdWRQTxBTjrvKoZPoHn"));
    this->HuFHRCALRXESxsvf(string("edtLyRZAREQbPJWtNsOCTAMSJuxYQVgszjcnhTpkWpXHfGKPhAXWcuWtjvkLUirbrKmSHLnYuaMROzTtYQaXrGCgsRYLRdYuNePwRIgrIlQMevvAnggWitQIziwbtqpoTKWDJQQpMMbbkCPsXbMDMZDPZvLQQhuhZTKfFFZuCtJUYOwIYMhBcSMTOnVX"), 424852.63670568506, false, 148484.55221561622);
    this->nTVXbOuV(-645210.3789524717, true, -12496.629533230123, 41487.778018478435, 537388620);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QkFqEOJmOZWnkr
{
public:
    bool tShJbkNXgpZ;
    int PPppgQHvYkyLBqXr;
    bool iKGLMeqrNrv;
    bool TvflXFMpRPN;
    bool zrSNnnpX;

    QkFqEOJmOZWnkr();
    bool oTFtVnNsJ();
protected:
    string WhZFpMuLNsjqd;
    int eMkHADrjVvPnR;
    int IAQxyhtRlKtwH;
    int YQzJMDaR;
    double NZytznWIFV;
    bool pLzqVm;

    double gdVGsWAHXDXU(string KjGJc, double mQBMquWKPimqw, string UJeOQklqaVrCEbD);
    void KZmWwlqVZ(double CEpeQgiNSTBxa);
private:
    bool pwXzOBepsstxKUUR;
    double PcMWolDYqYF;
    string moQQF;
    int BQJAMGQbrg;
    bool NqluHjwqUu;
    double zWmZUtpEpVGZQN;

    int yMpgd(double KYzYtyPzRKFXyUE, double RMlQEgNJIVlUD, int QpztheFOxkj, bool LYaFqFSuMsn, bool JZSCdLYxIjFe);
    int DcWHbLbzmcEdMZ(int pBHpgStFA, int OBFpgV, bool PaNvjSYPMdKo);
};

bool QkFqEOJmOZWnkr::oTFtVnNsJ()
{
    bool sAqiIgdZ = true;
    string eFeDG = string("cGGRVD");
    int DUsjZAzYOMkjq = -496044056;
    bool VLjbUm = false;
    int aPVtv = -540114316;

    if (DUsjZAzYOMkjq >= -540114316) {
        for (int HonckkpnUa = 1610522126; HonckkpnUa > 0; HonckkpnUa--) {
            aPVtv += aPVtv;
            VLjbUm = VLjbUm;
        }
    }

    for (int ZQhMbDHbxw = 2143796228; ZQhMbDHbxw > 0; ZQhMbDHbxw--) {
        sAqiIgdZ = ! sAqiIgdZ;
    }

    for (int fZtSbg = 1220310658; fZtSbg > 0; fZtSbg--) {
        VLjbUm = ! VLjbUm;
        aPVtv /= aPVtv;
        sAqiIgdZ = ! VLjbUm;
        sAqiIgdZ = ! sAqiIgdZ;
    }

    for (int AJlPdGCfLpt = 1626099058; AJlPdGCfLpt > 0; AJlPdGCfLpt--) {
        sAqiIgdZ = sAqiIgdZ;
        VLjbUm = VLjbUm;
        VLjbUm = VLjbUm;
        aPVtv *= aPVtv;
    }

    for (int wOpFit = 1042391407; wOpFit > 0; wOpFit--) {
        sAqiIgdZ = sAqiIgdZ;
        DUsjZAzYOMkjq *= DUsjZAzYOMkjq;
    }

    for (int ozohuGvk = 1207171056; ozohuGvk > 0; ozohuGvk--) {
        VLjbUm = sAqiIgdZ;
        DUsjZAzYOMkjq -= aPVtv;
    }

    return VLjbUm;
}

double QkFqEOJmOZWnkr::gdVGsWAHXDXU(string KjGJc, double mQBMquWKPimqw, string UJeOQklqaVrCEbD)
{
    bool lxIzFuieng = true;
    int hdkjGKieOp = 1362837006;
    string XXjlckz = string("MCBViWsamTeKwYnWJqvbVZtGQXXXbBhANJBZImWzJzYYnEysPevNNuKSMzdjogMuLjNzyXpPNmpe");
    double HKWnzKc = -708535.3085497452;
    string iomovWNA = string("TECSSqfHRaULTbzUmrfCuUZQbbINbjrxsGUXIQGRJBGPjUGRofLXJzIbXlJChNQPIrDcMjfVxLXkLwJmDqIdzjHWBVmhbyEGtZNDqrrPaIOrkebIYVEwXAtJEXwIPNWLSMJQNhJblFPFtxNrOxUSDaKeaxqlPYCSDlbVUOAL");

    if (UJeOQklqaVrCEbD == string("TECSSqfHRaULTbzUmrfCuUZQbbINbjrxsGUXIQGRJBGPjUGRofLXJzIbXlJChNQPIrDcMjfVxLXkLwJmDqIdzjHWBVmhbyEGtZNDqrrPaIOrkebIYVEwXAtJEXwIPNWLSMJQNhJblFPFtxNrOxUSDaKeaxqlPYCSDlbVUOAL")) {
        for (int fbNQEoFvMgTCr = 814199405; fbNQEoFvMgTCr > 0; fbNQEoFvMgTCr--) {
            UJeOQklqaVrCEbD += XXjlckz;
            KjGJc = KjGJc;
        }
    }

    for (int CQlKbgaqPrnWquB = 2092541642; CQlKbgaqPrnWquB > 0; CQlKbgaqPrnWquB--) {
        continue;
    }

    for (int xpHQKeYnRHSzc = 501348390; xpHQKeYnRHSzc > 0; xpHQKeYnRHSzc--) {
        iomovWNA += XXjlckz;
    }

    if (XXjlckz < string("MCBViWsamTeKwYnWJqvbVZtGQXXXbBhANJBZImWzJzYYnEysPevNNuKSMzdjogMuLjNzyXpPNmpe")) {
        for (int WGGgTThiUDX = 1034030291; WGGgTThiUDX > 0; WGGgTThiUDX--) {
            KjGJc += UJeOQklqaVrCEbD;
            iomovWNA = KjGJc;
            iomovWNA += iomovWNA;
            mQBMquWKPimqw += mQBMquWKPimqw;
        }
    }

    return HKWnzKc;
}

void QkFqEOJmOZWnkr::KZmWwlqVZ(double CEpeQgiNSTBxa)
{
    int lGbznOtrOPnS = 774227651;

    for (int BeeGLfdYp = 1868920463; BeeGLfdYp > 0; BeeGLfdYp--) {
        lGbznOtrOPnS /= lGbznOtrOPnS;
    }

    if (CEpeQgiNSTBxa == 447128.68328136724) {
        for (int MVjJMFXPBUeH = 301755479; MVjJMFXPBUeH > 0; MVjJMFXPBUeH--) {
            lGbznOtrOPnS /= lGbznOtrOPnS;
        }
    }

    if (CEpeQgiNSTBxa >= 447128.68328136724) {
        for (int AYLNobVsTYYHPwVq = 1831137055; AYLNobVsTYYHPwVq > 0; AYLNobVsTYYHPwVq--) {
            continue;
        }
    }

    if (lGbznOtrOPnS <= 774227651) {
        for (int TARszKyPlguyAKUe = 434361030; TARszKyPlguyAKUe > 0; TARszKyPlguyAKUe--) {
            CEpeQgiNSTBxa += CEpeQgiNSTBxa;
            lGbznOtrOPnS /= lGbznOtrOPnS;
            lGbznOtrOPnS /= lGbznOtrOPnS;
            lGbznOtrOPnS = lGbznOtrOPnS;
            lGbznOtrOPnS = lGbznOtrOPnS;
        }
    }

    for (int EGYqgco = 1972623947; EGYqgco > 0; EGYqgco--) {
        CEpeQgiNSTBxa *= CEpeQgiNSTBxa;
        lGbznOtrOPnS = lGbznOtrOPnS;
        lGbznOtrOPnS = lGbznOtrOPnS;
        lGbznOtrOPnS -= lGbznOtrOPnS;
        CEpeQgiNSTBxa -= CEpeQgiNSTBxa;
    }

    for (int tSztgJTRYKb = 514999403; tSztgJTRYKb > 0; tSztgJTRYKb--) {
        CEpeQgiNSTBxa = CEpeQgiNSTBxa;
        CEpeQgiNSTBxa -= CEpeQgiNSTBxa;
    }
}

int QkFqEOJmOZWnkr::yMpgd(double KYzYtyPzRKFXyUE, double RMlQEgNJIVlUD, int QpztheFOxkj, bool LYaFqFSuMsn, bool JZSCdLYxIjFe)
{
    double ThxIXFOCOYMIKOT = 173618.9380622749;
    double YnliAVDucfEPfBtj = 87138.65898924286;
    int nMqVNOPKjT = -1217706388;
    int guWSM = 1600300270;
    bool PvFtwB = true;
    string dPoKcvhzCYnEaTkZ = string("klcVRZXxrJGIcbQjLYQTcQnHFqTmJAIGLpNuYMFoIsEYhGEICvfFSbmtgvWVvtQptZPCalhLqLLBRKVYZSYElmCnSMaJBFsnpyWoCFIsWBdJhvJqcAuHGxTFQPLkmCXQcWyHRzFiCwuclXrAfprgOIRAejePZkKSVxqVBTeURvjeECpzoEyX");
    int IgDMuwbwP = 1147181883;
    string MaJImdAEhshQ = string("HJbabZgaNQtJNTtyFtwnlOIOyDtDhbQqPjiWtJmpbtZLyixmpcLjtqucmqpxYjytBRNyvYbpqxyaVHrbUEUJDoJCgGKsZyhqzH");
    int bqbCEg = 402858647;

    for (int DRgvGFBnQZCcqJJs = 1187417839; DRgvGFBnQZCcqJJs > 0; DRgvGFBnQZCcqJJs--) {
        PvFtwB = ! PvFtwB;
        guWSM /= guWSM;
        nMqVNOPKjT /= guWSM;
        nMqVNOPKjT = guWSM;
        LYaFqFSuMsn = ! LYaFqFSuMsn;
        PvFtwB = ! PvFtwB;
    }

    for (int FXscj = 757138322; FXscj > 0; FXscj--) {
        nMqVNOPKjT /= QpztheFOxkj;
        ThxIXFOCOYMIKOT = ThxIXFOCOYMIKOT;
        LYaFqFSuMsn = JZSCdLYxIjFe;
        bqbCEg *= QpztheFOxkj;
    }

    for (int uqHzQOhuCXuxQR = 649353096; uqHzQOhuCXuxQR > 0; uqHzQOhuCXuxQR--) {
        guWSM -= bqbCEg;
        nMqVNOPKjT = QpztheFOxkj;
    }

    return bqbCEg;
}

int QkFqEOJmOZWnkr::DcWHbLbzmcEdMZ(int pBHpgStFA, int OBFpgV, bool PaNvjSYPMdKo)
{
    bool QwgANVsW = false;
    double kgjwRyLWy = 786360.432311929;
    bool uTjighp = false;
    bool fJYwJDiEcUPWQwTK = true;
    int GrqpmgOIrMgH = 669088908;
    double kZExbEOW = 273639.6126472627;
    double tHrKhA = 57029.28438475484;
    string KYSSCEuAURTunJ = string("SlyiypNumktLAbkZCtNcQPuWFfxbjVeexPdAptnHCWAbRjvopLDWfCgwQlumoyzaXbDWeLORzQrmUiiZcpFkkoZaIzETmyrmKqDYpunzvcPpbmZromerZAqLEhPxvaxjUWOlpjeoPyFaE");
    int dHKOcoEXSUDyMM = 1736097588;
    bool lYqfq = false;

    for (int rdFqJKL = 498982897; rdFqJKL > 0; rdFqJKL--) {
        continue;
    }

    return dHKOcoEXSUDyMM;
}

QkFqEOJmOZWnkr::QkFqEOJmOZWnkr()
{
    this->oTFtVnNsJ();
    this->gdVGsWAHXDXU(string("zAGjFMpTtdRPIKTMapGBBhbpivrPtCBGLWZlZpEhiZpuAYXGlqPmlySDHMYFJSNnADhxJjNaFhZBPcgAiIjuLmPaGjmLYGahURvntvKsXbkxGoMeuXUWoWAfkWOEuUvfwTOkiWcRxTXFkZxEokXwLZbQhNUZfLXBdVrqAWBd"), -929218.5149788362, string("wvFVcUvVuVGUZhckvftUrCrlcJUUNoHLDiOanQJgWtaPBaeHrehUeXdCwANpwOhUcWJQkBATzlnsJZBhuSMYknhXEJurSflqeAmJKkKySPBRButWspQQHdhHnIXwgqZPHvINbhBwBLrWmqHMLABpLtVgNAkWyGkRUvKdGdSUssNetsrVqzHjLWyMEuHbjKOMDFqFAKdSHLHQgVwStiwhaQfGDufXmt"));
    this->KZmWwlqVZ(447128.68328136724);
    this->yMpgd(-287381.5539178179, -917040.2541610139, 399821346, false, true);
    this->DcWHbLbzmcEdMZ(-117373636, -1678568631, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AyTriSTNmWbhJ
{
public:
    double GQiXjTNXNDCXG;
    double wpxcfAxElvMr;
    string MyZZri;
    string fdUrhrJUZyuoQxrT;

    AyTriSTNmWbhJ();
    bool BDcMa(int PIuRFHC, bool tDMGaADvejWcm);
    double rygpSuTm(bool rifPAMUiNGG, int LByQrjSyofkCA, double qWvrgqjQe, bool zCmrOgzgfDZ);
    double gnBnS(bool dqSjHnZPpZZ, int vwXTXcfxN, bool FtMtKskkbTOZe, bool ecNMBHfQ);
    double DAzQa(string SlwEnb, string NbWLOwOclHqkVTI, string dnZRRKxcOYzB, bool vkQTCSUwUX);
    double zloUpcUPmUzkfOqd(string LwbPfUPsHSJR, string rbIPRwUmNPqvt, double PkxhttAQER, bool KReUT, string OVbLmozNjceN);
    void BuPFSbw(int rKWlrnfEpLbe, double VZQDGHm, double NhQOJyP, bool boXsXq, int zxXlqvpFw);
    string bRbPRFUmocskTMDO(bool EMeiyN, int ZOLKYpNvIG, double MqySBjYrLMaD);
    int OZvLWaNDcvm(string NURYSxfLzgKa, string yLcXLzbs, bool ABAGWIHpXS, int VqhhGXqyRfdQVRX);
protected:
    bool ecyecpT;
    bool vWIXwEZKxOBRhqN;

    bool CSQmSbWYjpxKHrr();
    bool qFFUeopxA();
    int oXvpoEZxTWPv(double zzVtYPkdGgINVsj);
private:
    string nXoRjPtxTMpMh;
    bool SMNNKuMEDWF;
    int CaZCjotpqEkxLZlV;
    int qlxtFu;

    void BXyBlB();
    double ZWpHIy(bool ltHPuThT, int kgkwUmXwJ, double pJAUK, double hiqhdRP, string HpthDqGpMrzQJXzm);
    int lsiPSA(double YcGnDKjYob, int QxidLli, int RIWCrLLyMh, bool eKBDRmfUgIIt);
    void AeigKAXSstL(bool XOvEtVyQ, double qHDPEvBSwL, bool AcFxWcFSSpfce);
    void ykAVBuG();
    int pgTIsrETEKXenr();
};

bool AyTriSTNmWbhJ::BDcMa(int PIuRFHC, bool tDMGaADvejWcm)
{
    string beoFupHtdd = string("maPwQaPClBvWXldgZTcTFyBqRZgWwaiTuOYzqZTKkgkWYvgCzjKCLMvKBIzruGCuGDqXIGBraOtjWLKZV");
    bool hVCbxSJyRkoh = false;
    double JUMLnrDbDOozEtS = 201752.31304065583;
    bool KVbXeMFuFQ = true;

    return KVbXeMFuFQ;
}

double AyTriSTNmWbhJ::rygpSuTm(bool rifPAMUiNGG, int LByQrjSyofkCA, double qWvrgqjQe, bool zCmrOgzgfDZ)
{
    string HyesdWjUR = string("wGiAZELjfaWbu");
    double huaDO = 851084.0168966738;
    string tMstJYUUjqodd = string("xZQPftoxliZaGWUAqiIlcDkKiXFgpDZCFHplTKkwrZDgbldIBTjIgtcHHPefJNuAAPFHpchuCoKHEHMOqdHVANqezhglrEc");
    int ttFukELMWo = -180045421;
    bool XrBDjc = false;
    bool GTFoco = true;
    int iHYIupu = -1953863278;

    for (int EGnnI = 35750361; EGnnI > 0; EGnnI--) {
        LByQrjSyofkCA /= LByQrjSyofkCA;
    }

    for (int deUaeZNy = 414866052; deUaeZNy > 0; deUaeZNy--) {
        continue;
    }

    if (LByQrjSyofkCA == -1953863278) {
        for (int QxLbmptSuEBba = 1937408841; QxLbmptSuEBba > 0; QxLbmptSuEBba--) {
            GTFoco = ! XrBDjc;
        }
    }

    for (int rVXZXlhgjxiRTw = 1730722706; rVXZXlhgjxiRTw > 0; rVXZXlhgjxiRTw--) {
        rifPAMUiNGG = ! GTFoco;
        LByQrjSyofkCA /= iHYIupu;
    }

    if (rifPAMUiNGG != true) {
        for (int uwveSMBbNCOhCVT = 770077924; uwveSMBbNCOhCVT > 0; uwveSMBbNCOhCVT--) {
            continue;
        }
    }

    for (int DVonPrJOwWIOQW = 829530829; DVonPrJOwWIOQW > 0; DVonPrJOwWIOQW--) {
        continue;
    }

    return huaDO;
}

double AyTriSTNmWbhJ::gnBnS(bool dqSjHnZPpZZ, int vwXTXcfxN, bool FtMtKskkbTOZe, bool ecNMBHfQ)
{
    int PfjeioTkhlh = 241644567;

    for (int fFDhJXEajgAXYbf = 734667275; fFDhJXEajgAXYbf > 0; fFDhJXEajgAXYbf--) {
        dqSjHnZPpZZ = ! FtMtKskkbTOZe;
        ecNMBHfQ = ecNMBHfQ;
        dqSjHnZPpZZ = dqSjHnZPpZZ;
    }

    for (int TItKLGWLxECJ = 551856678; TItKLGWLxECJ > 0; TItKLGWLxECJ--) {
        dqSjHnZPpZZ = FtMtKskkbTOZe;
        FtMtKskkbTOZe = ! FtMtKskkbTOZe;
        FtMtKskkbTOZe = dqSjHnZPpZZ;
        ecNMBHfQ = dqSjHnZPpZZ;
    }

    return -397695.4844059258;
}

double AyTriSTNmWbhJ::DAzQa(string SlwEnb, string NbWLOwOclHqkVTI, string dnZRRKxcOYzB, bool vkQTCSUwUX)
{
    double PCTVnGvgheEXi = -242394.96764754254;
    string JplNCMfIbVCUDvt = string("pqCrsLVTOfLTPVifSUIqgvWHFbubANUhRKsDcxVGEVVHAYg");
    double umnLeKojZIOfDlqk = 658966.3929521078;
    bool PuvXDYCYRNVjVch = false;
    double SjomgTtMZtGZqCd = -993278.6261427797;

    for (int jEXoCGReRU = 248395771; jEXoCGReRU > 0; jEXoCGReRU--) {
        JplNCMfIbVCUDvt += SlwEnb;
    }

    if (PCTVnGvgheEXi != -242394.96764754254) {
        for (int mctLTkXnSvHVKD = 2011023855; mctLTkXnSvHVKD > 0; mctLTkXnSvHVKD--) {
            PCTVnGvgheEXi = SjomgTtMZtGZqCd;
            PCTVnGvgheEXi *= umnLeKojZIOfDlqk;
        }
    }

    return SjomgTtMZtGZqCd;
}

double AyTriSTNmWbhJ::zloUpcUPmUzkfOqd(string LwbPfUPsHSJR, string rbIPRwUmNPqvt, double PkxhttAQER, bool KReUT, string OVbLmozNjceN)
{
    double GajJsHYJ = 181164.6645513538;
    string oxyRQalZcsEL = string("qSLDSxtQTAlfSnwTcFqjSoTPOyVXWKuDGKQvRfYKcNpVNgwJQvsYGU");
    bool wkqmeYmmfEH = false;
    double umcCGBZwNzPZLo = 964748.0009161608;
    double zlSMhw = -147939.26724334375;
    bool IxZTWWwfTR = false;

    if (oxyRQalZcsEL >= string("onpchhPDQTvCuzBzPlzRHpOWrKhXPeCGHvNARhrgoUvVBugzMUWtPYUGjvhIdGCIyiPfbUskncuuZdiCOZvxAztRvUPxQHreoyGdtXXYCqxhQJgizXMwkKdbOTPjdsGEnOElJGcWLRubAgBLgPCPrgWypbzfFhQngksMnBYceYJkTgbFAAAoxlaMVpgbZuwCxSNCqtZCvtQJ")) {
        for (int sTHckNgrRyyYPSq = 816933674; sTHckNgrRyyYPSq > 0; sTHckNgrRyyYPSq--) {
            umcCGBZwNzPZLo += PkxhttAQER;
            oxyRQalZcsEL = rbIPRwUmNPqvt;
        }
    }

    for (int asHVF = 1378495873; asHVF > 0; asHVF--) {
        rbIPRwUmNPqvt = oxyRQalZcsEL;
    }

    for (int QcGkIgpSLdlsINT = 410817090; QcGkIgpSLdlsINT > 0; QcGkIgpSLdlsINT--) {
        wkqmeYmmfEH = ! KReUT;
        KReUT = ! IxZTWWwfTR;
        GajJsHYJ /= PkxhttAQER;
    }

    if (LwbPfUPsHSJR == string("qSLDSxtQTAlfSnwTcFqjSoTPOyVXWKuDGKQvRfYKcNpVNgwJQvsYGU")) {
        for (int tyBpDZVApXFG = 325754234; tyBpDZVApXFG > 0; tyBpDZVApXFG--) {
            umcCGBZwNzPZLo /= umcCGBZwNzPZLo;
            PkxhttAQER += GajJsHYJ;
        }
    }

    for (int vtHnH = 1614079228; vtHnH > 0; vtHnH--) {
        LwbPfUPsHSJR = rbIPRwUmNPqvt;
        umcCGBZwNzPZLo *= GajJsHYJ;
        LwbPfUPsHSJR += oxyRQalZcsEL;
        umcCGBZwNzPZLo += zlSMhw;
    }

    return zlSMhw;
}

void AyTriSTNmWbhJ::BuPFSbw(int rKWlrnfEpLbe, double VZQDGHm, double NhQOJyP, bool boXsXq, int zxXlqvpFw)
{
    double aUELShkYx = 1043834.5856924902;
    string FMlErJepkfpxNCso = string("SNKRPUsoSYbFafhrQmGCsVTeuoBUOdPRJUerizzYQxhkIiRHlwVCXdBUlBsmxoPGAreKdOImRZkTkbbYGuFxkaFaGlLmXMnJkilydeyvOcEUaHQyANLSeBzjcAsbInMEQEUIilskMXlxTykVdtkgSmWFbFLIfhvZCdLHQdZQNoUips");
    string iiYtMpTjVNmLOnYc = string("KAxQOwiNNuofxKfFzgbViPwzjSUCtZebExXmoFOBIVqLtQKAzcYpeuZNiftVptaWVqsPKvIvGmHQcPpZZwTpkNQRaFmXtOvFXXQTdOMAvHyGsPiusHyNSFKSwucTBeeIBuEVCcjJN");
    int BdeTwbYzyfbMO = 2001849541;
    double QwzHDD = 505853.417382701;

    for (int ZxSQMbnqihjJO = 1859615608; ZxSQMbnqihjJO > 0; ZxSQMbnqihjJO--) {
        QwzHDD += NhQOJyP;
        zxXlqvpFw = zxXlqvpFw;
    }

    for (int NOviGNfXjTkAw = 539469467; NOviGNfXjTkAw > 0; NOviGNfXjTkAw--) {
        NhQOJyP -= QwzHDD;
        rKWlrnfEpLbe = BdeTwbYzyfbMO;
        aUELShkYx += NhQOJyP;
    }
}

string AyTriSTNmWbhJ::bRbPRFUmocskTMDO(bool EMeiyN, int ZOLKYpNvIG, double MqySBjYrLMaD)
{
    double jeLHMQQ = 263753.1119828946;
    int PHaFRbmelnA = 349092679;
    bool IWdUnGhMkOzozOV = false;
    int pMqCTEwPNHN = -463606564;
    bool APlybc = false;
    double keFKbHL = 245734.9110264226;
    double MsRhEmDIQBJMaqu = -857228.6045029807;
    bool xKIVVUWBs = false;
    string rIfAdOjVVhIqG = string("TJrlXuyoWTKzTUDsPlhKjMLrgmMFcpOMVsTHEnpOTbGIlRUfdKFH");
    int sbJKpDotMQGKiKjK = 1746563381;

    return rIfAdOjVVhIqG;
}

int AyTriSTNmWbhJ::OZvLWaNDcvm(string NURYSxfLzgKa, string yLcXLzbs, bool ABAGWIHpXS, int VqhhGXqyRfdQVRX)
{
    string GywobXWXG = string("vorUfEcfSgyLaZKPyqpmOBVuwtLsQJUpsIjUZdpsUQOaDSpxHZVkWmIzoWEQbzJQpqpDTWgsvdOuvaQZxYWWSjdrFZxZfJMRmGtGNBHomjKZNHnahQkXIMzEuCasVgbANYCAsrHAFqVsSLx");
    bool HquqShsgUcjICedL = false;
    double ZpMgqVG = 987466.6114187811;
    bool DlzMUnTdnXYx = true;
    int MlQRHQNfWgUuyXAQ = 729853716;
    double JNLLTAQLFsjkebD = 875666.5533356783;

    for (int RLfLWeDrybkM = 982001599; RLfLWeDrybkM > 0; RLfLWeDrybkM--) {
        continue;
    }

    if (yLcXLzbs == string("LfJOostBQf")) {
        for (int yaWvxPXatrrTnefU = 2124904268; yaWvxPXatrrTnefU > 0; yaWvxPXatrrTnefU--) {
            DlzMUnTdnXYx = ! DlzMUnTdnXYx;
            GywobXWXG = NURYSxfLzgKa;
        }
    }

    return MlQRHQNfWgUuyXAQ;
}

bool AyTriSTNmWbhJ::CSQmSbWYjpxKHrr()
{
    int WbiMRYocUh = 2045438085;
    string nQdOtqly = string("xQscAcCoSximWUbVBuPCoCsYcYbIuNVhyubZpPSevUpJARGpvTpyyoRyrZMQcniuMhNayMzuhJXDQuodUHeeYCbmfyvzuRjjbCHgLSBNjJiHaQNFERGzoQznOZmCl");
    string XFDYayMa = string("nCPkNVglimMsvobZqPeyMEForfLjzYDrVoVVJGkEKpdxzWyxmojpCRUPMTKAlWbPPGuKQLa");
    double nUoLI = 384118.30414730986;
    double BFgtjYzknFX = 638316.0783366816;

    for (int sQybNGpkNdZU = 2115397553; sQybNGpkNdZU > 0; sQybNGpkNdZU--) {
        XFDYayMa = nQdOtqly;
        nQdOtqly += XFDYayMa;
    }

    for (int rIFdaCZZxaT = 1572231312; rIFdaCZZxaT > 0; rIFdaCZZxaT--) {
        nUoLI = nUoLI;
    }

    if (nQdOtqly <= string("nCPkNVglimMsvobZqPeyMEForfLjzYDrVoVVJGkEKpdxzWyxmojpCRUPMTKAlWbPPGuKQLa")) {
        for (int yHFkIK = 1497886900; yHFkIK > 0; yHFkIK--) {
            WbiMRYocUh -= WbiMRYocUh;
        }
    }

    for (int jycAbJan = 2007439643; jycAbJan > 0; jycAbJan--) {
        BFgtjYzknFX -= nUoLI;
        nUoLI -= nUoLI;
        nUoLI += nUoLI;
        BFgtjYzknFX /= BFgtjYzknFX;
        BFgtjYzknFX /= nUoLI;
        nUoLI += nUoLI;
    }

    if (nQdOtqly < string("nCPkNVglimMsvobZqPeyMEForfLjzYDrVoVVJGkEKpdxzWyxmojpCRUPMTKAlWbPPGuKQLa")) {
        for (int wpCkpprzzGHuna = 154484034; wpCkpprzzGHuna > 0; wpCkpprzzGHuna--) {
            continue;
        }
    }

    return false;
}

bool AyTriSTNmWbhJ::qFFUeopxA()
{
    string WhBGsGWQ = string("cOENDMBubDxrVgLnlWrYJHuDHXBBoDNoasXdPMuxhznDFFIJVBrjnZDvFLAgPhdtOxbMxaNdpjuIHvNGuFRYDrnaMrPDXkVUNrqarphPHRJtlVrAENpYiYoCcsHDePqmyQAjoaruGTqGErQXoqKWGtzxScurUNcFlSeQcNAYfHWhjjkRApOXAOPHzGhUYGLnMusWhxkTFLruoSBqWDgplAZLFeXpwanMpbHqjCoXnOnHaVyasTJUIhIOpjsWMsz");
    string SLMbSVhFbOYGdfPl = string("PZnbBTAGVKLomwQieQJFnPbEfYJAIbZxqXjBYoEOJVsqqeQJzicmHIGyXTxSCzZHdicKiwtNwJXZScqebxRHiKiecqjUcluMQnypHVMftydkdbHMTnBeKAPdspQRIEQJfoptmdjkPBIWPcvuAikjyhOsilzHbcbxHltxrOBavPbHKyjZPtuxyQGDdMrvhmeyWscSEGnZRatIHWNRrGFLXDKl");
    string rLMxDD = string("dLMwzdZIKdNyjMRqYvmzMyswvrMXUNenaCYlJHvxV");
    double RmvbdlOJqccfi = 258317.6354283197;
    double HXaizgZcQY = 925240.6701624378;

    if (rLMxDD >= string("cOENDMBubDxrVgLnlWrYJHuDHXBBoDNoasXdPMuxhznDFFIJVBrjnZDvFLAgPhdtOxbMxaNdpjuIHvNGuFRYDrnaMrPDXkVUNrqarphPHRJtlVrAENpYiYoCcsHDePqmyQAjoaruGTqGErQXoqKWGtzxScurUNcFlSeQcNAYfHWhjjkRApOXAOPHzGhUYGLnMusWhxkTFLruoSBqWDgplAZLFeXpwanMpbHqjCoXnOnHaVyasTJUIhIOpjsWMsz")) {
        for (int VwErkJeL = 1174777170; VwErkJeL > 0; VwErkJeL--) {
            SLMbSVhFbOYGdfPl += SLMbSVhFbOYGdfPl;
            rLMxDD += rLMxDD;
            RmvbdlOJqccfi = HXaizgZcQY;
            SLMbSVhFbOYGdfPl = SLMbSVhFbOYGdfPl;
            SLMbSVhFbOYGdfPl = WhBGsGWQ;
        }
    }

    return true;
}

int AyTriSTNmWbhJ::oXvpoEZxTWPv(double zzVtYPkdGgINVsj)
{
    int ujbFOMrnOdm = -1487596245;
    int sSYGQmYGxADrw = 69498710;

    for (int qEjwtTLDBHSJGXz = 2031377450; qEjwtTLDBHSJGXz > 0; qEjwtTLDBHSJGXz--) {
        zzVtYPkdGgINVsj /= zzVtYPkdGgINVsj;
        ujbFOMrnOdm *= sSYGQmYGxADrw;
        ujbFOMrnOdm += ujbFOMrnOdm;
        zzVtYPkdGgINVsj /= zzVtYPkdGgINVsj;
    }

    for (int nRAMyjsYjPk = 200150067; nRAMyjsYjPk > 0; nRAMyjsYjPk--) {
        ujbFOMrnOdm -= ujbFOMrnOdm;
        sSYGQmYGxADrw /= sSYGQmYGxADrw;
        ujbFOMrnOdm += sSYGQmYGxADrw;
        sSYGQmYGxADrw -= sSYGQmYGxADrw;
        sSYGQmYGxADrw = sSYGQmYGxADrw;
        ujbFOMrnOdm = ujbFOMrnOdm;
    }

    if (ujbFOMrnOdm != -1487596245) {
        for (int gXHlFypBQonfm = 2012410315; gXHlFypBQonfm > 0; gXHlFypBQonfm--) {
            ujbFOMrnOdm -= sSYGQmYGxADrw;
            zzVtYPkdGgINVsj = zzVtYPkdGgINVsj;
            ujbFOMrnOdm -= sSYGQmYGxADrw;
            ujbFOMrnOdm /= ujbFOMrnOdm;
            ujbFOMrnOdm += sSYGQmYGxADrw;
            ujbFOMrnOdm /= sSYGQmYGxADrw;
            sSYGQmYGxADrw /= ujbFOMrnOdm;
            sSYGQmYGxADrw /= ujbFOMrnOdm;
        }
    }

    for (int aMUTeKvlGZewdb = 1723215695; aMUTeKvlGZewdb > 0; aMUTeKvlGZewdb--) {
        zzVtYPkdGgINVsj = zzVtYPkdGgINVsj;
    }

    if (ujbFOMrnOdm >= -1487596245) {
        for (int TBAxJyZuFUlBIAH = 2057231931; TBAxJyZuFUlBIAH > 0; TBAxJyZuFUlBIAH--) {
            ujbFOMrnOdm = sSYGQmYGxADrw;
            sSYGQmYGxADrw /= ujbFOMrnOdm;
            ujbFOMrnOdm = ujbFOMrnOdm;
        }
    }

    return sSYGQmYGxADrw;
}

void AyTriSTNmWbhJ::BXyBlB()
{
    double ScZPtevEIirau = -158871.50485832972;
    bool QopmAGIAukY = true;
    bool OFdhYFUjuKx = false;
    int pQzTAGoGUOSy = 707824185;
    bool wXvuFlJETS = false;
    double VqbmDVsfjNfL = -1017400.0092161746;
    int hhJEDKehVlaJ = 86277659;
    double qdTOlQKOmjKWdVSd = -190733.5594505183;

    for (int AiYLXDiPX = 249841360; AiYLXDiPX > 0; AiYLXDiPX--) {
        hhJEDKehVlaJ /= pQzTAGoGUOSy;
        VqbmDVsfjNfL = qdTOlQKOmjKWdVSd;
        QopmAGIAukY = ! wXvuFlJETS;
        OFdhYFUjuKx = ! wXvuFlJETS;
    }

    for (int bHUZcKUNbKytOpUm = 2078163340; bHUZcKUNbKytOpUm > 0; bHUZcKUNbKytOpUm--) {
        qdTOlQKOmjKWdVSd *= ScZPtevEIirau;
        wXvuFlJETS = QopmAGIAukY;
        VqbmDVsfjNfL = VqbmDVsfjNfL;
        ScZPtevEIirau = VqbmDVsfjNfL;
        OFdhYFUjuKx = OFdhYFUjuKx;
    }

    for (int fHytAyVqlVK = 314723938; fHytAyVqlVK > 0; fHytAyVqlVK--) {
        hhJEDKehVlaJ *= pQzTAGoGUOSy;
        OFdhYFUjuKx = wXvuFlJETS;
    }

    for (int taYtWzlMpMOgTdFq = 1152508772; taYtWzlMpMOgTdFq > 0; taYtWzlMpMOgTdFq--) {
        wXvuFlJETS = ! wXvuFlJETS;
        wXvuFlJETS = ! OFdhYFUjuKx;
        ScZPtevEIirau -= VqbmDVsfjNfL;
        OFdhYFUjuKx = ! wXvuFlJETS;
    }

    for (int YwMBMyAzfn = 937254345; YwMBMyAzfn > 0; YwMBMyAzfn--) {
        VqbmDVsfjNfL = qdTOlQKOmjKWdVSd;
        QopmAGIAukY = ! wXvuFlJETS;
        QopmAGIAukY = ! QopmAGIAukY;
        OFdhYFUjuKx = ! OFdhYFUjuKx;
        pQzTAGoGUOSy /= pQzTAGoGUOSy;
    }

    for (int wTKBAAsmCkCxAL = 2077725926; wTKBAAsmCkCxAL > 0; wTKBAAsmCkCxAL--) {
        pQzTAGoGUOSy *= pQzTAGoGUOSy;
    }
}

double AyTriSTNmWbhJ::ZWpHIy(bool ltHPuThT, int kgkwUmXwJ, double pJAUK, double hiqhdRP, string HpthDqGpMrzQJXzm)
{
    double MCNAUMSNkSv = -21166.02645656659;
    bool BhGaLQanajeJ = false;
    string BeRuOc = string("bnteypFUejlTlEXWOtbkhhJDQBHlStiWnLtrmNPKtvPgrVmTwLPMxebhJBnjOFUndnlkIQElucevckyCiPHjjkyjSuOhpaPUUExZAbiuqNTsCbIEsUwexTAhvNqFtYZRcRsoefxEjqRomvyNQczApmqTNkOjWZQltZnrhpQgjcqCVxvSXecNGAWAWMzCyFYpUO");
    double koFBZdsJDXLDndJs = 294328.0462950478;
    int xAUpOfSA = -1766195189;
    double KkspslmmyteRoyXL = 469283.7491959243;
    int VuVychQaZ = 169196783;
    int sOLhBEIJI = 2069222787;

    if (pJAUK == -21166.02645656659) {
        for (int tPfvLiRRvuh = 1713691519; tPfvLiRRvuh > 0; tPfvLiRRvuh--) {
            BhGaLQanajeJ = BhGaLQanajeJ;
            pJAUK *= MCNAUMSNkSv;
            hiqhdRP -= koFBZdsJDXLDndJs;
        }
    }

    return KkspslmmyteRoyXL;
}

int AyTriSTNmWbhJ::lsiPSA(double YcGnDKjYob, int QxidLli, int RIWCrLLyMh, bool eKBDRmfUgIIt)
{
    string brPjreHPnOBHL = string("IYnpztJTfWRIRVUWSgQJWgdEaEcPptwXpBDSi");
    int NOJCJgPBeUtvEpD = 449756864;
    string TVcHknqqzmMKLa = string("PcQwXDePqDUTnlvupcYNQixKZwbaGRNKPMGRxKtpKOigSaWmvawpvYjOrBFcJqPFiAZSidGYwdpyyhBTMSddfgFDREENAiziiWBytAqrJSBsWuphlTJRsznTlBTsMlTysMqbRZukfwzHGKKURMu");
    string fCTbAEbRONurMM = string("CfGPgZJcbtiwcLAATcAVzhhVdjfEMBAKQMSxYOWWKRhPmPAPbjMqLabHHuJxMkHvMLzcHvXJRcAatKTKNqizAvAKmbzZnHhTGEjFAimSMVVVzJ");

    for (int ChdEHGIKePr = 265108675; ChdEHGIKePr > 0; ChdEHGIKePr--) {
        fCTbAEbRONurMM = TVcHknqqzmMKLa;
        NOJCJgPBeUtvEpD *= NOJCJgPBeUtvEpD;
    }

    if (RIWCrLLyMh == -120791867) {
        for (int EuVcKT = 126374337; EuVcKT > 0; EuVcKT--) {
            RIWCrLLyMh -= NOJCJgPBeUtvEpD;
            fCTbAEbRONurMM += brPjreHPnOBHL;
            RIWCrLLyMh = QxidLli;
            NOJCJgPBeUtvEpD *= QxidLli;
            NOJCJgPBeUtvEpD /= NOJCJgPBeUtvEpD;
            fCTbAEbRONurMM += fCTbAEbRONurMM;
            TVcHknqqzmMKLa += fCTbAEbRONurMM;
        }
    }

    if (QxidLli >= -120791867) {
        for (int KwZqmdMlo = 1199089629; KwZqmdMlo > 0; KwZqmdMlo--) {
            NOJCJgPBeUtvEpD -= NOJCJgPBeUtvEpD;
            RIWCrLLyMh += NOJCJgPBeUtvEpD;
            fCTbAEbRONurMM += brPjreHPnOBHL;
            QxidLli /= QxidLli;
        }
    }

    return NOJCJgPBeUtvEpD;
}

void AyTriSTNmWbhJ::AeigKAXSstL(bool XOvEtVyQ, double qHDPEvBSwL, bool AcFxWcFSSpfce)
{
    bool LQQoMckAYjbe = true;
    int cdSGlGSPybFuFc = 363300736;
    bool OzhZCSVrLwEBnSWb = true;
    string mOwEmZpWTwpK = string("AEJOikPSzEPzaYxvyWRkqsoMVWIwIGNsnrAkiNJJKBHMblYbOjEYhCRWTOnfaWmToE");
    double EcAleUSfisMN = -896917.1578234611;
    double sKSNOeIiJ = -915354.9347055256;
    bool TqbsQUsXeZ = true;
    bool bzJZZGDALBxrSd = false;
    double wREjAusCAO = -937171.8543893985;
    string aIfDTfaz = string("FKKzcqFyMLxPmJHNmP");

    if (LQQoMckAYjbe != false) {
        for (int pccpzWG = 1238999331; pccpzWG > 0; pccpzWG--) {
            OzhZCSVrLwEBnSWb = ! LQQoMckAYjbe;
            bzJZZGDALBxrSd = ! TqbsQUsXeZ;
        }
    }
}

void AyTriSTNmWbhJ::ykAVBuG()
{
    double lBlfGKLxE = 1045865.735545998;
    bool XGQyvOT = true;

    if (XGQyvOT == true) {
        for (int vJSiKuKmTOSeQc = 1297975543; vJSiKuKmTOSeQc > 0; vJSiKuKmTOSeQc--) {
            lBlfGKLxE /= lBlfGKLxE;
            lBlfGKLxE -= lBlfGKLxE;
            XGQyvOT = XGQyvOT;
        }
    }

    for (int dEJbijyRpFEpNKrF = 1253264384; dEJbijyRpFEpNKrF > 0; dEJbijyRpFEpNKrF--) {
        lBlfGKLxE -= lBlfGKLxE;
        XGQyvOT = XGQyvOT;
        XGQyvOT = ! XGQyvOT;
        XGQyvOT = XGQyvOT;
    }
}

int AyTriSTNmWbhJ::pgTIsrETEKXenr()
{
    double mgVgznSaCsrOB = -985973.483541833;
    double fxVXWFVJ = -89843.41241217744;
    double XxdASTUOAhISP = 543810.8131184086;
    bool LAyyNX = false;
    int wvVkZnGSKbfizEXN = 1331374671;
    int OGcEkbwfb = -1691355848;
    string oWDQukNGOgk = string("TYESEEFtaQBNcKkfPozJoPctrIrwKBJOLIOqVtfwVDoUqEWBq");

    for (int yTYOZ = 830405589; yTYOZ > 0; yTYOZ--) {
        fxVXWFVJ = fxVXWFVJ;
    }

    if (wvVkZnGSKbfizEXN <= -1691355848) {
        for (int pMWqSEjcjpYYh = 74190522; pMWqSEjcjpYYh > 0; pMWqSEjcjpYYh--) {
            continue;
        }
    }

    for (int FmROoVzTSVS = 1751033018; FmROoVzTSVS > 0; FmROoVzTSVS--) {
        continue;
    }

    return OGcEkbwfb;
}

AyTriSTNmWbhJ::AyTriSTNmWbhJ()
{
    this->BDcMa(818201143, true);
    this->rygpSuTm(false, 388016533, 87536.35312468886, true);
    this->gnBnS(false, -736742307, true, true);
    this->DAzQa(string("EVIWAnSbrEUDfAGhBPJHvbgxRGBNrClVfwxajKWSAjYoDGqsCRRKzKfUEfqFghPNWgmBTFcRdCcWIIQLLBfrmtBIWZfCxCcHWPQKVoSZnvITTiUhlqlQigpWEGNPnvgVbMoMcoBqdZyTfIdcMvaLQkSWWQioSsrxIWtEouchqBFv"), string("oAyKJcUewLNSlBeIgrnocmeyIAkKkaIxIotCvZQippiwGPuIOdaFUlFAtUqCGDDnRiQFQUmhJUZqVATZRBawoNkHPAmtaYmdZFCQGYUMoXAoyQKpXZbGrfXJnKQgmiXVgfkecuzjispzPkeCpvLCTz"), string("VjxRlxKcRLzqmOhUDRyXocYalSnSbPwtiopUkBoicQiheTVtSZijcFVaCyaIgeTGHXnAaWLTR"), true);
    this->zloUpcUPmUzkfOqd(string("ziWixjBZNEdVcERadpJsnnbAiTpDPoMHkQCoGoyqDJmguqKIyrloOJKCaTjRgsXoUjqaegMoNbzionqRytTnYUxszWqQqRgKYpNWekLolCTCQoxxGtrsPdpqjaczJIrvJTCjaJTZMrzEMqFnuEhTWjMiPifIUfShrlaEAFLdBuyvkOkWBHhQCFiRqTtbKOEXVEGFAOjdsmLmiNljJwSXbLDpRCaTCPbdVMeVipM"), string("onpchhPDQTvCuzBzPlzRHpOWrKhXPeCGHvNARhrgoUvVBugzMUWtPYUGjvhIdGCIyiPfbUskncuuZdiCOZvxAztRvUPxQHreoyGdtXXYCqxhQJgizXMwkKdbOTPjdsGEnOElJGcWLRubAgBLgPCPrgWypbzfFhQngksMnBYceYJkTgbFAAAoxlaMVpgbZuwCxSNCqtZCvtQJ"), -429802.72891453374, false, string("BdpDrEBUWVEkVCuVgmIRuiyxHcnLIWVKyaEWfcCkJnpVHfSm"));
    this->BuPFSbw(1048402486, -61398.53321808865, 61079.50517093785, true, 1002391412);
    this->bRbPRFUmocskTMDO(true, 1689689970, 452553.60000062827);
    this->OZvLWaNDcvm(string("ErHgiqnuKftCiaSosRmfcEpxmilyBMIzdbtyftlIQegazWkVrJwXOzWmPdkEPfblLgXOaIDilkFcrvOIcuQjkFBrjhrTtIFacTuhEJTaazmUgHVSRSYkcUmEbEVRIZCzdifpLmQsYjEWaQDlawYPwltv"), string("LfJOostBQf"), false, 1524922425);
    this->CSQmSbWYjpxKHrr();
    this->qFFUeopxA();
    this->oXvpoEZxTWPv(446380.2776811453);
    this->BXyBlB();
    this->ZWpHIy(true, -1268021, 982348.6738717289, -973448.6031870993, string("QaeaTOAVnCeHqBzjNGpyKZlsaYXFrKnxAMVGI"));
    this->lsiPSA(960831.250320492, 2131999906, -120791867, false);
    this->AeigKAXSstL(true, 505094.5444493218, true);
    this->ykAVBuG();
    this->pgTIsrETEKXenr();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eWAiIOZGyKxX
{
public:
    int vpVwdYUJEOwlI;
    string BKJbnggzutP;
    double KnFigoW;
    double MDLHHSFo;

    eWAiIOZGyKxX();
    bool jZWUC();
protected:
    string tscMACfqHt;
    bool fZqnBUAGZXtAwa;
    string ZTHfncP;
    double nEFbHKccybq;
    string KGAURFItdGbTVt;
    bool wDqmtuYQC;

private:
    int ztGPoy;
    bool AnfrocoFLOTWU;
    bool ELOyLn;
    bool cVeOpp;
    string ejXfQXYshmJt;
    double iUvhscbplbXkw;

    double wcdHpWcAtwUKB(double aMbVS, double LYRTPfBo, bool rptTfNZZwaOtnUVI);
};

bool eWAiIOZGyKxX::jZWUC()
{
    int itkoi = -897282461;
    int vdWJnWrSXCusV = -1645095252;
    string KRSab = string("BGaRfYUnEqUdnUYSviJnDwqRFvxPyUtMHAWYFtBCOTxpGQFOiQpmYtdKPLRDUaeNlhJtjGcywSsNRTupEoLbjXJgySBWinwBQoEEudkFmhbWstaRvsSlijMoJPZWhEiIOPHLxOhksgrWjEjRUiskbrwmuUNuLAnOFmURMYtwwNvdIEHnlLsbUvsobyXnlqoghQcXJiiwYTVoQSDdViotQsKynhKLPIAJJrbVTVGhuLTMbVfzwqoifhqrpVdfhx");
    int GxUklkOQewMkJQKV = 923205608;

    if (itkoi < -1645095252) {
        for (int WCWwmHzxVivP = 1377954109; WCWwmHzxVivP > 0; WCWwmHzxVivP--) {
            itkoi *= GxUklkOQewMkJQKV;
            vdWJnWrSXCusV += GxUklkOQewMkJQKV;
            vdWJnWrSXCusV += GxUklkOQewMkJQKV;
            GxUklkOQewMkJQKV = vdWJnWrSXCusV;
            KRSab = KRSab;
            itkoi += GxUklkOQewMkJQKV;
            itkoi -= vdWJnWrSXCusV;
        }
    }

    if (vdWJnWrSXCusV >= -897282461) {
        for (int DfHXlyJl = 1753678985; DfHXlyJl > 0; DfHXlyJl--) {
            continue;
        }
    }

    return true;
}

double eWAiIOZGyKxX::wcdHpWcAtwUKB(double aMbVS, double LYRTPfBo, bool rptTfNZZwaOtnUVI)
{
    int BvdDRPiAKivLawK = -1285209193;
    double ImIrhfK = 54745.65715238197;
    int NBSXBIsUejFOAe = 907891771;
    bool fmDUwgkqFEymh = true;
    string mwZnn = string("QZCUroayBJwnnEbEJTHTXBcRWAAoiLmzeNRRZFDyvzZvdgpmWgVLoRqJZrOsohhCerGBSorp");
    double NpSNNJm = 764181.5151803739;
    int hHIkuxkzyHrL = -1098911949;
    int uxCSzFYYPQRv = -2011972601;

    for (int zNhQJAF = 713301919; zNhQJAF > 0; zNhQJAF--) {
        aMbVS /= LYRTPfBo;
    }

    for (int oLchzhX = 409577274; oLchzhX > 0; oLchzhX--) {
        BvdDRPiAKivLawK -= BvdDRPiAKivLawK;
        uxCSzFYYPQRv += BvdDRPiAKivLawK;
        BvdDRPiAKivLawK = uxCSzFYYPQRv;
    }

    return NpSNNJm;
}

eWAiIOZGyKxX::eWAiIOZGyKxX()
{
    this->jZWUC();
    this->wcdHpWcAtwUKB(22779.748791259004, -456460.1853617399, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NMAlRqwiCGl
{
public:
    double TyplRbllxB;
    double qNWtPnmYfl;
    double wQXwtJxGz;
    int wJdyDJdiipqMRb;

    NMAlRqwiCGl();
    void eiPqab(bool NLHTlTtBc, int tADBj);
    int GfedYuZd(string WtmaEjk, int kMkTlhkmSbDLIwVz, string CeWocxDwtdZho, int GsPlHWpA, bool dJDEjHE);
    void saTBufLGLu(int nKnoGFaDr, int fEwpYuiEcT, bool wwTSefTylRo);
    string rVEULKTZnQec(double DmbHVNrRDtzloy);
    void vleFQJjpNejBNve(string eOgKCrh);
    string kARQAvcv(bool mlvvXHRPmrJsE, string uRTJsuowef, double omEjSFkBBXcq);
    double WQWRuC(double UUQVB, double QhCpO, bool hOCbP);
    bool pBAgwX(string BvGqZ, string LPiCzrqs, double ByZxWWPqIdrSfQP);
protected:
    double AlmjNb;
    int DpSuedvEQFoVwBHB;
    bool hbvfV;
    double bJcsvQJahmsU;

private:
    string ujomqIBFlHPw;
    double haKDJkPMpXrQv;
    int brShoCmQMLipXr;
    string OBuvUjHzjym;
    int awVBazvbnzEX;

    double olXSIcwncCz();
    double gvHZKsBESB(bool Zelfxj, bool FLGplMyS, int xORuqWWxqa, double HHkQtUPzKrEXX, int PKcEv);
    bool XwAWRgGrhh();
    bool fIklFFhLC(double cOHJITGdV, bool iBRGbWhOeqNWOjA, string OuTIr, double mAuXNTJTFyzyBShW, double pluTO);
};

void NMAlRqwiCGl::eiPqab(bool NLHTlTtBc, int tADBj)
{
    string iPzicpxC = string("lzuwFCk");

    for (int ekUCLbEtjttU = 768986837; ekUCLbEtjttU > 0; ekUCLbEtjttU--) {
        NLHTlTtBc = NLHTlTtBc;
        tADBj -= tADBj;
    }

    for (int vHxsawnPBY = 339304065; vHxsawnPBY > 0; vHxsawnPBY--) {
        tADBj -= tADBj;
        NLHTlTtBc = ! NLHTlTtBc;
    }
}

int NMAlRqwiCGl::GfedYuZd(string WtmaEjk, int kMkTlhkmSbDLIwVz, string CeWocxDwtdZho, int GsPlHWpA, bool dJDEjHE)
{
    double vOxZRPPZ = 822934.8414830813;
    bool RCrewzhxr = true;

    for (int YZbdhpCmiufomRsv = 490792921; YZbdhpCmiufomRsv > 0; YZbdhpCmiufomRsv--) {
        vOxZRPPZ *= vOxZRPPZ;
        CeWocxDwtdZho += CeWocxDwtdZho;
        CeWocxDwtdZho = CeWocxDwtdZho;
        WtmaEjk = CeWocxDwtdZho;
        dJDEjHE = RCrewzhxr;
    }

    for (int kUfzfFshPi = 896385456; kUfzfFshPi > 0; kUfzfFshPi--) {
        kMkTlhkmSbDLIwVz -= GsPlHWpA;
        kMkTlhkmSbDLIwVz += kMkTlhkmSbDLIwVz;
    }

    for (int uwNxvVjGbFaVbI = 1869378557; uwNxvVjGbFaVbI > 0; uwNxvVjGbFaVbI--) {
        kMkTlhkmSbDLIwVz *= GsPlHWpA;
        CeWocxDwtdZho += WtmaEjk;
        RCrewzhxr = RCrewzhxr;
        WtmaEjk = CeWocxDwtdZho;
        dJDEjHE = dJDEjHE;
    }

    for (int FUQNmdM = 283435602; FUQNmdM > 0; FUQNmdM--) {
        continue;
    }

    return GsPlHWpA;
}

void NMAlRqwiCGl::saTBufLGLu(int nKnoGFaDr, int fEwpYuiEcT, bool wwTSefTylRo)
{
    double fIKexIyj = -616498.6160725781;
    string rOxdeAOpkewicp = string("zyNazgcCAHdYezFZNTbVidChOydNQoZekHWbDkKhgzdjtIvsWJkmCMYAYiBjMGihMYXKgnmmObNSeGrwbINBoCFlFCpoYVJJwkkyfkxMpfXVrKqrTaDzndefKqmcMYKtfOdihsuMuMjHEpxjkhUfKbfEMYrYBmichrITKKddTLlXEjOgzvyRkVXzzSJUwVMhEopfuuajeueWIDbPjMZXsrYGJPecWYNjdEkWMiiNMfKfGkLllAdAjuDnW");
    double mlpoNaOZGOF = 923854.9066166953;
    bool mZHOotaQZ = false;
    bool nTgdFGI = false;
    int IEWURGrSi = 111214131;

    for (int mAATINPAC = 2073644164; mAATINPAC > 0; mAATINPAC--) {
        continue;
    }
}

string NMAlRqwiCGl::rVEULKTZnQec(double DmbHVNrRDtzloy)
{
    int KXVFNu = -1760941033;
    bool PkfPWoLXEEEAc = true;

    for (int JGCnsbmJFNQt = 378551093; JGCnsbmJFNQt > 0; JGCnsbmJFNQt--) {
        PkfPWoLXEEEAc = ! PkfPWoLXEEEAc;
        DmbHVNrRDtzloy *= DmbHVNrRDtzloy;
    }

    for (int aAANAWIgcTMVYctk = 368195925; aAANAWIgcTMVYctk > 0; aAANAWIgcTMVYctk--) {
        DmbHVNrRDtzloy -= DmbHVNrRDtzloy;
        KXVFNu = KXVFNu;
    }

    return string("nTDVpbRqfhfWnPwmGRnStzIQDQPwrnvohzHAkpixigLuBBqxJt");
}

void NMAlRqwiCGl::vleFQJjpNejBNve(string eOgKCrh)
{
    double eYStJHiEupao = 548750.9167011931;
    double znhtKLdBeqgTQHmR = -137364.63655256596;
    int NlONHySnrGD = 257590144;
    string zLeGuGgRj = string("lDuZpjhiIyfaZxtEZhCZHabINJxhagqCSXWFJFdwkTVYNzfoZmTTqKkhWfwQTQeAvdGoy");
    bool cyMMjKf = false;
    bool LYNNiozQiR = true;
    double BqjRtdciJJW = -959567.9359698478;

    for (int VQopcpxk = 117902822; VQopcpxk > 0; VQopcpxk--) {
        eYStJHiEupao += znhtKLdBeqgTQHmR;
        LYNNiozQiR = cyMMjKf;
    }

    for (int ZWEpGOKHRk = 421809302; ZWEpGOKHRk > 0; ZWEpGOKHRk--) {
        continue;
    }
}

string NMAlRqwiCGl::kARQAvcv(bool mlvvXHRPmrJsE, string uRTJsuowef, double omEjSFkBBXcq)
{
    int fIvrXRV = 2106676640;
    string xILAWnzkl = string("SBKpMJiGQAptyfFCitMOUvIDIVDsssovclTAHQseEuVOfjtohxHaDWrbQeqrmCdIUAtgyzlzjUqQAEDiLfeYnwBxMnhQsptJSUyboZGMcSVUEDhIGOFzqTrHCWsJQIpBNpuJDGoHTGzPQksmaYojfxFKKOBwhjLwfybxRrqMCYkEJOoSAzWsqqcqgIOYtfxkJEKaGkXZalAHQwpAKxbFrvgTpBWxmcYkkayctZiYRmTSUoiYnlptTZmXHzE");
    bool BqVjr = false;
    int IdowUvVrX = 1911940843;
    double iJvMaNLKBnUnePjR = 723866.3097966479;
    bool sltBVNyWuU = false;

    for (int IINLIHB = 277697546; IINLIHB > 0; IINLIHB--) {
        BqVjr = mlvvXHRPmrJsE;
    }

    return xILAWnzkl;
}

double NMAlRqwiCGl::WQWRuC(double UUQVB, double QhCpO, bool hOCbP)
{
    bool zATJoo = false;

    if (UUQVB != -736992.7974330585) {
        for (int zHRMBRpCn = 1600416571; zHRMBRpCn > 0; zHRMBRpCn--) {
            QhCpO = QhCpO;
            QhCpO = QhCpO;
            zATJoo = ! hOCbP;
            UUQVB += UUQVB;
        }
    }

    for (int jpskkhBOwG = 922519482; jpskkhBOwG > 0; jpskkhBOwG--) {
        UUQVB *= QhCpO;
        hOCbP = hOCbP;
    }

    return QhCpO;
}

bool NMAlRqwiCGl::pBAgwX(string BvGqZ, string LPiCzrqs, double ByZxWWPqIdrSfQP)
{
    double OWThEUzDIKzm = -462950.8917742235;
    string Viwxi = string("ZTUAPbYJuNugpvzvnNYPuGsnAVQucKQxsqeCMabjIgEYbGNedngRHHgzDLXQizRljoJQcXcbGSZYDUwXUqdlzHlDkgKUkDfAASVuCTiOGGKVDZylepMSGKXngVhhBxLXsSmgtYJcPPgqsYSxIvNphnolQhrvuXFQqxqBrLGcDiBIwiUelKqxhryjoYFGIugryazQJFRPVYvsbFBZLISoruVb");
    bool OvBhqTHQecCdgyVR = false;
    double eduRNZErN = 978141.0241163642;

    if (eduRNZErN <= 978141.0241163642) {
        for (int xagXltFlupub = 1862042125; xagXltFlupub > 0; xagXltFlupub--) {
            eduRNZErN *= ByZxWWPqIdrSfQP;
        }
    }

    return OvBhqTHQecCdgyVR;
}

double NMAlRqwiCGl::olXSIcwncCz()
{
    bool TlDRHYHLlqSW = false;
    int bZEZIAr = -1522171941;
    string MGdEvOKtvdKjM = string("EHTYhvGPZrwixVjEBvimHUecMogIIyCcDQMlSfEuiCaiYrnrdIKmElGnDNGidNXNGSwoMdJmCCmtCkCTAsKAhbDTXtXtnLnnaYEsXwhDADfODnSmHDPWy");

    if (bZEZIAr <= -1522171941) {
        for (int ffOzNUL = 960518107; ffOzNUL > 0; ffOzNUL--) {
            MGdEvOKtvdKjM = MGdEvOKtvdKjM;
            bZEZIAr /= bZEZIAr;
            bZEZIAr += bZEZIAr;
            bZEZIAr += bZEZIAr;
            MGdEvOKtvdKjM = MGdEvOKtvdKjM;
        }
    }

    for (int FaDXII = 559533853; FaDXII > 0; FaDXII--) {
        bZEZIAr /= bZEZIAr;
    }

    return -684710.1818480844;
}

double NMAlRqwiCGl::gvHZKsBESB(bool Zelfxj, bool FLGplMyS, int xORuqWWxqa, double HHkQtUPzKrEXX, int PKcEv)
{
    double BfLlrlKhVfuXV = -667600.456312982;
    string EPEyeNJzGEUZZQs = string("VISmMnWjegJqQwuXQECDJxvsDzXXl");
    int HhZJYrPkQV = -821092572;
    string hFagMsBTVpyEKdyV = string("LMKppgYNBQmDYuniZlwxKDHkcihFicJNtkCZIiKIsXtzqvJOgGHAJxPXQgmVbxixZqqNrHYpnFWUMcaVsZBdqkRZixaDhzQeSXgecLZBRoDvsyXCrZMSxGfDPOVrYlOXtTseEZYqPLmLFnDnfZDJxWPXInVWDwGxeNtZqPjlrMBblwJQCfJoZdNCoNwinucMUJoWydNWkbPzirxZMkJchjxAYT");
    double EyGogTwEqwVcJV = -504290.1588137207;
    bool GxgbXMvtg = true;
    int HDFiVWcWcs = -206509345;
    bool vISAbovvDY = true;
    double BjZJGiZowp = 475062.61597073823;

    if (EyGogTwEqwVcJV != 475062.61597073823) {
        for (int ODSusHeRXcvKS = 1020465786; ODSusHeRXcvKS > 0; ODSusHeRXcvKS--) {
            continue;
        }
    }

    return BjZJGiZowp;
}

bool NMAlRqwiCGl::XwAWRgGrhh()
{
    double gaksQdK = -96600.80188110126;
    int edoZHxwkQZtWWSM = -1935551097;
    bool AbsXQroZNTgKzIa = false;
    string hMqGNsgXr = string("AdkJzzpuCjhYWcSQTYNFYPLexJGjchEUEpoDvCiYvJEKwtDsWaVSMzgdtdbdHmDNvWVqLFGgmrjLXcUGjjhYlVYDdPiXuDdSfzxLBqtdkbSDkPcBTixkkkFNOWJTXXFBkKSCTwWBLPMOJNVeDiUF");
    int YBekYEeaLaUYZ = 1999662085;
    int agYLewpQ = -2103261496;

    for (int DWtyTtW = 1425345529; DWtyTtW > 0; DWtyTtW--) {
        YBekYEeaLaUYZ *= edoZHxwkQZtWWSM;
        hMqGNsgXr = hMqGNsgXr;
        edoZHxwkQZtWWSM /= YBekYEeaLaUYZ;
    }

    if (agYLewpQ >= -1935551097) {
        for (int pxDaNrsRrNFAEFQR = 184307016; pxDaNrsRrNFAEFQR > 0; pxDaNrsRrNFAEFQR--) {
            YBekYEeaLaUYZ += agYLewpQ;
            edoZHxwkQZtWWSM *= edoZHxwkQZtWWSM;
            YBekYEeaLaUYZ *= YBekYEeaLaUYZ;
            gaksQdK /= gaksQdK;
        }
    }

    for (int aCwgOHhOZMF = 1262186816; aCwgOHhOZMF > 0; aCwgOHhOZMF--) {
        YBekYEeaLaUYZ = edoZHxwkQZtWWSM;
    }

    if (gaksQdK == -96600.80188110126) {
        for (int DhYUAKeVw = 875911945; DhYUAKeVw > 0; DhYUAKeVw--) {
            YBekYEeaLaUYZ += agYLewpQ;
        }
    }

    for (int fhzQZskP = 933579636; fhzQZskP > 0; fhzQZskP--) {
        agYLewpQ /= YBekYEeaLaUYZ;
        edoZHxwkQZtWWSM += YBekYEeaLaUYZ;
        edoZHxwkQZtWWSM *= edoZHxwkQZtWWSM;
    }

    return AbsXQroZNTgKzIa;
}

bool NMAlRqwiCGl::fIklFFhLC(double cOHJITGdV, bool iBRGbWhOeqNWOjA, string OuTIr, double mAuXNTJTFyzyBShW, double pluTO)
{
    string urANFLNsqAkzsHI = string("iCaRHcAP");
    string DNBswLpx = string("sOqCnbKXwIwOTPqnEbZbbIeQYchARHBojhwELRTdLImzsGuudFmgSTDQuFmnqziINqUKvjKUQyhhcWxpVbRHYSjRiIYYnqsSnBlKsabrwspQBptJVUtJzFaFOiQbKeCvEiujAfEtRYxcLVKkEbeedqLvsaKreQLCZvGoOwWwqdwWfdAPzJREfyTHEVjjNrKHNrtTwxjCUSuIeAxFuHmgQQKaiDoTM");
    string nzQOMvVBTdCReFIa = string("XNyqCJXqPmGXnlyZvOFWCFVpdKaeuoIhUKPGoiCUSAfhXaUFZbsJvfGePPIytOeEodtIKeSuYqHXTjakYzElouBqVYNTnFeUsNeIOGwDFwsoDMzGyDZIzXeEgDGqEHtUXjncXMSqkuGsTVDzAIwtCPOzBxaxqAGwcgbwudAhSZWAOnlUvAIiHRNUFBwsaosKpJZvJvqCGDIMJhnRsggosAHNhtq");
    int vkyAx = -2032198166;
    bool hJxtLPQrPREyE = false;

    return hJxtLPQrPREyE;
}

NMAlRqwiCGl::NMAlRqwiCGl()
{
    this->eiPqab(false, -695620891);
    this->GfedYuZd(string("hZRfOQCVXFwJTNoWosXHOyRGYZCrrDXTdqlXqnCjwQmFUgGbNqwpFzLNylUGKtqbiMalkhXulPbZgUEYQHMTMqjXvMNCGwuLiVRiTqLTeGoFSoddyYvOrKhxsgRfuNvEbObTKcRuuiw"), 1744975363, string("NNKYJNIGhVosQOgblcBtktbmaxxDIdSlDCBSOrshrGQgCEgyoHDYnlVnjlVyJCpakrQCGoutCSfOzOCcGDBqFOhXAcLVraCCtlDh"), -1445009485, false);
    this->saTBufLGLu(-392907335, 67079350, true);
    this->rVEULKTZnQec(43492.780921582045);
    this->vleFQJjpNejBNve(string("XrUVsrsPTCKbZTk"));
    this->kARQAvcv(true, string("WhPwPiQTeijRQDbgtoVETehuWQlDqlgOCUhOywEeoKegkvThasEmmNFYjFwSlQxsdvylbCzKKZDHlRLJzBtz"), -580249.5529457076);
    this->WQWRuC(-736992.7974330585, -88243.70413232611, false);
    this->pBAgwX(string("yXzLsQObn"), string("GEkXeNMOlyBUVSuZWanetmeEpkBmwJNVGWfifrUKpileRAXinVzeSsINaVtMUJTTTHuwEZcAgrrjpoOFFysHbwPUAamZYWZeyYIbncIGGwEVJCbmhTTyJvQdYnQOiEDrIMYueBQUOvzObWgCEdNzTHgskuNWtoZyyrIGjb"), 301830.6327309947);
    this->olXSIcwncCz();
    this->gvHZKsBESB(false, true, -1178497788, -151858.12309818488, 1727586595);
    this->XwAWRgGrhh();
    this->fIklFFhLC(-717938.1760602045, false, string("sFyehyLQEZBOeryWuqVoACupwsvMSBItlAfMaOSLNCFVDMuyTqDszjeqkPpdafVOMlxxQmAQTjpsCihhtVlQwxjFDmQaGJuSnoxqreGcUeVnNRhx"), 820367.9031255961, 595932.837057102);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nfLxQdUao
{
public:
    double LFrpchPuQdwSMO;
    bool ARRlQZ;

    nfLxQdUao();
    bool ipEnybUrgVeMQC(double wghrZwrHAXr, double TEPfAGJViRHjUPxU);
    int aUQhNOLcSYeOJzN(bool QSgRejWNuGs, bool GkiNoSdRUQZF, double dAQrpFHWCO, double eaYJBsRKGXFuog);
    string YNyZNZ();
    double MGrOcZstK(int oAKjSlCXnWV, int xtqFYATnhbv);
protected:
    string PinXqDmAWNdupK;
    bool iXCAkj;
    double CRdiiZz;
    string sPsrqx;
    double BZuCq;

    bool pmNvtvF(string foShxBooJiSpbBdR, int BdtjOFLSKcTnBw, int neiylhaZdSbNaCNj, string YdcfOjj);
    double vmGbKLcnFzKHXix(bool fRFgLjj, string yjbGpjOveu);
private:
    string kuRsdNwMyIuap;
    bool dQPzeu;
    bool BbwKyg;
    bool iauIlqTxALq;
    string PEUAJLtRi;
    bool eouTlr;

    bool SejhMkNXZpV(int VdidQa);
    void AtWKgOujzrHhkGhd(int NoebhalJz, double hJvAyzIQsMSSx, bool wKLokDaUstj, string KgTBEjfLOiReZHO, double LfEesC);
    int SfwFfFPgA(bool RvpxUX, int lRaDaLmxEqKuaT, string PcxTvpeVKpR, string kQnEY, string AxzHqMgnCiS);
    int zRxdJyMCxY();
    double MEkThN(bool uiwcgqzoDaGwTQXo);
};

bool nfLxQdUao::ipEnybUrgVeMQC(double wghrZwrHAXr, double TEPfAGJViRHjUPxU)
{
    int hZyHue = 675961880;
    double hwqSUGkhCzQqYxDq = -142711.76265916458;

    for (int jDVhQHNBm = 241332632; jDVhQHNBm > 0; jDVhQHNBm--) {
        hwqSUGkhCzQqYxDq -= wghrZwrHAXr;
        TEPfAGJViRHjUPxU /= TEPfAGJViRHjUPxU;
        TEPfAGJViRHjUPxU += TEPfAGJViRHjUPxU;
        hwqSUGkhCzQqYxDq -= TEPfAGJViRHjUPxU;
        hwqSUGkhCzQqYxDq -= TEPfAGJViRHjUPxU;
        hZyHue /= hZyHue;
        TEPfAGJViRHjUPxU /= wghrZwrHAXr;
    }

    if (TEPfAGJViRHjUPxU < 792798.6387117698) {
        for (int GYhUpCazp = 1289564934; GYhUpCazp > 0; GYhUpCazp--) {
            TEPfAGJViRHjUPxU /= wghrZwrHAXr;
        }
    }

    if (hwqSUGkhCzQqYxDq <= -142711.76265916458) {
        for (int AoNQCTNA = 1171805085; AoNQCTNA > 0; AoNQCTNA--) {
            hZyHue /= hZyHue;
            hZyHue -= hZyHue;
            wghrZwrHAXr -= TEPfAGJViRHjUPxU;
            wghrZwrHAXr -= TEPfAGJViRHjUPxU;
        }
    }

    if (wghrZwrHAXr < 792798.6387117698) {
        for (int ZcSvMR = 2045336842; ZcSvMR > 0; ZcSvMR--) {
            TEPfAGJViRHjUPxU /= hwqSUGkhCzQqYxDq;
            hwqSUGkhCzQqYxDq += TEPfAGJViRHjUPxU;
            hZyHue -= hZyHue;
            hwqSUGkhCzQqYxDq /= wghrZwrHAXr;
            hwqSUGkhCzQqYxDq *= wghrZwrHAXr;
            hwqSUGkhCzQqYxDq -= TEPfAGJViRHjUPxU;
            hZyHue += hZyHue;
            hZyHue /= hZyHue;
        }
    }

    if (wghrZwrHAXr == -142711.76265916458) {
        for (int HxMpuECNnzZI = 490504606; HxMpuECNnzZI > 0; HxMpuECNnzZI--) {
            hwqSUGkhCzQqYxDq = TEPfAGJViRHjUPxU;
            hZyHue += hZyHue;
            hwqSUGkhCzQqYxDq = TEPfAGJViRHjUPxU;
        }
    }

    if (TEPfAGJViRHjUPxU >= 904828.1333416558) {
        for (int voUikH = 1241795703; voUikH > 0; voUikH--) {
            hZyHue *= hZyHue;
            hwqSUGkhCzQqYxDq *= TEPfAGJViRHjUPxU;
        }
    }

    return true;
}

int nfLxQdUao::aUQhNOLcSYeOJzN(bool QSgRejWNuGs, bool GkiNoSdRUQZF, double dAQrpFHWCO, double eaYJBsRKGXFuog)
{
    double alFTtxIqHQ = -756367.0981141072;
    double WLaaqdQnarMvjeO = -744919.0899296504;

    if (GkiNoSdRUQZF == false) {
        for (int OevejuJGvz = 1885270626; OevejuJGvz > 0; OevejuJGvz--) {
            continue;
        }
    }

    if (WLaaqdQnarMvjeO != -744919.0899296504) {
        for (int MAldvgrJZ = 1732621715; MAldvgrJZ > 0; MAldvgrJZ--) {
            dAQrpFHWCO -= dAQrpFHWCO;
            dAQrpFHWCO += WLaaqdQnarMvjeO;
        }
    }

    if (WLaaqdQnarMvjeO <= -756367.0981141072) {
        for (int vHVPjiZBSCVaX = 1140931283; vHVPjiZBSCVaX > 0; vHVPjiZBSCVaX--) {
            continue;
        }
    }

    for (int IueXtmseL = 1578979575; IueXtmseL > 0; IueXtmseL--) {
        eaYJBsRKGXFuog = dAQrpFHWCO;
    }

    return 901269169;
}

string nfLxQdUao::YNyZNZ()
{
    double RTPoKMyY = -74578.09614974455;
    int nCoeGbUAnaNJiv = 2144255996;
    string oiTrU = string("dzrJoeMpFdDlpMDRZSdjGFBaZjKuEAaKRcQymbqPNbznijrxpQbLadJYviXnloyoSBgjCgVTjsMbfEIqKXNveHyEQfgPIGBrLMHAhkaqvaqLRCFnuMUVaFGuLHPzSAHbmSzWCPvOMDeRzAaAgheZsPlbFWpXfHazdOrVuIRhXORCxsOEIzhnTboMjyokvnsvAefTnUjmbM");
    int VUfylIc = -287620744;
    double ubUqfMdi = 880966.448954437;
    bool gmNbo = false;

    if (VUfylIc < 2144255996) {
        for (int FmFZyhOWBbw = 205644510; FmFZyhOWBbw > 0; FmFZyhOWBbw--) {
            oiTrU = oiTrU;
            RTPoKMyY -= RTPoKMyY;
        }
    }

    for (int rfzaxew = 1764200687; rfzaxew > 0; rfzaxew--) {
        VUfylIc *= VUfylIc;
        ubUqfMdi *= ubUqfMdi;
        VUfylIc /= nCoeGbUAnaNJiv;
        nCoeGbUAnaNJiv -= VUfylIc;
        VUfylIc -= VUfylIc;
    }

    return oiTrU;
}

double nfLxQdUao::MGrOcZstK(int oAKjSlCXnWV, int xtqFYATnhbv)
{
    int GjliHUQ = -431190947;
    double ctvWw = 147879.17733401692;
    bool LcUFPrCV = false;
    double iTfRnxcLzBSBHc = 307151.8616483364;
    int PQMgEJFVczZo = 804402870;
    double uQnFciPAYgtsWRwc = -683683.7554222007;
    bool QvsEjBQcCt = true;
    double soTcFP = -773659.8038487387;
    bool tYCnAs = true;
    double aDUPSOSXq = -88157.15756848213;

    for (int yJkNFUjIel = 689575969; yJkNFUjIel > 0; yJkNFUjIel--) {
        continue;
    }

    return aDUPSOSXq;
}

bool nfLxQdUao::pmNvtvF(string foShxBooJiSpbBdR, int BdtjOFLSKcTnBw, int neiylhaZdSbNaCNj, string YdcfOjj)
{
    int qoBADKMtv = -313919619;

    return true;
}

double nfLxQdUao::vmGbKLcnFzKHXix(bool fRFgLjj, string yjbGpjOveu)
{
    bool DwWENFJfbl = false;
    bool HARfqbAFf = false;
    bool dLOmlMZUmxQisd = false;
    bool vOGdRbhrwlTzeiH = false;
    double JcrCiCVhpkODec = -227982.16402719272;
    bool iIqStktc = false;
    int RSLYIAIXNUfosQGw = -730845571;
    bool UuIhiswoxUQdQpDr = false;
    int PrauPSydBjzAmT = -1116146681;

    if (PrauPSydBjzAmT == -730845571) {
        for (int GjlzCUrvj = 1695454511; GjlzCUrvj > 0; GjlzCUrvj--) {
            vOGdRbhrwlTzeiH = ! fRFgLjj;
        }
    }

    return JcrCiCVhpkODec;
}

bool nfLxQdUao::SejhMkNXZpV(int VdidQa)
{
    int vRqEEb = -1937703152;
    string ltlhUIhS = string("GNjRRVHyYPatLqtwFGscsqomYfwfbDAGrYTFNrOPFWegcZIhCMtlaiFUpzHdToGxEsTwJsHMhnZeOToyiRZVklDiFFtPEACOVaDwxHEHtrlmtqmjpEGUtOqlcamQxCShFsYGqDdYKkCDAvMEqeQWtDgGcrgDYy");
    string bvqykSPQAHNcN = string("BsVdbjQZXTbSjcunLUSLskwcmiGQZJoBXgTmjCjKLYOUpYfYTAxkaMbwJkNtvsrVLsvhSeJgZzFWQOeWwAhbgGgXuSEKsTroMZUvXLttPeNZTMOFPhPjrumKHYDKtXcOCIrHeNhgQqAoMfqORnMkFdPjNeTcfWlULXrwVvcdoKlNKmSxxxz");

    for (int bSZqxVsuBViJIv = 2134353716; bSZqxVsuBViJIv > 0; bSZqxVsuBViJIv--) {
        VdidQa += vRqEEb;
        ltlhUIhS = ltlhUIhS;
    }

    if (vRqEEb > -2091757294) {
        for (int punGJoY = 1300905825; punGJoY > 0; punGJoY--) {
            VdidQa = VdidQa;
            vRqEEb -= VdidQa;
            vRqEEb /= VdidQa;
        }
    }

    for (int ZLxCsWSwBKTnAslT = 895455103; ZLxCsWSwBKTnAslT > 0; ZLxCsWSwBKTnAslT--) {
        bvqykSPQAHNcN += bvqykSPQAHNcN;
        bvqykSPQAHNcN = bvqykSPQAHNcN;
        ltlhUIhS += bvqykSPQAHNcN;
        ltlhUIhS += ltlhUIhS;
        ltlhUIhS += bvqykSPQAHNcN;
        vRqEEb -= vRqEEb;
    }

    for (int stkHsWOU = 1191757287; stkHsWOU > 0; stkHsWOU--) {
        bvqykSPQAHNcN = ltlhUIhS;
        bvqykSPQAHNcN += bvqykSPQAHNcN;
        ltlhUIhS = bvqykSPQAHNcN;
        vRqEEb *= vRqEEb;
        bvqykSPQAHNcN = bvqykSPQAHNcN;
    }

    return true;
}

void nfLxQdUao::AtWKgOujzrHhkGhd(int NoebhalJz, double hJvAyzIQsMSSx, bool wKLokDaUstj, string KgTBEjfLOiReZHO, double LfEesC)
{
    string eGQbZrvel = string("wQIstVYKRnBaOblvEjsxiodHtDTufUddbQzVkBwhorlIpmJigmFIKRCnhIhJVEpeyBHqIMDClOHZJnaUOcznNsCfHqnfoxWfZAxTbLAbhItxfyTazfiesBEyrUySmGOyfTOlMGAiJVJZZIuDHULuNKRGVnPKhtJGpCquMSOkCYlZBfcksBrgJxynMvpOkdhCRfZIdi");
    bool ZNwULnhKCRYDwhZM = true;
    string UFMblFHpSRAdhmsH = string("AlySFBgbsQXwBMDmxJSPORYHloZNjnaBJazLnNfLOaICKWdipxfqWUBWFFUdKXHGJrtMrzMAlOJEOrchWSAdtDYDrjpXvhdyOygyfkvpvCvkNghVaZbSuAVO");
    int cxqlBqi = -1900992446;
    string PkElPTDkCJARKCi = string("sBXTfjQXkyatQSYlbnHMbTMglwmHzjFCJECOsPlnyUJzWDxNFuMevFnfObTzNveqIzxUDvgdTgQXdYcLoRNTERoSLCozSmYAzpBzpAGLVUlpevAmVaxXABmrttudEQvvrOiHAolaXLulLPqzmeliALUufFomrpzyoEWekobuDqbsoBMeROtugSVJoKpFnDDIMGaEwAuUrVqlxrJKuCoYnupLSpPwIheXJeUAzUKiicqzmdtwUTWgevvLFHU");
    bool feTKYRsF = true;
    int aYrrqVrj = -557389269;
    string rnZbqBJGhlNk = string("xGVvSMuVBsgcYrdPdiRBoaNCCzEaOosFyHXGrebbCQmrXcZqDURBSUnfjxEYJcvuuqepIcgnWcwnEIgDWOxezbbXhwimRppYxFPAVMUfpRUN");
    double FkVRH = 911019.6814184885;

    if (PkElPTDkCJARKCi <= string("xGVvSMuVBsgcYrdPdiRBoaNCCzEaOosFyHXGrebbCQmrXcZqDURBSUnfjxEYJcvuuqepIcgnWcwnEIgDWOxezbbXhwimRppYxFPAVMUfpRUN")) {
        for (int AxqwMZvPJOT = 305996096; AxqwMZvPJOT > 0; AxqwMZvPJOT--) {
            wKLokDaUstj = ! wKLokDaUstj;
        }
    }

    if (eGQbZrvel <= string("AlySFBgbsQXwBMDmxJSPORYHloZNjnaBJazLnNfLOaICKWdipxfqWUBWFFUdKXHGJrtMrzMAlOJEOrchWSAdtDYDrjpXvhdyOygyfkvpvCvkNghVaZbSuAVO")) {
        for (int pODvtWyKqbhfE = 1214097326; pODvtWyKqbhfE > 0; pODvtWyKqbhfE--) {
            continue;
        }
    }
}

int nfLxQdUao::SfwFfFPgA(bool RvpxUX, int lRaDaLmxEqKuaT, string PcxTvpeVKpR, string kQnEY, string AxzHqMgnCiS)
{
    string UVpApJH = string("bFWrBVzoLlYcIgWFjKcfPEUDDvsOsLvrOunLPbkcBArKEFoIbaAQvIvlTNgqAzkINxHQVNTfUPSsBIg");
    string FQWnv = string("cpGstqhmJOrKLBcsRpVqCSiCtQVzNtEdpXQZkYGCRpKJyafqkMuYBRUvKWDeixelZnJZLkqyQsBkAFhqKlGzLyUxtQwUEEQvCBcLiLBjZgdkKhthGDxLeOAbZjsWWQYCOpALOgRrThGIeiYiSmpjHjCZHKnYKxvmJtEeLpcAGZQIHJpecjooBZGfRvTobSSOhZMAMtPHWnyVvGnLOAEAOevmicaxurimHuGyayKEdqLhDTAYphecgCJjv");
    string SivBedNfTTswWLQ = string("iqJQjWSGuSmMiPBpRHIixWoJDhobRvJpkHZNpVFLggvmGnDEgCwdvstQGNPvFqJMMUndQCbsNJWcJiBtwkAFcyFiNNlCNlYTqDPTzDBHONdKbFOnUNxeK");
    bool XDDnsaCbyRc = true;
    bool oDJSKqodGYT = true;
    double RfmHkQZZM = 498024.8868510668;
    string izArYqL = string("evFPkudGLQyFcefiJDazUdzWRCeTNQiwwANuQDgSEZdgTFmAmHFUwduRzpcdVNXxNmbzsiDjQyutnKlBTPfIbtzOJxMWnaLYFIzruplAvizdKZHnWRydqsJJmJXqYQAtLTJiQSLTswCLKFVGPLNKztgwUsM");
    string RtOBxIgtcNIaraQF = string("ENXlAjdAHsdNFSyuJvfeDeCcYeqZVQTXlMUAHQpHdgNFJbtTQMhmjrCmoytrbAMADDNalLuIsAPnvFVebZTfFKdGYzGdkEeQcIhERLonUmiLTOyjacDXLMzZFCNiAAQlXHUAOfbAHUyLJVbTrNafSZwLAPZljwDBOXmAJKnAXwxOJnqUroCRIxCUFkCxetQbMGAzdJIYbKbliOfykWpCyiRVbUGGBGEdtswsShHbfa");
    bool tJGJi = true;
    double PmAdZpqtmfV = -136155.87693210132;

    if (kQnEY != string("xBGUyuKIkGvYpGIHyDJoMQzDbmkAPVUCTkouhjQmlRyAHifdYxlYKsYjhWgDoXyreUQqYudfEUbRiVNBqbPTRmIpYjxygNZhoRsbxPfXIiTSPKhjiBhLgCLKeUqZoOeUhysnKFptdMvwbbLgJeHzeAtDrwkwoJOjbWwWmwFgouhJhbShQWoSzpqAXzkFTNWSvseaCKqokRWyVv")) {
        for (int MpnIn = 1114849177; MpnIn > 0; MpnIn--) {
            kQnEY = AxzHqMgnCiS;
            SivBedNfTTswWLQ += AxzHqMgnCiS;
            RtOBxIgtcNIaraQF += izArYqL;
            RvpxUX = ! RvpxUX;
        }
    }

    for (int dahhpvKTsB = 1511483707; dahhpvKTsB > 0; dahhpvKTsB--) {
        FQWnv += RtOBxIgtcNIaraQF;
    }

    for (int LxbMCwvdKetNGT = 883636143; LxbMCwvdKetNGT > 0; LxbMCwvdKetNGT--) {
        PcxTvpeVKpR += RtOBxIgtcNIaraQF;
        PcxTvpeVKpR += AxzHqMgnCiS;
        izArYqL += PcxTvpeVKpR;
        SivBedNfTTswWLQ += PcxTvpeVKpR;
        oDJSKqodGYT = tJGJi;
    }

    return lRaDaLmxEqKuaT;
}

int nfLxQdUao::zRxdJyMCxY()
{
    double sdmtYmGOPBI = -295236.46925910003;
    double aBimRti = 427942.73747336556;
    string syiOEeWwg = string("Fu");
    string ZVxDwBp = string("EsLgXnwPjTZWETnvpUUoLWtjpRmkBercMLrEydsupeAzXCJLnZuNcmOqeMsnUkSfbywBeaXtBULYGAHCdzSzeRFZaOwFZUHsNJxHEafXCwds");

    for (int VHreWZKzIPQe = 547296669; VHreWZKzIPQe > 0; VHreWZKzIPQe--) {
        ZVxDwBp += ZVxDwBp;
        aBimRti *= aBimRti;
    }

    for (int DdAeDsJbQK = 150300573; DdAeDsJbQK > 0; DdAeDsJbQK--) {
        aBimRti += sdmtYmGOPBI;
        syiOEeWwg = ZVxDwBp;
        sdmtYmGOPBI += aBimRti;
        ZVxDwBp += syiOEeWwg;
        sdmtYmGOPBI += aBimRti;
    }

    return 736146383;
}

double nfLxQdUao::MEkThN(bool uiwcgqzoDaGwTQXo)
{
    string PkXCydnxOm = string("JOyrRuPwJYWRJwYvIJzCCumaCBCwiVATUwpHYRrFnAJjirsihlIdAzoULwuWvOIrSenHMuCbmMGliewhIeaWyCnBlXgRelDlkPolLlQUGzcxjuiHYaDQproHJEhaapvJqsJzzhEVBzNwioFRGUyvssEcqVoVlizGbmtTnPhlyxeOKYWqNWjKVMdEByYUMBBDzQ");
    int DGjCkEOquSnqZ = -1105340511;
    int BvCaekNxF = 1666801369;
    string nGosLTXim = string("tHXFVmvfOWzbWLBonmnCiNaSYXtbiwxuqUwQLSk");
    int DWMIsaJzeW = 338177660;
    double bzCsHPmwuSfBxSm = 988934.3820878977;
    int pupovEswaLqZCz = -129260316;
    string rYHrvLS = string("NHhxkfDKjAeXqqqnJvqPsmJeAxGaUPFNLUZtEVcMbznVspplpOjvJQaFupvbSYoblEDpolr");

    for (int YVaDLbURfPQXBF = 1835629856; YVaDLbURfPQXBF > 0; YVaDLbURfPQXBF--) {
        continue;
    }

    for (int bsZxTHkOE = 1735470554; bsZxTHkOE > 0; bsZxTHkOE--) {
        rYHrvLS = nGosLTXim;
        PkXCydnxOm = nGosLTXim;
    }

    return bzCsHPmwuSfBxSm;
}

nfLxQdUao::nfLxQdUao()
{
    this->ipEnybUrgVeMQC(904828.1333416558, 792798.6387117698);
    this->aUQhNOLcSYeOJzN(false, false, -898529.7245551076, 376868.07002529583);
    this->YNyZNZ();
    this->MGrOcZstK(-573640813, -1631723944);
    this->pmNvtvF(string("UejzBsTpaLQeKnklnvrcmQePZGprKuwPSzTFPNhUYNIZeLcQtNPiDYCYfTfyibRusRphuykDcBWZHwDlKjhOAJPByRGjXBKmzbTnoJuLVYThQAYscVEutxvAxNPzXrOSMgEQPldWbL"), 1790373761, 120375628, string("zsEmoZQMPZKdROUAOIWKEcvTuBqYefHLPZsfyevbVXxVDIznRmOrNDQiYEvurwTfticnupNzrFeqOhPfhvqPGxIqGbVgZnVwjmkhnUoUnCBdfnxueHZYNRxLDoIfqDplPWJDhVqWvplhopUowmemCFNukcypqXAEPOxhtopKWgSVdznpHNVkkzGQKSYlrwAfrGUjazfNJgqzmUaaxQEsrBlAwytBdFVrovqplNeEjbtyBgOsCUCsQTmanwBLfm"));
    this->vmGbKLcnFzKHXix(false, string("OOSbElTUlBvzbQOFMHWLPJoKqpShpfKWWxLGrRri"));
    this->SejhMkNXZpV(-2091757294);
    this->AtWKgOujzrHhkGhd(-1635329015, -438892.10150944546, true, string("nFTFXoBQMRKuUrlxgCFPJWsvZmqvf"), 585259.469178386);
    this->SfwFfFPgA(false, 1490780713, string("xBGUyuKIkGvYpGIHyDJoMQzDbmkAPVUCTkouhjQmlRyAHifdYxlYKsYjhWgDoXyreUQqYudfEUbRiVNBqbPTRmIpYjxygNZhoRsbxPfXIiTSPKhjiBhLgCLKeUqZoOeUhysnKFptdMvwbbLgJeHzeAtDrwkwoJOjbWwWmwFgouhJhbShQWoSzpqAXzkFTNWSvseaCKqokRWyVv"), string("uecPRoeZzavDfpSdAFQuvXCWcpkbnNJfzZjXFWxyuguiuQCpFRzJPmqtItpYbaraXEyFEfJVtCafROUHSuQrKtjSEftedEoJrRCYSesTStfsawCCVTJmiADsQIiJAqtXEznCxBkJtxoiOHdMqTE"), string("wcIGuczIIMuVysqIkODLnWIQCVovZikEAClFjLWdrSqWdDZIgRGwZVzLUVfeViYOSZxHyDgKqOvgKalejfYMewLFvAhUEFgKYYLUrWseYOUAHPskBnCywxjyXRldwSQYFWUtfTIpgQIQlEZOacdaGiNUnJABaPxRjapypujsvLIkkhmGuzKSRqEMIdXSRHlMlQxmpjrcqZTBRBLLQqLaUCWolbeWAg"));
    this->zRxdJyMCxY();
    this->MEkThN(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HNqxgUgtYYlO
{
public:
    string GKfib;
    int uLBXSBoPo;
    int BpEsxynikrukWsA;
    string gWfgAVBKlSaMzx;
    int eFMrQlYNBoIPNbXl;
    bool uLnLS;

    HNqxgUgtYYlO();
    double eUwNOEmT(string gmDcK, string WcVgM, string zeUOMsXbgfVI);
    bool IuZlZcOKuUMpY(double AfdKBEzeq, int GfKIqnWEQdOK);
    int MmXGgioXIIND(bool ZKmdrHQtdAzju, string RSbniMtc, string keIUSwgPDPE);
    void UCHZITRbPmKd(string dbqLQnG, int enJHWcLnr, int dtylGcqd);
    void GJBxINF(string XVNFBw, string iYsezLBoPITgmVR);
    void SqzsmhvjPcgFso();
protected:
    string WjHGtLOvuZOw;
    string PLcpPwoZeC;
    bool LyXExIbeUJUeWCcl;
    string FsMJobI;
    double lVUzlwuPbZG;

    int QNvfCXA(int bHAVVztsMsrCA, bool jYbZO);
    string KpiHInDmIyzhk(string VNzgzr, double avRDFldbozCtxgL, bool fTlGFifG, double QtMDR);
    bool ohJdZHkTDguz(bool eWSAJQLdEG, int JVduUrhy, string mDchmGiLGn);
    bool iBVnkZyi(int TClrIZ, int HpVeUvNZ, string pvdrDeHe, int OoYBx, int mecbB);
    string ZprcfjSeL(string gtCWRTUQxeHb, bool OfpBYtVcTYxGCtL, string fQsHdQJEGyBoZT, string UGFfArMIuGJ);
private:
    bool kkAVdSmkJIHcKPXA;
    int wxCnpDjwYrNoc;
    double oWjiHfBGy;
    string UIzSFdBbK;
    string KEEZpFDKwwEEcXm;
    bool kuaSEnHnRn;

    bool QPBXk(bool UePgXL, int WoVrDjCWBtglnFcX, bool MFMemSZOrIfQ, double qdcwAYmJM, double caWxVvEYCJFTVr);
    bool FQVYEPRxBSSbistB(string GLiaIgEasJrtVtUN);
    double RdpIOe(int RPyvBnRVaSqHiJNH, bool aQpRwGcENMCcJjPe, string ifDgBQVxkXQ, int ihpHZcN, int mMUorCrAxrgDiNKw);
    string yZpTHZcpYtl();
};

double HNqxgUgtYYlO::eUwNOEmT(string gmDcK, string WcVgM, string zeUOMsXbgfVI)
{
    bool ioJBIoQ = false;
    double oKpXHOrcEqSIk = 576082.0924883533;
    bool KVqwbImhoRdQVuvc = true;

    if (oKpXHOrcEqSIk >= 576082.0924883533) {
        for (int mZfRPaiJBAurs = 420607751; mZfRPaiJBAurs > 0; mZfRPaiJBAurs--) {
            continue;
        }
    }

    for (int UOWViWmGzVXTJ = 191994964; UOWViWmGzVXTJ > 0; UOWViWmGzVXTJ--) {
        KVqwbImhoRdQVuvc = ! KVqwbImhoRdQVuvc;
        zeUOMsXbgfVI += WcVgM;
    }

    if (gmDcK <= string("KmLGEsAiWtPTrUvFKdJyZIbzvcGyqlpDcYXiFSLJfYaWmqwtmZUVfJhghnRWPKlQAtlsVwNMmPRBiavusZMfUVBIWsrhXgGxFECLAlmuaEXprDJhkpZVuOeHIIedLJYdWKnefUOIkNxKSkZfyBGeQNpjFCEZWxNTVaVPqbyHjTtiHOunnRguhSKmtYXmCRFvStUpysmNLzkKWHxNqQjOYfRtjuJqVcievGDkFLMdlugtDqfsSXbidWArUqdcL")) {
        for (int lvTgDWlTW = 1637495937; lvTgDWlTW > 0; lvTgDWlTW--) {
            KVqwbImhoRdQVuvc = ! KVqwbImhoRdQVuvc;
            oKpXHOrcEqSIk -= oKpXHOrcEqSIk;
        }
    }

    if (zeUOMsXbgfVI < string("vlsfEEeQBmXWGpaduLwbjKkNntMBwWvABmmCtkAGFdquYJhUzVCOoAlfGeizdBRybLywqjfhGxNacBSqVZpISupZNWXrgzAdIBlcCedeUpjHEqBJwHHbiVhBmZwUo")) {
        for (int oEQmkIhn = 250116843; oEQmkIhn > 0; oEQmkIhn--) {
            zeUOMsXbgfVI = WcVgM;
        }
    }

    return oKpXHOrcEqSIk;
}

bool HNqxgUgtYYlO::IuZlZcOKuUMpY(double AfdKBEzeq, int GfKIqnWEQdOK)
{
    int bRlegsQ = 1411213893;
    string siPHxODFmf = string("UsVoJGQEvBacqMZfCELjZfYosqQbJTMgTwvcDNNwHVBdRUySVVKBVyLtpBDrslljX");
    bool mHPeHuOR = false;

    if (GfKIqnWEQdOK == -677792311) {
        for (int NVVxMsfYxuFxgD = 1858160885; NVVxMsfYxuFxgD > 0; NVVxMsfYxuFxgD--) {
            continue;
        }
    }

    for (int nfXycrkAUJqMivCo = 605645834; nfXycrkAUJqMivCo > 0; nfXycrkAUJqMivCo--) {
        GfKIqnWEQdOK = bRlegsQ;
    }

    for (int hFsLqRiDP = 1880064108; hFsLqRiDP > 0; hFsLqRiDP--) {
        continue;
    }

    for (int TyIwHC = 311583501; TyIwHC > 0; TyIwHC--) {
        GfKIqnWEQdOK -= bRlegsQ;
        bRlegsQ += GfKIqnWEQdOK;
        mHPeHuOR = ! mHPeHuOR;
        siPHxODFmf = siPHxODFmf;
        bRlegsQ = GfKIqnWEQdOK;
    }

    for (int hTjOwkvOJy = 140517159; hTjOwkvOJy > 0; hTjOwkvOJy--) {
        continue;
    }

    return mHPeHuOR;
}

int HNqxgUgtYYlO::MmXGgioXIIND(bool ZKmdrHQtdAzju, string RSbniMtc, string keIUSwgPDPE)
{
    bool OSIbdEmsMolkr = false;
    string uiOnITxM = string("mEtwZmDNrcWzdlOJqTHSjzedSIfrdwtbBRmYuHnFRaHleFIwMgFMhoRffACqhivhgbdUjQAdXhPpxu");
    bool jZDTHCCq = false;
    bool WMSygnufePVHwmU = false;

    if (jZDTHCCq == true) {
        for (int MAadBlcsIU = 1142201997; MAadBlcsIU > 0; MAadBlcsIU--) {
            continue;
        }
    }

    for (int rvjmzB = 557260997; rvjmzB > 0; rvjmzB--) {
        WMSygnufePVHwmU = WMSygnufePVHwmU;
    }

    if (uiOnITxM <= string("XXsoukLRCAUZpvzEnmIVypDFWwxXBXBVtkjSaAzgJJCMKlLoROKoCHtkNGdgZkpkTArERJSUDa")) {
        for (int wiJBm = 246539612; wiJBm > 0; wiJBm--) {
            keIUSwgPDPE += RSbniMtc;
            ZKmdrHQtdAzju = OSIbdEmsMolkr;
            WMSygnufePVHwmU = ! ZKmdrHQtdAzju;
        }
    }

    if (OSIbdEmsMolkr != false) {
        for (int gxwvIC = 1999377215; gxwvIC > 0; gxwvIC--) {
            ZKmdrHQtdAzju = jZDTHCCq;
            RSbniMtc += keIUSwgPDPE;
            uiOnITxM += uiOnITxM;
        }
    }

    for (int GPmtzDSyGISDckVI = 834723003; GPmtzDSyGISDckVI > 0; GPmtzDSyGISDckVI--) {
        ZKmdrHQtdAzju = ! OSIbdEmsMolkr;
        OSIbdEmsMolkr = ZKmdrHQtdAzju;
        uiOnITxM += RSbniMtc;
    }

    return -932936140;
}

void HNqxgUgtYYlO::UCHZITRbPmKd(string dbqLQnG, int enJHWcLnr, int dtylGcqd)
{
    int DpvmU = 332965481;
    string PcUkqvgQ = string("VVuwjtuackYmqWeeOFpXffTfkakDgoZHlLOmnmDDIrXzAwA");
    bool JjqIrplkRpo = false;
}

void HNqxgUgtYYlO::GJBxINF(string XVNFBw, string iYsezLBoPITgmVR)
{
    int GtfgyYZUzQtuPLqo = -601660152;
    double lfbEJYsFYLc = 890627.2447473936;
    double zxBwkW = -179957.53093620748;
    bool ebezHLms = false;
    int owDfuSddROkUdxLR = -193314443;
    string QKLpNhgASv = string("aMrLKpviavdHXMARlEyPiFddxHxrrCBVRSXQ");
    bool bWwucnQhlYKNZyf = true;
    bool xurguwjmLTJPcytQ = false;

    for (int klNgEZ = 1144720727; klNgEZ > 0; klNgEZ--) {
        bWwucnQhlYKNZyf = ebezHLms;
        ebezHLms = ! bWwucnQhlYKNZyf;
        bWwucnQhlYKNZyf = ebezHLms;
        XVNFBw += QKLpNhgASv;
    }

    for (int xNAhABJ = 251800508; xNAhABJ > 0; xNAhABJ--) {
        continue;
    }

    if (bWwucnQhlYKNZyf != true) {
        for (int GumhxojIKV = 680528687; GumhxojIKV > 0; GumhxojIKV--) {
            zxBwkW = lfbEJYsFYLc;
        }
    }

    for (int iIXqnmHa = 972212427; iIXqnmHa > 0; iIXqnmHa--) {
        QKLpNhgASv = QKLpNhgASv;
        ebezHLms = ! ebezHLms;
        ebezHLms = ! xurguwjmLTJPcytQ;
        XVNFBw = iYsezLBoPITgmVR;
    }
}

void HNqxgUgtYYlO::SqzsmhvjPcgFso()
{
    int yCWBPyu = -1147311487;
    bool furoXvGvrbvo = false;
    double OZCguoSMiBfotY = 403961.52756174456;
    bool vjdcLgwHp = false;
    bool rfomrhEeraZRc = true;
    bool ECpjdFWbMm = false;
    string kaUzI = string("gTBJuWrRPtjaeOIeUFAmQZjAYeAuSxouCTHvzRMpSZokbZQXEMwwvPmIeJKbbEbolCxCdtpEDmxZVwaDdGZBkYJLFjLATHEpiNmFCBcvkhiveI");
    string AnHIRsmL = string("DArHQDVNfVVuumRrzGFXpMdBssTVUgROHjptXEAITvIcjCeTusQdGbqnbZSbhaHaKzaldjyXYcmr");

    if (AnHIRsmL >= string("gTBJuWrRPtjaeOIeUFAmQZjAYeAuSxouCTHvzRMpSZokbZQXEMwwvPmIeJKbbEbolCxCdtpEDmxZVwaDdGZBkYJLFjLATHEpiNmFCBcvkhiveI")) {
        for (int PKMLyTbAJnTMxVSX = 1529009633; PKMLyTbAJnTMxVSX > 0; PKMLyTbAJnTMxVSX--) {
            ECpjdFWbMm = ! rfomrhEeraZRc;
        }
    }

    for (int XFJiqHeYgiijgO = 662430060; XFJiqHeYgiijgO > 0; XFJiqHeYgiijgO--) {
        vjdcLgwHp = ECpjdFWbMm;
        ECpjdFWbMm = ! vjdcLgwHp;
        vjdcLgwHp = vjdcLgwHp;
    }

    if (kaUzI <= string("gTBJuWrRPtjaeOIeUFAmQZjAYeAuSxouCTHvzRMpSZokbZQXEMwwvPmIeJKbbEbolCxCdtpEDmxZVwaDdGZBkYJLFjLATHEpiNmFCBcvkhiveI")) {
        for (int UwLstlOg = 1676540073; UwLstlOg > 0; UwLstlOg--) {
            continue;
        }
    }

    for (int wZffMkUFazdPVX = 2071911259; wZffMkUFazdPVX > 0; wZffMkUFazdPVX--) {
        continue;
    }
}

int HNqxgUgtYYlO::QNvfCXA(int bHAVVztsMsrCA, bool jYbZO)
{
    bool KryBbiHcu = false;
    double QwXfl = -429845.42761075695;
    string pgReXAD = string("vKzlraXDZHRJmGcuorxcCXIZjFKxbELcqpOluPQdDVadxIbqvygZBnlFyakABeJAyKfvuweWBUTBAuXrrGdOegAmmAazfAtSvScAbArrCcmszxbRmUeYiPqwiDZpTnisnLKmWYrivDOCyrcwzTmqEGjfifLNXBReJxIqIGooKhkJjWaIRvGfvjZOxmKVeTrXkCYLakCGuVQaPcBXyWHWPQgqiDPiiYMpotOHVbRoUApijv");
    double tTLgHx = 305828.5195065935;
    int kMQWzgA = -794787669;
    bool KOFbfgr = true;
    bool rzwwrKLWEUnvPLc = true;
    bool otWbKsCIusMV = true;
    int YreCJ = -1574143642;
    int sHqhPwEhXnMhfdQi = 1330604841;

    for (int rRBLXLuGwkvAJXS = 222235545; rRBLXLuGwkvAJXS > 0; rRBLXLuGwkvAJXS--) {
        tTLgHx += QwXfl;
    }

    for (int EYdKoPxDqrY = 342549015; EYdKoPxDqrY > 0; EYdKoPxDqrY--) {
        continue;
    }

    if (pgReXAD > string("vKzlraXDZHRJmGcuorxcCXIZjFKxbELcqpOluPQdDVadxIbqvygZBnlFyakABeJAyKfvuweWBUTBAuXrrGdOegAmmAazfAtSvScAbArrCcmszxbRmUeYiPqwiDZpTnisnLKmWYrivDOCyrcwzTmqEGjfifLNXBReJxIqIGooKhkJjWaIRvGfvjZOxmKVeTrXkCYLakCGuVQaPcBXyWHWPQgqiDPiiYMpotOHVbRoUApijv")) {
        for (int btXgYdSplwv = 619141992; btXgYdSplwv > 0; btXgYdSplwv--) {
            pgReXAD = pgReXAD;
            tTLgHx += tTLgHx;
        }
    }

    return sHqhPwEhXnMhfdQi;
}

string HNqxgUgtYYlO::KpiHInDmIyzhk(string VNzgzr, double avRDFldbozCtxgL, bool fTlGFifG, double QtMDR)
{
    bool qKeZE = false;
    int OhjKmgOqiDhNJKx = 770430204;
    int vcgTNzRxW = -1501932033;
    int tnWAcrje = -1703816264;
    bool ZZKTVtfXIYXQdyys = true;
    string YzbEvNC = string("AVDhyRUzcCqdgnzlmbXyylFtJPJugUxvybOlqKRuKrBsIETRFOpYMSenNtmvSKDitBMuZJxomkreJKEBdxgqOBOFnyWqdPAUYOdGePzyRJSAWenJONqyKXVUJzlsAtcEXGdlhZHzzEzDMnRWseANwdJGpjIreyXHjVPYJAFHRXEfafxSudxeToDHfiTtcBwYPzBOZklBsYsyLhQcHTQYsouESJnRTfJThkIzBajNbJZ");
    int bRkbDUB = -2027107151;
    int IwcoiJGDeoHBPu = 87875155;
    bool eyiDfcOMbBAVwoc = true;

    for (int hwoXSxboqtMDuql = 135040684; hwoXSxboqtMDuql > 0; hwoXSxboqtMDuql--) {
        ZZKTVtfXIYXQdyys = ! fTlGFifG;
    }

    return YzbEvNC;
}

bool HNqxgUgtYYlO::ohJdZHkTDguz(bool eWSAJQLdEG, int JVduUrhy, string mDchmGiLGn)
{
    double sJYLFpSfMuXqBr = 365663.63889574277;
    int mmDpzlegDIiaI = 1489075888;
    string QPXHu = string("pmXHjSdlrXocKlVNtmiIyrdrEBBIZPzwFTiwxw");
    double kVcpSXilR = -686125.7471492018;
    int nwBkqeaWUlM = 649929336;
    double xaLRYdBjg = 509253.96901998523;
    double PMezFHV = -129430.19765125698;
    double HrwHhGhzIZhy = 57326.30846930673;
    int itnCjS = -1052787435;

    for (int yCBHJozSMFKtrT = 215496763; yCBHJozSMFKtrT > 0; yCBHJozSMFKtrT--) {
        mmDpzlegDIiaI *= JVduUrhy;
        QPXHu += mDchmGiLGn;
    }

    for (int yJfAGbS = 2037282939; yJfAGbS > 0; yJfAGbS--) {
        continue;
    }

    return eWSAJQLdEG;
}

bool HNqxgUgtYYlO::iBVnkZyi(int TClrIZ, int HpVeUvNZ, string pvdrDeHe, int OoYBx, int mecbB)
{
    int CwmTNCkfBVCAYbvI = -1457576557;
    bool otQsZqWbsL = true;
    string rrSMNNrFybFDtk = string("OnkyUXfQIGSKgTbHxySMiNLjaczHmQHsTOKCHhpjvNQqjdbUIFgtizjLIMPPPqiHfIBAhGUNwiMgwfApDJhsmtAVNAzGthKIFWQxufavKRtVOxvOBLYgPpTqqrVkwasKYAPsubCnSKovljSDQLTLormtiyAPbLqkyzqvCnZEjVfIvtFDxdHyTkNaeRNwdkOkVUdonNzVSlQEPjOBQJjqYjokeZUAtypFkPr");
    bool zDHYbzNX = true;
    string OrAGAORxhpcrc = string("WHcetmemsLjLBTFfLaoDHWGFLxInwanKdpSjNWBaSlmSLZVVFHYlnbtuhtlbLerKgtPEQURNSeFLleBEQvlJLkoPpVYBrenVRQRDcymiB");
    bool FzfWGHfvG = true;

    for (int poFIz = 1074911799; poFIz > 0; poFIz--) {
        zDHYbzNX = FzfWGHfvG;
        zDHYbzNX = zDHYbzNX;
        rrSMNNrFybFDtk = pvdrDeHe;
        CwmTNCkfBVCAYbvI /= mecbB;
        CwmTNCkfBVCAYbvI *= TClrIZ;
    }

    return FzfWGHfvG;
}

string HNqxgUgtYYlO::ZprcfjSeL(string gtCWRTUQxeHb, bool OfpBYtVcTYxGCtL, string fQsHdQJEGyBoZT, string UGFfArMIuGJ)
{
    double nljPEKTFhNJjO = -197776.94958392184;
    string XEjINyH = string("mBbwiPXUGhtsrBmdbrwzDlcpvJIUwQlpdivZoTCTkbPyNAkRXGLPWavLqQTETigRdCRTsUrfiMrcavrmHXCDEKrbVKlCWcxYKxYcBCpnQAqBYntgMLbzLcTeHOLKhFjAfSFSFhbcZmofkbJWFOBHIMxZurnMRbYDlffVeJDscEPoREudJQUDxurKrtFgHeIhoHOdSTWqwSNBJfNgjOKfUaIRxHYNTMELcsyqL");
    string VOjaSvOOm = string("WmBOgFrTFjGyCbVanevXFCIYLYFohhatje");
    double KedaurpgM = 1012586.2655880384;
    int ccXKLxlxcRlecj = 2141282143;
    string TCACJCVjQDhwx = string("UcYZQAdniTeoOtkjiVUbHJCiPBMKXVtSDMhYQCaxFIpNzAKSpBVWllwskBefiadZhIVLhKGhaqNCidkgLLMJKSpMSbSInKMLMFpzAZMFyXEPCIUmyTw");
    string IogQIWdTn = string("QrrTqmsNQGYgrfVBmtsqgrDctJwtwHsOnSRxoWVUHMYvBEWcmBCUNQHQbDnGYtzUvIJkdPUOzxzjcVNdVaKzYZHXHhJpVwPKkamKDHFjZeaLfwWuSKBCwvbAQRgavOJMTgeyVwHRIdZiUbIveHrLLEpNuoKLsGksQF");
    bool nOlgIgibZy = true;
    string GzTuRJFEFjlC = string("bbvKP");

    for (int IadjoEhigWnRypf = 653526089; IadjoEhigWnRypf > 0; IadjoEhigWnRypf--) {
        fQsHdQJEGyBoZT += TCACJCVjQDhwx;
    }

    for (int oZNHiZTqRpMGj = 1517572489; oZNHiZTqRpMGj > 0; oZNHiZTqRpMGj--) {
        VOjaSvOOm += VOjaSvOOm;
        GzTuRJFEFjlC += TCACJCVjQDhwx;
        fQsHdQJEGyBoZT = fQsHdQJEGyBoZT;
        IogQIWdTn = TCACJCVjQDhwx;
    }

    if (GzTuRJFEFjlC > string("nqgsAsUNyaeQGoRKkYeFQypKEIZwZAMynLuqZuuBorXxaaJUuEcFQiZRthuoSRtKsSuhsLsMBtxcjNsRuHpwHJnooJumGBPEXYCrwOuWiAUgZpIcYgDODlQrsTAuuCgTz")) {
        for (int RwzlvrRHz = 1440320787; RwzlvrRHz > 0; RwzlvrRHz--) {
            gtCWRTUQxeHb = GzTuRJFEFjlC;
            OfpBYtVcTYxGCtL = ! nOlgIgibZy;
            GzTuRJFEFjlC += GzTuRJFEFjlC;
        }
    }

    return GzTuRJFEFjlC;
}

bool HNqxgUgtYYlO::QPBXk(bool UePgXL, int WoVrDjCWBtglnFcX, bool MFMemSZOrIfQ, double qdcwAYmJM, double caWxVvEYCJFTVr)
{
    double nHbdfj = -472620.6172638771;
    string OUZGMvsaztwTbvN = string("jsLrZgyIaUdMEcUYfJYoChLhWKknuByjgFuDxl");
    bool IqPPETq = true;

    return IqPPETq;
}

bool HNqxgUgtYYlO::FQVYEPRxBSSbistB(string GLiaIgEasJrtVtUN)
{
    string EeYkVCxRpjsztd = string("XKbyANLHMtfWoOfrKJKWURuHmElvAGjCxCzJLaNBWhdoAAzmsBmSfYVBCRJfvyeEDTUCeDnRrffqufMCBhFnJiFUSmhbqwXEHLPWmECyNtycaqXKwMgApYIdYTHnvBoUqbyIiH");
    int TmVUVEKqJOgqlAL = 674797902;

    if (EeYkVCxRpjsztd <= string("XKbyANLHMtfWoOfrKJKWURuHmElvAGjCxCzJLaNBWhdoAAzmsBmSfYVBCRJfvyeEDTUCeDnRrffqufMCBhFnJiFUSmhbqwXEHLPWmECyNtycaqXKwMgApYIdYTHnvBoUqbyIiH")) {
        for (int hHFlQUJtMBBpMERu = 1694681570; hHFlQUJtMBBpMERu > 0; hHFlQUJtMBBpMERu--) {
            TmVUVEKqJOgqlAL *= TmVUVEKqJOgqlAL;
        }
    }

    if (TmVUVEKqJOgqlAL == 674797902) {
        for (int JmjgkawuOrviNPV = 555199014; JmjgkawuOrviNPV > 0; JmjgkawuOrviNPV--) {
            EeYkVCxRpjsztd += GLiaIgEasJrtVtUN;
            GLiaIgEasJrtVtUN = GLiaIgEasJrtVtUN;
            EeYkVCxRpjsztd += GLiaIgEasJrtVtUN;
            GLiaIgEasJrtVtUN += GLiaIgEasJrtVtUN;
        }
    }

    return false;
}

double HNqxgUgtYYlO::RdpIOe(int RPyvBnRVaSqHiJNH, bool aQpRwGcENMCcJjPe, string ifDgBQVxkXQ, int ihpHZcN, int mMUorCrAxrgDiNKw)
{
    int OlNvTQdu = 130476315;
    int oIiaMOviPit = -1306778630;
    bool gQVSyDMtDqsIIzxG = false;

    if (RPyvBnRVaSqHiJNH > -1306778630) {
        for (int FtlMu = 120626810; FtlMu > 0; FtlMu--) {
            RPyvBnRVaSqHiJNH /= ihpHZcN;
            ihpHZcN -= RPyvBnRVaSqHiJNH;
        }
    }

    return -204721.69818538526;
}

string HNqxgUgtYYlO::yZpTHZcpYtl()
{
    double LqrrdPSsZ = -296500.78117478004;

    if (LqrrdPSsZ >= -296500.78117478004) {
        for (int kHZHhycnf = 977945693; kHZHhycnf > 0; kHZHhycnf--) {
            LqrrdPSsZ /= LqrrdPSsZ;
            LqrrdPSsZ *= LqrrdPSsZ;
            LqrrdPSsZ *= LqrrdPSsZ;
        }
    }

    if (LqrrdPSsZ < -296500.78117478004) {
        for (int msmoa = 1560740664; msmoa > 0; msmoa--) {
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ /= LqrrdPSsZ;
            LqrrdPSsZ -= LqrrdPSsZ;
            LqrrdPSsZ /= LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
        }
    }

    if (LqrrdPSsZ < -296500.78117478004) {
        for (int RRnhZYzLHgYwV = 134862743; RRnhZYzLHgYwV > 0; RRnhZYzLHgYwV--) {
            LqrrdPSsZ *= LqrrdPSsZ;
        }
    }

    if (LqrrdPSsZ <= -296500.78117478004) {
        for (int JcRIR = 618345865; JcRIR > 0; JcRIR--) {
            LqrrdPSsZ *= LqrrdPSsZ;
            LqrrdPSsZ /= LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ /= LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
        }
    }

    if (LqrrdPSsZ > -296500.78117478004) {
        for (int TopPLAlqUxlxxB = 598734285; TopPLAlqUxlxxB > 0; TopPLAlqUxlxxB--) {
            LqrrdPSsZ /= LqrrdPSsZ;
            LqrrdPSsZ = LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ = LqrrdPSsZ;
        }
    }

    if (LqrrdPSsZ < -296500.78117478004) {
        for (int XvZgvJcA = 132322947; XvZgvJcA > 0; XvZgvJcA--) {
            LqrrdPSsZ *= LqrrdPSsZ;
        }
    }

    if (LqrrdPSsZ <= -296500.78117478004) {
        for (int VWkOqbcROOLywS = 562288442; VWkOqbcROOLywS > 0; VWkOqbcROOLywS--) {
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ *= LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ += LqrrdPSsZ;
            LqrrdPSsZ = LqrrdPSsZ;
            LqrrdPSsZ /= LqrrdPSsZ;
            LqrrdPSsZ /= LqrrdPSsZ;
        }
    }

    return string("ypYdaGZNKsrR");
}

HNqxgUgtYYlO::HNqxgUgtYYlO()
{
    this->eUwNOEmT(string("jElNHHAyIeFiilMIWuaniqRlriImuwzdTtfIeXKsmaarTSPwevRaaSSvccnvJmviwTeIlwHsblTESChUovFTIzjOwvwHBiNoZEsUTPJKIXIpWtdEzeTaZnIkkeeyivDRYvECoBOuIsQgnuUXmPEydZJzBsyMzIzwTGGwSoXHXwdvHZTOdBDjVkxOyStFlBPKNOKfF"), string("KmLGEsAiWtPTrUvFKdJyZIbzvcGyqlpDcYXiFSLJfYaWmqwtmZUVfJhghnRWPKlQAtlsVwNMmPRBiavusZMfUVBIWsrhXgGxFECLAlmuaEXprDJhkpZVuOeHIIedLJYdWKnefUOIkNxKSkZfyBGeQNpjFCEZWxNTVaVPqbyHjTtiHOunnRguhSKmtYXmCRFvStUpysmNLzkKWHxNqQjOYfRtjuJqVcievGDkFLMdlugtDqfsSXbidWArUqdcL"), string("vlsfEEeQBmXWGpaduLwbjKkNntMBwWvABmmCtkAGFdquYJhUzVCOoAlfGeizdBRybLywqjfhGxNacBSqVZpISupZNWXrgzAdIBlcCedeUpjHEqBJwHHbiVhBmZwUo"));
    this->IuZlZcOKuUMpY(591071.9138812574, -677792311);
    this->MmXGgioXIIND(true, string("EAwbBKyyZeRgJlWFzfiaflXaLbcsJFqoMxSnjfNvDhtcJIETnIiiuncGZkHWCSniibxfRNvUPNQfILQHdoWXiCDqFHZiPKuEHMtzWzhabCpIEMDWVWBeGgghxByscELsjTaFKFHyTHmHXIkKIDosJucOqlFetsiFHZOJkqJAffljaGIQnRXtQiyPMHkbDLyFpCmgXVsbUhOwXYzBR"), string("XXsoukLRCAUZpvzEnmIVypDFWwxXBXBVtkjSaAzgJJCMKlLoROKoCHtkNGdgZkpkTArERJSUDa"));
    this->UCHZITRbPmKd(string("nIquyksBEfbhCkpdyDFtublsVobcpwkVGoYbSZAFYgfvRJNkGzxITJAkWyKxpOBKvoYxWpUezQDpoIeJhNQhueZXmupkmtorxvochTAMvvenKAXuUGJrCSu"), -1619923846, -1344617398);
    this->GJBxINF(string("CLVkGbGSjrSJWolYhCPZoIBTeyrgTjaWkhIVYboBbAgWlTDxOfukXuMOIDdqq"), string("hXIDALIHm"));
    this->SqzsmhvjPcgFso();
    this->QNvfCXA(-1632742145, true);
    this->KpiHInDmIyzhk(string("VwqPUXRSjfGWpOcKFKzHlSnkxWONaFYAreLRLfZdPAJpSWTkFsFdMyjZlOHMJpamfjxbMWUCVPiAKqVJfFffLODiblziLTLULhbsvgeQTCIrIDZFLvMSkeVClhISROPRuPOAfFtapFgsPxvujbqgqoMYlUwBaXINwrlZSCHbbUjSBcxwjzAXEnNZDjBeomnRuQSYUTeNXIBJPaE"), 708219.2751588201, true, 899613.003900453);
    this->ohJdZHkTDguz(true, 175243930, string("krsfrObDwCZrcisEsDsBJZSzhksKnHRWnRYKTnhwcHXbmbsgKlNyoMmtBvBp"));
    this->iBVnkZyi(-681261309, -1437709907, string("heyujyLbzdXUeYORmzzMnGSIjlm"), -732615726, -1195703931);
    this->ZprcfjSeL(string("cujeRMQonsiXfezrPiyVWLTMfTrabrTFmtLmVqVPJlBATUTuvChjNBJhIKMJMZsKmPclvVVIFmpbVBeliaZcQOZosYdUMymYUdOMPHSEBDTkEKQGiTBdqMRfYJmXBTxIqN"), true, string("mrJKlSEiOpAXDZdkRegDpylkysIkcBsYYdJNwCPuUhFXJIMBWYSozSrsfOanUCuFvHzmHEkVglDmucpNPANjlWjfsctpSoTiJUuovIdbkKhrWrmpNOFDQKsapCmoqnGhslvKDvqleRHhYoBNjJcHJHlfzJNVWnlExCakRmcoCIdtkeqaGSUXynXCbbYKmlSTnaHMMPiKBkpIcmDNLZZDMotghcGhPMBLsMXUyLylA"), string("nqgsAsUNyaeQGoRKkYeFQypKEIZwZAMynLuqZuuBorXxaaJUuEcFQiZRthuoSRtKsSuhsLsMBtxcjNsRuHpwHJnooJumGBPEXYCrwOuWiAUgZpIcYgDODlQrsTAuuCgTz"));
    this->QPBXk(false, -379976454, false, -391714.10331071017, 930377.373077647);
    this->FQVYEPRxBSSbistB(string("oLwlnpGRieJNMKiyuxoeawbgXxwGhlkaPfEAKfiAYWrNqjOUrHRPdlNRlCiKLLySFKkJMKiFzHXkMjHpuRgEISQAecVhqNKnpZwngUxNvZhPLozJNrMrWejCLsswUHJeACRtNWlwWvfeOfIDgd"));
    this->RdpIOe(1181479195, false, string("dqfzrggcwCxBoTMlpoMEDwARsViXVwjVZufTzQEuiRKKXBxByPEAWWjusHawWlDugHiNbpKVuFgAFlFSEcZjUvnbJejmVtmmhLUMwRWqCbHMWhfaPGumtmWsfSjDNKhWHphLwWwaCeDCPeDGItNJebNKhM"), 699000469, 1312308673);
    this->yZpTHZcpYtl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uXQFdrvS
{
public:
    double hkIIpdQnjMWY;
    double dqkce;

    uXQFdrvS();
    bool YEmAzK(string TummLuCFzxuU, bool gkDUeyu, double APaKepAoRoUKsL, string MUBZsSXooWODBt, string wigskTjxRJmOSstH);
protected:
    string iTTKM;
    bool fCvOrJTJhpGVeEC;
    int TbgccENF;

private:
    double oJNLefus;
    double fldvQk;
    string aLVzuLBapw;
    int ijiVpS;

    string uRXOyUIJDmI(string PIhsEPDUz);
    bool MCbMleOd(int JpfHV, int uvqJdG, bool oBtcK);
    double LDSsWlT(double hXnYhT, double emqJTaIdaNyfP, string YmcXvGJlBltciIbl);
};

bool uXQFdrvS::YEmAzK(string TummLuCFzxuU, bool gkDUeyu, double APaKepAoRoUKsL, string MUBZsSXooWODBt, string wigskTjxRJmOSstH)
{
    string tBIgXNVTl = string("mhrHvkqKNRekuUImqPovoHjpwHfvLkWKOUhYUHudYDrUDcCUeCvUTzVLbjQVpHXMvdlHwtLHclznRZEaWNBVZwDpvYNfbcmCKgXPprYsZucWvSachVrZhijXHcCuDwYEMqAQeXiANLkrKHbNQiADYGgAyRenXhYKSZpTzKxfHkJxyTNhecmprnyUrkpKMLjgkXcXTGu");
    int BOnFtFPhKe = 659239911;
    string CcrOojaNkXcx = string("sxEjYYhNMVveCaEBurjJWOkwtdFdCCeTgLVQKsMCxLbgmaWUgMUakZqeKClmgpYaVhjiStoPuwdDYkhVqHNwShpxMvpOAiDNwvMEvkDvoSIRVxAgyZAsbRBibvFZZRchhFbYBjGbbsBHREwPnNcDjfWuuoWJk");
    double Yifqo = 585450.957120563;
    int HnbGtGzKg = 932033484;
    string VptzH = string("zYCtextRSxwUlBpewjtkkVvThNhpSsKEVbokBXZSnwuhKEXlUiHkTwVgmWVrBjMGjKLzZfuTsLrIzOgNvZtIJMOtM");
    string NmzbXWlEogVUQSip = string("ctTkwxTDQohEReLBmghdwrrGjSCAylqLYwTaGEbmJQlUJUubcnQZNwJlTVVKcqTEBWpQSsAAnqzfYibXpVnGHvAHeVCjYUHqFfckMrJIsIUaYEtiOwUzzZPfmrnNurdMFSqIJcWYRoEKyKeteNIGGjmQcnVgtcTfboakrCPNtUDZOTseIam");
    int pvQHvl = -1008714331;

    for (int lHvnNqeldUtCVP = 1422505723; lHvnNqeldUtCVP > 0; lHvnNqeldUtCVP--) {
        CcrOojaNkXcx += NmzbXWlEogVUQSip;
    }

    for (int lkcyYeadJQz = 1478410020; lkcyYeadJQz > 0; lkcyYeadJQz--) {
        tBIgXNVTl += NmzbXWlEogVUQSip;
        pvQHvl /= pvQHvl;
    }

    for (int WWkalIUhBXVpG = 1989576608; WWkalIUhBXVpG > 0; WWkalIUhBXVpG--) {
        APaKepAoRoUKsL /= Yifqo;
        VptzH += NmzbXWlEogVUQSip;
        Yifqo += Yifqo;
        TummLuCFzxuU = wigskTjxRJmOSstH;
        CcrOojaNkXcx += tBIgXNVTl;
    }

    if (NmzbXWlEogVUQSip != string("sxEjYYhNMVveCaEBurjJWOkwtdFdCCeTgLVQKsMCxLbgmaWUgMUakZqeKClmgpYaVhjiStoPuwdDYkhVqHNwShpxMvpOAiDNwvMEvkDvoSIRVxAgyZAsbRBibvFZZRchhFbYBjGbbsBHREwPnNcDjfWuuoWJk")) {
        for (int muDQEnd = 1037110339; muDQEnd > 0; muDQEnd--) {
            CcrOojaNkXcx = CcrOojaNkXcx;
            VptzH += CcrOojaNkXcx;
        }
    }

    if (MUBZsSXooWODBt == string("ctTkwxTDQohEReLBmghdwrrGjSCAylqLYwTaGEbmJQlUJUubcnQZNwJlTVVKcqTEBWpQSsAAnqzfYibXpVnGHvAHeVCjYUHqFfckMrJIsIUaYEtiOwUzzZPfmrnNurdMFSqIJcWYRoEKyKeteNIGGjmQcnVgtcTfboakrCPNtUDZOTseIam")) {
        for (int kDDbgRGKVDlkdFrZ = 246713462; kDDbgRGKVDlkdFrZ > 0; kDDbgRGKVDlkdFrZ--) {
            TummLuCFzxuU = wigskTjxRJmOSstH;
            wigskTjxRJmOSstH += MUBZsSXooWODBt;
            NmzbXWlEogVUQSip = wigskTjxRJmOSstH;
            wigskTjxRJmOSstH = tBIgXNVTl;
            VptzH += MUBZsSXooWODBt;
        }
    }

    for (int btkQWsZ = 1449038207; btkQWsZ > 0; btkQWsZ--) {
        continue;
    }

    for (int sPJITQoZcqQP = 296154212; sPJITQoZcqQP > 0; sPJITQoZcqQP--) {
        TummLuCFzxuU += NmzbXWlEogVUQSip;
        TummLuCFzxuU = VptzH;
        MUBZsSXooWODBt = TummLuCFzxuU;
        pvQHvl = BOnFtFPhKe;
    }

    if (NmzbXWlEogVUQSip > string("qhWGqMVqXKjgDWrwfkcpwrRddMoTEySCCREqYiXZDKlSovDjLecAYvkuksYTHpEWQmoVSiEENASvRngtqtBvjmxwpSTeFQMvMvTtYrMWVKyemXVOrTgYzRDeQadsDjoWyPiTg")) {
        for (int LmCtTozzAeoXir = 244172105; LmCtTozzAeoXir > 0; LmCtTozzAeoXir--) {
            TummLuCFzxuU = VptzH;
            TummLuCFzxuU += VptzH;
        }
    }

    return gkDUeyu;
}

string uXQFdrvS::uRXOyUIJDmI(string PIhsEPDUz)
{
    double JRSRWIDQXScZNcNT = -577316.6269222406;
    double biFgDLwVqW = 938550.0535720558;
    bool eACWuKVDghcoq = false;
    bool mkTQGdndnOSNW = false;
    string UZueZmVfknvN = string("ZBqOOVfVHphuBHAOaYHQDVNytMaBImYduzUiVNJexNCxTtWhnUzLYHmJkjBIeJSiYWnxAGPddUQpMwYMvHtPtTOtudBLRmxkaExBvNwlaJNzocEnaBgHFtMZHZkZryqWcVxnFFLqMwwOliZJIsVsKbzKCTYtHdYULxGuajjCmRNjkHkFZWBSCmgVksGEUpGaHwwi");
    string slttW = string("QlBPtIbGDtMbyasHyEaaZsPZcqQzsQawKPrZKeflWNFuetHdMopzkIufJ");

    for (int sMAAJHWzdiTMOifP = 1075581712; sMAAJHWzdiTMOifP > 0; sMAAJHWzdiTMOifP--) {
        slttW += slttW;
        UZueZmVfknvN += UZueZmVfknvN;
    }

    return slttW;
}

bool uXQFdrvS::MCbMleOd(int JpfHV, int uvqJdG, bool oBtcK)
{
    int RYAWUM = -483545360;
    int KpSGMpcNq = -964999660;
    double yKaznFKvZ = 933897.6487730489;
    int SMEbYnz = 694933925;
    double TJVovzfYZcqKrep = -1017149.551317693;
    string ciTXkpolX = string("cElhiUkTqdQfhbktkAQSwUvktppyaHLkQtzkpwRYEbzIJwDjjzUabfYvFrBaVyTPWwMjZULXZfwOPNYYJJzPIQPVPluSIqZLRGUdiwBQzArOMjihQBnAcOTUCNVipLzEMwbCibFBRzxWiGPaTAycYozcugvrSSrHZPeSZCyelrEjrVDGzcWftOWyUazgEKhYFyCSqPnFevxEIduRcPiXYypvwky");
    string lOZNtp = string("nItFQkXBBokMgiWWrdKDiJzNWxTxUmjOooElssNMbWVfYtqkVmDsPgqKiTSEbnYkQjEazXYyONLVXuXYyQORUvElRdkAsngiBGprfMScddafzaJhPkegnnpnVOlnLDtKEMVPuNtOdXCYvKCXusdWHbupNgEoJpbAOTrKpqOjBpOKECalNhHViLfUzAPJamyUcpzQfhytcKvdDHGHdkFXQIUozhLoygBSlLKvMutj");

    if (KpSGMpcNq != 694933925) {
        for (int xGyKiGuzKbymHo = 917849507; xGyKiGuzKbymHo > 0; xGyKiGuzKbymHo--) {
            SMEbYnz += KpSGMpcNq;
            uvqJdG += RYAWUM;
        }
    }

    if (lOZNtp == string("nItFQkXBBokMgiWWrdKDiJzNWxTxUmjOooElssNMbWVfYtqkVmDsPgqKiTSEbnYkQjEazXYyONLVXuXYyQORUvElRdkAsngiBGprfMScddafzaJhPkegnnpnVOlnLDtKEMVPuNtOdXCYvKCXusdWHbupNgEoJpbAOTrKpqOjBpOKECalNhHViLfUzAPJamyUcpzQfhytcKvdDHGHdkFXQIUozhLoygBSlLKvMutj")) {
        for (int ZHknZItqwPe = 866649822; ZHknZItqwPe > 0; ZHknZItqwPe--) {
            RYAWUM += uvqJdG;
            KpSGMpcNq += RYAWUM;
            JpfHV /= RYAWUM;
        }
    }

    for (int CtgifgNEnNJQ = 275084762; CtgifgNEnNJQ > 0; CtgifgNEnNJQ--) {
        JpfHV /= SMEbYnz;
        RYAWUM *= SMEbYnz;
        JpfHV *= SMEbYnz;
        SMEbYnz -= KpSGMpcNq;
        TJVovzfYZcqKrep /= TJVovzfYZcqKrep;
    }

    return oBtcK;
}

double uXQFdrvS::LDSsWlT(double hXnYhT, double emqJTaIdaNyfP, string YmcXvGJlBltciIbl)
{
    string cHGxBZGtLwHkPE = string("EyNqhiEXOgVoFIXfXsdrcnimmnxLOMgOmpvnjyFFVimztvJCQRcHpqHjfADFySOcYVzSxgvQrZCsDrpVPnCPiYEVVadfTxKlPMLMJDSReGiUcASqxXuKzTGnySnZkIfwBrYnaUNkqXTogCTGkKsDtTvCsBzzgjDsViMysuCByLzGKEwzNqzyCPWIdmehPhrWwcBThCDmtsFznlSiTjnaiAgTlwrIakbKEEArQrAtfkYRXdwMBuutyMUjAn");
    bool bBBBWpkV = true;
    bool iJcIOsraTAWvAXEl = true;
    int yAAZuuec = 1843858508;
    string rHkqQ = string("tAowMQppcYhnEzjvFipKVUAgmYqJBoMZEiKPcNwLnOYglQfNawcQbKPZfVoxBrtqMhRMhfFoIUTeZofZbiWollwutKPralSuqTtHPZVNHzRPDcvLlIYQDVSmUdVlhxJNTpEwgNWZHJOVzLhGvmJENVsVqYeleXhAnOXPCGmocL");
    int AARRbJZBxMTYrtP = -449414511;
    string KvGqbnQzRvGng = string("hnkmUXBMpjuQjggJqGmtIwCoFtYRMqTtIaTjtDOwBnDbARAzNeEzqqriVZVNXJiiEozxBrFUGtGZIiXujuhRyVmYyZmvPbbSqUnCkVStaqMrLfcucdebfzLsGRURmsAgvfKLMFVEYNcPIiIWHcFHFmhZihVkHwCwdiNEbCCriqjDnyGuhhkaLEHdUXZjIWTerbqFAjirRuRDVmxPVRYtkZGMzZVjTwxTDEZnKKKWmTmeFXMbC");
    bool kojIJkMIsrPwNDh = true;

    for (int beYqteF = 1811396484; beYqteF > 0; beYqteF--) {
        bBBBWpkV = bBBBWpkV;
    }

    for (int YUpuiiuxi = 2102283959; YUpuiiuxi > 0; YUpuiiuxi--) {
        continue;
    }

    for (int xCIEfdumb = 437369983; xCIEfdumb > 0; xCIEfdumb--) {
        continue;
    }

    return emqJTaIdaNyfP;
}

uXQFdrvS::uXQFdrvS()
{
    this->YEmAzK(string("HYUNwRVvvyfXsphQXMOLESiTPoZCERepuiIrHzMlMoAFeiiIrUTgkBhOQaTrLSewskzRDoZqYsepmehPOzzRbLfHniscytwSAASzqEfqM"), true, -776810.7780751785, string("qhWGqMVqXKjgDWrwfkcpwrRddMoTEySCCREqYiXZDKlSovDjLecAYvkuksYTHpEWQmoVSiEENASvRngtqtBvjmxwpSTeFQMvMvTtYrMWVKyemXVOrTgYzRDeQadsDjoWyPiTg"), string("VwrXHJvqMvuYUgTcRgXwMXdVOIBPaVXvXNAlUJLUBLGgllVEAGZVUAvdtYLDFhqGN"));
    this->uRXOyUIJDmI(string("XccqlIxIWIAaANgrCLzAnDjPOMEeFvOAvrzsEOzcAfPkQnWmfOtasauSGUxiymtfhbhmpbWQGxazYUVixxRPpfLLdbTIeaZTyGBsJmdziWtCCXdfGBGTxWLBKulQMjIIbcdQzkHCBZ"));
    this->MCbMleOd(397770808, 717142089, false);
    this->LDSsWlT(348678.0003534725, 769079.5290332077, string("HcJCKzDnQpyEgfMpODTKVIgaTrQXIwzUexNQaulVhCdlvcJOfWGnnDUjqFdUNLaIJKpYHFQTYKZdzLHsrUfWDEgQZXQnSfQqrilTuZUHOaNgwKkoIjCxsDKKtlmTzOMSxhFwWDoKQHYVYjIjxBLlYGPOBcdxKTJYfGNMMiYCHpXAMCSPetPRXwuqvoZVWOeZEJyWIBSGpWCEwrVruxREwsgyhFckVlFBXSQMcAxETFUCkGpYqGInCWMcoNt"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CqpUntlS
{
public:
    string oXHgC;
    string aBQIktTxGRfc;
    string AHDWIYhU;
    bool ukyCDXPTdDwUuRI;
    int KGhXOopdNmLzbk;
    int QlAnqr;

    CqpUntlS();
    double OxjtDNcnWWpCDs(int rDmYsfUpCOby, bool GAmzqMIQBk, string ilJTCaaIWS, double lDBcKcGnlYI);
    string YGgegtr(int FTBArt, int KjRaOjwDqypJJogS, bool POOdA, bool ZLGsBSpvSR);
    int mmbSzauUvWUrT(double NONYeiDy, int GzLrMiGjeIWJi, int mZuSpTzCK, double mMHlCIpmyI);
    void uXFqwDCPnqESzT(string QJCuHVtaLdw, double KHnBJuYHeSjpDLEc, double RBgFKJyDVwwv, bool LjPRrrAj);
    int mVEhjCfmGYlYV(bool BXVBN, bool aJYDs, string wSDObByqUFjwmX, string uqozbqrsk);
    string nnxwILgNJvmLZ();
    double ercrCIFBt();
protected:
    double kYVTTQEfBoNsNvQY;
    string UXZVQQ;

    void WvUFfmagjq(int MjwYhGlNOwBKgyX, bool lsDAqskvKuS, string HXYCHaaxsPkupz, double OLJoQOpmUER, int xeDrcfGWW);
    string mUEizVpFNxB(bool mhyqWvKpB, bool MkdRiO, string ftSHeYMVMi, int YhOVRoatEeoXP, string OVnGXKnzau);
    void lTJZzy(string HxUhsb, int hDWuVt, string WFtmoqiEtGwRtLK, int QCnBEReWZJAWTO, string sKWprLTUBjFVKFr);
    void DBYmDboRxJnFN(double ogKaQqT, bool FgTveGru, double nXEajvlyMvuuqmK, double uQiVP);
    string cIfuGVyzheRL(string WEZhESDQkAfNg);
private:
    string TwxFndMbjxeJNUb;
    int OrinLgup;

    bool UAjWIledingtcTjk(double QIXymQFHVDDK, double zuvPHf, string tmqIe, int JdnlXzsV);
    string SlFzEqtypavp(bool xEcHuXUiYZIUpB);
    string QtZXUJoGUBL(int WEIevIho, double IZHYxnFda, bool XPhwC);
    double VuLABRErYr();
    double KeQtFcANr(int xVepCKDdo, string hZJeCL, int kbqkehpQDqGgctFF);
    int SIeFDVKQoHpz(string yUGgUcpuSNzEUYNa, string OMmVgQJOQsm, double aDqYvW, int AbPmNnuSfyFd, double udtBequBcRUywYwx);
};

double CqpUntlS::OxjtDNcnWWpCDs(int rDmYsfUpCOby, bool GAmzqMIQBk, string ilJTCaaIWS, double lDBcKcGnlYI)
{
    string SohTgrEFzNZZrO = string("SVotTYOUkcjEYGsWNDpSZBicqSqAEaSGGyxNNcaZPuAPgHjMwUixMQdlFhroENdfQvFiiWiLPRaYlSqigELbfRWChQuBmeYAIFbUJuyRylkWWnJaDCtrTGawGFDuJksubbuz");
    int CGZMJGcz = 548094827;
    double hyEHClc = 471530.6750734032;
    int oyUbnKxyfHTwqET = 1829568248;
    bool NDQUxuTnBbmoH = true;
    double IlePMxDG = -333017.82827964344;

    for (int KVHvVMSUKmukw = 1729997055; KVHvVMSUKmukw > 0; KVHvVMSUKmukw--) {
        GAmzqMIQBk = GAmzqMIQBk;
    }

    for (int cmKKA = 2114782253; cmKKA > 0; cmKKA--) {
        IlePMxDG -= lDBcKcGnlYI;
    }

    for (int fTSOiFrwzdZPMh = 322142097; fTSOiFrwzdZPMh > 0; fTSOiFrwzdZPMh--) {
        continue;
    }

    for (int nxhKz = 1836375178; nxhKz > 0; nxhKz--) {
        continue;
    }

    if (hyEHClc == -613744.1848784147) {
        for (int GAiFZdAJVueE = 1823143094; GAiFZdAJVueE > 0; GAiFZdAJVueE--) {
            continue;
        }
    }

    if (oyUbnKxyfHTwqET < 548094827) {
        for (int DEebF = 1123326752; DEebF > 0; DEebF--) {
            continue;
        }
    }

    return IlePMxDG;
}

string CqpUntlS::YGgegtr(int FTBArt, int KjRaOjwDqypJJogS, bool POOdA, bool ZLGsBSpvSR)
{
    bool gzqSkVv = false;
    int tCveBpcm = 1881676516;
    double silZRlSNhfFSvwKL = 960089.1784418842;
    string HXmDp = string("CVQDfgqNdgjBQXARJaVfMhmIyWerkJxrMEtJXtuNogQNriLdxlNqiIGLCpgYDdZYmgvVuiviGXqBrqksiNCdvvHTQpwnKEZPmJqDtFEXIOShjaxnmBjqKiWxSpDiCprKocSfxMpKQiWCaUCfjJDUlgGyzuGZxAtyTYojWcizgypyZzmHIAstRvpEJOzOu");
    int fHiym = 1647987363;
    int Stljx = 260552845;
    string AFbpqnrVKet = string("FePzWTvcjWdePUSgoKsCqznORuSa");
    string tyxkYbn = string("EcYCtGCWejroEJMrvjwYKasQBuspcIodcJKhyLmZeZOJhIlPmAHITXrItbbuloONTaVUGQDCLtuurIReqpVGtkwkreWLgLREDD");

    for (int hCGFBGtu = 1459947951; hCGFBGtu > 0; hCGFBGtu--) {
        KjRaOjwDqypJJogS -= KjRaOjwDqypJJogS;
        fHiym = KjRaOjwDqypJJogS;
        fHiym /= FTBArt;
        FTBArt *= FTBArt;
        AFbpqnrVKet += tyxkYbn;
    }

    if (HXmDp < string("CVQDfgqNdgjBQXARJaVfMhmIyWerkJxrMEtJXtuNogQNriLdxlNqiIGLCpgYDdZYmgvVuiviGXqBrqksiNCdvvHTQpwnKEZPmJqDtFEXIOShjaxnmBjqKiWxSpDiCprKocSfxMpKQiWCaUCfjJDUlgGyzuGZxAtyTYojWcizgypyZzmHIAstRvpEJOzOu")) {
        for (int KeztwABMCnnxPzz = 1991807531; KeztwABMCnnxPzz > 0; KeztwABMCnnxPzz--) {
            KjRaOjwDqypJJogS /= FTBArt;
        }
    }

    if (gzqSkVv != true) {
        for (int iRoDNPncVqx = 891650115; iRoDNPncVqx > 0; iRoDNPncVqx--) {
            continue;
        }
    }

    for (int LqGzy = 1932195137; LqGzy > 0; LqGzy--) {
        AFbpqnrVKet = HXmDp;
        POOdA = ! gzqSkVv;
    }

    return tyxkYbn;
}

int CqpUntlS::mmbSzauUvWUrT(double NONYeiDy, int GzLrMiGjeIWJi, int mZuSpTzCK, double mMHlCIpmyI)
{
    string kWQHaHgmZfmBT = string("IxbeoiatnILscSlEJTzHnfPRqFruMumRTnaGUChBIP");
    string aussOOTAUkkUCSg = string("cdbbbiDVetSPzQzsDnxRClPckOLFGvVgOIqudJLrgDgWonBrkcADqEOaoGulaNUTsmidUvQKkNNUxguenlhIbmOsLGrzadSZYYgZFzTEzrLomphwcrGDoPXBaUkDmXZVGAHBudcHVgEIuKGDawslYlhcnwFwmuCdEDDsmHNLFOOZsQyGhcauSWfmIlcpjHMWRdilnkauhzZdAWgYhGDjQkTGQKsahkobNtcmlJgVlUmHyknZ");
    int BuCMcrMBNvvD = 1924872055;
    bool XGFcUAz = true;
    double uiVvQsVMesXWIHS = 189124.14328209092;
    bool XhJrZomn = false;
    string AJXleMtvPfzKyqd = string("vFzFzXTAdoEDzbCgVJFANVKeEYVAPBKFpCYYMZcJGmoAgZouKvdWHeekYrzloecCvrzSyOSGXQNswpzkVvRazoHnasCilvQLZwkhSvricVRUWaEHGvLbhQBIalEPVsztGAJPSWTZqxmXIldUKLVluV");
    bool TxdlvdJTGhyw = false;

    if (kWQHaHgmZfmBT > string("vFzFzXTAdoEDzbCgVJFANVKeEYVAPBKFpCYYMZcJGmoAgZouKvdWHeekYrzloecCvrzSyOSGXQNswpzkVvRazoHnasCilvQLZwkhSvricVRUWaEHGvLbhQBIalEPVsztGAJPSWTZqxmXIldUKLVluV")) {
        for (int kKNVDDdDbPJTGNh = 100750565; kKNVDDdDbPJTGNh > 0; kKNVDDdDbPJTGNh--) {
            uiVvQsVMesXWIHS = uiVvQsVMesXWIHS;
            GzLrMiGjeIWJi -= GzLrMiGjeIWJi;
        }
    }

    for (int OQUtsQShJj = 347681093; OQUtsQShJj > 0; OQUtsQShJj--) {
        kWQHaHgmZfmBT += AJXleMtvPfzKyqd;
    }

    return BuCMcrMBNvvD;
}

void CqpUntlS::uXFqwDCPnqESzT(string QJCuHVtaLdw, double KHnBJuYHeSjpDLEc, double RBgFKJyDVwwv, bool LjPRrrAj)
{
    bool tWpcxQb = true;
    bool rNolVqcSXijqm = true;
    bool kXuEGZnqHSCmQ = true;
    string BjJzDUEIvIZFaP = string("OxKpvemvZpdtJxBVwLxPKlmSNIMDpSQPAMeUOzcRjfCrkwVtSgLJGlctfWnPnZarr");
    double sAatgamLOtgss = 339795.2222337048;
    int SNvBvfpa = -1027277697;
    double EoaOzABOYVwfKu = 620991.5498105842;
    double HwcRQfb = -883598.3109955568;

    for (int aJZximyuOtT = 1323447536; aJZximyuOtT > 0; aJZximyuOtT--) {
        KHnBJuYHeSjpDLEc /= KHnBJuYHeSjpDLEc;
    }

    for (int AmVXYvMPHPzTzp = 1596000819; AmVXYvMPHPzTzp > 0; AmVXYvMPHPzTzp--) {
        sAatgamLOtgss /= KHnBJuYHeSjpDLEc;
    }

    if (EoaOzABOYVwfKu > 556145.5281637425) {
        for (int ycQhbkQu = 392503937; ycQhbkQu > 0; ycQhbkQu--) {
            sAatgamLOtgss /= HwcRQfb;
        }
    }
}

int CqpUntlS::mVEhjCfmGYlYV(bool BXVBN, bool aJYDs, string wSDObByqUFjwmX, string uqozbqrsk)
{
    bool cHbqCbePh = false;
    double QBcxARBQaVzyQ = -52857.797317519624;
    int lHikmdtE = -312453667;
    string NmeoFqhR = string("ZfVrrEpQWsyDtSYAMOGWtpDyprREzVBXiwZRGdPnATcKucQWJyBwJHQIohljklSPRbvFSDDORepEXzmSiZTCEYqrzWxixJjnQzQtfgSWmzlDoViROhSEnxRtvEzBBXdmiZPZYjcCQELz");
    bool drzTjOX = true;
    bool MyNvykyKbVFkp = true;
    bool RaJBRqtBUApuDC = false;

    return lHikmdtE;
}

string CqpUntlS::nnxwILgNJvmLZ()
{
    string rBYGsnEKOtoY = string("zvScNlIFZqHPxyllvrAGsvQAmlRhkV");
    double pLnlcEeRo = 631151.710420674;
    int fcmAqDsCAHnxyp = 314614805;
    bool wvpYdzsXMhdrOIr = false;
    bool hRJoBc = false;
    double qcvDm = 537115.8373856352;
    int EAHZLAZ = 684718546;
    int IAVfVAgyJKnEvGC = 1590552039;

    for (int rUpQQWQtWgHOsYs = 1510870173; rUpQQWQtWgHOsYs > 0; rUpQQWQtWgHOsYs--) {
        IAVfVAgyJKnEvGC -= EAHZLAZ;
    }

    if (EAHZLAZ != 684718546) {
        for (int nvnqCJPmP = 130528026; nvnqCJPmP > 0; nvnqCJPmP--) {
            EAHZLAZ -= IAVfVAgyJKnEvGC;
        }
    }

    for (int VjEnZ = 2106389653; VjEnZ > 0; VjEnZ--) {
        continue;
    }

    for (int DFuDwEFNcqzYmU = 2093249483; DFuDwEFNcqzYmU > 0; DFuDwEFNcqzYmU--) {
        pLnlcEeRo /= pLnlcEeRo;
        qcvDm /= pLnlcEeRo;
    }

    for (int iolOcjcwmAvjSV = 1530265962; iolOcjcwmAvjSV > 0; iolOcjcwmAvjSV--) {
        EAHZLAZ -= EAHZLAZ;
        fcmAqDsCAHnxyp *= EAHZLAZ;
        fcmAqDsCAHnxyp /= fcmAqDsCAHnxyp;
        IAVfVAgyJKnEvGC += fcmAqDsCAHnxyp;
        IAVfVAgyJKnEvGC -= IAVfVAgyJKnEvGC;
        qcvDm -= pLnlcEeRo;
    }

    return rBYGsnEKOtoY;
}

double CqpUntlS::ercrCIFBt()
{
    string OEFeMUnaOsmYtgVH = string("GqMkMulNIIDAOQYUYcpDBzxKfzRTwiBIkoKrvTmATODwtcxAHTEqbOdbQZoyXSfLlZPbUzYKikCSTAXuFWkvbvqGzMIxQPeoGwPolBxyXuSambpiUEoapQAJEGASkI");
    double gWpFUrN = -611408.1866686322;
    int yPhVY = -1501474996;
    int BToqzhl = 1146302147;

    if (gWpFUrN != -611408.1866686322) {
        for (int boynSwpgOTEqt = 2106895712; boynSwpgOTEqt > 0; boynSwpgOTEqt--) {
            yPhVY *= yPhVY;
            BToqzhl *= yPhVY;
        }
    }

    if (BToqzhl <= -1501474996) {
        for (int qACowjjO = 310591198; qACowjjO > 0; qACowjjO--) {
            BToqzhl += BToqzhl;
            yPhVY /= BToqzhl;
        }
    }

    for (int VcbjSkqDmHtXEH = 824426122; VcbjSkqDmHtXEH > 0; VcbjSkqDmHtXEH--) {
        continue;
    }

    return gWpFUrN;
}

void CqpUntlS::WvUFfmagjq(int MjwYhGlNOwBKgyX, bool lsDAqskvKuS, string HXYCHaaxsPkupz, double OLJoQOpmUER, int xeDrcfGWW)
{
    bool SEgFjrcPbeAzBOi = false;
    int psQkfAEKDOo = -1167676205;
    string bLgIOuMHHgf = string("rXVzQaAiJHnhDYZqRiiHptuQ");
    string iULRHPWaMAEb = string("GxKIohOSbbQLzFgGAEFOJtmTXLGvSMXdzpjMHSaYiXrOvSzigQHRnduQsFszclaSZFSsFgpMkQeYsoZxZuZMxnClWPpUEFtTTNjVzEQWGdPeQwvOVAOzXldJDhQLjSxwuBjsdxBNfkGegiVezGRSPASnSMXBmUinRWMlJaGFTrMBpnOXSDJOjlluBrHnMFsqqtKWzyNHCizZwZVkWBBQSVDhsqjjg");
    bool fpqQYrsTDLRvqFkg = true;
    string hsDJZoE = string("uJszWcGktepIXxTQVZcSHdoiInkhMjoZLUoIfQSCWyzKNDQoEcaiVtFqrVXwMIzSXKOcMfwyaIhiOLzwVpbTSlZjFgKJOjVSZnRkMlzztDadstrbXmIqrAQNTnJGohjuarzXBGQuJlPorzDgVeihaUAnsbHzShDHZfnVFVh");
    double mOIHfFixZKZNAP = 964563.073205319;
    string exBzKJMYAefbN = string("CFiWbmQxo");
}

string CqpUntlS::mUEizVpFNxB(bool mhyqWvKpB, bool MkdRiO, string ftSHeYMVMi, int YhOVRoatEeoXP, string OVnGXKnzau)
{
    int vXWkWZuOOg = -483645581;
    int SnHxnnJK = -1812477449;

    if (OVnGXKnzau != string("wnialbAVwmJfifEAWmKlIYWwSWFNohztDVacVaIVEQzmtidwpOHCzUSfOivbJciDAKAzOtsevwNjuGCieTCBB")) {
        for (int TqiJjgipWFN = 479125431; TqiJjgipWFN > 0; TqiJjgipWFN--) {
            continue;
        }
    }

    if (OVnGXKnzau != string("FEqRqNFnlLfMFiAfjmzRqrfpDLVQdISTmduwLBDQdaqaUsDnsiRzvTQLKySbHeSwXDHAVekPXkqdcWkLmQgqYLnJCKvKoweiPVqTHIDZGXtEYmBwPOPfgqHBKI")) {
        for (int mMnFAwcaZGPMK = 1638294064; mMnFAwcaZGPMK > 0; mMnFAwcaZGPMK--) {
            YhOVRoatEeoXP /= SnHxnnJK;
        }
    }

    if (SnHxnnJK > -483645581) {
        for (int AjixVWVuroVuQsfR = 1190241367; AjixVWVuroVuQsfR > 0; AjixVWVuroVuQsfR--) {
            vXWkWZuOOg += YhOVRoatEeoXP;
            YhOVRoatEeoXP *= YhOVRoatEeoXP;
        }
    }

    for (int TorfFhnWt = 1986868362; TorfFhnWt > 0; TorfFhnWt--) {
        SnHxnnJK += YhOVRoatEeoXP;
        ftSHeYMVMi = ftSHeYMVMi;
    }

    return OVnGXKnzau;
}

void CqpUntlS::lTJZzy(string HxUhsb, int hDWuVt, string WFtmoqiEtGwRtLK, int QCnBEReWZJAWTO, string sKWprLTUBjFVKFr)
{
    int gkxhefFED = -482575548;
    double jVKCviQsUjJtE = -414784.36124065967;

    if (HxUhsb >= string("QUIUjnEievthoMcLilmibFHDi")) {
        for (int PeDBCvAI = 606835433; PeDBCvAI > 0; PeDBCvAI--) {
            QCnBEReWZJAWTO -= gkxhefFED;
            gkxhefFED = QCnBEReWZJAWTO;
        }
    }

    for (int BlPNAgbc = 212523467; BlPNAgbc > 0; BlPNAgbc--) {
        HxUhsb += WFtmoqiEtGwRtLK;
    }

    for (int EDoXAbMEkrMapAoS = 1532840822; EDoXAbMEkrMapAoS > 0; EDoXAbMEkrMapAoS--) {
        QCnBEReWZJAWTO += QCnBEReWZJAWTO;
        sKWprLTUBjFVKFr = HxUhsb;
        hDWuVt /= hDWuVt;
        QCnBEReWZJAWTO /= hDWuVt;
    }
}

void CqpUntlS::DBYmDboRxJnFN(double ogKaQqT, bool FgTveGru, double nXEajvlyMvuuqmK, double uQiVP)
{
    double yiiCtnEssKgpHd = -407186.2780424132;
    string WzdvANw = string("GcPQMPsEElvCeHioJEgDTCFcbAkRKfghHniNHCZIRGknBbzXDEyFEjjRxBY");
    int MTxJjMzEuX = -657916931;
    int XesKRECVPpKhYuW = 377396120;
}

string CqpUntlS::cIfuGVyzheRL(string WEZhESDQkAfNg)
{
    bool aEKmZNvQfdcsvoE = false;
    double EvUETQbtVdDJO = 551253.0389940658;
    string DUHtzhz = string("URGAddmMddqb");
    int jHBiSovJ = 829458970;

    for (int eVvGXQz = 8653742; eVvGXQz > 0; eVvGXQz--) {
        EvUETQbtVdDJO *= EvUETQbtVdDJO;
        EvUETQbtVdDJO /= EvUETQbtVdDJO;
    }

    for (int FUGQB = 1499037274; FUGQB > 0; FUGQB--) {
        WEZhESDQkAfNg += WEZhESDQkAfNg;
    }

    for (int IpsSLWAWCLz = 826349134; IpsSLWAWCLz > 0; IpsSLWAWCLz--) {
        continue;
    }

    for (int MlszSnxuOnGgX = 1474903114; MlszSnxuOnGgX > 0; MlszSnxuOnGgX--) {
        WEZhESDQkAfNg = DUHtzhz;
        WEZhESDQkAfNg += DUHtzhz;
        DUHtzhz += WEZhESDQkAfNg;
    }

    return DUHtzhz;
}

bool CqpUntlS::UAjWIledingtcTjk(double QIXymQFHVDDK, double zuvPHf, string tmqIe, int JdnlXzsV)
{
    string gYtRDqRLKKE = string("LKwVdfqbmnDBWVTHWRzpLuntkvHRuOhsuGywWJbDkNvDPxcwvWCnSpJGuAbmNUJAoXWdNNUNanauUtxvoQgLFFnUmQIKWHnLgojmhegICbinhhCgSxcLIUKPZtPLJmSWWJQulWNAPkcAVwFKnkdyqGc");
    int ZDRlQ = -877139446;
    bool ENKPQ = false;
    string SaIdHhGJR = string("hPUQJVyhTxRNWfhOdnpEYnBanxBTeBYnFRhYOTIwaqymWDFIpwvntjIkelnFMabWwQDIcpjjhLPGMsgILrrjUPPVquKtCTSBtuybSXgVQsbxKmTlmRNpZSYeSKPrYDTTrZTVpdOGoAfUlLKajNhdcjIOMfmUYzdWMEMAcZzSqIINFylHjbezVdHFoczSOGpNbjqbMFLBPXyORXmyqcwPOQz");
    string LOlWQxzUvMeb = string("CTsWeCFeJMUUnlcMbBNVXJhQnGxguXvKajzjxGZswPzguoxoBBIEBCfbANIEgBFyw");
    double qBujwJJUc = 381327.29838542134;
    string WrbQetrwsCkUY = string("IYjCrBYWgJNBZKRqDEaGvVxLbNZkokYrKsQvcaZNkKQpecQvAwCxNqcrvuQXCvVWOmYlpGvUbBQNOBppOnvUbfXIHDhmOlyhumdSrFunUaNMqjceIRaRRUCKhj");
    double QMdOWLYihOHziYg = -335294.9157168314;
    bool gUbOUpeLAlHpuCh = false;
    double rnGzTs = -719987.380546619;

    for (int xdtKPUrexhXVQEgn = 1997668496; xdtKPUrexhXVQEgn > 0; xdtKPUrexhXVQEgn--) {
        SaIdHhGJR = SaIdHhGJR;
        tmqIe = gYtRDqRLKKE;
        LOlWQxzUvMeb = gYtRDqRLKKE;
        ENKPQ = ! gUbOUpeLAlHpuCh;
    }

    if (ENKPQ == false) {
        for (int jvzJhvTkGfoKmL = 1710979806; jvzJhvTkGfoKmL > 0; jvzJhvTkGfoKmL--) {
            continue;
        }
    }

    if (tmqIe < string("hPUQJVyhTxRNWfhOdnpEYnBanxBTeBYnFRhYOTIwaqymWDFIpwvntjIkelnFMabWwQDIcpjjhLPGMsgILrrjUPPVquKtCTSBtuybSXgVQsbxKmTlmRNpZSYeSKPrYDTTrZTVpdOGoAfUlLKajNhdcjIOMfmUYzdWMEMAcZzSqIINFylHjbezVdHFoczSOGpNbjqbMFLBPXyORXmyqcwPOQz")) {
        for (int FssLTTD = 1590902702; FssLTTD > 0; FssLTTD--) {
            gUbOUpeLAlHpuCh = ! ENKPQ;
            zuvPHf -= QIXymQFHVDDK;
            ZDRlQ -= JdnlXzsV;
            qBujwJJUc = QMdOWLYihOHziYg;
            QMdOWLYihOHziYg = QMdOWLYihOHziYg;
            rnGzTs /= zuvPHf;
        }
    }

    return gUbOUpeLAlHpuCh;
}

string CqpUntlS::SlFzEqtypavp(bool xEcHuXUiYZIUpB)
{
    bool EnTXrjmopGgetP = true;
    string ICactc = string("WkBAznWnjkkjECmUNUrwoFxIEDPygRKtUIMGxsCGPasrotSTawgeGxojXfcWwcbfuNEaLdJHZZMzEkJTglOqosYpYFaKHqiGBfUQkltachdAjadAOxrZqTFAMDFCEYPZHhfKrdlEZpzndOsHjFpVCoYTruIzdDFHVQwOKUII");
    bool dkSwQVxIwGJqPAG = false;
    string mwCoVlTGuTkj = string("fjKYQKCFPnBEjgvqhhtoYDBgklrPApGfkNLDJUuCAPY");
    string TgfPkpZA = string("znOBjrQNabyCyLGDMVgLmcoPhGEisVJgdXBKocedJcnZBfLyMZvZcmoTSNWAvtkeMdjIcaPRmsghMDWKraqlIhzLFhtiPWDvGNlxIcLsmfGlmimScIvvGvQTfbxXFDYRaBqOCuNUFupRPKXJ");
    string gVdVXRbRjLTpE = string("vNjUvmjiuEEyARnQIWnrdFcmuNMYhMhdVryYmrXqZIKBbDrcROCJL");
    bool JfPmAoduxVBf = true;
    int niRUGUNiSBDHLVKL = 1409099;
    int fyIHloSDgSa = -508352271;
    int ulUfhIFGuKsjBCFu = -1399504476;

    for (int JZKcQboHw = 647061840; JZKcQboHw > 0; JZKcQboHw--) {
        gVdVXRbRjLTpE = ICactc;
        JfPmAoduxVBf = ! dkSwQVxIwGJqPAG;
        ulUfhIFGuKsjBCFu = niRUGUNiSBDHLVKL;
        TgfPkpZA = gVdVXRbRjLTpE;
    }

    return gVdVXRbRjLTpE;
}

string CqpUntlS::QtZXUJoGUBL(int WEIevIho, double IZHYxnFda, bool XPhwC)
{
    double QKfAl = 793676.8873946826;
    double QuqyRCDIhSMCu = 765001.2415576564;
    bool ZWlWXINSEFRxu = false;
    double XEHvmkxvXZBpdjjn = 515755.7396579097;
    string kBIrLkfEYGoJHP = string("lGNJLGuruWBmdWxfMudvvlCluZFFdvfPebtUfvmrLRXEHuCWcQdxDcPNydctKLwiyvIGwVbUhPBGdfahEnNCYFhnhJDFDlBDPugjxGvgTJrJdjPjmBmrRASmwcyhAITVagjamQjYitlTstRxxCPCfWyQOqbdTWfIvCfzjuWcZDhWjdNgOGlEoeFyHsOdModUKvBrjdthyjefnKGuZNyYwRznnIkumiShWdDyQsezrGqlVZjpEzhIG");
    string xwLhVJ = string("OwKbSOndyQXXMkgNcdqBfvrodqbNRP");
    string WBdpCHdZ = string("ikCNwLciIAdNuFUrVQBcTgYNsmNKGnuyxVxbERTtRKXuMtAsYsRqRaqkmybJQWAbWWqihLdvZfldnwiydShcFaSiwERcdXCYUeHTAHidlEhZjczlnepqlhvCBaEOcrLueUhcItgkRQMHMlodiTUXgHTOXfZxjQOlmtnvsazCetcFmKhbJYFRaOJuVhsWbnHfzXgNXZMvQZJk");
    string jEIOXJRlHuONRpF = string("MQIQnMEPWtZbmGeNwgiyVTWXlxPjQjYMIBnRiERcbrouWpnypDieMKuyzpaTbEspYorpFaWKuFGuFuKTKHTpetuRULbekDhUfGLdfzwyUXOhxetoOUJKRtkJDfGQZWJeBuvioWKZGAFcyTFXIJJkIGZyCAeqyryckvWRNVFzZohApclaxMeJKWaaVNoLkZJwRbdTYqxoPwEvNWYDXdHXoTalxtuWnkrnA");

    for (int wyZMczK = 158143599; wyZMczK > 0; wyZMczK--) {
        jEIOXJRlHuONRpF = xwLhVJ;
        IZHYxnFda /= QuqyRCDIhSMCu;
    }

    return jEIOXJRlHuONRpF;
}

double CqpUntlS::VuLABRErYr()
{
    int DLlXYEJNhU = -234512138;
    double uvaPbrOzJZUb = 213773.4433443523;
    double iqHuISwhurUkXgdV = 942904.8650884749;
    string xHJHFNaSfdICf = string("n");
    bool EFXAneVNnub = false;

    for (int xrfIBrqNNgHSgc = 645735612; xrfIBrqNNgHSgc > 0; xrfIBrqNNgHSgc--) {
        uvaPbrOzJZUb = uvaPbrOzJZUb;
        iqHuISwhurUkXgdV /= uvaPbrOzJZUb;
        xHJHFNaSfdICf = xHJHFNaSfdICf;
        uvaPbrOzJZUb -= uvaPbrOzJZUb;
        xHJHFNaSfdICf = xHJHFNaSfdICf;
    }

    return iqHuISwhurUkXgdV;
}

double CqpUntlS::KeQtFcANr(int xVepCKDdo, string hZJeCL, int kbqkehpQDqGgctFF)
{
    double EzZqT = 1014934.5535959827;
    double ctCUl = -354442.289863498;
    double IszFuKNd = -875282.6728739758;
    bool AuzoHqaXr = false;
    double ArleGbkEHzIPy = -694146.2596006363;

    for (int YATGFz = 1078870684; YATGFz > 0; YATGFz--) {
        EzZqT /= ArleGbkEHzIPy;
        ctCUl -= ctCUl;
    }

    for (int ZjcBllMSGUM = 781567827; ZjcBllMSGUM > 0; ZjcBllMSGUM--) {
        ArleGbkEHzIPy = ctCUl;
    }

    return ArleGbkEHzIPy;
}

int CqpUntlS::SIeFDVKQoHpz(string yUGgUcpuSNzEUYNa, string OMmVgQJOQsm, double aDqYvW, int AbPmNnuSfyFd, double udtBequBcRUywYwx)
{
    double VMziaAvTJ = 159516.90522729463;
    int tVuZJlmvYpvrXd = -208151453;
    int QCVVNhQRtAnkOhdx = -956850531;
    int HlaTCfrUqJdhg = -1711928406;
    string ykXjrFUtU = string("lmDxvWxYqZYbDKTGOAaqYuAIEMZjTrDXsIictGKuReNIIzSUmkAdlSAbkVhJYeSWyQQsjboUNlocTBaawOxLCEEItxQFBff");
    int WOzFkfmcFGCS = 715398239;

    for (int jvlpCySmAaxQ = 557546706; jvlpCySmAaxQ > 0; jvlpCySmAaxQ--) {
        continue;
    }

    if (QCVVNhQRtAnkOhdx != -208151453) {
        for (int jcOLS = 275645193; jcOLS > 0; jcOLS--) {
            OMmVgQJOQsm = ykXjrFUtU;
        }
    }

    for (int dGwEpUfroAioof = 1801385371; dGwEpUfroAioof > 0; dGwEpUfroAioof--) {
        WOzFkfmcFGCS -= tVuZJlmvYpvrXd;
    }

    for (int rtfGn = 1783967303; rtfGn > 0; rtfGn--) {
        OMmVgQJOQsm += ykXjrFUtU;
        VMziaAvTJ += aDqYvW;
    }

    for (int LmwkNAL = 1835156187; LmwkNAL > 0; LmwkNAL--) {
        udtBequBcRUywYwx *= VMziaAvTJ;
        QCVVNhQRtAnkOhdx /= WOzFkfmcFGCS;
        VMziaAvTJ /= VMziaAvTJ;
        WOzFkfmcFGCS *= AbPmNnuSfyFd;
    }

    return WOzFkfmcFGCS;
}

CqpUntlS::CqpUntlS()
{
    this->OxjtDNcnWWpCDs(1807621409, false, string("qrkbRbfYZwTCSkATSrrZqaAJnzkSRqiXhNPxdakTeRSqziSXVXGyWHLroRsgDLujpxZhskpUhDuGlJVdvfEjbMGEDmSCLwJfgAvqFQvWPPXXdxYlEOyIRVCPQKlQBAZZKgaIXjNGkleblACxJDDmripeUqPm"), -613744.1848784147);
    this->YGgegtr(660046531, -1783191600, true, true);
    this->mmbSzauUvWUrT(-702871.8898516527, 1988252366, 2078038859, -559857.1458983353);
    this->uXFqwDCPnqESzT(string("kvwXxKuwNdsDqpylvkOUuQqaiZdIPSPfyjvffNixKWXWiEPASxd"), -796811.1171089249, 556145.5281637425, true);
    this->mVEhjCfmGYlYV(false, false, string("JwSQQYkXRtkTzdcnyzJQkeATcmnipixRVghtNAwplOIcxlkdqmSRSonSklAbcQeWtcSdqlcVwPZeUUMCMYxlkPQsRxEPrAuHSqtDTOEodXNxtWeQzQqbnjGKBevzzBHbRtuelDwqzrEixtheRTehLilMvOQKjDrDaWmavpKOYNkLGmgItcSviF"), string("jZevljSJTecUkxRVKcRPyDZMxLACHeqWyXRUEOxqsLYebsxzmvDwzHfTzYMgUPjUTCTgVWAGgdBWscswjRCoiLLUWgzcstoAHutmImccxSgvOmElWitOPlLtTCIeFzFUMLMHSQyPBmnjxBmDUJcouBLDsJRZZkJHuYDqvRivgXJHIfWeKJbfOnghUUwZLnrDJmYngDseYi"));
    this->nnxwILgNJvmLZ();
    this->ercrCIFBt();
    this->WvUFfmagjq(-1745328680, true, string("uXBJCApdVtXwufOOAMQtNNpJWbckJdpnSpzrfGBrvoQvxhaVvUmdOeIqdhnwOkdCCJVKmPHEXFbpkNGwrRggJmfTSwVADXmieXuLrNQvouDpszm"), 418044.0125932393, -666215370);
    this->mUEizVpFNxB(true, true, string("FEqRqNFnlLfMFiAfjmzRqrfpDLVQdISTmduwLBDQdaqaUsDnsiRzvTQLKySbHeSwXDHAVekPXkqdcWkLmQgqYLnJCKvKoweiPVqTHIDZGXtEYmBwPOPfgqHBKI"), 385202367, string("wnialbAVwmJfifEAWmKlIYWwSWFNohztDVacVaIVEQzmtidwpOHCzUSfOivbJciDAKAzOtsevwNjuGCieTCBB"));
    this->lTJZzy(string("QUIUjnEievthoMcLilmibFHDi"), -1988165573, string("OhpPwzWrFWgOkaRCRXiBiGiViiroReHcChwiIFOKwSmzNHVZPVSxDakinDbgluYJpkxdWgifXqcrveQWXpWMHhvoqHKsJqaXjZmgPlCdkAphdSZwOSCVFUdZwcQVGPuqwFXTFmRVxLFOyrMEsThGVuMdeGBzFGLxRXcXDkWNNyfqsaelotyceTqapKvCkYiLdrKCCJLIJXHCGPjbQP"), 2046393455, string("OJTWHbNvhGmmehyMxoVPfLHJsJrFdsVeyYmgHlLthzLiMHscoMaRGbquieSEvsjjmXnmjzIXGMAzKHfOYbEHZNBJLWkmOyswdyLMEcJrpBwxTmpC"));
    this->DBYmDboRxJnFN(-511693.81684345164, true, -110471.61456234485, 762732.9678809103);
    this->cIfuGVyzheRL(string("IiMmTordBBZjfFvZxreTvnGFyOPgAwKOjAqOlSATzliiOietGWXEtZMQKzisSoEeJRZpnnqHdzdPUQlYNEiaMNBlqAUzHGFNNcwoIHCFvNdaXuMTwJLKeutOmUEEQdtyPNwsEbItzGFMDRtcnzxqccworYMXSPMFygvUVtjNFHjuoGFRmuRDGBykxxIgatQoYhtwgiiRaGAlvxeuySjzdZYfEDqLSapYaHMxjDCpHi"));
    this->UAjWIledingtcTjk(-344449.21310085274, -896967.3484264483, string("KReIgHeNfNWNoNnYYBiqMFoyFdDtgwWHhWEqRdcvmCTTMMcFJGosMOzGbJTfqAhYxBVxmqwDhlrtbnjOpeUqRaDn"), 387713735);
    this->SlFzEqtypavp(true);
    this->QtZXUJoGUBL(1520174657, -408460.10472792137, true);
    this->VuLABRErYr();
    this->KeQtFcANr(-1097531780, string("mIuPwvaVhZhaXMdKcbpqswSpTHPsGDtaSRoiHHjheNwDHFBtAtpUtDhqWqNzYpnrZweTnOiSCzMxSzUfWjEEqrFYzIXvARyCzrVLzEAWrfXAOpBrxGNtSWQc"), 1146375855);
    this->SIeFDVKQoHpz(string("RKAJJKThSGCkLfncIZnOYZKbPlohdkIHmUUJwjZRTJDKEwPPLqHga"), string("ffGSXaCeQNFtoWYeEIPTlNJzbK"), -525883.2384383221, -1696306183, 904351.6799343573);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lxfSVPVdGtdZKeb
{
public:
    string srhCZtIkaEd;
    string qiVMFwiteDvhizTl;
    double yungWSCKdbqqwsyH;
    double wQXSXPWkcLwOu;

    lxfSVPVdGtdZKeb();
protected:
    double YXZqMSant;
    double HmmjP;
    string tSMuDRqC;
    string vUPUTIZy;
    int bnRzXqQ;

    int XpckXvMqxtt(double xBROg, int ZDmOqQsdWZwO, string VTCaQansdPxP);
    void xyhkZUuEhAc(bool aPojErJPdFn, double PtLRtVpCw);
    int WXcBrho(double nhyWVqWetmRn);
    bool JnMtsb(string CXBryW, string inqGTiMJPisYSsAl);
private:
    bool EvGjIwsaIkW;
    double HRSueSFR;
    string JuZtSpXsvvpl;
    bool yBQOHTG;
    bool eWMULcia;

    double joLOOMxLwYedRbHd(int uUyXfBrQJejaaqy, bool xPnrc, string nkVFYBVhidDNfSbP, bool vpfezM, bool XrlkkIY);
};

int lxfSVPVdGtdZKeb::XpckXvMqxtt(double xBROg, int ZDmOqQsdWZwO, string VTCaQansdPxP)
{
    bool vHouaXE = false;
    string lADaUBF = string("pcsHFlpBYPevBsXQaDgtGkPuTnKryVGDku");
    int gIlohLefhro = 945846885;
    int dZrsDWR = -680820977;
    string dIdROXCBdF = string("qYVhVQnismUdjcKxogjzFHxmEBBIxhdtLpehRTNRNXDwpwMpuwHysLGogaaFvBawidgjWdOrxJVsFDJfAmeupmPiPtcmfDKQavqVQJoIfwKzYbRlzuNKSmselNRzZ");
    double ivupI = -688526.6584393878;
    double FXvntuYamXzb = -355987.61296389543;
    double BKcvEHkun = -748910.158612015;

    if (dIdROXCBdF == string("qYVhVQnismUdjcKxogjzFHxmEBBIxhdtLpehRTNRNXDwpwMpuwHysLGogaaFvBawidgjWdOrxJVsFDJfAmeupmPiPtcmfDKQavqVQJoIfwKzYbRlzuNKSmselNRzZ")) {
        for (int OtfSEpTrPNDrOaN = 786613873; OtfSEpTrPNDrOaN > 0; OtfSEpTrPNDrOaN--) {
            gIlohLefhro += dZrsDWR;
            ZDmOqQsdWZwO *= dZrsDWR;
            ivupI /= xBROg;
        }
    }

    for (int Muzbs = 715767097; Muzbs > 0; Muzbs--) {
        dIdROXCBdF += VTCaQansdPxP;
        ivupI *= FXvntuYamXzb;
        dZrsDWR += gIlohLefhro;
        dIdROXCBdF += VTCaQansdPxP;
        dZrsDWR /= dZrsDWR;
        xBROg /= FXvntuYamXzb;
    }

    for (int zGufmg = 1154143934; zGufmg > 0; zGufmg--) {
        continue;
    }

    if (BKcvEHkun <= -178894.32053518915) {
        for (int elVKzhrb = 1503182101; elVKzhrb > 0; elVKzhrb--) {
            dZrsDWR *= dZrsDWR;
        }
    }

    return dZrsDWR;
}

void lxfSVPVdGtdZKeb::xyhkZUuEhAc(bool aPojErJPdFn, double PtLRtVpCw)
{
    string RwklORTQkB = string("ovMKbWXhPATqiaFvRemtRmzbyzzqvdWBltVxwaQtJoNXeOulMXeWfbQmxikDQgvasKbiIoYKIBjQNApHkYDBhvKFgPekpZkNjjawNRvgEWaEketDUKouuzuwVkBWhwEbxGWbLEjIQkMBNGEFCXZqARDOcSKmzvYxyNJlvHedCMLFiztxgxwyCtGRNWTJdvuhbqbjaHHhMmVNp");
    string rbXKK = string("PZwujvDnRaNlEUD");
    double YCeFqkLctZPPri = -519426.987004501;
    string qOqYi = string("CXMMfYCqKPixRaqdzwxDciiUYgILxlyIoJQFspIpRRVqkNMNcwaayEzZAiIWMBkCektaKBKKmVwnqqwQJSZjFgefaTUEFebvhaerFpPUdDMJWXfvlQyrDxAfauCdthFUMxpzRtAWpGnajcDwmOwdHjqDVKiiXecSBzHvQdsupBR");
    string zezzLsCHrZkJRp = string("pvbtqcqvkBiboNbZRVMMvTAmOSUelivqeflZjmGRCUNbdByRgTszePdtOMNtCuqRzbxLcLpusfpmgrZOWTowIcZYLpmWoysPRsnggJkohrxjmwKuUxTjiRQKkCGYGIRWLCQYNSFKMNigobtFInSVqkqawYtJCubWtRRkWfPlgygGeuKitORveYCFHdxWKsUHKXkUrXirLPNcDrvgsaNJZTPVuYLSJGcHzIqZA");
    bool kJTWeeWMP = false;
    string DjlTkADDZHZjwca = string("dHpHyhDrKTSybYKQSNbogWWYyNjefQHZQkDykwDaAVzLBMoQjJwiTpdvlgfpAdFvAlInCRmFPpVUYErVmrR");
    string pnheFivOlvVwzxO = string("dvqrpoyrrwdrkTUZXoVEZPVondYwElqDwnbJlmCHZPdHSAupByAzQPLPqgFVNCDcFKVIPoMZSKYbZCPIQmcvPLjxgHdVTxgWemClyDZHyJCcngwFJbTuliSVSdFG");
    bool hMAFJwe = false;

    if (hMAFJwe != false) {
        for (int eGAzNqE = 271520315; eGAzNqE > 0; eGAzNqE--) {
            continue;
        }
    }

    for (int OwkrdoY = 1480159286; OwkrdoY > 0; OwkrdoY--) {
        zezzLsCHrZkJRp = DjlTkADDZHZjwca;
        RwklORTQkB += pnheFivOlvVwzxO;
    }

    for (int otbtJlUYqX = 2085230932; otbtJlUYqX > 0; otbtJlUYqX--) {
        YCeFqkLctZPPri *= YCeFqkLctZPPri;
        PtLRtVpCw = YCeFqkLctZPPri;
    }

    for (int YCNMjZIdCRNBr = 1874855882; YCNMjZIdCRNBr > 0; YCNMjZIdCRNBr--) {
        qOqYi = zezzLsCHrZkJRp;
    }

    for (int DrMwZGYX = 564635091; DrMwZGYX > 0; DrMwZGYX--) {
        qOqYi += rbXKK;
    }

    for (int yZzPgt = 450611963; yZzPgt > 0; yZzPgt--) {
        continue;
    }

    for (int DCBgTao = 1971801076; DCBgTao > 0; DCBgTao--) {
        pnheFivOlvVwzxO += rbXKK;
        pnheFivOlvVwzxO = RwklORTQkB;
    }
}

int lxfSVPVdGtdZKeb::WXcBrho(double nhyWVqWetmRn)
{
    double trpfU = -76625.83418247418;

    if (nhyWVqWetmRn == -76625.83418247418) {
        for (int LvRKFrcnfI = 2017297115; LvRKFrcnfI > 0; LvRKFrcnfI--) {
            nhyWVqWetmRn = trpfU;
            trpfU = nhyWVqWetmRn;
            trpfU /= nhyWVqWetmRn;
            trpfU -= trpfU;
            trpfU += trpfU;
            nhyWVqWetmRn -= trpfU;
            nhyWVqWetmRn -= trpfU;
            nhyWVqWetmRn -= trpfU;
            nhyWVqWetmRn -= nhyWVqWetmRn;
        }
    }

    return -1164886220;
}

bool lxfSVPVdGtdZKeb::JnMtsb(string CXBryW, string inqGTiMJPisYSsAl)
{
    bool fXPNovYIuiK = false;
    int ZLibcLmxxURGXYH = 1372356309;
    double FcfFnLgBLNitl = -332514.38229086954;
    int JNnIDZpV = 1758805984;
    int BVwQSjqAAWZ = 1556372862;
    double mlOrYsclCGyFH = 586006.803122012;

    for (int QoiZTmieRGwd = 997434407; QoiZTmieRGwd > 0; QoiZTmieRGwd--) {
        ZLibcLmxxURGXYH *= JNnIDZpV;
        CXBryW += CXBryW;
    }

    return fXPNovYIuiK;
}

double lxfSVPVdGtdZKeb::joLOOMxLwYedRbHd(int uUyXfBrQJejaaqy, bool xPnrc, string nkVFYBVhidDNfSbP, bool vpfezM, bool XrlkkIY)
{
    string kStUALfmwga = string("cXYmgODrsRzYzrVeIn");
    string LTqjf = string("pZCXGuNeFNiswLLawByKgZURWiNiEF");
    int YLDendDyXU = -1797353051;
    bool BUJaUnOvinTqvLyF = true;
    string nzjfZZRBEBaKEIV = string("TXSXgMMMICdgdqQXKDXtRGOTGsetkPQBLlXQLeYALhzuKUBbPfScOCkhguMZkVdXLsLDVzXQKPQvsbdmxCbPIkvMfAkwRyWaJdgmmVGPVBTpAJQqgtRaJHhzPCuHAqldgscEXRLcaEvNQrfsvmbzfeckyGvXIoJZdHMPETiALSntCrSWULesySZACxJCvoEIPxIssGwxYVGBiLAYDRthEDiY");
    bool dOqtxmYqXXjgVqv = true;
    string hAYesMV = string("tmXBstPNlGDSrXcJHZwYZjEKsiokidwEUDcgyVQDDXvUPgWJCoOOaeIIpcIySghvqOeHKtcishCqkvywbyvOtsjoyAhKgtqiIJHWibJRGixyxNszvJTdquWqiXAFOcIbkpwhKeBuEPsDHMTCBpZiqpwFztSTxJVTyAYBZTFKIGNuqBituLwHHoMBhxvmRtIStezMtNSwLqaWhJuKdKtDERoKfDqRtWrVRJaAxlFea");
    string koosx = string("LwFyXLLtdPjQvFBQCnwBleBsPfSHhEYIvYpCGNdhsIWrnDGtHJdFEMkZbiqoZCWLpMuTuzNIHpbmXZuBiyMWcvPJFvAomtohpZGQUJvIHECGKicfldHIOjjpiQqlmLTpuXJnTWjQWBVHqYICyQemxVUnTldcCpNwDiSHaLunCvQeYyRcwsWEJroTBjiXZMjLHQYwqlEDI");
    bool ZySSlsLjAFc = false;
    string uUTPkIM = string("ekBvTbiGTEyNAPiYCLeRIpXdahPSMYnfYndeZDeOGGQedkYNtQwFsxyJQOTPRdFjEgBONvQWEYISkNsvGYAcPwXUEciaAhIXYhCrtfivVzMkFyLWHnswkhdvowomivRzCqRjbCEwjzETuQDxgOpHlYReKHOOEtAzEhhtPpJqKKAdAjvjjhFCjIiaCIEHEZzBywzOtynZRstNWVxLAqGKLHfzIyZ");

    if (kStUALfmwga == string("TXSXgMMMICdgdqQXKDXtRGOTGsetkPQBLlXQLeYALhzuKUBbPfScOCkhguMZkVdXLsLDVzXQKPQvsbdmxCbPIkvMfAkwRyWaJdgmmVGPVBTpAJQqgtRaJHhzPCuHAqldgscEXRLcaEvNQrfsvmbzfeckyGvXIoJZdHMPETiALSntCrSWULesySZACxJCvoEIPxIssGwxYVGBiLAYDRthEDiY")) {
        for (int HiyBb = 48631236; HiyBb > 0; HiyBb--) {
            nzjfZZRBEBaKEIV = uUTPkIM;
        }
    }

    if (hAYesMV == string("TXSXgMMMICdgdqQXKDXtRGOTGsetkPQBLlXQLeYALhzuKUBbPfScOCkhguMZkVdXLsLDVzXQKPQvsbdmxCbPIkvMfAkwRyWaJdgmmVGPVBTpAJQqgtRaJHhzPCuHAqldgscEXRLcaEvNQrfsvmbzfeckyGvXIoJZdHMPETiALSntCrSWULesySZACxJCvoEIPxIssGwxYVGBiLAYDRthEDiY")) {
        for (int ecukqxtNHzuJ = 459669334; ecukqxtNHzuJ > 0; ecukqxtNHzuJ--) {
            continue;
        }
    }

    return -515873.6232752367;
}

lxfSVPVdGtdZKeb::lxfSVPVdGtdZKeb()
{
    this->XpckXvMqxtt(-178894.32053518915, 1842677492, string("ylhmKnBzlNIUlsHifNxfCdEbglfXbxLKzINSesQkqtPstsPwAMQqbpzETmdnIJbuMKJewBRgoPStNZAKqGIKkdfOepvYbULkdmEdxOfdbPxNheIMMQIOBtolcpprzvSzwEzzURNGUHwmHcHxMChNNsyIuDSOCcrudpyXHK"));
    this->xyhkZUuEhAc(false, 684681.3354702919);
    this->WXcBrho(-426533.63404318626);
    this->JnMtsb(string("ixcDARzCtjkBeBiBPeJlzsQdMdIdRTVLGHKVimsSbRiMHgFyegwqeZQLLyRSJIKWxCIWHJnIxeXrtHJiVmwkhunRItUuozmTv"), string("oIyBFGFnlUoEEddeQXRJVMclFLEvRzoXqGYosCZdVyeeOPCq"));
    this->joLOOMxLwYedRbHd(-1738286021, true, string("LIWmSLogjmxnANBCHSIRMcGEwnyXTACvFZPKWUzWfPjSeQgkWunRGveKjjOtmzgOEGIvxydSUJYqXZoeqXYrXofIsEfbVVZKfYmOHPfyKNVaNMjOEAtGlelIueyYWkWZsMsbSipVwAQReBwNoLxxzmmmoaTXTMVEWpLbGsvPVTVgawX"), true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qwJFhyvVXNEe
{
public:
    double bBFTXydWORJwQQ;
    double OqeDMZvh;
    int LJgrUsKSZkRc;
    double asSVRDjIbiXIKRoO;
    double lQKrfUotzzQipK;

    qwJFhyvVXNEe();
    double sUTfOE(int MvvgsQWogE, bool VhrGp, int jGttysBGzWxK);
protected:
    double HaZDFuDWp;
    int WluNJbujJflDyiHc;

    double cPAUnSiZKo(double HGzOSqjeD, bool kOGsYBzUaaQ);
    string DvJvtKrbeRAUweTj();
    bool yWXFEK();
private:
    bool zkhSUfP;
    int AVcKJ;

    int wNbruBRgjNlq(bool CCpGeXWkZKN, double qhelJub, string CWAjUqNuRGWPNUTP, bool fITcgHBTbiGonFue, double AFSwcmIvs);
    double kqRuBuuErEGK(bool mhjDowfFjjQjkdVa, string WfNBRgsAxaRKpKed, bool ttgUIPz, string vlxRcQGf);
    void uMgRHpQmvDySMW(string WkLMZupD, bool Niigq, int HQcxWzipLaCqngrD, string hYawKvaocbWO);
};

double qwJFhyvVXNEe::sUTfOE(int MvvgsQWogE, bool VhrGp, int jGttysBGzWxK)
{
    int yeQDoK = -1255412173;
    int hhsKiWUlVQiknZJO = -183792993;
    int ZwOFJaNIG = -522205238;
    int OkBUBPZOxAeqN = 1306658026;
    string bBOIIKr = string("ltlYfoUOXmaYZpAhvRpgoSOpNTyToPClmNXXXVZIuohnwkcchHbAAArJqbRORvtrqyUHbKRhDwyHYySjFNyQANSRYkRGQrEvjrldOYFQAPccayeSRloYACStdzmGNFpylTjZPSFUXVamyhCUOFDBVZGPsdxLLuXawhujLjrJZZyQvUkjyUoKinEsyULWzihoyNNpjiOLhuYxXulHIRxkdvkEJCjugbBvGncOOWzZMNDNClOAolq");
    double OXEkCI = 887895.6711432819;
    int cjvDcpx = 157889483;

    if (jGttysBGzWxK <= -522205238) {
        for (int MKphLY = 882151242; MKphLY > 0; MKphLY--) {
            MvvgsQWogE /= MvvgsQWogE;
            cjvDcpx = yeQDoK;
        }
    }

    if (MvvgsQWogE < -1990063942) {
        for (int TCRJsuCCzd = 1457267453; TCRJsuCCzd > 0; TCRJsuCCzd--) {
            jGttysBGzWxK *= ZwOFJaNIG;
        }
    }

    if (yeQDoK != 202122413) {
        for (int KkFtGjLHMCHVfC = 406267912; KkFtGjLHMCHVfC > 0; KkFtGjLHMCHVfC--) {
            VhrGp = VhrGp;
            ZwOFJaNIG /= OkBUBPZOxAeqN;
        }
    }

    for (int kOXtwGsHPWB = 133013188; kOXtwGsHPWB > 0; kOXtwGsHPWB--) {
        hhsKiWUlVQiknZJO /= jGttysBGzWxK;
        MvvgsQWogE = yeQDoK;
    }

    if (MvvgsQWogE < 157889483) {
        for (int oHYaZsLKDZzG = 125498468; oHYaZsLKDZzG > 0; oHYaZsLKDZzG--) {
            ZwOFJaNIG -= MvvgsQWogE;
            cjvDcpx -= ZwOFJaNIG;
            cjvDcpx += ZwOFJaNIG;
        }
    }

    if (jGttysBGzWxK != -1255412173) {
        for (int HZFSo = 204370668; HZFSo > 0; HZFSo--) {
            yeQDoK *= ZwOFJaNIG;
            cjvDcpx -= yeQDoK;
        }
    }

    for (int MTZdV = 583641909; MTZdV > 0; MTZdV--) {
        cjvDcpx -= MvvgsQWogE;
        yeQDoK -= ZwOFJaNIG;
    }

    return OXEkCI;
}

double qwJFhyvVXNEe::cPAUnSiZKo(double HGzOSqjeD, bool kOGsYBzUaaQ)
{
    int OlwgUgA = -1560723092;
    double rqugBAywXrb = -219887.068785717;
    int zBGGfN = 1430004274;
    double tVCJy = 507918.7063908502;
    int pYyBtRnuqaZ = -706951573;
    string LMbZfsyQbpUzOQ = string("owJJkyKLTcfLPljpLaFGUBupGIEVNUYXfbFXkXYYOvQutSoQqZvruwLVJnTooLNsJxNJxefjFvsDzNZeXoyGSXkWGnnftQkhgrusnUTURmViyqZBhOvODSSmmEmHOQHWGzkniMMPWvsGggKVZKatkxDbTpkhjbWUaUamrfGBvdBjPsH");
    int RJmGdfkqLtqKs = 1488405719;
    double IKCBEdicXQ = 588617.3396446028;
    string ahKQYWzvMWzGCyc = string("expVhHrRgTiVMPCavkFJXyQWFQPDHjxGqySLbxQIgaKkkoPpbnTFAYeufJirJVwLMbhKMEXnayLazlGizwScnBiMGAByohWUcwvMlvVMdSlbhiPkxVAizQKoUfVjUVIjZpnFDqaCGXnHxcbxRKWCCmWfIOJVVZziIzhWvqGqGglUVKSRvLJrlcEAiJIdrWDsA");

    if (HGzOSqjeD != 507918.7063908502) {
        for (int UeTTCVjQPQiUk = 542936324; UeTTCVjQPQiUk > 0; UeTTCVjQPQiUk--) {
            pYyBtRnuqaZ += OlwgUgA;
            IKCBEdicXQ /= HGzOSqjeD;
            HGzOSqjeD *= tVCJy;
        }
    }

    return IKCBEdicXQ;
}

string qwJFhyvVXNEe::DvJvtKrbeRAUweTj()
{
    double pupSTNAHA = -334555.23167147214;
    int JxkGofQAepCLtEeu = 1213896848;
    bool fAmNcpInORTIghTN = false;
    int UpzTVcUottCj = 764614302;
    string DzLyGGkFr = string("dhePkPghsuEXtzWCzABjywzISZaKhlwjjRHolpRFSZTBhuerekwDOVWNdNzKQfebxRxHzvKgBGQtBbYFVUcnGKRoCeWZyksmxOKgDQErASYYFeBPJUnApjXgkFoQjoDLSjSncQRoVTHjRoeadNxRfgeEbXEkWWwDVsERZmSabGfUtlTxzSDIPpWwBmFeRKyPwzeOCMmSNQI");
    int MNBqR = -502815849;
    string BkcOxURdVgn = string("fpMQzZhXnGuPLLobwAeQnlmmjaqW");
    int ypNrMd = -1586248523;

    if (JxkGofQAepCLtEeu > -1586248523) {
        for (int scYaiAMj = 497004974; scYaiAMj > 0; scYaiAMj--) {
            MNBqR += MNBqR;
            ypNrMd += ypNrMd;
        }
    }

    for (int QsrBxhYqdvfizoi = 1612808158; QsrBxhYqdvfizoi > 0; QsrBxhYqdvfizoi--) {
        JxkGofQAepCLtEeu = MNBqR;
        UpzTVcUottCj += ypNrMd;
    }

    if (ypNrMd < 1213896848) {
        for (int JpGna = 177899238; JpGna > 0; JpGna--) {
            UpzTVcUottCj = UpzTVcUottCj;
            UpzTVcUottCj -= MNBqR;
        }
    }

    for (int ZtvPYRVinUo = 1104878936; ZtvPYRVinUo > 0; ZtvPYRVinUo--) {
        BkcOxURdVgn += DzLyGGkFr;
        JxkGofQAepCLtEeu *= UpzTVcUottCj;
        JxkGofQAepCLtEeu /= UpzTVcUottCj;
    }

    for (int ejPbJitmhdGNtC = 1247205817; ejPbJitmhdGNtC > 0; ejPbJitmhdGNtC--) {
        BkcOxURdVgn += DzLyGGkFr;
    }

    return BkcOxURdVgn;
}

bool qwJFhyvVXNEe::yWXFEK()
{
    int ZgdDl = 1836417767;
    double ilEfPQXBCrDUUs = -1007925.5883670383;
    double cjxIA = -856013.5430207661;
    int ZoaiIQNFJaJ = -569217;
    string QUIaPJWMnhFIcK = string("MPtBehbRadiecpThJIBxvwJnndoTWJvdYdffLWYkkpNamsHVnsGlqVNJZFwgRykJIWQRDfYHosEAgHUinhUCSMcONtfsYbGYDdFCqLhlsxZQmURuXIPUyRvSDNpFXySLehteQruloKfnfsUuhbDd");
    double LLRhQVg = -1024528.9651206816;
    string ibfUyJ = string("wwAsJfsUNIIN");

    for (int BAfTDdKzjs = 1439561498; BAfTDdKzjs > 0; BAfTDdKzjs--) {
        continue;
    }

    for (int rNEWEUmr = 477430079; rNEWEUmr > 0; rNEWEUmr--) {
        ibfUyJ += ibfUyJ;
        ibfUyJ = ibfUyJ;
        QUIaPJWMnhFIcK = ibfUyJ;
    }

    if (LLRhQVg == -856013.5430207661) {
        for (int ECFbQZQEskxlzCUl = 649669547; ECFbQZQEskxlzCUl > 0; ECFbQZQEskxlzCUl--) {
            continue;
        }
    }

    for (int JxNkjJejxtLeDQB = 75577724; JxNkjJejxtLeDQB > 0; JxNkjJejxtLeDQB--) {
        continue;
    }

    for (int DqHaeg = 146336790; DqHaeg > 0; DqHaeg--) {
        LLRhQVg -= LLRhQVg;
        QUIaPJWMnhFIcK = ibfUyJ;
    }

    return false;
}

int qwJFhyvVXNEe::wNbruBRgjNlq(bool CCpGeXWkZKN, double qhelJub, string CWAjUqNuRGWPNUTP, bool fITcgHBTbiGonFue, double AFSwcmIvs)
{
    string UvYrqTYMgbRi = string("BtCkILvPyTaMNtiMSBaWwcKvOqZTnWIZNbmetJIwPxpYQWztJuweOMzEWxpkXjDBJKlwLCYiPJaoRlYDJFtaPLCkNkSEhLHFZvsPxKqeEnPalJKWPvdxBGKfiXZZTtarkNnaxVzyyNrSbPUdsnTBZnGgUxUEULelUHGmXNCqxosTFgeirJLKmNhIsDINabnUXSPaJEeDnBbCewlBEACcZIZcEyITDDHAIOrsqRmGHfuP");
    string EoCiuvyUgEnVK = string("EFgyOyDhHkhhxgtDiPiFrnHHZeeydaCHcvbKozmKVulsCCnFLjMGvVsMMJLmkBNHHlXOVetOI");
    bool jOMRNLwvNA = false;
    bool BIjalMVRWjRCYoWr = true;

    if (BIjalMVRWjRCYoWr != false) {
        for (int XIHyvpHtSUag = 1039715475; XIHyvpHtSUag > 0; XIHyvpHtSUag--) {
            fITcgHBTbiGonFue = ! BIjalMVRWjRCYoWr;
        }
    }

    for (int HfkBMsVEUJ = 1177025861; HfkBMsVEUJ > 0; HfkBMsVEUJ--) {
        UvYrqTYMgbRi += EoCiuvyUgEnVK;
        UvYrqTYMgbRi += UvYrqTYMgbRi;
        CCpGeXWkZKN = ! CCpGeXWkZKN;
        EoCiuvyUgEnVK += UvYrqTYMgbRi;
    }

    for (int jnaMf = 676521789; jnaMf > 0; jnaMf--) {
        jOMRNLwvNA = ! fITcgHBTbiGonFue;
        qhelJub = qhelJub;
    }

    return 587593664;
}

double qwJFhyvVXNEe::kqRuBuuErEGK(bool mhjDowfFjjQjkdVa, string WfNBRgsAxaRKpKed, bool ttgUIPz, string vlxRcQGf)
{
    double ClFVPXckEVoPlFH = 729566.1513297398;
    int fkGaejEgK = 1940543355;
    double EWIJYKJfHnC = -989031.2834461473;
    bool PQFZUcQlpFPEs = false;
    bool rxNzOdUq = false;

    for (int mrtxSz = 211088447; mrtxSz > 0; mrtxSz--) {
        vlxRcQGf = vlxRcQGf;
    }

    for (int noegeanFeBRZsRE = 1178188336; noegeanFeBRZsRE > 0; noegeanFeBRZsRE--) {
        fkGaejEgK += fkGaejEgK;
        rxNzOdUq = ! PQFZUcQlpFPEs;
        EWIJYKJfHnC += EWIJYKJfHnC;
    }

    return EWIJYKJfHnC;
}

void qwJFhyvVXNEe::uMgRHpQmvDySMW(string WkLMZupD, bool Niigq, int HQcxWzipLaCqngrD, string hYawKvaocbWO)
{
    double sdNmgHNlLY = -963241.6500567949;
    double DPCbKzyOPPiZgzH = 275269.12472005514;
    bool zmxMrnHIaFdQP = true;
    string gpWfXncBeZsKkG = string("rVdZxvWgedATjtPovXXRqxKnsFISounoQOPvNVKxxDyAKyYeXamLoIGCkNOGuVDLYlGLbnXKjlDLTbiiEpypoKYOQToQCNbrZyehXKsZssePuOcWCmxO");
    string QJarkHSCNLozk = string("LFrmpeSzjVunpioxqIyrFhrnLhgypUdFpLwzExRXmtrdKbbAvSkIVzBWyELwEISYbyiYAiKYAWeMEpxrphbJSoTqbFXqaNzmUzWHSsrNhdSTfemmStsQEIntymfjvEVxWTddIEBrCwoNxExuBVURiCmEFklgVlVoUvbMSJVxETdKqWhcahqNxVKCmjUxuZBkHAEJmLkTRxWfZvYykpfTkqvpRYwdLsDumUhVcbI");
    int qCVCccZU = -2106427502;
    int WmKCOsvIh = -104798963;
    bool UAkACBDTqt = false;
    double mCovlS = -163131.4186614924;
    int OlZfWyuEzbQ = 1842238220;

    for (int cZExfFRuTzrXVNs = 1003833542; cZExfFRuTzrXVNs > 0; cZExfFRuTzrXVNs--) {
        continue;
    }

    for (int tuUzoDn = 1904303878; tuUzoDn > 0; tuUzoDn--) {
        gpWfXncBeZsKkG = gpWfXncBeZsKkG;
    }

    if (sdNmgHNlLY >= 275269.12472005514) {
        for (int dnVyJ = 308034147; dnVyJ > 0; dnVyJ--) {
            gpWfXncBeZsKkG += gpWfXncBeZsKkG;
        }
    }

    for (int tNbShNKUC = 33929276; tNbShNKUC > 0; tNbShNKUC--) {
        continue;
    }

    for (int bLmIPnJY = 593648579; bLmIPnJY > 0; bLmIPnJY--) {
        gpWfXncBeZsKkG += gpWfXncBeZsKkG;
        hYawKvaocbWO += QJarkHSCNLozk;
    }
}

qwJFhyvVXNEe::qwJFhyvVXNEe()
{
    this->sUTfOE(202122413, true, -1990063942);
    this->cPAUnSiZKo(-1027106.1370945175, false);
    this->DvJvtKrbeRAUweTj();
    this->yWXFEK();
    this->wNbruBRgjNlq(false, -20947.042532121086, string("BRNb"), false, -944688.2641064092);
    this->kqRuBuuErEGK(false, string("pBRKebZaIlVIMTABqLfDlrcXvCBqdnuUEKRbdVosJmiEdbXHATJeLiYNPdEmayLEeiZjyxvBbatUrKdIAdFxCiDbkGkLFbbLMUNcxrliYfNqX"), false, string("Ih"));
    this->uMgRHpQmvDySMW(string("FDrkMXqGpaXqQhlECpmkiZrGTFhTigTwP"), false, -1515087786, string("teMdkcyjRJrUnyDeCfSBgkGnhzkZnwnbjg"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dhhZNPKivIJC
{
public:
    bool liqGntegqUY;
    string ftLFRMDh;
    bool xsQuOBAKeEOQdVXM;

    dhhZNPKivIJC();
    string jCMCKcq();
    void uubBGE();
    bool mdUsFYYrWA(double FRKjXhrraJgPly);
    int eufLgW(string GHyMUVtPZfXmO, double uswXCQm, bool imQQVK);
protected:
    string UWHWwKdNps;
    bool bpEIbPf;
    double rauegIKUEN;
    string xXNladLYofoWwM;
    int uoUcufSe;
    int xQisiYnxEbkgfPj;

    bool bvixreWQLaAVOz(string mRzdutfxeUpQ);
    void bDtGxSRQ(double oEXhu, string QhHwTr);
    string nggOpbCKmIZuuG(double ypeRQANdsRRp, string GfygdrfiGgjjD, bool fnQpPoFU);
private:
    bool eSBspdDR;
    double JiVoInOrdX;
    bool DsgZMwQJtJBVx;

    double mSqBUD(double bdJhYLUbN, string cYJQxOHDxDM, double Dizqdmqph, double hTqyfFVE);
    double ClctuZSRyeo(int rLeHLyYkMyJ, string aimyBUkl, double IOJOD, string cCLmG);
    bool mUTkvjZlNnMuX(bool saArxYpLvlB, string EhYzHIDJoLwv, string MVwrm, bool LEjmQFAp, bool IeTLCi);
};

string dhhZNPKivIJC::jCMCKcq()
{
    string mQbaUSkutiBXz = string("yqzLqiwzcBhqLxTJOstIZXLFONPRxaNuianPTSXTkMjiClehcAbORdcaQICXfjxsovKJlRxoaRIXHlYeplNzVvCTMvlbopBYdoZuBePtHDlJeNcvrHviTTPreZzVpsfvJUPjsiJOAbpUUFvIqFNmWGcQXZTHErbqrpbHotztqGqqMqxLhvmdmTgDKjChsEQiNirWVKRuVtzDCsKsEyJWRyxCKVWHPHxqsqUqXwKuhbbei");
    string koffMqjve = string("AMKVqVUFkWBufMEIckpztShcotKkibWCbjUQgwBSRXbZEqNfzTFItRoWxUyUpUFpJOgcmPIldMKkwOqgnNfZQAglxeJzfgQIjsZmRgRFdBmsTKodcSfPuHNSsZpIGpHPbxgSWgAXszLOgRudDrrQnZQqEeOSbbCuJgjsOkqTCcgaELNmerrWiCFSjlGrrZpCMEhRyKybJqdwlEWNDqgyTdKZIVdd");
    double hgweEEIVcR = 1026673.0942522096;
    bool anUkxaxuWnJCXB = false;

    for (int vpmAbRhJWia = 2472557; vpmAbRhJWia > 0; vpmAbRhJWia--) {
        anUkxaxuWnJCXB = ! anUkxaxuWnJCXB;
        koffMqjve = koffMqjve;
        koffMqjve = mQbaUSkutiBXz;
    }

    if (mQbaUSkutiBXz == string("AMKVqVUFkWBufMEIckpztShcotKkibWCbjUQgwBSRXbZEqNfzTFItRoWxUyUpUFpJOgcmPIldMKkwOqgnNfZQAglxeJzfgQIjsZmRgRFdBmsTKodcSfPuHNSsZpIGpHPbxgSWgAXszLOgRudDrrQnZQqEeOSbbCuJgjsOkqTCcgaELNmerrWiCFSjlGrrZpCMEhRyKybJqdwlEWNDqgyTdKZIVdd")) {
        for (int Sadsh = 98011213; Sadsh > 0; Sadsh--) {
            continue;
        }
    }

    for (int hQHNFEVtqdBPCBo = 11040482; hQHNFEVtqdBPCBo > 0; hQHNFEVtqdBPCBo--) {
        koffMqjve = koffMqjve;
        anUkxaxuWnJCXB = anUkxaxuWnJCXB;
        hgweEEIVcR *= hgweEEIVcR;
        mQbaUSkutiBXz += koffMqjve;
        anUkxaxuWnJCXB = ! anUkxaxuWnJCXB;
    }

    for (int ndsoAMk = 44852387; ndsoAMk > 0; ndsoAMk--) {
        continue;
    }

    for (int zYasddrd = 2007119690; zYasddrd > 0; zYasddrd--) {
        mQbaUSkutiBXz = mQbaUSkutiBXz;
    }

    return koffMqjve;
}

void dhhZNPKivIJC::uubBGE()
{
    bool jgGWWnBFYTdrCGH = true;
    string fBgEhQY = string("izPzDuPrLOHaZhYXxYlvngbaTQHvXuCzyPPXYdwearwFUhnEjwYRbQBTZnkpbNbyxoNDuTzCsGViQPuohtqL");
    string WfsMK = string("LQWGtGgZcrmwfogktqLlRHCjXWYfpAZhBArHKaUoryiLRhHESwZdKTMMOAabYSkzLxGMCWIuEoV");
    double RYuvIrz = -860295.1711032197;
    int sAQbYYJZYDWH = 1632532202;
    double APTgsHU = 469580.5076178726;
    bool MCPNhB = false;

    for (int DEDGSkBZ = 383425439; DEDGSkBZ > 0; DEDGSkBZ--) {
        jgGWWnBFYTdrCGH = ! jgGWWnBFYTdrCGH;
        WfsMK = WfsMK;
        WfsMK = WfsMK;
        jgGWWnBFYTdrCGH = ! MCPNhB;
    }

    if (jgGWWnBFYTdrCGH == true) {
        for (int SzWzoKRpprXcsQe = 1609188861; SzWzoKRpprXcsQe > 0; SzWzoKRpprXcsQe--) {
            continue;
        }
    }
}

bool dhhZNPKivIJC::mdUsFYYrWA(double FRKjXhrraJgPly)
{
    double uWsMTXRSBYAV = 898263.1477022088;
    double OXgwUtwGcJjEODh = -856948.1061026641;
    string kZQoX = string("uzhZkHPbzcGxaHrPtTYhyEATOtZYpUruSZvOBqzIRcClBfdJfDHlmhxkzmRPuOoAoyRuWvxoCVkUPxMbbyosUZruyXyBwlshvhkyNDNsnpVrHEIGfdScMbFoIhWqRgEmLcGCuJhHQYzEWaTQnhopObcOfOeTuCkNbAxWxQROVvmvMmaqrnvuTRoeIwVgidQctPiFs");
    double pdjTs = -496432.9273353453;
    bool KKJaNon = false;
    int pzhyzkxou = 2111454319;
    int wyvqY = -1742359964;
    bool fNwflAKJFOZDGlQ = false;

    for (int gXJqqPLN = 1075676315; gXJqqPLN > 0; gXJqqPLN--) {
        OXgwUtwGcJjEODh *= FRKjXhrraJgPly;
    }

    for (int jPPhbyp = 1340999092; jPPhbyp > 0; jPPhbyp--) {
        continue;
    }

    for (int RMvfAbsuPJC = 303557772; RMvfAbsuPJC > 0; RMvfAbsuPJC--) {
        FRKjXhrraJgPly /= FRKjXhrraJgPly;
        FRKjXhrraJgPly += uWsMTXRSBYAV;
    }

    for (int VLVmvwWMhqXdVA = 114867973; VLVmvwWMhqXdVA > 0; VLVmvwWMhqXdVA--) {
        OXgwUtwGcJjEODh += pdjTs;
    }

    for (int fDYWMxwglKj = 860104831; fDYWMxwglKj > 0; fDYWMxwglKj--) {
        fNwflAKJFOZDGlQ = fNwflAKJFOZDGlQ;
    }

    for (int MyvYkcPNoICwa = 906776583; MyvYkcPNoICwa > 0; MyvYkcPNoICwa--) {
        FRKjXhrraJgPly -= FRKjXhrraJgPly;
    }

    if (fNwflAKJFOZDGlQ != false) {
        for (int zTMuKUgbnLL = 1522131827; zTMuKUgbnLL > 0; zTMuKUgbnLL--) {
            KKJaNon = fNwflAKJFOZDGlQ;
        }
    }

    return fNwflAKJFOZDGlQ;
}

int dhhZNPKivIJC::eufLgW(string GHyMUVtPZfXmO, double uswXCQm, bool imQQVK)
{
    double IUuvqE = 131963.83512554583;
    string LicEUwsuaqr = string("OMXUeFLgpiyuNSCRPsUROcTjUDHebHCtoYAjLLnzwvVxkmcEmRKpoibZIdBJtiuTcsPlsRtHgenteXnGfAkJiFPpTHMoVXOlgwysaaNrxVfCLBfzgMGBBgMLqnVuIfzcArhkzOpxCndYzzRmtMyrnPTJCXQoGRAioGOFRAlKTwMrnUTIlypzGzOVKIDhhtwjbGSNlRvsYQnBpvqkoPrhtOtIIBeIAauGuODrfUMMk");
    double YQsVMqddFOwDrM = 505972.91072547866;
    string QkslxCUa = string("dOIggFeAMfgCRbHxmsZHgWAFXbZIGfANEjEsZJGsENNKZKdYNZldZBeCkRtAYcKpLUCqmyeIijMTXareIhcEYlyvOlkrKSKl");
    bool OiBjlQJNXwzV = false;
    string STNFnfYZWzti = string("pZcLHvgwvBIIgnowwjX");
    string qsGaWuUJrJkAF = string("xygWOVrSQHwDCPgzAxJExYBBjTzvzawuCrpFOSiekhibpselVJEJCKRsCOcWiNuJZBGlQqhgzzYAINXCuEgQjkvMyFvaBwfCwPPxIYnsWWkHYjRiUOEYCtwXPEpgQbvdQNpYkYBznpeDcSEuerylnLwRBgvxpvmNGXKgzPwaIwAWFNNhXipZolawqfoDLzzu");
    double BHpVAPiWeqGT = 515220.1253732408;

    if (imQQVK == false) {
        for (int ElnsMsMhSjvAMjQ = 364671415; ElnsMsMhSjvAMjQ > 0; ElnsMsMhSjvAMjQ--) {
            qsGaWuUJrJkAF += LicEUwsuaqr;
            IUuvqE += YQsVMqddFOwDrM;
            YQsVMqddFOwDrM /= BHpVAPiWeqGT;
            QkslxCUa += STNFnfYZWzti;
        }
    }

    for (int kPUVKw = 2010243893; kPUVKw > 0; kPUVKw--) {
        qsGaWuUJrJkAF = LicEUwsuaqr;
    }

    for (int cYpQH = 1297506878; cYpQH > 0; cYpQH--) {
        IUuvqE /= uswXCQm;
        BHpVAPiWeqGT += YQsVMqddFOwDrM;
        STNFnfYZWzti = qsGaWuUJrJkAF;
    }

    if (GHyMUVtPZfXmO <= string("OMXUeFLgpiyuNSCRPsUROcTjUDHebHCtoYAjLLnzwvVxkmcEmRKpoibZIdBJtiuTcsPlsRtHgenteXnGfAkJiFPpTHMoVXOlgwysaaNrxVfCLBfzgMGBBgMLqnVuIfzcArhkzOpxCndYzzRmtMyrnPTJCXQoGRAioGOFRAlKTwMrnUTIlypzGzOVKIDhhtwjbGSNlRvsYQnBpvqkoPrhtOtIIBeIAauGuODrfUMMk")) {
        for (int hgJZrRBDZHgJkJ = 1668349545; hgJZrRBDZHgJkJ > 0; hgJZrRBDZHgJkJ--) {
            GHyMUVtPZfXmO += qsGaWuUJrJkAF;
        }
    }

    return -1874946587;
}

bool dhhZNPKivIJC::bvixreWQLaAVOz(string mRzdutfxeUpQ)
{
    bool GWrrGeRpri = true;
    string BmDkBYtat = string("hsikAwrkczCKFoZkYhxxzSPFgAPPiFdXRGnOdLuvAxRumQNihXQZBxSumyncrncHNEnipyrUrBQiYHMmUkGdMdNWYNvORPGzYDmZxzcUdXRKRmDrNQfrnODsmMeIFvrtpTBmtDsOiEyUOjPEnrQnPuRIrjUfOa");
    string qrbQatjNAzFmOd = string("EqSgmbxvRjtFSoJ");
    int XuqdBmwnrN = 1853662971;
    int KplreTGEyO = 1334533478;

    for (int RAfZK = 1462777122; RAfZK > 0; RAfZK--) {
        continue;
    }

    for (int yvRcue = 1771998017; yvRcue > 0; yvRcue--) {
        XuqdBmwnrN = KplreTGEyO;
        mRzdutfxeUpQ += mRzdutfxeUpQ;
        BmDkBYtat += BmDkBYtat;
    }

    for (int AfilvbKbZux = 811512435; AfilvbKbZux > 0; AfilvbKbZux--) {
        continue;
    }

    for (int PePHfuOjUeF = 1119303813; PePHfuOjUeF > 0; PePHfuOjUeF--) {
        continue;
    }

    return GWrrGeRpri;
}

void dhhZNPKivIJC::bDtGxSRQ(double oEXhu, string QhHwTr)
{
    string BVnhWJFWeTNCpQG = string("mRZmUOAKpgIGDrhtXfjcetdhafHtStlmVpXaPwkbZiWXOxJZLMeetWvkgCkETMCMsgrfFutdroAnYqVbHXLADqJhGayJlHIFmNpUrhhEojgkSOUqanXmtQTcXlawrHDz");
    double BLTWyBb = 756504.5418108265;
    int prmxxGdZJDmN = -1826178462;
    double nEbQezMHJ = 210958.2885364344;
    double iXuzKlSEJlv = 209229.94350350535;
    string NRCUryRJspZNZ = string("nzDwEjkGPFCEszbKqsFQzFmAsnIWxVyctmEjhiwPbKwbRLncHAdizbiHoDqWw");
    double DMsbbqJmYpPjGsJ = -581737.899415532;

    for (int AnTyfElHPrUidkZt = 517135716; AnTyfElHPrUidkZt > 0; AnTyfElHPrUidkZt--) {
        nEbQezMHJ -= iXuzKlSEJlv;
        iXuzKlSEJlv /= nEbQezMHJ;
        DMsbbqJmYpPjGsJ = iXuzKlSEJlv;
    }

    for (int PnklPcZKnUB = 978284026; PnklPcZKnUB > 0; PnklPcZKnUB--) {
        continue;
    }

    for (int wligDlVtj = 1987996558; wligDlVtj > 0; wligDlVtj--) {
        nEbQezMHJ += DMsbbqJmYpPjGsJ;
        nEbQezMHJ /= iXuzKlSEJlv;
    }

    for (int fXtwRzgAYZGoMCE = 1485923325; fXtwRzgAYZGoMCE > 0; fXtwRzgAYZGoMCE--) {
        continue;
    }
}

string dhhZNPKivIJC::nggOpbCKmIZuuG(double ypeRQANdsRRp, string GfygdrfiGgjjD, bool fnQpPoFU)
{
    bool HcmlUrlX = false;
    bool TpNzS = false;
    bool rPqyCPpmhKapoY = false;
    double VjltfaH = 443261.76673591445;
    double cDrHEIhliKe = -833018.3241128982;
    int OrrnsNyHVFg = -1144502989;
    double MfiEfnyv = 287655.5347373117;

    for (int ZAVtOvZ = 1982932762; ZAVtOvZ > 0; ZAVtOvZ--) {
        MfiEfnyv /= cDrHEIhliKe;
        cDrHEIhliKe = ypeRQANdsRRp;
        MfiEfnyv += ypeRQANdsRRp;
        MfiEfnyv += cDrHEIhliKe;
        GfygdrfiGgjjD = GfygdrfiGgjjD;
        TpNzS = rPqyCPpmhKapoY;
    }

    if (HcmlUrlX != false) {
        for (int GegvWQrovPppEgI = 557676566; GegvWQrovPppEgI > 0; GegvWQrovPppEgI--) {
            continue;
        }
    }

    for (int FpoJPg = 1767532535; FpoJPg > 0; FpoJPg--) {
        HcmlUrlX = ! rPqyCPpmhKapoY;
        ypeRQANdsRRp += MfiEfnyv;
        VjltfaH += cDrHEIhliKe;
    }

    for (int kLyxwguTxN = 1617878437; kLyxwguTxN > 0; kLyxwguTxN--) {
        continue;
    }

    return GfygdrfiGgjjD;
}

double dhhZNPKivIJC::mSqBUD(double bdJhYLUbN, string cYJQxOHDxDM, double Dizqdmqph, double hTqyfFVE)
{
    string kVyVmTUxuLK = string("OhFkyIHalAPnqdPzuaZBgiUVVlEvawQdD");
    int BNNQqNDYASMsepe = -2039626287;
    bool CMSMBq = false;
    bool YwNOnUqwIplQqwsQ = false;
    bool AodGGTiSo = false;
    string mdORfumMwi = string("jphLMpqsmvJGsvhVjQAFbwULmQQiEoaAlIHvKRbjfxxdiTOfFwlzuhVTIZcJbnVWMeViIZIyqrlJoyGFNoXAgOc");
    int xMLYivt = 1945625872;
    bool mheYPLbP = true;
    double THagDrkkgMlu = 654876.7696357714;

    for (int JZcdfLPxKzNAHFID = 1845714764; JZcdfLPxKzNAHFID > 0; JZcdfLPxKzNAHFID--) {
        YwNOnUqwIplQqwsQ = YwNOnUqwIplQqwsQ;
    }

    return THagDrkkgMlu;
}

double dhhZNPKivIJC::ClctuZSRyeo(int rLeHLyYkMyJ, string aimyBUkl, double IOJOD, string cCLmG)
{
    string eEnpelW = string("jmlUSNMVWOjoR");
    double imIcHFJSnb = -962710.5305954525;

    for (int gDqIHwlrxNTirjM = 1867130398; gDqIHwlrxNTirjM > 0; gDqIHwlrxNTirjM--) {
        imIcHFJSnb -= IOJOD;
        cCLmG += aimyBUkl;
        cCLmG += cCLmG;
        imIcHFJSnb += imIcHFJSnb;
    }

    for (int eSnDNthqa = 134837371; eSnDNthqa > 0; eSnDNthqa--) {
        aimyBUkl += eEnpelW;
        eEnpelW = aimyBUkl;
    }

    for (int yvRsewuC = 860718407; yvRsewuC > 0; yvRsewuC--) {
        aimyBUkl += cCLmG;
        imIcHFJSnb += IOJOD;
    }

    return imIcHFJSnb;
}

bool dhhZNPKivIJC::mUTkvjZlNnMuX(bool saArxYpLvlB, string EhYzHIDJoLwv, string MVwrm, bool LEjmQFAp, bool IeTLCi)
{
    double cfMzwLS = 307256.8545315455;
    int cikIPPoFgrJHlb = 1931869150;
    int tfadjkYNUVTk = 1688718101;
    int vemlNRReWYmMUScg = -1312593096;
    bool BSpIGlxMxHRIYSJE = true;
    string WxSEYTeSZ = string("PchyWvtwAsHfNPSKZjMEXYIpDuCvtckbr");
    double MOUckAZGOkXVCGZ = -51749.58534253512;
    string pHGDHDIEIYzUKNIk = string("FHTfLqqBPokMLIdYMlYkaqbtjysoWpLSlftCMaDuNDehfCYqJUeSQzCXXqG");

    if (WxSEYTeSZ <= string("xcoCUlDaZpnJtCVoAbFJghwcQKrMnfabawApgfGANUCRUYeNVaGPJwnnAkfpDzJvTRyzGKMRxVDcAqjCYKgSAIYAJxKhDsEjSxfSDVixizgwvrBENDBOJpHvpVzrYtFThgehcIFVjHhcfLLlhfimdFdXpSoWzjUtesSamXoOkeGFycRawfsvcWwwpNwsMtnhftizHqxyyGAcbpDjefQFMWgHxYI")) {
        for (int zHxLBmBTd = 712724003; zHxLBmBTd > 0; zHxLBmBTd--) {
            WxSEYTeSZ += pHGDHDIEIYzUKNIk;
            MOUckAZGOkXVCGZ += cfMzwLS;
        }
    }

    return BSpIGlxMxHRIYSJE;
}

dhhZNPKivIJC::dhhZNPKivIJC()
{
    this->jCMCKcq();
    this->uubBGE();
    this->mdUsFYYrWA(-263609.1112742325);
    this->eufLgW(string("wFHQygVlnFlGboIzrdmHDZHGpLJVKUVaBezDQAJkaIPlcnEuhJJFzCieWVsNfwwmsLtOsXmApJgqiHBp"), 291394.95121952833, true);
    this->bvixreWQLaAVOz(string("RiuptnhVycuGmqsrZejupOvZKQAnItpzfQOKGXyesJagXmDxKHdNzlvLpgJX"));
    this->bDtGxSRQ(511765.3964634615, string("pYkSCaocSKTnOrkVUJzTrCAOyHldRihUfelHojVvNAujjXlyedKykRpAMPaEJHjKlYaylFuXcBVqooZYMJuuwQJnmGMYmYCCaIuflMULsMWAnjzkiKydhmJYBSzDVzSxchXtRakenpQx"));
    this->nggOpbCKmIZuuG(-175383.1420404099, string("BSZrAvZDNSBmhsrCjqGUPXaCoUqqrIXjuLdnxcMDDKNLPTpDgMaoOLrXIMNoFiSYQPGIkccChbUBSyGoQrjCoIAqmSmDZEERktPRoIPVaGfyUqccjVjTLeyZJvIfZgrzFaHgzDLPlQlNbxRIEUoNLLkALPnlJHAWowWrE"), false);
    this->mSqBUD(445085.1919186544, string("YhvmfJrrUWPkLPuyNmNAPonzfAXfoqptzPoVzctXvdiZQsorNmvNHJtbtPaiV"), -650944.0185455455, -939089.5218836839);
    this->ClctuZSRyeo(1388257325, string("KaXgzhXxauEOoEILLMUtyZKcBwKYAAwDtYeXBwuIwMuwCFzbhtSRDXsKDqNVnbLGrgOQlfPKjneIshnvknRgZPDRKeym"), 355138.98502279073, string("qsiHhtGhpoqRbISPjfrdbseIgniLlbbizaTEshpsfJyiwaoIaiSRCtqEUEIrpiwwYQNjTmDehmQBgcngacqHfVfAKkOBezmOdoQkYIzglVdUxvOCWovgJZSJzIDvJbnVZ"));
    this->mUTkvjZlNnMuX(true, string("CAEegdbLEFXPWKxLoINBhdgiZZWULBfMULImUPbiHctVNAPIOhtIycOxSEOlwYJUoXIkXIBiEWIkoHCTljeGJcsNRgELomMIwrJfegwRvqHhJXcqgosKvtzADEXPwVjhIRvbPbHahlxrkWLcpSxBRPxLJegzEPMBhtIoSWSYmcZfnccfQApAlRrVSunfPzHIJMAjNS"), string("xcoCUlDaZpnJtCVoAbFJghwcQKrMnfabawApgfGANUCRUYeNVaGPJwnnAkfpDzJvTRyzGKMRxVDcAqjCYKgSAIYAJxKhDsEjSxfSDVixizgwvrBENDBOJpHvpVzrYtFThgehcIFVjHhcfLLlhfimdFdXpSoWzjUtesSamXoOkeGFycRawfsvcWwwpNwsMtnhftizHqxyyGAcbpDjefQFMWgHxYI"), false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gZrnkXzWH
{
public:
    double RBFknEgFoz;
    string pJsiEUDPn;
    int mBekoFSXIWDAm;
    string coOcIrk;

    gZrnkXzWH();
    bool PyNETf(int oSKFTLsLOozJg, bool yxlyCjywP);
    double ylZMVwUKolswybph(string EKiPD, string BPxTPlryr, int dBpBZUxPZsjmf, int pzbTczKNF);
    string wwXpAdEV(bool MFdzzQawWbBJrCe, bool BrNeyCighyDvQE, bool yUObmYmipHkANxQ, string oMJhvhArwzWMkl, int HNqpbnddioMDAO);
    bool pLvijLqob(string smImQFUc, int TUDXI, bool zHUtvoZyiNUhLR, string XrVaMQobTSYR, int FCBWnikTQpxBe);
    int dCAMiQNaqV(int vdcUbQRNWisShfDm, double NlsLWhv);
    string syqmqcElY();
    bool QuRPdYLAZMXvyFwh(bool QXtEnQhSppgWUgB);
protected:
    bool LhQjVVbYTU;

    bool CbVFCmCVtuXdeQ(int pAPdm, double wARmsQTV);
    void hJguDQpRvtDiDjtw();
    bool pokWPT(bool WHeEt, bool NnSClBlVICpX, int DfzuIIDwuyNsmXCP, int dmvfogTIWNuqAziJ, int zyLAlIwIJvT);
    bool oqDNLadF(bool zOruBf);
    double PjDnzeMAi(string VtQYOMfITdzoZtu, double UdEkcqza, double bYeBQWPA, string IbnYvPWAuZMb, string BfCdY);
    void dNlCiU(int WqeGM);
    int TIMwxpTw(string tTygDmHGCwx, bool UZNUZzuEbrMqyHW, bool ewuXeZkDBoIon);
private:
    double AsEFgtoRYySF;
    int WqwfVrVgkemcDwM;
    string ueazRppESO;
    double OxFGQnwHHgkUJO;
    double tpYarkVBAcAKthg;

    void ihcIVPrtshhk(bool VZwUwRe, double XcAaZSWuun, double YGvbUz);
    void tsfoiwmEzc(int KppFcaRNAc);
    int FFIkSUrWjKxnQJ(int NjCBpUgJzVuTgC, int ZchTupmcEjTpww, double wkHhtKKK, string JDQURC, string BySbyVL);
    bool scWhDYUHikYTSp(int TWwohNyfrzrZ, string uFleyD, bool cwDAoBfaAzr);
    bool THlLqmcQ(double jIFITmZVOcjCSEL, bool sFExMxKzIzvvxFFx, string goQnD, double OXAnQCFe, string GcUFwWtSxNTWBu);
    double qNhvRwTMnRLgVc();
    double qBVspTb(bool NlKwNyn, int spXtCVtrdFh, double GrAtKfPrNHJP, double QiHxbMoyMHf);
};

bool gZrnkXzWH::PyNETf(int oSKFTLsLOozJg, bool yxlyCjywP)
{
    int ayFnCN = -2018455205;
    bool DZFpd = true;
    bool bCkyE = false;
    string DNICnNNsmniE = string("oXOOeuBSJLShKarnxvrHUkdxgBYVimANxMLxOKCAvaoeeyhVQWbMxRJsvZxjdnNgAyRvpCSubPJTDGVcAnYTHggoCeAPCGjrIKHsQbQIDOynRyqJvwPpOhbGrzqGfTouzyEDFXWvVIjRahNnVRTgfJXcEYu");

    if (bCkyE != true) {
        for (int SQvOPiSDWfP = 1123883543; SQvOPiSDWfP > 0; SQvOPiSDWfP--) {
            continue;
        }
    }

    if (bCkyE != true) {
        for (int gPHGyliCvUYL = 1635489400; gPHGyliCvUYL > 0; gPHGyliCvUYL--) {
            ayFnCN *= ayFnCN;
            oSKFTLsLOozJg *= oSKFTLsLOozJg;
            ayFnCN += ayFnCN;
            ayFnCN *= ayFnCN;
            DZFpd = yxlyCjywP;
        }
    }

    return bCkyE;
}

double gZrnkXzWH::ylZMVwUKolswybph(string EKiPD, string BPxTPlryr, int dBpBZUxPZsjmf, int pzbTczKNF)
{
    double WdVdUJ = 627202.0125367581;
    string RzhJjwpR = string("pOFhXyQlnYovJHGSsjCqojcSLzlPoLbgGFDEfipBUpOwrRsxXMogMVAgAJyRWthNvykQGVJyQuDdziXwihGKaovpsSwHFRiSjUjgfgLFnlnYByvYYfmPPmoTpepXqon");
    int kdcBsVtlHfaXaYzQ = 75395719;
    bool XHmMyEeQkqeHkUpo = false;
    bool HXSawYMuJ = false;
    bool VbGxzId = false;
    int NmHHkvBLbDv = -817197086;
    bool YVmglztdqfrVyr = true;

    for (int IJodBxHGNF = 520988322; IJodBxHGNF > 0; IJodBxHGNF--) {
        YVmglztdqfrVyr = XHmMyEeQkqeHkUpo;
        EKiPD += RzhJjwpR;
        HXSawYMuJ = VbGxzId;
    }

    for (int QiXUCKPp = 846025765; QiXUCKPp > 0; QiXUCKPp--) {
        continue;
    }

    return WdVdUJ;
}

string gZrnkXzWH::wwXpAdEV(bool MFdzzQawWbBJrCe, bool BrNeyCighyDvQE, bool yUObmYmipHkANxQ, string oMJhvhArwzWMkl, int HNqpbnddioMDAO)
{
    bool yJmkhsf = false;
    int IfWWMGxg = 1573662800;
    double wITbZSwIgxlAmj = -242752.89337094105;
    string wJRYAtXAXGqu = string("PDFwTECbUdiJWouaOcGJQbTGMYbLRXmjroHLmPjVKlXeyuOSdsVAJPTKLWTdiXyBadmQIwBGOEvRMkQdBmQBDNgyayinqPfgMFCKrkYuBBRMiPRiAVaMdVprleajhVJwxgNoICWWQNdPHcYzCYnxipzqVSctLivSqobHCjmrXqWOMyLsDgK");
    string wQDWGc = string("LbPwfvzruTZGDPYNPIwHvQKgGqPNbUtNXZvNcBakRlUAUfWyjNAMFnfAKEAUwKLOjMmPOYyBkLTyjYIcDwiSXzbsCMizTMyddTJUevduaEhOmYOAqnxvidrgTsaYAzSmnWfsNaixqxCPKSuZlcsldUMcOiQfTGcLBFFkgNySdsXStVArVNdUauUzmAXCcmNAdirmjeSjNkagZFNbHsEztlXYqEkOiCGUxUOaZY");
    string BJrkBQYQS = string("jgMOISylkkMHmHYtxZECjThPkancDRXLfSSGoUmfGKtUaSkLlnOVzwgwscejWpKdUCnZxQQPNDgnDhPekiqpPnaYwPyuoBPprztwUHwoRkFjwFATzzEiRVXHMaAeLHQmniJ");
    int ymYVIxpdGOZ = 1400566532;
    bool mspcZYFaZ = true;
    double OMYPnvZ = -890340.9664808701;
    string fVznVSIZbOhYaDvS = string("MXolZBQkgAGYjhQkbgsbJxctBgsFinAsuYtlIGsZzfelwrynXpXsymiFOwuLcdqOrtAdddhGjgbSKMlsllcFrGguhNJdZKPthCAGZnMLvuOwtfVtEtbkmTGhExUevu");

    for (int LRCZfVDEUKmkfL = 1548721815; LRCZfVDEUKmkfL > 0; LRCZfVDEUKmkfL--) {
        wJRYAtXAXGqu = wJRYAtXAXGqu;
    }

    if (OMYPnvZ == -242752.89337094105) {
        for (int ktyInryOzEdmjl = 1684961676; ktyInryOzEdmjl > 0; ktyInryOzEdmjl--) {
            continue;
        }
    }

    for (int ciFPkRbf = 1919201810; ciFPkRbf > 0; ciFPkRbf--) {
        continue;
    }

    for (int gqOjtbnAipa = 844334857; gqOjtbnAipa > 0; gqOjtbnAipa--) {
        mspcZYFaZ = ! yJmkhsf;
    }

    return fVznVSIZbOhYaDvS;
}

bool gZrnkXzWH::pLvijLqob(string smImQFUc, int TUDXI, bool zHUtvoZyiNUhLR, string XrVaMQobTSYR, int FCBWnikTQpxBe)
{
    string ZzPQNlgr = string("LzMmGIkWohTgXnUTZaMukihMBicbKZCWKDvGrtbhOmadlgOqFhVGfZywdLSkTnArCPsbJmUVudroRWaNBVhrlxgavAKANFWIlmUEtLmoWExjTPpBpSatuApe");
    bool rXYIg = false;
    int PlmncaRnWhkcLHS = -440268711;
    double yFRNQNYyqgddEx = -154264.99535376555;

    for (int lnLHTSQhRPppLnx = 941062892; lnLHTSQhRPppLnx > 0; lnLHTSQhRPppLnx--) {
        continue;
    }

    if (FCBWnikTQpxBe <= -440268711) {
        for (int KmLPxfLooeLCzs = 1856583629; KmLPxfLooeLCzs > 0; KmLPxfLooeLCzs--) {
            FCBWnikTQpxBe *= TUDXI;
            PlmncaRnWhkcLHS = PlmncaRnWhkcLHS;
        }
    }

    for (int CyjAD = 2052748865; CyjAD > 0; CyjAD--) {
        smImQFUc += smImQFUc;
    }

    for (int VPOMC = 2048168695; VPOMC > 0; VPOMC--) {
        continue;
    }

    return rXYIg;
}

int gZrnkXzWH::dCAMiQNaqV(int vdcUbQRNWisShfDm, double NlsLWhv)
{
    double RHbxngRIKgTLHySZ = -281781.75303921296;
    int mVQYbtKvTfIQ = 11355453;
    double JqiZPXy = 369224.5556575447;
    double HzseqMqabYJpl = 731704.4850863987;
    double UbOaxJWRdoIKgZj = -629376.139803715;
    int HbtsDKU = 96398014;
    bool vMfBZIXtUIH = true;
    bool JaIXjBdCiJaq = true;
    string XszVgxaXWvsE = string("DhkpTQhIJdWPGLITVSWFaxBgmlRMslknjgXI");

    return HbtsDKU;
}

string gZrnkXzWH::syqmqcElY()
{
    double AVONzOQDot = -297427.1603849831;
    string maSQaKPkatJPdiVC = string("hfoldSuJDqIeIzUxZyymcccgtwAZGfSPtyHjkKvBBpnN");
    double rZwtJdefpWLWf = 653386.4452982504;
    int pXHalSQjdEvs = -1183756469;
    bool bKXWgjlJo = false;
    double IQBWJqS = -294630.4136557275;
    bool PWcHEs = false;
    double aBGhpXwVwg = 773738.9574193287;

    for (int sTNAwZgHVgjfdM = 1258316592; sTNAwZgHVgjfdM > 0; sTNAwZgHVgjfdM--) {
        aBGhpXwVwg *= AVONzOQDot;
    }

    for (int qyQPltXgKG = 1176969017; qyQPltXgKG > 0; qyQPltXgKG--) {
        aBGhpXwVwg = IQBWJqS;
    }

    if (aBGhpXwVwg != -294630.4136557275) {
        for (int MlMiUURDXB = 97930465; MlMiUURDXB > 0; MlMiUURDXB--) {
            maSQaKPkatJPdiVC += maSQaKPkatJPdiVC;
            AVONzOQDot -= rZwtJdefpWLWf;
            rZwtJdefpWLWf = rZwtJdefpWLWf;
            IQBWJqS *= rZwtJdefpWLWf;
            IQBWJqS /= AVONzOQDot;
            PWcHEs = PWcHEs;
        }
    }

    return maSQaKPkatJPdiVC;
}

bool gZrnkXzWH::QuRPdYLAZMXvyFwh(bool QXtEnQhSppgWUgB)
{
    int vASoWjFExoYOZb = 119209762;
    string YqTjvXpAOJOAqSH = string("OtVJrUyqcHZJujuuDSxrVkqIRVErrFVBqsDQPMfvvXRkUK");
    double ddPRLSvRCnMJHZ = 333653.0916384382;
    double yzYxPbZK = 302844.25374307384;
    string DYHDsHbUNYUNTye = string("RMicjeFlrfAzLBrGGlMEQRldpgzZDYQZsaDyiwOeOipkRRquWqwBaPKGElnlklfVGhoTtMeMUoVFVHRvGyNEltPKqDdsNoTusgZzoBMxCElnH");
    bool jHWxxK = false;
    int yELItFaaikwRKcWE = -247770009;
    bool SKwDhVvFjplXZ = false;

    for (int wWYniMhPIdIqh = 1052655240; wWYniMhPIdIqh > 0; wWYniMhPIdIqh--) {
        SKwDhVvFjplXZ = ! QXtEnQhSppgWUgB;
        yELItFaaikwRKcWE /= vASoWjFExoYOZb;
        yzYxPbZK = yzYxPbZK;
    }

    return SKwDhVvFjplXZ;
}

bool gZrnkXzWH::CbVFCmCVtuXdeQ(int pAPdm, double wARmsQTV)
{
    double ebzecibIt = -803292.4906665643;
    string atFKbtyKM = string("vmassWhzJpEAgwgfYvnzKOsNZHqoRxsoKBsCfJdTZblCSnytRLlLVZAGhXafasyTVgqoVPlKldajjblYSbYcOiZGKSzldTuwoUeoyzipzoKNXiFeGrvYXGPeIZXWkhFnyW");

    if (pAPdm < -1002788172) {
        for (int UyYJI = 2006169210; UyYJI > 0; UyYJI--) {
            wARmsQTV /= ebzecibIt;
        }
    }

    for (int pURSkqP = 489853465; pURSkqP > 0; pURSkqP--) {
        wARmsQTV /= ebzecibIt;
    }

    for (int QenNsNKtMCE = 927380565; QenNsNKtMCE > 0; QenNsNKtMCE--) {
        wARmsQTV += ebzecibIt;
        wARmsQTV -= ebzecibIt;
        ebzecibIt *= ebzecibIt;
        wARmsQTV -= ebzecibIt;
    }

    if (ebzecibIt <= -292795.92002856714) {
        for (int eSIeC = 692843799; eSIeC > 0; eSIeC--) {
            continue;
        }
    }

    for (int ypxxQg = 765828969; ypxxQg > 0; ypxxQg--) {
        continue;
    }

    return true;
}

void gZrnkXzWH::hJguDQpRvtDiDjtw()
{
    double cBOcRL = 955501.8893853129;
    bool qXgSgX = false;
    string OMnBXxRjfFj = string("nRiaYhJBZDfYIRKhLhTygWkoBlvhpFOIQpgBmereSDrzWHJudmpZaQZuecbKimKsxaZzLkJQykYNWOSiBOr");
    string aAFJyb = string("JrPPDeEeWtKzJOwxteKgqPxRVGtGGPLQjKZaHwylQYFzBSCasEhmhADKoydRdSovtOIqrqShpfSEZkcQriaaPIQZdAixmoSfHgLoUITrhzInyBIYqafpGJQYaNOmcCTriOQQgzEejBsKiFPfuJyIbuIGFeiW");
    bool HdKmnFQs = false;
    double hQzXSgWisvoGaBXn = 611008.9881602392;
    int cuBVbufproJt = 1867950682;

    for (int NeBZxQYbaynyZavV = 1833750653; NeBZxQYbaynyZavV > 0; NeBZxQYbaynyZavV--) {
        continue;
    }

    for (int CVavtkaDcWdSOB = 130287987; CVavtkaDcWdSOB > 0; CVavtkaDcWdSOB--) {
        qXgSgX = qXgSgX;
        cBOcRL /= hQzXSgWisvoGaBXn;
    }
}

bool gZrnkXzWH::pokWPT(bool WHeEt, bool NnSClBlVICpX, int DfzuIIDwuyNsmXCP, int dmvfogTIWNuqAziJ, int zyLAlIwIJvT)
{
    bool ATNjg = true;
    double cEKwNRkLZy = 622654.7643619153;
    int tnDeL = 1090023387;
    bool CPKtIxARnPR = true;
    string DgRMOOGRFXSQYh = string("AKTveSNhYOlraFGJRQNtZvaJhIPNRgoUwAmxUUpzRiCQqLwomJHlFuuoKdIVmvWTMApFcJtb");
    int LJtiCiTFSkAR = -1504930232;
    string inURNuWoCcFRhpm = string("LamAOoGhsijAOMQbKOIGumwOZXYsZMVVHAfMhGbxRkNvdIVIYQpOSCKadYZVcaMvRcRHFQJLuoViNOWGbGbgDexfRDZAcSBqfevhcdHMYImuUSBSajaNYhSvJmvAwptheVGFGUochKHgFOOBUeqRGCGcMGuuKBONrDTOwCxkRdiRdQfuUh");
    double UTcNZmKKNhd = 729772.4055194918;
    int mVzRgRLvRcGyF = -224107366;
    string bLHxP = string("MyNkbDrxrqLuRTQohuyfEqszCOYYPFhPrFVtWtgueshFpQuS");

    if (CPKtIxARnPR != true) {
        for (int nOSOPKxkgRe = 1004793600; nOSOPKxkgRe > 0; nOSOPKxkgRe--) {
            WHeEt = ! WHeEt;
        }
    }

    return CPKtIxARnPR;
}

bool gZrnkXzWH::oqDNLadF(bool zOruBf)
{
    string HUfQeLGsr = string("XnBcXMZvAacAPJSjRRhLUXAgvADriiwzljjhYtiKRdnBgXxjOeZrQqYLujPeHMVHKBqaXmvqvJlJWXQDmSsuUSpYxTYwkDYHLYb");
    string zjMJhbmJtSh = string("HzOPCOTTlQJCqloDWjOQmypUhYKXFPDEjPNRZtAngsGkuEquIFzMVhKYuxYXBChZKKVXrotlpHEUfMrxQWNViXOB");
    string WkKNmqRKgSi = string("DdgHDfaeXrHARkdPsQqVfewEBCSSxZqUysuayZXEhkrUsYbeWIHybzGzqYnxlT");

    if (zjMJhbmJtSh > string("XnBcXMZvAacAPJSjRRhLUXAgvADriiwzljjhYtiKRdnBgXxjOeZrQqYLujPeHMVHKBqaXmvqvJlJWXQDmSsuUSpYxTYwkDYHLYb")) {
        for (int LfbIecDEbYyB = 95599513; LfbIecDEbYyB > 0; LfbIecDEbYyB--) {
            zOruBf = ! zOruBf;
            HUfQeLGsr = zjMJhbmJtSh;
        }
    }

    return zOruBf;
}

double gZrnkXzWH::PjDnzeMAi(string VtQYOMfITdzoZtu, double UdEkcqza, double bYeBQWPA, string IbnYvPWAuZMb, string BfCdY)
{
    bool kUOQPbWkz = true;
    int HqNXaAd = 879720705;
    int HGiAYQdQXXGbxoBt = 805555285;
    double EMfqIuOcLaBTot = 149436.01615503986;
    bool VubtLPwAooyL = false;
    int nRcVunCdRm = 1246199434;
    int WySobmRwu = 930561977;
    int UjowxYW = -637573222;
    double gjejnZS = -178106.36160741613;

    return gjejnZS;
}

void gZrnkXzWH::dNlCiU(int WqeGM)
{
    bool RDFbeSFhp = true;
    int upXCb = 1912842369;
    int nHmzIlVFee = -75127670;
    double ODZqfNDMpN = -727482.8013894344;
    string DxOQkiIgGG = string("ezVJqSorCfVYXYUZtFBUvITUQMeJactLigDokxOywoGpwWBNtSbdt");
    double sCizGVCPbccQYXGf = 849012.7509245747;
    bool uxTIHbc = true;
    bool GBKkEeePemC = true;
    string YBpGzlQJKTJpWIBg = string("ByhRpsXccgizWRSJmzdjBpwiYBuVxTgkulWlgBmgrowoQNtJYaICyURaxhGyECjevCzPjuNLJW");
    string gCMPTpaB = string("ZnuiylzfUTvjBkflFDJehswxOXYhhVUlmfnmPDSrySIiGciVMfMNOtzepficroSJzRdaoOCoPtttOaSYDSuXAbjJpkAyxhkcivLCVuHEBSMIdfnmIzAoZXYgFvuCphARbwqaLuXiAZhIIihePhJCgmKwDLAFSKEoKzIszQlTORWofpaj");

    for (int tGIhdZbXdNhViegB = 1857608643; tGIhdZbXdNhViegB > 0; tGIhdZbXdNhViegB--) {
        continue;
    }

    if (WqeGM > -320087009) {
        for (int yqdxalCZZaZKWEqx = 1850213516; yqdxalCZZaZKWEqx > 0; yqdxalCZZaZKWEqx--) {
            uxTIHbc = ! RDFbeSFhp;
        }
    }

    for (int qNyhqVzXHHOOQZR = 126413760; qNyhqVzXHHOOQZR > 0; qNyhqVzXHHOOQZR--) {
        GBKkEeePemC = ! uxTIHbc;
        gCMPTpaB = YBpGzlQJKTJpWIBg;
    }
}

int gZrnkXzWH::TIMwxpTw(string tTygDmHGCwx, bool UZNUZzuEbrMqyHW, bool ewuXeZkDBoIon)
{
    double CYuZV = -693872.8626399662;
    bool oUDjDadJGyBexXUS = true;
    string DwSKNQoWbUyDAMp = string("ieuNEGPzFPKOQJZEofsDCOVEzPEOVUkUYUulJBcSnykxhqQHNJZPxHeQNzOuhljKgQXuwVHpyWRwZBexsOVZdBaeuMXadnqpBeSnG");
    double ctObWSAJ = 289569.6203111707;
    string iYVaG = string("LtaQUyjYzUUmCeuTwPGIyFPapqOYXxPqmjjFzzsnsdCwHcOYDcolKhIlArDqxZRsfPlHizAk");
    string WkjLxeuKLfhEn = string("hGSrhGnncDpGdJjNzDlQQdsrbGGkgatzrQeDKNFqjDupHmUPOdzszhbosvWEmoOayQXztMZJVJGIOBbftjfTQoQXmohYRxtDQtpjKMayXZtIkBsldNINPlZCCEcHutXpnCJxsaaUlFCTZRLixWHnnsHdwhbCnapJZPUnzwjU");
    string PxaSs = string("HYkmIWlerkhlKAzmHALeOdxjIXXUuMBZSzZhZCYDvnSVHcaAPclTbTyvUfSmAZw");
    double jhPEAUjOq = -18504.219274302523;
    int QTrRAflyJj = -2116584401;

    if (QTrRAflyJj == -2116584401) {
        for (int VRdQFTjRJkOL = 794857147; VRdQFTjRJkOL > 0; VRdQFTjRJkOL--) {
            DwSKNQoWbUyDAMp += PxaSs;
            tTygDmHGCwx = tTygDmHGCwx;
            WkjLxeuKLfhEn = WkjLxeuKLfhEn;
            DwSKNQoWbUyDAMp = PxaSs;
        }
    }

    for (int aUcJUKT = 1183644242; aUcJUKT > 0; aUcJUKT--) {
        UZNUZzuEbrMqyHW = ! ewuXeZkDBoIon;
    }

    if (DwSKNQoWbUyDAMp > string("hGSrhGnncDpGdJjNzDlQQdsrbGGkgatzrQeDKNFqjDupHmUPOdzszhbosvWEmoOayQXztMZJVJGIOBbftjfTQoQXmohYRxtDQtpjKMayXZtIkBsldNINPlZCCEcHutXpnCJxsaaUlFCTZRLixWHnnsHdwhbCnapJZPUnzwjU")) {
        for (int dTYDPzHdZzNWsM = 631809468; dTYDPzHdZzNWsM > 0; dTYDPzHdZzNWsM--) {
            UZNUZzuEbrMqyHW = ewuXeZkDBoIon;
        }
    }

    for (int LTVZWaBiCD = 1003467648; LTVZWaBiCD > 0; LTVZWaBiCD--) {
        oUDjDadJGyBexXUS = UZNUZzuEbrMqyHW;
    }

    if (WkjLxeuKLfhEn <= string("hGSrhGnncDpGdJjNzDlQQdsrbGGkgatzrQeDKNFqjDupHmUPOdzszhbosvWEmoOayQXztMZJVJGIOBbftjfTQoQXmohYRxtDQtpjKMayXZtIkBsldNINPlZCCEcHutXpnCJxsaaUlFCTZRLixWHnnsHdwhbCnapJZPUnzwjU")) {
        for (int BOgCx = 1904461665; BOgCx > 0; BOgCx--) {
            continue;
        }
    }

    if (jhPEAUjOq == -693872.8626399662) {
        for (int VZkmZaPGWGvmt = 1537175084; VZkmZaPGWGvmt > 0; VZkmZaPGWGvmt--) {
            tTygDmHGCwx = tTygDmHGCwx;
            WkjLxeuKLfhEn = tTygDmHGCwx;
        }
    }

    for (int EzFEnFEQ = 1456218108; EzFEnFEQ > 0; EzFEnFEQ--) {
        DwSKNQoWbUyDAMp += iYVaG;
        jhPEAUjOq -= CYuZV;
        UZNUZzuEbrMqyHW = ! oUDjDadJGyBexXUS;
    }

    for (int ItoPQNGLmRhq = 892728963; ItoPQNGLmRhq > 0; ItoPQNGLmRhq--) {
        DwSKNQoWbUyDAMp += iYVaG;
        WkjLxeuKLfhEn = iYVaG;
    }

    return QTrRAflyJj;
}

void gZrnkXzWH::ihcIVPrtshhk(bool VZwUwRe, double XcAaZSWuun, double YGvbUz)
{
    bool JySsap = true;
    string xOfWtexKAkuci = string("wXHNknNKKfwFDgoOhVfsTqasnysKkUWKtVKaEQgBubnlEtbUXrUqRssXiSIkWFYFJAIjRhLHNPUndaGrGbtXNjRejKXvSnUoMBzpYLxbRrLDVjmSR");
    double iJCGMCbNAQm = 912319.6697445465;
    string erAvc = string("OPNPEDkzAOFvjMpFzZgGmCeSfjVdxSlNWBpmnHAoeUypKzhINeCXmmOeqNlEqyIoJBcNXkuzyGBlwzadaoCUSxsxaWBhoXdmpVAtQnGHzhmoxISFVCkvKZanNhxGZgYbVjsAOBuoCwQvzEnSZMvvMykiPmgbpMFjmvjLfAOlGOrmGNjXhjrsOPJbgehPIJzzcjGwPhcJZOJwmWxSePSrOwlHKVobYFOYmJEnyrVoczrcN");
    double cyKuEBELQSPmvUr = 959887.4144562375;
    bool lwdMXbSUROf = false;
    double nsiIUzk = 752218.7174053257;
    string MJOnSxUdNYv = string("sEXhKaJQDHiuwXUfJILXzFvwSRYcpHdfbQXmyKWOmKATLHNinLzlCJJbDqvwBKjLwKyUMXKfulmKhaFkeZWcdbTfPzauZNsTOsivJWqEJNdwwgQVqHSKtXNAbGRpXVPOcwQFIPxtuoxMjOgCMYLLnQOebRhzauqYUVMpuwHmIljFmDLKHDFPrFnKkcyXkpSsfnnMjNdslDhGVAyrHRNkMzrvoQpqXWspOVKLNvpPBFYZYKKwVnZbPvD");

    for (int MyTAusnbYDbppR = 1653432985; MyTAusnbYDbppR > 0; MyTAusnbYDbppR--) {
        cyKuEBELQSPmvUr /= iJCGMCbNAQm;
        YGvbUz /= iJCGMCbNAQm;
    }

    for (int oIGbmkqksqbMCwWF = 308963155; oIGbmkqksqbMCwWF > 0; oIGbmkqksqbMCwWF--) {
        VZwUwRe = JySsap;
    }

    for (int OjetOplgNf = 1653983758; OjetOplgNf > 0; OjetOplgNf--) {
        MJOnSxUdNYv = erAvc;
        XcAaZSWuun /= iJCGMCbNAQm;
    }
}

void gZrnkXzWH::tsfoiwmEzc(int KppFcaRNAc)
{
    int QCwdGIoLCY = -1165761643;
    bool sLtGFvxxaXrKsEB = true;
    double skQSgLQPjKWvn = 1038303.1327279551;
    string WxTYNtf = string("xepBpbDPhqOGQLkoKTdpQuAwhcpfJWhYFIdwdeigjwyeXhxMYiufaaKCxcRWbDiFFrNiYTzYKqktJiJNCBTbpYMtmxENWSSLtqsSVezknAVLSRNXpkNOrwvGEEZWgeKZeCNcuYxToWgreoAvkFcMKurqeUuoiBBufVSWGLtv");
    bool FvCuFtzKYpmobg = true;
    int LjxjCeXabzzkgie = -1802253104;
    bool tlrCPgqBbiFfBcfI = false;

    for (int ONvuZpbNvQsAEyLJ = 2096107843; ONvuZpbNvQsAEyLJ > 0; ONvuZpbNvQsAEyLJ--) {
        skQSgLQPjKWvn *= skQSgLQPjKWvn;
        sLtGFvxxaXrKsEB = ! tlrCPgqBbiFfBcfI;
    }

    for (int qlkRoaEYyQGN = 194357134; qlkRoaEYyQGN > 0; qlkRoaEYyQGN--) {
        LjxjCeXabzzkgie /= LjxjCeXabzzkgie;
        KppFcaRNAc = QCwdGIoLCY;
        LjxjCeXabzzkgie = KppFcaRNAc;
        FvCuFtzKYpmobg = ! tlrCPgqBbiFfBcfI;
    }

    for (int XZxTfRYufocdcbRB = 747426629; XZxTfRYufocdcbRB > 0; XZxTfRYufocdcbRB--) {
        continue;
    }

    for (int oIazSHSZEnjKDvQj = 241592131; oIazSHSZEnjKDvQj > 0; oIazSHSZEnjKDvQj--) {
        continue;
    }

    for (int utsFjRrRHbVjlKaO = 586050440; utsFjRrRHbVjlKaO > 0; utsFjRrRHbVjlKaO--) {
        LjxjCeXabzzkgie /= LjxjCeXabzzkgie;
    }
}

int gZrnkXzWH::FFIkSUrWjKxnQJ(int NjCBpUgJzVuTgC, int ZchTupmcEjTpww, double wkHhtKKK, string JDQURC, string BySbyVL)
{
    double GduqkPkrR = 687928.0347804249;
    double uqQitpLQQaDGv = 946208.5962487666;
    double lENrhqcqFOB = 962138.237828426;

    for (int cPyuAGZ = 1768086306; cPyuAGZ > 0; cPyuAGZ--) {
        lENrhqcqFOB += lENrhqcqFOB;
    }

    return ZchTupmcEjTpww;
}

bool gZrnkXzWH::scWhDYUHikYTSp(int TWwohNyfrzrZ, string uFleyD, bool cwDAoBfaAzr)
{
    double yywJJPfVLPZri = 959699.6751560789;
    bool TMMHpXxqpJHUp = false;
    string lpbPZCyfUKQuXtJw = string("ReIpeyYNnTFBFhSbjcyUMhZYawgHeIqJlarIKbNAoBGFlXfGjsiSvPgeREkbDItzgYfKGPWUHmMchuBnSjMmUZepLwInuNJKUvBVWnytNNJvBhwrapUwvMIQpCobwQJOeNGWcKZYgxdmwuHQwoRvMJaxhwXgcR");
    bool HqkwRDiwsuf = true;
    bool GquFJXXGEfas = true;
    double EUfnUddGY = -273758.60051434604;

    if (cwDAoBfaAzr == true) {
        for (int UMNFaFxP = 1580960859; UMNFaFxP > 0; UMNFaFxP--) {
            EUfnUddGY = yywJJPfVLPZri;
        }
    }

    return GquFJXXGEfas;
}

bool gZrnkXzWH::THlLqmcQ(double jIFITmZVOcjCSEL, bool sFExMxKzIzvvxFFx, string goQnD, double OXAnQCFe, string GcUFwWtSxNTWBu)
{
    string NDRIgagybAUFk = string("gigFuNJbPXPqWHsrSzpwiLBujZjWNAgkbuntWghHxAZyGQiVNjlsBVGuqoAUSeXzDQYABFjvGuPzRTzPqvhKZTouxgcylzCiNdTabLiJegUZMCLIwZTwmpaWjoWAJEipRHdCIfReEnxDWnolPoWAkZeSMtmwPbVFksqpBfOMoYCHgdsD");
    int gHFkEpaFuwHcGg = -852431867;
    string UtsYJy = string("aKbvtIoetdAeYrVxUFYMmVvqBtcpLyCkkibLiNzIlHkgSnHWJywWhCsOGxbIuiKSeqxymwfNsVeILFgckTPHjXkzDhrJoTyHnwVWFISLYPcVrjIgTtGScUvQQcwQtQzNacstZHjYVEdMFxsAGHcalBtoKAVTDhQhXZTSuVolcEMgZDjEvtiDCGXyBBBesVWToJJRtyQCI");
    double ZKuxhZKASmnxqrBJ = -107253.57647577203;
    string eaNvbblteXwRst = string("hjalKoelbNyCsDTNPLxRTkjcIJJgGwtfkQSefJSXaLHgAhaYhsgZqlZbuSXgZzzooWVEDgLzteerCakQtpErmtmtsCVzoXDrIhnJhzHCKWGUpQWgupZGMgfDVfLCJrmtrEGeaUAwfIdVFFTDfhLXexncqhRCQIKPtulhemFmBfwkpKODIlfcnAvullEkisPHsQjl");
    bool CUnkEaT = false;
    double tBSxgYSEAPMS = -236198.88370134612;
    int gzeEaOsea = 1126030896;
    bool YLZaNGXVmgLUSsu = true;

    return YLZaNGXVmgLUSsu;
}

double gZrnkXzWH::qNhvRwTMnRLgVc()
{
    string UWzTXRlE = string("pFXAjMFcMCP");

    if (UWzTXRlE < string("pFXAjMFcMCP")) {
        for (int naXqsujZy = 1441822651; naXqsujZy > 0; naXqsujZy--) {
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
        }
    }

    if (UWzTXRlE <= string("pFXAjMFcMCP")) {
        for (int wmJfSIwgJqHhXIP = 915424179; wmJfSIwgJqHhXIP > 0; wmJfSIwgJqHhXIP--) {
            UWzTXRlE += UWzTXRlE;
        }
    }

    if (UWzTXRlE >= string("pFXAjMFcMCP")) {
        for (int qNSHNY = 1165863378; qNSHNY > 0; qNSHNY--) {
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
        }
    }

    if (UWzTXRlE <= string("pFXAjMFcMCP")) {
        for (int BnUSOBzCpgBNbkE = 875828159; BnUSOBzCpgBNbkE > 0; BnUSOBzCpgBNbkE--) {
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
        }
    }

    if (UWzTXRlE != string("pFXAjMFcMCP")) {
        for (int PnDUZdxz = 1807572009; PnDUZdxz > 0; PnDUZdxz--) {
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
        }
    }

    if (UWzTXRlE != string("pFXAjMFcMCP")) {
        for (int MmMPeYFUUcxxs = 258963059; MmMPeYFUUcxxs > 0; MmMPeYFUUcxxs--) {
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE = UWzTXRlE;
            UWzTXRlE += UWzTXRlE;
        }
    }

    return 416154.6059647316;
}

double gZrnkXzWH::qBVspTb(bool NlKwNyn, int spXtCVtrdFh, double GrAtKfPrNHJP, double QiHxbMoyMHf)
{
    int OOXooteR = 777454554;
    double kcuasHXBFPYEg = 331264.48303895944;
    int zMxJPjceNEbAJ = -1137836639;
    int PxfBSiyRLN = -1639768174;
    int qpPstz = -220861722;
    string fiamvnVkpmi = string("EEnDHhpwgxpbspuQSLjZNsVdHtbiNlXNRfLHRFEhGesfGsBaNzGFRiElDKWawiMhKVrpMLrFeYMVlqDgcyBWlaSIjnodzwFCBOoDLdEapEPZYVHaJZrMBOUIeGILFgsxhvKZCarLHJlLhOxHbJfYkHucvKfSpovyPwIKQerInMsQLhZDzjAHEYjbcgKwnxMjbXNQmvZqQevRkqYNcUz");
    int ATePYPfcvsgADDV = 1072710033;
    int WQKhaKYvBsZ = -204236564;
    int dMIJeyUO = 714742585;
    bool eRdyfLyUVQdNDL = false;

    if (OOXooteR > 714742585) {
        for (int MGNUAGz = 1455469518; MGNUAGz > 0; MGNUAGz--) {
            ATePYPfcvsgADDV -= WQKhaKYvBsZ;
            zMxJPjceNEbAJ *= WQKhaKYvBsZ;
        }
    }

    if (NlKwNyn != true) {
        for (int EONuXLv = 100530170; EONuXLv > 0; EONuXLv--) {
            continue;
        }
    }

    if (qpPstz > 777454554) {
        for (int zdWHIVMTx = 1680368166; zdWHIVMTx > 0; zdWHIVMTx--) {
            zMxJPjceNEbAJ /= ATePYPfcvsgADDV;
        }
    }

    for (int xPOsCKqOe = 1355541853; xPOsCKqOe > 0; xPOsCKqOe--) {
        spXtCVtrdFh -= ATePYPfcvsgADDV;
        GrAtKfPrNHJP += QiHxbMoyMHf;
        QiHxbMoyMHf /= QiHxbMoyMHf;
        zMxJPjceNEbAJ = PxfBSiyRLN;
    }

    for (int AmhZn = 350578060; AmhZn > 0; AmhZn--) {
        fiamvnVkpmi = fiamvnVkpmi;
        qpPstz += OOXooteR;
    }

    for (int nGfsGxymnvtTHnU = 255321027; nGfsGxymnvtTHnU > 0; nGfsGxymnvtTHnU--) {
        qpPstz = ATePYPfcvsgADDV;
        qpPstz -= qpPstz;
    }

    for (int njyrDpsDZCCWZzMt = 1539994864; njyrDpsDZCCWZzMt > 0; njyrDpsDZCCWZzMt--) {
        dMIJeyUO -= ATePYPfcvsgADDV;
    }

    if (spXtCVtrdFh >= -204236564) {
        for (int qBrGXcd = 159369743; qBrGXcd > 0; qBrGXcd--) {
            NlKwNyn = NlKwNyn;
        }
    }

    return kcuasHXBFPYEg;
}

gZrnkXzWH::gZrnkXzWH()
{
    this->PyNETf(1957193722, false);
    this->ylZMVwUKolswybph(string("CoZlCFNWFnVaoJEnxyQzrrCyxAYijRPKJmuuJBfSROEdyjGuLRbHTqkPQLfGLlNESFmCrEOlzUeWAKStdSujXFfAgnDoOjjtWVyYeAvXtxFPyQQBmIDWtTnecIvAFaopdN"), string("ZbPbHbkaZAJCcXDVadRzQTwVjSMZPGXhPHwHuvvnmfBZholtBqqWidWBXIhIZNoqzjqcGEWkMbQiJTGBNgmGwWRONyoUjXzOttWFhuJYpZRIzvegGaCkIFCOlDkDGMwoFYNlOkQwSKBdatEhwVuvoyKSoPUpdGVFOpWIbwQlxEofUhWnyBIKk"), 1726046167, 772656112);
    this->wwXpAdEV(true, true, true, string("LPlQjFeEnQhDVSDbcICBEzcUfhecuaUQdJByGXFKjwQNpvwFNSSQUQyUjnGgFQwCAhDJapHcWinZQGENUMxjPAdxzRAbiBmrUCafowwlmjLQLmJvaCoNPFohEVXeIOKPHUmHPIcdiORXmGigpFYFkJEIjCezTsBsbJkmALFgEIimRUsEGEEMiyfkdIWb"), -1318893776);
    this->pLvijLqob(string("wMpoYrXPGWGbwbdJhrpGxFSWUKWKGNPRaeLtaXXnWJiJNvNGxZBkZxzFeWzLunnkMMwniRxKpwZWnXphufeaTYnNRLxmhjMnADTPEhGBbqEFwHVBkQtqnrnOuDQMRhBvjiPwKmgjsfIduHNZSmYCSKeOPLjqOAJnaYffXKyNkezfUgqcaOL"), 928396642, false, string("xZZLezPyeNMMRfeNKAUNrJGESTIxHkhVnrPKiVKbKqIveLMsXzMKBcGOnKabaaOBbobTEskNVJkcEtIQveiMRooAHDrsQWZrnJIXUdvDZLinxiHYTakrqsGrpstjJbqytRuCusRYlyCqrXhSwAuNREbFSbqFzM"), -880605823);
    this->dCAMiQNaqV(989360242, -254136.1637052642);
    this->syqmqcElY();
    this->QuRPdYLAZMXvyFwh(false);
    this->CbVFCmCVtuXdeQ(-1002788172, -292795.92002856714);
    this->hJguDQpRvtDiDjtw();
    this->pokWPT(false, false, 1459768379, 1330247519, 343811846);
    this->oqDNLadF(false);
    this->PjDnzeMAi(string("NBWdlkfMSstSgwqZalOqlayFZGLGyWOhbsCdRfSSouSjyRrGfFomQKyatrpNIPbaGIzJVcdycpXMjVsTKcImeUJrZUcxUXoQgrPdPXePwHVTz"), 132376.77052063597, -254748.57846956007, string("PjMWziILhbqxVxEEnVRAhuvYnJTQImgsNdvsITfeoRCUJRPIPsEtAFTNZBofteBMKgLTCQsFkrnpAeIQpikgezwdBHmjpqqvjUdvTQEdIxjBSDGtBBSUFXIucfAwnwHHXcOQOwtIgThyoRAeJGosIdNZIavLohBNskVppPghuUxruyLXlQaNZKhreOYrIIugdLTsvzGiJJKCsWvDFjONRFuxKGCRcAtMcKZfFdYAvbtXefbDfiszvMgWRTzZ"), string("SQZikuMIgBVcqlTSnYX"));
    this->dNlCiU(-320087009);
    this->TIMwxpTw(string("YVcBxGxU"), true, true);
    this->ihcIVPrtshhk(false, -988327.3327511386, -448922.7675256215);
    this->tsfoiwmEzc(-889764895);
    this->FFIkSUrWjKxnQJ(-281459295, -486048491, -382306.8598512235, string("XUqoTnVmchoQuUuxmeo"), string("QPMuzxxGrnmSQoRptdzTGuXmgVXgjsZUzbecvFAuMQRLaMSeMFyQjwjscexSeWlALMPsoYOhuGRaJeNraTwYMKouohcKPlfzJCvYJhkLtznvDjoWXEVLHPhoYJlfdaBJdGXxZZSUzWfUAuEuLHLehzdUtwMyfMxbhpoHMqqTFCSGpSkXYTwwjyRzKNxlJlaGgLqHkqgrvmiBDmnBTcSeEQWxsAmvQxWmRNoWQumuoGcnfYwJNASD"));
    this->scWhDYUHikYTSp(322640810, string("NIzpJolYvwRgkrvViTTlACUqyWIlAZlrdOThOTVureKKkJiYqvpTUGzgsYNjoHoairabiAeiGEyvnSzLclVqxwJycfKuYFSTHpTNcslCAGeACaFMpOcxPHscKINVWOhszvfdvnOsPjQJNGtDUDuPBgeIUtxfPKEMUIm"), true);
    this->THlLqmcQ(-570562.5575751577, true, string("ygbnungnxUHIFdNePeSNnjdvMmSPBkmFSklHKucQZsMFspAZDfAFiaVPSSzhqfkSzQuAcnYBzPHikAGVyYkPBoEfMyfLbmq"), 8446.323522397319, string("SUpehHJfaEziTJ"));
    this->qNhvRwTMnRLgVc();
    this->qBVspTb(true, 1847538781, -692967.5749789674, 893154.2003268788);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EmkuOcojxXRs
{
public:
    bool FEdltAisFaPzGo;
    int YhdPOvsvQv;
    string ulGhWrOcVHWmcdT;
    string liDoGl;
    bool eqsDTBlsy;
    double JYVvD;

    EmkuOcojxXRs();
    double gvuYqFyFrNkYOYDD(string RAlCBrE, bool WAtIMKzybnuwXzHU);
protected:
    int NmKvbH;
    double BnlqMXWJnZzz;
    double xWEQjaSQHyefEfd;

    bool oVjDnIHA(int BtimFLjOfktH);
private:
    int QflnCypIMT;
    bool PsYRGjZqoCIIxUvX;
    string jyBXMZiOxUwFYgXK;
    int WqXOaU;

    double jCrfRka(string FHacsHSOCF, bool SWmyfEmWTgbUOBRV, string thDPSWKgWlA);
    int AHKsT(double qdlOMIiZgS, int dqayNLaY, double pDBDfyMSqCTHRBzu, string yirLtvbVkx, double TtnHgYpRV);
    int vCosYzyOEAkTZ(string crlwdxxpJFqpz, int yFGVwIk);
    int ewezGaNWhRT(bool SgKzPkkzVTOTyY, double wxXPWRVXWzPwq, double hrLfxUMksERuUHy, bool GeDZkwi);
};

double EmkuOcojxXRs::gvuYqFyFrNkYOYDD(string RAlCBrE, bool WAtIMKzybnuwXzHU)
{
    int JLjyqEPWdyAT = 1202311160;

    for (int cgvWiYecLXRL = 491078658; cgvWiYecLXRL > 0; cgvWiYecLXRL--) {
        WAtIMKzybnuwXzHU = ! WAtIMKzybnuwXzHU;
    }

    for (int HoNZlsilmROUhT = 1287224932; HoNZlsilmROUhT > 0; HoNZlsilmROUhT--) {
        WAtIMKzybnuwXzHU = WAtIMKzybnuwXzHU;
        WAtIMKzybnuwXzHU = ! WAtIMKzybnuwXzHU;
        JLjyqEPWdyAT /= JLjyqEPWdyAT;
    }

    if (JLjyqEPWdyAT > 1202311160) {
        for (int BggwlrfsVc = 1014038610; BggwlrfsVc > 0; BggwlrfsVc--) {
            RAlCBrE = RAlCBrE;
            JLjyqEPWdyAT = JLjyqEPWdyAT;
        }
    }

    return 846642.6205084383;
}

bool EmkuOcojxXRs::oVjDnIHA(int BtimFLjOfktH)
{
    int nStVe = 1031948857;
    double aogWr = -203383.83162724302;
    bool dgEtQL = false;
    int cndLdOigEGIjj = 186612225;
    double LvjIAtUx = -449664.65736695816;
    double LKHoT = -607019.9083594796;
    bool OceMRBkQNgPEH = true;
    double fBnaBtdoLWlw = 650725.8404687329;

    if (cndLdOigEGIjj != 1031948857) {
        for (int Npsgn = 148446439; Npsgn > 0; Npsgn--) {
            continue;
        }
    }

    for (int KGbhzxy = 1878850067; KGbhzxy > 0; KGbhzxy--) {
        fBnaBtdoLWlw -= aogWr;
    }

    return OceMRBkQNgPEH;
}

double EmkuOcojxXRs::jCrfRka(string FHacsHSOCF, bool SWmyfEmWTgbUOBRV, string thDPSWKgWlA)
{
    int yfkAxsSAH = -352129288;
    bool YodkiHItQCffp = false;
    string VjfHOYxOPVwNW = string("FBqWHWxNqciSpVkGqelBtnqqrXNamKzhgdqDHucKcoSpPoRqbvSUIyWKxLPpXxGwoSTCtypnhLr");

    return -442361.4841475721;
}

int EmkuOcojxXRs::AHKsT(double qdlOMIiZgS, int dqayNLaY, double pDBDfyMSqCTHRBzu, string yirLtvbVkx, double TtnHgYpRV)
{
    double NdevlM = -1039078.7982137792;
    string kdbIYLIhc = string("TlCJBIZSbHrVXoBAGmKSHQLwdPfNqaOsGySrHlClNaDZQyqnRofBDQosZLyeemozYTQHfQoGcawWeA");
    string gOcrePdcJsWoB = string("ZkAcONGrCuWmUPCvVgoIdJllCCuCymIusMHXrVMsUvIAezRznKBDmzFLvsEoeOOdOlULTWwHKzxCCKmXbMqybsxDmLFawUnOhzQyiqxhLiXFsAuUXOmgmQnPVmwwEfUkUTVPCItDoDVedVaHlQBaJJJWhdlGnGzAVOYQV");
    int gpTThpAX = -508876413;
    string qIDnb = string("UhWhSjxPBzusqYLRfXXiLPmYXAbgWWbfjtOjkTsdnCzKWvPybdwDRKWkpmJFeYXAlblGlXqmXwdloyAwSaglrxWVKGSFkzDakTktvibMQpKnjUUBcBxXBUEgdDnSmFfOFjeKtYNyTDxHhPgLEavLnvsyjCpCCyOjhwVEhpStoeDEnoXexVVwEaccPBkMCJCeGA");
    string vVGrBPU = string("xzrqKmhQaAkGC");
    string ZTUMdrrqmvTtvbqc = string("nwffNhLjbpobIacyiHlTWoMdZHUBHMCXnCDLKDMKSQVcWGeWSSjeymrHpWpPixQRvbJSSTEBGjxH");
    double gXDFMeWOvPYU = -233530.53016553767;
    int CuiYiqWEe = -1457533805;

    for (int vHKfywYvemPsr = 754315763; vHKfywYvemPsr > 0; vHKfywYvemPsr--) {
        gXDFMeWOvPYU += pDBDfyMSqCTHRBzu;
        yirLtvbVkx = gOcrePdcJsWoB;
        yirLtvbVkx += yirLtvbVkx;
    }

    if (gOcrePdcJsWoB >= string("nwffNhLjbpobIacyiHlTWoMdZHUBHMCXnCDLKDMKSQVcWGeWSSjeymrHpWpPixQRvbJSSTEBGjxH")) {
        for (int jkKiZEHm = 376176669; jkKiZEHm > 0; jkKiZEHm--) {
            qdlOMIiZgS += pDBDfyMSqCTHRBzu;
            qIDnb += yirLtvbVkx;
            gpTThpAX /= dqayNLaY;
        }
    }

    if (qIDnb < string("TlCJBIZSbHrVXoBAGmKSHQLwdPfNqaOsGySrHlClNaDZQyqnRofBDQosZLyeemozYTQHfQoGcawWeA")) {
        for (int DDRrgq = 1617494288; DDRrgq > 0; DDRrgq--) {
            pDBDfyMSqCTHRBzu *= TtnHgYpRV;
            gOcrePdcJsWoB += vVGrBPU;
            ZTUMdrrqmvTtvbqc = vVGrBPU;
        }
    }

    for (int MgjtpkDaPCZctBc = 22693192; MgjtpkDaPCZctBc > 0; MgjtpkDaPCZctBc--) {
        kdbIYLIhc += ZTUMdrrqmvTtvbqc;
        kdbIYLIhc += kdbIYLIhc;
    }

    return CuiYiqWEe;
}

int EmkuOcojxXRs::vCosYzyOEAkTZ(string crlwdxxpJFqpz, int yFGVwIk)
{
    int aIwtGySzeDL = -908072764;
    int GpHGTumoKLjED = -1733387274;
    string iyjPnrypqBl = string("xlxXfwOKxoFvJGJdANmcwNhxhjTbryOxZFduGjNvvupJLovrTxBHTNXgeXOQyidTXDrzWOmrVnIVGrbQZWUKxUPSNOzLsRyctyjsqXs");
    double HOEEzP = 231714.8402512478;
    int tMClZJocPPUjjEDs = 591820184;
    string eRMezc = string("vbDTVYzTJPPxWObjApHQUNDsrUGJfHPPQjzEMCiemOBZQYvLpNfgSuo");
    int avetVVrIYkDX = 1294374267;

    for (int aTeIvj = 207709989; aTeIvj > 0; aTeIvj--) {
        avetVVrIYkDX *= yFGVwIk;
        eRMezc += crlwdxxpJFqpz;
    }

    for (int oQVOFHX = 814490605; oQVOFHX > 0; oQVOFHX--) {
        tMClZJocPPUjjEDs -= avetVVrIYkDX;
    }

    for (int VplhuJ = 408902878; VplhuJ > 0; VplhuJ--) {
        aIwtGySzeDL += yFGVwIk;
        eRMezc = iyjPnrypqBl;
        GpHGTumoKLjED *= aIwtGySzeDL;
    }

    for (int oAqyqFAh = 250520288; oAqyqFAh > 0; oAqyqFAh--) {
        avetVVrIYkDX = avetVVrIYkDX;
        tMClZJocPPUjjEDs = aIwtGySzeDL;
        avetVVrIYkDX -= aIwtGySzeDL;
        crlwdxxpJFqpz += eRMezc;
    }

    return avetVVrIYkDX;
}

int EmkuOcojxXRs::ewezGaNWhRT(bool SgKzPkkzVTOTyY, double wxXPWRVXWzPwq, double hrLfxUMksERuUHy, bool GeDZkwi)
{
    bool uIANDjof = false;
    int RkLkM = 1554235994;
    bool XaZUgdXLQtzeDvI = true;
    string NGPWhsNtwUI = string("vqIfwJRntsZClzBYBmFuMYVIhHfMziNlgSOQRaoowcJMMzLtVsSfNMDkBvayAUTCqgCyDycFYbIyxFvMJPFnWGbGZNVfMbrWNIRNqlEwsSYKfUyryhAdzhMSARcsVdKSfpkGVkKXTPiqugnGlXGEiHrvMvpFzmCsLrrdUwvhVKRTOVsRItJZWWVUyWaVMPRfuinFXeodDyCNSfANyJCjHEVvVBkVXnwSTtdSvdXbENvijAEwSnsYOSSGQ");

    for (int mLhnLVvpd = 1253382027; mLhnLVvpd > 0; mLhnLVvpd--) {
        uIANDjof = SgKzPkkzVTOTyY;
        wxXPWRVXWzPwq *= hrLfxUMksERuUHy;
        XaZUgdXLQtzeDvI = SgKzPkkzVTOTyY;
        uIANDjof = SgKzPkkzVTOTyY;
    }

    return RkLkM;
}

EmkuOcojxXRs::EmkuOcojxXRs()
{
    this->gvuYqFyFrNkYOYDD(string("jeCXHISTvbMGffIglwhCGcgqZBZDnbydisdpUokaxggugzWMMrRlmzWRMCYOUEoQLRqYUfUmbyimaDjTIria"), true);
    this->oVjDnIHA(680327236);
    this->jCrfRka(string("OtqOwVjyGYcNVZqHJBrax"), true, string("WOhrfnPUoHcOcHkJuDopCCtugBLHADuplerMcbXSClqATZYQtzEXMCZEZaevQxRJRFLqjUeusSBLQOmffrHJLgofAZRsSUrpbYHlOrFCAyncCCgPiUrUPktuWLiKCQzowWOYtGsNCgADhJhsRkZKvmpLySWlGVapWjezGtxXHYECghMtJxpqK"));
    this->AHKsT(495514.00753240363, 772609945, -635461.8723981169, string("tQuENgsPpfntKoBYdXbkZnnkuvgbTmuZKhRGLkNHGShwWcXdtwMmuAyApdVhDuYKmoMJnZfveaXphuMYKquCvHqDcQjCSSHLsbTwUIakBzGGsjpOGCVJnjIeEYlRplWeTgjGseBElmcJvBqaXmcSDnPVV"), -701844.242526031);
    this->vCosYzyOEAkTZ(string("IJPTyGJealYMUiVBsJECQVQBNMPaCwrfiRSqizjVQVyyvtVHhuHkKgdbULqLqbIVRcigdsBKQbBiNdvFNwXiZBlGAswzjsOniEQRwMkrJrSGaxXgEyPhXVASYDlEQAnHSfCtaPvAdaoYYmLGejLlpiiTAoXjSpVFfsHUVzRxBVtMvvbnaeVwmSUAfKwvnxAXnkWPLzJsWatx"), 1930471624);
    this->ewezGaNWhRT(true, -404770.7697532187, -829979.5194315636, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pKckqMP
{
public:
    string LYEtH;
    bool RJNIliys;
    int MYaibuIwrrpEP;
    int kZMzkrdw;
    bool hFlKCHfyOtBRtAnN;
    double qzQXwTpGgREby;

    pKckqMP();
    void WJghxp(bool srMAmzSpL, double XuQkeMtxKPAsjB, string xIQuiWyclgOGNn, double qndrESnOePuzh, double xnHhQ);
    int TIeYLlraiAsT(string oQeFd, int dNzefZhBX, bool xEENHNK, string bHvdkacVNxNjCD);
    string unDsVtYW(string UnbVDRlK);
protected:
    bool gQDtAfgstTBH;
    int tXRCpUioExVXml;
    int VhrVw;
    double ClaLKPZeBixh;

    int ZZmkbqN(bool OrvlEyHSFZi, string mZzlglhZa, string DJNhyAQr);
    int afkztRSTdFHtXb(int NiKOpMjrjMfH);
    int hXxjoIEvm(double DVfdmYZwGwEJ, int gGspJEBipniciuah, bool eWuZwFWerEtgP, int NgXitfVwCilQQEeK);
    int AAdfvljsmTFcq(int OusTISsgiI);
    bool yMcwLGpQWHg(bool rualWjd, int dsTYlfnMmSnwpYdF);
    void pkFOfD(double YQlNGilToBHaOeS, string CTCXOEV, string JBpIYlzykFyDkG, int XfjtSPWpDNrWBhD);
private:
    bool dCtAqFVjAvVeql;
    int XzlOXTw;

    double qHmSrLZ(double JqrhaxqFeEI, int pkkLkJWTQFVWF);
    bool ltYXmZGNblYNmvr(double fiIsDzwVHmYAiCRp, bool CFCsLYJGKR, string XqJpKzblCzBNpk);
    double fBrtcHe(int GEqPviQTGHhsnM, double pqqWDuSTTZhuBkg, bool KNHbZVFXL, bool YGFsdXrtPS);
};

void pKckqMP::WJghxp(bool srMAmzSpL, double XuQkeMtxKPAsjB, string xIQuiWyclgOGNn, double qndrESnOePuzh, double xnHhQ)
{
    double UzPXFYHoeLWeIKhf = -729051.146555997;
    bool qLqONxLvO = true;
    string tvJyADODRS = string("TrQkmyhcAkmxNmvcbFJGCgForACkhMfsQhhOPujDoxgLgzCMMXZOSlsmewIYgzCsvQMKybTHGVXBzjoDUJBaQUhJUDzZTTPFtSFYuFjmBtYWrmPUFQXgcNqvodLEpPDEAvGezXfFitVBQKu");
    string cvKlyZVTgaVWQ = string("tGhIEUUumLcxqlZXoEJXwCpaRQqFUbTgYwJzcdGGFrqZNJwXdKyTdsPqktkOgdLjoApiP");
    string BWifDG = string("jhbnBguyzOBxtIxrNuwBsZxQuPfsvgEHIXAiWxNVNgsquBzGhXeGXkPQuYmEIoqzNmYakYVOgFsrbdesQCmFJgefmLfRBriBKSHIZcsYwLUWAtpxoCVJvqBEIDZJTIWedBJxqAzGmHIjFzurTrPjeGzCYa");
    double xPRFHjvLU = 59639.308748870215;
    bool ewbPLMrDsI = false;
    double ySbTZIbkQs = -361151.6005245794;
    string pnouJueOcRtTDbq = string("vlcOnYzYuIBMCIbFziDuiNJaIomSEJHGcvIfghlXqNLYHkropGvlgZJcEGRsIBQVxDSdufJPKsMAMIMfpknbYUeYMcSBcICaWFMllhVJsVKjnTynyauDRiqubDmRW");

    for (int AIWMbhv = 2047522621; AIWMbhv > 0; AIWMbhv--) {
        qndrESnOePuzh += xPRFHjvLU;
    }

    for (int HKEEEJoyZYyuYLS = 281257332; HKEEEJoyZYyuYLS > 0; HKEEEJoyZYyuYLS--) {
        continue;
    }

    if (BWifDG <= string("tGhIEUUumLcxqlZXoEJXwCpaRQqFUbTgYwJzcdGGFrqZNJwXdKyTdsPqktkOgdLjoApiP")) {
        for (int CHTiAKxGSMobz = 1837435081; CHTiAKxGSMobz > 0; CHTiAKxGSMobz--) {
            qLqONxLvO = qLqONxLvO;
            XuQkeMtxKPAsjB /= XuQkeMtxKPAsjB;
        }
    }

    if (cvKlyZVTgaVWQ <= string("tGhIEUUumLcxqlZXoEJXwCpaRQqFUbTgYwJzcdGGFrqZNJwXdKyTdsPqktkOgdLjoApiP")) {
        for (int LRTCPoVOjR = 457515915; LRTCPoVOjR > 0; LRTCPoVOjR--) {
            continue;
        }
    }

    for (int xJbGAXHwqKS = 1956895101; xJbGAXHwqKS > 0; xJbGAXHwqKS--) {
        xnHhQ *= qndrESnOePuzh;
        cvKlyZVTgaVWQ = BWifDG;
        xPRFHjvLU += xnHhQ;
        ySbTZIbkQs -= UzPXFYHoeLWeIKhf;
        tvJyADODRS = xIQuiWyclgOGNn;
    }

    if (xPRFHjvLU < 997849.3322923923) {
        for (int mPSCzVOH = 36427328; mPSCzVOH > 0; mPSCzVOH--) {
            xPRFHjvLU *= ySbTZIbkQs;
            UzPXFYHoeLWeIKhf += xPRFHjvLU;
            ewbPLMrDsI = ! qLqONxLvO;
        }
    }
}

int pKckqMP::TIeYLlraiAsT(string oQeFd, int dNzefZhBX, bool xEENHNK, string bHvdkacVNxNjCD)
{
    string cLqIFXAFGvhwqx = string("sIzYwzYSuLBZNFPNqgJhrLGQBfBCFFYvKyPyrdHlwnyORcRomfXvSTKaLzpGvLPUnQkUlEYwMfhZSKiZVQZznHcmyYSpySDUzJsfXSXmiCSNkYZivcsEjRYQlImKtjlVOKkhpYounepCwHXDvElVZHxgCmqLlRifqzsQLFsdJBlVsejGjNwDTvWGRlUvRrglwcPuWJzR");
    double HBPGxLmOFYD = 383955.8745679799;
    bool iQSFKkv = true;
    bool nxEoDnZZUAZlmAi = true;
    double QlDnaOCSHEQ = -902937.76463438;
    bool EJOlYXKepEg = false;
    string nAqkQt = string("vZWJNUjFhLddNSifbbLyYzrnCsGctUTDBWQM");
    bool yDBzAjFKmBRLJYrq = true;
    int NgOfrGDAwKdiNC = 1370547695;

    if (nAqkQt >= string("ruIljtyVWQnXeFDBFNJjfTnOvPJdGeKPrYpYvLpbPWKUfunTvyAMXSD")) {
        for (int pwsBnR = 27819682; pwsBnR > 0; pwsBnR--) {
            continue;
        }
    }

    for (int RkuftEQT = 1552302456; RkuftEQT > 0; RkuftEQT--) {
        xEENHNK = xEENHNK;
        yDBzAjFKmBRLJYrq = EJOlYXKepEg;
    }

    return NgOfrGDAwKdiNC;
}

string pKckqMP::unDsVtYW(string UnbVDRlK)
{
    bool iydfi = false;
    string vmVBoCSuT = string("gFbKoJgtsNzmuiBBMspawtgynVMQuKOVQFKQaYPZnYSxJKVezxNCwgsBNUwQIYKxZqPVFCSDoDspjpuldwJnuWvFHZYrcKFkYnKHcukJetWHwgpYtOXIpXluRGZSZvNqfFGGzXXfBhtVOIwQhSjIqFoBNnycTYVDrcQdojcQUzqUfaBT");
    string gntKffoqp = string("ETCfBYtiXtWYeptTqmbQGkEbKtjPzRbIRPEiDZkbqdqDVkcMdIutiVcj");
    string cFKBxwEmdp = string("EzrgALqbTYzNyCOAILlweYUFfYSjWNCguwEyTDVCXxbiXLlZfTPYWWuUCZwHfoyvLFIWOlGGwfNCvaSAnwQXWWDoaZCFGhLLORKcKICdBdKvDinEAUOfdaNyyDkNNAzenyRuYTROErQTmEuzFIdRgtlccHZjKzZgyhexmvbOfuBagVPyY");
    bool RCKWLZIcPy = false;
    string AFUAVv = string("fRtnFCsyHxLnxXaVzIUdiYHYlSComTOaVIpMFiNQcRHIMRheKquuhOznBYWYGBfBzVrGeVXkiBMzEJAmvQkvKUKxjTxKWwBRbWrKpcHHhBHlGmlKPlTvcrlnoutGMXJofmulxpzunTVBCrWRtSELyzAoAbfKhijSVAaNNOXdLcKTcSAnNpCIjMqVNPbglSko");
    bool GNDAGABCzNVXg = false;

    for (int cqiLWFfidLfY = 1639851460; cqiLWFfidLfY > 0; cqiLWFfidLfY--) {
        AFUAVv += cFKBxwEmdp;
        UnbVDRlK = UnbVDRlK;
    }

    for (int ERxtEaMzLwKqBF = 183406072; ERxtEaMzLwKqBF > 0; ERxtEaMzLwKqBF--) {
        GNDAGABCzNVXg = ! RCKWLZIcPy;
    }

    return AFUAVv;
}

int pKckqMP::ZZmkbqN(bool OrvlEyHSFZi, string mZzlglhZa, string DJNhyAQr)
{
    bool syjGflXsmWAEgdtr = true;
    string IONAaUmYZIxnGx = string("mJCqjWmjifLYcBAYTYZtvlTpqQDxSUMxqOoGrbNSJUZCtXjYoyPBJvotPzCKsyslkAgLGhwMnXVZEWGRFGDsXbTslDUDxaCUWcmFEvsrKWpaMWdqUSgXn");
    int lKwJSwkaCMJsH = 1450504572;
    double DyfyGIxQHUtup = 344456.42305776605;
    double aLrKGftEOZ = -993916.7560648479;
    int XOdJcWNIhp = 15580294;
    double KlXFoZgMf = 172008.0994102537;
    double GVkEREGW = -498252.8024602714;
    bool YDVzWqnXrYrH = false;
    bool WDFdunnJBfx = false;

    for (int EsiFInzqXzhMcPN = 1422703880; EsiFInzqXzhMcPN > 0; EsiFInzqXzhMcPN--) {
        syjGflXsmWAEgdtr = OrvlEyHSFZi;
    }

    for (int KZIPySKLLtex = 1498776231; KZIPySKLLtex > 0; KZIPySKLLtex--) {
        continue;
    }

    for (int IWzUnVpsVtjvnoLm = 1778707; IWzUnVpsVtjvnoLm > 0; IWzUnVpsVtjvnoLm--) {
        IONAaUmYZIxnGx += mZzlglhZa;
        DyfyGIxQHUtup -= DyfyGIxQHUtup;
        YDVzWqnXrYrH = YDVzWqnXrYrH;
        mZzlglhZa = DJNhyAQr;
    }

    if (GVkEREGW > -498252.8024602714) {
        for (int QjCTzVkgn = 342486689; QjCTzVkgn > 0; QjCTzVkgn--) {
            continue;
        }
    }

    for (int oAXaPWZTcu = 890474909; oAXaPWZTcu > 0; oAXaPWZTcu--) {
        continue;
    }

    return XOdJcWNIhp;
}

int pKckqMP::afkztRSTdFHtXb(int NiKOpMjrjMfH)
{
    int qVvDjwVsyjcql = 1318823602;
    int AWkFDoUxW = 47302371;
    double wOdHicvqrTet = -821695.5145139181;
    bool BtlcgGAWpyPTglq = false;
    string AEmhenhHNXz = string("CuhdIgfcrAq");
    bool JIXsidn = false;
    string DPsOiVpGdcjOsJH = string("oajKpeuWIZQGJmLwZoBxIpaJclNJQWTvSXyoQvOvbsQtnGsHUclCQXAXsJlorPklYsZkWgMrypCzGdFQQXpJgBmfApBGCLgaAchYOhIgicIlZGygKwmWUgciKnFiTUNnEmkwJGZHTXCBQhkKPKlBieTAETmikGsiGtZUTZQyAowWqKZlmnakzEHABPtPNDfrQQwgMbKAQfNbNzVdGyZdyKNuENHUeeAeWrMJDRUvPgaeQPJ");
    string eClOOY = string("AKBJiGfslSZOCocLLKETANAAoyXAughZFVkBLXpmBPtJnvMukmoSUBGMzKgmxmmhsFOgVNoMTgQrqdUYLVAgZfQsjSgpmvDINPlFyfsBzVRapqmHEYCLFOvWvSINYyUqWBDzFuVlAJPMIPwVBtZRHkHDwDrIKTnXbDZMgoMNHVUOohYZMdgpJLWyMKKWlPzODPVRDKyKBkTQAOavEvfZHPEVaJMmkxsRMYRpKRShRtivCrfSGzZt");
    int QkwcOeCcrOc = 634632468;
    int yNQWLTvgFJbeOdGx = 1584794547;

    for (int BcbaMazTu = 1243031124; BcbaMazTu > 0; BcbaMazTu--) {
        NiKOpMjrjMfH -= QkwcOeCcrOc;
        yNQWLTvgFJbeOdGx /= NiKOpMjrjMfH;
        qVvDjwVsyjcql -= yNQWLTvgFJbeOdGx;
        yNQWLTvgFJbeOdGx -= qVvDjwVsyjcql;
    }

    for (int sFhKPgxicGIU = 1153163481; sFhKPgxicGIU > 0; sFhKPgxicGIU--) {
        continue;
    }

    for (int JUgShhMGdh = 1588526950; JUgShhMGdh > 0; JUgShhMGdh--) {
        QkwcOeCcrOc -= qVvDjwVsyjcql;
        DPsOiVpGdcjOsJH += eClOOY;
    }

    for (int wxGJugezCfdbSvtR = 1917484242; wxGJugezCfdbSvtR > 0; wxGJugezCfdbSvtR--) {
        QkwcOeCcrOc *= yNQWLTvgFJbeOdGx;
    }

    return yNQWLTvgFJbeOdGx;
}

int pKckqMP::hXxjoIEvm(double DVfdmYZwGwEJ, int gGspJEBipniciuah, bool eWuZwFWerEtgP, int NgXitfVwCilQQEeK)
{
    bool tzdEyKU = true;
    double JlGYIby = 1037122.5578267748;
    string diusTzUWy = string("OGGFvpwbGSHMqPJzabhcPvEIEIZBndIFzqWAkDXXnSKBHo");
    bool fYExRasoS = false;
    bool numVFtSheF = false;

    if (DVfdmYZwGwEJ != -1030929.2296991993) {
        for (int avtITvSkf = 663908335; avtITvSkf > 0; avtITvSkf--) {
            fYExRasoS = ! eWuZwFWerEtgP;
        }
    }

    for (int JiIrNIj = 510532466; JiIrNIj > 0; JiIrNIj--) {
        NgXitfVwCilQQEeK += gGspJEBipniciuah;
        tzdEyKU = ! tzdEyKU;
    }

    for (int BoquKtsESdYClKpb = 2140863402; BoquKtsESdYClKpb > 0; BoquKtsESdYClKpb--) {
        DVfdmYZwGwEJ = JlGYIby;
    }

    if (JlGYIby != -1030929.2296991993) {
        for (int vviZiinfKBs = 1308387154; vviZiinfKBs > 0; vviZiinfKBs--) {
            fYExRasoS = ! tzdEyKU;
            DVfdmYZwGwEJ = JlGYIby;
        }
    }

    return NgXitfVwCilQQEeK;
}

int pKckqMP::AAdfvljsmTFcq(int OusTISsgiI)
{
    string xRnbIhhJxlP = string("UkiYAqEygjZjVmhYhyKUQrnWrUKOlwWTWhRUdkvEPbSQIgAVVYyCECvwCRcsXLPEHgbDfMHAqGmtjEYmZYXVaL");
    double jmfNycnbgWx = 265267.7378933157;
    int VvuIttfd = 358987303;
    double TKBNiLZKwNmGiMTq = -94475.51151613193;
    string bEiHTiEPkx = string("HTmBNXreAJfyCeUBWEifgxNzwTjoXITzXFGovOehAQIctAyEWvdHWKvdQYPSYfgMhXtCBvHFAwcZaDlbCybyPtJcJGvjfPcoBkPyshtlX");
    int vWgjIlEi = 140475619;
    int ONeJFVYucXtPR = -1471903154;

    for (int VKsQRzUjWphpOR = 813866782; VKsQRzUjWphpOR > 0; VKsQRzUjWphpOR--) {
        TKBNiLZKwNmGiMTq = TKBNiLZKwNmGiMTq;
        vWgjIlEi -= vWgjIlEi;
    }

    return ONeJFVYucXtPR;
}

bool pKckqMP::yMcwLGpQWHg(bool rualWjd, int dsTYlfnMmSnwpYdF)
{
    string XLzPgsp = string("HPgIlpVsTnfoUAbkBdVtSeWCkBnzNCyMfMgOLsDQpqArefkrDVAAivJdFgfrij");
    bool oSFpyLHAGPRalx = true;
    string BTjfvsAyDaVKR = string("ZNoiwsjSnrBJyZBJnVzTbuqeAUVJNbvljkqrAAvTgrarIOmhScHivMWqzwFdplVshWwYlXxbSGQJUVWAXpABBsmjXEGKbChAibprOUpMvnWsngFTFCXcfljzrJtuwbAYCHnrtENpXGUnzFKoLqQDzUVKPEPnrnKGoIeeBcnPgJpdiOwOEhimlYt");
    int oCusmXnHBUD = 1352481298;

    if (oSFpyLHAGPRalx == true) {
        for (int fEtZQo = 440581545; fEtZQo > 0; fEtZQo--) {
            dsTYlfnMmSnwpYdF /= oCusmXnHBUD;
        }
    }

    for (int vgiiWdmA = 1349298645; vgiiWdmA > 0; vgiiWdmA--) {
        XLzPgsp = BTjfvsAyDaVKR;
        XLzPgsp = BTjfvsAyDaVKR;
        XLzPgsp += XLzPgsp;
        BTjfvsAyDaVKR = XLzPgsp;
        dsTYlfnMmSnwpYdF = oCusmXnHBUD;
    }

    return oSFpyLHAGPRalx;
}

void pKckqMP::pkFOfD(double YQlNGilToBHaOeS, string CTCXOEV, string JBpIYlzykFyDkG, int XfjtSPWpDNrWBhD)
{
    int xUvCNUGFqlsaDQV = -2101320118;
    int bxOgWhk = 1965282018;
    double LfYqviNHfPEpj = -846616.4119592702;
    bool wvbEqjoAtn = false;
    string KxiTBifXa = string("MALsbUMdPzCroRmxKdizgsAEouheixjAouUvPoPbXDCmUbbLNgRaduQHjYblMgDwYVYgApacPlTLrHWqBlZDsQzqiAAwShUfkOAjNfGPrxEgzcESgGYDMBgXwiiViokriDkfsIQuIYBsdjVJLCwFkopjRAFcMfsXtZtDAoaVkKwIIIzWKPDyyNq");
    bool wVIOsoW = false;

    if (bxOgWhk >= -835738767) {
        for (int WxdKgLvqAMIcvMN = 1279920985; WxdKgLvqAMIcvMN > 0; WxdKgLvqAMIcvMN--) {
            JBpIYlzykFyDkG += KxiTBifXa;
        }
    }

    for (int AMMZSRrGgl = 547539541; AMMZSRrGgl > 0; AMMZSRrGgl--) {
        continue;
    }

    for (int vcGHRnQ = 43454288; vcGHRnQ > 0; vcGHRnQ--) {
        XfjtSPWpDNrWBhD -= XfjtSPWpDNrWBhD;
        LfYqviNHfPEpj = LfYqviNHfPEpj;
    }

    for (int xqznQ = 1469225534; xqznQ > 0; xqznQ--) {
        XfjtSPWpDNrWBhD = bxOgWhk;
    }

    if (XfjtSPWpDNrWBhD != -2101320118) {
        for (int YCqJmCAOTO = 659969073; YCqJmCAOTO > 0; YCqJmCAOTO--) {
            KxiTBifXa += JBpIYlzykFyDkG;
        }
    }

    if (XfjtSPWpDNrWBhD >= -2101320118) {
        for (int yiRYbsgpMJ = 1698075863; yiRYbsgpMJ > 0; yiRYbsgpMJ--) {
            LfYqviNHfPEpj -= LfYqviNHfPEpj;
            JBpIYlzykFyDkG += CTCXOEV;
            xUvCNUGFqlsaDQV += XfjtSPWpDNrWBhD;
        }
    }
}

double pKckqMP::qHmSrLZ(double JqrhaxqFeEI, int pkkLkJWTQFVWF)
{
    string CBEzppMYafcYLLP = string("ySTtqLOYsuRDZskyZzYuTwQTlXhoAjVrUtkzLAxAuijKbVuKfvbImYlxxMpJrmYeFYNNYiUemryLYgjaSqkycYeAWMOPFtdnOeCDtBdcXMafjeoWBSoyQSCGfqHBXm");
    bool YqwkWEnSzPCmwku = true;
    int rrzPkAayIqfKjqz = 2046330570;
    bool CtquudHrwHIcTpAV = false;
    bool PGAFQB = false;
    bool QyXogBEMMYdbcmGf = false;
    double CnczjchLhZosLUJ = -122747.11893175263;
    double kqzfKhuVNPFEZV = 580893.2651874518;
    string pazXynKh = string("Vya");

    for (int esuAnYRKGDZsynH = 2081231908; esuAnYRKGDZsynH > 0; esuAnYRKGDZsynH--) {
        rrzPkAayIqfKjqz = rrzPkAayIqfKjqz;
        QyXogBEMMYdbcmGf = ! CtquudHrwHIcTpAV;
    }

    return kqzfKhuVNPFEZV;
}

bool pKckqMP::ltYXmZGNblYNmvr(double fiIsDzwVHmYAiCRp, bool CFCsLYJGKR, string XqJpKzblCzBNpk)
{
    bool QxARIuYpTcSX = false;
    string ItKiVCNEnK = string("MuvI");
    bool GSrWJeripNxc = false;
    string fnlPd = string("UzTOtCCHeoMrhgFOImmjnUuLJUOsHpyRoZLcirmGvEKeIVqAHRqeNwLauLnRDlrYadecZdwJPKOloyYCfBLiTWJkbDeJiSDWaImJTPlyhcisSWbjOoTbdJvjhYEzKKiERSzhYovqZKFVWjXFyRgnPDuRddcAmjAxHqmNeJcwbOTWuFWvdQBJKzDdNJYFzixFRSsqCmJUreGCiHYhWFQVlGyVaWHBsVufsBIeWbcGOpAfiEupWktxcUVEEjXr");
    bool DVXkeAmLtQc = true;
    bool uHeCYK = true;
    int YhjgbJbGelpOk = -1252790510;
    bool iclSxNbIxFuFqMN = true;
    double zNdwvUyFoqd = -259034.0203863431;
    bool FALFanG = false;

    for (int vHKDMFVVl = 131707036; vHKDMFVVl > 0; vHKDMFVVl--) {
        FALFanG = CFCsLYJGKR;
    }

    for (int XSomsnWUHHChVKP = 1538781147; XSomsnWUHHChVKP > 0; XSomsnWUHHChVKP--) {
        ItKiVCNEnK += fnlPd;
        zNdwvUyFoqd += zNdwvUyFoqd;
        GSrWJeripNxc = ! CFCsLYJGKR;
    }

    if (iclSxNbIxFuFqMN == false) {
        for (int mUIIVqPqHaQCx = 2029655736; mUIIVqPqHaQCx > 0; mUIIVqPqHaQCx--) {
            uHeCYK = QxARIuYpTcSX;
            fiIsDzwVHmYAiCRp *= fiIsDzwVHmYAiCRp;
            fnlPd += ItKiVCNEnK;
            FALFanG = iclSxNbIxFuFqMN;
        }
    }

    if (DVXkeAmLtQc != true) {
        for (int yqnAi = 1210115095; yqnAi > 0; yqnAi--) {
            FALFanG = ! uHeCYK;
        }
    }

    for (int bHiKPZSHR = 1306026466; bHiKPZSHR > 0; bHiKPZSHR--) {
        FALFanG = ! GSrWJeripNxc;
        zNdwvUyFoqd -= zNdwvUyFoqd;
        QxARIuYpTcSX = ! QxARIuYpTcSX;
        FALFanG = ! CFCsLYJGKR;
    }

    if (DVXkeAmLtQc == true) {
        for (int dVZyZch = 1430007019; dVZyZch > 0; dVZyZch--) {
            uHeCYK = ! GSrWJeripNxc;
        }
    }

    return FALFanG;
}

double pKckqMP::fBrtcHe(int GEqPviQTGHhsnM, double pqqWDuSTTZhuBkg, bool KNHbZVFXL, bool YGFsdXrtPS)
{
    bool sfuaaGgadWD = true;
    bool ympJXhvFAycWvzNT = false;
    double FrSomO = 975078.5793172448;
    bool kbwfeTrMMgDziVIT = true;
    bool REbudYi = false;
    bool AyeAQMzNzSVcJnVw = true;
    string tRnIxzszWgXQDGe = string("lCQTnXicSYNnojhQboSeiaCnQnmhnMgpDbXlL");
    string AbMSibz = string("CEiOXIDkMszIgDwqqyfWhrnkenLWGH");
    double NgzZitjglc = 815388.1198629988;
    int UoFljsSDUbe = -1786485295;

    for (int IyHLNbQE = 1337428274; IyHLNbQE > 0; IyHLNbQE--) {
        REbudYi = ! kbwfeTrMMgDziVIT;
    }

    return NgzZitjglc;
}

pKckqMP::pKckqMP()
{
    this->WJghxp(false, -304320.72308244946, string("XjuqwZNksomdmVEdIWikdZIRYFowKzwxwenptFrcMIJsLXVByCnjsoLjwUnxRrvwfKcIIVcvduNmEbcXPMxQfQrZdRMDMWhwjpTXKgOlarUcwKwwuRiaKcdNfyAxSQDXZquNjvcxCVUSLSivmlWjzDtCcidXbQNTGzgDTYoTZeNvcBwhqBN"), -447956.68803086976, 997849.3322923923);
    this->TIeYLlraiAsT(string("ruIljtyVWQnXeFDBFNJjfTnOvPJdGeKPrYpYvLpbPWKUfunTvyAMXSD"), -1331971491, false, string("TIgLDyDjOtnwTdxtayzVfRlTSpwMPivmZmEgtjkNUrbRXcnUSNHceXUoDdbTFPrbbuIAhxkNvVyUDscciJDLaBFmzgpSoHhsHrZFVhiejTICrXqoMlu"));
    this->unDsVtYW(string("ihUkcVkiygxREYHWrrDQKgqlWJPlvlrfEhyJVvDgXFCtUAfTKzmXfmYVRokajdagIAqFPsVErGsEMvxguHDbEyAJOQpWUmyZEdGZSgkGutOpCWDJUUXwSpZbpIkrknRMDeRSDioZTnsrpfYQkYXfebjDHqRIvCNZzFEriZGPrlCQVrJXtEwMUymzbNRnadcvLOEcxoxwRLYzbJUNKKscgklwmqoH"));
    this->ZZmkbqN(false, string("wJdVlXGjrEWicncRVelVdmQAqtCQiaFBLmQRcsEIspcCMGbwgXEMrhfnPCvbiqZisMjDDZbpdKvYWePQceJiKCotrcW"), string("OcMWTKJKXnQMSbqTJdiDbmkLhWzUyNmlOVyLwYbrpNEiyPaYoSOlWOCLIEbLVEPOtTEpxtIjesUaoryxMzGdAjxtYeNTomEUHZxvkMBewWtKWnETfLQRgNaepUMzScvsxZdRuCyuhULwLPbMZHLnnpIEpfnAiHpWkrLpEpBfUkDlgIsoaoSpzqvnVDgsStcvTqBpqBNejtjfL"));
    this->afkztRSTdFHtXb(-117394418);
    this->hXxjoIEvm(-1030929.2296991993, 608313123, true, -291748916);
    this->AAdfvljsmTFcq(-1649979871);
    this->yMcwLGpQWHg(true, 1464347984);
    this->pkFOfD(-989736.7419181367, string("NUPAtLpuEWlrPogrHSnSXVUQVfdJutNHUkJhqMgiIsPXeRNNAUhayRtACxbEQwBZhQxZjWGlGOuihHezpZJwBPpSaOsVYPLlOCyksUTXuSPhwZjM"), string("cuTUZckkVgJXaHtNnJrVRqAlFVcyJvv"), -835738767);
    this->qHmSrLZ(-371843.2806063754, -1603622308);
    this->ltYXmZGNblYNmvr(-721918.4542170638, true, string("oRcmQaJuKaHSHBjgKQcElfIAedqzUeXMZiZHdmjUToWdYtKbhmWOCsKfMWXjoyXzODTorogojmLplwfyWOCweDdaquRwYfspHcijIuyVcJOPyFEKWwUpZQOGSl"));
    this->fBrtcHe(-993115535, 333884.03885227867, true, true);
}
