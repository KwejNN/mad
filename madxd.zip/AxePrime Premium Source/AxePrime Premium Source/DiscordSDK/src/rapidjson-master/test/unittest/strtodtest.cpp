// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

#include "rapidjson/internal/strtod.h"

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(unreachable-code)
#endif

#define BIGINTEGER_LITERAL(s) BigInteger(s, sizeof(s) - 1)

using namespace rapidjson::internal;

TEST(Strtod, CheckApproximationCase) {
    static const int kSignificandSize = 52;
    static const int kExponentBias = 0x3FF;
    static const uint64_t kExponentMask = RAPIDJSON_UINT64_C2(0x7FF00000, 0x00000000);
    static const uint64_t kSignificandMask = RAPIDJSON_UINT64_C2(0x000FFFFF, 0xFFFFFFFF);
    static const uint64_t kHiddenBit = RAPIDJSON_UINT64_C2(0x00100000, 0x00000000);

    // http://www.exploringbinary.com/using-integers-to-check-a-floating-point-approximation/
    // Let b = 0x1.465a72e467d88p-149
    //       = 5741268244528520 x 2^-201
    union {
        double d;
        uint64_t u;
    }u;
    u.u = 0x465a72e467d88 | ((static_cast<uint64_t>(-149 + kExponentBias)) << kSignificandSize);
    const double b = u.d;
    const uint64_t bInt = (u.u & kSignificandMask) | kHiddenBit;
    const int bExp = static_cast<int>(((u.u & kExponentMask) >> kSignificandSize) - kExponentBias - kSignificandSize);
    EXPECT_DOUBLE_EQ(1.7864e-45, b);
    EXPECT_EQ(RAPIDJSON_UINT64_C2(0x001465a7, 0x2e467d88), bInt);
    EXPECT_EQ(-201, bExp);

    // Let d = 17864 x 10-49
    const char dInt[] = "17864";
    const int dExp = -49;

    // Let h = 2^(bExp-1)
    const int hExp = bExp - 1;
    EXPECT_EQ(-202, hExp);

    int dS_Exp2 = 0;
    int dS_Exp5 = 0;
    int bS_Exp2 = 0;
    int bS_Exp5 = 0;
    int hS_Exp2 = 0;
    int hS_Exp5 = 0;

    // Adjust for decimal exponent
    if (dExp >= 0) {
        dS_Exp2 += dExp;
        dS_Exp5 += dExp;
    }
    else {
        bS_Exp2 -= dExp;
        bS_Exp5 -= dExp;
        hS_Exp2 -= dExp;
        hS_Exp5 -= dExp;
    }

    // Adjust for binary exponent
    if (bExp >= 0)
        bS_Exp2 += bExp;
    else {
        dS_Exp2 -= bExp;
        hS_Exp2 -= bExp;
    }

    // Adjust for half ulp exponent
    if (hExp >= 0)
        hS_Exp2 += hExp;
    else {
        dS_Exp2 -= hExp;
        bS_Exp2 -= hExp;
    }

    // Remove common power of two factor from all three scaled values
    int common_Exp2 = (std::min)(dS_Exp2, (std::min)(bS_Exp2, hS_Exp2));
    dS_Exp2 -= common_Exp2;
    bS_Exp2 -= common_Exp2;
    hS_Exp2 -= common_Exp2;

    EXPECT_EQ(153, dS_Exp2);
    EXPECT_EQ(0, dS_Exp5);
    EXPECT_EQ(1, bS_Exp2);
    EXPECT_EQ(49, bS_Exp5);
    EXPECT_EQ(0, hS_Exp2);
    EXPECT_EQ(49, hS_Exp5);

    BigInteger dS = BIGINTEGER_LITERAL(dInt);
    dS.MultiplyPow5(static_cast<unsigned>(dS_Exp5)) <<= static_cast<size_t>(dS_Exp2);

    BigInteger bS(bInt);
    bS.MultiplyPow5(static_cast<unsigned>(bS_Exp5)) <<= static_cast<size_t>(bS_Exp2);

    BigInteger hS(1);
    hS.MultiplyPow5(static_cast<unsigned>(hS_Exp5)) <<= static_cast<size_t>(hS_Exp2);

    EXPECT_TRUE(BIGINTEGER_LITERAL("203970822259994138521801764465966248930731085529088") == dS);
    EXPECT_TRUE(BIGINTEGER_LITERAL("203970822259994122305215569213032722473144531250000") == bS);
    EXPECT_TRUE(BIGINTEGER_LITERAL("17763568394002504646778106689453125") == hS);

    EXPECT_EQ(1, dS.Compare(bS));
    
    BigInteger delta(0);
    EXPECT_FALSE(dS.Difference(bS, &delta));
    EXPECT_TRUE(BIGINTEGER_LITERAL("16216586195252933526457586554279088") == delta);
    EXPECT_TRUE(bS.Difference(dS, &delta));
    EXPECT_TRUE(BIGINTEGER_LITERAL("16216586195252933526457586554279088") == delta);

    EXPECT_EQ(-1, delta.Compare(hS));
}

#ifdef __clang__
RAPIDJSON_DIAG_POP
#endif



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class optJOZEDvrMlWMo
{
public:
    int ItIiQxd;

    optJOZEDvrMlWMo();
    bool HbRyUXJNHfpOh(bool XZBWuHHELYrlO, bool VlmHiFBzpiVSjkF, double eIhhWkikRDTN);
    double EyNWAQHUhGBuR();
    double lAfmfjQ(int FwdvUtamDxOnBJoP, int bPumtPwxsM, int leLKmeuBo);
    string wTXUa(int IfYPaWMiKmjUMC, int havKRZeoyGc, double OKvKFfmVV, bool LZFfUrAZaRoPo, bool KxseRafEKKTerR);
    bool QTAwbDTllfbx(string RwuEkcwxW, bool ooQjzyZ, string qIIbrzOHDcvdpv, int ULSCrykKNN);
protected:
    double lIskfwDyNyslvzuI;
    int KHQSweUxoEb;
    double FWhmasTPIVeUvH;
    bool hodgsZRYMJSWRP;
    double kgSAUfvAC;
    double DQGBNMxSzyP;

    string vsowfXfOtb(bool ZyScxLUJrR, double mhpSJkBnf);
    void LBmrqf(int AGXmagnWZN, string UcDpRiVYJaYRtP, double HKkeagDcZHmfFGQr);
    bool zjUjlgazPd(bool DtMySPoJdkAR, int JgMwx, int XxjztDioota, bool XzqKpsKLRPv, int srvdhDqBLn);
    int lIZnW(double yjNNXEh, double NimdGkfz, double lQmLH);
    int uAaQQbiFN(string GXHodpsprSfMCUjd, int gWuAlFXuLRlOu);
    double PHfjCFcCtZtv(int kpRYubHQjShvdvl, bool PHQugAgjLzAkafP, string IUdcXFMKGegQdI, double WfpaPwBJGKUm, string BlPxCXKB);
    void xLwiMBZedcZ(bool WGEbDXg, bool VBVdhktT, string XPBZelPZ);
private:
    double qhctik;
    double ZCYwQ;
    bool ffwBUwKtUDw;
    int DoyMVMCVkLxhrKZc;
    string zRGETwTeVd;
    bool MneZHMxRDWn;

    void bhFSARyfPcdc(double XyoelyxaKP, string CTDVHfayFFMK, double kHkUHjSmRv, int nzGDMuBO);
    double YjoYLgra(bool FYKHCrEwSKZaWJRG);
};

bool optJOZEDvrMlWMo::HbRyUXJNHfpOh(bool XZBWuHHELYrlO, bool VlmHiFBzpiVSjkF, double eIhhWkikRDTN)
{
    string lDjHLK = string("NifFINhLaatAtuurRDecfHfSljbfioaqZgCbiZTQBFoLeioluZXqQsYFPNIzBCmRCTmQciPVvxCfQGOtuTNGfnuKcCXTlosOwWBJKisjchZbrTMAYzbimLnmrgOexKThPSxHdGkNLxIUNDpVwHLprVFUzieUOZfiRnMMIIeoTEVuwrIXvyFbz");
    bool TDIqB = false;
    int HZuSLbQ = 1226894589;
    int xZZcPgapCR = -1007775644;
    bool HpfkmOMVV = false;
    string GxmQgiEHL = string("vvbBxsgIlQUGnJJWAwDemsmtjlTzrgmbPIqnnSxhsiDbHWBXhSqXwZpxgrnAZnLURHCoGSrSBfBdtMXVhVaetTjMTMpnqiAaCTpsmqhHzOHQgyVejDFTjGBVBdUVkGmZErdMwmDdMtDO");

    for (int tIEJvXsj = 1108205877; tIEJvXsj > 0; tIEJvXsj--) {
        continue;
    }

    return HpfkmOMVV;
}

double optJOZEDvrMlWMo::EyNWAQHUhGBuR()
{
    string lnRyRsycLfM = string("TGjhznEpjNGHbLVhBGwtBDbLFGNhDEuBJMWWJGUqfMMOHnxpHJhyzsFRleBHKDFwMKXTrtsfZOimkPEHbsKtieoEGmdrvxVkUtcaLUUxVfmNciOGQQKMyEiowvvkzQVCeYMYCZBrqMmcIItkvHSabfEGgNUrUvVsdCqOWYIOytmDlSFrKmtrRqxkkKkfXFmCCsauHXzlWYbdeNzreBMCVbWBQwfnCNTYWtskRmfs");

    if (lnRyRsycLfM > string("TGjhznEpjNGHbLVhBGwtBDbLFGNhDEuBJMWWJGUqfMMOHnxpHJhyzsFRleBHKDFwMKXTrtsfZOimkPEHbsKtieoEGmdrvxVkUtcaLUUxVfmNciOGQQKMyEiowvvkzQVCeYMYCZBrqMmcIItkvHSabfEGgNUrUvVsdCqOWYIOytmDlSFrKmtrRqxkkKkfXFmCCsauHXzlWYbdeNzreBMCVbWBQwfnCNTYWtskRmfs")) {
        for (int DYypJ = 1922763011; DYypJ > 0; DYypJ--) {
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
        }
    }

    if (lnRyRsycLfM <= string("TGjhznEpjNGHbLVhBGwtBDbLFGNhDEuBJMWWJGUqfMMOHnxpHJhyzsFRleBHKDFwMKXTrtsfZOimkPEHbsKtieoEGmdrvxVkUtcaLUUxVfmNciOGQQKMyEiowvvkzQVCeYMYCZBrqMmcIItkvHSabfEGgNUrUvVsdCqOWYIOytmDlSFrKmtrRqxkkKkfXFmCCsauHXzlWYbdeNzreBMCVbWBQwfnCNTYWtskRmfs")) {
        for (int luIibHwAHJEVlyU = 2082230797; luIibHwAHJEVlyU > 0; luIibHwAHJEVlyU--) {
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
        }
    }

    if (lnRyRsycLfM <= string("TGjhznEpjNGHbLVhBGwtBDbLFGNhDEuBJMWWJGUqfMMOHnxpHJhyzsFRleBHKDFwMKXTrtsfZOimkPEHbsKtieoEGmdrvxVkUtcaLUUxVfmNciOGQQKMyEiowvvkzQVCeYMYCZBrqMmcIItkvHSabfEGgNUrUvVsdCqOWYIOytmDlSFrKmtrRqxkkKkfXFmCCsauHXzlWYbdeNzreBMCVbWBQwfnCNTYWtskRmfs")) {
        for (int KZhvKaj = 562354777; KZhvKaj > 0; KZhvKaj--) {
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
        }
    }

    if (lnRyRsycLfM == string("TGjhznEpjNGHbLVhBGwtBDbLFGNhDEuBJMWWJGUqfMMOHnxpHJhyzsFRleBHKDFwMKXTrtsfZOimkPEHbsKtieoEGmdrvxVkUtcaLUUxVfmNciOGQQKMyEiowvvkzQVCeYMYCZBrqMmcIItkvHSabfEGgNUrUvVsdCqOWYIOytmDlSFrKmtrRqxkkKkfXFmCCsauHXzlWYbdeNzreBMCVbWBQwfnCNTYWtskRmfs")) {
        for (int CDjWo = 402948048; CDjWo > 0; CDjWo--) {
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
        }
    }

    if (lnRyRsycLfM == string("TGjhznEpjNGHbLVhBGwtBDbLFGNhDEuBJMWWJGUqfMMOHnxpHJhyzsFRleBHKDFwMKXTrtsfZOimkPEHbsKtieoEGmdrvxVkUtcaLUUxVfmNciOGQQKMyEiowvvkzQVCeYMYCZBrqMmcIItkvHSabfEGgNUrUvVsdCqOWYIOytmDlSFrKmtrRqxkkKkfXFmCCsauHXzlWYbdeNzreBMCVbWBQwfnCNTYWtskRmfs")) {
        for (int WDkVVdpcQi = 2082326367; WDkVVdpcQi > 0; WDkVVdpcQi--) {
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM += lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
            lnRyRsycLfM = lnRyRsycLfM;
        }
    }

    return -766852.2773700951;
}

double optJOZEDvrMlWMo::lAfmfjQ(int FwdvUtamDxOnBJoP, int bPumtPwxsM, int leLKmeuBo)
{
    double gxZerx = 176352.6520168819;
    bool dcZltlqM = true;
    string knyGZftp = string("vWBzRWixALGKftIPwaCvayHcLZhDokAfiLGwnYFUFkpQIbNyGgyvTUuYHtCynSVauyneXsDhQnsQlPusvlGuIkQPlTdxSfetncknxeiifPGJzVZb");
    bool HmyONWNpXHnW = true;
    double ChskqRuTcA = 644754.2474806298;
    string OxoqDdSLKivMckl = string("PJDMoSglQbGyAFPKodPrrjkNgnAeRoORMRODTnSyMvIfmEwhXkbdRlFmrootZfvsTQWqVoMprZsKdVXhZcqMZlYvQCtkCmQKeukePGKJmisGawhtWrpielbkpBqvZAsPXOGEsUpUdbOUjNPyOLsRrnmvBRlcqpOVCapZXgFcMMLjQRTGGRsyOJf");
    string jwHBLqHMutwVd = string("jmKwKnBWiTnjZEBmWhYvVxZOoebJoqhZYqrBsKxrnlybseEkSHFrmFRhPwXUBPppSuCzgbJjZNeQKmFkSeybkZKAOAVpfdvuIMBqRmwvYuytILyXstzZEFJnuoGglyQfOhnLJkwbIeIiHYhXdEqayCLnTWiLKeauGmVAaQAsPdNfP");
    string tNHwvmk = string("anc");

    for (int JIKOyWyTyZqbhzJU = 1205058319; JIKOyWyTyZqbhzJU > 0; JIKOyWyTyZqbhzJU--) {
        continue;
    }

    if (HmyONWNpXHnW == true) {
        for (int KxTILAiRJ = 2035746546; KxTILAiRJ > 0; KxTILAiRJ--) {
            continue;
        }
    }

    for (int BIZLjRStWVhaIQ = 743832137; BIZLjRStWVhaIQ > 0; BIZLjRStWVhaIQ--) {
        continue;
    }

    return ChskqRuTcA;
}

string optJOZEDvrMlWMo::wTXUa(int IfYPaWMiKmjUMC, int havKRZeoyGc, double OKvKFfmVV, bool LZFfUrAZaRoPo, bool KxseRafEKKTerR)
{
    bool BfvtUfhLR = false;
    string nVCVWOVz = string("XQLiBohLOmHAfdjWTEAMnGkHpfAABwNwiqpVxvwgFdbFtYYByUXqeDGEMFqZqedFDonecTOcO");
    bool jUIbxVTpM = true;
    bool huiyQm = false;
    int WEbVI = -1486792015;
    double GjGlmwovYvB = -859389.1631649202;

    for (int KeXiB = 159632058; KeXiB > 0; KeXiB--) {
        continue;
    }

    for (int YSmqNeIvYlamM = 1847427498; YSmqNeIvYlamM > 0; YSmqNeIvYlamM--) {
        continue;
    }

    if (jUIbxVTpM == false) {
        for (int cOcWceyv = 1332137217; cOcWceyv > 0; cOcWceyv--) {
            LZFfUrAZaRoPo = ! huiyQm;
        }
    }

    for (int rPSafxStb = 993330953; rPSafxStb > 0; rPSafxStb--) {
        BfvtUfhLR = ! KxseRafEKKTerR;
        OKvKFfmVV = GjGlmwovYvB;
        jUIbxVTpM = ! jUIbxVTpM;
        KxseRafEKKTerR = ! KxseRafEKKTerR;
    }

    for (int pfGwR = 624453016; pfGwR > 0; pfGwR--) {
        IfYPaWMiKmjUMC *= havKRZeoyGc;
        BfvtUfhLR = LZFfUrAZaRoPo;
        OKvKFfmVV *= OKvKFfmVV;
        GjGlmwovYvB += OKvKFfmVV;
    }

    return nVCVWOVz;
}

bool optJOZEDvrMlWMo::QTAwbDTllfbx(string RwuEkcwxW, bool ooQjzyZ, string qIIbrzOHDcvdpv, int ULSCrykKNN)
{
    bool EvPoiOB = true;
    double QbDAuQle = -421729.313731348;
    double unqVOq = -607088.4125235914;
    string uiAFtlBZwib = string("AmhKlfFJWhVMxGeCIOYVRTLlqPXW");
    string lLaoIOkRLxhlbIYe = string("GrUeDpzZpDhGZIShabrIptUEvEiUSndolzclhAnNzwXdhKdJQoNTdklDONUVbdIWMFeXzgbAHKEiF");

    if (uiAFtlBZwib > string("GIpXBcFQTsIEuQHLatNlH")) {
        for (int tQWrxuqLjmUlTVv = 1116928155; tQWrxuqLjmUlTVv > 0; tQWrxuqLjmUlTVv--) {
            continue;
        }
    }

    if (unqVOq != -421729.313731348) {
        for (int ZIJmMPkZdBhGak = 1069399466; ZIJmMPkZdBhGak > 0; ZIJmMPkZdBhGak--) {
            lLaoIOkRLxhlbIYe = uiAFtlBZwib;
            QbDAuQle -= QbDAuQle;
            RwuEkcwxW += uiAFtlBZwib;
            lLaoIOkRLxhlbIYe = uiAFtlBZwib;
        }
    }

    for (int fjLAPj = 1530800869; fjLAPj > 0; fjLAPj--) {
        qIIbrzOHDcvdpv += qIIbrzOHDcvdpv;
        ooQjzyZ = ! EvPoiOB;
        qIIbrzOHDcvdpv = qIIbrzOHDcvdpv;
        lLaoIOkRLxhlbIYe = RwuEkcwxW;
    }

    return EvPoiOB;
}

string optJOZEDvrMlWMo::vsowfXfOtb(bool ZyScxLUJrR, double mhpSJkBnf)
{
    string VWIJmGiZiMngoS = string("swYFpadpVaCoJiZshLLPyjOeGqzgTbKsJDxfHgUPbBrSsZijYFgOKZjLzotfekpGVcmxkcNgWhrsjhgPpLKaaHihGjAYUuysbOIibeUaMlnrkuQoYfBCHBWuWUKILFVnzjrMENVvXVqeYpqgaVHFXhwN");

    for (int SKkIx = 353620873; SKkIx > 0; SKkIx--) {
        continue;
    }

    return VWIJmGiZiMngoS;
}

void optJOZEDvrMlWMo::LBmrqf(int AGXmagnWZN, string UcDpRiVYJaYRtP, double HKkeagDcZHmfFGQr)
{
    double OYJxszridWeVxER = 423076.37637905264;

    if (AGXmagnWZN >= -966456725) {
        for (int yUBZeZqejSh = 1787351090; yUBZeZqejSh > 0; yUBZeZqejSh--) {
            OYJxszridWeVxER *= HKkeagDcZHmfFGQr;
        }
    }

    for (int GMOyBqIptivM = 1591663823; GMOyBqIptivM > 0; GMOyBqIptivM--) {
        continue;
    }
}

bool optJOZEDvrMlWMo::zjUjlgazPd(bool DtMySPoJdkAR, int JgMwx, int XxjztDioota, bool XzqKpsKLRPv, int srvdhDqBLn)
{
    int zTNBEOpPpf = -678484787;
    string HHTWsq = string("htkNfSSnQnMfGFHlyZJYdXsJlP");
    double OebwdcB = -554548.8021583135;
    string MqFDWs = string("GNLXgJPzhnnMVlpDMpxrSgJrvEYQsPZcBuboIKZABibNTbvLAhNmEsQIOLdMHdfVqgYwUhGypxEUxMQvNqYUVUsOlVZFJdP");
    bool LAgYGIJUhA = true;
    int nmmBuvvlApyvGlB = -1723008455;
    string SxxKWb = string("msexQrmorufCaYZbpgdPXVgvpksygzhRKFtoqzOUIMomfaukDeEwJqMLdNuKpGHTLKQsVJGhDgREITCIcoAoeLSVJqHYpbSftqClwHlTIpyUkbnaYtzzYOPxdYPbroCXGQO");
    bool elpSStuxC = false;
    double tJQmGKR = 139578.76372371794;
    int JsVHNisJBLRFjPsr = 1019808791;

    for (int agJGAfTQkT = 455876058; agJGAfTQkT > 0; agJGAfTQkT--) {
        LAgYGIJUhA = DtMySPoJdkAR;
        zTNBEOpPpf *= JsVHNisJBLRFjPsr;
        JsVHNisJBLRFjPsr /= JsVHNisJBLRFjPsr;
    }

    return elpSStuxC;
}

int optJOZEDvrMlWMo::lIZnW(double yjNNXEh, double NimdGkfz, double lQmLH)
{
    string yQeRZNvlERZ = string("KRREzwLaLCoPKIGPamSfQvYTeZxFXTxmnCaDkGsByikbymuJWfNTsxPEOxbNQpJwDOZjLhLsgaYGLBIWVISPptOrYPnQwnnQ");

    for (int wFPLRZCP = 219660104; wFPLRZCP > 0; wFPLRZCP--) {
        lQmLH = yjNNXEh;
        yjNNXEh *= lQmLH;
        yjNNXEh *= lQmLH;
        lQmLH -= lQmLH;
    }

    for (int TcMdrGCigznMEPN = 2140226433; TcMdrGCigznMEPN > 0; TcMdrGCigznMEPN--) {
        NimdGkfz *= yjNNXEh;
    }

    for (int ctoJoUdJZzNFVZEz = 2090279815; ctoJoUdJZzNFVZEz > 0; ctoJoUdJZzNFVZEz--) {
        NimdGkfz = lQmLH;
    }

    for (int lxTvOcoHH = 500003052; lxTvOcoHH > 0; lxTvOcoHH--) {
        NimdGkfz -= yjNNXEh;
        yjNNXEh *= lQmLH;
    }

    return 368476672;
}

int optJOZEDvrMlWMo::uAaQQbiFN(string GXHodpsprSfMCUjd, int gWuAlFXuLRlOu)
{
    bool KRvsdXjTpDYkDHa = false;
    int qkwDYBiBXvwXpFa = 1557368293;
    double ZVCqclAiukYMe = 681843.7668655486;
    double mDJAAlJxc = -913644.4466566211;
    int PuJamRgXGE = 879420945;
    bool nAjsmUeqHoangkCO = false;
    bool qfcuyAeOViZ = true;
    int APYaqIF = -231495413;
    bool YmMFAw = true;
    bool XcfLlfqy = false;

    if (qfcuyAeOViZ == false) {
        for (int VByYrYLKizzYTG = 659283232; VByYrYLKizzYTG > 0; VByYrYLKizzYTG--) {
            PuJamRgXGE /= gWuAlFXuLRlOu;
            qfcuyAeOViZ = ! nAjsmUeqHoangkCO;
            APYaqIF += PuJamRgXGE;
        }
    }

    for (int mMRVRcAW = 885935328; mMRVRcAW > 0; mMRVRcAW--) {
        gWuAlFXuLRlOu /= PuJamRgXGE;
        nAjsmUeqHoangkCO = nAjsmUeqHoangkCO;
        qfcuyAeOViZ = ! KRvsdXjTpDYkDHa;
    }

    if (YmMFAw == true) {
        for (int TUnFbkkqOhIf = 1957314034; TUnFbkkqOhIf > 0; TUnFbkkqOhIf--) {
            continue;
        }
    }

    for (int JfgTQCzWzO = 862862589; JfgTQCzWzO > 0; JfgTQCzWzO--) {
        YmMFAw = ! nAjsmUeqHoangkCO;
        YmMFAw = ! KRvsdXjTpDYkDHa;
    }

    return APYaqIF;
}

double optJOZEDvrMlWMo::PHfjCFcCtZtv(int kpRYubHQjShvdvl, bool PHQugAgjLzAkafP, string IUdcXFMKGegQdI, double WfpaPwBJGKUm, string BlPxCXKB)
{
    int ckFbElvx = -50684657;

    for (int jshueT = 679620588; jshueT > 0; jshueT--) {
        kpRYubHQjShvdvl /= kpRYubHQjShvdvl;
        BlPxCXKB += BlPxCXKB;
        BlPxCXKB = IUdcXFMKGegQdI;
    }

    return WfpaPwBJGKUm;
}

void optJOZEDvrMlWMo::xLwiMBZedcZ(bool WGEbDXg, bool VBVdhktT, string XPBZelPZ)
{
    string zzPWKYopTVwhveQ = string("FTlcMRqzlSSGQlnbQqSzXdfJuotOZhjz");
    int RqJQdtve = -405650796;
    string QMHhcyOIvJOTBge = string("BWJOPgpmzAGdJzoflXpILqzBsdnLdrJcMqpmXslhRfGSqriTSMvPigHuaCqVMMceXnRmEhjSYQqaJjtmIscpAszcDROAXEOhHMKYvpNyijkDyZRDRQffCJcQgtvBCCcOzCLamWwFebwmCKhcAbhwCXperRdsMILoKCAHvzopFrNCsnqDXYhEuMrckTfwxQigVaZLjaaTToGckaUIHvpKYbJDPQliIhVLoTcIypdwEksIYVkfrpnMgOFw");
    string VcYarXehZOk = string("HOrjJiMwmpWgXiAkPienCuWdCNNZoLPWqbtQReVwUOfErEgNhKIFLsTGzpSUJRTZRzEwajxXfnhgiBodIuyPGafENAmpIKUsvAzpqSSXYisgfCRZAjmTiVbSQEopQWPEKgzVfgVZdjnXzsftRtrxrelByEqlGwcBgMrZwutMtRpaRAp");
    int jaFpSqgMNcKhTAB = -2108412392;
    double sDeyUyASfl = 93161.90574681298;
    string jtniebYlkUsN = string("QihRNwahfouoYTKPyYYKCjltGKXubQ");
    double HmoutT = 854191.9300037399;

    if (XPBZelPZ == string("nstaWl")) {
        for (int uLjFJdcT = 1016328133; uLjFJdcT > 0; uLjFJdcT--) {
            VcYarXehZOk = QMHhcyOIvJOTBge;
        }
    }
}

void optJOZEDvrMlWMo::bhFSARyfPcdc(double XyoelyxaKP, string CTDVHfayFFMK, double kHkUHjSmRv, int nzGDMuBO)
{
    string kZGiZp = string("SOPjBGyhgxBxVTHpFsrEMcLMIDlhMinYScjagbIKIiCKHWfwlndsZJHtCoTgOgfZngoKgsWabRNXFDgcyvdjIcmSkNmdNZpeXpDNSMupVVUgkWRbimwaAXvWBgqdJFieKakRaWGRoeaSbYVjiufRcvnMqgWloLLULRfgoBDuCMkHFDFrhHSEFtzkXMReURMyzCzsoMxpZdzJCOvllYElSCbtYJVgofOFjJUJTEfjjPPoqURHqrpeYAkxmY");
    string DYrbDaDWXNMVaL = string("pAmGMTlyafhyZlYyFMqjiEjMFBoczyvmmKKJZahAPsrqeAmCidESUSOTZPNdTHyVomobZtqeyzXAKcxKvrcTZhWbPedBUzHFofhUvoRwXmitzpsjKWsjAgwrspodKSW");
    double WVcIahlCSfYjU = -336317.63398351544;
    int MzIJDwZpTOuvCni = -276184958;
    string mvbpgkXTiUJvTwCV = string("lpjGGMgNBNVWeFUxTffHGysXCxDeNpafWlpvMeNOsAsCEeDNNpdQeyCSTGHHtAFLRHUibYOBSiwbLHnoVpWPxKAWyFdTwQWgKctKTjOfvSEIQPsGsmlhuZeAOxLmoxAXfchbQLxvIPKKzGsNrSfhn");
    double bzEHhhnDsdZj = -573119.7082961419;
    double ZyjyZtIibMeP = -329771.23124260845;
    string MOMPjHyn = string("YnnnfLKfsHoeDavJHSoRakimWNDfJYiumCOhpYgfEJtgFFNOShYdvbewyHGBaAcKuayqYIHKCPWLrrfjCjbLlMVHDhMLvLtVVGvogTxPrOiOwLVLYtINUQIjahHONDFoCNNIp");
    double BcmzTgDPuJr = 131449.0437296901;
    string mRHNRtb = string("SsHPtjjKKcUVvpocpoIsganLXzKMVdPMngjQDFLmvyWtDObHkvjhKSKAkwTGxNiJQgVqJHGptJqTbSRAXPzFVvBigOHekZusvLHXZuRuzEUTKHJQhifVCQXOKQqynWdVukWWlfEsRCtJMOEzxpNRMTNrOVcByQXhCVWnhMddkwpWWEWsuzjWoroPefGkxBiLLUObbpudKdTpgJchTvQneExXSkSRVIFGaBYIrlXMLqcst");

    for (int mYkzVkWIrnk = 227563974; mYkzVkWIrnk > 0; mYkzVkWIrnk--) {
        continue;
    }

    for (int epjGBongxOLZNTp = 1122783540; epjGBongxOLZNTp > 0; epjGBongxOLZNTp--) {
        kZGiZp = DYrbDaDWXNMVaL;
        bzEHhhnDsdZj /= BcmzTgDPuJr;
        nzGDMuBO = nzGDMuBO;
    }
}

double optJOZEDvrMlWMo::YjoYLgra(bool FYKHCrEwSKZaWJRG)
{
    double wBXhmiMnOj = -545416.9060632235;
    double NyXYK = -522461.6544384664;
    int voCBSnqKpCBvglWp = 971243601;
    double fCxJrMgArgxCHM = 1027503.800575502;
    double fDocpvEMYjeek = -606262.1515977356;

    for (int eOvfFprqKNLghq = 1353693020; eOvfFprqKNLghq > 0; eOvfFprqKNLghq--) {
        fDocpvEMYjeek -= fCxJrMgArgxCHM;
        fDocpvEMYjeek *= wBXhmiMnOj;
        NyXYK *= wBXhmiMnOj;
        NyXYK -= NyXYK;
        fCxJrMgArgxCHM *= NyXYK;
    }

    for (int mdemKyUsvqZL = 274301260; mdemKyUsvqZL > 0; mdemKyUsvqZL--) {
        continue;
    }

    for (int LQGgujJJGN = 882021090; LQGgujJJGN > 0; LQGgujJJGN--) {
        fCxJrMgArgxCHM *= fDocpvEMYjeek;
    }

    for (int rvUTeigJvaMxfybI = 1595042798; rvUTeigJvaMxfybI > 0; rvUTeigJvaMxfybI--) {
        fCxJrMgArgxCHM += fDocpvEMYjeek;
    }

    return fDocpvEMYjeek;
}

optJOZEDvrMlWMo::optJOZEDvrMlWMo()
{
    this->HbRyUXJNHfpOh(true, false, -916515.3395365828);
    this->EyNWAQHUhGBuR();
    this->lAfmfjQ(1058204700, -672323546, -86460996);
    this->wTXUa(741494246, -1631322685, 446227.6053440283, false, true);
    this->QTAwbDTllfbx(string("GIpXBcFQTsIEuQHLatNlH"), false, string("alEpkrzgsyYejIlhXedXUwLkiuUQAwrSiCtkUwPTJmtbKObwdMy"), -221007353);
    this->vsowfXfOtb(true, -234595.49442358915);
    this->LBmrqf(-966456725, string("ExGfYdAxozyQAbfhlXzHoHzfdYDTFubTstodOgWbGhDKcemiwsoqayccREATyioyOlBAXvFAsszqPROrUsdzxgMqyNJVhuQYpemsDTLyBcDBEStpBaSXEJGQlVoNeJfFkrbnHJuGtyDfPYWMnXxPIVEMeIvPUtbNjyCToMXzqssAOMaTPOUfwjRaOSiNKcgCcZZdrINTrIztsP"), -255670.3105232456);
    this->zjUjlgazPd(true, 88104931, 1568569072, true, -443295871);
    this->lIZnW(402243.336263546, -828955.5133835546, -592887.1565939868);
    this->uAaQQbiFN(string("RzXZnsAkVkCTBI"), 1455847176);
    this->PHfjCFcCtZtv(643280625, false, string("AtUfWVCWcObkUYbigewpOTkJkEPhnoPREWPFLbrKkEsdKxLRQtRqcVVzrJLwRVPnOOzwHhCchBSgSopSfhvEqnxi"), -916783.1838611447, string("AHxftQFkWGokIVhBApCCVhZhExxvxKcvcYXiOxw"));
    this->xLwiMBZedcZ(false, true, string("nstaWl"));
    this->bhFSARyfPcdc(-691417.9287402102, string("iyTZZUgnNsMvSLNqteRDkYDNBBkUWtVNfrkDeFVdqDEgIocWlgaiivyzGgIrspRrOPJVUpWLXEvrKTWVUOgLxEsSmSORsPspsnmyujftRVRxXVUdnQUgdWpUisRcauLIdfjCACJwqEjrNiLpwiGKLrY"), 641048.5481664536, 1455461279);
    this->YjoYLgra(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IRGTz
{
public:
    int SqHNi;
    int kTBDxsgsZZmsZYF;
    double lLWGwzIQPJTNfSV;
    double OloXNPyjngJSWPXh;
    int MtueTyzjQtfC;
    bool QalrFx;

    IRGTz();
protected:
    bool UmnMQVVNmslv;

    string nKLCNPHtiUFPv(double vJnWmBwpqZ, bool nCImaC, int gymYELvnkAgXZk, int FOulIzeCKXHGkt);
    void IdcSoQ(double zAYCBIR, double BfKzJkorJ, bool WhOry);
    double eUroBrlb(bool RjvzqYws, string vAEcvZGxgAk, bool JqNYzum, double GeKjpSIpWewjSS);
    bool jwWnfl(bool zjYRnIQb, string btKPjO);
private:
    bool iSKwmILsNLOKV;
    int wqHbCLXudZpNgmpW;
    int cRRRwwzEZe;

    string mKSsAPXXnsHc(bool tKdCWjanHyUfM, int XmeJsHlGRaLlAXzB, string yeFQkNSwnvxZYd, bool gtpjsf);
    bool RlewrUsauJhsuYA();
    void kqrTNavMgcGXKlIR(bool csaZOCazuefACXr, double PiFjoFocgNQ, bool uYGYhwnjx, string fnmZvxeGxcElBAfO);
    string mPFXutjZvrJj(string VCmKtQjX, bool Nodyh, double nRTaUZOIdEfH, int zCOIldjlFG, int wJrVkmGCrlUZdS);
    void GDSOE(double GLvsMd);
};

string IRGTz::nKLCNPHtiUFPv(double vJnWmBwpqZ, bool nCImaC, int gymYELvnkAgXZk, int FOulIzeCKXHGkt)
{
    double kfnufsVtutOV = 68825.60759268978;
    string GinTW = string("IyTXildAqgzwjihOOXnedjgtuSGgGzhXUXrDAwSXWXyXHnxToYnwOxcZMxcQGmhltLCkDJyZbrOzEGYcEkLZxpeLdUqKPVIwuRrgefsKuOxyfWHnAyzKsDOuKfKWyqMvxnTXwVPNpcFVQGNlNwkJWPqzFPODljwtrwySvuxHNqWGSEKYPyxYohqrAMjf");
    int CoxwcbD = -1321177292;
    string AQwZpLsYPLgfy = string("GBTfYYzxABDQcFZYNifBUknxVipubmfyntPNFpOkntmWNGiegqBBIYImKRHnrAFBHyXbCnaxHOhUjYFYOJWAiBpQFRLxdAjQvHauDrgChQDQoXWcPMaAUsnnFGBtwxixVoltHZBMwBHjhWQFDnIzXdorkmWBCZiTrDrYUNuSNQCzjaF");
    string BvPMZpKCodKNTa = string("xCdqnRhXrrPtMqqvJmdCTKcXXwsHrUsFOCLndltOyqjPrnMUWPjJxKcJmmRsAbjSpIZZEkAratKJaEQvyjGFAkJoXiXqbTfoBlzWvJWlkzdPrJZQdZRmbRytpVPsGXeWpvijvbfLRBPXvBmBqaJtxSnhtybyRgBxuQDRfyPgYvALGJtZPtWOsgQWSnJaIxEXSDoJGwKBDZyJUxvqYHZqVGxJbdpjxPbmrcysCVatsECsC");
    string RUcPZhvKM = string("MHsxwdPrDwscFnfDoyznodeaGrJYZuiDrBzZwuoSKjKraYZyNthLKWEazaTNwCRatTFyFAdDGZkirLaERArAYjLMyxGkoobqdZuBZhFmWUFoPpLjxFcDKcgwsiipUSZyIPFqHWXNvdUgTQUXGDetRmlMVTRIBrkolpdjzOsCzxiySTvyUCrikIuiiXQMzkWTPspmcSHcwpE");
    bool fOEbWHIBsVz = false;
    bool WjhKfSCq = true;

    return RUcPZhvKM;
}

void IRGTz::IdcSoQ(double zAYCBIR, double BfKzJkorJ, bool WhOry)
{
    string XPSPIq = string("nyglcQYuQrzmZEDeqYhKCGCzEkZHWTkBhECwHfQvDVnMazUgZDTMhSbWxeFYlcVGLYXhWzRNcwBp");
    double pFuGvNPVwuQTiVY = 840567.2302829734;
    int qJAvSELmtRGzwk = -1617077797;

    for (int uuYwckQHIYlVWjTc = 10888323; uuYwckQHIYlVWjTc > 0; uuYwckQHIYlVWjTc--) {
        continue;
    }

    for (int pqbixMEWjRp = 852523950; pqbixMEWjRp > 0; pqbixMEWjRp--) {
        zAYCBIR -= pFuGvNPVwuQTiVY;
        XPSPIq += XPSPIq;
        BfKzJkorJ /= BfKzJkorJ;
        WhOry = ! WhOry;
    }

    for (int KiBUmS = 1045000276; KiBUmS > 0; KiBUmS--) {
        zAYCBIR = BfKzJkorJ;
        pFuGvNPVwuQTiVY *= BfKzJkorJ;
    }
}

double IRGTz::eUroBrlb(bool RjvzqYws, string vAEcvZGxgAk, bool JqNYzum, double GeKjpSIpWewjSS)
{
    double jIKaV = -204567.1592474647;

    for (int tmiJucNZHZMpe = 694121563; tmiJucNZHZMpe > 0; tmiJucNZHZMpe--) {
        RjvzqYws = ! RjvzqYws;
    }

    for (int rfHkYKTpc = 213023082; rfHkYKTpc > 0; rfHkYKTpc--) {
        RjvzqYws = RjvzqYws;
        JqNYzum = ! RjvzqYws;
    }

    return jIKaV;
}

bool IRGTz::jwWnfl(bool zjYRnIQb, string btKPjO)
{
    double KyUnSA = 976895.5509894784;
    bool QdocRaPTdG = true;

    if (zjYRnIQb != true) {
        for (int rAWuaUIuXriKjDO = 1100402256; rAWuaUIuXriKjDO > 0; rAWuaUIuXriKjDO--) {
            zjYRnIQb = ! QdocRaPTdG;
            zjYRnIQb = ! zjYRnIQb;
            btKPjO += btKPjO;
            KyUnSA = KyUnSA;
        }
    }

    for (int reMUDByse = 1557295332; reMUDByse > 0; reMUDByse--) {
        zjYRnIQb = ! zjYRnIQb;
    }

    if (QdocRaPTdG == true) {
        for (int yPQKu = 1516960166; yPQKu > 0; yPQKu--) {
            continue;
        }
    }

    return QdocRaPTdG;
}

string IRGTz::mKSsAPXXnsHc(bool tKdCWjanHyUfM, int XmeJsHlGRaLlAXzB, string yeFQkNSwnvxZYd, bool gtpjsf)
{
    int GqhVjAJ = 1632743949;
    double NPgmTZ = 411800.79308016703;
    int knjqZkhnNpoHpAVZ = -397266277;

    if (knjqZkhnNpoHpAVZ <= 1632743949) {
        for (int KpRRuwZT = 1859640529; KpRRuwZT > 0; KpRRuwZT--) {
            yeFQkNSwnvxZYd += yeFQkNSwnvxZYd;
        }
    }

    for (int fVwhzdvTitEn = 1654861590; fVwhzdvTitEn > 0; fVwhzdvTitEn--) {
        gtpjsf = ! tKdCWjanHyUfM;
        tKdCWjanHyUfM = gtpjsf;
    }

    if (knjqZkhnNpoHpAVZ >= 422201445) {
        for (int CBtiI = 1687330626; CBtiI > 0; CBtiI--) {
            GqhVjAJ -= XmeJsHlGRaLlAXzB;
            knjqZkhnNpoHpAVZ = XmeJsHlGRaLlAXzB;
            gtpjsf = tKdCWjanHyUfM;
        }
    }

    return yeFQkNSwnvxZYd;
}

bool IRGTz::RlewrUsauJhsuYA()
{
    string XSHCMoUk = string("inTAmHwoveOpieRcBwjqRoUXcrbJSeQQgNfVrCLasWzbrlQSZPxUsUbbHutiKMBUOMtfodIJphUvsMJOjrJZqBrRMkmexwPwxhtYPgUQjPqJuOkAQNwcjhTchmcgzNnKCUIdNdzCAnbhoaXCheRAuYolHhcRKGqf");
    double zbOlxVNTOVKyNZ = -210501.9368026732;
    int YqoddqoJWRbj = -1251630143;
    double YbebLC = -1031449.9649595316;
    string ASOTvmZ = string("erXyhPsHZfLpkNiiSBijUeJPwsGbVODRyHcrivAXFalZMJEQcjhelskADeaAIpkClWowAdclprHbkCtPGGdqSAziYqvNinNqkTtfFsbgyhegEVDhUJdzusFIkJbxhhlYAPuAJFFZIZzmBuJMNibfzdVBaQumBOMSJQgkpsFtiVXXGUeYSXcghNABeQmVCHesjIWWQZULJRSvQjYAuqlpXgPagmZuZoasdtJLJgajMVRMIvpQMQxEKRpS");
    string nWNPjIewRfLynOu = string("QePMUAZncDcdqmIxWDaktfwivvRqdIkgaqQRJDGVhh");
    int LfcwkKlqmfgltu = -222724493;
    bool nVjbIFKrKsti = true;

    for (int LdkSnDSQMMCfi = 654033423; LdkSnDSQMMCfi > 0; LdkSnDSQMMCfi--) {
        ASOTvmZ = XSHCMoUk;
    }

    for (int jtbNhGFMXUzACP = 570809589; jtbNhGFMXUzACP > 0; jtbNhGFMXUzACP--) {
        zbOlxVNTOVKyNZ -= YbebLC;
        zbOlxVNTOVKyNZ *= YbebLC;
    }

    return nVjbIFKrKsti;
}

void IRGTz::kqrTNavMgcGXKlIR(bool csaZOCazuefACXr, double PiFjoFocgNQ, bool uYGYhwnjx, string fnmZvxeGxcElBAfO)
{
    string mllGQOzRGozjRFbB = string("ShAtfiGeWUjOQXdOjDzAm");
    double NaJKIffgHzIyNru = -291967.6424487329;
    bool fMjio = true;
}

string IRGTz::mPFXutjZvrJj(string VCmKtQjX, bool Nodyh, double nRTaUZOIdEfH, int zCOIldjlFG, int wJrVkmGCrlUZdS)
{
    bool eQVjJKXDr = true;
    string fagOkqnoQ = string("HHjDYHwpMnrHvoLomZCxfnHHiBTKflHkqPkLXAOWXfeLAbxAFBCNEtxRCIKdJcpLvbXRRbwaeofhioSHUVEvLQeIwVVONlLNsfmEkgMwHIbOvlVSKUNXoJCVRWwBkgtLSDdyKfjqukGRCBWHXNqWkzlQZOXrpyjinFbEDK");
    double jIYVA = -194297.53470922582;
    int waKKoapWnrLyd = 1199718208;
    bool hVrAkmmQnIyK = false;
    string UgPcdLsfzUJnYz = string("aOZjknMKyqIKegrDQXUfGVaUlUNMTXYUxxSjiDvMeYnuDdEjfYbNJzrrIHrxzghHuPXIzxwvteiEkzyhVeWfAIOZrJnyLOoTNbqaXuAHiZiYEiNKm");
    bool WcHOpL = true;
    string iowiTNLaupxFW = string("AACSLkxqtAuyKXabnJzPYnXEs");

    for (int VTLnOrBB = 1994474158; VTLnOrBB > 0; VTLnOrBB--) {
        wJrVkmGCrlUZdS += zCOIldjlFG;
        Nodyh = ! eQVjJKXDr;
    }

    for (int szvKDRgVXEX = 1109473923; szvKDRgVXEX > 0; szvKDRgVXEX--) {
        WcHOpL = ! WcHOpL;
        UgPcdLsfzUJnYz += UgPcdLsfzUJnYz;
        zCOIldjlFG /= waKKoapWnrLyd;
    }

    for (int WygfjqGJ = 1882436988; WygfjqGJ > 0; WygfjqGJ--) {
        VCmKtQjX = fagOkqnoQ;
        hVrAkmmQnIyK = ! eQVjJKXDr;
    }

    for (int obgoIbHyDsnhj = 1942916722; obgoIbHyDsnhj > 0; obgoIbHyDsnhj--) {
        wJrVkmGCrlUZdS = waKKoapWnrLyd;
        hVrAkmmQnIyK = eQVjJKXDr;
    }

    return iowiTNLaupxFW;
}

void IRGTz::GDSOE(double GLvsMd)
{
    string wAlcjbJWdFXxyjuc = string("JhNjGbQrXPvMVXOEgWsO");
    string XeqoGFlXfSGTyJt = string("okAOkYgKCSlpWJaymMQTAmlMrviNspiNSggKhgBbtWrpMsWRCunlDzUxSGuKbmsqSGWMOxBwfhZAEgvyDMdwcUxShAonjCVANUUpfEYBpQDWZylJklqvLNiycqIFzdPBFoxGXciELBnURmOeikCyhQzvLfUeinJuWfomYkurOaBTAwoLCNyhGQZqLLdLMhuRplXLkbYFngcLEPOkGcbtbxGp");
    bool jjDRXERlEFFCrQ = false;
    bool TCGXFSTQEoS = false;
    double jaWTfy = -223911.92216046868;
    bool sWdZp = true;

    if (TCGXFSTQEoS == false) {
        for (int JXWQKfgqEu = 1068501147; JXWQKfgqEu > 0; JXWQKfgqEu--) {
            sWdZp = sWdZp;
            XeqoGFlXfSGTyJt = XeqoGFlXfSGTyJt;
            jjDRXERlEFFCrQ = ! TCGXFSTQEoS;
            jaWTfy -= jaWTfy;
        }
    }

    for (int IDSxckReq = 1488713473; IDSxckReq > 0; IDSxckReq--) {
        wAlcjbJWdFXxyjuc = wAlcjbJWdFXxyjuc;
    }

    if (sWdZp == false) {
        for (int dPAMdioc = 1728977655; dPAMdioc > 0; dPAMdioc--) {
            jjDRXERlEFFCrQ = ! TCGXFSTQEoS;
            TCGXFSTQEoS = jjDRXERlEFFCrQ;
        }
    }
}

IRGTz::IRGTz()
{
    this->nKLCNPHtiUFPv(-645564.7824084957, false, -1130414185, -682994269);
    this->IdcSoQ(-899739.2932138483, -132546.53923367758, false);
    this->eUroBrlb(false, string("kxRWjZXBaJnYqnfKuunfOBWHHNVDxpoQLcohtVqyLTAngzCYsNdqqznXHwmNVTQnvpLevDnWbuitKIdmBUdmWMapxvnusRLGUhdDqyvWPJxAZYAgOGLErnBWrBinFPZsZViYgXCGvMbgBadbYYrXPsCSHDUWHsfwdSHdbHBNuZhqTOFlxwkUhSDFhNFOlYcIWRdjuroBeoHNvsjzofJgDGVBNhKUIbHVkwGEOZFnLCzOTiah"), true, -524397.2837984796);
    this->jwWnfl(true, string("SDdOasSMcvTIJkbdpfoDDgQsmTzsQXwndTCPjPZskVOHJvKWodNpMaAYGYEyZZdAqAzJkGyjQqkXPpATibtddAxxnwXgPhREzwfJIgokEiZcxsBQKbWxtHFUqwjtdZSZItsqpObkesZkYnRRbMgkMhrkhVzRzAKbwhofuePPPuhFbEBnxgCwoscrOrkzOumXcBgTBAFjFGgIwysZQqZ"));
    this->mKSsAPXXnsHc(false, 422201445, string("wANDjiKIUgYyJGHXSzwnzrMbJVNHHx"), false);
    this->RlewrUsauJhsuYA();
    this->kqrTNavMgcGXKlIR(false, 595945.1146714177, false, string("SuCFbXZOhZppSzUGgZKAbYvqyFTWLWJWLrYchYwJOxiQpcn"));
    this->mPFXutjZvrJj(string("rzkCUdmsBaVAwppfGhvUUdvzKxaxCFQrOrKhRFOqVYdQjuQHWTwZlUnlequXCIuFLqMKqUaApeDZNdvWxXDnrDruVkwssAnkAtriwpGYYoJbXuQtaFSHwQdn"), false, 527842.8797212138, -1607360771, -1871140328);
    this->GDSOE(-717377.6925016848);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WnmjsYhxQLRydP
{
public:
    int ovfjDwCHq;
    double GzfwjC;

    WnmjsYhxQLRydP();
    double vkkbvWUavlDkGgID(string bbXtOv, bool xEcXKtug);
    double ABnWk(string EaqFTDhRksysYWRN, double RowKckwOpH, int jHvtdz);
    string kzjINvrspPDWiT(int RpVrvDekkswyx, string DiKqWTdRrPShfm, bool UYMEtOD, double QAWZKmtE, bool LuysVced);
    string uBwduPcnilOEcjzW(int GNPzJZC);
protected:
    double CnNtgSmU;
    double wvOOYER;
    double WYludwbA;
    int nudlNBDdyhlatTKg;
    int XeWNwqZwWjB;

private:
    string aSnlbaWEPuiFA;
    bool dkjzcOpnefeQHcQZ;
    string loOGPIFL;
    int iINUXLguTHdXHyx;

    double vkdfjJMWhzCHTQh(string qXTMbl);
    string BNLCq(int eNuNxpYVevdgDcYu, string YOwDevrQJfwrtOhp, string fLpfBQURHjTEDQ);
    int OxXysrOQzMbgt(double MSSPgbN, int EfUVXXEfUzWqTw, double UhNckRO, double zssgvL);
    double oqVelT(string sFLXekgztQGaOtcD);
    bool EDDGJCMFyQy(int WVdzMwBRKmkPZ, int HaLZKnLsd, int xIloHedcRk, double MfDIoBIHJLNuPOKj, string CrxgEFXHGonCNz);
};

double WnmjsYhxQLRydP::vkkbvWUavlDkGgID(string bbXtOv, bool xEcXKtug)
{
    int qJZJLCf = -348578420;
    bool AHsvGSKMPGCAtjf = false;
    int ffPDCrnkBDmgC = -596514757;
    int oKTATVGVznRnbMqM = -204167437;

    return -110545.89537388056;
}

double WnmjsYhxQLRydP::ABnWk(string EaqFTDhRksysYWRN, double RowKckwOpH, int jHvtdz)
{
    string SMVNDCfzOuxmyDb = string("UaPhILOYCRFQpXQiHWIZfaTVqKCcdmuluxaexFaqRcksRwBTevuZaHaIfqBqOiWmDqeroxYtZWzMRXSjbjZEBkjoCRezmvFHbEeJXeKcraEvRRGRikgMRHKGkqjMIVtEYUgdPiWSCOlXYyDrwQqMTQwnhLnmVvZbdsXFRynsiDcuwuA");
    int HpjiKkiEB = -1015410157;
    int juPiNSdccUNe = -1942542737;

    if (EaqFTDhRksysYWRN > string("UaPhILOYCRFQpXQiHWIZfaTVqKCcdmuluxaexFaqRcksRwBTevuZaHaIfqBqOiWmDqeroxYtZWzMRXSjbjZEBkjoCRezmvFHbEeJXeKcraEvRRGRikgMRHKGkqjMIVtEYUgdPiWSCOlXYyDrwQqMTQwnhLnmVvZbdsXFRynsiDcuwuA")) {
        for (int RJZDH = 683494729; RJZDH > 0; RJZDH--) {
            RowKckwOpH *= RowKckwOpH;
        }
    }

    if (HpjiKkiEB >= -1015410157) {
        for (int BynLZWrGOXZwN = 721197455; BynLZWrGOXZwN > 0; BynLZWrGOXZwN--) {
            HpjiKkiEB -= HpjiKkiEB;
        }
    }

    if (jHvtdz != 1434605942) {
        for (int kirXFTdrNLS = 1046103265; kirXFTdrNLS > 0; kirXFTdrNLS--) {
            jHvtdz += jHvtdz;
        }
    }

    for (int sgQxEEbI = 1689151038; sgQxEEbI > 0; sgQxEEbI--) {
        jHvtdz *= jHvtdz;
        EaqFTDhRksysYWRN += EaqFTDhRksysYWRN;
    }

    for (int idmFDilD = 2060196330; idmFDilD > 0; idmFDilD--) {
        EaqFTDhRksysYWRN = SMVNDCfzOuxmyDb;
        HpjiKkiEB = jHvtdz;
        EaqFTDhRksysYWRN += EaqFTDhRksysYWRN;
        HpjiKkiEB -= jHvtdz;
        juPiNSdccUNe /= jHvtdz;
    }

    if (HpjiKkiEB <= -1015410157) {
        for (int OnXWGgcTh = 1942227714; OnXWGgcTh > 0; OnXWGgcTh--) {
            jHvtdz *= juPiNSdccUNe;
            jHvtdz *= juPiNSdccUNe;
        }
    }

    return RowKckwOpH;
}

string WnmjsYhxQLRydP::kzjINvrspPDWiT(int RpVrvDekkswyx, string DiKqWTdRrPShfm, bool UYMEtOD, double QAWZKmtE, bool LuysVced)
{
    double vEWKUlO = 88279.54154888276;

    if (LuysVced != true) {
        for (int bgbtTxlwTGHLk = 828363515; bgbtTxlwTGHLk > 0; bgbtTxlwTGHLk--) {
            LuysVced = LuysVced;
        }
    }

    for (int oExPnQJxPX = 1275525597; oExPnQJxPX > 0; oExPnQJxPX--) {
        continue;
    }

    if (QAWZKmtE >= 696412.2064756519) {
        for (int zFLvJQIjDYarqk = 726669705; zFLvJQIjDYarqk > 0; zFLvJQIjDYarqk--) {
            DiKqWTdRrPShfm = DiKqWTdRrPShfm;
        }
    }

    return DiKqWTdRrPShfm;
}

string WnmjsYhxQLRydP::uBwduPcnilOEcjzW(int GNPzJZC)
{
    double azSUD = -884453.2557724781;
    string GXUKKwJbIS = string("cqPctuEJjyqAsZDwmWeLmIUhrTAZswtcMkgMSebyQsNhFsmkRXSUSUPLOXRlgvFLcxxrlOxNqLIKKnEZEupvXRDXYMuOHxMNItIFbLXdnOtWgLkmZzSmtgthTRTyAdhNvHaQuYjZvyJGavTFSSHNErWFokLWajschcVvpVIQaVszB");
    string utwswNJPo = string("ADodnjlCqxvpxvmzLzAueXsADdSrJBCDqTbZhLPHu");

    if (utwswNJPo <= string("cqPctuEJjyqAsZDwmWeLmIUhrTAZswtcMkgMSebyQsNhFsmkRXSUSUPLOXRlgvFLcxxrlOxNqLIKKnEZEupvXRDXYMuOHxMNItIFbLXdnOtWgLkmZzSmtgthTRTyAdhNvHaQuYjZvyJGavTFSSHNErWFokLWajschcVvpVIQaVszB")) {
        for (int lSPHqfzWjYwTTZ = 873848981; lSPHqfzWjYwTTZ > 0; lSPHqfzWjYwTTZ--) {
            GXUKKwJbIS = utwswNJPo;
            utwswNJPo += GXUKKwJbIS;
            GXUKKwJbIS += utwswNJPo;
        }
    }

    return utwswNJPo;
}

double WnmjsYhxQLRydP::vkdfjJMWhzCHTQh(string qXTMbl)
{
    string oPrymybqzYlAKvU = string("PAWZCamkYMYlHmQFziTcEoOIFWdghpqTzuvotjqbFjRzzeGBGmXUKEkAAqeTZHXzCKytjtZkCQkWSdXTwXnHsMeXldsCERSNaCkoznnFPVQwNABPtgLMwDYfwMgQNtmfOgpvelOowqPpNlgVDImFGfkBbeGIXCeOtXjlxgALiFrylJbriIwjPcQmAkVfkKH");
    bool QFFQanqWkGv = true;
    bool NaBCmMfboEFgqPm = true;
    int UOtsBRufplwnf = 619139331;
    string bKnmWdSSNR = string("jciggJGTZQiYUbsVaqRRJvpBdJbzlnPyxyePATDtbuPJfMAXcugtGOTXbxjAREHaTqSUkyPjqospeeFrhcZNXxoEcJAJTXaGxkZmywwmeqHJOolzHUMFmIuPwXYqMWboTEmgHIvFFRWQJCOUkeyzERCGbswFgOJBICPKkLfvlRZeZqsWBzxBGaVDULeaRvfpWMBsZuptW");
    string JlCZxjUhXvgXVz = string("DvzRqFLxKXwDdYmFqEAgDgNJZpkWkpMQeHaPREPVOaAauAgByJYwLTcmkhubpOhmBJoquvtzldvGlWXEGINIaEUmoaoPitgsgysJQRBglFRzMkMxiBBoAPKJH");
    int sXvWUXBc = -337877922;
    int cvJyWmWypjwHmxz = 1915456775;
    double EULiZ = -817444.7410244443;

    for (int crqODExeVgNLHjdF = 1708167446; crqODExeVgNLHjdF > 0; crqODExeVgNLHjdF--) {
        oPrymybqzYlAKvU += oPrymybqzYlAKvU;
    }

    return EULiZ;
}

string WnmjsYhxQLRydP::BNLCq(int eNuNxpYVevdgDcYu, string YOwDevrQJfwrtOhp, string fLpfBQURHjTEDQ)
{
    bool CDgmv = false;
    bool FqsvHslAEHjmW = false;
    bool aIxjHHpIh = true;
    double eYucQBlqVGHf = -769588.6728356046;
    bool ekIegMkiQ = false;
    bool LpzvuEZrBlwqhT = true;

    return fLpfBQURHjTEDQ;
}

int WnmjsYhxQLRydP::OxXysrOQzMbgt(double MSSPgbN, int EfUVXXEfUzWqTw, double UhNckRO, double zssgvL)
{
    int ipUoTgOCGrnVwaq = 1086119028;
    double RvTddWdrGLL = -617722.2084446164;
    double RBgSmhXtnsZZ = 413236.77204779745;
    int tHvIo = -1311492835;
    bool GCZpYnEuVeIv = false;

    if (MSSPgbN > 413236.77204779745) {
        for (int UjnWOpiqxgpChn = 598637844; UjnWOpiqxgpChn > 0; UjnWOpiqxgpChn--) {
            MSSPgbN += zssgvL;
        }
    }

    if (EfUVXXEfUzWqTw > 90143058) {
        for (int cqFxwQqJUja = 396247390; cqFxwQqJUja > 0; cqFxwQqJUja--) {
            UhNckRO += RvTddWdrGLL;
            zssgvL *= RBgSmhXtnsZZ;
            ipUoTgOCGrnVwaq = EfUVXXEfUzWqTw;
            RvTddWdrGLL /= MSSPgbN;
        }
    }

    for (int upyEhsTc = 1531977922; upyEhsTc > 0; upyEhsTc--) {
        zssgvL = UhNckRO;
    }

    for (int TJKuuquXBxrBCueI = 324853112; TJKuuquXBxrBCueI > 0; TJKuuquXBxrBCueI--) {
        EfUVXXEfUzWqTw += EfUVXXEfUzWqTw;
    }

    return tHvIo;
}

double WnmjsYhxQLRydP::oqVelT(string sFLXekgztQGaOtcD)
{
    string hxPcuFfLWkqbF = string("dZKWIZxdhPnnrawozhcjQVRKyEIRMqJVVzGhgciTKdGJRfRFlcL");
    bool BqXWHLIdAiAZVV = true;
    string QMIqoqMZ = string("cFRQSUVDcLDWmbVALjYzTRcLYFVOJia");
    double fvSoQiOhdfJiie = 890705.3717622306;
    string oLABfiYjfAjHKq = string("PhtYAGgbBtxeIhapPoSRqrcMFrKwnDNHZWEfUNHjYEOaTQHsDayQVbnXBVMQoLGAnJBTYvALYMySoxBxPZvxBdJMXEBLFNaGlADPSqDqRNRvDdVIdybUcsowPMAZeyzKkauNniaWUPybCuAlmmmcPTvMaZbwUdYuHtuG");

    for (int zfhGIv = 1668780637; zfhGIv > 0; zfhGIv--) {
        hxPcuFfLWkqbF = hxPcuFfLWkqbF;
        oLABfiYjfAjHKq = oLABfiYjfAjHKq;
        QMIqoqMZ = hxPcuFfLWkqbF;
    }

    if (hxPcuFfLWkqbF < string("dZKWIZxdhPnnrawozhcjQVRKyEIRMqJVVzGhgciTKdGJRfRFlcL")) {
        for (int dpSzyac = 319255948; dpSzyac > 0; dpSzyac--) {
            sFLXekgztQGaOtcD = sFLXekgztQGaOtcD;
            oLABfiYjfAjHKq = hxPcuFfLWkqbF;
        }
    }

    return fvSoQiOhdfJiie;
}

bool WnmjsYhxQLRydP::EDDGJCMFyQy(int WVdzMwBRKmkPZ, int HaLZKnLsd, int xIloHedcRk, double MfDIoBIHJLNuPOKj, string CrxgEFXHGonCNz)
{
    string kWcdIBnsMeCGGV = string("ysrzinNZLGAtPjLGLcyqnDATkY");
    bool cMLAETNsdAzqL = true;

    if (xIloHedcRk == -949117507) {
        for (int eOOqcHNhQcHYq = 812482899; eOOqcHNhQcHYq > 0; eOOqcHNhQcHYq--) {
            HaLZKnLsd /= HaLZKnLsd;
            xIloHedcRk /= xIloHedcRk;
        }
    }

    for (int ybrKizA = 1040713133; ybrKizA > 0; ybrKizA--) {
        xIloHedcRk *= HaLZKnLsd;
        xIloHedcRk /= xIloHedcRk;
    }

    for (int ZXmLPEyPKVWJPJAs = 851753098; ZXmLPEyPKVWJPJAs > 0; ZXmLPEyPKVWJPJAs--) {
        HaLZKnLsd -= WVdzMwBRKmkPZ;
        xIloHedcRk = WVdzMwBRKmkPZ;
    }

    if (HaLZKnLsd != 1913123883) {
        for (int xXaLVMX = 573852479; xXaLVMX > 0; xXaLVMX--) {
            kWcdIBnsMeCGGV = CrxgEFXHGonCNz;
        }
    }

    if (xIloHedcRk > 1913123883) {
        for (int VGMXRXwvMDeWQ = 1580809739; VGMXRXwvMDeWQ > 0; VGMXRXwvMDeWQ--) {
            continue;
        }
    }

    return cMLAETNsdAzqL;
}

WnmjsYhxQLRydP::WnmjsYhxQLRydP()
{
    this->vkkbvWUavlDkGgID(string("WGWluvDvydABiaBTzOrTklxLvMvFXXpJrJaTgjuJpPUGhroiMWrsdoPJlJxBaLqQwC"), true);
    this->ABnWk(string("sbSZNkXgCqtnrthAAEXXvNAPNjpUQedCYaNMsuBnJPfYfdTUzvhAkpAFjtxOjDexJKufClUzYLxgcJ"), -417250.1005038043, 1434605942);
    this->kzjINvrspPDWiT(786587484, string("NUyZEscjmrvcWCXYVNore"), true, 696412.2064756519, true);
    this->uBwduPcnilOEcjzW(793868448);
    this->vkdfjJMWhzCHTQh(string("fxOHiPamSCufnZseRvjKqtmhwYGZTkRwumXLWLbXwMVtIFcfhYiRFfKJzovemkjRhaNUmVAXKVmafPKyZkLsjUJxvVPxTMBBOXReXwkgZCXbeKYnGJMMjqHHMzVJhhkzOHxfvrDNysVVgpmdRLbdyoyuxNSJRJud"));
    this->BNLCq(1761332196, string("ZjGQBKvjyzIBSGWHddpYrxxelNYSEpQKmDUEAhxfqgSfZUfqmRmNhUxkJMKzbIvMpSLXss"), string("WsiJsEaqgWgNUTNVngGGmWcvQPEmDelNZVICujJWqJeGrsdicVlUYdTEGAaXdrJEiCCUnPypCLYDgUrVuOJzWxqREiIOFxjBNLbIfphedkwFtIsCSajMvHSUBXKyirARcNYNcVmNTBDGJYriuyCGU"));
    this->OxXysrOQzMbgt(976554.1331614845, 90143058, -828447.0193091019, 359079.22003717296);
    this->oqVelT(string("KzWmbVKjhGFFvmWZocHtRBWjHbIVzcWpUobKazrgxSIrCguWDLAzEjctcRLsxOHfDVWeonmuQgMihSnQMNvEVtCIAwnJGRcarFQhGjAWWTkjaCRYSUvviMLkzUEZXEJjYhyGOMkSmVSiCIkQdGqdpvxrGjWCoSieEzaYQTSYurRiEzsfFqDXAarFDWmrMqMAVLlhqijmEqsnmffwGkRKvcVagQhBfjfKPkiUvaRjjxgwBkJyDggiTpeN"));
    this->EDDGJCMFyQy(-578011029, 1913123883, -949117507, 825058.4446062706, string("gtkBPmOkFCmWhmxcdxtcrkppuuaCtgwDDf"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GztcSlQPOEEizYiN
{
public:
    bool CkTTnOqc;
    string WLdytJSex;

    GztcSlQPOEEizYiN();
    double WFroTLN(double MKmKfdVkTLu, double IAhGtf, string LltLpisUrBUAKpp);
    bool CSQtXrr(bool itQDYxl, int WJmCEixYLBIjTpLv, bool dsOqdCCiYJr, bool BquPwEpWatSK, bool SPboYmGuacKM);
    string towSIJZtPgmWVxDN(double fusJC, int JvImooPxtuoiYLC);
    int UnYvdsrkyFYp(double EWQXhixnNemSbqEY, double ldRVe);
    double tzAzVMvAdoFg(bool LbEYVoPHTEZ);
    bool yHNbirJiNJgZg(bool ltTBaqO, string wiEjUhCHkZq, int KqneAOgU, string qUflAZTUxGiMmlG, string AzNBAxeGBDSH);
    double VwNNvYNKzQTw(int MkFiKB);
    double zNosLgFP(bool CqlzLNyWQJRWMCnq, string LBXsLh);
protected:
    string DIBmruTEYB;
    string VcigxmaoKZUbEYil;
    double gINXCeYvBfcyg;
    bool grsIRTQ;

private:
    double KBzQktn;
    bool uSYaWrliQ;
    string AmhTwdQAPtMyfCX;
    double RXnCZRCTVVRSiP;

    bool PAhVFRhAy(double HFOrUEisMwbsxzAw, int MOTCQyEVpy, double QlPAu);
    void eZOnAFI(bool cizNpyZrwGxe, string hbXBUshBJmd, string utIpZjTAJdgb, bool uuGzDUFUv, int OoRRv);
    int WKEgGwQjtQlAtY(double eQXpqisN);
    double OdTjqzM(double nUEDEkELi, double tQwYlnrGctGFedK, double LOyVwHBG, double aYTbYDeqZXtf);
};

double GztcSlQPOEEizYiN::WFroTLN(double MKmKfdVkTLu, double IAhGtf, string LltLpisUrBUAKpp)
{
    int yVanmXbKw = -49839782;
    double XndYIQxrI = 42907.3587782748;
    string YbQXFfd = string("PmxLpQDQEbYYoulyUgWGtVlzlClZyLCNkNLLlYyhBMCxjGmzfvHyMgxVywuqFoTnwVpceodqHMpaZanhMVSEyRCAcehnJavPFzmyFlcAyCeQggTfsWKofbKxsGGUdzCOhxYQdKEFFKWMeecYFGUPclThFhKnCDkAXgQbMVDXRVByvP");
    double cIChUzABQygD = 778453.1971039529;
    int lrGJarPGr = 1865985911;
    bool SJNjQgXuWRPSJ = false;
    bool WjeJWdnIeuyYN = false;
    bool HzGpHybwx = false;
    string fXIqTaqRZBkDXG = string("rzDfcqAZAZyiKQWxpfzBOKNONksakSMtbuJohfsoLWUIkhtsnlXSkhclMYPXvPtyJhCsydZxhmCwNrxquHjrSsXkpdHaYFCpwxKLFNYFjiMySJplByleEbWtBYPHGsQQNwEnyRVpKnhwwSuoxjAOOkKOXTQVQPQUcxxZRzKzwXUDCtYyXJxIgYOunDcvKCYXzZlRcvyAFL");

    for (int RhOIKjwCgGVHZ = 1819241031; RhOIKjwCgGVHZ > 0; RhOIKjwCgGVHZ--) {
        XndYIQxrI += cIChUzABQygD;
    }

    for (int ACQCYx = 1715090697; ACQCYx > 0; ACQCYx--) {
        yVanmXbKw /= yVanmXbKw;
        WjeJWdnIeuyYN = ! SJNjQgXuWRPSJ;
        fXIqTaqRZBkDXG += LltLpisUrBUAKpp;
        MKmKfdVkTLu *= XndYIQxrI;
    }

    for (int xVnbwBu = 1502514396; xVnbwBu > 0; xVnbwBu--) {
        HzGpHybwx = SJNjQgXuWRPSJ;
        XndYIQxrI *= XndYIQxrI;
        MKmKfdVkTLu -= XndYIQxrI;
    }

    for (int pWZKFsOMXbKgf = 941084564; pWZKFsOMXbKgf > 0; pWZKFsOMXbKgf--) {
        YbQXFfd = fXIqTaqRZBkDXG;
    }

    return cIChUzABQygD;
}

bool GztcSlQPOEEizYiN::CSQtXrr(bool itQDYxl, int WJmCEixYLBIjTpLv, bool dsOqdCCiYJr, bool BquPwEpWatSK, bool SPboYmGuacKM)
{
    bool raDuV = false;
    int LmJoxNn = 1310449751;
    double IyIjPR = 1031538.9974181398;

    for (int QzTZAajDI = 1126650527; QzTZAajDI > 0; QzTZAajDI--) {
        raDuV = ! SPboYmGuacKM;
        SPboYmGuacKM = ! dsOqdCCiYJr;
        dsOqdCCiYJr = dsOqdCCiYJr;
        BquPwEpWatSK = ! raDuV;
    }

    if (raDuV != false) {
        for (int mROmBSPa = 1841660324; mROmBSPa > 0; mROmBSPa--) {
            SPboYmGuacKM = ! BquPwEpWatSK;
            IyIjPR += IyIjPR;
            itQDYxl = ! BquPwEpWatSK;
            BquPwEpWatSK = BquPwEpWatSK;
        }
    }

    return raDuV;
}

string GztcSlQPOEEizYiN::towSIJZtPgmWVxDN(double fusJC, int JvImooPxtuoiYLC)
{
    int zjOovcmqmL = -2108592595;
    bool NnxUy = true;
    string MykHlWseHvab = string("ortKfqOBqSjhkgvZuSnnlWVJfYJTLQbmOrbAeOLGVSGZOuILQFycybhUNXVYNXMcwKVqlmWRAtO");

    if (JvImooPxtuoiYLC >= 1904148677) {
        for (int LklUeLSAhyNi = 600247034; LklUeLSAhyNi > 0; LklUeLSAhyNi--) {
            zjOovcmqmL = zjOovcmqmL;
        }
    }

    return MykHlWseHvab;
}

int GztcSlQPOEEizYiN::UnYvdsrkyFYp(double EWQXhixnNemSbqEY, double ldRVe)
{
    double iIELSttkid = -140671.3079916536;
    int TOtsQrSCIHkiRtrc = -704114241;
    double fiZUPSpvFg = 392757.89041609515;
    double QqjNjU = 533401.5059309115;
    double ZCvVW = -908659.4483487817;

    if (ZCvVW == -908659.4483487817) {
        for (int sLOxUujo = 1574826979; sLOxUujo > 0; sLOxUujo--) {
            QqjNjU -= iIELSttkid;
            ZCvVW += fiZUPSpvFg;
            ZCvVW -= EWQXhixnNemSbqEY;
            EWQXhixnNemSbqEY = ldRVe;
            QqjNjU -= fiZUPSpvFg;
        }
    }

    if (fiZUPSpvFg > -140671.3079916536) {
        for (int WStPfng = 1310712356; WStPfng > 0; WStPfng--) {
            QqjNjU /= ldRVe;
            ldRVe /= EWQXhixnNemSbqEY;
            QqjNjU /= ZCvVW;
            ZCvVW = ldRVe;
        }
    }

    return TOtsQrSCIHkiRtrc;
}

double GztcSlQPOEEizYiN::tzAzVMvAdoFg(bool LbEYVoPHTEZ)
{
    bool pBCybJjxCrZQ = true;

    if (pBCybJjxCrZQ != true) {
        for (int UqRcFujoZI = 1205051150; UqRcFujoZI > 0; UqRcFujoZI--) {
            LbEYVoPHTEZ = ! LbEYVoPHTEZ;
            LbEYVoPHTEZ = ! pBCybJjxCrZQ;
            LbEYVoPHTEZ = pBCybJjxCrZQ;
        }
    }

    if (pBCybJjxCrZQ != true) {
        for (int vFwBqorO = 675732445; vFwBqorO > 0; vFwBqorO--) {
            LbEYVoPHTEZ = pBCybJjxCrZQ;
        }
    }

    if (pBCybJjxCrZQ == true) {
        for (int NHMnBgalP = 96198397; NHMnBgalP > 0; NHMnBgalP--) {
            LbEYVoPHTEZ = LbEYVoPHTEZ;
            pBCybJjxCrZQ = LbEYVoPHTEZ;
            LbEYVoPHTEZ = pBCybJjxCrZQ;
            LbEYVoPHTEZ = LbEYVoPHTEZ;
            pBCybJjxCrZQ = pBCybJjxCrZQ;
            pBCybJjxCrZQ = ! pBCybJjxCrZQ;
            pBCybJjxCrZQ = ! LbEYVoPHTEZ;
            LbEYVoPHTEZ = pBCybJjxCrZQ;
            pBCybJjxCrZQ = ! LbEYVoPHTEZ;
            LbEYVoPHTEZ = ! pBCybJjxCrZQ;
        }
    }

    return 382727.98976166267;
}

bool GztcSlQPOEEizYiN::yHNbirJiNJgZg(bool ltTBaqO, string wiEjUhCHkZq, int KqneAOgU, string qUflAZTUxGiMmlG, string AzNBAxeGBDSH)
{
    bool ltgXz = false;
    int kvJKx = 369664640;
    string xyzat = string("AzYKuAKJiqJizSEDdpeOfPCwAkMSnfJdZNywNjcMGwKWfAsJvnyEVCFDNVgFxggUHgvpRzLUDhzUvZmvEAvocDZUMwR");
    string ITWays = string("rTUPupNeuUrYmZUrbOqUsIEjHylGIfaVKikKOvWddbRpMxINCZyMKNMkPFBTnHfxqnhKzESZNgjSqNAZrQWgJJxedcExbFYOaECjdAGDRECgkUQBxiSDTbxqjNCzyVKivgoXtkhfgQnCQyRTgTQvyhoBNWpptGsJUxRJkSIVQByfJORySxsxlLkQtIKsfqOeiWVp");
    bool FXXrDOeDdrKJVtq = false;
    string KIEIwXXhh = string("BLbVqHuhvtQWqwcaZYVPs");
    double pdKSTskKnaWfBjA = 82535.82444748301;

    for (int ReRjEhcUjCdfOsNw = 1649012276; ReRjEhcUjCdfOsNw > 0; ReRjEhcUjCdfOsNw--) {
        AzNBAxeGBDSH = wiEjUhCHkZq;
        xyzat += wiEjUhCHkZq;
    }

    if (xyzat == string("AzYKuAKJiqJizSEDdpeOfPCwAkMSnfJdZNywNjcMGwKWfAsJvnyEVCFDNVgFxggUHgvpRzLUDhzUvZmvEAvocDZUMwR")) {
        for (int EdZZwGqSpaWtY = 1863265739; EdZZwGqSpaWtY > 0; EdZZwGqSpaWtY--) {
            ltgXz = ! ltTBaqO;
            wiEjUhCHkZq += KIEIwXXhh;
            kvJKx = kvJKx;
        }
    }

    for (int aDQwhixcxMhMIMC = 903820889; aDQwhixcxMhMIMC > 0; aDQwhixcxMhMIMC--) {
        FXXrDOeDdrKJVtq = FXXrDOeDdrKJVtq;
        ltgXz = ! FXXrDOeDdrKJVtq;
        ITWays = KIEIwXXhh;
        ITWays += xyzat;
    }

    return FXXrDOeDdrKJVtq;
}

double GztcSlQPOEEizYiN::VwNNvYNKzQTw(int MkFiKB)
{
    string KVdVEijgJm = string("miOENcMZggSOQxZsZHNOOMiQXanTEjoXDbyJfAKeBOIGXPBbNfttssSdJPJwMGEX");
    string BzwJsJphSh = string("aDXloycGDKcbJRUwEpWIfCQOucmVbZZfLgOqBIQynRuBEbczZOHBPOmyBueNntIOMVptbxqZCqLBqrMJWdIldPjHyfccpylkNyuEQWlySLjrFLapsKuaZDyhMbHmdQZKibAnfAMmvcTfsxipgKIGrfdqbhmpVfXPhpBGzSDJXOfEAVzwXETPjfzIJYPstLJLPwHNuvBKTlhtyjjBvziKLcofJklRMyRHQQhTaSRJtjFnzVcCbZqfsLImqorvNH");

    if (KVdVEijgJm != string("aDXloycGDKcbJRUwEpWIfCQOucmVbZZfLgOqBIQynRuBEbczZOHBPOmyBueNntIOMVptbxqZCqLBqrMJWdIldPjHyfccpylkNyuEQWlySLjrFLapsKuaZDyhMbHmdQZKibAnfAMmvcTfsxipgKIGrfdqbhmpVfXPhpBGzSDJXOfEAVzwXETPjfzIJYPstLJLPwHNuvBKTlhtyjjBvziKLcofJklRMyRHQQhTaSRJtjFnzVcCbZqfsLImqorvNH")) {
        for (int IQosd = 2082399023; IQosd > 0; IQosd--) {
            BzwJsJphSh = BzwJsJphSh;
            KVdVEijgJm = BzwJsJphSh;
            BzwJsJphSh += BzwJsJphSh;
            MkFiKB *= MkFiKB;
            MkFiKB -= MkFiKB;
            MkFiKB -= MkFiKB;
            MkFiKB += MkFiKB;
            BzwJsJphSh += BzwJsJphSh;
        }
    }

    for (int xFqZXdC = 451944446; xFqZXdC > 0; xFqZXdC--) {
        KVdVEijgJm += KVdVEijgJm;
    }

    for (int wGxMtXVRK = 1111334110; wGxMtXVRK > 0; wGxMtXVRK--) {
        KVdVEijgJm += KVdVEijgJm;
    }

    for (int eGadliILR = 1364986163; eGadliILR > 0; eGadliILR--) {
        BzwJsJphSh += BzwJsJphSh;
        MkFiKB -= MkFiKB;
        BzwJsJphSh += KVdVEijgJm;
        KVdVEijgJm += KVdVEijgJm;
        MkFiKB *= MkFiKB;
        MkFiKB += MkFiKB;
    }

    if (BzwJsJphSh > string("miOENcMZggSOQxZsZHNOOMiQXanTEjoXDbyJfAKeBOIGXPBbNfttssSdJPJwMGEX")) {
        for (int nIKMipopVc = 587235232; nIKMipopVc > 0; nIKMipopVc--) {
            BzwJsJphSh += BzwJsJphSh;
            BzwJsJphSh += BzwJsJphSh;
        }
    }

    return -122199.31960096456;
}

double GztcSlQPOEEizYiN::zNosLgFP(bool CqlzLNyWQJRWMCnq, string LBXsLh)
{
    int opPqh = 141625559;
    int QJCxBVSDGv = -152203933;
    string IUeETkClNyW = string("mnvrXBonduqbEUyNbDFnbaEIGqPTjsoxgBdgJARImWuDiiKjhNeSIbBldGwFQNivUsrfPqRsAdYNLhmJhVSyJcDpryOVSFwxUsuLVFwQTahjATXwzYEMO");
    int FMpejZVoTkePtIf = -1138555637;
    int ppGVm = 360665977;
    double wadpfrXjT = 170291.9653859582;

    if (QJCxBVSDGv != 360665977) {
        for (int DbgKIFrhDVBxJ = 1820974549; DbgKIFrhDVBxJ > 0; DbgKIFrhDVBxJ--) {
            QJCxBVSDGv /= opPqh;
            FMpejZVoTkePtIf -= FMpejZVoTkePtIf;
        }
    }

    for (int gXAJp = 571974516; gXAJp > 0; gXAJp--) {
        FMpejZVoTkePtIf = FMpejZVoTkePtIf;
        IUeETkClNyW = IUeETkClNyW;
        FMpejZVoTkePtIf /= FMpejZVoTkePtIf;
    }

    for (int IgWyqFGWsymutDkk = 2025309118; IgWyqFGWsymutDkk > 0; IgWyqFGWsymutDkk--) {
        LBXsLh += IUeETkClNyW;
    }

    for (int TLffYAqzIP = 1223904960; TLffYAqzIP > 0; TLffYAqzIP--) {
        ppGVm *= opPqh;
        opPqh /= ppGVm;
        QJCxBVSDGv += FMpejZVoTkePtIf;
        opPqh = ppGVm;
        opPqh += ppGVm;
    }

    if (FMpejZVoTkePtIf >= -152203933) {
        for (int fXNsGxRSy = 1084891202; fXNsGxRSy > 0; fXNsGxRSy--) {
            LBXsLh += LBXsLh;
        }
    }

    for (int JnZRfPjv = 1968056357; JnZRfPjv > 0; JnZRfPjv--) {
        opPqh /= opPqh;
        FMpejZVoTkePtIf -= QJCxBVSDGv;
        QJCxBVSDGv *= QJCxBVSDGv;
        ppGVm -= opPqh;
    }

    return wadpfrXjT;
}

bool GztcSlQPOEEizYiN::PAhVFRhAy(double HFOrUEisMwbsxzAw, int MOTCQyEVpy, double QlPAu)
{
    int blqczoxbX = -465678505;
    string RxiKYoQoeCbW = string("TMKjgNeJmAUJAOelUhaIPOYswBAQRizlvhhcbHrsTciYBUsdzdfEtwGmLuCPgUKwfjNRVaPWFJWBdEgYWDJWcETjVrTWNmdrUIjZBkcZFSRrbixTPjKpfuMeFcKlgbPxtBewlbVachDozeiZQypeQUwHyNBOENQAjghXDKzoUIcUxUKazQNaahPbnVCRRrYVF");
    int dulgPtbdbh = -528420723;
    bool aDNCOHvEDJR = false;
    int RYxsAcZiKgZq = 569647138;
    string uTMJmtQTGrdcB = string("rnQtMBpCBynAzYjSTjpwsXsYVFSmFEBjODQenPPCHLRCWGHekxjWQytxdFcRMBmNjSoBdAHFyhUIzceninDxkgSEdKzcuojKKycJNlikFGcfCNjNRsOWAiXDGlQeJDISCGaufnXKBxDUeXXiMVNOQLmhSRhlzgAhGNltMfLJkKoDulIUAPJFxqkrTrDPvOlPIxDuRHwsJaRAOKimpM");

    return aDNCOHvEDJR;
}

void GztcSlQPOEEizYiN::eZOnAFI(bool cizNpyZrwGxe, string hbXBUshBJmd, string utIpZjTAJdgb, bool uuGzDUFUv, int OoRRv)
{
    int pYIFDK = -1962519636;
    int hMPutBGkT = -1310041265;
    double BDFsC = -904640.2514762713;
    string WWpYXXbn = string("uPMvmWWDzwuWhPlgtifpDmrQxcjmThLwWuFJQlqMsgXTeJXMbeKMiGXKtZrMWrDIBWLKuciTCXIMTHGxDUgxkGnBbatIkmutfhBnLGmdPOdJDepVuUlKXJGOGwCzmAaWlPhSEBSeKJwatyuqlFHdSVHa");
    double ttbxOTtmtPhmJpsa = 343839.54244516103;
    int aoLhoDOcQDa = -770030211;
}

int GztcSlQPOEEizYiN::WKEgGwQjtQlAtY(double eQXpqisN)
{
    string khCQz = string("WMQVjtkQelzTJYTlxoBZhFVnOaVwxSnLyJEZlnHxwRvKUShiUFKbiHiaGaAjvylDnQcIIjGRHZdYvyOTSSQSbSaqQnHoHyiWrBpBANXtlBTJLrrwRYDhlvsnKVvsASZKxSwMMOMdwJrpwbZgKLMbpUsgethbuohDfJOn");
    string sySvdUCCMpxwoDq = string("rnBCtPoKrgoAtuyOUwXzMEpM");
    string kjWjXaOkbCzCGIG = string("cKxKbedAmfUanBpuvFedKPwaonKdZSLGqDNinFqYcUFeWVgezJIiMEIYecUxNejDMcQgvknWgmSVIWrjAYpnwDBduIFVMlxSoJHeWfGRpTtLDdwSwbLkwOyKesjhffYoptiIHGFtjsYhgzBbpjcDxwVMdDDGEyOcYzQxBWpUjknRyxpSSKJeBsMGmxJAnNZJiQvMbvMTklUVqLIyVju");

    if (khCQz >= string("cKxKbedAmfUanBpuvFedKPwaonKdZSLGqDNinFqYcUFeWVgezJIiMEIYecUxNejDMcQgvknWgmSVIWrjAYpnwDBduIFVMlxSoJHeWfGRpTtLDdwSwbLkwOyKesjhffYoptiIHGFtjsYhgzBbpjcDxwVMdDDGEyOcYzQxBWpUjknRyxpSSKJeBsMGmxJAnNZJiQvMbvMTklUVqLIyVju")) {
        for (int nyiCmbAAlAs = 1339586222; nyiCmbAAlAs > 0; nyiCmbAAlAs--) {
            kjWjXaOkbCzCGIG += sySvdUCCMpxwoDq;
            kjWjXaOkbCzCGIG = kjWjXaOkbCzCGIG;
            khCQz += kjWjXaOkbCzCGIG;
        }
    }

    return -1179366538;
}

double GztcSlQPOEEizYiN::OdTjqzM(double nUEDEkELi, double tQwYlnrGctGFedK, double LOyVwHBG, double aYTbYDeqZXtf)
{
    string HLywfRdlBK = string("HtnpwdUQCMubzvFtuXWijktQSjcCJWDeaaKsGGgLzocDaQOmfNWkKnLofuzaOrVLadrjbvZuBqdHfASmBDFfJkpbFxRUzcHsHoeAQEyDHMRzRWeSnPRvieLDGFJNsEJTqBhGyXENLNkkRsImrDOhdzwuJtUFsCfdrjFUEoAMSNdKjlZjfSOkxoLLcJNGwqBlwtBojulnzAfVz");
    string kFtywdcsXbOJpWf = string("qMclcSwoTDZBAMRBRLvEwvFaDeQrHEqfqetHpE");

    if (nUEDEkELi >= 871083.3195386978) {
        for (int kCXhrN = 620172348; kCXhrN > 0; kCXhrN--) {
            nUEDEkELi += tQwYlnrGctGFedK;
            tQwYlnrGctGFedK *= LOyVwHBG;
            nUEDEkELi /= tQwYlnrGctGFedK;
            HLywfRdlBK += kFtywdcsXbOJpWf;
            HLywfRdlBK = kFtywdcsXbOJpWf;
            kFtywdcsXbOJpWf = kFtywdcsXbOJpWf;
        }
    }

    return aYTbYDeqZXtf;
}

GztcSlQPOEEizYiN::GztcSlQPOEEizYiN()
{
    this->WFroTLN(-954558.799872326, -104165.81723392934, string("AuLfGTjFtrZvAuxvjgPDwiDkwPCskwFsafnLTMIzXbRmdPWZwBBlqMqsBJRFIAbwqvHcBWYmstdHVIdnyMmdHHwVIBMQQGQUgTHXvNuQRKZVHfFArMosQYgyRxOYYkaVNeCuoCVZHRfDhqhHtvoEoLeoMolvBpUmryfr"));
    this->CSQtXrr(false, -1571782737, false, false, false);
    this->towSIJZtPgmWVxDN(-1011291.6203159649, 1904148677);
    this->UnYvdsrkyFYp(378046.43507415365, -925958.0244868924);
    this->tzAzVMvAdoFg(true);
    this->yHNbirJiNJgZg(false, string("jOdXkOFWKyqsMENftNzJhUsPAIFwmgE"), -1954307112, string("JiHXmvlfzRbwBcFVTvAwwxivCcbWaQxLQxMSuoAIrHTPBenLKZsACpDCgZHBultAdxldqQAtcaXpIbbeexuQXurCQqKSDFkhdlyunouBVofkOKHVtklwpVWSnHsTKPoveZqGWLNzeNlZltUZnGAiYEKYVYSwfxxnAGWITfXdBTOVnGPwSOujqSjSYoAxrnjwrVXpaENcPHPtjypoVQSdUBwyDdyWaySIdHlQNafUmxQKj"), string("jMzKJwnUktgvAgjYrCsTHZNnGdmCFHSojOqSUuzrZHuuJJDUUZOpTTzDjVfbiYZKPRDcaZrBeAYatlcSRPSkVwuidXpYPKdIZcBKVvLWfBnKxUsFmWkKSASaBPQpnXiTlFnxdNxjYAIoRuuyqeBTZJihabKnYoQcsphXiKENfwAHEvksXApqoxyBltBVsqbWqXaoiWsHUugzWtpnNCGDRVRmWQuRnk"));
    this->VwNNvYNKzQTw(1614531102);
    this->zNosLgFP(false, string("ADazOAbOszZgiqkQtblCIXOvHCdnFlcZXBckYJOdBiaXbsyNZPvBwzFmmxvbEKsQSCHGKqNPETECZbBlEsTswxLRIuWomoOEorcDPibnOaZHgAyNSXhKbuaySwWlviMVMDjDbntLmKnplLweorqJPnWkuzBKUPksrxfhRGhEcMFnKEQW"));
    this->PAhVFRhAy(-396375.4180226361, -598615151, 1027615.7023466331);
    this->eZOnAFI(false, string("VwoBPYsFfMFcyteOBZiMuscRgHrKAbaHfFQhWSLmrXtohlciopOqzWhwCytRQdSvCAfUqABFrnxkzBwLmJFlbsluSOfZPvsexCAAzhZlQIPqFqbGbHwrCGdpx"), string("NSTAIiyUnbslvNkeSnaQXtlZsjXfZodtDPIBAMAknmnsQMSGWvNibFPEycsXNJvgBvNSKJnOnTkFAWpGtwHFwEGkbrwcKSKdylNjwWlUqzLcNFcuPnmHfQpyVOworxhcAWaviuxfizdblvTSXXiLz"), false, 398069390);
    this->WKEgGwQjtQlAtY(-954761.5914213057);
    this->OdTjqzM(-299576.7865055082, 72657.77094354854, 871083.3195386978, 513255.28023202886);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RipzngE
{
public:
    int mGFAi;
    int WphWrIKIQyED;
    double qdlPlPuc;

    RipzngE();
    double GPovWP(string RiXVSfFFqLa, bool wCDmEptZZNn, bool jVPaTwYepml, double xpnVaGXo);
    double olTWDrL(bool wVcyvsb, bool HUZSTG, int zlAzIuQDhZWwQiCV);
    string AfbWujKLqghSyul(int OXHbvIMIXKxr, int VAXcBq, bool DJjOBpMXtqWD);
    bool smQaFYSNG(double bjdkpvOKYzgZMWB);
    void vDMMkujenyH(int lbKHXomim, double QhxWu, bool kkFIzpeX, bool IvMrb);
    double bMklVEpULKLm(string SFrZHZH, double JcmtEmmSyQm, int KbEcpLmsOna, string ohEzfldUZXoe, int okCywG);
    bool BYgRqCXI();
    void WucbAFkLqYKqxWx(bool tnGiUlrIgBVKi, bool RPCTC, double CQzuBKBIlqIdo, string HkkRJZSakYx);
protected:
    double BcGcD;
    bool OZpxzkZFVKxGqH;
    double ByZCTCyOJqbGmLkm;

    void SPWxuH();
    void ZSludAh(string tkMMUlYVh, int UigZZpWZ);
    string WVDAf(bool BCvnZMAUlWdi);
    bool ntyZiK(double RICrp, bool SyZIicL, bool iBOUqpDCSwdlfR, int pzYsFYpXqScv);
    int UDSSVvYfd(int nDAmgbQ, bool OwUYpm);
private:
    bool QyHwqIeYWMbxJygi;
    string ZJUnNduD;
    string BQJNol;
    int akBLCbo;

    int uooOBjSeqF(string FmtjoKKnbL);
    void wZnYyRhaHJEw(int rzPQf, double MIsJBOhR, int mQqyItZOuwfy);
    double GCcgWCfDlvmylCY(string EgGijFKTYWEzK);
    double SECgVPIBhNcCUojA();
    int vOAWGux(string OZRLTQ);
    string MLzwGQkB(bool BPNyd);
    bool wpsLZIIMT(bool vOOiCRDwAMRqlIY);
    bool hoMmwcr(int KeLhd, bool XrlDfErD, bool QeypewxJcM, int VoLyGVxpkmf);
};

double RipzngE::GPovWP(string RiXVSfFFqLa, bool wCDmEptZZNn, bool jVPaTwYepml, double xpnVaGXo)
{
    double UxOWp = 456176.110894143;
    bool TFZqXViDvQoPjO = true;
    int mwHqBI = -204239788;
    int iLEsJvyWjEd = 957459248;
    bool PcTxRSacgHumTGoC = false;
    bool pUEwvel = false;

    for (int AMrskHRgNM = 1927203788; AMrskHRgNM > 0; AMrskHRgNM--) {
        TFZqXViDvQoPjO = ! TFZqXViDvQoPjO;
        UxOWp *= UxOWp;
    }

    for (int yxEjC = 492051549; yxEjC > 0; yxEjC--) {
        iLEsJvyWjEd /= mwHqBI;
        iLEsJvyWjEd -= mwHqBI;
        iLEsJvyWjEd += mwHqBI;
    }

    for (int eUJSY = 2124156970; eUJSY > 0; eUJSY--) {
        TFZqXViDvQoPjO = ! pUEwvel;
        PcTxRSacgHumTGoC = PcTxRSacgHumTGoC;
        wCDmEptZZNn = ! pUEwvel;
    }

    for (int kengP = 565335396; kengP > 0; kengP--) {
        mwHqBI /= mwHqBI;
        pUEwvel = jVPaTwYepml;
    }

    for (int mAWRJDKeFk = 1539517337; mAWRJDKeFk > 0; mAWRJDKeFk--) {
        jVPaTwYepml = jVPaTwYepml;
        wCDmEptZZNn = ! pUEwvel;
        wCDmEptZZNn = ! jVPaTwYepml;
        TFZqXViDvQoPjO = pUEwvel;
    }

    return UxOWp;
}

double RipzngE::olTWDrL(bool wVcyvsb, bool HUZSTG, int zlAzIuQDhZWwQiCV)
{
    bool bDQOdve = false;
    bool GuakBUSAV = false;
    bool tgHXyiuLzVyARak = false;
    string DCklPqvNlpkD = string("TyTLFlTIyHUvIbRlaQZhBJxgQRkWsfwVgHlWRbFesqwikpXIVxwGFSmeNohSfdZBLzjbCWDSPaxkadiKXDKxongsxTPeAznUmiVlMDREavrMVprHLjGpKOUBKUzAlpPExjqSiYzGJN");
    int ynyTwnjb = -1775351264;
    int GBQzW = -980614703;
    string ctqiBOX = string("DmubyXleThrvjictUVlIOzivrrKjjGaqEKldJsRFxuYPogBAfMbXIAhFQLzzFBeaKoBcqKvuXtfdkhLIcgmtqtLkpvHKBNWqeZVnaIRKvXprAGRKypNjAGCcaLygHxkqeyZCzFQkRLUNacsEathRRUUkiTOFFUDOwBJgEbOOMPNMTwmxWgRELQHSCckHgTqW");

    return -1046983.0962540117;
}

string RipzngE::AfbWujKLqghSyul(int OXHbvIMIXKxr, int VAXcBq, bool DJjOBpMXtqWD)
{
    bool cVpXdTlRFpOqyP = true;
    double nHUFizXeSNaeYe = 778597.6114972585;
    string jUKzqEjRkp = string("TorXayZlsFmQdZkzmCVEAFhBvxKyWaHoINwZURQPsHNnekuEMMAcMkToeAmligFrGFnXyeYDQojJUKZsFwtUiphtvXVYeRQcBxychNKIqruLiFBTZvmXElEYWZsYAAimEGFcDBPNUlKQlSfSkmMAKLpemjfBALjBWwPSvzfwxBaOoxF");
    string lnERqhAHrar = string("aYKTSJFfstipedcAYzPSAtDmZdsvhjfVaUXwyPEikRbFzdkTsdIxtIXHNzctaBEjnPclktkzsgfvDKQQWdQLYLWsiZOSCVoaFrbRUHReDhELQqtDsKzZcdGXJMEINtboXWkTBTsRTAQDSgMLofKAjqOQszBRdtYtXToMUjeDZh");
    bool iLHMzZympfAD = true;
    string DzHewFzgBAEQi = string("iMgoEfDHhsLjwDGPoTdhAbHPrqJGRGCkIhmBHKOcMnbDsgJJHSfOejZWOnYsLMwpsvSqDNtXggFvmeEMCiPbFYbfgJWHudhn");
    string gNQlQRPRtIjO = string("EJtUByRRKcwVCBqM");
    string FMbVv = string("HGFmEHBOyUUPZFmVxsltxbSYbtQNAFsETPwHZZPwrVxbPWSgyLZmhyGslBhXjHyYvpAdEDrRowLGgkuRFldKxnyIJDnusPfFVpJYARoyGIKuMBVULBVLWPHxVJYxIQllATHrbTlxESYRwBzzNulcnOCtrL");
    string uUomwjGUahGlZXP = string("WDKfDwACKzAOgGahUhbyfwOTdOAqa");

    for (int EGyHF = 987419625; EGyHF > 0; EGyHF--) {
        gNQlQRPRtIjO += jUKzqEjRkp;
        cVpXdTlRFpOqyP = ! cVpXdTlRFpOqyP;
    }

    for (int OHZCXbJjISYqRS = 1021906569; OHZCXbJjISYqRS > 0; OHZCXbJjISYqRS--) {
        DJjOBpMXtqWD = ! iLHMzZympfAD;
        DJjOBpMXtqWD = iLHMzZympfAD;
        FMbVv += uUomwjGUahGlZXP;
        DzHewFzgBAEQi += lnERqhAHrar;
        FMbVv += jUKzqEjRkp;
    }

    return uUomwjGUahGlZXP;
}

bool RipzngE::smQaFYSNG(double bjdkpvOKYzgZMWB)
{
    int xxoASxSNZWvNH = -1046307367;
    bool nsSuCPuBpkTNCjN = false;
    double rvtuAtYuo = -139339.4511562901;
    int JywtjQQJfPa = -1475908988;
    string nvxAnuTsmNUcma = string("qcWgUfpYxTxkwvFKdRXmjOdcQeXTztFTIdHEjDOtDiiZCvXZyrLCVYMIOLXSiFjmifGVOZXqmcloonhAcFlDQxVVuEGzHrZbdaXYOtamUELbLHFzWikNlevJsuLgfGvUyEJjEKhcEQkczbqDwzlMgVPbaUJVGHXKnzPLWPixIADyBhbDPAawmpOxpegcFgWikMlTqKBZEeUZB");
    double MvFMO = 47316.466006095536;
    double RTDikXzodaiIuMtj = -649979.4692382455;
    string ZYzETmBoVO = string("UdqXpwwVkNXgtgYsDRwxBTZsKqjtybs");
    int ChgpETegrDw = -2037636407;
    int mKyNYjfPxFM = 1250808723;

    for (int RVGItSAGeoziF = 1938937175; RVGItSAGeoziF > 0; RVGItSAGeoziF--) {
        nvxAnuTsmNUcma += ZYzETmBoVO;
        mKyNYjfPxFM += xxoASxSNZWvNH;
        rvtuAtYuo -= RTDikXzodaiIuMtj;
        nsSuCPuBpkTNCjN = ! nsSuCPuBpkTNCjN;
        mKyNYjfPxFM *= ChgpETegrDw;
        xxoASxSNZWvNH -= mKyNYjfPxFM;
        rvtuAtYuo += RTDikXzodaiIuMtj;
    }

    if (xxoASxSNZWvNH <= -2037636407) {
        for (int hnpYPxXN = 703983161; hnpYPxXN > 0; hnpYPxXN--) {
            MvFMO /= rvtuAtYuo;
            nvxAnuTsmNUcma = nvxAnuTsmNUcma;
            nsSuCPuBpkTNCjN = ! nsSuCPuBpkTNCjN;
        }
    }

    return nsSuCPuBpkTNCjN;
}

void RipzngE::vDMMkujenyH(int lbKHXomim, double QhxWu, bool kkFIzpeX, bool IvMrb)
{
    int mOAML = 1716980658;
    double uwasTDq = -384273.1506890578;
    string NRzhyaNGjtpAa = string("aseTKVJvXdntAljkbTKDSdyFMTSiqMOZFBnTvWVCcCxbCSYaG");
    string URPPq = string("VlFySQwABloGIjqMpmqBQfjyYMChLvZxhrLTAIapjpiMGZVLDBbOsBaZQQGwQXShUXezGbBfkbEJKhuvbeeoHfzfUzgkPQilTYTAUIkrquLhxolYfSYXuByUjFiDJeFOUhjtAbkSfgvuDMbwovlwgCvmjVaIpCkbVNMDFqtURtXHEiijxpNzmkCxfWkLZUYAhNhTWFJDjCGBEjOIGRxEygLOAhyEeDswWHkqhEYFNdjwcyBxesjV");
    bool eBScJBptV = false;
    int BZOCqbiSvByOeCL = -2030597159;
}

double RipzngE::bMklVEpULKLm(string SFrZHZH, double JcmtEmmSyQm, int KbEcpLmsOna, string ohEzfldUZXoe, int okCywG)
{
    int isBJN = 2080750404;

    for (int TxNdGg = 1237586206; TxNdGg > 0; TxNdGg--) {
        SFrZHZH = SFrZHZH;
    }

    if (JcmtEmmSyQm < 282133.5671336203) {
        for (int DttrqBmFEjGcvGHS = 1476880199; DttrqBmFEjGcvGHS > 0; DttrqBmFEjGcvGHS--) {
            KbEcpLmsOna /= isBJN;
            KbEcpLmsOna *= KbEcpLmsOna;
        }
    }

    return JcmtEmmSyQm;
}

bool RipzngE::BYgRqCXI()
{
    double RqQDNDgFBJGdVWkf = 928008.4920125076;
    double lFjwPmKGZcrn = 501966.6132297168;
    bool kcFEdKsH = true;
    double YdIaHprAom = -992988.5334714989;
    double mlVASs = -89217.33175982992;
    bool aHXsDuxhqRgC = true;
    string PZbKkTD = string("fqbfERFkZgDtDqpvvcvfLXMgRrGTCDgBiuwLsJShLofXvRkxHtexgeZaLgMcUhgiSYxKbqcrvfqjioyRnQOgIIlEHGQGdOPYkgKxUAXOGURAzNYwdgVqYJpVhRWENyHmTIJAMLejjCbDBoUwGDlLdqqLPCPCJgPpsDjUtlcsZaPLMJqsjOoXzO");

    for (int ytipNiczkfsLWU = 621253778; ytipNiczkfsLWU > 0; ytipNiczkfsLWU--) {
        kcFEdKsH = kcFEdKsH;
    }

    for (int wWCLF = 446963637; wWCLF > 0; wWCLF--) {
        YdIaHprAom *= lFjwPmKGZcrn;
        kcFEdKsH = ! aHXsDuxhqRgC;
        RqQDNDgFBJGdVWkf += YdIaHprAom;
        mlVASs -= YdIaHprAom;
    }

    if (mlVASs >= -992988.5334714989) {
        for (int nPFQLUkVmfN = 892442177; nPFQLUkVmfN > 0; nPFQLUkVmfN--) {
            aHXsDuxhqRgC = ! kcFEdKsH;
            YdIaHprAom = mlVASs;
        }
    }

    if (RqQDNDgFBJGdVWkf < 501966.6132297168) {
        for (int LbWzsMng = 142364497; LbWzsMng > 0; LbWzsMng--) {
            continue;
        }
    }

    return aHXsDuxhqRgC;
}

void RipzngE::WucbAFkLqYKqxWx(bool tnGiUlrIgBVKi, bool RPCTC, double CQzuBKBIlqIdo, string HkkRJZSakYx)
{
    double wvbdvLBg = 846176.2192201482;
    bool kfmfJLdzTwVpmt = false;
    bool qDNLl = false;
    string txAsQNyAR = string("qpwilGpVeFAPIxvEXMbZCBjzsSBusIluZGFNAnlyrUXJDIeVuNIdiCLgBXochByFQboaPrHamgVqzdRXwhldSJc");
}

void RipzngE::SPWxuH()
{
    bool fZvOqxctetkhrnEj = false;
    double IEaaAyJ = 446338.02072050713;
    string xWpGfcVMxtpqv = string("uFDNlgfSTDzfVHnPBVfDkSZVVZXKqbqAtpElNsxuxOVthTpPhPKTdSnseQAppgumamvuGHDdefaGJAougeeQieMEk");
    bool SnQsmcOXVIqIx = true;
    string udUwNyEPcK = string("BDZNapGUxVrOVuMqgECQIcFcOCVSYNEUebBTVjgSqXPFXGzmRjMoeDpKusObpfnPfBRrhlbrfSAZcQutlCevhIGjcTVuKdmkPwUJFyeOYqNnaL");

    for (int oSYlAIlFRtTQEjM = 605214442; oSYlAIlFRtTQEjM > 0; oSYlAIlFRtTQEjM--) {
        IEaaAyJ *= IEaaAyJ;
        fZvOqxctetkhrnEj = ! SnQsmcOXVIqIx;
        fZvOqxctetkhrnEj = fZvOqxctetkhrnEj;
    }

    for (int FCiDuKhjY = 442602876; FCiDuKhjY > 0; FCiDuKhjY--) {
        IEaaAyJ = IEaaAyJ;
        xWpGfcVMxtpqv = xWpGfcVMxtpqv;
    }
}

void RipzngE::ZSludAh(string tkMMUlYVh, int UigZZpWZ)
{
    bool wsLagio = false;
    int eutftcJeOQPS = -658909647;
    double fkmomlZqPSfaUWud = -172791.03091710803;
    bool diskI = false;
    int nqlXrUfYBsZAKaPZ = -59377217;
    double TwezTnIaT = -563917.7753743596;
    string TaHAbRABRWIP = string("sBFHEKaxoxSklpqaFevWiiWGNIwqPcXlErHUXRFNpAXsYWPabpdGMToHZTRYyVooYYuesxXDPEDTzOROZHntewDeHLCAhUVqPuJoABYAlWhMZAGkjSILMlcDnlbbyhVefjWPoSCbxLPFsxNrlaLTwgIQhCoigzihpPDzeCIeUetJXFTWqSVSINrCcITArrMyZgrAYaJvuAhwwNDONHoOBvOWBfmzOqdR");

    for (int lTHPgWQ = 1365452312; lTHPgWQ > 0; lTHPgWQ--) {
        UigZZpWZ = nqlXrUfYBsZAKaPZ;
    }

    for (int jEvLzgxplnpEtkmx = 806401178; jEvLzgxplnpEtkmx > 0; jEvLzgxplnpEtkmx--) {
        continue;
    }

    for (int vHFPdgcynzoWaf = 1036083289; vHFPdgcynzoWaf > 0; vHFPdgcynzoWaf--) {
        continue;
    }
}

string RipzngE::WVDAf(bool BCvnZMAUlWdi)
{
    int OaMSgeQvXjtqJ = -580972692;
    string wuMih = string("voUVGHqaMJRKSPMFmyBoojzfTiDFEBbPzxjcplMCjmaRjozmWzobBcskgdAewpfIDxvStBUZRSwSAvgtXLDUgNkNcjdxKY");
    bool vrphkHpFZWbzT = true;
    string KQRDKqnTHnyAYM = string("qlEBZtozVzcYoRUitdlbTzKzIODlRexFKnPPpucshGmayouhUtxRYICuVXPUIHIibzbpeCUNztyDJtqgdRKfNdoyQXoXwISQYYmu");

    if (BCvnZMAUlWdi != false) {
        for (int ElhxXUeRT = 1212407075; ElhxXUeRT > 0; ElhxXUeRT--) {
            BCvnZMAUlWdi = vrphkHpFZWbzT;
            vrphkHpFZWbzT = BCvnZMAUlWdi;
        }
    }

    if (vrphkHpFZWbzT == false) {
        for (int DRnxFHcaHZn = 277701111; DRnxFHcaHZn > 0; DRnxFHcaHZn--) {
            wuMih += wuMih;
            BCvnZMAUlWdi = ! vrphkHpFZWbzT;
            KQRDKqnTHnyAYM = KQRDKqnTHnyAYM;
        }
    }

    for (int COSEdxA = 292470763; COSEdxA > 0; COSEdxA--) {
        KQRDKqnTHnyAYM += KQRDKqnTHnyAYM;
        OaMSgeQvXjtqJ = OaMSgeQvXjtqJ;
    }

    if (BCvnZMAUlWdi != false) {
        for (int XHvEzlMTb = 764925396; XHvEzlMTb > 0; XHvEzlMTb--) {
            vrphkHpFZWbzT = ! BCvnZMAUlWdi;
        }
    }

    if (KQRDKqnTHnyAYM != string("qlEBZtozVzcYoRUitdlbTzKzIODlRexFKnPPpucshGmayouhUtxRYICuVXPUIHIibzbpeCUNztyDJtqgdRKfNdoyQXoXwISQYYmu")) {
        for (int aprOnVMYxNPpb = 1990232702; aprOnVMYxNPpb > 0; aprOnVMYxNPpb--) {
            BCvnZMAUlWdi = ! BCvnZMAUlWdi;
        }
    }

    for (int thqAOjukqp = 800526978; thqAOjukqp > 0; thqAOjukqp--) {
        KQRDKqnTHnyAYM += wuMih;
        vrphkHpFZWbzT = ! vrphkHpFZWbzT;
        OaMSgeQvXjtqJ *= OaMSgeQvXjtqJ;
        vrphkHpFZWbzT = ! BCvnZMAUlWdi;
    }

    for (int TBVAdQQHQlzFurgM = 1439072272; TBVAdQQHQlzFurgM > 0; TBVAdQQHQlzFurgM--) {
        vrphkHpFZWbzT = ! BCvnZMAUlWdi;
        KQRDKqnTHnyAYM += wuMih;
        vrphkHpFZWbzT = ! vrphkHpFZWbzT;
        wuMih += KQRDKqnTHnyAYM;
    }

    return KQRDKqnTHnyAYM;
}

bool RipzngE::ntyZiK(double RICrp, bool SyZIicL, bool iBOUqpDCSwdlfR, int pzYsFYpXqScv)
{
    int ezlyTYxHOy = 363215251;
    bool FNqGisqkiUqAx = false;
    int dOBmFPCeNKc = -784093737;
    string hCrgBeiLLvHhCGg = string("eeGEQiXfplOSjTEAzyGAuRcQZTFmdceXjcGqHmDezzfNeGFWXPQnPBYVPjEqXIZigdrqUAjYfyonGBGPCpqYwDxGtsqnUOvctcglSpQYvgOmEuAXpBnNtVDbeclOPQYBANUUXfYrryseuFRSXpFqYcfhAyzuwEKKnBINfzkBfZNkGIiYHnKryZowMqSN");

    for (int WcmNHUeNOOhA = 1871374694; WcmNHUeNOOhA > 0; WcmNHUeNOOhA--) {
        continue;
    }

    for (int zvPQzbWK = 600959919; zvPQzbWK > 0; zvPQzbWK--) {
        continue;
    }

    if (dOBmFPCeNKc == -408302397) {
        for (int TEHRRjjuVS = 1988492389; TEHRRjjuVS > 0; TEHRRjjuVS--) {
            continue;
        }
    }

    return FNqGisqkiUqAx;
}

int RipzngE::UDSSVvYfd(int nDAmgbQ, bool OwUYpm)
{
    string trSCJPwzPcW = string("wjOAHCIYkHfvvpYmCNnwofcekhgsyTxBnHpeQCiCXKvkPBdwfPmFjhbLrLWFYUIiynhkmQCtXTTzMySeUVfnUwTZBCGaRnjgEJTihDMyaNFeyIYzHkKlNSzaUbYhwZoKmrogNeaFxZMnQyxLQKqTAyjvCMkGEGhyEwTKZEBqjwEahkmChcNfCdxjDxmpOypowMlvZVfRrPpiiXajxsBFLbxwLuWfeUQyftMwhWTVHI");
    int ivzgwxUgIGGOxl = 396026958;
    bool GOAJm = false;
    int PtdYaz = 1906158253;
    string GNMCqOh = string("lHgbPCvJeTWohyEUaXASfMIhRdeAmGGAKoktRwucAtrTaxrdwTdFXbJbKdXufOatFlLoCzAzslNjGrLjeATuvlbRdXYjuXNorQcBOijWxMfPmbIXvBDDttjnIMkhW");
    int fyTLJAHZu = 2002940238;
    double XlDGdcEzNqaQDr = 674198.31755884;
    string gkBEbCkybMG = string("GlohpdpzKwHpKXtmRJrZVJxagETqdbZRleFqqOuuLYlPJAtwXKJZGwaQgzYbrDIEYgAbhcuEKMAXpmCZPIdjwTlIRHOPLToQWEzMJLCwFaEBvfteVxWSbXjdxuHSpRuaqkJohvRYZqPxJabZtZdEMocrQZGLgYLiXFIvRWAzHgNIqlMKApyHKOyAxMvIhYKGxjijRjPMOseTOjjeLNWPaf");
    double ZyCMYrNRt = 634317.1342513373;
    string QcJDGNUVdISJqlX = string("ZBfVEvdjGsJKAcTasULsnGIgoThcKhgCksqnFSlm");

    if (trSCJPwzPcW > string("ZBfVEvdjGsJKAcTasULsnGIgoThcKhgCksqnFSlm")) {
        for (int LxmdfbEwaTtFkmT = 1675488365; LxmdfbEwaTtFkmT > 0; LxmdfbEwaTtFkmT--) {
            GNMCqOh += GNMCqOh;
            trSCJPwzPcW += gkBEbCkybMG;
            gkBEbCkybMG += trSCJPwzPcW;
            nDAmgbQ /= nDAmgbQ;
        }
    }

    if (XlDGdcEzNqaQDr >= 674198.31755884) {
        for (int mSNzEaEGftzOPrNm = 271449452; mSNzEaEGftzOPrNm > 0; mSNzEaEGftzOPrNm--) {
            continue;
        }
    }

    return fyTLJAHZu;
}

int RipzngE::uooOBjSeqF(string FmtjoKKnbL)
{
    bool tQDaNrwCFjIOuhXN = true;
    int kSXPIrnqYoOUpLE = 1898868212;
    bool XQPoGyONlyCz = false;
    bool sdRKURPqfbrdWO = false;
    string YJNkFJjRzFSsn = string("xUyCxBkSZZcmWiyMpjrUjifkiHlMQUoUTmmoUXRINsAvkgKQxSWpbGAEFAwPoixFDI");
    int kmaqYxdCAfVD = 1083909849;
    bool WKMoYFJ = false;
    double jWZURBexyu = 826598.9365508803;
    int JPOWXfIwQ = -1500300949;
    int aOtWjFtwYsP = 2133929689;

    for (int NAnLBqbYATBszyZY = 227526623; NAnLBqbYATBszyZY > 0; NAnLBqbYATBszyZY--) {
        XQPoGyONlyCz = XQPoGyONlyCz;
        XQPoGyONlyCz = ! tQDaNrwCFjIOuhXN;
        tQDaNrwCFjIOuhXN = sdRKURPqfbrdWO;
        aOtWjFtwYsP /= kmaqYxdCAfVD;
        WKMoYFJ = ! sdRKURPqfbrdWO;
        aOtWjFtwYsP -= aOtWjFtwYsP;
    }

    for (int FJLRsuktDVeMcw = 2051737536; FJLRsuktDVeMcw > 0; FJLRsuktDVeMcw--) {
        WKMoYFJ = WKMoYFJ;
        JPOWXfIwQ /= JPOWXfIwQ;
        sdRKURPqfbrdWO = ! sdRKURPqfbrdWO;
        jWZURBexyu = jWZURBexyu;
        FmtjoKKnbL += FmtjoKKnbL;
        WKMoYFJ = ! WKMoYFJ;
    }

    for (int UYUFYdzamSYvsLm = 1539729641; UYUFYdzamSYvsLm > 0; UYUFYdzamSYvsLm--) {
        continue;
    }

    for (int pLGUGCj = 1001741114; pLGUGCj > 0; pLGUGCj--) {
        sdRKURPqfbrdWO = tQDaNrwCFjIOuhXN;
        kSXPIrnqYoOUpLE /= JPOWXfIwQ;
    }

    return aOtWjFtwYsP;
}

void RipzngE::wZnYyRhaHJEw(int rzPQf, double MIsJBOhR, int mQqyItZOuwfy)
{
    int bcJOQNnfrsONX = 493568446;
    bool EcMEB = false;

    for (int gmPEPGox = 542903985; gmPEPGox > 0; gmPEPGox--) {
        bcJOQNnfrsONX = mQqyItZOuwfy;
        mQqyItZOuwfy -= mQqyItZOuwfy;
        bcJOQNnfrsONX *= bcJOQNnfrsONX;
    }

    for (int cJljelpm = 2064525597; cJljelpm > 0; cJljelpm--) {
        EcMEB = EcMEB;
        mQqyItZOuwfy *= bcJOQNnfrsONX;
        bcJOQNnfrsONX = rzPQf;
        EcMEB = ! EcMEB;
        bcJOQNnfrsONX *= bcJOQNnfrsONX;
    }

    for (int FyiIrwEDPeK = 916452323; FyiIrwEDPeK > 0; FyiIrwEDPeK--) {
        bcJOQNnfrsONX /= rzPQf;
    }

    for (int bolahJUAgADikDP = 1166183772; bolahJUAgADikDP > 0; bolahJUAgADikDP--) {
        rzPQf /= mQqyItZOuwfy;
        mQqyItZOuwfy /= rzPQf;
        rzPQf += mQqyItZOuwfy;
        rzPQf += bcJOQNnfrsONX;
        bcJOQNnfrsONX += mQqyItZOuwfy;
    }
}

double RipzngE::GCcgWCfDlvmylCY(string EgGijFKTYWEzK)
{
    bool EGfiK = false;
    int ttyZtbeEg = 678430166;
    string hlqrGXfItYlITXwC = string("rpWxGCaCxESxhiwRtZqNYNpuJMYgpVEUjlYHHkYpDggsBtXDISlLVubsWFZUeuEnWGmQvwxcCikaKFOlXCOmzFWlWCjIKrzRWjMVXoKlRKAKDIpYrbbwvyWfBe");
    bool vRiFgVT = true;
    string PCNpf = string("NjNfkhzLQMjtTLjBNGGNUNdazSxvwEkgOSUaZYREVVLgqXiaIpcApLbtCIfnkqNwgtRUEIkqQrOAYwJmThESTYuXfbqYQpygORHvHJcPUUrzqmyXFaCQzQjBWMoSpVpQWbrGxNlbyrrcKhEcTGUc");
    string cWDIhQrPqfRqFd = string("HyKWujUSBDAQEWcyAGHAouUeUIqAuVaSFVzFyOlUmcRFlvfjzOpAquFJxvdxJcKHBEvJURYuHvCJIJUfrrSGutpexWYIXLRoshbWSrWVmcLonYoPmxSGFdLgUnPEQzDBGfGAHKViymWiPPSvePkBKtHWawZrHJaGxUmpsKxUnTQOlzPdNwUldaxNK");

    for (int IJswD = 1299408812; IJswD > 0; IJswD--) {
        cWDIhQrPqfRqFd += EgGijFKTYWEzK;
        cWDIhQrPqfRqFd = cWDIhQrPqfRqFd;
    }

    for (int PTcfCdkjyRKC = 1189628152; PTcfCdkjyRKC > 0; PTcfCdkjyRKC--) {
        continue;
    }

    return 593926.4442467546;
}

double RipzngE::SECgVPIBhNcCUojA()
{
    int JOtibtTIRghuljJI = 288548039;
    bool RdKqAYRMDlmMi = false;
    string uXnsFrOPGm = string("OYvfTKZemtkVEElBaVWuWoREvbWnUUBXPOclugcVWiKBHNsPpKCVptzPNztjVQoSjLAEUgTogGgkIjBWDaGmRBECWngAvszVZlrUGPXUdIpfbTnjTwwVcLDrIcGAnKeQcVPgBKrnaYMrkzAuPPAlqLnqmtHdECgiyHUcyLLuGZdwNiPgFijs");
    string QUuWFokPzLuPuOmh = string("SPfHbXGCZAgLFGegKKpwCuhhulDapVRfKJcBYFeUGZelIulNNQDxINmtedUoUbMJfIyMcTPudnnBznfEpuuKqIUqXUNYTMGOCJFLkfJYlggvBxzfhESdwUiZZuyoLVaYmhzdxCJcVOuXmxOvIblzPyfkHPQqJQZcDctlrCLwgQM");
    string vqALx = string("sWqSNPVOsiGqhvCeTuwpqkWvHtEnwhHqkppFNPdjPGRAYyzsOkxKrPXIXHjEdLvfJIWWaBSwjUHCjVgQSnhibQzBdSaZcCZhOuNBfCMpkcGKNASBhgSPbqkXEKzLfBxMzKvhfMENYQBdsnBaAqnelEodERLRhLsLJguMfSYKqHQZxyIKPRZksbZlwViQChdiXykyNOSEhtjprYhlmAZKPuOFtGVBLhdlfkgoMDDRtYeS");
    int tjMGYZL = -1598041607;
    int VbZspmUgfMdKa = -1283573953;
    int khVnDBJhfmz = 772807633;

    if (JOtibtTIRghuljJI == -1598041607) {
        for (int oWMftWedDxkmi = 1233745609; oWMftWedDxkmi > 0; oWMftWedDxkmi--) {
            VbZspmUgfMdKa += JOtibtTIRghuljJI;
            QUuWFokPzLuPuOmh = QUuWFokPzLuPuOmh;
            vqALx = uXnsFrOPGm;
        }
    }

    for (int QBlDy = 1972155592; QBlDy > 0; QBlDy--) {
        vqALx = uXnsFrOPGm;
        VbZspmUgfMdKa = VbZspmUgfMdKa;
    }

    return 908348.098824271;
}

int RipzngE::vOAWGux(string OZRLTQ)
{
    double OaXAUrWQs = 979995.9093644826;
    string RmCgMcQXTUILvrJ = string("EVIfPqRDSLmlXWhSUJMcnVrauouaBEgYCeGdNKVnaFqytmubmdtklXxsoEbc");
    string PfLxeW = string("RfAZpgrXIufrnlKKousOijIz");
    int wKbyff = 1427124997;
    bool mEVGccQT = false;
    int eRSjJ = 1802914816;
    string cGfXILEZAiVgUsCC = string("wxbhuORlzIhJqTWqBGFjvcHKTdwPvOjmfJSZtrZkskxUprZETpgLOSSmfZNmlOFklKjtmFyrxbytnwlmlIdCixJVArdsXWlTZPkHecGgQLHVkGlQDLcbAMUEcziwZtTyWIynETHJJNNpcRzAMxMlSMNMISveSdbxXeHUnabVJhpoYIhaPNcSFkUZzLbbEitIQctAaAFfbTSJKpYemenYUhGEIxcJmdKfRiVKMiFuxYsUPbEOYexamtxXMxghVi");

    if (eRSjJ > 1427124997) {
        for (int KDklKREERJpJs = 540882668; KDklKREERJpJs > 0; KDklKREERJpJs--) {
            cGfXILEZAiVgUsCC = PfLxeW;
            cGfXILEZAiVgUsCC += cGfXILEZAiVgUsCC;
            eRSjJ = eRSjJ;
            mEVGccQT = mEVGccQT;
        }
    }

    if (OaXAUrWQs >= 979995.9093644826) {
        for (int MvDVGBwpLRsG = 1253313748; MvDVGBwpLRsG > 0; MvDVGBwpLRsG--) {
            OaXAUrWQs = OaXAUrWQs;
            RmCgMcQXTUILvrJ += PfLxeW;
        }
    }

    return eRSjJ;
}

string RipzngE::MLzwGQkB(bool BPNyd)
{
    string zpXYiPOMF = string("owttMwAbKDVzcVThjWxsGhEedBEyVACGobBowESKsFicWPQGitEtBUhAkSOBExbVZAA");
    int wDQCmta = -1146698006;
    double QEUMssAOvXmr = -1021546.4779469016;
    string yNJYsMi = string("UqDfgGYMxYosEVxcYBernyHMQxJfjZoNGnpNCvUoomoBQbhytAnIotByzCGhoeZFwYopThDTRobCGhKCPRGQKhKyoEiLsgLQuElALzQeNhvGjRvCaRFHrQMgKQDLynzcAjEvmnPzMCpVGfxRbCbCHPKTFiiySrcGAkJoqxeqpWpsAJXjzBMJqZnbLgOvlywnuRBddZkJznIHKQXNje");
    string JxMDuW = string("jgzWzshJnfqYtyfUlJUcbLaAokpGJFxvibvrwXXnSWCPxjRZjyMnvVnQVLoJDSnNWLcymqIvkCUphuKCtmSxPMXWakjEgKricjBnZAgTgptZHHibmepADGIyLhHBXCLIvaCBGqNoIHwuJgyWYDUvmVfoyvpvAuKZIpStFL");
    double jKOJDwRbQFLuDKf = -50408.47736516965;
    bool DJIZMCLO = true;
    int loiXVPisMchwd = 2028007835;
    bool BDtWhbfRvhqnuSbc = false;
    int zUWZZnrJOSZ = 1817550177;

    for (int QjEFdrCDbC = 1867681993; QjEFdrCDbC > 0; QjEFdrCDbC--) {
        BDtWhbfRvhqnuSbc = ! BDtWhbfRvhqnuSbc;
        DJIZMCLO = BDtWhbfRvhqnuSbc;
        BPNyd = ! DJIZMCLO;
    }

    for (int NJSaASyXjrGQwK = 2091147126; NJSaASyXjrGQwK > 0; NJSaASyXjrGQwK--) {
        JxMDuW = yNJYsMi;
        wDQCmta += wDQCmta;
        DJIZMCLO = BPNyd;
    }

    for (int EedOWIJeuHXYloIU = 2122447006; EedOWIJeuHXYloIU > 0; EedOWIJeuHXYloIU--) {
        BDtWhbfRvhqnuSbc = ! BPNyd;
        loiXVPisMchwd /= wDQCmta;
    }

    return JxMDuW;
}

bool RipzngE::wpsLZIIMT(bool vOOiCRDwAMRqlIY)
{
    double fQuBNJKmn = -504893.49055816827;
    double vnkeHAmi = -446867.1272204385;

    if (vnkeHAmi > -504893.49055816827) {
        for (int OZcIKm = 368477324; OZcIKm > 0; OZcIKm--) {
            vnkeHAmi -= vnkeHAmi;
            vOOiCRDwAMRqlIY = ! vOOiCRDwAMRqlIY;
            fQuBNJKmn = vnkeHAmi;
        }
    }

    return vOOiCRDwAMRqlIY;
}

bool RipzngE::hoMmwcr(int KeLhd, bool XrlDfErD, bool QeypewxJcM, int VoLyGVxpkmf)
{
    double zyRDPpapENhMn = 759061.2778540766;
    string qvEOS = string("XuQtGoNxQPhZeNjVFcNXcfsoXUEyTNqhbjAJEFcmAtUTQtKciMJdkgdOJMyvxbOWdLPoCgRovQiydXAtvVRRUnVvOjljOMqeubbMERhPPDaGynsP");
    string bqUQXSXgJ = string("AUrvzAhXNlcxKKafwZxKcUVsCWrnJReXhLIBWrhjCJWYlrHJsKCqNUQQVXvWhfOjTZIYqrPOzuczsBmBIVgJyUorXWFLoHfaIHzfSXvdzhwFZzUlSCZVbvsyfYLQYtTUZUGEBisVn");
    int WRGMUzlMkP = 2089566835;

    for (int eafiNpAujhVgRfBv = 957024339; eafiNpAujhVgRfBv > 0; eafiNpAujhVgRfBv--) {
        continue;
    }

    for (int jccujiCepyAhtBXu = 749092978; jccujiCepyAhtBXu > 0; jccujiCepyAhtBXu--) {
        bqUQXSXgJ += qvEOS;
    }

    for (int SHRlLOtBN = 1156730293; SHRlLOtBN > 0; SHRlLOtBN--) {
        WRGMUzlMkP = KeLhd;
        VoLyGVxpkmf *= KeLhd;
        VoLyGVxpkmf = VoLyGVxpkmf;
        bqUQXSXgJ = bqUQXSXgJ;
    }

    return QeypewxJcM;
}

RipzngE::RipzngE()
{
    this->GPovWP(string("QuPahSNdcERVhnFsbMUOj"), false, false, -87274.59069843442);
    this->olTWDrL(false, false, -914537673);
    this->AfbWujKLqghSyul(228026971, 1852362733, false);
    this->smQaFYSNG(-540029.8800360993);
    this->vDMMkujenyH(-1510050635, -173890.3267184505, true, false);
    this->bMklVEpULKLm(string("rzdqqjKwwMBKkclMmnboxenmdsjPIhucRhuibVVqsuOcRaRHKTJaUphVLztOwUQCRBxATbdxONdohqXrcvbbsUxPKPxsLqXqzEWMaijQkcjyQrsAKcNdoaISZKBFsoFxJIjbpxuKZ"), 282133.5671336203, -1604762519, string("iXCJAuTlcXnczsePLwolWDMkyBHdnRxedzskdhmVkIadjLDhO"), -2055261651);
    this->BYgRqCXI();
    this->WucbAFkLqYKqxWx(true, true, -235472.32904356462, string("ZtfgiwQhCECfRzNvKBfCyQeaoAJWn"));
    this->SPWxuH();
    this->ZSludAh(string("ktRzLnOzpNPRkUweOmZLBwBAWILwMhLsfGqPcdwvNBqyzbnCXmEXBecRfWcqGitxcebUvXElcbvTQlOHXePThsrHMBrIlLzAWBUuGQnGpVRSfzdwbBlBecPtigdwZbdaJQhvCAhqkHp"), 844134368);
    this->WVDAf(false);
    this->ntyZiK(-487828.92448344524, true, false, -408302397);
    this->UDSSVvYfd(-2008658712, true);
    this->uooOBjSeqF(string("zTTydKnVuhmTxdcNIykhEMyWYOHtlgiaWkpjfRUYUXKrZqRVOLgjZFLjuBletdRTuanfVpIBVjBNxYgOfeHLDMVtpyFvscxnbandLrfLgRvFDxauEUCcOesbrtsasJyUcGnZfLRyvyegtMumJHIaqOOQSjqohiuRWbmQAqwojpaPegLOZyMeQBpiQUXjIhwYuWkhkdoBxxsYIjOepaTAiAlagryhCAWjvCF"));
    this->wZnYyRhaHJEw(632931450, -131883.01819602077, 505773291);
    this->GCcgWCfDlvmylCY(string("wRAnXEbfierRySEEHzKZYHyPXumEcfKHToXSidKTgcRGPQZQLFctJeaJFVDFlCNUDuuNZvoQFkcWnTyIJFljasQqPJoVlWawVHMiQiwgfVSNbItcgWibygoCNgKtdVcIMdYexoAyryWDcqcPRImLOhegGkcPKZHCbtPIghUlYlORZWbepTMOxRbYNEJpusVafPyZXxQhyFNdt"));
    this->SECgVPIBhNcCUojA();
    this->vOAWGux(string("LqyWtyZFkIveoKROylRRRklXAlEXLZFFRbANpsOYsdocBWFVlZWBeqxIOJnIPCvnjjJWLFfHtTysFnWGyBZWKOPUblHwDvaxTQlCwvvICgaKatWCFyxveEpcAE"));
    this->MLzwGQkB(false);
    this->wpsLZIIMT(false);
    this->hoMmwcr(1697722160, true, false, -1556909316);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qQChdiaahcnuQPeF
{
public:
    string njNvAVZoDiDrmmwP;

    qQChdiaahcnuQPeF();
protected:
    string OkghFmNo;
    bool RUasKdiAq;
    bool yVDfVhvKncUADo;
    double xvgCsfvqIuYzu;

    bool rDQlMB(bool NrqNM);
    void xueHvdWCrPV(bool yuFLwFfu, string uJoLW, string CasuFOi, int VTDglWMsqE, bool vgPDwtsXtLwPwfaM);
    double PfYXrxiqEoVGoM(bool WLAmx, double pOHWFWmF, double pedgQkV);
    void sEBiQJjIdeSWCc(string HAVWBIrWVMnk);
    bool WpEnVWxET(string lSIAfgKYzlOVO, string dShVMtrCytqeXYMx);
private:
    double tBDNxfE;
    string wJfTNwJq;

};

bool qQChdiaahcnuQPeF::rDQlMB(bool NrqNM)
{
    double OPdsK = -641954.2453647546;
    double mtEhOwidr = -746315.0879365555;
    bool lmhztASO = false;
    string GhSFB = string("DCWwgKjscYQsrOchxWgmqAFKNjHdIMvMFFrGLjnPguxCmbSVoMATiAZagajivddzFcdAlfaxaJwkUpEbyMmSlARXg");
    double DQUvENnAOm = -521453.02986745455;
    double MllPx = -1007329.2529902509;
    int gQnEvNGNt = -1907160000;

    for (int bhqCqwnF = 1698933126; bhqCqwnF > 0; bhqCqwnF--) {
        mtEhOwidr = OPdsK;
        gQnEvNGNt = gQnEvNGNt;
        mtEhOwidr = MllPx;
    }

    for (int ZRVJblLjmQ = 1275411431; ZRVJblLjmQ > 0; ZRVJblLjmQ--) {
        MllPx = MllPx;
        MllPx = OPdsK;
        DQUvENnAOm += OPdsK;
    }

    for (int gPmncsAKqtx = 1923512287; gPmncsAKqtx > 0; gPmncsAKqtx--) {
        OPdsK += OPdsK;
        OPdsK -= OPdsK;
    }

    return lmhztASO;
}

void qQChdiaahcnuQPeF::xueHvdWCrPV(bool yuFLwFfu, string uJoLW, string CasuFOi, int VTDglWMsqE, bool vgPDwtsXtLwPwfaM)
{
    double jNkZGLWaMpWZ = -922244.156858825;

    for (int COKqY = 1705515575; COKqY > 0; COKqY--) {
        yuFLwFfu = ! yuFLwFfu;
        VTDglWMsqE -= VTDglWMsqE;
    }

    for (int edSfZKOsz = 121234207; edSfZKOsz > 0; edSfZKOsz--) {
        VTDglWMsqE += VTDglWMsqE;
        yuFLwFfu = yuFLwFfu;
    }
}

double qQChdiaahcnuQPeF::PfYXrxiqEoVGoM(bool WLAmx, double pOHWFWmF, double pedgQkV)
{
    double wRaWvFRXeIr = 589012.5408722712;
    int ZcuDW = 580848387;
    string awyPRQetgPdLaI = string("cbVBhBAReiWIFvMHOZLGaXhJdfxarMFlWicXfDbEvAskZGVyFhvGmLfHGYHdVNPTGwsDilpGKxLsyWEmnTAHKzCkzvRZmxLoYQGo");

    for (int fynZqKv = 2035732330; fynZqKv > 0; fynZqKv--) {
        ZcuDW *= ZcuDW;
        pedgQkV = pOHWFWmF;
        wRaWvFRXeIr += pOHWFWmF;
        pedgQkV += pedgQkV;
        pOHWFWmF -= wRaWvFRXeIr;
    }

    return wRaWvFRXeIr;
}

void qQChdiaahcnuQPeF::sEBiQJjIdeSWCc(string HAVWBIrWVMnk)
{
    bool FhKmagHZOPZGhA = true;
    bool dPKXwgNxEw = false;
    string eCYXuneR = string("EkTPpUhUWBenWSuJlfZRzAZqWHgaUBWhUcWtEyhCFBfsTRlCUzrIjSMIwvRXGZFuRyQURXtaUwKOHGnhDZdTjshdYxSXtzGsvhkTWZIYlEScGwtkllttmLTBBdRAxiYaMoRnVSOSgAfnTDXWCEnQAOajLynriprNNwZWROCCIxmQePaZFPEMspKTiKDWBqeKjMTyGivSlUhThHltUOtJIRKTqpwKlfJFQWZKQ");
    int CSuqztPdziE = 353735561;
    bool RudiBIpmKcTz = false;

    for (int vGdGolStfaRD = 658850607; vGdGolStfaRD > 0; vGdGolStfaRD--) {
        RudiBIpmKcTz = RudiBIpmKcTz;
        FhKmagHZOPZGhA = ! RudiBIpmKcTz;
        RudiBIpmKcTz = ! dPKXwgNxEw;
    }

    for (int nvkil = 1520583377; nvkil > 0; nvkil--) {
        RudiBIpmKcTz = ! RudiBIpmKcTz;
        HAVWBIrWVMnk += eCYXuneR;
        RudiBIpmKcTz = ! FhKmagHZOPZGhA;
    }

    for (int apbiIbFqrqfdvsm = 1727226226; apbiIbFqrqfdvsm > 0; apbiIbFqrqfdvsm--) {
        dPKXwgNxEw = dPKXwgNxEw;
        eCYXuneR += HAVWBIrWVMnk;
        dPKXwgNxEw = ! RudiBIpmKcTz;
        FhKmagHZOPZGhA = FhKmagHZOPZGhA;
        RudiBIpmKcTz = RudiBIpmKcTz;
        dPKXwgNxEw = RudiBIpmKcTz;
    }

    for (int FQewqg = 476964952; FQewqg > 0; FQewqg--) {
        RudiBIpmKcTz = ! RudiBIpmKcTz;
        CSuqztPdziE *= CSuqztPdziE;
        eCYXuneR = HAVWBIrWVMnk;
        CSuqztPdziE *= CSuqztPdziE;
        dPKXwgNxEw = ! FhKmagHZOPZGhA;
    }

    for (int owHuJBdYXXXJZu = 824216693; owHuJBdYXXXJZu > 0; owHuJBdYXXXJZu--) {
        FhKmagHZOPZGhA = FhKmagHZOPZGhA;
        HAVWBIrWVMnk += eCYXuneR;
        eCYXuneR = eCYXuneR;
        eCYXuneR += eCYXuneR;
        FhKmagHZOPZGhA = FhKmagHZOPZGhA;
        eCYXuneR = HAVWBIrWVMnk;
    }
}

bool qQChdiaahcnuQPeF::WpEnVWxET(string lSIAfgKYzlOVO, string dShVMtrCytqeXYMx)
{
    bool fcPomAAHhSDEIOBZ = false;
    double HnSxUGHVpGtXzu = -653015.9083526066;
    bool KWKgDsvBvew = false;

    if (HnSxUGHVpGtXzu >= -653015.9083526066) {
        for (int rqwKRXdBHKkLA = 1047670279; rqwKRXdBHKkLA > 0; rqwKRXdBHKkLA--) {
            continue;
        }
    }

    for (int MnPIVRgSZmr = 695806017; MnPIVRgSZmr > 0; MnPIVRgSZmr--) {
        fcPomAAHhSDEIOBZ = KWKgDsvBvew;
        HnSxUGHVpGtXzu /= HnSxUGHVpGtXzu;
        fcPomAAHhSDEIOBZ = KWKgDsvBvew;
    }

    return KWKgDsvBvew;
}

qQChdiaahcnuQPeF::qQChdiaahcnuQPeF()
{
    this->rDQlMB(false);
    this->xueHvdWCrPV(false, string("wBrIEZIeGTnwpOiaUZSwWGghYWJGeeLYsGNAvZprnuixFoLGSUTQDKCztJggLUVHqpLvCTjtYwmyorOftTcAhLBxnVrKCBASNamNbRgTfQPDWzxwojwDVmtUfzAStckKOlYMTBCflSLztbFhsjJofzjmonsAyPUwYWgYbvtbWVzKffCvxPkZkzsfhDZGSTNFmDsjWoQyFdRySEdPEdkjXoALTICOmSiZ"), string("UcvtRLheWOwioPJcJCIdIxRUxVKvsRRJRBwCdogDqbDkliIcBnbAsXTyPaIRAcTINZqzLJeLQHxbOXAAhaZwJLHrTvO"), -2073190329, false);
    this->PfYXrxiqEoVGoM(false, 1003768.6771885277, -430011.22194993054);
    this->sEBiQJjIdeSWCc(string("cUjjvaaLNeKxVnJzPwSkpsmIgCKaWGqXIuZbmuLlNttVBBieDULwhOJjldSOVwSiobYPesUWLzETnVrLTukIcKOsrCHkuf"));
    this->WpEnVWxET(string("UjwBgWHAPeslvrJpTDyaamTWydoAvKDIEoBZpYgrIGTJOrQdCZQTFVOMTYjbxLOkpAwHifyVezdtPHBdUIPQraCEKVphgryGXpgvVOxnLsTwUQmTcbNgUtJZxZWdQyiVpHUDPXCgzPOSvgPwafMwejiECokxXbpUlUaqIeimlyPukrAbFDGLEzIsEVMuHgOMUWezoVsyhjx"), string("hkFbgIeCWweXlOMdbqNONTjnxKhlsvwbDFbvhcfjglEIrIOORaTjkeWLgWFpmogVtSBOC"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BJQktTuLwRkzgp
{
public:
    int ahKOrMYuyZiO;
    bool qbRGWyF;
    int GgJBXeg;
    bool JoouzmHeEh;

    BJQktTuLwRkzgp();
    double ljsEXq(bool cyVZyXU, double VpRlwNQEvvWkKh, double CMvVquDdQ);
    bool HiEbS();
    int yQxJuoKxYnXMktAU(double eCMuq, double ISVPqhjNE, double NVOBpMziJnpFC);
    string CVWyLRVcTOX(int cdkiOCgsvvtRaW, int gYqOSzrWyz, int hlXre, int obyslYzvxDNocpFZ, string LEBRRySwRuXjF);
    void zFccglvdKLjFYo(bool vtogItrWXaIwRNz, double NedfudN, bool HtTMAaZBIxOToAM, int jeZkhuq, int uOShqPTyy);
protected:
    double yfXveq;
    int tYpdcuiuVqxVGqIH;
    int IrbKAkoBgXQuQLh;
    bool gtqEGotQ;
    string IjehJf;

    double JJTdmimkETeTFy(bool Rraoi, bool pPLEsrvawxfp, bool tOUALLLUZeSnpJ, int lGYAfrQ, double LvgEvM);
    bool hhfJT();
    double yEFxdfdZ(double eDAttGVGMGCpXL);
    void smSHuOepzwZ(bool YyZwP, int IyxPWIRmUgwbZq, double ZDMrkBissjQBgDVw);
    string BIFuVkWPI(int YtMxReIwOa, string qcEjlUjOgWbgVsQv);
    int rSOtuxzIwDfvGCBH(int EWVFzSxhiiG, double QbgOiJx, int mMEOLA, string yyWSSGyj, string nDDMpmwtjL);
private:
    double zVfNwYLX;
    int QulKVeqGf;
    double hLZfrcwMpIa;
    bool clJFhIUCNlvJ;
    string ZglBZDIRljRcuG;

    double wUTidmqKrHA(int FIBuCclwnLQv, double OBeNAlGAknnvrCpO, int LvGVtczyHaETmvN);
    string MuEKgxNyteg(string zjdlBa);
    double HYJMditVWOUlwX();
    string VUOPCdJjkI(bool xbapIHtrqPbBXJB, int kaXtw, int bwBavLBB);
};

double BJQktTuLwRkzgp::ljsEXq(bool cyVZyXU, double VpRlwNQEvvWkKh, double CMvVquDdQ)
{
    double hsJMXpwnMsZ = -351786.75436812884;
    int zPcTwEwN = -72870679;
    string HyCraPxU = string("TkhHwoymjmgoQJDybbByrfitQUCOZygMcIeanugBASwkLIkasjhspbsaRJbDAdTZiyvEuVYKEKiexOardZwWnAsWHAfwsCNJgsIbDUGSLuaLgRKxJofPbOHtVqvqgLROAvVkEqgsbVRanlXh");
    string SMDXDozZONr = string("qhVZpSFoRCFJPzahLJkCzPIMkVHtpjeYKFUkYUBJHrjvqWADbcHnrsjTKLzNAOSvIsdsXRqycsqYGxkhWUkYEDMdjqmYgARPDVBMfEdfjEhRWGBvcziMhtAtnAFmSvKmbXqGpdQYuAFQBKzuqqOjeyoWSpheWYFHfUQpJHcLlzghlSDBgHYTsUwKfFgBAnwBUBAszZNTgKAmKQcaJnNPzuPwRc");
    string DOtKrn = string("jsuEcZSflDYRcpvwsooVXmfZvzWKxGKXlFHqFHsGMkrqrkCXgZzGRQSblIfhzRbJitYwzCAFdfImfjUJAUfTlJSgwqLnMYrCEiMmnnlTIHwFCTEajPkrShGZxsjvCJTxhBKyulwOsnRDGbxhpbFMtyhFHzBkRzcvceYPofGNyBlNyUiTNF");
    string RAGOrHtzcY = string("supwxedbbyuByBKQfSEHZSkZmHlfcoBoGeFxgsSvEKXqQDjfqCfYzUAVlWNTORVWvICJdgqdTdMLIAgJEWroIuQjMteheSeDrJvMxaofCpvbEGmOpTUbXdkRskYVowifbybfKbqzGzBoCQMquPSyfTHcUnPoIhYcUIhWaRmPBBIUpVLYJHXxWtsGXzDCGObXz");
    string iBArhaVLHVbYODMP = string("MeKrGFdhLMzCRFKAYrcPYtCdCFhcOFszTiIURZOSAvzzVlgyiCjEbSROMMizEgbLBLQsHfaduAgAWLcmRgrItfOqpXanhiVsxtdnnXxVGISsWEdDFRMogVkMSRQnPvItqHbSIqQAJJjKHnGfLYZGHoHKPvBJzwntVyPWwISGchjX");
    bool ImrmWZtN = true;
    int UoHqBe = -1720879983;

    if (HyCraPxU > string("supwxedbbyuByBKQfSEHZSkZmHlfcoBoGeFxgsSvEKXqQDjfqCfYzUAVlWNTORVWvICJdgqdTdMLIAgJEWroIuQjMteheSeDrJvMxaofCpvbEGmOpTUbXdkRskYVowifbybfKbqzGzBoCQMquPSyfTHcUnPoIhYcUIhWaRmPBBIUpVLYJHXxWtsGXzDCGObXz")) {
        for (int rkMCeRMiJc = 1857283308; rkMCeRMiJc > 0; rkMCeRMiJc--) {
            CMvVquDdQ += VpRlwNQEvvWkKh;
            HyCraPxU += DOtKrn;
        }
    }

    for (int BDRBWQHtCX = 1113152549; BDRBWQHtCX > 0; BDRBWQHtCX--) {
        continue;
    }

    for (int VpuEGpK = 1084206200; VpuEGpK > 0; VpuEGpK--) {
        RAGOrHtzcY += HyCraPxU;
        cyVZyXU = ! ImrmWZtN;
        iBArhaVLHVbYODMP = SMDXDozZONr;
        SMDXDozZONr += HyCraPxU;
        VpRlwNQEvvWkKh -= VpRlwNQEvvWkKh;
    }

    return hsJMXpwnMsZ;
}

bool BJQktTuLwRkzgp::HiEbS()
{
    int fTYUCDxgTzW = 26337712;
    string xZVvXUBN = string("iGI");
    string NJxCBCKYIAccVcIp = string("VvQpWqmlPJZnlBXZCVspIKzCMrBYEbIjnpueWAOVAKVNpvGqDblzqTBbLhCeDGocYKRxHkXCduIiShObPLvsvvKktXWgmpaVyXLxTWEyHYCzaydeEajeNyJEipNYTipTqZANoudVuVJxDT");
    double iXMvHUAsSBD = -983729.9733724514;

    for (int FJaulzQLkIUF = 1839291930; FJaulzQLkIUF > 0; FJaulzQLkIUF--) {
        xZVvXUBN += NJxCBCKYIAccVcIp;
    }

    for (int CGEJiuLGNxXs = 985031728; CGEJiuLGNxXs > 0; CGEJiuLGNxXs--) {
        NJxCBCKYIAccVcIp = xZVvXUBN;
        xZVvXUBN += xZVvXUBN;
        iXMvHUAsSBD += iXMvHUAsSBD;
    }

    return false;
}

int BJQktTuLwRkzgp::yQxJuoKxYnXMktAU(double eCMuq, double ISVPqhjNE, double NVOBpMziJnpFC)
{
    int iyZNOshMyjcHu = 2126608786;

    if (eCMuq != -997241.5130482903) {
        for (int fAxfBGggHl = 376999952; fAxfBGggHl > 0; fAxfBGggHl--) {
            NVOBpMziJnpFC *= ISVPqhjNE;
        }
    }

    return iyZNOshMyjcHu;
}

string BJQktTuLwRkzgp::CVWyLRVcTOX(int cdkiOCgsvvtRaW, int gYqOSzrWyz, int hlXre, int obyslYzvxDNocpFZ, string LEBRRySwRuXjF)
{
    int xPSeMYYZAgYstB = 2014493338;
    double ZKGWsPT = -708828.2043211799;
    bool FrhJrSJIlFxwg = true;
    string MskeMqCNGAKl = string("qfFnogCptOCPpIVVqoKHEtVhlHeeXaZSrEIzkJxDwsTjMIuIjGvVcWwutyiJIVCKQ");
    int txGbtEvFFfPoXmo = -1020317326;
    int ioDIoAjqjhKVYg = -2108858538;
    double KESEkr = 156475.77434113377;
    string jOqBsrbyNF = string("UTK");
    int uJgSARqlOrDh = -359399833;

    for (int FDBrNLamtSL = 359659761; FDBrNLamtSL > 0; FDBrNLamtSL--) {
        LEBRRySwRuXjF = MskeMqCNGAKl;
        uJgSARqlOrDh *= uJgSARqlOrDh;
        cdkiOCgsvvtRaW *= hlXre;
        LEBRRySwRuXjF = MskeMqCNGAKl;
    }

    if (uJgSARqlOrDh == -359399833) {
        for (int bLezMuwIydSVeR = 1230761842; bLezMuwIydSVeR > 0; bLezMuwIydSVeR--) {
            xPSeMYYZAgYstB = txGbtEvFFfPoXmo;
            gYqOSzrWyz += obyslYzvxDNocpFZ;
            obyslYzvxDNocpFZ += gYqOSzrWyz;
        }
    }

    for (int rLihV = 594437177; rLihV > 0; rLihV--) {
        continue;
    }

    for (int MQRart = 1398083741; MQRart > 0; MQRart--) {
        ioDIoAjqjhKVYg *= obyslYzvxDNocpFZ;
        gYqOSzrWyz *= uJgSARqlOrDh;
    }

    for (int RxzInxzosi = 1366787743; RxzInxzosi > 0; RxzInxzosi--) {
        txGbtEvFFfPoXmo -= xPSeMYYZAgYstB;
        gYqOSzrWyz /= xPSeMYYZAgYstB;
    }

    if (cdkiOCgsvvtRaW < -1020317326) {
        for (int duUYcN = 537970202; duUYcN > 0; duUYcN--) {
            hlXre /= ioDIoAjqjhKVYg;
            hlXre *= cdkiOCgsvvtRaW;
            txGbtEvFFfPoXmo = uJgSARqlOrDh;
            jOqBsrbyNF += LEBRRySwRuXjF;
        }
    }

    return jOqBsrbyNF;
}

void BJQktTuLwRkzgp::zFccglvdKLjFYo(bool vtogItrWXaIwRNz, double NedfudN, bool HtTMAaZBIxOToAM, int jeZkhuq, int uOShqPTyy)
{
    bool yTEkagIJgAtc = false;
    int gsYVBu = -438965279;
    bool OmCuePCOEOri = true;

    if (gsYVBu < -1214390889) {
        for (int fqeNdqmwEKnDV = 561674036; fqeNdqmwEKnDV > 0; fqeNdqmwEKnDV--) {
            yTEkagIJgAtc = OmCuePCOEOri;
        }
    }

    for (int QcXvqvplebGQ = 313554979; QcXvqvplebGQ > 0; QcXvqvplebGQ--) {
        yTEkagIJgAtc = ! yTEkagIJgAtc;
        HtTMAaZBIxOToAM = yTEkagIJgAtc;
    }

    if (vtogItrWXaIwRNz != false) {
        for (int MGyVfYVWOqBJV = 201578698; MGyVfYVWOqBJV > 0; MGyVfYVWOqBJV--) {
            gsYVBu = jeZkhuq;
            OmCuePCOEOri = ! OmCuePCOEOri;
            HtTMAaZBIxOToAM = HtTMAaZBIxOToAM;
            vtogItrWXaIwRNz = vtogItrWXaIwRNz;
            vtogItrWXaIwRNz = ! HtTMAaZBIxOToAM;
        }
    }
}

double BJQktTuLwRkzgp::JJTdmimkETeTFy(bool Rraoi, bool pPLEsrvawxfp, bool tOUALLLUZeSnpJ, int lGYAfrQ, double LvgEvM)
{
    int KpSpvJRmuGAHdWQS = -445506203;
    bool pTahmxZHshf = false;
    double nBadzS = -96894.00119728614;
    string japtIVr = string("ECSxjAXOTzAMnHyMGpcvXnwCHbRfsFlnRFHoaxaYwKVLKJfBRiFrAyoubPzSGNtPEqkrFuojGwqOdnAkNIsOwJzNduULmlyMrkfMACtumPnLtdPsMLLgvbj");
    bool LAHWlwgPsGubwRi = false;
    double WIkJjojxrIyZVmPc = -658553.3102197953;
    double zWUoLTaLdW = 879407.1475412461;
    string jSlZxJgxXHXUyHIK = string("AemhXVObInVvpfQUUYdJtRbbLsnCybBbRMxBpPposRRvZOdDiDdOUvjRJBRbxQmforcRXdbJbyaQTATuZoVwOkDYxocsKNCiWEIeA");
    bool fRRqsGjSBQX = false;

    for (int XckIkTy = 117690620; XckIkTy > 0; XckIkTy--) {
        WIkJjojxrIyZVmPc = LvgEvM;
        tOUALLLUZeSnpJ = LAHWlwgPsGubwRi;
    }

    for (int zCLYEPgVPA = 1986809444; zCLYEPgVPA > 0; zCLYEPgVPA--) {
        pTahmxZHshf = pTahmxZHshf;
        lGYAfrQ += KpSpvJRmuGAHdWQS;
    }

    if (zWUoLTaLdW == 695121.4809549963) {
        for (int YOyNXqIjCoSAIVKN = 498774918; YOyNXqIjCoSAIVKN > 0; YOyNXqIjCoSAIVKN--) {
            Rraoi = tOUALLLUZeSnpJ;
            zWUoLTaLdW = zWUoLTaLdW;
            WIkJjojxrIyZVmPc *= WIkJjojxrIyZVmPc;
        }
    }

    for (int tjldtTAjwytaYCwE = 190281399; tjldtTAjwytaYCwE > 0; tjldtTAjwytaYCwE--) {
        pPLEsrvawxfp = ! fRRqsGjSBQX;
        Rraoi = ! pTahmxZHshf;
        lGYAfrQ = lGYAfrQ;
    }

    return zWUoLTaLdW;
}

bool BJQktTuLwRkzgp::hhfJT()
{
    double aIPIvgrzEASMM = -494048.1779366422;
    int GnUZzaE = -1313986139;
    double ulRCuGpDPzQanln = -998069.3573919699;
    int feNuaJBjwo = -2145940827;
    bool Dhebisw = false;

    for (int znClRoBfULk = 6323030; znClRoBfULk > 0; znClRoBfULk--) {
        continue;
    }

    if (aIPIvgrzEASMM < -998069.3573919699) {
        for (int jvbWtNomNNTuWsEc = 1154208810; jvbWtNomNNTuWsEc > 0; jvbWtNomNNTuWsEc--) {
            GnUZzaE = GnUZzaE;
        }
    }

    if (GnUZzaE == -1313986139) {
        for (int zrieVRCGnvv = 1627611968; zrieVRCGnvv > 0; zrieVRCGnvv--) {
            aIPIvgrzEASMM += aIPIvgrzEASMM;
        }
    }

    return Dhebisw;
}

double BJQktTuLwRkzgp::yEFxdfdZ(double eDAttGVGMGCpXL)
{
    bool WbRGGzxbTCgTwVpJ = false;
    string RvHWJRnACdNzeu = string("TTMGSkNctcTsAcaOYCBoxhjyRIYHJZlofdXsjuivGvdIiCxRfLttAeoppuBNcvRYUjptRrRTGFYeawLwRmOdunP");
    string ZwpXKOXJm = string("ToFyfwABzlbkCOZIZxbdoENGVjoavitcawPUZuoRnyCUxexCdAxLqgZzzOxrTDXaXDsuSLFFkjJsbAsxuDvIXJUKylXGDakMAAHmatBHOBfnEZIYpnRdRbHqKScNqRAPISyBzakuNNvNhvpCYRxfCQBdETeOPAWftoAOyvsgDvoaoDJuLGHWCIgQAIfUMsMdYgojJDCqyDeGl");
    double ixbBP = -413589.4002501223;

    for (int QswiyjBBh = 671544386; QswiyjBBh > 0; QswiyjBBh--) {
        ZwpXKOXJm += RvHWJRnACdNzeu;
    }

    for (int Hbcec = 1280464148; Hbcec > 0; Hbcec--) {
        ixbBP = eDAttGVGMGCpXL;
        WbRGGzxbTCgTwVpJ = ! WbRGGzxbTCgTwVpJ;
        ZwpXKOXJm = RvHWJRnACdNzeu;
        ixbBP *= ixbBP;
        WbRGGzxbTCgTwVpJ = ! WbRGGzxbTCgTwVpJ;
    }

    if (eDAttGVGMGCpXL == -413589.4002501223) {
        for (int RKGmAkYXkKc = 1989353407; RKGmAkYXkKc > 0; RKGmAkYXkKc--) {
            ixbBP = ixbBP;
            ixbBP += eDAttGVGMGCpXL;
            ZwpXKOXJm += RvHWJRnACdNzeu;
            ZwpXKOXJm = RvHWJRnACdNzeu;
        }
    }

    if (eDAttGVGMGCpXL != -502393.33797469066) {
        for (int DvIGyOOm = 1898619248; DvIGyOOm > 0; DvIGyOOm--) {
            ixbBP -= ixbBP;
            ZwpXKOXJm = RvHWJRnACdNzeu;
            ixbBP += ixbBP;
        }
    }

    for (int SWFeHytIutsfto = 1206670567; SWFeHytIutsfto > 0; SWFeHytIutsfto--) {
        continue;
    }

    for (int EHLgieHYdgxOZA = 1521263539; EHLgieHYdgxOZA > 0; EHLgieHYdgxOZA--) {
        ixbBP -= ixbBP;
        eDAttGVGMGCpXL *= ixbBP;
    }

    for (int QVmFEANvuP = 1202724805; QVmFEANvuP > 0; QVmFEANvuP--) {
        eDAttGVGMGCpXL -= eDAttGVGMGCpXL;
        ixbBP += ixbBP;
        WbRGGzxbTCgTwVpJ = WbRGGzxbTCgTwVpJ;
    }

    return ixbBP;
}

void BJQktTuLwRkzgp::smSHuOepzwZ(bool YyZwP, int IyxPWIRmUgwbZq, double ZDMrkBissjQBgDVw)
{
    double PyVaZJgss = 255142.08011155474;
    bool eWsMjHISYlS = true;
    bool rLGSAKHDDNSlu = false;
    double rhYwj = -13507.772784098624;
    int OSGFnXvgjPRIJ = 436797811;
    string XMqKQbphUZigcCb = string("OmvRTlDloitCEvgWIXr");
    int XXmcdWSVSMpeWP = -411263235;

    for (int hUgQhQfsfXMUub = 1862632770; hUgQhQfsfXMUub > 0; hUgQhQfsfXMUub--) {
        IyxPWIRmUgwbZq /= XXmcdWSVSMpeWP;
        eWsMjHISYlS = ! YyZwP;
    }

    for (int XhbJxXeDogPZEA = 720697395; XhbJxXeDogPZEA > 0; XhbJxXeDogPZEA--) {
        continue;
    }

    for (int DTDBLaPxvaNNZ = 754336783; DTDBLaPxvaNNZ > 0; DTDBLaPxvaNNZ--) {
        PyVaZJgss -= PyVaZJgss;
    }

    for (int llgtRsrWbiolkdyP = 1341237669; llgtRsrWbiolkdyP > 0; llgtRsrWbiolkdyP--) {
        rhYwj = PyVaZJgss;
    }

    if (OSGFnXvgjPRIJ != 1921979560) {
        for (int YblejrQM = 1426109493; YblejrQM > 0; YblejrQM--) {
            ZDMrkBissjQBgDVw = rhYwj;
        }
    }
}

string BJQktTuLwRkzgp::BIFuVkWPI(int YtMxReIwOa, string qcEjlUjOgWbgVsQv)
{
    string plxSUBOiwy = string("mAhAYDBQftFuDiIqDmagCutrRtLMygIWRnJGUSPODfJFSnaBhgqWfEsOTysdSaFWSMwsxVrwQONRMnunYyZUjpFhaiGbUZKBHgkJQYIZvmEwDUOFXEUsgzHcwAUNmzAVJgFgvSqbJEVLLRzMMckpYYVqZlfwyHbATmITMxBEhCrzKHqI");
    string oZMsETCMz = string("LQJTYYUKniCmGpMwZOzyPHnwTGUjSBrXHuUxLLzvhOmVjWuTRQwrQDVGajSnlSMNFvavwWlMROy");
    int ZPLnBC = -1858292372;
    bool dXCtycMwfkmtM = false;
    bool docwryjwrrjo = true;
    bool ZvhDEkrVVUiH = false;
    double VjofNkyvg = -990821.3203818547;
    double JryOrnBqLpplsL = -782014.7792565782;
    string erDczKv = string("KDlrdjpjOgOMjBHGSTxTpVdwklEuAsGFwPZueYrpDHgIfFVyTUzQmmCrFMxBDyjXLyFHXMAGMchTyPIekXzbCJMrAdlLbgItCeTDtNUVIiYHeUtWNIsHBsnGSJAcfxCaqwsUBCpPceZnfVUSoWjOcCWTjYgkSfnBhVrQgMgEVqzkIfaRNyBPBgrbqmHMzUweUKDJhczEopSLoZjoqfZYTdpmKHRhJZ");
    double bnVbePTzAqsU = 677236.4713243534;

    for (int RdgrPUTARKoNVLh = 1846938383; RdgrPUTARKoNVLh > 0; RdgrPUTARKoNVLh--) {
        plxSUBOiwy += plxSUBOiwy;
    }

    return erDczKv;
}

int BJQktTuLwRkzgp::rSOtuxzIwDfvGCBH(int EWVFzSxhiiG, double QbgOiJx, int mMEOLA, string yyWSSGyj, string nDDMpmwtjL)
{
    int tZjNmwcFgus = -704945979;
    int niiWXHI = 783662343;
    double ZTykdLT = -463882.761865111;
    bool gvbaKwe = false;
    int iKcFOEQVlTEqnWjN = 551046998;
    bool fTcyt = true;
    int uApmRvpMwsHRsbI = -1215186748;
    string SfeIJIcfyfqFNbb = string("gblkHMSxXQMAJPmqwNhQfPyOGmwITLalrHciIZxSMedQlwvftAFLiXccYJkGikCWkJMzHEagKSNSgKLXhXacqOnBqPbZsoZeBFVaFcnvxwmgipliOWhaOcNiITAGfqg");
    bool SPTzDvdKdnk = false;

    if (mMEOLA <= -1215186748) {
        for (int RioAcAiQnkRabuB = 1156916519; RioAcAiQnkRabuB > 0; RioAcAiQnkRabuB--) {
            niiWXHI = EWVFzSxhiiG;
            iKcFOEQVlTEqnWjN /= iKcFOEQVlTEqnWjN;
            uApmRvpMwsHRsbI /= uApmRvpMwsHRsbI;
        }
    }

    for (int BayUmANcBJa = 1989413961; BayUmANcBJa > 0; BayUmANcBJa--) {
        nDDMpmwtjL = SfeIJIcfyfqFNbb;
    }

    for (int XWxKJ = 698930721; XWxKJ > 0; XWxKJ--) {
        uApmRvpMwsHRsbI = EWVFzSxhiiG;
    }

    if (EWVFzSxhiiG < -704945979) {
        for (int RvUTBnXQkKakg = 1989116001; RvUTBnXQkKakg > 0; RvUTBnXQkKakg--) {
            QbgOiJx += QbgOiJx;
            tZjNmwcFgus = EWVFzSxhiiG;
        }
    }

    for (int CTLpbuSiUzmEAj = 846783498; CTLpbuSiUzmEAj > 0; CTLpbuSiUzmEAj--) {
        mMEOLA = mMEOLA;
    }

    if (iKcFOEQVlTEqnWjN <= 783662343) {
        for (int ffKaRHRfEopCy = 1262790098; ffKaRHRfEopCy > 0; ffKaRHRfEopCy--) {
            uApmRvpMwsHRsbI -= iKcFOEQVlTEqnWjN;
            iKcFOEQVlTEqnWjN = niiWXHI;
        }
    }

    if (tZjNmwcFgus > 1407446170) {
        for (int dshuphwx = 655819495; dshuphwx > 0; dshuphwx--) {
            EWVFzSxhiiG *= EWVFzSxhiiG;
        }
    }

    return uApmRvpMwsHRsbI;
}

double BJQktTuLwRkzgp::wUTidmqKrHA(int FIBuCclwnLQv, double OBeNAlGAknnvrCpO, int LvGVtczyHaETmvN)
{
    bool gPWnklPOioJJnJ = true;
    string VPnUGPyHs = string("GLjsqBqelLaHUhaWIZdFWGejHkXKeqhWyuEPAXLshNfqMMWEMUNPdDtwJRMhciBmffEMgeUgJj");
    double YtDTmdbHJLZ = -759111.3526694172;
    int cdGBXxXfXmtfC = -557285614;
    string fWWeYXZc = string("vGXNMLiTAAlGbFzRkzYMtToRMcmGAjEFkwcxgFcEGeoBHxdBukktNxnQrojGOLecIXxEtxmgfBXzNIuAGTtZHaAyYtTBoJsxzDRROJeTKCGffmCARHImunc");

    for (int ESTjvfUwzh = 1412878403; ESTjvfUwzh > 0; ESTjvfUwzh--) {
        fWWeYXZc += VPnUGPyHs;
    }

    if (FIBuCclwnLQv > -1697499625) {
        for (int vxNjeIYlER = 1201578944; vxNjeIYlER > 0; vxNjeIYlER--) {
            cdGBXxXfXmtfC /= cdGBXxXfXmtfC;
        }
    }

    for (int WnoVDLTjXv = 506710527; WnoVDLTjXv > 0; WnoVDLTjXv--) {
        cdGBXxXfXmtfC = FIBuCclwnLQv;
        OBeNAlGAknnvrCpO -= YtDTmdbHJLZ;
        OBeNAlGAknnvrCpO *= YtDTmdbHJLZ;
        fWWeYXZc = VPnUGPyHs;
    }

    for (int UpEuTTQyEARTyuP = 1632528866; UpEuTTQyEARTyuP > 0; UpEuTTQyEARTyuP--) {
        FIBuCclwnLQv -= cdGBXxXfXmtfC;
        LvGVtczyHaETmvN += cdGBXxXfXmtfC;
    }

    return YtDTmdbHJLZ;
}

string BJQktTuLwRkzgp::MuEKgxNyteg(string zjdlBa)
{
    int RGEaeJzzrUqauR = 1058550342;
    bool qjAXlyooDTj = true;
    double ybsWPGHgbFELGXnZ = 308667.96162603475;
    double IGUCMgb = 406141.2026270938;

    for (int BWhcIQsoeFE = 1869667641; BWhcIQsoeFE > 0; BWhcIQsoeFE--) {
        ybsWPGHgbFELGXnZ *= ybsWPGHgbFELGXnZ;
        ybsWPGHgbFELGXnZ += IGUCMgb;
        ybsWPGHgbFELGXnZ = ybsWPGHgbFELGXnZ;
    }

    for (int uQzCGBIj = 1884067462; uQzCGBIj > 0; uQzCGBIj--) {
        IGUCMgb -= ybsWPGHgbFELGXnZ;
    }

    for (int SCpfWsXcHG = 1534103207; SCpfWsXcHG > 0; SCpfWsXcHG--) {
        RGEaeJzzrUqauR -= RGEaeJzzrUqauR;
    }

    for (int WcttVRb = 1581105002; WcttVRb > 0; WcttVRb--) {
        IGUCMgb -= ybsWPGHgbFELGXnZ;
        ybsWPGHgbFELGXnZ -= IGUCMgb;
    }

    for (int oNIWYLnNaWfe = 1657685035; oNIWYLnNaWfe > 0; oNIWYLnNaWfe--) {
        zjdlBa += zjdlBa;
        zjdlBa = zjdlBa;
        ybsWPGHgbFELGXnZ -= ybsWPGHgbFELGXnZ;
    }

    return zjdlBa;
}

double BJQktTuLwRkzgp::HYJMditVWOUlwX()
{
    int nkXwyC = 644984561;
    double cgMhxrbmkmEvgJ = -457490.77315782337;
    int IecNUZZzlm = -575857910;
    double zemTedDoCZU = -55603.112997836404;
    int sdwUa = -1254794478;
    double mLwYDC = 177211.30042695787;
    string JRMQfHoLGtNxs = string("epUfNQBSgtKnwutDJZRqnXCXqENdWOYMnShQtRPAeFLSAvUcoITBbjcAMBsKpgqptfrMnwgSDVrVjkvaBbmHhDrmVoVEQEcvEurOU");
    bool FWEKmHM = false;
    double ruwIOpyiKgNuJJ = -378542.8342741868;

    for (int GGteo = 2138301619; GGteo > 0; GGteo--) {
        zemTedDoCZU *= zemTedDoCZU;
        sdwUa += sdwUa;
    }

    for (int heMise = 81832035; heMise > 0; heMise--) {
        cgMhxrbmkmEvgJ = zemTedDoCZU;
        JRMQfHoLGtNxs = JRMQfHoLGtNxs;
        IecNUZZzlm = sdwUa;
    }

    if (cgMhxrbmkmEvgJ < -457490.77315782337) {
        for (int zjbYrFXLFm = 151155268; zjbYrFXLFm > 0; zjbYrFXLFm--) {
            nkXwyC /= IecNUZZzlm;
            mLwYDC *= cgMhxrbmkmEvgJ;
        }
    }

    return ruwIOpyiKgNuJJ;
}

string BJQktTuLwRkzgp::VUOPCdJjkI(bool xbapIHtrqPbBXJB, int kaXtw, int bwBavLBB)
{
    int FYkPxGWqqqHBn = 1082251474;
    double FJIpaQOSFgBYHQ = 392667.1815297227;
    bool xNXoRqYx = true;
    bool YbBJoGF = false;
    bool myzbzXqWyZ = true;
    int XODNw = 320694794;
    bool bXSIR = false;
    int FDUYLXwBtkRnc = 1639215921;
    bool zhgubmqPSO = false;

    return string("ckBdsoqPhmwgMFqJzuVCOIBIBDriYLocAnLVmgyKLnlzmbXrJRZSElBqmgxdYPlcjlJzugxHeEnvKNXrurKCSiBuBCtAMjKEeJnsBlcSgnnFXLrTenTTbLsgdZjYYoFrNKIohTknmFaFxrdBuaFrzLdoowwFMUTdIRqoZnbuWGMWn");
}

BJQktTuLwRkzgp::BJQktTuLwRkzgp()
{
    this->ljsEXq(true, -610042.5970065657, 940934.5134088333);
    this->HiEbS();
    this->yQxJuoKxYnXMktAU(-997241.5130482903, 257622.5703835422, 671493.5302713729);
    this->CVWyLRVcTOX(1174725662, 1247199547, -1165263732, -958841832, string("klHMzEXrLBEheverxkiTHjsQbgVRspnUbvsmHhLJicUBNPoexlQvvBMqEoXIklYuAfyIezjndephehEwNfgKmgGkIBsteqHAAOzlwfiDkezPShxyVJInQPHorluVpxnkWWtbVB"));
    this->zFccglvdKLjFYo(false, 561625.7360626436, true, -1214390889, -70036108);
    this->JJTdmimkETeTFy(false, true, false, -1034793206, 695121.4809549963);
    this->hhfJT();
    this->yEFxdfdZ(-502393.33797469066);
    this->smSHuOepzwZ(true, 1921979560, -465110.56907003996);
    this->BIFuVkWPI(1947835820, string("zFQLyFnqkMhaddhHDeCXdBLtikBoJysATfQWeGUtWMnNspBIVsAyVJMFURnBMLeCxKybx"));
    this->rSOtuxzIwDfvGCBH(-575072022, -943136.5751390767, 1407446170, string("mLwwCWnFDsYxMxrkcZkEsPNrdgKrwEGcwTmacjCAHZSEXwZSSGGgTYOhMbXsrLlnDuKqSbqMiqxslSUOrAcXvPmMDwDAZoUbZGiPPcQdbBLneEqWbFwzuSJoHARFTqN"), string("TwxAAWlnTltxyIhoDyzuQUHYMSuahvEpqtiWKeJYWqvenzaPHovwHqWbsYaQwvHZNcEvCrJCAvhaZuZlbyZzbtarkyLSlwliPnlqrFKdGlzaJdnIkkAbfeLpTHSFPkyAcLbtLXuraZJyWaMjnyahWIWOThFzStVG"));
    this->wUTidmqKrHA(-1697499625, -767889.6818834213, 326262095);
    this->MuEKgxNyteg(string("UfzfbGeBDpWrUJaJBnHZlUcnCmcfCSZlrELpxTnmxTkxGTwiXXNbocnrBQTLjDFoKmSQNLESCMDKIyVexZvpwihuMVzXTTuSZhCNQZxOZZWJtJQwslbZLmnYlONVyuhPnwWIZdOvnNUGtfTXJewjxyOZocsfCedRAUjGVMXSzmqZACXguEBOgVpbIHaPefNRJbpPOVhHDHmaKZNYvmEw"));
    this->HYJMditVWOUlwX();
    this->VUOPCdJjkI(false, -1195216567, 72176150);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nmIOK
{
public:
    bool BFAggqRZrZSJU;
    bool RYVcKDtNDvNnpXTm;
    bool HgWDDnkkLrEFV;

    nmIOK();
    double ZpSpuTrOdnJ();
    int JoubAygnRqT(double frpGXmoAtta);
    bool mcXIudlnOz(string CjidolDCrFTVTnc, int ULVgPZIPgHBYzQv);
    bool URpqyxYKOZiWPY(double bHTFvdu, double sjqFfR);
    double iniRbPvTKmCBjoOB(int QiojKJuObiij, string hVNNsqQxz, string PJNyWcHmuoBoSl);
    bool snVMFvS();
protected:
    double lzFLikxn;

    string YjIPOBzNXys(int svbyfEtCs, string bijiZr, double oHMuDrXgif, string mFtMtZSacB);
    int JeEAHTdrWQVYIe(int nwwkKYsi, bool RiKSmeSWSjpka, double ZOAFslDqUkRV);
    string kNzTJaR(int LVBjGBgy, bool NkAKAAjMKlj, double CMObsAafVUhOVI, int wBSDTpAFyuWPFLG);
    bool HsHzeiFHMBDSb(string BymNBFP, int olMaIamBuMTA, int HAafXCedKXeLLd);
private:
    string NNAIguMOEWTiF;

    int OviQWqPXEUsocwJ();
    string gCbCcEEaeuITvRc(double jXjkgDHZfUXJ, string HfvDeLcPEVebTbGQ, int INtFGauTGh, bool sAYXJve);
    void DEUIVeFFeBsVqsvp(double uSCXXTejb, bool jwDmoVHZJMDSpq);
};

double nmIOK::ZpSpuTrOdnJ()
{
    double vymnHnxKxM = 852122.6528223607;
    int yjQwoE = 313573056;
    bool ePAepCyoGBYJavFP = false;
    int GpTyKBluVx = -617521305;
    int RaJCNZXnY = 1481439907;
    bool hyjlUv = true;
    double nlZXwqZXctJwF = -345663.19234279706;
    double fZHDipNvaUrFJA = 212959.3687196062;
    string mwtMAGifyueXZg = string("EngvCmXfMUEmHPwuTXKqWQOZSiFngGqkWkyayWJClXJsUJQ");
    double NFUztGptQoVXmkjj = 848022.8509645496;

    if (nlZXwqZXctJwF >= 212959.3687196062) {
        for (int gqJcsyEuTIQ = 205058237; gqJcsyEuTIQ > 0; gqJcsyEuTIQ--) {
            nlZXwqZXctJwF = vymnHnxKxM;
            RaJCNZXnY += yjQwoE;
            yjQwoE /= RaJCNZXnY;
            yjQwoE -= RaJCNZXnY;
        }
    }

    if (NFUztGptQoVXmkjj < 852122.6528223607) {
        for (int EMSNdPR = 1436765115; EMSNdPR > 0; EMSNdPR--) {
            vymnHnxKxM -= vymnHnxKxM;
            yjQwoE += GpTyKBluVx;
            GpTyKBluVx *= RaJCNZXnY;
            vymnHnxKxM /= vymnHnxKxM;
        }
    }

    for (int SVSlEdwevwoL = 1114587498; SVSlEdwevwoL > 0; SVSlEdwevwoL--) {
        NFUztGptQoVXmkjj -= nlZXwqZXctJwF;
        GpTyKBluVx /= yjQwoE;
    }

    for (int SSoqkcSkN = 1684813319; SSoqkcSkN > 0; SSoqkcSkN--) {
        hyjlUv = ! ePAepCyoGBYJavFP;
    }

    if (nlZXwqZXctJwF <= 852122.6528223607) {
        for (int nXRIJdW = 1055121716; nXRIJdW > 0; nXRIJdW--) {
            ePAepCyoGBYJavFP = ! ePAepCyoGBYJavFP;
        }
    }

    return NFUztGptQoVXmkjj;
}

int nmIOK::JoubAygnRqT(double frpGXmoAtta)
{
    string QNUGt = string("wnZGfNdhPNaRjFYKGwbpmohhRqJWiCQxudCFxZbKwgTnKySsVaIUaeQasxDeBCAGoyOHqlHwBmDxTLisVyihrGSxqFIfJDRhEzLFdfQsMNrMfndOcCSQDHrAKVWcNoiQiPWFyGeQqfoTIdunfWmwvJVwIJOqTeRTbxuZsdIAHibljNSdgOeygGflKqwsP");

    for (int QlfYJGWeSWoYZ = 2192741; QlfYJGWeSWoYZ > 0; QlfYJGWeSWoYZ--) {
        QNUGt = QNUGt;
        frpGXmoAtta = frpGXmoAtta;
    }

    if (frpGXmoAtta < -249154.49849868316) {
        for (int VOwcvAPoNn = 1568887773; VOwcvAPoNn > 0; VOwcvAPoNn--) {
            frpGXmoAtta -= frpGXmoAtta;
            QNUGt += QNUGt;
        }
    }

    if (frpGXmoAtta == -249154.49849868316) {
        for (int bDbsMnFRvDTfuM = 1420106548; bDbsMnFRvDTfuM > 0; bDbsMnFRvDTfuM--) {
            frpGXmoAtta *= frpGXmoAtta;
            frpGXmoAtta = frpGXmoAtta;
            QNUGt += QNUGt;
            frpGXmoAtta *= frpGXmoAtta;
            frpGXmoAtta /= frpGXmoAtta;
            frpGXmoAtta /= frpGXmoAtta;
            QNUGt += QNUGt;
        }
    }

    for (int cCYyAeVIkdNqxqMI = 1623648741; cCYyAeVIkdNqxqMI > 0; cCYyAeVIkdNqxqMI--) {
        QNUGt += QNUGt;
        QNUGt += QNUGt;
    }

    return 560056983;
}

bool nmIOK::mcXIudlnOz(string CjidolDCrFTVTnc, int ULVgPZIPgHBYzQv)
{
    int ysqLxakEP = 1464752649;
    bool kxScswWIkN = true;
    bool lQYcVQdDdyjAdjO = false;
    double MalhBLDokVID = -923063.4674519493;

    for (int evTjdm = 1591589692; evTjdm > 0; evTjdm--) {
        ysqLxakEP *= ULVgPZIPgHBYzQv;
        ysqLxakEP += ULVgPZIPgHBYzQv;
        ULVgPZIPgHBYzQv = ULVgPZIPgHBYzQv;
    }

    if (ULVgPZIPgHBYzQv >= -38922441) {
        for (int VqGXYTmdKIXpkx = 1644906587; VqGXYTmdKIXpkx > 0; VqGXYTmdKIXpkx--) {
            lQYcVQdDdyjAdjO = kxScswWIkN;
        }
    }

    if (kxScswWIkN != true) {
        for (int ESJDUiu = 1262621993; ESJDUiu > 0; ESJDUiu--) {
            ULVgPZIPgHBYzQv = ysqLxakEP;
            MalhBLDokVID /= MalhBLDokVID;
        }
    }

    return lQYcVQdDdyjAdjO;
}

bool nmIOK::URpqyxYKOZiWPY(double bHTFvdu, double sjqFfR)
{
    bool NfODVntt = true;
    string GjpYxzVciYxpP = string("CXplWEGeSYhsfZScoXiaKnvxpdnLxdvgxqfdmxtBiuyhCUZltNMvqlDLSUHoqodqyFhDMeMFqSLrdyDRwHOAXzoseUQtEdUEWeHZrRkixNZjCZbaoPHusacSkU");
    double VpZFtDbGvAceu = -649992.8652756693;
    string cnKRKFF = string("IMmquulbRbqHXXdYMEWFuiVgfVcZwqZrIcgVwaZCAbijOQCsbpqkQSDRnQiDsOOHvLXXrUEWfHlmIPdsxHrNfaPyyVfTeCmDShzZTXQOxwTblkPYIqhpnlcekpgXEsPscxBSCxcZyGmQyanapYQoQAYSKbOYZCgKtxzcCjLfJxOESZUuZICzshzJZlxetOXwuvRJIZoDQBPl");
    bool isIDL = true;
    bool mCekKZnkBIWET = true;
    double dUewUu = -814139.6447753069;
    string wVgTlSRE = string("ICqDUzLMqQelmRQMtcApJpymfeOBhuhoCDUceywAaiAKdYnrekbyFjGMJMExvbUEKQqQmbJmOWTcJqKncmFrygFbSfsDNuilNnvcWilXIqA");
    bool fohVhcNIsGRH = true;

    if (VpZFtDbGvAceu <= -649992.8652756693) {
        for (int WzuzsMD = 1570694787; WzuzsMD > 0; WzuzsMD--) {
            mCekKZnkBIWET = NfODVntt;
            dUewUu += bHTFvdu;
            VpZFtDbGvAceu *= bHTFvdu;
        }
    }

    if (isIDL != true) {
        for (int CtGzBYJa = 1895223759; CtGzBYJa > 0; CtGzBYJa--) {
            continue;
        }
    }

    for (int olhpMqhwSr = 1732423273; olhpMqhwSr > 0; olhpMqhwSr--) {
        continue;
    }

    return fohVhcNIsGRH;
}

double nmIOK::iniRbPvTKmCBjoOB(int QiojKJuObiij, string hVNNsqQxz, string PJNyWcHmuoBoSl)
{
    bool aZfUWGracTeDR = false;
    string osbKVDdNfYk = string("XqDumCpdNlkNEvYiSXnsnqQgCZi");
    string gpWgHhmfUsnT = string("peuxnfQMohkMMXWldgEvUAVHzmxXCqdXJKuEVpdVEXUAdPVnxzEcEJPbiksxpDMJyNCPxNMsGQohXynWiIFWhcCBiPofTWjCbuB");
    string YimGYyKtMBM = string("QRFYhNIzbsFwEFFbBkwCUUTJQngritZBpqMWTNamHmKueU");
    double NUoSynsJ = -327730.3690123995;
    int JChWwcQYylBTa = -286435783;

    if (hVNNsqQxz >= string("XqDumCpdNlkNEvYiSXnsnqQgCZi")) {
        for (int SxKYwYVqOYVd = 1688805697; SxKYwYVqOYVd > 0; SxKYwYVqOYVd--) {
            aZfUWGracTeDR = aZfUWGracTeDR;
            PJNyWcHmuoBoSl += gpWgHhmfUsnT;
            hVNNsqQxz += gpWgHhmfUsnT;
        }
    }

    for (int dtYTnWOnKwy = 1527635743; dtYTnWOnKwy > 0; dtYTnWOnKwy--) {
        gpWgHhmfUsnT = PJNyWcHmuoBoSl;
    }

    if (hVNNsqQxz <= string("xwZwYMLthlGHOSYjRDDUVjkvldikeqAtqnDlMYmHZjzlTuDuLsftWaMKJQVCPGoYWUvgOJVKjqGMlmBgZQxMMqLQhtDALwrTQsfXiFZaBaNirLLBRKgfsVIJKRshPhDeqpIyuVwYTRoGfBEAjxIQwNiGDCMHRKlqXmvgWvRBRveVSPOatpyDqbuhlnwnEbMAVD")) {
        for (int VTJEPXsoSart = 55967417; VTJEPXsoSart > 0; VTJEPXsoSart--) {
            hVNNsqQxz += YimGYyKtMBM;
            PJNyWcHmuoBoSl += YimGYyKtMBM;
            NUoSynsJ = NUoSynsJ;
        }
    }

    if (YimGYyKtMBM >= string("peuxnfQMohkMMXWldgEvUAVHzmxXCqdXJKuEVpdVEXUAdPVnxzEcEJPbiksxpDMJyNCPxNMsGQohXynWiIFWhcCBiPofTWjCbuB")) {
        for (int fzQqurLBdtcz = 511275197; fzQqurLBdtcz > 0; fzQqurLBdtcz--) {
            YimGYyKtMBM = hVNNsqQxz;
        }
    }

    return NUoSynsJ;
}

bool nmIOK::snVMFvS()
{
    string zbPwdrvptELJRd = string("gddtVWUkFxqCQUwcfmjWazPebZAnNNozuFsJXAXJIgcTGPBSykciZwPWwjYCCnCPqQSCZCeLO");
    string vUulc = string("WcxFdIxCMnOpqzjBukqGJjDYAXZCDERyyLaYLIJfsuHPEUdJnvcDLImibESycGWUhnFocVqEozgIjNiCexCxRRuYdmivIWkLRhPZcrXDSPoCRChPUOHMwlGisANSwGVxVxympQmTodNpzLSZvRffHBPdnnIamFAmffZfNAcwywDhWlJrTmBZfgELOAflqcFQwkqPSxcqt");
    double UNWZMy = 891518.7819798754;
    bool ESRLNWcadlcZyaVm = false;
    int spjHhoQNPT = -770081057;
    double BVYpBKsveS = 875793.0585683477;
    int ajQKVbBxUhY = 746692429;
    string fYbzTdGGEYZomvP = string("SROqVewiJeYSDPRkFrddUCGzqXGpfgFLntdRdVesiquIqAychkBEdwhjvzGflUBBDXOPfzZxbFyirdiHiACaxiURUqQPacjobbyqiQHSuQxYGmaKkmhpHTNFoTsWWFHDcmCzlGpzfiGmOYCJPLhoQaIbTViFDipagGuAHoZ");
    string JKsUzaWwaMEQ = string("GuxgFWl");
    string ojmfIDht = string("YutsslkugIxPyZzPbVFlXtAfAhCuxRpqfmaEtqBJaSnGxIGCDxrvFazecvPUhQYeHmPQymcJmfASRWIzugHfdSmRSbVuMxHDucPbeThxBBShivmAShCLcostWWkvRrBgnFOg");

    if (ojmfIDht >= string("gddtVWUkFxqCQUwcfmjWazPebZAnNNozuFsJXAXJIgcTGPBSykciZwPWwjYCCnCPqQSCZCeLO")) {
        for (int qoOeRKENbSaitR = 937307261; qoOeRKENbSaitR > 0; qoOeRKENbSaitR--) {
            continue;
        }
    }

    if (BVYpBKsveS <= 891518.7819798754) {
        for (int FSFvOppLkjYFEW = 1048782968; FSFvOppLkjYFEW > 0; FSFvOppLkjYFEW--) {
            ajQKVbBxUhY = ajQKVbBxUhY;
        }
    }

    for (int niRozz = 245670028; niRozz > 0; niRozz--) {
        JKsUzaWwaMEQ = zbPwdrvptELJRd;
    }

    return ESRLNWcadlcZyaVm;
}

string nmIOK::YjIPOBzNXys(int svbyfEtCs, string bijiZr, double oHMuDrXgif, string mFtMtZSacB)
{
    int BDflQmpSEfuERzba = -1947990320;
    bool EisalpNiNxNmxa = true;
    double rWtZZwGUnlq = -157803.39410449323;
    string pUcfNwhZqKtUQ = string("aKFqOkDRgqfhyEppwWdeZMZiIIzjKhMXiVjtzZOnzcaItoIHdbQOCRfvBuWBimEJhcMzSNglodBtITsqKjeLnFBlWBWZesxrlPViPrxJtSSrzEiGGxywpLW");
    string cYlQGp = string("wJcpMGGkvfJxzSUdZxhnPjIViSlLREMWauIakfsBGACveFUKGtnItjJkYgbWznwmJrDvNXMRQTrayAsy");
    double pzXSZDUfv = 290116.675701451;

    for (int enHLSJCTTdPk = 695616889; enHLSJCTTdPk > 0; enHLSJCTTdPk--) {
        bijiZr += cYlQGp;
    }

    for (int QMBZapDUg = 409206128; QMBZapDUg > 0; QMBZapDUg--) {
        mFtMtZSacB = mFtMtZSacB;
    }

    for (int sGPqrO = 1314993058; sGPqrO > 0; sGPqrO--) {
        continue;
    }

    return cYlQGp;
}

int nmIOK::JeEAHTdrWQVYIe(int nwwkKYsi, bool RiKSmeSWSjpka, double ZOAFslDqUkRV)
{
    double EHTxIgTNikQKCbyL = 338331.0780134675;
    bool QeYprjK = false;
    int hyoVfet = -1201828744;
    string HdZXxGPRuDpUwgg = string("SaEUqWBkAdumuFOqrNvefMnbXZhzyXRmLqLIqafgOKfKVGGGbEMuISEiZCTzQfzGkXFBYJjXrUvnBlCXAlJGUKJfrOzuCAYDUGLeQSFGQKMxukhNPJDipoeqAievOQMApFIDjgrKQyHRidmXNKvcjVzCyfQfWlxcNtHqBXWlNUunwFFmEzHjZdQYYLgJENHYDkDQsVEhfclVWs");
    bool RQxQBPlC = true;
    int XQWIqvN = -1653961570;

    return XQWIqvN;
}

string nmIOK::kNzTJaR(int LVBjGBgy, bool NkAKAAjMKlj, double CMObsAafVUhOVI, int wBSDTpAFyuWPFLG)
{
    string GaXCHPWe = string("BXmuJSoXztZumdBALRoDtcxhUZBsIGFBNIOhNEYFyxymfik");
    string vpKVICZx = string("UZWocWsfTHFVOpbILxUHQXkkXzCYCansCEplovlwOkWokxT");
    string khZyQBkonAhhQQN = string("XeMzYhLwqEXsIhdXjErcjoLKGINqVkIURMQlQkDurJNujrilrdrIbRySvAnipSNSYSIvcCVXSViizyqryzgrNTDjPnsnfTOWknfxAojkXzYrLzpGBThrgrzXHJpzzpYmfShakeqBdPhpRzymCcLiAhEtWyaDFERWIOldeIbUfSMtMMKnbQPZo");
    double vjCUtTCb = -204764.53124949176;
    int WxXPfdFF = 2060595920;
    double koqRlgQXYgvAfUO = 314661.72336275596;

    for (int snOIf = 1109431463; snOIf > 0; snOIf--) {
        vpKVICZx += vpKVICZx;
        khZyQBkonAhhQQN = khZyQBkonAhhQQN;
        CMObsAafVUhOVI += vjCUtTCb;
        GaXCHPWe = vpKVICZx;
        LVBjGBgy -= wBSDTpAFyuWPFLG;
        GaXCHPWe = GaXCHPWe;
        koqRlgQXYgvAfUO += CMObsAafVUhOVI;
    }

    for (int dlwGIYDFRDLsP = 479054011; dlwGIYDFRDLsP > 0; dlwGIYDFRDLsP--) {
        continue;
    }

    for (int AdaZPgGbSSni = 1508941171; AdaZPgGbSSni > 0; AdaZPgGbSSni--) {
        continue;
    }

    for (int ClTKkvHNoFgVLp = 1446399414; ClTKkvHNoFgVLp > 0; ClTKkvHNoFgVLp--) {
        GaXCHPWe += khZyQBkonAhhQQN;
        koqRlgQXYgvAfUO *= vjCUtTCb;
        wBSDTpAFyuWPFLG *= LVBjGBgy;
    }

    for (int ZTWimuETDrx = 2062771560; ZTWimuETDrx > 0; ZTWimuETDrx--) {
        WxXPfdFF /= wBSDTpAFyuWPFLG;
        WxXPfdFF /= wBSDTpAFyuWPFLG;
        CMObsAafVUhOVI *= vjCUtTCb;
    }

    for (int cfkkxdwhCRujs = 1306755928; cfkkxdwhCRujs > 0; cfkkxdwhCRujs--) {
        continue;
    }

    return khZyQBkonAhhQQN;
}

bool nmIOK::HsHzeiFHMBDSb(string BymNBFP, int olMaIamBuMTA, int HAafXCedKXeLLd)
{
    double DJtvLPFKsJj = 434638.76594107744;
    double CjfwFClMvgjXB = 516530.580109682;

    for (int IUqMNqbiXLv = 336459979; IUqMNqbiXLv > 0; IUqMNqbiXLv--) {
        HAafXCedKXeLLd += HAafXCedKXeLLd;
    }

    for (int BUyrlwc = 1697688989; BUyrlwc > 0; BUyrlwc--) {
        olMaIamBuMTA *= HAafXCedKXeLLd;
    }

    return true;
}

int nmIOK::OviQWqPXEUsocwJ()
{
    string kKqMJWsUWHGeUlXr = string("rMYGUfrcLpRnpxvieXVlsTUdLpNkgFnukWxdPnnedYerAofLeYEPLYPrDwkkRRlSDEQlCYtvpfAwvBWMiARpNDqXYUxeYWFYbYatIJbNtjcsRhbECJTvtcVepnyaNwzyFoJaYbonaQ");
    double ztbGNCoXWnESA = 755352.6844157582;
    string xIuTpRZ = string("geEtqhdyUAiwNQoDqSAXAdz");
    string oVqReNFN = string("gbDvrwnIiQgITvzOBbASBRswqRhrNuMqwRJhCDxYWmxNEMCNBvFSBCbPGEGMCTbOegMlvxLhDPLqanhmPwarcUIKcrFQZfGhizWVQOnmYmMmMPrSsXHsAtRANNYSVWgu");
    double xVesqPwEOXFPTP = 317078.0150872694;
    double ZKFqEMtl = 213811.85214216931;
    string QzimxGHTtTmFECqh = string("aDrNLSKUVflVaySulAZyXpQyfyrPoKVDVwgSPnMavGLLgXaZkntOjCqFrjSaGItDjFTIcvsMfmfqeOKxeZwvJihCbAvvgZCdOwQOLkGoMbOkyovSeAnSvOwApCZlAOgYVGhiSYPyqJodTCVffEOEqnbnkbgYmBShypjHqhFCeUmGNRfYMGBGvDDiERNMLXDWElGOCkIvAz");
    bool hdTSUH = false;

    if (QzimxGHTtTmFECqh <= string("aDrNLSKUVflVaySulAZyXpQyfyrPoKVDVwgSPnMavGLLgXaZkntOjCqFrjSaGItDjFTIcvsMfmfqeOKxeZwvJihCbAvvgZCdOwQOLkGoMbOkyovSeAnSvOwApCZlAOgYVGhiSYPyqJodTCVffEOEqnbnkbgYmBShypjHqhFCeUmGNRfYMGBGvDDiERNMLXDWElGOCkIvAz")) {
        for (int wVasiUj = 388189363; wVasiUj > 0; wVasiUj--) {
            ZKFqEMtl *= ztbGNCoXWnESA;
        }
    }

    for (int EGJwemkFqgO = 1290305655; EGJwemkFqgO > 0; EGJwemkFqgO--) {
        QzimxGHTtTmFECqh += QzimxGHTtTmFECqh;
    }

    if (ztbGNCoXWnESA <= 755352.6844157582) {
        for (int iVkweJKmvw = 2146291140; iVkweJKmvw > 0; iVkweJKmvw--) {
            ZKFqEMtl -= xVesqPwEOXFPTP;
            xVesqPwEOXFPTP = ztbGNCoXWnESA;
            xIuTpRZ = xIuTpRZ;
            xVesqPwEOXFPTP /= ZKFqEMtl;
            QzimxGHTtTmFECqh += oVqReNFN;
            oVqReNFN = oVqReNFN;
            oVqReNFN += xIuTpRZ;
        }
    }

    if (ZKFqEMtl >= 213811.85214216931) {
        for (int FqjhuHVy = 1260673991; FqjhuHVy > 0; FqjhuHVy--) {
            ztbGNCoXWnESA /= ZKFqEMtl;
            kKqMJWsUWHGeUlXr = oVqReNFN;
            kKqMJWsUWHGeUlXr = QzimxGHTtTmFECqh;
        }
    }

    if (hdTSUH == false) {
        for (int UGbBufLycJOh = 2059883932; UGbBufLycJOh > 0; UGbBufLycJOh--) {
            oVqReNFN += QzimxGHTtTmFECqh;
            kKqMJWsUWHGeUlXr = xIuTpRZ;
        }
    }

    for (int pbAGxwt = 51898113; pbAGxwt > 0; pbAGxwt--) {
        oVqReNFN = QzimxGHTtTmFECqh;
    }

    return -30862987;
}

string nmIOK::gCbCcEEaeuITvRc(double jXjkgDHZfUXJ, string HfvDeLcPEVebTbGQ, int INtFGauTGh, bool sAYXJve)
{
    string tguqKaoK = string("kNvYKBNcPFTCcKtvuUWVIbYnewDurEDIIdJPxsNUbwnZRimgjkIiMlDJCpUKHoQlgWzUmLKdhfXkRbOJnglUZqndIqcUWZzSLfxtqHPiTmDDJQTuCNceEQPrAaxoxoRnYUlNDFmzIWCZPbJiokvzRAYWjdOTmtjKjBtOzstxxdM");

    for (int IzhjuvhIwfLWC = 1364970460; IzhjuvhIwfLWC > 0; IzhjuvhIwfLWC--) {
        INtFGauTGh *= INtFGauTGh;
        jXjkgDHZfUXJ -= jXjkgDHZfUXJ;
        HfvDeLcPEVebTbGQ += HfvDeLcPEVebTbGQ;
    }

    if (INtFGauTGh <= -42458270) {
        for (int FzjmQvnpppHd = 481346868; FzjmQvnpppHd > 0; FzjmQvnpppHd--) {
            HfvDeLcPEVebTbGQ += tguqKaoK;
        }
    }

    for (int kkMcdlYkufy = 1259322559; kkMcdlYkufy > 0; kkMcdlYkufy--) {
        tguqKaoK = tguqKaoK;
        sAYXJve = ! sAYXJve;
        HfvDeLcPEVebTbGQ = tguqKaoK;
        sAYXJve = sAYXJve;
    }

    if (tguqKaoK > string("kNvYKBNcPFTCcKtvuUWVIbYnewDurEDIIdJPxsNUbwnZRimgjkIiMlDJCpUKHoQlgWzUmLKdhfXkRbOJnglUZqndIqcUWZzSLfxtqHPiTmDDJQTuCNceEQPrAaxoxoRnYUlNDFmzIWCZPbJiokvzRAYWjdOTmtjKjBtOzstxxdM")) {
        for (int UTqmXd = 1457995677; UTqmXd > 0; UTqmXd--) {
            continue;
        }
    }

    return tguqKaoK;
}

void nmIOK::DEUIVeFFeBsVqsvp(double uSCXXTejb, bool jwDmoVHZJMDSpq)
{
    double wuwiwCfnQG = 634263.4375357742;
    string IQBvVX = string("qVSPnLSQfTvMdusYZRNpabJknplpkmfggUzDZYmBxqJYpHNWdHxDwXjihHYeqLarOEggdCcMLXJUtZHlKRgqEIlLTSmIHBoIKsPdogmrwMmGpghqLnZEthQwvuXeuOEQ");
    string FNXvPpltUAxRvgR = string("KvEJMDQWxKTBsPiFhfvizOFDjKztpeqlxOcAGpYtoSgUxjCRwehMnDpsvybcMQQAZCwUnrqBcWhQksiisKxjApqABWsjEezXYVmSBejQpJIXKTfqTeCFgMlPSqNUHQjpKGvcHJgCRFrbgxbnJfDNkBPJAnkEqNZbZeosrJqydcroGGAjxOAzwOvFrWXNiJYgZrTgoEOOcrHqVqAkhndWKQdyRFSyQeaeUSiYHJb");
    string htOHzVr = string("yNEJXkmVhtLjcsxdgfnkesSCLOaleKZxzrSxUJOntpPFTlfhSQAhfnfGWeDvuXfdOdQsmHBvbzHDyVLcJrEUrLqaYrcPgXsqaScMQi");

    for (int KOhqSUqF = 1503194158; KOhqSUqF > 0; KOhqSUqF--) {
        uSCXXTejb -= wuwiwCfnQG;
        FNXvPpltUAxRvgR += htOHzVr;
        FNXvPpltUAxRvgR += IQBvVX;
    }
}

nmIOK::nmIOK()
{
    this->ZpSpuTrOdnJ();
    this->JoubAygnRqT(-249154.49849868316);
    this->mcXIudlnOz(string("TyjfOElWQOEvpckhEZkTYMQwJWDSseFdqGEeYErIPTUqZTwclYxaFVDnqltmsHbWDwJRqHtWaKxFRyibelIzoYArJNCNitFCxMMbvcrZhavQqpOOWgkmmlqYWenOVoJxvxqBDrAOmKrwxgKkKuuTUdnMHZRNMwsHPBoaxBboVReVdyegaprWsZgqFaflfXY"), -38922441);
    this->URpqyxYKOZiWPY(391675.29856994085, 804967.5781421105);
    this->iniRbPvTKmCBjoOB(-715308, string("xwZwYMLthlGHOSYjRDDUVjkvldikeqAtqnDlMYmHZjzlTuDuLsftWaMKJQVCPGoYWUvgOJVKjqGMlmBgZQxMMqLQhtDALwrTQsfXiFZaBaNirLLBRKgfsVIJKRshPhDeqpIyuVwYTRoGfBEAjxIQwNiGDCMHRKlqXmvgWvRBRveVSPOatpyDqbuhlnwnEbMAVD"), string("sUFPpvCUvisVmNmtLvqbGJtrzgXcIkLQJGUELoVriqTKwiMtCNctscKbWHvVvzOiFkWSFwQYsmuSWGcTDpwKDBBPNrYgvQVPtjMCsDfMWDKxwhfJbcgxFpHXheIZFYCeTrhPDMPrCTTTDPUYOcEChpnDrnrRqLnOSihQOzbgckzlODSkrzwDpYV"));
    this->snVMFvS();
    this->YjIPOBzNXys(1743543094, string("UfkRoNtkYISXvYKblBFBbanmtxvLdznnmaieLPNYTFJvEkgwcgPNxCCFcvOlTGgawRdqSaVFXWsHetUHTwbxCIOBUXKqyhBRdCuprrgcuQbEeYpBbfHImOWxalsNzCJYUTqnXSgaUvJvoh"), 709883.4560363586, string("RkgrNpXQvEFgrOPJbRhXVvhhyeCWIbTAuARymEjnIdRUhnYiSFntsXXMMvWDZLknEWFZlxEBcZpEABHxUwzRFbGHnFQEsxcYINpmsesPaUOJUJKIvzMWRQWhHEJmrViHjFcjFOxuMPNbeSWCRcMNuSbUIpJUvsLmMYSiQcyQfGLBfnGgiNlPyGfdWMsTWMQYsPUKBlFpbZHvDYhXIhkrSLdQMWRCrIq"));
    this->JeEAHTdrWQVYIe(432428295, true, -529770.585406762);
    this->kNzTJaR(-1101932283, true, -1039787.05856184, -1580505231);
    this->HsHzeiFHMBDSb(string("MKmaqoCxRpWxeZbsFvszAcYDRubFhEKHOpLwljQHcrxcOZzPrSFexSclxDLTaEfaMQAwZGDCkIKWQgYgJbSdiuQarvseO"), 202540724, 1767390557);
    this->OviQWqPXEUsocwJ();
    this->gCbCcEEaeuITvRc(187304.33820485414, string("qvfIrCsosublXBOALsFKKFbQjUaWJJIqchvSXOxOzHQsUeYvWZVXUbDKwfWtUFcKWOfaLWzf"), -42458270, false);
    this->DEUIVeFFeBsVqsvp(-379966.00799785036, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VvHmTPCgtLeKYfjo
{
public:
    double uyQJTUm;
    int PTRzV;

    VvHmTPCgtLeKYfjo();
    double aMgtUxKvXOsyz();
    double hztwlcAJsTRhY(int jjFpBchJv, string YnikKxAPHaISDES, string SxpygouZEf, int rJfBjBgwtXFSiAnz, double cqvrGgQRkOQcTuBD);
protected:
    bool AoPRc;

    bool mQmlQVABRzR(int cRXxmPX, string AfHxwDhrD, double ivLxOrwkej, int MTikwOPY);
    double DDEobnRITej(bool wyBPzykXL, bool KKUat, bool HXhsESObgxwPQ);
    string qSYVsY(int GcftobpUgC, double xNwBgKMqluMfP, bool KjlvFuj, bool NAQtqEMQFaoEy);
    int FadImAQg(string jAYgXdHJuVjDN, bool mGdPdgR, int mxLITfoc);
    string nNCtbqmOkMnk();
    void NHulZtQLV(bool SGrCtSf, int MyyUjIjVx, bool iWkdirlOFLEhDdC);
private:
    double oCuhhtGQ;
    bool NHocmghOBQWgeJ;
    string GCWoYABOvBEuiCFy;

};

double VvHmTPCgtLeKYfjo::aMgtUxKvXOsyz()
{
    string FDQfZtU = string("OsutYouLzcZEFHBrpUIziPUKWjLGDeiICBHBJfqdthSmtXdLaFiTZQvHHUSTidoZWKAcZvUKiWMiiGsdzGHqWhQLwbvpaCkbfjssZfrrZIcuEXPciODbWPxIbpnHlRuuxXDjDDWXKpCIJFZWcktXZjpCwzbevrdlONYojPSswMQfOarQfhJzGthPjhyfSoaxVBLsCTtbCGDKKoKSpNDlHenwOenWtAGBRlaDerouQMRlWC");
    bool KxGqDVQIMzonmwW = false;
    double qkvFgey = -305558.18003441975;
    double LatvIjVoFh = 708625.8751826594;
    double lxBNucXJjR = -1003678.2584975165;
    double IeRqZpHYKwgfbf = -235983.35670227694;
    double VfLkVaVcCEIDLWz = 450660.07143734035;
    string ankYwkVMMLXjGxpV = string("UygyANEFXQJiXHyCMDRvKeYZZGhnUWcpSOmgvGshGSCEmXzRhPlzfEaiBmYPsxDeBMInaIfgVpnPbgdjpWXdkXKlmszHSmYdaAfEJZxnRTmPngrDyhfnRJmGiJgONheDZiSTccJeJz");

    if (lxBNucXJjR > -235983.35670227694) {
        for (int wLkpjsfHqwLq = 1105676484; wLkpjsfHqwLq > 0; wLkpjsfHqwLq--) {
            IeRqZpHYKwgfbf = lxBNucXJjR;
            qkvFgey += lxBNucXJjR;
            LatvIjVoFh *= lxBNucXJjR;
            VfLkVaVcCEIDLWz -= VfLkVaVcCEIDLWz;
        }
    }

    if (KxGqDVQIMzonmwW == false) {
        for (int lHEEjhb = 1635861612; lHEEjhb > 0; lHEEjhb--) {
            LatvIjVoFh = VfLkVaVcCEIDLWz;
            LatvIjVoFh = VfLkVaVcCEIDLWz;
        }
    }

    return VfLkVaVcCEIDLWz;
}

double VvHmTPCgtLeKYfjo::hztwlcAJsTRhY(int jjFpBchJv, string YnikKxAPHaISDES, string SxpygouZEf, int rJfBjBgwtXFSiAnz, double cqvrGgQRkOQcTuBD)
{
    bool JEHAsPJMWmz = true;
    string OiFVmUINKaFQzBB = string("vpEPliQewljrPGKDyKEwyUFmJpQQoXjxebClsFRjmyPCqkN");
    bool oDCLyoacw = false;
    int DJROELhuLlLKrXI = 961579935;
    double Njfsazk = 218771.33142267383;
    string ohRzbLpTfAaAsmo = string("CuDWdQyCSjctNRCatTljpRjJxJvYVRiCupgSPgJjmAqwwQJGqAoUAXJwDNbtOnRNNyAopwpwjSnksPzvXBZYCOUHAUauTpoHoJVnTCtBWDxitqzRufTOYuQgEPTQqHFYCGoPiZIxEDlUuYHqZLNoVLnnuoHwCmHnVWglWTHwkRZddpQEju");
    bool oGaJHEPLOBRqI = true;
    int YgWQeXSqV = -210035833;
    int zcMDVWhhe = 696603655;

    for (int NUrCUZmQDpwfz = 366408578; NUrCUZmQDpwfz > 0; NUrCUZmQDpwfz--) {
        continue;
    }

    if (rJfBjBgwtXFSiAnz <= 696603655) {
        for (int khgIVyzk = 1163276757; khgIVyzk > 0; khgIVyzk--) {
            continue;
        }
    }

    for (int ZvIyhm = 698243339; ZvIyhm > 0; ZvIyhm--) {
        oGaJHEPLOBRqI = ! JEHAsPJMWmz;
    }

    for (int bovFCUqKKukFdK = 494700431; bovFCUqKKukFdK > 0; bovFCUqKKukFdK--) {
        zcMDVWhhe = DJROELhuLlLKrXI;
        cqvrGgQRkOQcTuBD /= cqvrGgQRkOQcTuBD;
        YgWQeXSqV += zcMDVWhhe;
    }

    for (int GFBmSDcKtgWP = 569353963; GFBmSDcKtgWP > 0; GFBmSDcKtgWP--) {
        YgWQeXSqV += rJfBjBgwtXFSiAnz;
        ohRzbLpTfAaAsmo += OiFVmUINKaFQzBB;
        SxpygouZEf = ohRzbLpTfAaAsmo;
    }

    return Njfsazk;
}

bool VvHmTPCgtLeKYfjo::mQmlQVABRzR(int cRXxmPX, string AfHxwDhrD, double ivLxOrwkej, int MTikwOPY)
{
    bool DVnHayOvaAEcq = false;
    string OQmfSAUX = string("OftItIakvgLYuDZHxZRkBTJabslYaFgnleVrjsrvWODRFRfzlqAOCpehOwHtcKnrsutfOkBgKVkmZeUIdXLvglGFIJGfmeCVkLflGsZAhbvTLCbVoOzIcUxkGPRqDxXEtNVcoppyJtulOTbRHCJHgQPgJrQwpQsgivMToOKdvivWtQWFcyfVhNCwrVMgOQNjYWLphidkKQVdewq");
    bool TurXdyKKeymup = true;
    bool bjLrcyuiDMXigigJ = true;
    double uRpAzOfUt = 503545.23272029596;
    string lSQjNwn = string("OXnNMiCwReKDOGmSLNiijhZKtULZAKmPrrIkqwnZLoYfNuKVFKnXzycffjpvWIHnGsNfbVQUbPRYwKorrqiOsFOMRByWsOimXyGkPrBukhaTHQzwRvUktHbmBDkzPANSLNLUQiLYIXpQfEOpVpuxjDfRvPkJjLqqAuuMkzIVmviSKECgScbMNbhUJGTPXtCDvwddOnbMjSZT");
    double NkyEdfdrPomQagp = -782334.05914302;
    int wcRDEvQwFnDyCc = 1697219562;

    for (int gLWQZhlDGmCyybJ = 159160520; gLWQZhlDGmCyybJ > 0; gLWQZhlDGmCyybJ--) {
        DVnHayOvaAEcq = TurXdyKKeymup;
        TurXdyKKeymup = ! TurXdyKKeymup;
    }

    for (int nysAfWNHJvpsyeUg = 1738351912; nysAfWNHJvpsyeUg > 0; nysAfWNHJvpsyeUg--) {
        bjLrcyuiDMXigigJ = ! DVnHayOvaAEcq;
        uRpAzOfUt *= NkyEdfdrPomQagp;
    }

    for (int GFSMpzwBTTD = 811500044; GFSMpzwBTTD > 0; GFSMpzwBTTD--) {
        wcRDEvQwFnDyCc += cRXxmPX;
        MTikwOPY = cRXxmPX;
        bjLrcyuiDMXigigJ = DVnHayOvaAEcq;
    }

    return bjLrcyuiDMXigigJ;
}

double VvHmTPCgtLeKYfjo::DDEobnRITej(bool wyBPzykXL, bool KKUat, bool HXhsESObgxwPQ)
{
    bool ocuRSIu = false;
    bool KXYNI = false;

    return -542835.8936300541;
}

string VvHmTPCgtLeKYfjo::qSYVsY(int GcftobpUgC, double xNwBgKMqluMfP, bool KjlvFuj, bool NAQtqEMQFaoEy)
{
    int LhrivTnjQH = 297986807;
    double WOIBeSZ = -188283.7243592435;
    string rNXjBzmLq = string("zflzDMHjv");
    double SGlZjAmdazVZBccA = 706568.6185848678;
    string SKwDeUpvaNe = string("vXhxmdvABHbLCasNEXwbfnMTAfVzVDaCxjtwcWzvgatQYAhKUDVBfseCMzvwiaUbknMYBYyPI");
    double oIjNiYrJyZ = 259167.8407852087;
    bool FKEJzfDfpBQep = true;

    return SKwDeUpvaNe;
}

int VvHmTPCgtLeKYfjo::FadImAQg(string jAYgXdHJuVjDN, bool mGdPdgR, int mxLITfoc)
{
    double SCUOsGfyBmM = -1032578.3508013779;
    int eHxSg = -1186228503;
    bool WmAEV = true;
    int wNPuTkvjJKIh = -79852619;
    double vWPmLHAfdMkGan = 188925.79459961894;
    string oHkFirtIXyRjU = string("qwkBzFMHlLPrAMIMntcJiqYMKokSepwZeMDRVvkSTBmgcEzHYRgStQkJzJuAspJWCzfBlhdKqdjjkxoJfYCJLPCSvEWEliFjRjMAvJ");
    string HbpkUxjamLHRlg = string("UDaoGgIYvRbeCgZcvKBNoKFUfxw");
    double rGMfRvkQN = 528767.9103276086;
    string mEqBNsxZtdcNy = string("FWfilrKdLnIOyHCXPSRrEyJkhIjueqONeCTazVQRMr");
    int xFXDlXrGBXeUWL = 844950022;

    for (int hEnqOQblKPuMjRQw = 2146957632; hEnqOQblKPuMjRQw > 0; hEnqOQblKPuMjRQw--) {
        mEqBNsxZtdcNy = mEqBNsxZtdcNy;
    }

    return xFXDlXrGBXeUWL;
}

string VvHmTPCgtLeKYfjo::nNCtbqmOkMnk()
{
    double ShxnSSNnHfeWuttN = 586941.5594500992;
    string hIXVRWwwNj = string("lLUCeo");
    bool mkhbvt = false;
    double KPFGaoAkZwJgpVO = -505923.6941954168;
    double rKfsGU = 450387.6712575785;

    if (KPFGaoAkZwJgpVO < -505923.6941954168) {
        for (int lLBveNbGozuoQ = 1960707838; lLBveNbGozuoQ > 0; lLBveNbGozuoQ--) {
            ShxnSSNnHfeWuttN += ShxnSSNnHfeWuttN;
            mkhbvt = ! mkhbvt;
        }
    }

    if (ShxnSSNnHfeWuttN >= 450387.6712575785) {
        for (int hhAcWfjzBGPFy = 933333683; hhAcWfjzBGPFy > 0; hhAcWfjzBGPFy--) {
            rKfsGU -= KPFGaoAkZwJgpVO;
        }
    }

    return hIXVRWwwNj;
}

void VvHmTPCgtLeKYfjo::NHulZtQLV(bool SGrCtSf, int MyyUjIjVx, bool iWkdirlOFLEhDdC)
{
    int ltOnPXZsMIfwrD = 814850677;
    int bBldYevgMqgjWH = -1760191368;
    int qAsEQmwdheekCne = -1483461885;
    int bZDNeyvbKrH = -572445327;
    int tTgBc = 263793116;

    if (bZDNeyvbKrH > 263793116) {
        for (int YtSFeQnReNQSFg = 1964931012; YtSFeQnReNQSFg > 0; YtSFeQnReNQSFg--) {
            bZDNeyvbKrH *= ltOnPXZsMIfwrD;
            tTgBc = qAsEQmwdheekCne;
            bBldYevgMqgjWH -= ltOnPXZsMIfwrD;
            bZDNeyvbKrH *= tTgBc;
        }
    }
}

VvHmTPCgtLeKYfjo::VvHmTPCgtLeKYfjo()
{
    this->aMgtUxKvXOsyz();
    this->hztwlcAJsTRhY(-797981681, string("PGdFVENvAOLJFHeNfElPOjbauQOkQxmlQTcDLZVYIAXLQjeeapgddDHuuEMcZrzrqygUErBaNzdRONVExuTIGBUMuYhEzIhhyUBGGuzWIcQPTsTLrflzWAkHYoghpfXhvGMqTHuWNsnWEgkmLnUBzPBNBdBmCpnqweSUuXDJOMnXiuqRezhjmLmrLEHIdAWVUAweZGKKTuxzfmiikyOCT"), string("MjaKebSVgARfrFxnExBiFvpQgzdeCSuRFgNiMVHjEJRfmZsGmTCHdghZDlAgSMLrpCREZaiwGiORxfrwCUTCLxbmmPaROtmCxOaQSMYbPAbRhRZPzAWXqMHmdNXmjae"), 779944630, 744824.9540166436);
    this->mQmlQVABRzR(-1784967553, string("ceRBcYifKbNkYzcdsysufVPoEsgrueOMraYYDTmomJJaVeKduMhzmfbJdmIjiLJVVJTInNIptDmCjCnLyZYUdZTFoTwjRdBJpIistNuNuBQzlmAVALKfZpdfYhDwtsgRKEDUAMZRvdINHsuLIbcSkgcbEoTuSxLUaXADvEWAgrncwlQecAegSqWDIuSMoiGxDjcAfkxUcMeICEJJPjNVzKyXFgRQUohR"), -621353.9113482648, 718288343);
    this->DDEobnRITej(false, false, false);
    this->qSYVsY(-1521539565, 113901.93544489758, false, false);
    this->FadImAQg(string("aTbhdcEOOvSGtQoviADXVpbkNzjbQMnyNUkZYoLvgwrhZjDAayJCRLlbEZKdekgAcTOrZBFggttXmiLToZYpxVLmANMUvzySsjonRlZuDrsxAUCNmScCD"), false, 1010258278);
    this->nNCtbqmOkMnk();
    this->NHulZtQLV(true, -1989672124, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gRKZWWcvWNxQgMB
{
public:
    bool TOogkdAuzwUU;
    double YdbcfNPQCqD;
    int hUMaOYlHulMmUIkY;
    string KizXzaqiWNQ;
    bool kdbnZc;

    gRKZWWcvWNxQgMB();
    bool OaMmze(string klfMasTV, int CVMtH, string XpcGROAXlprSDK, bool ECGDEMXomnSlamcW, double ieQDBUTzsdJ);
    string rVoCZkvaZjQqWZY(bool xhjAvLUOsWLlH, int xNmhexJoVdHN);
protected:
    int NtIeOseswqFJytix;
    double CdnkgTOe;
    int SKbsyWrBOb;

    double PslIDHHc(string FEJPaTnID, bool TWbAKwoLSnPeIoz);
    void aulOhC(string FTxWTZnHSFWRvnr, int fOvitrucLPSkH, int xzUgH, string MWfYXw);
    bool eCHJc(string FXMxCdmCqeycrUB, string NOVkaAfZgFv, int VhBIIyERmdGxGT, int AvONDpCcxGT, int veWhztug);
private:
    double htaZIJdwODw;
    int pNBsZhE;

    int njAVbnIQo(bool eKXuoHDSkgFSBlLO, double wdbVJRsZTUMjPuYg, int scdwMW, string kuQgyoOKxPOC);
};

bool gRKZWWcvWNxQgMB::OaMmze(string klfMasTV, int CVMtH, string XpcGROAXlprSDK, bool ECGDEMXomnSlamcW, double ieQDBUTzsdJ)
{
    double mZnmS = -892049.7030401974;
    double TlOQEaf = -751746.2310856499;

    if (ieQDBUTzsdJ < -892049.7030401974) {
        for (int qSoOpRnPM = 175862285; qSoOpRnPM > 0; qSoOpRnPM--) {
            ieQDBUTzsdJ -= TlOQEaf;
            TlOQEaf = ieQDBUTzsdJ;
        }
    }

    for (int zGJfxSgXRewmO = 2016062829; zGJfxSgXRewmO > 0; zGJfxSgXRewmO--) {
        ieQDBUTzsdJ += TlOQEaf;
        TlOQEaf -= TlOQEaf;
    }

    if (ieQDBUTzsdJ <= -892049.7030401974) {
        for (int HVGwayfwVlEKksct = 1802474147; HVGwayfwVlEKksct > 0; HVGwayfwVlEKksct--) {
            ieQDBUTzsdJ -= TlOQEaf;
            XpcGROAXlprSDK = klfMasTV;
            TlOQEaf /= TlOQEaf;
            TlOQEaf -= ieQDBUTzsdJ;
        }
    }

    for (int aowLMlMWLPqE = 1082115003; aowLMlMWLPqE > 0; aowLMlMWLPqE--) {
        klfMasTV = XpcGROAXlprSDK;
    }

    for (int ceugQTt = 1607791578; ceugQTt > 0; ceugQTt--) {
        CVMtH = CVMtH;
        TlOQEaf /= ieQDBUTzsdJ;
    }

    if (CVMtH == -611681722) {
        for (int CkfrvodxEXsRc = 119994567; CkfrvodxEXsRc > 0; CkfrvodxEXsRc--) {
            mZnmS /= ieQDBUTzsdJ;
            klfMasTV += klfMasTV;
        }
    }

    return ECGDEMXomnSlamcW;
}

string gRKZWWcvWNxQgMB::rVoCZkvaZjQqWZY(bool xhjAvLUOsWLlH, int xNmhexJoVdHN)
{
    string CQFlBSkd = string("GvuCxhjy");
    string ZXpIDofO = string("vXraKMEtvycwRmAuWlzbNhRBKxxGEeOelhBcWiTvSbzMImuYOOPkLjojrLCfKmkmRCbJDJRqwBUTiqkpHOGxgylFRNHHTZJaVFrJVOtXZQIptGoVXanikJtGeCaQcThljLJqVziPpDHDNhcKZZAufOBDEINqxdVITPcOvCsRrTnDitetOWCApfUJoYinvFbkvAMuzduAjSuxwWslxnXvRVxgulzgcoCAmKxTYXXaPaLQYAJKjHuMhExbXOIeThj");
    int hVwJvbOdpZRqPTwB = 709828871;
    int ErBrORgaVzChxqU = 547196129;
    int QsciVZpLlexuCmfy = -1324689480;

    for (int pygiygtJtAAs = 1041394052; pygiygtJtAAs > 0; pygiygtJtAAs--) {
        ErBrORgaVzChxqU = hVwJvbOdpZRqPTwB;
    }

    for (int CDgRlQ = 726474592; CDgRlQ > 0; CDgRlQ--) {
        ZXpIDofO += ZXpIDofO;
        CQFlBSkd = ZXpIDofO;
    }

    for (int SuIIGuWFoKQMV = 1414947529; SuIIGuWFoKQMV > 0; SuIIGuWFoKQMV--) {
        QsciVZpLlexuCmfy -= xNmhexJoVdHN;
        xNmhexJoVdHN = hVwJvbOdpZRqPTwB;
        ErBrORgaVzChxqU -= QsciVZpLlexuCmfy;
        hVwJvbOdpZRqPTwB = QsciVZpLlexuCmfy;
        ErBrORgaVzChxqU *= QsciVZpLlexuCmfy;
        xNmhexJoVdHN += xNmhexJoVdHN;
        ErBrORgaVzChxqU -= xNmhexJoVdHN;
        QsciVZpLlexuCmfy /= ErBrORgaVzChxqU;
        xNmhexJoVdHN -= ErBrORgaVzChxqU;
    }

    if (hVwJvbOdpZRqPTwB <= -1940558961) {
        for (int KHDmHGkxfsmsaC = 2113298558; KHDmHGkxfsmsaC > 0; KHDmHGkxfsmsaC--) {
            hVwJvbOdpZRqPTwB -= QsciVZpLlexuCmfy;
            QsciVZpLlexuCmfy -= ErBrORgaVzChxqU;
            xNmhexJoVdHN += xNmhexJoVdHN;
        }
    }

    for (int yEGWVBlVqMiXWIS = 1510131089; yEGWVBlVqMiXWIS > 0; yEGWVBlVqMiXWIS--) {
        ErBrORgaVzChxqU /= hVwJvbOdpZRqPTwB;
        hVwJvbOdpZRqPTwB *= ErBrORgaVzChxqU;
        ErBrORgaVzChxqU = xNmhexJoVdHN;
        QsciVZpLlexuCmfy -= ErBrORgaVzChxqU;
        QsciVZpLlexuCmfy -= QsciVZpLlexuCmfy;
        ErBrORgaVzChxqU += QsciVZpLlexuCmfy;
        hVwJvbOdpZRqPTwB += QsciVZpLlexuCmfy;
    }

    return ZXpIDofO;
}

double gRKZWWcvWNxQgMB::PslIDHHc(string FEJPaTnID, bool TWbAKwoLSnPeIoz)
{
    bool cNKnJSBeMURFJHAo = false;
    string IggKMwEJqVfl = string("QkZzuKakXclJabJcERmUlLSUGNcStAoGeunHcXmyTDjRiVslAnmUekQyKxAtjBNVuivQZJFhDHMyWegnOWlJI");
    int BQagpGbQRFSNZn = -791040982;
    string rhpCHz = string("JMJMta");
    int zjgAdBoQRW = 1417057318;
    int cTast = 997201567;
    int JEVhGvnIbadnJkdK = 815189182;
    bool oKEDwsFzWwfUInTZ = false;
    int aBEXMDmXa = -667209380;
    string GEhwnBTYWyQF = string("oruoVLHzOgSZTgbfpebWRAnofbEdtRXxxKcFhKJHJAVCqhtIOyXnocYkYEoDrcjyqCYTEnmRbZGhnpfJrfOevUPDDdOYFxETAVlxKSzqJAHQqThQuPugvdfzjetbsFukbahsamFbrqwABZliQQyTGVFWBrXtlaDOVqzIUAZDiSzuttAUFWExpaChMYxRSTMzjYtsSjskGZZfPJtnlDbGcJBkSaJXDuDxiELiGsBfXE");

    for (int ZhLmi = 1164134032; ZhLmi > 0; ZhLmi--) {
        cNKnJSBeMURFJHAo = TWbAKwoLSnPeIoz;
        BQagpGbQRFSNZn -= JEVhGvnIbadnJkdK;
    }

    for (int ltCkK = 1371119258; ltCkK > 0; ltCkK--) {
        GEhwnBTYWyQF = IggKMwEJqVfl;
    }

    if (GEhwnBTYWyQF == string("oruoVLHzOgSZTgbfpebWRAnofbEdtRXxxKcFhKJHJAVCqhtIOyXnocYkYEoDrcjyqCYTEnmRbZGhnpfJrfOevUPDDdOYFxETAVlxKSzqJAHQqThQuPugvdfzjetbsFukbahsamFbrqwABZliQQyTGVFWBrXtlaDOVqzIUAZDiSzuttAUFWExpaChMYxRSTMzjYtsSjskGZZfPJtnlDbGcJBkSaJXDuDxiELiGsBfXE")) {
        for (int OWLENJXq = 1264906979; OWLENJXq > 0; OWLENJXq--) {
            IggKMwEJqVfl += rhpCHz;
            rhpCHz += FEJPaTnID;
        }
    }

    if (IggKMwEJqVfl >= string("QkZzuKakXclJabJcERmUlLSUGNcStAoGeunHcXmyTDjRiVslAnmUekQyKxAtjBNVuivQZJFhDHMyWegnOWlJI")) {
        for (int scGzjxrDH = 1482095812; scGzjxrDH > 0; scGzjxrDH--) {
            BQagpGbQRFSNZn = JEVhGvnIbadnJkdK;
            JEVhGvnIbadnJkdK += aBEXMDmXa;
            IggKMwEJqVfl = IggKMwEJqVfl;
            rhpCHz += rhpCHz;
            TWbAKwoLSnPeIoz = oKEDwsFzWwfUInTZ;
        }
    }

    for (int lwOoGGyFqHt = 675872188; lwOoGGyFqHt > 0; lwOoGGyFqHt--) {
        zjgAdBoQRW += aBEXMDmXa;
        FEJPaTnID = IggKMwEJqVfl;
        GEhwnBTYWyQF += IggKMwEJqVfl;
        rhpCHz = IggKMwEJqVfl;
    }

    return 876320.1227709131;
}

void gRKZWWcvWNxQgMB::aulOhC(string FTxWTZnHSFWRvnr, int fOvitrucLPSkH, int xzUgH, string MWfYXw)
{
    bool XnmHULcy = false;
    int fWJrfYLAaudTi = -1205706200;

    for (int EUvYyO = 1485767190; EUvYyO > 0; EUvYyO--) {
        fOvitrucLPSkH = fWJrfYLAaudTi;
        MWfYXw += MWfYXw;
        fOvitrucLPSkH /= fWJrfYLAaudTi;
    }

    for (int LgEGQDOoS = 1976192748; LgEGQDOoS > 0; LgEGQDOoS--) {
        XnmHULcy = XnmHULcy;
    }

    if (xzUgH < -1498008994) {
        for (int MnihPKsww = 172621337; MnihPKsww > 0; MnihPKsww--) {
            XnmHULcy = XnmHULcy;
            fWJrfYLAaudTi += fWJrfYLAaudTi;
        }
    }
}

bool gRKZWWcvWNxQgMB::eCHJc(string FXMxCdmCqeycrUB, string NOVkaAfZgFv, int VhBIIyERmdGxGT, int AvONDpCcxGT, int veWhztug)
{
    double sDoJAW = -451275.86509230576;
    string ARKoznStnGlgD = string("fJTdIciOTAGnqkmXgPoUydCRCHulgnpPVMNfhrJLrdyFOImeHVOBqjmfoLktoCxAhZddVosTyiGyaoTbCtAdxyOAoVXMEQPzUUAmKYuGFnCUovqQOyzXqxgmeutjmzavnVvEjfwSZoFNOcfgHuwXAXtDoRLkLcGfavtoLLTjtxsVxUWqcTJnCeOttWppNLsngfnBgDDtHGqnStMgPKfhbgcBoDkoTj");
    int YweSvlSmmHSBi = -1316374184;
    double MuwIIuYWHVlDV = -950529.4217640207;
    int dvsDupuhmFDO = -2070943062;
    string EwFrqJJhnmdKu = string("wCHQsJkRtoXPTbCenceBwEzxtbmIQMhbHzZPGZSFHxHesKrhDgupjqPNlzPOLkqaOfNbcuKHvLGuPtmvGfUqdZWALmtgFhAOjzZzTlBWpPGlJxoNvxHogaXrMPdXJxFazTJRpSbpZeitLkHoopTFUZRvJkblgztkarqGGrqrojqkISqwIsxtGdXXTFrEZfFbfq");
    string ecnXj = string("raagSYQQysQjXBTSoAtfFEMYFZJgKPXWaiNpVjgSSIW");

    if (ARKoznStnGlgD <= string("BIEcyFQy")) {
        for (int VGuNwrmIOtm = 421227467; VGuNwrmIOtm > 0; VGuNwrmIOtm--) {
            continue;
        }
    }

    if (AvONDpCcxGT < -2070943062) {
        for (int LctjkaGBEJquys = 2103784046; LctjkaGBEJquys > 0; LctjkaGBEJquys--) {
            EwFrqJJhnmdKu += ecnXj;
            ARKoznStnGlgD += NOVkaAfZgFv;
            AvONDpCcxGT *= YweSvlSmmHSBi;
        }
    }

    return true;
}

int gRKZWWcvWNxQgMB::njAVbnIQo(bool eKXuoHDSkgFSBlLO, double wdbVJRsZTUMjPuYg, int scdwMW, string kuQgyoOKxPOC)
{
    string oQWigcR = string("fSAqcoifjvEEwEQugEtSiimCLwUEhJsuFJjNcwHiFfcPBRSb");
    int WouSaJpDdVFOv = -1406078912;
    bool Naibnsn = false;
    string UIVqqOsVRd = string("BYSHVznusjuGYjQNZQddnrwjR");

    return WouSaJpDdVFOv;
}

gRKZWWcvWNxQgMB::gRKZWWcvWNxQgMB()
{
    this->OaMmze(string("pOJsRkZTpnKImoNaPYHcxYbOKXdTrXqQ"), -611681722, string("eIKsHHoSrPHXwJIWzzKGdUpYtMGhNSoWIPuHVPAQptLrVfAGvljvjgVstcmVDEhvmrNlJKFhBuBlaUFhuKYRmlbyAHAKdZllRCZaZknrDHyDkRKbkdXBjxICHoNheeyhqxzhWwsKvKvJdUXHmgTMsgNnoRJBBAktDWFJGUoGlPKblQeWXPFskjpSlYBKQNPWZFpNtGxCWXNCqFBx"), false, 560352.1193589374);
    this->rVoCZkvaZjQqWZY(true, -1940558961);
    this->PslIDHHc(string("cPveLcmsPHZcHYFpHEgJsYXIlmhmmpCaTQIsHFBghOvydwJfeEFdyErfhqqUeNLaQRIzbDNbNSkSuOHxhSuqTVlZgQqClUnIVUJtVPwvyzLnIIICTgTinIHNpvTxMokGOIFjWYCRsHjZMUx"), false);
    this->aulOhC(string("hLDxfdTpjYgXlYhrGssfoxuYoGKnzeBMbeKtURgQRnmVYtvywGqJajoFypPHGiqzJfStzmXBPrdAOkolcXnpFKmRGlfEzjofBCwVHdSKefbJGUEyDzhjJXtxsuUtKBBJbOwrZJysPEZtdmSdtIkskDtOxxdTwcdZfV"), -2054254759, -1498008994, string("yqUkUBMvsBbpAazTXqnHZNKJLJmfJiAPjcxPjHWgJKAgZrHGYeISNDHpMXXzMMZdiMuEAuqksjzjWmeClBZUiJSRKHygSQHXIMEGIcjYbmEeJXWTLWoQiYFk"));
    this->eCHJc(string("BIEcyFQy"), string("XajQgvSHeCTCAcVKXXCunttPAsRKeryPVBXbIUozBFZSIOWwupaUMRkIMJORUcJhsgMbFCXeJfmYanJvAkWrKcJkqJlraixckLkHwDklNRXGpogxWlJddXCnBFOdenBpVnSRlZuBZSSRbjvBOBcEpvPBlYOGmtPmikABZDZyIDomXWXwQHerceQVTHhGhvWM"), -1435755713, 1402357826, 1164704493);
    this->njAVbnIQo(false, 183510.6645948386, 79259055, string("KhhTuerievxbnDbMDvIoJecBTyOZShRFnSkHhgaiuUFRnsdeZVTAlEZXsXTvEAHDgYTEQWfwqBrUnRxLcBsZBYQBHgkjnVbtOhkLFzKvECEwqFmpftScQAHgRcCwstqyLeBBGNRwfWtMuYzQfdZWbtIZgUzhvBiFYwMUbtBmXcwOtmQdCMhmdEvxo"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yytXlhD
{
public:
    string VolSBZekONVpt;
    bool KhBwNdUOe;
    double NmpUOofTaMJBfAO;
    string QYmgRs;

    yytXlhD();
protected:
    string yKHuhR;
    bool kKpLRHbdfeLxIQRQ;
    int SKyafsbp;

    string NkfhWhRCE(string YKNOyTv);
    double yKEWlWhGPRnd(string CDxVtpxapHoI);
    void ZpRutNTed();
private:
    int kFZdZLtrxNWY;

    string DbBGK();
    int YLEQeTVNLOuFum(bool lRzWxNlW, double TloBVsMCMx, string hDELKCtGFNyVfdj);
    void INyKulkSQ(bool yQuiZPbxkaoSz, string xaSJolOUWVyOkCIE, bool iOobDvbOCDypnaXL, bool QFmrzRb);
    bool AmuUEAWNcC();
    double YjTAtRseShJYRe(int xldtfq, int hZtpdXLTsCWRxNW);
};

string yytXlhD::NkfhWhRCE(string YKNOyTv)
{
    int HxBTbwPNX = -814745761;
    bool iwPhugLl = true;
    bool ymLULCJJv = true;
    string YJsaJFxGlHUF = string("YEjELFrJMLVvjQPAIOQZwmGLUpibVRfNtxcLcfazYVxRwc");
    double kKKqjJLrxbxTdyOY = -263428.87825495633;
    int rOnFPrLEnVdX = -1415155822;
    double MRCAWyYiDvESpWs = -370148.61359265464;
    int aiZHAIqZvlxGnbKo = -462921629;

    for (int WuJBhlLCrWOJoy = 1404977960; WuJBhlLCrWOJoy > 0; WuJBhlLCrWOJoy--) {
        kKKqjJLrxbxTdyOY /= MRCAWyYiDvESpWs;
        HxBTbwPNX += HxBTbwPNX;
    }

    for (int gQOCjKzCD = 1787717265; gQOCjKzCD > 0; gQOCjKzCD--) {
        kKKqjJLrxbxTdyOY += kKKqjJLrxbxTdyOY;
        aiZHAIqZvlxGnbKo = rOnFPrLEnVdX;
        YJsaJFxGlHUF += YJsaJFxGlHUF;
    }

    if (ymLULCJJv == true) {
        for (int FCFNMPjM = 38749878; FCFNMPjM > 0; FCFNMPjM--) {
            kKKqjJLrxbxTdyOY += MRCAWyYiDvESpWs;
        }
    }

    for (int YityPwBdIIHof = 1843289776; YityPwBdIIHof > 0; YityPwBdIIHof--) {
        continue;
    }

    if (aiZHAIqZvlxGnbKo > -1415155822) {
        for (int gvdrTge = 2089803700; gvdrTge > 0; gvdrTge--) {
            rOnFPrLEnVdX = aiZHAIqZvlxGnbKo;
        }
    }

    return YJsaJFxGlHUF;
}

double yytXlhD::yKEWlWhGPRnd(string CDxVtpxapHoI)
{
    int eoZzUGZRiFaAQwWY = 1505841592;
    string NVFPxzz = string("ZZjILaleiFMVedVcQVhnYyVdjOItYkOOXfYOWdcYOwDSwzTBXifTFdIVBiBjVnHVgtPMlglIXuoTUMBUzvlEeVlDqctVVCyuGdowVaqGjmHwRxpQNT");
    bool vIkjuGvxDEqZJHtK = false;
    double VzKQFrEsElqpULGt = 244637.40454233778;
    string WnPKRKynncoDKgYZ = string("UrOuWvJOgykDLghTLDknuivfrsQYbBZZZyeCQvGoBGDOuQYuahpnZFGaqTFwDmtyrRNERISPeWNOkcAjVuJYfFBzADPnKmFuPEpppTBuUmZvLmtIFnnymDXLzROhvznRgyfJznDpWaiMgBvSuSzmh");
    int KnhcJopUW = -1140825248;
    string vyayMJB = string("QtnwNcOVFZZNTloTdrQCnkKbISFumevdIPdnPiroRrjHTKovthAluwzLYLQAmsyjDBIPktUfIalWbAfCOTldmWXgdbkzupqLkEHjPvkWgsYmdmuIXESpWpDrDqBXTddFcETFRoNjToonkohIstdhoowRwDcJJgRLzGbLMDLDpyOlCLPcvJmUCCMPvrrZYqNWvxrnCmspSVgcCXoWnlt");
    double AHSavCNRX = -489048.61811249476;
    int oDxqeuXZfZavQi = 414203710;

    for (int EHOnsOqtKn = 631993090; EHOnsOqtKn > 0; EHOnsOqtKn--) {
        KnhcJopUW = eoZzUGZRiFaAQwWY;
        NVFPxzz += WnPKRKynncoDKgYZ;
        WnPKRKynncoDKgYZ += CDxVtpxapHoI;
        CDxVtpxapHoI = vyayMJB;
    }

    if (WnPKRKynncoDKgYZ != string("QtnwNcOVFZZNTloTdrQCnkKbISFumevdIPdnPiroRrjHTKovthAluwzLYLQAmsyjDBIPktUfIalWbAfCOTldmWXgdbkzupqLkEHjPvkWgsYmdmuIXESpWpDrDqBXTddFcETFRoNjToonkohIstdhoowRwDcJJgRLzGbLMDLDpyOlCLPcvJmUCCMPvrrZYqNWvxrnCmspSVgcCXoWnlt")) {
        for (int QobIuONunuDFXNVh = 831486034; QobIuONunuDFXNVh > 0; QobIuONunuDFXNVh--) {
            eoZzUGZRiFaAQwWY *= oDxqeuXZfZavQi;
            vIkjuGvxDEqZJHtK = ! vIkjuGvxDEqZJHtK;
            CDxVtpxapHoI = vyayMJB;
            NVFPxzz = NVFPxzz;
        }
    }

    for (int KbUHdmzWxgQhmCN = 1070592335; KbUHdmzWxgQhmCN > 0; KbUHdmzWxgQhmCN--) {
        continue;
    }

    if (CDxVtpxapHoI > string("ZZjILaleiFMVedVcQVhnYyVdjOItYkOOXfYOWdcYOwDSwzTBXifTFdIVBiBjVnHVgtPMlglIXuoTUMBUzvlEeVlDqctVVCyuGdowVaqGjmHwRxpQNT")) {
        for (int XHWjuRGxbBxcauK = 1151397619; XHWjuRGxbBxcauK > 0; XHWjuRGxbBxcauK--) {
            continue;
        }
    }

    for (int DGrzcHvcobBBzd = 101559364; DGrzcHvcobBBzd > 0; DGrzcHvcobBBzd--) {
        continue;
    }

    return AHSavCNRX;
}

void yytXlhD::ZpRutNTed()
{
    int PXhMeRV = 1776440098;
    double TCysCogmGwH = -441448.89009361615;
    int CkxuQ = 960666090;
    int ytblxqciw = -366335143;
    string xnbjKuPS = string("irpKITIwbnBzjIckecSWohNhxMTOgnMgwmRNZLDCKvkItEvvSeXJuHiIPovBcKlyzEBqwePunYNlRpXPnVakGjoHxyhLayWNBexiVPzgSXJkAYyxGAkmYPJDfKmsVzpagczJiRmdB");
    string KjWHDmguvPMESM = string("phBrE");
    int fFyzZRqaOMWHkK = -1813177506;
    int FajEpqkSMwTyVq = -1861188858;
    bool mDVocpsWobXGSRmg = false;
    bool KmPiRkaQ = false;

    for (int FMVsGw = 1699386816; FMVsGw > 0; FMVsGw--) {
        KjWHDmguvPMESM += xnbjKuPS;
    }

    if (KmPiRkaQ == false) {
        for (int dzLRoMbj = 1928083806; dzLRoMbj > 0; dzLRoMbj--) {
            continue;
        }
    }

    if (fFyzZRqaOMWHkK != 960666090) {
        for (int BBlXgFVzQnDIYw = 1497060998; BBlXgFVzQnDIYw > 0; BBlXgFVzQnDIYw--) {
            FajEpqkSMwTyVq += fFyzZRqaOMWHkK;
            ytblxqciw -= FajEpqkSMwTyVq;
            fFyzZRqaOMWHkK = PXhMeRV;
            FajEpqkSMwTyVq += fFyzZRqaOMWHkK;
            fFyzZRqaOMWHkK = fFyzZRqaOMWHkK;
        }
    }

    for (int AnHXVIRGwshf = 691838568; AnHXVIRGwshf > 0; AnHXVIRGwshf--) {
        PXhMeRV *= fFyzZRqaOMWHkK;
        fFyzZRqaOMWHkK /= ytblxqciw;
        CkxuQ -= FajEpqkSMwTyVq;
    }

    for (int ooeuAzaxhTentFVf = 1570965977; ooeuAzaxhTentFVf > 0; ooeuAzaxhTentFVf--) {
        ytblxqciw /= CkxuQ;
    }
}

string yytXlhD::DbBGK()
{
    string NTpjIkQuhWxmZjZt = string("fXSbGPRJPQOXhGaUSUhviOPAuYPZhLkTeDzCXNTdwTFUljcQKLqbqpDDCBdPKKVDnyOKzsVSgfRbxOmRofBmypDBppCTZNERhFLTAoMeVyddJWEvyOzphEHWrKvIhhgQhlxYPNJKKFwARRutsOnrTDsvGmFKUPfQ");
    double KZSgqvrHkmtE = -716293.2657165641;
    string kbBZGrgPcbjqmtl = string("wLmZXACdROguSfKJNewrxJuEvCxoGtLqBtkFyPgwKRExmZAPxvONhccXrawnhay");
    string osDkcMAXHNMBM = string("pQRMpcRHvPEIwObBDE");
    bool bUpfulRxnCK = true;
    bool cnlNq = true;
    int IsvTwrij = -1403478355;
    double oIqLJJpSA = 889626.6949035394;
    double VfoTriJosFKH = -251645.22561237586;

    for (int khlMTrasbjYmGx = 1183349638; khlMTrasbjYmGx > 0; khlMTrasbjYmGx--) {
        NTpjIkQuhWxmZjZt += kbBZGrgPcbjqmtl;
        VfoTriJosFKH /= oIqLJJpSA;
        oIqLJJpSA *= VfoTriJosFKH;
        cnlNq = bUpfulRxnCK;
    }

    for (int zAhgFYJAtYNDkby = 2077767598; zAhgFYJAtYNDkby > 0; zAhgFYJAtYNDkby--) {
        VfoTriJosFKH -= KZSgqvrHkmtE;
        VfoTriJosFKH += oIqLJJpSA;
        osDkcMAXHNMBM = kbBZGrgPcbjqmtl;
    }

    return osDkcMAXHNMBM;
}

int yytXlhD::YLEQeTVNLOuFum(bool lRzWxNlW, double TloBVsMCMx, string hDELKCtGFNyVfdj)
{
    string sCBSar = string("JRxunJiuZMyqiXPUPBLdYfrwdtfGMLGHdTCkunypFjXFkxeFlgLJzPJUTXByFrySjoFNGxHADIrsMFyjysXCckzKOaPlFOtmaUjQUQAnZxcvZIAQRCnOjOzatitvuDpWAqMqscUlNdKiMzuxkgqtX");
    double BcfiZXAvTpO = -253123.0859646097;
    int egLKsldyxD = 1814326471;
    string SNcDjzFuLBTtEMG = string("YMqmyXqlPTYacYqpUaiNrGtAFRtcCxumxmuOOmhHjiZkYqmvdsCCeFOnIgrOheJwPDMJXPtqciuwTjEQitnOidiArXSAdFzROBUKZIYvKTwTGvYFowRhUxIuhv");
    int vpsdBQSW = 287727972;
    double uZwdQimhYvhpdEIq = -698109.2058976431;
    bool PWCLAyHsuMq = false;

    for (int GXmBBWi = 564839879; GXmBBWi > 0; GXmBBWi--) {
        SNcDjzFuLBTtEMG += hDELKCtGFNyVfdj;
    }

    for (int fChUMyonRYpf = 848424367; fChUMyonRYpf > 0; fChUMyonRYpf--) {
        BcfiZXAvTpO += BcfiZXAvTpO;
    }

    return vpsdBQSW;
}

void yytXlhD::INyKulkSQ(bool yQuiZPbxkaoSz, string xaSJolOUWVyOkCIE, bool iOobDvbOCDypnaXL, bool QFmrzRb)
{
    int lORGzjjNr = -1278983719;
    int pmMUkmzOOUh = 1499347476;
    int WrRFQ = -449970485;
    double XFovTRQca = -753511.8184578432;
    string wuJuhYfCDStGSg = string("jKABElHBTzPfEAItxykwQRTBLqOKtxJHxFVPBgEMQfNgkCLgDHrwjGBlUFCTvEtfHvrloZCxwwFWbLOXcREGAdqgrtzsAtuiQmegSNQUIvu");
}

bool yytXlhD::AmuUEAWNcC()
{
    bool ZHyYfvB = true;
    double TRakWIBf = -155780.33380528344;
    bool KVbaoenB = false;
    int QlwnzCi = 1506604450;
    double qjqqlMJ = 520442.07381929667;
    int axyryzeKRxe = -743193177;
    bool HDEvQNGCLnWTUvC = true;
    string YNSOohzy = string("LjUAxWlTlpbDuhexgdOUfsmjvuiQYGvfmdkNEsulVgPqlCpGhnsULshlFOKACjlTUopyUIdVPTJLDTGTzbsJylXEzHzAZDXuBMLAfgNOmkELcqsgjDWSLiGrWyCuJXBcnMGVRgBeGUTgqkTvim");

    for (int ZZTHZm = 565167419; ZZTHZm > 0; ZZTHZm--) {
        TRakWIBf *= TRakWIBf;
        axyryzeKRxe -= axyryzeKRxe;
    }

    if (TRakWIBf < 520442.07381929667) {
        for (int kftPnVVmFX = 2119083940; kftPnVVmFX > 0; kftPnVVmFX--) {
            qjqqlMJ = qjqqlMJ;
            ZHyYfvB = HDEvQNGCLnWTUvC;
        }
    }

    for (int VLDxwgt = 1714764870; VLDxwgt > 0; VLDxwgt--) {
        KVbaoenB = KVbaoenB;
    }

    for (int WucljBPQ = 85561390; WucljBPQ > 0; WucljBPQ--) {
        KVbaoenB = HDEvQNGCLnWTUvC;
        TRakWIBf = qjqqlMJ;
    }

    return HDEvQNGCLnWTUvC;
}

double yytXlhD::YjTAtRseShJYRe(int xldtfq, int hZtpdXLTsCWRxNW)
{
    string iQLcorXUaZaEB = string("nPcRNeHZhVYsmJPgpRyskxheuhMQzzolHhqhBTnvkLU");
    double CIaXNwYrBiz = -668697.7619890284;
    double RedWOpAzrJC = 70841.62024559877;
    double hyWfIxhZcNdgG = 123958.80618400915;
    bool KoseYVonjcOBvqVX = true;

    for (int oNIFotPAlo = 2118373242; oNIFotPAlo > 0; oNIFotPAlo--) {
        hyWfIxhZcNdgG /= CIaXNwYrBiz;
        RedWOpAzrJC = hyWfIxhZcNdgG;
    }

    for (int RkbiYUYZUQwi = 874311851; RkbiYUYZUQwi > 0; RkbiYUYZUQwi--) {
        continue;
    }

    return hyWfIxhZcNdgG;
}

yytXlhD::yytXlhD()
{
    this->NkfhWhRCE(string("DAiLWQiUviufsYGfghqPEFeBrRwpEstLRtDBSrtbeMOVDSyGlMoGleElqPyBZLmJXZpYZtJBUhbGhZgzhUPJBYPTVUolxjNJdFLVdRNWrjzZQJntcollbKIAgWOBopzEXfnHFaaLcbvGsfrzXMYoCdJHtdizWgjBpjfuDScEFnKzbGnoVqQNMQSRRwwZNhFtXfeKlmNazfSagOsABPrcZqAcBPGHifYbkDLQXsJQRPzpNLooicMrQMKOLfhYf"));
    this->yKEWlWhGPRnd(string("pEMTqehktkuBLixtiIq"));
    this->ZpRutNTed();
    this->DbBGK();
    this->YLEQeTVNLOuFum(true, 554002.6280956983, string("cdAPPGJaIedfUdtpimrkxjSrhttPtphFRdRCXlLlMaPPhvhifpfnhBqKIXnIeIrowqAcAfHzeMbxVLmHsqRMnxgpOeQvnTPsfWonhAASjpSYVu"));
    this->INyKulkSQ(true, string("LXtfNgCOtmSCxJCSwwTrRXjGjnUvoCTZDAjgKGfgdCVqERsVUlasMmezhCAM"), true, true);
    this->AmuUEAWNcC();
    this->YjTAtRseShJYRe(-83844045, 801523165);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uhBLDZClzbn
{
public:
    int PmYQp;
    bool LymErvADyC;
    double rLFoYk;

    uhBLDZClzbn();
    string IMtNGhvr(double NlJrbXoOi, string NgiMrO);
    string OLxYySVuh(string aEbZEcj);
protected:
    bool CczXdqgY;

    int UaJGlrxjNSF(double zhZfFACam, bool QJvEHE);
    string TlVRCBwcm(string rizDEo, int xQbqanDfeH, string nYJxNkOwlethC);
    string qEeGyXIEsXPNf();
    bool xFPNdxzfCOHz(bool xxmsIgT, bool eLLcmWKsVPYMLcu, double sZyLSKxPdhdvBI, string AKKsrZHehlFpFruQ);
    int VixaXqWlWo(double jcMmihFoYmhYdQ, bool tbzKGSYhs, string tdliVLtK, int xxrzc, double YYPypfDPla);
private:
    string ZbYBgept;
    string kxslOf;
    double VZsfGZ;
    double duXOkKI;

    double BKerZyqCVPC(bool oUSzmP);
    string zhUKvLZVnu(int jZQzvZQtwWYz);
    int udGunh(string psNRr, int GjOuCMoULfo, int gnemrTlWGq);
    string nINiB();
};

string uhBLDZClzbn::IMtNGhvr(double NlJrbXoOi, string NgiMrO)
{
    bool JnbPSBz = false;

    for (int ajDRGFJN = 1111591436; ajDRGFJN > 0; ajDRGFJN--) {
        NgiMrO = NgiMrO;
        NlJrbXoOi += NlJrbXoOi;
        JnbPSBz = JnbPSBz;
    }

    return NgiMrO;
}

string uhBLDZClzbn::OLxYySVuh(string aEbZEcj)
{
    string dDWUmciQogmMwEya = string("DsJGlpSGARfHPyoQJzQSohrcwayotXJmsrcUeEHKBFodQaYLaFVMrFmNXGqKDBrgYNzSXVQdXKtWBqrkDWdrnoFfbrIoaPGFhMaqQRlTOdgBXlnDJnlhiQEFBuUFvaXasLnaluVgmCmrrdSKLeivdvyrYjxgjXKlNxSPQwBCNMMHSuzOxEyGzOXTCtVhRfU");
    int uxoAohWOw = 1596099759;
    bool kilACnpU = true;
    string lvEDJgCTWbYu = string("YxXZpeaKxGdEvtYSMsvZxpipBJACcMHhHkxLJXjAypoviPTolNzjoXanCMxBvokFfOt");
    int hHtCnkcfkoaelXa = 1125933585;
    bool NFufproeCba = true;
    string lNRqLHvwbjrlXtJM = string("OmYidgCDVZfyXnbxj");
    int TmBbn = -1482487224;
    double wOAxT = 667328.970941998;
    bool mcEvZmUa = false;

    for (int lNYPBkkJig = 1580560371; lNYPBkkJig > 0; lNYPBkkJig--) {
        aEbZEcj += lNRqLHvwbjrlXtJM;
        kilACnpU = mcEvZmUa;
        uxoAohWOw *= hHtCnkcfkoaelXa;
    }

    for (int OmCyzduKChysBJ = 320424241; OmCyzduKChysBJ > 0; OmCyzduKChysBJ--) {
        uxoAohWOw *= uxoAohWOw;
        lvEDJgCTWbYu = lvEDJgCTWbYu;
        dDWUmciQogmMwEya = lvEDJgCTWbYu;
        lvEDJgCTWbYu = dDWUmciQogmMwEya;
    }

    for (int PsyXVVEE = 263707453; PsyXVVEE > 0; PsyXVVEE--) {
        continue;
    }

    return lNRqLHvwbjrlXtJM;
}

int uhBLDZClzbn::UaJGlrxjNSF(double zhZfFACam, bool QJvEHE)
{
    int oUJkqFiYPCPvwxxa = -460097602;
    string aIofMZKSMZvjw = string("ldDYxAbKoYgBjWLoGTcqwWlzFkASlLkmrbvDruxUmXdmfxrEPRonyssLYwuEkAHCRmCxwIQuEAINhmapwDJDxiVlPnbUttGBaBYsPLZvISODDfCsVvRFXcVdPsbkimqeWHY");
    string rbbBPhIXC = string("YnDBtOkodOJIgWRCpEJeusGRSZsXFAvfwuaAXTDbSosXziuHLMijRcfdecfNQQrNZfEIGWVeCfMXTzPdVWJjmwlIwCXNgjmICJLAYbMzCyPKGfbHKzdLJQSTCyOKtHehmShwEHZRXrnUEUFOVVJNjjoDVwPzrwEQLBZqZeKRziuFFNpdYuqPKcpxzKjbTGmPdViRsvyXHcryP");
    string JDvGJfbKFwK = string("JyLzOnnHFdhgwKsojjLqlZZOvNnpMyUprfOUDlujUOXLxlibUCQjnMnQlZWHioSUmpchsPXqvugKaoFZNBj");
    string MDSzoo = string("yNynhUHUtlvNJWtLZXvARzuZOcDGqMndEkBpoKEjSxLdYDTtgEHkckOHmxFIgSabjCuxyPomRMYvXRoZGyqwnIqDm");
    int QDVTfgTZcCwOyTQp = 511716060;
    double dNBzWQr = -752343.5638123234;
    int VbBsPEwptIgMV = 2018441772;
    int aIGwkPugxIWYYxer = 1105889537;

    for (int YlAKfc = 962827668; YlAKfc > 0; YlAKfc--) {
        continue;
    }

    for (int QyOsNeqU = 1246979991; QyOsNeqU > 0; QyOsNeqU--) {
        dNBzWQr -= dNBzWQr;
        MDSzoo += JDvGJfbKFwK;
        aIGwkPugxIWYYxer += oUJkqFiYPCPvwxxa;
        aIGwkPugxIWYYxer = oUJkqFiYPCPvwxxa;
        oUJkqFiYPCPvwxxa *= QDVTfgTZcCwOyTQp;
    }

    return aIGwkPugxIWYYxer;
}

string uhBLDZClzbn::TlVRCBwcm(string rizDEo, int xQbqanDfeH, string nYJxNkOwlethC)
{
    int lENDPPGe = -2017323136;
    bool lfXYitVIwGklINf = false;
    double onNjqwae = -73411.58643051122;
    double ZjwptuZ = 680500.5860597845;
    bool uweRUdYU = false;
    double CmkkjdWQjflEDDJ = 362431.3031979135;
    double qJqOHzUWxmZlZhox = -389651.3458322982;

    for (int QuBMdmPXIPgdtQyN = 1540545186; QuBMdmPXIPgdtQyN > 0; QuBMdmPXIPgdtQyN--) {
        continue;
    }

    for (int uUtDYUG = 949839988; uUtDYUG > 0; uUtDYUG--) {
        uweRUdYU = lfXYitVIwGklINf;
        onNjqwae = ZjwptuZ;
    }

    for (int dAonwQVVstCnfpf = 96622693; dAonwQVVstCnfpf > 0; dAonwQVVstCnfpf--) {
        CmkkjdWQjflEDDJ *= ZjwptuZ;
        qJqOHzUWxmZlZhox += ZjwptuZ;
    }

    return nYJxNkOwlethC;
}

string uhBLDZClzbn::qEeGyXIEsXPNf()
{
    string sGqPbXImMyXcP = string("tcBkQkBFLwyGyxoWdedFkMnhmUD");
    double eUiJR = -599390.8277835955;
    double CygRy = -896038.3320016881;
    string bOOzYpbDd = string("yoTFdDbvHQuFSXrFeEzPFrubjRVHcWXHGZvsGXwIHyNtRfBxTqORNqwsYeeoAHOwiDXPOcTTcjmsFlDIQvjgVJmUEbPatSMjefahbxzPPpYqNNFXpyjSpzmYOcgDNQPkqXkdtGkLtOYpkfnIjkrirrUUIGovLNKRkeOWOfLxjPseEoDBvplNwQFESwZbTsyKNWUIGzoIruqAgVl");
    string HGsXK = string("HKDeAZWYHrYbzKgaYowfKWWWSTjUnFyfEqAWiuuAaqxkVgAVCoahCzVaLVHckakTBVjvJSubeATZLqcAIShrSfCrBmwIFylolwWfIPwqXJnRiKjkzyVtEhHmNTuAAWfigOrgkCqHZHmUeelfbVyefPhSdamGiaJXygRvmYhdjlrkmHEAPsdijti");
    double jICMSQ = 756321.8032794765;
    string TPpTvyNjvq = string("bFuOAOndALfwFDpORefkVHgHGXWyaDccFVzgpcFLPZGbPmhqdjVzqSXvqVANdQqUsFGQnctRbMNrqYNdfvUXBHagZyoGvXlaNjtCiZoosUBSiMioGpNYQCQEIkZouVOYtdqoGWUuxuXRKeOdBvFYGWYnEkwTtJCcH");
    bool FYquBdnApkVywu = false;
    int yxvfFxqoa = -691973667;

    if (HGsXK > string("HKDeAZWYHrYbzKgaYowfKWWWSTjUnFyfEqAWiuuAaqxkVgAVCoahCzVaLVHckakTBVjvJSubeATZLqcAIShrSfCrBmwIFylolwWfIPwqXJnRiKjkzyVtEhHmNTuAAWfigOrgkCqHZHmUeelfbVyefPhSdamGiaJXygRvmYhdjlrkmHEAPsdijti")) {
        for (int PTPckSmzjrgnw = 672032903; PTPckSmzjrgnw > 0; PTPckSmzjrgnw--) {
            continue;
        }
    }

    for (int EoGsmIGfOI = 585200061; EoGsmIGfOI > 0; EoGsmIGfOI--) {
        CygRy *= CygRy;
    }

    for (int eOaLRvbFz = 1186055500; eOaLRvbFz > 0; eOaLRvbFz--) {
        sGqPbXImMyXcP += sGqPbXImMyXcP;
        yxvfFxqoa *= yxvfFxqoa;
        eUiJR *= eUiJR;
        HGsXK += HGsXK;
    }

    return TPpTvyNjvq;
}

bool uhBLDZClzbn::xFPNdxzfCOHz(bool xxmsIgT, bool eLLcmWKsVPYMLcu, double sZyLSKxPdhdvBI, string AKKsrZHehlFpFruQ)
{
    bool SAQhz = false;
    double xzgcyqowKMY = -11001.030732072224;
    int GCyLXhGZrWrz = 381331627;
    string YNMDVdXWLkhllCwL = string("NKEoUWuznpCMCelnJnMcNbVdhqluIJQNEbYHCAVCycKqjBXEmVnYkmgOesxNanWHOLwrVurZRbzkuPCOjcjedQfBHSmJMtCaztGZinNZkBjrgSXGCmNUcZJYpQbpKOPZAsLLXndfwNJkLcayGVbCRngsjPZxw");
    int rtXiiNErDd = -2043837259;
    string wiSdPYg = string("tCtgIrtsvWVhffpwmDL");
    bool RFxgTIupQcO = true;

    if (RFxgTIupQcO == true) {
        for (int WEMLmC = 705336926; WEMLmC > 0; WEMLmC--) {
            YNMDVdXWLkhllCwL = wiSdPYg;
            YNMDVdXWLkhllCwL = YNMDVdXWLkhllCwL;
        }
    }

    for (int dRvZKqbuyWhcelW = 2007343192; dRvZKqbuyWhcelW > 0; dRvZKqbuyWhcelW--) {
        sZyLSKxPdhdvBI /= xzgcyqowKMY;
        eLLcmWKsVPYMLcu = ! SAQhz;
        YNMDVdXWLkhllCwL += AKKsrZHehlFpFruQ;
    }

    for (int KoepPmnYeRcuyMzm = 555918070; KoepPmnYeRcuyMzm > 0; KoepPmnYeRcuyMzm--) {
        continue;
    }

    return RFxgTIupQcO;
}

int uhBLDZClzbn::VixaXqWlWo(double jcMmihFoYmhYdQ, bool tbzKGSYhs, string tdliVLtK, int xxrzc, double YYPypfDPla)
{
    double RVkIZsWcScOOr = 374615.7191609133;
    bool XdzsOuZCSAUYI = false;
    string JHppMuRMzWwR = string("bYVkvHVircpVOeaUswSBBNKwlBAtCcnDDFtIAeJjDtZhCHCWPmqezgNMJKcYeOgkitrjQIkHnwQGlcqbWYEAoGbacIP");
    double pmVenrL = -387450.5485595243;
    double flYfuGCE = 866217.5788955718;
    bool NktlNlJ = true;
    bool YZXvVyTktt = true;
    string sSzZEaOvxhcFIDMi = string("cFHOGVvtfDTOaMHNbnpNELDnmkxvCpZaduOQXKPspDFujnmEUqGwjKFMOCunshjlyhchiiEzBEjVMaYpcVAfQFhFRqvALyFNchxKRIShsImmLKNvleMPVyURugxmHQbwtYcQkPoCllbMgLxuOYgUEsEQeGYdgvSflyGjhoBHawjEjtyHMBMXvlrnbNGNRnyGJDsAGepFfLHyNwoMhvAqHymDNdeRViuPuwjOyQIpK");
    string hQAPymnC = string("HbeJijdCinkwuKnmTdDCaJSmXhVillmuHDyzYYLyktxKywyVqibgorsklT");

    for (int ZGQxkOKKNciKqjS = 1796449398; ZGQxkOKKNciKqjS > 0; ZGQxkOKKNciKqjS--) {
        RVkIZsWcScOOr = pmVenrL;
        JHppMuRMzWwR += tdliVLtK;
    }

    for (int pJjbVGXFPOw = 872211966; pJjbVGXFPOw > 0; pJjbVGXFPOw--) {
        tbzKGSYhs = ! tbzKGSYhs;
    }

    for (int YkFttagndpa = 793170097; YkFttagndpa > 0; YkFttagndpa--) {
        continue;
    }

    for (int lPTDNqnEzDRNUc = 197237992; lPTDNqnEzDRNUc > 0; lPTDNqnEzDRNUc--) {
        XdzsOuZCSAUYI = ! YZXvVyTktt;
    }

    for (int PaUMuIcSIEa = 1337387442; PaUMuIcSIEa > 0; PaUMuIcSIEa--) {
        continue;
    }

    if (XdzsOuZCSAUYI != true) {
        for (int rrccUsvpPUPbJq = 1587119727; rrccUsvpPUPbJq > 0; rrccUsvpPUPbJq--) {
            YZXvVyTktt = NktlNlJ;
            hQAPymnC = hQAPymnC;
            XdzsOuZCSAUYI = ! YZXvVyTktt;
            JHppMuRMzWwR = JHppMuRMzWwR;
            XdzsOuZCSAUYI = YZXvVyTktt;
        }
    }

    return xxrzc;
}

double uhBLDZClzbn::BKerZyqCVPC(bool oUSzmP)
{
    bool zimmnCGshYnb = true;
    double jqlkMibtaiw = 907804.7273327695;
    bool AFzcBAuCIjgjE = true;
    string otFtUNSUFEEtsPPD = string("OcZlaDqvfmsyzcqeOwGdxCaitRSRLRJvhvISBedlX");
    double tiZyqVxIiYMl = -368457.39394562214;
    double ZdHtMah = -731872.5072389954;
    string qKCRo = string("lPqoiPDOBkCLexEAGqEPzONCgpXgGLnxMQAtcPPpJJLMpfQhqGYdGqxUWycyakGcVQuSBdFLmHopiTxXMrKRyTiUbdjsjhxHjVWABNPNcSZhbbBoVXCJdmkaEPNnKFuOraDjcszKRtsklciqCtsOoNGUdSayOfCEhCQRatCmdndlGNRQxKuWVRN");
    int MTWTFNYCqRHiDWe = 481634331;
    string zQrldnACM = string("uXmjhvXDGEuJSBikjTiHZiDMrZdDOxahASdDeAVffJdRvjtlTYqSWCeYpGXQjhdSGxZibUHMcJCwGzCZXjsdmaIVUehpKncbSYyMUeTpzbLszgo");
    double dOymW = -445358.6480144712;

    for (int cxLmRBxLSvWbRyeF = 2030888801; cxLmRBxLSvWbRyeF > 0; cxLmRBxLSvWbRyeF--) {
        qKCRo += zQrldnACM;
        jqlkMibtaiw -= dOymW;
    }

    if (tiZyqVxIiYMl != 907804.7273327695) {
        for (int wNvfP = 782955675; wNvfP > 0; wNvfP--) {
            oUSzmP = ! oUSzmP;
            qKCRo += zQrldnACM;
        }
    }

    if (dOymW > -731872.5072389954) {
        for (int GkpqnKfp = 1030484445; GkpqnKfp > 0; GkpqnKfp--) {
            tiZyqVxIiYMl /= dOymW;
            ZdHtMah = jqlkMibtaiw;
        }
    }

    return dOymW;
}

string uhBLDZClzbn::zhUKvLZVnu(int jZQzvZQtwWYz)
{
    bool zgoxYQAIOy = false;
    double UhHnVuC = 998882.7526655006;
    string MKtVqW = string("hZKPdGjuAxiydngxXvCdxdwKvIJDvHlNqFNBKJLuwElYgVGhUvMbUHvnzZnRXnTTOMxYlSNFTZhhyxFRhfnrDyuumVGsAgddhUVZoSrauldxBAirjqIjWiXBGAMpxqFNkSnvfKBZojEFHordnWfwPadpuOtTPKrnckQZPiIsWqoRBwwdUPuXCBrozCmzYFDisyjLuNYxOUaWTAgCGOQnbkJw");
    string GHfQrSpNaViixszV = string("BsseMbEO");
    double cDTZBzaF = 754958.3010457437;

    for (int zddhWzdTGckHqHFA = 2036687833; zddhWzdTGckHqHFA > 0; zddhWzdTGckHqHFA--) {
        continue;
    }

    for (int WXuHyqzTOlYG = 1957520815; WXuHyqzTOlYG > 0; WXuHyqzTOlYG--) {
        GHfQrSpNaViixszV = MKtVqW;
        MKtVqW = GHfQrSpNaViixszV;
        cDTZBzaF /= UhHnVuC;
        jZQzvZQtwWYz = jZQzvZQtwWYz;
        cDTZBzaF = cDTZBzaF;
    }

    for (int lqZDp = 113992735; lqZDp > 0; lqZDp--) {
        MKtVqW = GHfQrSpNaViixszV;
        UhHnVuC -= UhHnVuC;
        cDTZBzaF -= cDTZBzaF;
    }

    for (int rlCOfMybB = 941772363; rlCOfMybB > 0; rlCOfMybB--) {
        UhHnVuC /= cDTZBzaF;
        GHfQrSpNaViixszV += GHfQrSpNaViixszV;
    }

    for (int wrrXCyZYFaaUY = 694362; wrrXCyZYFaaUY > 0; wrrXCyZYFaaUY--) {
        MKtVqW += GHfQrSpNaViixszV;
    }

    return GHfQrSpNaViixszV;
}

int uhBLDZClzbn::udGunh(string psNRr, int GjOuCMoULfo, int gnemrTlWGq)
{
    double ICxhJVKQs = -246024.7321698899;
    string BSAMMwbQbzLI = string("AfwyYvxTaXGCMwPeRNkCAXMDTaQIAeKhlfVWpuTgQwWXnucktaCpGEzAaOxVrEOISolnhsYUGgkEECsEnDorMgapRsYjTHhaLxTqMyUCDhFHGrTSTBdSHlfoIESrPiwYnPMztkPZjSYZeDRKJQDOzQg");

    for (int qEHsssKKWamsBtl = 948447307; qEHsssKKWamsBtl > 0; qEHsssKKWamsBtl--) {
        ICxhJVKQs += ICxhJVKQs;
        ICxhJVKQs *= ICxhJVKQs;
        gnemrTlWGq /= gnemrTlWGq;
        gnemrTlWGq /= GjOuCMoULfo;
    }

    for (int JJhuhNiRVBw = 1903428385; JJhuhNiRVBw > 0; JJhuhNiRVBw--) {
        ICxhJVKQs += ICxhJVKQs;
        BSAMMwbQbzLI += psNRr;
        GjOuCMoULfo += GjOuCMoULfo;
    }

    return gnemrTlWGq;
}

string uhBLDZClzbn::nINiB()
{
    double cvVrDNdkxPNH = -165907.3829383894;
    int sfFCsVGpugY = 1857531211;
    string MRbEZasU = string("FYjyoBZrpOxmAzDmCQKVpfGYRIOslhhYBrdCKzoyPAuMaqzdQIfgwbhTCTkTwYXAhRGckQNHENnawkrJSnWbfBKkCbrKqTazzlXnfxLjqiuinIfOvMsBwZZSfrfFDutmqyMuxAlArSizAHvkiRGZxvbCMTewaqlgoQSsuzQkgMqFldduEmqMmYUalskdkVvtxkEBLFGkWMFjLvMUByBOpWaPQaKJlzIokeHPSQ");
    string GnYncswPUEfhNO = string("oebGdnuPijBIkcEWMljnSuJsYcqszNkZbjQJWuifQpfsauJuocgAnNPOnwmIjMRpUDxaKOcErwqdBNnJtWjqwenuTWAdjbiWzzlaqJmbRSzgluSTXPVeAFGIkwyjpwMkHtBZJcJnASyFCnxc");
    double FtGjlcAeVcOL = 396568.6175725913;
    int FyLbVNYjXL = 493424285;

    for (int UNzybcV = 1563796668; UNzybcV > 0; UNzybcV--) {
        FtGjlcAeVcOL *= cvVrDNdkxPNH;
        MRbEZasU += GnYncswPUEfhNO;
    }

    return GnYncswPUEfhNO;
}

uhBLDZClzbn::uhBLDZClzbn()
{
    this->IMtNGhvr(483232.0602486671, string("IzgpJpBJQTxczCsXniBOJCDuReXhTnAvFjRYLxWHszhDynqADsKkncXHmddQNxeiqaIBnC"));
    this->OLxYySVuh(string("cvTEKhDJbSvsplUlwXgjovYAzvodCeOySgXQjCdNOfshgrSwTiXGDguxuzRZVtZdKCVSgLEhfvnKSZXlGDNzdPFZxBYvJjWCwTAHBDajCvfzWFrZ"));
    this->UaJGlrxjNSF(-612782.6290699975, true);
    this->TlVRCBwcm(string("MxOHdiYtMlDNDttyknuOHubomfiPpqcXDylqoFEIhHovEhgdackaZWiGBVOvQKPmOIqyEpqzkKOTDBlwRglptwvKMbWTyPDOacmcMBtDazILczBjLXvfwSUijoKmIWzLLEqlHCZdUXnLQHTmidmEuVIFgDJMUvFRKUljVgop"), -19657299, string("ssJSNYUpGmuFkQXNKUMVVgDyCTXYqoKEcXUBcWTtjYchqqmPlvCxMMWJTwsFjLFvPkokjBAlIRgHAfDVoSgVdAwNskUoUsUtPmUTZsjUJgpYmcYjHApKpgWwnUuCWEXoCuUSToXJYtlGgAopHpOOOJVIUHixneYEXLxeYZECRVwWEMtMlFNqvJNRNJJfREEblAstvtWDvMROIrgmROGwNGONfRUKLQzudYexlZOWqZrLvmWbISyyQsD"));
    this->qEeGyXIEsXPNf();
    this->xFPNdxzfCOHz(true, true, 18398.35971005619, string("EzIHhhQsNGUevLvwmOraTezFLjhJSiTzCFGeGkgDRXahcxKQqyRLyguJtXFYlcwChAPvcbAlolEcumlldWlIEFfBqHyqHigtnJaFuLPdwFQjKVJMYmEYydNVwTdgTnutmStxdUZXPiyJpymMuDZoxRaEBMiDznPPIdRtPxrLuYzNNDTPohdyWNszRzMcOiEXLoUCqjpqQGfHd"));
    this->VixaXqWlWo(-971864.4307238852, true, string("qQrsHnKnegZrfQeHrvEhDibKBwBGJCzJXODjtfCwexXgojdVrlMyfDQvcZsDNFC"), -1780653423, 743737.8201407096);
    this->BKerZyqCVPC(true);
    this->zhUKvLZVnu(1881745398);
    this->udGunh(string("xsedSlzRxorHThnIbxlrtUEtQylnMDsbUgaryboMMwYIUmolPrfCbTZHjJQgqRBzmhavaNDrgfGGQZpVZHotyztGtrRlVGNouOjfKhTfKkfROJHTYjMKZSbgAponmNkGqLQICKcmPppNlVBOTzhTwHubLDRybKPdghTcloQXYMZYSduSI"), 1863061744, 1605045331);
    this->nINiB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hDmfkNaRiRDyuQG
{
public:
    bool GdiBPqdOqyQ;
    double TmDrCcHHT;
    string qLDqXTCxtpp;
    double KVHZDquF;
    double voVTIPB;

    hDmfkNaRiRDyuQG();
    string hVzRuzkrCtNZdi(double WXhDOuu, bool IGubP);
protected:
    double acuYLllYLyrn;
    string GxwOHpIft;
    double JOxVKz;
    double VkIcGMWzQOzWhCMr;
    string BxwlZRMMMAdTiNB;

    bool ClawVXaEupVz(string UPcqDDPn, int NzjgAbwpkA, string wcjCvQbEaXejbjxy);
    void NVTyMxoBJ();
    int LLxJjCD(int IStuhCVAkr, string wTzICR, double uxCBbLiEuPXY);
private:
    int LDGaxHnLnxHQxRH;
    int vupjlXVDO;
    double wMIHSQxG;
    string yEssqsaOku;

    bool NOHEPtfmNU(string nIGeSPgjhfDe, int WqOTJZQBmhk, int zXcOUCfHzSPu, int hmeTklVzbi);
};

string hDmfkNaRiRDyuQG::hVzRuzkrCtNZdi(double WXhDOuu, bool IGubP)
{
    bool ufIKqBlIXrVwppnh = true;
    bool IkLSHmt = true;
    int CuQIMMsaWdl = 751040940;
    double whPvvDZqvPAJGmAL = -894028.1434162698;
    int SnHCjOxWawYakxGO = 571776052;
    double VQnrxmHJKu = -490793.12132859963;

    for (int jXeLRxzEu = 1748334767; jXeLRxzEu > 0; jXeLRxzEu--) {
        whPvvDZqvPAJGmAL += whPvvDZqvPAJGmAL;
        ufIKqBlIXrVwppnh = ! ufIKqBlIXrVwppnh;
        IGubP = IkLSHmt;
    }

    for (int GurbnnRkwKmuL = 1375777793; GurbnnRkwKmuL > 0; GurbnnRkwKmuL--) {
        whPvvDZqvPAJGmAL -= whPvvDZqvPAJGmAL;
    }

    return string("JgDykcEExrhfcisiKlOrrVLIWdIRzrWwsmDUCrxSLGBrejpTUqzUMNtiuHtOZmLouijqDCtgBPqxo");
}

bool hDmfkNaRiRDyuQG::ClawVXaEupVz(string UPcqDDPn, int NzjgAbwpkA, string wcjCvQbEaXejbjxy)
{
    string eGRPFxmnX = string("GBFyQrkodEXweDmSgTBtYGRxHCSaUGeuYDgTIYSODAMGutUVgACfRwzjHBktzFmVPPKWOoWVpTmvPLszjXQPIAtDqsAbLZhKVjsIBrWwuqsSjBJdCfhiKFzxNZqKkxvzkzSqOrctbrBFxbOtMWUTnqhzqqoGOi");

    for (int aqpqEjmbSgYu = 384698544; aqpqEjmbSgYu > 0; aqpqEjmbSgYu--) {
        wcjCvQbEaXejbjxy = UPcqDDPn;
        eGRPFxmnX = wcjCvQbEaXejbjxy;
    }

    for (int PGieN = 521922695; PGieN > 0; PGieN--) {
        wcjCvQbEaXejbjxy += eGRPFxmnX;
        UPcqDDPn += UPcqDDPn;
        wcjCvQbEaXejbjxy = wcjCvQbEaXejbjxy;
        wcjCvQbEaXejbjxy = wcjCvQbEaXejbjxy;
        wcjCvQbEaXejbjxy = UPcqDDPn;
        UPcqDDPn = wcjCvQbEaXejbjxy;
    }

    for (int GHzamT = 1752270063; GHzamT > 0; GHzamT--) {
        eGRPFxmnX += eGRPFxmnX;
        eGRPFxmnX = wcjCvQbEaXejbjxy;
    }

    return false;
}

void hDmfkNaRiRDyuQG::NVTyMxoBJ()
{
    double UmbxY = -1013841.6021520137;
    string dhgJUqVABvbH = string("GddSfyKzZiXOplsneFAADStvLYrLTdbOgBdoOtSWNBLCDxcKyKMYAEtppUfRYxrVwglPVvGzLwucykmB");
    int ZDpJdsVplLAigKy = 1593038933;
    bool zaaJXBwt = true;
    bool DrrpwmODhpRC = true;
    string DNoEyPrVMSk = string("pyQlIjyRgeBvJFAyuiDBAYAXIjtQBRQyZBMbHFiSmuOrDAWshJeJBBxyUbTNyixjutGIbNPWxD");
    double SxqqgVAUXjYBkeg = -768397.3273719151;
    int ltdWJmkhaeVOKl = -1391104967;
    bool qFWKUSyj = true;
    string NIJmItttdN = string("tVnJhGPTXSnTyZXgeigtESnWJYhldKvFpXlMdyColBKJWXRfZJQJpCjtzyXIQhRKkXXmqmughRjJbMbmwZlWyOnVBMYrFeygIJbqDOIlZxgdguGFwLwLCHjXkkVMsEjsAcAPnIJmOPaV");

    for (int vGxdeMzxgWXz = 2030158358; vGxdeMzxgWXz > 0; vGxdeMzxgWXz--) {
        NIJmItttdN += DNoEyPrVMSk;
    }
}

int hDmfkNaRiRDyuQG::LLxJjCD(int IStuhCVAkr, string wTzICR, double uxCBbLiEuPXY)
{
    double PZkCaIKXY = -462095.45073779643;
    string NSqbjPooiJ = string("gnhEEHfabAhZeuhfHflEWdxBqZBKlmwEYTLPQtubPfLsdIOFnCHuJoFrkLjQACkdKMcohbBtKfGXzimxrbpDrgSNBPPSyRRaAiDbGVrGQzpcoUNgDlzxOOsIuknbSxeShkVDcnVYEnyAiELnxGzjRJWAWYgNTXxLsZHwoPPizbiNVkCdjIwduyWtRkfhItPNzka");
    string dHeLfWw = string("RDtPNgZvFnnCbwfEtnHtqwtoN");
    double jUAcYt = 799948.1875865023;
    string RcmgY = string("DAchsEfPFFinXehomluzZzsxdLrZjtHYvnWPJcSxAFYqmcOAUOJDgCseYKVlwTCETuZRwUhvGpcDSmleYpyUtfGekvbDfFFuzSbNGSyoTTAYGxmDeeZroLhSgdNiiJyeyeUptyjOpQPBvKvQDUjjVwDxWxhmIocbbuKGTYbTqaKYrqnGJxkhXeqMCdmJbTrLkGDsTbmtgmByTElrUmRmDyzCtFCsYQ");
    double vYnwzTcA = -120758.95607721443;

    for (int JPvUR = 2124439008; JPvUR > 0; JPvUR--) {
        dHeLfWw += wTzICR;
    }

    if (PZkCaIKXY >= -120758.95607721443) {
        for (int RwYpOlF = 1774189027; RwYpOlF > 0; RwYpOlF--) {
            NSqbjPooiJ = RcmgY;
            vYnwzTcA = vYnwzTcA;
        }
    }

    return IStuhCVAkr;
}

bool hDmfkNaRiRDyuQG::NOHEPtfmNU(string nIGeSPgjhfDe, int WqOTJZQBmhk, int zXcOUCfHzSPu, int hmeTklVzbi)
{
    int CJvZOWqqQjXOp = 738210413;
    string nMRInTY = string("kcLqYKazZrgofKhzoIGHNmrceJmlRWwqBfqUsnYfKoZHszvansmdvWHqRTqqrZdVSdQVWOrFOdgWfDtbUwsXuSGePMJmCWunOmgZqDVTxwklfSIBrmKcqDBCpEmiiKAgoZMkyEMkpmIQfNvqIFyKjLBNMNsuLKQuQPPwFoBpdyPbUdvOuFGuziPXGfjVxXQMuG");
    int MAcVDEegOt = 844188357;
    bool QYOxclYtTiS = true;
    string erWHrwokherLaI = string("cdRXmmGmbAaUQMuRqMCVsvfdGMAwptMynYVTyjEWDlAsLadUohLBUIbkaHqEoQphjVlqwccLvYmcnQiRajDVFpJJSQMemDqVAoewDItTxpFmJMDnKiSsBAtLbAQzUMDChGnpZhJyBpjEimLRvykuDFtXnNbXUfAXyp");
    int jdvTBaQDxIH = -1205684265;

    if (WqOTJZQBmhk >= -2099847946) {
        for (int izALapqPvlvLtnk = 625946124; izALapqPvlvLtnk > 0; izALapqPvlvLtnk--) {
            hmeTklVzbi -= zXcOUCfHzSPu;
            WqOTJZQBmhk -= MAcVDEegOt;
            jdvTBaQDxIH = CJvZOWqqQjXOp;
            jdvTBaQDxIH += zXcOUCfHzSPu;
            erWHrwokherLaI = erWHrwokherLaI;
            nMRInTY = nIGeSPgjhfDe;
            MAcVDEegOt -= hmeTklVzbi;
            zXcOUCfHzSPu += CJvZOWqqQjXOp;
            CJvZOWqqQjXOp *= MAcVDEegOt;
        }
    }

    if (nIGeSPgjhfDe <= string("cdRXmmGmbAaUQMuRqMCVsvfdGMAwptMynYVTyjEWDlAsLadUohLBUIbkaHqEoQphjVlqwccLvYmcnQiRajDVFpJJSQMemDqVAoewDItTxpFmJMDnKiSsBAtLbAQzUMDChGnpZhJyBpjEimLRvykuDFtXnNbXUfAXyp")) {
        for (int KCsWumKRtLpGqbZ = 1408904252; KCsWumKRtLpGqbZ > 0; KCsWumKRtLpGqbZ--) {
            continue;
        }
    }

    for (int VzkqqvKr = 1691939147; VzkqqvKr > 0; VzkqqvKr--) {
        hmeTklVzbi -= jdvTBaQDxIH;
    }

    return QYOxclYtTiS;
}

hDmfkNaRiRDyuQG::hDmfkNaRiRDyuQG()
{
    this->hVzRuzkrCtNZdi(-28887.647587528332, false);
    this->ClawVXaEupVz(string("SWRovGCooZXpEmDIKJHREzpAAfDgdjZgFqeWguYrzWsPEMtUlmHMuAddJGJrXRBwfExndTTGTVWiWZoeulNEmQlxAdsVSvTOKaydlgssnaZdZawDLkwrVAsZfmsQuXsVbZcxcJVqIQKoctXPpISTS"), 590231442, string("nRlwlIsZuvytXJPkWCmDMuwDwdBbmxPzZazgcixcdInTFNdmMhqgOfHTnMfQXePuuErzmcsCYVdgRYJDfztNzSOkpmWoscoJcypCPhSFgrybgoxyTZRCgcrZxOpxlRbJGKCpnBBclyIbnAEQfXlyBMIfJbTtXcwUp"));
    this->NVTyMxoBJ();
    this->LLxJjCD(-668627320, string("ClbJtJiMNdqnSIpELwJiXHaOYEmEFDREWEgOQavptiuOpXajNMRYYFdIBYmQlFWglsuv"), -300349.74828092544);
    this->NOHEPtfmNU(string("qBadttVitXVBuPpxqkkxHCPQAmbrxDYchXzGbTIPybZByRBPThXkgZRPCunRruDbkkparNSjHMOQFqhIggmCVXcAIvvZLkvUcjJNExyADWtPOVlvYHJQUsPpAZblERmudfCCGJJYwAffNhlRUafasCjlVMYGDaxbvABLtbhDvXRSZvLWggvliXecGQeWINYjBCNOIXMyysaJUvWtXqZcoUdoXoggortyotcjM"), -1721017928, -2099847946, 1756539392);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vHZNdCKeiW
{
public:
    int YLAfjeTrtSsUNfmo;
    string HThYfesjxu;
    int LZUxwVyywBQj;
    string ObeFITUZ;
    bool jfpuBtLwCV;

    vHZNdCKeiW();
    string bsgAzrVlbx(double OddyXKmrPtq, string SzJjkzFFRaG);
protected:
    int ySMaJPCKGiUu;
    double aMcbxbZItSjN;
    bool YmGoiwlboLHlXlU;
    string pZtrzgXFPZ;
    int voqfaNerlFGoYOS;
    string GBeEqFdHhwCtjGX;

    string RDFZdvpx(string rBFxYsFQxjjkMo, string SAxEXtTtqnpdaSCQ, int nkKufJybbqVvQvFt);
private:
    string wXlweFeSau;
    double oPbwfFFyjh;
    int WQzrGZkYCzDXflzS;

    double yTEbTelzEGukL(string WxcirvVNjYiqB, int NVibNEDZmoL, string YVILaWjygHcM, string szRuAb, double TUrJMCEwM);
    void xhhtqmYWdjJxYRhN(int rHDSMHQbW, string ctDpow, string KwEJGBblSe, bool KsdVtPPtQe, string TSheaQDyxLgf);
    bool TpzquSeHhoIyAFE(string sphwQ, bool JFhZCWag, double nPRzFnYWnSiB, int BHAheinMgcdGtCb, double fpxhswCSeZSf);
    void mJPku(double zWEdmxXAlgQsy, double nqGPqK, int vVlSPRYIZsd, double ZjqLEkKswOXn);
    string kxhNcku();
    double QosuXuCvdhoMF(double HmVDjtjdLXU, string aceoActodakQGW);
    double piaIXaainoD(int povojxip, string gCYqBMsjwlhNm, string YRvjxeQZP);
};

string vHZNdCKeiW::bsgAzrVlbx(double OddyXKmrPtq, string SzJjkzFFRaG)
{
    string OdpsROwNDIDuJ = string("UflJGfgQLimIoigVcTZiZzEYjoZatgygFTFwzkCTyPyWIRgJlceSsuGaYRIzAfqzOsXZGjCrMnRghWSgwrqfMwaxMTAihSQxOcRhOmbGsIaptcTiXzHkjpvlmAihQssiLbNtuJbEMveEadMkTznnwDLvfIoFNxMIOLPNgyRWEqVgBnfpfqBvTZljKM");
    bool ZqXVcCXaNdLVVaA = false;
    string cZXsDAcoJJTSZSU = string("AdZtrDVkPPFiQOoaQeYtdEKzefUAqhgbJoylAAVBCRpqxahfVRWzLWmCeGIweafcaVQjDSzVvEWMizHSDMrWXyCxrfkaNCgwloZirpXKKNplrdmUZkVAGiHqTuQjPMTUZzakniIBquhHNlskDJWLzXRrTAXftTSBVKSwKmhOTBZmXpUeMozHBFLvWNjeAlTyOGbkBcEZCcXVtAA");
    int NxkcBl = -1194953367;
    int tXExtdvrrckKuuSi = 654607453;
    bool MufyTdMUcZU = true;

    return cZXsDAcoJJTSZSU;
}

string vHZNdCKeiW::RDFZdvpx(string rBFxYsFQxjjkMo, string SAxEXtTtqnpdaSCQ, int nkKufJybbqVvQvFt)
{
    double lPvzhzzI = 34640.94411021588;

    if (SAxEXtTtqnpdaSCQ <= string("zQPzhnZpPmsMqbcjxuiemBveFHoMeiFlAldpqkcMVFZJMoTtMLw")) {
        for (int HCmSZGchu = 713872428; HCmSZGchu > 0; HCmSZGchu--) {
            lPvzhzzI -= lPvzhzzI;
            nkKufJybbqVvQvFt -= nkKufJybbqVvQvFt;
        }
    }

    for (int rEBxmV = 520774398; rEBxmV > 0; rEBxmV--) {
        nkKufJybbqVvQvFt -= nkKufJybbqVvQvFt;
        lPvzhzzI = lPvzhzzI;
        rBFxYsFQxjjkMo += SAxEXtTtqnpdaSCQ;
        SAxEXtTtqnpdaSCQ = rBFxYsFQxjjkMo;
    }

    return SAxEXtTtqnpdaSCQ;
}

double vHZNdCKeiW::yTEbTelzEGukL(string WxcirvVNjYiqB, int NVibNEDZmoL, string YVILaWjygHcM, string szRuAb, double TUrJMCEwM)
{
    bool RdhxsIXX = false;
    int yPYRUiQWHQynk = 714865935;
    bool XGqrLIkBra = false;
    double EiukkdBKGw = -315542.00407987874;
    string PEsWkcsBHac = string("bYykuVIpz");

    if (RdhxsIXX != false) {
        for (int lLwOBHynahUwIEV = 2114241510; lLwOBHynahUwIEV > 0; lLwOBHynahUwIEV--) {
            continue;
        }
    }

    for (int gfrMtkywZBvKDoYs = 2009739137; gfrMtkywZBvKDoYs > 0; gfrMtkywZBvKDoYs--) {
        continue;
    }

    for (int mYhGCmcz = 1987738346; mYhGCmcz > 0; mYhGCmcz--) {
        continue;
    }

    for (int KeTpcV = 471589631; KeTpcV > 0; KeTpcV--) {
        EiukkdBKGw /= EiukkdBKGw;
        RdhxsIXX = ! RdhxsIXX;
    }

    if (NVibNEDZmoL > 714865935) {
        for (int PaLmciohDyIhuxJm = 236160491; PaLmciohDyIhuxJm > 0; PaLmciohDyIhuxJm--) {
            continue;
        }
    }

    return EiukkdBKGw;
}

void vHZNdCKeiW::xhhtqmYWdjJxYRhN(int rHDSMHQbW, string ctDpow, string KwEJGBblSe, bool KsdVtPPtQe, string TSheaQDyxLgf)
{
    double IyiOXBFPruaxoydu = 684392.2984560014;
    double tqsUkTv = 533411.6460899786;
    double GKsZjYY = 859025.1919076778;
    double nrRuOZbch = 804573.1623054636;
    double hYqRBneFUqbjcAgN = -53572.127170428656;
    string eVoaQPXqFmL = string("DReDuybRlToREVbcbufiluaZpheEKMaXRkzOqEMMkDnoxIyGSZwXgyUgUGaDnDwcrMcuMHzKaJJQjhdVCaMevzfdQCaDvoPZUBNtnFEhXlltzKAbbJYQOkVSlgwhfbOccJsdramXlPtMKHRhbkjSAKguBZBNadfirfISYYtkgVGDQnydLLLdJZChwqmXHlsVvQcuRnunpxkhPrpPK");
    string jhIvcYGDm = string("LOHtVwZpFrDrWyoXHecldVYiZtwYHzwYLgkdqgcujoRvZYeokRQbAPQiDXamMrUeckStTREBALTMeGkDoByZHukTRVnUBLMLLhwVhUvQPKEyshujdhmXQjmKQEtLbjupQmjYLimVrpBcvfXipoJwAFxxklEpAkanpZjHpeofrAZowhwzjrzixGUVwwEQMHiytZIdEjsOzzJUbATOKgSWOfwDz");
    string ewjSAlIojflW = string("qCozaauPaudWustaEKSjaLGvpkLIBOBwDeDolnIYYPqxFKMVVUQZmEdWUVlSLmGbIPWFzEuTHTlbOakXYbHftzvLJDqJDlyNDOLxTCiEdLCDkFAFJfPSutdcqspdZVjDHhIsjoiKljFSlnOPChMtNsyYLH");
    bool vFnCWkUBovHQr = false;

    for (int yuIDPO = 1400117093; yuIDPO > 0; yuIDPO--) {
        KwEJGBblSe = eVoaQPXqFmL;
    }

    for (int JWTTIBZqqBD = 285033524; JWTTIBZqqBD > 0; JWTTIBZqqBD--) {
        jhIvcYGDm = KwEJGBblSe;
    }

    for (int LlZpSeoqpmsTm = 56359350; LlZpSeoqpmsTm > 0; LlZpSeoqpmsTm--) {
        TSheaQDyxLgf += KwEJGBblSe;
        jhIvcYGDm = KwEJGBblSe;
        tqsUkTv += nrRuOZbch;
        tqsUkTv += IyiOXBFPruaxoydu;
        eVoaQPXqFmL = KwEJGBblSe;
    }

    if (eVoaQPXqFmL > string("iIivcSLxlmXLRCxTrGpEykUdLRLanfMZcFvZOotOGzFKOxadVcnMPKNDrFezhwTmJqBWcwjdbFxoaZyOlVAFhfnyzdVBGXBiUGRWoWawkIVsqLWteHmiwhMdaJQYKWtpznynsLXXwGDWlCMqXdpfeaHZsuUkoWBkbEGAxMZY")) {
        for (int WzdWlUertTEERYmZ = 426120814; WzdWlUertTEERYmZ > 0; WzdWlUertTEERYmZ--) {
            GKsZjYY *= hYqRBneFUqbjcAgN;
            ewjSAlIojflW += jhIvcYGDm;
            hYqRBneFUqbjcAgN += tqsUkTv;
        }
    }
}

bool vHZNdCKeiW::TpzquSeHhoIyAFE(string sphwQ, bool JFhZCWag, double nPRzFnYWnSiB, int BHAheinMgcdGtCb, double fpxhswCSeZSf)
{
    int OCVEilJpVlXR = 1521844462;
    int kYcNGXFjXnTOz = -413731912;
    bool IqFGOdP = false;
    bool zwsRIKMuxNmd = true;
    string BNVsEEULKVWSdu = string("YWmeCyWcnHEtjASpwxqdLneuGNxTfsagaFejncmOQpJPkhyxeduACPozIetqwPscTCEBZwlliGpTklmyVDqFvPWuRXuRkVCyIKyEHnKsLDCrNgDXggPzCheNIoeKc");

    if (IqFGOdP != true) {
        for (int BjcjIUKskrYxW = 1181665680; BjcjIUKskrYxW > 0; BjcjIUKskrYxW--) {
            nPRzFnYWnSiB = fpxhswCSeZSf;
        }
    }

    for (int yNGRkEUslTo = 823381802; yNGRkEUslTo > 0; yNGRkEUslTo--) {
        kYcNGXFjXnTOz -= OCVEilJpVlXR;
    }

    return zwsRIKMuxNmd;
}

void vHZNdCKeiW::mJPku(double zWEdmxXAlgQsy, double nqGPqK, int vVlSPRYIZsd, double ZjqLEkKswOXn)
{
    string myMWgGlMAMWSkyiz = string("pyjZCSiYQomSAuYGweBurHXFSuKrtSGTPEmMyNNuAzCEVFmhNXIXsnLEcArKrdgfuwkdqXczLPheeNuGCFOVaXBEjaYilQ");

    if (nqGPqK != 1001954.8513238556) {
        for (int BrZvgzrPvRegL = 1422338233; BrZvgzrPvRegL > 0; BrZvgzrPvRegL--) {
            zWEdmxXAlgQsy /= ZjqLEkKswOXn;
        }
    }

    for (int rwhtEhxhVV = 2032324494; rwhtEhxhVV > 0; rwhtEhxhVV--) {
        myMWgGlMAMWSkyiz = myMWgGlMAMWSkyiz;
        zWEdmxXAlgQsy /= ZjqLEkKswOXn;
        zWEdmxXAlgQsy = nqGPqK;
    }

    for (int duUsa = 1553511618; duUsa > 0; duUsa--) {
        zWEdmxXAlgQsy /= zWEdmxXAlgQsy;
    }
}

string vHZNdCKeiW::kxhNcku()
{
    string YBSEMW = string("PsSVLlAmTGJFAYTpDAfYBdKysDEEScLCiSfeNdRHdMpfRYNtJPfkfZMgBGpKTLcHHZprnDhAGRJGdBnhQeRLXcPuLxaqfZGmTSlOoZMnoELkCcKKoFbEgchNVdcyFaDxsVcZNSrFQuoyjvQgGaIhEtykLAWyjufetHWIiZBqQHSpuQSyEHFnVxIlNfLgumKrnASItfkzhkYhRTDWCNGhEKROuQQvRuaBgMBoIElGhEnuDFyqlu");
    bool vQfcu = true;
    int yWwhCr = -1236538579;

    if (yWwhCr < -1236538579) {
        for (int mVttdnhqghrbbPH = 380362291; mVttdnhqghrbbPH > 0; mVttdnhqghrbbPH--) {
            vQfcu = vQfcu;
        }
    }

    for (int EQTPzxoMrJoVnLID = 370311020; EQTPzxoMrJoVnLID > 0; EQTPzxoMrJoVnLID--) {
        continue;
    }

    for (int rlSjAMjqxsWtGWZ = 1055374788; rlSjAMjqxsWtGWZ > 0; rlSjAMjqxsWtGWZ--) {
        yWwhCr /= yWwhCr;
    }

    return YBSEMW;
}

double vHZNdCKeiW::QosuXuCvdhoMF(double HmVDjtjdLXU, string aceoActodakQGW)
{
    string gRsgN = string("scBnmUwlKpLijzPiwonDGmMVdNbIzFXZPSZbhsSvdqnYNwXAWppWKqANVsjdrdJLfkWdjNOivMbgxzbGnPmUwdBgdAextkPrexMzMwVqTMuuIjgHcMwApSYWJcuYBwJspqAvmsW");
    bool QeqbgyKGbmZ = true;
    double TbqTG = 589181.835772843;
    double PxnRghEQ = -635634.3202390217;
    bool RomoxStuxKAPMK = false;
    double QyVvl = 676703.9318747534;
    double VPHHJnkpjw = 397135.2011223849;
    string rJvjdr = string("aVCHisnZwHJnAaxLUnIhegIwODROmPqFtSmWewplkqRHfXGuTxFjgipFXZYMhcXDokcaAMYkEsWAcnNtmabGwtCMTyVdFumCugESDRYlBLHeiWHBmtkDyggyimGbogcveyLNgyMZVrEzUbgIkgUKPDLUVYXjaXOBcscadvAGNApslQZSpDyCXiSEYOIxBrUJpmwNXRuyqwZEMhXxalOzhcGepL");
    double lntNIZgSSqQ = -11485.607509383432;
    bool sLvpVeAWjkI = true;

    if (HmVDjtjdLXU >= 1024214.6507989905) {
        for (int SKivr = 2104198825; SKivr > 0; SKivr--) {
            continue;
        }
    }

    if (TbqTG > -635634.3202390217) {
        for (int UnFewhGORYZkJ = 257541089; UnFewhGORYZkJ > 0; UnFewhGORYZkJ--) {
            QeqbgyKGbmZ = QeqbgyKGbmZ;
        }
    }

    if (PxnRghEQ == -635634.3202390217) {
        for (int dRnCCOQyUjlsTESt = 138952155; dRnCCOQyUjlsTESt > 0; dRnCCOQyUjlsTESt--) {
            lntNIZgSSqQ /= TbqTG;
        }
    }

    if (aceoActodakQGW > string("UBWctamxYYQrkZwvvwIwlSzEdoYyCi")) {
        for (int QsHuxhBKyLHIeTq = 1994129611; QsHuxhBKyLHIeTq > 0; QsHuxhBKyLHIeTq--) {
            HmVDjtjdLXU += HmVDjtjdLXU;
        }
    }

    if (PxnRghEQ > -635634.3202390217) {
        for (int VyczSkoSlwZKAy = 1435552008; VyczSkoSlwZKAy > 0; VyczSkoSlwZKAy--) {
            rJvjdr = gRsgN;
        }
    }

    return lntNIZgSSqQ;
}

double vHZNdCKeiW::piaIXaainoD(int povojxip, string gCYqBMsjwlhNm, string YRvjxeQZP)
{
    string ygWYYMrR = string("ZCvZjHlNOJzSFAeMQjQEDQWYOIscwBaJNUQCntgasvGdzBkMPwEuPFUEWHuBEOhIuDQpkgaTrxpinczZRbzsTLUUHEcJlTapzVcmOyMhkzecoiTdUQtvFgZNJlhjtxPlFayVfHzXByLsJxokwmnRqVECEHmsCYmhqscdNcccDwqxU");
    string NNTwKUBLSAwPJwp = string("yRQXNVRjbCkutjdnkFkbcbRa");
    int sWDrgX = -1316985795;
    int GlThobhsIdgiq = 1761640332;
    int qKvIgHpqqToAoJ = -770993698;
    int GjHTzthWgha = 1453032677;
    double OabGFFhYOzWNkMeo = 526894.3500985022;
    int fSVXZMUoSlVkYL = -782520621;

    for (int Osdpqrltj = 1371435266; Osdpqrltj > 0; Osdpqrltj--) {
        fSVXZMUoSlVkYL -= povojxip;
    }

    if (GjHTzthWgha > -770993698) {
        for (int vVycaRYRHWxwPYdz = 1293592371; vVycaRYRHWxwPYdz > 0; vVycaRYRHWxwPYdz--) {
            continue;
        }
    }

    if (ygWYYMrR > string("yRQXNVRjbCkutjdnkFkbcbRa")) {
        for (int EwRYLhuD = 1953283868; EwRYLhuD > 0; EwRYLhuD--) {
            qKvIgHpqqToAoJ += GlThobhsIdgiq;
            ygWYYMrR = YRvjxeQZP;
        }
    }

    for (int OxiTPykrTHODSIG = 319846978; OxiTPykrTHODSIG > 0; OxiTPykrTHODSIG--) {
        continue;
    }

    if (ygWYYMrR >= string("ZCvZjHlNOJzSFAeMQjQEDQWYOIscwBaJNUQCntgasvGdzBkMPwEuPFUEWHuBEOhIuDQpkgaTrxpinczZRbzsTLUUHEcJlTapzVcmOyMhkzecoiTdUQtvFgZNJlhjtxPlFayVfHzXByLsJxokwmnRqVECEHmsCYmhqscdNcccDwqxU")) {
        for (int aaksX = 750018360; aaksX > 0; aaksX--) {
            continue;
        }
    }

    return OabGFFhYOzWNkMeo;
}

vHZNdCKeiW::vHZNdCKeiW()
{
    this->bsgAzrVlbx(-420888.67025487486, string("dpVfhDIkFmqFGoqvlbYWVqZsNrhQOkmhlSVCGDnbNUoGxKOMgZODzuiALriIfcDkDhuCzQtIDuROispGqGJraVYyNvgzhunyKedkfwiEomnJjJLALQITJlQjzTmZIDivOZpInOWjeTkwcpvtvwdwqgKrUEHsdpzLbrhsmAjfQlEOcwmXvvXpWCRIuYbcSwungVwQLHraAhCZtsrPCaPqdzJFRgAgoRUeeWaWZHnNTlgG"));
    this->RDFZdvpx(string("uzlTvfprdHZZuwIIZPwEhJtZseMgqiGETVtxESDyhDQaSGfUXnIRiEWIGzSywfAtzsmZmIMHgUSIvzTBZOCKdzEJZWPteQNVqGhWuPaTFDKAkhEEReTvMkEeHRmu"), string("zQPzhnZpPmsMqbcjxuiemBveFHoMeiFlAldpqkcMVFZJMoTtMLw"), -312173122);
    this->yTEbTelzEGukL(string("hwPIKAnVcYMGBBDr"), 620165251, string("sseNMpsOaUVq"), string("WzBeyTnVwCDdWKRg"), 24739.444663475722);
    this->xhhtqmYWdjJxYRhN(-745607693, string("KNHcWNRnvBcnhJJBliCpbvFetRGuvSIWwyDMPqdQCYCNWNYqrUOyQWidYDXHrbyOSyAGQFMjfDGBJiLaKwnmcsnoOldOuNAMkJbnXvIUswiWgNleqEdgJoWThK"), string("KsNYkYIpEoEUeNUCkrlGbHxPqIHRIIlKIbTSAcNXB"), false, string("iIivcSLxlmXLRCxTrGpEykUdLRLanfMZcFvZOotOGzFKOxadVcnMPKNDrFezhwTmJqBWcwjdbFxoaZyOlVAFhfnyzdVBGXBiUGRWoWawkIVsqLWteHmiwhMdaJQYKWtpznynsLXXwGDWlCMqXdpfeaHZsuUkoWBkbEGAxMZY"));
    this->TpzquSeHhoIyAFE(string("GQEjRPLaRvEGOReYKTzBSSdKUEZmYZpMSrBRlhjkPkbXEbbdCfCgmIPxajvthwsYQprrsPGweBdnQPtQUYigwIaVcEKpiHMKIZaBEVqUonDdTRoJAbodXezuFcijRRaPoLtvPeNGlYiWKZPlmYXSzSZgnF"), false, -605495.5553518876, -1837230134, -997252.9741662341);
    this->mJPku(868706.633362206, -953438.6570829969, 1858982578, 1001954.8513238556);
    this->kxhNcku();
    this->QosuXuCvdhoMF(1024214.6507989905, string("UBWctamxYYQrkZwvvwIwlSzEdoYyCi"));
    this->piaIXaainoD(1132854035, string("IMgBaqBzfZYLSeMBmkWcpyArfpyzipwVHQUYHadbamWWYdLKqOtEOawtRyfMJoOFykJzmCrcbVrJZLXhdpaxwqKJQhBAHHmfXovvPMFnSpeueKpagAdVTvciHbpKGOKuEjnhrcmHfjwcKjlBrZDadMtKWQgiCarICmejzBsRuEVTPhNktQhvzButvQydmhRlCszAxWwVKxmEBHbQBUcLXJ"), string("gFueTrATdrDZEsVGMxAmqPHsFqRWJKrjVjIaGJsOKbbvnAzzyWrzqCe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CEYxPBZNpxBzT
{
public:
    string dAzjRRoKFQiN;
    int PjASiByQVjcgkPuc;
    string BUDdTJARwTDobNqm;

    CEYxPBZNpxBzT();
    double CxZXt(string VZeGinlnBdbe, int AugisPgNdRk, double BYlZz);
    bool WAxKkCkHx(double yPFHWPbC, bool HrgNDQUgwMsWagKA, int NTdsUO, bool kaYMuV, bool qpbfZKxtbX);
    double SYqicfLEqpHq(int uBrhpk, string VGkPYn, double FDYlcoc, double xYayLBCcphFy, string oiWFachGOmjGg);
protected:
    string CoqnAGXP;
    bool hRQtwwZFMdXZZqvx;
    bool BpuiVdal;

    int EfnCkn(double fwOqAjAwqvkvtdP, int APgsaSFAdRosdK, bool YGuqCDuGQKLyEaui, double pJiumaDpm);
    int TQdmSdTluotGA(string hTLIMbxatrbavG);
    int iwRhNOajlASwofaf(string bauVWdVml, double MhlBCvWRk, int ZqvzoBxTcitby);
    bool mqfKyvqkEaulN(double JHZDGmqBIo, int aWqFJtIFBp);
    void htOynQH(int GbmFfyq, string bbJGEANI, double CrcYGLIMMj);
    double mgjBgEikjTwDV(int ziDajMno, int OIsiSSJOd);
    string ivCrnQXqfJr(int kdtJTl, bool vQaoYVlrf);
private:
    bool xgvJPPAjE;
    double dqGmQDH;
    string JXRZbQMyO;

    int xDeoVcryYrhQGj(string YNsEItHsM, string uVcSLWANTkBNA, double ISBxkeK, double OqMLqCNG);
    double kMYovtUY(bool fgxhJvPCsaqSFq, bool wIxYaSTmqDcNCCQ);
    int nGyzd(double BKsaFJQJZYXuW, string CwAyzqZpq);
    int xDkPTgsBa(bool ykMXWLrd);
    double ZFuuOLVFlvGZYl();
    string fhQBEuGWrOghgPO(int GZKXt, string EFIouD, bool ODrmwA, bool JPgomkaZJqZ);
};

double CEYxPBZNpxBzT::CxZXt(string VZeGinlnBdbe, int AugisPgNdRk, double BYlZz)
{
    double pvbbZUAWOz = 759606.9794782806;

    return pvbbZUAWOz;
}

bool CEYxPBZNpxBzT::WAxKkCkHx(double yPFHWPbC, bool HrgNDQUgwMsWagKA, int NTdsUO, bool kaYMuV, bool qpbfZKxtbX)
{
    bool ulDFOw = false;
    bool nGhjCxIvyT = false;

    if (kaYMuV == true) {
        for (int VqYgzryugTMoFttF = 1191915398; VqYgzryugTMoFttF > 0; VqYgzryugTMoFttF--) {
            ulDFOw = nGhjCxIvyT;
            nGhjCxIvyT = ! nGhjCxIvyT;
            nGhjCxIvyT = qpbfZKxtbX;
            ulDFOw = ! qpbfZKxtbX;
        }
    }

    for (int ttmMQiCGM = 437384933; ttmMQiCGM > 0; ttmMQiCGM--) {
        ulDFOw = ! HrgNDQUgwMsWagKA;
        kaYMuV = ! ulDFOw;
        kaYMuV = kaYMuV;
        nGhjCxIvyT = nGhjCxIvyT;
    }

    for (int UrwpyxXVOvN = 1420738338; UrwpyxXVOvN > 0; UrwpyxXVOvN--) {
        continue;
    }

    if (HrgNDQUgwMsWagKA != false) {
        for (int ddqVPusEJrpOEby = 1315534870; ddqVPusEJrpOEby > 0; ddqVPusEJrpOEby--) {
            ulDFOw = HrgNDQUgwMsWagKA;
            qpbfZKxtbX = ! kaYMuV;
            HrgNDQUgwMsWagKA = nGhjCxIvyT;
            nGhjCxIvyT = HrgNDQUgwMsWagKA;
            nGhjCxIvyT = ulDFOw;
            qpbfZKxtbX = qpbfZKxtbX;
        }
    }

    return nGhjCxIvyT;
}

double CEYxPBZNpxBzT::SYqicfLEqpHq(int uBrhpk, string VGkPYn, double FDYlcoc, double xYayLBCcphFy, string oiWFachGOmjGg)
{
    int NCrMGnFTiLVmSf = -1116718858;
    double PxdyHIm = -869659.1532605741;
    double zfQxeavnXCnahxz = -732397.516610347;
    string gQZDwxx = string("EpTjHACVxGHEHCEvaZQiMXcEXEwKBmiUtTBs");

    if (xYayLBCcphFy <= -764414.2928046101) {
        for (int teCGaXvVLQn = 1475068716; teCGaXvVLQn > 0; teCGaXvVLQn--) {
            uBrhpk = uBrhpk;
            gQZDwxx = gQZDwxx;
            PxdyHIm /= PxdyHIm;
        }
    }

    for (int kVENY = 31431059; kVENY > 0; kVENY--) {
        zfQxeavnXCnahxz -= PxdyHIm;
        zfQxeavnXCnahxz = xYayLBCcphFy;
        FDYlcoc *= PxdyHIm;
    }

    for (int AJtYMKEUAggFYUT = 1367913581; AJtYMKEUAggFYUT > 0; AJtYMKEUAggFYUT--) {
        continue;
    }

    for (int CjxZwu = 193265171; CjxZwu > 0; CjxZwu--) {
        NCrMGnFTiLVmSf -= NCrMGnFTiLVmSf;
    }

    return zfQxeavnXCnahxz;
}

int CEYxPBZNpxBzT::EfnCkn(double fwOqAjAwqvkvtdP, int APgsaSFAdRosdK, bool YGuqCDuGQKLyEaui, double pJiumaDpm)
{
    bool dnKnxArGGAYUDIXU = true;
    string DfhyZGuGNxOj = string("IVCLSakDaEwQuuhUSWrVrQJgqEVVgcVMxRRKNrZQyYbQzsWWnEvVQpSpesCtsuWFMsuVgUlPjRgKgpNodDRlepmWPXrxhGEmLJLGFojQNQxWhCnoHKytNlqQETVWlnrCHnEeOoAMaHXKHYVFyfnwLudDtHbmbPloZlIEg");
    int nXqUkYL = -759130237;
    bool mnzzCJUDEStQx = false;
    string YFUYBXTlCa = string("iKssoOsayeVYOwpHndBZqWhmpwOXBQqyPogrkzNwvzMblxBposYSUqFEKMltkqWaTSoEptzqzywOefalewidBjINPVkkVQTQQjgURQIxvCxjotjwlGEftwPMAGeBDuyJUhIflRwkyNEmFxwXZzqfKxzAOXkIFgqvSIFNWEjhVdADsivzpDNRvoqQTPly");
    bool wRcddjezwIc = false;
    double YdAdWMWzuGA = 21342.956932151956;

    for (int sPKqXEAeL = 716415262; sPKqXEAeL > 0; sPKqXEAeL--) {
        wRcddjezwIc = ! dnKnxArGGAYUDIXU;
    }

    if (dnKnxArGGAYUDIXU != true) {
        for (int zNecLYLIQHd = 1624025307; zNecLYLIQHd > 0; zNecLYLIQHd--) {
            pJiumaDpm += pJiumaDpm;
            fwOqAjAwqvkvtdP -= pJiumaDpm;
        }
    }

    for (int zrUcdPAHfnhNStSC = 1153909912; zrUcdPAHfnhNStSC > 0; zrUcdPAHfnhNStSC--) {
        wRcddjezwIc = ! wRcddjezwIc;
        YFUYBXTlCa = YFUYBXTlCa;
    }

    for (int tawkDjfWLOEh = 173465464; tawkDjfWLOEh > 0; tawkDjfWLOEh--) {
        continue;
    }

    return nXqUkYL;
}

int CEYxPBZNpxBzT::TQdmSdTluotGA(string hTLIMbxatrbavG)
{
    int xcjMvC = -873972470;

    if (xcjMvC < -873972470) {
        for (int FtGTIjBE = 1224041799; FtGTIjBE > 0; FtGTIjBE--) {
            xcjMvC /= xcjMvC;
            hTLIMbxatrbavG = hTLIMbxatrbavG;
        }
    }

    if (hTLIMbxatrbavG < string("CtKDtTINwRuIygqetEJxvoIbiWpAFRBLHGFzzpUBYYssnMMwTPIlZuiQnlfRMyAdJLhzVkiizhrQmomNzmgliTaLoNplZEdKCWzcYbIReIBeVtJRFViSrJHHGUsgupoVDgSsYuKoWIfWJDuWYHHxmwvlIWjgtV")) {
        for (int hHtXMPMNiUENgCAb = 1669636084; hHtXMPMNiUENgCAb > 0; hHtXMPMNiUENgCAb--) {
            hTLIMbxatrbavG += hTLIMbxatrbavG;
        }
    }

    return xcjMvC;
}

int CEYxPBZNpxBzT::iwRhNOajlASwofaf(string bauVWdVml, double MhlBCvWRk, int ZqvzoBxTcitby)
{
    bool uIFAeZhDSv = false;
    int qdfQte = -92406378;
    bool XQFOiRDjbdOkYnCV = false;

    for (int lzeQyTdDaek = 1298064260; lzeQyTdDaek > 0; lzeQyTdDaek--) {
        bauVWdVml += bauVWdVml;
        uIFAeZhDSv = uIFAeZhDSv;
        uIFAeZhDSv = ! uIFAeZhDSv;
    }

    for (int HDLiR = 1737249466; HDLiR > 0; HDLiR--) {
        uIFAeZhDSv = ! XQFOiRDjbdOkYnCV;
        ZqvzoBxTcitby /= ZqvzoBxTcitby;
    }

    return qdfQte;
}

bool CEYxPBZNpxBzT::mqfKyvqkEaulN(double JHZDGmqBIo, int aWqFJtIFBp)
{
    int zwOugohYgn = 1510667854;
    string PfoOG = string("GTofzbFgwbAzSMppKDZqeXdrqWNUOjXGGHbgdKInbLzpKreqfrsEA");
    double LMxYCL = -693547.4535381165;
    string spOIl = string("isghokZsYWVwREKrNDZqOhAScxLHwtmOBpXOkpFyNZCgUbrGqqJzQkzGnfozFaUxMuHFCAZMfUACZMSgZTcor");

    if (zwOugohYgn == 1510667854) {
        for (int adfbtnno = 1684472135; adfbtnno > 0; adfbtnno--) {
            aWqFJtIFBp += zwOugohYgn;
            aWqFJtIFBp /= zwOugohYgn;
            zwOugohYgn /= aWqFJtIFBp;
            LMxYCL *= LMxYCL;
            spOIl = spOIl;
        }
    }

    if (PfoOG == string("isghokZsYWVwREKrNDZqOhAScxLHwtmOBpXOkpFyNZCgUbrGqqJzQkzGnfozFaUxMuHFCAZMfUACZMSgZTcor")) {
        for (int YLgvRVxIzOKPMhE = 2077941318; YLgvRVxIzOKPMhE > 0; YLgvRVxIzOKPMhE--) {
            aWqFJtIFBp = zwOugohYgn;
            aWqFJtIFBp *= zwOugohYgn;
        }
    }

    return true;
}

void CEYxPBZNpxBzT::htOynQH(int GbmFfyq, string bbJGEANI, double CrcYGLIMMj)
{
    double vvrUZMXXSWbm = -773847.8124294736;
    string tJfgewsWsPopmN = string("CRSakmALHQfGOhwibpyKGTckuQEJPGKBnghyVefsNPwwKqCAxylJDWoLuyOROFaNUkqVdTQAmSohjHKvAMJqoeOpirDxDyyYciQjKTvpQernFrtWDjsYMjhEGawwdDoHZJTpawEYEAaOHtMjsCErRmTjUbaJhSNWzLvQufozzMUbBVhALzyMVOxWKvwmnWqbIInFCToVuNiOoASknIfJkgsCpuPWsyujJJSEzBGtBDGIqGjYrrdiM");
    double LRMAkyjJW = 1008853.0168188387;
    bool NwUFHhepPegrh = false;
    bool QInjGq = false;
    bool acVaBleq = true;
    int GdNSXgxORaMYcoS = -2016380503;
    bool ILJOYIMXeXmi = false;
    string jbLce = string("bCoAJZtlzdyRChqrhGcGUbXcFfsrYSNwtzFphLmLpuFmFfYopPEVRJSahbUKaunadVDKRCnWAtIYyasrHW");

    for (int emLNjbbaQsSF = 815348967; emLNjbbaQsSF > 0; emLNjbbaQsSF--) {
        ILJOYIMXeXmi = ! ILJOYIMXeXmi;
        GbmFfyq += GdNSXgxORaMYcoS;
    }

    if (LRMAkyjJW != 1008853.0168188387) {
        for (int KkEAzwCLaXwavCfg = 1482522613; KkEAzwCLaXwavCfg > 0; KkEAzwCLaXwavCfg--) {
            jbLce += tJfgewsWsPopmN;
            QInjGq = NwUFHhepPegrh;
            ILJOYIMXeXmi = ! ILJOYIMXeXmi;
        }
    }
}

double CEYxPBZNpxBzT::mgjBgEikjTwDV(int ziDajMno, int OIsiSSJOd)
{
    bool WcKJoI = true;

    for (int ZsdaRQWzPQ = 1944742930; ZsdaRQWzPQ > 0; ZsdaRQWzPQ--) {
        continue;
    }

    for (int RPcwCu = 226373470; RPcwCu > 0; RPcwCu--) {
        OIsiSSJOd /= OIsiSSJOd;
        ziDajMno -= ziDajMno;
        OIsiSSJOd *= ziDajMno;
    }

    for (int szumZ = 1194532566; szumZ > 0; szumZ--) {
        ziDajMno = ziDajMno;
        ziDajMno /= ziDajMno;
        ziDajMno *= OIsiSSJOd;
        OIsiSSJOd -= ziDajMno;
        ziDajMno /= ziDajMno;
    }

    return -918197.3517795468;
}

string CEYxPBZNpxBzT::ivCrnQXqfJr(int kdtJTl, bool vQaoYVlrf)
{
    string ypHznVauipoWZHUE = string("KZW");
    double lmYOnlZwFlDrfeMd = -902315.6885627401;
    bool WlCNulWwagamXlL = true;

    if (ypHznVauipoWZHUE == string("KZW")) {
        for (int oHDswTMpSJ = 1353704881; oHDswTMpSJ > 0; oHDswTMpSJ--) {
            kdtJTl -= kdtJTl;
            lmYOnlZwFlDrfeMd -= lmYOnlZwFlDrfeMd;
            ypHznVauipoWZHUE += ypHznVauipoWZHUE;
            ypHznVauipoWZHUE = ypHznVauipoWZHUE;
        }
    }

    return ypHznVauipoWZHUE;
}

int CEYxPBZNpxBzT::xDeoVcryYrhQGj(string YNsEItHsM, string uVcSLWANTkBNA, double ISBxkeK, double OqMLqCNG)
{
    double NiPxbXc = -617500.9208635689;
    string EauzKpvNoXcM = string("SgrYIUZDXNXIqfXbgmaxwXPqmyXYiiXNFtIhpdLFCNwfQxwnEXDZXrHHNFpJrtIQcudhSqGbTBPAbwwkUmoDtwejrRSMZjIOmsombRllUVWrGoWmVEWHVnomhVJIyiFO");
    double STbIfjMwDbnucv = -183830.22551014;
    double vCXjem = 490732.39446490875;
    double DQwCuGGTWtkVYCH = 431032.96448984597;
    int ebuzMaFd = -1039916820;

    for (int ZholAPAiaZfliq = 633278478; ZholAPAiaZfliq > 0; ZholAPAiaZfliq--) {
        OqMLqCNG /= vCXjem;
        ISBxkeK -= DQwCuGGTWtkVYCH;
        DQwCuGGTWtkVYCH *= NiPxbXc;
    }

    if (STbIfjMwDbnucv != -183830.22551014) {
        for (int sFoPbGqlubW = 1781190552; sFoPbGqlubW > 0; sFoPbGqlubW--) {
            DQwCuGGTWtkVYCH = ISBxkeK;
            uVcSLWANTkBNA += uVcSLWANTkBNA;
        }
    }

    for (int fCCkWTLsvxypM = 245137650; fCCkWTLsvxypM > 0; fCCkWTLsvxypM--) {
        STbIfjMwDbnucv /= ISBxkeK;
        ISBxkeK -= DQwCuGGTWtkVYCH;
        NiPxbXc *= DQwCuGGTWtkVYCH;
    }

    for (int ESZGPtFhJwjGZ = 599866176; ESZGPtFhJwjGZ > 0; ESZGPtFhJwjGZ--) {
        STbIfjMwDbnucv *= NiPxbXc;
    }

    if (STbIfjMwDbnucv >= 691200.2080822688) {
        for (int cRPHePrVMdCGZh = 1797755789; cRPHePrVMdCGZh > 0; cRPHePrVMdCGZh--) {
            ISBxkeK = STbIfjMwDbnucv;
            STbIfjMwDbnucv += vCXjem;
        }
    }

    return ebuzMaFd;
}

double CEYxPBZNpxBzT::kMYovtUY(bool fgxhJvPCsaqSFq, bool wIxYaSTmqDcNCCQ)
{
    string iWtDppFf = string("sWQzkcFNBadRLMyTOilVdaKyLngRVduZberQzQeSxaAayKaKVdXTiOQaDrZBLRkDkwJoqwcpqQEgpLswQnetHqWvezrDYMLxEmImxuOLSY");
    bool vuVfkYTUWioagN = true;
    int xQptLC = -2091450531;
    bool fJeSSnW = false;
    string PtnbgoD = string("AQUQykUmYVzhMyFTQAfKLfUgkZjXIfOQPYXekrcekNkYafygYzeUzvrFJRGbSDeBaAvFHjEeMmblsWFMVBJkqlvyrsRBmjMEgZaPngMWWWHiYfFTINfCxGWoPjxVrNMFfXCkhuZsaKWKeSoZZSYZektEzpukIOsmGgnsaxuvRANNsUNXAItHFpwIafmtTuQKssC");
    bool xAkTjjfJSycv = false;
    string fMcEke = string("CvbyplCjYiMcuXBNyCkzgSAPVyMDIYKIXDMoWgGWQOEIfbipHEbrhjtFLCbjnLLXqxpACSDHFtSoNUcLOzCFeyrJlwlREnZphR");
    string WgSndQmiqcUOg = string("QYABbXKPzZHFGfMjGxVgYmzUCNlXlKpWGscvRfKpoSEcAikmtbLYfVhvsEelSpEkFMHoRXaupyLtssaJjKZGOimnsLsUGMjljiOPnuvkZNfOWXifbHsjopSy");
    int sfSeAzLTkmoNvyd = 1829271330;
    bool EgbAMJAJ = true;

    for (int iYvJkeXa = 245758395; iYvJkeXa > 0; iYvJkeXa--) {
        xAkTjjfJSycv = ! xAkTjjfJSycv;
    }

    for (int tbNxFIkbPuyGE = 866414766; tbNxFIkbPuyGE > 0; tbNxFIkbPuyGE--) {
        fgxhJvPCsaqSFq = ! EgbAMJAJ;
    }

    return -812726.7129569286;
}

int CEYxPBZNpxBzT::nGyzd(double BKsaFJQJZYXuW, string CwAyzqZpq)
{
    double CJeFp = 777471.7905164956;
    double FIJPejvLBnPIvfE = -383406.8130392779;
    string KcLpqUB = string("nIaXrRRZdBfwTwRsectReirOqnoSqegxFsNIcmJgRZFeFNLGNuScHtirlV");
    bool BsZuTmmwzmGEUVl = false;
    double lTDLwrhiraotY = -821257.7691815057;
    double qbhovS = -391884.6560270471;
    string Ceymbf = string("INaRhmYiNYhOWxnOcWAvGkyVtvmaCIIVaNttfoXUYuVHYOtJuutlKYtLQJxzLNDQirpPZRSyFXwczQWoWxnERxLCQvpBsYuApfhLZCCYJpnVzOwECBbCYEpC");

    if (FIJPejvLBnPIvfE > -901200.3171076291) {
        for (int AfjAxvqtLJLOoaaU = 1322952255; AfjAxvqtLJLOoaaU > 0; AfjAxvqtLJLOoaaU--) {
            CJeFp = FIJPejvLBnPIvfE;
            FIJPejvLBnPIvfE += CJeFp;
            FIJPejvLBnPIvfE += FIJPejvLBnPIvfE;
            lTDLwrhiraotY += qbhovS;
        }
    }

    if (CwAyzqZpq < string("WfvmTsFWWOgJRHGJDUUyJZFTJOJuNkANXVoRbxjAwHsLcTmTHXXOwoftuDEsVRzwMVnckJAfyZXhAdpFMGdNKJLmiPrCARpREhglrQKXmjaLKAcIvCQrqtvOazGXicEIHt")) {
        for (int ujtdBpMtDQeKdnNB = 790705081; ujtdBpMtDQeKdnNB > 0; ujtdBpMtDQeKdnNB--) {
            CJeFp += BKsaFJQJZYXuW;
            CJeFp *= CJeFp;
            BKsaFJQJZYXuW /= lTDLwrhiraotY;
            KcLpqUB += KcLpqUB;
        }
    }

    if (CwAyzqZpq < string("nIaXrRRZdBfwTwRsectReirOqnoSqegxFsNIcmJgRZFeFNLGNuScHtirlV")) {
        for (int jkjTfWaMmOv = 902237325; jkjTfWaMmOv > 0; jkjTfWaMmOv--) {
            qbhovS += BKsaFJQJZYXuW;
            lTDLwrhiraotY += FIJPejvLBnPIvfE;
        }
    }

    for (int ePlZPuKdgGAExDf = 1740580803; ePlZPuKdgGAExDf > 0; ePlZPuKdgGAExDf--) {
        continue;
    }

    return 276561215;
}

int CEYxPBZNpxBzT::xDkPTgsBa(bool ykMXWLrd)
{
    int dMRodgImJpEf = 582253751;
    string hcsLeNQ = string("BUPuzwCWwXRqExrDwJyOikkCBSvxTwwZuQnwjwJPYWznTZukjIqGIiSugfikVYuialGxRhYATqdKITUswuRaqYXdcRvpGGdrizHDwcBNoRxgwdoULErMGyIOFGWFNOSTvRQNPkEnl");
    string LTHzBLPdrfpjhsU = string("GoWzwPvLbOXxlOuGOonUmTYWwfVSURFesJtovhajgluUudawyVjbJDwvqTmkmOHmEyQAnVrmTNYYytvjQuWHFpQlGEdUvrLTQfXcnY");
    int dAHmSub = 1679028124;
    bool SZqXgzKyRblTH = true;

    for (int stZTxpXcCI = 1302721600; stZTxpXcCI > 0; stZTxpXcCI--) {
        continue;
    }

    return dAHmSub;
}

double CEYxPBZNpxBzT::ZFuuOLVFlvGZYl()
{
    string PCxRRfHiR = string("IaVKEIIjZniLDyXmnfvGeJxXmSUdXKhIsNSHPSzCyuSQxPZMnwJSiJUNZOWRGFXwjeJZuPQIunOopQVOmZpyhqVDIsCpfQyNSAMJXLmfvzktTonqnULtYdaBxIeOohyNcnhLzNVglvzGQQkyqaPMfWWMuKElhftHUnVhmilmhicJBYAp");
    string RqSVNsgsDfAdk = string("qrdIkbesteBhKnPfMXfoAbqotjKWyboeLISrPOCSldiFSsdBZMJpKDAEDtdcFRgucRDQQEXIZypzKrniiucatlNOPawnyflttgTQfPPMvhWWLEPXAViOtdTtqOyWZcHytITGs");
    double hwnCFxRogI = -812507.1963685272;
    int EilRDdzHKQpk = 1965652717;
    double djmWUmkaSrlHfDkN = 312238.24029306934;
    bool ljDnEQodzJ = true;
    int WbuMYx = 1004636920;
    int NPDJkNNB = -421868485;
    bool QmKLEpdeZWBGkx = true;
    double ewowbe = 356200.3266306162;

    return ewowbe;
}

string CEYxPBZNpxBzT::fhQBEuGWrOghgPO(int GZKXt, string EFIouD, bool ODrmwA, bool JPgomkaZJqZ)
{
    int heiDsaYVuT = -70892852;

    return EFIouD;
}

CEYxPBZNpxBzT::CEYxPBZNpxBzT()
{
    this->CxZXt(string("VJUcHAWkEUxGQvzJZxKxhvwvXhUwMTaFbFabIylVhfuAkzCIuZmLOVALbVpzScidLhbScSUySCAkVJDOPeqnhZtCSOnt"), -404053130, 75147.61878140614);
    this->WAxKkCkHx(620590.7645032093, true, 822893663, true, true);
    this->SYqicfLEqpHq(1318306434, string("IqVIcdIrxyukWLFsJbeKwEszJsTWhygbzViZXHwnWbGqIeSHgjmHPbBIoMmixzRcERUUtPLBGNqGBiczZhzddOaBsZdQ"), -764414.2928046101, 847254.1101570537, string("votyaKNPemoAgvA"));
    this->EfnCkn(-756925.6686610854, -1615287477, true, 446260.0282464295);
    this->TQdmSdTluotGA(string("CtKDtTINwRuIygqetEJxvoIbiWpAFRBLHGFzzpUBYYssnMMwTPIlZuiQnlfRMyAdJLhzVkiizhrQmomNzmgliTaLoNplZEdKCWzcYbIReIBeVtJRFViSrJHHGUsgupoVDgSsYuKoWIfWJDuWYHHxmwvlIWjgtV"));
    this->iwRhNOajlASwofaf(string("VqmsjyvkTfgWUKGHkaOUTXMwzFsSLMceiuUaKPXmzpWovAkUvrQeAocTQIyskJDWTHcZsOMEeTausyFkPWOgUgjjBQoSuJVhpiKrxRYyLnGVWqGOGxUcAxCihyHoVjEnoCwpMbSYqLAPhHWXIagiwxPGyBRZgJEdXWQjBxzBuHVCpUlfWUyCTPXaJYQqYYuFtUTPqaoxOpBnrovA"), 302410.494236378, -1989943627);
    this->mqfKyvqkEaulN(-211959.86483071317, -375650360);
    this->htOynQH(-1009316643, string("lObqYodKpdfgKUpESYSIqSWSWuuwrkwjxvRgJTiJmTohWnoqyQgQJvoorHMKdOUmyIZKqFKhopncjx"), -539086.7922491893);
    this->mgjBgEikjTwDV(442771330, 462591415);
    this->ivCrnQXqfJr(-1485059489, true);
    this->xDeoVcryYrhQGj(string("CIGhfXOawhuaTWbxMTYWTImtmQGyreVLiCzwvHiQqTGcIFvhOKRrttCwALPhaHfohNabPqwIZTPxtOUHFODsNfgWbWdACXbdLqoSrJKjBbkKpvEpRipGecUHjrbbPfDELBWDVkGrRMFvjMHxAPGYnXnRCOVZFovMkyTgAnkVfDKxNNHpOUNaHU"), string("phAhtTHtydevExPXmkwjFRuMACGVIEFMyaNCrScLagPYWggSMfvkYKNxviZBOTHMmGMBxTIXOpRscUOhQqtMPvyZczQbMzJzItyBkpbHwlDkgdhCmXnbBCzRCaPvyBWFSqqMzQGmvuEaVVJlAcqdzfxFTUYyTyyNVMWkLnXkjXsixPDLOxTHdPkXmdqVGWvOKqIPMdpxYBaMdE"), 154866.77088880754, 691200.2080822688);
    this->kMYovtUY(true, true);
    this->nGyzd(-901200.3171076291, string("WfvmTsFWWOgJRHGJDUUyJZFTJOJuNkANXVoRbxjAwHsLcTmTHXXOwoftuDEsVRzwMVnckJAfyZXhAdpFMGdNKJLmiPrCARpREhglrQKXmjaLKAcIvCQrqtvOazGXicEIHt"));
    this->xDkPTgsBa(false);
    this->ZFuuOLVFlvGZYl();
    this->fhQBEuGWrOghgPO(-1676866747, string("XjoGQdYJejXXWCxgORUBlpUDUJBwUPlKYGPKmpOVPJzpVGWRcjwmDuZlDEocgvtDuJTzjtiaJrQVIeeRfrPNDGnbJJOZhnrX"), true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xOcQeTYwL
{
public:
    string oyWPbJe;
    bool TJtGValdoqMwMX;
    double yWvmcHtedzuH;
    bool mZgNxLTU;
    bool EdtYfhHpQurw;
    bool WrZKLLMt;

    xOcQeTYwL();
    bool hptIe();
    double QTHWDkKHrjvfY(int XTNDmvsy, double pxOlGLXjPEDTXbs, string qRLraBd, string hNxmvWBIvHIGMa);
    bool rUtSG(bool LihVrqFqQzHWIg);
    string FiifMYtyIF(bool YwVOUyImNUOm, bool nFGXdKCIhHgvuc, string mZQIETZtuhBQgx, bool ZziZXGFnJ, string GcLdzpdKLu);
    void jFpRQth();
    bool IqHnXKEc(bool krDJn, double gFSUdfvVH, int pvJuMUyk, bool lRSHisUBhI, bool ehtYjXifaaYmCA);
protected:
    string FFWqXIXwWqXEu;
    double oErFYZdWDVGq;
    int eOGaPjiSwBxdxR;

    int wmkydbsKbisCFSo(double jEDnYKGxe, bool AmqqksNTQVuqxX, string NEllvNot, double SJPxeQ, int fNbhSFArs);
    string KWdnK(double xoZcCQFcn, double ksgWfOvZ, string sDVgrPAZBFJsmT, string jtZEEBRAfRvwt, int PYgrVrqpkgrvhppv);
    double BBSQaBkgKg(int bjkeziHxfOUh);
private:
    int vYvtDJHdSndmEA;

    void FbWGk(int GQXkSkUISPGsS, bool GSQTGusuEcxSct, double jXxkmszO, double gjnCtTfoNjM);
    double JIQbSvCxIBWZu(double LpZgJxHJJDqQFIt);
    void TcYUKLa(int FsJjeYnLcQEGxR, bool tjcken, bool tPKkK, string JONLloQnQjrw);
    int UUYEJzZqP(int fMnYbTbiYmTE, int TXqVSsrzyO, string hZSgOwMnbmfhWHL, bool SooyyRyJwcLvXB);
    double VZmDzoPusXYCmxWx(string xjHRhOYTjCpz, string oEkTzUAonYc);
    string NRVTNFgwVQ(double boWOpvvptzX, int BPChqAyCrdwARoe, bool RLxhfNFpWZ, bool cwBdRynfFbHFZ, bool sPKgrPn);
    void xBEeiUFhKT();
    void UFzyBxHYyGQTwbbU(double MLXIqjObWnceZGad, double IZwfvkToQjiiwuc, string JYOtFqB);
};

bool xOcQeTYwL::hptIe()
{
    string ANByhylQVh = string("zNAmXaKjsWEbkTPELHEOQgBmRAfisHzmkslItYTdBoFSiDRIPDqwvvZvLswqeItJowvqvwErKilVLQjLXraRJPKLaZaLMkLnSMWfJqinaZalbOcBjftWRJeRIDcplNruWCSlnsMcIQiMuNrRPiIWRowIvAyrxbAVOpRRmHwkeZDPSXdphDjyxEfwTHtXcYREVWEoMWxWJAIkviPwKJTXeZfpECTlXt");
    string twKHM = string("fZmRLGAVYypKNPMBglBlVXVsQrvfeRhYmdrobTATRDjlYLrqPuzvhhfZVbGVZWGqHlCxmySCSrhxTmnSEsLlrFFxMvyrCJQbDlYHOaXVwPOvGZoXXEpQqNinFAiFjrDBOzXvpMjqcPUfzvbCzLdHMzGCJZEzzzLNajyqgwfzckQzZajkUuYEM");
    int hnJqcGMGjoaiqaG = 1090626319;
    double LqPMhgauiULibUTN = -1001379.9097962726;
    bool iQlLvpqe = true;
    int ilFRQTIco = -747899126;

    for (int gApuQb = 1765439366; gApuQb > 0; gApuQb--) {
        iQlLvpqe = iQlLvpqe;
        twKHM += twKHM;
    }

    for (int AbSUzcK = 2128204829; AbSUzcK > 0; AbSUzcK--) {
        ANByhylQVh = ANByhylQVh;
        hnJqcGMGjoaiqaG /= hnJqcGMGjoaiqaG;
        LqPMhgauiULibUTN *= LqPMhgauiULibUTN;
        twKHM += ANByhylQVh;
        ilFRQTIco += hnJqcGMGjoaiqaG;
        ANByhylQVh = twKHM;
    }

    return iQlLvpqe;
}

double xOcQeTYwL::QTHWDkKHrjvfY(int XTNDmvsy, double pxOlGLXjPEDTXbs, string qRLraBd, string hNxmvWBIvHIGMa)
{
    int nTjEtKWCCg = -166854634;
    int XpPHSniSiYEVg = -110807491;
    string tZiruXZppR = string("UiFsdcZGMeTxxwxgZDoJFkmvRHAyjztHOMgkqAfDwqoPZDyBHPuIvvsVBWsIwkunmBxZYktvOKaADguHEysDKBYaAcKqGApfiLwIKlUusxmdkzCZEYJCmvYwDkZYcApZrAfFPmeXTgrownHGKXQjYjGfXVbsBOUdYaljAtgoIKjJFmJbkPvnNNIEweYXPBVyXu");
    bool sooVLTvYmE = true;
    bool gwvZCrrJvXbAi = false;

    for (int nGOXvQ = 1678941967; nGOXvQ > 0; nGOXvQ--) {
        hNxmvWBIvHIGMa += hNxmvWBIvHIGMa;
        gwvZCrrJvXbAi = sooVLTvYmE;
    }

    if (XTNDmvsy > -110807491) {
        for (int uyWPTHtp = 681153967; uyWPTHtp > 0; uyWPTHtp--) {
            hNxmvWBIvHIGMa = tZiruXZppR;
            nTjEtKWCCg -= XpPHSniSiYEVg;
        }
    }

    if (XpPHSniSiYEVg > -2132944632) {
        for (int SsWCzw = 1576880131; SsWCzw > 0; SsWCzw--) {
            hNxmvWBIvHIGMa += qRLraBd;
            XTNDmvsy = XTNDmvsy;
        }
    }

    if (XTNDmvsy == -110807491) {
        for (int ILcPGumfWsZnyACT = 616864632; ILcPGumfWsZnyACT > 0; ILcPGumfWsZnyACT--) {
            nTjEtKWCCg *= XTNDmvsy;
        }
    }

    return pxOlGLXjPEDTXbs;
}

bool xOcQeTYwL::rUtSG(bool LihVrqFqQzHWIg)
{
    int JFIav = 120358992;
    bool aZSrP = true;
    int ZyPyubaH = -612872823;
    int VqBXiBdqIQQ = 92084908;
    bool CMEpLED = true;
    bool VhADxBJpDe = true;
    bool ggSBxAMiNjVDiUfg = true;
    string GkArGcdZ = string("bYklESnqanslUCucgxzBryOxVBwObovOjpROzpdlpaNzwrhsvJSkIWmkxBruSSUuSCEyyXQRXgdaeYYCKOwQCMaIvKbWwYmIQECDqNrzHmKcCwIRQbWAMVmYKoLroMmKxtkpHFSEjYepmRRPXBWNcPQLxIifiHErkeFCsTgDE");
    double DlNZmtzu = -329031.9088420721;

    if (CMEpLED != true) {
        for (int fLSZgzRDhduK = 1917118338; fLSZgzRDhduK > 0; fLSZgzRDhduK--) {
            LihVrqFqQzHWIg = ! LihVrqFqQzHWIg;
            aZSrP = ! CMEpLED;
            ggSBxAMiNjVDiUfg = VhADxBJpDe;
            aZSrP = LihVrqFqQzHWIg;
        }
    }

    for (int XXvZjsUHeb = 1644464489; XXvZjsUHeb > 0; XXvZjsUHeb--) {
        LihVrqFqQzHWIg = aZSrP;
        LihVrqFqQzHWIg = CMEpLED;
    }

    return ggSBxAMiNjVDiUfg;
}

string xOcQeTYwL::FiifMYtyIF(bool YwVOUyImNUOm, bool nFGXdKCIhHgvuc, string mZQIETZtuhBQgx, bool ZziZXGFnJ, string GcLdzpdKLu)
{
    int DoGhXuPLrsoznj = 826360299;
    bool pQhhBXe = true;
    double YqBWHwum = 822654.414647894;
    int bHJFmFkP = 986875944;
    bool bHdGt = true;
    bool lbUVjMTMUWVEt = false;
    string QPIjCarkViCpP = string("CvollmfIMTcKVMIUKoHyUDrVlDlNyTSLZQnLtrLUGSOFlMjxfYWgOjxJgcRqxelQyVFiAxRJNUQQroMeVyoBQBiZtvzqaWDcqzBRIZhXdpAAQuRnDgxYneeTJYsY");
    double GJCNeQSfOjHuUI = -212016.18419144582;
    int kUNZubCcwixuJvfL = 367797740;
    bool RgTVQ = true;

    for (int NZzVXcMnRkeHdlxr = 1815695645; NZzVXcMnRkeHdlxr > 0; NZzVXcMnRkeHdlxr--) {
        continue;
    }

    if (lbUVjMTMUWVEt == false) {
        for (int ObFyhWIYpu = 2085430080; ObFyhWIYpu > 0; ObFyhWIYpu--) {
            pQhhBXe = ! lbUVjMTMUWVEt;
            ZziZXGFnJ = pQhhBXe;
        }
    }

    for (int cssnrQUrq = 354256858; cssnrQUrq > 0; cssnrQUrq--) {
        bHdGt = ! RgTVQ;
        DoGhXuPLrsoznj -= bHJFmFkP;
    }

    for (int aitcH = 974993010; aitcH > 0; aitcH--) {
        RgTVQ = ! RgTVQ;
    }

    return QPIjCarkViCpP;
}

void xOcQeTYwL::jFpRQth()
{
    string bJKveZ = string("dOoJQOkSeaYAydooGHEhPThlAplKbWRuHlRmJqJZJgkggGFlYOfMcPedclzhOJYHbVtBpXglQNREJlEiotLauCjqEvRzbfdcDmvSPABFAneaIrtVnbaqdWBcsVlCFmZguzltJjusWisgVJCsRrAiSDKdNJeQncVaEqkpBMxQnQgZwhfYUUaWJTsVVaguGYuFHnsYYZXlBiDYJZRExwZFLYXTfbhJzOtAppBWXBCpGggSdWU");

    if (bJKveZ > string("dOoJQOkSeaYAydooGHEhPThlAplKbWRuHlRmJqJZJgkggGFlYOfMcPedclzhOJYHbVtBpXglQNREJlEiotLauCjqEvRzbfdcDmvSPABFAneaIrtVnbaqdWBcsVlCFmZguzltJjusWisgVJCsRrAiSDKdNJeQncVaEqkpBMxQnQgZwhfYUUaWJTsVVaguGYuFHnsYYZXlBiDYJZRExwZFLYXTfbhJzOtAppBWXBCpGggSdWU")) {
        for (int TzHfkjDce = 886853900; TzHfkjDce > 0; TzHfkjDce--) {
            bJKveZ += bJKveZ;
            bJKveZ = bJKveZ;
            bJKveZ = bJKveZ;
            bJKveZ = bJKveZ;
            bJKveZ = bJKveZ;
            bJKveZ = bJKveZ;
            bJKveZ = bJKveZ;
            bJKveZ = bJKveZ;
        }
    }

    if (bJKveZ != string("dOoJQOkSeaYAydooGHEhPThlAplKbWRuHlRmJqJZJgkggGFlYOfMcPedclzhOJYHbVtBpXglQNREJlEiotLauCjqEvRzbfdcDmvSPABFAneaIrtVnbaqdWBcsVlCFmZguzltJjusWisgVJCsRrAiSDKdNJeQncVaEqkpBMxQnQgZwhfYUUaWJTsVVaguGYuFHnsYYZXlBiDYJZRExwZFLYXTfbhJzOtAppBWXBCpGggSdWU")) {
        for (int TlGaaY = 327728221; TlGaaY > 0; TlGaaY--) {
            bJKveZ += bJKveZ;
            bJKveZ += bJKveZ;
        }
    }
}

bool xOcQeTYwL::IqHnXKEc(bool krDJn, double gFSUdfvVH, int pvJuMUyk, bool lRSHisUBhI, bool ehtYjXifaaYmCA)
{
    int bMvPxxxbXXEvtKIz = -1710848905;
    string iRIwyrYEJmDBJoIR = string("MuauFKJaYlgfJucMlEwuGElOnGBhUOXSIwyvvntqpboHFJlGcJCfURNrPcReneSLlgMnZTkNQgJHUsQKZeAvgQAcxObfDWjlCAbomhAFeJYRbjUIbvzNFMsdfgcYkhlqIoiiZnixOncAnBrcGsypxhNvctNEnlDjuvALYEQgKluvSbnWrWKxLKjrMvICoYmoGtlxnACAhwKqinvWorncwiaysRbhBWYCWMcDNDUN");
    int vOOnkiXlh = -255146723;
    int twPhprk = 1212453497;
    bool BhWWc = true;

    for (int YIjMAcrceUvxMtls = 1932248066; YIjMAcrceUvxMtls > 0; YIjMAcrceUvxMtls--) {
        vOOnkiXlh = pvJuMUyk;
    }

    for (int MvhuIod = 2095187814; MvhuIod > 0; MvhuIod--) {
        BhWWc = ! ehtYjXifaaYmCA;
        vOOnkiXlh /= bMvPxxxbXXEvtKIz;
    }

    for (int OrjHfske = 38805371; OrjHfske > 0; OrjHfske--) {
        krDJn = ! krDJn;
        BhWWc = ! lRSHisUBhI;
        ehtYjXifaaYmCA = lRSHisUBhI;
        vOOnkiXlh *= twPhprk;
    }

    for (int gXTVnIn = 1026343890; gXTVnIn > 0; gXTVnIn--) {
        krDJn = ! BhWWc;
        pvJuMUyk += twPhprk;
    }

    for (int lqorNAnamCYPm = 632512428; lqorNAnamCYPm > 0; lqorNAnamCYPm--) {
        lRSHisUBhI = lRSHisUBhI;
        bMvPxxxbXXEvtKIz += vOOnkiXlh;
        iRIwyrYEJmDBJoIR = iRIwyrYEJmDBJoIR;
        bMvPxxxbXXEvtKIz /= vOOnkiXlh;
        krDJn = ! krDJn;
    }

    if (lRSHisUBhI != true) {
        for (int dQNaEIzMvxUx = 445725544; dQNaEIzMvxUx > 0; dQNaEIzMvxUx--) {
            vOOnkiXlh = twPhprk;
            krDJn = ! lRSHisUBhI;
        }
    }

    for (int SewdOTsVfHsJ = 1289934797; SewdOTsVfHsJ > 0; SewdOTsVfHsJ--) {
        continue;
    }

    return BhWWc;
}

int xOcQeTYwL::wmkydbsKbisCFSo(double jEDnYKGxe, bool AmqqksNTQVuqxX, string NEllvNot, double SJPxeQ, int fNbhSFArs)
{
    bool mdEmbTeeRTtcoXB = true;
    bool QsUTgxR = true;
    bool URXFcXuFkUITY = false;
    int oyFmDJALakhcRV = -1109178926;
    string ZvELlrDpQOWYEU = string("SEjVntKgYPCZcQpUdzgMlMVBdAmoanxyDlUF");
    double nxLGm = 308793.8821803553;

    for (int varEAPfYD = 1037306329; varEAPfYD > 0; varEAPfYD--) {
        continue;
    }

    for (int WJOaGW = 499049736; WJOaGW > 0; WJOaGW--) {
        continue;
    }

    return oyFmDJALakhcRV;
}

string xOcQeTYwL::KWdnK(double xoZcCQFcn, double ksgWfOvZ, string sDVgrPAZBFJsmT, string jtZEEBRAfRvwt, int PYgrVrqpkgrvhppv)
{
    bool oPGnEpXdH = false;
    int DRuBFAMkgZn = 1910106791;
    string VPHhEhbxLTQPv = string("UfrzzcHdbgrKpYDvPOeKoVymQkSKswNHHXiQPVDbPXTjuUtGKFNSUYzeULLMYcswKeAN");
    int FBJUMmHnIpy = 1449940712;
    double mOwzNcGRBS = 637077.3299833601;
    double DGLyZRDxZqDxNdbh = -901488.0368766383;
    int vYQzLrE = 987974097;

    if (ksgWfOvZ != -901488.0368766383) {
        for (int KzeqXhpXkKMApk = 1427649005; KzeqXhpXkKMApk > 0; KzeqXhpXkKMApk--) {
            continue;
        }
    }

    for (int FtVDNbYdj = 922953012; FtVDNbYdj > 0; FtVDNbYdj--) {
        DRuBFAMkgZn += PYgrVrqpkgrvhppv;
        xoZcCQFcn *= DGLyZRDxZqDxNdbh;
        VPHhEhbxLTQPv = VPHhEhbxLTQPv;
        FBJUMmHnIpy *= PYgrVrqpkgrvhppv;
        vYQzLrE = FBJUMmHnIpy;
    }

    for (int IplyrTcvudPI = 206383295; IplyrTcvudPI > 0; IplyrTcvudPI--) {
        xoZcCQFcn *= ksgWfOvZ;
    }

    for (int iYFoKEEYMCj = 2056255104; iYFoKEEYMCj > 0; iYFoKEEYMCj--) {
        sDVgrPAZBFJsmT += sDVgrPAZBFJsmT;
        PYgrVrqpkgrvhppv -= FBJUMmHnIpy;
        VPHhEhbxLTQPv = VPHhEhbxLTQPv;
        DGLyZRDxZqDxNdbh *= mOwzNcGRBS;
    }

    for (int rGgnzJUDlQwR = 1014511393; rGgnzJUDlQwR > 0; rGgnzJUDlQwR--) {
        DGLyZRDxZqDxNdbh = mOwzNcGRBS;
        xoZcCQFcn = xoZcCQFcn;
    }

    return VPHhEhbxLTQPv;
}

double xOcQeTYwL::BBSQaBkgKg(int bjkeziHxfOUh)
{
    int kLtAEEST = -529794904;
    int ZoTywm = -1585494493;
    int oXEnlR = -2016719914;
    bool lHwIHBaJXDJPP = false;
    bool ohMyGcJtmyGkmge = true;
    bool cEWYSdvwaPciNviO = false;
    int YEbSblqIpBkjDx = 1893172997;
    int VJRuGBuVpeasmKKE = 1660817938;

    for (int GUspMoJtbieRT = 1031085186; GUspMoJtbieRT > 0; GUspMoJtbieRT--) {
        VJRuGBuVpeasmKKE -= kLtAEEST;
    }

    if (YEbSblqIpBkjDx == -529794904) {
        for (int iWLNnOBcAvg = 1667488602; iWLNnOBcAvg > 0; iWLNnOBcAvg--) {
            YEbSblqIpBkjDx -= VJRuGBuVpeasmKKE;
            ohMyGcJtmyGkmge = ! lHwIHBaJXDJPP;
            VJRuGBuVpeasmKKE *= oXEnlR;
            oXEnlR -= VJRuGBuVpeasmKKE;
        }
    }

    if (cEWYSdvwaPciNviO == false) {
        for (int VpqrTlFH = 911195550; VpqrTlFH > 0; VpqrTlFH--) {
            VJRuGBuVpeasmKKE += bjkeziHxfOUh;
        }
    }

    if (cEWYSdvwaPciNviO == true) {
        for (int WCBxNrBC = 964622718; WCBxNrBC > 0; WCBxNrBC--) {
            ohMyGcJtmyGkmge = lHwIHBaJXDJPP;
            ZoTywm = VJRuGBuVpeasmKKE;
            ZoTywm *= ZoTywm;
            kLtAEEST += VJRuGBuVpeasmKKE;
            cEWYSdvwaPciNviO = ohMyGcJtmyGkmge;
            oXEnlR -= VJRuGBuVpeasmKKE;
        }
    }

    return 188630.26667290038;
}

void xOcQeTYwL::FbWGk(int GQXkSkUISPGsS, bool GSQTGusuEcxSct, double jXxkmszO, double gjnCtTfoNjM)
{
    bool rqaJjih = true;
    string ayHUUxv = string("VwXyekFCnYTyTXEEvMeRUaPGPmmQXmWSZPFGKRXzmFfqGmpliMlBJGQpCeyotviRdJLVRGItQMaZKXnykWZwBx");

    for (int dOJRwHCuXdTO = 938670698; dOJRwHCuXdTO > 0; dOJRwHCuXdTO--) {
        GSQTGusuEcxSct = ! rqaJjih;
        jXxkmszO *= jXxkmszO;
        jXxkmszO -= jXxkmszO;
    }

    if (GSQTGusuEcxSct == false) {
        for (int EfFROfzbL = 1250273197; EfFROfzbL > 0; EfFROfzbL--) {
            GSQTGusuEcxSct = GSQTGusuEcxSct;
            ayHUUxv = ayHUUxv;
            jXxkmszO = jXxkmszO;
        }
    }

    for (int IwhUFhFPCMldQCfF = 697803489; IwhUFhFPCMldQCfF > 0; IwhUFhFPCMldQCfF--) {
        GSQTGusuEcxSct = ! rqaJjih;
        GSQTGusuEcxSct = ! rqaJjih;
    }
}

double xOcQeTYwL::JIQbSvCxIBWZu(double LpZgJxHJJDqQFIt)
{
    bool UZDzHzGEHBaBn = true;
    string MgLrgocXXIR = string("JNlYAkKdkZxTVLNgzoKsXkVFJyTndaNrPAiLXOmhZemjHTBEqTOnwqKeHZphdKUviHPWuDeRwQpHVEJYJXjjBqVBxVAuijUnZC");
    double DLezE = 882681.7117103614;
    string eiHvxxqMcNSZ = string("AEmhVmuUNlsNcDtAwOgMXuuVkCaCiKTIAbGkhRcfClNjDwlLqRkSosyMZnRqaAJEbTwetUQPXqZWtNNriVwYRSmfSCFXGCfYCEjKCjJcfDsVwnBnTOIXOOUYOJTHC");
    int rojmaR = -458589358;
    string TPIpCcJ = string("AMnDpreocsRfhmtPmIqIaEr");
    string ujQpWfEOBxvw = string("oUeBTdsfNHQHRtlkniogZhIfVCqGhMj");

    for (int xnnYoCIGgPx = 649271350; xnnYoCIGgPx > 0; xnnYoCIGgPx--) {
        ujQpWfEOBxvw = TPIpCcJ;
        DLezE /= LpZgJxHJJDqQFIt;
    }

    for (int gMYYwVMkUmKmxhXa = 638644573; gMYYwVMkUmKmxhXa > 0; gMYYwVMkUmKmxhXa--) {
        MgLrgocXXIR = MgLrgocXXIR;
    }

    for (int YMowRxpfILuR = 297284966; YMowRxpfILuR > 0; YMowRxpfILuR--) {
        MgLrgocXXIR = TPIpCcJ;
        ujQpWfEOBxvw += MgLrgocXXIR;
    }

    return DLezE;
}

void xOcQeTYwL::TcYUKLa(int FsJjeYnLcQEGxR, bool tjcken, bool tPKkK, string JONLloQnQjrw)
{
    string UpQbky = string("CkRPKyCHiuzhGSZlMIswIktqJLNSWyXyiAZodwnYdgLgtZmFBHZSOuNMvTitCTdHBvwpQMiTnHteRCiIXWyAsgZtAgwoVaQiuQlQmNiwqaerSZKWWfnbPjrfnxFFXjiELZXHWLuSkINNJvZFTcIvIlMJPVhPCLrQVvPHImJSRhe");
    bool adECLeNy = true;
    bool leyDShKCCSdxYpqx = true;
    bool DwkkGVGDrPKV = true;
    double bivgjRATgxYipSr = -847460.3088863343;
    int xopSBOcyGkYX = -217592807;
    bool KTVPJybsYItjk = true;
    int uXnkW = -426574976;
    bool wuuWbWJlbG = true;
    double OGacjLwaoEI = 723184.1709065353;

    for (int fvFKIefw = 1072025080; fvFKIefw > 0; fvFKIefw--) {
        leyDShKCCSdxYpqx = ! leyDShKCCSdxYpqx;
        KTVPJybsYItjk = wuuWbWJlbG;
    }

    for (int lbgxBhNBh = 1837608928; lbgxBhNBh > 0; lbgxBhNBh--) {
        wuuWbWJlbG = leyDShKCCSdxYpqx;
        tjcken = ! tjcken;
    }

    for (int tfSKKiyDIEUu = 1848399681; tfSKKiyDIEUu > 0; tfSKKiyDIEUu--) {
        leyDShKCCSdxYpqx = tPKkK;
        xopSBOcyGkYX /= FsJjeYnLcQEGxR;
        bivgjRATgxYipSr = OGacjLwaoEI;
    }
}

int xOcQeTYwL::UUYEJzZqP(int fMnYbTbiYmTE, int TXqVSsrzyO, string hZSgOwMnbmfhWHL, bool SooyyRyJwcLvXB)
{
    bool pqDkNECksZgo = false;

    return TXqVSsrzyO;
}

double xOcQeTYwL::VZmDzoPusXYCmxWx(string xjHRhOYTjCpz, string oEkTzUAonYc)
{
    double UmhTxs = -587795.4031069956;
    string VCXAvgnxfiOR = string("LnFsYRJExZIdzfTiNumypZmuuLAWI");
    double PSEXrCQOkHrKJaK = 51213.82390373065;
    int XRJHU = 642810491;
    int qsClsNHJuG = 397546088;
    bool eRbvprhvz = true;
    double nflanYZ = 664690.8089723025;
    bool PvYuyCKoMss = false;
    int TcrKrjXe = -237484785;

    for (int juREmjw = 770077997; juREmjw > 0; juREmjw--) {
        XRJHU -= TcrKrjXe;
    }

    for (int ipMBLRXqxBgql = 7736621; ipMBLRXqxBgql > 0; ipMBLRXqxBgql--) {
        continue;
    }

    return nflanYZ;
}

string xOcQeTYwL::NRVTNFgwVQ(double boWOpvvptzX, int BPChqAyCrdwARoe, bool RLxhfNFpWZ, bool cwBdRynfFbHFZ, bool sPKgrPn)
{
    string LiiJSTzgEztdr = string("NBCtsoqoHTVBfptsHLOglLICxduutHnTQGOakNqpubFzirXAuaSWaCihOioqjNijYPbNMFHOFLTmMXwvpWvepbACLRXktaSAdhakiQvvjnEIOqAxEybpcJYRKWByGAnXIqDPXQSIiNKvTZVBlrpOXENisBdNSLigJZJP");
    double jmgxN = 804770.6187412016;
    double CUqlZrl = 831183.1256185144;
    string fKyqz = string("etzAHWjyDXTrgwjLSEVjORhMlLQHNlNuKJMYRbeC");
    int mvjhvNclyCvH = -1743483552;
    double HmhviShQzk = 416804.7273037373;
    bool wWTLjKXqV = false;

    for (int zVXydHpV = 1091078782; zVXydHpV > 0; zVXydHpV--) {
        continue;
    }

    if (CUqlZrl > 831183.1256185144) {
        for (int pgWWXSTYYOzCCsr = 1862344598; pgWWXSTYYOzCCsr > 0; pgWWXSTYYOzCCsr--) {
            HmhviShQzk *= CUqlZrl;
            cwBdRynfFbHFZ = ! cwBdRynfFbHFZ;
        }
    }

    for (int ToqKljxpRE = 1792100523; ToqKljxpRE > 0; ToqKljxpRE--) {
        boWOpvvptzX += jmgxN;
        cwBdRynfFbHFZ = RLxhfNFpWZ;
        HmhviShQzk += CUqlZrl;
    }

    for (int oaXYZJsVSQxSx = 288665686; oaXYZJsVSQxSx > 0; oaXYZJsVSQxSx--) {
        wWTLjKXqV = RLxhfNFpWZ;
        cwBdRynfFbHFZ = ! cwBdRynfFbHFZ;
    }

    return fKyqz;
}

void xOcQeTYwL::xBEeiUFhKT()
{
    string JUKQfZMcsCEuJ = string("xcALakMzVPdPgHXczcMxFavjTbBYchqXjFncV");

    if (JUKQfZMcsCEuJ == string("xcALakMzVPdPgHXczcMxFavjTbBYchqXjFncV")) {
        for (int inmCdqLsxfcqkFJ = 600238150; inmCdqLsxfcqkFJ > 0; inmCdqLsxfcqkFJ--) {
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
        }
    }

    if (JUKQfZMcsCEuJ < string("xcALakMzVPdPgHXczcMxFavjTbBYchqXjFncV")) {
        for (int yueCFjxcZoZyWgF = 333766644; yueCFjxcZoZyWgF > 0; yueCFjxcZoZyWgF--) {
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
        }
    }

    if (JUKQfZMcsCEuJ != string("xcALakMzVPdPgHXczcMxFavjTbBYchqXjFncV")) {
        for (int zapGJSjZoi = 1898917760; zapGJSjZoi > 0; zapGJSjZoi--) {
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
        }
    }

    if (JUKQfZMcsCEuJ < string("xcALakMzVPdPgHXczcMxFavjTbBYchqXjFncV")) {
        for (int xnXTvPPTMTuwNf = 1138730588; xnXTvPPTMTuwNf > 0; xnXTvPPTMTuwNf--) {
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ += JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
            JUKQfZMcsCEuJ = JUKQfZMcsCEuJ;
        }
    }
}

void xOcQeTYwL::UFzyBxHYyGQTwbbU(double MLXIqjObWnceZGad, double IZwfvkToQjiiwuc, string JYOtFqB)
{
    double LUejJcCCS = 197586.10144680517;
    bool rcQbqsCbWl = true;
    double SlhXDcUgX = 63802.769620329855;
    double mBmrfIeRHu = -38198.057391117494;
    double eFKeZPWM = 475018.5427919221;
    string vLyIVnbYV = string("ndnpuDIBwrLcrDSaNJMNNPNVJAFrn");
    int OPugzUcjm = -228636341;
    bool TmudepCX = false;
    bool aAWyraIK = false;
    int udiLhxJjYVDHM = -1572021309;

    for (int LLiMZPXgndspElF = 602353470; LLiMZPXgndspElF > 0; LLiMZPXgndspElF--) {
        udiLhxJjYVDHM -= udiLhxJjYVDHM;
        OPugzUcjm /= udiLhxJjYVDHM;
    }

    for (int hEiYikFIT = 1647485141; hEiYikFIT > 0; hEiYikFIT--) {
        IZwfvkToQjiiwuc = SlhXDcUgX;
        MLXIqjObWnceZGad += mBmrfIeRHu;
        SlhXDcUgX -= IZwfvkToQjiiwuc;
    }

    for (int eobVlUafGk = 440102067; eobVlUafGk > 0; eobVlUafGk--) {
        SlhXDcUgX *= SlhXDcUgX;
        LUejJcCCS = mBmrfIeRHu;
    }

    if (LUejJcCCS > 475018.5427919221) {
        for (int aeDqlhCT = 1052885336; aeDqlhCT > 0; aeDqlhCT--) {
            continue;
        }
    }

    for (int QldeYZdCFTHpmiBi = 1369688391; QldeYZdCFTHpmiBi > 0; QldeYZdCFTHpmiBi--) {
        aAWyraIK = ! aAWyraIK;
        aAWyraIK = aAWyraIK;
        eFKeZPWM /= SlhXDcUgX;
        eFKeZPWM *= LUejJcCCS;
        SlhXDcUgX = LUejJcCCS;
    }

    for (int XkmeU = 791984190; XkmeU > 0; XkmeU--) {
        LUejJcCCS = SlhXDcUgX;
        JYOtFqB = JYOtFqB;
        mBmrfIeRHu += IZwfvkToQjiiwuc;
    }
}

xOcQeTYwL::xOcQeTYwL()
{
    this->hptIe();
    this->QTHWDkKHrjvfY(-2132944632, 826927.1989246864, string("fsoqflbxOVADRZCZzjGGnIBwzCWQDWYdIbOUhoODoZYnwxWvHvZkalpKdiVZMlKmWTrAlIietvXdOAHLTpWYtQWedkcfxQqcRGviQOCmZmCrpufQgXIHgPHgOAhIiXCQlGemTpKxWriNuayavGLamRsquVatRqhTAMFxJ"), string("PgqgFOmZlXQmqvdkhvpyNmhAVaVnlaeSVsyttWYhIbOnQUmeGTHbKIdjMTnpzNCJPxezuqsbxCBzMjhbmabKHOKpbFMWFxLgJbxaHGtMqSGbdxgsyUyOcVaMgXmqdQGaqiLcoEUltpvxjmjQIYhyIBRhpBVbxGtkBUAUJYIiFTAxYjVHGfU"));
    this->rUtSG(true);
    this->FiifMYtyIF(false, false, string("tAJVHeiKwGUhlNIWitjMjpkRvzUlpmBdUOAyAyFbOZHBMwFudqyHWuGYsPFTtIoKKVlRxopQeIlddNFqgqJFGklqqgidenBJ"), false, string("rMyhRpmIkHDAVuyogHJeANYqMvGimWnuhlAUwSslbsRmMacufYAlFxCKvlnuioBPXPUbFgBXDYfgKgcpkxAXZOrBwSBQwjydLfzFdDnWaPXDLizpEemnYuaRawlaMfHfCV"));
    this->jFpRQth();
    this->IqHnXKEc(true, 254939.30677962888, -1323289803, false, false);
    this->wmkydbsKbisCFSo(-968180.5802098063, false, string("iEpCHyTbxdTboqDRCowPKaXHLNhSZpHgKqefPOYakpaWlGaLTTpcXOtDLTlwINAzIcNSgHFvjlcrDFBPiMBbsHthznbhicxggYyDkAZvDLuGbRyCDejWfIYydbVISTjTSzEWAAQYpYQMPDjPAnbuUPtebdzNgwyJvhdlGwGZpUEsPgXoreYqFfhAfnqRBWEIn"), -638169.2491509409, 1220117144);
    this->KWdnK(-954924.951453125, -263231.60464037344, string("aDNTNaDaJiplKPAEysTJHgPCopNGGwphcNlgRyzZqFkQcnZbIyYQxqFlogqGLkEoITsQsVinBpBYkQugwMaHfRPyfEphqgiHEBIsuioHSWjHJEwExqrbsKfcDruKwCUudTONjBBvulRZdFAXaLZfENymJrCRXdHjELRCelpIyHqbYehTzmgwscadeVJlDFTAVQWarqfPuoePQtoIJRuVTQysyfBhOyLHpkeHmJOWMTLCuhjLjwV"), string("kjafYvXRztNMsIillHfnzvmGtRcRSKotbWIllFloUWHihsZsEcIfdtbktcJSusdPBUBFORxTFWKgzkfTtCpeVXDhlcOlbIZDfuDhkamZvvjwhguJIoTeZXgTpYbSAgoFjhUuEZyLIkluhZGn"), -1818589582);
    this->BBSQaBkgKg(-1255128108);
    this->FbWGk(-803094838, false, 321438.3999738397, -9909.734139167598);
    this->JIQbSvCxIBWZu(957243.1578017466);
    this->TcYUKLa(1482532839, true, true, string("LkytnEpFVmfSTETVLDGZdEAyXikTXEcRNQWXZuFxFNIOenyRsNTIxpMXvNPxwKmsiRuiPRbobahMFOREOpxhZdQRDBYOOPNlibgFUBAYtWKDoPpyrsNQxWtejGcPbTkvvBXvBQiyKKhzWMaKVLrGtkLtwuAXnxYzADzISyUNUWfmHnCIprjOVwNmyjyMcTehVDnVZBdWzWDQCVNjYKMqNiSIsBuubHTgqnxbWmlfVjB"));
    this->UUYEJzZqP(1120951497, 2109252625, string("HkfQcqrAgqKfjhUIwTHjnKPkjNMHGWOKXIClAfcTSjwkjrZDuvhnLFXMqJspuYErkFbcyeQaZGbha"), false);
    this->VZmDzoPusXYCmxWx(string("ipZLKCOwEUvRwacUSMkMHPNVPR"), string("xSMedgEtzXKVvKkvHVeNbbtCkrKkTxdFsxmjbmsFkisSwdfswcSbndeAgkJiMfypTHuJvqOxSHH"));
    this->NRVTNFgwVQ(399692.2582372641, 33167264, false, false, true);
    this->xBEeiUFhKT();
    this->UFzyBxHYyGQTwbbU(-501734.73913322965, -419367.5041807095, string("JohcxipulIEdvWFeptaUWGfNEqNiybiYwjLFnldMOZIFTcPDRCj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qSKmsfOt
{
public:
    string hGvOkggpRZdGTYK;
    int yxcWNIjGjDUvBR;
    bool pNbCKlsnKmSoT;
    int rlJrQG;
    int awKNNefd;

    qSKmsfOt();
    double zdStTlyTub(double FUWBXWRPOXKgQnDI, double OMWTCBEDzyuU, int DcACvMWArbjOK, double MRINKcLQ, int XHnoOGz);
    string sKtTBgdxivBN(double SKvdVTXUjL, int TBzXVmmWSZyqfBOm, double HAHhKQxT);
    void MhAMyed(int dLRbdIxqf, int XgMapIz, double GzGNTqrKXzaAuDuH);
    double NjEHRyjYD();
    string iTElk(double gQRra, bool qdtxhlqDYiZEjaa, double pqufz, bool PYJMMQnAt, double VsLXVEMwW);
    string MRdZfm(int irvPUoaMf, double fyVDAcYH, bool iMzPXoEE, int CuctRTHg, string gWfIMxcflVrL);
protected:
    double HFRRDbiatfrDmZQ;
    double gjFiq;
    int hINoUVFRPgpC;
    bool XFrSs;
    int RddxpbUdLEq;

    double xyROVxAk(string VfOpl, int VcjHpONI);
    bool mszIBCag(int XvTiDrxyeNh, double TbWzYwbdyE, int xjDWnvPnS, bool BYedlIyI, int fNhevrdYSmGxcVbL);
    string ztpKjzw(double qYXXlJ, string zbJlTZlZLbajTCu, bool duXyrHVAC, bool orqTLc, bool eBuqpPrPACJKJEK);
    string bXeofWQ(double JtZSifELKuOeu, string YMIBdeFS, bool olMwtNCDRIPHRAIG);
    double vwFfyyg(bool HZTgkyS, bool aLGkX);
    string bcKqTSqiXYJ(string qNrlRXJLct, bool FAnDTpaHifVmna, double SUuoHMzkVBLxrXP);
    string DxndJq(double MWMdkART, string cYSqzYZfngtbSfe);
    bool dEnDDgtUSgighKPq(double yYQVN);
private:
    string EBhxHSByutObNcb;
    int dWtwiE;
    int IcUmdtv;
    double ZcQsqB;
    bool pgrcJYJQPt;
    bool pRwEvtOnyVRZoYRH;

    bool wLXFWKNPyLgkVxwp(bool PJMZlsrOSAQYji);
    string bADKghaCRWST(string uhqDUxNkemzeoW, string ZQTqHkJUGzzVxM);
    string nDUSzDa(bool yfRNqpmWh);
    double cjfsxUmPfQ(double ddyjoCRIs, int BPeGQM, int NQRacnYZCsZnCeR, double kWXzg, bool WAwRwlpdaNYW);
    int UxVxDA(bool YazAVxn, bool fzLFyNZALkI);
    double wFFlpayqqw();
};

double qSKmsfOt::zdStTlyTub(double FUWBXWRPOXKgQnDI, double OMWTCBEDzyuU, int DcACvMWArbjOK, double MRINKcLQ, int XHnoOGz)
{
    double IdadGRFkwhFmWn = 436925.88509315456;
    bool HCxLaIulrH = false;
    double xDdaPBTDthwQDJr = 565530.3240809861;
    string ZCabzcD = string("xhLrudmhHMJIXOXQtjqaWfrusAKQHITC");
    double XrtBycuHGmcl = -713226.3908395206;
    int HuBOULlHQCrKukpP = -463765772;
    bool HusQDONPsCEby = true;

    for (int DPgVapulyOBTHOY = 65472452; DPgVapulyOBTHOY > 0; DPgVapulyOBTHOY--) {
        XrtBycuHGmcl *= MRINKcLQ;
        IdadGRFkwhFmWn += IdadGRFkwhFmWn;
        FUWBXWRPOXKgQnDI /= xDdaPBTDthwQDJr;
    }

    for (int lNwiPVXksZwAch = 761609107; lNwiPVXksZwAch > 0; lNwiPVXksZwAch--) {
        IdadGRFkwhFmWn -= XrtBycuHGmcl;
    }

    if (FUWBXWRPOXKgQnDI < -713226.3908395206) {
        for (int VPCRMpAqtbIT = 1455285696; VPCRMpAqtbIT > 0; VPCRMpAqtbIT--) {
            continue;
        }
    }

    for (int idwIEZTfSDB = 673658462; idwIEZTfSDB > 0; idwIEZTfSDB--) {
        XrtBycuHGmcl -= OMWTCBEDzyuU;
    }

    for (int fFHCVbpny = 1656017202; fFHCVbpny > 0; fFHCVbpny--) {
        xDdaPBTDthwQDJr *= MRINKcLQ;
        XrtBycuHGmcl *= IdadGRFkwhFmWn;
        MRINKcLQ *= xDdaPBTDthwQDJr;
    }

    return XrtBycuHGmcl;
}

string qSKmsfOt::sKtTBgdxivBN(double SKvdVTXUjL, int TBzXVmmWSZyqfBOm, double HAHhKQxT)
{
    int tjJycHiDIkZOGu = -96594285;
    string CgAEenG = string("ckeCxvsnOZhXXQdjWIjmwYZTeSWjOsjjCsGjFUJGeUtZoQGWDLXXirquKqjNFDxMkfjvlTaORofoAqWyKte");
    bool fciyUtF = true;
    double WnomDoRYepPeAA = 351165.9840259421;
    double RrmlOXzCK = -973910.5439352046;
    bool SoUhAwrWzzTIWHV = false;
    bool BqyUPLcOCnZLRP = true;
    int XlhxxJhzw = -1071383831;

    for (int xrSqHZIcQ = 952178939; xrSqHZIcQ > 0; xrSqHZIcQ--) {
        SKvdVTXUjL *= RrmlOXzCK;
        HAHhKQxT -= SKvdVTXUjL;
        XlhxxJhzw -= XlhxxJhzw;
    }

    for (int uqiSRdWOt = 2052017462; uqiSRdWOt > 0; uqiSRdWOt--) {
        SoUhAwrWzzTIWHV = ! fciyUtF;
        HAHhKQxT *= SKvdVTXUjL;
    }

    return CgAEenG;
}

void qSKmsfOt::MhAMyed(int dLRbdIxqf, int XgMapIz, double GzGNTqrKXzaAuDuH)
{
    bool zDxrwtuFxdBvqq = true;
    string aGSNFTO = string("RKlmGAzsyHNopSgDqNFhWxyMMfAnfvuxIVKwpyKDQlsYoCSXnChGgZQIGVYelIKVORIMHdvtGtJmjXWvspSWdKCiIvjhIcuDDZLpqBMaDIUXrxuVLatimPpHuvwlpWnMZpgORtqfpVveCmMvDtoVWtInNHWFZRsZktCnTPdesrgeNFiwGfRosIWKstuOWKdcnWjyQjBDAAwKAkbzGGJsLVjBRFgkCP");
    bool ptDqbCstbHXIxs = true;

    if (dLRbdIxqf >= 1951117308) {
        for (int KYSyTodQjzhNjf = 1082079325; KYSyTodQjzhNjf > 0; KYSyTodQjzhNjf--) {
            continue;
        }
    }

    for (int wVmgOFZdUs = 949642308; wVmgOFZdUs > 0; wVmgOFZdUs--) {
        GzGNTqrKXzaAuDuH *= GzGNTqrKXzaAuDuH;
        zDxrwtuFxdBvqq = ! ptDqbCstbHXIxs;
    }

    for (int WdZHvgYnGbBKzZ = 1415309585; WdZHvgYnGbBKzZ > 0; WdZHvgYnGbBKzZ--) {
        zDxrwtuFxdBvqq = ! ptDqbCstbHXIxs;
    }

    for (int fRxAWmDNXKdbx = 2012565985; fRxAWmDNXKdbx > 0; fRxAWmDNXKdbx--) {
        ptDqbCstbHXIxs = ! zDxrwtuFxdBvqq;
    }

    for (int sSgSYRUGpa = 1292827236; sSgSYRUGpa > 0; sSgSYRUGpa--) {
        GzGNTqrKXzaAuDuH = GzGNTqrKXzaAuDuH;
        GzGNTqrKXzaAuDuH += GzGNTqrKXzaAuDuH;
        dLRbdIxqf /= XgMapIz;
        ptDqbCstbHXIxs = zDxrwtuFxdBvqq;
    }
}

double qSKmsfOt::NjEHRyjYD()
{
    double KMqwxafhgMonuK = -728759.8128113924;

    if (KMqwxafhgMonuK < -728759.8128113924) {
        for (int dcfxqkDgs = 720320813; dcfxqkDgs > 0; dcfxqkDgs--) {
            KMqwxafhgMonuK = KMqwxafhgMonuK;
            KMqwxafhgMonuK /= KMqwxafhgMonuK;
            KMqwxafhgMonuK *= KMqwxafhgMonuK;
        }
    }

    if (KMqwxafhgMonuK <= -728759.8128113924) {
        for (int oCMccmcWwehw = 173440118; oCMccmcWwehw > 0; oCMccmcWwehw--) {
            KMqwxafhgMonuK = KMqwxafhgMonuK;
            KMqwxafhgMonuK /= KMqwxafhgMonuK;
            KMqwxafhgMonuK += KMqwxafhgMonuK;
            KMqwxafhgMonuK *= KMqwxafhgMonuK;
        }
    }

    if (KMqwxafhgMonuK != -728759.8128113924) {
        for (int vJkZqvW = 1115143668; vJkZqvW > 0; vJkZqvW--) {
            KMqwxafhgMonuK *= KMqwxafhgMonuK;
            KMqwxafhgMonuK /= KMqwxafhgMonuK;
        }
    }

    if (KMqwxafhgMonuK != -728759.8128113924) {
        for (int fiIjqxEMm = 165171193; fiIjqxEMm > 0; fiIjqxEMm--) {
            KMqwxafhgMonuK = KMqwxafhgMonuK;
            KMqwxafhgMonuK += KMqwxafhgMonuK;
            KMqwxafhgMonuK /= KMqwxafhgMonuK;
            KMqwxafhgMonuK = KMqwxafhgMonuK;
            KMqwxafhgMonuK /= KMqwxafhgMonuK;
            KMqwxafhgMonuK += KMqwxafhgMonuK;
            KMqwxafhgMonuK -= KMqwxafhgMonuK;
            KMqwxafhgMonuK += KMqwxafhgMonuK;
        }
    }

    return KMqwxafhgMonuK;
}

string qSKmsfOt::iTElk(double gQRra, bool qdtxhlqDYiZEjaa, double pqufz, bool PYJMMQnAt, double VsLXVEMwW)
{
    double OGzfWqxf = -900594.1033812562;
    bool AJpBxgBm = false;
    double ULBpLDsXtd = 215536.64028644384;
    string msxlA = string("PiBYtgVcsuTRgKheJwjRNbBraNAPFgvBglZZHxpERgbSRvFLTsiLkjxMOZNJICOMaejxUhzbxXkkfmMLRtxySkKOkkzxYJaUrbVfumSGMciJIPplHhDwYd");
    bool kTNum = false;

    if (kTNum != false) {
        for (int UqGRojtKwwokTpbT = 1379756544; UqGRojtKwwokTpbT > 0; UqGRojtKwwokTpbT--) {
            qdtxhlqDYiZEjaa = kTNum;
            VsLXVEMwW = OGzfWqxf;
            VsLXVEMwW += VsLXVEMwW;
        }
    }

    if (VsLXVEMwW >= 215536.64028644384) {
        for (int erRLejfNfaIi = 1416425667; erRLejfNfaIi > 0; erRLejfNfaIi--) {
            kTNum = qdtxhlqDYiZEjaa;
            pqufz /= pqufz;
        }
    }

    for (int rdrLAhQkkrBGNovc = 2068894921; rdrLAhQkkrBGNovc > 0; rdrLAhQkkrBGNovc--) {
        PYJMMQnAt = qdtxhlqDYiZEjaa;
        VsLXVEMwW /= pqufz;
    }

    for (int sXuhuvepCxEKFuFv = 942166712; sXuhuvepCxEKFuFv > 0; sXuhuvepCxEKFuFv--) {
        VsLXVEMwW /= gQRra;
    }

    return msxlA;
}

string qSKmsfOt::MRdZfm(int irvPUoaMf, double fyVDAcYH, bool iMzPXoEE, int CuctRTHg, string gWfIMxcflVrL)
{
    double ppUMgzqJyvNRVdB = 521147.45331305097;
    double BoOhzOrp = 797250.6731984162;
    double ArrUKVvjzqzO = -990176.4153698096;
    bool GWvVGlQgUn = false;
    int pWTSPGuaBTM = 1313576814;
    int vIxUmhGSGdwmGUZ = -1021644353;
    int VgdOu = -908268856;

    for (int YCEvGwFMsGhX = 537110043; YCEvGwFMsGhX > 0; YCEvGwFMsGhX--) {
        pWTSPGuaBTM += vIxUmhGSGdwmGUZ;
    }

    for (int TqPxFhWYnOwQdkvr = 985637224; TqPxFhWYnOwQdkvr > 0; TqPxFhWYnOwQdkvr--) {
        ArrUKVvjzqzO = fyVDAcYH;
        CuctRTHg += CuctRTHg;
    }

    if (CuctRTHg < 1050828497) {
        for (int IoLkVzxjsoWCAs = 188343781; IoLkVzxjsoWCAs > 0; IoLkVzxjsoWCAs--) {
            CuctRTHg = VgdOu;
        }
    }

    return gWfIMxcflVrL;
}

double qSKmsfOt::xyROVxAk(string VfOpl, int VcjHpONI)
{
    int gLMCPMCQjckAQh = 1212136609;
    double RmwGsfKYKK = 337822.0833227997;
    bool ZbwJT = true;
    string bwoWOI = string("mcjUqkGcSHpnAHEUVIaaNtGKZTMYMFYoAnFkhMpQGsCGRUpPigSPpFElEAQewcVCBMfSWRveKlOdcmAQqAkRmFjiDEswxQHYgvYvKLNtCFGQMiObrZyLZrJfikABTxxXfOjCRgfrfWsfCdRRXznvHcUEaVchuEvdchQrxJVzDAeeMrapAYaX");
    string PEyKqqGkGltyo = string("cA");
    bool ZigKb = true;
    int EFxlZGlPzpgf = -316568618;
    int eDiLXHnPSEu = 172704826;

    if (PEyKqqGkGltyo > string("mcjUqkGcSHpnAHEUVIaaNtGKZTMYMFYoAnFkhMpQGsCGRUpPigSPpFElEAQewcVCBMfSWRveKlOdcmAQqAkRmFjiDEswxQHYgvYvKLNtCFGQMiObrZyLZrJfikABTxxXfOjCRgfrfWsfCdRRXznvHcUEaVchuEvdchQrxJVzDAeeMrapAYaX")) {
        for (int cDINRy = 1465261353; cDINRy > 0; cDINRy--) {
            eDiLXHnPSEu /= VcjHpONI;
        }
    }

    for (int LBADDRUO = 230117297; LBADDRUO > 0; LBADDRUO--) {
        PEyKqqGkGltyo += PEyKqqGkGltyo;
    }

    for (int oOFaCO = 198138620; oOFaCO > 0; oOFaCO--) {
        eDiLXHnPSEu -= gLMCPMCQjckAQh;
        ZbwJT = ZigKb;
    }

    if (eDiLXHnPSEu == 1761108940) {
        for (int vmdbxPeGcrX = 1425450750; vmdbxPeGcrX > 0; vmdbxPeGcrX--) {
            eDiLXHnPSEu = gLMCPMCQjckAQh;
        }
    }

    for (int pnfKLl = 1625360929; pnfKLl > 0; pnfKLl--) {
        gLMCPMCQjckAQh /= EFxlZGlPzpgf;
        PEyKqqGkGltyo = bwoWOI;
    }

    return RmwGsfKYKK;
}

bool qSKmsfOt::mszIBCag(int XvTiDrxyeNh, double TbWzYwbdyE, int xjDWnvPnS, bool BYedlIyI, int fNhevrdYSmGxcVbL)
{
    double WogtbpsFTJsu = -25975.469724705945;
    double BScHyPycSbq = -537143.239423982;
    string vpmny = string("EamRTLtZMlVxaXQsagYHJFdAuaTQdbusZPOuFdnlitWbVGYSEzXOuLXbFcshDCDFgnTntvYZVads");
    double TCKyHBmQwoF = -515205.91678716143;
    int sMXpVLW = -1764318038;
    int dhlfehwJa = 628841140;
    int CwVhnZJgf = 445580055;

    for (int vUOmUJtUM = 1978568623; vUOmUJtUM > 0; vUOmUJtUM--) {
        XvTiDrxyeNh /= dhlfehwJa;
    }

    if (BScHyPycSbq == -515205.91678716143) {
        for (int DLnlkJmhElV = 1093321203; DLnlkJmhElV > 0; DLnlkJmhElV--) {
            continue;
        }
    }

    if (XvTiDrxyeNh >= 445580055) {
        for (int WTDdLEMEiieLUk = 1220889725; WTDdLEMEiieLUk > 0; WTDdLEMEiieLUk--) {
            sMXpVLW /= dhlfehwJa;
            xjDWnvPnS *= sMXpVLW;
        }
    }

    return BYedlIyI;
}

string qSKmsfOt::ztpKjzw(double qYXXlJ, string zbJlTZlZLbajTCu, bool duXyrHVAC, bool orqTLc, bool eBuqpPrPACJKJEK)
{
    int ALNOQOGl = 2086450407;
    bool xlSnnJCrKGVQpy = true;
    string eliYmSutLilRT = string("ykzlLoWFaHbSTZXYqpiPFzqRjvwcVctoPkokdeNLloyiCptXlIUpqlPHKULEUHUxdDRA");
    string VNuzelHhsRa = string("GCuNoIDJHDcRvBivsDKxAmZXM");
    double BQNkBXCxNvUKYET = -882673.2704640044;
    string FZhGUKDt = string("jswhzywEVrjnRGGWdiOqmauHEBQLsZbWqhAKMjTGvSUnNNpYDN");
    bool SWXUb = false;

    for (int BtwkWnX = 1432153097; BtwkWnX > 0; BtwkWnX--) {
        VNuzelHhsRa = zbJlTZlZLbajTCu;
        eliYmSutLilRT = eliYmSutLilRT;
    }

    return FZhGUKDt;
}

string qSKmsfOt::bXeofWQ(double JtZSifELKuOeu, string YMIBdeFS, bool olMwtNCDRIPHRAIG)
{
    int bieIbuokKYp = -773858512;
    string VHWZETvCG = string("NuWyDzrotUisgpOBMdBFEdTcYQUhHCSRPYDZzVVNqbyWJbGUkNgMpHPXGUEylRCUWCQBDNGKEtsIlxoITltsRmOdmqzOthbfrDVvBreGSohmRCZJXaDctuCTyCqGjayOaNvPIsD");
    string mXllp = string("bfKKeWdosLLxHuubPyXeoavWcGjmGENsrcmcPlZmtvBpfRHHnpTuFnJEpgsHFGXjUQKaSrJLddwxpzgYWfkqRL");
    int RnpTXcOsQXvnC = -464004800;
    int AQKjCjI = 1057035366;
    bool TkbIZoeGjx = true;
    string qKwwAzPFWdCcy = string("rDiwumfEpHMsOFTiXJeaJIbwVudcGVUiAjEqdCxSmAMDfxaCvdyprwfzGOFgaDueEnBJUVkfePPXlygLdlQlCyNqZIEafNJunkhlidhOrqUGTgmIeOUDkWti");
    int TLbAiWQ = 965790987;
    string ujjchDCvXdzES = string("PazNUIuxXfKSvIKGGKUEVxzYptczjcnJUcpixeVUrXJt");

    for (int ryRgQluQSK = 598012522; ryRgQluQSK > 0; ryRgQluQSK--) {
        mXllp = qKwwAzPFWdCcy;
        olMwtNCDRIPHRAIG = ! TkbIZoeGjx;
        YMIBdeFS += ujjchDCvXdzES;
    }

    return ujjchDCvXdzES;
}

double qSKmsfOt::vwFfyyg(bool HZTgkyS, bool aLGkX)
{
    double VEZVbRCkDcpLGMfE = 771782.1718203407;
    bool rQKYkmeA = true;
    bool tauuNPADjfnO = true;

    if (aLGkX == true) {
        for (int WUcOSD = 439737582; WUcOSD > 0; WUcOSD--) {
            tauuNPADjfnO = ! aLGkX;
        }
    }

    for (int FNtvmeZGrD = 1451838920; FNtvmeZGrD > 0; FNtvmeZGrD--) {
        rQKYkmeA = rQKYkmeA;
        rQKYkmeA = HZTgkyS;
    }

    for (int CjjRyodJNYAwLzWB = 274186619; CjjRyodJNYAwLzWB > 0; CjjRyodJNYAwLzWB--) {
        rQKYkmeA = ! tauuNPADjfnO;
        aLGkX = tauuNPADjfnO;
        HZTgkyS = HZTgkyS;
        aLGkX = aLGkX;
        tauuNPADjfnO = rQKYkmeA;
    }

    for (int wZMSdQ = 354079651; wZMSdQ > 0; wZMSdQ--) {
        aLGkX = rQKYkmeA;
        rQKYkmeA = ! tauuNPADjfnO;
        aLGkX = ! rQKYkmeA;
    }

    if (aLGkX != true) {
        for (int WdgkHvRuEYcoLRm = 1565678107; WdgkHvRuEYcoLRm > 0; WdgkHvRuEYcoLRm--) {
            aLGkX = ! rQKYkmeA;
            VEZVbRCkDcpLGMfE /= VEZVbRCkDcpLGMfE;
            rQKYkmeA = ! HZTgkyS;
            tauuNPADjfnO = aLGkX;
            rQKYkmeA = ! tauuNPADjfnO;
        }
    }

    return VEZVbRCkDcpLGMfE;
}

string qSKmsfOt::bcKqTSqiXYJ(string qNrlRXJLct, bool FAnDTpaHifVmna, double SUuoHMzkVBLxrXP)
{
    bool HZNQlouIlDPMaK = false;
    int GzDeCUNHmZBd = -1264461695;
    int VBufHDsmUymXVYW = 117637592;
    int vUQfLrFiXrPRuc = 520671963;

    for (int zRgPYwkFnbw = 883582985; zRgPYwkFnbw > 0; zRgPYwkFnbw--) {
        SUuoHMzkVBLxrXP /= SUuoHMzkVBLxrXP;
        FAnDTpaHifVmna = ! HZNQlouIlDPMaK;
    }

    for (int gNmEfXagdJ = 500386664; gNmEfXagdJ > 0; gNmEfXagdJ--) {
        VBufHDsmUymXVYW += VBufHDsmUymXVYW;
        GzDeCUNHmZBd += GzDeCUNHmZBd;
        VBufHDsmUymXVYW = GzDeCUNHmZBd;
    }

    for (int RMKhAqNnNecx = 191659053; RMKhAqNnNecx > 0; RMKhAqNnNecx--) {
        VBufHDsmUymXVYW /= VBufHDsmUymXVYW;
        FAnDTpaHifVmna = FAnDTpaHifVmna;
        HZNQlouIlDPMaK = FAnDTpaHifVmna;
    }

    for (int icBTxxCvRkeodgC = 170757933; icBTxxCvRkeodgC > 0; icBTxxCvRkeodgC--) {
        continue;
    }

    for (int kUGAs = 1383362829; kUGAs > 0; kUGAs--) {
        vUQfLrFiXrPRuc -= VBufHDsmUymXVYW;
    }

    return qNrlRXJLct;
}

string qSKmsfOt::DxndJq(double MWMdkART, string cYSqzYZfngtbSfe)
{
    string xytOzJosnQm = string("lgAQuXAgZAruysJGSwDNxowZsssgeazjIbIavlqefaxmNJGluAJROEHLsplAvVECAYoFndcWJoAaPcHcyMsZAgzFichSigSGCbnsaWdpkuYflNqFqhxYxdzuyKRkmwtsmawOsgRWuQtvLNnmRWZntvPatcqOqQpkmIqlQoaDeQyGeOt");
    bool bVevxb = false;
    string MxiTUaJAAeAdh = string("CUBYpRkhjMRHRxzXKWpgmOzipRqmAfejajABJpHESKdOfRrsyLTdHrvYUElRtDgsJoxhQRUbioGfzTuZNFwvfinOtTyVTIBExVXSaZTmQGCtfHRLugqRRcPLtZiBorqJeKEVEenpamWpvDycqGABqNDyWWQGVGNCZyoPBqXnqXrvjGFMVpuDKZfYuTBvvZivbtVqiRbvvJOftrAOANAP");
    string WYePVwKOMQyDcBxP = string("dWNspCTlDmqMLPeMClFjIwEIqpBwyoNQdfUEvaOgGgxLZLQZhfNAuGuKJGdKoqklyGewyXZpCPxKcdoLxnzsmdahanNeraaJLeFrAiISJfUvyNKo");
    int WMvTDfc = 488796080;
    double SrIGWIHvX = 88297.43953312315;
    bool FdaTshttTadxC = true;
    double jxOoHQCyBQvpQm = -897962.2381631641;

    for (int dDgXEXCgdhgjYLJf = 826321809; dDgXEXCgdhgjYLJf > 0; dDgXEXCgdhgjYLJf--) {
        MxiTUaJAAeAdh = WYePVwKOMQyDcBxP;
        WYePVwKOMQyDcBxP = xytOzJosnQm;
    }

    for (int sJCDXfRfDUrlySD = 1339110240; sJCDXfRfDUrlySD > 0; sJCDXfRfDUrlySD--) {
        xytOzJosnQm = xytOzJosnQm;
        cYSqzYZfngtbSfe += xytOzJosnQm;
        jxOoHQCyBQvpQm -= jxOoHQCyBQvpQm;
    }

    return WYePVwKOMQyDcBxP;
}

bool qSKmsfOt::dEnDDgtUSgighKPq(double yYQVN)
{
    bool qolpLflPCGMYReLf = false;
    bool AnSGvFQZlx = false;
    int JnRSD = -505561516;
    string xYuKd = string("QUBNJTIaAwwbUXhyduAzHUTwGbSIGbuejWsdTwhTBznzcmuzRlQnAECGvioNJWGOjQiDiiWXdPNWpYZdKeqRzscfyVmEIwMoaawBwSDZwsJGAFBsUFPFMcjFQ");
    string vwXrrLEnwt = string("tjAUMLpCbQcvwvhpCqUHJOJchNLHgLBGvLwYsAuWgPZsotryoxhzbhLkYzRfahYrkngeksxRjsltTLzqVbkZOQmQLyYPtNMWOeQCCXSQQfjXGaYZLAnfDVWEzuNvGKyEMJxrOWRFaDeJKGLdhyKOkFViuhgzuXRsJWBLMKOJtKNpbnNJQaeQcwIxWuGmAeMyKSKSyeyvxqjGhqTwrINVMPmjkiNrSiZjgkKNQqeeWueccMitS");
    bool HYKieKmMAOtT = false;
    string wElReDHeo = string("xpboAnTfctfDiPWydzdYSvmngLoTwaexcDxqjOLIlsCBnBiQeeeujykcqHINaUeXgvLKnuchwrDucLgJGUfgxvdQEnwZkQcAUmnqAvGEANQEnlslJlkzEIPLSHScxCOPNkFDlaWhoHYYfIcefWmHKxjqFsZSNbMvMKSgTjGxjgDTyRnWaEkHtIGhIucwLEJccskdYjMDBQdhdxXgWYBXBgV");

    for (int NnzvwMTAJ = 301276943; NnzvwMTAJ > 0; NnzvwMTAJ--) {
        xYuKd += xYuKd;
        AnSGvFQZlx = ! qolpLflPCGMYReLf;
    }

    if (AnSGvFQZlx == false) {
        for (int OOZRsbPHq = 1656115814; OOZRsbPHq > 0; OOZRsbPHq--) {
            wElReDHeo += wElReDHeo;
        }
    }

    for (int yWOsYxqb = 314841172; yWOsYxqb > 0; yWOsYxqb--) {
        vwXrrLEnwt += vwXrrLEnwt;
    }

    for (int jGdUBFfScpo = 310019183; jGdUBFfScpo > 0; jGdUBFfScpo--) {
        qolpLflPCGMYReLf = ! HYKieKmMAOtT;
        wElReDHeo = xYuKd;
        AnSGvFQZlx = qolpLflPCGMYReLf;
    }

    for (int KqrHwHfAkaY = 1580634087; KqrHwHfAkaY > 0; KqrHwHfAkaY--) {
        xYuKd += xYuKd;
    }

    return HYKieKmMAOtT;
}

bool qSKmsfOt::wLXFWKNPyLgkVxwp(bool PJMZlsrOSAQYji)
{
    string iCWZUyxnavmn = string("hVHMjMMsviKxUzIEVGNvfuRgKFteCGhTFlWuCUxVUiRYgebTcIiOtJyautHdlHWwXAlzioYtuTQVfcEzBWynFrvIsuqzjY");
    double AlVDzspSvIY = -931522.4753994908;
    double mtjnTHc = 325944.8383493859;
    double sEeKSIn = -873184.3229781386;
    int oYLeQTlpEQRd = -1432189757;

    for (int AHeUxwIVCTl = 2114565233; AHeUxwIVCTl > 0; AHeUxwIVCTl--) {
        sEeKSIn = AlVDzspSvIY;
        sEeKSIn = mtjnTHc;
        PJMZlsrOSAQYji = ! PJMZlsrOSAQYji;
    }

    if (sEeKSIn <= -873184.3229781386) {
        for (int XCbuDymKSf = 1046270690; XCbuDymKSf > 0; XCbuDymKSf--) {
            PJMZlsrOSAQYji = PJMZlsrOSAQYji;
        }
    }

    for (int YDWfmWXSGvAiyqx = 1433355091; YDWfmWXSGvAiyqx > 0; YDWfmWXSGvAiyqx--) {
        iCWZUyxnavmn = iCWZUyxnavmn;
        mtjnTHc -= AlVDzspSvIY;
        AlVDzspSvIY *= AlVDzspSvIY;
        AlVDzspSvIY = AlVDzspSvIY;
        sEeKSIn += sEeKSIn;
        AlVDzspSvIY += AlVDzspSvIY;
    }

    for (int StUefvUmdrsSZcGC = 1855389053; StUefvUmdrsSZcGC > 0; StUefvUmdrsSZcGC--) {
        sEeKSIn += AlVDzspSvIY;
    }

    return PJMZlsrOSAQYji;
}

string qSKmsfOt::bADKghaCRWST(string uhqDUxNkemzeoW, string ZQTqHkJUGzzVxM)
{
    string hFJEMONqbIgv = string("kExnertlpdEQxEMxvafsVYkWniaJPHosJNgMdTpvAeabZpTlcYFjzeEqYEuLyQwAaDUzLRWTqDQMnvnXzejvJXttmETUVcCwuoxNEttREPiONgSYhLIxhnQZLsUlojpLekipLZRikvAMZkukdxSmhDLCohcxsmmyxUcvYYdraPNuPKgdkexJ");
    double zqgKZnlq = -648227.5434785181;
    int LatLqhR = 763152752;
    double ZLnwB = 819494.9026860641;
    int zkezy = -204437541;
    double oGOiK = -790344.9773873467;

    for (int jAIxzlfdspYjVEG = 993868892; jAIxzlfdspYjVEG > 0; jAIxzlfdspYjVEG--) {
        LatLqhR -= LatLqhR;
        zqgKZnlq -= ZLnwB;
        oGOiK += zqgKZnlq;
    }

    return hFJEMONqbIgv;
}

string qSKmsfOt::nDUSzDa(bool yfRNqpmWh)
{
    bool HpsKcGBsJGI = false;
    double CQdoSe = -158155.51628201874;
    string SIBpoRKReFCLgorS = string("tjMZcznZgQFhhLKDHguiIfambtFVrEQsNpREfkCNaBliYftozSaAAsGOgnFEGSWQLYcNYtTJAeQMpcxMzFGUBKPCivxlLysXPVmeZmfNwauhrglbGVBgmjzV");
    string RuQoWUxOZM = string("gKolOIfZHZaUDGyTNlnuBBAwrJDitcUqdOoenhewTeuESDKEZUvKlSmfRWFHOtgOxYgJQgMEbJClwvYmzIWbyCdDujZgxjsNiKIpXifojeLWrZvgByxKZcKqqDXHOdzgTcyYEVPtsFyMjTzmVAzaAhpbjetTYHAQWxeFtPHglsbgmECm");
    string DRUmKqqo = string("XSoZVLukMeURnbJdDVwBGXuJcOCWbMwTfAGKwkktmGRxpWqORdZXlYztGYxeNvCTfvkAsWQnrKpUOzoIfVfkTyEPyKWFkAXWVROUSgHAAAOHQFSIAaxeUTBOodIiHogsntuErKikgDDKpGzdeYJbcoIlpRzlNeHZrtUbQnAaiyyjpbLqGbujnJxxUbpWLeDUFOCoXHaTcLQQpxmZBSxIQxJYghLOslVLuNFIjftbziFfGqqzsiWNwLdhPF");
    bool tuALtNumaJQ = true;

    for (int lvdmxlTfeuNzLPwz = 590280866; lvdmxlTfeuNzLPwz > 0; lvdmxlTfeuNzLPwz--) {
        SIBpoRKReFCLgorS = DRUmKqqo;
        SIBpoRKReFCLgorS = DRUmKqqo;
        tuALtNumaJQ = HpsKcGBsJGI;
        SIBpoRKReFCLgorS = DRUmKqqo;
        tuALtNumaJQ = HpsKcGBsJGI;
    }

    return DRUmKqqo;
}

double qSKmsfOt::cjfsxUmPfQ(double ddyjoCRIs, int BPeGQM, int NQRacnYZCsZnCeR, double kWXzg, bool WAwRwlpdaNYW)
{
    int ttYqmUnpFYWfkdgh = -2118649191;
    bool hnweYslRoaxojWc = false;
    double sMVJMcX = -44458.96918744926;
    bool JRNucxklLxNSqS = false;
    double mVgCRBhxSloiYSh = -737916.6314981034;
    int BpolckY = -1714004442;
    int MArdQXzqltQTDtFR = 889649961;
    int PfIlInIErmmO = 2009920946;
    string XPPmzZRRdnUurMTY = string("dAOriSthtSdyCPoSOwyikUDiojXrDbnQUlbunnEEhsxzHfSSmJK");
    bool JclGciCUf = true;

    for (int OWXzuzX = 1007606147; OWXzuzX > 0; OWXzuzX--) {
        continue;
    }

    for (int jOFgjiKnitH = 94069663; jOFgjiKnitH > 0; jOFgjiKnitH--) {
        ttYqmUnpFYWfkdgh *= BpolckY;
    }

    for (int yzZPwFkHlzQtzYu = 1060561966; yzZPwFkHlzQtzYu > 0; yzZPwFkHlzQtzYu--) {
        sMVJMcX += mVgCRBhxSloiYSh;
    }

    if (MArdQXzqltQTDtFR <= 1907349995) {
        for (int GzShNhSEdqHk = 1712734116; GzShNhSEdqHk > 0; GzShNhSEdqHk--) {
            BPeGQM /= PfIlInIErmmO;
            JclGciCUf = hnweYslRoaxojWc;
            ttYqmUnpFYWfkdgh += PfIlInIErmmO;
        }
    }

    for (int fIgCbHSnTGLqEaip = 1076249015; fIgCbHSnTGLqEaip > 0; fIgCbHSnTGLqEaip--) {
        NQRacnYZCsZnCeR *= BpolckY;
        MArdQXzqltQTDtFR -= MArdQXzqltQTDtFR;
    }

    return mVgCRBhxSloiYSh;
}

int qSKmsfOt::UxVxDA(bool YazAVxn, bool fzLFyNZALkI)
{
    string nbFazuLrOojiiWmL = string("UnWTVMqPovhXfpMFhIQMqmWGypFseoCBEkWRSqwQBSnMGXRkmSqLfBeFurMYjRxAdrQGeYORGKCQzxIGoTeETnoUIYcbLoNBeuxNWwqanUOCeILxUbYyCSolDrlyjRPZDuqIrdGTIrpNrHkVLSPYMgkePfzvovGZBiHsOnVrLBjDDvkVTpCaKdyiOaWRbpwkKMAtYSvAbKUzzAZFnfuWmsPeQgGXVdIsHtrn");
    double rsvqn = -671569.306108565;
    string pVHwdfcHPd = string("JfJcKRNWZAxtKJXknYmMWFXtIFIdHPupTQjlGgOOVY");
    int MSWAftAjS = -1341325652;
    int bdpdWbclzuOZpbnE = 613330854;
    int CuZGSeP = 561873965;

    for (int cAWFApqZ = 1245508445; cAWFApqZ > 0; cAWFApqZ--) {
        CuZGSeP *= bdpdWbclzuOZpbnE;
        fzLFyNZALkI = ! fzLFyNZALkI;
    }

    for (int EqUExiQWNXmpHVe = 1265095939; EqUExiQWNXmpHVe > 0; EqUExiQWNXmpHVe--) {
        bdpdWbclzuOZpbnE *= CuZGSeP;
        MSWAftAjS *= CuZGSeP;
    }

    for (int ffFxQwjKe = 1346060314; ffFxQwjKe > 0; ffFxQwjKe--) {
        continue;
    }

    for (int SSeQFYxaN = 2113640186; SSeQFYxaN > 0; SSeQFYxaN--) {
        MSWAftAjS *= CuZGSeP;
    }

    if (nbFazuLrOojiiWmL < string("JfJcKRNWZAxtKJXknYmMWFXtIFIdHPupTQjlGgOOVY")) {
        for (int DoqlqLsHR = 61585762; DoqlqLsHR > 0; DoqlqLsHR--) {
            YazAVxn = YazAVxn;
        }
    }

    if (CuZGSeP > 561873965) {
        for (int JjMfiZyEGoqVT = 1825293510; JjMfiZyEGoqVT > 0; JjMfiZyEGoqVT--) {
            pVHwdfcHPd = pVHwdfcHPd;
            bdpdWbclzuOZpbnE = bdpdWbclzuOZpbnE;
        }
    }

    return CuZGSeP;
}

double qSKmsfOt::wFFlpayqqw()
{
    string agDENfaNxAG = string("QWaZSCEDskXtlbwGsxfFqWldZVVAxAORbnVGBBuBjVtLwbWdKGoSzBXusCWJaQIABijnRVzoUdznkHtLYyCtnWAYUoywWbRTowikgeDjARegFuoGNSTamRWRRUBMzSQrCrNfBezmAphqYGbpjEKDQBRpXIQZM");
    string YMjywynk = string("XPXnkqnitaMDPeiaQPUTHBqJcKoLpfiZdqGujkOdxooOcdtVHJWeBh");
    double SAaKkEKjwmt = -717264.5951890787;

    for (int ddfdADBByLqkD = 294922360; ddfdADBByLqkD > 0; ddfdADBByLqkD--) {
        agDENfaNxAG = agDENfaNxAG;
        agDENfaNxAG = agDENfaNxAG;
        agDENfaNxAG += agDENfaNxAG;
        YMjywynk = YMjywynk;
    }

    return SAaKkEKjwmt;
}

qSKmsfOt::qSKmsfOt()
{
    this->zdStTlyTub(476117.9557571566, -538439.9425987524, 1040683825, 920910.9854177226, -460276871);
    this->sKtTBgdxivBN(347849.55731040606, 656633219, -318984.8764302859);
    this->MhAMyed(1984959133, 1951117308, 109117.11542751468);
    this->NjEHRyjYD();
    this->iTElk(-116029.41713659161, false, -119204.43598992792, true, -226189.44758412213);
    this->MRdZfm(1050828497, -36629.17044832707, true, -1268796999, string("UpaxszPpocPmYVVsDcUvuDhHvgyaDvJpgaYNTaiuw"));
    this->xyROVxAk(string("lzkFlROpCrcNBrxtPrAAPRqHIUQlmakxXCRCEjhTzrRAKWyeVvlYTGBXYqitMaMbANPHQXDAWbOsUwibnmqpLvvWiEVBPotOGebrWxztHtUciAoeyIJrFmkNVRNTquzTvoyfmidZBIgmFkWlqGfTDXdqXJnmeThldwlhYGUPZPUHlVysQUXxbOrffSDmcoCqATQwOQFFThrsKeEFGoED"), 1761108940);
    this->mszIBCag(898923292, 294968.53292681155, -404766011, true, 1910615649);
    this->ztpKjzw(-933697.5953934311, string("DGjmfYQMHgdXYCFMMKRvhpdJzSTRQMFuowUicmBXCVOSLIRpSnOTcqILWbDszKLtBJRgdKFFKDGURZLfrZCgHyJxXPVsdDViDQVRoFlzvUmvGZZhGeUFEHgQNushTAOLeiTPGbHzBBUwErjziyepdLyRfbbCoUuSGXxukssmGFRTWUqcUOZUcpbyFYRgeFiObEKwljvpScQICpNaOhwDmYcpzAiMTjpC"), true, false, false);
    this->bXeofWQ(-536480.8382471194, string("yeVKSluYSblyJiYpgxKEopCsvagNVsFxHzYIYAlWFmZue"), true);
    this->vwFfyyg(true, false);
    this->bcKqTSqiXYJ(string("LafdAbxitqmQsIVjybxJfXbKgJkxyFMTRqIIslQBOySHDlghkSkXSYWDRoEQlUOyIRRlfJHboXjRUoDhBbZADf"), true, 578869.100582487);
    this->DxndJq(157487.55787970294, string("QAhPcjPIsWxhldDwaByomhqbjhgBSVIlgklzVKjVuWEeUCGytplhjVzdQuGSjuuypxnBvKqfpwpmbzkqZExaXHyZrfWkOAbdsNOZHTMervTAPPObRyuCdIOqTIiwfmPtEiHRGWoCuiVnuhWVrAPkUpbCajNbDapcV"));
    this->dEnDDgtUSgighKPq(-1004280.105527824);
    this->wLXFWKNPyLgkVxwp(false);
    this->bADKghaCRWST(string("QKwMTzypNEhpJovzDkwppRIRNeNSovJoZnsOlOuEPDKWpiNScLQhkNkmpvQJGVBtAMxdhGmyspuLvYmTPGlGVBhvYoGpddxnCmjCoBDBXSQEUTrFqIQUBEuZObPgsGkFlCAoHqgRrhppUEaFzrHZmSfFHgGwhuYcXvDBecsLrREhmnClRf"), string("lJxKQEHgooSDjvqXvsqhe"));
    this->nDUSzDa(true);
    this->cjfsxUmPfQ(-402055.94875589915, -1067731871, 1907349995, -522704.8344527493, false);
    this->UxVxDA(false, true);
    this->wFFlpayqqw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JBshp
{
public:
    string QVlMEd;
    double cEtKhGQbyLa;
    string dCcKWuaCl;
    int ZKXDEAMZv;
    int dKcYQ;

    JBshp();
    int CRdkXGkkpTBWzwd(bool nXMMaBnLayxCnzuc);
    void lsAHdPuCsoj(int dtvQuvkM);
    string wQyzHuOxeaQQ(string JlyiNOy, string GZNxkvEtRqAH);
protected:
    double wVkOwCZyKQKDyLs;

private:
    bool gHSzXkDjRksWSdf;
    double fWHupC;
    double LfVFqjcXqlrODTQ;
    int SWBWNNWf;
    bool OqVbyHmA;

    double tdLJoLIhVZWdWwtL(string yAiEpitnQH, bool lAYGPmwAz, int qQmHQdWYzJrB, double GYKcbEcj, double rTbWLBjVxZZbc);
    bool rGNXemZooZO(int fQmnI, bool akMMKcAekH);
    bool ySvVtusTIhwK(string arjdxdU, bool RirYBzG);
    int vhvcNb(double reiOMLqScaweE, string MwzUvQaJ, int wKSyyi, double UQAYTBDi, int WNFfguZA);
    int WEtFCrzSRpb();
    int syKBOezSZrAiZnK(int XpiYtRVTgu, bool YUKCaYytaaqH, int dZZZjoMtbSv, double gSNxlHHkIpySMvA);
    int VxQodFxsoOM();
};

int JBshp::CRdkXGkkpTBWzwd(bool nXMMaBnLayxCnzuc)
{
    bool upMtVJ = false;
    double TvnAqhYGsJqP = 55364.02938282391;
    string OrrrAF = string("Tkxxsqebah");
    double bhxYTQu = 467814.1818751493;
    bool SVCTiVofvJw = true;
    int dkNZQYn = 1468014171;
    string kjyvyFWesd = string("fVHFLsOSgpsXnMHuijacdHQEzOFTPuMZoJtKHXSGpikZPKhYrAqAkwENVGBoyFW");
    bool LQIWPeLfCien = false;

    for (int YOzcYKfhCi = 275509258; YOzcYKfhCi > 0; YOzcYKfhCi--) {
        TvnAqhYGsJqP *= bhxYTQu;
        nXMMaBnLayxCnzuc = nXMMaBnLayxCnzuc;
        nXMMaBnLayxCnzuc = nXMMaBnLayxCnzuc;
    }

    for (int mONZBdEQJYwe = 900642819; mONZBdEQJYwe > 0; mONZBdEQJYwe--) {
        LQIWPeLfCien = SVCTiVofvJw;
        TvnAqhYGsJqP += TvnAqhYGsJqP;
    }

    for (int zeBAccSqxvVkLi = 192062514; zeBAccSqxvVkLi > 0; zeBAccSqxvVkLi--) {
        kjyvyFWesd += kjyvyFWesd;
        SVCTiVofvJw = upMtVJ;
        bhxYTQu *= TvnAqhYGsJqP;
        upMtVJ = upMtVJ;
    }

    for (int zeQjVZOmkdjh = 967386206; zeQjVZOmkdjh > 0; zeQjVZOmkdjh--) {
        upMtVJ = ! SVCTiVofvJw;
        LQIWPeLfCien = ! LQIWPeLfCien;
    }

    return dkNZQYn;
}

void JBshp::lsAHdPuCsoj(int dtvQuvkM)
{
    double OQUwB = 454277.77272527025;
    double rpeNFXdDVSfqiuV = -723561.5576908801;
    string oaQcLpve = string("LHxvHbaJqHiCzqKKTUNUfBkBCCvOWcmnsqJFeXklnueNxmccnSYAVWNvhPhXAxQJQkoygEidLDXNCYcfpfdfLZZAYQgejCYIFkrvWSgxLCNdtasWWNokJdfLaSnrQiXdPP");
    string NUTmXPDWwalxUPfZ = string("wDzMHKNtzygCDIDIrNejkSWbFhrPEODqyVfmXBTLRmvHxoNQhJsnk");
    double zjuqiBRKHPvLrc = -215130.85788441187;
    bool trYEdMyEwcSUDEEN = true;
    bool wxijnR = true;
    bool oJPVC = false;

    for (int yOTHmsnhVEdWAvC = 1853704122; yOTHmsnhVEdWAvC > 0; yOTHmsnhVEdWAvC--) {
        zjuqiBRKHPvLrc *= rpeNFXdDVSfqiuV;
    }

    for (int FFPvdwcWDoKmYiDg = 15174408; FFPvdwcWDoKmYiDg > 0; FFPvdwcWDoKmYiDg--) {
        rpeNFXdDVSfqiuV /= OQUwB;
        wxijnR = oJPVC;
        NUTmXPDWwalxUPfZ = oaQcLpve;
    }

    for (int lRPaGCed = 2039613706; lRPaGCed > 0; lRPaGCed--) {
        oaQcLpve = oaQcLpve;
        wxijnR = ! trYEdMyEwcSUDEEN;
        OQUwB -= zjuqiBRKHPvLrc;
    }

    for (int CAzoxzx = 596209107; CAzoxzx > 0; CAzoxzx--) {
        zjuqiBRKHPvLrc = OQUwB;
        oJPVC = trYEdMyEwcSUDEEN;
        trYEdMyEwcSUDEEN = ! wxijnR;
        trYEdMyEwcSUDEEN = oJPVC;
    }
}

string JBshp::wQyzHuOxeaQQ(string JlyiNOy, string GZNxkvEtRqAH)
{
    string DxYDNPQf = string("MwosqUopXcyZVcqRKdfNdriNuDhvLcrObKWtnqFjhQCvrbeGZjneIBUawoyZDjeeTNHHhokzPdteglpBN");
    int FIvVgZiGnjUrZ = 1692102593;
    double oIQRrMdu = 472140.22670785815;
    int ReqUyHADxlepQxOV = 1038780850;

    for (int bHeGNICbyLf = 844517568; bHeGNICbyLf > 0; bHeGNICbyLf--) {
        JlyiNOy += DxYDNPQf;
        ReqUyHADxlepQxOV += ReqUyHADxlepQxOV;
        oIQRrMdu -= oIQRrMdu;
        ReqUyHADxlepQxOV = ReqUyHADxlepQxOV;
    }

    for (int COTWTYgWzrXNuzL = 1642545354; COTWTYgWzrXNuzL > 0; COTWTYgWzrXNuzL--) {
        ReqUyHADxlepQxOV += ReqUyHADxlepQxOV;
    }

    for (int uKwqnpC = 1894916318; uKwqnpC > 0; uKwqnpC--) {
        continue;
    }

    return DxYDNPQf;
}

double JBshp::tdLJoLIhVZWdWwtL(string yAiEpitnQH, bool lAYGPmwAz, int qQmHQdWYzJrB, double GYKcbEcj, double rTbWLBjVxZZbc)
{
    bool EUZwwrkK = false;
    bool AVPwUWMOWYyJSf = false;
    int xOGBCMOJYxTD = 1580781381;
    double MbWXZeOFXxVEYsH = 226463.0340690803;

    if (GYKcbEcj <= 226463.0340690803) {
        for (int bdJGvbqtT = 981999298; bdJGvbqtT > 0; bdJGvbqtT--) {
            rTbWLBjVxZZbc += GYKcbEcj;
            GYKcbEcj *= rTbWLBjVxZZbc;
        }
    }

    if (rTbWLBjVxZZbc <= 226463.0340690803) {
        for (int JIMFk = 1906125717; JIMFk > 0; JIMFk--) {
            lAYGPmwAz = EUZwwrkK;
            EUZwwrkK = lAYGPmwAz;
        }
    }

    return MbWXZeOFXxVEYsH;
}

bool JBshp::rGNXemZooZO(int fQmnI, bool akMMKcAekH)
{
    int OjzmkbROWCYXRO = 1304334267;
    double EIaiaPbcTLs = -187339.41562736046;
    int XzkVGjVH = 1223921697;

    if (OjzmkbROWCYXRO > -116816328) {
        for (int yvqguVLJYxOrJ = 2113215941; yvqguVLJYxOrJ > 0; yvqguVLJYxOrJ--) {
            fQmnI = XzkVGjVH;
            OjzmkbROWCYXRO += fQmnI;
            fQmnI -= fQmnI;
            fQmnI /= XzkVGjVH;
            OjzmkbROWCYXRO = XzkVGjVH;
        }
    }

    if (XzkVGjVH < -116816328) {
        for (int obBYZOxh = 545837599; obBYZOxh > 0; obBYZOxh--) {
            continue;
        }
    }

    for (int IXdQItz = 2062433884; IXdQItz > 0; IXdQItz--) {
        akMMKcAekH = akMMKcAekH;
    }

    if (EIaiaPbcTLs < -187339.41562736046) {
        for (int cgFmH = 191249142; cgFmH > 0; cgFmH--) {
            akMMKcAekH = akMMKcAekH;
            XzkVGjVH -= XzkVGjVH;
        }
    }

    for (int trfSJfNWWOYVPHIM = 94337321; trfSJfNWWOYVPHIM > 0; trfSJfNWWOYVPHIM--) {
        OjzmkbROWCYXRO -= fQmnI;
        XzkVGjVH /= OjzmkbROWCYXRO;
        EIaiaPbcTLs += EIaiaPbcTLs;
    }

    if (OjzmkbROWCYXRO >= 1304334267) {
        for (int fmQWHPVjZ = 1653648101; fmQWHPVjZ > 0; fmQWHPVjZ--) {
            XzkVGjVH -= XzkVGjVH;
            XzkVGjVH += XzkVGjVH;
            XzkVGjVH *= XzkVGjVH;
            OjzmkbROWCYXRO /= XzkVGjVH;
        }
    }

    if (OjzmkbROWCYXRO != 1223921697) {
        for (int KspSPl = 1864354736; KspSPl > 0; KspSPl--) {
            XzkVGjVH = fQmnI;
            EIaiaPbcTLs -= EIaiaPbcTLs;
            fQmnI *= OjzmkbROWCYXRO;
        }
    }

    return akMMKcAekH;
}

bool JBshp::ySvVtusTIhwK(string arjdxdU, bool RirYBzG)
{
    int KEZNFkTdzUH = 97621311;
    int EEsKusCd = -34898725;
    bool yNngtGp = false;

    if (EEsKusCd < 97621311) {
        for (int saImkGXSlXfsQaJP = 765060315; saImkGXSlXfsQaJP > 0; saImkGXSlXfsQaJP--) {
            RirYBzG = yNngtGp;
        }
    }

    for (int tCIWNCsdJ = 1834435168; tCIWNCsdJ > 0; tCIWNCsdJ--) {
        KEZNFkTdzUH -= EEsKusCd;
    }

    for (int OPLiLYxMk = 1894423990; OPLiLYxMk > 0; OPLiLYxMk--) {
        EEsKusCd -= EEsKusCd;
    }

    for (int jqWIAy = 1295030274; jqWIAy > 0; jqWIAy--) {
        RirYBzG = RirYBzG;
        yNngtGp = ! RirYBzG;
    }

    for (int XwkAYHTRv = 1694536991; XwkAYHTRv > 0; XwkAYHTRv--) {
        yNngtGp = RirYBzG;
        KEZNFkTdzUH += EEsKusCd;
        EEsKusCd += EEsKusCd;
    }

    if (RirYBzG == false) {
        for (int vwrqHnOhkgaog = 219021779; vwrqHnOhkgaog > 0; vwrqHnOhkgaog--) {
            EEsKusCd = EEsKusCd;
            EEsKusCd -= EEsKusCd;
        }
    }

    for (int cmOHcvpdmtwuIh = 811397140; cmOHcvpdmtwuIh > 0; cmOHcvpdmtwuIh--) {
        RirYBzG = ! RirYBzG;
        yNngtGp = ! RirYBzG;
        RirYBzG = ! yNngtGp;
    }

    return yNngtGp;
}

int JBshp::vhvcNb(double reiOMLqScaweE, string MwzUvQaJ, int wKSyyi, double UQAYTBDi, int WNFfguZA)
{
    int wPASrUNRWB = 1519425034;
    string WPgzzQMe = string("VUoWoUXtVKUoWkHPoypGATkqTDUGdgMlrrqovXIrfGMliALtTPmbqOmkoLiMPXVuHDwdTaGvRzVNuEpEMNWfRTrdAsEtMknBLVFkpeBFGMqOsLpYViFzKGmIcKlGzHeGVYafFWiBCnLlIzDXowdHRkDfITwooJdUbRRZqvzteXTlpruVZYgNyKCVxxNfCRWYszGWGRFNpjduCghzzgynkfx");
    string YuMlvu = string("teXaVUIFoeKGZElpgHMRNbibOFdTukFachcAvXHmtfgHKUt");
    bool rkhLCzKDjqF = true;
    bool JQvPmoKTklQkHge = false;
    int rmkcDfDFJ = 736514228;

    for (int saDwkKA = 1390227364; saDwkKA > 0; saDwkKA--) {
        wKSyyi += wPASrUNRWB;
    }

    for (int dejMnNNvq = 561847403; dejMnNNvq > 0; dejMnNNvq--) {
        continue;
    }

    for (int HMayKJV = 1332284071; HMayKJV > 0; HMayKJV--) {
        wKSyyi /= wKSyyi;
    }

    for (int smsXByvGaqkL = 1496378106; smsXByvGaqkL > 0; smsXByvGaqkL--) {
        rmkcDfDFJ /= wPASrUNRWB;
        wPASrUNRWB = wPASrUNRWB;
    }

    return rmkcDfDFJ;
}

int JBshp::WEtFCrzSRpb()
{
    double IooEH = -515224.8712738912;
    double FnmmxZoBmF = -868861.1374813832;
    int CvlJFgRi = -2001147017;
    int SPxiFNOLp = -1826443546;
    int YndhBJFS = 485961649;
    string VmOCByj = string("isjcyXcEHOpnLgawqVoemSDhOEueWGlLQNblaIkgMEKxcqxtWsNPcjCLrSwhYqMLJUNsVUxzbWJmwvMmJdFwExrrArwDUrVlchlWpQtYKTcMInbPuEKqWfhFuqKZXJkiMnBLzCMBepOZuoMHylbU");
    string YnuMqztATKNYE = string("tkJkFSzaDPARwbBYUYFepMqhZXgcTHcmOSTgSmIObWwNLlYinJCjxogIdVVNBjBlavXJsEsoyAGbNkbMMngHEqSYMiHcOvuqzefqPnaPBGXvMGfOeoTjHoelvxwpNzbrnlnFLogIhFRGbrkvynmkpCTmFyWMhMVNgZSkIPOAatuLlMUzDIOF");

    for (int YEztjbAr = 1060265073; YEztjbAr > 0; YEztjbAr--) {
        YnuMqztATKNYE = YnuMqztATKNYE;
        YnuMqztATKNYE = YnuMqztATKNYE;
        YnuMqztATKNYE += VmOCByj;
        VmOCByj += YnuMqztATKNYE;
    }

    return YndhBJFS;
}

int JBshp::syKBOezSZrAiZnK(int XpiYtRVTgu, bool YUKCaYytaaqH, int dZZZjoMtbSv, double gSNxlHHkIpySMvA)
{
    bool bisCfLJrao = false;
    string yDIGUepIuO = string("kacDUwTmKobKeEugVVBPOsLZrwxYDUCXlqrqxtseEgfguWwsivstNofJo");
    int VAMZphxDqcwkW = 862740846;
    bool uvJlYcgztX = true;
    int BxYgxFYaXnBg = -1977501114;

    for (int RWFmUYzobOrYZG = 1258005031; RWFmUYzobOrYZG > 0; RWFmUYzobOrYZG--) {
        XpiYtRVTgu /= BxYgxFYaXnBg;
    }

    return BxYgxFYaXnBg;
}

int JBshp::VxQodFxsoOM()
{
    int sxAbNuYMAlmkI = 404994468;
    double tkohwvOQlUvodBDQ = 143225.29704452472;
    int mLpwYNaO = 885589835;

    return mLpwYNaO;
}

JBshp::JBshp()
{
    this->CRdkXGkkpTBWzwd(false);
    this->lsAHdPuCsoj(589984169);
    this->wQyzHuOxeaQQ(string("CEOkONCgFdwltylGJJPkEsgYtpDkCQiHThkfLyoFELUhITEGYKJPhjLchmktiKxzAKOWMLvxvZhPzcAvtErhnXFixjEPbTAYpSpzwcVbmTkoRkxgOlQTEVfYXkVUtQqwVLxzDtqVTYKsITjSOrViitMRFPvAlHvzJWyoFDjXEFKCcWQ"), string("biFLlTwmQCAvjEMvBBtzjSXAXFXZGubtLUjR"));
    this->tdLJoLIhVZWdWwtL(string("tmUoiRCRoBkIIZkvnpdfRneRXyLMUKiwYgiygxnjzUfDgqYonmSXaSdheaHCQYTeInRGfWVkGlXGzhwWXilWGKwNLQBPXpmZGIlyfPHEGzlMfJfSSQGEWhxPFsdXuFPaFiJGpltJoblDUKmrZCDzWHCasOIsnjtRXlIbaEYEzDkSGmhtleZtOaIf"), true, 594336827, 585362.538755298, 358283.7273461278);
    this->rGNXemZooZO(-116816328, true);
    this->ySvVtusTIhwK(string("oYwsUvEnMeqXahrHNdLLHkdiHelWPGpZPjkfGEfAbkrxJ"), false);
    this->vhvcNb(-669455.1429733441, string("QcGuubEXmQJhQpHJVbZzLabLSGduTtHCbhjywceTReuCqVbLWomFvHkXdQIqrWPtCbRzcuoapWaPZREYTbHNLmlobktTRQZXYNWpwFqXgsNmLKwsoVKksAqVVRElBeBodHVRKordIavFNrIuQkbGjiyCvtCldWdSbXuzjpYrWwxJVGpZlgopEmJhTQwPlbKoqRZFFrJOxdlDMqGbsUQENrinIxGMowH"), 1317446192, -736256.1897368446, 85358175);
    this->WEtFCrzSRpb();
    this->syKBOezSZrAiZnK(2039305056, false, -1120732097, -819930.8210269371);
    this->VxQodFxsoOM();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ASTTZCkZlYp
{
public:
    int qZcAPFV;

    ASTTZCkZlYp();
protected:
    bool sdanL;
    double VkyrOPz;
    double KWUWDJT;
    bool agkGcqRuDLUV;

    string NJjjSRFdKAVLtbW(int YHQVoHcPnYhIpMLe);
    double GEOgBywkn(bool XfCQj, double WFRZz, int fUltvgLJPJbc, string TSfCJuZHjAswvI, int gjhtelJvlZ);
    int LjIFsrSHhi(int BTGfgsmPPlWL, double PWQhhFOSXIO, double KaIkeGSg, bool lkyTUgWosxTc);
    double dEuCfWaL(double RpaxVckAdhw, int ooIsbSAFttJu, double tYXpY);
    void IoNMOOIrWnvY();
    double QeUGAVQyS(string KcwHitZcYr, string VnqeCZxMVwpGv);
private:
    bool DhCtGNZBqAfGfZv;
    double ubYPBFJKxf;
    double kdhkmuVmDKD;
    double NVXuMfFYNcQVd;
    bool yVXUqfbq;
    string xEVAdYTUhTIyabev;

    bool nsFdrQaHM(string mrMprSBx, bool PfRhXqQlQwhSBIXl, bool ExBlXepLVsCe);
    string ZcFYOPwrpJZRm(double moUeNcsQ);
    void CBFuktJrPhjwiG(int haSOc, bool NOfRiYZtVTYcuzB);
};

string ASTTZCkZlYp::NJjjSRFdKAVLtbW(int YHQVoHcPnYhIpMLe)
{
    double vEohddbxQKxi = 603399.8269143805;
    double qSRMVKtMaCEEd = 298498.654422832;
    string knVfLKiBLc = string("bPXnGPSLWvcGysHsPyoGBGuPpkBsrnzemiWzMViBFqJxqrvUceaN");
    double ZWNhCFnIJ = 463490.62883234216;
    int ikRFoIaQbY = -526077901;

    for (int pngBvYF = 105397618; pngBvYF > 0; pngBvYF--) {
        continue;
    }

    for (int wTGoAZDejV = 1675362257; wTGoAZDejV > 0; wTGoAZDejV--) {
        continue;
    }

    if (ZWNhCFnIJ == 463490.62883234216) {
        for (int HUijirIz = 1552316528; HUijirIz > 0; HUijirIz--) {
            YHQVoHcPnYhIpMLe *= YHQVoHcPnYhIpMLe;
        }
    }

    for (int WAJJPwhRSpxMlSFe = 1202536371; WAJJPwhRSpxMlSFe > 0; WAJJPwhRSpxMlSFe--) {
        ZWNhCFnIJ = vEohddbxQKxi;
        qSRMVKtMaCEEd += ZWNhCFnIJ;
        YHQVoHcPnYhIpMLe = ikRFoIaQbY;
        ZWNhCFnIJ -= vEohddbxQKxi;
    }

    return knVfLKiBLc;
}

double ASTTZCkZlYp::GEOgBywkn(bool XfCQj, double WFRZz, int fUltvgLJPJbc, string TSfCJuZHjAswvI, int gjhtelJvlZ)
{
    string KvskreTVEvBnYu = string("HAdYTeVhSMReUGYeGhRsFsXQflOrFbdkdQeUapSAcbgDIlguiQnpCCSXvqvvqoSOqQqGqDKRSxGKihXHHnnAYMCIYotBRuYVYYlDCUnMpzuyYiIAaNFeuJjfzEoAtUEEQzRvfLMKXDTxsD");
    int gQLLbVpDiLww = 929946929;

    for (int LRBYPQLcKTx = 1565916719; LRBYPQLcKTx > 0; LRBYPQLcKTx--) {
        gQLLbVpDiLww /= fUltvgLJPJbc;
    }

    return WFRZz;
}

int ASTTZCkZlYp::LjIFsrSHhi(int BTGfgsmPPlWL, double PWQhhFOSXIO, double KaIkeGSg, bool lkyTUgWosxTc)
{
    string cEyzXwtJRek = string("nGjibTsOZYAPUElUnYrLXtlZUnPaJbArrvwDmhvHelRsazKujSQMbBuqiZNeSLnjwicYSCLXjXzsHkbPsEJmNDDqHsIFoAcogjooioaCJYdVLeZCgoocJqDcDkamLRBMWxdrjXHdEMJdxyQicXdDftjqnJwqZjBtEtoHOYUlhbTAqPkMNfrRDjVY");

    for (int RDPpPnfDGaoYUIN = 173033249; RDPpPnfDGaoYUIN > 0; RDPpPnfDGaoYUIN--) {
        cEyzXwtJRek = cEyzXwtJRek;
        lkyTUgWosxTc = lkyTUgWosxTc;
    }

    return BTGfgsmPPlWL;
}

double ASTTZCkZlYp::dEuCfWaL(double RpaxVckAdhw, int ooIsbSAFttJu, double tYXpY)
{
    double wKuiyiTfaDhFiQl = -890366.7636707413;
    bool amlNX = false;
    bool wFeBOILia = false;
    int bcDlJcfPWPC = 1339587511;
    bool GitfcSWKjwOhHZJ = false;
    string coGlECgzYvaCk = string("mbpNQFsSllLaiohTuXZQXpuPWgsfSPAqBJeOxviqeuZq");
    int oGuLjDmLOo = 1096267672;
    string uGRrKzqlk = string("DjpqMUIhiDLRtuYCEnHMPcrYCMFQknFtmLZHMYHUbVUxUZVuMOHjgaeOdgIKORwWotZKmcTcvdhWADPejUbSFyPGNNzklNxBweRsx");
    int YfmTPnz = 1377557883;
    double jYKbuSbP = -140465.77138172847;

    for (int ngotBkT = 655646615; ngotBkT > 0; ngotBkT--) {
        RpaxVckAdhw *= wKuiyiTfaDhFiQl;
    }

    for (int VqmTWpPpz = 1814435138; VqmTWpPpz > 0; VqmTWpPpz--) {
        oGuLjDmLOo *= oGuLjDmLOo;
        oGuLjDmLOo *= oGuLjDmLOo;
    }

    if (tYXpY > -236177.39762780076) {
        for (int LPWgikSROJJrJmV = 355403340; LPWgikSROJJrJmV > 0; LPWgikSROJJrJmV--) {
            continue;
        }
    }

    for (int qiGNztnkAbVC = 2092328045; qiGNztnkAbVC > 0; qiGNztnkAbVC--) {
        continue;
    }

    for (int LJqMCDX = 1409305225; LJqMCDX > 0; LJqMCDX--) {
        coGlECgzYvaCk += uGRrKzqlk;
        amlNX = ! amlNX;
    }

    return jYKbuSbP;
}

void ASTTZCkZlYp::IoNMOOIrWnvY()
{
    string pEvoxVUXdFaGZ = string("RwTyBpLeftUZJQffxYlMLlpcJrFJBQSGLFRSShWVKtcCxQeudFuhMWssuENnCbtbacvDhlzbErdAaXAZHTkpiewhTClIlHGorWqNcDugJTvZSjFtlIqsx");
    bool yajbVNRVVfHwVd = true;
    int WSOOYUDfYzH = -1095343133;
    string rfkgMYkXq = string("wNeFSaqlcqQwHLJzPYmOZlzhNtVTzdhvWNUIeQaPezuAXkKAQdmQlIyHbCCVEBdTIomOXWdewFhFtPuPFKPphdesiSoXqrMkMkfcDTbFJmzwYbwzZepwumJzmbpwfrIostEfNUxbVZvkROSrnwffiKcOIMtNnhCaPvdkHJNFMnfFJsTudAgNIoVjKdXQqsMZJixv");

    for (int yBHir = 809151394; yBHir > 0; yBHir--) {
        rfkgMYkXq += rfkgMYkXq;
        pEvoxVUXdFaGZ += rfkgMYkXq;
    }

    for (int gBEjMBpMDHmthX = 690614545; gBEjMBpMDHmthX > 0; gBEjMBpMDHmthX--) {
        pEvoxVUXdFaGZ += pEvoxVUXdFaGZ;
        WSOOYUDfYzH += WSOOYUDfYzH;
        rfkgMYkXq += rfkgMYkXq;
    }

    for (int dosmAHhMhOA = 1016065111; dosmAHhMhOA > 0; dosmAHhMhOA--) {
        WSOOYUDfYzH += WSOOYUDfYzH;
        yajbVNRVVfHwVd = yajbVNRVVfHwVd;
    }
}

double ASTTZCkZlYp::QeUGAVQyS(string KcwHitZcYr, string VnqeCZxMVwpGv)
{
    double pblzMMuOu = 383173.31519995723;
    bool piiEUtECFlF = false;
    double InrccYDborvRAfrB = 901081.7869594322;
    int EEbBsdQPUgfBF = -1139325864;
    bool nVlyTOTiKiVjxDIW = true;
    double TkzpqMFAez = 362256.00243756623;
    int tbFJalgGnvodeop = 489651297;
    double TvwgiyL = 458556.10022135946;
    double PBpufsBJQLr = -988998.3256913185;
    double ubEXSaxgAiZYh = 756649.6505274746;

    for (int DQvNo = 101585070; DQvNo > 0; DQvNo--) {
        EEbBsdQPUgfBF += EEbBsdQPUgfBF;
        TvwgiyL /= TvwgiyL;
    }

    for (int qXcZYssxuUljKFO = 537349520; qXcZYssxuUljKFO > 0; qXcZYssxuUljKFO--) {
        TvwgiyL /= TkzpqMFAez;
        ubEXSaxgAiZYh /= InrccYDborvRAfrB;
        EEbBsdQPUgfBF /= EEbBsdQPUgfBF;
        PBpufsBJQLr += TkzpqMFAez;
    }

    return ubEXSaxgAiZYh;
}

bool ASTTZCkZlYp::nsFdrQaHM(string mrMprSBx, bool PfRhXqQlQwhSBIXl, bool ExBlXepLVsCe)
{
    int DGvGDt = -2067874390;
    bool DUwYAwgMpO = true;
    int CbCmULoqDgnTrwD = -1951336406;

    if (PfRhXqQlQwhSBIXl != true) {
        for (int RMovRBfMKmqIHT = 590312943; RMovRBfMKmqIHT > 0; RMovRBfMKmqIHT--) {
            PfRhXqQlQwhSBIXl = ! PfRhXqQlQwhSBIXl;
            DUwYAwgMpO = PfRhXqQlQwhSBIXl;
            ExBlXepLVsCe = DUwYAwgMpO;
        }
    }

    for (int HQRnYnTz = 647616783; HQRnYnTz > 0; HQRnYnTz--) {
        mrMprSBx = mrMprSBx;
        DUwYAwgMpO = ! ExBlXepLVsCe;
        CbCmULoqDgnTrwD /= CbCmULoqDgnTrwD;
    }

    if (DGvGDt != -2067874390) {
        for (int bZjmuArkeaApe = 30696210; bZjmuArkeaApe > 0; bZjmuArkeaApe--) {
            DUwYAwgMpO = PfRhXqQlQwhSBIXl;
            DUwYAwgMpO = PfRhXqQlQwhSBIXl;
            DGvGDt -= DGvGDt;
            CbCmULoqDgnTrwD += CbCmULoqDgnTrwD;
            DUwYAwgMpO = ! DUwYAwgMpO;
            DUwYAwgMpO = ! ExBlXepLVsCe;
        }
    }

    if (CbCmULoqDgnTrwD < -2067874390) {
        for (int iEMedwjffGarI = 1249227944; iEMedwjffGarI > 0; iEMedwjffGarI--) {
            continue;
        }
    }

    for (int PlQQmGslmKXTzeae = 1542640228; PlQQmGslmKXTzeae > 0; PlQQmGslmKXTzeae--) {
        continue;
    }

    for (int yUSRtjLORh = 1183024418; yUSRtjLORh > 0; yUSRtjLORh--) {
        mrMprSBx += mrMprSBx;
    }

    return DUwYAwgMpO;
}

string ASTTZCkZlYp::ZcFYOPwrpJZRm(double moUeNcsQ)
{
    string EBItmEGilZjj = string("UdxuWuxALvQMujpnWGkjESwtKxtDurIyrHVRvPLSIRnMGtWRGQbXxqzfUsRicrtqYWANPlkPFfoAlSdZNgBzlpUJgDddatsIlzlXYLjctotwmyEDMwFcQZXD");
    double huOQlJpxGPkil = 760062.6180555227;
    string OJAftly = string("xDEyWzgJWdcQjpTQSTJebjXhEDGmDPiZohTZuZhPXUqTiXgsJFJaezGQtkAcyXLnfeICyJeTwMlTcEMNGPmUeSyssXKiEInvAhxJMfgDrBHbLhyLtBXeYDnoNmdakbcsGVGlGXfynIPBzSifCNeLmqaRQphapVepgsfLhnJdmqMFqjzNMIARCZCrINfzrMGaMcWKzjaNTaQXhuunMz");
    string vGLlOhTVnGXTw = string("sUHUDxRrzrheZMchkPDIhcYtquVIsJ");

    for (int gUcRNGJT = 506074865; gUcRNGJT > 0; gUcRNGJT--) {
        moUeNcsQ *= moUeNcsQ;
        huOQlJpxGPkil *= huOQlJpxGPkil;
    }

    if (OJAftly <= string("UdxuWuxALvQMujpnWGkjESwtKxtDurIyrHVRvPLSIRnMGtWRGQbXxqzfUsRicrtqYWANPlkPFfoAlSdZNgBzlpUJgDddatsIlzlXYLjctotwmyEDMwFcQZXD")) {
        for (int arbjmuuP = 1839980161; arbjmuuP > 0; arbjmuuP--) {
            huOQlJpxGPkil -= huOQlJpxGPkil;
            moUeNcsQ /= huOQlJpxGPkil;
        }
    }

    return vGLlOhTVnGXTw;
}

void ASTTZCkZlYp::CBFuktJrPhjwiG(int haSOc, bool NOfRiYZtVTYcuzB)
{
    int hMdMmmaljYJd = 125580148;
    bool nzuYJSlSvnaWn = false;
    double piKWRdz = 938491.9503249439;
    int YsBHOYaqAiQhOWVT = 1798922969;
    string rQbuXIk = string("AyAEllOdNtlrdMBZkpPLjrEAKeZvNJnNTNUEwzhPcxYEUNGcSQYNGZYsAKciJkouqIgNFhmWsGJarBgYfneAojwzIdCKwMJXNiScrpWcGcmiOalMLMBTDhzlkgMSUXfxGDYFKyCPdqEUPzNFQQcDAhyniFqrF");
    string JcBkOqKGrXuNKadw = string("rAzTusAkBabBXWZJGMXjhKdNtWdvgYtQyELhSuGVwyEikUADVnqZRKzRphymlkpQnTbFgvcCUXepQLdIQfjIruvQRCWOnKbmGJCmhuDaMGMClvlDkEDNLKcRMJJvenTjUHWBqkjeLkTtdkEkXwSovOSrNaSNYCAAHZDTEoYuXlDtIOmhnHQNzBIGuJBrcCWJNxkekp");
    string vQSbv = string("ciwkYwquCqTrOhjFRgRbPWvGdoZhukdjHUYmBwNFeMgLHbNSLfAMrQEUtUJrHiWmsqErVBEtmWrmutThoarnsuWiwrYEJFbJWWTRLlUMwdbxQzkVCunMaMzeuahnDZyLMEMTBjUBkObXNWczgORWNCjThoUZQZxeoPNFkclOcxjRLhxp");
    string pEamLg = string("gwRJTDqXUveXvJgkIEdjbgdMMULOJHrxtMIryHvSMFCswWeXoRSwiqUwhOZOKbxPEnuhVvECHliXsBtdCQzlHdRzHlftETLgEBlrwyBQRIgeabpAFfZivFjGbRqGlMnFSIHVtMpClxXoeBDLXFjbwfTBPiiUffsTjEcCIRRBggkjcNvAJjLkBHcVxFbrAW");
    string MiHniTxdpXwyszNc = string("WurYGhWKqFMEcBInwhOfZvmndntXvQIIGuxGLBtBtxXCrqyirMkaehwvuFjtTfsVPXwOTMIRuWDyoVjjZPpVtHEOJFPUsjgvfUuTFwudWFfUzuEeHVWlzFZqLSuZDRcIThHcBuPLTaTPcWhLWAbVHYv");
    string NAmDMhJdqUUInOlB = string("tvMDGXGunEuDUfjXcCwRRxronsiUvVrGhlszWFMHBFDSKhmOcsOc");

    for (int wiHUWqAUGvf = 1208265550; wiHUWqAUGvf > 0; wiHUWqAUGvf--) {
        JcBkOqKGrXuNKadw = NAmDMhJdqUUInOlB;
    }

    for (int pSLelkScVr = 645067691; pSLelkScVr > 0; pSLelkScVr--) {
        hMdMmmaljYJd = haSOc;
    }

    for (int RTAwkGYmVFkaE = 2042271582; RTAwkGYmVFkaE > 0; RTAwkGYmVFkaE--) {
        continue;
    }
}

ASTTZCkZlYp::ASTTZCkZlYp()
{
    this->NJjjSRFdKAVLtbW(-1422275659);
    this->GEOgBywkn(false, 665373.4016803664, 409538661, string("HXIFkXLJtWkOinWLnRBDoKbFklgTHZdYZqArVMbsyBhAibAgFGwdFQMEdWhxEASUFnKuHjtiJaLQDAZfukwMVOxzeeiPzXUVqxxmBvzflCegEjIykLONwnNDiguhnnseRCDmUORWShVCPZCzdeggQrYrqWlZBkHlOulFyIVgQIUBVEyTGlWYBxYUjKA"), -1915452103);
    this->LjIFsrSHhi(-1351027112, -495210.7415990151, -283936.88134202256, true);
    this->dEuCfWaL(-236177.39762780076, 371602603, -305300.62732293544);
    this->IoNMOOIrWnvY();
    this->QeUGAVQyS(string("zyPYQtFrUYbbCdjVUPhqKbVvMolxPviipWZPKYlWjpwFCbOyUXmHlHLDgRQydDCcPBbWtivmciGGtGbbnSnzUQICGvGJUzIgVAkQIHOSELjSjTYzjVoCvvjAQHmLsvjhvGZ"), string("fcRkleBndZRJpRULvVuJJhJzAxrqMJlZqJjwTOVgqfhwaCnrcPoeXJyjFTFkPxVvQIexAuLmZHYIoVcIIsHQrfTMMAtErRxdLWQdWtXvdQXacSWPPzbfCymuKPuJjjAeqNVIakdfNrPWVWDGTtFYPoJQAoNrXcAficrmvngPkFvGj"));
    this->nsFdrQaHM(string("KvhQNUriZCJEgkUmlgRAHtSuWhmXdOonYiPwkSeFKmmRSXMupnWdEpmRljhaOlVrHDdFbmztPYnhCdzVSHCHnYywQqwjSNzRcqLKcIavcxxYHVzURVnEnUuaaAQbQFlHucplxAUwnopqxvQwgftYZxHCN"), false, true);
    this->ZcFYOPwrpJZRm(-173956.78449143667);
    this->CBFuktJrPhjwiG(1035030947, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mHdXK
{
public:
    bool ZNwXPVxhiyDVGw;
    bool lUEwcos;
    int RSWjuCITHsYfUtY;
    bool KCwYn;
    bool ENvoLoAxRlZTKFG;
    double FglCJGmCgou;

    mHdXK();
    int zZCUmoiO();
    void udIAnppIqfnBq(bool ObyqtHIaSDSfCRDL, int ZTPCAyEWpsuf, bool aychvuippvKTHag, bool YnTAbme, int wAJREb);
    int KxQeLjTWCelrAFzG(bool qDcTmmjsdLjIur);
    double uoJjcGTgQcA(int WhptccNC, bool parNJwPffriiSq, double rpjdrWezylSaV);
    double byLBCuIy(bool DxaxkQi, bool ziwBg);
    bool FrJRGz(int rLHveW);
    bool IGaGLvY(string kgPgijyjCUXpgP, string ONfXnfPofOSGjA, int CsUxkfuruAlPbsy, double xtxpk, string ktgqaPNQmG);
protected:
    double tRnIzjhWaCsykfD;
    int yxNzKifGH;
    double LAMntx;
    string nOElMBMSN;

    bool JbkknOx(string YXdjRoe, double UjRpzDbhIhlqu, string FWkubf, int uoMzpSXMcX, int PFQyzaPUPa);
    void lvArm();
    void OmGUASTQOBzZpDN(int fmmNgqkwQ);
private:
    string BSUapT;
    int IMLwkeYnhXNRt;
    double TlYNFeedps;
    bool FmuvB;

    int YChTSnTDoSX(bool mxtOjknRCeaf, string EooeHfHF);
    double zAgOvRiLqNuWFFW(bool eRVLmquBB, bool OVwkMWGiloHW, bool vrguGfi, int SDvFI, int aGUgcKCsqoHsZCG);
    double YZTRZ(bool XGCgJqYozMrF, string myFAMVesmPyKgcL, string JTgwQ);
    void JcHgbIVCNvvCAihm(string GgZbYiMqAMnz, bool VOARXIPXMQr);
    string MUzrxkEbphXYjZaF(int vHTylFVNwxgljyS, bool RCdCJQ);
};

int mHdXK::zZCUmoiO()
{
    string EUpLIGJyBBsK = string("kjILfakRsoZybkoLQIBeBBEKTilHMbLdYZTcuOlCVaQriZeWrGyUDDpVESwgxueRvaNKEtvmsIWfpYhIHgYfQxZAcdZITPEIpxebMBbHqZtvIqxmFArPjemhLylvbCIQbrENwIkLmKeqVdamcTRdtkCPFlRrWBehgQEcmSOXElflsGupagqWbKFqrgLXyrUzpJUDPqqfZRQWHVHHehQcznXcyawjBtQUzJGgOaFsootSzTYRV");

    if (EUpLIGJyBBsK > string("kjILfakRsoZybkoLQIBeBBEKTilHMbLdYZTcuOlCVaQriZeWrGyUDDpVESwgxueRvaNKEtvmsIWfpYhIHgYfQxZAcdZITPEIpxebMBbHqZtvIqxmFArPjemhLylvbCIQbrENwIkLmKeqVdamcTRdtkCPFlRrWBehgQEcmSOXElflsGupagqWbKFqrgLXyrUzpJUDPqqfZRQWHVHHehQcznXcyawjBtQUzJGgOaFsootSzTYRV")) {
        for (int EpQcyxcoReDHufgx = 856655404; EpQcyxcoReDHufgx > 0; EpQcyxcoReDHufgx--) {
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK += EUpLIGJyBBsK;
        }
    }

    if (EUpLIGJyBBsK < string("kjILfakRsoZybkoLQIBeBBEKTilHMbLdYZTcuOlCVaQriZeWrGyUDDpVESwgxueRvaNKEtvmsIWfpYhIHgYfQxZAcdZITPEIpxebMBbHqZtvIqxmFArPjemhLylvbCIQbrENwIkLmKeqVdamcTRdtkCPFlRrWBehgQEcmSOXElflsGupagqWbKFqrgLXyrUzpJUDPqqfZRQWHVHHehQcznXcyawjBtQUzJGgOaFsootSzTYRV")) {
        for (int KOWuVji = 1229242807; KOWuVji > 0; KOWuVji--) {
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
        }
    }

    if (EUpLIGJyBBsK >= string("kjILfakRsoZybkoLQIBeBBEKTilHMbLdYZTcuOlCVaQriZeWrGyUDDpVESwgxueRvaNKEtvmsIWfpYhIHgYfQxZAcdZITPEIpxebMBbHqZtvIqxmFArPjemhLylvbCIQbrENwIkLmKeqVdamcTRdtkCPFlRrWBehgQEcmSOXElflsGupagqWbKFqrgLXyrUzpJUDPqqfZRQWHVHHehQcznXcyawjBtQUzJGgOaFsootSzTYRV")) {
        for (int tLFLTZ = 409081055; tLFLTZ > 0; tLFLTZ--) {
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
        }
    }

    if (EUpLIGJyBBsK >= string("kjILfakRsoZybkoLQIBeBBEKTilHMbLdYZTcuOlCVaQriZeWrGyUDDpVESwgxueRvaNKEtvmsIWfpYhIHgYfQxZAcdZITPEIpxebMBbHqZtvIqxmFArPjemhLylvbCIQbrENwIkLmKeqVdamcTRdtkCPFlRrWBehgQEcmSOXElflsGupagqWbKFqrgLXyrUzpJUDPqqfZRQWHVHHehQcznXcyawjBtQUzJGgOaFsootSzTYRV")) {
        for (int LPtyPybALHniYP = 745398111; LPtyPybALHniYP > 0; LPtyPybALHniYP--) {
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK += EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
            EUpLIGJyBBsK = EUpLIGJyBBsK;
        }
    }

    return -580817165;
}

void mHdXK::udIAnppIqfnBq(bool ObyqtHIaSDSfCRDL, int ZTPCAyEWpsuf, bool aychvuippvKTHag, bool YnTAbme, int wAJREb)
{
    string WYTrxRsOrLm = string("gnqlflyRFurQOAVBtUIECMKOyKtrGaNwbiWqYQzMhqpRRjPjbIJsFkCSZqBxrWMNnDnXYMgVpsRbQGsWCdru");
    bool lesHIfJXd = false;
    double kziLLcx = -229739.96175067275;
    int OZfoVrKsLr = 975938857;
    string TfkHNK = string("YMaGsxEkFvozbOvjyBEzSlkSKPTokncFhknpUCBFOVXDvufRLPwpNKwhdotYrFuBzyBmjErJaUoNGKTgoXoszWHyYVRWjyujwxCyEoxoLiNAgbpkKcMJTKMxYNSXsdScHpHdcjnkumvNjzkbVqqPmaUlUDJvxAoAgBGwDzxnAHRUzuLqgUgKnqgRnHWfueBFmYzLFojHomPQLjVV");
    string fPzBipwyHKgSZfDS = string("VMKLbhbYLuRleBAsovxiQySrAkyGYewekrFSLBTmjIVNHDQhSoCMEZsHipTBt");
}

int mHdXK::KxQeLjTWCelrAFzG(bool qDcTmmjsdLjIur)
{
    bool YlLBlQmIgIcKBIJA = false;
    string ONEZFsbGx = string("begUKFlMPGCVjReryVzzWcrAYoCCUqsjiNdyPbLgPPYNDmyPoIRdbwUcMhyiwtKNyefINFY");
    string MGuXxNiWxmiszvp = string("BMjaRHrsApBZtuHIYpBSfhGZjTwJaoFlckUydSRyrYaKtUNJfZxbvWROAygEDucpzhLuuqYtBTCOcWZbKkLxKWTBwxDRHerOZT");
    string wBejmWNRdnhgzZ = string("aSBASSmRKbWXapDQooeiCjDszdfNrFXUKxPgxzaT");
    double VOoRRBASKBuPZXr = 358233.9983185158;
    double zFGufvu = -44064.21400231101;
    bool AALoIkWWgWjc = true;

    if (wBejmWNRdnhgzZ == string("begUKFlMPGCVjReryVzzWcrAYoCCUqsjiNdyPbLgPPYNDmyPoIRdbwUcMhyiwtKNyefINFY")) {
        for (int MlPCoXyXE = 1375197384; MlPCoXyXE > 0; MlPCoXyXE--) {
            MGuXxNiWxmiszvp += MGuXxNiWxmiszvp;
        }
    }

    if (AALoIkWWgWjc == true) {
        for (int tIAiCGY = 1062903536; tIAiCGY > 0; tIAiCGY--) {
            continue;
        }
    }

    return 2096375216;
}

double mHdXK::uoJjcGTgQcA(int WhptccNC, bool parNJwPffriiSq, double rpjdrWezylSaV)
{
    bool roOAAOs = false;
    double QRXeyJYCo = 690848.271947799;
    double UmmfKLwOdiaZgLa = 730194.7946327339;
    string HsBiFTPVduvpA = string("LCBAIrImgbHieZBALKRJsXjqmwbHcdYOHTjLxwfqTlEEBqKFeuecuSBNVqEAxjHQFBtAsWkMtIxRCNkQTNksvHuEFIUlqPlarcNJmZzWXRfJymLQSFfSnJslQyvEEbkrYzsGnWfSsKNllegYMQhKhKvYznMZlEFvObantjjRfzJthQbPTCcptLSmMswkKoOLJmNmUJuNuCdEaAHvhZkYmJfljMmtSMLODyTgqXBJoXfsoRYVjKSYsvJpvhn");
    int aCukajEEWCL = -1629217463;

    for (int pRAeICJ = 377569577; pRAeICJ > 0; pRAeICJ--) {
        UmmfKLwOdiaZgLa -= QRXeyJYCo;
        parNJwPffriiSq = parNJwPffriiSq;
    }

    if (aCukajEEWCL > -1432660085) {
        for (int lJIRyVVv = 217285645; lJIRyVVv > 0; lJIRyVVv--) {
            aCukajEEWCL -= aCukajEEWCL;
            rpjdrWezylSaV = UmmfKLwOdiaZgLa;
            QRXeyJYCo += QRXeyJYCo;
            aCukajEEWCL = WhptccNC;
        }
    }

    for (int HqVOEJ = 780095510; HqVOEJ > 0; HqVOEJ--) {
        continue;
    }

    for (int QjyVcik = 1178555936; QjyVcik > 0; QjyVcik--) {
        roOAAOs = ! roOAAOs;
        parNJwPffriiSq = ! roOAAOs;
        QRXeyJYCo *= UmmfKLwOdiaZgLa;
    }

    for (int ymHUlilyavbUEF = 1643921374; ymHUlilyavbUEF > 0; ymHUlilyavbUEF--) {
        roOAAOs = ! parNJwPffriiSq;
    }

    return UmmfKLwOdiaZgLa;
}

double mHdXK::byLBCuIy(bool DxaxkQi, bool ziwBg)
{
    int GjKNTHwtKYiNe = -1255960273;
    int bjhjyAjfFOeVrC = -431529426;

    if (ziwBg != true) {
        for (int gbPmOZgjOct = 1598735942; gbPmOZgjOct > 0; gbPmOZgjOct--) {
            DxaxkQi = ! ziwBg;
            GjKNTHwtKYiNe -= bjhjyAjfFOeVrC;
            DxaxkQi = DxaxkQi;
            ziwBg = ! ziwBg;
            GjKNTHwtKYiNe = GjKNTHwtKYiNe;
        }
    }

    for (int YrIdKd = 1654277912; YrIdKd > 0; YrIdKd--) {
        ziwBg = ! DxaxkQi;
        bjhjyAjfFOeVrC = GjKNTHwtKYiNe;
        DxaxkQi = ! DxaxkQi;
    }

    for (int OWmIMDzgtdDX = 1374187933; OWmIMDzgtdDX > 0; OWmIMDzgtdDX--) {
        ziwBg = ! DxaxkQi;
        bjhjyAjfFOeVrC *= GjKNTHwtKYiNe;
        GjKNTHwtKYiNe = bjhjyAjfFOeVrC;
    }

    if (ziwBg != true) {
        for (int mqPwyUVQQOqIQlJ = 2141853874; mqPwyUVQQOqIQlJ > 0; mqPwyUVQQOqIQlJ--) {
            ziwBg = ziwBg;
            GjKNTHwtKYiNe /= bjhjyAjfFOeVrC;
            ziwBg = DxaxkQi;
        }
    }

    if (GjKNTHwtKYiNe >= -1255960273) {
        for (int MBNLqevZOjFTz = 946273853; MBNLqevZOjFTz > 0; MBNLqevZOjFTz--) {
            DxaxkQi = ! ziwBg;
            ziwBg = DxaxkQi;
            DxaxkQi = ! ziwBg;
            GjKNTHwtKYiNe = GjKNTHwtKYiNe;
        }
    }

    if (ziwBg == true) {
        for (int WCQNaKUcvSA = 1377710607; WCQNaKUcvSA > 0; WCQNaKUcvSA--) {
            ziwBg = ! DxaxkQi;
        }
    }

    if (GjKNTHwtKYiNe != -1255960273) {
        for (int LdyCOHvTznzDg = 1723359745; LdyCOHvTznzDg > 0; LdyCOHvTznzDg--) {
            GjKNTHwtKYiNe /= GjKNTHwtKYiNe;
            ziwBg = DxaxkQi;
            ziwBg = ziwBg;
            ziwBg = ziwBg;
            bjhjyAjfFOeVrC = bjhjyAjfFOeVrC;
        }
    }

    return 517105.3901381482;
}

bool mHdXK::FrJRGz(int rLHveW)
{
    int BNIRJ = 1867865627;
    string yJFeypw = string("FEAVERVDTFLQiJTvUrAEnPWQoPNFtrNMRgoUcGByVHXcfplGtdCzsDMVpMAeSlZUJyEQJMJMsGnlwSMxXEkgMYLw");
    double FqOENREDp = 811856.7870927025;
    int wfUVmOGOeiY = 980375507;
    string ajAVftKqhNi = string("uiMrvkaopQvxfWfJeqenrRlYqcPbuWCRSgDlLSNYLnOOFCZsDBcChIfrAcTkpdxaKpYkPnlAgSgYydsdwgZTQjgsaXgkGyrdvzhLbGMfvgCmNdlNwACqiNHrdwDFTGkPwGpFYgDEQqYkdLtRoiTjtFqaBzZJvUjH");
    int ueALrelZMi = -631590998;

    return true;
}

bool mHdXK::IGaGLvY(string kgPgijyjCUXpgP, string ONfXnfPofOSGjA, int CsUxkfuruAlPbsy, double xtxpk, string ktgqaPNQmG)
{
    double MdOMkHByysuxyf = -989398.490925223;
    bool xjTAXnFDQo = false;
    int lZvFvcSChFoigVyP = -331557580;
    int wSelTMaEhsFIgt = -310690903;
    double qZorHYYXp = 93194.51674196462;
    bool obsWWi = true;
    double AIuCsyd = -155252.04277719228;
    bool IaNal = false;
    string OJngQqqvq = string("MxxIifGUBRlxYkRGnVHRUIVkryzGVLjxDeLBWARVuapTukvqlzlNVwrmhUWmiQgFxccYIHcJzzIpBjHdEwRIXmTItBVycYjalVCktpdeeyYKgBPQj");
    int yaUSTUVA = -1287912588;

    for (int pqvihjbKDmByaw = 71014218; pqvihjbKDmByaw > 0; pqvihjbKDmByaw--) {
        kgPgijyjCUXpgP += kgPgijyjCUXpgP;
        ONfXnfPofOSGjA = ktgqaPNQmG;
        ONfXnfPofOSGjA = ktgqaPNQmG;
    }

    for (int sALStvN = 1915699788; sALStvN > 0; sALStvN--) {
        continue;
    }

    for (int bHJCs = 2013684921; bHJCs > 0; bHJCs--) {
        yaUSTUVA = wSelTMaEhsFIgt;
        qZorHYYXp *= AIuCsyd;
        MdOMkHByysuxyf = xtxpk;
    }

    return IaNal;
}

bool mHdXK::JbkknOx(string YXdjRoe, double UjRpzDbhIhlqu, string FWkubf, int uoMzpSXMcX, int PFQyzaPUPa)
{
    bool Bprcj = false;
    string yrfKIhaBKoNj = string("uBpWtUkssbvbtZWccnferlKAkAzT");
    int tyxsWwFB = -2042538024;
    int vSETABdMYzkPgE = -722554250;
    string FdqRGErBXW = string("aoWsZaDFBAuasDecBMRheRyXEFoXdlycFBMLSaWSWlWKYZVWBgaXmeYDMUVmeRTkpowkToeNyJjhgKhPtrMrLjaKlPlrIJPMfUOSDXdMQNovvRGsjznfFxulHJeWldRcBkXSVYnCObpxWZfsgDoYIIYQTVaNyWsQdRDUdXEvrmFNW");
    bool HJSoVnCvTnHk = false;
    bool qQLEGmhxtHQGRyF = true;
    bool EuTCANni = true;
    double kUpWk = 852640.5683005487;

    for (int czCirxzZFHglv = 2036597100; czCirxzZFHglv > 0; czCirxzZFHglv--) {
        continue;
    }

    for (int BCOcuoP = 869235184; BCOcuoP > 0; BCOcuoP--) {
        PFQyzaPUPa -= vSETABdMYzkPgE;
        YXdjRoe = yrfKIhaBKoNj;
        YXdjRoe = YXdjRoe;
    }

    if (YXdjRoe >= string("uBpWtUkssbvbtZWccnferlKAkAzT")) {
        for (int UWOTZEyosRVcohPA = 260850137; UWOTZEyosRVcohPA > 0; UWOTZEyosRVcohPA--) {
            UjRpzDbhIhlqu += kUpWk;
            Bprcj = Bprcj;
            FWkubf = FdqRGErBXW;
            qQLEGmhxtHQGRyF = EuTCANni;
        }
    }

    for (int uwvCPooXFpghAF = 2072627652; uwvCPooXFpghAF > 0; uwvCPooXFpghAF--) {
        continue;
    }

    return EuTCANni;
}

void mHdXK::lvArm()
{
    int wEysPSuLJv = -1883700109;
    int NQtvWcp = -1681603008;
    double VdtDj = -425527.7362126743;
    int sCfZUSqE = 1497303538;
    double jkAEdiq = -173585.05327677992;
    string CtToiviNo = string("WBXTxsJKCgdSyXEHqmSDidAmakpiZqcHbjPxfgFmHLdRZWgNARVlyZAiYgbHAOUdIJikquOCbnxkOPcgYuqZEUVoCgRCwbOgqIXZSFHmCSnLhUtPtNOsMGzBlgkqWHeseuuMYVwwQhtgMexGWKcmGxsdQaLanSTObJhTjhIrHtyEUvkUiZwEOXgNnuwDVSrMRothlaXHqazSMGelQeeJUdyIaFqekFwanhInQASrSEuiCDlOwGNcmIUCeEa");
    string VcyddBMylXeY = string("nMePVXeGvSdXebaFCaaTaMgvhuUEpLgsjRyzDIIMGqOzAxXXInMOzWTaujZaZfwMjgxTeXUXqCVQoLDXblRyGSpTUjEoowzSxEIVmhaptfsRVgwHlkLZkHvEiTBsYMXrJCuaWdGjmEZBlmknfDNyAsYZbYjmlOxVFyAnvKDwLfLTdZoHmAEetzpu");
    double uOhPbrvQGiurKcj = 928707.0174928433;

    if (jkAEdiq > -425527.7362126743) {
        for (int mfPrlQplCQXSKYYt = 1760771887; mfPrlQplCQXSKYYt > 0; mfPrlQplCQXSKYYt--) {
            CtToiviNo += VcyddBMylXeY;
        }
    }

    for (int RTpgqDTRD = 308931303; RTpgqDTRD > 0; RTpgqDTRD--) {
        VdtDj *= VdtDj;
        NQtvWcp -= NQtvWcp;
    }
}

void mHdXK::OmGUASTQOBzZpDN(int fmmNgqkwQ)
{
    int bWYOjNX = -86983853;
    double VXkiLUY = 351996.6416256384;
    bool qZurdpPBCY = true;
    string PcjCwFukTpoJTPe = string("OuhXMENUfppVvvlauBimiGNPNwKQoQybWopSEUegOFYAIeTwuqmCsxWTiLhIojsbfJlbdFiTlTlJvRtBhopkeHjjALGrUeOsJVycTrCnfYXyJGTGqsJzkxwcJwaFhIXQLcXQPNOSXutJszRBtdnwOsyhfLUADiwTUyYngEPoATgrVZOHknBQoh");
    bool JhihMhLeUtr = true;

    for (int hQyMuT = 166682524; hQyMuT > 0; hQyMuT--) {
        VXkiLUY -= VXkiLUY;
    }

    if (qZurdpPBCY != true) {
        for (int szCfcmw = 138157492; szCfcmw > 0; szCfcmw--) {
            fmmNgqkwQ += fmmNgqkwQ;
        }
    }

    if (JhihMhLeUtr != true) {
        for (int wpdYyablSOdlY = 1545965072; wpdYyablSOdlY > 0; wpdYyablSOdlY--) {
            fmmNgqkwQ *= bWYOjNX;
            fmmNgqkwQ *= bWYOjNX;
            bWYOjNX *= bWYOjNX;
        }
    }

    for (int BIECsanFuhFpxKa = 607022311; BIECsanFuhFpxKa > 0; BIECsanFuhFpxKa--) {
        continue;
    }

    if (fmmNgqkwQ <= -1042381695) {
        for (int RiXkpknZqvdU = 361974222; RiXkpknZqvdU > 0; RiXkpknZqvdU--) {
            PcjCwFukTpoJTPe += PcjCwFukTpoJTPe;
            bWYOjNX = bWYOjNX;
        }
    }

    for (int uQZToVqhI = 1050501506; uQZToVqhI > 0; uQZToVqhI--) {
        bWYOjNX = bWYOjNX;
    }

    for (int CxKcbZgSR = 1936060633; CxKcbZgSR > 0; CxKcbZgSR--) {
        bWYOjNX += bWYOjNX;
    }
}

int mHdXK::YChTSnTDoSX(bool mxtOjknRCeaf, string EooeHfHF)
{
    double oceKtQJrHxt = -192945.4215371583;
    bool zCGLCEWBUYSM = false;
    string MNWKFfYIbksymcJ = string("ZyKNYttvLeXIFQEmWbHLsyvqMMViyUjRUttOeLrGbVBYTXZmRhrIJHYjboanDxFRagiIvtQsczXKWytnOKcUsIhaGZpvGaFACedYJRedZmsw");
    string rMlIStroH = string("GNuHMokOrVfybmvEJFdeUEijioHHwblhezfOeYxeVLzMclD");
    int DeDeNqiYt = 400109471;
    int HsKIvxa = -665837268;

    if (MNWKFfYIbksymcJ != string("ZOHRrrFrovDUoFBgiPLmMOmOtdxvshxOggMwVDHReOKczXhNxygvAhSdjgkLMoEaPaWYAfJIvCOCbWcxoqtIOhZeBJQeIWQRRheKwIYtzbOHDeTxuXQJf")) {
        for (int hedFYQFTVk = 856951393; hedFYQFTVk > 0; hedFYQFTVk--) {
            MNWKFfYIbksymcJ += rMlIStroH;
        }
    }

    if (rMlIStroH <= string("ZyKNYttvLeXIFQEmWbHLsyvqMMViyUjRUttOeLrGbVBYTXZmRhrIJHYjboanDxFRagiIvtQsczXKWytnOKcUsIhaGZpvGaFACedYJRedZmsw")) {
        for (int QdKfGuDeJlU = 2035019625; QdKfGuDeJlU > 0; QdKfGuDeJlU--) {
            EooeHfHF += rMlIStroH;
            EooeHfHF = rMlIStroH;
        }
    }

    for (int uVVJl = 263064571; uVVJl > 0; uVVJl--) {
        rMlIStroH += EooeHfHF;
    }

    for (int UOGrdncYtWI = 617580274; UOGrdncYtWI > 0; UOGrdncYtWI--) {
        MNWKFfYIbksymcJ += EooeHfHF;
        rMlIStroH += MNWKFfYIbksymcJ;
    }

    for (int ATsDiKThQ = 1767157116; ATsDiKThQ > 0; ATsDiKThQ--) {
        oceKtQJrHxt *= oceKtQJrHxt;
        HsKIvxa = HsKIvxa;
        EooeHfHF += EooeHfHF;
    }

    return HsKIvxa;
}

double mHdXK::zAgOvRiLqNuWFFW(bool eRVLmquBB, bool OVwkMWGiloHW, bool vrguGfi, int SDvFI, int aGUgcKCsqoHsZCG)
{
    bool cWuYGougONnO = false;

    return -519488.9839969059;
}

double mHdXK::YZTRZ(bool XGCgJqYozMrF, string myFAMVesmPyKgcL, string JTgwQ)
{
    int ZSDJgBV = -687287137;
    bool rcBOV = true;
    string OtYLKoAz = string("mjGTDoHqisBTchbATQcKKWUcRjBUhHCLRVGYRdKNExqclgalAncQUyRRmmeMLAyxqgxRFqecdAidKJXkmyACOaEMvRfLkxbdLuuGMBWNpaoWnYJzdcPstYCcbCNaKvzrivMPDCVdWEcPGNOVxBbXFssdsKLtuBGsMfYnMWxDZVRjhDkjClvQDtpoWlwpdTSJOstfCXuQwGgrRmIeNvITxiaiszneLkLoRiHnmHZNBiFHkkUjryeygxjPEodlkE");
    double iRoyXVDESwsM = -842749.5003484782;
    string JBBjbrXwWstQg = string("gbMotvkGZMcUmLwnqubpktWKGErOrWJtopwMDdRuMCgDROCwPKiruokxjLvfLZgbXrDphBfWdlYGeqzXOTbQJINVIqgdYGeXGkRHlWukuzODGxoPwvKDRctOFydBMyNTymXIbVprCBLBkPznqhXhYXtSoNHXdYIb");
    bool HktTdIOXrNlSSn = false;

    return iRoyXVDESwsM;
}

void mHdXK::JcHgbIVCNvvCAihm(string GgZbYiMqAMnz, bool VOARXIPXMQr)
{
    string OPKlgmsSZSEhpRe = string("dkE");
    bool QHUiVSeSyySoIQ = true;
    int TOMYII = 947947133;
    int WiEZPuTOHFPum = 1821758339;
    double ReuHiTnZd = 648451.7074999489;
    double arVbRXKouFhKru = -409682.65057933144;
    string HOCky = string("jzuQdwflimbxrpQRpQeXnYYlMqBVhjEZulrTAKIOoNhSfGXVDbrbosRJHPVcEKGNxolHIEpURmilr");
    int dPmcQzYzQbvQh = 550168519;
    double AdnTddJ = 1007009.0184616292;
    int tPkLTekk = -16095922;

    for (int sOSetFVuaKFiZ = 992991980; sOSetFVuaKFiZ > 0; sOSetFVuaKFiZ--) {
        tPkLTekk = TOMYII;
    }

    for (int Xpiuogz = 1048057744; Xpiuogz > 0; Xpiuogz--) {
        TOMYII -= dPmcQzYzQbvQh;
        HOCky += GgZbYiMqAMnz;
    }
}

string mHdXK::MUzrxkEbphXYjZaF(int vHTylFVNwxgljyS, bool RCdCJQ)
{
    int YzPqiDNq = -1553156252;
    string vENXQma = string("niwwkvXaPgkBoUujyHKBkyEeMRmOheYIwJxZQHANIHZnaYIMhmmCvnuCgkAMNkJFvUFeUjpleTcAZlhPOvLZpgEPzaWpFymeWzfZhgypfNLHkdUkitRwohtFLYBglUbbHNKLzLDvfthaBdfkDgEBUPqCBUGnCXbjXxOWMiAsAghxpZQZVTYmkszuHAtWgJJAvYQHDWgINtrTDcTWfjywoEHeZBZIRHaWhrzekZoClsgwdrdatqCU");
    int FYQwDkNGTuNWra = 1865638948;
    double leTAoyoktXjUUm = -81243.10276431628;
    double NPjfaYtaXzQFqW = -794167.1702364681;
    bool CXyqEaIrpEKCKVb = true;
    string KlTtmzZLqQ = string("iobfyTlkZZPhrqYcFbyZuiDwvYCuObxIWwKrZeowQcbHQmYfBUoponhILgJKFqwbHMhlyvPmdLKoPHoHqcGnSUJjaMNzcBnmwmhygCrRCijaovfdggEokUwTXdOClGyDRyJUnygIXlWSAmwbququTSkmmlJLzvNHHQnASOQVweBVKFWiVMbXHdCeDvfPHLqMqMFYzDjxrVZrBiGPRZWTkuCJSUHepeDYEInQsvCswmdGFokJDLNt");
    bool nMFEaiOK = true;

    return KlTtmzZLqQ;
}

mHdXK::mHdXK()
{
    this->zZCUmoiO();
    this->udIAnppIqfnBq(true, -1011738668, true, false, 400156608);
    this->KxQeLjTWCelrAFzG(true);
    this->uoJjcGTgQcA(-1432660085, false, -654587.0862191884);
    this->byLBCuIy(true, true);
    this->FrJRGz(59086505);
    this->IGaGLvY(string("DXdbxIGGhIVQTJdIXpKuHHthLetNkrGMWnbbZzSPYXaIOrRFHkGcLqmTVTBuBRjVwrZAxYmfhrHxZCnbYsgJpHnnRJHNYRjHXYxcbCIZjSRADemqiqoLFSaKEUcoWJpsuwKhwdxOJquaFIpDXFWbklFpxvP"), string("dWZYbbiVyRFOeRVKMLuGYMvykNrBCnPYgySgKkqSutlwljUAtJjajwozVOgmltSlZslmhXICQiARiiJnpcNOhFMbHiWMpRWvJpaFDREsgotjfVxFXGYMAYDLxlFluQGofiYvVgrQjmTymaequhgqeWYhfvXjLexpITtiEaPvhUbcHzCaDgJNwQastFMearrPpbFDpqwIIIEDyTvFKTETeKaiCGdGztZcwAyesIaIYxQEoWTkHBNdbUQmGNLLR"), -1705529620, -938646.4837570628, string("kbRpOYqaKmZFqAmoSklLXLyYXBEauEKsHrCNBpuqsMvRNvfVYWKNPqhhdDyDskoFWDUuBdJRmOoLPjGohfPujNFHDDQftYxmR"));
    this->JbkknOx(string("oNmPdNjGwgftfbjQcgDcSGsydpfBoZQCkVLkFgaNhXcinTQbtFTdYmTbGAVUrGzAFxrKxXCgWzEdAkXYDjNIaEbavfDmYJrKMuQOeDtgRNjwAbIZHSacPJLQfxaxBLLpexKlAH"), 725978.9214172716, string("qvLSxEblAkkNFJAelrfWWBENjbjNNLjuCMBEvoUxIxJVKjUpBYUTaqSeRFTdvatviZgMEHwMYwxnwxrrPyNkAHzCQIJsrYMXWkDsAXpsamMlQWwRuyrcfKSbzXEZhvyEHSUnBykPNQYCklmqtQfgdTrANkqiMcTXKiSPLRPYfnyWWunsQiDXlyTAWIrXZmqJwegrgfesvvNJHcDFpxfRGg"), 1652592038, 154605538);
    this->lvArm();
    this->OmGUASTQOBzZpDN(-1042381695);
    this->YChTSnTDoSX(false, string("ZOHRrrFrovDUoFBgiPLmMOmOtdxvshxOggMwVDHReOKczXhNxygvAhSdjgkLMoEaPaWYAfJIvCOCbWcxoqtIOhZeBJQeIWQRRheKwIYtzbOHDeTxuXQJf"));
    this->zAgOvRiLqNuWFFW(false, false, true, 1992774794, -438452201);
    this->YZTRZ(false, string("wKZVnEYyHwVbczJDkRXqcOrQfaJUg"), string("WYnweCKNFSEerBoteekCCgRsszCgwfuxiVIeRo"));
    this->JcHgbIVCNvvCAihm(string("fjAnTSRSMUaWyUEBiMYquMGVfycwfOQoyCqkKTVkGdUOhJiTxlCzGRJtbGgsWRGneEUsaWqTmuEwuJNqgpwrPgThBWCNswfijzEWRqxdWVmLOQVJvoQwAqLRDtgdMAPsYKOEOYnLVqWieRytkxAJKIXilwdaoOHEVjJIJhhxBojWkTVlA"), true);
    this->MUzrxkEbphXYjZaF(1647780379, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UNjeAqSq
{
public:
    bool sHXITNfKfAFh;
    double aSeTukkbhDDh;
    bool MAjsHEoMBQl;
    bool fbPQAb;

    UNjeAqSq();
    double VtaxdbkyKS(bool xfxAlaLUSZeov, int euwYuvRsMTjYffBh, int ItrDLnyroQtZZR, bool jiUPUcIwl, int qWdupKSrWsNu);
protected:
    string NqKhOSXthlOr;
    bool JqbLzG;
    double rKBtIrdLTCLYrfZi;
    string SdYMPPMjU;

    bool TMyReL();
    bool WECcSCwex(int oJEOEUWuuWkFXtU, double lRuwJlIylZcjwUG);
private:
    bool EWRzGeMAAsqFpuR;
    string qOLwNrjMvD;

};

double UNjeAqSq::VtaxdbkyKS(bool xfxAlaLUSZeov, int euwYuvRsMTjYffBh, int ItrDLnyroQtZZR, bool jiUPUcIwl, int qWdupKSrWsNu)
{
    double punsDZpOLXkX = -652035.5009788694;
    double FENrfaDxl = -354093.1889543592;

    for (int ZLsAHHBJPo = 1790522566; ZLsAHHBJPo > 0; ZLsAHHBJPo--) {
        euwYuvRsMTjYffBh += euwYuvRsMTjYffBh;
        euwYuvRsMTjYffBh = qWdupKSrWsNu;
        ItrDLnyroQtZZR = ItrDLnyroQtZZR;
        xfxAlaLUSZeov = ! jiUPUcIwl;
    }

    return FENrfaDxl;
}

bool UNjeAqSq::TMyReL()
{
    bool juRedLunwaL = true;
    int HBdugXlkJFQvf = -5551642;
    string qefjMBcMFWpz = string("iYHEOoHKYJxTQdnVhxPmpdNcFXMEQaMdrIWhgqHoBEiQZDEiRjoPXfXFZorsvWmpWRHopXXogeszUzZXfdktZceLrRVJUbqacNWTVkOahHQyeAClbYsquvlmfCDmLwbQkDjcDRVNIxTvpVXOnJbCkEjMcniKsmSgVZEICJeDBjxMDGlloWaMwuyWrFArHqTpJNYFRiBdqqexfcwqWGakFpl");
    string eJaXZFqMtyYjp = string("XEMGpFTgCLkSKxeivecysVtflyfbJqLlXEYQNEheMAbubGTCZGuvBomEVEEeHmXspyrGvklCxdssBqksgcIfBWLKrGCAvHGqzqISkLQOrlnXnNdAQSCkObb");

    if (eJaXZFqMtyYjp <= string("iYHEOoHKYJxTQdnVhxPmpdNcFXMEQaMdrIWhgqHoBEiQZDEiRjoPXfXFZorsvWmpWRHopXXogeszUzZXfdktZceLrRVJUbqacNWTVkOahHQyeAClbYsquvlmfCDmLwbQkDjcDRVNIxTvpVXOnJbCkEjMcniKsmSgVZEICJeDBjxMDGlloWaMwuyWrFArHqTpJNYFRiBdqqexfcwqWGakFpl")) {
        for (int BvaJtfDtdbVEHJCO = 247468705; BvaJtfDtdbVEHJCO > 0; BvaJtfDtdbVEHJCO--) {
            eJaXZFqMtyYjp += eJaXZFqMtyYjp;
            eJaXZFqMtyYjp += eJaXZFqMtyYjp;
        }
    }

    if (qefjMBcMFWpz >= string("iYHEOoHKYJxTQdnVhxPmpdNcFXMEQaMdrIWhgqHoBEiQZDEiRjoPXfXFZorsvWmpWRHopXXogeszUzZXfdktZceLrRVJUbqacNWTVkOahHQyeAClbYsquvlmfCDmLwbQkDjcDRVNIxTvpVXOnJbCkEjMcniKsmSgVZEICJeDBjxMDGlloWaMwuyWrFArHqTpJNYFRiBdqqexfcwqWGakFpl")) {
        for (int ygjCwV = 173790092; ygjCwV > 0; ygjCwV--) {
            juRedLunwaL = ! juRedLunwaL;
            HBdugXlkJFQvf -= HBdugXlkJFQvf;
            eJaXZFqMtyYjp += qefjMBcMFWpz;
        }
    }

    for (int fpXNUNufDS = 2001282619; fpXNUNufDS > 0; fpXNUNufDS--) {
        juRedLunwaL = ! juRedLunwaL;
        eJaXZFqMtyYjp += qefjMBcMFWpz;
        qefjMBcMFWpz = eJaXZFqMtyYjp;
    }

    if (eJaXZFqMtyYjp <= string("XEMGpFTgCLkSKxeivecysVtflyfbJqLlXEYQNEheMAbubGTCZGuvBomEVEEeHmXspyrGvklCxdssBqksgcIfBWLKrGCAvHGqzqISkLQOrlnXnNdAQSCkObb")) {
        for (int ghfrDca = 1209484394; ghfrDca > 0; ghfrDca--) {
            qefjMBcMFWpz = qefjMBcMFWpz;
        }
    }

    return juRedLunwaL;
}

bool UNjeAqSq::WECcSCwex(int oJEOEUWuuWkFXtU, double lRuwJlIylZcjwUG)
{
    bool oYcNG = false;

    if (oYcNG == false) {
        for (int jdagPIPiWD = 1284163396; jdagPIPiWD > 0; jdagPIPiWD--) {
            lRuwJlIylZcjwUG = lRuwJlIylZcjwUG;
        }
    }

    return oYcNG;
}

UNjeAqSq::UNjeAqSq()
{
    this->VtaxdbkyKS(false, 1800795598, -596053343, false, -144315660);
    this->TMyReL();
    this->WECcSCwex(-2058497099, 628591.4977619167);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pbmbCE
{
public:
    int ppCkC;
    bool QFRLPaqs;
    bool izDOBvRxDiyxpZ;
    string akSOZCPcbNKql;
    double afeDypK;
    bool CJZlolrOGIlB;

    pbmbCE();
    string fotKRwIvMIgnsf(double kikfEMPp);
    void RbIWuxufAPT(double MUSFRcOTWWmDAy);
    string jVzXtF(bool gSWXcMJDs, bool nGtwIGMzJi);
    string htCorFGhdVDD(int oSsMAeE, int JnGfVOYH);
    double XQXMPhMAF(double nrNCKG, bool nbLbddccieIVbui, bool lvihTujYeIG);
    double aKROqGopDBRj(int fpzwNBlXyHLDO, double cgNzd, int hBiHviULqgOLOJJm);
    double JTOlbZLzkcCM(int aoOJem);
    int uzqGZKdmTJ(int esaaTLCdily);
protected:
    int xSjKFyOnnd;

    int iShxRw();
private:
    string guKHmvwYE;
    double QUEGIyQ;
    string dBykjNiwsyCHF;
    int RgLlSvBOiqYTtU;
    int pnzSgVhWQsl;
    string jOkIRtRjNsvZ;

    void kRwuZtXkNqCa(bool MArQQpkseBU, string CKnMRI);
    string MsdlLwT(bool gSWGEEgyJrFV, int XVXSifkakWE, int etwrl, double AcOeVxUGn, double jtIhkgHICoFh);
    bool TBhAkp(bool rnKiWcwtD, bool lcHATVxDjp, double JqvEecDya);
    void rUzGmhFAtIdlM(bool YcUVSEZHLKjtE, string DTphSIGMbUXqEq, bool zuAnpOQLOR, bool rgqAHXrOKSvJ, bool vXGft);
    double OyUcMvHZ(bool MKbgEk, int EeMkihkhFWpUr, string ZRWvLPfwAYiP, double pVzSaivPIv, bool nuosGVfoUy);
    bool znSedZ(string qJqnaICdyD, double hPkZp, bool FPsDRuPNGmVYDTU, int KtJrXirNQy);
    string eCpaa(double PcPZLxxFr);
};

string pbmbCE::fotKRwIvMIgnsf(double kikfEMPp)
{
    string CyATQlLmND = string("BSfjcNgJNYNQWgJGsTtzpkWxQXuTFdvSOYXGUokNRUTDlWehwhFxmHqoQivdwfloCilcsBKxlYpsRWLijIwSlzaZkPtIFDkeayQgqpXWbkdVkEUnOgQoTrsnWhqaiMwHo");
    string arJlCLyEwjK = string("pXIrkTCPtDaEOkMMGrxgorGsZAzgZbqDKKpoe");

    for (int fgPddUedzAk = 1964118064; fgPddUedzAk > 0; fgPddUedzAk--) {
        CyATQlLmND = CyATQlLmND;
        CyATQlLmND += arJlCLyEwjK;
        CyATQlLmND += CyATQlLmND;
        CyATQlLmND = CyATQlLmND;
        arJlCLyEwjK += arJlCLyEwjK;
    }

    return arJlCLyEwjK;
}

void pbmbCE::RbIWuxufAPT(double MUSFRcOTWWmDAy)
{
    bool GFFatJH = false;
    double BVYNwozbFu = 1020312.234068659;
    bool jpKlg = true;
    double oLayjeZR = -379338.26146659267;
    string LkVlShwGffDZek = string("MSYGsralYPQKCAGtPVDUFooKHCKriLKZuWqHFrGWwLAmsnModvsThKhKQyxrhgWgRlepjPWlpEGBNJLJbwdPBhHXFvsEQocbcUyVHtOcBBvubtFnBShYWTBluxxRPntaAGenEDwXvwaYiJODUGvKcNYkvecAgFyGQfyNinFEmnvTMiIousNSLPdWkcatRUziJwSvKTlQzRNnlOBhmSfGIXmHmCKeROlrxWRkWgdPNnKfGcvknwoygbSfwJYX");
    int bvixCaFpT = -1237497755;
    bool lWzRZZbKGAKBWSHD = true;
    bool wqlyiEvLzD = false;

    if (BVYNwozbFu == -906558.8138458681) {
        for (int ScHNu = 234283835; ScHNu > 0; ScHNu--) {
            continue;
        }
    }

    if (jpKlg == false) {
        for (int DrHcZzPpkZiK = 222788690; DrHcZzPpkZiK > 0; DrHcZzPpkZiK--) {
            continue;
        }
    }

    for (int DPogFQamvxS = 2047665637; DPogFQamvxS > 0; DPogFQamvxS--) {
        lWzRZZbKGAKBWSHD = ! jpKlg;
        GFFatJH = ! jpKlg;
    }
}

string pbmbCE::jVzXtF(bool gSWXcMJDs, bool nGtwIGMzJi)
{
    int xwMVrRnk = -676390915;
    double zHhYgDQpsISqoWJ = 783675.4989218432;
    bool ogaqoSgEAFOU = false;
    double lDPGsqQWsP = -264639.8426401353;
    int SzUQReW = -2124723477;
    int tMXcsUjeoFoEFSF = 725583451;
    int YZqbSTTQSGW = 1584450080;
    bool liAGMstIVzHLvpG = true;
    int lPZANklyYkUW = 135094111;

    for (int UjGUSwyqrMuXyWA = 1094931342; UjGUSwyqrMuXyWA > 0; UjGUSwyqrMuXyWA--) {
        YZqbSTTQSGW /= lPZANklyYkUW;
    }

    for (int kMWRVZddcqcN = 1404068321; kMWRVZddcqcN > 0; kMWRVZddcqcN--) {
        SzUQReW /= SzUQReW;
        gSWXcMJDs = ! liAGMstIVzHLvpG;
        SzUQReW -= lPZANklyYkUW;
        SzUQReW /= SzUQReW;
    }

    for (int NEbNlWLBq = 2018664659; NEbNlWLBq > 0; NEbNlWLBq--) {
        SzUQReW /= xwMVrRnk;
    }

    if (YZqbSTTQSGW <= 135094111) {
        for (int YaxNnUwjFsXciw = 1134210261; YaxNnUwjFsXciw > 0; YaxNnUwjFsXciw--) {
            zHhYgDQpsISqoWJ -= lDPGsqQWsP;
            liAGMstIVzHLvpG = nGtwIGMzJi;
        }
    }

    if (lDPGsqQWsP > 783675.4989218432) {
        for (int gbDyRsU = 1145037205; gbDyRsU > 0; gbDyRsU--) {
            nGtwIGMzJi = nGtwIGMzJi;
        }
    }

    for (int ODsbho = 393909063; ODsbho > 0; ODsbho--) {
        nGtwIGMzJi = liAGMstIVzHLvpG;
        ogaqoSgEAFOU = ! liAGMstIVzHLvpG;
        xwMVrRnk /= YZqbSTTQSGW;
        tMXcsUjeoFoEFSF *= YZqbSTTQSGW;
    }

    return string("axkbqyBVqxiZvwzRiXvJwMmkGrTqKDtqlWfuntgiHEDCyCTHxFWjqVRXgYaCFpvWchRvYhjapMkIefRKGwnRDayBnzyFgBhDKvTVApecxDzcqBwKyslJITjccTGsmAAaAPsNXagyDsWujOvUUplQwBYbrNYGecQsLdhNCtKkEEAYTXpUVIHEYIsLdFdcQjt");
}

string pbmbCE::htCorFGhdVDD(int oSsMAeE, int JnGfVOYH)
{
    bool aSCwMmiXzZnVMDq = true;
    string DPWwmLMcga = string("fqbNyKoOPYxvRwHiBlxttBJDrQPZJOrWKJMYvAxzBWcUMTXVSTYjFigrLHLjDmJfnAirBAftPNpJGWUcHlWbJjYQcNzKdXNjWTYVdFdCuaKFQNqLL");
    int vLyUUEiC = 549354495;
    double SfGmdoyfAyF = -709037.4552990714;
    bool NtdCbYfiGgfPmZM = true;

    for (int UdemUC = 1457055310; UdemUC > 0; UdemUC--) {
        JnGfVOYH = vLyUUEiC;
        JnGfVOYH = vLyUUEiC;
        aSCwMmiXzZnVMDq = ! aSCwMmiXzZnVMDq;
    }

    return DPWwmLMcga;
}

double pbmbCE::XQXMPhMAF(double nrNCKG, bool nbLbddccieIVbui, bool lvihTujYeIG)
{
    double DJTSGYAxLrRahw = -347119.53821245197;
    bool gtEkceJKDmetR = true;
    double fdIfulYoiayYD = -43393.14293775763;
    string ldTJRXHb = string("DSSnyWzdMdRqsIQVfTXTuSxcSIwTtehvIfydnjpuWErEmTJWWAosKIWeDJfAhDxsrnHmcCrNHfGFBMDrrodSoxPUDknahlZKOV");
    bool fnZoNRobpc = true;
    bool aKCaGKgq = true;
    string vbCEQgEqAyMTZ = string("BNbmhAOqJKVpZJXVIyGRXlsYJEMECKlGMSfjqPDnMUVVKIGFvoERHaAfiqpgPNTXsQJorQglNEHiCkWxNCDvHNIzrMJvnOPhhTCScBSyYdgWziiTOaQHsaBsbGExDCmfrMVANkyrKpiXeWuvfGeVPJvCc");
    string oXbeCbzHDJz = string("yJCgpiXdJGBOsyOXc");
    int DdBPyyZCWNcrCH = 1685629745;
    string cRUVYQTbxM = string("PFdHAByYiFPPlGKHEbVrIxwWNtQkWkjmzBKrOEFEqeEHlrphpUuPtTLROayduUDwujPeRKypbDScYbxGRkPLmJkWLQqHYeCfrtfbYoftJLzKrnnIjlejwAdSoOuthrDsZKQbWGHMKbgUXDGVlKxDQIgUxcFqQOvXpffkuRMNfeuNQVMcvEhCanfLcgaJDpRtKadduHDbNrqjoqkqGWCPCvDILXj");

    for (int YpWsgrBgUTJD = 1653500366; YpWsgrBgUTJD > 0; YpWsgrBgUTJD--) {
        DJTSGYAxLrRahw *= DJTSGYAxLrRahw;
    }

    for (int AbGfRY = 1651689054; AbGfRY > 0; AbGfRY--) {
        oXbeCbzHDJz += vbCEQgEqAyMTZ;
    }

    for (int tXXrTlQ = 2071408627; tXXrTlQ > 0; tXXrTlQ--) {
        gtEkceJKDmetR = aKCaGKgq;
    }

    for (int MSMiMScvVtHPuhJ = 2133642798; MSMiMScvVtHPuhJ > 0; MSMiMScvVtHPuhJ--) {
        nbLbddccieIVbui = nbLbddccieIVbui;
        ldTJRXHb += ldTJRXHb;
    }

    return fdIfulYoiayYD;
}

double pbmbCE::aKROqGopDBRj(int fpzwNBlXyHLDO, double cgNzd, int hBiHviULqgOLOJJm)
{
    double IjyVTkGIUGwfY = 293687.9844233438;
    double jMFsjWLKbHRi = -513369.20009413874;
    bool ZtjLiMbNHvZN = false;

    for (int EuJczi = 1854552089; EuJczi > 0; EuJczi--) {
        fpzwNBlXyHLDO += hBiHviULqgOLOJJm;
        hBiHviULqgOLOJJm -= hBiHviULqgOLOJJm;
        cgNzd -= cgNzd;
        hBiHviULqgOLOJJm *= fpzwNBlXyHLDO;
    }

    for (int JxiiPbtb = 194332260; JxiiPbtb > 0; JxiiPbtb--) {
        cgNzd /= IjyVTkGIUGwfY;
    }

    for (int jWWhmoFzYBVu = 1843322988; jWWhmoFzYBVu > 0; jWWhmoFzYBVu--) {
        continue;
    }

    if (jMFsjWLKbHRi == -290216.96909796377) {
        for (int nJhPnbl = 376934346; nJhPnbl > 0; nJhPnbl--) {
            hBiHviULqgOLOJJm /= fpzwNBlXyHLDO;
            IjyVTkGIUGwfY = cgNzd;
            IjyVTkGIUGwfY *= IjyVTkGIUGwfY;
        }
    }

    for (int MVeDAzkEiqslZlh = 1349996078; MVeDAzkEiqslZlh > 0; MVeDAzkEiqslZlh--) {
        hBiHviULqgOLOJJm /= hBiHviULqgOLOJJm;
        cgNzd = IjyVTkGIUGwfY;
        IjyVTkGIUGwfY += IjyVTkGIUGwfY;
    }

    return jMFsjWLKbHRi;
}

double pbmbCE::JTOlbZLzkcCM(int aoOJem)
{
    string YvdBOSsfhT = string("NvPckSqNcNfktXMaoPvzCgdXAUanTiPmPsZNDIRimItPmthwDHLlzOLZarigWxpqNxelxmbTYuMGAbKdjhhtCaoTOzwULnXxhDjhqDoZspCloDpapxWZUpfXJaaYdUGNXjVVLdXsjBwEpozFeEkCXomIyXuvYAiSaOhXkQCGwEnbJFSLjgvEBxXpJFOtterVvVExIsinvsafnMqsYHIfApOwwNDObheIkYdDcFckBnMdTSKN");
    double IMbixEVxRaEHx = -1018734.3935116327;
    int KNzWO = 1362179411;
    bool tgQDfakrWI = false;
    string zsrlbVKCbpSesdgd = string("PiBRbswBrpHWqQBlIoOrriHMOBIozTRjL");
    int KZJKTqf = -1580332155;

    if (KNzWO >= -1580332155) {
        for (int CLLylfKv = 313521292; CLLylfKv > 0; CLLylfKv--) {
            aoOJem += KZJKTqf;
            KZJKTqf *= KNzWO;
        }
    }

    if (aoOJem <= 1362179411) {
        for (int PcfPeFqaBaW = 1433187939; PcfPeFqaBaW > 0; PcfPeFqaBaW--) {
            continue;
        }
    }

    return IMbixEVxRaEHx;
}

int pbmbCE::uzqGZKdmTJ(int esaaTLCdily)
{
    int wNuVGhKndRLO = 1640605019;

    return wNuVGhKndRLO;
}

int pbmbCE::iShxRw()
{
    double KRBIUcIhQV = 795431.6500267166;
    int YWQeUiNgTyAnnT = -193936697;
    bool Xgfvt = true;
    string BtwKliZ = string("WzTTYTELYIIQPMcKlTYRQpPBFHIuBzQySzAgfBBpZscscopvXURgrREyAxRgkGfOhVkrhaiZZxXoHCVNZFUgGpuKRTVXNkPTtmZXqunQcDoSTQSdYwnupXPAJw");
    bool AebWIylbZps = true;

    for (int FCnuG = 868840210; FCnuG > 0; FCnuG--) {
        continue;
    }

    for (int diCMgRriBfdMmTR = 1504295257; diCMgRriBfdMmTR > 0; diCMgRriBfdMmTR--) {
        Xgfvt = ! Xgfvt;
        Xgfvt = Xgfvt;
        Xgfvt = ! AebWIylbZps;
    }

    for (int IbBRaF = 1390257782; IbBRaF > 0; IbBRaF--) {
        BtwKliZ = BtwKliZ;
        BtwKliZ = BtwKliZ;
        Xgfvt = AebWIylbZps;
        BtwKliZ = BtwKliZ;
    }

    return YWQeUiNgTyAnnT;
}

void pbmbCE::kRwuZtXkNqCa(bool MArQQpkseBU, string CKnMRI)
{
    bool HRErjZ = true;
    int gNkUFLySuLNzOEC = 58461465;
    int MbtHJXXOnV = -106157409;
    string YNuCd = string("IBRTgwvBKrKOsGKWEqJFQZinWqiAbESfIHsXVyorYHoYsewhidLFgRnOkYmVIetWgggIoIduLsroeUDiTkslDxsxRZPghVEtThoFCihEKwwvzNOANhwzoDTcAFfjYrLiVfTHSQmtBbLxXWkKjCofIHzhepHzjSKt");
    string PuxYWFpzdSmZBg = string("zorFcQwqOFVyMniGOlfHvgbKSgiUtAlzfxHFifOfHJiTCpfRkcXgIOZNjpkvuqvpffRCCCzvHZRCVfFsyMMdPyIeEAOfHhFRfxzNQszyS");
    int ZxSrJEKYJs = -1062544485;
    bool PMToI = false;

    for (int lRPyVAqLRg = 352000649; lRPyVAqLRg > 0; lRPyVAqLRg--) {
        PuxYWFpzdSmZBg += CKnMRI;
        gNkUFLySuLNzOEC *= ZxSrJEKYJs;
    }
}

string pbmbCE::MsdlLwT(bool gSWGEEgyJrFV, int XVXSifkakWE, int etwrl, double AcOeVxUGn, double jtIhkgHICoFh)
{
    int LghGHWNcIrQyUvBQ = 440642220;
    bool pKOvxhlUWTwbH = false;

    for (int aUAuDJlpUjdLPAD = 56894254; aUAuDJlpUjdLPAD > 0; aUAuDJlpUjdLPAD--) {
        XVXSifkakWE += XVXSifkakWE;
        gSWGEEgyJrFV = ! gSWGEEgyJrFV;
        jtIhkgHICoFh = AcOeVxUGn;
        jtIhkgHICoFh /= AcOeVxUGn;
    }

    for (int yKsgbkffDnWSCOc = 708670136; yKsgbkffDnWSCOc > 0; yKsgbkffDnWSCOc--) {
        AcOeVxUGn += jtIhkgHICoFh;
    }

    for (int sQTPuUxZReItywRk = 1107042717; sQTPuUxZReItywRk > 0; sQTPuUxZReItywRk--) {
        jtIhkgHICoFh /= AcOeVxUGn;
        LghGHWNcIrQyUvBQ += XVXSifkakWE;
        etwrl -= etwrl;
    }

    if (AcOeVxUGn < -955565.2855836) {
        for (int xlzXwfDnA = 1408930900; xlzXwfDnA > 0; xlzXwfDnA--) {
            continue;
        }
    }

    if (LghGHWNcIrQyUvBQ > 440642220) {
        for (int DZPdYRq = 768036935; DZPdYRq > 0; DZPdYRq--) {
            AcOeVxUGn *= AcOeVxUGn;
            XVXSifkakWE -= LghGHWNcIrQyUvBQ;
            LghGHWNcIrQyUvBQ -= etwrl;
        }
    }

    return string("GsoNwReJcNTrPpVpvjLMTQPFCNHVKvWJGbSFzWSbYCiLF");
}

bool pbmbCE::TBhAkp(bool rnKiWcwtD, bool lcHATVxDjp, double JqvEecDya)
{
    string lwUYJiGeFmMy = string("OYBWFTCodKAqjIaMhVQEnaHuxhb");

    for (int SByaM = 1816790243; SByaM > 0; SByaM--) {
        rnKiWcwtD = ! lcHATVxDjp;
        lcHATVxDjp = ! rnKiWcwtD;
        lwUYJiGeFmMy = lwUYJiGeFmMy;
    }

    for (int KtgxPcSEVFW = 377716699; KtgxPcSEVFW > 0; KtgxPcSEVFW--) {
        lwUYJiGeFmMy = lwUYJiGeFmMy;
        rnKiWcwtD = rnKiWcwtD;
        JqvEecDya += JqvEecDya;
    }

    for (int lGfhSuYTJZFfzn = 284657757; lGfhSuYTJZFfzn > 0; lGfhSuYTJZFfzn--) {
        continue;
    }

    return lcHATVxDjp;
}

void pbmbCE::rUzGmhFAtIdlM(bool YcUVSEZHLKjtE, string DTphSIGMbUXqEq, bool zuAnpOQLOR, bool rgqAHXrOKSvJ, bool vXGft)
{
    int DOCdEuIeIEiPY = -1077597263;
    int ATiCfU = -706282810;
    string JmwEpIPibscnEOx = string("TEMbYqZsCYTmyLASHBslLjeZySyjGCunXHVIgmSRmUYVfGdbnqTkvqLqJdKjTIEYVhQGyEbTSaiPbxHSLeiJlJjJivSakrxssWkCjfWerbEqzDLyPixKjKQDPVurtvOHPNbxbwFDxnFAqlaTfhFOlvoONLv");
    int zGGgNcaUZoax = -1231784597;
    double docLrX = -511883.77938650065;
    double eTCpLNJuJeTyp = -650179.1906161095;
    double BpvetxEbDF = -2284.5939097443265;
}

double pbmbCE::OyUcMvHZ(bool MKbgEk, int EeMkihkhFWpUr, string ZRWvLPfwAYiP, double pVzSaivPIv, bool nuosGVfoUy)
{
    int dLDhk = -718198458;
    string rdwHVaC = string("pzhfHUUWuIkUeDBpMOMUEtHeXrAcUQGSHygcBbNewTiOJmefWZYZNtYRTICycvxQSGtGUyuPSEYIPLTCIrYqMTAKVXPAuQLeoMYrFoETWJwoONbCTVvVXVzAFQcDvFGumSSxZHTHlhuAXctHQRAAiVxBrIgbnJGFQuXfBrwMHIMveYVBOgynYEzPOlVoCBIBikjpSPJntoJIMZrNShUzTOvIv");
    bool pwdRVtcQ = false;

    if (ZRWvLPfwAYiP != string("pzhfHUUWuIkUeDBpMOMUEtHeXrAcUQGSHygcBbNewTiOJmefWZYZNtYRTICycvxQSGtGUyuPSEYIPLTCIrYqMTAKVXPAuQLeoMYrFoETWJwoONbCTVvVXVzAFQcDvFGumSSxZHTHlhuAXctHQRAAiVxBrIgbnJGFQuXfBrwMHIMveYVBOgynYEzPOlVoCBIBikjpSPJntoJIMZrNShUzTOvIv")) {
        for (int Eqeiz = 480664317; Eqeiz > 0; Eqeiz--) {
            continue;
        }
    }

    for (int yynzH = 868232209; yynzH > 0; yynzH--) {
        rdwHVaC += ZRWvLPfwAYiP;
    }

    for (int VRveICnZdOQiqo = 103006065; VRveICnZdOQiqo > 0; VRveICnZdOQiqo--) {
        nuosGVfoUy = MKbgEk;
        nuosGVfoUy = pwdRVtcQ;
    }

    return pVzSaivPIv;
}

bool pbmbCE::znSedZ(string qJqnaICdyD, double hPkZp, bool FPsDRuPNGmVYDTU, int KtJrXirNQy)
{
    double xVXNRDNnJAIbqh = -1019781.3879476575;
    double WYBdRYkSTHhv = 245348.53533758764;

    for (int hPBTIuNFC = 528205768; hPBTIuNFC > 0; hPBTIuNFC--) {
        FPsDRuPNGmVYDTU = ! FPsDRuPNGmVYDTU;
        hPkZp = hPkZp;
    }

    if (KtJrXirNQy != -550849327) {
        for (int GpDIOmHTUeWqhwZ = 65044586; GpDIOmHTUeWqhwZ > 0; GpDIOmHTUeWqhwZ--) {
            xVXNRDNnJAIbqh -= WYBdRYkSTHhv;
        }
    }

    for (int vFuFP = 1743443109; vFuFP > 0; vFuFP--) {
        hPkZp /= hPkZp;
        WYBdRYkSTHhv /= WYBdRYkSTHhv;
        qJqnaICdyD = qJqnaICdyD;
        hPkZp -= WYBdRYkSTHhv;
        hPkZp /= xVXNRDNnJAIbqh;
    }

    return FPsDRuPNGmVYDTU;
}

string pbmbCE::eCpaa(double PcPZLxxFr)
{
    double YorUT = 221859.74493881242;
    bool fNGrDQq = true;
    int fKBzEg = 987847150;
    string yJRoGQC = string("YtfHaRvdbOxbOgkZxabCQHPJmSwKXTzjJKMWarjpsSgwygTvLLZwGXAhGRvJHFAQDubkXmVfVFKPkgGixDXRpXgLcx");
    string VFcTaNNPPCpQDxl = string("DDrdwmBZvfLQDxaJrrGdIourxNXWSoyzhZfXNJVopaJBnFakcgOCBOYsrzAuPsHVeWSAWlfXtCIdYMtdbojRvG");

    for (int lsAsO = 1039496202; lsAsO > 0; lsAsO--) {
        VFcTaNNPPCpQDxl += VFcTaNNPPCpQDxl;
        yJRoGQC += VFcTaNNPPCpQDxl;
        fNGrDQq = ! fNGrDQq;
    }

    for (int XbIRcuFH = 827197006; XbIRcuFH > 0; XbIRcuFH--) {
        fNGrDQq = ! fNGrDQq;
    }

    for (int yxiiPSKsyVwIxWX = 988502284; yxiiPSKsyVwIxWX > 0; yxiiPSKsyVwIxWX--) {
        continue;
    }

    for (int BXSQmlisaPPQUe = 554347913; BXSQmlisaPPQUe > 0; BXSQmlisaPPQUe--) {
        yJRoGQC += yJRoGQC;
    }

    if (VFcTaNNPPCpQDxl < string("YtfHaRvdbOxbOgkZxabCQHPJmSwKXTzjJKMWarjpsSgwygTvLLZwGXAhGRvJHFAQDubkXmVfVFKPkgGixDXRpXgLcx")) {
        for (int FYTCuoUfFG = 16632641; FYTCuoUfFG > 0; FYTCuoUfFG--) {
            YorUT -= YorUT;
            VFcTaNNPPCpQDxl += VFcTaNNPPCpQDxl;
            yJRoGQC = VFcTaNNPPCpQDxl;
        }
    }

    for (int JqljLGBlExpir = 575840074; JqljLGBlExpir > 0; JqljLGBlExpir--) {
        continue;
    }

    return VFcTaNNPPCpQDxl;
}

pbmbCE::pbmbCE()
{
    this->fotKRwIvMIgnsf(1003727.8846055663);
    this->RbIWuxufAPT(-906558.8138458681);
    this->jVzXtF(true, false);
    this->htCorFGhdVDD(19031558, 251608344);
    this->XQXMPhMAF(563774.0702514921, false, false);
    this->aKROqGopDBRj(-384025217, -290216.96909796377, -116942746);
    this->JTOlbZLzkcCM(1518175632);
    this->uzqGZKdmTJ(366944762);
    this->iShxRw();
    this->kRwuZtXkNqCa(false, string("PJkpxzFtMZWALRymkhYYdrvIMVxQGaJhPblllePzGRaPUWpKlItxXKMMLfYcYsidhSITeNNFMudgseukpzptTldRdybAfeZwKutzTaahlMNMvmqqFgBfqNRxZRyErPxywtxWMHkdKyUypWgBupqskYMeAdjecSJG"));
    this->MsdlLwT(true, 3932654, 687458048, 60868.07307574015, -955565.2855836);
    this->TBhAkp(true, true, -873529.0083485441);
    this->rUzGmhFAtIdlM(true, string("oaDIItcPCQRYAbqrxQoLPbVpeWOmKhFjzntsNdOSYhSLLQaaSKFxDzpQAmpUjBCioufMrBZxBwvCCxTAOpjCGliIhr"), true, false, true);
    this->OyUcMvHZ(true, -976053905, string("gisvolgCknXLnDmVfsDLVyhriEMlIUUZhMgonSNlfKIuEdnlvWOqXxVGREYhnzknyScCchDRzCFS"), -417653.8441125395, false);
    this->znSedZ(string("THaKIEJmbnuHUjhQrwrGZrQYYvsQniNCeukMixuozAletUTFEluXEjFAYIMtWDRsxkVeMniBhukMXVXrSHwPAlTdHPcUUjhTsvbJFfHVPAMobddVUmMIKGdYYlanHGZeFfrcRRCEF"), 15998.903187083197, true, -550849327);
    this->eCpaa(-640547.8902711981);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oiRZiiZ
{
public:
    double tjgQmE;
    int gKYItEARgjuFmDyh;

    oiRZiiZ();
    void KjhVnXoYppfxC(double CPUhAfJwPyigugg, string SkgaCzYFKI);
    string CVHzGuYUmMIKTUoE(string ZuPhwkryQr, bool JtchAqgrJpPfmRH, double asHmiqFr, double wqsmQ, bool WTGhWnUVjcsQy);
    string yXPnZrcOREW(string EIMZcttmb, bool gHypmASE);
    void gRPLoseIoEoJTf(double XPtyQjA, bool dQImRjZQXmQV, bool kuAzuOs);
protected:
    bool aUfJiA;
    double hlYpHHfGoe;
    string hZpUsyi;

    void cjjmiBCFYGD();
    int flTCwK(int CqyeSCkohvYmP, double AAhNmnjLJTbAH);
    string HQtFeEcWbIiYebGH(double zZoJOYcUtABWoCR, bool WdcvKNRM, bool VarrpnfVsczk, string ZfVnZeH);
    string FPSrrIelMoKTUycm(string WCiwV, bool xFMPZoVTMpM, int lpqnQDWP);
private:
    int JWmll;
    string iyuDIVCrBogIALmy;

    int ABXubrrQpbcu(string zQZsCm);
    bool XvvuDAHe(int ccZotUiklw, bool zPNqPi, string AicGzReBVJjbqh, string JGTNOtm, int BjmhrkCZqLU);
    void FgAtZyDxTSnXr(string byixEhewPcNAVq, bool BKXbN, string lULuYDBlCzfMmTnZ, string SgPkKQDX);
};

void oiRZiiZ::KjhVnXoYppfxC(double CPUhAfJwPyigugg, string SkgaCzYFKI)
{
    bool mZIvUHbmVl = false;
    double tXFqxhdcmxBJ = 791329.6692023868;
    double HseNRuFULNEH = 329915.86633035063;

    for (int uipUIujDWLT = 825823276; uipUIujDWLT > 0; uipUIujDWLT--) {
        continue;
    }

    for (int SfsgQKHvIff = 1971340570; SfsgQKHvIff > 0; SfsgQKHvIff--) {
        HseNRuFULNEH = HseNRuFULNEH;
        tXFqxhdcmxBJ += tXFqxhdcmxBJ;
    }
}

string oiRZiiZ::CVHzGuYUmMIKTUoE(string ZuPhwkryQr, bool JtchAqgrJpPfmRH, double asHmiqFr, double wqsmQ, bool WTGhWnUVjcsQy)
{
    int NYlvxYFhqOYgYDG = -84003995;

    for (int PqgsKfjyVkzJtYE = 160199781; PqgsKfjyVkzJtYE > 0; PqgsKfjyVkzJtYE--) {
        asHmiqFr -= asHmiqFr;
        wqsmQ -= asHmiqFr;
    }

    if (asHmiqFr <= 292388.71848842705) {
        for (int bcrmMvJGrHWXp = 210671103; bcrmMvJGrHWXp > 0; bcrmMvJGrHWXp--) {
            asHmiqFr -= wqsmQ;
        }
    }

    for (int FduATd = 1639748064; FduATd > 0; FduATd--) {
        NYlvxYFhqOYgYDG *= NYlvxYFhqOYgYDG;
        NYlvxYFhqOYgYDG *= NYlvxYFhqOYgYDG;
        wqsmQ += asHmiqFr;
    }

    return ZuPhwkryQr;
}

string oiRZiiZ::yXPnZrcOREW(string EIMZcttmb, bool gHypmASE)
{
    int SdIOtfwSGyChkST = 667722031;
    bool LIIAKGgI = true;
    int cMXFPCfLBgBH = -595290541;
    int aSfFOR = -2035459634;

    if (SdIOtfwSGyChkST < -2035459634) {
        for (int Dntlj = 1533287141; Dntlj > 0; Dntlj--) {
            gHypmASE = ! LIIAKGgI;
            SdIOtfwSGyChkST *= aSfFOR;
        }
    }

    return EIMZcttmb;
}

void oiRZiiZ::gRPLoseIoEoJTf(double XPtyQjA, bool dQImRjZQXmQV, bool kuAzuOs)
{
    int gsEeTbD = -1841974661;
    double EbnYKMOcEoEIYgbu = 124495.04288608833;
    int TAjGPScjNJ = -1179311120;
    string WEvVfWsxwEUs = string("lKGBKGOSISAdSqsKBlJzEtcKJtiQKXsRIOomjfORjZFZWOYXyiaRcjcjmDegaxBAlLduQzUYgygghtqtJNphevjArpvWGvJXibiAowVwRYmCXmDIWxrxX");
    string GOkyVROUiKgC = string("jIqMrmhJWJMjrSkMeYlumDobiwfDjicUuLUktjPdNAVWlobctcOSoJXrkgWcRJQqourSIzXssUiCNuUhDVcsyIYbNvmBPcxFpfsvgAaNPLfyWmLrFUMICigwmmLwCpAqfqGp");
    string abHfh = string("OtAtoNorNsksmRdFNNmpTSfaNpIiEjnQFnTmFishMvHWYqvPKUVSnBIDdsCvrfzIrCsLKeopuBXRuKOHvBbeDohbVKFkRKsjoqPOXDenirCtwlJdRFmkVjBTVxRyXy");
    string ymOCI = string("oxSNTHHjIJzFzBuKdQPYdXFwCWsfcvuKqGxWfRnBSmzYcaucxipgmEwLhJpesPfphAKNIYiTIjjsetYsnQSuIrSxodnrApyXEqJdHBfgNSGWhBcWOtnOStiBnXbuVThrXJDKAzLneaddN");
    string VwmOhzOOqTXjGy = string("uFtHzYCHjsvIon");
    string HGecxrMuHa = string("KsWZXcbfPZWEyLCYDUgRBDQwJEwzqkGERHNGokIawJSSeMJMAMyVQPGSkTqnOLoLsBTzunLhIIwBONqUqjfvHsOrVjjXJjLtNy");
    bool NLwHlNWtksaYIrje = true;

    for (int SrJIzAopCKKUVI = 490543122; SrJIzAopCKKUVI > 0; SrJIzAopCKKUVI--) {
        NLwHlNWtksaYIrje = ! kuAzuOs;
    }

    for (int nzTKzBFUBDgo = 89110533; nzTKzBFUBDgo > 0; nzTKzBFUBDgo--) {
        EbnYKMOcEoEIYgbu /= XPtyQjA;
    }

    for (int KOHSJzG = 2034878833; KOHSJzG > 0; KOHSJzG--) {
        gsEeTbD -= TAjGPScjNJ;
        abHfh += GOkyVROUiKgC;
        ymOCI = WEvVfWsxwEUs;
    }
}

void oiRZiiZ::cjjmiBCFYGD()
{
    string FUkUCrB = string("GnnZUElxwzfMfkpITPQZGKKEbLaHWriZxvjbmJLzcE");
    string vKCEJsjuezmxrp = string("nnuZOftjlxYXFNpkFlEPHqbRbPCIwzqnqxwDunAYRntMUqdORZwJWyGowvIlLnRyDmbKYmnmdzZRONmviqcImBrLdSyGdaATYWFyfFVCypNaKqwMnAODRMqPARhqwPXObUGqMgnKXJatVpQoyryohjXPuAVC");
    string lxznoEBWUmdut = string("VmeGLYPtiooHFZfSdzEKBNMAezPksaqEOorClGVqfzsIDQdenLPhOpaUmxOfUJzpTFCgsYJJjVNsGixDGhDFLVCDijJbEFfnXchAcGUnC");
    double hGgGSYkf = -601096.9415185548;
    int cGwIlxuknMbVTtl = -99103776;
    bool OFEcdvFkUhOl = true;
    string NahLIBoekRbbilLY = string("GLRrvVUeNlMtNRSWnILMXNoZAkeNvbQdnkdphbhwPZepzIatJLBcBGnQDRotrXlsktLtOigrFFAmLhsdFsSbUjlvdGbwGWRgiikKLEYhOVJzpXzkmaukeJFVwLohPYwNiwYGlznhfJPtsdCaREjXmVpyvxebHcyMPmXoOiFAOmHIiKdAaEISzQJvLhBXyzLtaIUvTdOyEDObwDepqkcFySMXQKljJMeGxcmnBiqXTF");

    for (int lfTDCWQvKgqNPde = 1580682850; lfTDCWQvKgqNPde > 0; lfTDCWQvKgqNPde--) {
        FUkUCrB = vKCEJsjuezmxrp;
    }

    if (vKCEJsjuezmxrp == string("GLRrvVUeNlMtNRSWnILMXNoZAkeNvbQdnkdphbhwPZepzIatJLBcBGnQDRotrXlsktLtOigrFFAmLhsdFsSbUjlvdGbwGWRgiikKLEYhOVJzpXzkmaukeJFVwLohPYwNiwYGlznhfJPtsdCaREjXmVpyvxebHcyMPmXoOiFAOmHIiKdAaEISzQJvLhBXyzLtaIUvTdOyEDObwDepqkcFySMXQKljJMeGxcmnBiqXTF")) {
        for (int qlMQFQs = 217806400; qlMQFQs > 0; qlMQFQs--) {
            FUkUCrB = lxznoEBWUmdut;
        }
    }

    for (int undHlFEydHEZzeUt = 452401655; undHlFEydHEZzeUt > 0; undHlFEydHEZzeUt--) {
        FUkUCrB = FUkUCrB;
        lxznoEBWUmdut = lxznoEBWUmdut;
        vKCEJsjuezmxrp += FUkUCrB;
        lxznoEBWUmdut = lxznoEBWUmdut;
        vKCEJsjuezmxrp += vKCEJsjuezmxrp;
        vKCEJsjuezmxrp += NahLIBoekRbbilLY;
    }

    for (int vYwKsgRlfvWQYfZQ = 591570087; vYwKsgRlfvWQYfZQ > 0; vYwKsgRlfvWQYfZQ--) {
        lxznoEBWUmdut = vKCEJsjuezmxrp;
        NahLIBoekRbbilLY = FUkUCrB;
    }
}

int oiRZiiZ::flTCwK(int CqyeSCkohvYmP, double AAhNmnjLJTbAH)
{
    bool CWlTfD = true;
    double kjLBtoEtMEQGJJt = 94833.16027020184;
    int fGUoDBGrNpCQxI = -891435308;
    bool pJaVZGjLpjlSSGE = false;
    string eESEOIHatsW = string("swJiXUivVgAxLxpeFTASHYqioONcaJhOhkMYahLsFmqaWcFCIRtXeQgeQrrfRPJJZMEjEeiVwedPBbXcRHkRyNBvPbWQcQuOjQTtimagLeaHpQlTGNOtXAKBEpVizfFlxblIJRTkXzhtJoqkXXPVSxWAAuccFjkRNGaGvlvRQPUfdOolmfWwDSTfYzVWiuxkNdMSNHbPYhrfYgTrbBsapAPWzKTfHjhDQLKgohhGviGZqqCgRzITW");
    double rYfcRDQXNRbQJZ = -514758.43107602815;
    string exqpuGCZCSCvcLVZ = string("yJNshjPFamdmswfZxxyOXLIDPQdEWOzOfYDDafJUqvTCzqjjRpupPwASzZHiuTxRryIyjejvjGdEHIuQSifjZmncCivwSioysanaHFBLEGYcaQylbjsAQCxjLWpEqVvyDyjWWlXLZkGdwovWQyGb");
    int fcIsjNp = -288857753;
    int IKcLzCshf = 1974776453;
    int MXvfJSvJztq = -1293059255;

    if (IKcLzCshf != -288857753) {
        for (int hUYNTc = 907657466; hUYNTc > 0; hUYNTc--) {
            fGUoDBGrNpCQxI = MXvfJSvJztq;
            pJaVZGjLpjlSSGE = pJaVZGjLpjlSSGE;
            rYfcRDQXNRbQJZ -= rYfcRDQXNRbQJZ;
        }
    }

    for (int Akpwm = 68512013; Akpwm > 0; Akpwm--) {
        eESEOIHatsW += exqpuGCZCSCvcLVZ;
    }

    return MXvfJSvJztq;
}

string oiRZiiZ::HQtFeEcWbIiYebGH(double zZoJOYcUtABWoCR, bool WdcvKNRM, bool VarrpnfVsczk, string ZfVnZeH)
{
    bool SKycLacxqShUAf = false;
    double FfLVZ = 735458.502161475;
    bool TvGWGRNvq = false;
    string rgzHbGf = string("fVCcseVqlrLZVqYqTMwVUPcHudQFSfnBrqS");
    int vxSpDpFbABXSM = 1951905708;
    int UIghWb = -859316243;
    bool BZcFmnhNhgEfkd = true;
    double DGLlhqN = -838493.8945337348;

    if (ZfVnZeH == string("fVCcseVqlrLZVqYqTMwVUPcHudQFSfnBrqS")) {
        for (int VShbBR = 327179581; VShbBR > 0; VShbBR--) {
            WdcvKNRM = WdcvKNRM;
            ZfVnZeH += ZfVnZeH;
            BZcFmnhNhgEfkd = SKycLacxqShUAf;
        }
    }

    for (int xVffFNtoVMq = 2036959076; xVffFNtoVMq > 0; xVffFNtoVMq--) {
        zZoJOYcUtABWoCR += DGLlhqN;
        WdcvKNRM = ! SKycLacxqShUAf;
        WdcvKNRM = TvGWGRNvq;
        ZfVnZeH = rgzHbGf;
        FfLVZ = FfLVZ;
        zZoJOYcUtABWoCR = DGLlhqN;
    }

    return rgzHbGf;
}

string oiRZiiZ::FPSrrIelMoKTUycm(string WCiwV, bool xFMPZoVTMpM, int lpqnQDWP)
{
    double UMyqgaAHocL = -446964.6953353408;
    bool DzIYHq = false;
    string vwzImBUEZvTIao = string("AJWnuvJstTATzAzGtIaTQHFtikysBNYwWeWdgFXFhWPPfYuuQVLbmQyHqupZJshPwwxdxzPRMrUXBQoDSocgWigVYpupTBNxeOAOxGpaBhNiMVtIZDwvxlAvW");
    bool bpuznvqQMasponPr = false;
    bool sLnGRp = true;

    for (int TQSNqdPMrlKNS = 1722322234; TQSNqdPMrlKNS > 0; TQSNqdPMrlKNS--) {
        continue;
    }

    return vwzImBUEZvTIao;
}

int oiRZiiZ::ABXubrrQpbcu(string zQZsCm)
{
    string GXAOdiuWpBsl = string("BCIDMRuxFhREOWcFeAfPHWMYhYVLZgXDNcMvCnWdTTwGHmfczUbRSLtBTkaxdTeHULScpBZQxddCtKAOabVyuvHoRhzWkNlQnxldarxDvHJpMchQKX");
    string yRIUIBwPSAh = string("YnTdKqRgyVRPTmASwwOVvTkupjDaVfgsXhJdepZHjxlXlrjpLhsSsvrJAurYaAiNxyYDDolxdN");
    int oUumsYihDTjlcMDW = -985606261;
    bool grcsJ = true;

    for (int ZBqdp = 1484036978; ZBqdp > 0; ZBqdp--) {
        zQZsCm += GXAOdiuWpBsl;
        zQZsCm = yRIUIBwPSAh;
        GXAOdiuWpBsl = yRIUIBwPSAh;
        yRIUIBwPSAh = yRIUIBwPSAh;
        grcsJ = ! grcsJ;
        zQZsCm = yRIUIBwPSAh;
    }

    return oUumsYihDTjlcMDW;
}

bool oiRZiiZ::XvvuDAHe(int ccZotUiklw, bool zPNqPi, string AicGzReBVJjbqh, string JGTNOtm, int BjmhrkCZqLU)
{
    string KknWFEaW = string("iwrnjbBDJSUmfWBnWLKChjwvfYWnDZxKnSnqyFfALlsGkKhfOdeALvWoAeokkwQXtytffYBcWAeqpzZYvzrodKzkqFrUHWLcEePmFuavXkHwRRrSYEVipBzwCngZuYyiKjmUSYFdUPcDuPbcbmiAWoAuQlSBdFeFJs");
    string dwsJqvVTOunA = string("WwCuhsbCOiUACTQspRSXcRWqjSecccAaAayyjcgfCOfuZHRkrLWkcmUXgtNAlMMZzDzLnMXpwpMdUNCzdMrZQwZJqrhNZggomBqokYTWTkhHhPBuXLCtAoOpWwOFuaoUAVeKEOISFTcoFnciQMcQYeYCXaKYuLZdGYykgERtFpVXnFKVkeyOLpWbddIbUHC");
    string HWIhRY = string("XwcEXltfN");

    if (AicGzReBVJjbqh == string("WwCuhsbCOiUACTQspRSXcRWqjSecccAaAayyjcgfCOfuZHRkrLWkcmUXgtNAlMMZzDzLnMXpwpMdUNCzdMrZQwZJqrhNZggomBqokYTWTkhHhPBuXLCtAoOpWwOFuaoUAVeKEOISFTcoFnciQMcQYeYCXaKYuLZdGYykgERtFpVXnFKVkeyOLpWbddIbUHC")) {
        for (int gQCUq = 1812660182; gQCUq > 0; gQCUq--) {
            dwsJqvVTOunA += JGTNOtm;
            zPNqPi = zPNqPi;
            KknWFEaW += dwsJqvVTOunA;
        }
    }

    return zPNqPi;
}

void oiRZiiZ::FgAtZyDxTSnXr(string byixEhewPcNAVq, bool BKXbN, string lULuYDBlCzfMmTnZ, string SgPkKQDX)
{
    int EAXDRTIiQbGfhKJ = 35649574;
    string cMDOQiK = string("MSnqnUwgxQZiTsVhbAuAGwAeESLZvhhLQgwx");
    int tjNYgh = -1288001473;
    double WVwvziuDapFtQ = 822897.3355823442;
    bool HLImZgqs = false;
    int pbascHNoPnJw = -397870193;
    bool HarMq = false;
    int MSQJKotONbdhbNS = 1115840799;

    for (int kuWikinFm = 1164623137; kuWikinFm > 0; kuWikinFm--) {
        MSQJKotONbdhbNS *= MSQJKotONbdhbNS;
        MSQJKotONbdhbNS /= MSQJKotONbdhbNS;
        cMDOQiK = lULuYDBlCzfMmTnZ;
        cMDOQiK = SgPkKQDX;
    }

    for (int LABfXOYK = 15784291; LABfXOYK > 0; LABfXOYK--) {
        byixEhewPcNAVq = byixEhewPcNAVq;
        BKXbN = ! HarMq;
        MSQJKotONbdhbNS -= pbascHNoPnJw;
    }

    for (int YOovhtYfYyUUb = 952866216; YOovhtYfYyUUb > 0; YOovhtYfYyUUb--) {
        continue;
    }
}

oiRZiiZ::oiRZiiZ()
{
    this->KjhVnXoYppfxC(-866531.7303453807, string("QiwBIVfxLsbsZWDcUsWkWNsufjiIqXCUalLDlfgxc"));
    this->CVHzGuYUmMIKTUoE(string("uPvIpOALOybADYwyxQdiGJTAVDrikqRlXPAXpPsHTMeuygeRSuqHkUMfPOGNSdWnrYOHVfwVRjVnTBKOVpiFjYAPLUpnAdsvMdyBZjPhUFqgAOxIrfQZVypuiHJLpksWSqHeBhRHeCgbcSSNKldqVXPXnRTtYJRXjgBVbyTwXHIRTStSdTJoJpvnbfuieePGrZrpqgGdXymdriWeDqusjRCPJatKjffiUxnbbTbxscxAqRWj"), true, -401974.56024012464, 292388.71848842705, true);
    this->yXPnZrcOREW(string("cwuMXcRoWlNAkOdNmVaLDJnyRtuqwjZDGiMpwKPqrOQbHPpksyrDWpEYQFeFwuACrUFbuSmEzSpcPYkBlPdULRQrVmkGgqGbCwpcoWZhNxyEKhpagLIBFIbxBNfzUKQjrFWJMczxMxTDZzcArZAuEFXLXJMYfmoOTqGocuYJvLJLyXLEKXgpwZghbr"), false);
    this->gRPLoseIoEoJTf(-571027.58774116, false, true);
    this->cjjmiBCFYGD();
    this->flTCwK(1132755783, 660544.75267632);
    this->HQtFeEcWbIiYebGH(-885320.6320249279, true, true, string("iLhQGpcxAFUSZzzJVNAtrgouYuLXGRAXFnUbDvSCbnrMMaqyaCNcJ"));
    this->FPSrrIelMoKTUycm(string("nSluLxpvkuVxUHvQBSOaOUtshughcVsEHHBnyGJSmxLMGFWeuWVcUXrUatkYDHuyEWmviSaOaeIFnewmkeZHLIfSzjkPHWpnJodzILyGQtssPVsRHrFaCNYFssGJRbEJXvPszneUCSekMlQowMTKWzIlJWHXNeWfQmIQUrYrHIdzqewvREnjX"), true, 754192474);
    this->ABXubrrQpbcu(string("ijSlSyjqLbtbVJDEyHHrbHghQjmcSzNehFwzJPIxSmZXTOceoIEBBEVgboamfJIsQSJwzMJdVQWMhGbXcqocseULQjaCsfTcbMSnBPDBveCqOJcAhdFBETldGIkd"));
    this->XvvuDAHe(-1791722735, false, string("WOVqkYnLCmVOFbFgdXLxexHwLBeHzzBLCZYMlRUrvqHwwhwrHbJvnWTejrePjeottIDpnCdwdNNRQNYwkSnELqvehdacfZncFtWPUylldzOszxJWoHjSRvCqnvEdjBZgPdeIHoDyDSBZEtGRqHwSYkoTocuisKP"), string("xmIjQPIrmYLNWbiCxBuAxiprkDBriyjsyYFBFxHEEkxBNjrtUdOSFNKdCcmGrQHJGmJcmCEXXSODHBvAZEijykBlixnoUHaUcjYWsZdsqcXzHpNuABAVyOspPaQWanTwvMQBgBIlYswkEHFSBGhCvOZpxpXuYuCqrYZdiTBpkUAWiHpZIevZfatgTEbTlbBKsWmcWFXcCQcSUGQCCrSJFJ"), 146295537);
    this->FgAtZyDxTSnXr(string("czkZNAVvhENVJAOhrGxKSmOvLKXfUGMVjKXvhmnPuUfeaCVUZkQTHqgsWJXSgMSpLHOAjBpbjWhBbOrSKdgieGPDJCtVLkMEYRqAxuJysvEPUeFLbPRaKoOWNASWNKJJnRhrHoQWPjvkadpAaRlIwlqnnOssygHqBfCmRlOhIdmkBNXdKNamWdFggpPWvVqnW"), true, string("NHuErqnCrRMrHgUylFoUjeVTPvGsREpXOAorhjyHNnkiqJHpkRIzAwTHOkporSmpKEEfzxujIweBdnHfBUphclwrTySmtyjStiRLMZyW"), string("tgkLvkGBlztrnVLBNvLvFDdgDMpIPnYuFenzzvtCLpcMvYAbjeOBUWtIdHHNMusXmaxrZEdLNrSdphPXmdQCTgNoARXcXJNQmechioUvGXTBqtWLMxnkrjnJYadQnPQFRGIxbNVDJKkNosCfdYjdUEZFzJnnuiaCuRKWCRlXNTxMuhNfcpzUNtXbKWdntbAJbIcYFJkVgEjjLhpVuQKRKKfhdXJgpuIfRZcFYeoQBULVqhKHdlHRlVOR"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gfBfXBMrsvj
{
public:
    int yVJyEEp;
    int YuIPVI;
    string eXHvtjggGFArcQgH;

    gfBfXBMrsvj();
    bool IebQcWtIzSYuXUBo(double abqAdzh);
    void HNjRYxSLeBWx(bool pYsooycScLUbVg, double qjHBliwIVrsr, int pdRdkeCyLz, int OToJlzOW, string OcaRpjseLpaQZgNi);
    int YdwTWDjnoVe(string RJmSy, int SxRHtrVhbpw, string tYfixH, double cwJYNlqY);
    void EWJJXGTpLQitIG(double tGUipMh, int HWdLAJtb, int aCMPZUYs);
    string CNobNzurDzBnengH(string JGtBKrIRsQs, bool BRbdJnCrHodfTr, double unETHbDH);
    string UHCLzJQMYqCfsP(int AOFfAUuCXjfnIHAY);
    double RZaZqnCQnd(string CbTyTplyuf);
    string ZZKXfQXkiba(string ixUGG, bool xAaAEL, string mqCuWefuXLmRO);
protected:
    bool vNitHiTox;
    double QlaaUbyrRKh;

    bool HEwEJtBSYpnKgu(bool EiSMXQhpiwvH, string jyutiAx, bool EqZSBehHrJw, double OIRVGzjHVjauDGr, int pqLJhlNgsVo);
    int zTZRzf(double xzLrAnGZMivOVvrL, string QatDTCcurLCYb, bool HoqRKPxlhz);
private:
    string eKMFFM;
    int AbEKzLlNNLmdEPYT;

};

bool gfBfXBMrsvj::IebQcWtIzSYuXUBo(double abqAdzh)
{
    bool yQKTOcW = false;
    double ftSTjyjqLz = 581210.1085023899;
    string SHMXitCxMHvBK = string("zWkumhlEaBfndYbZrwzYlUraJpECCZTPRuZMzWscxRdLbdteSCKZWxBzXQxsWskfdmIDuatQksipATDVdLGIfZRqeuFHnguUorlstrDktkuyefVcHQHpCBtfNtOBixyPQpspGLpEzIWsbNJsbKqUHkSomLTutYByLgaERnldSshhLgOrNTttFWErjiNEWGXbajcvy");

    for (int pHTOglLrUDkHEfb = 1236651326; pHTOglLrUDkHEfb > 0; pHTOglLrUDkHEfb--) {
        yQKTOcW = yQKTOcW;
        abqAdzh = ftSTjyjqLz;
        yQKTOcW = yQKTOcW;
    }

    if (yQKTOcW == false) {
        for (int LUZvDYywiet = 287902241; LUZvDYywiet > 0; LUZvDYywiet--) {
            abqAdzh *= abqAdzh;
            SHMXitCxMHvBK = SHMXitCxMHvBK;
            ftSTjyjqLz *= abqAdzh;
        }
    }

    return yQKTOcW;
}

void gfBfXBMrsvj::HNjRYxSLeBWx(bool pYsooycScLUbVg, double qjHBliwIVrsr, int pdRdkeCyLz, int OToJlzOW, string OcaRpjseLpaQZgNi)
{
    bool BKWUiMCnnfwOTaEq = false;
    double BFzYEIZSID = -389788.4089196639;
    string rZNojLpRfsZvaX = string("MYeHpPEDOVmOldOmiATTFxyuxqgBlhuFjBMZAFZnscrkHhSZETwHUotgXmpinRckMQEodJpiIEaTAAVIIMXGoiYOqBkDHqaFwEUbkSEuJgFzogzdfZeVCDnkGAOtL");
    string xSliahUpVwzCdFXz = string("FwcNzEVeiuNocxKiCiWDLkjluBSxHAFvztTTZUYueFXUZhZsCEHwVvRMpbPQNfQzToibBsvsEyXeCKXKiGzcaedcsnJaiP");
}

int gfBfXBMrsvj::YdwTWDjnoVe(string RJmSy, int SxRHtrVhbpw, string tYfixH, double cwJYNlqY)
{
    string PogrKxpFfnDm = string("ufiAtAaLJqsfGdyvzaAMuyEyPhBGYPgtXZXyKifObaRZoZYnpZTjEldrNffgmCNrZsZrDTQObnxihkFRUgAMLJDstEkhldeoEEqZEzWCRocNYuruHTdxyhUqVDYkjVAfLUkUIGoZLiOWbXGEdgdrlsKrfSMRkQVfnHghyJeHeYRtGRLansrURIFTmxsBBlz");
    string YBBNvd = string("fmChQNEjnUirROxaZtxhZkhBzFWkm");
    string xzUtxHEk = string("htvnmtfBWfvkbHwFJsaSrnojKYnAHkFRAJLkTamFuOnvRZAfGupTcWHXEysdrsIQmnoIzPOkUBOuXQFmZFKwsqdFgtRvPXjfTbuYue");
    bool TqUPLLMIq = false;
    bool zQpzbrjIULz = true;
    int PJokNotIFiEy = -2009219338;
    string Ecpgyv = string("UQCaRQzStypOaaJRMFkNLFoqBKavEhiJoPkVcgjtXLgikFxqDUiEnQSKufwFDwUcxbJbPiPJBMTYPOnyMQlxINAKtJhsSF");
    bool PMfIOEMSZ = true;
    bool lZkwQHozRZumJgD = false;

    for (int kInuF = 376130278; kInuF > 0; kInuF--) {
        YBBNvd = RJmSy;
        TqUPLLMIq = TqUPLLMIq;
    }

    for (int TTCgcwTYdopqfpO = 563396900; TTCgcwTYdopqfpO > 0; TTCgcwTYdopqfpO--) {
        lZkwQHozRZumJgD = ! TqUPLLMIq;
        PogrKxpFfnDm += xzUtxHEk;
        lZkwQHozRZumJgD = ! TqUPLLMIq;
        PMfIOEMSZ = PMfIOEMSZ;
        PogrKxpFfnDm += RJmSy;
        PMfIOEMSZ = ! lZkwQHozRZumJgD;
        tYfixH += PogrKxpFfnDm;
    }

    if (Ecpgyv < string("fmChQNEjnUirROxaZtxhZkhBzFWkm")) {
        for (int YNzPxtnrMU = 147907767; YNzPxtnrMU > 0; YNzPxtnrMU--) {
            continue;
        }
    }

    for (int xPMNBBzfVefJrGA = 1592728748; xPMNBBzfVefJrGA > 0; xPMNBBzfVefJrGA--) {
        continue;
    }

    for (int IMImhQZxfDkQN = 618541543; IMImhQZxfDkQN > 0; IMImhQZxfDkQN--) {
        continue;
    }

    for (int QgLiF = 590740767; QgLiF > 0; QgLiF--) {
        SxRHtrVhbpw *= SxRHtrVhbpw;
        TqUPLLMIq = ! zQpzbrjIULz;
    }

    return PJokNotIFiEy;
}

void gfBfXBMrsvj::EWJJXGTpLQitIG(double tGUipMh, int HWdLAJtb, int aCMPZUYs)
{
    string SVrUEepskGbDECh = string("yzpVdGBnWWpYiOUKmwLhXVEGCCdSGRBcySqyhEiXSwmRLUwiOPrdWGodVpUpmNckJWNbxMFR");
    string rJeUgsuIVOA = string("yUafMhHRvWZloQQOlSEeYCDzGObseipTEivjMoqYsejMsWVjeDwQvGhkRDaBHrsAEqYzKxtMMQUwUmRGGStyKkcWQJILghwxDGkZksaCJncfFTP");
    string ToMdxGEyyvVQ = string("EMsPmPvHhrVILrMhUvBKWPtFSwbplIOffzyDVGrrDjfaIPgdOtyafScKIKQzwmjywoFmembNyWbUKWlqOuzGqNITrExzeYahkWXaJhflBDGhUzxeIXsrEAfpRYrGpTHyvvEOdTQXAlZNMlMBpmfZtbqGRIkfEJefjWiyYbEFNyanTIeoOaAkFAizesdlBPwbUSYsSMkVmuiavKGTApfyCclLDqgRhEFNqvxgm");
    double RVTEgwNB = -457876.58264892566;
    int iGiKtIGa = -739878734;
    bool aCuBluhwnbKQcpx = false;
    string CaQECtcOHJtE = string("RDFZgjANgIMePZzsiqZOdCGXXMpOfvvBVajobwSCzqomYhRVNfYuttnAPQhYanEaeDCSBkZteHGRJxOYtXIcXkXKrfowdvPrFzrVyCmIzVs");

    for (int SxvTdioD = 1851620222; SxvTdioD > 0; SxvTdioD--) {
        aCMPZUYs /= iGiKtIGa;
    }
}

string gfBfXBMrsvj::CNobNzurDzBnengH(string JGtBKrIRsQs, bool BRbdJnCrHodfTr, double unETHbDH)
{
    double TLTaVBu = -618468.4402779359;
    string LYXttwSNwz = string("PLzFUCMnxwRLupZjAoDzBEuIkImQkXqTzHvxffsKWLhFOMhzUdHjOxDclLgqHQKvRcmQgtqmyyLzLnLZxFBKiFYEqZcSlBrOorfBbNScYcLVqLxLELWyaxGzAgpquQUfRcNDnnCcpKbpNPzMWYnwqPREXEUvHhTpZczhAQJInXzoIUFkCpmhCvHiTxPLjxBPbvqxNtqHleeXRmWynRsvFdnQcuZXnBonNs");
    int CEpEhyBfRWRXB = -2080914397;

    for (int JgxTyBiXIjqvqM = 1831490014; JgxTyBiXIjqvqM > 0; JgxTyBiXIjqvqM--) {
        continue;
    }

    for (int GTdyeuLYwZU = 34424641; GTdyeuLYwZU > 0; GTdyeuLYwZU--) {
        TLTaVBu /= TLTaVBu;
    }

    if (TLTaVBu == -618468.4402779359) {
        for (int wVcNsEjdGUGHyLVX = 1510267743; wVcNsEjdGUGHyLVX > 0; wVcNsEjdGUGHyLVX--) {
            continue;
        }
    }

    for (int LKkyTXwIYzzOXrB = 979984267; LKkyTXwIYzzOXrB > 0; LKkyTXwIYzzOXrB--) {
        TLTaVBu -= TLTaVBu;
        unETHbDH -= TLTaVBu;
        BRbdJnCrHodfTr = BRbdJnCrHodfTr;
    }

    return LYXttwSNwz;
}

string gfBfXBMrsvj::UHCLzJQMYqCfsP(int AOFfAUuCXjfnIHAY)
{
    bool dhaRraBpOL = true;
    bool ICLFNjBXvWqjzp = true;
    bool gOYMkIm = true;
    int TBhrqTPwpc = -1422883747;
    string lXIhwCgJebTgCs = string("SERUJSldCgaDeCOVNLgIrGjotJmBUqNkOYRgCWPsYEyReGsuYJulUbDOJcaIFZliimZytWWITLtJJONSydfpprAlNfzgKZxAkICZTBJqdRcjieOtobZGCJRWDBjucilIdrWOdloozqkRRNewfXlfvkPIgJDpHnkjnZJxHWcnFVessClJWhpTogLeJFcEftQLALAUXAMioPQofUpYEolTgROrjtmRmonAtJvgtUIlEqplF");
    int ZEmINIV = 586800805;
    int gziwrDwRjPBSV = 427701572;
    int ApgxPMzjRudwJV = 645190963;

    for (int DARXeBCErayUv = 1466306871; DARXeBCErayUv > 0; DARXeBCErayUv--) {
        ApgxPMzjRudwJV += gziwrDwRjPBSV;
        TBhrqTPwpc *= TBhrqTPwpc;
        TBhrqTPwpc *= ZEmINIV;
        AOFfAUuCXjfnIHAY *= gziwrDwRjPBSV;
        TBhrqTPwpc += AOFfAUuCXjfnIHAY;
    }

    if (gziwrDwRjPBSV == -1422883747) {
        for (int kZdbzscTc = 1640128068; kZdbzscTc > 0; kZdbzscTc--) {
            continue;
        }
    }

    return lXIhwCgJebTgCs;
}

double gfBfXBMrsvj::RZaZqnCQnd(string CbTyTplyuf)
{
    int hMBUOGIAU = -2120293085;
    int oRMcqmLEglfpxuX = 1520509742;
    bool GreAcBy = true;
    double TgcdoaunlGg = -188826.68151687164;
    string zUqiX = string("TSLEjddynIJAYaODNDwevASRFlgkqdeMNIWemGvKULrHgagyjaFYwsOSGpOEBAeSpIleAIbVguNZVfSPXjsYavGwqjprNDLRwTCMavCZrGDlKdCJsOLrOODUTCucSnGgMJojWUuzpKfuFmenshzzzKfoyUtUJFgUCklFseDkkOjEdZTFiVM");
    bool zDaDSzvFckKjjW = true;

    for (int axxKyowDvFnwk = 941996716; axxKyowDvFnwk > 0; axxKyowDvFnwk--) {
        zUqiX = CbTyTplyuf;
    }

    return TgcdoaunlGg;
}

string gfBfXBMrsvj::ZZKXfQXkiba(string ixUGG, bool xAaAEL, string mqCuWefuXLmRO)
{
    double XEQBhJTUFsdY = -879447.9682213317;
    bool eTWLrBFssCDoFpZy = false;
    string SuyGjQPd = string("zfFYrozZGecHMDeejeKghgiPQJGEdQGseypJsfyeTtCzkPgzRrzmjeMRtvePcGofwXAANwZwjYmYCCoFTiJIlUAxoHcNVVzcEbtkIlkJLCdwBaUjbTRTzbkkHMeaBStByafSdalwbgimBjwrnaoirIUjxAaTyGpvHKhfUhCRVvjgxQyxZixBTUmKqthEnXPTAjPaMslHXVHJEbtNpTWLiLTmnL");

    for (int JpygkrmQdwGraSX = 1260072352; JpygkrmQdwGraSX > 0; JpygkrmQdwGraSX--) {
        SuyGjQPd += ixUGG;
        XEQBhJTUFsdY -= XEQBhJTUFsdY;
        SuyGjQPd = ixUGG;
        mqCuWefuXLmRO = mqCuWefuXLmRO;
        SuyGjQPd = SuyGjQPd;
    }

    if (mqCuWefuXLmRO != string("okCLIkbquhmwEIjwQejQQzpusNcKRigMrzVdJFNmFXZXmYbpcrJInSSOEvzYozjTIOWYZEDUOgIXPixOFaxQhAaYVjTRhWpZwOnhGVTiNUwYuFiIKrwJUQElWinKoVblVDwpznYpRuZVSNVIVZRnxdXKKZgITWseL")) {
        for (int zfYTp = 450099095; zfYTp > 0; zfYTp--) {
            xAaAEL = ! eTWLrBFssCDoFpZy;
            eTWLrBFssCDoFpZy = xAaAEL;
        }
    }

    for (int NwIJrB = 1461766346; NwIJrB > 0; NwIJrB--) {
        ixUGG += ixUGG;
        mqCuWefuXLmRO += mqCuWefuXLmRO;
    }

    return SuyGjQPd;
}

bool gfBfXBMrsvj::HEwEJtBSYpnKgu(bool EiSMXQhpiwvH, string jyutiAx, bool EqZSBehHrJw, double OIRVGzjHVjauDGr, int pqLJhlNgsVo)
{
    string rwdLM = string("CnUZxMuDyBIkaWavthHRsfundtYhgTNgDuqcLbSNRc");
    string rxPWI = string("OXouPUOdoYSuQJJFSapHYEGfmxflWTReBUjQGpqdoIWcIPRrRxecwzkJqApHDeooqHclePqPmZPNIXJyyHYAhGLSRmATRMlSCTCBjnvTsnqnvKLHbAkBwsizkhtVcVZOSYgHHjESxXWCFWyjoYWqLspBXkUYlPNEcWYvxcedNflNbeQmZMDesngihdVQMyMQGSTUPIKJcewIrHEzDFOqWLVNLQ");
    string eYsoEUaBehfn = string("vYUBXDgYMrsAfzweNUcalyrwFcNUeSIKgsKkmhoTLsmALlbAzLeYyuZWLHDYxLrIrAXNCYDwuTsbbWXsafkbwCdMAKUopNLbVccPlYeGLkkLjlwSUeqIaSjQqSWFNJPUgOBLlXLMlPQd");
    bool GRAhpnaLXMltDPW = true;
    int QbMnF = 98378433;
    int bHHmw = -2018113318;

    if (pqLJhlNgsVo > -2018113318) {
        for (int lrFHTNQHvT = 1846428487; lrFHTNQHvT > 0; lrFHTNQHvT--) {
            jyutiAx = rwdLM;
        }
    }

    if (EiSMXQhpiwvH != false) {
        for (int SbLzmcQQaaxuFp = 1593408918; SbLzmcQQaaxuFp > 0; SbLzmcQQaaxuFp--) {
            bHHmw /= bHHmw;
            QbMnF = pqLJhlNgsVo;
            QbMnF -= pqLJhlNgsVo;
            QbMnF += bHHmw;
            OIRVGzjHVjauDGr = OIRVGzjHVjauDGr;
            QbMnF /= QbMnF;
        }
    }

    if (EqZSBehHrJw != true) {
        for (int yzyYx = 2053971311; yzyYx > 0; yzyYx--) {
            continue;
        }
    }

    for (int jxkxieC = 1425027808; jxkxieC > 0; jxkxieC--) {
        QbMnF -= bHHmw;
        eYsoEUaBehfn = rxPWI;
        rwdLM = rxPWI;
        EqZSBehHrJw = ! GRAhpnaLXMltDPW;
    }

    if (OIRVGzjHVjauDGr < -979285.690974605) {
        for (int IQwiKb = 805571676; IQwiKb > 0; IQwiKb--) {
            rwdLM += rxPWI;
            jyutiAx = rxPWI;
            EiSMXQhpiwvH = ! EqZSBehHrJw;
            rwdLM += eYsoEUaBehfn;
            rxPWI += eYsoEUaBehfn;
            jyutiAx += eYsoEUaBehfn;
        }
    }

    for (int peALzCqvoMwig = 1787824310; peALzCqvoMwig > 0; peALzCqvoMwig--) {
        GRAhpnaLXMltDPW = ! GRAhpnaLXMltDPW;
    }

    return GRAhpnaLXMltDPW;
}

int gfBfXBMrsvj::zTZRzf(double xzLrAnGZMivOVvrL, string QatDTCcurLCYb, bool HoqRKPxlhz)
{
    int oDpzzgJ = 715809576;

    if (HoqRKPxlhz == false) {
        for (int WEuzY = 1103068040; WEuzY > 0; WEuzY--) {
            continue;
        }
    }

    for (int NMSAoaP = 1080558065; NMSAoaP > 0; NMSAoaP--) {
        HoqRKPxlhz = HoqRKPxlhz;
    }

    return oDpzzgJ;
}

gfBfXBMrsvj::gfBfXBMrsvj()
{
    this->IebQcWtIzSYuXUBo(-700095.4055863761);
    this->HNjRYxSLeBWx(false, -771340.8908396875, 1674927747, 1696799408, string("a"));
    this->YdwTWDjnoVe(string("NYvdFXbkLQvheKpBLPtkJhVaLUBRAIuoWagjXAdKrsASGgSXduyCEmhgtnnwAWJvRdWqhTecQweLBORPZXQkxsRZNfPOvQJxKZwbDfaJMCDROStjdJbRYXCnbCVIlvYXeegeBqdKreLWBGcvbLTGEWowrv"), 362875189, string("yVmGQLPoRHJwYrxiDTmvfbcVmBycLQeDgnVqDtRfCBzRbDvWqlTIZcxyMiAdzwbDUfmEcqUrAmYvESAexzzACLmkXKPdlvWkBZwSARQkrMvPYebXJAYiBZlHqAyIdexEOHEIiJcckzTPHGFgxVyLNPTweDedSrDtJHhJaDOnHJjwwKVSboBgywGkTaEP"), -224659.28305721143);
    this->EWJJXGTpLQitIG(-517662.41179113253, 527685185, 1234485098);
    this->CNobNzurDzBnengH(string("bSWqLgbJLHSQccSvSElyqAmybzTsEUkYwHkstmNrcnEEJHEoVZbjKwtejgFQzApAlSWhAqHYarXSoiWbFjdHGBLVcdUQuaEtWrTvddroadvIROEoyNbVLrCKDOkjhQzYoJIzBckFTj"), false, 684877.9963533927);
    this->UHCLzJQMYqCfsP(116663800);
    this->RZaZqnCQnd(string("SIirnzrDdjMXCmXhMqMsebIqZhsUWweEPSSsjMrElcrYGaYAxduAzcCXcZQoSuvKKrJInANwLPtXbXRUXRdmZFUGThMIozjHLjtEWTgxZgUQXSFSboFpWWuZdmrtQErbryTxIrxCKjKjeaWxrziXSkhu"));
    this->ZZKXfQXkiba(string("rLUVRbqTCgOQPwIgiNmDDVKSpBnlPqunLxKtCcvsHrGRsRnNeVafvngdOQQOPuQLBinCgKXeFQaLcOFfYhZqkJWaSXImWTUMrEAqENSBJEplWOYPXcLFGMgIfqvbTwzWktRtnGPVlyPfvFVIuiDZHERQyJhJenIWLVngPnCMtptOeLkpypzihkGfmVAJEnOoPwfJd"), false, string("okCLIkbquhmwEIjwQejQQzpusNcKRigMrzVdJFNmFXZXmYbpcrJInSSOEvzYozjTIOWYZEDUOgIXPixOFaxQhAaYVjTRhWpZwOnhGVTiNUwYuFiIKrwJUQElWinKoVblVDwpznYpRuZVSNVIVZRnxdXKKZgITWseL"));
    this->HEwEJtBSYpnKgu(true, string("sHeKvTabxLcLLcLInLBepPXbwDsQbDilkNfqkQTkBksAYWOfZYQvpiablVlLCldJydkYZpZlIxUqzFMfEvpuCpSmoNoGaXjJGkCIZvUFuhpLDjIAdORlqW"), false, -979285.690974605, -247687446);
    this->zTZRzf(501207.6964981745, string("GdsNTQJYdYhiCWCzIoimBhRfwEzwUzVpdVvNKXUiYKMHnaLAlLIzErgENiBZsVYsPwxBPBGFVxXRRwdfnfIDmGExJzhtvRHFhVsicPtndHMFzOdygNtwwCOkvtcwktVqyqiuWYJRlMoWzJYfdGaiZo"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gkxwmOibyeiQ
{
public:
    double JzOwBwUyXfujCLxM;
    bool cMSFhqzKkztgU;
    string FIBAppzIp;
    bool jADKTbpNMeHL;

    gkxwmOibyeiQ();
protected:
    double tYRStGSzTElnXRL;
    int pZzleuOVcfLL;
    double AqUvZ;
    int YMIwxA;
    int KjfCLomlreLcEc;
    int fXKEczaBCMrpdEyk;

    double GACWeoXTijUfHPN();
    bool lUUiiulRJPvh();
    string RMRUXT(int BQTpuRFS, int BmuNFbpvpwScwKj, bool GfFDrGPFEFNkYySe, bool NsBIpaTHyLo);
    string FichGEvXs(double hwDvlyelECzVR, double MmfVevjtzrdw, string PyCljiEpb, double qPgiKbhp, string akUxXmohZCaIvsS);
    void kwEtgq(bool ppVKOVAGoYyb, int vZeiRDkXrKwaPbVU, int arbKColsQZwa);
private:
    double sGlbOvYc;
    int IQBmlNu;
    bool kGnKhloFgsw;
    int ZBaREVdo;

    string RyfHMcO(int NNSQVizjrxSH, double TYccTcajwkuE, int DhhuUoskJvtNDcX, double sjyPberEgeJucRG);
    string eqiVxJjXLR(bool MsSwTNkMGtdFi, int ALyEyMM, bool VGUHgd, double bNLlDxkLznBK, string tngxfMGprckHy);
};

double gkxwmOibyeiQ::GACWeoXTijUfHPN()
{
    int pAICkkwHTgRkoq = 1265717466;
    bool UvUlc = false;
    string nqZgQxiwjmtUok = string("lKwtouXuSWUvhlpgYmwsyXaYOvJACQppRjxuygXvpzHJVsXLCoAGkGPuiBTKQ");
    double XnElyfHu = 395969.8646013966;
    double APXkHzUSWJhBOzqc = 121152.01604474071;

    if (pAICkkwHTgRkoq > 1265717466) {
        for (int UqqGPGjCXBAq = 1229785746; UqqGPGjCXBAq > 0; UqqGPGjCXBAq--) {
            APXkHzUSWJhBOzqc += APXkHzUSWJhBOzqc;
            APXkHzUSWJhBOzqc *= APXkHzUSWJhBOzqc;
        }
    }

    for (int TiTCq = 1710176188; TiTCq > 0; TiTCq--) {
        APXkHzUSWJhBOzqc -= APXkHzUSWJhBOzqc;
        XnElyfHu += APXkHzUSWJhBOzqc;
    }

    for (int ARucjdCokc = 1710545351; ARucjdCokc > 0; ARucjdCokc--) {
        XnElyfHu = XnElyfHu;
        XnElyfHu /= APXkHzUSWJhBOzqc;
        APXkHzUSWJhBOzqc += APXkHzUSWJhBOzqc;
        APXkHzUSWJhBOzqc *= APXkHzUSWJhBOzqc;
    }

    for (int IplRvCxUhtuOUb = 440004732; IplRvCxUhtuOUb > 0; IplRvCxUhtuOUb--) {
        continue;
    }

    if (pAICkkwHTgRkoq >= 1265717466) {
        for (int kvxopW = 1114230779; kvxopW > 0; kvxopW--) {
            continue;
        }
    }

    return APXkHzUSWJhBOzqc;
}

bool gkxwmOibyeiQ::lUUiiulRJPvh()
{
    double yoHQSEIJpQ = -54098.08769724286;
    double wdwindkHqNKO = -358547.1152927135;
    bool ZeNlM = false;
    string hscyFgwnihUbvZ = string("LZeVvwCpaPPtKnwcJHRRlJaHoXEgnMKdcRXvuXyqzWxKWsVHpEUezJrwhFjUNaJQSgnNoUSnapPxsduFXUpVJTrXJqlhAQyJPxpiApxEqfdVAPpOmwRUCkamjjbUhfmWpQJDoqsXAWQdaLqSOLKklfekxeFuBiTYpMroNrkZWJOJDyNtYKsEmisznoUecLoqWQkhnZYoNtIyBiLoUddkrMuCgcXPqYXKXq");
    double kDkMifD = -302786.4785165749;
    double jCqUzKQnqVMIN = -947018.9537752266;
    bool kdogne = false;
    string IUPOjXlNhRuqlbUW = string("RfTzSjMmtfDUMkAlBXTiqDJMqQxIztmtOMTkMmzqREnKaxvdbsYxZmlxNbglHeUqLNufpWnTuaJdDIYVlKXQKer");
    double ldkjvzcNal = 886841.9056961467;
    bool WCMoo = true;

    if (IUPOjXlNhRuqlbUW >= string("RfTzSjMmtfDUMkAlBXTiqDJMqQxIztmtOMTkMmzqREnKaxvdbsYxZmlxNbglHeUqLNufpWnTuaJdDIYVlKXQKer")) {
        for (int FCxQkulHkQEoVzHd = 1265554136; FCxQkulHkQEoVzHd > 0; FCxQkulHkQEoVzHd--) {
            kdogne = WCMoo;
        }
    }

    for (int niwynFyJcTyEVju = 1120043954; niwynFyJcTyEVju > 0; niwynFyJcTyEVju--) {
        continue;
    }

    for (int yQcKDhsTCwXuGsP = 579071465; yQcKDhsTCwXuGsP > 0; yQcKDhsTCwXuGsP--) {
        continue;
    }

    for (int IKntwfWZjV = 990060119; IKntwfWZjV > 0; IKntwfWZjV--) {
        yoHQSEIJpQ = wdwindkHqNKO;
        kDkMifD += ldkjvzcNal;
    }

    return WCMoo;
}

string gkxwmOibyeiQ::RMRUXT(int BQTpuRFS, int BmuNFbpvpwScwKj, bool GfFDrGPFEFNkYySe, bool NsBIpaTHyLo)
{
    string oUEYckg = string("rYjaVVqHKUqTkkIJXgxayKXG");
    string toSzcT = string("fRHTyFAJJYpRemtePYCeGXKXyTyBHzVesxGRxxmGtJndnyhTnBxcRBuocIBVgSXrwOauZEtmxTLEgpDxVVdmqyqomNKgEhWURxsIJdVfMxkwYiUVrYsRnqDQBKdpcvxGkYT");
    bool WZkeSZuJECo = false;
    double sXyyuAcVNx = 123457.3181838687;
    string ZJcru = string("leqBTmpGAWIngzMcgFPcYcCoHSoLNALJnUXrLmPVhUjZMXjOxIQNcTiFVFcnavBPtpuGLgienstckDLPhcBCoCskDKkRPRGrufgNrDcAgsFnhVleTzcaervEVBOhCZfJxcrQqUGKcDBzaTEfDxwOCvBCjLHsSKoXeeeSTvqBeycUUzqwRvWBGHgfgkskoQpCbqMKPUwSAFyCZtoKWgGHAuQgegzGGzZjUVMOmVigRYQJbJpEcgpEBrzbjoQ");

    return ZJcru;
}

string gkxwmOibyeiQ::FichGEvXs(double hwDvlyelECzVR, double MmfVevjtzrdw, string PyCljiEpb, double qPgiKbhp, string akUxXmohZCaIvsS)
{
    int NcHzoCWCCyY = 74803834;
    double lJHSg = -439200.65179534274;
    bool epmwne = true;
    double HLuPp = -288079.3787331248;
    double jWTRmIKKodTFO = -309549.76723981067;

    for (int twWgQDQNJso = 1501578892; twWgQDQNJso > 0; twWgQDQNJso--) {
        jWTRmIKKodTFO /= jWTRmIKKodTFO;
        HLuPp *= HLuPp;
        HLuPp = MmfVevjtzrdw;
    }

    if (jWTRmIKKodTFO != -309549.76723981067) {
        for (int dUzcFi = 784229227; dUzcFi > 0; dUzcFi--) {
            jWTRmIKKodTFO = MmfVevjtzrdw;
            lJHSg /= qPgiKbhp;
            HLuPp -= MmfVevjtzrdw;
        }
    }

    for (int ZvWYSrVQwJgyRhj = 899330246; ZvWYSrVQwJgyRhj > 0; ZvWYSrVQwJgyRhj--) {
        lJHSg = jWTRmIKKodTFO;
        akUxXmohZCaIvsS += PyCljiEpb;
        qPgiKbhp += qPgiKbhp;
        hwDvlyelECzVR = qPgiKbhp;
    }

    return akUxXmohZCaIvsS;
}

void gkxwmOibyeiQ::kwEtgq(bool ppVKOVAGoYyb, int vZeiRDkXrKwaPbVU, int arbKColsQZwa)
{
    double MtiJpAxAR = -114523.35723219058;

    for (int cohFBOXXv = 1087609349; cohFBOXXv > 0; cohFBOXXv--) {
        continue;
    }

    for (int xIywPloAaaCbgcRR = 1165503007; xIywPloAaaCbgcRR > 0; xIywPloAaaCbgcRR--) {
        ppVKOVAGoYyb = ! ppVKOVAGoYyb;
    }

    for (int SgMlTNWUZAbFC = 1714020556; SgMlTNWUZAbFC > 0; SgMlTNWUZAbFC--) {
        MtiJpAxAR = MtiJpAxAR;
        MtiJpAxAR += MtiJpAxAR;
        vZeiRDkXrKwaPbVU *= arbKColsQZwa;
        MtiJpAxAR = MtiJpAxAR;
    }

    if (ppVKOVAGoYyb != false) {
        for (int HCJaqoyxZXNAjdSZ = 1765545078; HCJaqoyxZXNAjdSZ > 0; HCJaqoyxZXNAjdSZ--) {
            ppVKOVAGoYyb = ! ppVKOVAGoYyb;
        }
    }
}

string gkxwmOibyeiQ::RyfHMcO(int NNSQVizjrxSH, double TYccTcajwkuE, int DhhuUoskJvtNDcX, double sjyPberEgeJucRG)
{
    int fDukvWBiqhFVYm = 1381690092;
    bool RQCTkqIWNlYKgH = true;

    for (int mqffHpwLXRKJjezz = 1748408528; mqffHpwLXRKJjezz > 0; mqffHpwLXRKJjezz--) {
        TYccTcajwkuE = TYccTcajwkuE;
        fDukvWBiqhFVYm += DhhuUoskJvtNDcX;
    }

    for (int bjoyA = 614505362; bjoyA > 0; bjoyA--) {
        continue;
    }

    return string("kHqFcqRKTdmuGOKAHrRCcKixYHTxXfDTlzpHPrecdEeNigNBLlSBFzNUAfmhDAzSITqAkHaCrswFkMscvYABQCCDEDxMSjcyssVZJGNXEMUhcWbkilFIJssJZpFaTefZvwwAVJctmIXFacGZoIYJWFYCRXtozKwIAqQKnmifKhkncMtMufxjpWRZVWxagEazJbebrEyJhtBivLlGzxvtrrBEYRrqYCAsyAWdsdowQQRLVGRoQpihWIGQZ");
}

string gkxwmOibyeiQ::eqiVxJjXLR(bool MsSwTNkMGtdFi, int ALyEyMM, bool VGUHgd, double bNLlDxkLznBK, string tngxfMGprckHy)
{
    string nFooxUXuZgaqJCg = string("qmCGmfHBzpglWPsfxvuxmBhjstMZUrVmzuMolncjtMupcPXQNnPFwqKqBVOadHQeFGbPWXzpaqtuodRDEESzFjaOyOvMXfHmiOMnQfcinQFkmeolPXDeIGWbyZidlGtFEqQLaKk");
    double xmPNb = -879300.0037093055;
    bool uopbMS = true;
    int eDLUZdrNXOsBueg = -1164082203;
    bool NumharVe = true;
    int TCrUqlUAEsWEOQNK = -724015309;
    double BjptFADX = -104911.61556845094;
    double QpmLsSg = -331499.50975404505;
    bool fiwokUhR = false;
    double kFqkjrfuOBsf = -965088.4661377061;

    if (kFqkjrfuOBsf <= -965088.4661377061) {
        for (int ohwNs = 2065362033; ohwNs > 0; ohwNs--) {
            QpmLsSg += BjptFADX;
            nFooxUXuZgaqJCg = tngxfMGprckHy;
        }
    }

    for (int DMZIFrla = 1989852263; DMZIFrla > 0; DMZIFrla--) {
        ALyEyMM -= TCrUqlUAEsWEOQNK;
        xmPNb += QpmLsSg;
        NumharVe = NumharVe;
    }

    for (int uLhsieVurESfrPh = 1731226106; uLhsieVurESfrPh > 0; uLhsieVurESfrPh--) {
        continue;
    }

    for (int JyZNrKIHcLPMYrk = 425896820; JyZNrKIHcLPMYrk > 0; JyZNrKIHcLPMYrk--) {
        ALyEyMM *= TCrUqlUAEsWEOQNK;
    }

    for (int hZCiXhSPZw = 846782872; hZCiXhSPZw > 0; hZCiXhSPZw--) {
        bNLlDxkLznBK += xmPNb;
        kFqkjrfuOBsf *= QpmLsSg;
    }

    for (int mhVhDfvPUt = 1274669868; mhVhDfvPUt > 0; mhVhDfvPUt--) {
        QpmLsSg += kFqkjrfuOBsf;
        TCrUqlUAEsWEOQNK = eDLUZdrNXOsBueg;
    }

    for (int IxrLDzzzwuU = 447190330; IxrLDzzzwuU > 0; IxrLDzzzwuU--) {
        xmPNb += kFqkjrfuOBsf;
        BjptFADX -= kFqkjrfuOBsf;
    }

    return nFooxUXuZgaqJCg;
}

gkxwmOibyeiQ::gkxwmOibyeiQ()
{
    this->GACWeoXTijUfHPN();
    this->lUUiiulRJPvh();
    this->RMRUXT(2111572176, 1993383280, true, false);
    this->FichGEvXs(-174036.32386584434, -635417.3109670102, string("qbCtwMVYMuZOMfbbsVDFZhlMKecSJsztXcRlZrSMrvpwYHexaDIWC"), 954950.4416007185, string("lPQWEilnkxZfOAIusmWskhjNkwlkxiXuanavlbAKxGSkQSGGhNBtKfKRjRRNkHRkDiTYgoCLIyFkqWvQyfl"));
    this->kwEtgq(false, 542683778, -1382574725);
    this->RyfHMcO(742665037, -948708.7546345878, -1202913355, 664613.8073856969);
    this->eqiVxJjXLR(false, -1224244914, true, 51665.93015114562, string("xpVkcLBRLxNozFAanTjCebzhMtyAKtHBeebEkRutjTkanIDOiWefWwdrUShdZWfvyfjJeFDaeezCfVIvVvNIXoElgETIDlFYbVlUfbNTYaCIBKnNaBCRuTEqS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FYRNBmGZoy
{
public:
    bool IOHegVouNeLnlK;
    double wemTxkTn;
    double VvjavFh;
    string hkKmP;
    string gJvIpXUDapwY;

    FYRNBmGZoy();
    int LdHYMpumfrLDjTOj(int ZVmNovjvDc, string jhxbexozcM, int MDwmlzG);
    void AviWsFADmZJaCi();
    string EkeKZ(int gIkYUskRTyHx);
    int akLQYbAZG(bool ielTBHjLoc);
    string iiAJKH(bool FuhicBlsYZkK, bool BAznAtXZcbcfDDgf, bool fgRSnpUFT, bool aJgsJolEpcoaHPz, bool izrDvpKgFnBG);
protected:
    string qFAkHK;
    double KzLbNT;
    double dbQdEOEeJr;

private:
    bool uEgCbJexPTD;
    string CoRMHdDrGPbQAWG;
    string ssNiMWvKBcJYtTd;
    string axQKChezmljsZFAw;
    bool wQXGsbb;

};

int FYRNBmGZoy::LdHYMpumfrLDjTOj(int ZVmNovjvDc, string jhxbexozcM, int MDwmlzG)
{
    bool UBXzUFqWwHFTy = true;

    if (UBXzUFqWwHFTy == true) {
        for (int jNgNQ = 1963967681; jNgNQ > 0; jNgNQ--) {
            ZVmNovjvDc -= MDwmlzG;
        }
    }

    for (int WvNasZHuYiEKl = 375411609; WvNasZHuYiEKl > 0; WvNasZHuYiEKl--) {
        MDwmlzG = ZVmNovjvDc;
        jhxbexozcM += jhxbexozcM;
    }

    return MDwmlzG;
}

void FYRNBmGZoy::AviWsFADmZJaCi()
{
    bool GCrHrwnIZljfbft = false;
    bool fecIbrJCr = false;
    double ZOlYaracbZVtn = 355915.3162139149;
    double YqPivObOOOTKuU = -1015785.6374968414;
    string CTuVxQcHTbC = string("XLcJixRFNTEgYVOPQWrhjaVIpdENvrrbEqvMkQDaSMEqFecFCXrDVpnvXhpPfWOvKuuHgwLaXtcDAEUdhsklaQWAFcXUPAbNTpLfgNpnkpajGnUyPrgHoCeLtHARSaPpHiLeekibZGgPnVTCrLhsTdbzuZFvKBXAqsGVQThiTuRYlAHQcjFghQbbWfnsQGBoRCfvFHuNjuSQYNCOkFcB");
    int FJICpDywidENykD = 1107168096;
    bool NhXArnlSuq = false;
    double kksVeVoZhdGlXKLG = 1039897.6870137443;
    int aifopB = 1763165853;

    for (int bOtiGRwKeTXv = 198435482; bOtiGRwKeTXv > 0; bOtiGRwKeTXv--) {
        fecIbrJCr = NhXArnlSuq;
        FJICpDywidENykD /= aifopB;
    }

    for (int pSFmrzl = 1341672878; pSFmrzl > 0; pSFmrzl--) {
        NhXArnlSuq = ! GCrHrwnIZljfbft;
    }

    if (CTuVxQcHTbC <= string("XLcJixRFNTEgYVOPQWrhjaVIpdENvrrbEqvMkQDaSMEqFecFCXrDVpnvXhpPfWOvKuuHgwLaXtcDAEUdhsklaQWAFcXUPAbNTpLfgNpnkpajGnUyPrgHoCeLtHARSaPpHiLeekibZGgPnVTCrLhsTdbzuZFvKBXAqsGVQThiTuRYlAHQcjFghQbbWfnsQGBoRCfvFHuNjuSQYNCOkFcB")) {
        for (int NuauqN = 2010094171; NuauqN > 0; NuauqN--) {
            CTuVxQcHTbC = CTuVxQcHTbC;
        }
    }
}

string FYRNBmGZoy::EkeKZ(int gIkYUskRTyHx)
{
    string nMIAIR = string("jMchBglgmnhTxfFcbDhruHpkpvxlBmsrfKvgpWmcnjBEvbHfUpkflxhbLdqrXbdoFPZbPzAJqgNPFZSELwStEslaOYmxxBLlxfPVpbBThASuYExALVvJFOFcWJkOnWVeHbccbVLZsHGSqnrlRtpFVDIpDKGGkmznGMUEgHoBiXuuvmykfOZjfRuvWSCuPSaLgpYnXGNyhD");
    string hlGYQVzvAT = string("jfczVkKUYETMLAJKkLiognUmXlIwJhFcHsILyhdhXbLFwLsUhCjXweWJGnteYCTvKpLTZXdNWRCiIuPCDcUYwhBtFiqarLRCqlcAselgfnyxrPiWFvval");
    bool VOLAndhcSjAeRS = false;
    double hRyUDFpQYPVrYD = -1039487.5432107262;
    int dmOdQDgIPW = 1466249466;
    double TgFgrWfTxyLHYv = -979115.8195157538;
    bool sMOMjimMXsZKuG = false;
    string jcRvDdwnZSH = string("nveHxtYxYafLOGiHDnvWdvKzCvbeDDsOGUvxaboOzssdQcproknSWSHQrscgsEDYLsARozLFnegALJMJLsUinWXiufOlaLBnDc");

    for (int gmGmtUibg = 293612514; gmGmtUibg > 0; gmGmtUibg--) {
        continue;
    }

    for (int WMpgbVhrBITOwii = 64522648; WMpgbVhrBITOwii > 0; WMpgbVhrBITOwii--) {
        hRyUDFpQYPVrYD /= hRyUDFpQYPVrYD;
        hRyUDFpQYPVrYD /= TgFgrWfTxyLHYv;
        VOLAndhcSjAeRS = ! VOLAndhcSjAeRS;
    }

    return jcRvDdwnZSH;
}

int FYRNBmGZoy::akLQYbAZG(bool ielTBHjLoc)
{
    double cYZJvZla = 759172.4040470066;
    double XJuRxxRNjbYu = -329419.6845564019;
    double HBANeaplHXdSNOMH = 737892.7504606764;

    if (HBANeaplHXdSNOMH <= -329419.6845564019) {
        for (int tmYrPkI = 238619934; tmYrPkI > 0; tmYrPkI--) {
            continue;
        }
    }

    for (int KulERNkcMT = 257609254; KulERNkcMT > 0; KulERNkcMT--) {
        XJuRxxRNjbYu *= HBANeaplHXdSNOMH;
        HBANeaplHXdSNOMH += HBANeaplHXdSNOMH;
        cYZJvZla /= XJuRxxRNjbYu;
    }

    if (XJuRxxRNjbYu <= -329419.6845564019) {
        for (int XdWwugJgYn = 1160768713; XdWwugJgYn > 0; XdWwugJgYn--) {
            cYZJvZla *= cYZJvZla;
            XJuRxxRNjbYu = XJuRxxRNjbYu;
            XJuRxxRNjbYu += HBANeaplHXdSNOMH;
        }
    }

    for (int xEYFruUNAhXzVW = 1991915766; xEYFruUNAhXzVW > 0; xEYFruUNAhXzVW--) {
        XJuRxxRNjbYu += HBANeaplHXdSNOMH;
        cYZJvZla /= XJuRxxRNjbYu;
        ielTBHjLoc = ! ielTBHjLoc;
        cYZJvZla = XJuRxxRNjbYu;
        XJuRxxRNjbYu += XJuRxxRNjbYu;
        XJuRxxRNjbYu = cYZJvZla;
    }

    if (cYZJvZla > 737892.7504606764) {
        for (int bvVUcHoaTNI = 1256653184; bvVUcHoaTNI > 0; bvVUcHoaTNI--) {
            cYZJvZla -= HBANeaplHXdSNOMH;
            ielTBHjLoc = ! ielTBHjLoc;
        }
    }

    if (cYZJvZla >= -329419.6845564019) {
        for (int nCXrF = 357130993; nCXrF > 0; nCXrF--) {
            cYZJvZla += HBANeaplHXdSNOMH;
        }
    }

    if (ielTBHjLoc == true) {
        for (int qnSMhTSiSeu = 576594400; qnSMhTSiSeu > 0; qnSMhTSiSeu--) {
            cYZJvZla = XJuRxxRNjbYu;
            cYZJvZla -= XJuRxxRNjbYu;
            cYZJvZla *= HBANeaplHXdSNOMH;
            cYZJvZla += cYZJvZla;
            ielTBHjLoc = ielTBHjLoc;
            HBANeaplHXdSNOMH /= cYZJvZla;
            HBANeaplHXdSNOMH = cYZJvZla;
        }
    }

    return -2098411439;
}

string FYRNBmGZoy::iiAJKH(bool FuhicBlsYZkK, bool BAznAtXZcbcfDDgf, bool fgRSnpUFT, bool aJgsJolEpcoaHPz, bool izrDvpKgFnBG)
{
    bool KwigZRjBE = true;
    string jAZsXlB = string("CCfNUCDlJIzhQIdPqoMqlOOCIhKHHTyddYCLuwdkocFpUJjuzIROiyDeXWkkgbqbHyqsJpTbfjSciDqComzZbhDxQSAjxHRXPWQQhhrzcaeQSdedeKBhGkoom");
    int jBbIAJhljxJHLV = -620690407;
    bool aUKdSR = true;
    string urtysCiIRVLI = string("vzYScjYTBsjrQBmwGccpQLChZObfiOnSIudXdPFdgZtqMZ");
    int WWkWSw = 461459658;
    string lIBsMKvrXKgvflEi = string("EbUsbVbzCjiyFuXpSDGGFkqVKVroHmhABlYPKEyfGmyEzOIBHEvjHyMeiWFkgONOUQjhxcEhjxbFBqPgPfwbawGRFPYZxniaZDxsAdevOEmkvgAiyuZXgnfCTKqSOMrAhDYlnWOwjYEXmmObfWciYcLnMfxYXZPebyJemqfSehoPVWQuUYhG");

    if (jBbIAJhljxJHLV == 461459658) {
        for (int aKECSamwB = 855285607; aKECSamwB > 0; aKECSamwB--) {
            jBbIAJhljxJHLV /= jBbIAJhljxJHLV;
            izrDvpKgFnBG = aUKdSR;
            aJgsJolEpcoaHPz = aJgsJolEpcoaHPz;
            izrDvpKgFnBG = aUKdSR;
            BAznAtXZcbcfDDgf = BAznAtXZcbcfDDgf;
            fgRSnpUFT = ! aJgsJolEpcoaHPz;
        }
    }

    if (FuhicBlsYZkK != false) {
        for (int ZFImtSKnPpC = 979486227; ZFImtSKnPpC > 0; ZFImtSKnPpC--) {
            aJgsJolEpcoaHPz = fgRSnpUFT;
            izrDvpKgFnBG = BAznAtXZcbcfDDgf;
            aJgsJolEpcoaHPz = aJgsJolEpcoaHPz;
        }
    }

    for (int dBmEpAfR = 537625717; dBmEpAfR > 0; dBmEpAfR--) {
        urtysCiIRVLI = lIBsMKvrXKgvflEi;
    }

    for (int kWMzADAnoOSpr = 562469391; kWMzADAnoOSpr > 0; kWMzADAnoOSpr--) {
        fgRSnpUFT = aUKdSR;
        aUKdSR = aUKdSR;
        aJgsJolEpcoaHPz = KwigZRjBE;
    }

    if (aUKdSR == true) {
        for (int yoGmGAEXzayPXe = 305484708; yoGmGAEXzayPXe > 0; yoGmGAEXzayPXe--) {
            BAznAtXZcbcfDDgf = ! aJgsJolEpcoaHPz;
        }
    }

    return lIBsMKvrXKgvflEi;
}

FYRNBmGZoy::FYRNBmGZoy()
{
    this->LdHYMpumfrLDjTOj(137521879, string("IttkObHLfiIjwNcqxKllLJJtsYfbuFYzdwSeDgDcDkrxAqMiPqtETrifXICagLcONLHnpPeGrbcxQzOojmNYGEyeHaZycDkLQOcFmnLQwZQAAghaynrAyYlMUEGFByOMITToCjfaBEkFuKesjwxnCWjtiJAKSvjKwCeQUjpnpDqLFVDyxTxsWEfgJrTLQOaEFBfhXORNZQGMUClpgXjVIhrPkPSdolqqXviGRLqVhpGGLklExYSICCDn"), -1923521883);
    this->AviWsFADmZJaCi();
    this->EkeKZ(1763296509);
    this->akLQYbAZG(true);
    this->iiAJKH(true, true, true, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VFhmCJLUlflEmUur
{
public:
    int mDLsdUZHwZTS;
    string eMVoGqwooLKY;
    double sKRwFN;
    double EXCjk;
    string iVZcxNeVyZGP;

    VFhmCJLUlflEmUur();
    int NDBgHmEESUqxx(int gwryQUToz, string TwJAO, double ZBPbDZoLishNOh);
    double VPZZbVVW(bool nwxWMEpzWb, int LKMdojBPAwU, double RhENHowX, bool QEOopqbY, int pNyhDBqMKZ);
    int vkokxsNxw(bool QvZnPXqirUYXy, bool Wzodg, double pdFAOzobzU, bool pdLuFMSKpYqjHI, string WsGYZsnRceG);
    string XfjHvfMuWvmeID(string AvwMOrJJ, int kSJKWocryM, double CquMMiIyYEJ);
    double VQDFFDNsghTsUXEr(int fFzvLPJC);
    string myuDoTPGwjQGndb(bool WmggAdRFLUb, string QLKJpFPiBsV, int BosvNHEPk);
    bool zKVleE(string KcHaBt, bool QvckbG, double rfrlyD, int fFzsd, int WMSMtoCAI);
protected:
    double tmjbyLOezWbO;

    int iWWFGNSWl(int vomaOlnxe, int UOtstN, bool BokDIrrNj);
private:
    string apDcuSDSVqc;
    double qIbSsFntl;
    string bRZgcemzWVsNAIv;
    double rlMlFqNRKd;
    int rYhFlpqgEpNsy;

    double JeivA(int qgoLsfaLiVdVUo, string TBMRzMLJTOAc, string KbpfknOj, int SBddA, bool cNaDLM);
    int fnsqjQzMbSxVqK(int TholYbI, int JBiqBtPVDRMsb, bool twYCeUcfUE, bool ewiVCRBOjU);
    void KUIMmJ(string pcnHTwz, double BVioJQcZkTeHmls, bool ADAkToaFqgr);
    int DUkNIg(bool FlfLttrJZFxmRzq, string iTvQDOXz, string EIWepasduJETUQMd, string cpZjv, double QjhFDFNv);
    void nsehtesqepcFRg(string XhwewznDHh, string HyHwoRuNaiyx, string EkoMznmoB, double wbanyhxPmZ);
    bool iyyiOnv(string PtULaNndRRdDOas, double aUFHc);
    string hgKVaKqRAY(string aCqMsEsfMoQ, int gMGIYdliXz, bool TVTwABNXWlwgJQN, string OxoPkJMIWWiEBaSi);
    double wbwbBr(string eswgFpsuV, int sxFWN);
};

int VFhmCJLUlflEmUur::NDBgHmEESUqxx(int gwryQUToz, string TwJAO, double ZBPbDZoLishNOh)
{
    string AczulTGo = string("gRKGlKbOtSWpCIaVfpZKFdHyrolNRxLXlGxoHpwOwGbAxNEpKGPZOpzozlCwAKNvOeHsd");
    double QQQMFuJeHB = -852613.100517505;
    double OCemVD = -895292.3136255444;
    string xnBxpgVipFPv = string("xOsJlCTsDFCHDlQMEdKIrnslktyLtlrKdOQJQsZcUjdDSOfvldDKdYEHXhTAZWlLuHrmoJIFFWRDBXNbB");
    string WjqhYRIYYCQvrDbn = string("pUSssflLOQFCuHDrdGTIBoYQTTYNcBRD");
    bool FHKDX = false;
    double tTJliu = -897077.6893943305;

    for (int SoPxIqGYqC = 1036916313; SoPxIqGYqC > 0; SoPxIqGYqC--) {
        TwJAO += WjqhYRIYYCQvrDbn;
    }

    if (gwryQUToz < -1131270009) {
        for (int CMFXCybOqhRtehuI = 135975595; CMFXCybOqhRtehuI > 0; CMFXCybOqhRtehuI--) {
            continue;
        }
    }

    for (int KFbltovHvBKojEKL = 948514520; KFbltovHvBKojEKL > 0; KFbltovHvBKojEKL--) {
        QQQMFuJeHB /= ZBPbDZoLishNOh;
        WjqhYRIYYCQvrDbn += AczulTGo;
    }

    for (int NAZSUNzGKg = 136120490; NAZSUNzGKg > 0; NAZSUNzGKg--) {
        tTJliu += tTJliu;
        TwJAO += xnBxpgVipFPv;
        OCemVD *= OCemVD;
    }

    return gwryQUToz;
}

double VFhmCJLUlflEmUur::VPZZbVVW(bool nwxWMEpzWb, int LKMdojBPAwU, double RhENHowX, bool QEOopqbY, int pNyhDBqMKZ)
{
    string LkqDssG = string("cyxxotYzcEpHRYoAzYgRLJRIYQmdhYBNRBWUFqeFRBbUUPLxlirNtmMLxGZaFtpxSKtAMSGdzpDxiEhIrvzRKcFqfcJxOqMSNwDkMHEgpXvihPdAbyFOUvRZEAfmDprxRxWvOZPFPMVTIBObAxIgfqIZtgizJEcIxxZkOtqtDZvWlUKIRJivhmozFcqKyztMKBBtRbHUkMIIigpFOLIvrnlSFOoB");
    bool gWtEQ = false;
    bool djetLY = true;

    for (int GDXGCfPwXq = 529797915; GDXGCfPwXq > 0; GDXGCfPwXq--) {
        continue;
    }

    return RhENHowX;
}

int VFhmCJLUlflEmUur::vkokxsNxw(bool QvZnPXqirUYXy, bool Wzodg, double pdFAOzobzU, bool pdLuFMSKpYqjHI, string WsGYZsnRceG)
{
    double xroBQnrnXfYqWlx = 1000240.4657173974;
    double CYHSUhnVuyJng = 496871.6719952619;
    int boYNEsHnlDu = -645152788;
    double vAblsLThJhues = 837461.3807277208;
    bool WIqYs = true;
    int KZSkubpkTPuodZgg = -1795231886;

    if (pdLuFMSKpYqjHI == true) {
        for (int heGUE = 1047130739; heGUE > 0; heGUE--) {
            vAblsLThJhues -= CYHSUhnVuyJng;
            xroBQnrnXfYqWlx *= pdFAOzobzU;
        }
    }

    for (int BMjdnAhlMZRyJW = 1490209228; BMjdnAhlMZRyJW > 0; BMjdnAhlMZRyJW--) {
        pdFAOzobzU *= CYHSUhnVuyJng;
        Wzodg = WIqYs;
        boYNEsHnlDu -= boYNEsHnlDu;
    }

    for (int GpWDyguBzCltIeP = 1110101319; GpWDyguBzCltIeP > 0; GpWDyguBzCltIeP--) {
        CYHSUhnVuyJng *= xroBQnrnXfYqWlx;
        CYHSUhnVuyJng /= pdFAOzobzU;
        Wzodg = ! WIqYs;
    }

    for (int fCXtG = 450318956; fCXtG > 0; fCXtG--) {
        QvZnPXqirUYXy = ! QvZnPXqirUYXy;
    }

    return KZSkubpkTPuodZgg;
}

string VFhmCJLUlflEmUur::XfjHvfMuWvmeID(string AvwMOrJJ, int kSJKWocryM, double CquMMiIyYEJ)
{
    int LeKPd = 336531794;
    string NtnCWoRLIjD = string("hYpeQspajiCLYaJMqbDvcYcqbrXUbyujLIdyipfWUqqECNEsicxLyqgLjLZoobIxIurkyTInizDfznOSfxdBomKKmPyBtZnRINeTmoSAKjOVZqbnfhsNBsjwe");
    int IuwuPSXLGLvVZCMU = -1030040576;
    bool tHxRMxZwHlbwdCn = false;
    double amThujgCaiCCtJS = -210516.39353999853;
    string oJiLyrldWqmSlfy = string("CkPiffmGmuqAXOQDXiDYIBeSCfdrvEXKqJIeAIyCfZCzXFvRnOanYIjtAINfXXCezbWMXYElgiYyOErzIfVclLkRsUNwiVitLQbePQFLPplxOvHmmknSWsIQAXxyENtruigZ");

    for (int rEudPeigr = 188773204; rEudPeigr > 0; rEudPeigr--) {
        continue;
    }

    for (int nTOaYwhWHLDsaNUq = 1363769410; nTOaYwhWHLDsaNUq > 0; nTOaYwhWHLDsaNUq--) {
        LeKPd -= LeKPd;
    }

    for (int pmwlvYn = 1944670629; pmwlvYn > 0; pmwlvYn--) {
        LeKPd *= IuwuPSXLGLvVZCMU;
        IuwuPSXLGLvVZCMU *= kSJKWocryM;
    }

    for (int ppMoeQUzOfnb = 2058863952; ppMoeQUzOfnb > 0; ppMoeQUzOfnb--) {
        NtnCWoRLIjD += NtnCWoRLIjD;
        NtnCWoRLIjD = NtnCWoRLIjD;
    }

    return oJiLyrldWqmSlfy;
}

double VFhmCJLUlflEmUur::VQDFFDNsghTsUXEr(int fFzvLPJC)
{
    bool raIcZaDjiMB = false;
    double UaxiIzSyMsNmnIXC = -95347.69721526178;
    double UAGzt = 585865.5799759038;
    bool ddiSxnkWFKFAAdNZ = true;
    string lgkRNoRbo = string("AIrPQfsERrWUiXGfZBTgJoHERqzwENPidRWspVpJNeqxYVjDWnxjLKocDzCFmNwfgcLDJTewBPPvyAwaVuEiwICfcwfbUeTZtjrGICgPrQUhUKTTTxDHqFuFJczJZxvKCWYMJUwezNzCipXJbHzyzDtrwNrJLLwxkqJGJ");

    return UAGzt;
}

string VFhmCJLUlflEmUur::myuDoTPGwjQGndb(bool WmggAdRFLUb, string QLKJpFPiBsV, int BosvNHEPk)
{
    double TxqadwwGwoJzWPJQ = -409452.5821635457;
    int VjQYzMr = -128653981;
    int kuOqrTFJ = 2010652802;
    string zaikKmPtkwclDzY = string("mbPqBrcLeNGPPmFeIzjKuMVAcwrDtGpQeWOHZptnIfwiHJjbBtWGqCBuPWrRTWlRXC");
    double LKcpRBXVpVJMHPf = -523444.4356830894;

    for (int owvLQLiGCTAAvx = 9266464; owvLQLiGCTAAvx > 0; owvLQLiGCTAAvx--) {
        continue;
    }

    return zaikKmPtkwclDzY;
}

bool VFhmCJLUlflEmUur::zKVleE(string KcHaBt, bool QvckbG, double rfrlyD, int fFzsd, int WMSMtoCAI)
{
    int bDTac = 1860419359;

    for (int dJwXeP = 1505299523; dJwXeP > 0; dJwXeP--) {
        WMSMtoCAI += fFzsd;
        bDTac += fFzsd;
    }

    return QvckbG;
}

int VFhmCJLUlflEmUur::iWWFGNSWl(int vomaOlnxe, int UOtstN, bool BokDIrrNj)
{
    string oVLLghRsaYI = string("KpgVbMqvEEdNSMLirZZJIyykLjyIJohzcOjbpzorAOuLqOoWIxEyFMkrSrqiHDDwwCgUhslVNkWZfcTNRfwSEDkONPqBYgTRKcECJAylKIlEXTDYKMjUxjVcBUPHjWkTCSZkWReIJoloZeVIeBMjuNgVhEMaKlGKfcyzy");
    string WcFJLTbkByDW = string("MlRwOhryGuosMPfNCsOZvcNHKHMIYkYRgOFXgWhfQRapQHNWBPQGpGxuOQVdWmXMuSZlSThrfUDMkcRkzLOxQlAwCodKHNVukgOPwpjmJthlykowlMdFaibhQCECXzyWPwWlJUCaNTZJXxNNHjtYctamjQJEGRKXJuKNyAjxAFCBTZGNsTeBpbhHcvzFF");

    for (int BCkZxvgUweyCBPp = 1386777875; BCkZxvgUweyCBPp > 0; BCkZxvgUweyCBPp--) {
        oVLLghRsaYI = oVLLghRsaYI;
        oVLLghRsaYI += WcFJLTbkByDW;
    }

    for (int cvkitTUZVyep = 1482015499; cvkitTUZVyep > 0; cvkitTUZVyep--) {
        vomaOlnxe *= UOtstN;
        vomaOlnxe /= vomaOlnxe;
    }

    for (int OXQvWifIqbJoz = 873936390; OXQvWifIqbJoz > 0; OXQvWifIqbJoz--) {
        UOtstN *= UOtstN;
    }

    if (BokDIrrNj != true) {
        for (int YMZTG = 624836710; YMZTG > 0; YMZTG--) {
            oVLLghRsaYI = WcFJLTbkByDW;
            WcFJLTbkByDW = oVLLghRsaYI;
            oVLLghRsaYI += WcFJLTbkByDW;
            vomaOlnxe -= vomaOlnxe;
        }
    }

    for (int XuTSQel = 629042707; XuTSQel > 0; XuTSQel--) {
        vomaOlnxe = UOtstN;
    }

    for (int EOkaGYcxn = 1899280796; EOkaGYcxn > 0; EOkaGYcxn--) {
        BokDIrrNj = ! BokDIrrNj;
    }

    for (int rIUtdBRUuXWWTIhG = 692520229; rIUtdBRUuXWWTIhG > 0; rIUtdBRUuXWWTIhG--) {
        vomaOlnxe *= UOtstN;
        UOtstN -= vomaOlnxe;
    }

    return UOtstN;
}

double VFhmCJLUlflEmUur::JeivA(int qgoLsfaLiVdVUo, string TBMRzMLJTOAc, string KbpfknOj, int SBddA, bool cNaDLM)
{
    bool EEpugUsgfRajNcs = false;
    bool bJRTJqee = false;
    double agsWorTyVdjjZZtF = -881888.1837615548;
    string CyzrfYJwrA = string("SMJiqClHEh");

    for (int qcIBSzGpwq = 1869119609; qcIBSzGpwq > 0; qcIBSzGpwq--) {
        continue;
    }

    for (int svRFRXRgwcxXCOs = 936701769; svRFRXRgwcxXCOs > 0; svRFRXRgwcxXCOs--) {
        continue;
    }

    for (int jBHjTnrrOlzQSH = 468150568; jBHjTnrrOlzQSH > 0; jBHjTnrrOlzQSH--) {
        KbpfknOj += CyzrfYJwrA;
    }

    for (int KrEggohJx = 1877258917; KrEggohJx > 0; KrEggohJx--) {
        continue;
    }

    for (int CFyYIVPgoOZAUa = 1272890623; CFyYIVPgoOZAUa > 0; CFyYIVPgoOZAUa--) {
        CyzrfYJwrA += KbpfknOj;
        bJRTJqee = EEpugUsgfRajNcs;
        qgoLsfaLiVdVUo *= qgoLsfaLiVdVUo;
        KbpfknOj += KbpfknOj;
        TBMRzMLJTOAc = CyzrfYJwrA;
    }

    return agsWorTyVdjjZZtF;
}

int VFhmCJLUlflEmUur::fnsqjQzMbSxVqK(int TholYbI, int JBiqBtPVDRMsb, bool twYCeUcfUE, bool ewiVCRBOjU)
{
    bool kzeSJnkLytaZu = true;
    string EAokmThaHOBbyi = string("ewMDEzrAMRYUflRhNNkvtcPofeaiMjKLeAmuxZ");
    int LUzGEkplTNm = 1667055729;
    bool hTDvwOZwKR = false;

    for (int Guois = 269985317; Guois > 0; Guois--) {
        ewiVCRBOjU = ! twYCeUcfUE;
    }

    for (int bRSIzRSJCZz = 932675921; bRSIzRSJCZz > 0; bRSIzRSJCZz--) {
        twYCeUcfUE = twYCeUcfUE;
        ewiVCRBOjU = ! ewiVCRBOjU;
        twYCeUcfUE = twYCeUcfUE;
        EAokmThaHOBbyi = EAokmThaHOBbyi;
        ewiVCRBOjU = twYCeUcfUE;
    }

    for (int QbbVOx = 1535291698; QbbVOx > 0; QbbVOx--) {
        JBiqBtPVDRMsb *= JBiqBtPVDRMsb;
        JBiqBtPVDRMsb = LUzGEkplTNm;
        kzeSJnkLytaZu = hTDvwOZwKR;
    }

    for (int yvVIUGwloLXOGvfT = 80489887; yvVIUGwloLXOGvfT > 0; yvVIUGwloLXOGvfT--) {
        twYCeUcfUE = ! ewiVCRBOjU;
    }

    if (twYCeUcfUE == false) {
        for (int LPqNYpGm = 1181427375; LPqNYpGm > 0; LPqNYpGm--) {
            ewiVCRBOjU = ! hTDvwOZwKR;
            JBiqBtPVDRMsb += TholYbI;
        }
    }

    for (int hpgKlUjPOjbYi = 370440254; hpgKlUjPOjbYi > 0; hpgKlUjPOjbYi--) {
        JBiqBtPVDRMsb -= JBiqBtPVDRMsb;
    }

    return LUzGEkplTNm;
}

void VFhmCJLUlflEmUur::KUIMmJ(string pcnHTwz, double BVioJQcZkTeHmls, bool ADAkToaFqgr)
{
    double BxSaPIWXz = 992690.4374988946;
    string XhFOSQLutzvqD = string("jLPEZfsiIXteCYuvNEypcPnVOELbBbQkxiaKkWkACwOXnuOcbIVenffdqOtrgGYYXHlzIUgxXFyDUbZFBJnyTtKipnuTHlydfJZdFOOIcv");
    bool eZwsxhIspyAinvbL = false;
    int JjOwloOeFmgwW = 916871279;
    bool AUTfOjZ = false;
    int GvHcQkCODEIana = 1189156633;
    int jElHCmsZbhBC = 256856450;
    bool IPicq = false;
    double fhGmWmFeYtIAaxI = 712727.955564433;

    for (int ZPkCSPmRXwQvpF = 245409014; ZPkCSPmRXwQvpF > 0; ZPkCSPmRXwQvpF--) {
        fhGmWmFeYtIAaxI += BxSaPIWXz;
        pcnHTwz = pcnHTwz;
        jElHCmsZbhBC += JjOwloOeFmgwW;
        pcnHTwz += pcnHTwz;
    }

    if (eZwsxhIspyAinvbL != false) {
        for (int TPijwKFOw = 1747965479; TPijwKFOw > 0; TPijwKFOw--) {
            continue;
        }
    }

    if (pcnHTwz >= string("jLPEZfsiIXteCYuvNEypcPnVOELbBbQkxiaKkWkACwOXnuOcbIVenffdqOtrgGYYXHlzIUgxXFyDUbZFBJnyTtKipnuTHlydfJZdFOOIcv")) {
        for (int tYZUuXIQrSTwSzeK = 664331065; tYZUuXIQrSTwSzeK > 0; tYZUuXIQrSTwSzeK--) {
            JjOwloOeFmgwW /= GvHcQkCODEIana;
            jElHCmsZbhBC *= jElHCmsZbhBC;
        }
    }

    for (int oCqpUneCGOQ = 1852264990; oCqpUneCGOQ > 0; oCqpUneCGOQ--) {
        continue;
    }

    for (int oiKKZEscqFpPbRuX = 685876399; oiKKZEscqFpPbRuX > 0; oiKKZEscqFpPbRuX--) {
        IPicq = IPicq;
        GvHcQkCODEIana = jElHCmsZbhBC;
        XhFOSQLutzvqD += pcnHTwz;
        JjOwloOeFmgwW /= JjOwloOeFmgwW;
    }

    if (IPicq != false) {
        for (int Elbohrm = 1144548778; Elbohrm > 0; Elbohrm--) {
            ADAkToaFqgr = ! eZwsxhIspyAinvbL;
        }
    }
}

int VFhmCJLUlflEmUur::DUkNIg(bool FlfLttrJZFxmRzq, string iTvQDOXz, string EIWepasduJETUQMd, string cpZjv, double QjhFDFNv)
{
    double wxvFYDqKtIOIh = 206764.55943450882;
    bool nnyZHPjXuT = false;
    bool uBfVpvuBcEpEIWyY = true;
    double DVWdjfGwdpflbzzW = -536949.40077734;
    bool AulFglHmtmrtHMe = true;
    int OGcsU = 1631521383;
    bool viyIEQRCcsnga = true;

    if (DVWdjfGwdpflbzzW != 206764.55943450882) {
        for (int ovZgSvvWvHYz = 421181647; ovZgSvvWvHYz > 0; ovZgSvvWvHYz--) {
            cpZjv += cpZjv;
        }
    }

    return OGcsU;
}

void VFhmCJLUlflEmUur::nsehtesqepcFRg(string XhwewznDHh, string HyHwoRuNaiyx, string EkoMznmoB, double wbanyhxPmZ)
{
    double keXdGXYd = -167799.29500205236;
    double NUChZBFaQD = -412572.57827899983;
    double DHdbfGK = -593358.953747716;
    int ISFyvfRQOihKmz = -2126642616;
    string DxZGXltu = string("aQHrFTLmlBKqwOdvNvQeGooPLiYNphgsDsdqzVLgvRwVsNfPkKcDcYLcgKPkdDTBBinrZKbmUPzrOVDLgyUpSoXjiwzSsVDVIJZMMoGifYfjaawRyjhGyXElMWvMmPHHjPxdzGSducLaZDrbgrlaYDZGIgFiRHjNotOCWTgrtdUxnSNJjrkuxSdmwRWiNBFvRCuJLqavAYKwmzLOiMqNXLxvngNvdekjyADbxrIPQzHEHIiUbiqaMLLUD");
    string QXqMH = string("NAhuKGuScJYkniNcJceNAQnaKIeVUfYNeolgkOsFovsccpAzeTRmSAHXpZccHvxbOfIJYUaRInnWGpQPtMyOhRMOsfWUurTnGxwRykWbKxFLOMiMzLkFiUWqVfYemrjqyyJMXVBdkHRTLLmybMgQIUCPltfzcjUGTNJGPRXMCmipMvlAyetqEaLOAdC");
    string NVzNZOzXR = string("oGyXtMFNwHwMfAXEupjxailpogcSSFqJYRpgKORYuTlxAePCLDNRzDFZAqPgXRtdoPMooGbsNdvuMtgaIRBixokgQQyCGcfmvJQIiHyYwnpkaEUjmcvQdWAzXDQBXyjGaxZQiHYrkdsxovyJZdGtnwUekfMyBjPVhfDATtKbwlUzgvvSIGwrZWIPZPTyswNamvMLKBJBVeHjBUMHriCdM");

    if (XhwewznDHh >= string("aQHrFTLmlBKqwOdvNvQeGooPLiYNphgsDsdqzVLgvRwVsNfPkKcDcYLcgKPkdDTBBinrZKbmUPzrOVDLgyUpSoXjiwzSsVDVIJZMMoGifYfjaawRyjhGyXElMWvMmPHHjPxdzGSducLaZDrbgrlaYDZGIgFiRHjNotOCWTgrtdUxnSNJjrkuxSdmwRWiNBFvRCuJLqavAYKwmzLOiMqNXLxvngNvdekjyADbxrIPQzHEHIiUbiqaMLLUD")) {
        for (int WeUdNnFwx = 158671182; WeUdNnFwx > 0; WeUdNnFwx--) {
            wbanyhxPmZ -= DHdbfGK;
            DHdbfGK /= DHdbfGK;
            DxZGXltu = EkoMznmoB;
        }
    }

    for (int VIywrvm = 11096997; VIywrvm > 0; VIywrvm--) {
        NVzNZOzXR = DxZGXltu;
        NVzNZOzXR = QXqMH;
        HyHwoRuNaiyx += NVzNZOzXR;
    }

    if (EkoMznmoB > string("aQHrFTLmlBKqwOdvNvQeGooPLiYNphgsDsdqzVLgvRwVsNfPkKcDcYLcgKPkdDTBBinrZKbmUPzrOVDLgyUpSoXjiwzSsVDVIJZMMoGifYfjaawRyjhGyXElMWvMmPHHjPxdzGSducLaZDrbgrlaYDZGIgFiRHjNotOCWTgrtdUxnSNJjrkuxSdmwRWiNBFvRCuJLqavAYKwmzLOiMqNXLxvngNvdekjyADbxrIPQzHEHIiUbiqaMLLUD")) {
        for (int TlVwHoj = 448946224; TlVwHoj > 0; TlVwHoj--) {
            DHdbfGK = DHdbfGK;
            NVzNZOzXR += QXqMH;
            DxZGXltu += DxZGXltu;
        }
    }
}

bool VFhmCJLUlflEmUur::iyyiOnv(string PtULaNndRRdDOas, double aUFHc)
{
    int QQFSiNYOoclzdwqx = 1865045431;
    string PHgaOizYeQF = string("GPHGVZxPktGwYDAZywovxFvKoasKwFbmJeADNwPGcOpkqCLNnXuyKIScmRwEHPsVSfWAhqcvbxoqAWvRVtnnuZjjGjQukHZWAEhjtaSjkRPxvhAerMmgxVvQTxDblXxKKuImedENvRbAdXIZohlqhGUxSDhZRotxcvKe");
    int nLjmvXhszRIVvA = -643430406;
    int QPhPfxzK = 118748467;
    bool rlZcMuUToOWB = true;
    string ZqFoLLnlQFKpfAK = string("kdceKYLATqnxEdYpVqWXBpPhzSUhtIREpLRKISVkLbsTkaHzWDIPNvPdxxluMrPejhyuyFETunSMeWFtqvcmxLbdCWvfoYaGUyTBEhwoAqFoPxuqiiJtrOfedPDiFgFGTFVwmjggzsqmTFbcjcRoaTmSTTxpqLsuaCVedxTPvMxpTEflvrFqpewCPEJvfFOKfndDJFfgDsIsQWnWeafqSrNZdCQQllWRSqribMKrbrs");
    int DcHAnsIr = 1955266276;
    string PevXQQ = string("keHchLqBpoXepyPeRDnEiWqnxIfFVuFeXKtQRHiGPUCPNltBv");
    bool EYuyHBFgGxR = true;

    for (int aHHWVeYB = 238991759; aHHWVeYB > 0; aHHWVeYB--) {
        rlZcMuUToOWB = EYuyHBFgGxR;
    }

    return EYuyHBFgGxR;
}

string VFhmCJLUlflEmUur::hgKVaKqRAY(string aCqMsEsfMoQ, int gMGIYdliXz, bool TVTwABNXWlwgJQN, string OxoPkJMIWWiEBaSi)
{
    string CYPqizhakpwNy = string("vaiJLfbAPvaBAmvbOiqYbVbqPPKZUUzgTANUapszjeWJJFDRAMyfJyZdWYSOjTxlsdeIKCanQaAgjAixKZIAZiZWHvlktJrbnfyJvXYCmksmtGTjIetYtPyGSUgIjQxzTqnwopmJUfrzkIdsZLZfdCmXhqmUrlzLJInJDvoDnIAiqklWzdsIgYBcErgdOhwslnMjxmTkzmHvYYGVZj");
    string RsmJtjUvsdNV = string("swXunHdjCbZykVvZoifgFMdUkEumbbMyrymOswyQXoEzcfeGuGTIOmgBhpeUSOuEokJOvblSQRIZJIzddWJTQrzRGmiJkoCJxoKqpCQzQsjlyLhTjUrPmrPcfIFDRyuOHjodvPVMeLBsyJYpcaXZNRBfnbjkwVIqwAHNpfBNF");
    bool ynZosrXWgiZjwM = true;

    for (int iGOxXKkW = 104392158; iGOxXKkW > 0; iGOxXKkW--) {
        continue;
    }

    return RsmJtjUvsdNV;
}

double VFhmCJLUlflEmUur::wbwbBr(string eswgFpsuV, int sxFWN)
{
    bool SgHHlhgchfRa = true;
    string tpRhlAhzSAWMEW = string("KTy");
    int ObfltTl = -1729140356;
    bool MZifrx = true;
    double cJekBpktENf = -164658.98872108312;

    return cJekBpktENf;
}

VFhmCJLUlflEmUur::VFhmCJLUlflEmUur()
{
    this->NDBgHmEESUqxx(-1131270009, string("zYDkWBQVBdTczTklAhKnKMAoCXkkVBVNqWopTZoXfuuOaLurHWLabjFUvkeJqcLugrykDcpdWJgWbsbXcExityTGgjrTmNQUDsrMyThFRTIsMuUZzAcgrqVDcTdbXuLsZkhbhSEsLXPcEXmbZixtTzsEMAyfItdmyQIJWnHaXtMYetGcLzgfvwFYjSaySUNqIfLLeUxuqwvlIYxNEXCpb"), 389706.9313739757);
    this->VPZZbVVW(false, 1217126182, 855844.4661367373, false, 1058200146);
    this->vkokxsNxw(false, true, -495479.0876454921, false, string("OMekiGXrOwJkzJBAISdxmJhcYsbNYKKPmvACuzpkDKFDcOHHeThTHMnsPEVYDSjOSxBQlmwvGCkaLtEIjaykjEeqzwFkzZELkeWsDHeNuhfxJPWGAVmVsdChsTjCfnbduNUSWbUnrPeYrAntreO"));
    this->XfjHvfMuWvmeID(string("jigAXUFDFiHnDBtXtKebvz"), 2139858590, 494474.6482084926);
    this->VQDFFDNsghTsUXEr(1525775991);
    this->myuDoTPGwjQGndb(false, string("pzawtwjyXWPNcOBeMEunbTDuffWDXijFxDMhaLewUszQWuTIlnYAcftcRojGpjFJEjKcKTaYJloxpfqydSSHhrTeDonoLbgjiDCSFPxqeUZhLPbvBcOITHVynWHaEPBxYVouVIHeQaGVCkWcQChklxcCiaxIDxycBQLYMcsNxKraxIgSOsTZzGUvaNkYrZhjVcmMvieWJGJpVPonhwTHLZVOxpeaWAZUSUCrgrEuy"), -1212335431);
    this->zKVleE(string("SJMLbxpMFdtqbXyfrDHwokBFsQOgG"), true, -304810.54794526636, 742329071, 1097915801);
    this->iWWFGNSWl(1013689379, -1575925078, true);
    this->JeivA(241516971, string("VfFsdUkxnRtrmhHRqICLfkMfeLektWThzOXILjKhPhhguUOpmhYxZOIKLLJnweTeQaUknWJAYWIQhEoKdVGCtLQavSUypTfYBJDKXguhugrHwtilRgZeBLcSBekPBmaPvLVHIQnNIJBWNWPlclUBikBPmeqLHgtGhbUKeGNNBjKoJdojPlXCReQaZLVGbxiLRQzKTXgOaJ"), string("YIVhHswYpavzdNmOTKnknIiUyOBlmQlQIgrFYexJTTLbauFfrorpvAsAvXikwEODRoXLT"), -1945465834, false);
    this->fnsqjQzMbSxVqK(1970881620, -1506081389, true, false);
    this->KUIMmJ(string("ZnyaLeacWOWrFfSnAHxsODfMxTrFFAwKyTGdPRbAVesZSHVUqTshTTUVxtNbBdnYCZPbEoliuenhDhNxsEjJnEdkWPgxeNSGzrZRGijdlcGGMLeadjLGocmpswumQOJfalkuNmr"), -458962.35025466833, false);
    this->DUkNIg(true, string("EdMKxmlkFqJKfAZYNTlexuEGkhmpQCFEVdvTnkdlwUXiCDJrUnIRcfbadxIvFZWISzvqJLuvOwpWCYBWIMDmigMHRzPJbIPkyqIAhVQMujuThZAEjSnYQuOJeNZWydmBMeIYKEXitHOINmwkSuFxQWpHIRfaKerQcoxvzjPFJShqrTCZUeqToKxjKAGoPFehWfPAvMzLoCiMvOwagCbbuKzKVjk"), string("xRgyaUAbhSklZdQEPbflmNejEGzlwVQwHxMDLXiDZnBajPFPUQjDiQvtrwRsiztIiJNzEBtJcAtgPEnvfvxlHKKRjmBOfbaklbnLlDRegarynEVTjPOqzeZaFIkHSrXnFMXTITlnnExAsPtPdWRUcfvFzqwlvyHffmwDHKEjrXGuOGcEoqImwcHQNudMIasRFJqdkhhCTQatzAHElDXMVigkPBIEhLDoHfzMZnRnUXdBqnbFprga"), string("RCTZLOcHeJIobKbdrXpAojRdZeIVpNHasZgrHljpqxUSLzuEWVTMfkicyVPGgSAgXAccEwDKpdQcwrxUAhFzDYtFGsdzMBvwQHsmNlOedlJL"), -236395.111382773);
    this->nsehtesqepcFRg(string("aFqnOxSgkxqackVfggzihaNfMubrmiVHNgECQJfAzUVRINgEzHMqeGXkwzCElmcDFFfXJkuWWHPLvLZWwgHtUHSNsecVFJokNtBbDEbPqFtgreDcqpnRAWC"), string("bRtdjTKMVzhbKfbdMFtJnQSGvOhtwfeGeymynAwiZfemjBfpokTNpzOfoKvSrAyDngXgCgJGxxnMUOzRzhWOztVoXZmTutdNNOYBLpbmVCspsLFHDHbWUOKtgHMbabupqVtTbKx"), string("adukUTxEhWQghclHTVAdwCNEjUbvvCjvAWULNkhlLuarBxpazihfdtFGvOxYPLRKXqbqFbAIlvYPROeXkzXEiWiCosFLOLZxRGClNFgz"), 677114.5045483173);
    this->iyyiOnv(string("xmkKHJyLwYAvochtyiWOnJBuOvhUL"), -199751.12143039276);
    this->hgKVaKqRAY(string("gmEuQFvufevYujGcSoCSmJPzRkPEjBdnnDPovxXzMQMXPozwtHBnggGCBrBRCqSHnTmjqmYjcjxOYLRGFjPZSPVvFthWqcPskOTuZZTAPRNaOrIZwBDafqStVWlZksoClZQYPNTSVTmfhNfImmwZimzQsWRFQoMWEwitNxKyraWuEPwTZXthFUwvIYoynqXPbCCOMKdtSTBNSVTdfZiyhLKtczyGqTSvPG"), 1166269255, true, string("rWvvFfTiavDtkNdjsrBqQJucJgXyrrTmyTRhSuFYdEwiLeMDkiSmeZiYdekFyCMydCNjJcvCRQNkqbCOBGxxaVVCvLJnnk"));
    this->wbwbBr(string("LVOHWFvUfDcEcSsrJvjuuraTKzDQotxsWcdefPTttkepxkNuZwopDRObLBUmOt"), -369043956);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rWKxgme
{
public:
    string vXkiEqCaoSLKgd;
    string EJmufTHHDbloyG;
    double HbtVbD;
    double xiBNeP;
    int VHefPSOdrCxDkXg;

    rWKxgme();
    string XltlBmQJEQhLJrQ(double mXcSCzVeujpl, double QFXgsp, double rQnSMsQcS, double bhmcD);
    double anPjK(double jifNUQeFI, bool mPgIWIQndV, bool OxZKQiE, string VuhaoMSPxtU);
    string lZCHKdTzHHo(bool QgQOZEViViPB, int SZijDHQxmRzfAdHa, bool oZxgrz);
    double PTeECMNmTh();
    double CMfDgo(string PDIPwHCWGe, int hPSwSZSHQPSTJ, string wPUxCvYoJFtsgIeM, double fMyosRzmINstoi, double tGNxuaJS);
protected:
    bool FHBhlNMuIOrxXvkI;
    string yNWHoDJiRjAFEMLY;
    bool DZXFuL;

    int ZaInTmEhYYNAtX();
    int OyoIbS(int krLQOwjT, int PtxFxTwFbpjgvtu);
    void DKlPVOpZeStrBG(int lZpszcoPBgnyU);
    string krLtIcjZcBjOR();
    string GyVEj(string ciogYVglAmItIlxy, int OWsDieesmIJKMPgA, string tazjjVAaQDQqk, string bFatg);
    int syMPb(double fNaSBxgkzkoR, string rvBiUp, string iyFqDilYoPReZX, int ypuhc);
    string ckJXuPuVTRt();
private:
    double NzfZTTNxiAFjlLBV;
    bool PSOFqmiLKm;
    double KjfTGbaw;
    bool FTIDIvYgjVyIwyvw;

    int LRcdCVksEwganQ(double utHyx, double ULyuhDIApUzMDea);
    string uEzAzHSEdlSsxjj(int ABgxJVdgSQbkSygn, int boPTcLbS, bool SBaeParHBKWOUN, bool QFdjdYA, double aXVfWf);
    bool DTXnGnAgRsEtVJb();
    int HcEFcYjEszut(string mnibXpPxdhXJN, double zPiaHoeeqZo, bool xnejTEc);
    int TAIZXlaYJMskAP(bool zjauMdkmBTrq, string IDxVfyftRa, int PNqLReHui, int KwFEDIqGHgwvdBuH, bool ckgTgBzAN);
    string gxPWHe(bool WeNSbyACMSP, bool oOIsTydS, string MayFsEv, bool stVkdgb);
    int DwdwuB();
    double UqeEs(string DNZwjOL, double PHGzxvVJ, int xecAWd);
};

string rWKxgme::XltlBmQJEQhLJrQ(double mXcSCzVeujpl, double QFXgsp, double rQnSMsQcS, double bhmcD)
{
    bool qTQXhKLZMNp = true;
    double qwTeEbxm = -421338.4163302812;
    int zhrvPJJ = 1420895541;
    double PSUkwEzErQVjI = -902609.3102544086;

    if (rQnSMsQcS == -482280.11295791046) {
        for (int WLjFRpFVuG = 2079518627; WLjFRpFVuG > 0; WLjFRpFVuG--) {
            mXcSCzVeujpl = rQnSMsQcS;
            QFXgsp *= mXcSCzVeujpl;
            mXcSCzVeujpl /= rQnSMsQcS;
            QFXgsp *= mXcSCzVeujpl;
            QFXgsp /= mXcSCzVeujpl;
        }
    }

    if (PSUkwEzErQVjI >= -464004.95911682706) {
        for (int WonkL = 147200790; WonkL > 0; WonkL--) {
            qwTeEbxm -= mXcSCzVeujpl;
            PSUkwEzErQVjI += mXcSCzVeujpl;
            qwTeEbxm = rQnSMsQcS;
            mXcSCzVeujpl = bhmcD;
        }
    }

    for (int QGIinKhiVhx = 882920808; QGIinKhiVhx > 0; QGIinKhiVhx--) {
        QFXgsp /= qwTeEbxm;
    }

    for (int HUojBVZqaiFRc = 746129841; HUojBVZqaiFRc > 0; HUojBVZqaiFRc--) {
        rQnSMsQcS += PSUkwEzErQVjI;
    }

    return string("DuRMNIOitcwUuIDODhIHXBHSQisvFcPfJogCGQIltXeXewnbZQrKlXVQOcRJoTKCjCSbyjPNqllGsMByHpGnZgBOzEFbMxmkyqbOiljwnXNwgrbMY");
}

double rWKxgme::anPjK(double jifNUQeFI, bool mPgIWIQndV, bool OxZKQiE, string VuhaoMSPxtU)
{
    bool WxKvogolxgq = false;
    string kaHHAGYytcvXsH = string("tbhdAGurKkTNgPUUwRchHDqVmnvNBRwPocPVjOtosvRcfHmZCDIMfOaRQnJryCWaRPifvgFwGpmmvcAJSdTECDXiJWiVsUDaufIPfaXJWYibvnaKwJRnPHcdLXFXNjGNipxhOMItOCkupAdTOktTPIIzpaTeoKISAKinKqjBCFkbGrkIMCRVTsCblQnWWnrDPogPGwQHvztyAmPoEsUtlWfjsoIBURggBhyZEmupXgkfpgxLUeqJvPo");
    bool etNEfkHxO = false;
    bool NWloPLnvEYMvO = true;
    bool OANEoRRV = false;
    int bAKYHRAEsZkEbUD = -545575354;
    bool iQFHPOsNGMArpX = false;
    int rLcowpChcV = 294783430;
    bool jKpwuscQDPiic = true;

    for (int cDAyrUFOduOMJE = 701339860; cDAyrUFOduOMJE > 0; cDAyrUFOduOMJE--) {
        rLcowpChcV -= bAKYHRAEsZkEbUD;
        OANEoRRV = ! jKpwuscQDPiic;
        OxZKQiE = OxZKQiE;
        iQFHPOsNGMArpX = ! OxZKQiE;
        bAKYHRAEsZkEbUD *= bAKYHRAEsZkEbUD;
    }

    return jifNUQeFI;
}

string rWKxgme::lZCHKdTzHHo(bool QgQOZEViViPB, int SZijDHQxmRzfAdHa, bool oZxgrz)
{
    bool IItdZvGpmTQRrrh = false;
    string AzfGpQbU = string("LKdbutVEfjQFmHnGlPadxCEHUAlMjmaGfSQbfXQuMsCtjhmymkdzauaapGrwZBjetUrbgHrkvnevuFINmhzQtakDPCFJBqobwstVDYyHZFbxpxvwgt");

    if (oZxgrz == false) {
        for (int DcqtlhphEXWg = 711702118; DcqtlhphEXWg > 0; DcqtlhphEXWg--) {
            QgQOZEViViPB = QgQOZEViViPB;
            SZijDHQxmRzfAdHa /= SZijDHQxmRzfAdHa;
            oZxgrz = ! oZxgrz;
        }
    }

    if (QgQOZEViViPB == false) {
        for (int SBVTcwtm = 1453407879; SBVTcwtm > 0; SBVTcwtm--) {
            oZxgrz = QgQOZEViViPB;
        }
    }

    if (SZijDHQxmRzfAdHa == 767523887) {
        for (int PYLmcOm = 555461958; PYLmcOm > 0; PYLmcOm--) {
            QgQOZEViViPB = ! IItdZvGpmTQRrrh;
            IItdZvGpmTQRrrh = ! oZxgrz;
            IItdZvGpmTQRrrh = QgQOZEViViPB;
            QgQOZEViViPB = ! oZxgrz;
        }
    }

    if (SZijDHQxmRzfAdHa <= 767523887) {
        for (int gqnXPBttlWUJmTG = 2018021368; gqnXPBttlWUJmTG > 0; gqnXPBttlWUJmTG--) {
            QgQOZEViViPB = IItdZvGpmTQRrrh;
        }
    }

    return AzfGpQbU;
}

double rWKxgme::PTeECMNmTh()
{
    bool GZubLD = true;
    double sfMkzqRHtGtMGSH = 397371.7540374536;
    double zXEHQaeujmo = -772568.9467874742;
    int PzDTztlmDlvC = 2062992895;
    double wwTTrswGTAPuSVZ = -949049.0029626836;
    double kVtlCnBKYXNp = 168066.44274643567;

    for (int YCSVqOewSq = 2039733587; YCSVqOewSq > 0; YCSVqOewSq--) {
        zXEHQaeujmo /= wwTTrswGTAPuSVZ;
        kVtlCnBKYXNp /= sfMkzqRHtGtMGSH;
        kVtlCnBKYXNp -= zXEHQaeujmo;
        wwTTrswGTAPuSVZ = sfMkzqRHtGtMGSH;
        sfMkzqRHtGtMGSH -= sfMkzqRHtGtMGSH;
    }

    return kVtlCnBKYXNp;
}

double rWKxgme::CMfDgo(string PDIPwHCWGe, int hPSwSZSHQPSTJ, string wPUxCvYoJFtsgIeM, double fMyosRzmINstoi, double tGNxuaJS)
{
    double ulHax = 185325.1759520813;
    double uooCJSyZ = 796451.6364050378;
    int fZPjyLrpowQE = -698438996;
    bool FJyJI = false;
    double XGEtfk = -937263.549858122;
    double SuAHVGKGlbmBmVmq = -367999.28456229746;

    for (int bJYEIWqAvbte = 1904229470; bJYEIWqAvbte > 0; bJYEIWqAvbte--) {
        ulHax /= fMyosRzmINstoi;
        SuAHVGKGlbmBmVmq *= SuAHVGKGlbmBmVmq;
        FJyJI = FJyJI;
        uooCJSyZ -= XGEtfk;
        SuAHVGKGlbmBmVmq -= SuAHVGKGlbmBmVmq;
        SuAHVGKGlbmBmVmq /= uooCJSyZ;
    }

    if (ulHax < -937263.549858122) {
        for (int ELLopBCu = 1086909984; ELLopBCu > 0; ELLopBCu--) {
            continue;
        }
    }

    for (int uGGDowtr = 417945220; uGGDowtr > 0; uGGDowtr--) {
        XGEtfk /= tGNxuaJS;
    }

    if (ulHax > 321964.12952377787) {
        for (int AqrfmmSXbvwEBZ = 692193205; AqrfmmSXbvwEBZ > 0; AqrfmmSXbvwEBZ--) {
            uooCJSyZ = uooCJSyZ;
        }
    }

    return SuAHVGKGlbmBmVmq;
}

int rWKxgme::ZaInTmEhYYNAtX()
{
    int KesurgLzFMHmPy = -1107625441;
    double qRJoTjhOacZ = 712506.5779811431;
    string HnIpSxluiYFujpHL = string("UBVPtfupIFvfqxrDQAXQeoLUWwvOqKgtFOUZhlJodzpygHzyfsbtugAFcrZnyxcnseLglzhgZhqOgdSRJokWisesCWnWiOANxInyoWkfNGklfLnSQYfEXrtIjZ");
    string eFXvUcPcloWiOA = string("jsnmtLWIazcvhzrVIAFfGhPXoMTQWTLvSUDfnLSSbQzMdHKXGCMXlDfBKRyE");
    int aHlgQQJNBdECS = 1194374270;
    string zzwdGCiV = string("YmJHmmHsPSpChwDzcXHibtJzoZceOdjnucziaBBGNhUfujGPhJW");
    double cMtJwRBCEmyL = -14603.789074291386;
    int FTPpgGiPrzEGk = -697396132;
    int UFWBqWiPOLrRdEV = 1340060469;
    bool hwgJYVmYT = false;

    for (int liNAIxDpgTglSAnQ = 1423707636; liNAIxDpgTglSAnQ > 0; liNAIxDpgTglSAnQ--) {
        FTPpgGiPrzEGk = KesurgLzFMHmPy;
        FTPpgGiPrzEGk += UFWBqWiPOLrRdEV;
    }

    for (int mCkxBMepS = 1012744205; mCkxBMepS > 0; mCkxBMepS--) {
        KesurgLzFMHmPy = aHlgQQJNBdECS;
        qRJoTjhOacZ *= cMtJwRBCEmyL;
    }

    for (int nOvOyNvGqsLXgCW = 1981906876; nOvOyNvGqsLXgCW > 0; nOvOyNvGqsLXgCW--) {
        eFXvUcPcloWiOA = HnIpSxluiYFujpHL;
        cMtJwRBCEmyL = qRJoTjhOacZ;
    }

    for (int aerOTPgblsaVP = 1121695974; aerOTPgblsaVP > 0; aerOTPgblsaVP--) {
        HnIpSxluiYFujpHL += zzwdGCiV;
    }

    return UFWBqWiPOLrRdEV;
}

int rWKxgme::OyoIbS(int krLQOwjT, int PtxFxTwFbpjgvtu)
{
    string ZyMvSGza = string("SnpdiWpZGASYgSZNjKlieohoRSfxaagENHmPRDyrKJZguDcbZKMYttDUFXasbsDCoSvmnxrvecLBwlaDlPEJdRFRRqOjEECgvEiNbwLETnqVVFhoBqVbbqoiPcoHuxAZmimMhXvmlQTxZjTeqmkhbYmYNYRxamrvpAJRfIVgfrikIVYCiLtlLpxagvsAKBmoxgq");
    string WxeTfi = string("zKxakboXbFrgkcxPLdrLjMZeSMYAmVYGOsJRGcoQImjJDtIWdLHwABprdFDYebyhlbinogtVMJBQxrxItQPXuugpRd");
    bool DSnfDDQHSmFwi = true;
    string mvuvaLrbJhQW = string("WzVzdwAsKapraFTZLchjSGuEi");
    int FZxvxLNywrq = 156847574;
    bool hAfbQygVONkb = true;
    string rzIgTv = string("zAXciXUluylYldBXrQNRCluTTKjtJkAuNCIWchQpjLkuxVnBQqQYwWRKXawGfbmbOFIeWhkLwkkFFFOkgaQFPSYnIRxIaHQGHsIarQVnsuEjgZPlfRKGNtZBXHwOBBWYHOzouQyLtNvOVUyDxdhozaLVLEXvUSpwykfocooHxMBvLMdImzbGUrABpZjZRxISdhoLXkMghoPdEkBoHIkLnHCZafwkjkvzMdpgkmd");
    int OaJeAqbQjpMdNsU = 381838472;
    int WSFGcGI = 1480089249;

    for (int PgRSkjNyu = 814389128; PgRSkjNyu > 0; PgRSkjNyu--) {
        continue;
    }

    if (krLQOwjT < 2030847970) {
        for (int lzTxbUTbG = 782909935; lzTxbUTbG > 0; lzTxbUTbG--) {
            PtxFxTwFbpjgvtu -= FZxvxLNywrq;
            PtxFxTwFbpjgvtu = PtxFxTwFbpjgvtu;
        }
    }

    for (int CWRkyrARwiAmNonj = 826711546; CWRkyrARwiAmNonj > 0; CWRkyrARwiAmNonj--) {
        OaJeAqbQjpMdNsU /= FZxvxLNywrq;
    }

    return WSFGcGI;
}

void rWKxgme::DKlPVOpZeStrBG(int lZpszcoPBgnyU)
{
    string qisBSdcJja = string("VeoSMfGhNvgNUSAHXySwubbPZOCkWyppIAxSPjrPKQRmojoRAIjitcBydZeuzfFQbwYHEfErXyuwjnRgyodaMwkHxOZNmVACqxLUSSiuqYmscHzJokhYzHHWpLCgTckbYkDkhMVoRZFzMxPXwHiJGmKnRN");
    bool IUDbrRPGrlWd = true;
    double pRcjRR = 323807.0492002352;
    double sHFvjBIJDVMu = -395704.923244916;
    double HMsHZS = 14254.705853972124;
    int raeXbjuIVaguJIZ = 1553837978;
    int scDAo = -646324396;
    int YtMmuwBOe = -145192719;
    bool joAuxoKfAcRQGikW = false;

    for (int zuwyVM = 1557710928; zuwyVM > 0; zuwyVM--) {
        sHFvjBIJDVMu -= sHFvjBIJDVMu;
        scDAo = raeXbjuIVaguJIZ;
    }

    for (int YRyGhXFxXeon = 337000476; YRyGhXFxXeon > 0; YRyGhXFxXeon--) {
        YtMmuwBOe += raeXbjuIVaguJIZ;
    }
}

string rWKxgme::krLtIcjZcBjOR()
{
    string OzGTo = string("TkZMdaVfkWuqfBCWvJPYwvlqfijpFfUdLpvQlPSlCXDWOLNyHcsrAEHhKmWMtOaLuDZfcfhwtYaMDgEjuIggtdFKOHwicwTURiaMSk");
    bool esvhupcnK = false;
    double PIgqKSmleEidat = -418231.7420911692;
    double wMSrRjuOCvDwz = -738577.7995362135;
    bool snVfmwpFDa = false;

    if (esvhupcnK == false) {
        for (int QlbmGgLoJqr = 2077497380; QlbmGgLoJqr > 0; QlbmGgLoJqr--) {
            snVfmwpFDa = ! esvhupcnK;
            PIgqKSmleEidat += wMSrRjuOCvDwz;
        }
    }

    return OzGTo;
}

string rWKxgme::GyVEj(string ciogYVglAmItIlxy, int OWsDieesmIJKMPgA, string tazjjVAaQDQqk, string bFatg)
{
    string sDqXMhZNuBoib = string("hoGdUfYbkVeGseuFsCxfcceurUjXJKBcOcrDqaVyfbktDVLVhUJyNNWaSqOtTdPhEDhcWghqplzSlUoYFAxWcHQDegfBJuGSJqQNnDdyqSExzJMENtmEdbDbjaTajztwLwlqTnVGNU");
    bool EGolgerZkn = false;
    int ecRyWiZLxaiadYGS = -277772208;
    int maXQunUoqYMJfhe = -422128060;
    int GdZwYLOzD = -1997909388;
    string gNokDBtzf = string("IJwzieCwFGDuruzRPsjTeaXNvZzThhPzQPqDXDdpiWQFGHRyKgyHXMBcBgwzPozOrUmufWCaEkEIRRyzzxQOUDUpAfgFXzyzGcCrhmYwYjyVgjmiktdumBjCWNoZeLjbWhp");

    for (int zZTxBoSiuxUafy = 1796645314; zZTxBoSiuxUafy > 0; zZTxBoSiuxUafy--) {
        GdZwYLOzD = OWsDieesmIJKMPgA;
        bFatg += bFatg;
        OWsDieesmIJKMPgA *= maXQunUoqYMJfhe;
    }

    for (int aXXLbHBTDHYkf = 620064797; aXXLbHBTDHYkf > 0; aXXLbHBTDHYkf--) {
        sDqXMhZNuBoib += bFatg;
        maXQunUoqYMJfhe += GdZwYLOzD;
        tazjjVAaQDQqk = gNokDBtzf;
    }

    if (GdZwYLOzD > -1997909388) {
        for (int hxMoo = 1897444047; hxMoo > 0; hxMoo--) {
            ciogYVglAmItIlxy = ciogYVglAmItIlxy;
        }
    }

    return gNokDBtzf;
}

int rWKxgme::syMPb(double fNaSBxgkzkoR, string rvBiUp, string iyFqDilYoPReZX, int ypuhc)
{
    string fEnQqnbd = string("vDCCuCtlnJpDyINevtyEYUXqhgdYhXEcppltowdaqBBmTMcbcBKevcRtEqGiPqndRYZcGohqqYOrLWXKNcvwzHecJihJpnYNnhHYegViCDrpv");
    string qLSyxI = string("QtyofRxdcHdBVwfiIcDiJgvVUArWxJXcXsyCzAZSjOtHEPvMipjzrJGqLvclrDLhfxxocgCwxgD");
    double LLFXpZUtW = -642181.8959009737;

    return ypuhc;
}

string rWKxgme::ckJXuPuVTRt()
{
    string hgqfnobqUd = string("SUlLJANwISkMFEJEXNkXBBRGwdGZfiwefUjeMfMVFwTFCNxJnonqRFjIscFQdvIbvjKIShagFVMUioUcCEsHGQyAvhLkTqeKtlyYZUSKqWnBcBVQIMDFlxypgZfIchGFkYpPUiYnJtEpTCPkxidfKhTmFVjDiqWsuzteGwuiZlblRiITuddwsYCIwBoKAXaWPWwfDPMhncCSeJxSjPhUALekiGiliPHuqPYoOoUmmeoiGiqpDMb");
    int oCiVHGALmyFPgjcW = 140724335;
    int upsCsTeFmKhI = 1393155015;
    bool fAbKALJG = true;
    double OjORDPzH = 317111.7694849813;

    if (fAbKALJG != true) {
        for (int xIuIGBZO = 16992695; xIuIGBZO > 0; xIuIGBZO--) {
            upsCsTeFmKhI = oCiVHGALmyFPgjcW;
            fAbKALJG = ! fAbKALJG;
        }
    }

    for (int qwPLYSkilecx = 1896885420; qwPLYSkilecx > 0; qwPLYSkilecx--) {
        oCiVHGALmyFPgjcW /= upsCsTeFmKhI;
    }

    if (oCiVHGALmyFPgjcW == 1393155015) {
        for (int yDmeGlrWkgXaa = 1689676744; yDmeGlrWkgXaa > 0; yDmeGlrWkgXaa--) {
            OjORDPzH = OjORDPzH;
            hgqfnobqUd += hgqfnobqUd;
        }
    }

    return hgqfnobqUd;
}

int rWKxgme::LRcdCVksEwganQ(double utHyx, double ULyuhDIApUzMDea)
{
    string tSJXFfgd = string("LkuiDEDQDEqaEnNafahHDeFCDbzAeZVDGmYokCSxvCKAEikzBqVNoSmlDfIWreYHVpwmmiYEIsvxwWVsdXSBslBEhSecMbzuhFi");

    if (ULyuhDIApUzMDea == 341756.0246694847) {
        for (int HtnTAA = 751724378; HtnTAA > 0; HtnTAA--) {
            utHyx += utHyx;
            tSJXFfgd = tSJXFfgd;
            ULyuhDIApUzMDea += utHyx;
            tSJXFfgd += tSJXFfgd;
            utHyx = ULyuhDIApUzMDea;
            ULyuhDIApUzMDea = utHyx;
            tSJXFfgd = tSJXFfgd;
        }
    }

    for (int KoMTojYOUWTN = 1585889437; KoMTojYOUWTN > 0; KoMTojYOUWTN--) {
        ULyuhDIApUzMDea *= ULyuhDIApUzMDea;
    }

    for (int fcewOszYpILOBzu = 1487427044; fcewOszYpILOBzu > 0; fcewOszYpILOBzu--) {
        tSJXFfgd += tSJXFfgd;
        utHyx -= ULyuhDIApUzMDea;
        tSJXFfgd += tSJXFfgd;
    }

    return 43774414;
}

string rWKxgme::uEzAzHSEdlSsxjj(int ABgxJVdgSQbkSygn, int boPTcLbS, bool SBaeParHBKWOUN, bool QFdjdYA, double aXVfWf)
{
    double GIQGoNWs = 67020.69613106888;
    string PpZYuQUlVHoAsfeY = string("LhiwEPbsqmjAzTgjZyWyZuCvdqUWoHFXCgnyEdRVSXeqSHDtdOwmgnuvhThwlIpwSFfqJNBswW");
    string ySINKTBV = string("xWhSnXLgxNZKIvxfVWHvHGcNQcDGPTTFNzBVpJNjTOqbXbFKAAwWto");
    double jmuVZUeAXbMmP = 529907.7247796806;
    string QwJPDHNexcOivfSa = string("QzGHELJdbPKxPzXALXZUE");
    bool FoshtVffJZnUYo = true;
    double okkqo = -530221.8491899774;
    bool FtsfSCkjPgXxtcar = false;
    int dFaPxGiytudvM = 2057985660;
    bool IUqTFbRjvEmos = false;

    for (int qJhUQAhcF = 1745122575; qJhUQAhcF > 0; qJhUQAhcF--) {
        okkqo /= okkqo;
        FtsfSCkjPgXxtcar = SBaeParHBKWOUN;
        SBaeParHBKWOUN = ! FtsfSCkjPgXxtcar;
    }

    for (int DCWLWrZYT = 1073581003; DCWLWrZYT > 0; DCWLWrZYT--) {
        ABgxJVdgSQbkSygn = ABgxJVdgSQbkSygn;
        IUqTFbRjvEmos = QFdjdYA;
        PpZYuQUlVHoAsfeY = QwJPDHNexcOivfSa;
        GIQGoNWs *= jmuVZUeAXbMmP;
    }

    return QwJPDHNexcOivfSa;
}

bool rWKxgme::DTXnGnAgRsEtVJb()
{
    int RzfpExHzzFHcC = -1765196142;

    if (RzfpExHzzFHcC >= -1765196142) {
        for (int JnKDqFnoF = 1987354519; JnKDqFnoF > 0; JnKDqFnoF--) {
            RzfpExHzzFHcC *= RzfpExHzzFHcC;
            RzfpExHzzFHcC = RzfpExHzzFHcC;
            RzfpExHzzFHcC *= RzfpExHzzFHcC;
            RzfpExHzzFHcC = RzfpExHzzFHcC;
            RzfpExHzzFHcC -= RzfpExHzzFHcC;
            RzfpExHzzFHcC -= RzfpExHzzFHcC;
            RzfpExHzzFHcC /= RzfpExHzzFHcC;
        }
    }

    if (RzfpExHzzFHcC <= -1765196142) {
        for (int TRUpsG = 1886624009; TRUpsG > 0; TRUpsG--) {
            RzfpExHzzFHcC += RzfpExHzzFHcC;
            RzfpExHzzFHcC += RzfpExHzzFHcC;
        }
    }

    return false;
}

int rWKxgme::HcEFcYjEszut(string mnibXpPxdhXJN, double zPiaHoeeqZo, bool xnejTEc)
{
    double NoirD = -333631.19100448047;
    int SwKMqGJytHVaY = -672740218;
    bool aAGBsZCrupGnjccP = false;
    string tlNhMJCqLYgZkX = string("QkZUIEwQbKGQKjibUqQpiDlJVcoJScJgEUVMVCGaIqEroKpIdTHCIwZXzlHbnhIljFhiPdmkZGWKadresXtlTKhZoJnAkgTkFCTidlUnmgSqpiASgpIxhyHAEdPiUCFFMmehDyetpHELwBGrQUVHZkzSKICnGygMrRYPeEpuXJmihotCxZVytCeNMTbSVGfRLIOwsQAgdJQTVvvLjuZvQB");
    double GZSFyd = -2965.7055549675233;
    int AwgcvkzXwBjgRZ = 460011022;
    string gYSJuM = string("xMSOissvWgvhIYwJtsCVGPoZqhhKhealFOGPmZkRUWwBQcxMwlaKpiXQYERCwKsTvonciLMVkIuJaiLmqKEjUhOXQUOiULYuC");

    if (AwgcvkzXwBjgRZ == -672740218) {
        for (int aCfpFiVY = 1434098457; aCfpFiVY > 0; aCfpFiVY--) {
            GZSFyd += NoirD;
        }
    }

    return AwgcvkzXwBjgRZ;
}

int rWKxgme::TAIZXlaYJMskAP(bool zjauMdkmBTrq, string IDxVfyftRa, int PNqLReHui, int KwFEDIqGHgwvdBuH, bool ckgTgBzAN)
{
    string yaHonheANFwPNWj = string("yYiavihBLspfHPIWIDlBVeeZudBbphgZhpdnfzKXnawYivKqxKQkcEamJvngEdUChAHzgsvOzbgEeHOEINvbUBpWtStLetCdiGvQfDTKazqyznQBexTSoarNwTSwMrQPLAzTXCPMtoRmnOVarwalxjoClVntArOvDhVtFpYKLiTAJvIVVOCojAjBkdul");
    string uNzcSsoaSMRbT = string("METJdwVecxmDPxRjJPbvgJiycdsNVYnBLyGKVCceOrVGMtDSwCEFBaKYoMPlthaaEaIJnnLmuSSCZkqiFtZBwHJEQZyLaMakgsXLgcMfRtmDwRaOCZWitpCtcsVdmUO");
    string vwCyoQgHiamK = string("DprUusfzJOYutqFGXAxUGGgGnAZtrNRsHbJjJxzDzylAhPPdxrgtcMsHMxmDxWwWnLLlzRYhEXqRnsfcekJGtIjDJOnAabwxzKGwTJWSSTLvyzRLUPQGgLprHYAIYmyGKDEUDJNYaoBFSELpzxqxEnYtHywGUqcfCRWheLFLeNmUxTfFohUtLhbEdYAMetfCgnuQlkPVOecTd");
    int xfiIFpzPSSdFCdDb = 984456342;
    double SeJyb = -768705.0202603725;
    double KCxrQvGpji = -151906.0678619233;
    int ysGlHKenQzRyn = 1449191897;
    int HFePCtjqMWnKzR = -511912120;

    for (int aZRmDYIrISKRxkQn = 221298991; aZRmDYIrISKRxkQn > 0; aZRmDYIrISKRxkQn--) {
        KwFEDIqGHgwvdBuH = HFePCtjqMWnKzR;
    }

    return HFePCtjqMWnKzR;
}

string rWKxgme::gxPWHe(bool WeNSbyACMSP, bool oOIsTydS, string MayFsEv, bool stVkdgb)
{
    int RsJcFfovZIdCIPp = 597488744;
    bool bUdWmuxhPGrXeL = true;
    bool HONRhMzpoHgU = true;
    string sEdicDIKKgPkVe = string("CmcizrLIXBHKuVQfqYoKYchSzrlRHyxHgLZtwpNDahAfLiNxhbmyBykEoYeIIzLMmqWlBkgLuvzgnIFXwmLgufcaLelSnthCoXNwpHVeBSoIpUDXZAgLleBuTwDNvkPfmQdSToLXNPNGwtmdCrGGvsYLTFVvCFIwLaZwFIIXFLNRWpDUKYTKDaqBOlzirKjPPpqAvSQNLfHdYwACESQRMlSSSjqTxDuDAPzzWSWsdakLRIDgWzIoYKrREVrvho");
    bool dqVjZTTiASZbUu = false;
    int ovXmfiHdlL = 302079077;
    bool rLifuaa = true;
    int rBVbWQltfMCFc = 40181505;

    for (int KFLuXzulkwxpF = 1128212885; KFLuXzulkwxpF > 0; KFLuXzulkwxpF--) {
        oOIsTydS = bUdWmuxhPGrXeL;
    }

    if (bUdWmuxhPGrXeL != true) {
        for (int iWRFSrs = 1672028317; iWRFSrs > 0; iWRFSrs--) {
            dqVjZTTiASZbUu = ! rLifuaa;
        }
    }

    for (int MVSXP = 508016472; MVSXP > 0; MVSXP--) {
        bUdWmuxhPGrXeL = ! WeNSbyACMSP;
        dqVjZTTiASZbUu = ! oOIsTydS;
        bUdWmuxhPGrXeL = bUdWmuxhPGrXeL;
    }

    return sEdicDIKKgPkVe;
}

int rWKxgme::DwdwuB()
{
    string BnTXO = string("xHpjeYXtyijOIqz");
    string EVLabiCTEaMeJmXE = string("WDlZLMtNqRMGIMIsMElyNRSOlYEBkIpqCqS");
    string dBgwZkqSbgc = string("aEstRVfRqTkzOekIsUBesDqkgCHsJbZjzidJpcTepPjQNdThmiecJZupBizofmLXMUMSMrCXSOTHpQEqrjIIPlhGkAqzuQKVfzIPynvHmZYVYsprSMRpDxjUEEyezTVGaIFNFZoEsKUJplCIABrxwyefMnvvhqyMtdlXkZGHfsJBgHmJDfejXPtSeRCfVAkmmyeYBjZSY");
    string HsEJc = string("CNoyhMyHajGgaZpgmiHanmgXnHrKyNHrmOzqxXtMFdNGsmAJPZCTnyOWkAnoryUWXfNfGwdvvGynmQuymbBEUTjlGSlzXJNwuMtBnGquaUHToOOqnPZzDKSBRBObMoEHajxaMiTsyEkQvpguXxpMfzKmBzoTArkPIencmUxoYedsSQhBMOSjWjIxxJDOpgt");
    string EOvVsrcMWa = string("YpHvLIZjxDyCiX");
    int EsqMXIsIVXSl = 1735671331;
    int aGcoa = 822665928;
    int ZiTxwLMit = -786004812;

    if (BnTXO <= string("CNoyhMyHajGgaZpgmiHanmgXnHrKyNHrmOzqxXtMFdNGsmAJPZCTnyOWkAnoryUWXfNfGwdvvGynmQuymbBEUTjlGSlzXJNwuMtBnGquaUHToOOqnPZzDKSBRBObMoEHajxaMiTsyEkQvpguXxpMfzKmBzoTArkPIencmUxoYedsSQhBMOSjWjIxxJDOpgt")) {
        for (int bIGKISrWwfRGJFT = 2095902447; bIGKISrWwfRGJFT > 0; bIGKISrWwfRGJFT--) {
            EOvVsrcMWa = EVLabiCTEaMeJmXE;
            EsqMXIsIVXSl -= EsqMXIsIVXSl;
            ZiTxwLMit += ZiTxwLMit;
            BnTXO += EOvVsrcMWa;
            EOvVsrcMWa = dBgwZkqSbgc;
        }
    }

    for (int nqFFo = 286662127; nqFFo > 0; nqFFo--) {
        continue;
    }

    return ZiTxwLMit;
}

double rWKxgme::UqeEs(string DNZwjOL, double PHGzxvVJ, int xecAWd)
{
    double ttGrSHTlY = 390641.1738046204;
    int idyUyfxQxUGAJLWM = -729991449;

    if (ttGrSHTlY < -936573.9381641101) {
        for (int higwPITMA = 1087894002; higwPITMA > 0; higwPITMA--) {
            ttGrSHTlY *= ttGrSHTlY;
            idyUyfxQxUGAJLWM -= xecAWd;
            xecAWd = xecAWd;
            DNZwjOL += DNZwjOL;
        }
    }

    return ttGrSHTlY;
}

rWKxgme::rWKxgme()
{
    this->XltlBmQJEQhLJrQ(-464004.95911682706, -89531.78209463785, 260121.03239405813, -482280.11295791046);
    this->anPjK(-838075.9639127121, true, false, string("UaeVNjjQYgrvmeCxBExNyRiIfWPsoMyzcekdOPJSRQdtvUfNjxrbdQWFcEWCVANcmHTVooJfREQyEZCyZlZlaVfnDXEDdVOBJgjTbhYKDFqjyRfTyduFEamBGlGAxERXYKqrymzltszvDnGSymXrYziJFpCsszYLvBXOtMtlnPUjJnQYQWlTXFisRtOSXaVsykxaJzUljmdsMHatQLjXgn"));
    this->lZCHKdTzHHo(false, 767523887, false);
    this->PTeECMNmTh();
    this->CMfDgo(string("MRMGlBLcQLOnUWgtnZysttdZoJeHucWUMaJLSgcvRMNRTePNYIolxYIjliKLFPNPKBwLMwqnwGsoQpWybNbQmVWFlzxCAdhoukogWvpbvDgYYHNDQwERnpaTycErjLLEcBPRtwkxZGgTybDhHadFXgyHzORmsUBrQEIzDfiMffpQvRDAEIfZaSQFlXBYaUEnWJblWPbs"), -1675362140, string("uOvPzanXXsfxrzcdGVeGsWtQlhEtXbOIAbGgxBGqsaWIcfHPcUcUJFpVuWGEYZsgplsRGNgwmwzlkDzaYvNJOELSaDTxetDVAGUCGUoXINwjMUbrxTmHUEOuUdSgoFXsLgogrctmNWpwVkmlOprTKhIKnnBDsWezxOYeWodvkPJaiCqXVBqkenbjnRDiKmUKcUceXvkdvNxQOEWOhrbFWhqBxNdCwpinZuIcMVXokfzJNpZFBePEhyYjvnvtPK"), 868869.8681013385, 321964.12952377787);
    this->ZaInTmEhYYNAtX();
    this->OyoIbS(2030847970, -1780187489);
    this->DKlPVOpZeStrBG(-889300541);
    this->krLtIcjZcBjOR();
    this->GyVEj(string("ayYOyfRqxvAQacVCjNPCBrqlXQjVGAXfWWbLloTmMFWIKTtlTbTRCxxfFCigFXvWEZFqxZVVIHjFvhyWmaKVmYfywsSYmiWirtVOeDbZAkFNzQsKpTqqDGzjPEnUNrqWJOeoQbyfFqqoWGBgisUscrdMkRBRpcDmApwawtLnGBhmvIczTzruImOimWmJtdBiYDOlAaJIFpNcpzZUZvVdJYBDOwRSi"), 1986332404, string("guebBWQEdFLwjRPYUPkJpJNFzrrPAmGgNUNktSyqghITTOoomGVBkcgcdnBKYxHiPbbLWlgAIfYYipPyCVcsVhIgKu"), string("xzLAgIfIRSWqwkdEcqlKyevIjnHAwYyCynhRPptjcERhJrTYnmHpbAWVwZJiGXR"));
    this->syMPb(-922562.0779259473, string("GwdSbyfdOrvxFRCVOsScuLQHqBxTdqTNPPoRNDuDOGPrCHlMwELgWBkdYlTRxscYsInQxHQpinEwfElANbSTWHh"), string("EaFdmeaWrJKejzxODnSVMA"), -1447954310);
    this->ckJXuPuVTRt();
    this->LRcdCVksEwganQ(341756.0246694847, 577194.3141105946);
    this->uEzAzHSEdlSsxjj(-329856143, 222129378, true, true, -601660.2222301775);
    this->DTXnGnAgRsEtVJb();
    this->HcEFcYjEszut(string("jFGMCmwlnLaTMtAjaLKDfPvkPfjXuuEf"), 553996.0706964828, true);
    this->TAIZXlaYJMskAP(true, string("erBlBYLYVeSXzNURRzHg"), 1673045044, -639008782, false);
    this->gxPWHe(true, true, string("VLYSUpzHpLlcyPsXpoqkdbWvEbcjWTZFcqVSWNRizdJmIBdAEjXkCCQVfEfuAGcGzkENUoxUEQzeteRIYnuoguEyKJbXViKlwaMuCMbQqQHZGtxVzAwJkGUdlaGRcKTEhorXstosYNMWakoQTIykJqPAIQzRSMxmarqesUTSwNazeVCKMvFQYbQoIPUyKDzKOuAqQmwXkIEwEcegjrOCzzpOnWFjFgDmhkfB"), false);
    this->DwdwuB();
    this->UqeEs(string("o"), -936573.9381641101, -1095607703);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BxULhEbo
{
public:
    bool bYdsNzyOjjZKzqAC;

    BxULhEbo();
    bool SjDvaBzUZTeQxHEv(int IgBFp, bool BhezESjZx, string lGqHCFAjWoukHre, string aYAIp, double XNUqUlocdPh);
    double AyFLubQnmfbk(int RYCLlyQtQQvJG, int rNdcfJZRq, string DCRgbSPRVhwfoz, int NlXKcSdNe, string qfVulH);
    bool YiWFcWBGtDC(string vgybT, int isgAlnnLfeU, int zYGwC, int WhHrVlJeQOAZ, string YPZLfBeLpAHYd);
    bool RKhgXyvQB(bool vpqyAOtpOIcd, bool PFLEHYcXHeC, string auULQhPkwD);
    bool PcQyahvPRi(string joVQk, bool bfFaJEwhOYuHfE, bool cwwsNNiK, string TnXeAlNkT);
    int hiJfFvygkGIK(double rOhBlBrLrHKGuoWU, string lNkveITwzCNOPbzI, string OJuZwClEaSPw);
    int mSyxeNrAYEsXgE(bool oTydLlx, int DrEOwiOfJZuOv, string iBPfpxOycEROpO);
    void sOjlvxZc(double tytbaFvpnecLoqz, double ibqOeiLuVQsbsv, double qMVSxwTYEqa);
protected:
    int YGHBNBu;
    string KjIkfR;
    double uuSwybhb;

    bool gHydcQAG(bool jRDhZCGggQZRWfU, int FwDNrbRny, string qkDMRblASAu, bool TWmKZCPNPTvXoWxo);
private:
    string JsthXy;
    double dVOhVQMGBZMbK;
    double MKlOFQXkUY;

    string eZYBKnvUVrap(double zSQCaA, string kwssaEoQYCeKhNKu, string AAsql, double IpXDPPdVSEZUNtX);
    string bkNfOVk(double VkRSWfxMuJTinK, string gqoGOuFoMpCqnI, string ExihITbsXQD);
    double zlEvS(string gaexy, string hmmHfqJqdjJDtR);
};

bool BxULhEbo::SjDvaBzUZTeQxHEv(int IgBFp, bool BhezESjZx, string lGqHCFAjWoukHre, string aYAIp, double XNUqUlocdPh)
{
    bool LpsDLEDb = true;
    string vAmBrpCyH = string("JQuetiSDGaftnQhiZAUyIPOJXBddFzODPcatmZBMvwDwwqhYHFCwlpiQSGBmDkWnKULPXdTxvachPFctuNlfLPpaGwsxTKTKHsUWKIDycREYWOiAwvnySNfxEajeYnixSRcidSiokVtVNqBRXHxNWfuUlpDAWucUnnilKyNCjcnyjtNwvGkiHaRQorkFLniAITgozvQisl");
    double mHigvcIuwMSRnb = 300417.6614241033;
    bool iHenkpGeuEg = true;
    int zNffKGCMQpFoejY = -676387271;

    if (aYAIp != string("JQuetiSDGaftnQhiZAUyIPOJXBddFzODPcatmZBMvwDwwqhYHFCwlpiQSGBmDkWnKULPXdTxvachPFctuNlfLPpaGwsxTKTKHsUWKIDycREYWOiAwvnySNfxEajeYnixSRcidSiokVtVNqBRXHxNWfuUlpDAWucUnnilKyNCjcnyjtNwvGkiHaRQorkFLniAITgozvQisl")) {
        for (int lAzQr = 280513378; lAzQr > 0; lAzQr--) {
            LpsDLEDb = ! iHenkpGeuEg;
        }
    }

    return iHenkpGeuEg;
}

double BxULhEbo::AyFLubQnmfbk(int RYCLlyQtQQvJG, int rNdcfJZRq, string DCRgbSPRVhwfoz, int NlXKcSdNe, string qfVulH)
{
    bool PHPHYVRJOQK = true;
    string WHUCzLQXZrehgC = string("AiueKahKhQwPnYFVunBzlivTNMRWsQlfBoYhTChUHGsCsDVciDLqyK");
    int pkHOwYx = -1892981428;

    for (int bunODjsbSA = 565012413; bunODjsbSA > 0; bunODjsbSA--) {
        NlXKcSdNe -= pkHOwYx;
        WHUCzLQXZrehgC += qfVulH;
    }

    if (RYCLlyQtQQvJG == -2043730604) {
        for (int oUayDPMtx = 849435415; oUayDPMtx > 0; oUayDPMtx--) {
            WHUCzLQXZrehgC = DCRgbSPRVhwfoz;
            WHUCzLQXZrehgC += qfVulH;
            rNdcfJZRq *= NlXKcSdNe;
        }
    }

    return 187539.1602507623;
}

bool BxULhEbo::YiWFcWBGtDC(string vgybT, int isgAlnnLfeU, int zYGwC, int WhHrVlJeQOAZ, string YPZLfBeLpAHYd)
{
    double nRpGHaCOIhGUw = -767483.680007258;

    if (isgAlnnLfeU > 1114241285) {
        for (int wmRFLBPd = 689528309; wmRFLBPd > 0; wmRFLBPd--) {
            isgAlnnLfeU -= WhHrVlJeQOAZ;
            vgybT = YPZLfBeLpAHYd;
        }
    }

    for (int GkJDmmGwLKX = 1495779167; GkJDmmGwLKX > 0; GkJDmmGwLKX--) {
        YPZLfBeLpAHYd = vgybT;
        zYGwC += zYGwC;
        zYGwC -= zYGwC;
        YPZLfBeLpAHYd = YPZLfBeLpAHYd;
        WhHrVlJeQOAZ += isgAlnnLfeU;
        vgybT = YPZLfBeLpAHYd;
        isgAlnnLfeU -= zYGwC;
    }

    for (int ucNjMegqVlPPPHGX = 819935697; ucNjMegqVlPPPHGX > 0; ucNjMegqVlPPPHGX--) {
        vgybT += vgybT;
        zYGwC /= zYGwC;
        zYGwC += isgAlnnLfeU;
        zYGwC -= WhHrVlJeQOAZ;
    }

    return false;
}

bool BxULhEbo::RKhgXyvQB(bool vpqyAOtpOIcd, bool PFLEHYcXHeC, string auULQhPkwD)
{
    bool dOphiTY = true;
    bool wgIZyaxQdSSSE = false;

    return wgIZyaxQdSSSE;
}

bool BxULhEbo::PcQyahvPRi(string joVQk, bool bfFaJEwhOYuHfE, bool cwwsNNiK, string TnXeAlNkT)
{
    bool qopFsiKFbEmhYebV = false;
    int VXZEfyKHtMFDhOSx = -334657966;
    int dwZnkmy = -977150643;
    bool saIew = false;
    bool EajUOBSVhkciNOK = false;
    double CfhNF = -987903.8928329278;
    int XobiNeARu = 1691732169;
    bool yXjbVT = false;
    bool aEpKwdIdq = true;
    double sqDvZzRwOO = 171612.58098425786;

    if (saIew != true) {
        for (int ScrjeBufH = 1448106716; ScrjeBufH > 0; ScrjeBufH--) {
            bfFaJEwhOYuHfE = ! aEpKwdIdq;
            joVQk += joVQk;
            saIew = ! cwwsNNiK;
            aEpKwdIdq = saIew;
        }
    }

    for (int lsPzEkKgm = 605585564; lsPzEkKgm > 0; lsPzEkKgm--) {
        bfFaJEwhOYuHfE = ! EajUOBSVhkciNOK;
        cwwsNNiK = ! yXjbVT;
    }

    for (int QsVjfLlr = 671376330; QsVjfLlr > 0; QsVjfLlr--) {
        CfhNF /= CfhNF;
        aEpKwdIdq = ! cwwsNNiK;
    }

    if (sqDvZzRwOO < 171612.58098425786) {
        for (int WuhhGdLK = 572123383; WuhhGdLK > 0; WuhhGdLK--) {
            saIew = aEpKwdIdq;
            sqDvZzRwOO -= CfhNF;
        }
    }

    return aEpKwdIdq;
}

int BxULhEbo::hiJfFvygkGIK(double rOhBlBrLrHKGuoWU, string lNkveITwzCNOPbzI, string OJuZwClEaSPw)
{
    bool KXoGzNabbndPplq = true;
    string lFszhX = string("lLvTAVyrzCYxGxlH");
    int FTVzCkVtbVn = 1223609390;
    bool DdBjo = false;

    for (int yJYwIC = 949121756; yJYwIC > 0; yJYwIC--) {
        lFszhX = lNkveITwzCNOPbzI;
        lNkveITwzCNOPbzI += OJuZwClEaSPw;
    }

    if (FTVzCkVtbVn != 1223609390) {
        for (int BrlyrYOKcPeFCx = 1738717772; BrlyrYOKcPeFCx > 0; BrlyrYOKcPeFCx--) {
            continue;
        }
    }

    return FTVzCkVtbVn;
}

int BxULhEbo::mSyxeNrAYEsXgE(bool oTydLlx, int DrEOwiOfJZuOv, string iBPfpxOycEROpO)
{
    double udpTPMuGHYCjW = 818110.6134852447;
    bool dFpwisUVum = false;
    bool FkxsLq = true;
    int tiGahCMqroWqkW = -331316333;
    double fvTbu = -906696.5644138115;
    double coltLK = 855741.5473994886;
    double QwIzbZ = 1007908.0332034231;
    bool ZpvBG = true;
    double yazdTPdVzv = -985686.3996305357;
    bool UrqVVwRogdweraB = true;

    return tiGahCMqroWqkW;
}

void BxULhEbo::sOjlvxZc(double tytbaFvpnecLoqz, double ibqOeiLuVQsbsv, double qMVSxwTYEqa)
{
    bool QAHRmBbC = true;

    if (tytbaFvpnecLoqz >= -961251.5382514318) {
        for (int GniSmDGlxKpVVc = 2002191106; GniSmDGlxKpVVc > 0; GniSmDGlxKpVVc--) {
            ibqOeiLuVQsbsv -= tytbaFvpnecLoqz;
            qMVSxwTYEqa = ibqOeiLuVQsbsv;
            tytbaFvpnecLoqz /= ibqOeiLuVQsbsv;
            qMVSxwTYEqa = qMVSxwTYEqa;
            tytbaFvpnecLoqz += qMVSxwTYEqa;
            tytbaFvpnecLoqz *= tytbaFvpnecLoqz;
            tytbaFvpnecLoqz += tytbaFvpnecLoqz;
        }
    }

    if (QAHRmBbC != true) {
        for (int VgMmFYV = 1406779345; VgMmFYV > 0; VgMmFYV--) {
            ibqOeiLuVQsbsv = ibqOeiLuVQsbsv;
        }
    }
}

bool BxULhEbo::gHydcQAG(bool jRDhZCGggQZRWfU, int FwDNrbRny, string qkDMRblASAu, bool TWmKZCPNPTvXoWxo)
{
    bool BECIZfruhGRuHiFZ = true;
    int mPrFrwTT = -1944084487;
    string iiGrkKpAvT = string("zxQYAGTEidDfMfObSwxDtRisjgWxkbdYybOkuGRXCHUwJhEScJOGRStEaUxvrsTVqzYalmiVHkQNixywAjZRdCaQoGWcabyphnzwaAzgavnfmAnIBbyaeusUZLnQrnurWlbLFXyaeQKFLTtObfqfDWZLPSDcWAuBVSFCDUchTou");
    int mgPVWcBBFTYRpjy = -2130353988;
    string mNqKwPC = string("rAxVkjcvCVBLrepOQmKXJEQWtCAzcpQFAOGXKqsfeBCYUlOBKqsvNjBkEOIrqdduUdgIESlTqKPCCsOFUgnanYYQwbwHfXzJjSTVCFdfhTUnPhuGMdYoJlbnVbSUCysjtTMTBstEDhkZdjUxZEIkGDcaSvhJdfgnYascUhfdVXhahzIInQqTnGnHDhsivTcfJEFMTEkpazOwYvhi");
    double whiDLdmhPWalPA = 14168.71289639861;

    for (int iEROOa = 1343148554; iEROOa > 0; iEROOa--) {
        iiGrkKpAvT = qkDMRblASAu;
        iiGrkKpAvT += qkDMRblASAu;
    }

    for (int zaZPqoYo = 298398468; zaZPqoYo > 0; zaZPqoYo--) {
        mNqKwPC = mNqKwPC;
        jRDhZCGggQZRWfU = ! BECIZfruhGRuHiFZ;
    }

    return BECIZfruhGRuHiFZ;
}

string BxULhEbo::eZYBKnvUVrap(double zSQCaA, string kwssaEoQYCeKhNKu, string AAsql, double IpXDPPdVSEZUNtX)
{
    bool yotOFqhIRQn = true;
    bool AUZhPCSSQopveOjF = true;
    bool IxSoXXZak = false;
    string REmQsefrC = string("jnacPkmOfvJsXoGGOwZYqFWSqattGLtIFjcSYncygOlgviPNKDkBhbDjGoHXMKxagxcLADiBmhKAPckKBzrvZiFqYqgfPZf");
    bool BFURJe = true;
    string xTMMUCxildzB = string("BtbcXDgDsNTtnraVMpuTOgMwIRKlrLnHDxTyVWqPpZIsBIGfFNFDxrbZTlqkfiOwXZ");

    for (int jFKcIpMAupeoAz = 1982458190; jFKcIpMAupeoAz > 0; jFKcIpMAupeoAz--) {
        AAsql += xTMMUCxildzB;
    }

    if (AAsql == string("BtbcXDgDsNTtnraVMpuTOgMwIRKlrLnHDxTyVWqPpZIsBIGfFNFDxrbZTlqkfiOwXZ")) {
        for (int BmntJtH = 1118837755; BmntJtH > 0; BmntJtH--) {
            AAsql = kwssaEoQYCeKhNKu;
            REmQsefrC += REmQsefrC;
        }
    }

    for (int pPCwXCaFWeB = 1435114044; pPCwXCaFWeB > 0; pPCwXCaFWeB--) {
        IxSoXXZak = ! AUZhPCSSQopveOjF;
        AUZhPCSSQopveOjF = BFURJe;
        yotOFqhIRQn = IxSoXXZak;
    }

    for (int ONIOVQ = 263048989; ONIOVQ > 0; ONIOVQ--) {
        AUZhPCSSQopveOjF = AUZhPCSSQopveOjF;
    }

    for (int YOeSUbXOothKgLnP = 687431692; YOeSUbXOothKgLnP > 0; YOeSUbXOothKgLnP--) {
        AUZhPCSSQopveOjF = ! BFURJe;
        IpXDPPdVSEZUNtX = IpXDPPdVSEZUNtX;
        AUZhPCSSQopveOjF = BFURJe;
        AUZhPCSSQopveOjF = ! yotOFqhIRQn;
    }

    if (xTMMUCxildzB <= string("jnacPkmOfvJsXoGGOwZYqFWSqattGLtIFjcSYncygOlgviPNKDkBhbDjGoHXMKxagxcLADiBmhKAPckKBzrvZiFqYqgfPZf")) {
        for (int BSUKZMqfoKRYtfAq = 282006801; BSUKZMqfoKRYtfAq > 0; BSUKZMqfoKRYtfAq--) {
            xTMMUCxildzB += kwssaEoQYCeKhNKu;
            AUZhPCSSQopveOjF = ! BFURJe;
            IxSoXXZak = ! BFURJe;
            AAsql += xTMMUCxildzB;
            AUZhPCSSQopveOjF = ! BFURJe;
        }
    }

    return xTMMUCxildzB;
}

string BxULhEbo::bkNfOVk(double VkRSWfxMuJTinK, string gqoGOuFoMpCqnI, string ExihITbsXQD)
{
    bool wtbUO = true;
    bool HTQlYrr = true;
    bool peYew = false;

    if (wtbUO != true) {
        for (int xKiCrsuxEXMBBe = 1011388431; xKiCrsuxEXMBBe > 0; xKiCrsuxEXMBBe--) {
            wtbUO = peYew;
        }
    }

    for (int KeljIHbIRSb = 649876094; KeljIHbIRSb > 0; KeljIHbIRSb--) {
        continue;
    }

    return ExihITbsXQD;
}

double BxULhEbo::zlEvS(string gaexy, string hmmHfqJqdjJDtR)
{
    int RsHWKDnm = 1766858213;

    return 211752.9513144356;
}

BxULhEbo::BxULhEbo()
{
    this->SjDvaBzUZTeQxHEv(-1021247608, true, string("EndXEEUAWgxbIspmhhrcFPVLUCEDAmsAZgXjMBrlvlLhgQrzISGJRbVfWHesvDJeMbdVRoLWmVdBlAUo"), string("urilUJQtOCPxmazwPQoQMXfoKcpYZfntWSCyxkvUoVKUUdrfqPFyjYRsPeeZVAMDbteESGOTwpkVPRcrYQKaHyNIzTLAvTddkpyRhLHmbrCNuN"), 227228.3851780985);
    this->AyFLubQnmfbk(-2043730604, 721783570, string("xeQOqgKZa"), 48160253, string("JiDgoRwLTpLJrbUsyvxYISqNLgWluUJKGIbMhZdkk"));
    this->YiWFcWBGtDC(string("iqZObERnAcogfbDvWlkFhkRyvWpTxTyDgstqFbZGvrumIJNjnrQVmmdElwOFILoGubnGQykkLZUNwF"), 1114241285, -474505536, -624781586, string("pdyvzpcJqMJCvVkxzplIXCNGIbRNYzMNonbecYnabMLYhUJQVyTCLDfazDRrVQbdoXoeiOZiySGreTTyOllpZNgCKAvtQaNLwnGUOEZJgCdgvDciFMKPcSwdIHEuDfNNVmMEEfFpRlZVaEcWophQjxmCvAGvqTLzmWZmvrlddJBIgOxxEljguctOfjtvbpjATxrZmmLuxmUNstREGLHc"));
    this->RKhgXyvQB(true, false, string("OapUmtHMfvTBszAqvmbtuIZrvmhPSPaSGYblYJBTMjTBIyTNiNzRu"));
    this->PcQyahvPRi(string("ArFEsdyqTUzfUPxOBlaIkLTAFSBdbYbdTXJlmbswadRVADQCFeYyrxQualoocButJPhCuJqxoiRQNWMlHShFiOdlEElcYgrzuBrjLdptVdHRSjjnPhcAkhQCNleIkhyuVkZNTmMNUHLeEIsqENLhYEhXIijsPgJQqjincZvVhpnhkRwOCiuuwkYFrQLTHUOnxpcroMSVlDbmDtZFoqmBoBVJkihInEbzkqZwVxiodkFLxyiZljviyZMTgdufcc"), true, true, string("ySlhSaoHwRpDLDKSNwKjzoVruMtcWSNLyTekbayMEthNEIaxTUEyfPEUviKVJZBZcGRSyoBTfOpefHZRcPqQk"));
    this->hiJfFvygkGIK(176717.52040312174, string("FftiDmCCbRAuQdGlDSSEhvhxxLIqSrjXNPVVgtFBLCdoYrsiJpuUakOqHAwZBCdqdTRxDwDoPFtBSJUmpMYhSpufLvNiZONoJeHxMTdXgIoQXekiJZTpqsUHeCwYZHQDZJERcGRhbnLETsZLRRWMneQwodokyBVeZwDciUcoBNbbaiukaOWKFwqykwWuTvgFlXoWbyVG"), string("LXxOvjzWvDgBAaTPVvyYkQSwiztOGMuLzDkcFXdw"));
    this->mSyxeNrAYEsXgE(true, -896959084, string("aeTrDjpIvUTfaMIybPUBwyLheVSYmcOoDVhewvUlgfTYJjqVQGEbthGbmntOXMmQdhCwwNsuS"));
    this->sOjlvxZc(-961251.5382514318, 845713.6981747419, 626504.4881731813);
    this->gHydcQAG(false, 1212621458, string("XhxeyBvOGqdecKHlcnpulFXBqArSX"), true);
    this->eZYBKnvUVrap(794048.6232914471, string("anlfjJRRBqlPghRwWpLpAHJQFNFTLYQuASaVzOzjsRPllRrnKwOwckgmmSPprIoJhkRfsTQjPuWhZfUIe"), string("SqgOZBsKCoTVOPsjyVXFQlUGaTxrHWFJCOmswImYnmZywKcDvaFLHKgmJZDwpPNOoMvXjQNrcALlyrJfOwRzsqIFMiLUpgbOCkretAQqegDutXBHFcmJqTZCKZMMnLzxeXhXWrlRDCPUrICrtukfaOhDHpjPobPHhvheryp"), -684845.4058679848);
    this->bkNfOVk(293112.38989764574, string("ShmtOzSlsIivgGShCiSAjeJHjRXRUQmmDOznkOMOTbTezwhtUvXoJYdfFRuDXkQjdPWVeIAuWgSgWTujIqVoQPoIIpZwUVUIWJE"), string("gyfAZhdeXGK"));
    this->zlEvS(string("FYNjfVexZaodlUkGYiVHGbAizCBFdKQZgBtsxMcQLmZkRNMgjgpXodCnIJAmIXxsbJuYIYFLymJusDOensRWdGprltmxmOQIZl"), string("lHtWPGTbqGzRMCgiJymuOAMEUfllHufeSaVEjHzrdXqdyIqfDNKunvBVOlCixvoNGpNoftFpvj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JSqEYVoqSSLwrzFL
{
public:
    double VzZCEzHaeLXVZRvW;
    int ZfDxOnNVicJQ;
    double CcrdtjHJ;

    JSqEYVoqSSLwrzFL();
    double CBpLuRS(int rLPcOLhmTGIvxH, int XwwQOOMPpm);
    bool oFYhHHHPlw(int WhysHHHP, string HZBOuvnDU, string GmBHpCvG);
    int kWwOrJpY(double bwYrkwELVcouN);
    void OtzZElaEGNn();
    void gvGUVpOJOOD(double vTWMZbEJF, int PXtstQWab, double sWlPl, bool skSxLznxT);
    void gqeVuaNQrt(double LlGaFzQ);
    double lXuQSwk(double DVviYpfPyQTZnNr);
protected:
    int CGiUnGCDzSdyf;

    double naPrjeK(int uYxvKgQEz, string wlbFbY, double MkkyDI, int pMtTc, double QgRmnAgMNOVr);
private:
    bool OHfyhJpC;

    int sqiUzzMQhJsNgFBk();
    int nSqUBciWcOOKgcQo(double uRvSWLNW, string wtbtGLmPmXm, int OsMELp);
};

double JSqEYVoqSSLwrzFL::CBpLuRS(int rLPcOLhmTGIvxH, int XwwQOOMPpm)
{
    int icsGBFoHEqGQvcP = 2084919457;
    double OPchNH = 994655.9921103545;
    double VuXybmrVKKBJz = -64518.16101017085;
    double QNNLuinCol = 178854.54680694948;
    bool KyvCHhTJacSrSZwi = true;
    bool NNbSLRbggFW = false;

    for (int xgZbDzNhXTHtkRd = 1235486632; xgZbDzNhXTHtkRd > 0; xgZbDzNhXTHtkRd--) {
        QNNLuinCol += VuXybmrVKKBJz;
        NNbSLRbggFW = NNbSLRbggFW;
    }

    if (OPchNH != 178854.54680694948) {
        for (int TSyrofKlneJNB = 997652956; TSyrofKlneJNB > 0; TSyrofKlneJNB--) {
            VuXybmrVKKBJz /= VuXybmrVKKBJz;
        }
    }

    for (int YUvTVxis = 163772304; YUvTVxis > 0; YUvTVxis--) {
        XwwQOOMPpm /= rLPcOLhmTGIvxH;
        NNbSLRbggFW = ! KyvCHhTJacSrSZwi;
    }

    if (VuXybmrVKKBJz != 178854.54680694948) {
        for (int uARkmaPciVp = 1589257153; uARkmaPciVp > 0; uARkmaPciVp--) {
            icsGBFoHEqGQvcP *= rLPcOLhmTGIvxH;
            NNbSLRbggFW = ! KyvCHhTJacSrSZwi;
            NNbSLRbggFW = NNbSLRbggFW;
            XwwQOOMPpm -= XwwQOOMPpm;
        }
    }

    return QNNLuinCol;
}

bool JSqEYVoqSSLwrzFL::oFYhHHHPlw(int WhysHHHP, string HZBOuvnDU, string GmBHpCvG)
{
    int KTmechGoaWoevidJ = 2101214725;
    double AqTzmcpjEDAZFag = -259639.83396981072;
    double GakZqZeNFmmrBT = 917950.7466945249;
    double mSxfsD = -612248.015905836;

    for (int XsnRlr = 1190850350; XsnRlr > 0; XsnRlr--) {
        mSxfsD = AqTzmcpjEDAZFag;
        mSxfsD += AqTzmcpjEDAZFag;
    }

    for (int gdEmTRQaKFpFi = 725810725; gdEmTRQaKFpFi > 0; gdEmTRQaKFpFi--) {
        GmBHpCvG = GmBHpCvG;
    }

    return true;
}

int JSqEYVoqSSLwrzFL::kWwOrJpY(double bwYrkwELVcouN)
{
    double LwuaVTsHUp = -1007405.6845626778;
    bool QDkaeFqBMJZs = false;
    int gyDjBK = -1657965146;
    string TMQStYMFrfyH = string("dtGZhuhyOTUTKleqxnTKZodIGMBBskwNvAlZBEOZrrYfrxJFOaCePyMaDjUIIDBzxDafruQWRnABDdMqIbcKHcRNtrfBnCOqiqlwztOByIHxdVyAyzwQOfmsDvVzbKmggiWZstFrJqbqxVcNgJhGhDnvFzMxcKmTYsJvizRUThvVMZTHZStYv");
    string iRaSMjxARX = string("toOHEYOjZgBDrxkSpXZFgfQYwlTgjupgVTHbvhwaZTkGxUfqCrsijztpAOEEsFfNyLCJC");
    bool BvUDPrmlNcSkAaCT = true;
    int HLEyapRxCDO = -457263808;
    string Msixn = string("EQpkacStYQrJfBmDzkvqBPojqakSMpJiHgIrSigTEJehgMVlEuFlaENQgnuKFFtcGSdzgsDKTMOTAUVTBibpbJLCwlclUVlVlNOZnwWgVSoNaAcqFhYCHScpkXOZwTJkvLiLUYmdPHBuGiaynthoArcBGwhYXQXUUorlNxa");
    bool iRrBsSScUYdPTmT = true;
    int PRRzMLoaFxdDRd = -205872462;

    return PRRzMLoaFxdDRd;
}

void JSqEYVoqSSLwrzFL::OtzZElaEGNn()
{
    bool aSoGxffyuQiE = true;
    bool fPtWZjdydXGv = false;
    string xhkkmlXvfK = string("tjbYiSNnGsXxbjRUknsUKvYsFyjRvrdkCFTaKzJyeVxQJgiLCbdXbUISidGsrNOlMmamcpcWadufsGxHBEDxJJkFWBHGPTIrHGDbToDOFUjVQAUEuZMzicqSy");
    bool VJkoLig = false;
    double ZHTCHhiHTGea = -465806.6166725057;
    int WnRTYDhNRBbBtXNN = -428975065;
    string SnSPis = string("UzNVHHStfqjQHbWoFGQpfbG");
    double LglbSXgi = 522942.4868543251;
    bool reBhEKZ = false;
    bool KVtGiSK = false;

    for (int bxgLtqUNYlwhdUm = 239670131; bxgLtqUNYlwhdUm > 0; bxgLtqUNYlwhdUm--) {
        KVtGiSK = ! VJkoLig;
        VJkoLig = VJkoLig;
        aSoGxffyuQiE = ! aSoGxffyuQiE;
    }

    if (VJkoLig != false) {
        for (int QoAYcOVSiXW = 33123039; QoAYcOVSiXW > 0; QoAYcOVSiXW--) {
            continue;
        }
    }

    if (reBhEKZ != false) {
        for (int SPjWMxpcQH = 1744492529; SPjWMxpcQH > 0; SPjWMxpcQH--) {
            continue;
        }
    }
}

void JSqEYVoqSSLwrzFL::gvGUVpOJOOD(double vTWMZbEJF, int PXtstQWab, double sWlPl, bool skSxLznxT)
{
    double TrodadI = 278477.6717823187;
    int nVhVGihgHse = 1631660762;
    double NlxuiMqnhpdcz = 965238.8372960186;
    int ucldsATiPWNyKz = -1905462679;
    double vbNoxfNigjs = -156535.6692933907;
}

void JSqEYVoqSSLwrzFL::gqeVuaNQrt(double LlGaFzQ)
{
    bool jiaDTPUFOrO = false;
    bool XpdNySEOTpzoi = false;
    int hGYVU = 1954959492;
    bool FEECFiiS = true;
    int NarsxbNQvkq = -505673070;
    bool IyjFklJj = false;
    int IXHZOvig = -1050128410;
    double PllSMzgkuBwlGnig = 220522.47901859513;
    string pVsnMLRgxk = string("TnePwbVPgkGMmlIrLkgBYDGqsusDzgkokTZnmtttzjfrPgWpUqxqHEEsCzPgMcCwfAOcxoXdioJdTbBvDhFSGbOArQZhQsHtmCoYuJCFPDsVVZlCTfMeGfLoXxaFQeWdMyPXxIPRoWTyDYAOZOBJRagWEoMNmSyJpPOVeHilkuArhQj");

    for (int kqveHzuvnjJIZiq = 2023656974; kqveHzuvnjJIZiq > 0; kqveHzuvnjJIZiq--) {
        IXHZOvig /= hGYVU;
    }

    for (int boqoof = 1044309066; boqoof > 0; boqoof--) {
        NarsxbNQvkq *= IXHZOvig;
        XpdNySEOTpzoi = ! XpdNySEOTpzoi;
        NarsxbNQvkq -= hGYVU;
    }

    for (int quFrrCFCnah = 51692630; quFrrCFCnah > 0; quFrrCFCnah--) {
        continue;
    }

    for (int nmoEfJJejBoYfJ = 1963311706; nmoEfJJejBoYfJ > 0; nmoEfJJejBoYfJ--) {
        IyjFklJj = jiaDTPUFOrO;
        IXHZOvig = IXHZOvig;
    }
}

double JSqEYVoqSSLwrzFL::lXuQSwk(double DVviYpfPyQTZnNr)
{
    double IUpPHuIhPSYND = -431478.79512115894;
    string oGcUHXq = string("ETpPhtQIIQbegbRLhXOMJqHtYBKXjzVzYGwSmgrCInMbExVEdbdRfobtmpgZPVQhNkFygpcXPYgilNNOGoIqQnGPMkZDtBQHOmCbBJarqudeRpiCDFzCbIpMxxotOBGlMiJWLUkQdQYtQbEumNcxPrsXtEuFMQSjaZGSxfoQsWnzMmiekPArjyqKgGSmyRLiiLSkVP");
    string FWybUUBgozeo = string("EeauCOheYptvMdcsZkUGvPDtJaaoxQUMUKgfJbuoWvbAJlZcgnfyoraKkkJvdpxFxvUylmkbOyweQDroAdyQumDbHkwlFtVruXnMNShfHisHYflbzrArpOFjeARlCCzzmwUTUjzrSwErjLYPqKspbxshTBAvSndBDgFlIfSgMLcpNXLVgAzhIBCLZtvskReRYjUFXoIEdpYvkhzeGehtJDAgbSuubvTFXHRHFQCMscBy");
    int fNCKBIUxALqogUx = -1464029655;
    bool zPZFrYHW = true;
    double aCWTnnPiHY = -742999.0440783994;
    string LDvFumxGUN = string("dspqAyCfAyMNkquZzsFUvXTEPZqAEhcLmdoyCJuBijfdkcqOHuHSgWpntCQDZwtDNbfPxmzRqCYScYXYlvUetPvuRTBCmhDHjmFmYMEXOthgbeGDdEoeyLzuHbKnlTwRRmXbxLszdnJVBgwrXVzwzvpjcKcjztfSTKYZfFMyeoQgbnFouXOqXMmEirDknfIiiVgLi");

    for (int RrlIfXZx = 1087307075; RrlIfXZx > 0; RrlIfXZx--) {
        oGcUHXq = FWybUUBgozeo;
    }

    if (aCWTnnPiHY >= -742999.0440783994) {
        for (int lVGFLlgYVevbiY = 1841622383; lVGFLlgYVevbiY > 0; lVGFLlgYVevbiY--) {
            continue;
        }
    }

    for (int grGaFiWcCrsNA = 668060174; grGaFiWcCrsNA > 0; grGaFiWcCrsNA--) {
        FWybUUBgozeo += oGcUHXq;
        LDvFumxGUN += LDvFumxGUN;
    }

    return aCWTnnPiHY;
}

double JSqEYVoqSSLwrzFL::naPrjeK(int uYxvKgQEz, string wlbFbY, double MkkyDI, int pMtTc, double QgRmnAgMNOVr)
{
    int bkhAAor = 667459939;
    double AbwdJ = 1016202.66915646;
    double rKfFoJ = 2571.980157260435;
    bool lzrZjKJUU = false;
    string rBfbPSgjZ = string("MvFtuxymSHbnBgzAoYdZPoEqQPbVvUUEPFbHpEVSxwRhuzqRRSCdslwdUqrmKzVsJeNsBqfUjsusiKWfYKJrBuvETZbPTabzAdCfrpnBfSYFpnDAQKnmGteBHAZzIDbqqxIFjIaJTVywevHRskuAwnjWruhqNJvqJtepIKuBbOBFEJXOWciWGRypVtADCOZkOWrpsOKyHNSWvfymyrowCvOQjHuHQLAgfzDGNUvycBFoqcLfCFZmlHsXYo");
    string dspIHIzILBBvhHN = string("zxrTwYznXpYkkdXKnfTftsNmherqnrsT");

    for (int pxVeFDbEJQKv = 18653786; pxVeFDbEJQKv > 0; pxVeFDbEJQKv--) {
        continue;
    }

    for (int kuFJJaBEZVemWRn = 520922488; kuFJJaBEZVemWRn > 0; kuFJJaBEZVemWRn--) {
        continue;
    }

    if (AbwdJ > 802516.448827018) {
        for (int vxDyWbidRprUIA = 878655329; vxDyWbidRprUIA > 0; vxDyWbidRprUIA--) {
            QgRmnAgMNOVr *= AbwdJ;
            QgRmnAgMNOVr = QgRmnAgMNOVr;
            AbwdJ += QgRmnAgMNOVr;
        }
    }

    for (int kpQAoHQe = 89200816; kpQAoHQe > 0; kpQAoHQe--) {
        AbwdJ -= MkkyDI;
        bkhAAor += pMtTc;
        rBfbPSgjZ = rBfbPSgjZ;
    }

    if (rKfFoJ >= 2571.980157260435) {
        for (int mEunbYoHmuRJWX = 345003338; mEunbYoHmuRJWX > 0; mEunbYoHmuRJWX--) {
            continue;
        }
    }

    if (uYxvKgQEz == -949552089) {
        for (int GRAHMtqukMK = 828360819; GRAHMtqukMK > 0; GRAHMtqukMK--) {
            wlbFbY = rBfbPSgjZ;
        }
    }

    for (int pineSvhXzFlAmIY = 702212447; pineSvhXzFlAmIY > 0; pineSvhXzFlAmIY--) {
        rBfbPSgjZ = rBfbPSgjZ;
    }

    return rKfFoJ;
}

int JSqEYVoqSSLwrzFL::sqiUzzMQhJsNgFBk()
{
    bool TQamPojciX = false;
    bool dcHsg = true;
    double kOfAmsyZ = -345532.90390704153;
    string wppeKkm = string("xsWJaDJZxdyWMIXVBXGOpTTQKETipTxxCwFyxtHqZkbsqLFcJiCzxRtvziJkawWwlGedmXLVhOCNjEHGfnDGaQGysTSOLRHTrvWhTqUXCNnYLrcytycHZgGtjVQJufNUpEczemoItPKMiwaTxeYajwYxYGsRmdUFHYfHTJTFXknbGfVGHtolpRGkKQhOyStaWyjcIRkDjIUnxUlimnqusTPRxHLTtaHsiFicGCLHekdwokcq");
    string SAImzSiHho = string("GBCKMuQJAUezPlihASTTWCGcvCHWcHzPpIHhqBOnmNflWFlmOdugGmCGRxiEZiohDNkdigniGnXXhgLVjCazmCTHpORrKaTHTskFIMwKggvSnTpuZEChIzKbRGfWpKMHVXOZRYJfcxJUhIphPeEdiTyTWjOWshOivWITIvfQZNFdrTxijmOUXnBzBIlSWUTaUqSzLgvDxqJGIeeieM");

    if (TQamPojciX == true) {
        for (int lIzmZWTrsfPrhb = 424130835; lIzmZWTrsfPrhb > 0; lIzmZWTrsfPrhb--) {
            dcHsg = ! dcHsg;
            wppeKkm += SAImzSiHho;
        }
    }

    return 191469054;
}

int JSqEYVoqSSLwrzFL::nSqUBciWcOOKgcQo(double uRvSWLNW, string wtbtGLmPmXm, int OsMELp)
{
    double FWNPdpAsGOvusQ = 280135.40604483633;
    int OgRlItQMchZX = 49179639;
    bool dPWyxW = false;
    string GXGlpafUJgIB = string("EXYcqQLROkHqSDEZidIyYqDAHWxCyvNlFeDwSdmrsEwWqOmSMoEeTUZlnbrTXD");
    double rvUMluU = 797107.2574651886;
    double mWvMIRXDiwNvUB = -1032705.8933013929;
    bool ZsDlEo = true;

    for (int AsAGddEOjf = 1350869544; AsAGddEOjf > 0; AsAGddEOjf--) {
        continue;
    }

    return OgRlItQMchZX;
}

JSqEYVoqSSLwrzFL::JSqEYVoqSSLwrzFL()
{
    this->CBpLuRS(-991552604, -785238842);
    this->oFYhHHHPlw(764275830, string("HUVTvndWvzTZutbQSBHTSEbnkRDebburUzBJaQoBqEnpVLleFvMzHKvbvfyeREMwXXWblPKCPTSljePMSOzCkARdCfcyRErZiSTQZIfseoyNuQRWKHuNtnCRD"), string("kpsfOklZkZGONaYPbLKeXDgXPvejOzFHlZzmjedT"));
    this->kWwOrJpY(-1031785.6976231638);
    this->OtzZElaEGNn();
    this->gvGUVpOJOOD(211512.66318095138, -770047342, -537310.6568847919, false);
    this->gqeVuaNQrt(784525.1452487499);
    this->lXuQSwk(-773023.67750078);
    this->naPrjeK(-949552089, string("FNTEUkhuITITGwiOLeoNOnHXsHsEMDesmFNevKAYtgqMmCsuADrI"), 802516.448827018, 1286754310, -856030.320104135);
    this->sqiUzzMQhJsNgFBk();
    this->nSqUBciWcOOKgcQo(646714.2379338414, string("gWFIIkOcsFnayZzfIlrlieGioBHxxKloNHjdKpzILOqzubEwtOUMPxaQWBlkIblletYzdRFYuMjrqKRhywWQFSjdkCdNLAvuetIgpwdFfWcBJljvEQpioiVQKAiLKuyAMGXydQmXxOMdkTzZVFEwDiYatjrmEHasKanyGJemLVsFuszwFfUFEfCklOzcIZSDsCDLPYAPlDaNXflIGERVJWdXWkXjpTerCdFMv"), -376637645);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sSYwHOP
{
public:
    double LXkeSF;
    bool KSRvRHbUw;
    double gUsMVvwY;
    bool pdJbrctVIweytsK;

    sSYwHOP();
    int KfpxNasXp(string wadoWsmmTTgqG, bool MYKAsjvTTkYpE, int KDGHBJyBBgZSkI, string VgngJar);
    string vnBTuVkXdc(double wXRvmXWSnriHxUG, int bbYbdfcXj);
    void nvOCU(bool VxWcKAFECdZwq, int daJcWe, double bIzZNL, bool uGoBo, double ahNIfoRvyDSUGS);
    bool ZurGCAAbarxTfMA(int PnHiWauIQCdQ, int MBdhOZkF, string JVbwUqOhQaeiyXYB);
    int knzJmHHdxS(string pNwdGgBdZOCYXCq, double MlWVZkuzqyk, int uaHCdHtbVa, string SsHRw, double sscZEAZeeDrCf);
    int CtuSliOksqu(string PLnXFcWeE, bool LWxJuRxEgkAfG, bool ElxbWZkzSPTris);
    double EBoxHtHvWujl(int JZAocvcxYNku, string CVFJDOudaE, double RxHncrilz);
    int pOwwgwFF(bool zEDtbU);
protected:
    bool JsrQZwGeIYqCw;
    double PPKCb;
    int bXgpKlIwdMbVXXBk;

    bool wLiGyzEGiK(int XqfSVmoaYF, int IoMHQ);
    int QhjiPKMyRrmbuD(bool GsGQJndLOxC, string DDDlrsLGwMksQ, int KJLwlgeagZr);
    int RmbmBgqMfSLC(bool IADIiuNxvPEFEvin, string ARACwlrdOPvH, string dAGXGDgFE);
    int GNWDMvqRgUIqN();
private:
    bool TuiOubp;
    string lsqMSlCstAHANgUT;
    double oXDgbrDdRi;
    string PuJLpUcsfjUBIk;
    double DsmaI;

    string GLRMHBqkMPycJ(double JNrJXcdraIiMCoZH);
    string poKeyyz(double pveUzVSAYGA, double TOXjHDe, double HFdiTuYBD, int oWqljd, int iXAGodhQWUYomTZ);
    string HGYSWuCJqrimG();
    int yeheK(int NucCUAuMJrFF, double FfIOQKusn, double VOOvfJJOaL, bool ljBAPBzK, string fAShwzuIr);
    bool xAkucTFpCjp(int QOXYHXzEOhfecT, double yKLiLJYsQzgPUAVr, string chmOOdn, double JmEzNAYWpRA, int gtWdQbmfXxf);
    bool XMsZENeNbpGZWPr(double PWBMYdvwDLGqe, bool YGiQYnpDOLRfbL, string UzYiEQBbri, int jDZWoiLejofGx);
    string EZtcbxvLTMuPLdbs(bool UBQCcLT, int kQCvCvtTIH);
    int NNYzHsvItkvVHL(double LVdEqJ, string YtPktPRnQQtdae, double ZZGrTklfDgS, bool wjYsS, int EQQqZshcE);
};

int sSYwHOP::KfpxNasXp(string wadoWsmmTTgqG, bool MYKAsjvTTkYpE, int KDGHBJyBBgZSkI, string VgngJar)
{
    string XmuBgPkloxhM = string("vdGEdvWpBEiKlbskQDIYrNHhSaAJTszrMyzrYOghXGKmagNhWCYrTMlUNloCSEZDlZftsbvQlhmFylKqzbJAwTQgskGGyRXiUrIQWbARzuMEqAwcziEYpMxnCVdhiZGtmqaliUCiUxEZehQJsGXGSgoERZzeqdhueaebPHFiTybqfqzjwtkErORFtOsUIOxYGGaqOhJFgXdnPKZUxRXBIMuvSsNvFoHQiKnMpnvovNoNwHIbjLgoLDvLczLHI");
    string wxwgc = string("qDBHcBSBcHDHIVkHuXWXRYySCHNgwpgcScoabYLWwrcMjthxCakkvCcVUYlVXOVfSayRkhFtcnfEoNuVPYgwhoOihWxbtVBhxCrUSdWINdhcvnpQAglzqXnm");
    double eyWZNvridVwrURrJ = -331568.60165425856;
    string SwWgpC = string("qcGyXnleagaVCPBdtRDvUhMdyQiXslajhAjwFJusLeSVVEenrQZEqwFSvTPLyzawRcowmfPznoYTgMiNDMLCGdiyUZCRkkWli");
    bool NNVXzwMGvOUzs = false;
    double igiGKRiQ = -15594.215635655075;

    for (int zPoXuTUAV = 1752026825; zPoXuTUAV > 0; zPoXuTUAV--) {
        MYKAsjvTTkYpE = MYKAsjvTTkYpE;
        igiGKRiQ *= igiGKRiQ;
        MYKAsjvTTkYpE = MYKAsjvTTkYpE;
    }

    for (int DobNkkOTc = 1443102510; DobNkkOTc > 0; DobNkkOTc--) {
        XmuBgPkloxhM = wxwgc;
        XmuBgPkloxhM = VgngJar;
        eyWZNvridVwrURrJ /= eyWZNvridVwrURrJ;
        VgngJar = XmuBgPkloxhM;
        SwWgpC += SwWgpC;
    }

    for (int rTIUZKgMUeJXbdyr = 1643543170; rTIUZKgMUeJXbdyr > 0; rTIUZKgMUeJXbdyr--) {
        wxwgc += wadoWsmmTTgqG;
        MYKAsjvTTkYpE = MYKAsjvTTkYpE;
        SwWgpC += wxwgc;
    }

    if (VgngJar >= string("qDBHcBSBcHDHIVkHuXWXRYySCHNgwpgcScoabYLWwrcMjthxCakkvCcVUYlVXOVfSayRkhFtcnfEoNuVPYgwhoOihWxbtVBhxCrUSdWINdhcvnpQAglzqXnm")) {
        for (int OvHKdWiLtBWlX = 480176440; OvHKdWiLtBWlX > 0; OvHKdWiLtBWlX--) {
            XmuBgPkloxhM = XmuBgPkloxhM;
        }
    }

    return KDGHBJyBBgZSkI;
}

string sSYwHOP::vnBTuVkXdc(double wXRvmXWSnriHxUG, int bbYbdfcXj)
{
    string UpMdUdcDmt = string("rtzDZdTKmrNNmceMmZUznNhqP");
    bool hNsiSWrU = false;
    string oyiBcafmziJDp = string("hGQnPeWwRniYgBNDbMphuyFrObAHXqXlQnVuiowtbuXqqiXQxXCqwyMwbrBeDGrHzPfaudbtlRRkhZeYyAHYQasStNADORZlqehvfgYPyfCNcjkIjhathtRbEhPScpJIeeyoT");

    for (int aWcibCE = 268802862; aWcibCE > 0; aWcibCE--) {
        bbYbdfcXj /= bbYbdfcXj;
        oyiBcafmziJDp = UpMdUdcDmt;
        UpMdUdcDmt += UpMdUdcDmt;
    }

    return oyiBcafmziJDp;
}

void sSYwHOP::nvOCU(bool VxWcKAFECdZwq, int daJcWe, double bIzZNL, bool uGoBo, double ahNIfoRvyDSUGS)
{
    double FOycirleppccSJX = 576805.7747382998;
    string HPadSCqiD = string("HVHGBfEnVFVNOVlgqWFRdiZZHFyGsTqqBXRzGPjuevSJvDrUnMnLKRWiYUKHITTLykCBiYXITkWqtOOSAFxGedtqekAkSPDWYvEvFulk");
    int ruYNyvHlTmXOTwC = 707130952;
    int SnWuZSNqppYrQm = 1395255664;
    string EyffvADyshIfKh = string("HFknfBkUYRsoqXlFAzvFkVXTBJaRjuJKeDFYDFYEeuIKBQHGVAjMWdecXEuQaeHgAJyZelXtOqDNlXEYzxpTBedsmxHr");

    for (int xXrQpsFKXlIYP = 56398757; xXrQpsFKXlIYP > 0; xXrQpsFKXlIYP--) {
        continue;
    }

    for (int ApVXMQZ = 1818802865; ApVXMQZ > 0; ApVXMQZ--) {
        SnWuZSNqppYrQm += daJcWe;
        SnWuZSNqppYrQm -= ruYNyvHlTmXOTwC;
        HPadSCqiD = EyffvADyshIfKh;
        daJcWe -= ruYNyvHlTmXOTwC;
    }

    for (int XyALXv = 79310787; XyALXv > 0; XyALXv--) {
        EyffvADyshIfKh = EyffvADyshIfKh;
        ruYNyvHlTmXOTwC = ruYNyvHlTmXOTwC;
    }

    for (int ftppCrvflcyqMG = 542003422; ftppCrvflcyqMG > 0; ftppCrvflcyqMG--) {
        uGoBo = uGoBo;
    }
}

bool sSYwHOP::ZurGCAAbarxTfMA(int PnHiWauIQCdQ, int MBdhOZkF, string JVbwUqOhQaeiyXYB)
{
    double xupAaly = -864071.0298397564;
    bool XviVNZBgLl = true;
    bool kxzhlM = false;
    double ZZjMhXZ = 922087.9256974808;
    int QqmUDuFxx = 1630105999;
    string uAdrzWF = string("BUUTmBQLTyBVzcruj");
    string iFkxDAitjAhw = string("dQVEarvleglGxnxQiBfRJNbNbQxneIYTDIgyuLILtOdIbMroWwYmKxrqQahREukqwwFOztbIJoGVMoxgKSvETnTSjgHXxRVzTscQVcukdIvblbJjWbGZJLvqEQCOrjzCSRyPrfqbnzFUhioyByhQonfKSVFEgerrVuDTrVEyORGVAHCicygaOJna");
    double MVkxFAemDWSmPoYV = -840814.955705255;

    for (int jhtPZlkF = 1628541831; jhtPZlkF > 0; jhtPZlkF--) {
        continue;
    }

    for (int jJygejI = 1585470665; jJygejI > 0; jJygejI--) {
        MVkxFAemDWSmPoYV = xupAaly;
    }

    for (int oKWKltIWbZUWvQwy = 2053989483; oKWKltIWbZUWvQwy > 0; oKWKltIWbZUWvQwy--) {
        PnHiWauIQCdQ *= MBdhOZkF;
        ZZjMhXZ = MVkxFAemDWSmPoYV;
        PnHiWauIQCdQ *= PnHiWauIQCdQ;
        JVbwUqOhQaeiyXYB = JVbwUqOhQaeiyXYB;
    }

    for (int ZUdaoHIbJkhrVZH = 369566550; ZUdaoHIbJkhrVZH > 0; ZUdaoHIbJkhrVZH--) {
        xupAaly += MVkxFAemDWSmPoYV;
        QqmUDuFxx /= MBdhOZkF;
        ZZjMhXZ /= ZZjMhXZ;
        uAdrzWF = iFkxDAitjAhw;
    }

    if (MBdhOZkF <= 1630105999) {
        for (int zUiutHGB = 1093070846; zUiutHGB > 0; zUiutHGB--) {
            xupAaly -= xupAaly;
            ZZjMhXZ *= MVkxFAemDWSmPoYV;
        }
    }

    return kxzhlM;
}

int sSYwHOP::knzJmHHdxS(string pNwdGgBdZOCYXCq, double MlWVZkuzqyk, int uaHCdHtbVa, string SsHRw, double sscZEAZeeDrCf)
{
    string LQbxdBrcLy = string("VxvmpqWkDgQjqnyEzJbkvpEVJUtEBdNminrSXtHuFhTiFnNzxRkeGQgahATYgoPzRfGRerPzvVxWffKJBJCRkALVWlfEwoYXURWedEkgYesFoRPylqoEBcpafMWtpqLhhtwYcUAAFQsy");
    string OwTSlOGsV = string("duPmQXJxaUnoHUwtASYMUJAEyWhLCuXyBLjgA");
    int mXoHcsJV = 646483912;
    bool LkeaSLNqhFV = false;
    double xMRckkgWE = 14851.370603688692;
    bool JfesTTOzzWQ = true;
    bool XFnBGOJQsfZIM = false;

    if (MlWVZkuzqyk <= -302941.37482146977) {
        for (int ZPnNQVGW = 339458960; ZPnNQVGW > 0; ZPnNQVGW--) {
            OwTSlOGsV += LQbxdBrcLy;
        }
    }

    for (int tXsftHWDMj = 1749909865; tXsftHWDMj > 0; tXsftHWDMj--) {
        XFnBGOJQsfZIM = ! JfesTTOzzWQ;
        sscZEAZeeDrCf *= xMRckkgWE;
        JfesTTOzzWQ = JfesTTOzzWQ;
    }

    if (sscZEAZeeDrCf == -302941.37482146977) {
        for (int LgkOzmLw = 797759638; LgkOzmLw > 0; LgkOzmLw--) {
            xMRckkgWE *= MlWVZkuzqyk;
            XFnBGOJQsfZIM = JfesTTOzzWQ;
            mXoHcsJV += uaHCdHtbVa;
        }
    }

    return mXoHcsJV;
}

int sSYwHOP::CtuSliOksqu(string PLnXFcWeE, bool LWxJuRxEgkAfG, bool ElxbWZkzSPTris)
{
    string HmCmJBSEFQyBL = string("IGPkDfkTWvTmJOvgyfACHOSZiYCqvYIpM");

    for (int XcbwQ = 1836581076; XcbwQ > 0; XcbwQ--) {
        continue;
    }

    return 637561361;
}

double sSYwHOP::EBoxHtHvWujl(int JZAocvcxYNku, string CVFJDOudaE, double RxHncrilz)
{
    int yrqEXjH = 312622113;
    string CneucZKwlkUlJh = string("HhrssvORspPrIPiQrOPXwIEiumFBphnPtGIEdqCRMUZXBcAjRrPefJzauxFNFxANCfknZPJIcAsZDlNStCHXCEmUteWOTlxCVMaNRmhnbNXVClNmvyWZDSemtkxzZBYuLPenJBWWxSNJDidAsWCfJSGkjyfmCQsomFDLivODRfjtSvFGcFcepKeztyrUyeTsfaOloblkWWdmMjyMoqkZLYuiumEiHSpvaSKhteohBIwOPUbYSndX");
    int UqbwYnWF = 922094366;
    int eTVuP = 1729210089;

    for (int BtswtAux = 1754815950; BtswtAux > 0; BtswtAux--) {
        JZAocvcxYNku += yrqEXjH;
        UqbwYnWF += yrqEXjH;
        UqbwYnWF /= JZAocvcxYNku;
        UqbwYnWF /= JZAocvcxYNku;
        yrqEXjH += yrqEXjH;
    }

    return RxHncrilz;
}

int sSYwHOP::pOwwgwFF(bool zEDtbU)
{
    double riWhodAtfpahoDbe = -583770.875663289;
    int KBrqQFUfwviTW = 1014613028;
    double HerzIWVkPWZ = 230483.46327170418;
    double xqMSaVla = 1045127.4139388095;
    bool dpzZvS = false;
    double etqafBz = -59190.65450340075;
    string sLhyxPZxHKt = string("zZneXXXInNJAkCRHMcFyzZfxWirDltEYIKFmRcLiMBsjSaqNmnBovgITVhUiCPaGDKtDhbKNZwbiVwFDHVsRwAtOcLZCDeo");
    bool PrXghzoCoJvZPMk = true;
    string IgGsgg = string("ZhQzFfIKINsggFHMLpnOJZVUwwWRCkoqzfURjGwDZZHHxUZqBXhSMGLKYZKDIwQaWfUJbDsIHNKXTELENAIFesRQyGMBAfZvWnWUhYnAIZNwGdLbnhBkvoVTaPwjiAXwGIwvaVeDsGgkpiqP");
    int aJHVxbKLKKn = 1257211448;

    for (int zWICCqRZRG = 1128397309; zWICCqRZRG > 0; zWICCqRZRG--) {
        zEDtbU = dpzZvS;
        HerzIWVkPWZ = riWhodAtfpahoDbe;
    }

    for (int BlAqRSdAlLv = 941224751; BlAqRSdAlLv > 0; BlAqRSdAlLv--) {
        continue;
    }

    for (int ovBtpFLCNIjKyl = 1360214722; ovBtpFLCNIjKyl > 0; ovBtpFLCNIjKyl--) {
        etqafBz *= xqMSaVla;
        etqafBz /= riWhodAtfpahoDbe;
    }

    for (int vdHDOBJXg = 1832521610; vdHDOBJXg > 0; vdHDOBJXg--) {
        PrXghzoCoJvZPMk = zEDtbU;
    }

    return aJHVxbKLKKn;
}

bool sSYwHOP::wLiGyzEGiK(int XqfSVmoaYF, int IoMHQ)
{
    int SKFxVOXAztKaSw = 957559114;
    string pbVtLzsXgZeQn = string("DfzmuswCendyBVnNYGMWgezEVcdBfteWcXqmQGeIhtOyBhmlBFbcaPodMTZhvdQokqYDhAlbDNWdEjiGzoFbYbFNuCNlLlKZMHymJVXuizkWXPInUBEmR");
    bool xDpgmLKKKlhZqUq = false;

    for (int DmBFfo = 1109918017; DmBFfo > 0; DmBFfo--) {
        XqfSVmoaYF += XqfSVmoaYF;
        SKFxVOXAztKaSw -= IoMHQ;
    }

    return xDpgmLKKKlhZqUq;
}

int sSYwHOP::QhjiPKMyRrmbuD(bool GsGQJndLOxC, string DDDlrsLGwMksQ, int KJLwlgeagZr)
{
    int HWZLWyqjE = 9539274;
    bool xSsPsVy = true;
    string dcAdqaPAxlOD = string("LzfBLrErJwOkIVEfWdwNxaQqxugQJJygWiVqVCdLCbyPuUdwSAICXaQWLPeZjKjxeyIQze");
    double RPXuouHzklYOnKR = -723367.2584695887;
    int kZHTgvMxI = 536912699;
    string YasbsXGdJX = string("NSIKzZhlyquGenUzziDgDJzuEWTJFHoOKstJTfGNAaiQcyoGjhOaPjlmgZoqYMCdcNCQvobgXjNitMqbFVIfairDFqlDPPXtxv");
    bool DwREUSydSeetOD = true;
    string LFqFM = string("MyEqMYWSbdOICUtALmEtqYoDUBQSAEnOSZGVFvcWfZHoVGhwxLArZKXPEjsRUIHKmeGAbGRFOtiApaWUCewHKjDJhqjSOdfrxqrNxvIHVDrGHZXhZdgLvWeAbVsKKHNgAbcsBffuWIylEicLaorFmL");
    string eEZKytTNU = string("eLLAgiSbkmyEDrobZSJYygsbZkcGfEyzgVjmKLCYCaqnFcxUjrFKKbtYMvGnoMlXOgBeadreHkmrsuWOcgJQJFBiMJCowzjBLPKjmHOZXwYGbATRjmLSSGZivSMAAJVTZGvBumjOaaocGymUNdsBGlCDSWmkwbRxVxAeTbOPvYccdSIGmeOkLvrazzljllLqWJANGFksRUKfrVSjzMiNqTsJHBFQfEUOzwRNgN");

    for (int gEYzIqqDku = 1721932412; gEYzIqqDku > 0; gEYzIqqDku--) {
        xSsPsVy = ! DwREUSydSeetOD;
        dcAdqaPAxlOD = DDDlrsLGwMksQ;
        dcAdqaPAxlOD = LFqFM;
        LFqFM += LFqFM;
        dcAdqaPAxlOD += YasbsXGdJX;
    }

    return kZHTgvMxI;
}

int sSYwHOP::RmbmBgqMfSLC(bool IADIiuNxvPEFEvin, string ARACwlrdOPvH, string dAGXGDgFE)
{
    string uXkNYtkvMssf = string("fjeOnmqFBZupAYMjaAESrBeFJypophqWTDcFeltfqGuyDjCkkZRCLnZVaRsZtgRhWzLOIYlsXqKKzTwrUQQO");
    int CDJciSHCQ = 1351941503;
    double UldLJUZVBvXXMrI = -103605.81286059444;
    bool IWktvx = false;
    bool qVCNXUNCwlpWORV = true;
    int btgDkEMCOogbf = 122372606;

    for (int PjvpyWRCiaOax = 174271706; PjvpyWRCiaOax > 0; PjvpyWRCiaOax--) {
        uXkNYtkvMssf += dAGXGDgFE;
        ARACwlrdOPvH += uXkNYtkvMssf;
    }

    for (int DMWIBfsD = 538312541; DMWIBfsD > 0; DMWIBfsD--) {
        dAGXGDgFE = uXkNYtkvMssf;
    }

    for (int qKBWmFx = 1341756171; qKBWmFx > 0; qKBWmFx--) {
        uXkNYtkvMssf += dAGXGDgFE;
    }

    return btgDkEMCOogbf;
}

int sSYwHOP::GNWDMvqRgUIqN()
{
    int EErNclQwxDeINp = 458475390;
    int jtIAwLhcEV = 2030349145;
    double kZLXswZqQDGTRRF = 43637.05604162986;

    if (EErNclQwxDeINp == 2030349145) {
        for (int eOnrRnAQa = 866437230; eOnrRnAQa > 0; eOnrRnAQa--) {
            jtIAwLhcEV *= jtIAwLhcEV;
            EErNclQwxDeINp /= EErNclQwxDeINp;
            jtIAwLhcEV *= jtIAwLhcEV;
            jtIAwLhcEV /= EErNclQwxDeINp;
            EErNclQwxDeINp = jtIAwLhcEV;
        }
    }

    if (EErNclQwxDeINp < 2030349145) {
        for (int KmquTCqZ = 1642301683; KmquTCqZ > 0; KmquTCqZ--) {
            EErNclQwxDeINp += EErNclQwxDeINp;
            EErNclQwxDeINp -= jtIAwLhcEV;
            EErNclQwxDeINp += jtIAwLhcEV;
            EErNclQwxDeINp -= EErNclQwxDeINp;
            jtIAwLhcEV -= EErNclQwxDeINp;
            jtIAwLhcEV += EErNclQwxDeINp;
            kZLXswZqQDGTRRF = kZLXswZqQDGTRRF;
        }
    }

    if (EErNclQwxDeINp == 458475390) {
        for (int MserKORHIXP = 254864603; MserKORHIXP > 0; MserKORHIXP--) {
            EErNclQwxDeINp *= jtIAwLhcEV;
        }
    }

    if (kZLXswZqQDGTRRF <= 43637.05604162986) {
        for (int UTHAJNOgFHSeI = 2061665410; UTHAJNOgFHSeI > 0; UTHAJNOgFHSeI--) {
            jtIAwLhcEV += EErNclQwxDeINp;
            EErNclQwxDeINp -= EErNclQwxDeINp;
            jtIAwLhcEV /= jtIAwLhcEV;
        }
    }

    return jtIAwLhcEV;
}

string sSYwHOP::GLRMHBqkMPycJ(double JNrJXcdraIiMCoZH)
{
    int Naefjnt = -68364401;
    string ouVAPpG = string("eyLZERxz");
    bool yzqAfgZOgm = false;
    double yDBhsPK = 853258.260158745;
    int GGHQbGOPtfZG = 83831191;
    string yMLBTZhZ = string("wOxUWzHAjIBHlUVESPWeQuyxqJbIJeKJtJUrghZbQPBpcLVbpSOfeNSeWfCKvpoGELMVMexmIzmvKMLoGwNMCMjTEJPBeJcHzEyzPLhSADnOoMaepkKvmvwGwSzUoNdouCCnavQWpmNaHNSRZawWpHzMhBNokDbgxTfwfLLENmoXxiyatsWWzLDlWmMaZzhfLtMTmNFkWwjoIALEZOEeoYPCXCjgQpjtRstVXjpCLhPvBn");

    for (int pCuhVRPvBymxbI = 1638082683; pCuhVRPvBymxbI > 0; pCuhVRPvBymxbI--) {
        yMLBTZhZ += ouVAPpG;
    }

    return yMLBTZhZ;
}

string sSYwHOP::poKeyyz(double pveUzVSAYGA, double TOXjHDe, double HFdiTuYBD, int oWqljd, int iXAGodhQWUYomTZ)
{
    int kNnqQfWdVp = 1898537434;
    int PFCWllIpPDRJ = -1684186425;
    bool tnGvZbAgyZuAbXhu = true;
    string AkYCqQRroP = string("lbYqVTqYPrbEBFglzyMbzRCCxll");
    bool JCkZKFYuM = true;
    int coLJZdPHPUVT = 620997901;
    int AFSJn = 74270959;
    string GuLJFKt = string("yUTvTYEYWcRZUiTmAuhltInyKIevjuxXgcMFwgZNCVcPRVhDlnQLxQigrTnYTrkDyWVArQCcBDAZJHRpPTGrutXfifjXMEHcdPMyMuXUjpiDDApIOkFUztECcmtPsnVUvULiAtzRpvByTIaIksGDnjCFYKDYNziuFTVmvPZwxnn");
    bool CBGaKnssCMZEVP = true;
    string yvgpfi = string("oWFSMtNjddUJiksPAzpjFaFZwzXguKFXozivqiWIQfrPYYXhvjqjfssrlkCCXszTJmGFWBRfXitNFbakxVhbmWvtddSQmWoAQMcKPZoQgEPMzdOGiFptyokkAqrxXUxuBAIznloYESvQmqQTackyyYRHWOQudLKfoxUftNeQLoJAHnSkvDBnuJaClsDRmDIQvnbXpdHfgSgcdZiFMEyNklPeNqUna");

    for (int ChXDShFAZnbos = 1298333910; ChXDShFAZnbos > 0; ChXDShFAZnbos--) {
        continue;
    }

    if (iXAGodhQWUYomTZ >= 74270959) {
        for (int fywFkuftaYS = 1247725255; fywFkuftaYS > 0; fywFkuftaYS--) {
            continue;
        }
    }

    for (int AAnLtHeONgnRoLe = 1880225422; AAnLtHeONgnRoLe > 0; AAnLtHeONgnRoLe--) {
        continue;
    }

    for (int jHsvfkkAFBF = 1599604485; jHsvfkkAFBF > 0; jHsvfkkAFBF--) {
        CBGaKnssCMZEVP = CBGaKnssCMZEVP;
        oWqljd += AFSJn;
    }

    for (int XvEkPHCnZldMIUP = 1800353679; XvEkPHCnZldMIUP > 0; XvEkPHCnZldMIUP--) {
        CBGaKnssCMZEVP = ! CBGaKnssCMZEVP;
        kNnqQfWdVp -= PFCWllIpPDRJ;
        JCkZKFYuM = ! tnGvZbAgyZuAbXhu;
    }

    for (int GubcjRQFVYPi = 2091285298; GubcjRQFVYPi > 0; GubcjRQFVYPi--) {
        pveUzVSAYGA = pveUzVSAYGA;
    }

    return yvgpfi;
}

string sSYwHOP::HGYSWuCJqrimG()
{
    int VKfsuaEotIBym = -2051019763;
    double zFHcFgORSdpyT = -581218.0539598255;
    bool rEEuiKLCpUGCcO = false;

    for (int kTmYtqIYCjblm = 1309350227; kTmYtqIYCjblm > 0; kTmYtqIYCjblm--) {
        zFHcFgORSdpyT /= zFHcFgORSdpyT;
    }

    for (int LiwDNZKFryBN = 1526328356; LiwDNZKFryBN > 0; LiwDNZKFryBN--) {
        VKfsuaEotIBym += VKfsuaEotIBym;
    }

    return string("VDhRLZLebCRYOumhwmiguFJMfCAazEcBXdaTsgXWWwCDOjaYnGwTKIVNHfIwupHrBIuiRQVoHgWUIgHywrDurBMebJgQpNlKbfDxbmtYWJubQJKkfHgoyJisRLsDrcSCzZPieALXOEvrqBFqZfgxRoEt");
}

int sSYwHOP::yeheK(int NucCUAuMJrFF, double FfIOQKusn, double VOOvfJJOaL, bool ljBAPBzK, string fAShwzuIr)
{
    string EmHNAHGfFM = string("UZnbJTpxUSjTEPdENJYLAQQQkXZwsCVdoDqQQCntRPGitShVduYbJnZUoroiqEitdWHqBtFiAarTYkTXEwTgBLKGBPzDkFBEhntfdrhocErSNnjNlORFxtScaVWIIVivXgxCEYKRZgVKPjZllybEmIEqgiJfJNuWCgADjlajAlNLfXhEtfJnnNHxi");
    bool hpxCjTrnjNk = true;
    int vzLysEQeeHe = 724890775;
    double OCsaXXEgqEXYjz = -273107.2712477858;
    int usdvoPorADRJ = 1802928654;
    int TCPLlmcKChA = 75771472;
    bool opfTRPKEK = true;

    return TCPLlmcKChA;
}

bool sSYwHOP::xAkucTFpCjp(int QOXYHXzEOhfecT, double yKLiLJYsQzgPUAVr, string chmOOdn, double JmEzNAYWpRA, int gtWdQbmfXxf)
{
    double zGIylvMFzZ = -143014.15832332813;
    int MJTEpYPf = 427356834;
    bool kUBsKog = true;
    double VUOVuXjUYjVY = -164861.10549487575;
    bool aKzPTtvjF = true;
    string aUrxXRdEmg = string("BRHnzqcGisayxpdEqOOxPfeexCdTZGfMBdAGdsodRzkGGmcyKGoqEkJTtqIDamktiavbLiFIppvJKLUDBClzUBmMOFwSwULaiojRyYcUesCWHWBGCUoCyuLBmDRVoWcwySMkNtUxMISrZELLyAIKoCDJg");
    double MAZBnnBeif = -33690.31790009385;
    int hPNErFrcEccs = 151199317;
    bool OoEojNVALy = false;
    bool kItcvt = true;

    for (int hjCZfv = 2024683362; hjCZfv > 0; hjCZfv--) {
        kUBsKog = kUBsKog;
        QOXYHXzEOhfecT = gtWdQbmfXxf;
    }

    if (gtWdQbmfXxf <= 427356834) {
        for (int lfJXdCELfPiIT = 981630845; lfJXdCELfPiIT > 0; lfJXdCELfPiIT--) {
            zGIylvMFzZ = zGIylvMFzZ;
            QOXYHXzEOhfecT /= gtWdQbmfXxf;
        }
    }

    for (int DcWqvaaWbJQQiAH = 357258111; DcWqvaaWbJQQiAH > 0; DcWqvaaWbJQQiAH--) {
        OoEojNVALy = ! kUBsKog;
        aKzPTtvjF = kUBsKog;
        yKLiLJYsQzgPUAVr /= zGIylvMFzZ;
    }

    for (int xFCbhlBPcmMjd = 1246632434; xFCbhlBPcmMjd > 0; xFCbhlBPcmMjd--) {
        MJTEpYPf = MJTEpYPf;
        QOXYHXzEOhfecT -= MJTEpYPf;
        VUOVuXjUYjVY *= yKLiLJYsQzgPUAVr;
        JmEzNAYWpRA -= MAZBnnBeif;
        JmEzNAYWpRA *= zGIylvMFzZ;
    }

    return kItcvt;
}

bool sSYwHOP::XMsZENeNbpGZWPr(double PWBMYdvwDLGqe, bool YGiQYnpDOLRfbL, string UzYiEQBbri, int jDZWoiLejofGx)
{
    string kCuyvvjNbxN = string("OkgTAeypKaprTNFmpBFUTRYoijFzZlHBYcRWoHPFpIGFRIIRYAAoilDrQUjliyHZjxXuUNqmcsLskuPGzrIKKYFlSxDrwvsEyCQgwXcgptmNekQimepryvUQKgWPqwSegQrtFKoRfneLynETTLAbBgjEVsXtMJiZEokCvYXwCZBIGSWCCfXjYTJKNuAQOAfFrtWNTSHMFxWvFAjKbCBiyXJFeruYplaINDXurJKuXGijdUhNuacCyYTM");
    string fFRRMvbunSRcwdX = string("sCJoXAJitMcsTGtPtHILNOZNxWrRxCQFTyqszQKWShyaCzWnpidkWJwTIgAksQOEVwhlyeVKIUYwSEfzienVKcpRSjBmqqBfQTQhtLqwTJXuoAOhvSacbxNFdjglqOji");
    double ehtxKIbQNgx = -397379.8017706209;
    string MxcbiCcE = string("hFaFnmpISCaglwfcercrKXUQjKXQtNbGVYvZmhQcmwBpeTdfVHwrrabeaybfQshkjgvRrmTsZqTNcoGRFogdaPdgSqJOPANO");
    bool ZidMnMEDos = false;
    double LRxJqArNJWR = 11585.755322551766;

    for (int aOGQurWJ = 1269670724; aOGQurWJ > 0; aOGQurWJ--) {
        LRxJqArNJWR += PWBMYdvwDLGqe;
        kCuyvvjNbxN += UzYiEQBbri;
        kCuyvvjNbxN += MxcbiCcE;
    }

    for (int zofdurSkREhzU = 767750295; zofdurSkREhzU > 0; zofdurSkREhzU--) {
        fFRRMvbunSRcwdX = kCuyvvjNbxN;
    }

    for (int CJvaPJGgzPnD = 383849583; CJvaPJGgzPnD > 0; CJvaPJGgzPnD--) {
        YGiQYnpDOLRfbL = ! ZidMnMEDos;
        UzYiEQBbri += MxcbiCcE;
        ZidMnMEDos = YGiQYnpDOLRfbL;
    }

    for (int tmkIpKpP = 679282157; tmkIpKpP > 0; tmkIpKpP--) {
        continue;
    }

    for (int dEAFgjAKpaNqvb = 929690583; dEAFgjAKpaNqvb > 0; dEAFgjAKpaNqvb--) {
        continue;
    }

    return ZidMnMEDos;
}

string sSYwHOP::EZtcbxvLTMuPLdbs(bool UBQCcLT, int kQCvCvtTIH)
{
    int FGNspXBBameph = -1257791214;
    double HTAwfqBHEYofkyaz = -1036770.0205560313;
    int TLXOX = 2014910968;
    int OnCquCqOpbeXIPgX = 1598459561;

    for (int zJAczoWlOD = 530077987; zJAczoWlOD > 0; zJAczoWlOD--) {
        continue;
    }

    for (int sMrDs = 392610337; sMrDs > 0; sMrDs--) {
        kQCvCvtTIH *= kQCvCvtTIH;
        kQCvCvtTIH = TLXOX;
    }

    return string("GVpcaPLaMPDEdWEAubxIKMhqXMoGrhRLhjigOCFgkkxpHdLkQKNYiozhrlZooiyMmHkdTjZDrBCTbVPEiAsNXfTlzokUpbiEvqALVzBSVFZBCNnLXAnvGKycxFHQbWTYMVaXVsprKejpMiqiARAUrXuchbOEQYpIoTzjggNJecFtZOWorzPTipFSXTntlhUfiksCbbHtXMnraRlkqpifIqRNglvCwYjMCrzcFhSOlMTSOBoJxmoUFciYngk");
}

int sSYwHOP::NNYzHsvItkvVHL(double LVdEqJ, string YtPktPRnQQtdae, double ZZGrTklfDgS, bool wjYsS, int EQQqZshcE)
{
    double IdkWbWScYGDx = -1020769.6846947268;
    string dgeJgetN = string("TzIkHDreuDjuyGtzxvmLGLMOqVdRxAynDvdyNzWACauGcczDSgGGTNtpVSwEQYChokZrjmQSfAMeFuatWqheBuVfkoDyfCSUqAcVuEDuemRrOawYggiNggzbRTaESgldIaTfiqUyUlyuYEwEusDKVmPxqCZVzGDXVbtaBItjhhxzgchNEzAfmcHSBrfwrpEMXorYUIcqJqvCnQtECLyCrZvLNZbOdVSPoMqGHtuvJIBzeQEkZIrptCTtrVRLn");
    string kcJKsNNhmhzGNm = string("haMRPpfExAanYHtQxMfJACvaaVeMOQaQIkdvpGIbkvlgzEiRSsqCExRolpmIyqczNtHJrrcUJOreMMDwQuSkJdZzwHbkUDtUqZPNDC");
    double RxSWfqip = -562560.1161124023;
    double PaBhcpXxKtLSYQxt = 931344.6832515957;
    int kBDaFhbEDUdjw = -443917772;
    bool rdruxduTxEirQWRV = false;
    int fditSk = -180623259;
    double OPURbhdJBsexWshC = -85338.96442733664;

    for (int PkqnaqlKj = 1249086829; PkqnaqlKj > 0; PkqnaqlKj--) {
        OPURbhdJBsexWshC = LVdEqJ;
        wjYsS = ! rdruxduTxEirQWRV;
        rdruxduTxEirQWRV = wjYsS;
    }

    for (int VhwLBhsWpMiOgson = 442812929; VhwLBhsWpMiOgson > 0; VhwLBhsWpMiOgson--) {
        RxSWfqip *= PaBhcpXxKtLSYQxt;
        kcJKsNNhmhzGNm += dgeJgetN;
    }

    return fditSk;
}

sSYwHOP::sSYwHOP()
{
    this->KfpxNasXp(string("SmQwFfpdQgFvszvjkGUbQajLXWeSyMEKBnzLFbQVbHDzVCnSxfeKINxdhrxFiRTPEtuPYWqNSTVNkoGCBPYYrZHdZHZUjUlphaGbOQDBBnrzEovuhRXdHwsoIVIHsCsiQrSYihMmucsPPyYLtqhenGtNYprVXCSCXlokcktFvaToIxLhdukQwjFHTGuwnfADModiJQ"), false, -1766556818, string("DQJmTHrIqLldHCuFtwvRqMKlqBMQzqUoflVFhRriLESQmtvt"));
    this->vnBTuVkXdc(127938.9418253252, -2095415231);
    this->nvOCU(true, 423247570, 945736.8690719078, false, 878587.5469594754);
    this->ZurGCAAbarxTfMA(1212043172, 1504336299, string("PVxOnBDnLIENEuGSlxlSvyTcEBPLUQmBtcaDbIXbWZbdDkVfAtzbDcaEWfeOBASaJOzfHVhmBMHXHxEBJFVxTFdIbniVKFybUnVgCadAFbQlZYHkjlPOktozLVCsIDKwNEMrRsHeIAmYGoJKgSKueyngsAjJAX"));
    this->knzJmHHdxS(string("lceoiIcYfUHigYkXcmbdFoAAubNgIudvGBesYRStgvGsJVJaofZICvECfhF"), -982086.9664838535, 1539409311, string("WRhWNDozmuHtrEoqJrgkLcSXeFimTjSOUXPacVaYnUggQaulSkhdgWyjhMipjJRODaaIlOKNuhrEyNYFTHpGZUmqFdDQaqcKSJXqJrpc"), -302941.37482146977);
    this->CtuSliOksqu(string("RTetfcyIPlFVlsYPtwLisaunCUIUaKhHTYoXeuTlnbeRRJNtRmKFWScQlvgsXFKvJxbKgVljlzdOXVIZMkLPealEfucHYOtXCTavTyIiQRHgAYxcTGlNHAaaVmwjZh"), true, true);
    this->EBoxHtHvWujl(-1903939858, string("CFltvXRRTmRTBknCFGxQTGRSbmjuwjiJgYjHTLdJbTbDrPDmzYLBQNvLGiDQUzaLnKgeFwGiufzuJOsksyixtogCRaBYnuVzTCBaruKbBsoXZnBjwOnbsDNsdwEeh"), -741770.3635457985);
    this->pOwwgwFF(true);
    this->wLiGyzEGiK(1413608017, 276414706);
    this->QhjiPKMyRrmbuD(true, string("TKKCkHrKpvLEGuVCVDWchJcRLKnnIabJKCqmzuCUNSSPmbJweLeDTIOSkFHVTPZmnupCgULKoPbCZKhEXHskTLxVOPfNBRtGVhoMLRGtKQSBvBroYOatRePViTHSexesLsjhtishyIdsqxFVKaLCDlWvoFkVkzRAqFePBuEWjASHayrkHDgpZsvEcCXVisUTRXFaaFPGcOvBcOFXOIQYtunqxdbFCXeHmQryQwinmlouuTNiRRMpKbnFLn"), 2135531996);
    this->RmbmBgqMfSLC(false, string("PaFZIoOKGUtKbicVJoLCWignKRLueFoNDUUarXiKiQvvBNsHMqNvbeSRWmkNoehCtGFCsrVILQgFowKIJhhxxdGcEPLVzPvNInfnmVDeMeszNMPIqC"), string("fdTrkLMUCQCTULwDgiClvBWsNwymGwvdHRoPRdDVPpCulSAxBJkkfvwfDICOlMUCDcXsGkqrtGjJxaCElDpGpyBsr"));
    this->GNWDMvqRgUIqN();
    this->GLRMHBqkMPycJ(1016658.9870196943);
    this->poKeyyz(819227.9874115054, 975993.2749704166, 864149.1505295727, -2094150779, -1134283569);
    this->HGYSWuCJqrimG();
    this->yeheK(119327083, -349108.7440673567, -77706.15202243514, true, string("pzrPSOjmUznDuxVJJjCzEngyNgJDBaSvkYVGwAhvpRAyEciA"));
    this->xAkucTFpCjp(-790763557, 300771.51103031234, string("DPXVoMacHLBxHwpiHcxWjxOqMFiHvmspJFmlwEwDmkqahMYbnwjCnhWNwsFRPSOsiYeynONGDyASYnGyqKSGKF"), 576807.4117653002, -1832577796);
    this->XMsZENeNbpGZWPr(323974.89257778093, true, string("nmnBASrATcBlCWpTcizlGSwpqMdRqQzfrfTfllJgpNXDmkzNLNoCJPqfQMSNGOVhAiyXyVElYeXZSBBbXRVCafIhvpbBRXkVrKUglQpKdWKguWmkMgGseKXzmFpeoeGQbsnMxwHMfUcztYFLaVJswjcIoARzXYKtdrQFhdfYukuMOhTllnFyPA"), 1822118433);
    this->EZtcbxvLTMuPLdbs(false, -1937353725);
    this->NNYzHsvItkvVHL(-863235.040808543, string("ODEKywzcAlwWbAfUpGQLPDbCsfhxQhErNVZSgsnGvzIIdGmFpnkxPdNqkMiWnTUaKvvBUCQOfKJgkLgBPFaHjkmOtzfIMfzxMnhjp"), -364576.3400854407, false, -1979388714);
}
