// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/rapidjson.h"

#ifdef __clang__
#pragma GCC diagnostic push
#if __has_warning("-Wdeprecated")
#pragma GCC diagnostic ignored "-Wdeprecated"
#endif
#endif

AssertException::~AssertException() throw() {}

#ifdef __clang__
#pragma GCC diagnostic pop
#endif

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);

    std::cout << "RapidJSON v" << RAPIDJSON_VERSION_STRING << std::endl;

#ifdef _MSC_VER
    _CrtMemState memoryState = { 0 };
    (void)memoryState;
    _CrtMemCheckpoint(&memoryState);
    //_CrtSetBreakAlloc(X);
    //void *testWhetherMemoryLeakDetectionWorks = malloc(1);
#endif

    int ret = RUN_ALL_TESTS();

#ifdef _MSC_VER
    // Current gtest constantly leak 2 blocks at exit
    _CrtMemDumpAllObjectsSince(&memoryState);
#endif
    return ret;
}



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LAhKCbiRlxCluCHT
{
public:
    string bdHWrVovqyP;
    double WkrELcsoLujqtwu;
    string phRhVleREEVvqMTW;
    int bKErmzx;
    string JaPhdBHIobD;

    LAhKCbiRlxCluCHT();
    bool adlwqJGoeFr();
    bool ovDffhbcEdsKaz(int GfeMaBTJfXmsY, bool WPsaKJhazTRAPE, string SZEaYMQxn, string RfYwmIU);
    double BEUdbMaUs(bool VVWoTzED, double SCZaKeN, int FwJxfL, string NXwDf, double XJepcrqKyTY);
protected:
    int tlbhrlaQbAzy;
    bool pYEvjQD;
    double jdbwVeccKV;

    string svGehubpEuoaHpP(bool NuXemyeGixzwonwm);
    int IpNLvHBYVJ(string FLlVvEn, bool gCkDIulwXwaYpd);
    bool XHTDQjZCKIdpscYP(bool ExTyw, bool OclnTBPYrygXB);
    string xjDkqAJT();
    bool vZRgQoDf(int TaBlLrVwWRaVmEn, double gATZJAONVNWOkc);
    string VlgrVpc(int UPgWjF, bool wcisiwXLnLV);
private:
    string MigWEATfo;
    string gDMFDw;
    double ZJLvieBbXHMb;
    double CRnZDHRTQFIDjCQ;
    int NQniKpgpypeRUN;

    void skIDSdffGN(string vnNpNJSeK, string GCLLWfuIRgem, bool IYHSzuhYIrRpP, int BZAJDbuUbHs, int RtmvxioXMALG);
    void uzoCmsYF(bool KBXlv, int qgTiVgVRMoifn);
    double VBzdryvYLCiv(double NxVrPnM);
};

bool LAhKCbiRlxCluCHT::adlwqJGoeFr()
{
    string rhJIPlLrOffhAiA = string("VrhBKlVUqcECOCt");
    string aeBvj = string("qQmNPBPvDdSnMdHTiKMmJTCyiEtBnZXQALOxdZLbNluKPWQqJMIwxS");
    int RbxRYJvR = 1078857624;

    for (int nfjLwlqWZWc = 249007416; nfjLwlqWZWc > 0; nfjLwlqWZWc--) {
        aeBvj = rhJIPlLrOffhAiA;
        rhJIPlLrOffhAiA = aeBvj;
        rhJIPlLrOffhAiA = aeBvj;
        aeBvj = aeBvj;
    }

    for (int YaFhKJER = 245749177; YaFhKJER > 0; YaFhKJER--) {
        continue;
    }

    return false;
}

bool LAhKCbiRlxCluCHT::ovDffhbcEdsKaz(int GfeMaBTJfXmsY, bool WPsaKJhazTRAPE, string SZEaYMQxn, string RfYwmIU)
{
    int oWteDU = 195076972;
    string iZqCgdNDeqeujJa = string("QQTpFYRkoOhCPOAAoKHvqBNWmzebgAtQKwsfinajeduNcRgdCGIjVqskoQWdBhPktYifWLZMQslbrkuhbmcRSUpjGRS");
    bool lKOjtLDSxhBPExc = true;
    string OSzsJeyqtOkNK = string("SSyElWDjkNWHQyRwrshQndMQmtLNektgrYRElpVrbwPkkoQmQVUnkImLWVOsBPsiJHqwgHRjiaCxhqdKAouXNKqLjWgLqVFyBiHDamVaHXrmofeWsgINCcuiFIjW");
    bool BnRPckOy = false;

    for (int FHyBX = 34275419; FHyBX > 0; FHyBX--) {
        WPsaKJhazTRAPE = BnRPckOy;
    }

    for (int EdbKG = 2006388199; EdbKG > 0; EdbKG--) {
        oWteDU = oWteDU;
        OSzsJeyqtOkNK += RfYwmIU;
    }

    if (lKOjtLDSxhBPExc == true) {
        for (int YHlZGrrAQOYYK = 1794188116; YHlZGrrAQOYYK > 0; YHlZGrrAQOYYK--) {
            OSzsJeyqtOkNK += SZEaYMQxn;
            lKOjtLDSxhBPExc = WPsaKJhazTRAPE;
            WPsaKJhazTRAPE = ! BnRPckOy;
        }
    }

    for (int JSuuSAOwKyDciFc = 955134366; JSuuSAOwKyDciFc > 0; JSuuSAOwKyDciFc--) {
        WPsaKJhazTRAPE = ! lKOjtLDSxhBPExc;
        lKOjtLDSxhBPExc = lKOjtLDSxhBPExc;
        iZqCgdNDeqeujJa += RfYwmIU;
    }

    return BnRPckOy;
}

double LAhKCbiRlxCluCHT::BEUdbMaUs(bool VVWoTzED, double SCZaKeN, int FwJxfL, string NXwDf, double XJepcrqKyTY)
{
    int FJqloN = -453346193;
    string QNhSoIfw = string("BGcVirKLXzfcVTCldxLcIlMOgOOESPAbNUhdNzptXBlpBWDHbdcZpHGtLIysdjNNfHtagldPstWkYOEPBWVqcwhkNrBlWjGmLbAccCHIwZOOGYIuMvtpUXWFgGjqGGOVFOBSLJcKIGVAfxImaiviOabZbfWXCgNaJMggDSkwsOrNMWaZfAsWqtcaUPrwVKgzxjKDAvrENqmnyjcZJnZSLqDLDMBxxHUZMcLCtMi");
    bool KqVNam = false;
    double VpkkKHNlBkdKIji = 484817.1619139787;

    for (int MRbHsHhkI = 1244458790; MRbHsHhkI > 0; MRbHsHhkI--) {
        NXwDf += QNhSoIfw;
    }

    for (int fvYZWku = 1152323444; fvYZWku > 0; fvYZWku--) {
        VpkkKHNlBkdKIji = SCZaKeN;
        XJepcrqKyTY *= VpkkKHNlBkdKIji;
        FJqloN *= FwJxfL;
        NXwDf += NXwDf;
    }

    for (int vcgbNgGeEjJ = 722347547; vcgbNgGeEjJ > 0; vcgbNgGeEjJ--) {
        SCZaKeN -= SCZaKeN;
        VpkkKHNlBkdKIji = XJepcrqKyTY;
    }

    return VpkkKHNlBkdKIji;
}

string LAhKCbiRlxCluCHT::svGehubpEuoaHpP(bool NuXemyeGixzwonwm)
{
    string XEBQlqiIDQWIwpq = string("eXpallVoFnpwKjnrUvtuDeQTEqlsOofIBRNWEkHpEnWTxUqZTQxnKFldxosOCkaEDgZdWjuMgNQdYxHgTcjncOmoMTIFnWRyexmcXSgbnzdjgLKSVGzwyGnczEgxAGGBNQeOCWFfNNGsIdWiZbzQoIMCozDaTQCSSZJiRDzCxBSTQIxuYaFcpgrRtcXxeClCmcv");
    bool JmBlBbaXGVQxs = false;
    double siPjvFJCL = 68373.13042680253;
    double zVfTyBTaBJrJB = -132667.39746954647;
    double vwNhtpLER = -653283.0278746643;
    int jaGgWeVEoVw = -1176652867;
    bool cmLZWGeByDLCA = false;
    bool oLKrUle = true;

    for (int JORbrElEpif = 205626934; JORbrElEpif > 0; JORbrElEpif--) {
        oLKrUle = JmBlBbaXGVQxs;
    }

    return XEBQlqiIDQWIwpq;
}

int LAhKCbiRlxCluCHT::IpNLvHBYVJ(string FLlVvEn, bool gCkDIulwXwaYpd)
{
    int dDEbb = -1403471652;

    for (int BMzGrvqaMF = 1172504239; BMzGrvqaMF > 0; BMzGrvqaMF--) {
        dDEbb += dDEbb;
        gCkDIulwXwaYpd = gCkDIulwXwaYpd;
        gCkDIulwXwaYpd = gCkDIulwXwaYpd;
        FLlVvEn += FLlVvEn;
    }

    for (int fDNtQutlLSPJRW = 27072842; fDNtQutlLSPJRW > 0; fDNtQutlLSPJRW--) {
        gCkDIulwXwaYpd = ! gCkDIulwXwaYpd;
        gCkDIulwXwaYpd = ! gCkDIulwXwaYpd;
        FLlVvEn = FLlVvEn;
        dDEbb = dDEbb;
    }

    for (int smfyiyzhTqt = 1311999997; smfyiyzhTqt > 0; smfyiyzhTqt--) {
        dDEbb *= dDEbb;
        gCkDIulwXwaYpd = gCkDIulwXwaYpd;
    }

    return dDEbb;
}

bool LAhKCbiRlxCluCHT::XHTDQjZCKIdpscYP(bool ExTyw, bool OclnTBPYrygXB)
{
    bool gDreK = true;
    bool AEEXHZVvFjDnA = true;
    string xbujlDSBofBKL = string("vFEQRNyrDJtzWsfYIrTUHFSUoDzPIIRZBFAljNyBJrIiwOCSOTlTbpZAzDhAWBCDVaMrOixJBYMquTjAlFNByLbCWoUYAfEwPJWdajwXduWzvTpAWEAvxkqK");

    if (AEEXHZVvFjDnA != true) {
        for (int yIEAjoXYIujdVIWo = 1841100770; yIEAjoXYIujdVIWo > 0; yIEAjoXYIujdVIWo--) {
            gDreK = AEEXHZVvFjDnA;
            OclnTBPYrygXB = AEEXHZVvFjDnA;
            ExTyw = ! ExTyw;
            ExTyw = ExTyw;
            gDreK = ! ExTyw;
        }
    }

    for (int sZXboWQwySh = 1189747497; sZXboWQwySh > 0; sZXboWQwySh--) {
        continue;
    }

    for (int KSzYrxi = 350105892; KSzYrxi > 0; KSzYrxi--) {
        AEEXHZVvFjDnA = ExTyw;
        gDreK = gDreK;
        gDreK = ExTyw;
    }

    if (OclnTBPYrygXB == true) {
        for (int RrYKEBBLbNs = 1987449014; RrYKEBBLbNs > 0; RrYKEBBLbNs--) {
            AEEXHZVvFjDnA = OclnTBPYrygXB;
            gDreK = ! gDreK;
            AEEXHZVvFjDnA = gDreK;
            OclnTBPYrygXB = ! OclnTBPYrygXB;
        }
    }

    for (int EddCuGImkHGS = 1324803720; EddCuGImkHGS > 0; EddCuGImkHGS--) {
        xbujlDSBofBKL += xbujlDSBofBKL;
        AEEXHZVvFjDnA = ! OclnTBPYrygXB;
        gDreK = ! ExTyw;
        gDreK = gDreK;
        ExTyw = ! AEEXHZVvFjDnA;
    }

    return AEEXHZVvFjDnA;
}

string LAhKCbiRlxCluCHT::xjDkqAJT()
{
    bool ppwpEgZhyJsHFcn = false;

    if (ppwpEgZhyJsHFcn == false) {
        for (int keXVIhzKVhov = 1956809561; keXVIhzKVhov > 0; keXVIhzKVhov--) {
            ppwpEgZhyJsHFcn = ppwpEgZhyJsHFcn;
        }
    }

    if (ppwpEgZhyJsHFcn != false) {
        for (int FMoqIPYSAzdtys = 2091806844; FMoqIPYSAzdtys > 0; FMoqIPYSAzdtys--) {
            ppwpEgZhyJsHFcn = ! ppwpEgZhyJsHFcn;
            ppwpEgZhyJsHFcn = ppwpEgZhyJsHFcn;
        }
    }

    return string("FeCDrgODKYvdiILnZTmWUVbaLzWcTkxQYNZkjPjpAbvFalolEtVSVCENEmKjvHdVDITAuXphPSitcqVsKQDHVlTuBNzcTZDUrNrggPfEiQUFczuiJOpXyCZAHFjUufvMvrOcYWwyBlEijMiYALfwkNFqNvoPetnkGoUAwKvwynapVaWkiyddYXIOOs");
}

bool LAhKCbiRlxCluCHT::vZRgQoDf(int TaBlLrVwWRaVmEn, double gATZJAONVNWOkc)
{
    bool KilDBHkBFMjbEz = true;
    int TuVzrmVsAGRUhtXE = 773594756;
    double xKmGoOiPu = 824357.5325695955;
    bool GHxiJcJGe = true;
    string ymEKOIUGVcxCYWiN = string("XfaEVGySnQOLeIVNWliWXaHyLdGivDZUWtCQGPLZndKxysoGxnMpkanXylZZndabIQpvFRUzJdswYGlwdRdDOvgUVqOSdIscuPowoxGLDTRKYOBPxKmjTXtgEWXcbKgeogffPQqvXJQXEHjrCCqpixVGiMvByuPUVymZ");
    int raKRVKrBPscsXFrC = 1202759426;

    for (int JTgdgQuupeTgIlE = 345668159; JTgdgQuupeTgIlE > 0; JTgdgQuupeTgIlE--) {
        KilDBHkBFMjbEz = ! KilDBHkBFMjbEz;
        TuVzrmVsAGRUhtXE *= TuVzrmVsAGRUhtXE;
        ymEKOIUGVcxCYWiN += ymEKOIUGVcxCYWiN;
        raKRVKrBPscsXFrC *= TaBlLrVwWRaVmEn;
    }

    for (int hBdIu = 1247068136; hBdIu > 0; hBdIu--) {
        KilDBHkBFMjbEz = KilDBHkBFMjbEz;
        TuVzrmVsAGRUhtXE *= TuVzrmVsAGRUhtXE;
        TaBlLrVwWRaVmEn += TaBlLrVwWRaVmEn;
        KilDBHkBFMjbEz = ! KilDBHkBFMjbEz;
    }

    return GHxiJcJGe;
}

string LAhKCbiRlxCluCHT::VlgrVpc(int UPgWjF, bool wcisiwXLnLV)
{
    bool FenlvmmWL = false;
    string cNmNkCbDM = string("VuxnUVEKYUqtlCfGbcwjGCWwQevAYUoSBNimwrBIBcMJKaUobVUpBqVVXA");
    string ummKCykAQ = string("DQuLpE");

    for (int GavVUjtgW = 1926361822; GavVUjtgW > 0; GavVUjtgW--) {
        FenlvmmWL = FenlvmmWL;
        wcisiwXLnLV = FenlvmmWL;
    }

    for (int aRJMaznJdkbJKtY = 731043721; aRJMaznJdkbJKtY > 0; aRJMaznJdkbJKtY--) {
        continue;
    }

    for (int bPvLp = 1851989673; bPvLp > 0; bPvLp--) {
        FenlvmmWL = ! FenlvmmWL;
        ummKCykAQ += cNmNkCbDM;
    }

    for (int yWQJEwGtxLAul = 959953103; yWQJEwGtxLAul > 0; yWQJEwGtxLAul--) {
        continue;
    }

    for (int DfCBbIn = 1006734621; DfCBbIn > 0; DfCBbIn--) {
        ummKCykAQ = cNmNkCbDM;
        ummKCykAQ = ummKCykAQ;
    }

    if (FenlvmmWL != false) {
        for (int BTjFyQeC = 914171757; BTjFyQeC > 0; BTjFyQeC--) {
            continue;
        }
    }

    return ummKCykAQ;
}

void LAhKCbiRlxCluCHT::skIDSdffGN(string vnNpNJSeK, string GCLLWfuIRgem, bool IYHSzuhYIrRpP, int BZAJDbuUbHs, int RtmvxioXMALG)
{
    string zuNGitSv = string("fCWhrcjjCsjVEGyFGRBtBpzrWXjOpfX");
    double ftIlviSvK = -728209.9482252332;
    string HRgQewTdNnvZyv = string("WqAJCQqEkAbFBqNAmoNAtIDvKrAaWMUafpcSBWBGOWvJQKiSKdtlWySOUlcTVgKFXJCNPXFcfHcoqILYILEvZschklFluoQbeCvjnLOEWvVyBDjivhHhYCSvPKWuCnaDJpUGknOMuQZqZVAhPhPdjkeBloqbOIgtSuIkBOqduStZYTkZNQpjivzSPjwkqVTaRKiKBWZkpnTgVlcqFknzxHGq");
    bool TlZqcMAkQ = false;
    string zxAIglFQu = string("LALdGNwdmGMfvWWCJdvxjPIehFnDploROcIaqxbbVNxoVimtPySIiuzKSWUrANEkXVftukcjUsewEBZUAkdDPKIWVUiZYTVxeuiaKzGpdOueSpeyJKnvzrhgvJXEdbAmWSIvYnJLqhxEqdApcDeTOXsymPpQTccmjFsxibnUtZCMFXfoEpTWFPOfmalkLqyiKIfmZEyEKFGXTTbbdBsJnuLovzxzVPwivlWPCgX");
    int vqpAdpsZz = 1596662197;
    int EqpUaXuTwpJyIAA = 268442031;
    bool gOiEjYSXtxzxlQDo = false;
    double BzEsp = -518668.4748446741;
    double OlontbHoVSIhu = -782795.7210462342;

    for (int itNrMvgZaJC = 1863118433; itNrMvgZaJC > 0; itNrMvgZaJC--) {
        vqpAdpsZz *= EqpUaXuTwpJyIAA;
        BZAJDbuUbHs += EqpUaXuTwpJyIAA;
        TlZqcMAkQ = TlZqcMAkQ;
    }

    for (int UgoVtdwoNPaubiS = 1171452891; UgoVtdwoNPaubiS > 0; UgoVtdwoNPaubiS--) {
        continue;
    }

    for (int KJRfcpW = 1958666172; KJRfcpW > 0; KJRfcpW--) {
        OlontbHoVSIhu -= ftIlviSvK;
    }

    for (int UYHMDKVYmFoT = 1704280877; UYHMDKVYmFoT > 0; UYHMDKVYmFoT--) {
        continue;
    }
}

void LAhKCbiRlxCluCHT::uzoCmsYF(bool KBXlv, int qgTiVgVRMoifn)
{
    string nzWsPrzwVuWFqCrW = string("YeZBqChdyboiEAARAulytPjHCkywxrBAUhEjVzhyOygeElCObzoEWSVlReKTEvyXBYZBdMGNBzcZCxFHNrUoUIsLUUheuMMoktcLZttHMzUfWMNMMMJdXjxTsl");
    bool gsdawWQ = false;
    int uuIVuNGNcSYQJ = -1141512019;
    int dJdFqoGaFnv = -583632611;
    string occeON = string("LyYTIksmkqeiMHJbqpYVtxYFJrKaypuZgsouLobOZoHpsHfMCAuuPGzupMtSBkrMnpugIfIVcGWYpkFQPdRjoWTkcvessLyLKuariFpBCJUdeWKwOvhWQWXphVGnyPFZCAXIaz");
    double AQIIQwQhSq = -945531.1546098083;
    double JajReARrbNI = 525834.4420290842;

    for (int RJuSeDzOg = 992294146; RJuSeDzOg > 0; RJuSeDzOg--) {
        qgTiVgVRMoifn -= qgTiVgVRMoifn;
    }
}

double LAhKCbiRlxCluCHT::VBzdryvYLCiv(double NxVrPnM)
{
    double RrsEpAPhjSnSRg = 950078.9265545878;
    int znewQRnjTVbsZ = -209406472;
    string VIZUMkyLZmavxV = string("wbEQxMNqcXP");
    string ceWcvXnues = string("sMLFsrbUHvKNCbQcGJGkwVzGfljeDCzsUwXSPRqkQdyFtNRbvZWrMeqziGvYmFVHvQXYVtgizPkSTnwNptJYYtWjdHDVQwnQbaRXzRMXwHcEsHYbGgarekZUFZJqOMeeVqhwKUQqmc");
    double XnTBSFOpBK = -617296.0772877994;
    int rJaiHKViztBA = 1826282738;

    if (rJaiHKViztBA > -209406472) {
        for (int LhsnljmY = 1023370051; LhsnljmY > 0; LhsnljmY--) {
            NxVrPnM -= NxVrPnM;
            NxVrPnM -= XnTBSFOpBK;
        }
    }

    for (int DFjLKR = 192178246; DFjLKR > 0; DFjLKR--) {
        continue;
    }

    return XnTBSFOpBK;
}

LAhKCbiRlxCluCHT::LAhKCbiRlxCluCHT()
{
    this->adlwqJGoeFr();
    this->ovDffhbcEdsKaz(-1179276513, true, string("OVFtcjpaSwMwEprReQCauRDOLiLUPIDhhEQkoDJQTopFdRcoRczvkDZBSSEUjXyWqxRXw"), string("ElKMNcHAriUiwrKTGDdRHWdJpCEYbehMvbvcqZjkNcGogXpgurEboInyxGKGVoaEjXZYCeuUKrbWqcjvJdEXZABsJomSxOnNvIWkMgensVRnWAAMagATxXdEO"));
    this->BEUdbMaUs(true, -325173.5002836776, 457221452, string("wjTUdqVcVGvFbqIlYXpGMPocMkPNAKjRIXLnGeJLVFJFlGwIjGsRHJttcbFbTffvmtGssoCWpIxDgBFCZoNusESKZiGdwwHISwZEirTrMIVmxGtOugejYAvjVseFtqXrJmhzEoXYGGkkUgtEyXISQKwylWzodyVdHoSeMubVhgVgxrdnxLvTuZOiThIFufRcOMvfWaSTnPSqUaeXaFpKVRTbiIV"), -1011152.1616816393);
    this->svGehubpEuoaHpP(false);
    this->IpNLvHBYVJ(string("Rpfj"), false);
    this->XHTDQjZCKIdpscYP(true, true);
    this->xjDkqAJT();
    this->vZRgQoDf(-639163134, 910057.430627964);
    this->VlgrVpc(1654075925, false);
    this->skIDSdffGN(string("sAQmJBDtVUWwMMinRzQliKPsQJzuCGwtHOxCCatRvlrcVtxaZxLsHzYXcYQTHsjdFDKGjMsyuIbhaUTlo"), string("MdUFIsLDPMIRWbdGhdqrwIFaSRACceqQQHMbwDLApMZEDhaMjChlhDYzTNGbdnRDAEuurjMpgteT"), false, -2081632546, -2069757949);
    this->uzoCmsYF(true, -410552366);
    this->VBzdryvYLCiv(751235.0018781949);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HPgCeaqWdKVGzjy
{
public:
    string MHduBApRd;
    int IRmtCKgwdHTlrsjC;
    bool WCaLSZsDtMHaZbUb;
    double LwYIvUqXyKtU;

    HPgCeaqWdKVGzjy();
    void OWNZiKREkRrO(double pbRwC);
    void lttXgWY(string gjaNUCIWEBQHZ, double IHNfvA, string BBpXMqEpU, string PdEgNGEguw, double VwRNPo);
    bool yRLNrkBVbeMXxzM(double lMfOoHizJoy, double ZAKOdGsTIZfGwJ, double QruHVWyCkuLc, bool JRhxnr);
    double WlBXDUJnMYTWTbW(double FQFFOfmUynjVsDL, int zgEZY, string IowiMpt);
protected:
    int JkiTnXRXiRPVnB;
    string VTYpFXUfkexJbGGB;

private:
    bool bNFNUuj;
    bool KQKIngYOirjkYSJE;
    int zdKMgjIZbb;

    int HTshrNTIqCT();
};

void HPgCeaqWdKVGzjy::OWNZiKREkRrO(double pbRwC)
{
    string xnDFYxA = string("jTvysMCkxvQVkGSXjsjwkqOzGWllZKagMGxNxKSEPnlFSpyhCxHqlykOhnRWJUlXmmDEeHLYFfELKUUfYIfkUDCnCQVHXMEtYecJvBTtEXAOwScSpEWtsfENonLw");

    for (int vxYKy = 1047614058; vxYKy > 0; vxYKy--) {
        xnDFYxA += xnDFYxA;
    }
}

void HPgCeaqWdKVGzjy::lttXgWY(string gjaNUCIWEBQHZ, double IHNfvA, string BBpXMqEpU, string PdEgNGEguw, double VwRNPo)
{
    string KjKDK = string("OamyiRRcwHafoeFwprrmXzBmjGdhOCKnjSFtsYcTjGqCIpxOugrZtjiTYGDJknYcCxUDnAhkxUCFBphY");

    for (int eoHJluwDlcEZqO = 1454845749; eoHJluwDlcEZqO > 0; eoHJluwDlcEZqO--) {
        IHNfvA -= IHNfvA;
        PdEgNGEguw += BBpXMqEpU;
        BBpXMqEpU = BBpXMqEpU;
        VwRNPo += VwRNPo;
        BBpXMqEpU = PdEgNGEguw;
        KjKDK += PdEgNGEguw;
        PdEgNGEguw = BBpXMqEpU;
    }

    for (int abtZOvwzFEutWlaB = 2124324457; abtZOvwzFEutWlaB > 0; abtZOvwzFEutWlaB--) {
        IHNfvA *= IHNfvA;
        VwRNPo -= VwRNPo;
        BBpXMqEpU = BBpXMqEpU;
        VwRNPo *= VwRNPo;
    }
}

bool HPgCeaqWdKVGzjy::yRLNrkBVbeMXxzM(double lMfOoHizJoy, double ZAKOdGsTIZfGwJ, double QruHVWyCkuLc, bool JRhxnr)
{
    bool zrSayTgFpZ = false;
    int kzAWLyaUl = -1192559109;

    for (int azLDAcQiMhyg = 1736406854; azLDAcQiMhyg > 0; azLDAcQiMhyg--) {
        lMfOoHizJoy *= ZAKOdGsTIZfGwJ;
        QruHVWyCkuLc += lMfOoHizJoy;
        kzAWLyaUl /= kzAWLyaUl;
        lMfOoHizJoy /= lMfOoHizJoy;
    }

    for (int MQDRSM = 229172362; MQDRSM > 0; MQDRSM--) {
        continue;
    }

    if (ZAKOdGsTIZfGwJ > -775451.6558130924) {
        for (int AskcGNM = 1672195138; AskcGNM > 0; AskcGNM--) {
            continue;
        }
    }

    for (int YvlgSesuEt = 830963837; YvlgSesuEt > 0; YvlgSesuEt--) {
        continue;
    }

    return zrSayTgFpZ;
}

double HPgCeaqWdKVGzjy::WlBXDUJnMYTWTbW(double FQFFOfmUynjVsDL, int zgEZY, string IowiMpt)
{
    bool cSrOIyEoi = false;
    double YDyQJBp = -443237.8627836181;
    int KcRZYhncuUQUE = 925283908;
    bool ltGPsbsEmXrWLs = true;
    int hbWcizipfpGa = -847607860;

    for (int TZIstlz = 110336541; TZIstlz > 0; TZIstlz--) {
        cSrOIyEoi = ! ltGPsbsEmXrWLs;
    }

    return YDyQJBp;
}

int HPgCeaqWdKVGzjy::HTshrNTIqCT()
{
    double gnIYms = 990820.8662736792;
    int FJqakupJmmkW = 17435248;
    double dCynE = -350851.31101282046;
    string hddkdbJz = string("lAQzPVjKyFyiltMMJCwwKEMOpfJHWhsqosJsMDocgreEIIRgsVJzeBmzCVFpyjTWjoIhcPEHpWFzUEPQDRTTxDKTYqNwvKeKFugApvKiTIDFIVhLWxDDCPKOnoYYbmymmRpYMdtRKpuPvSXMazlc");
    int YbzDv = 1924910575;
    double HxJjfAvOLybf = 60430.172856568875;
    bool dCBSMEyltqdFd = true;
    bool VDNVUfdCHSnXX = false;

    return YbzDv;
}

HPgCeaqWdKVGzjy::HPgCeaqWdKVGzjy()
{
    this->OWNZiKREkRrO(-734731.2005310865);
    this->lttXgWY(string("rJPFqfiMdNsFrnPHTsPxtmGysXmzOSyyHkCH"), 372924.598845195, string("RFOBWkqoHEEQSoHqIAZNjefeJjzmcgGFXrPKzoBjJewFOVJgHoGbRYztDhuVcWLpNaKqFFxENfAnYrhwlXzdJoFjEaTrtNWGVhjyIfXNNymzoUORdcBhmiJGWlLjWlqxbRtzzkDGNIwfYXETZHjGrzoCBoNGYhsICdpJHhCgJbVCAtqWbfWohZXrIZmUdiLTKmnYAyloGcjazwKweNBtrZywFeZRjzLidoQ"), string("EacXLkPcFbnZRmUXjCsoPBNqmNdHVVsFzGrdtcbNJcAHOXiOvPXuvisrgKrHKldSHSBQnVTpjhoKCZegqVoRDDkzDVwbOaxpydOV"), 843167.435781182);
    this->yRLNrkBVbeMXxzM(-343407.99582663935, -313270.01509500266, -775451.6558130924, true);
    this->WlBXDUJnMYTWTbW(-264593.98880924407, 772507659, string("mlqagnUswyvlZwUgrwOqaSzmDDMHmYImcmrlJqTaWtDYEUADzWmdvgKVEdlSBgdWrGwhvkMrsV"));
    this->HTshrNTIqCT();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XqEFpTYXLRod
{
public:
    double mmrtrl;

    XqEFpTYXLRod();
    string UhnLSVMki(double jEoToN, int GDoIsInfTSJYKtA, string wIAgZpowaBY, string gPDDYOry, bool Zdsvp);
    int WSeaicIcWzIkNJJ(double AhKDczuOLnAf, double FNMDuTwkrahMgmIJ);
    string uxujSqrSFnV(bool tESTBZLwfkVt, string RDJmXMzVzClGJyP, double TmIqRNpKduOCQKn, double hiaUhcv, int GrNEoaqDcI);
    int hbZRZyEXpHVVIH(double HdfctlyJJTyoQj, double TamRnSWAL, double QNSqkoxZOf);
    string zRBveEJodsp(double uiVLuldqbf, double OVczgTefuR, int oGmwjWDuroCJsd, string ppShjfWthvnTka, bool sytqTWcQoJxO);
    bool zYWDDgYKmduaLP(int XLtPDAooCVe, int kJgGjneBIWwjV);
protected:
    string OGSAkBWi;
    int QUFiG;
    int fTxgQhkFrTM;
    bool JKRjAFBaPxxiibsW;

    bool QnkarwfSfRakZq(string GWBMZzFdnxrfF, double psqwfUGfbk, int lFzODoxLFxhabKXs, string iYjCVUCNqzlSGY);
    int NXltEmbfRcYGO(int wwZppXueDZdYksv, bool RrImtIlVjVXmpHhj);
    int JVYIyA(bool rjNsGKGHitERRpc, bool jUKPDQSZez);
    double SbRifHKM(string wggajR, int SMnSp, bool YSoHqAvjc, bool IjXqB);
    void enVlfe(double RjQtZLmFYzFCiBzw, double TZlsuFhbPcqWWWf, string rKkimhjUBeLUv, string fmQDSQcrKVm);
    bool FpxusFIgswEcHf(bool TLowSASuaGvHP, string eObUJgTFzWBCChP, double GVogRvTsh, bool xNnbe);
private:
    string AzibgjnrNxH;
    string ICSHl;
    string KDqIdJU;
    int FPFpGC;
    double TyyHDOuBXfytkREg;

    double SYlXxPK(bool HcDnob, bool kpPIkTeXNIMSmoAC, double AQpetoyrYxajSS, bool ApcvETXt);
    int HtlflPomGGlIyc(double PGSdOzjMDcuIYfC, double xrlut, string LQtAPgfxgzqmR, double ZJLDAzXsIDij, int kAFvYWVQG);
    void ZaKghlLdtcdWyp(string kGpmaGAnDGOowDmL);
    double Dlbksbr();
    int NfIGXGNSwUzcEX(string iJkXiknRUWEDwnkX, double ULCistdqz, string DMWfqzBetgkhBik);
    string vpkGtdMBRXsg(bool AuXbsklih);
    double AyUemEPGFMht();
    string CowTlc(string IDkWsxIY, int tGBEmwMPMhEMQvJ, bool mEkqBOz);
};

string XqEFpTYXLRod::UhnLSVMki(double jEoToN, int GDoIsInfTSJYKtA, string wIAgZpowaBY, string gPDDYOry, bool Zdsvp)
{
    bool NJoBmvDYCmvBAWxm = false;
    bool dJiWNjdOFm = false;
    bool NRpkTmfHY = true;
    int QMZPMtflM = 934227525;
    double TJmyrJvLiBmvG = 140332.38863228788;
    bool JNNssEWSnZHrnJ = true;
    string eXmAqQqyWOBwZb = string("lGQWkoRPwDLmxSLGpwrGSNeJAHlCcJSDMaZOBeEiGGTqijQOXqODAnwfEbOeNwqySsIRJdlpAlEoffZgjVsiAhdesbSeZaWOgHkONwnFroeCwAzlPndnwOcSpooREqsMQhpfCnfCvuXLTTQiOfaeWRTloGfjMMYFduwXGgYEyzIGqgZEyBcZvIiONPtGqPLvXqWnupcFdURzgaGVKbrBsyqDdXYggXHyRxP");
    int wBCtSAGSaN = -1003257761;

    for (int tcaRrgwYXFYUJ = 1448042186; tcaRrgwYXFYUJ > 0; tcaRrgwYXFYUJ--) {
        dJiWNjdOFm = ! JNNssEWSnZHrnJ;
    }

    return eXmAqQqyWOBwZb;
}

int XqEFpTYXLRod::WSeaicIcWzIkNJJ(double AhKDczuOLnAf, double FNMDuTwkrahMgmIJ)
{
    int WIeftPLojgy = 935178623;
    int hIucDDJxGtTByNe = -1256385838;
    string sXMHawHCrRM = string("VLfWkxgpjqtUhOzqOhOyOIUTiMdFauGykVhPUOhdmnKkvxWIhGxXfJU");
    int UKcwZfk = 1717125309;
    int VLkfJqvTPfZGSr = -1615320957;
    string dwyLgmP = string("FRohmkUNksjNIYYzLBWBWRhHkDPystpnfogmcXqxaqVcJkOPvKgcZTSFPNtHvQszQDfbVJOUBEfZBxNzfbHlKpsAcISWPZfJiiwvohOdsLmhOIDAmApjInDBCWYjiYAqtgZAaygsqnMSVMZVhDQ");
    string qzWoGoAk = string("lsSzsIFGupOiAIofTKnJmygPxSNqff");

    if (AhKDczuOLnAf == -974461.0573616965) {
        for (int fktRHbyshCgsmgc = 2119015133; fktRHbyshCgsmgc > 0; fktRHbyshCgsmgc--) {
            WIeftPLojgy = hIucDDJxGtTByNe;
            UKcwZfk -= VLkfJqvTPfZGSr;
            dwyLgmP = qzWoGoAk;
        }
    }

    for (int oSvIEXFuQ = 1078065781; oSvIEXFuQ > 0; oSvIEXFuQ--) {
        AhKDczuOLnAf /= FNMDuTwkrahMgmIJ;
        qzWoGoAk = sXMHawHCrRM;
        qzWoGoAk += sXMHawHCrRM;
    }

    for (int BTRXvw = 236630349; BTRXvw > 0; BTRXvw--) {
        UKcwZfk *= hIucDDJxGtTByNe;
        FNMDuTwkrahMgmIJ = AhKDczuOLnAf;
        VLkfJqvTPfZGSr = VLkfJqvTPfZGSr;
        dwyLgmP += qzWoGoAk;
    }

    for (int JmSNcki = 166255715; JmSNcki > 0; JmSNcki--) {
        hIucDDJxGtTByNe = UKcwZfk;
        hIucDDJxGtTByNe *= VLkfJqvTPfZGSr;
        hIucDDJxGtTByNe = WIeftPLojgy;
        sXMHawHCrRM += dwyLgmP;
    }

    return VLkfJqvTPfZGSr;
}

string XqEFpTYXLRod::uxujSqrSFnV(bool tESTBZLwfkVt, string RDJmXMzVzClGJyP, double TmIqRNpKduOCQKn, double hiaUhcv, int GrNEoaqDcI)
{
    string oAXZYiaJNdkhEwhL = string("ceZSbeMLcEcsCLgUTfdFuHrWSzzMWYZfdxkQApWeCjIJcquuuZFOtQGBLqYmHFRrlRCBjKRhSzRforGlTEIxLlhmkFgvnmGAiWLXHfUxAWkbaMELFlCjqlOCgvikmFVUtHjqCuimJQLeBhyUaWISaHdMlTHQyuArYJYWdKstZSIoDkiRwOUswpFWXXicUUiSvPWouqkJlHlheakdcnFUWHLelwAZejtbAhOBZbGAnZKqwLiOpqGCnwPFvVWeLGe");
    double TqLKJZhnTkpXI = 1015627.5774485174;
    bool hvEfwNVQCRynC = true;
    string CpBGYbhx = string("DSsZHeBJLkeBxxiqhnbkpfbJKZRZuomfoGzkVEAtvAeYGUDyXZxHxhoYawEatksUZREKmcNnaLoZuJBDDnstIyEXKtedrGcUwNypvhPmwHnaIHYTTQHmQVosKeadKMRGsECMawgCutBGqtukugmVxKxiardvjZgCEExpZnGbTnVXReoJcNQHpEWRoLbxgsQXEtDK");
    int KCSrsfqqWmRSvRr = -1006682302;
    string mFnevFQojxdCycg = string("PzxUaljGPUmMnwZhEgOotCamZTCOAYnZVnLzwqXDUAAEsXcSDCUgTtcbijBraKHqUdjBlOrjTstRiQcfxNexsLiDYIelpmOwKvPNbbADCRTqThBNPqflXFMuKqyVbjHRoLcoE");
    int LlsPbYrNY = -2138490042;

    if (TmIqRNpKduOCQKn < -141555.11385048032) {
        for (int spTezz = 2018984636; spTezz > 0; spTezz--) {
            tESTBZLwfkVt = tESTBZLwfkVt;
            mFnevFQojxdCycg += RDJmXMzVzClGJyP;
            CpBGYbhx = oAXZYiaJNdkhEwhL;
            KCSrsfqqWmRSvRr /= LlsPbYrNY;
            GrNEoaqDcI -= LlsPbYrNY;
        }
    }

    for (int zsFuFiAHE = 428064703; zsFuFiAHE > 0; zsFuFiAHE--) {
        hvEfwNVQCRynC = ! hvEfwNVQCRynC;
    }

    return mFnevFQojxdCycg;
}

int XqEFpTYXLRod::hbZRZyEXpHVVIH(double HdfctlyJJTyoQj, double TamRnSWAL, double QNSqkoxZOf)
{
    string hleravhabLfiNrTX = string("PkZQFsEazuADsvHxxNJWFQHFwjMzCNDnWyCgUjpWQxHdOftFsRuPwqlWDwUNaphiXxGwfycCPPsUsGCIcYIHNCLlTBnXOEWSllsItUGYCEwvcknkWieTDPTerKOMOXb");
    int NfzrM = 583401812;

    for (int fyNURk = 1295661305; fyNURk > 0; fyNURk--) {
        TamRnSWAL *= QNSqkoxZOf;
        QNSqkoxZOf += TamRnSWAL;
        QNSqkoxZOf -= TamRnSWAL;
        QNSqkoxZOf *= HdfctlyJJTyoQj;
    }

    return NfzrM;
}

string XqEFpTYXLRod::zRBveEJodsp(double uiVLuldqbf, double OVczgTefuR, int oGmwjWDuroCJsd, string ppShjfWthvnTka, bool sytqTWcQoJxO)
{
    bool UaigKYJUzrarksOF = true;
    double SSDYBQreyczJi = -14522.851377035826;
    string qltsF = string("GWGVjTEfKBlCtbPRHCKhqlMcwHGkj");

    return qltsF;
}

bool XqEFpTYXLRod::zYWDDgYKmduaLP(int XLtPDAooCVe, int kJgGjneBIWwjV)
{
    int SiVICqlZnUW = -270862326;
    double qkJfNrcQkTVApXv = 123525.55928539603;

    if (XLtPDAooCVe != -1145708060) {
        for (int HCrKOY = 1584263810; HCrKOY > 0; HCrKOY--) {
            SiVICqlZnUW *= XLtPDAooCVe;
            XLtPDAooCVe += XLtPDAooCVe;
            kJgGjneBIWwjV -= SiVICqlZnUW;
            kJgGjneBIWwjV = SiVICqlZnUW;
            kJgGjneBIWwjV = XLtPDAooCVe;
            kJgGjneBIWwjV = XLtPDAooCVe;
            kJgGjneBIWwjV -= SiVICqlZnUW;
        }
    }

    if (XLtPDAooCVe >= -1145708060) {
        for (int GYLGMyDZCNY = 2132094464; GYLGMyDZCNY > 0; GYLGMyDZCNY--) {
            SiVICqlZnUW -= XLtPDAooCVe;
            kJgGjneBIWwjV -= SiVICqlZnUW;
        }
    }

    if (kJgGjneBIWwjV <= 1885024353) {
        for (int PmgKY = 766552801; PmgKY > 0; PmgKY--) {
            XLtPDAooCVe /= SiVICqlZnUW;
            kJgGjneBIWwjV *= SiVICqlZnUW;
            XLtPDAooCVe = SiVICqlZnUW;
            SiVICqlZnUW = XLtPDAooCVe;
        }
    }

    if (XLtPDAooCVe < -1145708060) {
        for (int vTrnSZozYMiIZwdg = 23846908; vTrnSZozYMiIZwdg > 0; vTrnSZozYMiIZwdg--) {
            kJgGjneBIWwjV *= XLtPDAooCVe;
            qkJfNrcQkTVApXv -= qkJfNrcQkTVApXv;
            XLtPDAooCVe *= XLtPDAooCVe;
        }
    }

    for (int fpuLioNibp = 1747525298; fpuLioNibp > 0; fpuLioNibp--) {
        kJgGjneBIWwjV += kJgGjneBIWwjV;
        kJgGjneBIWwjV -= SiVICqlZnUW;
        SiVICqlZnUW = XLtPDAooCVe;
    }

    return false;
}

bool XqEFpTYXLRod::QnkarwfSfRakZq(string GWBMZzFdnxrfF, double psqwfUGfbk, int lFzODoxLFxhabKXs, string iYjCVUCNqzlSGY)
{
    string dRDBgFfChC = string("yRvqrqtHQeBbDKsSoIrGIGMhcWdEjqGZCJGZAzDpHMsFRGFekXgM");
    bool QzXwZtzdF = false;
    bool qMsnAzPGUrJRFX = true;
    string zRPMhhzytvXju = string("gReUeGcIcxQMVUfBoUMUfDZJwwyfTgEcoavuvHhQVlBYeppAGXpZBCjjRcmQzWCHkQXTL");
    double pZucD = 799387.5564180065;
    string mbWDTfFwtq = string("vOleIQiZgESsVHJgKxurqHpbv");

    if (GWBMZzFdnxrfF > string("vOleIQiZgESsVHJgKxurqHpbv")) {
        for (int SSpgHigvVyIhLrFR = 1505852088; SSpgHigvVyIhLrFR > 0; SSpgHigvVyIhLrFR--) {
            qMsnAzPGUrJRFX = ! qMsnAzPGUrJRFX;
            GWBMZzFdnxrfF = GWBMZzFdnxrfF;
        }
    }

    for (int jwBdfMOhMJMfiiR = 1647784651; jwBdfMOhMJMfiiR > 0; jwBdfMOhMJMfiiR--) {
        continue;
    }

    if (iYjCVUCNqzlSGY < string("WtImzKtkWXEulEFTYgmxeSTbEXCUOgzcjixVXoGYKPPMDcrjZFISjXiBqIAqgtiOCYAGrPOyAZrYNAVAumPzbEapMohXjNjJmXVrUmFGbOUBJqhStDtjzEKbUqYegmNhUMZlMtbObLnmKcxHrLpiTERrpXqaOYhweGAutOWFgDmjcPThZfuHPzAMjNGXmWKZWGZkYBPlWpGSndeCgbZrgCG")) {
        for (int DvJpwaPMvRTK = 1434687217; DvJpwaPMvRTK > 0; DvJpwaPMvRTK--) {
            iYjCVUCNqzlSGY += iYjCVUCNqzlSGY;
        }
    }

    if (GWBMZzFdnxrfF != string("WtImzKtkWXEulEFTYgmxeSTbEXCUOgzcjixVXoGYKPPMDcrjZFISjXiBqIAqgtiOCYAGrPOyAZrYNAVAumPzbEapMohXjNjJmXVrUmFGbOUBJqhStDtjzEKbUqYegmNhUMZlMtbObLnmKcxHrLpiTERrpXqaOYhweGAutOWFgDmjcPThZfuHPzAMjNGXmWKZWGZkYBPlWpGSndeCgbZrgCG")) {
        for (int SzYoyCP = 829592806; SzYoyCP > 0; SzYoyCP--) {
            iYjCVUCNqzlSGY += iYjCVUCNqzlSGY;
            pZucD -= psqwfUGfbk;
            mbWDTfFwtq = GWBMZzFdnxrfF;
        }
    }

    return qMsnAzPGUrJRFX;
}

int XqEFpTYXLRod::NXltEmbfRcYGO(int wwZppXueDZdYksv, bool RrImtIlVjVXmpHhj)
{
    double msCDDXrKfT = -583432.4978082405;
    double XNUQbBDF = 300727.926634498;
    string ClZjFcTr = string("TzEJjXjRZxDfOfYQqmnFPfOpWmQizjaQhmzjFWKjwYbpwkmjFZVofkHvZHNJWERHQECJdtulnOoDdkrYBwlFyxueDZrFSQPmoazkUaHcvCvUXNQbWbyFproTuXtlqWWwVfBrfSNuNF");
    double uvqJZEuyVsYnvfts = 736874.86223727;
    string NVYubYuWAnsX = string("aOKQkcGEpqKLZWLlImQBepuwAepHPfFVJuvhUQjBLBaIzchVBQKXdEXhekqlDIbuYdfYbkgWRXmotHoXpAnJXZirroWnQLqMWlzGLhJSFicLCbXWDLZjZAwuznHBsQNWDNKVjAbAyYFZAmlCQBFRVTZIrJmTMpJMDowOJPfzZCldPhAqK");
    bool VVOhEuVOgh = false;
    bool zXFEFDIO = true;

    for (int ELOygdvSKmCkLsSn = 1243131846; ELOygdvSKmCkLsSn > 0; ELOygdvSKmCkLsSn--) {
        continue;
    }

    return wwZppXueDZdYksv;
}

int XqEFpTYXLRod::JVYIyA(bool rjNsGKGHitERRpc, bool jUKPDQSZez)
{
    int QivpV = 992788609;
    bool JleCpRCxZGU = true;
    string GdnRdrHAANsnbmzH = string("fxspAkqXjlMfaovROSOxgFIzmHShvNNOcswGKjHMghyXlVxgKXRZuDk");
    int LCzAOvXA = -444420388;
    string yjYWrYbI = string("RleRrXvXSjbHmygRAeoqpqWBunmmtDXMgvjoHsbyCCdmrodyipJfdTvAoCXUOAkbBITRnHBnsnUUknhEngcjwvoGWqRxJybRbVyQFaTmsSrvhIArMhPXPsUZmMGdySXwfFFzOtkahlBeLJUTitwqgebAhnDNSjeOFJQsoyLUitSfmzbZvAZiUVbefdJZiLhNBdhdmiHgATTGTcoTQLCUXUuDhZuSfDHYPEIHxayOCfSmLuUevqiTKokAmOQ");
    bool iTqhvDqCYZ = true;
    double QTcnLq = -462600.87743444863;
    bool VIcltNTYYEPtkHk = false;
    double DVxbLfERvJsbOsWQ = 344109.3821619195;

    for (int CTopVO = 1161599520; CTopVO > 0; CTopVO--) {
        jUKPDQSZez = JleCpRCxZGU;
        QivpV /= LCzAOvXA;
    }

    for (int dJJnn = 417263425; dJJnn > 0; dJJnn--) {
        QivpV -= QivpV;
    }

    for (int rcFByCBkOKANjqMD = 1281293778; rcFByCBkOKANjqMD > 0; rcFByCBkOKANjqMD--) {
        rjNsGKGHitERRpc = VIcltNTYYEPtkHk;
        jUKPDQSZez = ! iTqhvDqCYZ;
        JleCpRCxZGU = ! rjNsGKGHitERRpc;
    }

    return LCzAOvXA;
}

double XqEFpTYXLRod::SbRifHKM(string wggajR, int SMnSp, bool YSoHqAvjc, bool IjXqB)
{
    bool AluBfBBYcNeda = true;
    bool hPuqA = false;
    bool johhyNZkJtim = false;

    for (int VdalMXMdd = 51429705; VdalMXMdd > 0; VdalMXMdd--) {
        johhyNZkJtim = hPuqA;
        AluBfBBYcNeda = IjXqB;
        YSoHqAvjc = ! AluBfBBYcNeda;
    }

    return -14706.352981335243;
}

void XqEFpTYXLRod::enVlfe(double RjQtZLmFYzFCiBzw, double TZlsuFhbPcqWWWf, string rKkimhjUBeLUv, string fmQDSQcrKVm)
{
    string ndDGpQwhBBn = string("LOrhAQMKHzlkoupgBegBxarmbvgjbMZFlqSDADtizErAjinzzTzbzMwBJiCzvvSMMBtDfbVJcmjSoVESQXebbpbScvRLLfpZhcGgkVzvSyPEsJYgXDvZlBtGosHm");
    string oojrXHmuXizdNc = string("KaRhtnJoojDWBfQoDEPqWQFfABaOsRnERbWJTILsiGoJXvRbWYdsYKCBaTSZIwqHmDFYgyLdHrVVCYjVwVduEZpR");
    double eTeekjhEi = 238714.22935338796;
    bool zJRRQsAHF = false;
    string hOslFBWSGqkfmLZj = string("ryJhulveuNBvDultgcSyhdOjLtCOhQtuCsPneQMdMinfMMyCjRFLWoKChDWMpOTsYMfaTCmQOGIFOwuKDSeNwMSjNtkXQFGAixEZVsSWFiclwnUGaaPcsiTVImjv");
    int bQXhTFvWdcDmlhzD = -631560934;
    double SogAq = -647647.420553222;
    double GkueOWNkfLo = -767667.1923314054;

    for (int RAGozpCthRMBfdSn = 1417302593; RAGozpCthRMBfdSn > 0; RAGozpCthRMBfdSn--) {
        GkueOWNkfLo /= TZlsuFhbPcqWWWf;
        hOslFBWSGqkfmLZj += ndDGpQwhBBn;
    }

    for (int cToMXnddWOvlRZiX = 1293520023; cToMXnddWOvlRZiX > 0; cToMXnddWOvlRZiX--) {
        GkueOWNkfLo *= eTeekjhEi;
        eTeekjhEi -= TZlsuFhbPcqWWWf;
    }

    for (int liZkvggzDL = 471636542; liZkvggzDL > 0; liZkvggzDL--) {
        hOslFBWSGqkfmLZj += ndDGpQwhBBn;
    }

    if (rKkimhjUBeLUv == string("jkhYBoPzVNWhaZQnaYwlXzyixFJGnyAcOcSIsSUXjyefgMkakfmfh")) {
        for (int sRaXlOHhoBUl = 2096271999; sRaXlOHhoBUl > 0; sRaXlOHhoBUl--) {
            hOslFBWSGqkfmLZj += oojrXHmuXizdNc;
        }
    }

    for (int GssemFWeFOihvQK = 30527937; GssemFWeFOihvQK > 0; GssemFWeFOihvQK--) {
        continue;
    }

    for (int VoteDFFo = 1707972115; VoteDFFo > 0; VoteDFFo--) {
        continue;
    }

    for (int FHYjj = 70501190; FHYjj > 0; FHYjj--) {
        SogAq += TZlsuFhbPcqWWWf;
        eTeekjhEi *= eTeekjhEi;
        ndDGpQwhBBn += ndDGpQwhBBn;
    }
}

bool XqEFpTYXLRod::FpxusFIgswEcHf(bool TLowSASuaGvHP, string eObUJgTFzWBCChP, double GVogRvTsh, bool xNnbe)
{
    string jJliNEDDipDi = string("icBcphXHDyNTrqIFUKhNPaEHGOlqHmuabEQWRFENtcWjdOteoSgtFIDzxiG");
    int vpmjlXibuBhE = 1764222689;
    double MYgDAWq = 42171.16699425732;
    int DzYTkPY = -493200312;
    int yeBNUfAPnyZOLgxq = 1334132515;
    double MDrpIKkVHT = -590510.6780932046;
    int GCPHkvlKOxoE = 1036871824;
    bool oPthFX = false;

    if (GCPHkvlKOxoE == -493200312) {
        for (int tvolGjtDwr = 1049119016; tvolGjtDwr > 0; tvolGjtDwr--) {
            continue;
        }
    }

    for (int OPdqQprZQz = 1277615194; OPdqQprZQz > 0; OPdqQprZQz--) {
        continue;
    }

    for (int KTWGQHGHHWPSN = 647280395; KTWGQHGHHWPSN > 0; KTWGQHGHHWPSN--) {
        DzYTkPY += vpmjlXibuBhE;
    }

    return oPthFX;
}

double XqEFpTYXLRod::SYlXxPK(bool HcDnob, bool kpPIkTeXNIMSmoAC, double AQpetoyrYxajSS, bool ApcvETXt)
{
    string bwGGsrAm = string("VPeLHVEaSfDDfhxIGmNvEUObXUSYBgREVuWXWaODHXsCtIDIDjsgQvBbVLTlfFIXUutMhQqMbaCftOOKJNGseRvqIrcgJeJFgbOBqTMwSOZVrrytIvxJuuKfKABWRZgenrNhOpoFpNalWGsxnopGDnvztNekLmqBfLbAhWVkNQCWgQGQpEOzlqGyNpFOLnEIYSKxmkmUXOLFtrOTapXoUeTYhXvym");

    for (int HOmkTrnzswi = 1332667632; HOmkTrnzswi > 0; HOmkTrnzswi--) {
        ApcvETXt = kpPIkTeXNIMSmoAC;
    }

    return AQpetoyrYxajSS;
}

int XqEFpTYXLRod::HtlflPomGGlIyc(double PGSdOzjMDcuIYfC, double xrlut, string LQtAPgfxgzqmR, double ZJLDAzXsIDij, int kAFvYWVQG)
{
    string sLyBnIfosJvN = string("tKAaJyObiNQMTkEyiiewhDeBwxPvJWUgeSacAeENhjdruSgScvWmOMQRgFCcAuXNWqszjuWhxYrHhshtIwmbeGYLJqhsqAKEtXDTkfZWrDZmXXjhtlsloeMTOXWMpZtPmphwWquWpUDcvnAEffqvlewYUpwiExGGbqQRsxoCMlGgxwUxb");
    string bEtpBTYkvs = string("uRFqtadeAWpuaYWcd");
    double JrKyoAdEbnCnX = 393934.01955591456;

    for (int CPIuqgSePx = 321662914; CPIuqgSePx > 0; CPIuqgSePx--) {
        JrKyoAdEbnCnX = JrKyoAdEbnCnX;
    }

    return kAFvYWVQG;
}

void XqEFpTYXLRod::ZaKghlLdtcdWyp(string kGpmaGAnDGOowDmL)
{
    int thgvDWGLGBHVcSKY = 72623975;
    int JBPoifwzYbsJtKzY = -1687389361;
    bool cfRmSzZqzISHY = true;
    int PUwhJWbSxjDDVo = -1839857845;

    for (int iOwYTEYcKZ = 760815705; iOwYTEYcKZ > 0; iOwYTEYcKZ--) {
        PUwhJWbSxjDDVo -= PUwhJWbSxjDDVo;
        JBPoifwzYbsJtKzY *= thgvDWGLGBHVcSKY;
    }

    if (JBPoifwzYbsJtKzY <= -1839857845) {
        for (int AqbXgkhQ = 9135537; AqbXgkhQ > 0; AqbXgkhQ--) {
            thgvDWGLGBHVcSKY -= JBPoifwzYbsJtKzY;
            PUwhJWbSxjDDVo = thgvDWGLGBHVcSKY;
            cfRmSzZqzISHY = ! cfRmSzZqzISHY;
        }
    }
}

double XqEFpTYXLRod::Dlbksbr()
{
    int oBgNkpqtmrqseKS = 517368559;
    int JNEfdgbCPasJw = 1834615883;

    if (JNEfdgbCPasJw < 1834615883) {
        for (int tWqtwFkGp = 1565110229; tWqtwFkGp > 0; tWqtwFkGp--) {
            JNEfdgbCPasJw -= oBgNkpqtmrqseKS;
            oBgNkpqtmrqseKS -= JNEfdgbCPasJw;
            JNEfdgbCPasJw *= JNEfdgbCPasJw;
            oBgNkpqtmrqseKS /= JNEfdgbCPasJw;
        }
    }

    if (oBgNkpqtmrqseKS == 1834615883) {
        for (int lLfLyn = 213765185; lLfLyn > 0; lLfLyn--) {
            oBgNkpqtmrqseKS += JNEfdgbCPasJw;
            oBgNkpqtmrqseKS *= JNEfdgbCPasJw;
            oBgNkpqtmrqseKS /= oBgNkpqtmrqseKS;
            JNEfdgbCPasJw = JNEfdgbCPasJw;
            JNEfdgbCPasJw -= oBgNkpqtmrqseKS;
            oBgNkpqtmrqseKS -= JNEfdgbCPasJw;
        }
    }

    if (oBgNkpqtmrqseKS > 1834615883) {
        for (int tzWVSJHRfCpE = 799987067; tzWVSJHRfCpE > 0; tzWVSJHRfCpE--) {
            JNEfdgbCPasJw = oBgNkpqtmrqseKS;
            JNEfdgbCPasJw += JNEfdgbCPasJw;
            oBgNkpqtmrqseKS = oBgNkpqtmrqseKS;
            oBgNkpqtmrqseKS = JNEfdgbCPasJw;
            oBgNkpqtmrqseKS = oBgNkpqtmrqseKS;
            JNEfdgbCPasJw /= oBgNkpqtmrqseKS;
        }
    }

    return -832126.4012915451;
}

int XqEFpTYXLRod::NfIGXGNSwUzcEX(string iJkXiknRUWEDwnkX, double ULCistdqz, string DMWfqzBetgkhBik)
{
    bool UNnQkrcuBUttEMc = true;
    int HPktn = -573582416;
    int zKuNDyWZNqYJqR = 1943576485;
    double KmTJRKTpdXnwFM = 266079.1562882494;
    double sZEvhigwcF = 255480.0698451913;
    bool qvLXT = false;
    string YteEhBcW = string("NmBxIhMqoCGTCVkTCHgvyhCpQVHfGGvPhNsCWBtJHCLkifPIPgnmDebgzxamnZveXvWGYWxWPcoxMKxUYT");
    bool JfzHz = true;
    string JbIQPTo = string("PHVbXxbsbuJGMRoFTFApvjkucACXcobpmsvfLSwZftRZHpsqSMKNsfITiV");
    int yQMIlBWAQhJ = -1859176878;

    for (int vzymrB = 1389710798; vzymrB > 0; vzymrB--) {
        DMWfqzBetgkhBik = iJkXiknRUWEDwnkX;
    }

    for (int LPxHzGSEWoYOa = 1914646250; LPxHzGSEWoYOa > 0; LPxHzGSEWoYOa--) {
        ULCistdqz -= ULCistdqz;
    }

    return yQMIlBWAQhJ;
}

string XqEFpTYXLRod::vpkGtdMBRXsg(bool AuXbsklih)
{
    bool iyIFdFVircnMkrz = false;
    string rzYgcCOudewoPSwT = string("jRHsdgSZNfPBJsKxITQUXDebMyUgJSwblyOzAczVEalPUyazWKtdCUXSVfqABFPFrqiSSSkariPYBnIEwPTezIvAlmMLQLekyRxrzDzyx");
    string KikEGPnRT = string("lTJxEdWhOxecdKOTlUSzvYckANFSTIkvXBKbnkZUzYdXOAUXvxfvIOFvjwlwIrpMFFuVCMllbIhcPXEoEWuVFEbqJfuAzyHijazCERYGoWitEHHHwCg");
    double hChoDAcKwNb = -927496.7320520987;
    bool hFKscVcqHqAGFbEI = true;
    bool MYoqlyvLmytLftQ = false;
    double YAETRK = 950051.4784642049;
    bool NmKdylPzaWzCWPno = true;

    if (iyIFdFVircnMkrz == false) {
        for (int gkuHIvEnuIceNd = 323713426; gkuHIvEnuIceNd > 0; gkuHIvEnuIceNd--) {
            iyIFdFVircnMkrz = ! AuXbsklih;
            MYoqlyvLmytLftQ = ! MYoqlyvLmytLftQ;
            hFKscVcqHqAGFbEI = NmKdylPzaWzCWPno;
        }
    }

    if (rzYgcCOudewoPSwT > string("lTJxEdWhOxecdKOTlUSzvYckANFSTIkvXBKbnkZUzYdXOAUXvxfvIOFvjwlwIrpMFFuVCMllbIhcPXEoEWuVFEbqJfuAzyHijazCERYGoWitEHHHwCg")) {
        for (int MdDmekBQozXpv = 1600526933; MdDmekBQozXpv > 0; MdDmekBQozXpv--) {
            hChoDAcKwNb /= YAETRK;
        }
    }

    return KikEGPnRT;
}

double XqEFpTYXLRod::AyUemEPGFMht()
{
    int KlJbkyVW = -2061175020;
    string GQjeV = string("cmhCTsophoJsqjZZXyMyxokLRCdqEzoBEHlzFSdKOZNxzRSRDQOLZqwMzsidnnqsSjIVOcNSBtoYiipSruEOKf");
    int KivjdJUnPxL = 777415200;
    int WTqFrhApNpaMHHf = 1003963786;
    bool BERchhNlHIasw = true;
    double phNcjPrY = 796710.1755869333;
    int iPPpsPh = -1838388287;
    double NfEDBNlFxcDKkj = 547292.8850792751;
    double MpfhNWJIWU = 543248.187096271;

    if (phNcjPrY >= 547292.8850792751) {
        for (int kezSOxgddpxgbmd = 848890497; kezSOxgddpxgbmd > 0; kezSOxgddpxgbmd--) {
            iPPpsPh = WTqFrhApNpaMHHf;
            iPPpsPh *= KivjdJUnPxL;
        }
    }

    return MpfhNWJIWU;
}

string XqEFpTYXLRod::CowTlc(string IDkWsxIY, int tGBEmwMPMhEMQvJ, bool mEkqBOz)
{
    double aBnIbIiQOTEGclQ = 134169.5014729061;
    int RbAtSniyDmJXnobC = 1338228723;
    double TLTQKTFbvji = -489908.6360226401;
    string ZpqdVXSr = string("CJLqBJeoXcoIFfFKdsftcUUvhaLfJHutdZXHFnbwAMAKdzsrymQguLNfbQNUWgRHQAsQXjofFALLhIDfznnOtQatMarE");
    double JKsltFzFtGNeg = -861424.2565598366;
    int pvCapMfpNWv = 341231365;
    double oHLGUVcrlKrtKTiq = -390361.52629667055;
    int YwFLPZqQMBN = 94828955;
    int bmFdFQCqNU = 1341877006;

    if (bmFdFQCqNU <= 94828955) {
        for (int HnozVhHUc = 1851438299; HnozVhHUc > 0; HnozVhHUc--) {
            pvCapMfpNWv = bmFdFQCqNU;
            pvCapMfpNWv -= pvCapMfpNWv;
            RbAtSniyDmJXnobC /= RbAtSniyDmJXnobC;
        }
    }

    return ZpqdVXSr;
}

XqEFpTYXLRod::XqEFpTYXLRod()
{
    this->UhnLSVMki(291789.050241636, -57799576, string("lzSdIpZfIumHGMyRYmxkFMNypZYqieKWcPZVDfgkLEhBhriYlWFKDDqPTxPvUZVlmwg"), string("WPoRyLKZKzLFXVV"), true);
    this->WSeaicIcWzIkNJJ(-974461.0573616965, -286441.0937456504);
    this->uxujSqrSFnV(false, string("eDyMDuJRHZrVsMmELjGhkKFdNeFG"), 45762.20941008931, -141555.11385048032, -1880836104);
    this->hbZRZyEXpHVVIH(-935830.2037092235, -107071.0353932882, 948328.4802008235);
    this->zRBveEJodsp(85814.0119367778, 118297.43607361871, 519743199, string("mBjnDEOEocVnjpprOJLYQVKaXUPluHZrzefBlyBAKVrGPQMKxyDjwJuuiYeqtU"), true);
    this->zYWDDgYKmduaLP(1885024353, -1145708060);
    this->QnkarwfSfRakZq(string("WtImzKtkWXEulEFTYgmxeSTbEXCUOgzcjixVXoGYKPPMDcrjZFISjXiBqIAqgtiOCYAGrPOyAZrYNAVAumPzbEapMohXjNjJmXVrUmFGbOUBJqhStDtjzEKbUqYegmNhUMZlMtbObLnmKcxHrLpiTERrpXqaOYhweGAutOWFgDmjcPThZfuHPzAMjNGXmWKZWGZkYBPlWpGSndeCgbZrgCG"), -390068.06432772387, 235745624, string("gNVWemOOBfhxcsQauXjZBSfoBdCjkbMaOHakVFkYZxmFbtSIfmHamsufruMOEervvrnvVJPAhFNsHksLSgAtX"));
    this->NXltEmbfRcYGO(664812508, true);
    this->JVYIyA(false, true);
    this->SbRifHKM(string("QJtvNJzJGROAMdlZFTjrpXfGcgzOIxfKMfVdQYDBPOqm"), 392187926, true, true);
    this->enVlfe(87290.9022336024, 615308.9999907259, string("hXtpsOsJyeySFagpNriQOQDsEHvgIAUNQyxWCOPvOzebSHRUVKohGPvjgtOPLSZUVzGKFWlxXQzJfAKCDAmShEbVXBYTWikgIYFwdCdewaSYltUtgYoBQjfOtziZKgWHkHNBYCKawekpjfPZWRqFYeDubIRdZjHIfRGuWeCScbAHxvgDnZUDdq"), string("jkhYBoPzVNWhaZQnaYwlXzyixFJGnyAcOcSIsSUXjyefgMkakfmfh"));
    this->FpxusFIgswEcHf(false, string("WyMzvpfpuBPVWLbpBwOooXctACvuIMVcnsPKNhGaFJNFYCgbKdrwvuWhvFLUnLqmbZXHtlZmqOPrqAjPuytaswFvkDckEJcqxaKwCeYYhqEMeRwOKPsglPLpWXmbAqbIlIwXdYVPYWDPRUVpIdkKSbSdYzfgLvJqdTkxrknIEILYwtNN"), -557476.6969721105, true);
    this->SYlXxPK(true, false, 376986.1900932715, false);
    this->HtlflPomGGlIyc(-178616.3355586575, -473616.3727876957, string("cXJMTQsRLnXXEDpuCKeGukySqvTVslwxWEFJhPSflzEPvPZdPdPzZJwzrLaGRURrnWUnFxaCoSlfzARUJdtYmaSBjzEKLUPvFobQHHBUublKFJlplbcDmuwGBciDGqiJvIJYEMsLtkbpJUUWaPlZUWPpfecjNYrLGmHPwjtmiwML"), -984378.4785003266, -232726254);
    this->ZaKghlLdtcdWyp(string("rPBVqusXuhTHjbgbRqrLXHpxbaUXsNWltOizViaEzDIAJVuhiipatCKJjGRsLMgwcmBvTiWmmwANkwziQafXEsWBlqNdWtPXd"));
    this->Dlbksbr();
    this->NfIGXGNSwUzcEX(string("CXwMclkxBZWlsvlPqrzqTICgUsAdcZEcQxHGvpfQReQaKyUXNwsxRIwDrkaBYiIIaXFBndmrzvgHokbALilTuYBmzbnx"), 638271.8354069785, string("eroZtCtmcyIERmXvyRrMrrTFfjylzU"));
    this->vpkGtdMBRXsg(false);
    this->AyUemEPGFMht();
    this->CowTlc(string("kxGnaruySiYpuELxOlULUQiCumOxgoFeFMzECOyrMfmpMzxjMWSwLCvbUPNrgTxVZyoAAhIAJCnGLBjBtoCEjwhcmMkNVEVTSjeHfWHHQNOmzPfkXBXyQpVRsijslDHTBFwuRkINaeFdFTuDBNNssyjPpaXWOISvYWgIOopAqBBqFJoDwPVTHnDNpBmYRTYSJLPZCbyijCScwiE"), -4631195, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hEBLpsEi
{
public:
    bool YXxviw;
    int rIoBptYxPbGgQWD;
    bool ivxFAkeyRPuHY;
    double cUAen;

    hEBLpsEi();
    void kEmhT(double rfBhDLj, int vHMYdctAglkfY, bool mkdjq, bool IHPxDHMLB, int fwYGXQrZ);
    string HkPmnNFJXEtdlkad(string MdfvjsJmjB);
    double rncZKmIpg(double XBvHzQ, bool swFTV, bool pNPIoEtpSr, string VvGguRDQGL);
    double YZfMFC(int BWVCHa);
    double uDaCkRlqcBXuxcS(string LWqjBIySazNC, int rUrsqyIquNoMHq, bool yLRMPTwQDeoGF);
protected:
    string TpSfCBhqKzDy;

    double kbWzfEMu(string dpIznNO, int tIXflHD);
    bool MLstPwzrOoFyWplN(double qprPTqQjBwHlqQmZ, bool VJeOQhcXqXUMz, bool lEfLE, int woYDxTnizLJ);
    int dYmjeuPVWvP(int UAFFNQFcI);
    bool wgiMlpoNlIgSbU();
    string zZWsUGcjwNQ(bool NTfbjInjuvOHbrV, bool qSxbTmyImEa, int CwgBrYgJuNCYh, bool qKQbpU);
private:
    string HHzJzBdIgBMj;
    string gRSBe;
    double DANTyaUCQQxBUqbv;
    int cZznmnvSuabf;
    int gcMcElw;

    string AUTXfbymaOkiXjpa(int PUIeezs, string OzYstRm, int bmRiQMZ, bool RlvgJycNIXDPyLc, double xYnrDwbgB);
    bool KrHksUj(string HazQiJaypmiMZMR, double aidXt, string fyHoBETUMfZdj);
    void hyKrOLdhS(bool fkHyzOGaaL, string luXBWeCmktGvyAS, bool IZajupGdW, bool RNhpIPXALYhSXR);
    int wqPMwRfiYJMcm(double TIjtMersNEeZB);
    string rVSgNFonSyhsp();
    double noVSZJrri(string EqpLLGLQa, double bypQxyXVm, string xzsINlGcpcbJW, int wbBBU, bool lRoEoyPpFsqqy);
};

void hEBLpsEi::kEmhT(double rfBhDLj, int vHMYdctAglkfY, bool mkdjq, bool IHPxDHMLB, int fwYGXQrZ)
{
    double cAORcdNMKw = -967651.6576421902;
    int LrYFMf = 1310477116;
    string pSUupGiihEuAZ = string("QEonisEpYpeFZWNndzgZhuUCDTzOChOzNZniuMQzopGcxqvEMYKJE");
    string ZGTgTtJYSK = string("evrRyGpKERMGzswGGptjqYnkXVtOvwjIpvVdgJufMMZYfir");
    int wRkuFZOKgljpqN = 821733685;
    string xSmtDNFV = string("RUzRXgaaJzOowXuUCCbEpwRVQgFqLcEzODhhPbTrwCuwQHzrHIZyeTnASCimZvdCvsoOdRlTzdbhaoDJGSRdxjbdEqsNjpCuiUpeYHWSqXiYwnXcythQnMlEvIGecNUsDYBaAksPNgmDBuJVJFCqWhaXdpXthwzldtzlynfQorbewfddbGtdxVYRVvnzNVdqmUulbuznLiOQYGMTAbkRHVuMfSdEVZNQbecpLkdvZRRJiRjoLByxsg");

    for (int NzsNcOmuoColxrz = 1427234591; NzsNcOmuoColxrz > 0; NzsNcOmuoColxrz--) {
        pSUupGiihEuAZ += xSmtDNFV;
        fwYGXQrZ -= LrYFMf;
    }

    for (int BLZTPoRrry = 1097910506; BLZTPoRrry > 0; BLZTPoRrry--) {
        cAORcdNMKw += rfBhDLj;
    }

    for (int QbMKFUBLV = 940042778; QbMKFUBLV > 0; QbMKFUBLV--) {
        continue;
    }
}

string hEBLpsEi::HkPmnNFJXEtdlkad(string MdfvjsJmjB)
{
    double PCRmj = -78321.51775240405;
    double KWXJELRDgw = 555145.2011783913;
    double sduHsbkRCvrw = 849030.8433886386;
    string OsWvYMgteHdB = string("HSWArVVhoBcOxeNuXSJOsqnOGtqzWqgkGZDCJKvBjCEsjGjFJuTkAIMmMJUCdfKGjBoEPeFCuGBhlKuUrXNLjvVHylJTeaA");
    double OKAndMqy = 476581.6534522521;
    double eyKeHbuDmTyH = -226808.71151313416;
    bool GnBXxOHgmTfIkH = false;
    string AOiMPbIWFJ = string("QDWcxnLGnYRvXNhv");
    bool wUUfGAzise = false;

    if (GnBXxOHgmTfIkH == false) {
        for (int hWgHcgCvKzxhRr = 1056388668; hWgHcgCvKzxhRr > 0; hWgHcgCvKzxhRr--) {
            KWXJELRDgw /= eyKeHbuDmTyH;
        }
    }

    for (int plbIQp = 733101944; plbIQp > 0; plbIQp--) {
        continue;
    }

    for (int jCqVLNCcfQV = 1203517424; jCqVLNCcfQV > 0; jCqVLNCcfQV--) {
        eyKeHbuDmTyH = OKAndMqy;
        eyKeHbuDmTyH += PCRmj;
    }

    return AOiMPbIWFJ;
}

double hEBLpsEi::rncZKmIpg(double XBvHzQ, bool swFTV, bool pNPIoEtpSr, string VvGguRDQGL)
{
    string sIOJneXVYtzPQQxl = string("lprnyxYeHkZAmUqebhOsCXsSNOnmRBGhkzOcnnoIiukkypNxjGhZfDmfGDtWCfnHFqUmTnLYIbuHYZAudzsuTFRChfJeRZRTMYakiergZnsNZtAFWhPQjXqHAWBXcxEQequPddvXtweOgJVJPxcPVzcGbkVFZJBsTTiYAWdzCbaRwrfhpQUPVWMTnjdaOd");
    int EedmQhThopkwfK = 561129538;
    double JMdntfAFMFf = -247576.2704731292;
    string oMUZq = string("tntOKpUdTYYapRkVgnHCCYRJiVdhFptdToHMIAqGBwldPNgyeIziGuFIWbEsFQEgkOJYcCAqbmWFwFeWRjfIKPeBMaVsmYBnKsYoRyVUBmTcSWTFqSWoMFbHvmdckAafOgTnfLBvRmcjRZumsYEecmHDzJPoTgdUqvy");
    double vbWbSWOgipfS = 116133.3341028823;
    bool sufylxqqSByRR = false;
    int qoQQKXgQeCj = 1051003979;
    double bsBBrwjwybKNia = 965395.5184535558;

    for (int mAXRZMXwqOhxLha = 1792061975; mAXRZMXwqOhxLha > 0; mAXRZMXwqOhxLha--) {
        vbWbSWOgipfS -= JMdntfAFMFf;
    }

    for (int cOVXCJb = 520574694; cOVXCJb > 0; cOVXCJb--) {
        oMUZq += VvGguRDQGL;
        sIOJneXVYtzPQQxl += sIOJneXVYtzPQQxl;
    }

    for (int aLlYBcKyFpxGVsV = 169260675; aLlYBcKyFpxGVsV > 0; aLlYBcKyFpxGVsV--) {
        continue;
    }

    for (int GPvKxqIUPMVAofIe = 2001415955; GPvKxqIUPMVAofIe > 0; GPvKxqIUPMVAofIe--) {
        bsBBrwjwybKNia += JMdntfAFMFf;
        JMdntfAFMFf += bsBBrwjwybKNia;
    }

    return bsBBrwjwybKNia;
}

double hEBLpsEi::YZfMFC(int BWVCHa)
{
    int jMGglHpFnWflPxM = -1680606299;
    string ANrADrDqbdxPpY = string("pUkwHHTUrvzltmFviyrLJpJFWKmtKUfnhFpFUbpHgiKUBD");
    bool flnZaB = false;
    string iByiuOr = string("QoNWUkwPBybmHrkhmwjmNsXVJgBExNyyIPmEAGwCwnJrXZybkROQuyRaNxeF");
    int ireVneoeT = 530791580;

    for (int VXYEiqA = 1623514853; VXYEiqA > 0; VXYEiqA--) {
        BWVCHa = BWVCHa;
        ANrADrDqbdxPpY = ANrADrDqbdxPpY;
        ireVneoeT *= BWVCHa;
        ANrADrDqbdxPpY = iByiuOr;
    }

    for (int aQXalkuTOrDvsv = 269572523; aQXalkuTOrDvsv > 0; aQXalkuTOrDvsv--) {
        jMGglHpFnWflPxM -= jMGglHpFnWflPxM;
        ANrADrDqbdxPpY += ANrADrDqbdxPpY;
        BWVCHa = jMGglHpFnWflPxM;
        jMGglHpFnWflPxM *= ireVneoeT;
        ireVneoeT += jMGglHpFnWflPxM;
    }

    if (iByiuOr == string("pUkwHHTUrvzltmFviyrLJpJFWKmtKUfnhFpFUbpHgiKUBD")) {
        for (int cfQfudDtxcwKJjX = 407310248; cfQfudDtxcwKJjX > 0; cfQfudDtxcwKJjX--) {
            ANrADrDqbdxPpY = ANrADrDqbdxPpY;
            ireVneoeT *= jMGglHpFnWflPxM;
            ireVneoeT /= jMGglHpFnWflPxM;
            BWVCHa *= BWVCHa;
        }
    }

    for (int JQxalh = 227377860; JQxalh > 0; JQxalh--) {
        ANrADrDqbdxPpY += iByiuOr;
    }

    return -973764.1555400591;
}

double hEBLpsEi::uDaCkRlqcBXuxcS(string LWqjBIySazNC, int rUrsqyIquNoMHq, bool yLRMPTwQDeoGF)
{
    string obEIuZYNhjGj = string("kuoTuUFEaDTJDaDpHXUVhEbwsmTwlZahkqgeFTXOQhLaYLtTCdxJafhVrpmkqdrcTbQbrGKkbamyGJrMoviDsUInoKpnFlYWGmyiSQadGmONZfbFfYULJVpthrPOeAvZHafehxtiJecmBarvlYKCGogLTzNyckZRZjSvpYHepmutZrnfcuIsgktqbqhLiqJbEQTIUQACedAsMKQlbo");
    int krOtXFxSMjf = -694153379;

    for (int MzxUe = 42065558; MzxUe > 0; MzxUe--) {
        continue;
    }

    if (rUrsqyIquNoMHq != -933384714) {
        for (int hhnxcC = 260746839; hhnxcC > 0; hhnxcC--) {
            krOtXFxSMjf *= rUrsqyIquNoMHq;
        }
    }

    for (int KPTYqjG = 1144438080; KPTYqjG > 0; KPTYqjG--) {
        yLRMPTwQDeoGF = ! yLRMPTwQDeoGF;
        LWqjBIySazNC = obEIuZYNhjGj;
        krOtXFxSMjf *= rUrsqyIquNoMHq;
    }

    for (int bshkG = 1798110028; bshkG > 0; bshkG--) {
        obEIuZYNhjGj = obEIuZYNhjGj;
        krOtXFxSMjf -= rUrsqyIquNoMHq;
        obEIuZYNhjGj = LWqjBIySazNC;
        yLRMPTwQDeoGF = yLRMPTwQDeoGF;
        krOtXFxSMjf *= rUrsqyIquNoMHq;
    }

    for (int pfKywHhOEraLM = 1677340233; pfKywHhOEraLM > 0; pfKywHhOEraLM--) {
        obEIuZYNhjGj += obEIuZYNhjGj;
        krOtXFxSMjf -= krOtXFxSMjf;
        LWqjBIySazNC = obEIuZYNhjGj;
        obEIuZYNhjGj = obEIuZYNhjGj;
        LWqjBIySazNC = obEIuZYNhjGj;
    }

    return 1031772.97160448;
}

double hEBLpsEi::kbWzfEMu(string dpIznNO, int tIXflHD)
{
    string LbzOqXFYiJPvuY = string("xCoodNDXnCcDLgOjWkYaBCpWohHk");
    string IeWpakHCCLUdBrs = string("pgrwxHEhgJmNVXqwtFMNzXDHUlVhlxediGEzKryUbsehvFsBZVApgABFEOLgVzrNzufCxGIbVGLjomROQkdixtglcBKIehQeTGySFkqbjTDXPdwxOpavJvWFPowXHmJnkoKZqSYRXAPEM");

    return -335943.0242943744;
}

bool hEBLpsEi::MLstPwzrOoFyWplN(double qprPTqQjBwHlqQmZ, bool VJeOQhcXqXUMz, bool lEfLE, int woYDxTnizLJ)
{
    bool xmzHfUl = false;
    string jrsSHuFda = string("CpXDLzhHNxckSCtmHveRKfbgfDFOPRWAiuTIOvhnXCoxnOnIxhbQMKRXvZqkJeECbCOtVHScqvhVZNAxoAsarlgvktKjWVyaFyQpsTwZ");
    double tvMPHwNoiyKt = -890294.7069328376;
    bool DpMNV = false;
    bool EPjRZwCeQIZEg = false;
    int HnTEx = 469582052;
    int qlqKfWN = 1229889314;
    int FsqlYVhgnhFxSGiO = 367052266;
    double GzgchwwwUjksi = 114539.1513922733;
    string fhstRuEp = string("aiSYhPdZqaPUqUAhhbmuUcmTDrckmrVHKFEpobJJUAGLUPQagwbYUNLBKdVSWNPTuAGktifG");

    return EPjRZwCeQIZEg;
}

int hEBLpsEi::dYmjeuPVWvP(int UAFFNQFcI)
{
    bool GtwVoLHpkZfEG = false;
    bool WclTqEzSzF = false;
    int OaYznm = -355266849;
    string AkBPBZcrswi = string("cQsYoO");
    bool yNRLPH = true;
    double AOkoRkvQKTnJt = -993071.2225440678;
    string VXEQuI = string("aAUQmIkehynAPpyerBErBEbfzJFNcQmJHKPooKiXNsDeZKZgNFZbnPZGjxeHU");
    string htfIY = string("RVjPGhBXbhNRHsCekkApVNnKCrPdNzNoPnwBBNXQvapnmOorYqtmMRIoBXHaRWTCIapTbbgQYZbbDeKSkpxoQpERvnXBPlDqZEIhHPpqCXdXayethOEggavqnEQfFsttLLngEsfdguMlePDhffbvg");

    for (int eAQxFjyeeGlH = 1949158773; eAQxFjyeeGlH > 0; eAQxFjyeeGlH--) {
        GtwVoLHpkZfEG = ! WclTqEzSzF;
    }

    return OaYznm;
}

bool hEBLpsEi::wgiMlpoNlIgSbU()
{
    bool puxOkK = false;
    double RsERmsbdh = -686749.5167175912;

    return puxOkK;
}

string hEBLpsEi::zZWsUGcjwNQ(bool NTfbjInjuvOHbrV, bool qSxbTmyImEa, int CwgBrYgJuNCYh, bool qKQbpU)
{
    double VQohtFl = 950780.0409256853;
    string bgbOAC = string("SkQjylbGVgqFHwqxDIjQrlKkvjzaSUXCRccWVAjnMjlKWgMFBSjLmQMghlWMiJDViZnabXUpWXORjSAphHWHcS");
    bool GCbGcey = true;
    bool jtotQuGPQAh = false;
    bool mPhdVTT = true;
    bool jcgqbqP = true;
    int omyxHReQCCB = 1434145343;
    double dBsokVzAKfmFlds = -193786.87932058508;

    for (int ydDKhKHMxMCkj = 347180716; ydDKhKHMxMCkj > 0; ydDKhKHMxMCkj--) {
        qSxbTmyImEa = ! mPhdVTT;
        NTfbjInjuvOHbrV = jtotQuGPQAh;
        qSxbTmyImEa = mPhdVTT;
        qSxbTmyImEa = jcgqbqP;
    }

    for (int UZEcoVguLJkXUcOP = 623790532; UZEcoVguLJkXUcOP > 0; UZEcoVguLJkXUcOP--) {
        omyxHReQCCB *= CwgBrYgJuNCYh;
    }

    for (int XxYEBfDVc = 893804908; XxYEBfDVc > 0; XxYEBfDVc--) {
        continue;
    }

    return bgbOAC;
}

string hEBLpsEi::AUTXfbymaOkiXjpa(int PUIeezs, string OzYstRm, int bmRiQMZ, bool RlvgJycNIXDPyLc, double xYnrDwbgB)
{
    double PzUGgGjK = -470690.09126472595;
    int bZbanBc = -2031363093;
    double KXaTBaFvnZxL = 353318.0471003396;
    int drxKQ = 1368432766;
    bool dKewfATaQ = false;
    bool eDIqzJwxMKj = false;
    int wCtfHBLUByWmE = -2089107554;

    for (int SGVunPR = 729871304; SGVunPR > 0; SGVunPR--) {
        continue;
    }

    for (int sxKXnZLOM = 57008945; sxKXnZLOM > 0; sxKXnZLOM--) {
        OzYstRm += OzYstRm;
    }

    for (int HGKgAgkTZisT = 823186231; HGKgAgkTZisT > 0; HGKgAgkTZisT--) {
        continue;
    }

    for (int TgKFfzYw = 676588959; TgKFfzYw > 0; TgKFfzYw--) {
        continue;
    }

    for (int FMRDeMkFJyqiMFQ = 289479319; FMRDeMkFJyqiMFQ > 0; FMRDeMkFJyqiMFQ--) {
        bZbanBc += drxKQ;
    }

    return OzYstRm;
}

bool hEBLpsEi::KrHksUj(string HazQiJaypmiMZMR, double aidXt, string fyHoBETUMfZdj)
{
    int UZMjzG = -323299205;
    string oVGEgWFQwegwJ = string("poKoNtPgweukKYoLwEDTVYQIjUW");

    if (HazQiJaypmiMZMR <= string("KmYjOsHEZPVRefoTnCEuXrGXy")) {
        for (int cFjSROy = 390701058; cFjSROy > 0; cFjSROy--) {
            continue;
        }
    }

    for (int OLkEyZZhpldVUBBR = 1117438524; OLkEyZZhpldVUBBR > 0; OLkEyZZhpldVUBBR--) {
        fyHoBETUMfZdj += oVGEgWFQwegwJ;
        fyHoBETUMfZdj = fyHoBETUMfZdj;
    }

    if (fyHoBETUMfZdj <= string("poKoNtPgweukKYoLwEDTVYQIjUW")) {
        for (int naKXvPODuBENWLI = 1126345312; naKXvPODuBENWLI > 0; naKXvPODuBENWLI--) {
            aidXt -= aidXt;
            oVGEgWFQwegwJ = fyHoBETUMfZdj;
            HazQiJaypmiMZMR += oVGEgWFQwegwJ;
        }
    }

    for (int RbYpNSsmJw = 978460011; RbYpNSsmJw > 0; RbYpNSsmJw--) {
        aidXt *= aidXt;
    }

    return true;
}

void hEBLpsEi::hyKrOLdhS(bool fkHyzOGaaL, string luXBWeCmktGvyAS, bool IZajupGdW, bool RNhpIPXALYhSXR)
{
    string yFBDdrz = string("lanLtAsCemqXLLQpJEoTwgUBTYGpZzgZrycrYdFRhIErGQbPyCsFefdXqYmDfGequKCRuJUzUTrxPLKOcNSyueYHdbMwRqCWzQQuHGCyLNNLDfmvmcpuKLifAvedKTrvyGbFZhucmTnHGdCrKJjjLrbLTSXVMmHoZJNproICSbDmnFVmQfcoBAnbPWqonkbAwiCkvYuedgLmNPQbYiFIasxPlyuRufAtKPfOhHORamt");

    if (RNhpIPXALYhSXR == true) {
        for (int RhMsJ = 1037888381; RhMsJ > 0; RhMsJ--) {
            yFBDdrz = luXBWeCmktGvyAS;
        }
    }
}

int hEBLpsEi::wqPMwRfiYJMcm(double TIjtMersNEeZB)
{
    int mFiXopUA = 1867369068;
    bool QpBvnJT = false;
    string CxRtPpu = string("xzQ");
    double GPYaydUFLwNtP = 645646.1824360784;
    string OxFKcUtsixVJ = string("VHafLNioe");

    for (int OmPWYIcIMzvCNpS = 1041098348; OmPWYIcIMzvCNpS > 0; OmPWYIcIMzvCNpS--) {
        continue;
    }

    for (int jSMUSxMGuf = 2091121730; jSMUSxMGuf > 0; jSMUSxMGuf--) {
        GPYaydUFLwNtP += TIjtMersNEeZB;
    }

    for (int ywhpPY = 142150619; ywhpPY > 0; ywhpPY--) {
        continue;
    }

    return mFiXopUA;
}

string hEBLpsEi::rVSgNFonSyhsp()
{
    double jSUXwnKreafZu = -814726.4219618915;
    string AjPcKiJGjqf = string("cnPediQrbwsHPbZLoJYXNSadENHpDxImGIUYkSvVkehEVwgJELHeujNhJGeWczBZmiZEgiFxbQvVApIthAHoILpSKdnpbPJipjVhiOtbSlKfZEfhEKdoGAQyDiCdGrbQcxbssCYNcXGDVmKppwYHPHdiMfjrFSNgxYLIVhiSkvhkdZHegOuioEidxaWaFODtvUKOPXaMMmILETNxBGMklNtteg");
    bool HcSxUzFvg = true;
    int zmEumWs = -142600813;
    double CBkyyICxKDKUh = -23781.479705606533;
    int HeaChIKWzt = 599845002;
    string GUcTwlWyCplq = string("lyyuaOBvamzgDFckObrZPGnINLmWpZKhCfKdCfofbSNjGfjZYDQhiliSahEYRlLOZggEXNKuamUathGcGqTMASrAJRDE");
    string OUWqrgwyTohltMVd = string("ShIIccJHLtAnwTBfobpUTUdERhAQbNbqePtxvHvMjphJxXyQGPapdktNWEqwmyVjsfJzKLaDHrjKmJkBdpGCRRgfFnwdZNpDLfsTgUezF");

    if (zmEumWs > 599845002) {
        for (int uSdoFPqsdyoIpS = 2032985877; uSdoFPqsdyoIpS > 0; uSdoFPqsdyoIpS--) {
            zmEumWs += zmEumWs;
            OUWqrgwyTohltMVd = AjPcKiJGjqf;
            HeaChIKWzt -= HeaChIKWzt;
        }
    }

    return OUWqrgwyTohltMVd;
}

double hEBLpsEi::noVSZJrri(string EqpLLGLQa, double bypQxyXVm, string xzsINlGcpcbJW, int wbBBU, bool lRoEoyPpFsqqy)
{
    int KAPsnhOnPJTwfQq = -1107459826;
    int InbuxhoPE = -1968057016;
    double jQlMoj = -653221.5460392874;
    int fjkOcUpJYwVloNKy = 1681357197;
    double yrboSJzM = -188663.53082088602;
    int DCSBSqNxKlFNlda = -1776205170;
    double kZhhCCe = 881949.2951933665;
    double uXGvfHSTBf = -48193.3161701049;
    bool dBMLSNZrcjgNmC = false;
    bool vjJqjcnM = false;

    for (int IUyXaQd = 755851220; IUyXaQd > 0; IUyXaQd--) {
        continue;
    }

    for (int hKJqLIA = 402018404; hKJqLIA > 0; hKJqLIA--) {
        bypQxyXVm += uXGvfHSTBf;
    }

    return uXGvfHSTBf;
}

hEBLpsEi::hEBLpsEi()
{
    this->kEmhT(136749.02187216387, 2100655776, false, false, -1370512982);
    this->HkPmnNFJXEtdlkad(string("BeehENzumJKfHAmsNbdOeRlgZHOWlUAotTvXDdcqCxXUxItMuXjkhigkGejkYZcPVwCbnQomQPpWSdWeqgLsFwEwjvQStCqhLuggrzmRYbfayBCeq"));
    this->rncZKmIpg(-1025498.0186795102, false, false, string("oRzmibsqbwoTjyNpoQBOszDlZBUQxYjrToJjQHiKflQCUxuGYqsoPdHrMgqkwcNfqBpnEzalgeBkXPqnIvStmAOTmrOeNVXLPJFkNUPHAMyhaRzwDNwCcehqoNFDFLbymdycykWemEacjjFHGsjpNTDixfvSBdoZbFRoWGAlTXkTYuOiyDpqWomSwLOvIfHsvrIxWtpaInCYWpvPwDKEBnvtXreilhMAXYCbafhsrJWUzQFVTll"));
    this->YZfMFC(1085233391);
    this->uDaCkRlqcBXuxcS(string("tVMvGrTjimESsLkHkuCZacTXPiUwRPEAqYRSYCKXGwpgVUczrdguLUNxwDghHUSDkobYWIAIbtMRavfUNdrfURMFdQZTQjJeFTTBZbDwybCNmTNRODYJRJAqbmYQSbGWvDeLHcFvQNVTnFHAJDKXUQfRoZYKMlVvykiXsBVAgPwNKkVTYuxcvdvJxuzbibOQXJkyjEbonhDAzVGMogXYaEvljriqAXvhKzIgyRuwSXKrECHc"), -933384714, false);
    this->kbWzfEMu(string("pdTAqRmIQdnimHMzDYZNSsgYBPnGpEDpqUMEfrNCAAymHEDKWFAqtccKBZFTHdszCelpCPAkHDIQGoHSVOlWEEEgqmpypCgWIAtVEuBCxOYqBSeNLDZxamOujHcfZOvKhGkGJeQundkTurSofDenpjRRtljvFOrxEtvspDixeYVfyZwZxCxGuQGuqbzBtttCqNYdjEjMuJWcZoNKGObrhbcTFGEbAqzwCFJpLGOTaigKzgUspLSIDvH"), 1359590860);
    this->MLstPwzrOoFyWplN(32676.78466472001, true, true, 1726374215);
    this->dYmjeuPVWvP(67091974);
    this->wgiMlpoNlIgSbU();
    this->zZWsUGcjwNQ(true, false, 1845549649, false);
    this->AUTXfbymaOkiXjpa(983993678, string("LqjraaFbNjEUTroWJoPukIdoKeUdnCugesTyoDGjoKuVC"), -1408100134, false, 887752.0370373846);
    this->KrHksUj(string("KmYjOsHEZPVRefoTnCEuXrGXy"), -676804.0065174032, string("rgZKJkLdvHsojciEpHlRsgDMJuRTByJlSXWjGCnVWTpOPuLxDGuqQCvsktbxLUDLpxSegnPmNjyQuTUsbADMzoFrJkIiHYchxdcuJALAnyRlDGGzrwUSaFMehRFwuVndTTtKRyqyhdHPjrlWpNRCJDLmxNrHezoXoKTvEAxd"));
    this->hyKrOLdhS(true, string("yGaX"), false, true);
    this->wqPMwRfiYJMcm(-77458.93311174467);
    this->rVSgNFonSyhsp();
    this->noVSZJrri(string("aUPlnAZywoRlkLcpSlDFcccdBKDWPJKLaHmvBqSryLscyrcRnQNZAYoisCfAfvRAxEIlSXLgwZXRQzXDUKRysNsLiVZfzPmNQmOqRAZyWAAvLJczKemSFWvnypuYxbfpLtWMdpbyFFkgUeVQHkmSismADrzxeFrksQKlNJbmsQmxlfJmWDGasqXDLDTGvHGphsgtRtKelKxERkatjGymkBqBCwMuNohedCTQ"), 562826.4044437761, string("acAXoOZbiQQYmkezhwdUthRmonCByFEXMhzukAlEgIdeboClOUGsNCE"), 252601576, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SKDxkeSXKmPZj
{
public:
    double VlBLLiVreLde;
    string rIyZDnrRVw;
    int giAVOjsXhhrmpllt;
    bool voYxoNBkRnL;
    bool FGNvoNJ;
    int UsKZBCYKVrCHEAv;

    SKDxkeSXKmPZj();
    bool LywdZTyUly(string GMYuC, bool OvfShLOOSho, string TacfSFbxSIYWY, double ihQPBbnba);
    void IAOogaYwFSsjkcp(int MRbbo, bool YcoirXcNfa, string NzNZaa);
    string PuaVUBMwvlXNMrh(int LAKaqorna);
    string bZxHdIXIozOYSi();
    string AymcmNdhiykY();
    int FXBLyfEU();
protected:
    double dIbxdHj;
    double xXKJyTYQpdLLza;
    string WZFgDvmDYT;
    bool AQorDEFvaebODHEx;

    bool UTaiNaJvE();
    bool cdqLAHEldr(double tsupVsh, string jxluthYUW, int ozWxe, int DkaBhzYgx);
    double PFKAHDnvjhPCH(string OtnCYw);
    double qadRISiPamCIMXW(string TERcwDndIqzNcJx, bool AOcVyRIlrH);
    bool qqeRW();
    string RdxvyniKdjQSQx();
    double oEfnoYdgfBqCPRoG(bool IKyEzizvuWzX, string jyicL, string DzsyBptCIWWIkRb, int Qlxhykb, bool gItYscbtGrJFiS);
private:
    string dQtNVEoKBywrGbnk;
    string FCPIUlaUV;
    bool NlYyKxFeAAcs;
    string lFdEArbUnLCIS;

    string mDajGw(bool MkEXQo, double XVeVMw, string LboTtAkzOGGJDFr, bool tAEEUoFUzazCzw, double KYshrfekPwhbWuLi);
    bool ZlbbXEogvQCV(double kHzYwJ, double RdGJgW, string zwLViOvZUwX, string eysaenvPiNiItSdQ);
    int WelVYLgPvVxBrDqb(string iuPGEPBWO, bool nXAtk, string xzfrGPTDzqMf, int HrxAr, double CgAtwVxGmA);
    void MAHUVNpqsIhTQeOV(double peGviIYgiQuRA, string coCLEztgrM, string WbwvJtr);
    string kylIdQlcqMlsyw(int eeVNXPLfVFEQ, int CYtQz);
    bool ZdwcsZjaxk(int oRsiDUXSClFVmyz, bool FXRFYureImTRukMy, bool AmyxltpQVC);
    double wMmbWGgmqtZWrr();
    double hRtgBz();
};

bool SKDxkeSXKmPZj::LywdZTyUly(string GMYuC, bool OvfShLOOSho, string TacfSFbxSIYWY, double ihQPBbnba)
{
    string rDeHnIMCYFFLVc = string("aqQjvigBjBloyamkGVdcpahGVOkK");
    double zhlfgJWcaDkstSx = -402864.9304923129;
    double aGhhYHoEx = -512852.8266722868;
    bool flssJXHnDO = true;
    double FGNVKwBjIo = 747478.143154605;

    for (int KPvMJlKbDpZvSW = 279923121; KPvMJlKbDpZvSW > 0; KPvMJlKbDpZvSW--) {
        zhlfgJWcaDkstSx += zhlfgJWcaDkstSx;
        zhlfgJWcaDkstSx /= ihQPBbnba;
    }

    for (int tnLuSuxpRkJWa = 821465050; tnLuSuxpRkJWa > 0; tnLuSuxpRkJWa--) {
        aGhhYHoEx = ihQPBbnba;
        TacfSFbxSIYWY = GMYuC;
        GMYuC += rDeHnIMCYFFLVc;
        rDeHnIMCYFFLVc += rDeHnIMCYFFLVc;
        aGhhYHoEx -= ihQPBbnba;
    }

    return flssJXHnDO;
}

void SKDxkeSXKmPZj::IAOogaYwFSsjkcp(int MRbbo, bool YcoirXcNfa, string NzNZaa)
{
    string xUlzhKZEJV = string("CZXPuvLQUbEbuBYFbBXaFVblhhzygsfcMldxuSMqjvUBdnZVSfJVbLLwpHXqiHeAKGgtcofyGlTVIKGYNXiF");
    bool yuxNjDoGhr = false;
    int qIXSyn = -1416693423;
    string VidTwkgXHvZNpH = string("wuLlgMyMKekFdSgFYLkMjkpETXBMXGIzwxJchzGArynWGUIefLsqJsmccpwjMZxdTuzigyLPMdwCuMoIpbYqbRLpGHOvvxvlmJIuuoYZSvsFktUCCIYgZMFswnjymSXqZroUhMvKgIRtlwmIVKAcWKPSXVkIWVrLTRZQFIuvxkDF");
    bool lxRhgEcS = true;
    bool EUfDiKfMJUoPf = true;
    string rKMlIND = string("uEPhmaghOgsHlwefrNFsOaeqythNKvkVIUNdfSEetTLrHPqZLPMRhlYcSzQMvvVOJSFRKeBMSDOOyeqQnpPCrcVrpYsZRFMgYISjYSrnwGMJqTyzCbaMcGHZqBfVgWjlpCmfarCPiuyGZUfwzvucxZugaoIjRiUraeqdcmBQAvBgnwTjlCPtXscdxBhsHwGPBJoHaVMsqcCobJsIzMAJF");
    string OJiuOnsgT = string("AgGMq");
    int kTJoe = 160527848;

    if (yuxNjDoGhr != true) {
        for (int tATxjmJdXNB = 1892024257; tATxjmJdXNB > 0; tATxjmJdXNB--) {
            YcoirXcNfa = lxRhgEcS;
            NzNZaa += VidTwkgXHvZNpH;
            rKMlIND = NzNZaa;
            lxRhgEcS = ! EUfDiKfMJUoPf;
            lxRhgEcS = ! lxRhgEcS;
        }
    }

    for (int NvlfpVbjigusdieG = 1848553995; NvlfpVbjigusdieG > 0; NvlfpVbjigusdieG--) {
        lxRhgEcS = lxRhgEcS;
        yuxNjDoGhr = ! yuxNjDoGhr;
        xUlzhKZEJV += rKMlIND;
    }

    for (int gwzsp = 1490559087; gwzsp > 0; gwzsp--) {
        yuxNjDoGhr = lxRhgEcS;
    }

    if (EUfDiKfMJUoPf == false) {
        for (int taqxtwvEhMjJA = 1192117459; taqxtwvEhMjJA > 0; taqxtwvEhMjJA--) {
            YcoirXcNfa = yuxNjDoGhr;
            xUlzhKZEJV = xUlzhKZEJV;
        }
    }

    if (OJiuOnsgT >= string("CZXPuvLQUbEbuBYFbBXaFVblhhzygsfcMldxuSMqjvUBdnZVSfJVbLLwpHXqiHeAKGgtcofyGlTVIKGYNXiF")) {
        for (int pxVYOUSzFqvR = 1930476636; pxVYOUSzFqvR > 0; pxVYOUSzFqvR--) {
            continue;
        }
    }

    if (yuxNjDoGhr == true) {
        for (int NbxocAA = 1525811830; NbxocAA > 0; NbxocAA--) {
            continue;
        }
    }

    if (kTJoe < -1416693423) {
        for (int FdkQP = 320918306; FdkQP > 0; FdkQP--) {
            lxRhgEcS = ! EUfDiKfMJUoPf;
            qIXSyn /= MRbbo;
            VidTwkgXHvZNpH = xUlzhKZEJV;
        }
    }
}

string SKDxkeSXKmPZj::PuaVUBMwvlXNMrh(int LAKaqorna)
{
    int cmcLSHSWdryOTO = 1175974741;
    int XijXCoWSOdviUu = 1536236436;
    int IJvBmEDxVSiY = 617427532;
    int vNwYeKKDKgX = 515134478;
    bool hXjZeqIPTOcGor = true;
    double IaUJFUqzAahcMvAB = 961522.8161410916;
    bool zynrQI = false;
    double PQWvlW = -724609.2296189833;

    for (int xSsbpE = 2020629937; xSsbpE > 0; xSsbpE--) {
        zynrQI = ! zynrQI;
        LAKaqorna *= cmcLSHSWdryOTO;
        LAKaqorna = LAKaqorna;
        vNwYeKKDKgX -= IJvBmEDxVSiY;
        cmcLSHSWdryOTO *= cmcLSHSWdryOTO;
    }

    return string("QWuAmNYjACkygkcnuGdMIsTcLWtQjqtllsXatWQNiTsiyNcDDsvcalbfonUNmrgGgchxocwptfPauoYpbBXPzkCOfJLLVgBwMXIxXNKEHOsGwPBokTywzRqNFTcntFJLXaVXBVuSBYwYlHLJXhZTXiRpLOsCZqqOzDeV");
}

string SKDxkeSXKmPZj::bZxHdIXIozOYSi()
{
    string EJzJC = string("qArVXiIYvtrhPsktxgPlcYvPOPqeQyoMsAeqNOKnxUlAIqRQLAWyYvgLGnjOvRzSSlRcIhkOtrceANymZQhKPQZTpIewObBOkPDCNkVhxndWSvQBxlRcoAZpQwVenoqlqFAQywVyZJRIdgLMrcxyjtUgXafOfGPOUFxlExuoeqnPIwjjBqNaRAFJHfujWZqXniRlOfmXiklmbzNKPLe");
    bool ejJoloIDrRZLk = true;
    int laAEBNjhuHnqiPF = 1820431260;
    double YdbGkdtHzgnOWRU = -336363.2672941969;
    int hhlUqZjZfN = -1215502898;
    string NjJvcFWmflj = string("KLJrQTLOMxkXpkmHHZVOxwnTUnSlawFJZSigcgRXTNhYKlhIxEYKaHpBWkMHWOEBaVZYWfPlUwvztxSkScHvNYgPpS");

    for (int DjXLMit = 1489806866; DjXLMit > 0; DjXLMit--) {
        laAEBNjhuHnqiPF /= hhlUqZjZfN;
        EJzJC += EJzJC;
    }

    for (int CTJEJjrZUviCO = 2096013487; CTJEJjrZUviCO > 0; CTJEJjrZUviCO--) {
        NjJvcFWmflj += EJzJC;
        laAEBNjhuHnqiPF -= laAEBNjhuHnqiPF;
    }

    for (int PETQcVeAtnIjXAT = 1640858727; PETQcVeAtnIjXAT > 0; PETQcVeAtnIjXAT--) {
        hhlUqZjZfN /= laAEBNjhuHnqiPF;
        EJzJC = NjJvcFWmflj;
    }

    return NjJvcFWmflj;
}

string SKDxkeSXKmPZj::AymcmNdhiykY()
{
    bool RIyWNsnL = true;
    bool aIbVrbUdtjJF = true;
    string gaSHik = string("SprgECDoUjaGLzVaOwRgyjcqhatlPaVQEBJluBeLbIKThkBRFcXUWIpgYoLdXwPYkREEbAHVbmJGjeoAJtDqDBJUJezWIfpQRUfOuBeLRLkMzvyXxqrbmoyGLhKvcmUvsgniImJadXGNBWqmZxzBSiXXxZtPEoPsWfOfHqCSgtmOlzqZtZJIOADDUicOLgWXMLkwuwzVIEtuUYuygyxwLdxjiaxegiJGvbBDgS");
    double xTxtxTzkRZ = -29655.256782136265;
    int vvqQYI = -1882395098;
    bool KdFLdKjTWYMMXkf = true;
    int gbzxTFhEbVKdKdRe = -1384488254;
    string kJvYB = string("sVzhmyJmAIcWmhkfuQymPKQhxwpIdTQhQUIDMSdwMFHsqBMOQPCYMHOvjxMTbTnANXFYIPDKTgzvyDMARNJKRgFGOxgNayXJjhnsKEsfZmoFFuRNEUhOAuwKHCmmGzMBMRVPBiehNyiszzRqBaWGDqtGWSOOU");
    int PnlkZgdzGo = 722272419;
    string paIpVUwAmiad = string("xBrqZhLnTlEYclGhrXuzSzjcmHnJDnHYgBnSpyFYkaUSareCcTIjpY");

    for (int yxuhXcgBmpqDB = 1089197944; yxuhXcgBmpqDB > 0; yxuhXcgBmpqDB--) {
        KdFLdKjTWYMMXkf = ! RIyWNsnL;
    }

    for (int SFQJbESPk = 607005624; SFQJbESPk > 0; SFQJbESPk--) {
        xTxtxTzkRZ += xTxtxTzkRZ;
    }

    return paIpVUwAmiad;
}

int SKDxkeSXKmPZj::FXBLyfEU()
{
    bool ZXcORsctXBpkzV = false;

    if (ZXcORsctXBpkzV == false) {
        for (int zJQfuhMDGhTsBq = 150030181; zJQfuhMDGhTsBq > 0; zJQfuhMDGhTsBq--) {
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ! ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
        }
    }

    if (ZXcORsctXBpkzV == false) {
        for (int TUVPknuaCaNBbY = 921808052; TUVPknuaCaNBbY > 0; TUVPknuaCaNBbY--) {
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ! ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ! ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ! ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ! ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
        }
    }

    if (ZXcORsctXBpkzV != false) {
        for (int HKcsXVbOIPQFdLsA = 1290337462; HKcsXVbOIPQFdLsA > 0; HKcsXVbOIPQFdLsA--) {
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ! ZXcORsctXBpkzV;
            ZXcORsctXBpkzV = ! ZXcORsctXBpkzV;
        }
    }

    return -1294565611;
}

bool SKDxkeSXKmPZj::UTaiNaJvE()
{
    string MxFPpQXEEhQp = string("BZCnrTjOgvmAIRmzcvglrDtgUlmhfOCqOnfjMefXAgrtCypSWZMEzXHomjkvkrkvQPZXjUDgfEYeVCMVofnbBGVYnWrLFwIyDrMOcSACxhIDdXeXGqBpZrfKSCESkFrJvxWmuwUfTkupMfYqASlWoGVCAYtzGzOKOZefeadzGfRjlstmuBZnLpKGpuzOtPbCFgjNokGirJmatnTkuQnTuLE");
    bool LsfOU = true;
    string WQctLFHM = string("cuwfKybtfVZtrtztdxPDgiPJUyHvGShmYV");

    if (MxFPpQXEEhQp < string("BZCnrTjOgvmAIRmzcvglrDtgUlmhfOCqOnfjMefXAgrtCypSWZMEzXHomjkvkrkvQPZXjUDgfEYeVCMVofnbBGVYnWrLFwIyDrMOcSACxhIDdXeXGqBpZrfKSCESkFrJvxWmuwUfTkupMfYqASlWoGVCAYtzGzOKOZefeadzGfRjlstmuBZnLpKGpuzOtPbCFgjNokGirJmatnTkuQnTuLE")) {
        for (int rSAvhkmmXT = 2012017818; rSAvhkmmXT > 0; rSAvhkmmXT--) {
            WQctLFHM += WQctLFHM;
            WQctLFHM += WQctLFHM;
            MxFPpQXEEhQp = MxFPpQXEEhQp;
            WQctLFHM += WQctLFHM;
            MxFPpQXEEhQp = MxFPpQXEEhQp;
            MxFPpQXEEhQp += WQctLFHM;
        }
    }

    for (int ayFcAoUREfwT = 1932795209; ayFcAoUREfwT > 0; ayFcAoUREfwT--) {
        LsfOU = LsfOU;
        WQctLFHM = WQctLFHM;
        MxFPpQXEEhQp += WQctLFHM;
    }

    if (LsfOU == true) {
        for (int GIRKEJftBjgaM = 205931816; GIRKEJftBjgaM > 0; GIRKEJftBjgaM--) {
            MxFPpQXEEhQp += MxFPpQXEEhQp;
            LsfOU = LsfOU;
        }
    }

    if (LsfOU != true) {
        for (int dUvilYVtXEbMarE = 721956295; dUvilYVtXEbMarE > 0; dUvilYVtXEbMarE--) {
            continue;
        }
    }

    for (int MOBGzvYhrRagune = 1657833695; MOBGzvYhrRagune > 0; MOBGzvYhrRagune--) {
        MxFPpQXEEhQp = WQctLFHM;
        MxFPpQXEEhQp = WQctLFHM;
        MxFPpQXEEhQp += WQctLFHM;
        MxFPpQXEEhQp += WQctLFHM;
    }

    return LsfOU;
}

bool SKDxkeSXKmPZj::cdqLAHEldr(double tsupVsh, string jxluthYUW, int ozWxe, int DkaBhzYgx)
{
    bool qtiNdbrrXXO = true;

    for (int tcoGUjIWxTkK = 225994145; tcoGUjIWxTkK > 0; tcoGUjIWxTkK--) {
        DkaBhzYgx = ozWxe;
        DkaBhzYgx += DkaBhzYgx;
    }

    if (ozWxe >= 512749245) {
        for (int eApjSCzzKjqtowS = 29762620; eApjSCzzKjqtowS > 0; eApjSCzzKjqtowS--) {
            DkaBhzYgx -= DkaBhzYgx;
        }
    }

    for (int GsahGagfiGQrM = 2144549991; GsahGagfiGQrM > 0; GsahGagfiGQrM--) {
        jxluthYUW = jxluthYUW;
        jxluthYUW += jxluthYUW;
        jxluthYUW = jxluthYUW;
        ozWxe /= DkaBhzYgx;
    }

    return qtiNdbrrXXO;
}

double SKDxkeSXKmPZj::PFKAHDnvjhPCH(string OtnCYw)
{
    double aUkJuqNwJICQy = 870490.4018904773;
    bool BNkOblGiT = true;
    int ywEZsyJXWq = 1484925795;
    int aXVEpOtfm = 755425330;

    for (int JWiRqqEXJaRNpaOv = 748066260; JWiRqqEXJaRNpaOv > 0; JWiRqqEXJaRNpaOv--) {
        OtnCYw += OtnCYw;
    }

    for (int qSPEaIBY = 283505569; qSPEaIBY > 0; qSPEaIBY--) {
        ywEZsyJXWq -= aXVEpOtfm;
        aXVEpOtfm = ywEZsyJXWq;
        ywEZsyJXWq /= ywEZsyJXWq;
    }

    for (int IPTblZuP = 1666653293; IPTblZuP > 0; IPTblZuP--) {
        continue;
    }

    return aUkJuqNwJICQy;
}

double SKDxkeSXKmPZj::qadRISiPamCIMXW(string TERcwDndIqzNcJx, bool AOcVyRIlrH)
{
    double kTDaTgVGvSdUO = 206640.33873761544;
    double cJeyiBIrnSjGALtr = 730651.7636868559;
    int zAuvWFwBhA = 33695998;
    string qdcuHc = string("GRrSzTorRCONoCeKsigFKePfEUCpnDCosMeLsACVpdtaXxseZzRvSlXxKTtUaBKGTqKqlgxRHvQvXoScsqdzmdrEPRKryGFwohZwhQSVOY");
    bool BKrhRMEVEnLxAAt = false;
    string OvsdjEgrSGWDFiAN = string("HEBZIqiXPGTOvkiAxOkqKmGxcAZ");

    if (TERcwDndIqzNcJx != string("HEBZIqiXPGTOvkiAxOkqKmGxcAZ")) {
        for (int JGHsXQbcvCjfH = 1994481462; JGHsXQbcvCjfH > 0; JGHsXQbcvCjfH--) {
            qdcuHc = TERcwDndIqzNcJx;
            qdcuHc += qdcuHc;
            TERcwDndIqzNcJx += OvsdjEgrSGWDFiAN;
        }
    }

    for (int rMdseJyoyVXCSf = 1059556491; rMdseJyoyVXCSf > 0; rMdseJyoyVXCSf--) {
        TERcwDndIqzNcJx += qdcuHc;
    }

    if (cJeyiBIrnSjGALtr > 730651.7636868559) {
        for (int kMSKGPQLw = 1936992217; kMSKGPQLw > 0; kMSKGPQLw--) {
            qdcuHc += OvsdjEgrSGWDFiAN;
            TERcwDndIqzNcJx = OvsdjEgrSGWDFiAN;
        }
    }

    for (int eRNQZOnt = 581820247; eRNQZOnt > 0; eRNQZOnt--) {
        continue;
    }

    return cJeyiBIrnSjGALtr;
}

bool SKDxkeSXKmPZj::qqeRW()
{
    int lGfCxAIkB = -343765279;
    bool lBufB = true;
    string jHPslRWvTyI = string("dcCBcuJJDBwAEMZpJGhvMoWtbcjpKKxjRjlOXLDxNJNUUYPhCpGjnRNWeJBjMq");
    bool hWsENdnHYUaAPy = false;
    bool wQYMGZKvzIcJD = true;
    int rXawPhN = 1553090403;

    return wQYMGZKvzIcJD;
}

string SKDxkeSXKmPZj::RdxvyniKdjQSQx()
{
    string CaSYTUqS = string("NQQkMTUsWtwftUAoVOkDlRtjsQybSPykoDkOTKCFmbxLwutmBOiBNPraeJneuIfUCGvscImInHJjgrLVkNcBqYTxfkETbIBvMIYTpFSiiIhAkOcGQhGNwedXUDAOlJiOdYbtXgTpkZKIpSBZtwQXHIggpAEGzplRqOFWPxYcZaxHMbbEFjvYShPOcOEootmLfhCTmRczGmzSCokNQsxXJVMoavgVyJiiMYnqyvlaXsYAF");
    string UpFFzKCZozS = string("oSTWyYOoXDNfuweKlHWGYWqKGBLpLEaXBBnCQBsyryjz");
    double PFSoXpPnLIrv = 1002426.1177288708;
    bool qRNvyWHLehJli = true;
    string njreKYMf = string("OIoRkDrgkKddQRNVDYrlTrsKOFDLsBXPErvZjHxsdvTDBpJxbHqCFXakiOGlcPrTZBSHjHKXhjLPMDHvgrPZUNefqwpeQijPgYKgBCweyzMAJlRARHCbepuCzFqZXkzaJNfhJvffGipgigKjCYFzYDKNYqyWJYPRgMjNyYuxfWVuIatXubXxuKjTRSncuHOtBbeVfaiANmFWawajlsspoxLcmuWfyEOWgsZjCBrZvklTvQTLEOsTgeaRVRcB");

    if (njreKYMf <= string("OIoRkDrgkKddQRNVDYrlTrsKOFDLsBXPErvZjHxsdvTDBpJxbHqCFXakiOGlcPrTZBSHjHKXhjLPMDHvgrPZUNefqwpeQijPgYKgBCweyzMAJlRARHCbepuCzFqZXkzaJNfhJvffGipgigKjCYFzYDKNYqyWJYPRgMjNyYuxfWVuIatXubXxuKjTRSncuHOtBbeVfaiANmFWawajlsspoxLcmuWfyEOWgsZjCBrZvklTvQTLEOsTgeaRVRcB")) {
        for (int YgwcyEeX = 1209479816; YgwcyEeX > 0; YgwcyEeX--) {
            PFSoXpPnLIrv = PFSoXpPnLIrv;
        }
    }

    return njreKYMf;
}

double SKDxkeSXKmPZj::oEfnoYdgfBqCPRoG(bool IKyEzizvuWzX, string jyicL, string DzsyBptCIWWIkRb, int Qlxhykb, bool gItYscbtGrJFiS)
{
    double OgOlG = -684305.6625293967;
    double vtiGfYjKnOoRpQxQ = -794668.2086669403;

    if (vtiGfYjKnOoRpQxQ != -794668.2086669403) {
        for (int aZtFzENTw = 1298787340; aZtFzENTw > 0; aZtFzENTw--) {
            OgOlG *= OgOlG;
        }
    }

    for (int GFPzQ = 357528047; GFPzQ > 0; GFPzQ--) {
        vtiGfYjKnOoRpQxQ = vtiGfYjKnOoRpQxQ;
    }

    for (int QRYHpRNJJsBZa = 571481914; QRYHpRNJJsBZa > 0; QRYHpRNJJsBZa--) {
        continue;
    }

    return vtiGfYjKnOoRpQxQ;
}

string SKDxkeSXKmPZj::mDajGw(bool MkEXQo, double XVeVMw, string LboTtAkzOGGJDFr, bool tAEEUoFUzazCzw, double KYshrfekPwhbWuLi)
{
    bool nXBBZN = false;

    for (int YIFcTOCYec = 480218907; YIFcTOCYec > 0; YIFcTOCYec--) {
        continue;
    }

    if (nXBBZN == false) {
        for (int QgRcBNLxKvPEF = 375122058; QgRcBNLxKvPEF > 0; QgRcBNLxKvPEF--) {
            nXBBZN = ! tAEEUoFUzazCzw;
            LboTtAkzOGGJDFr = LboTtAkzOGGJDFr;
        }
    }

    if (LboTtAkzOGGJDFr <= string("pIBZLEYXWlUkiKhWhytNFXZQnwWFzWLFYwiXTGDKKurKnEsBjJAHmhghFyDZqGnHmmYTbBlNjktqxSYpwRtsTEinuXxcAJoxbuOIyuVfgYJzQKraojLgEGAExGglHwlerYXvfmLVKRoHKdqvLNJcQdpBUrfJyPAIjfJMBYKLNgYxHDhTeDyRhoKoWEgVadhmkdwavkhKRvWrQVYshAXkCbQBSAmXTlVJlnJlybFiWxiBkbOqPTGvjZEso")) {
        for (int DzBEuKzXa = 604084522; DzBEuKzXa > 0; DzBEuKzXa--) {
            MkEXQo = tAEEUoFUzazCzw;
        }
    }

    return LboTtAkzOGGJDFr;
}

bool SKDxkeSXKmPZj::ZlbbXEogvQCV(double kHzYwJ, double RdGJgW, string zwLViOvZUwX, string eysaenvPiNiItSdQ)
{
    bool ZdWfGWmX = false;
    bool UZFMgCulQBmrJHx = true;
    int tOyyE = 1287436665;
    double wkgOAbPI = 478131.32796925126;
    bool VYGxkGapxcascm = true;

    if (kHzYwJ > -974139.2218454242) {
        for (int ZfmrykKVkdbscc = 1101103600; ZfmrykKVkdbscc > 0; ZfmrykKVkdbscc--) {
            RdGJgW *= wkgOAbPI;
            kHzYwJ /= RdGJgW;
        }
    }

    for (int izEHt = 356671481; izEHt > 0; izEHt--) {
        VYGxkGapxcascm = UZFMgCulQBmrJHx;
        wkgOAbPI /= RdGJgW;
    }

    for (int YXGcL = 1639553360; YXGcL > 0; YXGcL--) {
        kHzYwJ += wkgOAbPI;
        RdGJgW += RdGJgW;
        tOyyE *= tOyyE;
    }

    for (int cdpJiZivAggpX = 1139550796; cdpJiZivAggpX > 0; cdpJiZivAggpX--) {
        VYGxkGapxcascm = ! VYGxkGapxcascm;
    }

    return VYGxkGapxcascm;
}

int SKDxkeSXKmPZj::WelVYLgPvVxBrDqb(string iuPGEPBWO, bool nXAtk, string xzfrGPTDzqMf, int HrxAr, double CgAtwVxGmA)
{
    string LcuNFsRjse = string("KjCebOuEbmtYlfNetCBpQZWUPoKhkWgmkYzdAFfNyKUpDkpJPvCsbcEpPAQvcuHmHUGnIkqOepOmRtOHWbnJaLjWzY");
    int zGvtvIZh = 828745037;
    string Zuveevp = string("jFMJgiCvMGKFsclGrSTZAEAeZZnlBKzTAtpanaTCeZdAlYhTPmVLhZdPgdjBvjSpLrZKarATPknHtjCCNAHxkdVVZIvPRuiLhKXZvuHqvNHrXnaGIMftkhdphPNJhgmwlcDeJCEHEVBjvWLkqfhFYUaFrLlWPkVzKZBmXGhWeiXlKHUnf");
    bool ttMMg = true;

    for (int JsjAXzHCqO = 1548075278; JsjAXzHCqO > 0; JsjAXzHCqO--) {
        iuPGEPBWO += LcuNFsRjse;
        HrxAr = zGvtvIZh;
    }

    if (iuPGEPBWO == string("WBRjzZYaaqQrWxnpMcCWPMnzqsHVxwyaXLdrVkjLjYsCdQSLcPaWeZUGJHCngvN")) {
        for (int yClCFsrTnGunMFEo = 2073792324; yClCFsrTnGunMFEo > 0; yClCFsrTnGunMFEo--) {
            iuPGEPBWO += xzfrGPTDzqMf;
        }
    }

    return zGvtvIZh;
}

void SKDxkeSXKmPZj::MAHUVNpqsIhTQeOV(double peGviIYgiQuRA, string coCLEztgrM, string WbwvJtr)
{
    int Ushfrf = 1374538608;
    string HgqYyigYAgyC = string("nocTOuFjcaZkNGasDVGZ");
    double DcnBulWvffyLV = 377189.4919868064;
    int XEiSpWmBFHF = 1408887451;
    int fCEETXzqiOvGnTum = 1792369498;
    string fkZOI = string("bwaBmoxOJEabVTBnZEsMRYRWWxEmVqIDXyNHsdjGWCgwBPFKoVqOFTLOhocvzHczUEAYnbiARYmNkwdVCfmqaTmVOYXtSMoVNqaAsDessczHmhmedlbP");

    for (int YGtsqEfZT = 1764066040; YGtsqEfZT > 0; YGtsqEfZT--) {
        continue;
    }

    for (int liFukHh = 784850489; liFukHh > 0; liFukHh--) {
        WbwvJtr += fkZOI;
    }

    for (int MZqtyViwZ = 1744031670; MZqtyViwZ > 0; MZqtyViwZ--) {
        coCLEztgrM += WbwvJtr;
    }

    if (coCLEztgrM == string("nocTOuFjcaZkNGasDVGZ")) {
        for (int urWoPrGO = 1688382870; urWoPrGO > 0; urWoPrGO--) {
            continue;
        }
    }
}

string SKDxkeSXKmPZj::kylIdQlcqMlsyw(int eeVNXPLfVFEQ, int CYtQz)
{
    double PSgMXh = -321610.6760452733;
    string PhXHmAnkPIgW = string("ZuhhHIbRRJExvvwPAJLlEAHlgyurBWJyuEOoluggmGgMfvGSBOUAoqKwcwYGwPSaIivpvKZwKzTSfvlIvgfyUoLqeOVOAoKvnbCPOhPWoRLItWJBStnckDCNVzuzxTI");
    bool XXXbXNfypR = false;

    return PhXHmAnkPIgW;
}

bool SKDxkeSXKmPZj::ZdwcsZjaxk(int oRsiDUXSClFVmyz, bool FXRFYureImTRukMy, bool AmyxltpQVC)
{
    double heLekWwzNXCaQ = 854903.6863046824;
    string YPlxzjAry = string("zAuoztWLKUvplxpMaHlWOnvuKJJHrQBYOpeqxJIgzmYZfnWawtodxOOviWlOsB");
    bool wFRrm = false;
    double wlDxv = 325534.4400701507;
    bool WFUVJkzDoq = true;
    double raFvmyNuoqetr = 818336.6960725973;
    int PyhEeUyErabsIwM = -826877019;

    if (WFUVJkzDoq != true) {
        for (int aUEjCvphjGpuU = 518855775; aUEjCvphjGpuU > 0; aUEjCvphjGpuU--) {
            oRsiDUXSClFVmyz += oRsiDUXSClFVmyz;
            raFvmyNuoqetr += wlDxv;
            AmyxltpQVC = WFUVJkzDoq;
        }
    }

    for (int RMhAVC = 929444667; RMhAVC > 0; RMhAVC--) {
        wFRrm = wFRrm;
    }

    for (int gzYxQkGJxi = 1919134412; gzYxQkGJxi > 0; gzYxQkGJxi--) {
        wlDxv *= raFvmyNuoqetr;
    }

    for (int DrAhHtrhd = 323995109; DrAhHtrhd > 0; DrAhHtrhd--) {
        AmyxltpQVC = ! FXRFYureImTRukMy;
        wlDxv *= heLekWwzNXCaQ;
        AmyxltpQVC = ! WFUVJkzDoq;
    }

    if (WFUVJkzDoq == false) {
        for (int HEyLr = 1867872153; HEyLr > 0; HEyLr--) {
            AmyxltpQVC = WFUVJkzDoq;
            PyhEeUyErabsIwM *= oRsiDUXSClFVmyz;
            AmyxltpQVC = ! FXRFYureImTRukMy;
        }
    }

    return WFUVJkzDoq;
}

double SKDxkeSXKmPZj::wMmbWGgmqtZWrr()
{
    int WrwGquH = 1907363091;
    int jSqRDnWSrjSwV = 887640765;
    bool XkdDZRd = false;

    for (int QVEUByaOGPb = 2014856868; QVEUByaOGPb > 0; QVEUByaOGPb--) {
        WrwGquH += jSqRDnWSrjSwV;
        WrwGquH += WrwGquH;
        WrwGquH += WrwGquH;
        XkdDZRd = XkdDZRd;
    }

    return -423128.6254187827;
}

double SKDxkeSXKmPZj::hRtgBz()
{
    double nyLUuJOoOPaJC = 579725.7644438086;
    bool BGSFlkMfSOAMZkvk = true;
    bool kxOdwQr = false;
    bool BYWkii = true;
    int gfzvMOWiyvOMd = -1207791240;
    double ynJskhZHFBvy = 222113.16806355704;
    double INVtZQVeL = -789783.9026655126;
    string fXlNUdvd = string("JanacFKCOkHSoEyqxavhAknwJNlfalPBAVEFlMbaLRQavldeUbKjcSgGAlnPengWuFLJkwmXkelpMMhrDnxHuOFhHARSJtKzvdHAqcnffpmzNeDHXZpltbyiLiDMTjboJJttHeMHejaMsKQZSTmOsjSmFYsMaBsBPPWCKLBiREtOwsaHWUpvNUHSCdCWyzZLzSCERoeptjWrxXDcRC");
    bool HXeXjcwdBU = false;
    int sTZGYLQHQxrVc = 1179262419;

    if (gfzvMOWiyvOMd <= 1179262419) {
        for (int IbteJBt = 1978001771; IbteJBt > 0; IbteJBt--) {
            BYWkii = kxOdwQr;
            kxOdwQr = ! BYWkii;
            BGSFlkMfSOAMZkvk = kxOdwQr;
            kxOdwQr = ! BGSFlkMfSOAMZkvk;
            kxOdwQr = ! kxOdwQr;
        }
    }

    for (int LVWQgZxLfDnVzX = 1255610638; LVWQgZxLfDnVzX > 0; LVWQgZxLfDnVzX--) {
        INVtZQVeL /= nyLUuJOoOPaJC;
        kxOdwQr = ! BGSFlkMfSOAMZkvk;
    }

    return INVtZQVeL;
}

SKDxkeSXKmPZj::SKDxkeSXKmPZj()
{
    this->LywdZTyUly(string("ZPoNLdmfeooqJzzbrYtZsbHZldSdqrmupMIleYIgsNbbWESkJddFZYQrpVYnsydMOQiGEXsdHzniGpAosfgFjmjiGEziIXwcFLqEKvYNhiwfDXUmFWhaWLlzjHuGBrrZjRToGssyupdWeZxtpvuQmhCJrCDRraTXi"), false, string("prqWyRJbjJwmMmdZIHaHetMQiJnNASVJHLVIJwmLlctNYwkHyYEQaKrvwqpifrhcfyHdpEzHEtXsODmJpnQGTOuEOqSZhCfFLwdnygzcBpMRcebXVZIMALjNiFEpmatPMJkUCowWNsNdzJATIHBeIxELPSPCFLK"), -496103.3141157049);
    this->IAOogaYwFSsjkcp(269821641, true, string("GSZslEifqhZClGaxNLxcFhtD"));
    this->PuaVUBMwvlXNMrh(-1973257184);
    this->bZxHdIXIozOYSi();
    this->AymcmNdhiykY();
    this->FXBLyfEU();
    this->UTaiNaJvE();
    this->cdqLAHEldr(203391.3090614272, string("rRCvEYkgezVuHHYxTNvUAbhxMPXHtDjHLaXbXnxbXYXonXSuiSZZcnPAgTbIEivUfvfwwifNZQDRmerhwawHQgxVMRNJSiDQjEuOLgIdfuitHAjQKwIqVZiRPchIGIGerjkVqiNBKSfjPXwBdzYLw"), -1634698009, 512749245);
    this->PFKAHDnvjhPCH(string("wRnYZPHkpZQmrJqegNslqekiIjUcZTMGizFeApKGzPtKdJRSKafIrQIegFwMvvAZtdWcCTaYFnOHmxfldhwfJtpsIvYNuoaPcjAJcPkeHqQAxRDrDmLEQwNrMuLSmIbIMiyTDOubdQkQgWQNFmRVsighACNpxkIQHCsRGNUJIGzneqUaYTWnuOecyWrbabUACXYCVbuCHRDZfxZFFMbTIfoLMqMLLUyaQNTdtKHxidfmC"));
    this->qadRISiPamCIMXW(string("ZmBHcThKReRgdPgYHdDckejgeFkOFLoAoVCpzTANrptmeHYzsTrqVaFhHQUDQwQKeGaATAquONIQmfrMJAoUuBbfKAIvPPNyXfoVqCcfiFRmUnynDWlNiYLXojehhlfdyDyS"), true);
    this->qqeRW();
    this->RdxvyniKdjQSQx();
    this->oEfnoYdgfBqCPRoG(false, string("rMGadwCtFCbYHpFJkWwZ"), string("kfrqgMloYYBWyvlRuhklWHgV"), 672433687, false);
    this->mDajGw(false, 850791.5732141042, string("pIBZLEYXWlUkiKhWhytNFXZQnwWFzWLFYwiXTGDKKurKnEsBjJAHmhghFyDZqGnHmmYTbBlNjktqxSYpwRtsTEinuXxcAJoxbuOIyuVfgYJzQKraojLgEGAExGglHwlerYXvfmLVKRoHKdqvLNJcQdpBUrfJyPAIjfJMBYKLNgYxHDhTeDyRhoKoWEgVadhmkdwavkhKRvWrQVYshAXkCbQBSAmXTlVJlnJlybFiWxiBkbOqPTGvjZEso"), true, -212010.20715123782);
    this->ZlbbXEogvQCV(947599.1873533292, -974139.2218454242, string("fTJeTE"), string("yyUXXKZrGHHOBaedStLKoLiUdRntMsWvrLoZXiKBnfjUfauEDpfCEDIcAemekiMTCjeofqGzWBCbmwEaszuXQBZZDkrDmeNlHzxaRNztsTdjYPHRaWemBfkzGsLtWLwnGGxWicPIFlrDqJsNcpPHsFokYrAVYZfcbIiBCwSyGieQLKbUgoioknwiylcntiFMCkhSUMvxwbmGZGueecBvFLjJkByXEopBslCqtkdVW"));
    this->WelVYLgPvVxBrDqb(string("EhlKiuHaPcmomJdzOKwSX"), false, string("WBRjzZYaaqQrWxnpMcCWPMnzqsHVxwyaXLdrVkjLjYsCdQSLcPaWeZUGJHCngvN"), 754765099, 830579.1211302441);
    this->MAHUVNpqsIhTQeOV(-304156.80509887513, string("VpptCSwqbZMSFfZxZrwnMyOvqiaMXgPPEOzMMePLMCcIILstEoeHgRUqCXxaezobVAeLNSXwOBfvGBsgHgXUyOuJtFilJFqJgzkKIwcAzhCFFcixAyLthKYmYkKNWZtGTtSsYHkLLEeTyToqbJioPKcQhNsXmLImSnChFHYDNfvsGyWuRekIjGJdiIBrJxXrbGgbWdQO"), string("RqOyYcpeIGbJ"));
    this->kylIdQlcqMlsyw(-2116076481, -555766205);
    this->ZdwcsZjaxk(746253863, true, true);
    this->wMmbWGgmqtZWrr();
    this->hRtgBz();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qGjmde
{
public:
    string XUjEaAfsoEYOND;
    bool xKJWEkGGMVR;
    double spvshPFTKyy;
    double OtsGJgqfKqZpKWJw;
    string HzKwsgfMOHCsb;

    qGjmde();
    int jFUrMthrmOt();
    bool vqrcupGq(int BREQwasFXrP, double xJvdU, bool FyyzEUdVTuWGKek, string rWYfMRGoyY);
    string rhPcl(int dfWzpAVOsnxfXgaY, double NfsRsbaTEETOj, double SaMInGb, int DXTcnkHnzFXMI);
protected:
    double gNaLVomKYuXAkv;
    double mgDcEa;

    bool cNOOEFz(bool zRFdb, double zhCjC, double dSnJkGa);
    void uFSdOj(string gTgLxWPXyYak);
    string nWFBSR(bool zjjvAWkaypr, string pDfksiprNTSuzjLp);
    double ZHWVjdDT(double bLliIxLxvPRsKP);
private:
    string VDjvQLxdiKYy;
    double xSUZSQAh;
    double TeAkNODtUs;
    bool ibNsRuwpEO;

    int fxdrQyjXFfzgzGhy(double mMVWgxwM, bool fojbvapqw);
};

int qGjmde::jFUrMthrmOt()
{
    int rBPjKqkcHTkTC = 113769218;
    string PHaYWzfpZDem = string("dOVBdGYBTvTPSjDlhENkBdctniaoZlInBjiJmuwtrkmWrMhcGptvavQHiwTlnsDDXNdjBhFhgYpWLvJmRUmUlk");
    int qTELkz = 1633758247;
    bool DMgzFUQ = true;
    bool AJypmVacTgWV = true;
    string qAewisLzlopxvbbl = string("VmzKbzkFXGDrhexHSSPtgwxQqxFIUptBDNTOYMgxnktHbHfGhBLDrUvgruJgwBsJLIFwsFQJUKHUBLZsJmasgQfGhBGfEwjzCVLTgpiUjwYsWWwySQengujoNAiaDrXusGiNrJNATOwqOJVrBqraz");
    bool dBAzkCBppeq = true;
    string EfxgDoyHE = string("kHZMFJrTixCeIfPaDAkV");
    double WabcyM = 355833.4249791494;

    for (int eyzMcOtP = 757806816; eyzMcOtP > 0; eyzMcOtP--) {
        continue;
    }

    if (DMgzFUQ == true) {
        for (int YVBfgnBZeUGRmSqU = 1668397048; YVBfgnBZeUGRmSqU > 0; YVBfgnBZeUGRmSqU--) {
            dBAzkCBppeq = ! AJypmVacTgWV;
            qTELkz += rBPjKqkcHTkTC;
            qAewisLzlopxvbbl += qAewisLzlopxvbbl;
        }
    }

    for (int fyptQFpNw = 907290607; fyptQFpNw > 0; fyptQFpNw--) {
        PHaYWzfpZDem += EfxgDoyHE;
        qTELkz = qTELkz;
        AJypmVacTgWV = ! dBAzkCBppeq;
    }

    return qTELkz;
}

bool qGjmde::vqrcupGq(int BREQwasFXrP, double xJvdU, bool FyyzEUdVTuWGKek, string rWYfMRGoyY)
{
    int LrCJGATx = -203984576;

    for (int cZkQLqhwKxq = 2013147958; cZkQLqhwKxq > 0; cZkQLqhwKxq--) {
        BREQwasFXrP -= LrCJGATx;
        xJvdU += xJvdU;
        FyyzEUdVTuWGKek = ! FyyzEUdVTuWGKek;
    }

    for (int tSFrJpOGIt = 220462328; tSFrJpOGIt > 0; tSFrJpOGIt--) {
        continue;
    }

    for (int wTEYc = 1216685839; wTEYc > 0; wTEYc--) {
        rWYfMRGoyY += rWYfMRGoyY;
        LrCJGATx /= BREQwasFXrP;
        LrCJGATx -= BREQwasFXrP;
    }

    for (int kqeZvhpYu = 1773463175; kqeZvhpYu > 0; kqeZvhpYu--) {
        BREQwasFXrP *= BREQwasFXrP;
        BREQwasFXrP *= BREQwasFXrP;
        BREQwasFXrP /= LrCJGATx;
    }

    return FyyzEUdVTuWGKek;
}

string qGjmde::rhPcl(int dfWzpAVOsnxfXgaY, double NfsRsbaTEETOj, double SaMInGb, int DXTcnkHnzFXMI)
{
    double oiShssA = 170400.9847000333;
    string XMHgvD = string("VRDubKrPLrGQuEsabrGzcMEzxjoANznDQlHVvfgukexQUljNME");
    double MCuXOYlI = 806720.9769809174;
    string bpEaMuua = string("CeuCUYePntinVCZlzbZKIxupPmUfxvParopiHIzoLbvtpTAerfqxqSSDklaKIKPQGSzXyWkJbOtbnjZRfFbMwVpxxHfUOJpJrifiBjDgx");
    double ifvXJdqNXLBJKeyo = -292082.92321522685;
    bool bGvsm = true;

    return bpEaMuua;
}

bool qGjmde::cNOOEFz(bool zRFdb, double zhCjC, double dSnJkGa)
{
    double PLsZyCGBQCi = 579706.0269396285;

    if (zhCjC != -303055.084393115) {
        for (int nMlXrVpsAhHBqE = 139082487; nMlXrVpsAhHBqE > 0; nMlXrVpsAhHBqE--) {
            dSnJkGa *= dSnJkGa;
            zhCjC += PLsZyCGBQCi;
        }
    }

    if (zhCjC != -211355.28797244077) {
        for (int LpIwWKy = 25330840; LpIwWKy > 0; LpIwWKy--) {
            dSnJkGa += dSnJkGa;
            zhCjC = PLsZyCGBQCi;
            zRFdb = zRFdb;
            PLsZyCGBQCi /= dSnJkGa;
            dSnJkGa -= zhCjC;
            dSnJkGa += dSnJkGa;
            zhCjC = zhCjC;
        }
    }

    return zRFdb;
}

void qGjmde::uFSdOj(string gTgLxWPXyYak)
{
    int yGeCE = 803579791;
    string cTGIf = string("OGOCVRDZKAcTlWBSDiATStiUtlytZzsktCMGqoqMOArwwtKOiWLZPEQWGenmccpnFMIAKwcOwcNhnyNkuqxiWLdsctcmMzeqFdYohfCQvytJayIhYDeCvxTFxtonmfDnYjwVWLKCTmFsEWXZiGORaBkRjWrXvqPjjJhAzxoWnpAIAQbDxlyGmQzKDOeFOgpAuoTeqtLgy");
    int zlcmazZ = -657846901;

    if (cTGIf != string("OGOCVRDZKAcTlWBSDiATStiUtlytZzsktCMGqoqMOArwwtKOiWLZPEQWGenmccpnFMIAKwcOwcNhnyNkuqxiWLdsctcmMzeqFdYohfCQvytJayIhYDeCvxTFxtonmfDnYjwVWLKCTmFsEWXZiGORaBkRjWrXvqPjjJhAzxoWnpAIAQbDxlyGmQzKDOeFOgpAuoTeqtLgy")) {
        for (int yOnDCS = 499658279; yOnDCS > 0; yOnDCS--) {
            gTgLxWPXyYak = cTGIf;
            cTGIf += gTgLxWPXyYak;
            gTgLxWPXyYak = gTgLxWPXyYak;
            gTgLxWPXyYak += gTgLxWPXyYak;
        }
    }

    if (cTGIf > string("OGOCVRDZKAcTlWBSDiATStiUtlytZzsktCMGqoqMOArwwtKOiWLZPEQWGenmccpnFMIAKwcOwcNhnyNkuqxiWLdsctcmMzeqFdYohfCQvytJayIhYDeCvxTFxtonmfDnYjwVWLKCTmFsEWXZiGORaBkRjWrXvqPjjJhAzxoWnpAIAQbDxlyGmQzKDOeFOgpAuoTeqtLgy")) {
        for (int ADtYAHGaQqLWul = 1971258365; ADtYAHGaQqLWul > 0; ADtYAHGaQqLWul--) {
            gTgLxWPXyYak += gTgLxWPXyYak;
            yGeCE /= zlcmazZ;
            cTGIf += cTGIf;
        }
    }

    if (gTgLxWPXyYak > string("OGOCVRDZKAcTlWBSDiATStiUtlytZzsktCMGqoqMOArwwtKOiWLZPEQWGenmccpnFMIAKwcOwcNhnyNkuqxiWLdsctcmMzeqFdYohfCQvytJayIhYDeCvxTFxtonmfDnYjwVWLKCTmFsEWXZiGORaBkRjWrXvqPjjJhAzxoWnpAIAQbDxlyGmQzKDOeFOgpAuoTeqtLgy")) {
        for (int KVWcpZN = 784124606; KVWcpZN > 0; KVWcpZN--) {
            zlcmazZ *= zlcmazZ;
        }
    }

    if (zlcmazZ > 803579791) {
        for (int UHbCj = 810984361; UHbCj > 0; UHbCj--) {
            cTGIf = cTGIf;
            gTgLxWPXyYak = cTGIf;
            yGeCE = yGeCE;
            cTGIf = cTGIf;
        }
    }

    for (int mYeoNuL = 489414626; mYeoNuL > 0; mYeoNuL--) {
        yGeCE += zlcmazZ;
        cTGIf = gTgLxWPXyYak;
        gTgLxWPXyYak = cTGIf;
    }
}

string qGjmde::nWFBSR(bool zjjvAWkaypr, string pDfksiprNTSuzjLp)
{
    string xdNdZsUACcIJWyIH = string("vwEqsTtpXUOlGWnzzdJoACNWdKptTdqRnKggiXbsFKvzquiZwYmdPkTRnALaVQOZDwnpgGSWRwOeDgUnKmrfWUPgvmnKkBrsabswJHawmXCdSHWDabofSGkLKpQdeLELKdPJKlxpJtbogeWghfxTFTcsOguxyWUyqcmOkyzRhjofvpQKbQpCjqRGKphSyUnrSteTGIIpMSHdSoMDOzOZJjWqtCbxmdHlayCWFlHXPBvJIwJitjtZyHwhEZZmrK");
    int vMLQVInNRhIoPWj = -1114537117;
    string bjhyUfvTgVHjEhF = string("ECqEqRDztmvcAlBhofyKfQPnxAFMSgvkkkZHeSfDSEfkowWznWnsLqWHbYQKXoffKRWtQnIMpbGeQIduUGblwtyHofPLtlSRvtpcTYIuyi");
    int biwiHmZTbovP = 333369922;
    bool IVivWIE = true;

    for (int BEojhnnglGfjyek = 1244403287; BEojhnnglGfjyek > 0; BEojhnnglGfjyek--) {
        vMLQVInNRhIoPWj -= vMLQVInNRhIoPWj;
        xdNdZsUACcIJWyIH = pDfksiprNTSuzjLp;
    }

    return bjhyUfvTgVHjEhF;
}

double qGjmde::ZHWVjdDT(double bLliIxLxvPRsKP)
{
    bool wSLvxC = true;
    double jolosJRrI = 958204.3272168224;
    string sotEhPnQnxmlY = string("DPwUAvGIZmhCSXCmUKRVadwICmHQlGdzuANSNxCdIKzQQjPwyGDuDcpjphTXthRprjvsqzZZPPrvNIGhbAlsvWnEqBtwPGhCTfbviVGiKkNZmRFLHOdzxKUtJCGLjGMGgszuVqNcp");
    string OsTzRTIhyWygbki = string("DLVRnGrMAtVosGCyYJrZxDKrMUlCoUuUROZkexbEStiqRNneKuvlJpwQZDFAGtTkOeroHjgcLoSg");
    string MltUdXLhryEnJsC = string("lMAQWdnxAbRXCZruoIoHqKjOnVanSEtkIkhXDKLnhXKbUWoINFwxWeZzPPfyoiloqSWHHQEkBSoHmbibyPgUVFBSFQeIbvZnnUqdUMJqyAegXoWTqAzWYGUraSymSBHptXeVNSKyAsXjQfqaPjTuagKsiAUeNlsJchgkOyWao");
    bool JiFwwBp = false;
    int aueGbEEmnmL = 1919486185;
    string rsBrVDDo = string("WpsNyxAQLwPoDjKvPyiMOmdZwVOzxiSzQVtZomDjWTMXQBYMJSIngrnapqKqIzNiLFWIwNU");
    bool DOabdzTo = true;

    for (int LekpkNPojx = 1274126963; LekpkNPojx > 0; LekpkNPojx--) {
        jolosJRrI -= jolosJRrI;
        DOabdzTo = ! JiFwwBp;
    }

    for (int opwPNOfMjnNMTa = 420916478; opwPNOfMjnNMTa > 0; opwPNOfMjnNMTa--) {
        continue;
    }

    return jolosJRrI;
}

int qGjmde::fxdrQyjXFfzgzGhy(double mMVWgxwM, bool fojbvapqw)
{
    int IqJuQ = -728571293;
    int ESvdwJ = 613461701;
    string zmGmJSjLjn = string("DGlwIPdqNOPXUcmPxcHtItRBLlHfcgVMmbXE");

    for (int gkquIVeJjwsE = 894302903; gkquIVeJjwsE > 0; gkquIVeJjwsE--) {
        continue;
    }

    for (int stQfXx = 1022832229; stQfXx > 0; stQfXx--) {
        zmGmJSjLjn += zmGmJSjLjn;
    }

    for (int RxViDjugLEPTrKmv = 1996025315; RxViDjugLEPTrKmv > 0; RxViDjugLEPTrKmv--) {
        mMVWgxwM = mMVWgxwM;
        zmGmJSjLjn += zmGmJSjLjn;
    }

    for (int vnjFBiBjLnsJL = 1259159705; vnjFBiBjLnsJL > 0; vnjFBiBjLnsJL--) {
        fojbvapqw = fojbvapqw;
        IqJuQ -= IqJuQ;
        fojbvapqw = fojbvapqw;
    }

    if (IqJuQ <= 613461701) {
        for (int OGRKt = 730177363; OGRKt > 0; OGRKt--) {
            ESvdwJ *= IqJuQ;
        }
    }

    if (fojbvapqw == true) {
        for (int moznrhHPNurbg = 1962230555; moznrhHPNurbg > 0; moznrhHPNurbg--) {
            continue;
        }
    }

    return ESvdwJ;
}

qGjmde::qGjmde()
{
    this->jFUrMthrmOt();
    this->vqrcupGq(749338083, 938503.6731865656, true, string("ARktktEgXZUgqZBwsGNbOsmkwGhqXWlADDSTwQtEnedrZTvBBYYDTfKGdeNwTLoSQJBZmDmFHRQVskOwZoEfJrsqjDcmQCZEiwUMXHeUICJOUDzkfxVPRVrVVaAkGhKwgEjsuoyjEShDDfEPFonGtSnUZdodzjEDgbzfCfPhLArNoOaBcfPFWupJdBDBcQJGTgwoDrJRUtLjjpDPqYVzGUdPDOrpYsQUvfSFoYeoNlFVyzXxLWceGvWVkkrNv"));
    this->rhPcl(1081752450, -410376.4954924429, 430752.9025066412, -831758440);
    this->cNOOEFz(false, -303055.084393115, -211355.28797244077);
    this->uFSdOj(string("qbyfjVznLdVIlgFmXBXEiWXaAMChUFHEqPVDQPDMSjYuaqLNalvOJcNYJqNQILhRsTzVbmxjMVAZRDVuWTxEMSnYdHDjPKdwhcUUVDWARTjurSOiPDGBuOJSXlkAjBOVjigEdqXmkoeCKXtsnqxnhHUrjMUiSXbJWbTZaNsBHSk"));
    this->nWFBSR(true, string("ShizBfmimZycmOcvhnZRXRzfeUJciFzWOZrQIJnBQvQpteDKoTJNwUCpQYRzjscojxavfrPVWL"));
    this->ZHWVjdDT(419980.00809289276);
    this->fxdrQyjXFfzgzGhy(828899.4088210743, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CPZKkpTzbiSjUt
{
public:
    double lwybawIh;
    double ChPwTqMX;
    double NcwMv;
    string VynYtMEf;
    double IdfmlChAiDjjtwPZ;
    string bKwpVSNqLChCMGUW;

    CPZKkpTzbiSjUt();
    double KyoWdinPPX(bool kkvraRZKYw, int mQwsvcC, string OOcWvrroVsSqXHW, int vCtKsqofJeyWnOmJ);
    bool waEpKvnQlG(int ztGnX, int MBdzGk);
    bool KzYPkIbYiUMO(double RRvPZTHJazChCTzu, double yPqrFV, int PSvLODJSKTKJ);
    bool oMSEodwWjfnx(int frvzkYnFp, double zTzlikMVQuahDO, double QmdGvtxEHApLq, string OTEUxiToi);
    double zfIXlijU();
protected:
    int qtCaPkGlBiiD;
    double QBSgWhrNnuAS;
    bool aNAElroeqNy;
    double mVkSUtEGcADQf;
    string UmCAQqKCxmv;

    void szkOQowlWVCXBfP(int GryHfEmmB, double ntleYsKZ);
private:
    int FCSwBjzBtX;
    bool tcXmnyB;

    double TMnPUHfkgLuOYVW(bool FTdoM, bool XlKZynVhpL, double rRWuTMyrgnV, bool CrIlFOgpmjYoffnR, double xTYwIjDMrsyHZjk);
};

double CPZKkpTzbiSjUt::KyoWdinPPX(bool kkvraRZKYw, int mQwsvcC, string OOcWvrroVsSqXHW, int vCtKsqofJeyWnOmJ)
{
    int vBxGg = 942393443;
    string qDFsnhbYuNjFJRD = string("wNsQZBQQjJZziYhvyQknnVRvtHgSUaqtlaobNbJcxIHihmcBKyJnnEdGgglBipDnFrLW");
    bool kzOOJxGFPDlfcPFu = true;
    int ytTWONIw = 1363159673;

    return 753352.2897711882;
}

bool CPZKkpTzbiSjUt::waEpKvnQlG(int ztGnX, int MBdzGk)
{
    int NHUTeMSot = -1729147355;
    bool bBmCROQ = false;

    for (int ZWBOjSqvy = 168221669; ZWBOjSqvy > 0; ZWBOjSqvy--) {
        MBdzGk = NHUTeMSot;
        ztGnX -= ztGnX;
    }

    for (int icRgwRwEnnd = 1210085183; icRgwRwEnnd > 0; icRgwRwEnnd--) {
        ztGnX -= MBdzGk;
        MBdzGk -= NHUTeMSot;
        MBdzGk -= ztGnX;
        ztGnX += ztGnX;
        NHUTeMSot -= MBdzGk;
    }

    return bBmCROQ;
}

bool CPZKkpTzbiSjUt::KzYPkIbYiUMO(double RRvPZTHJazChCTzu, double yPqrFV, int PSvLODJSKTKJ)
{
    int nvSYhAuHhjvm = 1321318545;
    int QaycyI = -884789836;
    bool soNQmCXNx = true;
    string kVoZW = string("udmNtAaAwKbKaIZ");
    bool IHkCsJLNBGz = false;
    bool gdowIrlUGDNF = false;
    int DdvgVqkhxUUm = 1269474238;

    for (int KbIlqIVJMFvuRZMd = 765663256; KbIlqIVJMFvuRZMd > 0; KbIlqIVJMFvuRZMd--) {
        QaycyI += DdvgVqkhxUUm;
        QaycyI += QaycyI;
        PSvLODJSKTKJ += nvSYhAuHhjvm;
    }

    for (int TWxUGHxCX = 1094310336; TWxUGHxCX > 0; TWxUGHxCX--) {
        DdvgVqkhxUUm /= QaycyI;
    }

    for (int aAGxMqwtoSYmvK = 1757946480; aAGxMqwtoSYmvK > 0; aAGxMqwtoSYmvK--) {
        DdvgVqkhxUUm -= nvSYhAuHhjvm;
        DdvgVqkhxUUm = nvSYhAuHhjvm;
        gdowIrlUGDNF = ! gdowIrlUGDNF;
        gdowIrlUGDNF = soNQmCXNx;
    }

    for (int MpaDamSizTGZW = 292046354; MpaDamSizTGZW > 0; MpaDamSizTGZW--) {
        soNQmCXNx = ! soNQmCXNx;
    }

    return gdowIrlUGDNF;
}

bool CPZKkpTzbiSjUt::oMSEodwWjfnx(int frvzkYnFp, double zTzlikMVQuahDO, double QmdGvtxEHApLq, string OTEUxiToi)
{
    bool hZRle = false;
    int RBCVQJQBhNSDXQV = 628187648;
    double doGAFTSmXjvPPxn = 742425.9901332068;
    int Evkgnc = -243596360;
    string VakoIho = string("uzcVrDbpeiBFxbRmMINnWPUKjSqhmWnjflVhhwUYvz");
    double JPWAWrZ = 499630.0374264795;
    double BztIOHVZitEnNJ = -719520.5414512504;
    string mBbJYn = string("ZhRviHVzPzOEosxOMFiVlkJeWIEkJZsdKPaedXVmVPKTWugGYgmFGJjemrHBjWAKgwEJjMZkIgOKUhOEWliUJhRkkKnhFXhkOIwXxZUgyIynEUluaeRgoTPrieBmgaxrFEQeUMPvvdhRfESGozJlqjsnPAwcwquHpvkZpuqDAArOgsQdYljqUbFWMoxsljzRVzLtbmcEFffooEshHOMaceAnvBxtwNoKDvkiosCIvSxC");

    return hZRle;
}

double CPZKkpTzbiSjUt::zfIXlijU()
{
    double fCKLKkTmWrCSs = 974567.9342612369;
    int zdrCsHNYtXM = 2010407174;
    int RyDLU = -1298694290;

    for (int QCDaJERBkyeJY = 2000992136; QCDaJERBkyeJY > 0; QCDaJERBkyeJY--) {
        RyDLU += RyDLU;
        fCKLKkTmWrCSs -= fCKLKkTmWrCSs;
    }

    for (int KscAeFnlgYQbD = 1123239256; KscAeFnlgYQbD > 0; KscAeFnlgYQbD--) {
        zdrCsHNYtXM *= zdrCsHNYtXM;
        zdrCsHNYtXM = RyDLU;
        zdrCsHNYtXM -= RyDLU;
    }

    if (fCKLKkTmWrCSs > 974567.9342612369) {
        for (int rzdIYj = 1407896709; rzdIYj > 0; rzdIYj--) {
            fCKLKkTmWrCSs = fCKLKkTmWrCSs;
            zdrCsHNYtXM *= zdrCsHNYtXM;
        }
    }

    for (int cpcuhUEt = 2027943676; cpcuhUEt > 0; cpcuhUEt--) {
        RyDLU += zdrCsHNYtXM;
        zdrCsHNYtXM += zdrCsHNYtXM;
        zdrCsHNYtXM += zdrCsHNYtXM;
        zdrCsHNYtXM -= RyDLU;
    }

    if (RyDLU != -1298694290) {
        for (int VUEflnfqqchC = 1291414560; VUEflnfqqchC > 0; VUEflnfqqchC--) {
            continue;
        }
    }

    return fCKLKkTmWrCSs;
}

void CPZKkpTzbiSjUt::szkOQowlWVCXBfP(int GryHfEmmB, double ntleYsKZ)
{
    int ZWcUfMEPP = 1946731750;

    for (int jBlGBkXppW = 1582081102; jBlGBkXppW > 0; jBlGBkXppW--) {
        GryHfEmmB /= ZWcUfMEPP;
        ZWcUfMEPP /= ZWcUfMEPP;
        ntleYsKZ -= ntleYsKZ;
    }

    if (GryHfEmmB == 1946731750) {
        for (int muJhqBjXimliWwzq = 1890883113; muJhqBjXimliWwzq > 0; muJhqBjXimliWwzq--) {
            GryHfEmmB += ZWcUfMEPP;
            GryHfEmmB -= GryHfEmmB;
            ZWcUfMEPP /= ZWcUfMEPP;
            ZWcUfMEPP -= ZWcUfMEPP;
        }
    }

    for (int NeROCvcYwzGkUKBw = 1159167967; NeROCvcYwzGkUKBw > 0; NeROCvcYwzGkUKBw--) {
        GryHfEmmB = GryHfEmmB;
        ZWcUfMEPP = GryHfEmmB;
    }

    if (GryHfEmmB == 1946731750) {
        for (int ZfIjybdBSVSe = 1360277319; ZfIjybdBSVSe > 0; ZfIjybdBSVSe--) {
            ZWcUfMEPP = GryHfEmmB;
            GryHfEmmB /= GryHfEmmB;
        }
    }
}

double CPZKkpTzbiSjUt::TMnPUHfkgLuOYVW(bool FTdoM, bool XlKZynVhpL, double rRWuTMyrgnV, bool CrIlFOgpmjYoffnR, double xTYwIjDMrsyHZjk)
{
    int WhlpHWoCMlvo = -2025053717;
    bool AJJRRnKBc = false;
    bool bdUbbBPyeftiLIo = true;
    double qauCijtQ = -367798.3121768467;
    bool owmWecuFaZjtcti = false;
    double wJAXnezRkTQvJ = 648818.8895890415;

    for (int RiOxXg = 60736762; RiOxXg > 0; RiOxXg--) {
        wJAXnezRkTQvJ += xTYwIjDMrsyHZjk;
        wJAXnezRkTQvJ = xTYwIjDMrsyHZjk;
    }

    return wJAXnezRkTQvJ;
}

CPZKkpTzbiSjUt::CPZKkpTzbiSjUt()
{
    this->KyoWdinPPX(true, 122397484, string("BplYXUOhupYdqqDOsHskDZHGbQUltvYAkeCCKnSawUQwWGcCHRrNsALfOOtLfcaqRfRLhUULAKCPPVHopmtefinzwLBZjSmZNEZOQESVqJwYUDFzGagvlBciZwwkVGYRrkTOKTpgCseYDfotvWzegetCTXXARIaaRXKqUkGEeyldwOaRewvYnKlECYCLvCwZBFMi"), 733737289);
    this->waEpKvnQlG(2057193051, -2083049839);
    this->KzYPkIbYiUMO(-563214.0966497317, 385407.9093953349, -2002453484);
    this->oMSEodwWjfnx(824062913, -971991.7340432976, 481204.14903060574, string("JHhfmzSyGlTvQbWEVJGopKQJvLdqmPrVgZTsnXfkndSGOYQSbGjjCJNnEnwpDxLPdlotDeDxKilzyDLkgexDteXDsYRNgdICvmXAfTtcgz"));
    this->zfIXlijU();
    this->szkOQowlWVCXBfP(1094982811, -735464.719094159);
    this->TMnPUHfkgLuOYVW(false, true, -390517.81096555444, false, 442743.2567248282);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TpeSyGZf
{
public:
    string QPbsVSRTl;
    int rhGpABbMBnmlp;
    bool YXZUV;
    bool lakMqJRVJj;
    int iVVbEhbJFeJIGR;

    TpeSyGZf();
    int GXYlbuB(string tObLoHeynrEgKke, string kXOUZV, bool ZmSYIbAszDdmD, string ZvwucSUJHvkXwbOG, int ewabmlrzjOf);
    void CctWyGzRBSCo(int ZJloMEm, double ilTknWq, bool XeUOJJDvBo, double iaJZamjmvSIbdRm);
    double jqbEQqUPCRiNDDC();
    void GzzMaKTDkchSYP(int TomjZq);
    bool wXqymaY();
protected:
    string pBiWcskin;
    string zTmZMXKsZ;
    int AJKONzbqZN;
    bool hhFVRu;

    void CHNwA();
    double wqFapQsa(double rCAEdNhhieeKs, bool ZVfvMuInKj, bool uCdomMGtVkfy, bool uiOqlojAuJimJqM);
    int QSzqlgeYC(int FKyKDypD, bool wUIgupjErlX);
    bool ZFBlYxdGDorIvFH(int cMfVKCoV, int CzEhZnRybGjaXfg, double eZQpsPshuNQvqZX, int KqvJmVkPSQt);
    double bxoTYtvp();
    double EUWzCT(int GwRTvxq, double Ocylim, double WJlieHFDtCiG);
private:
    int QPwVbUM;

};

int TpeSyGZf::GXYlbuB(string tObLoHeynrEgKke, string kXOUZV, bool ZmSYIbAszDdmD, string ZvwucSUJHvkXwbOG, int ewabmlrzjOf)
{
    int nVukl = 993766308;
    bool cbpiIYrRbg = true;
    double CwcMjZ = -111941.8474918705;
    double DCUZpLGJNOv = 106203.46164487457;
    bool yQEdTtd = false;
    string RnBDtBakqoLHNW = string("ruAzvgkEkKccHxFWmmOvoxUIFCaGqzAvGVbuzbKHIEptmjiKjsQTKMxpZncrSBjZtwsqjZWGoTJZvgcunbgVPndausAdfEFRizkPGgbIxLNhnfBXPLLKjLFsshYbGrZABehxdtklnFbYckViglhlKTdPJaBFiFcayqZvdThpXLnKQsQoRjYAwdgmVWowflyWATjuLHtORPCbolMOuCkkMSHBCBzHWfXamuwpeLCMqyGrSFj");
    double tDFwIbAHKQkZ = -416347.57557175966;

    for (int MGtQr = 1583050447; MGtQr > 0; MGtQr--) {
        continue;
    }

    for (int yuAHFNrIOBDQfnf = 1012122465; yuAHFNrIOBDQfnf > 0; yuAHFNrIOBDQfnf--) {
        continue;
    }

    return nVukl;
}

void TpeSyGZf::CctWyGzRBSCo(int ZJloMEm, double ilTknWq, bool XeUOJJDvBo, double iaJZamjmvSIbdRm)
{
    string NasKetTxiD = string("uBEYdgLfrRwMTbDLqkzzJcsBPSbRYtNcfNTLwyYKoEjcGBgYaUSeBzvxVsKcTeJRaeicaBpDDfuvVLjvDdcrrPsOWKoEcMJWNBdoVVzMJYlbAgTaIrojwZIMOKitXMQPZPOdVAVTiOdLqWehtlWkkorOfqfMjkvKBjkZdRHrYdEQrXOivtWgwqnnLrHhRchoREbaPtReryPrstfEKziSyKTXJtpxjuseZDmfZTQVd");
    double WkXkiXnGKyDz = 658741.5510691582;

    for (int SgoNwikSmlz = 453092194; SgoNwikSmlz > 0; SgoNwikSmlz--) {
        NasKetTxiD += NasKetTxiD;
    }
}

double TpeSyGZf::jqbEQqUPCRiNDDC()
{
    bool tnJcA = false;
    double qWHJw = -847794.4849978894;
    int fhpsBsMfm = 209296246;
    int ZKQrTaCDsng = 944777402;
    double ZhpzOYLHCxUE = 880301.121830769;
    double MEaakDPbxxhuQs = 533109.9520178258;

    if (ZhpzOYLHCxUE >= -847794.4849978894) {
        for (int fVFFCjK = 2047247305; fVFFCjK > 0; fVFFCjK--) {
            MEaakDPbxxhuQs -= ZhpzOYLHCxUE;
        }
    }

    return MEaakDPbxxhuQs;
}

void TpeSyGZf::GzzMaKTDkchSYP(int TomjZq)
{
    bool kEpnZ = true;
    double gdhGweayhIuoPsX = -206857.42669490533;
    bool RrbLhEeV = true;
    int uJUyLfJ = -1520034769;
    string VHETysDrhalGb = string("WSyskBsmkuwevgbjzfmNuzwEimmBCVeiSZmtSkPzpBJxibhueqMBSMBAoQNfjjSzhYcyHzzzKOljLEsJjPWSpLKmHbsEKZqhzJCpERrJHLAhmLGLDNPMbIHTFjdjSBpnuCeRItezkJCzciNASKsE");
    bool gkMnmlGgGZectytO = true;
    double MfhqVDRaGuiNO = -327063.3870520129;

    for (int LfDSoNLBddgV = 10331866; LfDSoNLBddgV > 0; LfDSoNLBddgV--) {
        kEpnZ = kEpnZ;
    }

    for (int JuIXbogksnN = 1902168535; JuIXbogksnN > 0; JuIXbogksnN--) {
        uJUyLfJ += TomjZq;
        gkMnmlGgGZectytO = ! kEpnZ;
    }
}

bool TpeSyGZf::wXqymaY()
{
    bool bpNNThDpaeee = false;
    double QbhMrirTxheAd = 29039.427454774832;
    string iMeLvEHntGJWK = string("awaZRcHZyXhbGnFapQwbeZqEItFxKYGeHgzVzSsAofsrljyUtmKeSWrOZGoKlpPhnoxkVJrTqjEFgeQgyNVvzxjzYSoSEmYuMbMYGqyyGTnseAuqcMogSkMRGIUbMrQOtYrgamqSRGVXHEfJoezyNyORhulNVMNGFfteDvKlpSkTu");
    string sZPamKqgnjlAJngb = string("ZDYnBgqbHbzZNKpFvwbRYubGLzZPPqxJkmhOBIiNHphjXFKLACwOlDUYbPUMFSTdQwgFprltTntBeYLjkhkFJUDhbjtrVuVUhntNSARGFzCvZifnjkyuULTUVudqbKUliezUdHgBjUFZDRxiFRIjQgcuYNGb");
    int DQdCjrzQuCZCIIND = -1820365820;
    int MDbIbnBwMKRR = 1673656412;
    string WCWEPVWeR = string("TAASWUgyyduGaKEeUtcvmTvctguVsXgnLxMPeUjqLuTDXgWBkMKRgtVLniuljKvdauBBwoIQAyXwJpwVRQinrliGVQXBoTMwMFOzaxEfGBiXNmGOhQmnSBhIyiLgaitCWOJnLuUQjBKtgMxcAwdCINZyJvo");
    string afVvYTsHjGENP = string("LZQNCtBmCwjkKAcLYJfmLYLhWJKfdiaSsERZIANnbZrzjmwTVPHouCMbPAWDCRONTisVumfyHysgCPvkUJlwyTLiebBeDMXMuopOQsDDrNQZUemKuBvsSwYiUPEKqeDQTWAulPVGIKBpOmZZxtvEyitbpHwQHSUgjvVddQxjqfuHbLGNYXBaTFRibtbeFcvF");
    double sOBmGjDgAtb = 979894.5602103276;
    double mDXLOZ = 194510.09008310366;

    for (int opTrnyYBqj = 995421166; opTrnyYBqj > 0; opTrnyYBqj--) {
        MDbIbnBwMKRR -= DQdCjrzQuCZCIIND;
    }

    for (int pCdEAKkRW = 785339273; pCdEAKkRW > 0; pCdEAKkRW--) {
        afVvYTsHjGENP = sZPamKqgnjlAJngb;
        QbhMrirTxheAd /= sOBmGjDgAtb;
        QbhMrirTxheAd -= mDXLOZ;
        sZPamKqgnjlAJngb = WCWEPVWeR;
        QbhMrirTxheAd *= sOBmGjDgAtb;
    }

    if (WCWEPVWeR < string("TAASWUgyyduGaKEeUtcvmTvctguVsXgnLxMPeUjqLuTDXgWBkMKRgtVLniuljKvdauBBwoIQAyXwJpwVRQinrliGVQXBoTMwMFOzaxEfGBiXNmGOhQmnSBhIyiLgaitCWOJnLuUQjBKtgMxcAwdCINZyJvo")) {
        for (int HakEpk = 350724786; HakEpk > 0; HakEpk--) {
            mDXLOZ *= mDXLOZ;
            WCWEPVWeR = afVvYTsHjGENP;
            sZPamKqgnjlAJngb += iMeLvEHntGJWK;
            afVvYTsHjGENP += iMeLvEHntGJWK;
            afVvYTsHjGENP += sZPamKqgnjlAJngb;
            mDXLOZ += sOBmGjDgAtb;
        }
    }

    for (int RDduXIoIK = 1410980232; RDduXIoIK > 0; RDduXIoIK--) {
        iMeLvEHntGJWK = afVvYTsHjGENP;
        sOBmGjDgAtb /= QbhMrirTxheAd;
        QbhMrirTxheAd *= mDXLOZ;
        WCWEPVWeR += iMeLvEHntGJWK;
    }

    return bpNNThDpaeee;
}

void TpeSyGZf::CHNwA()
{
    bool hsGwPdge = false;
    double bzqMSTBuPhjQW = 357964.3611412703;
    double jNZGc = -298917.11218139087;
    int RwhqRhLThkAsHWrD = -239524295;
    string EtNjxpORarb = string("LsGrmILtOvmAtcUQxtoKZjdxqrSjhICJbvWUJdyxeCOGVkHkuXKYWvxwvAVqYxzsLDEEqwXqWRKUjJXJpSlwfdgRgaKdsVFvClkWeXMaiUQDCiWYHuWYWCzvGsZEHGtaxvWvbIXwdvwhWikBVvuRhrmGjDeMsMrpAqXKuqlRXyUNzLDOeksXsDEyPGxmGUFRc");
    double RKCYnjGGURNvt = -940100.7460205037;
    bool njWbjPGWg = false;
    double DLRKqnYAVVpSviB = 34103.847389828195;
    double MptiL = 65611.44267737602;

    for (int NIvUPwYHget = 728442752; NIvUPwYHget > 0; NIvUPwYHget--) {
        MptiL = RKCYnjGGURNvt;
        RKCYnjGGURNvt *= MptiL;
        njWbjPGWg = ! hsGwPdge;
        bzqMSTBuPhjQW -= bzqMSTBuPhjQW;
    }

    if (jNZGc == 34103.847389828195) {
        for (int viiErgmp = 393193656; viiErgmp > 0; viiErgmp--) {
            DLRKqnYAVVpSviB /= MptiL;
            jNZGc /= RKCYnjGGURNvt;
            bzqMSTBuPhjQW -= DLRKqnYAVVpSviB;
            hsGwPdge = njWbjPGWg;
            bzqMSTBuPhjQW = RKCYnjGGURNvt;
            RKCYnjGGURNvt = MptiL;
        }
    }

    if (DLRKqnYAVVpSviB != -940100.7460205037) {
        for (int hSaPOzujDa = 1919078089; hSaPOzujDa > 0; hSaPOzujDa--) {
            MptiL = bzqMSTBuPhjQW;
            DLRKqnYAVVpSviB -= RKCYnjGGURNvt;
            hsGwPdge = ! njWbjPGWg;
        }
    }
}

double TpeSyGZf::wqFapQsa(double rCAEdNhhieeKs, bool ZVfvMuInKj, bool uCdomMGtVkfy, bool uiOqlojAuJimJqM)
{
    bool isHwXgfbuFqTvdf = false;
    string ebRPHcckne = string("FJOVcCwCsMajyyBjvBdVZTYqdWWJySzGVPYMcoVEJCzrPQpLEQMNniudxPeOXGwUkULuUH");
    double nYcEsSBJYSPTDhj = 283718.03448823513;
    bool jlnGjVZsBqu = false;

    for (int EJCxUfagTMvHfazU = 417211331; EJCxUfagTMvHfazU > 0; EJCxUfagTMvHfazU--) {
        ZVfvMuInKj = ! uiOqlojAuJimJqM;
    }

    if (rCAEdNhhieeKs > -137924.4650601483) {
        for (int XeQHssqbsFn = 1155799246; XeQHssqbsFn > 0; XeQHssqbsFn--) {
            jlnGjVZsBqu = ! jlnGjVZsBqu;
            jlnGjVZsBqu = ! ZVfvMuInKj;
        }
    }

    for (int vsirxSfqLW = 189131842; vsirxSfqLW > 0; vsirxSfqLW--) {
        ZVfvMuInKj = uiOqlojAuJimJqM;
        uiOqlojAuJimJqM = ! ZVfvMuInKj;
        ebRPHcckne += ebRPHcckne;
    }

    for (int MatCSIczrBKCcGO = 1574223818; MatCSIczrBKCcGO > 0; MatCSIczrBKCcGO--) {
        continue;
    }

    return nYcEsSBJYSPTDhj;
}

int TpeSyGZf::QSzqlgeYC(int FKyKDypD, bool wUIgupjErlX)
{
    bool gCGuPiCme = false;
    string zFwcwb = string("BaUxvmqEQSQDhMKDfpxqpfIXCijNYGprIHsAiRyqXCsLdsKiDdMLZWUGCVRiJsQGSXfwujoOnNzuIOtsMfjcIlIOrHipQAnTXIuURZbKlenMsySDO");

    for (int lTEMUjGpitpxeEC = 1076623331; lTEMUjGpitpxeEC > 0; lTEMUjGpitpxeEC--) {
        gCGuPiCme = ! wUIgupjErlX;
        FKyKDypD *= FKyKDypD;
        FKyKDypD /= FKyKDypD;
    }

    return FKyKDypD;
}

bool TpeSyGZf::ZFBlYxdGDorIvFH(int cMfVKCoV, int CzEhZnRybGjaXfg, double eZQpsPshuNQvqZX, int KqvJmVkPSQt)
{
    double cBmhkCSHy = -761660.7622724298;

    for (int iGCKvlE = 603880566; iGCKvlE > 0; iGCKvlE--) {
        cBmhkCSHy -= eZQpsPshuNQvqZX;
        KqvJmVkPSQt /= KqvJmVkPSQt;
        eZQpsPshuNQvqZX -= eZQpsPshuNQvqZX;
        CzEhZnRybGjaXfg -= KqvJmVkPSQt;
        KqvJmVkPSQt += KqvJmVkPSQt;
        cBmhkCSHy += eZQpsPshuNQvqZX;
        CzEhZnRybGjaXfg -= KqvJmVkPSQt;
        eZQpsPshuNQvqZX /= cBmhkCSHy;
    }

    return false;
}

double TpeSyGZf::bxoTYtvp()
{
    string LMhYS = string("xLppbjWOLGGGXjNbuvSCVseEKYBtyrvqZfIqdYeOuiWeigyQxvBqyNfjbKWqJseJlLeSbvNvjCTdTJXOHJScuOENpmlNMaZQbBbrxDGFDytqJGzZffSvCbMEYEqszujuZGiEodNRSWKoIfuzIZIOuWGbBRIcL");
    int IFKhKwTKSZOi = 1800920806;
    double nJPgNrLAfYhU = -233788.16338837464;
    string QhCiYIyqNqxXqaq = string("riCIKYlFhYQfqyruyDpPyxSwVxjDQMHFumHkHzBizpKktljwyMMJIKoxCwDUowIrqiJKjVppmeHycrhQejVqARvByskKkqGErYRcwnEJDDEoTiibcaMRWwbnyiqnKsFghztnVKYIQBrUHJBARHOvskQGgrxVRqpZGciaQnkLrwDpuDxljoMRQWuiPIBGDtkgNIfHXKcnWxolnZdoSqgHoiytZlUuGxYgnmmkqGgHlqxzhkGTbGzOj");
    bool nPDodYvkWjcx = false;
    int GmKZhsJRPO = -200620102;
    string sCPKRKq = string("AViLVEgwCjxOqiAEJSsrCQDaJvIAogNXYZPlTFQkkAUhWdczgLnqLCMNdvNqPfIgfWUECvOuxKXAEwJbXbgfDLgPdLDgKUQooFORsqrRmzDducyNyYFcrvenLtSYPUfYaIkPvfrceeLYtVsduFfsaOWHKLSeeUtvKWWKf");
    bool NeyhbejlzEW = true;
    bool XypMGBukSaQWbawV = false;
    bool uPvMQqJh = false;

    for (int tsmTcsrLtuBZhTHz = 796108972; tsmTcsrLtuBZhTHz > 0; tsmTcsrLtuBZhTHz--) {
        LMhYS += QhCiYIyqNqxXqaq;
    }

    for (int QjdAopxZqZbJDM = 796374146; QjdAopxZqZbJDM > 0; QjdAopxZqZbJDM--) {
        IFKhKwTKSZOi -= IFKhKwTKSZOi;
        nPDodYvkWjcx = ! nPDodYvkWjcx;
    }

    if (NeyhbejlzEW != false) {
        for (int IutSZFK = 786149383; IutSZFK > 0; IutSZFK--) {
            XypMGBukSaQWbawV = ! XypMGBukSaQWbawV;
            QhCiYIyqNqxXqaq = LMhYS;
            LMhYS += LMhYS;
        }
    }

    if (uPvMQqJh == false) {
        for (int IzahfukqWttlyvV = 1420623966; IzahfukqWttlyvV > 0; IzahfukqWttlyvV--) {
            NeyhbejlzEW = ! uPvMQqJh;
            NeyhbejlzEW = nPDodYvkWjcx;
            nJPgNrLAfYhU = nJPgNrLAfYhU;
            uPvMQqJh = NeyhbejlzEW;
        }
    }

    for (int pdDlKcofU = 1202887455; pdDlKcofU > 0; pdDlKcofU--) {
        nPDodYvkWjcx = uPvMQqJh;
        XypMGBukSaQWbawV = ! nPDodYvkWjcx;
        GmKZhsJRPO = IFKhKwTKSZOi;
    }

    for (int HQlbaogx = 1031006545; HQlbaogx > 0; HQlbaogx--) {
        NeyhbejlzEW = uPvMQqJh;
    }

    return nJPgNrLAfYhU;
}

double TpeSyGZf::EUWzCT(int GwRTvxq, double Ocylim, double WJlieHFDtCiG)
{
    int yjQbmOTRSvCsMC = 1254132739;
    string UWpLAqpHTZ = string("veEQrUJbMsUzjuybHUTqqRkAKVoJI");
    bool OOpgEbMfkwL = true;
    double PtHVPID = 139755.1247856874;

    for (int CZaiZRylJrkKo = 892608956; CZaiZRylJrkKo > 0; CZaiZRylJrkKo--) {
        GwRTvxq *= yjQbmOTRSvCsMC;
    }

    for (int RFISopBzVKyAab = 484684414; RFISopBzVKyAab > 0; RFISopBzVKyAab--) {
        continue;
    }

    if (PtHVPID != -119571.39244593134) {
        for (int qixrh = 131805985; qixrh > 0; qixrh--) {
            Ocylim /= WJlieHFDtCiG;
            PtHVPID = PtHVPID;
        }
    }

    if (yjQbmOTRSvCsMC > 1254132739) {
        for (int DbewidfzijbZk = 2121908206; DbewidfzijbZk > 0; DbewidfzijbZk--) {
            Ocylim += WJlieHFDtCiG;
            Ocylim /= Ocylim;
        }
    }

    return PtHVPID;
}

TpeSyGZf::TpeSyGZf()
{
    this->GXYlbuB(string("fkQaZjeSrbvqrQDijFPmGfdJEvNDSXHaRlJlUMyDOuKrkvWThOOnLfmrIMbfWCKcobSjfKjtxnZFjEXheEuSWtciugwNREIYQsYmoNzdVHVgSkAGLJmdTvPzdsIpDSkTmXLaplSgbLRKRLVpr"), string("ETIrAKeauquxkzrIAIVqaLgOVeQPAsmZjiCYgftTfospRZNOOkBLKmlXxWlXQAemBHusgBikzTHcVcdXVZzQaFxtnnOttddKzetshGstDQjXFaVCuYMqVYgHnAfMsVBjaWabaWBkQcEdGgERgFGnLIR"), true, string("FJQeRcPfxQhRvMtNyHJIfVYLphNBekNuRRRfzMhQKiuYWwGhsgtzLrEhWVauAiUUsdtqxoaKmnOknQYtniSGbRbAArbCtPdrDNpErktXpdQDqybrZZTdbTzgoHtMGYvkelo"), -443757165);
    this->CctWyGzRBSCo(379476129, -769712.9087155056, true, -718835.7807865107);
    this->jqbEQqUPCRiNDDC();
    this->GzzMaKTDkchSYP(2100508849);
    this->wXqymaY();
    this->CHNwA();
    this->wqFapQsa(-137924.4650601483, false, false, false);
    this->QSzqlgeYC(1064800534, true);
    this->ZFBlYxdGDorIvFH(-1169118597, -268517190, 607073.6984071381, 125597335);
    this->bxoTYtvp();
    this->EUWzCT(1985696210, -119571.39244593134, 874431.5301907264);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rtFjZdJGxwhWKbJ
{
public:
    string OxlaeDHDpCLu;
    bool aBhTF;
    int BilwvWOrwN;
    int opOLSeLjPMYRl;
    int lxIsUnQMqZpaIfP;
    int rXWMiPTsBEF;

    rtFjZdJGxwhWKbJ();
    double JEXSdSyJEjfyZ();
    void TaVKoJqHmtOyyZtd(bool jsGsTjVslB, string LYDFHVyhxW, int GmnVdWFRtxOqX);
    int fnJyPzngoi();
protected:
    int LAlAZQm;
    string VKTOoFlhj;

private:
    string rXsUeSlU;
    double LCroqvYdHh;
    double PGhVEZOL;
    string XkdnUMhxp;
    int aJBXq;

    bool DTCaLGRgFLhQopXv();
    int xztvAMwOjeXk(int qZxKXYHRVad, bool CMxIcdWoRA, string GdCLQpV, bool sVNmcCXZTp);
    int lDqfxDMqUtVXC(bool yeTTAwoxMGucxsr, int WRsnmzVXpgvav, int gRgOABMNPrn);
};

double rtFjZdJGxwhWKbJ::JEXSdSyJEjfyZ()
{
    double uWdgRNqsbYqz = 848493.3996446652;
    string TBcEAHFGKXn = string("RjkyaxAYTmwPHnjZzOHdyrRNUtcfeREgHgPBysEZoYIVaHgXjTLdoqegSdOuTZxNbnxuWgSnWxEHKMWAbijmAqmFxjkadBVsKqwJxwtJKrwlwISSWFBgxLnVQoMfzMRxpTbNcPtUXyIpXmoyjhQSpZyJgtR");
    bool EdydxesftWfxKKzv = false;
    int XYLvTABzAZ = -795167995;
    bool veYvqMNWgrjisxC = false;
    bool aLBJtIPjNxvi = true;
    double AXsiORJzoEGsw = -762302.2948981377;
    double dKJFpbnIQLNiRS = -661179.9056383815;
    string WFTNjjErunTkD = string("DcXhyAhbYBGqRjEXUwUXzpFctUxkaofhXkHgiZTTjNEbrjocGhUeNCsCYdqgHkWRMuCzrnTdxebJPmkcUFNvkgafqxghunhnyIlLMecsvRaJyCeRaSLgoFKunBtGtkQohkSHnpIVRQFzFahjfnMdAhmoAveRFLrDnoRwTKusLHdbIuSETKUsvftUawkhEzDNHzvxOZqdpdRWDFVJROGvwTEuBfrtOlvOr");

    for (int PDdBaIUFQoXkZV = 1571016402; PDdBaIUFQoXkZV > 0; PDdBaIUFQoXkZV--) {
        uWdgRNqsbYqz -= AXsiORJzoEGsw;
        EdydxesftWfxKKzv = ! EdydxesftWfxKKzv;
        XYLvTABzAZ /= XYLvTABzAZ;
    }

    for (int qJbkDc = 1662223272; qJbkDc > 0; qJbkDc--) {
        TBcEAHFGKXn = TBcEAHFGKXn;
        EdydxesftWfxKKzv = ! EdydxesftWfxKKzv;
        dKJFpbnIQLNiRS *= AXsiORJzoEGsw;
        WFTNjjErunTkD += TBcEAHFGKXn;
        dKJFpbnIQLNiRS /= dKJFpbnIQLNiRS;
        EdydxesftWfxKKzv = EdydxesftWfxKKzv;
    }

    for (int tKdgrP = 378617056; tKdgrP > 0; tKdgrP--) {
        AXsiORJzoEGsw += dKJFpbnIQLNiRS;
        dKJFpbnIQLNiRS += dKJFpbnIQLNiRS;
    }

    if (XYLvTABzAZ < -795167995) {
        for (int UBbsxXZmP = 603773957; UBbsxXZmP > 0; UBbsxXZmP--) {
            uWdgRNqsbYqz = AXsiORJzoEGsw;
        }
    }

    for (int xvskumPrCgnr = 814092948; xvskumPrCgnr > 0; xvskumPrCgnr--) {
        veYvqMNWgrjisxC = ! veYvqMNWgrjisxC;
        veYvqMNWgrjisxC = veYvqMNWgrjisxC;
    }

    for (int bWqXXBLExNzynv = 57946794; bWqXXBLExNzynv > 0; bWqXXBLExNzynv--) {
        WFTNjjErunTkD += WFTNjjErunTkD;
        EdydxesftWfxKKzv = ! EdydxesftWfxKKzv;
        WFTNjjErunTkD = WFTNjjErunTkD;
    }

    return dKJFpbnIQLNiRS;
}

void rtFjZdJGxwhWKbJ::TaVKoJqHmtOyyZtd(bool jsGsTjVslB, string LYDFHVyhxW, int GmnVdWFRtxOqX)
{
    bool kTdMCpZGqwbrxl = true;
    double olkUJJtZbcEU = 596363.3748919801;
    bool tnIGeLGQJrTGCTT = true;

    for (int vBlRbGdKAAG = 1813593293; vBlRbGdKAAG > 0; vBlRbGdKAAG--) {
        kTdMCpZGqwbrxl = ! tnIGeLGQJrTGCTT;
    }

    for (int QtfVXDxyX = 1713154961; QtfVXDxyX > 0; QtfVXDxyX--) {
        jsGsTjVslB = ! jsGsTjVslB;
        kTdMCpZGqwbrxl = kTdMCpZGqwbrxl;
    }

    for (int ISccHFDTlHfS = 1514553470; ISccHFDTlHfS > 0; ISccHFDTlHfS--) {
        jsGsTjVslB = kTdMCpZGqwbrxl;
        tnIGeLGQJrTGCTT = ! kTdMCpZGqwbrxl;
    }

    for (int GDzOQkb = 1797313003; GDzOQkb > 0; GDzOQkb--) {
        GmnVdWFRtxOqX -= GmnVdWFRtxOqX;
    }

    if (tnIGeLGQJrTGCTT == true) {
        for (int rcxOinqPPfHpw = 1394378525; rcxOinqPPfHpw > 0; rcxOinqPPfHpw--) {
            jsGsTjVslB = tnIGeLGQJrTGCTT;
            kTdMCpZGqwbrxl = tnIGeLGQJrTGCTT;
        }
    }
}

int rtFjZdJGxwhWKbJ::fnJyPzngoi()
{
    string sBFvHz = string("NkPtXUFZLghCcZXicRfRaUtXBCMJIdfTumlKRwbFcEPZuUWblsObHLg");
    double slmvsJr = -240527.5763964224;
    bool QpCDLgRSIYoqi = true;
    bool IjeLHjMggBTqZJ = false;
    string CmMJqWWAejaO = string("eINOZgDKPzcGzeKlaZIoYlYvJKHfnGzESDpGNFmxCyXJKYBuoemeMdkBfWfWuGbybsnJnUSPXAaZrJspcug");
    string yKTvBJLOqPLeGg = string("QJRFhrImZxMzQsbSrTxrhkcmHnuKRiXOfbrybPTdppULzKDpNaqXkhYtEAmlDnXtrfzzhooLmWGMKTBDLEheQIesACRSmaAnmNTOJWD");

    for (int ZghwWrtDnkxaNN = 1359230374; ZghwWrtDnkxaNN > 0; ZghwWrtDnkxaNN--) {
        yKTvBJLOqPLeGg = CmMJqWWAejaO;
        yKTvBJLOqPLeGg += CmMJqWWAejaO;
        CmMJqWWAejaO += yKTvBJLOqPLeGg;
    }

    return 1188085133;
}

bool rtFjZdJGxwhWKbJ::DTCaLGRgFLhQopXv()
{
    string TCRiJpn = string("eXOhgXMyxyNhCJiTKhOTwcjPpBTwVWjxjdNJxbQLMyOOTuLBgdOqzFSpVQhDYszDpvEWPCuGFJrELliqVUxHZBSMnXsvCqQLTiUIggXOrBLJcNmtUtbAgemfjZrFOk");
    string gOqgVQ = string("bEqQnyrMIjuBRoKEuyZidtapKZZCKlTXoaRYLikdlUlGsAFGjqULpwLyKdWoGQcsSEVXUyEqmkDXZBampBBoXzKUaWrjWeXhloaXsQKAvFiMMjAqOVKkpxHjFLDZPeMiHTUvoECxgTCdSBgnsrCwxJxvxskwIPebgsAYJGrYdRoKzrCKPdbPSpHxWxsuBiiurKYrKPJhWevITalhpbOfjDKYCjOTSFBiWgEQCHalIPANMp");
    int xkdAPpTClHDZn = 680586241;

    if (TCRiJpn < string("bEqQnyrMIjuBRoKEuyZidtapKZZCKlTXoaRYLikdlUlGsAFGjqULpwLyKdWoGQcsSEVXUyEqmkDXZBampBBoXzKUaWrjWeXhloaXsQKAvFiMMjAqOVKkpxHjFLDZPeMiHTUvoECxgTCdSBgnsrCwxJxvxskwIPebgsAYJGrYdRoKzrCKPdbPSpHxWxsuBiiurKYrKPJhWevITalhpbOfjDKYCjOTSFBiWgEQCHalIPANMp")) {
        for (int YFcFpsFxh = 1666843263; YFcFpsFxh > 0; YFcFpsFxh--) {
            TCRiJpn += gOqgVQ;
            gOqgVQ = TCRiJpn;
            xkdAPpTClHDZn -= xkdAPpTClHDZn;
        }
    }

    for (int FZbKoOHErLZ = 1840979738; FZbKoOHErLZ > 0; FZbKoOHErLZ--) {
        TCRiJpn = gOqgVQ;
        gOqgVQ += TCRiJpn;
    }

    for (int qZLDSdVGNYQzaeL = 357711614; qZLDSdVGNYQzaeL > 0; qZLDSdVGNYQzaeL--) {
        gOqgVQ = gOqgVQ;
    }

    return false;
}

int rtFjZdJGxwhWKbJ::xztvAMwOjeXk(int qZxKXYHRVad, bool CMxIcdWoRA, string GdCLQpV, bool sVNmcCXZTp)
{
    bool YQPBXPOAzbEQ = false;
    double RgTEk = 405081.2945341092;
    string fTrITFlAwOlYeTF = string("BBltHIoRLVkYghGtXTuJlbBpCYzWyGXu");
    double lqZIdKoGSwbAXkEQ = -290679.5326599193;
    double bFDhLvdumpSC = -157112.03917533407;

    if (bFDhLvdumpSC > -157112.03917533407) {
        for (int RhWCXkjpzAmZc = 1063683761; RhWCXkjpzAmZc > 0; RhWCXkjpzAmZc--) {
            continue;
        }
    }

    for (int GYgIFZbAElVqFkOE = 757542629; GYgIFZbAElVqFkOE > 0; GYgIFZbAElVqFkOE--) {
        qZxKXYHRVad *= qZxKXYHRVad;
    }

    for (int XjDEcslqdRYGwxkX = 454321841; XjDEcslqdRYGwxkX > 0; XjDEcslqdRYGwxkX--) {
        fTrITFlAwOlYeTF = GdCLQpV;
        CMxIcdWoRA = sVNmcCXZTp;
        CMxIcdWoRA = sVNmcCXZTp;
    }

    for (int KLsGgIUXYqcG = 1181627626; KLsGgIUXYqcG > 0; KLsGgIUXYqcG--) {
        GdCLQpV = GdCLQpV;
        fTrITFlAwOlYeTF += fTrITFlAwOlYeTF;
        CMxIcdWoRA = YQPBXPOAzbEQ;
    }

    return qZxKXYHRVad;
}

int rtFjZdJGxwhWKbJ::lDqfxDMqUtVXC(bool yeTTAwoxMGucxsr, int WRsnmzVXpgvav, int gRgOABMNPrn)
{
    bool lrAlLxYOxxiB = true;
    bool EvElPAkI = false;
    bool daqHUUg = true;
    double lYlQCkbeI = 326861.3825137183;
    double oMohtFqQ = -929962.8745539403;
    int fTeGZPPsNgy = 186798332;
    double kzzVtfIb = 776931.4943152581;
    string jxLyOxAMXtr = string("UVbdnEAnvkdxjFmHWCwQCutPWKcFdeBLkGBvEixthqOgKrydvlpOCLDiFUsWMgbXjT");
    double ltmMX = -522614.4409334115;

    for (int pkvdUHU = 374331030; pkvdUHU > 0; pkvdUHU--) {
        EvElPAkI = ! daqHUUg;
    }

    for (int zWoHjaNVtoJhEcci = 2009694558; zWoHjaNVtoJhEcci > 0; zWoHjaNVtoJhEcci--) {
        kzzVtfIb *= kzzVtfIb;
        WRsnmzVXpgvav += WRsnmzVXpgvav;
        EvElPAkI = lrAlLxYOxxiB;
        oMohtFqQ += lYlQCkbeI;
    }

    for (int ByQBX = 853224304; ByQBX > 0; ByQBX--) {
        oMohtFqQ += ltmMX;
    }

    return fTeGZPPsNgy;
}

rtFjZdJGxwhWKbJ::rtFjZdJGxwhWKbJ()
{
    this->JEXSdSyJEjfyZ();
    this->TaVKoJqHmtOyyZtd(false, string("LpWCmHeIYzOdlYPUpcVQsmDSWUSjdovwDfJfIZDOiQMqrimURBVOSGgAUnDEpcYtfjebFr"), 1989993627);
    this->fnJyPzngoi();
    this->DTCaLGRgFLhQopXv();
    this->xztvAMwOjeXk(77787797, false, string("UQDvzmxgjNpwqFZQbKDTUNydQyAFZuzwVnqCZqvXNXZZVJeplnzQKAkqoPSvQsXfWVZVZznYBiFxTmSnEAFENYkooGPJnIduLvpJPiwsviWKarJgAxiIMktOfFQhYRsPUCcKjbcoVgNdFVXHpMmRdgkfRPoduRzGR"), false);
    this->lDqfxDMqUtVXC(true, 296020800, -2006056536);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mRdEIulKQlSTA
{
public:
    double bUrdNk;
    bool lNqsTflos;
    double gyNOcI;
    double CAKFfP;

    mRdEIulKQlSTA();
    string EvazpeBObRa();
    int TqsdIp(string EkBxZTL, int YGVAt, bool iwnBHYoXCbnxQ, string OLkAgWqu);
    bool sLuoZn(string gAkoFC);
    int vTRFvLlanL(int syIUtYvtBCZkn, string AlXizliBStRarF, bool lkdQZPJIYT, bool TmTSjTY);
    double DYvSeTjf(double UdsrlZy, bool ltRVQUujSYcjhvXN);
    bool MUuMEZffs(bool mrpwwVasVbwPjO, string xdVHPTWJ, int XliTtJWcOqiLxbz, double RTRywOleTpARLIr);
    double cPchJAgMEdJLGpNl(string fyiZysWJUrrfj, double COzvXpw, double JHAunliWn, int dfObsBfFWQBzKdu, double CCtktjuqc);
    string SeQYHJDDKeX(double AfjDTvcTPKBQy, string eqzmvAqc, bool YxVVPJXznJPQkr, string EbGYeMrCRU);
protected:
    double rftTWGl;
    string swOKVkTgXnU;
    bool NisjxOyHAHeN;
    int EeecbvCKayJX;

    string LpgBK();
    double lRhfJHXi(int yrmoUWOoBd, int dIkUAQegpMsLApp);
    double GxpNvuNiwVe(bool cCMkwX);
private:
    double KHIDd;

    string ZxkqAP(double AbkCcUlld);
    int YUrZbGmCOUtEZ();
    double waLqdU(string RcBdPxCjbDfANjy);
    void kelOcQXm();
    string ZObcVaUNOm(double vkRoaZ, bool wJStAZfUlWWBL, bool aClCDNLaKRNr, int ZiGafVlHlqiKLcan);
    int hiVUTtIcgOSFiako(int nommbUT, bool qFuFlbRVaHlfPk, double aKSzKYzZetvq);
    void DuaBMqclwq();
};

string mRdEIulKQlSTA::EvazpeBObRa()
{
    bool OYLsfurJ = true;
    int hNNWAdyNjwBI = 1151844813;
    int JLdLRxIxELIy = 1211461358;

    if (hNNWAdyNjwBI != 1151844813) {
        for (int HaMjAXsMTUFqj = 2145960467; HaMjAXsMTUFqj > 0; HaMjAXsMTUFqj--) {
            JLdLRxIxELIy -= JLdLRxIxELIy;
            hNNWAdyNjwBI += hNNWAdyNjwBI;
        }
    }

    for (int EKFdFIVdllMC = 1307571822; EKFdFIVdllMC > 0; EKFdFIVdllMC--) {
        JLdLRxIxELIy = JLdLRxIxELIy;
        hNNWAdyNjwBI += hNNWAdyNjwBI;
    }

    if (hNNWAdyNjwBI == 1151844813) {
        for (int zQSYZbHcr = 834932801; zQSYZbHcr > 0; zQSYZbHcr--) {
            hNNWAdyNjwBI = JLdLRxIxELIy;
            JLdLRxIxELIy *= JLdLRxIxELIy;
            JLdLRxIxELIy /= JLdLRxIxELIy;
            JLdLRxIxELIy = hNNWAdyNjwBI;
            JLdLRxIxELIy = JLdLRxIxELIy;
        }
    }

    return string("iARrCpMnLdiOJTwldFVjiaLoTnRbfAibbjAcugpxo");
}

int mRdEIulKQlSTA::TqsdIp(string EkBxZTL, int YGVAt, bool iwnBHYoXCbnxQ, string OLkAgWqu)
{
    bool kpbLhPwviegrPvC = false;
    bool BKDXDe = false;
    double gIbhc = 29822.27479761754;
    string XFhildagUbWoTStu = string("HvbbXkZpJSdhUEUFjtiVbkTyrPqrXJdRbTnFttLrVvxUxuRNBNlbAuuivwvqsLbPRYmnwVNlFvZXXUwqhZLCXqHBjuudXBIEcZSXaFxbacCiEjqUSZTJRxLoAVjfSdxJLBsniGRbhIroIoAUhSxtbDGJsDHxGSZfuji");
    string gNAjEXeShQBB = string("QfNLHCKddzqRRUwllTkTcbGZBryoTOCQlZfDUjTPdlTCMJikcHJsHjuNeDXkuwTUjlGhyCHYNzizpzcOvyZRGiabatHqNBLuoYsJAlXQoNIWGLwevhiMDyDqJphiMWIBcrhxeEYeuDSqFEmksskZfwrGhwMkIjckhYBOIwuigUPqOUPJlxKZXfHelC");
    double ERIyuKgllDkwYRC = 108183.75044306785;

    for (int jdTgTPaI = 556670636; jdTgTPaI > 0; jdTgTPaI--) {
        kpbLhPwviegrPvC = ! iwnBHYoXCbnxQ;
    }

    for (int azthgMtBoyD = 1719444934; azthgMtBoyD > 0; azthgMtBoyD--) {
        continue;
    }

    if (iwnBHYoXCbnxQ == false) {
        for (int lohsZvJgqto = 849756782; lohsZvJgqto > 0; lohsZvJgqto--) {
            OLkAgWqu += OLkAgWqu;
            kpbLhPwviegrPvC = BKDXDe;
        }
    }

    for (int VlzxakUD = 1768997019; VlzxakUD > 0; VlzxakUD--) {
        gNAjEXeShQBB += XFhildagUbWoTStu;
    }

    return YGVAt;
}

bool mRdEIulKQlSTA::sLuoZn(string gAkoFC)
{
    bool vkAegOF = false;
    double GObQDB = 735322.5454071602;
    bool nFOQnF = true;
    string hYeEW = string("mtrvFhrshFfvQhoJdJouxAdyYaUDcomIufazzAHUcVcTJROpRQgIPcHvJeCSrnqsrVhmalizYZcqPJspbPqqmTwaGgvXBzpxshBRKRlrtPObIyemJkxWR");
    double FxNPeMhifywdMYPF = 398188.8358651957;
    double RjHZrCXxbS = -240066.1171225688;
    double qJnIm = 819471.5038948053;

    for (int TpjRZr = 1208406109; TpjRZr > 0; TpjRZr--) {
        hYeEW += hYeEW;
        qJnIm *= FxNPeMhifywdMYPF;
    }

    for (int FabaLW = 1635729088; FabaLW > 0; FabaLW--) {
        nFOQnF = nFOQnF;
        GObQDB = FxNPeMhifywdMYPF;
        hYeEW += gAkoFC;
        gAkoFC = hYeEW;
        nFOQnF = ! nFOQnF;
    }

    for (int WqWYeMklPfQPlJh = 1972330936; WqWYeMklPfQPlJh > 0; WqWYeMklPfQPlJh--) {
        hYeEW += hYeEW;
    }

    return nFOQnF;
}

int mRdEIulKQlSTA::vTRFvLlanL(int syIUtYvtBCZkn, string AlXizliBStRarF, bool lkdQZPJIYT, bool TmTSjTY)
{
    double vADVyqzKjvk = 567532.3294354505;
    bool KsesaU = true;
    double DwwyGmxbWAkJc = 1009406.398075931;

    return syIUtYvtBCZkn;
}

double mRdEIulKQlSTA::DYvSeTjf(double UdsrlZy, bool ltRVQUujSYcjhvXN)
{
    string LiOtzBSfGUi = string("RDeEScxfvUnQVeFZWbMbcwdOvyXTlZuzFcMYcuYRpCovEuoQEJlSPowUjDABmvovGwDEjUjocJRdrnPXjHPNoUQfqLXBrKbrwvHCKjDqDZAeJRQusXtNezphqrugjDQzMxyBXHpvxCGSTDaYyUsgcNymkgsqxLHfKuxrwikBpZZJxrcMprAPIVXqFveqTLNEDRHJUMAJSzyhHdLQydeafioBWkdzHgggow");
    int doElitBJmjzmhMm = -1779545821;
    bool eFZKuIrdkv = true;
    string iYCUwoe = string("cizJLnPMbLcfcrBIaxwjMSETBPxOKOMPdmGsendiIdNtBLOkCoKHinTIlu");
    bool acZRbgwwgQRG = false;
    bool rXGCHOAIZx = false;
    double mUlGKBX = 774003.1761753805;
    double tuWMdw = 344340.9667809259;
    int YHpgnzZKsmDkLUF = 799553567;
    int VxroC = 257198975;

    for (int TouKhCufYUseLxt = 1369115982; TouKhCufYUseLxt > 0; TouKhCufYUseLxt--) {
        tuWMdw *= mUlGKBX;
    }

    if (rXGCHOAIZx == false) {
        for (int JKTqZIhdQcK = 1349184577; JKTqZIhdQcK > 0; JKTqZIhdQcK--) {
            continue;
        }
    }

    for (int agLPSOeT = 1475371175; agLPSOeT > 0; agLPSOeT--) {
        UdsrlZy *= tuWMdw;
    }

    return tuWMdw;
}

bool mRdEIulKQlSTA::MUuMEZffs(bool mrpwwVasVbwPjO, string xdVHPTWJ, int XliTtJWcOqiLxbz, double RTRywOleTpARLIr)
{
    bool EHOCbPQeCn = true;
    int IODqfuZBkhswQ = -482970197;
    int sghgO = 1069357956;
    int sDHtzZulBmWFwT = 1664060989;
    double uMexEz = 511341.2411064388;
    int lHmmb = -690639795;
    int jzCwoz = -2071136557;
    string qBcSGgBnTBX = string("DdkNuqKwDwFNysRaRsbyjMptloRzIXLRCcUWoMqcfHfGYVzqYFFgyzTgdmWTFNgYBaNkxZoUAowVDqFjzQKJNWalTUsqeHSJiCcPiktyocSrJuwnNUJBJcxhkrLciiQQlJiTDNXeDusfsGTjJZrKYDEiMxfawOkVIrupxqWbxDAiIZnjKKDKyvDsdKLieaOkuEky");
    int VWgxni = 1810797721;
    int AOpBluzW = -1820610038;

    if (jzCwoz > -690639795) {
        for (int ZNdwXUEPMj = 1688048222; ZNdwXUEPMj > 0; ZNdwXUEPMj--) {
            sghgO = AOpBluzW;
        }
    }

    if (AOpBluzW <= 1979908680) {
        for (int npPBFXbyivH = 1639351983; npPBFXbyivH > 0; npPBFXbyivH--) {
            continue;
        }
    }

    return EHOCbPQeCn;
}

double mRdEIulKQlSTA::cPchJAgMEdJLGpNl(string fyiZysWJUrrfj, double COzvXpw, double JHAunliWn, int dfObsBfFWQBzKdu, double CCtktjuqc)
{
    string GFhdCxoUbjbH = string("YUIzjGmwgUZjQJcsjzPkjHdxGqhbAHnAvxpmurQw");
    int TiKgKpeZJvAOI = -479129077;
    double rRdiEAqkvval = -858225.4073288026;
    bool bOPYxErgHGCpA = true;
    bool YraYBEQBOKaahtEp = false;
    bool hrlyyxNirJOxUmWP = true;

    for (int MgTNDEkiaLUJCiC = 1626460421; MgTNDEkiaLUJCiC > 0; MgTNDEkiaLUJCiC--) {
        TiKgKpeZJvAOI /= dfObsBfFWQBzKdu;
        rRdiEAqkvval *= rRdiEAqkvval;
    }

    for (int zgVytIjdpOf = 1358653420; zgVytIjdpOf > 0; zgVytIjdpOf--) {
        JHAunliWn *= COzvXpw;
        COzvXpw *= JHAunliWn;
        hrlyyxNirJOxUmWP = YraYBEQBOKaahtEp;
        hrlyyxNirJOxUmWP = ! bOPYxErgHGCpA;
    }

    for (int nSlgK = 1816257713; nSlgK > 0; nSlgK--) {
        fyiZysWJUrrfj += GFhdCxoUbjbH;
        COzvXpw -= JHAunliWn;
    }

    if (rRdiEAqkvval < -858225.4073288026) {
        for (int bjRtb = 1627552528; bjRtb > 0; bjRtb--) {
            continue;
        }
    }

    return rRdiEAqkvval;
}

string mRdEIulKQlSTA::SeQYHJDDKeX(double AfjDTvcTPKBQy, string eqzmvAqc, bool YxVVPJXznJPQkr, string EbGYeMrCRU)
{
    double bfRrmEkQ = 233627.8743079058;
    bool CmRXSioH = false;
    double ogLwAYtQxPlC = 514285.36173946894;
    int yQUOreawCcOjfGG = -2032569612;
    double DjBayFHIRvwhc = -391934.15451150446;
    string vBdkIhCvOdUFNHL = string("heRBquesOfHEUiPZQYiQofstZLpFDgMRZlTlhPkZYYtvbUDETHmnxLsKCoRzBOwnQVycPayVcxXRHgLEAENCBZqDBxbSCFshiAoWyceTmcGbjhXCuivJTLSXXmoECNptDpaPsFVloZOkdSWlZBurNBHMEMjZiqcxQrBGAValXXWknLlJUDUFsiVDumwSyTGgZTXMUDgiSsokzdETeoYvfChjxaAusEMNBwRzBNxbEZ");
    bool iAduqQesNwpMtZR = true;
    double yOQKhgehISnxF = 199831.61033405375;
    bool UokJNAclbrn = true;

    return vBdkIhCvOdUFNHL;
}

string mRdEIulKQlSTA::LpgBK()
{
    int NiSQwi = -1876028502;
    bool llpyUwLifxgz = false;
    bool jugkdMiw = true;
    bool PReaexLJ = false;
    int cetrg = 1002667078;
    bool IJJTRVFascKVl = false;
    int mMlgsPulDvdKSchR = -357461449;

    for (int QxvcFkylxjXMlTY = 54348465; QxvcFkylxjXMlTY > 0; QxvcFkylxjXMlTY--) {
        jugkdMiw = IJJTRVFascKVl;
        mMlgsPulDvdKSchR /= cetrg;
        NiSQwi -= NiSQwi;
    }

    for (int IyDoYXiTSHeza = 1507474739; IyDoYXiTSHeza > 0; IyDoYXiTSHeza--) {
        cetrg = NiSQwi;
        cetrg -= cetrg;
        NiSQwi *= cetrg;
        PReaexLJ = ! IJJTRVFascKVl;
        jugkdMiw = ! llpyUwLifxgz;
    }

    for (int zLcgq = 2046334938; zLcgq > 0; zLcgq--) {
        llpyUwLifxgz = ! jugkdMiw;
        cetrg -= NiSQwi;
    }

    return string("MWOkkjzGjLBUQMKbMxerPdramfJnLQFnE");
}

double mRdEIulKQlSTA::lRhfJHXi(int yrmoUWOoBd, int dIkUAQegpMsLApp)
{
    string XPgPDFznX = string("upGXPFRCDQtNmKuGZdGhubCeqjvFuwyugfZWEbaHyocQcUYgOeCTvcgtYUWqFEV");
    double ixMvK = 178121.97026011357;
    string KQvwwmYutBEhmA = string("vqEnggdQVRJUeBdJiJTwbwQDvCHODwruLaTtqfmkDdgiIhaNzbotNjAgZLjQXqyAAjkSHZsvuUzEeaeQXnYsRRmfIvEXzWNsrVcFhFCqwzwzVUgKpIrMULeSQgwKegBoadLSGpSolJNyWdQhVMqIylXHCEtovEYUuDoPZOyMsthjQRlhCODRVreMyu");
    bool alLOGBTY = true;
    string uSsQyjqLc = string("RurzzlyQNheYMfLhgWQqWqWtaHxSOyVMAKfmQstGRPtlqkYqVGXcBYIyvAVBXKPktQoQU");

    for (int GiAXcZYorFSvlxg = 1613368323; GiAXcZYorFSvlxg > 0; GiAXcZYorFSvlxg--) {
        alLOGBTY = alLOGBTY;
    }

    return ixMvK;
}

double mRdEIulKQlSTA::GxpNvuNiwVe(bool cCMkwX)
{
    bool URveBRnqIKObaAWw = true;

    if (cCMkwX != true) {
        for (int dpiaDpF = 256146336; dpiaDpF > 0; dpiaDpF--) {
            cCMkwX = ! cCMkwX;
            URveBRnqIKObaAWw = URveBRnqIKObaAWw;
        }
    }

    if (URveBRnqIKObaAWw == true) {
        for (int HzZfbpZyIRGWRg = 978589423; HzZfbpZyIRGWRg > 0; HzZfbpZyIRGWRg--) {
            URveBRnqIKObaAWw = cCMkwX;
            cCMkwX = URveBRnqIKObaAWw;
            URveBRnqIKObaAWw = ! URveBRnqIKObaAWw;
            URveBRnqIKObaAWw = ! cCMkwX;
            cCMkwX = URveBRnqIKObaAWw;
            URveBRnqIKObaAWw = ! URveBRnqIKObaAWw;
            URveBRnqIKObaAWw = URveBRnqIKObaAWw;
            cCMkwX = cCMkwX;
            cCMkwX = cCMkwX;
        }
    }

    if (cCMkwX != true) {
        for (int HgjBTNYwYMcwBsNG = 944753710; HgjBTNYwYMcwBsNG > 0; HgjBTNYwYMcwBsNG--) {
            URveBRnqIKObaAWw = URveBRnqIKObaAWw;
            cCMkwX = ! cCMkwX;
            cCMkwX = ! URveBRnqIKObaAWw;
            cCMkwX = cCMkwX;
        }
    }

    return 62836.90283689276;
}

string mRdEIulKQlSTA::ZxkqAP(double AbkCcUlld)
{
    int xVHynDnGZJrDoXAP = 1752055853;
    string kdnHJjFK = string("IlbGZuhHokoBGzdoesAeDAafQGfgOqfSOSpxxlppByxGsSxfxUAezMKODDsZIPHWoFxzxImVJVjqdRklLotetZcftSQAGqRDrpQIeseL");
    int zTMxK = 347458756;

    for (int wZMUXSUZElxJpWl = 1300040142; wZMUXSUZElxJpWl > 0; wZMUXSUZElxJpWl--) {
        kdnHJjFK += kdnHJjFK;
        kdnHJjFK = kdnHJjFK;
        xVHynDnGZJrDoXAP -= xVHynDnGZJrDoXAP;
    }

    return kdnHJjFK;
}

int mRdEIulKQlSTA::YUrZbGmCOUtEZ()
{
    bool GfCoGLFHh = true;
    string oGBRoynS = string("dmhmPdvtCZYiSiBoawSnKIASwudqwoltirfZUkdTdiPQNXkqCjFafqOVqKuhBdErGRCABeZaxREkZmCLAfGNCYOdLybwONUQGBAaLKAvXXwRaXidQyvIwyvkMmaCgBJgRDeSfsErLbtAeRpIKOaBKvabsOPvaAoUwILTKsDDlOjeHvcarMDiNevapnvzAqDVRIgGxqQrLWyzHMkiTlyfqMweUpmyRhMjUIVxWuTbmtLtdVOWJieC");
    string QkHFbBoEizpb = string("UlkZNUxJdsbxrzcDXoTKwwzBJqgVXsBFqfuUpbDzQIqPDcBaNVhGgGLiUkNynGbqBLKadHTyVOgRyJsjZUqLTVGOBeGchsQpwGpDgEbPauiImDfQLTtvjcuhMEkcExYPwfFGvoIwdwclrtoQwApRoiJ");
    double oLadQBplyE = -283972.5483435959;
    string XrQVhsgxSeyl = string("RPWecoRgyfYaNPogmRQkxWKbEwQEJzlRGSXEvefsBIEfEwknKiimFMFneyTjquqckdNSKgUBPudmDJKklAIZFGcErxOoLtgUoDkjSAFKdOfOgmZNVgcdjndIzbWZwHAueGIEYlwCLOQyEbUyBTtECOWQiuqHjEcIWDwOSTOGGsSvMaTuQBBSpzOgk");
    int elWcVXMieGbauXsS = -1050063856;
    double PKqVuunoKUSwtqO = 263203.04546584096;

    return elWcVXMieGbauXsS;
}

double mRdEIulKQlSTA::waLqdU(string RcBdPxCjbDfANjy)
{
    bool VSHAv = true;
    double zBiBlMKpmEqVxD = 593362.2062189935;
    double tRtPPrDmu = -789994.0718067283;
    int qsZRqbibarWrmIYk = -1947748761;
    string VoEpWeqSq = string("zIJLdxLXmwBhxtgIVhaVOLaohsWONyFKYkyvtDjXEbKgfhKCpddvDLsbQPsivgwMwDLcYWsMyIuXTMlCIvRBTRObppwYPyiHnlYxFwOsEXMIcqpfJihXWnzhxyvpivpvaZUnL");
    int ciZMun = 563283924;

    return tRtPPrDmu;
}

void mRdEIulKQlSTA::kelOcQXm()
{
    string EGNTBEJAI = string("MzLRutJZVeeWwwagyLGsxdChPeQgGPZCpWySKLHDFhwfaOfsOyTDkSrWqOFDOQwoRSzkWgSCPhFXRtoelPbwEGhcXA");
    bool nLVSorcKozFH = false;
    double QWXxuvDxHws = -188905.90344257385;
    string zVFkuAlILXIpVyE = string("qQErTZLHDfkYxiGfobHpJfovSeMVpFBofUdviAsHVuQD");
    int dGuUVFRlX = 1930600162;
    string mvQVC = string("PySJXfFDwtYHqIcSgOdQoGTVKjVGBZsuLDeGeDjeGXCJbHCCywrrDElGOFidJFhySJ");
    bool KINlFiZxGnQjaJ = false;

    for (int eVEzMhkpR = 1638548048; eVEzMhkpR > 0; eVEzMhkpR--) {
        dGuUVFRlX /= dGuUVFRlX;
    }

    for (int LXIpkKgPbzzIFw = 808183463; LXIpkKgPbzzIFw > 0; LXIpkKgPbzzIFw--) {
        nLVSorcKozFH = ! KINlFiZxGnQjaJ;
        EGNTBEJAI = mvQVC;
        zVFkuAlILXIpVyE += zVFkuAlILXIpVyE;
    }
}

string mRdEIulKQlSTA::ZObcVaUNOm(double vkRoaZ, bool wJStAZfUlWWBL, bool aClCDNLaKRNr, int ZiGafVlHlqiKLcan)
{
    double PRoqFFZqR = 857684.7986457822;
    string FqANNf = string("lntJfPnrIVDdkyDtCFhtojslFVCdMNBbML");
    string dCPwBVNkp = string("ExEgqDVIKKRvfAqrtzWLxSjXoWTPeUtemlJvHVAHyCtjQHTkKOJoSrgmozMxAAGFDSDAozWADgMSAZFiQbgldDWxKbrEnAumlaCRwGGCAErfnULfktwyFBjTznogATXbVhCvKkhpFXljifjasiziEAAsCqEZHZNgIScKQOmCBJpwkanCwXYXyNbnhMGiaGHgbMQSvwYyBOijwKktvJUIIQqjvORDyAFwh");
    int ztLtkVX = 477621111;
    double epkAJbzl = 421302.5546661191;
    double xzlRCnsIHckV = 755748.6019327636;
    int AYWvxjBAClD = 1505421335;
    double KRwtaUuoJOI = 386393.30165956443;
    bool TXJhppQlMw = false;
    int OSQPZAAxDZY = -252562987;

    for (int AsJRTWbjQCSMqqwM = 1532988597; AsJRTWbjQCSMqqwM > 0; AsJRTWbjQCSMqqwM--) {
        continue;
    }

    for (int ylNwNQKyd = 1603825543; ylNwNQKyd > 0; ylNwNQKyd--) {
        ztLtkVX -= OSQPZAAxDZY;
        TXJhppQlMw = TXJhppQlMw;
    }

    for (int IQlhghtbkrLDOXlB = 698577222; IQlhghtbkrLDOXlB > 0; IQlhghtbkrLDOXlB--) {
        OSQPZAAxDZY = AYWvxjBAClD;
        epkAJbzl = xzlRCnsIHckV;
    }

    if (xzlRCnsIHckV != 755748.6019327636) {
        for (int bMoPAPmfFfWGkf = 1398013194; bMoPAPmfFfWGkf > 0; bMoPAPmfFfWGkf--) {
            continue;
        }
    }

    for (int rCcZwEWSuOQth = 10269817; rCcZwEWSuOQth > 0; rCcZwEWSuOQth--) {
        OSQPZAAxDZY = ztLtkVX;
    }

    return dCPwBVNkp;
}

int mRdEIulKQlSTA::hiVUTtIcgOSFiako(int nommbUT, bool qFuFlbRVaHlfPk, double aKSzKYzZetvq)
{
    double tJxXo = -259825.6230441473;
    int ZBxgSGVZwtn = 902484914;
    double nhaEgxcNaAq = -679646.1465697117;
    bool lGZuaouurLAFNw = false;
    double xExVBBRLVDOYIkPc = 649433.4763983627;
    double ovuONDHalNW = 604449.0614253912;
    string GMWOrZHmklKaHw = string("iXKBRqiwVyNhEkrwMTliizUfXVVGFBvqtlJhMtnRCDNLQUwxGxSBEAbptEjIhItPtLHzkDekuRKhMRTpWDODjakwXIpaAUQNNRRBApTMlZVhTFQjJUeGvKoGIVjTEGlUkvcnLGBLddWXkZzeCzIfTqfrCFQZGYVsEUvI");

    for (int gNNnTWB = 616533695; gNNnTWB > 0; gNNnTWB--) {
        lGZuaouurLAFNw = ! qFuFlbRVaHlfPk;
    }

    if (nhaEgxcNaAq >= -679646.1465697117) {
        for (int oadGPfmlqc = 2052138614; oadGPfmlqc > 0; oadGPfmlqc--) {
            xExVBBRLVDOYIkPc -= nhaEgxcNaAq;
        }
    }

    if (nommbUT >= 1856921127) {
        for (int pJVgCDe = 565745001; pJVgCDe > 0; pJVgCDe--) {
            tJxXo = xExVBBRLVDOYIkPc;
        }
    }

    for (int ewDISASU = 1307251809; ewDISASU > 0; ewDISASU--) {
        nhaEgxcNaAq = nhaEgxcNaAq;
        aKSzKYzZetvq = nhaEgxcNaAq;
    }

    if (tJxXo <= -259825.6230441473) {
        for (int tXuQrO = 165678386; tXuQrO > 0; tXuQrO--) {
            lGZuaouurLAFNw = lGZuaouurLAFNw;
            tJxXo /= xExVBBRLVDOYIkPc;
            nhaEgxcNaAq -= ovuONDHalNW;
        }
    }

    return ZBxgSGVZwtn;
}

void mRdEIulKQlSTA::DuaBMqclwq()
{
    double nUxeCqJxz = -792899.5078417666;
    int uwdZPYtOuM = 1185841721;
    bool QhRxhHaoIbZbr = false;
    string dDLkYDRH = string("oFWaTrOeDbYjCqDYBvnMkUzMgEmm");
    int rmantYHoVUarax = 940520825;
    int wwZoaSxkYzq = 1787104579;
    string fFtVDtJfRN = string("aevvjWHcpvJEhbfmYSETaNFwEKZYoNvArgWDrJyPLCCNrMDdTtxumNgvZzvodglegpkPLnfCLveRFONzUsFfjrNTUcReFmTOXdZFzECewYOMwprDUgKSOxPztoWHRpHySVWtUwNIhEOydFBSQEnbehGKxuhyRhDNstWxqKidbPzXTedHGGzUSVkSLuMwOvxUtk");
    int sjzWcNSoeeAk = -2139023285;
    int DftjEihRqrPohNIp = -1758990083;
    int PsjSBOhpsNP = 1614880955;

    for (int QOnjwzKajkmgqB = 1369182307; QOnjwzKajkmgqB > 0; QOnjwzKajkmgqB--) {
        nUxeCqJxz /= nUxeCqJxz;
        wwZoaSxkYzq *= PsjSBOhpsNP;
    }

    if (uwdZPYtOuM > -1758990083) {
        for (int bFejNUXfuIVCOsLc = 1693878744; bFejNUXfuIVCOsLc > 0; bFejNUXfuIVCOsLc--) {
            uwdZPYtOuM += wwZoaSxkYzq;
        }
    }

    for (int ceAPKGMZRJmnP = 1403461498; ceAPKGMZRJmnP > 0; ceAPKGMZRJmnP--) {
        PsjSBOhpsNP *= rmantYHoVUarax;
    }

    for (int EjEPQH = 1563110733; EjEPQH > 0; EjEPQH--) {
        wwZoaSxkYzq /= sjzWcNSoeeAk;
        sjzWcNSoeeAk -= sjzWcNSoeeAk;
    }
}

mRdEIulKQlSTA::mRdEIulKQlSTA()
{
    this->EvazpeBObRa();
    this->TqsdIp(string("dZGMHUkSGIzSrxXloqIZHqnnoAZWXzGDzVpcnsqUHWqEjhhzcIhiyibPmsiJMXCjJuSNQpqqTdaovGqAMjMMPhWOqwaChoPatx"), -1167377762, false, string("vxsXVXnRb"));
    this->sLuoZn(string("AkSHeNZgaVRQDmrIVwASzFZVwmHvBVwUyZLKNbANzwMyoEwTqnrbQdlNOxDyaTKHBBHralNGvmOZCysJDpfpSSEBlZEOJMbHNsmtWhCaXnUuEMPsXYSWWlfITqByFFQPAAlhVOJEJzfSGQUgCIxebKCChuqAGIcwTIShRQxjDEXmQKcYTrOOoixJugtT"));
    this->vTRFvLlanL(-27800009, string("ZDdqOjuwNRledNqejsndIPORTGTbBUGJmuAYkEnfMlgLXIqCZhtVFlocsxeSPXWYfruLYVJvTSkIreVclzWGiZCPxktvzpkxlAuINiTNFTLrvNMyrCQtyFekUtSIQSJnAYEBjRauKOYdYI"), false, true);
    this->DYvSeTjf(781992.6321170938, false);
    this->MUuMEZffs(false, string("nUbUPhTjAXkUsNXZmuXdPYKKNcynoPONOrlGamYlKeYZLFcJGdjFOiiDIADbcpQdTpXTixHBeVhUlxaFxKFsmUoZOvUOayEDxLsoHPiQGxjcYfyvNdgzIjtfDcYlKoNTlAZdattJpIOVmVAvNmQFudWzuRXtZkQJYLDdMgNeQWptMUAfsCHVACSNyTUtRItKjZbismxDfTfvJqbeobifiOcvCGjFixAKRfnsjXtOOQjkIRXEuZTtTcxEjvf"), 1979908680, 892880.9147939621);
    this->cPchJAgMEdJLGpNl(string("HvNljpOgAwuRpPZEaAJGrLMVnseIcSKLcKpGKUxuaWFrMdPaITEHQavGFsFQgAPfhWxoXcYDUFhfGLbyjztwssxFebYTqmMKZeeosfpwmVFmYP"), -464629.10143631644, 962077.4665115387, 1280534299, -820178.2790436145);
    this->SeQYHJDDKeX(-456530.99395390763, string("KDeyZitNPYXwQELZMNORgOLjMmmXZgaRAsEPilQMarGmJwJjnlIifDZvtSkPPULcHApglSNmbgQLDDkFNecBfFhhpjtsHcSPsrjxiWLubBpuXXbBjhmNnPeSkrDgVIAMBAOOGQaYVusTbtoFkrrXVgkqDQ"), true, string("aqeqwCTOIarvdEYIMUjLMTSXdEfoThosHhdJoobBvicPibrGgIvBmlkWubQeDMeFTOfKdsCoqtlFxPVWgocQWoABmRrYvnkfrPhqGhiLeKJMtjmXICbGOyuIwzOEjUdLUYrZoyIVkSnNHZzailnlqfSGSewELqwnEOTVFjkZfWlkhDUkBkVkznwoenNzPHHuVLICoFFcfn"));
    this->LpgBK();
    this->lRhfJHXi(173141709, -552738024);
    this->GxpNvuNiwVe(true);
    this->ZxkqAP(548565.5380263521);
    this->YUrZbGmCOUtEZ();
    this->waLqdU(string("QHdXRXbwnDijBXNCUCYwaiZYbanqgXTOXWoIUUzWJNiuuJWGoMcTdYmpiUeCyBpacgjaTlHKbIZeheTQCYgFBZbaHLnFXRkghuDluLltpocniJQdLixjIqtiRiqhIQZnijcDrZtUCpvCbhodfsBIcGIhsSNCZrsAtNPIhJeJGjCrAnlHfavBzUKtRZYoPhDOZoqWaDJsgUCCKvZNTxrQObZedSgsofqUaHJDrnoJAbDNTzEQF"));
    this->kelOcQXm();
    this->ZObcVaUNOm(-147116.53556863542, false, false, -810849796);
    this->hiVUTtIcgOSFiako(1856921127, false, 165949.5618781669);
    this->DuaBMqclwq();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WOkYIZeMsKwhpNq
{
public:
    bool UtdZdJCTyqTVQn;
    string RmxtznnYW;
    string yoPLjsRsUSYlQGDs;
    bool cWOQNiAkifKbNS;

    WOkYIZeMsKwhpNq();
    bool wvBqY(double ijYtfIDDnSlxcw);
    double FQhVyicpvJ(double wpgXl, double RAmQaIsLJCCA);
    bool eeGaUkhBnhhVjU(string PAgTPbWVIeeC, string NrgJRNQ, bool zHjUsSCOmiL, double CqzQgFgWpSsDhdz);
    double FxkYsmjsbsndh(int RkoZgdU, string pjUcsY, bool tHbZu, int VZzCuRtq);
    int XSPYjRQD(string iNcxaTzL, int FLXBfarEitysZ);
    void oqCSrGBEloaCkc(bool LvmUdxLhYOtFMr);
    double RFmKPBy(bool gBZcZRpRmnD, string tZpbe, int TOCxXPjxgqfiMZFe, int EsbYGoQ);
protected:
    bool eFlbIoJbP;

    void YbhpQaZ(int IVfgRHdtJZkCyo, double HZsPNZS);
    double UuKEUxSRrQr(int qgGZGlvTWlfzbNJD, string EVheAzSXUZbZS);
    void HzRcgVeduq(int HenMvgjve, bool EETlJRHrHnMAad);
    string MyMaqfTNCZmCsF(bool hJInZJovFYUL, double fDJveSkpmFgdPtmw, string gPREMWj, double MdctrxDQb);
    bool sBDdjEUgGdWqPNS(bool yaFBQhlZmMh, string SixEMm, string PdKLwIu);
    void fSokgCX(string wfoUzOWbZkYjRZ, double IyHdaQGELXhSPl, bool muTgEvNU, string WFomRAUb);
private:
    bool BadJLXCQc;
    string gLuymhwHypLrzMWu;
    double mFwGl;
    double NGUBmnVIcpkf;

    void WkIas();
    bool KOiOeGfEYvoYMr(bool Twnan, double uMyfImuQFnQzheq);
    void UhCPJmylSXlWGdc(bool eFLWynGKRwJgkHb, double awBMWgUY, bool kMTuEpw);
};

bool WOkYIZeMsKwhpNq::wvBqY(double ijYtfIDDnSlxcw)
{
    double qnVCt = 717682.8325811628;
    string DUWjWKFtd = string("PiHSnrzdSwNbmKjRBdgylJqVJGZPXIzeGjCHxlpnuinWctpOAVzqifAbjsJCzWUJdhPPmzNGOgimiLMpEPUGWgtAeVoPsgdGLdVtIwVPbRBTZYnyufmGjdQsotOEsrbLUcWNfWKogSEvPvyHJLsRrIWVCqcdJlLohldsajnycJLdEdqItIqTAscLseGxiPBMziRSnLIGbajTbCJHwNvglkrZVOrqbb");

    if (DUWjWKFtd == string("PiHSnrzdSwNbmKjRBdgylJqVJGZPXIzeGjCHxlpnuinWctpOAVzqifAbjsJCzWUJdhPPmzNGOgimiLMpEPUGWgtAeVoPsgdGLdVtIwVPbRBTZYnyufmGjdQsotOEsrbLUcWNfWKogSEvPvyHJLsRrIWVCqcdJlLohldsajnycJLdEdqItIqTAscLseGxiPBMziRSnLIGbajTbCJHwNvglkrZVOrqbb")) {
        for (int ivxgx = 459864956; ivxgx > 0; ivxgx--) {
            qnVCt -= ijYtfIDDnSlxcw;
            ijYtfIDDnSlxcw -= ijYtfIDDnSlxcw;
            ijYtfIDDnSlxcw -= ijYtfIDDnSlxcw;
            DUWjWKFtd += DUWjWKFtd;
            DUWjWKFtd = DUWjWKFtd;
        }
    }

    return true;
}

double WOkYIZeMsKwhpNq::FQhVyicpvJ(double wpgXl, double RAmQaIsLJCCA)
{
    double OCuLHCDTuvNRskQ = 69595.2153518676;
    bool fwLjl = true;
    double Djrfza = 315032.23121999006;
    int mWCLZtJYLTi = -2080220325;
    double LYwZUYYdePM = -927007.3819859445;

    if (RAmQaIsLJCCA > 69595.2153518676) {
        for (int MKJbGmlHamqReRr = 1705085244; MKJbGmlHamqReRr > 0; MKJbGmlHamqReRr--) {
            LYwZUYYdePM *= RAmQaIsLJCCA;
            OCuLHCDTuvNRskQ = Djrfza;
        }
    }

    for (int VauekZTWjKlDZfAs = 1196258041; VauekZTWjKlDZfAs > 0; VauekZTWjKlDZfAs--) {
        RAmQaIsLJCCA += wpgXl;
        wpgXl = RAmQaIsLJCCA;
        Djrfza *= Djrfza;
        wpgXl += Djrfza;
        LYwZUYYdePM = wpgXl;
        LYwZUYYdePM /= wpgXl;
        LYwZUYYdePM = OCuLHCDTuvNRskQ;
    }

    if (Djrfza >= 315032.23121999006) {
        for (int UoGQBh = 264741511; UoGQBh > 0; UoGQBh--) {
            mWCLZtJYLTi += mWCLZtJYLTi;
            Djrfza = RAmQaIsLJCCA;
        }
    }

    for (int sumKiui = 1749455082; sumKiui > 0; sumKiui--) {
        continue;
    }

    return LYwZUYYdePM;
}

bool WOkYIZeMsKwhpNq::eeGaUkhBnhhVjU(string PAgTPbWVIeeC, string NrgJRNQ, bool zHjUsSCOmiL, double CqzQgFgWpSsDhdz)
{
    int MvstBBBRJWtojOt = 1411386323;
    int SzElHBiaLNkGTKtk = -531207272;
    int oKIqZWLYIHPTCQZw = 411530252;
    int uEEIxojxOvCER = -249968967;
    double iwIEaanpr = -469209.99189938715;
    double sWKBuiewHPzW = -198916.72286797262;

    return zHjUsSCOmiL;
}

double WOkYIZeMsKwhpNq::FxkYsmjsbsndh(int RkoZgdU, string pjUcsY, bool tHbZu, int VZzCuRtq)
{
    int dvZcjywWxIApnWq = -148847641;
    int rIpwzGz = -1043112226;
    int QDitoHoEUjL = -1975999320;
    int MflCpapEc = -475498251;

    return -595561.1924654981;
}

int WOkYIZeMsKwhpNq::XSPYjRQD(string iNcxaTzL, int FLXBfarEitysZ)
{
    string BsNGU = string("HaRiFoTaSSotSZYrKEsMbhkKtyBqoFCtGbhSTYEvOCEwxCmNXfDOQaNzFmrkxJJXRyUVSAdeJzfXwItbmttIygwvnijvkmSgIPWGLWCEmZQbPlYNQSwNBvsbvwphTmmsQDmUeZvAxcttytbZbzlngBnKlggEZSTdUnfeBGaXODeaUHYzvvGDOWSEsCNKrGIuGrQkOUV");
    string eLpnQMQfIVxoNdW = string("gajqaQDkDYWapRdbegwaOzHqlynPsExOFyiuQbXYNSPVsRvbOsLoWrjcBhhIZiWzJPaTZPVzcSdwRUXaRJtKUxSLNHnbcVISIHEhAUmzmcMlNGZhNN");
    double nqipmuv = 645229.4623953493;
    bool NdYzfpZijLaSu = false;
    int HDKIolNpdK = -29792134;
    double UQizUIljZG = -882380.6251943215;

    for (int YHHzYdlSg = 375759761; YHHzYdlSg > 0; YHHzYdlSg--) {
        iNcxaTzL += BsNGU;
    }

    if (NdYzfpZijLaSu != false) {
        for (int amdVkWSDpG = 515774204; amdVkWSDpG > 0; amdVkWSDpG--) {
            BsNGU = eLpnQMQfIVxoNdW;
            eLpnQMQfIVxoNdW = eLpnQMQfIVxoNdW;
        }
    }

    for (int hDtztE = 1752743840; hDtztE > 0; hDtztE--) {
        FLXBfarEitysZ /= HDKIolNpdK;
        BsNGU += eLpnQMQfIVxoNdW;
    }

    if (BsNGU == string("HaRiFoTaSSotSZYrKEsMbhkKtyBqoFCtGbhSTYEvOCEwxCmNXfDOQaNzFmrkxJJXRyUVSAdeJzfXwItbmttIygwvnijvkmSgIPWGLWCEmZQbPlYNQSwNBvsbvwphTmmsQDmUeZvAxcttytbZbzlngBnKlggEZSTdUnfeBGaXODeaUHYzvvGDOWSEsCNKrGIuGrQkOUV")) {
        for (int nHjUd = 1661814244; nHjUd > 0; nHjUd--) {
            nqipmuv /= UQizUIljZG;
        }
    }

    for (int cnUhAOa = 529072005; cnUhAOa > 0; cnUhAOa--) {
        iNcxaTzL += BsNGU;
        UQizUIljZG = UQizUIljZG;
        FLXBfarEitysZ += FLXBfarEitysZ;
        UQizUIljZG /= UQizUIljZG;
    }

    return HDKIolNpdK;
}

void WOkYIZeMsKwhpNq::oqCSrGBEloaCkc(bool LvmUdxLhYOtFMr)
{
    string dOqNDVodEB = string("dJanHboWxkCJtnWkPfQeSDfCLkYudnWTvVxlxfjRBgQiGQiQdxkLfcqYMpHrSKjHSWeTa");

    if (LvmUdxLhYOtFMr == false) {
        for (int KinAgPsxnMrsw = 1119837341; KinAgPsxnMrsw > 0; KinAgPsxnMrsw--) {
            LvmUdxLhYOtFMr = LvmUdxLhYOtFMr;
            LvmUdxLhYOtFMr = LvmUdxLhYOtFMr;
            LvmUdxLhYOtFMr = ! LvmUdxLhYOtFMr;
            LvmUdxLhYOtFMr = LvmUdxLhYOtFMr;
        }
    }

    for (int jiNBa = 1091981471; jiNBa > 0; jiNBa--) {
        dOqNDVodEB += dOqNDVodEB;
        LvmUdxLhYOtFMr = LvmUdxLhYOtFMr;
        dOqNDVodEB = dOqNDVodEB;
        dOqNDVodEB += dOqNDVodEB;
    }

    for (int wPILy = 655415919; wPILy > 0; wPILy--) {
        LvmUdxLhYOtFMr = LvmUdxLhYOtFMr;
    }
}

double WOkYIZeMsKwhpNq::RFmKPBy(bool gBZcZRpRmnD, string tZpbe, int TOCxXPjxgqfiMZFe, int EsbYGoQ)
{
    double JmMNhZnBrxqL = -813363.2618257005;
    int TtCBhjamw = 1824555764;
    double dKCZgWkkrxK = -463085.10911614477;
    bool EAeNb = true;

    for (int NIswWISPRxHgrtM = 136124106; NIswWISPRxHgrtM > 0; NIswWISPRxHgrtM--) {
        continue;
    }

    for (int mXaBeU = 423850572; mXaBeU > 0; mXaBeU--) {
        continue;
    }

    for (int xfBCFg = 1741337167; xfBCFg > 0; xfBCFg--) {
        TtCBhjamw += TOCxXPjxgqfiMZFe;
        gBZcZRpRmnD = gBZcZRpRmnD;
    }

    return dKCZgWkkrxK;
}

void WOkYIZeMsKwhpNq::YbhpQaZ(int IVfgRHdtJZkCyo, double HZsPNZS)
{
    int AOtCVZFcujXqJZ = -1174958877;
    bool TiQlL = false;
    string VlBPOoovNimpOf = string("XbWBulmnqNNAOUdFcNMJXvOcWYcVereDbmSbFfAXifgPosiOLtMFLFitxhNsZyfDHPCRqdEYeLAivGowOltNyALKlEZPSvlAaralvHgmWCMAQnrfhRxvAdnndDTYCBKQzvsbPtWFyEnTJIUjkCWrihRvEUbZaVrChyxAVZzwFNJAfcNIwFPbBVzRNjNlYfjupOevRXFvbTtXWlh");
    bool AXVfE = false;
    int qqfNdw = -974865827;
    double ZonWH = 459666.9543819509;
    string JKNsCwseebtyPeGG = string("TtdCmsVlqlwgTPIguimKPQuZtcWVWKmIKlPnJVQMqPdODUznKJYztcLigdmoYliYaFzXNfYerVWzdSWSrUTmUgObpSfKF");
    bool jHYnwENRYlUQmgb = true;
    bool iSRXBrUKBim = false;

    if (AXVfE != false) {
        for (int vezcKrCtfxG = 2088375312; vezcKrCtfxG > 0; vezcKrCtfxG--) {
            ZonWH = ZonWH;
            AOtCVZFcujXqJZ /= IVfgRHdtJZkCyo;
            AXVfE = jHYnwENRYlUQmgb;
            IVfgRHdtJZkCyo += IVfgRHdtJZkCyo;
        }
    }

    if (VlBPOoovNimpOf == string("XbWBulmnqNNAOUdFcNMJXvOcWYcVereDbmSbFfAXifgPosiOLtMFLFitxhNsZyfDHPCRqdEYeLAivGowOltNyALKlEZPSvlAaralvHgmWCMAQnrfhRxvAdnndDTYCBKQzvsbPtWFyEnTJIUjkCWrihRvEUbZaVrChyxAVZzwFNJAfcNIwFPbBVzRNjNlYfjupOevRXFvbTtXWlh")) {
        for (int RxvPBsc = 1581759926; RxvPBsc > 0; RxvPBsc--) {
            continue;
        }
    }

    if (jHYnwENRYlUQmgb == true) {
        for (int yXrwqTVMUlfj = 335907553; yXrwqTVMUlfj > 0; yXrwqTVMUlfj--) {
            AXVfE = ! iSRXBrUKBim;
            iSRXBrUKBim = ! AXVfE;
            AXVfE = ! jHYnwENRYlUQmgb;
        }
    }

    for (int LqKZRiYTdaEzfxM = 599681689; LqKZRiYTdaEzfxM > 0; LqKZRiYTdaEzfxM--) {
        continue;
    }
}

double WOkYIZeMsKwhpNq::UuKEUxSRrQr(int qgGZGlvTWlfzbNJD, string EVheAzSXUZbZS)
{
    double vAWbGZMSkVJbmhjT = -376881.01164372853;
    bool qeksCXK = false;
    int jTPRDlVaMQBaJpw = 901011958;
    int ObLcKW = 125708529;
    int jyrMm = 1416959659;
    string RfjDbgsGlOFd = string("RGpRnditYLbgsVMXJnlQjVKYvJQzXQxPKVxUhIdBYvZaDmXBVRuYpiaevPuoSTsXOPpNWcknyhhgZycGxRaxBlcmQgHZbStmWYClryThlVwsCCQtqUwzujdgCNSXLqFqPrVwsFMKkXFGwwaRgT");
    bool YbyvVZI = false;
    string oFRZwRSOdE = string("rCGQxVMOvrbEPkNbVmpPTaeogHejmutHTKJttnlEeTkuPvuVmCfKVhpACoCaEhW");
    string EquXWt = string("rszjWKMYeXuSXcajKPyiVsHnhZYaDkVLgFtb");
    bool TAoMNRNSnlIKIci = true;

    for (int QDtyWIqGdBcFD = 1564339855; QDtyWIqGdBcFD > 0; QDtyWIqGdBcFD--) {
        continue;
    }

    return vAWbGZMSkVJbmhjT;
}

void WOkYIZeMsKwhpNq::HzRcgVeduq(int HenMvgjve, bool EETlJRHrHnMAad)
{
    string ypObN = string("uLFVxNlCeDQumgkYCxrSUFsoSwRuhUPbEpuFQzmEZWJoWLeOOBsCGjbVUSDeaSgJJHQxdFSHgrrDMqhxIuAJkQcbqcLedZjfEnChrgoexmESFCWVesavVWYhKPBYdtcDxnjhfTzdAxmeEBjBHwYPuGZtQZgXfJTOdODMUHMFEqYGZlZqpIoaAWzsBJikOsdffPGEbLesTh");

    if (EETlJRHrHnMAad != false) {
        for (int cBYyEvTcTJvHg = 1514259020; cBYyEvTcTJvHg > 0; cBYyEvTcTJvHg--) {
            HenMvgjve /= HenMvgjve;
            EETlJRHrHnMAad = EETlJRHrHnMAad;
        }
    }

    for (int RrqmhOmCZv = 1243821783; RrqmhOmCZv > 0; RrqmhOmCZv--) {
        continue;
    }

    for (int YbJxHgA = 1959080841; YbJxHgA > 0; YbJxHgA--) {
        EETlJRHrHnMAad = ! EETlJRHrHnMAad;
        HenMvgjve *= HenMvgjve;
        HenMvgjve = HenMvgjve;
    }
}

string WOkYIZeMsKwhpNq::MyMaqfTNCZmCsF(bool hJInZJovFYUL, double fDJveSkpmFgdPtmw, string gPREMWj, double MdctrxDQb)
{
    int XmxgnyZQ = -1777780141;
    string HhuaJFZDYNkVrqT = string("bsaqmaVGBcAFIBpPIVeDNwHfKLd");
    bool nAdheXi = false;
    int wXLnvDDsaX = 113064742;

    for (int egTXoLSJzaMBmYnE = 1633954698; egTXoLSJzaMBmYnE > 0; egTXoLSJzaMBmYnE--) {
        hJInZJovFYUL = nAdheXi;
    }

    for (int TGDItF = 1686418245; TGDItF > 0; TGDItF--) {
        hJInZJovFYUL = ! hJInZJovFYUL;
    }

    for (int cGROOzNxKzCoEG = 1147111567; cGROOzNxKzCoEG > 0; cGROOzNxKzCoEG--) {
        continue;
    }

    return HhuaJFZDYNkVrqT;
}

bool WOkYIZeMsKwhpNq::sBDdjEUgGdWqPNS(bool yaFBQhlZmMh, string SixEMm, string PdKLwIu)
{
    int dfcfpaQasjQDgv = -1439681675;
    bool EfFsqHm = true;

    for (int YfYHtdfXdQ = 1079941716; YfYHtdfXdQ > 0; YfYHtdfXdQ--) {
        continue;
    }

    if (PdKLwIu > string("MhpkhNprPEtXWjVXdRuJmZgNejLDeOJNIvuLILPDAJYVZsPwogEUlliQEdPQrbRdhCDEMcOkthKfCNyFdmEiysWwDboiDdIeWRqVPJgGMtlnQg")) {
        for (int mujAIjbRmzSYupR = 667461908; mujAIjbRmzSYupR > 0; mujAIjbRmzSYupR--) {
            continue;
        }
    }

    return EfFsqHm;
}

void WOkYIZeMsKwhpNq::fSokgCX(string wfoUzOWbZkYjRZ, double IyHdaQGELXhSPl, bool muTgEvNU, string WFomRAUb)
{
    bool gUxLQ = true;
    int gIvShpXWFZ = -822828466;
    int cruZNhKjjECbYH = -862699476;
    string hDfzjZRE = string("RlSbArCdNTZFUwJnQWABEdBpGdATxwBBNhkLoVxMSwfBUUldjdQZlwEJmkXOAhJxjWCGDrCcxHMFBIsYfVxQqrzozwFxaznMZwxLyaHqoDZVvdAsZqwhIPepOZjLyYMGheApRbgYumFDclZmdezFwAuIWCZAwyfAsFKD");
    double OdTUDiuDFfp = -583255.8887291459;

    for (int XFDKEWxU = 1727732998; XFDKEWxU > 0; XFDKEWxU--) {
        OdTUDiuDFfp *= OdTUDiuDFfp;
        muTgEvNU = muTgEvNU;
    }

    for (int DOtgOKt = 2024127554; DOtgOKt > 0; DOtgOKt--) {
        continue;
    }

    for (int VwwgUuKSoPg = 1147316407; VwwgUuKSoPg > 0; VwwgUuKSoPg--) {
        muTgEvNU = ! gUxLQ;
        IyHdaQGELXhSPl -= IyHdaQGELXhSPl;
        wfoUzOWbZkYjRZ += WFomRAUb;
    }
}

void WOkYIZeMsKwhpNq::WkIas()
{
    int AXeydG = 1286766404;
    double teprlANYu = 896397.521796203;
    double PJYBU = 643804.1106709973;
    int zOJnMKzOMibrFJo = -91069068;
    string xxBoySJymmYooV = string("wudKDKrsqtOycmSYfr");
}

bool WOkYIZeMsKwhpNq::KOiOeGfEYvoYMr(bool Twnan, double uMyfImuQFnQzheq)
{
    int BHiKokSAPUG = 1754942270;
    bool RKKpETxxTHCle = true;
    bool DAztusJpdXVzIau = true;
    int ZIbRehIpLtD = -1610239670;
    string YDxjQlF = string("olCgVKcjdjDObmARXCtZATTvJJBUCQOMuYeNCiUOm");
    int mUvJESKwfE = 622738773;

    for (int AQkAvsIF = 1130041173; AQkAvsIF > 0; AQkAvsIF--) {
        Twnan = Twnan;
    }

    if (DAztusJpdXVzIau == true) {
        for (int iaaqUawnkxiqx = 1016135380; iaaqUawnkxiqx > 0; iaaqUawnkxiqx--) {
            continue;
        }
    }

    for (int hiJtxysihmjilm = 1823416191; hiJtxysihmjilm > 0; hiJtxysihmjilm--) {
        Twnan = ! RKKpETxxTHCle;
        YDxjQlF = YDxjQlF;
        RKKpETxxTHCle = Twnan;
    }

    for (int eECZdHMTEmoWOi = 1331999426; eECZdHMTEmoWOi > 0; eECZdHMTEmoWOi--) {
        continue;
    }

    if (RKKpETxxTHCle == false) {
        for (int NMyavVWCXdpwVG = 825016843; NMyavVWCXdpwVG > 0; NMyavVWCXdpwVG--) {
            YDxjQlF += YDxjQlF;
            mUvJESKwfE = BHiKokSAPUG;
        }
    }

    for (int TwmnuqLoQDBJVHX = 602213321; TwmnuqLoQDBJVHX > 0; TwmnuqLoQDBJVHX--) {
        uMyfImuQFnQzheq = uMyfImuQFnQzheq;
    }

    return DAztusJpdXVzIau;
}

void WOkYIZeMsKwhpNq::UhCPJmylSXlWGdc(bool eFLWynGKRwJgkHb, double awBMWgUY, bool kMTuEpw)
{
    bool eWntHB = true;
    string tiBxKXhodt = string("kTSsgRjYJpkvvpDdlVcLdhwtszqHHrgaUKxzGfuapqDpaoamZikolfukQtsylIBECrctlejIXwjpBiYWlMHu");
    bool BuBcqcLdjOeJCh = false;
    int KDPGO = -1161743495;
    string KIkLzfz = string("yeAckrhtoHGrlQCLyvWCSIzyWVzOECPtuRiJCZXuwjHkwNDCWGacCMAqsztShkoNHHlpHyqaulayOFtZIzroavDqPaohnIyosiXLnRBXXRrUwXwYqpjUlfMMmbXplMEOJWaIErQvcvrPnFnwEBlPsUOolaTCUsgSbrbXihzOmwOXmMrXzuTbPJdpdnxzaBUSaLfPvVIBmLhGrlcawjyzcLaZFUbcOMTshCQJVXY");
    bool KBlpTTFuXoWr = false;
    string orJIJlLdQHisu = string("rMLMPBvaJStttVhMEGAAswbrejCCerosAahIkUyrxhjuhKSyzKcWNmMRxcEtogQgmfrMROXiJEDYPbhyEptTxdNUCMqxKHqqeujslNKzfIjIsuuvAVCGbrNuIukCVsTouTqjKKhQpNhsss");
    double TrMFfItUmXABopYH = 143689.74549902478;
    int MrziEiBB = -844101320;

    for (int kWyWAAMgBGGZAb = 1430139861; kWyWAAMgBGGZAb > 0; kWyWAAMgBGGZAb--) {
        BuBcqcLdjOeJCh = ! eWntHB;
        BuBcqcLdjOeJCh = ! eWntHB;
        eWntHB = ! kMTuEpw;
    }

    for (int ArMIgIvoSTF = 2057460996; ArMIgIvoSTF > 0; ArMIgIvoSTF--) {
        KIkLzfz = tiBxKXhodt;
        eWntHB = ! KBlpTTFuXoWr;
        orJIJlLdQHisu = tiBxKXhodt;
    }
}

WOkYIZeMsKwhpNq::WOkYIZeMsKwhpNq()
{
    this->wvBqY(-355212.6024825968);
    this->FQhVyicpvJ(901800.5604499696, -614977.6785954731);
    this->eeGaUkhBnhhVjU(string("DwdxswbxiKxRKYLkChbNLaWoPeNEXhDoohnTefZIkEljQJbShhEuomAGHMMraSiyWzsKsTfEItJQJvuFoaXpCJIFbatHoMeztayygmkJpYRgHWabPZQGDOJW"), string("IvTXokCkJVWsAlesakvPLoyZkAKvbHPCFlccRkwkJIgZeFsuhwsYYLeGuahUGVLxysTSuQKDaVULMFdnzKOBWDnzgHTQiAoCYMoyFlAGZBqQRtfEmGkTkaAEmQEXFTyOfycrQLeAzPpkbecQNiPasnFHRDedLAoguNAYLyNitdjpyrsWaeYDCgcfEUAFvRnZyoTGzkAhBrhIJYCL"), false, 521184.8003612468);
    this->FxkYsmjsbsndh(-1520260589, string("echaVfamltjXmDoxRxnJsQxsZJYoVDxxdivJfWNglzYEAdRlxFfRuRUvkTLsbxJJfysugzezRwuzOhdIjEAFRtOXF"), true, -681341009);
    this->XSPYjRQD(string("TlPxvzVQfhFgFIVyEcYTzGRQhDsvQJsHbLyoQhCAwpuuAcxOEhgNusHMWdulelnpuBkwtyoxkVCnLtNgCMwHjDPaCfdXloijIoyvZLGaGGSbs"), -1044107599);
    this->oqCSrGBEloaCkc(false);
    this->RFmKPBy(false, string("lqqyCOKnPVerfboBMeojacbmCfmPBUkmhGAdZbUGyQlyBtmngKIxmMdqWLHuAtSomYfhgFoLmwzacuUolegxgLBcVImRBuoZGOVTCgMmtfCtrPvJuVhBXIhPJNCWUaZLDPUwusExixeVqmReWjdggfyWmfuPSNITEcOEWLeVFjoiuclZMfeQVoLnXpfdcMRQPjco"), 734629086, -1164867712);
    this->YbhpQaZ(1352070922, -485254.8687238286);
    this->UuKEUxSRrQr(-1959495885, string("AOYpNyeEPDGDFErWvBvrYPaEyinWsBaPJWAXbHRKTBKPWlXUHXjRphLSlcMZpgnBDcYdbjkrngkUUZMeaNQaDNgoDazeWuzjAkfnxrcvjlVmnYgqkahhkLgGGZnQMwlJD"));
    this->HzRcgVeduq(-582464160, false);
    this->MyMaqfTNCZmCsF(true, 626869.4019328505, string("qBZtICrwenhaJZEaVahxITicTEmGLUzmlPQwHDQfacpvHVrXwzjEhjiyAOtOcaOSHqRiUVPeezwNSnvgDOjfzBfWDZPUnwrChuNEvZYNungCKxpiSLQoNNHhsZPRQbhpjGuPNdaCqogeFgbb"), -237808.8206019114);
    this->sBDdjEUgGdWqPNS(false, string("MhpkhNprPEtXWjVXdRuJmZgNejLDeOJNIvuLILPDAJYVZsPwogEUlliQEdPQrbRdhCDEMcOkthKfCNyFdmEiysWwDboiDdIeWRqVPJgGMtlnQg"), string("joKiyAPJtXzvjGnIAWsiojCxnhwFFIceTYeXpJMHdDZKAVFbvNXiFOtEryhrqspOMqbSpbkfNuVaHpwybmQsSkGjmpAcvZuNERIIcbFyZcBfDFeKFNtGSPOvLNbIEOvVVJyzbTgjPGrWyjQNhfBulpTjXaYFltgcWBIvauaWUwLEdEAQaUHPaYJtbzwKaxAsnQKcmLQSXQjEXINrPzVouDlyrqmNNEhm"));
    this->fSokgCX(string("NfxhtbkBVFQgSCGShlP"), -580378.6250757932, false, string("PSNoJzOOwXbMHIvpCkBBNcRXJEyQlfzhqwvJwnH"));
    this->WkIas();
    this->KOiOeGfEYvoYMr(false, 366298.50865679316);
    this->UhCPJmylSXlWGdc(true, -229659.93413821276, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JZNrCokkBo
{
public:
    double JAClQ;

    JZNrCokkBo();
    double RszZBRqIlJ(double ztWPQTm, int NbxgxfYaQKEqpKL, int tbNRlbvqLUla);
    void dFohGqkRm(double bbYVICni, int jSUenoACRfm, double WvkXiHIivm);
    int kcxNamKsMXkWsU();
    string UjyXT(double GhrRVnWmbu, string ThRubWoF, string lGfJXJdrjwJVmL);
    double yQgHey();
    string IFnDWOYQhSQJyaux(bool HhfjVcNlW);
    void nhozefvAyaCLQLEY();
    bool RODQLBphqfCzBysQ(string cnQjiBF, bool QuDAyto, bool APSXSjmmSVBtagx, string alwbcumu, bool KAPVKKKuWQIrLpU);
protected:
    double plUgEUSfM;
    bool UIbEMCbRgah;
    int NoPDJsnFnIXK;
    int VdfYjBLbP;

    string RuZAYaTXPbThXFW(bool xumXDVvP, bool BAaiNAkHiw, bool xDXMe, int OzJXEsgcFjRSS);
    string nzRQNaHu(double nZJjmEsivRnEz, bool krJkUlOk, int gKgWUyUZJRuq, int lDRCYRDbhEYcp, string UNmSsd);
    string CBsnLYi(bool oEBPt, string opvozORuBpnVgrEB, int ZkwLTaap, bool cJdFDf, double UuSPlicvfPzJJ);
    int dyLZaTSl(bool xehbFyECvq, bool HSfzlmAQy);
private:
    bool WVQIhJfyzS;
    bool HViOMeVDGNhvz;
    double RNprPd;

};

double JZNrCokkBo::RszZBRqIlJ(double ztWPQTm, int NbxgxfYaQKEqpKL, int tbNRlbvqLUla)
{
    int KMyNf = 1883722827;
    double TcmPGcAkWeDWqGjY = -408477.5346979152;
    double CZdTqe = -657082.1660317023;

    for (int SOnqyDxhkZC = 1437738642; SOnqyDxhkZC > 0; SOnqyDxhkZC--) {
        ztWPQTm *= TcmPGcAkWeDWqGjY;
        NbxgxfYaQKEqpKL -= KMyNf;
        NbxgxfYaQKEqpKL = KMyNf;
        tbNRlbvqLUla += KMyNf;
        NbxgxfYaQKEqpKL -= tbNRlbvqLUla;
    }

    if (CZdTqe != -779577.9627932608) {
        for (int zykuSIJFBWg = 1633041044; zykuSIJFBWg > 0; zykuSIJFBWg--) {
            KMyNf = NbxgxfYaQKEqpKL;
            CZdTqe = TcmPGcAkWeDWqGjY;
        }
    }

    for (int BpqyKg = 721146435; BpqyKg > 0; BpqyKg--) {
        ztWPQTm /= CZdTqe;
        NbxgxfYaQKEqpKL -= NbxgxfYaQKEqpKL;
        CZdTqe *= ztWPQTm;
    }

    if (ztWPQTm >= -779577.9627932608) {
        for (int IUmygwEDZX = 1867427952; IUmygwEDZX > 0; IUmygwEDZX--) {
            tbNRlbvqLUla /= tbNRlbvqLUla;
        }
    }

    return CZdTqe;
}

void JZNrCokkBo::dFohGqkRm(double bbYVICni, int jSUenoACRfm, double WvkXiHIivm)
{
    double AHFUHqKNS = 299732.1299803667;

    if (WvkXiHIivm == 310919.25498189585) {
        for (int xOvNRs = 1091484670; xOvNRs > 0; xOvNRs--) {
            WvkXiHIivm -= AHFUHqKNS;
            AHFUHqKNS = WvkXiHIivm;
            bbYVICni /= AHFUHqKNS;
            bbYVICni -= bbYVICni;
            WvkXiHIivm *= WvkXiHIivm;
        }
    }

    for (int EHwssOGpsPof = 1320479492; EHwssOGpsPof > 0; EHwssOGpsPof--) {
        WvkXiHIivm -= AHFUHqKNS;
        jSUenoACRfm -= jSUenoACRfm;
        jSUenoACRfm += jSUenoACRfm;
    }

    for (int wxsjfYHxu = 801868792; wxsjfYHxu > 0; wxsjfYHxu--) {
        jSUenoACRfm -= jSUenoACRfm;
        AHFUHqKNS = bbYVICni;
        WvkXiHIivm -= bbYVICni;
    }

    if (AHFUHqKNS != -742603.5592432413) {
        for (int fNhRXZWVkhxDWKXN = 159004011; fNhRXZWVkhxDWKXN > 0; fNhRXZWVkhxDWKXN--) {
            WvkXiHIivm *= bbYVICni;
            bbYVICni += WvkXiHIivm;
        }
    }

    if (AHFUHqKNS == 310919.25498189585) {
        for (int kDxanmtM = 288017167; kDxanmtM > 0; kDxanmtM--) {
            bbYVICni = WvkXiHIivm;
            AHFUHqKNS += WvkXiHIivm;
            bbYVICni *= AHFUHqKNS;
            bbYVICni /= bbYVICni;
            bbYVICni = bbYVICni;
        }
    }
}

int JZNrCokkBo::kcxNamKsMXkWsU()
{
    string TaVnY = string("qQmFABhaksQjFuJyTmWPqxaGkqNpXZIrHQrKC");
    double mLXoheScYQjTo = -490410.95905575855;
    double jXewewZJg = 745940.6589400164;
    int JQXzHkix = -756006236;

    for (int wFQGy = 36767314; wFQGy > 0; wFQGy--) {
        jXewewZJg = jXewewZJg;
        mLXoheScYQjTo += jXewewZJg;
        jXewewZJg -= jXewewZJg;
        JQXzHkix /= JQXzHkix;
    }

    for (int clZGoOhOVRj = 1541490423; clZGoOhOVRj > 0; clZGoOhOVRj--) {
        TaVnY += TaVnY;
        TaVnY += TaVnY;
        mLXoheScYQjTo = jXewewZJg;
    }

    for (int TPjKUGhUMFNJ = 233798735; TPjKUGhUMFNJ > 0; TPjKUGhUMFNJ--) {
        continue;
    }

    if (mLXoheScYQjTo >= -490410.95905575855) {
        for (int WFLUBSLjZhe = 2097646267; WFLUBSLjZhe > 0; WFLUBSLjZhe--) {
            mLXoheScYQjTo /= mLXoheScYQjTo;
        }
    }

    if (jXewewZJg != 745940.6589400164) {
        for (int vylJtxqqT = 697011039; vylJtxqqT > 0; vylJtxqqT--) {
            jXewewZJg /= mLXoheScYQjTo;
            mLXoheScYQjTo = mLXoheScYQjTo;
        }
    }

    return JQXzHkix;
}

string JZNrCokkBo::UjyXT(double GhrRVnWmbu, string ThRubWoF, string lGfJXJdrjwJVmL)
{
    int TXSaQYI = -1963177588;
    bool OMXKUPtz = false;
    double tNzDrqjeQzSaqUkc = -67745.55131475542;
    int DjZdRuOOorkipGF = 1820187255;
    int AyURPTPmVZKtuz = 393887428;
    string SHnkAOpWVTKOyh = string("uzYKKsilghDevajnKEMvAAZUaNxDgorlAXCGjlXzjwylwATlwBvgbBXoeRRWkmWqELaIEiHeKBswKudvLstWunIKzpYZIQKWKFzbtjbBWNhbzWpsHkbgKrZjltpdwoqcpClcUOzkuzHRdYNBeUSAAOPWEeRUGkCOnnjERElggKmQBLTgPTCsFIGZAfcNiJxlYFWlS");
    bool LNoduZqatT = true;
    string gmeEnf = string("TqPonBwuxdHONtMbZQtHBcvnSmDcHNtiuwwVjAesPOUVHzXIWsnxLXpWevOWMWUzXcifhbCcgGwimHGOTibXEknpfJhJyJxUAQQGPkbRtaLsQXpCZJzFfwJlXZcmYtHluyLhFxTICVzvmKRbzBRckVuGdjjiWKgxMeCyskAJGuusEqsujxEwaysRmBTYRbqFYntOyZFjfnzqSTgnyHwDziGNSNtyoQINUyOLiUnJQHplVWAwTOzuSztlYhLfR");

    for (int PdoJUwNIJJ = 1290334811; PdoJUwNIJJ > 0; PdoJUwNIJJ--) {
        DjZdRuOOorkipGF = TXSaQYI;
        GhrRVnWmbu *= GhrRVnWmbu;
    }

    return gmeEnf;
}

double JZNrCokkBo::yQgHey()
{
    bool vCxVjTRKgwN = true;
    double qYFPg = 990646.8267249728;
    string maYLuConMO = string("EPUUpWuqklxEWokffZKUnNISCZlmwUKbcPqPnJpPpltuiWUUtFraFHXEUYRZpPGmstHsXStyZNBnEeWfkTigHdJaDBxELbksUXCZDleusXzIRTWXTofKIQjTJoVanLwwOrCOaqsbfzkpDFFpQAZefghaSxCrQMKdTKbefREXLetWSEhTAIVEAuwVeoIiHBzkAWFLepOaDNdzUOtMWtniRgdsVlztziU");
    int wtzTVxYPIVGUTJ = -1523995026;
    bool MYlPogE = true;
    string EIMAYBqpCV = string("gjbXpRwjvohFQOWGPdliIYBgNWwTnpyMWpeFYRLCXyxoMgkjWBCQXOdUaEjBh");
    bool qDsjzxaKUbV = true;
    string AqNOIUBMMuOpR = string("SfCdZsywxsPPfXkKItpkwszNHgtsGqaKqqIHOKmWaIqaWuqqBwEItzCLvFAQYedF");

    for (int HqUHyzKcNR = 714649659; HqUHyzKcNR > 0; HqUHyzKcNR--) {
        continue;
    }

    return qYFPg;
}

string JZNrCokkBo::IFnDWOYQhSQJyaux(bool HhfjVcNlW)
{
    string TJasr = string("aiFJMrzsiFskFjJGmQjDgORDCvYdeyurSkhTJRifZwLXCUYHqixADnLAaBbqVkCyHzyftKepGtzVAvTKlBfxFZwWwEzOaUMNiVIILkBEUCoglSggpPgUnNbZJ");
    bool xRvbewTMMGjS = true;
    int jnmeYYijvHbs = 295095521;
    string AwasnvAISz = string("cGJdjrnSLVKdBCkmZAAbASGhcDMzRTgdswdMaiYFXFOBBCVKcXjMgPrSoPXbreMtBKdZKsYcMeFPnBxycfElHSdkoYftAlZdcrjZUaqoRVblzfZpFaNEakmOI");
    string quJERClHibjL = string("IHPJNhLIIEjYxHFgilkKhVTSlDkEtMboJhubCMIrUEFhwpMpgWXZxWBEJpaWnvjxYmTtXYeo");
    string DAjHUmm = string("yeHvfbtiiIDYZImaCCCKtcztPqaFsnOREJxkyQr");
    int RQOECCm = -1359392108;
    double fyeGTZnoIhwwg = 938033.7282835612;
    double Hgbor = 393894.18752967054;
    int tkoQFdMKITHuZn = -1739223503;

    if (fyeGTZnoIhwwg != 938033.7282835612) {
        for (int KgtqSfRRUzINbC = 837459106; KgtqSfRRUzINbC > 0; KgtqSfRRUzINbC--) {
            DAjHUmm += TJasr;
            quJERClHibjL += AwasnvAISz;
            AwasnvAISz = TJasr;
        }
    }

    if (DAjHUmm >= string("yeHvfbtiiIDYZImaCCCKtcztPqaFsnOREJxkyQr")) {
        for (int esjOegpHESoBmGE = 1246539655; esjOegpHESoBmGE > 0; esjOegpHESoBmGE--) {
            DAjHUmm = quJERClHibjL;
            jnmeYYijvHbs = tkoQFdMKITHuZn;
            quJERClHibjL = AwasnvAISz;
            Hgbor *= fyeGTZnoIhwwg;
        }
    }

    if (quJERClHibjL > string("cGJdjrnSLVKdBCkmZAAbASGhcDMzRTgdswdMaiYFXFOBBCVKcXjMgPrSoPXbreMtBKdZKsYcMeFPnBxycfElHSdkoYftAlZdcrjZUaqoRVblzfZpFaNEakmOI")) {
        for (int ykVSYmWIOBokXH = 1808414257; ykVSYmWIOBokXH > 0; ykVSYmWIOBokXH--) {
            continue;
        }
    }

    for (int zgVEzBS = 1369275607; zgVEzBS > 0; zgVEzBS--) {
        continue;
    }

    return DAjHUmm;
}

void JZNrCokkBo::nhozefvAyaCLQLEY()
{
    string TdBiVa = string("SBVWGKNcEAJhbNfOhNuqGmpgCzxCidMUxcTopAqdMNzCkFMEZZdQpSLdrtZwYmFzAFGsMnJcSBWcZselKh");
    int ABWsOjfcnTtWenGO = 1582078692;
    int WTuZE = 1197826045;
    int kNtkysLpPsgeT = -1565740371;
    double RqPOUFooFYqfck = -1036708.9388861463;

    if (WTuZE != -1565740371) {
        for (int NypINURSjAKknwOd = 1846222908; NypINURSjAKknwOd > 0; NypINURSjAKknwOd--) {
            TdBiVa = TdBiVa;
            TdBiVa = TdBiVa;
            kNtkysLpPsgeT += ABWsOjfcnTtWenGO;
            WTuZE *= kNtkysLpPsgeT;
        }
    }
}

bool JZNrCokkBo::RODQLBphqfCzBysQ(string cnQjiBF, bool QuDAyto, bool APSXSjmmSVBtagx, string alwbcumu, bool KAPVKKKuWQIrLpU)
{
    int MgmXbGKI = -2077174545;
    string qbsMMe = string("PKXIVzTuisjUfzJpxzHCAVexUtKPGaxByoWwPGzJDfmbvuOHWLGSQQjskFOjFZVDZxszuWDWYBEcraFaWeL");
    double BdxFmgPTKS = 618704.8396438992;
    string eTRLqMazgqF = string("PMtdsKOFGwzrirlRFEBrZlWdpTOGWJVUwnibVVmgEJHGMDErKLDjDNxGJDIgqUBHvAqeGjsGLpdXnyDbHhInLQVgkYGpHNINoVDaDnCvDAHwMbEnfihcuDJNNmWEprzeLZvzVrMrJrI");

    for (int WkEye = 1336155986; WkEye > 0; WkEye--) {
        cnQjiBF = qbsMMe;
    }

    return KAPVKKKuWQIrLpU;
}

string JZNrCokkBo::RuZAYaTXPbThXFW(bool xumXDVvP, bool BAaiNAkHiw, bool xDXMe, int OzJXEsgcFjRSS)
{
    string nFMODzeJXc = string("UaYsTobDGgmSRgejWEEwbODMapNIcfKsMknfkoHnmEmbrdYGNtWEdqFUqaECJajllCOFmYvVZWYLeFukqBFahoxLkbOTRNeUVsSMKsYPfrCaYPXvSJbyfaLEWPAyWoateRnFYgsqVVuUhNduMoKyLvxItlzcwOdQZQqSNqYHiaAvQoWpKJDfXpSNzYpPMeuUpyxTMVnkRSDsszmapTIgDh");
    int mPJvUYcyXmQCtgW = -1826861847;
    int JgRVyhmCB = -1230145800;
    int uShDlTQkFYOyc = 620913447;

    for (int SqhzIFw = 572467623; SqhzIFw > 0; SqhzIFw--) {
        continue;
    }

    return nFMODzeJXc;
}

string JZNrCokkBo::nzRQNaHu(double nZJjmEsivRnEz, bool krJkUlOk, int gKgWUyUZJRuq, int lDRCYRDbhEYcp, string UNmSsd)
{
    double SLWAptR = -422792.0195107176;
    int jHiwkrlPyO = 1949546301;
    string JaGXVtRa = string("mFXHobenROEXHGdJMzIXUBqBjyylvOWNsQXSMGjxgaWIQiPJtSWuNiUHDVnckwYEgJcNIoCNTRLVvkuLLkuCMrroGMaDdyyyhCNxnqOcuXGwRYGUpVgKVAfhZFU");

    for (int GpCsgMZ = 1871889734; GpCsgMZ > 0; GpCsgMZ--) {
        SLWAptR += SLWAptR;
        lDRCYRDbhEYcp /= jHiwkrlPyO;
        gKgWUyUZJRuq -= lDRCYRDbhEYcp;
    }

    for (int teBkX = 627373167; teBkX > 0; teBkX--) {
        continue;
    }

    for (int fTuJbgJIjNthXrx = 17372958; fTuJbgJIjNthXrx > 0; fTuJbgJIjNthXrx--) {
        continue;
    }

    return JaGXVtRa;
}

string JZNrCokkBo::CBsnLYi(bool oEBPt, string opvozORuBpnVgrEB, int ZkwLTaap, bool cJdFDf, double UuSPlicvfPzJJ)
{
    string TmjAe = string("prEDfxjlzhKINyJNxzXUQjb");

    for (int WDjjgIBr = 204557773; WDjjgIBr > 0; WDjjgIBr--) {
        ZkwLTaap = ZkwLTaap;
        TmjAe = TmjAe;
        ZkwLTaap *= ZkwLTaap;
    }

    for (int HHAWDK = 2141762020; HHAWDK > 0; HHAWDK--) {
        continue;
    }

    for (int FqhUXIVkuj = 387377460; FqhUXIVkuj > 0; FqhUXIVkuj--) {
        opvozORuBpnVgrEB += opvozORuBpnVgrEB;
    }

    return TmjAe;
}

int JZNrCokkBo::dyLZaTSl(bool xehbFyECvq, bool HSfzlmAQy)
{
    double xVqzdWjOCoA = -209345.11100631292;
    string mHkRydxVFC = string("KDTYusvZXZVLkuItFqrrHyrkCRxeAyjjvGPPwInVqfUiqFvVlVuBEzPXrtQ");
    double cHPJVrDQqjEI = 551265.7930552529;

    for (int FOqVbY = 831623432; FOqVbY > 0; FOqVbY--) {
        mHkRydxVFC += mHkRydxVFC;
    }

    for (int ElsViKzymAtwNmX = 237628011; ElsViKzymAtwNmX > 0; ElsViKzymAtwNmX--) {
        mHkRydxVFC = mHkRydxVFC;
        xehbFyECvq = ! xehbFyECvq;
    }

    return 1944402689;
}

JZNrCokkBo::JZNrCokkBo()
{
    this->RszZBRqIlJ(-779577.9627932608, -694105677, 2107129244);
    this->dFohGqkRm(310919.25498189585, 1861636462, -742603.5592432413);
    this->kcxNamKsMXkWsU();
    this->UjyXT(653546.3545549773, string("HLYRPTwJzLdJ"), string("IQUSqwWyzvHOlVmuoAWvOqpIzUeaVLkFvMuJbhDPKFtfwRuDcRtVtMAMQYLULsnzlBreaQKMTsMqOqIxLFmbvwRcvYxomaLslofgYOxhIjIuIzoKeJkLjwordXLgwNGFQyupnGNgSfXXuLpalblFLtZqNFItQmJFqKePfwZLqKyPhLWrZatcYBPfMkoOQqsobYOUQRktHmCskNUqWqSZQQYaCTzGYioCeR"));
    this->yQgHey();
    this->IFnDWOYQhSQJyaux(true);
    this->nhozefvAyaCLQLEY();
    this->RODQLBphqfCzBysQ(string("lwooNyXseDUZJvFtOgZhldhWuqgxcwMclyqZfPoowIzCBKVcarAXjDAVBhUCCgUHKMPwJNzJVAcadsbDraIyFysBBKecNJkGSqJWAJkZYgMbmzbpzRBpRyAwRqXUysXLgAUCwOnuXCfVFUeNuvpAtHLLQSgTPghLLxPvplAxAviFCVBmThfnRzuOThWmcJwygSYOAzisbkkBWEvPYcAItBjOXRsNBg"), false, false, string("wPSyuIEmzWFdzCxXcQEeRIGWMptEM"), false);
    this->RuZAYaTXPbThXFW(true, true, true, -738272338);
    this->nzRQNaHu(274337.8014824635, false, -391684682, -570032605, string("PDJKNPRAonPJOrhXOoHNZgshzkOIbAfbmAlhQfcTPRmNfcZoVZWXqTOpvipQLUzYZlloWiYWLZGXmpsuYTLgetVIXLFVFdFRomyWVEOKlaJFKpJHuBSJglynERbzObMAkomOiOPgdxUf"));
    this->CBsnLYi(true, string("KqfDxKByPJrNtUThpSNUTTyZSpEoqJTOhJiatOgXEUmSrlCMRzcikVtLsfOCZVpNnXywVrcxuRfZrEMWvDPaZWKbTREJGCMuKgaEFvCgEdgqoyOghDkzLFaKFvfIgTuVnWPZXSUrWCyxZbNAoYpPHMDUsfnEJKeUgvNApdNraNHjlFumFNOjZdwzzTKmxGPJPgLnynbEMWvptxvZyhbAqqOByFcDrgNKREINDhsZ"), -701525727, false, -526226.9024602612);
    this->dyLZaTSl(false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NYMlMCVbsKaXJV
{
public:
    string tRjWplS;
    string poCtEqyb;

    NYMlMCVbsKaXJV();
protected:
    int rOxVClRWeza;
    string StyBK;
    bool ssErACEUBWHoCY;

    string izhYqwrRB(bool rEcWmubxsDtpfY);
    void PbesBUUASU(int rfYLl, bool jEMDFNxIglSNr, bool KjhSbhcbItHmd, int gFtHtOsJKfmD);
    void LOAihuSYe(int IlwgqeAQHvfy, double IwyBpqq, int tDDkCHfvHMgTYn);
    bool FpZTbUpGxSNz(double EgIyvwpytZviAc, string PvauPO);
    double PQwWjjBAFFfMl(int GSSAK, bool lUNARZBJYMi, string ZcVTQ, string nybUbOibFCWIzj);
    void HCEGkedN(bool QOilultvC, bool XTJdzXEnbbTHc);
    bool NJdHEYusjujQjCf(bool SMnLAqHABRVRJwhf, string kEeLZIaMIH, bool wmCESPdpx);
    string zZFXAuYBVDWDDd(bool pewRfp);
private:
    bool fsieHo;
    string ykqxaNTSYshrib;
    bool pDXZqf;

};

string NYMlMCVbsKaXJV::izhYqwrRB(bool rEcWmubxsDtpfY)
{
    bool gEvwwslh = true;
    double jMoVS = 460914.557310289;
    double VxbXQvHhOheqF = -177221.1593977966;
    string cklsVsX = string("KRBUakgZAfLwJgDpkEbLffcAHGwTNGrxihKhTznPaEWfYQuirkmtlhOzSkjsBQcGkXGOVPfKOPOLTfOgfxgqvCYvzieIARaalVedPcosNyzbvWgnMUzgxmiQIpSbQazEKLsuEaCiPrxDzJKJgIkVXXAqfRTYYZbCPdOOfbqAKNCHXONNDHPERHyhKhbvZVRLtRkMzOPfFmwfVWMJFUvqNzCbW");
    string nRWpanIogg = string("kFyCYcnGZydWSFFarzltsCNFkhDwroKiMyCtaICnmRDxiEXWZkEZGdNIZZLoCpMlLkAqOlHpFUiwLHCYPfKcnrCpgwgYxPXZHmyrMujQc");
    int rMFypHL = 237365997;
    double PCarTjoAtMyViyy = 487256.8282181591;
    int BGJPteURlO = 1135567301;

    if (rEcWmubxsDtpfY == true) {
        for (int YXoQj = 551699155; YXoQj > 0; YXoQj--) {
            PCarTjoAtMyViyy += PCarTjoAtMyViyy;
            jMoVS *= VxbXQvHhOheqF;
            rEcWmubxsDtpfY = ! rEcWmubxsDtpfY;
        }
    }

    if (VxbXQvHhOheqF == 460914.557310289) {
        for (int otmkGraWM = 119824578; otmkGraWM > 0; otmkGraWM--) {
            jMoVS = PCarTjoAtMyViyy;
        }
    }

    for (int NLPIkxJjARMEU = 798186808; NLPIkxJjARMEU > 0; NLPIkxJjARMEU--) {
        VxbXQvHhOheqF += PCarTjoAtMyViyy;
        BGJPteURlO += BGJPteURlO;
    }

    for (int ISmxtLVwcifSOC = 1093916215; ISmxtLVwcifSOC > 0; ISmxtLVwcifSOC--) {
        continue;
    }

    for (int dKojhL = 2030685366; dKojhL > 0; dKojhL--) {
        continue;
    }

    return nRWpanIogg;
}

void NYMlMCVbsKaXJV::PbesBUUASU(int rfYLl, bool jEMDFNxIglSNr, bool KjhSbhcbItHmd, int gFtHtOsJKfmD)
{
    bool GLYKCdMmqWCMiJ = false;

    for (int XoMhj = 1223118099; XoMhj > 0; XoMhj--) {
        KjhSbhcbItHmd = ! GLYKCdMmqWCMiJ;
    }

    for (int lhVRMCsyOl = 405877011; lhVRMCsyOl > 0; lhVRMCsyOl--) {
        rfYLl += rfYLl;
        rfYLl -= rfYLl;
        rfYLl *= gFtHtOsJKfmD;
        jEMDFNxIglSNr = ! KjhSbhcbItHmd;
    }

    if (jEMDFNxIglSNr == true) {
        for (int JkTdphlCk = 72571883; JkTdphlCk > 0; JkTdphlCk--) {
            jEMDFNxIglSNr = GLYKCdMmqWCMiJ;
            GLYKCdMmqWCMiJ = ! jEMDFNxIglSNr;
            GLYKCdMmqWCMiJ = ! KjhSbhcbItHmd;
            GLYKCdMmqWCMiJ = KjhSbhcbItHmd;
            gFtHtOsJKfmD /= gFtHtOsJKfmD;
            jEMDFNxIglSNr = KjhSbhcbItHmd;
        }
    }

    if (jEMDFNxIglSNr == true) {
        for (int BmybBOcgUtH = 175021936; BmybBOcgUtH > 0; BmybBOcgUtH--) {
            rfYLl = gFtHtOsJKfmD;
            KjhSbhcbItHmd = KjhSbhcbItHmd;
            jEMDFNxIglSNr = jEMDFNxIglSNr;
            GLYKCdMmqWCMiJ = ! GLYKCdMmqWCMiJ;
            jEMDFNxIglSNr = GLYKCdMmqWCMiJ;
        }
    }

    for (int ZTpkDaQBJYd = 10974524; ZTpkDaQBJYd > 0; ZTpkDaQBJYd--) {
        continue;
    }

    if (gFtHtOsJKfmD <= -535568382) {
        for (int tSObAqbonYqKFJxl = 469751765; tSObAqbonYqKFJxl > 0; tSObAqbonYqKFJxl--) {
            KjhSbhcbItHmd = GLYKCdMmqWCMiJ;
            gFtHtOsJKfmD = gFtHtOsJKfmD;
            GLYKCdMmqWCMiJ = KjhSbhcbItHmd;
            KjhSbhcbItHmd = KjhSbhcbItHmd;
        }
    }

    for (int VqCnntEqMdOmlGX = 1214676958; VqCnntEqMdOmlGX > 0; VqCnntEqMdOmlGX--) {
        gFtHtOsJKfmD /= rfYLl;
    }
}

void NYMlMCVbsKaXJV::LOAihuSYe(int IlwgqeAQHvfy, double IwyBpqq, int tDDkCHfvHMgTYn)
{
    int lFDmkgSF = -820627538;
    int OUJQZvguBHiL = -41173862;
    int iqdDecpw = 902199939;
    int NZulNOhcSscmw = -899912842;
    double xsSsqbqzbiwg = -918804.9821174028;
    bool MOKZoku = true;
}

bool NYMlMCVbsKaXJV::FpZTbUpGxSNz(double EgIyvwpytZviAc, string PvauPO)
{
    bool awZXeWBmPixsdYN = false;

    for (int DeMENsHHVqq = 550024759; DeMENsHHVqq > 0; DeMENsHHVqq--) {
        PvauPO += PvauPO;
        PvauPO += PvauPO;
    }

    return awZXeWBmPixsdYN;
}

double NYMlMCVbsKaXJV::PQwWjjBAFFfMl(int GSSAK, bool lUNARZBJYMi, string ZcVTQ, string nybUbOibFCWIzj)
{
    string eJAtGsdcJTt = string("UtoNLbPBCjAQnMmZzJwxixeEqEBQPqLvxAHcyarlucdApGRrYrTgpUaphdJpPdJtVhpfkAIFTVdZKSXsawydPxeMtnIOUwXXgHvKEAeQQpUPwsoctibzadvPNquePLmMKpwwmYuzFQtAhfqKWnvQdgRMZCGOBlpFHirIldCWDSXRVLmLSFzdiWQidMprKoZejHMnijaTFIstqqMJcxBpbjZGXzEMzvI");
    string uPiBWzgpAaTQd = string("JYUudiGkyPRKFEtkxcoGRmAVdJCiZkdQjhngyZlVDtPsXVAFCecnvdrBDqdTTQoUaZXGAGoLzvocvmZYIzfQkiNLUiBDJNWMzHbTpzEGXjHHFLqxhNruIcUDZupUrxOCjdSpPZMYpKQdFgVZAHzykbYYsvdIlxyKvoFnrlsNeNYKNXutOHOidXRjlrMPuYp");
    double ExYXOziRAqnJCe = 374256.18223637424;
    bool ihQfDEI = true;
    string RIsRE = string("tUlEkBZVXQvJNrKhasEqtFeHRLeVXYelusMLrQwHMFLrkbUnjoyHfyzjePTTkMKNgCdTQghPzeAnXtXKsmuNSunfldsTZaXoPzWuOyxbqLSwdkpnPhruTwuJkGlRXpJomSyMoYqCXoNzBQQZdYbxKinVbvShfTexYRlOnuCHWuPYCoaLYDLyJvDvDxtopNKnpWQGeweXfRNJBatEYgTUyOesBgXreZrxkNuIxBwBhzJwQbBM");

    if (RIsRE > string("UtoNLbPBCjAQnMmZzJwxixeEqEBQPqLvxAHcyarlucdApGRrYrTgpUaphdJpPdJtVhpfkAIFTVdZKSXsawydPxeMtnIOUwXXgHvKEAeQQpUPwsoctibzadvPNquePLmMKpwwmYuzFQtAhfqKWnvQdgRMZCGOBlpFHirIldCWDSXRVLmLSFzdiWQidMprKoZejHMnijaTFIstqqMJcxBpbjZGXzEMzvI")) {
        for (int ikxlPaxSVkQiaF = 791686016; ikxlPaxSVkQiaF > 0; ikxlPaxSVkQiaF--) {
            uPiBWzgpAaTQd = eJAtGsdcJTt;
            eJAtGsdcJTt += ZcVTQ;
            RIsRE += uPiBWzgpAaTQd;
        }
    }

    return ExYXOziRAqnJCe;
}

void NYMlMCVbsKaXJV::HCEGkedN(bool QOilultvC, bool XTJdzXEnbbTHc)
{
    string cDnTU = string("FuUrUwglmkPwgLMipiUEOrLOaCsDjsIRrdlbbszwmdGPfDnrlAQtnGXuTpuTbREMXZfTiAbIzTriDqZESOGZVoGxwDiPJhrY");
    int qGBQDfh = -2102369506;
    bool FXXqJmfAkxfw = true;
    int LgarYcNnsbgk = 1225613083;
    double eHoWVcQ = -953267.8391682084;
    int oZKNGRtGHk = 1676924219;
}

bool NYMlMCVbsKaXJV::NJdHEYusjujQjCf(bool SMnLAqHABRVRJwhf, string kEeLZIaMIH, bool wmCESPdpx)
{
    double JKWhhNsOzTgmOH = 280262.82350789406;

    for (int UAUavmRTiOup = 1641972284; UAUavmRTiOup > 0; UAUavmRTiOup--) {
        continue;
    }

    for (int PhqwoD = 794859169; PhqwoD > 0; PhqwoD--) {
        SMnLAqHABRVRJwhf = ! SMnLAqHABRVRJwhf;
        wmCESPdpx = SMnLAqHABRVRJwhf;
        kEeLZIaMIH = kEeLZIaMIH;
    }

    if (SMnLAqHABRVRJwhf == false) {
        for (int xrWpBIaP = 1172298591; xrWpBIaP > 0; xrWpBIaP--) {
            SMnLAqHABRVRJwhf = SMnLAqHABRVRJwhf;
            wmCESPdpx = ! wmCESPdpx;
            SMnLAqHABRVRJwhf = ! SMnLAqHABRVRJwhf;
        }
    }

    return wmCESPdpx;
}

string NYMlMCVbsKaXJV::zZFXAuYBVDWDDd(bool pewRfp)
{
    bool EwdZxXamHPch = true;
    string CQKPZ = string("oBRkbUZFvYSNMYNJoQpgEBgpDqNWkzmjTxOohQuCaLiVDgHYNDWWZavFZNkBALYIyOeTpLkZdFAlGHSSEFPjcncwZgsqKndGytvlfWCvOXpyXvDtpNHSXawtadQfdxJNeiZwpYoANHQXzBnnuEvICRqEoukMxbREjzjnGWNEUEoSzKybVEGfmlIbqpGCnQWxkJMXaizryDpBZuCWqNGJWijNXpmbnLwlpFcbSWK");
    double HCbYoAlNyPCDWIni = -215428.03138750428;
    bool NWSflRUAAosnqvP = false;
    int ajABRDCLREPsB = 2041589646;
    double rYIKMOHxboeNci = 836047.5702616076;
    bool TQsYx = false;

    if (pewRfp != true) {
        for (int OvRbNoWwEvxzBaTk = 892359434; OvRbNoWwEvxzBaTk > 0; OvRbNoWwEvxzBaTk--) {
            continue;
        }
    }

    for (int UrYQii = 101864490; UrYQii > 0; UrYQii--) {
        pewRfp = EwdZxXamHPch;
        pewRfp = pewRfp;
        pewRfp = NWSflRUAAosnqvP;
        CQKPZ += CQKPZ;
        ajABRDCLREPsB += ajABRDCLREPsB;
    }

    if (HCbYoAlNyPCDWIni >= 836047.5702616076) {
        for (int TvbNQhuulMOuuRAC = 1560824125; TvbNQhuulMOuuRAC > 0; TvbNQhuulMOuuRAC--) {
            rYIKMOHxboeNci += rYIKMOHxboeNci;
            NWSflRUAAosnqvP = ! EwdZxXamHPch;
            CQKPZ = CQKPZ;
        }
    }

    return CQKPZ;
}

NYMlMCVbsKaXJV::NYMlMCVbsKaXJV()
{
    this->izhYqwrRB(true);
    this->PbesBUUASU(1184440147, true, true, -535568382);
    this->LOAihuSYe(-1037798613, -138394.01549458865, -1956206717);
    this->FpZTbUpGxSNz(-79139.24280549433, string("IKMRDfIwxovciXdgajAezEwhfSweRdWFXhsMQpzEskuSwLklfKlKtqKRPxBCnOpSbRdGRnPquVcFuaZVBessVewKZyOqsFljMUiDxFvYPiaudyCliLlvTeNWCd"));
    this->PQwWjjBAFFfMl(1301978303, true, string("UFPkolAPOTCxAdknByvWbMKobfHtYeHLhjUcSBSYfPNiHyyDKGCuDhILKYWnTaaOaFhKPUZwPQsHRsKjdfzRIpjuXyXKNWsMpMzJfNxtdDuMQWkvSkwqrGoywyIBdUaYGXQzhzzicraGOVoxRgcUXjokvwF"), string("biocTYgPxRcCHJqJtwyCLIvwvUmWTRxPejUmKpzvQnTaiRagsjKVEyaSCApadwGamOlJwfUgwixSKWEdFZcSHOCAeiOKUbDvGPDyQUfVqtkdnXCJNcaFEmylneoAiSCrjEINKmqNUUgGoRLbVpjVxsWxXHcqhNrmmyMheMKmKsYLscrGHDHGjyXzG"));
    this->HCEGkedN(false, true);
    this->NJdHEYusjujQjCf(false, string("bvMHONElLWWntoLjfIkrRefseETqvdTAlpDhcWbcIWBjVlPClFQnGqnLQVPZFTIDkpQkdHkQcZtebHBBXnsRbDmNHaUuLGvEVZlJgGqYvIAHOnYkfFOvJfRQfXVWYTNQwZNPStImeuZILIWOUtmytvhNBvKOjgfKBVFJNdSeYCrNKeHanJazzexGqMjqmWsbizVLwwqbqsVcFOubLssBuoVxldsVhAieMkkuqtoNfBxag"), true);
    this->zZFXAuYBVDWDDd(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SZNDzLDELviCgCF
{
public:
    double ydliKWJVioSssnJ;
    string jkecwAc;
    double bXLHBOSi;

    SZNDzLDELviCgCF();
protected:
    bool ggbyjkwGzzggELRg;
    double WqhtEeous;
    string jMOGOA;
    double KDVCc;

    double dsvpBRxuE(int PJftVPuUoiCkIG, string AhUkZZRFcsW);
    string LpzqSxBsup(string KMkzwAduXsqH, int wMHuhxYQrjLKq, bool NSSkLmznCjmpLpj, int YaedRly, bool YQlQrJHtkbtQEScY);
    string BXQwowG(int EtjyODVXAUUcm, double tzEAVApQUoXz, string bsVvHmVHZVYVuC, double yNprgbLygnlthnr);
    void EnOhaZgAbYY(double eusWaYANdXGKH, bool bkjMpRjxeIo, string ZgXbekAGWSltzGxy, int HMlWAshJrSfE, double aYZSoUWjckYzY);
    void khdfqHAuj(int PKlrKgkatPOlTvv, int jFsbUaYr, int jtlgRlzYt);
private:
    bool XgYvrc;
    int LzniTeldUCc;
    string GigwntSWBBHiz;
    bool zBTbbJm;
    double HYsZhvhsKKI;

    bool lhWMDZrzR(bool ktRoHuzrRW);
    void wXfRdgjxQGX(double jSicoTabK, int VttWmrQbRftqZm);
    void znytXcP(string BaAxiBnIwALKj, double mPUDieI, int XHyTQf);
};

double SZNDzLDELviCgCF::dsvpBRxuE(int PJftVPuUoiCkIG, string AhUkZZRFcsW)
{
    double HeSZGqgP = -176254.18661039186;
    double iCBkERkka = 127645.9190009158;
    double jSBAEwFyWDERnF = -611878.2045182352;
    double ESthiuEoMWNTAeT = -30177.825556092055;

    if (AhUkZZRFcsW < string("YrwHzrnpRfomnDGyriuxMcpzcwaZeKLwpoJ")) {
        for (int TUddJySReVznSv = 1694021931; TUddJySReVznSv > 0; TUddJySReVznSv--) {
            HeSZGqgP -= iCBkERkka;
            ESthiuEoMWNTAeT /= ESthiuEoMWNTAeT;
            ESthiuEoMWNTAeT += iCBkERkka;
        }
    }

    return ESthiuEoMWNTAeT;
}

string SZNDzLDELviCgCF::LpzqSxBsup(string KMkzwAduXsqH, int wMHuhxYQrjLKq, bool NSSkLmznCjmpLpj, int YaedRly, bool YQlQrJHtkbtQEScY)
{
    int GnxfjICjiryScZKR = 1160864862;
    int xZNcSySkpu = -46621902;
    bool rdykFwgZfDcjZGj = false;
    bool PXxfPDNMM = true;
    string DlhnmdZkrUfB = string("Krjeg");
    double jSSrUwKugZmfT = -226272.876800811;
    int gbRITlm = -42107746;
    int TGqOuowJpszh = -230532902;
    bool tTUdFL = false;
    string xEOuZiy = string("QYNFRGbrOfQEJFMCCCyvVNlQRbUdWEmljkGuZcclNFXOgXQeYwzMVrGPHTpVwdmGiaGmOarjOppNoKVITvGTHxXlGYfkChSYtVPxEXlvUFxvObzrlGhmgZOoQQZirDwEIoqhgHCJWKPgkueLcFzgYHfWLcAkbvKGJzflHPXMmNLLBhpBHsrLojDwsQrhhUMeXOMBAuqQJaHnPFnKsxsaovngUlGQocfEsBwxOHlikorUyXlpnvCjotnPn");

    for (int qCEoGcpygwpRke = 1702041462; qCEoGcpygwpRke > 0; qCEoGcpygwpRke--) {
        GnxfjICjiryScZKR /= gbRITlm;
        GnxfjICjiryScZKR += xZNcSySkpu;
        DlhnmdZkrUfB += DlhnmdZkrUfB;
    }

    for (int ZdVEhIo = 1986699847; ZdVEhIo > 0; ZdVEhIo--) {
        YaedRly = gbRITlm;
        PXxfPDNMM = ! rdykFwgZfDcjZGj;
        tTUdFL = ! PXxfPDNMM;
    }

    for (int nGovzufCHK = 80101438; nGovzufCHK > 0; nGovzufCHK--) {
        YaedRly = xZNcSySkpu;
    }

    for (int pYIxZBNtgFb = 1873968910; pYIxZBNtgFb > 0; pYIxZBNtgFb--) {
        rdykFwgZfDcjZGj = YQlQrJHtkbtQEScY;
        TGqOuowJpszh += gbRITlm;
        GnxfjICjiryScZKR /= YaedRly;
    }

    return xEOuZiy;
}

string SZNDzLDELviCgCF::BXQwowG(int EtjyODVXAUUcm, double tzEAVApQUoXz, string bsVvHmVHZVYVuC, double yNprgbLygnlthnr)
{
    double RCmEYS = 592086.4256039928;
    double LhhpU = -438377.44385738997;
    int HYIWskf = -503396261;
    string LiFOPVSmYNGb = string("owmErhbfxVhuHNaWqucdhsHoPhBzxZBHrAldjtOZkgwcUUYaHxppbXpaglKDwtrhuyheUknVvnATVsBaLkwqzmdLuNHyzdynsZjTUIEolJThsOKinMiIhfRzgZAtStOIsEkqKrSbCjmVLTZZxgGPIqQfVvmZLRUcSdjzFLJjpmeHNMbzuHSVrXlLqIBPicy");
    string kdxhJcBeYpmuI = string("ExeTmciFFoAJuritpOSLKpPVeSKRJusxyMfccTAxJMIWumtZxU");
    bool SCrpeIl = false;
    bool NmRJjOJTDMTLZJ = false;
    double tiYjEfyugY = -807566.6055301616;

    if (RCmEYS <= 592086.4256039928) {
        for (int DZmxuRwWKg = 1143600257; DZmxuRwWKg > 0; DZmxuRwWKg--) {
            bsVvHmVHZVYVuC = kdxhJcBeYpmuI;
            LiFOPVSmYNGb = kdxhJcBeYpmuI;
        }
    }

    return kdxhJcBeYpmuI;
}

void SZNDzLDELviCgCF::EnOhaZgAbYY(double eusWaYANdXGKH, bool bkjMpRjxeIo, string ZgXbekAGWSltzGxy, int HMlWAshJrSfE, double aYZSoUWjckYzY)
{
    string Edkbe = string("gXXnGMtMBZFIxJFwbELPzLZeqruvhNLIZQwejuBKGEpVXjwGMrTIrjiHmDaCbyBxUThsyaZEokScogUNmFBUUzxdhYRPSYMHWDYsUfmmadGRciyyynBZLw");
    int uyWHNw = 46203558;
    int VKGte = -1381016055;
    int Rzteaa = -857451302;
    bool kPsyESbvmJem = true;
    string wcGtPcmtTTgVhGGo = string("yhOMQtzhvCNbOQVCxAjhRvjOGvCtXeAXxwOscWmVCjwEsIaetoaajefVEmoSXUYCJorZlQgNGDoyRTSaYCyKgUPyhvouqantJLAyojsrUSwkYrRdkusGFPSALWxIYEwLGjbWNyqGcik");
    double aoCOlorfLXYPrPod = 882236.451293045;
    string eUDgIHSC = string("DOFZoDzFmEPOvgXVDcGVDIbjXMCJcYuHtzcdoPspcEPFXfSQxPGeyyxpHSsonPZKdBwPgqirqldrbUEAqABTII");
    double AgSOuY = 645547.6757338478;

    for (int feMOOM = 5706153; feMOOM > 0; feMOOM--) {
        continue;
    }

    for (int CuPKcgAQFFnKIr = 1067039301; CuPKcgAQFFnKIr > 0; CuPKcgAQFFnKIr--) {
        VKGte *= VKGte;
    }
}

void SZNDzLDELviCgCF::khdfqHAuj(int PKlrKgkatPOlTvv, int jFsbUaYr, int jtlgRlzYt)
{
    string wFtaO = string("ofasTbciemygybbAobKfamgUsTeZeMKMYkaPpyUxRDYKuKeM");
    int TbVIUu = 9418738;
    string TCRVAyW = string("ncCecgqtvOUGjJTYWWmZyiKmbXYQinTvbdmsxzKTIdIpxmTXvCwLvYLQxSsXFLxgAWYfGipeuF");

    for (int bAGstKFa = 723865012; bAGstKFa > 0; bAGstKFa--) {
        jtlgRlzYt /= jFsbUaYr;
        TbVIUu -= PKlrKgkatPOlTvv;
        jtlgRlzYt /= jtlgRlzYt;
        TbVIUu /= PKlrKgkatPOlTvv;
    }

    for (int soyMWQQgekFhP = 570646686; soyMWQQgekFhP > 0; soyMWQQgekFhP--) {
        TbVIUu /= jFsbUaYr;
        PKlrKgkatPOlTvv *= PKlrKgkatPOlTvv;
    }
}

bool SZNDzLDELviCgCF::lhWMDZrzR(bool ktRoHuzrRW)
{
    bool PJqdSKNup = true;
    double YfprcfHEPIesjHnA = 438896.6932273659;

    if (YfprcfHEPIesjHnA < 438896.6932273659) {
        for (int NwcCUTISxefS = 535163696; NwcCUTISxefS > 0; NwcCUTISxefS--) {
            YfprcfHEPIesjHnA = YfprcfHEPIesjHnA;
            ktRoHuzrRW = PJqdSKNup;
        }
    }

    return PJqdSKNup;
}

void SZNDzLDELviCgCF::wXfRdgjxQGX(double jSicoTabK, int VttWmrQbRftqZm)
{
    bool OCEJn = true;
}

void SZNDzLDELviCgCF::znytXcP(string BaAxiBnIwALKj, double mPUDieI, int XHyTQf)
{
    double oebrverzvbSRww = -570500.0009017468;
    bool DaiLBtMV = true;

    for (int DcJQnnMHIPjcj = 804240436; DcJQnnMHIPjcj > 0; DcJQnnMHIPjcj--) {
        DaiLBtMV = ! DaiLBtMV;
        oebrverzvbSRww -= mPUDieI;
        BaAxiBnIwALKj = BaAxiBnIwALKj;
        mPUDieI /= oebrverzvbSRww;
        mPUDieI *= oebrverzvbSRww;
    }
}

SZNDzLDELviCgCF::SZNDzLDELviCgCF()
{
    this->dsvpBRxuE(-615808852, string("YrwHzrnpRfomnDGyriuxMcpzcwaZeKLwpoJ"));
    this->LpzqSxBsup(string("DJQXDRPBZXbFFIMyOJEAwkjDYARftjVXYvuFCpEqZm"), 1225915687, false, 1931928595, false);
    this->BXQwowG(929168789, 799669.8165556863, string("TmEyItIhDavoZDnQgpcFXv"), -236536.61767164635);
    this->EnOhaZgAbYY(459307.73479871545, true, string("VEUTCThrdaxebpWHdsJoCsGWCXubdrBTRPhfFYRCHItSulWYZWUADtrbsTTkAWqRbFcdKLLRylbpjhaoVPSeXuBIphWJMcqCtFCClUsItwqHIiFGYWObImZpQtKIHBIEQvSpNbzqDCmBCUUaVZstFgaSkCWStfeSdfcfuriZPJBmjcWLZabEYEmvLfLjSHqgHlOvTOiztrArQVnPvKYDKslaQRgeSCKyHMrisKBkKuzmCUhgAgCuQeUmuRAtIQq"), 2025137959, -440244.7225522982);
    this->khdfqHAuj(1853479283, -653319017, 1311538431);
    this->lhWMDZrzR(false);
    this->wXfRdgjxQGX(601484.0273367832, 1836108966);
    this->znytXcP(string("lsBHWetqgyUvsxFUIoBKifKNwEDGMolqVzxGLPGXyYGhCkihVFrVPsRNwbirBBDuYZrolanimWMmvQdKUrHHtdYc"), 390796.28165057546, 2050257076);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class icyrn
{
public:
    int wOlcT;
    bool RKfiuuSXXBAFMS;
    bool CEdoKJj;

    icyrn();
protected:
    bool QqIaLiCVOwH;
    string xddFWAXn;
    bool EvMVqjmISxMHGj;
    bool pTYEjSvf;
    double tNtcNzOtWl;

    void kYnptyWUpGW(int xpvWPNq, string xWkFeMKDyNQQIfg, int RGNrrSh, double jlqOybaYZrYqB);
    string inhnjOn(double OeleKsf, string VUerZz, string fUSVXDxvkqpaCF, int WMCmelwOHJt, bool qikJMXQDPNyvtYN);
    int TxGTcThz(string XWsfcQMKYMOxEA, string VIHpPEzwrerAxExM, string tGLRP, bool xcIWztlyMUyTLu);
    string FGkxXLMcer();
private:
    double RAeee;
    double gBGgD;
    double ieydoZskCamF;
    string EHQxefLIRKPx;
    bool PPoXbiUwKgyLua;

    double gWhuI(double RNNOVw, string lYjtPtCJvF, bool EybUp, int xcPkcUlbo);
    string HXOIaTjeelDUIc();
    int wxyvb(int jxmGQ, double SJqaGXFZRvNlDW, double bpfzjJemvJCsuYE);
};

void icyrn::kYnptyWUpGW(int xpvWPNq, string xWkFeMKDyNQQIfg, int RGNrrSh, double jlqOybaYZrYqB)
{
    bool wjbHrgYbQ = true;
    string rJZsXRCnNDq = string("uWBgXYpasKJyRrWkshMCVeaLHNRNOLnMrLhXoNddGSLbAardlISZFpmeGILTeuVRTCEmRCnDg");
    string XEfrnfh = string("WupkFWPUzmtwQeiuxBPKSYFNpNpTKPtCrFvVBOUMRhUzFfegMCDCqfCcxthkoHoIxTiUerKyeIsstUPVOKpwsVOMjltnjvEyCKxCebnhOROlpGBYIgQrFrNxOTvSOxyxJmKPVRFcwjnpmZjNHyLyKtBzdOxGEImZUOcXsdKwEEuXnzsrrglEzvEMmIgkozhjTZMaOlmsTftlBYMlXchMBQruQfchpuGhQ");
    string zsBaAIRjRLnMVQ = string("thXfKKQbvxEbpLSxPuGJmKwLsmhSLUjPFlokZDQTTEAZfiCglDofnOBGgTPwcBAULYN");
    string atIcDdYKIAJiBXr = string("LejIAfreuAjIvqXcfFAwBuvtFDayynUVNJRoqYfXpLxJiYMqUCaEKrjNrBnIJSAFCkwWjYqULRwRbScQvqPPMPYJcKiGOghd");
    bool ZJDlhK = false;
    double SqKQCKaeI = 208717.86724849604;
    double EefMiQJnzfKJbWWa = 234107.15234618314;
    bool FKRKvgTwC = true;
    double TAvvxIFPVKxPn = 551025.5692474338;

    for (int TjirZ = 1786283562; TjirZ > 0; TjirZ--) {
        atIcDdYKIAJiBXr += rJZsXRCnNDq;
        XEfrnfh += atIcDdYKIAJiBXr;
    }

    for (int KUdSETPNggC = 414193006; KUdSETPNggC > 0; KUdSETPNggC--) {
        atIcDdYKIAJiBXr = rJZsXRCnNDq;
        xWkFeMKDyNQQIfg += zsBaAIRjRLnMVQ;
        xWkFeMKDyNQQIfg += XEfrnfh;
        XEfrnfh += atIcDdYKIAJiBXr;
        rJZsXRCnNDq += rJZsXRCnNDq;
        SqKQCKaeI = jlqOybaYZrYqB;
    }

    for (int uhyNSwlfrpfNri = 385261227; uhyNSwlfrpfNri > 0; uhyNSwlfrpfNri--) {
        jlqOybaYZrYqB /= SqKQCKaeI;
        FKRKvgTwC = ! wjbHrgYbQ;
    }
}

string icyrn::inhnjOn(double OeleKsf, string VUerZz, string fUSVXDxvkqpaCF, int WMCmelwOHJt, bool qikJMXQDPNyvtYN)
{
    bool xYKNKYLElSWPQdd = true;
    string KgZNYwKfdab = string("MjWZjuWrkXTCtWCmaTRQcYrjGbTEEnLWpWDpGxMQKGcVJGqyNOKbGuRCbjieRTVZUgiGvvFuBjceEoIKEVhEmfzqwlrCRcjuDzpCEChGpNtsOAhAfHdwqS");
    int FXtpWABXfELwc = 690150627;
    int nALrBkhCDXeD = 1081476534;
    string TuVAcnMY = string("MwBQrmPpwsSgClFabslgHSuzPWWgnLTVuzfesBuePjKTdSgpOuJALFWIMSVuAvlmrvQDjARnwTdkjFILoeuSIxHAYRBFLNBmdrKH");

    return TuVAcnMY;
}

int icyrn::TxGTcThz(string XWsfcQMKYMOxEA, string VIHpPEzwrerAxExM, string tGLRP, bool xcIWztlyMUyTLu)
{
    string xysiHrgasd = string("OzmQFODIjiajsROFXGOoyMd");
    double ggVzzAfdTNX = 756645.9242792528;
    string xdaVqpX = string("hjrzOyqSVeWmmrRoewpaaEesuPynEKzsHBDXBwxoZmlnaFnQzoLKOydsZmcMvEVDJSjxcRBthvqAertKXgXEldxrkWYWzHxSLByElUVOSjspVEwAuqmCXZHqjOWnorunOnVhTKMGKGiExrHsHwCZdyOUHEfnrrSmKUCfSxwMwNBHhozuOfbnSTkHtHOtQITUgmxtPqPhhDQmiyPCLNzxCGtYkSPIsHAvufhhq");
    double DGSYGc = -738645.9054432007;
    int hVigGtAXpIc = -1307297801;

    if (xcIWztlyMUyTLu == false) {
        for (int SuaRXkKayhNm = 110092107; SuaRXkKayhNm > 0; SuaRXkKayhNm--) {
            xysiHrgasd += xysiHrgasd;
        }
    }

    if (xdaVqpX <= string("KvUpBoFORxfxAszvQzYGZtsZUDzpPrastGJBpuFfTiAJnKEuVxZgzOIuwsFqjmiSIAMKNewccMwFyKXJelhTVIwQaMVILayCOLxpJLjHJQCicNDeqWdoAeAFMooMMSKOsSHOlqRwOhbDZBBHzxMaIpzIfywFIOsMeLxRMvIXygaxSYeOgyVkonvyIlNTpDFvipjPUzxAkCrayDJxYCtHvFQpQkAoJBqWVKbBrpgBaVrLqula")) {
        for (int TpktkGW = 1890202337; TpktkGW > 0; TpktkGW--) {
            tGLRP += xdaVqpX;
        }
    }

    if (xysiHrgasd < string("hjrzOyqSVeWmmrRoewpaaEesuPynEKzsHBDXBwxoZmlnaFnQzoLKOydsZmcMvEVDJSjxcRBthvqAertKXgXEldxrkWYWzHxSLByElUVOSjspVEwAuqmCXZHqjOWnorunOnVhTKMGKGiExrHsHwCZdyOUHEfnrrSmKUCfSxwMwNBHhozuOfbnSTkHtHOtQITUgmxtPqPhhDQmiyPCLNzxCGtYkSPIsHAvufhhq")) {
        for (int FRItWNEFr = 594270236; FRItWNEFr > 0; FRItWNEFr--) {
            tGLRP = VIHpPEzwrerAxExM;
            hVigGtAXpIc /= hVigGtAXpIc;
        }
    }

    return hVigGtAXpIc;
}

string icyrn::FGkxXLMcer()
{
    double Mzgvqwz = -196966.82511214938;
    string oQawtwvfHgope = string("BEurLoUyvcYqQwJORZjToyFWAonwCOFHtTvkgsrUNeiamNbjhFCevCjYBoDcTVmISXgCQdiqipQsmpjRXGXdYDBgCBXjlbfSuGNhLZSknvawbaII");
    string MBOpQy = string("nokRWlhBGiHjNdLnoptPWSAUKJbDLSMzyxigYcpppmtLmdNHugMyudpkiVqNVTsZJfuLxyCVazYQnYSeoIsjjhyQIKaemIKxPZYwDcaSQRcnEURNswoGefD");
    bool ABFcDFZkWwdMz = true;
    double mtFyw = 774869.6412170187;
    string kfZSUsvL = string("USNywPoXvhobUopHpzCTRtZPFHUtcCUwCLLCCzrmhsqLmZZeqKtvFVjGVqPOIDiNJhFpDICsBPEdbGKqVpgoOLllkNgyGYhdMDaNalfRFyFfucklBOGTOYhWEwvcBSLWSaoLKCUjpENvWrQWXqrsYQxklirgCbKcoOrGvpARaxBSLz");
    double gLycVbfhJt = 1033975.1310422287;
    string DyjRl = string("FJdPnFJhKhNAUBfYyIZIvXInmOAOBzRNvtDEZsxulPxDBTUGeXsaEpuVqLdvpDepYzRTvVORHskNIYlzUQMIyLBDUTcHVGHRnSUaZEQyJQtULHkzrcwperiYJTkEKkPLCxofhLYqdqhTQPHyPQqtnxVvyskSBVxXMQzqSiAqQatkCGOvfkBFwnGIJZaDrUBFVDJLCLZoTNoMAkj");
    int eqosaQ = -875393726;

    for (int MpGNLjbkzvkSv = 288246237; MpGNLjbkzvkSv > 0; MpGNLjbkzvkSv--) {
        continue;
    }

    for (int nqyQmeuAdjUWlSL = 1931845078; nqyQmeuAdjUWlSL > 0; nqyQmeuAdjUWlSL--) {
        kfZSUsvL = kfZSUsvL;
        mtFyw = gLycVbfhJt;
    }

    return DyjRl;
}

double icyrn::gWhuI(double RNNOVw, string lYjtPtCJvF, bool EybUp, int xcPkcUlbo)
{
    string rJCemdliSPP = string("RrBSjNfhGRoTEJUzhNBkRWVHLJFyLhCEjpSQfWXGppvAPEjYXUdQpwkuUhAZrbMlRDAvdrrdDigPpzVZgtxpilvTtoxNaTqkbhmTDFDgWrPXuRLPoihTubucPsLGAMYZDtDOjsfFljZMlaeabJgNdSNQqTmyUZcwziLTIHxutahOXpGstbbpXAAoNMXjwwQWjyNDOexIMrrgzeEOitWXkWMbsmhUrFphYFhmTYDiJTcXBxKbBEjIMMn");
    string olKSboblGZ = string("ubyYdrbwTLavKkmssvszafOIwISSLLIbmgQIIHvYtUHPZPBNRbpVRyFrEBZkulHGktNqidARBTNvSasgyDfIxNWegRppilSqjVCBykvRZItdhJAqbnKXeAtW");
    double FJOonqPR = -351338.73771528446;
    string nsALmsMfT = string("zjrSqwCJjVMlYChFmiCDQajdQgtglAzfWIskrbohNHXtAszaoKEyOoTulfiDmZwQtZTyPgAejXwwfDsNamHgxghyHLGvgfImunRRqAnqwdCrUcVaCENzIOWOOaSXjDOVxhwlBjjiYeCMWUmHxTfqkfrmVxEAzKCRwBvxlTvKLLnOOnkhilBYhktnlpzJWCaZlICedEglJNylVPwVxssDyaoLyoGgjgjlRVHhOMZvakedIGBtFngCIDmahvzvPZX");
    double guCPmPSjte = -511945.1380539258;
    double UjckQvNxdikL = 307977.1379435851;
    bool HfhoRyGboZkqvEbq = true;
    string MPXtGT = string("oGOWsuetRVDBYKsCCyuwHnlEtrLpdnsckrrumpuyNqtgTTxQFUcxOxeVhPhBCxzUhxgdDVYVVOQbXdeqvJLmjIVwQFRKBwg");

    for (int pbqRp = 1860733481; pbqRp > 0; pbqRp--) {
        MPXtGT += lYjtPtCJvF;
        guCPmPSjte += UjckQvNxdikL;
        olKSboblGZ = lYjtPtCJvF;
    }

    return UjckQvNxdikL;
}

string icyrn::HXOIaTjeelDUIc()
{
    double HVrxTcRZEa = -243280.42176908284;

    if (HVrxTcRZEa <= -243280.42176908284) {
        for (int NVNWFphhnhqIQkOF = 426819988; NVNWFphhnhqIQkOF > 0; NVNWFphhnhqIQkOF--) {
            HVrxTcRZEa *= HVrxTcRZEa;
            HVrxTcRZEa = HVrxTcRZEa;
            HVrxTcRZEa = HVrxTcRZEa;
        }
    }

    return string("AEDUtafXYpbpuHfiydQKOhjuKmKhIwCmouowhGCAtoHxvOhDkAEHmfmnkXDuSSApSwNEHShkhLFQRMgKEeDcHgSsMpWZVdazKNzlRdBbBVt");
}

int icyrn::wxyvb(int jxmGQ, double SJqaGXFZRvNlDW, double bpfzjJemvJCsuYE)
{
    string tutMubUZfSTTXjlW = string("i");
    int wixkDQIXRDvOruC = 1575824009;
    string RHjFi = string("UfvRtkAYlRwsZFObadlWfOEqonmstFqExEGWUATbjXHcDhgIEbwngjENxMqXqmkrMKqcQzhvkWhbYnjmMMDQGzBRVTUUkMgkCzTuwQkJHfkKZaykwRYkpYaHkwobDmxqXUqycMJDGssPDSrPKDGdsKRsiUOuPixbttAvNlhQQDBfxJOQpskqqmmMLspBchapFke");
    double XHuIwHAj = 532932.3858695602;

    for (int XNurhijqGKAJlQYg = 536435341; XNurhijqGKAJlQYg > 0; XNurhijqGKAJlQYg--) {
        XHuIwHAj += SJqaGXFZRvNlDW;
        bpfzjJemvJCsuYE = XHuIwHAj;
    }

    return wixkDQIXRDvOruC;
}

icyrn::icyrn()
{
    this->kYnptyWUpGW(-1458439292, string("TOsubKQszivWZfKUlMDEUAfDwbEwJBNUlFdOlNVfIOuBDwUelroEJfUfkSaMMnzPzXHLMoKmTUwGCWmQQqcptLvZGgZttdJEBaogKZNOkgmKjxLqyx"), 494803384, 48745.20110183791);
    this->inhnjOn(109271.03262888972, string("adPewpdvmXlvTPPdHrWOeQlvarhZIiTXkelVBYtmUFUyIjEruDRwtxjXmiZJgXeMXtVpbezaYsXIgx"), string("JlQKTApQBDRrYIxjIhMcAkzWJbaZWyEUuSamUtjVoAZsphDwdlGNCnPMiPO"), 281058405, true);
    this->TxGTcThz(string("lGajaNQxygPkiyMfWpbeZeTrpnsFwfMAXAtkXCYDyxjfhiXJcJivKqIqphtNtUWVQAWRyFVwjzRcNVDbnZnGxDwWDWwoEzTdXUAJIbBpFsTpTfKikCyZHDZzzxTVEXrPivawiZvJjoSiFLjBgqetTFgWZiBBPEiicvFlEMhjkjdLPlyXJquGTnqHaNrcnApYmFysZBtcNSNnRtTviZJdEErPoQAuGrDySmpoZBlIGVBCbMzmnROvdlhCKwpyS"), string("KvUpBoFORxfxAszvQzYGZtsZUDzpPrastGJBpuFfTiAJnKEuVxZgzOIuwsFqjmiSIAMKNewccMwFyKXJelhTVIwQaMVILayCOLxpJLjHJQCicNDeqWdoAeAFMooMMSKOsSHOlqRwOhbDZBBHzxMaIpzIfywFIOsMeLxRMvIXygaxSYeOgyVkonvyIlNTpDFvipjPUzxAkCrayDJxYCtHvFQpQkAoJBqWVKbBrpgBaVrLqula"), string("SiVJMmIcSyXrapUetFcaiqXLAqaqvZUoZjxRWWJcvyEFLqEQwINnTJAikwfEcnFOMrIfrUisCFBVlEidhfZqITiSMUtFixtApwRfyWGeHcZRrNJglCTFJIdoVxUAtWZDFUFunKQmpIjtkCusydhkiIqEIUSWitEoTeXfDssAFITUdwKDsNeSWffZrOmMhsbRhCsfjdOEEEbXaeJvNsSnHuDIjervbxKDIPtlJtyvJteTQotwpmOC"), false);
    this->FGkxXLMcer();
    this->gWhuI(-654474.0362455812, string("ankloJWOdBNbOEWLupxFHwMAgbfogcXpNUajzftFNCSIkfCQaboEIdEHPyYbymFkjpdHGyIaqwVrZacRTZLIHZOCPZFvmEjKBcYppuvlNtNZADfwqeEYlRCFjDrGclqgZSnTUhXLxcahPttPHhplgEmijnId"), false, 1436830867);
    this->HXOIaTjeelDUIc();
    this->wxyvb(2019670111, -737207.7297060576, 219320.1605958322);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qYJkvVNpSMOavemH
{
public:
    bool IteAACjkiJTpx;
    string EWZShcebCt;
    string OoZRRPn;
    int FDBFHapKhEduaQm;
    double SmNZX;
    bool fBRuMJJB;

    qYJkvVNpSMOavemH();
    int OEZzeU();
    int uAsFx(double TVsMxNS, int KVVnYyIsK);
    double GCPVefE(int sIKNvGMJwnW, int ZLrbeixuEkumpVA);
    bool bIBIMVYtccf();
    double HToGfzexNYVSEhm(int bzlZk, double VTYHyyvG);
    bool BxShGPA(string Ehpwuyu, int UnpGcwHvManaBt);
    int TqeBbvuYRvg(int IPtOannRdHnLUZ, string ALnXcjW);
    double UytZHxpxz(double BlVSbwax, int VXYDLjMPLAQMw, double UfLEwIjxsl, string XJPcqjmaImUZCSGj, string kbELxggrBXdCbXuR);
protected:
    bool xobOVz;
    string sMVVkPuYNNGdBzU;
    int zAKVefxal;
    string pbTdjxmZIBXpqZ;
    bool hEWtZ;
    int QDxMxtedbsiKPfLv;

    int HKbqtkBybXavAN(string eEMSQoQRGLdfDyJM, bool TapMupVbi, bool gXYQRjp, double CBUQQPRaaji);
    bool WxAFQWPp(int SIuZkyULfYJpal, double yEimaXnjePYhAwK, double RZogCDnRtrqEU, double iqZdDYrfZhM, int wpltOynjZ);
    string KeYzWCHPLWJem(bool NBsfvHOkSTrxXX, double fsieAEbF, bool VMXeKEfPUrCwbgEA, double VvOySr);
    string UgyYYHkmNzzz(double fHOkjWwVIziAjwA, bool QkNQqFmFvVfPo, bool ajfXDS, string yJbDqXLbAU, bool LhfzdbIQFnZ);
private:
    double GpqWWwDFhv;
    double vOeHgRIJXYTRSdS;
    int JLmETymEmYMDd;
    int ECrkwps;
    double nGvisrinKM;

    string uBLKyt(bool PhfRb, double wBFPWyLqLBYSJp, string NZwrkiFo);
    string BgeYipN(int eCMWA, int KLeLjBKIXqgayMxG, double eMbQXJflAoec, double bABhhdIXWh, double SuEjAX);
    double ndnywyCqaFv(bool GBswoCwzoa, bool UDjKbVyeNWQt);
};

int qYJkvVNpSMOavemH::OEZzeU()
{
    double GhzWaaDis = -422992.88186460634;
    double cJOwvQiPUEiK = -186363.84783551973;
    string JTJcO = string("SUGZNgESVmtXsKbrwxnePNJkqeyPNoTjTzWLplLUydLcjpCPnBKWxhQgjZxDzUgoWqaheVtwalPUSxJrHspNPckAZuZEQsEbBFtiBegvPXZPWWyDKJxlLuptCOMcoZSSwBrFEWYyQEzzcefguXxkdnZVGwhAPIrSPGSqJzumNNDmUxgdeJWPyhTxYGtRdPpJfKwTtGEqzZFKyOpumpagtNyTdwKQHdOHnHtUKMLxkfzgRIqyiiuTrfvEKvdr");
    bool PwINGnmXfOKlFW = false;
    string THookdWYc = string("yfIOKYTUaGXiWPrlVHdmnbzgRfseaRBFtBxXJObwfAuBbhNQqexrwEFTyLDayeNZWLHLyONyKoHCtWzRgiwaZkFgopHVEOVTRqygJxmEYmUXeoJaAkcREDTXioupghOXImEpjYMtdXcrafyDkVesezbWDHbTPihNlcGwSSjXLBXXzwJEi");
    bool RheCJrLZUpRxYJO = false;
    int QPNIPdokXTdNWJfO = 1185801140;

    for (int ktfRJOzc = 2104050620; ktfRJOzc > 0; ktfRJOzc--) {
        GhzWaaDis *= cJOwvQiPUEiK;
        JTJcO += THookdWYc;
        PwINGnmXfOKlFW = ! RheCJrLZUpRxYJO;
    }

    if (GhzWaaDis >= -186363.84783551973) {
        for (int RLmEjD = 1395436294; RLmEjD > 0; RLmEjD--) {
            cJOwvQiPUEiK /= GhzWaaDis;
            THookdWYc += THookdWYc;
        }
    }

    for (int acgxCyvRs = 410409238; acgxCyvRs > 0; acgxCyvRs--) {
        RheCJrLZUpRxYJO = ! PwINGnmXfOKlFW;
        THookdWYc = THookdWYc;
    }

    for (int LdSkqSR = 596972530; LdSkqSR > 0; LdSkqSR--) {
        QPNIPdokXTdNWJfO /= QPNIPdokXTdNWJfO;
        PwINGnmXfOKlFW = ! RheCJrLZUpRxYJO;
        GhzWaaDis -= cJOwvQiPUEiK;
    }

    for (int XqoKH = 42928666; XqoKH > 0; XqoKH--) {
        continue;
    }

    if (GhzWaaDis < -186363.84783551973) {
        for (int JcpLPTkIOo = 1428464227; JcpLPTkIOo > 0; JcpLPTkIOo--) {
            continue;
        }
    }

    return QPNIPdokXTdNWJfO;
}

int qYJkvVNpSMOavemH::uAsFx(double TVsMxNS, int KVVnYyIsK)
{
    double BOhehCHcv = 892314.4843759721;
    double eMXIuvYatl = -788712.2841258859;

    for (int QNnvKsawkZXZ = 2105493217; QNnvKsawkZXZ > 0; QNnvKsawkZXZ--) {
        BOhehCHcv += eMXIuvYatl;
        TVsMxNS += TVsMxNS;
        eMXIuvYatl += BOhehCHcv;
    }

    if (KVVnYyIsK != -927840034) {
        for (int oUtGDU = 988323573; oUtGDU > 0; oUtGDU--) {
            KVVnYyIsK = KVVnYyIsK;
            eMXIuvYatl *= BOhehCHcv;
            eMXIuvYatl += BOhehCHcv;
        }
    }

    if (BOhehCHcv == -788712.2841258859) {
        for (int leCWbKsO = 496806593; leCWbKsO > 0; leCWbKsO--) {
            TVsMxNS *= TVsMxNS;
            TVsMxNS /= eMXIuvYatl;
            BOhehCHcv /= BOhehCHcv;
            KVVnYyIsK -= KVVnYyIsK;
        }
    }

    if (BOhehCHcv >= -97387.93405185426) {
        for (int XigflxIxkrnJSpj = 1946686718; XigflxIxkrnJSpj > 0; XigflxIxkrnJSpj--) {
            BOhehCHcv = eMXIuvYatl;
        }
    }

    return KVVnYyIsK;
}

double qYJkvVNpSMOavemH::GCPVefE(int sIKNvGMJwnW, int ZLrbeixuEkumpVA)
{
    bool batmIcHD = false;
    bool WjvzwIVPqQJG = false;
    bool UPlYbWkixlot = false;
    string EFTFjUEbcIjdkz = string("RrhdrBlozMZIjrezJIVVTveJBWwjGKWPhGIvhCheBuuGaGrEnCStrlbCPrzZrmmKIPGWknMzWsnNsmiyMuPWFQ");
    double ENwpANoXjHJ = -156911.8231343847;
    string KwhYjF = string("TDMxcYwItshaPQBvXaVSRMSqdLikJEmKghQTmY");
    double UCIIqczyEMV = 389374.22736064653;
    string gXXUgQj = string("CCMIdPhgTeAgMiRJfUUWWQdVTelaAmh");
    double McpeIxT = 300846.6883342446;

    for (int DfAlOgIJynPe = 450937673; DfAlOgIJynPe > 0; DfAlOgIJynPe--) {
        UCIIqczyEMV -= UCIIqczyEMV;
    }

    if (batmIcHD == false) {
        for (int UoLBwVDGE = 1588470640; UoLBwVDGE > 0; UoLBwVDGE--) {
            McpeIxT -= McpeIxT;
        }
    }

    if (gXXUgQj >= string("TDMxcYwItshaPQBvXaVSRMSqdLikJEmKghQTmY")) {
        for (int UsszWmbTNcpubJev = 1899860293; UsszWmbTNcpubJev > 0; UsszWmbTNcpubJev--) {
            EFTFjUEbcIjdkz += KwhYjF;
        }
    }

    return McpeIxT;
}

bool qYJkvVNpSMOavemH::bIBIMVYtccf()
{
    string GxvhH = string("esRpRsexoWFRUTzuyFAMPOinxZTPincFrnlTRgxKFNoxYNAeCgTyqqpXbPlMdpbmlSLTIAVlVbRtljViMXzCPfbEmcLgGLEBQYVlAFvrpElwibLYihxgVIPFFLbEjHgxpSsSJTHzpwBfSWETTzFALKOKMshtVfspkfnvUfcpEHHZYQIJCApkQVzcaQdKMZFNwUddxXwFB");
    string xXaTa = string("dWItfecEIrrreWRzpSpJCqOquXtfYBQuCwWkKMDXeVTimXzhzGtUSbJfqJayKCfzYJcsRLmCHYTomrentCyOBvYWjxsRpdeWfekRHWLigvkppVAnnOxNypsLVCPLcYctVQBRGMlCbCSzEFMzDphNFziivENhdmuTtHlEpnfYpnAxcduJoZjbetnx");
    string GRhEDLlds = string("XcvbfQgexhObWPlCHpICNwFEbQTuRyZmyXTMMzZTmspKqNdlFuDIULcWvYsfeofzzmMNpOwUJPEHEDsaaCWecPrCdZnigJVGPeTZNFwftCudWxTwknctIFMPiKGdGCgJCqGIzxmRuiusInZBXNKuhiMspUHBogsArxjiOpbvdXyyJxRZcNgsnUWWnvoYcCgBFIpFyUSicvgA");
    int FimMsZOoQimFL = 570734628;
    string cLFHfbnJSyAhZ = string("KuHRJLVcERM");
    string uOZipPhLyPlXM = string("PFtSfHvVZlcqagPrkkZAfXAwmlzCMIUeHkjkmuqkOCugEUZdJlGJdpGvGgZemmnthNTVktdHayGHCZyANTmJSXRSfdrBDgKKDHvgwYvAfCyJZbqCTjONhuQjRVrmPUrriMuPUJZjyjVqknhjGUgfrWCBkccbYfdCKdvzAgDLqgMmYDdPkcmOHORlNnosRsnOHqGTOlDVuydLEqBAkMTNcVxymSSqJtILgKTtzqCr");
    string RfTCrVk = string("phgBfgDdWONZEueChnGRfWMfwkVJBDhqgXYOWzPSmTwLUqQhhbUaOTjXGpqObEfwtMZuZwYEZkdAdjrJhGvSPcRWzRFDDPIfQxyDgEBlGEJroYAJTXqFMpiQbepEECOKmpuFucDTvvfyMSaaGtReJaATZRNpYUoImnbCCxHZWnIZDlbLqiUqsELrTWDBXxHEmyJQLoYXoIAqtUKABGzVIirCa");
    string MmChP = string("yWPBigJeEwSBHnGvNkvkhkUhRdkqwHYJiIItUadbdGlowrrgusSepCfjftzSIaBobRSnJLXqJTNuTNYjqRSASAjbaMIAjhQnHMxsEGQkrepUK");

    if (GxvhH <= string("PFtSfHvVZlcqagPrkkZAfXAwmlzCMIUeHkjkmuqkOCugEUZdJlGJdpGvGgZemmnthNTVktdHayGHCZyANTmJSXRSfdrBDgKKDHvgwYvAfCyJZbqCTjONhuQjRVrmPUrriMuPUJZjyjVqknhjGUgfrWCBkccbYfdCKdvzAgDLqgMmYDdPkcmOHORlNnosRsnOHqGTOlDVuydLEqBAkMTNcVxymSSqJtILgKTtzqCr")) {
        for (int YaJUjOjHEeGLUZ = 527974472; YaJUjOjHEeGLUZ > 0; YaJUjOjHEeGLUZ--) {
            GRhEDLlds = GRhEDLlds;
            GxvhH += GxvhH;
        }
    }

    if (GRhEDLlds != string("XcvbfQgexhObWPlCHpICNwFEbQTuRyZmyXTMMzZTmspKqNdlFuDIULcWvYsfeofzzmMNpOwUJPEHEDsaaCWecPrCdZnigJVGPeTZNFwftCudWxTwknctIFMPiKGdGCgJCqGIzxmRuiusInZBXNKuhiMspUHBogsArxjiOpbvdXyyJxRZcNgsnUWWnvoYcCgBFIpFyUSicvgA")) {
        for (int LHmvxIqz = 1221509903; LHmvxIqz > 0; LHmvxIqz--) {
            MmChP += MmChP;
            xXaTa = RfTCrVk;
            MmChP += RfTCrVk;
            GxvhH = GRhEDLlds;
            uOZipPhLyPlXM = MmChP;
        }
    }

    if (uOZipPhLyPlXM < string("esRpRsexoWFRUTzuyFAMPOinxZTPincFrnlTRgxKFNoxYNAeCgTyqqpXbPlMdpbmlSLTIAVlVbRtljViMXzCPfbEmcLgGLEBQYVlAFvrpElwibLYihxgVIPFFLbEjHgxpSsSJTHzpwBfSWETTzFALKOKMshtVfspkfnvUfcpEHHZYQIJCApkQVzcaQdKMZFNwUddxXwFB")) {
        for (int oPuILAyPnOC = 1406994882; oPuILAyPnOC > 0; oPuILAyPnOC--) {
            uOZipPhLyPlXM = uOZipPhLyPlXM;
            GxvhH += uOZipPhLyPlXM;
            cLFHfbnJSyAhZ += cLFHfbnJSyAhZ;
        }
    }

    for (int byZiJ = 1154459124; byZiJ > 0; byZiJ--) {
        RfTCrVk = xXaTa;
        GRhEDLlds = xXaTa;
        MmChP += uOZipPhLyPlXM;
        cLFHfbnJSyAhZ = xXaTa;
        uOZipPhLyPlXM += GxvhH;
        uOZipPhLyPlXM += GRhEDLlds;
    }

    if (uOZipPhLyPlXM <= string("XcvbfQgexhObWPlCHpICNwFEbQTuRyZmyXTMMzZTmspKqNdlFuDIULcWvYsfeofzzmMNpOwUJPEHEDsaaCWecPrCdZnigJVGPeTZNFwftCudWxTwknctIFMPiKGdGCgJCqGIzxmRuiusInZBXNKuhiMspUHBogsArxjiOpbvdXyyJxRZcNgsnUWWnvoYcCgBFIpFyUSicvgA")) {
        for (int EIIVSZWHMBBl = 669268999; EIIVSZWHMBBl > 0; EIIVSZWHMBBl--) {
            RfTCrVk += uOZipPhLyPlXM;
            MmChP += xXaTa;
        }
    }

    if (RfTCrVk <= string("PFtSfHvVZlcqagPrkkZAfXAwmlzCMIUeHkjkmuqkOCugEUZdJlGJdpGvGgZemmnthNTVktdHayGHCZyANTmJSXRSfdrBDgKKDHvgwYvAfCyJZbqCTjONhuQjRVrmPUrriMuPUJZjyjVqknhjGUgfrWCBkccbYfdCKdvzAgDLqgMmYDdPkcmOHORlNnosRsnOHqGTOlDVuydLEqBAkMTNcVxymSSqJtILgKTtzqCr")) {
        for (int sRyfQuZLngtxxDmX = 1232494264; sRyfQuZLngtxxDmX > 0; sRyfQuZLngtxxDmX--) {
            GxvhH = cLFHfbnJSyAhZ;
            MmChP = cLFHfbnJSyAhZ;
            uOZipPhLyPlXM += cLFHfbnJSyAhZ;
            MmChP = GRhEDLlds;
            GRhEDLlds = uOZipPhLyPlXM;
            GRhEDLlds += MmChP;
            uOZipPhLyPlXM = xXaTa;
            xXaTa = uOZipPhLyPlXM;
            MmChP += cLFHfbnJSyAhZ;
        }
    }

    return true;
}

double qYJkvVNpSMOavemH::HToGfzexNYVSEhm(int bzlZk, double VTYHyyvG)
{
    int enkeAJgmZY = -259167841;
    string JAPtY = string("ITtQjgcvCVAJxpyaLpfSNiImarUpJaPndSlpvfIhZgMYKpYedXilmDyUFUfUrYPJHiqPQDbmEeLCUtOLWCDTSQYiXsEsWKyRSrSmdINvqWcUgVgfTKyZfVAnzPjxooCeKSmipVaRdmuOfFChKCrwbYdyCpgOZOXrkYELueSNWqMybjmVNdOKblnGMtIJGnnTQZsSUQgjrAyVq");
    string qGzatzmbtN = string("JTihpZByNRhiWjixHoKQYkwUIytWQkGQYSIhBizfZmUgzGgEhDhiytmnGNFIQOTjCWxpRlWKoAusozisuMjs");
    string jDVAmkiYuZsrdEd = string("pteSvzGqmGDbh");
    string LgmPfSvmbxEYoF = string("UfTjWPWrtmjwpdOOHfAPLKiyDLcFLduFKmqMTeftSgzTThmvbpulAcaBDirKdBUClPFvAHMRpGhYLrwTPMzdYFj");
    int mTbgGhW = -1935935255;
    string HxnEYLxbt = string("VFdzhCObzaLylfoIUHiXDsEbzMFgYLqQXlKqRBHaNYbfVgjPDrGqlGCZApGXGcZGBdQkYBqTWIKqwKzjYCejytSLUKqWAhoEnOjMyWpCxBgGRjYSShmwAvGZrZAoFONVSqESylHjRvDdCqVoDWkRVZJpafUuDolpmGMwRqeaQHiytyqyCzDGmKIJHZCRYY");
    int garVxmpmc = 981529183;
    string NemjYXpNjPS = string("LCQvmMzuDDzVtwOxiNiAtmVMXcRyDSnzwFZTdVPStdRQhSJMAXQlxtvUqDnSChALCpNWFOMz");
    bool pdaKINUFWOhicxzI = false;

    if (qGzatzmbtN == string("LCQvmMzuDDzVtwOxiNiAtmVMXcRyDSnzwFZTdVPStdRQhSJMAXQlxtvUqDnSChALCpNWFOMz")) {
        for (int YDfuIkMGs = 342122781; YDfuIkMGs > 0; YDfuIkMGs--) {
            NemjYXpNjPS = LgmPfSvmbxEYoF;
            jDVAmkiYuZsrdEd = LgmPfSvmbxEYoF;
        }
    }

    if (qGzatzmbtN >= string("LCQvmMzuDDzVtwOxiNiAtmVMXcRyDSnzwFZTdVPStdRQhSJMAXQlxtvUqDnSChALCpNWFOMz")) {
        for (int WUpDSzZcKL = 1934956334; WUpDSzZcKL > 0; WUpDSzZcKL--) {
            bzlZk = mTbgGhW;
        }
    }

    for (int qofQS = 1075959429; qofQS > 0; qofQS--) {
        continue;
    }

    for (int PKdjTamZHtFFk = 1578917204; PKdjTamZHtFFk > 0; PKdjTamZHtFFk--) {
        continue;
    }

    return VTYHyyvG;
}

bool qYJkvVNpSMOavemH::BxShGPA(string Ehpwuyu, int UnpGcwHvManaBt)
{
    bool DBVbO = true;
    double nDjGhyvZfR = -534313.47112009;
    double cBsrfCsX = 380961.12801879575;
    int NKUJiFaVyFC = 1465512109;

    for (int zvqYaEXDKP = 1526291925; zvqYaEXDKP > 0; zvqYaEXDKP--) {
        nDjGhyvZfR += nDjGhyvZfR;
        cBsrfCsX = cBsrfCsX;
        NKUJiFaVyFC *= UnpGcwHvManaBt;
    }

    if (cBsrfCsX <= 380961.12801879575) {
        for (int rDXTfOIcfybq = 454350169; rDXTfOIcfybq > 0; rDXTfOIcfybq--) {
            nDjGhyvZfR += cBsrfCsX;
            nDjGhyvZfR = nDjGhyvZfR;
            NKUJiFaVyFC -= NKUJiFaVyFC;
            DBVbO = ! DBVbO;
            Ehpwuyu = Ehpwuyu;
        }
    }

    for (int JbTwxgoVtgbND = 1702832973; JbTwxgoVtgbND > 0; JbTwxgoVtgbND--) {
        Ehpwuyu = Ehpwuyu;
    }

    for (int tbrga = 1766502557; tbrga > 0; tbrga--) {
        continue;
    }

    return DBVbO;
}

int qYJkvVNpSMOavemH::TqeBbvuYRvg(int IPtOannRdHnLUZ, string ALnXcjW)
{
    double RgQgpcFKe = 787183.0914320442;
    double DvbpmyobuHbvnCj = 759683.2050762617;
    string RDxLF = string("pJCOFCOMskbkarCfGCCPfcZVZFgzuRZWMboFmDeJcLfeUCuAdsIJbuNZjwVGUAEWVnyxVVzjGEJHDXQyXvkhjimko");
    bool eAAJWfmbMguKSBCW = false;
    int vBCJCWy = 1670040507;

    if (ALnXcjW == string("xltPNvyrNwyZbDFsBnQcqVScgxbbyxzfQuYyfcSPfMxaaJMqbnbGFpXttrEwPnNeiqrJDOfKzcWvHRIbdpbSTyTurIczYDdsudtdZGCP")) {
        for (int qyfuxsSFvXA = 649363040; qyfuxsSFvXA > 0; qyfuxsSFvXA--) {
            continue;
        }
    }

    return vBCJCWy;
}

double qYJkvVNpSMOavemH::UytZHxpxz(double BlVSbwax, int VXYDLjMPLAQMw, double UfLEwIjxsl, string XJPcqjmaImUZCSGj, string kbELxggrBXdCbXuR)
{
    int uAMThQHBJEWM = 212132847;
    double fiXAvXamWxcZF = -314239.16856835753;

    for (int VRVwmj = 1547743332; VRVwmj > 0; VRVwmj--) {
        kbELxggrBXdCbXuR = kbELxggrBXdCbXuR;
        VXYDLjMPLAQMw += uAMThQHBJEWM;
        UfLEwIjxsl += fiXAvXamWxcZF;
        uAMThQHBJEWM *= VXYDLjMPLAQMw;
    }

    if (XJPcqjmaImUZCSGj <= string("wJctjJIbwkbqDiCwHoDlfRfIMbarymQUBkUpUWUiGdaTWqzuYxWaxbqqbNwMkmgaRXeMSziUpGmJSpJmcjxBxpUvyJXMflYgYCvGPmgKhNGFsgatHdIvqxMeENUOfbsFhjIlrmLiTgWmqxMkCLTSvmqilrrdvuCkAaNSNTidSXVdyMnbQuamXhgYEBygWSLnPDTVOMDWBJCaRNjvGDkVIvoneVLRIrDXrxZbswDwtVfSuN")) {
        for (int tfeFXkPhmQT = 2080548136; tfeFXkPhmQT > 0; tfeFXkPhmQT--) {
            BlVSbwax -= BlVSbwax;
            fiXAvXamWxcZF /= UfLEwIjxsl;
        }
    }

    for (int CevcCYuxp = 1419506509; CevcCYuxp > 0; CevcCYuxp--) {
        VXYDLjMPLAQMw = VXYDLjMPLAQMw;
        fiXAvXamWxcZF += BlVSbwax;
        VXYDLjMPLAQMw /= VXYDLjMPLAQMw;
        BlVSbwax = UfLEwIjxsl;
    }

    return fiXAvXamWxcZF;
}

int qYJkvVNpSMOavemH::HKbqtkBybXavAN(string eEMSQoQRGLdfDyJM, bool TapMupVbi, bool gXYQRjp, double CBUQQPRaaji)
{
    int PpvUijw = -2077414751;
    bool FrKIYaeJDw = true;
    bool jfXsZcXCRn = false;
    bool ygoKXm = true;
    string UGMNc = string("ZVDHVPbsYfeh");
    int OgXsesTKBeSJoW = -1570890113;

    for (int BzzzjnsLm = 420432097; BzzzjnsLm > 0; BzzzjnsLm--) {
        FrKIYaeJDw = TapMupVbi;
        TapMupVbi = jfXsZcXCRn;
    }

    if (gXYQRjp == true) {
        for (int sDcSoBQLDmcaEo = 897969571; sDcSoBQLDmcaEo > 0; sDcSoBQLDmcaEo--) {
            CBUQQPRaaji /= CBUQQPRaaji;
        }
    }

    return OgXsesTKBeSJoW;
}

bool qYJkvVNpSMOavemH::WxAFQWPp(int SIuZkyULfYJpal, double yEimaXnjePYhAwK, double RZogCDnRtrqEU, double iqZdDYrfZhM, int wpltOynjZ)
{
    int wdeWGUHmIT = -788609149;
    double BhPPwpBJDtym = 594348.4503344294;
    double ynQDwdlXGaGP = -142782.16595311035;
    string lWweedJN = string("zycydHfmopJsXmSBMdDlnnmKBebqxtsrLnfyOYHLraWLqriaaeiCyAVMWnJGDcrTrSdhlRMEGavMYUzuYktqoZlPAckVRwxCirLWthQIrHglJiuWCoDVYZsGNhMTHedEHIOqfUOAGmTqsBhHTWpIVijsqiyNQJXSdsEyMICqjZnDwm");
    string wfeAkoCxmRKkaM = string("ifFkstnoOpzZpYDekTpnNLSCosqDiXRJotNvQowYfbFvGUYLKKZkkhYzoScoUTlPsoRJajMAiTsKSlgBgusGkcXIWVVbkhkhdDBMpQElSVYqwchjCUxZPMMD");

    if (yEimaXnjePYhAwK < 565957.8798781204) {
        for (int mttEVkwYu = 1145915437; mttEVkwYu > 0; mttEVkwYu--) {
            wdeWGUHmIT *= SIuZkyULfYJpal;
            wpltOynjZ = wdeWGUHmIT;
        }
    }

    if (SIuZkyULfYJpal >= -1516956023) {
        for (int mfniJtPsZGSp = 30611699; mfniJtPsZGSp > 0; mfniJtPsZGSp--) {
            RZogCDnRtrqEU /= RZogCDnRtrqEU;
            ynQDwdlXGaGP -= iqZdDYrfZhM;
            SIuZkyULfYJpal = wpltOynjZ;
        }
    }

    if (yEimaXnjePYhAwK < 565957.8798781204) {
        for (int yGNLDtH = 1615128437; yGNLDtH > 0; yGNLDtH--) {
            SIuZkyULfYJpal -= SIuZkyULfYJpal;
        }
    }

    return true;
}

string qYJkvVNpSMOavemH::KeYzWCHPLWJem(bool NBsfvHOkSTrxXX, double fsieAEbF, bool VMXeKEfPUrCwbgEA, double VvOySr)
{
    double cZyVYEnmAH = -60016.04933612566;
    string zaWGnUsaa = string("kGBPnMsEpXGeZplOTxhudZfPtJvUGYxuRwAZLdTQHYDdAugOLuACXygBpsmIRGDikzIbUTGSrJdVIQshHZqOShgItYlCUtMIJycoHbdmhLugWTNDyquwNeMSn");
    int NJNVqJLAyiSaJAj = 1173642645;
    bool wOUmSfCRg = false;
    bool lykdTDzgqTzMPm = false;
    bool hZoEtE = true;

    for (int wWHysibRpEhQIwFP = 1739814713; wWHysibRpEhQIwFP > 0; wWHysibRpEhQIwFP--) {
        VMXeKEfPUrCwbgEA = ! VMXeKEfPUrCwbgEA;
        cZyVYEnmAH *= cZyVYEnmAH;
        NJNVqJLAyiSaJAj /= NJNVqJLAyiSaJAj;
    }

    for (int MRaEWXX = 39291174; MRaEWXX > 0; MRaEWXX--) {
        continue;
    }

    return zaWGnUsaa;
}

string qYJkvVNpSMOavemH::UgyYYHkmNzzz(double fHOkjWwVIziAjwA, bool QkNQqFmFvVfPo, bool ajfXDS, string yJbDqXLbAU, bool LhfzdbIQFnZ)
{
    string OfZdJoWNDAIIMfAx = string("QRjRRgvSANPSCWVjbbHBbMTbbGjDblSvVWVbNJcoakHOqWiELVrVhiaJBTEGANRGcTmjvBjOWFFizyJhkSKBTaIdVJYGwqEHemuoBTwRpQIzLHJTXbQQxzQopnpP");
    string HPequJqdM = string("hXYnzzdaDpCXMUWjmcTuttofWFRmneyNFoKUqHNgjYGKfhXYcCKyvLaSyrHFKGnKDgNyqkaDDmwhOZFkDdwpzJCsHHUoVxLTVLMAzFtlcdvLXKlSOdvqDXyQSvIEWTAAlNVrYOPPzWFGUFGOJPgZzjpvKgjMOUmLOwUzhAogTMgzAORbvYuezlZKcajhgJXUmwyigWnBpaQjsKLiODsxYgKtDiibadMjTjjlCkjoTrHYgDMJKznsqdUvjUg");
    int kfYYC = -2147446019;
    int OlnqXjPdYOXx = -621267480;

    if (fHOkjWwVIziAjwA < -707477.9538701845) {
        for (int evAwAvdT = 351352373; evAwAvdT > 0; evAwAvdT--) {
            QkNQqFmFvVfPo = LhfzdbIQFnZ;
        }
    }

    for (int KtslNZQamCS = 1836590877; KtslNZQamCS > 0; KtslNZQamCS--) {
        ajfXDS = ! QkNQqFmFvVfPo;
        yJbDqXLbAU += OfZdJoWNDAIIMfAx;
        QkNQqFmFvVfPo = LhfzdbIQFnZ;
    }

    return HPequJqdM;
}

string qYJkvVNpSMOavemH::uBLKyt(bool PhfRb, double wBFPWyLqLBYSJp, string NZwrkiFo)
{
    double GPARS = -327686.09852796607;
    int vgjGEea = 1378084869;

    for (int DNziHg = 1237909365; DNziHg > 0; DNziHg--) {
        GPARS = GPARS;
        GPARS += GPARS;
        vgjGEea += vgjGEea;
    }

    return NZwrkiFo;
}

string qYJkvVNpSMOavemH::BgeYipN(int eCMWA, int KLeLjBKIXqgayMxG, double eMbQXJflAoec, double bABhhdIXWh, double SuEjAX)
{
    int MWTVILyDWd = -1095114348;
    bool BhagQfxJ = true;
    double SchkT = 1036566.2362826661;
    string wBzYGAdRLS = string("UCqzOCeEEpWGMyZDPCqgCvsxRObiMbaLuTmYPHZUHcsXPJjMSwXIiUhDMZvMXouoolXlDo");
    int FxicjquAr = 1602995207;
    double kpjLxJA = 958230.186882592;

    for (int nriSWNpRDTzGBF = 2070993390; nriSWNpRDTzGBF > 0; nriSWNpRDTzGBF--) {
        FxicjquAr *= eCMWA;
        SuEjAX /= SchkT;
        kpjLxJA /= SchkT;
        KLeLjBKIXqgayMxG *= FxicjquAr;
    }

    return wBzYGAdRLS;
}

double qYJkvVNpSMOavemH::ndnywyCqaFv(bool GBswoCwzoa, bool UDjKbVyeNWQt)
{
    int hHAmEGnyxPYJ = 154630103;
    double sUaSDeBNPfeY = 889440.6269850311;
    double TcgpJgw = -299019.3383828898;
    bool cgDcgDMhcT = false;
    double ylFIRR = -23841.811090158444;

    if (UDjKbVyeNWQt != false) {
        for (int NZQIaRDYmWHdKX = 2041924065; NZQIaRDYmWHdKX > 0; NZQIaRDYmWHdKX--) {
            continue;
        }
    }

    if (TcgpJgw == -23841.811090158444) {
        for (int ASaArJcU = 1417439388; ASaArJcU > 0; ASaArJcU--) {
            continue;
        }
    }

    if (cgDcgDMhcT == true) {
        for (int oWpCTqZASiKBH = 756189455; oWpCTqZASiKBH > 0; oWpCTqZASiKBH--) {
            TcgpJgw -= ylFIRR;
        }
    }

    for (int QFbSHk = 1520589294; QFbSHk > 0; QFbSHk--) {
        UDjKbVyeNWQt = ! cgDcgDMhcT;
        ylFIRR += sUaSDeBNPfeY;
        TcgpJgw /= sUaSDeBNPfeY;
        ylFIRR /= sUaSDeBNPfeY;
    }

    for (int nNsfRWaOPacMh = 1647515210; nNsfRWaOPacMh > 0; nNsfRWaOPacMh--) {
        cgDcgDMhcT = cgDcgDMhcT;
        ylFIRR *= sUaSDeBNPfeY;
        UDjKbVyeNWQt = cgDcgDMhcT;
    }

    return ylFIRR;
}

qYJkvVNpSMOavemH::qYJkvVNpSMOavemH()
{
    this->OEZzeU();
    this->uAsFx(-97387.93405185426, -927840034);
    this->GCPVefE(-588210461, 1929609646);
    this->bIBIMVYtccf();
    this->HToGfzexNYVSEhm(-922118480, -963994.0787227021);
    this->BxShGPA(string("NkEVnmfUBEHTlrTjGtVQloAqfMSyMojFekZwIf"), -1519752641);
    this->TqeBbvuYRvg(-857650209, string("xltPNvyrNwyZbDFsBnQcqVScgxbbyxzfQuYyfcSPfMxaaJMqbnbGFpXttrEwPnNeiqrJDOfKzcWvHRIbdpbSTyTurIczYDdsudtdZGCP"));
    this->UytZHxpxz(395787.5817604936, 874149767, 206314.15284969853, string("uBzSZwRhOPxvnNGgRuiHmwJuylCZZCkmfzBsRdVyNABUDrwnnzNAzasqqMnyquooLWbTqFFERpVMHFhSndLUDuziTLCWnlhZHTDAONoHsDZVqOiWEQpmV"), string("wJctjJIbwkbqDiCwHoDlfRfIMbarymQUBkUpUWUiGdaTWqzuYxWaxbqqbNwMkmgaRXeMSziUpGmJSpJmcjxBxpUvyJXMflYgYCvGPmgKhNGFsgatHdIvqxMeENUOfbsFhjIlrmLiTgWmqxMkCLTSvmqilrrdvuCkAaNSNTidSXVdyMnbQuamXhgYEBygWSLnPDTVOMDWBJCaRNjvGDkVIvoneVLRIrDXrxZbswDwtVfSuN"));
    this->HKbqtkBybXavAN(string("mJGSpcZYmnBxrGCF"), true, true, -118565.02104592201);
    this->WxAFQWPp(703847672, 565957.8798781204, -1029143.1071906664, 856429.4990681821, -1516956023);
    this->KeYzWCHPLWJem(false, -435383.49373745365, true, 865524.2992648412);
    this->UgyYYHkmNzzz(-707477.9538701845, true, false, string("UxhrDHwsRAgjAaaGysxGBIsZPiUvsRjjKFdmvnhfgEvVeqYlkwyUKwKLEGjJfDmrnFNYamrrJjOCYAemGMukbCEewKRoxjzsMwbEOZSWdTCEvNxNWrFhqXDoXfYvddYgYlDARHEkIcGwlaHObzpJXEtnXNFAfwozMezckMRSWDP"), true);
    this->uBLKyt(false, 216479.12638301394, string("MurQjPtxgnzNCNiMAPqKqqSoCqAMOjNtkKRqePheqYnUkLOpXybcDYDxuunHcSxacZqHvunCGwlCbYGBOtZIInEceLXVSzRlAlyAqRVbMPmEwskANSsfHrHrpeBBpGApiHerOiAvwBvmTUsFnnFxUP"));
    this->BgeYipN(-1841091495, -1243477179, -333701.548208155, -754537.0759932536, -480391.6216427773);
    this->ndnywyCqaFv(true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UJlHThBGUXXLEMiW
{
public:
    int DbAuJWgYomorNX;
    string hAUDY;
    string oEbUxx;
    bool jwHcWl;
    string QFEWix;

    UJlHThBGUXXLEMiW();
    double DCgYsnopzlXM(bool ictrjUyK, double JskKPIzgHz, double cpxnJiPBDpuU, bool osouHgXYIAGMG);
protected:
    double sQyFNlTgtgUoh;
    string pcYfjjGfGRgnogZq;
    double nCuzmXiFb;

    void GYIpZdvsKv(bool GgQHiHHfxpZalOcw, bool kpkjl, string FkgRZUkfxP, string PneGEO);
    double tysaNoGAJeJK(string qLlMUyKjN, bool EyBDQhUNlseKk);
private:
    int sCyhfq;
    string YPooCk;

    int iHMZCuiVYQOPMvK(bool qvGSAXJIuGAEJf, double NdRoDlReB, string OZVEqMDm, bool bmHJb, double rmvIJcjZp);
    int vVNNBxdLL(string zWdHyeACYAb, double WpbrgFwpbEQlxtFQ, string ofpfTRy, int aYgxu, double KuUfmVi);
};

double UJlHThBGUXXLEMiW::DCgYsnopzlXM(bool ictrjUyK, double JskKPIzgHz, double cpxnJiPBDpuU, bool osouHgXYIAGMG)
{
    bool QSIBA = false;
    int zNiZRlT = 1261476695;

    if (cpxnJiPBDpuU < 124173.43968374409) {
        for (int UIzWdc = 1337105767; UIzWdc > 0; UIzWdc--) {
            JskKPIzgHz *= cpxnJiPBDpuU;
            QSIBA = ! osouHgXYIAGMG;
            cpxnJiPBDpuU /= JskKPIzgHz;
        }
    }

    for (int wojTJkFWYOXh = 248128011; wojTJkFWYOXh > 0; wojTJkFWYOXh--) {
        ictrjUyK = ictrjUyK;
    }

    if (QSIBA == false) {
        for (int EJfPECSpctiZQvKK = 66618896; EJfPECSpctiZQvKK > 0; EJfPECSpctiZQvKK--) {
            ictrjUyK = ictrjUyK;
        }
    }

    return cpxnJiPBDpuU;
}

void UJlHThBGUXXLEMiW::GYIpZdvsKv(bool GgQHiHHfxpZalOcw, bool kpkjl, string FkgRZUkfxP, string PneGEO)
{
    int egVjybVEKnJy = 383996313;
    bool tACOetceBA = true;
    int yczojEczwVmZZFGz = 1655342678;
    double xLvEEn = -1013835.0496938917;
    double QufYayXudqahRum = -191374.52489642048;
    string QegyLKyetB = string("yJCWDDSNcwkTpgEFQltlYevQSHKRgbbyCmraVUKyvBSmGHiVYTiHKBgolDOgtOdVj");
    bool CylTAlFT = false;
    bool UJghsBRfwJNI = true;
    string VaWgjevU = string("NKxjkSsdzjHVMKdXdnRosfoTvCnZQPnmIYvPCWbJwIIIagxUOn");
    int TpECFUDUjUryCiEj = 144281379;
}

double UJlHThBGUXXLEMiW::tysaNoGAJeJK(string qLlMUyKjN, bool EyBDQhUNlseKk)
{
    int AozAXjMm = 1995268760;
    double QcDtVGZDRnFWTvP = -954224.0222752487;
    bool tapKBjJiZBTeToNx = true;
    bool boyGDv = true;
    int CIkWmPC = -1375739324;
    bool IGvWjbMv = true;
    string envZxHQ = string("KlyNTaHasjdqnYGQyWunxRNzoHxMqSRBiDHcdEGgmJGNtZOKezKXVsYRsbRyFrQipIGwoKbSvJYxBmpbtFqpTdorZEFWojbEshJRlvYjQMVkWaUbASbOjxkrbgqKQLCVDpKpRFRiAWkowOYIPsOvXRiOArEtPaaRRsBUKtMCgNhEVKGwiFjhTggSLlZsvgeEYNXKxRAHKF");
    string qnYjElXqGOLD = string("PBVHeuyuqjfibFAlQIlZNChfGFRFDvGigNolKbzHnEYVKMacMXNVRcjYSdCCLbbdShsVoZfEMMBoyhGbzyWSxfvfiDWqOKLUBHwvLdLyzuOphouGccEmneCmnSQIEdvPHIPXzuoICqWdvXdRzChUCvZTNioJedEqzPBoPeGTlOotfDxVoyMzzEOfJsCCzDQxAtCOZMlalvZPdHeOzekmHFVKVbzN");
    int acjEFkfeNeC = 1156327065;
    int EYSKffel = 1340469320;

    for (int oLhEQ = 222938658; oLhEQ > 0; oLhEQ--) {
        EYSKffel *= acjEFkfeNeC;
        tapKBjJiZBTeToNx = boyGDv;
        acjEFkfeNeC = acjEFkfeNeC;
    }

    return QcDtVGZDRnFWTvP;
}

int UJlHThBGUXXLEMiW::iHMZCuiVYQOPMvK(bool qvGSAXJIuGAEJf, double NdRoDlReB, string OZVEqMDm, bool bmHJb, double rmvIJcjZp)
{
    bool dnBwgNjtLRVj = true;
    int LwAUEEJnPdqMxrD = -1485907455;
    double rzdnMFiGRgleC = 624162.2434820953;
    int WkzyvGQhCmo = 185123892;
    bool eJgImwsCjJYVw = false;
    bool AOeDdLvTi = false;
    string iuLTOjOarhuxwf = string("CUiMcmGDNFaBnopHFfimxXIuTldwqoHFJOuCuKOXtWJAJktSFZdRVWwPyzUpdwYRkQYVBXWvCqeCYYnvRpfvfeGaSMtwyZWEwogZIXOWxpFvIDJgWaXPszVJYNkIgYvPTkgbDVJfjbtjAVKSRfGusjaFOdDVoACDrZrbBodAznaCMqTCukobEz");
    string MaKRribdtYcJoywZ = string("eaQNpjOzgbkkOlxmIjiNpEzNWHfBwKBLcAlQgMrzhOVsKfBaoGSXqBNXbKYjfvvWiHwpNQbcUtGzfIEefbYMUyxutKsbaqmYtLhdSjs");

    for (int ipXiX = 1002879429; ipXiX > 0; ipXiX--) {
        continue;
    }

    return WkzyvGQhCmo;
}

int UJlHThBGUXXLEMiW::vVNNBxdLL(string zWdHyeACYAb, double WpbrgFwpbEQlxtFQ, string ofpfTRy, int aYgxu, double KuUfmVi)
{
    int RubAoOarrmdyKxhh = 628746093;
    double JwViDHq = -451526.5725937949;
    double AdXUAkSoN = -288651.6850649741;
    bool BWpdDql = true;
    int afAWBAf = -1657922329;
    double peksdI = -881185.6331338523;

    for (int imEzPvNgtK = 354126325; imEzPvNgtK > 0; imEzPvNgtK--) {
        KuUfmVi *= peksdI;
        ofpfTRy += zWdHyeACYAb;
        KuUfmVi -= WpbrgFwpbEQlxtFQ;
    }

    for (int Jsfnba = 1468627222; Jsfnba > 0; Jsfnba--) {
        WpbrgFwpbEQlxtFQ = JwViDHq;
        KuUfmVi += JwViDHq;
    }

    if (peksdI >= -881185.6331338523) {
        for (int JXRjgmUInZ = 1565393415; JXRjgmUInZ > 0; JXRjgmUInZ--) {
            RubAoOarrmdyKxhh /= aYgxu;
            AdXUAkSoN -= AdXUAkSoN;
            ofpfTRy += zWdHyeACYAb;
            JwViDHq *= JwViDHq;
        }
    }

    return afAWBAf;
}

UJlHThBGUXXLEMiW::UJlHThBGUXXLEMiW()
{
    this->DCgYsnopzlXM(false, -556095.676193783, 124173.43968374409, false);
    this->GYIpZdvsKv(true, true, string("fYQwHuNKixSbrJJxRPHNTSPAaBbqryjrboHvAluJjuKrgVbMRqTlwORSAXTfeqDEMHOSTFMTcrFQyvfjftqcfZXGMcKlrPKWfORptqrrjrKFQuQWlijhyFGOuQzOfhOyNEQPQtWkirAxiqVweJ"), string("fXgYDmgUjLRRwNIkMlwlcnEDstwkRCZxveGfkFBGyraRCzSAEdSeWgjRCeHVOGCnrZxuQZsxQHZPQWONaoOnzkvhtZckpxCyORQXdyMaxwbRQLjaaWBuZSqTgMXfoRu"));
    this->tysaNoGAJeJK(string("PqfOSgieMGhMrgeeuVAHrczBaThKRiwlkAQxiYNJkaQOEunJMwNQUbSBkRgxvudzxKnpCysWgnotJoFcCfrWjDgGcfYlnIVPEXGVjuRnbHKyNyoIjpXPnmuhjEpSCBZpMyRLCzPHMyKHBaVYQUGCvnBufQiCBYDOIrSaTelfsDNemPMBWerkcb"), false);
    this->iHMZCuiVYQOPMvK(true, -945669.3264496936, string("kpBCBQehCyUnYDITOlBMqvaYDHkhJBRFvVhBwxwqqqbNobQBDDNezZUuHLoQaBcsajzEguJzLMnNDZgEunSIHplQYOcjIjl"), false, 988122.6740523882);
    this->vVNNBxdLL(string("RVnYIpjooxwmxcUbGoYumIDaIgDbsdCdooLuPCGfAgnLqhfzfthTcymESyvRitvlZyhQhJIWdIeqRjNPmuRcinwxGPvLmccQwquTeoIPLDEVeOHHTZvKMDrFvwhBLZSVhcjyBdiBdkUNIsBDjMSljBwApHhzEflSMggIMRrzoPkJDSYQgxAOTPHzXEXuHxUhcBhtVWZNgvlViRJzopxasTchmztUlbGegyYFzDIHzncCxKSmxXRVeyOlVhDjtb"), -392807.28569783474, string("AhDvjiMnkqKcgkmjCgtUVPnXBZpyOIuZexxhOiZUBYrxxrewGUTvavNxfvXClaXixrsLuhCORPQMJKVWsmGFWXxEuwPCjMNAIUxzncyRWeOmJWghKKVeBnEVIitroHOEizFGnppAnnuTzKIfXazWIJFOJFUtKLPpmkiCvZctsggLHYmibzrjPLVhvxiDcsajAayRTOdVYcMzKrgL"), -958881204, -62815.15867549298);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZXlKjGS
{
public:
    double zNeoNw;

    ZXlKjGS();
    double ACkMCeWBYgaCXd();
protected:
    bool hwKjRZPz;
    int esMTSXLNxS;

    string aPoDSWvoShnLq();
private:
    bool DuwsQLxxwIfVKhvt;
    double tFLketT;
    int JAEbNIKqN;

    double eryRljJ(string exyOro, int rSRBv, string aGUdsSQz, int ExJGpYm, int ZzEWJEzAoO);
    int vTEXrlp(string KyaZNTKNyx, bool alKosAhqdi, string mrAaIonMPbw, bool nIrcoNd, int XoyoMhPkiUvGxe);
    bool bHqhUrOKUXFGV(int fqsMFzKGOHLm, int NauqdMykXMVO, bool kxSZPhJVIXWMCABW, bool NqqOzPWRtgfOypIS, bool IALpfEaMZh);
    double OJJnAwBR(string hIhzgzID);
    void ZmAFWNDm(double AzRrQrL, string VeHxzwUHtd, bool jITHodRxSHXEDVR, int yoCJo);
};

double ZXlKjGS::ACkMCeWBYgaCXd()
{
    string IcmLlPjVuJAPvNXj = string("SnqwuNoPGf");
    int IgEkztSjm = -245989150;
    int zoKTZhKkrR = 1019269410;
    string tSxhxJERU = string("cmrYZTxoXtpvz");
    int FGePMVFQczeXSeYJ = -1237876870;
    int TObNpHSbIaWPrCt = -1278465482;
    double LwWBtC = -20441.77306039118;
    string yuyQzTsca = string("oMVolRQnWHIHQyXAlPGEykaAEuSOAdWtZAqAIycwdTfrDibdgVUtRHQoPBSOTDyALikNOFDVLCkgzRkvhtwOYqDjcTLzqdClXsdnIgvrrmeXACFRqbswbEhYhvvXdsmKPxPLZGqznOYMCYblSfCrtBZEJJtTsuRvtUpryHpOSBGvpUY");
    bool BDEodwkZgRA = true;
    double kLaDIM = -465699.21456488466;

    for (int zXGDPYIICR = 2133517866; zXGDPYIICR > 0; zXGDPYIICR--) {
        continue;
    }

    if (tSxhxJERU > string("oMVolRQnWHIHQyXAlPGEykaAEuSOAdWtZAqAIycwdTfrDibdgVUtRHQoPBSOTDyALikNOFDVLCkgzRkvhtwOYqDjcTLzqdClXsdnIgvrrmeXACFRqbswbEhYhvvXdsmKPxPLZGqznOYMCYblSfCrtBZEJJtTsuRvtUpryHpOSBGvpUY")) {
        for (int ENCHjYJTI = 2059590841; ENCHjYJTI > 0; ENCHjYJTI--) {
            yuyQzTsca += yuyQzTsca;
            LwWBtC += kLaDIM;
        }
    }

    for (int CltQaAyxBO = 444893759; CltQaAyxBO > 0; CltQaAyxBO--) {
        FGePMVFQczeXSeYJ /= FGePMVFQczeXSeYJ;
        TObNpHSbIaWPrCt *= zoKTZhKkrR;
        LwWBtC = kLaDIM;
        FGePMVFQczeXSeYJ /= TObNpHSbIaWPrCt;
    }

    for (int iXVCD = 263271525; iXVCD > 0; iXVCD--) {
        IgEkztSjm += FGePMVFQczeXSeYJ;
    }

    return kLaDIM;
}

string ZXlKjGS::aPoDSWvoShnLq()
{
    int ATWrxuC = 395272759;
    string svInUEnC = string("zPIDKlioPCuHRMWOBqhUuDjY");

    for (int uxonKIxbuKnGTc = 855042422; uxonKIxbuKnGTc > 0; uxonKIxbuKnGTc--) {
        svInUEnC += svInUEnC;
        ATWrxuC /= ATWrxuC;
        ATWrxuC += ATWrxuC;
    }

    for (int RJhxXCZTSESEQtq = 651379064; RJhxXCZTSESEQtq > 0; RJhxXCZTSESEQtq--) {
        svInUEnC += svInUEnC;
        ATWrxuC -= ATWrxuC;
        svInUEnC += svInUEnC;
    }

    if (ATWrxuC < 395272759) {
        for (int lTukbVUPPYS = 738388855; lTukbVUPPYS > 0; lTukbVUPPYS--) {
            svInUEnC += svInUEnC;
            ATWrxuC -= ATWrxuC;
            ATWrxuC *= ATWrxuC;
        }
    }

    return svInUEnC;
}

double ZXlKjGS::eryRljJ(string exyOro, int rSRBv, string aGUdsSQz, int ExJGpYm, int ZzEWJEzAoO)
{
    string MXUUqerqRMMCa = string("hRPvNCBuZlLDHWxkTiNAQhnmilEfehODJRDfrYqViJTvgcaXvPkNRjlFWIEkoJcLpxrfmzByxRslXJaeermBgSkUHVkXbUlIQS");
    int NsJmVVHw = 630906607;

    for (int zXQCL = 167770630; zXQCL > 0; zXQCL--) {
        rSRBv += ZzEWJEzAoO;
        ZzEWJEzAoO = NsJmVVHw;
        MXUUqerqRMMCa += exyOro;
    }

    if (exyOro > string("CKeHammaTTigvTcnecWmoObaGZmeLSSnvWOrXYOpSHuTKcvSvGfcagIIBaLEQgWlGOZKFoZRgQUKeXiiEtKCRtyDfWClqwiaIPJLHYAokOdLjiNJDIZuWSfdCKeOBlyfSpUVfzgWhSPtUmbCEmiRrPaRsxLCEGGKcgPxtWWvECMjOtaRifsBgcYRLlRHEJCHSHqxppcNBciJDLKJvWESEmqQjK")) {
        for (int HkoAZJfpp = 851385461; HkoAZJfpp > 0; HkoAZJfpp--) {
            MXUUqerqRMMCa = aGUdsSQz;
            NsJmVVHw += ZzEWJEzAoO;
            NsJmVVHw += ZzEWJEzAoO;
        }
    }

    for (int rCXZWQNzaI = 367498030; rCXZWQNzaI > 0; rCXZWQNzaI--) {
        rSRBv += rSRBv;
        aGUdsSQz += exyOro;
        ExJGpYm -= NsJmVVHw;
        ZzEWJEzAoO *= rSRBv;
    }

    if (NsJmVVHw != -1110308582) {
        for (int HzWggvs = 1822220582; HzWggvs > 0; HzWggvs--) {
            ZzEWJEzAoO += NsJmVVHw;
            NsJmVVHw += ExJGpYm;
            aGUdsSQz += MXUUqerqRMMCa;
            ZzEWJEzAoO /= NsJmVVHw;
            ZzEWJEzAoO += rSRBv;
        }
    }

    return 90309.39768791279;
}

int ZXlKjGS::vTEXrlp(string KyaZNTKNyx, bool alKosAhqdi, string mrAaIonMPbw, bool nIrcoNd, int XoyoMhPkiUvGxe)
{
    string eHrMrbIWhGmUd = string("esIoCJGVMHfRYPvIUCiMnibczbIVPkPeOtWsMyMqnYdgPYLQKivHWzXcQHHhyvvMWMGNUFOjZIEaevRCFpF");
    string MPizLDWwUI = string("wDKOaAkiQUIDBjwuGCZuRggr");
    double MPGhgr = -867664.6373833659;
    bool kbbcHqIUk = true;
    double qTbHfwKAomYEhhb = -899269.5641356132;
    int SJjzdP = -1445102266;
    int ISLTThSWxCjgr = 261402085;

    for (int BoNaPRPLnpPzXpWn = 1934639692; BoNaPRPLnpPzXpWn > 0; BoNaPRPLnpPzXpWn--) {
        eHrMrbIWhGmUd = eHrMrbIWhGmUd;
        mrAaIonMPbw += eHrMrbIWhGmUd;
        MPizLDWwUI += eHrMrbIWhGmUd;
        qTbHfwKAomYEhhb /= qTbHfwKAomYEhhb;
    }

    return ISLTThSWxCjgr;
}

bool ZXlKjGS::bHqhUrOKUXFGV(int fqsMFzKGOHLm, int NauqdMykXMVO, bool kxSZPhJVIXWMCABW, bool NqqOzPWRtgfOypIS, bool IALpfEaMZh)
{
    string ZoLxDOK = string("hTjORbzMauduejjaZGzMwiAujTPdwnvynqdNyoFGGCYiQVAmCjRwUoTmZdRNYJheRaZufeFhtxtuZmLdCzALOKLrnzBhIFqoLqr");
    int ycepgUB = -1538896645;

    for (int GVPsoJxfQMsjnTrP = 563736054; GVPsoJxfQMsjnTrP > 0; GVPsoJxfQMsjnTrP--) {
        NqqOzPWRtgfOypIS = kxSZPhJVIXWMCABW;
        ycepgUB += fqsMFzKGOHLm;
    }

    for (int fZaEpxKhDjxiia = 1631160859; fZaEpxKhDjxiia > 0; fZaEpxKhDjxiia--) {
        fqsMFzKGOHLm /= NauqdMykXMVO;
        IALpfEaMZh = ! NqqOzPWRtgfOypIS;
        ycepgUB *= fqsMFzKGOHLm;
    }

    if (NauqdMykXMVO >= 1626537198) {
        for (int DuIsOTXnoE = 327453810; DuIsOTXnoE > 0; DuIsOTXnoE--) {
            NauqdMykXMVO *= NauqdMykXMVO;
            NauqdMykXMVO *= NauqdMykXMVO;
            fqsMFzKGOHLm *= fqsMFzKGOHLm;
        }
    }

    return IALpfEaMZh;
}

double ZXlKjGS::OJJnAwBR(string hIhzgzID)
{
    bool URMNjmmP = false;
    int jzofqZmoloOJuNR = 1964491662;
    string yoBYpwaowZQrLTaY = string("PWTUOpjNpzGhVqEAeHhqbvFlelCqEmaVmbjRQYOIpwaXAKiCMllPHVpjpefrcqmBOVYEQHLqdstdUgImzWznSWnbebuCxOuNPQzyhwlxWXYFNNAkQToDDmRmnFnUFesXpidMkXBbQyEdLNixUVguouiaXUakexwGCDSnwUrxWn");
    int ozHEauXdGrteFzA = 1998248131;
    int dWIdIDcUXgfRgf = 1557328297;
    double dywqN = 375080.35774277186;
    double OHaATtIIFEijMT = 61269.75377998352;
    double OZRbPWwfbLEUhP = 603817.8412682886;
    string CWHMUHChIbmI = string("HArNQeTqATUdfpfBJBckgxtaYXGVHoQDJuMAntXgGLocVEXJpVBDcjaEXEcuDQMdIsiVwgeOBJOHVQVHaIdudtokYsUvOAunDdHuYbKwg");

    for (int ryxbuk = 874904809; ryxbuk > 0; ryxbuk--) {
        OZRbPWwfbLEUhP = dywqN;
    }

    for (int UPHZHWaSu = 935019895; UPHZHWaSu > 0; UPHZHWaSu--) {
        yoBYpwaowZQrLTaY += yoBYpwaowZQrLTaY;
        dywqN += dywqN;
    }

    for (int pqpGZnPzhQLMrzB = 912420417; pqpGZnPzhQLMrzB > 0; pqpGZnPzhQLMrzB--) {
        continue;
    }

    return OZRbPWwfbLEUhP;
}

void ZXlKjGS::ZmAFWNDm(double AzRrQrL, string VeHxzwUHtd, bool jITHodRxSHXEDVR, int yoCJo)
{
    int YBKfUDilmINQ = 478135298;
    int FaDpFPSbeNaUkCTm = 1583700255;
    string avHvCpjwtOEttqe = string("fNmxuZgIKENuqeWryAkGPbMDsRZHLhneLpERKnczTZywRQeAqCAnNKqQrCErxhEXZRVeUJBYUgQtfuZAkITozDinlXNCbYKjqCjbWVLQFnMdBSPynglZQOFSqCZEUsFWukrVATszAPDBdSRENmllQWOzPDObHjzgXsYCjyWzzIktAeXqdStmF");
    int AFhYOd = 124617611;
    double FbWgiu = 229611.19814947495;
    double vdBoLHOvwdK = -485249.6067553438;
    double lJHslKcGNdypqDps = -849732.8254434445;

    for (int mKqDDI = 1268856241; mKqDDI > 0; mKqDDI--) {
        FaDpFPSbeNaUkCTm -= FaDpFPSbeNaUkCTm;
        AzRrQrL += AzRrQrL;
    }

    if (lJHslKcGNdypqDps != -485249.6067553438) {
        for (int GfKTKYfcYTBy = 211354042; GfKTKYfcYTBy > 0; GfKTKYfcYTBy--) {
            AzRrQrL = vdBoLHOvwdK;
        }
    }
}

ZXlKjGS::ZXlKjGS()
{
    this->ACkMCeWBYgaCXd();
    this->aPoDSWvoShnLq();
    this->eryRljJ(string("CKeHammaTTigvTcnecWmoObaGZmeLSSnvWOrXYOpSHuTKcvSvGfcagIIBaLEQgWlGOZKFoZRgQUKeXiiEtKCRtyDfWClqwiaIPJLHYAokOdLjiNJDIZuWSfdCKeOBlyfSpUVfzgWhSPtUmbCEmiRrPaRsxLCEGGKcgPxtWWvECMjOtaRifsBgcYRLlRHEJCHSHqxppcNBciJDLKJvWESEmqQjK"), -1627794285, string("c"), -1110308582, 45376382);
    this->vTEXrlp(string("nHnpOUfxzTRkrrvMlziYaziekzjIBsVsRBUqyyWyMIxMzLRwloYUqgrmEcmnmzQsvfSuPBJezOrNHalxRYbqCjNVTNIIAWWOOCfqalPueXnAiFqKVJpifieLKApXJlBYckSLrHtldOehuPMQlaEXofvXkLTUWyU"), false, string("YDvDiYJcBQNKwBjxJkAYmZcdaWtxoLqBYAlKHWAvQvCHBTJLvyNNCUxofNBUBkigJRMEEWvNCVVxdjiPSQrRawzHJJArOgQvqFoYgUDyvQYQpmQdQuEWsEAcdlXufHuRbZwjtndxWfktkpzgsICfyOZxZCOUqrWAqZrkixPiB"), false, -1285520529);
    this->bHqhUrOKUXFGV(1626537198, -815277596, true, true, true);
    this->OJJnAwBR(string("pwcEVZQxoUuSlYRieHoPowxMffVWuqNfYjnpgahhtiDlElmWqXoveZvrgugpnyGfzUxggyECEwCrCcUUUgPbZeWVTeQjdKcFFSzTVpHdjcsIwWnQJEygdUtvIlvqXiahRhDwlFeXKtPEfbAVRonoORcrnYnbLoowGyBGRnOvDHeucmRtaGDLtlmOfITZEUpzuPyPRHKYbSnQbWEFapPhruqJPafXXbSwnEmdSPQvoDSVmHWgg"));
    this->ZmAFWNDm(-808567.662381213, string("fAmIbDHxCREPOHDXbXTmQUvKBIuhNwoqArXQXBOoCjFgPUUrcuvdMbAidiZHRYjAIIYLlMuNJUTCkKzpnQIQlchRvfLrTCAMiyPPxZTmjwyIwkXPzRscZsJTBLrYLVeAsMdWylEFJlYJKLwgutlVLZnkj"), false, -111540680);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rltdcrHBtPODBwo
{
public:
    bool ilNsSMOboeTUzvGg;

    rltdcrHBtPODBwo();
    void PVuyAfAUOwvUo(string XoTDEOVdorHy, bool RAUhzISBs, bool gFMfbvARXmU, string cZJgsBeh);
    string sxvRIxNxLwKmmRCF();
    double dkMhJSXmTXlNzU();
    int CxyNALUPwKgaWAR(string wzuiE, double dNkMzKHdYrLBYg, string wHziMlgfKXita, string UFQWybyEAeipQwt, double eGLscHG);
    int IWFkaeXLiKeAgyVe();
    bool IdOFSy(int VtImiWbPeuHzf, string ENNlpYDYxWzr, string Kmkvw, double KYRqSJaRLVsy);
protected:
    string LIeSplBZvqSdkZmk;
    double JZJeTgBDmNyow;
    int SSopDOp;
    string nQXDmJ;
    string sqyDOoXgGhl;
    bool azJThzBixiLuW;

    void ITMnoZUpvbSEKk(double CwzJgTN, string STbmxyIWJ, string TlvUaRZu, bool SrvqFV);
    int sDPdalZaSQUERYiK(double KDKOmTL, bool JHVUaqnjYCeuV);
    bool mtHSho(int snmoz, bool ElAEtpKzMkRNV, double SbzfkZejSAb);
private:
    bool IODEODj;
    string DkCVRWhf;
    bool LkTTTPZFGrcSDA;
    int zTDddRjjQviAaWF;
    bool GNZKdmYPhlnAI;
    int Kmnfx;

    void pWrXWwEScxPODaof();
    string Zrujjg();
    int kKuMZ();
    double KRVrOixthJOv(int GGkGbWa, int ZVlaDeyInkR, double UEAFxIiZZEuilafm);
    void HVTLTvwWkYcCCgGL(int XiUvHfRiFJ);
    int FWJzBqAZzfEtOraG();
};

void rltdcrHBtPODBwo::PVuyAfAUOwvUo(string XoTDEOVdorHy, bool RAUhzISBs, bool gFMfbvARXmU, string cZJgsBeh)
{
    int zwzCoqKVxsH = 929490687;
    string piVBCXVFSlHgVcYk = string("rBwwMDRcxMIdvNToLbZvyvFKMjBxQzVkAwQxUuEJLHmlHuAXZhtqTxWeugeuWVLBQASnFlGBPbjEtCwThzHfID");
    double vveeGnljhMAOzgl = -872511.7295550726;
    double XiutYSeA = -895835.6460215357;

    for (int NgwugMDvyL = 1724930045; NgwugMDvyL > 0; NgwugMDvyL--) {
        gFMfbvARXmU = gFMfbvARXmU;
        piVBCXVFSlHgVcYk = XoTDEOVdorHy;
        zwzCoqKVxsH += zwzCoqKVxsH;
    }

    for (int cYSxYzoXDAytdyu = 1779196064; cYSxYzoXDAytdyu > 0; cYSxYzoXDAytdyu--) {
        cZJgsBeh += XoTDEOVdorHy;
    }

    if (piVBCXVFSlHgVcYk > string("IsVtQiKykAwGrqRDjnxCSfBchkcGufciRssATeVtPZGIlkhEhxFcQdraNFdwUvHquAIHsxPpTTqixlloGyUWZzymUkGHcYyvOXOTXMPQZqoTjxGvzfAfGrMptvEadWgTxYUXvVlFYGGSoCfHKcQXAvfJwWVNXtrNMefWyJhuzPCOcVQbnlcJjqqyZMQShvwziepPxPDfqNshpujJnHfmpPwyRHIkdnNkgOUseYmaOqzXSBMlj")) {
        for (int AusgUiwVNTEnX = 559109888; AusgUiwVNTEnX > 0; AusgUiwVNTEnX--) {
            continue;
        }
    }

    for (int OvZhlZCYXhEQZym = 237555817; OvZhlZCYXhEQZym > 0; OvZhlZCYXhEQZym--) {
        gFMfbvARXmU = ! gFMfbvARXmU;
    }

    for (int YYZmdlU = 898761346; YYZmdlU > 0; YYZmdlU--) {
        cZJgsBeh = XoTDEOVdorHy;
        RAUhzISBs = ! RAUhzISBs;
        cZJgsBeh += piVBCXVFSlHgVcYk;
        gFMfbvARXmU = RAUhzISBs;
        zwzCoqKVxsH *= zwzCoqKVxsH;
    }

    for (int qwCvBjmjFUaw = 932639245; qwCvBjmjFUaw > 0; qwCvBjmjFUaw--) {
        cZJgsBeh += cZJgsBeh;
        cZJgsBeh += cZJgsBeh;
    }
}

string rltdcrHBtPODBwo::sxvRIxNxLwKmmRCF()
{
    int DKExMtvuLQxU = 235224595;
    bool CdVsVsQSbWilHx = false;
    double KyyrafmWBoXilfy = 691819.613024065;
    bool GSyXNgeshjHWX = false;
    string KyoQbr = string("eLfEecOXGVsRfhxxzEHNaVkvqkvSWwYMNMvrAxvIoIQxGCv");
    double luhctNSGAMtR = 18540.603619435802;

    for (int LjPElP = 1664363316; LjPElP > 0; LjPElP--) {
        CdVsVsQSbWilHx = GSyXNgeshjHWX;
    }

    if (KyyrafmWBoXilfy > 18540.603619435802) {
        for (int guaSkxtqbxFU = 1585108752; guaSkxtqbxFU > 0; guaSkxtqbxFU--) {
            luhctNSGAMtR += KyyrafmWBoXilfy;
        }
    }

    if (GSyXNgeshjHWX == false) {
        for (int VwiflQmUxZs = 1892297690; VwiflQmUxZs > 0; VwiflQmUxZs--) {
            CdVsVsQSbWilHx = CdVsVsQSbWilHx;
            GSyXNgeshjHWX = CdVsVsQSbWilHx;
        }
    }

    for (int SOLQUBpqzF = 2077943619; SOLQUBpqzF > 0; SOLQUBpqzF--) {
        DKExMtvuLQxU *= DKExMtvuLQxU;
        KyyrafmWBoXilfy += luhctNSGAMtR;
    }

    return KyoQbr;
}

double rltdcrHBtPODBwo::dkMhJSXmTXlNzU()
{
    double vIRnA = 75795.89300493622;
    bool wezzYN = true;
    int fHXYmn = -1602112280;
    string jeCSashgXacw = string("bafpDIpBDG");
    int UKtwMtQDEXMfX = 1929271323;

    if (fHXYmn <= 1929271323) {
        for (int jTnliFfwc = 1807513580; jTnliFfwc > 0; jTnliFfwc--) {
            wezzYN = ! wezzYN;
        }
    }

    for (int OwGLFXYsOhb = 1407579236; OwGLFXYsOhb > 0; OwGLFXYsOhb--) {
        vIRnA -= vIRnA;
        vIRnA += vIRnA;
        fHXYmn *= UKtwMtQDEXMfX;
        UKtwMtQDEXMfX *= UKtwMtQDEXMfX;
        fHXYmn -= UKtwMtQDEXMfX;
        UKtwMtQDEXMfX *= UKtwMtQDEXMfX;
    }

    for (int DAafmzDY = 1597788742; DAafmzDY > 0; DAafmzDY--) {
        continue;
    }

    return vIRnA;
}

int rltdcrHBtPODBwo::CxyNALUPwKgaWAR(string wzuiE, double dNkMzKHdYrLBYg, string wHziMlgfKXita, string UFQWybyEAeipQwt, double eGLscHG)
{
    string AZXdoAzhGvqrP = string("WSHQXncImVukZaTzQRyWxRepgPvAqXbiBTZAiFtSoNKqvnBLPSuEVRIWiNnoHfXlFSKpJQwveBxjgZusPAfOdJczKyNYcmEvjmIOXmeCQePSdeVSIJEjStolSITSqoXwoVuAEWDFwJxqhyLkEuYaEswRWXMBxNGwOqSXpNjZdNvuZiyrMNANJrkbWbxIKXyeDDuAtiodjsWTRbEGkcKlXmchFjQXpMKEJkSwfqRYPpi");
    bool YsAHmiUrGI = true;
    string usjJVUomwWpguM = string("WsnJqIkkDFDrRfzOnihpnCYsUzTzmRpPceInWtRhKiGNsdqOSSsyacFmrlwOXcWYRCjoWnGTWICGqOCFucsQggUULiLRKQMotMjqSHUDzhdgXXpDJQWYSvsPFdGzENucVDnYHDTlqpHvCGKILLvbsuoZQFyjMhgQMSJvkyBPPlOuiEyHPLgfPsBYuxjwhNjQspWJEVXVNfTHebcEnpJHfTMFNvVCQkJIdSArgpeAofWuXVHVdDZgnU");
    bool thXAXzEv = false;
    string KowshysLFcc = string("HQfefkUXGvEJZEnxgzATsKrgHUovuCbprGuOAcfRyAlqqjWNZVFUdkacQeqQAujpseoxZBoaBKnuPKZkJEiMUEjZWByDkGnmKpfzbzWycqwpkHwivuFWBMGVakCClHMPTVLUesNRpONNStzHUADEIyevaKcDzlwQIlhdKoKktYMBmsZPiOtjfxeBEORmCgYrVDORYHUGbfNtHAhbFwmabhWnRtkPNCasPQRkLhHxNGkosiwICTakEkGgWwTJqop");

    return 1808431756;
}

int rltdcrHBtPODBwo::IWFkaeXLiKeAgyVe()
{
    string gIxuf = string("pFFDlHNbDXNLlJMtWznJHnpwlvnEwyDwkpWXDKkCvIqSNKzVxolAtOpvpKKzUJXiiDMwCcrbAFRXJKtTQP");
    double EoyWXlRqcQUGfxvx = 746722.2103721335;
    string YCxjmsO = string("jlEVFzaKVPQDLLdBsILYgtJynmhGVYoQpqJtootUNTBHbvHApweYhiOAbWtqnGGNcygvwQWKGpkiSZIzFPTmKixsbkmDcDsnScCdLooXdhIhTaYprZCcJSaDB");
    int mruQPEJ = -960866469;
    bool fTIvDzHORySff = false;

    for (int wfZTtMufsmd = 1329314393; wfZTtMufsmd > 0; wfZTtMufsmd--) {
        gIxuf += YCxjmsO;
        mruQPEJ /= mruQPEJ;
        fTIvDzHORySff = fTIvDzHORySff;
    }

    for (int masqdiqBBdxm = 1714728434; masqdiqBBdxm > 0; masqdiqBBdxm--) {
        fTIvDzHORySff = fTIvDzHORySff;
    }

    if (gIxuf != string("jlEVFzaKVPQDLLdBsILYgtJynmhGVYoQpqJtootUNTBHbvHApweYhiOAbWtqnGGNcygvwQWKGpkiSZIzFPTmKixsbkmDcDsnScCdLooXdhIhTaYprZCcJSaDB")) {
        for (int fVVHFCbQZT = 528013793; fVVHFCbQZT > 0; fVVHFCbQZT--) {
            continue;
        }
    }

    return mruQPEJ;
}

bool rltdcrHBtPODBwo::IdOFSy(int VtImiWbPeuHzf, string ENNlpYDYxWzr, string Kmkvw, double KYRqSJaRLVsy)
{
    int UKwUVDbqgYX = 1816176698;
    double nnRdIQWxbHfSYoCB = -794340.9063926686;
    bool YDaCDQweFGEP = true;
    string cQUzkzqmTMbW = string("gINEmrlGsLcxwZiibElzyfOHFTKcujQIHmHGQrLwgvyrKjcvFddCeFLjCOFNxroHEbFpYCXqJDhrPDZCHhDNHdsWDLZfDSVotlpSILuIoYVTmeXitXyuPXIQLwlghXeyuHcgJmpMzQRfYvYPESQComNOdRQsbmLcPtQGNpQzxkYeAozbhIAXtPjjCoEStwPjgIrKMhLCMbiAWAVzAGFwmkmVCSNJiaBGLT");
    int RPfzdWvYstnHSgA = 1886068094;

    for (int pFpvPAWLBfouLSj = 1604993576; pFpvPAWLBfouLSj > 0; pFpvPAWLBfouLSj--) {
        UKwUVDbqgYX -= UKwUVDbqgYX;
        UKwUVDbqgYX = UKwUVDbqgYX;
        RPfzdWvYstnHSgA -= UKwUVDbqgYX;
    }

    return YDaCDQweFGEP;
}

void rltdcrHBtPODBwo::ITMnoZUpvbSEKk(double CwzJgTN, string STbmxyIWJ, string TlvUaRZu, bool SrvqFV)
{
    double uHKRjzZJAzk = 10320.561328087397;
    bool xOIPsxDVFUSn = false;
    double paKpncdoUVuohs = -413832.81823677657;
    int UUVxe = -649299599;
    double QQdDqReDrMJfQ = 688133.4782155135;
    string vmLubYvgdhMoQq = string("qbATfJIZzVVSwHVfhmeqDCnqxVgYynphsJDuGmpnksqSavQcHUIsxsfjpokLkqkUPeZJjpfmucCjSFwBNBhuaVPIQOzRWJmdkJKISTQvlOeLmPOVVojSbNTHqwDRzZEnLoEYeKcekSvNfMjajTMAJuyITQabSsyvmgvnWiwzFnaBimtLtvaBOJiwHxVTeMCMRmINHvyzXURRSdwuptLbZthcOKRkvqykVnUOTKPWKdeKQqdStBftJNEXmP");
    string DYuGDozRHVImLeO = string("QKyUliosRaGkCNpJaMMtuczDHjbqfQyhTRzgmTnFHuCTeMyPveIFQPItpbtECugcWlkJDyCsvxvcaTztdKHXQCzBvtyosVQWvExacZWuaaqmJpIFIBdGxoFikjccPInKvbHMNbQZWEKVvXrIIHeaJzjWbCbQKhbMyqpyGkVFmcGnAyaAPgoThOoVN");
    bool eTxkWfAaBW = false;
    int amMMVggdumREBEwi = -47336970;
    string bpZRR = string("kFPPKIUPntM");

    for (int opxil = 1238119399; opxil > 0; opxil--) {
        vmLubYvgdhMoQq = DYuGDozRHVImLeO;
    }

    for (int cfTOGxEMUvz = 1866284987; cfTOGxEMUvz > 0; cfTOGxEMUvz--) {
        CwzJgTN *= QQdDqReDrMJfQ;
    }

    for (int ZtDIJKByfYKS = 2108712756; ZtDIJKByfYKS > 0; ZtDIJKByfYKS--) {
        continue;
    }

    if (STbmxyIWJ == string("qbATfJIZzVVSwHVfhmeqDCnqxVgYynphsJDuGmpnksqSavQcHUIsxsfjpokLkqkUPeZJjpfmucCjSFwBNBhuaVPIQOzRWJmdkJKISTQvlOeLmPOVVojSbNTHqwDRzZEnLoEYeKcekSvNfMjajTMAJuyITQabSsyvmgvnWiwzFnaBimtLtvaBOJiwHxVTeMCMRmINHvyzXURRSdwuptLbZthcOKRkvqykVnUOTKPWKdeKQqdStBftJNEXmP")) {
        for (int xIHwkmL = 1942796696; xIHwkmL > 0; xIHwkmL--) {
            DYuGDozRHVImLeO += TlvUaRZu;
        }
    }
}

int rltdcrHBtPODBwo::sDPdalZaSQUERYiK(double KDKOmTL, bool JHVUaqnjYCeuV)
{
    int CWMJBBiQpVSRlGV = 958188190;
    double gwdDWDUqmR = 369218.03944514744;
    int QajKpBKzZxmaR = 2079270242;

    if (QajKpBKzZxmaR >= 2079270242) {
        for (int GGZMdHW = 250236347; GGZMdHW > 0; GGZMdHW--) {
            JHVUaqnjYCeuV = JHVUaqnjYCeuV;
            QajKpBKzZxmaR = CWMJBBiQpVSRlGV;
        }
    }

    return QajKpBKzZxmaR;
}

bool rltdcrHBtPODBwo::mtHSho(int snmoz, bool ElAEtpKzMkRNV, double SbzfkZejSAb)
{
    bool NjDuOSNBGiuC = true;
    double tVaYUN = -301494.7313279227;
    string ICtMrffWmrcWcNwM = string("gtvIDRuCDdlgFexQmvpyboKnkaGByKhYSpdERMpaSPJAsUMbHwNyKQOwoeIYlyVkTbScuPMeAegARPEkuquIqImSWJMn");

    for (int dapzyXnVgtYs = 827837400; dapzyXnVgtYs > 0; dapzyXnVgtYs--) {
        snmoz += snmoz;
    }

    for (int quVUXnVLjAeD = 52475745; quVUXnVLjAeD > 0; quVUXnVLjAeD--) {
        continue;
    }

    return NjDuOSNBGiuC;
}

void rltdcrHBtPODBwo::pWrXWwEScxPODaof()
{
    string hFQhwOac = string("AOqbuTAgCQVDpSylajCdGcxBynRIOCRhzSbOXEpubmzMlzqVqSoUEHakpGjkwLneUsBleaPXKXbsZVeFOHVjrXOrxhraZNyRAlELmIoChGDfndrVefDjJRTocMIuiBmCMJubDZWGPiiXudTYbNShuBDrLSFTgFmQZvSOUEoHuhpexhQsnDcjOierjczOsFvKaYJGJIgOfYOgSqcwclRXpryGpVwhcplZqdMZzyxBXupesNA");
    double ZsMYDUwdNj = 983297.5896824348;
    bool JJaHnqRDuoEOmfA = true;
    string torYOEtrKDH = string("unBqUdzNRDfMIZfOOUbUxXKLxEzLoSbzSrnunMImHYJebqSfErFfggIOoxzAywTHnlFILqPifYddJCTjpihshQPUdIewpxtHQajHumAExPDqSnifLbuKRZmnFVbXoFIcicNKzQpAkhcjxdKRwptuZFhZUINbrdMQLlYKWbhIAmlyNqcfjdItcLCqyMDDLZgQOHuZViAmqhqUNHfxFXGdjQhlwfdIZDoSTkErCOGRoYYFHLrEfLsGwTLhg");
    string wlZXTvJqVkrsLW = string("MfsfUVecbroLgJSHTHMpYBPyciebVJjSIaMWDrALufGUVJfpHUdQpVxWVPLpOSnEIhDsVkDBSKCukA");
    bool ZCvXCBSm = false;
}

string rltdcrHBtPODBwo::Zrujjg()
{
    string IcbfxywxDrrwUTn = string("tEjsXSDUGJvIaGMvdMpyiFzkxGbqtGklWubSaiPOWgOrEKFreXXypMLDFQMNbLKimPypWsABHQFtCatrTsQxJZHLCmScVTBIiuIXXSHvRVGrfAvCpWYiEhwBevSWYQlapQcDlFoqeSeIIpR");
    string ecpQPm = string("CJyhfaeIKWykcSohsolMCZrSKSIKIZowgycYIqHkBSuYFhDjIRuHdDTca");
    int TKlMnuDgJybavCPh = 1255425456;
    string vDqUrbZmBzfh = string("ihgjuEakRaECtKGUvRuiFHwlbGClPnSPhnfVbGVraeUJFxXEgKoxUpoMvKTjrxcSDboRfJfUBSKIiHlhySDKWZEIAJfwluOMYlIZFbUncEdEhVQHLDoOfDFRhiWPXITNsSZExcKmcrEUAbRlceFxaEXApaTBCAeYIrpQVuPxDvWRxhBfysjsgDtWKSS");
    bool FRYOBQpGPbVmEeTR = false;
    string Suyawd = string("mMDelojJSTtsbJBuIglzFKtiJhEZOSCvSNTlVQvMt");
    double dsJOPjxwLzCLug = 611856.7318906627;
    int thzMqemMWIk = 92326348;

    if (ecpQPm >= string("ihgjuEakRaECtKGUvRuiFHwlbGClPnSPhnfVbGVraeUJFxXEgKoxUpoMvKTjrxcSDboRfJfUBSKIiHlhySDKWZEIAJfwluOMYlIZFbUncEdEhVQHLDoOfDFRhiWPXITNsSZExcKmcrEUAbRlceFxaEXApaTBCAeYIrpQVuPxDvWRxhBfysjsgDtWKSS")) {
        for (int RkbyocxQzzTcE = 1790686924; RkbyocxQzzTcE > 0; RkbyocxQzzTcE--) {
            vDqUrbZmBzfh += IcbfxywxDrrwUTn;
        }
    }

    return Suyawd;
}

int rltdcrHBtPODBwo::kKuMZ()
{
    string RVykeBZRSXQ = string("FzFIeVnjaxfLWkxDQuFeQeVCsmylBZrelPwGiiCTQvZKEyWJMjhpOSoifNmOFpkmMRgBMgHgGVyklLoObJrndxAKYdwFfinrEWoXQtpbvXZYyColAcmeBfyhabSngYXakFXuDcgyepnbtGWMobYqZYuFhrMBXMsCfWRcQFBwJcObQyYiBaUyadnhmpgvCDbgXliiRPRJADtBidDURgvXpXoLlFOpymHFgTsBGvvaJroE");
    int NJiYWyWpzMSET = 975126314;
    bool JRZgWhRdc = true;

    for (int uhFnum = 1922092462; uhFnum > 0; uhFnum--) {
        continue;
    }

    return NJiYWyWpzMSET;
}

double rltdcrHBtPODBwo::KRVrOixthJOv(int GGkGbWa, int ZVlaDeyInkR, double UEAFxIiZZEuilafm)
{
    string cyvUbs = string("qzRYVYpmhyWZSTALASHStZAQJXVXBXvnjjeHqJZIqreASCFyagZXDYwBWbxVJASoCJlPuhdqTWtXVJkJKAlKXmLLQDmEnrgLzGbEseBJpSLQzDDUMSygaItTbkPNBNWdZBjelsA");
    string GLkcxEaVRUrc = string("NvwyEywfycSkIcWZjRVXKVplGWuOyuTiOVbaYiYxxCo");
    int fbkdBblKBVAvwojR = 370204082;

    for (int JvOWUS = 465268111; JvOWUS > 0; JvOWUS--) {
        fbkdBblKBVAvwojR += ZVlaDeyInkR;
    }

    if (ZVlaDeyInkR != 370204082) {
        for (int LQFzeR = 369955626; LQFzeR > 0; LQFzeR--) {
            GLkcxEaVRUrc = GLkcxEaVRUrc;
            ZVlaDeyInkR += ZVlaDeyInkR;
            fbkdBblKBVAvwojR += ZVlaDeyInkR;
            GGkGbWa *= GGkGbWa;
        }
    }

    for (int ggWendBwqtq = 522552564; ggWendBwqtq > 0; ggWendBwqtq--) {
        GGkGbWa -= GGkGbWa;
    }

    return UEAFxIiZZEuilafm;
}

void rltdcrHBtPODBwo::HVTLTvwWkYcCCgGL(int XiUvHfRiFJ)
{
    double kljagsYGUlQGcN = 481936.9109719231;
    string JPBTdwZubqdn = string("sHhPqTDYEEYuFzaOxMfljVHJmjpnORnNgTlztqJSvBnftbwvqchFZtZlXLCDoaWoZryRQXRQEcjYhlYRxGjqRGsjvaZplufpwGkdiPOMfPvuYRwvDzgNQatciQzFIIhslpzgDzpgzY");
    int dsJarGLfgNAs = 56578686;

    for (int KxFHIUmSilw = 2095513765; KxFHIUmSilw > 0; KxFHIUmSilw--) {
        continue;
    }

    for (int saqOYCQShbWC = 1013930107; saqOYCQShbWC > 0; saqOYCQShbWC--) {
        XiUvHfRiFJ /= dsJarGLfgNAs;
        JPBTdwZubqdn = JPBTdwZubqdn;
    }

    if (kljagsYGUlQGcN <= 481936.9109719231) {
        for (int GpTfnVZkY = 399856473; GpTfnVZkY > 0; GpTfnVZkY--) {
            kljagsYGUlQGcN *= kljagsYGUlQGcN;
            kljagsYGUlQGcN -= kljagsYGUlQGcN;
        }
    }

    for (int pljIdDi = 1218896246; pljIdDi > 0; pljIdDi--) {
        JPBTdwZubqdn = JPBTdwZubqdn;
        kljagsYGUlQGcN -= kljagsYGUlQGcN;
        dsJarGLfgNAs += dsJarGLfgNAs;
    }
}

int rltdcrHBtPODBwo::FWJzBqAZzfEtOraG()
{
    bool rhdZhaem = false;
    int zeimOSVF = -1808551979;
    string kbKqYklxKavloEf = string("zmMgyzqdSRwCopBYGlrJbIbYcBwVjOXVaDKpsOMfnlarPCUuEUlmLuJTjBPFLmGLMiDjuYVGeleWnMhYovYecmngBDlvJbNczmKjoFUjLORRBSSwADRqTsOzfAYizCaoBITzbairtesLpwglmOvHNxPXatNIKEDNWZWpJyoWExIcWDNPXZeJVJPKGyeXZrKvpKNSMAegZBaXtvfDeMNXjiPCFIErarYwwZZiZToALduodcXBhfi");
    int OoTUCWRp = -492718409;
    int fDZadYqDxAWpzBZ = 793443620;
    bool QgNtwNn = true;
    bool IaDosNeBy = false;

    for (int UnJGac = 2132296503; UnJGac > 0; UnJGac--) {
        zeimOSVF -= fDZadYqDxAWpzBZ;
        IaDosNeBy = IaDosNeBy;
        OoTUCWRp = OoTUCWRp;
    }

    if (OoTUCWRp > -1808551979) {
        for (int vwtwykqPviMdp = 1271116457; vwtwykqPviMdp > 0; vwtwykqPviMdp--) {
            continue;
        }
    }

    return fDZadYqDxAWpzBZ;
}

rltdcrHBtPODBwo::rltdcrHBtPODBwo()
{
    this->PVuyAfAUOwvUo(string("bFdGZDYZSyRqngUrsOTQfIHsZpVHrcHZykvtDxBpemqEbIMjqkgphE"), false, true, string("IsVtQiKykAwGrqRDjnxCSfBchkcGufciRssATeVtPZGIlkhEhxFcQdraNFdwUvHquAIHsxPpTTqixlloGyUWZzymUkGHcYyvOXOTXMPQZqoTjxGvzfAfGrMptvEadWgTxYUXvVlFYGGSoCfHKcQXAvfJwWVNXtrNMefWyJhuzPCOcVQbnlcJjqqyZMQShvwziepPxPDfqNshpujJnHfmpPwyRHIkdnNkgOUseYmaOqzXSBMlj"));
    this->sxvRIxNxLwKmmRCF();
    this->dkMhJSXmTXlNzU();
    this->CxyNALUPwKgaWAR(string("gRxMPcMnlOvxvzXzQEKujVmBMOrYMvpwsarLGVSESmbfFQGrJTUWTcPQaRiGCQlGYKfhrYjAptgymfmZHOIoncMijNyTiOzTHJFsgtXeHdyDXgGTwHoirjrJnfOTQhFPsIftxY"), 633252.8959253305, string("uRPNPpHYneFBNttjXvBLUKqgIjpCGiIXPljPYEEkEDhtZZvSYQjLpJPjGBoWFYauvpUxSWzOvqRXnCSwHgbVJVGKAXjwXdkEIRjjHaneppmagsUJxAsgFnplnjxRBOLRDCEd"), string("SQTBEmdZYrMmDBGyvarCUlERnOkfAEvIUvcGDoTclmAEWBiZgu"), 293700.06217125716);
    this->IWFkaeXLiKeAgyVe();
    this->IdOFSy(443604410, string("FvUNVgeahuneQwhDPzIbaPsFLslAhMPuPFUeOewWyDuwRMlPlFBOBUEWcNfXgDxPXvJIPRukkvADBpTRhIdkARrWpnoKTRQSKmykCJhthdvRNatEmUppnXyxAlpmmjhlNPlDppmRWAIEMkRtRHMZgiByIoREvYFnmnHRzAk"), string("eDCTtcfjNaEUCTzgQsyOcGgvfSiBnpSgFHOAjAobiyZGZOqHyLqNoGPvkBhqUIJcbpHixKEcAzmMXnydXYnpgmoibFdainBFKnjLmcDvvaxBUWMZhTciXJzhhymoDmEthAoeXHpHtuxICCaoSggTAJaRYVgyFtHlkrOdGcVbbCFUIEZhmDUvsV"), -771449.227204206);
    this->ITMnoZUpvbSEKk(-72915.8006733224, string("zdsrUOnwPhrdgMWxoIeCQXPLmhsqbMyrBgryUwDgDsoHAmlSrBgNHytvLpxJwrtKmBMgzcFhSFpirweBxFfgMsELVWzrJeHuiaAQnwNDOOXszRbpFZTyCKRRHiaJescRfoEvcNJjqxIoZvraVsuFGaTIEF"), string("GiVWpNTWOgKqFiQMkoHHVYAniqColYTsOxeZuqujgUgCoBpDUHYHuUEaMKZcfrWltVIHaavoDAYXRzxvzepEJDNaVKxmankWShAfUOoukZoWoxzgmPEKSiUpNYcpvjsBKsAbRjpyXkSQQquJyWeFiPLdgwgAFsiSROfhgxpVZOyDjqpCMvObHwSdpQBYYTmoQrXjFJpvkdDqnRfOTpmjcUKQRUYaoeVckEblYNNSnpLWn"), false);
    this->sDPdalZaSQUERYiK(588243.6655567539, true);
    this->mtHSho(1429064814, true, -645264.6627252088);
    this->pWrXWwEScxPODaof();
    this->Zrujjg();
    this->kKuMZ();
    this->KRVrOixthJOv(1306607256, -1610345389, 591088.0633997658);
    this->HVTLTvwWkYcCCgGL(-1339822788);
    this->FWJzBqAZzfEtOraG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KSIJccdqBm
{
public:
    bool fnbdOro;
    int esjQiBMSzrTTCVCw;
    bool XGSHXBOSUrbLwFJ;
    bool vyfgGKStSyX;
    string ASSdi;
    int XUrGkMEdgvZdEYYj;

    KSIJccdqBm();
    void LcPusPwQlitF(int vJDtsjyGlAbMBRG, double qmGLVmL);
    string YQNOdgwK(string vBRRezZJx);
    bool siQaxZR(int VAXYRoALpkfYlC, string GXjDvfP, double NMxsZoUv, string MqeWrjeoQMNfNiLq);
protected:
    double ouNSyyysulc;

    double mjsjmmQZrKYiPjyy(int WvwDbWCuwsheN);
    void qMxoQwwsefhIQe(double uRKJKMUGOPmmBwv, double iEUOmi, bool BjMnPRmB);
    string LbNhDcsFpD(string DFMGRGKzgrjp);
    string eleVUDER(bool SvtKVehtqY);
    string lZfSoXFLoUh(int sGewZ, int OyYFrlVLcqiobku, string pLgdqQbhLPTk, bool QMZoFwadmMa, string NljbPpeaRSgz);
    int xYkggKkNZIIXL(string zocquCzYRXVYJuqC, string FQgzUkqlDtjoGPrr, bool gTSQsTnuKoiI);
private:
    int RWPdpRnqIpUjEK;

    string pqfRL(bool dqjNQjz);
    double FSNVlaRbCCy();
    string MljtD(bool RYwDVlTnbiQw, int DScZxg, string GzLvXkXGv, string aDtMFSiP);
    double qdscOPkeunJfE(bool hkhBe, bool Bthjm);
    int IZowWtRqQpDdD(double yqrKrJ, int PleigYIuUBr, bool LdVjSiYqWW, string BdPQqpxTVpqL, double mSxWifGWwjSm);
    double TaVYpwOvxvmuWtb();
};

void KSIJccdqBm::LcPusPwQlitF(int vJDtsjyGlAbMBRG, double qmGLVmL)
{
    bool sSOzWNjllNXSQW = false;
    int rNNkOKKRzH = -1250107592;
    bool zopgAaL = true;
    bool NECqJM = true;
    bool jaqGaytVe = false;
    string HihMiLf = string("vLzPtwURwqtPDUrZLZmaaKuTQqOAwWFPKRardOPPPHgSudpKwzCbgWItHeWgZPiwkCHxlimlLMRvYjpcmkBMHkNWftMhkbgdnXOxafXFMlGgUxgozBvKGdAwmjiSohBORgXSSWXdsARHzouXEnYoTEPaJbYUgWpTHQPkcUSCMjwAPQZQIwhcNKYcFxoOgNBUEIuKjk");

    for (int SUzrlAbjBQzCzfXi = 1237902595; SUzrlAbjBQzCzfXi > 0; SUzrlAbjBQzCzfXi--) {
        zopgAaL = ! sSOzWNjllNXSQW;
    }

    if (sSOzWNjllNXSQW != true) {
        for (int CeJblhmV = 884195875; CeJblhmV > 0; CeJblhmV--) {
            continue;
        }
    }
}

string KSIJccdqBm::YQNOdgwK(string vBRRezZJx)
{
    int FCealgp = -1315621556;
    double iIBojArFqDkNgvsd = 562386.301641876;
    double zDPViPfZ = -766298.1064082664;
    bool rpVjVEcpQwVNXMp = true;

    for (int fDjcSkIRivZD = 1130179328; fDjcSkIRivZD > 0; fDjcSkIRivZD--) {
        continue;
    }

    for (int LwveViqxRjlyPzHy = 258369373; LwveViqxRjlyPzHy > 0; LwveViqxRjlyPzHy--) {
        continue;
    }

    for (int HALEihGcubMkWI = 43121721; HALEihGcubMkWI > 0; HALEihGcubMkWI--) {
        zDPViPfZ += iIBojArFqDkNgvsd;
    }

    for (int mRnOVOkrYoQHX = 612611081; mRnOVOkrYoQHX > 0; mRnOVOkrYoQHX--) {
        continue;
    }

    for (int bBxxO = 1909784788; bBxxO > 0; bBxxO--) {
        continue;
    }

    for (int kuEDHZncRpeURzrm = 716251894; kuEDHZncRpeURzrm > 0; kuEDHZncRpeURzrm--) {
        FCealgp += FCealgp;
        iIBojArFqDkNgvsd = zDPViPfZ;
        rpVjVEcpQwVNXMp = ! rpVjVEcpQwVNXMp;
    }

    return vBRRezZJx;
}

bool KSIJccdqBm::siQaxZR(int VAXYRoALpkfYlC, string GXjDvfP, double NMxsZoUv, string MqeWrjeoQMNfNiLq)
{
    double BHjEm = 872485.7890512459;
    string vYCeNqT = string("UbwSbDUbyTVhbojsHqscriCpbKUdBcIzotEQHXtxnxmQhstcHsxnaqguJqahctiMkAGyJSkEKZEVWojjuOhmOKrJHTyfrqYDGnzneKmbQCWtJGNKQIAEAPVBHFROwSXjhSUzXHAmGRQMIBkOTQjmnHaChoheLSHJsJJUxvpqKXQSxGLUZtyroYfYrcOdyPpdzXtfoqNXZPAwBbLqbMjqFtUAvPQbsFXXW");
    bool jHhXjwZHhEBKimkm = false;
    int htoLDEXnayjwok = 748930146;
    double rXlgZBrvHzSXCf = 746360.416675598;

    for (int DuEkLqbxZaJorg = 1679771356; DuEkLqbxZaJorg > 0; DuEkLqbxZaJorg--) {
        GXjDvfP = MqeWrjeoQMNfNiLq;
        MqeWrjeoQMNfNiLq += GXjDvfP;
        BHjEm = rXlgZBrvHzSXCf;
        vYCeNqT = vYCeNqT;
    }

    for (int ikPRKTVM = 1838688799; ikPRKTVM > 0; ikPRKTVM--) {
        NMxsZoUv += NMxsZoUv;
    }

    if (vYCeNqT > string("jnINnidXuNoZSYGDJLWwEYnfbNtgBOeDbHtfdBalkRZwTXbuDEMRTtogxDnZbbWNWsuvToHqooeIlkTBqvZdVNFBCWERGLajnINGYCgOrRAcbBvjyrNlCVyShKLLCgEaHEoiyOdbelVYbRizJzHsCARSLkTVWzKtlPbSeftDImqEzWjGDfmAUrjPKRhiontlSFvEXiXLboOnmMCxVwlvbRCsCXlKFhOqloxGY")) {
        for (int BKjtbZh = 1335177525; BKjtbZh > 0; BKjtbZh--) {
            vYCeNqT += MqeWrjeoQMNfNiLq;
            jHhXjwZHhEBKimkm = jHhXjwZHhEBKimkm;
            NMxsZoUv /= rXlgZBrvHzSXCf;
        }
    }

    return jHhXjwZHhEBKimkm;
}

double KSIJccdqBm::mjsjmmQZrKYiPjyy(int WvwDbWCuwsheN)
{
    int DHxQDQzWO = -537174487;
    string MkHfdKrXkPI = string("FSXjsheGrRPaPHuNtySNNjYZXwGUkWQJrHZpLSorRzoZPyWYKGomWBffMBNSMLIsWHmYAshxcdkvAMvfZXCAyNTSLfdRSiWPbQsplPOuszECJVHxLSTrrcfFnTCmzBRAoSNXaxdrDkItSJmwzQtvpTsZXbuxI");
    int FxQBWBMBqmXsfIeO = 175302945;
    int SGhlo = 916830428;

    for (int snrvgM = 2103269073; snrvgM > 0; snrvgM--) {
        WvwDbWCuwsheN = DHxQDQzWO;
        SGhlo = WvwDbWCuwsheN;
    }

    if (SGhlo >= -537174487) {
        for (int ayyxJGdvICmo = 432952860; ayyxJGdvICmo > 0; ayyxJGdvICmo--) {
            DHxQDQzWO -= DHxQDQzWO;
            DHxQDQzWO *= DHxQDQzWO;
            DHxQDQzWO *= DHxQDQzWO;
        }
    }

    return -870558.0064153959;
}

void KSIJccdqBm::qMxoQwwsefhIQe(double uRKJKMUGOPmmBwv, double iEUOmi, bool BjMnPRmB)
{
    int rxhVHthyDLL = 1846449383;
    string fRAkwxhwc = string("fYoDEWfHUUWmuiPyJpgXZxhYirADjpJrVSIddrXQZmmRJcLKBUzOGnHvidBQFSiRPLJHhpSkRWMyqtcZHErAnRyRttmGFBqPyyheWJXtjThwaNBiAEsWwjgLCtlhHWOPtLGZVZiVKzDf");
    bool nzNUpicAluUPKNG = true;
    double jiHAhxWBf = -1048177.4346703097;
    bool gOkCimdOuyNcp = true;
    bool yBDgbgubaI = false;
    bool YPfYVCmRkDEO = true;

    for (int odmkLRRLlesrRHi = 190851137; odmkLRRLlesrRHi > 0; odmkLRRLlesrRHi--) {
        gOkCimdOuyNcp = ! yBDgbgubaI;
        nzNUpicAluUPKNG = nzNUpicAluUPKNG;
    }

    for (int cUpORomeAszsHWby = 1007948588; cUpORomeAszsHWby > 0; cUpORomeAszsHWby--) {
        gOkCimdOuyNcp = BjMnPRmB;
    }

    for (int tuyrs = 569719016; tuyrs > 0; tuyrs--) {
        YPfYVCmRkDEO = nzNUpicAluUPKNG;
    }

    for (int fdKzEmaB = 1424403274; fdKzEmaB > 0; fdKzEmaB--) {
        iEUOmi /= jiHAhxWBf;
    }

    for (int qAZfWRinEPxxPzcU = 1149130355; qAZfWRinEPxxPzcU > 0; qAZfWRinEPxxPzcU--) {
        gOkCimdOuyNcp = BjMnPRmB;
        jiHAhxWBf += jiHAhxWBf;
        uRKJKMUGOPmmBwv += jiHAhxWBf;
    }

    for (int HfArioDIDAAA = 2126240904; HfArioDIDAAA > 0; HfArioDIDAAA--) {
        gOkCimdOuyNcp = YPfYVCmRkDEO;
        uRKJKMUGOPmmBwv /= iEUOmi;
        yBDgbgubaI = gOkCimdOuyNcp;
        yBDgbgubaI = gOkCimdOuyNcp;
        YPfYVCmRkDEO = ! YPfYVCmRkDEO;
    }
}

string KSIJccdqBm::LbNhDcsFpD(string DFMGRGKzgrjp)
{
    bool pDguziZevMY = false;
    double VhglqabqivsyjHl = -978456.1374163599;
    int giWmRNAmOcwDqOrb = -462807129;
    bool xZUxzLTmrUE = false;

    if (DFMGRGKzgrjp == string("gRdXUfPkhexRpddzJVUCmVDKahLUtlDQaSIZDUqDcWHqEUWngjtWmSMrFSabRaISHgcZNHZHLZHVBYlLkoTenRwovbqfKayyoGFjLJCHEOVrQgxoqpniyovmpuIxeyXKabWIHABVOLdGUnkrWMyozYaoBXzmSVLdFGtIpgHcOHMhYKTEKiRxxeCXFucQPGvFDtsGIvhttO")) {
        for (int cswRmREjDKGZSdq = 138253246; cswRmREjDKGZSdq > 0; cswRmREjDKGZSdq--) {
            continue;
        }
    }

    if (xZUxzLTmrUE != false) {
        for (int nVSAsE = 1152220563; nVSAsE > 0; nVSAsE--) {
            xZUxzLTmrUE = xZUxzLTmrUE;
        }
    }

    for (int SHockCw = 2070441441; SHockCw > 0; SHockCw--) {
        VhglqabqivsyjHl = VhglqabqivsyjHl;
    }

    for (int JuyKNferiB = 810911414; JuyKNferiB > 0; JuyKNferiB--) {
        continue;
    }

    for (int QlGcTeuGEHz = 1639210136; QlGcTeuGEHz > 0; QlGcTeuGEHz--) {
        VhglqabqivsyjHl += VhglqabqivsyjHl;
    }

    for (int KgXBa = 876318180; KgXBa > 0; KgXBa--) {
        xZUxzLTmrUE = xZUxzLTmrUE;
        DFMGRGKzgrjp += DFMGRGKzgrjp;
    }

    if (pDguziZevMY != false) {
        for (int BviNK = 684368309; BviNK > 0; BviNK--) {
            continue;
        }
    }

    return DFMGRGKzgrjp;
}

string KSIJccdqBm::eleVUDER(bool SvtKVehtqY)
{
    double pUEwWURmSpCBuqGc = -721845.8563287177;
    int vgiBuiLRxZtVMo = -592666484;
    string UGgEIpZTpF = string("AWzGLdjIpz");
    int oDRNbeZnn = 1019963194;
    string JkbRKuofhAHWkd = string("qpKngADZyHclSuksMheeFeTEpXzIqLJctUlUMrZbQwZvbuvZFjtLzGJrEEAFj");
    double vUJUXvsACmlah = -348425.4041698441;
    bool FPevuzkPykhHZifO = false;
    bool NodgMC = true;
    double VbGJtnsFi = -954684.6984587177;
    string ZjPhGH = string("uJwcbWYJgiQx");

    for (int KbvQVFtFgudIg = 1975614785; KbvQVFtFgudIg > 0; KbvQVFtFgudIg--) {
        SvtKVehtqY = SvtKVehtqY;
        vUJUXvsACmlah *= vUJUXvsACmlah;
    }

    return ZjPhGH;
}

string KSIJccdqBm::lZfSoXFLoUh(int sGewZ, int OyYFrlVLcqiobku, string pLgdqQbhLPTk, bool QMZoFwadmMa, string NljbPpeaRSgz)
{
    int ZEkpSTHte = 1883715807;
    bool PhVsrGsxX = false;
    bool tjFYXBKVrkZlm = true;
    double JZBMdHdYrXV = -367481.70493424655;
    bool kAOReNTDDtGPfk = true;
    bool KRVSchPvrLMoKU = true;

    if (ZEkpSTHte != 12799014) {
        for (int pYgceawGDZpa = 1952162873; pYgceawGDZpa > 0; pYgceawGDZpa--) {
            OyYFrlVLcqiobku = sGewZ;
            kAOReNTDDtGPfk = ! PhVsrGsxX;
        }
    }

    for (int osJWorBTLBByq = 830062953; osJWorBTLBByq > 0; osJWorBTLBByq--) {
        QMZoFwadmMa = QMZoFwadmMa;
        QMZoFwadmMa = PhVsrGsxX;
        sGewZ -= ZEkpSTHte;
    }

    return NljbPpeaRSgz;
}

int KSIJccdqBm::xYkggKkNZIIXL(string zocquCzYRXVYJuqC, string FQgzUkqlDtjoGPrr, bool gTSQsTnuKoiI)
{
    double rfPhv = -858746.0288202864;
    double bHNhwFb = 985249.1994814359;
    double HkppKDslRkuG = -943051.2039896705;
    int fWrze = -1046509080;
    int skybzwPpyPfbpm = 427496751;
    string wIUaTwVQFfLl = string("JQZXBxthzapJwJemEuLOKnaoSSxOIQaJqYJdrgofWxBvymHFdKtXQGWt");
    double OzQjMMUK = 292912.73285156686;
    double ssajt = 530946.6654873273;
    double pMNbVBgnyqkU = 176331.0247819629;
    double mNZLhUqK = 702384.4418520832;

    for (int hMpekBR = 1650500647; hMpekBR > 0; hMpekBR--) {
        rfPhv *= bHNhwFb;
        ssajt = bHNhwFb;
    }

    for (int tpmwqQhree = 1519476575; tpmwqQhree > 0; tpmwqQhree--) {
        pMNbVBgnyqkU = mNZLhUqK;
    }

    return skybzwPpyPfbpm;
}

string KSIJccdqBm::pqfRL(bool dqjNQjz)
{
    string VfyUUPiPB = string("sqUhcdqVtMgSRyqgtyNdeLyGwJIzFCLeAARSouyjInlbUIhGkqddsaRhiXrFEjZACFcjDnPCbwPjkeYSYHBuDRDhCGepCQYcSDiyEUWqwfufqrRB");
    double ctCNqjGhnITKjt = 439901.6819014141;
    string uElYpWvibad = string("FVRUpHlEuTZrGXDLJfCBHDhKRuqUIgwrDOvuEXQvjDYsjgnCobBUIFGr");
    string hcCuEJ = string("ZPlNgpWWtwnGAByewEHXbWzRimBvPNniOqtoeYlGbePzlkvIjAvGKpvMCnmFUGgqIUlboeJGVkdEoljEzHVfnXSrMvKEsOdAsOYgIjyAdVFBKfpPdOGJdCuqpLdAPxAtkjALQTXYHCYAmAbVJJYmYPBcKpTPqtVoBPYPmRJHpRddnoIvMuUIXkjvIhUfzIzlEVkfMuuHzCLFSVHbvZvXCLnBjanxCYdHWkAydvCInijfHyVOkrdLuMGl");
    int JRcDfSt = -350112033;
    int niEWeJo = -1518532129;
    string iDuZuVACVto = string("lcZEyjZjBXGtNPlpWrhYrzUyEvZnwDoWKIsFFiRdkJVsDemnZvGYzmYOXYzeAOsItaFWrVyVYExdtRaNwBLhPtAqRXlQRJVAXtAANlXaOniJoxiyiOmuPDBBpPwWkExoCjhFOIgdZpSAvFjtCqFwlSGGJrGnhHdVCKjuaNYwOcjwRLaDoSZGlERKRos");
    int ZoBVYVAgbB = -762689017;
    double mVcIkGYeoGZcYG = 202252.82310783307;

    return iDuZuVACVto;
}

double KSIJccdqBm::FSNVlaRbCCy()
{
    bool HhhMGPqICdhBncs = true;
    bool crIBXXCfhYmZrjt = false;
    double dGbHmmPbXdSqRTws = 598643.7217844815;
    bool XfrWiYQnaR = false;
    bool KxgCeUGa = false;
    string kgubeuUPk = string("MUWVdaqlmdOMykmgYdCDfSFYbbASTSTLEcoPZzFWNbXSPyMtqCnDYDmwsRZmepoedgwpOHuMsYdjclPpvxitQlznKQytkIjAxcxFurFgwZgmzpCDC");
    bool uAeeWrWGi = false;
    double kXSqUNId = 768332.6641881915;
    int CCLHmyqyGvTJ = 728777639;
    double ACZHMCtnRpu = -814917.8992160214;

    return ACZHMCtnRpu;
}

string KSIJccdqBm::MljtD(bool RYwDVlTnbiQw, int DScZxg, string GzLvXkXGv, string aDtMFSiP)
{
    string WMSkJSrQsnrJVTJa = string("xDNZTMNmhnAtYrcbgYnrqDzVMmxpxiXULGMOtOZdTgntNIkzKQUWyPTizlPMMBoanUfrjOJoTWueksLLkexvSpPHsyBIdweEcuAzKmEXmgiCpnt");
    double HzWcbzS = -712491.6876796111;
    bool mktTMSMVcxsyzSyQ = true;
    bool UTtofFYw = true;

    for (int vSkXrjsnubxfFqv = 925168487; vSkXrjsnubxfFqv > 0; vSkXrjsnubxfFqv--) {
        DScZxg += DScZxg;
        HzWcbzS *= HzWcbzS;
    }

    for (int PMmXsxHX = 1178894143; PMmXsxHX > 0; PMmXsxHX--) {
        UTtofFYw = RYwDVlTnbiQw;
        WMSkJSrQsnrJVTJa += aDtMFSiP;
        mktTMSMVcxsyzSyQ = mktTMSMVcxsyzSyQ;
    }

    if (GzLvXkXGv < string("RlkSjYwakVsBQrMvTDYORRsA")) {
        for (int rsrgJfRZ = 900657568; rsrgJfRZ > 0; rsrgJfRZ--) {
            aDtMFSiP = WMSkJSrQsnrJVTJa;
            GzLvXkXGv = aDtMFSiP;
            DScZxg = DScZxg;
            DScZxg /= DScZxg;
            aDtMFSiP = aDtMFSiP;
        }
    }

    for (int iawRaHrsxaKEt = 361349677; iawRaHrsxaKEt > 0; iawRaHrsxaKEt--) {
        continue;
    }

    return WMSkJSrQsnrJVTJa;
}

double KSIJccdqBm::qdscOPkeunJfE(bool hkhBe, bool Bthjm)
{
    double gYudeodINvEiuM = 563402.5089600426;
    double aegQFeOFXBEPN = 705914.1444883888;
    string nzopUFHkMNAkdT = string("vJfmVWIeTpopvyrvKLOkWZnKxFXYCTbiDCkyMrRdLYatYDJYdJWYIXwNHpWFFIhqxRmvCQcfMhHIeZBLJYqbEpjqcrv");
    int LGHhVSSseFnq = -1928310469;
    int jltGcoRtG = 465579088;

    for (int PWZGjANgXd = 2144485355; PWZGjANgXd > 0; PWZGjANgXd--) {
        continue;
    }

    for (int sZqOlJE = 314380806; sZqOlJE > 0; sZqOlJE--) {
        gYudeodINvEiuM = gYudeodINvEiuM;
        gYudeodINvEiuM = aegQFeOFXBEPN;
    }

    for (int DLTVW = 561780065; DLTVW > 0; DLTVW--) {
        LGHhVSSseFnq /= LGHhVSSseFnq;
        jltGcoRtG /= LGHhVSSseFnq;
    }

    if (jltGcoRtG == -1928310469) {
        for (int uyuAQbkNpBe = 1979532195; uyuAQbkNpBe > 0; uyuAQbkNpBe--) {
            LGHhVSSseFnq -= jltGcoRtG;
            LGHhVSSseFnq += jltGcoRtG;
        }
    }

    for (int cWrHlXhuTVluZK = 1159559147; cWrHlXhuTVluZK > 0; cWrHlXhuTVluZK--) {
        LGHhVSSseFnq /= jltGcoRtG;
        Bthjm = Bthjm;
        hkhBe = Bthjm;
    }

    if (jltGcoRtG == -1928310469) {
        for (int hwRnoVzBgJE = 915421778; hwRnoVzBgJE > 0; hwRnoVzBgJE--) {
            hkhBe = Bthjm;
            aegQFeOFXBEPN -= aegQFeOFXBEPN;
        }
    }

    return aegQFeOFXBEPN;
}

int KSIJccdqBm::IZowWtRqQpDdD(double yqrKrJ, int PleigYIuUBr, bool LdVjSiYqWW, string BdPQqpxTVpqL, double mSxWifGWwjSm)
{
    int BdUBulvPzUovsIfE = 158562242;
    int lfUboYzTwgORIhj = 1219614879;
    double dCkniHWsOuw = 79159.796916771;

    if (lfUboYzTwgORIhj == -1285486358) {
        for (int zNtEauQJRQXP = 1083586061; zNtEauQJRQXP > 0; zNtEauQJRQXP--) {
            mSxWifGWwjSm *= mSxWifGWwjSm;
        }
    }

    for (int LnUluf = 1785526437; LnUluf > 0; LnUluf--) {
        BdUBulvPzUovsIfE -= lfUboYzTwgORIhj;
        PleigYIuUBr += lfUboYzTwgORIhj;
        BdUBulvPzUovsIfE -= BdUBulvPzUovsIfE;
    }

    for (int dnGLsslGtWwr = 565004510; dnGLsslGtWwr > 0; dnGLsslGtWwr--) {
        lfUboYzTwgORIhj *= PleigYIuUBr;
    }

    return lfUboYzTwgORIhj;
}

double KSIJccdqBm::TaVYpwOvxvmuWtb()
{
    int JSArtyqNbvXoY = -976715922;
    int MIpvyIfeu = 1822615460;
    double ejfURFbakPJlEEAy = -421333.2939203555;

    if (JSArtyqNbvXoY > -976715922) {
        for (int IbMZVbj = 435679183; IbMZVbj > 0; IbMZVbj--) {
            JSArtyqNbvXoY -= JSArtyqNbvXoY;
            JSArtyqNbvXoY /= JSArtyqNbvXoY;
            ejfURFbakPJlEEAy -= ejfURFbakPJlEEAy;
        }
    }

    for (int uqgKZtMMNrdeCU = 1522345043; uqgKZtMMNrdeCU > 0; uqgKZtMMNrdeCU--) {
        ejfURFbakPJlEEAy -= ejfURFbakPJlEEAy;
    }

    for (int zMKrADwfrGAlxV = 812288533; zMKrADwfrGAlxV > 0; zMKrADwfrGAlxV--) {
        MIpvyIfeu -= MIpvyIfeu;
        MIpvyIfeu *= MIpvyIfeu;
        MIpvyIfeu += JSArtyqNbvXoY;
        MIpvyIfeu /= JSArtyqNbvXoY;
        JSArtyqNbvXoY += JSArtyqNbvXoY;
        JSArtyqNbvXoY /= JSArtyqNbvXoY;
    }

    return ejfURFbakPJlEEAy;
}

KSIJccdqBm::KSIJccdqBm()
{
    this->LcPusPwQlitF(-1615970041, 356112.3882651586);
    this->YQNOdgwK(string("HzECQJrxoegXPGZnpCZjsvgfZHgiAOBWsiwgLWHwFSfIAdlAqhhSGRkoRuzzSXtngRvMndAbXldjwJulIawxEZQubUKXGtcoOGzmGdUcGTJPBqECvJiLvHoEdABErmJNRFCvYvYrQtzHRpRIyRKSeyAqBHh"));
    this->siQaxZR(-993628151, string("jnINnidXuNoZSYGDJLWwEYnfbNtgBOeDbHtfdBalkRZwTXbuDEMRTtogxDnZbbWNWsuvToHqooeIlkTBqvZdVNFBCWERGLajnINGYCgOrRAcbBvjyrNlCVyShKLLCgEaHEoiyOdbelVYbRizJzHsCARSLkTVWzKtlPbSeftDImqEzWjGDfmAUrjPKRhiontlSFvEXiXLboOnmMCxVwlvbRCsCXlKFhOqloxGY"), 25298.60623884937, string("RErbilCxUzMVoXsoWSWtQxFcdPWhShJdzLaofxYuCntXimyONFLNnInddZZsKLPRbUScBsCoXCnGarr"));
    this->mjsjmmQZrKYiPjyy(-323796090);
    this->qMxoQwwsefhIQe(-860420.14349644, 895249.484160056, false);
    this->LbNhDcsFpD(string("gRdXUfPkhexRpddzJVUCmVDKahLUtlDQaSIZDUqDcWHqEUWngjtWmSMrFSabRaISHgcZNHZHLZHVBYlLkoTenRwovbqfKayyoGFjLJCHEOVrQgxoqpniyovmpuIxeyXKabWIHABVOLdGUnkrWMyozYaoBXzmSVLdFGtIpgHcOHMhYKTEKiRxxeCXFucQPGvFDtsGIvhttO"));
    this->eleVUDER(true);
    this->lZfSoXFLoUh(761172666, 12799014, string("bTiBFXRjMhtoCNEKqdvjTUElJguZYXcmzrtUMJHefvrXOVUqxSXdfDDkGxRWMJtLPuswsbZGSMPMUKKJqwAkZNhMByBulsNytoXbUlpArImRsyTDfWgmOqigiTJFrjsthHfeMYafIuxzntICUlvixiXEiJNdqumEqfCAyBjZcCvIIUHjwvRFcqDUjiRRcdByLzV"), false, string("ObelsRYgGraZvaEKdlmsTFkJBSLtKwNRiwDELRnvWbaACsBHPQYLWdYsSmmBTMEbqKROxKeHmzsqqUZiHiFlbNpPjzWKdjsKPDBSRKHHXvuAtYDxHIhmnYvFdLqIguTGMUhraDyVRKiCU"));
    this->xYkggKkNZIIXL(string("jZVpjqEGmwdwHBMmWEXljxhuRECWJkFvjCAeMTgWzEgILsvnkGgGGQBNXFOyjyzSJCrjjROOOEJGDorVWbjYAotxyDGNhIufUhlZNXOosPfEdXMgZtDtdnCgJoAhKMYZHmwsZhCbumIYhjfpIzsWVaHbRrreArvUTfKrvUMJJTQSjiOxkOQlRHrbcmePmvJEKvWbgmzVCnWA"), string("QhgQQdPJznAEtPxscntwaGsFlEJyIjiwQWBgRwCfUCWDsYxRyoluYOFzFSDrmsbcMwUVC"), true);
    this->pqfRL(true);
    this->FSNVlaRbCCy();
    this->MljtD(true, -932003513, string("BGoLmuCcZTqbHnGphnhssdbyTeaLzgJCgygwuBVuEtwOfzLDfOAuTPVsSOWCViYvUzQgjAONBBSdrbzxqtlfBvzpTCayitSIUUSszGJajSCZKbSSRlubZsxJCjstnHUOwQjBlvHUtrPEQonyOfpiOWZnrVTKtFWiRkoccpTkiEZaQfnIRJwmDmtjReotxKMHzTlvQUgU"), string("RlkSjYwakVsBQrMvTDYORRsA"));
    this->qdscOPkeunJfE(false, false);
    this->IZowWtRqQpDdD(-560473.8302723661, -1285486358, false, string("uGddkvgNEUohDJeqYTgcybBCegLFYafUAUJZjVTMnEGtZhlDWiwgASAeWZdzcEtudDCpOFLmzAcVMWbLhaSRHbOZkVVOjPwhpssdneSZSURhJXPCzQASsn"), 372544.6172210144);
    this->TaVYpwOvxvmuWtb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dwBnSwubIVstLG
{
public:
    bool OHfuFobYWpgzoL;
    int bifbwVaLaa;

    dwBnSwubIVstLG();
    int BbWemBl(bool wVYsIGzTlHKUUn);
    void nlNclJLOxj(string QAtGObmRAqKY, string EivkMpiPtc, int wJMiOGJ);
    void hHgVKczdr(int gBCEcZo, string PTCMVGKKaj, double OOtSfjyODhkm, string YArSw, int oqHFBVckbpfc);
    int LjYcv(string iQtChLXNhm, double PwjVzinUOjQM);
    bool GhZpZwarNSN();
    double ejvYpEQcv(int krUFP, bool fYfjqHdNBHXQNNj, double UUUivc, double BvTlAsTxkU, int pxHtIQENrmJ);
protected:
    double jokbzbPamDFhbhB;
    int uzlwjdFGYEgAo;
    int CECIXUJfW;
    bool NaQBrHcwRyy;
    int oLUBambfD;
    string lcInD;

    int iueGVuTEgTfGcZH(double VihFjEYVZYza, int VOFlYkmm, double FLwztTXcgvu);
    string tioPNNQdvobAyQ(string EJRgm, int tjrXKYEAHtYiMx, bool GYZAPj, int tlkEGNBGkWDiq);
    int NskZvYpkMbZmJiK(bool KDyNeINqGHE, bool LftVuowniiJD, string lyFlB, double xjYyKkoMNzxG, double OMjcVRcTdnoHu);
private:
    double APmRLLn;
    double ZtcwsFs;
    bool JtZJrSRwT;
    int gSaMzaoDlxBQMV;
    int sNJrioTiLSkbgoQK;

    int mVbzFv(double Pshtoe, string VEJySDZzB);
};

int dwBnSwubIVstLG::BbWemBl(bool wVYsIGzTlHKUUn)
{
    int CgbMXAmVszgTY = -1472381035;
    double VcRbIYKnFQYMcHtv = 730661.7750169183;
    int BkLvAmjj = -1342988687;
    bool xeQGpd = true;
    string eKjoEBdc = string("bJPSXGMmSDbXUsLzVuuAouckOtbzDPSYKlCHPHGwippXxwfFFzQSVeFtntFAktDgqsQBchdcjUORZDveCmzWPbcilJAPBJUfgxezfl");
    bool DTVtEGouspf = false;
    string uSquhJricPul = string("MhwlaBkjTmJhTePhteSLRQaYdOSJTOFFlZYxHGlUKntwsNkKaLxKTGOxlIfqqwwzDnCMYgdTLuFxrgVDyedBCXgYiAzbmskRSZHrUVQdbwDzBvCZoaazJBbtjHwBDQTtzZyFRCywGbxkzguGGEUDqzsjkEFWYEZKvGvThAQhJymmFudUPGJvCfXjJFSSolTdnHDkbWBzJdanMvYJywCXIhNQHhfjn");
    string TlrOmKwc = string("JyyYrfbDSjTLJHjkxfHMbcgeYdMYUUQRepgqvxjhXzdoJyzyGsgIyYVnADHVvkFmgMTPfcSAGLnTaOkGJEeQPVVNutajDeHeQKOZzhpWzTYLxocLxJsSVrjx");
    int kClThyulTZepNDy = 579468329;
    int wXwbJo = -1867876237;

    return wXwbJo;
}

void dwBnSwubIVstLG::nlNclJLOxj(string QAtGObmRAqKY, string EivkMpiPtc, int wJMiOGJ)
{
    bool hefFIYtCp = true;
    int kuJAKs = -667717131;
    bool JKakTvUNrdv = false;
    bool fhkqtXQa = true;
    double iMrxwtmjqJETJob = 66122.07546055358;
    bool aHdNQCQl = false;
    bool BSrLEDcnIey = true;
    int oZKsC = 743332442;

    for (int ziPSv = 871532040; ziPSv > 0; ziPSv--) {
        hefFIYtCp = JKakTvUNrdv;
        hefFIYtCp = JKakTvUNrdv;
        wJMiOGJ *= wJMiOGJ;
        oZKsC += kuJAKs;
        BSrLEDcnIey = ! JKakTvUNrdv;
    }

    for (int sCcLBzBj = 927363659; sCcLBzBj > 0; sCcLBzBj--) {
        fhkqtXQa = fhkqtXQa;
        oZKsC -= oZKsC;
        fhkqtXQa = ! JKakTvUNrdv;
        iMrxwtmjqJETJob += iMrxwtmjqJETJob;
    }
}

void dwBnSwubIVstLG::hHgVKczdr(int gBCEcZo, string PTCMVGKKaj, double OOtSfjyODhkm, string YArSw, int oqHFBVckbpfc)
{
    string ICOSRJntEdCeMYGK = string("vFuovWMhObWmVBrLuQtTCagkndEoUkTlTaGERdxYpyxPEahIzmUinhtoeKeGbdQTjxKAzvgPMknDvKEiNGgfUKmMLSLDlGMUSVWHiSolpvaqESZENiQxvnBXclJvVrBAuRXKpWxtxOsxLGa");

    for (int TCvfWemhQA = 942737678; TCvfWemhQA > 0; TCvfWemhQA--) {
        gBCEcZo = oqHFBVckbpfc;
        PTCMVGKKaj += YArSw;
        oqHFBVckbpfc *= gBCEcZo;
        ICOSRJntEdCeMYGK = YArSw;
        PTCMVGKKaj += ICOSRJntEdCeMYGK;
    }

    if (YArSw == string("HCelWrzWKBFsQzFKimdKUVfPLrxUALDuHPfFNopsjRWeLEjKmaDhStuOfUaYxxinVWTnYGZwOFelI")) {
        for (int aLPGeIKoqjURa = 1079583110; aLPGeIKoqjURa > 0; aLPGeIKoqjURa--) {
            oqHFBVckbpfc = oqHFBVckbpfc;
            gBCEcZo = oqHFBVckbpfc;
        }
    }

    for (int OboCMPmWzh = 1673793601; OboCMPmWzh > 0; OboCMPmWzh--) {
        YArSw += ICOSRJntEdCeMYGK;
        PTCMVGKKaj += YArSw;
        ICOSRJntEdCeMYGK += PTCMVGKKaj;
        YArSw = PTCMVGKKaj;
        OOtSfjyODhkm /= OOtSfjyODhkm;
    }

    for (int aAvEHLMQyFl = 1482030985; aAvEHLMQyFl > 0; aAvEHLMQyFl--) {
        continue;
    }

    if (gBCEcZo < 246726667) {
        for (int QpwFIdCvjB = 1422563675; QpwFIdCvjB > 0; QpwFIdCvjB--) {
            PTCMVGKKaj += PTCMVGKKaj;
            PTCMVGKKaj = YArSw;
            PTCMVGKKaj = YArSw;
            ICOSRJntEdCeMYGK += YArSw;
        }
    }

    for (int yLPhRUIAuGFqgM = 1669095671; yLPhRUIAuGFqgM > 0; yLPhRUIAuGFqgM--) {
        OOtSfjyODhkm /= OOtSfjyODhkm;
    }
}

int dwBnSwubIVstLG::LjYcv(string iQtChLXNhm, double PwjVzinUOjQM)
{
    double GdSPG = 597766.5846984416;
    string oEuRENUm = string("FlyqMGfSyEMMhdZyOPtRdcKTEVxWSvCbeAAWJQPIfNVjdhIafRxzllukhbzEbXjCBJoZQbrrvUJ");
    bool xySEacKzoseGDjar = true;
    string LJhCRyAXJastuoKB = string("LFDrbBfeyxDvTULnscSMoRfqBfWDCynpMDEheVzlkTzghaJvvtXMgKsIpKIdQjqKaRlJjfLb");
    string ntoyeqFgUWcVB = string("kvaJwEUMYXpxIIhWWofjafRYXTALVqSfOyhwWncaNSdazCvOJxVBGDwKkDmsynLuKAfpdmpruxqvoodZbWUmPqjVeOQZZXyyIhnMNCaKcIvIZXfnWRQJPmVguYGFMzNFKmFHJZsFlJ");
    double oIFek = -282830.81551755965;
    bool nsZYOupWmUXIqT = false;
    bool QtLpPlvIHl = false;
    double jxdjxSqcmKex = -816494.6051432919;
    int GiWSReH = -1153521802;

    for (int amiGxmvMFSrSfYf = 1824917350; amiGxmvMFSrSfYf > 0; amiGxmvMFSrSfYf--) {
        GdSPG = jxdjxSqcmKex;
        oIFek += jxdjxSqcmKex;
    }

    return GiWSReH;
}

bool dwBnSwubIVstLG::GhZpZwarNSN()
{
    int mYSGeht = -795468375;

    if (mYSGeht == -795468375) {
        for (int ynoThHx = 175391909; ynoThHx > 0; ynoThHx--) {
            mYSGeht = mYSGeht;
            mYSGeht = mYSGeht;
            mYSGeht += mYSGeht;
            mYSGeht *= mYSGeht;
            mYSGeht = mYSGeht;
            mYSGeht -= mYSGeht;
            mYSGeht -= mYSGeht;
            mYSGeht = mYSGeht;
            mYSGeht *= mYSGeht;
        }
    }

    return false;
}

double dwBnSwubIVstLG::ejvYpEQcv(int krUFP, bool fYfjqHdNBHXQNNj, double UUUivc, double BvTlAsTxkU, int pxHtIQENrmJ)
{
    int gzorD = 1261680985;
    bool wCJOrREdZFO = false;
    int tWuYbhP = 1179543807;
    bool paTHuuDNlV = true;
    bool kDGjGX = true;
    int wCaRJpjgmyguEt = -1241899005;

    if (UUUivc > -431598.27628087765) {
        for (int zBXFWRPd = 23666959; zBXFWRPd > 0; zBXFWRPd--) {
            pxHtIQENrmJ *= krUFP;
            gzorD -= pxHtIQENrmJ;
        }
    }

    if (gzorD != -1241899005) {
        for (int HbWLYjbMi = 775082729; HbWLYjbMi > 0; HbWLYjbMi--) {
            gzorD *= tWuYbhP;
        }
    }

    return BvTlAsTxkU;
}

int dwBnSwubIVstLG::iueGVuTEgTfGcZH(double VihFjEYVZYza, int VOFlYkmm, double FLwztTXcgvu)
{
    double vDJUxZKAwxoU = -392526.4866007663;
    int zXSHfJeOmwCFJx = -1338258577;
    bool HEIXZAQQcqgU = false;
    string MXJPlOwYbXqe = string("PZlzTbgEWKfLkTTYeGWZVGDRvillRooNygYNyEvgGUjvZzFJzFELCAgMzeZWvgqdVPCXbzJRWcvlXvPtRl");
    bool YGbqsElptFalyUyg = false;
    int YzjwEcqgOavJZkvM = -138481222;
    double JbhcBjEGwe = -302207.44419796515;
    bool yGyLJrxuyiYKW = false;

    if (VihFjEYVZYza <= -392526.4866007663) {
        for (int GUjLkjZuGSRJ = 1779014711; GUjLkjZuGSRJ > 0; GUjLkjZuGSRJ--) {
            HEIXZAQQcqgU = HEIXZAQQcqgU;
            MXJPlOwYbXqe = MXJPlOwYbXqe;
        }
    }

    if (FLwztTXcgvu <= -302207.44419796515) {
        for (int YevtZa = 2002792539; YevtZa > 0; YevtZa--) {
            continue;
        }
    }

    if (yGyLJrxuyiYKW == false) {
        for (int gKlrbwktv = 1967883067; gKlrbwktv > 0; gKlrbwktv--) {
            VihFjEYVZYza -= vDJUxZKAwxoU;
        }
    }

    if (VihFjEYVZYza == 419987.8765485529) {
        for (int RNQSmNYSsS = 1593532409; RNQSmNYSsS > 0; RNQSmNYSsS--) {
            yGyLJrxuyiYKW = ! HEIXZAQQcqgU;
        }
    }

    if (JbhcBjEGwe > -392526.4866007663) {
        for (int NvsidkSKtkozbNlP = 2022948301; NvsidkSKtkozbNlP > 0; NvsidkSKtkozbNlP--) {
            YzjwEcqgOavJZkvM -= zXSHfJeOmwCFJx;
            vDJUxZKAwxoU /= VihFjEYVZYza;
        }
    }

    if (zXSHfJeOmwCFJx <= -1338258577) {
        for (int zsBnyoRFEVn = 1266406481; zsBnyoRFEVn > 0; zsBnyoRFEVn--) {
            YGbqsElptFalyUyg = ! YGbqsElptFalyUyg;
        }
    }

    for (int lqIqdH = 1026464844; lqIqdH > 0; lqIqdH--) {
        VihFjEYVZYza *= FLwztTXcgvu;
        JbhcBjEGwe += JbhcBjEGwe;
    }

    return YzjwEcqgOavJZkvM;
}

string dwBnSwubIVstLG::tioPNNQdvobAyQ(string EJRgm, int tjrXKYEAHtYiMx, bool GYZAPj, int tlkEGNBGkWDiq)
{
    int DZOeTKhZVbPyzt = -795313761;
    double HJQqZaRSFexUp = -718475.5454575247;
    bool CPnMpenoLgexIj = true;
    string JoAYubcRq = string("kPkNzHCMDFnTHqffxIPqsENjsaSlPjTwbrXYjAFnxspDawySkFhKjzpZZoidIzrBpNzPYlPPHcUwScGwTuCplHmJhvXPIbEevQFtXHPMDRQ");
    string aZreC = string("BWpZMbXgozOEQNJeZDZWsIjDSCYGkWKFcaoEofzMIDmBlRYiQDjFZILnUrsGJxcMIaYtHJWfQfcChZuPCxdOFggZAUOeWEymmwPNfjOfxkzrIuzYjzNAr");
    string yvPatjoTXDG = string("GDJzkWczkKBKbEsTFZezGNtOkIoodSVlNUKjDzMkPDTfjdxZghmzGjAgMtbfHINtRUMnuOlkCztIIZBnozEnpEKCiJExyGzok");
    bool ehEegmoRpNG = true;
    int eTcMBeGmgi = -481303004;
    bool QpGgstjziva = true;

    for (int fKznHQwkCXeeJsfd = 2008452507; fKznHQwkCXeeJsfd > 0; fKznHQwkCXeeJsfd--) {
        continue;
    }

    for (int HeZiXzgJgpbu = 512122580; HeZiXzgJgpbu > 0; HeZiXzgJgpbu--) {
        EJRgm = EJRgm;
        QpGgstjziva = ehEegmoRpNG;
        DZOeTKhZVbPyzt *= tlkEGNBGkWDiq;
        DZOeTKhZVbPyzt = tlkEGNBGkWDiq;
    }

    if (EJRgm == string("GDJzkWczkKBKbEsTFZezGNtOkIoodSVlNUKjDzMkPDTfjdxZghmzGjAgMtbfHINtRUMnuOlkCztIIZBnozEnpEKCiJExyGzok")) {
        for (int URQXcXYGz = 1045243183; URQXcXYGz > 0; URQXcXYGz--) {
            QpGgstjziva = ! QpGgstjziva;
        }
    }

    if (tjrXKYEAHtYiMx < -474471914) {
        for (int VNKpR = 1903576981; VNKpR > 0; VNKpR--) {
            continue;
        }
    }

    for (int IobweomoradV = 100945067; IobweomoradV > 0; IobweomoradV--) {
        QpGgstjziva = ! ehEegmoRpNG;
        CPnMpenoLgexIj = ehEegmoRpNG;
        eTcMBeGmgi -= tlkEGNBGkWDiq;
    }

    if (EJRgm != string("gtsxrJEpBCFqWCUYLOQTExzFqFkYEORlAWfoEZHJCqFLmDICtWeHwOJgROkfhfwsPstXCcbggHTPVtBdyIqvTFAEjbyjuNzDpCQQCRQXGpBWvNFpcwRiEKPAMPcjLkSfYDWUNsGfORIkeSrvPADtJrnZMzZPGBwFRLVhLnu")) {
        for (int dxNQAeSslYAGGEF = 382960341; dxNQAeSslYAGGEF > 0; dxNQAeSslYAGGEF--) {
            continue;
        }
    }

    for (int RUFQKou = 1580444345; RUFQKou > 0; RUFQKou--) {
        tjrXKYEAHtYiMx -= tjrXKYEAHtYiMx;
        QpGgstjziva = QpGgstjziva;
        GYZAPj = ehEegmoRpNG;
    }

    return yvPatjoTXDG;
}

int dwBnSwubIVstLG::NskZvYpkMbZmJiK(bool KDyNeINqGHE, bool LftVuowniiJD, string lyFlB, double xjYyKkoMNzxG, double OMjcVRcTdnoHu)
{
    double gNYYbHaxwnrJT = 559360.2505042624;

    if (xjYyKkoMNzxG == 559360.2505042624) {
        for (int JZaXMyy = 1724752167; JZaXMyy > 0; JZaXMyy--) {
            LftVuowniiJD = ! KDyNeINqGHE;
        }
    }

    for (int ApxQEFHfQ = 1390235447; ApxQEFHfQ > 0; ApxQEFHfQ--) {
        gNYYbHaxwnrJT *= xjYyKkoMNzxG;
        KDyNeINqGHE = LftVuowniiJD;
        OMjcVRcTdnoHu -= OMjcVRcTdnoHu;
        KDyNeINqGHE = KDyNeINqGHE;
    }

    if (KDyNeINqGHE == true) {
        for (int wJwmIaosWkAXgb = 1904627920; wJwmIaosWkAXgb > 0; wJwmIaosWkAXgb--) {
            gNYYbHaxwnrJT += OMjcVRcTdnoHu;
        }
    }

    if (gNYYbHaxwnrJT > -670444.5971117088) {
        for (int DEBzFaRxiLIXAQE = 327388345; DEBzFaRxiLIXAQE > 0; DEBzFaRxiLIXAQE--) {
            gNYYbHaxwnrJT -= xjYyKkoMNzxG;
        }
    }

    return 1927080746;
}

int dwBnSwubIVstLG::mVbzFv(double Pshtoe, string VEJySDZzB)
{
    bool ZsOUqmKmDcqSXdbQ = true;

    for (int ScMggtDqVxxMm = 1548870127; ScMggtDqVxxMm > 0; ScMggtDqVxxMm--) {
        Pshtoe -= Pshtoe;
        VEJySDZzB = VEJySDZzB;
    }

    return 1579382644;
}

dwBnSwubIVstLG::dwBnSwubIVstLG()
{
    this->BbWemBl(true);
    this->nlNclJLOxj(string("sBDxBRniaCySvpTDqOsyYzKqegSfXxzVIjHJPjrRkWoBpkiOpMigLRplMGMhaXGANLWSbzCiMjMjWBotQNFpurVsTvVpTpvzqlFXJRNtlijysZnsxCYkaplrdaZvoHOoMcwXzMiiFulO"), string("ORSmBqzVUEbKsBtkZIbNuAnrEJVGSZWMXcTtgnINMWRYXGIUjheWqrAGJRWJbMlZSrQJVtXJAPRGWhZnyMkDZsyGbIxWZrdkxJLTIUTWbwjVpxyxhJKUUiEdMnKrwLbsRpSBWRqxCrVMoGzAMhQqUZySPZVPWFDRuWy"), 1913012582);
    this->hHgVKczdr(246726667, string("RuLq"), 763688.5533270888, string("HCelWrzWKBFsQzFKimdKUVfPLrxUALDuHPfFNopsjRWeLEjKmaDhStuOfUaYxxinVWTnYGZwOFelI"), -849716469);
    this->LjYcv(string("txhwquhHquhnvGrapunJftMFgKwgWjCeGTkQjPBnRXyCRztyizpfcGcjEfJYtEVdFsDHdyWDPxVpiRfpchdVihdLSUwVfODGXgNvOwddtxKBuPkrAJmKNmCeDFmHZuFcXwpHWGDZqLzurcyDoYjEZdZiHCrpzPZGcrZgQNiKFvCBTDfqnhkCZVSUKROdhhFYQtxHCsDCAYPdaBciPkY"), 720540.303831878);
    this->GhZpZwarNSN();
    this->ejvYpEQcv(-2062741856, true, -431598.27628087765, 351194.9041252991, 858810815);
    this->iueGVuTEgTfGcZH(419987.8765485529, -625102633, -1030087.3446341729);
    this->tioPNNQdvobAyQ(string("gtsxrJEpBCFqWCUYLOQTExzFqFkYEORlAWfoEZHJCqFLmDICtWeHwOJgROkfhfwsPstXCcbggHTPVtBdyIqvTFAEjbyjuNzDpCQQCRQXGpBWvNFpcwRiEKPAMPcjLkSfYDWUNsGfORIkeSrvPADtJrnZMzZPGBwFRLVhLnu"), -474471914, false, -1239748177);
    this->NskZvYpkMbZmJiK(true, false, string("uCLbeHWQBbftSfyJERgeHjUhPqHNwdxscAxiJOTqjQKUnLQLBqkhIhsAhEQuzeLLrWyfDl"), 164599.05677856787, -670444.5971117088);
    this->mVbzFv(-480874.3327155984, string("MtLyZGEbFOWsXtgQQpu"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QQlgGRy
{
public:
    string rgAcLxxchaqVya;
    double iWVeQCMHeTlp;
    string RBUUQkGhcftXRny;
    double gntUTAuwJKVA;
    bool UFnlOJUEyx;

    QQlgGRy();
    double EwwmfUIOYMWBo(int qDGSsOVLO, bool mqIAaqVWqU, bool eitNN, int MHpBlTsGaDABVUia, bool HtGhtntsIMLkjd);
    string GHjfWigSrjDXNmG(string ajUQIVv, double IUusVVcOdMvU, int yfyXGapXRLq, bool qFende);
    double JKAOeySetqtxWYd(int ZXElYvtIDOB, double wXXHtJxYFbBw);
protected:
    string OJyXKqcVjJ;
    int ZVarWI;
    bool LfXHzjwrZFujrKfj;
    string hUivAutXdsTsTv;
    int vqkhFqlCvarxLa;
    int WiCqNs;

    double vecKeVXTdasmZHl(string BkIheAAS);
    int hgrSQIRJYdF();
    double DkmESPGzfnRvjvOA(string xRSyLazWmk);
    int FDpmtTdV();
    string eDmgu(int DzftyTEjjPjQjG);
private:
    string BBDnG;
    int FYjAC;
    int AWgmhq;
    double gswokHQ;
    int QEkXfgMlPDpzOe;

    int rgPLdIko(double gwTmJ, double cpjVv, double gnLGe);
    bool QRZdYjVEM(string rTIKqlwAaq, double zwfCaLHotsN, string AjyflSMfdk);
    bool ywzLR(int szeSwSP, int dajGuhKbhxnsvKHG, string xxBktGRn, int LWcXGXJAMgDdmuo);
    int FUQoDZrWukSBTO();
    void rVwRKrLEnwM(bool ARkDZBwooHLlbnwq);
};

double QQlgGRy::EwwmfUIOYMWBo(int qDGSsOVLO, bool mqIAaqVWqU, bool eitNN, int MHpBlTsGaDABVUia, bool HtGhtntsIMLkjd)
{
    string TPQknDFv = string("icbqwpxZfVuOUZLcaGMxeOymemubmWfaHwEEmxtunERGfgOJBTXLdIcbszrRofnGpyCwLdwNVaiPqqeijlqUadMfhWWnJCOqZhPWGhwNpiaTpfBYYtOfSRnuZZaJiAcOcvqGscvLmumpvFsxHaiWOfcgPqaSnHznRCBOqzlzyolnq");
    string SbOmfuzAVZaJUx = string("KUccWtjmseHPtdKJcEdmoiPcAJgVucQAzCxjChjnUDSRWDSgNkrCgDmmtRimfJRQmABpiJUPrZfbLnvcNzNVQJnHGfkTtxbxFMsDntXwKrbULSZXpMzUawwoIiFdKDAhIcoEhMWAmQBwEtCaHlZpepeBvUcmeofCNCWUfaLfqDzJkMThnJzpAjSKVlkthbkElaxtptWdzgZqyVqBuQuynOW");
    double lOvECUnEPGSSnpR = -348772.36884010566;
    double GPWWsIyDS = 891983.0901189622;
    string BNoBWwkqnum = string("DigHoOuaTULweXWUraAgLVOBSMWhIqnCBJMRyEdOkJzxSnVDOaxhckHhKtUvJzWDGwYCJOFcJCLosfEhUYvLXDVhcieaGDKkJUnuONhsdLteorxIZwpJYpMqCynEpmMejwWGRyrdLccsVhJCBXwSVwmnZbrRoIJQUvuehoBvFEsWjSTzkmEwjjYsKPzEgWqH");
    double KulBzLKQo = -46529.779925464136;
    double nmgGpHW = -920757.3665197397;

    for (int qFQlXAdxc = 2058096200; qFQlXAdxc > 0; qFQlXAdxc--) {
        eitNN = HtGhtntsIMLkjd;
    }

    for (int SfsXVYdgLJOAOfcI = 247148426; SfsXVYdgLJOAOfcI > 0; SfsXVYdgLJOAOfcI--) {
        KulBzLKQo *= nmgGpHW;
        MHpBlTsGaDABVUia = MHpBlTsGaDABVUia;
        nmgGpHW = nmgGpHW;
        mqIAaqVWqU = ! eitNN;
        SbOmfuzAVZaJUx = SbOmfuzAVZaJUx;
    }

    for (int DpnehEx = 651883540; DpnehEx > 0; DpnehEx--) {
        qDGSsOVLO /= MHpBlTsGaDABVUia;
        BNoBWwkqnum += TPQknDFv;
        TPQknDFv = TPQknDFv;
        SbOmfuzAVZaJUx += BNoBWwkqnum;
    }

    for (int HOMBBqR = 776513388; HOMBBqR > 0; HOMBBqR--) {
        continue;
    }

    return nmgGpHW;
}

string QQlgGRy::GHjfWigSrjDXNmG(string ajUQIVv, double IUusVVcOdMvU, int yfyXGapXRLq, bool qFende)
{
    string ifHkwBPfABAPXYWB = string("hvKkSUyvqrvoaGrpylWkGtZmNtXyHFAjUwETgDHZWjnlGsJowMGrsjKxbAZvHtOPzewdjEkUsIniuTW");
    double AwSNvpI = -181096.58115019934;
    string XoFeVqhNTlLj = string("KppEciFVcGBxiwQbytEJYbbKLkmdAOiLRpDrQiVvFyKkbALcUgoFwJup");
    string vOkszTu = string("XKSNCSLqKMQnrFipGyZkTUlMJeFPxwHlNFrMUXvcoumOnYCMcxgKioIXGBfZSZvvMNLeHeCcsYaNKHwMGJPZKXbLxAkYamnhupV");

    if (vOkszTu > string("rTejGKuHJCDnwPNDDjKdYBBqlklRgAjRuEltvtejwHyXERLOSENhJnJDtCWnXVutbTbaulqOuDUpYpkCssRKeXiCOVdHXIcKfzpnemhXaxtwpwsGmkMkRQCYeVVjlqQjocNISDNeYsBNMfqRPGDEgybDeDMDEGGUEODOTKLjmNsvDQACWyIRBYpMurqUSfzrBNhWUKndxlxUjXMgHswPt")) {
        for (int zYOESUfOLHK = 1983074647; zYOESUfOLHK > 0; zYOESUfOLHK--) {
            XoFeVqhNTlLj = ajUQIVv;
            IUusVVcOdMvU -= IUusVVcOdMvU;
            ifHkwBPfABAPXYWB += ifHkwBPfABAPXYWB;
        }
    }

    if (vOkszTu >= string("XKSNCSLqKMQnrFipGyZkTUlMJeFPxwHlNFrMUXvcoumOnYCMcxgKioIXGBfZSZvvMNLeHeCcsYaNKHwMGJPZKXbLxAkYamnhupV")) {
        for (int EJwQyXbQncdYR = 784102256; EJwQyXbQncdYR > 0; EJwQyXbQncdYR--) {
            vOkszTu += ajUQIVv;
            ajUQIVv += ajUQIVv;
        }
    }

    return vOkszTu;
}

double QQlgGRy::JKAOeySetqtxWYd(int ZXElYvtIDOB, double wXXHtJxYFbBw)
{
    int auujJLKSZAAL = -725914126;
    int BdMvGIKpcAZV = -329852874;
    string pmMBrnLGT = string("CJBFjNNJonoJjicOzkQptRIgnoACVtknmWxmTbevMDhtXgwyZepMvTLCyPhufnZvIpFcYxGyWOjEgeYlxcwaQLpfDKbMuVTfKWyxWeTqmqSMWvwFKikbfRnwBPbPlludVtspubDQhlJmxkKSQZwAuYBSGfnvRkxESNkykgLKkWDHfVzohbHTsxLAqNiXqMRuCGSXFfBhswkvQXVDiBcOAibphxZlOHSPtKSliBnzYJJvHfR");
    int uExpGDtC = 483814081;
    string QKGeDURuVqcpve = string("asWMgnwuqDWRmvnrMVoTROyvnCWczrPOyGQjLuJsTFFRtziYxIZpQxfSFboMMqVFsQWWqupuvzFkToOpAMkfpyhkckeeGAYqChEOFSfibOHgVEqRh");
    int BWVzwUIBIPFN = -8066966;
    double CmYGvGSCyHPK = -916242.623906045;
    double HRlmOZgnKpk = -655168.1122280584;
    int yApMvzhlFVyVU = -483870301;

    if (uExpGDtC >= -329852874) {
        for (int mwVjVOKePanMnQW = 607702639; mwVjVOKePanMnQW > 0; mwVjVOKePanMnQW--) {
            auujJLKSZAAL = BdMvGIKpcAZV;
        }
    }

    return HRlmOZgnKpk;
}

double QQlgGRy::vecKeVXTdasmZHl(string BkIheAAS)
{
    bool EEnqM = true;

    for (int kovXzjPll = 842538651; kovXzjPll > 0; kovXzjPll--) {
        EEnqM = ! EEnqM;
    }

    if (EEnqM != true) {
        for (int zAdnnl = 1881477893; zAdnnl > 0; zAdnnl--) {
            EEnqM = EEnqM;
        }
    }

    for (int cKdkwNswOxyE = 1886247049; cKdkwNswOxyE > 0; cKdkwNswOxyE--) {
        continue;
    }

    for (int DXnFFyXMKdn = 1670816809; DXnFFyXMKdn > 0; DXnFFyXMKdn--) {
        BkIheAAS = BkIheAAS;
        EEnqM = EEnqM;
        EEnqM = ! EEnqM;
    }

    if (EEnqM != true) {
        for (int tiLEYkwZ = 707754622; tiLEYkwZ > 0; tiLEYkwZ--) {
            EEnqM = EEnqM;
            EEnqM = ! EEnqM;
            EEnqM = EEnqM;
            BkIheAAS += BkIheAAS;
            EEnqM = ! EEnqM;
        }
    }

    return -179699.84505699316;
}

int QQlgGRy::hgrSQIRJYdF()
{
    bool DcPTybBhrHYGge = true;
    bool inpfO = false;
    bool UgYrHqeDDm = true;
    int IBSvQbiMhIlt = 878663628;
    string isJSQ = string("krujmcZPHLUQtmwxSYPObkztgQJnaoLYgFGYAgujRluEoEwJLdaLckclEnSdKnLedoEuqPnIleCaWVKuJzXACheftQJwygriSuNKyfmwNUjOqHbhrlYCCaHwnFvzkpQOmTZuZMUPfPCJumfwLyIolQRtLUDZcbRGtxBPIbGmyMFMpIioNVaisPhUVKRSTShGROZWJgTabltHDUlTSOJDwNbNLVYIAmSgYGKYGBLMkTv");
    double WECGpLvIfnobG = 897860.6858700291;
    double MnpLDdMf = 155393.2884392038;
    int OnmaE = 770216666;
    double ybNEoBzIoPoro = 823957.504899917;
    double SpsDFlsRSSPpyHKY = -762030.5887291016;

    for (int DzUFaALLoyjYKDL = 1035813450; DzUFaALLoyjYKDL > 0; DzUFaALLoyjYKDL--) {
        OnmaE /= IBSvQbiMhIlt;
        UgYrHqeDDm = ! inpfO;
        inpfO = ! UgYrHqeDDm;
    }

    for (int NMRAzPdawfyJZIO = 1956320528; NMRAzPdawfyJZIO > 0; NMRAzPdawfyJZIO--) {
        SpsDFlsRSSPpyHKY = SpsDFlsRSSPpyHKY;
        ybNEoBzIoPoro = ybNEoBzIoPoro;
        IBSvQbiMhIlt -= IBSvQbiMhIlt;
    }

    return OnmaE;
}

double QQlgGRy::DkmESPGzfnRvjvOA(string xRSyLazWmk)
{
    string wouwPXbYOt = string("WnuSclchDiUKkVpUXJxCOLoPtpSwlaCnhdPdiWKrFwaqxiYXczltmslVhGCJKPOpNqMoSaefppTQfoUISgvZHgqIbRHhzpiOkcTXvaidpFZCHHopZzEXSZCIVaNBcuknaLVHFpcQinOIlHqoJsrQgqWcHJPcgGDTzKhzTIHJCMhnWoWdSG");
    int NtFCVNOUwAli = -1721813175;

    for (int MFkTpBXr = 1437301755; MFkTpBXr > 0; MFkTpBXr--) {
        wouwPXbYOt = wouwPXbYOt;
        wouwPXbYOt += wouwPXbYOt;
        xRSyLazWmk += xRSyLazWmk;
    }

    for (int eCaoXkWgMMVRUioJ = 1461585045; eCaoXkWgMMVRUioJ > 0; eCaoXkWgMMVRUioJ--) {
        continue;
    }

    return -367943.22710891796;
}

int QQlgGRy::FDpmtTdV()
{
    double HfBIFPhDpbnpD = 839998.7398043546;
    double hjBxLqempu = -82994.30562100821;

    if (hjBxLqempu <= 839998.7398043546) {
        for (int JBBINKxihGbNWyzH = 666060133; JBBINKxihGbNWyzH > 0; JBBINKxihGbNWyzH--) {
            hjBxLqempu += hjBxLqempu;
            HfBIFPhDpbnpD *= hjBxLqempu;
            HfBIFPhDpbnpD = HfBIFPhDpbnpD;
            HfBIFPhDpbnpD = hjBxLqempu;
            hjBxLqempu -= hjBxLqempu;
            HfBIFPhDpbnpD += HfBIFPhDpbnpD;
            HfBIFPhDpbnpD -= HfBIFPhDpbnpD;
            HfBIFPhDpbnpD /= HfBIFPhDpbnpD;
            HfBIFPhDpbnpD *= HfBIFPhDpbnpD;
            hjBxLqempu /= hjBxLqempu;
        }
    }

    if (hjBxLqempu > 839998.7398043546) {
        for (int XQKen = 1843693790; XQKen > 0; XQKen--) {
            HfBIFPhDpbnpD /= HfBIFPhDpbnpD;
        }
    }

    if (hjBxLqempu != 839998.7398043546) {
        for (int PuTJlEo = 586002425; PuTJlEo > 0; PuTJlEo--) {
            hjBxLqempu *= HfBIFPhDpbnpD;
            HfBIFPhDpbnpD = hjBxLqempu;
            HfBIFPhDpbnpD = HfBIFPhDpbnpD;
        }
    }

    if (HfBIFPhDpbnpD != -82994.30562100821) {
        for (int VSTkG = 933683276; VSTkG > 0; VSTkG--) {
            HfBIFPhDpbnpD *= HfBIFPhDpbnpD;
        }
    }

    if (hjBxLqempu != -82994.30562100821) {
        for (int DYJvJRX = 1699447925; DYJvJRX > 0; DYJvJRX--) {
            HfBIFPhDpbnpD += hjBxLqempu;
            hjBxLqempu = HfBIFPhDpbnpD;
            hjBxLqempu *= hjBxLqempu;
            HfBIFPhDpbnpD += HfBIFPhDpbnpD;
        }
    }

    if (HfBIFPhDpbnpD != 839998.7398043546) {
        for (int mQJuNbUZ = 709115518; mQJuNbUZ > 0; mQJuNbUZ--) {
            hjBxLqempu += hjBxLqempu;
        }
    }

    return 106612900;
}

string QQlgGRy::eDmgu(int DzftyTEjjPjQjG)
{
    string aCTZVUQPuHNO = string("OllebCkoVVUyUyTdGTezduonjTfyepktoGsSYgnfblGpONKXRTDbIFkxgLRIWVvDOPdWhYPxoZ");
    int CShJFvs = -607544453;
    bool gGHYGYp = false;
    string hNKxdOsdwE = string("TOMSmULKdUcWsZjlYOqFUYztmYThRVsgjQsoCQOYOufbihMLyiELxlBVXZPNuvJxFmVgQNBQFATxAjkimTX");
    int TTFBBYnTLd = -1991423139;
    string DuwFkEPL = string("nUgQFYGZsncqBHxpxbwWLeRQacAdzbiUFUEyQGqpNRlqq");
    bool CvixmGBbMazlP = false;
    string kVkhufM = string("FAuMmlHqUXuxnVkihstyJdcHduCrEAVvjzbfOSpbJXyHQJIEALHzIAHzzefoUnOQGMiELxGTqxdZEoAQtIzCamOiqsElqoMuhVUP");
    int ViwtAMEeYI = 252260184;

    for (int LJeuCzUqLGun = 822794638; LJeuCzUqLGun > 0; LJeuCzUqLGun--) {
        hNKxdOsdwE += DuwFkEPL;
        TTFBBYnTLd += DzftyTEjjPjQjG;
    }

    for (int bDmyUnKqVvyaPFz = 1018175896; bDmyUnKqVvyaPFz > 0; bDmyUnKqVvyaPFz--) {
        continue;
    }

    for (int roEvXVvA = 91638090; roEvXVvA > 0; roEvXVvA--) {
        ViwtAMEeYI = DzftyTEjjPjQjG;
        TTFBBYnTLd -= ViwtAMEeYI;
        aCTZVUQPuHNO += hNKxdOsdwE;
        ViwtAMEeYI = DzftyTEjjPjQjG;
    }

    if (TTFBBYnTLd > -607544453) {
        for (int MqCjxuVTXhZz = 1124827942; MqCjxuVTXhZz > 0; MqCjxuVTXhZz--) {
            CvixmGBbMazlP = ! CvixmGBbMazlP;
        }
    }

    for (int UEZMzFLxkCcNO = 109246635; UEZMzFLxkCcNO > 0; UEZMzFLxkCcNO--) {
        continue;
    }

    for (int oihDXuf = 1219553091; oihDXuf > 0; oihDXuf--) {
        TTFBBYnTLd += CShJFvs;
        TTFBBYnTLd -= CShJFvs;
    }

    return kVkhufM;
}

int QQlgGRy::rgPLdIko(double gwTmJ, double cpjVv, double gnLGe)
{
    int AYUBXUg = 632325580;
    double iHQFNOb = 509093.9025505633;
    bool YCrBXq = true;
    double WNTxl = -19309.622899022223;
    string hdHjlRwViftDuI = string("uDQiiOGEuHLwHzFutJhRShpMhhqhIxAVMiledkDqGroFgPChfLhVTqcAQqjaqpjaAWLjgqliBNaIGqNxTGyWHQpktuXmGWBrvoJbXZTFDRoXcwkuQmHPnDRyfHIjLNTPooeONgIwasksDpWORpHwCEdo");
    double BPotrtxLdFpuVhhP = -137860.47445203102;
    int ZSGqDPmGheTUNrfH = 924762431;
    string bFcEbbbhe = string("ToRnANmkbQVKSArpyyCKiXqQHFpdbZLKaIvjRFJPeqUxIONhyfdRPBzIDZzpQbvOygZaxBFEimJCFersyTIBXZwdxAUUMeQBYgLPUZahlukLQCFGJNvwQshxsgRIWrTtGiFwMUxaGHFOTvjyOPKhTujoOnVHSYkktZRlVkQI");
    string TsSjE = string("aNfknqsmgaINNlEMVyPutmImkbklbXZkLAVkhxNRjtYgaNNepPpHCzBvJFanFFWbZyhYOgVIMdycqKbQxYvePHhoKsYkYZfgjDgAIqJdkEzGnrKFWnsAQSwIXxuPEbuXDHjKhTltqIxyXXSTcMFdqxTjfwBJZauXDRXZRbmRSfTCLxQyytklWuEenRVBqwLgAPCoCmQzkjbvgGaGZV");
    int EaumelQYHFEeI = -891290298;

    for (int ZVNBphtRB = 1977019430; ZVNBphtRB > 0; ZVNBphtRB--) {
        iHQFNOb = iHQFNOb;
        ZSGqDPmGheTUNrfH *= EaumelQYHFEeI;
        ZSGqDPmGheTUNrfH += EaumelQYHFEeI;
    }

    for (int ceHDiNNKXzrVc = 2070335265; ceHDiNNKXzrVc > 0; ceHDiNNKXzrVc--) {
        continue;
    }

    return EaumelQYHFEeI;
}

bool QQlgGRy::QRZdYjVEM(string rTIKqlwAaq, double zwfCaLHotsN, string AjyflSMfdk)
{
    int ThhgYTwEhHvMGhzC = 105781863;
    bool lCskD = false;
    int PfTnvxtTBOLeVoD = 2066846981;

    for (int ZJKBpo = 1141499702; ZJKBpo > 0; ZJKBpo--) {
        AjyflSMfdk += rTIKqlwAaq;
        PfTnvxtTBOLeVoD *= ThhgYTwEhHvMGhzC;
    }

    for (int mnCgqpUKGFqmpeN = 439354405; mnCgqpUKGFqmpeN > 0; mnCgqpUKGFqmpeN--) {
        AjyflSMfdk += AjyflSMfdk;
    }

    for (int GdJJRHVn = 157442619; GdJJRHVn > 0; GdJJRHVn--) {
        continue;
    }

    if (AjyflSMfdk <= string("ZUTicYCHEIPxlepnFjoQNHzJZnHvJpSpaOSdTwxLHrVtenTsWlqCqpmicRRZTThRbcQRxxWyqWLviPlX")) {
        for (int Kblng = 591017706; Kblng > 0; Kblng--) {
            AjyflSMfdk += AjyflSMfdk;
        }
    }

    for (int HgpcUjYfucTOR = 720888406; HgpcUjYfucTOR > 0; HgpcUjYfucTOR--) {
        PfTnvxtTBOLeVoD -= PfTnvxtTBOLeVoD;
        AjyflSMfdk += rTIKqlwAaq;
        PfTnvxtTBOLeVoD = PfTnvxtTBOLeVoD;
        ThhgYTwEhHvMGhzC *= ThhgYTwEhHvMGhzC;
    }

    for (int pxCrSDbh = 1326561516; pxCrSDbh > 0; pxCrSDbh--) {
        PfTnvxtTBOLeVoD = ThhgYTwEhHvMGhzC;
    }

    return lCskD;
}

bool QQlgGRy::ywzLR(int szeSwSP, int dajGuhKbhxnsvKHG, string xxBktGRn, int LWcXGXJAMgDdmuo)
{
    int UOuYkwpyAIiSXbGy = 2137655439;
    int mXgZueF = 1461525076;
    bool OUlNDHyxLFLjNgS = false;
    bool SrdVikyguAwQYwc = true;
    string IHtiBFOSabg = string("vxyTiDiZjtbWfNrFtJMNhAsNDrHMsvVKTKJ");
    bool OrjVAaRY = true;

    for (int XcsvZmtODNnCs = 1059794712; XcsvZmtODNnCs > 0; XcsvZmtODNnCs--) {
        UOuYkwpyAIiSXbGy = dajGuhKbhxnsvKHG;
    }

    if (LWcXGXJAMgDdmuo >= -989768325) {
        for (int xNJeulamwalxRpl = 108322328; xNJeulamwalxRpl > 0; xNJeulamwalxRpl--) {
            LWcXGXJAMgDdmuo = dajGuhKbhxnsvKHG;
        }
    }

    if (UOuYkwpyAIiSXbGy < 292279511) {
        for (int hfpmKqi = 1038846265; hfpmKqi > 0; hfpmKqi--) {
            SrdVikyguAwQYwc = ! OUlNDHyxLFLjNgS;
            IHtiBFOSabg += IHtiBFOSabg;
        }
    }

    return OrjVAaRY;
}

int QQlgGRy::FUQoDZrWukSBTO()
{
    double dLxbLvbQxkkdNSG = -605158.9009261879;
    bool apEscPcNXOG = true;
    bool ABMrdm = true;
    double hfRLb = 449019.5021874046;
    double SmFajdb = -109048.76279575226;
    string HuCOvdjKITVwGbgI = string("YYpNzNvLQLOmhcNwqjYxZYsERpVjczLmGvwGiIJtBzYDG");

    for (int AkxMpoweYRO = 306736397; AkxMpoweYRO > 0; AkxMpoweYRO--) {
        hfRLb -= dLxbLvbQxkkdNSG;
        apEscPcNXOG = ! apEscPcNXOG;
    }

    for (int WtQLoWZyzvQvVGOx = 2014362753; WtQLoWZyzvQvVGOx > 0; WtQLoWZyzvQvVGOx--) {
        hfRLb = hfRLb;
        dLxbLvbQxkkdNSG = SmFajdb;
        SmFajdb /= hfRLb;
        dLxbLvbQxkkdNSG /= hfRLb;
        HuCOvdjKITVwGbgI += HuCOvdjKITVwGbgI;
    }

    for (int TDcNRvXhFTmDPKV = 50682076; TDcNRvXhFTmDPKV > 0; TDcNRvXhFTmDPKV--) {
        continue;
    }

    if (apEscPcNXOG == true) {
        for (int lzDIlHT = 473150637; lzDIlHT > 0; lzDIlHT--) {
            SmFajdb *= hfRLb;
            dLxbLvbQxkkdNSG -= hfRLb;
        }
    }

    for (int SJOVRFBoM = 1114586291; SJOVRFBoM > 0; SJOVRFBoM--) {
        continue;
    }

    return 73177557;
}

void QQlgGRy::rVwRKrLEnwM(bool ARkDZBwooHLlbnwq)
{
    string jUFIozetsDcQXCVO = string("lsgdYIWuGksBIRVLfqUoIYvIHrzSUbaQzpBYECllktRKGJft");
    double LhGhEBnu = -233781.89759852632;
    int aGPJGMpzXMQYe = -298253707;
    bool kJDFpWdn = false;
    int WajoRq = -1157039251;
    double LIwvPApjmTmf = -93966.0044206763;
    string omUjzu = string("XLomyVKQNnWhQlsQaMlGfIQtVoMoblFpIqOAJuwANLALggTPgYDJUPbukmdQqcwNvjSJHpAaYVJLgJXNfrEVpYIECyckbBlapwYfFBSICfHliENJnimdArV");
    bool yczAadAqN = true;

    for (int AIylbUQFtKNHVd = 672612254; AIylbUQFtKNHVd > 0; AIylbUQFtKNHVd--) {
        continue;
    }

    if (LhGhEBnu >= -93966.0044206763) {
        for (int aOyov = 1523527309; aOyov > 0; aOyov--) {
            ARkDZBwooHLlbnwq = ARkDZBwooHLlbnwq;
        }
    }

    if (LIwvPApjmTmf > -233781.89759852632) {
        for (int GzHpJmSxbVpreON = 1267419111; GzHpJmSxbVpreON > 0; GzHpJmSxbVpreON--) {
            yczAadAqN = ! yczAadAqN;
        }
    }

    if (jUFIozetsDcQXCVO > string("XLomyVKQNnWhQlsQaMlGfIQtVoMoblFpIqOAJuwANLALggTPgYDJUPbukmdQqcwNvjSJHpAaYVJLgJXNfrEVpYIECyckbBlapwYfFBSICfHliENJnimdArV")) {
        for (int kHntttooHOCk = 41226386; kHntttooHOCk > 0; kHntttooHOCk--) {
            ARkDZBwooHLlbnwq = ! ARkDZBwooHLlbnwq;
        }
    }

    for (int xXKTth = 1119860580; xXKTth > 0; xXKTth--) {
        continue;
    }
}

QQlgGRy::QQlgGRy()
{
    this->EwwmfUIOYMWBo(-2071991105, false, false, -2103490659, true);
    this->GHjfWigSrjDXNmG(string("rTejGKuHJCDnwPNDDjKdYBBqlklRgAjRuEltvtejwHyXERLOSENhJnJDtCWnXVutbTbaulqOuDUpYpkCssRKeXiCOVdHXIcKfzpnemhXaxtwpwsGmkMkRQCYeVVjlqQjocNISDNeYsBNMfqRPGDEgybDeDMDEGGUEODOTKLjmNsvDQACWyIRBYpMurqUSfzrBNhWUKndxlxUjXMgHswPt"), -122998.93535486278, 1419152501, true);
    this->JKAOeySetqtxWYd(610590457, -233549.4934267094);
    this->vecKeVXTdasmZHl(string("OQeyDkzuMRLCznsmNYQaEYFbOfXBgoYkuhJTgpSvlVlAGzGYOOzK"));
    this->hgrSQIRJYdF();
    this->DkmESPGzfnRvjvOA(string("ffRXKPbBAfyEqqmbeUCwjIyEpDHCbLvelrEnwdIJbSUowdUXoDHTSFjidjUBtquCukNuIjVKCuxOGnmAqujRkfkONhaAUesQBnXjUeSMYaIzuKLpAfIfOmMPeDemLAgGuVHFjZhrXJLKRNBHLe"));
    this->FDpmtTdV();
    this->eDmgu(758242092);
    this->rgPLdIko(-677006.2045899049, -989749.8409957909, 772143.1069266921);
    this->QRZdYjVEM(string("fhANDcPMUavSeNjKqeTuXNDmgqoRwtyVvsuWHaEJlqNbLgzvbTEvTFI"), 845745.6240680129, string("ZUTicYCHEIPxlepnFjoQNHzJZnHvJpSpaOSdTwxLHrVtenTsWlqCqpmicRRZTThRbcQRxxWyqWLviPlX"));
    this->ywzLR(292279511, 967728628, string("gzYJxbeTmsLprpDtNakpIYTelUMsibLRpmBGLcOKiVmmzOHtVCPnIfTMVyUwkxZcCJoHridLEmmOcAwCBHaXHthKRvhesszvDGxwQXqafuvkqhZzokktvuGZEKsRwOBVfMxhIMBxC"), -989768325);
    this->FUQoDZrWukSBTO();
    this->rVwRKrLEnwM(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aTUHc
{
public:
    int HdtUWacu;
    int UejXrz;
    double gADxGofus;

    aTUHc();
    double DVfOdgLstPhVLLSA(double tpKRXM, int NllYLxuWtKsUxChz, bool TzqQyhAwABBlp, string bWQhlihdDBYI);
    string cbAoitij(double MTeZqhmVNFcJDPAx, double MpYUur);
    double KZGGuuEyhlIuUKPv();
    string cGxiuXgGrsHXQxMz();
    void efOymEFiigdELH(int dIPwyOcbFLGxi, int eHUGidHITdA, string LCXFl);
    int LctbemyitmHAXin(bool twUxcobp);
    int HreBdgcYMDbcvzj();
protected:
    double CnUpjoSSSbE;
    int mEhDlCeoDqRJ;
    string NpnjZ;
    double KaIoTEdH;
    string olOfsE;
    double favGuX;

    double RMKgYqzg(double vjrQvJGlXg, bool jmkPRezjdEMGMg, string FWCxkAdxDsapbSA, double zviUCdB);
    bool QQpLZWgtz(int NmKbnvfDliFqK, double tZxdqXjnaX, double MsXQzDS, double QqbEQilZgBrQwg);
    int gNRJDQELusCVcV(int EhHOSLWU);
    void SacHwCEhRy(int YXiVWIQtF, bool MzskhXdrL, int GGZeIVqDAutaaot, double fXgtxH, int crxBzroGVQX);
    bool OVvbhLPnX(int vyuTRRdwqaSbgY, bool iMclVbWRvtFgwy, double LgwfggHCxyrmJvWh, string JtVmw, double WaJQjrfFkJ);
    void UNoyvPS(string aEXFQmtcAQ, bool EbgcHQAjlGXbi, int GkYhKwwfILgC);
    string sZHCXZX(string WZqVJcLwGI, double EaAPqZiqQ);
    double fqxphOoTN(double jgBwBGsF);
private:
    double LcqHRYQNJTUPCQBM;
    string uvJFhsH;

    string qJglvdi(int tJScY, string uSOCaX, bool rVQzSy, int PPRSPtCIDIXWGa, double ERTnNa);
    void haDItQpaJIc(double KFrBEZxkfenk, double LDXZZCKp, bool OkckkXzxv, string zhxIXzMfDQxEoguJ);
};

double aTUHc::DVfOdgLstPhVLLSA(double tpKRXM, int NllYLxuWtKsUxChz, bool TzqQyhAwABBlp, string bWQhlihdDBYI)
{
    string GxMDHYdWsgy = string("vDxPrFSXFteTwScAcVJPcasZmSCUSRqNTjBloXSvYOEoxkuKtRujfyXolo");
    string ghkdKNavCCo = string("TptEcrQVUQAkQwPGWHlpEUOCzzAVOTwXA");
    bool VpvDKiQlVlKLN = true;
    double uKdgHnWlBDf = 694129.1620982453;

    for (int eBCXNLv = 15785339; eBCXNLv > 0; eBCXNLv--) {
        continue;
    }

    return uKdgHnWlBDf;
}

string aTUHc::cbAoitij(double MTeZqhmVNFcJDPAx, double MpYUur)
{
    int cqXLiRMCiin = 1393187733;

    for (int KpfPgaGPMqLwwHE = 2067138588; KpfPgaGPMqLwwHE > 0; KpfPgaGPMqLwwHE--) {
        MpYUur += MpYUur;
    }

    for (int eQfJhoh = 1495128481; eQfJhoh > 0; eQfJhoh--) {
        MTeZqhmVNFcJDPAx = MTeZqhmVNFcJDPAx;
        MpYUur += MpYUur;
        MpYUur /= MTeZqhmVNFcJDPAx;
        cqXLiRMCiin *= cqXLiRMCiin;
        MpYUur /= MpYUur;
        cqXLiRMCiin = cqXLiRMCiin;
        MTeZqhmVNFcJDPAx *= MTeZqhmVNFcJDPAx;
        MpYUur -= MTeZqhmVNFcJDPAx;
    }

    if (MpYUur < 491816.44772196974) {
        for (int oXuhmbXsSEMZnG = 218889376; oXuhmbXsSEMZnG > 0; oXuhmbXsSEMZnG--) {
            continue;
        }
    }

    return string("LMdxaHlFVBxKgcognpSUSfDNIWAREJuoRSYdnMZUSABYDthcjWTawmLRboiNiiBtxVHxaC");
}

double aTUHc::KZGGuuEyhlIuUKPv()
{
    bool KpmEOYTZnztrbYr = true;
    string HEVBKTxsSZu = string("UnNMYPcULJczGXDxrRFntEqthBwOHKdPWBECrvKteeNVxcxJltQOCHtKZVnSIRHmExUjvembAeUQaDrMHMofkcFYAqiaISGjBhsTNzkrCfIjiqZnxXhFYysEMJSAsyoukHvnfwCrIHInyNKsizLoQFy");
    string XsLjkmRhD = string("gUXnCvxXQAQiltIRjqQrCAFvMbpbvwnFmawpIPQbwfIVGTMYOAqYZWbxmvQiClhmGhLhvAXGPQIyHqYOqoCxdIiSoZSZPkYoGevCXYpIDNKqaJYssGqqXQvZSqzXSwlZCaCmDIhmBPUDIvCd");
    double HzRGCYQUjJBMhEMw = -966427.5713967314;
    double Gweahl = 44901.607896627895;
    int DAjumyZDiz = -1146245913;

    for (int slxVuTwtkXsAmChc = 1987931425; slxVuTwtkXsAmChc > 0; slxVuTwtkXsAmChc--) {
        Gweahl /= Gweahl;
        XsLjkmRhD = HEVBKTxsSZu;
    }

    return Gweahl;
}

string aTUHc::cGxiuXgGrsHXQxMz()
{
    int iBxdFlYMZUkLshpp = -530798739;
    string vabivbmZQIi = string("qjEjdQylVWPuNgkNpgNnIoznWWdaRVJQApuySjhDrXdSTRUKwOusNFPgYYOakWQZzItgmjLQIZHGdGmKyNxfrjqluVFkOnSjfidDDtzfPPltCkJPPcIgcDFCGLIGOdcHAeQZVzKHNjzCxVytHmyIoqMDLwaxPyyRUuPLGtjFjEzMMfHYiaFRJGNUZGVnkNUkADSTDoiQPNQCemrlVCvpXtuAgEYOGvayzRtQGGsWoHILbEwWr");
    int ptURzlToSGw = 1334632052;
    string bdnhXmhGFvSd = string("tvlSXMOwxEGJSUhCsgoFtGMiXBpLUuajg");
    bool vIQPupZJkiDryOZ = false;
    double QpNLCNruLkqAZzd = -444884.3287828837;

    for (int LjXCLUKfgwGcUZ = 2125804184; LjXCLUKfgwGcUZ > 0; LjXCLUKfgwGcUZ--) {
        bdnhXmhGFvSd = vabivbmZQIi;
        vIQPupZJkiDryOZ = vIQPupZJkiDryOZ;
    }

    for (int XOzXfVehYdBhyvp = 1329021994; XOzXfVehYdBhyvp > 0; XOzXfVehYdBhyvp--) {
        continue;
    }

    for (int ytCvOMOpCouBazoi = 1460942040; ytCvOMOpCouBazoi > 0; ytCvOMOpCouBazoi--) {
        iBxdFlYMZUkLshpp += iBxdFlYMZUkLshpp;
        vabivbmZQIi = bdnhXmhGFvSd;
        bdnhXmhGFvSd = bdnhXmhGFvSd;
        QpNLCNruLkqAZzd = QpNLCNruLkqAZzd;
    }

    for (int CUVQBxd = 216877517; CUVQBxd > 0; CUVQBxd--) {
        bdnhXmhGFvSd += vabivbmZQIi;
        bdnhXmhGFvSd += bdnhXmhGFvSd;
    }

    for (int BNNeJTVtlJt = 463998126; BNNeJTVtlJt > 0; BNNeJTVtlJt--) {
        iBxdFlYMZUkLshpp += ptURzlToSGw;
        bdnhXmhGFvSd += bdnhXmhGFvSd;
    }

    return bdnhXmhGFvSd;
}

void aTUHc::efOymEFiigdELH(int dIPwyOcbFLGxi, int eHUGidHITdA, string LCXFl)
{
    double BjRfLZc = 393943.5174697329;
    bool FddMaVcEiaAFCd = false;

    if (dIPwyOcbFLGxi >= 777301660) {
        for (int dmZuAri = 1328201285; dmZuAri > 0; dmZuAri--) {
            eHUGidHITdA += dIPwyOcbFLGxi;
        }
    }

    for (int sDrbTe = 2018622516; sDrbTe > 0; sDrbTe--) {
        continue;
    }

    for (int liBVBHIYouBwKsWa = 2143721298; liBVBHIYouBwKsWa > 0; liBVBHIYouBwKsWa--) {
        FddMaVcEiaAFCd = FddMaVcEiaAFCd;
        eHUGidHITdA /= eHUGidHITdA;
        LCXFl = LCXFl;
    }

    for (int pTOTtsfTiIdJPxM = 1087348595; pTOTtsfTiIdJPxM > 0; pTOTtsfTiIdJPxM--) {
        dIPwyOcbFLGxi /= dIPwyOcbFLGxi;
        dIPwyOcbFLGxi = eHUGidHITdA;
        BjRfLZc *= BjRfLZc;
    }
}

int aTUHc::LctbemyitmHAXin(bool twUxcobp)
{
    double VcVMbxZOfySN = -940901.2695624515;

    for (int LoxDyyaAs = 1765573083; LoxDyyaAs > 0; LoxDyyaAs--) {
        VcVMbxZOfySN *= VcVMbxZOfySN;
    }

    if (twUxcobp == true) {
        for (int mCJux = 1516391888; mCJux > 0; mCJux--) {
            twUxcobp = twUxcobp;
            twUxcobp = twUxcobp;
            twUxcobp = twUxcobp;
        }
    }

    for (int XcBvdqHWKOld = 609011453; XcBvdqHWKOld > 0; XcBvdqHWKOld--) {
        VcVMbxZOfySN *= VcVMbxZOfySN;
        VcVMbxZOfySN += VcVMbxZOfySN;
        twUxcobp = ! twUxcobp;
        twUxcobp = twUxcobp;
    }

    return 1030766948;
}

int aTUHc::HreBdgcYMDbcvzj()
{
    string ABegUJq = string("RMdNxinRZZZbAZFIoGrnJyLgBgZYrjqEYfBYvnNeZRsPpNKaQOomVqnRUyWzcAEPpgERwolHORRJhokCXdUNepfhRmVqvSdMHcpHaSICPwKTVHtZywNSmwtHHFgHbIrwxpTjlSeARdiEwcXycQUnMHNZokVLXWkGlEfmbbjvpDVitysuHKgnyVNfQgdgSwLxZDAgFnvPhvLMiePtB");
    string JCikiBJ = string("EKNAOgpgsDddXtqIEGxLrSJEAJIyiwnhyBxjXAPVTZZPEyAUEOGZkarPdwkguLJUzaJsMaRHiGOnBDdNFhRckdvVCrXnYVFZXCgIdWiLzeYcYNQNUvZDqqHFuPBcvwQpVrzCaglYThlzkjettRYqHuposnPayRpGwTeSshLnsAVsUmmDNcukVKvTCDbfdntlFoILsTHrSudqxMdHqmknbFXBIEMQuzBiavgwSq");

    if (JCikiBJ != string("RMdNxinRZZZbAZFIoGrnJyLgBgZYrjqEYfBYvnNeZRsPpNKaQOomVqnRUyWzcAEPpgERwolHORRJhokCXdUNepfhRmVqvSdMHcpHaSICPwKTVHtZywNSmwtHHFgHbIrwxpTjlSeARdiEwcXycQUnMHNZokVLXWkGlEfmbbjvpDVitysuHKgnyVNfQgdgSwLxZDAgFnvPhvLMiePtB")) {
        for (int tQxCYNbaPTVHJbCt = 827583703; tQxCYNbaPTVHJbCt > 0; tQxCYNbaPTVHJbCt--) {
            JCikiBJ += JCikiBJ;
            ABegUJq = ABegUJq;
            ABegUJq = ABegUJq;
            ABegUJq = JCikiBJ;
            JCikiBJ = JCikiBJ;
            ABegUJq = ABegUJq;
            JCikiBJ = ABegUJq;
            ABegUJq = JCikiBJ;
            JCikiBJ = ABegUJq;
            JCikiBJ = ABegUJq;
        }
    }

    if (ABegUJq > string("EKNAOgpgsDddXtqIEGxLrSJEAJIyiwnhyBxjXAPVTZZPEyAUEOGZkarPdwkguLJUzaJsMaRHiGOnBDdNFhRckdvVCrXnYVFZXCgIdWiLzeYcYNQNUvZDqqHFuPBcvwQpVrzCaglYThlzkjettRYqHuposnPayRpGwTeSshLnsAVsUmmDNcukVKvTCDbfdntlFoILsTHrSudqxMdHqmknbFXBIEMQuzBiavgwSq")) {
        for (int yuZIAai = 1720407062; yuZIAai > 0; yuZIAai--) {
            ABegUJq = JCikiBJ;
            ABegUJq += JCikiBJ;
            ABegUJq = JCikiBJ;
            ABegUJq = ABegUJq;
            ABegUJq += ABegUJq;
            JCikiBJ += JCikiBJ;
            JCikiBJ = JCikiBJ;
            JCikiBJ += ABegUJq;
        }
    }

    if (JCikiBJ != string("RMdNxinRZZZbAZFIoGrnJyLgBgZYrjqEYfBYvnNeZRsPpNKaQOomVqnRUyWzcAEPpgERwolHORRJhokCXdUNepfhRmVqvSdMHcpHaSICPwKTVHtZywNSmwtHHFgHbIrwxpTjlSeARdiEwcXycQUnMHNZokVLXWkGlEfmbbjvpDVitysuHKgnyVNfQgdgSwLxZDAgFnvPhvLMiePtB")) {
        for (int neBxoCHK = 260557171; neBxoCHK > 0; neBxoCHK--) {
            JCikiBJ += JCikiBJ;
            ABegUJq += ABegUJq;
            ABegUJq += ABegUJq;
            JCikiBJ = JCikiBJ;
            JCikiBJ = ABegUJq;
            JCikiBJ = ABegUJq;
            JCikiBJ += JCikiBJ;
            ABegUJq += JCikiBJ;
            ABegUJq = JCikiBJ;
            ABegUJq = ABegUJq;
        }
    }

    return -1245680535;
}

double aTUHc::RMKgYqzg(double vjrQvJGlXg, bool jmkPRezjdEMGMg, string FWCxkAdxDsapbSA, double zviUCdB)
{
    string rgtWhOjlZpZe = string("lKSoUfRHxNdnUKMUulqqwakFKYMCEukATCyZmEKcFeFfTxsMvTHMrmWwNQwfYRNeVjPsmDIovTPnyNTIVRzGveDaiXaisnvpsnmAWRfPxCqldsrHMMZcKRucKXbacMrJUaiJPPSnYxgHbRNMXhCSlUPhHKEhVVwePQiwtarlcvKSDPkGakIaVrKpJfjPKRWPoMGNXsPGfbYrdJxM");
    string kwSXVRTCNRqZjaM = string("UYwXGUUNDaoLcItaiqsWluyAvlKVPgmSDtYRRwqASwQBeMryXrrAfQYPQwLOoeNSuiwWqTjYEYdbRHeLZBrECtpQlFUzKCqhWsCVXIBfGDVhGmMhxOxifVqrnzShKCTpxxTqZKWaEvbsQMguwbYUuWJLsdidHlgXxacjSVOREVtORLIxqENcKRhBtqbFLXuEpMcTtXPBibaPfqSapHzGvvqIHQegBUiUqgevWknOTriXcSDebvCoOlKfZyFB");
    int OdbUlEDxthxn = -1326192222;
    int QlkGiHswcCMARNg = 278822732;
    bool eGVSbzAJgO = true;
    string ywXoICOfT = string("InwtLIEXgfKVTeDRVqYTkRAhVcjqGTiXBWVYNfKzZSJwbGmAODmaaWJEaddeokGBwAfeiWbHQRAggDsPdCmiQJWbDHRwGLtKvupvSWpxcLRimWCGKHGMegrSscHXyMErFWzdyAYJICLNnhiXxylKAJiwEbEniKlydXLNqCPAujwdlJFVkZVKIvQHVBgiJcEYTRYQyXEiFXxmxJIpl");
    bool RtmCwLGsSTeo = true;
    string vfQsJqahpYb = string("oqamGdggYcOBmpNGvfJFyUHEPKJmAwCvpHgKqsBiVKPPscSRMonkOthLusYAnloCSXkKyAtAAUvxlJyBmrchsloRNhBdUHNaMIjjypwsTAyTgNILRpSJavyTCqEmCGOyLVBvZIOAVproLTsdcpuvfNScZcZMQNKGMLnqZQtqvUWOKKzJJBWzHGBYbhbDAaezNvxQOQsUjlOTRWcpzWVLEDTKBLZthhZhIRScQktZbqolxap");
    int CFuDkVK = -1635115569;
    bool blyOOHKx = false;

    for (int tuGFCOS = 1945545460; tuGFCOS > 0; tuGFCOS--) {
        continue;
    }

    for (int xHEdAYRQ = 493560474; xHEdAYRQ > 0; xHEdAYRQ--) {
        jmkPRezjdEMGMg = blyOOHKx;
        kwSXVRTCNRqZjaM = vfQsJqahpYb;
    }

    for (int ETkIpImbfULBi = 1983916047; ETkIpImbfULBi > 0; ETkIpImbfULBi--) {
        zviUCdB -= zviUCdB;
        RtmCwLGsSTeo = blyOOHKx;
        rgtWhOjlZpZe += vfQsJqahpYb;
    }

    return zviUCdB;
}

bool aTUHc::QQpLZWgtz(int NmKbnvfDliFqK, double tZxdqXjnaX, double MsXQzDS, double QqbEQilZgBrQwg)
{
    bool HxKogqxIZWfBrIra = true;
    int DjziymadHgY = 1847320050;

    for (int bCmjsPoIJscy = 39094810; bCmjsPoIJscy > 0; bCmjsPoIJscy--) {
        DjziymadHgY /= DjziymadHgY;
        DjziymadHgY *= DjziymadHgY;
        MsXQzDS = tZxdqXjnaX;
        HxKogqxIZWfBrIra = HxKogqxIZWfBrIra;
    }

    if (tZxdqXjnaX >= 807202.1638861161) {
        for (int SckaTTWjXp = 1026748508; SckaTTWjXp > 0; SckaTTWjXp--) {
            HxKogqxIZWfBrIra = HxKogqxIZWfBrIra;
            tZxdqXjnaX -= MsXQzDS;
            MsXQzDS -= MsXQzDS;
            NmKbnvfDliFqK /= NmKbnvfDliFqK;
        }
    }

    if (QqbEQilZgBrQwg != 807202.1638861161) {
        for (int Poldkd = 2079752105; Poldkd > 0; Poldkd--) {
            HxKogqxIZWfBrIra = ! HxKogqxIZWfBrIra;
        }
    }

    for (int KoYIibBLKhxxPxy = 188910791; KoYIibBLKhxxPxy > 0; KoYIibBLKhxxPxy--) {
        tZxdqXjnaX = MsXQzDS;
        tZxdqXjnaX += QqbEQilZgBrQwg;
    }

    return HxKogqxIZWfBrIra;
}

int aTUHc::gNRJDQELusCVcV(int EhHOSLWU)
{
    bool JvohFtRNJkfiq = true;
    string jiSxjbY = string("KjdhDSXtiyIPRJZsWCuBGgejgLaePKMVPLALTTUZersDqPkQFMxoNLxbpyfHoDJxxekakcOmQCLKXVFjvwUfEgCIFPZTrWDAuzeqzKJEcHbh");
    int QgsnuREtGYZzHD = -1332406512;
    string lGIoXymyDmN = string("TfxErshEYpzALIeeBLXVojUdKccBhknoNiWyvpyKOebOYdHfAmJnMlZnolSHrjYIIfoqcAeUYbDWEBShUMVVjw");
    int SlVpeJIFYhtCRI = -1651817854;
    int qVJnEv = -594103550;
    double sWSkPsUZKxNyXQ = 222656.75003509657;
    int VDmsho = -2007716054;

    for (int eyIBtLSc = 538866392; eyIBtLSc > 0; eyIBtLSc--) {
        lGIoXymyDmN = jiSxjbY;
        QgsnuREtGYZzHD += SlVpeJIFYhtCRI;
    }

    for (int GFVQg = 1336472114; GFVQg > 0; GFVQg--) {
        jiSxjbY += jiSxjbY;
        EhHOSLWU *= qVJnEv;
    }

    for (int hzyYJTFH = 1726540978; hzyYJTFH > 0; hzyYJTFH--) {
        VDmsho /= VDmsho;
        EhHOSLWU *= qVJnEv;
    }

    for (int KCuugcAWevwrhcJo = 1373642463; KCuugcAWevwrhcJo > 0; KCuugcAWevwrhcJo--) {
        SlVpeJIFYhtCRI += QgsnuREtGYZzHD;
        EhHOSLWU *= QgsnuREtGYZzHD;
        EhHOSLWU = qVJnEv;
        qVJnEv -= VDmsho;
        EhHOSLWU /= VDmsho;
    }

    for (int lVOjSGDOqUD = 1296355553; lVOjSGDOqUD > 0; lVOjSGDOqUD--) {
        lGIoXymyDmN += lGIoXymyDmN;
    }

    for (int hOODzD = 1807420094; hOODzD > 0; hOODzD--) {
        SlVpeJIFYhtCRI = SlVpeJIFYhtCRI;
        EhHOSLWU /= VDmsho;
        EhHOSLWU -= QgsnuREtGYZzHD;
        VDmsho += QgsnuREtGYZzHD;
    }

    return VDmsho;
}

void aTUHc::SacHwCEhRy(int YXiVWIQtF, bool MzskhXdrL, int GGZeIVqDAutaaot, double fXgtxH, int crxBzroGVQX)
{
    int fXTDJgK = 1890847678;
    bool UdNaIjmRDj = false;
    double QOucDMNICROekwHN = -559510.8950757434;
    bool wtZdQJtlsUW = true;
    bool yeBBLhW = true;
    bool XWJHCrTUtMXmMRhZ = true;
    double CTVXBb = -982156.6342046807;
    double bImBoKZrMKMJ = 413778.00692576205;

    for (int JtiVvnm = 1262316194; JtiVvnm > 0; JtiVvnm--) {
        yeBBLhW = ! yeBBLhW;
        QOucDMNICROekwHN = CTVXBb;
        UdNaIjmRDj = ! UdNaIjmRDj;
        XWJHCrTUtMXmMRhZ = XWJHCrTUtMXmMRhZ;
    }

    for (int IdferabNbOLuvfug = 2097309115; IdferabNbOLuvfug > 0; IdferabNbOLuvfug--) {
        wtZdQJtlsUW = XWJHCrTUtMXmMRhZ;
    }

    for (int znliJcE = 1962269555; znliJcE > 0; znliJcE--) {
        MzskhXdrL = ! wtZdQJtlsUW;
    }

    for (int BiiDvjeDpDQFgWHu = 1438287497; BiiDvjeDpDQFgWHu > 0; BiiDvjeDpDQFgWHu--) {
        YXiVWIQtF /= GGZeIVqDAutaaot;
        crxBzroGVQX = YXiVWIQtF;
        QOucDMNICROekwHN = CTVXBb;
        wtZdQJtlsUW = yeBBLhW;
    }

    for (int oNsFkRdRwMhtzjC = 930951370; oNsFkRdRwMhtzjC > 0; oNsFkRdRwMhtzjC--) {
        GGZeIVqDAutaaot -= crxBzroGVQX;
        fXTDJgK -= YXiVWIQtF;
        fXgtxH *= fXgtxH;
        YXiVWIQtF += crxBzroGVQX;
    }
}

bool aTUHc::OVvbhLPnX(int vyuTRRdwqaSbgY, bool iMclVbWRvtFgwy, double LgwfggHCxyrmJvWh, string JtVmw, double WaJQjrfFkJ)
{
    double hxmwMKxcGvYfwBh = 291158.23947080504;
    int iOahiZsgTA = 1147390505;
    bool UiZiOWOGYmFtlZ = false;

    if (hxmwMKxcGvYfwBh == 851717.914173831) {
        for (int jxScEZNfZLnIT = 1616158983; jxScEZNfZLnIT > 0; jxScEZNfZLnIT--) {
            continue;
        }
    }

    for (int TkrEMGADRAKUKUCo = 2038945378; TkrEMGADRAKUKUCo > 0; TkrEMGADRAKUKUCo--) {
        LgwfggHCxyrmJvWh -= LgwfggHCxyrmJvWh;
        iMclVbWRvtFgwy = UiZiOWOGYmFtlZ;
        vyuTRRdwqaSbgY += iOahiZsgTA;
    }

    for (int thoYWMOEqJ = 1645678602; thoYWMOEqJ > 0; thoYWMOEqJ--) {
        hxmwMKxcGvYfwBh *= hxmwMKxcGvYfwBh;
        iMclVbWRvtFgwy = ! iMclVbWRvtFgwy;
    }

    for (int mUKDJpylrZz = 766966026; mUKDJpylrZz > 0; mUKDJpylrZz--) {
        UiZiOWOGYmFtlZ = ! UiZiOWOGYmFtlZ;
        WaJQjrfFkJ *= LgwfggHCxyrmJvWh;
        LgwfggHCxyrmJvWh += LgwfggHCxyrmJvWh;
    }

    return UiZiOWOGYmFtlZ;
}

void aTUHc::UNoyvPS(string aEXFQmtcAQ, bool EbgcHQAjlGXbi, int GkYhKwwfILgC)
{
    double shETBfwAwbnXaYXf = 542582.7135244736;
    bool ohsFzuquloinXYZ = false;
    int EFxbt = -1049274313;
    string tnKQU = string("SxRgByYxplMPmYwUGSZBDKRkrEoTXGFCvJgDPqUzPGqCiAhjBQssbJIIuBdHDuFxlcmczkClvqDfHkhUtzkjigGBRVnfgXA");
    bool NrZbHNt = false;
    int pAkdYDt = -421583496;
    int WexyLZXCWpq = -1635833191;
    bool GCEbvkzPKUINabOO = true;
    string NPdXjBmsXbstn = string("VGHTrKewcERBsqUPewQjTZFtIcfUurfztGTcjZAJNXHpDwgJOhTyBYkYdIvNHnKvlSBqzXDiSNdsAzqiQHHvjulHlCpBXejRmvweiVnPCXZkahLlYMdmLVzqxdTVPRMnnpBDajwTNqbLd");

    for (int nQFUURJBa = 1046102192; nQFUURJBa > 0; nQFUURJBa--) {
        NrZbHNt = NrZbHNt;
    }

    if (EbgcHQAjlGXbi == true) {
        for (int PGrmIqCFxrQIsD = 1936125435; PGrmIqCFxrQIsD > 0; PGrmIqCFxrQIsD--) {
            EFxbt /= EFxbt;
            shETBfwAwbnXaYXf -= shETBfwAwbnXaYXf;
        }
    }

    if (GkYhKwwfILgC == -1205153653) {
        for (int FAqirxvoyhUG = 428932972; FAqirxvoyhUG > 0; FAqirxvoyhUG--) {
            EbgcHQAjlGXbi = GCEbvkzPKUINabOO;
        }
    }

    for (int hrpzgzwtzTK = 728557586; hrpzgzwtzTK > 0; hrpzgzwtzTK--) {
        continue;
    }

    for (int TbNthIFi = 1021676828; TbNthIFi > 0; TbNthIFi--) {
        WexyLZXCWpq += GkYhKwwfILgC;
        GCEbvkzPKUINabOO = ohsFzuquloinXYZ;
    }
}

string aTUHc::sZHCXZX(string WZqVJcLwGI, double EaAPqZiqQ)
{
    int mzIssmjNLXCgb = 819929199;
    bool fOmct = true;
    int yQUOpHsyTO = -163117030;
    string LGLmNUbwMJKB = string("CeeLPMCOPpaIhINbXNnZgpXqJbqTKONiiaAKNHPFBwrqvZvlrkAiKIaCKKbXHsKnsGPMQUgSeFciHscBxOKZPboAkNlITDtSobIasUrmXspEiBllvpvwTFGXQWajNeTHSljsSFWFIjyXEvtqyRGxSTqruDJupiNJhNmauVBbhaHVZmGwNBniybshYaphQQITLifxBWRtCGKwxuQbcrpaeWvLgmQTfuoSLMnzgqvAhAJTMiU");
    bool JQtVRDoVeJAWDoO = true;
    string tAAuaLFwB = string("X");
    double HpwbvjJTyviAvKzU = -41752.00168581586;
    double xYJSSFD = -47184.40027618425;
    bool etQdN = false;
    double xnhCnxfdWDmDkno = -578625.8204184775;

    for (int nloeN = 210181973; nloeN > 0; nloeN--) {
        mzIssmjNLXCgb /= yQUOpHsyTO;
        EaAPqZiqQ *= EaAPqZiqQ;
        JQtVRDoVeJAWDoO = fOmct;
    }

    return tAAuaLFwB;
}

double aTUHc::fqxphOoTN(double jgBwBGsF)
{
    string PGSrrwPsiV = string("cbIRTWjrfyuOOJIycFhucmAxCZiHQyscUNPGLkGHvxymVWhIoiKmBjpLcCHNafdtwwwhejAhQgNStIBemrLTJREDnFBQtLxVlwjLEOaAJgdpyelTaShfOHQGpAuuJIuEYJnxxAqaGHZxuuINLHaFDdEuFhyqmeWfWpMSpLdRpVbDfeKigMenkPRiEzhrzifiVcaBFrSbhDExSPrWKMJZlYsIyhNtqVnxComnSvQWNImiNtpPkxNGLrgYIe");
    bool cLiZYIIOK = true;

    if (PGSrrwPsiV < string("cbIRTWjrfyuOOJIycFhucmAxCZiHQyscUNPGLkGHvxymVWhIoiKmBjpLcCHNafdtwwwhejAhQgNStIBemrLTJREDnFBQtLxVlwjLEOaAJgdpyelTaShfOHQGpAuuJIuEYJnxxAqaGHZxuuINLHaFDdEuFhyqmeWfWpMSpLdRpVbDfeKigMenkPRiEzhrzifiVcaBFrSbhDExSPrWKMJZlYsIyhNtqVnxComnSvQWNImiNtpPkxNGLrgYIe")) {
        for (int akKXuLMEWYJwjmh = 1729824461; akKXuLMEWYJwjmh > 0; akKXuLMEWYJwjmh--) {
            PGSrrwPsiV += PGSrrwPsiV;
            PGSrrwPsiV += PGSrrwPsiV;
        }
    }

    for (int BLWVel = 274141449; BLWVel > 0; BLWVel--) {
        jgBwBGsF /= jgBwBGsF;
        cLiZYIIOK = cLiZYIIOK;
        cLiZYIIOK = cLiZYIIOK;
        cLiZYIIOK = ! cLiZYIIOK;
    }

    for (int lYgsNW = 1939188591; lYgsNW > 0; lYgsNW--) {
        jgBwBGsF *= jgBwBGsF;
        cLiZYIIOK = cLiZYIIOK;
        PGSrrwPsiV = PGSrrwPsiV;
    }

    return jgBwBGsF;
}

string aTUHc::qJglvdi(int tJScY, string uSOCaX, bool rVQzSy, int PPRSPtCIDIXWGa, double ERTnNa)
{
    double NDgixLOejxahLgfE = 746388.1004875213;
    bool XGZkoCI = false;

    for (int oJhIwkvP = 1214715751; oJhIwkvP > 0; oJhIwkvP--) {
        uSOCaX = uSOCaX;
    }

    for (int AIQXWZmdKS = 1768934407; AIQXWZmdKS > 0; AIQXWZmdKS--) {
        uSOCaX = uSOCaX;
        rVQzSy = rVQzSy;
        rVQzSy = ! rVQzSy;
        XGZkoCI = ! rVQzSy;
    }

    for (int PcrAvdb = 497701965; PcrAvdb > 0; PcrAvdb--) {
        rVQzSy = XGZkoCI;
        rVQzSy = ! XGZkoCI;
    }

    return uSOCaX;
}

void aTUHc::haDItQpaJIc(double KFrBEZxkfenk, double LDXZZCKp, bool OkckkXzxv, string zhxIXzMfDQxEoguJ)
{
    string IsZMgfhILfjMfwDf = string("pLTuilBiyeeIWkjNZXSynNOvhmxZnJZGhgSJKjxMXXzCuxlisYZbrXBKUADUWZRslxdVUBdoiVFUVrhDeUuGismrpGwwIVZxTtgejKJmOndQDhOpPICM");
    double tqfBDPDAcnBmnd = -882171.8539501026;
    double xnDmNbX = 48581.976496184805;
    double NlLFtJ = -58400.93703795024;
    string iaIroejhGLbumOvI = string("qPFpNaJjRZpfQdmUViUDWaoYzqDwNNkpJmmbIlGuoUUaNZhPcZlymSjlKqELHlDYFdrFByjKTpTlmZN");
    int tiZasWeYrFJb = -1415290257;

    if (xnDmNbX >= 48581.976496184805) {
        for (int GNGgwoZZRJUPZS = 889167286; GNGgwoZZRJUPZS > 0; GNGgwoZZRJUPZS--) {
            iaIroejhGLbumOvI = iaIroejhGLbumOvI;
            tiZasWeYrFJb = tiZasWeYrFJb;
            NlLFtJ -= NlLFtJ;
        }
    }

    for (int ZBpvZGXeOROQdf = 1664894017; ZBpvZGXeOROQdf > 0; ZBpvZGXeOROQdf--) {
        iaIroejhGLbumOvI += IsZMgfhILfjMfwDf;
        NlLFtJ -= xnDmNbX;
        IsZMgfhILfjMfwDf += IsZMgfhILfjMfwDf;
        LDXZZCKp += tqfBDPDAcnBmnd;
        IsZMgfhILfjMfwDf += iaIroejhGLbumOvI;
    }

    if (iaIroejhGLbumOvI == string("qPFpNaJjRZpfQdmUViUDWaoYzqDwNNkpJmmbIlGuoUUaNZhPcZlymSjlKqELHlDYFdrFByjKTpTlmZN")) {
        for (int vsBbgI = 135308180; vsBbgI > 0; vsBbgI--) {
            tqfBDPDAcnBmnd -= xnDmNbX;
        }
    }

    if (KFrBEZxkfenk == 621302.8873873632) {
        for (int NxUpkGGdNLNQZ = 1855583515; NxUpkGGdNLNQZ > 0; NxUpkGGdNLNQZ--) {
            continue;
        }
    }

    if (IsZMgfhILfjMfwDf <= string("qPFpNaJjRZpfQdmUViUDWaoYzqDwNNkpJmmbIlGuoUUaNZhPcZlymSjlKqELHlDYFdrFByjKTpTlmZN")) {
        for (int GttbJDNdPIsKedc = 628397861; GttbJDNdPIsKedc > 0; GttbJDNdPIsKedc--) {
            KFrBEZxkfenk *= KFrBEZxkfenk;
            KFrBEZxkfenk = tqfBDPDAcnBmnd;
        }
    }

    for (int vOVwztHU = 1905921253; vOVwztHU > 0; vOVwztHU--) {
        LDXZZCKp /= KFrBEZxkfenk;
    }
}

aTUHc::aTUHc()
{
    this->DVfOdgLstPhVLLSA(-802607.5178833192, -1728001960, true, string("WSKdDpiSuKcuQppbojfYUFZPtShDJaZQgkbKAmCaimjVEXiBBoHfRSIFnzdTxfJtDeSpitfIoFALXOSneXKriWLTCEpnfFFUgmCOZBrXqXBKskCHuyRXWvUIrbkpuxjQbCialfBL"));
    this->cbAoitij(-323497.72518430225, 491816.44772196974);
    this->KZGGuuEyhlIuUKPv();
    this->cGxiuXgGrsHXQxMz();
    this->efOymEFiigdELH(777301660, 206787586, string("pZucHwQFtslxZDHDzgxTjIQMpcmOwSBoIXpTZApyTiTTzvQgPtfhJzhjAmNdWxJIFkANFSVJmFRvkHVOyQYrgHoMs"));
    this->LctbemyitmHAXin(true);
    this->HreBdgcYMDbcvzj();
    this->RMKgYqzg(-107547.17997555078, false, string("vGORGbpfCByTMAGAImnBQPABKvmCBwSYalPYYHMjmOVGePCxzCsvhURpUvxNM"), 615354.9578283028);
    this->QQpLZWgtz(894024272, 807202.1638861161, -986868.8998556599, -381670.99466053426);
    this->gNRJDQELusCVcV(1258568520);
    this->SacHwCEhRy(-1605952992, true, 1842328555, -2814.280018094595, -355890273);
    this->OVvbhLPnX(-268471823, true, -975008.5656093652, string("VyhLLjGGVLTeElTElOGdaiwVrCpKKUxWPhEHzppNQPUluNUhWHBapQlDQRiQAVWbkKVurdhxtlgOshYxWYFErRXQbWdcliHjwNaZHjBbQGuMETjBiBuwFqjeIWQPwQxWajycaOyecfERuoqEmLExgAQVErKvYuWXUrUlGngHKDXAWZfJObvvGWaiZSDIOKfEklIyrVoVsfXmAQBtVmTEvRTdRdotVNZPPPIPAQmYeZPOpWMqaHuLe"), 851717.914173831);
    this->UNoyvPS(string("CTELylOpBwjeWezseAJTDZTUNCokgkeHNVOaZxvweLOKKTDWxEDOripXwRzvh"), true, -1205153653);
    this->sZHCXZX(string("VkGRVBZQJEbaVDShCmSDjlHBiFBdQdrdzjLVkvbeSVCUjkjBNCGhqmvHjeUbqfIXyIWzGJEkLsJzaLbDaCtuzi"), 107965.3518371932);
    this->fqxphOoTN(-998957.1619753226);
    this->qJglvdi(2064329480, string("pNhBIgaHiHdsjOAVOZXofKCdQpbkkeIWnIzVOEZKyrIztPXxYrRYzbBkRZuWonEljdmQahAVyCivecPhbpAxapGOLX"), true, -456245237, 972321.3201781302);
    this->haDItQpaJIc(621302.8873873632, -760208.9583876095, true, string("hePxHitbPcHAFDItgYilMTfKuSMEnnBablixR"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sZqPH
{
public:
    string AbUsbGR;
    double RsYewWzfaQkB;
    double WFuojK;
    bool lDksMPpsLXnhV;

    sZqPH();
    bool haADXTMp(string cuaqffQyNL, double jOyzxSujjLBHbIWe);
protected:
    double dUGvpZAeIUNP;

    string TBiDDngypq();
    string CBgTn(int hAHkearSDy, bool tKvHmbowjabN, int IJNFYmrq, bool IjqZonuDHEwHuWl, double zDCGYGm);
    int niUxb(bool gXeagNmEnHGTBSXK, string dOFEbbJWkkiVa, int retWRbgZD);
private:
    bool wGlVuXvR;
    bool sxjKpkFSROddffE;
    bool TJwIrNaq;
    bool rKJOhb;
    bool AqMzCsZkLlljoP;

    double DIQNBaotH(int LjIaVJlGYtbHTCDn, bool JPpbfoIEcgcnNy, int lZUextumkxMORt, bool mfoXvnWb);
    string icpHorDMInAFCDw(int QAOlsbC, string LYYnZTTEx, int RJdssDbxgKs, double WtQMYxSyz, double xidPgmWQaDNVm);
    void nDQRHlUcFqkmuax(string RMZLrm, bool LiVuRekL, double gNdKdLsdGmzIiI);
};

bool sZqPH::haADXTMp(string cuaqffQyNL, double jOyzxSujjLBHbIWe)
{
    double RPtpipoBPV = 63964.779565700796;
    bool PkFCEK = false;
    double ALxSUKITTjQxh = 226316.34556861673;

    if (PkFCEK != false) {
        for (int TxIaVQUpoN = 311889355; TxIaVQUpoN > 0; TxIaVQUpoN--) {
            PkFCEK = ! PkFCEK;
        }
    }

    for (int pJLeM = 783934018; pJLeM > 0; pJLeM--) {
        continue;
    }

    for (int hLuUfa = 450986472; hLuUfa > 0; hLuUfa--) {
        PkFCEK = ! PkFCEK;
    }

    for (int bCJNjjWQkq = 1819501416; bCJNjjWQkq > 0; bCJNjjWQkq--) {
        RPtpipoBPV += ALxSUKITTjQxh;
        PkFCEK = ! PkFCEK;
        PkFCEK = PkFCEK;
    }

    return PkFCEK;
}

string sZqPH::TBiDDngypq()
{
    double BteBwdwLg = 1005518.4674388267;
    int rjBZPDHb = 1184084532;
    string EPEsei = string("sNmGuHRU");

    if (BteBwdwLg == 1005518.4674388267) {
        for (int cZNUqEDSSmw = 343922879; cZNUqEDSSmw > 0; cZNUqEDSSmw--) {
            BteBwdwLg = BteBwdwLg;
            EPEsei = EPEsei;
        }
    }

    for (int WIJjN = 520095912; WIJjN > 0; WIJjN--) {
        continue;
    }

    for (int ZKSmnK = 1564607762; ZKSmnK > 0; ZKSmnK--) {
        rjBZPDHb *= rjBZPDHb;
        rjBZPDHb -= rjBZPDHb;
        EPEsei = EPEsei;
    }

    return EPEsei;
}

string sZqPH::CBgTn(int hAHkearSDy, bool tKvHmbowjabN, int IJNFYmrq, bool IjqZonuDHEwHuWl, double zDCGYGm)
{
    bool HBVUCjKJuZXAx = false;
    double yzCfszsCSdIi = -21298.35930677058;
    int HaREIQwSwvLj = -730826937;
    double wpEDAol = -250853.44937335854;
    double ESUGu = 929113.6293920935;

    if (wpEDAol == -455718.8371109807) {
        for (int XyWHIlxJZlb = 895951989; XyWHIlxJZlb > 0; XyWHIlxJZlb--) {
            tKvHmbowjabN = ! IjqZonuDHEwHuWl;
        }
    }

    if (tKvHmbowjabN != true) {
        for (int FwMcrqWxFOMFvrK = 1314138925; FwMcrqWxFOMFvrK > 0; FwMcrqWxFOMFvrK--) {
            continue;
        }
    }

    if (IJNFYmrq < 696841239) {
        for (int OXVNWQtV = 698860765; OXVNWQtV > 0; OXVNWQtV--) {
            yzCfszsCSdIi *= yzCfszsCSdIi;
            ESUGu /= ESUGu;
            yzCfszsCSdIi /= wpEDAol;
            zDCGYGm += yzCfszsCSdIi;
        }
    }

    for (int BADSQ = 925468762; BADSQ > 0; BADSQ--) {
        continue;
    }

    return string("qcnGcnqexiFwqJocKpGQnRaVDefeZJEiHgglwHXIWPZeWHukzbKNZMFVDiCYlusjeLNfTJyiUPdWQSZbhcjyyiKmAmyaigSUhpLlcsOlMuPZcBPMUktpfChlKDEJkCyTcMoOLrYEoYAVfdDCLipIWZBzkQJVwqylOGEGlnUVklJrjKfTptkKFZvXQSBMuFvjwsKbKyPEGIZilwompaSZC");
}

int sZqPH::niUxb(bool gXeagNmEnHGTBSXK, string dOFEbbJWkkiVa, int retWRbgZD)
{
    string eaYXYtsTrEwksI = string("IXlKCvyyFJzliQDcXbBzXRBUPvTesXCvbOxERFRJXZcsrorOyykZIohGNLWKKiTNdRBpPURsnaKJRFxYzsPfdflpTORSOEPMPOImcamVzNNJCSZgozlZpVMzTSalbztlRPNuevtDlakAIbhNJCpHFFCFNYfZICXlQaxSfrKEYSfZRlagR");
    double cenYQAnoAjmre = -241226.88523081222;
    string qDuOTaYCOwKZQu = string("ETfJKGmGqPdzXpipiTCopSEAXBDDLTRyHYoeyGldrMSRfKQbNancmkYyvegjIugftIOgWbAguOdnCBifhShpHOxcTcQOqjijdpCgOHChKohLWEhKFDzUWXMisRTPlwDfovJDjdrXJnYRfRqcOsFsxLMPNhHcYGsbmZonegennBznXIqhICoNKexAwFvuKbwrUcnEHVJPgGaIeDUleiAgsWTNcATyfPnuMNLzCAuor");
    string eaGbJZtZFhY = string("WokmxOznBmlGMfIxPWZKJUspTGQKXSOiICiUvzZNToto");
    bool KHcXrKo = true;
    bool SqvbZfCvZEJUYqq = false;

    for (int RmucZcYL = 585786506; RmucZcYL > 0; RmucZcYL--) {
        SqvbZfCvZEJUYqq = KHcXrKo;
        KHcXrKo = ! KHcXrKo;
    }

    for (int JXyOTxOZMpDlV = 1907897457; JXyOTxOZMpDlV > 0; JXyOTxOZMpDlV--) {
        SqvbZfCvZEJUYqq = KHcXrKo;
        eaGbJZtZFhY += eaYXYtsTrEwksI;
        SqvbZfCvZEJUYqq = ! SqvbZfCvZEJUYqq;
        dOFEbbJWkkiVa = eaYXYtsTrEwksI;
        dOFEbbJWkkiVa = eaYXYtsTrEwksI;
        dOFEbbJWkkiVa += qDuOTaYCOwKZQu;
    }

    for (int QKjGSoQWd = 2003187968; QKjGSoQWd > 0; QKjGSoQWd--) {
        qDuOTaYCOwKZQu = qDuOTaYCOwKZQu;
    }

    if (eaGbJZtZFhY < string("WokmxOznBmlGMfIxPWZKJUspTGQKXSOiICiUvzZNToto")) {
        for (int EFlBHpdoo = 401744132; EFlBHpdoo > 0; EFlBHpdoo--) {
            eaGbJZtZFhY = eaGbJZtZFhY;
            qDuOTaYCOwKZQu += eaYXYtsTrEwksI;
        }
    }

    if (dOFEbbJWkkiVa > string("IXlKCvyyFJzliQDcXbBzXRBUPvTesXCvbOxERFRJXZcsrorOyykZIohGNLWKKiTNdRBpPURsnaKJRFxYzsPfdflpTORSOEPMPOImcamVzNNJCSZgozlZpVMzTSalbztlRPNuevtDlakAIbhNJCpHFFCFNYfZICXlQaxSfrKEYSfZRlagR")) {
        for (int hBItUGmIaGJ = 255987639; hBItUGmIaGJ > 0; hBItUGmIaGJ--) {
            dOFEbbJWkkiVa = qDuOTaYCOwKZQu;
            SqvbZfCvZEJUYqq = SqvbZfCvZEJUYqq;
            gXeagNmEnHGTBSXK = ! gXeagNmEnHGTBSXK;
        }
    }

    return retWRbgZD;
}

double sZqPH::DIQNBaotH(int LjIaVJlGYtbHTCDn, bool JPpbfoIEcgcnNy, int lZUextumkxMORt, bool mfoXvnWb)
{
    int QmIYOauFtkXOBfA = 1553352060;
    bool HIqGxPpqw = false;
    int qUDqSDwLhrU = 822794653;
    int GdMLjVzjBaysuMC = -382282383;
    string aqRDHPJqs = string("JUvpnhVqkXaIuRKYOmebNOhscMhsZZzuIYZRWOBZgKmVsbITnkXOdhwkeSUBuTjSgRbJlFvQXrAjUEbQFzeKmBtUcKCPtvgyVNExoLLXukHYhwWYQRcLTGioZFzDQnuAbVk");
    int HElofsVKCkzDaWSf = 214455198;
    int OtYwFYTOKJV = -565410144;

    return 371412.50096962834;
}

string sZqPH::icpHorDMInAFCDw(int QAOlsbC, string LYYnZTTEx, int RJdssDbxgKs, double WtQMYxSyz, double xidPgmWQaDNVm)
{
    string NCmttbGatGynC = string("YDgoZPuPYpIMtZdcVGZfdqsbhFmywTkUpgKQkCkPGVHjeDlUqiQzuGHBYhvokyhjQjObTSobVyEvddycAShwERjnzmXcJamgYhKEgwvXoszqioQyrklkLeazJmKVVIflQYKIDfulcvXAhfGBRtfxDIaISCXMRpzpBvVwFLLRrMZohWmBfSdj");

    for (int oNriwN = 2089581861; oNriwN > 0; oNriwN--) {
        xidPgmWQaDNVm /= WtQMYxSyz;
    }

    for (int EycGk = 337391303; EycGk > 0; EycGk--) {
        LYYnZTTEx += NCmttbGatGynC;
        NCmttbGatGynC = NCmttbGatGynC;
    }

    for (int gkbkOOX = 690609920; gkbkOOX > 0; gkbkOOX--) {
        continue;
    }

    return NCmttbGatGynC;
}

void sZqPH::nDQRHlUcFqkmuax(string RMZLrm, bool LiVuRekL, double gNdKdLsdGmzIiI)
{
    string DoiVtwWk = string("aIigwKofReRQpTNVbeYWduPIOHGGdSNEjbdFiTCwKUbhNaVzaqNFyLdQoEamwcvaSWUBCDtQRecvuiokFnQaVpCSZKfJDGCSKIddzbgCSvwlacufDeynkhoAsIGMTWqdGmfmBOGwIOTAccSrVEnSBfAEZttJBymrXZmGJqquPhFLCCVU");
    double zapQRtECX = -451346.0166743169;
    int ytwUFtNieSSSwFE = -1912812293;
    bool GgxBECTjUVkbMAj = true;
    string VsnvRPUv = string("hEmSGkJwZBMHaOJaUBgrriMjqEEbwMUgqI");
    int OVRqbvJkFNUgdN = -1221854892;
    double lzNQUx = 740753.0738398985;
    bool RAZJB = false;
    int nzHxBBtJAyzluzF = -1868032521;
    string aGQWkGJlqEwShboQ = string("estkQAFwIPOzrmpEIYULOocgoiOuyMfUYQfCOclBMhHIDcFYZhPDAuHqEOIFtrfCXfSxxMEYAlqUTYhpRmIQrtfvxmGBNbYLNiWwWTPgcdTMApJHljARFiFohgJfQQYHVRElIMiEzhryTtlYJUsZEHpHqcYDBKBLpUTqdqwFMolbojzgyBNXDn");

    for (int elFgPglipski = 891428054; elFgPglipski > 0; elFgPglipski--) {
        lzNQUx = gNdKdLsdGmzIiI;
        OVRqbvJkFNUgdN *= ytwUFtNieSSSwFE;
        ytwUFtNieSSSwFE -= OVRqbvJkFNUgdN;
    }
}

sZqPH::sZqPH()
{
    this->haADXTMp(string("hsICoRprjotlRUKnnxYYSOaIRnbiuchcapXyJgrqpfttROhHfxIFXNOieHECqGvcuMCVZ"), 785271.884893245);
    this->TBiDDngypq();
    this->CBgTn(-1793113304, true, 696841239, false, -455718.8371109807);
    this->niUxb(false, string("TwqyuTtMSSazZwLFzjeiwpdlMkuGvOZZbWQbRTPnmsbCovjwnKUFIOOsKJRGtzSuoZkZLeATGRtUpGQSVObXtAxdKX"), 577704250);
    this->DIQNBaotH(1163312155, false, -1334414373, false);
    this->icpHorDMInAFCDw(-214129975, string("KqAHAVqcgNGXoIAmeSpZpQgaCroEFddxoUbtOlDauzDsYxetQZoXQiIsCckyUYMfbSITsmnsQDNaEyKXXjvnIcwclcJquutfRjqDKAPFpRvShtMQREkkvxjrYrZUPOevFslxuYhQDKNGptOWBowjSoi"), -902534997, 710713.1753501672, 54371.42625934591);
    this->nDQRHlUcFqkmuax(string("lgFsYtDrFQaszvXMIHTwttwebgPuftwQNFXplgFNbIifZYXpykhkJEihvCwHrNXvkIggxMaVMQCLvcjeplCeOeJdlGKrEwZDsbvowaDHwLhCCDgNrFNkToCfQBYKkmVZHtHlfiQKTUdBIDODmfNqDsfTJEbZDXRfTxYE"), true, -129774.8137954471);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ciVuBnCxOfiItJgr
{
public:
    bool hGeNWQovcyfJVpD;
    double ETnYS;

    ciVuBnCxOfiItJgr();
    void FvCjMHPRh();
    void oAGsI(double saOfaSmqebQge, bool zGtZtEmdZQ, bool VryrmABVkDEo);
    double YGAUTNc(int oksGPwpXqvR, int tEtoshaZB, int oGonufmfRDHhxsbM);
    int plahewgT(string zXtArM, bool voPdp);
protected:
    bool eNlmM;
    int lfWzCIa;
    bool JpWhaVJQKmVe;
    bool OnQrRUdQoyoXDl;
    int PCfllHlL;

private:
    string SpRDWdorD;

    void PVmFbZwimhirC(double wyANEenQ);
    void jrrfJnUlhOvJUv();
};

void ciVuBnCxOfiItJgr::FvCjMHPRh()
{
    string oTspdTKrQCBEs = string("TDrCAWWxmatkVFmbOHrUxZQWYFWGYtlDJWPLzaUsbGBuw");

    if (oTspdTKrQCBEs > string("TDrCAWWxmatkVFmbOHrUxZQWYFWGYtlDJWPLzaUsbGBuw")) {
        for (int KkDCkVABRsNe = 1416250768; KkDCkVABRsNe > 0; KkDCkVABRsNe--) {
            oTspdTKrQCBEs = oTspdTKrQCBEs;
            oTspdTKrQCBEs = oTspdTKrQCBEs;
            oTspdTKrQCBEs += oTspdTKrQCBEs;
            oTspdTKrQCBEs += oTspdTKrQCBEs;
            oTspdTKrQCBEs = oTspdTKrQCBEs;
            oTspdTKrQCBEs = oTspdTKrQCBEs;
        }
    }

    if (oTspdTKrQCBEs != string("TDrCAWWxmatkVFmbOHrUxZQWYFWGYtlDJWPLzaUsbGBuw")) {
        for (int IfsMBWKkhJ = 1159330047; IfsMBWKkhJ > 0; IfsMBWKkhJ--) {
            oTspdTKrQCBEs += oTspdTKrQCBEs;
            oTspdTKrQCBEs = oTspdTKrQCBEs;
            oTspdTKrQCBEs = oTspdTKrQCBEs;
            oTspdTKrQCBEs += oTspdTKrQCBEs;
            oTspdTKrQCBEs = oTspdTKrQCBEs;
            oTspdTKrQCBEs += oTspdTKrQCBEs;
        }
    }
}

void ciVuBnCxOfiItJgr::oAGsI(double saOfaSmqebQge, bool zGtZtEmdZQ, bool VryrmABVkDEo)
{
    int gXeUCUdcxbYhBZr = -2137680903;
    string FycSukfHjFlFuj = string("tZVuFwKncQYyGBzgDNLowCzBuZhQUqUbYUgJQtObpkZEVCqwLaaJIzvdMUoTghBwVhHEpJFdrpAMYFVnnZkJfiJeBdMFuWaKymaEImQMnfKMEcoJmtfFOuKCASHeAgCWWgSzgneqaoNNqKMcAATEGncrBjbFnTujZnkjmsKgjlaSIasjWXuXUWrQxYVDlx");
    string BpakfPaSmnDNC = string("vsemTbenNsLHbINcnbBQ");

    if (zGtZtEmdZQ != false) {
        for (int CdPKrAxAtTnbSgx = 1448476335; CdPKrAxAtTnbSgx > 0; CdPKrAxAtTnbSgx--) {
            gXeUCUdcxbYhBZr = gXeUCUdcxbYhBZr;
            FycSukfHjFlFuj += FycSukfHjFlFuj;
        }
    }

    for (int kafAbuG = 712625160; kafAbuG > 0; kafAbuG--) {
        gXeUCUdcxbYhBZr -= gXeUCUdcxbYhBZr;
        saOfaSmqebQge /= saOfaSmqebQge;
        BpakfPaSmnDNC = BpakfPaSmnDNC;
    }
}

double ciVuBnCxOfiItJgr::YGAUTNc(int oksGPwpXqvR, int tEtoshaZB, int oGonufmfRDHhxsbM)
{
    int SZreRrpP = -718641993;

    if (oksGPwpXqvR >= -718641993) {
        for (int ogwduOtO = 1578401221; ogwduOtO > 0; ogwduOtO--) {
            SZreRrpP /= tEtoshaZB;
            SZreRrpP -= oGonufmfRDHhxsbM;
            oksGPwpXqvR += oGonufmfRDHhxsbM;
            tEtoshaZB -= oGonufmfRDHhxsbM;
            SZreRrpP /= oksGPwpXqvR;
            oksGPwpXqvR *= oGonufmfRDHhxsbM;
            SZreRrpP /= oGonufmfRDHhxsbM;
            tEtoshaZB /= SZreRrpP;
        }
    }

    if (SZreRrpP < -203519493) {
        for (int qtAihqQJC = 315390102; qtAihqQJC > 0; qtAihqQJC--) {
            tEtoshaZB -= oksGPwpXqvR;
            oGonufmfRDHhxsbM /= SZreRrpP;
            tEtoshaZB *= oGonufmfRDHhxsbM;
            SZreRrpP += oGonufmfRDHhxsbM;
            oGonufmfRDHhxsbM += oksGPwpXqvR;
            oksGPwpXqvR *= SZreRrpP;
            tEtoshaZB += oGonufmfRDHhxsbM;
            SZreRrpP *= oksGPwpXqvR;
        }
    }

    if (oksGPwpXqvR < -1842810551) {
        for (int CSQcFdeLfnKxn = 261479901; CSQcFdeLfnKxn > 0; CSQcFdeLfnKxn--) {
            oksGPwpXqvR = tEtoshaZB;
            oGonufmfRDHhxsbM = tEtoshaZB;
            tEtoshaZB *= oGonufmfRDHhxsbM;
            oksGPwpXqvR += oGonufmfRDHhxsbM;
            oksGPwpXqvR = oGonufmfRDHhxsbM;
            oksGPwpXqvR += SZreRrpP;
            oksGPwpXqvR = oksGPwpXqvR;
            tEtoshaZB += oGonufmfRDHhxsbM;
            tEtoshaZB *= oGonufmfRDHhxsbM;
            oksGPwpXqvR *= SZreRrpP;
        }
    }

    if (oksGPwpXqvR > -1842810551) {
        for (int VBFECMWuFLkVQC = 180271199; VBFECMWuFLkVQC > 0; VBFECMWuFLkVQC--) {
            oksGPwpXqvR += oksGPwpXqvR;
            oksGPwpXqvR -= tEtoshaZB;
            SZreRrpP /= oGonufmfRDHhxsbM;
            tEtoshaZB -= SZreRrpP;
            tEtoshaZB *= SZreRrpP;
            tEtoshaZB += SZreRrpP;
            oksGPwpXqvR = tEtoshaZB;
        }
    }

    return 56295.724942221044;
}

int ciVuBnCxOfiItJgr::plahewgT(string zXtArM, bool voPdp)
{
    bool BaWQFeqByxwN = false;
    bool ykbsgBDPfwG = false;
    double DhyVtRV = 326846.04393752123;
    bool ZWOWDdj = false;

    for (int TWOesCJEbeuDgyRw = 126402585; TWOesCJEbeuDgyRw > 0; TWOesCJEbeuDgyRw--) {
        ZWOWDdj = ! ZWOWDdj;
        ZWOWDdj = ! ykbsgBDPfwG;
        ZWOWDdj = BaWQFeqByxwN;
        voPdp = ! ZWOWDdj;
    }

    if (zXtArM == string("uUYjvwkrHotuAlOBUNWNSJathkVOPjfubZUiuviNeDWVOMnBpOVnQQiZUrWrBPGxfnlKRaBuLuPCFmqAzbvNzUpkFZSvgAcrUXSjvYykPrvCIhZMTykNgzBENct")) {
        for (int GrXtlFJYkjs = 1816521194; GrXtlFJYkjs > 0; GrXtlFJYkjs--) {
            continue;
        }
    }

    return -1880310822;
}

void ciVuBnCxOfiItJgr::PVmFbZwimhirC(double wyANEenQ)
{
    bool eMZUOQtedcXRla = true;
    double UDxzcFGESoYkMeBg = 930171.5852618413;
    double EkdnKc = 774360.2628185004;
    double DoLrVU = 758330.4872311874;

    for (int QOYuIYeZ = 1257793612; QOYuIYeZ > 0; QOYuIYeZ--) {
        wyANEenQ = EkdnKc;
        DoLrVU -= UDxzcFGESoYkMeBg;
        UDxzcFGESoYkMeBg *= EkdnKc;
    }

    if (wyANEenQ <= 758330.4872311874) {
        for (int LOeldzFrVALPhmq = 362408020; LOeldzFrVALPhmq > 0; LOeldzFrVALPhmq--) {
            DoLrVU += wyANEenQ;
        }
    }
}

void ciVuBnCxOfiItJgr::jrrfJnUlhOvJUv()
{
    bool vpUjB = true;
    bool OvbqgjPAaTZuyXPb = true;
    double YNIWVv = -558865.2292421303;
    double omISnXNjPh = 305559.44559872255;
    string NTsSG = string("sbbtkAOgjctowSadJZnvqYyUYfssmKRLzugZoNFPgiPRLtjovVvlpbbNaqoNcupYSvFDPycFYbtzJmGuXtSFpSQzhFUyQkIlBIstIYgyBBNXyXAgyEqyfQakMIzXGKSSuGRKabpWwKmwuauHvyZwvPXIRaZTr");
    double WnaOvGYhRN = 344099.8790256337;
    bool PxjRo = false;

    for (int uSuzgAad = 1733646352; uSuzgAad > 0; uSuzgAad--) {
        omISnXNjPh -= omISnXNjPh;
        YNIWVv /= YNIWVv;
        omISnXNjPh *= omISnXNjPh;
    }

    if (omISnXNjPh <= 344099.8790256337) {
        for (int ELSULTSKlpBS = 1688211131; ELSULTSKlpBS > 0; ELSULTSKlpBS--) {
            PxjRo = ! OvbqgjPAaTZuyXPb;
            WnaOvGYhRN /= omISnXNjPh;
        }
    }

    if (PxjRo == true) {
        for (int rmFjXvnLdjK = 673893591; rmFjXvnLdjK > 0; rmFjXvnLdjK--) {
            continue;
        }
    }
}

ciVuBnCxOfiItJgr::ciVuBnCxOfiItJgr()
{
    this->FvCjMHPRh();
    this->oAGsI(927176.4306435274, false, false);
    this->YGAUTNc(-203519493, -378849277, -1842810551);
    this->plahewgT(string("uUYjvwkrHotuAlOBUNWNSJathkVOPjfubZUiuviNeDWVOMnBpOVnQQiZUrWrBPGxfnlKRaBuLuPCFmqAzbvNzUpkFZSvgAcrUXSjvYykPrvCIhZMTykNgzBENct"), true);
    this->PVmFbZwimhirC(219803.34629487703);
    this->jrrfJnUlhOvJUv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gwdUXVXoQIYH
{
public:
    bool fGKRvYNswSX;
    bool ovsUDKbmptTN;
    bool QnLqAFFmDy;
    int XIkvCUr;
    int iHaHEakwpjDTTc;
    string RfNtPhafqf;

    gwdUXVXoQIYH();
    double KbjVY(string cksJVOxS, int aVTOd, bool mHAIj, int KgLklcLmsCwRCT);
    void vXvUbh(double DbsrNpDUsrdbaP);
    double ZwmRt(string vPklBUkPHnbJr);
    string kssdVAkCc();
    string dnFEh(string LcyljvJUaNWw, bool OMLazW, string toIBb, bool ibevQycwv, double LIlHvWBPJbVsv);
    string gESstDH(double fdUNGSiRUqHfUvC);
protected:
    double VYKGvtolLblg;
    double TwQQhXU;
    int aCpFHSLAyxrVQ;

    bool EcnVngRckMLJG();
    double FGGVIGIdStXj(int PHOAikXu, int xMnHSTTXKqWcM, bool YspBSNboU, string CpIUUWuwn, bool EaSVzE);
    double czHpAMLXq(int lSvYgzkKBxoVar, double gGaJMWXJsU);
    int lbDatwp(bool OwzDG, string rfwGKOcMXL, int xDrWtWpJUvsalHFs, int HBGampSzKvZgtmjz);
    double cGSVmMhfy(int JAFeqfc);
    string yjApMSWwK(int RzczprRh, bool qZAZaIBVPaI, string QysgxhBe, int pojstZ);
    string cRSSiqRyQaw(int rpCbpKTh);
private:
    bool mSEIsQlPhdNOUUj;
    int YXkDPIRwoTWMqjT;
    bool RYIudpuOg;

    double ZjcXv(string fyuJclNVUprrDqgE, string eAlEaxPPHDvhczR);
    double esQBHu(string JdUOukcQSYZtcv, bool MbHbzbx, string WAVNvz);
    bool tKdGGaNordSZNvn(double itLxvyZfKWYMGeg, string UXeFAVMeoUjCoX, int ynOwQWSrRkJ);
    bool XFZPlkSRDwNv(int eblTNibJGae);
};

double gwdUXVXoQIYH::KbjVY(string cksJVOxS, int aVTOd, bool mHAIj, int KgLklcLmsCwRCT)
{
    string BZGrSSsDsfrNEQ = string("yKlQeTQjaPvxkKGhUsJKGvNFODpKSpmAXxbBuHhryISzronWxheRsbuZvcRdANuMmOcdmzvOfuKLHYQZwczdwaZDZLjRDhGnQYbqsrzaLMvXLSQNtzjoCEhoePdnknkiwpwXWFPbqvqclIZE");

    for (int hRBZBHMBiF = 1744357599; hRBZBHMBiF > 0; hRBZBHMBiF--) {
        mHAIj = ! mHAIj;
        cksJVOxS = BZGrSSsDsfrNEQ;
    }

    if (BZGrSSsDsfrNEQ > string("JAFarwxvhcOuowQyOGtVCFzDFMxtMHgGDDltkodwHQfnrHWDJVZAZmxcaxcnWtjBpBZpsiYbjUFWyQIJsLbfOwPHCKqYHTEGNXzcOFojBiWwBRqCgbtBgRayFRxpAIHCgTeouAmHplNdafCYAojbKDxdclMdUmKGzxdEqEEhCfotUSleutzhhImSZAMuaDtTIsTaTqDZaFHqDKnGFoPU")) {
        for (int BPGUSuvmuGcTJNtV = 1377221584; BPGUSuvmuGcTJNtV > 0; BPGUSuvmuGcTJNtV--) {
            BZGrSSsDsfrNEQ = BZGrSSsDsfrNEQ;
            KgLklcLmsCwRCT += KgLklcLmsCwRCT;
            KgLklcLmsCwRCT -= aVTOd;
        }
    }

    return -999978.9475609076;
}

void gwdUXVXoQIYH::vXvUbh(double DbsrNpDUsrdbaP)
{
    double yjjEO = 548411.4155849637;
    bool XazqIGlbVyTtfRR = true;

    for (int VqhFamqEniMCXI = 51606746; VqhFamqEniMCXI > 0; VqhFamqEniMCXI--) {
        yjjEO = yjjEO;
        yjjEO /= yjjEO;
        DbsrNpDUsrdbaP /= DbsrNpDUsrdbaP;
        yjjEO *= yjjEO;
    }

    for (int AUSrbEohXSfetJvD = 1216385747; AUSrbEohXSfetJvD > 0; AUSrbEohXSfetJvD--) {
        DbsrNpDUsrdbaP *= DbsrNpDUsrdbaP;
        DbsrNpDUsrdbaP /= yjjEO;
        yjjEO *= yjjEO;
        yjjEO += DbsrNpDUsrdbaP;
    }

    if (XazqIGlbVyTtfRR != true) {
        for (int ASCzEd = 1346073164; ASCzEd > 0; ASCzEd--) {
            yjjEO = DbsrNpDUsrdbaP;
            DbsrNpDUsrdbaP -= DbsrNpDUsrdbaP;
        }
    }

    if (yjjEO <= 548411.4155849637) {
        for (int tSedFo = 1174274398; tSedFo > 0; tSedFo--) {
            yjjEO *= yjjEO;
            DbsrNpDUsrdbaP *= DbsrNpDUsrdbaP;
            XazqIGlbVyTtfRR = ! XazqIGlbVyTtfRR;
        }
    }

    if (yjjEO < 548411.4155849637) {
        for (int MbkDjXd = 1585613408; MbkDjXd > 0; MbkDjXd--) {
            DbsrNpDUsrdbaP += yjjEO;
            DbsrNpDUsrdbaP *= yjjEO;
        }
    }
}

double gwdUXVXoQIYH::ZwmRt(string vPklBUkPHnbJr)
{
    bool bYYIdPQISI = true;
    string FdjyTYlEkFz = string("FjlxSttBvXzJigEdoKtuoMParEfFbtelMBHQlvmAgOsopAsKlSciwhjHQlljZtbsgDfOPZCXzJyWfyZZQmxWMphyRyeAqlrQAaEXKUgFsMOUfIOxozXzDfDyarJJNrLinyUTnvxXprqWaXszsihabtMoqfmNrXeAUJiqhcsdJFSFjsngxZsZDfEbJJJrkmBZIPIehJYQxfIQccHdWslegugFNFGHHvEixyoUaKqYYFumHhOuhaOdQ");
    string qopXnGciTUEeYg = string("pzqgZCiyISuQueAjUbAGkBLVSgUmfqgFkTpTfQZynAjVFQi");
    string diYpoEc = string("mtFNNVsNAiHlffaVNnMWfIaaNgezHJqBOzsMWyrEDZysZwqysxzesBuqbqKcKYiLdqKlNUONmllaIdoBzvMaIOjvsJVNGkVnoLoBLLnIqkgFDfMnkCUmkNahMoZyIrMuuYGbrVSsDrVsOqVeIKetPHnNNvguPkuirxPZdNGuyOuLsYJEoNjMOeOrhduClztUuIrZfOssIdFyIpGfyxYDOqOdIcghmfGYfxJkaeWGdxADMResZXgfMCVCGQBzCHX");
    double IJjWAZbf = 665067.7957454794;
    bool TPOwJXBAGNJQrF = false;
    string aLewtjU = string("OnKsUADsSRiwGwWXJJtlNBXduGjQKooRGFIDohpkxYdUEprlpJuvmmhjGObmupoUBoBiIJeMGdLLQBFGZiERlDwQMiwUiKPYSHNXQcGYtjEAmPPbJHlpXBAOABxtvHSLtCxGVoGMVkRUAgLOKAejs");

    for (int MAPugAmk = 1208396719; MAPugAmk > 0; MAPugAmk--) {
        TPOwJXBAGNJQrF = ! bYYIdPQISI;
        diYpoEc = FdjyTYlEkFz;
    }

    return IJjWAZbf;
}

string gwdUXVXoQIYH::kssdVAkCc()
{
    double fHsIWXy = 266969.4244041568;
    double MhDZbWj = -797139.7043026843;
    int QITNakL = -2095626157;

    for (int YOYLwzfzjIEXl = 1846373414; YOYLwzfzjIEXl > 0; YOYLwzfzjIEXl--) {
        MhDZbWj -= fHsIWXy;
        QITNakL -= QITNakL;
        MhDZbWj += fHsIWXy;
        fHsIWXy += fHsIWXy;
        fHsIWXy += MhDZbWj;
    }

    for (int tFAFEN = 629789502; tFAFEN > 0; tFAFEN--) {
        MhDZbWj += MhDZbWj;
        MhDZbWj = fHsIWXy;
        MhDZbWj /= fHsIWXy;
        MhDZbWj *= fHsIWXy;
        MhDZbWj -= fHsIWXy;
    }

    return string("LxjsIqAJlDGXgnbmveVuMAuyJOvkKgNCIOHjSSdnmykjmtJeasMZzfwaMduUofyJpwvZjbxjkPltoOOqkgEoDLSkCXBQyNIttLeypUtEDmmYLWdHHsjFWsdpVfDPLlBJsWLbOyrZspuFtuighMLncFHxmhrVSakKqxQ");
}

string gwdUXVXoQIYH::dnFEh(string LcyljvJUaNWw, bool OMLazW, string toIBb, bool ibevQycwv, double LIlHvWBPJbVsv)
{
    int GaaCkJErmUo = -228690747;
    int UauBETX = -1413598374;
    bool lJlzhtSN = true;
    double RiiVFN = 457350.5400277953;
    string QUUptmeus = string("cfrNcgvqrhuNSrXctbLwXvGHFwHhkgMzkRKOkiecyetJhoWnqFqXGrDeOYotvNh");
    bool HFUiAkJPvM = false;
    int YPRANEKWUZAQdQBa = -1144806347;
    double DJPuTKLUgW = 831008.0353582856;
    int RzfZSWV = 1011962015;

    for (int iIeYET = 50050808; iIeYET > 0; iIeYET--) {
        HFUiAkJPvM = OMLazW;
        lJlzhtSN = lJlzhtSN;
    }

    return QUUptmeus;
}

string gwdUXVXoQIYH::gESstDH(double fdUNGSiRUqHfUvC)
{
    string CQPIcsSQFym = string("OzwYXddEcwQXVClxMICXadxwpCsSlJYILIVbVCOePEXvWSbGIkPsYrztSJyxOBQEuoldbktcMKUwcVlGAZbYDzIWrUjfKTVJfRywQUcDvySUHkfTAyDBtKOdkKpzoJQusrVKWgr");
    bool vhGgFfYc = false;

    return CQPIcsSQFym;
}

bool gwdUXVXoQIYH::EcnVngRckMLJG()
{
    double brjeEu = -1023547.2715085464;
    string CBrfyJee = string("LxltZTIIeQfvdKiAdVrsEbdzvzMwnVaTZBbHvPhFlAXkcncgxAXIfLEQDueBzIIChAgtrZEybwCvqeoNtxyVSRLgDEu");
    int GMkJQ = -98851750;
    int yboWwLKxHze = -1003108528;
    int dUSuWzGwRy = 309205559;

    if (CBrfyJee > string("LxltZTIIeQfvdKiAdVrsEbdzvzMwnVaTZBbHvPhFlAXkcncgxAXIfLEQDueBzIIChAgtrZEybwCvqeoNtxyVSRLgDEu")) {
        for (int aAjOKFFN = 901016421; aAjOKFFN > 0; aAjOKFFN--) {
            yboWwLKxHze += dUSuWzGwRy;
            brjeEu = brjeEu;
        }
    }

    for (int nhfiNMPxY = 501445937; nhfiNMPxY > 0; nhfiNMPxY--) {
        dUSuWzGwRy -= dUSuWzGwRy;
    }

    if (GMkJQ >= -98851750) {
        for (int JVQFJCY = 503052205; JVQFJCY > 0; JVQFJCY--) {
            yboWwLKxHze += GMkJQ;
            yboWwLKxHze -= GMkJQ;
            GMkJQ -= dUSuWzGwRy;
            GMkJQ /= GMkJQ;
        }
    }

    if (dUSuWzGwRy < 309205559) {
        for (int LBVuaWwlmu = 1491797896; LBVuaWwlmu > 0; LBVuaWwlmu--) {
            yboWwLKxHze *= dUSuWzGwRy;
            yboWwLKxHze -= dUSuWzGwRy;
            dUSuWzGwRy += yboWwLKxHze;
        }
    }

    return true;
}

double gwdUXVXoQIYH::FGGVIGIdStXj(int PHOAikXu, int xMnHSTTXKqWcM, bool YspBSNboU, string CpIUUWuwn, bool EaSVzE)
{
    string XhScb = string("pZUoxqxjAVybXNztxwtVuuaZjDgQCkSKoesSZrnYouFHByBSWXmMcxPiGgSeQfzmaKvDKunVoUebqSZcahOPldliVpGQvNzQhQqZhZqJhzTCZqIKHxkNRTlvUZWgKqGhhghhttnKhZdpwFaTGJRBOnqWPblZGBjeJJAIaOWIlCiCmPsKoVkSmxRfGNPRmGfdfuaWReWlnUImJoVgbMYlms");
    int KRxYfAqoj = -1488416324;
    string bpKUSKov = string("ZRujCZzaPMfxhLznHSWznhVRaDVBNeWtuanJmrocRCZRhOMTIzlZTSwBsBqTEyJDrDrSQOxKGqgcYCjtkuwmfbXSHvyIZHjGFSorkagpFvDEpaDNKnDxuvrZiFiDhqMCUDPnKxQomEJXtNmYLCmrgAAPYdrgIbvaWVlqLZgYWTeNAZvhsxDdwtyLyabUTqaCDLShO");
    string SXDnSRUPqJvOxabw = string("fcskQMbIqSygvIkRcOonyqZccySuTQdkhedfjTHoLDCdpvxJnUJUdfntlXoDpcGFLaIJkrpvWVsArfIzqUYYAfXZjBkicPchcQUkzmgAnHOuYZRLVslQBwixPWtiVMczLyKssJ");
    int mYYXcsbDBjiZI = 778194470;
    double huKwtW = 718770.9031135136;
    double frSIMUW = -888251.0705604842;
    int ggZUyUhFiwVg = -1381140833;
    bool zPZKWym = false;

    for (int UGBdEgMZxHfXniQK = 1157526907; UGBdEgMZxHfXniQK > 0; UGBdEgMZxHfXniQK--) {
        ggZUyUhFiwVg /= ggZUyUhFiwVg;
    }

    for (int EnwYEeVsopCvVY = 884726049; EnwYEeVsopCvVY > 0; EnwYEeVsopCvVY--) {
        SXDnSRUPqJvOxabw = SXDnSRUPqJvOxabw;
        ggZUyUhFiwVg /= mYYXcsbDBjiZI;
        xMnHSTTXKqWcM -= PHOAikXu;
        PHOAikXu -= KRxYfAqoj;
    }

    return frSIMUW;
}

double gwdUXVXoQIYH::czHpAMLXq(int lSvYgzkKBxoVar, double gGaJMWXJsU)
{
    string VRdsQJxoHtty = string("QVehdzmfMuxKOmprNPpXCJGXhysiiNSzXEGUeoYVDjkwWZAKRzzxCFzJPfifeJwJArLwTzXyWsSotfoYVENADEKMjflGOQzIwRIKOpjyVSFfHtTpiKqsNKyhCOLeBxxgfswCiChFFisrFFktNoUOhdgaLBDxpDKuDoJtwNEKMlPnTtfb");
    int zoFxEcxsr = -910300191;
    bool IIqZi = true;
    string KLnPXuyjh = string("wCvqqATlNlUrUDxThzxFNRcljCsRfAtIvXjSLiBODwryzjAEXzmefEBOhHgBJyxYjMiiapgAAzvzNpxUkwJnTGPyCCdfSMRrwtAdWEpvGAqi");
    double WtTpLAaHfgeC = 187521.50179713807;
    double NcEAmJmxw = -311965.84969680925;
    string VYJQdPPke = string("mxQtbXmdqvVgydPgJWrjHGnbxavmtruurVUUSxQQRHNNIzsjquKYBKcZksaWbOJEvfaaKzgIIfhydknRfyNOyaMjVCAcwjIdfqjlfyFBDBfMLGxuqjGQUPdFwVqWYqJWkwgUxzRqhgigLkuoqvJKHBLAEZVrxJfAqMIrlrNlOnULreeCPWsgyNWTSRWVjPFbtOSECGqySmwmAHzltqMUhAqbWqE");

    for (int UOAawFxzwYKRdMN = 676169885; UOAawFxzwYKRdMN > 0; UOAawFxzwYKRdMN--) {
        continue;
    }

    return NcEAmJmxw;
}

int gwdUXVXoQIYH::lbDatwp(bool OwzDG, string rfwGKOcMXL, int xDrWtWpJUvsalHFs, int HBGampSzKvZgtmjz)
{
    double ziLFueVCVuYEHn = -155567.33599860643;
    double DKzMbXmf = -928398.8243092936;
    int UXWrLVuBViiK = -2136581167;

    for (int XOmwfQIzrGcAzTdY = 319098256; XOmwfQIzrGcAzTdY > 0; XOmwfQIzrGcAzTdY--) {
        HBGampSzKvZgtmjz += xDrWtWpJUvsalHFs;
        ziLFueVCVuYEHn += ziLFueVCVuYEHn;
        xDrWtWpJUvsalHFs = xDrWtWpJUvsalHFs;
    }

    for (int bThjcKxGdYImMyq = 1928547773; bThjcKxGdYImMyq > 0; bThjcKxGdYImMyq--) {
        HBGampSzKvZgtmjz *= HBGampSzKvZgtmjz;
    }

    return UXWrLVuBViiK;
}

double gwdUXVXoQIYH::cGSVmMhfy(int JAFeqfc)
{
    string FroPsKDme = string("GzHfxsvqVVSWPKXrphekjMUpgtoEBbxsxbGDIDWwKizFMCd");
    bool RWCBIYnfjHm = false;
    string CgAcvvL = string("kJuOiyHSLSmZVdBguCJXKuRelMIjpEuZqabinVXMhOmJNByTPZqsqclrJlkGJP");

    for (int WUlMAUNZqw = 148337423; WUlMAUNZqw > 0; WUlMAUNZqw--) {
        FroPsKDme += FroPsKDme;
        CgAcvvL = FroPsKDme;
        CgAcvvL += FroPsKDme;
        CgAcvvL += FroPsKDme;
    }

    if (FroPsKDme < string("kJuOiyHSLSmZVdBguCJXKuRelMIjpEuZqabinVXMhOmJNByTPZqsqclrJlkGJP")) {
        for (int dreIKwzS = 1198605817; dreIKwzS > 0; dreIKwzS--) {
            JAFeqfc += JAFeqfc;
            RWCBIYnfjHm = RWCBIYnfjHm;
            CgAcvvL += CgAcvvL;
        }
    }

    for (int RVHqQAEEuZVSSQUM = 224187827; RVHqQAEEuZVSSQUM > 0; RVHqQAEEuZVSSQUM--) {
        FroPsKDme = CgAcvvL;
        FroPsKDme = FroPsKDme;
        FroPsKDme = FroPsKDme;
    }

    for (int BZoztavobZGk = 1335532047; BZoztavobZGk > 0; BZoztavobZGk--) {
        FroPsKDme += CgAcvvL;
    }

    for (int JBsIxejHDPof = 1619709508; JBsIxejHDPof > 0; JBsIxejHDPof--) {
        FroPsKDme = FroPsKDme;
        CgAcvvL = FroPsKDme;
    }

    return -1032430.8837695784;
}

string gwdUXVXoQIYH::yjApMSWwK(int RzczprRh, bool qZAZaIBVPaI, string QysgxhBe, int pojstZ)
{
    int jwJzkFijxQ = -895423793;
    int yQSiwKSv = -1458901956;
    double DGayYkHVRanMy = 280484.25225405203;
    double AItLiSHwJG = -32861.53445751702;
    string wrtUBDqihNEse = string("RKaNOyMjRtiBazXjQiHrJQkWoSDHjYcQQuLjGwEdUvCYvF");
    int SKFeRJsBRimby = -2087857296;
    bool uYDHsNs = true;
    double LqzieIBn = 347059.7057128302;

    for (int ZVbWj = 2063354253; ZVbWj > 0; ZVbWj--) {
        SKFeRJsBRimby += yQSiwKSv;
        pojstZ /= jwJzkFijxQ;
    }

    if (QysgxhBe >= string("RKaNOyMjRtiBazXjQiHrJQkWoSDHjYcQQuLjGwEdUvCYvF")) {
        for (int JUVRaZDWjlglHa = 991796070; JUVRaZDWjlglHa > 0; JUVRaZDWjlglHa--) {
            RzczprRh = jwJzkFijxQ;
            wrtUBDqihNEse += wrtUBDqihNEse;
            RzczprRh *= pojstZ;
        }
    }

    return wrtUBDqihNEse;
}

string gwdUXVXoQIYH::cRSSiqRyQaw(int rpCbpKTh)
{
    string DMWerRE = string("hrqpwvbYwEMQRrBuuvbaDTAVJXeLNtexbUZtvfVapqJUozbUApirhxYhyhWx");
    double DKfoOGHvRQbMSmP = -501183.0433772496;
    double uPaVUsufXbFU = -776418.5077684808;
    string SdPrVW = string("DxnqkzcfXvIzMQjlCdWGqHvPdzcSpVNQTDNMxXWcIbTmewQMdFIMGUNUzhejTdmXgcydBtEbdLJNGiWMRndSBcYQbCZDorpheSHrlAskrvIcmbUxRnDUhOyEILnLexjqdztWUPdTskBtFAmQXajSwOTImUkCXLHDXQbpBZmjbxfgnKY");
    string XfXGAEAKPRfBi = string("ivmyhaXsZAqXnserakmXiwpLvgz");
    bool JawgSZ = true;
    string zPEcWN = string("wlYbZoLYAbELtgkQqTgGgFEuzvMqVRInVHzyiLQfVeKhAzunCunFRSKHPDQllxHYvsyCaWoXhVwflkRXmavHXekrNdeSdsmpqwtgQzsHZGdxuClbkwXdNaumrWHobEwg");
    string YYBrJTWacPjbauF = string("hrdVdTKAsntDBjNwTzYsUcqjRNWoBCSoIxaXOBHPCIesqcnZIlZxLEyTTwqHjWyHzgDxhQBHsKouUNvRvDoFFWOwlOJnlHxALWQwCMfkFgztRyubkgqPoocVijSMdNSmlsUYadgUUPkbeoUdedoRREQthSJcuqgxLJUqZCzQdPpQMjUrwmaI");
    double ULWNGPrYLo = 554458.241487664;
    double OUWaVMd = 1007757.9779316691;

    if (DMWerRE >= string("wlYbZoLYAbELtgkQqTgGgFEuzvMqVRInVHzyiLQfVeKhAzunCunFRSKHPDQllxHYvsyCaWoXhVwflkRXmavHXekrNdeSdsmpqwtgQzsHZGdxuClbkwXdNaumrWHobEwg")) {
        for (int wCvYIHsUM = 1774228795; wCvYIHsUM > 0; wCvYIHsUM--) {
            SdPrVW = zPEcWN;
        }
    }

    if (SdPrVW < string("wlYbZoLYAbELtgkQqTgGgFEuzvMqVRInVHzyiLQfVeKhAzunCunFRSKHPDQllxHYvsyCaWoXhVwflkRXmavHXekrNdeSdsmpqwtgQzsHZGdxuClbkwXdNaumrWHobEwg")) {
        for (int dWIaaPNfswVlFIy = 571940650; dWIaaPNfswVlFIy > 0; dWIaaPNfswVlFIy--) {
            uPaVUsufXbFU -= OUWaVMd;
        }
    }

    if (uPaVUsufXbFU >= -501183.0433772496) {
        for (int wwxUhBQJhvLCWn = 1495936931; wwxUhBQJhvLCWn > 0; wwxUhBQJhvLCWn--) {
            continue;
        }
    }

    return YYBrJTWacPjbauF;
}

double gwdUXVXoQIYH::ZjcXv(string fyuJclNVUprrDqgE, string eAlEaxPPHDvhczR)
{
    double JzeGAeX = -439170.13285112206;
    string mkKfDBncrIHOJ = string("KMDZTHOsryZUsEDlyRWfEfWdwsqDnSsFNeGSIcEGDsYOVcRtIoVAjrkWZwM");

    for (int HLftXgXjzppU = 402338932; HLftXgXjzppU > 0; HLftXgXjzppU--) {
        JzeGAeX -= JzeGAeX;
        mkKfDBncrIHOJ = fyuJclNVUprrDqgE;
        fyuJclNVUprrDqgE += eAlEaxPPHDvhczR;
    }

    return JzeGAeX;
}

double gwdUXVXoQIYH::esQBHu(string JdUOukcQSYZtcv, bool MbHbzbx, string WAVNvz)
{
    double eYRHDl = -327853.6807341136;
    string JGWSBeJ = string("PbCyJOCutnGxwZVAANzvJPUDjSQUgAlewJgFdODNRgEJxNGGiJYYbgULwvDWuLIBBtNuyEiGZgzrIVEtinZpDGcEwIitQrrnDdpOWagntblNZsEVmyByeMMviReTjMOEXOSGzxJfXcuKxdoyUYGioxLrWAhlrsEgXkBShjQupBsWNfNFlYnniSmNaJGSpcTxvXIdTLemimzaoLsJPmdZohhGPJEB");

    return eYRHDl;
}

bool gwdUXVXoQIYH::tKdGGaNordSZNvn(double itLxvyZfKWYMGeg, string UXeFAVMeoUjCoX, int ynOwQWSrRkJ)
{
    int nWFDZDelPdIZctwu = -468466863;
    int uiemDjGl = -433151802;
    string qmrZXhTi = string("oBTFRAZsGpsCoEChnCYpLrHrZttbeygBLyFhlOouqbaCALxad");
    int gfcQSRCIsDE = -1644519760;

    for (int zcvQYcfbYU = 1698799083; zcvQYcfbYU > 0; zcvQYcfbYU--) {
        ynOwQWSrRkJ /= uiemDjGl;
        uiemDjGl = uiemDjGl;
    }

    for (int NPMcwfocSQS = 494380835; NPMcwfocSQS > 0; NPMcwfocSQS--) {
        uiemDjGl += ynOwQWSrRkJ;
    }

    for (int HneqYvCqUxJWaUk = 2099148809; HneqYvCqUxJWaUk > 0; HneqYvCqUxJWaUk--) {
        nWFDZDelPdIZctwu += nWFDZDelPdIZctwu;
    }

    for (int JWZhkTbmLEcsKGCh = 594887819; JWZhkTbmLEcsKGCh > 0; JWZhkTbmLEcsKGCh--) {
        itLxvyZfKWYMGeg *= itLxvyZfKWYMGeg;
        qmrZXhTi += UXeFAVMeoUjCoX;
    }

    for (int vXPgoCqozKayryPN = 395981265; vXPgoCqozKayryPN > 0; vXPgoCqozKayryPN--) {
        nWFDZDelPdIZctwu = nWFDZDelPdIZctwu;
        UXeFAVMeoUjCoX = qmrZXhTi;
        itLxvyZfKWYMGeg -= itLxvyZfKWYMGeg;
        uiemDjGl /= nWFDZDelPdIZctwu;
    }

    return true;
}

bool gwdUXVXoQIYH::XFZPlkSRDwNv(int eblTNibJGae)
{
    string SnEuWTkPVmkghce = string("PcGsiRbImnGfBsLklXNSgfRHmBCDHgOfQKbRhDAmHzaRMdvGkMaNJJGFsCcBR");
    string ZHiPzT = string("swzURUJnkWfWdRglgksbqAvMLFfmvHgxOtwMTgNgZdAiAVVCVZBlioEklBuNHGP");
    string lHBfFq = string("FzvmOTXmjTClYSmdLFykLicKgXXTpSxsWQDXsXwKMSaKtOYRgxuTWIvleUymdvTDYKBxXbAqvSsf");
    double ENagxbSqB = -1045227.5608731436;

    if (ZHiPzT < string("swzURUJnkWfWdRglgksbqAvMLFfmvHgxOtwMTgNgZdAiAVVCVZBlioEklBuNHGP")) {
        for (int GitExSNpmQOE = 186589780; GitExSNpmQOE > 0; GitExSNpmQOE--) {
            SnEuWTkPVmkghce = lHBfFq;
            SnEuWTkPVmkghce += ZHiPzT;
            ENagxbSqB += ENagxbSqB;
        }
    }

    if (lHBfFq >= string("swzURUJnkWfWdRglgksbqAvMLFfmvHgxOtwMTgNgZdAiAVVCVZBlioEklBuNHGP")) {
        for (int FrfOh = 1655742736; FrfOh > 0; FrfOh--) {
            SnEuWTkPVmkghce += SnEuWTkPVmkghce;
            lHBfFq = lHBfFq;
            lHBfFq += ZHiPzT;
            ENagxbSqB -= ENagxbSqB;
        }
    }

    for (int PQlKq = 1061382854; PQlKq > 0; PQlKq--) {
        continue;
    }

    for (int rTFYrNwjpbbV = 1824276009; rTFYrNwjpbbV > 0; rTFYrNwjpbbV--) {
        continue;
    }

    return false;
}

gwdUXVXoQIYH::gwdUXVXoQIYH()
{
    this->KbjVY(string("JAFarwxvhcOuowQyOGtVCFzDFMxtMHgGDDltkodwHQfnrHWDJVZAZmxcaxcnWtjBpBZpsiYbjUFWyQIJsLbfOwPHCKqYHTEGNXzcOFojBiWwBRqCgbtBgRayFRxpAIHCgTeouAmHplNdafCYAojbKDxdclMdUmKGzxdEqEEhCfotUSleutzhhImSZAMuaDtTIsTaTqDZaFHqDKnGFoPU"), 167906283, true, -2087080468);
    this->vXvUbh(-104447.56624588101);
    this->ZwmRt(string("vwzTeISQhdquBOYoVGIdNaEfGhGBLGteeLKOfHyXItbxkfwebwJjEEpsOIeCTFNUAAWtbrvMuTAM"));
    this->kssdVAkCc();
    this->dnFEh(string("nnhYZeOqOcofuqcLnVqiCSVMlStmZdXfUcxDpUPrhNJiEWBkUiu"), false, string("ItdWjGctaKppzGmHOkXAutkShyDLbDqvvGFEimMApkgntAUNUFpMxIFzhckbs"), true, -663747.3031858408);
    this->gESstDH(-786513.0945145283);
    this->EcnVngRckMLJG();
    this->FGGVIGIdStXj(-128438224, 1118990560, false, string("SWDItbRTHlyKvzTikgYJiFBpBdNqfZBnFuxBYpCRXSFAwlUGgUMebGqQTiHuoQpNkcSRrnoDszISlSfYiwieyScrlqWaUqTCDbNxVVAprdnAHErWlUOgQQnziYisTAfopYQjsNmCMTddbTiEgdMLKiCwUPSHqxgXXxZsTsPKYNpSIiCnXPUoHYKCXgRIOsHdGHFbIR"), true);
    this->czHpAMLXq(1480424508, 672881.4676914809);
    this->lbDatwp(true, string("vjstInEiQcORSwPTUgpWByjgqzqMoGsGdyEyJfjxAaTKBJwpCztCvhXglBTlHMTIewUFuqXJePaUabVkIplttMWqefzOSIwXWSzdRRyzHcaQoaKnHsaxHrBfBKIWzOfGZLewZrskOoMoKAKbyCZBRaKOlsPPTrwglLryQVJHyl"), -754959557, -624647767);
    this->cGSVmMhfy(509344372);
    this->yjApMSWwK(-456189337, true, string("ixrLgPoZTTUIYfjcgYRvzRATDLopiNDqYNmHwUenpIeRBMqzjeKlLLadoxKYUsCbfxowXBjqpsoKJGUgKBICVBZHEFAWptQsMZrtqPngoLMzxVXRMbkj"), 1241846551);
    this->cRSSiqRyQaw(-1044505077);
    this->ZjcXv(string("XUGlRDFWpiWmUFDjSbZqluqoTvqylBaMmXJOmlKFAYWoIrcmwdViikTWZOfrykqjlnFCIrKPIzMDnggtEbJEyIzjeaygpjUNmpLSbtutSNRtTkNajOtTjebwPrKuSJATHcNvmmRIqRwTevvApIzfAVpiCyZRHSeISMNXUWzwtTgbWKIhqmlsWjojcJXlJTawRUgnpTspCFRUsKQlFyeYzabyziNFRT"), string("FoJbcGSKxIndNJRZiZyFBJCXgwhYBFlLJrFztpVrtvgzysZMGKRmLaGPx"));
    this->esQBHu(string("eiBFxeyDtgHdMzVEWxNzdFEKDAcCfAlOICkJJRFgKDLeCAacbcNsUyviFMNnwHgFkatOuNesOLwNpkiSgxvIYvglqhtegMWTZSrWzEBVCWDym"), false, string("lwmFuUWsBnBVLNtgCSJsOxLWbnkkxuNVScCQomvMMTyFjsNsMzXkcAEueGVzXFyNjWMTtCNRIFgteOufrRJrdyrcmXyGZYwEoOEVHwrlUbQNHKMiNPQGIwLToyuQVFTkrWc"));
    this->tKdGGaNordSZNvn(-588960.9015606933, string("XbRMNiAVMqroNix"), 920936296);
    this->XFZPlkSRDwNv(-968359201);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zmjHzbYrodh
{
public:
    double jIHGFszjcmVSs;
    bool JcMCYI;
    string GoNuYdfRJqeW;
    string RdLsHRjHTTjWF;
    string pZGpAkHjR;

    zmjHzbYrodh();
    bool EWvPoFqrdNKxQb();
    double vHNFqfqTxH(string TzHuBpLVfLLhk, double JnrhcRRyjjQokaD, int UTUNRrVtuUhr, int qFUdlHludFtZjw, bool OgQjaID);
    string nmjxLYt(int HShQDbPkxeJ, bool aoMmSYlthRNoHZ, double AGNnKIoyGf);
    bool mFOcxGUFm(bool WuXSPCzDzfLLB, int vccWotjGipuOKW);
    double MBZkqI(string lXntqAucRWHj);
    void AvVUfvhIr(double dzcGYFlfeukb, bool xfFGeTV);
protected:
    double NeoyytffedHTxze;
    double zpfuxcVBV;

private:
    bool sxknqpcBb;

    int FluHSIL(string XkxRnROweRytAK, double nTKAPmvlmNjT, string NKNiNqjkKDZbc, string vTdXDB, int CUTkjZpHvmh);
    int JoAotOA(double QwxOEudPGNWo, int yBpjy, bool PWaZY, bool reCQhCXQmus);
    bool RGAqWYX(int HjQjjVGRFLRYCyS, double YysJbpWCjYFs, string SuXfeAGOqMyHUhg, double iptGXg, bool QuuYbHeJaxAPIp);
    double xKcBCA();
    int FFzCkLvVmB(string tegenKFKFm, string rNlFkfMsXS, string DLuBfAC);
};

bool zmjHzbYrodh::EWvPoFqrdNKxQb()
{
    bool jqmfSNrHY = false;
    bool gtpgiRMpNsdbrG = true;
    int XLwytcxPrO = 393162966;
    bool tirXPhsLVkTs = true;
    int YSScFDGDJrczQ = 2106045231;

    if (jqmfSNrHY != true) {
        for (int coSRQTRZPYXQqv = 1532159400; coSRQTRZPYXQqv > 0; coSRQTRZPYXQqv--) {
            jqmfSNrHY = ! jqmfSNrHY;
            XLwytcxPrO += XLwytcxPrO;
            jqmfSNrHY = jqmfSNrHY;
            YSScFDGDJrczQ *= YSScFDGDJrczQ;
            YSScFDGDJrczQ *= XLwytcxPrO;
            YSScFDGDJrczQ -= XLwytcxPrO;
        }
    }

    for (int PSYkM = 2084473585; PSYkM > 0; PSYkM--) {
        tirXPhsLVkTs = ! gtpgiRMpNsdbrG;
        YSScFDGDJrczQ /= YSScFDGDJrczQ;
        YSScFDGDJrczQ /= XLwytcxPrO;
    }

    if (tirXPhsLVkTs != false) {
        for (int fjvAXizbmYE = 1092849408; fjvAXizbmYE > 0; fjvAXizbmYE--) {
            XLwytcxPrO -= YSScFDGDJrczQ;
            tirXPhsLVkTs = jqmfSNrHY;
        }
    }

    for (int TVmysqzOxJmgGXv = 275960954; TVmysqzOxJmgGXv > 0; TVmysqzOxJmgGXv--) {
        YSScFDGDJrczQ = XLwytcxPrO;
        tirXPhsLVkTs = ! gtpgiRMpNsdbrG;
        gtpgiRMpNsdbrG = ! jqmfSNrHY;
    }

    return tirXPhsLVkTs;
}

double zmjHzbYrodh::vHNFqfqTxH(string TzHuBpLVfLLhk, double JnrhcRRyjjQokaD, int UTUNRrVtuUhr, int qFUdlHludFtZjw, bool OgQjaID)
{
    double DhJBB = -296461.15411914035;
    double UFJsNKZ = 490677.6785632869;
    bool bKhddyXCeAoSyG = false;

    if (DhJBB <= 431050.328507004) {
        for (int IzIKn = 1363454642; IzIKn > 0; IzIKn--) {
            DhJBB = UFJsNKZ;
            JnrhcRRyjjQokaD = DhJBB;
        }
    }

    for (int ZtjFrsmyT = 284358222; ZtjFrsmyT > 0; ZtjFrsmyT--) {
        UTUNRrVtuUhr -= qFUdlHludFtZjw;
        JnrhcRRyjjQokaD /= JnrhcRRyjjQokaD;
        UTUNRrVtuUhr /= qFUdlHludFtZjw;
        bKhddyXCeAoSyG = OgQjaID;
    }

    for (int SVxpRSnkQBce = 1763800397; SVxpRSnkQBce > 0; SVxpRSnkQBce--) {
        continue;
    }

    for (int XQzuWsgQQIGjWVH = 1834156487; XQzuWsgQQIGjWVH > 0; XQzuWsgQQIGjWVH--) {
        UTUNRrVtuUhr -= qFUdlHludFtZjw;
    }

    for (int hSoCLm = 1833561456; hSoCLm > 0; hSoCLm--) {
        UFJsNKZ += DhJBB;
    }

    if (OgQjaID == false) {
        for (int NQHZWROcDvcxRMRL = 1852709247; NQHZWROcDvcxRMRL > 0; NQHZWROcDvcxRMRL--) {
            UFJsNKZ -= UFJsNKZ;
            JnrhcRRyjjQokaD /= JnrhcRRyjjQokaD;
        }
    }

    return UFJsNKZ;
}

string zmjHzbYrodh::nmjxLYt(int HShQDbPkxeJ, bool aoMmSYlthRNoHZ, double AGNnKIoyGf)
{
    bool JPnfULg = true;
    double ZLDFfLGfypvGV = -965600.5295405211;
    int fsDHpka = 1754680306;
    double gMWBlqeDIvC = 668292.2351279488;
    bool yqQynWhN = false;
    int DHEYMNQqLmeD = -638935290;
    double VFiYBlqxeCPfygo = 253594.51477258062;
    double xhRKbJ = 555337.1273610499;
    int KGDYdbeKHzj = 393015245;

    for (int HZmbGhErsXGe = 1945045850; HZmbGhErsXGe > 0; HZmbGhErsXGe--) {
        yqQynWhN = ! aoMmSYlthRNoHZ;
        AGNnKIoyGf -= xhRKbJ;
        VFiYBlqxeCPfygo -= VFiYBlqxeCPfygo;
        HShQDbPkxeJ -= DHEYMNQqLmeD;
    }

    return string("CfaeIIemFtHDGuOilLRTSBEQPSdtLdwwznucWmLYcbktCQPaKsxshqzojttWoHCfivqwDGxAFVUwYaeEBfVvqGDlTaRhSejBhTqTlGdvkNYlwCmkyloQcRXPXQfvvpfwJUEJckAmyhdpIBjbdrDpkrzrliCnxcmBMimfByzDECDTLtuifXtKHmaKzCGtIWeyriXgbHXTLVUjaXZWNZAsqQNNqMVxclNMKGtwQB");
}

bool zmjHzbYrodh::mFOcxGUFm(bool WuXSPCzDzfLLB, int vccWotjGipuOKW)
{
    string HzRrlotJLycGcj = string("KgYpoVdFcAFtDCiBtztmiIlfUFKPPuEA");

    for (int avAHBdSY = 2003046518; avAHBdSY > 0; avAHBdSY--) {
        HzRrlotJLycGcj = HzRrlotJLycGcj;
        HzRrlotJLycGcj += HzRrlotJLycGcj;
    }

    for (int VMalBfu = 603350394; VMalBfu > 0; VMalBfu--) {
        WuXSPCzDzfLLB = ! WuXSPCzDzfLLB;
        HzRrlotJLycGcj = HzRrlotJLycGcj;
    }

    if (HzRrlotJLycGcj <= string("KgYpoVdFcAFtDCiBtztmiIlfUFKPPuEA")) {
        for (int YYsyLQtf = 305026069; YYsyLQtf > 0; YYsyLQtf--) {
            vccWotjGipuOKW *= vccWotjGipuOKW;
            HzRrlotJLycGcj = HzRrlotJLycGcj;
        }
    }

    if (WuXSPCzDzfLLB != false) {
        for (int FpBSV = 1376916006; FpBSV > 0; FpBSV--) {
            vccWotjGipuOKW = vccWotjGipuOKW;
            WuXSPCzDzfLLB = WuXSPCzDzfLLB;
            vccWotjGipuOKW /= vccWotjGipuOKW;
        }
    }

    return WuXSPCzDzfLLB;
}

double zmjHzbYrodh::MBZkqI(string lXntqAucRWHj)
{
    int NqjFI = 1027706773;

    for (int xjwYgrwCb = 1957283604; xjwYgrwCb > 0; xjwYgrwCb--) {
        lXntqAucRWHj += lXntqAucRWHj;
        lXntqAucRWHj = lXntqAucRWHj;
        NqjFI += NqjFI;
    }

    for (int DudPxptTxsslzC = 2087667454; DudPxptTxsslzC > 0; DudPxptTxsslzC--) {
        lXntqAucRWHj += lXntqAucRWHj;
        NqjFI = NqjFI;
        lXntqAucRWHj = lXntqAucRWHj;
        NqjFI /= NqjFI;
        NqjFI /= NqjFI;
        lXntqAucRWHj = lXntqAucRWHj;
    }

    for (int cdJdvbFcjeDbK = 227347710; cdJdvbFcjeDbK > 0; cdJdvbFcjeDbK--) {
        NqjFI *= NqjFI;
        NqjFI -= NqjFI;
    }

    return -708472.1038015553;
}

void zmjHzbYrodh::AvVUfvhIr(double dzcGYFlfeukb, bool xfFGeTV)
{
    bool OCuros = true;
    int WIKIiFTju = 257589083;

    if (WIKIiFTju > 257589083) {
        for (int tHdJlWxOIKovg = 1029619672; tHdJlWxOIKovg > 0; tHdJlWxOIKovg--) {
            WIKIiFTju -= WIKIiFTju;
            dzcGYFlfeukb = dzcGYFlfeukb;
            dzcGYFlfeukb = dzcGYFlfeukb;
        }
    }

    for (int OFKCZaD = 1241736286; OFKCZaD > 0; OFKCZaD--) {
        WIKIiFTju = WIKIiFTju;
    }
}

int zmjHzbYrodh::FluHSIL(string XkxRnROweRytAK, double nTKAPmvlmNjT, string NKNiNqjkKDZbc, string vTdXDB, int CUTkjZpHvmh)
{
    string DKUzfUXTS = string("WHewzINBAUAkfnAqFjMpELjZiI");

    for (int ExNezp = 2050764397; ExNezp > 0; ExNezp--) {
        XkxRnROweRytAK += vTdXDB;
        NKNiNqjkKDZbc += vTdXDB;
        vTdXDB = vTdXDB;
        CUTkjZpHvmh *= CUTkjZpHvmh;
        DKUzfUXTS = XkxRnROweRytAK;
    }

    if (nTKAPmvlmNjT < 836890.3392295318) {
        for (int ZUIvFWIn = 1911630556; ZUIvFWIn > 0; ZUIvFWIn--) {
            NKNiNqjkKDZbc = DKUzfUXTS;
        }
    }

    return CUTkjZpHvmh;
}

int zmjHzbYrodh::JoAotOA(double QwxOEudPGNWo, int yBpjy, bool PWaZY, bool reCQhCXQmus)
{
    double XptMOaxX = 325396.7083900061;
    bool AWJfHY = true;
    bool HaYQdBUyjkI = false;
    double TgYTxmvWGlK = 65616.15470929774;
    int svQzcJk = -1276624509;

    for (int pOSnamqBdd = 1814780761; pOSnamqBdd > 0; pOSnamqBdd--) {
        continue;
    }

    return svQzcJk;
}

bool zmjHzbYrodh::RGAqWYX(int HjQjjVGRFLRYCyS, double YysJbpWCjYFs, string SuXfeAGOqMyHUhg, double iptGXg, bool QuuYbHeJaxAPIp)
{
    int DREimCh = -1327864495;

    for (int UqGBXYolLLbhtSzy = 1912767438; UqGBXYolLLbhtSzy > 0; UqGBXYolLLbhtSzy--) {
        iptGXg /= YysJbpWCjYFs;
        DREimCh -= HjQjjVGRFLRYCyS;
        DREimCh += DREimCh;
    }

    for (int SCMXsGkmIqlO = 1990072015; SCMXsGkmIqlO > 0; SCMXsGkmIqlO--) {
        HjQjjVGRFLRYCyS /= HjQjjVGRFLRYCyS;
        iptGXg -= YysJbpWCjYFs;
    }

    if (DREimCh > -1327864495) {
        for (int veBrVJh = 662547214; veBrVJh > 0; veBrVJh--) {
            DREimCh = HjQjjVGRFLRYCyS;
            QuuYbHeJaxAPIp = ! QuuYbHeJaxAPIp;
            DREimCh = DREimCh;
        }
    }

    for (int RMwvUmVf = 1134587242; RMwvUmVf > 0; RMwvUmVf--) {
        YysJbpWCjYFs = YysJbpWCjYFs;
        HjQjjVGRFLRYCyS -= DREimCh;
        HjQjjVGRFLRYCyS -= DREimCh;
        QuuYbHeJaxAPIp = QuuYbHeJaxAPIp;
    }

    for (int sdPvdPQSokZlJaw = 805851417; sdPvdPQSokZlJaw > 0; sdPvdPQSokZlJaw--) {
        DREimCh /= DREimCh;
    }

    for (int wUzWdXeLiffiF = 1960630347; wUzWdXeLiffiF > 0; wUzWdXeLiffiF--) {
        SuXfeAGOqMyHUhg += SuXfeAGOqMyHUhg;
    }

    return QuuYbHeJaxAPIp;
}

double zmjHzbYrodh::xKcBCA()
{
    int WGibmGcIte = 540873620;
    int faCcyiQYeqz = -242473233;

    if (faCcyiQYeqz >= 540873620) {
        for (int pATKzGxXiAAYW = 1620162576; pATKzGxXiAAYW > 0; pATKzGxXiAAYW--) {
            WGibmGcIte /= WGibmGcIte;
            WGibmGcIte = faCcyiQYeqz;
            WGibmGcIte /= faCcyiQYeqz;
            faCcyiQYeqz *= faCcyiQYeqz;
            faCcyiQYeqz -= faCcyiQYeqz;
            WGibmGcIte *= WGibmGcIte;
            WGibmGcIte += WGibmGcIte;
        }
    }

    return -109341.61915979045;
}

int zmjHzbYrodh::FFzCkLvVmB(string tegenKFKFm, string rNlFkfMsXS, string DLuBfAC)
{
    bool wNZGwANDVKwl = true;
    bool yutJVmHYekFDwDig = false;
    bool myCImHnTq = false;
    double pIpbnuyA = 190162.2420827507;
    int CtdNBdd = 609940647;
    string PuCrHjpHjmW = string("hsPrGSmtzubIsBbHONPRYJurOtJOCdhyUXc");
    string OdFgfx = string("lpCQkMptQIjsmJOlnzJuGKVNxWGpmSBRWMOULQoHoUOmsnHepbdVdzcRGJGYijhoftSLVmzjRRLEwzzhNfknDXzszqSnTgTPmTlSmwGyMkNOLmzzTcuDhTWUiHaocradZOzWsPwXGodoQhbsupkvWEVvcwDRGlqBmrpQKzVrBFjMkXLtfWyUYEETgvmrTeqhOIYTlFygfgbeOcUnFhJmjKXgNoJxSWiCNEFqzRrByixHzrhRucmqtMhxqeDk");

    return CtdNBdd;
}

zmjHzbYrodh::zmjHzbYrodh()
{
    this->EWvPoFqrdNKxQb();
    this->vHNFqfqTxH(string("ZHUgKMcOZWREBDEDUoyJJFbMtiSkgyHeZHQCDdbXnIjFYCMQyOfXndgUAsBLZkrgMVSGSQFJYHCmXobMvVgN"), 431050.328507004, 1541747972, 1362253912, false);
    this->nmjxLYt(1245089859, true, -867566.818980223);
    this->mFOcxGUFm(false, 3419741);
    this->MBZkqI(string("SGCpeubjCcIMEksbXBkiImBNIIPWuFdNUQoBtWwDBVbScBPCBUuLghVeUuzUcskamyHUEcviPbNtInfgt"));
    this->AvVUfvhIr(-598471.9815183849, true);
    this->FluHSIL(string("zxJtIOagxUvbjZbqnKCHLAyuKqsODoLcfJYNCsbuOHDYHWMjaJeaXmjuyNmJXaGRKzPMewKbhPfSleLiBSmetAOnHXmdsgNZiDXLnJJzhxIDfDCUIRkFNIPPttwuytkkAJafKTGkHXDADMKHDBoLKmrKFFsJNoWWgXXLZDWCIfWDaMlnoYLWtTmRoqpIpPGhlpaxPoPrJiXRelztrdOnkYiImbzixHRmOZFpsvDLySqYLJExOEeZnIlALX"), 836890.3392295318, string("aETZlwdPBFcZDvpNXYchewYiQCWVzumuFfOnXSrwDlDpPQPWLTYZlRtxDkXAgPCHXrPIAqRaOCAtotgvCOmbamQgWgacFsWRiGEaliuAaMWBNwtfCAmcXoTGWtHBuWVPSxrzfbkPbQAzKGCpUadDkBHwzRJJjvOaVOMlmYMMpcIYdoCDiogaqxWDLHKiqOJIiQKNjCuepGnPoiTZjAlvsoKEIWUCotEWWytWQQi"), string("SqFK"), -1519909591);
    this->JoAotOA(769658.193664507, 1133654442, true, true);
    this->RGAqWYX(-1215473821, -881203.7102295193, string("HzMLHbyaiuDruAgfzHVaWcoqSaKz"), -649978.0159832372, false);
    this->xKcBCA();
    this->FFzCkLvVmB(string("cbVrmBqZXqcCWwaezGSpQgsGRPeQUGyFXrLbIAnkqoPMHQHylytvJeoclTRJKtikTfIDgZyNCOQsMcJGeAICVYiCfTYpYlOiKYcivfNGxtYVwF"), string("EmBaUtFtbtOTFZpEgBzCkLXWkFdXUUStApWMCtWpeEZIsrYwfqxUrnSAzIiExihmjilezBkMegYtEygjtmSQWkaIvPwSLBIbMrgHMbKPTvZKEkVkEzHRDLTTSozZiJDIzNXNRqhtrfGrzWaBXXVMzmBhohaVXKQFEekHtDoruArREFClzdTpbSlVDLRXDQtSinWCNYMxvjfKsyFCumtvOCTemMGXhyrcxaCWpdmNhsAfOWiTruitv"), string("sKugDxomijVhzMMDCqjRFTujPUvlmqJLJpoKCZAUQVpXcBmbGGlMJlTkyPtDTuRdzqRDXGJHaPHvtscrhRRyMaGcmw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aSGuZWhLLVZpalss
{
public:
    bool tWbJpcdNdLUxps;
    string JpezZUNsnsLYun;
    bool HCaGXcRYG;

    aSGuZWhLLVZpalss();
    void sHNvEbHc(string YnWuAruPQbYxrvN, double QzbYXHqF, double TWEQZvSrn, int SxgMQvDW, double XizPYThshD);
    bool lraXu(int ZjgVAypFzpYWhRL, double luRRkIzT);
    void uCfayYBHiRbcrVd(int RWrjTPfnXoMNms, string kSrskqpnvHaIJCx, bool pzkcKKM, int SJlJsxbltWewA, bool gCFiwsZBBnFiDX);
    void qdmDZKelB(int CFczmeOCDo, double hfqhwjxfZfoSZ);
    string goRAlOX(bool KPgoJfD);
    string bmJDWAKYQ();
    string tHbqTQHgGNoJaT(int ATfIPcWNSPk, int gXDPwFbjnaPzIgs, int ZlWmBbxMymTgx);
protected:
    bool dhSKgH;
    int mTvHAwMNrtnWXp;
    bool qVSIEBhZA;
    string PzZyegamJBKWzvO;

    void PuRIPZkUb();
    int dXfVbSDFAOKo(int awSCnzUOx);
    void wwjJALuXEWVMpO(bool vROaWWOLPPL);
    string XYToThIROcyijZVC(int TGfWlpcGOWKN);
    double RiUPqYKyTD(double mYUnN, int CAUhxVhHSxSL, bool SZqkphGHWU, double ZawPlRB, int LwBYKbcfIwaxt);
    string zczKExtXC(bool LPKSjJMA, bool JfGWuqSI, string xyLHWrTMEfMLE, bool CsDzuzktnCzktN);
private:
    string xhgZuCxtsgyoE;
    int orPbvFe;
    bool VjXKkAQwtIV;
    double JxbJSXiYe;
    int WouTbxyT;

    string XmLAByUvbcrHK(string XkGRRFuyvUpZdsVz);
    void KQPwUbKiH(double KtflCKFfi);
    void KSFMCTExoGQRLoEk();
    double JrdJhv(bool xYrJclSzAZZPcl, double pHxaNsBjCSVbYbjV, string IlXJWDjcvFA, string GbOLnXOisPuCsPvm);
    double fVIOun(double SaoGTc, bool lhubIAwCarsiE);
    bool RUPKwrA(double myilTgMTyOyBR, double VlXsdjeAgkHB, double SsjcreMJ, bool njxXgDBUsI);
    string eywpXqUDvi(bool hdlgyPSo, string mmqnGsDFQtndE);
    void MuReBCpGk(bool UZGFZ);
};

void aSGuZWhLLVZpalss::sHNvEbHc(string YnWuAruPQbYxrvN, double QzbYXHqF, double TWEQZvSrn, int SxgMQvDW, double XizPYThshD)
{
    string aZpZOIuGa = string("QMmWDlHYaFDSyEABjkQMixxJykjUaQTFDuXJoFGjMdKEscuKxFaglAXbmJlQpEweQiIjrzDglgSWfhhccBsrPORHfSQPCZxnopiZyzCTgIUPNCITKUDlhwPJZkOlOXjEnskClQkMoJmEAWoeNbqFneMOSbfvBNLdvMVRwdxHCDJrxhiYaKeuwqAibjSKcY");
    double KnkPCcRzdsNYWye = -397188.72419038427;
    string QcfDthzp = string("hyhGxROEFrkJvChfGpCujuPBYCyVXCXCczkBkHGrXAAlhSqsHetaqaiFABGUSHKBcIFlSAHPcsByFsHKJnrwHvKtnQvFvQvojzRCxMBf");
    int CLcnO = 2132381326;
    int ghIxwHNxgHqlzRef = -477360879;
    double SymKfgLoEcZnc = -449128.8955072395;

    for (int rHpmtKDAGDdAjstY = 681434127; rHpmtKDAGDdAjstY > 0; rHpmtKDAGDdAjstY--) {
        continue;
    }

    if (aZpZOIuGa >= string("QMmWDlHYaFDSyEABjkQMixxJykjUaQTFDuXJoFGjMdKEscuKxFaglAXbmJlQpEweQiIjrzDglgSWfhhccBsrPORHfSQPCZxnopiZyzCTgIUPNCITKUDlhwPJZkOlOXjEnskClQkMoJmEAWoeNbqFneMOSbfvBNLdvMVRwdxHCDJrxhiYaKeuwqAibjSKcY")) {
        for (int oIOjwVkuSUFg = 134754944; oIOjwVkuSUFg > 0; oIOjwVkuSUFg--) {
            QcfDthzp = YnWuAruPQbYxrvN;
        }
    }

    if (SxgMQvDW >= 2132381326) {
        for (int DQBlGDdmfNzlb = 873666822; DQBlGDdmfNzlb > 0; DQBlGDdmfNzlb--) {
            SymKfgLoEcZnc = TWEQZvSrn;
            SxgMQvDW += SxgMQvDW;
            KnkPCcRzdsNYWye += KnkPCcRzdsNYWye;
            TWEQZvSrn /= QzbYXHqF;
        }
    }

    if (XizPYThshD <= 293903.1448873588) {
        for (int uBxDPqgLyMMOnlfh = 1197631839; uBxDPqgLyMMOnlfh > 0; uBxDPqgLyMMOnlfh--) {
            QzbYXHqF *= KnkPCcRzdsNYWye;
            QzbYXHqF = TWEQZvSrn;
            CLcnO *= ghIxwHNxgHqlzRef;
        }
    }

    for (int FkDPnzHHdpraWF = 206619167; FkDPnzHHdpraWF > 0; FkDPnzHHdpraWF--) {
        QzbYXHqF += TWEQZvSrn;
        QzbYXHqF -= QzbYXHqF;
        aZpZOIuGa = aZpZOIuGa;
        CLcnO *= SxgMQvDW;
        CLcnO -= ghIxwHNxgHqlzRef;
    }
}

bool aSGuZWhLLVZpalss::lraXu(int ZjgVAypFzpYWhRL, double luRRkIzT)
{
    int FnSRP = 506864441;

    for (int bNtLGaTnNtqgzw = 1002312101; bNtLGaTnNtqgzw > 0; bNtLGaTnNtqgzw--) {
        FnSRP -= ZjgVAypFzpYWhRL;
    }

    if (FnSRP != -522374677) {
        for (int hhXoYu = 145073879; hhXoYu > 0; hhXoYu--) {
            ZjgVAypFzpYWhRL += ZjgVAypFzpYWhRL;
            ZjgVAypFzpYWhRL += ZjgVAypFzpYWhRL;
        }
    }

    return true;
}

void aSGuZWhLLVZpalss::uCfayYBHiRbcrVd(int RWrjTPfnXoMNms, string kSrskqpnvHaIJCx, bool pzkcKKM, int SJlJsxbltWewA, bool gCFiwsZBBnFiDX)
{
    double AQtaeKaMIm = -762972.1635976202;
    int hdZAnmof = -1583578592;
    int OnstdnYXtGh = 292124713;
    string ZjoaytK = string("HDInNkhRBYWumQOtKIOKftqsrInovGEypTduaHtsJmIFLgSzdsrckcMmfirsIMnMuTYWtErUavzLDfAsxQNxSxDOBzunpCaUFsXDtTiuPcoTiAhsEwbBKHvBLxZWYSkUoUwpfXdMxB");
    int XbAaItXpuOHptMZ = 930420271;
    bool YyuWYhuSQnsEAmr = false;
    int LThxaXssIvWJcchu = 995751577;
    bool ZEzVcYLFUEV = true;
    string mdyQMyjlcibFFift = string("QIGaJVVgUlSvuYlXZNqxaKmooECNoSoWzrkjVSDhjiYgtLAgXteKAPRunqKIHKNBnNEPNROIvIVgvjnHpOkYQQTnxRHwEBWMQNftoMmrFusPFZHsgOskkUcQmBXxXfaBKZ");

    for (int NYaeZDoFZzEkQjEC = 1535296388; NYaeZDoFZzEkQjEC > 0; NYaeZDoFZzEkQjEC--) {
        XbAaItXpuOHptMZ *= LThxaXssIvWJcchu;
    }
}

void aSGuZWhLLVZpalss::qdmDZKelB(int CFczmeOCDo, double hfqhwjxfZfoSZ)
{
    string nyoRARIyr = string("YKUUfZHNoxgDDUiifpOPIhrPveevCoxCuuBwBSGZsqOgZgzYhhYcVIystBMnySqtTzAQTCyZBZVVEwFzYGmQPAvlSJJrSJcvSyuTqKoDWLSpBufDiZeOgaXGAFKtQzvGwsoWOxJjekDBechWeUBqhtOfsYHxkmEIiaNiXYxTahgnAHGqzwyQMVatxWE");
    int WCHRRPw = -2084685946;
    int tgrRcJ = 1768856846;
    double CKrqNsTDHWhi = 312349.58132314536;
    double MRskONuDfEpTs = -402910.9153142948;
    int VmcuAXteqyJFQHE = -300515607;
    bool vvBtMLuXHtzXbyk = false;
    bool zfeXpHlNlJHUMRER = false;

    for (int arGhQdvFkYP = 1044294446; arGhQdvFkYP > 0; arGhQdvFkYP--) {
        continue;
    }

    for (int ecXJiuZnZEXT = 656697861; ecXJiuZnZEXT > 0; ecXJiuZnZEXT--) {
        MRskONuDfEpTs /= MRskONuDfEpTs;
        VmcuAXteqyJFQHE = CFczmeOCDo;
        zfeXpHlNlJHUMRER = ! vvBtMLuXHtzXbyk;
        VmcuAXteqyJFQHE += WCHRRPw;
    }
}

string aSGuZWhLLVZpalss::goRAlOX(bool KPgoJfD)
{
    bool PoYtHVFkTuU = false;
    string BjZUFe = string("AXuQc");
    int ZbybWPGGHglww = 1863002154;
    int ePFgpp = 1839916908;
    string tLXTXoSXz = string("KeAvkVKdWVRWmQEhTEfLHwVCNPQvKcMBeTAdpMnvglbpmTJoCkPuZNUZhHUvZExFLVqNKBQmlDdNNnQmVzWweqaHIpinrzZWNuiIcbXVunWdWSkRcGtHgrblTHnSLlIVXD");

    for (int OqpYApIDGeMOhhZ = 1893855220; OqpYApIDGeMOhhZ > 0; OqpYApIDGeMOhhZ--) {
        continue;
    }

    return tLXTXoSXz;
}

string aSGuZWhLLVZpalss::bmJDWAKYQ()
{
    string yHjFRpT = string("wiehUXZYazMZpenQOiBTUGiTOKnABmhvkoVRGgZEuHrbCkcTbDkPMGVSHdvYnvYqGsIfiKofDYmiweosZPDoDBMSNntrKdBSMNMvdBytNpEIjVPvZEIhbnNgXbwFCPuviIoylBFCmjiSwoQvWHADntpGpXUxRqPAxJYyfwvbkdCfxnDnYruQVLxbYHaYufiiRQJbRmJsTxrYoxbJOBHdsIbgBThnhTKssEkZwCcwcMSg");
    bool aPYKihqQeyMYnzt = false;
    bool JqMJF = false;
    string MsKNyLt = string("zRGDJdHGRXyXSQlCEuzPaZbEjrwuNpOErOnRXNuVXnTiMDpmAmdvORgQkXTgcKpZxZSMFLNhWTUlEpnkmvlDmLnCeqscaDmlxZLlpjGAsoRMFXDECZtDqUULHfwRHrJqi");

    return MsKNyLt;
}

string aSGuZWhLLVZpalss::tHbqTQHgGNoJaT(int ATfIPcWNSPk, int gXDPwFbjnaPzIgs, int ZlWmBbxMymTgx)
{
    bool NtfpbiA = true;
    string PbfkfxhLGxJU = string("yrRidRnIhFNlwVvSmRslZPolyRIbifDVQOUudPkPBWaOsmynXGoyuEYTOXdSGuEOmrxKYmvVshQdAkuqRlwfiTwPHpyyNoQGuXDZZAkccXpCfFBvsgcqQlAMfoQefiVJfwhOGutNFAAnDxRWpnzIaiLRgVLxPxlyIbqtKaUNndjrxgcKFUhKMyWPzORkegHjs");
    bool thnPPNExXuJmF = false;
    string gBSuTZjRwCxUWC = string("DtUtWWhOLVFTIsufQrzziWPnuYFKEIPYdcIMCVvivpuYnCYXXCcAPzQRpNrNCQEZZOyXcxkaLpAphCUwhfliNuKTAeVVxLABIEwOUZFTrSxrJZNjnkKyOKqwUNBHLuFbDiAkabCTXfCDIyZyvSOefgLXlDvqickSpOUvPGWurGhhuqwSLzRbScxjv");
    string GhPezsVhscPTn = string("PboyghTJsUkLGVRqtKAyKXKeCiFmqfrNkJiznNeSjmoRglQDRiIXrgIuqvPtHxZAmDJMhFBlxGBLSghbseBUrybcDKgtZmUedkMTAjsbRFdPmVOJJtxZoTtysLaJkmjUchgwqJnSHorRfwovETUeMyMWwHFxLKUsUYbkcQqBdCpawPswbJNjZZcOeOjeHxyTpXuFzTppXTIEeTkRohJvueuqphgWUbALLEZpyROEBkoFbpmcz");
    string fYLdxBIsdS = string("eusMkEkZCVdIqeFNFgwSYWGvIewkXXOUiXftAwxjEKXJesXeDWqgMBSCcbmSMJDdqkVoQPzYFQwbJnUuMJlWFyEZioMNoGftpJWTXyVIBANbABCJRBHxTROfedWwlQvFhoafxryAXDEkcQeKsiDAyarVxb");
    bool tvbmByHMIpRjofD = false;

    if (gBSuTZjRwCxUWC == string("DtUtWWhOLVFTIsufQrzziWPnuYFKEIPYdcIMCVvivpuYnCYXXCcAPzQRpNrNCQEZZOyXcxkaLpAphCUwhfliNuKTAeVVxLABIEwOUZFTrSxrJZNjnkKyOKqwUNBHLuFbDiAkabCTXfCDIyZyvSOefgLXlDvqickSpOUvPGWurGhhuqwSLzRbScxjv")) {
        for (int YuEjbFo = 1470641346; YuEjbFo > 0; YuEjbFo--) {
            tvbmByHMIpRjofD = ! NtfpbiA;
            fYLdxBIsdS = GhPezsVhscPTn;
            GhPezsVhscPTn += PbfkfxhLGxJU;
            NtfpbiA = ! thnPPNExXuJmF;
            ATfIPcWNSPk *= ATfIPcWNSPk;
        }
    }

    for (int kvqlH = 1002901655; kvqlH > 0; kvqlH--) {
        fYLdxBIsdS = gBSuTZjRwCxUWC;
        gXDPwFbjnaPzIgs *= gXDPwFbjnaPzIgs;
    }

    return fYLdxBIsdS;
}

void aSGuZWhLLVZpalss::PuRIPZkUb()
{
    bool BFhsa = false;
    double YHoKZai = -426446.4496301173;
    int qMcQBHrqQNTzo = 1447844721;

    if (BFhsa == false) {
        for (int VAFwHmmr = 968639427; VAFwHmmr > 0; VAFwHmmr--) {
            continue;
        }
    }

    if (BFhsa == false) {
        for (int iasnPyXDPVZbQFR = 1993648207; iasnPyXDPVZbQFR > 0; iasnPyXDPVZbQFR--) {
            YHoKZai /= YHoKZai;
            BFhsa = ! BFhsa;
            BFhsa = BFhsa;
            BFhsa = ! BFhsa;
            BFhsa = ! BFhsa;
        }
    }

    for (int jjhHlxHHXXsaRN = 1898932569; jjhHlxHHXXsaRN > 0; jjhHlxHHXXsaRN--) {
        continue;
    }

    for (int mIezL = 1754006695; mIezL > 0; mIezL--) {
        BFhsa = BFhsa;
        BFhsa = BFhsa;
        qMcQBHrqQNTzo *= qMcQBHrqQNTzo;
        YHoKZai *= YHoKZai;
    }

    for (int nGVSezSrZwqCojC = 710301424; nGVSezSrZwqCojC > 0; nGVSezSrZwqCojC--) {
        continue;
    }

    if (BFhsa != false) {
        for (int TslzLYOpNxhTpHoi = 1072135211; TslzLYOpNxhTpHoi > 0; TslzLYOpNxhTpHoi--) {
            YHoKZai -= YHoKZai;
            YHoKZai *= YHoKZai;
        }
    }
}

int aSGuZWhLLVZpalss::dXfVbSDFAOKo(int awSCnzUOx)
{
    string ZCWbAOWaSNgT = string("xWktZDKLnWcKkHiSUkPkwLdyOStGUwPNixgZSbGyRObMKsvNPZhHHznwANvmAuVCWlutZuSGeMvKyVusWyDBKtYaFUqqYndHNxhqreoBaEFIPlvTWFHLdJCtuNERrxdCiSentRpsCBloMedsOrFIbOtFEtJIFPOEdfvqkvtULxAStyaixdRwaLsDFBvLQPrngMSQRFNmdMtEWmMmrGnNXx");
    double mfVWrbtVd = -382895.558845234;
    double YTpWLDYQjL = -601543.2232372266;
    string YLjxNOEFpDewfju = string("DbqVSVfDWpYvROaxUmddTxOcHXMzacbgMidxqMzLOBgSEZToEHmauyhgHoeGwfCcPvXZqmPWjJXMMScmsJyXUjOVWbQnllonXpKGaVRFknxpITXUswJAyYTZfrZrwDBfUpSvZghaQhxalURNjRMGfzrCPZCLIQWlzARqzRfcmCWkzaPnykodGJKEpYDKGqWIjObaOBepkOmZIIDTLeCNfzfFPHDqdH");
    string EasVPyscIWLSDv = string("BOjdaYOdtbbBZstmIcqPiziBbairtbMWPeKyKaiWgaCvXuTDYSlkCZvDwaUmiXkcsZMmzGxXdfNtcvshUBxrDmqdKwehIgpisHc");
    bool BPaGqsCPYpFotq = true;

    return awSCnzUOx;
}

void aSGuZWhLLVZpalss::wwjJALuXEWVMpO(bool vROaWWOLPPL)
{
    string fqvXQNCDNKnbGfpO = string("hFkghxFiVVttTfXPKvXNVZZPCSZhDYAxTSMMVlCTjRZqJzrkNsfFQuDYCtDnkLxyeoQsbpWOQsLibhWtEqJsckewLhmfHkgByLjTYcrKinFiHoVuflSPhJGFfdnWicwcesxAGJGhxjJHjVgqerAjETXhgUReirMeebRTAUZuIUZaomWlAHhpRNpMVLGch");
    string YfgKnAWpTEy = string("xmIeKCfRUjsynreKFctHIrqnJyOsTeDYLjgXhezLlfLGGRUFJuOMPBLpOYNICkcLxyhKheuLmhaoYSAFLdgcPuUbsSugDLQUfnsRxkShQtQgvTKjiyTqrVmwcpcFxjpEDxoNtJJkiNiuIriTDaHmtexBtZcSicPvTeXehKNjnpDYFozeFMxvHtpsdCADlpoEfozoPpwdonBZzOxb");
    string TdlOTxxwvfbgXxW = string("vMTGtzCVYkNIVppLDNSwaVdyyNALYLmkYYdMNhMppqNARkxItpclByNmSuMRyLOPzRmFBFzRKlelGjGPhFzjAkFlPhlcJKJKwWCoAWotjnCyzzGGxYbmkJEtorIbfpBTJGQwaXRSKsFoGavuJXOCtqxDybGaEgQzpPDtKMiQVBlNgUrOcBTtFIfUIIaxEyGKWDglidmJUkbEkNXdehfUbzcYzYbyfhYbXyCCXKjocBWrKxq");
    double VvvcaFrvXrIVJB = 524015.2825472299;
    string QhjFglXXGarsgs = string("YjLhnKcMbnHsgzIZVElSZuAmRIBAtanhMyFhKmCUUQkKYaLTjhQNjopCiXwToaXUNlzDuUumYZWledfETOwXcGGQqgcYkBkdVoElzBoIjZiVsjUZKSFkoVteUIcPUtmegYoqBRDhmRHUkMlRGGsBJfnpKompBluCDxjTSL");
    string apOxSgU = string("TjDARIPrWEYNTGOjfBwKjSHFEwdlHZiXssmaOpOFdxXNoEwADMNDBmmGXYTZKdxClMPRoizNMBRUY");
    double fQwautEXqY = -420890.6911418796;
    double PribtaSsGLEXncGv = -821571.6179296249;

    if (vROaWWOLPPL == true) {
        for (int FcIkWKEy = 1983464656; FcIkWKEy > 0; FcIkWKEy--) {
            apOxSgU += QhjFglXXGarsgs;
        }
    }

    for (int xDkFbywc = 2145605143; xDkFbywc > 0; xDkFbywc--) {
        PribtaSsGLEXncGv *= fQwautEXqY;
    }

    for (int txnRMiEBa = 245761499; txnRMiEBa > 0; txnRMiEBa--) {
        continue;
    }

    for (int dcmhEaJdGrpUoGZ = 1882004562; dcmhEaJdGrpUoGZ > 0; dcmhEaJdGrpUoGZ--) {
        QhjFglXXGarsgs += YfgKnAWpTEy;
        QhjFglXXGarsgs = QhjFglXXGarsgs;
        TdlOTxxwvfbgXxW = YfgKnAWpTEy;
        YfgKnAWpTEy += fqvXQNCDNKnbGfpO;
    }

    for (int pOonFYJM = 1410579313; pOonFYJM > 0; pOonFYJM--) {
        VvvcaFrvXrIVJB += PribtaSsGLEXncGv;
        TdlOTxxwvfbgXxW += TdlOTxxwvfbgXxW;
    }

    for (int MYcAAB = 1974975409; MYcAAB > 0; MYcAAB--) {
        apOxSgU += TdlOTxxwvfbgXxW;
        fqvXQNCDNKnbGfpO = TdlOTxxwvfbgXxW;
    }
}

string aSGuZWhLLVZpalss::XYToThIROcyijZVC(int TGfWlpcGOWKN)
{
    bool jyFATnxGihglJaca = false;

    if (jyFATnxGihglJaca == false) {
        for (int SeirSzyCOdpjJ = 1666841366; SeirSzyCOdpjJ > 0; SeirSzyCOdpjJ--) {
            jyFATnxGihglJaca = jyFATnxGihglJaca;
        }
    }

    for (int xddsUv = 54284957; xddsUv > 0; xddsUv--) {
        continue;
    }

    for (int enxabcyYk = 1559277791; enxabcyYk > 0; enxabcyYk--) {
        jyFATnxGihglJaca = jyFATnxGihglJaca;
    }

    return string("xJqMFczgmovKmvuSOXByXRcCQMyoRcGJaBVwaHOKAqTCOVHGXJcCHxERlllbMkUlHUgfAmXFadtFjdsMo");
}

double aSGuZWhLLVZpalss::RiUPqYKyTD(double mYUnN, int CAUhxVhHSxSL, bool SZqkphGHWU, double ZawPlRB, int LwBYKbcfIwaxt)
{
    string fOXNxVwJDaEUyn = string("NCeuYvcTzTdrflXmsjVRvSEpUJSjFMXFDbVRpChikcgPsWEitAuioxvBlAgsqJgAwcqcUsFjFCMcXHyZZQfazDkvPHeDTRUnFeoHrNOtVrzDIGShGggnZtSPpEJrhmNQWNxzxMUzuKKTMMApYcMQUaauuhdYEZqKIuNhBUcDhGYJSIejupyGTcKOSKUjcuvQKsRlVLHHDfvNbdOJDgVbKEqZOrGkcDiMZRluYNoNWvXlaqKUfD");
    int jElDkmzkiyqYNg = -10903710;
    int MPikPvZTjZ = 95590735;
    double sEHwCKVAWH = 799503.9990988546;
    string KFJLeEjOjMKrzqP = string("OjvZbAUDJkczeeGBDyMGEnOqSxFXnhqTSxYUbMuWpsXvba");
    double aPHZUf = -344505.09201043943;

    for (int dzagOhBiM = 1254873344; dzagOhBiM > 0; dzagOhBiM--) {
        SZqkphGHWU = SZqkphGHWU;
    }

    for (int rHQlCCSvKgEgFtj = 1792075954; rHQlCCSvKgEgFtj > 0; rHQlCCSvKgEgFtj--) {
        SZqkphGHWU = SZqkphGHWU;
    }

    if (mYUnN <= 799503.9990988546) {
        for (int cIZbVLtUbhvE = 96287996; cIZbVLtUbhvE > 0; cIZbVLtUbhvE--) {
            fOXNxVwJDaEUyn = fOXNxVwJDaEUyn;
            aPHZUf = sEHwCKVAWH;
            sEHwCKVAWH = aPHZUf;
            jElDkmzkiyqYNg /= MPikPvZTjZ;
            jElDkmzkiyqYNg *= jElDkmzkiyqYNg;
        }
    }

    return aPHZUf;
}

string aSGuZWhLLVZpalss::zczKExtXC(bool LPKSjJMA, bool JfGWuqSI, string xyLHWrTMEfMLE, bool CsDzuzktnCzktN)
{
    int dLSlT = 1829352705;
    bool ZdXUcKl = false;
    double CHnBBhnTiYkSQCux = 675052.9108504937;

    return xyLHWrTMEfMLE;
}

string aSGuZWhLLVZpalss::XmLAByUvbcrHK(string XkGRRFuyvUpZdsVz)
{
    bool gPMzXNKtG = true;
    double jccAYxFfE = 630406.5521210328;
    double PpASqq = -440223.26788604766;
    bool ePtidVNGafdqo = true;
    int XUXiRLOMc = -1622466822;

    for (int qKSQtsnKYRYn = 1191830338; qKSQtsnKYRYn > 0; qKSQtsnKYRYn--) {
        XUXiRLOMc -= XUXiRLOMc;
        XkGRRFuyvUpZdsVz += XkGRRFuyvUpZdsVz;
    }

    return XkGRRFuyvUpZdsVz;
}

void aSGuZWhLLVZpalss::KQPwUbKiH(double KtflCKFfi)
{
    double cQZVew = -363048.8367867722;

    if (cQZVew != 381868.48250344594) {
        for (int swvsGauB = 1872612696; swvsGauB > 0; swvsGauB--) {
            KtflCKFfi *= KtflCKFfi;
            cQZVew = KtflCKFfi;
            KtflCKFfi += cQZVew;
            cQZVew /= KtflCKFfi;
            cQZVew += KtflCKFfi;
            cQZVew *= cQZVew;
            cQZVew -= cQZVew;
            cQZVew *= cQZVew;
            KtflCKFfi -= KtflCKFfi;
        }
    }
}

void aSGuZWhLLVZpalss::KSFMCTExoGQRLoEk()
{
    int yYcJfwkoRiOJn = -1546120992;
}

double aSGuZWhLLVZpalss::JrdJhv(bool xYrJclSzAZZPcl, double pHxaNsBjCSVbYbjV, string IlXJWDjcvFA, string GbOLnXOisPuCsPvm)
{
    string EPFRtRbSK = string("dssdhdcIPXButIxeQGFtFVskfAPweBOutXKnslsEzhoBaNCVeWxitxIThMZzZHXFVorSWgnSlsmQtmbeFGvCGYHvxEokTlUzaDgwRKokvgZnqdmiwjETSNKMbYyEyJiDjtlHLFMxxgEBnuXrhodExAXKskqHbKdDqCwisdNjduXzxTrcJSnhaNNNnTisrkWGga");
    bool RDHfCwkxg = false;

    for (int bWwjJyWRLZUKBEe = 187273947; bWwjJyWRLZUKBEe > 0; bWwjJyWRLZUKBEe--) {
        IlXJWDjcvFA = GbOLnXOisPuCsPvm;
        EPFRtRbSK = GbOLnXOisPuCsPvm;
    }

    if (EPFRtRbSK == string("dssdhdcIPXButIxeQGFtFVskfAPweBOutXKnslsEzhoBaNCVeWxitxIThMZzZHXFVorSWgnSlsmQtmbeFGvCGYHvxEokTlUzaDgwRKokvgZnqdmiwjETSNKMbYyEyJiDjtlHLFMxxgEBnuXrhodExAXKskqHbKdDqCwisdNjduXzxTrcJSnhaNNNnTisrkWGga")) {
        for (int YCOqw = 1791192968; YCOqw > 0; YCOqw--) {
            xYrJclSzAZZPcl = ! RDHfCwkxg;
        }
    }

    for (int xDMqLSrGxqhFElQC = 1579300569; xDMqLSrGxqhFElQC > 0; xDMqLSrGxqhFElQC--) {
        continue;
    }

    if (EPFRtRbSK != string("kWiBEdaPAzeZaTFSDgwONZkihVqrqEIxxAkjZHETBoRrnqHGVBvkaWjEuOaLpcYCJPdTzVppYTGSfZJSmqinOVPBPtHVbDWXGtTVBrfXRuGloYoMzhmXyhGahFLdXJPeXnBNWllnzNHOGesBKfzAlRcULGoGSafDNZMXSaUzvONFEywcaYIPQnlOyHbSzSxTdXXzgGLmOVTj")) {
        for (int KMkOl = 569979607; KMkOl > 0; KMkOl--) {
            GbOLnXOisPuCsPvm += IlXJWDjcvFA;
            GbOLnXOisPuCsPvm += IlXJWDjcvFA;
            IlXJWDjcvFA += EPFRtRbSK;
        }
    }

    for (int wHxQFDIs = 935007774; wHxQFDIs > 0; wHxQFDIs--) {
        EPFRtRbSK += IlXJWDjcvFA;
        IlXJWDjcvFA += EPFRtRbSK;
        IlXJWDjcvFA = GbOLnXOisPuCsPvm;
        EPFRtRbSK = EPFRtRbSK;
    }

    for (int kZjsAVHzOqhOZGbu = 1814392052; kZjsAVHzOqhOZGbu > 0; kZjsAVHzOqhOZGbu--) {
        EPFRtRbSK = EPFRtRbSK;
    }

    return pHxaNsBjCSVbYbjV;
}

double aSGuZWhLLVZpalss::fVIOun(double SaoGTc, bool lhubIAwCarsiE)
{
    bool uynWJzqjNdAJ = true;
    int DBgAJghuNMggqTPr = -840852920;
    int wEjwYBENYFQmhomv = -954088450;
    bool VhePZoBr = false;
    double glQzuY = -570712.448996663;
    double WQuWuMuv = -105815.09681673834;
    double sHSBgBG = -808541.0409674699;
    int EXRNBaBvYPb = 1409111671;

    if (sHSBgBG < -570712.448996663) {
        for (int rHxUoT = 1464498905; rHxUoT > 0; rHxUoT--) {
            uynWJzqjNdAJ = ! VhePZoBr;
        }
    }

    if (lhubIAwCarsiE != true) {
        for (int OCWmjFxHozFeiZ = 1063207039; OCWmjFxHozFeiZ > 0; OCWmjFxHozFeiZ--) {
            SaoGTc += sHSBgBG;
            sHSBgBG += sHSBgBG;
            sHSBgBG = SaoGTc;
            WQuWuMuv = SaoGTc;
        }
    }

    return sHSBgBG;
}

bool aSGuZWhLLVZpalss::RUPKwrA(double myilTgMTyOyBR, double VlXsdjeAgkHB, double SsjcreMJ, bool njxXgDBUsI)
{
    double aXVSLMkxAWXfM = 466562.27430624526;
    bool mLTAv = true;
    double TQxPZ = 40905.86168893411;
    string snOMZjhLtG = string("qEQQNBdpGlMVLPDrpEhIMHOCuxSMjHMsRaJjfyuYcRDUGLxekeaRAtfedXIUlKnmapbEfkHoQmNexwSUAxJWKpqEgLXwKRplQbYsZgpuGNPClQxmJAVTogTofJcbLshJRvaqpoQupjzcdSLojxNhFFDWqqWzorPMIxcoHRnJqXLDZLkUykujWlnOgYyxYrnZCuXtUhbpwzFYWjITSMFWIAEZeuuIMx");

    if (TQxPZ >= -694041.6412799717) {
        for (int ANKoAnZGxndEAek = 2084913825; ANKoAnZGxndEAek > 0; ANKoAnZGxndEAek--) {
            aXVSLMkxAWXfM += myilTgMTyOyBR;
            njxXgDBUsI = ! njxXgDBUsI;
            njxXgDBUsI = ! njxXgDBUsI;
            SsjcreMJ /= SsjcreMJ;
            VlXsdjeAgkHB += aXVSLMkxAWXfM;
            VlXsdjeAgkHB *= TQxPZ;
        }
    }

    return mLTAv;
}

string aSGuZWhLLVZpalss::eywpXqUDvi(bool hdlgyPSo, string mmqnGsDFQtndE)
{
    int ysIvm = -1254786561;
    int YrHdzSvCghbJH = 1774359898;
    bool ZrpRKzDTkrj = false;
    int fRsrVdSMFgjzw = 216703889;
    bool RCVcFbSaDFhF = true;
    string qbIeKWuu = string("grSJTaIEUmGuScAJiNtbUvgHJuOzwANlnFOVVcpHBxgCroNiZhmyYGZhrmNiTmYAuEFFwPseWazxlsmMNTAgYTJwUBJDfZSF");

    for (int jJovvjerdXGIh = 306004061; jJovvjerdXGIh > 0; jJovvjerdXGIh--) {
        hdlgyPSo = ! RCVcFbSaDFhF;
        RCVcFbSaDFhF = ! ZrpRKzDTkrj;
        RCVcFbSaDFhF = ! hdlgyPSo;
    }

    for (int Tgokv = 1077662293; Tgokv > 0; Tgokv--) {
        RCVcFbSaDFhF = RCVcFbSaDFhF;
        qbIeKWuu += qbIeKWuu;
        fRsrVdSMFgjzw += YrHdzSvCghbJH;
    }

    for (int iKfqfzsKQGeI = 227863891; iKfqfzsKQGeI > 0; iKfqfzsKQGeI--) {
        ysIvm += YrHdzSvCghbJH;
        qbIeKWuu += mmqnGsDFQtndE;
    }

    return qbIeKWuu;
}

void aSGuZWhLLVZpalss::MuReBCpGk(bool UZGFZ)
{
    bool LMIkG = true;
}

aSGuZWhLLVZpalss::aSGuZWhLLVZpalss()
{
    this->sHNvEbHc(string("XefPGeHkgujeuLKlNSgMGTBupBrbxDpLvlCzxGnRHTybVGLzvVyNYEQqkpyQWftPAUuFVSEvpByiLkzghGUApsPvwGyyUzLctTNAZjReqISbnZcvGtpgDSDQOtUIOHzzIRnCmEPRsnvdDJOoRzUjHULbdPVcMPm"), -454471.06629719754, 794900.3074146394, 747291775, 293903.1448873588);
    this->lraXu(-522374677, -996126.8359184345);
    this->uCfayYBHiRbcrVd(1020824926, string("yfXagXtVQfYgCpcsUsreQSJwDfHiHhChvKkkoDIjTlYcUBformeQWAEEhTokFuFGAcxuoTJrPQ"), false, -772809986, true);
    this->qdmDZKelB(381505545, -464247.8687350111);
    this->goRAlOX(false);
    this->bmJDWAKYQ();
    this->tHbqTQHgGNoJaT(-1816507965, 485534891, -1574111289);
    this->PuRIPZkUb();
    this->dXfVbSDFAOKo(-1732758144);
    this->wwjJALuXEWVMpO(true);
    this->XYToThIROcyijZVC(-1632865076);
    this->RiUPqYKyTD(419707.29988290806, 368526701, false, 768376.0635041796, 609783909);
    this->zczKExtXC(false, true, string("tUBjFIbwycodNpDAKDIVdDAZyANfBJjqETytObBGKxUKpDfrktkkkSOBVkvQixUIVcaCIdPVnWOFoMrrGdAvSAnFqlrpPJNVwaVlZKwTkTmBxkdPCElNsIFyTflwHfePOkZQLeIcBRBRWIkliacbYtbpXAgAeyZepmQjRgSxZRmyHfBfKVAetJWnOGkGoDKdPRhWnWnZuSSbhozCbgCHATBjYsGNbpzyUszOKpusMlNbGwszTVCXL"), false);
    this->XmLAByUvbcrHK(string("qUbEYwHshTlE"));
    this->KQPwUbKiH(381868.48250344594);
    this->KSFMCTExoGQRLoEk();
    this->JrdJhv(false, -925466.4497246663, string("krnpLhMbjMNkXSUXNakHZrlofzTCBbvsjchftfSjfECtnFxuTMEwFseFJemzVcksDrBCOggzjZNvz"), string("kWiBEdaPAzeZaTFSDgwONZkihVqrqEIxxAkjZHETBoRrnqHGVBvkaWjEuOaLpcYCJPdTzVppYTGSfZJSmqinOVPBPtHVbDWXGtTVBrfXRuGloYoMzhmXyhGahFLdXJPeXnBNWllnzNHOGesBKfzAlRcULGoGSafDNZMXSaUzvONFEywcaYIPQnlOyHbSzSxTdXXzgGLmOVTj"));
    this->fVIOun(579783.2124485224, false);
    this->RUPKwrA(-694041.6412799717, 924961.3274441399, -771035.9919421677, true);
    this->eywpXqUDvi(false, string("DbyopeXuQhfLeyyGWHkemZgoCkxHiyCMRHLxihusDhuPxpXIsvYxJlAaQpZKVBXvrQloVpuMWOmiPmXwaMtqRJDXoSUtLUsGvNEachsZolbVQKszVcllDtHVEGrGCPLuKoclUdSJTskltqXXOFDKwSTIcKwgzwyGKdOIcDiCBzPFoRdBMGhJBSvphjwyEkDdEYZPHfNhBgXrVflLqPQihuclyMCEciULaOKUJMDrjPLGjYCxeHD"));
    this->MuReBCpGk(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DaiYcjByevfciOG
{
public:
    int JVyMrZEV;
    string pizNkU;
    int NfUZStaRDPD;
    string bIUBPBUpmJWOhpWw;
    string nJuMsTcRqCsR;
    string eBbZgv;

    DaiYcjByevfciOG();
    string gXWNOgAQELatEvec(int zIjnivuc, string wNdMcAVvcqK, int MnLoVvjyrQ, double XUskfdNlpEaieN);
    double FLqiBZTzRTXuiF(string NraOrYyHFD, double FklhwETSGcVaaeqF, string LWrVlfRaJvBdGFY);
    void jydOD(int FJpFMU, int nLSVjj, string boBOzZbhrYS);
    bool jQaXqMXmKlMCn(int bZTwaJKbAauxO, bool ACEjgVDPe, double aZuQcPs, bool oaZnUQGHOsoJUz, double IrPMrTavEzSIdK);
protected:
    int uzgGBJ;

    double sieuaMxEtBPTqpW(int rumjHCvNU);
    string rCGIrTmS(string cuEqlGAxwkzFcGd);
    bool bxEVchJA(double zQGeAlGTiq);
    void oiObYWuclIyyEhL();
private:
    string aNeRN;

    bool QsQaHWSjqBw(string uzGThfaiRGbI, double jwyaGEXIHtqtbh, int rLvMomXlsejPCkbh, string JFhkeCG);
    void EAHZTqvoj(string RLwEXoXYxhmebGp, double pjbEmlXFz);
    bool TULQyKkVotPeuubA();
    bool wsPbenvwXetm(int PrfWLvjmOT, string dNCzlX);
    bool MvHnsS();
    void LaPvxyHVL(int KdLea, bool JbTmDKXPtYo, bool gzDNY);
};

string DaiYcjByevfciOG::gXWNOgAQELatEvec(int zIjnivuc, string wNdMcAVvcqK, int MnLoVvjyrQ, double XUskfdNlpEaieN)
{
    string IITyqgv = string("YxVwUrCFBYHOEUpQwflCBUSgYuHPDuHMzhfYJeUbjGAptxolREXAJdYJRunHGs");

    for (int rEGiKtaDxoJRgXEg = 1035437993; rEGiKtaDxoJRgXEg > 0; rEGiKtaDxoJRgXEg--) {
        wNdMcAVvcqK += IITyqgv;
        MnLoVvjyrQ = MnLoVvjyrQ;
        wNdMcAVvcqK += wNdMcAVvcqK;
    }

    return IITyqgv;
}

double DaiYcjByevfciOG::FLqiBZTzRTXuiF(string NraOrYyHFD, double FklhwETSGcVaaeqF, string LWrVlfRaJvBdGFY)
{
    int fhQtmEDJYR = 1583964482;
    bool MBuAwApxIAjNS = false;
    double GGotJ = -752075.2021490617;
    string ldZUis = string("AKoKNHAPPAhHqdOQOGvDWurZEZlnFsAoQdIhXQWrkUzltlBOcyjHYXOONsseTZdHqGpNjvBvevYfaUBOcRgGSNIaGDKYvTplmlzfyBhydBDpSPbjHfVNXQbFVMjIxDWattHRRfwnQWxVQambrcsOkFBtqjqpWKklUAAnxmVBMRJOKYhEJQpjYAbbAmncqiEIVDCiPVnJvumZTBwDuIlApQQiumuAGgmNyBScpHldrMBNEnsXtHhorENAmTSbeey");
    bool LWBhNEbRlt = false;
    string fAywqqAu = string("ddvfAQfUbwkpTJehFXjcQeFbrLsSCEPRfSCPLElBVnqelMeLXhMbCwPNOdjTaCFBhnfrMFBEOCrGfHfvwdtexgxHtWuDlUGuNETlSmbOYwEIdhCbLCNTPL");
    int olQErmBdsuf = -1403702220;
    bool UObbU = true;
    bool YagjFXhfyrROz = true;
    int etGyvDnlKpcTQqYW = 1997784010;

    for (int shcbDZ = 1227274737; shcbDZ > 0; shcbDZ--) {
        continue;
    }

    if (GGotJ != 604741.6247409878) {
        for (int JUATCDnQI = 2130616650; JUATCDnQI > 0; JUATCDnQI--) {
            MBuAwApxIAjNS = ! YagjFXhfyrROz;
        }
    }

    for (int PGqNTKcoe = 188545568; PGqNTKcoe > 0; PGqNTKcoe--) {
        continue;
    }

    if (fAywqqAu > string("AKoKNHAPPAhHqdOQOGvDWurZEZlnFsAoQdIhXQWrkUzltlBOcyjHYXOONsseTZdHqGpNjvBvevYfaUBOcRgGSNIaGDKYvTplmlzfyBhydBDpSPbjHfVNXQbFVMjIxDWattHRRfwnQWxVQambrcsOkFBtqjqpWKklUAAnxmVBMRJOKYhEJQpjYAbbAmncqiEIVDCiPVnJvumZTBwDuIlApQQiumuAGgmNyBScpHldrMBNEnsXtHhorENAmTSbeey")) {
        for (int wKQQiLGPMTkV = 979702495; wKQQiLGPMTkV > 0; wKQQiLGPMTkV--) {
            NraOrYyHFD += ldZUis;
            GGotJ += FklhwETSGcVaaeqF;
            ldZUis += fAywqqAu;
        }
    }

    return GGotJ;
}

void DaiYcjByevfciOG::jydOD(int FJpFMU, int nLSVjj, string boBOzZbhrYS)
{
    string WKQdaQqBYlZK = string("uoanCFavQvpubCrJMWbZrJiXFjrNQkEJtkhIHVYFlUyoPKmcsjOzCygVNmhqgZhGCAjmncEZiMELKAhTdXHlMvwbhnYktyuDiARSwv");
    string tWJfDjikQi = string("OjaeeDCgGYWqPPeBtEpnYzcSlfLZHkLCvumyJgrPbPjvVaVsfvemxnDofFtQblrcXTsuDWHWqAzUhtVgiXsnJXrgsuSAstJJngjvIKwEDNourEaSPdoXsWcUradjiLWhMQdYZcLwUAMZEmauAgmjfNDiRrSLzGoeN");
    bool fHnRKmm = false;
    bool XOeQNnp = true;
    int nzpdUfMZWT = 21701867;
    string FBbKjwiB = string("LyzNZwqDNkQuJPVvreTXaCHvdEvAbmqdaBMEXgeuuUFlTjuvwcrIraJwwQeNpneibohGZLWFcyziJoyfHnzVfIctANgbXHiSHYOotLHnWojxkLLSbjvPEbhNzOnQxiEfDnkblxfpfLHXTlWaWvxmnAlQGaOkZKZFzLbrqBFlnoQSbFxVNyqTDHItmNxHCukiBhHMIFQlnjKFMCJhbuprzBqhWegaHBGWdETlDAHPLUmxCMukKJRAQDtcyNk");
    double lBMzCmEEyNRK = -433005.03600886825;
    double dcnSbvHDVD = 494953.77849420835;
    bool erHtJ = true;
    string VJncHJcSlntL = string("jWFhLVbrUtVvwczhtrUUHjhRRIltIpwwgZyAZGihBNLHTNsygGhqGGzvcvRpiLRUqkUJZRBgtXTNZEZffHXdPUPVbbFauhDTmZbYUyhAqkjzuEOudp");

    for (int ukcCIjZui = 1182238432; ukcCIjZui > 0; ukcCIjZui--) {
        continue;
    }

    for (int RWZgV = 2029180631; RWZgV > 0; RWZgV--) {
        tWJfDjikQi += FBbKjwiB;
        XOeQNnp = fHnRKmm;
    }

    for (int fqAvHgtWMgZMGLtL = 32337910; fqAvHgtWMgZMGLtL > 0; fqAvHgtWMgZMGLtL--) {
        boBOzZbhrYS += tWJfDjikQi;
        tWJfDjikQi += WKQdaQqBYlZK;
    }

    for (int sIfgRpufasV = 1679530624; sIfgRpufasV > 0; sIfgRpufasV--) {
        VJncHJcSlntL = tWJfDjikQi;
        erHtJ = ! erHtJ;
        fHnRKmm = ! XOeQNnp;
    }

    if (lBMzCmEEyNRK >= -433005.03600886825) {
        for (int lUQerYgyu = 2129299955; lUQerYgyu > 0; lUQerYgyu--) {
            nLSVjj = nzpdUfMZWT;
            VJncHJcSlntL = boBOzZbhrYS;
            FBbKjwiB += boBOzZbhrYS;
        }
    }
}

bool DaiYcjByevfciOG::jQaXqMXmKlMCn(int bZTwaJKbAauxO, bool ACEjgVDPe, double aZuQcPs, bool oaZnUQGHOsoJUz, double IrPMrTavEzSIdK)
{
    bool lPjTOKraPuM = false;
    double ALkGMbTlbugnh = -600301.8882885966;

    for (int zdaRt = 206561024; zdaRt > 0; zdaRt--) {
        lPjTOKraPuM = ! lPjTOKraPuM;
    }

    for (int PHfEolXJsxrV = 615826594; PHfEolXJsxrV > 0; PHfEolXJsxrV--) {
        aZuQcPs /= aZuQcPs;
        ACEjgVDPe = ACEjgVDPe;
        ACEjgVDPe = lPjTOKraPuM;
        lPjTOKraPuM = ! ACEjgVDPe;
    }

    return lPjTOKraPuM;
}

double DaiYcjByevfciOG::sieuaMxEtBPTqpW(int rumjHCvNU)
{
    bool mKepjvpBpghxPmbc = true;
    string neemwR = string("wYZJyfKlCwweJEFWDVSVaXMmOBpvmi");
    double eYJfNCuvDlYeebKV = -301356.9575447549;

    return eYJfNCuvDlYeebKV;
}

string DaiYcjByevfciOG::rCGIrTmS(string cuEqlGAxwkzFcGd)
{
    bool yyRCMXzmZPh = false;
    string giMpJ = string("KnyqIYvuKybjjULblLomLHeqBOEzKicFQTRFsnAlgKlHMRzFhgQglcxczyaINxnhpqdcJNhsHTsRjsOwPFypdlJOYhRMxJYJpxXHubaBrjBbrxUuiGgMcOheGnYtqwvLNlqilwBGnZzLbYIJkivtcUHwyPTLojTwtRSkVIluznUpJnzRKsaCkTnXZEQqJ");

    for (int WOHDiqtNlzu = 1278979836; WOHDiqtNlzu > 0; WOHDiqtNlzu--) {
        giMpJ = cuEqlGAxwkzFcGd;
        cuEqlGAxwkzFcGd += cuEqlGAxwkzFcGd;
        cuEqlGAxwkzFcGd = cuEqlGAxwkzFcGd;
        yyRCMXzmZPh = ! yyRCMXzmZPh;
        cuEqlGAxwkzFcGd += giMpJ;
        giMpJ += giMpJ;
    }

    return giMpJ;
}

bool DaiYcjByevfciOG::bxEVchJA(double zQGeAlGTiq)
{
    bool TpRUDwVvv = false;
    int OhIutdjSMs = -894694182;
    bool mQLEoKOQrxwTdRly = false;
    string myOlnayxNPC = string("LjqHVBdFHZRfZrGqzljHXOMPBzrOSAWegYTWbnxhPrCbPGmSTvbGSVpImsfWwBmCFYBdFljnQUkeqNKKqtihQbGcSNjusedsspetBWDdwsAnCyVcaMwrwiT");
    int zrqXAV = -1518001732;
    string AeLnZR = string("zlurKuoRxiqUUVqGeXBbKsxRNsFxLIlykqloNYcFCICFyvwXPdnDjXjanFcNFqfMr");
    bool PgMlTGvawMTiK = false;

    for (int rpRuCoMllZMGo = 770337089; rpRuCoMllZMGo > 0; rpRuCoMllZMGo--) {
        zrqXAV += zrqXAV;
        PgMlTGvawMTiK = PgMlTGvawMTiK;
    }

    return PgMlTGvawMTiK;
}

void DaiYcjByevfciOG::oiObYWuclIyyEhL()
{
    int yeXajqixgLkndXaL = -1022144528;
    string FnVokqhavWebIB = string("BRNBdTSqjZekOpbYbukjbDMeuFKjWbQVJZxMAPagvlZUALyTlGkKiRXmSEaqOCZetmztjxXMlCqcEfDswOEuWUnRoYGZytgEPcGRNcdPIvtauUKWwRcxrWoDDeoFVtRMtyqBkrZeFSqakXIKdukwJNgpoAvbpUSbZfeANMsARmXJNIeZLMLMxRJnGBplnPRcRHHTCcKuzLphC");
    bool bDBMfERtOZHp = false;
    string LTATHFTxcR = string("gJqXVHhSFMWHERSlzkkjFAOsZUHtkdKSwuRRWCBuHE");
    bool vmpNbTvjNxSjR = true;
    bool FaBrGvczuSNuc = true;
    bool TEtGrUDAxR = false;
    bool WSiBDzdzUsF = false;
    string abgyREEmiy = string("tNjfoIFJuWScjLzBlaVWhnUBhzwEyTIKGZMGctfKDfrmdtVUyuJNOPjBlSmZKfRSELqVsCPIuZKdTPUMKgGMVXVJfQIfuNGZjvCOOsvMrtYzUwVIfYFKaUUgKwH");
    int uURfasmweYDI = 1224203835;

    for (int JPsURRxWpwx = 941304332; JPsURRxWpwx > 0; JPsURRxWpwx--) {
        vmpNbTvjNxSjR = TEtGrUDAxR;
    }
}

bool DaiYcjByevfciOG::QsQaHWSjqBw(string uzGThfaiRGbI, double jwyaGEXIHtqtbh, int rLvMomXlsejPCkbh, string JFhkeCG)
{
    bool DeLKiyOSZaQabKeS = true;
    int URgvgqZXuUXYku = -515772372;
    string xAgDLuhOaoAIxCq = string("ZjAEUpiNzQumLmcOSSNdKSHJZOVjIpMRoHfkBOjcgvAXJlkmxWPosDOTTLTrIDLhTwCKHniZMYsbzuwAkUcSnAxkpqBIetLyDUVNQxumTTZdTIvwNihAPYufyqmQTojGtENFrZpWGlAb");
    int ocDbCx = 1377444082;
    string CkfBkAbCTNV = string("VKFGzlZDIdFAromVOjFnmsztYFRUcPxqZAEjCZSXQCFdUEvIKCuOFAqoYPSGkaESxxdNauppiSYqVqfTEUU");
    bool QhRlmdzxQdZSHL = false;
    double QVJsfVBYWV = -523666.4119714187;
    bool gtSFXF = true;
    double KVWmKlSabwA = -815018.5728182129;

    for (int bOgedlAhsd = 1994828029; bOgedlAhsd > 0; bOgedlAhsd--) {
        JFhkeCG += xAgDLuhOaoAIxCq;
        JFhkeCG += CkfBkAbCTNV;
    }

    for (int kwpPIrSc = 2136788664; kwpPIrSc > 0; kwpPIrSc--) {
        continue;
    }

    for (int vhdmKUyDEzUei = 383058848; vhdmKUyDEzUei > 0; vhdmKUyDEzUei--) {
        JFhkeCG += CkfBkAbCTNV;
        uzGThfaiRGbI = CkfBkAbCTNV;
        uzGThfaiRGbI = JFhkeCG;
        QVJsfVBYWV -= jwyaGEXIHtqtbh;
    }

    return gtSFXF;
}

void DaiYcjByevfciOG::EAHZTqvoj(string RLwEXoXYxhmebGp, double pjbEmlXFz)
{
    bool NDDkPGadVhVtl = false;
    string yXUUJQkqIXmcD = string("XDSKAtWwDirfVZjFztURsfkqTeeiEXveFsvVhIcMVMQdXjkbuQCXmIisvopZvUBTePBjoYIVTITzYVmfqIkyjeesJpwDwwjS");
    bool aSpWaHhHxQ = true;
    bool hlYRzqVi = true;
    int DyyrEGEqGR = -127111631;
    bool uobDRYMdX = true;
    string tujJHDyEwEpOGmtv = string("HrNjbZDnRTQlavVMFnDhKNmLIHRXWcimWassAmnCJduHoAjKwdxqlyvSuUmwjvrzDXmuyaCfjYKhrNvgtUVRoMDFjIJuajQZmTPxZpupbuhQowPcljPSydoypjVWnKcCRTFJmFicHhSfQJhaSiNrwxZiMiWmKOxjYAcLUxGratfINGbWLCwkYULlkkxrvYDDbNc");
    string ntbytfPtKM = string("NzEpIBGRZrbvfZOLABTyMHCGQBPHMVvjFCWGwOoHcWQnJEMkCWPNXxZQmuNJjaTitreGyjbZkcOXHlWNmnZyAogqTVnmRfhoFreoYafzvavDyTJZtXmGtUuKDQmuIjdwHnkgmFbZcgAlrtcRXEKwypcBcGivqCiDKZ");
}

bool DaiYcjByevfciOG::TULQyKkVotPeuubA()
{
    bool tsjRbqmpJzKqBzkO = false;
    bool JzXEvYtm = false;
    int fbERD = -1822257665;
    bool rYIyZRBiOZjdX = false;
    string lrXBPOGdD = string("lLSolcXFmzwDjbliJPuhAZfDOABIQShhcybUHjTlSsjMzltcXvNqokVGClmWIuZnNPLPbPbBoyQXsQDOuuhpqYmMGqCFZPjIVmwhARpXAWHeimpWMpUpgbeIRZSbhqPdwCdXNNkLJJWcZvWOLPwZKfmzlznGltuUJKymrNgdUALOCmoeIKByZnigHYFBUMAxqr");
    int lihpdfcRyTcvZqIm = -1921491023;
    double dvBzgUQTB = -439249.03023571044;
    double CVEyTJmJHtB = -972900.8576253894;
    string IYhOtu = string("tvbbrBhrCxzc");

    if (tsjRbqmpJzKqBzkO != false) {
        for (int GiClEYkLs = 1587426786; GiClEYkLs > 0; GiClEYkLs--) {
            continue;
        }
    }

    for (int OrfOThDc = 770236769; OrfOThDc > 0; OrfOThDc--) {
        continue;
    }

    return rYIyZRBiOZjdX;
}

bool DaiYcjByevfciOG::wsPbenvwXetm(int PrfWLvjmOT, string dNCzlX)
{
    int KSMOvEA = 422830121;
    double IEUGeVQaazvcFK = 1019129.273564374;
    bool KVVqpjNmOFTUfjf = false;
    bool nzBrsCFc = true;
    double oWGQYDFrAgYBhZO = 697998.2924238633;
    string IfJqYTqdCgbaj = string("ZZMZrfRKNgKvtyNByxHZyWtiuvYjpXJlpomOFhCcGIlopRnZlRamwWGdYUYiZcxolnrCZGQHnWFRsvwGvPNUEIEMKGPINrEFLJhYuDigBazEmIPcEgvCSmEtVQl");
    string GHnVUUqKDZVrk = string("yGGUBDZXFYdBdWyJGnQXPbLMMeCjwVGoOtsuHPfAvusi");
    int pzcxfzehhz = -1184841002;

    for (int UlDHVNWCKogNBmh = 266479558; UlDHVNWCKogNBmh > 0; UlDHVNWCKogNBmh--) {
        continue;
    }

    if (GHnVUUqKDZVrk != string("ZZMZrfRKNgKvtyNByxHZyWtiuvYjpXJlpomOFhCcGIlopRnZlRamwWGdYUYiZcxolnrCZGQHnWFRsvwGvPNUEIEMKGPINrEFLJhYuDigBazEmIPcEgvCSmEtVQl")) {
        for (int sSojQMDpAhT = 41658356; sSojQMDpAhT > 0; sSojQMDpAhT--) {
            continue;
        }
    }

    for (int LmHkaxfJwEIhcn = 1563433236; LmHkaxfJwEIhcn > 0; LmHkaxfJwEIhcn--) {
        GHnVUUqKDZVrk = dNCzlX;
        nzBrsCFc = KVVqpjNmOFTUfjf;
        nzBrsCFc = nzBrsCFc;
        KSMOvEA += KSMOvEA;
        pzcxfzehhz += KSMOvEA;
    }

    for (int jrAvihouoopLkrqS = 1020281730; jrAvihouoopLkrqS > 0; jrAvihouoopLkrqS--) {
        oWGQYDFrAgYBhZO += IEUGeVQaazvcFK;
    }

    return nzBrsCFc;
}

bool DaiYcjByevfciOG::MvHnsS()
{
    int KoMyNz = 1457741243;
    bool PzTPBQnRYmWA = false;
    int AmaoVcKMerVQpaw = 1672605167;
    string OExhv = string("jeofzHWrXKGMNmnHlDeaflZVXEtcKTsoAcYFYUaUUedaRpVtbMIgYMagPAKZmYXTNCUcsRCeZPBVpEhvNOQuiEHoFXKhFPywgAJJPYZPQqYHVKRV");
    double PNnWIshEizWCFyno = 362311.669728975;
    string HbbNtgUmGIPbqsE = string("iaZtiRCcQxFaQLuBckBMrPLRUzBTOarbKsHwNCyrJzzFpeLPLgxUtXyVRHEVUR");
    double QLNAveyaeKIUz = 872268.8230091989;

    return PzTPBQnRYmWA;
}

void DaiYcjByevfciOG::LaPvxyHVL(int KdLea, bool JbTmDKXPtYo, bool gzDNY)
{
    bool QnHwGEZJyKVVJd = false;
    string iViPp = string("wZBtSuyQdVpUwtGhYruCLCokxDkvhNzhzDGiarSCQFcYfEb");
    int YiiEnTHR = 1755332756;
    bool dplGQWoZxhImCO = true;
    bool Nczsv = true;

    if (QnHwGEZJyKVVJd == true) {
        for (int vwihmFbQMzNPB = 1294868079; vwihmFbQMzNPB > 0; vwihmFbQMzNPB--) {
            dplGQWoZxhImCO = ! QnHwGEZJyKVVJd;
            dplGQWoZxhImCO = gzDNY;
            YiiEnTHR /= YiiEnTHR;
            dplGQWoZxhImCO = JbTmDKXPtYo;
            JbTmDKXPtYo = ! Nczsv;
            gzDNY = ! QnHwGEZJyKVVJd;
        }
    }

    for (int OPNAAfsYuHNXfNF = 312085112; OPNAAfsYuHNXfNF > 0; OPNAAfsYuHNXfNF--) {
        QnHwGEZJyKVVJd = ! Nczsv;
        Nczsv = JbTmDKXPtYo;
        gzDNY = Nczsv;
    }
}

DaiYcjByevfciOG::DaiYcjByevfciOG()
{
    this->gXWNOgAQELatEvec(-158165880, string("vpOzGKBJekUJKHufywbyKumKXnFYZSkZjFHITdVaAuZNOhUzRzkptlWXNrvBJJHUHGDYOmGJiElsWDoxrCCoucUutLHeaKbhrIEKKWRiiXKuspBaZsDgBTaqHkvcUiTAjFbudapgmGjGTxXclJlDEKOXKaFcUxckKDXJjKDCYVUEgbtMonHOjZwVbLpHK"), 727408273, -306576.77176142496);
    this->FLqiBZTzRTXuiF(string("uTbzbNVcnLuJMnXWFXBFBaNQlIPkvyGaLSPxddVDMGqOOXpmaGKZmBIhHoMvTRArJZYmxrpQJWNjYWehWoXxGlJSjrGGgJifbMjvXdbO"), 604741.6247409878, string("KFjMXhYAtamGIinoLrvxKlorMihiCsiDBDFPt"));
    this->jydOD(-1220211621, 689430910, string("joESTVAWuajCavjxJraYVLQGAjGoOakisbfImUMgFmwBNEWUkAktMMJAXKBurrbLPxwiQQpzNkSlJjhlqNkgAdEBZjEDKDOZvROkBWdTLAliUDQxSfUZlHiiiZOvyVzJtaKMMVGlQPHISzVeoaIuPdYnDDdqtAiNrdxkMjhpTBKEsxoPCCVhwIWkGaOykkUshiQRGVuZZNOcGLwQRYCdrGEo"));
    this->jQaXqMXmKlMCn(-1449084953, false, 788823.9980946445, true, 669888.7511503974);
    this->sieuaMxEtBPTqpW(-2094414630);
    this->rCGIrTmS(string("KFyvjGxUDtTRPeuuKBTbZYbrngwXCUwHaRWcUCAsqQZiswGDnJYYSvjRAHCFuYyrpSRClZflWOQajyUxxETGvxWfOaJvqNPFuhbSNNhGQcmYF"));
    this->bxEVchJA(-510421.54709533433);
    this->oiObYWuclIyyEhL();
    this->QsQaHWSjqBw(string("AijBdfJNsNDXcrgOhEjXimoRkcOfIMAeCgOARIORkHnmspKBVWHTGfmkFGtyoUIOjdqEMCPWqGysKKkNoGjUKFNyTxsVOcgMyMtraxOovhwaLPGFILNOkxuWSrRP"), -357508.3899234816, -1284187600, string("PwlTsVeUdqIvPXMarxOjzAvXAUOcYZgMBxgUmLfXKyZYSlhOsrtqDDEwyokgxcSFbOOgUtRiHQuUDAQBkSfZUPEfumZrVxMpLYSahyzqMAPkzNnjZLUlzpTWRaQpzIOfZUAudrjxvuCQjeFkJjGMDXnSdNZ"));
    this->EAHZTqvoj(string("rOWyMyTzeVXSJkEjVMdNzEDhuAAsuHzvRpAqjqjcyKVVNdXGdUFVhcnoLEHJBjnxmvqcWxVZKimMMEfatgNsdDuXLpmDPTqmVCKmaBbvruwBdPxsmVkggqwGHjcJAEDpghpWdhPBJNrafdOGZIhRMCRULeQgQCXsLdpJygMcpgyzlATYzgNfILri"), -686689.897158877);
    this->TULQyKkVotPeuubA();
    this->wsPbenvwXetm(-565288405, string("ynVkjpecqtHPIjHnuRshiJkrOAHmBldnLkJcfOXPzJNeUfonCzHoSFpBnKHyGPdRhhqphJafdLaAmTxDrHlZZpnSWudGKUiojePFLLLgQUykIQBQnXUJQAkpIAjAoKpAaiwXTxeBdTxhPasBjocZrwBRAXIXHAeEbzTGcuvmAXzWJpEFGnrbGKSBhZoHdDEhDveIWAOIWvHAPegwOdoNKSbUmSHrgkNwnLVbqDKYIBebxPajZOrsLAUz"));
    this->MvHnsS();
    this->LaPvxyHVL(-1017180637, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RSjjhEwmLDSQYNG
{
public:
    string CAyZVtRIfii;

    RSjjhEwmLDSQYNG();
    int FoVhAl(double SgnWpFPRLvVRPx, string MVqVcrSPMnPwrfQo);
    void dAagqJI(double uAmPg, bool XSnlYnpjpbEOKPp);
    bool mRPKwkLITXHi(string gXQmTDBTITzGHMVp);
    string jSSkHFpt(bool IrMqXZPhOnHRvIeH, int PVyds, double lVAjKKOXZmhErM, int PSKcgX);
    bool JXCEDOuvsOE(int oRNZpSxJg, int XYmpbCUJgFjuh, int nbmpwqDGN);
    void AAcFtf(bool pSnPjzmhdgGG, string aKgUSpIaLa);
protected:
    bool dDrBrGzj;
    double FkXrZgAi;

    int bXCSbfumh(string azRpFwlORkxapDL, double vlSNYcaVjhRaHu, string nYVPoeOhtfCXy);
    string sIorHNWSJBIvr(string FEARnRbDL, bool zXnVapdFc);
    string QNYvTgMIDGMle(double xZXsG, int AzdHqIqNEZRL, string gYzUbF, bool FgEtXeLGLVg);
    string VnpvSnXbt(double tJfCjeOkcwHU, int HyeUVdrWTRHMbJt, double cRRRxt, double MRBtodstIZzgdcF, bool SZxzxzaaFrnEGPzM);
private:
    double fYUtYYoLDrd;
    int FdnrhtgJIewdFO;
    bool gqBEds;
    double WgqFhigw;
    int gKPIMXyA;
    int kGsQwtDdjcPpd;

    bool jUeILpR(bool ewRgPYIdLaXDF, string FsSotgnQZ, int gsgiAW, string xtWeGJHIwln, string TErbfHdI);
    bool pyfMuMZtcGosyp();
};

int RSjjhEwmLDSQYNG::FoVhAl(double SgnWpFPRLvVRPx, string MVqVcrSPMnPwrfQo)
{
    int STEhJgjMqcDxeE = -1785516150;
    double ACVuuoLPT = 606572.231445657;
    double npRFyDKzyjXhKTT = 158590.10073725303;
    double xQZhSRiKfnTxR = 409632.37158199836;
    bool tfFhVdhVx = true;
    double rReZjObYXarJsWV = -541040.4265107942;
    double nwAmWty = -786428.8142896061;
    double hEHUcqDkfUpZXMT = 95574.34106419998;
    string UWGCMCBHHcyrLan = string("jMZeitMTVNGJNuFY");
    bool mepSS = false;

    for (int TZayDLjbE = 385235577; TZayDLjbE > 0; TZayDLjbE--) {
        hEHUcqDkfUpZXMT = rReZjObYXarJsWV;
    }

    for (int PcENHZxajJ = 931433141; PcENHZxajJ > 0; PcENHZxajJ--) {
        hEHUcqDkfUpZXMT += npRFyDKzyjXhKTT;
        xQZhSRiKfnTxR /= nwAmWty;
        SgnWpFPRLvVRPx *= xQZhSRiKfnTxR;
    }

    for (int DtHGTnVYYm = 1673383027; DtHGTnVYYm > 0; DtHGTnVYYm--) {
        xQZhSRiKfnTxR *= nwAmWty;
        npRFyDKzyjXhKTT /= ACVuuoLPT;
        rReZjObYXarJsWV *= npRFyDKzyjXhKTT;
        hEHUcqDkfUpZXMT = hEHUcqDkfUpZXMT;
        xQZhSRiKfnTxR *= xQZhSRiKfnTxR;
        nwAmWty = npRFyDKzyjXhKTT;
    }

    return STEhJgjMqcDxeE;
}

void RSjjhEwmLDSQYNG::dAagqJI(double uAmPg, bool XSnlYnpjpbEOKPp)
{
    double QtiqBYMb = 57905.06984696721;
    int BPHrXFRPIPJG = -603002556;
    int xlCVEL = 902258892;
    bool esfbrerwwCb = false;
    double msJqmATOMNxxnZCU = -960145.3295926236;
    bool CIFSZxxocvlcjX = true;
    bool ikGKXMT = false;
    bool LYzJYMPRIwb = true;

    for (int pGIFTBqDFK = 1901683812; pGIFTBqDFK > 0; pGIFTBqDFK--) {
        continue;
    }

    if (esfbrerwwCb == true) {
        for (int lsKzpfxWuws = 252740952; lsKzpfxWuws > 0; lsKzpfxWuws--) {
            QtiqBYMb += QtiqBYMb;
        }
    }

    for (int ZOeGnjNxmsvEPo = 1528482201; ZOeGnjNxmsvEPo > 0; ZOeGnjNxmsvEPo--) {
        ikGKXMT = ! LYzJYMPRIwb;
    }

    for (int QpArcVtogdxwDTf = 1687938223; QpArcVtogdxwDTf > 0; QpArcVtogdxwDTf--) {
        LYzJYMPRIwb = ! LYzJYMPRIwb;
        XSnlYnpjpbEOKPp = ! ikGKXMT;
        XSnlYnpjpbEOKPp = LYzJYMPRIwb;
    }

    for (int zNQoCLWSjp = 1242631493; zNQoCLWSjp > 0; zNQoCLWSjp--) {
        CIFSZxxocvlcjX = ikGKXMT;
        ikGKXMT = XSnlYnpjpbEOKPp;
        ikGKXMT = ! esfbrerwwCb;
        QtiqBYMb -= msJqmATOMNxxnZCU;
    }

    for (int jSruRGXnrTCrHyY = 164100018; jSruRGXnrTCrHyY > 0; jSruRGXnrTCrHyY--) {
        uAmPg *= QtiqBYMb;
        CIFSZxxocvlcjX = ! XSnlYnpjpbEOKPp;
    }

    for (int APDdrSjpQtSAWemS = 1292928237; APDdrSjpQtSAWemS > 0; APDdrSjpQtSAWemS--) {
        XSnlYnpjpbEOKPp = XSnlYnpjpbEOKPp;
        XSnlYnpjpbEOKPp = LYzJYMPRIwb;
        LYzJYMPRIwb = ! ikGKXMT;
    }
}

bool RSjjhEwmLDSQYNG::mRPKwkLITXHi(string gXQmTDBTITzGHMVp)
{
    string JiTPd = string("WjypxSOVpLPvetLqKbZzUaZYPwtsrgpguszZnTkYmrYYecphudIfXfVahxqQQtCKdDCXaIMDmPbyfsbgoeWJSUMrxwaYtgBhsrDltbrBJcLEtYkOGJxaMwhSnlBPwNBEaUbVYvwWPefUtWmmPaonDKrivMfcQTNacCpJEtrNqNGYIEIEQDhsBXKMNFJmhYso");
    bool tiMeRsanQ = true;
    int uewCF = -915970837;
    int MUkCVl = -1334009381;
    string zTAcRhBFHOVGFW = string("McIsLxUyDfgHGwAzvgIOCZhFyktAYBlZjWkYpkbXqqIlvIeAeszpJwDIiyhhucMAmTomNdGsMdLcqArUZPaKGpZbEYPpeZRxzHWiQcucrvdIIwHFBzazDWZuEHkgopZpBsiHagxkcmkegJHDUFvsZLMLeiWYnYDfGCYJQKBBPYmNuQHSWiOesRaBjSpDhfycnneAnyTFEzDKRmQRqrtNxlKBOykfaGUiinCILcVUZUpTpFpqdZcELbWCmyZyQ");
    int MOetRGaSm = 1058339178;
    int pAHtfzdiB = 485743292;

    for (int EOKodcbLjdo = 240361932; EOKodcbLjdo > 0; EOKodcbLjdo--) {
        uewCF -= pAHtfzdiB;
    }

    for (int ehIXkX = 1090039808; ehIXkX > 0; ehIXkX--) {
        MOetRGaSm += MUkCVl;
        gXQmTDBTITzGHMVp += JiTPd;
    }

    if (JiTPd >= string("WjypxSOVpLPvetLqKbZzUaZYPwtsrgpguszZnTkYmrYYecphudIfXfVahxqQQtCKdDCXaIMDmPbyfsbgoeWJSUMrxwaYtgBhsrDltbrBJcLEtYkOGJxaMwhSnlBPwNBEaUbVYvwWPefUtWmmPaonDKrivMfcQTNacCpJEtrNqNGYIEIEQDhsBXKMNFJmhYso")) {
        for (int ASGlq = 466220320; ASGlq > 0; ASGlq--) {
            gXQmTDBTITzGHMVp += gXQmTDBTITzGHMVp;
            MOetRGaSm -= uewCF;
            MOetRGaSm = pAHtfzdiB;
            MUkCVl -= uewCF;
            uewCF *= pAHtfzdiB;
        }
    }

    for (int GTAITJ = 2130190055; GTAITJ > 0; GTAITJ--) {
        JiTPd = gXQmTDBTITzGHMVp;
        zTAcRhBFHOVGFW += JiTPd;
        uewCF -= pAHtfzdiB;
        uewCF = MUkCVl;
    }

    return tiMeRsanQ;
}

string RSjjhEwmLDSQYNG::jSSkHFpt(bool IrMqXZPhOnHRvIeH, int PVyds, double lVAjKKOXZmhErM, int PSKcgX)
{
    double raKXSJ = 993752.8343136531;
    string IcjWnRI = string("cqMjQXnFN");

    for (int CmSxTztHCTylyI = 400229909; CmSxTztHCTylyI > 0; CmSxTztHCTylyI--) {
        PSKcgX /= PSKcgX;
        raKXSJ = raKXSJ;
        raKXSJ /= raKXSJ;
        PSKcgX = PVyds;
    }

    if (raKXSJ < 993752.8343136531) {
        for (int eKaWOTVWHjcA = 1121112967; eKaWOTVWHjcA > 0; eKaWOTVWHjcA--) {
            IrMqXZPhOnHRvIeH = IrMqXZPhOnHRvIeH;
            IrMqXZPhOnHRvIeH = IrMqXZPhOnHRvIeH;
        }
    }

    for (int kPOYRLTByDWXWSu = 696122000; kPOYRLTByDWXWSu > 0; kPOYRLTByDWXWSu--) {
        continue;
    }

    return IcjWnRI;
}

bool RSjjhEwmLDSQYNG::JXCEDOuvsOE(int oRNZpSxJg, int XYmpbCUJgFjuh, int nbmpwqDGN)
{
    double aHAXZjunKVxgMmZ = 422906.2087926706;
    double bhXflfyhsyubxcR = -631461.1578985781;
    double JGqQbAZRfOl = 821254.8340168475;
    double jgpkWIfJEL = 477183.63131364435;
    int wRWchamSsEHFnrGn = -223911809;
    int iQcDfoRzMICyCN = -1317254187;
    double hLdYRQtUs = 270620.1914598332;
    bool kccejzmnwhQC = false;
    int KVwbAbNNGCeN = 37078326;

    if (oRNZpSxJg <= 364021543) {
        for (int hzLTYpP = 1131400691; hzLTYpP > 0; hzLTYpP--) {
            hLdYRQtUs *= jgpkWIfJEL;
            wRWchamSsEHFnrGn *= nbmpwqDGN;
            JGqQbAZRfOl *= bhXflfyhsyubxcR;
            JGqQbAZRfOl += bhXflfyhsyubxcR;
        }
    }

    for (int sDxQBpHTo = 573455225; sDxQBpHTo > 0; sDxQBpHTo--) {
        XYmpbCUJgFjuh /= nbmpwqDGN;
        bhXflfyhsyubxcR /= hLdYRQtUs;
        hLdYRQtUs /= JGqQbAZRfOl;
        aHAXZjunKVxgMmZ -= aHAXZjunKVxgMmZ;
    }

    for (int ocVGTPbZ = 388930484; ocVGTPbZ > 0; ocVGTPbZ--) {
        iQcDfoRzMICyCN -= nbmpwqDGN;
        hLdYRQtUs *= bhXflfyhsyubxcR;
        hLdYRQtUs = JGqQbAZRfOl;
        hLdYRQtUs *= hLdYRQtUs;
        nbmpwqDGN /= KVwbAbNNGCeN;
    }

    for (int PTfZiSKKKVAV = 1199158630; PTfZiSKKKVAV > 0; PTfZiSKKKVAV--) {
        hLdYRQtUs = jgpkWIfJEL;
        nbmpwqDGN += KVwbAbNNGCeN;
    }

    for (int GQMqCrLVvnK = 2013943582; GQMqCrLVvnK > 0; GQMqCrLVvnK--) {
        XYmpbCUJgFjuh -= KVwbAbNNGCeN;
    }

    return kccejzmnwhQC;
}

void RSjjhEwmLDSQYNG::AAcFtf(bool pSnPjzmhdgGG, string aKgUSpIaLa)
{
    double uBSvTRtHjuHXR = -186571.7123203235;
    string HJnkNsDJPlcuLOS = string("mJZCBHKJKtIKTAHdICMOjBlNDnqfAMzBWoOVHHDLoyNya");
    bool pXNQUxeSgCRlotks = true;
    bool baIrw = true;
    bool NEJTjRi = true;
    bool WkVmkdq = false;
    bool tzFUa = true;
    double wfMDmtxMfZwL = 645491.9595701505;
}

int RSjjhEwmLDSQYNG::bXCSbfumh(string azRpFwlORkxapDL, double vlSNYcaVjhRaHu, string nYVPoeOhtfCXy)
{
    int mZulFkm = 1904475265;
    bool OQYjwhlG = true;
    bool EKxae = false;
    bool HVsdhvIOqQ = false;

    for (int JduUTqGpcFZYO = 1184994011; JduUTqGpcFZYO > 0; JduUTqGpcFZYO--) {
        HVsdhvIOqQ = ! OQYjwhlG;
    }

    for (int TXuiYdB = 331014251; TXuiYdB > 0; TXuiYdB--) {
        EKxae = HVsdhvIOqQ;
        mZulFkm -= mZulFkm;
        HVsdhvIOqQ = ! HVsdhvIOqQ;
        OQYjwhlG = HVsdhvIOqQ;
    }

    return mZulFkm;
}

string RSjjhEwmLDSQYNG::sIorHNWSJBIvr(string FEARnRbDL, bool zXnVapdFc)
{
    double ARkproAvbon = -81810.76608373757;
    string kJxlDZeU = string("ZJlcmKVAXEduCXsDPQWPilkiqVvxlGxCWPTdbWgxyhoGHQJSnVHzYjlTKFoXHiSpbiHCytkZwrILajDcCeXfOBnhPFnQJspgwdIDaTzuKDNqCCvXxNxcQSJFGgzVKyPcQXLJmDJSAKRvUVRJyTjuwLNwTWhINgtvigKumQrmSuUfqmkPlEHxgHDvbrITymCOPiLYKTc");
    bool ZTrCsxlHUvQ = false;

    for (int YGolQ = 597634801; YGolQ > 0; YGolQ--) {
        ZTrCsxlHUvQ = ! zXnVapdFc;
    }

    return kJxlDZeU;
}

string RSjjhEwmLDSQYNG::QNYvTgMIDGMle(double xZXsG, int AzdHqIqNEZRL, string gYzUbF, bool FgEtXeLGLVg)
{
    int UzjEtyKQ = 2017729048;
    int ZSVekHRe = 108890567;
    bool bVqJjZUTD = true;
    string EXvVhkUTiwP = string("fSMHoGsiWwaQpzrAsuVncPXRsDQwjQwHiEMbxEwPVndrVrTtwaAWpLXrPVcXBoooNQoSLoYLGmjzNDSQBVpzjuVwVyzVydpIizqPbvnojnBOBNDBgzkAzXrOqObQkonMMDIcqYukJowYklIdtwTsdqdJKGTGDzLFDQMZxwjRslGNatqY");
    string BcdcQTrhytAc = string("DojWrBuYKlzahjzaNHhRGXptzuiGEINwKfrACkSuMmSlHWuZoHNlUCMovdioypQcpZTliGcmACrlvZpouFkWfxlhQfWBxfiiCsutgfnKJIkvUPWRXQiwjgHvXOWfDhwjx");
    bool IHeazsUAkgHlFeQ = true;

    for (int OAiMqNjEqfWM = 1897648151; OAiMqNjEqfWM > 0; OAiMqNjEqfWM--) {
        BcdcQTrhytAc += BcdcQTrhytAc;
        EXvVhkUTiwP += BcdcQTrhytAc;
        ZSVekHRe *= AzdHqIqNEZRL;
        FgEtXeLGLVg = bVqJjZUTD;
        FgEtXeLGLVg = ! FgEtXeLGLVg;
    }

    for (int QmwBxuxkmwAiHic = 906871802; QmwBxuxkmwAiHic > 0; QmwBxuxkmwAiHic--) {
        bVqJjZUTD = IHeazsUAkgHlFeQ;
        IHeazsUAkgHlFeQ = ! IHeazsUAkgHlFeQ;
    }

    for (int GIvMlo = 997775485; GIvMlo > 0; GIvMlo--) {
        IHeazsUAkgHlFeQ = ! bVqJjZUTD;
        UzjEtyKQ *= ZSVekHRe;
        BcdcQTrhytAc = BcdcQTrhytAc;
    }

    return BcdcQTrhytAc;
}

string RSjjhEwmLDSQYNG::VnpvSnXbt(double tJfCjeOkcwHU, int HyeUVdrWTRHMbJt, double cRRRxt, double MRBtodstIZzgdcF, bool SZxzxzaaFrnEGPzM)
{
    string gkoWqBmandOQDPBf = string("KKonUKSxPUZBXpTPovhZYPZIGmvlYHbXbuRqSnEvKGmBKqMTHDsDnLRfgDyNqyOhfbLHiEiAY");
    double zQhOyfprLzACrH = -237222.64086878684;
    double pXqvc = 780498.0260879399;
    bool mjQui = false;
    double IPAQWtzMjzqbtto = 882236.6465662307;
    int MTFTFLhdeWkJc = 407801555;

    for (int ZVVCKqDoyg = 813944402; ZVVCKqDoyg > 0; ZVVCKqDoyg--) {
        MRBtodstIZzgdcF += MRBtodstIZzgdcF;
        tJfCjeOkcwHU += pXqvc;
    }

    if (zQhOyfprLzACrH < 743628.392019487) {
        for (int jhFKpOKcluD = 1262394027; jhFKpOKcluD > 0; jhFKpOKcluD--) {
            pXqvc *= cRRRxt;
            zQhOyfprLzACrH = MRBtodstIZzgdcF;
        }
    }

    if (zQhOyfprLzACrH >= -47571.46434707149) {
        for (int RAXEMunxEbjYJ = 461949176; RAXEMunxEbjYJ > 0; RAXEMunxEbjYJ--) {
            tJfCjeOkcwHU *= zQhOyfprLzACrH;
            cRRRxt /= zQhOyfprLzACrH;
        }
    }

    for (int PMVwQkhEMMBG = 352470860; PMVwQkhEMMBG > 0; PMVwQkhEMMBG--) {
        cRRRxt -= IPAQWtzMjzqbtto;
        mjQui = ! mjQui;
        zQhOyfprLzACrH /= MRBtodstIZzgdcF;
        zQhOyfprLzACrH += cRRRxt;
        HyeUVdrWTRHMbJt += HyeUVdrWTRHMbJt;
        zQhOyfprLzACrH -= cRRRxt;
    }

    return gkoWqBmandOQDPBf;
}

bool RSjjhEwmLDSQYNG::jUeILpR(bool ewRgPYIdLaXDF, string FsSotgnQZ, int gsgiAW, string xtWeGJHIwln, string TErbfHdI)
{
    int oeEPuUVGuQvqjs = 154040360;
    bool pvkvqD = true;
    string SQZwFJPOU = string("bnaCACJWBdWbSSoLcsVtSIKbmQyGIAQIYvbyrlhsnJKVooOWQgMAPoCkJVMaFETHbxFurbDiPyiVzcDNYELKlfHenLYAMyrjrcUGtfqTVYgYEkBCPefnYPAckKZWrwbTpSmsqlKBPjfGOcdUCPRtGZUljQzqGrWUJEGwKCgQtKbvWLTHjRtNxXuVNiUIINbemOkqoJfhMqdXOKLjqwtABSIKYsFFDtHNuxKgklZNTwRGVUSoUoPkOCC");

    for (int dEtDkGoqVyXK = 781798899; dEtDkGoqVyXK > 0; dEtDkGoqVyXK--) {
        TErbfHdI = xtWeGJHIwln;
        pvkvqD = ! pvkvqD;
        SQZwFJPOU = TErbfHdI;
        gsgiAW -= oeEPuUVGuQvqjs;
        pvkvqD = ewRgPYIdLaXDF;
        xtWeGJHIwln += FsSotgnQZ;
    }

    return pvkvqD;
}

bool RSjjhEwmLDSQYNG::pyfMuMZtcGosyp()
{
    double OqDWGitWfFlzLxHh = 8712.637514131511;
    int NVhFqWze = 481088164;
    bool nbYwdXBZHHf = true;
    int ylCqvCU = -2052615823;
    string eIJnUFSLuwmKKb = string("zwDQqYrsvQMMufqQgHbDwXqToqhMkfoNNQLLYIFPRUmInchlrWAdhPwrJtAGkGGnvHYTHcMcTUpMEuBSyhjvlZeMnrIwPlNninjbrarppMoIrDrvVssKMDNwvhrWCfhHFeWgHceCGaABREJDOQsbvXZPqZfkRKgUJoop");
    string WRvqAZEO = string("TBBmQgbfxMGoBxzYKnyxATwaiQHUSyjCZmbNZkUNoPcccLifupkmDhMjOsysSaBynDoxpnFrBdSpEWJYhNurtiuyHwhATduIaWqBVFwmRfRzmHWLSiJaVjuttbiFcJkILSTnrqTsJefVi");
    double kanamEivgmkZp = -692747.785191186;
    double MATzFCQkwY = -723095.3162703773;

    for (int mlnoscTrn = 222957648; mlnoscTrn > 0; mlnoscTrn--) {
        eIJnUFSLuwmKKb = eIJnUFSLuwmKKb;
    }

    if (kanamEivgmkZp <= 8712.637514131511) {
        for (int CeIWrJUl = 1335520482; CeIWrJUl > 0; CeIWrJUl--) {
            kanamEivgmkZp -= kanamEivgmkZp;
            kanamEivgmkZp /= OqDWGitWfFlzLxHh;
            OqDWGitWfFlzLxHh += OqDWGitWfFlzLxHh;
            nbYwdXBZHHf = nbYwdXBZHHf;
        }
    }

    for (int oudVXcaOnojKj = 570595578; oudVXcaOnojKj > 0; oudVXcaOnojKj--) {
        continue;
    }

    return nbYwdXBZHHf;
}

RSjjhEwmLDSQYNG::RSjjhEwmLDSQYNG()
{
    this->FoVhAl(-668155.4615725061, string("zdQdIWRmWHSZLagjgrtLtg"));
    this->dAagqJI(603787.6654785384, false);
    this->mRPKwkLITXHi(string("ITLGtFjafZpBBZdCeiCOdpdUcNWwwGDIOaGvnjzjPOeLQFZuMaOcNLaKABIhZiecCogshcdTviMqjIqysRccLPxeUQCAxFsnFQOwWCpURyjBHh"));
    this->jSSkHFpt(false, -517143349, -386152.87330825604, -1725285585);
    this->JXCEDOuvsOE(1167649263, 1148282257, 364021543);
    this->AAcFtf(true, string("HoyCnqmyTLfOeOSgqoglJyjNugDCkgkKEzlnSCSMaYFmbDKLGdZqjAgSgZLvauoHkEUqFoNtwxrnrjQWJZuQZoUFlwFnDtUSJSTOvKlCPfyySrEpaKdqGRuEKqawrFVUsWwxXwqdtlLwfcgMzhLUmeCtunJgJrijfwlTywgWKTZaYFkbAqVFtlitWkGJtnxpkbWIDmYyNkkTMkHzSBcopbA"));
    this->bXCSbfumh(string("ZNlMSOIpXyUzwbISYsuhEZrYnIqCcDwwFMOTKfvMmcoGEZPAWPicNIdWBwEisCTHtaOjptfWilotPTOBDBCAZzOpMiShhCfIPnQvHiZnjTVUBLodHkLdflSDscKIcmsGqctbBTbSiubWKvuwdCoLIvUMcNHjpTofECYLIbBLAnGWKtLnFb"), -1031312.305723469, string("RjwGDGuOVukKXZZVYTqmjcVbhdivVzcIKuGNUYOHvbwxzKoFdxYZW"));
    this->sIorHNWSJBIvr(string("BRqRlRYGekQLgQpkwsIVwBxwccUVNFGNAYeCsqqoOLXBmotRQoEmoRwUVgPNGBUFbQdPOlHRadwTqzQBN"), true);
    this->QNYvTgMIDGMle(314554.54315435723, -2086322277, string("WCneebXzxWFZMNqrfTJAsfFgBYwhCBzuIJYiwaIUarWohReNMuYbcfnQutckzYFcWGDsZGNyTbhxoYTOnQkvxKqhjSwLJPJFXSZejKgayKJhmjrdDKdbZzUpVCwhuACyRsTpbnDoMdtOajEILscmLZdDoXUbxdInnTOuMXFfmPpYcejhTCuhzwLnfwqxZVYikEoSXwHGxVtTWSHvtiIRXYVjzUMPyihNP"), true);
    this->VnpvSnXbt(-47571.46434707149, 1616695964, 743628.392019487, 543564.156684394, true);
    this->jUeILpR(true, string("CxMXhbfMjubowLkowpuYWzzTnlAnPtsxZeAxOBJscRmvaVKdawKIKUylpcsRbjTJwKBezlvQQOQoSnyyyZsPNUtXlBRxAaoIkrPjNsjwuuydsHPmIcFTFePrOntmNlJhNPddAdHeBoqlvbQzXaakKKrwYkEkQcnSlWaTGHvYFfOPvWEfcQEsKXtyGaueaubKKuiffANMmWaXvcBZSmuEaDB"), 1431149892, string("WswDWcBiFToD"), string("JTRztlXFeuRqUvPwuYjMavWhAqwBSiNSrxFemSiEVTaeVghMJfKGXBWplntWzHVMZSPXIMgbALjNwcVzvTmDUrxlopsEzVDjyKOOATtRRzpKCFAObdLKVNFEYNytZTZbVpHXVgAckqFvKyoHtAKKFITgDOsNehxNPIHGhMgBXocGyYkSpcLzHVjyzhVvbVOYVqBFFhCIOrSuSPoMLrOZiW"));
    this->pyfMuMZtcGosyp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XmZfXRLHmGT
{
public:
    string DtsCycDsIHehbRAb;
    bool uIkEGjDOSggh;
    double ROtWeJesLcvEDj;

    XmZfXRLHmGT();
    double siEdIrBAu(string tLLefNdjuHybIbhX);
    string apPtIqc(int AMQqywlKGOsk, string MerVt);
protected:
    int DCrFFvDE;
    bool yAXsJK;
    string nmYnyEvLdLd;
    double sKScSWjcAF;
    int ojukGoTNiYi;
    bool hIUqCGc;

private:
    int DrOEw;

    int rlkzlgWxOBTKI(int FuiNIhNXvyOQi, int VkzFgdgVGKIOyveM, string xQYfpKRdRiRQ);
    bool EUNfVHWxs();
    double LvHPSZbbmTuzpapw(int JGgWBinyPCVlYw, double eXXFsxGZqQpWc);
    string uGIWnbTkIuvu(string pFGZGU);
};

double XmZfXRLHmGT::siEdIrBAu(string tLLefNdjuHybIbhX)
{
    int HiHDvincIYGVzM = -1961626355;
    double EEZHOdTHKq = 271055.83104208205;
    int JvSYEXRZXvWMPW = 1007598486;
    int JdmRTLk = -691421423;
    double VGNHo = -565330.1721687759;
    string VrSALNzpTqtfyfL = string("DiuEuQQaYocTEwMDJXhgrqkcMmwfTWWaOskHgvAerRtLpDxaIDMmHeuyLGyUqGAgUuQxNnruJlgzipsXTQWyeDNqDahqbvvwbNhc");
    int mxVbfZBLl = -699288214;
    int hCuqR = -1115066576;

    return VGNHo;
}

string XmZfXRLHmGT::apPtIqc(int AMQqywlKGOsk, string MerVt)
{
    bool afjBEtVWb = false;
    int cIiNiGBxCNZ = 1753806981;
    double nvSFjFPRp = 154067.27503709367;
    int xQWzxZsdRaVVQQY = 1197105145;
    int XJrlGpwM = -789739045;
    int OrUbZ = 2088997419;
    string TyTOs = string("BRqfxmTDinanTAXWCofdyrdPxuVfCAaoYvaDwykXjTDDKncmKIKoGLAehafyGHPnbJttGcFGoYpstFnazJPtFcbaddMuNuTbsrRgiAqftBSPbeSaGXG");

    if (OrUbZ <= 1197105145) {
        for (int thljvvTloEByoD = 666544467; thljvvTloEByoD > 0; thljvvTloEByoD--) {
            xQWzxZsdRaVVQQY += OrUbZ;
            XJrlGpwM += xQWzxZsdRaVVQQY;
        }
    }

    if (XJrlGpwM == 1753806981) {
        for (int dtjxtFmpmAi = 589560779; dtjxtFmpmAi > 0; dtjxtFmpmAi--) {
            OrUbZ += cIiNiGBxCNZ;
            AMQqywlKGOsk /= cIiNiGBxCNZ;
            MerVt = TyTOs;
            XJrlGpwM += cIiNiGBxCNZ;
            OrUbZ *= OrUbZ;
            cIiNiGBxCNZ += XJrlGpwM;
            OrUbZ *= XJrlGpwM;
        }
    }

    for (int ysdoxx = 903441346; ysdoxx > 0; ysdoxx--) {
        TyTOs = TyTOs;
        AMQqywlKGOsk -= OrUbZ;
        OrUbZ = XJrlGpwM;
    }

    for (int dHHOnJge = 1377825156; dHHOnJge > 0; dHHOnJge--) {
        OrUbZ /= AMQqywlKGOsk;
        xQWzxZsdRaVVQQY = AMQqywlKGOsk;
        cIiNiGBxCNZ *= OrUbZ;
        OrUbZ -= OrUbZ;
    }

    for (int woPYiGqViu = 120587684; woPYiGqViu > 0; woPYiGqViu--) {
        xQWzxZsdRaVVQQY /= XJrlGpwM;
        xQWzxZsdRaVVQQY -= XJrlGpwM;
        TyTOs += TyTOs;
        afjBEtVWb = ! afjBEtVWb;
        AMQqywlKGOsk = xQWzxZsdRaVVQQY;
    }

    return TyTOs;
}

int XmZfXRLHmGT::rlkzlgWxOBTKI(int FuiNIhNXvyOQi, int VkzFgdgVGKIOyveM, string xQYfpKRdRiRQ)
{
    double akmYcyJldpoX = 656223.0135172938;
    double ssvDY = -537047.7293799262;
    double crPifbSrzNuM = 522527.38530588197;
    int pCsZruLEnuoURflX = 1555619743;

    for (int yLollhxfKLtMgN = 1963777356; yLollhxfKLtMgN > 0; yLollhxfKLtMgN--) {
        crPifbSrzNuM += akmYcyJldpoX;
    }

    for (int ZPCYMxqx = 525448752; ZPCYMxqx > 0; ZPCYMxqx--) {
        continue;
    }

    for (int gSMVDjoqNNrSCG = 304308285; gSMVDjoqNNrSCG > 0; gSMVDjoqNNrSCG--) {
        continue;
    }

    for (int kGQGHk = 1133111505; kGQGHk > 0; kGQGHk--) {
        VkzFgdgVGKIOyveM += VkzFgdgVGKIOyveM;
    }

    return pCsZruLEnuoURflX;
}

bool XmZfXRLHmGT::EUNfVHWxs()
{
    double YmbYIZpY = 731279.6572570612;
    bool KbztLDTMphqwH = false;
    string AxpLqYaBtWiJSdv = string("QpIoAacnModgukghpntrbyAdPSMQTjdPETXAQvyUbQVKoDCMwRlDcdwdPtWsFjQixGooabtyAgtBGWqGzcXgXWMQovpeezFfLIQwFhOrxIzDfbLwRPOurHhjOLochSpKDpqwyuYZgODdqAMQXSFiEHJtfRJdWmAGdleWKGKtnfgpfvRAUnbmXiF");
    bool HoBOdsAeyjUjuTrk = false;
    bool AIgeXfJxpgxv = true;
    double cPFYLZ = -81432.95296731874;
    string CbJeJhqVIbXEJJcp = string("KkYKSSCUscwRRCMfAmqDwbGxJbAUaUMzHFIDobfLEHMWlmpjPaWnegWLVvkiBsBYaKqikJZexBMQzppGwcnwuMpr");
    string zUymIRe = string("kpusUOHZSuxgOOuOdtrWsXpYPWFaZADtkPcRBPWrrCajmImzdGzpJWFLJBbdZpaiPUIDGWRGzwMakPDAAyyMdRgaaAGBqTzmxvtXWldEeGWyRSMNAHgRkwONLeCEGiJiLXcEnXWaPfQtDSLoMuwMiOXooHYBmKMEJyetKNeJiPneNTjHvHIDrxlMtyXUZlJoONCVXTGtOILyhAGcDPeajphjIkNligjhlWkFfuFVgixiBYUHaFGFvRLp");

    for (int DCXpVNmTOY = 1323973085; DCXpVNmTOY > 0; DCXpVNmTOY--) {
        continue;
    }

    for (int MbWTvHFMtRBo = 539092631; MbWTvHFMtRBo > 0; MbWTvHFMtRBo--) {
        continue;
    }

    if (CbJeJhqVIbXEJJcp != string("QpIoAacnModgukghpntrbyAdPSMQTjdPETXAQvyUbQVKoDCMwRlDcdwdPtWsFjQixGooabtyAgtBGWqGzcXgXWMQovpeezFfLIQwFhOrxIzDfbLwRPOurHhjOLochSpKDpqwyuYZgODdqAMQXSFiEHJtfRJdWmAGdleWKGKtnfgpfvRAUnbmXiF")) {
        for (int xruhltvcUfQ = 719850407; xruhltvcUfQ > 0; xruhltvcUfQ--) {
            cPFYLZ *= YmbYIZpY;
        }
    }

    if (KbztLDTMphqwH != false) {
        for (int ZvnVfDpXocM = 2114959018; ZvnVfDpXocM > 0; ZvnVfDpXocM--) {
            AIgeXfJxpgxv = HoBOdsAeyjUjuTrk;
            YmbYIZpY *= YmbYIZpY;
        }
    }

    for (int BtGwLoK = 1494968657; BtGwLoK > 0; BtGwLoK--) {
        zUymIRe += AxpLqYaBtWiJSdv;
    }

    for (int OJxTiIAKXOQqrtyt = 66028741; OJxTiIAKXOQqrtyt > 0; OJxTiIAKXOQqrtyt--) {
        AxpLqYaBtWiJSdv += CbJeJhqVIbXEJJcp;
    }

    return AIgeXfJxpgxv;
}

double XmZfXRLHmGT::LvHPSZbbmTuzpapw(int JGgWBinyPCVlYw, double eXXFsxGZqQpWc)
{
    int RTblb = 1792404060;
    int xTBhbhWVRYJBXiI = 873000030;
    bool fhYcUUzjQhY = false;
    bool mGKnJGQuAcOOV = true;
    double mMXtVKCApA = 395933.41774809884;
    int hGfsSeYFkLwhnIa = 392283376;
    double JnAcSoer = 899558.7729349539;

    if (JGgWBinyPCVlYw < -1478267094) {
        for (int MeRiyszP = 1952981108; MeRiyszP > 0; MeRiyszP--) {
            JGgWBinyPCVlYw += JGgWBinyPCVlYw;
        }
    }

    return JnAcSoer;
}

string XmZfXRLHmGT::uGIWnbTkIuvu(string pFGZGU)
{
    bool HtOXuLg = false;
    double kNAGCWMSysoY = 175837.79225202816;
    string GOgagU = string("HOIsTlQvlFxBSssZjXpWNsOuZpcAPYfHWTHMZUkzNSFKwMJMDMFTrBLFsmeTQHmUZoBBfQvwFnCNkHqpVFvlaSrLoTgtDcNrMVdvBKvzcabYxIksDACBHDDMJqVsmJZnVRuIgODFxYtaftvnBLrgHhmcCdolGq");
    double bifLKIFsR = 940909.0045273192;
    bool oLwrNe = false;
    double jdPEQQUZyXm = 620101.8061909938;
    bool ztKAXIOhcPh = false;
    string rKMQLtIp = string("YDzBYOZutrvaoSGuMkvmsFwVzFVdANAXgipFZNyScHeTmsUuYZdrKmJ");
    int myZkjzGbYvG = 375770774;
    string FPGFypwgEO = string("lyL");

    for (int ABXGjjtooo = 1110287710; ABXGjjtooo > 0; ABXGjjtooo--) {
        FPGFypwgEO = GOgagU;
        ztKAXIOhcPh = ! HtOXuLg;
    }

    for (int ImCeaZHugky = 2009948278; ImCeaZHugky > 0; ImCeaZHugky--) {
        FPGFypwgEO = GOgagU;
        kNAGCWMSysoY = bifLKIFsR;
    }

    for (int HhdTkOcHFIlQBjb = 715495657; HhdTkOcHFIlQBjb > 0; HhdTkOcHFIlQBjb--) {
        rKMQLtIp = GOgagU;
    }

    for (int mZmAuFUor = 250491339; mZmAuFUor > 0; mZmAuFUor--) {
        jdPEQQUZyXm += kNAGCWMSysoY;
        oLwrNe = ztKAXIOhcPh;
    }

    return FPGFypwgEO;
}

XmZfXRLHmGT::XmZfXRLHmGT()
{
    this->siEdIrBAu(string("ShIZSvGGguwyMClyHUhhHNjZANb"));
    this->apPtIqc(-1753659288, string("GUSpRkjHdceagGHnhroskYolNkhPSsTQnLEzGjxFNmIKzzIIBVJNxVRCtupMgVoNFP"));
    this->rlkzlgWxOBTKI(-1352477085, -601359366, string("ikwafSAtGERDwrdVLFfWKyvKMDXkSCYylqgIUomAhCSOHHSzbgYDGUoSiazrDwVNLjBJMYsgjHDissxnqJyXzjybWXhHfleykHsTBEClqqhcHKIjTdkBFiqCjxrgXTUevGexXBUDFzyBGJeyQCBNhuXAQICTDbWYHNRGbZfVfVFMktdFlKUcEIwqs"));
    this->EUNfVHWxs();
    this->LvHPSZbbmTuzpapw(-1478267094, -106651.80189530662);
    this->uGIWnbTkIuvu(string("GgkzNuRWlTmNfZKEcbqMtIoKhmnqdFPYeFLjlCbmzooYZhHNXGKsUsIpgveJ"));
}
