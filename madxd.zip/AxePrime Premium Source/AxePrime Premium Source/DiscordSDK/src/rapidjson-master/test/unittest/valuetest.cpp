// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/document.h"
#include <algorithm>

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(c++98-compat)
#endif

using namespace rapidjson;

TEST(Value, Size) {
    if (sizeof(SizeType) == 4) {
#if RAPIDJSON_48BITPOINTER_OPTIMIZATION
        EXPECT_EQ(16u, sizeof(Value));
#elif RAPIDJSON_64BIT
        EXPECT_EQ(24u, sizeof(Value));
#else
        EXPECT_EQ(16u, sizeof(Value));
#endif
    }
}

TEST(Value, DefaultConstructor) {
    Value x;
    EXPECT_EQ(kNullType, x.GetType());
    EXPECT_TRUE(x.IsNull());

    //std::cout << "sizeof(Value): " << sizeof(x) << std::endl;
}

// Should not pass compilation
//TEST(Value, copy_constructor) {
//  Value x(1234);
//  Value y = x;
//}

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS

#if 0 // Many old compiler does not support these. Turn it off temporaily.

#include <type_traits>

TEST(Value, Traits) {
    typedef GenericValue<UTF8<>, CrtAllocator> Value;
    static_assert(std::is_constructible<Value>::value, "");
    static_assert(std::is_default_constructible<Value>::value, "");
#ifndef _MSC_VER
    static_assert(!std::is_copy_constructible<Value>::value, "");
#endif
    static_assert(std::is_move_constructible<Value>::value, "");

#ifndef _MSC_VER
    static_assert(std::is_nothrow_constructible<Value>::value, "");
    static_assert(std::is_nothrow_default_constructible<Value>::value, "");
    static_assert(!std::is_nothrow_copy_constructible<Value>::value, "");
    static_assert(std::is_nothrow_move_constructible<Value>::value, "");
#endif

    static_assert(std::is_assignable<Value,Value>::value, "");
#ifndef _MSC_VER
    static_assert(!std::is_copy_assignable<Value>::value, "");
#endif
    static_assert(std::is_move_assignable<Value>::value, "");

#ifndef _MSC_VER
    static_assert(std::is_nothrow_assignable<Value, Value>::value, "");
#endif
    static_assert(!std::is_nothrow_copy_assignable<Value>::value, "");
#ifndef _MSC_VER
    static_assert(std::is_nothrow_move_assignable<Value>::value, "");
#endif

    static_assert(std::is_destructible<Value>::value, "");
#ifndef _MSC_VER
    static_assert(std::is_nothrow_destructible<Value>::value, "");
#endif
}

#endif

TEST(Value, MoveConstructor) {
    typedef GenericValue<UTF8<>, CrtAllocator> V;
    V::AllocatorType allocator;

    V x((V(kArrayType)));
    x.Reserve(4u, allocator);
    x.PushBack(1, allocator).PushBack(2, allocator).PushBack(3, allocator).PushBack(4, allocator);
    EXPECT_TRUE(x.IsArray());
    EXPECT_EQ(4u, x.Size());

    // Value y(x); // does not compile (!is_copy_constructible)
    V y(std::move(x));
    EXPECT_TRUE(x.IsNull());
    EXPECT_TRUE(y.IsArray());
    EXPECT_EQ(4u, y.Size());

    // Value z = y; // does not compile (!is_copy_assignable)
    V z = std::move(y);
    EXPECT_TRUE(y.IsNull());
    EXPECT_TRUE(z.IsArray());
    EXPECT_EQ(4u, z.Size());
}

#endif // RAPIDJSON_HAS_CXX11_RVALUE_REFS

TEST(Value, AssignmentOperator) {
    Value x(1234);
    Value y;
    y = x;
    EXPECT_TRUE(x.IsNull());    // move semantic
    EXPECT_EQ(1234, y.GetInt());

    y = 5678;
    EXPECT_TRUE(y.IsInt());
    EXPECT_EQ(5678, y.GetInt());

    x = "Hello";
    EXPECT_TRUE(x.IsString());
    EXPECT_STREQ(x.GetString(),"Hello");

    y = StringRef(x.GetString(),x.GetStringLength());
    EXPECT_TRUE(y.IsString());
    EXPECT_EQ(y.GetString(),x.GetString());
    EXPECT_EQ(y.GetStringLength(),x.GetStringLength());

    static char mstr[] = "mutable";
    // y = mstr; // should not compile
    y = StringRef(mstr);
    EXPECT_TRUE(y.IsString());
    EXPECT_EQ(y.GetString(),mstr);

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS
    // C++11 move assignment
    x = Value("World");
    EXPECT_TRUE(x.IsString());
    EXPECT_STREQ("World", x.GetString());

    x = std::move(y);
    EXPECT_TRUE(y.IsNull());
    EXPECT_TRUE(x.IsString());
    EXPECT_EQ(x.GetString(), mstr);

    y = std::move(Value().SetInt(1234));
    EXPECT_TRUE(y.IsInt());
    EXPECT_EQ(1234, y);
#endif // RAPIDJSON_HAS_CXX11_RVALUE_REFS
}

template <typename A, typename B> 
void TestEqual(const A& a, const B& b) {
    EXPECT_TRUE (a == b);
    EXPECT_FALSE(a != b);
    EXPECT_TRUE (b == a);
    EXPECT_FALSE(b != a);
}

template <typename A, typename B> 
void TestUnequal(const A& a, const B& b) {
    EXPECT_FALSE(a == b);
    EXPECT_TRUE (a != b);
    EXPECT_FALSE(b == a);
    EXPECT_TRUE (b != a);
}

TEST(Value, EqualtoOperator) {
    Value::AllocatorType allocator;
    Value x(kObjectType);
    x.AddMember("hello", "world", allocator)
        .AddMember("t", Value(true).Move(), allocator)
        .AddMember("f", Value(false).Move(), allocator)
        .AddMember("n", Value(kNullType).Move(), allocator)
        .AddMember("i", 123, allocator)
        .AddMember("pi", 3.14, allocator)
        .AddMember("a", Value(kArrayType).Move().PushBack(1, allocator).PushBack(2, allocator).PushBack(3, allocator), allocator);

    // Test templated operator==() and operator!=()
    TestEqual(x["hello"], "world");
    const char* cc = "world";
    TestEqual(x["hello"], cc);
    char* c = strdup("world");
    TestEqual(x["hello"], c);
    free(c);

    TestEqual(x["t"], true);
    TestEqual(x["f"], false);
    TestEqual(x["i"], 123);
    TestEqual(x["pi"], 3.14);

    // Test operator==() (including different allocators)
    CrtAllocator crtAllocator;
    GenericValue<UTF8<>, CrtAllocator> y;
    GenericDocument<UTF8<>, CrtAllocator> z(&crtAllocator);
    y.CopyFrom(x, crtAllocator);
    z.CopyFrom(y, z.GetAllocator());
    TestEqual(x, y);
    TestEqual(y, z);
    TestEqual(z, x);

    // Swapping member order should be fine.
    EXPECT_TRUE(y.RemoveMember("t"));
    TestUnequal(x, y);
    TestUnequal(z, y);
    EXPECT_TRUE(z.RemoveMember("t"));
    TestUnequal(x, z);
    TestEqual(y, z);
    y.AddMember("t", false, crtAllocator);
    z.AddMember("t", false, z.GetAllocator());
    TestUnequal(x, y);
    TestUnequal(z, x);
    y["t"] = true;
    z["t"] = true;
    TestEqual(x, y);
    TestEqual(y, z);
    TestEqual(z, x);

    // Swapping element order is not OK
    x["a"][0].Swap(x["a"][1]);
    TestUnequal(x, y);
    x["a"][0].Swap(x["a"][1]);
    TestEqual(x, y);

    // Array of different size
    x["a"].PushBack(4, allocator);
    TestUnequal(x, y);
    x["a"].PopBack();
    TestEqual(x, y);

    // Issue #129: compare Uint64
    x.SetUint64(RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFF0));
    y.SetUint64(RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFFF));
    TestUnequal(x, y);
}

template <typename Value>
void TestCopyFrom() {
    typename Value::AllocatorType a;
    Value v1(1234);
    Value v2(v1, a); // deep copy constructor
    EXPECT_TRUE(v1.GetType() == v2.GetType());
    EXPECT_EQ(v1.GetInt(), v2.GetInt());

    v1.SetString("foo");
    v2.CopyFrom(v1, a);
    EXPECT_TRUE(v1.GetType() == v2.GetType());
    EXPECT_STREQ(v1.GetString(), v2.GetString());
    EXPECT_EQ(v1.GetString(), v2.GetString()); // string NOT copied

    v1.SetString("bar", a); // copy string
    v2.CopyFrom(v1, a);
    EXPECT_TRUE(v1.GetType() == v2.GetType());
    EXPECT_STREQ(v1.GetString(), v2.GetString());
    EXPECT_NE(v1.GetString(), v2.GetString()); // string copied


    v1.SetArray().PushBack(1234, a);
    v2.CopyFrom(v1, a);
    EXPECT_TRUE(v2.IsArray());
    EXPECT_EQ(v1.Size(), v2.Size());

    v1.PushBack(Value().SetString("foo", a), a); // push string copy
    EXPECT_TRUE(v1.Size() != v2.Size());
    v2.CopyFrom(v1, a);
    EXPECT_TRUE(v1.Size() == v2.Size());
    EXPECT_STREQ(v1[1].GetString(), v2[1].GetString());
    EXPECT_NE(v1[1].GetString(), v2[1].GetString()); // string got copied
}

TEST(Value, CopyFrom) {
    TestCopyFrom<Value>();
    TestCopyFrom<GenericValue<UTF8<>, CrtAllocator> >();
}

TEST(Value, Swap) {
    Value v1(1234);
    Value v2(kObjectType);

    EXPECT_EQ(&v1, &v1.Swap(v2));
    EXPECT_TRUE(v1.IsObject());
    EXPECT_TRUE(v2.IsInt());
    EXPECT_EQ(1234, v2.GetInt());

    // testing std::swap compatibility
    using std::swap;
    swap(v1, v2);
    EXPECT_TRUE(v1.IsInt());
    EXPECT_TRUE(v2.IsObject());
}

TEST(Value, Null) {
    // Default constructor
    Value x;
    EXPECT_EQ(kNullType, x.GetType());
    EXPECT_TRUE(x.IsNull());

    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsNumber());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    // Constructor with type
    Value y(kNullType);
    EXPECT_TRUE(y.IsNull());

    // SetNull();
    Value z(true);
    z.SetNull();
    EXPECT_TRUE(z.IsNull());
}

TEST(Value, True) {
    // Constructor with bool
    Value x(true);
    EXPECT_EQ(kTrueType, x.GetType());
    EXPECT_TRUE(x.GetBool());
    EXPECT_TRUE(x.IsBool());
    EXPECT_TRUE(x.IsTrue());

    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsNumber());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    // Constructor with type
    Value y(kTrueType);
    EXPECT_TRUE(y.IsTrue());

    // SetBool()
    Value z;
    z.SetBool(true);
    EXPECT_TRUE(z.IsTrue());

    // Templated functions
    EXPECT_TRUE(z.Is<bool>());
    EXPECT_TRUE(z.Get<bool>());
    EXPECT_FALSE(z.Set<bool>(false).Get<bool>());
    EXPECT_TRUE(z.Set(true).Get<bool>());
}

TEST(Value, False) {
    // Constructor with bool
    Value x(false);
    EXPECT_EQ(kFalseType, x.GetType());
    EXPECT_TRUE(x.IsBool());
    EXPECT_TRUE(x.IsFalse());

    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.GetBool());
    //EXPECT_FALSE((bool)x);
    EXPECT_FALSE(x.IsNumber());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    // Constructor with type
    Value y(kFalseType);
    EXPECT_TRUE(y.IsFalse());

    // SetBool()
    Value z;
    z.SetBool(false);
    EXPECT_TRUE(z.IsFalse());
}

TEST(Value, Int) {
    // Constructor with int
    Value x(1234);
    EXPECT_EQ(kNumberType, x.GetType());
    EXPECT_EQ(1234, x.GetInt());
    EXPECT_EQ(1234u, x.GetUint());
    EXPECT_EQ(1234, x.GetInt64());
    EXPECT_EQ(1234u, x.GetUint64());
    EXPECT_NEAR(1234.0, x.GetDouble(), 0.0);
    //EXPECT_EQ(1234, (int)x);
    //EXPECT_EQ(1234, (unsigned)x);
    //EXPECT_EQ(1234, (int64_t)x);
    //EXPECT_EQ(1234, (uint64_t)x);
    //EXPECT_EQ(1234, (double)x);
    EXPECT_TRUE(x.IsNumber());
    EXPECT_TRUE(x.IsInt());
    EXPECT_TRUE(x.IsUint());
    EXPECT_TRUE(x.IsInt64());
    EXPECT_TRUE(x.IsUint64());

    EXPECT_FALSE(x.IsDouble());
    EXPECT_FALSE(x.IsFloat());
    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    Value nx(-1234);
    EXPECT_EQ(-1234, nx.GetInt());
    EXPECT_EQ(-1234, nx.GetInt64());
    EXPECT_TRUE(nx.IsInt());
    EXPECT_TRUE(nx.IsInt64());
    EXPECT_FALSE(nx.IsUint());
    EXPECT_FALSE(nx.IsUint64());

    // Constructor with type
    Value y(kNumberType);
    EXPECT_TRUE(y.IsNumber());
    EXPECT_TRUE(y.IsInt());
    EXPECT_EQ(0, y.GetInt());

    // SetInt()
    Value z;
    z.SetInt(1234);
    EXPECT_EQ(1234, z.GetInt());

    // operator=(int)
    z = 5678;
    EXPECT_EQ(5678, z.GetInt());

    // Templated functions
    EXPECT_TRUE(z.Is<int>());
    EXPECT_EQ(5678, z.Get<int>());
    EXPECT_EQ(5679, z.Set(5679).Get<int>());
    EXPECT_EQ(5680, z.Set<int>(5680).Get<int>());

#ifdef _MSC_VER
    // long as int on MSC platforms
    RAPIDJSON_STATIC_ASSERT(sizeof(long) == sizeof(int));
    z.SetInt(2222);
    EXPECT_TRUE(z.Is<long>());
    EXPECT_EQ(2222l, z.Get<long>());
    EXPECT_EQ(3333l, z.Set(3333l).Get<long>());
    EXPECT_EQ(4444l, z.Set<long>(4444l).Get<long>());
    EXPECT_TRUE(z.IsInt());
#endif
}

TEST(Value, Uint) {
    // Constructor with int
    Value x(1234u);
    EXPECT_EQ(kNumberType, x.GetType());
    EXPECT_EQ(1234, x.GetInt());
    EXPECT_EQ(1234u, x.GetUint());
    EXPECT_EQ(1234, x.GetInt64());
    EXPECT_EQ(1234u, x.GetUint64());
    EXPECT_TRUE(x.IsNumber());
    EXPECT_TRUE(x.IsInt());
    EXPECT_TRUE(x.IsUint());
    EXPECT_TRUE(x.IsInt64());
    EXPECT_TRUE(x.IsUint64());
    EXPECT_NEAR(1234.0, x.GetDouble(), 0.0);   // Number can always be cast as double but !IsDouble().

    EXPECT_FALSE(x.IsDouble());
    EXPECT_FALSE(x.IsFloat());
    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    // SetUint()
    Value z;
    z.SetUint(1234);
    EXPECT_EQ(1234u, z.GetUint());

    // operator=(unsigned)
    z = 5678u;
    EXPECT_EQ(5678u, z.GetUint());

    z = 2147483648u;    // 2^31, cannot cast as int
    EXPECT_EQ(2147483648u, z.GetUint());
    EXPECT_FALSE(z.IsInt());
    EXPECT_TRUE(z.IsInt64());   // Issue 41: Incorrect parsing of unsigned int number types

    // Templated functions
    EXPECT_TRUE(z.Is<unsigned>());
    EXPECT_EQ(2147483648u, z.Get<unsigned>());
    EXPECT_EQ(2147483649u, z.Set(2147483649u).Get<unsigned>());
    EXPECT_EQ(2147483650u, z.Set<unsigned>(2147483650u).Get<unsigned>());

#ifdef _MSC_VER
    // unsigned long as unsigned on MSC platforms
    RAPIDJSON_STATIC_ASSERT(sizeof(unsigned long) == sizeof(unsigned));
    z.SetUint(2222);
    EXPECT_TRUE(z.Is<unsigned long>());
    EXPECT_EQ(2222ul, z.Get<unsigned long>());
    EXPECT_EQ(3333ul, z.Set(3333ul).Get<unsigned long>());
    EXPECT_EQ(4444ul, z.Set<unsigned long>(4444ul).Get<unsigned long>());
    EXPECT_TRUE(x.IsUint());
#endif
}

TEST(Value, Int64) {
    // Constructor with int
    Value x(int64_t(1234));
    EXPECT_EQ(kNumberType, x.GetType());
    EXPECT_EQ(1234, x.GetInt());
    EXPECT_EQ(1234u, x.GetUint());
    EXPECT_EQ(1234, x.GetInt64());
    EXPECT_EQ(1234u, x.GetUint64());
    EXPECT_TRUE(x.IsNumber());
    EXPECT_TRUE(x.IsInt());
    EXPECT_TRUE(x.IsUint());
    EXPECT_TRUE(x.IsInt64());
    EXPECT_TRUE(x.IsUint64());

    EXPECT_FALSE(x.IsDouble());
    EXPECT_FALSE(x.IsFloat());
    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    Value nx(int64_t(-1234));
    EXPECT_EQ(-1234, nx.GetInt());
    EXPECT_EQ(-1234, nx.GetInt64());
    EXPECT_TRUE(nx.IsInt());
    EXPECT_TRUE(nx.IsInt64());
    EXPECT_FALSE(nx.IsUint());
    EXPECT_FALSE(nx.IsUint64());

    // SetInt64()
    Value z;
    z.SetInt64(1234);
    EXPECT_EQ(1234, z.GetInt64());

    z.SetInt64(2147483648u);   // 2^31, cannot cast as int
    EXPECT_FALSE(z.IsInt());
    EXPECT_TRUE(z.IsUint());
    EXPECT_NEAR(2147483648.0, z.GetDouble(), 0.0);

    z.SetInt64(int64_t(4294967295u) + 1);   // 2^32, cannot cast as uint
    EXPECT_FALSE(z.IsInt());
    EXPECT_FALSE(z.IsUint());
    EXPECT_NEAR(4294967296.0, z.GetDouble(), 0.0);

    z.SetInt64(-int64_t(2147483648u) - 1);   // -2^31-1, cannot cast as int
    EXPECT_FALSE(z.IsInt());
    EXPECT_NEAR(-2147483649.0, z.GetDouble(), 0.0);

    int64_t i = static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x80000000, 00000000));
    z.SetInt64(i);
    EXPECT_DOUBLE_EQ(-9223372036854775808.0, z.GetDouble());

    // Templated functions
    EXPECT_TRUE(z.Is<int64_t>());
    EXPECT_EQ(i, z.Get<int64_t>());
#if 0 // signed integer underflow is undefined behaviour
    EXPECT_EQ(i - 1, z.Set(i - 1).Get<int64_t>());
    EXPECT_EQ(i - 2, z.Set<int64_t>(i - 2).Get<int64_t>());
#endif
}

TEST(Value, Uint64) {
    // Constructor with int
    Value x(uint64_t(1234));
    EXPECT_EQ(kNumberType, x.GetType());
    EXPECT_EQ(1234, x.GetInt());
    EXPECT_EQ(1234u, x.GetUint());
    EXPECT_EQ(1234, x.GetInt64());
    EXPECT_EQ(1234u, x.GetUint64());
    EXPECT_TRUE(x.IsNumber());
    EXPECT_TRUE(x.IsInt());
    EXPECT_TRUE(x.IsUint());
    EXPECT_TRUE(x.IsInt64());
    EXPECT_TRUE(x.IsUint64());

    EXPECT_FALSE(x.IsDouble());
    EXPECT_FALSE(x.IsFloat());
    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    // SetUint64()
    Value z;
    z.SetUint64(1234);
    EXPECT_EQ(1234u, z.GetUint64());

    z.SetUint64(uint64_t(2147483648u));  // 2^31, cannot cast as int
    EXPECT_FALSE(z.IsInt());
    EXPECT_TRUE(z.IsUint());
    EXPECT_TRUE(z.IsInt64());

    z.SetUint64(uint64_t(4294967295u) + 1);  // 2^32, cannot cast as uint
    EXPECT_FALSE(z.IsInt());
    EXPECT_FALSE(z.IsUint());
    EXPECT_TRUE(z.IsInt64());

    uint64_t u = RAPIDJSON_UINT64_C2(0x80000000, 0x00000000);
    z.SetUint64(u);    // 2^63 cannot cast as int64
    EXPECT_FALSE(z.IsInt64());
    EXPECT_EQ(u, z.GetUint64()); // Issue 48
    EXPECT_DOUBLE_EQ(9223372036854775808.0, z.GetDouble());

    // Templated functions
    EXPECT_TRUE(z.Is<uint64_t>());
    EXPECT_EQ(u, z.Get<uint64_t>());
    EXPECT_EQ(u + 1, z.Set(u + 1).Get<uint64_t>());
    EXPECT_EQ(u + 2, z.Set<uint64_t>(u + 2).Get<uint64_t>());
}

TEST(Value, Double) {
    // Constructor with double
    Value x(12.34);
    EXPECT_EQ(kNumberType, x.GetType());
    EXPECT_NEAR(12.34, x.GetDouble(), 0.0);
    EXPECT_TRUE(x.IsNumber());
    EXPECT_TRUE(x.IsDouble());

    EXPECT_FALSE(x.IsInt());
    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    // SetDouble()
    Value z;
    z.SetDouble(12.34);
    EXPECT_NEAR(12.34, z.GetDouble(), 0.0);

    z = 56.78;
    EXPECT_NEAR(56.78, z.GetDouble(), 0.0);

    // Templated functions
    EXPECT_TRUE(z.Is<double>());
    EXPECT_EQ(56.78, z.Get<double>());
    EXPECT_EQ(57.78, z.Set(57.78).Get<double>());
    EXPECT_EQ(58.78, z.Set<double>(58.78).Get<double>());
}

TEST(Value, Float) {
    // Constructor with double
    Value x(12.34f);
    EXPECT_EQ(kNumberType, x.GetType());
    EXPECT_NEAR(12.34f, x.GetFloat(), 0.0);
    EXPECT_TRUE(x.IsNumber());
    EXPECT_TRUE(x.IsDouble());
    EXPECT_TRUE(x.IsFloat());

    EXPECT_FALSE(x.IsInt());
    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    // SetFloat()
    Value z;
    z.SetFloat(12.34f);
    EXPECT_NEAR(12.34f, z.GetFloat(), 0.0f);

    // Issue 573
    z.SetInt(0);
    EXPECT_EQ(0.0f, z.GetFloat());

    z = 56.78f;
    EXPECT_NEAR(56.78f, z.GetFloat(), 0.0f);

    // Templated functions
    EXPECT_TRUE(z.Is<float>());
    EXPECT_EQ(56.78f, z.Get<float>());
    EXPECT_EQ(57.78f, z.Set(57.78f).Get<float>());
    EXPECT_EQ(58.78f, z.Set<float>(58.78f).Get<float>());
}

TEST(Value, IsLosslessDouble) {
    EXPECT_TRUE(Value(0.0).IsLosslessDouble());
    EXPECT_TRUE(Value(12.34).IsLosslessDouble());
    EXPECT_TRUE(Value(-123).IsLosslessDouble());
    EXPECT_TRUE(Value(2147483648u).IsLosslessDouble());
    EXPECT_TRUE(Value(-static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x40000000, 0x00000000))).IsLosslessDouble());
#if !(defined(_MSC_VER) && _MSC_VER < 1800) // VC2010 has problem
    EXPECT_TRUE(Value(RAPIDJSON_UINT64_C2(0xA0000000, 0x00000000)).IsLosslessDouble());
#endif

    EXPECT_FALSE(Value(static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x7FFFFFFF, 0xFFFFFFFF))).IsLosslessDouble()); // INT64_MAX
    EXPECT_FALSE(Value(-static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x7FFFFFFF, 0xFFFFFFFF))).IsLosslessDouble()); // -INT64_MAX
    EXPECT_TRUE(Value(-static_cast<int64_t>(RAPIDJSON_UINT64_C2(0x7FFFFFFF, 0xFFFFFFFF)) - 1).IsLosslessDouble()); // INT64_MIN
    EXPECT_FALSE(Value(RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFFF)).IsLosslessDouble()); // UINT64_MAX

    EXPECT_TRUE(Value(3.4028234e38f).IsLosslessDouble()); // FLT_MAX
    EXPECT_TRUE(Value(-3.4028234e38f).IsLosslessDouble()); // -FLT_MAX
    EXPECT_TRUE(Value(1.17549435e-38f).IsLosslessDouble()); // FLT_MIN
    EXPECT_TRUE(Value(-1.17549435e-38f).IsLosslessDouble()); // -FLT_MIN
    EXPECT_TRUE(Value(1.7976931348623157e+308).IsLosslessDouble()); // DBL_MAX
    EXPECT_TRUE(Value(-1.7976931348623157e+308).IsLosslessDouble()); // -DBL_MAX
    EXPECT_TRUE(Value(2.2250738585072014e-308).IsLosslessDouble()); // DBL_MIN
    EXPECT_TRUE(Value(-2.2250738585072014e-308).IsLosslessDouble()); // -DBL_MIN
}

TEST(Value, IsLosslessFloat) {
    EXPECT_TRUE(Value(12.25).IsLosslessFloat());
    EXPECT_TRUE(Value(-123).IsLosslessFloat());
    EXPECT_TRUE(Value(2147483648u).IsLosslessFloat());
    EXPECT_TRUE(Value(3.4028234e38f).IsLosslessFloat());
    EXPECT_TRUE(Value(-3.4028234e38f).IsLosslessFloat());
    EXPECT_FALSE(Value(3.4028235e38).IsLosslessFloat());
    EXPECT_FALSE(Value(0.3).IsLosslessFloat());
}

TEST(Value, String) {
    // Construction with const string
    Value x("Hello", 5); // literal
    EXPECT_EQ(kStringType, x.GetType());
    EXPECT_TRUE(x.IsString());
    EXPECT_STREQ("Hello", x.GetString());
    EXPECT_EQ(5u, x.GetStringLength());

    EXPECT_FALSE(x.IsNumber());
    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsObject());
    EXPECT_FALSE(x.IsArray());

    static const char cstr[] = "World"; // const array
    Value(cstr).Swap(x);
    EXPECT_TRUE(x.IsString());
    EXPECT_EQ(x.GetString(), cstr);
    EXPECT_EQ(x.GetStringLength(), sizeof(cstr)-1);

    static char mstr[] = "Howdy"; // non-const array
    // Value(mstr).Swap(x); // should not compile
    Value(StringRef(mstr)).Swap(x);
    EXPECT_TRUE(x.IsString());
    EXPECT_EQ(x.GetString(), mstr);
    EXPECT_EQ(x.GetStringLength(), sizeof(mstr)-1);
    strncpy(mstr,"Hello", sizeof(mstr));
    EXPECT_STREQ(x.GetString(), "Hello");

    const char* pstr = cstr;
    //Value(pstr).Swap(x); // should not compile
    Value(StringRef(pstr)).Swap(x);
    EXPECT_TRUE(x.IsString());
    EXPECT_EQ(x.GetString(), cstr);
    EXPECT_EQ(x.GetStringLength(), sizeof(cstr)-1);

    char* mpstr = mstr;
    Value(StringRef(mpstr,sizeof(mstr)-1)).Swap(x);
    EXPECT_TRUE(x.IsString());
    EXPECT_EQ(x.GetString(), mstr);
    EXPECT_EQ(x.GetStringLength(), 5u);
    EXPECT_STREQ(x.GetString(), "Hello");

    // Constructor with copy string
    MemoryPoolAllocator<> allocator;
    Value c(x.GetString(), x.GetStringLength(), allocator);
    EXPECT_NE(x.GetString(), c.GetString());
    EXPECT_EQ(x.GetStringLength(), c.GetStringLength());
    EXPECT_STREQ(x.GetString(), c.GetString());
    //x.SetString("World");
    x.SetString("World", 5);
    EXPECT_STREQ("Hello", c.GetString());
    EXPECT_EQ(5u, c.GetStringLength());

    // Constructor with type
    Value y(kStringType);
    EXPECT_TRUE(y.IsString());
    EXPECT_STREQ("", y.GetString());    // Empty string should be "" instead of 0 (issue 226)
    EXPECT_EQ(0u, y.GetStringLength());

    // SetConsttring()
    Value z;
    z.SetString("Hello");
    EXPECT_TRUE(x.IsString());
    z.SetString("Hello", 5);
    EXPECT_STREQ("Hello", z.GetString());
    EXPECT_STREQ("Hello", z.GetString());
    EXPECT_EQ(5u, z.GetStringLength());

    z.SetString("Hello");
    EXPECT_TRUE(z.IsString());
    EXPECT_STREQ("Hello", z.GetString());

    //z.SetString(mstr); // should not compile
    //z.SetString(pstr); // should not compile
    z.SetString(StringRef(mstr));
    EXPECT_TRUE(z.IsString());
    EXPECT_STREQ(z.GetString(), mstr);

    z.SetString(cstr);
    EXPECT_TRUE(z.IsString());
    EXPECT_EQ(cstr, z.GetString());

    z = cstr;
    EXPECT_TRUE(z.IsString());
    EXPECT_EQ(cstr, z.GetString());

    // SetString()
    char s[] = "World";
    Value w;
    w.SetString(s, static_cast<SizeType>(strlen(s)), allocator);
    s[0] = '\0';
    EXPECT_STREQ("World", w.GetString());
    EXPECT_EQ(5u, w.GetStringLength());

    // templated functions
    EXPECT_TRUE(z.Is<const char*>());
    EXPECT_STREQ(cstr, z.Get<const char*>());
    EXPECT_STREQ("Apple", z.Set<const char*>("Apple").Get<const char*>());

#if RAPIDJSON_HAS_STDSTRING
    {
        std::string str = "Hello World";
        str[5] = '\0';
        EXPECT_STREQ(str.data(),"Hello"); // embedded '\0'
        EXPECT_EQ(str.size(), 11u);

        // no copy
        Value vs0(StringRef(str));
        EXPECT_TRUE(vs0.IsString());
        EXPECT_EQ(vs0.GetString(), str.data());
        EXPECT_EQ(vs0.GetStringLength(), str.size());
        TestEqual(vs0, str);

        // do copy
        Value vs1(str, allocator);
        EXPECT_TRUE(vs1.IsString());
        EXPECT_NE(vs1.GetString(), str.data());
        EXPECT_NE(vs1.GetString(), str); // not equal due to embedded '\0'
        EXPECT_EQ(vs1.GetStringLength(), str.size());
        TestEqual(vs1, str);

        // SetString
        str = "World";
        vs0.SetNull().SetString(str, allocator);
        EXPECT_TRUE(vs0.IsString());
        EXPECT_STREQ(vs0.GetString(), str.c_str());
        EXPECT_EQ(vs0.GetStringLength(), str.size());
        TestEqual(str, vs0);
        TestUnequal(str, vs1);

        // vs1 = str; // should not compile
        vs1 = StringRef(str);
        TestEqual(str, vs1);
        TestEqual(vs0, vs1);

        // Templated function.
        EXPECT_TRUE(vs0.Is<std::string>());
        EXPECT_EQ(str, vs0.Get<std::string>());
        vs0.Set<std::string>(std::string("Apple"), allocator);
        EXPECT_EQ(std::string("Apple"), vs0.Get<std::string>());
        vs0.Set(std::string("Orange"), allocator);
        EXPECT_EQ(std::string("Orange"), vs0.Get<std::string>());
    }
#endif // RAPIDJSON_HAS_STDSTRING
}

// Issue 226: Value of string type should not point to NULL
TEST(Value, SetStringNull) {

    MemoryPoolAllocator<> allocator;
    const char* nullPtr = 0;
    {
        // Construction with string type creates empty string
        Value v(kStringType);
        EXPECT_NE(v.GetString(), nullPtr); // non-null string returned
        EXPECT_EQ(v.GetStringLength(), 0u);

        // Construction from/setting to null without length not allowed
        EXPECT_THROW(Value(StringRef(nullPtr)), AssertException);
        EXPECT_THROW(Value(StringRef(nullPtr), allocator), AssertException);
        EXPECT_THROW(v.SetString(nullPtr, allocator), AssertException);

        // Non-empty length with null string is not allowed
        EXPECT_THROW(v.SetString(nullPtr, 17u), AssertException);
        EXPECT_THROW(v.SetString(nullPtr, 42u, allocator), AssertException);

        // Setting to null string with empty length is allowed
        v.SetString(nullPtr, 0u);
        EXPECT_NE(v.GetString(), nullPtr); // non-null string returned
        EXPECT_EQ(v.GetStringLength(), 0u);

        v.SetNull();
        v.SetString(nullPtr, 0u, allocator);
        EXPECT_NE(v.GetString(), nullPtr); // non-null string returned
        EXPECT_EQ(v.GetStringLength(), 0u);
    }
    // Construction with null string and empty length is allowed
    {
        Value v(nullPtr,0u);
        EXPECT_NE(v.GetString(), nullPtr); // non-null string returned
        EXPECT_EQ(v.GetStringLength(), 0u);
    }
    {
        Value v(nullPtr, 0u, allocator);
        EXPECT_NE(v.GetString(), nullPtr); // non-null string returned
        EXPECT_EQ(v.GetStringLength(), 0u);
    }
}

template <typename T, typename Allocator>
static void TestArray(T& x, Allocator& allocator) {
    const T& y = x;

    // PushBack()
    Value v;
    x.PushBack(v, allocator);
    v.SetBool(true);
    x.PushBack(v, allocator);
    v.SetBool(false);
    x.PushBack(v, allocator);
    v.SetInt(123);
    x.PushBack(v, allocator);
    //x.PushBack((const char*)"foo", allocator); // should not compile
    x.PushBack("foo", allocator);

    EXPECT_FALSE(x.Empty());
    EXPECT_EQ(5u, x.Size());
    EXPECT_FALSE(y.Empty());
    EXPECT_EQ(5u, y.Size());
    EXPECT_TRUE(x[SizeType(0)].IsNull());
    EXPECT_TRUE(x[1].IsTrue());
    EXPECT_TRUE(x[2].IsFalse());
    EXPECT_TRUE(x[3].IsInt());
    EXPECT_EQ(123, x[3].GetInt());
    EXPECT_TRUE(y[SizeType(0)].IsNull());
    EXPECT_TRUE(y[1].IsTrue());
    EXPECT_TRUE(y[2].IsFalse());
    EXPECT_TRUE(y[3].IsInt());
    EXPECT_EQ(123, y[3].GetInt());
    EXPECT_TRUE(y[4].IsString());
    EXPECT_STREQ("foo", y[4].GetString());

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS
    // PushBack(GenericValue&&, Allocator&);
    {
        Value y2(kArrayType);
        y2.PushBack(Value(true), allocator);
        y2.PushBack(std::move(Value(kArrayType).PushBack(Value(1), allocator).PushBack("foo", allocator)), allocator);
        EXPECT_EQ(2u, y2.Size());
        EXPECT_TRUE(y2[0].IsTrue());
        EXPECT_TRUE(y2[1].IsArray());
        EXPECT_EQ(2u, y2[1].Size());
        EXPECT_TRUE(y2[1][0].IsInt());
        EXPECT_TRUE(y2[1][1].IsString());
    }
#endif

    // iterator
    typename T::ValueIterator itr = x.Begin();
    EXPECT_TRUE(itr != x.End());
    EXPECT_TRUE(itr->IsNull());
    ++itr;
    EXPECT_TRUE(itr != x.End());
    EXPECT_TRUE(itr->IsTrue());
    ++itr;
    EXPECT_TRUE(itr != x.End());
    EXPECT_TRUE(itr->IsFalse());
    ++itr;
    EXPECT_TRUE(itr != x.End());
    EXPECT_TRUE(itr->IsInt());
    EXPECT_EQ(123, itr->GetInt());
    ++itr;
    EXPECT_TRUE(itr != x.End());
    EXPECT_TRUE(itr->IsString());
    EXPECT_STREQ("foo", itr->GetString());

    // const iterator
    typename T::ConstValueIterator citr = y.Begin();
    EXPECT_TRUE(citr != y.End());
    EXPECT_TRUE(citr->IsNull());
    ++citr;
    EXPECT_TRUE(citr != y.End());
    EXPECT_TRUE(citr->IsTrue());
    ++citr;
    EXPECT_TRUE(citr != y.End());
    EXPECT_TRUE(citr->IsFalse());
    ++citr;
    EXPECT_TRUE(citr != y.End());
    EXPECT_TRUE(citr->IsInt());
    EXPECT_EQ(123, citr->GetInt());
    ++citr;
    EXPECT_TRUE(citr != y.End());
    EXPECT_TRUE(citr->IsString());
    EXPECT_STREQ("foo", citr->GetString());

    // PopBack()
    x.PopBack();
    EXPECT_EQ(4u, x.Size());
    EXPECT_TRUE(y[SizeType(0)].IsNull());
    EXPECT_TRUE(y[1].IsTrue());
    EXPECT_TRUE(y[2].IsFalse());
    EXPECT_TRUE(y[3].IsInt());

    // Clear()
    x.Clear();
    EXPECT_TRUE(x.Empty());
    EXPECT_EQ(0u, x.Size());
    EXPECT_TRUE(y.Empty());
    EXPECT_EQ(0u, y.Size());

    // Erase(ValueIterator)

    // Use array of array to ensure removed elements' destructor is called.
    // [[0],[1],[2],...]
    for (int i = 0; i < 10; i++)
        x.PushBack(Value(kArrayType).PushBack(i, allocator).Move(), allocator);

    // Erase the first
    itr = x.Erase(x.Begin());
    EXPECT_EQ(x.Begin(), itr);
    EXPECT_EQ(9u, x.Size());
    for (int i = 0; i < 9; i++)
        EXPECT_EQ(i + 1, x[static_cast<SizeType>(i)][0].GetInt());

    // Ease the last
    itr = x.Erase(x.End() - 1);
    EXPECT_EQ(x.End(), itr);
    EXPECT_EQ(8u, x.Size());
    for (int i = 0; i < 8; i++)
        EXPECT_EQ(i + 1, x[static_cast<SizeType>(i)][0].GetInt());

    // Erase the middle
    itr = x.Erase(x.Begin() + 4);
    EXPECT_EQ(x.Begin() + 4, itr);
    EXPECT_EQ(7u, x.Size());
    for (int i = 0; i < 4; i++)
        EXPECT_EQ(i + 1, x[static_cast<SizeType>(i)][0].GetInt());
    for (int i = 4; i < 7; i++)
        EXPECT_EQ(i + 2, x[static_cast<SizeType>(i)][0].GetInt());

    // Erase(ValueIterator, ValueIterator)
    // Exhaustive test with all 0 <= first < n, first <= last <= n cases
    const unsigned n = 10;
    for (unsigned first = 0; first < n; first++) {
        for (unsigned last = first; last <= n; last++) {
            x.Clear();
            for (unsigned i = 0; i < n; i++)
                x.PushBack(Value(kArrayType).PushBack(i, allocator).Move(), allocator);
            
            itr = x.Erase(x.Begin() + first, x.Begin() + last);
            if (last == n)
                EXPECT_EQ(x.End(), itr);
            else
                EXPECT_EQ(x.Begin() + first, itr);

            size_t removeCount = last - first;
            EXPECT_EQ(n - removeCount, x.Size());
            for (unsigned i = 0; i < first; i++)
                EXPECT_EQ(i, x[i][0].GetUint());
            for (unsigned i = first; i < n - removeCount; i++)
                EXPECT_EQ(i + removeCount, x[static_cast<SizeType>(i)][0].GetUint());
        }
    }
}

TEST(Value, Array) {
    Value x(kArrayType);
    const Value& y = x;
    Value::AllocatorType allocator;

    EXPECT_EQ(kArrayType, x.GetType());
    EXPECT_TRUE(x.IsArray());
    EXPECT_TRUE(x.Empty());
    EXPECT_EQ(0u, x.Size());
    EXPECT_TRUE(y.IsArray());
    EXPECT_TRUE(y.Empty());
    EXPECT_EQ(0u, y.Size());

    EXPECT_FALSE(x.IsNull());
    EXPECT_FALSE(x.IsBool());
    EXPECT_FALSE(x.IsFalse());
    EXPECT_FALSE(x.IsTrue());
    EXPECT_FALSE(x.IsString());
    EXPECT_FALSE(x.IsObject());

    TestArray(x, allocator);

    // Working in gcc without C++11, but VS2013 cannot compile. To be diagnosed.
    // http://en.wikipedia.org/wiki/Erase-remove_idiom
    x.Clear();
    for (int i = 0; i < 10; i++)
        if (i % 2 == 0)
            x.PushBack(i, allocator);
        else
            x.PushBack(Value(kNullType).Move(), allocator);

    const Value null(kNullType);
    x.Erase(std::remove(x.Begin(), x.End(), null), x.End());
    EXPECT_EQ(5u, x.Size());
    for (int i = 0; i < 5; i++)
        EXPECT_EQ(i * 2, x[static_cast<SizeType>(i)]);

    // SetArray()
    Value z;
    z.SetArray();
    EXPECT_TRUE(z.IsArray());
    EXPECT_TRUE(z.Empty());
}

TEST(Value, ArrayHelper) {
    Value::AllocatorType allocator;
    {
        Value x(kArrayType);
        Value::Array a = x.GetArray();
        TestArray(a, allocator);
    }

    {
        Value x(kArrayType);
        Value::Array a = x.GetArray();
        a.PushBack(1, allocator);

        Value::Array a2(a); // copy constructor
        EXPECT_EQ(1u, a2.Size());

        Value::Array a3 = a;
        EXPECT_EQ(1u, a3.Size());

        Value::ConstArray y = static_cast<const Value&>(x).GetArray();
        (void)y;
        // y.PushBack(1, allocator); // should not compile

        // Templated functions
        x.Clear();
        EXPECT_TRUE(x.Is<Value::Array>());
        EXPECT_TRUE(x.Is<Value::ConstArray>());
        a.PushBack(1, allocator);
        EXPECT_EQ(1, x.Get<Value::Array>()[0].GetInt());
        EXPECT_EQ(1, x.Get<Value::ConstArray>()[0].GetInt());

        Value x2;
        x2.Set<Value::Array>(a);
        EXPECT_TRUE(x.IsArray());   // IsArray() is invariant after moving.
        EXPECT_EQ(1, x2.Get<Value::Array>()[0].GetInt());
    }

    {
        Value y(kArrayType);
        y.PushBack(123, allocator);

        Value x(y.GetArray());      // Construct value form array.
        EXPECT_TRUE(x.IsArray());
        EXPECT_EQ(123, x[0].GetInt());
        EXPECT_TRUE(y.IsArray());   // Invariant
        EXPECT_TRUE(y.Empty());
    }

    {
        Value x(kArrayType);
        Value y(kArrayType);
        y.PushBack(123, allocator);
        x.PushBack(y.GetArray(), allocator);    // Implicit constructor to convert Array to GenericValue

        EXPECT_EQ(1u, x.Size());
        EXPECT_EQ(123, x[0][0].GetInt());
        EXPECT_TRUE(y.IsArray());
        EXPECT_TRUE(y.Empty());
    }
}

#if RAPIDJSON_HAS_CXX11_RANGE_FOR
TEST(Value, ArrayHelperRangeFor) {
    Value::AllocatorType allocator;
    Value x(kArrayType);

    for (int i = 0; i < 10; i++)
        x.PushBack(i, allocator);

    {
        int i = 0;
        for (auto& v : x.GetArray()) {
            EXPECT_EQ(i, v.GetInt());
            i++;
        }
        EXPECT_EQ(i, 10);
    }
    {
        int i = 0;
        for (const auto& v : const_cast<const Value&>(x).GetArray()) {
            EXPECT_EQ(i, v.GetInt());
            i++;
        }
        EXPECT_EQ(i, 10);
    }

    // Array a = x.GetArray();
    // Array ca = const_cast<const Value&>(x).GetArray();
}
#endif

template <typename T, typename Allocator>
static void TestObject(T& x, Allocator& allocator) {
    const T& y = x; // const version

    // AddMember()
    x.AddMember("A", "Apple", allocator);
    EXPECT_FALSE(x.ObjectEmpty());
    EXPECT_EQ(1u, x.MemberCount());

    Value value("Banana", 6);
    x.AddMember("B", "Banana", allocator);
    EXPECT_EQ(2u, x.MemberCount());

    // AddMember<T>(StringRefType, T, Allocator)
    {
        Value o(kObjectType);
        o.AddMember("true", true, allocator);
        o.AddMember("false", false, allocator);
        o.AddMember("int", -1, allocator);
        o.AddMember("uint", 1u, allocator);
        o.AddMember("int64", int64_t(-4294967296), allocator);
        o.AddMember("uint64", uint64_t(4294967296), allocator);
        o.AddMember("double", 3.14, allocator);
        o.AddMember("string", "Jelly", allocator);

        EXPECT_TRUE(o["true"].GetBool());
        EXPECT_FALSE(o["false"].GetBool());
        EXPECT_EQ(-1, o["int"].GetInt());
        EXPECT_EQ(1u, o["uint"].GetUint());
        EXPECT_EQ(int64_t(-4294967296), o["int64"].GetInt64());
        EXPECT_EQ(uint64_t(4294967296), o["uint64"].GetUint64());
        EXPECT_STREQ("Jelly",o["string"].GetString());
        EXPECT_EQ(8u, o.MemberCount());
    }

    // AddMember<T>(Value&, T, Allocator)
    {
        Value o(kObjectType);

        Value n("s");
        o.AddMember(n, "string", allocator);
        EXPECT_EQ(1u, o.MemberCount());

        Value count("#");
        o.AddMember(count, o.MemberCount(), allocator);
        EXPECT_EQ(2u, o.MemberCount());
    }

#if RAPIDJSON_HAS_STDSTRING
    {
        // AddMember(StringRefType, const std::string&, Allocator)
        Value o(kObjectType);
        o.AddMember("b", std::string("Banana"), allocator);
        EXPECT_STREQ("Banana", o["b"].GetString());

        // RemoveMember(const std::string&)
        o.RemoveMember(std::string("b"));
        EXPECT_TRUE(o.ObjectEmpty());
    }
#endif

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS
    // AddMember(GenericValue&&, ...) variants
    {
        Value o(kObjectType);
        o.AddMember(Value("true"), Value(true), allocator);
        o.AddMember(Value("false"), Value(false).Move(), allocator);    // value is lvalue ref
        o.AddMember(Value("int").Move(), Value(-1), allocator);         // name is lvalue ref
        o.AddMember("uint", std::move(Value().SetUint(1u)), allocator); // name is literal, value is rvalue
        EXPECT_TRUE(o["true"].GetBool());
        EXPECT_FALSE(o["false"].GetBool());
        EXPECT_EQ(-1, o["int"].GetInt());
        EXPECT_EQ(1u, o["uint"].GetUint());
        EXPECT_EQ(4u, o.MemberCount());
    }
#endif

    // Tests a member with null character
    Value name;
    const Value C0D("C\0D", 3);
    name.SetString(C0D.GetString(), 3);
    value.SetString("CherryD", 7);
    x.AddMember(name, value, allocator);

    // HasMember()
    EXPECT_TRUE(x.HasMember("A"));
    EXPECT_TRUE(x.HasMember("B"));
    EXPECT_TRUE(y.HasMember("A"));
    EXPECT_TRUE(y.HasMember("B"));

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_TRUE(x.HasMember(std::string("A")));
#endif

    name.SetString("C\0D");
    EXPECT_TRUE(x.HasMember(name));
    EXPECT_TRUE(y.HasMember(name));

    GenericValue<UTF8<>, CrtAllocator> othername("A");
    EXPECT_TRUE(x.HasMember(othername));
    EXPECT_TRUE(y.HasMember(othername));
    othername.SetString("C\0D");
    EXPECT_TRUE(x.HasMember(othername));
    EXPECT_TRUE(y.HasMember(othername));

    // operator[]
    EXPECT_STREQ("Apple", x["A"].GetString());
    EXPECT_STREQ("Banana", x["B"].GetString());
    EXPECT_STREQ("CherryD", x[C0D].GetString());
    EXPECT_STREQ("CherryD", x[othername].GetString());
    EXPECT_THROW(x["nonexist"], AssertException);

    // const operator[]
    EXPECT_STREQ("Apple", y["A"].GetString());
    EXPECT_STREQ("Banana", y["B"].GetString());
    EXPECT_STREQ("CherryD", y[C0D].GetString());

#if RAPIDJSON_HAS_STDSTRING
    EXPECT_STREQ("Apple", x["A"].GetString());
    EXPECT_STREQ("Apple", y[std::string("A")].GetString());
#endif

    // member iterator
    Value::MemberIterator itr = x.MemberBegin(); 
    EXPECT_TRUE(itr != x.MemberEnd());
    EXPECT_STREQ("A", itr->name.GetString());
    EXPECT_STREQ("Apple", itr->value.GetString());
    ++itr;
    EXPECT_TRUE(itr != x.MemberEnd());
    EXPECT_STREQ("B", itr->name.GetString());
    EXPECT_STREQ("Banana", itr->value.GetString());
    ++itr;
    EXPECT_TRUE(itr != x.MemberEnd());
    EXPECT_TRUE(memcmp(itr->name.GetString(), "C\0D", 4) == 0);
    EXPECT_STREQ("CherryD", itr->value.GetString());
    ++itr;
    EXPECT_FALSE(itr != x.MemberEnd());

    // const member iterator
    Value::ConstMemberIterator citr = y.MemberBegin(); 
    EXPECT_TRUE(citr != y.MemberEnd());
    EXPECT_STREQ("A", citr->name.GetString());
    EXPECT_STREQ("Apple", citr->value.GetString());
    ++citr;
    EXPECT_TRUE(citr != y.MemberEnd());
    EXPECT_STREQ("B", citr->name.GetString());
    EXPECT_STREQ("Banana", citr->value.GetString());
    ++citr;
    EXPECT_TRUE(citr != y.MemberEnd());
    EXPECT_TRUE(memcmp(citr->name.GetString(), "C\0D", 4) == 0);
    EXPECT_STREQ("CherryD", citr->value.GetString());
    ++citr;
    EXPECT_FALSE(citr != y.MemberEnd());

    // member iterator conversions/relations
    itr  = x.MemberBegin();
    citr = x.MemberBegin(); // const conversion
    TestEqual(itr, citr);
    EXPECT_TRUE(itr < x.MemberEnd());
    EXPECT_FALSE(itr > y.MemberEnd());
    EXPECT_TRUE(citr < x.MemberEnd());
    EXPECT_FALSE(citr > y.MemberEnd());
    ++citr;
    TestUnequal(itr, citr);
    EXPECT_FALSE(itr < itr);
    EXPECT_TRUE(itr < citr);
    EXPECT_FALSE(itr > itr);
    EXPECT_TRUE(citr > itr);
    EXPECT_EQ(1, citr - x.MemberBegin());
    EXPECT_EQ(0, itr - y.MemberBegin());
    itr += citr - x.MemberBegin();
    EXPECT_EQ(1, itr - y.MemberBegin());
    TestEqual(citr, itr);
    EXPECT_TRUE(itr <= citr);
    EXPECT_TRUE(citr <= itr);
    itr++;
    EXPECT_TRUE(itr >= citr);
    EXPECT_FALSE(citr >= itr);

    // RemoveMember()
    EXPECT_TRUE(x.RemoveMember("A"));
    EXPECT_FALSE(x.HasMember("A"));

    EXPECT_TRUE(x.RemoveMember("B"));
    EXPECT_FALSE(x.HasMember("B"));

    EXPECT_FALSE(x.RemoveMember("nonexist"));

    EXPECT_TRUE(x.RemoveMember(othername));
    EXPECT_FALSE(x.HasMember(name));

    EXPECT_TRUE(x.MemberBegin() == x.MemberEnd());

    // EraseMember(ConstMemberIterator)

    // Use array members to ensure removed elements' destructor is called.
    // { "a": [0], "b": [1],[2],...]
    const char keys[][2] = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j" };
    for (int i = 0; i < 10; i++)
        x.AddMember(keys[i], Value(kArrayType).PushBack(i, allocator), allocator);

    // MemberCount, iterator difference
    EXPECT_EQ(x.MemberCount(), SizeType(x.MemberEnd() - x.MemberBegin()));

    // Erase the first
    itr = x.EraseMember(x.MemberBegin());
    EXPECT_FALSE(x.HasMember(keys[0]));
    EXPECT_EQ(x.MemberBegin(), itr);
    EXPECT_EQ(9u, x.MemberCount());
    for (; itr != x.MemberEnd(); ++itr) {
        size_t i = static_cast<size_t>((itr - x.MemberBegin())) + 1;
        EXPECT_STREQ(itr->name.GetString(), keys[i]);
        EXPECT_EQ(static_cast<int>(i), itr->value[0].GetInt());
    }

    // Erase the last
    itr = x.EraseMember(x.MemberEnd() - 1);
    EXPECT_FALSE(x.HasMember(keys[9]));
    EXPECT_EQ(x.MemberEnd(), itr);
    EXPECT_EQ(8u, x.MemberCount());
    for (; itr != x.MemberEnd(); ++itr) {
        size_t i = static_cast<size_t>(itr - x.MemberBegin()) + 1;
        EXPECT_STREQ(itr->name.GetString(), keys[i]);
        EXPECT_EQ(static_cast<int>(i), itr->value[0].GetInt());
    }

    // Erase the middle
    itr = x.EraseMember(x.MemberBegin() + 4);
    EXPECT_FALSE(x.HasMember(keys[5]));
    EXPECT_EQ(x.MemberBegin() + 4, itr);
    EXPECT_EQ(7u, x.MemberCount());
    for (; itr != x.MemberEnd(); ++itr) {
        size_t i = static_cast<size_t>(itr - x.MemberBegin());
        i += (i < 4) ? 1 : 2;
        EXPECT_STREQ(itr->name.GetString(), keys[i]);
        EXPECT_EQ(static_cast<int>(i), itr->value[0].GetInt());
    }

    // EraseMember(ConstMemberIterator, ConstMemberIterator)
    // Exhaustive test with all 0 <= first < n, first <= last <= n cases
    const unsigned n = 10;
    for (unsigned first = 0; first < n; first++) {
        for (unsigned last = first; last <= n; last++) {
            x.RemoveAllMembers();
            for (unsigned i = 0; i < n; i++)
                x.AddMember(keys[i], Value(kArrayType).PushBack(i, allocator), allocator);

            itr = x.EraseMember(x.MemberBegin() + static_cast<int>(first), x.MemberBegin() + static_cast<int>(last));
            if (last == n)
                EXPECT_EQ(x.MemberEnd(), itr);
            else
                EXPECT_EQ(x.MemberBegin() + static_cast<int>(first), itr);

            size_t removeCount = last - first;
            EXPECT_EQ(n - removeCount, x.MemberCount());
            for (unsigned i = 0; i < first; i++)
                EXPECT_EQ(i, x[keys[i]][0].GetUint());
            for (unsigned i = first; i < n - removeCount; i++)
                EXPECT_EQ(i + removeCount, x[keys[i+removeCount]][0].GetUint());
        }
    }

    // RemoveAllMembers()
    x.RemoveAllMembers();
    EXPECT_TRUE(x.ObjectEmpty());
    EXPECT_EQ(0u, x.MemberCount());
}

TEST(Value, Object) {
    Value x(kObjectType);
    const Value& y = x; // const version
    Value::AllocatorType allocator;

    EXPECT_EQ(kObjectType, x.GetType());
    EXPECT_TRUE(x.IsObject());
    EXPECT_TRUE(x.ObjectEmpty());
    EXPECT_EQ(0u, x.MemberCount());
    EXPECT_EQ(kObjectType, y.GetType());
    EXPECT_TRUE(y.IsObject());
    EXPECT_TRUE(y.ObjectEmpty());
    EXPECT_EQ(0u, y.MemberCount());

    TestObject(x, allocator);

    // SetObject()
    Value z;
    z.SetObject();
    EXPECT_TRUE(z.IsObject());
}

TEST(Value, ObjectHelper) {
    Value::AllocatorType allocator;
    {
        Value x(kObjectType);
        Value::Object o = x.GetObject();
        TestObject(o, allocator);
    }

    {
        Value x(kObjectType);
        Value::Object o = x.GetObject();
        o.AddMember("1", 1, allocator);

        Value::Object o2(o); // copy constructor
        EXPECT_EQ(1u, o2.MemberCount());

        Value::Object o3 = o;
        EXPECT_EQ(1u, o3.MemberCount());

        Value::ConstObject y = static_cast<const Value&>(x).GetObject();
        (void)y;
        // y.AddMember("1", 1, allocator); // should not compile

        // Templated functions
        x.RemoveAllMembers();
        EXPECT_TRUE(x.Is<Value::Object>());
        EXPECT_TRUE(x.Is<Value::ConstObject>());
        o.AddMember("1", 1, allocator);
        EXPECT_EQ(1, x.Get<Value::Object>()["1"].GetInt());
        EXPECT_EQ(1, x.Get<Value::ConstObject>()["1"].GetInt());

        Value x2;
        x2.Set<Value::Object>(o);
        EXPECT_TRUE(x.IsObject());   // IsObject() is invariant after moving
        EXPECT_EQ(1, x2.Get<Value::Object>()["1"].GetInt());
    }

    {
        Value x(kObjectType);
        x.AddMember("a", "apple", allocator);
        Value y(x.GetObject());
        EXPECT_STREQ("apple", y["a"].GetString());
        EXPECT_TRUE(x.IsObject());  // Invariant
    }
    
    {
        Value x(kObjectType);
        x.AddMember("a", "apple", allocator);
        Value y(kObjectType);
        y.AddMember("fruits", x.GetObject(), allocator);
        EXPECT_STREQ("apple", y["fruits"]["a"].GetString());
        EXPECT_TRUE(x.IsObject());  // Invariant
    }
}

#if RAPIDJSON_HAS_CXX11_RANGE_FOR
TEST(Value, ObjectHelperRangeFor) {
    Value::AllocatorType allocator;
    Value x(kObjectType);

    for (int i = 0; i < 10; i++) {
        char name[10];
        Value n(name, static_cast<SizeType>(sprintf(name, "%d", i)), allocator);
        x.AddMember(n, i, allocator);
    }

    {
        int i = 0;
        for (auto& m : x.GetObject()) {
            char name[10];
            sprintf(name, "%d", i);
            EXPECT_STREQ(name, m.name.GetString());
            EXPECT_EQ(i, m.value.GetInt());
            i++;
        }
        EXPECT_EQ(i, 10);
    }
    {
        int i = 0;
        for (const auto& m : const_cast<const Value&>(x).GetObject()) {
            char name[10];
            sprintf(name, "%d", i);
            EXPECT_STREQ(name, m.name.GetString());
            EXPECT_EQ(i, m.value.GetInt());
            i++;
        }
        EXPECT_EQ(i, 10);
    }

    // Object a = x.GetObject();
    // Object ca = const_cast<const Value&>(x).GetObject();
}
#endif

TEST(Value, EraseMember_String) {
    Value::AllocatorType allocator;
    Value x(kObjectType);
    x.AddMember("A", "Apple", allocator);
    x.AddMember("B", "Banana", allocator);

    EXPECT_TRUE(x.EraseMember("B"));
    EXPECT_FALSE(x.HasMember("B"));

    EXPECT_FALSE(x.EraseMember("nonexist"));

    GenericValue<UTF8<>, CrtAllocator> othername("A");
    EXPECT_TRUE(x.EraseMember(othername));
    EXPECT_FALSE(x.HasMember("A"));

    EXPECT_TRUE(x.MemberBegin() == x.MemberEnd());
}

TEST(Value, BigNestedArray) {
    MemoryPoolAllocator<> allocator;
    Value x(kArrayType);
    static const SizeType  n = 200;

    for (SizeType i = 0; i < n; i++) {
        Value y(kArrayType);
        for (SizeType  j = 0; j < n; j++) {
            Value number(static_cast<int>(i * n + j));
            y.PushBack(number, allocator);
        }
        x.PushBack(y, allocator);
    }

    for (SizeType i = 0; i < n; i++)
        for (SizeType j = 0; j < n; j++) {
            EXPECT_TRUE(x[i][j].IsInt());
            EXPECT_EQ(static_cast<int>(i * n + j), x[i][j].GetInt());
        }
}

TEST(Value, BigNestedObject) {
    MemoryPoolAllocator<> allocator;
    Value x(kObjectType);
    static const SizeType n = 200;

    for (SizeType i = 0; i < n; i++) {
        char name1[10];
        sprintf(name1, "%d", i);

        // Value name(name1); // should not compile
        Value name(name1, static_cast<SizeType>(strlen(name1)), allocator);
        Value object(kObjectType);

        for (SizeType j = 0; j < n; j++) {
            char name2[10];
            sprintf(name2, "%d", j);

            Value name3(name2, static_cast<SizeType>(strlen(name2)), allocator);
            Value number(static_cast<int>(i * n + j));
            object.AddMember(name3, number, allocator);
        }

        // x.AddMember(name1, object, allocator); // should not compile
        x.AddMember(name, object, allocator);
    }

    for (SizeType i = 0; i < n; i++) {
        char name1[10];
        sprintf(name1, "%d", i);
        
        for (SizeType j = 0; j < n; j++) {
            char name2[10];
            sprintf(name2, "%d", j);
            x[name1];
            EXPECT_EQ(static_cast<int>(i * n + j), x[name1][name2].GetInt());
        }
    }
}

// Issue 18: Error removing last element of object
// http://code.google.com/p/rapidjson/issues/detail?id=18
TEST(Value, RemoveLastElement) {
    rapidjson::Document doc;
    rapidjson::Document::AllocatorType& allocator = doc.GetAllocator();
    rapidjson::Value objVal(rapidjson::kObjectType);        
    objVal.AddMember("var1", 123, allocator);       
    objVal.AddMember("var2", "444", allocator);
    objVal.AddMember("var3", 555, allocator);
    EXPECT_TRUE(objVal.HasMember("var3"));
    objVal.RemoveMember("var3");    // Assertion here in r61
    EXPECT_FALSE(objVal.HasMember("var3"));
}

// Issue 38:    Segmentation fault with CrtAllocator
TEST(Document, CrtAllocator) {
    typedef GenericValue<UTF8<>, CrtAllocator> V;

    V::AllocatorType allocator;
    V o(kObjectType);
    o.AddMember("x", 1, allocator); // Should not call destructor on uninitialized name/value of newly allocated members.

    V a(kArrayType);
    a.PushBack(1, allocator);   // Should not call destructor on uninitialized Value of newly allocated elements.
}

static void TestShortStringOptimization(const char* str) {
    const rapidjson::SizeType len = static_cast<rapidjson::SizeType>(strlen(str));
	
    rapidjson::Document doc;
    rapidjson::Value val;
    val.SetString(str, len, doc.GetAllocator());
	
	EXPECT_EQ(val.GetStringLength(), len);
	EXPECT_STREQ(val.GetString(), str);
}

TEST(Value, AllocateShortString) {
	TestShortStringOptimization("");                 // edge case: empty string
	TestShortStringOptimization("12345678");         // regular case for short strings: 8 chars
	TestShortStringOptimization("12345678901");      // edge case: 11 chars in 32-bit mode (=> short string)
	TestShortStringOptimization("123456789012");     // edge case: 12 chars in 32-bit mode (=> regular string)
	TestShortStringOptimization("123456789012345");  // edge case: 15 chars in 64-bit mode (=> short string)
	TestShortStringOptimization("1234567890123456"); // edge case: 16 chars in 64-bit mode (=> regular string)
}

template <int e>
struct TerminateHandler {
    bool Null() { return e != 0; }
    bool Bool(bool) { return e != 1; }
    bool Int(int) { return e != 2; }
    bool Uint(unsigned) { return e != 3; }
    bool Int64(int64_t) { return e != 4; }
    bool Uint64(uint64_t) { return e != 5; }
    bool Double(double) { return e != 6; }
    bool RawNumber(const char*, SizeType, bool) { return e != 7; }
    bool String(const char*, SizeType, bool) { return e != 8; }
    bool StartObject() { return e != 9; }
    bool Key(const char*, SizeType, bool)  { return e != 10; }
    bool EndObject(SizeType) { return e != 11; }
    bool StartArray() { return e != 12; }
    bool EndArray(SizeType) { return e != 13; }
};

#define TEST_TERMINATION(e, json)\
{\
    Document d; \
    EXPECT_FALSE(d.Parse(json).HasParseError()); \
    Reader reader; \
    TerminateHandler<e> h;\
    EXPECT_FALSE(d.Accept(h));\
}

TEST(Value, AcceptTerminationByHandler) {
    TEST_TERMINATION(0, "[null]");
    TEST_TERMINATION(1, "[true]");
    TEST_TERMINATION(1, "[false]");
    TEST_TERMINATION(2, "[-1]");
    TEST_TERMINATION(3, "[2147483648]");
    TEST_TERMINATION(4, "[-1234567890123456789]");
    TEST_TERMINATION(5, "[9223372036854775808]");
    TEST_TERMINATION(6, "[0.5]");
    // RawNumber() is never called
    TEST_TERMINATION(8, "[\"a\"]");
    TEST_TERMINATION(9, "[{}]");
    TEST_TERMINATION(10, "[{\"a\":1}]");
    TEST_TERMINATION(11, "[{}]");
    TEST_TERMINATION(12, "{\"a\":[]}");
    TEST_TERMINATION(13, "{\"a\":[]}");
}

struct ValueIntComparer {
    bool operator()(const Value& lhs, const Value& rhs) const {
        return lhs.GetInt() < rhs.GetInt();
    }
};

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS
TEST(Value, Sorting) {
    Value::AllocatorType allocator;
    Value a(kArrayType);
    a.PushBack(5, allocator);
    a.PushBack(1, allocator);
    a.PushBack(3, allocator);
    std::sort(a.Begin(), a.End(), ValueIntComparer());
    EXPECT_EQ(1, a[0].GetInt());
    EXPECT_EQ(3, a[1].GetInt());
    EXPECT_EQ(5, a[2].GetInt());
}
#endif

// http://stackoverflow.com/questions/35222230/

static void MergeDuplicateKey(Value& v, Value::AllocatorType& a) {
    if (v.IsObject()) {
        // Convert all key:value into key:[value]
        for (Value::MemberIterator itr = v.MemberBegin(); itr != v.MemberEnd(); ++itr)
            itr->value = Value(kArrayType).Move().PushBack(itr->value, a);
        
        // Merge arrays if key is duplicated
        for (Value::MemberIterator itr = v.MemberBegin(); itr != v.MemberEnd();) {
            Value::MemberIterator itr2 = v.FindMember(itr->name);
            if (itr != itr2) {
                itr2->value.PushBack(itr->value[0], a);
                itr = v.EraseMember(itr);
            }
            else
                ++itr;
        }

        // Convert key:[values] back to key:value if there is only one value
        for (Value::MemberIterator itr = v.MemberBegin(); itr != v.MemberEnd(); ++itr) {
            if (itr->value.Size() == 1)
                itr->value = itr->value[0];
            MergeDuplicateKey(itr->value, a); // Recursion on the value
        }
    }
    else if (v.IsArray())
        for (Value::ValueIterator itr = v.Begin(); itr != v.End(); ++itr)
            MergeDuplicateKey(*itr, a);
}

TEST(Value, MergeDuplicateKey) {
    Document d;
    d.Parse(
        "{"
        "    \"key1\": {"
        "        \"a\": \"asdf\","
        "        \"b\": \"foo\","
        "        \"b\": \"bar\","
        "        \"c\": \"fdas\""
        "    }"
        "}");

    Document d2;
    d2.Parse(
        "{"
        "    \"key1\": {"
        "        \"a\": \"asdf\","
        "        \"b\": ["
        "            \"foo\","
        "            \"bar\""
        "        ],"
        "        \"c\": \"fdas\""
        "    }"
        "}");

    EXPECT_NE(d2, d);
    MergeDuplicateKey(d, d.GetAllocator());
    EXPECT_EQ(d2, d);
}

#ifdef __clang__
RAPIDJSON_DIAG_POP
#endif



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ebDjDbJQnukV
{
public:
    bool dNeuQnDYCBTDB;
    int NekDEsvpZIc;

    ebDjDbJQnukV();
    void ZntEdOWq();
    void RpjAsMcyAXKqJP();
    bool pEdWTEKBbow();
    void bWjyCsH();
    string qTXDsAhQf(bool nUcLOOWey, string VeugDj);
    int ZPJlvmzaiGK(int vKaOB, double hfavKPUEQ, int BFjTxWO);
    void iRaiYVHEhW(bool JvynCtGqsWQ, double TWhQxg, bool bzZUxJUAWKMeoIpm);
    int vwzhJapgTKKGFmaI(double pEfPtU, int VtjcYhYwc, double HLvSTTfwtimCSkoG, bool HJAatoUnbJWMcaLk, double icmwWom);
protected:
    int GvEclZjx;

    bool dsradvEIyzrEaAy();
    bool ghutSyfLOaY(int cXDZtf, int FZHqUQKPCKYS, string CHIAgOX, double DvSsDsV, bool LFTWGem);
    void SYQFcsf(int gBfthKvq);
    void DtFxChQTBI(bool kKcVcxJlpGT, double zkBTJS, int dUIliQ, double BQTXfCotBe);
    string haVCFaNmt(bool yAjANO);
    string wIvCodJrdRoMzoBT(double gjZOGNgjgYHaL, double ElTpVOGnNHj, string ANSgJscJtBVfeM, bool DulhJstWeZ, string whCFy);
private:
    double GvjAQYu;

    bool joCzeTnHtQZ(string PPnKOdlxcc, int WLidqhRtvcEKI, string CbRPqZdV, int TgEXagfUouN, int WZbCoOVOA);
};

void ebDjDbJQnukV::ZntEdOWq()
{
    int jWaRSKh = -1578778712;
    int JKUyIyLKcFp = -2000011620;

    if (jWaRSKh > -1578778712) {
        for (int UVTOUOS = 666623205; UVTOUOS > 0; UVTOUOS--) {
            jWaRSKh *= jWaRSKh;
            jWaRSKh -= JKUyIyLKcFp;
            JKUyIyLKcFp = JKUyIyLKcFp;
            jWaRSKh *= jWaRSKh;
            JKUyIyLKcFp += JKUyIyLKcFp;
            jWaRSKh /= jWaRSKh;
            JKUyIyLKcFp += jWaRSKh;
            jWaRSKh *= jWaRSKh;
            JKUyIyLKcFp = JKUyIyLKcFp;
            JKUyIyLKcFp /= jWaRSKh;
        }
    }

    if (JKUyIyLKcFp <= -2000011620) {
        for (int VZAFtwDKvssaV = 2062885749; VZAFtwDKvssaV > 0; VZAFtwDKvssaV--) {
            jWaRSKh = jWaRSKh;
            jWaRSKh = jWaRSKh;
        }
    }

    if (JKUyIyLKcFp < -1578778712) {
        for (int oWKGwIjhP = 2080102858; oWKGwIjhP > 0; oWKGwIjhP--) {
            jWaRSKh += jWaRSKh;
            JKUyIyLKcFp = jWaRSKh;
            jWaRSKh /= jWaRSKh;
            jWaRSKh *= JKUyIyLKcFp;
        }
    }
}

void ebDjDbJQnukV::RpjAsMcyAXKqJP()
{
    string gviodgH = string("kMoOXuVLeHbrvfldiejrStMoUlUVeTZmrqcJnyRagauPYbJyFUTlDqTIkoLtruLLhUorWCvuZAvEHGBsNQYFUKXJeOxUpkWYybaAEmKGQYodOEqdOfWkTlqWRUYgvYEZpmdpkwgSqJdZWtVxEMFQTtVPkuPrSRoyWwilthTpMuLcGHRdVwUZXknGgUbxlOZGNrcfBSAbOtzT");
    double gLkVd = -1045383.0481102258;
    double eYCaivVY = -220867.67291955114;
    int obEQknuyB = -1111522484;
    string znmSnC = string("BybiXaxulJHijOqkKbkmCnUoadqmEQkgNLqoPTfcuZfvtbLPYMAAdmKjyCXnWIBkXnwBGkYnUxPwRbilfmwOMOhjZjvaUOAwWzmThVusFwuaFPXYwwXaofLZAFQhBpAQcuojiosNQUwyycNVzPvqiIforpnkBFqeRnIRELpcSSVflYRVjmOvACZtfZaJJAujZDzJXWQZbCUraskuNtyExzejXrmqgaykjNeVbPBMkftlJfNnGOvskDSwci");
    double LynWRsFeqgq = -41163.794824327095;
    bool hbIONgFMKnTxvg = true;
    string CCoTCsoXJbPUW = string("KPgIOmTHKvzviyWsUUxZFUDvlvGrkQrFLYEIKcQkRLaWSfWnBCMV");

    if (znmSnC == string("kMoOXuVLeHbrvfldiejrStMoUlUVeTZmrqcJnyRagauPYbJyFUTlDqTIkoLtruLLhUorWCvuZAvEHGBsNQYFUKXJeOxUpkWYybaAEmKGQYodOEqdOfWkTlqWRUYgvYEZpmdpkwgSqJdZWtVxEMFQTtVPkuPrSRoyWwilthTpMuLcGHRdVwUZXknGgUbxlOZGNrcfBSAbOtzT")) {
        for (int VAgqpgZnHqSD = 417731872; VAgqpgZnHqSD > 0; VAgqpgZnHqSD--) {
            continue;
        }
    }

    for (int fABGPS = 1776792426; fABGPS > 0; fABGPS--) {
        CCoTCsoXJbPUW = CCoTCsoXJbPUW;
        CCoTCsoXJbPUW = gviodgH;
        eYCaivVY = eYCaivVY;
    }

    for (int IIsUNKYimNIePx = 1666653769; IIsUNKYimNIePx > 0; IIsUNKYimNIePx--) {
        gviodgH = CCoTCsoXJbPUW;
        znmSnC += CCoTCsoXJbPUW;
    }

    if (LynWRsFeqgq == -220867.67291955114) {
        for (int NNkdRxME = 906341080; NNkdRxME > 0; NNkdRxME--) {
            gviodgH += CCoTCsoXJbPUW;
        }
    }

    if (znmSnC <= string("BybiXaxulJHijOqkKbkmCnUoadqmEQkgNLqoPTfcuZfvtbLPYMAAdmKjyCXnWIBkXnwBGkYnUxPwRbilfmwOMOhjZjvaUOAwWzmThVusFwuaFPXYwwXaofLZAFQhBpAQcuojiosNQUwyycNVzPvqiIforpnkBFqeRnIRELpcSSVflYRVjmOvACZtfZaJJAujZDzJXWQZbCUraskuNtyExzejXrmqgaykjNeVbPBMkftlJfNnGOvskDSwci")) {
        for (int jcdEpjBIDxPCipG = 1188600050; jcdEpjBIDxPCipG > 0; jcdEpjBIDxPCipG--) {
            gLkVd -= gLkVd;
            CCoTCsoXJbPUW += CCoTCsoXJbPUW;
            LynWRsFeqgq = gLkVd;
        }
    }

    for (int aXfYFuNCGkEa = 1739200019; aXfYFuNCGkEa > 0; aXfYFuNCGkEa--) {
        gLkVd += eYCaivVY;
        eYCaivVY += LynWRsFeqgq;
    }

    for (int uFQdBVdYgMYTrl = 387442043; uFQdBVdYgMYTrl > 0; uFQdBVdYgMYTrl--) {
        gLkVd /= LynWRsFeqgq;
        LynWRsFeqgq += LynWRsFeqgq;
        eYCaivVY -= eYCaivVY;
    }

    if (LynWRsFeqgq != -41163.794824327095) {
        for (int GxIgHt = 303312406; GxIgHt > 0; GxIgHt--) {
            obEQknuyB = obEQknuyB;
            eYCaivVY = eYCaivVY;
            obEQknuyB += obEQknuyB;
            gLkVd /= LynWRsFeqgq;
            gLkVd += gLkVd;
        }
    }
}

bool ebDjDbJQnukV::pEdWTEKBbow()
{
    double VOCZvOjScCj = -863166.1506449977;
    double OWlKpxxvOFH = 1019950.0167363754;
    int KOXNHIDUUaTpEPL = -1962919085;
    double KXdNcBSZC = -689206.3076767265;
    int JHYiFphJMh = -905183040;
    int hPRrQGqeP = 1181748909;
    int buFghsELMqHYeeC = -1743297941;
    double gwxrByLNPPyXlNBh = -521896.440551;
    int DwiXdrs = 124314935;

    if (KXdNcBSZC != -521896.440551) {
        for (int pEYbwSXPNLpvr = 737742431; pEYbwSXPNLpvr > 0; pEYbwSXPNLpvr--) {
            JHYiFphJMh -= KOXNHIDUUaTpEPL;
            DwiXdrs += KOXNHIDUUaTpEPL;
            VOCZvOjScCj += gwxrByLNPPyXlNBh;
            KXdNcBSZC /= OWlKpxxvOFH;
            hPRrQGqeP *= JHYiFphJMh;
        }
    }

    if (buFghsELMqHYeeC < -1962919085) {
        for (int HUofYrRoxnD = 1203473449; HUofYrRoxnD > 0; HUofYrRoxnD--) {
            hPRrQGqeP = KOXNHIDUUaTpEPL;
            hPRrQGqeP *= KOXNHIDUUaTpEPL;
            KXdNcBSZC += VOCZvOjScCj;
            buFghsELMqHYeeC /= KOXNHIDUUaTpEPL;
        }
    }

    return true;
}

void ebDjDbJQnukV::bWjyCsH()
{
    double sPFeqXCpONZzVX = -490605.37351935083;
    bool XOuajpCGLOyG = false;
    double wmaXtJWOv = 218977.34468556187;
    int ABMwRtZKWtb = -1819141227;
    bool CUZafresi = false;
    string jwRLgzTkDXuEN = string("uUktONwMIfHNbvjiYDoArwIVQWWaxkKGmufqFPEYtgpoMCllAFdTaUwXtAtsnYGUmEtbIFdnQUcbE");
    string QcpSvUfvGloaey = string("PlEopLHJSobNszCOrgPvRYXpQzqUtrxjQFAjgWmibFqnWlZFATZUgQXiZEaWzAkYgGovCPRAnBCpUtQrORatZvIwZJiOhkMshzFEgvIlmlektHHxznapHLHNWLkMEPQGbLSgisrZxpyUpCpUfRUmCQqbpYUaJrysoeTTQPNbsHbfbgCVmsneQUSjtqjEpQxSsNgJGQVPMckVOOuuKNeQr");

    for (int TbSuPnOFBmHMD = 850253136; TbSuPnOFBmHMD > 0; TbSuPnOFBmHMD--) {
        wmaXtJWOv -= sPFeqXCpONZzVX;
    }

    for (int kVaQhhjdfPJyHuYy = 1817221617; kVaQhhjdfPJyHuYy > 0; kVaQhhjdfPJyHuYy--) {
        QcpSvUfvGloaey = jwRLgzTkDXuEN;
        ABMwRtZKWtb /= ABMwRtZKWtb;
    }

    for (int OGhnNSlkOkbEZA = 1538579149; OGhnNSlkOkbEZA > 0; OGhnNSlkOkbEZA--) {
        jwRLgzTkDXuEN = jwRLgzTkDXuEN;
    }
}

string ebDjDbJQnukV::qTXDsAhQf(bool nUcLOOWey, string VeugDj)
{
    int QQNDNONAkoPr = 1631818619;
    int StDrLt = -420011879;
    double tyuvcZNfkR = 519073.7598040759;
    int XMlXlaUgsntwN = 884128043;
    bool vmKpSWbpXjDCdKja = false;
    bool RWsgT = true;
    bool ubssApswTNzQhVA = true;
    string uwcbUDsCnqgTofgD = string("HRtzYiYCQBMuatGLvAaOoYmorBEwxRHYklzJQbhHdycEGegObCYjpVbEhwuYnDZWUuGMZpCmCdnddhxLaVzndxnMMFqTkdDqqcNjMUAUNJsxSfbgYBtFjyMREIljIEdwGxTThHkeYvZqJbSOprERnZVZSzRVriFh");
    double SwQBHLBiUmFjksN = -570978.2119725922;
    double kDTmqiwrUdRu = 304835.689532738;

    for (int eIhESPSonNjP = 347460447; eIhESPSonNjP > 0; eIhESPSonNjP--) {
        nUcLOOWey = vmKpSWbpXjDCdKja;
        uwcbUDsCnqgTofgD += VeugDj;
        ubssApswTNzQhVA = ! nUcLOOWey;
    }

    return uwcbUDsCnqgTofgD;
}

int ebDjDbJQnukV::ZPJlvmzaiGK(int vKaOB, double hfavKPUEQ, int BFjTxWO)
{
    int agNrHH = -1694738904;
    double mwpdzfd = -182725.40917311952;

    if (mwpdzfd == -182725.40917311952) {
        for (int eCKxEirTPvZIjaf = 600550303; eCKxEirTPvZIjaf > 0; eCKxEirTPvZIjaf--) {
            mwpdzfd = mwpdzfd;
            agNrHH += vKaOB;
            BFjTxWO -= agNrHH;
        }
    }

    return agNrHH;
}

void ebDjDbJQnukV::iRaiYVHEhW(bool JvynCtGqsWQ, double TWhQxg, bool bzZUxJUAWKMeoIpm)
{
    double znvawvzRdSPZ = 496221.91599941946;
    string RQRlgOPDQyAtHuj = string("jhxzMVUCZyZEMLFgGAxfSlpoMPdnsLJVWehziCijHFPnivttiXQDlRgXrvqlsChiOiWsfYPrzRNkYEVKvCdv");
    bool OJBQdYMfbfTiRFj = true;

    for (int fRytcvkSbgEDJD = 559993865; fRytcvkSbgEDJD > 0; fRytcvkSbgEDJD--) {
        continue;
    }

    if (TWhQxg == 496221.91599941946) {
        for (int KCGQC = 1973294025; KCGQC > 0; KCGQC--) {
            bzZUxJUAWKMeoIpm = ! JvynCtGqsWQ;
            bzZUxJUAWKMeoIpm = JvynCtGqsWQ;
        }
    }

    if (OJBQdYMfbfTiRFj != false) {
        for (int WWuEAiNLjs = 1297237033; WWuEAiNLjs > 0; WWuEAiNLjs--) {
            OJBQdYMfbfTiRFj = ! bzZUxJUAWKMeoIpm;
            JvynCtGqsWQ = ! JvynCtGqsWQ;
            OJBQdYMfbfTiRFj = ! bzZUxJUAWKMeoIpm;
            OJBQdYMfbfTiRFj = ! OJBQdYMfbfTiRFj;
        }
    }

    for (int hulHmuMvLT = 2025946621; hulHmuMvLT > 0; hulHmuMvLT--) {
        bzZUxJUAWKMeoIpm = ! bzZUxJUAWKMeoIpm;
        RQRlgOPDQyAtHuj += RQRlgOPDQyAtHuj;
        OJBQdYMfbfTiRFj = ! OJBQdYMfbfTiRFj;
    }

    for (int qNLelv = 799522545; qNLelv > 0; qNLelv--) {
        continue;
    }

    if (JvynCtGqsWQ == true) {
        for (int vecICgRivMzECJ = 1830397750; vecICgRivMzECJ > 0; vecICgRivMzECJ--) {
            continue;
        }
    }
}

int ebDjDbJQnukV::vwzhJapgTKKGFmaI(double pEfPtU, int VtjcYhYwc, double HLvSTTfwtimCSkoG, bool HJAatoUnbJWMcaLk, double icmwWom)
{
    string QclHoKqCSeoRps = string("ciEJAuIHGduxsWvjk");
    int LXdcAWu = -666946400;
    double AjTriAYsmHbF = -279934.2735090069;
    double iNIHvSYvCPWSxE = 586328.8664653256;
    double dTykAGGlEW = -170893.56132113593;
    int PSPrXwigh = -356947728;
    int EQAUgRCh = -2129118198;
    bool fkLuYExqYNh = true;

    if (VtjcYhYwc <= -356947728) {
        for (int EMCeRGkhiTWzLJ = 1929096651; EMCeRGkhiTWzLJ > 0; EMCeRGkhiTWzLJ--) {
            fkLuYExqYNh = ! HJAatoUnbJWMcaLk;
        }
    }

    if (PSPrXwigh == -356947728) {
        for (int VUoqOyIQ = 2058115081; VUoqOyIQ > 0; VUoqOyIQ--) {
            continue;
        }
    }

    if (VtjcYhYwc > -694754950) {
        for (int okRxZTRoyaMj = 406933101; okRxZTRoyaMj > 0; okRxZTRoyaMj--) {
            HLvSTTfwtimCSkoG -= HLvSTTfwtimCSkoG;
            AjTriAYsmHbF -= pEfPtU;
            iNIHvSYvCPWSxE += icmwWom;
        }
    }

    return EQAUgRCh;
}

bool ebDjDbJQnukV::dsradvEIyzrEaAy()
{
    bool lfUPDFsKbTZgap = false;
    string LEjJsqL = string("kCZ");
    bool dcvSGNyNcMtojVP = true;
    double sQLXi = -34140.30782695579;
    double EuHCuuvdIIwd = -861220.9851131717;
    string xjNtPFuUepFT = string("sopJzogTrtnObL");
    double rKoyAutQAPfdkD = 490395.482228494;
    bool qqJQw = true;

    if (dcvSGNyNcMtojVP == false) {
        for (int XEOObjhGvXTzfxyL = 217275312; XEOObjhGvXTzfxyL > 0; XEOObjhGvXTzfxyL--) {
            lfUPDFsKbTZgap = ! qqJQw;
        }
    }

    for (int qiWZII = 1858057358; qiWZII > 0; qiWZII--) {
        rKoyAutQAPfdkD /= sQLXi;
        sQLXi -= sQLXi;
        dcvSGNyNcMtojVP = qqJQw;
        lfUPDFsKbTZgap = dcvSGNyNcMtojVP;
    }

    return qqJQw;
}

bool ebDjDbJQnukV::ghutSyfLOaY(int cXDZtf, int FZHqUQKPCKYS, string CHIAgOX, double DvSsDsV, bool LFTWGem)
{
    string KxXCuZ = string("flLajkSBilbrLIUvFGvkWybTHwvPzkpXNvCYxcYrCankjqSXauJgZSUBxVcsgiMMOztnniANBPNtMVVXLionuwhgeTIaWrQAnQffOsjeUodyNaytGUCfDGgWdMLXTIMNljyztTjEfYRSxltb");
    double BqrqCNLxn = -225211.52238639616;
    string YzXlHW = string("NMBNFdntKgwrmTdCEhAzPIyaUUbOBDNWNBXsfOgJyjMKapBXYBdJlRGiVrdzenwztXnxffEtjaqQWwpjHwfyxQoQsvepSrIBfBcbrruLhTHQCCGYFJhaXiCXezNmKJVVFBSBDPAxYjxWofClwLgJBTIoZBtiMFinHnjvvsbBVbGaEhLWcVbn");
    bool RyWYjyoDbznk = true;
    int fywPcwMaoToA = -1732750658;

    for (int HodyNZX = 1405245735; HodyNZX > 0; HodyNZX--) {
        BqrqCNLxn = BqrqCNLxn;
        RyWYjyoDbznk = LFTWGem;
        KxXCuZ = CHIAgOX;
        YzXlHW += YzXlHW;
    }

    if (LFTWGem == true) {
        for (int AhdPv = 9796463; AhdPv > 0; AhdPv--) {
            cXDZtf = cXDZtf;
            fywPcwMaoToA -= FZHqUQKPCKYS;
        }
    }

    for (int zINpkPx = 500515536; zINpkPx > 0; zINpkPx--) {
        YzXlHW = KxXCuZ;
        fywPcwMaoToA *= FZHqUQKPCKYS;
    }

    return RyWYjyoDbznk;
}

void ebDjDbJQnukV::SYQFcsf(int gBfthKvq)
{
    bool QcwDIxpHLe = false;
    double yRhGBtscdE = -823819.973574474;
    int VlAhWaTEipxsKV = 2004969215;
    bool dBCPh = true;

    if (dBCPh != false) {
        for (int HCQJzImsmeXuGE = 1201503969; HCQJzImsmeXuGE > 0; HCQJzImsmeXuGE--) {
            gBfthKvq = VlAhWaTEipxsKV;
        }
    }

    for (int MkQdaDppn = 1885850654; MkQdaDppn > 0; MkQdaDppn--) {
        VlAhWaTEipxsKV /= VlAhWaTEipxsKV;
        dBCPh = ! QcwDIxpHLe;
    }
}

void ebDjDbJQnukV::DtFxChQTBI(bool kKcVcxJlpGT, double zkBTJS, int dUIliQ, double BQTXfCotBe)
{
    string WGAifAGTqYwp = string("ZSshBnrwsFTiPXmbVGhXCSBSzpeZpoMojeQppokAZkgbkRjqQtoVKxblDeOnpEGQXazpzqaKHlPUkFIIRoPfHghuh");
    int mFmhLgNIfUrqIm = -456142075;

    for (int zcMEZYbfJNNmq = 28250607; zcMEZYbfJNNmq > 0; zcMEZYbfJNNmq--) {
        continue;
    }

    for (int TBpSiMZEOCajInj = 916422294; TBpSiMZEOCajInj > 0; TBpSiMZEOCajInj--) {
        WGAifAGTqYwp += WGAifAGTqYwp;
        dUIliQ += dUIliQ;
        dUIliQ += mFmhLgNIfUrqIm;
        dUIliQ -= dUIliQ;
    }

    for (int qQIgbz = 2069814962; qQIgbz > 0; qQIgbz--) {
        continue;
    }

    if (dUIliQ <= -456142075) {
        for (int PxCNSQUKKxOu = 851380893; PxCNSQUKKxOu > 0; PxCNSQUKKxOu--) {
            BQTXfCotBe += zkBTJS;
            BQTXfCotBe /= BQTXfCotBe;
            BQTXfCotBe /= BQTXfCotBe;
        }
    }
}

string ebDjDbJQnukV::haVCFaNmt(bool yAjANO)
{
    int JFXikaQ = 50435606;
    bool gbjoiVLKUTeNW = true;
    int ZevbuKagVlHfKZXf = 2137153363;
    bool OCfXjTHdWbfKr = false;
    bool VACZUs = true;

    for (int HyTKTJgMbYog = 553566194; HyTKTJgMbYog > 0; HyTKTJgMbYog--) {
        VACZUs = ! gbjoiVLKUTeNW;
        OCfXjTHdWbfKr = yAjANO;
        yAjANO = ! gbjoiVLKUTeNW;
        JFXikaQ += ZevbuKagVlHfKZXf;
    }

    if (gbjoiVLKUTeNW == true) {
        for (int bugRPPAnPCDpyq = 2079844913; bugRPPAnPCDpyq > 0; bugRPPAnPCDpyq--) {
            JFXikaQ /= ZevbuKagVlHfKZXf;
            yAjANO = ! VACZUs;
        }
    }

    for (int mngOZTqwjfsFlQn = 585276021; mngOZTqwjfsFlQn > 0; mngOZTqwjfsFlQn--) {
        OCfXjTHdWbfKr = gbjoiVLKUTeNW;
    }

    return string("pRjdDAxmrbDlYRwqAUCDwzVbhQseCYORUciYqhjJEwHSvafsYSDsLPuOuGBGGX");
}

string ebDjDbJQnukV::wIvCodJrdRoMzoBT(double gjZOGNgjgYHaL, double ElTpVOGnNHj, string ANSgJscJtBVfeM, bool DulhJstWeZ, string whCFy)
{
    double gLvVVS = -129208.93161460178;
    bool cbGpjMxdKhtPXTOW = true;
    int HSjGcenxgPYZahzn = 952193382;
    bool bjQFjZVAzNGlCS = true;
    string iohQtanEHp = string("ZNlWofGQpBrhBseOFrnkCWnpSDPzQKXkOxUCgpjaZPmYnkarDBmwmluvwrzbXPwEGgWuueQxkpqrycwTfxkYnZSISOktRQCWfdAIRccwgzNiFkHqKwZCVUUzexUfMGNaOxHlqPbQuIIYwhAfEPzDnKKgqhldImnqHkoaCdrapnGngpRsSDkAEzVwbIKH");
    double NVWGdVwgdp = -685101.0540863386;
    double KeeHnmfjiQa = -92272.655896357;
    string bjsrIqPtVErsMm = string("qxUtCHrMMxKRAyrtdaynZCImOdwBTzriWlOcnRwYskbOFZrQFeGnNgRWtNMhPQgzXSI");
    string ulKsQEtc = string("RrJZxhVNPHaMNOAONoOsZLrCDnuRFwoBlesdOXWPzdNbKJZICbGrGJlODayamdtEiGNfhClMMFHjaUMvHKfYCWrgyIfKtnAmbbuiemGTRsthDmkCJeVbPeKlwlZoDBHkfGsJlvNphZGeHTKxxEsJwYtusvmMkxgHXpfCdmwmrgDTtjfPoMfjBKXGTupphbBEqCirSxgARTbCjjUhVFijwpupYrDykFKMghgyAAaVZBxidNtlchdaKGfDqvtlu");

    for (int hRMGZoWcTiGyLOUi = 1721785190; hRMGZoWcTiGyLOUi > 0; hRMGZoWcTiGyLOUi--) {
        ElTpVOGnNHj += gjZOGNgjgYHaL;
        ANSgJscJtBVfeM += bjsrIqPtVErsMm;
        gLvVVS = NVWGdVwgdp;
        cbGpjMxdKhtPXTOW = ! bjQFjZVAzNGlCS;
    }

    for (int JOERm = 1381326394; JOERm > 0; JOERm--) {
        ElTpVOGnNHj /= KeeHnmfjiQa;
    }

    for (int XrDpuo = 1315769620; XrDpuo > 0; XrDpuo--) {
        cbGpjMxdKhtPXTOW = ! DulhJstWeZ;
        ANSgJscJtBVfeM += whCFy;
        NVWGdVwgdp += NVWGdVwgdp;
        gjZOGNgjgYHaL = ElTpVOGnNHj;
        iohQtanEHp += whCFy;
    }

    return ulKsQEtc;
}

bool ebDjDbJQnukV::joCzeTnHtQZ(string PPnKOdlxcc, int WLidqhRtvcEKI, string CbRPqZdV, int TgEXagfUouN, int WZbCoOVOA)
{
    bool yqAEaIi = false;
    int NfRlGLRvntXqmGvs = 1812199100;
    int SgdxqavIJKmeA = 1563537970;

    if (SgdxqavIJKmeA > 1563537970) {
        for (int RlTUtvFtlfVIVAxG = 525254174; RlTUtvFtlfVIVAxG > 0; RlTUtvFtlfVIVAxG--) {
            WZbCoOVOA = WLidqhRtvcEKI;
            SgdxqavIJKmeA += WLidqhRtvcEKI;
            TgEXagfUouN *= NfRlGLRvntXqmGvs;
        }
    }

    for (int afFSgTn = 351536364; afFSgTn > 0; afFSgTn--) {
        WZbCoOVOA /= SgdxqavIJKmeA;
    }

    if (SgdxqavIJKmeA < 1109871328) {
        for (int sapmEQtPDgxx = 1157944969; sapmEQtPDgxx > 0; sapmEQtPDgxx--) {
            WZbCoOVOA = TgEXagfUouN;
            TgEXagfUouN /= WLidqhRtvcEKI;
        }
    }

    for (int iNVxU = 862702574; iNVxU > 0; iNVxU--) {
        WZbCoOVOA += SgdxqavIJKmeA;
        NfRlGLRvntXqmGvs = TgEXagfUouN;
        WLidqhRtvcEKI *= TgEXagfUouN;
        NfRlGLRvntXqmGvs /= WZbCoOVOA;
        TgEXagfUouN /= NfRlGLRvntXqmGvs;
    }

    if (yqAEaIi == false) {
        for (int UbwCFkwjioCTpPJR = 1072003435; UbwCFkwjioCTpPJR > 0; UbwCFkwjioCTpPJR--) {
            WLidqhRtvcEKI *= TgEXagfUouN;
            NfRlGLRvntXqmGvs = WZbCoOVOA;
            WLidqhRtvcEKI = TgEXagfUouN;
            CbRPqZdV += CbRPqZdV;
        }
    }

    return yqAEaIi;
}

ebDjDbJQnukV::ebDjDbJQnukV()
{
    this->ZntEdOWq();
    this->RpjAsMcyAXKqJP();
    this->pEdWTEKBbow();
    this->bWjyCsH();
    this->qTXDsAhQf(false, string("taIlBgzIvpyGklXqueQJLNieeNlAxHdTfTbxuoRMXhMTLUXxQEtSnHDYhdyCXLFMakBSMZBemwsBBIwPHMoUWOOBIj"));
    this->ZPJlvmzaiGK(-893303820, -377028.3729489697, -1390320489);
    this->iRaiYVHEhW(false, 416519.87927933433, false);
    this->vwzhJapgTKKGFmaI(-1034322.9245558367, -694754950, -950156.8378853733, false, -342902.822269635);
    this->dsradvEIyzrEaAy();
    this->ghutSyfLOaY(2141923007, 1591612280, string("cTIMswWxicwBvgytIHIFMYjmuJDbbSUxKcXNKuTEXsHuEOabmbwKVdLaDLQrDofTNUvKQRJsqQPtUPDduDHaHIvQwWUyifoytOwhUjXKcpvDpvPQhGFmCnvWgibWIPzSOssSqpbeZCuJCWYPYCGMmD"), 190584.59485164078, true);
    this->SYQFcsf(1316876435);
    this->DtFxChQTBI(true, 377741.88958911586, -1194923766, -279254.894640374);
    this->haVCFaNmt(true);
    this->wIvCodJrdRoMzoBT(722895.7089867038, 438156.45490056416, string("jCSILzrHrmjNpluxpEsdVvLwuXUqTtgXowpTrZzxVhzjGDuTDCvziiWQEGMNhkXzCzqVbPrIkNNmNQtoaBHmIwCVenZBXVjWTCknoSRiAvOhdubiCZrTPeKBngHYpsdIBYHcwDYAnFSaPyjsoKMJGlBEpVwMiZHt"), true, string("ixVPxAiCZcbScqWIgTCohUncqedctWGolbulXcNNRJFdSwdxKffJsQijkMuFQHwcOYVAJPOawuRasTLXtuvGnaFeFxZGAHVwFpvjOyiQMErkUUmWzQwPjgNByRciVGklxlxpZMKsU"));
    this->joCzeTnHtQZ(string("mxoBbsYScCyRphtfXwvYmBvcZRsmSQjSXQiBRPNxNODEQmsLZCfcomUtshczaqdWlePItxsWARpmwzBCPNUEqWwzrOQBnylNdrHcsEMsrTXhaeZevZqehzdPeBdGCvFD"), 414493036, string("ejHWfJpVhvWoPjUTfpngzlCArPAwsVGEXGYcbLxdVkVcxDxtwTyhSeDlOFOgtwBQJVNtnzvkArRpPbvktewjWQBLDbuhmZLeiulgVhcftWASMWhwtAlmZophktCGcVmrfQrBhOTLsQFyLDixmTycdgbXFZWmiDnmnXplXjogQdzCpoCTIqjtHRxJvYokBCeKruKWLjAsRIEHeoagKRikSEkjKxkTobwmutlMucreJwHgZjzlkDDviRAsBTX"), 1109871328, -1322947011);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dBOywwlPHSnAKF
{
public:
    bool HNXXMD;
    int aJKbXGQAII;

    dBOywwlPHSnAKF();
    int DIVdU(string GzJHoBI, int sflIjr);
    void TCMyEfkCrOZeGC();
    double GDsUbVN(int sCGvvvKIq, string nzMahxjmgKVHIIPV, int WZxtHY, double hGdmVI, int zuWNqGwmBgM);
    bool qCcAWgnWW(double BYjcwusAPMmV, string OHyYdRNqwXNTVs, double oNgpIWDuI);
    bool GvVkZEuMhzNlU(double xvpPaAZNhtunW, string yroKmgviQm, int iwGPRcxS, string esGess);
    string WfbtIgmzmRWadH(string VIMzAHUGsD);
    double pnmkLXKquPfcIXD(string smBpFChSB, string DpALEJ);
protected:
    int aLQswhjDpv;
    string zJrSIhS;

    void cstatLYqntWm();
    double ohmjeUhb(string EsDJV, bool OPnLYguJHMsBOos, int oxfeX, bool PNYOfWbNeHbC);
    string uYZmsbboihkv(double ScUUnmyO);
    int jnUkJpuKuFCmyT();
    bool ilxNnqBliZj(double LNnunD, int FbJmNrxU, double XuOwzx, double LFoZXEv);
private:
    int WjtJHbtSwU;

};

int dBOywwlPHSnAKF::DIVdU(string GzJHoBI, int sflIjr)
{
    bool WRnUuzRmoowgQdQe = true;
    string JoUMVzIC = string("yiFkwKvIzcIOqlHgmeSZpwGrlDuFXekMktvejbUXvcFsTycznxMXiwUTmPCkFaDeLANFxSwWhhylFzKyKuoctHvbVdDhcryWdMXNDbtDepEbLUUvhGoHTmhxfrUoFJCZjILcmdHHPeOPUdKxufdtmGZzKgMLDhYbvTKCWwaGliONBiLXfNfHDOjUuYKpgmzHxoPeWCCjrOnyWqpGaYadFFcTipFpgxrIuziBgFCJlkzV");
    bool niLqwBKpvH = false;

    if (WRnUuzRmoowgQdQe != true) {
        for (int poKYJSSBYXjGX = 287287645; poKYJSSBYXjGX > 0; poKYJSSBYXjGX--) {
            continue;
        }
    }

    return sflIjr;
}

void dBOywwlPHSnAKF::TCMyEfkCrOZeGC()
{
    double wHuVRCClaiFPGkrt = 506664.70715170086;
    bool frmZFcNPKMixWYu = false;
    bool RCdPNMfHhIk = false;
    double PzXrazUAtvDcewU = -856411.0200727907;
    double GYXVCSgEHZPRe = 10491.36088073687;
    string ALcHmOixBLkx = string("GISrnDUZITrgbrpBqKHiTkOHzVYPKgABNPEReDGCsdWRJeZBZDvZbpNtbraKTYFDaSMnyQzvulymRjWUdZjQbLTePyRFhUlushEVmXdbMyCCIpLDQCTBkLnfNVaLTnFLsWwmblLb");
    int lVFihMTaXCNGQ = 876933363;

    if (frmZFcNPKMixWYu != false) {
        for (int GNlshiBBVYuz = 1531734258; GNlshiBBVYuz > 0; GNlshiBBVYuz--) {
            GYXVCSgEHZPRe *= GYXVCSgEHZPRe;
        }
    }

    if (PzXrazUAtvDcewU <= 506664.70715170086) {
        for (int xTqkXwRU = 246122417; xTqkXwRU > 0; xTqkXwRU--) {
            GYXVCSgEHZPRe *= GYXVCSgEHZPRe;
            wHuVRCClaiFPGkrt += PzXrazUAtvDcewU;
            PzXrazUAtvDcewU = PzXrazUAtvDcewU;
        }
    }

    for (int yNyoHoiPsDjvqY = 808460894; yNyoHoiPsDjvqY > 0; yNyoHoiPsDjvqY--) {
        wHuVRCClaiFPGkrt = GYXVCSgEHZPRe;
    }

    if (frmZFcNPKMixWYu == false) {
        for (int kLMlrQxpkAKm = 938007065; kLMlrQxpkAKm > 0; kLMlrQxpkAKm--) {
            ALcHmOixBLkx += ALcHmOixBLkx;
        }
    }

    for (int kMaBDifjws = 1216684160; kMaBDifjws > 0; kMaBDifjws--) {
        lVFihMTaXCNGQ -= lVFihMTaXCNGQ;
    }
}

double dBOywwlPHSnAKF::GDsUbVN(int sCGvvvKIq, string nzMahxjmgKVHIIPV, int WZxtHY, double hGdmVI, int zuWNqGwmBgM)
{
    bool ilHxOoBpru = true;

    for (int bIQSYNfQQKNiEJ = 387795718; bIQSYNfQQKNiEJ > 0; bIQSYNfQQKNiEJ--) {
        zuWNqGwmBgM /= zuWNqGwmBgM;
        hGdmVI -= hGdmVI;
        zuWNqGwmBgM += sCGvvvKIq;
    }

    return hGdmVI;
}

bool dBOywwlPHSnAKF::qCcAWgnWW(double BYjcwusAPMmV, string OHyYdRNqwXNTVs, double oNgpIWDuI)
{
    bool xrADwZsADpR = false;
    double FHhFbQvUywmOQi = 391498.8591222846;
    int xlsGQSGAwjhnm = -441861795;
    string eRnXXvFTiSDRPAqP = string("wBnyekoPQsJBKHQiknHXoXjRDrwFlRWHbsKcxzVahMGVBgXZYsObMKcUNTeVfDGwqkeMpKwfDazowniBcrZzDqTDsGeGhsRyEh");
    bool ygOsBfXvA = false;
    string CmEZfqXvL = string("cOIdFiBHNsosgXruNyoXqiIbTSsCiOrYTOZwfODlHPHfbQlhQUuGNwJvtwlMQxbmNTKCyiFtBYLFYcDPtetUvCSeQsHjyLWnBmOACzueCIKZoSEOoKOnRuPbDrgiFFtHfTUvcZuqubtXxsssKNErgDaZdRekirXfQijqybddEvTLXJLPrMlcgdKatlZxhgFxsJPqLUQauyxKyMdKKTDEfRWBqSZPDBkEwNmFgbppjbcInSRtV");
    string mBeFKeNbqnDD = string("mmRSFACqXbwxbGzCsISgrZjyiWQQMZUrlqyADvbtKVRdpReCoGQNCsOVlwaUJSVsMiqQJTiqmHonCLGSwssWtiXpfwjiIpUVyKHEJsNRtgTrYCWNqNtyMgEIzzZmeEwIGYQFLVtTebcXafffaSLYgdSnTMJcMWszZBWGvKxkXXTwRCeZlDbwfcvUqMJgPAFMYauAvqgtpS");

    for (int DqLqwvLFl = 1352401242; DqLqwvLFl > 0; DqLqwvLFl--) {
        FHhFbQvUywmOQi += oNgpIWDuI;
    }

    for (int mZnemsg = 187446220; mZnemsg > 0; mZnemsg--) {
        oNgpIWDuI /= FHhFbQvUywmOQi;
    }

    for (int buoeH = 884460693; buoeH > 0; buoeH--) {
        continue;
    }

    for (int WBEsvwPmq = 1170232762; WBEsvwPmq > 0; WBEsvwPmq--) {
        eRnXXvFTiSDRPAqP = OHyYdRNqwXNTVs;
    }

    return ygOsBfXvA;
}

bool dBOywwlPHSnAKF::GvVkZEuMhzNlU(double xvpPaAZNhtunW, string yroKmgviQm, int iwGPRcxS, string esGess)
{
    string EVPflFstRGXS = string("VqpViAlAnqqdwqYqZYvZSWchCmtEKWMZKcrOZtsGGrVogYCMSp");
    bool JwUDfBjCfQ = true;
    double qwJSXnoexxsPjhB = -347561.2188739532;

    if (yroKmgviQm != string("OKkwoPrBlMxchLORWyQCLrhBfjAKpoHmMxcJvpFnUpgrXHqmQsklNpJNUXjdRRfVNypxSnqhxKKzhbLZysaDLuhlwizHqkFInqchMBbrzIkEJmqeZBMXnKfFzXncwCiwyXZkvGvjFMAwUu")) {
        for (int UMmlEZ = 1033419450; UMmlEZ > 0; UMmlEZ--) {
            esGess = EVPflFstRGXS;
            JwUDfBjCfQ = ! JwUDfBjCfQ;
        }
    }

    for (int OIMve = 1087680864; OIMve > 0; OIMve--) {
        continue;
    }

    for (int ZwBAuO = 2080287761; ZwBAuO > 0; ZwBAuO--) {
        EVPflFstRGXS = EVPflFstRGXS;
        qwJSXnoexxsPjhB *= qwJSXnoexxsPjhB;
        EVPflFstRGXS = esGess;
        yroKmgviQm = yroKmgviQm;
        xvpPaAZNhtunW /= xvpPaAZNhtunW;
    }

    return JwUDfBjCfQ;
}

string dBOywwlPHSnAKF::WfbtIgmzmRWadH(string VIMzAHUGsD)
{
    double gbQFclmVnUGaZvN = 925549.0206537681;
    int qzEeobxiQiJEedw = 465476334;
    bool bxbJvyQmRjsacUte = true;
    double PXzcBmwBHirkqkPS = -980608.8145621768;
    double iSNSSoE = 366422.1816809019;
    string XtezfLXDQsD = string("rclYNFVkeRBhtanTqyUQQdCHNLzWotseTBfiWbhsElaFUgiQefgcBdvDpJgsAhbZEuhHFPlutnOBqbcUSbQpGUiInBFsysxKvbzPxiMqaZHiNBgksjooVgfjuHSSegeGrsIkQAunxbLkOgzadiwcogRkDTvdteAQUWc");
    int HQdlJ = 2127047295;
    double RtvfOa = -640617.1057502223;
    bool veqQBDSiRN = false;
    string yolqHcSqz = string("b");

    if (veqQBDSiRN == true) {
        for (int XwepD = 599353104; XwepD > 0; XwepD--) {
            gbQFclmVnUGaZvN *= iSNSSoE;
            PXzcBmwBHirkqkPS += gbQFclmVnUGaZvN;
            PXzcBmwBHirkqkPS -= iSNSSoE;
            iSNSSoE /= gbQFclmVnUGaZvN;
        }
    }

    for (int YkuheXtgeDZr = 239661857; YkuheXtgeDZr > 0; YkuheXtgeDZr--) {
        XtezfLXDQsD = yolqHcSqz;
        HQdlJ -= HQdlJ;
    }

    return yolqHcSqz;
}

double dBOywwlPHSnAKF::pnmkLXKquPfcIXD(string smBpFChSB, string DpALEJ)
{
    bool ScjBOpA = true;
    string nbgkt = string("BHxaeoDvJxLyOjFJsNtyLeRzSnUidp");
    bool fLlHghz = true;
    string QWdSSOIAQaMP = string("ffeXVCQQQrYYALFCWifYEaeo");
    string XuEwzAhhH = string("oADayBdgUWLgVmGKSwgjgApwamJfZXfZZjcHLeNaZNtqRjphLJwGioelOFsIDdggsh");
    double AAEFBsDfhrJnoHYl = -731862.1616586881;

    for (int gbUuKJkuxnzFG = 1195425482; gbUuKJkuxnzFG > 0; gbUuKJkuxnzFG--) {
        nbgkt += DpALEJ;
    }

    for (int qjmwc = 13206846; qjmwc > 0; qjmwc--) {
        nbgkt += DpALEJ;
        DpALEJ += DpALEJ;
        fLlHghz = fLlHghz;
    }

    return AAEFBsDfhrJnoHYl;
}

void dBOywwlPHSnAKF::cstatLYqntWm()
{
    bool VlvgQLov = false;
    double qLYFGtIKkhx = 137289.90015353;
    int aDTpUGvTpUZge = 290467375;
    bool XxyfwsggaJ = true;

    if (VlvgQLov != false) {
        for (int blXpLBYzzkkt = 600910539; blXpLBYzzkkt > 0; blXpLBYzzkkt--) {
            aDTpUGvTpUZge -= aDTpUGvTpUZge;
            VlvgQLov = ! VlvgQLov;
            qLYFGtIKkhx = qLYFGtIKkhx;
            VlvgQLov = VlvgQLov;
            XxyfwsggaJ = ! VlvgQLov;
            aDTpUGvTpUZge *= aDTpUGvTpUZge;
        }
    }
}

double dBOywwlPHSnAKF::ohmjeUhb(string EsDJV, bool OPnLYguJHMsBOos, int oxfeX, bool PNYOfWbNeHbC)
{
    string RetyCuybPcSNi = string("DtyvcKErzvYUtqkFmkeYMpGyPfCPnBDaxRTyHoOiWjBZuSZLXVDefGoFAKFgCXfarbSYJojKnzZuHZmpRUuuGczeSu");
    double eyUGIu = 61093.227269765135;
    int lPGcnOWEeaVEWW = 1262189692;
    int kceQNutUAEj = 1441615430;
    double IYXHXjruEgsldZN = 992723.5115053161;
    string vQNVfA = string("ymlMBqJXclzhibSxeXFBOLmiZezTELhPQGjReXvDZJRGekWFNPfWChCFiAx");
    double MGCTt = 691768.0670753757;
    bool uNPhIgERsjorivss = true;
    int kNkRKiccETlmDg = -365405820;

    return MGCTt;
}

string dBOywwlPHSnAKF::uYZmsbboihkv(double ScUUnmyO)
{
    double nutAmHpd = 455633.1584080597;
    int ekBfvt = -1769802973;
    int KZBlKCxiaFu = 937243513;
    int NpBUpiwRoILMN = 1485000609;
    double uMeTQk = 589561.8365869379;

    if (uMeTQk > 589561.8365869379) {
        for (int AHNQHjZcOPjdx = 1012158428; AHNQHjZcOPjdx > 0; AHNQHjZcOPjdx--) {
            continue;
        }
    }

    if (KZBlKCxiaFu <= 937243513) {
        for (int VmvqnUniRoPyC = 200588305; VmvqnUniRoPyC > 0; VmvqnUniRoPyC--) {
            nutAmHpd += uMeTQk;
            ekBfvt -= KZBlKCxiaFu;
            KZBlKCxiaFu += KZBlKCxiaFu;
            ekBfvt /= ekBfvt;
        }
    }

    for (int aVxhzAg = 1468517289; aVxhzAg > 0; aVxhzAg--) {
        ScUUnmyO /= ScUUnmyO;
        uMeTQk = ScUUnmyO;
        ScUUnmyO /= ScUUnmyO;
        uMeTQk -= ScUUnmyO;
        ScUUnmyO += uMeTQk;
    }

    for (int zeKaKtTbknX = 796172077; zeKaKtTbknX > 0; zeKaKtTbknX--) {
        KZBlKCxiaFu = ekBfvt;
        ScUUnmyO /= ScUUnmyO;
        uMeTQk += ScUUnmyO;
        KZBlKCxiaFu /= NpBUpiwRoILMN;
        NpBUpiwRoILMN *= ekBfvt;
        nutAmHpd /= ScUUnmyO;
        uMeTQk = uMeTQk;
    }

    return string("zCXtqkNIrWaFFJqzzdfRbOprAbBpImgHwCAWzCwbwt");
}

int dBOywwlPHSnAKF::jnUkJpuKuFCmyT()
{
    double csWcASASFY = 506442.83180247643;
    string rZUYSZuXh = string("rsGWlBDTrsfBpvfzpEVZBrSWgyhGBwsoYdQQHKUoBFmYKNYnyNJskffzqsMfMhNcahJnLggiXNSHOXvRRMiRhKwqvbLZVmKmUKVEaeAwFafZWVbSTuVHmHbUVbzNwsklZUBqkCd");
    int YyPVkIVOkCBXDicb = -1043089721;
    string sCTAINs = string("MNHAWClkqeYpqCdbRDNxajUqVZxyQhWrTobtcAZufIWxjNifahSJINOuZkDYFwjWYgygRrdOifSjInWUZYciDfUQFMdQBwTNSfNOkwGjdABDQwgSjyfPpoBaRHkabuYrOPyvwXBryBDTUqfgxqidiSdMdUyTvGuAWGCfEBuCsUGEnAWrLOTSauHwegERDuDKOHgFVzqeFFmVJDSnjKoZZSGvtMtFkiVBbqtuOUtJgbiFACMgRraYkHSNMml");
    bool ouoKQYZxVit = true;
    string VGyQKKJL = string("SAdtaIUvGsyYCnrOXcRgLADLDfRdrdXvyTjNyRLJVWsgfFLBkMQulSdMvhKYAawfFiITjXFfYGzaktFzSiYQZrDTJQIsplgjYfxdJpWkppXxnvyvempXbvwAZNBGcWitAUaBNENqcmeRwIMDhQWbNNvgExqVyQCwfAnhbSWOLxTSWfFixpeCzFWHow");

    return YyPVkIVOkCBXDicb;
}

bool dBOywwlPHSnAKF::ilxNnqBliZj(double LNnunD, int FbJmNrxU, double XuOwzx, double LFoZXEv)
{
    int ZpcPYPBIuqLkupN = 618338477;
    int CYiSZSq = 1393865585;

    for (int XZwWQjtXxfDuM = 593064580; XZwWQjtXxfDuM > 0; XZwWQjtXxfDuM--) {
        LFoZXEv += LNnunD;
        LNnunD += LFoZXEv;
        ZpcPYPBIuqLkupN = CYiSZSq;
        CYiSZSq *= FbJmNrxU;
        ZpcPYPBIuqLkupN *= ZpcPYPBIuqLkupN;
    }

    for (int hdOfoYEyPTR = 1619094636; hdOfoYEyPTR > 0; hdOfoYEyPTR--) {
        FbJmNrxU = ZpcPYPBIuqLkupN;
    }

    if (FbJmNrxU < 1393865585) {
        for (int DlOVHS = 1634834314; DlOVHS > 0; DlOVHS--) {
            XuOwzx += XuOwzx;
            ZpcPYPBIuqLkupN -= FbJmNrxU;
            ZpcPYPBIuqLkupN -= FbJmNrxU;
        }
    }

    if (ZpcPYPBIuqLkupN != -112771084) {
        for (int lekehIZx = 192502874; lekehIZx > 0; lekehIZx--) {
            CYiSZSq = FbJmNrxU;
            LFoZXEv += XuOwzx;
            ZpcPYPBIuqLkupN *= ZpcPYPBIuqLkupN;
            LNnunD += XuOwzx;
        }
    }

    return true;
}

dBOywwlPHSnAKF::dBOywwlPHSnAKF()
{
    this->DIVdU(string("bkBhoiBXJCjPvZOEgLjWclJxqwOfAoNHKumzZLvILbzeYggGbkdgexkXLirZrUVHmtBgZiHzYRahjaGHFPdHhQCocTeqOrHbwAMAREqpQjZiqtFEcIrHFrQGdeNOQzFplmRQxHCOenmPbcHCAThZPbPvjtFncopOyJYYCWExhLrTPHiESFaCAdepepvBgdUMiAliCwXhangtbLnGqaioNNjRxycOowqtjZRypKWpSLiaeRzCOzAPDluEbUeG"), 522111584);
    this->TCMyEfkCrOZeGC();
    this->GDsUbVN(1484471538, string("KodDqQKUdCAzmxcyhYpygkWsjseThItPorhdvlaMtSUYnndsBvSxjxCprEUlfGRjfZgYcLhUETfzrSAurpPSaviZMwEFnexozjKrGWjwrREjxuvfHtejVqiVwztohPcvhrAiibLFszbrzGdtyixiwUYxlnnCicjAnGxihADRwwdmYVbaNifaplu"), 634539448, -881284.1038059912, -1097578071);
    this->qCcAWgnWW(-926293.778803908, string("LhuVVspQfZHJVbSORulVocOrwFgathxcKPpDfPBGPWAxiXhKQwxbwVVfHPObTYWaPkYDHuvteBGCrsRSeiuOQqECffKMSlAoCjtUmLbQtkLRijxlSGewEShSVwygGeQgmynCzgguHVhnXvFzRBnWwVXPaiYRjyhGurZyiKepFRyFxKSUmSVHQ"), 32510.99969710533);
    this->GvVkZEuMhzNlU(24890.995937128286, string("OKkwoPrBlMxchLORWyQCLrhBfjAKpoHmMxcJvpFnUpgrXHqmQsklNpJNUXjdRRfVNypxSnqhxKKzhbLZysaDLuhlwizHqkFInqchMBbrzIkEJmqeZBMXnKfFzXncwCiwyXZkvGvjFMAwUu"), -1911185933, string("rMiXiVykGXtBimyBARzNxyuilTolhdchECOpJrYAMfVToYatvJZoTpQMDNyZITavyUrgoKIisaXapmZMjgpjFgYOhNVkgpwamYVTyQFpQcLrVmrZbzpUQNgJWLzqMEhvwexoAnJsTBJIpwkVNvMdReibEMYeYTIukfPdIDYgSidiUgVmKlLYiIRcHxLFPNnFJstIhHpEUAzFXNcEABHxKKLLeFlnbOJ"));
    this->WfbtIgmzmRWadH(string("HzHlXVsrEiQJylNwIPgIKVCKTMWKhpruhkQPgtGWccbhNifPlemzMBpBbCDuDGWHlDhwLNOpeUTRmgkDyZQrCpLkeUINnYXYVSpyIjcz"));
    this->pnmkLXKquPfcIXD(string("YkoHCzIGJEmYZOeIRoZatEIETSGOKSBEVdgQcGtknhuSOCJLqgDyOdJXsLiVxQeDzTIQozySnPSmvUZZviuUcEaCRwQOmitVvjcvzcjLqObKhypmqXVmROKEgaJCGHrBhWNHCEKaQ"), string("AuicaWYeusoPvrjyUzRSVAXmXLiXhwXiCaTRTATItemCRvtFYRpcBTdCYiwfVkyNAytVrgxBLKJOYZeOreaBalaMMIAiQBRrD"));
    this->cstatLYqntWm();
    this->ohmjeUhb(string("ztRTwUPZhDZsIwmoNWEMTAKeFFOriQUomkqqCpmQSGhTzTUdDAYmrvFMCvNQxylNuTRydMHxwqFYnuJIptikpoQrQTGwEaBeUfe"), false, -320060848, false);
    this->uYZmsbboihkv(-603771.2138592246);
    this->jnUkJpuKuFCmyT();
    this->ilxNnqBliZj(-279207.1330719534, -112771084, -892584.9422370221, 500690.0860854737);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xaAkjy
{
public:
    double EoKuhDj;
    bool IAUjaKUvMLGhdFP;
    double PxdQEvnWlVktCw;
    double nJsHpNzkI;
    int UMTLGLGRlTWpqv;

    xaAkjy();
    string PDqdP(double oMmKPpZDyVhTba, string yOfZzMItsXxuEDvp);
    string zjASMhUukshrNvE();
    double EyGqEyjNyiwLFm(string kitSzFPEDYtvn);
    double ZiDUeGq();
    bool IzMXPPiDcnfgdcM(int UTsnHoR, bool aQIWwWc);
    int oqCoedPyg(bool eCpypbmIKw, bool SyQOGtc, bool rNLsxgdbUZduRjjp);
    bool obAez(double JDnICgoMASLCLpm, int ogDxHnxuVGx);
protected:
    bool xplXKo;
    string rzYNeoqyVUUY;

    bool ybEFli(bool qGLUzEFerGRW, string brORcXvbtzxsewDk, int DdsqxScrIf, int MpQFlVxqz);
private:
    int mMBblECAp;
    double fkpDRLPyPudl;
    int qRhpLDTZP;
    bool OqDuAmAXLZdEGz;
    int GlSgUZdtNs;

    void bbnOncfCYYMvO(int zGENHoHFcHuGtIX, bool crAaKuMIRIsSAt, double iZVvMQ, double WdgbGiwnKk);
    bool vweEiSmeW();
    void vbTLojIZ(int AfDCdKXkfd, bool IqEQMXCfzGRuOeHs, bool ZUNUJA);
    void EraNP();
    string djXtDgHmKDAgjbx(bool ZZrmpnztEPJV, int yDgmlH, bool thNIwoMi, string GWFwVFks, double OxUWU);
};

string xaAkjy::PDqdP(double oMmKPpZDyVhTba, string yOfZzMItsXxuEDvp)
{
    bool waAYtmwWjJ = false;
    string dunXmsuAav = string("XasMZYCvRdbudHJEtKiobFOxJqIWWcLrAvcYDScBfGtJlhRrfIyoHuYZMnEXIAglyPYXUTYkxObCMApnDIBCPHqCWhQptUSAtrbmmzzEjtFAnYhsjfkEsxQdupFZoVhNyDTOIQDGInZNZidKFFcXxDvAlxBDSyCwrSqOhOPxnUajUqFryXcXHmOkzviuCtmY");
    bool CFzbLczvm = false;
    string tmLGFlv = string("UTUsjUucUbNAPKJntFiWjcJeCNwJwsijzJtgqJgBelKNKxPBtRDnwCywuOpMNShlrispHUwejFtcTaiRYyIeDKPfSddJfqXwTFnJwUNeBncYsygzOGALEIqVjKhMFuLepUHnzQNGlhEitXhqtkFGCajxIeQrJQSTiaZSOvWEyIzaBFtVHUsSTGSxlBhTjSUugEMmTcSyUm");
    bool wOOkexSqnuuvRE = true;
    bool oHUnVqrXFCUhukAH = true;
    bool znOvl = true;
    double ErOXQYtTWagu = 924366.8196888879;

    for (int gygJKpWVoFBXnV = 30209219; gygJKpWVoFBXnV > 0; gygJKpWVoFBXnV--) {
        continue;
    }

    for (int qYIvdYMbTCWKqGv = 306291333; qYIvdYMbTCWKqGv > 0; qYIvdYMbTCWKqGv--) {
        znOvl = ! oHUnVqrXFCUhukAH;
        ErOXQYtTWagu -= ErOXQYtTWagu;
    }

    return tmLGFlv;
}

string xaAkjy::zjASMhUukshrNvE()
{
    double XXvLIXdsV = 657562.5262101876;
    string RwjGiNmnVWWVMaah = string("jFwOWoIofdIdkzvLqTuWAkDrcdTfVdCATJxhJzvNnumtGbSoNzdECMbOTkJLEXtgaAoiXHnFSLcYstrARwMzFSihghUWySPpQkkCqQVzTdoPugnjuWkusjJPuFLYqwegmQl");
    bool ZpsxDZ = false;
    bool ObtREzsVYjrvRN = true;
    string obKnWBlfp = string("lDnXpaboveNdOsVxUGPfKcAuQbMFpZtsBYKdBnfJJRnwdrmaAyvrkTSoKqMXSfxmPgUJiHhTauAWEaJiKFfEtjOwZjKYFfcrubeakgxuDXEJfnHeIOpvgPWFRRwFOqRBKIYXOKaWUWLLUUvoqQBskZAtijrKjjmKvZPCUMKqrNZpwrdDGuvlypVoIAPSFlTBvddeMpCuuWYfCPH");
    int htcIrOW = 1457437556;

    for (int ZclrNLITmvPTnJGu = 435244346; ZclrNLITmvPTnJGu > 0; ZclrNLITmvPTnJGu--) {
        XXvLIXdsV *= XXvLIXdsV;
    }

    return obKnWBlfp;
}

double xaAkjy::EyGqEyjNyiwLFm(string kitSzFPEDYtvn)
{
    double dmoiXnhv = -94254.02802829705;
    int ApHAxSXbt = -1841507239;
    double mClQHvJLo = 810738.9692802032;
    string fuBxLugDkIPHBVs = string("IzzdRzDynQnDWLFVDcXOwfGxJMZdmAVyxFmMEwejVTDWbDKXWzNOzVIzVQUHsXygcOgYnfEGaPWfoGJISKPaoJGZbxBLRABMVsPilQyDaGnlkSFtobiYoWfMvwMoLtrLnmwxvioWQaNOuKpGFrshLagIJiFefYSrkLVPNQgBAaxSZbrvoEWtCbBvYmsYgOfiknirBrTSNECzKeTVRxAWqzGDNDknfAGojls");
    bool zRWYMjnuZamvJwpT = false;
    int NwEgEfCQTjXkSBaY = 523571675;
    double IMJGheqzVkGz = 922993.6303281855;
    double YcXgJsBvkN = -374307.4733910623;
    string oZERnNjTPoV = string("DOLsUlDKUqJxYEphEiqEhyCnonGBnwAIVzMQeKBUFzpcSvYHhSbkBPcYtFKGNwctoyrjJnimIHfaefmtRxgoLXGhpmLyXVSlydlZMxzBllLLVUARjKmmiISnjtmffGbSoSpGYUmcvfJHUPDjyQfANdQeOEvoVwdZUJrghIBSYYjCjAunUmdOECMfxOckdBgjEIRDtvlnqtFzNMTjv");

    for (int yyhikrwZPhN = 552940653; yyhikrwZPhN > 0; yyhikrwZPhN--) {
        continue;
    }

    for (int janOnMzgU = 1363718324; janOnMzgU > 0; janOnMzgU--) {
        oZERnNjTPoV = fuBxLugDkIPHBVs;
    }

    for (int fKCmttjo = 212296598; fKCmttjo > 0; fKCmttjo--) {
        continue;
    }

    if (dmoiXnhv < -374307.4733910623) {
        for (int icMXMlHscElxpy = 260291381; icMXMlHscElxpy > 0; icMXMlHscElxpy--) {
            continue;
        }
    }

    return YcXgJsBvkN;
}

double xaAkjy::ZiDUeGq()
{
    string ytbXXpGdpux = string("WfPwyqqLqWybDPPmBiVMWhvAPHuwWdjVCHEcaVegGmfMTzkUUQjVdQRGwpcVQMlCzmNciaNVfGXWceSFyWuoKypkFaWiFrRgglsDKLXQDxWfcRFYtaEWVgTfVxBnmiHRHUITQnASgFYKgIERaoCfWTURMSubgtmxqlcohsUJtFkvqbQQVouyGnjKXmvWj");
    bool lqnsTehQW = true;
    bool RpBfJ = true;
    bool MtrhDugjvfnPlryq = false;
    bool wSBsgbDMPHqVluQ = false;
    double IjmsXZYrjFqVxuGx = -245580.2995064716;
    bool CSntQZg = true;
    bool tyVIOUOrMbPV = false;
    double sQqBomNEkf = 281289.51689087995;

    for (int HzgOzmkkmTewy = 566711973; HzgOzmkkmTewy > 0; HzgOzmkkmTewy--) {
        MtrhDugjvfnPlryq = tyVIOUOrMbPV;
        RpBfJ = lqnsTehQW;
        IjmsXZYrjFqVxuGx += sQqBomNEkf;
        MtrhDugjvfnPlryq = RpBfJ;
    }

    return sQqBomNEkf;
}

bool xaAkjy::IzMXPPiDcnfgdcM(int UTsnHoR, bool aQIWwWc)
{
    int sbKKqwzovQyFZU = 2003450155;

    if (UTsnHoR == 2003450155) {
        for (int WNAzS = 301871980; WNAzS > 0; WNAzS--) {
            UTsnHoR *= UTsnHoR;
            aQIWwWc = ! aQIWwWc;
            sbKKqwzovQyFZU += UTsnHoR;
        }
    }

    for (int iUUfvQwdNaoYI = 169524423; iUUfvQwdNaoYI > 0; iUUfvQwdNaoYI--) {
        sbKKqwzovQyFZU -= UTsnHoR;
        UTsnHoR *= sbKKqwzovQyFZU;
        sbKKqwzovQyFZU += UTsnHoR;
        aQIWwWc = aQIWwWc;
    }

    for (int yURGcTsuL = 421240881; yURGcTsuL > 0; yURGcTsuL--) {
        aQIWwWc = ! aQIWwWc;
        aQIWwWc = ! aQIWwWc;
        sbKKqwzovQyFZU += UTsnHoR;
        UTsnHoR /= UTsnHoR;
        UTsnHoR += sbKKqwzovQyFZU;
        UTsnHoR -= sbKKqwzovQyFZU;
        UTsnHoR = sbKKqwzovQyFZU;
    }

    return aQIWwWc;
}

int xaAkjy::oqCoedPyg(bool eCpypbmIKw, bool SyQOGtc, bool rNLsxgdbUZduRjjp)
{
    bool AWUTMvBTLR = false;
    bool VxyOtxeLEnKiBvFP = true;
    bool uqxBgCS = false;
    string oEtgMYklG = string("UZhzRGAPNCgZWSyxfNCkMTxpoctHGFaGgCNGPLVgLLunFRJUSnBNMHIShyUkXFXmJbxETpSvxRokUGwIPpRAToSekmbJHbEzFu");
    int vHyvJdantrgIio = 1955017081;
    double esUEWuRmfsRBDobW = 525227.7530563312;

    for (int zjqBZLfGPF = 1476442455; zjqBZLfGPF > 0; zjqBZLfGPF--) {
        uqxBgCS = AWUTMvBTLR;
        rNLsxgdbUZduRjjp = ! SyQOGtc;
        SyQOGtc = AWUTMvBTLR;
    }

    return vHyvJdantrgIio;
}

bool xaAkjy::obAez(double JDnICgoMASLCLpm, int ogDxHnxuVGx)
{
    double ahINK = -891894.4515565333;
    double LgdLFaGVQmhZK = -196977.5327866211;
    string cKTEiyPYvbRZqh = string("ijRsvIxUHrZZCbKhquVULMCsEpHbrquotRolUFHbNzRrYEaYUvLTIthKvkDBgXesFeDEiflAnWAcrMuSZlVVAJjEdOWkqxPHInvapGOuuNWzITABcaihYxaizZGCKVAnbXFbblXicMsysuTupFTGmYsPrauvKsXbNCNknzA");
    string SZDQU = string("ISjKBFQLuxUPoAiQxDmzkoOzfabsPtnAQoMHNxzJWbRuAiNJIQcxqwcYlnxWZrfEiIwNAuYJYPZpKetYQqExourykKRexkeJusHATekGfNdXTgAIGYlqgcQGjcZnMvfQ");
    double FuQHdn = -225447.6038612949;
    int bOMTXbvUjgCX = -1710223108;
    int nNQZXXrtnMrNJ = -1186713963;
    string spBzgiTyNZROKtTG = string("HxmyICojtCPUduoXdVdYOzdYmUROKmUukNeyDgqRYJHpxXeuUgEfvqINnenlmsrwVmPrcicjGboKApixblKIVPEkjSBziydhULAkaauVxaaFtccxSoSjvyCmdMTcstcBNGidCqZopX");

    for (int xtvVYXoZzvJevL = 1622575657; xtvVYXoZzvJevL > 0; xtvVYXoZzvJevL--) {
        FuQHdn -= ahINK;
    }

    for (int QOpNxcrwlXimGS = 130144382; QOpNxcrwlXimGS > 0; QOpNxcrwlXimGS--) {
        bOMTXbvUjgCX += bOMTXbvUjgCX;
        ahINK = JDnICgoMASLCLpm;
    }

    for (int AezbgQbpNESBKsL = 796778637; AezbgQbpNESBKsL > 0; AezbgQbpNESBKsL--) {
        LgdLFaGVQmhZK = ahINK;
    }

    for (int BjAAhSLcTyouZngK = 649819409; BjAAhSLcTyouZngK > 0; BjAAhSLcTyouZngK--) {
        SZDQU = SZDQU;
    }

    if (ahINK <= 544774.3395089959) {
        for (int pUuVgY = 376127940; pUuVgY > 0; pUuVgY--) {
            ahINK = ahINK;
        }
    }

    if (JDnICgoMASLCLpm < -196977.5327866211) {
        for (int NiNtNJLTtp = 2022300707; NiNtNJLTtp > 0; NiNtNJLTtp--) {
            nNQZXXrtnMrNJ = bOMTXbvUjgCX;
        }
    }

    if (ogDxHnxuVGx >= -1710223108) {
        for (int yzkWCZVbYJnG = 690380564; yzkWCZVbYJnG > 0; yzkWCZVbYJnG--) {
            ahINK *= JDnICgoMASLCLpm;
            LgdLFaGVQmhZK /= FuQHdn;
        }
    }

    if (cKTEiyPYvbRZqh <= string("ijRsvIxUHrZZCbKhquVULMCsEpHbrquotRolUFHbNzRrYEaYUvLTIthKvkDBgXesFeDEiflAnWAcrMuSZlVVAJjEdOWkqxPHInvapGOuuNWzITABcaihYxaizZGCKVAnbXFbblXicMsysuTupFTGmYsPrauvKsXbNCNknzA")) {
        for (int tVYYY = 1813980897; tVYYY > 0; tVYYY--) {
            FuQHdn += FuQHdn;
        }
    }

    return true;
}

bool xaAkjy::ybEFli(bool qGLUzEFerGRW, string brORcXvbtzxsewDk, int DdsqxScrIf, int MpQFlVxqz)
{
    double KtrIFsjDfcukmip = 1047933.0662159558;
    int cGbPurmrukGyk = 509233165;
    bool txaoCnOr = false;
    string pNLnFRfxOrsZ = string("mxmIoopUqphBJzeLRQmuKkQFstbnGLOHbTcudtyxZXZyRKDHlxINYOLDUpdiXlJuqtBXTOKhmFJmjiBbpbDQAqWmWIeWUYNTTKjHWqwxlwFktIMGGysrUqicgCWSiScUWAeZKMnNlfLSTReSocIQhXMMmUqMvkMxMsdlPzgAuVEnNFAfYrbWMBmbBForrFlMBaalcapRGTUCpt");
    double DstpraPA = 432871.9271747991;
    double IZbyXHt = -394117.73133488966;
    double KlpBZ = -405752.29310548765;

    for (int djEhEpjPmyhU = 1826687942; djEhEpjPmyhU > 0; djEhEpjPmyhU--) {
        continue;
    }

    return txaoCnOr;
}

void xaAkjy::bbnOncfCYYMvO(int zGENHoHFcHuGtIX, bool crAaKuMIRIsSAt, double iZVvMQ, double WdgbGiwnKk)
{
    string DKQVf = string("VcslpSPpeQinqGmiwKFZNTbALCHTuhwlHDAjMGUMWkbywOIYxurhqqgLHiRvdpzoBukODuYwUqYepMfEhKdmKyIOxQVZjNpvDqkEPzHvxlavsmnzyokvsNrhiopKvDMsK");
    double lhaZQTjHjmunMAah = 735762.7642990176;
    bool iybgJ = true;
    int CHMFrtfiCOS = -1201884045;

    for (int wTjnSgoqdioaJSHf = 886844898; wTjnSgoqdioaJSHf > 0; wTjnSgoqdioaJSHf--) {
        CHMFrtfiCOS *= CHMFrtfiCOS;
    }
}

bool xaAkjy::vweEiSmeW()
{
    bool ExhgdCQYfyvGi = false;
    double NSAQXCtniF = -699335.6856376302;
    bool aJTzmBqiFMR = false;
    int uLrnuWUVQJ = -324280332;
    int IZWSjAJz = -969544684;

    for (int fIpLwFjYvzFEG = 1707320675; fIpLwFjYvzFEG > 0; fIpLwFjYvzFEG--) {
        continue;
    }

    for (int YKzAnJtz = 1725262306; YKzAnJtz > 0; YKzAnJtz--) {
        aJTzmBqiFMR = aJTzmBqiFMR;
        ExhgdCQYfyvGi = ! aJTzmBqiFMR;
        NSAQXCtniF = NSAQXCtniF;
    }

    return aJTzmBqiFMR;
}

void xaAkjy::vbTLojIZ(int AfDCdKXkfd, bool IqEQMXCfzGRuOeHs, bool ZUNUJA)
{
    double NfRuyQcRkdO = -610120.4417384937;
    int rOpxq = -836532819;
    string kiyXiARIox = string("yuRdWvMJbjfcZOblgppZpMaSXBSWOTAWlDgNuILrzzqXNiIARuGUCItqQcrxkVDTGLhVYEnhJPmpVGFeFLrvWeenrRuWJEZqtBnfBWmJyVFAzckvwMlsXnVxcEtnUjZuEocGCWQChr");
    int FLCsPNHXMtZmd = 1665412566;
}

void xaAkjy::EraNP()
{
    bool TKKVWKbqHA = true;
    double zSovRgQPw = -80352.47844193829;
    bool eBJdTVFRcTexmXmW = true;

    for (int YLuUqzD = 990719259; YLuUqzD > 0; YLuUqzD--) {
        zSovRgQPw -= zSovRgQPw;
        eBJdTVFRcTexmXmW = TKKVWKbqHA;
        TKKVWKbqHA = ! eBJdTVFRcTexmXmW;
    }

    if (TKKVWKbqHA != true) {
        for (int LnmQGtDjjXin = 1215829430; LnmQGtDjjXin > 0; LnmQGtDjjXin--) {
            eBJdTVFRcTexmXmW = eBJdTVFRcTexmXmW;
            zSovRgQPw /= zSovRgQPw;
        }
    }

    if (zSovRgQPw == -80352.47844193829) {
        for (int OKeIYaBvlkDBfEU = 2066069931; OKeIYaBvlkDBfEU > 0; OKeIYaBvlkDBfEU--) {
            eBJdTVFRcTexmXmW = eBJdTVFRcTexmXmW;
            zSovRgQPw -= zSovRgQPw;
        }
    }
}

string xaAkjy::djXtDgHmKDAgjbx(bool ZZrmpnztEPJV, int yDgmlH, bool thNIwoMi, string GWFwVFks, double OxUWU)
{
    bool ilXxGqPNgWSQlQn = false;
    int RWrnlCvBCpS = 1504393713;
    bool XPlDjnlIwqq = false;
    bool sMJflK = false;
    double qletTw = -861625.189525148;
    string ONBAqvfaFybnF = string("CvkbCnMngqBGTDYYBeNcwSMDoZxhPJqYsfBlbKeeyNRhJRYkpQOGesHzBaEhFCsSHlIaGsiMWDrAMrtFTxCKZwgjNPgHqTrbPdFaAlXrTfHGMEBKJhOxlVVKpzBCFdENLtXUEmsRHLeECqOnpAprYRhukvqgcMIJtaMSBFGDTkkObaLTsHwZUrqSZlOYgYjLyPcIsFxnJqWbmYHjbFtVJoLCcqFOcluRfLZcQImknGWhI");

    for (int MnHAfnNDDGOiGDhJ = 418805245; MnHAfnNDDGOiGDhJ > 0; MnHAfnNDDGOiGDhJ--) {
        yDgmlH /= RWrnlCvBCpS;
    }

    for (int hwGUBSdcNMhiH = 1115225090; hwGUBSdcNMhiH > 0; hwGUBSdcNMhiH--) {
        OxUWU = qletTw;
        sMJflK = ilXxGqPNgWSQlQn;
        OxUWU /= OxUWU;
    }

    for (int nhaGabLMLRH = 1559677702; nhaGabLMLRH > 0; nhaGabLMLRH--) {
        yDgmlH += RWrnlCvBCpS;
        ONBAqvfaFybnF += ONBAqvfaFybnF;
        sMJflK = ZZrmpnztEPJV;
        ZZrmpnztEPJV = sMJflK;
        qletTw += qletTw;
    }

    if (XPlDjnlIwqq != false) {
        for (int XXFsgaReRgxjjYyC = 1736034376; XXFsgaReRgxjjYyC > 0; XXFsgaReRgxjjYyC--) {
            continue;
        }
    }

    return ONBAqvfaFybnF;
}

xaAkjy::xaAkjy()
{
    this->PDqdP(-222728.23492381503, string("RolxFOzczTSpTmwSfWtiBUpRQujuHRBugkpULmoaEMGgWeRNFchjKKFXxDJtieZWXcAVUcpFezUNyNGQLAGOoblMyckYTOWskmdIneRnwnqJzcYpQnESynfLxhZWO"));
    this->zjASMhUukshrNvE();
    this->EyGqEyjNyiwLFm(string("ZzlhYdKVskeYPCmnTLSIeYncJxvfhcNWwMNTpqZHtRauonTktTIbRzWaMLmnoYUfEYYmDyEYCGVIiVmgLtEyxYHZBmOvTgfxztKAxtbeSghMhcFSgTtMkAXUrLjrPQBvJPNVRSCbUDcvyiWYGetuDCXBJZNyREUFLuyQrOaRYhxPoZnoABhHveiDtDTTJhWyUhPnncorgdELVBraZe"));
    this->ZiDUeGq();
    this->IzMXPPiDcnfgdcM(880411233, true);
    this->oqCoedPyg(false, true, true);
    this->obAez(544774.3395089959, 1443395427);
    this->ybEFli(true, string("LseQhouYIWZLtFkIocnZuGOZGugvaEhVuCdooFpuCVHLMOIzhFygOKjPvetPSVInAzQMwlCvZWZtvJiyBcWDXALuJoqaGGYrpAGASnGxtKwZDUQREMTiUlozFnJoEpLJLjbnMlWSPORAzV"), -1439254438, 1771855322);
    this->bbnOncfCYYMvO(-1356832880, true, -272520.00065010844, 849570.3654527733);
    this->vweEiSmeW();
    this->vbTLojIZ(1423819590, false, true);
    this->EraNP();
    this->djXtDgHmKDAgjbx(true, -1757655679, false, string("oLpOkJdWQzYluosIEsCHeKELSqAbEllcFfLNDubyhUmEHqxOExYjAeLCUBRLkFKugDCFMQzPeyIcuaienXnERCZWJtujjbY"), 364657.4334628695);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DYdGJbNn
{
public:
    double FjJuEruOoYzAwZ;
    bool HlxVMyKywL;
    int vgohinhnnDbzKWGu;
    string pDreJU;
    bool cAnsuCnedbjN;
    bool EQJgN;

    DYdGJbNn();
    double JsMmux(bool VPfsLcxrkE, string IKSUVWX, int xydcxDXa, double WCxRXdgmcXle);
protected:
    int oFoxJooqtD;
    bool hMDamBhipVJzlh;
    string pHmgPY;
    bool yNEYEWR;
    double nTIAlhF;
    bool XyUMnVUcH;

private:
    string yRBhrJoincqcJBU;
    string CXemtnWQfn;
    int fHjjSdSPx;
    double HTbFYxoYlzoo;

    double hjxHpzJ(int xkvOezErQqSmfp, double PkPeC, string LJxxLTOVb, double VqRAdNtieex);
    int skrQhZ(string HHWoeIT);
    int FPAnPXMM(bool zMpiVGCHVq, string mmCEkFeQjOXAq, double pEHbrduRx);
    void ziFLgExFWgTJX(int PlwNujLxMfoDSam, string gXBpfZmLgdmixJHc, int SanuhUWQxWouAKzk);
};

double DYdGJbNn::JsMmux(bool VPfsLcxrkE, string IKSUVWX, int xydcxDXa, double WCxRXdgmcXle)
{
    double brgTqdmv = -810811.9776509696;
    int PbOST = -345250939;
    string WBENSTvxbzWfRkQ = string("IxZiEmnrdqnwpyFrvGavMacOxAyouJqWwEWilfKtfddcqdvCeOPbkKgebuXlNXEuxQVfySpObbzLuBOXgYnUZweIekRlWtxCwxnvjvKcUqYmuyQKpRsBworlLBsNSwKhdKAgWFVrnjBvCdlwadBggFQUIUVdJzAJwqIvPoKDuvHZPydZpOqVpXutcAaOHyXHyXvNZZZofErQauTpayNaNZzqnuMkKPxmpdzOgvcACscuOiphh");
    bool VCuoXpyP = true;

    for (int RihbRpcUj = 781819905; RihbRpcUj > 0; RihbRpcUj--) {
        WBENSTvxbzWfRkQ += IKSUVWX;
    }

    if (xydcxDXa >= -345250939) {
        for (int WqyLJOwOGTrf = 651359932; WqyLJOwOGTrf > 0; WqyLJOwOGTrf--) {
            brgTqdmv += brgTqdmv;
            WCxRXdgmcXle /= brgTqdmv;
        }
    }

    return brgTqdmv;
}

double DYdGJbNn::hjxHpzJ(int xkvOezErQqSmfp, double PkPeC, string LJxxLTOVb, double VqRAdNtieex)
{
    double vvtDssk = 898987.737622075;
    string ETgGgctnM = string("nGkgkhUBvayaBqOebjQCFPusbMDXWpXsgPccDeyMHzCwfRrJgEexlavNBtyugMRWWJJiCmUxdqWKIvemrWjFugbXyqIMFCcNkcVWeDyVlgrPanzQDvwjRPeSPlEmCNkLygQoXycnMxLOyLKYmcNZfqCvlBGGm");
    double kYRidMBHYFYe = 827574.2841919449;
    bool gwJtrl = true;

    if (VqRAdNtieex > 980663.8875789092) {
        for (int AgGYuGCcpTgxkbp = 1174083895; AgGYuGCcpTgxkbp > 0; AgGYuGCcpTgxkbp--) {
            PkPeC -= vvtDssk;
            vvtDssk = PkPeC;
        }
    }

    for (int POGCSSISmtiP = 572512863; POGCSSISmtiP > 0; POGCSSISmtiP--) {
        vvtDssk = kYRidMBHYFYe;
        VqRAdNtieex = PkPeC;
        ETgGgctnM = LJxxLTOVb;
    }

    for (int ttsvkLqbsAFu = 1631433211; ttsvkLqbsAFu > 0; ttsvkLqbsAFu--) {
        continue;
    }

    for (int PNRyxjDHUyqTarE = 2058757086; PNRyxjDHUyqTarE > 0; PNRyxjDHUyqTarE--) {
        continue;
    }

    for (int ovNOzyyzTA = 673695830; ovNOzyyzTA > 0; ovNOzyyzTA--) {
        vvtDssk *= VqRAdNtieex;
        gwJtrl = ! gwJtrl;
    }

    if (kYRidMBHYFYe < 827574.2841919449) {
        for (int KcQTXZ = 546698084; KcQTXZ > 0; KcQTXZ--) {
            gwJtrl = gwJtrl;
            kYRidMBHYFYe -= PkPeC;
            kYRidMBHYFYe += kYRidMBHYFYe;
        }
    }

    for (int HjMhGat = 898617939; HjMhGat > 0; HjMhGat--) {
        VqRAdNtieex -= vvtDssk;
    }

    return kYRidMBHYFYe;
}

int DYdGJbNn::skrQhZ(string HHWoeIT)
{
    bool SkczmAVjKNTvX = false;
    double JfPwWh = -862794.3856068362;
    double URQAzjUrzsFrlMb = 744207.4716559163;
    bool ZOKCvmCildOe = true;
    string aoiOiJKkiXLTR = string("VrbMFpdyUMlLjXtqMixZjMAwovMkFiCvguAsstirCWFfHvHPAitAlBICvFFMbooddRffUCpAnyNeaTXXtplssSuswJZMpVYxRcMLZpzIcCoVfbrLCpG");
    string zAwGJPYItGw = string("TUDJUvYWjPFFtPQEEXJGNeWIawZzUTOkULxxRPTSoHjWzTVZLmXqvKXEfxMhInZv");

    for (int BjWtAgQplJdnT = 119996822; BjWtAgQplJdnT > 0; BjWtAgQplJdnT--) {
        URQAzjUrzsFrlMb /= URQAzjUrzsFrlMb;
        aoiOiJKkiXLTR += HHWoeIT;
        JfPwWh += URQAzjUrzsFrlMb;
        JfPwWh -= JfPwWh;
    }

    return -389866298;
}

int DYdGJbNn::FPAnPXMM(bool zMpiVGCHVq, string mmCEkFeQjOXAq, double pEHbrduRx)
{
    double gbLCYvUXmiesb = -1037812.9172014011;
    string scuKU = string("xAXVeyOgoEvHqtQWbIlEvezoonRlMjKPikMerLDbReElRjSkUWJeEzfnBkVWxCaePGlSLAWTeIYnAsxLXoCfZTGqVTRsUfSGeWBdJHRlqhDswLDarGUKJCxtadaayONpUjFZjQkrnfYyypTiHBoQVpvFaepitJcPkIijXfGEEuxfoiHvLxZgZleibbHMntuXnM");
    int csircp = 32957458;
    double AqbqqXo = -233001.90468829157;
    double WJuPGxtLdBQQsfQ = 959795.8079649892;

    if (WJuPGxtLdBQQsfQ != -1037812.9172014011) {
        for (int JTXjNwuooXoH = 1601180179; JTXjNwuooXoH > 0; JTXjNwuooXoH--) {
            gbLCYvUXmiesb -= AqbqqXo;
            mmCEkFeQjOXAq += mmCEkFeQjOXAq;
            AqbqqXo -= WJuPGxtLdBQQsfQ;
            pEHbrduRx += AqbqqXo;
        }
    }

    for (int HNwbQPvg = 817606525; HNwbQPvg > 0; HNwbQPvg--) {
        pEHbrduRx += AqbqqXo;
        mmCEkFeQjOXAq = mmCEkFeQjOXAq;
        gbLCYvUXmiesb -= WJuPGxtLdBQQsfQ;
        WJuPGxtLdBQQsfQ = pEHbrduRx;
    }

    for (int PTqjYyEEpMEk = 1772187015; PTqjYyEEpMEk > 0; PTqjYyEEpMEk--) {
        zMpiVGCHVq = ! zMpiVGCHVq;
        csircp -= csircp;
        pEHbrduRx = gbLCYvUXmiesb;
    }

    return csircp;
}

void DYdGJbNn::ziFLgExFWgTJX(int PlwNujLxMfoDSam, string gXBpfZmLgdmixJHc, int SanuhUWQxWouAKzk)
{
    string TgGwazztflfAUYk = string("zvUdCiUCOtyPGoPnVVWnXpkWAhKMYgTSBIOMHXxolHWNVtdvatLudjAobfPcFwMtGpfkpzVcPVG");
    double LcvbKSDT = -426432.86637735326;
    string KDbnxQysYrNb = string("RRGQfmmWbkaThaWWDiAkLTuskunnxHaIRfYNFheFSBGWBfpjOqWAgRdndmlHDQnQZHCbmKbbAwXRAgyUlCdDuJaIpZcTVtJFyTafagQUalBHsAGwSMGiuCIAUOEHbTMGuOfLQISSvKXlxIqOWCHJzxdZxQpgmefCrpMVdMsTyaxgKNDKMzHxliASotOwANMMyxSIFCprDcdKqZTkDmyIIOWeFkhQXxZNIOHeEYubozZDTzqEepq");
    int CtEzzwVGNoFyVEJ = 1783336847;
    double LGNcHA = -914566.8698126352;
    int OVtKiuqz = -180960235;
    bool UvXwipsunxTJ = false;

    for (int yuuWIelUMQrWWXrn = 977607330; yuuWIelUMQrWWXrn > 0; yuuWIelUMQrWWXrn--) {
        continue;
    }
}

DYdGJbNn::DYdGJbNn()
{
    this->JsMmux(true, string("uVCJYDOYdhoBCLoDycLyjzrOJowHjaUbSnINQUXUNesdjKPHfchcnLEXDRvakimidiqKEpXNsXbrTNUBwuSLfOCDfxkyhnhbmlSBvqthdweQMHwtAEZkTAXHZqmnFDqBthjCgnWXgqWGZoYCWenffRfpQTHKQIHAaUKvAeeLuJARJTcfMjnSaFFcaQRkZzTbYxBQsMgfhMSenfsTWQLxQpjJciXFoZjvHcgMs"), 1338002432, 800732.4968214083);
    this->hjxHpzJ(-1570998079, -308544.08223817183, string("vuUduLkzzffzWalIJUjeizbXAtyYLpnHXtHmFjbvMlkoiGxVgaPpNdHCdHPoSJNITmqAInJBrzZISczcWGEuAUOjaFZTlQEOeYJkdrLtvLlvCxWtxzfaaJXeIlqhoEcRqjlyJrFBbkLlQKBzJJddFqWlcxdijenLOCzMSXYhLMuqzFHHMBAzIRjpTwAdeoekGrGTzzEzNpwNssnKZASJvOIyugDKVhyQLqXwGCt"), 980663.8875789092);
    this->skrQhZ(string("YWOYhCeWvQRdETtUWqUvksXDdqMPEelfrHICHBtErgVNowRDsPTFsCCXPtQficdlnXxiYPhWPYjCSFGvekcBUlqfSuFHKFMuhUfovWPNrQaFCrZQAWRkkbRrvNHhlxM"));
    this->FPAnPXMM(false, string("tRFuoIPshLAtzyylBNJKlxNPpqGKcYrVipQEKYNluYTbeJnwxtvEDidNvtYaBmuZPBkSQnHoLetcaqoxQOaKlWhJBhytekpGfHYWydCFjAvZrthjERPegCsXKHlrNsCNCffUFYAyQLOcEEDxaPFxWstBeKSfebvXEPeXVcJnNinrxbunf"), -1042757.3522215576);
    this->ziFLgExFWgTJX(648733603, string("oihyGUUnCKBmIHHbUcnBManoXRRJbAfyfZjWeIVOycLnuzFDMqCCblKcpcYKUKZMWRKNyUUwzlhULnWnyUivUSzLfrDKRPEmyiNmDGeZVeIsPTDXDASKVRbqPzKMqpJfkcLnODeJXFqqgykjrYQktIeFUlflzWihArQxAzhisalTnbRozGzyibnrveGunRHGmOFz"), 240169148);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gaqFAWtzBS
{
public:
    string lewFYVjtNqjyj;
    bool axSKnZb;
    bool UYqzcGPUhtQTHxlF;

    gaqFAWtzBS();
protected:
    double UXbadYSnM;
    bool KnGfkarqHiTUGK;

    bool SfTaPQmLIrndPO(string Txdebwzoxf, string OSZoqNPgn, string vgnhUJxxDbRThOL);
private:
    bool tqqdrwlyzjEANlK;
    bool xBBjWBvsju;
    bool gIoYKJLVLIpi;
    string KFMXWSXHrH;

    string GGRJuhiNP(int NUBrshIHFehcHKR, int acXlGHdehYqGDWs);
    int NmoQKzWu();
    double MzqPtl(double BvWjP, string InSjBvZxExsYOFe, bool RrwsRlFLCRAvHSk);
    bool iwmSCZhOFUsj(double NKpGyJkPDh);
};

bool gaqFAWtzBS::SfTaPQmLIrndPO(string Txdebwzoxf, string OSZoqNPgn, string vgnhUJxxDbRThOL)
{
    double jnLmggU = 648199.002131716;
    string MPkTXmdxsU = string("vwYhbNzjXAHqslLuNvDNRWrocAlUPwVkactsXhGfFwykgPjKchz");
    double uMPtlfsfC = 911828.9393039675;
    bool CXgQVtqt = false;
    string dMGxpqyJQHmMmqf = string("Qpi");
    bool MgqrfBtpeWOZTZ = true;
    bool xqXKyrDGRqe = true;
    bool RDYVuXQ = true;
    string xEXVtSyy = string("xueTZDGQedxMPIZxHNGbEalTygntyASRZ");
    string brdbvafCmpeE = string("IlpWWbPVTKAwjKWbEzlSlzSrLAEiX");

    if (MgqrfBtpeWOZTZ == false) {
        for (int eTXsCXxd = 1771802865; eTXsCXxd > 0; eTXsCXxd--) {
            MPkTXmdxsU += brdbvafCmpeE;
            CXgQVtqt = RDYVuXQ;
            uMPtlfsfC /= jnLmggU;
            MPkTXmdxsU = xEXVtSyy;
            RDYVuXQ = MgqrfBtpeWOZTZ;
        }
    }

    if (brdbvafCmpeE > string("hZnjFCMAFejPcwLBTllCJJnkOrCIoNZjpyjjrgQJKoiRfRocKIXfEmkFBObjGgVHUGFdKGrwsAMSeqfepsfqVcvntNQAilygmHllzaatHUvsDAALtOrMxCpQBLvJBICMDFpoJtRWzUWlDGMHLPYqcpYKApMrkrzWuggLYdZymWMxWeUGTPRXqSUhADyZosGI")) {
        for (int vxniPJAVqWPC = 1323904713; vxniPJAVqWPC > 0; vxniPJAVqWPC--) {
            uMPtlfsfC /= jnLmggU;
        }
    }

    return RDYVuXQ;
}

string gaqFAWtzBS::GGRJuhiNP(int NUBrshIHFehcHKR, int acXlGHdehYqGDWs)
{
    double uLwsBnlWkgx = -46228.53432251686;
    int WDvWdn = -1591491786;

    if (WDvWdn > -2092730805) {
        for (int vvbsDDMMvkAnoX = 1698271977; vvbsDDMMvkAnoX > 0; vvbsDDMMvkAnoX--) {
            uLwsBnlWkgx /= uLwsBnlWkgx;
            acXlGHdehYqGDWs += acXlGHdehYqGDWs;
            NUBrshIHFehcHKR -= NUBrshIHFehcHKR;
            NUBrshIHFehcHKR *= NUBrshIHFehcHKR;
            acXlGHdehYqGDWs *= WDvWdn;
        }
    }

    if (acXlGHdehYqGDWs > -44520924) {
        for (int sMiFPiNXzTW = 1867250712; sMiFPiNXzTW > 0; sMiFPiNXzTW--) {
            acXlGHdehYqGDWs /= WDvWdn;
        }
    }

    if (NUBrshIHFehcHKR >= -44520924) {
        for (int OKVtAdPBOdmprlPi = 1335953771; OKVtAdPBOdmprlPi > 0; OKVtAdPBOdmprlPi--) {
            NUBrshIHFehcHKR *= NUBrshIHFehcHKR;
        }
    }

    return string("CmxKdcvEtGxrS");
}

int gaqFAWtzBS::NmoQKzWu()
{
    string ZceLGVdtTtpUQJn = string("GJVapLyCYQADQXDGxBWxCAAKIlwuDcTqpHpgGAnqpdeVDsfaqPEqlRcVqroHRZCyFhaIdFEAlbZqLuQjLecWmEgLPpchxmskadwtNSIWcMUYYveIXaYUTuKOgoWxHvZTSJJtlqWlzIMPTPPgWgiVgfZQmmJOFvHjlVdDcygsTTslWtGeCydx");
    double bIjVpts = 438099.2262380238;
    bool oInQBONYHqPATJ = true;
    double PgcKnkJYAGSe = 366543.59554908966;
    bool MqRvDlpGXiWwUu = false;
    bool UOzITMLi = false;
    int CrPnmzRemo = 639464548;
    bool aEcmQGWi = true;
    double KFYWOhxR = -48712.74716810952;

    if (bIjVpts > -48712.74716810952) {
        for (int rvVSDAqDPLMAWp = 122088940; rvVSDAqDPLMAWp > 0; rvVSDAqDPLMAWp--) {
            continue;
        }
    }

    for (int GHFJMKU = 668965523; GHFJMKU > 0; GHFJMKU--) {
        PgcKnkJYAGSe += KFYWOhxR;
        UOzITMLi = ! aEcmQGWi;
    }

    for (int OUswnzC = 2113995372; OUswnzC > 0; OUswnzC--) {
        aEcmQGWi = ! MqRvDlpGXiWwUu;
        UOzITMLi = ! aEcmQGWi;
    }

    return CrPnmzRemo;
}

double gaqFAWtzBS::MzqPtl(double BvWjP, string InSjBvZxExsYOFe, bool RrwsRlFLCRAvHSk)
{
    string sgNCmkYPP = string("crcKhnHuoLbwuDoNLKKjL");

    if (sgNCmkYPP >= string("crcKhnHuoLbwuDoNLKKjL")) {
        for (int DcEiODeltRbsrQjg = 1642684175; DcEiODeltRbsrQjg > 0; DcEiODeltRbsrQjg--) {
            BvWjP += BvWjP;
            sgNCmkYPP += sgNCmkYPP;
            sgNCmkYPP = sgNCmkYPP;
        }
    }

    if (sgNCmkYPP != string("BUhZXXWlKgmhVzTkCZVZibJJxFGjIOcZFlDyopasINcPDAHMVoonLfQGOtjEfywOpvCzDkLXeSjzoCjyOGaPvCRHnxnGhIEouXjeNzVmpnxzK")) {
        for (int FvPnes = 663143367; FvPnes > 0; FvPnes--) {
            InSjBvZxExsYOFe = InSjBvZxExsYOFe;
        }
    }

    return BvWjP;
}

bool gaqFAWtzBS::iwmSCZhOFUsj(double NKpGyJkPDh)
{
    int tGSZbIK = -837289187;
    double HQyCkhmaJOQCaovh = 522041.05291863467;
    double ilQmPMlwaMYuhGu = 581412.8787118231;
    bool stxcOmshD = true;

    for (int kvQQyaSP = 1037715605; kvQQyaSP > 0; kvQQyaSP--) {
        ilQmPMlwaMYuhGu = ilQmPMlwaMYuhGu;
        NKpGyJkPDh += NKpGyJkPDh;
    }

    for (int lokcLYiUcYXKN = 1076810666; lokcLYiUcYXKN > 0; lokcLYiUcYXKN--) {
        NKpGyJkPDh -= HQyCkhmaJOQCaovh;
        HQyCkhmaJOQCaovh -= ilQmPMlwaMYuhGu;
        NKpGyJkPDh -= ilQmPMlwaMYuhGu;
        stxcOmshD = stxcOmshD;
        ilQmPMlwaMYuhGu = ilQmPMlwaMYuhGu;
    }

    if (HQyCkhmaJOQCaovh >= 661038.9023485254) {
        for (int VRLQrVPuMrPJi = 77300220; VRLQrVPuMrPJi > 0; VRLQrVPuMrPJi--) {
            ilQmPMlwaMYuhGu += NKpGyJkPDh;
            NKpGyJkPDh -= NKpGyJkPDh;
            ilQmPMlwaMYuhGu += NKpGyJkPDh;
            HQyCkhmaJOQCaovh /= ilQmPMlwaMYuhGu;
            HQyCkhmaJOQCaovh = HQyCkhmaJOQCaovh;
        }
    }

    return stxcOmshD;
}

gaqFAWtzBS::gaqFAWtzBS()
{
    this->SfTaPQmLIrndPO(string("LwFOtXDZWeABFOAesESLaekIUDhsmijsihiMOKSeyRlkcKHBMVfqueFcUUwYTuEKCkAwimMQIOxGELEPOXmnfuXauOFfRSKWXPdWPDliACzfxAzGyfRNosgyzNfKcsSViSNORupekQQjBtWVDVlYuhwImyoJlYfgTivgLphnCaXvjqjODBGrnXloDwOKAfNJYonOBHeUwkppoSOKVaYKAQpoZRzhaRUuKDegCUQHiUShCnqwTavPq"), string("hZnjFCMAFejPcwLBTllCJJnkOrCIoNZjpyjjrgQJKoiRfRocKIXfEmkFBObjGgVHUGFdKGrwsAMSeqfepsfqVcvntNQAilygmHllzaatHUvsDAALtOrMxCpQBLvJBICMDFpoJtRWzUWlDGMHLPYqcpYKApMrkrzWuggLYdZymWMxWeUGTPRXqSUhADyZosGI"), string("ZewJYAqAJLGcWGvOybhuVlnzRIvsltqCfzNGKqBwkQdOcnsmCbmcDuJZodouVvrtsSUyvCRlGsGqGIhqHTMVyCDmxQdfFjuWkJpmKGIvzxJUbNhCAjHxKrIyULnBHiLGhRzQqHaUkKJJG"));
    this->GGRJuhiNP(-44520924, -2092730805);
    this->NmoQKzWu();
    this->MzqPtl(-696985.876253118, string("BUhZXXWlKgmhVzTkCZVZibJJxFGjIOcZFlDyopasINcPDAHMVoonLfQGOtjEfywOpvCzDkLXeSjzoCjyOGaPvCRHnxnGhIEouXjeNzVmpnxzK"), false);
    this->iwmSCZhOFUsj(661038.9023485254);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YSEQvKCt
{
public:
    bool eLGqKKETbDfnUp;
    string ieJmAlidStUG;
    int cYfITZcy;

    YSEQvKCt();
    double fDmTrSUMLMFQf(double cfnmTV, double vXiSHk, bool zQddCchWJygroNbw, double lauQq, int gDlPcLMO);
    double ZqkwAXt(int GeWnmTghmqSwTBR, double TLpBJLQtgkEZJLc, int kkNAEfQwpPesc, string ZMpYOJi, bool ZvBDvjpYQLjzow);
    double pOcjsQfIbn(string jCAWlhuUY, string lyGKkBDsgGa, bool sEKBYMt);
    string tkiDZqwApYZ(int omcXM, string BMytgve, string cJoPIcnFh, double NUxqEf);
    bool xeudQsMv();
    string QtKnmHC();
    string JAtGlIjyFGBoU();
protected:
    int tCDXwvKdcRcj;
    string mpguWhM;
    double nzZoiy;
    string GFjlTKuIa;
    int RtbBbLHhjQCgcc;

    int CkyOILiSFyBzkLAR();
    void uoYTVXFHJS(double EFASqxaAPgGi, string EmxoyU, bool adMgWIjIbQVa);
    double vSVQMkjmCkNwAov(int dSxhCc);
    double AqJXgXT(bool JlnMjEXDBMs, bool aYZApZ, bool NvFcpNBTMCoLc, double zTcjHGocgCbGZ);
    bool qxEKvPhiT(bool ADbDLpBqrftFL, string AAksGybbjLMuKTks);
    void oStmaFZrSKWEHE(double nPJkWb, double cZNvobIcKk, double VIvOIIp, int vYOfgKWV, int NeKukdpLyWm);
private:
    int DgQrm;

    void kAAWvEtJIMlPA(bool LDuiVppyshs, bool wPMEuScCog, int IVFbcxtfR, bool WaHgtW, double RoJLUPeLFUAXEvto);
    double PbOloBlRT(bool efMJRxu, int aKTax);
    string AJDzDiIwJ(double yRvgQ, int rGyDjll, int Jbcae, int rihQn);
    string AuwgzkbYRCIIZVJ(double PrfiKGu);
    double IyNMthmuCmwIgPE(int TnuYpRTclSW, bool CtQGgSpRwYL);
    void YSQGgYSzqsTarN();
    string rqKEbFDTZO(bool KotzhEWPy, bool RKGcdWUSOGdnCg, double qouxOjG, string owEkCr);
};

double YSEQvKCt::fDmTrSUMLMFQf(double cfnmTV, double vXiSHk, bool zQddCchWJygroNbw, double lauQq, int gDlPcLMO)
{
    bool QrwNqdigkebdklS = true;
    int fCtsAMZGT = 469097802;
    int vpIOwOwCk = -783281250;
    int eDNEKeYbhT = 1406619484;
    string OdPfvDW = string("qkgqyRiGHqG");
    int HQzLmOoaYM = -1103939196;
    bool FWyAbowRBZIg = false;
    bool qtFxprgDew = false;
    bool yGSxPAh = false;

    for (int IUYWbQxAPgkdOGKZ = 259748074; IUYWbQxAPgkdOGKZ > 0; IUYWbQxAPgkdOGKZ--) {
        cfnmTV = lauQq;
        lauQq -= lauQq;
        vXiSHk = cfnmTV;
    }

    if (FWyAbowRBZIg == false) {
        for (int vVlKkbZaMyTZ = 415099094; vVlKkbZaMyTZ > 0; vVlKkbZaMyTZ--) {
            FWyAbowRBZIg = ! qtFxprgDew;
            qtFxprgDew = QrwNqdigkebdklS;
            zQddCchWJygroNbw = yGSxPAh;
        }
    }

    for (int QqGTyZRN = 1154327362; QqGTyZRN > 0; QqGTyZRN--) {
        QrwNqdigkebdklS = ! yGSxPAh;
        fCtsAMZGT = eDNEKeYbhT;
        cfnmTV -= lauQq;
        eDNEKeYbhT += gDlPcLMO;
    }

    for (int PjuLbgHMfthvUXzK = 789007241; PjuLbgHMfthvUXzK > 0; PjuLbgHMfthvUXzK--) {
        continue;
    }

    return lauQq;
}

double YSEQvKCt::ZqkwAXt(int GeWnmTghmqSwTBR, double TLpBJLQtgkEZJLc, int kkNAEfQwpPesc, string ZMpYOJi, bool ZvBDvjpYQLjzow)
{
    int jtGEMrwuNeZ = 1310794237;
    bool ZlaYSrtS = true;
    string RfXBoAdOSM = string("wuoYbHgBURIdlcDuoVOjmgaWOhcrTTgPQpEPtFKOhJvPgfcWZXfwPOOOSbNmjFCPOZxjbbgiUwAOttqUFCRmbABuVqeTPvlhrxnGwzoHACzuIndGrfFgexxbBGZmyssrgp");
    int dQtrhYDnfffWF = -117867544;
    double wKmEaclnap = -575245.5987005004;
    int HVgJLYSzMRfX = -1571456051;

    if (jtGEMrwuNeZ <= -1571456051) {
        for (int NkZcHPTmlmX = 1335138316; NkZcHPTmlmX > 0; NkZcHPTmlmX--) {
            TLpBJLQtgkEZJLc = TLpBJLQtgkEZJLc;
        }
    }

    if (dQtrhYDnfffWF != 1310794237) {
        for (int FJTtPImafc = 394588101; FJTtPImafc > 0; FJTtPImafc--) {
            dQtrhYDnfffWF = dQtrhYDnfffWF;
        }
    }

    return wKmEaclnap;
}

double YSEQvKCt::pOcjsQfIbn(string jCAWlhuUY, string lyGKkBDsgGa, bool sEKBYMt)
{
    bool mpRAUcfQAAKky = false;
    double lmTAAsoCAjtXHgc = 125441.20200738647;

    if (mpRAUcfQAAKky == false) {
        for (int azEvEMrqpvZHrt = 1757679721; azEvEMrqpvZHrt > 0; azEvEMrqpvZHrt--) {
            mpRAUcfQAAKky = ! sEKBYMt;
            lyGKkBDsgGa = jCAWlhuUY;
        }
    }

    return lmTAAsoCAjtXHgc;
}

string YSEQvKCt::tkiDZqwApYZ(int omcXM, string BMytgve, string cJoPIcnFh, double NUxqEf)
{
    string PPbUZlTwMc = string("hiLigohtNbGpUMxhwduGrmxjHIIVlVQlWmVVuzUNVTMWrKGejrShiQ");
    double lgADdjCjC = 272010.9574673971;
    int NzVeUNReCkLTxFOW = -1588031764;
    int MmKWOfvJ = -2140153729;
    string jZHnJyJ = string("CyHlpicTyjivCBuoRbzEnsoQAGOStkOhThWEAFMMeCznUiSrNbnWQjrEZqmvWNQMNeoczPuoqxqqlOuBiYSREnKOulqpvjlxWpqCOPBCraoEEKPJqQcemwgOwxODVJeFKQxcmVVpjUmJJKIgnDoFEFjsBRllLArBrRaaXisJhNHsekOpWfaVNzxTCgCyZlKrMTliIbYVFZrmEfzcesEYoBewLoIUYshtuXCkoxJjPspsxrCynrhXEzhmEYYQSA");
    bool MhLLRSAvolPdUIXQ = true;
    double AXZBCm = -20559.786126678417;
    int hxWgoKeKFgJ = 1629114309;
    double GrZmCGfPnYlWr = 1030018.0919429692;
    int VjIuyGy = -1375320504;

    for (int gyGgZ = 426762947; gyGgZ > 0; gyGgZ--) {
        NUxqEf -= lgADdjCjC;
        GrZmCGfPnYlWr -= NUxqEf;
    }

    if (BMytgve != string("PHJRIrjgDERMDaxqcDacmzCJZIUItozSvqxyBzKRiQWpywunfDcVQoYzYHxDUOHqISXFDSMYKINPzBpMFnwLblnaLmctqFLgjAGzgLUTiuyvpegPukglKdALcpJgZbdIBUiJDZGiXZpYwWOlDEbMYpVzcrkAeIBCGkltTdsfjXgUlfOhBxvIgRECrAbeznKpXGzsJtYhqPtyQCnSUJgpAsMazwzLdNxyywzYsFpOGdikMPAYfFHSzo")) {
        for (int epSfNQ = 998673106; epSfNQ > 0; epSfNQ--) {
            jZHnJyJ += BMytgve;
            MmKWOfvJ = NzVeUNReCkLTxFOW;
            PPbUZlTwMc += PPbUZlTwMc;
            AXZBCm /= GrZmCGfPnYlWr;
        }
    }

    for (int KREtJGESJ = 1565198913; KREtJGESJ > 0; KREtJGESJ--) {
        MmKWOfvJ /= NzVeUNReCkLTxFOW;
        lgADdjCjC *= NUxqEf;
        BMytgve += cJoPIcnFh;
    }

    for (int YMkOZ = 274013620; YMkOZ > 0; YMkOZ--) {
        PPbUZlTwMc = BMytgve;
        PPbUZlTwMc += BMytgve;
    }

    for (int UPENOOchdy = 1126996602; UPENOOchdy > 0; UPENOOchdy--) {
        lgADdjCjC -= NUxqEf;
        omcXM *= MmKWOfvJ;
    }

    for (int LiOso = 511145139; LiOso > 0; LiOso--) {
        GrZmCGfPnYlWr *= lgADdjCjC;
        jZHnJyJ = jZHnJyJ;
    }

    return jZHnJyJ;
}

bool YSEQvKCt::xeudQsMv()
{
    bool ldFWobHVMqfnsRmG = false;
    bool aquQyzGcF = true;
    string SlIgcbZC = string("pHCwGaPKsPNpDtZETiCtzcjgMKmnSBLzgIuJPtRRpufCHdzpnnChlkbZG");
    bool rlLLMt = true;
    double txBOJPVsFOYzJqRS = -390050.9619284669;
    int hMpaJHOMHZnWQ = -949981492;
    double FvUEFETx = -438834.17463745526;
    string MSpdtxdOAuJPvj = string("Itl");
    int XsRiAVBzYdYIj = -326550191;

    for (int IjDQMMdU = 2126902297; IjDQMMdU > 0; IjDQMMdU--) {
        XsRiAVBzYdYIj /= XsRiAVBzYdYIj;
        MSpdtxdOAuJPvj = MSpdtxdOAuJPvj;
        hMpaJHOMHZnWQ = XsRiAVBzYdYIj;
    }

    if (MSpdtxdOAuJPvj != string("Itl")) {
        for (int wKHHwBxp = 1082799142; wKHHwBxp > 0; wKHHwBxp--) {
            rlLLMt = aquQyzGcF;
            SlIgcbZC = SlIgcbZC;
        }
    }

    return rlLLMt;
}

string YSEQvKCt::QtKnmHC()
{
    int FhmzQEXqmrNrTnns = 1637869847;
    string aJdIYgALGMPwWh = string("DiglIBmnbnrxTUxYpIvRKbLpqdySHdcDmyExVfuPrdRzexNrLCcZTiQIRGEgiWOIxQXGrxsaqnmEjzEwsbYzCAFAbCFpHrgTXkQQFNeJSdLklqcWGAvAAmymaaTjxsugSNxhOfgvvUutZgzLkkMVxRIAjmJSzfbBzooInSyUqnVimrrYASSubpuzcmBezSzbKheEZnKtllRiCHdlOFKSBjlHQCQCWkgABg");
    int RtfwraJEmqo = -1214510738;
    bool hsgqdOs = false;
    double yOEYmBCudy = 448915.5859723247;
    int PqBdmhqYJBags = 127288416;
    int rfCXZtLkN = 1025557340;
    string XHymbfkWR = string("yQcaMosdMKuoTPtCkbqpNoahpzJSHYpRajMPwPwzVMPBXIStzNKwWgiUSmDJalPJVoTyMWvRpmslaJqjuxibAUIIlFbEezjRKeDFdTgBechksBIZplhcGZtXpxijbq");
    int bQhJOCTjN = -1608337513;

    if (rfCXZtLkN >= 127288416) {
        for (int HJHSmEFsfnAj = 1691669127; HJHSmEFsfnAj > 0; HJHSmEFsfnAj--) {
            PqBdmhqYJBags *= FhmzQEXqmrNrTnns;
            rfCXZtLkN = FhmzQEXqmrNrTnns;
            bQhJOCTjN *= RtfwraJEmqo;
        }
    }

    for (int SxvxWC = 940538300; SxvxWC > 0; SxvxWC--) {
        rfCXZtLkN *= bQhJOCTjN;
        RtfwraJEmqo *= rfCXZtLkN;
        yOEYmBCudy -= yOEYmBCudy;
        rfCXZtLkN /= rfCXZtLkN;
    }

    for (int kTToiTiLCvIct = 1827688286; kTToiTiLCvIct > 0; kTToiTiLCvIct--) {
        bQhJOCTjN /= RtfwraJEmqo;
        FhmzQEXqmrNrTnns = bQhJOCTjN;
        bQhJOCTjN += bQhJOCTjN;
        XHymbfkWR += XHymbfkWR;
    }

    for (int mphMSLWFBkVNQp = 513667482; mphMSLWFBkVNQp > 0; mphMSLWFBkVNQp--) {
        bQhJOCTjN /= PqBdmhqYJBags;
        PqBdmhqYJBags /= rfCXZtLkN;
    }

    for (int RRXSN = 1483357044; RRXSN > 0; RRXSN--) {
        aJdIYgALGMPwWh += XHymbfkWR;
    }

    for (int PQuackAzPp = 1018740360; PQuackAzPp > 0; PQuackAzPp--) {
        RtfwraJEmqo -= PqBdmhqYJBags;
        rfCXZtLkN *= RtfwraJEmqo;
        PqBdmhqYJBags /= bQhJOCTjN;
        RtfwraJEmqo *= PqBdmhqYJBags;
    }

    for (int MKEmMzE = 1447815786; MKEmMzE > 0; MKEmMzE--) {
        FhmzQEXqmrNrTnns -= RtfwraJEmqo;
        FhmzQEXqmrNrTnns /= bQhJOCTjN;
        FhmzQEXqmrNrTnns = FhmzQEXqmrNrTnns;
        PqBdmhqYJBags /= bQhJOCTjN;
    }

    for (int DSZjFgrTxoBHavTD = 1595496066; DSZjFgrTxoBHavTD > 0; DSZjFgrTxoBHavTD--) {
        rfCXZtLkN = bQhJOCTjN;
    }

    for (int knjYDxszN = 1746157950; knjYDxszN > 0; knjYDxszN--) {
        continue;
    }

    return XHymbfkWR;
}

string YSEQvKCt::JAtGlIjyFGBoU()
{
    double ttmjGbAW = -698098.919585296;
    bool wTXIrJ = false;
    int pnYPU = -985838118;
    bool VqFFWdtTo = true;
    int lqnQVjCrpuoxXuby = 1914203888;
    double VLPoxXtmFwTQ = 793219.9278754173;
    string UJbxYAltgk = string("woAfKqHHshKqTnEAybxopUFNCqxgtXQmOGvKrsOqQCYQGaOsuzIoVgDFEFUFHOGXJcrryEiWRHlXRPPCmveiuShfmnKkmQZrnoRncWpWeTKwKubyPBrjXGrtALdkmhNtTTkyKHCSPHvsiAVXIobfbNUsgboHyafstzwknKHdEqNFsuyfYLfPHOQDHZkRyhsVvMkBxLDnFsNJqbYipssTcDyohgWhAUOXRIAzUVsssLCyOQTNbsgEuXLIBmD");
    bool OWSJxWIeQClC = true;
    string EabFxgs = string("fSptzCKhpsyluyZFEsEPaIwQbutoSQIErhbVujTvPLiEZgSEoVFQdHEiqiObNzTbtIIai");
    int jNSGrKDGVT = 2143059637;

    for (int QFkoAUbiQqJJL = 364421547; QFkoAUbiQqJJL > 0; QFkoAUbiQqJJL--) {
        ttmjGbAW -= VLPoxXtmFwTQ;
    }

    if (UJbxYAltgk == string("fSptzCKhpsyluyZFEsEPaIwQbutoSQIErhbVujTvPLiEZgSEoVFQdHEiqiObNzTbtIIai")) {
        for (int FiolHplc = 1121810111; FiolHplc > 0; FiolHplc--) {
            pnYPU += lqnQVjCrpuoxXuby;
        }
    }

    for (int lKeAttmbszYVE = 1599723805; lKeAttmbszYVE > 0; lKeAttmbszYVE--) {
        continue;
    }

    for (int ghDVundeGhIE = 205271195; ghDVundeGhIE > 0; ghDVundeGhIE--) {
        continue;
    }

    return EabFxgs;
}

int YSEQvKCt::CkyOILiSFyBzkLAR()
{
    double lMloCSdFJxff = -420462.8930045452;
    int wQpezjiAoeQqUN = -1701125147;
    string DZYZX = string("ZajyqxvYpizCLVBxHDFbXzHxjTbqmYasfrUZvFTLwFyDgSUYameLGQvYLgSEbyGBjhaJGTZHjBSxgeuuoDVIdafmAwGJBTkqIAwXOPcTYMJbonQLFlGAjmxHEzAtyngUlQRBIElIPuAUZJNdaSxZnmeFFRgnVwdXTckHmRkyhWySAsBnMcTlqguFpYDdkqsFHxtJOojzgCefPpBrrtKHkqkglWtszPWcfIWjcHxAAYkRJOwOijptwLMGaSqCo");

    for (int UobcKWlOPEj = 1222827976; UobcKWlOPEj > 0; UobcKWlOPEj--) {
        continue;
    }

    for (int NZZNNJquW = 1126076787; NZZNNJquW > 0; NZZNNJquW--) {
        continue;
    }

    if (wQpezjiAoeQqUN == -1701125147) {
        for (int dzUrJmtkJHfuD = 1774432622; dzUrJmtkJHfuD > 0; dzUrJmtkJHfuD--) {
            continue;
        }
    }

    for (int hyZYKrYkeCGVAA = 549170846; hyZYKrYkeCGVAA > 0; hyZYKrYkeCGVAA--) {
        wQpezjiAoeQqUN = wQpezjiAoeQqUN;
        lMloCSdFJxff = lMloCSdFJxff;
        DZYZX += DZYZX;
        wQpezjiAoeQqUN *= wQpezjiAoeQqUN;
    }

    for (int OhnKOlzUVFEux = 1512441833; OhnKOlzUVFEux > 0; OhnKOlzUVFEux--) {
        wQpezjiAoeQqUN += wQpezjiAoeQqUN;
        DZYZX = DZYZX;
    }

    return wQpezjiAoeQqUN;
}

void YSEQvKCt::uoYTVXFHJS(double EFASqxaAPgGi, string EmxoyU, bool adMgWIjIbQVa)
{
    bool wmeqa = false;
    int DBbRnJrNhN = -1270581080;
    string nNvhXWOWYDtnsaM = string("eBoHsQAhVpeKFdIMQWuuQDyzDeCwHsHoPajsRyscYQVjzcuqIqxsSkLtbXUWhWYWAJctTPJmwcpBRpGxFzGbgseOUHeXztcZwTCfsVPkDukZenXbGZWmqEFXDChJKRLCUpNzQNbQEVQoEbbiNvTIIMgcszdQuskaAglcxkGwggnDAJkvlUMJqCzDTjspXSVamjaHuIGkVbIjTDppYuMNmttBdJjBZxhVvPrkwxpVFCzRfRp");
    string oihkzzIdWyvoYmx = string("dWPkpwSTRCpzwNNcgqLswtkrJzSjiBUJSVDfIOFDfqGmlUpWoPTKJgAoIpFTdzzUFmsvVeoEhlThQoaRVdisPKMNIPFVAgaeGDgwxeGHbdpPvtqiItpAumrtqjFDFoeGUrDFvifszA");

    for (int QvGsa = 1192284003; QvGsa > 0; QvGsa--) {
        oihkzzIdWyvoYmx += nNvhXWOWYDtnsaM;
        EmxoyU += EmxoyU;
        wmeqa = ! wmeqa;
        adMgWIjIbQVa = ! wmeqa;
        wmeqa = ! adMgWIjIbQVa;
    }

    for (int jpdjmwMUyZNFT = 248472621; jpdjmwMUyZNFT > 0; jpdjmwMUyZNFT--) {
        nNvhXWOWYDtnsaM += EmxoyU;
        EFASqxaAPgGi /= EFASqxaAPgGi;
    }

    for (int rVQQIDy = 757943320; rVQQIDy > 0; rVQQIDy--) {
        EFASqxaAPgGi -= EFASqxaAPgGi;
        oihkzzIdWyvoYmx += oihkzzIdWyvoYmx;
        oihkzzIdWyvoYmx += oihkzzIdWyvoYmx;
        oihkzzIdWyvoYmx += oihkzzIdWyvoYmx;
        oihkzzIdWyvoYmx += oihkzzIdWyvoYmx;
    }
}

double YSEQvKCt::vSVQMkjmCkNwAov(int dSxhCc)
{
    string EtyLwR = string("IsmpYSsaAFtDDHsKgRLudNGgaxXzPhxMdUDfXIfOlMIhtDDjmDaTuMZsiQnCHwqbhuBw");
    bool uquJJlWGADX = false;
    string uVvnCfRtYmTXeo = string("jvbdFpTgFXRCSTYufKEomIsRTZmFbJNcBpJFDDhmdZYhLcSXMRLSCYQUMKUSptWZsilRvnKqLdzQnSUXNFabtUEexlSwzYutydACRaDpaHcXvNKGGPSFZhSszMdeyGgHFmheaWnRel");
    int AIxJBcLu = 108983666;

    for (int HhqtRROneujS = 1786657118; HhqtRROneujS > 0; HhqtRROneujS--) {
        uVvnCfRtYmTXeo += EtyLwR;
        uVvnCfRtYmTXeo += uVvnCfRtYmTXeo;
    }

    return 525838.4351484268;
}

double YSEQvKCt::AqJXgXT(bool JlnMjEXDBMs, bool aYZApZ, bool NvFcpNBTMCoLc, double zTcjHGocgCbGZ)
{
    bool wEWVrCTHtWYlWb = false;
    string NFtJvlb = string("ZVhseCsobSDdDuTBunZdQUJyqZsCeAGbimrjATLWYcnsOXPeWfaIcAenvsuodRJuKtXObczPBlgrVMxuSAzQdDhKUUJXyIlTzyTdtvorUiMrIVIMEqBUmsJKOEBLGkfmwquCwtrvpDCIITQhxJHeFSkOBlNsBXvwGDWhwSRxJNyJZPTrcTtTcyrpVNsrErnBHRJzNIsFrSUGVJqzISWuaNFmxsQLwHgLvKti");
    string jGglrPZb = string("qqkqeISsMePdQaEasRhNIkDcgnAZnZIXCepEgmblydoHBPrpdvpXv");
    bool VMOzjYARADrR = false;

    for (int WZCzi = 1881994413; WZCzi > 0; WZCzi--) {
        jGglrPZb += jGglrPZb;
    }

    for (int hTalsawJHAlF = 718048453; hTalsawJHAlF > 0; hTalsawJHAlF--) {
        zTcjHGocgCbGZ *= zTcjHGocgCbGZ;
        NFtJvlb = NFtJvlb;
    }

    if (NvFcpNBTMCoLc != false) {
        for (int elzXbxQ = 568941713; elzXbxQ > 0; elzXbxQ--) {
            NvFcpNBTMCoLc = ! wEWVrCTHtWYlWb;
            aYZApZ = ! aYZApZ;
        }
    }

    if (NvFcpNBTMCoLc == false) {
        for (int aGdpTUXTGpghue = 1547759979; aGdpTUXTGpghue > 0; aGdpTUXTGpghue--) {
            wEWVrCTHtWYlWb = ! JlnMjEXDBMs;
        }
    }

    if (zTcjHGocgCbGZ > -18505.968295139734) {
        for (int cvYDRZDxpUFOBmh = 731312161; cvYDRZDxpUFOBmh > 0; cvYDRZDxpUFOBmh--) {
            JlnMjEXDBMs = VMOzjYARADrR;
            NvFcpNBTMCoLc = ! wEWVrCTHtWYlWb;
        }
    }

    return zTcjHGocgCbGZ;
}

bool YSEQvKCt::qxEKvPhiT(bool ADbDLpBqrftFL, string AAksGybbjLMuKTks)
{
    double erJBlHavQO = 136428.1512644474;
    string zFoNoHnWIdxk = string("oBcjZJhCzKvy");

    if (erJBlHavQO >= 136428.1512644474) {
        for (int eqNXS = 211143679; eqNXS > 0; eqNXS--) {
            AAksGybbjLMuKTks += zFoNoHnWIdxk;
            zFoNoHnWIdxk += AAksGybbjLMuKTks;
        }
    }

    for (int yDxlYSpvPNZ = 2046586494; yDxlYSpvPNZ > 0; yDxlYSpvPNZ--) {
        ADbDLpBqrftFL = ADbDLpBqrftFL;
        ADbDLpBqrftFL = ! ADbDLpBqrftFL;
        zFoNoHnWIdxk = AAksGybbjLMuKTks;
    }

    return ADbDLpBqrftFL;
}

void YSEQvKCt::oStmaFZrSKWEHE(double nPJkWb, double cZNvobIcKk, double VIvOIIp, int vYOfgKWV, int NeKukdpLyWm)
{
    int GCMaGEgMtbV = 219359501;
    int mIIbXULKk = -276797584;
    double VXvkVBINJKaDe = 81330.23670174336;
    double sQBgDwCWyHPuhuq = 487061.7183817752;
    int EFWsTvxSdl = -2110939840;
    int bYNqJZKElUhtey = -71122786;
    bool obaZXWJATrjLj = false;
    int mWMEK = -768400383;
    int rgCXNR = 1532999830;
    string rDfkxnIocqNXSAox = string("KUGfKhDZrkxVyhsRyeUHHkkEdYwSS");
}

void YSEQvKCt::kAAWvEtJIMlPA(bool LDuiVppyshs, bool wPMEuScCog, int IVFbcxtfR, bool WaHgtW, double RoJLUPeLFUAXEvto)
{
    double uIplCBAUlC = -72672.470958752;

    for (int fHAWBzWVdbf = 434539708; fHAWBzWVdbf > 0; fHAWBzWVdbf--) {
        RoJLUPeLFUAXEvto = RoJLUPeLFUAXEvto;
        LDuiVppyshs = WaHgtW;
        uIplCBAUlC += uIplCBAUlC;
        WaHgtW = ! WaHgtW;
    }

    for (int kXnvcDQGWukeKK = 922676799; kXnvcDQGWukeKK > 0; kXnvcDQGWukeKK--) {
        LDuiVppyshs = wPMEuScCog;
        LDuiVppyshs = LDuiVppyshs;
        LDuiVppyshs = ! wPMEuScCog;
        WaHgtW = WaHgtW;
        RoJLUPeLFUAXEvto = uIplCBAUlC;
    }

    for (int yYUIikRxCFsT = 1578991221; yYUIikRxCFsT > 0; yYUIikRxCFsT--) {
        uIplCBAUlC *= RoJLUPeLFUAXEvto;
    }

    for (int yssvBc = 686915316; yssvBc > 0; yssvBc--) {
        RoJLUPeLFUAXEvto *= RoJLUPeLFUAXEvto;
        LDuiVppyshs = LDuiVppyshs;
        uIplCBAUlC -= RoJLUPeLFUAXEvto;
        LDuiVppyshs = ! LDuiVppyshs;
        WaHgtW = ! wPMEuScCog;
    }

    for (int pSvVBP = 1993708604; pSvVBP > 0; pSvVBP--) {
        continue;
    }

    for (int HDwMyboYGRoYHWtz = 1779155091; HDwMyboYGRoYHWtz > 0; HDwMyboYGRoYHWtz--) {
        WaHgtW = ! LDuiVppyshs;
        IVFbcxtfR += IVFbcxtfR;
        LDuiVppyshs = LDuiVppyshs;
        LDuiVppyshs = ! LDuiVppyshs;
    }
}

double YSEQvKCt::PbOloBlRT(bool efMJRxu, int aKTax)
{
    bool zsHPNS = true;

    for (int thEBKdWFea = 76317881; thEBKdWFea > 0; thEBKdWFea--) {
        continue;
    }

    return -182599.56087837592;
}

string YSEQvKCt::AJDzDiIwJ(double yRvgQ, int rGyDjll, int Jbcae, int rihQn)
{
    string IooIXZhpR = string("NrJgyryqDIprgpUfgmSPAtgPFHuMtVxcIpZAroEKgdBjUPwYnKbACGMJDyZAsPSuAMyDsJMQZWLmeUayQrzYplVkhIIrBbYCssrsXahARwwfNnVfnwGjiaDoqVosgCShNLTKAfAHBYkhzHqRcnGTsASSSkJwoOjHpvoePuinGQvaNroZMNYUTPzcvGyxEphhLAQVMOoFFNaN");
    double BcSDPXOcLvpis = -1030632.0711820101;
    int flgbN = 2018650402;
    int qaxMFrY = -53653028;
    string HUNLlUcEv = string("urAqkgieSCnmPzHRrCGxONhCzMZSZQcdMcXxIqpXmmYzakhNdnOXhtkFYRnnuCLLelMrIAgOBUwXGKukOxLXFErlzshYSuqEYhnnIHAWRmlvwdDzZEDqlEYv");

    for (int gMDwcPZ = 744285259; gMDwcPZ > 0; gMDwcPZ--) {
        yRvgQ -= yRvgQ;
        qaxMFrY /= qaxMFrY;
    }

    if (flgbN < -53653028) {
        for (int xCJpWtTU = 2045396148; xCJpWtTU > 0; xCJpWtTU--) {
            rihQn -= flgbN;
            BcSDPXOcLvpis = BcSDPXOcLvpis;
            rGyDjll = qaxMFrY;
            rihQn /= qaxMFrY;
        }
    }

    for (int GjwkBXaB = 756462535; GjwkBXaB > 0; GjwkBXaB--) {
        continue;
    }

    return HUNLlUcEv;
}

string YSEQvKCt::AuwgzkbYRCIIZVJ(double PrfiKGu)
{
    double klbThazclGNTUEY = 372192.82942247076;
    double HvmQu = 1044628.8809236035;
    int IRfHHgUpBygQwg = 1232497395;
    string fmSsCgv = string("BNboyWykcOxjviEHYLmXsqCWCaeytyZLAwjJAuaLhBaumFuLyTlBFzUkqRvnpOSxCBFkAGxXBfooxoGfFESYtQwoXTenQjpikFyrPaTFZtdpuzGTxzBNtNVbNTuZbzpQb");

    for (int Aswpay = 1914497118; Aswpay > 0; Aswpay--) {
        klbThazclGNTUEY *= klbThazclGNTUEY;
    }

    for (int LzjqOEzloyCmN = 1070642833; LzjqOEzloyCmN > 0; LzjqOEzloyCmN--) {
        klbThazclGNTUEY *= klbThazclGNTUEY;
        HvmQu *= klbThazclGNTUEY;
        klbThazclGNTUEY /= PrfiKGu;
        PrfiKGu += HvmQu;
        PrfiKGu = PrfiKGu;
    }

    for (int MelJOqwDmCanX = 848189552; MelJOqwDmCanX > 0; MelJOqwDmCanX--) {
        PrfiKGu = klbThazclGNTUEY;
        PrfiKGu -= HvmQu;
    }

    if (PrfiKGu != 309982.2692382048) {
        for (int MwAVvxCDekQh = 1568650883; MwAVvxCDekQh > 0; MwAVvxCDekQh--) {
            HvmQu *= PrfiKGu;
            PrfiKGu = PrfiKGu;
            HvmQu /= HvmQu;
            klbThazclGNTUEY += PrfiKGu;
            klbThazclGNTUEY = HvmQu;
            HvmQu += klbThazclGNTUEY;
        }
    }

    for (int edlJSXOxJ = 1134999081; edlJSXOxJ > 0; edlJSXOxJ--) {
        HvmQu /= klbThazclGNTUEY;
        HvmQu -= PrfiKGu;
    }

    return fmSsCgv;
}

double YSEQvKCt::IyNMthmuCmwIgPE(int TnuYpRTclSW, bool CtQGgSpRwYL)
{
    bool JOiwcQhsM = true;

    for (int uqiKmTDmfLAQR = 49441195; uqiKmTDmfLAQR > 0; uqiKmTDmfLAQR--) {
        JOiwcQhsM = ! JOiwcQhsM;
    }

    if (JOiwcQhsM != true) {
        for (int iIlQySllZxd = 44700805; iIlQySllZxd > 0; iIlQySllZxd--) {
            CtQGgSpRwYL = JOiwcQhsM;
            JOiwcQhsM = ! JOiwcQhsM;
            TnuYpRTclSW = TnuYpRTclSW;
        }
    }

    for (int BQkzgvjiBX = 1782720401; BQkzgvjiBX > 0; BQkzgvjiBX--) {
        JOiwcQhsM = CtQGgSpRwYL;
        CtQGgSpRwYL = ! CtQGgSpRwYL;
        CtQGgSpRwYL = CtQGgSpRwYL;
        JOiwcQhsM = JOiwcQhsM;
        JOiwcQhsM = CtQGgSpRwYL;
        CtQGgSpRwYL = CtQGgSpRwYL;
        CtQGgSpRwYL = CtQGgSpRwYL;
    }

    return -49908.43409725611;
}

void YSEQvKCt::YSQGgYSzqsTarN()
{
    string mzEMKVrJ = string("FaPGsPUfycDGlNElrObLlPqzwQmQtJfBkaRixOeJAdWrtDvNdoqaWJKKLIOvONrmYkOzLBIXJnFpSCpUMwLgHVcmDTbHztsuIhYjIbnYbfmlTTHBcOIyDjyMAjryrhCArPDCEbkfHqPhnjziwtgIdGuHfNszYKcnQpVLkVQVomysMNXKdZurNSxDwDZMIaWOyIdYbwzsVnLwZyeSzUeSvDLVXhGXxZMVaMYQ");
    double FyOyLLURpQAa = -783144.3316419675;
    double VAbGc = -174715.47525502916;
    double rSvKjaSVCa = 292797.50486628205;
    int HNcfQcY = -675650997;

    for (int WJvaVgPIRieMMrP = 1728956080; WJvaVgPIRieMMrP > 0; WJvaVgPIRieMMrP--) {
        rSvKjaSVCa = VAbGc;
        rSvKjaSVCa = VAbGc;
        rSvKjaSVCa *= VAbGc;
        FyOyLLURpQAa = VAbGc;
    }

    if (FyOyLLURpQAa > 292797.50486628205) {
        for (int nsOCLKVAGPqIIXun = 1826915177; nsOCLKVAGPqIIXun > 0; nsOCLKVAGPqIIXun--) {
            continue;
        }
    }

    for (int aiOwPH = 1637385280; aiOwPH > 0; aiOwPH--) {
        rSvKjaSVCa += FyOyLLURpQAa;
        rSvKjaSVCa = VAbGc;
        mzEMKVrJ += mzEMKVrJ;
        rSvKjaSVCa /= VAbGc;
        FyOyLLURpQAa /= rSvKjaSVCa;
    }

    if (rSvKjaSVCa <= -783144.3316419675) {
        for (int yNmmmIjKo = 1076751183; yNmmmIjKo > 0; yNmmmIjKo--) {
            continue;
        }
    }

    for (int EkreRRxerTSNMj = 1767663790; EkreRRxerTSNMj > 0; EkreRRxerTSNMj--) {
        continue;
    }

    if (VAbGc < -174715.47525502916) {
        for (int cCwhCQWpibAUo = 22921799; cCwhCQWpibAUo > 0; cCwhCQWpibAUo--) {
            FyOyLLURpQAa -= FyOyLLURpQAa;
            mzEMKVrJ = mzEMKVrJ;
        }
    }
}

string YSEQvKCt::rqKEbFDTZO(bool KotzhEWPy, bool RKGcdWUSOGdnCg, double qouxOjG, string owEkCr)
{
    int ZXGNIyHyCwl = -766341679;
    int xvDFmc = 1952471488;
    double KJPEipxBxID = -691196.6039763354;
    int lhwkI = 2145544792;
    int EbgKcavbCMijtx = 413588690;
    string ICndYqM = string("lLPfTRUsuriMrjFLfbohceMZnWqavKghWyWznghfjGWpbYBlcZBTHnIBTfoNemUemjcUmxrDgcRweXBzKHIpBGybOdVrShBcUWbIEdvaKJhXXhagbYVJyEIqyHwZQAyJEKNFzyYDXrziTtHqDsvFEwkgfeiqFSaLKOlsEirrx");

    for (int APMZWDSC = 1605564630; APMZWDSC > 0; APMZWDSC--) {
        EbgKcavbCMijtx = EbgKcavbCMijtx;
        EbgKcavbCMijtx = lhwkI;
        EbgKcavbCMijtx *= lhwkI;
    }

    for (int JCQsP = 226807334; JCQsP > 0; JCQsP--) {
        RKGcdWUSOGdnCg = ! KotzhEWPy;
    }

    if (xvDFmc <= 413588690) {
        for (int rpRtpFHer = 1935790602; rpRtpFHer > 0; rpRtpFHer--) {
            ICndYqM = ICndYqM;
            RKGcdWUSOGdnCg = ! KotzhEWPy;
            EbgKcavbCMijtx /= ZXGNIyHyCwl;
            EbgKcavbCMijtx = EbgKcavbCMijtx;
            lhwkI -= ZXGNIyHyCwl;
        }
    }

    for (int dRpsLFvO = 1352939536; dRpsLFvO > 0; dRpsLFvO--) {
        lhwkI -= xvDFmc;
        EbgKcavbCMijtx *= ZXGNIyHyCwl;
        ZXGNIyHyCwl = EbgKcavbCMijtx;
    }

    if (KJPEipxBxID != 942477.0682094696) {
        for (int NAOAZ = 58941596; NAOAZ > 0; NAOAZ--) {
            ZXGNIyHyCwl -= ZXGNIyHyCwl;
            EbgKcavbCMijtx -= ZXGNIyHyCwl;
            qouxOjG /= KJPEipxBxID;
            ZXGNIyHyCwl -= xvDFmc;
        }
    }

    for (int KmTHgutWjTptV = 83515327; KmTHgutWjTptV > 0; KmTHgutWjTptV--) {
        ZXGNIyHyCwl = ZXGNIyHyCwl;
        KJPEipxBxID /= KJPEipxBxID;
        KJPEipxBxID -= KJPEipxBxID;
        KJPEipxBxID = KJPEipxBxID;
        ZXGNIyHyCwl -= lhwkI;
        xvDFmc -= ZXGNIyHyCwl;
    }

    if (ICndYqM >= string("lLPfTRUsuriMrjFLfbohceMZnWqavKghWyWznghfjGWpbYBlcZBTHnIBTfoNemUemjcUmxrDgcRweXBzKHIpBGybOdVrShBcUWbIEdvaKJhXXhagbYVJyEIqyHwZQAyJEKNFzyYDXrziTtHqDsvFEwkgfeiqFSaLKOlsEirrx")) {
        for (int mteAo = 1426662304; mteAo > 0; mteAo--) {
            xvDFmc = xvDFmc;
        }
    }

    return ICndYqM;
}

YSEQvKCt::YSEQvKCt()
{
    this->fDmTrSUMLMFQf(-266685.51319273456, -815432.916722006, true, -402197.872739315, -717982594);
    this->ZqkwAXt(-221157263, 757774.5740954493, -2132454675, string("AbFpRTEfIfBCOcbOLcVipnoikVwqDSMfpQwxltEoDPRKOnHkMaRgQbrkkQPKIsyHlwpmDpRQREFqwEmFsCKHnHKVAbakBsuIAlWpaDHIYjVUKcaQMqysxFjtHqHZYSkekCzbEeKWcVSFdSabtHBJYVWbOgmPFuPZWBcCUmodqOaMxlISiHoNndqipoANtCtRnmvCfWrPSNYFrRhOejyZGrpRalnKZEcmarvJSAEEJNlkQLXaC"), true);
    this->pOcjsQfIbn(string("CpwREZudKCkgTNdoqGqGhzCQEZjjBGIXkiMGJixeDCpGLdJNmgKyWhgohtMNqRfMguEskgBNKwZkcIqnLmhRGerxCcpFXPlHLIjnfTtvaYrBuyLNYQpyNMPLhCrsymmMPAFbDyTtIktyWRtlKkmQyUlbbxhkBPKmuNgAkDIgvsTvgrfrTTRJoXquaLXNVYvjkzDLDnMtLnbOuZdzEvCHpthjCTBZwGN"), string("zSyobPoYSvkDBmYgVgCoZSyDQiCferh"), false);
    this->tkiDZqwApYZ(1570343863, string("QliRpahVkINuVJsZaIHUZyoiUDGNuLdhpmmQRMEpJUFCPajyIbLkZUwvNdwSzDUTUWJnjxSTrBtMVqtjcgGlLHWfgTJGMlftorzMVZmXbUkMApRRDtYHPpdAdpPbhmbGOHjjKfIiqCQjKIHZicNZKqueWOumdNSjbwYDJkjUPgQUUgmlhmDLnWKzZvZrfjdeamswIqNquOwzGmaZKN"), string("PHJRIrjgDERMDaxqcDacmzCJZIUItozSvqxyBzKRiQWpywunfDcVQoYzYHxDUOHqISXFDSMYKINPzBpMFnwLblnaLmctqFLgjAGzgLUTiuyvpegPukglKdALcpJgZbdIBUiJDZGiXZpYwWOlDEbMYpVzcrkAeIBCGkltTdsfjXgUlfOhBxvIgRECrAbeznKpXGzsJtYhqPtyQCnSUJgpAsMazwzLdNxyywzYsFpOGdikMPAYfFHSzo"), -119967.44249367528);
    this->xeudQsMv();
    this->QtKnmHC();
    this->JAtGlIjyFGBoU();
    this->CkyOILiSFyBzkLAR();
    this->uoYTVXFHJS(-674488.9194023006, string("cIPzOYurfEoYShdcijfbJdqAsNYFlymgFbwppajcuIERPfhpOiBLzkjlIsElwPGyTndZDMmUwCKoxncfgJUEbaDzAmsHruNumBEMWoMceqhYCxSSGwvGdpnOKHoomBZK"), false);
    this->vSVQMkjmCkNwAov(-1585059759);
    this->AqJXgXT(true, false, false, -18505.968295139734);
    this->qxEKvPhiT(true, string("uhTFstXnTfwsAoSpDIHqpjg"));
    this->oStmaFZrSKWEHE(-820507.3723604756, 837878.1693667797, -971885.9513262564, 2104103277, 213431790);
    this->kAAWvEtJIMlPA(false, false, -105161422, false, -479772.14036783326);
    this->PbOloBlRT(true, 978765642);
    this->AJDzDiIwJ(-344361.74054212956, 129013080, -1420389393, 292097200);
    this->AuwgzkbYRCIIZVJ(309982.2692382048);
    this->IyNMthmuCmwIgPE(352564277, true);
    this->YSQGgYSzqsTarN();
    this->rqKEbFDTZO(true, false, 942477.0682094696, string("rfdiUCQaBvSscUOTlSbpjtPSTdbDpqfxFrFMFeFpkHZavwtUqiyoTBdvoBkcwmFrCentXhjKHWmVxFQvxGUCBxKJCPs"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lVhXwmg
{
public:
    int eeBlnz;
    bool COMZUy;
    bool ZWmfLoieEtmgLbsT;

    lVhXwmg();
    bool IuDxnYwvN(string IiswzqpTGFIaOnbk, double onUJFVMSaJHKOv, bool wKCkZQpRsaMfi);
    void KiwFpvEmp(string TDkuaEVN, string efQuZNVaGZBJIG, double YHwsMvYGPXAap, int QAihYcUsbusvXMq, string HJelikSwzACxncn);
    string gCXgQZAAayumlDm(string arodpmGxsZamx, string NpyTYsMPsXkP, double WpTUaLpzPCDGsiK);
    string JuTGxcFNsn(string ZhLcYF);
    string hmIAhHmhQeggh();
    double WlCmduQQQkU(double WhXfkzevUI, double msPmXJPdy, string KntLOhFUDvH, string LrloNFPzrv, bool ovURkLmMaaRNGBGH);
    int pUaFp(double vOKysLiwoF);
protected:
    string VJZxVRXDl;
    bool bMaTDY;

    int ASgNtektdeVNXCAm(bool ycMNGVw, int XPspwXtuc, int oloGLoeUdScD, int SAWBAEIJOcc);
    int afVXcXygSQtf(bool SlKgSfYnKvyr, int GhqCQFEE, bool YDApSvDYCFU, string UbERdyJeU, bool svcQaEI);
private:
    int XVtBvgUqjDPoE;
    double yoilBIwRp;
    int riFXLxAQvFXmr;
    double vxmypvTpIpNAJaPN;
    string AbRVohGkh;

    double vsGnkqQJya(double IviwQ, int HgIlBUB, double FaiAIMSvjW, bool Airne);
    bool luoGrRVBSeoRI(int iyLibARnt, bool VALIvLajyPjBmJ, bool bJrOACMrMTzHkbN, bool JPNbnbqkyjY, double JDiKKYRxh);
    void YFWHrlWhlqrTMUbI(double MzRKCIlpGFrYk, bool VQzYXkYSrM);
};

bool lVhXwmg::IuDxnYwvN(string IiswzqpTGFIaOnbk, double onUJFVMSaJHKOv, bool wKCkZQpRsaMfi)
{
    double lWFpalgFVXyXXfYz = -132840.84931822482;
    string NbgJxbo = string("bzcnhcZBhgiDuGzJtgmcLfkxQLDYgmSHdoLXLrDANUOOdqGcwWUFhIEWiOICwzEeWGuxRPEawyuFxOVOMVJmTQjTbTRYysdxljqwteeYnMDtCZxEURNSxzdKVqCEhjjlkVSirRhxvYhAqpHEdwTXJGMdrwsOKRGtd");

    if (onUJFVMSaJHKOv <= -757740.6932722646) {
        for (int QalKBnLqCoRtUb = 450579601; QalKBnLqCoRtUb > 0; QalKBnLqCoRtUb--) {
            lWFpalgFVXyXXfYz += onUJFVMSaJHKOv;
            IiswzqpTGFIaOnbk = IiswzqpTGFIaOnbk;
            onUJFVMSaJHKOv -= onUJFVMSaJHKOv;
        }
    }

    for (int uuuQhwWOUQtuRUqw = 517094032; uuuQhwWOUQtuRUqw > 0; uuuQhwWOUQtuRUqw--) {
        continue;
    }

    for (int LDEINOkMKEKOCKdj = 404138647; LDEINOkMKEKOCKdj > 0; LDEINOkMKEKOCKdj--) {
        wKCkZQpRsaMfi = ! wKCkZQpRsaMfi;
    }

    if (lWFpalgFVXyXXfYz > -757740.6932722646) {
        for (int GJXLREFCqSMkUbG = 1134007156; GJXLREFCqSMkUbG > 0; GJXLREFCqSMkUbG--) {
            lWFpalgFVXyXXfYz += onUJFVMSaJHKOv;
            onUJFVMSaJHKOv = onUJFVMSaJHKOv;
        }
    }

    for (int NQfyoT = 1609248708; NQfyoT > 0; NQfyoT--) {
        NbgJxbo += NbgJxbo;
        NbgJxbo += IiswzqpTGFIaOnbk;
        IiswzqpTGFIaOnbk += IiswzqpTGFIaOnbk;
        onUJFVMSaJHKOv = onUJFVMSaJHKOv;
        onUJFVMSaJHKOv += lWFpalgFVXyXXfYz;
        onUJFVMSaJHKOv *= lWFpalgFVXyXXfYz;
        NbgJxbo = NbgJxbo;
    }

    for (int pFvMjSKqaM = 59296785; pFvMjSKqaM > 0; pFvMjSKqaM--) {
        NbgJxbo += NbgJxbo;
        IiswzqpTGFIaOnbk = IiswzqpTGFIaOnbk;
        lWFpalgFVXyXXfYz *= onUJFVMSaJHKOv;
    }

    return wKCkZQpRsaMfi;
}

void lVhXwmg::KiwFpvEmp(string TDkuaEVN, string efQuZNVaGZBJIG, double YHwsMvYGPXAap, int QAihYcUsbusvXMq, string HJelikSwzACxncn)
{
    string xFBdWYAIb = string("UlRtwyEcmgYhuFradQcCDIkCfIRbaZaQzBNpaeAZnCXoWeCrJdEnPPraAuWUPTGZKBUEdygULyQdMfkLVAzjyFYKMAXmjFAAPvkEpyKPdhciVCBCcucvpqtLexlITBqqxCdhzFiaQWGqhTRJDlGLxBD");
    string cxHZbo = string("CMjocaoJWmrSopsEdBmMAQQ");
    string ynhkbY = string("MUiaMLXzIIlDGsENAyaFIAFuvZMMmfJQPpPyYLPfArqaALRfUulnDSrsOBCVhSJZMXKDsbrEiVfrvbjyYPLarclOhdYxVklBIVLSpxQFetOXVqTOtwNvWNOGwSvwiLcNxCuARlBvDoRABvpbedeIKllzeTHMrSqcExNRQdACUIUnxSOpOIbZXVECRAFxwwUuoxfWXIHIzXNWteZmPaEOVzyGVKIYMRKZKBrstjC");
    bool SBLBKQlwXwLOUQ = false;
    double XlvXLwoxzTfUYrN = 969049.2641145324;
    bool OCJqulDO = false;
    bool tXkzzFamvM = false;
    double mJFDrDwI = -159841.09935014628;
    string CxCkoeMTWV = string("kEhgGcbUbfwHVpM");
    int ntfTOMjrouyvsmZ = -1665011368;

    for (int UdezCNSjQels = 1211734814; UdezCNSjQels > 0; UdezCNSjQels--) {
        efQuZNVaGZBJIG = TDkuaEVN;
    }
}

string lVhXwmg::gCXgQZAAayumlDm(string arodpmGxsZamx, string NpyTYsMPsXkP, double WpTUaLpzPCDGsiK)
{
    int reyJMCrNvq = 848085360;
    bool dyxCkpkpVuaibCmx = true;
    bool cRoXgOioDkbutU = true;
    bool JitmznJroBXZmTdr = false;
    bool zKLNhrcYxEAUc = true;
    bool EraDuIKPcu = true;
    string WymsMgKCSEbSRqn = string("tYdarsMuPPSTmysGkOnzsGMXxIyZDbFtgnGbbRdbdrWJUSSCFhJgLmcfNzMwHDuPHQexYBIbcgRVsmEaBAHZlgpsAwpuASlBLDGjPbrekrXaTwnAgXuJIvbdHDUsNQfYOPNmTIglfqyfqyVzJvmfywNpdCwifVYrutsMOjyfRGlMgMjFUIkHUIyxEiDCMWEVyEXpJpAckHeOcchXrpOajWHSecStgwWotspxHjreZhDvnYXhXwMkRq");
    bool UyxfKN = false;
    string fdRTHsvAzYslF = string("fFjIeEzzvsHpuTWuCDoICCfJmiDloNUwXZ");

    for (int VGaJTwxRg = 30786463; VGaJTwxRg > 0; VGaJTwxRg--) {
        continue;
    }

    for (int ZdvACvmpoLJV = 1720708868; ZdvACvmpoLJV > 0; ZdvACvmpoLJV--) {
        WymsMgKCSEbSRqn += WymsMgKCSEbSRqn;
        EraDuIKPcu = ! cRoXgOioDkbutU;
    }

    for (int MSFmmXjFzsXeDPy = 1314987082; MSFmmXjFzsXeDPy > 0; MSFmmXjFzsXeDPy--) {
        fdRTHsvAzYslF += WymsMgKCSEbSRqn;
        cRoXgOioDkbutU = dyxCkpkpVuaibCmx;
    }

    return fdRTHsvAzYslF;
}

string lVhXwmg::JuTGxcFNsn(string ZhLcYF)
{
    double wzUxnPhFVwFHi = 279522.82970241935;
    int FToVn = 1268991600;
    int mgdvSalUwAgHrUB = 31894445;
    string dgikzoASAjJDpFYe = string("jtUTuaSuFODGcSoTKQdBaeuyNjmeqGfXWIxzksoNthbiHUPffnMrCfVSSfjAkGILwlZlYKEfOsqqHrGjNKLgdYllijGrdXdY");
    double RRYYwqHm = -754503.64703799;

    if (dgikzoASAjJDpFYe <= string("jtUTuaSuFODGcSoTKQdBaeuyNjmeqGfXWIxzksoNthbiHUPffnMrCfVSSfjAkGILwlZlYKEfOsqqHrGjNKLgdYllijGrdXdY")) {
        for (int tuVPZUR = 1151734783; tuVPZUR > 0; tuVPZUR--) {
            dgikzoASAjJDpFYe += dgikzoASAjJDpFYe;
            RRYYwqHm = RRYYwqHm;
            dgikzoASAjJDpFYe += dgikzoASAjJDpFYe;
            RRYYwqHm *= wzUxnPhFVwFHi;
        }
    }

    return dgikzoASAjJDpFYe;
}

string lVhXwmg::hmIAhHmhQeggh()
{
    bool YKDhzgbIijtP = true;
    int nWaydtWqh = -337115030;
    double cYPVhAcxigGUnLBw = 774433.6577795764;
    int ayQcrlkIgjdlCh = -1012431257;
    double nbowlZgpqrMtI = 788922.1089320973;
    double PfnZCaQyNWcIBJ = 838137.8627572466;

    return string("FNAUAsupeOhksJvxMVptSMrZXClBVLHBrzQYhmWYgiLlYljvsDzSUISqUDhbTGixdrvbgyLFdpXvBEAjBmORaliDJhrmGOXNuEWBgXCeUapYDpplRBXxcpxkcsDiRXDfVfWacHtnNdBXzgljuPbmEsoIaROG");
}

double lVhXwmg::WlCmduQQQkU(double WhXfkzevUI, double msPmXJPdy, string KntLOhFUDvH, string LrloNFPzrv, bool ovURkLmMaaRNGBGH)
{
    int IjCMbFzNE = 361155833;
    int DuImDLdgnHHITdB = 1011704520;
    string ldTAbNtx = string("ZTYBKJurtVndLYUCdZdloUvQmxXcLGTVYkxiIorpZKhJrFozLYrxSvmfAFCtfDWidTYCmamEoepNAjqPkQuru");
    int QhRHftvQJZiMJotQ = 907390106;
    int LJKVk = 511620757;

    if (ldTAbNtx <= string("viSTAnfHFgQxINbDqKwovhlzemnESneVtTPpNOGKqLxXMvKXUYCpHXxWIohdpMBiNBlsqOvwgBdGRVmrHEpOLATXK")) {
        for (int QdLuC = 487610915; QdLuC > 0; QdLuC--) {
            continue;
        }
    }

    for (int xKLoXCwMzzsv = 2090784230; xKLoXCwMzzsv > 0; xKLoXCwMzzsv--) {
        continue;
    }

    if (ldTAbNtx <= string("KnxIajqbZEXBdDEUaxZCnOMTtRZucPlWCibmMOLIGcFOHOwfVbkffLUyYwLrDvMuAkWtwfIjEPFaKKvJNiZBwvDgYjwSiTOLLKcxTvZujnXXCHbzLyHuoawKTYgsHAGGhzaHeDckIlKjhtirZJepaRpH")) {
        for (int mRBEUwHHHTSf = 575039403; mRBEUwHHHTSf > 0; mRBEUwHHHTSf--) {
            DuImDLdgnHHITdB -= LJKVk;
            LrloNFPzrv += KntLOhFUDvH;
        }
    }

    return msPmXJPdy;
}

int lVhXwmg::pUaFp(double vOKysLiwoF)
{
    bool SOOknJXeKPLty = true;
    int UrLDxaBPCtYLLayX = -1493065597;

    for (int tOXzTAmNXe = 1043879566; tOXzTAmNXe > 0; tOXzTAmNXe--) {
        continue;
    }

    for (int yJuDupMYvER = 1043768557; yJuDupMYvER > 0; yJuDupMYvER--) {
        UrLDxaBPCtYLLayX -= UrLDxaBPCtYLLayX;
        vOKysLiwoF += vOKysLiwoF;
    }

    for (int eDjpfE = 1951369976; eDjpfE > 0; eDjpfE--) {
        UrLDxaBPCtYLLayX += UrLDxaBPCtYLLayX;
    }

    for (int nyIwHuYtcdBZ = 1533212040; nyIwHuYtcdBZ > 0; nyIwHuYtcdBZ--) {
        vOKysLiwoF = vOKysLiwoF;
    }

    if (vOKysLiwoF >= -622436.0543671247) {
        for (int UqQyV = 2025601634; UqQyV > 0; UqQyV--) {
            vOKysLiwoF /= vOKysLiwoF;
            SOOknJXeKPLty = SOOknJXeKPLty;
        }
    }

    return UrLDxaBPCtYLLayX;
}

int lVhXwmg::ASgNtektdeVNXCAm(bool ycMNGVw, int XPspwXtuc, int oloGLoeUdScD, int SAWBAEIJOcc)
{
    double OCLJXfkJmPIYasI = -59455.56562110575;
    int zgQHkyTTVVGZFl = 1216800111;
    bool eppPXPfReOOH = false;
    double mjJlMyVjvmi = -217532.7243795439;

    for (int oVVGevREqq = 884945769; oVVGevREqq > 0; oVVGevREqq--) {
        OCLJXfkJmPIYasI /= OCLJXfkJmPIYasI;
        SAWBAEIJOcc /= XPspwXtuc;
        ycMNGVw = ! eppPXPfReOOH;
        SAWBAEIJOcc *= zgQHkyTTVVGZFl;
        oloGLoeUdScD += oloGLoeUdScD;
    }

    for (int JCAnYKzIU = 325209066; JCAnYKzIU > 0; JCAnYKzIU--) {
        SAWBAEIJOcc = oloGLoeUdScD;
    }

    if (SAWBAEIJOcc != 1216800111) {
        for (int LFydwLfdp = 86357461; LFydwLfdp > 0; LFydwLfdp--) {
            oloGLoeUdScD -= XPspwXtuc;
            SAWBAEIJOcc += SAWBAEIJOcc;
            oloGLoeUdScD += zgQHkyTTVVGZFl;
        }
    }

    return zgQHkyTTVVGZFl;
}

int lVhXwmg::afVXcXygSQtf(bool SlKgSfYnKvyr, int GhqCQFEE, bool YDApSvDYCFU, string UbERdyJeU, bool svcQaEI)
{
    bool YnrUR = true;
    double aweFTRPSv = -974145.3070268169;
    bool QYFOFyVKwyCy = false;

    for (int mOkOh = 1062819519; mOkOh > 0; mOkOh--) {
        svcQaEI = YDApSvDYCFU;
        UbERdyJeU += UbERdyJeU;
    }

    return GhqCQFEE;
}

double lVhXwmg::vsGnkqQJya(double IviwQ, int HgIlBUB, double FaiAIMSvjW, bool Airne)
{
    string jniLzZq = string("gXxcwCyZKiNgnHCULwNBvIiRSUiXclBkawOOWjdLj");
    bool RKZjALFJMPAaw = false;
    string qXUKO = string("yiXwcUxrqLmHiBafOYKbOtyRvlUaFJgdBuRiiEyFFlmcfCPGwJptvIJvwMNvSxJeoWINWLuhbMvFrySohFMfqzviIxEuxRuIUtOhdYEeYfaJkCPJJwzswEZMniZZlaLwXXFmGYKXmYAYZCEaRAzLmSbZhtCLiLQCrrvPdKzclyamFqRbMWbvfiLoVcArybmNCXIwbhyo");
    int KZsFUFfxbgOdZZi = -2112877633;
    double uclEfFInNgnYqUCx = 975096.9894062626;
    string KDGDEEPHPKgbqz = string("fBofCvgqSUVDIuSJwleolIBelmdsiikpfpZrHAOHkNWcdHeCPXqmQyxPHIJGjSonxLKFjiErLgbFBKLFpRXUzKQXICKXtxOHQnOAFNqcWoMhntDdjDscUHJtCEjKOux");
    bool poQBzNkJr = true;

    for (int yfIItMZKzqal = 601838666; yfIItMZKzqal > 0; yfIItMZKzqal--) {
        uclEfFInNgnYqUCx = FaiAIMSvjW;
        KDGDEEPHPKgbqz += jniLzZq;
        RKZjALFJMPAaw = Airne;
        jniLzZq += qXUKO;
    }

    for (int qLRAjvnGxdDjlns = 1290629806; qLRAjvnGxdDjlns > 0; qLRAjvnGxdDjlns--) {
        jniLzZq = KDGDEEPHPKgbqz;
        RKZjALFJMPAaw = Airne;
        uclEfFInNgnYqUCx += uclEfFInNgnYqUCx;
    }

    return uclEfFInNgnYqUCx;
}

bool lVhXwmg::luoGrRVBSeoRI(int iyLibARnt, bool VALIvLajyPjBmJ, bool bJrOACMrMTzHkbN, bool JPNbnbqkyjY, double JDiKKYRxh)
{
    double rqIxTsX = -636778.2004123117;
    double WXgccvzakFNLn = -96726.91379023451;
    string zJWzaViRw = string("uGVHAGCHTvmHHMeZGyRaQdhzdnmZgkxoAbxFhUKXwkjXJwRgNNDCen");
    bool gKTbj = true;
    string UEALnyJt = string("HjwaTqzDEtxUkYuXauTKGpBvBLoeiJYMMxglzbhhfKSvisdACRNCYrKWLaORkdPPAwYFJNnjswMBZRQtidXNpmpaeeqBqjjyntpIlnYgRdikJMDwzbvWVLMbOhLAfOJGMNmlyvXqAXxvNRBECgPESwBiuvZbJYUrVqkIHOwKBFaBjvFcuTftSreJnvoRAPtlPVQuaIKUNeGwzZMJdaYPgrLTwcKQdQbCAzgDlLJNPYApoRPxcfwrr");

    for (int DaaNs = 215432935; DaaNs > 0; DaaNs--) {
        UEALnyJt += UEALnyJt;
        JDiKKYRxh += rqIxTsX;
        JDiKKYRxh += WXgccvzakFNLn;
    }

    return gKTbj;
}

void lVhXwmg::YFWHrlWhlqrTMUbI(double MzRKCIlpGFrYk, bool VQzYXkYSrM)
{
    string ecEIiOi = string("NpzHpkNbQtESzSLvdchsFSOjZrCHGikmKyCNoXtOIDCtGqwhGBGtilECvowMZfUxGNrqOAPOohbtoFEuzfyVWJFSLDhcpJJcHDBsVmcPJxwibtpcT");
    bool EMEVpxbmzaZwJYV = false;
}

lVhXwmg::lVhXwmg()
{
    this->IuDxnYwvN(string("kSHCOLJEIxLYxSQRjatsHQazRvceqPNDtonIQnCDveGAbEqXJbqNoJlnYobiFPTrmkLcVWBqtpfgBLIARFskEJRWaCJtwgqFDWIDsVwjUGjYtDUwtNEnHwtyiIxwNkCIsUQxoQfnX"), -757740.6932722646, true);
    this->KiwFpvEmp(string("jCxofucLQMGxNjuQTiCPZfcXApvzYtMYihJryeMAGsgDbYlBEJaofDzowjDheByuyKJPxytPRoBryzetnRUhduueLytLfTCFzrufmoAjsNeOPCAbAXisvPuzTKdSeRLDafiUTOsyWkPVXkezStvtONkoMDWeqTfyGIiPtfGymSihSSIsSZEWfDLAxODMBWwosPY"), string("hLDChMLpnHMykLISsufNbiunyiVJjJFdoftIUcAcZPBcUzdkpzhqMSivlfeeJGrPZNemyBuDHwrt"), 896563.2430978509, -930265608, string("qXjbWvYuixcOpoFDyhOJgNXHWOCEhZjhNCUDTsQEOWPLSexfBhv"));
    this->gCXgQZAAayumlDm(string("SfCgJtgtgTCdnKXvHdOEocsOSRCJRTQIuTjWTzjxHdYpSGgd"), string("FgFNyKtEcJZVczBwedrjQdbmuXPIHOYeDneZzjXoOFELswEh"), -285433.62999483827);
    this->JuTGxcFNsn(string("zXyCkdyKixRcSkXwmQYQVjuMcnIoGUPKzxQdysiZRwelmSTnJkJSmKkMwvQEgvAhSWluYaLrxluaFTRdGriSXwaSYPtNTScAnkZXkmjfjjfmfDlMgljqSkGaip"));
    this->hmIAhHmhQeggh();
    this->WlCmduQQQkU(314240.53962141724, -1043481.847276539, string("KnxIajqbZEXBdDEUaxZCnOMTtRZucPlWCibmMOLIGcFOHOwfVbkffLUyYwLrDvMuAkWtwfIjEPFaKKvJNiZBwvDgYjwSiTOLLKcxTvZujnXXCHbzLyHuoawKTYgsHAGGhzaHeDckIlKjhtirZJepaRpH"), string("viSTAnfHFgQxINbDqKwovhlzemnESneVtTPpNOGKqLxXMvKXUYCpHXxWIohdpMBiNBlsqOvwgBdGRVmrHEpOLATXK"), true);
    this->pUaFp(-622436.0543671247);
    this->ASgNtektdeVNXCAm(true, -1271747917, 695639510, 877157919);
    this->afVXcXygSQtf(true, 1816124194, false, string("SlAHfKRYxiiQeKSvtNpPLLONyVEasvEakLEATNavyHojbzFBoJrdpEYzRPnkPMFaQFualLwfhbqCrhmdMwuVsVARSUKowcbKsJnaSPIZWSoCMaGToGQDsWKWDpIGGo"), true);
    this->vsGnkqQJya(-898730.5287974116, -922233511, -333014.9819969093, false);
    this->luoGrRVBSeoRI(-2012268110, false, false, false, 941503.3578344283);
    this->YFWHrlWhlqrTMUbI(-346268.35732169595, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nZaOuqhi
{
public:
    int iTnwQ;

    nZaOuqhi();
protected:
    int eiWYibpYeUMHXR;
    double vyCpkYur;
    string MAkzvst;
    bool eZKkghd;
    bool bpzUN;
    bool lYNBlfZsDLjv;

    bool VFQBrp(int gzNkGOgdIzwa, int UOrITQIm);
    double HnZGlcfiRVullyQ(double ruBxpBizyjTj, bool PedlSzcJ, double SWdYsEZHkXbjlT);
    int zQUbxizO(int RpaNediprxDi, int kMnnzH, double IDvGhRZ, double uCDxl);
    void YaAldyfbRoPdb(bool JmQwtpx, string RzauLEQvMgcOV, string IKCdZ);
    bool EhKeTX(int qfIqghqJKjgLQ, string eVIGsVE, double BOUyXWM, string mPOLfCxbIWx, double yJsSYTIAACm);
private:
    int CgJQrodJTAXcV;
    int ZwdPrhUwDsTyI;

    int coOooZadg();
    string wzXprpM(bool XTClfUrMomQmQasE, string bOOkStC);
    string CRwapw(double TzYqKgPBJSpbMi, int RpQYJxIO, string zkfOtAkIO, double VNQFD);
    string rTwsnCDmT(int mTREY, int YPRoRV, int TTcmmzXExqWCsEnP, int VMVOPdkBpITaNeFk);
    void UqkrGPOI(double zqhskxPhE, double pzvsMUnpYZwQR, int mhOnnTQdZ);
    void YBGgj();
};

bool nZaOuqhi::VFQBrp(int gzNkGOgdIzwa, int UOrITQIm)
{
    double JqthGvQosWp = 620729.3610298823;
    double KGjJoUaCVez = 78771.04005704478;
    bool sEuIpx = true;
    string JDiQjhoJleuggNk = string("RPVNmGrzLdnrmVLo");
    double RJCDPBbo = 79592.91142268847;
    string ZoORzJcMbMD = string("MoiZOMCgjmwIkQrJfyLjnejPBdILCDSefajUSjUzchoaYxLTDfGuaKCpDaaqnPMHWpTYhQIgKbuzuCXAjCLFXuSezagUlIwXVTIquZHQpVhkeQJqsjbuUIeUsMELRzxZfocAtuWwJbIUrvcXFoMfKoepcVivLNsWjUFKdjVeqKJLqbhDWCQGQYebfYcvoayBayedcbgFOHhISkIvpOItsoilzwMmtPijVFBKeZ");

    for (int iTLcTGEqJS = 120123202; iTLcTGEqJS > 0; iTLcTGEqJS--) {
        continue;
    }

    for (int dkJwmC = 970728640; dkJwmC > 0; dkJwmC--) {
        KGjJoUaCVez = RJCDPBbo;
    }

    return sEuIpx;
}

double nZaOuqhi::HnZGlcfiRVullyQ(double ruBxpBizyjTj, bool PedlSzcJ, double SWdYsEZHkXbjlT)
{
    double ftQygZc = -1026319.802598056;
    string BLHiKBLSr = string("jUIwMYHovEXDsnGcOGaeMWdSKApilsIutgnFCbtLNtRkXXSgNKCMBYSAfMdNSNRsfjgMVfvlnUzebRUhYirPznWUCzxsHlheRp");
    int bFgDKamrbsoPbB = -588317325;
    string xRYcwLBBgad = string("dhFRojXOPQNnzXxxGJSLuuxkngWpWvNBKxMylwbaFbGhKvOeKFHiLLyKPsfEMbAEAUBlBFQhkknEtaoSblHATEXAqTKymRrhZIBTEcHWuTKYavCgVtAiarALmMkaxCfMRpwfzDnwVioRkglwnZiCBSxpDUDLGWpdKQhOSmscyDJFcumpDOTFvTXqTerHPKszPhNTJxPbJEfTdhJ");

    if (PedlSzcJ != true) {
        for (int VoFsnQj = 1518709197; VoFsnQj > 0; VoFsnQj--) {
            continue;
        }
    }

    return ftQygZc;
}

int nZaOuqhi::zQUbxizO(int RpaNediprxDi, int kMnnzH, double IDvGhRZ, double uCDxl)
{
    string HndXhuDGkrQH = string("WnUBDekeYWxLvHUafjoSqVLfmGZpUAfGRqywMvReOXjciTeLvaQBszOtSNiTXeFjMOuYnzlNgZJGRirhXlckVvWGIEADhlPhWwcYXvsdjpgbStIbvVmwSUTmOyaJqklWzlHYVatYVLj");
    double OWSbVXThmPq = 110434.89806235592;
    int GLCkyIvdxj = 1158813716;
    string Duzvu = string("guLBZbgHNaBvKCOXuSMJaKrsolVXmBdrYcEOgCHlYycheIyldWQuSWVICqgNXVfIaZhshlwNvzbSCWmLBDQOJXGaOVefqtdzFtmynzFTfXIBYHdIpVEPjtvZjOumCsnOrQobueWYqXtyGnImjmXmbgpvyqjACaFkATpDkyZQYDHduPBNNslvOftPpQcFvXJxlagV");
    bool UtwkoXzNsVdb = false;
    bool HGzUzm = true;
    bool IDqOzfNBo = false;
    string vAwKaTPfeIGHi = string("MbOBguGPNXQxDhazQGnCVnHmkCLiGIBernFumriFcuvUNcaALQtiFLtHJjYStXsMVmCBMkrfutmvYQuySqYYKoLtHcPtCwtReVAzEQHySGSBpowdWcnfhitncjWDksiNWYNgHvpXYgNLIJAvCIMCehERxoUmxTCXos");
    double ZKOnKKLaRIXXSkhF = 815004.4737038519;
    int uqYEfOcb = 1252386609;

    if (IDqOzfNBo != false) {
        for (int ibwwgpGQwEUwZDhd = 1361660372; ibwwgpGQwEUwZDhd > 0; ibwwgpGQwEUwZDhd--) {
            IDqOzfNBo = UtwkoXzNsVdb;
            OWSbVXThmPq *= IDvGhRZ;
        }
    }

    for (int RQvANwwi = 329047676; RQvANwwi > 0; RQvANwwi--) {
        RpaNediprxDi -= uqYEfOcb;
    }

    for (int fJecITNjdEhn = 1746410256; fJecITNjdEhn > 0; fJecITNjdEhn--) {
        uCDxl /= OWSbVXThmPq;
    }

    for (int GSpguxRXn = 2095960236; GSpguxRXn > 0; GSpguxRXn--) {
        continue;
    }

    for (int lOYpIbpZAW = 573923081; lOYpIbpZAW > 0; lOYpIbpZAW--) {
        continue;
    }

    return uqYEfOcb;
}

void nZaOuqhi::YaAldyfbRoPdb(bool JmQwtpx, string RzauLEQvMgcOV, string IKCdZ)
{
    string djPQoNQvwMljCuqJ = string("pfHoLQhkPbhncAFpYCeeenVwDfedrEoVxejePJHMpEFyHSZNwQeOzkhnoSHVPNhpRjTZZzZliFaPadPrYoktvIHMiSCjgQnUVDCiruLJAAoQlYdiNtZmpcXCojQKwurmOICPqCkitcMasfVEgxwVcHCYGIPSwuHplRQGStPZtij");
    bool tRDMoFDywPRej = true;
    bool OqljDhFruG = false;
    bool MYQkj = false;
    double qKDwl = 238595.3290006287;
    double mgPOhhxOKw = -650749.1529371112;

    for (int XBmKmpfTIDlIZif = 827606858; XBmKmpfTIDlIZif > 0; XBmKmpfTIDlIZif--) {
        continue;
    }

    if (djPQoNQvwMljCuqJ <= string("pfHoLQhkPbhncAFpYCeeenVwDfedrEoVxejePJHMpEFyHSZNwQeOzkhnoSHVPNhpRjTZZzZliFaPadPrYoktvIHMiSCjgQnUVDCiruLJAAoQlYdiNtZmpcXCojQKwurmOICPqCkitcMasfVEgxwVcHCYGIPSwuHplRQGStPZtij")) {
        for (int XKPLe = 1121589711; XKPLe > 0; XKPLe--) {
            qKDwl = qKDwl;
            IKCdZ += RzauLEQvMgcOV;
            JmQwtpx = JmQwtpx;
            IKCdZ += IKCdZ;
        }
    }

    for (int PBbIFeZhsS = 1227968761; PBbIFeZhsS > 0; PBbIFeZhsS--) {
        continue;
    }
}

bool nZaOuqhi::EhKeTX(int qfIqghqJKjgLQ, string eVIGsVE, double BOUyXWM, string mPOLfCxbIWx, double yJsSYTIAACm)
{
    string grKnLe = string("ntcLIeITPtkbIvMFqqjrqetMREkcDlNgYxLBXxgiqCqRCUXDKsNKIEDiAXhEDTqpJCiNiJgkqmBZRkPqXHeqqgMOEBVHacKGLJXzPZcATPtySqvERRcqzXkrteqZiPIVsIlXmNekXzeztCMZNZMonTAcFraTZMjYJAlddUcNJvpxqEWAydHegQRghxaDwkQeJICDxvDvJoJLDnZwdDEzHTRG");

    for (int CSwmWfmqKMjHn = 617923392; CSwmWfmqKMjHn > 0; CSwmWfmqKMjHn--) {
        mPOLfCxbIWx += eVIGsVE;
        grKnLe += eVIGsVE;
        grKnLe = mPOLfCxbIWx;
        yJsSYTIAACm -= yJsSYTIAACm;
        eVIGsVE = eVIGsVE;
        grKnLe += mPOLfCxbIWx;
    }

    for (int CHBAzkhv = 1856996267; CHBAzkhv > 0; CHBAzkhv--) {
        BOUyXWM /= BOUyXWM;
    }

    return true;
}

int nZaOuqhi::coOooZadg()
{
    int RMvvngM = 1419496755;
    string XyuNHlAyPrAr = string("qIWoBDSaAcQqQQzUwkBLfLWwzkWIVGfTtdSKYRhYsrxGATIRqirXOxAEKibVsusTFYpvKeDblKWOJPVaOKlITzAYAMsnpOnPGBMjkDHsaitNlaHSNBEDNMRdSzhXRxtzKBUGTEgovFZNLTGxIFKMGTrzEZhxGLkoBtevOJKJXFzhoEkpivXgQkeAjDBy");

    if (XyuNHlAyPrAr >= string("qIWoBDSaAcQqQQzUwkBLfLWwzkWIVGfTtdSKYRhYsrxGATIRqirXOxAEKibVsusTFYpvKeDblKWOJPVaOKlITzAYAMsnpOnPGBMjkDHsaitNlaHSNBEDNMRdSzhXRxtzKBUGTEgovFZNLTGxIFKMGTrzEZhxGLkoBtevOJKJXFzhoEkpivXgQkeAjDBy")) {
        for (int vFCSno = 188442530; vFCSno > 0; vFCSno--) {
            RMvvngM *= RMvvngM;
            XyuNHlAyPrAr += XyuNHlAyPrAr;
            XyuNHlAyPrAr = XyuNHlAyPrAr;
            RMvvngM /= RMvvngM;
            RMvvngM -= RMvvngM;
            XyuNHlAyPrAr = XyuNHlAyPrAr;
        }
    }

    if (RMvvngM < 1419496755) {
        for (int bqsgdOnItWsmega = 1726849444; bqsgdOnItWsmega > 0; bqsgdOnItWsmega--) {
            RMvvngM *= RMvvngM;
            RMvvngM /= RMvvngM;
            XyuNHlAyPrAr = XyuNHlAyPrAr;
        }
    }

    if (RMvvngM >= 1419496755) {
        for (int SWJITsj = 1750309480; SWJITsj > 0; SWJITsj--) {
            RMvvngM -= RMvvngM;
        }
    }

    return RMvvngM;
}

string nZaOuqhi::wzXprpM(bool XTClfUrMomQmQasE, string bOOkStC)
{
    double eHwhvCTqvUuIH = -549836.6238459178;
    double hczfPR = 543898.5408357151;
    bool lhVjDykXxejY = false;
    string CezDfLaIB = string("KXTcOunILDilPcAlkkNQcogfKFSxFIEpBJhJtfSubrZMCnkpVOrlitJlUSzMz");
    bool akoNp = false;
    int uZCpQMzlEVlZupGy = 1637135903;
    int PVfATkwx = 753471717;

    if (hczfPR > 543898.5408357151) {
        for (int bLKgzhbwLtwUOyd = 1471175393; bLKgzhbwLtwUOyd > 0; bLKgzhbwLtwUOyd--) {
            lhVjDykXxejY = ! XTClfUrMomQmQasE;
            CezDfLaIB += bOOkStC;
        }
    }

    for (int flrzptkODWuGFtq = 164861540; flrzptkODWuGFtq > 0; flrzptkODWuGFtq--) {
        PVfATkwx -= uZCpQMzlEVlZupGy;
    }

    return CezDfLaIB;
}

string nZaOuqhi::CRwapw(double TzYqKgPBJSpbMi, int RpQYJxIO, string zkfOtAkIO, double VNQFD)
{
    bool OaFDVqDwU = true;
    double HQlVCNlyRl = 914909.8741871224;
    int qhaDiTy = -1338205850;

    if (RpQYJxIO == -1707493893) {
        for (int wQIdaabRqR = 501562597; wQIdaabRqR > 0; wQIdaabRqR--) {
            TzYqKgPBJSpbMi *= HQlVCNlyRl;
        }
    }

    for (int MYMMZKAMwCMjCpGR = 626585930; MYMMZKAMwCMjCpGR > 0; MYMMZKAMwCMjCpGR--) {
        VNQFD -= VNQFD;
        HQlVCNlyRl *= HQlVCNlyRl;
    }

    for (int oByaCNEvpoEvL = 643363696; oByaCNEvpoEvL > 0; oByaCNEvpoEvL--) {
        RpQYJxIO *= RpQYJxIO;
    }

    for (int VnGuiNQ = 1613073808; VnGuiNQ > 0; VnGuiNQ--) {
        HQlVCNlyRl += HQlVCNlyRl;
    }

    return zkfOtAkIO;
}

string nZaOuqhi::rTwsnCDmT(int mTREY, int YPRoRV, int TTcmmzXExqWCsEnP, int VMVOPdkBpITaNeFk)
{
    string qNRppYmyhOuxYhi = string("HkSMhNSedysUexEIVybZvBwNUcuQynhbuDEphvnAsmdNVLgXCWDppvjgtzCEAubQLLnetNCdlzzPMdNSTPFlNaWQLfWdLqpxAnczrcxAkXweyZj");
    int XpgnRY = 2072854306;
    int gyfaiuTqqY = 190399602;
    bool UmPxAdycrRfIynu = false;
    int yPMYAUnaahthsWDb = -1274864438;
    int ujGizrGsdtstnbvg = -584952163;

    return qNRppYmyhOuxYhi;
}

void nZaOuqhi::UqkrGPOI(double zqhskxPhE, double pzvsMUnpYZwQR, int mhOnnTQdZ)
{
    bool YvUCwRSzPnHFNPI = false;
    int uDDOpmXAaBSfJL = -1932999399;
    bool kJbTFvOa = false;
    bool TQxiMAiImzlIAL = false;
    int grybRSCDl = 375766565;
    double CxgRaWW = 603729.234564367;
    string yqYFHVXkg = string("InVuoZaHbIlQqgvkGyxmckueegpARTnCZZniEbWOmaSWqTiMrEFYQHUHnLQnLuBjaxhbTIIiwvNVlkYBWzHUvOLkecUNyNWaYbDFzxjhKJSMzXGaEPfusTRlXBLfpkIOtUnTNCvrylUkGnQBiJbiCFGfUeONLfYcoLNyhWipZJBolteeVVuzSxJ");
    double NgbCpIGhUwAtYGcJ = 683548.5460131055;
}

void nZaOuqhi::YBGgj()
{
    string reZevXzsP = string("ZDwEkoHAZBmWNejMgWPpTlTISfjHqhxAseZLmORxHCaFSgTqQEAhiZgvpyQfDxUsWfIgORyRWTTspyblHkqZoIDYvkLJXEiqmBvMRlFamkAYKNDbnLlovJ");
    double ImpfNkTe = 482453.1191618211;
    bool vyGHEvcQ = true;
    int vCHznRDG = -111267955;
    int jeqyGHlWCUjj = -1681490053;

    for (int AzzWECRHiOR = 1679462900; AzzWECRHiOR > 0; AzzWECRHiOR--) {
        jeqyGHlWCUjj *= vCHznRDG;
        jeqyGHlWCUjj += jeqyGHlWCUjj;
    }

    if (reZevXzsP <= string("ZDwEkoHAZBmWNejMgWPpTlTISfjHqhxAseZLmORxHCaFSgTqQEAhiZgvpyQfDxUsWfIgORyRWTTspyblHkqZoIDYvkLJXEiqmBvMRlFamkAYKNDbnLlovJ")) {
        for (int WfteUwnqHLLyy = 1723881903; WfteUwnqHLLyy > 0; WfteUwnqHLLyy--) {
            jeqyGHlWCUjj = vCHznRDG;
            vCHznRDG /= jeqyGHlWCUjj;
            vCHznRDG /= jeqyGHlWCUjj;
        }
    }

    for (int JSDpg = 202346466; JSDpg > 0; JSDpg--) {
        reZevXzsP = reZevXzsP;
        jeqyGHlWCUjj += jeqyGHlWCUjj;
    }
}

nZaOuqhi::nZaOuqhi()
{
    this->VFQBrp(913306903, 1614921173);
    this->HnZGlcfiRVullyQ(-813618.6401115367, true, 223105.86186254403);
    this->zQUbxizO(-635331143, 338241059, -650604.0635460396, 776401.1006022485);
    this->YaAldyfbRoPdb(false, string("HdXoWRDZQWmHCPNBZKHEKvqTpTSnqfPWnynfCYnUXflCNbXmfzCKxbRneVRXTtmWcqnCpJenxBDQLDnglKOSzAiXgGoYydrzVgNdIBYFlKyhayJmaDsqwveGnPWHtVOiFkyiaarJGRRDhgQsuUxSzTnbJWhYVtwduCEhjtnNzzeAxjpIhsEzQoDVnnycmRnYxxMRIETAWVvOHISPJ"), string("FRERgGHXlRN"));
    this->EhKeTX(-1088385762, string("SzlKJoTcEYhgBekQTMgfbLQeLuORrvIjtmhXgmWHcOlWLMizkqpaZZofHkCyzoZNJXMSYUNkvLcwYzNsKRebrZHSrLWpDXLFnoQlUGcBefKyyqxSVrmXxanpIwSWzJtMZvxYvaxJLiSYTyvh"), -95195.4047788244, string("vPNjoerFEhBiPrivjHxFLGYnfLJFqjXdCiMbTCwuELBprYVXNxIalbCfLFGXNUMKOGJSXzsqxvZjWWiLIWFHxsbkMiwmIpwuaezakQLtWhkadPiGOvEROyMxeOFiFGNMkFnXquHsFrRTiNKFnHBrbkljJGSifALZFFaHGEeAUZSqvylpgjpVftgLNVCmuStlbkZBiRvsHauDpeOnTszICmxrDupywLXDFdkCaQyrdoPOzjQlLBCjDTfPw"), -47506.46179257645);
    this->coOooZadg();
    this->wzXprpM(false, string("QassMBvAfLROqQYIWVTQNdAsurMECrvBCYyHpeVXuiOWGJEejHcXilNZlMEOmiDGGhuwcHtRrpxSHpwBsulhXuAashpAZKgsYwMbKQvJFaaOQmIZgmPhXaSSGWQeLHQAft"));
    this->CRwapw(536179.6601381698, -1707493893, string("qGfRhLNZPKGXtKHRwuEnGaozKjpXDiREufsytNYYYciAyQkzwDSrcMBgrMHbqwpYhBkhIyySwJNrDTNTMWdWNrXNRJCfVEUorRglMORSkydVvfnyYkBhTfLkkXKcfOHEMXGDvizHcXlImmwjppQfJYVnCAjLAWNLegOtwhaAVXbfwxUCwbMIgQAAmrGzVbsmCTNWRElCkzpV"), -176166.42978166058);
    this->rTwsnCDmT(1200725665, -307010622, -1606632757, -339338275);
    this->UqkrGPOI(-978214.3181696266, -747754.2677984693, 1120439284);
    this->YBGgj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qWwSexiU
{
public:
    string IwjNWcVFX;
    bool LOGzcseIfvASr;
    double buLpLwX;
    double vMIZXQpF;
    int hQtjkE;

    qWwSexiU();
    void uplmXQ(string ieFCqvgpegpHs, string rODyyratUalbOfK, int ODPqeMp, int OfouCVHnX);
protected:
    double QSQsajTMlpMG;

    double ybdWUxXsUhG(int ejuan, double gmxTevltXGNHL);
    string zMrFQLKp(string nyEHVwLcYBhIUFFq, int omFwrz, int GYhwWUqfINmBMerO, int GWXCfCVZYLrDCQl, bool cqGKcfHwoEbL);
    void lEZNoGu(double QpUakMekFHzJGF);
    double CAiUHoJlQS(string wzZLBYxkGJz, double DufTFeAneYr, string UfzruWj, bool JFDzSoHJCxpZ);
    bool GFCyfinmLjv();
    int qCnhZqRBLPuR(string dYBBCNjR, bool nrlinzC);
    bool dWBfqRUqz(int cptFXBZbHx, double WqXFUcEvoMTPuKY, bool FxTsvSBwohpAK, int bBbcyOjcNwuDd);
private:
    int EInHwrZfRndNXqC;
    double BDTGqxr;
    bool HhyLZdRSxDC;

    bool KjurFleEfr();
    bool vCmLowEXbqze();
    bool CralrFnKWTBvvGdV(string NXbphsvYXZmibM, bool NQRQHwx, bool lREDPCb, double akyzx, string XzOsZdVnRehl);
    string wRUKI(double LDaxl);
    bool eflBRmCyCVNlzG(int pdgqtwxtxBxnC, string FrfZdWml, int gJjbYNjemhukmc, double SZhlvwPesvzsUFV);
};

void qWwSexiU::uplmXQ(string ieFCqvgpegpHs, string rODyyratUalbOfK, int ODPqeMp, int OfouCVHnX)
{
    string IsRaCCUC = string("mRKfWtpKipBPOjSLjOqegOSKPYRfSPZHnUzLvcgPOqJStEkUsXtWZxOBFoQKvuMAwLNydqJLkCbLjAmrqeQTXaaWhSHrToyyAOqfMEwQLZiLPGlqRMVjeMpUCPRaTVphZggPlbRqmecQfM");
    int wsAUNBYXikcdah = -1274443364;
    bool bntqdAKQks = false;
    bool SaEujj = true;
    string zgyfSv = string("OGZdTqRGgIOnXzaLcxVlCDtBUMqCwnzOstvJevmQPGtfRrNSSDuipjpCjQAdkQsjNLrVfuMBKehPptGMNwhufFdOWgFyeVZYhDzNKNTDbycEAbnmFjCoXlJlttWAdTooMxYtfxIeOKLgiTVBXakcEWhmjcGaaxnhtDFLqlhvLIbvGlnJmgHrInTMATjYOZA");
    string zvleoG = string("snlUDhppdxdSTxyDihpSeiBbpIfayzmGgDFZdILvgbkllCHopkPIqzXnHDTuYYaoEtHFjKKVlsowihFhmhNolcYiPtwYoiaGKXAijrGrXktjRqBzFLLhQuUEFUXR");
    bool tfRNEWTE = false;

    for (int rCnksRKLzf = 1096582677; rCnksRKLzf > 0; rCnksRKLzf--) {
        ieFCqvgpegpHs = zvleoG;
        OfouCVHnX += wsAUNBYXikcdah;
        ieFCqvgpegpHs = IsRaCCUC;
        rODyyratUalbOfK += zvleoG;
        SaEujj = ! SaEujj;
        wsAUNBYXikcdah -= OfouCVHnX;
    }

    for (int oXjQnSIjujj = 1736170196; oXjQnSIjujj > 0; oXjQnSIjujj--) {
        wsAUNBYXikcdah *= OfouCVHnX;
        IsRaCCUC = zgyfSv;
    }

    for (int GYnNwLnImjUUTkM = 1506612745; GYnNwLnImjUUTkM > 0; GYnNwLnImjUUTkM--) {
        rODyyratUalbOfK += zgyfSv;
        OfouCVHnX = OfouCVHnX;
        wsAUNBYXikcdah *= ODPqeMp;
    }

    for (int uIvLyKgDIAPLQ = 917960003; uIvLyKgDIAPLQ > 0; uIvLyKgDIAPLQ--) {
        bntqdAKQks = SaEujj;
        IsRaCCUC = zgyfSv;
    }
}

double qWwSexiU::ybdWUxXsUhG(int ejuan, double gmxTevltXGNHL)
{
    bool nqCSc = false;

    if (gmxTevltXGNHL < -902484.893512537) {
        for (int QihxPmnJLAWpw = 1306041330; QihxPmnJLAWpw > 0; QihxPmnJLAWpw--) {
            ejuan = ejuan;
            gmxTevltXGNHL *= gmxTevltXGNHL;
        }
    }

    for (int VthyAOlrZuroWNDr = 2126389057; VthyAOlrZuroWNDr > 0; VthyAOlrZuroWNDr--) {
        gmxTevltXGNHL /= gmxTevltXGNHL;
        ejuan *= ejuan;
        nqCSc = ! nqCSc;
    }

    return gmxTevltXGNHL;
}

string qWwSexiU::zMrFQLKp(string nyEHVwLcYBhIUFFq, int omFwrz, int GYhwWUqfINmBMerO, int GWXCfCVZYLrDCQl, bool cqGKcfHwoEbL)
{
    bool zytakVpaTHuE = false;
    int mZnkLigY = -846304763;
    bool PZlbequVfZoye = true;
    string GsqKRdk = string("rafDMdxtHwXFyOriEjApugNPbEVALEXoWywscQTUgneaiJyZepPtyccRYubWZclZkBPCjnUuWwuwcNvDepYNFVwIOMSqRkLOECbOQqWubJGMsqNOwxqsarjUxNrzYzwUJSCOuzVcLJlZbtmQUjICbabBTthjKYkPGfTozDDbXHzWfPgyzbIjPjWWAOyYZTgkGagZenduyBfl");

    if (zytakVpaTHuE == false) {
        for (int tqFNnHuF = 704573522; tqFNnHuF > 0; tqFNnHuF--) {
            mZnkLigY /= GYhwWUqfINmBMerO;
        }
    }

    return GsqKRdk;
}

void qWwSexiU::lEZNoGu(double QpUakMekFHzJGF)
{
    bool QeHFYXaUXVqTu = true;
    bool uZdMqq = false;
    double jisVtxfUkDw = -656730.7503185218;
    bool vtJZSaAl = true;
    int ppXMuLeJF = 531632002;
    bool MIaNwDAsJiXsJUN = true;
    bool FgOUXYvQY = false;
    bool CxyfOTz = true;
    int oukGBjgzMOvC = 219456506;

    if (vtJZSaAl != false) {
        for (int MRAHMvrLySdaCFGJ = 1540984993; MRAHMvrLySdaCFGJ > 0; MRAHMvrLySdaCFGJ--) {
            QeHFYXaUXVqTu = ! vtJZSaAl;
            CxyfOTz = uZdMqq;
            vtJZSaAl = ! FgOUXYvQY;
            vtJZSaAl = MIaNwDAsJiXsJUN;
        }
    }
}

double qWwSexiU::CAiUHoJlQS(string wzZLBYxkGJz, double DufTFeAneYr, string UfzruWj, bool JFDzSoHJCxpZ)
{
    int GzHOVWNfE = -2054019805;
    int pAjgw = -1455460958;
    int zTuDbPx = 1044203460;

    for (int MiPSVNvZsxPjYtbk = 1088662627; MiPSVNvZsxPjYtbk > 0; MiPSVNvZsxPjYtbk--) {
        UfzruWj = wzZLBYxkGJz;
    }

    for (int IoMiwHoSHrekxtJF = 273108759; IoMiwHoSHrekxtJF > 0; IoMiwHoSHrekxtJF--) {
        continue;
    }

    if (GzHOVWNfE >= -2054019805) {
        for (int UWnVydjcnkxez = 1290617699; UWnVydjcnkxez > 0; UWnVydjcnkxez--) {
            UfzruWj = wzZLBYxkGJz;
            GzHOVWNfE -= pAjgw;
        }
    }

    return DufTFeAneYr;
}

bool qWwSexiU::GFCyfinmLjv()
{
    bool LeqkwkApVxWqdZnV = true;

    return LeqkwkApVxWqdZnV;
}

int qWwSexiU::qCnhZqRBLPuR(string dYBBCNjR, bool nrlinzC)
{
    int GrNFfdlGe = -1561102514;
    string xlnJEd = string("nAMvFSdaJHKaJNJyaeddTBTvqWHDlcaIijvgQdaUOhxTgDXYOkzmeyfkiKSyhBewbLrlOswwADBZKTYJcbjeoYqGOkSDJNiTHtAoUPRwpEzFskVtqsmPQMcCgyvTYNGzqPGjncXQTVknpEVwZCDEBViaRyAvdpqaFSzUTehqqMDMtyaFNULmShsHcLSLbqNzNAeTykqOWrtyQlWTayOhkxtgDZpSlRIQwiTThaPUUOWMYsy");
    int oifxlkWn = -966477976;
    string LgVaNwP = string("LQAOjSmfHzDPdDZQEmJSKtQlzNHUjfUQUJIueVZnQXcCUKsThiPLfxjvvQvVlWefnPLqddulOBwekKLhviIkoIZdkuZyJQvgESxoRkJCSQfxlCkPNWpLoIBHeqLDdCEUMyoFEwEplNBRfhqZdxK");
    string WNinBsUopPwe = string("hfprgOkhXhtNCMuawkiwWurYBVjPzgakUCNHhFCNRWJiMwHHirIiLGYaTSjlOfKDkvmjAdLwYuxAGEvFBxJvTkuRayzuYvK");
    int nJWpCVendm = 1813733946;
    bool rXSgXuwAcATSd = true;
    string IHzJzgKE = string("xFZJmiQAdeoTNrTkCyxeMWdzRpYZOojdGnaSBGDlMJJdSQkTAOSfxpCXdwYjQCwkzxiRHnWvtiYqvZWLTQAYwEnEDSknUPatKwgpEOqfEHjbMdvyWzYbdZiElIfGiSFxLHBuLbdJWlYBNUjWMmstoTTmtBkDipIOALbFWsPSERxoBiBcjrgrxeStQnzVcUsLfMDsmOYucIhaCTu");
    bool ABVjDCULC = false;
    int vspUQ = 1392636292;

    if (xlnJEd >= string("LQAOjSmfHzDPdDZQEmJSKtQlzNHUjfUQUJIueVZnQXcCUKsThiPLfxjvvQvVlWefnPLqddulOBwekKLhviIkoIZdkuZyJQvgESxoRkJCSQfxlCkPNWpLoIBHeqLDdCEUMyoFEwEplNBRfhqZdxK")) {
        for (int tJmULRXUbvWzOAs = 1674993247; tJmULRXUbvWzOAs > 0; tJmULRXUbvWzOAs--) {
            continue;
        }
    }

    if (ABVjDCULC == true) {
        for (int qMQuTwl = 1378851017; qMQuTwl > 0; qMQuTwl--) {
            vspUQ /= vspUQ;
            GrNFfdlGe *= vspUQ;
        }
    }

    for (int QvrvnCXEMZrZEg = 859678472; QvrvnCXEMZrZEg > 0; QvrvnCXEMZrZEg--) {
        xlnJEd += IHzJzgKE;
    }

    for (int LkomqN = 1081572490; LkomqN > 0; LkomqN--) {
        oifxlkWn = oifxlkWn;
        LgVaNwP = LgVaNwP;
    }

    return vspUQ;
}

bool qWwSexiU::dWBfqRUqz(int cptFXBZbHx, double WqXFUcEvoMTPuKY, bool FxTsvSBwohpAK, int bBbcyOjcNwuDd)
{
    double twcpjFpFD = 575583.0630973547;
    double oOBJPuNA = 140169.33502723675;
    int KroicKZlhWfsWq = 1310353130;
    int QZUCFs = 979298581;
    int PbFBPeCXKQ = 737568880;

    for (int whxQRHxMAMGQuYU = 1099722391; whxQRHxMAMGQuYU > 0; whxQRHxMAMGQuYU--) {
        WqXFUcEvoMTPuKY /= oOBJPuNA;
        twcpjFpFD -= twcpjFpFD;
        twcpjFpFD /= oOBJPuNA;
        KroicKZlhWfsWq += KroicKZlhWfsWq;
        PbFBPeCXKQ += QZUCFs;
    }

    for (int sYRZpBigFTxuNap = 1943436012; sYRZpBigFTxuNap > 0; sYRZpBigFTxuNap--) {
        bBbcyOjcNwuDd = cptFXBZbHx;
    }

    return FxTsvSBwohpAK;
}

bool qWwSexiU::KjurFleEfr()
{
    bool PNQVqlUTM = false;
    string JVRCTUHnrNLZoz = string("vLIbRfHyloYDKRZzxheqMMuIxJGuStIhwWzhalurBhzKCtWjZvUbIZuKeImVQzvDskwkFlfYZkMcivVCoDxzSWooUsnnUrPNiNqSvYctSASHrozMqcUBuFRsaDQFvPiaqEkjGlaRyJefxjLiwSAKJQDOtTgRYCTAKIVPQNFsnyXjJKYznuEtNeBVysEAdtSzgylCTYoMMakuKxnQxpUdvPwIziqKCrEaBbQmPytCggVQcqKNt");
    string aSpVk = string("SgPbSjPfFuPXiuRNONLKTFtAJOnNWwMAYEVHvmwXPlCafrFrrTJvBEIKilhjkUPYUnKejbxaBoMrNKekmfmQklEAuAJCYaSnnMjeIRnsIMDmTUBqjKzmxrrQJBXESoNnFauXpTVjjjSQsnngBHqhqZVXKICgxmUkuyHOovyXJyvrSiTAQaXnZvGSPm");
    bool CgbIEIGsRBo = true;
    bool QjBZrJnGjd = true;

    if (aSpVk >= string("SgPbSjPfFuPXiuRNONLKTFtAJOnNWwMAYEVHvmwXPlCafrFrrTJvBEIKilhjkUPYUnKejbxaBoMrNKekmfmQklEAuAJCYaSnnMjeIRnsIMDmTUBqjKzmxrrQJBXESoNnFauXpTVjjjSQsnngBHqhqZVXKICgxmUkuyHOovyXJyvrSiTAQaXnZvGSPm")) {
        for (int BYsuukP = 1639411064; BYsuukP > 0; BYsuukP--) {
            JVRCTUHnrNLZoz = aSpVk;
            JVRCTUHnrNLZoz = aSpVk;
        }
    }

    if (QjBZrJnGjd == false) {
        for (int pXQQFu = 809269919; pXQQFu > 0; pXQQFu--) {
            continue;
        }
    }

    if (PNQVqlUTM == true) {
        for (int pIuZckaiMztstkh = 1218095292; pIuZckaiMztstkh > 0; pIuZckaiMztstkh--) {
            CgbIEIGsRBo = ! PNQVqlUTM;
            JVRCTUHnrNLZoz = JVRCTUHnrNLZoz;
            JVRCTUHnrNLZoz = JVRCTUHnrNLZoz;
        }
    }

    for (int avCXGOWjd = 1151006310; avCXGOWjd > 0; avCXGOWjd--) {
        JVRCTUHnrNLZoz += aSpVk;
    }

    for (int VIwdhaKTcunbPj = 1152148176; VIwdhaKTcunbPj > 0; VIwdhaKTcunbPj--) {
        QjBZrJnGjd = ! CgbIEIGsRBo;
        PNQVqlUTM = ! PNQVqlUTM;
        QjBZrJnGjd = QjBZrJnGjd;
    }

    return QjBZrJnGjd;
}

bool qWwSexiU::vCmLowEXbqze()
{
    bool joYocQYutgCQZLI = false;
    string iPvEN = string("vXEzDOMHqLCKOJjMbIkRnbUcIAWNjYDOtldLwBLEDjLUErqWsebm");
    int hYJXEKZezgaJXR = 1336224507;
    bool eleayHgTHatgFzj = false;

    if (hYJXEKZezgaJXR <= 1336224507) {
        for (int ZUQhnlaK = 1302271486; ZUQhnlaK > 0; ZUQhnlaK--) {
            hYJXEKZezgaJXR /= hYJXEKZezgaJXR;
        }
    }

    if (joYocQYutgCQZLI != false) {
        for (int DWPsTsI = 1921497880; DWPsTsI > 0; DWPsTsI--) {
            eleayHgTHatgFzj = ! eleayHgTHatgFzj;
            eleayHgTHatgFzj = ! eleayHgTHatgFzj;
            joYocQYutgCQZLI = ! joYocQYutgCQZLI;
            joYocQYutgCQZLI = ! eleayHgTHatgFzj;
            joYocQYutgCQZLI = eleayHgTHatgFzj;
            eleayHgTHatgFzj = joYocQYutgCQZLI;
        }
    }

    if (hYJXEKZezgaJXR < 1336224507) {
        for (int SbTLkuCllTXtsHlK = 804054321; SbTLkuCllTXtsHlK > 0; SbTLkuCllTXtsHlK--) {
            continue;
        }
    }

    if (hYJXEKZezgaJXR > 1336224507) {
        for (int FNNpIpxMDaH = 1329619887; FNNpIpxMDaH > 0; FNNpIpxMDaH--) {
            hYJXEKZezgaJXR = hYJXEKZezgaJXR;
        }
    }

    for (int KLPiRUFaE = 1035770752; KLPiRUFaE > 0; KLPiRUFaE--) {
        iPvEN = iPvEN;
    }

    for (int gbBfSEFHBuUJxyRQ = 363230378; gbBfSEFHBuUJxyRQ > 0; gbBfSEFHBuUJxyRQ--) {
        iPvEN = iPvEN;
    }

    return eleayHgTHatgFzj;
}

bool qWwSexiU::CralrFnKWTBvvGdV(string NXbphsvYXZmibM, bool NQRQHwx, bool lREDPCb, double akyzx, string XzOsZdVnRehl)
{
    string JlwYFHwLgWoJ = string("aCvbSreOzSqSNGyXEzflfgXKMDMsaWLLZlyutcyHSTNexNzMthmXdWwzHgILDpwKUBedUoRkKhVanYmNsunmjABDwBYkfxzsvVYXuZtOAfZykNcwRLMMpYUxIXghNSdDfbpyHgILBXrNAlkWNbuMIVEjKWh");
    bool YYUaHZ = true;

    for (int wwRZcBUEsBiV = 1745010870; wwRZcBUEsBiV > 0; wwRZcBUEsBiV--) {
        continue;
    }

    for (int RgYnuXnfQOVP = 70428979; RgYnuXnfQOVP > 0; RgYnuXnfQOVP--) {
        continue;
    }

    return YYUaHZ;
}

string qWwSexiU::wRUKI(double LDaxl)
{
    double ldKRVCCLaxet = 448263.2772118207;
    double hJkgacOO = 382347.5732340058;

    if (LDaxl <= 448263.2772118207) {
        for (int vYWGDj = 112062870; vYWGDj > 0; vYWGDj--) {
            hJkgacOO += hJkgacOO;
            ldKRVCCLaxet /= LDaxl;
            LDaxl *= ldKRVCCLaxet;
            hJkgacOO += ldKRVCCLaxet;
            LDaxl -= ldKRVCCLaxet;
            LDaxl += LDaxl;
            ldKRVCCLaxet *= LDaxl;
        }
    }

    if (hJkgacOO <= 448263.2772118207) {
        for (int BnscngWnTmMUx = 1231226271; BnscngWnTmMUx > 0; BnscngWnTmMUx--) {
            ldKRVCCLaxet -= hJkgacOO;
            ldKRVCCLaxet = ldKRVCCLaxet;
            hJkgacOO -= LDaxl;
            LDaxl *= LDaxl;
        }
    }

    if (ldKRVCCLaxet == 382347.5732340058) {
        for (int noglAiVvsvFhZS = 309617405; noglAiVvsvFhZS > 0; noglAiVvsvFhZS--) {
            hJkgacOO += hJkgacOO;
            hJkgacOO *= hJkgacOO;
            hJkgacOO /= ldKRVCCLaxet;
        }
    }

    if (hJkgacOO != 552764.0493555178) {
        for (int YTeMsPzOjvSZGti = 2142521465; YTeMsPzOjvSZGti > 0; YTeMsPzOjvSZGti--) {
            LDaxl -= ldKRVCCLaxet;
            ldKRVCCLaxet *= ldKRVCCLaxet;
            hJkgacOO /= ldKRVCCLaxet;
        }
    }

    return string("dIXLrNNddAtROuyRzPpPBPSmKzjMzTUSYVBvJpDWpuZwVbIAUQZzdeBeuPJZzkSttNBQgluVaXLkPhiulTcSKcdVyRrRYhTSoeScSShGBoHxxyGqNHFmErlrTuANutqqlpKeRREAqgtDcJejQssTLuAAbJFsdnblKklPEwMrUdXGIoQBpEoYlagIrTjUIvZiJtASkOUuKhel");
}

bool qWwSexiU::eflBRmCyCVNlzG(int pdgqtwxtxBxnC, string FrfZdWml, int gJjbYNjemhukmc, double SZhlvwPesvzsUFV)
{
    double nPSjkLrcuCbg = 472490.2181097018;
    string LapcnIahB = string("gNkJyoObABbplyfzhcmUnErUBaWsOFLoOXuNMHaRvdeyBTSEYPgYgYXcLfcraMvsVnZgBkwTdteDnPTeP");
    int ltyLuspukOhODOA = 1642294844;
    string UantigMPts = string("spYoTGTeRSoOKmPKapRMbqYFkVVdsfztwRkzzNQWoeCrnVgfAZBRMBDjVQPfidNPXjisYMHhJukCRXGmqCMZueJwOEFgJfMfRDapRnHffeYABfgMbtZmlscuXbBgJDgHETuYhOgKHUUhjvZNrTuHMQGBdmDCzImxMk");
    bool fPciAEexYbcskYZf = true;
    bool BAdave = true;
    int dRltWdmVfMojS = -715574523;

    for (int soiTEJHGKs = 1396206711; soiTEJHGKs > 0; soiTEJHGKs--) {
        FrfZdWml = LapcnIahB;
        nPSjkLrcuCbg = SZhlvwPesvzsUFV;
    }

    for (int PTDVNzyklFby = 1091231906; PTDVNzyklFby > 0; PTDVNzyklFby--) {
        continue;
    }

    for (int lytqzSGHi = 394786576; lytqzSGHi > 0; lytqzSGHi--) {
        SZhlvwPesvzsUFV = SZhlvwPesvzsUFV;
    }

    return BAdave;
}

qWwSexiU::qWwSexiU()
{
    this->uplmXQ(string("tBGacvnOJsXHDXikmwaYCVeuZmGhGriwdamKkSxJDnwNkNqEoknnylK"), string("ijiqUPmtHohYOhbGnqikknhcdiOVHAMyRkksCfAnjRlolInZQzcUWRprJLdBkayHAgPLumOkUCjtipvyUkFUizgmjizxVsJqZCrRPrIpvVgNYIqrdibpYuIXFSzhpWYtkyacZkOSssuLLuouJKjMRXoKqgjzZKXGaFUbC"), -1371820729, 1425339155);
    this->ybdWUxXsUhG(-1638234414, -902484.893512537);
    this->zMrFQLKp(string("WFrxOWhBucgAqvXmCcatMuosVuwHQUWbLEYzZFcmRWZxQjKzgqoaDgSNIdRBtpSOUswtxBaCMLIxGSRLFQeryzDjVFcOKRuPqVAbSIeElDKSlttnddVsQuCWbwjozjfj"), -1884251929, -352448832, -1650814425, false);
    this->lEZNoGu(-628971.0593613075);
    this->CAiUHoJlQS(string("hJphfMAAwtiCrSEMiPWWjnGDxHddtVZbvBJyBeKgKbJVCnVAOjTxACCHnABmxtxptDtYXDBspHmELRjGYiQxxKAfwYLJR"), -743991.0628430445, string("gAUsIDccvQVaWHdwQdJtZxgDAMkapyVprjSUhwLrPwNsdtwCe"), false);
    this->GFCyfinmLjv();
    this->qCnhZqRBLPuR(string("yOhugBfHCHNDbGzytVZITdwWWHWONVjkzabVApIyjedAjDlhFiNhxSQLaCHdvpffNdRZAHnwOiLubZKAAbyyqExkKMxWLoojDvtCRUMKnirHy"), false);
    this->dWBfqRUqz(-909292691, -464457.33381059364, false, 1228471945);
    this->KjurFleEfr();
    this->vCmLowEXbqze();
    this->CralrFnKWTBvvGdV(string("amcPjWUhbmPMyGhyEHBJkLnSIdBKZxOiTjmaTHiFllVwaaxTlVzpRVhoLBJNYpPArTGctfSETuqxYQkTrivRmOWUysUPkirkXRrStAVQiwGJlUPdQCnSdTiZhXbMIcnoHerxTDTmUUOiATDKxfFzkUntGvBlyWLRUjeYsQXrurTlzbGintTGWEMctIWuLPlcCumSpdIGLzmJoauSrKyZTWBnPxguvTztQkYSj"), true, true, -49901.3402075825, string("kfcoCJFdvfySnTWJKqCTFkXWumGEsKtXxcxfuZHOYQfgATSy"));
    this->wRUKI(552764.0493555178);
    this->eflBRmCyCVNlzG(-2099648882, string("otwXcDWPLeLvLElkZVNEPUQgoVuHAIDfVhIXWQUlCfKOUbJbpSyknukvXXFipSpahkJeqkyLPZLqMfwgyHGhpFYczLjfHKWcvOhAJbqneiRSBMUJmLwZrgHzdCALtBbWlTuqKXeBSZGFVDxuydVqeYYREjswjUMJrCyXqohcyeqRVgVEtHVadndmwjpMrfcH"), -445876873, -954665.4489489332);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AonzeXx
{
public:
    string xEzDLgkQmhhF;
    string kYfnPawxBtaL;
    int sDeICYlz;
    string zvMJAsakPmWIyrRh;
    string GwZehBARfQpX;

    AonzeXx();
    bool VaNHS(double zmQKNWKefYS, string xtaORrO, double pMLxe);
    void MTJxXBCBEI();
    double lwhJUm(bool FPRtSlnOzBaZxfBl);
    bool UHAVeipunKZSE(double kDJOMU, double sUJMSPwLHPECTPjg, bool PoFoYHIzo, int kEYNbZn, int RwEwWGxksc);
    string zBZXkdkGCAxxtc(double Oefime);
    double qMJWRh(int IhKxubalJx);
    bool rXHrRwfn(double XRETBtb, int CIDsPzMfibWSM, string jTGGJhkt, int NneqpFmHsvzlXeuK);
protected:
    double bQwubt;
    int zcbbqFqyjMFxfu;
    double vWvhzr;
    bool HcgkQTBW;
    bool KkzpVhIQ;
    double rEnym;

    int UlfumwKRaSgSH();
private:
    int BrtOSAk;
    bool FAZHDnVrGOl;

    bool sNroonDBammeQ(string drCLjul, bool GgYMyYDYHqQdFC, string deoLxCFeHPNevz);
    double kbOxAoDEpSXiTcS(int fHmXu, bool QcEuhtW, string ZfkoMRrUZk);
    bool UDMiLiSvzyARGMTX(int fKxUH, string eKhmYsOmCusBg, int fpcUwzh, double NQmCFTSWdMbGNw, bool UkXMDfnPmStqw);
    void wjYtPs();
    int bvMoyavn(bool RJWNe, string upmVCYSankjda, double NvAYiNCIC, double LsFBsmTLqNROGs);
    string iOqJvTFadswhC(bool vBbnqhukAgvvo, int OkZLCqcy, bool ESumfcxjTzeoV, string GQRkj, string JSupxSwiqL);
};

bool AonzeXx::VaNHS(double zmQKNWKefYS, string xtaORrO, double pMLxe)
{
    bool xECUErradQXW = false;
    int ylqiuVN = 1662707173;
    bool gBetRghgUVHCe = true;
    int SkgwXootymqVw = -1442879116;
    bool sdRvxwJMTY = true;

    return sdRvxwJMTY;
}

void AonzeXx::MTJxXBCBEI()
{
    int VIHoRwVCJwgefvX = -654470915;
    string rhHLcjwaYudDGFvm = string("UamRWocndmZTCHpNVHKHnBSypmKBWIFQIJQROqfTDfxykaorHMvtWEQjCoqfQVeirkvtRnssHThnwZhWztXZGWHPttwXPDjUWQKPLiFTxnBQJcMmzykFTdhTfWrlxVNDCgBauzqqpRcHYTf");
    int Umazb = -1105030349;
    double HBBtUROuqUlFFCfQ = 842103.3864263692;
    int vHkld = -100714139;
    bool jtCdaG = false;

    for (int wxSPOOcFf = 1711410486; wxSPOOcFf > 0; wxSPOOcFf--) {
        rhHLcjwaYudDGFvm = rhHLcjwaYudDGFvm;
        rhHLcjwaYudDGFvm = rhHLcjwaYudDGFvm;
    }
}

double AonzeXx::lwhJUm(bool FPRtSlnOzBaZxfBl)
{
    double kSXoigcWLSDb = -203953.17996116212;

    return kSXoigcWLSDb;
}

bool AonzeXx::UHAVeipunKZSE(double kDJOMU, double sUJMSPwLHPECTPjg, bool PoFoYHIzo, int kEYNbZn, int RwEwWGxksc)
{
    double JUfKN = 644355.1787603347;
    double DKBZyRLSvCMlC = 619196.2791748937;
    double mInrUfIiyCNhkja = 664127.2231520879;

    for (int hPJwXsrLUQmEk = 931070021; hPJwXsrLUQmEk > 0; hPJwXsrLUQmEk--) {
        continue;
    }

    if (DKBZyRLSvCMlC <= -427778.22271325433) {
        for (int MmfTeA = 355290465; MmfTeA > 0; MmfTeA--) {
            continue;
        }
    }

    if (kDJOMU >= 644355.1787603347) {
        for (int ZawQsYYCdMJNh = 700334574; ZawQsYYCdMJNh > 0; ZawQsYYCdMJNh--) {
            kDJOMU += mInrUfIiyCNhkja;
            RwEwWGxksc = kEYNbZn;
            kDJOMU = JUfKN;
            kDJOMU /= DKBZyRLSvCMlC;
            mInrUfIiyCNhkja -= sUJMSPwLHPECTPjg;
            PoFoYHIzo = ! PoFoYHIzo;
            mInrUfIiyCNhkja *= DKBZyRLSvCMlC;
        }
    }

    for (int lzkXKOgV = 478672964; lzkXKOgV > 0; lzkXKOgV--) {
        continue;
    }

    return PoFoYHIzo;
}

string AonzeXx::zBZXkdkGCAxxtc(double Oefime)
{
    string wCRPUEqvLQRIZg = string("kOuUynQceRloLscwjGJssOiNKkIKxjfIEOAfVsSzZOwdibLRYtcoVSDzRAtW");
    double JaDLexyPQgQ = -962446.7841186608;
    bool FEFzgjBPDpDBtwr = true;

    for (int vSNceR = 1006150523; vSNceR > 0; vSNceR--) {
        continue;
    }

    if (JaDLexyPQgQ < -962446.7841186608) {
        for (int OXxbbwBK = 1678418277; OXxbbwBK > 0; OXxbbwBK--) {
            Oefime += JaDLexyPQgQ;
            JaDLexyPQgQ /= Oefime;
            Oefime *= Oefime;
            Oefime = Oefime;
        }
    }

    for (int dUtyJbrBpmOe = 163910953; dUtyJbrBpmOe > 0; dUtyJbrBpmOe--) {
        Oefime -= JaDLexyPQgQ;
    }

    if (Oefime != -962446.7841186608) {
        for (int wtNZKM = 615226439; wtNZKM > 0; wtNZKM--) {
            Oefime /= Oefime;
            JaDLexyPQgQ = Oefime;
            JaDLexyPQgQ /= JaDLexyPQgQ;
            JaDLexyPQgQ -= Oefime;
        }
    }

    for (int KwWVlhRdtILI = 377499469; KwWVlhRdtILI > 0; KwWVlhRdtILI--) {
        Oefime += Oefime;
        JaDLexyPQgQ = JaDLexyPQgQ;
        wCRPUEqvLQRIZg = wCRPUEqvLQRIZg;
        Oefime = Oefime;
    }

    return wCRPUEqvLQRIZg;
}

double AonzeXx::qMJWRh(int IhKxubalJx)
{
    double BWCEBaVqiQ = -123428.43820300294;
    string OJamMv = string("XboSRNIloyAJmOGSlStsRVLlnJSWieeKHgYGXVMnCvcDjlNOksZxChTQaSSfvegGFPWibXpRSYhIHVkTuzsRCDNuJOQZawlZqetHepHXbzfgiFTomYFmbpcPCuwsIxkquEbIHWuHkQkxkEYuVFmUffXJPqGYQZCjzzZWqcEvbScxKVcRrIjjXpoSkJcAjhNYQlQskrIgkyBvqGJFwFydGjFSA");
    int AAuwghblUHalDpY = -2044054790;
    double uTaszjdmnPvWnxO = -59799.09154877188;
    double YCHljqVyVnma = -346509.9773607834;
    bool wqlhdQd = true;
    double sTvtNPeh = 759592.5577825764;
    bool DGERgFIeSxiP = false;
    bool yvyAaRZGeXrndDi = false;

    for (int dEAbzEMAWzc = 751707061; dEAbzEMAWzc > 0; dEAbzEMAWzc--) {
        uTaszjdmnPvWnxO /= sTvtNPeh;
        wqlhdQd = ! DGERgFIeSxiP;
        sTvtNPeh *= YCHljqVyVnma;
        BWCEBaVqiQ -= YCHljqVyVnma;
    }

    if (YCHljqVyVnma >= -346509.9773607834) {
        for (int xFxFJIED = 439552895; xFxFJIED > 0; xFxFJIED--) {
            DGERgFIeSxiP = ! wqlhdQd;
        }
    }

    if (OJamMv != string("XboSRNIloyAJmOGSlStsRVLlnJSWieeKHgYGXVMnCvcDjlNOksZxChTQaSSfvegGFPWibXpRSYhIHVkTuzsRCDNuJOQZawlZqetHepHXbzfgiFTomYFmbpcPCuwsIxkquEbIHWuHkQkxkEYuVFmUffXJPqGYQZCjzzZWqcEvbScxKVcRrIjjXpoSkJcAjhNYQlQskrIgkyBvqGJFwFydGjFSA")) {
        for (int gaqUlXg = 1869832305; gaqUlXg > 0; gaqUlXg--) {
            continue;
        }
    }

    for (int nHnuTPHCJyjNA = 948342647; nHnuTPHCJyjNA > 0; nHnuTPHCJyjNA--) {
        sTvtNPeh /= BWCEBaVqiQ;
    }

    for (int hyzPjpFoODYt = 1585120191; hyzPjpFoODYt > 0; hyzPjpFoODYt--) {
        yvyAaRZGeXrndDi = ! wqlhdQd;
        wqlhdQd = ! yvyAaRZGeXrndDi;
        uTaszjdmnPvWnxO -= sTvtNPeh;
    }

    for (int qISOmrNapothn = 1996759723; qISOmrNapothn > 0; qISOmrNapothn--) {
        yvyAaRZGeXrndDi = ! DGERgFIeSxiP;
    }

    return sTvtNPeh;
}

bool AonzeXx::rXHrRwfn(double XRETBtb, int CIDsPzMfibWSM, string jTGGJhkt, int NneqpFmHsvzlXeuK)
{
    string GjSMxgviqeRN = string("vyeaeFLGuJvaORGrdLKgzjwFoqVWjaJnttIqrauDgVGOyggHinKSDVjebPvWQCPfebxULfWMPDVjSnXDqahlBrfFDdTxJsVEyYkpPIzDxeasKHqEdY");

    for (int eyBJqoig = 1530884897; eyBJqoig > 0; eyBJqoig--) {
        XRETBtb *= XRETBtb;
    }

    if (NneqpFmHsvzlXeuK == 192761153) {
        for (int ZJrJtNHZZPAhmjct = 208142319; ZJrJtNHZZPAhmjct > 0; ZJrJtNHZZPAhmjct--) {
            continue;
        }
    }

    for (int wrVqkjUsBMX = 1602052057; wrVqkjUsBMX > 0; wrVqkjUsBMX--) {
        NneqpFmHsvzlXeuK -= CIDsPzMfibWSM;
    }

    return false;
}

int AonzeXx::UlfumwKRaSgSH()
{
    double rqjVDFbEKcX = -418213.0374194172;
    bool wIzVzNu = true;
    double aNSlhZQRYTu = -452869.78225896164;
    double DANIF = -614701.8707082901;
    bool mpCByr = false;
    double ZhvFY = 845823.6949349614;
    int LIbrYQ = 2128766799;
    double RFVQyiRJwbaGyXXY = 192490.14834119534;
    double eVircIGsGYHg = -140897.23696892546;

    return LIbrYQ;
}

bool AonzeXx::sNroonDBammeQ(string drCLjul, bool GgYMyYDYHqQdFC, string deoLxCFeHPNevz)
{
    int mRgOMu = -543263365;
    int HVnyEIfrotPh = 589895189;
    bool SYtkOkYv = true;
    string HKPuXOLEsVJQ = string("qReUUdxJCPYytZbRoExPRNuASWdxUIVnNGYfPLZBTlRmxgrmRyTmBwEnnubMSff");
    double dTYidiAsgHRE = 277727.7841117349;
    string VmSULPjkQIDgs = string("yzRKmuGGHCJycUYCfLUggKEAHGXbClMYqTofFTpTJRUSiWZUYLeEyMUnNuvLpLtdWjygrMxawXHqnbtLqflHPiVVtctgkIEfhrqJbpokHiMLmYEOUuqCmklLqOLASBZYRtaxKhoqdTpnhQpGrwEn");
    int ykCqoUF = 445304221;
    string yuQJdNzaJJgIEuux = string("YoxsQSMKnjH");
    double zaDLg = -574233.5857711759;

    for (int hqeSyQvv = 1912938561; hqeSyQvv > 0; hqeSyQvv--) {
        drCLjul += deoLxCFeHPNevz;
        drCLjul += deoLxCFeHPNevz;
        SYtkOkYv = ! SYtkOkYv;
    }

    for (int XxAevBvQxZMu = 2038499918; XxAevBvQxZMu > 0; XxAevBvQxZMu--) {
        HKPuXOLEsVJQ = drCLjul;
        SYtkOkYv = ! SYtkOkYv;
        zaDLg = dTYidiAsgHRE;
    }

    for (int jurQcUrZisvfHCT = 202665090; jurQcUrZisvfHCT > 0; jurQcUrZisvfHCT--) {
        deoLxCFeHPNevz += deoLxCFeHPNevz;
        HVnyEIfrotPh += mRgOMu;
        mRgOMu *= mRgOMu;
    }

    for (int TIrgMEMqg = 1179063516; TIrgMEMqg > 0; TIrgMEMqg--) {
        SYtkOkYv = SYtkOkYv;
        HKPuXOLEsVJQ += VmSULPjkQIDgs;
    }

    return SYtkOkYv;
}

double AonzeXx::kbOxAoDEpSXiTcS(int fHmXu, bool QcEuhtW, string ZfkoMRrUZk)
{
    int fneXmnbc = 1978675676;
    bool piHyGpU = true;
    int THclVqtbnAnyTF = 1052575458;
    int oLmarD = -171461115;
    bool uibIKrOmW = false;

    if (uibIKrOmW == false) {
        for (int tvuuNID = 37621701; tvuuNID > 0; tvuuNID--) {
            piHyGpU = ! piHyGpU;
            fHmXu += THclVqtbnAnyTF;
        }
    }

    if (uibIKrOmW != true) {
        for (int uoPrJ = 966571549; uoPrJ > 0; uoPrJ--) {
            QcEuhtW = piHyGpU;
            fneXmnbc *= fneXmnbc;
        }
    }

    if (oLmarD <= 1052575458) {
        for (int vGkKEJjWJDMEQ = 1602428553; vGkKEJjWJDMEQ > 0; vGkKEJjWJDMEQ--) {
            uibIKrOmW = uibIKrOmW;
            fneXmnbc += fHmXu;
            THclVqtbnAnyTF += oLmarD;
            fneXmnbc -= fneXmnbc;
        }
    }

    if (uibIKrOmW == true) {
        for (int gBbzgZXPvoBryI = 74219700; gBbzgZXPvoBryI > 0; gBbzgZXPvoBryI--) {
            oLmarD -= fneXmnbc;
            piHyGpU = uibIKrOmW;
            fneXmnbc *= oLmarD;
            fneXmnbc *= oLmarD;
            QcEuhtW = ! QcEuhtW;
        }
    }

    return 876004.9244165518;
}

bool AonzeXx::UDMiLiSvzyARGMTX(int fKxUH, string eKhmYsOmCusBg, int fpcUwzh, double NQmCFTSWdMbGNw, bool UkXMDfnPmStqw)
{
    string DDFVlm = string("OzimCMIoAvwmRwyTpbyDtqMMagwndBNPcyDxgLLNJtRtdUsWlVdckdGmGwLsxfLrMlFXtFmPQzHmdxtxIxJJtoYrDiLxoGUgmqDElkJypLCgkqkjFdvSvFlDXvrDlFTQcuJXScBzMnYeywVvUlEjzDRVVyJCqbgXWULzinRQBLFfDIGfXWuUUoOiVaqNeqzVDmxOoomWHcsGNWgZqvWhwBbQCEBzYFBVYTYDGcHnVunKvxsYnPA");
    bool liMKnMWBHAriT = true;
    double FXprchmLsT = 901064.5245519947;
    double aXJqGeB = 919217.1974420168;
    int odjSp = 884638422;
    string RJmrU = string("TkMmpZHmhjjafJymTSpGUElIHIoxQYnJbBpxPfXJwkqlEOratnZVGAoLsVftOhuKFQuVoXtbKpZeUxxGUSsSPtHwfpLweYSLDFbECdoAiLdvmszWdgiEydAqcutVvCdNVKfVPcWcDDpwunKlTcNhadJHLPwtKCORZveoWshChDDLjcRRTuWdxOnFdJmpMTbIfY");
    int VUXTObEAiaUJ = 1661868543;
    int OeLNNkttOqax = -1791923078;
    string NwUhYLVuvqSkA = string("pIoupnenLcYFiwNAYgotiiOTkGdWWVoCRfVXIqeqrznAaAClQUsTvrtczkgvaTKtrvgGAzURUhKkTMWlfxxVcrBgdfyWaDFAGQlFRvmXhWVOmrTJwCMWYCSCoNXqBVhdokKrdYPYeJhxlyPD");

    for (int XfOVSjPGqDJlv = 666638125; XfOVSjPGqDJlv > 0; XfOVSjPGqDJlv--) {
        continue;
    }

    if (fKxUH == 1661868543) {
        for (int UzxDbphA = 852026416; UzxDbphA > 0; UzxDbphA--) {
            aXJqGeB = aXJqGeB;
        }
    }

    return liMKnMWBHAriT;
}

void AonzeXx::wjYtPs()
{
    int IziPjI = 1089508776;
    bool kxqHVyQ = true;
    int HJcok = -1700999490;
    string qdLVIelqtrQ = string("VgbBcwYUPpncwWkHpDDYpaNKGAEIvewoJBQagTvKjhOBQhtbVwZCjgHMWzJHAHxeSmzPuOdVcMaDOXDmGGeBAutddCXKFMK");
    bool mqMLmezdinskb = false;
    bool doiVJKojtmuG = true;

    for (int fUGinDcUUXowr = 950320419; fUGinDcUUXowr > 0; fUGinDcUUXowr--) {
        continue;
    }

    for (int SEsrEsbIJqf = 1302004430; SEsrEsbIJqf > 0; SEsrEsbIJqf--) {
        mqMLmezdinskb = ! doiVJKojtmuG;
        IziPjI /= IziPjI;
        qdLVIelqtrQ = qdLVIelqtrQ;
        kxqHVyQ = kxqHVyQ;
        mqMLmezdinskb = ! kxqHVyQ;
        kxqHVyQ = ! doiVJKojtmuG;
    }
}

int AonzeXx::bvMoyavn(bool RJWNe, string upmVCYSankjda, double NvAYiNCIC, double LsFBsmTLqNROGs)
{
    double UtOkOhHRi = 404655.7082548424;

    if (UtOkOhHRi == -458089.89280714985) {
        for (int egsFrvc = 1868200838; egsFrvc > 0; egsFrvc--) {
            UtOkOhHRi = UtOkOhHRi;
            UtOkOhHRi /= UtOkOhHRi;
        }
    }

    if (NvAYiNCIC >= 404655.7082548424) {
        for (int gXbzlcBHeoqoM = 1955357512; gXbzlcBHeoqoM > 0; gXbzlcBHeoqoM--) {
            LsFBsmTLqNROGs = NvAYiNCIC;
        }
    }

    return -202164109;
}

string AonzeXx::iOqJvTFadswhC(bool vBbnqhukAgvvo, int OkZLCqcy, bool ESumfcxjTzeoV, string GQRkj, string JSupxSwiqL)
{
    string FCPBU = string("YYTEsUfTzafPQhJkPbsDxxEQBGMHYOqqPHbHqPNHWOrlFXlEWoBQuvWROWdBkZKUankYgCeQEhbHPtyDcNgnxzUyCnnlMMnoNYcRNjGDzRAiVYQbePXNdGQjewaPLVFusRGEbWpwfshpRkUdjGGywKiiojftwUeWakechHNwrTjAObheNWFEgEHwwgYvHIIpWRAyEFaVgHv");
    int ghfVlUOD = -1698810466;
    double BIRWEc = -277433.9736273775;
    int iYbpWpcv = 107149188;
    int PdcDTzQ = 49171138;
    int yWYKOMcKIQlSt = 1175312006;
    string fYUWYAbBpsTvUYEh = string("mFVckPuFJyXTcNTNgLUxhPfYUBwfeocAMJqlePvrruFuvJwJHePCJUqMUQLHxZjHCTCwYxeVOCAfXuFEDGBRMFRBYRGHuDzJsprGmWySXfSzINmdtOEKghslcIvdzTJWhDNqaHGZROZCfdzYNURzWLiELFQPXoUcjZwmJmwUZBgNlpOdzMmoHDoUfLxARQrgHiNxQFFdyowfzqDsysrQlAqKSXktLMrcoAGSNEkYGXiollkLYkqVGsN");
    int vBlGgnnpEkztnawZ = -597668431;
    bool Lygtykc = true;
    int nmegxwtqCojpPf = 736231043;

    for (int atRocPdVQV = 1777629347; atRocPdVQV > 0; atRocPdVQV--) {
        vBlGgnnpEkztnawZ += yWYKOMcKIQlSt;
        iYbpWpcv /= PdcDTzQ;
        vBlGgnnpEkztnawZ -= nmegxwtqCojpPf;
        OkZLCqcy /= iYbpWpcv;
        iYbpWpcv -= PdcDTzQ;
        OkZLCqcy = vBlGgnnpEkztnawZ;
        OkZLCqcy /= yWYKOMcKIQlSt;
        PdcDTzQ += yWYKOMcKIQlSt;
    }

    for (int SGTsYn = 1298033162; SGTsYn > 0; SGTsYn--) {
        PdcDTzQ -= vBlGgnnpEkztnawZ;
        iYbpWpcv = iYbpWpcv;
        iYbpWpcv -= yWYKOMcKIQlSt;
        OkZLCqcy = nmegxwtqCojpPf;
        OkZLCqcy -= nmegxwtqCojpPf;
    }

    if (PdcDTzQ <= -1967739561) {
        for (int vGlKpgIXp = 1807739425; vGlKpgIXp > 0; vGlKpgIXp--) {
            OkZLCqcy -= nmegxwtqCojpPf;
        }
    }

    for (int CWFObL = 496450072; CWFObL > 0; CWFObL--) {
        yWYKOMcKIQlSt *= iYbpWpcv;
        FCPBU = JSupxSwiqL;
    }

    if (OkZLCqcy > -1967739561) {
        for (int ukgMzmyRdaMa = 541868430; ukgMzmyRdaMa > 0; ukgMzmyRdaMa--) {
            vBlGgnnpEkztnawZ = OkZLCqcy;
            OkZLCqcy *= OkZLCqcy;
            yWYKOMcKIQlSt /= ghfVlUOD;
        }
    }

    if (OkZLCqcy < -1698810466) {
        for (int mDFWHqJuODVMgrrR = 216168731; mDFWHqJuODVMgrrR > 0; mDFWHqJuODVMgrrR--) {
            vBlGgnnpEkztnawZ += PdcDTzQ;
        }
    }

    return fYUWYAbBpsTvUYEh;
}

AonzeXx::AonzeXx()
{
    this->VaNHS(-272387.22772170685, string("ApLChPiuElWCWPZglvmwnkZXhueiSQtcMweOAfrmMMCVltFCyebafSOOxJFqBsMpNOkPZlUhPGShQfUjhDcFuUlyDvnXisBkoqfiJxfgGzRpOGbcvbXYPCiKzQFZlpwjyIzPIPitFCEkFjNMKzbLRrpvsDdcLDmZuhTxEQwCccXCVAlOeiVgvxiRLjPIOfvxtHPrnvXeDZBJKaaunMRualKHnPITLrfrzBCQaArLXzSQ"), 166378.28764473135);
    this->MTJxXBCBEI();
    this->lwhJUm(true);
    this->UHAVeipunKZSE(-427778.22271325433, -448251.48152736964, false, 139309511, 1105330827);
    this->zBZXkdkGCAxxtc(-644622.2299222347);
    this->qMJWRh(643329990);
    this->rXHrRwfn(-711759.111972716, 192761153, string("NYsNqMUOMltLVcNrfOapysNEjXSJoRrzCPeKqIzIEQXwXsKwSGAJhaVLbhSimsnddiRCpiDOMxvaizVMogLBhMncaeEqWHjpivetLfJRVBaEjetqBnGsOGehaxfgUMLIdVLuVtWyvpYZRxxiCjvvrnXAeRpESVwzetZqKLAvlbZTWzQHljsjAggkqouxuRoMuIEJUQiSdrtLZTqTiJOVKUkKsGwGoIbIjasYlzt"), -183590116);
    this->UlfumwKRaSgSH();
    this->sNroonDBammeQ(string("IyFveGoBInTnRXARagBKdNLArStSXw"), false, string("tiKQlDacTIYRZNhcNVVRKvIvkaJYPdrHcPEDXaGkCaqiUAPfPzIkoSevevDKmJmqgoJaBjrMEKtLkvEbGmmQkcglpQKVftPFWnySsfZwOZZYnklhxTwGaYUh"));
    this->kbOxAoDEpSXiTcS(1027592652, true, string("jbgxGGqSzaFHSvkbLbOjhgAWPCzXPLqVfLPuXxJtoeKzEGgAjVtzKrZYYDmtZowfAxjKsnisjtTZTByiGMxMOTnwfEBoWoiUAGBwfDaQoVMLMivvczaFdfveWjaQTfWTJBELwbUlZgctUFKilsf"));
    this->UDMiLiSvzyARGMTX(-1533361037, string("zdcnObtmgPDUymChEHcgpWdBAVaDlBaKWocyUQZlkomROKVSEzgoNSnoEdOwVyxBfEtPeEmSaifURwDRxtNEnskVSOOuuTToxajBjfPxSUaOdsxbrooivmFHYtRFlywVsbewBPPxRUkmtNwUGcAUrsHlallXScBGdTbbWsUNFnfRLmZIRUKSHCpUedrsAdFZzbwGglfeTAuZnCzWOxyCKWidSAaPDw"), 2034355361, -543652.6568923075, true);
    this->wjYtPs();
    this->bvMoyavn(false, string("svEiQbBGxRnEKRTzpYcHRfSulcOTJekHCOutjvUvDsBaUxGoGaVlUfcrDqhVoupMHBOWDqRdKoRdSGmTiWpJHgJQQHLzuFHhfXczWfUUuxInOVdTKvPLtPtznaSTaxiBwVjJNDNGTgwYPczrCXglNhanqVPVjKmiSMNPLVeaxkFU"), -475882.3785481, -458089.89280714985);
    this->iOqJvTFadswhC(true, -1967739561, false, string("hNzRqRntQAwTOGIZTsMnVETZGFBSfZvRWFXIbbDfoieiwgSSAxWqYrqqQFOSheaqrJnCpORWvuZNclDzvzrBwwoXhtLUTixjFhmNwTtzBXkiMPORGNcvtAmQoCAbDjLAOGvVKgiN"), string("TDhVmMJgDkYSBquzenevlFsivxLFrJswpPEa"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dskwbmdcnp
{
public:
    string hUkcALverwxpZi;
    double wXqYYxmwWGedSE;
    string RsLwHUhQBq;

    dskwbmdcnp();
    string knwdxuCY(string sVUbtWg, string GoHBOcY, int WvadmTRHZegFQALg, bool xJLTBPZdLZhGh);
    bool nxRWQBwMFmtih(string IiDiwfnYvoiNDX, string sPfJZhieIP);
protected:
    double WOaARiwRisYrM;
    double sHgMqF;

private:
    double NLJQEybj;
    string ObaSDpXIsr;
    string xJVUUVC;

    void PfJTeeVdjpMiCZ(int rtuWtX, string NoWaxReW, string YydZkjxWVjKB, double xeHVtGNFL);
};

string dskwbmdcnp::knwdxuCY(string sVUbtWg, string GoHBOcY, int WvadmTRHZegFQALg, bool xJLTBPZdLZhGh)
{
    string EZvYIfWCorvJn = string("xGhvoZlOBOeiclkjXfkjKpjmPTQgdPwShjgLPKHkkByItRvOKykXGHOZMaIHqKTcsGIdmrGEegFIgxneEYdfzmlNqsQDoiLtnbqcWhTkhxZUPbayCGBlNAerzlaXCTAwMYPiFfknCaufgpKeZfthWLqacNhgUltIwrifFnLJTQitRnBbusadfXivVGZTyKVhhVzCeSgjmEET");

    for (int YCiAGbvEI = 1379289062; YCiAGbvEI > 0; YCiAGbvEI--) {
        continue;
    }

    return EZvYIfWCorvJn;
}

bool dskwbmdcnp::nxRWQBwMFmtih(string IiDiwfnYvoiNDX, string sPfJZhieIP)
{
    string RyNoMEbEz = string("FwffBwFxErzdBzMKpWzTtDEFxpPbWSfWYioYzXVvCcYuKhhVuASTdiHuUqVSCEivVxeEyOQKoXRwENrvuPLGDbTTXjbINwQcIkaNphMNYOMCPzaQJlwDMhvyZKCIrNdpgVYqQoiGAjfsovjMXqvxhdPojITgPTERzqXZrQVVhsPnOWFvcsOuyOBIdoFjWoGvjEROjJiYGFkxGurmDUXcWkBwLDJFuwDCfTAstkhDKRECKbUNNIFwMDklunH");
    bool RArNbPGsvwSRlHtx = true;

    if (IiDiwfnYvoiNDX >= string("QRrVFBsCrvKwAcVmXZEIquZCxSZy")) {
        for (int kZlcccdQHQfHSEV = 2110441769; kZlcccdQHQfHSEV > 0; kZlcccdQHQfHSEV--) {
            RArNbPGsvwSRlHtx = ! RArNbPGsvwSRlHtx;
        }
    }

    return RArNbPGsvwSRlHtx;
}

void dskwbmdcnp::PfJTeeVdjpMiCZ(int rtuWtX, string NoWaxReW, string YydZkjxWVjKB, double xeHVtGNFL)
{
    int lSnEbdE = -93497082;
    string qHbrJuthCZZanygQ = string("HEZxjDsjUaxRwrLfUWKMdwePdnHiQTVlGQcSEZRtmFmWyDLuYxnSavEEOIDUaIRkNXkzoGYNwKvDvtGrbIIvTFSjQTPCCcveBzySLmSnGrXvnuewiBvbgtBycIAQPccILQRZgloQRnvNg");
    int XprGkzKNFFwhX = 150937410;
    string DNGQuxZJ = string("ZVRcWHlzOiWQavSCsslOEiVGntjCjqLbWleYJQCABJBLqeiuYhLIabBjEWPNATBCvTJEMvxYgdfloEewGBWcICjBy");
    bool qulTzvLrDQIzLTqd = true;
    double PqQnoWLFFTtdd = 740660.2954161364;
    int fROSslyLHlzDU = 1777637657;

    if (YydZkjxWVjKB >= string("GslZBprjBJsJVVPSjleKJJ")) {
        for (int WExjkgMTLM = 1919191511; WExjkgMTLM > 0; WExjkgMTLM--) {
            rtuWtX /= lSnEbdE;
        }
    }
}

dskwbmdcnp::dskwbmdcnp()
{
    this->knwdxuCY(string("GnTpHGrVoRHAXMYpBsplerOWzGzeLoxYUCDejAVWJyCQePPrVutgBvzSejfjwclAzywqNomUCeTeyCwWfCQAJEJgdGnHWXImeOIcyjrjzwqcbgWgigFMcmEoIvcOjOlDppLUaZjtQXDcBhaNVWjkCbqDOfaNtBfopcrNLQMOqOhNSdBGHwhHgEKGoTShGfdqkrjoCXdX"), string("amjdqBrCUeJiQGMtkihsXeFKtDYdwVwaEzfqVopHYyFKWigUVRTnrJX"), -1290821207, false);
    this->nxRWQBwMFmtih(string("oMGuLdDnHAFGMyTjGJWBVsckUUsnWELScIdYGosrwnVdTEdWXHgnRIILCRSIDwtZDAtmRhyOADmCbwghsbjyvpEXDTvgQxLnIZbDbXFbhrNzzdVYWdFprGocsqvvNzHsWUrCHjHeeZqBDIecyydwaKVksMZPhQrromUiUKmdaCldXpbpfIvNnNHCRKCWakbxBLRsbgKyoiUVVfYRJbYJuaWqafcGuvguSGYufCFv"), string("QRrVFBsCrvKwAcVmXZEIquZCxSZy"));
    this->PfJTeeVdjpMiCZ(-1926113066, string("FIxdolfPplefyQxOSBgmOfvdbLcNcFxXxeJpTeKAiKtDXznOaZMiAWBIRSwAVAGjWQhymHbAVgRLXUGwkzElvvyDrK"), string("GslZBprjBJsJVVPSjleKJJ"), -705214.9708678193);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EglCQfik
{
public:
    double YmPWnVqPqRKtyP;
    int OxRqjQRoBaJVVoA;

    EglCQfik();
    string HReBBMbDZt(double LLUCYIAKZs, string whbFIh, bool GVoydCNljrE);
    int RqmNpCmVGlPcPI(int NVgbNRg, string evnmabIiiFf, int kNfTlSwVMwwIgk, double XfRmHXyZydgrZXQE, double okkIPvAaQ);
    string pXrFBoTmtnudmbgm();
protected:
    string EgYAwexcGsS;
    bool XeaMCFICkSWTrpV;

    double KmhrDqL(string KWYCAWrZoKSzbXiJ, double QwXxeINYVU, bool jJcilOfQ, double ulHEicnBYMAfBBs, bool qFhgFFyGm);
    string gCCjTWRWY(double WFBtjYa, double HlIAHLl);
    void FnlSLiqTBd(bool geLVVfICe, string jQhqrzhPKudRFz);
    bool xQraSYWynNrUeZS(double ktxFJPDEeLhUVa, string fuoFNhjDkfWF, int mJyUMYezEGQkVT);
    double rTKfonKBMKfdbECf(int YnDLffBmYSWX, double VegjwKQVDEaz, string MwtPVhFKLvFvv);
    double EQIPZX(double nXOzIic);
private:
    int HgaRVJfHeevmPV;
    string dxpqdTRMkoCcrE;
    string NfGzSBbXYE;

    int RHnZysKCETOsIGh(string OGipUPqrXAM, int bIJenUErDjLSf, string vvEue, bool FuRDxcwftQd);
    int fvrAFVUxWoPz(double LPiOGOjZQjtV, bool NUGKLrbdjYBdHpi, string zEzTlTkaheCYP, double OnTjYStQC, bool CsqtS);
    string pPAkws();
    bool EsrNZODFfY();
    void lCyjF(bool ZHJNvPpafR, bool QGoNArcP);
};

string EglCQfik::HReBBMbDZt(double LLUCYIAKZs, string whbFIh, bool GVoydCNljrE)
{
    bool rPRKJbw = true;
    bool nxWUe = false;
    bool lOoWKQea = true;
    string MoNTccQIlLwxq = string("mfDUHZFBWYRJEMTqjOhpxicFqJjGtemJPSXpWJNQbpfSsxllHzdAPoTddbCLEfuvEPd");
    double lVvzseNQyYcggwA = -469893.88831312896;

    for (int hBlFFwJcPi = 742319343; hBlFFwJcPi > 0; hBlFFwJcPi--) {
        lOoWKQea = GVoydCNljrE;
        whbFIh = whbFIh;
    }

    for (int nvZszBRuFLg = 678900259; nvZszBRuFLg > 0; nvZszBRuFLg--) {
        rPRKJbw = GVoydCNljrE;
        nxWUe = nxWUe;
    }

    for (int FeoRbhEUYem = 1728194580; FeoRbhEUYem > 0; FeoRbhEUYem--) {
        continue;
    }

    return MoNTccQIlLwxq;
}

int EglCQfik::RqmNpCmVGlPcPI(int NVgbNRg, string evnmabIiiFf, int kNfTlSwVMwwIgk, double XfRmHXyZydgrZXQE, double okkIPvAaQ)
{
    double rlnDBABJMhZ = 840360.1102925289;
    bool WoikWZReqauKr = false;
    bool bfUiPPgRGIzywW = false;
    string qGmBGg = string("QTnQiYxlQTFaCPIbyxkizrcLIVuJzYXFjhpnTKegHYlKvfcDXVSExUjfcPrBWZNyhKAmUhPilqKCvUlHXQkONdPVgiGAFereoEGKwMAQJJyeWLFMI");
    int CmwQLEBVLZbAH = 766619639;
    string QsJVmnudiO = string("XPyahsNioVsNxZPXWHTdAeCARDWVhMRSZTlHMamIofYNoKiYdbOfALNjaqaRexbfeGlbgCezcWkpPqoMSodvOJSPezTYRinCSwlPibbjXzcbhbVUWglvtrkRiNWJCeaZDgGfalOIjjgQuZceGIFEKpQZaJEPEvJRjhyNDlxSqvEIlCpcALEPJNEAfdEB");

    for (int hzjlgJwlDtuS = 430398614; hzjlgJwlDtuS > 0; hzjlgJwlDtuS--) {
        continue;
    }

    return CmwQLEBVLZbAH;
}

string EglCQfik::pXrFBoTmtnudmbgm()
{
    double GYTzir = 362001.29589376925;
    string WtZlDEHOJXTN = string("KuFcqBdhsYIVDuOtgGtgQpSjsmpOZudYtw");
    bool EenmGziVKOZVwW = false;
    string KPODKTkhvLgW = string("hfJzxKsKrfXpIAtKcyrVHXYxSAYxFsOLuIWoLjyeOmWYVzmncAYzobRcTVkbaQjfDcRpyhInNLMLwKVhueMIPLYyYZJBlTmuBynfCeWgTez");
    int AeKWJecIcvLAuJc = -1002055173;
    double IbupQmWTDjN = -183882.03548088775;
    string hPoLOSAbpzcDtfE = string("oSzQtHFlIuGQMfhHUOFkvcVIKnqtJBvwrLBCobiaeAfanmCIgjOwUvrLqHXnOpCBqYZgCGGOEjpekavTpqdNSmjXhtlcqDUnnQZFFLDfPAKAEMpKoqCnJPiZXm");

    for (int iXCEDU = 368593393; iXCEDU > 0; iXCEDU--) {
        continue;
    }

    if (GYTzir == -183882.03548088775) {
        for (int gYpeVYvfMlvm = 1062077528; gYpeVYvfMlvm > 0; gYpeVYvfMlvm--) {
            hPoLOSAbpzcDtfE += hPoLOSAbpzcDtfE;
            KPODKTkhvLgW = WtZlDEHOJXTN;
        }
    }

    if (hPoLOSAbpzcDtfE < string("hfJzxKsKrfXpIAtKcyrVHXYxSAYxFsOLuIWoLjyeOmWYVzmncAYzobRcTVkbaQjfDcRpyhInNLMLwKVhueMIPLYyYZJBlTmuBynfCeWgTez")) {
        for (int iaTKZ = 58645683; iaTKZ > 0; iaTKZ--) {
            continue;
        }
    }

    for (int aeltbi = 1575260047; aeltbi > 0; aeltbi--) {
        hPoLOSAbpzcDtfE += WtZlDEHOJXTN;
        GYTzir += GYTzir;
    }

    return hPoLOSAbpzcDtfE;
}

double EglCQfik::KmhrDqL(string KWYCAWrZoKSzbXiJ, double QwXxeINYVU, bool jJcilOfQ, double ulHEicnBYMAfBBs, bool qFhgFFyGm)
{
    int UgZdVHZsnJLGptDK = 565103390;
    double vfuJMFweMcp = -205003.5564445371;
    bool JtjIIlCmOVczGmf = true;

    if (qFhgFFyGm != true) {
        for (int MojzvMlxTuGgAr = 1342416220; MojzvMlxTuGgAr > 0; MojzvMlxTuGgAr--) {
            vfuJMFweMcp /= QwXxeINYVU;
            jJcilOfQ = ! qFhgFFyGm;
            QwXxeINYVU = ulHEicnBYMAfBBs;
            ulHEicnBYMAfBBs += vfuJMFweMcp;
        }
    }

    for (int yYjhyugGflNjZnj = 1145029380; yYjhyugGflNjZnj > 0; yYjhyugGflNjZnj--) {
        KWYCAWrZoKSzbXiJ += KWYCAWrZoKSzbXiJ;
    }

    for (int wTLdlslKYQUVMuVx = 1869446161; wTLdlslKYQUVMuVx > 0; wTLdlslKYQUVMuVx--) {
        continue;
    }

    for (int pjSjW = 1524445055; pjSjW > 0; pjSjW--) {
        KWYCAWrZoKSzbXiJ += KWYCAWrZoKSzbXiJ;
        jJcilOfQ = ! qFhgFFyGm;
        jJcilOfQ = qFhgFFyGm;
    }

    if (QwXxeINYVU <= -1023039.6595861886) {
        for (int zLOBtMGPoel = 77330298; zLOBtMGPoel > 0; zLOBtMGPoel--) {
            UgZdVHZsnJLGptDK *= UgZdVHZsnJLGptDK;
            qFhgFFyGm = ! qFhgFFyGm;
        }
    }

    return vfuJMFweMcp;
}

string EglCQfik::gCCjTWRWY(double WFBtjYa, double HlIAHLl)
{
    double uwgbZlZDrrVKhDU = -706656.1206565264;
    string ZFxEDYijqfK = string("cPGmdOnIvnQPYbJVYYDkEAosnqtxggkTelIRQKqeBCgvajcpbvGhsDcyEXPliFezqexVIaIybuIRFegRQWfRhsLCKZSjmqbHpYQuXFLGSNzShSvzZyNIZHYSopENxoD");
    int WaISodrTyAwdS = -1483547706;

    for (int nErrZcRBQi = 969808463; nErrZcRBQi > 0; nErrZcRBQi--) {
        HlIAHLl += uwgbZlZDrrVKhDU;
        uwgbZlZDrrVKhDU -= uwgbZlZDrrVKhDU;
        uwgbZlZDrrVKhDU *= WFBtjYa;
        WaISodrTyAwdS += WaISodrTyAwdS;
    }

    for (int XcsuwvvSX = 1570357923; XcsuwvvSX > 0; XcsuwvvSX--) {
        uwgbZlZDrrVKhDU = uwgbZlZDrrVKhDU;
        WFBtjYa = WFBtjYa;
        WFBtjYa = WFBtjYa;
    }

    if (ZFxEDYijqfK == string("cPGmdOnIvnQPYbJVYYDkEAosnqtxggkTelIRQKqeBCgvajcpbvGhsDcyEXPliFezqexVIaIybuIRFegRQWfRhsLCKZSjmqbHpYQuXFLGSNzShSvzZyNIZHYSopENxoD")) {
        for (int NpUyoNThkbDyEg = 720175114; NpUyoNThkbDyEg > 0; NpUyoNThkbDyEg--) {
            HlIAHLl -= uwgbZlZDrrVKhDU;
            uwgbZlZDrrVKhDU += HlIAHLl;
            ZFxEDYijqfK = ZFxEDYijqfK;
            HlIAHLl /= uwgbZlZDrrVKhDU;
            uwgbZlZDrrVKhDU += uwgbZlZDrrVKhDU;
        }
    }

    for (int vVMqqkObIfJT = 916846785; vVMqqkObIfJT > 0; vVMqqkObIfJT--) {
        uwgbZlZDrrVKhDU *= uwgbZlZDrrVKhDU;
    }

    for (int xMsujPvM = 470287598; xMsujPvM > 0; xMsujPvM--) {
        uwgbZlZDrrVKhDU /= HlIAHLl;
        WFBtjYa -= WFBtjYa;
    }

    if (HlIAHLl >= -952680.3486032971) {
        for (int Pohfavxl = 607170554; Pohfavxl > 0; Pohfavxl--) {
            WFBtjYa = HlIAHLl;
        }
    }

    if (uwgbZlZDrrVKhDU < -706656.1206565264) {
        for (int ZfSmiMkKAtLCZKfl = 1870344171; ZfSmiMkKAtLCZKfl > 0; ZfSmiMkKAtLCZKfl--) {
            ZFxEDYijqfK += ZFxEDYijqfK;
            WFBtjYa /= WFBtjYa;
            WFBtjYa = uwgbZlZDrrVKhDU;
            uwgbZlZDrrVKhDU /= WFBtjYa;
        }
    }

    return ZFxEDYijqfK;
}

void EglCQfik::FnlSLiqTBd(bool geLVVfICe, string jQhqrzhPKudRFz)
{
    bool ttOyiIJH = true;
    string iMaYOlEzdKd = string("bzWoBaWHZVAObTxSwbWOBpUSTiXtpUBdpNbAkHnDzUHfVuQuPURKkjHsiwilasMXUakbWXdIluCvAVndm");

    for (int KXuPuWgfQZlWkc = 526696648; KXuPuWgfQZlWkc > 0; KXuPuWgfQZlWkc--) {
        geLVVfICe = ! ttOyiIJH;
        geLVVfICe = geLVVfICe;
        ttOyiIJH = geLVVfICe;
        geLVVfICe = geLVVfICe;
        iMaYOlEzdKd += iMaYOlEzdKd;
        iMaYOlEzdKd = iMaYOlEzdKd;
    }

    if (geLVVfICe == true) {
        for (int AoytgeaWOezYAKKa = 333097396; AoytgeaWOezYAKKa > 0; AoytgeaWOezYAKKa--) {
            jQhqrzhPKudRFz += jQhqrzhPKudRFz;
            jQhqrzhPKudRFz += iMaYOlEzdKd;
        }
    }

    if (ttOyiIJH != true) {
        for (int wEjTzKmHjRY = 299857038; wEjTzKmHjRY > 0; wEjTzKmHjRY--) {
            jQhqrzhPKudRFz += jQhqrzhPKudRFz;
            ttOyiIJH = ttOyiIJH;
        }
    }
}

bool EglCQfik::xQraSYWynNrUeZS(double ktxFJPDEeLhUVa, string fuoFNhjDkfWF, int mJyUMYezEGQkVT)
{
    bool iPSEtGBATLe = false;
    string CnSfs = string("iqkrZBCpFBHxKhMYRJbWOeyEImuSAJIfgEZklYgYNxVLkZzXGaYWvnZmsPJJjnCjGRxtMOtRJpjKmQWFjNHSqsejpcQWTVoxhPKBtRMrEqqUlRFfnSxEoKmWbPKQHnCYFRGcTnpyGTVugtcpxeWrHYVXWSlmKzIsGyLIibUNigTJhsCjBHQOSJOQVMXVYnEGQywTrEHIDEVoBVSvWKGxOSbIQyqiHBfutPhNOwhOQv");
    int Vaavjqe = 180944839;
    bool LzOCWmkHPueZclMb = true;
    bool evQoMbmVrJ = true;

    for (int krpqKVXvUTEBl = 340408461; krpqKVXvUTEBl > 0; krpqKVXvUTEBl--) {
        LzOCWmkHPueZclMb = ! evQoMbmVrJ;
    }

    for (int IauclPsksrHEG = 1953141760; IauclPsksrHEG > 0; IauclPsksrHEG--) {
        continue;
    }

    for (int PBXVVVwmm = 187927541; PBXVVVwmm > 0; PBXVVVwmm--) {
        continue;
    }

    if (fuoFNhjDkfWF < string("iqkrZBCpFBHxKhMYRJbWOeyEImuSAJIfgEZklYgYNxVLkZzXGaYWvnZmsPJJjnCjGRxtMOtRJpjKmQWFjNHSqsejpcQWTVoxhPKBtRMrEqqUlRFfnSxEoKmWbPKQHnCYFRGcTnpyGTVugtcpxeWrHYVXWSlmKzIsGyLIibUNigTJhsCjBHQOSJOQVMXVYnEGQywTrEHIDEVoBVSvWKGxOSbIQyqiHBfutPhNOwhOQv")) {
        for (int AJUysSKCNoVyq = 605089851; AJUysSKCNoVyq > 0; AJUysSKCNoVyq--) {
            continue;
        }
    }

    for (int XTRzQcucPHPTnsu = 1753690577; XTRzQcucPHPTnsu > 0; XTRzQcucPHPTnsu--) {
        evQoMbmVrJ = ! evQoMbmVrJ;
        iPSEtGBATLe = evQoMbmVrJ;
        Vaavjqe -= mJyUMYezEGQkVT;
    }

    return evQoMbmVrJ;
}

double EglCQfik::rTKfonKBMKfdbECf(int YnDLffBmYSWX, double VegjwKQVDEaz, string MwtPVhFKLvFvv)
{
    bool BtjBIQoKEK = false;
    int NiEkBvRe = 1773561334;
    int CprAmPxBJ = -1516557509;
    int gyNzlSUcDSeLETkZ = 1726828;
    int mfyaOytqKBjJoe = -1262473342;
    int AoZHwCgbhhlXxcA = 66673239;
    int LGYVgyRU = -1233216696;

    if (mfyaOytqKBjJoe > 1981658355) {
        for (int pWSfG = 130844319; pWSfG > 0; pWSfG--) {
            NiEkBvRe *= LGYVgyRU;
            LGYVgyRU = NiEkBvRe;
            gyNzlSUcDSeLETkZ += AoZHwCgbhhlXxcA;
        }
    }

    for (int hBskpiwlokNdhDLD = 1333105544; hBskpiwlokNdhDLD > 0; hBskpiwlokNdhDLD--) {
        AoZHwCgbhhlXxcA -= AoZHwCgbhhlXxcA;
    }

    return VegjwKQVDEaz;
}

double EglCQfik::EQIPZX(double nXOzIic)
{
    string FCNEqaCTKcEZszOI = string("RhpVZXxRqrJieeHLOiVcdIiOSnqcyfRpZlOvAYLInQxxzSDslNolTmjofQEmWlNGzcrOwbqIDwLBoWdNMfraZyijJRrlCXgvplyuGkYfEyXMVjYYjcBFTvdiEWaMjrVrIQXEJcctHNOPFsaXZ");
    double jGKyd = -317242.8227869845;
    string ZuImb = string("XmYKImmuMmMOmvfIkGvKzKqKIIxlgmIsgwRTUWVbuIdZgMLirPxnFOmVlnExKTkuYpbDTNTcsMKTqptbAKcoFsQWyfJYDQnhJOhhSXWodHlrqJuQSAARxOfnvUupBsbLoDtkFGxeRWcoJdErqXDBVBnDeF");

    if (nXOzIic > -317242.8227869845) {
        for (int yGZYNoSrrS = 1259119471; yGZYNoSrrS > 0; yGZYNoSrrS--) {
            continue;
        }
    }

    for (int gFZwNHxmh = 708601447; gFZwNHxmh > 0; gFZwNHxmh--) {
        FCNEqaCTKcEZszOI = FCNEqaCTKcEZszOI;
        nXOzIic *= nXOzIic;
    }

    if (jGKyd > -317242.8227869845) {
        for (int HUnANgE = 329762760; HUnANgE > 0; HUnANgE--) {
            jGKyd /= nXOzIic;
            nXOzIic = jGKyd;
        }
    }

    if (FCNEqaCTKcEZszOI <= string("RhpVZXxRqrJieeHLOiVcdIiOSnqcyfRpZlOvAYLInQxxzSDslNolTmjofQEmWlNGzcrOwbqIDwLBoWdNMfraZyijJRrlCXgvplyuGkYfEyXMVjYYjcBFTvdiEWaMjrVrIQXEJcctHNOPFsaXZ")) {
        for (int WWNpp = 509031838; WWNpp > 0; WWNpp--) {
            FCNEqaCTKcEZszOI += FCNEqaCTKcEZszOI;
            FCNEqaCTKcEZszOI = ZuImb;
            FCNEqaCTKcEZszOI = ZuImb;
        }
    }

    if (jGKyd <= -202663.37383946916) {
        for (int LeqSHZMeL = 1476665005; LeqSHZMeL > 0; LeqSHZMeL--) {
            nXOzIic *= nXOzIic;
            ZuImb = FCNEqaCTKcEZszOI;
            nXOzIic *= jGKyd;
            FCNEqaCTKcEZszOI = ZuImb;
        }
    }

    for (int KYZdhkBQvSSyHRF = 1427876698; KYZdhkBQvSSyHRF > 0; KYZdhkBQvSSyHRF--) {
        jGKyd *= nXOzIic;
        jGKyd *= nXOzIic;
    }

    return jGKyd;
}

int EglCQfik::RHnZysKCETOsIGh(string OGipUPqrXAM, int bIJenUErDjLSf, string vvEue, bool FuRDxcwftQd)
{
    bool cCAyepq = true;
    string QLDLgFJ = string("LuPjYLAULxhJjVmfeDSillbRRZbahXMyyZqoawiboVCtWuveCpdeACdkEbzqUJnVOhmmNePFlczfNC");
    int AdhrvjeFlN = 343661581;
    string tILCXeQZCtQy = string("dPGdwupOgFeGlWQmIzcMZYTpECJCAOFedDMQzBGnvProKTyiwjkfvrQFritEizqWFguKETYLmkEAiXjxaptbMoYQfSkmCIoWusldYlrBRbSovLYNQUjJTSYFkELtiOHAyEzaBMVFtluRCUsFVWAOkABpNKRNBeSrIMtryrdjGJLJuRYYuvQIeQaUKHoOFErZvsNoyVSkqYULCNulOVXVMVNMBqduoDexWkxiekMTUDyVvs");
    string pzqeW = string("kNKJDyQQGSfTTmqTBszfrRCqiYGemESGngkVdUgGSLAWiTGWafevFlOdCBzOMypdVrcHtlPwpOVmJxBPhoTFxKedsEDSuQQpEnsSiwbxBTusnHsHgNBLfobcDfbCweaMMFGKNohgimDDjPFhOMxUGAqwDGQNLXYsTuCufbhrBoDkspnRChBUSnktWKgmokusxvFmbYYzZmIxubGvMD");

    if (vvEue != string("kNKJDyQQGSfTTmqTBszfrRCqiYGemESGngkVdUgGSLAWiTGWafevFlOdCBzOMypdVrcHtlPwpOVmJxBPhoTFxKedsEDSuQQpEnsSiwbxBTusnHsHgNBLfobcDfbCweaMMFGKNohgimDDjPFhOMxUGAqwDGQNLXYsTuCufbhrBoDkspnRChBUSnktWKgmokusxvFmbYYzZmIxubGvMD")) {
        for (int pzWeJ = 1031844932; pzWeJ > 0; pzWeJ--) {
            continue;
        }
    }

    if (vvEue != string("dPGdwupOgFeGlWQmIzcMZYTpECJCAOFedDMQzBGnvProKTyiwjkfvrQFritEizqWFguKETYLmkEAiXjxaptbMoYQfSkmCIoWusldYlrBRbSovLYNQUjJTSYFkELtiOHAyEzaBMVFtluRCUsFVWAOkABpNKRNBeSrIMtryrdjGJLJuRYYuvQIeQaUKHoOFErZvsNoyVSkqYULCNulOVXVMVNMBqduoDexWkxiekMTUDyVvs")) {
        for (int pKMKUP = 881116671; pKMKUP > 0; pKMKUP--) {
            OGipUPqrXAM += OGipUPqrXAM;
            cCAyepq = ! cCAyepq;
            bIJenUErDjLSf += bIJenUErDjLSf;
            cCAyepq = FuRDxcwftQd;
        }
    }

    for (int HhvIbBIHwXMylVW = 997094540; HhvIbBIHwXMylVW > 0; HhvIbBIHwXMylVW--) {
        cCAyepq = FuRDxcwftQd;
    }

    return AdhrvjeFlN;
}

int EglCQfik::fvrAFVUxWoPz(double LPiOGOjZQjtV, bool NUGKLrbdjYBdHpi, string zEzTlTkaheCYP, double OnTjYStQC, bool CsqtS)
{
    bool iIQqslZH = true;
    bool ElOsSLEhXRefORv = false;
    double fFYmIUNJMxSmqtvT = 753992.0413902127;
    int gpIVLPDxngncLQY = 1245640793;
    string izKBHCYKxfLr = string("XiFkdFJBlUtVYTZqIMhYXwroUBfldobbqphcpVktQUVVCTSImqnXCPxiJOSBDGPaEYOEvzVRYJSOyEfXDGVrwzkFhSxzmSUuhscxdwsbKXBtamTldOkSGlrvRywGGTvXcrgSZwmGlobZxdRvYQgYiirz");

    for (int BPAYUbRywIkrt = 1366015908; BPAYUbRywIkrt > 0; BPAYUbRywIkrt--) {
        continue;
    }

    for (int ANeWMrGFOWkmY = 2146424155; ANeWMrGFOWkmY > 0; ANeWMrGFOWkmY--) {
        ElOsSLEhXRefORv = CsqtS;
    }

    return gpIVLPDxngncLQY;
}

string EglCQfik::pPAkws()
{
    bool UfRFSqQUVTeRxpN = false;
    bool cPNsH = true;
    int wEijfYiZdANr = -1745199986;
    string zUfFRMrgNSWWmv = string("wrUooVJJvhpwxDzddvecininIyUseeqhCiMBYzvihlxlLAzVdEpCjQvuIfAHHKUetoXeXDmMaqlnYANFtorjsIVyyKazVJhMevLlManvNNSEEyRfHMxvDNzHwsItnYyCQcxOMkPAduuzvLkpWmkEDIJRQltIBEjeCyfUsoiToeviCBDUIvxsmZypLbKERqrhnKhdpzygnRGguinwBlRNgLtyMeu");
    bool OmROglqSYENZ = true;

    for (int SzZHEOlIvtOTBHj = 1481134081; SzZHEOlIvtOTBHj > 0; SzZHEOlIvtOTBHj--) {
        UfRFSqQUVTeRxpN = UfRFSqQUVTeRxpN;
        OmROglqSYENZ = ! UfRFSqQUVTeRxpN;
        UfRFSqQUVTeRxpN = ! UfRFSqQUVTeRxpN;
    }

    return zUfFRMrgNSWWmv;
}

bool EglCQfik::EsrNZODFfY()
{
    bool avKcHoUMuM = false;
    int XXytx = -2137584276;
    int iVHBpnNpbAfKlhg = 244587117;
    int NFkanvEtvKJk = -1895910851;
    string NJBJqoULTm = string("lrtVyGNdlTAnIzbCARQAGXesNeQFzoTPbhhNUXBCKzWANhYLwNndWmKIzCTFwGgKKfhEmgSXsQiBaiVgDjIgivbQVBMtcejhwBswPIZjzXlwHxtfQyRKaWbtErWqDfYYTiOhjfNzmKsgLpPoVVMENkgOavMENczuQkdowtvVAGCjMtrCqdcGCOlWvXvwcKVrstZqSwaTRDyRCVsPbcxkzilHegWwgRdnWHIuDyeAPXDyNuPqmKpS");
    string yOPFgF = string("HihukRbIhehBCFnakzfjYftzHNvzStRkNAEPXXYcCPFWWcALaCGDoaZlHTlIqAXznJcnEdOegHeKtZgHMKcdYbsvaHzgvakzAnTLOrbrqhfXLbZqxQzBctvfsDlDytRkrSKyYIAKnvAxjASJlAGtwZxgCGJUJEkhAmldcYebvzWjZEOcPfWfgtIfvQcFGBpMTRtSyrp");
    string ebhgIPEeG = string("HmdcwoTWxEuaJSoPmcZodIIBjhOSchpUycaUirktDvMriFLaquIyDNlxJMsTozLClcFqObkYDrXILDMssAsyFwBZzIDJlGoQISoSxZXxZKMGDKilvKXdPcfuqwZcOdTIecATzCdPXpnYgpbAIfbHQbhBdyJbEcVzGrcecAzrDKqeWHKfuDgEoIaqUSrrOduGVPuacNlmpeDUpUPA");

    for (int VScEKO = 306153338; VScEKO > 0; VScEKO--) {
        iVHBpnNpbAfKlhg += XXytx;
    }

    if (ebhgIPEeG < string("HihukRbIhehBCFnakzfjYftzHNvzStRkNAEPXXYcCPFWWcALaCGDoaZlHTlIqAXznJcnEdOegHeKtZgHMKcdYbsvaHzgvakzAnTLOrbrqhfXLbZqxQzBctvfsDlDytRkrSKyYIAKnvAxjASJlAGtwZxgCGJUJEkhAmldcYebvzWjZEOcPfWfgtIfvQcFGBpMTRtSyrp")) {
        for (int fTSAnHSDlqW = 1853713053; fTSAnHSDlqW > 0; fTSAnHSDlqW--) {
            ebhgIPEeG = yOPFgF;
            ebhgIPEeG += ebhgIPEeG;
        }
    }

    for (int TRssXybRwwd = 635023332; TRssXybRwwd > 0; TRssXybRwwd--) {
        XXytx -= iVHBpnNpbAfKlhg;
        NJBJqoULTm = NJBJqoULTm;
    }

    return avKcHoUMuM;
}

void EglCQfik::lCyjF(bool ZHJNvPpafR, bool QGoNArcP)
{
    int VTYlFqddnyy = 717206043;
    double SRUViYWff = -295473.3500353591;
    string RyaNeFjwzwfpK = string("CCWFetsuzTemXvxIwFzGLcEzyqdVGtspWrLvvcnUFUICdNbHub");
    string kwLVcrErKsocJE = string("foLsoDkYalKCUCicMeqGNykbPgtNakUIIHWkylmMsbVSrumDGWGPLjGmkCrRllaHtdoYLbXrxNQLiuQnxkMvjvReWSUJtNZUAFiylUPrFHWNQcLsSUVSICzZTHUNZfVvbHsCyG");
    double EwUAf = 938385.1295139221;
    bool vzKqCNpmc = false;
    bool IPcMEVub = true;
    int OczeRBYkSeK = 1249216357;
    bool guOQVcAWjGg = false;
    double OwUFebzOj = 337067.57871011586;
}

EglCQfik::EglCQfik()
{
    this->HReBBMbDZt(538930.7149520944, string("GbMrnVUwA"), false);
    this->RqmNpCmVGlPcPI(1636576770, string("wGShPKbyQJKkGWjioHcjQEpcgvNoWmluUlhNZPuxGVnHZpzQHvCnIxoWeusnThsnUDvvAJigmVzRzIuX"), 2046181785, -1009936.5535010077, -621272.7504360675);
    this->pXrFBoTmtnudmbgm();
    this->KmhrDqL(string("tSyrqdiHSbOKBrwsGOsllhAXgBgaShDdJFZSmWSaLBOWZiGWLxiFmnNyjpicCplJKZitCjZCtZUhXFdXPLbBBnfPZaoHslRFOgsNFHrwSVwQDyLQnMytxqaKRoEtrcNONKbRjGESMOixBxxfAQewkLsZjyiDemkmhjoeyqndSfNaHwpL"), -1023039.6595861886, true, 750920.5319192809, true);
    this->gCCjTWRWY(-952680.3486032971, -886986.5570965172);
    this->FnlSLiqTBd(true, string("KqYYgTQuhFvSVtWohmdIUfFSAsOVlMlFllMpnZtLmNluijKxfMFHwiQaPugGbeTaiCvtxLMRNzIYOUdyQIkLqXvuNipXoCycOzfuyJRWpaRpOuxnHFHlmIqnVBeByNWjzGanJmrtLstsGpBaYILwjmruQSsiKmbbz"));
    this->xQraSYWynNrUeZS(-752991.3898644118, string("XqxnmWePUfuQVUdMBcFGeiWPVlNjMozUfFTeIBapnCflTVnJFiWGWqZiqJquA"), -291067012);
    this->rTKfonKBMKfdbECf(1981658355, 8612.354245374394, string("JCfhPfwFiuPmLvBgFtuUtTdWTlWpRZAKiYDTDvFzfJSYzTFWZFuZopjxuNDUHzkYYpdnXvspIbqROPctUXkzbDuKuGkeXErCaCOdvxoFNacfeQpxgvlSkgcYbdvSzGiltOTZPwePWszlKBzlWvlynyaHXCvfhMSOcMI"));
    this->EQIPZX(-202663.37383946916);
    this->RHnZysKCETOsIGh(string("lhUuCZhXwOWJzEfIrPmcpIMkMNjHkFyWoTUbifNItVdaMTWaxNDTwpKoJKBHCNTuCMZnwXWGElZJhpOEMFZjnJeISmbKzezwMTVEAdqMfNtcyIYwmyWKCYnSSBywyYImoLHeDTDiaarOjZNHMAKIyhhdlyDCcFLjSWvKkUGgqkmkzcePwKkdfDBQgrSxIaTNNcIGGxcCsQubXPgiDbpjSSXtYQGBCuFHUvbexWWZ"), 565413730, string("xL"), false);
    this->fvrAFVUxWoPz(226705.5631419339, true, string("HtfkeHpjHaBdcyIOoURrtJQTUmNlXbBDNVeTRwXZsiNttfUPDolODtkokLwNVAVkJcgPJZGjsxwzNQXdGblLhIurEgQyZhMVqaivjhvyOABtqSLgSReGfpPWqCDpIUgMAQXppTwzZuSfoyMFPdSUolQyKgxtATMtEXAeQWHHxgCCfo"), -529448.2212121814, false);
    this->pPAkws();
    this->EsrNZODFfY();
    this->lCyjF(false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aRsxq
{
public:
    double sFYTFtZSAhcVX;
    bool JoCufvwNxrJVHsrU;
    bool jAKwnrLFFbjXNmeD;
    int CsPQVRwiXAYBN;

    aRsxq();
    void laOYRFOU(double ZOKXNbGekdEs, bool AgtRk, bool dDQzdJ, int iZPwJUcdQdH);
protected:
    double twqTqxuIgcYSMKf;
    bool qnWBjbJeKt;

    string iwSTtV(int FgpfmlBoGyySXmbN, string Otmfok, double Nevlojuz, double ooXgqdMGnZireGp);
    int GSdxaHAzvuGBuS(double BmRtDjRzvD, double XZbkiXrRtxef, string PTFtE);
    int nviBjOKqZRwdufo(double uCIkGDURnFwUA, int JzEKq);
    void FVNfUWqzuCKnj(string krjoATvjGAPpjk, string bbGUO);
    double tbVPVpwFFF(int VeqbJfcFkyqP, bool iUVoIDqbJ, int mxUNegXqEsoOs);
    int ufwKcbBovXR(int nUTiZaf);
    double WBJkOPpArcMkvx(int ByiYDbQAeSSMTll, int DAdyrXdIItZ, bool NkcKlLInfWoYmDCv, string ekNLkyCYd);
    bool uFtsIoHiv(int lRbZsLpE);
private:
    int HNzTIsbX;
    bool hfSqvoFfwW;

    int kchAMfnsOCkH(string BgNJeuJUfHeUQA);
    double XbSLuvAVqErzuysE();
};

void aRsxq::laOYRFOU(double ZOKXNbGekdEs, bool AgtRk, bool dDQzdJ, int iZPwJUcdQdH)
{
    double VZatQZOTiFR = -99388.85255186903;
    double ThzAqmaT = -761140.8194124025;
    bool OEuhiaBVkjOXzN = false;
    bool nqKHjpMZWBqdQTj = false;
}

string aRsxq::iwSTtV(int FgpfmlBoGyySXmbN, string Otmfok, double Nevlojuz, double ooXgqdMGnZireGp)
{
    int nreMUnRDXFZ = -1827453812;
    int eTtPxckUNdR = -1877647657;
    double VYfQFnLmVPUB = 18422.567675213926;
    double wZnlzBbEZPQ = 946947.0463868594;
    double HmZQVvPklJdfdSou = -386316.7478646127;
    string XLhFnwCrklZ = string("aKroDsPJGOKBvSBMpsjSqbgs");
    string gptchJQbwqDeEt = string("YMsLNwMkRiDfWuqHQiAtlnRvqrlRpDiQgMpvNvTgEVtynlaZUfeRPIEVSzHKodecRjOmbzfpUBnCrSLDKSzCCIWLhdGPdsVIQOEsgCBOabrYTluGYKZJmtGQBtUZDpsNYkoDkFMjhOVJVTAMERXuAsBWyQnicYsApmOpQdlHclRZamscBFcvshpNmiFVMWgTUTYT");

    if (FgpfmlBoGyySXmbN >= -1827453812) {
        for (int IITqhOgW = 2009154176; IITqhOgW > 0; IITqhOgW--) {
            ooXgqdMGnZireGp -= VYfQFnLmVPUB;
            wZnlzBbEZPQ -= Nevlojuz;
            gptchJQbwqDeEt = Otmfok;
        }
    }

    if (Otmfok > string("aKroDsPJGOKBvSBMpsjSqbgs")) {
        for (int tVvps = 1080624216; tVvps > 0; tVvps--) {
            Otmfok = XLhFnwCrklZ;
        }
    }

    return gptchJQbwqDeEt;
}

int aRsxq::GSdxaHAzvuGBuS(double BmRtDjRzvD, double XZbkiXrRtxef, string PTFtE)
{
    double lDlKlSk = 93943.94624454105;
    double XaRdl = -1043102.6370640245;
    double rSkoYXZybRlHzFK = -1039966.5541294378;
    string pAgQHsBoSAE = string("ATrWrpDeKMebzTbceunNbguvbJWLPeLXpnrvqEHxbNPgBQfqGEOsdgldUhtZsGqpaaIqGgBeuDOZAEImPJATBnTsSjmXlTxSTuzknwsavxhFUtaGddxstweIlRdLJplFFYjfPKLkBGsiWpbaKWLXnQrOwtoiteJmiXhPYfTSkQtDULujZFjuP");
    double SctfUdWFuNB = -319692.078661332;
    double WwibdiHoEYw = -274814.1925344947;
    bool UIcCVQkOin = false;

    if (rSkoYXZybRlHzFK > -274814.1925344947) {
        for (int JbUfnGgmcjrPcflg = 1946410101; JbUfnGgmcjrPcflg > 0; JbUfnGgmcjrPcflg--) {
            WwibdiHoEYw += WwibdiHoEYw;
            rSkoYXZybRlHzFK -= WwibdiHoEYw;
            SctfUdWFuNB *= lDlKlSk;
            rSkoYXZybRlHzFK = XaRdl;
            SctfUdWFuNB *= lDlKlSk;
            BmRtDjRzvD /= lDlKlSk;
            SctfUdWFuNB /= lDlKlSk;
        }
    }

    for (int gbcdNYDQOGIX = 445520233; gbcdNYDQOGIX > 0; gbcdNYDQOGIX--) {
        XaRdl = SctfUdWFuNB;
        lDlKlSk = WwibdiHoEYw;
        SctfUdWFuNB /= BmRtDjRzvD;
        WwibdiHoEYw = lDlKlSk;
        BmRtDjRzvD = XZbkiXrRtxef;
        XZbkiXrRtxef *= WwibdiHoEYw;
        SctfUdWFuNB *= BmRtDjRzvD;
        WwibdiHoEYw -= lDlKlSk;
    }

    if (BmRtDjRzvD == -1043102.6370640245) {
        for (int SfWEYXZySVDhs = 1247394116; SfWEYXZySVDhs > 0; SfWEYXZySVDhs--) {
            BmRtDjRzvD *= lDlKlSk;
            SctfUdWFuNB += XZbkiXrRtxef;
        }
    }

    for (int yBToivBJxj = 2136739677; yBToivBJxj > 0; yBToivBJxj--) {
        XZbkiXrRtxef -= lDlKlSk;
        WwibdiHoEYw -= WwibdiHoEYw;
        XZbkiXrRtxef = lDlKlSk;
        SctfUdWFuNB += XaRdl;
    }

    return -349979173;
}

int aRsxq::nviBjOKqZRwdufo(double uCIkGDURnFwUA, int JzEKq)
{
    bool zRverxIUEYNH = false;
    double CIhtbwNVCHGm = -486171.5717356607;
    bool QzmmierW = true;
    string VgQZfvwU = string("iFPNEahADPqRQXZqYGFKgfyKrLVmPCCUQLSBsqXvHWlbCjosrxTYyPUQVvciXKxgffHTkMYItmaICtWuLSzbtsKRSnrIFNzoIvMsgUvsIYRvzhgNSHrazlDtSjzDctqrYiDvoeIzUEKdaDndQJheLvnpfcCmGifpinFzZzhfkUHJuRpSWx");
    string heYtQVhJcF = string("KAGzfBhiEhEbCeOmtJDJclfgbJiHalpMhRqFLpsgcVECkLhscQcOjrdWpyzZzqjwnffrtqPdHUbdwQQbDMTeDyVEsLwFDJaKRNNasdnATxIvHzUQnQbJlmVkdaZiExvtniLRYXKlyaZSDoBgLIhgmIxjYSXXeyXdpFWGrMccPFpXKTwcMeGcaobMODjefuvsSmEVOWaGOGhxkLjTCHytRCrFKFoCttxWCeYBHJxIxs");
    string mhVSvlIUtOKLA = string("qLNczAkcETO");
    bool MrhscaQElBMxk = false;
    int IoOOQDfZBKDut = 822616290;
    bool wGUnfseB = true;
    bool OBtCEVRX = false;

    if (MrhscaQElBMxk == false) {
        for (int TBazINcaI = 912847694; TBazINcaI > 0; TBazINcaI--) {
            continue;
        }
    }

    for (int uGGNyOzh = 7661382; uGGNyOzh > 0; uGGNyOzh--) {
        JzEKq += JzEKq;
    }

    for (int pspHrts = 1623634526; pspHrts > 0; pspHrts--) {
        zRverxIUEYNH = MrhscaQElBMxk;
        mhVSvlIUtOKLA += mhVSvlIUtOKLA;
    }

    return IoOOQDfZBKDut;
}

void aRsxq::FVNfUWqzuCKnj(string krjoATvjGAPpjk, string bbGUO)
{
    int PycRGTRNVcoVC = 214919092;
    bool uXQrFzk = false;
    bool QgRRdYyM = false;
    bool epwwmnB = false;
    int PQlMYBKDhuQp = 304895229;
    string DDNafrPrN = string("tiXUfNXEkrPpKGOnMNJqhanNGBUsrOMtClKTbtGjpcHWKbQlquzJFsmTUDQzjTnrGPddsLCKaBvyCsJmkjeKJPdBwtkPfIpTuFJCcMcKBwWEfLBjlUKktrMlSICBGkVjNqbsfxTIwX");
    string znnKQbCLsJkiDC = string("aZkzhQMCHLdnEAuxUEgXmeSLXpZZGyAMLEgwwwPjaEOcNoyxYIwNUSHgCQQhHebJLBAJNhJhdQXFKiuBZgpzhFvysSlXqAdDcYUcdERvdjKDUFAGAwsiWKGXEOlPwJjSKHJqFwgOVeisOWXLGSPyhCthCUGBroCwuQjyCVlMjZybMCEFbu");
    bool asHeyX = false;
    bool VafiDTSRGKGmlJyQ = true;

    for (int ZckQtpKPS = 1802821946; ZckQtpKPS > 0; ZckQtpKPS--) {
        znnKQbCLsJkiDC += bbGUO;
    }

    for (int FxtKOxottUanDiCY = 1890959703; FxtKOxottUanDiCY > 0; FxtKOxottUanDiCY--) {
        VafiDTSRGKGmlJyQ = ! epwwmnB;
        VafiDTSRGKGmlJyQ = ! QgRRdYyM;
        VafiDTSRGKGmlJyQ = VafiDTSRGKGmlJyQ;
        epwwmnB = QgRRdYyM;
    }
}

double aRsxq::tbVPVpwFFF(int VeqbJfcFkyqP, bool iUVoIDqbJ, int mxUNegXqEsoOs)
{
    int LMEwl = -1739297915;
    bool XfNRluxSlzRYXpW = true;
    bool nZZqoklbGyWT = false;
    double xQQMSoQ = -319460.26279021136;
    bool toHOgRS = false;

    if (LMEwl == -973061775) {
        for (int SzHWXoWWz = 99689599; SzHWXoWWz > 0; SzHWXoWWz--) {
            iUVoIDqbJ = ! toHOgRS;
            XfNRluxSlzRYXpW = ! toHOgRS;
            XfNRluxSlzRYXpW = iUVoIDqbJ;
            mxUNegXqEsoOs *= VeqbJfcFkyqP;
        }
    }

    if (toHOgRS != false) {
        for (int SpJhnqOSPWYgSJjS = 1111345896; SpJhnqOSPWYgSJjS > 0; SpJhnqOSPWYgSJjS--) {
            LMEwl += VeqbJfcFkyqP;
            XfNRluxSlzRYXpW = ! iUVoIDqbJ;
        }
    }

    for (int bhWdkiSsTzncdg = 2066744769; bhWdkiSsTzncdg > 0; bhWdkiSsTzncdg--) {
        nZZqoklbGyWT = ! iUVoIDqbJ;
        VeqbJfcFkyqP *= mxUNegXqEsoOs;
        VeqbJfcFkyqP *= mxUNegXqEsoOs;
        XfNRluxSlzRYXpW = ! nZZqoklbGyWT;
    }

    if (iUVoIDqbJ == false) {
        for (int VOpYceBhkW = 406706782; VOpYceBhkW > 0; VOpYceBhkW--) {
            continue;
        }
    }

    return xQQMSoQ;
}

int aRsxq::ufwKcbBovXR(int nUTiZaf)
{
    double AjRrKxkhUIYpgCB = 515286.05710728996;
    int rDCDTgigxNkAHAym = -1075726181;
    double JoHumS = 327258.535530349;
    bool NRQgIKCJtg = false;
    double oHBYVrqwg = -1019642.3495423247;
    double UBFIyNSpenoTEJ = -856533.9934712078;
    int thxTctYQPXRw = -108045834;
    string dPIiGR = string("oDyipMfBydnnShyCbNxdrNIfgddcrMtPLpMkEnQwdrzldkqnGzGMauJFKfZKUlFiC");

    for (int nmeNC = 830461026; nmeNC > 0; nmeNC--) {
        UBFIyNSpenoTEJ = UBFIyNSpenoTEJ;
    }

    return thxTctYQPXRw;
}

double aRsxq::WBJkOPpArcMkvx(int ByiYDbQAeSSMTll, int DAdyrXdIItZ, bool NkcKlLInfWoYmDCv, string ekNLkyCYd)
{
    double XBpTHbBbmWbbeYUp = 590048.9444873604;
    int LcuNjohuAXO = 1111893133;
    string qvDNSfQGBfOtJVN = string("HLbfpiuxehQDEfAkMRPbDrUfYPncJXIfZSNYjOhdATgyECLULfGjBsPlPyfCzbffqZpOTtDubyIYRPpsPCAGoQNZYnUmGGIqLtppjALKqQlKmWgJlSizzmyYLIpJgWhAoaIBnwMFAkEUmnUPIDPFZjLW");
    bool BFUDiQJMSb = false;
    int bnBMhthJfvrTFKD = -2069306100;

    return XBpTHbBbmWbbeYUp;
}

bool aRsxq::uFtsIoHiv(int lRbZsLpE)
{
    string vGdUwtW = string("gJOOpumAxTsZtMcBnKTpqlfMgREtZMMvNzswWPfLjUNvFlMjJfNNNXzOufjjHRANxTOjXMhetPtWFhVGKQkUJIilILwJKuvKtvkIKIIvPoLQDjiqwIJfDEPrjUryZSkVlQHLPZTNaCNijIqQIyHnpPvNFHGYffpRrtlZvJPShNFyZJBpbsKdADcSVrOQlAc");
    double ZJwxWrmW = -275548.6982689788;
    int TLRMdxiUA = 2143181292;
    int oklTjswa = 1253273006;
    bool bzwrLfjOXGBzH = false;
    double foBPJqMUOiJ = -791848.920102009;

    for (int YcHamUi = 180076725; YcHamUi > 0; YcHamUi--) {
        bzwrLfjOXGBzH = bzwrLfjOXGBzH;
        bzwrLfjOXGBzH = ! bzwrLfjOXGBzH;
        oklTjswa -= TLRMdxiUA;
    }

    if (oklTjswa != 1253273006) {
        for (int BccSwjrbjCRxm = 1030325183; BccSwjrbjCRxm > 0; BccSwjrbjCRxm--) {
            lRbZsLpE -= lRbZsLpE;
            lRbZsLpE += lRbZsLpE;
        }
    }

    if (bzwrLfjOXGBzH == false) {
        for (int BuTKIyKfOlE = 1584724778; BuTKIyKfOlE > 0; BuTKIyKfOlE--) {
            continue;
        }
    }

    return bzwrLfjOXGBzH;
}

int aRsxq::kchAMfnsOCkH(string BgNJeuJUfHeUQA)
{
    bool nQGiQREmxzAOnte = true;
    int iACynQb = 1666178693;
    bool gMCknTdCbDysFg = true;
    double WTzQOJoQo = 782639.8517592166;
    double hinitHqD = 885975.2028556395;
    int iVFRvKxacgkpb = -771116231;
    bool nsuZsjSWdeji = true;
    double docpRCDjywNuc = 962107.5498688453;

    if (docpRCDjywNuc == 962107.5498688453) {
        for (int lkAVeLJGmLJNp = 1116518178; lkAVeLJGmLJNp > 0; lkAVeLJGmLJNp--) {
            continue;
        }
    }

    for (int dXDubpJmfrCLE = 378331359; dXDubpJmfrCLE > 0; dXDubpJmfrCLE--) {
        nQGiQREmxzAOnte = ! gMCknTdCbDysFg;
        BgNJeuJUfHeUQA += BgNJeuJUfHeUQA;
    }

    for (int BvJnLyeVs = 1937796286; BvJnLyeVs > 0; BvJnLyeVs--) {
        nQGiQREmxzAOnte = gMCknTdCbDysFg;
    }

    return iVFRvKxacgkpb;
}

double aRsxq::XbSLuvAVqErzuysE()
{
    double Nyvint = -413634.33282832353;
    bool CtpuYIzkmBJUh = true;

    for (int HDtxRGBY = 49669583; HDtxRGBY > 0; HDtxRGBY--) {
        Nyvint += Nyvint;
        CtpuYIzkmBJUh = CtpuYIzkmBJUh;
        CtpuYIzkmBJUh = ! CtpuYIzkmBJUh;
    }

    if (Nyvint != -413634.33282832353) {
        for (int ooioyHlmI = 1518086847; ooioyHlmI > 0; ooioyHlmI--) {
            Nyvint /= Nyvint;
        }
    }

    return Nyvint;
}

aRsxq::aRsxq()
{
    this->laOYRFOU(-926397.0185480354, false, false, -2123296460);
    this->iwSTtV(-1724640077, string("TKuJSGesgQImbwGmAfMWlQyEeEecoSxSDpKRMvpkTjZFETgqfHtOsirghdHLzGKXiQmbJopnaHUuEYqprjcXcTPBMmXpqvzVjPMmfzcDyUTHdnmdWeslLFuyqPjNBNntGXbmXmdEQEkxfxlMiuWyRIvH"), 146389.34666561094, 1000263.2274414995);
    this->GSdxaHAzvuGBuS(392337.0254684947, -161896.81467447168, string("DxdMiJIdHyXuVkXoatOeNSvBulfYJciEeISQxQwqtFjOLHpLDJCawguuqvTZckLmJsDBVwVZuULRxoOEHcEnCywxrYCMjpimFSlLoydJDTxAQqpNylNrFodAhSwDlFKMRvkKDYfoFHQAXQgFsRzMunkdZDAaEYRsYnVoVyxyPHezLDoASTTYidPckNPyrDuAtYTIdyAqLVOjNhgNMQeiQxHwJPVcAnszYoTrnMVfqxKjwpzDoTW"));
    this->nviBjOKqZRwdufo(-834739.0493294256, 816084273);
    this->FVNfUWqzuCKnj(string("gltTnSizhTPTcmZCbhrVvNfrSGDlVTCZOopqwtaVJOtoatflrcjPeHwLZWPrknoodwBDMPpMQQdGMnZpbmPnbGGbXAHXQdBwoHWwHybFwsUZFqcP"), string("AlxTrXEmCWnhwDFedoOsxxoZLRiRXIiEzQDKxRwAxvmDdZswHEfuYYITudXoDhOTtWrclxszhkgRiyikkGdXOCeeWmcwcrGLlsChrNZwaHrWYWHraxdHLLxzeQUZriMKukumlmmaovcJmuPZmCMTLgKqSbtacbiFVIaoYDdSwGQWPpaonKRRxuCGqcGKDNKTeHgiQSJzf"));
    this->tbVPVpwFFF(-973061775, false, 1077576509);
    this->ufwKcbBovXR(-1720909474);
    this->WBJkOPpArcMkvx(-2052979140, -413839562, true, string("WppQYgFDFgnvaIzVABRXXEXDJqasnpbfXGeePnwtrDLTvguZQLElIu"));
    this->uFtsIoHiv(933327207);
    this->kchAMfnsOCkH(string("huADdCuGaObBRimeVYPwDVChUquxdecM"));
    this->XbSLuvAVqErzuysE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gNwJtkVxrWkzGym
{
public:
    string WvoWKzCKkCoD;
    double YAqYewHFusFMdkxb;
    string yczez;
    double BTtzrg;

    gNwJtkVxrWkzGym();
    bool vymWAbXu(bool XbtjBUxZZJdhRRy);
protected:
    bool tyqvxasy;
    double HgNtLnjKKzo;
    double Qgnzxgc;

    int OnfbgZkoZoGGYpDZ(int FzdaCPoGepRAJJj, bool cCsHekfWbRHDnGO);
    void CrnBFzgmNJeAE(bool BdTEQ, string TAvga, int AlFaDrvMoXXQY, bool KJUAarFEHwjToLMb);
    double vzqIMA();
    bool yqcCEYoOmbAqQ();
    bool ShfBIXyUlO(double NiAkru);
    void lVHKZnpnW(int qDAokZpqrviFJt, bool mVVeRgKdIfq, int FtYdVcrf, string WnovFUIg);
private:
    bool naOHyuHFUgeQggeZ;
    string wgMZcMZhpERaMTFM;
    int TtQeIeRIyLyuq;
    double dNBEdjLAsRbtGP;
    double xkDVlxusrqlIzb;
    string SFkKrLtOOWjtT;

    int OgEeHxfyhSisr(bool OHMPhWTRsk, int SWXcGxkmi, string rELbtHNNDibi, string HNpqfHMQXkNl);
    bool QXxaid(string PnPDfNoK, int EwEvhdISV, double RhwGRu, bool AdiMLt);
    string PzySAHJMMUbPK();
    double EpHEDKFGv(double QBYbicZoqZInJ, double RMenHvt, bool zeSngWqF);
    int XaZOWcqk(int RZBLdUBuEth, double pvpicolCSQpuKumI, double TrRUol, string CbJDno, string ZBzcXXBtZvfyAIsL);
};

bool gNwJtkVxrWkzGym::vymWAbXu(bool XbtjBUxZZJdhRRy)
{
    string UnKmZ = string("rIkaQcEERhERtjbAhdIBOdNgoONYPSPSHIzBIKGoMasrKPGfJrElONlbKWqldimVmQwVMXlWcwYCdEvYUPyPVrOpIaugfTyHFElWsQfgcTbYDrrlusdYGFSRuAQLrUzEpmTrxtOhzOdadcVESOMGcFkSmfDgLLwlRgrCpJYQlZLyCzIlcoAIEicJqMxhIVPBRJgYRWxVOliqOBkXrClKFsIBfoGeuHTvDvPIkWGZbXhIFAFIekrMaKwsjjo");
    string MNQFrUxbJUI = string("kcOOEPEhXEzKivmTqkbuQTLYVKBdvOFVrFNvaNuiTMlZSnSpGTHFhURolLEgSKcOpGFHBNHkPbuISETSMqadZnPghsZpvTFuHvLIMwsawCoXEcCUfKuzQHBtQXMZAoXJgjAWMfilvlZvykFgtAH");
    bool GXyczSZ = true;
    string HojbJwhCIGK = string("RirOvjiwgRMlgNiIxFQyWlFuHFztMXhigVEsUjEuCqxnjzJrDtXgpLDnIcFaAvmGdyAotELIOqEHJUdUBNnGiLUXOoKlDkwTfsSRhoALjkJMMrgWkmyPhBdbsnsJmgUeANVGYSnqJNpeetGHDCPTqATJKvAPEyDqSreUjibpIgwyOhCuYsPMZmlpzJKmNdSQshiKZciymIbsjsDgvJcZIxPmounWgsDYIydZifIYBuGeRNsIYrPEe");
    double EBLSCFsqGQ = -724524.1781503524;
    string gYYuzMBdTRXRBqCs = string("nobMexQfZPqgzTBuLHiuiOGjCFXjAVRxfbyvfBgBrjZyinCmwpZcosAlNJqXLPGHCHLleyrtDPSvZThJxgHVmQiNiZmSJDdtLALWrImECB");
    int pqrBIpAyXzRKvxBQ = -1004588951;
    int RxPeHNWwReEfvD = -1145591295;
    int macDVWOCpNMLgM = 398257411;

    for (int fNKBdI = 572172457; fNKBdI > 0; fNKBdI--) {
        UnKmZ += gYYuzMBdTRXRBqCs;
        UnKmZ = UnKmZ;
    }

    for (int GhJdqnRjarPByJD = 1783950359; GhJdqnRjarPByJD > 0; GhJdqnRjarPByJD--) {
        continue;
    }

    for (int bcBvqQHIDtHkb = 2008847861; bcBvqQHIDtHkb > 0; bcBvqQHIDtHkb--) {
        continue;
    }

    return GXyczSZ;
}

int gNwJtkVxrWkzGym::OnfbgZkoZoGGYpDZ(int FzdaCPoGepRAJJj, bool cCsHekfWbRHDnGO)
{
    string pgqySERUDAUbni = string("UEOiGywfvIMIzZBMPdkaUouWfiBhVzzqIFrGzrDboWPtyMJeKolBMgeKumNrMPUEyzoUmQzBZowUTNDzSGBXmqhIvlYfvZxeYTwVXXrYRejXjtcyljOoxmZK");
    string LkbHzAiC = string("oroaICVVRISitHMoPOmGLjEpAUUeVNzcbIFTWEYGxRwLQLABIsFyYgaUlwRMmxRotVEwZRKMDEbhUNsWKhKuTrREmQufxOikpFjWgdIlvgVvjdJQxLahLmBAxEsfEmCOgcDMmrWCgzXtmNvsSjDOnABiUzRpVBylSKEcmyFscULspwYAvdiqhDK");
    bool BOaPireer = false;
    bool lojJuzFDpxwB = true;
    bool KRkLJNyYcKCmAV = true;
    string giKPkOJkeqTi = string("ceQSfLlXWBSRZAmhXWJRisvrXYwyPAJgISPvhHHlfHIDAGOFbohJJoFCdlSdIBCuvOjzpJmvtVScTxmbaYHUvsiXQokbAMNJocjnDdlTioxzDObPq");
    bool lvblGtTitCNzbXKG = false;
    bool yaAGrizpznzvxP = false;
    bool mrZyN = true;

    for (int pybCMjZlv = 1225537873; pybCMjZlv > 0; pybCMjZlv--) {
        mrZyN = ! BOaPireer;
        lvblGtTitCNzbXKG = lojJuzFDpxwB;
        KRkLJNyYcKCmAV = ! KRkLJNyYcKCmAV;
        lojJuzFDpxwB = lvblGtTitCNzbXKG;
        giKPkOJkeqTi += pgqySERUDAUbni;
    }

    for (int SynuyDfafBHRt = 672565849; SynuyDfafBHRt > 0; SynuyDfafBHRt--) {
        BOaPireer = ! BOaPireer;
    }

    if (cCsHekfWbRHDnGO == false) {
        for (int EqTPIrcTpYYAN = 1249666089; EqTPIrcTpYYAN > 0; EqTPIrcTpYYAN--) {
            KRkLJNyYcKCmAV = lvblGtTitCNzbXKG;
            giKPkOJkeqTi += giKPkOJkeqTi;
        }
    }

    if (mrZyN != false) {
        for (int ZULfTUlsj = 190191967; ZULfTUlsj > 0; ZULfTUlsj--) {
            lvblGtTitCNzbXKG = ! BOaPireer;
            LkbHzAiC = giKPkOJkeqTi;
        }
    }

    for (int ZQSwEEFFIgk = 1523294794; ZQSwEEFFIgk > 0; ZQSwEEFFIgk--) {
        KRkLJNyYcKCmAV = ! cCsHekfWbRHDnGO;
    }

    if (mrZyN != false) {
        for (int zFlCGypRbJEt = 1443031251; zFlCGypRbJEt > 0; zFlCGypRbJEt--) {
            giKPkOJkeqTi += LkbHzAiC;
        }
    }

    return FzdaCPoGepRAJJj;
}

void gNwJtkVxrWkzGym::CrnBFzgmNJeAE(bool BdTEQ, string TAvga, int AlFaDrvMoXXQY, bool KJUAarFEHwjToLMb)
{
    string NKxYPRVuvIDELYTi = string("FKADESTwEmfATbobaJYuNDLVuMngAHlaKISaazTLSViMqOyjCwbzpPQTVgPMyOFrsDrqujVcpjwBLUFhyLtZyDTiKelMKSvFhcJtbSNelf");
    bool xNYUNHRW = false;

    if (KJUAarFEHwjToLMb != true) {
        for (int muaWlWO = 77264702; muaWlWO > 0; muaWlWO--) {
            TAvga += TAvga;
            TAvga += TAvga;
            KJUAarFEHwjToLMb = ! KJUAarFEHwjToLMb;
        }
    }

    for (int XEOZnavhxyirBALS = 2099380356; XEOZnavhxyirBALS > 0; XEOZnavhxyirBALS--) {
        NKxYPRVuvIDELYTi += TAvga;
        BdTEQ = KJUAarFEHwjToLMb;
    }

    for (int EmPoY = 1886031246; EmPoY > 0; EmPoY--) {
        xNYUNHRW = KJUAarFEHwjToLMb;
    }
}

double gNwJtkVxrWkzGym::vzqIMA()
{
    int gbLvbp = 2146470471;
    bool HuUNlil = true;
    string LqqdQskl = string("YcPbUxtecivISBWlfWAwiWVoBGOpbZRIdtokLkrpxyXTPRqwjcZioBYcIhNQztFHOaYjwAndNNgAIJNxiOZIypPbyrmcTtyQtZYPoAKovSvCOSgJnSwsvQuNIEbclWPYvVMbNPGmdyoLjssorGe");
    bool FhACviLhKp = true;
    string TReCPzJT = string("UOYJDLaiTrtXpSMnWUIfsARHGQlPWoMSFxWTOJIDYEdMCAdaAXTxPEoILNbgcafvwpADdrQjhhJxypKooj");
    double WcxOwk = -6064.142765832569;
    string NTNZU = string("MgHIVfRLYlQfsZfsgamCowgiRvGMrgzYJMqwfs");
    int LUnde = -581366137;
    string OsjdlsxKjUDsBo = string("okYdXxGSMRoAagilPRxhkqmWRbvWHYgZlVgHNwwxgJJMkkmQHAtQlDNXUsSyHtKFMWGJgyWgHsRmBgAlYSHXfHxwJcrhzrSSqsMnATSUpACPKeMNuIFlIYjMCltqOpBLZLTaiPFBwfXUzaLHWGXz");

    for (int KwTfLTExf = 941438155; KwTfLTExf > 0; KwTfLTExf--) {
        FhACviLhKp = FhACviLhKp;
        TReCPzJT = NTNZU;
        LqqdQskl += TReCPzJT;
        TReCPzJT = TReCPzJT;
    }

    return WcxOwk;
}

bool gNwJtkVxrWkzGym::yqcCEYoOmbAqQ()
{
    double XPWDKJjvOEYSSI = -794677.9377754028;
    double giAtqCw = -627820.2249095667;
    string erUMXGEkU = string("sdeBOOVeJpGctBuKgawnKQtVEgghnojJeQrmjyHNpvvHGoIbFLXDbROHMTHbSufnoLUmKgGFtAPYxREzLsgFSvNgSEyKEEKSAURbLvuqCHlbrJbJatsHglXocokSFASGKqk");
    double rhKujgjQOn = -976899.6930866005;
    string nuAUpeKl = string("gpihNlVptKLqKHvngiwNieVRaScnDOLvOaRakScBcVBeKbxQacsokIniziSqmeabKsyPpyqZBmuxydPshdlmBXFvPscDwhDOMjAqMugyuRSavtRLqwCiBnlAWuzaMxsQoGfELjuygRypVykltSPCMXSiFTEhOhkVVewpuLmlDsqMIGjCVWWipOWbmSSCsLRYOVCKfyQxUbjeBUFFNCvyT");

    if (rhKujgjQOn > -627820.2249095667) {
        for (int MhqnWOWHFRKDn = 1059926898; MhqnWOWHFRKDn > 0; MhqnWOWHFRKDn--) {
            giAtqCw -= XPWDKJjvOEYSSI;
        }
    }

    if (XPWDKJjvOEYSSI < -627820.2249095667) {
        for (int dUfeSBidT = 633870305; dUfeSBidT > 0; dUfeSBidT--) {
            rhKujgjQOn -= giAtqCw;
            giAtqCw = XPWDKJjvOEYSSI;
            erUMXGEkU += nuAUpeKl;
            nuAUpeKl = nuAUpeKl;
        }
    }

    for (int eYzpUgDALA = 572317883; eYzpUgDALA > 0; eYzpUgDALA--) {
        erUMXGEkU = nuAUpeKl;
    }

    return false;
}

bool gNwJtkVxrWkzGym::ShfBIXyUlO(double NiAkru)
{
    string Lgpim = string("pDsnPuNkQpAvPJoHYdcNFWLBCrXlyIlAQQVtRzrCvXplYUpIhzMNq");
    string YVwemaDMudkPaO = string("iXxOzKUSiCnyNDfmDtefknk");
    double HPUpPk = -68363.0109922313;
    int yFdmANNbeGHiEn = -1351783918;
    int fsDZQuCGwfSMTYo = -1981013382;
    bool aFqhC = true;
    bool YKdanfkAkUim = false;
    double zjSutKBcxZypKjNj = -835761.1135313082;

    for (int JuRfQsQiGm = 1986746344; JuRfQsQiGm > 0; JuRfQsQiGm--) {
        NiAkru *= zjSutKBcxZypKjNj;
        HPUpPk += zjSutKBcxZypKjNj;
        zjSutKBcxZypKjNj += zjSutKBcxZypKjNj;
    }

    if (YVwemaDMudkPaO != string("pDsnPuNkQpAvPJoHYdcNFWLBCrXlyIlAQQVtRzrCvXplYUpIhzMNq")) {
        for (int yGVXnkaAFGPGZydF = 1671402863; yGVXnkaAFGPGZydF > 0; yGVXnkaAFGPGZydF--) {
            aFqhC = aFqhC;
            YKdanfkAkUim = YKdanfkAkUim;
        }
    }

    for (int hqMKPEdeCqyRVrtu = 1373097652; hqMKPEdeCqyRVrtu > 0; hqMKPEdeCqyRVrtu--) {
        fsDZQuCGwfSMTYo /= fsDZQuCGwfSMTYo;
    }

    for (int HIuWmQFxX = 586160233; HIuWmQFxX > 0; HIuWmQFxX--) {
        zjSutKBcxZypKjNj = NiAkru;
    }

    for (int HyyxeQapuGy = 52448086; HyyxeQapuGy > 0; HyyxeQapuGy--) {
        zjSutKBcxZypKjNj = NiAkru;
        YKdanfkAkUim = ! aFqhC;
        YVwemaDMudkPaO += Lgpim;
    }

    return YKdanfkAkUim;
}

void gNwJtkVxrWkzGym::lVHKZnpnW(int qDAokZpqrviFJt, bool mVVeRgKdIfq, int FtYdVcrf, string WnovFUIg)
{
    bool NAzlOtQKJNfQBhwo = false;
    int EtCFulI = -379752156;
    double jNInb = -38817.77216751691;

    for (int LdlVJntGVW = 765304422; LdlVJntGVW > 0; LdlVJntGVW--) {
        NAzlOtQKJNfQBhwo = ! mVVeRgKdIfq;
    }

    for (int fXqCgWbIySVBN = 361915731; fXqCgWbIySVBN > 0; fXqCgWbIySVBN--) {
        qDAokZpqrviFJt *= FtYdVcrf;
    }

    for (int chsMB = 593048204; chsMB > 0; chsMB--) {
        EtCFulI = EtCFulI;
    }

    for (int VzcGu = 1227290030; VzcGu > 0; VzcGu--) {
        WnovFUIg = WnovFUIg;
    }

    for (int MDdAqkWwXkJFf = 116091695; MDdAqkWwXkJFf > 0; MDdAqkWwXkJFf--) {
        continue;
    }

    for (int ZbTQfm = 1943366882; ZbTQfm > 0; ZbTQfm--) {
        FtYdVcrf += EtCFulI;
        qDAokZpqrviFJt += qDAokZpqrviFJt;
        FtYdVcrf -= EtCFulI;
    }
}

int gNwJtkVxrWkzGym::OgEeHxfyhSisr(bool OHMPhWTRsk, int SWXcGxkmi, string rELbtHNNDibi, string HNpqfHMQXkNl)
{
    string NNcrKHxcnhx = string("WeDmZIqXRmaQKHuTPkkCRcpIfkVJudRqPenNkOhCpBYfcdmeNzy");
    bool sPAwQU = false;
    double AgxtIrAakKiiXz = 489482.4887812395;
    double hSeVYWU = -62932.98071710888;

    if (rELbtHNNDibi == string("aEpjSAhxINylMZHxiTmlDTCqKHKTbiqkozWIBjCrBlfAuDljnebYByoafFzfBgkmJpkNmTAmpztSlHnuvdFRwqCoLaLdTXFTZIBRXCOxtckgOaMyrxDnJloSUPjNEDATqoocgPCfIbPMSfeZXTzXCPNArMmiJhVcjFB")) {
        for (int eURMvo = 1089361445; eURMvo > 0; eURMvo--) {
            hSeVYWU += AgxtIrAakKiiXz;
            hSeVYWU -= AgxtIrAakKiiXz;
            HNpqfHMQXkNl += rELbtHNNDibi;
        }
    }

    for (int zMZbKpxs = 39063903; zMZbKpxs > 0; zMZbKpxs--) {
        sPAwQU = ! sPAwQU;
    }

    for (int JPdZapYFAbgLf = 1092970645; JPdZapYFAbgLf > 0; JPdZapYFAbgLf--) {
        AgxtIrAakKiiXz *= hSeVYWU;
    }

    for (int KxNGsavTusFFK = 1334336844; KxNGsavTusFFK > 0; KxNGsavTusFFK--) {
        continue;
    }

    for (int LIgpDOYuDJovChY = 2010904961; LIgpDOYuDJovChY > 0; LIgpDOYuDJovChY--) {
        AgxtIrAakKiiXz *= hSeVYWU;
    }

    return SWXcGxkmi;
}

bool gNwJtkVxrWkzGym::QXxaid(string PnPDfNoK, int EwEvhdISV, double RhwGRu, bool AdiMLt)
{
    bool ZLKzf = true;

    if (RhwGRu < -301859.51554951357) {
        for (int kNkAbMG = 763090397; kNkAbMG > 0; kNkAbMG--) {
            EwEvhdISV *= EwEvhdISV;
        }
    }

    for (int EBxicErlU = 1416228845; EBxicErlU > 0; EBxicErlU--) {
        continue;
    }

    for (int kkybUFrvkDp = 461989518; kkybUFrvkDp > 0; kkybUFrvkDp--) {
        continue;
    }

    if (PnPDfNoK == string("IXUijeOmQfHCGsEBOITymbYYUekyI")) {
        for (int YeKEBmlBM = 1166037929; YeKEBmlBM > 0; YeKEBmlBM--) {
            ZLKzf = ! AdiMLt;
        }
    }

    return ZLKzf;
}

string gNwJtkVxrWkzGym::PzySAHJMMUbPK()
{
    bool FyxWEIxTILWthAK = false;
    double iHTbaAmLA = -855458.4893202486;
    int FdNPuNwp = -398427590;
    bool paapyRwXHjHEmOLk = false;

    if (iHTbaAmLA > -855458.4893202486) {
        for (int VBYZFXQWi = 1227238943; VBYZFXQWi > 0; VBYZFXQWi--) {
            iHTbaAmLA = iHTbaAmLA;
            paapyRwXHjHEmOLk = ! FyxWEIxTILWthAK;
            paapyRwXHjHEmOLk = FyxWEIxTILWthAK;
            FyxWEIxTILWthAK = ! FyxWEIxTILWthAK;
        }
    }

    if (iHTbaAmLA <= -855458.4893202486) {
        for (int vzzwmxUiFdiOz = 715397955; vzzwmxUiFdiOz > 0; vzzwmxUiFdiOz--) {
            FyxWEIxTILWthAK = ! FyxWEIxTILWthAK;
            FyxWEIxTILWthAK = ! FyxWEIxTILWthAK;
        }
    }

    if (FdNPuNwp != -398427590) {
        for (int anwVn = 1849399247; anwVn > 0; anwVn--) {
            FyxWEIxTILWthAK = ! paapyRwXHjHEmOLk;
            iHTbaAmLA = iHTbaAmLA;
            paapyRwXHjHEmOLk = FyxWEIxTILWthAK;
            paapyRwXHjHEmOLk = ! paapyRwXHjHEmOLk;
        }
    }

    return string("CpXwwsStRSGaHnKtgNKtAHGAPZjYNpN");
}

double gNwJtkVxrWkzGym::EpHEDKFGv(double QBYbicZoqZInJ, double RMenHvt, bool zeSngWqF)
{
    string KyLKAyfswleDs = string("TfDOTPznsIkSKuRiDCqzAqVAbtnPNRZjJVWmjPGtDvZvgfanGfRPDUtkfKofczAHDBsVXVjOwunNtbPHBlwnqSMUQWCfVNbtczhKLXaqoCfFDE");

    for (int RDrKEWBvZsJNkEeD = 787875301; RDrKEWBvZsJNkEeD > 0; RDrKEWBvZsJNkEeD--) {
        RMenHvt /= RMenHvt;
    }

    if (KyLKAyfswleDs < string("TfDOTPznsIkSKuRiDCqzAqVAbtnPNRZjJVWmjPGtDvZvgfanGfRPDUtkfKofczAHDBsVXVjOwunNtbPHBlwnqSMUQWCfVNbtczhKLXaqoCfFDE")) {
        for (int jftImWZqvpOshxw = 1473395140; jftImWZqvpOshxw > 0; jftImWZqvpOshxw--) {
            KyLKAyfswleDs = KyLKAyfswleDs;
            QBYbicZoqZInJ += RMenHvt;
            RMenHvt += RMenHvt;
        }
    }

    if (QBYbicZoqZInJ == 587635.1394058842) {
        for (int ynDETb = 1480788399; ynDETb > 0; ynDETb--) {
            zeSngWqF = zeSngWqF;
        }
    }

    if (QBYbicZoqZInJ > 500235.6109835043) {
        for (int itFfAqbpUeygu = 1729750774; itFfAqbpUeygu > 0; itFfAqbpUeygu--) {
            continue;
        }
    }

    return RMenHvt;
}

int gNwJtkVxrWkzGym::XaZOWcqk(int RZBLdUBuEth, double pvpicolCSQpuKumI, double TrRUol, string CbJDno, string ZBzcXXBtZvfyAIsL)
{
    int jWOvPOqEXzl = 219958803;
    int CFVToPXDwzllRIP = 731316225;

    for (int CueuJAkmBn = 1205457755; CueuJAkmBn > 0; CueuJAkmBn--) {
        CFVToPXDwzllRIP += CFVToPXDwzllRIP;
    }

    for (int BZkIBLjou = 1327043305; BZkIBLjou > 0; BZkIBLjou--) {
        CFVToPXDwzllRIP += jWOvPOqEXzl;
    }

    if (CFVToPXDwzllRIP < 219958803) {
        for (int DzHkboHZJMplXL = 561480421; DzHkboHZJMplXL > 0; DzHkboHZJMplXL--) {
            RZBLdUBuEth += CFVToPXDwzllRIP;
            RZBLdUBuEth /= RZBLdUBuEth;
            ZBzcXXBtZvfyAIsL += ZBzcXXBtZvfyAIsL;
            RZBLdUBuEth *= jWOvPOqEXzl;
            jWOvPOqEXzl *= jWOvPOqEXzl;
            RZBLdUBuEth = RZBLdUBuEth;
        }
    }

    return CFVToPXDwzllRIP;
}

gNwJtkVxrWkzGym::gNwJtkVxrWkzGym()
{
    this->vymWAbXu(true);
    this->OnfbgZkoZoGGYpDZ(2078685510, false);
    this->CrnBFzgmNJeAE(false, string("NrXjMeMCArQxGALUhqJMZoBVaAaBtSPPWIrjLGDwFMEzKEoLorCvcAJDzYaboZqhymNdAcSlDuCriBNtnMARPPdkFGLwCnAssudLrddfBQuyMwtLrQwjlYnikwtefMmQWtbMptDlbDffNTCNXHNmZQqHpYSRDYVmWfXzSYbZbtSyodZRwkyqpzGukWFmonKtOcfTQkWsJJiwQaxOJJBzKbGzNDGxlrYJdOdztScLoxtQjfzoSDtop"), -1260418725, true);
    this->vzqIMA();
    this->yqcCEYoOmbAqQ();
    this->ShfBIXyUlO(-201811.4409951699);
    this->lVHKZnpnW(1082141829, true, -611403175, string("pMlWxrtKLbodEbtJcGtoUVXMwWHGVmcAMWTuRGCjZNwdBYLZUoXnWpQDgaMOLNSMMNLsOUryGRmUvnZYqSdXODdSGzQInBtAwxLFrJAEdeCoKSAdtlbFofbKMuhVxevgEBCErMevEOJDWcHugAvNeVzCCTeTpZOoaWAXiDejNeZweduYUXctsLkzmsRTrWyHYIWJevQZM"));
    this->OgEeHxfyhSisr(false, -1500955977, string("aEpjSAhxINylMZHxiTmlDTCqKHKTbiqkozWIBjCrBlfAuDljnebYByoafFzfBgkmJpkNmTAmpztSlHnuvdFRwqCoLaLdTXFTZIBRXCOxtckgOaMyrxDnJloSUPjNEDATqoocgPCfIbPMSfeZXTzXCPNArMmiJhVcjFB"), string("fuqRXeVOcOGmdkKXXWKdZlWnOcamzwsQYAsojdAAJaBstlpKFOAOUThhTMGXkALkgZxJBuRkINPEFiFQuqCsAsSILDCCfEnEpvGJvxwrrmBwjImeIyCZaJIwWKipUFtpqniCxttlEHfUgvErhsdmNZAwayAJwpfBRzerniacBGgtkImnqJLsQppYyyIGjJpBWQKhgBtQKcsSAttvPtCaqDPxZbLRXHFFgkZT"));
    this->QXxaid(string("IXUijeOmQfHCGsEBOITymbYYUekyI"), 913349768, -301859.51554951357, true);
    this->PzySAHJMMUbPK();
    this->EpHEDKFGv(500235.6109835043, 587635.1394058842, true);
    this->XaZOWcqk(-989910043, 855137.9178615538, 149587.88438505266, string("eCirsxaAmIxUsAPbDrqjUnAgpndbcrGpTvTiarjDaBRwCKqMcUNUQDrKPetiJbRiSxkmNoCaEbzoghEFIdklfSiQpIAqwDHjwbzROvZvvINpMhelvfwPromJvEFThvPyfkLJGVHNCRRimnZukFSTDDJqZQMLclrrUUJFbDpZFCqYRbMviUZKaabBGSgGEMnHJRcBlEWfKxsnuqcfsnFxOCbOvAgbnLpUpJOeDbZPB"), string("UQPvSGSHUjMNLqXtyttwHStgIwsYWwuYdQRLlcbiDCFnXDwXWvMkfTBEVevaHugGiKlTWrvxGRhTkGXBnSYchlkwustESwmQDQFpMuRMvVsnGluoPGvciPQYkjcsWcivnVMlquqYFqHnnBqNpwpVZnuxkCyxqQqUADXNGRouQCwXwSRvouPHOOGcyukMaUbuJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qZTQVDRfTpOaBcxb
{
public:
    double zVhriiAKzaJI;
    string YeYzUOfsThL;
    bool XrpoRA;
    int lkrdluELweXVlksT;
    int kqtcXPt;

    qZTQVDRfTpOaBcxb();
    void WEGLNAXtGRm();
    bool RVYvGmkuFkZlwOAz(int ACRbLPQxNPPgvJ, double zOdHVmyFO, bool CnTGFFZnnoXDOEd);
    int mSTMIo();
    int SGPDW(int JekFeScYzTRI, string pETzqadF, int xxNxKo);
protected:
    string DHYFIRLbn;
    bool MRCdaRZmlcXCoU;
    bool qTjehU;
    string dWWJFZbdzsk;
    int uGEjbHtHycmCpc;
    int HgvYujxFP;

    bool BGFixJDrITMG(double iWMmIBFBNzI, double xpvFERpjxGgTc, int rMIUYBTFN, string GkhGIClDIYW, double KlNiiUGXIDw);
    string TFHidYsRKtK(bool bORTRlrDY, int IyGYbEHXDKSTEi, bool hyssjADJjPWciW);
    double GpZRts();
    string vlEmeeAvpibHDso(double HjXlmBaSElPKOzva, bool GGvRhBN, string tOMzUguqEhgB, string EktRlNZDAQ, bool ZcihOJfOutJn);
    double oJNeVSWaBkvjQ(string aRRuAJFhLpDb, bool GDKRwlnTeURqbxv, int IKnkeUqjfT);
    string RkAKiYy(bool uIZOwiX, double TSYRBj, double pMMcMtzLQTu);
    string FOYFfPkXiPhi();
private:
    bool BMhLiKRWBn;
    double WRwmkn;
    int FaRFySMhHxkMpnUZ;
    bool MQmaYZQ;
    string zPmTKce;

    void nUWQDPynHXPnYyp();
    double OXzvvxIQZKm(double aUMdfXMJf, bool miUef, bool MoosPxmUuIrMLWOi, double HQgyBWM, bool VbTDvTzsHou);
    void gfMXr(double yqRib, string AGNGHZeugF, string yzkPpFOXZ);
    double YxInwuB(double nDsEVWkftcXPf, bool xhoGGUJpCNbadeeY, string bPafXmNiMqIB);
    string xggKtzNL(bool GsZPD, double XeWsQljkUMyE, double ijrjMQklpOm, bool YAfIcwforLKMRPob);
    void OBFwJgUsM(bool DerrMzWVw, int yeazmQHyzUJwzf, string BIKKkAHdHBbpoOLz, double dDpHwPmzekkArVOE);
    double xvFqEpHClYJjvMv(string lfatdAbzA, int GjhXRCqUXmWxsB, bool JcbZuEY, int nhMaRGrVninsjrX, double QnXiDVPLh);
};

void qZTQVDRfTpOaBcxb::WEGLNAXtGRm()
{
    bool CoRAUzvzCmbTfA = false;
    bool naMpyzJTsHjYyG = true;

    if (naMpyzJTsHjYyG == true) {
        for (int FSMZcquR = 1094502686; FSMZcquR > 0; FSMZcquR--) {
            CoRAUzvzCmbTfA = naMpyzJTsHjYyG;
            naMpyzJTsHjYyG = ! naMpyzJTsHjYyG;
            naMpyzJTsHjYyG = CoRAUzvzCmbTfA;
            naMpyzJTsHjYyG = naMpyzJTsHjYyG;
            naMpyzJTsHjYyG = ! naMpyzJTsHjYyG;
            CoRAUzvzCmbTfA = naMpyzJTsHjYyG;
            CoRAUzvzCmbTfA = CoRAUzvzCmbTfA;
            naMpyzJTsHjYyG = naMpyzJTsHjYyG;
            CoRAUzvzCmbTfA = ! CoRAUzvzCmbTfA;
        }
    }

    if (naMpyzJTsHjYyG == false) {
        for (int vkgmrFrDsCjeN = 1061550111; vkgmrFrDsCjeN > 0; vkgmrFrDsCjeN--) {
            naMpyzJTsHjYyG = CoRAUzvzCmbTfA;
            naMpyzJTsHjYyG = CoRAUzvzCmbTfA;
            naMpyzJTsHjYyG = naMpyzJTsHjYyG;
            CoRAUzvzCmbTfA = ! naMpyzJTsHjYyG;
            CoRAUzvzCmbTfA = CoRAUzvzCmbTfA;
            CoRAUzvzCmbTfA = ! naMpyzJTsHjYyG;
            naMpyzJTsHjYyG = ! naMpyzJTsHjYyG;
        }
    }

    if (naMpyzJTsHjYyG == true) {
        for (int hTcnjNJYlbxuC = 949161726; hTcnjNJYlbxuC > 0; hTcnjNJYlbxuC--) {
            CoRAUzvzCmbTfA = ! naMpyzJTsHjYyG;
            naMpyzJTsHjYyG = CoRAUzvzCmbTfA;
            naMpyzJTsHjYyG = naMpyzJTsHjYyG;
            CoRAUzvzCmbTfA = ! CoRAUzvzCmbTfA;
            naMpyzJTsHjYyG = naMpyzJTsHjYyG;
            naMpyzJTsHjYyG = CoRAUzvzCmbTfA;
            naMpyzJTsHjYyG = ! CoRAUzvzCmbTfA;
            CoRAUzvzCmbTfA = CoRAUzvzCmbTfA;
            CoRAUzvzCmbTfA = ! CoRAUzvzCmbTfA;
        }
    }
}

bool qZTQVDRfTpOaBcxb::RVYvGmkuFkZlwOAz(int ACRbLPQxNPPgvJ, double zOdHVmyFO, bool CnTGFFZnnoXDOEd)
{
    double tjZcFreNxeLOvIk = -249631.61996644456;
    bool JYSbpOxBbbQVHf = true;

    for (int wylNePfNtZfERMz = 1161689283; wylNePfNtZfERMz > 0; wylNePfNtZfERMz--) {
        continue;
    }

    if (ACRbLPQxNPPgvJ < 283905509) {
        for (int tUgzbqwnJXX = 1121002918; tUgzbqwnJXX > 0; tUgzbqwnJXX--) {
            CnTGFFZnnoXDOEd = JYSbpOxBbbQVHf;
        }
    }

    if (CnTGFFZnnoXDOEd == true) {
        for (int lNGhDyEthb = 9577575; lNGhDyEthb > 0; lNGhDyEthb--) {
            zOdHVmyFO /= zOdHVmyFO;
            tjZcFreNxeLOvIk -= tjZcFreNxeLOvIk;
        }
    }

    return JYSbpOxBbbQVHf;
}

int qZTQVDRfTpOaBcxb::mSTMIo()
{
    bool LuxBtzCSYWhD = false;

    if (LuxBtzCSYWhD == false) {
        for (int FVUTGEFFp = 1871307973; FVUTGEFFp > 0; FVUTGEFFp--) {
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
        }
    }

    if (LuxBtzCSYWhD != false) {
        for (int rkdNjbPWbTzqVkFF = 1168339991; rkdNjbPWbTzqVkFF > 0; rkdNjbPWbTzqVkFF--) {
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
        }
    }

    if (LuxBtzCSYWhD == false) {
        for (int DscNVHkGGFO = 172587908; DscNVHkGGFO > 0; DscNVHkGGFO--) {
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
        }
    }

    if (LuxBtzCSYWhD == false) {
        for (int CUGPaAjHBBDFo = 1377291955; CUGPaAjHBBDFo > 0; CUGPaAjHBBDFo--) {
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = ! LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
        }
    }

    if (LuxBtzCSYWhD != false) {
        for (int zMRaC = 203041641; zMRaC > 0; zMRaC--) {
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
            LuxBtzCSYWhD = LuxBtzCSYWhD;
        }
    }

    return 51757955;
}

int qZTQVDRfTpOaBcxb::SGPDW(int JekFeScYzTRI, string pETzqadF, int xxNxKo)
{
    bool MlnWQEkfm = true;

    if (xxNxKo <= -1751014110) {
        for (int yCTzOvwJS = 1664889923; yCTzOvwJS > 0; yCTzOvwJS--) {
            xxNxKo += xxNxKo;
            JekFeScYzTRI += JekFeScYzTRI;
            xxNxKo /= xxNxKo;
            xxNxKo *= xxNxKo;
        }
    }

    return xxNxKo;
}

bool qZTQVDRfTpOaBcxb::BGFixJDrITMG(double iWMmIBFBNzI, double xpvFERpjxGgTc, int rMIUYBTFN, string GkhGIClDIYW, double KlNiiUGXIDw)
{
    int UYOnnUMA = -182461148;

    for (int bpJqWBYfZthiFqnC = 1115046881; bpJqWBYfZthiFqnC > 0; bpJqWBYfZthiFqnC--) {
        UYOnnUMA /= rMIUYBTFN;
    }

    if (KlNiiUGXIDw != -912578.9082409714) {
        for (int sxkqJhiYmdjh = 1562639575; sxkqJhiYmdjh > 0; sxkqJhiYmdjh--) {
            xpvFERpjxGgTc -= iWMmIBFBNzI;
            iWMmIBFBNzI *= KlNiiUGXIDw;
        }
    }

    return false;
}

string qZTQVDRfTpOaBcxb::TFHidYsRKtK(bool bORTRlrDY, int IyGYbEHXDKSTEi, bool hyssjADJjPWciW)
{
    double rMCLTeLUv = 976499.2679408387;

    for (int wyfYFsmbsG = 220257508; wyfYFsmbsG > 0; wyfYFsmbsG--) {
        IyGYbEHXDKSTEi /= IyGYbEHXDKSTEi;
        hyssjADJjPWciW = hyssjADJjPWciW;
    }

    return string("bedgrVCkIsSDRFSojBVLyknvtyZcdWsiQztUrDWVcUnEwuXFmannDGXCHyLgyWGrVfkejwFegcOVZSjtboKvMLcHwZOumpLxOeKgdJRYSrGrYHvhetKLNodWdhLtEiyBQhCYVdQatDnjgPnZXWKmFAnChSEeyeAjstwmKpotuDYFBSG");
}

double qZTQVDRfTpOaBcxb::GpZRts()
{
    double kXfqmaHQuX = -401825.18817493;
    int QgWZqPRKNxSy = -1335161956;
    double ztrsTJkOPTZFgJTt = -105612.56143505551;

    for (int STvpYgWgP = 296892931; STvpYgWgP > 0; STvpYgWgP--) {
        kXfqmaHQuX += ztrsTJkOPTZFgJTt;
        kXfqmaHQuX = kXfqmaHQuX;
        ztrsTJkOPTZFgJTt -= kXfqmaHQuX;
        kXfqmaHQuX = kXfqmaHQuX;
    }

    if (ztrsTJkOPTZFgJTt >= -401825.18817493) {
        for (int gIDMColtuf = 219357916; gIDMColtuf > 0; gIDMColtuf--) {
            ztrsTJkOPTZFgJTt -= kXfqmaHQuX;
            ztrsTJkOPTZFgJTt *= ztrsTJkOPTZFgJTt;
            kXfqmaHQuX += ztrsTJkOPTZFgJTt;
            kXfqmaHQuX /= ztrsTJkOPTZFgJTt;
            kXfqmaHQuX /= ztrsTJkOPTZFgJTt;
            ztrsTJkOPTZFgJTt += kXfqmaHQuX;
            QgWZqPRKNxSy -= QgWZqPRKNxSy;
        }
    }

    for (int avgKBtWSpfdp = 1307612717; avgKBtWSpfdp > 0; avgKBtWSpfdp--) {
        kXfqmaHQuX /= kXfqmaHQuX;
        kXfqmaHQuX -= ztrsTJkOPTZFgJTt;
        QgWZqPRKNxSy /= QgWZqPRKNxSy;
        QgWZqPRKNxSy += QgWZqPRKNxSy;
        ztrsTJkOPTZFgJTt /= kXfqmaHQuX;
        QgWZqPRKNxSy += QgWZqPRKNxSy;
    }

    for (int McAFB = 1892155895; McAFB > 0; McAFB--) {
        ztrsTJkOPTZFgJTt = kXfqmaHQuX;
        kXfqmaHQuX -= kXfqmaHQuX;
        QgWZqPRKNxSy = QgWZqPRKNxSy;
    }

    for (int CbvunDyhxLu = 1783114117; CbvunDyhxLu > 0; CbvunDyhxLu--) {
        ztrsTJkOPTZFgJTt /= kXfqmaHQuX;
        kXfqmaHQuX += ztrsTJkOPTZFgJTt;
        kXfqmaHQuX += kXfqmaHQuX;
    }

    return ztrsTJkOPTZFgJTt;
}

string qZTQVDRfTpOaBcxb::vlEmeeAvpibHDso(double HjXlmBaSElPKOzva, bool GGvRhBN, string tOMzUguqEhgB, string EktRlNZDAQ, bool ZcihOJfOutJn)
{
    string EWmIjxIvAys = string("JCmzrhbopPHFSxErBrYCVvNJSInFrQVadoAThMeNSQLIMzIGRJiAxwpFtXjjqwznjpYNGJaxPrXxyLOhHYXnCxNEucBmyCAtQaBOxqTpFHjDILKrlCyhJdsfIwzsyLOSATaMixhKVktHnKWIqL");
    bool DpPTPsuu = false;
    string hKMFEGcT = string("NPDUOjwOTEteYOSJUbotddZfKZejvnWZQTjCUSkUJTpblZTqLTeRgomJoIQQqkaEuUjBJwDLffBBHkQQuiATmcJuGArjhWxGMVPWVtkaJLYfywbBwDrNWyfGngahlcHDxJIkPwjvumFdPQPXwIBtgbBePZTZzKWwbqkfwlqvUMS");
    bool ssRNGZmBpVXGXe = true;
    string PHHeQjOOidSnrZav = string("CUbpMukkvFpHdFEhOHbzfPZQNDeKyzCHIzuFoYTY");
    bool blUkamXmPFof = true;
    int gcjciQwjM = 1392123250;
    double cHtczctar = 55145.2531394082;
    int PTOUuKZRewVqonRy = -1934055212;
    int bBrlvjMMEO = 1955983358;

    for (int sGcOSlpVeikeo = 1104383477; sGcOSlpVeikeo > 0; sGcOSlpVeikeo--) {
        PHHeQjOOidSnrZav = EktRlNZDAQ;
        GGvRhBN = DpPTPsuu;
        ssRNGZmBpVXGXe = blUkamXmPFof;
    }

    for (int EvajIyoWAvkb = 1792398698; EvajIyoWAvkb > 0; EvajIyoWAvkb--) {
        continue;
    }

    for (int LNdVbe = 470855442; LNdVbe > 0; LNdVbe--) {
        ZcihOJfOutJn = ssRNGZmBpVXGXe;
        hKMFEGcT = tOMzUguqEhgB;
        hKMFEGcT = EktRlNZDAQ;
        hKMFEGcT += tOMzUguqEhgB;
    }

    for (int EcPHOYMKCO = 195625432; EcPHOYMKCO > 0; EcPHOYMKCO--) {
        hKMFEGcT = tOMzUguqEhgB;
    }

    for (int rdOjrkSCwgAzTDwT = 1564252495; rdOjrkSCwgAzTDwT > 0; rdOjrkSCwgAzTDwT--) {
        continue;
    }

    for (int GSqDNxnh = 1566794184; GSqDNxnh > 0; GSqDNxnh--) {
        EWmIjxIvAys += tOMzUguqEhgB;
        DpPTPsuu = ! ZcihOJfOutJn;
        HjXlmBaSElPKOzva /= cHtczctar;
        EktRlNZDAQ = tOMzUguqEhgB;
    }

    return PHHeQjOOidSnrZav;
}

double qZTQVDRfTpOaBcxb::oJNeVSWaBkvjQ(string aRRuAJFhLpDb, bool GDKRwlnTeURqbxv, int IKnkeUqjfT)
{
    int dscaIizJMjg = -1802663842;

    if (aRRuAJFhLpDb == string("AnDuaSdOKKpvQMFjmxfbGjDhPzuQTDPHxyJWiNGTKbmQTmWpQshpCer")) {
        for (int KBLUKXNLcJ = 1571150911; KBLUKXNLcJ > 0; KBLUKXNLcJ--) {
            GDKRwlnTeURqbxv = ! GDKRwlnTeURqbxv;
            dscaIizJMjg -= dscaIizJMjg;
            IKnkeUqjfT += dscaIizJMjg;
        }
    }

    if (dscaIizJMjg >= -1506915987) {
        for (int KlOwCXHA = 1775426991; KlOwCXHA > 0; KlOwCXHA--) {
            IKnkeUqjfT += dscaIizJMjg;
        }
    }

    for (int MYpCUKR = 831924002; MYpCUKR > 0; MYpCUKR--) {
        dscaIizJMjg = dscaIizJMjg;
    }

    for (int uwGUlK = 1847580230; uwGUlK > 0; uwGUlK--) {
        aRRuAJFhLpDb += aRRuAJFhLpDb;
        IKnkeUqjfT -= dscaIizJMjg;
    }

    return 961615.1071749893;
}

string qZTQVDRfTpOaBcxb::RkAKiYy(bool uIZOwiX, double TSYRBj, double pMMcMtzLQTu)
{
    string ayCbWCKyHowINqGT = string("RJXRqxzdZcNieoodkMpPxUeOMgHOTlKMTrJNhsnVWnUUTWPRgJEFlRpUgSeiBrIJNuBwwVMJNMIXFiXQqKiOARHNjNounXFgqkdTcLXIcfxoiqrlYEzzOhnweQOspoPPyBISrUnYCvwVpOCtT");
    bool YjpbouXvysrgbfW = true;
    int HsxiseXxtoCLxO = 638583990;
    bool bSRIVZZyFXZNDnBf = true;
    string OWmMUVYzkEy = string("DblgeMhhBJEbhXMAtRlZNKAbZDdghlSDWABOFUOKSTNVmCalpXnKlZzQuCaWZHVztyfpPKoVIBxfNfgsCeyrUlUKWOMrRaZBQiSPyTHhrZrpEQoWzlBpdZzLAJHuELNluEENqiYcNjvHsqCRHRQWPfgETOgPcRzcAxUBYBCEmemXayTGEMOxlHJGyNrbZOKshwezSTzWxSPBACf");
    string ZMHdlmH = string("IKKTgUgNKASPxiovkTXcstNsLLbYOlZROJGlVXeyZpEmAqoFEBowhZKHIgiuatLNgvAmKHva");

    for (int Cinzq = 605322329; Cinzq > 0; Cinzq--) {
        ayCbWCKyHowINqGT = ayCbWCKyHowINqGT;
    }

    for (int SIZHLLlnjod = 1961661941; SIZHLLlnjod > 0; SIZHLLlnjod--) {
        uIZOwiX = ! uIZOwiX;
    }

    return ZMHdlmH;
}

string qZTQVDRfTpOaBcxb::FOYFfPkXiPhi()
{
    double kPuzW = 138263.16893070197;

    if (kPuzW <= 138263.16893070197) {
        for (int ZxJpO = 1915263923; ZxJpO > 0; ZxJpO--) {
            kPuzW *= kPuzW;
            kPuzW -= kPuzW;
            kPuzW /= kPuzW;
            kPuzW -= kPuzW;
            kPuzW += kPuzW;
        }
    }

    if (kPuzW <= 138263.16893070197) {
        for (int eHumtpgZRNZDDZRq = 1898180005; eHumtpgZRNZDDZRq > 0; eHumtpgZRNZDDZRq--) {
            kPuzW -= kPuzW;
        }
    }

    return string("PvNYUaJdAnMbwszmFITEkaGyviDwunnFsKtJTKpQludDMgwquOOPRlpNxIywmWfMfhKacGLXNaRrnzQOiwpVWLWZZHeHQJHGUqkvanNkxIvLvTjYdhBqLjtXewmOuNGULIgdjpDIwlOKkR");
}

void qZTQVDRfTpOaBcxb::nUWQDPynHXPnYyp()
{
    int YFvcet = -1718850362;

    if (YFvcet == -1718850362) {
        for (int lUyXhHJEHpDH = 1285120001; lUyXhHJEHpDH > 0; lUyXhHJEHpDH--) {
            YFvcet -= YFvcet;
            YFvcet = YFvcet;
            YFvcet /= YFvcet;
            YFvcet /= YFvcet;
            YFvcet *= YFvcet;
            YFvcet /= YFvcet;
        }
    }

    if (YFvcet > -1718850362) {
        for (int LSGla = 873526712; LSGla > 0; LSGla--) {
            YFvcet *= YFvcet;
            YFvcet /= YFvcet;
            YFvcet *= YFvcet;
            YFvcet = YFvcet;
            YFvcet += YFvcet;
            YFvcet *= YFvcet;
        }
    }

    if (YFvcet < -1718850362) {
        for (int gSXAPatDhciEggxK = 404788761; gSXAPatDhciEggxK > 0; gSXAPatDhciEggxK--) {
            YFvcet /= YFvcet;
            YFvcet /= YFvcet;
        }
    }

    if (YFvcet > -1718850362) {
        for (int fcqmwtlIEcw = 931554807; fcqmwtlIEcw > 0; fcqmwtlIEcw--) {
            YFvcet /= YFvcet;
            YFvcet /= YFvcet;
            YFvcet += YFvcet;
            YFvcet += YFvcet;
            YFvcet /= YFvcet;
        }
    }
}

double qZTQVDRfTpOaBcxb::OXzvvxIQZKm(double aUMdfXMJf, bool miUef, bool MoosPxmUuIrMLWOi, double HQgyBWM, bool VbTDvTzsHou)
{
    string GqjomiivhlzJga = string("syRwTJjMFVDLWZeKCmkfCvpLowzuTChsqiQvmZXBnMHYINVNphYRlivthjQdyPAeLnUVaSbPGemzhqKOkUhQgsrjrEOAgYFIkrZXSeCqmIAfvXZXWCDkuXMPMOGBdumcppFQxdUqjILGUxevExfuAnrzaRLyQlCKwfOqhPvrxHFITnvSyeIegVahHbzVgiHcbdpIx");
    int PimnunrjSN = 473624477;
    double kvRMlzVn = 8377.474977435086;
    bool ZXOAM = false;
    string EyXiLUlyPYSbzRcv = string("IhIDBETiabKdNUTuoGXPFhEScKWDDigxLaqVuRmyEIyXBhwsY");

    for (int iqNBKwV = 1861759677; iqNBKwV > 0; iqNBKwV--) {
        VbTDvTzsHou = ! miUef;
        VbTDvTzsHou = MoosPxmUuIrMLWOi;
        ZXOAM = ! MoosPxmUuIrMLWOi;
    }

    for (int ILByk = 1551942833; ILByk > 0; ILByk--) {
        kvRMlzVn = HQgyBWM;
        MoosPxmUuIrMLWOi = miUef;
    }

    return kvRMlzVn;
}

void qZTQVDRfTpOaBcxb::gfMXr(double yqRib, string AGNGHZeugF, string yzkPpFOXZ)
{
    bool DGMmUCMVKQfdBT = false;
    double DDGGqaYQjtFxOk = 644866.9628602681;
    double WzpDoYHXm = 485395.7127003312;

    for (int tZNuzedmH = 753543029; tZNuzedmH > 0; tZNuzedmH--) {
        continue;
    }

    if (yqRib >= 575204.3086123668) {
        for (int bgeibnI = 2000698748; bgeibnI > 0; bgeibnI--) {
            AGNGHZeugF = yzkPpFOXZ;
            yqRib *= DDGGqaYQjtFxOk;
            DDGGqaYQjtFxOk /= WzpDoYHXm;
            yqRib += DDGGqaYQjtFxOk;
            yzkPpFOXZ = AGNGHZeugF;
            yzkPpFOXZ = yzkPpFOXZ;
            AGNGHZeugF = yzkPpFOXZ;
        }
    }
}

double qZTQVDRfTpOaBcxb::YxInwuB(double nDsEVWkftcXPf, bool xhoGGUJpCNbadeeY, string bPafXmNiMqIB)
{
    bool pKCJVUqtr = true;
    int UIjnyigHPOZLyMq = -1032463775;
    bool qKSCaQkNgXHWidvQ = false;
    bool UWacXkUPD = true;
    double nRUOZRlQpVWTFduG = 922897.1466390475;
    bool gfhSpHnlQSFLiQ = false;

    for (int MqGDAndxoiKnrg = 2054719730; MqGDAndxoiKnrg > 0; MqGDAndxoiKnrg--) {
        UWacXkUPD = ! pKCJVUqtr;
        pKCJVUqtr = ! pKCJVUqtr;
    }

    return nRUOZRlQpVWTFduG;
}

string qZTQVDRfTpOaBcxb::xggKtzNL(bool GsZPD, double XeWsQljkUMyE, double ijrjMQklpOm, bool YAfIcwforLKMRPob)
{
    string fHpVPACjuH = string("AsRwbtMaGsRGvBRxzlbzAqJPwPs");
    double SGSyiIEmCGfXzIH = -597100.7022209582;
    double xwUvO = -619341.0115329237;
    bool lximNSNgZ = false;
    double axSbiGgf = 201038.2755393489;
    string iiEkw = string("efYEoZJfkWTNUzeLGiiSuQUpWMNgZoJInFeQTuIJtvomhaDIMOuCjLuBZlYsuyexQDcozMjcfbwRHOIdgItajYzHAdduxkUvfgIRaPHysPGvTlWKhcjRZnAfDEWBIaNItXNxuPfvCuNXAIBLAwLyHWVNxarPXfFkuwTzhRSOqKdwVZTvRlScLRzWFBcaKAjkKoBDGvgHowIAYjIjSuEW");

    if (ijrjMQklpOm != -345091.33563042723) {
        for (int jRcPRIGCn = 1024680745; jRcPRIGCn > 0; jRcPRIGCn--) {
            xwUvO = xwUvO;
            axSbiGgf *= axSbiGgf;
            xwUvO /= ijrjMQklpOm;
            XeWsQljkUMyE /= XeWsQljkUMyE;
        }
    }

    if (iiEkw >= string("efYEoZJfkWTNUzeLGiiSuQUpWMNgZoJInFeQTuIJtvomhaDIMOuCjLuBZlYsuyexQDcozMjcfbwRHOIdgItajYzHAdduxkUvfgIRaPHysPGvTlWKhcjRZnAfDEWBIaNItXNxuPfvCuNXAIBLAwLyHWVNxarPXfFkuwTzhRSOqKdwVZTvRlScLRzWFBcaKAjkKoBDGvgHowIAYjIjSuEW")) {
        for (int AEiFSAuSmVlh = 1792121172; AEiFSAuSmVlh > 0; AEiFSAuSmVlh--) {
            XeWsQljkUMyE -= ijrjMQklpOm;
            xwUvO *= axSbiGgf;
        }
    }

    return iiEkw;
}

void qZTQVDRfTpOaBcxb::OBFwJgUsM(bool DerrMzWVw, int yeazmQHyzUJwzf, string BIKKkAHdHBbpoOLz, double dDpHwPmzekkArVOE)
{
    string WRRBMnaFGO = string("kSgSdFKwlSHavLlbCLFZkJeSWyTzbIFKQJArQnnuwjFDxZEzEvtStesStHPKHIfaNHsKQpaNzxiZQWzqQdbELVUwUESkqilByLBIDNRlSZJzsFaTyUZAJPjnAkLdduKSgvoWOvcWrMXTlSAbnruJGgjFkIozPVRbeAVCDwzfIJiMdiqAtLNoYZVIJXIhZqIVScDCrhiLMINTTZhAYydPWyXFUjlJzvsSPlPDOHKYnaDdLboRklInUedCkZdrF");
    double NRdGa = -886178.2433356032;
    bool cAXkyCZkSOCR = true;
    double tvammqgffSTVSz = -798151.1494849133;
    int yAYCpjRBUwHdpJk = -1816606996;
    int dHKLoXzm = -337708062;
    bool CvUzSnxtMnvvNFT = true;
    bool huCvZgLzWCyXhlG = false;

    for (int zWBTfGFJu = 71873984; zWBTfGFJu > 0; zWBTfGFJu--) {
        dHKLoXzm /= yAYCpjRBUwHdpJk;
        huCvZgLzWCyXhlG = huCvZgLzWCyXhlG;
    }

    for (int aYsfQLDCIEut = 1495954347; aYsfQLDCIEut > 0; aYsfQLDCIEut--) {
        continue;
    }
}

double qZTQVDRfTpOaBcxb::xvFqEpHClYJjvMv(string lfatdAbzA, int GjhXRCqUXmWxsB, bool JcbZuEY, int nhMaRGrVninsjrX, double QnXiDVPLh)
{
    string oNewttZDBUHH = string("jDJloSmYRDbknvKBQvXkMiAdgVsPWyvkrtHlildnIESenbBfYmCUOZSBlQQEWmOPJxRGlidLOccWovyIbKHRlHUuHAwGOlgvGbhUQgGOfrgZRMLDmxRvizgrBVreYfTnBQHCvWsoGbPXUszXcTOqDWzXRYaZmABfWQZkepUDoYZAsE");

    if (nhMaRGrVninsjrX <= -1561077997) {
        for (int cslCATVVvH = 1196643545; cslCATVVvH > 0; cslCATVVvH--) {
            oNewttZDBUHH += oNewttZDBUHH;
            GjhXRCqUXmWxsB /= GjhXRCqUXmWxsB;
            nhMaRGrVninsjrX = GjhXRCqUXmWxsB;
            oNewttZDBUHH = oNewttZDBUHH;
            oNewttZDBUHH += oNewttZDBUHH;
        }
    }

    if (GjhXRCqUXmWxsB > -1561077997) {
        for (int TRxnqEYEQC = 1040840881; TRxnqEYEQC > 0; TRxnqEYEQC--) {
            lfatdAbzA = oNewttZDBUHH;
            lfatdAbzA += oNewttZDBUHH;
        }
    }

    return QnXiDVPLh;
}

qZTQVDRfTpOaBcxb::qZTQVDRfTpOaBcxb()
{
    this->WEGLNAXtGRm();
    this->RVYvGmkuFkZlwOAz(283905509, -51841.47492543792, true);
    this->mSTMIo();
    this->SGPDW(-417564337, string("yMaRkDQrJeOKXOdicPLEJIIQIADcHhgzXAaLOQaCsTKhKWiGaWPMZqoXqtBbJCZlIMqTCqPnUYlqOYcytwlXBFngOFhScxVHoHgKWGPKDHdHAliyFPWAWXMya"), -1751014110);
    this->BGFixJDrITMG(288876.99097092886, -912578.9082409714, -240034422, string("OdKrtzcYlehfJEvUjMfTGfzfqNJYuyoqjMNxkJSzkbGGvoTIfVCNJbDxotSS"), -314979.9094469718);
    this->TFHidYsRKtK(false, -1952416971, true);
    this->GpZRts();
    this->vlEmeeAvpibHDso(-628025.3579419204, false, string("rlYExgjhsIZxIJgshGEnSrooWEWBYqnChajPkIOyUVHIrzEmmQRxeYKwMLHQZyqdqxpGNBggDmxTxIscwDQQMkqCTLFUpBaInFjLaoToBneQQGeUT"), string("bWuFGUqGMXjgIQTcpyupsBDzlBhEizMZPPFguDSeWhjgDmuVzqwfdVqSwsFNAbhgnWuuOLeToNGWRkmTT"), true);
    this->oJNeVSWaBkvjQ(string("AnDuaSdOKKpvQMFjmxfbGjDhPzuQTDPHxyJWiNGTKbmQTmWpQshpCer"), true, -1506915987);
    this->RkAKiYy(false, 505066.0817222046, 223124.9738786244);
    this->FOYFfPkXiPhi();
    this->nUWQDPynHXPnYyp();
    this->OXzvvxIQZKm(-334853.54209059733, true, true, -811276.3920183134, true);
    this->gfMXr(575204.3086123668, string("JpjnxVjTpJOYLrMUmJztzyrTNKCNhGGtXCjlKDfOKbBnAewCtcthPtjcItpiiQkfsiOiIKSHBgKoviXdwGuGWGtEkbBTTXPNMVUzfCegFtfcdqgFDMfRMPgMMfHSMV"), string("KYOcBhosrdMkGZQwiNCNlDyFggFwqrEIDAoeyuyotxosLfOmcbCdGwwUqYgWiUbsJsLIlYlayMtzTaeRVsDtZyeKanPlPEytmedsIeBpcKLtRMqKCzCUfIaKXmEgesBptAkxOGZUEPQLtpstHnpxiWtqcomkRzjfWwqrustBHvkZxyhGHPkeHNWsILhwzEkMeRMHdrOdMSVWokqfllPgygxwQuuJPXuHKqJdsGn"));
    this->YxInwuB(140239.64778640482, false, string("UqHehlqUXQnVqGvQHxbnMhByQRqGsdbXdCFLyYHuCexAAzsIIQQeApeewMtPYAMiukVUJeWrXGHRwGExWNYTfzqePLPtSxwXOLFhcdAXmYglwbLoRRpQBgaYRSAwAQXgztomarfpZOOPsuHTCBeGyZxdQN"));
    this->xggKtzNL(true, -345091.33563042723, 80497.08861841708, false);
    this->OBFwJgUsM(false, 1533348403, string("OqtoRwltQwEsebOuOXVTJuOddlVIpWyEqlDPDCDrqoOPGVKzXaCNiKdgbehIWfsQuUZx"), -745470.4688278493);
    this->xvFqEpHClYJjvMv(string("edEfDZmvudIhLXbHjDzBWiuhkRGyPAlKEbBrcerpqUByRTZZqgxPauhweLpVIFLLmLAlAqxfCzFmWEVVTmrrldjqVmKnaCTzlVSVzsTjMHbZDFikFssyVsHkKUVAfeOXYpRTvXNJonuUIDMkixcQljVqebULJwzBReblsIuKhuA"), -1561077997, false, -837223852, 1002898.2609822887);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uKkcdeAdiamR
{
public:
    string HZNnJWAqzGlV;
    double IvdscSmrbcuHo;
    string vQmHiFaojpp;
    int ADfXzhyAlCkcj;

    uKkcdeAdiamR();
    string RcoOxAsmU(bool yvKHCzYDXIU, string aFqGkdcDiDGAwU);
    void xGUnOq(double IkhpaAQ, double nPOHCKmKgruVy, int dGLiiwSbrRgIwR, double iLwGtRlf, int sLhfxKYnQeAf);
    string RLiBByZZjIGeNd(string BNNuILX, int efpAjaVdO, string VtttHPaTkegK, int icKOWuPxm);
    string KzCtPGqdvsfXqnHN(double hdHmRaCl);
    bool njwScfI(string dJjCSnjD);
    bool KQTsyaJ(string UxZYSoOMtYUZh, bool mtbQSVKf);
    int RzxUayM(string AnYGmwDZx, int izEflo, int uNoCDLjjDf, double vPRVqzM);
    void ettbZxysLv(bool MEexdfY, double NdmkwdGPyZrOp, int CGvXYYTCLlJLGk);
protected:
    double idtevMPqwt;
    int AairSedw;
    double IcriFnRATEAekrO;
    int mpGFmq;
    string YJnIuBvHJTp;

    string VntBaFUzQstDU(bool SseDyATiE);
    void eYmfTHahnWp(bool TNDJhzzCak);
    int YvdzjCUHxWQIMVAP(int bTwXSnfjkpryh, bool LsVBLesxp, bool CYYUKCjMe, double wlmEaLKJqGx);
    int XRXTYiqHm(double mFBmDDXZh);
private:
    string rUcOvfEVW;
    int CspFiUFqK;
    bool qLAoLzlJQitM;
    double HKCjRtgx;

};

string uKkcdeAdiamR::RcoOxAsmU(bool yvKHCzYDXIU, string aFqGkdcDiDGAwU)
{
    int dMgZDBKovAoWc = 1687634239;
    bool tsSUlcuHwTWBDI = false;

    for (int YeDbJsVraB = 400579662; YeDbJsVraB > 0; YeDbJsVraB--) {
        continue;
    }

    return aFqGkdcDiDGAwU;
}

void uKkcdeAdiamR::xGUnOq(double IkhpaAQ, double nPOHCKmKgruVy, int dGLiiwSbrRgIwR, double iLwGtRlf, int sLhfxKYnQeAf)
{
    double sCaYbOJCeEngYpze = 59172.55176285049;
    string cddAk = string("bZaWjQwzRgkXvwuqWcJCkKKOpsqkJTqQHsnxKthkKqYXArckBVrnHfYTxQGlWWyVsZYvLWFJjlKEYMBBpwoNwskWHURcKdHHOTnUcljLeiLEbBBpvyNkpMSmzYIOHetWUfsrILPaPXcqkOIYqTYLxKAxAPmxUteErBipbPvgBhBiXUFjKayrJzzivnQQfmgyALhwJNjJUOlmidblmKaSIDTbHYTGxWXQXNYJbqb");
    string uEyuRpS = string("ulFUBYaSQAnVJZhcTDHUSWlEhmVFDvvDbJGeNnXobiAnOJKhbmuGhgqUBNgoZNfxBanXtZKdJyyExKCEjdheiBBYYZMcDhrlogaN");

    if (sLhfxKYnQeAf <= -1086713912) {
        for (int igqYgNeKN = 1586722; igqYgNeKN > 0; igqYgNeKN--) {
            IkhpaAQ += sCaYbOJCeEngYpze;
            nPOHCKmKgruVy /= nPOHCKmKgruVy;
            sCaYbOJCeEngYpze += nPOHCKmKgruVy;
            sCaYbOJCeEngYpze = iLwGtRlf;
        }
    }

    for (int WqpVDHBX = 399567169; WqpVDHBX > 0; WqpVDHBX--) {
        sCaYbOJCeEngYpze *= iLwGtRlf;
    }

    for (int PMXFMH = 823118596; PMXFMH > 0; PMXFMH--) {
        dGLiiwSbrRgIwR *= dGLiiwSbrRgIwR;
        cddAk += uEyuRpS;
    }

    if (iLwGtRlf != -324344.39918840415) {
        for (int nVuyoQinCbNt = 1788794433; nVuyoQinCbNt > 0; nVuyoQinCbNt--) {
            uEyuRpS += uEyuRpS;
        }
    }
}

string uKkcdeAdiamR::RLiBByZZjIGeNd(string BNNuILX, int efpAjaVdO, string VtttHPaTkegK, int icKOWuPxm)
{
    int TxbKVpOcg = -26035282;
    double BLDckalmtMFv = 335893.6867649636;
    int xWJWuUxhPK = 142072306;
    bool DHBVkplDE = true;
    int eEzCg = 67643034;

    if (eEzCg >= 142072306) {
        for (int cpLJYRiQvR = 2000619655; cpLJYRiQvR > 0; cpLJYRiQvR--) {
            xWJWuUxhPK += xWJWuUxhPK;
            xWJWuUxhPK = TxbKVpOcg;
            efpAjaVdO *= efpAjaVdO;
        }
    }

    for (int hHmxzivCQ = 871449361; hHmxzivCQ > 0; hHmxzivCQ--) {
        eEzCg *= icKOWuPxm;
        eEzCg -= icKOWuPxm;
    }

    if (TxbKVpOcg != -864110483) {
        for (int tywbppM = 390081301; tywbppM > 0; tywbppM--) {
            BNNuILX = BNNuILX;
            icKOWuPxm += TxbKVpOcg;
            xWJWuUxhPK /= eEzCg;
            efpAjaVdO *= xWJWuUxhPK;
        }
    }

    return VtttHPaTkegK;
}

string uKkcdeAdiamR::KzCtPGqdvsfXqnHN(double hdHmRaCl)
{
    bool OmzNwDabwNrH = true;
    string UtYsBxgjSyl = string("FFvlToZTgfypcgIPvpdzLDHXsgAeUMPCREDWBZOFolEHVANfCQQsnKkKWyEkNqJzSXjOJZxNmHzTqpOkxtmadSCAtJXLXnrHnsFtoplVkTjWWJKlrEWkGNbXIMKzInTYCWsXLxztWSszthzZeLOLiXXZjMBTfr");

    return UtYsBxgjSyl;
}

bool uKkcdeAdiamR::njwScfI(string dJjCSnjD)
{
    string vyuUa = string("QxJssTpoKVjaaDyPdJTIJDFkInlrpzPWzAttalSwwSHNddGOGDkVKGJbMtepEGqBXXdpQQQQRh");
    bool WuxpC = true;
    int EtSKmjQTBgdG = 44348880;
    bool OdUkFPipKPQa = true;
    double sOmppcsHMoWF = 370459.04239678214;
    string KJqKb = string("IVPLjczjQZJHMTnQQZSyaefmhsuxQhZmkcRgXAG");
    int aixNeY = -602530405;
    double XrOBwkO = -912253.5698761814;
    bool JvuxVQkxBAq = true;
    string FTIwnNQWIwCKcaIp = string("oLqREvZPtnbrsYDbeNfrHMKgmYqkPeZHDRKCUFdYZrCVxJGCNYpPutVkXcXxcQavedxBeAZzmvZuIiHUZzfaLRaKVQOKQnxmUpVmQbcyEfVajpeekMRhnmoIWcdLiuTcukaDNBItYABRjNvEjlUDlXZKxHvsqDAYLuBbWGkTocbvmqEvuKgQaxHQdojFKHVE");

    for (int DCAIfG = 241555292; DCAIfG > 0; DCAIfG--) {
        vyuUa = FTIwnNQWIwCKcaIp;
        dJjCSnjD += KJqKb;
        WuxpC = ! WuxpC;
        sOmppcsHMoWF /= sOmppcsHMoWF;
    }

    return JvuxVQkxBAq;
}

bool uKkcdeAdiamR::KQTsyaJ(string UxZYSoOMtYUZh, bool mtbQSVKf)
{
    string KjiuEemtMzVLJBZ = string("JbsDqTTZPfxeOKkFVrTEvYHWyyeKwaBigqNJfKfOqAdEIdpbbHTSlDbOsenlLXmFihFdRHMPxNyMCICRtxxZESNRZCwUALfZkldTrDyohCGCwmEpUf");
    double lzQwuhFfQL = -194250.60175555173;
    int aueqzIxaLkwxEwyN = -16728394;
    double XlAqiGp = -207374.63093809946;
    string AAGGAjHsAat = string("KgVGcVPLHBSaXuwJWJwsvLwgrvSIprZRFObhfvdQpyHKfWouuuiCTypWtNMmLtVXgYjZPDnhSchxxOlSs");
    int ZEGXoNlWo = 208165303;
    int MtiZzODKNCEds = -809692106;

    if (XlAqiGp <= -207374.63093809946) {
        for (int ckyswrwPwPpWRz = 932329227; ckyswrwPwPpWRz > 0; ckyswrwPwPpWRz--) {
            KjiuEemtMzVLJBZ = AAGGAjHsAat;
            UxZYSoOMtYUZh += KjiuEemtMzVLJBZ;
        }
    }

    for (int evtnuSgoheJqi = 992778479; evtnuSgoheJqi > 0; evtnuSgoheJqi--) {
        ZEGXoNlWo = ZEGXoNlWo;
    }

    return mtbQSVKf;
}

int uKkcdeAdiamR::RzxUayM(string AnYGmwDZx, int izEflo, int uNoCDLjjDf, double vPRVqzM)
{
    int cBHQFLapscbww = -1155989818;
    int HjkDBRgWMtnFIH = -1242998916;
    string AoyVDLmYB = string("ZPeqUusadBtpQQNUtQEUWzSYTxAKVpOUlqnUA");
    int biOQUtwKwPaDJd = 614826784;
    int wwJuN = -888307995;

    for (int TKfFeWzAnwkZxvpg = 924029479; TKfFeWzAnwkZxvpg > 0; TKfFeWzAnwkZxvpg--) {
        wwJuN -= izEflo;
        AnYGmwDZx = AoyVDLmYB;
        cBHQFLapscbww /= wwJuN;
    }

    for (int suhhAlv = 1715337280; suhhAlv > 0; suhhAlv--) {
        wwJuN += uNoCDLjjDf;
        cBHQFLapscbww /= HjkDBRgWMtnFIH;
        biOQUtwKwPaDJd *= HjkDBRgWMtnFIH;
        izEflo += wwJuN;
    }

    if (izEflo != 1918465975) {
        for (int HyOjWccvdLlULl = 466912076; HyOjWccvdLlULl > 0; HyOjWccvdLlULl--) {
            AoyVDLmYB += AnYGmwDZx;
            wwJuN += wwJuN;
            HjkDBRgWMtnFIH *= wwJuN;
            wwJuN = HjkDBRgWMtnFIH;
        }
    }

    if (uNoCDLjjDf == -1155989818) {
        for (int ootQVqcuXQkRXO = 1595793690; ootQVqcuXQkRXO > 0; ootQVqcuXQkRXO--) {
            izEflo /= biOQUtwKwPaDJd;
            biOQUtwKwPaDJd = cBHQFLapscbww;
            cBHQFLapscbww /= wwJuN;
            biOQUtwKwPaDJd *= izEflo;
            HjkDBRgWMtnFIH = cBHQFLapscbww;
        }
    }

    if (cBHQFLapscbww != -888307995) {
        for (int DcqOZRMGmmlope = 342934727; DcqOZRMGmmlope > 0; DcqOZRMGmmlope--) {
            biOQUtwKwPaDJd -= izEflo;
        }
    }

    if (uNoCDLjjDf != 1918465975) {
        for (int ToObHfUvsSikk = 1067275570; ToObHfUvsSikk > 0; ToObHfUvsSikk--) {
            continue;
        }
    }

    return wwJuN;
}

void uKkcdeAdiamR::ettbZxysLv(bool MEexdfY, double NdmkwdGPyZrOp, int CGvXYYTCLlJLGk)
{
    double zagWQtsXTmqWiHKb = 575402.6133992369;
    int zPcHsqnN = 954683952;
    bool UIrgjhdjVR = false;
    bool MDYvff = false;

    if (MDYvff == false) {
        for (int uejSwoCBC = 69932358; uejSwoCBC > 0; uejSwoCBC--) {
            zagWQtsXTmqWiHKb /= zagWQtsXTmqWiHKb;
            MEexdfY = ! MDYvff;
            MEexdfY = MEexdfY;
            CGvXYYTCLlJLGk += zPcHsqnN;
        }
    }

    for (int DcmTIcpqRxA = 1729466813; DcmTIcpqRxA > 0; DcmTIcpqRxA--) {
        zPcHsqnN -= zPcHsqnN;
        MEexdfY = ! MDYvff;
    }

    for (int qYUkWtwFyTQuReo = 1367381026; qYUkWtwFyTQuReo > 0; qYUkWtwFyTQuReo--) {
        NdmkwdGPyZrOp /= NdmkwdGPyZrOp;
        MDYvff = ! MEexdfY;
    }

    for (int dYRWjnDKBLMxmh = 511469304; dYRWjnDKBLMxmh > 0; dYRWjnDKBLMxmh--) {
        UIrgjhdjVR = MDYvff;
    }
}

string uKkcdeAdiamR::VntBaFUzQstDU(bool SseDyATiE)
{
    double WxDfx = -192890.25730683547;
    bool TXkjtXifeJQmy = true;
    int WJNnlHtsjVg = 528943906;
    string LHTzFSHZrEaPKbIn = string("xoYabTQMtTVYxPuHdYpyKAcNyXWlaiHbYKLMiryACWEWQsedCxQnYgTYmbEKJeRSurUTsUhZFrWvueFPYOzVMmKepiqKhjCsuTGZQfwVINnPqZJNrXWjWISrmquvQFzzGSYAGpUeJPejkJukKNuXjVHybVXCJgRBsKowPnUlCcB");

    if (SseDyATiE == false) {
        for (int dOIvzRwiMhHkHpRY = 253496098; dOIvzRwiMhHkHpRY > 0; dOIvzRwiMhHkHpRY--) {
            SseDyATiE = TXkjtXifeJQmy;
            WJNnlHtsjVg += WJNnlHtsjVg;
        }
    }

    for (int hRhUye = 946821909; hRhUye > 0; hRhUye--) {
        WxDfx /= WxDfx;
        WJNnlHtsjVg += WJNnlHtsjVg;
    }

    for (int FZEeei = 320942999; FZEeei > 0; FZEeei--) {
        SseDyATiE = ! SseDyATiE;
    }

    for (int hiwfUSEWBKsbf = 1960615111; hiwfUSEWBKsbf > 0; hiwfUSEWBKsbf--) {
        LHTzFSHZrEaPKbIn += LHTzFSHZrEaPKbIn;
        SseDyATiE = TXkjtXifeJQmy;
        WxDfx -= WxDfx;
    }

    for (int HaelqHdwJqqSQObW = 792603947; HaelqHdwJqqSQObW > 0; HaelqHdwJqqSQObW--) {
        WxDfx /= WxDfx;
    }

    return LHTzFSHZrEaPKbIn;
}

void uKkcdeAdiamR::eYmfTHahnWp(bool TNDJhzzCak)
{
    double sioElVmZraQdLJel = -295024.07868085935;
    string jQQXdTqULXkpJXPa = string("QFAlRJPXPuWJpqYBzMNROsWPDfdSSgEoROkyFxLZPeEaTEskFrdzBhVWWJF");

    if (TNDJhzzCak == true) {
        for (int GyghhDeCyt = 1607397114; GyghhDeCyt > 0; GyghhDeCyt--) {
            TNDJhzzCak = ! TNDJhzzCak;
        }
    }
}

int uKkcdeAdiamR::YvdzjCUHxWQIMVAP(int bTwXSnfjkpryh, bool LsVBLesxp, bool CYYUKCjMe, double wlmEaLKJqGx)
{
    string zOaiFokiNfMkqUJ = string("PsBJYxRrCkvhdCiDXNinDv");
    bool SZzdzUqsJYcYiurQ = false;
    string GuHPvvtsaNZAzBFF = string("VjWuybWOWHTMBqkuS");
    double YNVGvkdTNY = -674164.2236776408;
    double CtFwGhL = 767314.0546888476;
    int QlTqlBZ = -1067926832;
    string StfLJZtBgVokNM = string("VRDVqcOkwosJXcwzfrsgd");
    string srjHtTrPyM = string("YWfeiYrKteaUtPuwFQHouVEkTIRKAZZTKxqTcqoOYAoYLAASVwiEHuSlQFoBdsfdAxghXKoxSlCyufmVqwfLbOxfAIPLpQFUvYccClojyssPbDjfrZflifPPKFGLWVrmBsZLgwHPROyCcKoXigrvOldlvToohMIIwtoaRMimPNGwgdPUVvdvXPTDEzJyXzweeEOJpyFBsZLswriBrwmPCZhZgEHNxVdNDihxMvbTY");
    int UzEMaKFZOauyH = 1581050478;
    double WCWLx = -35541.055178426686;

    for (int OEahU = 1240527820; OEahU > 0; OEahU--) {
        continue;
    }

    for (int fWJOx = 450037790; fWJOx > 0; fWJOx--) {
        GuHPvvtsaNZAzBFF += srjHtTrPyM;
        zOaiFokiNfMkqUJ += srjHtTrPyM;
    }

    return UzEMaKFZOauyH;
}

int uKkcdeAdiamR::XRXTYiqHm(double mFBmDDXZh)
{
    int zmujNQYkwZtt = 1734107720;
    double SwIvf = 148627.44445992922;
    bool ymrLJlgKf = false;
    double fSxklV = 299260.65751642175;
    double fpWqhKihUhoVXjr = 140261.56900935344;
    int spuoHiduP = 15048301;

    if (fpWqhKihUhoVXjr > 140261.56900935344) {
        for (int rtnrwX = 2089767578; rtnrwX > 0; rtnrwX--) {
            fpWqhKihUhoVXjr *= fSxklV;
            SwIvf *= fSxklV;
            mFBmDDXZh *= fpWqhKihUhoVXjr;
        }
    }

    for (int zndngx = 484042872; zndngx > 0; zndngx--) {
        fSxklV += mFBmDDXZh;
        mFBmDDXZh -= mFBmDDXZh;
        fpWqhKihUhoVXjr /= fSxklV;
    }

    if (spuoHiduP >= 15048301) {
        for (int gmuLIggYWPm = 1373093786; gmuLIggYWPm > 0; gmuLIggYWPm--) {
            SwIvf += fpWqhKihUhoVXjr;
            SwIvf -= fSxklV;
        }
    }

    if (mFBmDDXZh < -707613.6722304351) {
        for (int XgbbZsUxVNHch = 207182403; XgbbZsUxVNHch > 0; XgbbZsUxVNHch--) {
            fpWqhKihUhoVXjr *= fSxklV;
        }
    }

    for (int sSwXkQapWdhI = 167604065; sSwXkQapWdhI > 0; sSwXkQapWdhI--) {
        ymrLJlgKf = ymrLJlgKf;
    }

    for (int zNqsLr = 1564832292; zNqsLr > 0; zNqsLr--) {
        mFBmDDXZh += fSxklV;
        SwIvf = mFBmDDXZh;
    }

    return spuoHiduP;
}

uKkcdeAdiamR::uKkcdeAdiamR()
{
    this->RcoOxAsmU(true, string("iRQCheXkSdBSafPqyIyItoMkHtHEZuahWwqIEeXSrjwdPuQZuVXCYorxdpkkqIMpMJTscBzlVQxnATdWtNHMMcKSjOJSlbiboqydyoRcNDSldGoqoGYeynnzHpcnBusNZTZQZzmRYYHFcOBmqpjlkHxJwiikYoxxMUfhbRwiVkdiWdLLTKVGWEDHlWtmOqadmp"));
    this->xGUnOq(-333572.5598934092, -1032706.9877612039, -1086713912, -324344.39918840415, 2120424326);
    this->RLiBByZZjIGeNd(string("IxcioLAWhgNpKkOCtcKzTIaIyrFbBaHrDCDQcugv"), -864110483, string("QRzFPZVpjytBmMPbVmoDhbEfGpippEtNFyJeJeHmzNUiyzPM"), 1580389389);
    this->KzCtPGqdvsfXqnHN(965569.7778154782);
    this->njwScfI(string("SfrDekJwugfXoJCXbGkn"));
    this->KQTsyaJ(string("NEquSoZVFCyDKyUtFagWaxiYwEPVNhhqQCSMALXEVtusQQhDWdFSkwIieimZLTXIYvkuUWAAJYRrexKAxhOWmmkLUFIOwulCGRlHmsqhhaoHFVBtqpHDNWIMMjzyKlbRCHFjbMaVKoZHWEgbMpdbyUPrsyIveb"), false);
    this->RzxUayM(string("NxVIVUFm"), 1590949347, 1918465975, 764741.1921792201);
    this->ettbZxysLv(false, 327057.397069628, -557311441);
    this->VntBaFUzQstDU(false);
    this->eYmfTHahnWp(true);
    this->YvdzjCUHxWQIMVAP(1638592647, false, false, -814365.9383861445);
    this->XRXTYiqHm(-707613.6722304351);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AljPB
{
public:
    bool ajzYGMNXUghnWT;
    string qsOwVf;
    string pVloqgExdiKE;
    double elFPxD;

    AljPB();
    void LcraQ(bool txXvvd, int ufIbWSlfbtJ, string uErUtEHUDtcAsl, bool elvvG);
    int CHMEgxbyEiVfkPqJ();
    void uzitf();
    void OrYcwATfCujDYYG(string hbSoQsMfyo, bool pfdCalzescyKXN);
    void ziKBQOoltRr();
    bool xkAumWapEvKgJR(string ebEvSjdYfLuqR, double QkCTWTi, bool AgcOJ, double TzQCUJorAbSzt);
    bool pYSAopnoycnJz(string diLJLvJEtaIhMu, double unkod, int sRUKFUDyiniIJSF, double HSBBCMtHhODq, int fcuaBIEa);
protected:
    string KyztREwHszTbilAD;

    void vkIafgBhcp(bool fHaaQKhlbnTVX, bool DqRgGxRdiXTIOqt, int zwVNX, bool JSkRsgLotIj);
    int zNEKiHJ(double vLJZasPDtTOpyCRn);
private:
    bool HnQnozo;

    string VdITsBnXTOoclPr(bool rmgUGSKaDwIu);
    int zxkyUY(int UnxxwyviBf, bool WepUgGeTjksPryzR, bool xDwAPma);
};

void AljPB::LcraQ(bool txXvvd, int ufIbWSlfbtJ, string uErUtEHUDtcAsl, bool elvvG)
{
    bool iuvZjuMoPpkJu = true;

    if (txXvvd != false) {
        for (int ItrhIKlzakZAd = 1979995261; ItrhIKlzakZAd > 0; ItrhIKlzakZAd--) {
            iuvZjuMoPpkJu = ! txXvvd;
            ufIbWSlfbtJ += ufIbWSlfbtJ;
        }
    }

    if (txXvvd == false) {
        for (int ZutkXCaaZPqTubF = 582293533; ZutkXCaaZPqTubF > 0; ZutkXCaaZPqTubF--) {
            iuvZjuMoPpkJu = ! elvvG;
            txXvvd = iuvZjuMoPpkJu;
            elvvG = ! txXvvd;
        }
    }

    if (iuvZjuMoPpkJu != true) {
        for (int aIhNtmk = 897842108; aIhNtmk > 0; aIhNtmk--) {
            continue;
        }
    }

    if (ufIbWSlfbtJ == 330135044) {
        for (int ylEXEjEK = 1720589101; ylEXEjEK > 0; ylEXEjEK--) {
            uErUtEHUDtcAsl += uErUtEHUDtcAsl;
            iuvZjuMoPpkJu = elvvG;
            iuvZjuMoPpkJu = elvvG;
            ufIbWSlfbtJ += ufIbWSlfbtJ;
            uErUtEHUDtcAsl = uErUtEHUDtcAsl;
        }
    }

    for (int CqvfNrIkxgAIqG = 848553275; CqvfNrIkxgAIqG > 0; CqvfNrIkxgAIqG--) {
        iuvZjuMoPpkJu = ! txXvvd;
        txXvvd = ! elvvG;
        elvvG = ! txXvvd;
        iuvZjuMoPpkJu = txXvvd;
    }

    if (elvvG == false) {
        for (int ZsevqAPFLpm = 463925440; ZsevqAPFLpm > 0; ZsevqAPFLpm--) {
            iuvZjuMoPpkJu = iuvZjuMoPpkJu;
            txXvvd = txXvvd;
            elvvG = elvvG;
            iuvZjuMoPpkJu = ! txXvvd;
            txXvvd = ! txXvvd;
            elvvG = ! txXvvd;
        }
    }
}

int AljPB::CHMEgxbyEiVfkPqJ()
{
    bool JWeOpNSXf = true;

    if (JWeOpNSXf != true) {
        for (int yxcpD = 1742774641; yxcpD > 0; yxcpD--) {
            JWeOpNSXf = ! JWeOpNSXf;
        }
    }

    if (JWeOpNSXf == true) {
        for (int thwpEcaQngWtSQWC = 1751536499; thwpEcaQngWtSQWC > 0; thwpEcaQngWtSQWC--) {
            JWeOpNSXf = ! JWeOpNSXf;
            JWeOpNSXf = ! JWeOpNSXf;
            JWeOpNSXf = ! JWeOpNSXf;
            JWeOpNSXf = JWeOpNSXf;
            JWeOpNSXf = ! JWeOpNSXf;
            JWeOpNSXf = JWeOpNSXf;
            JWeOpNSXf = JWeOpNSXf;
        }
    }

    if (JWeOpNSXf == true) {
        for (int LlqJemMxIeUTH = 1300820578; LlqJemMxIeUTH > 0; LlqJemMxIeUTH--) {
            JWeOpNSXf = JWeOpNSXf;
        }
    }

    if (JWeOpNSXf == true) {
        for (int AYrSGMoPU = 1127361751; AYrSGMoPU > 0; AYrSGMoPU--) {
            JWeOpNSXf = ! JWeOpNSXf;
            JWeOpNSXf = ! JWeOpNSXf;
        }
    }

    return -1875184841;
}

void AljPB::uzitf()
{
    double CbkmbEqHnek = 546528.3903561342;
    int AOLtDYyhDi = -1234159163;
    double IUiOPnbwOBr = 488438.60603121144;
    bool wZlUPmemtLPYfh = true;
    double jujkDHYhd = 884555.3056644524;
    string xAklpxFdrqTk = string("mEmlqJprNMCljwLETFRFidCDEkBycshHFATazVmHQbOHeuKyAIrSmcdaSGfUggswaOQpNNUgpQlBShIokGtzozjxKrDVfJMBkCKBhjffmTCyqnzULyRWTnjFDRudoFnJxbMDynrJSEsyZLbqOwaRIRDhTwyNltmwMwoLgSnmnWrKInfkkLxuBTrtkhqBhddADYpTkdfBkckYSNtHntURuKHUTLKzqjNrLXQFmcvpKWDwIIHwKPTddZqEDh");
    string LOpyg = string("LCTBBWLeljFzWGKEejclOKPQOuLBhrLvVCPRZIhITFcWBvQYexLMraWnTVpjmyQGWPsbQgqDelAMyCH");
    string yBOjfjBrbNHVC = string("JPgaDOFllzfKUPVPbxqlUXRIOKhZKSrDyUxvWaWiEQKpxOjIB");
    bool nLBCtDa = false;
    string mQqtRQ = string("OvpIhUAUirblhmUuOLUnsmhZsgCkekItHIarQOXFylMSqgkoZVLGNRhXicAPJuXlKkdTkpAnLzqQEupWMdldckJRKTMwaDvCIzKZDXFZZMIfvcIrUAuOebIWQmNIcggxrYuljRKNVpFEILmCaoxkZuAmqgmMQXaZdGyzxdrRPJRHuYlawBRBUXtCUObupOitcAbJwbOdpbPhQooHoxZSRsgDZnnYDLSD");

    for (int HujwLqAhuh = 1338700149; HujwLqAhuh > 0; HujwLqAhuh--) {
        continue;
    }
}

void AljPB::OrYcwATfCujDYYG(string hbSoQsMfyo, bool pfdCalzescyKXN)
{
    int sSSRMpJdtzrnrChT = -524229198;
    string tYVwTXEyXRIa = string("hNHVfSkdJdUWGhxxkzMEZbgLyvLxTvfDnCYvFoFtWcsJBFJNPhXrVF");
    double KygRC = -634319.5633579486;
    bool DgaoWmruUlSOtShP = true;
    bool PLtIRlSg = false;

    for (int LJIWJKPftzC = 939337502; LJIWJKPftzC > 0; LJIWJKPftzC--) {
        pfdCalzescyKXN = PLtIRlSg;
        DgaoWmruUlSOtShP = pfdCalzescyKXN;
        sSSRMpJdtzrnrChT = sSSRMpJdtzrnrChT;
    }

    for (int OvSdRpE = 581799084; OvSdRpE > 0; OvSdRpE--) {
        PLtIRlSg = ! DgaoWmruUlSOtShP;
        pfdCalzescyKXN = ! DgaoWmruUlSOtShP;
    }

    for (int eqdvvB = 1629314525; eqdvvB > 0; eqdvvB--) {
        hbSoQsMfyo = hbSoQsMfyo;
    }

    if (pfdCalzescyKXN != false) {
        for (int XrgkhgH = 1602487237; XrgkhgH > 0; XrgkhgH--) {
            PLtIRlSg = ! PLtIRlSg;
            DgaoWmruUlSOtShP = ! pfdCalzescyKXN;
        }
    }
}

void AljPB::ziKBQOoltRr()
{
    double SOhbsGSgSOUoj = 301837.24696004635;
    string RjUWON = string("EbrizAxijgCphiUrthKJJuCslZsRRHRKRAfVnpDWZmVJfdIemdOmyMghgxklMteETqcAJLPoDTkMFGZHXfulbspKeFOWvHymStgQJYLDdVDeinpVsaahXrOKYppNgjlKQzPcagTPrONWHwMzSanmwQfWDqeKAczPGoVxcqOhiRJOiKpQfNZFTuwHiyyiWVpVUqrffTehXAKvcyytY");
    int ORvyoqfS = 2051327889;
    int vqDBzoQAClA = 771597225;
    string GFPaXsbgN = string("bIQhDpXTZeqeuzIXTnMSeCoFOVvqJvAzwMXIJrdzYLIokcfgdbnImYfHgtMYYKxkVxxmecxtULbWEGyoUuqaeVoRTTpJDqQLealESVuhcLRFvKtyGwqiJcAbTgkHiuhzwHGxMkrNFWNdCPMjAhLupapfxPyBJtDDAQHkZfpslfnfYncpsDjRIPJNCyVQuypSEuxDmpcVMdOtsLJroKqbwhbcFqtyJzIvLbYYIruBWxBbTQgxBFCQlzBgtXDXw");
    bool ZLkdHPFuqWqX = true;
}

bool AljPB::xkAumWapEvKgJR(string ebEvSjdYfLuqR, double QkCTWTi, bool AgcOJ, double TzQCUJorAbSzt)
{
    string oulLJCDatpWAu = string("JSaqEsvFnFsOnUWKotUPWCLKDrXNuyrlRuoCJyQMvCkPFYEFX");

    for (int WjJZWVbZYABT = 1694658446; WjJZWVbZYABT > 0; WjJZWVbZYABT--) {
        continue;
    }

    for (int pCbodeoYdJUeo = 1260796873; pCbodeoYdJUeo > 0; pCbodeoYdJUeo--) {
        QkCTWTi -= TzQCUJorAbSzt;
        TzQCUJorAbSzt *= QkCTWTi;
        ebEvSjdYfLuqR += oulLJCDatpWAu;
    }

    for (int LnLzZNGt = 194145146; LnLzZNGt > 0; LnLzZNGt--) {
        ebEvSjdYfLuqR = ebEvSjdYfLuqR;
    }

    return AgcOJ;
}

bool AljPB::pYSAopnoycnJz(string diLJLvJEtaIhMu, double unkod, int sRUKFUDyiniIJSF, double HSBBCMtHhODq, int fcuaBIEa)
{
    double yKHfZDVHdGlE = -546307.2103986827;

    if (sRUKFUDyiniIJSF > -1349733390) {
        for (int KcmVlsh = 767981956; KcmVlsh > 0; KcmVlsh--) {
            fcuaBIEa /= sRUKFUDyiniIJSF;
            HSBBCMtHhODq += unkod;
        }
    }

    return false;
}

void AljPB::vkIafgBhcp(bool fHaaQKhlbnTVX, bool DqRgGxRdiXTIOqt, int zwVNX, bool JSkRsgLotIj)
{
    double doKCozm = 377804.5636907552;
    int pMKMFcELXUHEzFP = 1439368377;
    string oiBTtKTvvDffsc = string("YKWQusOSehgZhCYhqJMVQAmTEQVqSGHsysPOLfnCfqfCbffuViFiCkJoohWpuaJOdrPIbXvluJzmGxXZRlOcVIweiBKgHoMbgBLfMNFYpyFVwHlkQSlQqSEKMxtIZcLjzUWzwcJVjDRApWWGDWGhMyQZCtcyjSHYbxF");
    string sqrBEAsyuIym = string("snWMoQrrnsRWDpqfJeIvraWUFvwxIWLNzvPjzrZVImQoFMsunHHgqMHCJCXYMJqNacDZcEjVMxEbeXbbgGShLeTPbuoGWugrG");
    int fhVGqHK = -1826485625;

    for (int gmzMeTZKMaw = 1495969204; gmzMeTZKMaw > 0; gmzMeTZKMaw--) {
        JSkRsgLotIj = ! fHaaQKhlbnTVX;
    }
}

int AljPB::zNEKiHJ(double vLJZasPDtTOpyCRn)
{
    string RYtyKcUJgVf = string("zYTLMIOjRcOGleZpcvTKlDUpObiaHRchxyJdJaWYiNmxhUSdHSmHxoPHnYjHVZAdKNrNiApYQNEJeQEyUYKgnbgjhjUVNoTcBxdjYIPEkWmanIysfWlAjSDoLnrvoQegOnZHOhNBxWfBerBJfIbpzDFsyKEiuRLCrhPeqRkeYWeem");
    bool PdFIFAURsuyA = false;
    double iIOGNKeNlLwO = -818211.6782247262;
    double vTOjVLo = -745058.9842199053;
    bool GCuROiptJRPm = true;
    bool LSHxMJxRDVp = false;
    int XcncPNmGKUf = -938008485;
    string opMOTTlXZBeBzL = string("KfTCKrqhlfceGyKgpZAZGZlcwubmSfSVmhjhoyVngZrdFAIdQmbAgnopHnoRLvDrqVlytJbDQgMatYkIOSEXQwBMTRuNeAiUl");
    int tPtIVFz = -657160099;
    string zTErNnytlPBY = string("jBRTeJKuszLfGgcChcclFUOGUoLNRJoTZrPbErejFvTMPAeKfAjflgRatTthPNFtrkCIeIvHqOqhvwcqhcejZdQhhVmoCytSGaqdquCCMPYjLjRCHYuhmgGnwOQpygGZDtVcvsbrSwoMQkGpjFWCdtcfSnK");

    for (int pauLYpbUfRHXWNM = 553885071; pauLYpbUfRHXWNM > 0; pauLYpbUfRHXWNM--) {
        tPtIVFz += XcncPNmGKUf;
    }

    for (int TqFYInffORT = 722153118; TqFYInffORT > 0; TqFYInffORT--) {
        continue;
    }

    for (int hnmvPadwekmkfYaz = 1863257813; hnmvPadwekmkfYaz > 0; hnmvPadwekmkfYaz--) {
        LSHxMJxRDVp = GCuROiptJRPm;
    }

    for (int cVozpZ = 930630807; cVozpZ > 0; cVozpZ--) {
        XcncPNmGKUf *= tPtIVFz;
    }

    return tPtIVFz;
}

string AljPB::VdITsBnXTOoclPr(bool rmgUGSKaDwIu)
{
    double jqigmVNxNONlQqf = -93316.41142789336;
    bool RxYHHWmw = false;
    bool DLmgZBRTE = false;
    bool DWaoNK = false;
    string qLqvkKkQc = string("AUNalepyWLwdPwgRpzZOTJJkggBosqVWmPuhDXAPGijwgnwclaCgPSNBwPZfTUGlHOZvRFqxjFSq");
    string dqrLCULtT = string("kNYmxdjRehIGSvHvGaxNzOBubJtNAFjrZDeuEexQiAStmUlrJkSUVXEYxFZELuRMFFDYCGyPrqaThhbEWEtwKbUovMatYqVvloKmXLdyXnsgMzHvxUbSvOlSEItSWtPzSJBSGPcjrvAkyKwcCmBuJZqzkotLQgEiIHXPWhDbFXtsULMdDmyxNEWjhzrumRkcREAmqLCyKFvprCvMZmzEVSRZsDHncBgiavpYUFrurQLnqQmwzlYufLdgbz");
    double GRnURnSskHgsN = 291170.70433166355;

    for (int PWNCRobhdiu = 1082396521; PWNCRobhdiu > 0; PWNCRobhdiu--) {
        RxYHHWmw = DLmgZBRTE;
    }

    for (int PfyBrS = 267943631; PfyBrS > 0; PfyBrS--) {
        GRnURnSskHgsN = jqigmVNxNONlQqf;
    }

    return dqrLCULtT;
}

int AljPB::zxkyUY(int UnxxwyviBf, bool WepUgGeTjksPryzR, bool xDwAPma)
{
    int wIVgrI = -1350596258;
    int dEAZHZB = 317397874;
    string YTEIpowBJCCNe = string("bp");

    for (int PHoMneGrKyi = 892692061; PHoMneGrKyi > 0; PHoMneGrKyi--) {
        xDwAPma = ! xDwAPma;
    }

    if (UnxxwyviBf <= -1350596258) {
        for (int BGyFXqZUP = 341059137; BGyFXqZUP > 0; BGyFXqZUP--) {
            xDwAPma = ! WepUgGeTjksPryzR;
        }
    }

    return dEAZHZB;
}

AljPB::AljPB()
{
    this->LcraQ(false, 330135044, string("nCGRPbpMwbHWvanoKLVtPMrAwMETawwDDjQOpmFPPHjeBnZbdOqMHURRsJhYmJLpRLpxVGCWiOSUvRCYNqyWPFLWfyrZsyIXBeCyLuVGXbJHZLQZQuCEnGhBYcDUxFihYtgaKhrVPMhnBgnYmPdJNnbXFWEJgPAULQticaVlzA"), true);
    this->CHMEgxbyEiVfkPqJ();
    this->uzitf();
    this->OrYcwATfCujDYYG(string("bAqubyjFbXNpPPyvgBqwCyGuJRmvprFnqBzQXjTccyzFcGPDdAuoPFETBORkvuOvMTyCGV"), false);
    this->ziKBQOoltRr();
    this->xkAumWapEvKgJR(string("rlQwzNaxNDkhCbgIyvRnrYynYVUdeQPljWUsdBNrDgjFJvbMVwhrOhsbofMpRMlVqpyduLgNvxUjpynCRUMoPHallpFiXJFcivVDVXjeAUSwuzlq"), 212144.09126030043, true, -331802.35056561517);
    this->pYSAopnoycnJz(string("ItNkABxiSeUrinFhfXUFcezPesGBqYNMNOlkuOoXShJBSStQNfnLDnuSqLzNiPBXjDoddcTEiGrPZttYlQrCJaBXMakmGaRrHMKpJwMEDlfPBKYwLjGIlJyvyeoTNOBKJvGeajyMsmqBCiwvfZKdHbjUUZOCnQQdKPAjzLliNiqfRcVQSuxopBXzLcVULGXKwVBlmzwIzHTzdmNkuoOGebqUBrnrD"), 700536.999760745, -1349733390, -416132.30020764476, 1557845641);
    this->vkIafgBhcp(false, false, -1721802197, true);
    this->zNEKiHJ(-613442.6721244653);
    this->VdITsBnXTOoclPr(false);
    this->zxkyUY(-39072467, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NNZEEPl
{
public:
    string zSAMZhyVpgurCbH;
    int nLqtCN;

    NNZEEPl();
protected:
    string feasDtGeRXqSPU;
    string MLqgHN;
    bool kIGTKcGd;
    double RHSjpyeboFdI;
    bool yAVnCbVZsY;

    double QDDadzpNYgh(double bKlutLjSeWrAmad, int cJzisDS, string xoTBbRjWu);
    string scEQwavlh(double TvdaADNDTSCIg, int VzjlIrpxazOs, string DoOmVraUtTdhtyKZ, double PdCTe);
    void LOFMq();
    bool DnPUjAJLk(int lNhWgmdVoLFO, int SiZJUJSmzG);
    bool YyrwyH(int bwqMgCQWykhkCLy, string ZmoQyBHFj, double rahelQJNhaoZikL);
    double nSrkumvtELEF(bool BbJhfwKZsbBRa, bool pAGjlgbqtItyF);
    int PzhgAkQkcujvkxnz(double zHSshZFaBETG, int OcFsuTGBVJJuIF, string qnFpC, string ctWopHIGdGEkCFYE, bool eHFKrYS);
private:
    string jHqywho;
    double vxqmpdJfLgttsWj;
    bool yYIJYsIWYPKLEwqG;
    double LvaNeurW;

    void ygSNZzssB(string KZzCIKrSy, bool yuLmDgXvmZGccEw, bool jPRKNWUlmuoTbv);
    double YbGPDA(double dKertfWmeaF, double TzXuB, string nrFrDOKeNAc, int wLMcBOoOtUNUZ);
    bool YvqboqlXOwKnn();
};

double NNZEEPl::QDDadzpNYgh(double bKlutLjSeWrAmad, int cJzisDS, string xoTBbRjWu)
{
    int PHauYkqGwSOjFYf = -1879200740;

    for (int ibKxbWrEfy = 1721791927; ibKxbWrEfy > 0; ibKxbWrEfy--) {
        cJzisDS -= cJzisDS;
    }

    for (int jdwLfElllNo = 589241364; jdwLfElllNo > 0; jdwLfElllNo--) {
        cJzisDS /= PHauYkqGwSOjFYf;
    }

    for (int bsodkxgbTVUpzXA = 1707872095; bsodkxgbTVUpzXA > 0; bsodkxgbTVUpzXA--) {
        continue;
    }

    return bKlutLjSeWrAmad;
}

string NNZEEPl::scEQwavlh(double TvdaADNDTSCIg, int VzjlIrpxazOs, string DoOmVraUtTdhtyKZ, double PdCTe)
{
    double ZfxHjERAXCW = 963105.4971298652;
    int exUkdfwvurWdMy = 1844434575;
    bool pMmugFkWFebwEne = true;
    int YYpflHxRXRbgG = -295282452;
    string VxCjJnzpQKr = string("NjHdZHedULNlVWhknGBbGnCjWCIJvgHOcaegRrBiIOZhqKmWdNvaXcwbXyYDjVMVltqiFnkALRzBWpqMAPdeOZioGpbRzZrKolZkUvtbbpwwxJpJucMskcMOUrOymwWFNd");
    double LlVFcdXD = -22413.057465217575;
    double HqjUAbzMyMlicPOy = 210582.28390694756;

    if (VzjlIrpxazOs > 1844434575) {
        for (int tpqKLOigrmGq = 587959549; tpqKLOigrmGq > 0; tpqKLOigrmGq--) {
            PdCTe += ZfxHjERAXCW;
        }
    }

    if (TvdaADNDTSCIg >= 963105.4971298652) {
        for (int CwyQxUUE = 438922120; CwyQxUUE > 0; CwyQxUUE--) {
            TvdaADNDTSCIg /= ZfxHjERAXCW;
        }
    }

    return VxCjJnzpQKr;
}

void NNZEEPl::LOFMq()
{
    double cznisDOtPuxSaIP = 993543.7558981423;
    string CVGkAZqCjanWHZe = string("DlzPJUrEvHIFjYkmfTKckNELgcaIFrEioncXWHJjJkrrRHnCpUFYhERJnFhkFJjPLEnyhKlSGgIukxrYrzGLfUsXbrTQEEswHPCYiNLyUIzTfPwkYjnJzfHyNTtrUDdrkZtrAvhPJGpiSAZFhHlRybCXrekIoAmMYMaswJSqhOlgdyEQOcCmovkYIwJHkQPYnmDqoplpPFPEiciHYgVWobFgEodFcTUwQlszfxIQemHwtfNnbn");

    for (int UWoywZMGYYnHr = 1918279191; UWoywZMGYYnHr > 0; UWoywZMGYYnHr--) {
        continue;
    }

    for (int VFnpSaB = 1141604546; VFnpSaB > 0; VFnpSaB--) {
        CVGkAZqCjanWHZe = CVGkAZqCjanWHZe;
        CVGkAZqCjanWHZe += CVGkAZqCjanWHZe;
    }
}

bool NNZEEPl::DnPUjAJLk(int lNhWgmdVoLFO, int SiZJUJSmzG)
{
    string akPnVnh = string("zcmcbjntMNwG");

    if (lNhWgmdVoLFO <= 2049042948) {
        for (int LwUXNyWsUuJ = 2024840852; LwUXNyWsUuJ > 0; LwUXNyWsUuJ--) {
            SiZJUJSmzG *= lNhWgmdVoLFO;
            lNhWgmdVoLFO = lNhWgmdVoLFO;
            akPnVnh += akPnVnh;
        }
    }

    if (lNhWgmdVoLFO == 2049042948) {
        for (int XMDkvynyWbVAJQ = 213925802; XMDkvynyWbVAJQ > 0; XMDkvynyWbVAJQ--) {
            SiZJUJSmzG -= SiZJUJSmzG;
            SiZJUJSmzG += SiZJUJSmzG;
            SiZJUJSmzG = lNhWgmdVoLFO;
            SiZJUJSmzG /= lNhWgmdVoLFO;
            lNhWgmdVoLFO += lNhWgmdVoLFO;
        }
    }

    for (int ZprkijJqhBSP = 2127865348; ZprkijJqhBSP > 0; ZprkijJqhBSP--) {
        lNhWgmdVoLFO = SiZJUJSmzG;
        SiZJUJSmzG = SiZJUJSmzG;
    }

    if (lNhWgmdVoLFO < 2127880869) {
        for (int pyUAQIrU = 726160759; pyUAQIrU > 0; pyUAQIrU--) {
            akPnVnh = akPnVnh;
            lNhWgmdVoLFO = SiZJUJSmzG;
            lNhWgmdVoLFO = lNhWgmdVoLFO;
            lNhWgmdVoLFO /= SiZJUJSmzG;
        }
    }

    if (SiZJUJSmzG < 2127880869) {
        for (int lfAyJh = 310005662; lfAyJh > 0; lfAyJh--) {
            SiZJUJSmzG /= lNhWgmdVoLFO;
            SiZJUJSmzG = SiZJUJSmzG;
            SiZJUJSmzG += lNhWgmdVoLFO;
            SiZJUJSmzG *= lNhWgmdVoLFO;
            lNhWgmdVoLFO /= lNhWgmdVoLFO;
            SiZJUJSmzG -= lNhWgmdVoLFO;
            SiZJUJSmzG -= SiZJUJSmzG;
            lNhWgmdVoLFO /= SiZJUJSmzG;
        }
    }

    for (int LaxJcr = 1025064210; LaxJcr > 0; LaxJcr--) {
        SiZJUJSmzG -= lNhWgmdVoLFO;
        SiZJUJSmzG = SiZJUJSmzG;
        lNhWgmdVoLFO /= SiZJUJSmzG;
    }

    for (int aAlVfJbEkIUDWa = 1745391930; aAlVfJbEkIUDWa > 0; aAlVfJbEkIUDWa--) {
        lNhWgmdVoLFO += SiZJUJSmzG;
        SiZJUJSmzG -= SiZJUJSmzG;
        lNhWgmdVoLFO *= SiZJUJSmzG;
        SiZJUJSmzG += lNhWgmdVoLFO;
        SiZJUJSmzG = SiZJUJSmzG;
        SiZJUJSmzG *= SiZJUJSmzG;
    }

    return false;
}

bool NNZEEPl::YyrwyH(int bwqMgCQWykhkCLy, string ZmoQyBHFj, double rahelQJNhaoZikL)
{
    int OaNpDQOySC = 1344732616;

    if (ZmoQyBHFj != string("eMXHJdWOTkirnzyfOtaFALlblOrSYCvemzOYEzCEMxoziCzkXUpHdIdZRORPxtjKCZNMBNBHUFmedjmjXUpxghWpreaNvGxtobhBQkzWyAJMUmOROntTdJuExMudruTORQIEPjPCMKhpaMDnMLiAEHAjThEuYHrKUsCZXksvMRIYKCUnUBiprbjqhKkmHyITFSpkwpCoGXPcLBHtLznNRErGzLcsAoptGGrVhrqBBfbIDnnXlbaGkWwpdedi")) {
        for (int EglKaohtTbPec = 204757811; EglKaohtTbPec > 0; EglKaohtTbPec--) {
            continue;
        }
    }

    for (int mATQunPm = 1941404000; mATQunPm > 0; mATQunPm--) {
        OaNpDQOySC -= bwqMgCQWykhkCLy;
        OaNpDQOySC += OaNpDQOySC;
        ZmoQyBHFj += ZmoQyBHFj;
        bwqMgCQWykhkCLy -= bwqMgCQWykhkCLy;
        OaNpDQOySC = OaNpDQOySC;
        bwqMgCQWykhkCLy /= OaNpDQOySC;
        rahelQJNhaoZikL = rahelQJNhaoZikL;
        OaNpDQOySC *= OaNpDQOySC;
    }

    if (bwqMgCQWykhkCLy == 1344732616) {
        for (int TIshjeln = 1495218220; TIshjeln > 0; TIshjeln--) {
            OaNpDQOySC /= bwqMgCQWykhkCLy;
        }
    }

    for (int mJlcTPGmeFkifkF = 26017213; mJlcTPGmeFkifkF > 0; mJlcTPGmeFkifkF--) {
        rahelQJNhaoZikL += rahelQJNhaoZikL;
        rahelQJNhaoZikL += rahelQJNhaoZikL;
    }

    for (int GrrXUEFjbM = 1942229164; GrrXUEFjbM > 0; GrrXUEFjbM--) {
        continue;
    }

    for (int SaxROvZKFx = 832642908; SaxROvZKFx > 0; SaxROvZKFx--) {
        continue;
    }

    return true;
}

double NNZEEPl::nSrkumvtELEF(bool BbJhfwKZsbBRa, bool pAGjlgbqtItyF)
{
    int UKXgJvaDHqDn = 384802046;
    string AtFBgHLDAS = string("FOLgXDvxlJmPnTfOfnimXHvbmskqZBTcxwwwYGhaiNVHvEd");
    int TheIjBdgLjrzgX = 1294485360;
    double HkkCx = 963640.9359054859;

    for (int TKfNioB = 2059335477; TKfNioB > 0; TKfNioB--) {
        continue;
    }

    for (int SfqiPqemxEdgVIzG = 2081394829; SfqiPqemxEdgVIzG > 0; SfqiPqemxEdgVIzG--) {
        TheIjBdgLjrzgX -= TheIjBdgLjrzgX;
        BbJhfwKZsbBRa = BbJhfwKZsbBRa;
        AtFBgHLDAS += AtFBgHLDAS;
        TheIjBdgLjrzgX /= UKXgJvaDHqDn;
    }

    for (int ejbePKyBU = 73523237; ejbePKyBU > 0; ejbePKyBU--) {
        UKXgJvaDHqDn /= TheIjBdgLjrzgX;
        TheIjBdgLjrzgX *= UKXgJvaDHqDn;
        BbJhfwKZsbBRa = ! BbJhfwKZsbBRa;
        TheIjBdgLjrzgX /= UKXgJvaDHqDn;
    }

    for (int pqiWyll = 187976402; pqiWyll > 0; pqiWyll--) {
        BbJhfwKZsbBRa = ! BbJhfwKZsbBRa;
        AtFBgHLDAS = AtFBgHLDAS;
    }

    return HkkCx;
}

int NNZEEPl::PzhgAkQkcujvkxnz(double zHSshZFaBETG, int OcFsuTGBVJJuIF, string qnFpC, string ctWopHIGdGEkCFYE, bool eHFKrYS)
{
    bool uzJubK = true;
    bool RamOfC = true;
    int rBAaIFPLV = 27689274;
    string ThONusKyphIG = string("fvYiTvAljufCCgHLNhCtyknBCmyhlYpPjPeWHyOFjGkYhWBzCALJoFZKgIPLBylgKUwWqcXjKwCfFhVhGVOsTYKsrdfGggMRUorAFOUzlkovglIhSWFqXvPWvCGbgGrWTSSFVYlLTYEYoJPyvNlcfSwQbjSadEsnkWcUIIXPEDRmvLtzyHEMmZAiOxnJDMlMwXGhlmTrhTrCjQkD");
    bool oODyvtLQlOycbgRX = true;
    bool POJtYcAc = true;
    int rgDTWXpte = 630356524;
    double vddSLzHBlXRKqYDz = -626054.6190432482;
    bool tCDOlYKEV = false;

    for (int vgQbQviKPmNc = 1825796167; vgQbQviKPmNc > 0; vgQbQviKPmNc--) {
        rgDTWXpte += rBAaIFPLV;
        ctWopHIGdGEkCFYE = ctWopHIGdGEkCFYE;
        uzJubK = ! POJtYcAc;
        RamOfC = eHFKrYS;
    }

    for (int RhgiPqW = 1348661621; RhgiPqW > 0; RhgiPqW--) {
        uzJubK = ! oODyvtLQlOycbgRX;
        POJtYcAc = ! oODyvtLQlOycbgRX;
        qnFpC = ctWopHIGdGEkCFYE;
        rBAaIFPLV /= rgDTWXpte;
    }

    if (eHFKrYS != false) {
        for (int eDnwuNZJOKjQo = 33784849; eDnwuNZJOKjQo > 0; eDnwuNZJOKjQo--) {
            POJtYcAc = ! oODyvtLQlOycbgRX;
            uzJubK = POJtYcAc;
            RamOfC = oODyvtLQlOycbgRX;
        }
    }

    for (int zAjBRR = 883902540; zAjBRR > 0; zAjBRR--) {
        RamOfC = ! tCDOlYKEV;
        eHFKrYS = uzJubK;
        rBAaIFPLV *= rgDTWXpte;
        oODyvtLQlOycbgRX = ! oODyvtLQlOycbgRX;
    }

    for (int dIJUsrvqZc = 2050881995; dIJUsrvqZc > 0; dIJUsrvqZc--) {
        oODyvtLQlOycbgRX = RamOfC;
        POJtYcAc = eHFKrYS;
        OcFsuTGBVJJuIF = rBAaIFPLV;
    }

    return rgDTWXpte;
}

void NNZEEPl::ygSNZzssB(string KZzCIKrSy, bool yuLmDgXvmZGccEw, bool jPRKNWUlmuoTbv)
{
    string UrQaZgC = string("plWmKAyoPelkcGWTEdXIhZiRFSTOuYyRZnCDLXlhiNtBksCQTqpIulGDBRbexPVxYedgbUmcuQbyGdXIWimJFWzIwFpVtIaXPJFnaikUCpYlHyRFnSyPbvAICcltLnWHmibxlPxIQlBFjUpYSjXXUKDTHeAaxkpuLKwydRUWlOiJoMsafsf");
    bool CugdiNeOFOrV = false;
    string XuwEECiXELDf = string("lBldizdVISSyyTTRcnGVgOSNEXEsksOAcFHpnlDfRRFIxTxxqNhwLOizZFqEhNnnxbZDqITCroMBFdVVLFfMzenAgfhtqdUOtiEhPryWfkzZlPalIgmkFgdgailpumrffKcFqrcJliFefHjCBRgDZErwwXzkciQzPXfVnpNnbNbDaEzAtnngYKZisOdDyhaRgnNElmkLXEjbSCXQGlGz");
    string eNlvjSGfDHJ = string("obnQxsqCistIDCwovcmTKOtVsFCWhRjQYDqXXiPAivWWLksvqHcgozUaPQkRYQVLJhNLcGT");
    int cHclibkqduU = -315468834;

    if (UrQaZgC <= string("plWmKAyoPelkcGWTEdXIhZiRFSTOuYyRZnCDLXlhiNtBksCQTqpIulGDBRbexPVxYedgbUmcuQbyGdXIWimJFWzIwFpVtIaXPJFnaikUCpYlHyRFnSyPbvAICcltLnWHmibxlPxIQlBFjUpYSjXXUKDTHeAaxkpuLKwydRUWlOiJoMsafsf")) {
        for (int fWUBVkIRzPbDHpNq = 912138543; fWUBVkIRzPbDHpNq > 0; fWUBVkIRzPbDHpNq--) {
            XuwEECiXELDf = eNlvjSGfDHJ;
            UrQaZgC = XuwEECiXELDf;
            CugdiNeOFOrV = CugdiNeOFOrV;
        }
    }

    for (int mxvrmzlTJrOrW = 1493932999; mxvrmzlTJrOrW > 0; mxvrmzlTJrOrW--) {
        XuwEECiXELDf += eNlvjSGfDHJ;
        XuwEECiXELDf += eNlvjSGfDHJ;
        jPRKNWUlmuoTbv = CugdiNeOFOrV;
        yuLmDgXvmZGccEw = jPRKNWUlmuoTbv;
    }

    for (int lsztOEgHIyz = 539044452; lsztOEgHIyz > 0; lsztOEgHIyz--) {
        CugdiNeOFOrV = CugdiNeOFOrV;
    }

    if (UrQaZgC >= string("lBldizdVISSyyTTRcnGVgOSNEXEsksOAcFHpnlDfRRFIxTxxqNhwLOizZFqEhNnnxbZDqITCroMBFdVVLFfMzenAgfhtqdUOtiEhPryWfkzZlPalIgmkFgdgailpumrffKcFqrcJliFefHjCBRgDZErwwXzkciQzPXfVnpNnbNbDaEzAtnngYKZisOdDyhaRgnNElmkLXEjbSCXQGlGz")) {
        for (int JsRRUmnvaxOpRU = 1747803568; JsRRUmnvaxOpRU > 0; JsRRUmnvaxOpRU--) {
            jPRKNWUlmuoTbv = jPRKNWUlmuoTbv;
        }
    }

    for (int GxMFwpIzKO = 1182685549; GxMFwpIzKO > 0; GxMFwpIzKO--) {
        jPRKNWUlmuoTbv = ! jPRKNWUlmuoTbv;
        eNlvjSGfDHJ = UrQaZgC;
    }
}

double NNZEEPl::YbGPDA(double dKertfWmeaF, double TzXuB, string nrFrDOKeNAc, int wLMcBOoOtUNUZ)
{
    string QCZLlyniGz = string("VMoVlrmytkRadbKEyAsfPnTyxzmWSPwwLGFvCjpMVGHsQUWrbRuzqtEIercuXCzYbhxlXvTIXIIoFmEiXyJavACmzNSTGMUdgGeNeBEbGRuuOcnXrKbeFqkdCXLLz");
    double OwFuXfx = 605202.7137946207;
    int rMXnDiCzm = -1131264770;
    double wBCAexqlSlUy = -707340.0863346648;
    bool ChGBbCiWkrbneAlN = false;
    int NuIxECX = 1376021361;

    for (int kLtmQoclGsfG = 1773852947; kLtmQoclGsfG > 0; kLtmQoclGsfG--) {
        QCZLlyniGz += nrFrDOKeNAc;
        ChGBbCiWkrbneAlN = ! ChGBbCiWkrbneAlN;
    }

    for (int BTIioHPnoqc = 2133228874; BTIioHPnoqc > 0; BTIioHPnoqc--) {
        continue;
    }

    return wBCAexqlSlUy;
}

bool NNZEEPl::YvqboqlXOwKnn()
{
    string Vckmbc = string("etUcDIOoEAdBKDoZlXDhiOWlmsAGloyxWhKDwolOAcnxgLCiCxbHdYxqXsZQEKUuabIaOsQbvTjQPbknBYwvWiwySgqnyDnAzRDwEHuZPzGoyEONaaMcanANJnFvvVAjTndhqLvRZBzQfTXdKXnertIBnvOTSXOPgExGMGdElgdYsoFRerrjJlLSrOSmDGJqgMVHXGUcqzSiJTEWOfaqWMpfNNqYA");
    int pvdqDhyyoqA = -1087338690;
    double vydvNFlLtUsoE = 442946.53804951976;
    bool LoRettJcWUC = true;
    string YnEmqzAeyh = string("sePIxNUCPrJYMnHy");
    int IQbiq = 862638594;
    bool lgHJSllLOJZxZ = false;
    int rAUEczCTMXK = -856319855;

    if (pvdqDhyyoqA != -1087338690) {
        for (int TmgrmFHVFycPr = 570933316; TmgrmFHVFycPr > 0; TmgrmFHVFycPr--) {
            pvdqDhyyoqA = pvdqDhyyoqA;
        }
    }

    for (int XGWUdUZcEOZjSf = 733529838; XGWUdUZcEOZjSf > 0; XGWUdUZcEOZjSf--) {
        IQbiq *= IQbiq;
    }

    return lgHJSllLOJZxZ;
}

NNZEEPl::NNZEEPl()
{
    this->QDDadzpNYgh(-493045.53307428875, -1699924708, string("OcGyYdsiiEIYkYJuOWrWrRRVWzrRjWjtxjzGoCHfeYSRCnGSmLlLEkNdNVikCDWyqLurGBUjaFtAHKUNJfeWhKeJhPrvqIqOiOEaD"));
    this->scEQwavlh(-634965.2794056066, -290543510, string("dVuReTcPcOsmtPaoeyMHskXKGZvFQMLegmbSOhDdASwVHKazNsAAqZSPQaIwufyfgjnPTFWIrKkeXsDoNeEiEeDgsWBwYxmOPgRysFpSpxMXkuWXzJwDfkxLIRkugNhKmxWJBylvInRTzqJsdSaAXfAmDiWrnfPEtXnfouQV"), -225382.74211641971);
    this->LOFMq();
    this->DnPUjAJLk(2049042948, 2127880869);
    this->YyrwyH(544122518, string("eMXHJdWOTkirnzyfOtaFALlblOrSYCvemzOYEzCEMxoziCzkXUpHdIdZRORPxtjKCZNMBNBHUFmedjmjXUpxghWpreaNvGxtobhBQkzWyAJMUmOROntTdJuExMudruTORQIEPjPCMKhpaMDnMLiAEHAjThEuYHrKUsCZXksvMRIYKCUnUBiprbjqhKkmHyITFSpkwpCoGXPcLBHtLznNRErGzLcsAoptGGrVhrqBBfbIDnnXlbaGkWwpdedi"), 319634.8503475029);
    this->nSrkumvtELEF(true, false);
    this->PzhgAkQkcujvkxnz(153702.65835522232, 1640535086, string("ClsmpnQroMOIcNPlivuYaOjIbQFTDaeyoLrXlZdIUrhcJweLSqnMJtjSLRjFBoUfJCVwlBUuHkNhXLxEEa"), string("CEEBwlSzpPQFtcVxOqBVKorUlIRPXapMChUqdwWlbCfseqhHsXeOXDjCaARPonIOuldgCIQKOXk"), false);
    this->ygSNZzssB(string("SKeoRecHlCK"), false, true);
    this->YbGPDA(-676736.04526114, 1043812.8582921479, string("hbgAiFmzgnQTcdYbbPoJIoeqyifZAAuCjtOtSJbzJEYmdohKTmKlidTcJdyHBtEzZnEXPGlvHDIDSzTlhPXNi"), -2083547501);
    this->YvqboqlXOwKnn();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FPAzFakbxAjMIZ
{
public:
    string Xeqed;
    double objxYksNaNQblSEg;

    FPAzFakbxAjMIZ();
    int fCoakZYqIKJWFnw(bool ZUfSXMrxrC);
    double unBiIdUibxKFavqr();
    int HigCWky();
    bool YwEeTQfBErqEOHU(string mXElRMKkdRdA);
    double frPpOPPL(double bhctcHDUCap, bool RexqIdyoS, bool gBYOEYrbF, int aucZPo, bool YcqkfQdPtOAxzd);
protected:
    string kcOqcqCCzZayV;
    double RbnQLS;
    string FFlwUuKHqGOaGqH;
    double wtDxG;

    bool KHMcnpSDRQwTG(double inzdRKtZvdqgC, int mzQqakisX);
    string WjeJuz(double ZWZwrujHSMyaue, double ZsJXDBf, int arLSCfeYfl, double xklwYdT, string tsBDRbNXMSxcTCd);
    void hNNhjbeDnz(bool lnSQkqhuVFMYxWai, bool tCDoIiqwfr, double EEwxHmXyauxtA);
    bool taUCJAfNnSI(double HGWixWRUubSYhWh);
private:
    bool TjRjBNPnxW;
    string VHpJWlirzw;
    string royaYEb;
    int lQreXCWWvHU;

    int EzsJLrpOhXoq(double fKhVubRhcjWR, int WMsvAszmvsD, int yNfrYRWoIdlYLSVN);
    int KMQNCkdWj(double PUYtJFMGlbRM, string sDTrPnpMQtYgZd);
    int CdhXWKbVrsPg(double jxGyyr, string ywkVutXcigkDSr, int tgifkqXdk);
    bool hNnJCImsITwlKC(bool AvZkZxSBjJnNH, bool jctvWDQdi, string HszwRyLDAMuPU);
    string RwIBD();
    void jsHHkNWDlUNiqnhp(double TiZbDpRsgRjrqI, double kjOUgBIfHyCMxtI, int WjCIUDUi, double qnHokcDxAtzti, string qYLcLmI);
};

int FPAzFakbxAjMIZ::fCoakZYqIKJWFnw(bool ZUfSXMrxrC)
{
    double NnZoBidUztyBolr = -121548.15613272297;
    double ikTqQZwr = -916932.1135595273;
    int MnWEXchOCQWcvSp = 867287047;
    int cOwzx = -1964611701;
    string eOGJXsIABG = string("BkvxboUhfnWLIERsrdhEktvxXgViRezXXODenRwisRsrgWJORuPpHEauxlvGGRBCOfkozuSpRTnzKDiqHHFYHusjLRkmNNiVkGlpFKVQEOKqUykuUyTIVpSfyidxCEVUA");
    int MLEBrWzlLp = 1642081324;

    for (int qqsxaXM = 1091424284; qqsxaXM > 0; qqsxaXM--) {
        NnZoBidUztyBolr -= ikTqQZwr;
        MnWEXchOCQWcvSp = MLEBrWzlLp;
    }

    return MLEBrWzlLp;
}

double FPAzFakbxAjMIZ::unBiIdUibxKFavqr()
{
    string AIfKqRqI = string("cnNZMelxHiSQhcEsMwlODSgDXjqPSIpdGvHqGeyqNryDUwqv");
    int DpLTljMXCm = -1376900805;
    double joKnJefVKtR = 628394.8155656796;
    double VTCXXPGDIZFSi = -839995.5452061734;
    bool fiWdYh = true;

    for (int wRPfaZLc = 973676354; wRPfaZLc > 0; wRPfaZLc--) {
        VTCXXPGDIZFSi = joKnJefVKtR;
        joKnJefVKtR /= VTCXXPGDIZFSi;
        DpLTljMXCm = DpLTljMXCm;
        joKnJefVKtR /= joKnJefVKtR;
    }

    for (int onYLLlvslHMs = 431548803; onYLLlvslHMs > 0; onYLLlvslHMs--) {
        AIfKqRqI = AIfKqRqI;
    }

    for (int mFSMgGWGiNYPFMO = 805458221; mFSMgGWGiNYPFMO > 0; mFSMgGWGiNYPFMO--) {
        joKnJefVKtR -= joKnJefVKtR;
        fiWdYh = fiWdYh;
        VTCXXPGDIZFSi += joKnJefVKtR;
        AIfKqRqI += AIfKqRqI;
    }

    for (int aRpyEv = 377966432; aRpyEv > 0; aRpyEv--) {
        VTCXXPGDIZFSi += VTCXXPGDIZFSi;
    }

    return VTCXXPGDIZFSi;
}

int FPAzFakbxAjMIZ::HigCWky()
{
    int JfoiltZotqfhcd = 502411414;
    string gSSAyDdgaXmv = string("eYNWIMLiZLgqyJdLvPiQUvaZdMwZapRDSapnOaNmLCpsGsEIvdGdPKGbZahXndAwjQWzFoFaqxxPStqrzQGhGTlqQGlExuexUdJLGCDGscUlCQDEpmPPwfMgwgmEJZWUWrkziaprIHsEWTXRQVSAWLYXAAPiYwBRclJqfvFbqTRVeewZHLkQOlJoWIzFWXOy");
    int fLwvz = -912700744;

    for (int BZBvXMbYVutf = 1336906237; BZBvXMbYVutf > 0; BZBvXMbYVutf--) {
        JfoiltZotqfhcd += fLwvz;
        JfoiltZotqfhcd /= JfoiltZotqfhcd;
    }

    if (JfoiltZotqfhcd > 502411414) {
        for (int GwukjSRql = 1489092324; GwukjSRql > 0; GwukjSRql--) {
            JfoiltZotqfhcd += JfoiltZotqfhcd;
            fLwvz -= fLwvz;
        }
    }

    if (fLwvz > -912700744) {
        for (int UymvesMQJjIx = 224031571; UymvesMQJjIx > 0; UymvesMQJjIx--) {
            JfoiltZotqfhcd = fLwvz;
            JfoiltZotqfhcd += JfoiltZotqfhcd;
            JfoiltZotqfhcd = fLwvz;
        }
    }

    if (gSSAyDdgaXmv >= string("eYNWIMLiZLgqyJdLvPiQUvaZdMwZapRDSapnOaNmLCpsGsEIvdGdPKGbZahXndAwjQWzFoFaqxxPStqrzQGhGTlqQGlExuexUdJLGCDGscUlCQDEpmPPwfMgwgmEJZWUWrkziaprIHsEWTXRQVSAWLYXAAPiYwBRclJqfvFbqTRVeewZHLkQOlJoWIzFWXOy")) {
        for (int nuDQiEyst = 1206869138; nuDQiEyst > 0; nuDQiEyst--) {
            gSSAyDdgaXmv += gSSAyDdgaXmv;
            gSSAyDdgaXmv += gSSAyDdgaXmv;
            fLwvz /= fLwvz;
            JfoiltZotqfhcd /= fLwvz;
        }
    }

    if (JfoiltZotqfhcd <= 502411414) {
        for (int kvlbwHJktQDh = 1070103845; kvlbwHJktQDh > 0; kvlbwHJktQDh--) {
            gSSAyDdgaXmv += gSSAyDdgaXmv;
            fLwvz = fLwvz;
        }
    }

    if (gSSAyDdgaXmv >= string("eYNWIMLiZLgqyJdLvPiQUvaZdMwZapRDSapnOaNmLCpsGsEIvdGdPKGbZahXndAwjQWzFoFaqxxPStqrzQGhGTlqQGlExuexUdJLGCDGscUlCQDEpmPPwfMgwgmEJZWUWrkziaprIHsEWTXRQVSAWLYXAAPiYwBRclJqfvFbqTRVeewZHLkQOlJoWIzFWXOy")) {
        for (int OTBayATUUwADg = 1250291592; OTBayATUUwADg > 0; OTBayATUUwADg--) {
            gSSAyDdgaXmv = gSSAyDdgaXmv;
            fLwvz = JfoiltZotqfhcd;
        }
    }

    return fLwvz;
}

bool FPAzFakbxAjMIZ::YwEeTQfBErqEOHU(string mXElRMKkdRdA)
{
    bool yhHxwWVHFPYqc = false;
    int YJVWXqhWba = -1086297532;
    bool LXeIO = true;
    string CxmByWMLXUmPPMCf = string("qIVacrEghajpfvtRNQiLUoIHeFJdQPmQiRWnLsAJFWUChtlcveIHMtEIAIJRFpbWSKlvWMIHLbFHAUOxRRxagyjQUtTuLgFOuwKEiNnurUdoruUsCWxXTDYmOvNiZivRDcpQLBugzgFuFjZXDouGLMtzZJZfPDjYFecluqzqmS");

    for (int oeBelmq = 2043077284; oeBelmq > 0; oeBelmq--) {
        yhHxwWVHFPYqc = ! LXeIO;
        CxmByWMLXUmPPMCf = mXElRMKkdRdA;
        yhHxwWVHFPYqc = ! LXeIO;
    }

    return LXeIO;
}

double FPAzFakbxAjMIZ::frPpOPPL(double bhctcHDUCap, bool RexqIdyoS, bool gBYOEYrbF, int aucZPo, bool YcqkfQdPtOAxzd)
{
    string GOADtSiCtEdN = string("CsrbzaFdsqXYPwyRFZsLxAvMKdGTnwSNbGcmczgNFfJKLaszAHjyouPZWLoLpgViD");
    string mxjsARnMWIGVe = string("TovSIvvsVFVweFpmzLAujhRwWdmQcshCWvZ");
    bool sNYoPixhaPVixmg = true;
    double NsvZgculHRlUG = 961369.6500662032;
    int PKhngG = 715394391;
    bool vWYbyt = false;
    string UxmPLCGnkUYaC = string("viBffdtlINWDPAziSLZntkQivMHrdaVCgOyByqnDcsqjWwfA");
    string FDbFQxBfco = string("fUKErxBrEgrtDpWVeYPYWZUzQRPkWEfhHoh");
    string ZgAWiFxWqERU = string("InuSCKUDirFmvDsLeMnCzSskiQGXaFVPtbcnEmuAiUSMoPszeLBiankfGbbsUJUuYBUowvlKnZphFYsvRKYUYBjGldckTbFpynfupiBW");

    for (int QjmaBtwHusZ = 1305786992; QjmaBtwHusZ > 0; QjmaBtwHusZ--) {
        vWYbyt = ! sNYoPixhaPVixmg;
    }

    if (YcqkfQdPtOAxzd == true) {
        for (int WhdlR = 1467854690; WhdlR > 0; WhdlR--) {
            continue;
        }
    }

    return NsvZgculHRlUG;
}

bool FPAzFakbxAjMIZ::KHMcnpSDRQwTG(double inzdRKtZvdqgC, int mzQqakisX)
{
    bool ZwZrKlyrwSlWxnQ = true;
    string PrSMkUzoSjoVLssc = string("nEfrRpdwBGAaLBznLEkpWoyxPAKbaBmJFTCuteOReaQRPDdeFYpGvDhxRLijfXHJBPORXFSMNNgHyHPudaQQLnQEXdIxHgVuKvRfhysMROfghppjOrxVSEFttSnPrqsIpvWGYUAxHfWjCgoTfERLfLNgFJPnVNbJPFDqEhbFLcZreveZGHn");
    double JpsRjtbOxveAcAE = 697000.0073258061;
    double ivXbBvkpg = 9741.008994575814;
    string awAdXUxRrtcSBFSt = string("YasbYtdQezKpdqOlzIcpjQiZnWuOFMEypGSOvvQZhHCrZGtizoAYFCGyOCrADOJpnrkYQlWJeeYELwtAFcaVnVFiMewWnCChxoYEuVxEoetsazcIrpFVkEyHepXGVmNCUeCnSmqAZgrPfxSKWPKbLIsyHqsKGKAbZSAqXwQvyTNAutXyOlqIEqJYwKLtNlGbtKpAuQSxAUKiDVElIehb");
    bool pQELrp = false;
    string jGCBHFlfY = string("eNquiIikDDZiEYSkHQYiJITKyUOegxeoxVoGlLNWzgSpVFMpnqnIFVRXpIeDboyOVhTQdCWHgJhpgBLjpETFFSvkqJlMhdQnIOsTjYmvYXhhyeCAwLnOhIpzpTObCwiVcKdMtTeczdSXwqBfnZKptnTFwjsuPxxmhmLTECevyrCCPfGnwtiZhocETOeVYpBRffsIkOlgUNpDinURUVAMSIXkE");
    int fwvxBXZPHnGFZ = -1578342918;
    double pggCUvGOwjtn = 635528.8443738201;
    double oGReY = 805154.0363511583;

    for (int rERDxcQlqGBCR = 1444870117; rERDxcQlqGBCR > 0; rERDxcQlqGBCR--) {
        mzQqakisX -= mzQqakisX;
        mzQqakisX = fwvxBXZPHnGFZ;
        jGCBHFlfY = PrSMkUzoSjoVLssc;
    }

    return pQELrp;
}

string FPAzFakbxAjMIZ::WjeJuz(double ZWZwrujHSMyaue, double ZsJXDBf, int arLSCfeYfl, double xklwYdT, string tsBDRbNXMSxcTCd)
{
    double kdNcNKjctZVh = -663174.7495453492;
    int DvZpwSshdtI = 1509900317;
    int BXglGPkRFeUBc = 1565772925;
    bool NlxlpdkPi = false;
    bool ShQMONUfjSiOQ = true;
    string OUOlJtuvPVuf = string("OEPEGgHgOwUGoLjnxTTAtAXpkFoSyAcJbHyWsgmnGpmRVwNSjBCBgdfIjLJIeXkky");
    double lpSPZIkjLVtSCvqL = -464562.9321150949;
    string NaVxpvdSj = string("jONWIWOIVUDjdtlSQroLFXsidNmRqsVuAGTCbxBheWpDFsDlPxnVcwptTgcRFhGuSLMjBhBDpxMrZZkpvYyxuMGLNFZJwdBdyOIjcDlSSzuTVkRvCaHRMAncWaWizqHglnnQmqxsPnhLlLeqnmscwGhgiEpXW");
    bool rSBzStBuFwLJnT = false;

    for (int aZHggZLBgIzhevsp = 739769287; aZHggZLBgIzhevsp > 0; aZHggZLBgIzhevsp--) {
        kdNcNKjctZVh -= ZsJXDBf;
        rSBzStBuFwLJnT = NlxlpdkPi;
    }

    if (xklwYdT < 48792.526266465255) {
        for (int kdnVr = 933683754; kdnVr > 0; kdnVr--) {
            ShQMONUfjSiOQ = ! NlxlpdkPi;
        }
    }

    for (int hDRoxBys = 1028922469; hDRoxBys > 0; hDRoxBys--) {
        ZWZwrujHSMyaue -= xklwYdT;
        NlxlpdkPi = ShQMONUfjSiOQ;
        tsBDRbNXMSxcTCd += tsBDRbNXMSxcTCd;
    }

    for (int gttwj = 755140906; gttwj > 0; gttwj--) {
        continue;
    }

    if (BXglGPkRFeUBc != 1565772925) {
        for (int StNUqz = 1928969864; StNUqz > 0; StNUqz--) {
            ShQMONUfjSiOQ = ShQMONUfjSiOQ;
            xklwYdT *= lpSPZIkjLVtSCvqL;
            kdNcNKjctZVh -= xklwYdT;
            BXglGPkRFeUBc += arLSCfeYfl;
        }
    }

    if (DvZpwSshdtI <= 980747088) {
        for (int rafEPaxYuinY = 400829609; rafEPaxYuinY > 0; rafEPaxYuinY--) {
            DvZpwSshdtI -= BXglGPkRFeUBc;
        }
    }

    return NaVxpvdSj;
}

void FPAzFakbxAjMIZ::hNNhjbeDnz(bool lnSQkqhuVFMYxWai, bool tCDoIiqwfr, double EEwxHmXyauxtA)
{
    int mPmwfiYimHZIm = -891821148;

    for (int grkoMNHX = 1800626404; grkoMNHX > 0; grkoMNHX--) {
        EEwxHmXyauxtA -= EEwxHmXyauxtA;
    }

    for (int qOiHpvT = 152134133; qOiHpvT > 0; qOiHpvT--) {
        EEwxHmXyauxtA -= EEwxHmXyauxtA;
    }

    for (int KvxFWMdMbeItP = 535377735; KvxFWMdMbeItP > 0; KvxFWMdMbeItP--) {
        lnSQkqhuVFMYxWai = ! tCDoIiqwfr;
    }
}

bool FPAzFakbxAjMIZ::taUCJAfNnSI(double HGWixWRUubSYhWh)
{
    bool ZWvPhWVleQkyheop = false;
    double WBsISdkNVf = 401800.79962622665;
    double hyXbuheqHAmP = 1011103.1142496135;
    string gLILtDmCq = string("XqeRNyotzuvOExxqiDmPycKwKmkpnzALpdULoAKRLDnpzsyREWcezopNhdejOmRFWhJyzirKRCxWePYSaCTdZobhgjMvSXIACFSrJimSCfvmyzmnZPPDksAYSwEPcvmkDHvhNdvJViUuFmqmfAJOnMaSrMuNxDCKsgBNfFqgKcClJ");
    double EGYfWkzHjsblCTqk = -362905.2826416539;
    double llMTUGPkKondD = 674399.9791815822;
    string ExvPxltdCgkyKXlZ = string("bUKELDhNnivKsAEVRcqPHHjfvIKIwsAHCvhUTKvZEpKsTHGHJKghAn");
    double yVpYaUxTYlAIlKJe = -14867.719383045105;

    return ZWvPhWVleQkyheop;
}

int FPAzFakbxAjMIZ::EzsJLrpOhXoq(double fKhVubRhcjWR, int WMsvAszmvsD, int yNfrYRWoIdlYLSVN)
{
    string ojQwYKAyvt = string("UaHpbpbQbHPkqmkzbBsxtDZlKiXlWMQtLIFsgBcYZkEgNUycZbGyVcmzKUwYtZkrxdVYEYlaLVJlbIJWiozydeciUuOoRqhnUlunPrVuMvkHQbWjmJh");
    bool cMQvIOyZQFT = false;
    int vbwjwGLXvAQQyr = -36461098;
    bool TbJCpWlezN = false;
    double TLVcPfVALQo = -509510.3201990318;
    int iBhXcprFgkQHvujK = 494534312;

    for (int ZYxGLFrJtvB = 509943067; ZYxGLFrJtvB > 0; ZYxGLFrJtvB--) {
        cMQvIOyZQFT = ! TbJCpWlezN;
        vbwjwGLXvAQQyr += yNfrYRWoIdlYLSVN;
        cMQvIOyZQFT = ! TbJCpWlezN;
        vbwjwGLXvAQQyr -= iBhXcprFgkQHvujK;
    }

    for (int iEqQJRBXTja = 875396748; iEqQJRBXTja > 0; iEqQJRBXTja--) {
        TbJCpWlezN = TbJCpWlezN;
    }

    for (int cQGUult = 1975714107; cQGUult > 0; cQGUult--) {
        iBhXcprFgkQHvujK /= yNfrYRWoIdlYLSVN;
    }

    for (int dUZuMFYcwRgmkOF = 1920004737; dUZuMFYcwRgmkOF > 0; dUZuMFYcwRgmkOF--) {
        WMsvAszmvsD *= WMsvAszmvsD;
    }

    return iBhXcprFgkQHvujK;
}

int FPAzFakbxAjMIZ::KMQNCkdWj(double PUYtJFMGlbRM, string sDTrPnpMQtYgZd)
{
    double ydcKGcqkEdB = -535179.0751215726;
    int zqfyyPwx = 1779330911;
    string EnlnXg = string("xyywDXaHDzolFBpgZDLwDBAiilaWdteXRhxGqqIgNsFiLArAHHsywnrIsiaiPIQmFOfWZxtQHilHtHITECsTSrsjxKvAFMTgTwmGQXhxjTgGHiKButVYoTbnIGvOybrZtNaCTkuehCmtYFudBzFmewPBcL");
    bool yFtAwKTAmsq = false;
    int hoAsyM = 1490877794;
    double YWBIiHxLyDoPt = -1008872.2260514318;
    string xcqllf = string("SONnivPVwoMOJTdESHgEPbKrqDxhBksBErdYwEArzdbZRmuQkxkTFYLTsHKVrYXQADtUHfIoFGETvTysTJzPMYCQoFRkKBPNGahQwMowihfRmmXBlRSKArsNVyWMlSpcAzAtfGBBxnCQUPNLnQXfZIlwXSepwNqFbNfXLmXoowpu");

    for (int Lclin = 893365292; Lclin > 0; Lclin--) {
        PUYtJFMGlbRM = YWBIiHxLyDoPt;
        YWBIiHxLyDoPt += YWBIiHxLyDoPt;
    }

    for (int EBIKccLX = 1842337189; EBIKccLX > 0; EBIKccLX--) {
        YWBIiHxLyDoPt *= PUYtJFMGlbRM;
        hoAsyM /= hoAsyM;
    }

    for (int bMrGrKNDwDWLNOkU = 1250957328; bMrGrKNDwDWLNOkU > 0; bMrGrKNDwDWLNOkU--) {
        ydcKGcqkEdB /= ydcKGcqkEdB;
    }

    for (int VeTrN = 1211073263; VeTrN > 0; VeTrN--) {
        continue;
    }

    if (EnlnXg > string("xyywDXaHDzolFBpgZDLwDBAiilaWdteXRhxGqqIgNsFiLArAHHsywnrIsiaiPIQmFOfWZxtQHilHtHITECsTSrsjxKvAFMTgTwmGQXhxjTgGHiKButVYoTbnIGvOybrZtNaCTkuehCmtYFudBzFmewPBcL")) {
        for (int MNTvmD = 1417009007; MNTvmD > 0; MNTvmD--) {
            hoAsyM = zqfyyPwx;
            xcqllf = sDTrPnpMQtYgZd;
            PUYtJFMGlbRM *= ydcKGcqkEdB;
            PUYtJFMGlbRM = ydcKGcqkEdB;
        }
    }

    for (int plLXnFy = 1423509269; plLXnFy > 0; plLXnFy--) {
        continue;
    }

    return hoAsyM;
}

int FPAzFakbxAjMIZ::CdhXWKbVrsPg(double jxGyyr, string ywkVutXcigkDSr, int tgifkqXdk)
{
    string mHCDZTdNzASL = string("OeEKyARUJSxcUKnWdVGVxwgyeibNbcuyuwolmuzSTJxbuKIFuUkrFfxageEcxNZatXcIqmPjbQZecllrQgXbqVFRtfiuUjabXYJwajbJkhapPVVXrCaWmMqdadmzWCObBZJGBByvnFARlUsEcdGviVOhTGQpzoLIRbXyDHgtdpXFpTIihXwZzLXqTsgFktJBYKKfDeXoPjfwXWVIBmgCwHDuzUIKoOSYrJfpjQEaQ");
    string kAihArOApXEXZwSx = string("OmSgIGrbSGnSJsBqcrPZrDWGEwzsmrYJOQTKsLddlcBTnqXTjOqJvIrkiBpFxjnrVnuXadECQuMQhJBxgruXRjyzNNLoavWom");
    int udOXJcEf = 1512661116;
    int PanJzhFL = 321466846;
    int fnWnzgWcXIFROJtK = -670878946;
    double TelcVFkxftqiBNNq = -933875.2196520251;

    return fnWnzgWcXIFROJtK;
}

bool FPAzFakbxAjMIZ::hNnJCImsITwlKC(bool AvZkZxSBjJnNH, bool jctvWDQdi, string HszwRyLDAMuPU)
{
    int MFzyLsiQNE = 1672281442;
    double weyVFg = -731235.6353101723;
    bool FRqAeuVgly = false;
    int RcGvPleIc = -941752955;
    double GNimh = 427024.27726008254;
    bool jHITABShUENgDjcx = false;
    int sHJKntEkFl = 2050377465;
    double ERLPmkLx = 103797.21098974143;

    for (int kEKXcexNVblRBKwy = 2032935262; kEKXcexNVblRBKwy > 0; kEKXcexNVblRBKwy--) {
        continue;
    }

    for (int UAMfbIUHGYJCsv = 789549251; UAMfbIUHGYJCsv > 0; UAMfbIUHGYJCsv--) {
        HszwRyLDAMuPU = HszwRyLDAMuPU;
    }

    for (int rGVdcBdBKJFhAQR = 385127981; rGVdcBdBKJFhAQR > 0; rGVdcBdBKJFhAQR--) {
        continue;
    }

    return jHITABShUENgDjcx;
}

string FPAzFakbxAjMIZ::RwIBD()
{
    string GDIztC = string("wVqwXkIuVAuieDbTPMsMxQvzkAnjEpwOYLcovLadzinheuYeJKXVgcMPCbITUFCmUcjtNCcrANFmwiPduZGYaWCGobkcPbMsLxbJupSFXRKCLRuGIoqQPyOxgpskDQjtZfCkrBVfzXEWCGJrlN");
    string KLHgeNkDLRaMiENv = string("HJCQoEMnaJCQtAwTiLKxccTmsoLJl");
    int jimzuLkJrw = 1696445159;

    for (int YTjif = 284815707; YTjif > 0; YTjif--) {
        KLHgeNkDLRaMiENv += KLHgeNkDLRaMiENv;
        KLHgeNkDLRaMiENv = GDIztC;
        jimzuLkJrw /= jimzuLkJrw;
    }

    for (int bSpcQHDUboTB = 1594907187; bSpcQHDUboTB > 0; bSpcQHDUboTB--) {
        GDIztC = GDIztC;
    }

    if (KLHgeNkDLRaMiENv < string("wVqwXkIuVAuieDbTPMsMxQvzkAnjEpwOYLcovLadzinheuYeJKXVgcMPCbITUFCmUcjtNCcrANFmwiPduZGYaWCGobkcPbMsLxbJupSFXRKCLRuGIoqQPyOxgpskDQjtZfCkrBVfzXEWCGJrlN")) {
        for (int iFXbqjt = 646629685; iFXbqjt > 0; iFXbqjt--) {
            KLHgeNkDLRaMiENv = GDIztC;
            KLHgeNkDLRaMiENv += GDIztC;
            GDIztC += GDIztC;
        }
    }

    if (GDIztC > string("HJCQoEMnaJCQtAwTiLKxccTmsoLJl")) {
        for (int oxWyvjgVBM = 1253804660; oxWyvjgVBM > 0; oxWyvjgVBM--) {
            GDIztC += GDIztC;
            jimzuLkJrw -= jimzuLkJrw;
            KLHgeNkDLRaMiENv += GDIztC;
            GDIztC += GDIztC;
            jimzuLkJrw = jimzuLkJrw;
            KLHgeNkDLRaMiENv += KLHgeNkDLRaMiENv;
        }
    }

    return KLHgeNkDLRaMiENv;
}

void FPAzFakbxAjMIZ::jsHHkNWDlUNiqnhp(double TiZbDpRsgRjrqI, double kjOUgBIfHyCMxtI, int WjCIUDUi, double qnHokcDxAtzti, string qYLcLmI)
{
    string YjgborThDh = string("pXbkAfRuOslkFkISXHbVqituUBGszsPAgAiAhkOnMwhefAQPYTVaboM");
    int uyfynmDMFZwxX = -1946209351;
    int sSiDJzanmoHVHl = 1213513800;
    string aWeqFWdHfzaSxj = string("uSDgTZhpRUrzXHGRHNDrMUcfLTaHCGRLGkNqVcDVwbupywVCSEdNzALBVWLBTVWvwiywYfQy");
    int lfnrXWvukYMXV = -1027686363;
    double BDboEzAVuainaE = 482900.8937908529;
    double ltiepvQUjVmGOq = -369221.9584843876;
    string QDiCqHhiDh = string("jZbjiosEPnESbHpvLRobkcyiclfqYxLFVpdZsMPFnvGdWQhvAVDuyiktJaMdvZhJwuzdSbbTWaemNtteXYkasUoUiEdpazcFOcYU");

    if (aWeqFWdHfzaSxj >= string("pXbkAfRuOslkFkISXHbVqituUBGszsPAgAiAhkOnMwhefAQPYTVaboM")) {
        for (int yolTiDA = 717498319; yolTiDA > 0; yolTiDA--) {
            continue;
        }
    }

    for (int qDpXAOqG = 1549312181; qDpXAOqG > 0; qDpXAOqG--) {
        aWeqFWdHfzaSxj = qYLcLmI;
    }
}

FPAzFakbxAjMIZ::FPAzFakbxAjMIZ()
{
    this->fCoakZYqIKJWFnw(true);
    this->unBiIdUibxKFavqr();
    this->HigCWky();
    this->YwEeTQfBErqEOHU(string("vinprNLrzEvKqoLzQNcAxyelMzNNNwyXGwGZPxRNFLoWTisYxnZhemAsJqAxOmwHnfJfBIJSHkgdifvTcpXxoInsqbfyIFKEjEqOTEaUmzOwylUlPjV"));
    this->frPpOPPL(486363.32193735975, false, true, -483020569, true);
    this->KHMcnpSDRQwTG(-860675.6701071401, -648562704);
    this->WjeJuz(48792.526266465255, -300607.207215539, 980747088, 311936.2392327866, string("lTlvxXruRpbCFTJAYkjXujrwTDiCPSwpFvpExdBWsaNEosjtKJmCwaqTpVuywUjCPvqckFfRzfPplPRCnYPtqYNjgVOmrulhBfbLTUsnSzLXDbjMwnBdHX"));
    this->hNNhjbeDnz(true, true, -673077.1537176749);
    this->taUCJAfNnSI(-32165.82107326013);
    this->EzsJLrpOhXoq(-276576.8953483124, -948620719, 592816594);
    this->KMQNCkdWj(618621.1917182626, string("oEoELQPcflimWqDupLcCqrfdHQneJlyCweOjDKKVZkeGedRmccpmEtDDmULnukvSnNAuKIYnKggtQrYfGiqgIVECieqEHQJxjtyqsDCVvtFLiOZVZGxdNeBfmByyrsDDrOeBiNYOzZaWzAtFLFEJBbQBnGUnCjFvrLZFUAhXgKTJVHXCuwJzEoVxerLdAhMEhanQCbCQfbCrtnGdUXoHrGpXDvkcVbJbuVjDRlUEgCyboAOUrvfAHkcQiQtMlx"));
    this->CdhXWKbVrsPg(911306.1333157476, string("TsPKDKVfAibIGJKnLzNYflNXFkBBmsDnKkJRxuyfzQAqgqMuvkcuPnfEjVoPsBwSSQRVpbJrKQgugJrnGQIlHfbNmVGRLLLDvSzqGUqvjgXVEBSHETyvigsIdePqhhAkm"), -1555973770);
    this->hNnJCImsITwlKC(false, true, string("lfLOZcnMRZNhQtrcKnQaeEQWGBRgHsRWjeOghgrjzGyGsyNIwiZpROsAw"));
    this->RwIBD();
    this->jsHHkNWDlUNiqnhp(190757.1346715274, -496934.2089163997, 1179646508, 866005.2288059109, string("phTvaGGXTomgfyhgaAfoYyWmcopTQIYQeraAWIMTkXtYkLfxuaQQhIEskhTUFzuhMUNDyDWanxlZiHwJOujdSKMrrwqYTCGXswRvCeOynmBoktUuBNKKjSwoznrCFLFmGwPTSYbyIsahTfVvOHwBkgHaniuTTKuKTAAOoNddiaSoXParGUroIsL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RcriFHXd
{
public:
    string DUgFOibInSdjulS;
    string syotnaluJrnFfbQ;
    double LEUIC;
    int rdsaxu;
    double KIlxRrO;

    RcriFHXd();
    string cwGGSWvAWtg(double DHhyMXVJYGKXPcD, bool TKQIg, string rntosryvOlO, bool qdtKiu);
    string UZkvxUhQlQADp(int smWUCwEKsDXHWlXQ, double sXswkRAYC, string yeznH, bool CnFfeqKlxfTLL);
    int czSbLICz(string optfUqVxVnVinGWZ, string yZHTH, int hgMAfsiNZBuSVx, bool VAPcvvm);
protected:
    double YKKodDMu;
    int uHwyysMO;
    bool jgsbU;
    string whzwiTzlbasQRSk;

    string iHhXnVmLvsoibcFs(bool iqmCFFW, double gQtWYHrxjQndUnVj);
    void AshxEjSC(bool vkLBDCHwuWfEwM, bool yCojlhPjRlnjwT, string usoefHqtxnEyc, bool kGZDkijxeDdUdpX);
    bool QAUFdYheycxYNtMV(bool YSLwYu);
    double YtMnhMgIUmZXH(double fQsBKqsTEdVUcAO, double qHSraNgthyFRQS, string CFwves);
    bool LTxIWaYFSOW(bool ojorELf, bool hVkpwRcrvzRJja, double nqzYDQtVFdpFpYFx);
    void TTyswSRaBLHWOrI(string CPserZcQ, string xFmwYobZxJcc);
    bool KIVrIlfzCFG(bool CTlneYyhGxLbKPQu, string bQctQWVufqBp, double FRbkrdyVbLxN);
private:
    int EKZKDICVjTS;

    void hAPUfOqLHWDUsmH(double VTLVPSaBQwCROdSk, int AxOvsJdvxcxW, double nafxBKT);
    bool ZDRtBzx(double OzURvuVir, bool YUEYPaa, int piaMumaBwHVz, int qJXYeXEOlbQKBKfN, double rBueoxYFZWprsGu);
    bool akpusIUnkTDlrGTY();
    void PtaKDOQ(string AziktsLCLNVFeC);
    int jCZMKMzu(int tOBjduyIEGHw, double ybvwDimEcnygSv);
    int pKOCMwhvb(bool XttTqFDbNSQFD);
    int nATOJna(int RMcwYyamDvPchA, string muFqw, bool AiOqIWt, string JuEshyOggLPaDx);
};

string RcriFHXd::cwGGSWvAWtg(double DHhyMXVJYGKXPcD, bool TKQIg, string rntosryvOlO, bool qdtKiu)
{
    int enNMrJJFRd = 1324694899;
    int JkhWZFga = 1220284468;
    int egkFiVXdSHKlNtFm = -1450785486;
    int fqQiZdP = -1871755980;
    double vmmSCIwXxotLr = 183559.74617257057;
    bool uJawG = false;
    string VQCUqgRt = string("aAtjCDeenfHFBvbTjwzpcqnoDumCYtZBmMquWSqNnpMlnNPZwVFktpAjebgqDOeXlCqQDIxyvJoExpCQEwTIerKdUzMVaJgBKDjzuvSIyPsrJRYzHRpOozWVxzxBgNUHylLQDSxkBgcnEgnWNprVXXYXpwsdLVidq");

    for (int pixeDKtSELVwIsQ = 58068795; pixeDKtSELVwIsQ > 0; pixeDKtSELVwIsQ--) {
        egkFiVXdSHKlNtFm = fqQiZdP;
        VQCUqgRt = VQCUqgRt;
    }

    for (int JlZxrDAQZ = 1430199159; JlZxrDAQZ > 0; JlZxrDAQZ--) {
        JkhWZFga = fqQiZdP;
        JkhWZFga = enNMrJJFRd;
        egkFiVXdSHKlNtFm *= JkhWZFga;
        egkFiVXdSHKlNtFm *= enNMrJJFRd;
    }

    for (int nCQAbPShnU = 950197963; nCQAbPShnU > 0; nCQAbPShnU--) {
        rntosryvOlO = VQCUqgRt;
        uJawG = ! uJawG;
    }

    for (int sIVRIX = 489575194; sIVRIX > 0; sIVRIX--) {
        JkhWZFga /= fqQiZdP;
    }

    for (int hhEOLnESKORv = 1939958820; hhEOLnESKORv > 0; hhEOLnESKORv--) {
        enNMrJJFRd /= JkhWZFga;
        JkhWZFga *= egkFiVXdSHKlNtFm;
        egkFiVXdSHKlNtFm /= JkhWZFga;
        uJawG = ! uJawG;
    }

    for (int fGWLjtYGzQco = 1425045802; fGWLjtYGzQco > 0; fGWLjtYGzQco--) {
        continue;
    }

    return VQCUqgRt;
}

string RcriFHXd::UZkvxUhQlQADp(int smWUCwEKsDXHWlXQ, double sXswkRAYC, string yeznH, bool CnFfeqKlxfTLL)
{
    bool NlNvZJZyBBiVy = true;
    double RTpnoJUHwiv = 939537.2576119596;
    int GmWxwOLkyR = 1435698486;
    bool JyasxQA = true;
    double cXYNraDHFnbLXy = 223994.53555870728;
    bool uGIeeNAuIDlHRd = true;
    string byKDqDI = string("YquqpmkrFWYfiXptbgbUXsHDpebrarjmPKjeCDsxmPvIWUNHuKVEJEDMhnIXMZMrJxjFngLqDSbbaxvngahJgTBSxpWoHwCPi");
    bool vLyJckyxJrsmRoP = false;
    bool ijQVJldp = false;
    string gyNAwyCHuvZAgoCN = string("WAqTBaqcPaGzjfNOsaAONoleiUjojKFNmDsBbkSUtBDQcTookILUGdroHxYSvQshvzqBBBshCEonogqjbBPfhDkqVhbFybVuvbCXALRHQttXMadYgDbKmlyUiDMEEnEFvpZVHAXMsjivLqzWSkrkBndGqemfcmxKXZHxBaFUglkffkdGXWiNdTxKGcQtRnRsqcFUdNWFl");

    for (int ioiQqPEqiwNPiCYd = 888918179; ioiQqPEqiwNPiCYd > 0; ioiQqPEqiwNPiCYd--) {
        continue;
    }

    return gyNAwyCHuvZAgoCN;
}

int RcriFHXd::czSbLICz(string optfUqVxVnVinGWZ, string yZHTH, int hgMAfsiNZBuSVx, bool VAPcvvm)
{
    bool HckjAy = false;
    int GMclTvyq = -476338409;
    bool XhNhNtPWGq = true;

    return GMclTvyq;
}

string RcriFHXd::iHhXnVmLvsoibcFs(bool iqmCFFW, double gQtWYHrxjQndUnVj)
{
    string stmzBfdavDgkmAW = string("UKlQeadGIfUPZcfARNHhGSrUBhlgfKmsrOgAIpwQazoosbatyBkxzGQULbIcc");
    string XYdDv = string("uDbxDXaseOREwuYInQkkdvJZdJCJUXWBVvBHtWGkKpFLgFzmWwvqmbpJsSwcIfjZmKEPJXssQiujSAtWVnvHgbEBcYVbUfCnSMrDRCLKcNlTZnHZaMCFIafCgWThauyEuFoQQRjfttvbefYpZrkjSwqYkoTQurxQdOffCfyNRQABNqVmAYYomASkjKXQoIYTb");
    int lGXQrhOGKtBWpZY = 1716395464;
    string vdtuK = string("QhNXtDFhxTDnCiTVjakpKVNhJNdcJndtOvZsXYqueJkTBIsOrisXmUHGDqFTMrfGlKTnyeQpTuJqKtrlpQKjzUdSoOlsCFvtPCzniPcRalbGdCRuucJiyaOYKfqVYBNEZmoqfsBjItZlCCPxBOjezeKvpSBLIwQebyQYCIqdZpzPaOLSHRdoftqVpRAUUBsKcYB");
    double ejRDE = 429298.8789952856;
    string dxFRecJ = string("NTkqdhQswjCuTlYAKwIRwlvGWkQLkMNjrHmXefAJKVuqRjGHrEkkrupkLYDbgF");

    if (dxFRecJ < string("uDbxDXaseOREwuYInQkkdvJZdJCJUXWBVvBHtWGkKpFLgFzmWwvqmbpJsSwcIfjZmKEPJXssQiujSAtWVnvHgbEBcYVbUfCnSMrDRCLKcNlTZnHZaMCFIafCgWThauyEuFoQQRjfttvbefYpZrkjSwqYkoTQurxQdOffCfyNRQABNqVmAYYomASkjKXQoIYTb")) {
        for (int MYOudlRZDct = 856099537; MYOudlRZDct > 0; MYOudlRZDct--) {
            XYdDv += XYdDv;
        }
    }

    return dxFRecJ;
}

void RcriFHXd::AshxEjSC(bool vkLBDCHwuWfEwM, bool yCojlhPjRlnjwT, string usoefHqtxnEyc, bool kGZDkijxeDdUdpX)
{
    bool aGOVmrJURIbZsC = true;
    int eGExixOA = -954182337;

    for (int UlFeun = 1317334149; UlFeun > 0; UlFeun--) {
        vkLBDCHwuWfEwM = kGZDkijxeDdUdpX;
    }
}

bool RcriFHXd::QAUFdYheycxYNtMV(bool YSLwYu)
{
    int HDlQFtaUdDbjAyt = 99682443;
    bool SpdOFnhWANHN = false;
    double vEPkDEjKD = 908917.9635963363;
    double iiuTFKRHwoqcYNIs = -993885.0705203164;
    bool WJTVXcKiLp = false;
    string ckDUmEsWamsE = string("afuGnaFfMcErbsYxlMvZjAJnVSHtqIfQcdSqTznGecGskpISegvAalEYaACNVZeZvZdqRILuiutYmqxdlztraWcIOlLbMbsocccpWRynaGeVygpHbMAGCSmCSBldFQgqKmzGBPVqZt");
    int CKUbuGIZUYZAEwIB = -1294291483;

    if (vEPkDEjKD != 908917.9635963363) {
        for (int cFaOTMiVvdvrlGUK = 587358072; cFaOTMiVvdvrlGUK > 0; cFaOTMiVvdvrlGUK--) {
            iiuTFKRHwoqcYNIs = iiuTFKRHwoqcYNIs;
        }
    }

    if (iiuTFKRHwoqcYNIs > -993885.0705203164) {
        for (int KXyBXDuWTTX = 412149920; KXyBXDuWTTX > 0; KXyBXDuWTTX--) {
            vEPkDEjKD += iiuTFKRHwoqcYNIs;
            iiuTFKRHwoqcYNIs /= iiuTFKRHwoqcYNIs;
        }
    }

    for (int AzBwp = 346977697; AzBwp > 0; AzBwp--) {
        WJTVXcKiLp = WJTVXcKiLp;
        SpdOFnhWANHN = ! YSLwYu;
        SpdOFnhWANHN = ! SpdOFnhWANHN;
        iiuTFKRHwoqcYNIs += iiuTFKRHwoqcYNIs;
    }

    for (int lsqgkdZfwOrrWu = 1004281595; lsqgkdZfwOrrWu > 0; lsqgkdZfwOrrWu--) {
        CKUbuGIZUYZAEwIB -= HDlQFtaUdDbjAyt;
    }

    for (int jiXfZPkB = 1471201806; jiXfZPkB > 0; jiXfZPkB--) {
        continue;
    }

    for (int zGGAKJKM = 842271664; zGGAKJKM > 0; zGGAKJKM--) {
        WJTVXcKiLp = ! YSLwYu;
        iiuTFKRHwoqcYNIs -= vEPkDEjKD;
    }

    for (int XhDcm = 1857819011; XhDcm > 0; XhDcm--) {
        iiuTFKRHwoqcYNIs /= iiuTFKRHwoqcYNIs;
        iiuTFKRHwoqcYNIs = vEPkDEjKD;
    }

    return WJTVXcKiLp;
}

double RcriFHXd::YtMnhMgIUmZXH(double fQsBKqsTEdVUcAO, double qHSraNgthyFRQS, string CFwves)
{
    int AuXjRiJUGO = 410800927;
    bool MSbrDqKcQfAmB = false;
    bool ePVvnYgGCx = false;

    for (int NbsFXYCOFkVF = 664416790; NbsFXYCOFkVF > 0; NbsFXYCOFkVF--) {
        qHSraNgthyFRQS *= fQsBKqsTEdVUcAO;
    }

    if (fQsBKqsTEdVUcAO == 511249.03604057565) {
        for (int JKDtFeoucwtT = 1826571988; JKDtFeoucwtT > 0; JKDtFeoucwtT--) {
            fQsBKqsTEdVUcAO += fQsBKqsTEdVUcAO;
            qHSraNgthyFRQS *= qHSraNgthyFRQS;
        }
    }

    for (int zPyWDt = 867963586; zPyWDt > 0; zPyWDt--) {
        qHSraNgthyFRQS += fQsBKqsTEdVUcAO;
    }

    for (int XsfQlAWZ = 462086472; XsfQlAWZ > 0; XsfQlAWZ--) {
        continue;
    }

    if (qHSraNgthyFRQS == 511249.03604057565) {
        for (int aURLnpzAIjj = 1956609017; aURLnpzAIjj > 0; aURLnpzAIjj--) {
            qHSraNgthyFRQS += fQsBKqsTEdVUcAO;
            CFwves += CFwves;
            fQsBKqsTEdVUcAO /= qHSraNgthyFRQS;
            MSbrDqKcQfAmB = MSbrDqKcQfAmB;
            AuXjRiJUGO += AuXjRiJUGO;
            MSbrDqKcQfAmB = ! MSbrDqKcQfAmB;
            MSbrDqKcQfAmB = ! ePVvnYgGCx;
            qHSraNgthyFRQS += qHSraNgthyFRQS;
        }
    }

    return qHSraNgthyFRQS;
}

bool RcriFHXd::LTxIWaYFSOW(bool ojorELf, bool hVkpwRcrvzRJja, double nqzYDQtVFdpFpYFx)
{
    double sBthHA = -677237.6585526828;
    string CSiEYZ = string("KxQSVkFoaCbMNqqvzNmZpJvUUcbKMDwlwlriSjwyeHCLewycLNzoMIsXIhkyuvvynLrFpiUSLAzCCyAssQvPwhfvRdFgXmd");
    int tldCZTJwASJHQfo = -1692618013;
    bool rBytrsqZaLXPsCvz = true;
    string kLziXojtf = string("rAXhLxjFtWvfPFIohRdNHObsrOnsBmEfRzAasgSNFLjlPZItVucxeGkBprDofdvGKblymJVmjQACBLSqmdCveTaXN");
    int GuqqlBpzNEdD = -1563329458;

    for (int SsOQeFnUhwSyI = 1140143140; SsOQeFnUhwSyI > 0; SsOQeFnUhwSyI--) {
        rBytrsqZaLXPsCvz = ojorELf;
        CSiEYZ += kLziXojtf;
        rBytrsqZaLXPsCvz = rBytrsqZaLXPsCvz;
    }

    for (int gxMOilUDSUMH = 353854333; gxMOilUDSUMH > 0; gxMOilUDSUMH--) {
        kLziXojtf = CSiEYZ;
        hVkpwRcrvzRJja = ! rBytrsqZaLXPsCvz;
        ojorELf = ! hVkpwRcrvzRJja;
    }

    for (int gNPddLAGFrjVXmIc = 216229229; gNPddLAGFrjVXmIc > 0; gNPddLAGFrjVXmIc--) {
        ojorELf = ! hVkpwRcrvzRJja;
        GuqqlBpzNEdD -= GuqqlBpzNEdD;
    }

    for (int etLgVFleVnkFNHQq = 1280880378; etLgVFleVnkFNHQq > 0; etLgVFleVnkFNHQq--) {
        continue;
    }

    if (ojorELf == true) {
        for (int rqWoWBQBZGri = 245765715; rqWoWBQBZGri > 0; rqWoWBQBZGri--) {
            ojorELf = ! ojorELf;
            kLziXojtf = kLziXojtf;
        }
    }

    for (int YBQTBUesKx = 1282363242; YBQTBUesKx > 0; YBQTBUesKx--) {
        continue;
    }

    for (int GmWLbuaHDfAPxTR = 3768536; GmWLbuaHDfAPxTR > 0; GmWLbuaHDfAPxTR--) {
        continue;
    }

    return rBytrsqZaLXPsCvz;
}

void RcriFHXd::TTyswSRaBLHWOrI(string CPserZcQ, string xFmwYobZxJcc)
{
    double ZorSpWBT = 1014645.4017826099;
    bool dUdoPzcHUpON = true;
    double pbjQuY = 106460.80946855427;
    double rCbgklEXd = -973208.0876557064;
    double wghrDOUWTF = -66887.64990581849;
    int owlaXXQBuTbqi = -713884628;
    double XWawksKbPZNYuKm = -823026.1647230876;

    if (XWawksKbPZNYuKm < -823026.1647230876) {
        for (int ucmzZIDBGBWkCAjd = 584736034; ucmzZIDBGBWkCAjd > 0; ucmzZIDBGBWkCAjd--) {
            wghrDOUWTF *= pbjQuY;
            ZorSpWBT /= ZorSpWBT;
        }
    }
}

bool RcriFHXd::KIVrIlfzCFG(bool CTlneYyhGxLbKPQu, string bQctQWVufqBp, double FRbkrdyVbLxN)
{
    string vihNeuPqkztPr = string("OgrmfNoejWpogkuUOfsbUnZcdcZbwXeQwWtexSwMhVWNGFBuIgliqMxfXxlkigKVMHscmzkiHOmHQzupeTgcYYBJjfDRvZKOTwTbTeSCyjLzWrLCDFVZeZuzgjpdJWUFeshKgvQaZwlirsazotcsaiFeIugjlyroBKuP");

    return CTlneYyhGxLbKPQu;
}

void RcriFHXd::hAPUfOqLHWDUsmH(double VTLVPSaBQwCROdSk, int AxOvsJdvxcxW, double nafxBKT)
{
    int JVtZLVoX = -283592152;
    int WOrTwAgTEK = -2092727831;
    int dsrxAKngtgEd = -1848514911;

    for (int KgDwbGFHj = 587538458; KgDwbGFHj > 0; KgDwbGFHj--) {
        AxOvsJdvxcxW /= JVtZLVoX;
        AxOvsJdvxcxW *= dsrxAKngtgEd;
        dsrxAKngtgEd /= AxOvsJdvxcxW;
        VTLVPSaBQwCROdSk *= VTLVPSaBQwCROdSk;
        dsrxAKngtgEd /= WOrTwAgTEK;
    }
}

bool RcriFHXd::ZDRtBzx(double OzURvuVir, bool YUEYPaa, int piaMumaBwHVz, int qJXYeXEOlbQKBKfN, double rBueoxYFZWprsGu)
{
    int fECRgbcgJZbN = 426267113;
    bool YgtvX = true;
    string tTMtzpjvDWV = string("t");
    bool SRHltnfl = false;
    double pTGHzUurNjt = 828062.4021853387;

    for (int QFdTvTypxDII = 1571543032; QFdTvTypxDII > 0; QFdTvTypxDII--) {
        continue;
    }

    for (int egzZqNIfijzysqUi = 834747853; egzZqNIfijzysqUi > 0; egzZqNIfijzysqUi--) {
        qJXYeXEOlbQKBKfN /= fECRgbcgJZbN;
        pTGHzUurNjt -= OzURvuVir;
        fECRgbcgJZbN -= piaMumaBwHVz;
    }

    if (qJXYeXEOlbQKBKfN > 426267113) {
        for (int EpfRd = 197607283; EpfRd > 0; EpfRd--) {
            pTGHzUurNjt += pTGHzUurNjt;
            YUEYPaa = ! SRHltnfl;
            qJXYeXEOlbQKBKfN = piaMumaBwHVz;
            YUEYPaa = ! YgtvX;
            pTGHzUurNjt *= pTGHzUurNjt;
        }
    }

    if (YUEYPaa != true) {
        for (int MxfNiKWkrlnaWAFT = 2057681166; MxfNiKWkrlnaWAFT > 0; MxfNiKWkrlnaWAFT--) {
            pTGHzUurNjt = rBueoxYFZWprsGu;
            SRHltnfl = ! YUEYPaa;
            SRHltnfl = SRHltnfl;
            YUEYPaa = SRHltnfl;
            YUEYPaa = ! SRHltnfl;
        }
    }

    return SRHltnfl;
}

bool RcriFHXd::akpusIUnkTDlrGTY()
{
    string sdWyeNXX = string("IDsQOiYslTCLlXQOJTzVogCymMEiTvFWbzICnLGinxdvSJhIJAcgWzdLpsjkbjTTjkJJGHRajexNobcJpF");
    int anMNFlpRVw = -1702886297;
    int MpDObFKPu = -720470018;
    bool ioeISRSA = false;
    bool bgIEEEmcCPjFN = true;
    int VJcOvENdF = 536337322;

    for (int IACXKiLM = 1265073358; IACXKiLM > 0; IACXKiLM--) {
        ioeISRSA = bgIEEEmcCPjFN;
        sdWyeNXX = sdWyeNXX;
    }

    for (int VgXNbSEorQSCZJpv = 1959028753; VgXNbSEorQSCZJpv > 0; VgXNbSEorQSCZJpv--) {
        continue;
    }

    for (int RJOreSMKvJuwmzM = 421964399; RJOreSMKvJuwmzM > 0; RJOreSMKvJuwmzM--) {
        bgIEEEmcCPjFN = ! ioeISRSA;
        VJcOvENdF *= anMNFlpRVw;
        anMNFlpRVw += VJcOvENdF;
        anMNFlpRVw += anMNFlpRVw;
    }

    for (int bwNapyxG = 427135597; bwNapyxG > 0; bwNapyxG--) {
        MpDObFKPu = MpDObFKPu;
    }

    for (int OkuxMpVzKaPYaz = 1610609283; OkuxMpVzKaPYaz > 0; OkuxMpVzKaPYaz--) {
        ioeISRSA = ! bgIEEEmcCPjFN;
        anMNFlpRVw += VJcOvENdF;
        MpDObFKPu *= MpDObFKPu;
        anMNFlpRVw /= VJcOvENdF;
        MpDObFKPu *= VJcOvENdF;
        VJcOvENdF = VJcOvENdF;
    }

    if (VJcOvENdF != 536337322) {
        for (int sqfyAvHssQkTsN = 1474137280; sqfyAvHssQkTsN > 0; sqfyAvHssQkTsN--) {
            ioeISRSA = ioeISRSA;
            ioeISRSA = bgIEEEmcCPjFN;
        }
    }

    for (int PzoPd = 1492488392; PzoPd > 0; PzoPd--) {
        MpDObFKPu /= MpDObFKPu;
        MpDObFKPu -= anMNFlpRVw;
    }

    return bgIEEEmcCPjFN;
}

void RcriFHXd::PtaKDOQ(string AziktsLCLNVFeC)
{
    double yDMVR = -829481.4181385271;
    string YqcYVebXb = string("KfEXGDrxcrayEptJyRrSNDbBGURuTFTlbTlqpaMmMnxfiyiYFQEskZiqJzlfeujkKyQVOsEWVTCjGxjybCxldyEHULdENTSQYRkGIGwDYWZHGLDKpHNocYAlNDXgzkIOpGectMwbZYmJWFAYwGPPWPFnrzaocdWNqAOupRbcYLcKjhmjHZXrjsoRQM");

    if (AziktsLCLNVFeC > string("KfEXGDrxcrayEptJyRrSNDbBGURuTFTlbTlqpaMmMnxfiyiYFQEskZiqJzlfeujkKyQVOsEWVTCjGxjybCxldyEHULdENTSQYRkGIGwDYWZHGLDKpHNocYAlNDXgzkIOpGectMwbZYmJWFAYwGPPWPFnrzaocdWNqAOupRbcYLcKjhmjHZXrjsoRQM")) {
        for (int qNpIhB = 2073402876; qNpIhB > 0; qNpIhB--) {
            AziktsLCLNVFeC += AziktsLCLNVFeC;
            YqcYVebXb = YqcYVebXb;
            yDMVR *= yDMVR;
            YqcYVebXb = YqcYVebXb;
        }
    }

    if (yDMVR < -829481.4181385271) {
        for (int OPLrgrmbvJU = 57100657; OPLrgrmbvJU > 0; OPLrgrmbvJU--) {
            yDMVR /= yDMVR;
            AziktsLCLNVFeC = AziktsLCLNVFeC;
            YqcYVebXb = AziktsLCLNVFeC;
            yDMVR /= yDMVR;
        }
    }
}

int RcriFHXd::jCZMKMzu(int tOBjduyIEGHw, double ybvwDimEcnygSv)
{
    double PhxxvHJDu = 371966.8088621326;
    bool mnxuyCBvFruFTOH = false;
    double NOvpBOVbPkc = -985766.0683261474;
    double NDSvozp = 850086.9129791729;
    int UHwoxh = -530860114;
    bool AgqiQfeojxfF = true;
    int BtdvZRsU = 33506686;

    for (int xNDiLnLgjZULys = 189759664; xNDiLnLgjZULys > 0; xNDiLnLgjZULys--) {
        NOvpBOVbPkc += PhxxvHJDu;
    }

    if (AgqiQfeojxfF != false) {
        for (int wwRnoDb = 1639569294; wwRnoDb > 0; wwRnoDb--) {
            NDSvozp -= ybvwDimEcnygSv;
            tOBjduyIEGHw *= BtdvZRsU;
            PhxxvHJDu *= PhxxvHJDu;
        }
    }

    return BtdvZRsU;
}

int RcriFHXd::pKOCMwhvb(bool XttTqFDbNSQFD)
{
    int qOtoLUlnNDbPH = 2110027935;
    string tqzgAjCLnBpWWTy = string("JJn");
    double yNzNOOvHR = 286769.14190339315;
    bool OMDezArPPvBsutU = false;
    string WYNIthQPsYChr = string("IKegYvauwuHFNtjIRESQHPcKiNYcXPpSQiigw");
    double acqQqveyxbSbE = 583952.4550368469;
    int ehzDzDaLFO = 137577137;
    double BdvoYkuqInzzvWQu = 966363.4963896769;
    bool XHQHPkfkYifIi = true;
    bool TwowX = false;

    for (int FuIcBnCw = 1406963382; FuIcBnCw > 0; FuIcBnCw--) {
        continue;
    }

    return ehzDzDaLFO;
}

int RcriFHXd::nATOJna(int RMcwYyamDvPchA, string muFqw, bool AiOqIWt, string JuEshyOggLPaDx)
{
    bool HMcAQMdaRvAZ = false;
    int mnuTWTzLNWShnp = 294216568;
    bool wzZoGNlghTsC = false;

    if (mnuTWTzLNWShnp > 323946722) {
        for (int BHfhMpS = 851977027; BHfhMpS > 0; BHfhMpS--) {
            HMcAQMdaRvAZ = ! HMcAQMdaRvAZ;
            muFqw += JuEshyOggLPaDx;
            JuEshyOggLPaDx += muFqw;
        }
    }

    return mnuTWTzLNWShnp;
}

RcriFHXd::RcriFHXd()
{
    this->cwGGSWvAWtg(-768318.8613825723, false, string("QrjTJnarhmWbAYvthjiy"), true);
    this->UZkvxUhQlQADp(801246918, 251121.19444087948, string("crvFYmQaUkHYPaODRcBmUPbKewmeUkcMYYxaJYFyWOztoCQdohVIckKEdtOVyxOwszNhqfiNcDpmOinOkVcjTbeyyNrmgxdnJBQyvoHwbnJqDMlCOpmrQYyNyiFLcdPkRcXegdxlPJeaAOFEPElOvpqYbGdvRAQKxVxVKiDmIjvbxJFgTnUeadQSngvWXnI"), false);
    this->czSbLICz(string("gRSIXUYEeLqxOgnHrvsTsAJOJpCDFqjedVQPIZzXmBdNQVTbpeXjSVJGwteOYmlbdYsXi"), string("KtWybRLrBS"), -1750934632, false);
    this->iHhXnVmLvsoibcFs(false, -32424.14169392353);
    this->AshxEjSC(false, false, string("joDIeSQQMNqCdiTCfefVkpdPSbBCRfRUCXlmeUQzgnAcDVerpkPnCgrGYDyxkRdrjLbgmQ"), true);
    this->QAUFdYheycxYNtMV(true);
    this->YtMnhMgIUmZXH(511249.03604057565, 50029.31522104169, string("oCfTueHPxsaUvxPbzlgEeXlFoEkxLsvQPmIPYXYaLTOCjVSBjOhcldYcttGQedYcBTosJmVgHLxJxaizj"));
    this->LTxIWaYFSOW(false, false, 694332.7155972611);
    this->TTyswSRaBLHWOrI(string("stOJasyFqDwFoCbgcmTDIUHEUeawDcRqvNROREjbIRCYxgcdwpSOAOoIKKAdCyyUkUnxuiRnosZiojwPhyviAjOxYzjgERpKZEZQfuZuHOxycgLgtAkUzMRQeUtZlAPCBUKjgQahgLrcfGvnIHmtfvgPfQPljtHboACCHBAYl"), string("zOPLDpIXhzHcxClokMkDoQcritPejnlqzCxQVhqxxyJEwMSHNFrdZkNbyOywInHkvEoOyPiOJUxLNo"));
    this->KIVrIlfzCFG(true, string("tBSgIiRtXYebdPqWeiSkchIBubtFvyQabFkULKmvkYCFvMtfQbiVOheyaMVCQBmnSJUxJqUxrwMOGciylrljzjQNwMIWwjMHJJzXjcpAmBWrhMWZHXSLpGtaNGArJwxEdJTrfugaMnfFq"), 154171.37697423244);
    this->hAPUfOqLHWDUsmH(-655419.827172012, 2121217359, -618868.2105129712);
    this->ZDRtBzx(802524.047485546, true, -126331716, -1666980022, 926285.3119453054);
    this->akpusIUnkTDlrGTY();
    this->PtaKDOQ(string("InvuvMkTWQgPQMDaMqKexsaaAPsIRmNrYeYPqTaMMoWMtFXIMIrhjgTuiwhqCepwODWqSqcwBGLhWAMvdBtIzZpwZZwhXdDchBSsu"));
    this->jCZMKMzu(-300454649, 316851.1500019863);
    this->pKOCMwhvb(true);
    this->nATOJna(323946722, string("cdduldYrbOpgFFATLKmhGYCAPnqJtKHpdyaBp"), true, string("IcENaJQecUFcIGaIxvtfZZalxchVIuKVIegyVcZyheQKIDDQxOxrrSTIptfUaNCPskSmRlKDWPCMLhqWNQbETYjDMdRjxgKaXXtdQsDZcLoGQWramiZTDKAFKgNuOOeXixtNrIQuzedRKmQPpefRdGLSZmJVOlizesPsSz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LqBBeveIidMVGxXm
{
public:
    int fhURfe;
    int pbYjACUJdHPr;
    int FHioELr;
    int RVQtx;
    bool NHstqDoBCZqO;

    LqBBeveIidMVGxXm();
    bool olBEVBKtV(string scBZz);
    void eHlzyJLmguRV(double ovamaWzRj, bool DKhPavZaMKVtZ, bool TrmGtfLBLo, int ZTSsj);
protected:
    string eSQydJ;
    string VnvQeHzudk;
    double jsOUOtmgcLP;
    bool kszSczXvQrM;

    double mwrno(int nSCMKeXqfb);
private:
    string oWmoDmcmf;
    bool OZpbPRW;
    double yduLnSmGyaJb;
    int FwVCbyWB;
    bool bLCpmdiT;
    double aEZSsd;

    string CxtOsoRLnJm(string GfGcnDXktzl, double DhzmvHfP, int ObSUIxeTuxVBI, string PTbIK);
    void rwoOQpLhacJ(int oNKDlBT);
    void dhgKlHpD();
    void lbhgzgwKJQPvuUMz(int KRYUyOTt, bool hqSLBJncLHx, string HTTITwfiVGpXXWhq, double RkPwqU, string HMQvdJdFxKZlrmC);
};

bool LqBBeveIidMVGxXm::olBEVBKtV(string scBZz)
{
    double LvNqo = 334484.680395668;
    int EnIzWIsLOh = -844663118;
    bool AmGRbuMMCBgqT = false;
    string yinkDFxRoAQgB = string("HNVsWFxmlhEtihBEGPfqaQFUogmNJickBEjrTPmZKfKkhovlsZuVOdEhaollREOFKRDTncxPrDztBWnbzeTfxvULxcUPoNWhVqvFQNDyYBWAXPhLpjorCyzGDhExfxfLUTVXlIcFuDEmvvAdqufrKVAsVxIIvXzpSREWKjqhDAqoUwqdRAwmqdqOprhIuNMkfcfGZWqXPfNFgMCjprryMZvwGftFevypWcKDqXjdi");
    bool GBEdaXufJSqwk = false;
    bool eVmFBF = false;
    string EctRWgXB = string("TclYPdvQoMsvRtIJGlFWakKCovNgVnyLoNlQymVdqJVhjTSpNYtdTALTpsLLzoaCdpuhvYRsPLYNXfpPRBItRHcXdebjhPAPmGMGmToQyvbuBmLQSMWmEA");
    bool lFPluNhAVBpW = true;
    string pRAqDrlnSSXwrH = string("gUppKofAsrZUNWnxpuozMKuRRcHFEmbVrUigxiQAZrhLpaiKgQTyHFvrDffPtzDvVymxktrDZnCgbiTWSVYCSzOXZUOARygIgewkUnrwFZnuhflaPVFSjIKTHXpWiGNHfXfDWsbOniVbbhNMlOJeupPcDzJOBLdixnlZeIUjevvtcbQBmgYpVUohKIRWQGXfseNgFhrqROjsoLbOZIBtYnXjPsNngESFWxUTjfzxRlHiZhmG");
    int BLCQrwfGg = -491172813;

    for (int KCXpDJxNDXS = 815022439; KCXpDJxNDXS > 0; KCXpDJxNDXS--) {
        lFPluNhAVBpW = GBEdaXufJSqwk;
    }

    if (AmGRbuMMCBgqT != false) {
        for (int erbsbflYKzw = 2053920116; erbsbflYKzw > 0; erbsbflYKzw--) {
            lFPluNhAVBpW = ! lFPluNhAVBpW;
            yinkDFxRoAQgB = yinkDFxRoAQgB;
        }
    }

    return lFPluNhAVBpW;
}

void LqBBeveIidMVGxXm::eHlzyJLmguRV(double ovamaWzRj, bool DKhPavZaMKVtZ, bool TrmGtfLBLo, int ZTSsj)
{
    int wIBFEygMC = 312750929;
    int xhKWDyoleO = 200321127;
    string MsiNzyOHWPVdtC = string("mXTqgSvOvGwJEQQpSSVJILXPisbmMpQOZXqDccOdXMnVpiFqcro");
    bool zCfpqt = false;
    bool ljIUxXcHcy = true;
    string jMeJNErMB = string("ScAWcflckgariSnfOBwLdNGFfzGZGzyraLCZXUiNQYNSlLAnZVydAzjjRliHPiMbDlpqlATRbwrxRvkCAOvFqgWOJajSavrnGhnWNhofUOJJnfZpJrTcSlEPZgNGmVAkTxcrRpEVzmrHH");

    for (int JOBgyvggFt = 1395033836; JOBgyvggFt > 0; JOBgyvggFt--) {
        ljIUxXcHcy = ! TrmGtfLBLo;
    }

    for (int TDQPTzwLrnjfUzr = 458729504; TDQPTzwLrnjfUzr > 0; TDQPTzwLrnjfUzr--) {
        continue;
    }

    for (int gevZtdddDp = 1402835774; gevZtdddDp > 0; gevZtdddDp--) {
        DKhPavZaMKVtZ = ljIUxXcHcy;
        DKhPavZaMKVtZ = ! TrmGtfLBLo;
        DKhPavZaMKVtZ = TrmGtfLBLo;
        xhKWDyoleO -= wIBFEygMC;
    }

    for (int rnhwSGpcxcR = 1394806844; rnhwSGpcxcR > 0; rnhwSGpcxcR--) {
        ljIUxXcHcy = ! TrmGtfLBLo;
    }
}

double LqBBeveIidMVGxXm::mwrno(int nSCMKeXqfb)
{
    double aXVYfLEZvoouEIpA = -943139.5262651748;

    for (int LlsMQy = 1183083342; LlsMQy > 0; LlsMQy--) {
        nSCMKeXqfb -= nSCMKeXqfb;
        aXVYfLEZvoouEIpA /= aXVYfLEZvoouEIpA;
        nSCMKeXqfb -= nSCMKeXqfb;
        nSCMKeXqfb += nSCMKeXqfb;
    }

    if (nSCMKeXqfb >= -855774867) {
        for (int vFkYRMcz = 410897322; vFkYRMcz > 0; vFkYRMcz--) {
            nSCMKeXqfb *= nSCMKeXqfb;
            nSCMKeXqfb *= nSCMKeXqfb;
            aXVYfLEZvoouEIpA *= aXVYfLEZvoouEIpA;
            nSCMKeXqfb *= nSCMKeXqfb;
            nSCMKeXqfb = nSCMKeXqfb;
        }
    }

    return aXVYfLEZvoouEIpA;
}

string LqBBeveIidMVGxXm::CxtOsoRLnJm(string GfGcnDXktzl, double DhzmvHfP, int ObSUIxeTuxVBI, string PTbIK)
{
    string XaOkgL = string("PlnFCWLKkbeAevbOKHKiZQoMqKOmIAyPlkHTWXBbpkqBpQXnRJHLHcQhh");
    string dZxmKkbct = string("gOXbOETonytnpqplZQkOxKyRiPAjBEtsxapjZRcuEDYxNrDmenqIpiTZvLwHeTznbKvJANGRWgrnLpYAmjtLcuZTJTECFOVVnIRYkEsfETtvDYKBwMNqwVLUhfOOOHcttPqOMnsjNXrDRXBnSCDGrAokMXjVFRsrLRrfkIxUrvlTQSelzoWSHgvJS");
    int FDbLCQHRsBFD = -2001240611;
    string sQeZkjcakGYwT = string("vSEsfRxqoQzQIbJkEfzCIRoeTDZeCgWSOavINWYvSWZKbzZLqljuDXZGiULjvJemRdeKcBuRiizuRagYzVDUmDQNZsgxqFbhEnCXjQdSbWmjJmjublQYJKACmnaBuPbwdIWuew");
    int dRzJqBIUcuwIP = 1912400925;
    string zNKWBWCyWrVE = string("OEhSxsVcvXnOXpYOpQAdEiWBfPuHWQmPIDirOWayHOTGdNYTQRiZvZOJwOStBdzFuBrHjSLzhbHSROSVSrCjuhacRjbburnJLbylvUvffTrFcKOpxQtRVuhGywghVBXMQQHOEogXsmXxhNFEPYuKTLPFQdaTrBHZGUJXXalVaGKlaJz");

    for (int SpwKhrgf = 199654804; SpwKhrgf > 0; SpwKhrgf--) {
        continue;
    }

    for (int MZnEVytpij = 1837646478; MZnEVytpij > 0; MZnEVytpij--) {
        FDbLCQHRsBFD -= ObSUIxeTuxVBI;
        PTbIK = XaOkgL;
    }

    return zNKWBWCyWrVE;
}

void LqBBeveIidMVGxXm::rwoOQpLhacJ(int oNKDlBT)
{
    int rDaNngUOAckbVOni = 927031807;
    string qFeSsnCSRFjIOZ = string("ugIPlMFQssyaslAUXirZfvsdxUrLlBLPuPcXpfiXvvZSmpY");
    string adVlsaxNQIVNzyUb = string("TGckgIFprVbILxRUkpvnEepNrZDUimRfxVLjPNQAMxRqWdkmtYekRQuGnrljIXoDJLcCVnQyvcERZNTSqtgvEvc");

    for (int gEkcesLjjEq = 226065272; gEkcesLjjEq > 0; gEkcesLjjEq--) {
        qFeSsnCSRFjIOZ = qFeSsnCSRFjIOZ;
        rDaNngUOAckbVOni += rDaNngUOAckbVOni;
        adVlsaxNQIVNzyUb = adVlsaxNQIVNzyUb;
    }

    for (int MSemnCtexpCmT = 1792133835; MSemnCtexpCmT > 0; MSemnCtexpCmT--) {
        qFeSsnCSRFjIOZ += qFeSsnCSRFjIOZ;
        rDaNngUOAckbVOni /= rDaNngUOAckbVOni;
        oNKDlBT = rDaNngUOAckbVOni;
        oNKDlBT /= rDaNngUOAckbVOni;
    }
}

void LqBBeveIidMVGxXm::dhgKlHpD()
{
    double NqYjCOMANV = 136836.13786637672;
    int bWpgdhhSARoY = -2127737594;
    bool ZwLoLhMMpDBaBin = false;

    if (NqYjCOMANV < 136836.13786637672) {
        for (int iWskAbe = 356137073; iWskAbe > 0; iWskAbe--) {
            continue;
        }
    }

    for (int sMLELESEDRKytk = 1652796753; sMLELESEDRKytk > 0; sMLELESEDRKytk--) {
        bWpgdhhSARoY += bWpgdhhSARoY;
        bWpgdhhSARoY = bWpgdhhSARoY;
    }

    if (NqYjCOMANV == 136836.13786637672) {
        for (int LjxTrzHtJiHTy = 1077752287; LjxTrzHtJiHTy > 0; LjxTrzHtJiHTy--) {
            NqYjCOMANV -= NqYjCOMANV;
        }
    }

    if (ZwLoLhMMpDBaBin != false) {
        for (int spexNYuTyVLEyhP = 592759593; spexNYuTyVLEyhP > 0; spexNYuTyVLEyhP--) {
            NqYjCOMANV += NqYjCOMANV;
        }
    }
}

void LqBBeveIidMVGxXm::lbhgzgwKJQPvuUMz(int KRYUyOTt, bool hqSLBJncLHx, string HTTITwfiVGpXXWhq, double RkPwqU, string HMQvdJdFxKZlrmC)
{
    int WOMJWoshbdktfYP = -474872320;
    int jGjmKtLxi = 141557965;
    double wvPpzDXm = -373891.58950440283;
    string pAsMN = string("ORgpUwpBsFnFicQtzKvBzzbSVmKJzEuaXrbJiVslLBTzgSWmkhzTpmavFZTxHSHJpvtRfwQYuknaCswJqROEnnioQRpnkLJxOmJHUKcTWmxFnQlkklcMRclzUhcRorwEmXDJhsBurgjZljFLnTxlEuncNAVSQPLAkqmYAQnbfEDRpLcjPpAVNfMBeDWyfimFiSyGsYKORDUqRnFCjEwjILFoDzpxrxaN");
}

LqBBeveIidMVGxXm::LqBBeveIidMVGxXm()
{
    this->olBEVBKtV(string("tnittINaLpHUeVeQhmUdfnEKyfGbLrPhwOUDPLcZCEmQDVuICHlxXMwzrxylnHparUXAjSEQROcmEaiSxCswSyaAFpVZEDIiuzlDqqDvaJTzSxihoXDdHjFiXcYEbDvwRvpAWZAhCwVPPPRymkXwKGRpFKfPTYRVetpIDUOMMDnAimjOHBgpTPifPAanvjwAsATOA"));
    this->eHlzyJLmguRV(519641.5823310237, true, false, -1851195781);
    this->mwrno(-855774867);
    this->CxtOsoRLnJm(string("FqliusFTTNkTxiDlWCfnaDpxTklbhJaIlgOBdHKMkJZEnxgRrWloybeNdKAdcqoxriwFRCcUMpLKwpdTGwWZwlcpGuRbdhpHtYvsmJxYaVfzVZKUGQdGeQWOlhQqBbaqbkTyTTdqAnkyuzNYDzaWqaakJHtFhEuKOAmNUvbErlfyheRWfnAAGGI"), -890241.706680246, -861960933, string("fuGTedqWqVVADGqClKWrSLaAWAFcVgAqXXHIgpljLJeAmNKErPPApVGutBgKUuDKJSMgvKOxQlEmRpjwcDRcyfCDBQfECnRMXPmYXlBjjncAjKltNAqNTEuLTeEcjSrdqGEoutXmzA"));
    this->rwoOQpLhacJ(2016621042);
    this->dhgKlHpD();
    this->lbhgzgwKJQPvuUMz(-150969989, true, string("ssPm"), 222702.06335002917, string("HmbiQFtMeNZdigpiNw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BjLWZVwCQpfpmkXj
{
public:
    bool UjNPsm;
    bool POgTghXWn;
    int yHpImiGu;
    string tkxWwO;
    bool zLCNsmxJdRkhqqVN;

    BjLWZVwCQpfpmkXj();
    bool QtPlnHoSTjLBvohP(string hXfFTSDNthu, int LlJeRzUqfCKrUN, string pRnhVQopgm);
    void XfMnFIgXMi(double RYeEahQWQ, int TLHCUy, double ZZtQBYKKQKIGcLCJ, int yWgqWRjMlXRfAow, int VXdhszUSDpM);
protected:
    string LCajpA;
    double tmvBzGyfUMqX;
    double pElnaRcOO;
    string nzEhT;
    string RekAZmsXlZvby;
    int HiOPE;

    bool YCVuu(int mkRGvPSdehRXI);
    string iunTvYZpc();
    string urQYvPyFcM(string WcwAZmka);
private:
    string wMrGnYFOMvsk;
    int DmlqasvjCx;
    int OZcUafeFJmTY;
    bool asSlFEZQ;
    bool UuxMnTK;
    int ZdtaZalUoMWZZQcM;

    bool lpFwOmtBnQTP();
};

bool BjLWZVwCQpfpmkXj::QtPlnHoSTjLBvohP(string hXfFTSDNthu, int LlJeRzUqfCKrUN, string pRnhVQopgm)
{
    double IncOdrNNRB = 855967.175986704;

    for (int AtxfpjJXCYqlcdHK = 2073395104; AtxfpjJXCYqlcdHK > 0; AtxfpjJXCYqlcdHK--) {
        hXfFTSDNthu += hXfFTSDNthu;
        LlJeRzUqfCKrUN -= LlJeRzUqfCKrUN;
        hXfFTSDNthu = hXfFTSDNthu;
        pRnhVQopgm = hXfFTSDNthu;
        pRnhVQopgm = hXfFTSDNthu;
        pRnhVQopgm = hXfFTSDNthu;
    }

    for (int kTgCoyNhIlW = 172489480; kTgCoyNhIlW > 0; kTgCoyNhIlW--) {
        hXfFTSDNthu += pRnhVQopgm;
        pRnhVQopgm = pRnhVQopgm;
    }

    for (int esZZkkCuyYUV = 1371161373; esZZkkCuyYUV > 0; esZZkkCuyYUV--) {
        continue;
    }

    if (IncOdrNNRB < 855967.175986704) {
        for (int ytTPqXMri = 1039529336; ytTPqXMri > 0; ytTPqXMri--) {
            continue;
        }
    }

    return false;
}

void BjLWZVwCQpfpmkXj::XfMnFIgXMi(double RYeEahQWQ, int TLHCUy, double ZZtQBYKKQKIGcLCJ, int yWgqWRjMlXRfAow, int VXdhszUSDpM)
{
    bool UdwCtERJE = false;
    int zXWpaEbCTckmWvwc = 1705686136;
    int UCplxJ = 749811754;
    double yYimzQRNMIeJBb = -146970.00009504543;

    if (RYeEahQWQ < 959573.6361740151) {
        for (int sphXjfUPoBgyThgJ = 938390428; sphXjfUPoBgyThgJ > 0; sphXjfUPoBgyThgJ--) {
            VXdhszUSDpM /= UCplxJ;
            UCplxJ -= VXdhszUSDpM;
            UCplxJ /= TLHCUy;
        }
    }
}

bool BjLWZVwCQpfpmkXj::YCVuu(int mkRGvPSdehRXI)
{
    double VVmLdGNTVWk = -1043839.7914855423;
    bool WXvyvQUlHo = true;
    bool pwaJYm = true;
    double uqigFlIb = -271285.28055826895;
    int IfFlQJeWlngRe = -11338495;
    bool VhZkSDEmQdoOZIEf = true;

    return VhZkSDEmQdoOZIEf;
}

string BjLWZVwCQpfpmkXj::iunTvYZpc()
{
    double GFyrXlkB = -365377.1478802604;
    double gEvTdFXsqoHwYkqp = 114759.84394747343;
    double HCApsuE = -244295.91739874255;
    double uLvELFtmk = -320080.5086881443;

    if (GFyrXlkB > -365377.1478802604) {
        for (int UhEjLUaiswQax = 879118359; UhEjLUaiswQax > 0; UhEjLUaiswQax--) {
            HCApsuE /= GFyrXlkB;
            HCApsuE -= GFyrXlkB;
            uLvELFtmk = gEvTdFXsqoHwYkqp;
            gEvTdFXsqoHwYkqp = HCApsuE;
            GFyrXlkB += HCApsuE;
            HCApsuE += GFyrXlkB;
            uLvELFtmk /= GFyrXlkB;
            GFyrXlkB *= gEvTdFXsqoHwYkqp;
            HCApsuE *= gEvTdFXsqoHwYkqp;
        }
    }

    if (HCApsuE == -365377.1478802604) {
        for (int ELEoYKBiYMrLqKNc = 804208917; ELEoYKBiYMrLqKNc > 0; ELEoYKBiYMrLqKNc--) {
            gEvTdFXsqoHwYkqp += GFyrXlkB;
            HCApsuE += GFyrXlkB;
            GFyrXlkB *= HCApsuE;
            GFyrXlkB = uLvELFtmk;
            HCApsuE -= gEvTdFXsqoHwYkqp;
        }
    }

    if (gEvTdFXsqoHwYkqp >= -244295.91739874255) {
        for (int BIHMd = 121399336; BIHMd > 0; BIHMd--) {
            GFyrXlkB += GFyrXlkB;
            gEvTdFXsqoHwYkqp -= HCApsuE;
        }
    }

    return string("RYlUTAdgTSxfbZuTIIvPGWcNWgabPpLxyBvBXevpvnTYTmeodlEARUwcVBWOzKqIMfyUrJFMJccHQaXPdhlvmLGthVheKcgVUfjCjSWnHWgEdIIXnwJHpEGdjrtuXGwsoHefZspurSNiVYXibhOEhUo");
}

string BjLWZVwCQpfpmkXj::urQYvPyFcM(string WcwAZmka)
{
    bool OeNRwdJTTZ = false;
    bool AXgKs = true;
    double quPjLDjUPZMTmCo = 801291.7467089634;
    string tZhYRhSIYXwaO = string("dUqkfKGUziYGGtczYtlFLeRSLGOTIQvwjmzDwoIPPhySKRXyXoEPEjkFMBXMwbaZYguCHVIOcWXFsLrnOzvfijZeyzlLzUIHpEFBTTUuGWMLFsaVrpRbDoXqTIHkOcRFXXRmjTbbREawZFTvIFswIcqpVCBXjZVJOKEIsJPkmW");
    string lRGIrNPTIBfx = string("bhqMMKYWQqCP");
    string omGcAAjIQhJ = string("vFuHtnxlBMuZwUldcqYKVThBHDIIDMJFVIeZciVHbWfhtdZBzNVZDuQtdvKEanDsErJgFVpvlkaDdwSbOFG");
    double dXBYGmjzzQgvq = -596794.640705724;
    int DQphmcriWiiyxv = 1756626062;
    bool UIWXKYOxTLJmZ = true;
    double JWGZv = -256658.58689201385;

    return omGcAAjIQhJ;
}

bool BjLWZVwCQpfpmkXj::lpFwOmtBnQTP()
{
    bool ycMdjIxrYFQaNFmr = false;
    bool IQFEzg = true;
    double qixHclUlDi = -149205.10551436996;

    for (int JqxAsZwcOJmwW = 1391216663; JqxAsZwcOJmwW > 0; JqxAsZwcOJmwW--) {
        qixHclUlDi -= qixHclUlDi;
    }

    return IQFEzg;
}

BjLWZVwCQpfpmkXj::BjLWZVwCQpfpmkXj()
{
    this->QtPlnHoSTjLBvohP(string("mycPxPmYxqcRf"), 2008502255, string("blcUUnyWFGcePjGArWKHGTQdmYAeJTlsjvflpDYrNfmostADcxGunLJmsstykoVrvmhruwPQZinrNilVbDLrdKEkhMKRNHmvQiFVYOLBOlgdXWRbaKJaoElXuDmeCUdKzLkyAlCOYWIHWBLQZYFeRUkTFhFTMvxBohtUHmGwldbfeWtvIkRJuOraa"));
    this->XfMnFIgXMi(959573.6361740151, 1030231483, 678673.2569584923, 611427590, 1543938230);
    this->YCVuu(1722695442);
    this->iunTvYZpc();
    this->urQYvPyFcM(string("XOmGsDrmlbUHHESsVtlZJGkmMNzEHPJqcxiOmtmtMTkuaRVACcIQxxSWWLziHQoAJVRwCGjEMBVIcxndqSIRHjbgMQdGdvwyVMOigNiYWANDGYhTQXoAixDUyOkimHrxAEYwmknSTCFRJBgrzsKHcwfoJMjPqIjgUUMWTfWKDbCjVRkqHbKvkdHwYCKuptMTaGtCwgNDkEidJBEjhfHgXjQOgOj"));
    this->lpFwOmtBnQTP();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iQHvDuMNm
{
public:
    string ZSBXPZbIAclbFdli;
    bool MGAYm;
    int ieWSGsEPE;
    double wlgPXZHJCb;
    string oDZGGRrhaZ;
    double bcBEfI;

    iQHvDuMNm();
    int hyxedrSXdJYOQ(double YjfXVAN);
protected:
    int QWrdAFwtYH;
    double kSUuPiZ;
    double NZUBIAlGBonADLAq;

    bool tFQEcxR(int MfycT);
    void vpznKfecNbaAtT(bool iyOkBQuH);
    double CcECJou(bool qAeUX, double enUvSNWRHJXcB, bool qptunYMdYfUBlF);
    int nPyzaRF(string rUPrAxOzeSXa, string juHXnIRjrQfp, bool vRkoyVnB, double VCABorJkN, double UcAcmDiEhZSk);
    bool NlfwF(double LETHAbVCqbKZAr);
private:
    bool NZAgznKPhRvmsW;
    int EfEIDWv;

};

int iQHvDuMNm::hyxedrSXdJYOQ(double YjfXVAN)
{
    double HzZmvmIoJuj = 153629.83812592126;
    string chtVPFnW = string("feOWQyGPsoJtvPobRMCASkajNUXdViYYgOwrbfbRXpPkpHtqtKlBvLSmfHooUvsZyselsRQdlJspvoXFRuljwKguxegtByMouPchnHwAIuhfpZlHsBvzKoweoATwHAnvRkpFfspVhHqLdwFdkQskQqbBYScDkZZOyVGeL");
    string yiTtczxUUgrHQYa = string("PiXPSaZSzDIqiYyyeNJknzSqqWBwoUQOEuXXNlFCJIwKlfGDhDwtdScgqgY");
    bool MnbgDiEtAULOYR = false;
    int XDBWFIuBTcdRI = -998475869;
    bool ryruETvw = true;
    string BDfYd = string("VBmyStTghZjBgPNMQamNVDSjJuPRxBXjuhSSGGuEyfjUDYBAwxJEHDvwGOdoLKCVk");
    int DaYiXNvwDMiJhz = -52089514;
    bool nqAEaTuZ = true;
    int gfHCMwRiitpylM = -220346034;

    if (HzZmvmIoJuj > 767915.3606467614) {
        for (int iyHZzccEgDj = 928767227; iyHZzccEgDj > 0; iyHZzccEgDj--) {
            BDfYd = yiTtczxUUgrHQYa;
            MnbgDiEtAULOYR = ! MnbgDiEtAULOYR;
        }
    }

    for (int EJXMksiWlYekV = 2126283981; EJXMksiWlYekV > 0; EJXMksiWlYekV--) {
        DaYiXNvwDMiJhz = XDBWFIuBTcdRI;
        DaYiXNvwDMiJhz -= gfHCMwRiitpylM;
        BDfYd += BDfYd;
    }

    for (int UIwiUqoVmkD = 1205767998; UIwiUqoVmkD > 0; UIwiUqoVmkD--) {
        HzZmvmIoJuj *= HzZmvmIoJuj;
    }

    for (int pbMKP = 1889122161; pbMKP > 0; pbMKP--) {
        DaYiXNvwDMiJhz *= XDBWFIuBTcdRI;
        MnbgDiEtAULOYR = MnbgDiEtAULOYR;
    }

    for (int iSiYqxBxAkyLdFd = 1744277273; iSiYqxBxAkyLdFd > 0; iSiYqxBxAkyLdFd--) {
        chtVPFnW += yiTtczxUUgrHQYa;
        BDfYd += chtVPFnW;
        nqAEaTuZ = ! MnbgDiEtAULOYR;
    }

    return gfHCMwRiitpylM;
}

bool iQHvDuMNm::tFQEcxR(int MfycT)
{
    double ufOJalH = 414102.1420694403;
    double nAdzIVyNkIZnzO = 981309.7900740233;
    string uExTAzV = string("bDPFQLqQWRSlqCTqeaKozZIHjABhGvFakLfxVV");
    int fHlIiy = 77758627;
    string EKnPzrCC = string("liyPYxOZAlaEIvrTctfbIXDhgifLqLMjiWpujJbxdWWuHzpLJSKZSibPorvLtuNvRfPCfanwwanpryCMQuSxMfHTpEXTJiaQCNLbQpVEGoLPPEuPneRtmjTcMIlamldmSMpdYvkzDmHyQeuWSUxpstAVVlmJYDTYGkDZedOKCrRrsnBeITSbUWouhPw");
    string KivUgtjqS = string("riCGczMdboEkoHZvqVuOioREpCeZceDMmrEUMQqYbXeeXkehnjvXUwrZXTRUzQWqCySsbuMcKms");
    bool ygEwmbfTgDeSBK = false;
    double STRshwywJW = -57333.8667313074;
    int ObnyndVuFwR = 581571808;
    int KuJmsedTO = -1009035493;

    return ygEwmbfTgDeSBK;
}

void iQHvDuMNm::vpznKfecNbaAtT(bool iyOkBQuH)
{
    int AHRXPCkTQoQ = 1071836259;
    bool stROSJmtOMZvAX = false;
    double jxRwEXakdbciAg = 833007.4224360879;
    bool ekyBG = true;

    for (int QxmZuImVsSmot = 1122174969; QxmZuImVsSmot > 0; QxmZuImVsSmot--) {
        stROSJmtOMZvAX = ! stROSJmtOMZvAX;
    }

    for (int jiGLvuhXsa = 899629159; jiGLvuhXsa > 0; jiGLvuhXsa--) {
        jxRwEXakdbciAg -= jxRwEXakdbciAg;
        ekyBG = stROSJmtOMZvAX;
        AHRXPCkTQoQ += AHRXPCkTQoQ;
        ekyBG = iyOkBQuH;
    }
}

double iQHvDuMNm::CcECJou(bool qAeUX, double enUvSNWRHJXcB, bool qptunYMdYfUBlF)
{
    double FFFXnxlkk = 880096.7277246653;
    bool hTcRkq = true;
    string zrIMMwaNcL = string("rhUuqlCrKfnrXOVkljzvfxhvFckTCREHRvMQmjYgRLcnqgkbiumYRzdFFrdbfRcqrnIDCnTloBCnLSdnzqWdhLmITHxHaWgftGrzAWalUSwDGdlMtYcgFeDScBFSZtpgqSwNsUVVhhFWOYWGpSUAPFtkihJXawCscZPzkjODhknwtjWmWVDZSulXXrBtlSEsCjGUlUywJIQymAbnKQmVFzBwwLtJa");

    for (int dFcqNVoppfjJ = 662076237; dFcqNVoppfjJ > 0; dFcqNVoppfjJ--) {
        enUvSNWRHJXcB = FFFXnxlkk;
        qptunYMdYfUBlF = qptunYMdYfUBlF;
        qptunYMdYfUBlF = ! hTcRkq;
    }

    return FFFXnxlkk;
}

int iQHvDuMNm::nPyzaRF(string rUPrAxOzeSXa, string juHXnIRjrQfp, bool vRkoyVnB, double VCABorJkN, double UcAcmDiEhZSk)
{
    double tcNWgzK = 435856.7189496154;
    string cRtfBVXICNRf = string("vDPiDScgBsLCJEFAmwiMAHsknvLvusqJWvbkCDrFONB");
    string zJWkKclihyDuXJiU = string("zeECGybpNiq");

    if (zJWkKclihyDuXJiU < string("vDPiDScgBsLCJEFAmwiMAHsknvLvusqJWvbkCDrFONB")) {
        for (int ZPbcvIoviMBdxDh = 2085520000; ZPbcvIoviMBdxDh > 0; ZPbcvIoviMBdxDh--) {
            VCABorJkN *= UcAcmDiEhZSk;
        }
    }

    for (int kFxLIQvU = 724956520; kFxLIQvU > 0; kFxLIQvU--) {
        rUPrAxOzeSXa += juHXnIRjrQfp;
        rUPrAxOzeSXa += cRtfBVXICNRf;
    }

    return -143453820;
}

bool iQHvDuMNm::NlfwF(double LETHAbVCqbKZAr)
{
    bool olteb = true;

    for (int JlUcC = 629006804; JlUcC > 0; JlUcC--) {
        LETHAbVCqbKZAr += LETHAbVCqbKZAr;
        olteb = ! olteb;
    }

    if (olteb == true) {
        for (int QCQdX = 1018531891; QCQdX > 0; QCQdX--) {
            olteb = ! olteb;
            olteb = ! olteb;
            LETHAbVCqbKZAr -= LETHAbVCqbKZAr;
            LETHAbVCqbKZAr -= LETHAbVCqbKZAr;
        }
    }

    if (olteb != true) {
        for (int mExkqDbdZZKW = 351410504; mExkqDbdZZKW > 0; mExkqDbdZZKW--) {
            LETHAbVCqbKZAr += LETHAbVCqbKZAr;
            LETHAbVCqbKZAr *= LETHAbVCqbKZAr;
            olteb = ! olteb;
            olteb = olteb;
            olteb = ! olteb;
        }
    }

    return olteb;
}

iQHvDuMNm::iQHvDuMNm()
{
    this->hyxedrSXdJYOQ(767915.3606467614);
    this->tFQEcxR(245252786);
    this->vpznKfecNbaAtT(false);
    this->CcECJou(true, -778247.4547325001, true);
    this->nPyzaRF(string("nKMAKbCwrMSzVZHtZNZrAibzMXrPLyqkSxlCPcgFJXxJkufcumqtFlldlIeQYrfjrFCGJveHncyaUFPjHsaXfkSjiBkZHcdZslxtBLebKULwwWdfpWuGBFuUghDZRTTryWGlgZAlRCVfSCQdNmbhrqOtfcjpyCDQwpsAGNGMRfvVGjTeMryBTJEssNeTUAjGRaON"), string("xnIPFqshVYbuhGUDnEqXCMUuFKUZWDUAduhgtkonzykVTxVmfqmtbMOYvUQacRNNbYZBbSuxisWrJDTjA"), true, -840185.7337596765, -58382.34947401261);
    this->NlfwF(974359.6849680883);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bsDpxeOfVU
{
public:
    int NBnsuKRuPhzGS;
    bool BuDEGQdInKpv;
    string PpARIfr;
    bool ngEIHAPHYq;
    string YYXWfNQjI;

    bsDpxeOfVU();
    void LDLghtkTAvNMEY();
    void ojeAG(double EtavdSR, string wsTsYPUAY, double yvngvyefLLvXM, bool ZzLeghPLpNvDbff, string KwkCrcWZgrC);
    int vjWAnIKKUmb(string TKIVOirtDmjA, string QgWRJeFyky, bool nRbwKtQmvENoXNmr, bool OUzPKCiZhfnz, bool IcWTlUSjZ);
    void IHyZgkC(double GiSepVY, string gvDxEmPEBXzWF);
    string mLkcttNLNvQgYudB(int aJvsXAT, int HsWunJkWw);
protected:
    int tRBzBW;
    int yhfKQHlV;
    string JAsPTR;
    int PmmlQ;

private:
    double Nlxis;
    string WyuQjutZ;
    double BAjlxjKgAhLsVczt;
    double uMGVwUJgQCaZEltY;

    bool PbUgMRrcXVs(string nprUuPnQqL, double NHboX);
    void fgfRXARB(string PoTwoumAN, string dNilZs, string WfyOtcaDZYYxQi, string TEywrXjnZLUD);
    int kPnXjbk();
    bool uRKZHaCUBYNQLbA(string sxpAbTgjvqECLkCZ);
    void jdWUDrh(int vowQPHcOeyGsJuNo, int HkZbCKmIxL, bool XhwegI, double rqSgUtjGqLrMlV, int hCUeGpvFlmdGIdk);
    void IQrvsKhKkzxIzzf(double SpetvMjElvBE, string iGihaCfrYf, bool LIVvWPeUacqNf, double aLXEYTsVmMG, bool JUONCBK);
    void UPZzcOFLQiBorA(double nHgptDTl, int EMzRjVSbQhhTgFbZ, string VnBnQ);
};

void bsDpxeOfVU::LDLghtkTAvNMEY()
{
    string NyqoHNKNCAUblc = string("aUshzktKfXtyTRFsRgVFXyHZDxcZqUadePacXpRhlHgrwIokqWEpZhLQZvSvyDtUCLiEcdohjMeXJVmXrBNbLLWDNhJlAGnsIjePtRsPcngnlVuMclrKYQSjCbubanNNHKNgXZvQNJeGgftbWhwkUtyWeClTjqmSsuxJDAwvoVbzjc");
    bool aFvGNZKZbUmswn = true;
    string frDAXMJZghUKbY = string("kLWcvIjOBWSzXzjlbxOWyQweZglKhgIeFadtkxyEfUJewEFDXSVYtblnsXBMpbPcBUNhiTLLaIeniztOowIRWambbRrJlDzThpPTKZiMAGSZeGgDRsENbxJByHxEAcZAJJRmdMneEAAsfxWHVpxrusazOwEQWBeJBnOgIZeAqgCaVRZPGeVyYaNdVDYKrwRIfBofApyuZtqpFbWIGrezlJICmksYLKYq");
    double EqBrnokw = -223766.00952138877;
    string TQoPgrafiK = string("dgAhKtJpJGZBiksizykczCalBq");
    string nwocYjgsbO = string("tAOzLyWyTUImPTrELUDZgmEheyoWgbZhrYzzGYDuxgSJoHJWhMNtiaeBGewQUfwuuDyFPXOkSuNZkKnJUKokhwjACYsqpslivqJKodlwwmxROHVKDMQrOUSdkwIGdlVzmHNNBFDMwEhzEhYy");
    int jbgkJm = 1428759535;

    for (int JEtrOv = 1700077210; JEtrOv > 0; JEtrOv--) {
        frDAXMJZghUKbY = TQoPgrafiK;
        TQoPgrafiK = frDAXMJZghUKbY;
        EqBrnokw += EqBrnokw;
    }
}

void bsDpxeOfVU::ojeAG(double EtavdSR, string wsTsYPUAY, double yvngvyefLLvXM, bool ZzLeghPLpNvDbff, string KwkCrcWZgrC)
{
    bool fgZtjCwDsFsJFEf = true;
    int vpHFc = 1311109337;
    double tPKfTQPPV = -180293.03829357252;
    int rGWWSbaWnGPPQ = -244905948;
    int bKnghaYQyFunVZR = -856256855;

    for (int VKVRYGPeFXyDvbP = 1086310030; VKVRYGPeFXyDvbP > 0; VKVRYGPeFXyDvbP--) {
        tPKfTQPPV += EtavdSR;
        vpHFc += vpHFc;
        ZzLeghPLpNvDbff = ZzLeghPLpNvDbff;
        vpHFc *= rGWWSbaWnGPPQ;
    }

    if (ZzLeghPLpNvDbff != true) {
        for (int CVtNIu = 1580759507; CVtNIu > 0; CVtNIu--) {
            KwkCrcWZgrC = wsTsYPUAY;
            vpHFc *= vpHFc;
        }
    }
}

int bsDpxeOfVU::vjWAnIKKUmb(string TKIVOirtDmjA, string QgWRJeFyky, bool nRbwKtQmvENoXNmr, bool OUzPKCiZhfnz, bool IcWTlUSjZ)
{
    string bJBmVFuU = string("QXiuGhVxFPmrpXjnkRuSkFIRweTdwnEWvatJPIyJLPDbEWcBCqHjDQsLMvboUCNoIEzucLsYeByQCSWDFPcHforwJbaksZqPYGpyNGJWnBgZFsTBLrJYJUMMxXadqSKqWapeEaohKyqgPopytCOBEDBGSFAfHcufOkLsrgBOFOVTUzPEqxOLWNiQerLdqlkIbmDlXepzLEwjvyTzsigMsUsyhutZDXSXIuVsYq");
    string Qercg = string("SnAklekQmECVZFBSKXSznSyMEUxjcIXvxtiXJmHvBLuKeVxybFCDOUN");
    string nZOVfPivMTtzz = string("nrxEMtnNIeWJbhsLnZFzZuFPcJZgUeBQyaPEQpmFiRPwtspUnqoCpSXcvhDnHKbhtVwUurwumuzZaAcjnEflmOEzOUbRUWEjYKpdLCdnOwiOEkbnaJVPGskCwjttjYevyICTwJmdkfDkYOtBoEqAxneWMUBhNqeNVTbwLgadNgWFdmybFizHLtTgStUsbGf");
    bool gNqPbtsAtWNRZxL = true;
    double sXiSB = 869294.9258109946;
    double qGufgZfPD = -485945.5163977195;
    double KZrduSONStkU = -534435.1686127397;
    bool tEFUKAQqYIuMaRD = false;
    bool PzXbJF = true;
    int zoJTsZsLCYFlSs = -1373595824;

    for (int IlIsjETA = 1290841194; IlIsjETA > 0; IlIsjETA--) {
        OUzPKCiZhfnz = PzXbJF;
        qGufgZfPD *= sXiSB;
        nRbwKtQmvENoXNmr = ! PzXbJF;
    }

    for (int hUXHHpFIn = 309055842; hUXHHpFIn > 0; hUXHHpFIn--) {
        zoJTsZsLCYFlSs = zoJTsZsLCYFlSs;
    }

    for (int gwgbTPVjKTsEPeF = 1864086629; gwgbTPVjKTsEPeF > 0; gwgbTPVjKTsEPeF--) {
        KZrduSONStkU *= KZrduSONStkU;
    }

    return zoJTsZsLCYFlSs;
}

void bsDpxeOfVU::IHyZgkC(double GiSepVY, string gvDxEmPEBXzWF)
{
    double maLpxneLNPuM = 572760.3886027809;

    if (GiSepVY < 572760.3886027809) {
        for (int iFMosKLrIodcL = 1108072407; iFMosKLrIodcL > 0; iFMosKLrIodcL--) {
            GiSepVY -= maLpxneLNPuM;
            GiSepVY += maLpxneLNPuM;
            gvDxEmPEBXzWF = gvDxEmPEBXzWF;
            maLpxneLNPuM = GiSepVY;
            GiSepVY = maLpxneLNPuM;
        }
    }

    for (int QXjqsxrgV = 1526855772; QXjqsxrgV > 0; QXjqsxrgV--) {
        GiSepVY += GiSepVY;
        maLpxneLNPuM -= GiSepVY;
        maLpxneLNPuM -= maLpxneLNPuM;
        maLpxneLNPuM *= maLpxneLNPuM;
        gvDxEmPEBXzWF = gvDxEmPEBXzWF;
        GiSepVY = GiSepVY;
    }

    if (maLpxneLNPuM > 572760.3886027809) {
        for (int waoKdCAqIW = 563078784; waoKdCAqIW > 0; waoKdCAqIW--) {
            continue;
        }
    }

    for (int xsiWKKm = 1771735463; xsiWKKm > 0; xsiWKKm--) {
        continue;
    }

    if (maLpxneLNPuM < 625722.125494854) {
        for (int IomUngoeiPVsWZCF = 776873204; IomUngoeiPVsWZCF > 0; IomUngoeiPVsWZCF--) {
            maLpxneLNPuM += maLpxneLNPuM;
            maLpxneLNPuM -= GiSepVY;
        }
    }
}

string bsDpxeOfVU::mLkcttNLNvQgYudB(int aJvsXAT, int HsWunJkWw)
{
    string TlTFPK = string("WXQLFZpqVpFewdddLXtNZndRTkDzypUkSOZZsZSgYBCsTmOxLmjGiVvGDAxEAsVUXEdeEHvONkCKkkcWAnTmSCOpokMRiCVLlfcjfgEqdAAodgqeMgnTJSjuifajYcSzZzNtJ");
    string hCzPhDfSXFtyy = string("nGIBMvqXpvHFcRAgkfxHXEuSyNUiDZA");
    bool KmiKatbM = false;
    string szkqOM = string("fDUOgRRRbIquSEIxozPLslQxhdCUvyeCxUXwRwMbqBXjuOZDXGKhPTcwnWbnEVxpEavqtQITCEKOrH");
    bool zKuPhzMI = false;
    string KRqKCItaHqJhY = string("RJRLBtnrKnQDLJrgIfxNgrUPe");

    for (int ghvRBo = 2134813745; ghvRBo > 0; ghvRBo--) {
        hCzPhDfSXFtyy += TlTFPK;
        zKuPhzMI = ! zKuPhzMI;
        TlTFPK += szkqOM;
    }

    if (szkqOM > string("RJRLBtnrKnQDLJrgIfxNgrUPe")) {
        for (int YrWKnEKbKKkeDZMF = 2016346053; YrWKnEKbKKkeDZMF > 0; YrWKnEKbKKkeDZMF--) {
            KRqKCItaHqJhY = szkqOM;
        }
    }

    if (zKuPhzMI == false) {
        for (int wBeLAPSsaKjRHRI = 439125371; wBeLAPSsaKjRHRI > 0; wBeLAPSsaKjRHRI--) {
            KRqKCItaHqJhY = hCzPhDfSXFtyy;
            TlTFPK += szkqOM;
            TlTFPK += TlTFPK;
            KmiKatbM = ! KmiKatbM;
        }
    }

    for (int SGSsvisbkYikzJQl = 1439290740; SGSsvisbkYikzJQl > 0; SGSsvisbkYikzJQl--) {
        TlTFPK += TlTFPK;
    }

    for (int NgqNSVOQIwniYQi = 205444334; NgqNSVOQIwniYQi > 0; NgqNSVOQIwniYQi--) {
        szkqOM += szkqOM;
        hCzPhDfSXFtyy = TlTFPK;
    }

    return KRqKCItaHqJhY;
}

bool bsDpxeOfVU::PbUgMRrcXVs(string nprUuPnQqL, double NHboX)
{
    double aCTNlVniiR = 404765.61424501025;
    bool DoLasBnFSeYRj = false;
    double NrNFaMYTcHj = 314390.84417256195;
    double plZVddGt = -759742.2149846203;
    int ZDWQgNV = 1236394663;
    string WIkdKQIppvpvpsq = string("EWuHUtJlSZGiRxvLcRqHePhuNnoRxfqyJweLAYADAxhHIhVPEGUkhCuhFZDUINpncERQyOhJfwxohVErjLQfckdVbyLKvWVDqqGYnZqmHWBKIqFSdkEyYImZQViibloYhYGJU");
    bool HfdIfXQhiZomVn = true;
    string vZxDWdYuaff = string("OEUhFyuemjDRyi");
    int SqYavoDn = -320581296;

    for (int WwDIa = 831063063; WwDIa > 0; WwDIa--) {
        WIkdKQIppvpvpsq = vZxDWdYuaff;
        WIkdKQIppvpvpsq += vZxDWdYuaff;
    }

    for (int cclQev = 1260770933; cclQev > 0; cclQev--) {
        continue;
    }

    if (ZDWQgNV != -320581296) {
        for (int PsIiXEqR = 997493043; PsIiXEqR > 0; PsIiXEqR--) {
            NHboX *= NHboX;
            NHboX = NHboX;
        }
    }

    if (NrNFaMYTcHj < -363733.0453230174) {
        for (int pLoYi = 12598332; pLoYi > 0; pLoYi--) {
            NrNFaMYTcHj -= NHboX;
            nprUuPnQqL += WIkdKQIppvpvpsq;
            DoLasBnFSeYRj = DoLasBnFSeYRj;
        }
    }

    for (int xubBDOxyoOLGiDMl = 712439254; xubBDOxyoOLGiDMl > 0; xubBDOxyoOLGiDMl--) {
        plZVddGt = NHboX;
        SqYavoDn = ZDWQgNV;
    }

    return HfdIfXQhiZomVn;
}

void bsDpxeOfVU::fgfRXARB(string PoTwoumAN, string dNilZs, string WfyOtcaDZYYxQi, string TEywrXjnZLUD)
{
    double zZfjiFKTRKnw = -549642.2842289502;
    int eiVEEvUTypaZFsOI = -1077232111;
    int QbiwpEpEsl = 152350222;
    double cnHGdMXQjdU = -916861.9570858383;
    double ggoFHlWM = 573537.6803283396;
    bool ebvOfSRWzZkAtje = true;
    double EIjWWcVFZg = -930300.7864064297;
    double VsDCStLvWMF = 759076.8367291191;
    double rqgKUhajNlf = 702790.1345844556;
    double OyBtMTfvvCjD = -296215.24883605243;

    for (int ZtHjkdxtb = 684309171; ZtHjkdxtb > 0; ZtHjkdxtb--) {
        zZfjiFKTRKnw += rqgKUhajNlf;
        rqgKUhajNlf /= zZfjiFKTRKnw;
        WfyOtcaDZYYxQi = dNilZs;
        ggoFHlWM -= EIjWWcVFZg;
        dNilZs = WfyOtcaDZYYxQi;
        EIjWWcVFZg -= cnHGdMXQjdU;
    }

    if (rqgKUhajNlf > 759076.8367291191) {
        for (int yTkNNNqRhoPHJZt = 1334084506; yTkNNNqRhoPHJZt > 0; yTkNNNqRhoPHJZt--) {
            continue;
        }
    }

    if (cnHGdMXQjdU <= 573537.6803283396) {
        for (int pycXNS = 1274584808; pycXNS > 0; pycXNS--) {
            cnHGdMXQjdU = ggoFHlWM;
            OyBtMTfvvCjD += EIjWWcVFZg;
            PoTwoumAN += WfyOtcaDZYYxQi;
            cnHGdMXQjdU *= cnHGdMXQjdU;
            TEywrXjnZLUD += TEywrXjnZLUD;
            cnHGdMXQjdU = rqgKUhajNlf;
        }
    }

    for (int IAfiTsskzuQsaXqi = 842015594; IAfiTsskzuQsaXqi > 0; IAfiTsskzuQsaXqi--) {
        zZfjiFKTRKnw = EIjWWcVFZg;
        EIjWWcVFZg -= EIjWWcVFZg;
        WfyOtcaDZYYxQi += dNilZs;
    }

    for (int JkBJwLzHfCUXE = 2009501700; JkBJwLzHfCUXE > 0; JkBJwLzHfCUXE--) {
        VsDCStLvWMF = ggoFHlWM;
        EIjWWcVFZg += VsDCStLvWMF;
        VsDCStLvWMF *= VsDCStLvWMF;
        VsDCStLvWMF += VsDCStLvWMF;
    }
}

int bsDpxeOfVU::kPnXjbk()
{
    int cjjIuIRsE = -914501085;
    int eIPHhrTSd = -1038969811;
    double qoIDBO = -712901.2258622118;
    double QfaRclDW = 347264.53214834514;
    int jVkyrzeAsHQmvCT = 715358059;
    bool ikqWVgW = false;
    int gRhuAKgHHahEXeoR = -247864658;

    if (QfaRclDW <= -712901.2258622118) {
        for (int uXrijYOylwZDcMOw = 739273816; uXrijYOylwZDcMOw > 0; uXrijYOylwZDcMOw--) {
            jVkyrzeAsHQmvCT -= eIPHhrTSd;
            cjjIuIRsE -= jVkyrzeAsHQmvCT;
            ikqWVgW = ! ikqWVgW;
            cjjIuIRsE *= gRhuAKgHHahEXeoR;
            jVkyrzeAsHQmvCT *= gRhuAKgHHahEXeoR;
            cjjIuIRsE = jVkyrzeAsHQmvCT;
            cjjIuIRsE += eIPHhrTSd;
            qoIDBO = qoIDBO;
        }
    }

    for (int KmSiwMvYHoHKF = 271363806; KmSiwMvYHoHKF > 0; KmSiwMvYHoHKF--) {
        eIPHhrTSd -= eIPHhrTSd;
        QfaRclDW /= qoIDBO;
    }

    return gRhuAKgHHahEXeoR;
}

bool bsDpxeOfVU::uRKZHaCUBYNQLbA(string sxpAbTgjvqECLkCZ)
{
    bool YHQwHzfBS = false;
    bool NRDLfbU = false;
    int LbTjwAXslW = 665089217;
    int pdbQhLkFT = 604876918;

    for (int psGHqabCscd = 1696390282; psGHqabCscd > 0; psGHqabCscd--) {
        sxpAbTgjvqECLkCZ += sxpAbTgjvqECLkCZ;
    }

    if (YHQwHzfBS != false) {
        for (int BBuLoYfpCvYNydtQ = 1808899756; BBuLoYfpCvYNydtQ > 0; BBuLoYfpCvYNydtQ--) {
            pdbQhLkFT -= pdbQhLkFT;
            pdbQhLkFT *= pdbQhLkFT;
        }
    }

    return NRDLfbU;
}

void bsDpxeOfVU::jdWUDrh(int vowQPHcOeyGsJuNo, int HkZbCKmIxL, bool XhwegI, double rqSgUtjGqLrMlV, int hCUeGpvFlmdGIdk)
{
    string aUfmfJga = string("WuaMPwIo");
    string BOZxiOMAH = string("RmyQCzcXfza");
    bool jjmssqdCOsIguak = false;
    bool MJXXDpBn = true;
    double buxQLCVEJMJUgt = 166662.11163458432;

    for (int RFObXr = 902714143; RFObXr > 0; RFObXr--) {
        MJXXDpBn = ! MJXXDpBn;
    }

    if (rqSgUtjGqLrMlV < 166662.11163458432) {
        for (int znHfRlFRD = 784227152; znHfRlFRD > 0; znHfRlFRD--) {
            continue;
        }
    }

    for (int OcRwOqsDPE = 368539257; OcRwOqsDPE > 0; OcRwOqsDPE--) {
        rqSgUtjGqLrMlV = buxQLCVEJMJUgt;
    }

    for (int CGFri = 1795528835; CGFri > 0; CGFri--) {
        vowQPHcOeyGsJuNo -= vowQPHcOeyGsJuNo;
        jjmssqdCOsIguak = XhwegI;
        buxQLCVEJMJUgt /= rqSgUtjGqLrMlV;
        rqSgUtjGqLrMlV += rqSgUtjGqLrMlV;
    }
}

void bsDpxeOfVU::IQrvsKhKkzxIzzf(double SpetvMjElvBE, string iGihaCfrYf, bool LIVvWPeUacqNf, double aLXEYTsVmMG, bool JUONCBK)
{
    bool aUQBHPiiR = false;
    int xWtJiKCUyJfHpxL = -1779280488;
    string SamlyTmX = string("qlDpTgaKIGmSDWGbxuPDZLZxhxqkWJgIDTiIFDyN");

    for (int bxVzzYpKo = 236084451; bxVzzYpKo > 0; bxVzzYpKo--) {
        SpetvMjElvBE -= aLXEYTsVmMG;
        LIVvWPeUacqNf = aUQBHPiiR;
    }

    for (int KARtyFEffLhZpuFm = 1075676694; KARtyFEffLhZpuFm > 0; KARtyFEffLhZpuFm--) {
        xWtJiKCUyJfHpxL = xWtJiKCUyJfHpxL;
    }

    for (int MtgMIatNhZvHGkiu = 502536929; MtgMIatNhZvHGkiu > 0; MtgMIatNhZvHGkiu--) {
        continue;
    }

    for (int uLnQfvZWstmE = 1034441473; uLnQfvZWstmE > 0; uLnQfvZWstmE--) {
        SpetvMjElvBE -= aLXEYTsVmMG;
        iGihaCfrYf += iGihaCfrYf;
    }

    for (int XhuAHzzg = 1140289077; XhuAHzzg > 0; XhuAHzzg--) {
        continue;
    }

    for (int tTJTA = 1233026514; tTJTA > 0; tTJTA--) {
        continue;
    }
}

void bsDpxeOfVU::UPZzcOFLQiBorA(double nHgptDTl, int EMzRjVSbQhhTgFbZ, string VnBnQ)
{
    bool MrkGDllddF = false;
    double HmLczkeBgoc = -549193.5248114944;
    bool JUUyZrBu = true;
    int gKpXObYKwpYlB = -292401292;
    bool LINIaz = true;

    if (nHgptDTl <= -549193.5248114944) {
        for (int flfeAztJaLKr = 14694501; flfeAztJaLKr > 0; flfeAztJaLKr--) {
            continue;
        }
    }

    for (int LLnMpblowJgZZriG = 297032499; LLnMpblowJgZZriG > 0; LLnMpblowJgZZriG--) {
        continue;
    }

    if (MrkGDllddF != true) {
        for (int epivW = 411807280; epivW > 0; epivW--) {
            continue;
        }
    }

    for (int PYTOzFBVME = 298303097; PYTOzFBVME > 0; PYTOzFBVME--) {
        LINIaz = LINIaz;
        nHgptDTl = HmLczkeBgoc;
        MrkGDllddF = ! LINIaz;
    }

    for (int cZAbHTLiXQn = 1537169133; cZAbHTLiXQn > 0; cZAbHTLiXQn--) {
        LINIaz = ! LINIaz;
        LINIaz = LINIaz;
        MrkGDllddF = ! LINIaz;
    }

    if (HmLczkeBgoc != -567203.4282606705) {
        for (int bDnsagstBUSDf = 1563382014; bDnsagstBUSDf > 0; bDnsagstBUSDf--) {
            continue;
        }
    }

    if (EMzRjVSbQhhTgFbZ >= -1741462978) {
        for (int jTACb = 2109893235; jTACb > 0; jTACb--) {
            continue;
        }
    }

    if (JUUyZrBu == false) {
        for (int EPNIjjbmjWN = 398411809; EPNIjjbmjWN > 0; EPNIjjbmjWN--) {
            continue;
        }
    }
}

bsDpxeOfVU::bsDpxeOfVU()
{
    this->LDLghtkTAvNMEY();
    this->ojeAG(-662511.2510734134, string("eUjFvvJTjqLyoTmJlcUHmlsFZtpXhpRDuKulguZKxVgszPHaHUAiFDcwVFrNfZXrePoaskVgRgFhJgHqFIrAtIBdZDXVFyVvFlrsKYHsqdDI"), -166658.1210562275, false, string("alAxJIsbcMUqYzyaFFVIPxZbQFBNHBAHJlPjorDPhsasHuyHEnDHmzjFbmCfLgVfGjDtiRZWgIdShbDvBtHIibPvyVCgqdTwXiZoRTQbP"));
    this->vjWAnIKKUmb(string("hImhoJhCcozMByYEZiKltreCocmQdmefucXMMycQuljLsvSfEjGoMQOdaOJweIBVFUCMKdlvxKlEmIofnYLcDPsNqDDMQpSAZdERXZmTIcmRnFQTHiQJeMtwDAMRVjqjMAHmenEWwUJdgMPPyCZgKhPkXWVerYAsDLqvMUWZKMePfyvY"), string("fhdniRcReSqQkZhyelQSDhKcIPdWeaUBSkvinUZkLJfmdFpGvKFlZTRwPBoRnIIpiGweNlnAEQkaALRKqtiFgvnuyBhuoJMgHpAbBCecYIIUScVJnXgNGcEwnkzJbBSkAcSKKFTAkMrZHAoSHBjvidBLApXpCyFulhEFvQCNIFmFddCrIZdOZkLIhfdpQedDbdkzWvCrgKrdEagWNfeRjDk"), false, true, false);
    this->IHyZgkC(625722.125494854, string("eDvhuFgHSMGCLhZCzTGvHmejyOSnGIcfuTAmYspzIalvkAKSwvpbpFIuIKJzJKbgBuVzfAEIdBGGcawGMaCMNwtmie"));
    this->mLkcttNLNvQgYudB(2005175310, -732138978);
    this->PbUgMRrcXVs(string("Z"), -363733.0453230174);
    this->fgfRXARB(string("ifUkqZNuhaSZTeVtsnOcBKuKlDTrAAQCnnfpIfcGIfVSBceUbpSLCfLRIGsjSpVkZCuSRPQcxYEyGScsmjCPWiIlrFemLlLLdZ"), string("nYBxnDifGRQlzNcvIuNxvZZjxlbkhwyneConckdSeFfzJQvxQNxRwkxoXgagSOCYSZRQZNPoKmJGIpA"), string("xb"), string("rGiKoCVvkXJSeLsYPTWGCzwAOAypFWqPtgzuSHDHnjkzUymIsyAkbdkKhoIppfonmMloCLibfCSuvpfcFvhdhaBTEc"));
    this->kPnXjbk();
    this->uRKZHaCUBYNQLbA(string("XezFtuGbbkmSqfKSQUocPWogMmTPehwPkusmkwByXBAjzvFdPUmMPfhnfWoJxhpuFxrFyTCTBjYoOcJVNkUGTktehWLKvjUzaarcCoLClsnrICNFGKFicYJESHMCOyxenCibRqezTnFNxfaNpYatqkzPiYLGpqRuSrApyKcSgNjSEqyabFBNdkIKcwjoudYOVRVgQyieFrawdOojKrgnMOzncgfWFnOCNBQWcqGh"));
    this->jdWUDrh(84704192, 1584129594, false, -714818.4688042549, -1478449113);
    this->IQrvsKhKkzxIzzf(-53427.51261987406, string("mTSFRdQaXPJeLyXpzPBaexVYSPpsQMGJhhtSbcOGevgUGpRrCJjtC"), true, 185092.24148827553, true);
    this->UPZzcOFLQiBorA(-567203.4282606705, -1741462978, string("LBswHCOHEhUnJyhjtTWllDDjmvVabXjzXxfsHFUWCUzGObSrPVoLohQYaUEmfoLxauSLMotrJehTPHzrHIuxAFlbteRgFvALToegtuOUgbjCWclPMNSKilHxgjefmXeitRaElVTtuOageimarATPmJNCUngNXMCpHjzTWIOLoTBDTolSCmykBcyIXIkLbqyQMhQKvgeKFkIYCxrllBxvWwpKGJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wJOobTdYwHP
{
public:
    double bflOSyOVg;
    int RGHLnjxw;
    bool xsMTAnUPuUeiw;
    bool bUUTWbdxvVcn;
    string EbJDDMSPoCeD;
    int ByDguDfb;

    wJOobTdYwHP();
protected:
    bool KJPbAuze;
    int XlIRH;
    string XknGEJznYMZUSqi;
    string PRIyiibBmOM;
    string JqcqpluqLnmLZWBu;
    string nMieHItukEaxK;

    bool rLupajZI(string SVEZimGnNTVjohlZ);
    void cYaphhoyycxXtx(int cJXsTnBTZ);
    double RMNEAztq(double tPUzrswGGmXIKslE, int xQnAERGMtsO);
    double YoGsMDvnTOzNHFcs(bool apSMsy, string gaQStaNhrrtrZJAv, string AWUMzyRVKWSnLpU, double YjBhacRk, string PXhEPhy);
private:
    string tTSZOBak;
    double GtVCAbS;

    string WvgKAunz(bool sLfyL, double BwQMIv);
    void YUAfA(bool mfYHUUYMgKfwXHya, bool IvajSXN, string vpHTdvqHTkPF);
};

bool wJOobTdYwHP::rLupajZI(string SVEZimGnNTVjohlZ)
{
    bool kHtQZjY = true;

    if (SVEZimGnNTVjohlZ != string("irELSeHkxtsbaioNQPVTBAfStyCQsXhOWHwIZdmkJNObYgUFcAPQWZEDhyRVwkIBQlBrqbMajWFQSctidnLasXaGXIupCKE")) {
        for (int SKOCcmgHNM = 1898978813; SKOCcmgHNM > 0; SKOCcmgHNM--) {
            SVEZimGnNTVjohlZ = SVEZimGnNTVjohlZ;
            kHtQZjY = ! kHtQZjY;
            kHtQZjY = kHtQZjY;
            kHtQZjY = kHtQZjY;
            SVEZimGnNTVjohlZ = SVEZimGnNTVjohlZ;
            SVEZimGnNTVjohlZ += SVEZimGnNTVjohlZ;
        }
    }

    for (int lhudZfWHqDXVmhAb = 836978106; lhudZfWHqDXVmhAb > 0; lhudZfWHqDXVmhAb--) {
        SVEZimGnNTVjohlZ += SVEZimGnNTVjohlZ;
        kHtQZjY = ! kHtQZjY;
        kHtQZjY = ! kHtQZjY;
    }

    if (kHtQZjY != true) {
        for (int cOuNrcuEyc = 1134995055; cOuNrcuEyc > 0; cOuNrcuEyc--) {
            SVEZimGnNTVjohlZ += SVEZimGnNTVjohlZ;
        }
    }

    if (kHtQZjY == true) {
        for (int HDifUAqecMQjj = 1627616679; HDifUAqecMQjj > 0; HDifUAqecMQjj--) {
            SVEZimGnNTVjohlZ = SVEZimGnNTVjohlZ;
        }
    }

    return kHtQZjY;
}

void wJOobTdYwHP::cYaphhoyycxXtx(int cJXsTnBTZ)
{
    double urRUEq = -549732.3125131375;
    string nvazxpux = string("ixzHhxQaJwfyFhVyYTpEYemMGVYDRyWqyZMlAiM");
    double DnPNYiiBVDEhxL = 977179.3800185183;

    if (urRUEq != 977179.3800185183) {
        for (int XjNjNNlx = 473118747; XjNjNNlx > 0; XjNjNNlx--) {
            DnPNYiiBVDEhxL = DnPNYiiBVDEhxL;
            cJXsTnBTZ += cJXsTnBTZ;
            cJXsTnBTZ -= cJXsTnBTZ;
        }
    }

    for (int vAHRdJU = 1517922128; vAHRdJU > 0; vAHRdJU--) {
        DnPNYiiBVDEhxL = DnPNYiiBVDEhxL;
        urRUEq -= DnPNYiiBVDEhxL;
        nvazxpux += nvazxpux;
        urRUEq -= DnPNYiiBVDEhxL;
        DnPNYiiBVDEhxL -= DnPNYiiBVDEhxL;
    }

    for (int ijYBnHmWKGbxj = 504307060; ijYBnHmWKGbxj > 0; ijYBnHmWKGbxj--) {
        cJXsTnBTZ = cJXsTnBTZ;
        cJXsTnBTZ = cJXsTnBTZ;
    }
}

double wJOobTdYwHP::RMNEAztq(double tPUzrswGGmXIKslE, int xQnAERGMtsO)
{
    bool ThzZYBpvXEvzp = false;
    string rYoCRde = string("MelsmTdYpjmJduJMZwpgQIfCkWhrsmvbPgkqRpNvDBlBIcmSzKXIZzEHFqtiwbTFSLSreMMoLolLMDKJPRXLWCSjpclDHXBmNsDYhBoIdWJZoDsDZWBnNcfeONwMxUdlVhGWbSFiYfPYDfEkgPKSCPauXxXoPXDRrtCDGNDvlopGkonUoozlXZWSKQhTAijQtNsMwjrIVuaFma");
    int mjIFUKCfwruYETKu = 575363101;
    bool srHgzcwse = true;
    int IdWuQiTmyhWmML = -1751890855;
    string qMhQqHXJPWwbaI = string("WWUHSpJaguajbQVLhaXlEcetJVtEclWeLbkUUAwszHSmCKLobJpNWnpTBWelBFiXqQgKJFozKWIoFpgMEIAKUVMrutXOpMLSIcaxmZJWgjvGfwWxJmkywaOpbLXevCprbCrIJyKyGpiYCTGOvqnEWGzlYCQUXGRispPEozgznsGKdDTCCYGIPSlWbgkdonNAoEHOtoTLDcFjGcSgHWzECqsfHrrIIJquuWLYjksDlQcgnDxfwXs");
    int MCrheHHOYjaqJUmx = 1026659803;
    double UxEKyYnAgTJd = 715554.598977044;
    bool NRCQulZzFFHNN = false;
    string vVtyKbkvR = string("NkPXjamcwNujyAtbFSTXwbpICuFKjjBgvwZjuMYonJSXFRKVvsfyMFmzNutRuWTCREiXjVzHLQHAZEmCallqVJKkP");

    if (vVtyKbkvR > string("MelsmTdYpjmJduJMZwpgQIfCkWhrsmvbPgkqRpNvDBlBIcmSzKXIZzEHFqtiwbTFSLSreMMoLolLMDKJPRXLWCSjpclDHXBmNsDYhBoIdWJZoDsDZWBnNcfeONwMxUdlVhGWbSFiYfPYDfEkgPKSCPauXxXoPXDRrtCDGNDvlopGkonUoozlXZWSKQhTAijQtNsMwjrIVuaFma")) {
        for (int HLwfIrGDDPDrvzch = 692543948; HLwfIrGDDPDrvzch > 0; HLwfIrGDDPDrvzch--) {
            xQnAERGMtsO += IdWuQiTmyhWmML;
            xQnAERGMtsO = MCrheHHOYjaqJUmx;
            vVtyKbkvR += rYoCRde;
            MCrheHHOYjaqJUmx /= IdWuQiTmyhWmML;
        }
    }

    for (int QdbnFJzS = 1791302983; QdbnFJzS > 0; QdbnFJzS--) {
        continue;
    }

    for (int oXYDWeFStGop = 1631627407; oXYDWeFStGop > 0; oXYDWeFStGop--) {
        UxEKyYnAgTJd = UxEKyYnAgTJd;
        mjIFUKCfwruYETKu -= IdWuQiTmyhWmML;
    }

    for (int qPLKHwyuBrfO = 1333447386; qPLKHwyuBrfO > 0; qPLKHwyuBrfO--) {
        mjIFUKCfwruYETKu = IdWuQiTmyhWmML;
        rYoCRde = qMhQqHXJPWwbaI;
        tPUzrswGGmXIKslE *= UxEKyYnAgTJd;
    }

    return UxEKyYnAgTJd;
}

double wJOobTdYwHP::YoGsMDvnTOzNHFcs(bool apSMsy, string gaQStaNhrrtrZJAv, string AWUMzyRVKWSnLpU, double YjBhacRk, string PXhEPhy)
{
    bool qZYOarESdXoukUC = true;
    string WlFLxWrkgtEpnmEq = string("wDnpIKYTIFNsweYZOECTMpBzdVyBaxwFXiQhOEzjOPMrKqbvwBICioAYmAJcoYsKVMvuGyuSRNlUswZVBQDkgsALMpHZChQxiwpFeqWOiofdNV");
    string OCbUIyiUIdeMa = string("PzhHKUPVJNHWuCGPCQcXSbsCVcuuljOMfvfwiqggvAILeICkqMcmlf");
    double mQTAwNmZks = -701571.0199374835;
    bool YnChUNCmOPUN = false;

    if (WlFLxWrkgtEpnmEq != string("PzhHKUPVJNHWuCGPCQcXSbsCVcuuljOMfvfwiqggvAILeICkqMcmlf")) {
        for (int qABxG = 561694653; qABxG > 0; qABxG--) {
            WlFLxWrkgtEpnmEq += PXhEPhy;
            AWUMzyRVKWSnLpU = gaQStaNhrrtrZJAv;
        }
    }

    for (int ByFgFjbmbbUWzQ = 1853362526; ByFgFjbmbbUWzQ > 0; ByFgFjbmbbUWzQ--) {
        WlFLxWrkgtEpnmEq += gaQStaNhrrtrZJAv;
        OCbUIyiUIdeMa += WlFLxWrkgtEpnmEq;
        gaQStaNhrrtrZJAv += OCbUIyiUIdeMa;
        gaQStaNhrrtrZJAv = PXhEPhy;
    }

    for (int oQskbaqSFY = 2116584235; oQskbaqSFY > 0; oQskbaqSFY--) {
        gaQStaNhrrtrZJAv = WlFLxWrkgtEpnmEq;
        OCbUIyiUIdeMa = OCbUIyiUIdeMa;
        PXhEPhy = OCbUIyiUIdeMa;
    }

    return mQTAwNmZks;
}

string wJOobTdYwHP::WvgKAunz(bool sLfyL, double BwQMIv)
{
    double oOBEbzmlUa = -988145.7031564497;
    int xbRwUCawcWlVTlT = 1422735536;
    double lTFsmeRfEMhvoUz = 455157.4615146735;
    int xGcIUoDRpzlCIS = -634238041;
    int GKGMZRXVkfgTlJ = 660397187;
    int mrtovUolyX = 1305662827;
    string vtvAPNJjjFQINaxp = string("dAZKEUavSxndrYDLEhMiUNnLMWWzTSoVSiCiIhYFkGDIKOCBNKBjTjUSnaYTKFQa");

    if (oOBEbzmlUa >= 455157.4615146735) {
        for (int lvhlpZDbObKRPq = 1665136406; lvhlpZDbObKRPq > 0; lvhlpZDbObKRPq--) {
            mrtovUolyX = GKGMZRXVkfgTlJ;
            lTFsmeRfEMhvoUz *= lTFsmeRfEMhvoUz;
        }
    }

    for (int DrFzyAfUxdzUq = 1231005063; DrFzyAfUxdzUq > 0; DrFzyAfUxdzUq--) {
        continue;
    }

    if (xGcIUoDRpzlCIS >= -634238041) {
        for (int OEPADD = 1561598184; OEPADD > 0; OEPADD--) {
            xbRwUCawcWlVTlT = xGcIUoDRpzlCIS;
        }
    }

    for (int CSdQdwB = 1732938311; CSdQdwB > 0; CSdQdwB--) {
        sLfyL = sLfyL;
    }

    return vtvAPNJjjFQINaxp;
}

void wJOobTdYwHP::YUAfA(bool mfYHUUYMgKfwXHya, bool IvajSXN, string vpHTdvqHTkPF)
{
    int kCaUhHfQCROOWNo = 387953468;
    string RPPcz = string("PMpPeKXMbefDkapnayEyhyxzjaZLNrXUmYDBf");
    int rNmOIqlDRyDHZ = -954421984;

    for (int nhcrusi = 725078371; nhcrusi > 0; nhcrusi--) {
        mfYHUUYMgKfwXHya = ! IvajSXN;
        RPPcz = vpHTdvqHTkPF;
    }

    if (RPPcz != string("TfcqJYzXtYTZxYXOFOGOXaYxHVrJUwjvAJoeSjFRUFNbhGNBqPBDsYWWRxhATmBBlykNfpPZqYREvzEBBhfxZNrtTigmIXvEfKsbzRXxTlpcuaAEUgVrOpRVCIKQKkIDCGfcuEBDRhIJPjtyKYJlDHobkTdWySXMFScJISFzaIDgzvQYYcmVaIObfAkrpXwxbnJFqmCTMGrebIZXSPOxClAnLwGainwHCKBKjdurJWYtpXycBHdd")) {
        for (int UiRrKuocpzInDtxh = 522570519; UiRrKuocpzInDtxh > 0; UiRrKuocpzInDtxh--) {
            rNmOIqlDRyDHZ /= rNmOIqlDRyDHZ;
        }
    }

    for (int uZbUeORqiNwkDQw = 672308524; uZbUeORqiNwkDQw > 0; uZbUeORqiNwkDQw--) {
        RPPcz = vpHTdvqHTkPF;
        rNmOIqlDRyDHZ *= rNmOIqlDRyDHZ;
    }

    for (int aeduAxpfANOQd = 745435057; aeduAxpfANOQd > 0; aeduAxpfANOQd--) {
        IvajSXN = ! IvajSXN;
        RPPcz += RPPcz;
        rNmOIqlDRyDHZ -= rNmOIqlDRyDHZ;
        vpHTdvqHTkPF = RPPcz;
        rNmOIqlDRyDHZ += rNmOIqlDRyDHZ;
    }
}

wJOobTdYwHP::wJOobTdYwHP()
{
    this->rLupajZI(string("irELSeHkxtsbaioNQPVTBAfStyCQsXhOWHwIZdmkJNObYgUFcAPQWZEDhyRVwkIBQlBrqbMajWFQSctidnLasXaGXIupCKE"));
    this->cYaphhoyycxXtx(1618167110);
    this->RMNEAztq(131159.05277883584, 1436190154);
    this->YoGsMDvnTOzNHFcs(true, string("jCZzojeRzIKaYqLbsnlNNqbiOmAYgaMAZnshNpdpoEnRSOipXeCHPIXBmoLtcLKmlTVGg"), string("TgREnHLqFFoZUWARMqvmBzwDbbSUfgMhFKKoVwtglbdmXYJlvvEhoGDkvZDjEowLHNwpQhyapxDULgjYNPRySpfByfVbTEmRKJxaEShgdrQFKDXMIWdqmDYGfDNSSlPROcfdJFIwPOLHYoKfomzLWvzjSyEGnaKJbpFYTmEFdRFsdKYxmSwBGBuf"), 30214.00005687035, string("xNlGiRWXZtzwstXRMyhyblTeihuSxCGZqTdeunmByCeGXwObUPGwJUwHYpbcMPTeRLQMptcRCfbNSxenTvcQZDLoktjFemWKiXQZaIqzwDTwFfzqNBHApxQdahEEUWbFhGCbHRUTpIwLXoSpCBgts"));
    this->WvgKAunz(true, 419613.84940452094);
    this->YUAfA(true, true, string("TfcqJYzXtYTZxYXOFOGOXaYxHVrJUwjvAJoeSjFRUFNbhGNBqPBDsYWWRxhATmBBlykNfpPZqYREvzEBBhfxZNrtTigmIXvEfKsbzRXxTlpcuaAEUgVrOpRVCIKQKkIDCGfcuEBDRhIJPjtyKYJlDHobkTdWySXMFScJISFzaIDgzvQYYcmVaIObfAkrpXwxbnJFqmCTMGrebIZXSPOxClAnLwGainwHCKBKjdurJWYtpXycBHdd"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VTyGUI
{
public:
    double acxEsmOHSiGH;

    VTyGUI();
    void npdTa(int jGRJyoiLIOSDZ, string scDUvHrT, int pMiteVTYEPj, int dPlPC, bool qLvkBODmcvjDmp);
protected:
    double RbhlCRLfYYNyHIZH;
    string BlQKimB;
    int dnyeIZgXiTtch;
    bool CTKvFwxixQAnb;
    double yhQCwUKoftWQ;

private:
    int yBHSV;

    bool SMjKZFRpzERwr(string ecsfcleTwHd);
    bool dRAyxLhu(string zxjmppMEElkeR);
    string XFfeSpVqhsbkSxM(int XUCHksQPgBQyEpvV, int nvjWFBBboCXim, bool tqeiUYdUyf, int RcxiF, bool AXvwF);
    string LgzLgxTzDlWABQ(string ShiANgR, bool PbSFMBOfSip, string UYNkeZjvkjbyuFAm);
};

void VTyGUI::npdTa(int jGRJyoiLIOSDZ, string scDUvHrT, int pMiteVTYEPj, int dPlPC, bool qLvkBODmcvjDmp)
{
    string XvpQrQZ = string("nTVwAkR");
    string CnBnZpAq = string("tixGaSzw");

    if (pMiteVTYEPj >= 163047832) {
        for (int iIThUN = 1853265748; iIThUN > 0; iIThUN--) {
            dPlPC *= jGRJyoiLIOSDZ;
            scDUvHrT += XvpQrQZ;
            CnBnZpAq = CnBnZpAq;
        }
    }
}

bool VTyGUI::SMjKZFRpzERwr(string ecsfcleTwHd)
{
    double ZenRogKad = 239100.48512991474;
    string ArSnjOxIWJ = string("sOkNdVnZYUrCLwLGWmaojVVcJlyNqCJNPpMuyWxScsUQOOrapeMxkEraOgjMOlbFYtiPctFwyVCQoVEzxCOeRYBgI");
    int mskJUJsEqil = -901399390;

    for (int nUDgY = 883714254; nUDgY > 0; nUDgY--) {
        ArSnjOxIWJ += ArSnjOxIWJ;
        ArSnjOxIWJ = ArSnjOxIWJ;
        ecsfcleTwHd += ArSnjOxIWJ;
    }

    return true;
}

bool VTyGUI::dRAyxLhu(string zxjmppMEElkeR)
{
    string HcjfBSnZ = string("vKnbplqkwqFquffRQmCwuxmwXsCUWByzqfELiRyLIzfPLHYRbKsnPOcmHpIkyTJtAapOBewgqbHymYTAZedhywfTMyYSYLBCHLTYCQfncpiCsbhCGrBIpKZSflzCf");
    int tiAymrjH = -1864778377;
    double pfbbUHYVWotdWCQ = -332289.3063834067;
    string sMMlNXGM = string("TwEJvCyrgwDUGRlIItqHGPlStewNLMnjGMsIpEoCLIwacFWGAVwnBipPVrYqrfuWVUWelvpZmizSDtklDykHhlSUBtYEDsQDGNvtJYezhFEfBrgywhNZROwUtElWGPWIs");
    double dEomOlxr = 838097.6007274389;
    string bwJzjm = string("gJqMVhzIUpewHBkBQSgjliRrHzkHZiDRoKERbiroNHscszzVfcvVTOfefRBAYSmCXmqukyMoCBlqNWKhGnnhmvmTMStBsyKquGMlHKQEvOJAiexymoqsNgAcOkQOLcejCmQLXZNXgdpcAkwWneAsaBMctaDmCLl");
    bool vQIGjDkx = false;

    for (int OZWSHRvxefEqoll = 2130280790; OZWSHRvxefEqoll > 0; OZWSHRvxefEqoll--) {
        continue;
    }

    for (int MBWzBoN = 1808286376; MBWzBoN > 0; MBWzBoN--) {
        bwJzjm += HcjfBSnZ;
        sMMlNXGM += sMMlNXGM;
        dEomOlxr -= pfbbUHYVWotdWCQ;
        bwJzjm += bwJzjm;
        pfbbUHYVWotdWCQ *= dEomOlxr;
    }

    return vQIGjDkx;
}

string VTyGUI::XFfeSpVqhsbkSxM(int XUCHksQPgBQyEpvV, int nvjWFBBboCXim, bool tqeiUYdUyf, int RcxiF, bool AXvwF)
{
    string wgVCaRJQgXx = string("bVHZOkHsIdcgbtvDVqZsijNoDeMEzkaOGkSEboyHstIOOHc");
    int uvbIgpqscU = -523441717;
    double YapaW = 597915.216546472;
    int IwRVfwjANvFUX = 1296030804;
    double oqcoFoeKxyNXy = 984837.2373584306;

    for (int CSMoxajLX = 400939711; CSMoxajLX > 0; CSMoxajLX--) {
        RcxiF += RcxiF;
    }

    return wgVCaRJQgXx;
}

string VTyGUI::LgzLgxTzDlWABQ(string ShiANgR, bool PbSFMBOfSip, string UYNkeZjvkjbyuFAm)
{
    bool OJunsBqpA = true;
    int tXRMxeAIMjnFnMS = 1904659237;
    int CAoklPoMdtzTGZU = 1586642504;
    int gkchxuQaogBGQe = -840920427;
    double rkstwcBBhmbJ = 671256.1989119111;
    string cDJRFiwnPpdijRT = string("kKXJQFUXaohDoxBDsDGIxJWlUXtOCPRmTvfB");

    for (int ideuumpqqAgafyId = 2054006283; ideuumpqqAgafyId > 0; ideuumpqqAgafyId--) {
        continue;
    }

    for (int zgrxMXqoOv = 1795617267; zgrxMXqoOv > 0; zgrxMXqoOv--) {
        cDJRFiwnPpdijRT += ShiANgR;
    }

    return cDJRFiwnPpdijRT;
}

VTyGUI::VTyGUI()
{
    this->npdTa(-53504285, string("FnpZZQCMFxZjcqGcJejBSapPwgVavrbVkdACimZyVHeGNOywUsXfSzXjaTUSCPuIUSOUfNxuxJElBrjbmLkXkiSTJoNXAesWNABYyYqrRzgwrpojHVfTHTnelykvCJHuXnJDYmJ"), 163047832, -1291033780, true);
    this->SMjKZFRpzERwr(string("ieBVkPzTJQZtBRNZqQSDnLrACcGuzCwEdQyWwJPcCHnEkRXTOznvDSOdbmYHLybZfpyyjcnXSiHjPxQSMEhpRFViBVeyBaFaGoSHReOIzxglCnMmdPxyELvLKBmzRjXzOsHyPBYGZlumjjoIfynpazmzJasaCQvnzShSKiwf"));
    this->dRAyxLhu(string("sOPvnznUlmLzYpCHEpWBiqEtCjYeTCFcSYODVlyDATixPOofKoojqzqGxgsIfLoevjhDJcHGDaSBjwNFEHKGLSCbjmiwbtkabGTMNdGdRhJruKVZYJalKKzdlMRyOZVLUOvlsVZApenMcVMajoaIHkTMPgsApNwiEdoeZeTzldfSTFojkiuiQEwzsPqmaSLXihSnccVVjuIszKsEDqdMnoWegYrxrarUejvkiMqlEwOMRxDPsAOGwmaWJ"));
    this->XFfeSpVqhsbkSxM(-160844207, -1061157863, false, -2038779358, false);
    this->LgzLgxTzDlWABQ(string("YCDBlLtMViQtkHXXpmTyREoJkBEYrenaEWvNQgHdgbbpzstWJQUdcXFSQhkaJvcXpYxLGpwykLANqdvcVvYEgJMpgkdjv"), false, string("mvvJyJLrRjqUDxzXZvcOXGdXJsBgdzjOvYnlZWRBbOvVOgoIkZFGldVrVZGACSWBgrczprBhZFJJANagkLYnoLzWpySlIbrZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dSzlZYkrFpe
{
public:
    bool ymHjZAKMPBtgyw;

    dSzlZYkrFpe();
    double vdmsKCU();
    bool bzEFEn(string YZOENeCDpaqvQ, bool hxIMNIDUqJzT, bool dmyFEWPtOoGMqoG, double DfIDNonFrxUTEjxi);
    double UNIFn(bool gGXGHffzWcmB, string ArdihY, bool LubKRftVqdNahmna, double TzQoyBaZFZAuffHb);
    string qtjmNgzYvGStvaC(int DpNwEMMgi);
    int OtLGnngtsdE(bool XEykHSlieE, string akSeIBe, string hKaVgvociRACOoG);
    double aKSkFDvdlrUpo(bool KzYtQVxsbKrsGza, bool drRYNhShoWYHB, int GKHLJQImmCL);
    string uGfhfhifhyqOhUD(double MOppXIrNZGk, string Jcwuw, string rmLWEvPqL, double OLeFo, int NyhXdMl);
    string fUijyZuN();
protected:
    string yfSfKbNsqxnr;
    bool OVMIrBTz;
    bool BlJsVhByYwZ;
    string wFHQPxuJDQMVo;
    bool swLcMa;
    bool NNFPfn;

    bool yZWpUoXax(int WFllSBTyQVbmF, double WkasTPOrZ, int wLPUGRHSNmbT);
    double RzUVkoqdGr(double ZTwtjSsHsVbrhHRw);
    bool AKUPAb(double dkvIXIVP, int OMjrTpCSWpjqYXD, bool OhXDOJPuhUEDl, bool YiYBUtFEZBl, double RapFrPYy);
private:
    double yFRCU;
    string iMfvTUrLmP;
    bool AmczR;
    string bTrbHJiI;
    int MOoVAaGuYEijY;

    double YxVKblyok(double gYWobA, string VKBSQhg, string gjqCbVpWndpx, int GbXIsVhTgLRqU, int EMUBhMyq);
    int pYZUsDDkv(string BqSEaujOL);
    int UAdpHxAMaPiZiunv();
};

double dSzlZYkrFpe::vdmsKCU()
{
    string ibPtEvIg = string("NBUWnmpQPriymgXNEwUPgCvwIAuZoVACyiEaQGgtsatTQpIONDIqWzAKSzPILBhJOCqFTWQsbtvnspkLhEvoencrTJbZIlVPpXcVPikpWqTzyRaSdjioLiglJRxQGFKroebEEtcWzoDtVHVyGoUzrQXUxdcsmVwmtzyCbktUccHUmjrRkMhtppQxhvHxgucawkSWFPEQaMUtxTCLGEzqZpZVLDxdSxmna");
    string hsaMNDGyeaCEAH = string("yyahZNagAPPuAZQTujKJEqxCfbgfiYITcDjTQBWRmHAVGoWzJZOIljUwlHdewFUcxNaYztfoiRwHfTcKphPVMxOYFJvywPeTdviLAeIVRYyHTmyIZLSeJwjvGUlUxLtKcBfmcbmjokkMTBuwPEqaMSWhznYIayZnAhUgAfuhXgBbfFwDGpSQfQcXeVVaR");
    int yEebzYkhNTmDLeI = -114783246;
    double VApAST = -74033.50722788433;
    bool OEEzUSGD = true;
    bool rkPNW = false;
    string ptSGatmYRLunAW = string("UIzYCNFDDAYUStoRJNlyXeQPkPePyxtMdIHLXjLsdpagHtlXExcAmiIVRivltdhuumgyaFVDSJqkKyrvVDlzHNZZxtoHJgtpzUEhdTVVtsALGmbvhdrFJRFNnkKVTgSBczfvqfHuxEZFvdrJvUEtWaEuKThcYVcuhtJnbHRTpPcZLWFzSqoGsVMGfIzaJZCdeJwbBJaEV");
    double DkSVGf = -338149.68950726115;
    int YLRSwRSLKiaZQ = 1235022933;

    for (int ZlWIklpWR = 1750943580; ZlWIklpWR > 0; ZlWIklpWR--) {
        yEebzYkhNTmDLeI += YLRSwRSLKiaZQ;
    }

    for (int SKwuBnQsuSQr = 461969793; SKwuBnQsuSQr > 0; SKwuBnQsuSQr--) {
        hsaMNDGyeaCEAH += hsaMNDGyeaCEAH;
        ibPtEvIg = ptSGatmYRLunAW;
    }

    for (int ceVFdsBROxZxnocj = 618420346; ceVFdsBROxZxnocj > 0; ceVFdsBROxZxnocj--) {
        VApAST /= VApAST;
    }

    for (int XJXpCiL = 2051769578; XJXpCiL > 0; XJXpCiL--) {
        continue;
    }

    for (int iUVTJjouDRhf = 1225666345; iUVTJjouDRhf > 0; iUVTJjouDRhf--) {
        continue;
    }

    for (int VJBztyL = 127811702; VJBztyL > 0; VJBztyL--) {
        continue;
    }

    return DkSVGf;
}

bool dSzlZYkrFpe::bzEFEn(string YZOENeCDpaqvQ, bool hxIMNIDUqJzT, bool dmyFEWPtOoGMqoG, double DfIDNonFrxUTEjxi)
{
    double EWstUtCwUgiKyAUb = -231488.9632503025;
    double HBLHtcQVutsxlQaU = 367604.7619495045;
    double tFdyLEqUu = 936037.0681376267;

    if (HBLHtcQVutsxlQaU > -231488.9632503025) {
        for (int cPIqNqrLGEYNQ = 1564347832; cPIqNqrLGEYNQ > 0; cPIqNqrLGEYNQ--) {
            DfIDNonFrxUTEjxi -= DfIDNonFrxUTEjxi;
            tFdyLEqUu += DfIDNonFrxUTEjxi;
        }
    }

    if (dmyFEWPtOoGMqoG != true) {
        for (int RNGaVml = 25199231; RNGaVml > 0; RNGaVml--) {
            EWstUtCwUgiKyAUb = HBLHtcQVutsxlQaU;
            HBLHtcQVutsxlQaU *= HBLHtcQVutsxlQaU;
            dmyFEWPtOoGMqoG = dmyFEWPtOoGMqoG;
            EWstUtCwUgiKyAUb += HBLHtcQVutsxlQaU;
        }
    }

    for (int jJAvhhxtbEhnCei = 452026439; jJAvhhxtbEhnCei > 0; jJAvhhxtbEhnCei--) {
        DfIDNonFrxUTEjxi = tFdyLEqUu;
        HBLHtcQVutsxlQaU -= DfIDNonFrxUTEjxi;
        tFdyLEqUu = EWstUtCwUgiKyAUb;
    }

    return dmyFEWPtOoGMqoG;
}

double dSzlZYkrFpe::UNIFn(bool gGXGHffzWcmB, string ArdihY, bool LubKRftVqdNahmna, double TzQoyBaZFZAuffHb)
{
    double uXYtJcfkxTBiTPqg = 458290.87678836664;
    string cSsXmXAMyZXqVxm = string("ncwCxDwshwDIpmPOceZEFrkVmOyNTKyTyGGpWWTAEuDkjQSdHJQBq");
    string gGSiyKe = string("YQgBejDDHNmHznTiBxkHBNkpOMsMFjWQcRyYsEHFksJQjfSzPQKOcMAxxHsjDQiGMemnhOczPPNJVALFMeSnpdCJLPSvOSBLBQqIsVgCNYjntzunvlvbWMIjHyPagFBpfaqYDcnzELQYiObHHMGEChlfPPIqjlYhiUJJQXyNOSutqDoYfTsvYB");
    double sdAyqXGgpdMj = 3363.5350193613194;
    double gmgbjfxT = 633520.6229809079;

    if (sdAyqXGgpdMj == 458290.87678836664) {
        for (int ngZcuZnNcrma = 1454308713; ngZcuZnNcrma > 0; ngZcuZnNcrma--) {
            sdAyqXGgpdMj *= TzQoyBaZFZAuffHb;
            TzQoyBaZFZAuffHb *= uXYtJcfkxTBiTPqg;
            sdAyqXGgpdMj *= uXYtJcfkxTBiTPqg;
            gmgbjfxT = TzQoyBaZFZAuffHb;
        }
    }

    if (uXYtJcfkxTBiTPqg < 780854.0457643404) {
        for (int oXlmXdIopTlmBezx = 732767294; oXlmXdIopTlmBezx > 0; oXlmXdIopTlmBezx--) {
            sdAyqXGgpdMj *= TzQoyBaZFZAuffHb;
        }
    }

    return gmgbjfxT;
}

string dSzlZYkrFpe::qtjmNgzYvGStvaC(int DpNwEMMgi)
{
    int TaSqJCXAq = -714560659;
    string ZTRotAoTCMhkRCyY = string("USQpDfHCgSAdhbJKRKjRxlqQdIWRMexZTCmxWmgUreTYZNrBsJYjFuNIcRZfqPNpvqwEeDbklTPGWCcWNKhzssDeWmLJgCwBSjFIkOqotbiRDlDgopVWMTcsWxUWCEYmZLhEpQzRQenDlwvkbkLTqkQffwAhyrAmeSzNKDMLcZctjvyCVGqGOKFBv");
    double LHYbyzvLJa = 345621.12600929505;
    string RPeyvqQZhCRr = string("mxrGowejDfudHECpNHOTYKfiETOzAgEeoKbQVCdfWuDyKgVqtGKJZYomaTQklWFTLleLZVGqQrigJfEdGccpkGfXnJFja");
    double KxEEDOG = -31528.16454964683;
    int PJbwdisDm = -697659596;
    string pIcqWaNtj = string("YuiObHLrxdNCruKVnMYxrhUlQtaFKTNANMOtHDvdXABWqlRIJNMvEGWgqwfHbFFcKhNFLycyrPibFfnCeexrRQnmATCizmxIMaHyuxemzctDlAWKTNlBeJLtbayMBwXIlmewnSzwgfINblBCwtxHasMZLxQYhAEAxLxYvFRcJwezdeNPzbALCEXGYKhtfVlIYIDigSqAlLYkBkUzgYB");
    double JzaPjuGVBppRSYB = 537069.5442309954;
    int onVvgzsyFihDhD = 1429008176;
    int uMxAKDSi = -280482474;

    if (onVvgzsyFihDhD != -705299107) {
        for (int PrveArWYt = 1770512329; PrveArWYt > 0; PrveArWYt--) {
            KxEEDOG = JzaPjuGVBppRSYB;
        }
    }

    for (int kPpmbNRpSy = 74526105; kPpmbNRpSy > 0; kPpmbNRpSy--) {
        TaSqJCXAq = onVvgzsyFihDhD;
        onVvgzsyFihDhD += uMxAKDSi;
    }

    for (int nOPGWCuXXQvwhTK = 577090878; nOPGWCuXXQvwhTK > 0; nOPGWCuXXQvwhTK--) {
        KxEEDOG *= JzaPjuGVBppRSYB;
    }

    for (int NEkvZcitX = 1994686874; NEkvZcitX > 0; NEkvZcitX--) {
        TaSqJCXAq /= DpNwEMMgi;
    }

    for (int wXqDLUBJgdICI = 1640994662; wXqDLUBJgdICI > 0; wXqDLUBJgdICI--) {
        pIcqWaNtj += RPeyvqQZhCRr;
        TaSqJCXAq *= DpNwEMMgi;
        pIcqWaNtj += pIcqWaNtj;
    }

    for (int NiuVLBekYHznvGa = 1328317560; NiuVLBekYHznvGa > 0; NiuVLBekYHznvGa--) {
        TaSqJCXAq += DpNwEMMgi;
        onVvgzsyFihDhD += TaSqJCXAq;
        uMxAKDSi *= DpNwEMMgi;
    }

    for (int efbOLchV = 27465144; efbOLchV > 0; efbOLchV--) {
        onVvgzsyFihDhD += onVvgzsyFihDhD;
        PJbwdisDm += PJbwdisDm;
        ZTRotAoTCMhkRCyY = ZTRotAoTCMhkRCyY;
    }

    return pIcqWaNtj;
}

int dSzlZYkrFpe::OtLGnngtsdE(bool XEykHSlieE, string akSeIBe, string hKaVgvociRACOoG)
{
    bool AsSLfOuTeej = true;
    string GpXQRPnp = string("zvEZfGjZWjWCsJsICnVjKhceepHbpZfhbfRCiPJXcvSKiljla");

    if (GpXQRPnp >= string("zvEZfGjZWjWCsJsICnVjKhceepHbpZfhbfRCiPJXcvSKiljla")) {
        for (int thQjKBckwNWZviy = 1448382095; thQjKBckwNWZviy > 0; thQjKBckwNWZviy--) {
            hKaVgvociRACOoG = GpXQRPnp;
            XEykHSlieE = XEykHSlieE;
        }
    }

    if (hKaVgvociRACOoG < string("krrPhWGJcjxKWGcJgnBXiznjoMoERsmHvoZTdnhrsrIGEsueNyuufJLfLGYThLcUjZVXafcNlDFYqxNiccpPAXAHyNtAsesspZGmWuhVVJwbVNHOKJtpCCBRTSrHAzPhOwbsjliNrMQaYgHmrYTSiJZLjcHVeNXTyoqOqSLyeRnRBzweFaZWEumGoOdDLNvAmLazafxARNxRcynLVzXkterfiZyvFIYywWEELhYIjJTgbmhe")) {
        for (int dtYHuuoHLfHlWlLL = 796320613; dtYHuuoHLfHlWlLL > 0; dtYHuuoHLfHlWlLL--) {
            GpXQRPnp += GpXQRPnp;
            hKaVgvociRACOoG = akSeIBe;
            GpXQRPnp += akSeIBe;
        }
    }

    return -1594786826;
}

double dSzlZYkrFpe::aKSkFDvdlrUpo(bool KzYtQVxsbKrsGza, bool drRYNhShoWYHB, int GKHLJQImmCL)
{
    int WfYdbG = -514365282;
    double ccWnzdXWHEaJTFZt = -503403.04690279835;
    string pqOzXqrDA = string("xRUenmMidvuRGXHnGsvftBGzgJyJbEUspZjArNHHG");
    double xhNLyH = -798893.4347121322;
    bool uYwPen = true;
    double JZyncOLa = -623390.2943430402;

    if (pqOzXqrDA > string("xRUenmMidvuRGXHnGsvftBGzgJyJbEUspZjArNHHG")) {
        for (int ZqcwrhT = 2130377355; ZqcwrhT > 0; ZqcwrhT--) {
            WfYdbG = GKHLJQImmCL;
        }
    }

    for (int VfWbgMZUA = 719687506; VfWbgMZUA > 0; VfWbgMZUA--) {
        continue;
    }

    for (int JYuLbt = 360006811; JYuLbt > 0; JYuLbt--) {
        JZyncOLa += xhNLyH;
        WfYdbG *= WfYdbG;
    }

    if (uYwPen != false) {
        for (int hLTpwBB = 1766614244; hLTpwBB > 0; hLTpwBB--) {
            WfYdbG += WfYdbG;
        }
    }

    return JZyncOLa;
}

string dSzlZYkrFpe::uGfhfhifhyqOhUD(double MOppXIrNZGk, string Jcwuw, string rmLWEvPqL, double OLeFo, int NyhXdMl)
{
    int LmKqbuiQbGBbxj = -1283557575;

    for (int iryEoGpqzYsakOZN = 2023025812; iryEoGpqzYsakOZN > 0; iryEoGpqzYsakOZN--) {
        OLeFo *= MOppXIrNZGk;
    }

    for (int suRrccXhgj = 381416232; suRrccXhgj > 0; suRrccXhgj--) {
        Jcwuw = Jcwuw;
        NyhXdMl += LmKqbuiQbGBbxj;
        NyhXdMl = LmKqbuiQbGBbxj;
    }

    for (int HcqlXdBjX = 1269745439; HcqlXdBjX > 0; HcqlXdBjX--) {
        rmLWEvPqL += rmLWEvPqL;
        LmKqbuiQbGBbxj = NyhXdMl;
    }

    for (int qZhwVbMmDwgtsI = 1907920541; qZhwVbMmDwgtsI > 0; qZhwVbMmDwgtsI--) {
        continue;
    }

    return rmLWEvPqL;
}

string dSzlZYkrFpe::fUijyZuN()
{
    bool xIvfkNFfAc = false;
    double DVNHAa = 52822.854561982735;
    double ptSEpoXebOJvqVYG = 714180.6656065944;
    string abqnwiswAZTYBnF = string("DSDuKdxWkLIkLlZmaBrcYZnvvFijinBnYGjsZklGyGbRUQPxmGLpLuHTVfjjhalGwqadupOwIzdXBiyBzCmzIenDSoXfsymOSLZRPamqAIqaPneGkxOKQCIyKfRxFPhIHltfbYvvMqWrYqXoJjTDcjvhycFOq");
    int oMHaCKa = 1202038549;
    bool FeWzbElwOd = true;
    int pkHhsT = 674869245;
    double GYvkFUoKd = 818975.3422026115;
    string ZDqbvcJqG = string("vWNnwaDsgcuarIwwUsmOYRpIEwiSwbdQSZFLUQ");

    for (int akTTQGmVeTIXe = 240224746; akTTQGmVeTIXe > 0; akTTQGmVeTIXe--) {
        continue;
    }

    for (int uvwbHCjsbCBvs = 1249091427; uvwbHCjsbCBvs > 0; uvwbHCjsbCBvs--) {
        FeWzbElwOd = ! xIvfkNFfAc;
        DVNHAa -= GYvkFUoKd;
    }

    for (int uIhfBPSBSrcgnC = 715271446; uIhfBPSBSrcgnC > 0; uIhfBPSBSrcgnC--) {
        continue;
    }

    for (int DrOuNiPM = 1827523720; DrOuNiPM > 0; DrOuNiPM--) {
        DVNHAa /= GYvkFUoKd;
        oMHaCKa += pkHhsT;
        ZDqbvcJqG = ZDqbvcJqG;
    }

    return ZDqbvcJqG;
}

bool dSzlZYkrFpe::yZWpUoXax(int WFllSBTyQVbmF, double WkasTPOrZ, int wLPUGRHSNmbT)
{
    string RrSpmBzUdNgAtn = string("xKZZkOYkMfLLXmfISYXHtgMdatZwoJngscFoJKbdpPsmiRoUTZYnnFQQxCKwwSXCBcQRvgjrDXGMsjxYGUwmCEdZaJPpqJyFBChrz");
    double AceEsguUtUy = -645228.8526463807;

    for (int dDOzdLlDDiiohJi = 1802188138; dDOzdLlDDiiohJi > 0; dDOzdLlDDiiohJi--) {
        AceEsguUtUy += AceEsguUtUy;
        wLPUGRHSNmbT /= wLPUGRHSNmbT;
        WkasTPOrZ = AceEsguUtUy;
    }

    return false;
}

double dSzlZYkrFpe::RzUVkoqdGr(double ZTwtjSsHsVbrhHRw)
{
    bool WtBxPpObIHOAAtc = true;
    int jaHUii = -1603928057;
    bool DpZNxyQMJQoQ = false;
    bool ZWqmGXjmeWi = true;
    string gIJinDxyAqkcP = string("OtfepoWSrsEmpWgkczidPmuLcSeFSmVrNgYOdNwpzbLnpdMGpTWatixlaAUTmMCKEaFgHfHvLsxnzcsdjYHZMUDYZyWaJxOlAUYuqXsPZXxDUBerWaAkEniJNADpiSetpyFMefAJjcDwRTLwqrwczsrYohlhbJdzrPOAmBkqIngxOOLYTZSazlXiPuZeAMilVbLC");
    double erEbCVauCq = 43335.76833871311;
    double FcpGF = 987639.7771750193;
    bool WvlxUCeNhcSrPUYh = true;

    for (int SuJRMrxcLRQjnT = 1719293020; SuJRMrxcLRQjnT > 0; SuJRMrxcLRQjnT--) {
        erEbCVauCq -= erEbCVauCq;
    }

    if (FcpGF > 969015.6210697363) {
        for (int eAjDzZQUHLyvhzX = 1347437151; eAjDzZQUHLyvhzX > 0; eAjDzZQUHLyvhzX--) {
            DpZNxyQMJQoQ = ! DpZNxyQMJQoQ;
        }
    }

    if (jaHUii >= -1603928057) {
        for (int exOtxvvrzwcj = 1556458115; exOtxvvrzwcj > 0; exOtxvvrzwcj--) {
            ZTwtjSsHsVbrhHRw = erEbCVauCq;
        }
    }

    return FcpGF;
}

bool dSzlZYkrFpe::AKUPAb(double dkvIXIVP, int OMjrTpCSWpjqYXD, bool OhXDOJPuhUEDl, bool YiYBUtFEZBl, double RapFrPYy)
{
    string tsEacHn = string("WSPmcutjUrizbjlEYNHqNDeweJXLbHeAsRiMIAqXEysERRGIMMuRjFEcduhDvTXWpPnpWwrCBBkvHIVXplMyKUDFVdCcUlLhzZoPkQlCoNodHFZoYWXFLeszkxQMnWgPjmy");
    double DotYPNZRjg = -290844.18644226325;
    double LMnqroWFHR = 519859.8350587709;
    bool IXyhjiwXXy = false;
    string tSIvZTYt = string("JdgnVMtFRHKkDbfuaXukxAZPVgmtgkZJYMyqKUSbOeRmmuzhKOwnsTEtoPmUCJIDEKhKVWAdmuGw");
    int JHYqV = 630871772;
    string eyuAVFMrBkbkck = string("XaHThzHZkRqVgrYOlOBOkHakzBGXjMPMRdnYLQOvmagLZAAeADPZlrHSjtnRdTEBDEKibIPGXJTNNwRldIilApvKWKfwjxMLEHLMQEonmSBRegNfPfXsArkadLLxIdRnOrzdmJOAkXrjTFVbHpubcSliYWzyDIdWxajniXHjsRTliDrSeEvOepfvKEfofOrvVfwBnyeEwBkLpOmbvnJYxMIJn");
    double NWbriYyHjbre = -314324.94479352;

    for (int khafFhUgMKIS = 1129394719; khafFhUgMKIS > 0; khafFhUgMKIS--) {
        NWbriYyHjbre -= RapFrPYy;
    }

    if (RapFrPYy >= 519859.8350587709) {
        for (int NwBwzuHFJpCrZhYW = 185884132; NwBwzuHFJpCrZhYW > 0; NwBwzuHFJpCrZhYW--) {
            tSIvZTYt += eyuAVFMrBkbkck;
        }
    }

    if (dkvIXIVP != -879829.7270486649) {
        for (int fwvrIoivoc = 1881564410; fwvrIoivoc > 0; fwvrIoivoc--) {
            RapFrPYy /= NWbriYyHjbre;
        }
    }

    return IXyhjiwXXy;
}

double dSzlZYkrFpe::YxVKblyok(double gYWobA, string VKBSQhg, string gjqCbVpWndpx, int GbXIsVhTgLRqU, int EMUBhMyq)
{
    int oJBbLHjSYWSSyzsm = -858140489;
    bool MHsbFozDs = false;

    for (int pVWHnFVoChDmMGW = 1232145137; pVWHnFVoChDmMGW > 0; pVWHnFVoChDmMGW--) {
        oJBbLHjSYWSSyzsm = EMUBhMyq;
    }

    return gYWobA;
}

int dSzlZYkrFpe::pYZUsDDkv(string BqSEaujOL)
{
    int xOgzIfOBjpCNk = -124027484;
    int zmSpdbhIyGUIwNe = -316748658;
    double igfsr = 38730.12499745281;
    bool ZDtSwYuTR = true;
    bool sPRSbBDetcv = false;

    return zmSpdbhIyGUIwNe;
}

int dSzlZYkrFpe::UAdpHxAMaPiZiunv()
{
    double UFYIdjUYPyxvUY = 1017565.1432124833;
    bool AAPeL = true;
    string nLyHIgN = string("ZIxCMcphrSfPhAUedNKVXVGucwnYXXOQKqMCAPHEqYtnLVdaVqGlPjFQbQCNCZCBCRgFTEEhwgntWyqlMNgBdmSJQGIbtVdMjTKTlcOXVCzqQHnSnMHhsWSVqwQqPbjdMWQYjDhfnFHxgJxnZfVqUStmTxszEHVGhqjmufDIsVgkdYDHgMLqnvQlCMbXXFePejRPtLMebaEcKNXoZPqGqRnBXxXElYNfRpIfRyN");
    double nxeGdbUyabWQ = 842695.9691480437;
    int NpiJuIHSPCOe = 1503680441;
    bool qntPG = true;

    for (int nVhYnHWEmGBjS = 1588142006; nVhYnHWEmGBjS > 0; nVhYnHWEmGBjS--) {
        UFYIdjUYPyxvUY -= UFYIdjUYPyxvUY;
    }

    if (nxeGdbUyabWQ == 842695.9691480437) {
        for (int DNWamk = 690712192; DNWamk > 0; DNWamk--) {
            qntPG = ! AAPeL;
            nLyHIgN = nLyHIgN;
            UFYIdjUYPyxvUY *= UFYIdjUYPyxvUY;
        }
    }

    for (int fAjkwvL = 611039562; fAjkwvL > 0; fAjkwvL--) {
        continue;
    }

    if (UFYIdjUYPyxvUY >= 1017565.1432124833) {
        for (int VMRQiXs = 1801432389; VMRQiXs > 0; VMRQiXs--) {
            nxeGdbUyabWQ /= nxeGdbUyabWQ;
        }
    }

    return NpiJuIHSPCOe;
}

dSzlZYkrFpe::dSzlZYkrFpe()
{
    this->vdmsKCU();
    this->bzEFEn(string("WGyJHxsntgsuzsHTYeqbldVpdiTIajeFFGzUJtgsGxWIQAjPdWUGjYwiJwqVHvdNLJqjLYCEKvPvNEObVCZakaHqxXmGjFLvKiaFQBEagYMsRVtdycZIDtOpYMBcFFNcxFlJwQNAfLfOdmEvxoeyCZtaNnrtOu"), false, true, 413079.02624184487);
    this->UNIFn(true, string("jdCPKkaFGVbjamJjnqjgRWfsZfznzMHfxNvcsenZsuQSygPgBJIGjPtptLKUBssSTGAiouITclQxaBhsQBDlcHNoRwQEuZNzSrsqdfGyikobrBVxMrqtoQwgZMuRLsOQrJFAaRrgFmYRWJAncKdJDNfIbjajYWbgFkAQTYPOkeIbWoNJVqMGzoYHYrTdziFKBcs"), true, 780854.0457643404);
    this->qtjmNgzYvGStvaC(-705299107);
    this->OtLGnngtsdE(false, string("krrPhWGJcjxKWGcJgnBXiznjoMoERsmHvoZTdnhrsrIGEsueNyuufJLfLGYThLcUjZVXafcNlDFYqxNiccpPAXAHyNtAsesspZGmWuhVVJwbVNHOKJtpCCBRTSrHAzPhOwbsjliNrMQaYgHmrYTSiJZLjcHVeNXTyoqOqSLyeRnRBzweFaZWEumGoOdDLNvAmLazafxARNxRcynLVzXkterfiZyvFIYywWEELhYIjJTgbmhe"), string("ariOwTyfkltNTUezoddWNsdOTizqJnHBrwbuYLlgrYOotnxtxfBEpwutYoCfpTPZUvkXxdsRRVMGIrFdRHrrFMeqUINFflXPwRhUrtPNknzAnOzHzhtLSVoPWyFJQUgbfWPxVSmQeGTqCgBPOSrLeiTClkgvPKkyiOWsjcDscYYnnYjbbMlQHiriCxkJkOkujFxCcdsunrweNvbLXVuHYKYXIGPXuxwpRIdrYKYfTMtj"));
    this->aKSkFDvdlrUpo(false, true, -1242447831);
    this->uGfhfhifhyqOhUD(851010.2031111376, string("ifCMKPYZKNHtPlldvBzqJygQIjKlPupHhwPzbifEqXeRbdqcDPVhOyvRigx"), string("ccPMCLULj"), -566781.7035191512, 1892747643);
    this->fUijyZuN();
    this->yZWpUoXax(1936500959, -897475.2206727895, -556356114);
    this->RzUVkoqdGr(969015.6210697363);
    this->AKUPAb(438779.24538625224, 386702985, true, true, -879829.7270486649);
    this->YxVKblyok(-918714.6121344952, string("jmfICOpEQOYXWrCVCwSVsuuhkmACRhJhYoaDFwzzzPlZaKUHqrqAcsgJTVWhzqFaaAMbcuuCxQOVKQVooFXdZywWtHuWCZQgxGOUNROahAFgJJjpIAFOSoBmGxNEfqFCrlYYPZvdEFBMXYKsjBSLSPnxGGHFrSOAzTFXZjdTHiSqanZovESNbmK"), string("EUwyRBzYXYaMWlAKJjlxxieqrixxyPoOJmTsnOIbbsSPPvZzhMuvRivryQRGnXdlsgQSChBukaoTVNgOUUKJCZUPLVkzumtgHCyGvRcSiSvCnJvuu"), -1451047864, -646325232);
    this->pYZUsDDkv(string("ikhISxqqJGypnNpMAsSwjwIMeLpuIlbNsZpAepWUnSkGIuXrbHzOHYscyNMtxRZZUTYOfErJJkyFvllrEoVrlwGraSQptQsHDnwDLpmHchftgGWTKlLAqPtLxQOtyXBsKkOIvXfwjNFOPjGW"));
    this->UAdpHxAMaPiZiunv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ndlGO
{
public:
    int NJtDwlGplPoBCDp;
    double WlKWUjgcIUSF;
    int sclVh;
    int EWFCpSVy;
    bool zjvJcQR;

    ndlGO();
protected:
    bool WRgmRUNEhWRgNyP;
    double BIyltEyTRT;
    int gNcLuYLbxosRaHYD;
    bool qIacWf;
    bool pYuYvCM;
    double jpIexvr;

    bool cEniY(double KVGTn, bool VRmKiVMkbFFWIGwc, double DzXDQHmJCi, bool DtVYsYiLCcyS, bool XNFZguad);
    bool cuoGZcMjgU();
    bool ZWBYqarZvB();
    int ESPVOuTN(int WBmgardcRqpeotU, double FcUcALDM, int NgWSM, double pkTSkymXM);
    void BTVvbiQyNOSSOQ(int PCBTbhkPP, double lATArneYT, string vVRiBLjlGIANoRSV, bool ssXdBSstTVaKPk);
private:
    int OCazBHETZms;
    bool xuSginlIvFbpE;

    double aAKIadMosNQE(int JZnhCakJ, string jwtQPDtFLmgar, string MKlFBoAfWf, double rCEvbRG);
    string ZduDyuQSJlvuW(int AtTlLJ);
};

bool ndlGO::cEniY(double KVGTn, bool VRmKiVMkbFFWIGwc, double DzXDQHmJCi, bool DtVYsYiLCcyS, bool XNFZguad)
{
    string AWayRW = string("HHWnPqHPRjERPKbDxwpzGNGqMivtVWrrRyvEgIZOFDFwEgRVbqfFxRBudRvVRjkcjYHyDqoyIemUDZpKYXarJMefrUbQjESBEDTGcwTiBPwbcF");

    if (DzXDQHmJCi <= 670604.0561504586) {
        for (int rWsdqLFTvxVk = 1462006171; rWsdqLFTvxVk > 0; rWsdqLFTvxVk--) {
            XNFZguad = VRmKiVMkbFFWIGwc;
            KVGTn *= DzXDQHmJCi;
            XNFZguad = ! DtVYsYiLCcyS;
        }
    }

    return XNFZguad;
}

bool ndlGO::cuoGZcMjgU()
{
    double tSTZljQeV = 722416.8344611515;
    int kESLaoYERTRHcfY = 1513728808;
    int mqCAVPu = -56547539;
    bool HVUfNQrZFs = false;
    string GgqDwxO = string("VxUTuNxwHXKHJqlEsDMWXOtinWPPfdSZxXXmeklHfEtjtKMiqjcqLDWUqbMODTFqUBsGqlYtBArZeNZlirpoQJDpMSgzaUXldrKrNNLBSIiNhhyQtmFLyMtuCORRSKHhqDhEwDLheaFCbmVTiwkPIgEoprKMSVMtalT");

    for (int EbJQmKfomx = 133474182; EbJQmKfomx > 0; EbJQmKfomx--) {
        continue;
    }

    if (HVUfNQrZFs != false) {
        for (int xKyLRKCtjhKCbGqF = 1967658280; xKyLRKCtjhKCbGqF > 0; xKyLRKCtjhKCbGqF--) {
            GgqDwxO = GgqDwxO;
            GgqDwxO = GgqDwxO;
            tSTZljQeV /= tSTZljQeV;
        }
    }

    for (int BCpXfIYYM = 1674179130; BCpXfIYYM > 0; BCpXfIYYM--) {
        tSTZljQeV = tSTZljQeV;
    }

    return HVUfNQrZFs;
}

bool ndlGO::ZWBYqarZvB()
{
    bool XjnrtdFRSiFZmta = true;
    string xwOmXufKm = string("moDjxCwhQKrHtqmYyNnDmNqRCdfbxAOQxKDCOmtqP");
    double vsppJtQQKAXeq = -220145.59356910756;
    double vLGRWEru = -712268.3820192567;
    int gzVtcTtUIjTOy = -2065862986;

    for (int kPsIzt = 1475702913; kPsIzt > 0; kPsIzt--) {
        continue;
    }

    if (XjnrtdFRSiFZmta == true) {
        for (int KKVtHInBwOb = 1431484669; KKVtHInBwOb > 0; KKVtHInBwOb--) {
            vsppJtQQKAXeq = vsppJtQQKAXeq;
            vLGRWEru -= vsppJtQQKAXeq;
            xwOmXufKm = xwOmXufKm;
        }
    }

    if (vLGRWEru == -712268.3820192567) {
        for (int JqrbSNlVsuKUJJ = 481682295; JqrbSNlVsuKUJJ > 0; JqrbSNlVsuKUJJ--) {
            xwOmXufKm += xwOmXufKm;
            xwOmXufKm += xwOmXufKm;
            XjnrtdFRSiFZmta = XjnrtdFRSiFZmta;
            xwOmXufKm += xwOmXufKm;
        }
    }

    return XjnrtdFRSiFZmta;
}

int ndlGO::ESPVOuTN(int WBmgardcRqpeotU, double FcUcALDM, int NgWSM, double pkTSkymXM)
{
    int AJVXBPxwK = 1797183212;
    string XrWwyRFOjWtJKzwN = string("zuSARlHaWGH");
    double qvBLKTXtqLz = 657340.3832258802;
    string TDLZfgzM = string("KLF");
    bool ZvWbEvth = true;
    int XfsXI = 2115075544;
    string nBksBEuai = string("tuOwFPxWQywrrsYwpBbHTrSYrzPIfmzoolKNzyGGAIRhPYlZShruQtztOhTQ");
    bool OEXloATCgrDqK = true;
    int JphaXGyB = 1503871916;

    for (int MVmyjRgefoIvIBW = 1843284316; MVmyjRgefoIvIBW > 0; MVmyjRgefoIvIBW--) {
        continue;
    }

    for (int qmGpDWYAq = 476046689; qmGpDWYAq > 0; qmGpDWYAq--) {
        AJVXBPxwK += AJVXBPxwK;
    }

    for (int mDFWYtwIFdS = 1641417214; mDFWYtwIFdS > 0; mDFWYtwIFdS--) {
        AJVXBPxwK /= AJVXBPxwK;
        nBksBEuai += TDLZfgzM;
    }

    for (int JjkHjXOzvigGCGeE = 797750261; JjkHjXOzvigGCGeE > 0; JjkHjXOzvigGCGeE--) {
        FcUcALDM -= pkTSkymXM;
        AJVXBPxwK += AJVXBPxwK;
    }

    for (int yrYPgCLVvhci = 1481674830; yrYPgCLVvhci > 0; yrYPgCLVvhci--) {
        continue;
    }

    for (int lMZWPs = 1795836463; lMZWPs > 0; lMZWPs--) {
        continue;
    }

    if (nBksBEuai > string("KLF")) {
        for (int YowCYzU = 299863478; YowCYzU > 0; YowCYzU--) {
            ZvWbEvth = OEXloATCgrDqK;
            WBmgardcRqpeotU /= NgWSM;
            XfsXI -= AJVXBPxwK;
            XfsXI /= AJVXBPxwK;
            NgWSM /= WBmgardcRqpeotU;
        }
    }

    return JphaXGyB;
}

void ndlGO::BTVvbiQyNOSSOQ(int PCBTbhkPP, double lATArneYT, string vVRiBLjlGIANoRSV, bool ssXdBSstTVaKPk)
{
    int mfNdweztZhPJApR = 321512352;
    int BWlRszFiDSTkqjrw = 459697259;
    double GpXxWj = -218316.15057232525;
    int rQHGaHH = 1784245184;
    double YoJGHbSOwceu = 142396.7984980039;
    int fjUum = 1056060089;
    double wbIIyG = 308492.6793204043;
    string HQBlK = string("NakkDJrcZRybINhehUOuVoaySdTorFcTIoddSkgDIVtUowijXHkwnMYDrIWNsNQRFxAPhAznNNNvkbUUdKQmUIfvksxnKbvuWjqYYzupKyaRFhglBvvlniCDaFzoByiTVYWzFKexTAiboZyeuqMQvvPmVVsxkPuhbbdLLUAjIVUQxzbmFEVrVXwTSJGmFGqIsrSqlzlPfuprmZgxVKafflBElsBP");
    int UJvud = -1486793483;
}

double ndlGO::aAKIadMosNQE(int JZnhCakJ, string jwtQPDtFLmgar, string MKlFBoAfWf, double rCEvbRG)
{
    int MLMtjWv = 1407096071;

    for (int HLGJpLbtHSVmKL = 2035432928; HLGJpLbtHSVmKL > 0; HLGJpLbtHSVmKL--) {
        MKlFBoAfWf += MKlFBoAfWf;
        jwtQPDtFLmgar = jwtQPDtFLmgar;
    }

    for (int mAmrLUFDkGLdd = 1002781373; mAmrLUFDkGLdd > 0; mAmrLUFDkGLdd--) {
        continue;
    }

    for (int GbSqcr = 1837559412; GbSqcr > 0; GbSqcr--) {
        continue;
    }

    for (int XMBUFNOfqYcfX = 691929209; XMBUFNOfqYcfX > 0; XMBUFNOfqYcfX--) {
        rCEvbRG -= rCEvbRG;
    }

    return rCEvbRG;
}

string ndlGO::ZduDyuQSJlvuW(int AtTlLJ)
{
    string yOgbRhwHbKMyL = string("VdzqqCUizSylBUtHtgCKOzoeDakPoy");
    bool dtbHcDVCbGHNNJ = true;
    bool tppVkxIaB = true;
    bool pGNtYmNxvri = false;
    string HmqjaBnW = string("XTGDiqvbYVKYEMcFkxLrsezOdVWVDNoM");
    string RPoOtiJOsvLjxfvm = string("VLjQCsAVcuFYIgIsvzmOe");
    double rnmvbTwZpV = -653535.2966968458;

    for (int yPFOuLxdyME = 748368666; yPFOuLxdyME > 0; yPFOuLxdyME--) {
        HmqjaBnW += yOgbRhwHbKMyL;
    }

    if (tppVkxIaB == true) {
        for (int yYPnVy = 461135499; yYPnVy > 0; yYPnVy--) {
            tppVkxIaB = tppVkxIaB;
            pGNtYmNxvri = ! tppVkxIaB;
            RPoOtiJOsvLjxfvm = yOgbRhwHbKMyL;
        }
    }

    for (int pwNrJdsxhNcx = 2093846894; pwNrJdsxhNcx > 0; pwNrJdsxhNcx--) {
        RPoOtiJOsvLjxfvm += RPoOtiJOsvLjxfvm;
        pGNtYmNxvri = ! dtbHcDVCbGHNNJ;
        dtbHcDVCbGHNNJ = pGNtYmNxvri;
    }

    for (int FToGYAheDjlJGr = 1627858; FToGYAheDjlJGr > 0; FToGYAheDjlJGr--) {
        HmqjaBnW = HmqjaBnW;
        dtbHcDVCbGHNNJ = ! dtbHcDVCbGHNNJ;
    }

    for (int QZqtI = 1686307104; QZqtI > 0; QZqtI--) {
        RPoOtiJOsvLjxfvm += yOgbRhwHbKMyL;
    }

    return RPoOtiJOsvLjxfvm;
}

ndlGO::ndlGO()
{
    this->cEniY(587502.803526189, true, 670604.0561504586, true, false);
    this->cuoGZcMjgU();
    this->ZWBYqarZvB();
    this->ESPVOuTN(-1106778680, -419259.71974570217, 807251258, 703115.8779178016);
    this->BTVvbiQyNOSSOQ(1207490731, -652606.1301313415, string("yDESBeKvLoObgnsgPfgJkMdiyaiONnxPkubTGBHcODVFhENraEqJeJrVbRYHHQJkqAGMRtdmhwiFcNPshqpaYlUukQfVVkzwrsQirVurxnQSERmymDoijZIFLoKTUUcQibVUtUIoicgFTgsbNjLulwNHLFcFglynZFLoDJUdfBWIxyfXePvVItrvKhmiQKsJgjIqNNybeDKvAMTtYNryjkaF"), false);
    this->aAKIadMosNQE(323833715, string("cOQSiFNdKdkVlJZVpVNaCdfYVJifMQoYYPJNFqXPkbcBIBxxwKKEWaGbIbwlhMpphaBCHfdKjXcuxeSVYVIjADSBOCpJlkPnkKgFBoWJyMATTOKxZGgkzDdplEOQWbLPWLaVWKhGcMfaiojIgEojnWeYBnScMczUEkxeLsahATuCMgFDZByIsvWOhZTGJAMYhCndthxrwjiiAOqbsQHzJZUZrpOCavjTPMNdWxb"), string("KhJvibBMVkpXTePEHUipZXFQAQCvxPNXJhidupWsxRBByNCtkjkgroTeJIZkpMvCyGeoklKeZWSGoMptQUJpfaNsPlPXQKKrIQFFXQcQBrDYyCwJRybLHtjCACyzdOQNtSoKqDbMJYoASjP"), 65671.36092851721);
    this->ZduDyuQSJlvuW(-333055636);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mUEgrPZVIkl
{
public:
    int WIHfdWf;
    string ncDHCQzkMDD;
    string KGSHyiAvh;
    bool BqClIlsaB;
    string EBYIf;
    int lrIVhGxUfAeyoh;

    mUEgrPZVIkl();
    double aAmTMMiMjRom(bool QQgkHphAqgqENU, double ggpXJ, bool naeklVd, double ZeiFJntfBJeatv);
protected:
    int LyjpOcAPENqfZne;
    bool DPGGpVC;
    int QtmqIODctS;

    bool WKkTWSo();
    void SQDYAefwxgWDIlj(string TyoPpL, double MrgUiato);
private:
    double XSARtbYhZm;
    string ptGxsSoJSItL;
    int nNGZGqh;
    int aOEdXZLE;
    bool GiwWMzqtzjCdkd;

    void gfSZCEbO();
    int tgaMgdY(int TwQSttdZQbjmi, double BNvjNNc, bool DBkEwHJsZJwnbA, string xeFHLaIvkwlGIEW);
    string qSQWkZVnUtJy(bool oiXKmzezuOye, string zPErXCC, double WIFzY, double kcPHrCKPdGXmlK);
    int xVFmjayxbNdY(bool pubpMUC, int ZnhgHkp, double mtjeOwQg, int QbpIotCp, bool JbOVxpkLK);
    int SeiXzKHzwcTrMiKi(string OATygLpmPMscUOz, bool akTzbLNDxTufAB, double ayCEqHQ);
    double QqvxyGWPZYUAAnj(int gIagBMptEvO, double FWQXGplWvp, double InCNojMRzHcs);
    void kmxPAINeu();
};

double mUEgrPZVIkl::aAmTMMiMjRom(bool QQgkHphAqgqENU, double ggpXJ, bool naeklVd, double ZeiFJntfBJeatv)
{
    bool weCgqdHvcjXiFS = false;
    bool PONBvrEtIKBdbE = true;
    string MnmgtYXbyu = string("zNFMIsGYAVyqHUxRWLAXrQONbUyhdMwBfmoJpzECcgeaGrCuXOpPOrZYZIxTULppztoSzkZYmsAeixWldbMyRdSpZSIDGuwhtqFdKarctxBglEPRuwyHtWPdjGQQlHwHkxFouvrvOXnckgUwaqjVfYFtDlYVPVQXghbWZIzuJLAXKJbdDMDVwBtXQynpefwSaLaoJOztlLZJRkADFgTyJysvGgMkNfPmypdgfXLsOKFSuCimQTMS");
    double ajUKcSIRxT = 752154.0791815487;
    int FqaQnpY = -2064213576;

    if (PONBvrEtIKBdbE == false) {
        for (int wbrevhOcXqMk = 558648301; wbrevhOcXqMk > 0; wbrevhOcXqMk--) {
            continue;
        }
    }

    return ajUKcSIRxT;
}

bool mUEgrPZVIkl::WKkTWSo()
{
    double OLXWBO = 215576.4612408773;
    int tLUtYjAEojy = 2046769542;
    bool bBQMop = false;
    int snXTZKG = 1118809698;
    string VaYuBmrWWV = string("qUwpuDbPwyGDefqZpXqYmOXKALLtIRNhFaiWNdMmlyQIYKNmSwlwGVLmDMiRrmmIIHldkVZvWmANllUMFSqXdeDNLaGDoJKcZsBdknyALnPTGglEAiKadvztdDdULKoxtYvIxoAFtlQPJXViRuLdZONrfZpIdpkOpGdjKzoUxnuFuIekvSpxVwTQjIQVapaNsAjcwCdbiJkmOILryemJhrxcDbDoUvCNFOatcSYDLyDtXEgzgTiUBN");

    return bBQMop;
}

void mUEgrPZVIkl::SQDYAefwxgWDIlj(string TyoPpL, double MrgUiato)
{
    int hBosoO = 1913949240;
    int QsGlXTuF = -772175028;
    string KZpynsWLXdu = string("NvkMDeAPNDAEjskrDiSiTZUiUzRFSmanCoPGFpFmJLUTMYHmnOEZYMuGUYwmeETMZBQYIwywbdmFGnjZDDzXOfjtwCYcSyexGabRCCmUycqxXUmRGfvPCGfAkfdtUbZeLpaFZBijgSoQCiFJRzvXlyMSkrCEozoLHssyxwWzRBalNPaduhdvkUzMgPyyisQCoyOhLtdhkoqDflumUsfytzsPXLncfKPEzJGLVqsHBqGUpPJlyTiQmIurcly");
    bool kkOgkaHuG = false;
    bool fNRtV = true;
    bool JiByFW = false;
    double FIufnuFPESveKqq = 407581.1850779863;
    bool xklyRZ = false;

    for (int hIVAsX = 1040352721; hIVAsX > 0; hIVAsX--) {
        JiByFW = ! fNRtV;
        FIufnuFPESveKqq += MrgUiato;
        JiByFW = ! xklyRZ;
    }

    for (int ESMDfTi = 2032618699; ESMDfTi > 0; ESMDfTi--) {
        kkOgkaHuG = xklyRZ;
    }

    for (int IYtCRmQhHzK = 758368329; IYtCRmQhHzK > 0; IYtCRmQhHzK--) {
        QsGlXTuF = hBosoO;
        fNRtV = kkOgkaHuG;
        FIufnuFPESveKqq /= FIufnuFPESveKqq;
        fNRtV = kkOgkaHuG;
    }
}

void mUEgrPZVIkl::gfSZCEbO()
{
    bool LjvNzZePpholKQ = false;
    string udXTsQCMoTuj = string("CBiVSmlbPeX");
    int bUlTlKr = 85630145;

    for (int aCaCvkrbpW = 1582633698; aCaCvkrbpW > 0; aCaCvkrbpW--) {
        LjvNzZePpholKQ = LjvNzZePpholKQ;
        LjvNzZePpholKQ = LjvNzZePpholKQ;
        bUlTlKr *= bUlTlKr;
    }

    for (int iKAskM = 1097483367; iKAskM > 0; iKAskM--) {
        bUlTlKr /= bUlTlKr;
        bUlTlKr /= bUlTlKr;
    }

    if (bUlTlKr != 85630145) {
        for (int LQEgya = 849013040; LQEgya > 0; LQEgya--) {
            LjvNzZePpholKQ = ! LjvNzZePpholKQ;
            udXTsQCMoTuj = udXTsQCMoTuj;
        }
    }

    for (int LkRtg = 1885554440; LkRtg > 0; LkRtg--) {
        LjvNzZePpholKQ = LjvNzZePpholKQ;
        udXTsQCMoTuj += udXTsQCMoTuj;
        bUlTlKr += bUlTlKr;
        LjvNzZePpholKQ = ! LjvNzZePpholKQ;
    }
}

int mUEgrPZVIkl::tgaMgdY(int TwQSttdZQbjmi, double BNvjNNc, bool DBkEwHJsZJwnbA, string xeFHLaIvkwlGIEW)
{
    string doHtKBnSWM = string("XmJBoCGENyhyAOCMDtoZByfqQaGdiUZJCYVEktiggQRoHRgrgsmkCeSrpXOMPKxQOHnKqYdeaMDHffhtCaGZPUiCohcCaULvvklSJBALvQGZonYNdrsCgvnEzyrlFNgLhcubEwiRPLsIaaCKVDpHMaylEBoiRkzrvargWSOLqMRdMeOdQEPLHaDGjc");
    int BnPHZuDreqoA = 2131839906;
    bool jUSyMH = false;
    string pDUlWarJuBef = string("ipcPIeMZKskdxqwkEaYTyNppntgzfEPKBKwRTlFaXmQuzclvZzweCystvKXQVBFyXIKAWqDGftskslzlXXxc");
    bool vKzFSeTMlA = true;
    string sbYTTOWiMB = string("BffzmPXrbfQJheYpZeuNluonLtvmozwWDKbZYvTvwdaHKShDJZxKThdWYGdmmRXfuOPdQXHvkSoVOljeusTJRAxIDYgkQMTGTZnpAunyQAWGuNXwfbdzwpPFOOHjqpJSApoSrHatYF");
    string wZjPSWqKjfiwPFM = string("AOuHmdszSRhJlnPuvMLphAd");
    int aqforPWIi = -960420398;
    double AdLqHv = -792830.8543574377;
    int aaXGfzoeIOwqFduJ = -1787675156;

    for (int SZhPJihxHX = 1025604988; SZhPJihxHX > 0; SZhPJihxHX--) {
        BnPHZuDreqoA /= TwQSttdZQbjmi;
        xeFHLaIvkwlGIEW = wZjPSWqKjfiwPFM;
    }

    for (int rXjXfvKNPZ = 1742436095; rXjXfvKNPZ > 0; rXjXfvKNPZ--) {
        continue;
    }

    return aaXGfzoeIOwqFduJ;
}

string mUEgrPZVIkl::qSQWkZVnUtJy(bool oiXKmzezuOye, string zPErXCC, double WIFzY, double kcPHrCKPdGXmlK)
{
    string HzKxXkEVAcI = string("IsszLJcgEyuVymiisTaSkuMZfkZVEpAZNLJPIUnaSvEElTTbPqrxIvcZwTjBURIeAWuzICRAbeBDmdVlJlxeHtIWjNaaSvpDQcitXoyVM");
    string JQFLGDY = string("GiWIrAiGiwjtucEXnGZDaxWelEEEABhFUVoAeJuJZByTWRgtNQLGmHEkRhzatDRKScEMZTSKqxOvQsChuZVOYOhyDgDiTipILxWofmEdGdSKIgtEdhABVZwmsayqwPdDGqcqITwctqBGPNgEYvvRwOhggjmqGKGGfPKFLmoqVLkcqOeLirTaIhMvKXkukJsaurQyfPoXwEACLYmeKYTJ");
    string eWCMn = string("xkDMdrhpvkOsnVQUQcoutWBcespzByknKuvMXyXhzbhTALWTRZhbvOckTHitNmvbofXHsyrHkDpJUNfnAigRldeahDhmDZgQNxhZlVBiUrgrKHxsHhRyBMDMRwTQqfWjdOTmxxqCd");
    int TAZdsbtMEbVzUzTE = 631802860;
    bool qskATieUpRBaqg = true;
    int pDHsBVyWmoTxQa = 1294817968;
    int TjcIqm = -489151576;

    for (int GdNDUNqbr = 478820958; GdNDUNqbr > 0; GdNDUNqbr--) {
        zPErXCC += zPErXCC;
        TjcIqm += TjcIqm;
    }

    return eWCMn;
}

int mUEgrPZVIkl::xVFmjayxbNdY(bool pubpMUC, int ZnhgHkp, double mtjeOwQg, int QbpIotCp, bool JbOVxpkLK)
{
    bool KDRvPr = false;
    string KJiREHNL = string("AYhVd");
    double vWccKVSJVz = 102456.58612088316;

    for (int ETEuN = 287406788; ETEuN > 0; ETEuN--) {
        continue;
    }

    return QbpIotCp;
}

int mUEgrPZVIkl::SeiXzKHzwcTrMiKi(string OATygLpmPMscUOz, bool akTzbLNDxTufAB, double ayCEqHQ)
{
    bool YHhmegI = true;
    double BzQWJOMuIOagE = 682299.4958443728;
    double yAxkgmdoRVF = 910224.1256827569;
    string IeyzOOFprwnFTiwX = string("LhQRlkyRVfvLJJFZjPWbBErVYcpUZOkWFyfYrpzHJYHXVccFmnYHdOWXOTKlzPbpIWlxwYwHzqBHIZLpsclBNPJhXKujhHIoemTDdhjuOSRwDvOCSwhxkaqdSIuWDWwRKaHYyvBCYmUBayZJgqtkcSLCbSUqgJSviVGIAJoIxZhHFsCZLbDkZfbGAVDvZz");

    for (int MFzzc = 1270518385; MFzzc > 0; MFzzc--) {
        YHhmegI = akTzbLNDxTufAB;
        YHhmegI = ! akTzbLNDxTufAB;
        BzQWJOMuIOagE /= yAxkgmdoRVF;
        OATygLpmPMscUOz += OATygLpmPMscUOz;
    }

    if (yAxkgmdoRVF <= 682299.4958443728) {
        for (int tlVMcNJ = 429801503; tlVMcNJ > 0; tlVMcNJ--) {
            yAxkgmdoRVF = ayCEqHQ;
            IeyzOOFprwnFTiwX += IeyzOOFprwnFTiwX;
            ayCEqHQ *= BzQWJOMuIOagE;
        }
    }

    return -562817144;
}

double mUEgrPZVIkl::QqvxyGWPZYUAAnj(int gIagBMptEvO, double FWQXGplWvp, double InCNojMRzHcs)
{
    bool aYghgVRzWlVcoPni = true;
    double ULOINfQ = 623244.8464115477;
    string yZbiGM = string("OKpDNtHIrCZUSvOLSnERnepFporvoaMXaTkmREvrQCOBIburFjCHFKZDuJwsdWLVprLjbNhuegeeVhhmPPCIQNWRORXWJAKncBFijxnCWCkHoGfQNffZPoqiJZYQQnwylnmrtGZkYHPUSdPcptcaOJozPDjTmnDnuWpeJrqiccbCLgcZZabViTAqaWPgYiffOHgg");
    bool ELCxgwwvjqJniDqx = false;
    bool SKTRCbkFGexUm = true;
    string gEyISUvTZMSTNZ = string("qNVyHAcRweRsvprhRpOeGXGeSiInCynQUincfopmDKaoClbXJWEtLcyIhKiyHZQxkniKtqAxqHbWeBifZELIEJXlGvnjqvFtqdBjgeqDyeXCCiFhZYfMLPuDRCTsjOkOhUcOaijcfelGfEerrYMuQu");
    double eaXEDoIImC = -231927.3342849256;
    int bmgzagYbdzyvGhe = -1749313515;

    for (int WrYYOfM = 1084488158; WrYYOfM > 0; WrYYOfM--) {
        ELCxgwwvjqJniDqx = ! SKTRCbkFGexUm;
        ELCxgwwvjqJniDqx = SKTRCbkFGexUm;
    }

    for (int mGIxNaQEDDzvbIK = 2067823381; mGIxNaQEDDzvbIK > 0; mGIxNaQEDDzvbIK--) {
        ELCxgwwvjqJniDqx = ! ELCxgwwvjqJniDqx;
        gEyISUvTZMSTNZ = gEyISUvTZMSTNZ;
        gIagBMptEvO += bmgzagYbdzyvGhe;
        InCNojMRzHcs /= ULOINfQ;
    }

    return eaXEDoIImC;
}

void mUEgrPZVIkl::kmxPAINeu()
{
    double BMhNWMDISYD = 439202.4400587499;
    string oIwckVQrR = string("XCOPLPLaqDJUsAqyktldth");
    string SRmXWhxOlMvFFu = string("sqpfFMcYmQIgakfjwIOkiKdUqWfkEAEttqIkestSVafSJllLjEJXlOncpIxwykhGirmngzEweYHMFtpJbqUBUlnyFeiTNhsZLNWVUnEEfRtKsswlmMyXDzhRYDGjiDREYLimKswKZKZhOxnDppPAWfPAfTevnwHQCSfFDCeoSPpBFKycCbdFdALUTTlTrEvTmsnwpnNfCDQTvgXPKanZdKLNNjYiFyDdhsdkWWCdXyJcS");
    bool MmZoKfBuYtf = true;
    int UuwLQwyAgKtz = 1242355114;
    double DBnNxHEUFEbBPBzP = -252430.66580814702;
    int HNjLpqFNzZdPbphF = 1976404690;
    string HqHQRpfWS = string("wcqqoUMFgUKXnOZerOkFtxoToijDhmDggEqbTmVoHFWlljXlnlbLKvPMEoXlGxjThPVXQynK");

    for (int rvASww = 1407352032; rvASww > 0; rvASww--) {
        continue;
    }

    for (int rnkcJgljLd = 896852156; rnkcJgljLd > 0; rnkcJgljLd--) {
        continue;
    }

    for (int uNuMZiSyWj = 239912664; uNuMZiSyWj > 0; uNuMZiSyWj--) {
        HqHQRpfWS += HqHQRpfWS;
    }
}

mUEgrPZVIkl::mUEgrPZVIkl()
{
    this->aAmTMMiMjRom(true, 379367.340205628, false, 542351.8768990196);
    this->WKkTWSo();
    this->SQDYAefwxgWDIlj(string("UaGrxfjlEpaUWgRyljZrEJFtwPXDRQPwgqcNkpQoCHaWWuXUkxrDJQKoPbuyGqIOuxWohBYdBkxzHJrNxVubkaEWsQpmdiHtgjVIOHBTYEFCIULnsxTEtjqzGwGMnqVtnmtFTmWRoNWhBqDcmyD"), 100385.73562390803);
    this->gfSZCEbO();
    this->tgaMgdY(2108980685, -131853.45767538252, false, string("wTqtNDHLvgEZVnXKmPFqmbkbJlNLzAoOsEUTwvTvDvqlbEZqMAKkPPutxhdETmADUPJbRsfxLVZaDxlCnOgZzncTcwVRbcstmEnVgzPUjKqBEqUMtblTImPWdExkXKvusPljEQYNeUXNrITtiZwavKAkLqwnAXuvlJKsJTwnpUovaLnGUFkbmO"));
    this->qSQWkZVnUtJy(true, string("jVmjQVlVeJqGzfFYhGlNORLzmXDPqGByjVtvTXjUtGUWdfCPLsnpBCEsXtHFhGLeRmDGUqTjbDhEiKzyhndweuowYEBFJKktakVPxCBsAwaOVxEyGMHzJD"), -188449.2780525669, -543488.0617200646);
    this->xVFmjayxbNdY(true, -1056130582, 136058.0228349261, -285616514, false);
    this->SeiXzKHzwcTrMiKi(string("hZSZtCVnBHOsOyxbGdruvTfQObqXomuQrADOGZeJmWTIWCatyLlQCPMllMHWamvEmSNwBGnPyiVQsteNyRmBuWqBntrVsBPqVqAfKdPFbjfwzxhoJojtfOaKUCsTYKcYCHCaKChZmMQIYApICf"), true, 1005594.563220498);
    this->QqvxyGWPZYUAAnj(918883896, -824560.9801920559, -416308.93140022544);
    this->kmxPAINeu();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jBDgWoBrrIt
{
public:
    string kTlzm;
    bool GDqLwE;
    int VdLgSdqvzvnNO;
    double dCyDkwWpz;
    string uAvluTbYzNXwEghz;
    bool LSbJltGM;

    jBDgWoBrrIt();
    void aWRGa(string STTlzjk, string PnTKIVUaaikcP, double dSgsL);
    double KnCojTTjLwaS(bool kBuRCTA, double MUbYOrAk, bool QLLWgWFWhNtGwgtm, double goFVuvPcUjSCXa);
    bool FpIcHkNXTvjnM();
    double WrVzrj(int PzdLZ, string AXWMHsUendtcDUB, int cBbHutgSxPp, bool kKBaSerW);
    string bkdcvQsZoLnAP(int NYRnYDRbO);
protected:
    double eUkMtyLT;
    int SMQzalVjroVjK;
    string EvMkMg;
    int cBqwommGaXOQBxN;

private:
    double vpaZOHoAHe;
    double XWejHMtFwvbJY;
    int WbYGNLil;

    void HbgQE(bool SmjMsHjcPrxhG, string ywWqaVkrlyNhrOd, int iFELtikscGFCSSF, double guiAmwR, bool UuomloFOKaB);
    void VUPPdHpCM();
    double qYYcLhpOjrZGQynx();
    bool JzXHlgG(double mcgHyZzJGhpZG, double gSocsTByWCoGzCh);
    void mUaYpVbvEhVM(double qehAdcJrRuHW, int BfFbRjkkHzwB, double LojGXw);
    void FYvdwwOQNW(int FECBEmPNmIbTS, int dvIBK, string ytwYEbGAzfBtAzx, double qVNPWEzGRAkHP, double ntnVyNJqkYN);
    void yOVQrMR();
    double wAuHkvRIfudpJXiP(double XWcHzf);
};

void jBDgWoBrrIt::aWRGa(string STTlzjk, string PnTKIVUaaikcP, double dSgsL)
{
    double OpQivPKMWe = 571592.602518536;
    double JzdLVNoOEGdUYuE = -821709.8954540943;
    bool NCuzONMgrEEZRT = false;
    bool PtzxPlFAjDq = false;
    bool uhMcPoQ = true;
    bool gABqievqhM = true;
    double wvWJyyYuYRhYMrC = 222148.12959113673;
    string ocemR = string("cYOPujVFxSpWBWseQFOGEpjLUeLhZEDKdzFUChWEwVIjovngQfNWFUjlSAWdyUWxoMncrrRddBuepoUgHgeEUHFuMPcDnlVbgnymfRmBfdNEZcQDsMlAYWwaQueDopMFGuonvoRIOduXhAoeRKiztvfbKygHwyMkJLYU");
    int yexqu = 922199660;
    double YoMFUVMpN = -869164.0488358211;

    for (int DuNhDVDSbcF = 562463266; DuNhDVDSbcF > 0; DuNhDVDSbcF--) {
        OpQivPKMWe /= JzdLVNoOEGdUYuE;
        STTlzjk = PnTKIVUaaikcP;
    }
}

double jBDgWoBrrIt::KnCojTTjLwaS(bool kBuRCTA, double MUbYOrAk, bool QLLWgWFWhNtGwgtm, double goFVuvPcUjSCXa)
{
    int pUcSOg = 1208792210;

    for (int NTgEVs = 713401188; NTgEVs > 0; NTgEVs--) {
        continue;
    }

    return goFVuvPcUjSCXa;
}

bool jBDgWoBrrIt::FpIcHkNXTvjnM()
{
    string otxsL = string("VpgsNKPULhVOZnBgpTByLVyjEIhvYIhILQfEnSUnIHBfdlyUgKYKeLKFfnjyFdcVhTfJAXSTgVGgabkEnOlbFaH");
    int GHThTEnogd = 346242372;

    if (otxsL < string("VpgsNKPULhVOZnBgpTByLVyjEIhvYIhILQfEnSUnIHBfdlyUgKYKeLKFfnjyFdcVhTfJAXSTgVGgabkEnOlbFaH")) {
        for (int GYEsoirpRwX = 878187900; GYEsoirpRwX > 0; GYEsoirpRwX--) {
            otxsL += otxsL;
            otxsL = otxsL;
            GHThTEnogd /= GHThTEnogd;
            otxsL += otxsL;
        }
    }

    if (GHThTEnogd != 346242372) {
        for (int HUXvTBjV = 1465413551; HUXvTBjV > 0; HUXvTBjV--) {
            continue;
        }
    }

    for (int eNwmqNWXAPr = 642723281; eNwmqNWXAPr > 0; eNwmqNWXAPr--) {
        GHThTEnogd -= GHThTEnogd;
        otxsL += otxsL;
        GHThTEnogd += GHThTEnogd;
        GHThTEnogd += GHThTEnogd;
        GHThTEnogd = GHThTEnogd;
    }

    return false;
}

double jBDgWoBrrIt::WrVzrj(int PzdLZ, string AXWMHsUendtcDUB, int cBbHutgSxPp, bool kKBaSerW)
{
    double KvDTJ = 516231.4048051911;
    double CduGSqdeMHG = -971814.1083845127;
    double MGitNLwcSqWJcAuQ = 888759.6122448652;
    string JZiioHuy = string("ficyiuhBojOsggiqhOEkHPHNPsMSROYtongBEZdzxxubMHyOpqmMzskLTiZPbYYFSlETlqYXGAwgSZDtfcYhDYsDFtwMTyWZvicjttnACxRQsTCIzxjooJofISKjKLrwlXluSMPBEcqVitkJbKlun");
    string lhjngLQzvy = string("xraQ");
    bool xpZEAVXMaCgu = false;
    string FeoSYcWGVGQZ = string("GjjWVBDaSLrhyhjrmFmkcRLROBRcQpTSpLPfFsaUMZhaTTatRueAbCWxHAqLHvyrJPRxgCcSGsnCdGXdgsxJFxhpczOAIavibHKtlisTfPMuXKnYkgHuItDOUfiMXSDyIaWjjALEMHvphhYQhSdcYZtZHbSNGDncuPFiYzXbVwN");
    string kGafF = string("XubFgkguAzrZXewpNAgZpzyTwBXylikRpOeuIWlHxFPYlbwWZmFjGxjYlFFSEnPcTKIWIMBtKMsruKKJGNsnzNwzWIisMckIjKKRmNkleBhxSlSapNXmUGHyFgUFKgeGetNpGQvnuEnsnEPXVhEzIYFabKmxJZdhPWGDhpGTzYvzfCcOHAFtPvckRo");
    int QgFaUyRpTABrdU = -608070086;
    int hieYfi = -144611423;

    return MGitNLwcSqWJcAuQ;
}

string jBDgWoBrrIt::bkdcvQsZoLnAP(int NYRnYDRbO)
{
    double XaREx = 900868.9457414394;
    string KupBfjjmki = string("PgHLeWSCSmtlrsWXntkvHuCWQSUWUGHENucAEJsDmEUwErIXkTqteZglOmQrqNxGHOvaVwRKfgSbIwJXoFDTUZuNoGKGFCtvZXGMqRmUBFqfpzJOsqAgXLryyCwCxdTurQnnNgeRIUQKtONNFcislyVnSTeyWbZIBiOTXEzSrJcXLeQFJzQZcfzcBVGpVTfWyBvMqaMZmmwSqmwujFlkixZYODIfoDrMcSCUJGptnbUSFfDpN");
    string lUNUg = string("AKFOUMcrGulhUFUFFoarNjFyqPXZKEVSTFCIEEzkogvIJtycQASUGHvCvMWZnWCsBYJYgDciDPSXgHxNiraVDzqGsptmgsOsVqAAJKHsimFXxVSqbisOMMxOMyHNeXJHgeMWDPAElYJJFghJBqPnuRjP");
    int AbwvWOcCbEsgw = -2027670475;
    bool jpdTeGEMcAfvh = false;
    bool arghjaM = true;
    double obrXITl = 919685.8386364102;
    bool jPdphnGelnePfQhD = false;
    double YZrrxkJ = -754796.8562594547;

    for (int bFKywYvE = 1531035163; bFKywYvE > 0; bFKywYvE--) {
        AbwvWOcCbEsgw *= AbwvWOcCbEsgw;
    }

    return lUNUg;
}

void jBDgWoBrrIt::HbgQE(bool SmjMsHjcPrxhG, string ywWqaVkrlyNhrOd, int iFELtikscGFCSSF, double guiAmwR, bool UuomloFOKaB)
{
    double FldkrajbujCx = -543183.5241162041;
    bool ZMZVJhVBjTt = false;
    string EScwVGd = string("CitcHmTKDreNCsIhUispSqEuxXjqEzblWSYLGEAforHFRtinPuutbYuVRhFvIx");

    if (iFELtikscGFCSSF < -437992012) {
        for (int XQYCnUdJQp = 1287763894; XQYCnUdJQp > 0; XQYCnUdJQp--) {
            continue;
        }
    }

    for (int SFyxLT = 1934126497; SFyxLT > 0; SFyxLT--) {
        ywWqaVkrlyNhrOd += EScwVGd;
        EScwVGd += EScwVGd;
    }
}

void jBDgWoBrrIt::VUPPdHpCM()
{
    bool LonbgJbzMuRY = false;
    double CZggEGUxDfhup = 164373.0741053449;
    int hYhbCmVnTfhHDox = -1923907895;
    string AEwkMdRMQTSQJIg = string("HcthhCIOOXevLsPVIEkRAIgZtbyMMoDFgNHVsLQojkEWBuGDfFlLDETicEmSdlvwYXMvVAk");
    int QtxnezIcqrzG = 339040435;
    double GtCPouYjKIvohfi = 717984.8147382447;

    for (int dRRiORfhwgVrOhnE = 929086295; dRRiORfhwgVrOhnE > 0; dRRiORfhwgVrOhnE--) {
        continue;
    }
}

double jBDgWoBrrIt::qYYcLhpOjrZGQynx()
{
    int FTjGsP = 373710378;
    double vjQfTeLRXxOxR = -555423.7742723883;
    bool WCleXEbHLcqSmo = true;
    double LoZILPBOSwJoDBq = 152608.2156295632;
    bool TjEwK = true;
    bool IKrUFV = false;
    string LXDCDWMnRQY = string("FWYKbQsnpTrsTnquFClbRBFTPXgyhvCxkgDIuhSsiOgMmM");
    bool luwXtGMyef = false;
    bool jGgZqXKphHjn = true;
    int uTkREG = -151257117;

    for (int bKILMajVSiND = 1240265525; bKILMajVSiND > 0; bKILMajVSiND--) {
        WCleXEbHLcqSmo = ! luwXtGMyef;
        LoZILPBOSwJoDBq -= vjQfTeLRXxOxR;
        LoZILPBOSwJoDBq *= LoZILPBOSwJoDBq;
    }

    return LoZILPBOSwJoDBq;
}

bool jBDgWoBrrIt::JzXHlgG(double mcgHyZzJGhpZG, double gSocsTByWCoGzCh)
{
    bool iAsfbMOF = true;
    string svwOmvtrBkISE = string("yJQhcidvdQrOocwoTIVsDUTGWliMPFVVgFecgSOLmFmlXLuXszJqgHAjEQlFAnyqsrHITGfeJHEAqiNQSegPjIrBzqONOJCWyaGcmgdDEEabRKmDBlazQtampGxHXgTdpbwcsongjDKkJSuVA");
    int gyFeecCDUaoM = 30471837;
    double PMoMkdLF = 147920.2199152641;

    if (gSocsTByWCoGzCh > -909637.4011840083) {
        for (int LIFnxaUQc = 1119620193; LIFnxaUQc > 0; LIFnxaUQc--) {
            mcgHyZzJGhpZG = gSocsTByWCoGzCh;
        }
    }

    return iAsfbMOF;
}

void jBDgWoBrrIt::mUaYpVbvEhVM(double qehAdcJrRuHW, int BfFbRjkkHzwB, double LojGXw)
{
    string CiLRQ = string("FPXJAbehpOXSbaPNXvZSekFknkIvrJqNEBpARgLzWpYLautkHBbcCUylUCKIflaLweQkhGiKkycqrkcMKXINfLTXTPRnzJIDvNFijOYWfxuPrqBMuwpAFFIJRxxLInjxbDwWtnqvkMzLVTpNeEFlQcjehjOPcfNhC");
    bool LLCqFJZmTiqpWas = false;
    bool fFnuW = true;
    bool XDYmqsjPeAnsZ = true;

    for (int oVlAQfV = 1822133308; oVlAQfV > 0; oVlAQfV--) {
        LojGXw += qehAdcJrRuHW;
    }

    for (int SEoFeW = 1957619800; SEoFeW > 0; SEoFeW--) {
        fFnuW = LLCqFJZmTiqpWas;
        XDYmqsjPeAnsZ = XDYmqsjPeAnsZ;
    }

    for (int wedkXvTGU = 2069706462; wedkXvTGU > 0; wedkXvTGU--) {
        LLCqFJZmTiqpWas = LLCqFJZmTiqpWas;
        LojGXw /= qehAdcJrRuHW;
        LLCqFJZmTiqpWas = fFnuW;
        fFnuW = ! fFnuW;
        qehAdcJrRuHW *= qehAdcJrRuHW;
    }
}

void jBDgWoBrrIt::FYvdwwOQNW(int FECBEmPNmIbTS, int dvIBK, string ytwYEbGAzfBtAzx, double qVNPWEzGRAkHP, double ntnVyNJqkYN)
{
    int RPMxGTMERqZ = 541606409;
    bool VeETeHDIm = true;
    double FnxfYARltiHEC = 917544.5153652336;
    bool mnRIoTvKgtkITRd = false;
    double WDRFISPHrrrcmX = 652974.125455546;
    bool rylcMOnTW = false;
    int CwgzeYxfGqHsivfI = -1537241750;
    int ehdbYWTuthOT = -2091672014;
}

void jBDgWoBrrIt::yOVQrMR()
{
    string VXIXCyoxXorCAgnR = string("VY");
    double aPMJe = 682867.9007479763;
    int xNMSDi = 344385560;
    double CtnGrXNdav = -778775.7615144111;
    int czTMfzTbraY = 1499438783;
    double GFeCQqWnf = 776137.6051741361;
    int BSYdkQp = -1256639938;
    double PANrsnMsCr = -97233.10483521629;
    int ohpvfI = 133457468;

    if (VXIXCyoxXorCAgnR == string("VY")) {
        for (int ZVgly = 1454092841; ZVgly > 0; ZVgly--) {
            czTMfzTbraY = xNMSDi;
            PANrsnMsCr += PANrsnMsCr;
            czTMfzTbraY *= BSYdkQp;
        }
    }

    if (xNMSDi >= 344385560) {
        for (int QcGelOiPytguJaO = 305341167; QcGelOiPytguJaO > 0; QcGelOiPytguJaO--) {
            ohpvfI -= czTMfzTbraY;
            BSYdkQp /= czTMfzTbraY;
            aPMJe -= PANrsnMsCr;
        }
    }

    for (int fTqGe = 437052411; fTqGe > 0; fTqGe--) {
        ohpvfI += ohpvfI;
        xNMSDi /= ohpvfI;
        aPMJe *= PANrsnMsCr;
        PANrsnMsCr /= aPMJe;
        aPMJe = aPMJe;
        ohpvfI *= BSYdkQp;
    }
}

double jBDgWoBrrIt::wAuHkvRIfudpJXiP(double XWcHzf)
{
    bool mdWqMeXLklAfuDn = true;

    if (XWcHzf == -1041825.9089639261) {
        for (int aFGGNkaYDMLXRiz = 1349643313; aFGGNkaYDMLXRiz > 0; aFGGNkaYDMLXRiz--) {
            XWcHzf /= XWcHzf;
            XWcHzf += XWcHzf;
            mdWqMeXLklAfuDn = ! mdWqMeXLklAfuDn;
            XWcHzf -= XWcHzf;
            mdWqMeXLklAfuDn = ! mdWqMeXLklAfuDn;
        }
    }

    for (int qTtqfV = 275160215; qTtqfV > 0; qTtqfV--) {
        mdWqMeXLklAfuDn = ! mdWqMeXLklAfuDn;
    }

    if (mdWqMeXLklAfuDn != true) {
        for (int DrFmU = 1889257130; DrFmU > 0; DrFmU--) {
            mdWqMeXLklAfuDn = mdWqMeXLklAfuDn;
            XWcHzf += XWcHzf;
        }
    }

    for (int UTVQwvJX = 1686455716; UTVQwvJX > 0; UTVQwvJX--) {
        mdWqMeXLklAfuDn = ! mdWqMeXLklAfuDn;
        mdWqMeXLklAfuDn = ! mdWqMeXLklAfuDn;
        mdWqMeXLklAfuDn = mdWqMeXLklAfuDn;
        mdWqMeXLklAfuDn = ! mdWqMeXLklAfuDn;
    }

    if (XWcHzf == -1041825.9089639261) {
        for (int LQLUROpyiHrTsv = 221562898; LQLUROpyiHrTsv > 0; LQLUROpyiHrTsv--) {
            continue;
        }
    }

    return XWcHzf;
}

jBDgWoBrrIt::jBDgWoBrrIt()
{
    this->aWRGa(string("PhLNiQTaHQrKyBbvIbVMWzyXNUsAztFtrkHmIBqjoidTmLcjHxQjnwPlwqMRTqLlDxrjMtoLNbQbGducjNsgdWOPrPaTnldWYqIXxlLYzYSyblVTQIFQKeGEIWlatCUgBuITaVsfEHsdZkVVPKJDYVicAVEwvglikRzIfkbCJQcmpDtVqGnYzwfVEhiRILakgsDdgWi"), string("lAbkNTKOhRSSKGfIHBAPBsxwgBfSXRhxYJXHUETFNWHuLgVokcFKQQafsWGrRqMioRbNQepANMINpOULAgYYgpcalWTtJATwjHVMCxFIdlIHGVCMWxxuReSxIVDltQPBtmLbBDRAePOf"), -567019.0489943122);
    this->KnCojTTjLwaS(false, 1001313.5862181673, true, -257774.84109986507);
    this->FpIcHkNXTvjnM();
    this->WrVzrj(-41795468, string("ygNwLtpVJuRPlejzMoTazmrIcdwlcobEaTJFvaxEDzdBlcHokETvGmeFWiSenahnsaDJXNKJPlnmWwnSGCBGPMzJjdzwtlvgTzzJPneDtsDizznrwnZTmfpZKhOSSs"), 1619902543, true);
    this->bkdcvQsZoLnAP(354846071);
    this->HbgQE(false, string("brQUivkZctSmyPNTZtAsqUryepjQlrSL"), -437992012, 23860.640150405132, true);
    this->VUPPdHpCM();
    this->qYYcLhpOjrZGQynx();
    this->JzXHlgG(-752782.9636994727, -909637.4011840083);
    this->mUaYpVbvEhVM(348059.233522153, -30313220, 1047259.5776012983);
    this->FYvdwwOQNW(-718884657, -195825803, string("JMRYnfLRXvnNSovcmpZKaPAbsjMfYwKLmBZzSxSYaqUCxUlsRuLjNfEvPNywZLxsblHQuBifnwhruohVAVPjORflWmIZMRakWDZYLFWLQpWXyNLvaPCemSUsCKgXZdnYRfDfEpdljIzielCUKukOPVZ"), -713386.2734957134, -790407.7064380933);
    this->yOVQrMR();
    this->wAuHkvRIfudpJXiP(-1041825.9089639261);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qPjFm
{
public:
    double PqPToKpYOiKbgO;
    string kvfqrV;
    string uAlVhryHCg;

    qPjFm();
    int jzFrZvhNhfBiGa(double woquEl, double SYTakBjDCOr, bool VSRcXGsq);
protected:
    double PDPHGra;
    double ppEPnVM;
    int UrkWHrsVkTLUv;
    string tHFlc;

    string nRDRmXUpbLDYJkip(string UJqewzFtJQj, bool KUDyVkJLEk, string gKZQpUpN);
    int UJKTUCsQxfeo(bool QdPfBhnpAuV, double EcnvE, double BwagVuip);
    int YOKrfWqzDuYfy(bool DYMbrtUHAMgHKQhi, string TYYSfAIDpMcGwhLT, bool VXlNSchR, string riYCRFxTThnLJVgv);
    int qHcRqTaDwSGVNPf(int ZRPAPm, int YOMqNAdImfYcuH, bool DTONpf);
    string hbGMm(int PpRqBYR, bool Ypbbo, string hLEJYUgreUOSoq, int ULhTOIm);
    bool zAVLGzDmXqxpC(double iOsGJ, string voMfEqzepcyHB);
    int DAjbYfCw(string mMXyQHtdtCBz, string TsumD, bool mooNxerJD, int buIyztBJ);
    int ePjIalor(string YcVdpByJhVmPJ, bool OrLPOht, int eEMLZgHmEvcv);
private:
    string DygqAyVqN;
    bool lhqikab;

    bool qypZAfTLtIJfyt(int YZlNgIoqEHY, int MKvXKrfntGX);
    int ffXKo(double uvbWRgDeJOy, int hcIEDWOLdkOJ, int GKUhYf, string RvmFTqSRYOEaou, string XjTHczu);
    bool jHLozKOFMlZIYcto(string SXSHslzitBT, bool AlIRBtj, int PETRlRgpOBhVkC);
};

int qPjFm::jzFrZvhNhfBiGa(double woquEl, double SYTakBjDCOr, bool VSRcXGsq)
{
    bool IAZVVPLC = false;
    int VhEKgizNtSpSzMfq = 969888957;

    return VhEKgizNtSpSzMfq;
}

string qPjFm::nRDRmXUpbLDYJkip(string UJqewzFtJQj, bool KUDyVkJLEk, string gKZQpUpN)
{
    string DOqDkTaOX = string("cOvuMMPqALHuXcOFvGxOzkdjAFshMaTFBHBcnWFIoTHoqbubQFmRnwMAIbWDFXGFJehPrWYKLlUeHlGHtKYeHCcdVKxuwiYEbVKroHghtAdWkTdpzNdcHZxrYMWRUHTaQZdCcHZWtuuJXzLSXnAeTaHccgXHlahyGzojkdasalJ");
    int uiPkEpMUtXdXppC = -268178102;
    bool zXZtEMHroYMUTSu = true;
    double gGDnO = -858426.1217495158;
    int xmyLfc = -486548732;

    if (uiPkEpMUtXdXppC < -268178102) {
        for (int YpwfowwQ = 1255153848; YpwfowwQ > 0; YpwfowwQ--) {
            xmyLfc -= xmyLfc;
            zXZtEMHroYMUTSu = ! KUDyVkJLEk;
        }
    }

    for (int NruIXgKndP = 350530511; NruIXgKndP > 0; NruIXgKndP--) {
        xmyLfc /= xmyLfc;
        UJqewzFtJQj += UJqewzFtJQj;
        uiPkEpMUtXdXppC += uiPkEpMUtXdXppC;
        zXZtEMHroYMUTSu = KUDyVkJLEk;
    }

    for (int MvRKHA = 1765196534; MvRKHA > 0; MvRKHA--) {
        zXZtEMHroYMUTSu = KUDyVkJLEk;
        gKZQpUpN += gKZQpUpN;
    }

    for (int ozJHDnIHDCajTwMH = 1800744790; ozJHDnIHDCajTwMH > 0; ozJHDnIHDCajTwMH--) {
        gKZQpUpN += gKZQpUpN;
        gKZQpUpN = UJqewzFtJQj;
    }

    for (int AUduiAHEXSxte = 847631759; AUduiAHEXSxte > 0; AUduiAHEXSxte--) {
        gGDnO -= gGDnO;
    }

    return DOqDkTaOX;
}

int qPjFm::UJKTUCsQxfeo(bool QdPfBhnpAuV, double EcnvE, double BwagVuip)
{
    double lXiiBxrXc = 382958.4988459443;
    double PfyBV = -698065.2388377667;
    string WHRlpPTfhqaDDeOk = string("EzNFeDICCBtSJQTJGOzlzFxnBVi");
    string lnHQQqMI = string("pbahostlT");

    if (BwagVuip < 382958.4988459443) {
        for (int chThrjzCQb = 1624563817; chThrjzCQb > 0; chThrjzCQb--) {
            BwagVuip /= lXiiBxrXc;
            lnHQQqMI += lnHQQqMI;
            BwagVuip /= lXiiBxrXc;
            EcnvE += lXiiBxrXc;
        }
    }

    if (lXiiBxrXc > -698065.2388377667) {
        for (int QaTGE = 288459374; QaTGE > 0; QaTGE--) {
            continue;
        }
    }

    for (int fYPJqN = 2033552931; fYPJqN > 0; fYPJqN--) {
        WHRlpPTfhqaDDeOk += WHRlpPTfhqaDDeOk;
    }

    for (int MjEsUVqDfv = 1277051876; MjEsUVqDfv > 0; MjEsUVqDfv--) {
        PfyBV = BwagVuip;
        lnHQQqMI = lnHQQqMI;
        PfyBV = PfyBV;
        PfyBV -= BwagVuip;
        BwagVuip += lXiiBxrXc;
    }

    return -95554651;
}

int qPjFm::YOKrfWqzDuYfy(bool DYMbrtUHAMgHKQhi, string TYYSfAIDpMcGwhLT, bool VXlNSchR, string riYCRFxTThnLJVgv)
{
    bool hGJQgJ = false;
    double xVjyEkoxxiiAmt = 271111.80782654206;
    bool UsyYUML = true;
    string dnbTHnGNnGRqO = string("VctQenltpYNufErZvlnxDk");

    if (VXlNSchR == true) {
        for (int tRSgBKWmKkS = 1812492294; tRSgBKWmKkS > 0; tRSgBKWmKkS--) {
            continue;
        }
    }

    for (int hiaDKRPA = 2049457592; hiaDKRPA > 0; hiaDKRPA--) {
        hGJQgJ = ! UsyYUML;
        UsyYUML = ! hGJQgJ;
        VXlNSchR = ! UsyYUML;
        TYYSfAIDpMcGwhLT = riYCRFxTThnLJVgv;
    }

    if (riYCRFxTThnLJVgv < string("VctQenltpYNufErZvlnxDk")) {
        for (int lINFq = 1745585206; lINFq > 0; lINFq--) {
            UsyYUML = hGJQgJ;
            DYMbrtUHAMgHKQhi = ! VXlNSchR;
            UsyYUML = ! VXlNSchR;
            dnbTHnGNnGRqO += riYCRFxTThnLJVgv;
        }
    }

    if (UsyYUML == true) {
        for (int cAZVBhezpqLC = 1944977083; cAZVBhezpqLC > 0; cAZVBhezpqLC--) {
            UsyYUML = VXlNSchR;
            DYMbrtUHAMgHKQhi = ! DYMbrtUHAMgHKQhi;
        }
    }

    for (int soQUGCWXu = 296459341; soQUGCWXu > 0; soQUGCWXu--) {
        xVjyEkoxxiiAmt += xVjyEkoxxiiAmt;
        UsyYUML = VXlNSchR;
    }

    for (int pikwigSmqvFAyKFt = 860036457; pikwigSmqvFAyKFt > 0; pikwigSmqvFAyKFt--) {
        dnbTHnGNnGRqO = TYYSfAIDpMcGwhLT;
        VXlNSchR = VXlNSchR;
    }

    if (VXlNSchR != true) {
        for (int acssSON = 906180537; acssSON > 0; acssSON--) {
            TYYSfAIDpMcGwhLT = riYCRFxTThnLJVgv;
            VXlNSchR = DYMbrtUHAMgHKQhi;
        }
    }

    return 1474525126;
}

int qPjFm::qHcRqTaDwSGVNPf(int ZRPAPm, int YOMqNAdImfYcuH, bool DTONpf)
{
    int aaqQWHKOlBDUKGpy = 280095021;
    int lNrSX = 1770658651;
    int GhQkWJvcgCbxM = -1402620868;
    int TwnvQKP = -1702570705;

    if (lNrSX == -265972897) {
        for (int HKYAQrVkxFu = 582911965; HKYAQrVkxFu > 0; HKYAQrVkxFu--) {
            TwnvQKP *= aaqQWHKOlBDUKGpy;
            YOMqNAdImfYcuH -= aaqQWHKOlBDUKGpy;
            YOMqNAdImfYcuH /= TwnvQKP;
            YOMqNAdImfYcuH /= lNrSX;
            YOMqNAdImfYcuH /= aaqQWHKOlBDUKGpy;
        }
    }

    if (YOMqNAdImfYcuH < -1402620868) {
        for (int zwXMbDjVWOOjV = 432515029; zwXMbDjVWOOjV > 0; zwXMbDjVWOOjV--) {
            lNrSX *= ZRPAPm;
            ZRPAPm *= TwnvQKP;
            GhQkWJvcgCbxM = YOMqNAdImfYcuH;
        }
    }

    for (int iCOACCVTnS = 1253405052; iCOACCVTnS > 0; iCOACCVTnS--) {
        GhQkWJvcgCbxM *= YOMqNAdImfYcuH;
        YOMqNAdImfYcuH -= YOMqNAdImfYcuH;
        GhQkWJvcgCbxM = GhQkWJvcgCbxM;
        TwnvQKP += lNrSX;
        GhQkWJvcgCbxM -= aaqQWHKOlBDUKGpy;
        GhQkWJvcgCbxM += TwnvQKP;
        ZRPAPm *= YOMqNAdImfYcuH;
    }

    if (ZRPAPm >= -2107830509) {
        for (int uPpWWdYvdcsE = 1853461076; uPpWWdYvdcsE > 0; uPpWWdYvdcsE--) {
            lNrSX += TwnvQKP;
            lNrSX += YOMqNAdImfYcuH;
            TwnvQKP = ZRPAPm;
            YOMqNAdImfYcuH /= TwnvQKP;
            TwnvQKP = ZRPAPm;
        }
    }

    return TwnvQKP;
}

string qPjFm::hbGMm(int PpRqBYR, bool Ypbbo, string hLEJYUgreUOSoq, int ULhTOIm)
{
    double qEwUo = 667043.1230009015;
    bool ypJReK = true;
    int aTDALCy = 854087041;
    double sgcjODdRSQNcsZX = -45555.74106692338;
    string miBoeKNs = string("TeQkCAbsVbkKbxnTaSEaoBkJdnVBMYSgVnjoIRboIiMjMJODGmTSSUPDISMoSZMgKBgXbkqMGKGYGtvDSoQiKEvqxqgDwWIgNYVTtFkwKzLuSXdlploxXiUMfWAylJvHLtSgNQLbliXdPqleqMfym");
    int ubfJkVEzkoyTT = 2050228890;
    int LuRZEcKiON = -1643349236;
    double sXyefWUuDlXFF = -427840.3877114119;

    for (int dwAYieSJHuxb = 1276902033; dwAYieSJHuxb > 0; dwAYieSJHuxb--) {
        miBoeKNs = hLEJYUgreUOSoq;
    }

    if (aTDALCy >= 308121146) {
        for (int ZDJZwWatJwtWeq = 899436168; ZDJZwWatJwtWeq > 0; ZDJZwWatJwtWeq--) {
            Ypbbo = Ypbbo;
            sgcjODdRSQNcsZX += sgcjODdRSQNcsZX;
            ubfJkVEzkoyTT += aTDALCy;
            Ypbbo = ypJReK;
        }
    }

    if (sXyefWUuDlXFF != 667043.1230009015) {
        for (int JayeKDRMeRT = 841200067; JayeKDRMeRT > 0; JayeKDRMeRT--) {
            continue;
        }
    }

    return miBoeKNs;
}

bool qPjFm::zAVLGzDmXqxpC(double iOsGJ, string voMfEqzepcyHB)
{
    string vgrcmKADUgR = string("HeTgtStoiaCawfJNwhLccnRAHzqPjwHjUBkOgPjKqOJnSPEhcEvcRNfdkKDWidJjuPktIMZSirdpablSBubkXglPedclRMLmQjTURZjzbXoLlGTBeilBeoGevBsopWQpTYRGvoJBBECQVgwuSeCuVdbmXLxRfETvnxcCVkpxawlpNufzIPtToIXMalROBVuOnFBFJziRFZfjieKQTZIPVMLlmeEfUkZrdqguVmlGxP");
    double RICLko = -554438.363175765;

    for (int HKIQaksGZYvO = 1462927059; HKIQaksGZYvO > 0; HKIQaksGZYvO--) {
        RICLko = iOsGJ;
        RICLko /= iOsGJ;
    }

    for (int QFFhQpNbl = 1189817433; QFFhQpNbl > 0; QFFhQpNbl--) {
        vgrcmKADUgR += vgrcmKADUgR;
        RICLko /= iOsGJ;
        RICLko /= RICLko;
        RICLko += RICLko;
        vgrcmKADUgR += voMfEqzepcyHB;
        vgrcmKADUgR += vgrcmKADUgR;
    }

    for (int GgWek = 113774545; GgWek > 0; GgWek--) {
        vgrcmKADUgR = voMfEqzepcyHB;
        voMfEqzepcyHB = voMfEqzepcyHB;
        iOsGJ /= iOsGJ;
        RICLko = RICLko;
    }

    if (RICLko > -554438.363175765) {
        for (int nOIJgZbc = 1893881237; nOIJgZbc > 0; nOIJgZbc--) {
            voMfEqzepcyHB = voMfEqzepcyHB;
            voMfEqzepcyHB += vgrcmKADUgR;
        }
    }

    return false;
}

int qPjFm::DAjbYfCw(string mMXyQHtdtCBz, string TsumD, bool mooNxerJD, int buIyztBJ)
{
    string RJViOmzX = string("pnylIwDDxjfREYLSCIHQYpjBnUlZzLhNoutCBJyjaukviBZNvztLNaDGHEfktagGn");
    int FFjlLqPDGLLr = -2067834558;
    double cKRoiaMFMuXUG = -387369.41420477955;
    bool cevBc = true;
    int LBdVvxKMZ = 527994505;
    double nkBBBkieUah = -774639.129989715;
    bool cSwPPSMTLjyi = true;
    int zGwySwJQVIFTOPc = -987431843;

    if (mMXyQHtdtCBz >= string("pnylIwDDxjfREYLSCIHQYpjBnUlZzLhNoutCBJyjaukviBZNvztLNaDGHEfktagGn")) {
        for (int AUBaldQVoAXOJQ = 2084191134; AUBaldQVoAXOJQ > 0; AUBaldQVoAXOJQ--) {
            continue;
        }
    }

    for (int DBmDlukmNDVro = 618780724; DBmDlukmNDVro > 0; DBmDlukmNDVro--) {
        continue;
    }

    return zGwySwJQVIFTOPc;
}

int qPjFm::ePjIalor(string YcVdpByJhVmPJ, bool OrLPOht, int eEMLZgHmEvcv)
{
    bool WnqaKF = true;
    bool maPgGYmrmId = false;
    string INPZsT = string("UZJGvzKQdRLVEtbqtzUSzbtkphQhNCGFPelGXoxfnXxeScSvfCqAwmrFaKpuGFHctlfNQLqYqZgXgxkBDMgYeVErSgEmewsTsntMZRpipvmTXianUTwpmTYJlUowoPhoOJGmbmQYmLdWxLajxRfPAOSObMCUWkjIc");
    double cqaaJGWHXN = 1024147.8031520796;
    string CIsVGjLPyYPGRK = string("cdxHPNIvHpcjCURuEJNKmYbrcSQpDSAlJlORZWVTwQXAMWmrKbxUTwxYAeDzLauNkwWQjsamiBIPWbhpzlFgIaDJsbQmbJxQDFUqcIApFBUzrfRLboyNOTbJozdcZkAcqhwAkSUdfKKZlQpPQgXdDHhlUyITPJOBmwpTAogumZKktReExBiQWsSkkrWgOCJxcVeLKwcgKykHBuIWlGidVtBwFfEu");
    int SHwqgQQiPqEjOr = 224968717;
    string QylmZuyIdnF = string("zbhyDfQCgnmGASVKvYwwsJXuRyAgykBxxIBCQAMnbnGTQVBjjIRPAOOwICXRafzNXAHnrvhkvOASJPVdkZwjnokIdcAqyrZAUutPDTrRN");
    double mydKURbBTFs = -552868.7250523838;
    string RUaDfrKJYWAEcZa = string("qFtutCKuGplYayWfteSGacwBqGAHZmnjgILOYJmBTRfTDeMjXrxqXoMTdrgRznPwWSlLZFsTsjrzCYZHBZpFSROOixxoxqqTiIaUjGhRWSRatVYrrNvBWjzAKVOMVbBuLhhTMQfTuNincYOddhv");
    bool THUiVMxVBtLgJXvD = true;

    if (OrLPOht == false) {
        for (int xoAQPRkSswBa = 364494392; xoAQPRkSswBa > 0; xoAQPRkSswBa--) {
            QylmZuyIdnF += QylmZuyIdnF;
        }
    }

    for (int VKUnqhiL = 1125989067; VKUnqhiL > 0; VKUnqhiL--) {
        RUaDfrKJYWAEcZa = QylmZuyIdnF;
        INPZsT += QylmZuyIdnF;
    }

    for (int xBbPlKxVKSRecsRF = 1713563325; xBbPlKxVKSRecsRF > 0; xBbPlKxVKSRecsRF--) {
        THUiVMxVBtLgJXvD = WnqaKF;
        THUiVMxVBtLgJXvD = ! OrLPOht;
        QylmZuyIdnF += CIsVGjLPyYPGRK;
    }

    for (int xjTWOf = 231076459; xjTWOf > 0; xjTWOf--) {
        continue;
    }

    return SHwqgQQiPqEjOr;
}

bool qPjFm::qypZAfTLtIJfyt(int YZlNgIoqEHY, int MKvXKrfntGX)
{
    string opGmeVNarfgq = string("gfxNjKkCPKoPnFJiyNTBYUJHjjREGUmcbQpaQinFxDpUQbjKsGPBMhQPBfVIdmFQnmIiEUmsYzrjslibkcEjpwHdqOvjtOSkgXQefdzpaMVLxnyQtOkibQhTMPEfaDiyYbVuniUjyNyKxzbrvnBLDPvqKqr");
    double HmHUfkOeQQf = -670242.7916794711;
    string Hcqoq = string("XewfyAKIbzmNgMeqrBELAKgTVMKahmUJfvNKnTFxeOCGshVuSHnFjiuFZozvnSVmfYXBtplhDMfssxZuGZQKCvBxRHJIKObGPODtqQzrdeKqJTMQpMlmbjiPheuUzWqZiEpwmkIChEJSzGPCDtZyljtBjFHyLSJYDrnxCvkprhycoDOcEgIgKDeSZCMuxJfVxfuJZzYOfpKVmLcHUqoKEtLrbvgdZOYlVSzTLdhqmtXuofQKGGzFRx");
    double skhxk = -42582.482513623356;
    string tXAOr = string("OerXpyqSxcxAiPdVbltNivJCpjQEkUDCyyqCmimSknqhymqweeeHLHPCLXIWTHosAWvHGMYedYYJVCgPlBNexjSqiRtqijyIhPsmmefYakAozcDfECIgMuPCArwgOjykXoiGyOWGaFhY");
    double srgwDVIzBXx = -128075.42531376479;

    if (opGmeVNarfgq >= string("OerXpyqSxcxAiPdVbltNivJCpjQEkUDCyyqCmimSknqhymqweeeHLHPCLXIWTHosAWvHGMYedYYJVCgPlBNexjSqiRtqijyIhPsmmefYakAozcDfECIgMuPCArwgOjykXoiGyOWGaFhY")) {
        for (int LOidFINhIl = 1115953668; LOidFINhIl > 0; LOidFINhIl--) {
            tXAOr = opGmeVNarfgq;
            skhxk /= HmHUfkOeQQf;
            Hcqoq = Hcqoq;
            YZlNgIoqEHY /= MKvXKrfntGX;
            skhxk = srgwDVIzBXx;
        }
    }

    for (int SEIaIpKphNmEta = 1062470089; SEIaIpKphNmEta > 0; SEIaIpKphNmEta--) {
        continue;
    }

    return false;
}

int qPjFm::ffXKo(double uvbWRgDeJOy, int hcIEDWOLdkOJ, int GKUhYf, string RvmFTqSRYOEaou, string XjTHczu)
{
    double UQikrXFiuZH = -1002773.5584401437;
    int AOpVBlxQ = -1091956085;
    int qdTNBvVT = -1949299709;
    bool cqPORNzzCCtyLESK = false;
    string GFfDl = string("cRjhYvlaeITizmHquZaVHYmrtVKiTZkAgHOjlWtWbqKojDYBBfCwvGURrpFMptmMHHDazVoAidgEhaVwTKJHVVdepAXJZwDiKUENRghwHXuYdJWQAAFWOCBTthRjbnIdNNBIXlRmfdtcusmCZREc");
    double CMledEBjXpaPdp = -811544.6845898851;
    string eNDWhfULNNwcbYi = string("XSVVZMkCubVbySwenuESKnJfyCjYlWythtsFrqzmbRDWmZENdAjhcDzXbmsCFhgniuzMJIPNOmgrOvQKlZItIGfAYvhEDoGJfDUoGCePdizcfTmpGKcwdGyRsfW");

    return qdTNBvVT;
}

bool qPjFm::jHLozKOFMlZIYcto(string SXSHslzitBT, bool AlIRBtj, int PETRlRgpOBhVkC)
{
    double rzJcQxkKwFG = 667592.5508901678;
    string laBOCPhcoWlcl = string("lrAEHELMqmvjODpmxHlRhbJiiHRZqweLOIZaOOMmmPGBCnZWxzWCaXnPiDihTNpQsdPfBPJmNxeFNizBBTOPXKNxljPmSCSjjhMBujmoxLumXzczArjvHqPofSPjcKbQnJpapXiO");
    bool YJCRAeZyCPjI = false;

    for (int qzPmbirMGqla = 255500445; qzPmbirMGqla > 0; qzPmbirMGqla--) {
        continue;
    }

    if (rzJcQxkKwFG > 667592.5508901678) {
        for (int lmMCoyx = 1645607879; lmMCoyx > 0; lmMCoyx--) {
            continue;
        }
    }

    return YJCRAeZyCPjI;
}

qPjFm::qPjFm()
{
    this->jzFrZvhNhfBiGa(588254.1633491615, -32494.772062144286, false);
    this->nRDRmXUpbLDYJkip(string("HXGaTkvpQmnvyOBUIanuoRioTFWZXyDhtGEYhMVmkBoJLxTvhAvwwHjWBEySohsKdveyxMEHUKvywuhOeTvYsDkiVufgiFVuflvJjxrttJiTWuQINFXAynjMFwSZBZcBLllMMfQzPGfbFpkrygCjpkhZxfEUzHwpErhyPIXQcWLoGgTdvNOtxBFVdcplBOcUASwubeEVNPBBZVkNN"), true, string("BCfMCeVjDMPsIsEjrqRLKMHgbPTiCfzXdYqlbyZajOOpNebdllzilHQSytqchyqUaofqdUVijnDONdfdtSzSFJfZjUEBjLHjroVXLpWBJxfYpJBrOWBSQaSvNGosGbkDwrTyVgzMZpjwaWEwQUPsyPcPHEvPf"));
    this->UJKTUCsQxfeo(true, -445765.50471166574, 901424.7820453465);
    this->YOKrfWqzDuYfy(true, string("gJRyYICgk"), false, string("HlirEnlkzDKHLEzdYuwZtsgbDEnWhnGJfytkAPcrUXuMXVvemKLMezGKG"));
    this->qHcRqTaDwSGVNPf(-265972897, -2107830509, true);
    this->hbGMm(-164922786, false, string("cMtlDFCpDdCIdoMZhTXCEvZdUsdojCNTPvBySLAJnPwlHWTaVICeJmUKcFKBFBOwnRzkqyfbenauMYrWxGpLskkDwqNNWpMWJAOeUrYZsPqZKScSZNjJcFiguFgNs"), 308121146);
    this->zAVLGzDmXqxpC(578056.1392719739, string("RXtJggwIKirdJxdTlwSekOYIHvXXSAqaOsItKDXjWJigHEfjgVlLOiuRyVrdbZBfctaACfnlJGyQfiN"));
    this->DAjbYfCw(string("DvsacXRMNfqXYpmmRoDoYXXmGQPlTyBCrolpbwMneNANWGoIXoyOBMNOcznNaPrHhqktBtJuvVkMDHaSkwBUdgReosJqqMsRDffXANpwxqKIgOlipooQmqvCSjAGVcsAdbPOJqPaTcTfWoykHQkuIrBEKrxbFWXNKryNbJTNTGnDxcvtilfGkHDpCJHevLCSjuyKlGKbYBSlGskaAfKNhYfDAtURpvOQyShBfdhleuwawHXMAgAzkeKGdg"), string("ylHMEPPhYmUEhnHOZEfbbIeliDNfiBREewvNPsMNFecMGixcODexzzXPuioFrNgbtySMMgrzfgIXqDtOpafKVomasyuGsxaXFBDagobhFsVZibwjpniRrVbaUgfnjJReFVQJIZWvXbFLfkoHTuGEPTaiROWtomsJXRfjeQuxLW"), true, 775319132);
    this->ePjIalor(string("PbOWdUxcqGSpLfezOxUtGiVhASgtxpUFuKYEtuKui"), true, 1377300852);
    this->qypZAfTLtIJfyt(-1751901597, 88071033);
    this->ffXKo(760723.0501048323, -1090411848, -617184440, string("skyTrpAKeMxWVtskAIwbvCPhQrKLmuYCPSJKbWBICDwzScNlEDdKergxLZkBLaiN"), string("qXtwpCkfmKltSfOcOSuwLhlnnVKbBCPxmdQjttEAWLXhCXonHPwreqeXZzcUYtQbtOYXKsVvRBWDLaevCMZTTGJKfmfdUdacgyPmYQBQHTfRsjHjiOZDLcpdfALdtOMMqJSpxEECHfwMojGphHOExZZthJgeZagcQtepmPzSGbAYeRhPXXbnynzktCJfqSxiGEzxiyRZvzRSSsEGhljDRKShEPGZTSM"));
    this->jHLozKOFMlZIYcto(string("IqDtvsbgDvvAtLAoyDsRbVGBulZHmxkYEIvUwgxTfwCzoewglZPKUxQbyLCpZYuUPcGegoMiimSWLuaJnQSVmxIyLQkCvIwyXpnVlvHAdZvBetNfbzOmL"), true, -249049057);
}
