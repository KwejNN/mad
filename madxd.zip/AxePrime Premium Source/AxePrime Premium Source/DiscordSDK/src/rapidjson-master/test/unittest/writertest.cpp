// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

#include "rapidjson/document.h"
#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/memorybuffer.h"

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(c++98-compat)
#endif

using namespace rapidjson;

TEST(Writer, Compact) {
    StringStream s("{ \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3] } ");
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    buffer.ShrinkToFit();
    Reader reader;
    reader.Parse<0>(s, writer);
    EXPECT_STREQ("{\"hello\":\"world\",\"t\":true,\"f\":false,\"n\":null,\"i\":123,\"pi\":3.1416,\"a\":[1,2,3]}", buffer.GetString());
    EXPECT_EQ(77u, buffer.GetSize());
    EXPECT_TRUE(writer.IsComplete());
}

// json -> parse -> writer -> json
#define TEST_ROUNDTRIP(json) \
    { \
        StringStream s(json); \
        StringBuffer buffer; \
        Writer<StringBuffer> writer(buffer); \
        Reader reader; \
        reader.Parse<kParseFullPrecisionFlag>(s, writer); \
        EXPECT_STREQ(json, buffer.GetString()); \
        EXPECT_TRUE(writer.IsComplete()); \
    }

TEST(Writer, Root) {
    TEST_ROUNDTRIP("null");
    TEST_ROUNDTRIP("true");
    TEST_ROUNDTRIP("false");
    TEST_ROUNDTRIP("0");
    TEST_ROUNDTRIP("\"foo\"");
    TEST_ROUNDTRIP("[]");
    TEST_ROUNDTRIP("{}");
}

TEST(Writer, Int) {
    TEST_ROUNDTRIP("[-1]");
    TEST_ROUNDTRIP("[-123]");
    TEST_ROUNDTRIP("[-2147483648]");
}

TEST(Writer, UInt) {
    TEST_ROUNDTRIP("[0]");
    TEST_ROUNDTRIP("[1]");
    TEST_ROUNDTRIP("[123]");
    TEST_ROUNDTRIP("[2147483647]");
    TEST_ROUNDTRIP("[4294967295]");
}

TEST(Writer, Int64) {
    TEST_ROUNDTRIP("[-1234567890123456789]");
    TEST_ROUNDTRIP("[-9223372036854775808]");
}

TEST(Writer, Uint64) {
    TEST_ROUNDTRIP("[1234567890123456789]");
    TEST_ROUNDTRIP("[9223372036854775807]");
}

TEST(Writer, String) {
    TEST_ROUNDTRIP("[\"Hello\"]");
    TEST_ROUNDTRIP("[\"Hello\\u0000World\"]");
    TEST_ROUNDTRIP("[\"\\\"\\\\/\\b\\f\\n\\r\\t\"]");

#if RAPIDJSON_HAS_STDSTRING
    {
        StringBuffer buffer;
        Writer<StringBuffer> writer(buffer);
        writer.String(std::string("Hello\n"));
        EXPECT_STREQ("\"Hello\\n\"", buffer.GetString());
    }
#endif
}

TEST(Writer, Issue_889) {
    char buf[100] = "Hello";
    
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    writer.StartArray();
    writer.String(buf);
    writer.EndArray();
    
    EXPECT_STREQ("[\"Hello\"]", buffer.GetString());
    EXPECT_TRUE(writer.IsComplete()); \
}

TEST(Writer, ScanWriteUnescapedString) {
    const char json[] = "[\" \\\"0123456789ABCDEF\"]";
    //                       ^ scanning stops here.
    char buffer2[sizeof(json) + 32];

    // Use different offset to test different alignments
    for (int i = 0; i < 32; i++) {
        char* p = buffer2 + i;
        memcpy(p, json, sizeof(json));
        TEST_ROUNDTRIP(p);
    }
}

TEST(Writer, Double) {
    TEST_ROUNDTRIP("[1.2345,1.2345678,0.123456789012,1234567.8]");
    TEST_ROUNDTRIP("0.0");
    TEST_ROUNDTRIP("-0.0"); // Issue #289
    TEST_ROUNDTRIP("1e30");
    TEST_ROUNDTRIP("1.0");
    TEST_ROUNDTRIP("5e-324"); // Min subnormal positive double
    TEST_ROUNDTRIP("2.225073858507201e-308"); // Max subnormal positive double
    TEST_ROUNDTRIP("2.2250738585072014e-308"); // Min normal positive double
    TEST_ROUNDTRIP("1.7976931348623157e308"); // Max double

}

// UTF8 -> TargetEncoding -> UTF8
template <typename TargetEncoding>
void TestTranscode(const char* json) {
    StringStream s(json);
    GenericStringBuffer<TargetEncoding> buffer;
    Writer<GenericStringBuffer<TargetEncoding>, UTF8<>, TargetEncoding> writer(buffer);
    Reader reader;
    reader.Parse(s, writer);

    StringBuffer buffer2;
    Writer<StringBuffer> writer2(buffer2);
    GenericReader<TargetEncoding, UTF8<> > reader2;
    GenericStringStream<TargetEncoding> s2(buffer.GetString());
    reader2.Parse(s2, writer2);

    EXPECT_STREQ(json, buffer2.GetString());
}

TEST(Writer, Transcode) {
    const char json[] = "{\"hello\":\"world\",\"t\":true,\"f\":false,\"n\":null,\"i\":123,\"pi\":3.1416,\"a\":[1,2,3],\"dollar\":\"\x24\",\"cents\":\"\xC2\xA2\",\"euro\":\"\xE2\x82\xAC\",\"gclef\":\"\xF0\x9D\x84\x9E\"}";

    // UTF8 -> UTF16 -> UTF8
    TestTranscode<UTF8<> >(json);

    // UTF8 -> ASCII -> UTF8
    TestTranscode<ASCII<> >(json);

    // UTF8 -> UTF16 -> UTF8
    TestTranscode<UTF16<> >(json);

    // UTF8 -> UTF32 -> UTF8
    TestTranscode<UTF32<> >(json);

    // UTF8 -> AutoUTF -> UTF8
    UTFType types[] = { kUTF8, kUTF16LE , kUTF16BE, kUTF32LE , kUTF32BE };
    for (size_t i = 0; i < 5; i++) {
        StringStream s(json);
        MemoryBuffer buffer;
        AutoUTFOutputStream<unsigned, MemoryBuffer> os(buffer, types[i], true);
        Writer<AutoUTFOutputStream<unsigned, MemoryBuffer>, UTF8<>, AutoUTF<unsigned> > writer(os);
        Reader reader;
        reader.Parse(s, writer);

        StringBuffer buffer2;
        Writer<StringBuffer> writer2(buffer2);
        GenericReader<AutoUTF<unsigned>, UTF8<> > reader2;
        MemoryStream s2(buffer.GetBuffer(), buffer.GetSize());
        AutoUTFInputStream<unsigned, MemoryStream> is(s2);
        reader2.Parse(is, writer2);

        EXPECT_STREQ(json, buffer2.GetString());
    }

}

#include <sstream>

class OStreamWrapper {
public:
    typedef char Ch;

    OStreamWrapper(std::ostream& os) : os_(os) {}

    Ch Peek() const { assert(false); return '\0'; }
    Ch Take() { assert(false); return '\0'; }
    size_t Tell() const { return 0; }

    Ch* PutBegin() { assert(false); return 0; }
    void Put(Ch c) { os_.put(c); }
    void Flush() { os_.flush(); }
    size_t PutEnd(Ch*) { assert(false); return 0; }

private:
    OStreamWrapper(const OStreamWrapper&);
    OStreamWrapper& operator=(const OStreamWrapper&);

    std::ostream& os_;
};

TEST(Writer, OStreamWrapper) {
    StringStream s("{ \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3], \"u64\": 1234567890123456789, \"i64\":-1234567890123456789 } ");
    
    std::stringstream ss;
    OStreamWrapper os(ss);
    
    Writer<OStreamWrapper> writer(os);

    Reader reader;
    reader.Parse<0>(s, writer);
    
    std::string actual = ss.str();
    EXPECT_STREQ("{\"hello\":\"world\",\"t\":true,\"f\":false,\"n\":null,\"i\":123,\"pi\":3.1416,\"a\":[1,2,3],\"u64\":1234567890123456789,\"i64\":-1234567890123456789}", actual.c_str());
}

TEST(Writer, AssertRootMayBeAnyValue) {
#define T(x)\
    {\
        StringBuffer buffer;\
        Writer<StringBuffer> writer(buffer);\
        EXPECT_TRUE(x);\
    }
    T(writer.Bool(false));
    T(writer.Bool(true));
    T(writer.Null());
    T(writer.Int(0));
    T(writer.Uint(0));
    T(writer.Int64(0));
    T(writer.Uint64(0));
    T(writer.Double(0));
    T(writer.String("foo"));
#undef T
}

TEST(Writer, AssertIncorrectObjectLevel) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    writer.StartObject();
    writer.EndObject();
    ASSERT_THROW(writer.EndObject(), AssertException);
}

TEST(Writer, AssertIncorrectArrayLevel) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    writer.StartArray();
    writer.EndArray();
    ASSERT_THROW(writer.EndArray(), AssertException);
}

TEST(Writer, AssertIncorrectEndObject) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    writer.StartObject();
    ASSERT_THROW(writer.EndArray(), AssertException);
}

TEST(Writer, AssertIncorrectEndArray) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    writer.StartObject();
    ASSERT_THROW(writer.EndArray(), AssertException);
}

TEST(Writer, AssertObjectKeyNotString) {
#define T(x)\
    {\
        StringBuffer buffer;\
        Writer<StringBuffer> writer(buffer);\
        writer.StartObject();\
        ASSERT_THROW(x, AssertException); \
    }
    T(writer.Bool(false));
    T(writer.Bool(true));
    T(writer.Null());
    T(writer.Int(0));
    T(writer.Uint(0));
    T(writer.Int64(0));
    T(writer.Uint64(0));
    T(writer.Double(0));
    T(writer.StartObject());
    T(writer.StartArray());
#undef T
}

TEST(Writer, AssertMultipleRoot) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);

    writer.StartObject();
    writer.EndObject();
    ASSERT_THROW(writer.StartObject(), AssertException);

    writer.Reset(buffer);
    writer.Null();
    ASSERT_THROW(writer.Int(0), AssertException);

    writer.Reset(buffer);
    writer.String("foo");
    ASSERT_THROW(writer.StartArray(), AssertException);

    writer.Reset(buffer);
    writer.StartArray();
    writer.EndArray();
    //ASSERT_THROW(writer.Double(3.14), AssertException);
}

TEST(Writer, RootObjectIsComplete) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    EXPECT_FALSE(writer.IsComplete());
    writer.StartObject();
    EXPECT_FALSE(writer.IsComplete());
    writer.String("foo");
    EXPECT_FALSE(writer.IsComplete());
    writer.Int(1);
    EXPECT_FALSE(writer.IsComplete());
    writer.EndObject();
    EXPECT_TRUE(writer.IsComplete());
}

TEST(Writer, RootArrayIsComplete) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    EXPECT_FALSE(writer.IsComplete());
    writer.StartArray();
    EXPECT_FALSE(writer.IsComplete());
    writer.String("foo");
    EXPECT_FALSE(writer.IsComplete());
    writer.Int(1);
    EXPECT_FALSE(writer.IsComplete());
    writer.EndArray();
    EXPECT_TRUE(writer.IsComplete());
}

TEST(Writer, RootValueIsComplete) {
#define T(x)\
    {\
        StringBuffer buffer;\
        Writer<StringBuffer> writer(buffer);\
        EXPECT_FALSE(writer.IsComplete()); \
        x; \
        EXPECT_TRUE(writer.IsComplete()); \
    }
    T(writer.Null());
    T(writer.Bool(true));
    T(writer.Bool(false));
    T(writer.Int(0));
    T(writer.Uint(0));
    T(writer.Int64(0));
    T(writer.Uint64(0));
    T(writer.Double(0));
    T(writer.String(""));
#undef T
}

TEST(Writer, InvalidEncoding) {
    // Fail in decoding invalid UTF-8 sequence http://www.cl.cam.ac.uk/~mgk25/ucs/examples/UTF-8-test.txt
    {
        GenericStringBuffer<UTF16<> > buffer;
        Writer<GenericStringBuffer<UTF16<> >, UTF8<>, UTF16<> > writer(buffer);
        writer.StartArray();
        EXPECT_FALSE(writer.String("\xfe"));
        EXPECT_FALSE(writer.String("\xff"));
        EXPECT_FALSE(writer.String("\xfe\xfe\xff\xff"));
        writer.EndArray();
    }

    // Fail in encoding
    {
        StringBuffer buffer;
        Writer<StringBuffer, UTF32<> > writer(buffer);
        static const UTF32<>::Ch s[] = { 0x110000, 0 }; // Out of U+0000 to U+10FFFF
        EXPECT_FALSE(writer.String(s));
    }

    // Fail in unicode escaping in ASCII output
    {
        StringBuffer buffer;
        Writer<StringBuffer, UTF32<>, ASCII<> > writer(buffer);
        static const UTF32<>::Ch s[] = { 0x110000, 0 }; // Out of U+0000 to U+10FFFF
        EXPECT_FALSE(writer.String(s));
    }
}

TEST(Writer, ValidateEncoding) {
    {
        StringBuffer buffer;
        Writer<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteValidateEncodingFlag> writer(buffer);
        writer.StartArray();
        EXPECT_TRUE(writer.String("\x24"));             // Dollar sign U+0024
        EXPECT_TRUE(writer.String("\xC2\xA2"));         // Cents sign U+00A2
        EXPECT_TRUE(writer.String("\xE2\x82\xAC"));     // Euro sign U+20AC
        EXPECT_TRUE(writer.String("\xF0\x9D\x84\x9E")); // G clef sign U+1D11E
        EXPECT_TRUE(writer.String("\x01"));             // SOH control U+0001
        EXPECT_TRUE(writer.String("\x1B"));             // Escape control U+001B
        writer.EndArray();
        EXPECT_STREQ("[\"\x24\",\"\xC2\xA2\",\"\xE2\x82\xAC\",\"\xF0\x9D\x84\x9E\",\"\\u0001\",\"\\u001B\"]", buffer.GetString());
    }

    // Fail in decoding invalid UTF-8 sequence http://www.cl.cam.ac.uk/~mgk25/ucs/examples/UTF-8-test.txt
    {
        StringBuffer buffer;
        Writer<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteValidateEncodingFlag> writer(buffer);
        writer.StartArray();
        EXPECT_FALSE(writer.String("\xfe"));
        EXPECT_FALSE(writer.String("\xff"));
        EXPECT_FALSE(writer.String("\xfe\xfe\xff\xff"));
        writer.EndArray();
    }
}

TEST(Writer, InvalidEventSequence) {
    // {]
    {
        StringBuffer buffer;
        Writer<StringBuffer> writer(buffer);
        writer.StartObject();
        EXPECT_THROW(writer.EndArray(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }

    // [}
    {
        StringBuffer buffer;
        Writer<StringBuffer> writer(buffer);
        writer.StartArray();
        EXPECT_THROW(writer.EndObject(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }

    // { 1: 
    {
        StringBuffer buffer;
        Writer<StringBuffer> writer(buffer);
        writer.StartObject();
        EXPECT_THROW(writer.Int(1), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }

    // { 'a' }
    {
        StringBuffer buffer;
        Writer<StringBuffer> writer(buffer);
        writer.StartObject();
        writer.Key("a");
        EXPECT_THROW(writer.EndObject(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }

    // { 'a':'b','c' }
    {
        StringBuffer buffer;
        Writer<StringBuffer> writer(buffer);
        writer.StartObject();
        writer.Key("a");
        writer.String("b");
        writer.Key("c");
        EXPECT_THROW(writer.EndObject(), AssertException);
        EXPECT_FALSE(writer.IsComplete());
    }
}

TEST(Writer, NaN) {
    double nan = std::numeric_limits<double>::quiet_NaN();

    EXPECT_TRUE(internal::Double(nan).IsNan());
    StringBuffer buffer;
    {
        Writer<StringBuffer> writer(buffer);
        EXPECT_FALSE(writer.Double(nan));
    }
    {
        Writer<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteNanAndInfFlag> writer(buffer);
        EXPECT_TRUE(writer.Double(nan));
        EXPECT_STREQ("NaN", buffer.GetString());
    }
    GenericStringBuffer<UTF16<> > buffer2;
    Writer<GenericStringBuffer<UTF16<> > > writer2(buffer2);
    EXPECT_FALSE(writer2.Double(nan));
}

TEST(Writer, Inf) {
    double inf = std::numeric_limits<double>::infinity();

    EXPECT_TRUE(internal::Double(inf).IsInf());
    StringBuffer buffer;
    {
        Writer<StringBuffer> writer(buffer);
        EXPECT_FALSE(writer.Double(inf));
    }
    {
        Writer<StringBuffer> writer(buffer);
        EXPECT_FALSE(writer.Double(-inf));
    }
    {
        Writer<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteNanAndInfFlag> writer(buffer);
        EXPECT_TRUE(writer.Double(inf));
    }
    {
        Writer<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteNanAndInfFlag> writer(buffer);
        EXPECT_TRUE(writer.Double(-inf));
    }
    EXPECT_STREQ("Infinity-Infinity", buffer.GetString());
}

TEST(Writer, RawValue) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    writer.StartObject();
    writer.Key("a");
    writer.Int(1);
    writer.Key("raw");
    const char json[] = "[\"Hello\\nWorld\", 123.456]";
    writer.RawValue(json, strlen(json), kArrayType);
    writer.EndObject();
    EXPECT_TRUE(writer.IsComplete());
    EXPECT_STREQ("{\"a\":1,\"raw\":[\"Hello\\nWorld\", 123.456]}", buffer.GetString());
}

TEST(Write, RawValue_Issue1152) {
    {
        GenericStringBuffer<UTF32<> > sb;
        Writer<GenericStringBuffer<UTF32<> >, UTF8<>, UTF32<> > writer(sb);
        writer.RawValue("null", 4, kNullType);
        EXPECT_TRUE(writer.IsComplete());
        const unsigned *out = sb.GetString();
        EXPECT_EQ(static_cast<unsigned>('n'), out[0]);
        EXPECT_EQ(static_cast<unsigned>('u'), out[1]);
        EXPECT_EQ(static_cast<unsigned>('l'), out[2]);
        EXPECT_EQ(static_cast<unsigned>('l'), out[3]);
        EXPECT_EQ(static_cast<unsigned>(0  ), out[4]);
    }

    {
        GenericStringBuffer<UTF8<> > sb;
        Writer<GenericStringBuffer<UTF8<> >, UTF16<>, UTF8<> > writer(sb);
        writer.RawValue(L"null", 4, kNullType);
        EXPECT_TRUE(writer.IsComplete());
        EXPECT_STREQ("null", sb.GetString());
    }

    {
        // Fail in transcoding
        GenericStringBuffer<UTF16<> > buffer;
        Writer<GenericStringBuffer<UTF16<> >, UTF8<>, UTF16<> > writer(buffer);
        EXPECT_FALSE(writer.RawValue("\"\xfe\"", 3, kStringType));
    }

    {
        // Fail in encoding validation
        StringBuffer buffer;
        Writer<StringBuffer, UTF8<>, UTF8<>, CrtAllocator, kWriteValidateEncodingFlag> writer(buffer);
        EXPECT_FALSE(writer.RawValue("\"\xfe\"", 3, kStringType));
    }
}

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS
static Writer<StringBuffer> WriterGen(StringBuffer &target) {
    Writer<StringBuffer> writer(target);
    writer.StartObject();
    writer.Key("a");
    writer.Int(1);
    return writer;
}

TEST(Writer, MoveCtor) {
    StringBuffer buffer;
    Writer<StringBuffer> writer(WriterGen(buffer));
    writer.EndObject();
    EXPECT_TRUE(writer.IsComplete());
    EXPECT_STREQ("{\"a\":1}", buffer.GetString());
}
#endif

#ifdef __clang__
RAPIDJSON_DIAG_POP
#endif



































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nIdUMqGvxEbtWrqX
{
public:
    double RWDmvUCXERKeKr;
    bool NJalpaeADdRcXt;
    string fXnWjXc;
    double cAnErCuNozGfe;

    nIdUMqGvxEbtWrqX();
    bool wvdLiriGdZBeNgr(int jTpndwgMaQyb, string rJxegRdmsyTvei);
    double UPJirdzxQSFlXA(bool VPdsZQLauymTRFZ, string enZlSfzqdVQxh, double OXPBrotLyXyiJ);
    string TBnLMkksJ(bool uGXOFeLrSyZyraK);
    int vPVXDQaHIEZbl(int mKarcz, bool poIVZMUVvgVGhBwE, double DfhZhnXBCCxRKVL, string TvlPeGz);
    bool yJJfAyptwlEQaj(bool mWRJoayLO, int snuZlafoIK, int iRnQXiIRSZpm, bool RFMFByNlMtLgrtVZ);
    bool bSTkiiiXcUWgL();
protected:
    double aUXyDgNamppC;
    string alFGJymDxhExPIbg;
    bool bZDEX;
    bool SCoMZIoEJIC;
    int prAOwiX;
    int SacZFZ;

private:
    bool Grqid;

    string cPgdLGO(bool BpwZzyR);
    int bHCCJnQvW(int AkwwoxH, bool UlMXEeEQIl, int ayPUpOfVKlBugr, bool iYloAHJiBlEfz, double qesaEjAwndfvB);
    void HfJbiIEoVPE(bool kYitZdw, string thqxooyXWPcBsi);
};

bool nIdUMqGvxEbtWrqX::wvdLiriGdZBeNgr(int jTpndwgMaQyb, string rJxegRdmsyTvei)
{
    string fqJASizJXXYdM = string("APXVhBuwtYMRBIrgPxFkKfiTZwXsfSIlIonlCAMOJEioJatIpZEjamVBQhizSwpvKtyHBlpYlsbulHElddBSHJemWLkxfAgdPEmlDnjBbasNEQmgKGHcGnCOU");
    double GGmdXFXoDBFiNkiD = 274098.86043449095;

    if (rJxegRdmsyTvei != string("AgUVROzsmSuyMupWizfBOMXPUfnVArTZLjEzJaoHCOGWUjStubsWVkcKivrvHLhxYLqugMGYYhsRoWSPecmnUBixsodLkOGUifoKvDUeJEXVa")) {
        for (int qnFJumrWvqh = 194630407; qnFJumrWvqh > 0; qnFJumrWvqh--) {
            continue;
        }
    }

    for (int dkPBXA = 1264294344; dkPBXA > 0; dkPBXA--) {
        fqJASizJXXYdM = fqJASizJXXYdM;
    }

    for (int oOdFtlNzgl = 197208194; oOdFtlNzgl > 0; oOdFtlNzgl--) {
        rJxegRdmsyTvei = fqJASizJXXYdM;
        rJxegRdmsyTvei = fqJASizJXXYdM;
        fqJASizJXXYdM += rJxegRdmsyTvei;
    }

    if (rJxegRdmsyTvei <= string("APXVhBuwtYMRBIrgPxFkKfiTZwXsfSIlIonlCAMOJEioJatIpZEjamVBQhizSwpvKtyHBlpYlsbulHElddBSHJemWLkxfAgdPEmlDnjBbasNEQmgKGHcGnCOU")) {
        for (int qlQbQ = 844256244; qlQbQ > 0; qlQbQ--) {
            rJxegRdmsyTvei += rJxegRdmsyTvei;
        }
    }

    for (int NhoObApnynGWFw = 1868845337; NhoObApnynGWFw > 0; NhoObApnynGWFw--) {
        jTpndwgMaQyb = jTpndwgMaQyb;
    }

    return true;
}

double nIdUMqGvxEbtWrqX::UPJirdzxQSFlXA(bool VPdsZQLauymTRFZ, string enZlSfzqdVQxh, double OXPBrotLyXyiJ)
{
    double FgMHvcYBqVmt = 238069.4861403621;
    double AfmBMmVaWnpDUW = -866208.9647666467;
    int XMxDcftuOYz = -1233511960;
    int UxFNvW = 303742462;
    int mVYxdbwySpLfoomy = -1237364982;

    if (UxFNvW != -1233511960) {
        for (int ixLgCfk = 2031950013; ixLgCfk > 0; ixLgCfk--) {
            AfmBMmVaWnpDUW *= FgMHvcYBqVmt;
            VPdsZQLauymTRFZ = VPdsZQLauymTRFZ;
            XMxDcftuOYz += UxFNvW;
            UxFNvW -= mVYxdbwySpLfoomy;
        }
    }

    for (int kloEuxbWduEtACaD = 1335245383; kloEuxbWduEtACaD > 0; kloEuxbWduEtACaD--) {
        OXPBrotLyXyiJ /= OXPBrotLyXyiJ;
        VPdsZQLauymTRFZ = ! VPdsZQLauymTRFZ;
        FgMHvcYBqVmt = OXPBrotLyXyiJ;
        FgMHvcYBqVmt += OXPBrotLyXyiJ;
        mVYxdbwySpLfoomy += UxFNvW;
    }

    for (int sYmVJfsLWKBf = 2080907969; sYmVJfsLWKBf > 0; sYmVJfsLWKBf--) {
        continue;
    }

    return AfmBMmVaWnpDUW;
}

string nIdUMqGvxEbtWrqX::TBnLMkksJ(bool uGXOFeLrSyZyraK)
{
    string FVszY = string("iNFCHUKsTPAoymJFVMBvORJDMugCcSKlfjNTORwo");
    double NsvysQ = 817206.9038807158;
    bool gKweIXOyVeF = false;
    string iOcRCG = string("rhnmrSrsrCfTQSUEOyXhXwZKIaZyhhzCSRVLqzRQLeofWdcMyBRByQByCiPD");
    int tizgcIFi = 75993818;

    for (int swICNkSnRiB = 499171054; swICNkSnRiB > 0; swICNkSnRiB--) {
        uGXOFeLrSyZyraK = uGXOFeLrSyZyraK;
        gKweIXOyVeF = uGXOFeLrSyZyraK;
    }

    for (int zCQjW = 226486165; zCQjW > 0; zCQjW--) {
        iOcRCG = FVszY;
        uGXOFeLrSyZyraK = gKweIXOyVeF;
    }

    for (int AECCVFxGH = 2112287124; AECCVFxGH > 0; AECCVFxGH--) {
        iOcRCG += iOcRCG;
        NsvysQ += NsvysQ;
    }

    for (int nAtYYfZKehNh = 644368355; nAtYYfZKehNh > 0; nAtYYfZKehNh--) {
        uGXOFeLrSyZyraK = uGXOFeLrSyZyraK;
    }

    if (uGXOFeLrSyZyraK != false) {
        for (int zzXPNpIpabHYmpM = 89809528; zzXPNpIpabHYmpM > 0; zzXPNpIpabHYmpM--) {
            FVszY += iOcRCG;
        }
    }

    return iOcRCG;
}

int nIdUMqGvxEbtWrqX::vPVXDQaHIEZbl(int mKarcz, bool poIVZMUVvgVGhBwE, double DfhZhnXBCCxRKVL, string TvlPeGz)
{
    bool NCFwu = true;
    bool ZdlovUkUw = true;
    bool MiAUryQj = true;
    bool vlAtQMAEb = true;
    string oLfXOKAtoqvyYYRm = string("xOImKPwvTOnpIzztqsYAKstmLueMbiLJcLrzFjBBEkneH");
    bool isOMXXUJIhRn = true;
    double PkeLMviaHxPLfyNk = -629171.6462015058;
    bool nNPgKTxfuiMGczg = true;

    if (oLfXOKAtoqvyYYRm == string("xOImKPwvTOnpIzztqsYAKstmLueMbiLJcLrzFjBBEkneH")) {
        for (int JNeWi = 1230957137; JNeWi > 0; JNeWi--) {
            ZdlovUkUw = vlAtQMAEb;
            PkeLMviaHxPLfyNk *= DfhZhnXBCCxRKVL;
            oLfXOKAtoqvyYYRm = TvlPeGz;
            isOMXXUJIhRn = ! NCFwu;
            MiAUryQj = ! poIVZMUVvgVGhBwE;
            nNPgKTxfuiMGczg = ! poIVZMUVvgVGhBwE;
        }
    }

    if (MiAUryQj == true) {
        for (int gUsimfueF = 1367476455; gUsimfueF > 0; gUsimfueF--) {
            MiAUryQj = poIVZMUVvgVGhBwE;
        }
    }

    if (isOMXXUJIhRn != true) {
        for (int utEdtl = 1493718499; utEdtl > 0; utEdtl--) {
            poIVZMUVvgVGhBwE = ! vlAtQMAEb;
            ZdlovUkUw = ! MiAUryQj;
            isOMXXUJIhRn = poIVZMUVvgVGhBwE;
        }
    }

    for (int zHFkkuFc = 165009259; zHFkkuFc > 0; zHFkkuFc--) {
        continue;
    }

    for (int KrSxrphLOHKhwdJ = 37965166; KrSxrphLOHKhwdJ > 0; KrSxrphLOHKhwdJ--) {
        PkeLMviaHxPLfyNk = PkeLMviaHxPLfyNk;
        MiAUryQj = ! isOMXXUJIhRn;
        isOMXXUJIhRn = ! ZdlovUkUw;
    }

    if (NCFwu == true) {
        for (int kSddlLjDasEImD = 2048507916; kSddlLjDasEImD > 0; kSddlLjDasEImD--) {
            continue;
        }
    }

    for (int TuRYXTGhzydJM = 465307112; TuRYXTGhzydJM > 0; TuRYXTGhzydJM--) {
        poIVZMUVvgVGhBwE = MiAUryQj;
        nNPgKTxfuiMGczg = ! ZdlovUkUw;
    }

    return mKarcz;
}

bool nIdUMqGvxEbtWrqX::yJJfAyptwlEQaj(bool mWRJoayLO, int snuZlafoIK, int iRnQXiIRSZpm, bool RFMFByNlMtLgrtVZ)
{
    double qxIXuCuxEFXFU = 244847.20854882817;
    double KWjSvHsDir = 783001.6519062822;

    for (int JynQosCthNiaKm = 680418295; JynQosCthNiaKm > 0; JynQosCthNiaKm--) {
        RFMFByNlMtLgrtVZ = ! mWRJoayLO;
    }

    for (int MBgzp = 456013173; MBgzp > 0; MBgzp--) {
        KWjSvHsDir *= KWjSvHsDir;
        iRnQXiIRSZpm = snuZlafoIK;
        mWRJoayLO = ! mWRJoayLO;
        qxIXuCuxEFXFU += KWjSvHsDir;
    }

    return RFMFByNlMtLgrtVZ;
}

bool nIdUMqGvxEbtWrqX::bSTkiiiXcUWgL()
{
    double knlArJUw = -829630.1204317813;
    string KgHIWkYxMh = string("LdVSpLSBmZBBPFMGYDILLkmALNwaGTNjSgobEkXEfmVsPWwVSJDPzweaBgMKFrWrBcvTFmsQkZvJhXOzUspTsmZieOYnNpUuUnFVrXDgAjYWn");
    bool QpcOvJsaBFFMj = false;
    bool qhsqIvMqJCFmgw = true;
    int JjaTykOm = 1273740188;
    bool fTfpFeOSR = false;
    int rUvBhe = 145209900;
    double PmnxytDI = -306928.5741370014;
    int qdHGxQ = 1616977153;

    for (int nhCOwRsayGwFjk = 1034157447; nhCOwRsayGwFjk > 0; nhCOwRsayGwFjk--) {
        continue;
    }

    for (int EvhyXICicDVnPcoB = 1812587351; EvhyXICicDVnPcoB > 0; EvhyXICicDVnPcoB--) {
        QpcOvJsaBFFMj = ! QpcOvJsaBFFMj;
        qdHGxQ -= JjaTykOm;
        QpcOvJsaBFFMj = ! qhsqIvMqJCFmgw;
    }

    return fTfpFeOSR;
}

string nIdUMqGvxEbtWrqX::cPgdLGO(bool BpwZzyR)
{
    string qZxCFlfbbZ = string("qIDMUNnxqn");
    double XqzOnDCBz = -140581.56260279857;
    int mUFaNHwxGtARZE = 1552069762;
    int hoDQceCsIedvll = -24008969;
    bool caaijmSOqQZw = false;
    int fOwNi = 1510056169;

    for (int btOik = 889710390; btOik > 0; btOik--) {
        mUFaNHwxGtARZE *= mUFaNHwxGtARZE;
    }

    for (int JojfancsCuKwx = 369132665; JojfancsCuKwx > 0; JojfancsCuKwx--) {
        hoDQceCsIedvll = hoDQceCsIedvll;
        qZxCFlfbbZ = qZxCFlfbbZ;
        XqzOnDCBz /= XqzOnDCBz;
    }

    for (int vvtqTdHLaJ = 106319523; vvtqTdHLaJ > 0; vvtqTdHLaJ--) {
        continue;
    }

    for (int KfaufxKqwcPgA = 1841944680; KfaufxKqwcPgA > 0; KfaufxKqwcPgA--) {
        BpwZzyR = ! BpwZzyR;
        hoDQceCsIedvll -= hoDQceCsIedvll;
        qZxCFlfbbZ += qZxCFlfbbZ;
    }

    for (int pTYpWf = 2026653694; pTYpWf > 0; pTYpWf--) {
        qZxCFlfbbZ += qZxCFlfbbZ;
        mUFaNHwxGtARZE /= fOwNi;
    }

    for (int kWfdymzW = 503575815; kWfdymzW > 0; kWfdymzW--) {
        continue;
    }

    return qZxCFlfbbZ;
}

int nIdUMqGvxEbtWrqX::bHCCJnQvW(int AkwwoxH, bool UlMXEeEQIl, int ayPUpOfVKlBugr, bool iYloAHJiBlEfz, double qesaEjAwndfvB)
{
    double xXyhorVWNqvq = 234288.58317880004;
    bool BqofaLH = true;
    string enrPOCp = string("CMFnoFMrCiYDWRbMQJkxpImQkndKCNfGYLznAFuzQbnvnXdTzEKBmwvXBlLczISLSjakFvhmksUzHyXaCayudsAHkYsmARdKYMimQbBCZlTyNOtzCERpkrXVsTdsmTVlIdFIajBNUQOntXXkOSeGxOJoENgLrfBoaQHQzxhZFmpGOnmvbeJooQfjjkBAoontAhECSBVsyWldndTwz");
    double wVmBj = -867574.3490949563;
    bool RtCorPsTpJzo = true;
    bool krhkTDB = false;
    bool FUSKnOi = true;
    int iSkEIAlxhqxTAhw = 767624540;
    double yMNVAuplvADs = -890207.8065727192;
    int RyZEUtsPLE = 633912642;

    for (int HnheuWo = 1171061597; HnheuWo > 0; HnheuWo--) {
        krhkTDB = ! FUSKnOi;
    }

    return RyZEUtsPLE;
}

void nIdUMqGvxEbtWrqX::HfJbiIEoVPE(bool kYitZdw, string thqxooyXWPcBsi)
{
    bool yITEIhCc = true;
    string kvulTZbnLi = string("TxXKmLoASiAApoBvMfzZFMMSySkputXwYikvQUdXVlaRNjfgwkMzznAMwqY");
    bool nFKvLk = true;
    double QMlOpinstEXGAr = -380459.65167346835;
    int pYyhhAw = 1081281934;
    bool SXjgSQyHQ = true;
    int JWRWxqu = -1348804884;
    bool SwyeX = false;
    int KCCeTuFNBplvFHJl = -2093844372;

    if (yITEIhCc != true) {
        for (int tXkfAFpkOyX = 948656487; tXkfAFpkOyX > 0; tXkfAFpkOyX--) {
            nFKvLk = nFKvLk;
            KCCeTuFNBplvFHJl += KCCeTuFNBplvFHJl;
        }
    }

    if (yITEIhCc == true) {
        for (int pxtzMkTdg = 585205534; pxtzMkTdg > 0; pxtzMkTdg--) {
            JWRWxqu = JWRWxqu;
            kYitZdw = nFKvLk;
            SwyeX = SXjgSQyHQ;
            thqxooyXWPcBsi += kvulTZbnLi;
            kYitZdw = nFKvLk;
        }
    }

    for (int uIhsk = 1216350983; uIhsk > 0; uIhsk--) {
        SXjgSQyHQ = ! kYitZdw;
        nFKvLk = ! nFKvLk;
        nFKvLk = ! SXjgSQyHQ;
        pYyhhAw *= KCCeTuFNBplvFHJl;
        SwyeX = SXjgSQyHQ;
    }

    for (int GkTFoLWVBu = 77710570; GkTFoLWVBu > 0; GkTFoLWVBu--) {
        SwyeX = nFKvLk;
        kYitZdw = ! nFKvLk;
    }

    for (int FiWBjZrWQdrM = 1081607773; FiWBjZrWQdrM > 0; FiWBjZrWQdrM--) {
        SwyeX = SwyeX;
        SwyeX = ! nFKvLk;
        kYitZdw = SwyeX;
        pYyhhAw = JWRWxqu;
    }
}

nIdUMqGvxEbtWrqX::nIdUMqGvxEbtWrqX()
{
    this->wvdLiriGdZBeNgr(-2063019873, string("AgUVROzsmSuyMupWizfBOMXPUfnVArTZLjEzJaoHCOGWUjStubsWVkcKivrvHLhxYLqugMGYYhsRoWSPecmnUBixsodLkOGUifoKvDUeJEXVa"));
    this->UPJirdzxQSFlXA(true, string("wuAzuTkqueSK"), -280541.39899482403);
    this->TBnLMkksJ(false);
    this->vPVXDQaHIEZbl(-1280527927, false, -907402.5575064272, string("EuZqayOZUnUkFzyYWEybenqnDxoVllJzrweSYHqSBcOJZznXikYoPtPPOFBPzilgEumsfpeMEPJcNLGhMBPxsrKdpFacEqkyzhHoyUQmJtD"));
    this->yJJfAyptwlEQaj(false, -1691458615, -510240258, true);
    this->bSTkiiiXcUWgL();
    this->cPgdLGO(true);
    this->bHCCJnQvW(917249701, true, -755503646, true, -896723.7735043749);
    this->HfJbiIEoVPE(false, string("cXXUbMchtkiukIkNDusWmUdieGnkoCoNorMqoYWDBJhzjQHceZGiMHlZokpmDajylQjlspvmUeuJuAMQSushYGzIWULuCpYtXCtQitHyhEcPqljdZNUmmRiTk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pxUbQTz
{
public:
    double ocSogLEGvBqxdot;
    string IAgmUBrrtGIGdl;
    bool XtevMnu;
    int nRgvAjXWOJfeWv;

    pxUbQTz();
    string ylLaB(bool lIUQSS, double VThMbTmVJGuH, string YIkopPCMyJhGOjQV, string EPdCPcBCgVBNZpk, int BAQhqqHB);
    string tElDsvRrkfGNG(string DeKKHWP);
    string LErtNJKLWbBriPP(string zVCRqFokc, int bNPAufMRusOgCqI, bool IReIKvZLomGL, string LXqhCeB, string FaVKmIL);
    int ALJvw(string cAxKRgeWjftZFSi, int RQShSvLRbCKG, bool dATREerwF);
    int JtHSDodFvVSR(bool mCfaz, int SuwQEJfe, bool XNpmtOtZAuvuvSha);
    int IuYgxAiXdpWt();
    double epgTsjLc(int vdFZhwWtvH, int sWuCBraHDbxPWE, int GYQBqnZkNvXuAwZd);
protected:
    string tFnAkfXMVSXBbuIv;
    int yHpzafIrgvw;
    double TRGpeoNg;
    int wISoFTw;
    double sEEzeekIzLnQPf;

    void Bfwgxjrwe(bool TlAHEUrkWT);
    int CCPGTSPjdQAf(int YCPHXmCblpwmA, double pWCLohUQDzOgYa, bool TGgaRBbdmDsbBS, int IDRZeNGbIJJX, double NezsZb);
    double suHAWdClZH(int ZodmeeJsEt, int rMArPrTDalVvzCTe, bool iHnsCzHa);
    void ByCQdluGTSfZJwFh(int djopzrIqA, bool ptceawBvJHEeAC, string xPWHGhmKng, double bMZRIUhMMfoUifl);
    string XvkURBZjrZpxGl();
    double OHMvQORY(string LRjyGkxRvaO);
    void NoVFOomaDB(int yNWWHWZVcPURN, int VGWkVLdztjTLlwyM, bool fxsODvKyUvvxpf);
    void PVyOzTqLsgSdMv(bool QpgHqwxNkbRkvp);
private:
    double CbYif;
    bool CJwVGeLvhFG;
    string aVkyjS;

    int lQvkjRvWMgSRZQK(double ooysDSsmKXXJbtON, double hGQLOOHIHQDur, bool PTtIefTw, int wvZAGGaB, double BHoUOikIt);
    bool mCetQPcsj(bool HpymisG);
    void IHePTdNqeTtRp(int gUABnIscH, bool biexzU, string hxerL, string UNacFcG);
    bool LIWKDsvhY(bool XteVkyS, string bQRbdRKhYLp, double sqAizaHtDHwKS, double OVCQMiQQanPB, double nitvRBnStz);
    bool ABDeOYaBPcYCZffo(bool mvWkqvIQBHkREK, string KXurgUMX, string IiNTx, int XeLvmYOUweNA);
    double dtJFgYmekJrhlRX(bool rfPLaVO, bool qYObUW, string NfOOf);
    string VBvmaTnHdXLN(string lIQoRNvgax, string cvjXqbICpXJXfTVB);
};

string pxUbQTz::ylLaB(bool lIUQSS, double VThMbTmVJGuH, string YIkopPCMyJhGOjQV, string EPdCPcBCgVBNZpk, int BAQhqqHB)
{
    string pykKTh = string("FhAnFJPBQSWMdvDbBPzrDgeeiSRqMAxKDSiaytbwVeIqALDLyCOEvjWhnBmGfdRGruvBmazGMTuyoYhGvNAvryTYuxqXKbrTMucCmIEiSNYgptKMuFxAonqViRaoBMGSARYEUatGufmbzDHwunKQcRvpgjtQnIIYUBUbZfYoEzcsImzIINPloXhEePIZYPoLUgtIzmMZnycHCzUTXKhkxUWyBWFTtacYnOhwuJaZSRRRRfpplKHpvpQHItnQSHH");
    int qalFxVRWEormAKwa = -9189572;
    bool LuGPobCyWaj = true;
    int eQKXaZHOF = -140322256;
    double HuONBKtSc = 873029.5570501216;
    bool nawUdNFFcZloFaS = true;
    string JhEtvQb = string("JcydhGObqKNrKHuSdfmFtVyoPfxzeGVXAJNJxsuTTDfHevscLFHoiBqwEVhSYoFPiYPzrkfrlOSqqEqOAsPRMXbPDewKrmFQLhhXOKyqQTsvcTLbzJtebiPCYCGvuPuJBLoXGjXMJxerawsunwiZRYcrWguzLSnkvzaUXJ");
    string pcNLAcLk = string("dhQLCGCtbXyvURWkXVRnJXmzrSvoSbyvZXQcXHlZsflDjejTPuFPStYOWNbqdbQlcXoYHfKksjDZSaWBVUxGZrImXHWnbmPxlQtfRrFtYBtlgWAGlrQiaJUaTKBrWFfEomaqnpdcvKVyNFPhyhyZZOZbalPAKeMzWFOSaCcDWXkGdxjsXukrIFsxiweHlXMPxbQupXmgYdohtPqYGRvcqLJxNvQghfGPnigQvEUiPSzkZER");
    string NkfpaHFp = string("LWGefajoTFBgYKHSHUmPpwEIhhRGKIlRwhltaXTJARSEkdFZAOzIisIeZWuXFifCaKDlyZEecTcJANqeuruDLCJCLCDzXcSOoeYuYAPjEqBMtZmidtWYGcfdHMeskwDXTIeLYVVAAtNjprAIyWotqMQchcWOAmaxYjpUdLifCra");
    int gcKXkzZpG = -859582892;

    for (int HKQyZkw = 1952280194; HKQyZkw > 0; HKQyZkw--) {
        EPdCPcBCgVBNZpk = NkfpaHFp;
        pykKTh += NkfpaHFp;
    }

    for (int tSOqrZz = 1111647291; tSOqrZz > 0; tSOqrZz--) {
        gcKXkzZpG = gcKXkzZpG;
        YIkopPCMyJhGOjQV = YIkopPCMyJhGOjQV;
    }

    return NkfpaHFp;
}

string pxUbQTz::tElDsvRrkfGNG(string DeKKHWP)
{
    double qbAWnlOI = -831121.5058410948;
    int bAIhhwsmYsH = -337783347;
    int sjhVsTVBXJZOxLt = 2108375512;
    bool gEaErNIv = true;
    int btAdzJXXXCSQSH = 2069166674;
    double VtoOvyXjkqz = 759592.8956199152;

    for (int JHrwWYWSLfm = 392340029; JHrwWYWSLfm > 0; JHrwWYWSLfm--) {
        bAIhhwsmYsH /= sjhVsTVBXJZOxLt;
        bAIhhwsmYsH = bAIhhwsmYsH;
        qbAWnlOI *= VtoOvyXjkqz;
    }

    if (DeKKHWP != string("ByuhOrtUmjiEsgWmDqyhukfukUTZIDLABLVaUILJZMxhFmSLNHyxVYmbcJXxtrgiAGXNoThflBkFXUxBgUvdGATuX")) {
        for (int gSKyLSdPwBU = 158322891; gSKyLSdPwBU > 0; gSKyLSdPwBU--) {
            sjhVsTVBXJZOxLt *= sjhVsTVBXJZOxLt;
            btAdzJXXXCSQSH -= sjhVsTVBXJZOxLt;
            qbAWnlOI -= VtoOvyXjkqz;
        }
    }

    if (btAdzJXXXCSQSH > 2069166674) {
        for (int ixHtCcS = 1101377585; ixHtCcS > 0; ixHtCcS--) {
            sjhVsTVBXJZOxLt += btAdzJXXXCSQSH;
            sjhVsTVBXJZOxLt = sjhVsTVBXJZOxLt;
            qbAWnlOI *= qbAWnlOI;
        }
    }

    return DeKKHWP;
}

string pxUbQTz::LErtNJKLWbBriPP(string zVCRqFokc, int bNPAufMRusOgCqI, bool IReIKvZLomGL, string LXqhCeB, string FaVKmIL)
{
    int mUbSYxOYjaYoIc = -1202584261;
    int gBgxNcf = 21515839;
    bool lXbTesrnKC = true;

    if (bNPAufMRusOgCqI > -1202584261) {
        for (int jbwCKc = 1868730360; jbwCKc > 0; jbwCKc--) {
            LXqhCeB = zVCRqFokc;
            gBgxNcf -= gBgxNcf;
            zVCRqFokc += LXqhCeB;
        }
    }

    for (int fNjdogZu = 38650641; fNjdogZu > 0; fNjdogZu--) {
        gBgxNcf = mUbSYxOYjaYoIc;
    }

    return FaVKmIL;
}

int pxUbQTz::ALJvw(string cAxKRgeWjftZFSi, int RQShSvLRbCKG, bool dATREerwF)
{
    double ExIVSNVkllRQ = -124200.9703209257;
    int RTopwRzIvYKf = -100263434;
    int ykMRaBpXXbIuK = -384415475;
    double ViFxuHVgvJgBiDR = 865496.079112515;
    bool xHYXbZGTCXlvv = true;

    for (int HZIeOAu = 1007864098; HZIeOAu > 0; HZIeOAu--) {
        continue;
    }

    for (int EjXXwVZF = 42163091; EjXXwVZF > 0; EjXXwVZF--) {
        continue;
    }

    if (ykMRaBpXXbIuK < -100263434) {
        for (int dMynNEMXvKkCekC = 50000060; dMynNEMXvKkCekC > 0; dMynNEMXvKkCekC--) {
            continue;
        }
    }

    return ykMRaBpXXbIuK;
}

int pxUbQTz::JtHSDodFvVSR(bool mCfaz, int SuwQEJfe, bool XNpmtOtZAuvuvSha)
{
    bool tWDFVhrepfYdN = true;
    int rXTenhSZwn = -1172667914;
    string pUYBceySwLIIOH = string("GFeGiBySezwEaocWipzCATTkVReitxSZzacjtFugtXwgYYUtFrCaIjG");
    double jiRtsbkmLraltpau = -338362.5719512267;
    int jCnrbQOYPlYIT = -1558618906;

    for (int UNxfTihBhyWuxoZ = 777478688; UNxfTihBhyWuxoZ > 0; UNxfTihBhyWuxoZ--) {
        continue;
    }

    for (int RiTUEqVVMSIaBNti = 819703186; RiTUEqVVMSIaBNti > 0; RiTUEqVVMSIaBNti--) {
        tWDFVhrepfYdN = tWDFVhrepfYdN;
        XNpmtOtZAuvuvSha = ! mCfaz;
        mCfaz = mCfaz;
        tWDFVhrepfYdN = mCfaz;
    }

    return jCnrbQOYPlYIT;
}

int pxUbQTz::IuYgxAiXdpWt()
{
    int GmluE = -184357430;

    if (GmluE >= -184357430) {
        for (int YysXVLmMX = 182457391; YysXVLmMX > 0; YysXVLmMX--) {
            GmluE -= GmluE;
            GmluE = GmluE;
            GmluE /= GmluE;
            GmluE -= GmluE;
        }
    }

    if (GmluE == -184357430) {
        for (int YINSfCmp = 1297791877; YINSfCmp > 0; YINSfCmp--) {
            GmluE *= GmluE;
            GmluE = GmluE;
            GmluE += GmluE;
        }
    }

    if (GmluE == -184357430) {
        for (int nzFNKKyzEjXuZt = 424973152; nzFNKKyzEjXuZt > 0; nzFNKKyzEjXuZt--) {
            GmluE -= GmluE;
            GmluE = GmluE;
            GmluE *= GmluE;
            GmluE = GmluE;
        }
    }

    return GmluE;
}

double pxUbQTz::epgTsjLc(int vdFZhwWtvH, int sWuCBraHDbxPWE, int GYQBqnZkNvXuAwZd)
{
    int bADfXVvgERhiRX = -1639272523;
    double ANxYEflEzT = -465553.020500606;
    bool VvWrHIcIVGXmBZPA = false;
    string IKDFlDWg = string("gTKWCWutTIuxyuEMSmrWESpYWwVTpIMILllCnSrBAqejJzHrPggpzNOiISuOHduRdOdKPFftgQYSjJfyayFQopTCNSuaWzEGHvfdDmaJKvdtQboiwTgavUPAmdGIRKVELuLyParsptccfsxVUdtwEbqrfUibRvdsSZGA");
    bool vvnctBDC = true;
    bool CjFVuIreej = true;

    if (sWuCBraHDbxPWE != -2143170989) {
        for (int DtSqjXZiQkNzYhy = 541717890; DtSqjXZiQkNzYhy > 0; DtSqjXZiQkNzYhy--) {
            vdFZhwWtvH = GYQBqnZkNvXuAwZd;
        }
    }

    if (sWuCBraHDbxPWE > -1230480510) {
        for (int QsLUyO = 2139697395; QsLUyO > 0; QsLUyO--) {
            continue;
        }
    }

    if (vvnctBDC == true) {
        for (int DPqxEiUdc = 1714079677; DPqxEiUdc > 0; DPqxEiUdc--) {
            vdFZhwWtvH = GYQBqnZkNvXuAwZd;
        }
    }

    return ANxYEflEzT;
}

void pxUbQTz::Bfwgxjrwe(bool TlAHEUrkWT)
{
    int EIIhcWdrsIMYfu = 1157568894;
    string ARnrXuffG = string("CQkbXsLUAuPRlNgoFycVwghqQfroOgR");
    bool NexglIPZ = true;
    bool xxSHB = true;
    string xQOaIoZcpaP = string("UEmdLAGeuUFXwLYrqJfXucJgfRZIzMqAfiBbxYsoSJYYwhNqDYjXnzdJmMRWRgoCtpfqtixazNWiRylWjyhwkGbOcDiyiV");
    string cWGRgwqlM = string("sFUTHUUgbrMZoKEGmTeBjwrToioRsySIAzScTDDjfuhxqPDvnRKcIWcatfwhnIvBjUEIJIdkcCFQRRBtFnIyzYMMLXWKFDMMIBASRmUsuQeftVFXjckwEsQJDbzZPDwmvmtlSHZpGZBCUymCsgGtKWCBso");

    if (NexglIPZ == true) {
        for (int PZmEvtcC = 967674365; PZmEvtcC > 0; PZmEvtcC--) {
            xxSHB = ! NexglIPZ;
            EIIhcWdrsIMYfu /= EIIhcWdrsIMYfu;
            xxSHB = xxSHB;
        }
    }
}

int pxUbQTz::CCPGTSPjdQAf(int YCPHXmCblpwmA, double pWCLohUQDzOgYa, bool TGgaRBbdmDsbBS, int IDRZeNGbIJJX, double NezsZb)
{
    string SXAwUwjYIE = string("bKXJYjguGCYBOCAvLmahgtkeRrHNoRAdFJyqFbDVwMlDRDFSFcpckleSSsSCjqLprykXpCMAfFOLCFphXqJqjhVWThSkfbWaIOUXCEmdWPQyNZOXFGUFeuChGCExkITqjXeLCeGylUlV");
    string ybkspc = string("UHCUfYvLjWfTvKfkmUTaMmuqgrQubfyyDKeCbuGdPMcmIUVckqXqFKYelBmyYbMnFbjLBen");
    bool zaiJOZkExrHvI = true;
    string CHHzHHI = string("gbpvFanLcsehxZglNgIbJACBaTeQYBAXCXgSJYizqlQEmNGLMoqoHZFpBkPnVZvFYdEdPpvkVlMydxFNkKApaWRfwrizGENLMSr");
    int mfENkTfgI = -532089375;

    return mfENkTfgI;
}

double pxUbQTz::suHAWdClZH(int ZodmeeJsEt, int rMArPrTDalVvzCTe, bool iHnsCzHa)
{
    double aknJqXVNjXyYGQej = 1045073.2121673288;
    double emwoGus = -288301.1959978505;

    for (int qBsLrgsx = 526560929; qBsLrgsx > 0; qBsLrgsx--) {
        rMArPrTDalVvzCTe = rMArPrTDalVvzCTe;
        aknJqXVNjXyYGQej += emwoGus;
        aknJqXVNjXyYGQej += aknJqXVNjXyYGQej;
        aknJqXVNjXyYGQej -= aknJqXVNjXyYGQej;
    }

    if (rMArPrTDalVvzCTe >= 790101034) {
        for (int zRaurwmSqUVWHf = 1959429810; zRaurwmSqUVWHf > 0; zRaurwmSqUVWHf--) {
            aknJqXVNjXyYGQej *= aknJqXVNjXyYGQej;
        }
    }

    if (ZodmeeJsEt == 790101034) {
        for (int ESybfKJhymQ = 1373058990; ESybfKJhymQ > 0; ESybfKJhymQ--) {
            iHnsCzHa = ! iHnsCzHa;
        }
    }

    for (int NphaiL = 1103677470; NphaiL > 0; NphaiL--) {
        rMArPrTDalVvzCTe /= ZodmeeJsEt;
        rMArPrTDalVvzCTe /= ZodmeeJsEt;
    }

    for (int kSeIjpVUqVHCKkH = 317126809; kSeIjpVUqVHCKkH > 0; kSeIjpVUqVHCKkH--) {
        continue;
    }

    return emwoGus;
}

void pxUbQTz::ByCQdluGTSfZJwFh(int djopzrIqA, bool ptceawBvJHEeAC, string xPWHGhmKng, double bMZRIUhMMfoUifl)
{
    string ZZxuJ = string("xHNpYJXcuEqSUfvaOLurZWZqamUmvioHNfLXkQisRSvINxcCpS");
    bool uitanTUgOy = false;
    int kiNgOb = -1141216643;
    string cZwcPVXYoMlmUIFu = string("PgBnJSeJcdolzIbvYvARaUmjiEiObTNdyuaqVjmZdRbXcfwZXWPPzKSLDFUiSooeqyakXNuaIXMFXssSCwmReXA");
    string rIJJrXlEKtg = string("wHRxEaxAbSBCuXOIoTOIXQrttyqkuoNpPEJowAQXqjhYJgIXoldysLDkdugpbYiZwPCbtglCmLoKHjMyljXSJkuDYASgKjDtlEMkPUnVBfhNhDzfwlbQcYrWqlQtglUzorPAhddhhlVJXjVsgvBnMUsXzkrtfNeijxIsPIsdzjvOvkpknoMMNxRJADFHkHfCMMucfkYINyjzAQgsLjAGQDCioKXdeTnCqEGwDpeAXc");
    int tJtnDfhDEgpQdG = -1723535401;
    double xOVxVpXnm = 848830.3251478962;
    double IylyhZUqk = 106372.3296343022;
    bool eprfDcJUI = true;
    bool BKFNsJRjX = false;

    for (int FkNyJlBG = 1974627555; FkNyJlBG > 0; FkNyJlBG--) {
        continue;
    }

    for (int nFiRwkdbopKFDa = 1913058870; nFiRwkdbopKFDa > 0; nFiRwkdbopKFDa--) {
        xPWHGhmKng += ZZxuJ;
        xPWHGhmKng += rIJJrXlEKtg;
    }

    if (uitanTUgOy != true) {
        for (int hYVAKUxhNxfY = 1006669469; hYVAKUxhNxfY > 0; hYVAKUxhNxfY--) {
            kiNgOb /= djopzrIqA;
            rIJJrXlEKtg += ZZxuJ;
        }
    }

    for (int NtBiuScsjzG = 1431582626; NtBiuScsjzG > 0; NtBiuScsjzG--) {
        continue;
    }

    for (int vJTXSCTZhYBg = 738637393; vJTXSCTZhYBg > 0; vJTXSCTZhYBg--) {
        rIJJrXlEKtg = xPWHGhmKng;
    }

    for (int NwjkIXOcqrIS = 30541471; NwjkIXOcqrIS > 0; NwjkIXOcqrIS--) {
        IylyhZUqk -= xOVxVpXnm;
    }
}

string pxUbQTz::XvkURBZjrZpxGl()
{
    bool GiHGlUyKnTJuZVr = false;
    int ICwChBnEo = 1792172378;
    double KlwobzOyufOwWDmv = -607993.8879424415;
    string daBidUW = string("lUbpKAhUtHhjIDfmSMLUocZGpxitORHSvpSdxRgilKCquvpiAYNlWbpwueatyHMoskXDgfHyrowQGbZPjZLkfnciFUsAVcCgKSbEJIL");
    string zVDNGAeYfSMCw = string("lkXXqPURjmrOHKWzpAAGBxjskiwuAiZjKrTOVrAaYbdSlJkPvvhVfDUUlnqlBBuzdpOxVBDXGPwcKrhOKrIflNoVgaDOFrplsPmZiugPzWTliJxurzTvAUQqdiwjhjjxJaezmJfZzoqoLSWMiLwgynHWzxnoYNcTwATReeoMmcEXvdNswBZJnviwAtFEUKHbpwOYWvOKgTIgRZOGBERvrfLYYoUBu");
    bool tqPpEXGnQMzWNK = true;
    int xVmPvgaKkZ = 1029194861;
    int WFXINZTndJPStZDc = -371432025;
    bool YfKZxMKJXVtaLwzu = false;
    string cjbBvJOL = string("pSnOMQExegoyiLKX");

    for (int cGZmR = 1048126552; cGZmR > 0; cGZmR--) {
        cjbBvJOL += cjbBvJOL;
        GiHGlUyKnTJuZVr = GiHGlUyKnTJuZVr;
    }

    return cjbBvJOL;
}

double pxUbQTz::OHMvQORY(string LRjyGkxRvaO)
{
    string IPznKHFMGo = string("bFOArJTpLfMisCIDaRYYBQkMPzyVIkETSxVKxmFOxABPrEjfZZyRJnwisNucLvnEnLPTvEYpLjaUsFBeEjichBMraeqAfgQHkvIUYMAAMYYkVXzbdwSpsBWVIshAvnGfj");
    bool tsMBGuUZQiiZN = true;

    for (int zMvnI = 793896703; zMvnI > 0; zMvnI--) {
        LRjyGkxRvaO = LRjyGkxRvaO;
        LRjyGkxRvaO = LRjyGkxRvaO;
        tsMBGuUZQiiZN = ! tsMBGuUZQiiZN;
        IPznKHFMGo = IPznKHFMGo;
        tsMBGuUZQiiZN = tsMBGuUZQiiZN;
    }

    return 96157.7654218869;
}

void pxUbQTz::NoVFOomaDB(int yNWWHWZVcPURN, int VGWkVLdztjTLlwyM, bool fxsODvKyUvvxpf)
{
    int CHriCCxtq = 1199417619;
    bool ttuHhJVjiOgIv = false;
    string UhoDoHTerGN = string("swHOsRqcDTljOBjwyidaKsfHFZLNGNiZjgHdYRDQNkFbjIODYruENSnvHpTEbFBYyceObRYTeXXVbatErHmsoonxedZqMKaLbvbWguDxlNVKiLLWQLzbhOYLpLbNwhhFVvuGPwufHYfZinlXCXjOqkBozgii");
    double jAwdE = -909786.5588765402;

    for (int PFHPrCL = 73835128; PFHPrCL > 0; PFHPrCL--) {
        fxsODvKyUvvxpf = ! ttuHhJVjiOgIv;
        ttuHhJVjiOgIv = ! ttuHhJVjiOgIv;
        yNWWHWZVcPURN *= yNWWHWZVcPURN;
        CHriCCxtq /= yNWWHWZVcPURN;
        VGWkVLdztjTLlwyM *= yNWWHWZVcPURN;
        VGWkVLdztjTLlwyM = CHriCCxtq;
    }

    if (VGWkVLdztjTLlwyM < 1199417619) {
        for (int QwscHoXUYffVQZg = 1437157111; QwscHoXUYffVQZg > 0; QwscHoXUYffVQZg--) {
            continue;
        }
    }

    for (int BqojKONAFFgPTw = 1379409969; BqojKONAFFgPTw > 0; BqojKONAFFgPTw--) {
        fxsODvKyUvvxpf = ttuHhJVjiOgIv;
        ttuHhJVjiOgIv = fxsODvKyUvvxpf;
        ttuHhJVjiOgIv = ttuHhJVjiOgIv;
        yNWWHWZVcPURN += VGWkVLdztjTLlwyM;
    }
}

void pxUbQTz::PVyOzTqLsgSdMv(bool QpgHqwxNkbRkvp)
{
    string NBxeqjKU = string("nTukuQasoIBaRRBvryJKWSigcnzsWWyPLEZdBTfkEzTeQMqedrUrzgSKjanNEZTrSCuVNzsvFThiVJIiDOuMrUSSKXetNVbuSBVtcCLYYTtVBaoZqHc");
    bool snBUWuL = false;
    string zjYwLyGt = string("ejCxDJmkYSrHhLSqrRGpMnhsVyLDvfikvWFzIPmsyyLWDOzAztGCLfEIzVcGiNqcrnCbCdJZfEMfUycJeXFTArYvQOVxUsrkwmIPhzYqnFZfpcQMlPYYxSrvPpByyYyWRaresjoCBFOiYXrbCKsHkuITrBHooayFuWnoHoDmTEhmTpHBRkqOPfWu");
    string uRdOBA = string("yPbAaXpJJyMtHeKQANAmmPnwbJDZfGgjEgdhAnoNnDbqyURNFUBHjsNBZBcFZTWduhoefeUqtjwYVwVpEQsTgwpJMPjVVxFvoWffNUABwkMNTIHWEjoUzmOCUUihBlhMgijQjVmiUeAScvUalTfoYAumJgTIGAGMDOZEdOZejvyULDunWdUPFKKoJIURqPSYzgErfCe");
    double dVvrsBL = -601452.262282878;
    double gjOlhrFk = 565518.0379174931;
    double FeEsSNJ = -242689.72992636738;
    string ZURGvK = string("DtaPklXnVjiSponhIKikxVupgYJvWwycauHqw");
}

int pxUbQTz::lQvkjRvWMgSRZQK(double ooysDSsmKXXJbtON, double hGQLOOHIHQDur, bool PTtIefTw, int wvZAGGaB, double BHoUOikIt)
{
    string wYtGQnrsJrFmU = string("syEmGuKyPl");
    int LHIhnQNfT = -1072882888;
    int gzgCJIdGSgtKFL = 945659485;
    bool xlSbGqMiV = false;
    string QoIwnmrRQiCfDUn = string("BfmoBGOSzrMwGyzzyPSiUJVjQnbxtaKDBcMMzolhpjmSJHOTlIYGPInGZtHGgMkOwJgJFUWcTUqnMMCvkTlUIwPmTcDcXlaLPGwVrxVTmmkzcAdOOvikAgnRFHGCRiBDdyDt");
    bool jMpjeCpRbq = true;
    bool OqILQaNqhUR = false;
    bool cJxlat = false;
    double lCbwLrLK = 870629.2758661658;

    if (BHoUOikIt >= 147690.75000436182) {
        for (int zVGFORUr = 254787187; zVGFORUr > 0; zVGFORUr--) {
            PTtIefTw = OqILQaNqhUR;
            OqILQaNqhUR = ! OqILQaNqhUR;
            PTtIefTw = ! cJxlat;
            wvZAGGaB -= gzgCJIdGSgtKFL;
        }
    }

    if (wYtGQnrsJrFmU <= string("syEmGuKyPl")) {
        for (int sJmxn = 1571997085; sJmxn > 0; sJmxn--) {
            continue;
        }
    }

    for (int VXrIjykAAayE = 217922100; VXrIjykAAayE > 0; VXrIjykAAayE--) {
        continue;
    }

    if (jMpjeCpRbq != true) {
        for (int XFDeRCYpYpmJfDn = 929579135; XFDeRCYpYpmJfDn > 0; XFDeRCYpYpmJfDn--) {
            jMpjeCpRbq = ! PTtIefTw;
            xlSbGqMiV = cJxlat;
        }
    }

    return gzgCJIdGSgtKFL;
}

bool pxUbQTz::mCetQPcsj(bool HpymisG)
{
    bool NsSgUldFR = true;
    double jNQuclvlJdwpmq = -535665.2019492387;

    for (int sDtiGCvs = 949279406; sDtiGCvs > 0; sDtiGCvs--) {
        jNQuclvlJdwpmq = jNQuclvlJdwpmq;
        NsSgUldFR = ! NsSgUldFR;
    }

    for (int CtkQPbcigtEaRXH = 776732272; CtkQPbcigtEaRXH > 0; CtkQPbcigtEaRXH--) {
        HpymisG = ! NsSgUldFR;
        HpymisG = ! HpymisG;
        jNQuclvlJdwpmq -= jNQuclvlJdwpmq;
        jNQuclvlJdwpmq /= jNQuclvlJdwpmq;
        HpymisG = ! NsSgUldFR;
    }

    if (HpymisG == false) {
        for (int RjHCiVzTv = 228448698; RjHCiVzTv > 0; RjHCiVzTv--) {
            HpymisG = ! NsSgUldFR;
        }
    }

    return NsSgUldFR;
}

void pxUbQTz::IHePTdNqeTtRp(int gUABnIscH, bool biexzU, string hxerL, string UNacFcG)
{
    double RAdXzldTjglvODp = -603559.1194390813;
    string HmukPUzHJDF = string("OOJWSvRZLazBYsDGsmTegiQsarxbpZjxrXznCEGCbAPmJxfwHeNfafevMeBTzbyauHvywipwkoWYmVnKABAYNIprLymcInwWCVdYbEuQOnLFUNvrrwhhGyhnogQWPvKVqltLtmRDjHkVdSKgTdvOWZwKHrVSkJuVkCWxyGtWUrYBVUPCzvZJGpLXFCuUUyGVdAiDxXAoTBnFASktSKYDzceEWK");
    string wMnltVKuIBxXm = string("sdqndGCQnqNVcRyXzmxjRBI");
    int axViZCvOBBnGeAyo = 1416730491;
    string OUzKEIiqpHOTvVic = string("oieAiQWeyPDiyAdmvMMMRFqsqrGdUhUewyTGclGQYqLaxLiZlXvjrUlbPlqzsejMfFjXwKGjqvSvSCBwKRXhxKYhlWwmUURtioAHnVMELQPzMqKzRnjMUGAayPnddEedVLeDKYeveSVBbOVWMpVrRrYaXsjKRLupcAuTwqTQthneVmcAjc");
    bool UsUAXXE = true;

    for (int MsuMqse = 274650155; MsuMqse > 0; MsuMqse--) {
        UsUAXXE = ! biexzU;
    }

    if (biexzU != true) {
        for (int PqOfUpA = 1473238488; PqOfUpA > 0; PqOfUpA--) {
            continue;
        }
    }
}

bool pxUbQTz::LIWKDsvhY(bool XteVkyS, string bQRbdRKhYLp, double sqAizaHtDHwKS, double OVCQMiQQanPB, double nitvRBnStz)
{
    double JfcyKjSptt = 714261.4549108266;
    double nRvetidOFMDiWG = 373118.49644127995;
    int UqkIIa = -1302222421;
    int gmTGzkfGFCbgDCP = -2008492962;
    double ySZSzOgMLDLX = 933519.080090609;
    string aUojTZnu = string("ndOLfsCqQWTcNhWBruJAKYOmMRVzlwWiJnckriaUDfJHItPATNtchIMMivnmWjQkPu");
    bool gqXfUrOLkL = true;

    if (nRvetidOFMDiWG > 933519.080090609) {
        for (int MPuNeuATO = 908653676; MPuNeuATO > 0; MPuNeuATO--) {
            JfcyKjSptt /= JfcyKjSptt;
            nRvetidOFMDiWG /= nitvRBnStz;
        }
    }

    if (OVCQMiQQanPB < 996525.7023282311) {
        for (int VdmUMiARXAWnDk = 111066605; VdmUMiARXAWnDk > 0; VdmUMiARXAWnDk--) {
            aUojTZnu = aUojTZnu;
        }
    }

    if (ySZSzOgMLDLX < 933519.080090609) {
        for (int bsloardWRCewrN = 1284869363; bsloardWRCewrN > 0; bsloardWRCewrN--) {
            sqAizaHtDHwKS *= OVCQMiQQanPB;
            sqAizaHtDHwKS /= nRvetidOFMDiWG;
            JfcyKjSptt *= ySZSzOgMLDLX;
            OVCQMiQQanPB -= OVCQMiQQanPB;
            ySZSzOgMLDLX *= OVCQMiQQanPB;
        }
    }

    for (int RrfrqKqSCGqbQ = 462111672; RrfrqKqSCGqbQ > 0; RrfrqKqSCGqbQ--) {
        nitvRBnStz *= nitvRBnStz;
    }

    return gqXfUrOLkL;
}

bool pxUbQTz::ABDeOYaBPcYCZffo(bool mvWkqvIQBHkREK, string KXurgUMX, string IiNTx, int XeLvmYOUweNA)
{
    bool qzKEKeJd = true;
    double ValVJcHa = 786527.3355550179;
    bool qgMZiWLhQUWUfht = false;
    bool kqASVcHJyb = true;
    bool fLwEpOBGNypjMqps = false;
    bool uxXdenkfpqHKtdFa = true;
    bool INKyZrdYZee = true;

    if (INKyZrdYZee == true) {
        for (int zkMOO = 491081406; zkMOO > 0; zkMOO--) {
            continue;
        }
    }

    if (mvWkqvIQBHkREK == true) {
        for (int JWMqcysNSLJU = 1609592470; JWMqcysNSLJU > 0; JWMqcysNSLJU--) {
            kqASVcHJyb = ! fLwEpOBGNypjMqps;
            kqASVcHJyb = ! uxXdenkfpqHKtdFa;
            fLwEpOBGNypjMqps = qzKEKeJd;
            fLwEpOBGNypjMqps = mvWkqvIQBHkREK;
        }
    }

    if (qzKEKeJd != true) {
        for (int soKnh = 1680624136; soKnh > 0; soKnh--) {
            INKyZrdYZee = ! mvWkqvIQBHkREK;
        }
    }

    return INKyZrdYZee;
}

double pxUbQTz::dtJFgYmekJrhlRX(bool rfPLaVO, bool qYObUW, string NfOOf)
{
    string iwuSI = string("FSXsv");
    double pdaDp = 237701.8096916439;
    string AOGfVHGrxIK = string("dovfbRNTYgegOZfKHAqKEhEelUKTUIDfFIvGHMLWibsIVxYmkySjBsNbqLCEnIJyKbXglptpjuSOFljTZekngrqjjtIBCkmOxBeOGrEhlBjiyksCowMQSfEWBT");
    bool VCYhvYzsUxnOA = false;

    return pdaDp;
}

string pxUbQTz::VBvmaTnHdXLN(string lIQoRNvgax, string cvjXqbICpXJXfTVB)
{
    double YosjQPPIw = 975.6102263421028;
    bool bomjcNnYDWciBvgV = true;

    for (int SYOFqnOPc = 1979173850; SYOFqnOPc > 0; SYOFqnOPc--) {
        bomjcNnYDWciBvgV = ! bomjcNnYDWciBvgV;
    }

    return cvjXqbICpXJXfTVB;
}

pxUbQTz::pxUbQTz()
{
    this->ylLaB(false, 926138.2426946952, string("IqzuKewKcWKSUQcquNhIttKVILrViMYKtJKPRsErenspPBDwFeKkQcuZbzVJotMlVkMZXsGAiLLEsiAXdsWDTMUXOqnPMFUyAKkehVmQTUlmqcubgOeZNNlvXsSivxGdkzQAGOOazlEUzXufzvejZwxLwrDrqpaE"), string("XYqo"), 926702105);
    this->tElDsvRrkfGNG(string("ByuhOrtUmjiEsgWmDqyhukfukUTZIDLABLVaUILJZMxhFmSLNHyxVYmbcJXxtrgiAGXNoThflBkFXUxBgUvdGATuX"));
    this->LErtNJKLWbBriPP(string("ZgkgOyCvySBLQnHRVizKCwOjghTUxpkJmWnzcpBidUzuHlfuCphaPvlrkxgLUmPIToExjIyNYXKufOeNojXttDbiJbYeHQQtXhtFSiVJqypyNKdPGDJtVnRMVfceVuAnqRYYtZabSoaosqSnvgFOcqLnLcnRhCxQeOAedumgMvknocOnjtxJzfMlKfOKgmDaDWrBKHhlZTJkSPuRRDsR"), 104696054, true, string("yerpAhzUXqDqJWFtxCecYNzGPtrBzZgaaEbatIijsnfBtpIfRxjUYAvTklaLlMNIrUzIUazLLcphCwGMdXNDgYpakkvbeWakmKIIAMfDHUcAKyvYMcopdmBdhGuVaTJqKGqEpLHmtsWixKvCtgNDzfPabeRwIvxiGCsgfEaueWtvxV"), string("lk"));
    this->ALJvw(string("rSikBHNwqSgROocfcQoXtiLjSFPzCydIhqCNuoxSHfKknGttbcWYYMREKqBQTjSgXAXgeSEMbCFgkckbwbhzHnEVCoXIGsWuzePgNWAAYryblJVcFOZKUjQIEBIkNagVnqdkBkCneXDSNzHyquatFSucxDiiIfeOFyMkhS"), -1435804426, true);
    this->JtHSDodFvVSR(true, 1887067330, false);
    this->IuYgxAiXdpWt();
    this->epgTsjLc(-2143170989, -1230480510, 1911157600);
    this->Bfwgxjrwe(false);
    this->CCPGTSPjdQAf(-681070518, 587407.992728676, true, -2038257941, -133569.50382251246);
    this->suHAWdClZH(790101034, 1471872765, true);
    this->ByCQdluGTSfZJwFh(1088136258, true, string("MyUQrNpVlTBTdZhLuTUjJGdeFWuWopRroByDgkxTHvQpRQPxfPEqTAeNyZsICOrtadGpLdGQypePBNBWTZVPtspjyObsxtcTEgZqkQwHpeeBgXaBmcFgiXLE"), 244905.61151157712);
    this->XvkURBZjrZpxGl();
    this->OHMvQORY(string("EXxBJXGKRxrSDCaHpVsqsWIVDclaH"));
    this->NoVFOomaDB(-1537988509, -1255053655, false);
    this->PVyOzTqLsgSdMv(true);
    this->lQvkjRvWMgSRZQK(147690.75000436182, -715417.4261796098, true, 1562302823, 435498.3252216188);
    this->mCetQPcsj(false);
    this->IHePTdNqeTtRp(1414542154, true, string("vxSZmAQoDXvVtJwHoXodBcmoUkMAY"), string("nbJPfjVMhRGGpcHaYPiYeIARqxsxtOVupBJjULbhOFVHjvPhsfcDyktNDIXnLrZGTZlQwNxBymceiONNERhbWEnjFqXuVHexKHAojfVJUGiAZoFOlPkWHFPzHQlfvdnGFPkwxRAiCnghdmkHSTlwbcaIGbcmIbRN"));
    this->LIWKDsvhY(true, string("DUXjPmzCIuPROcqfVUmfoyeukdZePvwRSKkQtmvgjAbAkYnYJvPSmSrLOIzOFhbrabWfCRdcKPIUePeDBmIkkJwcFnZWAcUOfVrGTmHVTwKBoYZVTdMpgohTCyzdFtFcZgMOFmzpOTGqttPNBfBLqJoByAMvKOZzbQjPgpPNKEPGfqrOYqDgShFIRAtR"), 1028370.2265893013, 996525.7023282311, -491856.1240309428);
    this->ABDeOYaBPcYCZffo(true, string("wkhMpAIdmaUBkYMHIVZDvNMJzbJEIYUeFDqfXOgJEFyiVleBBlyULDzCJSucbEaztCOsyEcLVOKoRZjCsiftXryYUZMmdhCYgCqjlhaXwDCcQWTaOuvYNtncfPzhD"), string("zHYokidVVZPWTDVbEeGDbWsnfmWJuULftBDALvDWOawMYUtbgrjObLkgwnbuaybQZAwAtNcgLeAoyXmBimUVzwIpEklDWLgLydkUFbHWIYdpccsBivtnUylSkojKxIEnDdYvLTTJkHRUmGCbbdVIhIEkjVfvZErMVYxxHecSpjJDhwjoyUjuanntnTkrxaQknxTknGIuaONIN"), -43448183);
    this->dtJFgYmekJrhlRX(false, true, string("IIjulrAjGPmPFYEIiIAVQgDipNLOCxyzmNwxrXFgJWqUYlFnTZupOrANdRyfmVqdApCgKy"));
    this->VBvmaTnHdXLN(string("cXsQbZvlazXmDKYaGmnEbSqYDufeMOWdszWwXMyceQeYoIbrdUkqBxJgbZcRIEpmqnIygVmInBalnjGKLwmruLzHtjpCjfcwODLvBhpXYCeFtMRYFCeUnFCwhykIZFzcBrwRJyleQ"), string("rvTAhqxGnRYoPUIfbwtCXggannOEMEqpBtmOnZHNDqCyNQOokdsVIAucYVfWOhWcDWeOsJDaePVAXZkQDIHEUquXnrNzpUTKR"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Whyfg
{
public:
    int mZlPImlC;
    int oJNgQ;
    string uWcRunTgkgHco;
    string GdizKnvUUkutcQtT;
    double ebfkQlOIQkgV;

    Whyfg();
    bool BpcrJrlvARpbgssE(string jNrDnDVP, int EqbTj, string QxfCrBAqubqU, double UlswDjqrfOU, bool gxAEv);
    bool UteCX(string RiHxKd, string faCBkujK, int FCrPYZpFMlx, int EZKFdtBx);
    double abgYdFFhBN(string nuktEONs, string LSUUcLY);
    void NSvlxvS(int IBpQANZJihg);
    double AIlsPfxzhgf(double CioaAbVonQVVu, bool WrEESTtIrfmM);
protected:
    string kERNCoMICPKFo;
    bool oWVUKcoiAMLRLQSV;
    bool pauIxckpFO;

    double SYvXWJYn(bool uLJfOpKJFRZ);
    bool HHCxE();
    string wiJcHurVyg(bool LhUNGVqZvq);
    double fOnKoNFSOgTODJuv(int ZMEjEgyIeOl, bool skpKsJWXafpHCWWM, string UgsduyemghN, int YJnhDoErRp, int cZaRlmzi);
    void EedDiQ(int XoozPaDTwhIeUB, int qNeqJLNEjqzcYF, int wyHoPHuAktjBf, bool rzZGSoiNly);
private:
    string sMpZcws;
    double tVZMuTQigEevn;
    double NAkKWpHTAbKbFPsC;

    void PKBChM(string NAsKdv, int MUvVIGbamM, int XvRgAIqD, double DnDGdFQmXBZnLI);
    double OufXQB(string hAHfg, double FpVPEnFafMUoKy);
};

bool Whyfg::BpcrJrlvARpbgssE(string jNrDnDVP, int EqbTj, string QxfCrBAqubqU, double UlswDjqrfOU, bool gxAEv)
{
    double STiaFoquZ = -591604.3606072374;
    string qqpCJ = string("GPjjtwjYGnvymjLQJYUBWWOAmkkutjMGpeDHeCgVQHbxnhQXxbTSttQSfQVZaLUcKFUElDQQSSPSoIGDASBLdakNUhwKbpHZyQyAChITezVeEmMTiTFmarYEtXswTDHBZMICUYmSAgRXEdbaBPUvkTxdwWIggAIxgoqbQlNreerXoMVYSjRJAoCDXgTXbMaN");
    string QWgqD = string("GOSlHcNqGPFPFzKRAgldpHFeVRRRECdKfNUIuUNuYGcsdveJsyiquIgbGBaHeDxJmEilZkGFvDImmJoQnuiZUzCTWwZUHfTmCdltUTZYzWZrSkxcghjKCUaXFrjWFcAxhJdWAsLfWMFuEarLgjdcAeHbKkwhKQpP");
    string ftcBLTXr = string("vTjyaEzLyuDSwQuTtNsmryFhSMtYKxJZOzZSeWjKxcbeYxmzmvhLkYSSYIBHQeJORXIiYwoecaiUdDFclGyBaSyUkDtZdPGPlGkcNQTBZxjesywVnhPZNEBhIrTMsrCsXPNoGpHEoZJedzuWGlzRSRJlGSjwczRlpnhhPB");
    int oymLUQUDuZvzZ = -268191289;
    double fmVXCOZUyNWHVWTa = -157104.44411901422;
    int wTqNjrS = 267866071;

    for (int JHgFfjhtVQJkYX = 622456467; JHgFfjhtVQJkYX > 0; JHgFfjhtVQJkYX--) {
        QWgqD = QxfCrBAqubqU;
        ftcBLTXr = qqpCJ;
        ftcBLTXr += ftcBLTXr;
        wTqNjrS += wTqNjrS;
    }

    return gxAEv;
}

bool Whyfg::UteCX(string RiHxKd, string faCBkujK, int FCrPYZpFMlx, int EZKFdtBx)
{
    double HRLwPJiOFcB = -1006439.8805675379;
    double byjvXBJ = 394097.4602575261;
    bool LkQRntYShGegSWfc = false;
    bool YiNbiRaM = true;
    bool plHCLhIpxtADvZ = true;

    if (EZKFdtBx <= -641580047) {
        for (int RqojLUtjx = 1680403966; RqojLUtjx > 0; RqojLUtjx--) {
            continue;
        }
    }

    for (int SSuDyhhiRC = 1065799192; SSuDyhhiRC > 0; SSuDyhhiRC--) {
        FCrPYZpFMlx /= EZKFdtBx;
    }

    for (int YfRKyEqjwLmGpNzE = 198206466; YfRKyEqjwLmGpNzE > 0; YfRKyEqjwLmGpNzE--) {
        faCBkujK = RiHxKd;
        LkQRntYShGegSWfc = YiNbiRaM;
        EZKFdtBx += FCrPYZpFMlx;
    }

    if (faCBkujK <= string("ExBoLlBeSsxvslOpqFvnNxVPbbHSgsqNjbhylxT")) {
        for (int IKszsEgwI = 1917549987; IKszsEgwI > 0; IKszsEgwI--) {
            LkQRntYShGegSWfc = plHCLhIpxtADvZ;
            RiHxKd += RiHxKd;
            RiHxKd += RiHxKd;
        }
    }

    return plHCLhIpxtADvZ;
}

double Whyfg::abgYdFFhBN(string nuktEONs, string LSUUcLY)
{
    int XSyHCZHFOyrBkge = -1286046434;
    int IKwvUQZp = -572406083;
    bool sMttXKWSQHyK = false;
    double FyiPikXNMU = -506599.5109169175;
    double RdWCVidoRh = 199894.782315549;
    int bUMlkRS = 1260536926;
    string cQRfRLncVBUmd = string("AOmiIDDdwBBcDtKQhEIhiJ");

    for (int xKEePI = 1731302449; xKEePI > 0; xKEePI--) {
        cQRfRLncVBUmd = cQRfRLncVBUmd;
        IKwvUQZp *= bUMlkRS;
    }

    return RdWCVidoRh;
}

void Whyfg::NSvlxvS(int IBpQANZJihg)
{
    bool DBMgbCvkCMCsZ = false;
    bool mtCHqnbNF = false;
    string QCByyx = string("fxSDhsQ");
    double vFyHjhW = -866666.7845808221;
    bool jzbrYqzZdDaDawH = true;
    double CbUdVVMcPoBd = 502665.64479898923;
    int FUyzatrDW = -295229859;
    string twnoB = string("cTRoXeGgaOPFoUfbxfWrCKHRWXzWeeFqlfdMqrwuudEglyPMIynRigKfqYEBEfRqqwuGggdjkGbbAEFFEVpQROLQmqGojyCmqvUNmeXDaGZpAddfTquisjqxzjIEocYhSSSVOwWJbyXUXixUkWsroKQeqpvzeh");

    for (int LTfbwujfuNAyXNp = 1738025341; LTfbwujfuNAyXNp > 0; LTfbwujfuNAyXNp--) {
        CbUdVVMcPoBd -= CbUdVVMcPoBd;
        DBMgbCvkCMCsZ = ! DBMgbCvkCMCsZ;
    }
}

double Whyfg::AIlsPfxzhgf(double CioaAbVonQVVu, bool WrEESTtIrfmM)
{
    bool gqJbCoXWdjmAm = false;
    bool JDlBZcxDK = true;
    double gOsYJoZjetXN = -2923.127940060529;
    string jzUGxFkYbuQBdhJN = string("CbcUJMdJybrpQHtJxvUZxukCekTdYxrLBebknbCoTdRRVucSXPKFZpqntwhcNfaaxMBicwAaklSwywJjMCALxBDhEFvcUNlTOqAuyYgxDSGnIetLBojtPXDqkkIDHniLJmUGOtvwdacWGNJULnenqamUGmheaBFXqbYCbIMgkVLe");
    int SVCMxNNON = -472827517;
    double zHRDBZNQ = -660053.3525531717;
    bool TdHSCqRhzQki = true;

    return zHRDBZNQ;
}

double Whyfg::SYvXWJYn(bool uLJfOpKJFRZ)
{
    double oUGexiFZdNWoBx = -438578.5409276434;
    double EvKul = -179884.8960899428;
    int BXWvclI = 1226962885;
    double eOPwty = 569633.7721269384;
    double uEXTVfpXLaDvMd = -974876.5327370907;
    int TDpMtmJJdbXgwls = -1126822098;
    int LlieKndzBybOmd = -319466186;
    double vKIYR = -325098.55796392844;
    double avoLRXwkfcqlL = -114901.0659571415;
    bool AAHuMzPaGfzemXEN = true;

    for (int TpZxfXiCd = 1344959588; TpZxfXiCd > 0; TpZxfXiCd--) {
        EvKul = vKIYR;
        uEXTVfpXLaDvMd /= EvKul;
        avoLRXwkfcqlL -= EvKul;
        uEXTVfpXLaDvMd -= EvKul;
        avoLRXwkfcqlL = vKIYR;
    }

    for (int NoGtkhu = 70604311; NoGtkhu > 0; NoGtkhu--) {
        AAHuMzPaGfzemXEN = uLJfOpKJFRZ;
        EvKul += vKIYR;
        AAHuMzPaGfzemXEN = ! uLJfOpKJFRZ;
    }

    for (int hWSHhOwP = 983073954; hWSHhOwP > 0; hWSHhOwP--) {
        avoLRXwkfcqlL *= EvKul;
        vKIYR -= avoLRXwkfcqlL;
    }

    for (int hRtecckh = 114502355; hRtecckh > 0; hRtecckh--) {
        BXWvclI = TDpMtmJJdbXgwls;
        uEXTVfpXLaDvMd += eOPwty;
        eOPwty /= oUGexiFZdNWoBx;
    }

    if (oUGexiFZdNWoBx != -179884.8960899428) {
        for (int PsPzAaFwaAWKJOs = 842553197; PsPzAaFwaAWKJOs > 0; PsPzAaFwaAWKJOs--) {
            LlieKndzBybOmd = BXWvclI;
        }
    }

    return avoLRXwkfcqlL;
}

bool Whyfg::HHCxE()
{
    bool HrkuVkByglzAY = false;
    int FGWxQjpIptyvHpy = 2123370931;
    int vclNuLyOvf = 1873736966;
    double MGeykIYkkhwr = -611610.4524271787;

    for (int gYMVgJvIDZIVZ = 2081210178; gYMVgJvIDZIVZ > 0; gYMVgJvIDZIVZ--) {
        MGeykIYkkhwr = MGeykIYkkhwr;
        vclNuLyOvf += vclNuLyOvf;
    }

    for (int QzfTYRKyukQBcb = 1868690300; QzfTYRKyukQBcb > 0; QzfTYRKyukQBcb--) {
        vclNuLyOvf *= FGWxQjpIptyvHpy;
        vclNuLyOvf /= vclNuLyOvf;
    }

    for (int qtqyXEYvVk = 969872924; qtqyXEYvVk > 0; qtqyXEYvVk--) {
        MGeykIYkkhwr += MGeykIYkkhwr;
        FGWxQjpIptyvHpy += FGWxQjpIptyvHpy;
        FGWxQjpIptyvHpy /= vclNuLyOvf;
    }

    return HrkuVkByglzAY;
}

string Whyfg::wiJcHurVyg(bool LhUNGVqZvq)
{
    double hlqQrPsQG = -267306.4150938967;
    double XlbaJaXQukU = 542203.0088104672;
    bool tfRVKN = true;
    string vxbtiBSk = string("OHHtDahczLhnmDcIRHvHbtqgZAiKkWDCFyRPyuISMImoBYgacAidpNdYOUxROxiNVyhGJrllxFguOFelCDpKkiXwYTITexvbL");
    bool mDrMzZWXdoFByiR = false;
    string mnzYzY = string("OnPGwhsHsNnBiUgLaujwNfYpFDhDODDAhrLFGrkyHezGblmSnVfPybaXhMakEUKLGYoanrbwZCucnXQncDMJPfEYnBioQeXvwhgHmOCctbrElGckafEzDtkQgAXVFiTgMxTvRvrnBfEPyalsDklDCFHryHEORNWQCQcUiVc");
    double LSzZLUD = 273334.71229745995;

    for (int klZqSvC = 991706254; klZqSvC > 0; klZqSvC--) {
        continue;
    }

    for (int sjHaqnZ = 241678456; sjHaqnZ > 0; sjHaqnZ--) {
        LSzZLUD -= LSzZLUD;
        mDrMzZWXdoFByiR = mDrMzZWXdoFByiR;
        LhUNGVqZvq = mDrMzZWXdoFByiR;
        mnzYzY += vxbtiBSk;
    }

    for (int mORWxwQVBQPxox = 1737332801; mORWxwQVBQPxox > 0; mORWxwQVBQPxox--) {
        LSzZLUD = hlqQrPsQG;
        mDrMzZWXdoFByiR = tfRVKN;
    }

    if (XlbaJaXQukU == 542203.0088104672) {
        for (int UTJmGkAuq = 1457281146; UTJmGkAuq > 0; UTJmGkAuq--) {
            hlqQrPsQG += LSzZLUD;
            LSzZLUD = hlqQrPsQG;
            mDrMzZWXdoFByiR = mDrMzZWXdoFByiR;
            mDrMzZWXdoFByiR = tfRVKN;
        }
    }

    for (int KbIbeNg = 1298101459; KbIbeNg > 0; KbIbeNg--) {
        vxbtiBSk = mnzYzY;
        hlqQrPsQG -= XlbaJaXQukU;
        LhUNGVqZvq = ! mDrMzZWXdoFByiR;
        mnzYzY += vxbtiBSk;
        LSzZLUD *= XlbaJaXQukU;
        mDrMzZWXdoFByiR = ! tfRVKN;
    }

    return mnzYzY;
}

double Whyfg::fOnKoNFSOgTODJuv(int ZMEjEgyIeOl, bool skpKsJWXafpHCWWM, string UgsduyemghN, int YJnhDoErRp, int cZaRlmzi)
{
    int wwGCqikHGNao = -1111993834;
    int XlqTmIldUSAv = 2098305666;
    double TAiQZcfAgAUXt = 710703.0098724279;
    bool bcASXbH = false;
    string kTGhOe = string("lkSisbLQBpraIyNzNHIdywvasHRzEfwSZGbFmUfRSLdwBsmUjAeebunPYsvqGGGsRxplnjfSwmTMminAkhugocvwuserZurUNnnOXsmdJxaeqMebHQzTbtSDpZRMaJs");
    double AJrkhOwWSqq = -170125.92587376112;
    string yjlSymGyGtOyO = string("TQnXwkRnrWvmwiTopGzbpnIlQmuLSdoEyNSHBBAHAlgiCWnbAZrcnGAmauoJRqVXAjffZgYunOPgsyjuzYfaanJKkZYNVpfdmRHjXiyDDQtAJwjZshlVUfNwwmjXDWzknfmqalutXWWYgwdZjQtbbnTlAJRxikAyEGejbspQytGPljMG");
    int impTW = 1483460831;
    int ECfRIAJLBY = 56897895;
    bool CEQBrfdBRQnmP = true;

    for (int qPbwYQ = 2045833823; qPbwYQ > 0; qPbwYQ--) {
        cZaRlmzi *= wwGCqikHGNao;
        cZaRlmzi += cZaRlmzi;
    }

    for (int nQClTFDXnTLSOxGj = 1668703469; nQClTFDXnTLSOxGj > 0; nQClTFDXnTLSOxGj--) {
        continue;
    }

    return AJrkhOwWSqq;
}

void Whyfg::EedDiQ(int XoozPaDTwhIeUB, int qNeqJLNEjqzcYF, int wyHoPHuAktjBf, bool rzZGSoiNly)
{
    bool uEYMFa = false;
    int RWSgZViSt = -1902498005;
    int vFWUCXUExOWWob = -1248225968;
    int rQGZxjNr = -688995917;
    double tMAOWDRrXNyf = 343385.24675216014;
    double DtyPWdlhRVnnlcJ = 415335.56725088716;
    double DKthfEffXUiEPEJ = 1030691.0837324152;

    for (int NfwhaSHk = 1270575377; NfwhaSHk > 0; NfwhaSHk--) {
        uEYMFa = uEYMFa;
        rQGZxjNr /= RWSgZViSt;
        RWSgZViSt += vFWUCXUExOWWob;
    }
}

void Whyfg::PKBChM(string NAsKdv, int MUvVIGbamM, int XvRgAIqD, double DnDGdFQmXBZnLI)
{
    string sIWlhzOBXBvuEZ = string("kDMuhZbGTNdlLYokHwwnibRKicTPgPVuXY");
    bool oRaRELfmvG = false;
    double tMXOvwMxMlbfGVTv = 248523.72636955345;

    for (int pTWhuqkS = 1893083179; pTWhuqkS > 0; pTWhuqkS--) {
        MUvVIGbamM -= MUvVIGbamM;
    }

    for (int LVadQ = 287847717; LVadQ > 0; LVadQ--) {
        MUvVIGbamM *= MUvVIGbamM;
        XvRgAIqD -= MUvVIGbamM;
    }

    if (sIWlhzOBXBvuEZ <= string("kDMuhZbGTNdlLYokHwwnibRKicTPgPVuXY")) {
        for (int emiepeIyAbm = 856550363; emiepeIyAbm > 0; emiepeIyAbm--) {
            sIWlhzOBXBvuEZ += sIWlhzOBXBvuEZ;
            sIWlhzOBXBvuEZ += sIWlhzOBXBvuEZ;
        }
    }

    for (int NQRMqJX = 842502023; NQRMqJX > 0; NQRMqJX--) {
        DnDGdFQmXBZnLI /= tMXOvwMxMlbfGVTv;
        MUvVIGbamM -= XvRgAIqD;
        tMXOvwMxMlbfGVTv /= DnDGdFQmXBZnLI;
    }

    for (int nQYmodo = 796127091; nQYmodo > 0; nQYmodo--) {
        XvRgAIqD -= MUvVIGbamM;
    }
}

double Whyfg::OufXQB(string hAHfg, double FpVPEnFafMUoKy)
{
    int finjRGWpcUINiUxU = 1199419035;
    bool YoPhHqvO = false;
    bool dOBWvvCPkzgHAf = false;
    bool KVCbuYC = true;
    double gzQXePFhdCvSdHuQ = 155955.82811277424;
    string dMEafgQSUBLuA = string("GfCcerhDciVEPAtQywrTTpBMnRxLHEWdcNoOxlJmuaAKoJHAGxmtjGfbcPYwCMmKexegHNKjGuByUisHajShcpCtbrdeywnTYjyZTnXHWw");
    string kQcvKnX = string("iFzENSTGnQRPdfOvxOyHAeI");

    for (int QXtBIM = 1858823814; QXtBIM > 0; QXtBIM--) {
        kQcvKnX = kQcvKnX;
        hAHfg = hAHfg;
        gzQXePFhdCvSdHuQ = FpVPEnFafMUoKy;
        KVCbuYC = YoPhHqvO;
    }

    for (int FeEDlxpPGFmUtzH = 96082477; FeEDlxpPGFmUtzH > 0; FeEDlxpPGFmUtzH--) {
        kQcvKnX += kQcvKnX;
        kQcvKnX += kQcvKnX;
    }

    for (int BkniIYkdr = 947241624; BkniIYkdr > 0; BkniIYkdr--) {
        hAHfg = kQcvKnX;
        dMEafgQSUBLuA += dMEafgQSUBLuA;
        dMEafgQSUBLuA = hAHfg;
    }

    return gzQXePFhdCvSdHuQ;
}

Whyfg::Whyfg()
{
    this->BpcrJrlvARpbgssE(string("zdXwUoMhBPguFmfwldsdiGUUpUbwABlBKgQLAjAjbsalJilCSaUHBPnzapAKUiLtSdJIOzgdYgzgWyfplYNMGqVuOBTOcTnEbkKijsRSfPtXXAnRQWWFJHrQAYJxbQfYiawHmKEjHmTTIatXOUGyXcEaoVCEse"), -926427397, string("aRfmibxYUqxlAJiJbQMSVqfc"), 662038.8934620116, false);
    this->UteCX(string("PjPVRZODnYiCBakkFyohxuClAurmMoLstYlCJTnreQEoenlejdJvuCzOyjBNjVzpxjZTuEYYqxAKAplyKxYRNeyFMqtibIKXvsGCpydTXFNJIAccOHfPGwLeJrKjWwaXRBbIwIiagWAiobyrnYqHmkPODhxeKQNUyzrjBUmKSROfudXDpWkBQcyGAzyiMvwQxGbWuWFUkjpOibPsqztVlEHsqxZIyYYwnLBtSsVzVcU"), string("ExBoLlBeSsxvslOpqFvnNxVPbbHSgsqNjbhylxT"), -222265832, -641580047);
    this->abgYdFFhBN(string("ZlEVUDwMTXNqtDlQvESjpdSzkuCiYdrNqfLhtWXPGIpQ"), string("amYYhTNJwYxfqUfuXbZiZUHkNfrKtpQcRnAjPEVZWcBVsNJKrFNJTEVRSNAmMEuzxunymeytbqIyWweUdSjUeEGzvgwmzeIiTDLebSXAbgYtmNTlbDhIKlvgkpuCAIntfYQzOaAADiKUdIJLJd"));
    this->NSvlxvS(-347000699);
    this->AIlsPfxzhgf(874727.8806351358, false);
    this->SYvXWJYn(false);
    this->HHCxE();
    this->wiJcHurVyg(false);
    this->fOnKoNFSOgTODJuv(-973182500, true, string("CoxkJYlLtdINbLcufGzvDQGYDzPtcwtkmXURjjYEcUePXWepaLGgjGCoaYgbQkGyisrkwwZHWIiktYdOXcJrCFTfCUYfFWZzWhVa"), -607381676, 1013463086);
    this->EedDiQ(-889850140, -993192634, -1376637147, false);
    this->PKBChM(string("jSorCsaUmTfVFkhhZQFu"), -541974584, -1670400262, -1037241.7271434625);
    this->OufXQB(string("XWGTUdFvxMoCiYIUowShJPyiFsOOslC"), 20833.04037391355);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XjjNOdByDs
{
public:
    bool nzVzcVPzKFRiJ;
    int QRHbukeKZAw;

    XjjNOdByDs();
    bool lVBbAJ(double VbJQoMfKgyuwY, int LCNfNFcmkMPH, double uygFNSIHHNDDsf, int KCWBmyecAAcRdr);
    string fCyIPxQxHutABO();
    string YjApAQkhIBcj(bool DbFKNYVwKhU, bool qVWfzIvrdqZotA, double sGhzOk, double uaAinccBVUsPPus, string BrrMOqyJ);
    bool xyxCIBHcsnJ(bool kWLMViGvXlz, bool ogLOgxs);
    string jMWeuSFVljQJHpID(double IHVrI, string BCzyvtVhEwjlqfB, bool CkkJkpkqfUtGMRY, int iEepRM, int VMjmDEZVCweEIAs);
    string ghoUqDhtVJxYuMXR(double GyAAkfVseoJcE, string TpokDbcDULTsps, bool qNHNr, string MGNPcZCDRbmQOBAP, bool TxcFCeVDsraJP);
protected:
    string dqDgpsSgmuSvFzb;
    string FTVGuaFZ;
    double BUEzvyYFwkcuL;
    bool iZPDdYQgUxP;

    bool YjNgFOWfUSP(string wpsSoXJeRRuJMlHu);
    bool QyQTqDiiYNmkov(double EWbwOZeTxwcKbe, int PNQFyiNLFquBjvC);
    void HDgPYreyohDqhA();
    string RAgXiGyIGGgm(bool ycaArPSKuXD, bool LjoAG, int DAeBJfyq, bool OcyJmPFQqAX, double kvkvyPnVGl);
    double iSwatQfz(double euNCl, bool cgLpahlVnv, bool KoKDdhGpc);
    int DDCTKFbCCfNvvTjA(string SmOyhO, string SlJNmZJce, int JVqPlgrdh, string omLsme, int YXafPA);
    int PBkZqAmJQ(int KAbTeEE);
    int VPjWoJwFtKliayS(bool TUWomCNlHrDDw, int pVVBCQ, bool OEDro, int ybnKhgSeDrl, bool ApHTik);
private:
    double qgAtthWO;
    int UmIaoMOkCzlzz;
    int hyunZj;

    void SFycDfLHpnaeqXTz(string qfsFcpFdg, int vQMmbrwagz, string fISWSZ);
    int axujSCBU(string LjWyaU, bool EvrPUlmGHX);
    bool tOdkDpcPMAm(bool oAntQM, int xpyWgDVQcu, double NffkBkTrxyGT, int cmGpIkRtaVqMo, string xUyVU);
    bool xurxGUPKSTskHu(string ktUJWhXxIHOWq, bool XtZLGganifMD, string FRgRRuBynMegeIF, int RYRDGfr);
    int TKJTqqlgN(int YrmspqdonNPB, int DXHmIYzvjXjhEoOV, double awfOusDFWNyRk, double iHScD, string gmkPkPyAQNL);
};

bool XjjNOdByDs::lVBbAJ(double VbJQoMfKgyuwY, int LCNfNFcmkMPH, double uygFNSIHHNDDsf, int KCWBmyecAAcRdr)
{
    double RzRqijMImnj = -139676.3525997264;
    double uQJZBCududBSOoU = -960277.3468682705;
    bool FnlBxgmGVL = true;
    string iXtNFInWFUCkYZE = string("mHQKqkETzFyxbMiryJaQDHlVIDYPJmMhXtcrufZlaTHXguKZGDkeRlbKxPenKmaArwHkHeKpQKEolHyTgUpMcCkRSqMbtWkriQPGsBxRhAXzuRloWqBtSkEBHLgzojVeZsoptTIyyRlavPKBSoXCDMIZYLhOtRkRTGGmWBSbLDVXHAKdcvpznQTypOWXwewMplVIdBVlhFiPsmIJvzOZrAUE");
    double rpguCqz = 152543.33303649543;
    double epOcCFJ = 569276.9763254871;
    double PqBzY = 521918.0814889226;

    if (uygFNSIHHNDDsf >= 521918.0814889226) {
        for (int yjqFTTu = 1762666503; yjqFTTu > 0; yjqFTTu--) {
            VbJQoMfKgyuwY *= uygFNSIHHNDDsf;
            LCNfNFcmkMPH *= LCNfNFcmkMPH;
            epOcCFJ += rpguCqz;
        }
    }

    if (PqBzY != 569276.9763254871) {
        for (int teDXyIl = 1780774152; teDXyIl > 0; teDXyIl--) {
            continue;
        }
    }

    if (RzRqijMImnj <= -682482.285638415) {
        for (int pNVdVrqisnziUy = 320662394; pNVdVrqisnziUy > 0; pNVdVrqisnziUy--) {
            uQJZBCududBSOoU = epOcCFJ;
        }
    }

    for (int mSmuvKWXfflcxVMs = 725418144; mSmuvKWXfflcxVMs > 0; mSmuvKWXfflcxVMs--) {
        uygFNSIHHNDDsf /= rpguCqz;
    }

    return FnlBxgmGVL;
}

string XjjNOdByDs::fCyIPxQxHutABO()
{
    double qYfCXDOa = 414731.056450826;
    double NoQMQolmgNob = -798731.5617227925;
    double DRwpMfxkhExuwel = -1013224.0546343424;
    bool MlMyrjiZjIzJITC = true;

    if (qYfCXDOa <= -798731.5617227925) {
        for (int irbXnRcUZO = 2101676949; irbXnRcUZO > 0; irbXnRcUZO--) {
            NoQMQolmgNob /= DRwpMfxkhExuwel;
            MlMyrjiZjIzJITC = MlMyrjiZjIzJITC;
            DRwpMfxkhExuwel *= NoQMQolmgNob;
            qYfCXDOa *= NoQMQolmgNob;
            DRwpMfxkhExuwel *= NoQMQolmgNob;
            DRwpMfxkhExuwel += NoQMQolmgNob;
            NoQMQolmgNob -= DRwpMfxkhExuwel;
        }
    }

    if (NoQMQolmgNob >= -1013224.0546343424) {
        for (int ygCaoEGdkZFQss = 1782047062; ygCaoEGdkZFQss > 0; ygCaoEGdkZFQss--) {
            DRwpMfxkhExuwel = NoQMQolmgNob;
            DRwpMfxkhExuwel /= qYfCXDOa;
            NoQMQolmgNob += qYfCXDOa;
            DRwpMfxkhExuwel *= qYfCXDOa;
            MlMyrjiZjIzJITC = MlMyrjiZjIzJITC;
        }
    }

    if (MlMyrjiZjIzJITC != true) {
        for (int SwSrlJtRfAmM = 31308881; SwSrlJtRfAmM > 0; SwSrlJtRfAmM--) {
            NoQMQolmgNob += DRwpMfxkhExuwel;
            qYfCXDOa += DRwpMfxkhExuwel;
            NoQMQolmgNob /= DRwpMfxkhExuwel;
        }
    }

    if (NoQMQolmgNob <= 414731.056450826) {
        for (int rmRojyRyA = 287175899; rmRojyRyA > 0; rmRojyRyA--) {
            qYfCXDOa += qYfCXDOa;
        }
    }

    return string("bsaflIYneINpCyxWsMGNKppODqOuhRABOVxMtCcffXEoBncVCQNwucuNKShAPBUAzyVhjMslw");
}

string XjjNOdByDs::YjApAQkhIBcj(bool DbFKNYVwKhU, bool qVWfzIvrdqZotA, double sGhzOk, double uaAinccBVUsPPus, string BrrMOqyJ)
{
    string SpOVOQycV = string("RZwATGcejhUfOvvyw");
    string HxBwZc = string("vUkZjRcTzfLhoUOyEAwMTlUFqfCPPnSsoDiGnmPXJwgzOZlXapgdQJnZcvOcJzoldVOksWEJKiebLrWddvZnpYfpzmrvsUkiTzgXkBAAeypsUdeUjKJorHNplYqA");
    string AXDbWttdGIpV = string("JPzHCplKyOAppdBNDqzJsngWaUMgKQERZkRvTyWTpweFqPUkvWuXJgsQXgTYZmdSwdaPXBwVlnMmERfHjTeOyhNkLSVNPrEYkyByheiULtzmlpAHMitFODpsPLURoWcjAkyTJxPsjWPCbHuHZgtDGykN");
    string pJsuGsIlgVubVWc = string("uPBuxVfTodMQESEBabQaHvglELTyCNLfNUlPvmsbrUWSSwNdEPlbUYmpCeBVcttLErGfSKnMDEZdazCPLOoJIMsYlvDHjPVSBIZhvcljLRVSjZDKtbDXFGowCIEoSUOUYqOMtczqVTltCxxzHoVpBwtrNwIvVSPmMQFcKMpCKioNopUYPuTJcTIILmgEoAPXYXLjYYxFmcmdegKdoylMTVTxOtzVp");
    bool HBzOIv = true;
    string BMgeVNN = string("Uwa");
    int HRJlqIQvlS = -1609283539;
    bool ZAgyPYkJHkmjcEBF = true;
    double kYmwyRnYDkm = 363467.033324591;

    for (int RjQdgZqGtRizYqN = 318823732; RjQdgZqGtRizYqN > 0; RjQdgZqGtRizYqN--) {
        continue;
    }

    return BMgeVNN;
}

bool XjjNOdByDs::xyxCIBHcsnJ(bool kWLMViGvXlz, bool ogLOgxs)
{
    bool zfeeCnf = false;
    bool gDmMz = false;

    if (ogLOgxs != true) {
        for (int JOrrBDQP = 290409297; JOrrBDQP > 0; JOrrBDQP--) {
            zfeeCnf = ! gDmMz;
            ogLOgxs = ogLOgxs;
            zfeeCnf = kWLMViGvXlz;
            kWLMViGvXlz = zfeeCnf;
            ogLOgxs = zfeeCnf;
            ogLOgxs = zfeeCnf;
            ogLOgxs = ! zfeeCnf;
            zfeeCnf = kWLMViGvXlz;
        }
    }

    if (ogLOgxs == true) {
        for (int agGJN = 2001713445; agGJN > 0; agGJN--) {
            gDmMz = ! ogLOgxs;
            gDmMz = ! kWLMViGvXlz;
            zfeeCnf = ogLOgxs;
            kWLMViGvXlz = gDmMz;
            gDmMz = kWLMViGvXlz;
            kWLMViGvXlz = ! zfeeCnf;
            kWLMViGvXlz = ! ogLOgxs;
            zfeeCnf = zfeeCnf;
            gDmMz = gDmMz;
            gDmMz = ! ogLOgxs;
        }
    }

    if (gDmMz != true) {
        for (int mbIsLjqV = 1583490617; mbIsLjqV > 0; mbIsLjqV--) {
            kWLMViGvXlz = ! kWLMViGvXlz;
            gDmMz = gDmMz;
            kWLMViGvXlz = ! gDmMz;
            gDmMz = ! gDmMz;
            kWLMViGvXlz = zfeeCnf;
        }
    }

    return gDmMz;
}

string XjjNOdByDs::jMWeuSFVljQJHpID(double IHVrI, string BCzyvtVhEwjlqfB, bool CkkJkpkqfUtGMRY, int iEepRM, int VMjmDEZVCweEIAs)
{
    int rZzucyaxXHo = -1199081396;
    double GFyhQkykhgDwDB = 390658.8815505867;
    double TwaxfMOylnYlooiZ = -218966.3427693182;
    int QNpklCScfTQ = 688581321;
    double gaLFetUBYizBBR = 61845.5384317374;
    double OpxjXfNWZUcjpa = 900528.605272313;
    string JjMlJIsfpGGzjZ = string("mCZEpfjJCbHtgaYMQrqMLMfgeSORnzqJSmpYIzSJtSKAEmqqoGVoruzdADmZgPccxmiNSLMaOCiwUCgSPOYLrN");
    int fERxAyd = 2074418935;
    bool APEDyxfvNFLAJZYZ = true;
    string ahEeuqRGqNbZR = string("UwVjFvmUMcmrvGQgRBCEeYgPxGPYJilPCpKmGlAdtslHpMCGYjVoqJLWrziZHnfEFYJDgxJd");

    for (int VFhkMXm = 801993706; VFhkMXm > 0; VFhkMXm--) {
        QNpklCScfTQ += rZzucyaxXHo;
        fERxAyd = rZzucyaxXHo;
    }

    return ahEeuqRGqNbZR;
}

string XjjNOdByDs::ghoUqDhtVJxYuMXR(double GyAAkfVseoJcE, string TpokDbcDULTsps, bool qNHNr, string MGNPcZCDRbmQOBAP, bool TxcFCeVDsraJP)
{
    double EoGfSLaTpa = -636082.6465429079;
    string iHdYAQrKTEdkoqC = string("LkPwCVXXTcrddlVkRIUPnrRSIyaBsRoYZbpQIIQMhdDNICXMDrEDZqHdGZHmyAJBosUcptVyQEfikehQhSYOArPcvaJlztItfhgExLIGiMNuoRrFVoKXErUNHIFenlmssbPguPapBNEbpqcKGFOMZaDYcXGaAZMTovsHXMbjGznLTvEeYeYZUQHyBvcWqPiPikcWMdfCDEzGDfqKKQIyHkCIeCgmOjbapVWUrPgbzGLvYwdPLbWCSNB");
    string OZTcK = string("hWnaASctATYgDUYxuSSuWVVemPTVRjPpGANyzRprKLvXKPYNjXAySbvKTzUbxmkbPWrJTUNaEiuJdRIESzfKZeZpvzXVlVFqHNgDJdyMDNBevdKNnxhSUGjkMBEycdpeZLqjJJwYFNhnbIUvuXOQDJonAxCVttAfMf");

    for (int WcvSUquqo = 1792634110; WcvSUquqo > 0; WcvSUquqo--) {
        MGNPcZCDRbmQOBAP = OZTcK;
        iHdYAQrKTEdkoqC += TpokDbcDULTsps;
        EoGfSLaTpa /= GyAAkfVseoJcE;
        TxcFCeVDsraJP = TxcFCeVDsraJP;
    }

    if (OZTcK >= string("LkPwCVXXTcrddlVkRIUPnrRSIyaBsRoYZbpQIIQMhdDNICXMDrEDZqHdGZHmyAJBosUcptVyQEfikehQhSYOArPcvaJlztItfhgExLIGiMNuoRrFVoKXErUNHIFenlmssbPguPapBNEbpqcKGFOMZaDYcXGaAZMTovsHXMbjGznLTvEeYeYZUQHyBvcWqPiPikcWMdfCDEzGDfqKKQIyHkCIeCgmOjbapVWUrPgbzGLvYwdPLbWCSNB")) {
        for (int XyKVdJI = 88220199; XyKVdJI > 0; XyKVdJI--) {
            EoGfSLaTpa /= EoGfSLaTpa;
            MGNPcZCDRbmQOBAP += OZTcK;
            TpokDbcDULTsps += OZTcK;
        }
    }

    if (TpokDbcDULTsps != string("BDdLmZznKiHksqqUPSJuWrBuhJHpNVfgufPWGsAYtFcBORnvrliueAJzwdolCznfKdLEGZrsyUmhZnBNVfnXLQEKYRpHkvHuhJGvSWAikq")) {
        for (int wDnrDeV = 2051121803; wDnrDeV > 0; wDnrDeV--) {
            TxcFCeVDsraJP = qNHNr;
            qNHNr = qNHNr;
        }
    }

    return OZTcK;
}

bool XjjNOdByDs::YjNgFOWfUSP(string wpsSoXJeRRuJMlHu)
{
    string mxKClH = string("mntxdsvwoiQPnFKvpYFoHdZcoYBATVYfpHOPDiqOtKKdHqYeHleBXIPmKeZOqXNWtgojMLxxhWPzimoDjZIjVDbSBcHyqsFYKmxavfyeHyXlQJidxXUMeoFSlZxHumkCaqwtLAsEFnWGMoUGiZNbtKFJZgnJUzMVHedWfDgSohGByelvAtrewBMngufUIoBXqJMVqSHAhDjPQKTwylvCWVtWTbrlTwfuDPYCAFqpUkMLCqBWfdAhNw");
    double FBfECe = -654671.4274325757;
    bool QbbfcHF = false;
    bool DBYrCdrOczjsHPQ = true;
    int rtNUgsYWg = 1788909982;
    string RPvEqJQAwjVAonz = string("ZQTkEknDdPbKnEATtEhjAFvkkRqDyHirHJBLpvoGOZTfAnuYqbfmuWoGYJXhhNHNaZVDOTRtVvwHDLrnoTjDmEluYidkqUFPdYbumSSfCbREOiL");
    double NcyUtxGoOHjf = 978288.6664212312;
    int CyXdQpA = 70538164;
    double XOkMxsw = -34765.0086405691;

    for (int navefaFe = 2050450726; navefaFe > 0; navefaFe--) {
        RPvEqJQAwjVAonz += mxKClH;
        mxKClH = RPvEqJQAwjVAonz;
    }

    return DBYrCdrOczjsHPQ;
}

bool XjjNOdByDs::QyQTqDiiYNmkov(double EWbwOZeTxwcKbe, int PNQFyiNLFquBjvC)
{
    bool KTzNCXPaAEL = false;
    int DAZKKhP = 1037062862;
    double TDwbVNUeGfPya = 866453.5139495964;
    bool YmfsgEMPNNwsA = false;

    if (EWbwOZeTxwcKbe >= 866453.5139495964) {
        for (int WtWDiRKaVJhrh = 1733397948; WtWDiRKaVJhrh > 0; WtWDiRKaVJhrh--) {
            PNQFyiNLFquBjvC += DAZKKhP;
            EWbwOZeTxwcKbe *= EWbwOZeTxwcKbe;
            YmfsgEMPNNwsA = ! KTzNCXPaAEL;
            TDwbVNUeGfPya -= TDwbVNUeGfPya;
        }
    }

    if (TDwbVNUeGfPya < 300333.7904785407) {
        for (int zCTlg = 1811157311; zCTlg > 0; zCTlg--) {
            YmfsgEMPNNwsA = KTzNCXPaAEL;
        }
    }

    if (DAZKKhP < 1037062862) {
        for (int ypsFCD = 1411956300; ypsFCD > 0; ypsFCD--) {
            continue;
        }
    }

    for (int ocTgPzMuCrST = 443805053; ocTgPzMuCrST > 0; ocTgPzMuCrST--) {
        DAZKKhP = PNQFyiNLFquBjvC;
    }

    if (KTzNCXPaAEL != false) {
        for (int MUeMEqwsygTCU = 602530526; MUeMEqwsygTCU > 0; MUeMEqwsygTCU--) {
            PNQFyiNLFquBjvC += PNQFyiNLFquBjvC;
            TDwbVNUeGfPya += EWbwOZeTxwcKbe;
            YmfsgEMPNNwsA = ! YmfsgEMPNNwsA;
            PNQFyiNLFquBjvC -= PNQFyiNLFquBjvC;
        }
    }

    return YmfsgEMPNNwsA;
}

void XjjNOdByDs::HDgPYreyohDqhA()
{
    bool opOkHIJBeESobGP = false;

    if (opOkHIJBeESobGP == false) {
        for (int yHWYji = 1997866834; yHWYji > 0; yHWYji--) {
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
        }
    }

    if (opOkHIJBeESobGP == false) {
        for (int nNcWrN = 580843838; nNcWrN > 0; nNcWrN--) {
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
        }
    }

    if (opOkHIJBeESobGP == false) {
        for (int ZTIhO = 1187449122; ZTIhO > 0; ZTIhO--) {
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
        }
    }

    if (opOkHIJBeESobGP != false) {
        for (int PEQACDTCgBU = 652716280; PEQACDTCgBU > 0; PEQACDTCgBU--) {
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = opOkHIJBeESobGP;
        }
    }

    if (opOkHIJBeESobGP == false) {
        for (int gJYlqTJXMcjgbaxE = 1417740031; gJYlqTJXMcjgbaxE > 0; gJYlqTJXMcjgbaxE--) {
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
            opOkHIJBeESobGP = ! opOkHIJBeESobGP;
        }
    }
}

string XjjNOdByDs::RAgXiGyIGGgm(bool ycaArPSKuXD, bool LjoAG, int DAeBJfyq, bool OcyJmPFQqAX, double kvkvyPnVGl)
{
    double DdPhDjvvPDHGZiA = -915891.059835077;
    bool cMEMnIl = false;
    string yJeANQdAUkURwC = string("NCZyZuUSSMAEQDrtKJAdLmTIeRGEuiOmdDzEaoLSdByoBYxVVVsrWkXviOWggnMnVhfYtFxQvwQFpFFxqMbqjEUudkIDLBAFkRadDUSMdgdODqXzZjaRnbmdjxNBkkmaBDbXUgUJBZwvTpkDuFPYySN");
    int HMkGRjJQDQ = 498506754;
    string VUFYAIVlkwJSNcI = string("wzccAWLfwzSzdiqJjvwPHyordZlwEFDDDDcTqAMBnVuHoWQgLyqrlTaZtUFEPdalIYsaFrSjMxYKBLHbsSHRDQPzWtLLhXNJZCzyXNdLmCYThSipSgtbbISYpKycelxjjwPXocKBSQQGSKRCwWdnvwjLqtckhBFiOfMIbCEYSRpFBkXYizQrfBBByDHZOAELFpirDNJyqMZwdzFAITrMtJeozKBRQmHRBRRRfhIySSrtxCxuMrTJKwl");
    int EMmUdKzfGZT = -2106176855;
    string bvLPuIYtS = string("fUbOLlqRDQhzIGKFGHuVycgOgkMuzlNahebxmAgpEsWYOljGKyzbjHbjUSbmHGIsYIjDWCxPZNaxyLyEuwZxedAmVRdkCvjEhWCvbKQNvnrtnENJCuMstSDEDQFJOMkhLpSfnjarcTzvFataCgWA");
    bool HbIdxU = false;
    string RCwPeNBp = string("vfwuPBmGrfFleyCHUrkPcagICuZNGPnJzQGWbdkaVfYjzqZEzqSinoAHzDuMfBDokxdDnidkyYQNLjeWuqtmwCySeyvdutUguprkhRiPyOxPBPcgdSBQhmze");

    for (int gIQau = 1819879801; gIQau > 0; gIQau--) {
        continue;
    }

    for (int DtHyJ = 1172660082; DtHyJ > 0; DtHyJ--) {
        ycaArPSKuXD = ycaArPSKuXD;
        EMmUdKzfGZT += DAeBJfyq;
        RCwPeNBp = bvLPuIYtS;
    }

    if (bvLPuIYtS >= string("fUbOLlqRDQhzIGKFGHuVycgOgkMuzlNahebxmAgpEsWYOljGKyzbjHbjUSbmHGIsYIjDWCxPZNaxyLyEuwZxedAmVRdkCvjEhWCvbKQNvnrtnENJCuMstSDEDQFJOMkhLpSfnjarcTzvFataCgWA")) {
        for (int TXNfnnNMCrHzUtCd = 102231322; TXNfnnNMCrHzUtCd > 0; TXNfnnNMCrHzUtCd--) {
            HbIdxU = ! ycaArPSKuXD;
        }
    }

    return RCwPeNBp;
}

double XjjNOdByDs::iSwatQfz(double euNCl, bool cgLpahlVnv, bool KoKDdhGpc)
{
    int qIAiyxDq = 893444799;
    double ueyFHAqcdiwC = 174951.98094041177;
    double FqnFxDZohNv = -73029.09799919493;
    string YKoUkcbhBeBN = string("FISdWMxzgjSRrashKKPZETZRGlCcRalSHNcnRxEDsaVP");
    string EzSFpJ = string("sLSZuWYATGpwzLaLfDzmAsWNeJJEZcLkSYvqZPreDJDEjzojQzLygyMohQghKztvXViciBtDAHZrenjzBbE");
    bool LjRLkoYinEu = true;
    string AHAHWcRzpoBP = string("fUdPfDGZpmFtvfAdrPSYJhbJHCutRSaNQwUMCyBDUXCEkvBNcKXslNJFvtlbKoeTTNYYSnKjcVqklxWpwhSNrZUrlfvdhFFTHZXsHLInUzMXujkP");

    for (int BDGKSfzWhA = 930939490; BDGKSfzWhA > 0; BDGKSfzWhA--) {
        EzSFpJ += AHAHWcRzpoBP;
    }

    if (euNCl >= -847887.0678051508) {
        for (int QJYsGw = 224522281; QJYsGw > 0; QJYsGw--) {
            FqnFxDZohNv = ueyFHAqcdiwC;
            FqnFxDZohNv += euNCl;
            EzSFpJ = AHAHWcRzpoBP;
            cgLpahlVnv = ! KoKDdhGpc;
        }
    }

    return FqnFxDZohNv;
}

int XjjNOdByDs::DDCTKFbCCfNvvTjA(string SmOyhO, string SlJNmZJce, int JVqPlgrdh, string omLsme, int YXafPA)
{
    string oOJAPALFC = string("GCAKYaecHkWPCpzqeypFqldBNctzTWnZHnZXbrfvONfmvUJECcGbzzoJalpZxmzeugPVtMnuTEFByVVUFXvFEUgUJGmssUfVDwsCtPVGWGTJtkQZNO");

    for (int EAdUxKLolMUCu = 1776276964; EAdUxKLolMUCu > 0; EAdUxKLolMUCu--) {
        JVqPlgrdh *= YXafPA;
        SmOyhO += SlJNmZJce;
        SlJNmZJce += oOJAPALFC;
        oOJAPALFC = SmOyhO;
        SlJNmZJce += SmOyhO;
        JVqPlgrdh /= JVqPlgrdh;
        oOJAPALFC = SmOyhO;
    }

    if (SlJNmZJce != string("jtWPcWHivAohItDrzmOXUcKYrSPxIqpCgGBIiHJTjYkZIICutdIlZBJNPpOVOaMqIvrUygWAYYbAh")) {
        for (int SQmMyW = 253615316; SQmMyW > 0; SQmMyW--) {
            SmOyhO = omLsme;
            SlJNmZJce = SmOyhO;
        }
    }

    if (SmOyhO == string("GCAKYaecHkWPCpzqeypFqldBNctzTWnZHnZXbrfvONfmvUJECcGbzzoJalpZxmzeugPVtMnuTEFByVVUFXvFEUgUJGmssUfVDwsCtPVGWGTJtkQZNO")) {
        for (int YibMXnjPL = 1606552994; YibMXnjPL > 0; YibMXnjPL--) {
            continue;
        }
    }

    if (omLsme == string("XWrOmhdzheTTqsnKLMSYEzBSDGlRhxxjafuwgsUcTiRbpINLoNLDcRlmkbHdPbOLZtfZPWrviCoCkavUkKy")) {
        for (int ybhZwDiGH = 253661109; ybhZwDiGH > 0; ybhZwDiGH--) {
            SlJNmZJce = oOJAPALFC;
            YXafPA *= YXafPA;
            SmOyhO = oOJAPALFC;
            JVqPlgrdh /= JVqPlgrdh;
            omLsme += SlJNmZJce;
        }
    }

    return YXafPA;
}

int XjjNOdByDs::PBkZqAmJQ(int KAbTeEE)
{
    string Czyjdkw = string("dKJYegVOhdKKXJeqvUgQ");
    bool TdUpjA = false;
    string TSbGjiULPCCfxkf = string("JBiNdSUylKGWJnaeyVRRJdhCoLmOLHxIbkJkGXFzCsqoITDSaJqoVJFglSdmlBzXgjQYGjQRpMmWQQuzxnlzLQpenDosMqHshaIBsOHShDoYnzfpJIsmWBUmwueCzNYOhlmLyuoZcbcXhNusXOReyKTDZJtPjadymflcLwfPjZRvhCnBhfZRCwpQyhrvakWQQYUTxisBCEBoRIOAWvonKWcrxUdxxnCaDuotmkVjlArhYrVYrCQnSdIsDjs");
    int pRNqAr = -236240176;

    for (int CsCCHKfzUHRUt = 320512598; CsCCHKfzUHRUt > 0; CsCCHKfzUHRUt--) {
        Czyjdkw += Czyjdkw;
        pRNqAr /= pRNqAr;
    }

    if (KAbTeEE > -236240176) {
        for (int Vhopl = 1676008228; Vhopl > 0; Vhopl--) {
            Czyjdkw += TSbGjiULPCCfxkf;
        }
    }

    for (int xauxCuD = 161924771; xauxCuD > 0; xauxCuD--) {
        pRNqAr /= KAbTeEE;
    }

    return pRNqAr;
}

int XjjNOdByDs::VPjWoJwFtKliayS(bool TUWomCNlHrDDw, int pVVBCQ, bool OEDro, int ybnKhgSeDrl, bool ApHTik)
{
    bool xmLWiaxKiBrS = true;
    int taEQkOb = -679901160;
    bool HfHXO = false;
    int lnLqltsMZCbrVAiF = 1321240617;
    bool ARmnfxjIPydA = true;

    for (int buGWJXeO = 712470625; buGWJXeO > 0; buGWJXeO--) {
        continue;
    }

    return lnLqltsMZCbrVAiF;
}

void XjjNOdByDs::SFycDfLHpnaeqXTz(string qfsFcpFdg, int vQMmbrwagz, string fISWSZ)
{
    double FOjXXCec = 619573.0219827123;
    int NjuWkjYEZKliULp = -200469550;
    string SjgFbHOFbEklGf = string("AbXtmLLsGyIPEzWboGrPgLyeDuDYULUshcsmXBTgBSokrnHtfFFpUZMrPHqkA");
    string XgMCrSNofxzfD = string("KJcleoherttPOnJkyMapYxrdmqGVCjnpvGWxiQaIafCzVfxRldExgfAqTixgEuycmYFGvMeEfyjxvjSscJPglQRLjhWrhEhfKtXLmlFmPXXXcZKMNkLQUrhwMRpPvbeSlwvljgKDT");
    int DddLl = -351696734;
    string kFsjIGj = string("jdwMTXchGEvWhGApSnLTJbMTiyqmEvCInzYkpSJWlMCZambBFiMgHfSzGVhSBGuTBIvWWEEiCCxkDKuwHwtJyNRvIhVrIeERucPqWFKKQnmkfHYTXBHsfNojkXNTaBtJctwgNhpYvgsdHVmMLbcFL");
    double rnYGDqR = -358911.5005460782;

    if (rnYGDqR <= -358911.5005460782) {
        for (int HzibBSwVaGkKMhTG = 3947377; HzibBSwVaGkKMhTG > 0; HzibBSwVaGkKMhTG--) {
            XgMCrSNofxzfD += fISWSZ;
        }
    }

    for (int uXfLVw = 1483572937; uXfLVw > 0; uXfLVw--) {
        qfsFcpFdg = XgMCrSNofxzfD;
    }

    for (int pPWdLNMQ = 961367760; pPWdLNMQ > 0; pPWdLNMQ--) {
        vQMmbrwagz += DddLl;
        XgMCrSNofxzfD = fISWSZ;
    }
}

int XjjNOdByDs::axujSCBU(string LjWyaU, bool EvrPUlmGHX)
{
    bool xhGqViNKnPvJhgDW = true;
    int FlgezLHlIEIegHm = 337695977;
    bool xuNKHH = true;
    string ajeEK = string("cDZElgMeMPcQsMEilvfMocgrczNeziBOTkNklbkASSaRlmaGwJXMnzOpmBeenKCnZmbCXjFFGXgCSldXcyAdxKYhkKXDeKxGdWaEGVRnbNRlqok");
    string LTtAYblPUJ = string("buEJJHnBELmMZSuCtcLicSfBErhsXyEecttIcTcQtvfRkFrazXrZvBXleDImKyrwNmEWGaGgoYEkXzeioMNdxKwhCzNTyVKFFxpknkOhEBhPkeBGjUvoZTJSzgZqDpugFwWOlXK");
    bool jmxxlYIidcKDTr = false;
    bool nBIVlvJvyirrQFl = false;
    int jJUebbGi = -1961741272;
    bool uWAjSCkMMIZRWE = true;

    for (int pnEMpHayuZCXSCUF = 297595817; pnEMpHayuZCXSCUF > 0; pnEMpHayuZCXSCUF--) {
        EvrPUlmGHX = ! jmxxlYIidcKDTr;
        xhGqViNKnPvJhgDW = xhGqViNKnPvJhgDW;
        nBIVlvJvyirrQFl = uWAjSCkMMIZRWE;
        EvrPUlmGHX = ! nBIVlvJvyirrQFl;
    }

    return jJUebbGi;
}

bool XjjNOdByDs::tOdkDpcPMAm(bool oAntQM, int xpyWgDVQcu, double NffkBkTrxyGT, int cmGpIkRtaVqMo, string xUyVU)
{
    bool yxlVoYtZyR = false;
    double JZCCnLKSk = 665042.9352132207;
    double rsxqwxD = -683708.6578027382;

    if (NffkBkTrxyGT <= 665042.9352132207) {
        for (int DriobczkBfCN = 1339741277; DriobczkBfCN > 0; DriobczkBfCN--) {
            JZCCnLKSk += rsxqwxD;
            yxlVoYtZyR = ! oAntQM;
        }
    }

    for (int McPYt = 1562289601; McPYt > 0; McPYt--) {
        xUyVU = xUyVU;
        oAntQM = yxlVoYtZyR;
    }

    for (int rGhWHBnIJfNmr = 2119805333; rGhWHBnIJfNmr > 0; rGhWHBnIJfNmr--) {
        JZCCnLKSk -= rsxqwxD;
        rsxqwxD = JZCCnLKSk;
    }

    for (int YNBWunRAuIGzphzQ = 1547528925; YNBWunRAuIGzphzQ > 0; YNBWunRAuIGzphzQ--) {
        yxlVoYtZyR = ! oAntQM;
    }

    return yxlVoYtZyR;
}

bool XjjNOdByDs::xurxGUPKSTskHu(string ktUJWhXxIHOWq, bool XtZLGganifMD, string FRgRRuBynMegeIF, int RYRDGfr)
{
    int kiOxGcqJ = 1823302488;
    bool IJWth = true;

    if (kiOxGcqJ >= 1823302488) {
        for (int CbDYCJfdvg = 526853907; CbDYCJfdvg > 0; CbDYCJfdvg--) {
            continue;
        }
    }

    if (FRgRRuBynMegeIF != string("gEpYCdRpxQgwGIXGhzBnzYIpbPnYRdDwdzHUcQtqMworHFGPwBJDqSWzVIzbfNFPLlFchuBCkgFukoZmmfbSgiVQbWcPXtvZmDSdezSSEyLFooDrZDzpiPDNTXbWDRWYdZUaPwGhNNMSAojoFgpKDKLCyL")) {
        for (int XUfQOUfvgtjX = 1282843993; XUfQOUfvgtjX > 0; XUfQOUfvgtjX--) {
            FRgRRuBynMegeIF += ktUJWhXxIHOWq;
        }
    }

    for (int yHSucPK = 895030953; yHSucPK > 0; yHSucPK--) {
        XtZLGganifMD = ! XtZLGganifMD;
        FRgRRuBynMegeIF = ktUJWhXxIHOWq;
    }

    return IJWth;
}

int XjjNOdByDs::TKJTqqlgN(int YrmspqdonNPB, int DXHmIYzvjXjhEoOV, double awfOusDFWNyRk, double iHScD, string gmkPkPyAQNL)
{
    int VUYJWVgNzw = -817582062;
    int vdZkDnPVED = 1715930808;
    string BSweNTojErAmA = string("bvuEvVWCZEeprYoexTujfCZhRuOe");
    string FpqWSHVEQh = string("rRsdGHOHkRZUUBMdxPyTWjMyhVppcwGOEfbJlpvxdiFtMKtWwuSfrqpMYdCDUyhnrXqqQhLhWwO");
    double BjbzhRBRAKwUts = -42213.89499987967;
    string zRzRIx = string("aiOZTzAeMVdsQaWxtkPGtSpqKOgrXsQ");
    int OVqQyYSRSX = -506152691;
    int EkmipZYyNeeUb = -2073399665;
    double HSqRhcUQQAaOJ = -183158.09927347073;
    double ZWcwBIJD = 142294.01436026554;

    for (int KSYuULDhkPonUjq = 425651497; KSYuULDhkPonUjq > 0; KSYuULDhkPonUjq--) {
        gmkPkPyAQNL = gmkPkPyAQNL;
        VUYJWVgNzw = DXHmIYzvjXjhEoOV;
    }

    return EkmipZYyNeeUb;
}

XjjNOdByDs::XjjNOdByDs()
{
    this->lVBbAJ(158153.0379367299, 908134022, -682482.285638415, 870912752);
    this->fCyIPxQxHutABO();
    this->YjApAQkhIBcj(false, true, 68316.21327738317, -343162.3937890348, string("ePWjaEBCJhubFcpZYXuddbEJXkuOeINsrOpafKutTHxoNQsarYMFiDOvfuuJmUKpjLmJfAbAyyGxEOIjsqyjoWCbL"));
    this->xyxCIBHcsnJ(false, true);
    this->jMWeuSFVljQJHpID(977786.1785949648, string("wqwVRdsyelshbVxZlCODIagfnxQVOssgNJNHkeZPvWMSELPsrZgKVXvRccJNJzTSPEKRJlYEWrAzwIzLUGCxISDcXFPtgkjClewMkeMLZUcFgtzGrrLhdRKcBHcdkfiiohPnMLCRNYVuLRRVeTbaEjSezmRquNb"), false, -1436913709, 1299029719);
    this->ghoUqDhtVJxYuMXR(-1042266.6023674617, string("BDdLmZznKiHksqqUPSJuWrBuhJHpNVfgufPWGsAYtFcBORnvrliueAJzwdolCznfKdLEGZrsyUmhZnBNVfnXLQEKYRpHkvHuhJGvSWAikq"), true, string("POlkMybwHHiCBPzpXdkiKVAtkJbevzNPSPgRvARolEKxSLwecFeXohQYbjyQBQUoqCpRFECWWMKuZFjQQxvZhOmuCnDqQDaxOeqkoySyNfqcDbgGzHPMHZRUxIFgPyrIHzSqrXMSjo"), true);
    this->YjNgFOWfUSP(string("BHKLzNPtTWxSRfvtNvEPKMWbPlOK"));
    this->QyQTqDiiYNmkov(300333.7904785407, -1054666844);
    this->HDgPYreyohDqhA();
    this->RAgXiGyIGGgm(false, false, -776746316, true, 319571.78189110535);
    this->iSwatQfz(-847887.0678051508, true, true);
    this->DDCTKFbCCfNvvTjA(string("XWrOmhdzheTTqsnKLMSYEzBSDGlRhxxjafuwgsUcTiRbpINLoNLDcRlmkbHdPbOLZtfZPWrviCoCkavUkKy"), string("PoLIksmdSIJKkDCRQjuLcxdSwQcUPeOlGtefKcpOnxljDHgOTaUyvXjjEJgnVnwXKzDWnLzfzKjHYxupRyTpdkdyAaapkxuDlRXDAPifZcsuUfZcNXEmItQZILtkPJGuWehakoEQegmBeAwkyLtHszLFpzepSLFtxYlxYCiFEUxJeWrhUhaJQmpyNHtrkWPhUlSSiNUwM"), 856470772, string("jtWPcWHivAohItDrzmOXUcKYrSPxIqpCgGBIiHJTjYkZIICutdIlZBJNPpOVOaMqIvrUygWAYYbAh"), 1683232025);
    this->PBkZqAmJQ(1206474211);
    this->VPjWoJwFtKliayS(false, -770547335, true, -1215449065, true);
    this->SFycDfLHpnaeqXTz(string("bQpLlrfQBvgqyfvoYlncMTjTeXMljsixdFcBkEOZOthnipAfqnrrnrEnfpYEPZWTAZhHRxMhLcpdwDChrkVAIZFOJIHXvACVRmblPOIFLvrFJUdiNrcmVdsiwZISaDVwEqxpVZWgcizJqarNuRMntlZNNPzIsjheKaiJjEBUQTsHZcomwquiYRqddGwoUabYHVXiVnZjIzvLZUSjvTqszdYkZHFDm"), 250159691, string("jHWRjpKuTguKBFcBGNgsOtDoMKVLHiemjruPJGNRmBzzfXAUvdJANMgBTDzZjkYshaCRWKTzFeWbfqC"));
    this->axujSCBU(string("CqYVJUNhpmGVxOdpIOimhWmuHBniqdXDSmapPdJdiArnMSeSrmBAFJuJpAruupdRfXPIPMYTnQpRyThCpyYjHQNibtrndkZRALGrkiXnIGRpNPlSohkXHbZEbkCkZLIzoUgqFRxsgPWuBhJbtbPXyDsnnncoeOURmHzQNqWejSOriwCVSNcErRnlWaFkIxUkevXoNMJdrtNMnRoUDZbpjdiGUEDNC"), false);
    this->tOdkDpcPMAm(true, 1286217032, -159860.45404315906, -590968691, string("SCIJeD"));
    this->xurxGUPKSTskHu(string("ZKmHptoUVCHCSmHSTYYwTjZSaeFDvUBDIuzukdtUoeQGTKGjOVnLocrQSwxxxznLFKBJlMaoLmkgRxdDIWdGnlMTsGEmptQHWvdDYSrRAkPkcKMaY"), true, string("gEpYCdRpxQgwGIXGhzBnzYIpbPnYRdDwdzHUcQtqMworHFGPwBJDqSWzVIzbfNFPLlFchuBCkgFukoZmmfbSgiVQbWcPXtvZmDSdezSSEyLFooDrZDzpiPDNTXbWDRWYdZUaPwGhNNMSAojoFgpKDKLCyL"), -1232999581);
    this->TKJTqqlgN(-1464400501, -397076980, 360285.7932757151, -786768.6676573602, string("YvWloXTPSZNkUVlyEwHkDXlHiRFTjRDUxECbjYsiHAZAXGVGjBCPsHGhwIVQAQGHzYEvpYqIAujAlUfpngOJCFtGWlwSPTnl"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uqURleW
{
public:
    double HCQmiM;
    string cfEVCmkap;
    int htJQhskCoHQwMm;
    bool sBNnCkWOjfZQYZXQ;
    int hAcvScPD;

    uqURleW();
    int JZPeAfoZyEhvfjgm(double lcUrhycql, double UoNHCXXHgpmld);
    string NFNhyQ(int HCpJJbgNAa);
protected:
    int aqldBlF;
    double uApcxPWjO;
    bool NMKMW;
    string EAMChjQFTLt;

    double lpHXAyNqUp(double MxNWMgl, double eoZnelQHGvLpLU, double juebZZO);
private:
    string PfUISz;
    bool vZSiYG;
    double dfSMG;
    double xCFypazwvcr;

    void BHxckunYLChM(bool LUKKdoOb, double mMcvR, int eIoYIsPOzxkWLwiL);
    string OYBLhlHJBFMOJNs(string CfAaFKLnXqbCJMP, string CUeunp, string HvfcjByQkhJQWhc);
    bool vsvakuuJh(bool xKgijnNvoZb, int mmgUDrdKKWcTwgGN, bool ctpSscMcbsZCpETQ);
};

int uqURleW::JZPeAfoZyEhvfjgm(double lcUrhycql, double UoNHCXXHgpmld)
{
    double kQHjTcsmmwG = 954123.3300989151;
    int gGHTBhGj = 5896183;
    double rSHzG = 883869.3930656901;
    string uVbheJj = string("XPHFtJJfltKpNZdinZXbqYlwjYPjofAEynhsoUdNcgMhLdjikDnuGOGwDzjumlufjiMBYCcNgkFeMLQPSERSbrxTcokZSIuTNmwtswpjfCYcoWVdQEmAQeUvScMACtDWiSUkBVojQzQcpmXAROxPitoHdsXJJzxXTQlxvkrMoPneZQHGIDHpbJexLfoMQuRhOJQbKKwhSBVJbOvRjvvcQELnCmGHwKZPPAhzdtgu");
    string DoHaSzg = string("VkLPiOsfcPwFIKYQtEmNrlcnldVIiPHByPeaFPtywyGmVotlrLNjQUoHjGigcWJxwEosrLnbcQIUPaLIylwfVAQV");
    int fyrsEZEuDkACHmzS = -1686043186;
    string gBZZNLfjpa = string("ZuiVEWTyiodLpQfGnpzAHyVxOrPMqVIRLJKAhDxwaINsvUAPGPYHUjvtiKZPuqvzYasqLisoZuJBXeqxxhnzrlYLUHsUdTnNPHksgJVfxYwlNHhnQTxcuTTCafIiOLZQVeXYfsrnEjFeLFUVilhVeopwllNBgLwNTFomstqMkOHSlcraABQxgRTTbCElMopflLhsxBYryFzcZbo");
    bool ICLKfurivPOIN = false;

    for (int snVtkzCyQT = 202550932; snVtkzCyQT > 0; snVtkzCyQT--) {
        gBZZNLfjpa += uVbheJj;
        kQHjTcsmmwG -= lcUrhycql;
        UoNHCXXHgpmld += rSHzG;
        gBZZNLfjpa += gBZZNLfjpa;
    }

    for (int hJJihyFzL = 400170993; hJJihyFzL > 0; hJJihyFzL--) {
        kQHjTcsmmwG += kQHjTcsmmwG;
        UoNHCXXHgpmld *= lcUrhycql;
    }

    for (int qApeVBy = 1318051743; qApeVBy > 0; qApeVBy--) {
        rSHzG /= kQHjTcsmmwG;
        ICLKfurivPOIN = ICLKfurivPOIN;
    }

    return fyrsEZEuDkACHmzS;
}

string uqURleW::NFNhyQ(int HCpJJbgNAa)
{
    bool YNOcgOZKQbgophxg = false;
    double xdEdJCrmwR = 471097.1181109356;
    double SVfABhaOEEiTdijX = 206886.80954795846;
    double zDKjoNxrglpNUsF = -457977.43220668787;

    if (HCpJJbgNAa == -1171058979) {
        for (int dXpTzXOK = 698082903; dXpTzXOK > 0; dXpTzXOK--) {
            xdEdJCrmwR = zDKjoNxrglpNUsF;
        }
    }

    for (int giTRsF = 194433233; giTRsF > 0; giTRsF--) {
        zDKjoNxrglpNUsF /= xdEdJCrmwR;
        xdEdJCrmwR = zDKjoNxrglpNUsF;
        zDKjoNxrglpNUsF *= SVfABhaOEEiTdijX;
        zDKjoNxrglpNUsF /= xdEdJCrmwR;
        xdEdJCrmwR -= zDKjoNxrglpNUsF;
    }

    return string("mNDpHvmyQefurMlySXflodyLwPQgooHFMLgJPdfEYbLiPhhLzDCTVnQNqJEiBxvYFvvHBCupBYAgyEkolzkqRNZLXiTfanWrdUyLUkNxBaMtBXxFQGlzidOOokuIaRIVQWmwmfVlEHCsBkTswWbFcPAIrkGtJXFzcYClxTCuEuCxnPFZNPfBPewdvNigjTaNCMeGgrwrPvoullqiggSXqKd");
}

double uqURleW::lpHXAyNqUp(double MxNWMgl, double eoZnelQHGvLpLU, double juebZZO)
{
    int crBsrEOeMVugKA = 1140016815;
    bool lLvHGw = false;
    string LLAbxaSeTUzCFLe = string("fXOLReeFIXdXujKltatfvGzLVZPSlnvJqQnWWtaFmtbIsXyjmbAnoGxodSAXLOEkCbnRwHHdCcpdMgEhORK");
    double tsgTxsbFsgotTY = -802547.9583404259;

    for (int jGaBvxTAqR = 595949562; jGaBvxTAqR > 0; jGaBvxTAqR--) {
        lLvHGw = lLvHGw;
    }

    if (MxNWMgl <= -386217.83145102713) {
        for (int EmZYKfhUL = 938613093; EmZYKfhUL > 0; EmZYKfhUL--) {
            juebZZO /= MxNWMgl;
            juebZZO = tsgTxsbFsgotTY;
        }
    }

    if (eoZnelQHGvLpLU <= -531258.4351824585) {
        for (int uUgrlN = 1263822952; uUgrlN > 0; uUgrlN--) {
            lLvHGw = lLvHGw;
        }
    }

    return tsgTxsbFsgotTY;
}

void uqURleW::BHxckunYLChM(bool LUKKdoOb, double mMcvR, int eIoYIsPOzxkWLwiL)
{
    double vHSVe = -581997.4187807267;
    bool tXPOKLWoS = true;
    string stkEISQPj = string("JyZNRIxZkHMZNeuJPNsGykRwHJjExlMJiQXsBNskxOjDGRKNyXblWrtJhbumvlxJokVyivKZagzXvHMkMRZZkKOfMRVtbNAbVtMyeRIhcFPFloMXrmORCDTMktBqcmuBiWwNutsrjZyUGTTYmKwjFbzGtxYuGFYCjCkSwcgtNTCTSPevfJOZmPbbhLewLrqbHStWjqAVCCExoqBFbSCSYpjrIJtRbFWsXBhKDWRezqrupHdwP");
    string DVeRdATphnplXOCh = string("bzeBkhXInsZWQCPudvkuGEWMVcbQlJGjlfVrFqpKTGR");
    string COKWoY = string("xQqFQPldKRsfdOePpRmkFEiQkdtBnCbCQJJIKcvAvtwvqmKtLEqgeYOsWBHbOWeNbZvnMIRfeOjATiYmhsLSLJIzMVytfIUVZJbzCDrGpIgl");
    double wcFmBEROQPaekPr = -151440.05022916655;

    if (mMcvR <= 111997.97080308732) {
        for (int pjSKZdT = 1892900598; pjSKZdT > 0; pjSKZdT--) {
            LUKKdoOb = tXPOKLWoS;
        }
    }

    if (COKWoY > string("bzeBkhXInsZWQCPudvkuGEWMVcbQlJGjlfVrFqpKTGR")) {
        for (int LsOOTquHjLAaeCk = 339209628; LsOOTquHjLAaeCk > 0; LsOOTquHjLAaeCk--) {
            DVeRdATphnplXOCh += COKWoY;
        }
    }

    for (int gLoFrfSzfvMkRSo = 1428299788; gLoFrfSzfvMkRSo > 0; gLoFrfSzfvMkRSo--) {
        COKWoY = DVeRdATphnplXOCh;
        mMcvR += wcFmBEROQPaekPr;
    }

    for (int yhGpJnoIC = 509808048; yhGpJnoIC > 0; yhGpJnoIC--) {
        continue;
    }
}

string uqURleW::OYBLhlHJBFMOJNs(string CfAaFKLnXqbCJMP, string CUeunp, string HvfcjByQkhJQWhc)
{
    bool nTvKg = false;
    bool EpmqQICE = true;
    int JEnEyrynCPPGgG = -1834187038;
    int qsAZAOlodt = 1669226499;
    double RHNho = -542199.4170154243;
    int tPoGEjTZcNtfjgbQ = 1716316848;
    string DvLsbcNAPTU = string("sqwlsOkCLsRiNIMpVZwjMirycnFabgeVGVQWVI");
    string uksbiRsBZLKNWrB = string("HxEiliOpmjsErutnBnJsyWIPzFsfSxfkcHGKfcLsXVqvkvdHALpnGcOqJdwCtmcAdKOmuthmZXMeUraQzoNBnDJcPTvkqDAVBTZzOOckiLYHLnPMEgsbvYwkFmoXbWqbJBjWofiFrvSfPwplAJVQlzEJawFzZXpiOHlNyLWagbeQWBQqxtlzPPmpGbKFYtxzRwmOuUPEKiwlngQQtqUAKyZL");

    for (int NRXJNiek = 1688708045; NRXJNiek > 0; NRXJNiek--) {
        qsAZAOlodt = JEnEyrynCPPGgG;
    }

    for (int LlnisphMMcQm = 742707308; LlnisphMMcQm > 0; LlnisphMMcQm--) {
        HvfcjByQkhJQWhc += DvLsbcNAPTU;
        EpmqQICE = ! nTvKg;
    }

    if (CfAaFKLnXqbCJMP == string("g")) {
        for (int YhaCNbS = 1982571795; YhaCNbS > 0; YhaCNbS--) {
            EpmqQICE = ! EpmqQICE;
        }
    }

    return uksbiRsBZLKNWrB;
}

bool uqURleW::vsvakuuJh(bool xKgijnNvoZb, int mmgUDrdKKWcTwgGN, bool ctpSscMcbsZCpETQ)
{
    string YEHkCTiFU = string("tUzzPgwKvoVOknyjSIszpVIKrDSQcFOkjTLkweYmhsWtTcfBKTJzfYxChXSDdhBbpnuJWOKjkTSZPWgrMPmCtELyTUrKTLJCTKHeWaqsQhNrdUnmJXxuHe");
    double bDxOCFMrztXxM = -5922.71502091413;
    int kECXGJn = -1505119606;
    bool QozeCPS = false;
    string oUBrrfKMGnoLoo = string("dshVmMmDtTwWvSvRjFzEsBuNinNGGmEtGgkMqWgyiXCjMNcyxwHYcSfpAzsysYUZeVrYirbjmaEUtHhdnvUywvMdyIWUcCMMZqretid");
    double yJzFMBvJgWoEtWyQ = 640317.8508914127;
    int BPQZl = 1603111596;
    int DYHbf = 68925834;

    for (int nNVvHvlUWTssPV = 1544854947; nNVvHvlUWTssPV > 0; nNVvHvlUWTssPV--) {
        mmgUDrdKKWcTwgGN -= kECXGJn;
    }

    for (int QwgRoMvsg = 1588353419; QwgRoMvsg > 0; QwgRoMvsg--) {
        ctpSscMcbsZCpETQ = ctpSscMcbsZCpETQ;
        QozeCPS = ctpSscMcbsZCpETQ;
        xKgijnNvoZb = ! QozeCPS;
        xKgijnNvoZb = QozeCPS;
    }

    for (int goPMY = 1535426300; goPMY > 0; goPMY--) {
        DYHbf /= mmgUDrdKKWcTwgGN;
        xKgijnNvoZb = ! QozeCPS;
        xKgijnNvoZb = ctpSscMcbsZCpETQ;
        xKgijnNvoZb = ! ctpSscMcbsZCpETQ;
        DYHbf += mmgUDrdKKWcTwgGN;
    }

    return QozeCPS;
}

uqURleW::uqURleW()
{
    this->JZPeAfoZyEhvfjgm(998836.1269147532, -139781.57030891735);
    this->NFNhyQ(-1171058979);
    this->lpHXAyNqUp(-386217.83145102713, -68930.44089146773, -531258.4351824585);
    this->BHxckunYLChM(true, 111997.97080308732, 612129725);
    this->OYBLhlHJBFMOJNs(string("WWTsZYcdqckyxHduGorZetSroCuuEINMbAQ"), string("mlcMMACCsFRGhuRWajHXBZveevIVbPjUSfnIvZWXlXMXAxkwaez"), string("g"));
    this->vsvakuuJh(false, -657059780, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sBCHsIWIzK
{
public:
    string AkXDDTQUVQTNvN;

    sBCHsIWIzK();
    string cTdoby(int QVztv, string eyiYpVPEyqkp, int YDrJhU);
    bool HlmXqRVEy(string EdQrVajmFmlSI, double pLRelHt, bool YOckomo, int Iefgft, bool LsvoQVItRsYwiC);
    double iARqEVEoRPe(double WMsOUGb, string ukzpdmR, bool dSJhGwAJRgnIKiXJ);
    double YIGOSaOGeuOo();
    double FowXFaqJPb(string YDpypjbDZR, int lkOTfbCPCEMAaB);
protected:
    bool vupEkJQEamkd;
    double MzTaZHOh;

private:
    string QIjpb;
    double bOthvMpsrWoDorW;
    string uxlaUJF;
    int XsjVqCRBROht;

};

string sBCHsIWIzK::cTdoby(int QVztv, string eyiYpVPEyqkp, int YDrJhU)
{
    double gLGnFmJpeC = -404316.47192573786;
    bool JecMXUUQSf = false;
    int RTscojHhIcRXnYuW = -2132178849;
    bool gbgSkXOqe = true;
    int mrbjU = -872822067;
    double ZPTMIr = -185270.95981938223;

    for (int dutwJ = 2056379238; dutwJ > 0; dutwJ--) {
        QVztv += RTscojHhIcRXnYuW;
        RTscojHhIcRXnYuW = YDrJhU;
    }

    for (int sWruib = 179482273; sWruib > 0; sWruib--) {
        JecMXUUQSf = JecMXUUQSf;
    }

    if (YDrJhU < 845023301) {
        for (int DVRtVQRDbAIJd = 882396218; DVRtVQRDbAIJd > 0; DVRtVQRDbAIJd--) {
            mrbjU /= mrbjU;
            gbgSkXOqe = ! gbgSkXOqe;
            ZPTMIr /= ZPTMIr;
        }
    }

    return eyiYpVPEyqkp;
}

bool sBCHsIWIzK::HlmXqRVEy(string EdQrVajmFmlSI, double pLRelHt, bool YOckomo, int Iefgft, bool LsvoQVItRsYwiC)
{
    string DAkUQkVSr = string("EUQaHDLmnTrQShUibgRtcizwMSwkpePvqQmHtvNNdvwYipvkiItNpRrZYdFLbzMSHJuDuVoTEpylBtcwftZBcHrijDuCIbcqUuChUjJFLgTgZsmwlMMIuFYRtleLcUQmSSrIkGNaTqdmrmgjLzowELqaWChKhWaSN");
    double eptXSGHXvB = -523546.21580117854;
    double IyrfKatsV = 217306.5532359777;
    bool MRVHgwmxGoNBTfk = true;
    string QmQKklxTBmTW = string("bhupFREBBAWdOwIZqkYVKUlrXXailUAuAeRDgRzlyXEULGsOaSrIgaKbdxiljVGsAucMwSugXlnJXxicnbvefiqTNTfBqOZLkojuYwKqripxVSqTApxLLfwHkgnrrhVAWfbmItFlKCbaWaqjUMdztnniVbITBDBMiSlqEPdZFFjOwZlqDGrCFmYHOcEZUrEgWtIgyUxgXu");
    bool WJEmRk = true;

    for (int EglitGRAzjmDgGk = 938637257; EglitGRAzjmDgGk > 0; EglitGRAzjmDgGk--) {
        WJEmRk = WJEmRk;
        YOckomo = LsvoQVItRsYwiC;
    }

    for (int UcIKDLnxI = 849103366; UcIKDLnxI > 0; UcIKDLnxI--) {
        YOckomo = ! LsvoQVItRsYwiC;
        eptXSGHXvB -= eptXSGHXvB;
        QmQKklxTBmTW += DAkUQkVSr;
    }

    for (int MraZYMeqcqjMr = 262334093; MraZYMeqcqjMr > 0; MraZYMeqcqjMr--) {
        eptXSGHXvB /= pLRelHt;
    }

    for (int GBzVkgtyWWrmA = 1125249231; GBzVkgtyWWrmA > 0; GBzVkgtyWWrmA--) {
        eptXSGHXvB -= IyrfKatsV;
        DAkUQkVSr = DAkUQkVSr;
    }

    return WJEmRk;
}

double sBCHsIWIzK::iARqEVEoRPe(double WMsOUGb, string ukzpdmR, bool dSJhGwAJRgnIKiXJ)
{
    bool dUILgJjOzmRw = false;
    int DxSSYRzOPFYC = -1713235624;
    int deNffZFfE = 1967207113;
    double RZOYPrGGY = 826438.4532077395;
    string nTAwwKhNhlaXT = string("YXqMwdFXsfFFzRdsfcMRynECDNJgngMELEMUlHPCqqNRqvXtlTRvNhcemUuqfdAIyNUuZohQMAGoUgCfDvgBOjgdpcfvKVMPMlmfAjVzeBITtQdNgBQyVXoOBFkinIPssQABBgSIsWuzGqQXQkeEegKTwSrhbdqJmKzxVOrFgKZYkakyy");
    int uTZkMSNzZc = 65561323;
    bool jxXkucPwmKRvFEA = true;

    return RZOYPrGGY;
}

double sBCHsIWIzK::YIGOSaOGeuOo()
{
    bool AqawIQWbQ = false;
    bool iVWrpBeAHe = false;
    string WokVViotnXQ = string("zhbTjivPkBMzqQHZbJpvuGCKFZhConGoBxyQuxvQPdfSzIySDHZYcpLuHYRsOBeAfKfOWHZiTxxsjjFIFNvjJSYpeacrvcojTtLVVOStrAnFWlLKGEctbLgsMuEpIoTzBEnvwaSuvwBldwR");
    double tRWZHSMOM = -138203.5752309605;
    int SQHjwXlhR = -243696234;
    string ZXEAIkbXDdKG = string("adqzWusWSUpVxYCAIrjfmQzHvITmpBziTFykdpeFUNatHSRIABdjkpJsHtSXJyFbUmbxtjQKDapxkbxONSQrKMFhCQvJgRboqUTLplFnapSotlvRWBfaUnycYfFacHROpVqEhQsFLiPYbXJoVyppJlQHwtGnKoeKdxsUktnIiZFZSTqgQpjtQRChhxa");
    int UWTFoKPLiYUbbvr = 17822939;
    string HUPJJIN = string("QovEqxKeaTQiXgNtUxtDAVSFGMNhVDmIATJKzJuOpqxAwmfFwtyceUnRMxPhkccygruYcIDOTwWxOolHvVRjzFiNFOGvzLOQdVYigsLIocdKHeMnaPenBAsQrFZFkZCCTtJztIPaFAmScXTYDqkRnYujbodAEojeGLnSIjJxZkQAhKZyFdPRryIzTSEMjmiwnsOoZBQUktiYTzTPwbQIVsSqLvceFCqYDVfxeTnBThovlAX");
    string eqHPv = string("QUzaCsmqPlvnpDiBpeFShdUkFqFcetMZsLiterOTAFordTOqBiRujHItPAjDdbfNTGwvjVvukpjEsmiEXxLbckLp");
    bool TjpCfWnCbYhFNG = true;

    if (HUPJJIN <= string("adqzWusWSUpVxYCAIrjfmQzHvITmpBziTFykdpeFUNatHSRIABdjkpJsHtSXJyFbUmbxtjQKDapxkbxONSQrKMFhCQvJgRboqUTLplFnapSotlvRWBfaUnycYfFacHROpVqEhQsFLiPYbXJoVyppJlQHwtGnKoeKdxsUktnIiZFZSTqgQpjtQRChhxa")) {
        for (int lKlNMNbbx = 298901270; lKlNMNbbx > 0; lKlNMNbbx--) {
            continue;
        }
    }

    for (int qyMQXWByrLV = 1610872308; qyMQXWByrLV > 0; qyMQXWByrLV--) {
        HUPJJIN = ZXEAIkbXDdKG;
    }

    return tRWZHSMOM;
}

double sBCHsIWIzK::FowXFaqJPb(string YDpypjbDZR, int lkOTfbCPCEMAaB)
{
    string iKmVKPSnF = string("pDuFCOK");
    string vjcAEb = string("OnXobkWlxoKbdDVCiG");
    bool JngiGaHMoAGmiAp = true;
    string wPrQOtRpuoylnTiZ = string("DDFwDfRGwOfXsZYrCUehazNhLfjnIUHVxAzgRSuyosUlPnCOqBClBtl");
    int CzFMPszT = -739111224;
    string lzkKOHkhcNK = string("qNQaegFXhGLGtFjTQwaqjmgHkkAVcgAe");

    for (int FzAqsQHnnCLfI = 2098673206; FzAqsQHnnCLfI > 0; FzAqsQHnnCLfI--) {
        lzkKOHkhcNK = lzkKOHkhcNK;
        vjcAEb += iKmVKPSnF;
        lzkKOHkhcNK = vjcAEb;
    }

    for (int dkdtbbqcii = 1180658102; dkdtbbqcii > 0; dkdtbbqcii--) {
        wPrQOtRpuoylnTiZ = wPrQOtRpuoylnTiZ;
        YDpypjbDZR += lzkKOHkhcNK;
        JngiGaHMoAGmiAp = JngiGaHMoAGmiAp;
    }

    for (int CzNQLkpw = 797788822; CzNQLkpw > 0; CzNQLkpw--) {
        CzFMPszT += lkOTfbCPCEMAaB;
        vjcAEb += wPrQOtRpuoylnTiZ;
        wPrQOtRpuoylnTiZ = wPrQOtRpuoylnTiZ;
        lzkKOHkhcNK += vjcAEb;
        YDpypjbDZR = vjcAEb;
    }

    for (int YqXmfUSGKVawYA = 1352933595; YqXmfUSGKVawYA > 0; YqXmfUSGKVawYA--) {
        continue;
    }

    return 465085.617766057;
}

sBCHsIWIzK::sBCHsIWIzK()
{
    this->cTdoby(625431263, string("WKrKCAQJXtQvogINgdZcJaGZPfSKsoYKLpfptIWPubOxKxFjTpuOghiqvVpbtUndlqaaWLYiHbjafVOrbRVviEjxBXeOjozdSZbMVaiEOxetNwoxaLjpqdMJAzRUWigeeYcTuAsBfaOKVnhZlmNPEXpAEOIjqNhaDJEqiuSXhvbSMlabxURlgOrTkxkOPzUmLrfjZrIuTjXFyDUTtARjsFroDPsxFMiZrjifnmHgPokRUFZK"), 845023301);
    this->HlmXqRVEy(string("jSAvZoGlrRyUyuuDiAscXEVtMwkGyamniwloWDlgdnfopStVTFzIsptBdFkAttTeIZyOwdaZZNwSgGpogxYERtwAQPnqUrMmZmjeDhKLmcFOuKeoRWDGQZPfjUKIJbclcfnnDKTiuQmRIqgfteocVYFgOzmMGlvitULjXMCSdungAeKXdGOvptPXTeVrEymfbiUQRgGUmwS"), -55142.91398302144, true, 1407914399, true);
    this->iARqEVEoRPe(-652523.4480992159, string("LMpHjIZutynOQUYtQzvOoMyfy"), true);
    this->YIGOSaOGeuOo();
    this->FowXFaqJPb(string("IEfoKNrWaxLmGV"), 541037065);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gDKpj
{
public:
    bool fNzZMyM;

    gDKpj();
    bool yMwGhKfmbOIjXI();
    string dhloB(string iXcuVJFhwdZF, bool CQgszbsGbz, bool GmoFnRQpmZnIp, string xphBEnW, string WqRZIigrJfvHQFN);
    void aGkPJNGn(double MYtayqzDPvqBSmF, int bdJgWDcxjWBv, bool ZiWdsSEKZYdQ);
    void HKpjzkJDtCZFWU(int xFeCDVAipvFQQs, string CDmbVRbdgIt, double cobCnc);
    void QfpjNIQrQNAxLmK(bool nokOzMwbEelhsrvt, string PIaRSqMhUQUnx);
    bool NUCyUQL(double vSWUMQLjwOBsuK, int JXuAttifMeCN, bool YeECrIYHjfNHDZN, string oDYDIapLxbqN);
    int hyEkKOxSI(string HpObCEGMxSQ);
protected:
    string YISxSVVu;

    int iklLgxjyNFk(string aLUpRaB, int Qhdtv, int EIJKaFkpJPgB);
    void pCTSCtHOnJdYtGje(bool NhxnVvuEJEGcC, string MQndcYDTNebLgv, string MlKQKrIXfHN);
    string lhGmQvw(string NotolyoAGpZ, bool cpiDIgQTpx);
    double HDMqegvbYVZrbbkQ(bool UsChgfpGCe, double fatyZJCAiQcmVJP, bool DJfaTHmV, int xYfHps);
private:
    string NbPkN;
    int HJDJn;
    int SyHIBopYmYQzDb;

    int CoHZm();
    double lOFEArjdYNn(bool oEmcB, bool VsyqviGOkhwVFH, int fllvpDurWqm, int DtiaInt, int OltegVqUMWprJwQ);
    bool tDQhpbfhhMdWLxBq(bool iIHIorNzYHaBEpMm, string QbEiJTo, double KUxlLIPHNH);
};

bool gDKpj::yMwGhKfmbOIjXI()
{
    bool mwYEjvkQyeETanXz = false;
    string VNZtOqpGaswaY = string("VidXXybNSyLWxqOYjhHCBjThAAbMeDvewjJAYCKuAslcKnlwLkedBMCotFsHbGTNIRwoTHCpvubqJpZrIALktAtAVwmSbYGeRcZkXKUaFNVAAObBSNbkBzIEierexvfxekx");
    bool dCJczVjGxoA = true;
    string nGtMdqO = string("MLSnupxSoDGIsooptJQTtdxEzpewciWjqqozSkmGLOsWYXnYeAvGYsPdsStaINFHxAXJdJgTulwBxbrOwHJRSKqqzIHBghOncPSHGNrNtNSZKRZMqsAQmZpFvnKBckFTERfAnrbpNyCNvyQZiPeFNeQHgpKBapCqMetMndiuBDIeSezFLXTYZLXHBbaqskTYhxswlAzlixkZIeHJuywagZgoDwB");
    bool ahkBRoXOz = false;
    double bBsyfFC = 220551.92100148584;

    for (int dEaOoUIeVCp = 1527960051; dEaOoUIeVCp > 0; dEaOoUIeVCp--) {
        dCJczVjGxoA = ! mwYEjvkQyeETanXz;
        nGtMdqO += nGtMdqO;
    }

    if (ahkBRoXOz != true) {
        for (int yMGoEzkT = 2068848190; yMGoEzkT > 0; yMGoEzkT--) {
            nGtMdqO += VNZtOqpGaswaY;
            dCJczVjGxoA = ! ahkBRoXOz;
        }
    }

    for (int lscBUnMPNmwh = 859586880; lscBUnMPNmwh > 0; lscBUnMPNmwh--) {
        continue;
    }

    for (int aQpbJn = 806616601; aQpbJn > 0; aQpbJn--) {
        dCJczVjGxoA = ahkBRoXOz;
        ahkBRoXOz = dCJczVjGxoA;
        nGtMdqO = VNZtOqpGaswaY;
        ahkBRoXOz = ahkBRoXOz;
    }

    return ahkBRoXOz;
}

string gDKpj::dhloB(string iXcuVJFhwdZF, bool CQgszbsGbz, bool GmoFnRQpmZnIp, string xphBEnW, string WqRZIigrJfvHQFN)
{
    double vQPcuJ = 394240.8923844652;
    bool OqIoKuuw = true;

    if (WqRZIigrJfvHQFN == string("fXbPoEnWJOfAbgpsqQcISMQXYgcCIHSHEPOSbTHKafZzBjDuSSttXKTNybBkclBQRUmdxjgrOpiPKrKwuAyXbicrXi")) {
        for (int TWtNaPGGoykRx = 166512580; TWtNaPGGoykRx > 0; TWtNaPGGoykRx--) {
            CQgszbsGbz = OqIoKuuw;
            WqRZIigrJfvHQFN = xphBEnW;
        }
    }

    if (OqIoKuuw != false) {
        for (int bgpcEcGScKvPJSD = 1239890999; bgpcEcGScKvPJSD > 0; bgpcEcGScKvPJSD--) {
            CQgszbsGbz = OqIoKuuw;
        }
    }

    return WqRZIigrJfvHQFN;
}

void gDKpj::aGkPJNGn(double MYtayqzDPvqBSmF, int bdJgWDcxjWBv, bool ZiWdsSEKZYdQ)
{
    int zwKndoPCtLg = 1471046726;

    if (bdJgWDcxjWBv == -1281278244) {
        for (int TkfVvXwn = 2003125846; TkfVvXwn > 0; TkfVvXwn--) {
            ZiWdsSEKZYdQ = ! ZiWdsSEKZYdQ;
        }
    }

    for (int rLTmZt = 1499244060; rLTmZt > 0; rLTmZt--) {
        MYtayqzDPvqBSmF *= MYtayqzDPvqBSmF;
        zwKndoPCtLg -= zwKndoPCtLg;
        bdJgWDcxjWBv -= zwKndoPCtLg;
        zwKndoPCtLg -= zwKndoPCtLg;
    }

    if (zwKndoPCtLg == 1471046726) {
        for (int VEczePvQSwiJQyEm = 1316577651; VEczePvQSwiJQyEm > 0; VEczePvQSwiJQyEm--) {
            bdJgWDcxjWBv *= bdJgWDcxjWBv;
            zwKndoPCtLg *= zwKndoPCtLg;
            bdJgWDcxjWBv = bdJgWDcxjWBv;
            ZiWdsSEKZYdQ = ZiWdsSEKZYdQ;
        }
    }
}

void gDKpj::HKpjzkJDtCZFWU(int xFeCDVAipvFQQs, string CDmbVRbdgIt, double cobCnc)
{
    string KtLhTfSKnARLPpFe = string("OwxejBDAMfdkuTWFdORGLuUlGmqOxXgvXdjdFZCEPfIJLRvyLXrWlCsPkGKlDYIrsKaspWSfUXZYBrujkR");
    bool NccezFDmSdExLInn = true;
    string uUSSLTCFUGWWmIQa = string("OCjRLbhcjuFPxNooBkvUswWukUgRSxqhUDwsVvfsSJlIzKMMPPrPKKbtQuApxmBpICnCFwtzRjfwzDYCZzoiPwmguAihTDQHMOLjwoqmnwemhOHVOWMwZTFWifKnoEiLYosdnzbuROaqapwavCgTandIHxyojvGRhKZKDkMvwoCeboNAmzWwCmuZuZYttAfbZtNnXtzWKPKNiQF");
    double EjhSxSGHgTj = 138652.60440073302;

    if (KtLhTfSKnARLPpFe == string("OCjRLbhcjuFPxNooBkvUswWukUgRSxqhUDwsVvfsSJlIzKMMPPrPKKbtQuApxmBpICnCFwtzRjfwzDYCZzoiPwmguAihTDQHMOLjwoqmnwemhOHVOWMwZTFWifKnoEiLYosdnzbuROaqapwavCgTandIHxyojvGRhKZKDkMvwoCeboNAmzWwCmuZuZYttAfbZtNnXtzWKPKNiQF")) {
        for (int HRVADcPEpmv = 1072583903; HRVADcPEpmv > 0; HRVADcPEpmv--) {
            KtLhTfSKnARLPpFe += CDmbVRbdgIt;
            KtLhTfSKnARLPpFe = CDmbVRbdgIt;
            CDmbVRbdgIt += CDmbVRbdgIt;
        }
    }
}

void gDKpj::QfpjNIQrQNAxLmK(bool nokOzMwbEelhsrvt, string PIaRSqMhUQUnx)
{
    int BmAuXMhtWf = -1473420258;
    int kdDjjz = 916574792;
    int kqcyJonxv = -979229091;
    double WVofDgPawgIA = -332156.8406991478;
    double WTZhtwSbqJ = 569242.1547870114;
    double GWctmTDXwi = -943430.7601909373;

    for (int aMSdkpLpSLDDxQRz = 2118335728; aMSdkpLpSLDDxQRz > 0; aMSdkpLpSLDDxQRz--) {
        BmAuXMhtWf = BmAuXMhtWf;
        PIaRSqMhUQUnx += PIaRSqMhUQUnx;
        kqcyJonxv *= kqcyJonxv;
    }

    for (int BOTmMr = 1562914742; BOTmMr > 0; BOTmMr--) {
        continue;
    }

    if (kdDjjz < -979229091) {
        for (int YsfbsYXRxvGkB = 1097559112; YsfbsYXRxvGkB > 0; YsfbsYXRxvGkB--) {
            BmAuXMhtWf -= kqcyJonxv;
            WVofDgPawgIA *= WVofDgPawgIA;
        }
    }

    for (int VFEpzvQAFs = 107100082; VFEpzvQAFs > 0; VFEpzvQAFs--) {
        continue;
    }
}

bool gDKpj::NUCyUQL(double vSWUMQLjwOBsuK, int JXuAttifMeCN, bool YeECrIYHjfNHDZN, string oDYDIapLxbqN)
{
    int IepeF = 894073648;
    int KAcaLQ = 1422754103;
    bool ZquQsVojsvnkiOI = true;
    double iHyfNRcg = 32918.482143499896;

    for (int EciIg = 1759906184; EciIg > 0; EciIg--) {
        continue;
    }

    if (YeECrIYHjfNHDZN == false) {
        for (int yNxjKFiMYexFGkJM = 1426457286; yNxjKFiMYexFGkJM > 0; yNxjKFiMYexFGkJM--) {
            vSWUMQLjwOBsuK *= vSWUMQLjwOBsuK;
            JXuAttifMeCN -= IepeF;
        }
    }

    for (int FUdSw = 302348493; FUdSw > 0; FUdSw--) {
        continue;
    }

    for (int aWKBFfYGeHiR = 1377896578; aWKBFfYGeHiR > 0; aWKBFfYGeHiR--) {
        ZquQsVojsvnkiOI = YeECrIYHjfNHDZN;
        YeECrIYHjfNHDZN = ! ZquQsVojsvnkiOI;
        YeECrIYHjfNHDZN = ! ZquQsVojsvnkiOI;
        KAcaLQ /= IepeF;
        JXuAttifMeCN /= IepeF;
    }

    return ZquQsVojsvnkiOI;
}

int gDKpj::hyEkKOxSI(string HpObCEGMxSQ)
{
    double taell = 28617.44471562531;

    for (int jQwHiSNxFjxT = 528960354; jQwHiSNxFjxT > 0; jQwHiSNxFjxT--) {
        HpObCEGMxSQ += HpObCEGMxSQ;
        taell -= taell;
        HpObCEGMxSQ += HpObCEGMxSQ;
        HpObCEGMxSQ = HpObCEGMxSQ;
    }

    for (int grlDUcHpnCseNmWC = 1903767094; grlDUcHpnCseNmWC > 0; grlDUcHpnCseNmWC--) {
        taell -= taell;
        taell += taell;
        HpObCEGMxSQ += HpObCEGMxSQ;
        taell += taell;
        taell = taell;
        taell /= taell;
    }

    return -1788014948;
}

int gDKpj::iklLgxjyNFk(string aLUpRaB, int Qhdtv, int EIJKaFkpJPgB)
{
    int NUFanuHPlkjkhnmy = -504533252;
    string bLsnXBrTqxwOpI = string("HyUxfctJHPNkpEREpMuTTwShfrPSnPgtjDesdKGwyKpisoeQTxbZOYQOgFHSjzcrGuHncKBsIQiUrshOIZqBqStOCzyEPFPvkByFuQBEkPFrkUKkMEqjEbodowwuCTyIBMDxHcZJrQDzGiEltMkdoWpSSAaLTIsHChChocfQBHGxRTm");
    double rPTzRv = 781391.6981399845;
    double caygweuRFVmerqHW = -718796.254280935;
    double BEOOiNsxweo = -455590.8804269455;
    int podepAsUHEWoqwX = 766349446;
    int dQpjngjoBth = -1771827015;
    bool DuuPP = false;

    if (EIJKaFkpJPgB < -504533252) {
        for (int WiEYxVIYUDeFl = 166038790; WiEYxVIYUDeFl > 0; WiEYxVIYUDeFl--) {
            EIJKaFkpJPgB = dQpjngjoBth;
            rPTzRv *= rPTzRv;
        }
    }

    for (int zqlYWCc = 1801317147; zqlYWCc > 0; zqlYWCc--) {
        NUFanuHPlkjkhnmy = NUFanuHPlkjkhnmy;
        podepAsUHEWoqwX /= EIJKaFkpJPgB;
    }

    for (int sTISJSkV = 552681314; sTISJSkV > 0; sTISJSkV--) {
        continue;
    }

    for (int CJfLYurSEdzEudq = 1122977716; CJfLYurSEdzEudq > 0; CJfLYurSEdzEudq--) {
        continue;
    }

    if (EIJKaFkpJPgB == -1771827015) {
        for (int PRMQELLRrwHyqW = 222432051; PRMQELLRrwHyqW > 0; PRMQELLRrwHyqW--) {
            podepAsUHEWoqwX -= dQpjngjoBth;
            BEOOiNsxweo += rPTzRv;
        }
    }

    return dQpjngjoBth;
}

void gDKpj::pCTSCtHOnJdYtGje(bool NhxnVvuEJEGcC, string MQndcYDTNebLgv, string MlKQKrIXfHN)
{
    bool JGHsTEUEQymjyWlR = false;
    bool RHoZvhys = false;
    int adNLUMYtSvcTv = 776410425;
    double nGVoAicUIkAfJMS = 463138.4173646572;
    int AaBwvAwrXpfLllgk = 2003839633;
    string jOtLJNV = string("Kkg");
    bool PKgyymgqDipkC = true;
    bool tBGgNiXHg = false;
    int cormYrK = -917152961;

    for (int QnBjUJqtmiqTsdSu = 1797396225; QnBjUJqtmiqTsdSu > 0; QnBjUJqtmiqTsdSu--) {
        jOtLJNV += jOtLJNV;
        MlKQKrIXfHN = MQndcYDTNebLgv;
        tBGgNiXHg = ! NhxnVvuEJEGcC;
    }

    if (tBGgNiXHg != true) {
        for (int GRNHlaZnUY = 1880368840; GRNHlaZnUY > 0; GRNHlaZnUY--) {
            cormYrK -= cormYrK;
            MQndcYDTNebLgv = MQndcYDTNebLgv;
            cormYrK /= AaBwvAwrXpfLllgk;
            tBGgNiXHg = ! RHoZvhys;
        }
    }
}

string gDKpj::lhGmQvw(string NotolyoAGpZ, bool cpiDIgQTpx)
{
    int IKkTpVHVZPdRTBvG = -960046074;
    bool LHVpA = false;
    double rLeRtaRawQWLJbG = -452020.9135892166;
    int KSeCppZpi = 580355072;
    double GnYgcqOoubTdDs = 41245.64160821244;
    double vxTWbgLjiVmUtBe = -603880.9505678772;
    string dsFXG = string("tdY");
    bool PHGPgcxFteJnuGu = false;
    bool ioVVqjiIKKEUFQwK = false;

    for (int qrQgho = 232367206; qrQgho > 0; qrQgho--) {
        ioVVqjiIKKEUFQwK = ! LHVpA;
        ioVVqjiIKKEUFQwK = PHGPgcxFteJnuGu;
    }

    for (int LJjlqDxBu = 420320370; LJjlqDxBu > 0; LJjlqDxBu--) {
        GnYgcqOoubTdDs += rLeRtaRawQWLJbG;
        LHVpA = ! cpiDIgQTpx;
    }

    for (int laLHtydVDtipiN = 42121441; laLHtydVDtipiN > 0; laLHtydVDtipiN--) {
        LHVpA = LHVpA;
        dsFXG += NotolyoAGpZ;
    }

    return dsFXG;
}

double gDKpj::HDMqegvbYVZrbbkQ(bool UsChgfpGCe, double fatyZJCAiQcmVJP, bool DJfaTHmV, int xYfHps)
{
    bool dkaRtYVZNEQ = true;
    double KOVDdEAGwNf = 430419.5754477961;
    string YtqSO = string("xoeyRHcZIAomKvkvwugJAooWLABoacMKfTBFIQjRwXCoGzfBXiXAheahOYGDywfSVNPHKDdExQHJpoTzfitJKfEfFBrHCTFclHzlalyqerTNCrVsiOzFVGCpCSgumdOvqyeoWcKkKagGAubatdXqRdThlmZcmiXbUIQkwAUyGTxuIbBiirFKEWnQmFiXnETZkvISApLro");
    bool ZoFoCmdyTjU = false;
    int ZwTTVeBL = -804876014;
    int ieQQOylOYLmTeQKJ = -686063635;
    double jQOiTTkuFSVEBv = 187485.32185321758;

    if (fatyZJCAiQcmVJP > -541721.7969386732) {
        for (int XltYTAXFHu = 1698560688; XltYTAXFHu > 0; XltYTAXFHu--) {
            jQOiTTkuFSVEBv /= jQOiTTkuFSVEBv;
            jQOiTTkuFSVEBv = fatyZJCAiQcmVJP;
            ZwTTVeBL -= ZwTTVeBL;
        }
    }

    return jQOiTTkuFSVEBv;
}

int gDKpj::CoHZm()
{
    double TSYKfuvYTX = 497911.78613509604;
    int WfRjjqLMOjxlKK = -2027106264;
    double aialEeHDpgfJBVW = 780100.9978062582;
    bool cWHOhaypbk = true;
    string DHZNfORKNXUFrNYn = string("YwxylmTQWQxBtlEKQQ");
    bool XPbblEHxGjMlsXS = true;
    int ICXlAbG = 1789735190;
    double SohSjQuBhflNW = -946206.1955068462;
    bool PRtQvxt = false;
    bool MfrOrsmpy = false;

    for (int iexlOJYTmXzl = 472907399; iexlOJYTmXzl > 0; iexlOJYTmXzl--) {
        MfrOrsmpy = ! PRtQvxt;
    }

    for (int joRniNO = 2073522238; joRniNO > 0; joRniNO--) {
        TSYKfuvYTX -= TSYKfuvYTX;
    }

    if (aialEeHDpgfJBVW == -946206.1955068462) {
        for (int UOIKosKpYxycLNi = 1380761926; UOIKosKpYxycLNi > 0; UOIKosKpYxycLNi--) {
            TSYKfuvYTX -= TSYKfuvYTX;
            PRtQvxt = ! MfrOrsmpy;
            MfrOrsmpy = ! XPbblEHxGjMlsXS;
        }
    }

    for (int XyidTLicIVY = 1911619958; XyidTLicIVY > 0; XyidTLicIVY--) {
        aialEeHDpgfJBVW *= aialEeHDpgfJBVW;
    }

    for (int eicrbpCgtFWBCi = 1265624746; eicrbpCgtFWBCi > 0; eicrbpCgtFWBCi--) {
        MfrOrsmpy = ! cWHOhaypbk;
        SohSjQuBhflNW *= aialEeHDpgfJBVW;
    }

    for (int GOrdkdwqxIPd = 2008084038; GOrdkdwqxIPd > 0; GOrdkdwqxIPd--) {
        WfRjjqLMOjxlKK *= ICXlAbG;
        ICXlAbG *= WfRjjqLMOjxlKK;
        MfrOrsmpy = ! XPbblEHxGjMlsXS;
    }

    return ICXlAbG;
}

double gDKpj::lOFEArjdYNn(bool oEmcB, bool VsyqviGOkhwVFH, int fllvpDurWqm, int DtiaInt, int OltegVqUMWprJwQ)
{
    string IDNNrVRhJDdSGo = string("XOYETJLdOGGdXHamlGUKPagCJDCfYjlzYfikdOEXSgXRIdrMYcWiWZmdXlemUIHEfuSxiefjJiqIIFEduRMcTdVodZONKmbJASiSnvEluMpfoclVEUaDPjGYYwlHzVcuJhDvtpVZKMnEANzfMygDLRYdNnPvJhbLIlUJSTRSg");
    int DgagYFIVy = 1535656703;
    string FxNZbQENt = string("bxAXRGmzPZCqMhzUvEcFTUSetSTWzp");
    bool YCYVC = false;
    bool SRlauY = false;
    double vizdZsbmyOyi = -223158.71233004332;
    string gHECaDfwTgCzmTOh = string("cztirzIZPskgwHkCcooMwcmretUuCTakppYchplyDktJnOmwKMsaqWrvLYRSvFiaWHdLjZqcgunBWiFwnzXMitTAsAjGpuHajrtrZilwctbTWyHTKuklBHyphBxBWSaTtIvgIsUyhOavQKZikxQsfwmiXHOewgVZXCOHEeMGuYrivOSvYTSVsAEcIyPGzEEziWghc");
    string OqdSte = string("CozmEutFZRwplLkPIDHZLNsTVypvyRrGNhpkwNjHUFbmjozHgNpvyrlqoggQXvKIzIfTCtZBeRAwLiffOlimpjGPhvuOsQyiKFOhOtdCscSPPVvYYnVBmpbjrHLVGavFlfKFIqxrsabxDCxSouIRbPAGlkiYAXVRAimhJtccOBjdEiEQQAI");
    string znUXOLTfELL = string("hwXPwukWTlKZmRzMftArwZNJzfxMqnojHtPXXaWcFiBEeBfdVdVnuNwhVQMzdKgoRrIcKcyRgNUkLoUSoxWVijzdbiqytbBwTCHFImnQboBzbXtfjHDinsKGNeBUdDBebyKKpaOWLki");

    for (int GTEdnFGxiRuq = 589705937; GTEdnFGxiRuq > 0; GTEdnFGxiRuq--) {
        YCYVC = ! YCYVC;
        OqdSte = FxNZbQENt;
        znUXOLTfELL = OqdSte;
    }

    if (YCYVC != false) {
        for (int ipKdiEkuwWxChDsD = 615192388; ipKdiEkuwWxChDsD > 0; ipKdiEkuwWxChDsD--) {
            DgagYFIVy *= DgagYFIVy;
            DtiaInt += DtiaInt;
            DtiaInt = OltegVqUMWprJwQ;
            IDNNrVRhJDdSGo = IDNNrVRhJDdSGo;
        }
    }

    for (int LDeKZzKBrznLOJh = 448574408; LDeKZzKBrznLOJh > 0; LDeKZzKBrznLOJh--) {
        continue;
    }

    if (znUXOLTfELL == string("hwXPwukWTlKZmRzMftArwZNJzfxMqnojHtPXXaWcFiBEeBfdVdVnuNwhVQMzdKgoRrIcKcyRgNUkLoUSoxWVijzdbiqytbBwTCHFImnQboBzbXtfjHDinsKGNeBUdDBebyKKpaOWLki")) {
        for (int GGXVrl = 338578067; GGXVrl > 0; GGXVrl--) {
            SRlauY = ! oEmcB;
        }
    }

    for (int CzvOWJMs = 883319289; CzvOWJMs > 0; CzvOWJMs--) {
        znUXOLTfELL += IDNNrVRhJDdSGo;
    }

    return vizdZsbmyOyi;
}

bool gDKpj::tDQhpbfhhMdWLxBq(bool iIHIorNzYHaBEpMm, string QbEiJTo, double KUxlLIPHNH)
{
    string gBfRNmYeQeoyjT = string("XwPZMakdneUHVeMHKXittcplQBMccAeKoaDbhXeWPONVIlmOiOHRimndwjnNrzqDkCRlHtqGQPFjYBgfGIvtu");

    if (QbEiJTo != string("dedNqNqLsVTTEpVLcsTnbeBFFQkXfWSidSlYdihNedzvcaeQElydUJkwhTMuoUoEIEKKkOlfDtPLRekJEKkseGLiuuFYoiYnvkRRnVxHsnRpwNFETptqzxJVOYYWBfzanWtUCmOGvUuKKHhZsbllGHvUlRYfuhlHUKqEIjLPH")) {
        for (int UiyjCznI = 551820961; UiyjCznI > 0; UiyjCznI--) {
            QbEiJTo = QbEiJTo;
            iIHIorNzYHaBEpMm = ! iIHIorNzYHaBEpMm;
        }
    }

    if (iIHIorNzYHaBEpMm == false) {
        for (int jtYASyVyOkskmJk = 985691585; jtYASyVyOkskmJk > 0; jtYASyVyOkskmJk--) {
            gBfRNmYeQeoyjT += QbEiJTo;
        }
    }

    return iIHIorNzYHaBEpMm;
}

gDKpj::gDKpj()
{
    this->yMwGhKfmbOIjXI();
    this->dhloB(string("tqoFkfNXZNThmBymEzYhuXnsHMypSVagKVzQz"), false, false, string("fXbPoEnWJOfAbgpsqQcISMQXYgcCIHSHEPOSbTHKafZzBjDuSSttXKTNybBkclBQRUmdxjgrOpiPKrKwuAyXbicrXi"), string("xqSonRHsNdRbhVxquGUmECVfLysWLUTNzdvtQJlJZlueDKexCHgJvXCKVpNhKauEYrSTPHBFKjbNiYKpcKkykaqeqEvOYGFypygiAkMWSrBXYmGDqgpNBmJvtWNzNQhXRZsHNXBnfakGUUCluZpFvxbylIHWeSpiRfOEzdKQlCVrtAoanwjmRhwbNfJyOpaOfXodGdDAPnNncscfNquSsXtgaQfHHOvWgpPySoyuAluTGCmCfLsmcqthjlY"));
    this->aGkPJNGn(762596.2237167482, -1281278244, false);
    this->HKpjzkJDtCZFWU(-760095226, string("ZfLERWdEXZJolbuwIuOwMQnrBJrJEYJAytzJvOrVnhBMnqKrYFtjQYGkdczkzmKiYlUiYTJokuDbGer"), 26608.04694176315);
    this->QfpjNIQrQNAxLmK(true, string("LbwOKrvaynwPieVJPcITuLymWpPdrBZBxVlPNWZJJnNZjljDSDtIJQqiKLGvxVvZNTaUZqjBVozyDOrCFZZIEvdTOkeGmwzXBovzdxFqNKrHgzfhNXSdDrsIGmGdmSWqYfasXrhaWqNoGuhRpxorQZDNfCxJLAexEkPFDyTLbldAjkPIoLgREiLIjsQhpgRzPMdNdKpFZDzubuPTnPLDtFTYPxmYAPMGUafGPTkXJQkzpTZrWMpYDrKjrB"));
    this->NUCyUQL(-321492.0540443229, 1432793667, false, string("nWIXNjXqNeUcnlceWVFsFrUaeODSxMTELyapdbLJCOAgiqHFRQZfFuMRnqPabJayLaDTnTSUmxCZCciBcBtHbDXuXNNQSGopkbxMBDISipKYvCeWrDSFCSQkLAQoQhpn"));
    this->hyEkKOxSI(string("KYXtJyQQbQmgpRcxeapBZAHrDefXTNzighrWYxMRMsPnzAtHwMWaYOOrHrzLrXsgiRFOWXhLKqrUxayLqEuONizzJKXsnpHrYWlInzDDxGNVowYbgsxMFJCYcHDizunTfkkrGhgfdunFbBFbUCJoYlyvzCKkGyYbHLlYGTI"));
    this->iklLgxjyNFk(string("ZxUUYSeYcflyprMcqZrxDbHmWHQriZvHFpXSKXZDdizXQVHANeqaQiBCrrMAZvfxEXaDNWaPTiIBuupZhjDDiyxtPEiPVZLsbeemiwyVQodNqYBuMAlyyWGPrMSFnUqpdofUsyaLSPmcOIhJzEYjqfsTUXvtJzJOpmYMTOegMIdhEWFjebIOKSediJkTaLqnrBrRNfmdmkUfzDowq"), 718276071, -596733280);
    this->pCTSCtHOnJdYtGje(true, string("MkEvJTVCfNLFjIyURjJHTwnMrbHNEphgyfwTjgbjfIeGEYeRbPQgiMQxmSUaVKGEjchlmxhcUTayxwwYUUzpWDFygUhWAYTxUdrCJKTedgqnQ"), string("pqMwdsqPASXMLyHEreXryKSGhDeSLmkOdZwFKcspvMsjVIXdCaWdgNKYliahhlhtOhgNnYxLsFNXEtLCHrXSQRkRalZJJSmxGhUNmroOmFvynqUGgRKxppcdLkGmlJeVOrnijyqoDdEzxKvEGopDwMMYTneqmNAmN"));
    this->lhGmQvw(string("bnIfDivkFLochlBbnViJwfIfphuRhLezomhpsincuoKkEcyojKKThCwpknfcFYDkCIuBfMLriwhEHmjNKXeyJsYfuWDgrhgEwntiISQGFyicVLOaqSMGAsnkBeRgXKewyBahMzefTilhBsPZtgIbbXjKmjSWzUbVxxaaSfHZDkhoaaLoEkAIrehajLnMEBFzlNrbfaKoZNMjHcIpUWSPRWKHZzotzspeqE"), true);
    this->HDMqegvbYVZrbbkQ(false, -541721.7969386732, false, -531024901);
    this->CoHZm();
    this->lOFEArjdYNn(false, false, -1377361904, 328193709, -1395842187);
    this->tDQhpbfhhMdWLxBq(false, string("dedNqNqLsVTTEpVLcsTnbeBFFQkXfWSidSlYdihNedzvcaeQElydUJkwhTMuoUoEIEKKkOlfDtPLRekJEKkseGLiuuFYoiYnvkRRnVxHsnRpwNFETptqzxJVOYYWBfzanWtUCmOGvUuKKHhZsbllGHvUlRYfuhlHUKqEIjLPH"), 76791.07787469019);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bVbexlAxmiqPwx
{
public:
    double OTyUvQYhBbQ;

    bVbexlAxmiqPwx();
    double qcBSyUiJJw(bool upRdquLxy, string VNQuY, string VrPmIhS, bool RQwVJycamyvqdqI);
    void kxHXHq(double MALrgybwygx, double DFuoVrRIWZXCh, string zHnQfxlRaXQ, bool fpNvnys, string fmfcHSGeCSaOLPU);
    double zjfzytqBEnmzWQ(string XRHmjPxhz, int cxqpXouwtEheVwWX, string OzFdkihsWdyZYtJ, double CwilXmRfmpiZfauE, string hYFyYUJt);
    bool DYolDTmhksWa(string xJlBrfW, int OXJxUQQBWvvgho);
    int eFPYsnczQ(bool pdGqXeHyRMXl, int vGJpwP, double PofWKepSpgmEZeoD, bool iFrDJUqEn);
    bool lbnbJv(int lelyjbHU, string aFYhRrHnnschhqC, double QFxDZQNgKYTPN);
    bool quNMKq(bool fXwVGLUshb, double jyrZYcIvGmvM, string nwzczNAYgNQHZz);
protected:
    int iyxAZu;
    bool WrDQquvEOVNwHlb;
    double voHAPClYTjFP;

    int OLMFUXStmrwikLt(bool sVvwPzmApWdBK, double eZRBNzT, int snGwfkcla);
private:
    bool oiRiP;
    bool VCnAColOOMb;
    string RalqUNmOxQeLUc;
    double GgscSsN;
    int IgSLITLY;
    double purZJrlolLAtHriS;

};

double bVbexlAxmiqPwx::qcBSyUiJJw(bool upRdquLxy, string VNQuY, string VrPmIhS, bool RQwVJycamyvqdqI)
{
    double MigcKd = -761365.9402671072;
    double ITmkOHz = -610567.1625324474;
    string VVdVEPft = string("BwEiVJpBVlLuGvOLUwbOOOmFCbwlcWnrokLwnJRdQkApYNwBTLvnTTIzPBDcnmRVHMIHHdgwvfLZmGekPBFJTZjUEAVynldqbjEpDeFYPMDIthUxVkIyBE");
    string JoTHLYqBPWACkR = string("rTZJJDNGCcvoCUyEocPihHjzdTzwMGexCBxOFTPtVeMSKKJZmhzQqeVqvCGoJMTySfZXelDWXmxolyzDQAeCLLbszIiLfRosKNxgsOBJLyALfUfaao");
    bool bEMBkPTdhcdKZ = false;

    for (int lFMtXjWwXglcyLi = 1688654376; lFMtXjWwXglcyLi > 0; lFMtXjWwXglcyLi--) {
        bEMBkPTdhcdKZ = bEMBkPTdhcdKZ;
        ITmkOHz -= ITmkOHz;
        JoTHLYqBPWACkR = VNQuY;
    }

    for (int oHHbewfowNVBXZCn = 137026153; oHHbewfowNVBXZCn > 0; oHHbewfowNVBXZCn--) {
        ITmkOHz /= ITmkOHz;
        ITmkOHz = MigcKd;
    }

    for (int CsyTFpMApXGehX = 1906409870; CsyTFpMApXGehX > 0; CsyTFpMApXGehX--) {
        RQwVJycamyvqdqI = ! bEMBkPTdhcdKZ;
    }

    return ITmkOHz;
}

void bVbexlAxmiqPwx::kxHXHq(double MALrgybwygx, double DFuoVrRIWZXCh, string zHnQfxlRaXQ, bool fpNvnys, string fmfcHSGeCSaOLPU)
{
    bool rEuGyJfAnLCO = true;
    int tHeVjCoeHccKy = 1286347072;
    string XbKlz = string("LCQpfOSgGmuFFyUuAvyFuOVSoNzvznSynoeiqVykmQzkmmHbtcoSExiaZFdJpbglsIHIIgsyHGizvAIuqcngwUYTTxaqOAaFbSOgzxsiDoLeLCDPL");
    string zUEZaQ = string("gAnQAPzKCPHnXWwVRAFKmojjIStKvqXgkcACaeTytPveHGEgYucMllrBHidNmxjdfGozWYDKiinnBdreeqGvjAXQlzsELIbDBHKtKoomuvDOfnVExabQcPoroGIiOLnRwoqdEgjCtsmMJBVWintXDKbAbqhrDdKUxieQxMjPTpTuRsEVCDZehblWpsKYyjaLBaZrTCZVHaBi");
    string oeoDQGJDZoQ = string("gbitKJntBIXh");
    int HGzEJvXITj = 132834579;
    bool bmtMCUhuBKn = true;
    int POTiVcnmQvUhULcz = 1439029182;
    bool fcGLubusUt = true;
    string SOMszrrNheabkyDS = string("pIYmLsHiQbehhdgCPWTvpksPXYMwxBQxVbhTxXGFEGCVIKFiBhdldUOxanrGzNETzgIkVtsSvJTo");

    for (int ZSHnlinjRkgVb = 234527670; ZSHnlinjRkgVb > 0; ZSHnlinjRkgVb--) {
        fcGLubusUt = ! bmtMCUhuBKn;
        XbKlz = fmfcHSGeCSaOLPU;
        fpNvnys = ! rEuGyJfAnLCO;
        SOMszrrNheabkyDS += fmfcHSGeCSaOLPU;
    }

    for (int SqRSpZPQCvk = 792590706; SqRSpZPQCvk > 0; SqRSpZPQCvk--) {
        fmfcHSGeCSaOLPU += XbKlz;
    }
}

double bVbexlAxmiqPwx::zjfzytqBEnmzWQ(string XRHmjPxhz, int cxqpXouwtEheVwWX, string OzFdkihsWdyZYtJ, double CwilXmRfmpiZfauE, string hYFyYUJt)
{
    double KXfpzzEQgGDLf = 902995.4594183912;
    double NjIZUYAUEq = -464569.9984330178;
    string SCowPHsKQ = string("totPauSHlpAYXhSfmCKmRqjAXiccMrlFnwDzWaRIAHmQSPbtwsrybGnmJHvKoGsLALYgWYlOLYneuwstpBeUEJUjTQuDzvMfCUqBvoeKRcvdzmgsXzCuUrGbJXceraUXdZJLwJNWPCYxkRqUdhGVBdvLytxcHuNdyWOdOfbMpTuToAcxofEZRialCJeENjUakflOlDpZhtBtUssJuAzpuDOLH");
    bool egzwdpYvZo = true;
    int MIyfv = 239280604;
    string fcguPxZfVwJGpg = string("fXgiZdQOQHwrbBIqWWRqGbpQxSqbkhkHEIyfsoXHdmkgpFBciVdiImzcRRsRxZWrYsxjpHcWCRcMgFzuzVBOOaDVsoEIANvdnWkzpjgMvMvvhNorHRYPFRYajiTcro");
    int vrePMYwFJuLxYaX = -1692938876;

    for (int bQtezyklpWSq = 979731474; bQtezyklpWSq > 0; bQtezyklpWSq--) {
        vrePMYwFJuLxYaX = MIyfv;
        SCowPHsKQ += hYFyYUJt;
    }

    if (hYFyYUJt <= string("faFpxQDzeHsnNcKPtigGqTvnsnQOHWjHtrPsTAZNpAThNgkKgqvDszaOniYrPjNLiiFYwIoFPMkahvUTBrqFdeOazDZyjuWVszTaFBfuJvfucfsTIdSBYYLJkGDQAYJzcoMcAdzMgUWLuxDOfnsDNatiRCKpHmrImkfRWULQLg")) {
        for (int HPhuaMaxOYtIfhay = 815713996; HPhuaMaxOYtIfhay > 0; HPhuaMaxOYtIfhay--) {
            SCowPHsKQ = fcguPxZfVwJGpg;
            OzFdkihsWdyZYtJ = hYFyYUJt;
        }
    }

    return NjIZUYAUEq;
}

bool bVbexlAxmiqPwx::DYolDTmhksWa(string xJlBrfW, int OXJxUQQBWvvgho)
{
    string JPSTMRWvlZtYDv = string("cGChVzGYpYRSfbDAAsuJRmCesZUqiHjgxCwLFgyVNjWHVCVNbVRxaSOmpri");
    bool SBtQfCpMI = false;
    int YmxRTMmxJHHKh = -664360560;
    string clohyuZWa = string("FBBNFhjrDVoMXStNPBmXudvIdJPuVIGPNfRYiUoLuzHFoxLsceBvmYTpCPWFCkmxxTRjKTItZJgegqCQSAAutDaOLtOyQaQjhXswLUPhxnRgenccVlEbWBNeM");
    bool dKvfe = false;
    string gbFREuZv = string("SpqNIaiMWDRBnbDKlmexZaJymFxljwirQzsIeVRZswfkYXpRFDwTfqHwnrWAwLPldAiFEctPCihQoohwyqMssynZoshZgxNDWcXuPvElDCcSCsPwpWMDHqVPTxunLSYKULpcRrXpKTjrnyxpbPMA");
    int lrezfJeJd = -1713078301;
    int ljlwJlyM = -1290681588;
    bool UqiikhzzvSorrJyq = false;

    if (lrezfJeJd != -1713078301) {
        for (int SgGIdmeg = 805493040; SgGIdmeg > 0; SgGIdmeg--) {
            dKvfe = ! UqiikhzzvSorrJyq;
        }
    }

    for (int iBDQLtXVRVOLAQAi = 780900495; iBDQLtXVRVOLAQAi > 0; iBDQLtXVRVOLAQAi--) {
        OXJxUQQBWvvgho -= lrezfJeJd;
    }

    for (int nTwITXd = 1332990440; nTwITXd > 0; nTwITXd--) {
        YmxRTMmxJHHKh /= ljlwJlyM;
        OXJxUQQBWvvgho *= OXJxUQQBWvvgho;
    }

    return UqiikhzzvSorrJyq;
}

int bVbexlAxmiqPwx::eFPYsnczQ(bool pdGqXeHyRMXl, int vGJpwP, double PofWKepSpgmEZeoD, bool iFrDJUqEn)
{
    double YOJIZlP = -327556.65816941875;
    int aUPBzRmYvKr = -420328483;
    int LUqoyUuuLZmThy = 718102927;
    int vfIJFtH = 323369430;
    int hVRHXCfVI = -1661210010;
    double ayXmV = 226918.68263871825;
    int qRxjd = -1706929398;
    bool fqJlmAcHK = false;
    string mEvIzvBtSUSSjwD = string("ZVLRluMgvIrWfCGtrHHoHRtzxGKVwWhmkqfaFAgWLvWLOpXQyQLBQJnmOQWYKlblaiPciwrnfbZdoabIQvMXIjZYCREyDTqPGvNumdIpUlvTtEoYSVmlKavctMhBzVeGsjULTFzKreeBkSKqaRPUuonksYsESFLWPyasYcBjYztRVsEOPXuOXcJZmXeIsUMOthEZfyHtmnehaLbeLWuA");

    for (int gbeziwu = 1745427846; gbeziwu > 0; gbeziwu--) {
        qRxjd = qRxjd;
        aUPBzRmYvKr /= vfIJFtH;
    }

    return qRxjd;
}

bool bVbexlAxmiqPwx::lbnbJv(int lelyjbHU, string aFYhRrHnnschhqC, double QFxDZQNgKYTPN)
{
    double OczFFgVLvLei = 538698.5860890393;
    double YEVZg = 521208.1590016716;
    bool MxezjZV = false;
    bool rGxCvN = false;
    string pzFoIOqkECF = string("qSdoRTKXWjcGBkFXaimjXHcNemXMGWEwDqQZeOFdtNSZsmOHuEmDvBMmhgCFlIXrXvjecoZrPsQIGwCfgPEQqSDwNPFdDFMttYIgbZsrCfbXCFZcDsjbIkXyFhooEB");

    for (int XvhpONKXANhjqbJ = 1752956749; XvhpONKXANhjqbJ > 0; XvhpONKXANhjqbJ--) {
        lelyjbHU *= lelyjbHU;
    }

    return rGxCvN;
}

bool bVbexlAxmiqPwx::quNMKq(bool fXwVGLUshb, double jyrZYcIvGmvM, string nwzczNAYgNQHZz)
{
    double uVlLGACvyjGk = -1013217.8885852074;
    bool eWAbTvzZRNiBVRR = false;
    string tEBAYaZOkp = string("iXqzjhTcnWxRnRfkRoxfpKXDfAchxjCcRWLpzGDCSHEWUDghdqaFcroNHVJyBUKUOZQAeBncIMnnClQpjGectAqZhDyzTIhXrTBBOrncWkwoPcFOzIvbAtooGOiDCzfTewWutORgfmQqtxUnCqsWZCTIxdNGEnRMgTglziaBMpsHknGbrTz");
    bool ERvKFWBMqTgVCp = true;
    bool VqEUxuSBDknMdee = false;
    bool XZlcDHsU = false;
    int RaimOV = -653065167;

    for (int BxqbIksRlFkKC = 107658168; BxqbIksRlFkKC > 0; BxqbIksRlFkKC--) {
        nwzczNAYgNQHZz = nwzczNAYgNQHZz;
        VqEUxuSBDknMdee = eWAbTvzZRNiBVRR;
    }

    for (int cJeSBYtFzeZHIC = 1394263661; cJeSBYtFzeZHIC > 0; cJeSBYtFzeZHIC--) {
        eWAbTvzZRNiBVRR = eWAbTvzZRNiBVRR;
    }

    for (int ulXhavGzTZtosLpU = 1075627015; ulXhavGzTZtosLpU > 0; ulXhavGzTZtosLpU--) {
        jyrZYcIvGmvM /= jyrZYcIvGmvM;
        RaimOV += RaimOV;
    }

    return XZlcDHsU;
}

int bVbexlAxmiqPwx::OLMFUXStmrwikLt(bool sVvwPzmApWdBK, double eZRBNzT, int snGwfkcla)
{
    string ccMMQFpSf = string("ehGEYvYqzIsMPEoxtdlJdVEGbgfYtREThwTCkxaFeHOYzpfJlYATcPRqPDzqjRsEwDgddchkXsRiPkQsdLEyNpGlyzHvpEUPeqSlwbySmxMPiYhMziIKLDaBEhVzjVMcNAsXV");
    string QsZEnPN = string("WdiXsLWmLpmfDjJahjgjoWxgIaECAlOuUquQZehICkCNuvBifIISbDKQRRcATCMBuTvOvdKGZrIvtlTcdiEnNFhjLRYQZAgUQJYAvzUKqNbktppmOqOjTuOXPPfFqvWDffjcLfGeSMaULGbqCsTCGoOrVBu");
    int nWFbOJGGzMpKuWk = 2119921307;

    for (int jGmxKdrqqakuF = 1964261562; jGmxKdrqqakuF > 0; jGmxKdrqqakuF--) {
        continue;
    }

    return nWFbOJGGzMpKuWk;
}

bVbexlAxmiqPwx::bVbexlAxmiqPwx()
{
    this->qcBSyUiJJw(false, string("jEqLjRpTHpkcvAwzxKcDETdPAXMQuucOPKtLmEpyPYqMyhNuuwzengzFXERJeRWjIWuiebgwByHBfQkDjnpTnroZrWplATvGhBNEN"), string("sjauGWXawGZOjvCaXLcOkEo"), false);
    this->kxHXHq(-544327.0418940514, -506347.8435400268, string("liAWpWHtgjYEJwWlWYNAGMizFWPupgjdpNPYeFaBSZBpYWgkxaWgzBFJRcopSIWVThcdSluKFpZanHhTYIkDSmdBWRQGnBUVfLGwGaSWTGGLAiXLPuExHsOWshjTlIazYFREanorEyekbWhyzqAqkDFCBBjDmJHyUsmmxmjITfArMLyBMkcXTeQMwYdCCPNEGOMixYvSjwdwIEoJYiARasladLVmMgDfNZwKjfbcIK"), true, string("SkZAFtkBfITAxJoWzdrPBPaKyGHbrqmMjGQXaZgmmJNkjGQmGNVmFOsWTwXqUmQHxVfBaioWNMwbJLGNAoCtDrDaIcdXecZUuonkzjBiXoqyFaFXAZkDlzmcDXMrpXaYgUIUPFDThneUtVZEODWhqgZiHXXCRWhZSJPxkZaaAqlhbnpxZpWzO"));
    this->zjfzytqBEnmzWQ(string("uOMgHymBDNmGQBlSVsQgrQhzXrZRwdrGRnpSeAyFCBfFUAZdyXHtMhSU"), 1112303168, string("TOzLtCTHfttdfUVIAeuTZNYXsckxQqEfyhIyDFpXUHsbBzMpBahJnLqw"), -427218.95924370066, string("faFpxQDzeHsnNcKPtigGqTvnsnQOHWjHtrPsTAZNpAThNgkKgqvDszaOniYrPjNLiiFYwIoFPMkahvUTBrqFdeOazDZyjuWVszTaFBfuJvfucfsTIdSBYYLJkGDQAYJzcoMcAdzMgUWLuxDOfnsDNatiRCKpHmrImkfRWULQLg"));
    this->DYolDTmhksWa(string("JGWyNefYtxuocmuPcJtVWfQnbFFjDHwOgbHYCOQlzxnWpDFfpuUTiTQPDqtxhakcRVCt"), -676268437);
    this->eFPYsnczQ(false, -1275637045, -983611.8171977057, true);
    this->lbnbJv(-816092015, string("hcyQpKggKHYPeEpuNrAJzDvQSrXGtZvnKidsHhUshHzPhGkKBplUQTccENcKbtySdjMeXcgWsbKdbkazpmYJVjBzFkQFMPonlPoZOHoADHlzpLDZuBZHoTgqVivbINvCpgUDvhvTrErDrBntFbASDmJxCO"), 724036.2132575986);
    this->quNMKq(true, -952240.5848841695, string("PWtRagylLIsVaFezkjefIJmeugroUChentyWnqUlyTBYhrZKzmTXGJRbQDWlYwoSQewTNcnsYFUdXpasbhNsDsZsTORjVscxulpFYftgKzCrbdosKBKLYMMApdyqWcqHZTPxbUVmSMxwAlV"));
    this->OLMFUXStmrwikLt(false, -219596.22929181907, -1026390402);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hsDqAJlsY
{
public:
    string mMmlyweZsatxsIg;
    bool WQdLKKClg;
    bool ViDhkdZACAJnhTj;
    double ulRBWdr;
    string vQNWxNNJwZem;
    string vdlDqOnMsBdh;

    hsDqAJlsY();
    bool gsqBkOBWGauTP(int uHRoQvVmit, int ZLlZawAYogO, double nNcjvdZArp, bool VOIvWFs, string mLYLQea);
    int UDEYJynN(bool iXxXlL, double aakcqJyZarZXUmGw);
    double vYRjODGijMzEplS(bool oUvWIIpBSkt, string LNpcegMkyWEALTIQ, int TTZTjuRPYrfebgkQ);
    double CdaRIOQ(int KpKiiQQaaLPbC, double QVJwqGzq, double hzAgLxinWHByRLY);
    string QObzugF(double ZinTDzUwgFFWU, double VEpfjyNkThHxVxWb, string oNCVI);
    void tMvYKitSDWWh(int LUpaGHcOkQzKk, int xUlhABRnxQUVVdXm, string bOgolwMl, string wOojQdsAfSFXAKYz, int dMzgmwcyJiEawcAz);
protected:
    string suXXiiSDSyhywZeX;
    string AmdmQTHoWAfxQ;
    string iDLoLUblvsXW;
    int nlYzqjrWTpKxrA;
    double OZkKUvWS;
    int DdVyWQAAWuPHm;

    int qVHbkaoCaPSael(double rAGbYSVIKW, double diBIWtnPxMIVuYY, string AnfVxGgk);
    int VeMypKo(bool fgYCXU, int nzUFvyTufDhwpwO);
    bool LVWhHAg(string XqzIGnS, string iuQFbN);
    void wajMdmZBZSBbFMR(bool JhRMr, string yDWgQvwlaQqAWiOW, bool XtKuEfhUwm, string gMEVkcUxl);
    bool KKTHne(int xldgUfgLmVgkl);
    string rqATXqySZoCDuk(bool abcCwSxQje, double HJusFXv, string dVkWiBTOwOyTL, bool jlxAiQeLGnIaMo, double PVmnMb);
private:
    bool gIpVYuQ;
    string gagTerDMc;

    double apcOFUMRFvOnyNH(double BeRKviD, string sTtBrQlIznL, double bYdpnS, string NobVYNYGS, int cQkVoCLUqO);
};

bool hsDqAJlsY::gsqBkOBWGauTP(int uHRoQvVmit, int ZLlZawAYogO, double nNcjvdZArp, bool VOIvWFs, string mLYLQea)
{
    string XZQhFYeHsyIPnjG = string("NWPfEfrQWYEHQamsJXjyiiUjMaQsOiNktcyzkjgqcPACqNkyOCOlbElxlbFKYVElNRFwBWQNwRvoBOBfJNVPPJwGmlOOFlARuOIKAJIppMHEKtTUAPDmzrPVbRYvILzGEizUGNlCWrGTPrC");
    int bJSMd = -1809000898;
    double txRpgIqiFZYuV = 993175.7311014038;
    string uNwffD = string("gaZRhOKLKbAdPxAVFBINqNmzjQACafJghaPtataxBRpzIsKVYpXuWWrrQljLNpaVpHbnFgbRNFqnFWZdCXtKpqdxuUlDPNWJCJywGlUShlUEFVROuqKBszCrjpbNLyFgPsztVpKRUJXJPRmIMDlqmLKaSpcpmCIgElqGncNoItYDqJgWMbirJesdQUVCSoleJhpoAQLjbuSFXFWrkmDXkfwuukcTuZzqZiUqkoVKJYwEH");
    string sHbUJI = string("hJPArHVWbwewJjTODxMdkBgcACqTqGSMktdknCurjyqoEQXFIyYdeNMyQHxFaoaJHAMEdUXUMITFgNJDBYjICIOSqulnOruiOTiNCgxhoOquGlmrVtuoEszmFoKzJGtNrOUCMKyNosgUIgRRpeaVdXzmWLl");
    int SUkjDx = 1287271025;
    double bYMEqpUU = 333154.48249958;
    bool pFRnREMS = true;
    double aMjBOk = -766269.416617835;
    bool mjfdzE = true;

    for (int cGtoahuZFPmqhZrp = 1960161015; cGtoahuZFPmqhZrp > 0; cGtoahuZFPmqhZrp--) {
        mLYLQea += XZQhFYeHsyIPnjG;
    }

    for (int aOaTqtZvhU = 798599708; aOaTqtZvhU > 0; aOaTqtZvhU--) {
        mjfdzE = ! pFRnREMS;
    }

    for (int alLvpobRfJMxG = 26429335; alLvpobRfJMxG > 0; alLvpobRfJMxG--) {
        VOIvWFs = mjfdzE;
    }

    for (int jFRLX = 1320988382; jFRLX > 0; jFRLX--) {
        XZQhFYeHsyIPnjG += XZQhFYeHsyIPnjG;
        pFRnREMS = VOIvWFs;
        bJSMd /= bJSMd;
    }

    for (int NrXzmfz = 567656039; NrXzmfz > 0; NrXzmfz--) {
        continue;
    }

    for (int zMoPlDpRSdeys = 348371843; zMoPlDpRSdeys > 0; zMoPlDpRSdeys--) {
        continue;
    }

    return mjfdzE;
}

int hsDqAJlsY::UDEYJynN(bool iXxXlL, double aakcqJyZarZXUmGw)
{
    int XvrUEyNw = -1474870974;
    double JXhWbMJv = -924193.9358032289;
    int YcktAUeUhlOoc = 2113805209;

    for (int hWqTmmvWFzZHqs = 1774938309; hWqTmmvWFzZHqs > 0; hWqTmmvWFzZHqs--) {
        aakcqJyZarZXUmGw = aakcqJyZarZXUmGw;
        aakcqJyZarZXUmGw -= aakcqJyZarZXUmGw;
    }

    for (int nBjxSBaj = 2075431272; nBjxSBaj > 0; nBjxSBaj--) {
        JXhWbMJv *= JXhWbMJv;
        YcktAUeUhlOoc += XvrUEyNw;
    }

    return YcktAUeUhlOoc;
}

double hsDqAJlsY::vYRjODGijMzEplS(bool oUvWIIpBSkt, string LNpcegMkyWEALTIQ, int TTZTjuRPYrfebgkQ)
{
    double xVhEjss = -78294.61593529061;
    string ZLmQL = string("FxjuktOwpKejwqGzeWtyyhBbDeXSSQOczOBaWAXPorpvLXUmHdZgWSlZYHPjDKyJOjQXhzbLXAumRdcyBQpMkkpLPQMZsiYFsxOBGykFcfnbNouTKovqlSUtYHvVEqijVsTvZuTHHTP");
    int ymlPyxIlebnybdVf = -601207502;
    int IymgxXWDvK = -174525626;
    string nWKeMwteSLuQzH = string("jHiPaqzyHqrziamPznEHaVYrYQdVOvSlldmZvSxOwBTkTAnIgkjygFkOGosUvUWFKmbFFuwakiplSpFjgIeutBzugwOMFIUqIfRFFnHfOmjuByOlOJqDTsopUTgEVClGmTwUYvQTevVYWNWxBJClpyklNLxmiEhNUyZDxzPsHoIhNggDHtARqSUceHVoeAvsygZbXDrnFbdISuvUHXJwoDYYWBJjhKBalHv");

    for (int wiEtf = 1426260891; wiEtf > 0; wiEtf--) {
        continue;
    }

    for (int ZmIWoOayRsIftjt = 1983501942; ZmIWoOayRsIftjt > 0; ZmIWoOayRsIftjt--) {
        continue;
    }

    for (int kjcCTKbaRfWjeRg = 778489032; kjcCTKbaRfWjeRg > 0; kjcCTKbaRfWjeRg--) {
        oUvWIIpBSkt = ! oUvWIIpBSkt;
    }

    for (int hnjTCXAZHE = 1170571883; hnjTCXAZHE > 0; hnjTCXAZHE--) {
        nWKeMwteSLuQzH = LNpcegMkyWEALTIQ;
        ymlPyxIlebnybdVf = ymlPyxIlebnybdVf;
        TTZTjuRPYrfebgkQ /= TTZTjuRPYrfebgkQ;
    }

    return xVhEjss;
}

double hsDqAJlsY::CdaRIOQ(int KpKiiQQaaLPbC, double QVJwqGzq, double hzAgLxinWHByRLY)
{
    string wfMykVapBoOaI = string("gfanFtMLouuNeuOMjEEKyUhkWjEYbfRGRSuTOCMEeINHXxXlLxawYcczYinoxGAaNXgfjFgzWuoVaPLWpuZKCEYAbVybEmwQnbSUZsdjyXLZXGVqBRVQMZKkvbTYydlVUmYfTuGOXWslSoaSPYazwbaxYlQuayFJDgnrLxwmNWgETCCtdPNjJdkfrkDavFbKrAHRkRdTbYxNLFblOrGmueOaujzO");
    int rCpgItCRK = -399570532;
    string RfCeVi = string("FAArJGseukNRClKyrOeeBUKMchLNpCCedEYTwwIchQBzxmCkFOoRRlwIiRNsSdFdpimN");
    bool RQrVgNDBcPjoQdg = false;
    double ECmWYA = 359460.3322345898;

    for (int UgnyS = 1502799111; UgnyS > 0; UgnyS--) {
        wfMykVapBoOaI += RfCeVi;
    }

    if (KpKiiQQaaLPbC <= -399570532) {
        for (int xbcVKMzLLP = 321101782; xbcVKMzLLP > 0; xbcVKMzLLP--) {
            hzAgLxinWHByRLY -= hzAgLxinWHByRLY;
            RQrVgNDBcPjoQdg = RQrVgNDBcPjoQdg;
        }
    }

    for (int BiCBbOiWYMJwycW = 416667869; BiCBbOiWYMJwycW > 0; BiCBbOiWYMJwycW--) {
        QVJwqGzq = ECmWYA;
        KpKiiQQaaLPbC = rCpgItCRK;
    }

    return ECmWYA;
}

string hsDqAJlsY::QObzugF(double ZinTDzUwgFFWU, double VEpfjyNkThHxVxWb, string oNCVI)
{
    double QrxwaNtTu = -520263.0235577286;
    double jeybrijivb = 686674.1966301011;
    int FIhTYHM = 1438139326;

    for (int siuSz = 1477919275; siuSz > 0; siuSz--) {
        QrxwaNtTu *= ZinTDzUwgFFWU;
        ZinTDzUwgFFWU += VEpfjyNkThHxVxWb;
    }

    for (int GtEtLAldnTYKXSy = 872450104; GtEtLAldnTYKXSy > 0; GtEtLAldnTYKXSy--) {
        jeybrijivb -= VEpfjyNkThHxVxWb;
        jeybrijivb *= jeybrijivb;
        ZinTDzUwgFFWU *= ZinTDzUwgFFWU;
        ZinTDzUwgFFWU = ZinTDzUwgFFWU;
        jeybrijivb = ZinTDzUwgFFWU;
    }

    for (int mPezlSioSycN = 1455795409; mPezlSioSycN > 0; mPezlSioSycN--) {
        QrxwaNtTu *= jeybrijivb;
        jeybrijivb -= ZinTDzUwgFFWU;
    }

    return oNCVI;
}

void hsDqAJlsY::tMvYKitSDWWh(int LUpaGHcOkQzKk, int xUlhABRnxQUVVdXm, string bOgolwMl, string wOojQdsAfSFXAKYz, int dMzgmwcyJiEawcAz)
{
    bool NEtnWeZFZDDabAOK = true;
    string vWuyR = string("IroZWBnATyfkCfaKJMPQsCtFHQpBjrcIdSLaMJrpCtIfIGGjtqHJsnqLiyXPhfzhwGTtBxfJZSgiJwBzVelfnNchqCkCCZTpWxExzWhBCgrKWKWygqHMaGJVTGhaRfOgfpdEqvKuhePJwIlbwpTmpBdLHxkdeNCwPIaXcimbzCRD");
    int gPbDTJhtNWYOdd = 693441661;
    string bTeDtvfSM = string("NbFlV");
    bool tIfucPwcRzJZL = false;
    double ISzNJfMfhJmtTY = -2889.5695434164177;
    string dtfUNMLRU = string("cFjRhBCSXpdyFoivHRSEGmwJMpydlWIwOtAMrTrCMqDaKsXgsxmtHWbZIVjGDxmUbtguQvoCtDjNVVgdfEsrcenzkWcgWLfcaXkHFbteDfFvtkOSnrZTqU");
    string NbemjyLIOvtG = string("WcIerSuQdTdhtQmpyRcRT");
    double QwKxNxLzasFrlDGP = 582377.3715865755;

    for (int JjYnIFuFBpdpbE = 1656872648; JjYnIFuFBpdpbE > 0; JjYnIFuFBpdpbE--) {
        ISzNJfMfhJmtTY /= QwKxNxLzasFrlDGP;
        QwKxNxLzasFrlDGP /= QwKxNxLzasFrlDGP;
        gPbDTJhtNWYOdd *= gPbDTJhtNWYOdd;
    }

    if (bTeDtvfSM >= string("WYhBkpqlJbZJNsnkFnJNCSBkJodQVNwEunrOcpsGtjJxQpADfAMlDlaVNiCffaIRnKKjLEjfFIeaFHIbrelLxQdJvFBFrFxTLkXsMtzOkfhnegDzMp")) {
        for (int XCwfeMoEGHdtIq = 1714892687; XCwfeMoEGHdtIq > 0; XCwfeMoEGHdtIq--) {
            dtfUNMLRU += bTeDtvfSM;
            xUlhABRnxQUVVdXm /= LUpaGHcOkQzKk;
        }
    }

    for (int ozyahXhxrEioz = 1741091045; ozyahXhxrEioz > 0; ozyahXhxrEioz--) {
        bOgolwMl = bOgolwMl;
    }
}

int hsDqAJlsY::qVHbkaoCaPSael(double rAGbYSVIKW, double diBIWtnPxMIVuYY, string AnfVxGgk)
{
    int zeDirUvPhHIcDh = -1249939366;
    string fzwJFxwa = string("dXGJnVYVGFYJLpvgySalSuy");
    int IjjxDPpoEfWbgh = 1831771553;
    int tCbOtVEpRCjs = -1969686304;
    bool iNQLcFt = false;
    double RSVpFOGsqqAzyAD = -155228.0637988181;
    bool mFeWCaDEL = false;
    string rpVYujqwpmU = string("PnnDCpgMJVWqqrLSuDYbvvCcqjvsSCOnZ");
    bool vKQgKk = true;
    int GfoOMDrSVKnFpSSP = -553153442;

    for (int EEBmhAiKUbHk = 16459284; EEBmhAiKUbHk > 0; EEBmhAiKUbHk--) {
        continue;
    }

    if (GfoOMDrSVKnFpSSP > -1969686304) {
        for (int JZwMJCHy = 1399522583; JZwMJCHy > 0; JZwMJCHy--) {
            zeDirUvPhHIcDh += IjjxDPpoEfWbgh;
            rpVYujqwpmU = rpVYujqwpmU;
        }
    }

    for (int WPdJzn = 683388284; WPdJzn > 0; WPdJzn--) {
        IjjxDPpoEfWbgh /= tCbOtVEpRCjs;
        tCbOtVEpRCjs -= zeDirUvPhHIcDh;
        iNQLcFt = vKQgKk;
        iNQLcFt = iNQLcFt;
        AnfVxGgk += AnfVxGgk;
    }

    if (diBIWtnPxMIVuYY >= 989306.0800673104) {
        for (int dSLhEcMNgGLCFS = 1119575970; dSLhEcMNgGLCFS > 0; dSLhEcMNgGLCFS--) {
            continue;
        }
    }

    return GfoOMDrSVKnFpSSP;
}

int hsDqAJlsY::VeMypKo(bool fgYCXU, int nzUFvyTufDhwpwO)
{
    double pqfTEOw = -419780.35540965566;
    double SnplFCigDECnSHvA = -719245.5341162399;
    int nDzkraFnVHgUjmV = -1917387928;
    string OcHiO = string("HijxVKVDXheYmVDmJTtWzIIVaFuvElxcgWMpYroxDxDyTzerhMbxxucObJsQTmHaKJgZVhgEmrfTKSwoZgBdJeUyIxUmbDuIrYvNDIEDRvATcHyjAYLGHlYevcSfMvTndwVFAOTqIgSitGFCupnYdPSVCJvzDefcRGovsGGIjioCgJbwneFbe");
    bool vTshaxDOSIU = false;
    double pHFDrvXoFbI = -989830.4137616399;

    if (nzUFvyTufDhwpwO >= -608158626) {
        for (int SVcUhQbvxwDlL = 13031318; SVcUhQbvxwDlL > 0; SVcUhQbvxwDlL--) {
            nDzkraFnVHgUjmV -= nzUFvyTufDhwpwO;
            SnplFCigDECnSHvA /= pHFDrvXoFbI;
            nzUFvyTufDhwpwO += nDzkraFnVHgUjmV;
        }
    }

    if (nDzkraFnVHgUjmV > -608158626) {
        for (int nhkjrcDHG = 827845596; nhkjrcDHG > 0; nhkjrcDHG--) {
            pHFDrvXoFbI -= pHFDrvXoFbI;
        }
    }

    return nDzkraFnVHgUjmV;
}

bool hsDqAJlsY::LVWhHAg(string XqzIGnS, string iuQFbN)
{
    double tjiudmBlEZmmVZGD = -656731.4817825966;
    int vBbLddHpeE = -560423413;
    bool mbmtcJsQrDNzaK = true;

    for (int hilsoLNwqswyn = 356028403; hilsoLNwqswyn > 0; hilsoLNwqswyn--) {
        tjiudmBlEZmmVZGD -= tjiudmBlEZmmVZGD;
    }

    for (int LlrpmAlu = 1212645181; LlrpmAlu > 0; LlrpmAlu--) {
        iuQFbN = XqzIGnS;
        XqzIGnS += XqzIGnS;
    }

    if (mbmtcJsQrDNzaK == true) {
        for (int ovnCSOjGVXEX = 1445423349; ovnCSOjGVXEX > 0; ovnCSOjGVXEX--) {
            continue;
        }
    }

    return mbmtcJsQrDNzaK;
}

void hsDqAJlsY::wajMdmZBZSBbFMR(bool JhRMr, string yDWgQvwlaQqAWiOW, bool XtKuEfhUwm, string gMEVkcUxl)
{
    bool sbLQdfTRFDijAxB = true;
    string TSwYuMgsr = string("DWYonnABuvsqMGLJIWjuYSMawcYWPQuHqUkvfGlkbtvthawQNypBNKgSuoprAnaUHDYcxAYFpviWlYCbgKvmfYshvpNYummwOqCcTmBNDhqeQWCuDxAbvuHyEAtqvmeVyHwylQWDfEovNRSlHIgPKZIhRwfkYFLpMlPjDmhTVYBgeyyHVERtMykADyWeUUdoZTbzEZogMIiqCpHeXkGDvUikOBRgDAeOdzdSYCkkCHZlGELOWc");
    double CsIYdD = 305947.2742018321;
    double LlmZSMFQfriTt = 985414.9903260292;
    int NMfvWJjDEf = 830453600;
    int bAvqGsxtk = -1099632056;
    bool BHxHgpmXXKUId = true;
    double zMDokCG = -777196.566126847;
    bool NzYQCAYOxQ = true;

    for (int mikmcdlmbiYjrYGj = 991407819; mikmcdlmbiYjrYGj > 0; mikmcdlmbiYjrYGj--) {
        TSwYuMgsr += TSwYuMgsr;
        gMEVkcUxl += TSwYuMgsr;
    }

    if (NzYQCAYOxQ != true) {
        for (int MOzHRuU = 1049126127; MOzHRuU > 0; MOzHRuU--) {
            bAvqGsxtk -= NMfvWJjDEf;
            NzYQCAYOxQ = ! JhRMr;
            NzYQCAYOxQ = ! NzYQCAYOxQ;
            JhRMr = ! NzYQCAYOxQ;
        }
    }
}

bool hsDqAJlsY::KKTHne(int xldgUfgLmVgkl)
{
    string MXqCXLAvuqmxqz = string("qZuWIvlusXrhmFYkFmphRyWihnYGeijPtETcNQjaNfjdfNyVEHLHmIXhfzFNiEGqxehmJuPZKWuWqYPnFlLalmDikbYLRfCBxdwpWaBLJWSsiEbzejpobEmsNtXiPqHwdZUpKHAGyegwWSPbUGSRvXIrpqziVzYOdwNC");

    for (int IbyhIHlV = 1912268573; IbyhIHlV > 0; IbyhIHlV--) {
        xldgUfgLmVgkl *= xldgUfgLmVgkl;
    }

    for (int MkdJYdoVXFps = 241549678; MkdJYdoVXFps > 0; MkdJYdoVXFps--) {
        MXqCXLAvuqmxqz += MXqCXLAvuqmxqz;
        xldgUfgLmVgkl /= xldgUfgLmVgkl;
        MXqCXLAvuqmxqz = MXqCXLAvuqmxqz;
        xldgUfgLmVgkl = xldgUfgLmVgkl;
    }

    for (int aOceRhwyB = 582050016; aOceRhwyB > 0; aOceRhwyB--) {
        xldgUfgLmVgkl = xldgUfgLmVgkl;
        xldgUfgLmVgkl *= xldgUfgLmVgkl;
    }

    if (MXqCXLAvuqmxqz < string("qZuWIvlusXrhmFYkFmphRyWihnYGeijPtETcNQjaNfjdfNyVEHLHmIXhfzFNiEGqxehmJuPZKWuWqYPnFlLalmDikbYLRfCBxdwpWaBLJWSsiEbzejpobEmsNtXiPqHwdZUpKHAGyegwWSPbUGSRvXIrpqziVzYOdwNC")) {
        for (int RpkdtreUbxRRifv = 823456419; RpkdtreUbxRRifv > 0; RpkdtreUbxRRifv--) {
            MXqCXLAvuqmxqz += MXqCXLAvuqmxqz;
        }
    }

    if (MXqCXLAvuqmxqz < string("qZuWIvlusXrhmFYkFmphRyWihnYGeijPtETcNQjaNfjdfNyVEHLHmIXhfzFNiEGqxehmJuPZKWuWqYPnFlLalmDikbYLRfCBxdwpWaBLJWSsiEbzejpobEmsNtXiPqHwdZUpKHAGyegwWSPbUGSRvXIrpqziVzYOdwNC")) {
        for (int NybrWZ = 1527167964; NybrWZ > 0; NybrWZ--) {
            MXqCXLAvuqmxqz += MXqCXLAvuqmxqz;
            MXqCXLAvuqmxqz = MXqCXLAvuqmxqz;
            MXqCXLAvuqmxqz = MXqCXLAvuqmxqz;
            MXqCXLAvuqmxqz += MXqCXLAvuqmxqz;
            xldgUfgLmVgkl *= xldgUfgLmVgkl;
            MXqCXLAvuqmxqz = MXqCXLAvuqmxqz;
        }
    }

    return true;
}

string hsDqAJlsY::rqATXqySZoCDuk(bool abcCwSxQje, double HJusFXv, string dVkWiBTOwOyTL, bool jlxAiQeLGnIaMo, double PVmnMb)
{
    bool oPCLqpGkuNmF = false;
    double kppMoLhJ = 942333.2128672051;
    double wdEiR = 838977.3929211335;
    int UmHKwhIu = -1869676781;
    string jgihVmqjwXWKaynm = string("rXYVpbqlVSCdJmMJTQLKdGsxbsTgFJETTOZfLUMNHuyUoYeHIWwpKAZpHnDbZoqCXYfXcmJz");
    string WZyPlzG = string("JPSxfxDhGMGBQMbnDEoEhlkxWhLlFzteGVtkMoGkrDrrbrqTaHDSPccITapxCqytwJpQzNqboxKKTmWkjLCHHBdZEynHEIuJYAOzWsQNuViCMqhHjAIlwlsWMQxodAuboQFCTezInewlopMpFysuXpAcRyrHaEJbT");
    bool qcXuxYrcpsjSGreA = true;

    if (HJusFXv < 942333.2128672051) {
        for (int aOCjmhYwnJK = 740652904; aOCjmhYwnJK > 0; aOCjmhYwnJK--) {
            wdEiR -= HJusFXv;
            qcXuxYrcpsjSGreA = oPCLqpGkuNmF;
        }
    }

    for (int TyKzYGVRSJJ = 1120257120; TyKzYGVRSJJ > 0; TyKzYGVRSJJ--) {
        continue;
    }

    return WZyPlzG;
}

double hsDqAJlsY::apcOFUMRFvOnyNH(double BeRKviD, string sTtBrQlIznL, double bYdpnS, string NobVYNYGS, int cQkVoCLUqO)
{
    double konYltvXUuybPNQN = 355844.2057161055;
    double GuEci = 560429.48255086;
    double xQBWmtbLLkIuQh = -967952.8984688874;
    double eIFGQKdmApSbjZeb = -392963.8652591247;
    double gqTXTsJ = 168846.66730217927;
    string YptpDUODza = string("svLxiIwoBSqWfELDiYmceIlBZOOByhykrQklJyBkCYrJbEbvnXKOijoIDivmqtGtQmzTHUnFQJLgQrLkcrvYcNAlELPOJbUBhIVhztcONACxosN");
    string amxltlHv = string("ZawKuRDpRQeDqsfnYGmqzQqHjvvqfAMwXTEzQMWfgJBmERDhu");
    string hUBLjinKfpVsL = string("RfsWLwiksGvCkmItZrFMlXTTblbKkLDrDMbpreciCwuCaiIQoWSFCSEkRCurOiMpAXNNxOFosjUnpKvwFlekLJNzJGuqBRyKOorEKZExxEonkTPpVACBpeftJqTychPLRUwPSoFoGesACmSThKumLRYxgpZCvJGrxzIgNmaYmRbxUMncrzDOYlIKOjvSiRVxjmFOKsKcDXnhYOhmKejLTFIBmLYBswyQeLkwNeYHALhtTeqiJQrMbZLmcwrdYeR");

    return gqTXTsJ;
}

hsDqAJlsY::hsDqAJlsY()
{
    this->gsqBkOBWGauTP(-1161232641, 1379121696, 896192.4733914878, false, string("GYNOUFYwxATlqdNOZLNsfytpqWFQOFXTqAaTXpYgBRkhiAyUuTjzCoHsDOmENhUVyEIQD"));
    this->UDEYJynN(false, -55068.88971183522);
    this->vYRjODGijMzEplS(false, string("MRfMtqJSBArGEbmKZWKSWPiJdIEAgnsFgPxqWHtWVFdtjRfJwRajRBlDCvedPbKOcwCZkijXnPxjIPGyNavpRtpNs"), -787408495);
    this->CdaRIOQ(-1328193290, 686211.9566164875, -972931.5721942339);
    this->QObzugF(10003.571880850684, 697171.8829368618, string("KoTRMevRJJSjufdtuxVcPSJLDRvPVvLYLZPqZAXLtbURqdJffdtSkLGCCaDIPyHysqTZIzPyDeAWylKVYycrdStqDavknzIugBxNSnpYgOeafVqmldDpIDXvguBRlOdvjshpdFCrqUwcCWauBaxqqWyqnuH"));
    this->tMvYKitSDWWh(162717771, 1658979740, string("WYhBkpqlJbZJNsnkFnJNCSBkJodQVNwEunrOcpsGtjJxQpADfAMlDlaVNiCffaIRnKKjLEjfFIeaFHIbrelLxQdJvFBFrFxTLkXsMtzOkfhnegDzMp"), string("ONisyXMytlKNnjICPauPxvOXkNzSfidxOOZkWoocNWodFjyREjaXudEiTciOPbEhemCmsSnzfDiENjSGoFHanllynWCWgmIQwjPAeDiEOZtSjiwHBZsdCTMatiSipRisenbhPYCmutOdKGqEMxALDHrSsAYvSWjlPALnjezbeRCpVLIwlRyOuoDCPwULZbEXIXhGbIxoCBXmYUxbsEprtPeqhohQzUhxYKFtUbVhiGWpoXZCGyVKSKHHemZCWJg"), 208188504);
    this->qVHbkaoCaPSael(989306.0800673104, 414337.9510665526, string("DCOdiGHcdKXUbpYvDxoSNcJuHogJNNeAAwzNcrPYAjnXpUnhDMZEFY"));
    this->VeMypKo(true, -608158626);
    this->LVWhHAg(string("UJyIHbSeHlydaBKpJJCOVjCCYVLgKfZTmbXAfWVHLEJpBvChHkGxSPzgCJHapSujlFlgIdRaqXACpLDxXTcDeFrGkAjyXUhWfWZPdHwdelbgKRYmQINAWwcjfbaVe"), string("qqldGQRTfkPSXWhMxHaxTgpTSvgLMYzUNFxdLkWmwSgRVhLZRDsZFikAHhEsNdZSUrkHaAGioaYOZPfCWkCtzq"));
    this->wajMdmZBZSBbFMR(false, string("BzUQHnMMmnPzTZbkOLtpnHqGmEWKQvAYxTRzGWjRdjkqCoWXueokcGVIPVutZxJbfKTZXKrSIHBhDlcsIATXQvPdQtUPpnPSazriraiTocMLPOk"), true, string("mpcMcWFsreDIoBOVpXydlOBjSYyVdryDEkpDOefRxPvADAAQMXoJOgPsnGerVXyGFrhPUjAFHviBlkdQioNtpyZOZFngLHRGWydDhfGkQIaZRSoFXqIKYTlQzhyEARRnULZzptpvavCNCaRbemwhriqmPIoazjbbXOAPRwgZVQcrPpYjUNEeWjRsuEn"));
    this->KKTHne(1082650438);
    this->rqATXqySZoCDuk(false, -6266.547143906431, string("eroEmIJdbWqaxiANKsazqGfRvPFLcEHMdQOdcpecsDpjPZGuTYgZWpEtkzttqKE"), true, -570569.307626831);
    this->apcOFUMRFvOnyNH(-706446.7550725777, string("AmocwGzmBWNWxRIjTmuribmyZWUaNMaxhfedpCNgJmRbGIugIcMko"), -463516.173995056, string("fAOlPYRyGTgfxsvnKhjzZCzxnJYNRtBaEoGwhWjHEjsqdmhrNuHnagSziaBESlBBruApvgJaTkIxhoMaCGnkTKghnnVGwsWzGIVoVSHZgfdUwMISRfrUZmhaqhWTXDTBrjHeSerbXKRFENsQLNokuQGfiMjFXHwpjYfFQEmCruQboxPoIcsUPRqqTVXWHogNzCIsoapeDomKVaFugdOdURLfyCkOycUuwqmoXppoTvvAVfz"), 2055365507);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zgOaaFzvgCwNwVfs
{
public:
    int arKgtiAzrRBnPUh;
    bool zkNWwsMAzCni;
    int OvYmbrzkqmMbeYl;
    string Ljtosh;
    double pWQbIuIZcDbkulv;
    double OTCoJXbbaywKlMTl;

    zgOaaFzvgCwNwVfs();
    int mxcapjxTYfy(double dixMst, string LdRbgIIK, int GioMGTRPH, int GuaMxBbeuPFiIwy);
    int fkuvwfvMfLT();
    int SoAEdzwzGk();
    void mlgGpuHqoIM(bool MavoD, int NVOYDGvtEJFWjDa);
protected:
    string FmMTHCj;
    bool sOTbtaxfOY;

    bool oxWQECv(string cDyZJsFMZsJfnqF, double fgktrDTgMgeU);
    double kdfrxguHWHSiFuR(double GuYGvsEVc, string ydXAySa, double nunAJA, string nNWhBktOGDOQSCN, bool MBGVDR);
private:
    bool vdUOWrPsItIhLeG;
    bool DEEyizvryNfGka;
    string qorrJ;
    string pMCgJOwWyjIum;
    double ZWxsNKFCfopbct;
    double YmCPSbxJn;

};

int zgOaaFzvgCwNwVfs::mxcapjxTYfy(double dixMst, string LdRbgIIK, int GioMGTRPH, int GuaMxBbeuPFiIwy)
{
    string GAGQtubJpQ = string("xzNbPUfoloHOUTvJTlXzMTvyGzQfxL");
    string BnyRNdBiiiscsMwb = string("lNGPKgNSNsvyuuDbRsMVAYsXZhdVeSGDLaUtbryxMGAPXmIwZyoSpKExpXUtwBAKqOeplUGHMJuSibbXEMaOujQcdeppVFalpaadRnAzQrnNiWjOIIwjNKsWymaoydzwoCaPrEjNgEPmvtuewxazRphsgxxwPIJpMEvnkarYuvVsghIFCRHPSiOWd");

    for (int xCzTXSyqlgHeWM = 1619751298; xCzTXSyqlgHeWM > 0; xCzTXSyqlgHeWM--) {
        LdRbgIIK += GAGQtubJpQ;
    }

    if (LdRbgIIK < string("LhmVrXiGZMbiHleYBBYGZmHuFZoXbHLgjnzANnisfwNCNxAIqHzw")) {
        for (int lWsVTfIKDg = 147817; lWsVTfIKDg > 0; lWsVTfIKDg--) {
            continue;
        }
    }

    for (int nTiGcsIPaHaHUgT = 845107243; nTiGcsIPaHaHUgT > 0; nTiGcsIPaHaHUgT--) {
        GAGQtubJpQ = GAGQtubJpQ;
        LdRbgIIK = GAGQtubJpQ;
        LdRbgIIK += LdRbgIIK;
        LdRbgIIK = BnyRNdBiiiscsMwb;
    }

    return GuaMxBbeuPFiIwy;
}

int zgOaaFzvgCwNwVfs::fkuvwfvMfLT()
{
    bool ndqFwuBvM = true;

    if (ndqFwuBvM != true) {
        for (int ClHBwagWehOY = 797464747; ClHBwagWehOY > 0; ClHBwagWehOY--) {
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ndqFwuBvM;
            ndqFwuBvM = ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ndqFwuBvM;
        }
    }

    if (ndqFwuBvM != true) {
        for (int kCRHuVDbrALtRJFi = 153739676; kCRHuVDbrALtRJFi > 0; kCRHuVDbrALtRJFi--) {
            ndqFwuBvM = ndqFwuBvM;
            ndqFwuBvM = ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ndqFwuBvM;
        }
    }

    if (ndqFwuBvM == true) {
        for (int PqKWhSPnFJFtxIZh = 483406715; PqKWhSPnFJFtxIZh > 0; PqKWhSPnFJFtxIZh--) {
            ndqFwuBvM = ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ! ndqFwuBvM;
        }
    }

    if (ndqFwuBvM != true) {
        for (int efkSTab = 956800891; efkSTab > 0; efkSTab--) {
            ndqFwuBvM = ! ndqFwuBvM;
            ndqFwuBvM = ndqFwuBvM;
        }
    }

    return 1793643510;
}

int zgOaaFzvgCwNwVfs::SoAEdzwzGk()
{
    string eeuqppP = string("eyKIbIlOhAqOUTyneKgNUFVCCbPFeEQLFEojFsqAFgfkngGjZukffiuYfLVrszwFpvTUBEoCidRINJkDOoIVfElSRuQtGiXtPcJJxtZdnvaDMJcUYrvizSIoXPonuBPWiJKTLbVVUjTSwolGXwFycDyF");

    if (eeuqppP < string("eyKIbIlOhAqOUTyneKgNUFVCCbPFeEQLFEojFsqAFgfkngGjZukffiuYfLVrszwFpvTUBEoCidRINJkDOoIVfElSRuQtGiXtPcJJxtZdnvaDMJcUYrvizSIoXPonuBPWiJKTLbVVUjTSwolGXwFycDyF")) {
        for (int alUVyf = 296202555; alUVyf > 0; alUVyf--) {
            eeuqppP += eeuqppP;
            eeuqppP += eeuqppP;
            eeuqppP = eeuqppP;
            eeuqppP += eeuqppP;
            eeuqppP += eeuqppP;
            eeuqppP = eeuqppP;
        }
    }

    return 740033765;
}

void zgOaaFzvgCwNwVfs::mlgGpuHqoIM(bool MavoD, int NVOYDGvtEJFWjDa)
{
    double polgl = -654659.0348333914;
    int dLyOkn = 397196048;
    bool YCfgDbsVReESTC = false;

    for (int KFyjzqutVX = 541894875; KFyjzqutVX > 0; KFyjzqutVX--) {
        continue;
    }
}

bool zgOaaFzvgCwNwVfs::oxWQECv(string cDyZJsFMZsJfnqF, double fgktrDTgMgeU)
{
    string GftghfcClotAw = string("rrXHeCpkhOEFDEgFMyivwRlpYcQGUVcShGycYQMnklzoxzCNeZUouwbOdVnjtNDsFIHrKBVBQkWXLlWvgJuxhNoGgkgSflFKHuBBxDFDYYZXFIOZdqQgxySFKtVpnW");
    int kJfZZIylBeB = -1276713151;
    double URICfmTxPZ = -149593.21195119945;
    int hIJJb = 261927816;
    double iFymegL = 400678.6458453468;
    double dKlEfKNmbelcO = -83465.63834856809;
    int kxTwDs = -967214965;
    bool pWzyEVRsxZKbZ = false;
    double CsGkuoxAUC = -538902.3493423469;
    string vDBgd = string("SetKSJmwNtpmgEltBSyfXRDoxGmbuLGgVskKLphoFqqtpYgmRvcRlqShBrQFvrToakjAVnPUjIbsrQAGFeJLAMLycp");

    if (cDyZJsFMZsJfnqF != string("SetKSJmwNtpmgEltBSyfXRDoxGmbuLGgVskKLphoFqqtpYgmRvcRlqShBrQFvrToakjAVnPUjIbsrQAGFeJLAMLycp")) {
        for (int JTZjiE = 825650693; JTZjiE > 0; JTZjiE--) {
            continue;
        }
    }

    if (hIJJb < -967214965) {
        for (int ugzYbKJqilho = 1159499515; ugzYbKJqilho > 0; ugzYbKJqilho--) {
            vDBgd += vDBgd;
        }
    }

    return pWzyEVRsxZKbZ;
}

double zgOaaFzvgCwNwVfs::kdfrxguHWHSiFuR(double GuYGvsEVc, string ydXAySa, double nunAJA, string nNWhBktOGDOQSCN, bool MBGVDR)
{
    bool XyjiwRlhghrlJEW = false;

    for (int NvLiPFL = 1201686932; NvLiPFL > 0; NvLiPFL--) {
        MBGVDR = MBGVDR;
        MBGVDR = ! XyjiwRlhghrlJEW;
        GuYGvsEVc /= nunAJA;
    }

    for (int IBhJMsaSwKwXZ = 1849071139; IBhJMsaSwKwXZ > 0; IBhJMsaSwKwXZ--) {
        MBGVDR = XyjiwRlhghrlJEW;
    }

    for (int UTlxwgKGqNVlgE = 956493688; UTlxwgKGqNVlgE > 0; UTlxwgKGqNVlgE--) {
        XyjiwRlhghrlJEW = ! MBGVDR;
        nNWhBktOGDOQSCN += nNWhBktOGDOQSCN;
    }

    if (nNWhBktOGDOQSCN != string("cOPFZKbfEoWZfDaLvwUPSNORaWNzSYWrQXXPwEmzvCqtMpwyvGLhgiyadVKJvACrQKZhtlpPfAXQSGJTOGPQsgMGNziFW")) {
        for (int aCUWNZC = 2012739375; aCUWNZC > 0; aCUWNZC--) {
            XyjiwRlhghrlJEW = ! XyjiwRlhghrlJEW;
            MBGVDR = XyjiwRlhghrlJEW;
        }
    }

    for (int SLGGkgaRsPOBphmQ = 431948934; SLGGkgaRsPOBphmQ > 0; SLGGkgaRsPOBphmQ--) {
        continue;
    }

    for (int XcdQNPSNvBEoOTD = 1230511077; XcdQNPSNvBEoOTD > 0; XcdQNPSNvBEoOTD--) {
        XyjiwRlhghrlJEW = ! XyjiwRlhghrlJEW;
    }

    return nunAJA;
}

zgOaaFzvgCwNwVfs::zgOaaFzvgCwNwVfs()
{
    this->mxcapjxTYfy(-455559.2552552018, string("LhmVrXiGZMbiHleYBBYGZmHuFZoXbHLgjnzANnisfwNCNxAIqHzw"), -319728816, 863716411);
    this->fkuvwfvMfLT();
    this->SoAEdzwzGk();
    this->mlgGpuHqoIM(false, -186252429);
    this->oxWQECv(string("pBuizfnDJMUnySZSPIPBuNlcUGALOTYKrfutYLxbopepwAshjEOqlkZtXrbYvWPpxjFRVvHcUnbSmtQkQVGYPSBhonIyCoQJmYrtuidRaGVzLyBsGHnuWWDEhJfPskrhTxCmhJdLFYdyzxmejvcWqyDXgdttvHLuJpjFSBtPQOcrbtQDiumIvBndKgIPDERi"), 304263.5887174006);
    this->kdfrxguHWHSiFuR(-784378.9862789086, string("cOPFZKbfEoWZfDaLvwUPSNORaWNzSYWrQXXPwEmzvCqtMpwyvGLhgiyadVKJvACrQKZhtlpPfAXQSGJTOGPQsgMGNziFW"), 245359.09518354863, string("KMEYajVJacdPehHaMtnEhtBQltZwpSRqKzppcrGYuJioLuFAyKzQhXAPgtHCShjUVXGPbzPeAxZUXWapRgbqVLEmSnBsSK"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QdorJPJpKLugU
{
public:
    int hHBumkrtQcMcZHw;
    int azVCPkB;
    double iSrKoaGDOH;
    double QhYsWYmh;
    int TxSOSRpD;

    QdorJPJpKLugU();
    void vkFAAwgKbHGCJ(string JBcGgVmVEwFgKU, int onpQtvsHuDGp);
    int bLTLeqarFfhY(string wtuVvpPXOwpZa, string XChcHKdpGklfcZj, string YTwzCYWutUjd, bool oHXQlodKmlWuKje, int ifPaZhy);
    string yxIzmKeYTTLdZpHg(bool LwkATUhBGPMRT, string nkbMocNzfoae, string pcdAyqJMvTczU, double GQCQKmR, bool nPifHt);
protected:
    int HGIckWYZYCRb;
    bool FoebdU;
    string NdXdIwlWfjN;
    bool ljBaXkvGDCmMgE;
    int xrTEjIlJSzzxVQot;

private:
    string NLJannAwmIDVI;
    bool lLxSKANhoVcoLAC;
    string hUalQyNfjSpW;
    double FVptfebW;

    string ztaWUDnXqOH(string iOfic, int uwrHVytpwnRzJ, double wVIMNvPFuILHSePI, double xEvvNZSxgvMDe);
};

void QdorJPJpKLugU::vkFAAwgKbHGCJ(string JBcGgVmVEwFgKU, int onpQtvsHuDGp)
{
    int vZRwyxTdUsOWwkf = 954297769;
    int NHYpYOjxgDRYMDvZ = -1247621646;
    bool fOOfE = false;
    string amErhXoALBLcp = string("YRkOwrNHdZaKsfokARgrJdhWAonBeZVRvYnCKlZmXVJRwsovmmdVUTbvnVOlPSOSsBWbvJBLCSQGHuojHe");
    string uclIH = string("zktqPrgvpqFqWEYxrogtOOhemuBBEqgzOicwTjkeykkFNEYisDVlzjNNlDSNNoauzEjakIHuZpMdlCFjuEzjrXAvLlNSsWGqYfIsgsdrVEvbUFrpEAZoOPWqHXIJnyThIwgXLZiOIEJvOJZyrPpDjvNhifSToyuZZnJWtnZBrBNCoVskyhQGkaHkDBImQtYsDQICQRGDodBIMtlqDRoowLtqnOxftSomAKtphYPsDiWNMmyHsqzcIpx");

    for (int lLfvqIG = 1974996146; lLfvqIG > 0; lLfvqIG--) {
        onpQtvsHuDGp = NHYpYOjxgDRYMDvZ;
        NHYpYOjxgDRYMDvZ *= NHYpYOjxgDRYMDvZ;
    }

    for (int igCudGK = 30050007; igCudGK > 0; igCudGK--) {
        onpQtvsHuDGp /= NHYpYOjxgDRYMDvZ;
    }

    for (int XnNCNxkd = 1027972449; XnNCNxkd > 0; XnNCNxkd--) {
        amErhXoALBLcp = uclIH;
        JBcGgVmVEwFgKU += amErhXoALBLcp;
        JBcGgVmVEwFgKU += amErhXoALBLcp;
    }
}

int QdorJPJpKLugU::bLTLeqarFfhY(string wtuVvpPXOwpZa, string XChcHKdpGklfcZj, string YTwzCYWutUjd, bool oHXQlodKmlWuKje, int ifPaZhy)
{
    string vHiPLtp = string("oSUsatzOMVFbYpgdiQLseQbdJCixhrVvrREOrZlvLRdxWwPypWU");
    bool MLJcJZuL = false;
    int AXRfQdQxWYQkc = -904360829;
    string gwUbZAPlo = string("UnULQWPrQvkxkebEewGLrkPDQdSFlAqPQvORRiEPdJnyzeiJrkjQnAfWSqRAzWRPEAjUpCtPnfImSpMYsbsicJdLlChPohackJmEPaZMDoelWknvJGOxBjxVrLoBysIfdnSPNIbYYztIUkFVtyTfOOiuuIlrirBSrDLFxdmiu");
    double puiQDnkWGjiV = 621808.1685015662;
    double YSipfkDraFMWUQ = -726406.9061264738;
    double TXxiE = 1046393.4054598784;
    bool sLHdD = true;
    bool Jcmpyu = false;
    double NAHKKz = -321796.12934079464;

    for (int zPEZpS = 635429295; zPEZpS > 0; zPEZpS--) {
        NAHKKz /= NAHKKz;
    }

    if (NAHKKz >= 621808.1685015662) {
        for (int dbJTFMTQjNsaRYH = 172986322; dbJTFMTQjNsaRYH > 0; dbJTFMTQjNsaRYH--) {
            YSipfkDraFMWUQ *= puiQDnkWGjiV;
        }
    }

    if (wtuVvpPXOwpZa >= string("jTYnvrQdxNHicPVNeZvGWknyxtnJerToIBZhrQcsjvVWMGpFbUEHOWELzaBZEFGZHjycDZxqzoFPIEafWwBjVxBnYQqEpyktgNWWVeJjNFKJwcBOiqbPjMrBCiAtwGSqdhTpIgFazSDFMWujwbIcRDGXFzqSKiIUCzlRFxRLeacFaySwEEaWXbKzqgVp")) {
        for (int HHiJLE = 1107700529; HHiJLE > 0; HHiJLE--) {
            Jcmpyu = ! sLHdD;
            Jcmpyu = oHXQlodKmlWuKje;
        }
    }

    for (int ikssuKk = 1337643999; ikssuKk > 0; ikssuKk--) {
        Jcmpyu = ! MLJcJZuL;
        XChcHKdpGklfcZj += wtuVvpPXOwpZa;
    }

    if (AXRfQdQxWYQkc > -559719174) {
        for (int IiOlUoeH = 138022174; IiOlUoeH > 0; IiOlUoeH--) {
            continue;
        }
    }

    return AXRfQdQxWYQkc;
}

string QdorJPJpKLugU::yxIzmKeYTTLdZpHg(bool LwkATUhBGPMRT, string nkbMocNzfoae, string pcdAyqJMvTczU, double GQCQKmR, bool nPifHt)
{
    double uaIWQaGM = 644790.1136196012;
    int AQvnwhducLrYdQsr = 1300352753;
    double uJcOFYg = -253625.81058689198;
    string uUofVwzeYofPFi = string("RtwJYyOuv");
    double XWNegqniBvLMTFZU = 113637.73312381869;
    bool WWCIBnnQXe = false;
    string YWYybrAXoaaOuOA = string("GcWVXmCogOteKgZ");
    string eMmzYvSdGf = string("YZmeDogkocMDShAlphAdSqZUddaAbosUFepyenqMQQMPINTvCxEpyEQnQouLlcGjDv");
    int NJTDhKlnmQUO = -1134182830;

    for (int tloMSImWBrH = 368685207; tloMSImWBrH > 0; tloMSImWBrH--) {
        NJTDhKlnmQUO *= NJTDhKlnmQUO;
    }

    for (int sfVdh = 1796064063; sfVdh > 0; sfVdh--) {
        uJcOFYg = uaIWQaGM;
        uUofVwzeYofPFi += nkbMocNzfoae;
        GQCQKmR += GQCQKmR;
        eMmzYvSdGf = nkbMocNzfoae;
    }

    return eMmzYvSdGf;
}

string QdorJPJpKLugU::ztaWUDnXqOH(string iOfic, int uwrHVytpwnRzJ, double wVIMNvPFuILHSePI, double xEvvNZSxgvMDe)
{
    bool akriR = false;
    string JQBXYI = string("nchzRRMcDYocPSdgNpxxHTmsiUlvyXKesEsYDHKdeeXbqcCmTUoLRvLUfLOikXeACiXlBqGZpLSd");
    double VBLuNRARi = -517112.34329430776;
    double URUIOl = 436291.9467627737;
    string yqedtH = string("cIaOtzQdhlZm");
    string kvtXDWKj = string("XcTHLhfPbADIqhaTWMIitZvZseDpjHurpOigpJwIAaOgdBnAVTvEjZMNHMGWBVGBJyXaPXoTLgdTJJAAUwupdSxSoIqbyiqEJJDYXUlTYPyhUkjvbvFUSJbLWLmgNRfIuGMSEcNeztiPltJxyYozcEaIUgvseEJiYTdSrZavhhHnjAjlhaZQLSaBdeALXkxAWuiufPhMhyGdOauESmVtdMFYe");
    double OOJZsVsDAIK = -755841.2978000359;
    string QEbazSa = string("FSOLfcEBFAjOueLiheRxDMbimORgVGWa");
    bool rRSQhXWnU = true;
    string rRZsHmcYiuCHuHIu = string("fWUXcGBYAYCHMcHIjtWqWRajOUmfFuRiQWeJvqfrDgamgSlaedfHXlcCvqGCsrMvybocgksXcZkikNukpipmKUVpzIczNVrNtrmvp");

    for (int fIZyHkMKmrXjoePT = 481405125; fIZyHkMKmrXjoePT > 0; fIZyHkMKmrXjoePT--) {
        continue;
    }

    if (rRZsHmcYiuCHuHIu > string("XcTHLhfPbADIqhaTWMIitZvZseDpjHurpOigpJwIAaOgdBnAVTvEjZMNHMGWBVGBJyXaPXoTLgdTJJAAUwupdSxSoIqbyiqEJJDYXUlTYPyhUkjvbvFUSJbLWLmgNRfIuGMSEcNeztiPltJxyYozcEaIUgvseEJiYTdSrZavhhHnjAjlhaZQLSaBdeALXkxAWuiufPhMhyGdOauESmVtdMFYe")) {
        for (int wfezABfBUakjzzKd = 774588205; wfezABfBUakjzzKd > 0; wfezABfBUakjzzKd--) {
            continue;
        }
    }

    for (int aXJQRekivdgOts = 1003030077; aXJQRekivdgOts > 0; aXJQRekivdgOts--) {
        xEvvNZSxgvMDe += VBLuNRARi;
    }

    if (JQBXYI != string("cIaOtzQdhlZm")) {
        for (int QhxSNH = 525154151; QhxSNH > 0; QhxSNH--) {
            xEvvNZSxgvMDe = VBLuNRARi;
        }
    }

    for (int jNlVU = 330399832; jNlVU > 0; jNlVU--) {
        kvtXDWKj = kvtXDWKj;
        rRZsHmcYiuCHuHIu = yqedtH;
    }

    if (rRZsHmcYiuCHuHIu < string("nchzRRMcDYocPSdgNpxxHTmsiUlvyXKesEsYDHKdeeXbqcCmTUoLRvLUfLOikXeACiXlBqGZpLSd")) {
        for (int FVMdw = 1796586892; FVMdw > 0; FVMdw--) {
            yqedtH += JQBXYI;
        }
    }

    for (int OMTjP = 1144166686; OMTjP > 0; OMTjP--) {
        VBLuNRARi += URUIOl;
        iOfic = kvtXDWKj;
        URUIOl += OOJZsVsDAIK;
    }

    return rRZsHmcYiuCHuHIu;
}

QdorJPJpKLugU::QdorJPJpKLugU()
{
    this->vkFAAwgKbHGCJ(string("USIxjeyRNuCImQUiONIfeLHnUAHsvAoJQGCzFaFlGOoUIhKTiwVyFkqakBvkXsehiBtnLENoOsOBiEOWBHRdVRGJcTVpetIoXNKWrlSlaUWgUicSEEKunuWePOPypJdyhFMJCdKUaQaJltKUdIAeAGuYarYaYxCipQZCZrlQMeDxhYjQyBYBcUCysZXjdiDELamFYVxW"), 1586198327);
    this->bLTLeqarFfhY(string("jTYnvrQdxNHicPVNeZvGWknyxtnJerToIBZhrQcsjvVWMGpFbUEHOWELzaBZEFGZHjycDZxqzoFPIEafWwBjVxBnYQqEpyktgNWWVeJjNFKJwcBOiqbPjMrBCiAtwGSqdhTpIgFazSDFMWujwbIcRDGXFzqSKiIUCzlRFxRLeacFaySwEEaWXbKzqgVp"), string("XNkPEBFVpTaaYeDMlSrxILRJjlHKhvxwOGRhqEAuptHjhkdbkFxcT"), string("aAGWqWtmNzNiyILNvkhPGYYzPzftwlleCMTjmmzLGZaJSWWULSQuifvHBXYNJoxcMRVXeqNyItbVFcuRvqxYaydbDoeWGPrKaTtlEtovflXGZSGaSYqxcCETvBycyIXkogZIHNngSxfEbfxsOtGZuAYsrMmMzzQiwgxmxMkFIMzuqRbCSuObsjbxJOfkHzWWllChYuxbOmXAqIZXwJnEnbqCEPHLHmlXqlqXHGyJWhgMZuFZEChDIj"), false, -559719174);
    this->yxIzmKeYTTLdZpHg(true, string("XXERhhPjegLbOpmCZOOrjEwFxgccMeeLhHZiOCpSKuBnyig"), string("pQtfoZWehVyhtxAiiHYVFfHNDOjuqHIAyaIBunHOfIEBNcbOIjTzHsfydkrWOJnEyesZhItpWjCNWYPs"), -506095.6262304445, true);
    this->ztaWUDnXqOH(string("uJYMMfDOzedSvFtsNcbFIHysaMNrkkQPItZYhrCcDbJcDryRRKSyrDJvTaQXkjnIWVbAPQiqQbuBZDxaRlvKjCIyUmLeHTQXJypzdsiPTRtfmpFRrqZyxXeUargGKVtiaMzkrGGDklWPccTLMweMgtMLJmiWaFilvR"), 6529335, 534857.5151748821, -76320.36073510448);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lwAdKauFbwU
{
public:
    bool VDwPc;
    double Onsdv;
    bool xnvVqcdRnGEuJSz;

    lwAdKauFbwU();
    double gAIcldInc(string NFOTJLdsDwVoU, double mRsUbxmsZoqB, double nFsooYMpBEbgdOZo);
    bool WwnIlKxUXP(bool fBZnv, bool GBCpf, string kexvlMVWAI);
    bool eDdYhhMTi(double yZORCESQbRFzxZ, string LvJLxhZOpMTQfcb, double IzEYtld, int cKglkPDHJoxHJYAY, bool VLoGROjmglXltqx);
    double qbFiHZzmbAxRy(string EGOIDLZZZeryIC);
    void peNcrqXaOAW(string zGgZZNEoWqSdZbNl);
    string ANnGpqm(int ieyKlXQKwnjbr);
protected:
    double ogaUyzbhA;
    bool gpHTjUXd;
    int bOjQvkNOnHWgK;

    int DADefLQDIvBSRcpr(string IiOHTtEyRN);
private:
    int jYSZVuxamw;
    int EDcQvHOrGAnPwc;
    int OpfzUTDQUv;
    bool jIpRpHosOHCcBDJI;
    double vCqSJTQeAURJcGMU;

    int RnmRJmmgQ(double nqqaUhMCfWvw, bool XIwYrsXHrEK, string cnELIDgIUj);
    int UWFTSyknuO(double YiHIdB, string QXbcUJnzGnI, string JLzFUM, string DrMxP);
    void dWqTVsf(string RRrmq);
    bool uYYRZLiBNsQQom(string zdiPbvvJDLwAZ);
};

double lwAdKauFbwU::gAIcldInc(string NFOTJLdsDwVoU, double mRsUbxmsZoqB, double nFsooYMpBEbgdOZo)
{
    bool ODzPxg = false;
    string RDyTN = string("UCCYPRGwrCfbtjHEmRatuXPPoqJtDfBFvySUbJBaXUijfUqGBlbXeMLCNCojKygRfEjWWyeSYHlwQkPKrjEhKFAVPgyHezGUvThajzLcZJcLiSLquYNiADmrnEPrsjSpoShyWqlZprLvFWvmlxBUTfkUPdDCUbSPhDfpIlfRkHqTSETzZVjXuiUXrJwLLwqWZaYRpiLr");
    double ireYebCJBqcqpAu = 1028353.3137860508;
    bool XTHdlHC = false;
    bool AHOoFS = true;
    double qazHmGIXN = -827878.6903419247;
    bool kQZJlG = true;
    double OAZQwDXv = 30147.62030406225;

    return OAZQwDXv;
}

bool lwAdKauFbwU::WwnIlKxUXP(bool fBZnv, bool GBCpf, string kexvlMVWAI)
{
    string IEQKnlMQsrcBEa = string("HOQjEwRWWKJGholokYEKLUqGyBpmgJGOPseWlIuHwGCNBEOBGFoYdkgVXETUVaYIUirdNbHqYLaIfKpSuQofmjdollNKdWirliGGultAsvtLNqQpgeBPsFSkKtCRWsqLJBHm");
    string bSWTdFHNFXIRc = string("DUJuwoSnmawnbjuhIqXVpueezHxjpcpPIUyyzPHpKcBcixCUrZLPqwBxanNaNbDzgiHnhSMphogbgGgUlAXEdxElAYhQbdRkTfdfyxHuWWCiWFJWXLkCbbzwmhvgRxCTbeMvxbQkLCHhSvtQYPlIZVWCfVBSqLufRmwQtCKO");
    double TcHaqoDl = -950681.3963074599;
    int AITQvDLUanijA = -869846478;
    double QbBzBStAIJ = -135570.67829169228;
    double djSOPkaKUGW = -933220.421967805;
    int pWpJMmlpZBcDe = -2066043950;
    int FOYFwfLo = -1925616544;

    for (int mQaQCZybej = 1254498606; mQaQCZybej > 0; mQaQCZybej--) {
        FOYFwfLo /= pWpJMmlpZBcDe;
    }

    for (int cjUAHjFSbrvu = 2075545203; cjUAHjFSbrvu > 0; cjUAHjFSbrvu--) {
        continue;
    }

    return GBCpf;
}

bool lwAdKauFbwU::eDdYhhMTi(double yZORCESQbRFzxZ, string LvJLxhZOpMTQfcb, double IzEYtld, int cKglkPDHJoxHJYAY, bool VLoGROjmglXltqx)
{
    int XJglENQMUMWHbWi = 903278518;
    string fozWIdcxMPodZ = string("RHCDIfFhnkUyZlDsWhVgDKjyFUYyEjeFbiQdrTqypAuYVvfDbdDzEonIsFAGcjqLbRbHOkRfittXJFsWZYDOtOIfuB");
    string WOWXhdmeQcQ = string("MBhdoGTAGQzthajiXQHgebGiycTFdpfPdotWzRUTsXOICaOilIEnipkWRtnyLfkDLpCoLRofJYXcCxmYCGdaxUKMCYEWrBMYXZQFTPQYdYRDhfsudPDuyNEJtKHbpDHPvnjBsYgxdFpbkkpTYtOhFcQPdgILEpcyiLkoGCFqKzHbVPzuEhzcbkFfkRtTxydiHCtMwiLWgQelfaCduuWGcTlCueBkchXk");
    int esELXxXYJzFdOGoS = 157743454;
    int LhsmwCMTsWDUFtP = 1781952273;
    int rVvMtn = -1761527742;
    int hCuCHS = -1665217769;

    for (int qCWWZYutraNt = 1843327720; qCWWZYutraNt > 0; qCWWZYutraNt--) {
        LhsmwCMTsWDUFtP = esELXxXYJzFdOGoS;
    }

    for (int BRsEboDEo = 1251013439; BRsEboDEo > 0; BRsEboDEo--) {
        esELXxXYJzFdOGoS /= hCuCHS;
    }

    if (XJglENQMUMWHbWi > 1781952273) {
        for (int NkRGd = 858778564; NkRGd > 0; NkRGd--) {
            continue;
        }
    }

    for (int RkztscRUrtZGlKQK = 901772805; RkztscRUrtZGlKQK > 0; RkztscRUrtZGlKQK--) {
        VLoGROjmglXltqx = VLoGROjmglXltqx;
        esELXxXYJzFdOGoS = esELXxXYJzFdOGoS;
        XJglENQMUMWHbWi /= XJglENQMUMWHbWi;
        XJglENQMUMWHbWi = XJglENQMUMWHbWi;
        WOWXhdmeQcQ += WOWXhdmeQcQ;
        hCuCHS += rVvMtn;
    }

    return VLoGROjmglXltqx;
}

double lwAdKauFbwU::qbFiHZzmbAxRy(string EGOIDLZZZeryIC)
{
    double wjlqhtPiv = -966433.2361375944;
    int KjyQv = -1006124910;
    string cadPqSBGZxvP = string("GruwtccoBAFdzfgkYblZSODTqXMtzSYqzLWmDMjLvJhzDhUjCVKduLokgphlyVeerGIbNJszqxsaaccyJskiEfAPjHVGxOyWVSMKPOJKMdEQYXnaugoTeWUGFVZPSOXUXDGroWGwceFHxupBbGVfCUokAmkYOlUxEnwjBkBsaotmxlkamVpKkJiPziVrXReTMErDeNOEYuiItyPKmHkfostDPCGeXbSa");
    string ENSSmGjghw = string("LyxTmMJoMhNHfqnkTOUAUtcIcZBznkBsJjCjQHLBqZvKhNdfEBKLtVOJeCiMihMECNyaAvCokuWrrcBXbUlUxQcRIESuOgUWCsEPJaooAzPOOhCOfeVlOOrCmv");
    double zXclCn = -494417.1071785942;
    string rLjkeiTwexUH = string("ewNcpeoUKvNRQPCgHQPGcjZPvsjVrGzoYHjyLRCgIcWjaVWJouAAthgJJTzRWOVFsrYIWTAVvujypGWfRnxIYWsHXrbzIauGnfxarTLtAzDPdgJVXkbjWulwGOuvvROcaXSTPofEbbCUulQosgUxVbjBsenmmMwDtqiMveCSmDGDIwmcXzAghzIeyFzFUYayMZvuhcUIPYabdibGPTRmzeHfYBfrKavCxybtODckYrITiqP");

    if (ENSSmGjghw < string("GruwtccoBAFdzfgkYblZSODTqXMtzSYqzLWmDMjLvJhzDhUjCVKduLokgphlyVeerGIbNJszqxsaaccyJskiEfAPjHVGxOyWVSMKPOJKMdEQYXnaugoTeWUGFVZPSOXUXDGroWGwceFHxupBbGVfCUokAmkYOlUxEnwjBkBsaotmxlkamVpKkJiPziVrXReTMErDeNOEYuiItyPKmHkfostDPCGeXbSa")) {
        for (int CdYYfIKoFOfavmT = 206353677; CdYYfIKoFOfavmT > 0; CdYYfIKoFOfavmT--) {
            ENSSmGjghw += cadPqSBGZxvP;
            cadPqSBGZxvP = cadPqSBGZxvP;
            ENSSmGjghw += EGOIDLZZZeryIC;
            KjyQv = KjyQv;
        }
    }

    if (zXclCn < -966433.2361375944) {
        for (int lmJrVjBKeq = 248646769; lmJrVjBKeq > 0; lmJrVjBKeq--) {
            ENSSmGjghw += EGOIDLZZZeryIC;
            KjyQv -= KjyQv;
            rLjkeiTwexUH += rLjkeiTwexUH;
        }
    }

    for (int VMIFUCOlD = 320531203; VMIFUCOlD > 0; VMIFUCOlD--) {
        cadPqSBGZxvP += cadPqSBGZxvP;
        rLjkeiTwexUH += EGOIDLZZZeryIC;
        ENSSmGjghw += cadPqSBGZxvP;
        EGOIDLZZZeryIC = cadPqSBGZxvP;
    }

    for (int SguSAaApJDzhZEQF = 248871396; SguSAaApJDzhZEQF > 0; SguSAaApJDzhZEQF--) {
        zXclCn -= zXclCn;
        ENSSmGjghw += cadPqSBGZxvP;
        EGOIDLZZZeryIC = rLjkeiTwexUH;
        ENSSmGjghw += ENSSmGjghw;
    }

    for (int rIgKiXVP = 1228769166; rIgKiXVP > 0; rIgKiXVP--) {
        zXclCn *= zXclCn;
    }

    return zXclCn;
}

void lwAdKauFbwU::peNcrqXaOAW(string zGgZZNEoWqSdZbNl)
{
    bool ggGuAotRmYgjS = false;
    string nBZcNPTSrsUgCbs = string("TjtlpAweMnckfXkHWWFaXSAetrDSpcqxDWBcGWIEDVvRseMqsCbaNgmgZruxPAFMbQuTvPdgdjkSOQNjBUdtMHMKNkAggmvMnmLrbWTYiDXxcUvGotZQFnVQPfkmZdqNqGwRAslPJtWPuNTyvQwUXWSbEHCYEKxAENLkTsmhnNLwXJIbMfCKhJRYezQdkooUeDbpalvGlXwTmZpfNZBwQdqvPv");

    for (int BATiVFoHM = 1693338816; BATiVFoHM > 0; BATiVFoHM--) {
        zGgZZNEoWqSdZbNl += zGgZZNEoWqSdZbNl;
        zGgZZNEoWqSdZbNl = nBZcNPTSrsUgCbs;
        nBZcNPTSrsUgCbs += zGgZZNEoWqSdZbNl;
    }
}

string lwAdKauFbwU::ANnGpqm(int ieyKlXQKwnjbr)
{
    int dkDXqTeemyxrN = -637191013;
    string OVKhE = string("OFZRcscOsJgrLZvijDjvCXoWgRWjEXpYbLCXjTSeKIDBAQyTTpwChcyAmzfQZfiHMXLrOTmvgYhyHNWXcyagbhQtYXOyvoeaHYrQhVtrBmqglMlopJQrPbUyvxJWkXcrMDCGoCLVhGRIjtQKTrREGiHarRulTOIXUoJthuYYTFOSJYBnUswqqAKPzuE");
    string nevbgpdhp = string("puonrDqoPkeygmOtIPpkzVZAPoTEMhHSJErKlAvmzhkZlAORcwvGkkdDEJlApjSzVdrrUFxyaFGYshMKBGZICmKbhkOyiWuOQbLlyVJpSSZBXXjJePFhVNzcQeJNsaSjfiaZLvpDfmcPttdYJjzc");
    string KCfThvcY = string("OYruvPFlcQuJYzrTMFGsZcRbZTnGBjypsvdEsKIEHhaGXOZ");
    bool jwtCYikPvoPi = true;

    if (OVKhE > string("OYruvPFlcQuJYzrTMFGsZcRbZTnGBjypsvdEsKIEHhaGXOZ")) {
        for (int xdhOk = 1528669831; xdhOk > 0; xdhOk--) {
            OVKhE += KCfThvcY;
            OVKhE += OVKhE;
        }
    }

    return KCfThvcY;
}

int lwAdKauFbwU::DADefLQDIvBSRcpr(string IiOHTtEyRN)
{
    double GzMcqD = 900912.3275852554;
    double ZJTUtMb = 890845.9737952386;
    bool JdLEXJeZqXvDqpH = true;
    int OYxSmy = 947972131;
    int IdvECcDUZLZycDb = 939560031;
    bool ehUhwaArDZ = false;
    string VpVtalb = string("OdiFQJUqpukwGaCnZMcIciVXvbZOVRRhYgQTVPvGPyplcXttOhwjGYymXGWCWbatQLHddbaPPaoZZxfuhzSVMOAtnMaSYgsXaOevkUOcfuEGKrpbfggCJOTxduoniXXHWLq");

    if (ehUhwaArDZ == true) {
        for (int AYqowzkxQSRXCae = 579063260; AYqowzkxQSRXCae > 0; AYqowzkxQSRXCae--) {
            JdLEXJeZqXvDqpH = ehUhwaArDZ;
            JdLEXJeZqXvDqpH = JdLEXJeZqXvDqpH;
            GzMcqD = GzMcqD;
            ehUhwaArDZ = ! JdLEXJeZqXvDqpH;
        }
    }

    for (int rnlsgTMHcTOvF = 1632260817; rnlsgTMHcTOvF > 0; rnlsgTMHcTOvF--) {
        continue;
    }

    for (int WWQJsDdmuJURVcR = 193030350; WWQJsDdmuJURVcR > 0; WWQJsDdmuJURVcR--) {
        JdLEXJeZqXvDqpH = ! ehUhwaArDZ;
        IiOHTtEyRN += IiOHTtEyRN;
    }

    for (int cKwBoZSqhoJc = 1588031874; cKwBoZSqhoJc > 0; cKwBoZSqhoJc--) {
        continue;
    }

    return IdvECcDUZLZycDb;
}

int lwAdKauFbwU::RnmRJmmgQ(double nqqaUhMCfWvw, bool XIwYrsXHrEK, string cnELIDgIUj)
{
    bool DoOWDE = false;
    string XYBlkBuC = string("matmAilFItAlTmKjNRPKQolXmucdyINcThRwrfUT");
    int DxhAbmpgPxA = 1703132922;

    for (int irAaQX = 2012992989; irAaQX > 0; irAaQX--) {
        cnELIDgIUj += XYBlkBuC;
        cnELIDgIUj += cnELIDgIUj;
        cnELIDgIUj = XYBlkBuC;
    }

    for (int FYthMLUDMB = 309886100; FYthMLUDMB > 0; FYthMLUDMB--) {
        XIwYrsXHrEK = DoOWDE;
    }

    if (DxhAbmpgPxA != 1703132922) {
        for (int FIvCBmXd = 1814512340; FIvCBmXd > 0; FIvCBmXd--) {
            DoOWDE = ! DoOWDE;
        }
    }

    for (int mRqYsabVoVmHop = 451373294; mRqYsabVoVmHop > 0; mRqYsabVoVmHop--) {
        nqqaUhMCfWvw -= nqqaUhMCfWvw;
        XIwYrsXHrEK = ! XIwYrsXHrEK;
    }

    return DxhAbmpgPxA;
}

int lwAdKauFbwU::UWFTSyknuO(double YiHIdB, string QXbcUJnzGnI, string JLzFUM, string DrMxP)
{
    int cTeMiUuyRZr = 1529316988;
    string mzFmLcFIvuHj = string("haAekaDwfrfPWrzVDaLcriJEFHMihBDfgTAgYDRNwaqbvgqdFzvQOMQoPTboDPaMqMyFwajoiFvqTZgSbWEmqpkxZgkMCZUKHsANaUaBRbkgTuTuhOmjiCYOCzXOzwkylIpMGKfDXRChIPgcfdYvjJPswzPSsxCxSKhXbRVKnizLLYLsLsBZzvVYtcOrXZVglYHSEQBxRrkOwMEvMXmVQRtckkisJxVEPeCI");
    string gQinPtD = string("sNVGwDBiZIOltMYojxnBEMSyhuPWwPwrrSeRsCrzAEdgGsEDUUsEbmRHmJCWA");

    if (mzFmLcFIvuHj >= string("LHJqupraVVMZKISoFKwQbXmAEJOFiSWbwuvlRgnAWDHRof")) {
        for (int RnckZFMvqAYKYo = 1429958881; RnckZFMvqAYKYo > 0; RnckZFMvqAYKYo--) {
            JLzFUM = QXbcUJnzGnI;
            cTeMiUuyRZr *= cTeMiUuyRZr;
            mzFmLcFIvuHj += QXbcUJnzGnI;
        }
    }

    for (int ppWxAopERvpfOMCs = 1021512972; ppWxAopERvpfOMCs > 0; ppWxAopERvpfOMCs--) {
        QXbcUJnzGnI = mzFmLcFIvuHj;
        mzFmLcFIvuHj = DrMxP;
        YiHIdB -= YiHIdB;
    }

    if (JLzFUM >= string("haAekaDwfrfPWrzVDaLcriJEFHMihBDfgTAgYDRNwaqbvgqdFzvQOMQoPTboDPaMqMyFwajoiFvqTZgSbWEmqpkxZgkMCZUKHsANaUaBRbkgTuTuhOmjiCYOCzXOzwkylIpMGKfDXRChIPgcfdYvjJPswzPSsxCxSKhXbRVKnizLLYLsLsBZzvVYtcOrXZVglYHSEQBxRrkOwMEvMXmVQRtckkisJxVEPeCI")) {
        for (int qSXxkHm = 604807172; qSXxkHm > 0; qSXxkHm--) {
            JLzFUM = gQinPtD;
            QXbcUJnzGnI = gQinPtD;
        }
    }

    for (int WHTrnvX = 374121430; WHTrnvX > 0; WHTrnvX--) {
        JLzFUM += QXbcUJnzGnI;
        JLzFUM += DrMxP;
        DrMxP += JLzFUM;
        JLzFUM += QXbcUJnzGnI;
        JLzFUM = DrMxP;
        mzFmLcFIvuHj += DrMxP;
    }

    return cTeMiUuyRZr;
}

void lwAdKauFbwU::dWqTVsf(string RRrmq)
{
    int YoutkuLIJhszpHop = -415700836;
    bool YmxzgSKiWCh = false;
    bool sKzqwZGvmjHhzv = true;

    for (int vwkbckTIoeFyyl = 1398474088; vwkbckTIoeFyyl > 0; vwkbckTIoeFyyl--) {
        YmxzgSKiWCh = YmxzgSKiWCh;
        YmxzgSKiWCh = YmxzgSKiWCh;
        sKzqwZGvmjHhzv = ! sKzqwZGvmjHhzv;
    }

    for (int YmmkorUysSZvmRku = 541214483; YmmkorUysSZvmRku > 0; YmmkorUysSZvmRku--) {
        continue;
    }

    if (YmxzgSKiWCh == true) {
        for (int zCFvjxCMqAqyZj = 974045556; zCFvjxCMqAqyZj > 0; zCFvjxCMqAqyZj--) {
            YmxzgSKiWCh = sKzqwZGvmjHhzv;
            YoutkuLIJhszpHop *= YoutkuLIJhszpHop;
            sKzqwZGvmjHhzv = sKzqwZGvmjHhzv;
            sKzqwZGvmjHhzv = sKzqwZGvmjHhzv;
            YmxzgSKiWCh = ! sKzqwZGvmjHhzv;
        }
    }

    if (RRrmq < string("ktnnKkgFeiBJgMCgVNxLqgdDxwKpaeUQKTxCYkQpAjtOIpXzXSxRCgJmziTBeqkSQppEieKIqLvoYRmNLXIfLuGqedJGSUKCcVZPYpIxEwePkxZNCiHezCsWMTuQosOBtcpiNpiV")) {
        for (int sBJAe = 128529062; sBJAe > 0; sBJAe--) {
            YmxzgSKiWCh = ! YmxzgSKiWCh;
        }
    }
}

bool lwAdKauFbwU::uYYRZLiBNsQQom(string zdiPbvvJDLwAZ)
{
    bool GUfevcP = true;
    int smfYDKSAjMfVkhY = 766597610;

    if (zdiPbvvJDLwAZ != string("VDZoJxapqcIKGSNNlVOFsaAwyESTBQcqmHLMbCCMVHBCVxjIOeZLEYxULHROnnIaHHFksMRJgiDgFhlPlxpSefpWfrKHzZQdUSkfHZJupJEMdCawjNzHPvituSYCqZMZwkbtMERBQrxInIulRuuVDtskvlqVuZRzzMRfoYlXmzoaUVfHahvOkakUQwNeLKNmvFqObMCn")) {
        for (int FeViX = 1780700781; FeViX > 0; FeViX--) {
            zdiPbvvJDLwAZ += zdiPbvvJDLwAZ;
        }
    }

    return GUfevcP;
}

lwAdKauFbwU::lwAdKauFbwU()
{
    this->gAIcldInc(string("ifAoRUNxuOJMUoQOzkRxeQPKOrgXkuzxgvpQaXmTLIxMnYSrhVoOMVedxLMzplWkalquFoDEyJfCjpRRUMRcsOpJVGvWCfsjDpMJdmKXNOiICWycoipmidQGSXQevZ"), -548996.2451413958, -973497.3282318093);
    this->WwnIlKxUXP(true, false, string("XQBPKnLcdejRUtJMFHdjIOohSWT"));
    this->eDdYhhMTi(-200254.71278324534, string("ZfFPaSCfOXbMPNBILMxwrcRaZTDevUQ"), -875624.6732291691, -2103422229, false);
    this->qbFiHZzmbAxRy(string("OEqwkxpNrtOWqitaxdVzQpqwuqhRudjFzTrCpdIYDholMuqvsQBpHIacrXwUrdpGKkvreKGIDdyDEwbohbAqqWiOJbwUHFdIXdRJOiANKRgRIBoatxjdSKFoM"));
    this->peNcrqXaOAW(string("BfZtszsBoETzjGshJZKIXsfWcEplYuFdnTKZxWuLMJVTiYqnTAUgKSVmjiDPnFnHGFiGiERflxCgksHsyYhuEAEksNAANUZVUfDaqODUrNPQtCbygDSSeVztygSgbqgkuCzYePPxhVXKyxDZrXDjhbxhPdLqILjBleNbipfm"));
    this->ANnGpqm(-325157032);
    this->DADefLQDIvBSRcpr(string("LptEzeoMAwDfbLGdxBtmIJcUUwbkAhVABCOddgZSZUZskMVhhJFeeyTzVeCqecIebdjruRfTFoeaTMYdMwFmhYqEHDGUszkTwYfMvLYFORbwmOjoPzkuEqWzxIOAuEiOMAgqxSenaBrNhG"));
    this->RnmRJmmgQ(-521619.2756325753, true, string("cjuYpYLwFQjQRhuhpoFqYpBpeiyEstOYXSGCXXRHtAUHramCrSXMtBMsxgULSHyRbIjYFKzmqMYgImYQwQoxntmpIONTrcwGVDMYacnvalMUneLnzuAAipVMgugOPMYNWwme"));
    this->UWFTSyknuO(-548855.716211914, string("gmLGDpsDeQTexhiXqpW"), string("LHJqupraVVMZKISoFKwQbXmAEJOFiSWbwuvlRgnAWDHRof"), string("xtRZVYhHnuvIySuuzyyajmKllCIRXbAFsbqLXbJnUNNIlkMcVVHwktowqvAMBBlOgyugNQrMreDYZWykSMoLyMXvmIqZPkgLHGoczAKbLNWfyJKQxBZiqRaOCYqQTDKclwyxIXAlhhbdjwglzHqfmBDrRV"));
    this->dWqTVsf(string("ktnnKkgFeiBJgMCgVNxLqgdDxwKpaeUQKTxCYkQpAjtOIpXzXSxRCgJmziTBeqkSQppEieKIqLvoYRmNLXIfLuGqedJGSUKCcVZPYpIxEwePkxZNCiHezCsWMTuQosOBtcpiNpiV"));
    this->uYYRZLiBNsQQom(string("VDZoJxapqcIKGSNNlVOFsaAwyESTBQcqmHLMbCCMVHBCVxjIOeZLEYxULHROnnIaHHFksMRJgiDgFhlPlxpSefpWfrKHzZQdUSkfHZJupJEMdCawjNzHPvituSYCqZMZwkbtMERBQrxInIulRuuVDtskvlqVuZRzzMRfoYlXmzoaUVfHahvOkakUQwNeLKNmvFqObMCn"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BsovuWtTzs
{
public:
    string YBidVcW;
    int ATbOUWsTCcHxQ;
    double qDvhAgQQi;
    bool tfOXodEnhqNW;
    double UIEeohkiBY;
    double sDGWxF;

    BsovuWtTzs();
protected:
    bool DsEzt;
    bool bKmACZdGDxIs;
    double IfYNEoPQyrOxDLui;
    string KRMeeOL;

    int aESNMIwGkI(string eGnbcL, string KiffZTHF);
    void ZaGTNNzgNKXDpszr(int pVbvWjHwWiXBPcWS, double ewIAugz, int sihuAlLbhj);
    void bOeHsLhGcof(bool RMrNphXJHrvCwOeU, double rGWnqrbcwHPBFNht, double gHxzCnb, double hfAJCJjRToyXRF, int nLDiCQhUbqlmG);
    string PrumSWo(int iSotEoMrXLGLozU, string rqrIyfqPBn, double TStfeoEZsx, string IEBDWXmvdStNN, double nKpVVuxFW);
    bool OaScBCmouwAz(bool RPjlQJSafyeVMo, int VvWdBFHRAebtY, double UdHONNwWokeFBPRn, double hrPtiAaRlXWDiifC, bool zkeGgOgEKdKqbwPv);
    double MXKXQ(string WbiimYmuUcVB, int snibX, int VeTnLzXHwkH);
    double aKRxRg(double ikHoSQ, double PdxdLp, double mWPGFjqxKrMmiU, string qjIaQeNVwYadxnV);
    string vVfzVqkodO(string cnkUBAksfeNUNsj, double yWMDGYByBnRDTh, double WsUCwIVx, bool xMDYfbG);
private:
    int drByUF;
    double FqjPrztg;
    double BxIZT;
    double OhQpG;

    double vKUeFrkK(bool DnhGjxBey, string ovAMrbwUm, int JkEmBumnRonmH, int ddOCL, double hBhhFVdzK);
    string PLzgfNyhgse(bool NFOBUwIFvypS, double CkAanjDAoxykGhJ, bool ymXiNQPb, int IJsLiEwZAGHvee, bool yVfMD);
    bool DDJKhifve(double eBBSoADWNCzuPdn, bool QoaaORiXoMwLST, bool OBaKeqRWkKTBtII, bool CRBbhLGCl, int dRMYttcYxs);
    string ftYYQIkoQnrXPka(string zVxCtaOwQts, string ffODCFUtwraA, string GHZttQ, int HlQGVYsmFhlLJk);
};

int BsovuWtTzs::aESNMIwGkI(string eGnbcL, string KiffZTHF)
{
    string BKsDmQrvfROuSL = string("RYAQJsAyyMnRWQjOKXmkhsDcOixkNUERsCcmuLZpsYXMzFzKbLALHDPRqQjvntkfgQQKnvtkSEfcRSXWmNYIuhoctNfXxRsRODsXrGARXyEFofhGKpcDXSrAMsURrzUrpVJrNClGjpBhoWYeYVGJoqoQpkMcICxdiDMyqWKWycooXUlarNrVcRSLXrxhXGuOwvDAnxiaxmCmRJyUxoYiMUlODZsqkNMRavnMfKgpjPpCIZ");
    double lMtSRgfnrjCjg = 290348.1497763847;

    return -547724729;
}

void BsovuWtTzs::ZaGTNNzgNKXDpszr(int pVbvWjHwWiXBPcWS, double ewIAugz, int sihuAlLbhj)
{
    int EbEZjXyBkFiw = -1863969058;
    string ATgOfRBKIguR = string("lYULfZV");
    int xuqhOalIgfOrwp = -517747752;
    string jRAlJlrzYHlju = string("jebKIJHNIsepFwUIblpmNIQnEanDxcdlEdKpQCbxsisTbMQOXNbOdUrHbvwjpWRcAHaqkUCKzEsAluSMJkwWPBYYMhDLAaflLOqEDskqDILzrnFNdDfBpfKqkGADbddDTVfJuZMQzUBhSuyyRxHsqZOYFxDaujtCCtZjCYlhGveMenkvvcuDScIJfuGwDbXhStA");
    double fUxdFTKi = -189861.7678315503;
    bool LyfestQPsFn = false;
    int XofSasU = -1990690696;
    bool ZguXIyH = false;
    string bQFBtuctplbORT = string("iUeAGOMxPZjSsAXrSMeeFnYRszWUWwgoNgeBHlyHGaOKtFliXNAvdwHBuKzxVfbAYbBLMBASlWLQlOVCsANeomtvovzIhTbkihWrBzzTuanuV");

    for (int GDrgQrUs = 1305227811; GDrgQrUs > 0; GDrgQrUs--) {
        pVbvWjHwWiXBPcWS /= sihuAlLbhj;
        pVbvWjHwWiXBPcWS -= pVbvWjHwWiXBPcWS;
        ATgOfRBKIguR += jRAlJlrzYHlju;
        XofSasU -= pVbvWjHwWiXBPcWS;
        sihuAlLbhj -= pVbvWjHwWiXBPcWS;
        pVbvWjHwWiXBPcWS += XofSasU;
    }

    if (pVbvWjHwWiXBPcWS >= -1990690696) {
        for (int dIVaCuDYwmVibYHT = 748082654; dIVaCuDYwmVibYHT > 0; dIVaCuDYwmVibYHT--) {
            LyfestQPsFn = ! LyfestQPsFn;
        }
    }

    for (int xkDcmsCIEEahdqq = 595234622; xkDcmsCIEEahdqq > 0; xkDcmsCIEEahdqq--) {
        sihuAlLbhj += xuqhOalIgfOrwp;
    }
}

void BsovuWtTzs::bOeHsLhGcof(bool RMrNphXJHrvCwOeU, double rGWnqrbcwHPBFNht, double gHxzCnb, double hfAJCJjRToyXRF, int nLDiCQhUbqlmG)
{
    string IuHAFRFuQaEZAv = string("bdtMObsbDVFFZaHshpAaxQVlVTYgAaKglxpiYugqgqAhLGLyFgpFaGHltXwFQwcYOvEaNnJILHOrtUEPViHESqopWEqgdIYKfFfzIiECRxFJuiYlSlWaPglEHOPE");
    double TiQVIYMOvZcx = 389014.0536168624;

    if (TiQVIYMOvZcx == 497046.9398215441) {
        for (int tYhBv = 875639848; tYhBv > 0; tYhBv--) {
            rGWnqrbcwHPBFNht = rGWnqrbcwHPBFNht;
            TiQVIYMOvZcx += gHxzCnb;
        }
    }
}

string BsovuWtTzs::PrumSWo(int iSotEoMrXLGLozU, string rqrIyfqPBn, double TStfeoEZsx, string IEBDWXmvdStNN, double nKpVVuxFW)
{
    bool iQeVejKMyiGQ = false;
    int rQAQwYgZYs = -1427633181;
    double HQrbSDfTTSGw = -902014.1110646724;
    double pxeOW = -1009529.6773800267;
    double nNuuOy = 461925.0721964417;
    int FggWn = 631941323;
    int GfPub = 793437929;

    return IEBDWXmvdStNN;
}

bool BsovuWtTzs::OaScBCmouwAz(bool RPjlQJSafyeVMo, int VvWdBFHRAebtY, double UdHONNwWokeFBPRn, double hrPtiAaRlXWDiifC, bool zkeGgOgEKdKqbwPv)
{
    bool xzYlyq = true;
    string LNuIMDuLLHrHL = string("pNLConVxLFzEjkOIsyRSXoozSRYGiaQugsuiZEfEUrBzQnshbIPSitrBFJNyrKyCVwIeEZRIcRzbkJRNbdSRaubdRacaMfLbNdHjOdgUqTAvxOIQCkIHXztdINatIpXjySxVlYMayFRvsJXCTTHykUMzyqkirSwSeubvuhTTCtkgbkwXwcaJCSuwsSJ");
    bool ZVjBY = true;
    int gatiyBwHA = 1570549988;
    int fawCykNMQSh = 2098925388;
    bool nUuhzvHjmPXd = false;
    bool tkDzVDqfx = true;
    string heLBSZH = string("MnLFHcQjhWTQoQmkJQWIqHHkOMkzqamaQFNwtyoieBOlQhHuKlVgGIkmPqOUQJPhGGbyEMiEdhbTGOckDhkRJgIiPKrpFumguDWwNUaOJXpThGgTSPTLiKHrzPaynOISPxkosoWhPGWcO");
    bool vSGRrnWJUvqrgp = true;
    string GOPhB = string("GJHtjYhSxFkJBMwXsblETEUIHRRbyjWnNgborIHSEmiqrzknjMaNeXoLMhRGyTAEjcDWQrYdaqleIXtDJpeGkRMYXlVQuZgEIGAyhLOaSNLnrkjWEvnaAlBVvpDgNGc");

    for (int tRynMaLIYMp = 1759808645; tRynMaLIYMp > 0; tRynMaLIYMp--) {
        xzYlyq = tkDzVDqfx;
    }

    for (int IYuDad = 1472319877; IYuDad > 0; IYuDad--) {
        zkeGgOgEKdKqbwPv = ! xzYlyq;
        xzYlyq = zkeGgOgEKdKqbwPv;
        vSGRrnWJUvqrgp = zkeGgOgEKdKqbwPv;
        vSGRrnWJUvqrgp = ! ZVjBY;
    }

    return vSGRrnWJUvqrgp;
}

double BsovuWtTzs::MXKXQ(string WbiimYmuUcVB, int snibX, int VeTnLzXHwkH)
{
    bool SpBNPSxGLWG = false;
    int WiajuzFDBAxZCOQD = -1375402109;
    double rDFmbDU = -635043.8143836826;

    if (WiajuzFDBAxZCOQD == 2092125739) {
        for (int eQQYssEeAjmfYB = 540196708; eQQYssEeAjmfYB > 0; eQQYssEeAjmfYB--) {
            snibX += snibX;
        }
    }

    for (int GmuoNQM = 404017171; GmuoNQM > 0; GmuoNQM--) {
        VeTnLzXHwkH *= WiajuzFDBAxZCOQD;
    }

    for (int MkGTHfXiFTzVSF = 221570179; MkGTHfXiFTzVSF > 0; MkGTHfXiFTzVSF--) {
        VeTnLzXHwkH = WiajuzFDBAxZCOQD;
        SpBNPSxGLWG = SpBNPSxGLWG;
    }

    for (int BgpdkXXB = 486041928; BgpdkXXB > 0; BgpdkXXB--) {
        snibX = WiajuzFDBAxZCOQD;
        snibX /= WiajuzFDBAxZCOQD;
    }

    if (rDFmbDU == -635043.8143836826) {
        for (int TVzTEYBakB = 1391481583; TVzTEYBakB > 0; TVzTEYBakB--) {
            continue;
        }
    }

    if (WbiimYmuUcVB < string("zJQMwzEMCVXAlXmQlpRpExWSXQqxvwjtzTuLntbgXkcbhWLxHvrduHLRxBgIpneBTDBXweTOVZHyYBFloECrczIkrgghAEfIcgYufuFYLbDcDUfaOokCnsEECDiVzypbilHBHyRwKWPyRbfAuFdokuVfMdXtEYgXPdoTBeAHvzomElCYxRQYCBoLdZypOymGuOAzSasdTTZMrVoZvTiEwqmStSkyYtZSKjfo")) {
        for (int kJtFFgZsdq = 1037000983; kJtFFgZsdq > 0; kJtFFgZsdq--) {
            WiajuzFDBAxZCOQD -= snibX;
            VeTnLzXHwkH -= snibX;
            WiajuzFDBAxZCOQD -= snibX;
            VeTnLzXHwkH += snibX;
        }
    }

    return rDFmbDU;
}

double BsovuWtTzs::aKRxRg(double ikHoSQ, double PdxdLp, double mWPGFjqxKrMmiU, string qjIaQeNVwYadxnV)
{
    string qnrmEG = string("OLQUBhEVMuTIhLtrpeoWOqwxXKbFTdcrLxOyjAgDhCQatyhTMXTbbfVNVPqldnzDNDqcfCfyVuZOhTESCMmkmfcuGcAGSXEGKdYHZaVoCVjFAEoLnGgtKBYPFalqYPHQznOmRtZgrenMkoIUmKbsRcBiHaVhHCimHflgQmsBKwKuPoaKJaCHaUwPZHRZoJLUgdDtqKUYdqPCU");
    string GOKDINODTQepLfB = string("BBlAqjIKbpLWFZVXEDcgiHbwLxguvgTixYSpsADlJXRxMIpLtStXSgNmQbivzhItdEkEv");
    bool DFSDmRfhwJtN = false;
    int ADQBxzlBF = 2063826363;

    if (PdxdLp == 468879.2319513833) {
        for (int ghDzmXpNl = 119417207; ghDzmXpNl > 0; ghDzmXpNl--) {
            continue;
        }
    }

    for (int PsGDPVhhgTi = 355580402; PsGDPVhhgTi > 0; PsGDPVhhgTi--) {
        qjIaQeNVwYadxnV = GOKDINODTQepLfB;
        GOKDINODTQepLfB = qjIaQeNVwYadxnV;
        GOKDINODTQepLfB += qjIaQeNVwYadxnV;
    }

    return mWPGFjqxKrMmiU;
}

string BsovuWtTzs::vVfzVqkodO(string cnkUBAksfeNUNsj, double yWMDGYByBnRDTh, double WsUCwIVx, bool xMDYfbG)
{
    double NQurNisGigmlUoAE = 486982.48667586996;
    int LpHdBsnaHJIOg = -486856529;
    string NMmzXygNUeaLLZV = string("bAYJKYDMUhhsQLhDmQTPqzqmSWDvvRkhYDiuVySRLJBKxHWgYArZpoeDKQJFAfqTGWUODWrvIueJSZWiwXnXsTtcKDxdUYGBKKnCISePrNaVvtZgznqZSKVrlxK");
    int BSimYoyfsabsArE = 567955100;
    double wnhKkHLgimKB = -421820.2773957827;
    bool FZhICYRUvKpiftGi = true;
    double iIKKOkvWP = 434810.3294498943;
    string bNLEAIWwnvXOEi = string("iXXtDHYxMlvTvuxcoHj");
    double DlLMpYCZktRyBd = 514873.5223109798;
    bool rVymIoJxqx = true;

    for (int aduzYHUYWIQ = 371529373; aduzYHUYWIQ > 0; aduzYHUYWIQ--) {
        continue;
    }

    for (int BVdvrrGLRHnYz = 623290495; BVdvrrGLRHnYz > 0; BVdvrrGLRHnYz--) {
        continue;
    }

    if (yWMDGYByBnRDTh <= 514873.5223109798) {
        for (int nCTNJTamIQmVMj = 1851950997; nCTNJTamIQmVMj > 0; nCTNJTamIQmVMj--) {
            continue;
        }
    }

    return bNLEAIWwnvXOEi;
}

double BsovuWtTzs::vKUeFrkK(bool DnhGjxBey, string ovAMrbwUm, int JkEmBumnRonmH, int ddOCL, double hBhhFVdzK)
{
    double TAGmJ = -1040398.4754933972;
    int JqCLXJcCcf = -827238382;
    string YOOnWuhdcbUmII = string("CfWVqiZwBbeFtmgvIqSEqqnJOmwjRcKMMDwsozSApLwkTQXELuwqWpImepOOvEINbGSlvCrQzymPYITRzIZqT");
    double CNSypDRFhboXFDz = 567332.462573803;
    int OTOwpdmuOAWEqMD = -645463597;
    double qCwvrQvVCR = -927009.3841569852;
    string RRITb = string("MGuoGAOMfQFqWuphKmowjiblVjYrVLMRdtORdMWNxVzRJtjUEOIlxvSDXQIjFSxItfpiZeUxllEnGNnwpbExXNEmKCOhKgOCRilhZZvgMNCXnZwUPMykFRGyNWYYmVLaNJaIHesGKbgxRtzEBzWpVqAHWl");
    int ULgJluIrTGjM = 1709332756;
    string SaPeA = string("BGQt");

    for (int RtJrkMdPVvBhRRQE = 478155207; RtJrkMdPVvBhRRQE > 0; RtJrkMdPVvBhRRQE--) {
        TAGmJ *= TAGmJ;
    }

    if (SaPeA <= string("CfWVqiZwBbeFtmgvIqSEqqnJOmwjRcKMMDwsozSApLwkTQXELuwqWpImepOOvEINbGSlvCrQzymPYITRzIZqT")) {
        for (int ZPnZSIHhwRsLw = 193407098; ZPnZSIHhwRsLw > 0; ZPnZSIHhwRsLw--) {
            qCwvrQvVCR *= qCwvrQvVCR;
            ULgJluIrTGjM *= JqCLXJcCcf;
        }
    }

    for (int YFltWxIPURICx = 286098862; YFltWxIPURICx > 0; YFltWxIPURICx--) {
        YOOnWuhdcbUmII = ovAMrbwUm;
        CNSypDRFhboXFDz /= TAGmJ;
        RRITb = SaPeA;
    }

    for (int aQZcoXL = 531726292; aQZcoXL > 0; aQZcoXL--) {
        ULgJluIrTGjM += JqCLXJcCcf;
    }

    return qCwvrQvVCR;
}

string BsovuWtTzs::PLzgfNyhgse(bool NFOBUwIFvypS, double CkAanjDAoxykGhJ, bool ymXiNQPb, int IJsLiEwZAGHvee, bool yVfMD)
{
    string LSTiYNwrsVicJ = string("IVEODSPgnKtkXVCHQnwuExjXkuXDMMp");
    int tEKUTYv = -1105208291;
    string JxETXvMJWH = string("PiDEKAimnOFdGFOAcNBJwQlgoaHKPoPFrmPhJFTGodseEclZJFkgrcujjGPgneqarTvfUCiaWqistXCJSYmemFVcBGqIjmlKiDaNYHnSHkOndUVTeJbmBDMrDUTnmWdsiZaAOxgNxVsYeTQGACczKOoyMLwNopJMtBavNJfhwghKkznFmrptpDkXrqFRRnHdQbJrhkdiBbxGNZwXPXYsPLSrkGAhLDlmVbVMWCitTfplOCXhNGKvMwfLyuX");

    for (int RAnQwUaJUlQFez = 1286048575; RAnQwUaJUlQFez > 0; RAnQwUaJUlQFez--) {
        tEKUTYv = tEKUTYv;
    }

    for (int ZMFLqGFGI = 913508767; ZMFLqGFGI > 0; ZMFLqGFGI--) {
        CkAanjDAoxykGhJ += CkAanjDAoxykGhJ;
    }

    for (int uTONKSoRYxVK = 2084705547; uTONKSoRYxVK > 0; uTONKSoRYxVK--) {
        NFOBUwIFvypS = ! ymXiNQPb;
        NFOBUwIFvypS = ! NFOBUwIFvypS;
    }

    return JxETXvMJWH;
}

bool BsovuWtTzs::DDJKhifve(double eBBSoADWNCzuPdn, bool QoaaORiXoMwLST, bool OBaKeqRWkKTBtII, bool CRBbhLGCl, int dRMYttcYxs)
{
    double lNhTxdr = -368906.093372826;
    bool sDibtfz = false;
    int jxngVXnoxAov = -1846607332;
    int DlErr = 2003791937;
    string CyTdAgBhAGmnPtm = string("ikfudbHrsIoyUeRMnWcRxyOScRmctapLUSHB");
    bool RrnRCpblxKfwWnU = true;
    int fXVPIFY = -532477301;
    bool aKhduH = false;
    double XDerBNMhISNRB = -193829.24603620777;

    for (int EOgOGrnbqUUGn = 1589880233; EOgOGrnbqUUGn > 0; EOgOGrnbqUUGn--) {
        RrnRCpblxKfwWnU = ! QoaaORiXoMwLST;
    }

    if (DlErr >= -1846607332) {
        for (int WOScLJWqMfrzt = 1759250313; WOScLJWqMfrzt > 0; WOScLJWqMfrzt--) {
            OBaKeqRWkKTBtII = ! aKhduH;
            lNhTxdr -= XDerBNMhISNRB;
        }
    }

    return aKhduH;
}

string BsovuWtTzs::ftYYQIkoQnrXPka(string zVxCtaOwQts, string ffODCFUtwraA, string GHZttQ, int HlQGVYsmFhlLJk)
{
    double piFZSKJJ = 172820.0955380251;
    string HwSYpjhrZ = string("XxeRuBOMdjvYOERqrfsWICpWcmDBBgWRLVlaASlYsgOJTCJjlnjuDqHIvT");
    bool qMMwPa = true;
    bool nvRYhDRhGMVUfzZd = false;
    bool hzupmIqWmqbzbGD = false;
    bool idxuhzWzXKWizlBw = true;
    int qQcbSZCmRXaRDL = 1942643373;
    string DxZAkdCFulltsf = string("LKrXgBscfDHjSlQAUtCjwcuNbhXBLmvhydxdMY");
    string tfrsVtwEZIhhjCmJ = string("wFthElRRysgPBhaQaaVMzbVbVKebqRtVfVENaAcfdfnSACEXpRGFViNcjlvInmrUFmqNqliinqbUvNCBVSjjpVXYRZcBKXEzgUKZLcoOjvjpbFnGsIsnOTOzftwtFWnXwJVFobsnuKLPLqwZXrbNOuorhOCEDsnaSiJBfwpURFtpieUMlAsGbmQFrXxdAEequwyxauFjNwUOWPrnHGARxiSrEVaQYVEuJVvClcHFtWtJWxHFWAutYKULfm");

    for (int RGvuLeBgRO = 120635063; RGvuLeBgRO > 0; RGvuLeBgRO--) {
        continue;
    }

    if (zVxCtaOwQts == string("wFthElRRysgPBhaQaaVMzbVbVKebqRtVfVENaAcfdfnSACEXpRGFViNcjlvInmrUFmqNqliinqbUvNCBVSjjpVXYRZcBKXEzgUKZLcoOjvjpbFnGsIsnOTOzftwtFWnXwJVFobsnuKLPLqwZXrbNOuorhOCEDsnaSiJBfwpURFtpieUMlAsGbmQFrXxdAEequwyxauFjNwUOWPrnHGARxiSrEVaQYVEuJVvClcHFtWtJWxHFWAutYKULfm")) {
        for (int ALmwKS = 1725298034; ALmwKS > 0; ALmwKS--) {
            GHZttQ += GHZttQ;
        }
    }

    if (hzupmIqWmqbzbGD != true) {
        for (int sHJqpJILq = 866451184; sHJqpJILq > 0; sHJqpJILq--) {
            DxZAkdCFulltsf += tfrsVtwEZIhhjCmJ;
            GHZttQ = ffODCFUtwraA;
        }
    }

    return tfrsVtwEZIhhjCmJ;
}

BsovuWtTzs::BsovuWtTzs()
{
    this->aESNMIwGkI(string("kSgEDyNqrTnDYyQZzrKuHLhdjTqlLjmrhbnVpJCdwQKXfwChaRmLFufDXCLamJfCJSrWX"), string("PGyzxzYxcGJpFUMGKDxNhkoRIqRdBmDQchbmvIaNBQChfLfapCmMuKfOuZTKPqxJjXwRVRlioAQDEsLQiKgFBSqTciVUdzJtQgQw"));
    this->ZaGTNNzgNKXDpszr(1503261223, -645598.7167219584, -1744771121);
    this->bOeHsLhGcof(false, 828114.708028639, 497046.9398215441, -1043729.4597410047, 1490874412);
    this->PrumSWo(468008822, string("WlePCgEUWbBlplSHGQiYgQKsWPUAZIeonnHcxUQTzVyPnWynsSTcIZQsuEMgbmZCoNsCVpIjNTlJdDYMuqfWMmZVDlcWqQXtVLTsaDMXBudRDbAtaKcwjxfOlL"), -292105.41211305093, string("ztjlvgFDkbBrEDSdNIydWdippchzurKTeSRmQSdJdnBvsPlCzmeZOCTpSibvklqlgXIwvvBhsICdYIWjYwPZGrSQBXyGIaqaShnZWbXQkgmEWLmCPvMzZXqSEwkhLuYWODJMfGpNgQfiMtokwUdZcpteQaLqLzzQZWCVzhPustJoOKfkzYaVryCafkyFYYHXFkqRaPuFIAXuBtPtrs"), 465617.3078786761);
    this->OaScBCmouwAz(true, -1659007622, -924241.6602104374, -611432.3915260283, true);
    this->MXKXQ(string("zJQMwzEMCVXAlXmQlpRpExWSXQqxvwjtzTuLntbgXkcbhWLxHvrduHLRxBgIpneBTDBXweTOVZHyYBFloECrczIkrgghAEfIcgYufuFYLbDcDUfaOokCnsEECDiVzypbilHBHyRwKWPyRbfAuFdokuVfMdXtEYgXPdoTBeAHvzomElCYxRQYCBoLdZypOymGuOAzSasdTTZMrVoZvTiEwqmStSkyYtZSKjfo"), 2092125739, -764036213);
    this->aKRxRg(267980.03872129205, 468879.2319513833, -604600.7090694539, string("UkQPEOgroCXMGvQrZlIvAZLcDnREzCdXxHFmazkCIXmHihKGSIzyCVtNRHhKzTDnAoPMbJFkKuWgGMIryNSauVmLmpABudlwWUWeGtkPOJJalCzSOrQwYEcaXrUbXcMYHkUmtEXoPZtNfdmPutOPTVYHYTwIjOAJinauYQdQtQhfxQQCGogWLKpkqvwNyhZs"));
    this->vVfzVqkodO(string("fhNYhjtLCbMAyygRoGTwkPpwoIRrYFwsRnjuoHdiKxuKGOXVPOQxFrWhjOnAGmZbUaYOqXtGTivYCoxUWhDjPnaLuTcSFtALyyKbdNoWEWnWE"), 300617.6370273191, -207920.0274380355, false);
    this->vKUeFrkK(false, string("EIgQoJUbfVJwoGSUNohyjBRSmEZRPPwHmgOfFYTXBpTqFEeHjjjvDbyihfgSp"), -510109630, 735689546, 505560.0593020025);
    this->PLzgfNyhgse(true, 325244.5403983147, true, -1829861651, true);
    this->DDJKhifve(8710.363824491305, false, false, true, -190115908);
    this->ftYYQIkoQnrXPka(string("tCujRmYvozRJcOtOWOaLwvuWrblaxnoDHLFAmGUFrfEcIuXCcQRMSlCssnizMrbffxlNTFqxbbfZUwVjRNHAkiPaAmIJfuzrRfqnTAWBvSlBphyzvwoLoHQngysjXjYoLweKwvAiwZoyyxngZkaPnFxXJkT"), string("rFtKIgqCztFoGMQlYSLtldcpFZkPafQDrtubeRdvJTfCtLAvuEOfQKEweJEFKsQXsRXUhRuNVvXKvkAkmTTucUcUOlQvvNzzYwCLPTxLPwkftOPYuqnwzLiDLkecrJyWBCEmbROfPihXomrbLRSWYInYSbkFzpMrcPiBoazo"), string("ghcEnfSDZmdxLEHsqozXWLOHxCpFEKjBDsiXCirPqtIZEsiuHVgVSsGBpzzbLIloTrqykCgonBwxiXsvdoxCsPCqVUNKmIyGKBtwNttSkjzqSGDIbVfRtnvrhzaeAdEbbLllZxAjTvIvFTdNFRUqjjFSpCAahKSJlPwnFjUzqMVMZcISDqMrHhQjZOlxNBoJPoysmxsfRUwGPCXFPLArtTBqPkLLxtEmwzYadZBjSOIyLeDOrCiajAQKunT"), 2085958771);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NYErQQloY
{
public:
    bool yGFhYGL;
    double VBTXpoCrb;
    double YMYRKfGqUsdEc;
    string KXBDUkkbecx;
    int NkFyKBezwR;

    NYErQQloY();
    void BoBxjWgyUGGZLC(int qjROzvRAUOxYOS, int KBAIPMPYBpsDU, int EBMuZaNIKc, int KPsrSjIeIDja, string alyVsLcvlrs);
    double plkeOlPx(int RvKuWKuKcNIkzH, int GmUxAdNagS);
protected:
    double BXJZuZdUtzNKtXR;

    void igcwsoDzYbt(bool PApVOpMp, int zfsyjmEWeexZBp, bool zugTzBVint, string nVVhoprOMmihLVel);
    double mtOgBmDa(int WDBUIJ);
    double WSNPJELuBNe();
    void xfecbdSvxxooTFc(bool HQkhHVKkCBhvv, double mZWClNZb);
    double TbMqZjOvMI(bool oLrTgJaxdODW, double IjViMWuxFdCkDBs);
    bool XOuezEMIKDEzk(int tMSXtLocWb, string DpNiaMWvcwr);
    int LAfmEIsDpahQBUyQ();
private:
    bool ICEvSmeupVBgh;
    bool oyOGW;
    bool edksLsHc;
    bool ZStmHTOPsdr;
    int gjBjYNFOLjSt;
    int kWmKpIeugMVAJxr;

};

void NYErQQloY::BoBxjWgyUGGZLC(int qjROzvRAUOxYOS, int KBAIPMPYBpsDU, int EBMuZaNIKc, int KPsrSjIeIDja, string alyVsLcvlrs)
{
    bool prJnVAOcwp = false;
    int RPKdvMuGjr = 418076138;
    int KcXSajDlZI = 654912449;
    double dPmwPILazy = 151528.91489289413;
    bool mgrrE = false;
    string evnxEiMPszYY = string("ZYhZfdilOjqrfBbueOzAfWBmAVxpaRxqYJmTYZHlkpCHoVAMMZPfGLQpbvQhSHsDGREFrYqWHdGOoiauzFzQXtYlYUgZitHykjXdFiLSWPFFuMqmHGtOPqfApXOC");
    int bVUOXSPPU = 1853406645;
    int sWeCqBTwhxeLm = -421960485;

    if (alyVsLcvlrs == string("ZYhZfdilOjqrfBbueOzAfWBmAVxpaRxqYJmTYZHlkpCHoVAMMZPfGLQpbvQhSHsDGREFrYqWHdGOoiauzFzQXtYlYUgZitHykjXdFiLSWPFFuMqmHGtOPqfApXOC")) {
        for (int WnYDhcHXB = 484015720; WnYDhcHXB > 0; WnYDhcHXB--) {
            KPsrSjIeIDja /= qjROzvRAUOxYOS;
            alyVsLcvlrs = alyVsLcvlrs;
        }
    }

    if (RPKdvMuGjr > -1785383695) {
        for (int GXHHXB = 1338068035; GXHHXB > 0; GXHHXB--) {
            EBMuZaNIKc += sWeCqBTwhxeLm;
            dPmwPILazy += dPmwPILazy;
            KPsrSjIeIDja -= RPKdvMuGjr;
        }
    }

    if (RPKdvMuGjr != 1981064102) {
        for (int DgtZXti = 325142394; DgtZXti > 0; DgtZXti--) {
            KBAIPMPYBpsDU -= KcXSajDlZI;
            RPKdvMuGjr /= EBMuZaNIKc;
            sWeCqBTwhxeLm /= EBMuZaNIKc;
        }
    }

    if (EBMuZaNIKc < -421960485) {
        for (int JYbxrvi = 2044247960; JYbxrvi > 0; JYbxrvi--) {
            RPKdvMuGjr *= KcXSajDlZI;
            KPsrSjIeIDja -= qjROzvRAUOxYOS;
            bVUOXSPPU += RPKdvMuGjr;
            KPsrSjIeIDja /= EBMuZaNIKc;
        }
    }
}

double NYErQQloY::plkeOlPx(int RvKuWKuKcNIkzH, int GmUxAdNagS)
{
    int frWeLSMbdXgDj = 1883962142;
    double QlWvvj = 32570.9675573049;
    double MlmnXmSyXgGwjWc = 606333.3648361636;
    bool jaVFcbaXDkHhimaQ = false;
    string CjceIcceLpFWQhjm = string("aSGqPipJJQvmBRWpOraDnVjerEPXqInlvxgnJFeWrulQJSEYBpWdTxbeTSjEkESYUnLasegaLrwoaVUsbbGovaieZPiopirnoiMIuBLfIAXTMkFwrdnwOUsiEqmAGqrUJRjvBXHLoWFThiXHvYvZNTxnfqJwMZhSMzGVGVsUcknlcODAPYnDXDVGcLvGsLgzzmtSlhhX");
    string Fzvznpim = string("YUHRoElIJLhOuhNHdyXUelpbQdbZtfkoblRoPFVzwrPNbKdNisvMQJrRGbAJLOmiERrlzUcqmLlrscuHTvImidtTtAFnyOWjpzPeuAIMKxGZtNRIYxWrStdPnndxXtSZjShxyKPdQWzQoUDolodVQlsjEUIxcMgoyJHmRuVXHMxRFGaWmceJtLmZXOTEZOIKTvONewwLhrnbyMyHkISgtqSESyPnCNASaVBFkdawEKdVXcxKg");
    int MDThUCRBEdns = -486428817;

    for (int BJBipEjJXp = 2089633294; BJBipEjJXp > 0; BJBipEjJXp--) {
        QlWvvj = QlWvvj;
    }

    for (int uSgfzvrRI = 1067109476; uSgfzvrRI > 0; uSgfzvrRI--) {
        continue;
    }

    for (int DDMBOToBocHHGVxM = 166039577; DDMBOToBocHHGVxM > 0; DDMBOToBocHHGVxM--) {
        GmUxAdNagS /= RvKuWKuKcNIkzH;
        GmUxAdNagS *= RvKuWKuKcNIkzH;
    }

    return MlmnXmSyXgGwjWc;
}

void NYErQQloY::igcwsoDzYbt(bool PApVOpMp, int zfsyjmEWeexZBp, bool zugTzBVint, string nVVhoprOMmihLVel)
{
    string SBhkpFJboeSnX = string("CFslHtNcuWBOekjKbAYYGDENNSDSQCJgenSsrjXZcmQbUgvOmfJeeSrqWbgzzFXzirGYMtzKpsRnN");
    bool UbDKSdsA = false;
    bool yfZxXfkek = false;
}

double NYErQQloY::mtOgBmDa(int WDBUIJ)
{
    bool HpBUREWdTtxMhJR = true;
    int NLViejUaVSGmwL = -999177589;
    string pYDqSXs = string("zguhPNeCWcLfBIbbHLsVREFvksKjOTpPKjHyZxOuUVtPJBmJgZkxuBrvruJuopBhTlqaDatebfrbdgJqNVaOlYHFRansbscEZJYYQipacFhmYdTrWEKjsxHhMsGqWgWXhAGjrzuMXEAQBQxedKRuNhNfIincvalnJLcBgsNZ");

    if (pYDqSXs > string("zguhPNeCWcLfBIbbHLsVREFvksKjOTpPKjHyZxOuUVtPJBmJgZkxuBrvruJuopBhTlqaDatebfrbdgJqNVaOlYHFRansbscEZJYYQipacFhmYdTrWEKjsxHhMsGqWgWXhAGjrzuMXEAQBQxedKRuNhNfIincvalnJLcBgsNZ")) {
        for (int MsZojykAH = 189284580; MsZojykAH > 0; MsZojykAH--) {
            WDBUIJ /= WDBUIJ;
            NLViejUaVSGmwL = WDBUIJ;
            NLViejUaVSGmwL -= WDBUIJ;
            pYDqSXs += pYDqSXs;
            NLViejUaVSGmwL /= WDBUIJ;
        }
    }

    if (HpBUREWdTtxMhJR == true) {
        for (int jgjSYfOFqGgiNbh = 56775025; jgjSYfOFqGgiNbh > 0; jgjSYfOFqGgiNbh--) {
            WDBUIJ -= NLViejUaVSGmwL;
            pYDqSXs = pYDqSXs;
            NLViejUaVSGmwL *= NLViejUaVSGmwL;
            WDBUIJ = WDBUIJ;
        }
    }

    for (int zeIzeqOFpFXDb = 987805674; zeIzeqOFpFXDb > 0; zeIzeqOFpFXDb--) {
        NLViejUaVSGmwL -= NLViejUaVSGmwL;
    }

    return -961124.4990437839;
}

double NYErQQloY::WSNPJELuBNe()
{
    double dutEkWq = 657685.2897756316;

    if (dutEkWq >= 657685.2897756316) {
        for (int wSrGmseK = 218393515; wSrGmseK > 0; wSrGmseK--) {
            dutEkWq = dutEkWq;
            dutEkWq -= dutEkWq;
            dutEkWq /= dutEkWq;
            dutEkWq = dutEkWq;
            dutEkWq *= dutEkWq;
        }
    }

    if (dutEkWq == 657685.2897756316) {
        for (int qfqpnmkndXtOgo = 1049761679; qfqpnmkndXtOgo > 0; qfqpnmkndXtOgo--) {
            dutEkWq *= dutEkWq;
            dutEkWq += dutEkWq;
        }
    }

    if (dutEkWq <= 657685.2897756316) {
        for (int vdhTuRaTWERBs = 296770544; vdhTuRaTWERBs > 0; vdhTuRaTWERBs--) {
            dutEkWq -= dutEkWq;
            dutEkWq += dutEkWq;
            dutEkWq -= dutEkWq;
            dutEkWq /= dutEkWq;
            dutEkWq -= dutEkWq;
            dutEkWq *= dutEkWq;
            dutEkWq /= dutEkWq;
            dutEkWq /= dutEkWq;
            dutEkWq /= dutEkWq;
            dutEkWq -= dutEkWq;
        }
    }

    if (dutEkWq < 657685.2897756316) {
        for (int MPLbSmwlRkMy = 1626300386; MPLbSmwlRkMy > 0; MPLbSmwlRkMy--) {
            dutEkWq /= dutEkWq;
            dutEkWq += dutEkWq;
            dutEkWq = dutEkWq;
            dutEkWq -= dutEkWq;
            dutEkWq *= dutEkWq;
        }
    }

    if (dutEkWq <= 657685.2897756316) {
        for (int BNCtMNwwcfJj = 2122266633; BNCtMNwwcfJj > 0; BNCtMNwwcfJj--) {
            dutEkWq *= dutEkWq;
            dutEkWq += dutEkWq;
            dutEkWq += dutEkWq;
            dutEkWq = dutEkWq;
            dutEkWq -= dutEkWq;
            dutEkWq /= dutEkWq;
            dutEkWq /= dutEkWq;
        }
    }

    return dutEkWq;
}

void NYErQQloY::xfecbdSvxxooTFc(bool HQkhHVKkCBhvv, double mZWClNZb)
{
    double vxdxerMSeusq = 748740.5430473986;
    bool mcsFpttjSY = true;
    string oEIpgs = string("HDFlcTeonQFNBiZyUOSsrSlTrSrJjcZCGYOKUDJyUiTLUhznJDGFQRnOMsZYdefeRUzLWYG");
    bool MpVEvswck = true;
    int SLbhBoahmEjE = 681816686;
    double myOwiq = -282896.9196063582;
    bool GSUNkz = false;
    string ZaNTXWXVWN = string("CWDpjtsRMGuaWVGejBhXyOtKq");
    string EDGfs = string("TiqlbyWOVJaTbbKSMaEswzTXIDYzTcXZWbqiBHedZYmdTudcEhauQOfmRm");

    for (int JxBZoanMlDepPIl = 632047639; JxBZoanMlDepPIl > 0; JxBZoanMlDepPIl--) {
        MpVEvswck = ! mcsFpttjSY;
        EDGfs += oEIpgs;
    }
}

double NYErQQloY::TbMqZjOvMI(bool oLrTgJaxdODW, double IjViMWuxFdCkDBs)
{
    bool tTCAeC = false;
    int gFDqbZql = 1964958985;
    string ZEaGKA = string("sVyCxHqQOxOpscjaEzbwsiRgEvrEpSjgmGWRAnBFGXHKdXRpHjcKbhrlUPeYoACgnvPVMXRlaDtBbV");

    for (int AYeMAxJreS = 350442884; AYeMAxJreS > 0; AYeMAxJreS--) {
        continue;
    }

    for (int nIDjmRghKWYByPI = 1406970664; nIDjmRghKWYByPI > 0; nIDjmRghKWYByPI--) {
        IjViMWuxFdCkDBs = IjViMWuxFdCkDBs;
    }

    return IjViMWuxFdCkDBs;
}

bool NYErQQloY::XOuezEMIKDEzk(int tMSXtLocWb, string DpNiaMWvcwr)
{
    string tQiOFmUHuAZlI = string("BeHpQIlBLGNnoipDhxCWdeDIHptIdhKYDoJXpmpipoIWWEuiHQUbtGTxcxhAKthEdQrSPKureJfhbkcbZpijXYbbPGukqqlNSUDwJXiEBhskEHT");

    for (int XhmUTJjVlAl = 308320468; XhmUTJjVlAl > 0; XhmUTJjVlAl--) {
        DpNiaMWvcwr += tQiOFmUHuAZlI;
    }

    for (int VUPRcSWuPWPoFHco = 935032726; VUPRcSWuPWPoFHco > 0; VUPRcSWuPWPoFHco--) {
        DpNiaMWvcwr = tQiOFmUHuAZlI;
        tQiOFmUHuAZlI = DpNiaMWvcwr;
        tMSXtLocWb /= tMSXtLocWb;
        DpNiaMWvcwr += DpNiaMWvcwr;
    }

    return false;
}

int NYErQQloY::LAfmEIsDpahQBUyQ()
{
    int TOwspSDQ = 387013879;
    double mVbSzOUBUKhUOif = -282514.2392074901;
    string baPJUKyACGExEIjL = string("XWjNtjeQjCoNOddOlfzBQMUijtquWOrfUJpvqQkfsVwXfjFsANHOxkwhGusKeloZuFkYEzNrYlGetRfJcYhtOFujUfNhtOVOuQjC");
    int tEqJpOUnTVtar = 948571834;
    bool CYKJGuWJNotG = true;

    for (int XrlSE = 1408575716; XrlSE > 0; XrlSE--) {
        CYKJGuWJNotG = ! CYKJGuWJNotG;
    }

    for (int gSSmWrAmLXdAp = 649284058; gSSmWrAmLXdAp > 0; gSSmWrAmLXdAp--) {
        continue;
    }

    for (int XjRJQmo = 1421168207; XjRJQmo > 0; XjRJQmo--) {
        tEqJpOUnTVtar /= tEqJpOUnTVtar;
    }

    return tEqJpOUnTVtar;
}

NYErQQloY::NYErQQloY()
{
    this->BoBxjWgyUGGZLC(-1785383695, 313586487, 1522760826, 1981064102, string("vTjcfclTJWlRCvicAkqghSgnGDynEhettBeolESkvbbuqUjGKIwaxVLLVbifvizuMvJwulavFuFCaNSASiHfAeApBsQiYKHiVntylnxtrQzUzdGmqbgETgUTUi"));
    this->plkeOlPx(1025992434, 862114821);
    this->igcwsoDzYbt(false, -103131912, true, string("HZaIKDoGSqGxAPPdyvQNBiaRMusteBoauljvGyNkZduwdmvxVoWeaJWjxMXxpZtsuVksOHBFkysvWOtCvxdHyULozgiimpXZGRXGFtfOLULiXXSMf"));
    this->mtOgBmDa(-1214788115);
    this->WSNPJELuBNe();
    this->xfecbdSvxxooTFc(true, 124241.26209598503);
    this->TbMqZjOvMI(true, -905235.8101613987);
    this->XOuezEMIKDEzk(-853160407, string("KkAMFfiVqSuLUoQVYZJmFndSeGtqertEgRyVOrLOwELIWYUVCzeLbAutVVealSXOvxkCFvrGXOoURsySluYzzrwKdVmqBaGweTIoVXucJgvPKFGWjLVNQRlVlUBOGbsXbxwLXnqVooNtjLinKDMWKvbNNFTBSxCFIroXsgkhuXEBGbiruYrQX"));
    this->LAfmEIsDpahQBUyQ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class miPFvSfyzLsC
{
public:
    string bzPKNRmGOv;
    bool OAqDaqlsFjq;
    bool ucfAARTQNF;

    miPFvSfyzLsC();
    bool LgclWKZpN(int pbzVnFM, int uCFijQXnZangsjq, string wUemtctumpH, double XQKKTCcpqQWR, int Sifpy);
    int LfPnGJCpxTJZssl(bool AfJzQVmyxadZX, int NuXInOPtoSFrFwD);
    string ABaIK(bool zbDBokNhhD);
    bool qzLjKEfv(string aJBYLJZ, double KhvzAatAIhWWheFU);
protected:
    bool mFjRmORJoSia;
    double sKphXANB;
    int tMZycdD;

    void mJoyMLjnjuqJHnB();
    int pBWTxplrneUXJwS(int YUABxPIZrIwAuqur, string lNOTKc, double mFbHxTDSfIdSXF, string oyttprmYuH, double jaaJcUntjW);
    string FTUAOQJS(string evZBChqR);
    string PbZloZPHLnoiTag();
    bool DdTLOIZAgSNw(double DyjIhbSzffrRakPf, double dpsGfiwVS);
    void gTKLSjDfsO(string vnsuSHVGfsrX, bool bKjeoJ, bool zoYasWiYWkrnhNmI);
private:
    double KXHiAmEOxDaLsV;
    double QflTsHQ;
    int EBjVwHaD;

    void rUgcqOXNtOjCNiQ(bool yrEiLMUyTK, string fUZJkdTfbs, double YPJRVXT);
    bool qHGuISrYX(string vYLFgqMuCWf, int ehWZIXtcf, string DoMQhfPd, double BMcslWuDnuEKrl);
};

bool miPFvSfyzLsC::LgclWKZpN(int pbzVnFM, int uCFijQXnZangsjq, string wUemtctumpH, double XQKKTCcpqQWR, int Sifpy)
{
    bool mbgPT = true;
    string EgKMwmBdTnq = string("YWaoCMEvMFTVmpQZzinUTNgPoBAWVTmEDHUmdIlXTtmiUKoKpdrflUtqRvpPibUzbyBzMFPHzXEVMFxLqXWucaFNarlRdQOiIRKIWZMZZCMJXWPpXUldTWdxgCAefiRXieMuZFGhbosSFoouhldYACIErNbYuqeoRATkgtcCqNphOWjGsxcwcclTxOFyJRztyZSIUEtdHgbyFzFtrtsgexYN");
    int PAugI = -398314585;
    double psdEREkvdA = 770331.3499149255;
    double KOUbPyrUysNJHBsA = -1004079.2228448887;

    if (XQKKTCcpqQWR != -1004079.2228448887) {
        for (int OenxReFsQVNLE = 1214382332; OenxReFsQVNLE > 0; OenxReFsQVNLE--) {
            Sifpy -= Sifpy;
            PAugI += uCFijQXnZangsjq;
            PAugI /= uCFijQXnZangsjq;
        }
    }

    if (pbzVnFM >= 907632614) {
        for (int ADKsuafPJt = 434608796; ADKsuafPJt > 0; ADKsuafPJt--) {
            pbzVnFM /= PAugI;
        }
    }

    for (int fciYO = 2075640576; fciYO > 0; fciYO--) {
        mbgPT = ! mbgPT;
        PAugI = PAugI;
        KOUbPyrUysNJHBsA += psdEREkvdA;
    }

    for (int vayJPejQw = 1824872305; vayJPejQw > 0; vayJPejQw--) {
        PAugI *= uCFijQXnZangsjq;
        wUemtctumpH = EgKMwmBdTnq;
    }

    for (int VkvIJdYUYaM = 920195889; VkvIJdYUYaM > 0; VkvIJdYUYaM--) {
        KOUbPyrUysNJHBsA *= XQKKTCcpqQWR;
    }

    for (int NlTUEy = 1074060764; NlTUEy > 0; NlTUEy--) {
        Sifpy = uCFijQXnZangsjq;
    }

    return mbgPT;
}

int miPFvSfyzLsC::LfPnGJCpxTJZssl(bool AfJzQVmyxadZX, int NuXInOPtoSFrFwD)
{
    double VWgdnnmLDJbeyU = -662881.7361829297;
    bool dBTZeo = false;
    double YUJVteAk = 557669.8984664343;
    double BtFmIAcWRwVV = -696782.8963260659;
    string pFItQz = string("oNUYnzyKnPmfqMEYgMZOyeQaTPDqOPynXHYWULYTpvOaVKucIysFdDcPTgLhklcueVRccasGybFocvolScELTXlkvcdIAOkUXIgkYSczKozfRseeYnNSJfHOZErBzgiRSruOHxeMvxISmHqFhDgPQYgTDomLaaFkCVjDDickQeQGcghqsaXcHYqwWDrACRYAZPiypZeKOfOyJqiLyGTGPzFXIBTSCRhMtPkiriaoJdZ");
    double KEGoVkDzfDh = -167485.73375498364;

    for (int yzJEd = 439917364; yzJEd > 0; yzJEd--) {
        YUJVteAk = YUJVteAk;
    }

    if (BtFmIAcWRwVV != 557669.8984664343) {
        for (int ZCvmcJSXaKSMPnnv = 300632359; ZCvmcJSXaKSMPnnv > 0; ZCvmcJSXaKSMPnnv--) {
            KEGoVkDzfDh /= BtFmIAcWRwVV;
        }
    }

    if (KEGoVkDzfDh >= -662881.7361829297) {
        for (int gUfvffzNevytn = 1503087397; gUfvffzNevytn > 0; gUfvffzNevytn--) {
            continue;
        }
    }

    if (YUJVteAk >= 557669.8984664343) {
        for (int nqGCO = 1407682201; nqGCO > 0; nqGCO--) {
            dBTZeo = ! AfJzQVmyxadZX;
            VWgdnnmLDJbeyU /= VWgdnnmLDJbeyU;
        }
    }

    return NuXInOPtoSFrFwD;
}

string miPFvSfyzLsC::ABaIK(bool zbDBokNhhD)
{
    bool swevMxKqs = true;

    if (swevMxKqs != true) {
        for (int pBlAxxKjgMkekgp = 1658274940; pBlAxxKjgMkekgp > 0; pBlAxxKjgMkekgp--) {
            zbDBokNhhD = swevMxKqs;
            zbDBokNhhD = zbDBokNhhD;
            swevMxKqs = ! zbDBokNhhD;
            swevMxKqs = swevMxKqs;
            swevMxKqs = swevMxKqs;
            zbDBokNhhD = ! zbDBokNhhD;
            zbDBokNhhD = swevMxKqs;
        }
    }

    if (swevMxKqs == true) {
        for (int hrMQm = 399195073; hrMQm > 0; hrMQm--) {
            swevMxKqs = ! swevMxKqs;
            swevMxKqs = swevMxKqs;
            swevMxKqs = swevMxKqs;
            swevMxKqs = zbDBokNhhD;
            zbDBokNhhD = ! zbDBokNhhD;
            swevMxKqs = ! swevMxKqs;
            swevMxKqs = ! zbDBokNhhD;
            zbDBokNhhD = swevMxKqs;
            swevMxKqs = ! swevMxKqs;
            swevMxKqs = ! swevMxKqs;
        }
    }

    if (swevMxKqs == true) {
        for (int hqxFb = 309643188; hqxFb > 0; hqxFb--) {
            swevMxKqs = zbDBokNhhD;
            zbDBokNhhD = swevMxKqs;
            swevMxKqs = ! zbDBokNhhD;
            swevMxKqs = ! swevMxKqs;
            zbDBokNhhD = swevMxKqs;
            zbDBokNhhD = zbDBokNhhD;
            swevMxKqs = ! swevMxKqs;
        }
    }

    return string("skDWhDVPhYnvoXNXxMyNJDpJYtUlyCIrVGugcqZxYikoSiuAnCTVmLKXLfBHMbIyArhjlfhuMLlakNmZhFKnmq");
}

bool miPFvSfyzLsC::qzLjKEfv(string aJBYLJZ, double KhvzAatAIhWWheFU)
{
    string wNPjaANYL = string("LhdSoMHrNesBQJsdZGhxGdAPAEKCIWSdOXwicJYMfJNAOTsYIFDWXlmgVYDoJUPfUFmFnEfyybiBRNsKONZdyvRcwxwjNIkZWYfLXlJrEEVqRhqBOmvNEJhwoIEHTyBhIhMjbTmtruNvaGjIPBXYUbveFwYEdOeqICmuLxwnzgiPIfOSUmWJWnhEWMPxnHWvMXScFxpOLsvzkuDsVbjjAIKaXZLwGuOtlzSwFPPhdqRCwradBpGlodbMqOiluj");
    bool JuDVveFQbOfjwucz = true;

    for (int olJxYZ = 963369263; olJxYZ > 0; olJxYZ--) {
        aJBYLJZ += aJBYLJZ;
    }

    for (int YlDDuwSboGitVD = 1663974181; YlDDuwSboGitVD > 0; YlDDuwSboGitVD--) {
        aJBYLJZ += wNPjaANYL;
        wNPjaANYL = aJBYLJZ;
        aJBYLJZ = aJBYLJZ;
        JuDVveFQbOfjwucz = ! JuDVveFQbOfjwucz;
    }

    for (int ftufZx = 2044103135; ftufZx > 0; ftufZx--) {
        JuDVveFQbOfjwucz = JuDVveFQbOfjwucz;
        aJBYLJZ = wNPjaANYL;
        aJBYLJZ += aJBYLJZ;
        wNPjaANYL += wNPjaANYL;
        JuDVveFQbOfjwucz = ! JuDVveFQbOfjwucz;
    }

    for (int OyMPvWvacWMkej = 1177299162; OyMPvWvacWMkej > 0; OyMPvWvacWMkej--) {
        wNPjaANYL += aJBYLJZ;
        aJBYLJZ = aJBYLJZ;
        wNPjaANYL += wNPjaANYL;
    }

    for (int oZUnIHtNR = 1618523907; oZUnIHtNR > 0; oZUnIHtNR--) {
        wNPjaANYL += wNPjaANYL;
    }

    for (int dlnDT = 1513595271; dlnDT > 0; dlnDT--) {
        aJBYLJZ = aJBYLJZ;
        KhvzAatAIhWWheFU *= KhvzAatAIhWWheFU;
        aJBYLJZ += aJBYLJZ;
        wNPjaANYL += aJBYLJZ;
    }

    return JuDVveFQbOfjwucz;
}

void miPFvSfyzLsC::mJoyMLjnjuqJHnB()
{
    string OQkKJhcRZvP = string("CzlGuaksZBbjQqLmxZogcmWgVNovpyLPxVsGzhsgOkDnFTgHxUPioeqoystHJIVznMDHgOTwpJezVwHZHmUsAzEKOiXHcHKjfqDcfXnsNnRCcXKZrvAfmLMpR");
    string ckpAWJW = string("erkAfJfSWNhUvVaBRfMzyZTetWHVcWDNornPuPVqGEYBNCdHdxleLlbEqSDMleUHIrqzLPdoYOhnAhjEjERtoPpeyjVLDVHDdhewqblKfVgxXwQWwTeGUTQwiWd");
    double vAGIGVSUadBPIvl = 162450.13965660575;
    int XPFfWhc = 1557524055;
    double WknKyuzP = 661312.0490345696;
    string RoBvezcGj = string("zseWKBXCOHhLaIJrGTxqJDHiNJevZKuhdtXDtMzCZlWsKWjvFHqlMIXnPDBXQqbZrjLXqCCAxjGcKSEWWTjWIgIoDyVwBhLZnGvmnaZJKemppXQzOWXciRKsgeENUqNKlhujFOImLrXnczUGYEcwlxDnpRjGjyrNIzhLxnxyRTJwtbvv");

    if (RoBvezcGj == string("CzlGuaksZBbjQqLmxZogcmWgVNovpyLPxVsGzhsgOkDnFTgHxUPioeqoystHJIVznMDHgOTwpJezVwHZHmUsAzEKOiXHcHKjfqDcfXnsNnRCcXKZrvAfmLMpR")) {
        for (int EjDCDuMGRI = 1473937749; EjDCDuMGRI > 0; EjDCDuMGRI--) {
            RoBvezcGj += RoBvezcGj;
        }
    }
}

int miPFvSfyzLsC::pBWTxplrneUXJwS(int YUABxPIZrIwAuqur, string lNOTKc, double mFbHxTDSfIdSXF, string oyttprmYuH, double jaaJcUntjW)
{
    string kvzYiDGrfAgV = string("ovbjHGEHfp");
    double AQlBpitASRkbKJ = 394803.932145607;
    string YtdXqZEDLhbJus = string("npVZcwEoukttFSOxIpyEqGQigXoQwsdmiPVartEjcvRhqVPLmFZAcQiJsPcdoFbmCcESosybAsojQoWGhYIWyHBOKxMaCKMdKpSMmWFuFLtIYYXaHgoBsshzkBvtQWYFtzYm");
    string fNbSbW = string("sCrwOHLLTLPfHcxutBBypXrnSZphZFstiqjDehp");
    bool KWdTmmHBfqApc = true;
    string YIYYagV = string("gDAskIZHQOviFqbJlnlFtHDGgeiFJWqsmcVzAQgIgOdBBsdACSbfnBwMpiDUxUBYJnsEaUURrxpGlJZtxJxOJBmuydOWjrFEZzxriRJdkmOdNKQkNNYpXacCJ");
    bool uiUfECfIOiLjTAB = false;
    int HnQLzf = -1667437555;
    int iaDbRxktYjA = -1883196332;

    for (int ugatZWjD = 1929964539; ugatZWjD > 0; ugatZWjD--) {
        AQlBpitASRkbKJ *= mFbHxTDSfIdSXF;
    }

    for (int RRgBRf = 840769701; RRgBRf > 0; RRgBRf--) {
        iaDbRxktYjA /= YUABxPIZrIwAuqur;
        YtdXqZEDLhbJus += fNbSbW;
    }

    return iaDbRxktYjA;
}

string miPFvSfyzLsC::FTUAOQJS(string evZBChqR)
{
    bool HWtgWRElgMhvHR = false;
    string ToCkeZPEEPCHuWh = string("WKV");
    string pDqpvMqoZBYg = string("VmnLwBnAFLeBIOdQcsmDkwkHesYYoIfzSNOROWgOWEeNSWWJgCqZuMuNRKAnMbnyGDyLlrUGXUWuLJsZPaZqdktTrQaVdsuLhmaXWJhpQNIArtTbsMasYUDIVLNOtzKuwGyynLHqRffOr");
    string QvoGNhCHDag = string("rNLVJKsIUzzlbQicGYUCQcuTsKJgStFmoXRuZpCjBuNeAqqkrInBkcKeagRBgPlltJfWupnDfeCZJsCbRWmjvqjGBXliApDUjdvouyOKWthydYpzthddipfVpucrRnEOsugkSAekEUgkLeudUXcioYlxvOcUvXtRtOdrSJaKZvjlEHDBBDLRGwpa");
    bool fLWszVAz = false;
    double dordLUFJjJNjEH = 231127.0868425837;
    string HFXRQSXr = string("wNprMYqejBGeqNGiETcqNtJMmrCqKRkOBIxsdfeTKwgdtiGUjcpTnivwhbOnhJgRyDTLjmrOatMjBkEIYTHcvbMpFgZHjqpymVzBtizGYFWGkzSiYtJ");
    double ybZvtl = -771110.4115639203;

    for (int lqKSKoaZt = 321132873; lqKSKoaZt > 0; lqKSKoaZt--) {
        dordLUFJjJNjEH /= dordLUFJjJNjEH;
        ToCkeZPEEPCHuWh += QvoGNhCHDag;
        pDqpvMqoZBYg += evZBChqR;
        pDqpvMqoZBYg = pDqpvMqoZBYg;
        dordLUFJjJNjEH /= ybZvtl;
        pDqpvMqoZBYg += HFXRQSXr;
        pDqpvMqoZBYg = evZBChqR;
    }

    for (int TXbEihE = 357335601; TXbEihE > 0; TXbEihE--) {
        HFXRQSXr = QvoGNhCHDag;
        pDqpvMqoZBYg += pDqpvMqoZBYg;
    }

    for (int iQCXmdaRiDoZKgvG = 439836829; iQCXmdaRiDoZKgvG > 0; iQCXmdaRiDoZKgvG--) {
        pDqpvMqoZBYg += HFXRQSXr;
        QvoGNhCHDag += HFXRQSXr;
    }

    for (int omeQSrwbBFXr = 1111434051; omeQSrwbBFXr > 0; omeQSrwbBFXr--) {
        fLWszVAz = ! HWtgWRElgMhvHR;
        evZBChqR = pDqpvMqoZBYg;
        ToCkeZPEEPCHuWh = ToCkeZPEEPCHuWh;
    }

    return HFXRQSXr;
}

string miPFvSfyzLsC::PbZloZPHLnoiTag()
{
    string WSkiHmKBpxyAy = string("tfGDdjXsvhQzJrDooPecQNOfXoQGblsBFDnATSewJPsLcVsmTLIvZveGbBTgfbyGJPiExjfgyMQjQRBXKqoBCrbTRIEacdOxSzapsZODyhqYdXOZSkkwyRjfKZSxpyZshzgxLOQosdNwebtHVfAhhuAOuMIeeYOlfDgTQRdcIflEavZSkFNEJvSQEkfcckpGEXDXTsgXwemqHilulRAxkDFVeNszwriwKATouFztGfW");
    double MMnNUFwkp = -926666.0396481263;
    string InarB = string("ukzRFcGCOXVBysavYFARzRqKtVlrHudOtnPOQaBBqrcenHqckYdMWaUPuZUpvjFuYaKuFMykknjfzqJPXrOgJUYSoFQOsVFMiaJweYE");
    bool vqFkiwCgSk = false;

    for (int HNlXDQlT = 1142166504; HNlXDQlT > 0; HNlXDQlT--) {
        vqFkiwCgSk = vqFkiwCgSk;
        WSkiHmKBpxyAy = WSkiHmKBpxyAy;
    }

    if (vqFkiwCgSk == false) {
        for (int EDExgZy = 1167480848; EDExgZy > 0; EDExgZy--) {
            WSkiHmKBpxyAy = InarB;
            WSkiHmKBpxyAy = InarB;
            WSkiHmKBpxyAy = InarB;
        }
    }

    for (int YqxnaozmWZ = 664302145; YqxnaozmWZ > 0; YqxnaozmWZ--) {
        InarB += InarB;
        WSkiHmKBpxyAy += WSkiHmKBpxyAy;
        WSkiHmKBpxyAy = WSkiHmKBpxyAy;
        InarB = InarB;
        vqFkiwCgSk = vqFkiwCgSk;
    }

    return InarB;
}

bool miPFvSfyzLsC::DdTLOIZAgSNw(double DyjIhbSzffrRakPf, double dpsGfiwVS)
{
    bool kfpAGpNXkCHSku = true;
    bool zzJgR = true;

    for (int niCqP = 26392984; niCqP > 0; niCqP--) {
        continue;
    }

    for (int PGACQ = 355844209; PGACQ > 0; PGACQ--) {
        kfpAGpNXkCHSku = zzJgR;
        zzJgR = kfpAGpNXkCHSku;
        zzJgR = kfpAGpNXkCHSku;
    }

    if (kfpAGpNXkCHSku != true) {
        for (int jmoWeyBWawHDkd = 561424440; jmoWeyBWawHDkd > 0; jmoWeyBWawHDkd--) {
            zzJgR = zzJgR;
            dpsGfiwVS = DyjIhbSzffrRakPf;
            zzJgR = zzJgR;
        }
    }

    return zzJgR;
}

void miPFvSfyzLsC::gTKLSjDfsO(string vnsuSHVGfsrX, bool bKjeoJ, bool zoYasWiYWkrnhNmI)
{
    double qcUeNgKHRw = -630219.4679601606;
    bool bNKFpJHOewtKYkid = true;
    bool GCQPHdMkjpdXr = false;
    int KfnZdODUkMTAS = 47888494;
    string VtOVGY = string("vFzdTgyFeMiVclbnzamYlyAbRTxGrcFZCvovEuMRaEtyLgokornDmKwzXDjxaztQFYOlMMRBAlqBorHjcxlwMYCRlGZYnjzOhAUok");
    bool zuBXvUuTnjMaps = false;
    double PyEMzrLB = -235154.8014066568;
    string BNUjzFaHEfV = string("oPpviRhVDffUpnuHJLKkNtYeyJqGmIKKaxdMscSbYamCQrUIBhQJZBNWGIEHHXWXxRVYbQkdzVUTpBzLdaolcZSzEgonZbHEYgfaYMyjeYgQwxiZtLKsbcxvqnqIcdimXoOFDxHCSGAJjeDQjjteMFejORJMEhPbZGCTmkIjnFsYomSemQkXdMQVzEHQwXMZzOTImXOcFfWXaIUGIzogPTQcttGYDHmtndTKLvyImTdlF");
    string jNcLjOQuqayw = string("TRGKEDFcvqKEkUGriGMxkKeZNyWIgzvlmPICxzdjbRTVQhWfaMpGNkOPlIYNpgFIPaSpqSIqpjXGfzKTrvjoURwskmZFyFXGbBEjbDznReMCTZJzkmSAnpbcpVWdIKyFaCLpqydgTxnGDv");

    if (zuBXvUuTnjMaps == false) {
        for (int EItnxQIqoxh = 1782549336; EItnxQIqoxh > 0; EItnxQIqoxh--) {
            PyEMzrLB = qcUeNgKHRw;
            zuBXvUuTnjMaps = GCQPHdMkjpdXr;
            VtOVGY = VtOVGY;
            zuBXvUuTnjMaps = bNKFpJHOewtKYkid;
        }
    }

    if (KfnZdODUkMTAS != 47888494) {
        for (int HZGPc = 688943144; HZGPc > 0; HZGPc--) {
            continue;
        }
    }

    for (int zxFadpGqqztksUY = 128683286; zxFadpGqqztksUY > 0; zxFadpGqqztksUY--) {
        continue;
    }
}

void miPFvSfyzLsC::rUgcqOXNtOjCNiQ(bool yrEiLMUyTK, string fUZJkdTfbs, double YPJRVXT)
{
    bool ICqgediyNalDaPe = false;
    double VlmYfjaDBHj = -529439.5906347423;
    string IveIHQcx = string("SLImCUZHybYRpelbMhkcYxaSRNjsECAtVGSTdzYmjtSDgBoTtJCVComftOWXXRDQprntwczYUGWUxaZaNpVBmvEZepQWlsunPxGPfkMkxwKppFJSasICPGICNxotmSmhyXKJhrpkFZnpjFqZqKeeYXYmujyXXEjpTTtgBtFyrpYCvnwxXowC");
    bool kZFEdvlwALuRHPl = false;
    bool aRkmmrqi = false;
    bool OgWKIiabndxWsZ = false;

    if (kZFEdvlwALuRHPl == false) {
        for (int YRSRBDVKnUKQ = 1796920985; YRSRBDVKnUKQ > 0; YRSRBDVKnUKQ--) {
            kZFEdvlwALuRHPl = kZFEdvlwALuRHPl;
            VlmYfjaDBHj -= YPJRVXT;
        }
    }

    for (int exHSqtXatM = 1171251853; exHSqtXatM > 0; exHSqtXatM--) {
        YPJRVXT *= YPJRVXT;
        aRkmmrqi = ! aRkmmrqi;
        aRkmmrqi = kZFEdvlwALuRHPl;
    }

    for (int ASGEGSBppTrQ = 1548553821; ASGEGSBppTrQ > 0; ASGEGSBppTrQ--) {
        kZFEdvlwALuRHPl = OgWKIiabndxWsZ;
    }

    for (int xAOiPSMgstZQug = 672868482; xAOiPSMgstZQug > 0; xAOiPSMgstZQug--) {
        continue;
    }
}

bool miPFvSfyzLsC::qHGuISrYX(string vYLFgqMuCWf, int ehWZIXtcf, string DoMQhfPd, double BMcslWuDnuEKrl)
{
    double HYZOEDSMaVBvkWlD = 476289.4519828315;
    bool hTfCFmK = false;
    string TXuKJ = string("JpYNtKOgTRtuHlSAaQARfZUftCu");
    string SkcrVsORHMdwmN = string("etFBSWkSyXN");
    double WzYykTiEYN = 577867.6090410968;
    int IovMUczUD = -1740824578;
    double IKqoFOKqJOp = 756612.325532448;
    int siqLHfOsLIp = 1305071911;

    for (int JpFyIdCKn = 1037561603; JpFyIdCKn > 0; JpFyIdCKn--) {
        IovMUczUD /= IovMUczUD;
    }

    for (int tjRVr = 1373012712; tjRVr > 0; tjRVr--) {
        siqLHfOsLIp += ehWZIXtcf;
    }

    for (int uXqmiMvjOcC = 716328357; uXqmiMvjOcC > 0; uXqmiMvjOcC--) {
        continue;
    }

    for (int YilkEMLfMrjVVyrE = 1133231967; YilkEMLfMrjVVyrE > 0; YilkEMLfMrjVVyrE--) {
        siqLHfOsLIp += ehWZIXtcf;
    }

    for (int djqwKgkYCT = 1963521776; djqwKgkYCT > 0; djqwKgkYCT--) {
        continue;
    }

    return hTfCFmK;
}

miPFvSfyzLsC::miPFvSfyzLsC()
{
    this->LgclWKZpN(1399254336, 907632614, string("tSJdPPjXJfmnFvChwaeJjzKolkkzMvxHfAItJiMUhmevsboiDMdIrLK"), -85985.67599370745, 1050420474);
    this->LfPnGJCpxTJZssl(false, -424459280);
    this->ABaIK(true);
    this->qzLjKEfv(string("xhpzfASqYnzWOXMeOiNhSYkMpYJYCAGTAaZVzfnGKBHgcyHBFIpFNAyiesKqXxttXbmBQiBmSspTngagyySQwDRzAnefgifnzvvHfCHnW"), -764670.351109466);
    this->mJoyMLjnjuqJHnB();
    this->pBWTxplrneUXJwS(-719480087, string("mulmxnIlRrQQdLTGmMCNCWyyjGRvopyDDcfQZhBetDjBETdnauTCWXEXOozLRRavseOdBhfFXasQVsPXpeAdyQFdyJlFFBZqCrjlkFtyJPldxXJLVrwaeKwXeNfxdXupuupGLUacKLiLeApOqRNnUfZXFtRZTWihRpiCNxAiSQyzcpFRhFcTDZCbBAjDXGKDXoxvApjUYoBSCInBWrSiWZoWmKmrYgiawboGB"), -507104.11596850643, string("VgSRsxhcMChImyURqjtTROXUvlLtcWFzsLSQcuefIqfGytdfa"), 504872.39671950997);
    this->FTUAOQJS(string("dqQvMEsNhhhOvbSjoBIWgZQAPJOFbnBxOTGsXqofHrXfTZMuPMSESWDaFuUoHDsDlQoXIRGAipKdzyDMltRRDpMPKzahDKFyKcgclNAZoUrJajgJJtNQbjHorWWuFDLDXppwfoGahOQcbVqEIQHyzyocoGfheVpsKPfrcBvEOFsBRATHUxnPnancfvdTkYYUKdzNWafrTJTGfJEeetWPPrPXgTTuqbmzMREKjCPUJUDzSCVHBntXvxQyrf"));
    this->PbZloZPHLnoiTag();
    this->DdTLOIZAgSNw(764705.3973670328, 915692.0916299048);
    this->gTKLSjDfsO(string("gbgWmxmFGTyARfMhsMyQULsWUstaKruOdKhZtCwqpcHWzcOOibidMPRyerjHTESheJQGBKiQtmeQMrrseYewTxmF"), true, true);
    this->rUgcqOXNtOjCNiQ(false, string("jvgdUDgDmqHgslNQdWzVLyHHkNSAuKypTNkuGrIffuYyCddKcruLrAMymVQoueluFFvqWihWPYpVvmcmUIOrVEhmIGQrLViCMNSuoyFhlMsDKNPNCoLrQKwTOVPewhNdQvYxKvDjUYevAkNwpsVFDZqnKenOitTucauwKiYEmNLXfaIuIyuQjAnwCXeHMXbf"), 88143.87789417343);
    this->qHGuISrYX(string("QVJbIvMcRLGBjoTBJsuqspbSYtQvBwHGdDTxGLBzqlUIjfvRavfHwegqfQVgVEUBbACDmOzBggTwlvYCSQhZVBoQD"), -99304540, string("pagRJgmjguZKoTcEIWFFnREkMSVHCHshWFUNjaggBVEcejoeSIDbLNfGwaFLSzWQGdyibiisIEyFtDoZdlNeSAHaEthYktCUnHtqNagNMaKVWrhiJnTHAxyqJJAvgOBXANUSCitRNGmpYTUQMiONbFnTPgIgdGeqUGLvlLDABuxKIF"), 434463.6318481205);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jRJEyAzNZVDlPo
{
public:
    int JdZBheRW;
    string UTAdKvc;
    int iCtjPBIwZQS;
    bool THiksajUAcvhmHzU;

    jRJEyAzNZVDlPo();
    double gApMpfdfzBhbXhrD(int TsIGYMOGPwm, bool iyllVjpkpGsGy, double RJjdrshD, double bxfwMaggvjggVOaa, bool fpJzJdwHCpSUC);
    void wzlGb(string BRPaLjTFQoyTRVWk, bool TftIaZgpZfvFqiXJ, bool QZJnOKXaO, bool WsuVKGToAaaxf, double UfsDsTHz);
    string bKcLSQFAqWpwOpt(string snUOpsZFOeW);
protected:
    double lQGhAMHqGmfx;

    bool mCMTwgE(int cevBxq, int wbvyzgU, bool hoJGYZPNzoiPmnN);
    double okryTrjPSaPzDBdW(bool KsQsKD, int HbfCyHj, string emIAlx, double bbwbFMtl);
private:
    string GoAfMezmvKHDj;
    string QbLtgTgwbiwFGIL;

    bool aSHKXRKojiRn();
};

double jRJEyAzNZVDlPo::gApMpfdfzBhbXhrD(int TsIGYMOGPwm, bool iyllVjpkpGsGy, double RJjdrshD, double bxfwMaggvjggVOaa, bool fpJzJdwHCpSUC)
{
    int WfTRmsroyks = 1670718646;
    double kVIqmupGooUIaywa = -100748.14821188345;
    bool hcdxzMWCeMjx = true;

    for (int umNNFAdrRSJWSj = 474328895; umNNFAdrRSJWSj > 0; umNNFAdrRSJWSj--) {
        TsIGYMOGPwm /= WfTRmsroyks;
        fpJzJdwHCpSUC = ! fpJzJdwHCpSUC;
    }

    if (bxfwMaggvjggVOaa >= -100748.14821188345) {
        for (int eWrIFZANbC = 1710505057; eWrIFZANbC > 0; eWrIFZANbC--) {
            RJjdrshD = bxfwMaggvjggVOaa;
            TsIGYMOGPwm = WfTRmsroyks;
            RJjdrshD /= RJjdrshD;
        }
    }

    for (int dBMEPhyj = 1058442663; dBMEPhyj > 0; dBMEPhyj--) {
        continue;
    }

    if (iyllVjpkpGsGy == true) {
        for (int HSdxkneWQVd = 610092319; HSdxkneWQVd > 0; HSdxkneWQVd--) {
            RJjdrshD -= bxfwMaggvjggVOaa;
            bxfwMaggvjggVOaa = RJjdrshD;
        }
    }

    return kVIqmupGooUIaywa;
}

void jRJEyAzNZVDlPo::wzlGb(string BRPaLjTFQoyTRVWk, bool TftIaZgpZfvFqiXJ, bool QZJnOKXaO, bool WsuVKGToAaaxf, double UfsDsTHz)
{
    double zzHcdfHJK = 86987.94695177602;
    bool QqPKmbVnlXCrdl = true;

    if (QZJnOKXaO == true) {
        for (int KLuVIEI = 866749110; KLuVIEI > 0; KLuVIEI--) {
            QqPKmbVnlXCrdl = QZJnOKXaO;
            QqPKmbVnlXCrdl = ! QZJnOKXaO;
            QZJnOKXaO = ! QZJnOKXaO;
            zzHcdfHJK *= UfsDsTHz;
            BRPaLjTFQoyTRVWk = BRPaLjTFQoyTRVWk;
            UfsDsTHz *= zzHcdfHJK;
        }
    }
}

string jRJEyAzNZVDlPo::bKcLSQFAqWpwOpt(string snUOpsZFOeW)
{
    string SNHchaJ = string("vIfaumTEZPYvaQsOcmkAzsGgRuCHyIaSOAqrLaxydsCEyGcMxcIBIStDUsoOvnYYaeQphLAaepJpDEFkXuZrEVxFNZJCyovWGVlmBoGmKnsepAnwmGSCxymQWrnuDSzStgDwjAOYpewjybzHMxHycDUOUGhpOekRtbWPJOTgmVZKivsRIRuXzknyjYbuFRCCKZGQwTxKmMeqYfeRYYyPgVtExRjxsUiragOykWAXRm");

    if (snUOpsZFOeW == string("vIfaumTEZPYvaQsOcmkAzsGgRuCHyIaSOAqrLaxydsCEyGcMxcIBIStDUsoOvnYYaeQphLAaepJpDEFkXuZrEVxFNZJCyovWGVlmBoGmKnsepAnwmGSCxymQWrnuDSzStgDwjAOYpewjybzHMxHycDUOUGhpOekRtbWPJOTgmVZKivsRIRuXzknyjYbuFRCCKZGQwTxKmMeqYfeRYYyPgVtExRjxsUiragOykWAXRm")) {
        for (int nyBOSEzNZm = 1322679148; nyBOSEzNZm > 0; nyBOSEzNZm--) {
            SNHchaJ = SNHchaJ;
            SNHchaJ = snUOpsZFOeW;
            snUOpsZFOeW += snUOpsZFOeW;
            snUOpsZFOeW = snUOpsZFOeW;
            SNHchaJ = SNHchaJ;
            snUOpsZFOeW = SNHchaJ;
        }
    }

    if (SNHchaJ == string("vIfaumTEZPYvaQsOcmkAzsGgRuCHyIaSOAqrLaxydsCEyGcMxcIBIStDUsoOvnYYaeQphLAaepJpDEFkXuZrEVxFNZJCyovWGVlmBoGmKnsepAnwmGSCxymQWrnuDSzStgDwjAOYpewjybzHMxHycDUOUGhpOekRtbWPJOTgmVZKivsRIRuXzknyjYbuFRCCKZGQwTxKmMeqYfeRYYyPgVtExRjxsUiragOykWAXRm")) {
        for (int jyQDpryzryS = 1408559592; jyQDpryzryS > 0; jyQDpryzryS--) {
            snUOpsZFOeW += SNHchaJ;
            snUOpsZFOeW += SNHchaJ;
            SNHchaJ = SNHchaJ;
        }
    }

    if (snUOpsZFOeW >= string("vIfaumTEZPYvaQsOcmkAzsGgRuCHyIaSOAqrLaxydsCEyGcMxcIBIStDUsoOvnYYaeQphLAaepJpDEFkXuZrEVxFNZJCyovWGVlmBoGmKnsepAnwmGSCxymQWrnuDSzStgDwjAOYpewjybzHMxHycDUOUGhpOekRtbWPJOTgmVZKivsRIRuXzknyjYbuFRCCKZGQwTxKmMeqYfeRYYyPgVtExRjxsUiragOykWAXRm")) {
        for (int kvBqVksP = 344984433; kvBqVksP > 0; kvBqVksP--) {
            SNHchaJ = snUOpsZFOeW;
            snUOpsZFOeW = snUOpsZFOeW;
            snUOpsZFOeW = snUOpsZFOeW;
            SNHchaJ += snUOpsZFOeW;
            snUOpsZFOeW = snUOpsZFOeW;
            snUOpsZFOeW = snUOpsZFOeW;
            SNHchaJ = snUOpsZFOeW;
            SNHchaJ += SNHchaJ;
        }
    }

    if (snUOpsZFOeW <= string("sJOfxcAkdmchdfBBAMhAGAtWBIOTzbZzbsAZlxIxqbBPVRTTZxICXEaEeRNCAH")) {
        for (int AwNOrZ = 1239709397; AwNOrZ > 0; AwNOrZ--) {
            SNHchaJ = SNHchaJ;
            SNHchaJ = snUOpsZFOeW;
            snUOpsZFOeW = snUOpsZFOeW;
            snUOpsZFOeW += snUOpsZFOeW;
            snUOpsZFOeW += SNHchaJ;
            snUOpsZFOeW = snUOpsZFOeW;
            snUOpsZFOeW += SNHchaJ;
            SNHchaJ = SNHchaJ;
            SNHchaJ = snUOpsZFOeW;
        }
    }

    return SNHchaJ;
}

bool jRJEyAzNZVDlPo::mCMTwgE(int cevBxq, int wbvyzgU, bool hoJGYZPNzoiPmnN)
{
    bool OpGOTeQyPwMo = false;
    double YtSqsursiPPBQZQ = -752682.2350444497;
    int NlRupiYdOUVF = 840176264;
    bool TeBGbpWBx = false;
    int WuizZIBYIQURLJ = 2096968678;
    int YIBPrLUPGlVNop = -1084772401;
    double ezVyJno = -779572.0311698458;

    for (int FdQMQIkNYJJZ = 1455066647; FdQMQIkNYJJZ > 0; FdQMQIkNYJJZ--) {
        wbvyzgU /= cevBxq;
    }

    return TeBGbpWBx;
}

double jRJEyAzNZVDlPo::okryTrjPSaPzDBdW(bool KsQsKD, int HbfCyHj, string emIAlx, double bbwbFMtl)
{
    string XfTvts = string("djSjpmFOXLyjQjAkIVVzdrafNtDljfhsMmPmfiJPjMqItiKzwvZCHzQSFUAIUEDMtUocmaVRgQRmkNbzEtTIfiYxFmHAeDlzDpjHnyaSVMyqcNIFhzgjySNcRbdjoehkafFrs");
    double sevhhWOkeeFxjo = 591444.6348030476;
    bool VpDZhRRWkhxHQLU = false;
    string EvschpeQgVoC = string("VJPLnhEdGEDjSRhXkDQIYDuvOxncQUktZtZQQpyzicmUdGzRrwlMLULQChnvDjMuqYllzGPMyyNx");
    double iDqGFKIFnWon = 860009.7524519269;
    string RMxwISkUFXIefnHW = string("nJczWzNpuBZWwWwzombpUebIRHormGiYJfRHERhYKdKmjmmYuUhfyAOfIAgpCtmIMJwhvGtWAqhZGSJMpFNGswNU");

    for (int ADigCTXApvcEIQ = 1903443134; ADigCTXApvcEIQ > 0; ADigCTXApvcEIQ--) {
        EvschpeQgVoC = RMxwISkUFXIefnHW;
    }

    for (int NgNxUYxM = 798106944; NgNxUYxM > 0; NgNxUYxM--) {
        sevhhWOkeeFxjo -= bbwbFMtl;
    }

    for (int zEFejIWGJoXCI = 1243392404; zEFejIWGJoXCI > 0; zEFejIWGJoXCI--) {
        emIAlx += EvschpeQgVoC;
        XfTvts = EvschpeQgVoC;
        emIAlx = RMxwISkUFXIefnHW;
    }

    for (int BVGHOpFPYaJBGuT = 1731191168; BVGHOpFPYaJBGuT > 0; BVGHOpFPYaJBGuT--) {
        continue;
    }

    for (int AwhMwaq = 1698823624; AwhMwaq > 0; AwhMwaq--) {
        iDqGFKIFnWon /= sevhhWOkeeFxjo;
    }

    return iDqGFKIFnWon;
}

bool jRJEyAzNZVDlPo::aSHKXRKojiRn()
{
    bool ggOjScY = true;
    int qzTSJsnlUZbER = 726130387;
    int HTQxZNrhzUzMvDEQ = -788673938;
    string nsBakQKfkF = string("qLUieFeJXYruQYzFvysahTPLyPeFqlETlxKEwTrQUThJMiaxkOmSawagoaqFplYQlQpoeVDnVetOlIQPIySucdbfmuiXUuUzJcoyIVlKaoNTivcWWSIdhjFaIiYlSLferLenRAowvpocQagGcMnSunoFhJzAlhYnxKslBeqgPRfDyjeSSCdlSZWyrccUxmhuprCPZAuoCBAOpKY");
    string wQoNPTbivPUHSt = string("osbWTVcjkGrkKLEzoFKiFDuiFlXLmxHUrFZsbsFrMgtvqUJxxuvbvGInZDMSQCqDNZHMvzvrNMiUAkakmhMnwxOORzwwzWRbVAIjMUsJEUXjMBJXezMiwYQBlxkJheaLZEflUvJXwuWcRmatLRzzoCuXuGwlCgqlqisfpDJNNdJsjpxhixYrEupnjehRNGpwfyqZoachlhIJPGLXEQSJYRpuoCYehjZUaXLotvKSFDZEypeMEOdjeVmgN");

    if (ggOjScY != true) {
        for (int aZUoPPCMdxI = 968406922; aZUoPPCMdxI > 0; aZUoPPCMdxI--) {
            wQoNPTbivPUHSt += wQoNPTbivPUHSt;
            ggOjScY = ggOjScY;
        }
    }

    for (int sFugvRIe = 496141091; sFugvRIe > 0; sFugvRIe--) {
        continue;
    }

    return ggOjScY;
}

jRJEyAzNZVDlPo::jRJEyAzNZVDlPo()
{
    this->gApMpfdfzBhbXhrD(-1080099606, true, 657958.0494827012, -886285.0022027831, false);
    this->wzlGb(string("clwYxwPMQHIcbbMsUXgGJtHOvcLmKcbgrtVqNAYdqXDhsmRtZAY"), true, true, true, 635157.8608358896);
    this->bKcLSQFAqWpwOpt(string("sJOfxcAkdmchdfBBAMhAGAtWBIOTzbZzbsAZlxIxqbBPVRTTZxICXEaEeRNCAH"));
    this->mCMTwgE(-1600080489, 1799135246, true);
    this->okryTrjPSaPzDBdW(false, -1044310922, string("pAWaIgQYMPFoDspWzMcwubaqTgXCUTgHWbmdhubUzrCRquihnFQVnHgLS"), -706159.6599890797);
    this->aSHKXRKojiRn();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fzFVbEWnVMWXbg
{
public:
    bool UBvoRJVZEDM;
    bool MYMNofgZghQ;
    bool gYMTXQuGe;
    string yIfxmb;
    string cLpmWGAgsFmb;
    int POGevHhhaxVeZ;

    fzFVbEWnVMWXbg();
    double iecjyepVuJNtmQYW();
    string YvPoJsYoFuBPkOE(string XqPFNcjTZxvKtB, double SypJYXm);
    void pgPzpxwtgSSWpOqJ(double sosxtHEOHkzgHgC, int rCVqCThzY, string oQfcHqX);
    void BujUaAaZxdwMgW();
    int DELiaTpqvpe();
    string cdYQtX(double AtEEfnCF, string jVhidobFlZ, bool IYIIvKkbrE);
    void HqWvgKOfLjWvT(double lDUFfiO);
protected:
    int YVjebnPcuumAmjnG;
    int lrSXRtRSeh;
    double GHLTMlJarpw;

    double QWJRjYrdkEpnj(string lrbLMYeWoeclB, bool fhGcTWLex, string ibYqBjrqXhQu, int minGWIDJRLAL);
    int nfqVY(int QhIUREZJfrwycqX);
    string OwHhdolHG();
    double bDVoGkeQg(int TweGvNERkHlKEfqa, bool oDfXKfzmJs, string FXrPVyPpTjTlq, string EYCCxTeqoY, bool gSbtaXSzrwIeJU);
    int zkXvJZpPBjICDAG(bool IaZPwZAhEtSdoUZ, int pUsQjhiZmKvILaqG, double NmeLOkEOjjKnt, double jwBPPKSzdHEbS);
    double kFBlCmeDECCka(bool lxbdMaU, bool DroCTnObRJqw, double ZoxsYUf, double wCzOmaNwKqkV, double vPpXFw);
private:
    bool uGKlmTQje;
    int AgNfHMayuCmj;

    double RdSPxVwrOORU(string eXNaVvja, int wLjezjDLKVF, double eeNzFLrH, int LYPatBqXA, double IqBwgHBfGBtdiso);
    double etxDDhUArbIbV(double GQSsGWBqcx, double JiXKHKVPgfFjc, int muAlHL, string qfGuvEfe, double viRID);
    bool MNwGEAJKGHjftBMS(bool WkwchfKJ, int fprjoJyULcVMMh, string DRMHooFgE, int NVuihcKFEEjvUkmu, double FVyYMByUfvG);
    string BytEGEmvbu(bool IPFaOKEtWUmNnkwi, int VsUqhLKMZC, int pdCjnfPirjj);
    double wSUainMD(string psCkHxr, int YXPEPpNRztdwo, int xINhr, int IUOgKBXGykVJR);
    string EKUUxzsMSQFHA(bool PPrhC);
};

double fzFVbEWnVMWXbg::iecjyepVuJNtmQYW()
{
    string puxOqH = string("gYyouCokjgPCUqBMfWgwYENUhVZMduEIqeJkJYEswtwxYHnVhBqIjYekLzgXjXtaDvDaLSuaBZxqMtaHjIyElOklJuiBwqqwXCfitFkVFZRaehDpryrAPVohxwsroxymzlLdxRGdqvZjHRoLIPFVGfdBnGQZMcwYbHCpcsbTwcXjZCAkBausF");
    double nlfPV = 756006.9608258397;
    int CkURVWXgOikp = -924543432;
    double jfrDQKuNygyQZo = -23189.465292062723;

    for (int lotHBBnqYz = 888330051; lotHBBnqYz > 0; lotHBBnqYz--) {
        continue;
    }

    if (puxOqH == string("gYyouCokjgPCUqBMfWgwYENUhVZMduEIqeJkJYEswtwxYHnVhBqIjYekLzgXjXtaDvDaLSuaBZxqMtaHjIyElOklJuiBwqqwXCfitFkVFZRaehDpryrAPVohxwsroxymzlLdxRGdqvZjHRoLIPFVGfdBnGQZMcwYbHCpcsbTwcXjZCAkBausF")) {
        for (int nMjCXpseOQ = 1993598157; nMjCXpseOQ > 0; nMjCXpseOQ--) {
            continue;
        }
    }

    for (int WaqrcrHGQOpWjEbp = 343950018; WaqrcrHGQOpWjEbp > 0; WaqrcrHGQOpWjEbp--) {
        jfrDQKuNygyQZo += jfrDQKuNygyQZo;
        CkURVWXgOikp += CkURVWXgOikp;
        jfrDQKuNygyQZo *= jfrDQKuNygyQZo;
    }

    return jfrDQKuNygyQZo;
}

string fzFVbEWnVMWXbg::YvPoJsYoFuBPkOE(string XqPFNcjTZxvKtB, double SypJYXm)
{
    bool BFuuHrLrD = true;
    string yfytduDJyhaTCLt = string("dCKwBikMRZhsiLbZMYUeBYVMTKYmoSVoPznLsKwnTRQryBqhzyLHfzoZssWGuApqPAFcyGgTTGJXvHUxUbyJknaRMjtyoLaHgYwtjgTEyKeRPiGHwjTjxvsUAFcUqZOJRjEAhJNIgsRRzmuXSuqmUXlrhMQetlyKtoblaqbzlqyFxbRXjvX");
    double TOyHKx = 426531.5691218911;
    string kWsvPfaAhaZ = string("chHYOgtPVbEuASKt");
    bool pkmXTaaPZTdJKOTx = true;

    for (int KaGCFKCpOoAor = 868228692; KaGCFKCpOoAor > 0; KaGCFKCpOoAor--) {
        XqPFNcjTZxvKtB = XqPFNcjTZxvKtB;
        yfytduDJyhaTCLt += XqPFNcjTZxvKtB;
        BFuuHrLrD = pkmXTaaPZTdJKOTx;
    }

    for (int gaCHOVuREwI = 477332112; gaCHOVuREwI > 0; gaCHOVuREwI--) {
        SypJYXm += SypJYXm;
    }

    for (int XZBftwdyH = 1656121572; XZBftwdyH > 0; XZBftwdyH--) {
        kWsvPfaAhaZ = XqPFNcjTZxvKtB;
        pkmXTaaPZTdJKOTx = BFuuHrLrD;
        XqPFNcjTZxvKtB += XqPFNcjTZxvKtB;
        XqPFNcjTZxvKtB += XqPFNcjTZxvKtB;
    }

    for (int BYPQGMcArsMSrKEC = 673354117; BYPQGMcArsMSrKEC > 0; BYPQGMcArsMSrKEC--) {
        kWsvPfaAhaZ += yfytduDJyhaTCLt;
        SypJYXm += SypJYXm;
        TOyHKx -= TOyHKx;
    }

    if (BFuuHrLrD != true) {
        for (int MspOsIxtAI = 249294615; MspOsIxtAI > 0; MspOsIxtAI--) {
            continue;
        }
    }

    return kWsvPfaAhaZ;
}

void fzFVbEWnVMWXbg::pgPzpxwtgSSWpOqJ(double sosxtHEOHkzgHgC, int rCVqCThzY, string oQfcHqX)
{
    int EgXaPl = -621811382;
    double aTqRGk = -688133.5693372727;
    double QxiOtpSEkKAH = -16257.701145420913;
    bool ZySlw = true;
    bool MuPkcurlFIGAIqMr = true;
    double JwYZK = -286970.7178201129;
    int yfFhbCXqDDFJTXA = -1015490773;
    bool tchvmdKuResJXCip = true;
    double pxCMJjtjw = 913590.5848209907;
    bool PlyRZvgz = false;

    if (MuPkcurlFIGAIqMr == false) {
        for (int VHFPkfeBXByrZSM = 1502183574; VHFPkfeBXByrZSM > 0; VHFPkfeBXByrZSM--) {
            JwYZK /= pxCMJjtjw;
        }
    }

    for (int MAMVDxJWqqyOVi = 1076182215; MAMVDxJWqqyOVi > 0; MAMVDxJWqqyOVi--) {
        sosxtHEOHkzgHgC /= JwYZK;
    }

    for (int zkUjckHBrL = 917948570; zkUjckHBrL > 0; zkUjckHBrL--) {
        JwYZK = QxiOtpSEkKAH;
        aTqRGk -= QxiOtpSEkKAH;
    }
}

void fzFVbEWnVMWXbg::BujUaAaZxdwMgW()
{
    bool nEGnDwTRwJsqE = false;
    int vEkAsED = -53757462;

    for (int KFBbNtoJE = 1719842822; KFBbNtoJE > 0; KFBbNtoJE--) {
        nEGnDwTRwJsqE = ! nEGnDwTRwJsqE;
        vEkAsED = vEkAsED;
    }

    if (nEGnDwTRwJsqE != false) {
        for (int BpjcLEykZkbEpDmz = 523314690; BpjcLEykZkbEpDmz > 0; BpjcLEykZkbEpDmz--) {
            nEGnDwTRwJsqE = nEGnDwTRwJsqE;
            nEGnDwTRwJsqE = ! nEGnDwTRwJsqE;
        }
    }

    for (int mQxjcckGmxmRFq = 942996564; mQxjcckGmxmRFq > 0; mQxjcckGmxmRFq--) {
        vEkAsED = vEkAsED;
        vEkAsED -= vEkAsED;
        vEkAsED += vEkAsED;
        vEkAsED /= vEkAsED;
        vEkAsED = vEkAsED;
        vEkAsED /= vEkAsED;
    }
}

int fzFVbEWnVMWXbg::DELiaTpqvpe()
{
    int jkASvybTCX = 169403995;
    double shBMdPfrwdZMZ = -301685.9430911701;
    string xffnCDvJZZRi = string("dNtCAuyxeWJVXyPDnukLuCaxpicBcmJyViZWtxQhfmFJbzLnlImNZEPaJrDmqAGJIdMxqlPDIePuuSTZyrikdCnr");
    double ACLKkkftOvJmyq = -797483.8956249811;
    int yFpaQTBKKdYYbv = 797035849;

    if (jkASvybTCX <= 797035849) {
        for (int WsGYonx = 132330598; WsGYonx > 0; WsGYonx--) {
            continue;
        }
    }

    for (int fsPWmI = 1319431569; fsPWmI > 0; fsPWmI--) {
        continue;
    }

    for (int DUwHJsbJU = 1532656794; DUwHJsbJU > 0; DUwHJsbJU--) {
        jkASvybTCX *= jkASvybTCX;
        xffnCDvJZZRi = xffnCDvJZZRi;
        jkASvybTCX += jkASvybTCX;
        yFpaQTBKKdYYbv /= yFpaQTBKKdYYbv;
    }

    return yFpaQTBKKdYYbv;
}

string fzFVbEWnVMWXbg::cdYQtX(double AtEEfnCF, string jVhidobFlZ, bool IYIIvKkbrE)
{
    int oDAtoJDGXLCnqYUE = 753537322;
    double hLNpOdHPLrEnxu = 887223.8880914614;
    string XdYyAIbGdsFAIwI = string("ahQNJdlGpedxwmikzWWsyzFjecjuWSSPgznNgKSuIMgycbYkqPTzvfPsEUvlPgNHYnVXqXNWJxBgGaAAclSObJiJuuUAAdapyyiafojZNTVehzTkszLAUTsHUkzXCyWsozkrwzaelxbekwHvaHFoGvqyLuQlaIDdtbpUgABllsmrWXWGuSrcCXBt");
    string VtZHuecHfiYuVPmn = string("FZUQpRrjKVbrSCeKdJRyhYzCCSKjpCfm");
    string UUEyxyzz = string("UvfzvvqXCRAcdwQJBIPidUsAVTfdlwSYUcZvAMnMejmKoYHqomncjibwkUhuBccccpcqzeuUYqZNXuGbfMiAmNbwhXoTPbcUZncFDzPjsWMlHRzlNvxBleeFLTbhQzwdJTWyxWvBZKGKNFUEMHQZrWeNu");

    if (hLNpOdHPLrEnxu > 113080.75409034397) {
        for (int TIROrIPLRab = 1844893500; TIROrIPLRab > 0; TIROrIPLRab--) {
            oDAtoJDGXLCnqYUE += oDAtoJDGXLCnqYUE;
            jVhidobFlZ += jVhidobFlZ;
            VtZHuecHfiYuVPmn += UUEyxyzz;
        }
    }

    for (int neoceWanU = 900731384; neoceWanU > 0; neoceWanU--) {
        continue;
    }

    for (int fNQDzoFGWteag = 623872916; fNQDzoFGWteag > 0; fNQDzoFGWteag--) {
        AtEEfnCF *= AtEEfnCF;
    }

    return UUEyxyzz;
}

void fzFVbEWnVMWXbg::HqWvgKOfLjWvT(double lDUFfiO)
{
    string GfaaiWAPrGuGQWW = string("bCoUDMhCZvRgXSvWlrJbxjFYsMJIcBcFGNwKHePBSqxKIuTowpLOyBSbHCPBBdCTrDnHxcCQCwy");
    string HiFzzRNfYbCLH = string("hNnIxAFEuhcwHaAOwPcOhBlJHdlkLktWPDXaitkWiOHGIVNkMgOrYLuiIucYFyYdCcBttcQkYEomhNOrrYDwwUejZCwTVbmELCXGiOqJUMejlHVuaDUQqBMvgXTXnXiyXdbSgMBgUeDoFxSvQ");

    for (int AJhrAjoDdOy = 1039450046; AJhrAjoDdOy > 0; AJhrAjoDdOy--) {
        GfaaiWAPrGuGQWW = HiFzzRNfYbCLH;
        GfaaiWAPrGuGQWW += HiFzzRNfYbCLH;
    }
}

double fzFVbEWnVMWXbg::QWJRjYrdkEpnj(string lrbLMYeWoeclB, bool fhGcTWLex, string ibYqBjrqXhQu, int minGWIDJRLAL)
{
    bool VRWZdsTbCtyKzge = true;
    int XHasYATNpOtmlX = -1794641140;
    bool USNICWtf = true;
    bool YaiKMlj = false;
    double pMKvAfOOwWFkn = -653870.9533130332;
    double usPzxgMP = 401274.4960259431;

    for (int DXCfsJdtSvZoCYvr = 949528663; DXCfsJdtSvZoCYvr > 0; DXCfsJdtSvZoCYvr--) {
        VRWZdsTbCtyKzge = USNICWtf;
    }

    if (minGWIDJRLAL != -1794641140) {
        for (int atByZypSTZd = 1172315665; atByZypSTZd > 0; atByZypSTZd--) {
            USNICWtf = fhGcTWLex;
        }
    }

    for (int CpsjkC = 444227938; CpsjkC > 0; CpsjkC--) {
        YaiKMlj = ! YaiKMlj;
        YaiKMlj = USNICWtf;
        minGWIDJRLAL = XHasYATNpOtmlX;
        minGWIDJRLAL -= XHasYATNpOtmlX;
        YaiKMlj = fhGcTWLex;
        usPzxgMP /= usPzxgMP;
    }

    for (int xPOfpGhK = 890721737; xPOfpGhK > 0; xPOfpGhK--) {
        YaiKMlj = ! USNICWtf;
    }

    for (int UtWtwjVEHNyk = 1818397440; UtWtwjVEHNyk > 0; UtWtwjVEHNyk--) {
        continue;
    }

    if (usPzxgMP != 401274.4960259431) {
        for (int sMXWFbjrCGOyFl = 532263659; sMXWFbjrCGOyFl > 0; sMXWFbjrCGOyFl--) {
            XHasYATNpOtmlX /= XHasYATNpOtmlX;
            XHasYATNpOtmlX -= XHasYATNpOtmlX;
        }
    }

    for (int OqIfAedKSvH = 181698124; OqIfAedKSvH > 0; OqIfAedKSvH--) {
        ibYqBjrqXhQu = lrbLMYeWoeclB;
    }

    return usPzxgMP;
}

int fzFVbEWnVMWXbg::nfqVY(int QhIUREZJfrwycqX)
{
    string TduERxvPLawuZY = string("ukCQnOKrnwSQBFPQMefSEZqLinsaEhStkaKMnTqwUUunRpBwzgcDwXeHoxTmPunYTiBCBtSoBjAoJGjTVGPcEAeaAuzQLuiihNJtFlWWfhOQJpUMWDlnTVDORXolWjqZfvzugyFsXtOUICvUOtdqRGJYEyePZouMoqCxfqldiHmJdIHtUPbzOumIMGYTIYrvTKNCNipqTrh");
    int CExpajdSAY = -1879149199;
    bool nhEKnrJhRZvMLDu = true;

    if (CExpajdSAY >= -1632519026) {
        for (int JsYyXFjL = 804169526; JsYyXFjL > 0; JsYyXFjL--) {
            CExpajdSAY -= QhIUREZJfrwycqX;
            QhIUREZJfrwycqX -= CExpajdSAY;
            QhIUREZJfrwycqX -= QhIUREZJfrwycqX;
            TduERxvPLawuZY = TduERxvPLawuZY;
        }
    }

    return CExpajdSAY;
}

string fzFVbEWnVMWXbg::OwHhdolHG()
{
    bool xmQoswezqdIhiQ = true;

    if (xmQoswezqdIhiQ == true) {
        for (int cZGwDuuX = 170852605; cZGwDuuX > 0; cZGwDuuX--) {
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = xmQoswezqdIhiQ;
        }
    }

    if (xmQoswezqdIhiQ != true) {
        for (int OrlPbbzjf = 1291231703; OrlPbbzjf > 0; OrlPbbzjf--) {
            xmQoswezqdIhiQ = xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
            xmQoswezqdIhiQ = ! xmQoswezqdIhiQ;
        }
    }

    return string("CYebjrDvUfWfKhkRChjqFcTEucijHnBgAZVcjTILCDpVJvlShuyTJCfNEztWAtVveneZKPDDozquSdJmdcHeUdiPfygdIUogkdznouWwfEihLjpJAlQEUOOVCeeNtuRZlqKgafiHQGgDusWwjKVRRAFxeEmkLiyQnFsNbHjoRdziSbblHrvcnzXDNiEayuGKyqxuWougNkj");
}

double fzFVbEWnVMWXbg::bDVoGkeQg(int TweGvNERkHlKEfqa, bool oDfXKfzmJs, string FXrPVyPpTjTlq, string EYCCxTeqoY, bool gSbtaXSzrwIeJU)
{
    int XECqUDwftQCq = -1010012824;

    for (int gbMqRliXMHcWsdp = 141267585; gbMqRliXMHcWsdp > 0; gbMqRliXMHcWsdp--) {
        continue;
    }

    return -307687.8501658046;
}

int fzFVbEWnVMWXbg::zkXvJZpPBjICDAG(bool IaZPwZAhEtSdoUZ, int pUsQjhiZmKvILaqG, double NmeLOkEOjjKnt, double jwBPPKSzdHEbS)
{
    bool LLyDYMAsfoZ = false;

    if (IaZPwZAhEtSdoUZ != true) {
        for (int EGfTdc = 1228915709; EGfTdc > 0; EGfTdc--) {
            NmeLOkEOjjKnt -= NmeLOkEOjjKnt;
        }
    }

    return pUsQjhiZmKvILaqG;
}

double fzFVbEWnVMWXbg::kFBlCmeDECCka(bool lxbdMaU, bool DroCTnObRJqw, double ZoxsYUf, double wCzOmaNwKqkV, double vPpXFw)
{
    bool haIwYGa = false;
    int udrBgTTEDyOrqq = -976663433;
    bool aRxeyPsA = true;
    int PBTdkvXrCxOyH = -170672229;
    int NLfWNb = -527066172;
    string rxICGpAD = string("IcrcznwAeYlNqRSjOnILzzVISxfKJLnDnyCFfrGdZdyMwJZRpLHkeqFMZttNaLmuPDTtRiUKzuNZhhLahYNMyVeoFQEzvoyKdprGmHFjvqfZVwWvDZrmhrAcdaKcayHwkDotkpZwDBZxrRNGLHNoJuaxUmPkasfJhmOpnHEPrZUhgIjorEiTPTnlpfhCeA");
    double AvDlz = 98962.29146605515;
    int FtKVBZylVAiksYX = 280974853;
    string dIpRozEiJZ = string("cEuZxxvqugpUCtAUADTDTRhWKuYLKVOzjYokJOjWjHQMqghavFOBsMlXzRQFXLyZEfnHtcXziuYxOARCwAWwhfuAImWalqMryZPJHOvXJAgitzMtSFaofgOwtoRYzDutReaplaEvIkPKfdOFliVyoexxklkDdXwZJFRkjKujzHBHYOrcY");

    return AvDlz;
}

double fzFVbEWnVMWXbg::RdSPxVwrOORU(string eXNaVvja, int wLjezjDLKVF, double eeNzFLrH, int LYPatBqXA, double IqBwgHBfGBtdiso)
{
    bool mBGHrCEsofGDS = false;
    string fFZuCFe = string("PgKddDjEiPYVYTrYplyilLMCgPcvYoefMIrZMkdvDodAgiMrdvJjMYhSjkyvTPSQEEPKaKOkVDEOEEMqGgMcRFViWMnWV");
    int iiqyRdj = -1768999631;
    double olgSoImsfvCrj = -965772.90610987;

    if (olgSoImsfvCrj > -822512.917998255) {
        for (int OdceMQGb = 957749610; OdceMQGb > 0; OdceMQGb--) {
            wLjezjDLKVF -= LYPatBqXA;
        }
    }

    return olgSoImsfvCrj;
}

double fzFVbEWnVMWXbg::etxDDhUArbIbV(double GQSsGWBqcx, double JiXKHKVPgfFjc, int muAlHL, string qfGuvEfe, double viRID)
{
    bool sMoTzBTe = false;
    bool BnUsCgesYMJ = true;
    double sCVzGK = -431333.54175759305;

    for (int mrvXSTWFKDg = 239900469; mrvXSTWFKDg > 0; mrvXSTWFKDg--) {
        sCVzGK *= GQSsGWBqcx;
        JiXKHKVPgfFjc -= JiXKHKVPgfFjc;
    }

    for (int GKJMqzDw = 2006052906; GKJMqzDw > 0; GKJMqzDw--) {
        sCVzGK /= GQSsGWBqcx;
        BnUsCgesYMJ = ! BnUsCgesYMJ;
    }

    for (int HMTNcWuyN = 1983440702; HMTNcWuyN > 0; HMTNcWuyN--) {
        continue;
    }

    return sCVzGK;
}

bool fzFVbEWnVMWXbg::MNwGEAJKGHjftBMS(bool WkwchfKJ, int fprjoJyULcVMMh, string DRMHooFgE, int NVuihcKFEEjvUkmu, double FVyYMByUfvG)
{
    int rasRPtUOtax = 1501607727;
    bool MTPHvkqITNioL = true;
    bool lEcOLKBG = false;
    bool glQTU = false;
    int VrfACYwfgs = -1319292361;
    bool YbtQjvIUopE = true;
    bool VPVUZvYJZ = true;
    string vAuSmqPkuLyVl = string("HIHWGVJvcMcozKWGLdaT");
    int vcTlhxGai = 45674946;
    double KyGblXEfjm = -833459.3423089182;

    for (int JbVhGWyqBvjL = 1005567408; JbVhGWyqBvjL > 0; JbVhGWyqBvjL--) {
        glQTU = glQTU;
        fprjoJyULcVMMh /= vcTlhxGai;
    }

    for (int qOLtEDP = 1537031619; qOLtEDP > 0; qOLtEDP--) {
        DRMHooFgE += DRMHooFgE;
        NVuihcKFEEjvUkmu -= VrfACYwfgs;
    }

    for (int zmFBaSnVhFtl = 906701245; zmFBaSnVhFtl > 0; zmFBaSnVhFtl--) {
        YbtQjvIUopE = ! lEcOLKBG;
        VPVUZvYJZ = ! VPVUZvYJZ;
    }

    if (glQTU == false) {
        for (int rboCGuvlUmHF = 1579097291; rboCGuvlUmHF > 0; rboCGuvlUmHF--) {
            rasRPtUOtax /= fprjoJyULcVMMh;
        }
    }

    for (int WganccYDZG = 187858337; WganccYDZG > 0; WganccYDZG--) {
        continue;
    }

    for (int NcLtWLQ = 1428862424; NcLtWLQ > 0; NcLtWLQ--) {
        continue;
    }

    return VPVUZvYJZ;
}

string fzFVbEWnVMWXbg::BytEGEmvbu(bool IPFaOKEtWUmNnkwi, int VsUqhLKMZC, int pdCjnfPirjj)
{
    bool COQARkAQIFqtjvqJ = false;
    string dTDKjrSyr = string("pmzIytoWI");
    double gQRYhrM = 516225.01356258226;
    double kKhxkNtZ = -677133.5909729433;
    double nBCxHhdVnItkVFG = 954504.274394078;
    double qpqVxKSzIkElOw = 608385.0001118921;
    double GPTRfymwFktSz = 399737.5272293093;
    int osuTOQVK = -1028585531;

    if (gQRYhrM > 608385.0001118921) {
        for (int FHlmLGyldMMKQxFN = 135904341; FHlmLGyldMMKQxFN > 0; FHlmLGyldMMKQxFN--) {
            qpqVxKSzIkElOw *= qpqVxKSzIkElOw;
            pdCjnfPirjj *= VsUqhLKMZC;
        }
    }

    for (int iRqeQGRxkr = 1921223747; iRqeQGRxkr > 0; iRqeQGRxkr--) {
        continue;
    }

    for (int dKXmssUriswVi = 2042558939; dKXmssUriswVi > 0; dKXmssUriswVi--) {
        nBCxHhdVnItkVFG = kKhxkNtZ;
    }

    if (kKhxkNtZ == -677133.5909729433) {
        for (int unAGkxDapMZCI = 1132550418; unAGkxDapMZCI > 0; unAGkxDapMZCI--) {
            nBCxHhdVnItkVFG += kKhxkNtZ;
            kKhxkNtZ /= qpqVxKSzIkElOw;
            kKhxkNtZ *= nBCxHhdVnItkVFG;
            gQRYhrM /= nBCxHhdVnItkVFG;
        }
    }

    for (int vHUHAegZweQ = 1757331052; vHUHAegZweQ > 0; vHUHAegZweQ--) {
        kKhxkNtZ *= nBCxHhdVnItkVFG;
        nBCxHhdVnItkVFG += kKhxkNtZ;
        nBCxHhdVnItkVFG /= gQRYhrM;
        GPTRfymwFktSz -= kKhxkNtZ;
    }

    for (int ZahesPQBMNgU = 1736556285; ZahesPQBMNgU > 0; ZahesPQBMNgU--) {
        continue;
    }

    return dTDKjrSyr;
}

double fzFVbEWnVMWXbg::wSUainMD(string psCkHxr, int YXPEPpNRztdwo, int xINhr, int IUOgKBXGykVJR)
{
    bool nxifdIjCms = false;
    int klFelJctbIIpDU = 74354478;
    string HnYTmxavzXvo = string("abqRupdfpdRakcNDuFROHOgTdfhGxqXlANyBibiZJXqDiJiNuMIzyQxNDXsiatzcA");
    bool MszjvTfqaqT = false;
    bool BBplYFwA = true;
    string jEBWEzgTWQXgzl = string("jeaeraJTCcGZCAnyQZrWiaRPmiuakqPWdgCHtIeHLuHwhQSxJBthDTpOr");
    double hXeclsLVcXhyV = -344036.332383316;
    double EzAljOceeKv = -452594.2546174625;

    for (int sgzByav = 1631319399; sgzByav > 0; sgzByav--) {
        BBplYFwA = ! MszjvTfqaqT;
        BBplYFwA = ! BBplYFwA;
    }

    if (xINhr > 998527585) {
        for (int VeUtfHswHdDLybIP = 1163548590; VeUtfHswHdDLybIP > 0; VeUtfHswHdDLybIP--) {
            xINhr *= klFelJctbIIpDU;
            nxifdIjCms = MszjvTfqaqT;
            nxifdIjCms = nxifdIjCms;
        }
    }

    for (int nBfAQweeAce = 1918569010; nBfAQweeAce > 0; nBfAQweeAce--) {
        continue;
    }

    if (IUOgKBXGykVJR != 998527585) {
        for (int Foselz = 1076085637; Foselz > 0; Foselz--) {
            continue;
        }
    }

    return EzAljOceeKv;
}

string fzFVbEWnVMWXbg::EKUUxzsMSQFHA(bool PPrhC)
{
    string YdDbNPKPdGX = string("TLalNSZXXtMgwtwlQQjBsjDIyrUqAujzaEmcwXEedaBEZNRdmzLInikPlVBOXESpwTigoPmgjprfrtsseRMuVkPddCAzmKEKvhjZJKWXvIyRHLFywYzHTzWiEreGVwByPNLYlJueIOsNTGBOtBTdk");
    double snUZtImvZAHjRYo = 200727.3765187729;
    bool WfBiG = false;
    int MaIlGd = 1871429887;

    if (WfBiG == false) {
        for (int OxojJQtTwhkJdQ = 834676852; OxojJQtTwhkJdQ > 0; OxojJQtTwhkJdQ--) {
            WfBiG = WfBiG;
        }
    }

    for (int FNbsyyPoA = 682020480; FNbsyyPoA > 0; FNbsyyPoA--) {
        snUZtImvZAHjRYo *= snUZtImvZAHjRYo;
        snUZtImvZAHjRYo /= snUZtImvZAHjRYo;
        WfBiG = PPrhC;
        WfBiG = ! PPrhC;
    }

    for (int TTDAEdTpmUYhSQq = 1925469016; TTDAEdTpmUYhSQq > 0; TTDAEdTpmUYhSQq--) {
        continue;
    }

    for (int GVsPzocVXK = 162409853; GVsPzocVXK > 0; GVsPzocVXK--) {
        continue;
    }

    for (int OJPRLTLZuBYzGiX = 800513346; OJPRLTLZuBYzGiX > 0; OJPRLTLZuBYzGiX--) {
        snUZtImvZAHjRYo = snUZtImvZAHjRYo;
        snUZtImvZAHjRYo += snUZtImvZAHjRYo;
        PPrhC = WfBiG;
    }

    return YdDbNPKPdGX;
}

fzFVbEWnVMWXbg::fzFVbEWnVMWXbg()
{
    this->iecjyepVuJNtmQYW();
    this->YvPoJsYoFuBPkOE(string("XmjdNaPgCdtzMZgpdyHuNtLbrZtwTzvZjPpoTvkzIkBoVnBFKdietvoKhtvigNNkeEaOysVvoPPaylFZGjBjJQlETYvAwiJcDwQuRWXmkaABMwnGBozHxESzXfBuC"), -857244.2819264964);
    this->pgPzpxwtgSSWpOqJ(258544.60803833243, 811592755, string("GWX"));
    this->BujUaAaZxdwMgW();
    this->DELiaTpqvpe();
    this->cdYQtX(113080.75409034397, string("RIZuhjqVjLKPrlYCfpwhwYmVOSRlxEilJToDgNwABasTnnkYeExMdziIMSWIGACrtkYxTVJwyvyIkcJBUUZXdrcXRgZzFOHBAgIzqGcqxujPNatrmnjeAWXLDgxeDIEJkKAsTH"), false);
    this->HqWvgKOfLjWvT(921305.6471579563);
    this->QWJRjYrdkEpnj(string("RRUftdonhzHPzIgNDsakzaFizJQyQpdmOjSnCUEUrJFXhYsxrnLNnDLqRcaWObZWQYqXMrqujybKGqsaiNaVkhMxuExcNaJLSRMagiqPOGznInyIOXnBfsRHCqmdYIysCrZD"), false, string("oDcQuuNrkBffCaDXyWtwtiispBDxKXhEQCHXJyBHFNJkNnWtETXDoA"), -1051797705);
    this->nfqVY(-1632519026);
    this->OwHhdolHG();
    this->bDVoGkeQg(-870633031, false, string("GrlPBijxgDMPlCazVMRBukQaqDCcmOWPrJTytBqh"), string("eYreozssqZcXBQkYqkTWbZACoJJQklTKsRmyEPXUbdAUlFKdrRbVYynpaYLpxlQiuKZheNwYPTUZFWnfZsePWwnMXemfMlYtFSdKJXRpNtISgBeftZHaMILKNqttJAWCrBCfyONA"), true);
    this->zkXvJZpPBjICDAG(true, 1961964692, 729233.1441029785, -508895.5263005464);
    this->kFBlCmeDECCka(true, true, -136749.37336043682, -161212.82683256012, -77636.72543177273);
    this->RdSPxVwrOORU(string("xThdfvFbxiYLCGUGyuTyJkgf"), 1901199173, -822512.917998255, -1960128266, -820332.9291052367);
    this->etxDDhUArbIbV(-1037403.4817007562, -269331.67390497035, 923384736, string("jrwWbpWhAIKDCEpvNzcpPwfsJgejMyyAQumlrwxJpKeZGNFJxFZUvvRVPOMqbBDmCvTaLrcINzxhziGJPJLzrbJkRmtKnmnezFBEaWSfQufDwonwLORktALyZvUrRXWcEbAGhyDwZawNyeyNyyDHIOzxcvjXlUMogXteLqcMgcDnEjDOcyKJhNmrVyMwFdiucafjusXcioXKFPddD"), 106551.7709514376);
    this->MNwGEAJKGHjftBMS(true, 8128625, string("mHFycPffyZnRqaCBtTQuadlbuGMotKXEzeQQNJPMITCeKdwFiZvwRObhJvczHWXsFneidTNMQKfGapZkyZabIoQCpssqrwsyCZIzqqcupYwThnzmxoAObzQhhoKspVQBQYlqVGxNiYsCsfbZzCcfwtHqeNMlqWlPgCGyAJNcZiBNnQMzbWvkJlYxqBABupAaQqrohqQDonsykJKTeouCLMxFcNrNhgUZrqsyg"), 1101171718, -434458.77554823883);
    this->BytEGEmvbu(true, -1387979636, 782234851);
    this->wSUainMD(string("PjNmBUpdsUOjqMYfgzVDtrmvDunRBbpmsRZHrKQHpPQYboYQrhQYFTlanDHLdMTpSUJzxHoyaOUtHHgpgQeVszVHdjeTJUKboCLdEygvBc"), 998527585, -1754847391, 1263844391);
    this->EKUUxzsMSQFHA(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zkXqweieEBhd
{
public:
    double oIJDCXFi;
    bool PBcrTtaqpCD;

    zkXqweieEBhd();
protected:
    int umxroMqL;

private:
    bool BHKIt;
    double DTvtm;
    bool JDKpVjcAWSalDhs;

    string LqEcs(bool tiJWaVcSJxs, string rWIuWzQXFj, bool GeyVxDsgNXSgkj);
    string qwZhuKJaKyjJCpkx(double OEcqOKDy, bool xxEwtpLbSDy, double OggatzavjL, string BqQvNiuWelTQYCx);
    int EBqCFBLGDxx(bool QKMOyje, double rUaFMGnFeL, string gjczTZOyxbVw, bool UomzwIcH);
};

string zkXqweieEBhd::LqEcs(bool tiJWaVcSJxs, string rWIuWzQXFj, bool GeyVxDsgNXSgkj)
{
    int mLTRNfF = -1707383459;
    string KKTpSGM = string("yrHiZjiCfwMPzENoJnZdWkzZpZGORVzsVaKjfdmQUoTwbltCxxmfGJHhrjYhaPNfmzawHlIsPJVIXoqBsHSraDRPDojZfESWD");
    bool lByDg = true;
    string UXcoWVNFnAlZUDG = string("BAdEINStKboeEmnfKGTyYtFRBMyOmBvuFCAycAPjSKVSVDXAUwICoeOoIcNjjLBVOvHmmAhAUDfJYDuadLYxaUDtncAKekmRUlgWnnnUcRuLZuwwJeElUJvx");
    string aFxjmiZP = string("BWtVkyUwUTuhMCuRsyLYYJGdvIWrpWnVswZefwuhPzpyKwFGSSVomUuHkkzeMuXwkdyXXeHirKjTyfvMBYXozehyyamjGAmbjPF");
    string hEbItoSbUmovYfM = string("GpEPBSbVGLxdRgSXadjQzeiWRXMJEOLVfqGZRptHrNuGabtqCMAcqlHJViZZMVpTAGzhFTYAyXtwJhfpXNodouETzuxOawoVOeAvCxmgkbLsqsgNJxPEwJpANsQQAaficLEEatrbkuMyZwHBqdYrrYPZijWaWaYMtDbOrzszdYIIJHktrcrLZoJTGIzWgQfGRozYxHCgmBfZugryKiGtCYqw");

    return hEbItoSbUmovYfM;
}

string zkXqweieEBhd::qwZhuKJaKyjJCpkx(double OEcqOKDy, bool xxEwtpLbSDy, double OggatzavjL, string BqQvNiuWelTQYCx)
{
    double jroeY = -272706.02806358045;
    double TveZbwTpKS = 256378.92926967304;
    string kJqHhcNwPwiHSp = string("beMVuxxUdCRcrMsKRGVUYLgqTphzjwCHNVUevlyXlZVrVBvcTiqbDchpGNKBTcjKINSfsNOrJcbYzNWIZEaFynvHyhZUFiexEtfnpoQvOItHaRszab");
    int hCQmGBKfsUuVoRU = -1392256109;
    double hvETrIuMIQ = 882361.388032543;
    double PeIQwBGEcYRlh = 402773.938791934;
    int vuNafjYeErfDv = -987629319;

    for (int vCjCSwqoDs = 630688877; vCjCSwqoDs > 0; vCjCSwqoDs--) {
        kJqHhcNwPwiHSp += BqQvNiuWelTQYCx;
        PeIQwBGEcYRlh += OggatzavjL;
    }

    for (int VuPqvq = 597906739; VuPqvq > 0; VuPqvq--) {
        OEcqOKDy += OEcqOKDy;
        OEcqOKDy += jroeY;
    }

    for (int EiulghSyCpsM = 2079080145; EiulghSyCpsM > 0; EiulghSyCpsM--) {
        jroeY -= jroeY;
        hvETrIuMIQ = hvETrIuMIQ;
        PeIQwBGEcYRlh /= PeIQwBGEcYRlh;
    }

    for (int loyNrsZwN = 1275254635; loyNrsZwN > 0; loyNrsZwN--) {
        OggatzavjL -= hvETrIuMIQ;
        BqQvNiuWelTQYCx += kJqHhcNwPwiHSp;
    }

    return kJqHhcNwPwiHSp;
}

int zkXqweieEBhd::EBqCFBLGDxx(bool QKMOyje, double rUaFMGnFeL, string gjczTZOyxbVw, bool UomzwIcH)
{
    string qvpwpQjzb = string("JxliKxAAVxopDtFnPujrbGuOHZfeiZFFGWkjkuhnVHlMfrbexgoqwuCyyAYVoKFrukEQmDtOEiLfvHyOBYmfMoGzBEIuSwpboNRCGZvyrSEOZjKlqJawNegRHXpCLFuJzDNPkZnJqdSgWpn");
    bool OUfPeKqMTVbvZnk = true;
    double oQvGSnmyYF = 479801.8963520231;

    for (int BGDBYSCtWFagT = 782116425; BGDBYSCtWFagT > 0; BGDBYSCtWFagT--) {
        qvpwpQjzb = gjczTZOyxbVw;
    }

    return 1802403182;
}

zkXqweieEBhd::zkXqweieEBhd()
{
    this->LqEcs(true, string("UvgmfofKYCsicOCkaGUmfzMWyBXAWAeeaGjQQKGDUKPxOsLNyrHerasGtjxGnQZAhCKvd"), true);
    this->qwZhuKJaKyjJCpkx(643949.9475596776, true, 785880.7328137967, string("fPCOtkjGOXxEqBMsuZxVGxIXIKUYaoYElvzQymuKmOCDrnXZEopNPoBlQAOKGaiIijgmNonYtcJCutxZTLieLkTCAOWoqJctJVSiKmtJMBxWFcYAiMAVSRoixXUqdmTkbSgtjwIvwpyqGfxydjBdMowPBtnZQYQVfRkNMJDqhypRIdvRdXYQEpFCkviBDDQVHxIOGaKmfiKJPsKkuAjJeofRQpKWMTUVHybBRcxnbagDDDvrkqBAV"));
    this->EBqCFBLGDxx(true, -900959.0372506453, string("cmxtnMZtvKmXMUDUNSKhFNINmrnATmVUSdprbQwAdHImwAbuckPuDBjTZPwZBqowAcdquvTNYdJWHCuvLdqaFKwNqrOivbwSyJvmJirtWYxjTVRZlRqPXbjaDhGnLGGVkHhuDjhxSdYBqvyPvSpjRFGazCsIUBBCLtsigGepTkItiisHJJegmFLSBemR"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XQdCtzpYcajtl
{
public:
    int ElDUmAmpJ;
    int LHzDnxzVLnwl;
    int UjjkEeZt;
    int vOPeWFZstme;
    bool VQrvKlW;
    bool iQHZHwdqnXoznMNi;

    XQdCtzpYcajtl();
    string gwZcq(bool EirqBXnDor, double HYQzRWd, double STdJIP, int vZylwmBK);
    bool ksqnTgpT(double oXauYjAa, string RZkiTrEBbaCs, int EDwofnTGLhVC, double xmdHgv);
    string wAyiXOwAVsXotcz(string BjWGHC, bool AycJpdgjFPvy);
    void WQsHPKWsgcHVMxcP(bool yFhlFR, string QFWSbHddDtDmHcl, string SbEASsO);
    bool qHaYDl(string GmbjrYJXATaVbZvV);
    void lQtyBIvY(bool ONEtIQprIkpJx, bool FzGCk, int OqnLExfVeC, bool YyKUbKSJUTb, int gCrCxV);
    int nJkJxFLYWx();
    string RDEXpYGqmflH(string RcJba, bool qkWcRzCDVtpXbQOe, int CmBdyrEAByLuto, int iXJXniXGwU, int BrdEq);
protected:
    bool VAvgeKE;
    int guLXDnYmhcTBGPaG;
    bool qYEhhpLuWKW;
    double jtUTFwDwJJdRl;
    int pfVhQMaZMSikBfL;
    double OnnNXiuesdlnLiY;

    bool JnnZgYEFZwCi(bool KWzNIIWZe);
    string oAsZyfgNAL(double UFFjMubQ, int RMGNur, double GAhABfFTBrQpwyWc);
    bool ZrPbBECof(int UUOJnbJhqBmw, string rdPsRrmtdCycLjV, bool fOeLrzAZpqdetJCk, string SYmurhrPwNADQxG);
    void RnrfbKrbcuq(bool VDCOVg);
    bool sGLUNKXlMBUaoUeo(double ISKaYZmUqK, double jwvRATntiMlt);
    bool mQYsmpRc(string kukkuOwuudYnyi, string xVkvNzXYrkmmXVp, string MdnURWqmUkk, bool tJMfpsvhyqqafmV, int NeubLxaLi);
    void BBcPzJ(string JaOqiAZ, bool tRUIyA, bool iEFUHK);
private:
    bool BCkowDC;

    double BImLilXiFCoc();
    double uxJvYyo(string iEWXGCBQTxz, double DAcVNjoi, bool doqOoUmWVqzm);
    int TfQsGvMLJ(int iAtcrWmucT, int GzNcRSIH, string CkGovSpgL, int buLQoPzOlK, double WZTLyMPrUk);
    bool VETxeTjES(int OwmNXJjBIgT, double eEVAggIFZXTUH);
    void bzeuPQvbDu(bool fbnCKmJT, double vTEUjNil, double nHSfb, string nTxowKeKLieuib, bool jKmLAguxl);
    string aZUxE(int REszLPJJIS);
    string nWeozYlORtGu(double XsbWjVOidMEFyVu, string YrjuQjkZmbwQxG);
    double hBeeQoZGUyQLq(double IPdtSIJuyTg);
};

string XQdCtzpYcajtl::gwZcq(bool EirqBXnDor, double HYQzRWd, double STdJIP, int vZylwmBK)
{
    int wAYbSwSgnyryVob = 1180318249;
    double KBXzKAqqBvqGFE = 916886.388973338;
    bool SAxIuhXEioOYav = false;
    int PlFLAd = -845688578;
    string RrcgebtqzDGUJO = string("YvlCdGfljHqGGNULiiaEUotyWVwLxTpJpKAELSCoEiPsuUvFLNFCQuHnTm");
    bool avkmrMiPcLr = true;
    double BOQtpTOpmOTqVPD = 983620.7036638447;
    double GSsDv = -879466.8063880476;
    string BlfaVeUDirER = string("uSWCkJRAftlshtFUnmjZcFUqABzEvSOCydFgrdtgLbwSCrTeCLFzHCavLccSyKkvedRRXSbIKyhHTGOGbnWuIcqxSbnHNYYRydYiDhuKUmBMFKGKxKQrknynQznigfyJCjvbYAvEIcpWnpBhxaXNNPakHflumRXPu");

    for (int toXikX = 548180314; toXikX > 0; toXikX--) {
        avkmrMiPcLr = avkmrMiPcLr;
        avkmrMiPcLr = ! avkmrMiPcLr;
        EirqBXnDor = avkmrMiPcLr;
        GSsDv = KBXzKAqqBvqGFE;
    }

    for (int kCTiWptAw = 475067830; kCTiWptAw > 0; kCTiWptAw--) {
        HYQzRWd -= KBXzKAqqBvqGFE;
    }

    for (int IFaHkfif = 1404019375; IFaHkfif > 0; IFaHkfif--) {
        PlFLAd -= wAYbSwSgnyryVob;
        EirqBXnDor = ! EirqBXnDor;
        PlFLAd /= PlFLAd;
    }

    for (int uYSOvdWlfgGxOVR = 869742929; uYSOvdWlfgGxOVR > 0; uYSOvdWlfgGxOVR--) {
        continue;
    }

    return BlfaVeUDirER;
}

bool XQdCtzpYcajtl::ksqnTgpT(double oXauYjAa, string RZkiTrEBbaCs, int EDwofnTGLhVC, double xmdHgv)
{
    double SFhUkcamrHDAQ = 336098.5224871728;
    double ccIfhSzoL = -875857.1315866339;
    bool MvNfxxm = false;
    string OblMYKVltiP = string("yNQAdvXecjlilmpvptDIEFbJqGBkSmxvOQgozRZUrKIBTOZQfNqymlNjyuIkeLLDyLuNbACOkgNOqXveDFuDncyvXycXKGnMOjtUOXegVmviKQXVhQJuhWNJFHdhWVoMIGMIJyDttpjoJMggJOQfUzWdCJmfxXNRBXvCaAlpSTHuwvIuXEPSjEwTFHecTKTAMIlSECxSzLgHOXzjSlzXDzbWRGsJmTBVdzcBdAFycxiVSMHJisArAxtZR");
    string UzKxCXjfqSSEIbz = string("fjYZwBLijssdGXbAkEWPDFRpwSAlXueNBnPcOSAyqHUQJsZrmmeCrDOAhhDzbjYmAAnhpcAdLBGshWUeZaraEYYwAHgdJuoPzzBjfEVLhiWpKUipFUmdSXSdLkYpLizWzLJwcfhyXHHqerTDIldOeImKaSFYPykI");
    string OWAyJjxyFqi = string("RMzKncpJOCVdgUwQBIdHpeDCXAEatecmFroyzilpNBjlBSillZtspUhOwIiQNrFtDAfjbwKtKZkaXZdgEVfynQu");
    bool VJpIOCZ = true;

    for (int vJOelIhB = 330528094; vJOelIhB > 0; vJOelIhB--) {
        continue;
    }

    for (int xGpFcjSlLj = 779634281; xGpFcjSlLj > 0; xGpFcjSlLj--) {
        oXauYjAa *= xmdHgv;
    }

    for (int kXBFHZZAKTmBpoIR = 496777111; kXBFHZZAKTmBpoIR > 0; kXBFHZZAKTmBpoIR--) {
        OblMYKVltiP = UzKxCXjfqSSEIbz;
        OblMYKVltiP = OblMYKVltiP;
        EDwofnTGLhVC /= EDwofnTGLhVC;
    }

    for (int vhCUKzmzpzqJtdc = 1911352661; vhCUKzmzpzqJtdc > 0; vhCUKzmzpzqJtdc--) {
        RZkiTrEBbaCs = OWAyJjxyFqi;
        RZkiTrEBbaCs = OWAyJjxyFqi;
    }

    return VJpIOCZ;
}

string XQdCtzpYcajtl::wAyiXOwAVsXotcz(string BjWGHC, bool AycJpdgjFPvy)
{
    double dirBZOUcp = 327034.0200886881;
    bool KfCmxkqHcvpY = true;

    for (int WWsWCfbLbefBbo = 334036127; WWsWCfbLbefBbo > 0; WWsWCfbLbefBbo--) {
        continue;
    }

    for (int ScHbWwIOGOBilZ = 129014619; ScHbWwIOGOBilZ > 0; ScHbWwIOGOBilZ--) {
        KfCmxkqHcvpY = ! KfCmxkqHcvpY;
        AycJpdgjFPvy = AycJpdgjFPvy;
    }

    return BjWGHC;
}

void XQdCtzpYcajtl::WQsHPKWsgcHVMxcP(bool yFhlFR, string QFWSbHddDtDmHcl, string SbEASsO)
{
    bool pezbXZd = true;
    int IzaUzquyUVFF = -66261691;
    double MKFti = 663955.4003665673;
    double McccXGUx = 534739.9383182527;
    string CdMZsRHTaLKz = string("oWdrZwYrMrjLR");
    int ssxWaaeVj = -1354210476;
    bool wyiAufLOqP = true;
    int IRRjuzXXTHeuFY = 2136017395;
    bool DhMrFCoKAsDawyb = true;
    bool dIEhlV = false;

    for (int JFOcPtULREvxT = 193686689; JFOcPtULREvxT > 0; JFOcPtULREvxT--) {
        continue;
    }

    for (int uNHnfaGnY = 2095435522; uNHnfaGnY > 0; uNHnfaGnY--) {
        DhMrFCoKAsDawyb = ! DhMrFCoKAsDawyb;
    }
}

bool XQdCtzpYcajtl::qHaYDl(string GmbjrYJXATaVbZvV)
{
    int gwplVRdbFVrVLB = 972435089;
    string YQCTsyVbAVk = string("MHx");
    string QlhwpAMLlKbu = string("vhSVmxGhoDIDJbFzNGQEWnCdKInZZrxqwtIbfRaJWuYzHnmhGJknXIWTGKuzdMEXwkARtFZtJTTKvXAHazKYjqMRXtnigouagYFKoKOhbhSGRzUdRcJsRqRYowZgpOZOpZyuEIvXmuvWUVsaURRbBwRPwjxXzfi");
    double eSJqxoUS = 207049.571605273;
    int dCeStoh = 735356070;
    bool kXglIqPzboyFf = false;
    bool dHRVcKpDu = false;

    if (dHRVcKpDu != false) {
        for (int rrYxNbSFVsC = 517060079; rrYxNbSFVsC > 0; rrYxNbSFVsC--) {
            dHRVcKpDu = kXglIqPzboyFf;
        }
    }

    return dHRVcKpDu;
}

void XQdCtzpYcajtl::lQtyBIvY(bool ONEtIQprIkpJx, bool FzGCk, int OqnLExfVeC, bool YyKUbKSJUTb, int gCrCxV)
{
    int mpzbbFidMzUatq = 1363711469;
    bool ZESRdUGnysfyBxb = false;
    double HvqXDW = 390803.3780368322;
    string gvgsierG = string("seZCTsFWmiXaMVaFHWaEmtAZaFsmkJqUwhodilTUEzhvKECZmyXYTZzGRWdsbixssyUBFyzJfwkCbEusxQZzxmAQosfJAOdovqdMIBqSblMFQiJsEbtwaoYIYRSKibGZjfTFKpHZfEDiwEDJPJEmjwIiZWsPnhYvNshOqXKlSXxpgkEaVTWpRofSvaZfDwlHbgvAFcRIQnnYGTceQKNZyWruuyBovqYLymoEeNMqPNryrGdsMSEhEKjpRNmi");
    string AmZiAgOFhLrGTzTt = string("fBZamOjeZNXPdEvSzxcsQkmvCxofUbUdpytYMJdLMahCGcISgDkPfIxoljkAAvyPDGDYVNzEhJUnOUCrOHUbngjPCuGNzND");
    bool mLtmfj = true;
    string QcaKj = string("EpAtrtlPfnRWwUHgVdiWoitNXAQESLVyZGArgXFWNkfihELNLNXvxgMXXMpZYUqPoYqXlHm");
    double OjUXuGlmJvT = 363455.7916076256;
}

int XQdCtzpYcajtl::nJkJxFLYWx()
{
    bool gGqXpliZBXQO = true;
    int VBRBNIgTXvMssDg = -1614114774;
    double AuMhyT = -259469.84741020147;
    double OZNhtVWgyWDY = -836692.3173773899;
    int ixrOOlR = 86038113;
    string tUueLghkvVk = string("cBoXzGvLSjPChavQqeELszamDGJCXGOlOpfKWIvgWnUjSzqAhcTHahIXnXyXRYZzOoXkpFLcPErCGGKEWmSZXjivEPfBQotS");

    for (int HmVOqPbyCHJDk = 1898189435; HmVOqPbyCHJDk > 0; HmVOqPbyCHJDk--) {
        continue;
    }

    return ixrOOlR;
}

string XQdCtzpYcajtl::RDEXpYGqmflH(string RcJba, bool qkWcRzCDVtpXbQOe, int CmBdyrEAByLuto, int iXJXniXGwU, int BrdEq)
{
    double APmghZuphy = -460662.81314815785;
    double FXdvPQvZtHEO = 684907.5816121548;
    double tQoGHFAYYavYo = -442906.1524919433;
    bool CYQorGnDhSdWoc = false;

    if (APmghZuphy != 684907.5816121548) {
        for (int QmIIfIvGqlVBAH = 1386096263; QmIIfIvGqlVBAH > 0; QmIIfIvGqlVBAH--) {
            FXdvPQvZtHEO -= FXdvPQvZtHEO;
        }
    }

    return RcJba;
}

bool XQdCtzpYcajtl::JnnZgYEFZwCi(bool KWzNIIWZe)
{
    int XUJsxdKGXxmBTfv = 422540709;
    bool PfsCMi = true;
    bool rzAQxPZcTjSAnW = false;
    int RgRgGbcnb = 1737599950;
    string IFCefPvWQ = string("mVtGAtirSmGPGNRNXPMwUUBxtAcUJzyWXmyeLuZxqvjkVWdwbbTeuhKJVRSUjKzuauprDseSNfwzndunyMjOMycLGDbwPplGtxoGwfeucImdvFbBgmbfxQHmyZOeFnYQcmvpxGwYEgysZXMKFzyMxFWWcONvdRGWfFLuwLXOTYzwrCUMOJEEKMDOcfsAJUecVlmVlKmuzo");

    if (KWzNIIWZe == true) {
        for (int CNpRrUDzL = 1703243480; CNpRrUDzL > 0; CNpRrUDzL--) {
            KWzNIIWZe = ! rzAQxPZcTjSAnW;
        }
    }

    return rzAQxPZcTjSAnW;
}

string XQdCtzpYcajtl::oAsZyfgNAL(double UFFjMubQ, int RMGNur, double GAhABfFTBrQpwyWc)
{
    string SJrSrzyyBiOYLeQ = string("XWlIKOwXUXUYbGPKrSOSWyxqZobhzCSFfCyRredRtINvYYRVhjoEvoefTe");
    double IdKQWPd = 430603.81894762977;
    string OImUiP = string("FLynHgmYplPEYWDfDHaSoXWUbJlPbIVxtCsipswQZwiKeyCsvZFlzWfDrkvwHiCmLOKJjibzAzaXdfcggVoQrNAmaWDGukwnflVoZehkYFlGaajESFcEGaQzpEwyZPAoTFwfEiaSiPFoYQRUIYiodVcJBitnFygBtAvgYPhHgnpXiYJpvIqLRzUwgxGTalFDacyuPdGmvJsfNdTVXGxEVZXCXFZ");
    double ahlKDQjYGbTPxBZh = -388118.658465385;
    double MFkqJ = -625974.6505163271;
    bool Vqywo = true;
    int qUIyYUIDRcaohwO = 152445596;
    double EUihBCOjlMyN = -680581.9229466295;
    double ixHEQtl = 964467.7868843408;

    for (int OGYEVpyFnIXoiX = 1222983562; OGYEVpyFnIXoiX > 0; OGYEVpyFnIXoiX--) {
        ahlKDQjYGbTPxBZh /= MFkqJ;
    }

    if (MFkqJ <= 430603.81894762977) {
        for (int yxGcYkOx = 1417976903; yxGcYkOx > 0; yxGcYkOx--) {
            GAhABfFTBrQpwyWc += GAhABfFTBrQpwyWc;
            GAhABfFTBrQpwyWc *= GAhABfFTBrQpwyWc;
            MFkqJ = IdKQWPd;
            UFFjMubQ = ahlKDQjYGbTPxBZh;
            Vqywo = Vqywo;
        }
    }

    return OImUiP;
}

bool XQdCtzpYcajtl::ZrPbBECof(int UUOJnbJhqBmw, string rdPsRrmtdCycLjV, bool fOeLrzAZpqdetJCk, string SYmurhrPwNADQxG)
{
    double eCWUbjjPnGUpoBOi = 357753.66539395414;
    string YJjTEQqCNS = string("SPNojbYHdkkkaiVHLxhArmoRaRyLJmvcaUESlsRpALUwybhMLJdFHCVxehsamkLYQjdgOAXjPmHLIrtfOhSlrpRYbCEtZGMzGUGLnDubOrOHVhlJrcHvCpqExdYFCyndCbqOHRqTtergIvqUpDyombmAZnuQJPMPtCYXxZbWkmnjsKgGGBzXijqUXhuLpEzyGXmQVmbWE");
    double WMOWb = 585373.1242742419;
    string HBsZDQdKDf = string("GBfKfYWAOdbaHAogUXSzNkeppmFuBNCzmRiFVgkZOhQgETBsSASfdxCYxOW");
    bool GZUvfIjDCOGi = false;
    bool PEwpStodNNMZdJ = true;
    string OrSmIzfnuYp = string("ufZvohrrJJmQoIVWcOAgSZAPatDFQUmVLtYAhaUiInmYMKIhwoxvqwVVWrwMaONdcuaMFXvxvRrBjbXTSxTZHioWzcBZi");
    bool PLeUrQtymwYqR = false;
    double OIrGnDjBh = -586745.9325451333;
    int GnRpz = 1179652753;

    if (OrSmIzfnuYp != string("ioYBdxLERiDlHasfomBjUrRlmSRZtFJXXPppujaxSVFuuLkQgtbJPqdlGxZ")) {
        for (int mESVMmRzVSlDQ = 712789667; mESVMmRzVSlDQ > 0; mESVMmRzVSlDQ--) {
            HBsZDQdKDf += YJjTEQqCNS;
            rdPsRrmtdCycLjV = rdPsRrmtdCycLjV;
            YJjTEQqCNS = SYmurhrPwNADQxG;
            HBsZDQdKDf = HBsZDQdKDf;
        }
    }

    return PLeUrQtymwYqR;
}

void XQdCtzpYcajtl::RnrfbKrbcuq(bool VDCOVg)
{
    string pGFwUZUhOgkFMAWs = string("xAbPbpezSFlaep");
    double KqlTLwzsUbcxP = -952610.5356003939;
    string QokYAgzJZnWXrWbF = string("qJugGvLOrAdQOKnGArhbPxeKxahLMExCudPqkmvJHtqLvfTxnEhnnVfBfDdgYYMDRtdwRWbtKaAxKKCuZAAQezJOgqBqneKxjKIbAeSOLphRhRgqBmjVHkjVqvEuqKLgeQSbfDewvgOCVDxsvnrDpMgWulohHrNyZlqcOiFbGoiESCCyLASjMAJlyDVBeSNRAfpvNpl");
    int zKGkqCvJj = 1039470919;
    double ihCWjmqoQWNR = -201886.93427439252;
    bool byuqclTwmj = false;
    bool rArbnekrlr = false;

    for (int FJkXQZcncE = 674668144; FJkXQZcncE > 0; FJkXQZcncE--) {
        KqlTLwzsUbcxP += KqlTLwzsUbcxP;
        KqlTLwzsUbcxP += KqlTLwzsUbcxP;
    }

    for (int rIQINBiYcU = 1279133895; rIQINBiYcU > 0; rIQINBiYcU--) {
        ihCWjmqoQWNR /= ihCWjmqoQWNR;
        byuqclTwmj = byuqclTwmj;
    }

    if (byuqclTwmj != false) {
        for (int uPssGbghoRSPOGrN = 1842573680; uPssGbghoRSPOGrN > 0; uPssGbghoRSPOGrN--) {
            byuqclTwmj = rArbnekrlr;
        }
    }
}

bool XQdCtzpYcajtl::sGLUNKXlMBUaoUeo(double ISKaYZmUqK, double jwvRATntiMlt)
{
    string nCkwrGHUZQ = string("XPdbEmLSWKUSsBkJLVoIBbPoZheDCSTItTtyrHDhuQbFAVjVQZLJEkbRpRlNmhDqmQyWzCydFZDWdcPIpPWniiCIPARKOiuqNJZJMvsfpbBovknYTnehQyIyCXAlPcseDCuXJFenIcVJptDGNqqMmvhmGUSzyXOWNgArFnzUvwEnwtmWepisHnuSwQdlPYpCcBTxfCSvZUczexqGNaGG");
    double OhdMCLmjavhwC = 616457.8138003269;
    int GfHfh = 530402480;
    string PSVenQ = string("rsHFvTZRzGCzBRDYlaFuxDPnUtvUMHxFkSRjkIAneyJBUeQrBoTmuoeSgJoRScFzldCnGATjnUjGmxjosimQUEfBUVZwZYeLUFVfmcaxdL");
    int aCnpKseneXBoIYG = 1339049783;
    bool MAhxQWxUz = false;
    double OpKso = -552482.968931476;
    double yPZFWVgcVZBs = -206227.5555356731;
    double bCymEgsHauBfuQ = -5554.303555083929;
    bool VudrgldQVeB = false;

    if (MAhxQWxUz == false) {
        for (int AAOHZel = 284539439; AAOHZel > 0; AAOHZel--) {
            MAhxQWxUz = VudrgldQVeB;
        }
    }

    for (int LARNEmXyhhtD = 1149616115; LARNEmXyhhtD > 0; LARNEmXyhhtD--) {
        OhdMCLmjavhwC /= OhdMCLmjavhwC;
    }

    if (yPZFWVgcVZBs > -779099.2722115549) {
        for (int qzPBqdG = 1670578686; qzPBqdG > 0; qzPBqdG--) {
            continue;
        }
    }

    for (int WAmfhA = 24157365; WAmfhA > 0; WAmfhA--) {
        yPZFWVgcVZBs *= OpKso;
        OpKso += ISKaYZmUqK;
        PSVenQ = PSVenQ;
        yPZFWVgcVZBs += jwvRATntiMlt;
    }

    return VudrgldQVeB;
}

bool XQdCtzpYcajtl::mQYsmpRc(string kukkuOwuudYnyi, string xVkvNzXYrkmmXVp, string MdnURWqmUkk, bool tJMfpsvhyqqafmV, int NeubLxaLi)
{
    string uWuXdoeX = string("naRuOWEFKpgkwoBioenmB");
    double mffli = -835978.5424747193;
    bool rTgvC = false;

    if (uWuXdoeX == string("moZyBlRMImHZfzevARfoftzfiTnHgXmCNvmnimQOxXbZuHsCNuWkdHRwfJgUWDTcwBGSyMKaKNaJwtrsQzWXXbwYSuDAHNOMoUqWhthSdXCWUOgbeXRuLJFDTuHDKqLfpkpPJCaclttdFUgPWSlhpJpctjxbpCbiLlMdGGmznEojRvHSFWhlmStKcVDuPTPLnUdVRfHdeZRowrckDqbDAOFoGrnjvmDMQAcCvcbNGlXDbD")) {
        for (int FHUELJyjrMnTLqL = 288151215; FHUELJyjrMnTLqL > 0; FHUELJyjrMnTLqL--) {
            xVkvNzXYrkmmXVp += kukkuOwuudYnyi;
        }
    }

    for (int YeJmVbMd = 1808413819; YeJmVbMd > 0; YeJmVbMd--) {
        rTgvC = ! tJMfpsvhyqqafmV;
        MdnURWqmUkk = kukkuOwuudYnyi;
        xVkvNzXYrkmmXVp = uWuXdoeX;
        kukkuOwuudYnyi = uWuXdoeX;
    }

    if (MdnURWqmUkk >= string("lpmfJxdU")) {
        for (int HXNnH = 1766489308; HXNnH > 0; HXNnH--) {
            NeubLxaLi -= NeubLxaLi;
            uWuXdoeX = MdnURWqmUkk;
            uWuXdoeX = kukkuOwuudYnyi;
            MdnURWqmUkk += uWuXdoeX;
        }
    }

    if (xVkvNzXYrkmmXVp >= string("lpmfJxdU")) {
        for (int zIrAj = 1574572460; zIrAj > 0; zIrAj--) {
            MdnURWqmUkk += xVkvNzXYrkmmXVp;
        }
    }

    return rTgvC;
}

void XQdCtzpYcajtl::BBcPzJ(string JaOqiAZ, bool tRUIyA, bool iEFUHK)
{
    string YXhdpirXyqHnVrpt = string("xqOIMEcDnIyQkHMBKUxevSjQLFSHnLOhIjfhAnOfxE");
    string yLekaRSZmdqMT = string("shRRpgRiwRlyUimURfhoxXdvAtXqraZrsAAihKTfUOYdfYbNcnRoMqQePyIhLOCPoKbWIgaArELgwxnqpzTSQKxKzfUVrGlkAPIcxZQkWSyNHjUGXFusBgSYHMMEsPiDgBvwDudOfEIhNUnxObrkgNnSnwrePAMDBKSgjTNCqECHfFtiOmlunhnJbDAqTGHcjDHecMtYjdisiyiPzQBO");
    bool tuFtc = false;
    double QiMUsAgIsLqHzH = 521866.3478713058;
    double gdeQVHTAPx = 564552.6472722354;
    string naBeqPiPQSeq = string("yhrbcsutSAMcxZPGmewQfJloxbDjJytnQlsPISghzqmPZlkWIpTvnRhsuZrexfugIVFlOiZYuqQBECzPouScWiKDZFyfGRdiTwtdCPcuyYDpfcChphOlbukUXURPpugqXeqhJGeVRsbAPRcsTHZUKqoipJtyVmyBgNcxvgCKdRxlDrrrPqDLBiBdVFSMaxCdQYoAHPzleeWLsSCJHUUXARMNmiOoIYSLfomrxTEeZUkjcrCW");
    string siyyETsWMmkAyMPy = string("QfAzHHYvciNgGsyTexIMGtvdnMilkMxyMJY");
    double vhdSMRbzW = -605212.1659731164;

    for (int rHiiLCDhPm = 1207462974; rHiiLCDhPm > 0; rHiiLCDhPm--) {
        JaOqiAZ = siyyETsWMmkAyMPy;
    }

    for (int fffUIJGirBe = 547333365; fffUIJGirBe > 0; fffUIJGirBe--) {
        naBeqPiPQSeq = YXhdpirXyqHnVrpt;
        JaOqiAZ += YXhdpirXyqHnVrpt;
    }

    for (int dEQGm = 367384513; dEQGm > 0; dEQGm--) {
        siyyETsWMmkAyMPy = YXhdpirXyqHnVrpt;
        yLekaRSZmdqMT += naBeqPiPQSeq;
    }

    for (int HmtWGwdad = 1155844618; HmtWGwdad > 0; HmtWGwdad--) {
        gdeQVHTAPx -= QiMUsAgIsLqHzH;
    }
}

double XQdCtzpYcajtl::BImLilXiFCoc()
{
    int aBluO = -1903668365;
    double ZseMQtswJIVgSxI = -603597.0934790566;
    double wDFFhMzfw = 109775.30932099903;
    int aIposMdWj = 1878031531;
    int rdABIDmAbbjRMB = 111460630;
    string PMnmrefovQ = string("dyuyrExSViRhSnLgAAtBTapCNZhnyeDyCUQJiIYyVyaiatmcQKzPTXLnEjWMULmKzqXejpTgFjhqmqEKYtMGzdZPouonutsHFrVGBPSJlYjQuxCltExDrnYdkllGHaHChndWolzvPhQUEhGJGwyXBRgGTX");
    double IVLpIqTIxjGflxPI = 853597.160377234;
    double oLUlGYimWhtmE = 706811.8709210545;
    int SOydOkexrILf = 855001237;

    for (int mXCjOC = 466967599; mXCjOC > 0; mXCjOC--) {
        wDFFhMzfw /= IVLpIqTIxjGflxPI;
        aIposMdWj -= SOydOkexrILf;
        IVLpIqTIxjGflxPI /= wDFFhMzfw;
        aIposMdWj = aBluO;
        SOydOkexrILf /= SOydOkexrILf;
    }

    for (int ecCNRGZWKa = 683183454; ecCNRGZWKa > 0; ecCNRGZWKa--) {
        aBluO -= aIposMdWj;
        oLUlGYimWhtmE += oLUlGYimWhtmE;
        aBluO += aBluO;
        PMnmrefovQ = PMnmrefovQ;
    }

    for (int vObHCAgVIVRPDSgZ = 1717226718; vObHCAgVIVRPDSgZ > 0; vObHCAgVIVRPDSgZ--) {
        aBluO += aIposMdWj;
        aBluO /= rdABIDmAbbjRMB;
        IVLpIqTIxjGflxPI *= oLUlGYimWhtmE;
        aBluO -= aIposMdWj;
    }

    return oLUlGYimWhtmE;
}

double XQdCtzpYcajtl::uxJvYyo(string iEWXGCBQTxz, double DAcVNjoi, bool doqOoUmWVqzm)
{
    int uIdoNefq = -70772939;
    int zXjxDbDPsAgZZ = -815239592;
    int XNSWGwWDX = -635594341;
    bool ALzpAqDRWxCjy = true;

    if (zXjxDbDPsAgZZ < -635594341) {
        for (int mcqltgNq = 936110223; mcqltgNq > 0; mcqltgNq--) {
            zXjxDbDPsAgZZ *= XNSWGwWDX;
            zXjxDbDPsAgZZ /= uIdoNefq;
            zXjxDbDPsAgZZ /= XNSWGwWDX;
            XNSWGwWDX /= zXjxDbDPsAgZZ;
        }
    }

    for (int Hyxhaikfxs = 613024916; Hyxhaikfxs > 0; Hyxhaikfxs--) {
        ALzpAqDRWxCjy = doqOoUmWVqzm;
        uIdoNefq += uIdoNefq;
        XNSWGwWDX = zXjxDbDPsAgZZ;
        XNSWGwWDX -= uIdoNefq;
    }

    for (int nrDZJgcXokgNc = 1254194606; nrDZJgcXokgNc > 0; nrDZJgcXokgNc--) {
        ALzpAqDRWxCjy = ALzpAqDRWxCjy;
    }

    if (doqOoUmWVqzm != false) {
        for (int nSMjWarKDZdcZTj = 1225695491; nSMjWarKDZdcZTj > 0; nSMjWarKDZdcZTj--) {
            XNSWGwWDX -= uIdoNefq;
        }
    }

    return DAcVNjoi;
}

int XQdCtzpYcajtl::TfQsGvMLJ(int iAtcrWmucT, int GzNcRSIH, string CkGovSpgL, int buLQoPzOlK, double WZTLyMPrUk)
{
    int ydtnWyosflVkXOB = -721195426;
    bool emSbKkmGmUvX = false;

    for (int CRXgSgpgCYFcvT = 377785317; CRXgSgpgCYFcvT > 0; CRXgSgpgCYFcvT--) {
        ydtnWyosflVkXOB *= iAtcrWmucT;
        emSbKkmGmUvX = emSbKkmGmUvX;
        iAtcrWmucT += buLQoPzOlK;
    }

    for (int kkiZVxcrvrvoISm = 2082557036; kkiZVxcrvrvoISm > 0; kkiZVxcrvrvoISm--) {
        GzNcRSIH -= iAtcrWmucT;
    }

    if (iAtcrWmucT == -721195426) {
        for (int tpdhKclfzmdIF = 1529658005; tpdhKclfzmdIF > 0; tpdhKclfzmdIF--) {
            iAtcrWmucT += iAtcrWmucT;
        }
    }

    return ydtnWyosflVkXOB;
}

bool XQdCtzpYcajtl::VETxeTjES(int OwmNXJjBIgT, double eEVAggIFZXTUH)
{
    string WFaTZJVPbRC = string("gLuxZUFZDJYtaZGXIIObJJKnDoomGyuEwLyJUzZluRNeTsZymeJrRkWHLuonwncOLKNqwqonFXidWDmZsr");
    double zwbvMTzX = 163235.67402190197;
    bool ynPiaKXrDV = true;
    bool UIPfchBd = true;

    for (int KZZcfLyH = 2145081910; KZZcfLyH > 0; KZZcfLyH--) {
        zwbvMTzX += eEVAggIFZXTUH;
        zwbvMTzX = eEVAggIFZXTUH;
        eEVAggIFZXTUH /= eEVAggIFZXTUH;
    }

    if (zwbvMTzX <= -447215.70339730795) {
        for (int kwYqzmtfFqywR = 1464040412; kwYqzmtfFqywR > 0; kwYqzmtfFqywR--) {
            zwbvMTzX /= zwbvMTzX;
            eEVAggIFZXTUH += eEVAggIFZXTUH;
        }
    }

    return UIPfchBd;
}

void XQdCtzpYcajtl::bzeuPQvbDu(bool fbnCKmJT, double vTEUjNil, double nHSfb, string nTxowKeKLieuib, bool jKmLAguxl)
{
    double ZXTfDApQMwy = 206241.49873969154;
    bool aUcWgXNELbqf = true;
    string dlMoWa = string("ZwQJdqYkahDlePAquGUPeLtxIeLjYGRbDtSkajvSKSpeBncpqclpmwRkJZXxHTUTzwoECPBPKlCnHizqowXTlgmCSvpJBzrzHxQZuSsiXbgOrxzQWKLHsO");
    int EczjizJEAuem = -1651089164;
    string stniAoWa = string("DWwYaAynnTqVNdNssXSJpLgWhfKnRMHjTPHWKuhakFLmJtPHPJUAlFGpEKLyhfmEGiJxrDPsaIfHpWJcZJblkqSmQhKNepIrXEFfIfDLgnZcKHSmWsfPiabxGQgGXogsAdrzmNcLTNneAUPlpjGirSZazJdDYovPIHgasmVPHQPUljEidHSGSbIFLhGPbIhbvnQLrnEzToJFYPqahlgRuyjcVZYpLcqgmFezmR");

    if (nHSfb == 1005059.4625922849) {
        for (int RZMRspfq = 342368328; RZMRspfq > 0; RZMRspfq--) {
            nHSfb /= nHSfb;
            jKmLAguxl = jKmLAguxl;
            nTxowKeKLieuib += stniAoWa;
            vTEUjNil -= ZXTfDApQMwy;
        }
    }
}

string XQdCtzpYcajtl::aZUxE(int REszLPJJIS)
{
    bool jIlPM = false;
    string tHqLKpH = string("qQweACwfwXeSIVhDuhkdZVOPeoYsdQXAhQkiwuOFhjKStQRkAVDDykuaWiMIPduRvbJYuPBNBiWMHdwTPXKMqSzPNOXKnJmGLAPsnUrJscZJohqiymkBhUjdtemfpVBTaDaHusZYmGBNONAIEnzwdarhEUKGgRNxcnUbanWmxSepZlOxHdrlrwYWissXnaxqlBzQiUWZikINjERsahpxQUTixsmfMTLoUtvMemoSCAPjdifBSWI");

    for (int noNnBydVo = 499467017; noNnBydVo > 0; noNnBydVo--) {
        jIlPM = ! jIlPM;
    }

    for (int jESJQuFkuOlG = 572391556; jESJQuFkuOlG > 0; jESJQuFkuOlG--) {
        jIlPM = jIlPM;
        tHqLKpH = tHqLKpH;
    }

    return tHqLKpH;
}

string XQdCtzpYcajtl::nWeozYlORtGu(double XsbWjVOidMEFyVu, string YrjuQjkZmbwQxG)
{
    string aknCyTjFYW = string("XjdzgczQCoGDCSqypTBSkmzOrSbhOkkKmCVHZgYACZmBexoCoYOCLlTbmfTqkSRfvDLJckMHsirEYqcpJftdIyQbhUNjhnXPjjWqzOfsyxAdtAaepdmdDthJkK");
    string DmQSksf = string("oNQDCszxtfyOwLsszorqvopJlJWKRHydMvcgJrnMqDHSZMzJKKvQTMzFaxARvulYkFAndfQprAEwxEDcYHOqNYGJIEehYyAZOMeENQKssYhkQtHeKovKtstYeaVXANmMPmLHobCodlspZRyuMBACZZmUVQboMCZEKwtUPPWBLFoJNQqAiWWygGHwshZDIsNedhtbVxDReKsrXgaXXgVyMxczFswqEpDtndSyc");
    bool jhXoxFzGFa = false;
    double oHEjxlSAqhyi = 887808.6087421678;
    string maoyCwGrLkWsJ = string("sWzvMMbzJuxFFcnFMjOlLyvgiimQcXBzDOPhKBhxjnyLMOgYWmaAVCJpioLgodLIbynCgUXlCrHoDJAnAMgsAiqqlYlGxVUOdaLBPkGqPEmWbtQQClwnaQbQvaJijSACmncImyzdpvEeLJSzCMzjLrZXIHVtCFyQvpABpJLZWfKsQSqfbfmJgmpznDvOUpC");
    string EqqdbgkY = string("cTVmeqanUehuGbqWcOpNoNFsByhISqpJGbyJEOFETcxvMmknlSTVpIEoYJqzWgrfJalNvYNalXKznPOFeGVVriNamDKuvBwksHRakXrLquPfjQp");
    int PpbuLrKrJtyy = -1960220793;
    string TeeQzErMa = string("zeGWNYFERhGsoImwlIdEfEbRzVfXNpVpwWDoIKVrVYAmVirdMOAWevKwmheAoMzZqUBneplSprTSBshvocNgsDHGbZjdIksMWxPLkPCKXBSRcbBPmnmrwyTKaJgKfaGCBkTUtezxpkEMiMmhLBfFQFTaWofFqxKYwBPwfBd");

    for (int vbATeOPNtSiuGQ = 503336534; vbATeOPNtSiuGQ > 0; vbATeOPNtSiuGQ--) {
        maoyCwGrLkWsJ += TeeQzErMa;
        PpbuLrKrJtyy -= PpbuLrKrJtyy;
    }

    return TeeQzErMa;
}

double XQdCtzpYcajtl::hBeeQoZGUyQLq(double IPdtSIJuyTg)
{
    double eBowQPNlGmofox = 400718.40528220305;
    int JitYNlCU = 875846199;
    int PfYVP = -722570207;

    for (int ZlYrjIJx = 312818211; ZlYrjIJx > 0; ZlYrjIJx--) {
        IPdtSIJuyTg = IPdtSIJuyTg;
        eBowQPNlGmofox -= eBowQPNlGmofox;
        JitYNlCU /= PfYVP;
    }

    return eBowQPNlGmofox;
}

XQdCtzpYcajtl::XQdCtzpYcajtl()
{
    this->gwZcq(false, 150760.25484069574, 197403.5769674498, -158381152);
    this->ksqnTgpT(750263.9912551381, string("thkdKamjQDEMipaqVHgKCOxjAycIsZalaTljdIOJSDmZVDRAFkZOXssCieAJmUARaUovoXAauyHnSpoOKzKdVLNUDINHcDWbzlFQeICFa"), 353925481, -478421.4340420896);
    this->wAyiXOwAVsXotcz(string("PiIhobQgsJsuNDXgAkDzLcvGLR"), true);
    this->WQsHPKWsgcHVMxcP(false, string("EQPPQYFtYqdeGZEROXNBJLnVHfwnhKvqVRUhUvYWLPvwOaPaSOSbZmDmNmsTPYMdaMkbmmjwqyXOrSIQkwrNOeQGhpHlSQbDZNTPYztFhdAesGGNBRkhmSdBjMfVpZGUWvaEyrHgxOdEMyTtqoNrAvOpLFVHfWBonTLWjlxdmixWxkHtNegVzHmooJLynbDsfsGyvby"), string("KJeqWqMiCxSMcJNxaHtjPbWKSBoJQbavLQhjNoXbGEThfkVikmtxCfqfhzjlfApDTFLlGPQgvcsHwxrTKUPyfpjnqePJGFlBDtWugb"));
    this->qHaYDl(string("LCDQgfXiIDOGfLMfWuTOIyKnfxLyiWHLvLCaCeFYwsvvVtUngWsnltoBVOdwlILtithlDkfRtlMiNyBPphfyWvuAMxkWPXCxfivDBlXLgInEqgRsLqmNpJFpGPYHCvDeClrYZxwIwEIYHndiIiWROVdPHWDCt"));
    this->lQtyBIvY(true, true, 558439570, false, 2083142331);
    this->nJkJxFLYWx();
    this->RDEXpYGqmflH(string("RpdbjxEcgNzShHdFmwZPzZXfatfrPoFPKOpyGyRnWRXMXzBqZrgGVFHazuvvGenmzYleGioajcfGtZVcELCvAZtoKpMxUBQmUDffIcyIPxwLRcfuquOkdvOvnKWkpuoVRepJKqzQKGNgjLRZotpwoqcZjxCneTODkDptowxnibGtTeMudWALZLxEfvefGKJmPgcHORNidAmrHbyiGvVXKhfHSaEPjYzx"), true, -3418708, 102664089, 442587975);
    this->JnnZgYEFZwCi(true);
    this->oAsZyfgNAL(-774609.9049137468, 619316724, -932503.4687045842);
    this->ZrPbBECof(-1975266270, string("ioYBdxLERiDlHasfomBjUrRlmSRZtFJXXPppujaxSVFuuLkQgtbJPqdlGxZ"), true, string("lPnrHNZHTrFTtKhHBJNaqkqdslsFbcJOITXFoOjNJPENNHyQeKUUHiboeObMysAYzUGmPuMTYsTJXXaKFVMGViTGxHkMcdRh"));
    this->RnrfbKrbcuq(false);
    this->sGLUNKXlMBUaoUeo(351899.38005427783, -779099.2722115549);
    this->mQYsmpRc(string("lpmfJxdU"), string("moZyBlRMImHZfzevARfoftzfiTnHgXmCNvmnimQOxXbZuHsCNuWkdHRwfJgUWDTcwBGSyMKaKNaJwtrsQzWXXbwYSuDAHNOMoUqWhthSdXCWUOgbeXRuLJFDTuHDKqLfpkpPJCaclttdFUgPWSlhpJpctjxbpCbiLlMdGGmznEojRvHSFWhlmStKcVDuPTPLnUdVRfHdeZRowrckDqbDAOFoGrnjvmDMQAcCvcbNGlXDbD"), string("wbLwcEVoVXCaWwrkaADBawVWRgIOhMgErAqcMPFyVBxUcfCyjzXoBSBCOGAydDfAJEgTHIWuiygBKLzGDxpIQLBiCjiTEVPbWZlXTDuvKhYVUbUKMyKkBbiHmtvsdnJlimmReSvrRHMZSGJVzuKogpdbrXYVyGfgaGRNRdkBCuqpdzxECXDngpidBZCniugcXlJAsdHWzUfJXNEsvCriJVnTPkPJPLkaQpTzRXeTxqDbwVZTQK"), true, -1039581082);
    this->BBcPzJ(string("YDQqOytlRMfgKppASRCfUBcWxNhTqjXeOFusLWNUUVQgPLIsysbaHpnMKvlvshNwBcnKUAqqcZyJCnHQXfoWAIsYpNHyXQNJFHcmJSBzeSapCtKBlfCLqSMgrbDRzofKdKRhlcsAmJNQxPzLKLWYJmSFFqurgRhneiBGmMhGFDaTBFJgAJMExbrrcMwdQgmAvQYbGKOWdRhXNBdzGYQlbO"), false, true);
    this->BImLilXiFCoc();
    this->uxJvYyo(string("XwubYZlTsDzyRTBcrpjVhgUuTBCfLecsDrGuoryFttuyyvPRiBWRfPAEVgIjGFAOvdDbzcGuQWdDMBEMoWsmpJnJaGwHYlxnlLLRNKAvyIAPAWOgG"), -858034.2366634975, false);
    this->TfQsGvMLJ(-1377452690, 910889246, string("UVFbHBFPHwstuzeOMRTfLObFysqPUbfjYQwNjDJDBmYQOUwWhQbroXIOpistJOzMCDBkGPTLXYJpnGagxMpvaoXjLflVrsaMAnkaWsQaaeelCEkBgQXMGtDaYXTYWwYVsXCrUYKSenXDKboPpiWRBSUgqxqaFleKJMgbaIstDQUkEuBKuvWuipqcDxaoatWAIFLCvOBflrFbRsdVcgvbIMvwrLzFri"), 146812458, 453665.2588196884);
    this->VETxeTjES(1856869522, -447215.70339730795);
    this->bzeuPQvbDu(false, 1005059.4625922849, 162004.44628375652, string("UxNJWjjDiUielWORnJGMroBVfpEBcfXYbMQRANkVQwsIlDEjOQrPRRDEcDvtpnLJWnOltieaUrKRTkTiDWJXyTHtnZiviiLHWUxlfQgAZQWHDeWRAAJbwXqanHZ"), false);
    this->aZUxE(-1731193624);
    this->nWeozYlORtGu(645099.5569521079, string("sVyJTJpUrMLqOpVhlFWcjUxvgDxqzdsuPzPVrsXyrjuQMnNNjzbViPsdOTTmVEHlAxuMZxnkXMzbKAsLwaWjTUVOSrKrQRMJitccOyWlSlrPXBcKVyqEJCmrgCxCGcgXTrTCdbGFkGJZtxQJSNuDgASTFQekFPIGjSNrRbPqyqtUPEzUJutAbGZngzEbTKItfspMcYJRbWuaJoQMhEYCP"));
    this->hBeeQoZGUyQLq(707455.3822074484);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CFelSC
{
public:
    bool XlLVwgKqjFeMx;

    CFelSC();
    double VTACCCTmyOL(int jNfleSYmAPYNgp, int XVkfxLnFqseHPC, int MRrTQosLtnjA, int PUCbgsdC, bool QHRHO);
    double GGTrVQyzsaDqj(string VSnWeShdbGdFqi, double fkusptKBnp, string EJmWxrnOQvjq);
    string JTLkSYoheV(string yLePHA, double ShKsXUnWUHuaeiXg, double ZKFsAngPr);
    void gaNVB(int ItCfWzeF, double WGiMmvM, bool zPRyLGJuK, bool yylAPBqleQHB, double UklFczifX);
    double KqfSUvIvxpDdTBp(bool uuVZW, bool msCVYLiTYBlyAy, string RHTrecKGxLzzuYV, double kUhaYddiPO);
    string nxGaBqItUPyS(double PyNDeN, string MrdzIhirYn);
protected:
    string znygoSGj;
    double VVxOVzmmjZmFkG;
    int OrDGaJtWRB;
    int kIyvGzd;

    void INMzeGLU(bool AKcxCjlmLeDEyvQU, double bocJBTpzEKBKJObR, double HaXvQKtIw, bool KRfWFTRGjuxgy, double GdnuZPgmKhMlj);
    double HjMIEmSrghdRe();
    bool dSDOXUDLaew(int rhjOOzQNYe, bool mSyDdPLvHHIS);
private:
    bool OOAQqO;
    string ZXyeMZSzbqyV;
    bool MefqkTNpLWENF;
    double TzcefspIarajr;
    double sIgMOgOZCXiWwVj;
    string yjcIChbWKnYJYmI;

    string SvXSNLiJtAlIkLY(int XNXolvipx);
    int TAjvkWYOMKzyHZBw();
    void pzaKekRBGSD(int iCFZe, bool uFBdESw, string ZOlpoY, double USbssDOc, double fHRxJTlyLJSK);
    void lVfpEof(double TcsKuxHkODLdcVGc, int VqdzrrtgjXUrQ);
    void fwmEp(double fQCTW, int UHLlux, string oCXoPLROY, int yWRujzVpkFWPThj, string aGgnKwSnzqXTs);
    int lxkwcchYZP(int HNdGMcnsppO, int gexOVfWeAHquPvb, int RQxBNPYEiRs, bool noLMbfALrjqcNt, bool uJUjdhggE);
    string CitXyeufdEMbOw(double UNSXk, bool AQuquhbDRqQnlLaT, bool aQRmQZz, bool AfKfFNjdTIdnl);
    void buVHBdcbBNos(bool rVFAMiQVqdn, int lxwDWfITF, bool ylYhOuAAkKs, string whjEoAEMRXKIl, double JlWZZ);
};

double CFelSC::VTACCCTmyOL(int jNfleSYmAPYNgp, int XVkfxLnFqseHPC, int MRrTQosLtnjA, int PUCbgsdC, bool QHRHO)
{
    string MWHUtWSJjyyJQ = string("HuJKOcxkQEhRsvyTyLfhaaMVSTOwiNVPYQTiIALvvWimXoauRHJWrAyEnVFbDThYXpoCJcEJJyIvkSYRoiZkKdMeCCyzJOInErYjefFgoxTUTANxjDoTwnJriNbVZWrCUAuOKkNKbhoKLADkkXUwYdgj");
    int ytCHwNtfQv = 733549236;
    double HUrVOztbm = -95782.596998296;
    int KDlMPEmSZfiy = -1405639597;
    double vZsdK = -776391.2874258758;
    string aYGzjolusDjJ = string("VRRFCZbXSCeUHLNhwMPmxawjnLsmlEPigaoadNXldOaHnjfkpCSrcaYpNlKkHVecwbQIjpsjNRFepcItcxVOjEgZjHizpwaQOhKUtzfPFydoZVSqHKargxugOcorHjsFOOhGRuhkbVujDMjMpCkNGELxrbjTXdYfAkCyrrRZfDhwlaKALXrXodjTtfIeCEpnkVKsWDWXj");
    double oSshaNY = -227296.59959144823;

    if (ytCHwNtfQv > -469998571) {
        for (int vojYgdxKEI = 1095116745; vojYgdxKEI > 0; vojYgdxKEI--) {
            PUCbgsdC = MRrTQosLtnjA;
        }
    }

    for (int JxlswpiSmrDLPF = 890118331; JxlswpiSmrDLPF > 0; JxlswpiSmrDLPF--) {
        continue;
    }

    for (int iRcnqwJAFLMgAKm = 2089483339; iRcnqwJAFLMgAKm > 0; iRcnqwJAFLMgAKm--) {
        HUrVOztbm = oSshaNY;
        XVkfxLnFqseHPC -= jNfleSYmAPYNgp;
    }

    if (vZsdK >= -776391.2874258758) {
        for (int gWKaOd = 756686333; gWKaOd > 0; gWKaOd--) {
            continue;
        }
    }

    for (int wvTTR = 729137858; wvTTR > 0; wvTTR--) {
        XVkfxLnFqseHPC -= jNfleSYmAPYNgp;
    }

    for (int QSodht = 746566584; QSodht > 0; QSodht--) {
        continue;
    }

    if (ytCHwNtfQv == -1244790090) {
        for (int DjVZxlEnWenXj = 751814169; DjVZxlEnWenXj > 0; DjVZxlEnWenXj--) {
            XVkfxLnFqseHPC *= jNfleSYmAPYNgp;
        }
    }

    for (int QUBWPsbVp = 1455601550; QUBWPsbVp > 0; QUBWPsbVp--) {
        continue;
    }

    return oSshaNY;
}

double CFelSC::GGTrVQyzsaDqj(string VSnWeShdbGdFqi, double fkusptKBnp, string EJmWxrnOQvjq)
{
    int whxnslEIzrfmjdxk = -1877570724;
    int YyWnhiFlJU = 1219978973;
    bool vUFRXfBsTTlx = true;
    bool DwsUxlBa = true;
    string dWPCcPgBIXuLLn = string("oHnGYWTKvcdphfHypMTyIoZAvKgbbHYwwTmiEsYyifYRZbCRKmfsNQpTKlZnqsMOHyraVkZxQGomojmHBmgwMSehnjYpJLGnxBLNthDKhwYCXZcrFgApghwCRYpXIkzTtRSBiKUSrsAsOIzqzZbSYtnHinzCnhZSVUmpJcZkkajXobKLHFIIbuhBuhfWHxl");
    string lfqvpJtXiPmi = string("BoWjhiCVSfgozpbNkkfWuOIFEe");
    string gIHIdEykIeGtL = string("MmQMAeQADC");
    string ffOCLS = string("fJgUugkZdpioLmAjBUks");
    string moRGwNUCjtbEPEd = string("xsU");
    string zaBtSjfZFyUzRoz = string("TPupmvkPbsyIUPrVldlydzxUnWRNLSDKVKubHHCpDvkzWdQgxqFPjIqyWxajUMxPYmypokKFCpOnRqmbfWMLBcPOtsRvqMXXeZlQZNoTmIeZORhclkqLAyzLjTCnZqNOleWjvKw");

    if (moRGwNUCjtbEPEd >= string("BoWjhiCVSfgozpbNkkfWuOIFEe")) {
        for (int OfMphLnJUP = 1297412141; OfMphLnJUP > 0; OfMphLnJUP--) {
            dWPCcPgBIXuLLn = EJmWxrnOQvjq;
            zaBtSjfZFyUzRoz += lfqvpJtXiPmi;
        }
    }

    for (int BUVJRqVnvOBLVE = 671956800; BUVJRqVnvOBLVE > 0; BUVJRqVnvOBLVE--) {
        moRGwNUCjtbEPEd += ffOCLS;
        moRGwNUCjtbEPEd += VSnWeShdbGdFqi;
        lfqvpJtXiPmi += gIHIdEykIeGtL;
        zaBtSjfZFyUzRoz = lfqvpJtXiPmi;
    }

    return fkusptKBnp;
}

string CFelSC::JTLkSYoheV(string yLePHA, double ShKsXUnWUHuaeiXg, double ZKFsAngPr)
{
    int OAQPBGsEBQF = -1739521524;
    bool FXJLmh = true;
    bool LOrepaceW = true;
    bool oejSmPgmAKwreJCG = true;
    double DosaoPF = -35875.62196357708;
    double IxleKcRBq = 136461.05466278386;
    string LNLdFTCUJ = string("ynOSiMtBxxShqVNNtFoKVJxCvgEHkaqEBqlFkwEJpLkVvFyulGIkXgdjzkUcGPbNPoHOaelllsZizTdPSAchZqyXbSVJnAvwLLAdAbOEyaRJtktfUjPVaHgMHWtnnjEjfqBxjDixnuyGvaVgQXrultNucNOvAfvRZe");
    double atPohihFn = -942800.2737338169;
    double ldGmWJLuNOAUspWc = -510343.94694203406;

    for (int PBfimpfqzInodK = 519861944; PBfimpfqzInodK > 0; PBfimpfqzInodK--) {
        ZKFsAngPr /= ldGmWJLuNOAUspWc;
        ShKsXUnWUHuaeiXg *= DosaoPF;
        ShKsXUnWUHuaeiXg /= ShKsXUnWUHuaeiXg;
    }

    if (ZKFsAngPr == -35875.62196357708) {
        for (int ILdzqcFtykIjGi = 1460463306; ILdzqcFtykIjGi > 0; ILdzqcFtykIjGi--) {
            ShKsXUnWUHuaeiXg -= DosaoPF;
            ZKFsAngPr -= IxleKcRBq;
        }
    }

    if (ZKFsAngPr > -982136.6568606049) {
        for (int xMXqH = 122032062; xMXqH > 0; xMXqH--) {
            IxleKcRBq *= atPohihFn;
        }
    }

    if (ShKsXUnWUHuaeiXg != -510343.94694203406) {
        for (int nagXh = 441989074; nagXh > 0; nagXh--) {
            FXJLmh = ! FXJLmh;
            ldGmWJLuNOAUspWc -= IxleKcRBq;
        }
    }

    return LNLdFTCUJ;
}

void CFelSC::gaNVB(int ItCfWzeF, double WGiMmvM, bool zPRyLGJuK, bool yylAPBqleQHB, double UklFczifX)
{
    double itkyNXJKFHcc = 502581.4350148124;
    int mdulSvgLAIhQox = -1194053910;
    int GxBkaOetHLJvibJ = -96878452;
    double tCQrnVSYHTnWvmoJ = 501446.6179534161;
    string DWzphb = string("ySUFReyvZhociVoDRummXVYNKmEcZeqYInSAfSawvjGLjJodYYIMCqmqbOAGqQSULtEsPrhVHimlvyGvmFGSCxMACcAvilHABsNMFxlMFLiRAwjVkapjvlEmMXZiemtMRsoYXIxfAleFVRoTFpLihwtDcUSkBIplLeQjoEGkmDpqPFiofRijDUwznXmApIhPGMaywzKCEF");
    bool jYaMPraXFEQVTQ = true;
    bool TYhPdbjKjua = false;

    if (zPRyLGJuK != true) {
        for (int wsFAZCdDdkugdb = 600081470; wsFAZCdDdkugdb > 0; wsFAZCdDdkugdb--) {
            continue;
        }
    }

    if (UklFczifX >= 71342.64582050865) {
        for (int nheAKANfes = 1584144088; nheAKANfes > 0; nheAKANfes--) {
            yylAPBqleQHB = ! TYhPdbjKjua;
            UklFczifX += UklFczifX;
            itkyNXJKFHcc *= tCQrnVSYHTnWvmoJ;
            zPRyLGJuK = yylAPBqleQHB;
        }
    }
}

double CFelSC::KqfSUvIvxpDdTBp(bool uuVZW, bool msCVYLiTYBlyAy, string RHTrecKGxLzzuYV, double kUhaYddiPO)
{
    int gSMoXtntvRh = -1246101284;
    int ktMCHZSM = -1384680230;
    bool XcDnjroITnCgB = true;
    bool PwnEQNv = false;

    for (int QjfekDqVqNIEjNL = 1438988546; QjfekDqVqNIEjNL > 0; QjfekDqVqNIEjNL--) {
        msCVYLiTYBlyAy = msCVYLiTYBlyAy;
        uuVZW = ! msCVYLiTYBlyAy;
        PwnEQNv = XcDnjroITnCgB;
        XcDnjroITnCgB = ! XcDnjroITnCgB;
    }

    if (uuVZW != false) {
        for (int gfdMNFjGI = 1015974907; gfdMNFjGI > 0; gfdMNFjGI--) {
            ktMCHZSM = ktMCHZSM;
            kUhaYddiPO *= kUhaYddiPO;
        }
    }

    for (int CpsttrCwIxnI = 561642358; CpsttrCwIxnI > 0; CpsttrCwIxnI--) {
        uuVZW = msCVYLiTYBlyAy;
    }

    for (int XLpaHzOttEm = 705784557; XLpaHzOttEm > 0; XLpaHzOttEm--) {
        continue;
    }

    for (int VbPfIHnSsxEZp = 1843616286; VbPfIHnSsxEZp > 0; VbPfIHnSsxEZp--) {
        continue;
    }

    for (int gOCEOctZoqGZH = 1386413630; gOCEOctZoqGZH > 0; gOCEOctZoqGZH--) {
        uuVZW = uuVZW;
        uuVZW = uuVZW;
    }

    return kUhaYddiPO;
}

string CFelSC::nxGaBqItUPyS(double PyNDeN, string MrdzIhirYn)
{
    string OmWQEXtjd = string("AepMoDnbFpKwPmFldVlMHBxXnKMFPgaNCTeYA");
    bool VrOLdVwrdVuLalx = false;

    if (VrOLdVwrdVuLalx != false) {
        for (int QSzHspkIOjNknLOT = 1176889542; QSzHspkIOjNknLOT > 0; QSzHspkIOjNknLOT--) {
            MrdzIhirYn = OmWQEXtjd;
        }
    }

    if (VrOLdVwrdVuLalx != false) {
        for (int iwJTRJZoftDhqLhE = 539406116; iwJTRJZoftDhqLhE > 0; iwJTRJZoftDhqLhE--) {
            OmWQEXtjd += MrdzIhirYn;
        }
    }

    for (int wvgluajeDdiBMfw = 1427571257; wvgluajeDdiBMfw > 0; wvgluajeDdiBMfw--) {
        continue;
    }

    for (int NinntARz = 1209269486; NinntARz > 0; NinntARz--) {
        VrOLdVwrdVuLalx = ! VrOLdVwrdVuLalx;
    }

    return OmWQEXtjd;
}

void CFelSC::INMzeGLU(bool AKcxCjlmLeDEyvQU, double bocJBTpzEKBKJObR, double HaXvQKtIw, bool KRfWFTRGjuxgy, double GdnuZPgmKhMlj)
{
    int oLsPGcvamGLBge = 423175653;
    int KCqxeRdSD = 549696503;
    string norOiprzfPG = string("dHWvGhGZBjqSNnFtNaNpCagjoQbYgkGLvNuTIokOVVdHtFNGGkWmOMpUyhFbEroswqTPSWUNcxKQorXBuSKUdeixzRTXcPqoDUomXFxXQoxmgrqZvuMGQsVmfklsdFuUbqBEereAAGDavNKlICJacGbqX");
    string HBWweotJr = string("zqbEQvKSqsYaXBnuZGTpZoMzuDJWFuMTxZvDtCmqkAEYyxDLwGWLxEZkmoDvMTeHLACkCqUAjibhLCcmspGadsZqTwFsuBEctSjHLDdwNMGcQJduovKElWnELufhXgbhEMTcFOPmvsnURtMtxcrixRSdoVnqQKtWnrtjtInKUZEWCMzbAvmWDOPfmdIhvTCBKHPBmTtOdHYTIOySCoaaIDMtdmXWtaJBXfgRyvJQ");

    for (int THYckNC = 1113028557; THYckNC > 0; THYckNC--) {
        continue;
    }

    for (int LkyxeXxtJhPzqebj = 657173997; LkyxeXxtJhPzqebj > 0; LkyxeXxtJhPzqebj--) {
        continue;
    }

    for (int IxnnYtxGY = 840509329; IxnnYtxGY > 0; IxnnYtxGY--) {
        HaXvQKtIw = HaXvQKtIw;
        KRfWFTRGjuxgy = AKcxCjlmLeDEyvQU;
        HaXvQKtIw /= HaXvQKtIw;
    }

    for (int plWQR = 1723930189; plWQR > 0; plWQR--) {
        continue;
    }
}

double CFelSC::HjMIEmSrghdRe()
{
    bool HaLJxMOK = true;
    int DUhVxpcvvpg = 728055595;
    bool OdGDSjMPUEABRZD = false;
    int axyASmWPoe = 793268040;
    int nVBSimUXsVkAdzVg = 717855614;
    bool eojQqQreM = true;
    double JXqEaYQExKjOJ = -861649.595698047;
    int MxxMnWOTuUqCGTM = 556802920;
    bool KzCJNX = false;
    bool wdOqxzaYo = false;

    for (int zooYXFYT = 1532062964; zooYXFYT > 0; zooYXFYT--) {
        HaLJxMOK = ! KzCJNX;
    }

    for (int xyHnKzWZhBYe = 1481410427; xyHnKzWZhBYe > 0; xyHnKzWZhBYe--) {
        wdOqxzaYo = eojQqQreM;
        KzCJNX = ! wdOqxzaYo;
        HaLJxMOK = ! wdOqxzaYo;
        nVBSimUXsVkAdzVg /= axyASmWPoe;
    }

    for (int MSfgUKCPHdM = 1037684250; MSfgUKCPHdM > 0; MSfgUKCPHdM--) {
        continue;
    }

    if (HaLJxMOK == true) {
        for (int nlIpSfBcOLlkfBhZ = 49930934; nlIpSfBcOLlkfBhZ > 0; nlIpSfBcOLlkfBhZ--) {
            HaLJxMOK = ! HaLJxMOK;
            wdOqxzaYo = HaLJxMOK;
            OdGDSjMPUEABRZD = HaLJxMOK;
            OdGDSjMPUEABRZD = ! KzCJNX;
        }
    }

    return JXqEaYQExKjOJ;
}

bool CFelSC::dSDOXUDLaew(int rhjOOzQNYe, bool mSyDdPLvHHIS)
{
    bool nwRhU = false;
    string jaDSVrYNrNs = string("vOHFSySyHKIdrVfffYqfqXLWhQDCmttjhPwAMqQlKGtgWiKizGjWhAAoXnqvCjllhUkhXorOjaSevpXTwroHPoCDKHDftUncGqWLhsBDc");
    bool QhVZYsgHo = false;
    int YaEFs = -1276756506;
    int KuopSarpi = 619959584;
    bool sIlhlpHyCqzB = false;

    if (rhjOOzQNYe != 619959584) {
        for (int uOmupqI = 286708764; uOmupqI > 0; uOmupqI--) {
            QhVZYsgHo = mSyDdPLvHHIS;
            KuopSarpi *= YaEFs;
        }
    }

    if (nwRhU == false) {
        for (int EwFTMfpxeMLCd = 1090858169; EwFTMfpxeMLCd > 0; EwFTMfpxeMLCd--) {
            continue;
        }
    }

    for (int BwrSyCTkG = 1650639290; BwrSyCTkG > 0; BwrSyCTkG--) {
        mSyDdPLvHHIS = nwRhU;
        nwRhU = mSyDdPLvHHIS;
        nwRhU = ! QhVZYsgHo;
        rhjOOzQNYe = YaEFs;
    }

    if (jaDSVrYNrNs != string("vOHFSySyHKIdrVfffYqfqXLWhQDCmttjhPwAMqQlKGtgWiKizGjWhAAoXnqvCjllhUkhXorOjaSevpXTwroHPoCDKHDftUncGqWLhsBDc")) {
        for (int sUpfPYdsxElrRngB = 447028301; sUpfPYdsxElrRngB > 0; sUpfPYdsxElrRngB--) {
            mSyDdPLvHHIS = ! sIlhlpHyCqzB;
            YaEFs /= YaEFs;
            QhVZYsgHo = sIlhlpHyCqzB;
            KuopSarpi /= rhjOOzQNYe;
            nwRhU = ! mSyDdPLvHHIS;
        }
    }

    for (int AutcdUXUEcQf = 2140235023; AutcdUXUEcQf > 0; AutcdUXUEcQf--) {
        sIlhlpHyCqzB = QhVZYsgHo;
        mSyDdPLvHHIS = nwRhU;
        KuopSarpi += YaEFs;
        nwRhU = ! nwRhU;
    }

    return sIlhlpHyCqzB;
}

string CFelSC::SvXSNLiJtAlIkLY(int XNXolvipx)
{
    double KhGuByxA = -799617.7569141573;
    string jOyHXdGPNxIWO = string("MgZmdgVdwSTFkiTNnnmeXUGKplvoMcuckhsmqRWrbpqaQqVGJzsIHZknDfjBpDQhjAvGVQmLhglFdPPorQgfsOsdbVmhrsCiNyHZsXOvbwmTZQJDTAyvPQRygwbiCgItehIZdGzKqzUnyeVoFfEykCpEEkFvrFqjmXpOrxQOrUoSRtCrVDCIYRMvhagniCSw");
    double tPSohxmQgFBEZcH = -880873.6461081306;
    int fTQcxxGfCwYw = 141978408;
    string XMOCWfkD = string("IQHqNZOBPdqYmVcxGIEtJCLGuBrpuEaNdCCItgYYEWIQGlpcdxsiqhSXrzYMHAbqKOUUXSTzTratFxDrDmHdhcxGaL");
    string MEUlZ = string("UPFlXTAMrftYvVHFdUjNJQKLPpSkYkVgYLOCQjqVJCUYiSUqUxJJsOTQZBGB");
    bool wvOogodNgCpyuJcz = true;
    double ElLxReNaJfIWv = -557579.7295354103;
    string JoWLaCJNzkjq = string("YeYYUYuRsfUrASCHHqxOjPfmtRWYzyxDjXxPESxJYUVCxFGQfaWPllheQfQdlHuXGsBoVJRhKEdVsjIctlErqrfVyCOEIttXOHazhviRIbQpycImbcioIFANOgkppHtuIuGWUxMVZbAMmIMgVxvWdTUqCVVUrmAUUnXopATYLIHMoHghPpVcBxISHRJpXPrzofrPMGvJUhCYlECXXQ");
    string BMLEdeGO = string("sXxNHediLaPZcTNlVXEXOVJYZdvVszwzbFOvYUnhJttrWenVrncKfWUOEijzXZWHDbbmKKYkmmLHewvKSLApkneZeJgodKQgHPIpTYXtRYcKacDpujZbeOtCPXVtCIpLSbSGiKZadGBliZFNZPpZSpKwIfMumqRKyRpypwBgcGSuBRMkwd");

    for (int iihABAnBtCdSIVz = 1430077887; iihABAnBtCdSIVz > 0; iihABAnBtCdSIVz--) {
        KhGuByxA /= ElLxReNaJfIWv;
        MEUlZ += BMLEdeGO;
        ElLxReNaJfIWv -= ElLxReNaJfIWv;
    }

    for (int XbRcFCZirZBHlzhH = 1644873554; XbRcFCZirZBHlzhH > 0; XbRcFCZirZBHlzhH--) {
        continue;
    }

    if (MEUlZ >= string("sXxNHediLaPZcTNlVXEXOVJYZdvVszwzbFOvYUnhJttrWenVrncKfWUOEijzXZWHDbbmKKYkmmLHewvKSLApkneZeJgodKQgHPIpTYXtRYcKacDpujZbeOtCPXVtCIpLSbSGiKZadGBliZFNZPpZSpKwIfMumqRKyRpypwBgcGSuBRMkwd")) {
        for (int iGmgScmhcB = 140183789; iGmgScmhcB > 0; iGmgScmhcB--) {
            KhGuByxA *= ElLxReNaJfIWv;
            tPSohxmQgFBEZcH -= tPSohxmQgFBEZcH;
            MEUlZ += BMLEdeGO;
            jOyHXdGPNxIWO = XMOCWfkD;
        }
    }

    return BMLEdeGO;
}

int CFelSC::TAjvkWYOMKzyHZBw()
{
    bool SnDhLlhyZpOTI = false;
    bool PDPBvnCWKkZmlS = true;
    string COFhHYUVWniHCpw = string("gYBvzlWHrncQcmgPPbKjktzeugbgYqviJtzuadIuBMNHSQEGMlopRAZFduvJiZiBDsmZMSIfwMtCtGQwFJlIxWzMahPsVGVqxftQsjAAVUeKgoJEvhgaapNyRALQv");
    bool VlNejgC = true;
    int NNALqcBBBtE = 757163257;
    double RKXmsubGGzH = 137847.3703134808;
    int eKgpdbKUTNiQd = 1149535363;
    string cjkph = string("WMsIOUEFpoYfnayVQJfrpWxgwjzvgVGnojoUDifGYNdllYpzJcTZJBdrizUpkXQEaBNdEXGIthxNYaYTgKnyyZvCWyeMCxHLvOgXxWklTjFWZiNIVUQbhZrRHTCuqyfQkAKFioKOVeJLSrgHzQqXDWVEMHHKimTikcJ");

    for (int VvswG = 952935743; VvswG > 0; VvswG--) {
        continue;
    }

    for (int MbJeTARuuBQsTyai = 273449545; MbJeTARuuBQsTyai > 0; MbJeTARuuBQsTyai--) {
        RKXmsubGGzH = RKXmsubGGzH;
        PDPBvnCWKkZmlS = VlNejgC;
        SnDhLlhyZpOTI = VlNejgC;
    }

    if (NNALqcBBBtE > 1149535363) {
        for (int aNIDmFvtSYVvt = 386083212; aNIDmFvtSYVvt > 0; aNIDmFvtSYVvt--) {
            continue;
        }
    }

    for (int BAobNPZ = 447369873; BAobNPZ > 0; BAobNPZ--) {
        eKgpdbKUTNiQd *= eKgpdbKUTNiQd;
        COFhHYUVWniHCpw = COFhHYUVWniHCpw;
        SnDhLlhyZpOTI = ! VlNejgC;
        cjkph = COFhHYUVWniHCpw;
    }

    return eKgpdbKUTNiQd;
}

void CFelSC::pzaKekRBGSD(int iCFZe, bool uFBdESw, string ZOlpoY, double USbssDOc, double fHRxJTlyLJSK)
{
    bool OkYPAsEXkguuIHg = true;
    bool KoMybFe = true;
    int jKZebbiONlFK = 707914052;

    for (int lwuuMUeWdP = 511056300; lwuuMUeWdP > 0; lwuuMUeWdP--) {
        ZOlpoY += ZOlpoY;
        OkYPAsEXkguuIHg = uFBdESw;
        fHRxJTlyLJSK += fHRxJTlyLJSK;
    }

    for (int xFeCwZFuV = 1919726894; xFeCwZFuV > 0; xFeCwZFuV--) {
        OkYPAsEXkguuIHg = OkYPAsEXkguuIHg;
    }
}

void CFelSC::lVfpEof(double TcsKuxHkODLdcVGc, int VqdzrrtgjXUrQ)
{
    int QIIYzD = 173172031;
    bool uPoRWhNtVBtoXCmQ = true;
    double OsFTPGGhRCdF = 275077.37346724136;
    int CanScjlXwFaAv = 1512186717;
    string zDdPw = string("NmfzMMpwWj");
    string ZapjjkN = string("EzDgkZxDmMenJAlznGmrNLBtXGcemyOvwjMalMOtYgeQaGAERihHpmjQEnJXRAwgscsSECwfuJHrgpkEtIHAJMNLpclvnYSjrLsdwyMZPxmzknGVRK");
    string WkfFbkFIUfaPUr = string("drtaVHntNVlPzDUJOtZSlzEUycjzWtQcNdlQJkQiNjaSCjnbmQqDzIdnGDNQctpihRPiSTkjiDXSwrrWcHypAyDfTaEMaJvAwGIyfHUJzJWJkLuuhXsAgWDLfyyibDypEVjPSIUDEPAwIhXVHoZrbNFnGRrItONeaMBLrSgkTxFOFltruUNtXMqgRRdfnQoCjzvUTQXBSKFMWmaBvbIxfXaTstbofbXvPJnLRBLAVhzzTjjwaSxlXfbn");
    double lrhAjMcGHiD = -449260.2840528379;

    for (int rdfiDdTUfF = 322001020; rdfiDdTUfF > 0; rdfiDdTUfF--) {
        OsFTPGGhRCdF += OsFTPGGhRCdF;
    }
}

void CFelSC::fwmEp(double fQCTW, int UHLlux, string oCXoPLROY, int yWRujzVpkFWPThj, string aGgnKwSnzqXTs)
{
    string aHIIfcNbEhxink = string("irUaQmBYeWrFQJCVOlmXNWpOfaulX");
    int GXnFZJYB = 2031049834;
    int vZxVPwHeBTv = -975528547;

    for (int GLVolfytsocheXm = 631324093; GLVolfytsocheXm > 0; GLVolfytsocheXm--) {
        continue;
    }
}

int CFelSC::lxkwcchYZP(int HNdGMcnsppO, int gexOVfWeAHquPvb, int RQxBNPYEiRs, bool noLMbfALrjqcNt, bool uJUjdhggE)
{
    int rlgxeaiOVmBZjhmG = -237039561;

    return rlgxeaiOVmBZjhmG;
}

string CFelSC::CitXyeufdEMbOw(double UNSXk, bool AQuquhbDRqQnlLaT, bool aQRmQZz, bool AfKfFNjdTIdnl)
{
    double NTNtoGDpW = 1008808.1932157406;
    double ZiRbDi = -668774.991024933;
    string IjaeAYMsPsXLNs = string("RrYraWAWTpkGJuQLkuUnhUqnrUIxsdHdXQCVMFkTtuXWjEvhsSRrfTlMjcXheRGAGkqFIFtaTdbkbrlVlnDCzpTzZrWwRBujIwXijjwhPAiwRKUZmYjnDjSSpJkiNyYTCejhCGstLMaUBaTRhaQjAAZHZeUpLBAoItazDiTFxBFBOGbwXqRBrVAnJsGMkOQhSdDnxmdqVhCGZvBburLpWjKEuRo");
    double MUDVTLVlgqam = -566069.8051288085;
    string sKUSJHYqzSbz = string("MYukgXKLYFPWBUoqrcjGOTYPStNWonoVwVznMBJyklCuJNgpsxCctXnvhUdmEqeTcwidNukpvDdBbKQCPLptZDGHPSzENcRvfcVFgywWkLSJfSAxqEvxkeGNoiQgTOKxnzOOuTPDcWNpkjwtcLalbzPemCpqtCQLYfmowEJOqWEnJEhlfpXCxty");
    string nAEIBPHkOV = string("SkOmbsKzOobPtUNIncDwmEClqROSwIcSlsNUIoRXuIhHFZ");
    int LtJpcIDMjTuXLf = -904483546;

    for (int oLcDkREPeIN = 955804170; oLcDkREPeIN > 0; oLcDkREPeIN--) {
        UNSXk /= UNSXk;
    }

    for (int iGbov = 1268804774; iGbov > 0; iGbov--) {
        AQuquhbDRqQnlLaT = ! AfKfFNjdTIdnl;
        aQRmQZz = ! aQRmQZz;
        IjaeAYMsPsXLNs += IjaeAYMsPsXLNs;
    }

    if (UNSXk == -566069.8051288085) {
        for (int LpwSOYPU = 1394949443; LpwSOYPU > 0; LpwSOYPU--) {
            ZiRbDi *= MUDVTLVlgqam;
            sKUSJHYqzSbz += nAEIBPHkOV;
            AfKfFNjdTIdnl = ! aQRmQZz;
        }
    }

    return nAEIBPHkOV;
}

void CFelSC::buVHBdcbBNos(bool rVFAMiQVqdn, int lxwDWfITF, bool ylYhOuAAkKs, string whjEoAEMRXKIl, double JlWZZ)
{
    string faLmqzWShS = string("utdywwhiVhwGjYcZKZBMfntnCHYhdKSHRQxojCInMBHSJvQcr");
    bool zZGxya = true;
    int znRurRzVWmYZpI = 2041341742;
    double UouoTVh = -1044732.0240850843;
    double yxaVpNQFMUD = -75577.0680877278;
    bool XXqmREzkK = false;
    bool CiRmR = true;
    string vsBGW = string("TxQYWHlIGJYnM");
    int qBNsoynzr = -78867093;

    for (int zuwme = 1782241031; zuwme > 0; zuwme--) {
        UouoTVh *= JlWZZ;
        yxaVpNQFMUD /= UouoTVh;
    }

    for (int GGxzbr = 230718794; GGxzbr > 0; GGxzbr--) {
        whjEoAEMRXKIl = whjEoAEMRXKIl;
    }

    for (int IWWNWswnpvziAX = 1804057644; IWWNWswnpvziAX > 0; IWWNWswnpvziAX--) {
        JlWZZ -= JlWZZ;
        zZGxya = ! zZGxya;
        zZGxya = ! CiRmR;
        JlWZZ -= JlWZZ;
    }

    if (znRurRzVWmYZpI >= -78867093) {
        for (int gKvyFYded = 303347893; gKvyFYded > 0; gKvyFYded--) {
            qBNsoynzr = lxwDWfITF;
        }
    }

    if (qBNsoynzr > -2086563673) {
        for (int FdbfOZtBeXs = 1324626906; FdbfOZtBeXs > 0; FdbfOZtBeXs--) {
            continue;
        }
    }

    for (int zQVVTZFTBH = 962125391; zQVVTZFTBH > 0; zQVVTZFTBH--) {
        yxaVpNQFMUD -= UouoTVh;
        yxaVpNQFMUD += yxaVpNQFMUD;
    }

    for (int lZqCXT = 1574456043; lZqCXT > 0; lZqCXT--) {
        continue;
    }
}

CFelSC::CFelSC()
{
    this->VTACCCTmyOL(-269750505, -1244790090, -469998571, -1445204373, true);
    this->GGTrVQyzsaDqj(string("GBFtfnNGHxxmDnJjTcwdqodvYzvQNVzmAgrAMJbPrWODHrJIyo"), 949126.1454090286, string("wCTPGUdvIOiFjfvqCvHYoxPlxzKEARnOGbDOJgsbKFxixzbMKOXdamcGhtjIlRYxgPQVqNydjCLvhEeypoyWiKqgSmWMrYpdWhPrgrsIaUomJdVFkCmOhNojlbBBvXHFRPDwmMqKMKETWGzavPAZW"));
    this->JTLkSYoheV(string("zIgCfQYWvjgfSvxLRUCofURTOXfaRbRzvDEqoqzJWXQaoUJMeewbVnfGCvkdoWoVD"), 520128.97457358055, -982136.6568606049);
    this->gaNVB(-2060846333, -436202.04644168884, false, true, 71342.64582050865);
    this->KqfSUvIvxpDdTBp(false, false, string("ZcmwUonDWVMgLtvLMZNmPjKfLpcVUvlIhcONjfPtTkwBxtwsxUGGnuUrJYNAnZaWfslQQpjxBEjryLHTnMHximwFEFTMhrKXPZDLMCRWCADJAMNwHIYEPfJbfgjVdLmhvbjfMahLZSFTpMpRiHYdJJWijvZAPNSWhOEavjBAGJVnokOkrqNkVEMDPKoLNyLmQMfYNLcATvYQdOANqkJrLsioiBuEVNKyYxHsHqQauWEfxneYPBocbxZvZCwXqOL"), 70620.49845391221);
    this->nxGaBqItUPyS(-616600.7608024062, string("kXtsdplGIPSTZfETMrcFUxplAghlnhTgJvUwDuRtSGfEptOIHwiuwYsvGTVxvNLPByuzrnkPCihgtLheDYREvrhxvDFhOLBNDNiHOjbSAvXoCwueiIQNgCYYVbDjCcGrOhBsaFwiLigtgMQ"));
    this->INMzeGLU(true, 222326.94253927658, 296189.5194268623, false, 106596.99691107566);
    this->HjMIEmSrghdRe();
    this->dSDOXUDLaew(1509860470, false);
    this->SvXSNLiJtAlIkLY(-1808134901);
    this->TAjvkWYOMKzyHZBw();
    this->pzaKekRBGSD(-242831212, true, string("boKMmppozYZIcIFMbtykUNKUhpzvixzrRyXzayMmRhWDhBQxazigiYgfbaffyoSiuiWjgwTaEUNqALxIQeyFuTLWCMLwSVoqemuIvjImGLmMBDgUkchSGOSzmQBR"), -766800.1818831846, -910573.7231721475);
    this->lVfpEof(-130904.19135866947, -931992841);
    this->fwmEp(355206.68074424507, -1966578231, string("anYbvCCQPLUvHzbFtqJxDhxGGGXjgFuffrOFvZVIwDnMWniUBmzxoMsICjWMrEcCcPosjtNTLNWJnADzprPyMCcBSUvkTXuQkiUUFPzdWqKxjkzkiAztZYvkYAGezVspdNERxNGWMrkNRdCiHFckfiJultsLxdpxGNQtOVGbnoMhLRaBfRZyxdvXsuFfgitUnFhQDRxgyzYtod"), -1868908007, string("BiRxOlDXDishjQLAwEvLeinp"));
    this->lxkwcchYZP(626949004, 1166384300, 691496694, false, true);
    this->CitXyeufdEMbOw(-817614.2552351652, false, true, false);
    this->buVHBdcbBNos(true, -2086563673, true, string("hLRmmbMrcrvpvZxNIyyyWApUjENLXAcBgGYXICWCzqYpYGrtXeibawYxqZntuUsLSRwigrNmPYEtIJAfpeMXnOGddHQRCYckBZdZKZbKPhjvZVLtsDkUl"), -839193.7416971353);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XkNgcxMHA
{
public:
    string XhuKYUqKhpxcer;
    int SCjWRCvXP;
    double GACzhQYgXSJUl;
    double OfrWHQLSXhiSX;

    XkNgcxMHA();
    bool SsSPptHjydce(string hkfElFxUsPJEieJ, bool HhYDAdvczln, int zcnuVyfEsXZIEV, string tlDIs);
protected:
    int GVoIK;
    bool mrUSubmonl;
    string aWnCPbYebVKsV;
    bool OgUFtLOGUKZA;

    double DvwWN();
    string dGEOroRe(bool mUPjZYgjrXN);
    void hvqvniabaaOnH();
    bool qsXyuTlPVTQCIKd(string dJgsq, string Ozgftm);
    int ainsOtGYrF(bool DXUvUndxKrbgRjjf, int UPpJP, string zheMkLZOSzHjppd, double CpUWIMavtzwzTm, int sjLmEJHHQm);
    string onLKtqzcQcIGqCr(int ONODMRRvM, int CGiKQ, bool RyKJVhl, bool eFnLocmVBMkccjH, double nCuKPEIRGwYtmM);
    bool RhQrc(double PQQwlmxzMcr, string SGtCDOZcExvZN, double ZkEhcPO, int YmpBoQkIlTfPmyA, string YmuUOd);
private:
    int qHpjCz;
    string ZGrBePTvtFMUzDf;
    string MmdLAlUZtf;
    int naPXLSPEycYZtHHj;

    void VhGAmVlwxcAKI(bool HadyxKXaLLhY, int pIDsnbk, double dkWcBus, string tddljbxayxENQEAG, string fuMMW);
    string MFLvztHRblbXd(int gYpmWuCEP, int hXwziuXbHJdf, double aveQWEdSRqkjLQ);
    int DSBVqNL();
    double PWjaRrk(string qyUYIp);
    string OMvTl(double OPbVSjY, bool NBusdSPhs, string EWnrf, string SRpdcrnQ);
};

bool XkNgcxMHA::SsSPptHjydce(string hkfElFxUsPJEieJ, bool HhYDAdvczln, int zcnuVyfEsXZIEV, string tlDIs)
{
    bool kLaHhiiuus = false;
    double UbKBTTQiaqpQARh = -78611.71404572407;
    string fLmHReTCktHk = string("xmyNemJdaOGEAVVGwFbSQZUimQbbHhafARgRARJrJYZuwxQeqkDwXBbEdRcWAguDuIrlqczKEpSBcCGxvZeiOfgddmUBHKzQaZItMtsPHjiYMkSdaRoMmzlnEKxwfEVfVhwfCxzcVqZzWHXPFGhAMqFmpTxMvAgKmvxDmjgsJAeUqxAXjPrZtRpVAYgMOpPQJOcAGKVsg");
    bool xodiltPClAgT = false;

    for (int oEDThcKlUqPrxp = 1595181093; oEDThcKlUqPrxp > 0; oEDThcKlUqPrxp--) {
        HhYDAdvczln = ! kLaHhiiuus;
        fLmHReTCktHk = tlDIs;
    }

    return xodiltPClAgT;
}

double XkNgcxMHA::DvwWN()
{
    double PiFXCXefrUcdJS = -908606.7395829072;
    int kFPSkFMkqPUmuvST = -1247397362;

    for (int OCqrFZXluGvF = 807242525; OCqrFZXluGvF > 0; OCqrFZXluGvF--) {
        kFPSkFMkqPUmuvST /= kFPSkFMkqPUmuvST;
        kFPSkFMkqPUmuvST += kFPSkFMkqPUmuvST;
        PiFXCXefrUcdJS = PiFXCXefrUcdJS;
    }

    return PiFXCXefrUcdJS;
}

string XkNgcxMHA::dGEOroRe(bool mUPjZYgjrXN)
{
    int TAXdnSgrEDmA = -278416358;
    double nbogF = -469357.8102847778;
    int hWBLlqgKQvkQeUpB = -332768245;
    int LWcxkWrSgGvLhk = -1963515899;

    for (int UCoGdtUtWOEBt = 184870300; UCoGdtUtWOEBt > 0; UCoGdtUtWOEBt--) {
        hWBLlqgKQvkQeUpB = TAXdnSgrEDmA;
        nbogF += nbogF;
        hWBLlqgKQvkQeUpB = LWcxkWrSgGvLhk;
        mUPjZYgjrXN = mUPjZYgjrXN;
    }

    for (int sQGSc = 171513512; sQGSc > 0; sQGSc--) {
        LWcxkWrSgGvLhk *= hWBLlqgKQvkQeUpB;
    }

    if (mUPjZYgjrXN != false) {
        for (int IVEVbwbqVxaDbLA = 339375010; IVEVbwbqVxaDbLA > 0; IVEVbwbqVxaDbLA--) {
            continue;
        }
    }

    if (TAXdnSgrEDmA < -332768245) {
        for (int cuSycLLctrbb = 1540911017; cuSycLLctrbb > 0; cuSycLLctrbb--) {
            nbogF += nbogF;
        }
    }

    return string("GEWfbjQxdyAmzacCXIfgNPhbtUYDjJhBHqLLouWZtgUtsLhavNCGtNStQXdxdPKjOPIRTUWdxFQWkkuDqQROePGFXmOMAmmkpYRTMihGhcmYEwOjWZiIwRQUqblFmWbdM");
}

void XkNgcxMHA::hvqvniabaaOnH()
{
    double TLMhJ = 830629.9860421281;
    int BNMlPUUgG = -1506281804;
    double ZEGUzZgQ = 882006.4540595226;

    if (TLMhJ != 882006.4540595226) {
        for (int xGXWENQeZZTF = 1177395537; xGXWENQeZZTF > 0; xGXWENQeZZTF--) {
            ZEGUzZgQ *= TLMhJ;
            TLMhJ /= ZEGUzZgQ;
        }
    }

    if (TLMhJ > 830629.9860421281) {
        for (int dvqAjTKqlhsYvjq = 1444161121; dvqAjTKqlhsYvjq > 0; dvqAjTKqlhsYvjq--) {
            ZEGUzZgQ -= ZEGUzZgQ;
            ZEGUzZgQ -= TLMhJ;
            BNMlPUUgG += BNMlPUUgG;
        }
    }

    if (BNMlPUUgG >= -1506281804) {
        for (int QhBGq = 1404698944; QhBGq > 0; QhBGq--) {
            TLMhJ /= TLMhJ;
            ZEGUzZgQ += ZEGUzZgQ;
            ZEGUzZgQ = TLMhJ;
        }
    }

    if (TLMhJ <= 830629.9860421281) {
        for (int vkeJCAsbFtKFz = 1519357917; vkeJCAsbFtKFz > 0; vkeJCAsbFtKFz--) {
            TLMhJ += ZEGUzZgQ;
            BNMlPUUgG += BNMlPUUgG;
        }
    }

    if (BNMlPUUgG == -1506281804) {
        for (int bkUeEILJrwMmQZ = 348652958; bkUeEILJrwMmQZ > 0; bkUeEILJrwMmQZ--) {
            BNMlPUUgG -= BNMlPUUgG;
            BNMlPUUgG -= BNMlPUUgG;
        }
    }
}

bool XkNgcxMHA::qsXyuTlPVTQCIKd(string dJgsq, string Ozgftm)
{
    string qRTQraWjeprN = string("fOYfaUSSXrePOfTQNUdGFRpHDEYIHKQVWUORybNlCATldu");
    double NMFGr = 417318.3719916003;
    double LSigCgdFXzsXvfK = 845106.2039677022;
    string NZvVoxMigHZdaRt = string("hMqnCAIhVggcIiQlmrNZLFZbGNj");
    string hOnWbrNEQepxEc = string("juLPmHKepeFOFhmQCClpoPRKDDbh");
    int TsJwXiMQXA = -678050046;
    double nJTupVgS = 744753.2396582022;

    for (int IBPNwnAZjekHmzDf = 406508492; IBPNwnAZjekHmzDf > 0; IBPNwnAZjekHmzDf--) {
        Ozgftm = dJgsq;
        qRTQraWjeprN = Ozgftm;
    }

    for (int RihsOfHdr = 227492849; RihsOfHdr > 0; RihsOfHdr--) {
        Ozgftm += NZvVoxMigHZdaRt;
        dJgsq = dJgsq;
        dJgsq += Ozgftm;
        hOnWbrNEQepxEc = hOnWbrNEQepxEc;
    }

    return true;
}

int XkNgcxMHA::ainsOtGYrF(bool DXUvUndxKrbgRjjf, int UPpJP, string zheMkLZOSzHjppd, double CpUWIMavtzwzTm, int sjLmEJHHQm)
{
    int emeasmKPaA = 122510718;
    bool NDcoIyqqpqWwuOe = true;
    bool DIpTOlu = true;
    int HAsgqahkuqXhgghb = 2037439679;
    bool ijxJIM = true;
    double XAaHRVipfD = 654402.4239641931;

    if (XAaHRVipfD < -935118.281225149) {
        for (int HQGYmiT = 260006981; HQGYmiT > 0; HQGYmiT--) {
            emeasmKPaA -= HAsgqahkuqXhgghb;
        }
    }

    for (int MsXxwk = 1603105806; MsXxwk > 0; MsXxwk--) {
        continue;
    }

    for (int mBOvrSPGdspuGbzJ = 1570138862; mBOvrSPGdspuGbzJ > 0; mBOvrSPGdspuGbzJ--) {
        NDcoIyqqpqWwuOe = NDcoIyqqpqWwuOe;
        zheMkLZOSzHjppd = zheMkLZOSzHjppd;
        UPpJP -= emeasmKPaA;
    }

    return HAsgqahkuqXhgghb;
}

string XkNgcxMHA::onLKtqzcQcIGqCr(int ONODMRRvM, int CGiKQ, bool RyKJVhl, bool eFnLocmVBMkccjH, double nCuKPEIRGwYtmM)
{
    bool QCJSdCOHwTN = false;
    double cFaBoXhhPSnBw = 106699.12428133769;
    double KtprrPCtGYT = 81576.9521149976;

    return string("KXaFOUCCMFjQnpRghYiuorCVdljdfZOEQMdr");
}

bool XkNgcxMHA::RhQrc(double PQQwlmxzMcr, string SGtCDOZcExvZN, double ZkEhcPO, int YmpBoQkIlTfPmyA, string YmuUOd)
{
    double QvTMLLMHIzrnteLJ = 360068.7405566939;
    string rtrWUkTTRRrhOWHd = string("MWfpFmcwRwGelFqUbioDxQKXu");
    string khtnLYj = string("MOhISlRmdSNmoINeccMQhZiJKAjndMJClfWETTBSdpCDyNJmCzvFrXSgsCdurQUKOhFbzCIoWSzKFjMpBjpzJUqxjwBlCyoKTylPikkrLzuarDVUNRQWcQyOYejZaoAEUjRsSnhbfKZaKvskOzHePFGVKWPEtBSFFbFPdUIkGTAvggjgrhoTIZICDjfdlCdNBicrVPmTzXAsxynZtEZfCHVcKIYztsMuNkgoSTGdhlhzobdHRRn");
    int WzTEnsLFPqIvI = 1464028547;
    int QhvZnxYJtTccZoG = -386733904;
    double jXars = -866299.7507541802;

    for (int rWLFKWUUQ = 1352989326; rWLFKWUUQ > 0; rWLFKWUUQ--) {
        QhvZnxYJtTccZoG /= WzTEnsLFPqIvI;
        khtnLYj = YmuUOd;
    }

    if (PQQwlmxzMcr > -866299.7507541802) {
        for (int OGDcSw = 67479524; OGDcSw > 0; OGDcSw--) {
            jXars *= PQQwlmxzMcr;
            khtnLYj += SGtCDOZcExvZN;
            jXars *= PQQwlmxzMcr;
            rtrWUkTTRRrhOWHd += SGtCDOZcExvZN;
        }
    }

    return true;
}

void XkNgcxMHA::VhGAmVlwxcAKI(bool HadyxKXaLLhY, int pIDsnbk, double dkWcBus, string tddljbxayxENQEAG, string fuMMW)
{
    bool VcCzWR = false;

    if (fuMMW < string("pPOxcIpUSUhkeXJIDTywPgvDpANkObQLgSosWGMGcHzwvtKEbaxMinvyBuvAVaplJeczXEJnaSGQzuELhRokxWaEGFmmDVwejczzmicvsoWMqAjTURgdtAKqyyZLpQiMPCZeXSlTUlDPPWCwQiyHzEllPANPGoZxcejEdTI")) {
        for (int qieVVmDwTvVPsHW = 1724350816; qieVVmDwTvVPsHW > 0; qieVVmDwTvVPsHW--) {
            HadyxKXaLLhY = ! HadyxKXaLLhY;
        }
    }

    for (int QfvzbiHwwaSi = 696641906; QfvzbiHwwaSi > 0; QfvzbiHwwaSi--) {
        fuMMW += fuMMW;
    }

    for (int hGltHOrMToYNjR = 1323971537; hGltHOrMToYNjR > 0; hGltHOrMToYNjR--) {
        tddljbxayxENQEAG = tddljbxayxENQEAG;
    }

    for (int GnVYLGRBTKp = 2080727416; GnVYLGRBTKp > 0; GnVYLGRBTKp--) {
        fuMMW += tddljbxayxENQEAG;
        dkWcBus = dkWcBus;
    }

    if (fuMMW == string("pPOxcIpUSUhkeXJIDTywPgvDpANkObQLgSosWGMGcHzwvtKEbaxMinvyBuvAVaplJeczXEJnaSGQzuELhRokxWaEGFmmDVwejczzmicvsoWMqAjTURgdtAKqyyZLpQiMPCZeXSlTUlDPPWCwQiyHzEllPANPGoZxcejEdTI")) {
        for (int rLtHwvkOViXvZLz = 589028007; rLtHwvkOViXvZLz > 0; rLtHwvkOViXvZLz--) {
            continue;
        }
    }
}

string XkNgcxMHA::MFLvztHRblbXd(int gYpmWuCEP, int hXwziuXbHJdf, double aveQWEdSRqkjLQ)
{
    string dnVOl = string("jUgQmcmZXtgLvUbxTwEkJgiVMUmvcagOFKveQDIcFTVLbriuBwSvpPdUzboYuZscihsTsmemqdtcfZefCvaAFkejooIxerCHbyAyimGpvMeDbtGhCiUDiPLytqkkAoLZwYWbKTDlmePHAwlcpjsZlcbtxKSXjVhXVJrtRe");
    string bqINfIP = string("dulrGXkZkMyOKarFggUBixUVeSe");
    string cujnzRZfBJHy = string("BunWMNQnjHpRxAhoMWJSMczbNkXHmmVuSIGBVxuHNlMSNfbAPQvMIifbntIpuMQVpXpHRubicweVZbORARyhjIAsHqNmDOoGpUx");
    int cNWTqtXxBfGHGYd = -1761829760;
    int eWLqmu = 558906959;
    double maXrRnfbiBxTmV = 956124.049450924;
    string WMdjSqzfbjzN = string("qCimvsPIxldnEvMNZEjQhOxsbdYVaxzGwOpVHtxwgBrAfteydoPAZKgbTFfAneAExfKbyEkmfLkYMHurruUSKZiJMEeNMNFqobRCkecntJBqZGeEAWxxSRbcwCYHDcSkmTAySfUSZWUkFRLrnLTtZNockELPPYXYDmykuWFRlz");
    int aNlCFjzbTM = 1652304501;
    double OHNeloHytR = 154725.050305342;

    for (int bvjUvPPDLI = 111490399; bvjUvPPDLI > 0; bvjUvPPDLI--) {
        dnVOl += WMdjSqzfbjzN;
        WMdjSqzfbjzN += WMdjSqzfbjzN;
    }

    for (int tvhwP = 981603752; tvhwP > 0; tvhwP--) {
        dnVOl = dnVOl;
        maXrRnfbiBxTmV -= aveQWEdSRqkjLQ;
        gYpmWuCEP = hXwziuXbHJdf;
    }

    for (int yMvMITqnGwYkSkxe = 1564086206; yMvMITqnGwYkSkxe > 0; yMvMITqnGwYkSkxe--) {
        continue;
    }

    for (int mcvgge = 1667656144; mcvgge > 0; mcvgge--) {
        WMdjSqzfbjzN = WMdjSqzfbjzN;
    }

    return WMdjSqzfbjzN;
}

int XkNgcxMHA::DSBVqNL()
{
    int ypdFSICbpBM = -434449182;
    bool CtXEQ = true;
    double oswBMEX = 981214.3892620819;
    string mMuzLZeWEcjSaKO = string("XuBWXbGPDZvjNTjyPYBXihCAqabLDYueRAHhzaRPZmUfLBjlxAMxKbAbsbCxuPJUAOvQccuMXTMCXoIRFibF");
    string eYwpIifG = string("zxBwhhZBKlTMlslRXAhKIthFuysCehtrXwMaOHoBCkjLRkXZYkZXaJnCvkvRVIknpdmjScLwloSANTBFsHEoKmTovKBXwgqfHCGrsoIgW");
    bool vErazohDZs = false;
    bool sOiJNLmnxFRH = true;
    bool EKoiXeYZDgzV = false;

    for (int pEYEWfQrPzIo = 716165794; pEYEWfQrPzIo > 0; pEYEWfQrPzIo--) {
        mMuzLZeWEcjSaKO += eYwpIifG;
        CtXEQ = ! sOiJNLmnxFRH;
        sOiJNLmnxFRH = ! EKoiXeYZDgzV;
    }

    for (int lSWLHdiZcr = 184785548; lSWLHdiZcr > 0; lSWLHdiZcr--) {
        mMuzLZeWEcjSaKO = eYwpIifG;
    }

    for (int biNXl = 1361187661; biNXl > 0; biNXl--) {
        continue;
    }

    for (int jptnbbzMSO = 2018924713; jptnbbzMSO > 0; jptnbbzMSO--) {
        eYwpIifG += mMuzLZeWEcjSaKO;
        eYwpIifG += eYwpIifG;
    }

    return ypdFSICbpBM;
}

double XkNgcxMHA::PWjaRrk(string qyUYIp)
{
    double mDDfhhQWPntImm = -278679.5634282294;
    double KTefTltaawaqCy = 468192.9055514539;
    string WiSUEVc = string("KBYVMHiwSkpvfdGLnGXllAzJtEDvNdZIDztVNbgbwhNjnvzKNEvTZdfhMaMcybMKQ");
    double bmnWLasCHvY = -220759.71343890805;
    string aXQCAlyTFdSN = string("bTaJkmumbTMdEnzqpLivEiVkx");
    int RoNxyR = -749915304;

    if (qyUYIp == string("KBYVMHiwSkpvfdGLnGXllAzJtEDvNdZIDztVNbgbwhNjnvzKNEvTZdfhMaMcybMKQ")) {
        for (int xcTkTHeHijWVSGn = 1468509868; xcTkTHeHijWVSGn > 0; xcTkTHeHijWVSGn--) {
            continue;
        }
    }

    if (mDDfhhQWPntImm != -220759.71343890805) {
        for (int tzGcPiaOlRPyrBC = 318502677; tzGcPiaOlRPyrBC > 0; tzGcPiaOlRPyrBC--) {
            aXQCAlyTFdSN += aXQCAlyTFdSN;
            bmnWLasCHvY = KTefTltaawaqCy;
            KTefTltaawaqCy *= bmnWLasCHvY;
            bmnWLasCHvY = KTefTltaawaqCy;
        }
    }

    return bmnWLasCHvY;
}

string XkNgcxMHA::OMvTl(double OPbVSjY, bool NBusdSPhs, string EWnrf, string SRpdcrnQ)
{
    string XTuShlrnht = string("FtoMxKuVrgDgWeLBijXvcOKLOeLsSnsQiNPiNOnfBjaRxeEOrBLNhxkRIHDleZNoUuzxanSyZnDdKOtMMqrPeAgvuElMSGmnSWByIOeduKFQtBNBbvWjwoZIModICkNIXoeFmgepOhOcwjSJUWFNThEmAeTEWEzvAVtGToQQEMxZwhdYuonmY");
    string BtUHrQa = string("ADPwCzInpZOHZCyZxxvUXoOqrPUAjdQf");
    bool lpxhtpmKMi = false;

    if (EWnrf == string("FtoMxKuVrgDgWeLBijXvcOKLOeLsSnsQiNPiNOnfBjaRxeEOrBLNhxkRIHDleZNoUuzxanSyZnDdKOtMMqrPeAgvuElMSGmnSWByIOeduKFQtBNBbvWjwoZIModICkNIXoeFmgepOhOcwjSJUWFNThEmAeTEWEzvAVtGToQQEMxZwhdYuonmY")) {
        for (int nLBHwpDLDXdDv = 752531718; nLBHwpDLDXdDv > 0; nLBHwpDLDXdDv--) {
            SRpdcrnQ += SRpdcrnQ;
            SRpdcrnQ += XTuShlrnht;
            NBusdSPhs = ! NBusdSPhs;
        }
    }

    if (SRpdcrnQ != string("BAoquivMeGPfPVvCSYlQAORwNwtSyQrUwPLtqueeFGEOYnMulsTURSMmifehBZNESURWNzeiTTHqhReWNsnqR")) {
        for (int tLyXwGNK = 917377919; tLyXwGNK > 0; tLyXwGNK--) {
            BtUHrQa = XTuShlrnht;
        }
    }

    for (int lxoeICqr = 856497850; lxoeICqr > 0; lxoeICqr--) {
        EWnrf += BtUHrQa;
    }

    for (int BUeRqXNYHKFW = 1211788880; BUeRqXNYHKFW > 0; BUeRqXNYHKFW--) {
        NBusdSPhs = ! lpxhtpmKMi;
    }

    return BtUHrQa;
}

XkNgcxMHA::XkNgcxMHA()
{
    this->SsSPptHjydce(string("EzyuVgtXFMdIsIdRUziztnlxyrsWOEHlJaeeBmGhQ"), true, -579913919, string("YepnXugNuVFAJFFyiehRbPndnvbBzZsWhYCoEFplEEiIzWoIKSJRMfPtpPnzqwGoHkDKwkpvhaiCxVcccmuAMXcNcnNKjFNrcUmOPesEmMrweZcSVyAkuMyXUnZZwMUtMdgYRYaZwlBBtmFnyJfwNcuItjtICfpMabgQJZDRMuwiFmXeaEGBSrLdKuOyXKLTqkdlFrByFiMeEnICzcBryuUuLJSbNbZQdtSvqscGHvzfTecLyx"));
    this->DvwWN();
    this->dGEOroRe(false);
    this->hvqvniabaaOnH();
    this->qsXyuTlPVTQCIKd(string("FUQgKrNCIHjCbleBBbSjygUNCEnghPFfOglFhhoDPddoRFTdnQlRAUBtxstrXATKPZvInRotDPPiyvpdOuimHzstjXPYCOKgekPbNbBDQKYiQraSaAYpyYudbJMxhxWyBGGTgEIAWvBRjIDHKXBZptAXti"), string("KzzmTtYmDQCmviQpQdYoAsHHJWuzJDPodRceEwNiOatYgYtPMsRVZRuftnnUyWsZn"));
    this->ainsOtGYrF(false, 1811156971, string("ZFGvFLrEzoPzdYWV"), -935118.281225149, -1790136363);
    this->onLKtqzcQcIGqCr(189441541, -122186154, false, false, 470479.0684673397);
    this->RhQrc(867242.4290058179, string("rMkapmZIypsFOHAOfrxSkpATkvvaRJppwIxlVNyaneNKXcMPvxpUgxuLaNFwRytHIucyUJQjIRccwrFQustMYHjoNiOmoa"), -92128.5739256729, -1356064371, string("IrbDEIFQeCuZbOLrKzSpvTOwdsquhIBZhEUoFclqiQRWDCCfjlsPDjSdiLX"));
    this->VhGAmVlwxcAKI(true, -1850593891, -823854.2577039611, string("HQPIWDvkQXfjhURZuCnhsxzlVrmwvaWrMmnTjyhKSOoCiJaWeaEApumXbpWdPNTPlaxaEDxQSRuayBPWtRuwwHUBGBAKiqQGBClsOnDNxNodzOALePXLKMdOFqggtyjcFRYcguoXLnBxjVEeXDsokdIgreHzcsUTLKgfjCiwIwrktjRQDZZxxJvDWOGwwIGRygtkwXosAzfnCqIcugrbpJSVGAu"), string("pPOxcIpUSUhkeXJIDTywPgvDpANkObQLgSosWGMGcHzwvtKEbaxMinvyBuvAVaplJeczXEJnaSGQzuELhRokxWaEGFmmDVwejczzmicvsoWMqAjTURgdtAKqyyZLpQiMPCZeXSlTUlDPPWCwQiyHzEllPANPGoZxcejEdTI"));
    this->MFLvztHRblbXd(1572857037, -2016483061, -729477.4237890863);
    this->DSBVqNL();
    this->PWjaRrk(string("ZKEscNonYMhXnEskrHSQFsloCefQoDRfyoaNyBlGlQkfSpTdKDuzcsAUZoXYopkSIDVjJSeHeWKEBmlGkBfQIVifLDFnQNrmFJmQoFBmPqZWlmdErnCpuVVWvACsIwCiUqCeaYyfVRKNJwGixABzzyZtLaTgThXTWXNSvhqueCaCuePWlEwxxsxzAyDWlgTFVRunjmbYqLTOkblZqmvmbXSPUKffxPMjXKoOoychKpwlC"));
    this->OMvTl(-1038303.6064787804, false, string("BAoquivMeGPfPVvCSYlQAORwNwtSyQrUwPLtqueeFGEOYnMulsTURSMmifehBZNESURWNzeiTTHqhReWNsnqR"), string("GGfkrDmdrRHnPjjBRJVnkDSp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HyMVngpWH
{
public:
    int NtwbWIycFAbpDO;
    double HDMdSctldCycN;
    string ZjZsbnt;
    int PnlvdfBBs;
    string xPBAEyIOlPoO;

    HyMVngpWH();
    double HuPWBz(bool YMdZnicCgHYy, double saNgqUtgxmgxsp, int OMkKmikzpDxz);
    int GIWpmdKvmvWa(bool kBtQUy, string xVdCyClcroVEGU, int grUxPfiskxG, double NGXDASusBvDYTAsg, double vJJNlNobhZNnCG);
    double aTHkxKNTQuZwQ(bool YcticaoJl, int fCckksNPluS, int NJhib, double JDxCGqbIgC, double ucFXTwaeIsHLj);
    int FkzBnnQUnPK(bool ffeVAzaACGca);
    int RpDzJjKywMwQmoVd(string NtoNmEmO, bool nsytYUk);
    double wWqtIi();
protected:
    double wnNeeIHoGL;

    int lxFheQx(string ZgwYkUACmabQt, double qhwoyUXWyOEq, int DtHmI);
    bool ulOcA(double uSlCPxrI);
    double NSVQWsEtjtb(string MGdCi, int ysOvgynFxGTR, double JVaUx);
    double nlZrA(bool MFxaycQivNoyIl, int CCkytklnXq, int jPmfIGE, string SVsay);
    int BHoaQNwisqPrTIkm(bool MWIlvWtqqHFxAg);
    bool ipyFe();
    void jqOTSL();
private:
    string fUXXgyEesUnc;
    bool TbckDEV;
    int DGxVfZXhsnP;
    int KmMmpIoFJPAWpr;

};

double HyMVngpWH::HuPWBz(bool YMdZnicCgHYy, double saNgqUtgxmgxsp, int OMkKmikzpDxz)
{
    string bjoSyVspC = string("eJMWJZVBqrkLfXozkHDfoyUZQqbDBJSGZXNozUmDIouVjSryo");
    bool cGICKx = false;
    bool nxAWPTzRFlx = true;
    bool BaCzzdWTQBo = false;
    double abtgFCTeLHOLu = -561417.4038797865;
    int xDXlTnpJebAn = -1945669934;
    bool iEXmBXt = true;
    int WuyjwIbaTMsoff = -1370676422;
    double hJauewmnIblnUBZ = -157779.66168445876;
    bool kfTIbldQEUbMqk = false;

    for (int CuWSrk = 936920115; CuWSrk > 0; CuWSrk--) {
        cGICKx = BaCzzdWTQBo;
        hJauewmnIblnUBZ = saNgqUtgxmgxsp;
        hJauewmnIblnUBZ = abtgFCTeLHOLu;
    }

    for (int NFngiGH = 298112437; NFngiGH > 0; NFngiGH--) {
        BaCzzdWTQBo = ! BaCzzdWTQBo;
        YMdZnicCgHYy = BaCzzdWTQBo;
        OMkKmikzpDxz -= OMkKmikzpDxz;
    }

    for (int dbHWRaWzuMHUHE = 519338482; dbHWRaWzuMHUHE > 0; dbHWRaWzuMHUHE--) {
        BaCzzdWTQBo = YMdZnicCgHYy;
        iEXmBXt = YMdZnicCgHYy;
    }

    return hJauewmnIblnUBZ;
}

int HyMVngpWH::GIWpmdKvmvWa(bool kBtQUy, string xVdCyClcroVEGU, int grUxPfiskxG, double NGXDASusBvDYTAsg, double vJJNlNobhZNnCG)
{
    double LSiujbyrZ = -998883.7028773079;
    bool loUxfIP = false;

    if (grUxPfiskxG <= -635707652) {
        for (int EnLLcOlDJs = 1969380339; EnLLcOlDJs > 0; EnLLcOlDJs--) {
            continue;
        }
    }

    return grUxPfiskxG;
}

double HyMVngpWH::aTHkxKNTQuZwQ(bool YcticaoJl, int fCckksNPluS, int NJhib, double JDxCGqbIgC, double ucFXTwaeIsHLj)
{
    double GTBbrBuZqzpJX = -958422.8613204226;
    double HsxpLUOLnFNKir = -876930.6240469168;
    string wyWpZQrNJsFPU = string("XuAcmHONuCpKhFVYQZOVgVOPAYZNsnLdrLOGcDEDzFWeWGlqfapUVIQdIswkwneppTsVaDMnOJGlqIXnEYjGPdCvuTJktumfUprcxGkeXYgclIpfksupscfeHsE");
    int TBhHERsw = -726700216;
    bool TqAeQAg = false;
    int kzffC = -109709434;
    double QkHGzbfAlLitUcUK = 146809.23646103262;
    int phjrHm = -1120886828;
    int bWnrFMQRpDTSist = -594804372;

    if (phjrHm < -334879651) {
        for (int QXAsjPJRu = 1114678630; QXAsjPJRu > 0; QXAsjPJRu--) {
            continue;
        }
    }

    for (int ynsPGtlTESWoA = 18678447; ynsPGtlTESWoA > 0; ynsPGtlTESWoA--) {
        continue;
    }

    for (int aGfItYtChWMuinTf = 1403051268; aGfItYtChWMuinTf > 0; aGfItYtChWMuinTf--) {
        fCckksNPluS -= kzffC;
        JDxCGqbIgC = QkHGzbfAlLitUcUK;
    }

    return QkHGzbfAlLitUcUK;
}

int HyMVngpWH::FkzBnnQUnPK(bool ffeVAzaACGca)
{
    bool rBQGhleCqgujI = false;
    int QxFChdImPKhyLVyx = -1905783859;
    bool UKSfRfqEj = false;
    double lUDDeryxVZOmnKI = -934594.0476154551;
    double tawEOwyNJYpXSa = -159524.9425205587;

    if (tawEOwyNJYpXSa >= -934594.0476154551) {
        for (int jkQnPNepNbqHu = 318523414; jkQnPNepNbqHu > 0; jkQnPNepNbqHu--) {
            QxFChdImPKhyLVyx = QxFChdImPKhyLVyx;
            UKSfRfqEj = ffeVAzaACGca;
            UKSfRfqEj = ffeVAzaACGca;
        }
    }

    return QxFChdImPKhyLVyx;
}

int HyMVngpWH::RpDzJjKywMwQmoVd(string NtoNmEmO, bool nsytYUk)
{
    string eUtwiJeJvQE = string("HXfyWHRcfSXBgsOZWjKKXVkPAuRXiIshgeoyDJYtSELotQHDZVvBEOGftvYarIMVGMqzfJkwBDgDVrSQJNEwIsVmbmecWKWOTSJDWunpZpaQhnlENMcEPIygbhWDZWfWwmpmbuWDSuyfIpoDodGRvNRBmEZRHlxocIEtzwslizydFHOKydVyxzlfxvdUXe");
    string VpSKbTTWFaNE = string("uvkHTkaSCVAftaobbrnTDCzOXthDDulnFwVqiYAGzEFBffRYTkMDiLMgmmsGWOXHtlhJtQHksQnVlnuEIesDRJqbFPxsImeGCuZTloZdZwbrbHwcdXPFdVbKHzSjMhfCoLgysGoMQRkWFznoLEzxnSDtMwMmKOnXTpPL");
    string ZrnHSp = string("ARzjduMgLNEGYTrsdWqFHldndlBILXmoefqurLlHidOEvUKWqhemDLLXgkEgZGDZZFkZdoCwqCmJWNQTfyeoNQXKCJhkzcLLJidnnGdftGlvZmIsoDLaQTDKCGdwstsNYyoIhZNHuSpP");
    int CetMIJPWWzJUtp = 820074064;
    double mDvZkvJJiDhZO = -1000257.4589858311;
    double OSkNEHU = -280941.53104772454;
    int yTsSTwCFeL = 1461349368;
    string NqatK = string("TUyeFpTjFmKHLXkoCPaCgeDMzCaafvdnOqHxHcumpjtIbDqFDReRUMWRipIcZbwjHTLVcEzweNWmXpMxZieesvGzMeNfzTiZXXFGRrerVXFwdStCAfDZzcXoEPTPHbpjtBCqOTwsXFJrsxHRAzqjout");
    int VtaLTPweUSJ = -717036231;
    bool tZyDCpS = true;

    if (ZrnHSp >= string("HXfyWHRcfSXBgsOZWjKKXVkPAuRXiIshgeoyDJYtSELotQHDZVvBEOGftvYarIMVGMqzfJkwBDgDVrSQJNEwIsVmbmecWKWOTSJDWunpZpaQhnlENMcEPIygbhWDZWfWwmpmbuWDSuyfIpoDodGRvNRBmEZRHlxocIEtzwslizydFHOKydVyxzlfxvdUXe")) {
        for (int OHXSpv = 1691264507; OHXSpv > 0; OHXSpv--) {
            NtoNmEmO = NqatK;
            nsytYUk = ! nsytYUk;
            eUtwiJeJvQE = NqatK;
        }
    }

    if (ZrnHSp != string("HXfyWHRcfSXBgsOZWjKKXVkPAuRXiIshgeoyDJYtSELotQHDZVvBEOGftvYarIMVGMqzfJkwBDgDVrSQJNEwIsVmbmecWKWOTSJDWunpZpaQhnlENMcEPIygbhWDZWfWwmpmbuWDSuyfIpoDodGRvNRBmEZRHlxocIEtzwslizydFHOKydVyxzlfxvdUXe")) {
        for (int uykEQzlJ = 1552838395; uykEQzlJ > 0; uykEQzlJ--) {
            NqatK = NtoNmEmO;
            eUtwiJeJvQE = eUtwiJeJvQE;
        }
    }

    for (int XBnBpkYiglwkVeqJ = 233125957; XBnBpkYiglwkVeqJ > 0; XBnBpkYiglwkVeqJ--) {
        continue;
    }

    for (int qMsZEEcPmYmpAuQB = 213616231; qMsZEEcPmYmpAuQB > 0; qMsZEEcPmYmpAuQB--) {
        continue;
    }

    return VtaLTPweUSJ;
}

double HyMVngpWH::wWqtIi()
{
    double qdCfWN = 678844.447227557;
    double FiYNvRvgAyOuWZ = 926054.6749556803;
    bool itxBGDejkqwfHn = false;

    if (qdCfWN > 926054.6749556803) {
        for (int oFJafQe = 1654695332; oFJafQe > 0; oFJafQe--) {
            itxBGDejkqwfHn = itxBGDejkqwfHn;
            qdCfWN += qdCfWN;
            qdCfWN += FiYNvRvgAyOuWZ;
            qdCfWN /= FiYNvRvgAyOuWZ;
            qdCfWN = FiYNvRvgAyOuWZ;
        }
    }

    if (itxBGDejkqwfHn == false) {
        for (int CDUPqxehCMuOh = 1751476249; CDUPqxehCMuOh > 0; CDUPqxehCMuOh--) {
            FiYNvRvgAyOuWZ = qdCfWN;
            itxBGDejkqwfHn = itxBGDejkqwfHn;
            qdCfWN /= qdCfWN;
            qdCfWN += qdCfWN;
            FiYNvRvgAyOuWZ = FiYNvRvgAyOuWZ;
            itxBGDejkqwfHn = itxBGDejkqwfHn;
        }
    }

    if (itxBGDejkqwfHn == false) {
        for (int KSSHRgHjyP = 1336269612; KSSHRgHjyP > 0; KSSHRgHjyP--) {
            itxBGDejkqwfHn = itxBGDejkqwfHn;
            qdCfWN = FiYNvRvgAyOuWZ;
            qdCfWN -= qdCfWN;
            itxBGDejkqwfHn = itxBGDejkqwfHn;
            qdCfWN = FiYNvRvgAyOuWZ;
        }
    }

    return FiYNvRvgAyOuWZ;
}

int HyMVngpWH::lxFheQx(string ZgwYkUACmabQt, double qhwoyUXWyOEq, int DtHmI)
{
    double KLSfasHCgIpZHek = 8114.211283043197;
    bool EmbLfyhESMkWa = false;
    bool TeJDcjWs = false;
    double PmezsTOjrOuuHWV = -170537.51421804616;
    bool HkjxXoHFAfTDmga = true;
    bool XzOditiRtRGScB = true;
    int LeHPtdGHKfBK = -2070373865;
    bool rcsjodIJdGBDRlod = false;

    for (int tWtUXrKQuhpNV = 398656724; tWtUXrKQuhpNV > 0; tWtUXrKQuhpNV--) {
        continue;
    }

    return LeHPtdGHKfBK;
}

bool HyMVngpWH::ulOcA(double uSlCPxrI)
{
    string uNekBqYsORkM = string("hYOZtYvrTIGSjjv");
    bool EXUrzLcRNqJ = false;
    int hDozagyZvCEIIg = 2137320961;
    int HbjxCrmnmFWUn = -2053837729;
    string TpcKbfcprkUgTHGd = string("hutoPYNXFRnUiGuQPkbQXFKYpzhyqbrClUDdaLoALHeMScZzvVELHCJsscjSnSrVzMpZONwkMITXQBduKImSkvhwumKlXSvdWIJRnrMKulgGwlSwcEBRlMmlnNNjwNPpgukYOZrEaQWkgztIlqOQzXjlSivDbUokxzfBvf");
    string BwLYrpdAJcnbANw = string("fTceAjrymVTcWJFTUKKHpHYtCnPdAeOknJRpzrzuNzWzSuIscjtLZKTeXdNoQLjKjajQNaDjUQwriiLTYbVJumJVxFKnTDnwqHcRviggFQoBOZxjzIQpVJXCLItWDOFOyWUspRoVBhaaICVmdZaXKZxyQZhytAZbLKcJnwbiYzfZpIqRFkpbkEaIEmk");
    string UsybqToNiTHifO = string("bJceGhdPqTMMTENKbHCTUTOBhiBiSpKWhEcJoxaPmLgjKBeACsjSRJiuuBDlPjcoIEWNsXhzKPllhSLIwZOdymcjjbnRvAsE");
    string sOlTSUhfFPYopOM = string("oosLXlayCUGKbCQJttRMGFVeNUQRmQpJofogQRmgscRGFgYPAVKJBvlNqpYbHgaWrxQKKsIaETcNLDgTRwYxQoBMcBIqDkMhgDcfgaWCkesCCNxmFlbJTYbOESvuaBWkJjYWtIkvJPWUPDLBdHOKBhgErWOdErFPyTLvJuMAZlZoXDfiYRBrLAqYVsouvPBgPNvNyXttVRTAIPdZQPASopMeLlOdfbaCWfZTLoUSrxOcrX");
    double jrnNf = 173312.20450763765;

    for (int UHwrHLH = 902262954; UHwrHLH > 0; UHwrHLH--) {
        UsybqToNiTHifO = BwLYrpdAJcnbANw;
        BwLYrpdAJcnbANw = sOlTSUhfFPYopOM;
    }

    for (int sbuAYcYvRgICTl = 1377034017; sbuAYcYvRgICTl > 0; sbuAYcYvRgICTl--) {
        TpcKbfcprkUgTHGd = TpcKbfcprkUgTHGd;
        BwLYrpdAJcnbANw += uNekBqYsORkM;
    }

    for (int LFQSCMfd = 1712059064; LFQSCMfd > 0; LFQSCMfd--) {
        UsybqToNiTHifO = TpcKbfcprkUgTHGd;
        TpcKbfcprkUgTHGd = BwLYrpdAJcnbANw;
        TpcKbfcprkUgTHGd += sOlTSUhfFPYopOM;
    }

    return EXUrzLcRNqJ;
}

double HyMVngpWH::NSVQWsEtjtb(string MGdCi, int ysOvgynFxGTR, double JVaUx)
{
    bool wmkreMBhfadPOnvJ = true;
    string fVToJhxSRck = string("efeQbYrmEZUVIpc");
    bool ssNKaYknJHTfMs = true;
    double KayZkkmvlNUa = -502938.2632309714;
    double TFMusVPsfCIoYF = -916832.2256376694;
    double KjnusaJAe = 764677.837883426;
    int lwOeclHmRetH = -472284173;

    if (KayZkkmvlNUa >= 739926.4950936616) {
        for (int dzonFAMQ = 747512022; dzonFAMQ > 0; dzonFAMQ--) {
            continue;
        }
    }

    for (int bTsRxGhiZ = 1905660589; bTsRxGhiZ > 0; bTsRxGhiZ--) {
        KjnusaJAe = KjnusaJAe;
    }

    if (wmkreMBhfadPOnvJ != true) {
        for (int HsmFLBnRm = 85030547; HsmFLBnRm > 0; HsmFLBnRm--) {
            lwOeclHmRetH += ysOvgynFxGTR;
            MGdCi += MGdCi;
        }
    }

    return KjnusaJAe;
}

double HyMVngpWH::nlZrA(bool MFxaycQivNoyIl, int CCkytklnXq, int jPmfIGE, string SVsay)
{
    string vPggK = string("JibdCLGrzBdJMAyLRXSaHnJgdRrhbfyYaYSaTPumwVGLzqFgsceVHkmzIqiAfqOvUpgcmnVBVwbJVHuXSRcnWjcacKRPvbRqfBAEzgbsHTloosBhsxjQxgEpiMSzhqSJypXfmojTbYtnxECmCdTDddr");
    bool bKBfaiKe = true;
    double opGGDZmsH = -520995.77716819564;
    bool MeXZKrRNxn = true;
    double BhtaHFaMNpxsX = 873329.6651149917;
    bool AmQThooIeC = true;
    bool EpmXIlMiYS = true;
    string cZFdMUmapWTQKnm = string("BCyIhYecgobKMBEhELzAwT");
    bool CqBxAhsaB = true;
    bool UFJkchyL = true;

    for (int EgSvkOBCaiuPUtc = 792659523; EgSvkOBCaiuPUtc > 0; EgSvkOBCaiuPUtc--) {
        UFJkchyL = ! CqBxAhsaB;
        bKBfaiKe = ! EpmXIlMiYS;
    }

    for (int GXTDzqMUbaPx = 219480593; GXTDzqMUbaPx > 0; GXTDzqMUbaPx--) {
        UFJkchyL = ! CqBxAhsaB;
    }

    return BhtaHFaMNpxsX;
}

int HyMVngpWH::BHoaQNwisqPrTIkm(bool MWIlvWtqqHFxAg)
{
    string gVFID = string("tEsabOkooeefVicxbVELJiMPBjmjYGTXdtOgBKqnEXarmBzGTVgRlkKorGRVfDnKg");

    if (gVFID >= string("tEsabOkooeefVicxbVELJiMPBjmjYGTXdtOgBKqnEXarmBzGTVgRlkKorGRVfDnKg")) {
        for (int cMzeSnkgRlIiKiIa = 414975412; cMzeSnkgRlIiKiIa > 0; cMzeSnkgRlIiKiIa--) {
            MWIlvWtqqHFxAg = MWIlvWtqqHFxAg;
        }
    }

    return 1293832107;
}

bool HyMVngpWH::ipyFe()
{
    int QItMbbgXLH = 1061932592;
    int VMyXOrPRpixDIj = -1337270501;

    if (QItMbbgXLH < -1337270501) {
        for (int UjNNNMRVZFxkLRv = 740649273; UjNNNMRVZFxkLRv > 0; UjNNNMRVZFxkLRv--) {
            VMyXOrPRpixDIj *= VMyXOrPRpixDIj;
            VMyXOrPRpixDIj = QItMbbgXLH;
            VMyXOrPRpixDIj -= VMyXOrPRpixDIj;
            VMyXOrPRpixDIj *= VMyXOrPRpixDIj;
        }
    }

    if (VMyXOrPRpixDIj < -1337270501) {
        for (int LTbBFcXWFzPqlK = 418323610; LTbBFcXWFzPqlK > 0; LTbBFcXWFzPqlK--) {
            QItMbbgXLH = QItMbbgXLH;
            QItMbbgXLH += QItMbbgXLH;
            QItMbbgXLH += VMyXOrPRpixDIj;
            QItMbbgXLH = QItMbbgXLH;
        }
    }

    if (VMyXOrPRpixDIj != 1061932592) {
        for (int XWpDmzRZbWoDtxvP = 492464773; XWpDmzRZbWoDtxvP > 0; XWpDmzRZbWoDtxvP--) {
            QItMbbgXLH += VMyXOrPRpixDIj;
            QItMbbgXLH *= VMyXOrPRpixDIj;
            QItMbbgXLH += QItMbbgXLH;
            VMyXOrPRpixDIj /= VMyXOrPRpixDIj;
            VMyXOrPRpixDIj = VMyXOrPRpixDIj;
            VMyXOrPRpixDIj = VMyXOrPRpixDIj;
        }
    }

    if (VMyXOrPRpixDIj != 1061932592) {
        for (int ANisnslRgXKvE = 812296422; ANisnslRgXKvE > 0; ANisnslRgXKvE--) {
            VMyXOrPRpixDIj = QItMbbgXLH;
            VMyXOrPRpixDIj += QItMbbgXLH;
            VMyXOrPRpixDIj = VMyXOrPRpixDIj;
        }
    }

    return false;
}

void HyMVngpWH::jqOTSL()
{
    int KkRWx = -417772132;
    string bXaGQfEzxNgTD = string("lXbkNNIWZZsHcPCIIGPsBvtSTpvaLhtDMYDnGIPtHJNOUiZDuwHQkhTSzAMyNAtgxrxHcaafCNJedJdxGmWFaBLoIdDSyMVQMeteAZXSRNQWufnoGirCIEKPyeRoVmYpQsqApfkESitRTUZNZBKd");
    bool sALef = false;
    int lBgkGct = -1092203116;

    if (bXaGQfEzxNgTD > string("lXbkNNIWZZsHcPCIIGPsBvtSTpvaLhtDMYDnGIPtHJNOUiZDuwHQkhTSzAMyNAtgxrxHcaafCNJedJdxGmWFaBLoIdDSyMVQMeteAZXSRNQWufnoGirCIEKPyeRoVmYpQsqApfkESitRTUZNZBKd")) {
        for (int EPCZRbpRv = 1202747627; EPCZRbpRv > 0; EPCZRbpRv--) {
            sALef = ! sALef;
        }
    }
}

HyMVngpWH::HyMVngpWH()
{
    this->HuPWBz(true, -38006.04546364909, -1987741879);
    this->GIWpmdKvmvWa(true, string("LJVcMuEoxjoxldDOjYlhKMAmNPEGHhYkebnpseiBqnXuxQplvfbLZTeEasWrBAdytLACEgaWwPgnRVwlrwBqlTsBQvOFWrfuWgDUEMtwPMIIRwRbiznTpNLOjIssHdzWvR"), -635707652, -668362.7102229978, -1023007.5826922656);
    this->aTHkxKNTQuZwQ(false, 4188934, -334879651, 739226.352707013, 952008.9863080061);
    this->FkzBnnQUnPK(true);
    this->RpDzJjKywMwQmoVd(string("rYPKBoNbfcnmeukArWkpegaqIuzZwAlgpShzipAClqfqHajKduXHBrjWBwKgzrdSGHpuoOCKEImgSfXTXoemkdcHsVJpOJelnlLMMUPj"), false);
    this->wWqtIi();
    this->lxFheQx(string("vHgTgPVWeEYEKutQaZXIQoVvSuaDqOfQsviweozeDpfeWZxxwPxqxKLbsyxvLrQapaszMXUrgAHGSkwmbOhsilYidaaPtuxASbfvvouGesiVHTscHDFfbTfCvnlrYYajMeDBYDIcudEvbMGsUiCBgAzIACWDzcZnZavoVoSfJOQOeFHkKLCyHcZFoqLPKXWnytAbIZGzPYJwphjyirVAzefrdqOJatzYTsfvWHU"), 116440.41745490985, 824319560);
    this->ulOcA(-838098.7166924963);
    this->NSVQWsEtjtb(string("xswitbMicemoikFivgmNyCPWDpLkHBNXGRbHUPFVwQDJCHQEekBaeJTRiVMWpKZTeUbXyDZtubLYNzgYlxgTTDurTuXrZDJxMfSxXGsMtaqeHUOnWyPDnetzQggQOlilWqhhrAavngAeLcedXDkhsECWXzlohVQIKrLAYdGksqbUSeRYWJgwVecbkx"), 124803937, 739926.4950936616);
    this->nlZrA(true, 947595276, 1624300819, string("ByhCoFpUMcTLxBXAjdSWzAaJWBaSkroxLnclsiqPdnHGppLJKsGKKYgAmNpCnQhQ"));
    this->BHoaQNwisqPrTIkm(false);
    this->ipyFe();
    this->jqOTSL();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xWOXcdR
{
public:
    double tpgJl;
    double WdWnhYz;

    xWOXcdR();
    bool tPNKUZUdPT(bool notGIsPPPHvEZW);
    int mzGFsuHqG(double DLNyRKOtuHjInnx, bool bhuLyRFoexjr, bool vQsRSOODdLMHmyy);
protected:
    int QmStKoiTa;
    double OZaPQLUdZfV;
    int eUGmm;
    int nbCiAnUjpRh;

    void JuFDGxccBNOh(bool IwydlYIf, string enunVgh, int NxTbcHNoM, int xIiYbB);
    int gmfKguolSr();
    bool JQEaSxdvf(bool MGNsVpq, int ojAFGmjTiMoxyL, bool DPFauMvCeNDAuQ, string DWNSyQEAsojK);
    bool FDwtmnE(double CYvKgTFKJ, string yCjumYRwhUeLZy);
    string ghlik(int gHdcsyyHH, string GYrbzqUVTbsd, bool dOtFuwv, bool NXCTDRpvxbn);
private:
    bool mOrWiIN;
    int DzGiqSbuuUcHsrV;
    string eHwncnERXYXTr;
    bool BGLByLMiHY;

    void IrwvVzMssUjMw();
};

bool xWOXcdR::tPNKUZUdPT(bool notGIsPPPHvEZW)
{
    bool fildxiVpIMhTDP = false;
    string vWIVUTjlEd = string("dQoFsyxkrzdIcKaRaLyjFFxcVFrgEPrtAEXkiNlMtnFpTPWJjVIatdHYclhLikxBhmoDeYIPWatABJUwAlLsyMPKvVhujdfnoZTTZsUjUswvHEdRjMBzhjJAbREQHIBnkGlaLRMiaxDETYUdFhIqpyHeBrQHZCzSQCOpZXaHYoUrOEhWbPsyfBiKXLsYGzzYidaufcZ");
    double DYDpVHN = 366697.3569851053;
    string VDPyGWbmgitLxBmc = string("MPIzETsMKMyiwOccCIkYIACANAccYRluTCiuvvLdIipBCuTQQCuYnc");

    if (fildxiVpIMhTDP == true) {
        for (int ippEgjZLgn = 1649903909; ippEgjZLgn > 0; ippEgjZLgn--) {
            vWIVUTjlEd = VDPyGWbmgitLxBmc;
        }
    }

    return fildxiVpIMhTDP;
}

int xWOXcdR::mzGFsuHqG(double DLNyRKOtuHjInnx, bool bhuLyRFoexjr, bool vQsRSOODdLMHmyy)
{
    bool SNQJafjfyYuiP = false;
    int gJmRMdonyDZUmzP = -2014003065;
    int WfWbFZFkMzqVt = -1562215717;
    int MkyhqAvlxahLOde = -48638807;
    int tPjFPfzmJndE = -1171079581;
    string EuTgNIwPjJpClUV = string("CQAQJOuLWeWXZSVsIcPSeqVlhRyHrojiXInRnVexCsFfSNJIPhQSiVhDetPCdEcNDtdJhmOkSegdahibEFBFcBOYhcTJTYnMCaygXO");
    string icIoK = string("ljOfupDMrbyvouoIINicGRqNhEMUKjdlfgQhcDjdUJqXoHDIypyJPWXIjstsOTRMZMTuvlMzxPTjVYRSCZMBpTvRNIzkfBVdccqfFKBKkiiTRWt");

    for (int DYWGYwpbnPxIbIH = 1013825899; DYWGYwpbnPxIbIH > 0; DYWGYwpbnPxIbIH--) {
        WfWbFZFkMzqVt = MkyhqAvlxahLOde;
        DLNyRKOtuHjInnx = DLNyRKOtuHjInnx;
    }

    for (int YWhLgLifQZJpk = 1654372682; YWhLgLifQZJpk > 0; YWhLgLifQZJpk--) {
        WfWbFZFkMzqVt = tPjFPfzmJndE;
    }

    for (int bQiHIZMpBBdcFtLq = 1305491097; bQiHIZMpBBdcFtLq > 0; bQiHIZMpBBdcFtLq--) {
        continue;
    }

    for (int FwbjxeMvvZNdU = 623057714; FwbjxeMvvZNdU > 0; FwbjxeMvvZNdU--) {
        MkyhqAvlxahLOde /= gJmRMdonyDZUmzP;
    }

    return tPjFPfzmJndE;
}

void xWOXcdR::JuFDGxccBNOh(bool IwydlYIf, string enunVgh, int NxTbcHNoM, int xIiYbB)
{
    int kBqBvGTY = -2122562290;
    int GjGeYwSqJjtNDPL = -130734355;
    bool YxyiUmARIwiC = false;
    double aAepViTsRKdgBVC = -652317.2507322045;

    for (int TezxfOOvAID = 766595194; TezxfOOvAID > 0; TezxfOOvAID--) {
        kBqBvGTY /= xIiYbB;
        IwydlYIf = ! YxyiUmARIwiC;
    }

    for (int qpyXCWgMvTbCyMN = 237982322; qpyXCWgMvTbCyMN > 0; qpyXCWgMvTbCyMN--) {
        kBqBvGTY /= NxTbcHNoM;
        xIiYbB *= xIiYbB;
        GjGeYwSqJjtNDPL /= xIiYbB;
        YxyiUmARIwiC = YxyiUmARIwiC;
    }

    for (int IWhERfSe = 850005423; IWhERfSe > 0; IWhERfSe--) {
        IwydlYIf = IwydlYIf;
    }

    for (int xptSD = 894329635; xptSD > 0; xptSD--) {
        NxTbcHNoM *= kBqBvGTY;
    }
}

int xWOXcdR::gmfKguolSr()
{
    int xtaDWjoKBgJDFF = -1053894876;
    bool UgZHQzEfLP = true;
    double kKatnmqvxkMj = -447787.11768332;
    int CLFtgKSk = 1891571470;
    string UjkYokksGMi = string("BGCOOhWzKOpIPrXwGmgNeKDyqPfefjlLyDOXJkIbeMTTWrANPqDpiBnuRKXeFDDjaFvZUPzUmJFBehrvFUvOMxBeWtVlbDNawuVotKQerxmkVxmoRzoMLvwjffYVWXieTtR");

    if (kKatnmqvxkMj > -447787.11768332) {
        for (int FEYMYkIKlUFqwpEL = 1387481903; FEYMYkIKlUFqwpEL > 0; FEYMYkIKlUFqwpEL--) {
            UjkYokksGMi = UjkYokksGMi;
            UgZHQzEfLP = UgZHQzEfLP;
        }
    }

    for (int HIYZj = 1662204658; HIYZj > 0; HIYZj--) {
        continue;
    }

    return CLFtgKSk;
}

bool xWOXcdR::JQEaSxdvf(bool MGNsVpq, int ojAFGmjTiMoxyL, bool DPFauMvCeNDAuQ, string DWNSyQEAsojK)
{
    double efanNPycRBO = -302379.64832442364;
    int pXVLJYzauiyxdfKX = 249989960;
    double JgDlFGgqIXXGiM = 775810.3750011632;
    bool rYTIcFDazMSK = true;
    bool fyBQfLkAUb = false;
    double JBmgXpcERqcP = 288878.0612437633;
    double sUKRkfR = 626407.1422904644;

    for (int VZvlqFVB = 559304872; VZvlqFVB > 0; VZvlqFVB--) {
        DWNSyQEAsojK += DWNSyQEAsojK;
        JBmgXpcERqcP = sUKRkfR;
        efanNPycRBO = JBmgXpcERqcP;
    }

    if (sUKRkfR != 288878.0612437633) {
        for (int tyxdKaQfcgB = 515322326; tyxdKaQfcgB > 0; tyxdKaQfcgB--) {
            continue;
        }
    }

    for (int KKMUMJKzSZftVh = 674992735; KKMUMJKzSZftVh > 0; KKMUMJKzSZftVh--) {
        continue;
    }

    return fyBQfLkAUb;
}

bool xWOXcdR::FDwtmnE(double CYvKgTFKJ, string yCjumYRwhUeLZy)
{
    string gCfVpScZp = string("tsdLJnlmyevitwNcVklbeUjithUyULvociuGOpxlIZAcufeuPBOaTBhaqPSNQFccecaRkhHPXuZyLORaccWoQQGXHsHKrRhFePdTSYujAmmlWpyXMaBgShGAKwDYUJxZrZSqPNdLWFbjlkaoJpfdKkUeWxCMWNHAkLzMeq");
    bool nWRnAvnQUsp = true;
    bool fhIdAlChQnlrOmJt = false;
    double dEIURfWdSYS = 544470.273528674;
    bool fOWqoUNa = false;
    int aQwEQBe = -10462516;

    for (int HKYqMxlFhjR = 1422179949; HKYqMxlFhjR > 0; HKYqMxlFhjR--) {
        aQwEQBe = aQwEQBe;
    }

    for (int IQmcec = 1925757890; IQmcec > 0; IQmcec--) {
        CYvKgTFKJ -= dEIURfWdSYS;
        fhIdAlChQnlrOmJt = fOWqoUNa;
    }

    return fOWqoUNa;
}

string xWOXcdR::ghlik(int gHdcsyyHH, string GYrbzqUVTbsd, bool dOtFuwv, bool NXCTDRpvxbn)
{
    double hrwhrkQpxbmOF = -839569.3974415127;
    string KijDQHELNbxM = string("GGNevuTRBfakHqNaGLpBnUSNixVUNFAWWgtDghIVKAtaASntaGejgmoWMEgIrTrjLEPxziVMyTjXQOCzcKtJDrxhjBRCAPXUZCLnOFvV");
    int VtfHBtflopJxAptc = -757003584;
    double JLNDoEl = -526989.6445371613;
    bool phvIQQeydspgi = true;

    for (int FjJmQrVmEgYX = 476272607; FjJmQrVmEgYX > 0; FjJmQrVmEgYX--) {
        KijDQHELNbxM += KijDQHELNbxM;
        KijDQHELNbxM += GYrbzqUVTbsd;
        dOtFuwv = ! dOtFuwv;
        KijDQHELNbxM = GYrbzqUVTbsd;
        GYrbzqUVTbsd = KijDQHELNbxM;
    }

    if (hrwhrkQpxbmOF < -526989.6445371613) {
        for (int oQGiqktYSkTh = 1875998666; oQGiqktYSkTh > 0; oQGiqktYSkTh--) {
            GYrbzqUVTbsd += KijDQHELNbxM;
            NXCTDRpvxbn = dOtFuwv;
        }
    }

    for (int klnJwEdvsxg = 481887900; klnJwEdvsxg > 0; klnJwEdvsxg--) {
        continue;
    }

    return KijDQHELNbxM;
}

void xWOXcdR::IrwvVzMssUjMw()
{
    string xqtftarmpoYWMcpl = string("FNhNgJfXllkedkCghHmyGXHzYXYfKmFVJokNdpWiKaNJNVbSlQYoXczZeIJHzeMKckNaGOgZDzbhSpgErrEueMfqtuCIbTFNnrtgooqhPVEbKLjJNPZkzFvnYqiWtXzhVXCXwncOKmeMwClAxHUTlltamtIyKlKeGBgxIHGyWpFxrBBxFAikqDFtm");
    bool dHlywvWCAiBTJToq = false;
    string vPzMuXjztbAtrjYl = string("PGCubxaESlhetTqcmCNkJQQvhzkiMtRxfXxGuHRwZObNwLuuABWBzZiblWpRKbbkMoaRadGYBgMWMexaXLmfUoOFjzuJxanZWBlTBwNaPNbLmYFiKTMDTPJkXykAlanynpsIng");
    int ijmNVgSNoikT = 1046770351;
    int PxtvcveA = -13147413;
    int MGncAZeqk = -1577801870;
    string vTKMjuPVqlFzQ = string("LUpiEUvkHAWTPOUArgJofLjfWLnYWfYWlmnOjQUuSfDezJejIltTLatoyydXTlRoLPVxXVJYwQcREdbdjru");
    string DLswI = string("CmCWLZIlkPKyNCTDkYPSLigVcnboUuTwGAddcEcANnVjMwsfVYQYRkiIkuvkZYEYcOwpLGdiqCfsyJTAuOVZiNAtZIuMWpfXQHMSCTPkTaKZAXvvugGxAIUjUGfRRtJtuNqInBxvJIlyMMwyjlJwFLzDEtCudvWnhzxZcMmNPYJsJHPgrytuzYssGdqsRKTAgAKHvrBdndxWmDEUKpCbagxyOzziBgdbEFTNhpPQnGol");

    if (PxtvcveA >= -1577801870) {
        for (int JucAwjbxIMTmzr = 1633176090; JucAwjbxIMTmzr > 0; JucAwjbxIMTmzr--) {
            DLswI += xqtftarmpoYWMcpl;
            vTKMjuPVqlFzQ = xqtftarmpoYWMcpl;
            vPzMuXjztbAtrjYl = vTKMjuPVqlFzQ;
        }
    }
}

xWOXcdR::xWOXcdR()
{
    this->tPNKUZUdPT(true);
    this->mzGFsuHqG(760456.3720318258, false, false);
    this->JuFDGxccBNOh(true, string("crkXUqqklWHSIsOonMxUDURMHSYZc"), 804179601, 729751277);
    this->gmfKguolSr();
    this->JQEaSxdvf(true, -327380410, true, string("UzQDNOZmnqrGHFefbBzmnAgbowiNiaNNPBKRWtZdDCUsQKmTfctRBQOVHvGidrNtTLYBwvINUBuSriQtfpDkEsTgAZtWpuRcYDNTvxMVsyEtSTkmnHBePMeHHVhxHfYb"));
    this->FDwtmnE(-898815.3423248916, string("fzapqAliWhhEqhYmKpgeKXpbBLTPKJZgRLofvsBYbrMbFeWCfmrrcOAsvnPSFXywzoCyRsUUIVknSByTwTQJLICySukcUKuVriLnqMkIztSLHWBlksuCQservM"));
    this->ghlik(-1737096810, string("rfDTpmhfRXMbthcVxdbgNNVglzsvBDLiHxOVZcYZGuZcRInUGEHvlNWadWOySpfamCTLjkoHhMnTjoSJxbInfoSoYqOpdpRHBDORQZaPVAtSQZEMqTQwOuqTxpDzKgveZFxHneWhzubOpRoygURoFkjDb"), false, true);
    this->IrwvVzMssUjMw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KtUsLdOcHvs
{
public:
    string cLGKEwYwdq;
    bool HAddlpgUYF;
    int gTfByOXVAHIf;
    double OzAfwCAr;
    bool jCutkHDG;

    KtUsLdOcHvs();
protected:
    double IAxnCa;
    int RMFcXMLJFBIJyKs;
    int RzwCZBn;
    int PEZZHkpISEF;
    bool VfVhhB;

    void SLdeCkMmrPXt(double scJhdPV, int ELukzqhdLVn);
    bool nzrExnegehlXYfz(bool cuRvV);
    string fbWmNGilHQKfoPDW(string YyNLCboyBi);
    void kBneWDrh(string niwXGScfKliDjaE, bool qosEJZpl);
    void SeFXSF();
    void gfJwpEGJqMRju(string ogUzB, string MHjCzXaF, bool diHXRpszPPWXz, double mFMHXWIzj);
    string yisbNrwcMR();
private:
    double eqxJf;

    bool akYOOtFqrNYdYpBf(string MtxURc, bool JrOAifLSOetaHB, string SqRRPjGrKFPTTuN, string DwaQZw, bool htIFaRdMQxQe);
    int pHzSPjfGCcOUH(bool CGpEF, string CfYYrpdXBvax);
    bool gxbSG(double igwMM);
    bool TOmxyoF();
    double CxAqUdwOUyBZVbw(double HbPDwL, bool KAxxPzoKQce);
    double Fyvkik(bool mBsYGvMhvgzMQ, bool bYijEfHgGb, double HSeOIqRUssLG);
    int kRqCQeWDEkSRenZ(bool eEbAVJwZmMEkWYZL);
};

void KtUsLdOcHvs::SLdeCkMmrPXt(double scJhdPV, int ELukzqhdLVn)
{
    bool woXnxszWusMeSo = false;
    bool peKbiazCeNrRSy = true;
    int gtWZYMlyv = -14159041;
    bool YEvSJJjmNBxn = true;
    int USCgNKPaniniPbf = 664417353;

    for (int vSBlMZcMIKYvXu = 1875905966; vSBlMZcMIKYvXu > 0; vSBlMZcMIKYvXu--) {
        ELukzqhdLVn -= USCgNKPaniniPbf;
    }

    if (YEvSJJjmNBxn == true) {
        for (int rjoObXprGoHkGafo = 605316202; rjoObXprGoHkGafo > 0; rjoObXprGoHkGafo--) {
            gtWZYMlyv *= gtWZYMlyv;
            USCgNKPaniniPbf /= ELukzqhdLVn;
        }
    }

    for (int ZIBiAvPKeZ = 18027165; ZIBiAvPKeZ > 0; ZIBiAvPKeZ--) {
        scJhdPV -= scJhdPV;
    }

    if (peKbiazCeNrRSy != true) {
        for (int wnwCUbURuvv = 1095256544; wnwCUbURuvv > 0; wnwCUbURuvv--) {
            USCgNKPaniniPbf *= USCgNKPaniniPbf;
            peKbiazCeNrRSy = peKbiazCeNrRSy;
        }
    }

    for (int YEzmPQ = 2052688409; YEzmPQ > 0; YEzmPQ--) {
        USCgNKPaniniPbf /= ELukzqhdLVn;
        woXnxszWusMeSo = ! peKbiazCeNrRSy;
    }
}

bool KtUsLdOcHvs::nzrExnegehlXYfz(bool cuRvV)
{
    double dcFFmXaZ = 206999.15358570547;
    string DeLSz = string("qpRinXoxcBGzIfaPlBDCvJOLUUCCZcfMfLiaRelqQjxJVuvxEXnTZlHspYAiaFdYw");
    int UbJIUEk = 1134114298;
    double piOnlNVk = -574608.2514810413;
    double rpLxIPQ = 742590.9152831848;
    double ptzLsflctWNeR = 554410.0086274206;
    double iydSJZNHBe = 148282.59945444134;

    for (int jtWTEEgGuaWS = 1815943460; jtWTEEgGuaWS > 0; jtWTEEgGuaWS--) {
        ptzLsflctWNeR *= dcFFmXaZ;
        rpLxIPQ /= piOnlNVk;
        ptzLsflctWNeR += piOnlNVk;
        dcFFmXaZ *= dcFFmXaZ;
        ptzLsflctWNeR /= rpLxIPQ;
        iydSJZNHBe *= rpLxIPQ;
    }

    if (dcFFmXaZ == 554410.0086274206) {
        for (int TbDkpxLskZDZD = 112567510; TbDkpxLskZDZD > 0; TbDkpxLskZDZD--) {
            dcFFmXaZ *= iydSJZNHBe;
        }
    }

    if (rpLxIPQ < 148282.59945444134) {
        for (int AZbpMGT = 2006918595; AZbpMGT > 0; AZbpMGT--) {
            rpLxIPQ = ptzLsflctWNeR;
            piOnlNVk *= iydSJZNHBe;
            piOnlNVk -= dcFFmXaZ;
            rpLxIPQ += rpLxIPQ;
        }
    }

    for (int cCtAtrPwf = 1895279030; cCtAtrPwf > 0; cCtAtrPwf--) {
        dcFFmXaZ += dcFFmXaZ;
    }

    if (iydSJZNHBe == 554410.0086274206) {
        for (int nhfOFpiZXVieif = 781113192; nhfOFpiZXVieif > 0; nhfOFpiZXVieif--) {
            ptzLsflctWNeR /= rpLxIPQ;
            iydSJZNHBe += ptzLsflctWNeR;
            UbJIUEk -= UbJIUEk;
            iydSJZNHBe = dcFFmXaZ;
        }
    }

    return cuRvV;
}

string KtUsLdOcHvs::fbWmNGilHQKfoPDW(string YyNLCboyBi)
{
    double luZPbQQhCiY = 210381.18264530835;

    if (luZPbQQhCiY != 210381.18264530835) {
        for (int adXjCaEfk = 1928175029; adXjCaEfk > 0; adXjCaEfk--) {
            luZPbQQhCiY *= luZPbQQhCiY;
        }
    }

    return YyNLCboyBi;
}

void KtUsLdOcHvs::kBneWDrh(string niwXGScfKliDjaE, bool qosEJZpl)
{
    int XnNLpOFIiH = -2048701489;
    double mCLMXnU = 218608.7755337928;
    bool HkBVGl = true;
    double GtIPyeezSg = -886238.0242741929;
    string UfgHUNLVcInMH = string("VNJKsjXnSAxSwOVIBpQHjhoKIVjxxlPFQuNloXdYuNAOQPuWMkACRSSyZwRiymhPgBgNsirRjJVlvQtYWhiiwrzXWQMvGyFxELHryMAXQyiDXUsuFjfraaWRetYuTjSIEnhAwWPMUYJQZNHmkoPVhtqKOnrNkESxulvaPKkDQcxYYMvhfHsAHNmjFHhurSKAFlrLNBUIHCCNBMhbLu");
    bool Kwtar = false;
    string QKQcwfCNtVdMmFr = string("VjoTRyndulazWrzhAEnHRFsHUZXDpCaxhdtKTRZzkaGCKuvfBtpwV");
    bool ZqPoF = true;
    string hKgVsSi = string("UDDtoygzAPdnmQQaRknJDqkVjZssMcaaVQzOEoIsMUwynocIAXpnzelpNdRpQdeEWddBhEoTIrqNAlGSUomqEWLMovRmvCMlDGqqzUhLEWymVEisxWCyFKhuZHfUSZNopnSbPGiNxtNERfOPEWtPDHdvjoTFkCCgZNxdPWihlGjrkAGzlQJXHWyoMGpPSKT");
}

void KtUsLdOcHvs::SeFXSF()
{
    double bJMgJfcdlstbSc = -367121.78593107115;
    double IPveEdxkg = -160320.9991862579;
    bool hAeehuNI = false;
    double XUfevMRff = 434291.9080239155;
    bool XVmNtqqvA = true;
    int mfOhIIipepxr = 834803979;
    bool hZFHlgqzshdHiz = false;
    string cEhBV = string("xmPTqvmOcnBkQuJjkTXjgcflsDKTvhUHCOyWovAHEeLstHllPEMRDKpaG");
    bool dlirXThIOGWEUL = false;

    for (int JWxVtUCxQLDDZaYI = 782473588; JWxVtUCxQLDDZaYI > 0; JWxVtUCxQLDDZaYI--) {
        continue;
    }

    if (IPveEdxkg < 434291.9080239155) {
        for (int FMhTlyOLajRKlNmI = 17033802; FMhTlyOLajRKlNmI > 0; FMhTlyOLajRKlNmI--) {
            dlirXThIOGWEUL = ! hAeehuNI;
        }
    }

    for (int kfTyeAjDPa = 1121924499; kfTyeAjDPa > 0; kfTyeAjDPa--) {
        IPveEdxkg = IPveEdxkg;
        hAeehuNI = ! XVmNtqqvA;
        cEhBV = cEhBV;
    }

    for (int WMQqFNcYpMpNoAro = 1977488040; WMQqFNcYpMpNoAro > 0; WMQqFNcYpMpNoAro--) {
        continue;
    }
}

void KtUsLdOcHvs::gfJwpEGJqMRju(string ogUzB, string MHjCzXaF, bool diHXRpszPPWXz, double mFMHXWIzj)
{
    bool KDNNyez = false;
    string ScVQlJ = string("KTjHnDjKgKfIIyGBnfRNkcbvqnCzIRppWDpPUhEKvDqQoAGlACTOLzswwjFspEwrxwPHnFSaEmywSSssthFCojmnGuxfqYvaYPKCGsoEYMKLZ");
    bool RcVJhxcLaNagXWMv = true;
    string FpudSuIxudNIoj = string("fMa");
    string EoMvCfxdNjalTX = string("EOmHCuldjuPSXXrfbDhNlMHZRQxzmDOrvQoEMOCcdXoYAdStNNbsuLAogJBxDIxGcHWzyYnjEKvWElAAZpTfLmJqnLGQtaEbJQDolBXBmYElqgxyMSiBwrklPYVzSAYgNrtnPVsMTsWDxfetplkpTOxxKKqWxmgYotepFORMgbtrXBTXBgocwJ");

    for (int tIYdFxGInxCgcaH = 124506866; tIYdFxGInxCgcaH > 0; tIYdFxGInxCgcaH--) {
        MHjCzXaF += MHjCzXaF;
        RcVJhxcLaNagXWMv = diHXRpszPPWXz;
    }

    for (int nrkEIEMTtjLzHjEP = 948084594; nrkEIEMTtjLzHjEP > 0; nrkEIEMTtjLzHjEP--) {
        ScVQlJ = FpudSuIxudNIoj;
        FpudSuIxudNIoj += FpudSuIxudNIoj;
    }

    for (int pSLviUvwbTv = 2132292503; pSLviUvwbTv > 0; pSLviUvwbTv--) {
        KDNNyez = diHXRpszPPWXz;
        MHjCzXaF += FpudSuIxudNIoj;
        KDNNyez = diHXRpszPPWXz;
    }
}

string KtUsLdOcHvs::yisbNrwcMR()
{
    string fTrBLyikDlPMOj = string("SLarTaRzUUEdDypWKSxWHZsppHoMUhvMPHJtdFPzztQXyDkVSwwjpSezBoVDlXULYdXEuWyzTCFMzsetGBFfdpRdhwoRuXXBroNiGKEOPjitlTzQGAYJTsEIFkdiRVypevmcddoKTZMIVYuBvuTEMBbCHgVQcBnKHmjfRYYxpQzAvTNCAbQySfiCNKdzpQVSowIHNwusZQq");
    string HypFW = string("SJaMiGvnKhTOrhqSuqyyozuDGKJdByETUNrAiilpDerIQPTcHVtnCTWcxOoEbSjBeYbrWCTgryQBsFRVIcWqAJFflWhDdzuzgreJBwsRMDkapRtpVqSfbMJsveKkHqZjTFReBgUSVlCzReDOZjykHUbJp");
    string PUMRnJVFkHHcxxl = string("SVxcHcyNLxYJMIaPcqVlZMMVcUpjrOLwtnhvykKEarWCDTiKkfEJWvlrMgrncHSRvRhIJIqHYuCXGpDtwgbqvkBe");
    string nOSeRrEdkRhdGRW = string("tqNFJoOzRlTPBhCZtHLskuzQnozPnSNaBZGPxzodJNNPltqMobbvtBwvMutJLWUcHXxXuuRresjvBolDEPRuQLPRBsQEllJuuDcuzvxFMghdiRvclPRrvzgMOZHkeUbJggbVLWvnGizLYETSqjGlEpZOXDyshoNVPMUrmzynjYpTEffCEWuApNvaxkTvVhRHkzgfrMFXSkxhsAQR");
    string jFTrGWcEIXuRXxiw = string("PdTBFfaPwkfHtMyCZCPTQBxthPiouUnEBugGYMmjglaPRSvlDJFkRyFWjVlSWfmFAmftWOToVaCVWpRCpwgePljdfgBrZFoSZaCYhMzFQhTxdYWSDILuzoWqmgkBjFAtzGDKfnuagZhZXrAVgaebpSFSllUAnoBWmSBkqxjxowimNZZWVPZ");

    if (nOSeRrEdkRhdGRW > string("SVxcHcyNLxYJMIaPcqVlZMMVcUpjrOLwtnhvykKEarWCDTiKkfEJWvlrMgrncHSRvRhIJIqHYuCXGpDtwgbqvkBe")) {
        for (int bbHzUqu = 661605006; bbHzUqu > 0; bbHzUqu--) {
            jFTrGWcEIXuRXxiw += HypFW;
            fTrBLyikDlPMOj = PUMRnJVFkHHcxxl;
            fTrBLyikDlPMOj = jFTrGWcEIXuRXxiw;
            fTrBLyikDlPMOj = nOSeRrEdkRhdGRW;
            PUMRnJVFkHHcxxl = PUMRnJVFkHHcxxl;
            fTrBLyikDlPMOj += PUMRnJVFkHHcxxl;
            fTrBLyikDlPMOj = PUMRnJVFkHHcxxl;
            PUMRnJVFkHHcxxl = jFTrGWcEIXuRXxiw;
        }
    }

    if (HypFW < string("tqNFJoOzRlTPBhCZtHLskuzQnozPnSNaBZGPxzodJNNPltqMobbvtBwvMutJLWUcHXxXuuRresjvBolDEPRuQLPRBsQEllJuuDcuzvxFMghdiRvclPRrvzgMOZHkeUbJggbVLWvnGizLYETSqjGlEpZOXDyshoNVPMUrmzynjYpTEffCEWuApNvaxkTvVhRHkzgfrMFXSkxhsAQR")) {
        for (int jkkWxjO = 701389191; jkkWxjO > 0; jkkWxjO--) {
            fTrBLyikDlPMOj += PUMRnJVFkHHcxxl;
            HypFW = nOSeRrEdkRhdGRW;
            jFTrGWcEIXuRXxiw += PUMRnJVFkHHcxxl;
        }
    }

    if (nOSeRrEdkRhdGRW > string("SVxcHcyNLxYJMIaPcqVlZMMVcUpjrOLwtnhvykKEarWCDTiKkfEJWvlrMgrncHSRvRhIJIqHYuCXGpDtwgbqvkBe")) {
        for (int tDHNJaWWWm = 409849495; tDHNJaWWWm > 0; tDHNJaWWWm--) {
            HypFW += PUMRnJVFkHHcxxl;
            jFTrGWcEIXuRXxiw = PUMRnJVFkHHcxxl;
            PUMRnJVFkHHcxxl = fTrBLyikDlPMOj;
            fTrBLyikDlPMOj = nOSeRrEdkRhdGRW;
            PUMRnJVFkHHcxxl = PUMRnJVFkHHcxxl;
        }
    }

    return jFTrGWcEIXuRXxiw;
}

bool KtUsLdOcHvs::akYOOtFqrNYdYpBf(string MtxURc, bool JrOAifLSOetaHB, string SqRRPjGrKFPTTuN, string DwaQZw, bool htIFaRdMQxQe)
{
    bool iwawFJPHwucfgloX = false;
    string diIrsFomaIepl = string("FUcQmriAWYjiEuxibciCzDGXrekxGXGmbnJRgmkklnLTvDSUDdIiioLgWsOnwbXkHMHvTYQjlsWWEKavPxTnDaEKllrbEGJAtNYhqRlJRCcEGcyosdMpqgrhfqIeqcNsxLCMCBwmuCHslpnlRAYMqJAhhlXlWqVVdPcUdOstbagkYefwqCtTvSRjySyQoSATkd");
    bool BGDqek = false;
    string XtSVsixpG = string("lybnUJqzUEmFkeJCVdkrhWtle");
    string WgrEHw = string("XOcsHThzmBFHlKoNlHOI");

    return BGDqek;
}

int KtUsLdOcHvs::pHzSPjfGCcOUH(bool CGpEF, string CfYYrpdXBvax)
{
    double bsREKctMksWOvr = -959375.7745938299;

    if (bsREKctMksWOvr < -959375.7745938299) {
        for (int FcmhCSCRaOM = 1563329702; FcmhCSCRaOM > 0; FcmhCSCRaOM--) {
            continue;
        }
    }

    for (int cDCMxGNoREukVx = 210303736; cDCMxGNoREukVx > 0; cDCMxGNoREukVx--) {
        CGpEF = ! CGpEF;
        bsREKctMksWOvr = bsREKctMksWOvr;
        bsREKctMksWOvr = bsREKctMksWOvr;
    }

    for (int HMVTbOVjtF = 1545818430; HMVTbOVjtF > 0; HMVTbOVjtF--) {
        bsREKctMksWOvr /= bsREKctMksWOvr;
    }

    return -1785572401;
}

bool KtUsLdOcHvs::gxbSG(double igwMM)
{
    double bDfXQ = -102063.0063658772;
    bool yjMEHXsQiR = true;
    double CVgcCKTdys = 931176.6969977686;
    string ZLlrKYgP = string("PxzajoAfSItKJKsJfNdznGbvLfQIHuiVvlmBrtHwOyXrCxpCrDWLdlCIHvHZNyRWiADDtIDHPPRBogCGjotVdMfCuSWhBxSiPYYmesGntyMlPIJEAYzLRXPmrkbPXUm");
    string ogywcbMcna = string("DDAftNZGzpmoZdlCQMaHsDxlWwOSDKrGGHMXthHfDNPKYdzUBFhYEWvCgvIVNhpOZjKhIGmnBohYcwJHRxdoXprAITqpcrITrCwaBdrolwMAqNprYLtTPllSuiBZRu");

    if (ogywcbMcna <= string("PxzajoAfSItKJKsJfNdznGbvLfQIHuiVvlmBrtHwOyXrCxpCrDWLdlCIHvHZNyRWiADDtIDHPPRBogCGjotVdMfCuSWhBxSiPYYmesGntyMlPIJEAYzLRXPmrkbPXUm")) {
        for (int vmnDsNiZXqV = 854578444; vmnDsNiZXqV > 0; vmnDsNiZXqV--) {
            ogywcbMcna += ZLlrKYgP;
            ogywcbMcna = ZLlrKYgP;
            yjMEHXsQiR = yjMEHXsQiR;
        }
    }

    return yjMEHXsQiR;
}

bool KtUsLdOcHvs::TOmxyoF()
{
    double FBNuPYlpbNz = -805297.5486677283;
    double QjskHLgnjyrkZpD = 201958.86962254843;
    double XJRRFMii = 177696.9550271917;
    string fqsxobazOKgpVKg = string("PlWsJQeKfQOFCnWjrSvWOiLxanFhlpPVEuelqASZRFbMJsRBSHIZnTJWoUIXQBJiEmpHMUyrLOZQdbVGUNQQzBgjaqGxsVxwZjWuiDjfZqDUDkr");
    string AgMCOISyJsMmMoz = string("dkVdFtOCpycUfpzyTwYUqLTChsGgGUldWIjQmeIIwhfoFBUNVHwCHEswPoLlWJLLbwFBaTvBgtjrpkvaoVMijwsTMKhcVCZcJhjvTvczsrsWUJKJLePwITbrNRcfCkcPnRLRQLjdwTBDHeJUsUwUxOtduOZfirGRQcqLGAzBUTQSKnjzNFNbojKWwkpnGudXuZWNHiCFXaFpsdDcxoottMYpbqqdXVjkbbdrbardoQJQhB");
    int WZTSMYhyeK = 880848902;
    bool wMYEwsDxd = true;
    double SjPEBgyi = 824320.7226137823;
    int WjymjLwcpOmX = -1623287464;
    double XMDdJ = 976017.638868155;

    if (AgMCOISyJsMmMoz != string("dkVdFtOCpycUfpzyTwYUqLTChsGgGUldWIjQmeIIwhfoFBUNVHwCHEswPoLlWJLLbwFBaTvBgtjrpkvaoVMijwsTMKhcVCZcJhjvTvczsrsWUJKJLePwITbrNRcfCkcPnRLRQLjdwTBDHeJUsUwUxOtduOZfirGRQcqLGAzBUTQSKnjzNFNbojKWwkpnGudXuZWNHiCFXaFpsdDcxoottMYpbqqdXVjkbbdrbardoQJQhB")) {
        for (int VBLYEQZjrYiB = 903392573; VBLYEQZjrYiB > 0; VBLYEQZjrYiB--) {
            continue;
        }
    }

    if (XJRRFMii <= 177696.9550271917) {
        for (int PoUCKwhaXMj = 326609426; PoUCKwhaXMj > 0; PoUCKwhaXMj--) {
            fqsxobazOKgpVKg += AgMCOISyJsMmMoz;
        }
    }

    for (int OfjtRbJsgFfsV = 759127894; OfjtRbJsgFfsV > 0; OfjtRbJsgFfsV--) {
        XMDdJ /= QjskHLgnjyrkZpD;
        SjPEBgyi /= XJRRFMii;
    }

    for (int YzSMTIYinIOdi = 870938821; YzSMTIYinIOdi > 0; YzSMTIYinIOdi--) {
        AgMCOISyJsMmMoz += AgMCOISyJsMmMoz;
    }

    for (int UfdmJGsYD = 1833896691; UfdmJGsYD > 0; UfdmJGsYD--) {
        XMDdJ += SjPEBgyi;
        XJRRFMii = SjPEBgyi;
        XMDdJ = FBNuPYlpbNz;
    }

    return wMYEwsDxd;
}

double KtUsLdOcHvs::CxAqUdwOUyBZVbw(double HbPDwL, bool KAxxPzoKQce)
{
    bool hWsmiVUoe = false;
    int evUTPLmvJk = -1521364629;
    int pHochSbVeb = 2071960710;
    int ugQZyZHaZw = -1533994133;

    if (evUTPLmvJk == 2071960710) {
        for (int MwMdDCj = 567785627; MwMdDCj > 0; MwMdDCj--) {
            ugQZyZHaZw *= ugQZyZHaZw;
            pHochSbVeb *= pHochSbVeb;
        }
    }

    if (evUTPLmvJk > -1533994133) {
        for (int mODAC = 963433285; mODAC > 0; mODAC--) {
            pHochSbVeb -= evUTPLmvJk;
            evUTPLmvJk += ugQZyZHaZw;
            evUTPLmvJk /= pHochSbVeb;
        }
    }

    for (int ouiPJWElsjhzO = 593247207; ouiPJWElsjhzO > 0; ouiPJWElsjhzO--) {
        ugQZyZHaZw /= pHochSbVeb;
        HbPDwL *= HbPDwL;
    }

    return HbPDwL;
}

double KtUsLdOcHvs::Fyvkik(bool mBsYGvMhvgzMQ, bool bYijEfHgGb, double HSeOIqRUssLG)
{
    double vMHdFLYQH = -83362.73488853656;
    string rLOAAyRyWEnfxRYe = string("bklOINFtcjDNbwjwakIyWdGiBtosbJrRNAmuLLxmZcHzvYGPYtiXuJcbMbbecnlrwVWBWrdhzCivOIneFcZEZIkrlMXJZjJhPgO");
    string bTgasATMpahYgAu = string("cqyfNCnLEZgQxTpNzPbfyxJbUzTPrewchAcaheUyiEtmSwGViKcIZsdqBAdSuHVUftiSQdwYuPUxqBmJPywpIpOoJyfHUxkUzAhfNPomZmpF");
    double NAcGfPxOHi = -857404.1067476484;
    int Qxnhf = -1475582107;
    bool xBXDEpNP = true;
    double ncyqB = -739160.0097923718;
    bool NxxeLXCgIrc = true;

    if (NAcGfPxOHi == -83362.73488853656) {
        for (int rRSfrgDSgdoef = 819441613; rRSfrgDSgdoef > 0; rRSfrgDSgdoef--) {
            HSeOIqRUssLG *= ncyqB;
            NxxeLXCgIrc = ! mBsYGvMhvgzMQ;
            vMHdFLYQH *= ncyqB;
            HSeOIqRUssLG *= NAcGfPxOHi;
        }
    }

    if (HSeOIqRUssLG == -739160.0097923718) {
        for (int aUCWhRYbEyTjKTgt = 1116819124; aUCWhRYbEyTjKTgt > 0; aUCWhRYbEyTjKTgt--) {
            vMHdFLYQH = HSeOIqRUssLG;
        }
    }

    for (int PrwNNdgERrZYfMX = 348074497; PrwNNdgERrZYfMX > 0; PrwNNdgERrZYfMX--) {
        rLOAAyRyWEnfxRYe += bTgasATMpahYgAu;
        rLOAAyRyWEnfxRYe = rLOAAyRyWEnfxRYe;
        bYijEfHgGb = ! mBsYGvMhvgzMQ;
    }

    return ncyqB;
}

int KtUsLdOcHvs::kRqCQeWDEkSRenZ(bool eEbAVJwZmMEkWYZL)
{
    double UQbEbeDQuMLkuL = 434591.5306942914;

    for (int sLsHbU = 578907773; sLsHbU > 0; sLsHbU--) {
        eEbAVJwZmMEkWYZL = eEbAVJwZmMEkWYZL;
    }

    if (UQbEbeDQuMLkuL > 434591.5306942914) {
        for (int wIlnpLCdh = 1918727860; wIlnpLCdh > 0; wIlnpLCdh--) {
            eEbAVJwZmMEkWYZL = ! eEbAVJwZmMEkWYZL;
        }
    }

    for (int uEpjixJAN = 482413416; uEpjixJAN > 0; uEpjixJAN--) {
        UQbEbeDQuMLkuL += UQbEbeDQuMLkuL;
    }

    return 1391810432;
}

KtUsLdOcHvs::KtUsLdOcHvs()
{
    this->SLdeCkMmrPXt(-631363.209028474, 2129477919);
    this->nzrExnegehlXYfz(true);
    this->fbWmNGilHQKfoPDW(string("UjSBsQGxjNAuroirFZvLY"));
    this->kBneWDrh(string("aqyzudaFLOhXtvNkDnlfEDawkdZgMCgjGucVDTpQxRDRsDrTtHyTomKRHzuJTYsSPHqQXPEafqYVlBIxEiiYHRkLeoCFKRsyDCyVytODmqURIZMUuAeHpUdAZoYBcYAHcSJEIqlVdnkPskpJFivAlOvOtBlyKGtNAaszZ"), false);
    this->SeFXSF();
    this->gfJwpEGJqMRju(string("inmFebXfwpeZOlzKOwzsTzBBirDCfyFAEgYuJiDFebZjsitjjudZwVguvXWItGtZgeBMlnLtuHVsYRUoOYwWywSbeSyPTxMiBTxbmcRqwmzSflzlkEUrJaGyXLOuSytRagSuEsnZOwYLFX"), string("dpDoZiXdNcmeWOXIxFmNvLoRbYIsmCggfaRmCqOWGZuOgdbsqSFssoaOZQJvWsrQFHgeTpoMmKNPZvWHlcbByJOMftxSmdMoyGyQtWvmtooBjDwhsNmxbVvhlhHcsojjpGDwjSnzCYHwChvpmOLltcJZMzTSfjJjtYaHzdqOyWZcAYCAkYEp"), true, -941520.5341354924);
    this->yisbNrwcMR();
    this->akYOOtFqrNYdYpBf(string("sJcCwwgHEpZfsyNVqxeGVULczsyJQNNKQzLBdFQmiAyfpHChTvCkZbxdSDTLpgSyQmsETiugjFbSoiHqXTlnCWNAvYpxxKvFcFrRxaUPsfFizUoZwZzgSJcktdWXFEfAbVPxmpHXFowHbPFMTPPVayrDnmZdYIjsRxDiMuGRbTsvjxdzlSrTKiOHcJTpcQkLXgLMWJ"), false, string("AubrDeLPpAlkhkehHeTxOXLyMHNhvCHDYplWieahaUwYwPwpsLOHXJyIYmAsSSgoBctOxzteEMrxDfjMLVHkQKOmJzuRCPDOUHGSHOOwHdTUWcusikAzVioFoHrykEjUyFZfDQyPATZBiMNHXIwihXmBxiGCvkqQQtPHmBFneldEySDxsHfWwSSPuePZvPVhUpUUYDLpcVsCtVmeqyDjIj"), string("HplMtcTEkCkiDRPDoIeqMZckPiUQqRVbsSmBuLuBjeuoChklVXXlRBbYnLryuiuStoxuGoOVIGDKFwGZjZJSrlYhnCsVnIAQlZMUxFzdhTOFcHhYGzmTEtFIx"), true);
    this->pHzSPjfGCcOUH(false, string("jkAAJxgGssTnljwVtJfgcQYhUFKnTPCgXacZRZMWIqTqQUcAYQmqiYnryDwkGrOcSHfmltBelbRzGEAsEmcOBqdLyyVVym"));
    this->gxbSG(-561706.16362199);
    this->TOmxyoF();
    this->CxAqUdwOUyBZVbw(-443424.6485099768, false);
    this->Fyvkik(false, false, 1011775.6416047764);
    this->kRqCQeWDEkSRenZ(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zffrvswNdtVUnJ
{
public:
    bool xvInvebCZxu;
    string LlUGcYNQmUohirm;
    double KYzDDnyNZAcCvw;
    bool ALugmofJIz;

    zffrvswNdtVUnJ();
    bool trcMAFIwGUrrORx(string nDULKCarjW);
    int PNKOARmTkHBpuGg(int AvjfiiMYhE, int BeVeMgAAnOk, int KHSAlnLVwLfU, string OeLQqh);
    double mncizhluMkf(int RzmIVyseDC);
    string hKLlFd(int yVGGRGWqgNnPLrn);
    string ftmIZ(string diAeRiygmwWivI, bool QXsTqnuPcNNXQ, int rYZRFxOPGdhZj, double ZliZOEyuP);
    void HtOysYT(bool vEPCNXAJaPNLZKl, bool UIaUtPvi, bool LUUDxs, string OIrnR);
    double RTelkRKMwQe(bool VZygaPDxPeApe);
protected:
    string krXuk;
    bool GjvLzqoVnQo;
    double razgEKLxZDhOOyZs;
    double wGdQDQ;

    int bNRtYpVf(double nBFBRkbBpd, bool aIqHm, double rDTkzOeu, double DwZCzBXtbVHXZcP);
    int TuquIUBwLEvmv();
    string EquBDH();
    bool EkzYRlIhEYb(bool BLjXgj, double ktjbLIFXQlwbnorG, double oeUGUwAJrMoinTn, double SNhhlMFDCxoFDM, string GpsWBuUL);
    int mEotXHIr(int ZYzacVSvJGDwoema, double SqQQASyiFhDopBR, double tjAvWmsZPuTd, string qSOHgLe);
    int NjeEAVsz();
    string dmRhy(int JoBYpbiCthZXHcoy, string RNhRiyL);
private:
    int vXyDQbmkAUuIbGzd;
    double TrvmwFG;
    double IUuamPwbQsRevm;
    double BuKTBPCDq;

    int vJXtTdD();
    int wWtCEYttouK(bool cuMPr, string cqOofUrKHkh, double RxaSMYhlQh, double EgfNrZrsllPaQbRr, bool woIcp);
    string BtAqM();
};

bool zffrvswNdtVUnJ::trcMAFIwGUrrORx(string nDULKCarjW)
{
    double nobKi = -41150.302197213074;
    string SafENjNDepUwv = string("avIHuDcktgUpAGedQAdOwDnSeBpUzdysOTTJGAalUAyJxUxxGqmvYZjgucRlXkERjWsfzEXXRvuHXcBqdFugwRGMjWsuBbDclYcDFLWqVSjINKZvEpvMjHzwzRaMpokorlSEJlpqXnYlsvGeJkVlxqHbkprQtOQSJoYbYIzXUjATyGYZOcjjNy");
    double zwejrIA = -521167.25574181665;
    string ajFChidpxgIb = string("LI");
    bool NrvtOBYHWPnMNY = true;
    int hqcAgMZutYJhqi = -1217846031;
    int xcttEluaKqzQFnDc = -1487794945;
    bool vqYOGWk = false;
    int itfcxHxDoWo = -815038626;

    for (int cBTOwksDOc = 2036154771; cBTOwksDOc > 0; cBTOwksDOc--) {
        itfcxHxDoWo = itfcxHxDoWo;
        nDULKCarjW += nDULKCarjW;
        nobKi *= zwejrIA;
        SafENjNDepUwv = nDULKCarjW;
    }

    return vqYOGWk;
}

int zffrvswNdtVUnJ::PNKOARmTkHBpuGg(int AvjfiiMYhE, int BeVeMgAAnOk, int KHSAlnLVwLfU, string OeLQqh)
{
    int VfnwTdvPNFcbWVNS = -213385171;
    bool OKGjH = true;
    bool dmfTmuIECx = false;
    string PkebyejyiJjrAN = string("cMAeRUuLbGjjpIoXPZlobZqyHlnQccCOaajPpauVIzEjuyTZNwVjwWuRtJzAcpeqFcwfRTZrzZjdBIjywbNXEEMMUwuyZfOsyHvFwnPoXuvylzejjRNMETVOLdNkeWYWWuYpZLxbzwCtRmXKJSdmFAdwuQcZKWUSRsSWBxnpNqJTWYqcEvWolTHaqjOeDLnN");
    double MfTmxtyy = -626959.0964964952;
    double fSdpQlqSx = -163469.63929255278;

    for (int LiacEGnBiqo = 1989850377; LiacEGnBiqo > 0; LiacEGnBiqo--) {
        OeLQqh += OeLQqh;
        VfnwTdvPNFcbWVNS += KHSAlnLVwLfU;
    }

    for (int WRIJLiiKMqhxK = 2007016151; WRIJLiiKMqhxK > 0; WRIJLiiKMqhxK--) {
        continue;
    }

    return VfnwTdvPNFcbWVNS;
}

double zffrvswNdtVUnJ::mncizhluMkf(int RzmIVyseDC)
{
    double WybHjXQTciynRtQ = -205340.48481336315;
    string StZUmcKQGH = string("XKCmAltRRTybCRBPPPRcNjIdHQGbYgbOnKEgxclfJmMxoyVhZNLwSkQWTuEMnQUaQlXWYwuFTO");

    for (int JqUeFFM = 229935216; JqUeFFM > 0; JqUeFFM--) {
        continue;
    }

    for (int qylMg = 1789864662; qylMg > 0; qylMg--) {
        continue;
    }

    for (int Qyamw = 2139690216; Qyamw > 0; Qyamw--) {
        StZUmcKQGH = StZUmcKQGH;
        RzmIVyseDC *= RzmIVyseDC;
        WybHjXQTciynRtQ *= WybHjXQTciynRtQ;
        WybHjXQTciynRtQ = WybHjXQTciynRtQ;
        RzmIVyseDC += RzmIVyseDC;
    }

    if (RzmIVyseDC <= -1504708841) {
        for (int UqfwbwPzXUb = 203348407; UqfwbwPzXUb > 0; UqfwbwPzXUb--) {
            StZUmcKQGH += StZUmcKQGH;
            WybHjXQTciynRtQ = WybHjXQTciynRtQ;
            WybHjXQTciynRtQ += WybHjXQTciynRtQ;
        }
    }

    if (StZUmcKQGH == string("XKCmAltRRTybCRBPPPRcNjIdHQGbYgbOnKEgxclfJmMxoyVhZNLwSkQWTuEMnQUaQlXWYwuFTO")) {
        for (int xMJxz = 1594116758; xMJxz > 0; xMJxz--) {
            WybHjXQTciynRtQ *= WybHjXQTciynRtQ;
        }
    }

    for (int wolvNEeOFSPTFdjU = 1596060204; wolvNEeOFSPTFdjU > 0; wolvNEeOFSPTFdjU--) {
        WybHjXQTciynRtQ /= WybHjXQTciynRtQ;
    }

    if (WybHjXQTciynRtQ != -205340.48481336315) {
        for (int odzAQBMUcvCCcGh = 804782896; odzAQBMUcvCCcGh > 0; odzAQBMUcvCCcGh--) {
            WybHjXQTciynRtQ -= WybHjXQTciynRtQ;
            StZUmcKQGH = StZUmcKQGH;
            WybHjXQTciynRtQ -= WybHjXQTciynRtQ;
            WybHjXQTciynRtQ /= WybHjXQTciynRtQ;
        }
    }

    for (int LYhQV = 1548987335; LYhQV > 0; LYhQV--) {
        WybHjXQTciynRtQ /= WybHjXQTciynRtQ;
    }

    return WybHjXQTciynRtQ;
}

string zffrvswNdtVUnJ::hKLlFd(int yVGGRGWqgNnPLrn)
{
    double uCPuKLPBjew = 289048.60691039584;
    int vyMNQDHNZvGNev = -791430364;
    string YnoQPtPiiLMUJHDS = string("EShzXMRbqnz");
    bool iyRYXgLw = false;
    bool hjLQkSTiSXi = true;
    double anZYLtHBcEKGc = -914532.5404811753;
    int FzXVzmT = 601264468;
    string JtZIfpAmGBmnRfQh = string("OEWKYexQINyFpQbGdScsmATbnowVbaKNjbdZJXqbddKcQenctbsqkIvLRDVrHTeozOMULhwrroRxZbXGNBackZqJHnccfeupMnzSHBPuQiMhdyXgNzxSBkAidajmCgeIHUrcXYWTkXVN");
    string uFKimWXuB = string("YhnINAOiwwQuUWBJoPvCwvGieOcDDxxMJGiUlxFMyTmQgdFGcBKlcBWnPBGNCvTGhbssFOpUzyOheASsTXUOZlbMbznSbjpPsrXbtpKQEBwMpNqLEJaLdtvuQWuRqlYvyVMjVNCzMSaAcDJfUxNcRHFSAkjyaVcdDKXALzaiWMtoCeAngevhDFtcJoYVgEBmiclrmBHonTsbywxvgwjsPApIYmENCJXWuUFXYerAHhRaRSD");

    for (int KCdxKKYDTpV = 813621974; KCdxKKYDTpV > 0; KCdxKKYDTpV--) {
        FzXVzmT -= FzXVzmT;
    }

    for (int elguh = 237879888; elguh > 0; elguh--) {
        continue;
    }

    for (int VIxOdZyiaL = 971346753; VIxOdZyiaL > 0; VIxOdZyiaL--) {
        uCPuKLPBjew *= anZYLtHBcEKGc;
    }

    for (int TTPcuInY = 402421146; TTPcuInY > 0; TTPcuInY--) {
        continue;
    }

    for (int NneNFbUg = 326969621; NneNFbUg > 0; NneNFbUg--) {
        iyRYXgLw = ! hjLQkSTiSXi;
    }

    for (int pSDwyzFVQmj = 881145506; pSDwyzFVQmj > 0; pSDwyzFVQmj--) {
        hjLQkSTiSXi = hjLQkSTiSXi;
        yVGGRGWqgNnPLrn += yVGGRGWqgNnPLrn;
    }

    return uFKimWXuB;
}

string zffrvswNdtVUnJ::ftmIZ(string diAeRiygmwWivI, bool QXsTqnuPcNNXQ, int rYZRFxOPGdhZj, double ZliZOEyuP)
{
    string vzbroaUiRfswH = string("PctFXDlUJuUgyrdoQIpbnZL");
    bool Kfjbm = true;
    bool fVgXnHvDQmp = true;
    int sQTqz = 763701917;
    double NPJnwTpn = -645982.3499871024;
    string EPGbWFByXyVOeEQr = string("ItQMHrJKFnuNifDNgxPmqIjywTrcLShjovJbkgHQLjXE");
    string hWwZeTYoDQvkgOK = string("WCFYzXLPdsZfQKieiIJsVIAjbKEPtmCIwFEVmcpybbfsByMrBnbJ");

    for (int qbAIAJLczkgo = 502674026; qbAIAJLczkgo > 0; qbAIAJLczkgo--) {
        diAeRiygmwWivI = EPGbWFByXyVOeEQr;
    }

    return hWwZeTYoDQvkgOK;
}

void zffrvswNdtVUnJ::HtOysYT(bool vEPCNXAJaPNLZKl, bool UIaUtPvi, bool LUUDxs, string OIrnR)
{
    double ezhenwzVLxxd = -586940.628398606;
    string cPWckjwMbUDRJzzF = string("btsGePlcpcLBkRjGgeBjbOGUQdqXSpFheMhHPWoBwyNrcyLPlawdrpcQtGQxQrUUCmhHrMnNfwMipAYxiAeQLYdObDAHfgyZiwsBMQLHMGvZcKZwCBBbHiRCqtbSpBdlhTQcdaarPjHUUF");

    for (int tOTutMQRqLnJHQvD = 148355301; tOTutMQRqLnJHQvD > 0; tOTutMQRqLnJHQvD--) {
        OIrnR += cPWckjwMbUDRJzzF;
        vEPCNXAJaPNLZKl = UIaUtPvi;
    }

    for (int XmpPEBr = 1632875937; XmpPEBr > 0; XmpPEBr--) {
        vEPCNXAJaPNLZKl = LUUDxs;
        cPWckjwMbUDRJzzF = OIrnR;
    }

    if (LUUDxs == false) {
        for (int bxftnMn = 326223992; bxftnMn > 0; bxftnMn--) {
            UIaUtPvi = ! LUUDxs;
            LUUDxs = ! LUUDxs;
            vEPCNXAJaPNLZKl = ! LUUDxs;
            OIrnR = cPWckjwMbUDRJzzF;
        }
    }

    for (int gwJaxQY = 1545546491; gwJaxQY > 0; gwJaxQY--) {
        vEPCNXAJaPNLZKl = UIaUtPvi;
        UIaUtPvi = vEPCNXAJaPNLZKl;
    }
}

double zffrvswNdtVUnJ::RTelkRKMwQe(bool VZygaPDxPeApe)
{
    bool RgToujFVIfXlZl = false;
    string iUaqjMboOdXp = string("AqAhfkmmRUGnTYxiWdezQhdRVSpxonpBomWVFficXOLybQYWIMlfeGhAOpedjcdPjqVgdrmMXiJkaXuRsvWYhtssPwZjTlpTIeKdKYEaMMbrbZvMmOIMhplzZWMiELDZSEEQTDaMhZOnQTUodXYWMvzxQaRdlYUNGPhAjmyernGZAPtZSglxUIwfkleyfBn");
    double BVayYYeJ = 415802.8610031871;
    double XftuqkNc = -481412.4882320235;
    int YmIZBVkDsYpwSX = -1438244289;

    if (BVayYYeJ > 415802.8610031871) {
        for (int bwVdUb = 1833280165; bwVdUb > 0; bwVdUb--) {
            VZygaPDxPeApe = RgToujFVIfXlZl;
        }
    }

    if (XftuqkNc >= 415802.8610031871) {
        for (int ejVYiFSiFJQCv = 1442159755; ejVYiFSiFJQCv > 0; ejVYiFSiFJQCv--) {
            iUaqjMboOdXp = iUaqjMboOdXp;
            RgToujFVIfXlZl = RgToujFVIfXlZl;
        }
    }

    if (VZygaPDxPeApe != true) {
        for (int dzHUj = 1590783678; dzHUj > 0; dzHUj--) {
            RgToujFVIfXlZl = VZygaPDxPeApe;
            RgToujFVIfXlZl = ! RgToujFVIfXlZl;
        }
    }

    return XftuqkNc;
}

int zffrvswNdtVUnJ::bNRtYpVf(double nBFBRkbBpd, bool aIqHm, double rDTkzOeu, double DwZCzBXtbVHXZcP)
{
    int xFBoihHgpsRIzCN = 446428175;
    int RALEpWPVjE = 753103225;

    for (int HvfGkzu = 331409710; HvfGkzu > 0; HvfGkzu--) {
        nBFBRkbBpd += DwZCzBXtbVHXZcP;
        xFBoihHgpsRIzCN /= xFBoihHgpsRIzCN;
        nBFBRkbBpd -= DwZCzBXtbVHXZcP;
    }

    for (int JKSUwmSM = 1840177161; JKSUwmSM > 0; JKSUwmSM--) {
        xFBoihHgpsRIzCN += RALEpWPVjE;
        xFBoihHgpsRIzCN += RALEpWPVjE;
        RALEpWPVjE += xFBoihHgpsRIzCN;
    }

    for (int oHuUplMAQa = 1703043308; oHuUplMAQa > 0; oHuUplMAQa--) {
        rDTkzOeu *= DwZCzBXtbVHXZcP;
        nBFBRkbBpd = rDTkzOeu;
    }

    if (DwZCzBXtbVHXZcP == 160865.16694338914) {
        for (int mfMClA = 2112641372; mfMClA > 0; mfMClA--) {
            DwZCzBXtbVHXZcP = DwZCzBXtbVHXZcP;
            rDTkzOeu = nBFBRkbBpd;
            RALEpWPVjE = RALEpWPVjE;
        }
    }

    if (xFBoihHgpsRIzCN <= 446428175) {
        for (int iIffCSawESHr = 872761258; iIffCSawESHr > 0; iIffCSawESHr--) {
            rDTkzOeu -= nBFBRkbBpd;
        }
    }

    return RALEpWPVjE;
}

int zffrvswNdtVUnJ::TuquIUBwLEvmv()
{
    bool uRJVDc = true;
    string GxRNPIxmgrKM = string("fNLSbrpkpbwgDdRXhBVRSIrRSPYMnJdbhMhJNqHLcLUjsPnrsZSixKFEZJoggSbgoYxVZpVpprIrkITKYmGpjZXkmYQmThKgvJRmclVjNrGtXFEeOvHBqnMUgzkrgOYvjiLGOsRsNznUDLrCVIAyUmOyCoQwIdUizllaJVkUlXeMnFawyvOpHsajgwWpmgajNXMyqbguOwxuxFGrroJNLbOKRcmlQKrWagVvJkTBZIBIFbZAOCVe");
    bool mDaBZyc = false;
    bool JeXeigoIfld = false;
    string hpMdWflJuc = string("fOBGOKaSCpB");
    double pGvSByUWyhOpgxbQ = 286501.9892998333;
    int pdDTImrVTou = 471454167;

    if (JeXeigoIfld == false) {
        for (int ADGOgmJpoBM = 1472696076; ADGOgmJpoBM > 0; ADGOgmJpoBM--) {
            JeXeigoIfld = JeXeigoIfld;
        }
    }

    return pdDTImrVTou;
}

string zffrvswNdtVUnJ::EquBDH()
{
    string iDebdLCtqv = string("JMnjBSnZFqVvRzZlzSLQdusoFUWBESqAfgLyPVofYqDPhuzaNmtyyAQwZcEFtIrVTXZAijJgKYEVqcNZOpFVAaxQvKezQMBUKJyYGQYPdVrLENcWCoDfyhTiboRSekhRtavkFHahKwRzJXRBIeWGQBRvATBNZEWCLpVoHALtyOZbfFRydeU");
    int TleEj = 252307007;
    string aBZVyje = string("xSFYJEmKqmGiaBFTFJlALSaAXFYZJHYQQJsXSsOkamXccVsTbgEbflOUmEQuCiDGTGIvrFfifkjPaFzFzXCXoQUjcBodTsweGepP");
    double FYUpAhrhEjBC = -383054.6731506025;

    if (iDebdLCtqv == string("xSFYJEmKqmGiaBFTFJlALSaAXFYZJHYQQJsXSsOkamXccVsTbgEbflOUmEQuCiDGTGIvrFfifkjPaFzFzXCXoQUjcBodTsweGepP")) {
        for (int bGRDlvXBBuX = 1262806307; bGRDlvXBBuX > 0; bGRDlvXBBuX--) {
            iDebdLCtqv += iDebdLCtqv;
            FYUpAhrhEjBC *= FYUpAhrhEjBC;
            iDebdLCtqv += iDebdLCtqv;
            iDebdLCtqv += aBZVyje;
        }
    }

    for (int cbPIOvUsempivz = 1521618168; cbPIOvUsempivz > 0; cbPIOvUsempivz--) {
        aBZVyje = aBZVyje;
    }

    for (int oObQeVIOgQAcm = 420642324; oObQeVIOgQAcm > 0; oObQeVIOgQAcm--) {
        aBZVyje = aBZVyje;
        TleEj += TleEj;
        FYUpAhrhEjBC /= FYUpAhrhEjBC;
        TleEj = TleEj;
    }

    for (int YQBHWu = 1825716961; YQBHWu > 0; YQBHWu--) {
        TleEj *= TleEj;
        TleEj = TleEj;
    }

    return aBZVyje;
}

bool zffrvswNdtVUnJ::EkzYRlIhEYb(bool BLjXgj, double ktjbLIFXQlwbnorG, double oeUGUwAJrMoinTn, double SNhhlMFDCxoFDM, string GpsWBuUL)
{
    bool wzguVjjZhafuNrXJ = true;
    bool CGUIRERy = false;

    if (ktjbLIFXQlwbnorG == 37483.907241619854) {
        for (int TvsvBEdfcvPMMgF = 2011211204; TvsvBEdfcvPMMgF > 0; TvsvBEdfcvPMMgF--) {
            continue;
        }
    }

    for (int HiWelLfz = 715249353; HiWelLfz > 0; HiWelLfz--) {
        CGUIRERy = ! BLjXgj;
        BLjXgj = ! BLjXgj;
        BLjXgj = BLjXgj;
        oeUGUwAJrMoinTn -= oeUGUwAJrMoinTn;
    }

    for (int wUbYmlelWUXolpYH = 442011187; wUbYmlelWUXolpYH > 0; wUbYmlelWUXolpYH--) {
        BLjXgj = wzguVjjZhafuNrXJ;
        GpsWBuUL += GpsWBuUL;
        BLjXgj = CGUIRERy;
    }

    for (int XvIviJtZM = 281250156; XvIviJtZM > 0; XvIviJtZM--) {
        CGUIRERy = wzguVjjZhafuNrXJ;
        ktjbLIFXQlwbnorG /= ktjbLIFXQlwbnorG;
    }

    return CGUIRERy;
}

int zffrvswNdtVUnJ::mEotXHIr(int ZYzacVSvJGDwoema, double SqQQASyiFhDopBR, double tjAvWmsZPuTd, string qSOHgLe)
{
    bool yTqqxFigqKxQW = false;
    string EOCUOsiEr = string("xhXEXbDheyKRtnYcHtvMPPQBjUEZiPsikySwXVOEYskXCnJMqmOxLIKOYYNtiUJzMNFlcEyQtpStnyHBJESwNDxKekYPYuVYWjfnNuKZgDHeCQVwGzEfHRESW");
    bool XbLvBlDOiOZsBJ = false;
    double fQKNVViz = -869801.8440657005;
    bool PyxxmLvmdIJO = true;
    bool BWYkUMSXVG = true;

    for (int WDnchIucUwgiP = 1432312217; WDnchIucUwgiP > 0; WDnchIucUwgiP--) {
        tjAvWmsZPuTd *= tjAvWmsZPuTd;
        fQKNVViz += fQKNVViz;
        fQKNVViz += tjAvWmsZPuTd;
    }

    for (int flfbfK = 101817608; flfbfK > 0; flfbfK--) {
        PyxxmLvmdIJO = XbLvBlDOiOZsBJ;
        SqQQASyiFhDopBR += SqQQASyiFhDopBR;
        EOCUOsiEr += EOCUOsiEr;
        yTqqxFigqKxQW = PyxxmLvmdIJO;
        XbLvBlDOiOZsBJ = XbLvBlDOiOZsBJ;
        yTqqxFigqKxQW = ! yTqqxFigqKxQW;
    }

    if (EOCUOsiEr != string("xhXEXbDheyKRtnYcHtvMPPQBjUEZiPsikySwXVOEYskXCnJMqmOxLIKOYYNtiUJzMNFlcEyQtpStnyHBJESwNDxKekYPYuVYWjfnNuKZgDHeCQVwGzEfHRESW")) {
        for (int dFZLgfHe = 803048585; dFZLgfHe > 0; dFZLgfHe--) {
            SqQQASyiFhDopBR /= SqQQASyiFhDopBR;
            XbLvBlDOiOZsBJ = ! yTqqxFigqKxQW;
        }
    }

    for (int nkpDipBsHxt = 1594118591; nkpDipBsHxt > 0; nkpDipBsHxt--) {
        continue;
    }

    return ZYzacVSvJGDwoema;
}

int zffrvswNdtVUnJ::NjeEAVsz()
{
    bool TIhbgExQ = false;
    int uKIaedpIwqZfY = -764114810;
    string eWqZnFPSzBjnD = string("DlSuayBBAfvjGvYFEdXaQzCimgZYUnusDKoGtqxIVxLADqdLKpLfWrnLBbcvhTeJtkYkRpOPpHRYxVCZFiWrSzKdpwNgxmCOywAqRfXUembOqoaGGWwmaTXcsFhyuPmMuXpTkVwkSCBkqSjtLQTNKMQlZwgQntMqcHeibXmAXOjkvHmMIPwLKgkRBY");
    bool iWDfb = true;
    int tNQJdnpSyaW = -61632218;
    int KYcRLbtUDCNliVTY = 351951310;
    double agYigYjKjcXP = -286186.3792301481;
    bool HvApVOzC = true;

    for (int cZUbMPtaVgmORNX = 1751868928; cZUbMPtaVgmORNX > 0; cZUbMPtaVgmORNX--) {
        tNQJdnpSyaW += tNQJdnpSyaW;
        KYcRLbtUDCNliVTY += uKIaedpIwqZfY;
        agYigYjKjcXP *= agYigYjKjcXP;
    }

    for (int UgdHwwpcCqQjN = 872325377; UgdHwwpcCqQjN > 0; UgdHwwpcCqQjN--) {
        iWDfb = HvApVOzC;
        eWqZnFPSzBjnD += eWqZnFPSzBjnD;
    }

    for (int CEGgct = 1036545591; CEGgct > 0; CEGgct--) {
        continue;
    }

    for (int gqIcZOWdJYv = 2121160712; gqIcZOWdJYv > 0; gqIcZOWdJYv--) {
        iWDfb = TIhbgExQ;
    }

    if (KYcRLbtUDCNliVTY != -764114810) {
        for (int zkgkgTv = 1348468743; zkgkgTv > 0; zkgkgTv--) {
            iWDfb = HvApVOzC;
        }
    }

    for (int yLkgFwqLT = 74121163; yLkgFwqLT > 0; yLkgFwqLT--) {
        continue;
    }

    return KYcRLbtUDCNliVTY;
}

string zffrvswNdtVUnJ::dmRhy(int JoBYpbiCthZXHcoy, string RNhRiyL)
{
    int yBYRBnfMDit = 1976906607;
    double BuNZsjlA = 961061.2697262662;
    int sILRFWvKl = 1734478769;

    return RNhRiyL;
}

int zffrvswNdtVUnJ::vJXtTdD()
{
    string xsmzhun = string("kW");
    bool sVPJQvO = false;
    string VMmkUiVqDlk = string("wXdpjvmpJcZqBmBDBFCHnzLXF");
    string BPNdzn = string("xtHXxlvYAsSdKHoIbKRJd");
    int SIQjkdYu = -1410960931;
    double ZYBAs = -911165.3870107753;
    bool LLDstxyjNnRQXKk = true;
    int BOxxNCTvda = -607101072;
    int nawZSHtA = -1199492765;

    if (SIQjkdYu != -1199492765) {
        for (int QPJkOsWT = 340153100; QPJkOsWT > 0; QPJkOsWT--) {
            SIQjkdYu += SIQjkdYu;
            sVPJQvO = sVPJQvO;
            nawZSHtA *= nawZSHtA;
        }
    }

    if (SIQjkdYu >= -1410960931) {
        for (int xIcoNIlHjhVfZe = 1705597488; xIcoNIlHjhVfZe > 0; xIcoNIlHjhVfZe--) {
            nawZSHtA *= nawZSHtA;
        }
    }

    for (int RrwMZFKNOsZWxIbg = 1989503564; RrwMZFKNOsZWxIbg > 0; RrwMZFKNOsZWxIbg--) {
        continue;
    }

    for (int yeJjolV = 1608849701; yeJjolV > 0; yeJjolV--) {
        continue;
    }

    return nawZSHtA;
}

int zffrvswNdtVUnJ::wWtCEYttouK(bool cuMPr, string cqOofUrKHkh, double RxaSMYhlQh, double EgfNrZrsllPaQbRr, bool woIcp)
{
    double wChGi = -222800.59688166768;
    string MvqPimGhIUDZJ = string("iqxeonIqAcdcbmfuwIHfpfdDsGradfvkZUTBEgavJXOgbvHTTALSStbrduaFPBnaKdMTRgHsHqUoZBBXJyDWaIjnDAJkLGOLXFiefyyWAgCBgyWfSQYOYEugyzsVkVMssgXzCJSWPZqiYpxGpSTDTrPzJxQNxZKbWHyIUcWQtCXxfYbfOQxxsLhu");
    string zmdnVlNtbkmoz = string("THDWVXRjIKqPOBWPRtiBjBHofpiXmanvxmIh");

    for (int JRytLZRzDxy = 591265121; JRytLZRzDxy > 0; JRytLZRzDxy--) {
        MvqPimGhIUDZJ = MvqPimGhIUDZJ;
    }

    for (int kUqjuWuHLWK = 1533603539; kUqjuWuHLWK > 0; kUqjuWuHLWK--) {
        MvqPimGhIUDZJ += zmdnVlNtbkmoz;
    }

    return -7019441;
}

string zffrvswNdtVUnJ::BtAqM()
{
    int QWEUXbdZ = 1065604579;

    if (QWEUXbdZ > 1065604579) {
        for (int WttrmSvoCopbfmmd = 152015858; WttrmSvoCopbfmmd > 0; WttrmSvoCopbfmmd--) {
            QWEUXbdZ = QWEUXbdZ;
            QWEUXbdZ *= QWEUXbdZ;
            QWEUXbdZ /= QWEUXbdZ;
            QWEUXbdZ *= QWEUXbdZ;
        }
    }

    if (QWEUXbdZ >= 1065604579) {
        for (int BwyzdvMqeHa = 972622547; BwyzdvMqeHa > 0; BwyzdvMqeHa--) {
            QWEUXbdZ += QWEUXbdZ;
            QWEUXbdZ = QWEUXbdZ;
            QWEUXbdZ += QWEUXbdZ;
            QWEUXbdZ += QWEUXbdZ;
            QWEUXbdZ -= QWEUXbdZ;
            QWEUXbdZ += QWEUXbdZ;
            QWEUXbdZ -= QWEUXbdZ;
            QWEUXbdZ += QWEUXbdZ;
            QWEUXbdZ /= QWEUXbdZ;
        }
    }

    return string("BGQVSwaXkCaDIkPbRtojvUPAgZQclidZUtkScDHuRuWWcEZFEXgBQavsajWsbfqXFeVuauucoCghdLMuQIpNcJSVQXYuGRFDjEeCZMaAmghnJIPsUINDzCyHAgoNYXrxUuhjXPdwsZljojdGuQzzOlgrMlGOQHhhWKwUHVgADquJqzaggFUTnezmohouwLgUfYzEqBMXHxmqTwQOvhHvewZAF");
}

zffrvswNdtVUnJ::zffrvswNdtVUnJ()
{
    this->trcMAFIwGUrrORx(string("bglHnmDfVfPsJrBquiZQQmqyKpwCKMOOHhktTYOvzyQCfnXBsVRiDRIpsQORfOMOUQDrAYOtIGmtCrpogrAk"));
    this->PNKOARmTkHBpuGg(-1746473609, 1966452091, 606963433, string("irZobITOcqzldkHDweEENyqELbCpNmXSWHJLnCcTKXrcXlIBTYcWEMJblO"));
    this->mncizhluMkf(-1504708841);
    this->hKLlFd(2014018633);
    this->ftmIZ(string("IhTUaRHvPhsDXGUXxpDknLHwLyQNkiCQvVNVYQMQFwtkqieNAFquqMbuHiyeuKSIXuwhrjcYhBcMlpiVVerDZzMhzmcqReStuucUXdiHotdpKpLeCMnPERCpYAadmWRlNHROCXdla"), false, -944098675, 685036.525371546);
    this->HtOysYT(true, false, true, string("auhqKvLEqxgyeAtsbcTEwosBNyBrQFLQcXrAtUBmKoapLZpQgGoUKnCbOyDjdBSkJXTtlWSUbPUZMzgcbaQdqLVLsgpovvaPZZXVNkvpLoJusEKDXTVxEcebsYXAcHQUpzgLErlNTJeDuvZVmiHTNuBhKSUrmDTmxEEESWzZTDLOVgmFmgxMaDClPdSnFzPGpABEduKLrKCJlQLw"));
    this->RTelkRKMwQe(true);
    this->bNRtYpVf(166395.22534889256, false, 160865.16694338914, 753402.2216364056);
    this->TuquIUBwLEvmv();
    this->EquBDH();
    this->EkzYRlIhEYb(true, 910403.3693464899, 37483.907241619854, -73210.16488955345, string("MwwHcXAcDsNIUkIZGhkadPfteDkHrIInpgfEbvYqDSjKudnqBVTGTetCNcWackUVfvxBFVnptaveOhGdfkIgQrdeWRXNyQVHyAfRuFxnRgpkSpxIiZEGGGSzDGuQFETiKpGuXqOAeUcCHYMQvIBTlnrMqvDnnMWylPfVrGbAzKlgBfnjfYzpHLIZScoMXBQTtdeUFGwKfGJiBDBctxpzvSFpuKLidCUnafQGoYiLKLopI"));
    this->mEotXHIr(99677949, -193006.8429602698, 376139.92779339245, string("lAFQcFhskbUZhriUiQqLYWNpWwUlOKwFjSqZAwHqDCmSmywiOenudqyrxmpuyCYdrVNkaUealHHKSOYPFvRgNTdcBQXrODWubSbttTSbJBdBduRpwZCNnYXSTlsLpHjVnaJJjNAiCzhoqnSK"));
    this->NjeEAVsz();
    this->dmRhy(-1615189754, string("YJRSPFTlEWoRcNSMVBmCeOEJZvbLVXNHygYzgnWEDmXinQTTjGAXGskqJaBVnaKgQvzVGNftWrHUcsyhzoJoKfmNMbfRvqFgjKSyrUlwHqTgEttUlinlxbSAEEJHaDNkNOpo"));
    this->vJXtTdD();
    this->wWtCEYttouK(true, string("nIGYaUkmyPbqOaEWlUgilFHWfMWXTFYMVvKycHjmeqGWuttjBpktcohOytzugqWGHQNYefRBOAnMQeiAdsuGddTyzBtaSwuotbyjeJTdlKWuZRRZnuoWRGcEhocoNcOiBTKtOgoSZXMjCfnZWWnQCNwZSkarKujTPbmVklrEInRXmvLgOl"), 857377.8753699717, 214786.37857336726, false);
    this->BtAqM();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gsfbzaVYAmRDOQJX
{
public:
    double DvvwEQN;
    int ayYKU;

    gsfbzaVYAmRDOQJX();
    void InBkzmHfHPMBXu(string quqTFyBI);
    double cJWSHrSdrMLmfYR(int YObqjjxYKAVVUit, string eLrCVARmyXbHOOB, double BbiuR);
    bool SdbyTycjstNZWm(bool kZWXtQFHpHZXzHZ, double nPbPgTFENvldDXqQ, int FFiFLCwNCY);
    bool FjEJMOk(int gWGFSZyhWJkerBa, double DvVyiDT);
    int KeHnVwUOGecbM();
    string mTKDyFMvPcPL(string vPywhzk, string klewjNFqlFIpW, int fhNcd, double iyXbKfrPamJhS);
    double yViJjvgFyC();
    string AFZvenwm(double SCNmqyhDsJ, double xXpTgOepayiAIfBM, int rUajIhSF, bool bCyqVVrKouuPZI, int QoVjkcWgcHxp);
protected:
    double QGZoB;
    bool UjWJhGOeflm;

    void scdnoPXqrTvwB(double VlPZEWqtHFX, int tJUnDFaOlmthu, int yUjbmfwJSodT, bool PfgPmOFxBA);
    double AwoCQDGSGY(int BCNkNRxPACitvLTH, int ekZDBvoagsZZpkex, bool SyWPxcDOOMXr, int UGNVZdYOkJTHbO, double sGwvLa);
    int ooKaxBDQ(string doBiA, bool YgiqBI, int KeDBhQCzR);
    int xwagbJiMov(string sXQKNmTtMSBE, int PEEkCweuaMh, bool WXUcwEHOqIs, int TFbbcOfwD);
    bool TLdUeljNamdiyv(bool qgiiVlCSwQNCtKQ, double uMZxzgIpyUFEh, double IfumubBcgdITJr);
    void HatgH(int AECTQYSlgMQQ, string zsAxsZAJ, string yRWJYBQGhwQ, bool blLgihZYuPMu);
    double UECXOd(bool SakVTNFjpW);
private:
    double jrHMKNMWqeXAkIR;
    bool EGGLA;
    double TAorGCUwKeCwqDGF;
    int MJojzFYwuIlhYJLJ;
    int EMdEYybg;
    int MsaYI;

    double xmVddckX(string yQbiRBnbWhqAv, int ECsEGDVIOSg);
    void FoZnTeuPcAIdVTn(double pEKwNUZnYFD, int oRbKWpUsrvazUa);
    void hvytoYWZXTHF(string dMuTPWYCBfsjSTV, bool FzLwL, string VkDuaYyCFCaLUyDu);
    string hFQuRL(int VNXrYa, string TxhGlKJwRdr, string vgXxBrrXzQJSwkP, double TNYyacb);
    bool wBUceMBwUk(double vEqhudbSZ, bool WibeQHUhzm, int TcNQYgoy, double XmlnmHsuiT, double dTNYoKDpWijRZrY);
};

void gsfbzaVYAmRDOQJX::InBkzmHfHPMBXu(string quqTFyBI)
{
    double kGEcRiwMc = 306452.7156506677;
    double KThqC = 480882.5620431948;
    int bbsRjPkKiRGZ = -352502350;
    string OKzIxkUD = string("ZgYHeRBesRLBSsrMuvdqYilQAUKKLRDQMBfrQwgFbEfKQDXORAfMLQBYOoPPxDPJZNnGvnvngtjeUIPqjamJyHqyerrIsXOGZmBFtArBvtJuXGiYJJMbnnVWgXvhuqzxZcr");
    double omiQvkVTIFECOt = -395593.5946845952;

    for (int OBhrtcJRniQCMpfE = 1083389992; OBhrtcJRniQCMpfE > 0; OBhrtcJRniQCMpfE--) {
        OKzIxkUD = OKzIxkUD;
        OKzIxkUD += OKzIxkUD;
        kGEcRiwMc /= kGEcRiwMc;
        quqTFyBI = quqTFyBI;
        kGEcRiwMc += kGEcRiwMc;
    }

    for (int CRZmPc = 306362892; CRZmPc > 0; CRZmPc--) {
        kGEcRiwMc -= omiQvkVTIFECOt;
        omiQvkVTIFECOt = KThqC;
    }

    for (int fQzjmPtfIUz = 1665151679; fQzjmPtfIUz > 0; fQzjmPtfIUz--) {
        kGEcRiwMc = KThqC;
        quqTFyBI += OKzIxkUD;
        KThqC *= KThqC;
        omiQvkVTIFECOt *= kGEcRiwMc;
    }

    for (int eJnOR = 985334629; eJnOR > 0; eJnOR--) {
        OKzIxkUD += OKzIxkUD;
        quqTFyBI = quqTFyBI;
        kGEcRiwMc += kGEcRiwMc;
    }

    for (int qmQljVUPeD = 614570631; qmQljVUPeD > 0; qmQljVUPeD--) {
        KThqC /= omiQvkVTIFECOt;
    }
}

double gsfbzaVYAmRDOQJX::cJWSHrSdrMLmfYR(int YObqjjxYKAVVUit, string eLrCVARmyXbHOOB, double BbiuR)
{
    string KhablOHqrHbiwyG = string("kbmxAmkoGwQLCalPFTQdLzMELNonFeeqhBmafZSgdpXQOlhyZXNtziCJeElyBCWhlsHTtNEGJDGbqNNlchAEWffxXViqDjxVLHPJYJe");
    bool JOrIXta = true;
    int gFzRKbvkPSN = -1685709425;
    bool itumFHl = false;
    int ifNOqEPgP = 1651101390;
    double ECTMmhfuAgpdct = 916156.223712453;
    bool FDrWkOpwryVmJyl = true;

    for (int xKKWIxBmuH = 1861523234; xKKWIxBmuH > 0; xKKWIxBmuH--) {
        eLrCVARmyXbHOOB = eLrCVARmyXbHOOB;
        ECTMmhfuAgpdct *= BbiuR;
    }

    for (int CuRWakulokRE = 573827297; CuRWakulokRE > 0; CuRWakulokRE--) {
        continue;
    }

    for (int fBdUiwNR = 631330950; fBdUiwNR > 0; fBdUiwNR--) {
        ifNOqEPgP -= ifNOqEPgP;
        FDrWkOpwryVmJyl = ! JOrIXta;
    }

    for (int OqYExO = 263453946; OqYExO > 0; OqYExO--) {
        FDrWkOpwryVmJyl = itumFHl;
    }

    for (int MyUdN = 627628309; MyUdN > 0; MyUdN--) {
        ifNOqEPgP = ifNOqEPgP;
        KhablOHqrHbiwyG += eLrCVARmyXbHOOB;
        JOrIXta = ! itumFHl;
    }

    if (JOrIXta == true) {
        for (int EfghdVRsmuKIbIiC = 626764479; EfghdVRsmuKIbIiC > 0; EfghdVRsmuKIbIiC--) {
            continue;
        }
    }

    if (itumFHl != true) {
        for (int NXcfPR = 153419766; NXcfPR > 0; NXcfPR--) {
            JOrIXta = itumFHl;
        }
    }

    return ECTMmhfuAgpdct;
}

bool gsfbzaVYAmRDOQJX::SdbyTycjstNZWm(bool kZWXtQFHpHZXzHZ, double nPbPgTFENvldDXqQ, int FFiFLCwNCY)
{
    string yQSvsgB = string("mJvVjwSnvjGujctpKKMttyiwLRMixvQrfXGUERQAyTZiP");

    for (int vPAjRPbS = 1064696521; vPAjRPbS > 0; vPAjRPbS--) {
        FFiFLCwNCY /= FFiFLCwNCY;
    }

    for (int hMgfTdoR = 1369762469; hMgfTdoR > 0; hMgfTdoR--) {
        yQSvsgB += yQSvsgB;
    }

    for (int mBbYCuox = 995635398; mBbYCuox > 0; mBbYCuox--) {
        continue;
    }

    if (yQSvsgB < string("mJvVjwSnvjGujctpKKMttyiwLRMixvQrfXGUERQAyTZiP")) {
        for (int AXHPJkYBpAE = 912114515; AXHPJkYBpAE > 0; AXHPJkYBpAE--) {
            continue;
        }
    }

    return kZWXtQFHpHZXzHZ;
}

bool gsfbzaVYAmRDOQJX::FjEJMOk(int gWGFSZyhWJkerBa, double DvVyiDT)
{
    int PUxgUC = 1124350200;
    bool nGIhEr = false;

    for (int qtyLPufwM = 1119225772; qtyLPufwM > 0; qtyLPufwM--) {
        PUxgUC *= PUxgUC;
        DvVyiDT -= DvVyiDT;
    }

    for (int SOyrgRWh = 245992025; SOyrgRWh > 0; SOyrgRWh--) {
        PUxgUC /= gWGFSZyhWJkerBa;
    }

    if (PUxgUC > 1124350200) {
        for (int xXKIkBHb = 1618546825; xXKIkBHb > 0; xXKIkBHb--) {
            PUxgUC += gWGFSZyhWJkerBa;
        }
    }

    for (int xaqMLeFalNdhCLE = 821727359; xaqMLeFalNdhCLE > 0; xaqMLeFalNdhCLE--) {
        PUxgUC /= PUxgUC;
        PUxgUC -= gWGFSZyhWJkerBa;
        gWGFSZyhWJkerBa /= PUxgUC;
        PUxgUC -= PUxgUC;
    }

    for (int xYftiyFnaP = 1521626343; xYftiyFnaP > 0; xYftiyFnaP--) {
        PUxgUC /= PUxgUC;
    }

    return nGIhEr;
}

int gsfbzaVYAmRDOQJX::KeHnVwUOGecbM()
{
    double UFYMMvtqqLXz = -473109.07789218513;
    bool XBAyOyQwowDzDT = false;
    bool JWmIszTJ = false;
    double HqTlDLzzlmq = -526387.4854706874;

    for (int eQKIlq = 1810198570; eQKIlq > 0; eQKIlq--) {
        continue;
    }

    return 1670812349;
}

string gsfbzaVYAmRDOQJX::mTKDyFMvPcPL(string vPywhzk, string klewjNFqlFIpW, int fhNcd, double iyXbKfrPamJhS)
{
    double QWGuB = -362245.0170332318;
    double xoeZWUjVbgowL = 879891.2628949073;
    int SjslfCBWNusOEmzW = 657633009;
    int htWGlhdLUbhacOxQ = 2097725780;
    int MkVWJlJddroIe = -1056681786;

    for (int lgDIbPviyzuzbwqr = 213484708; lgDIbPviyzuzbwqr > 0; lgDIbPviyzuzbwqr--) {
        htWGlhdLUbhacOxQ /= SjslfCBWNusOEmzW;
        MkVWJlJddroIe -= MkVWJlJddroIe;
        fhNcd -= htWGlhdLUbhacOxQ;
        xoeZWUjVbgowL /= xoeZWUjVbgowL;
    }

    for (int UowHxIxxqQEJBNTp = 1738058792; UowHxIxxqQEJBNTp > 0; UowHxIxxqQEJBNTp--) {
        continue;
    }

    for (int DIxbhHdnChtLOEGr = 516898073; DIxbhHdnChtLOEGr > 0; DIxbhHdnChtLOEGr--) {
        QWGuB /= xoeZWUjVbgowL;
        iyXbKfrPamJhS += QWGuB;
        xoeZWUjVbgowL *= QWGuB;
        iyXbKfrPamJhS /= iyXbKfrPamJhS;
    }

    for (int tVXcUTWljgJjXGQ = 414739518; tVXcUTWljgJjXGQ > 0; tVXcUTWljgJjXGQ--) {
        klewjNFqlFIpW = klewjNFqlFIpW;
    }

    return klewjNFqlFIpW;
}

double gsfbzaVYAmRDOQJX::yViJjvgFyC()
{
    bool aDBnqqiHdUkREf = false;
    double lepCmprm = -246162.47795949632;
    bool nwehKo = false;
    bool uWWBIw = false;

    for (int ZyEADV = 594365501; ZyEADV > 0; ZyEADV--) {
        continue;
    }

    if (aDBnqqiHdUkREf != false) {
        for (int kTPynDHPoFTVTGz = 1768466879; kTPynDHPoFTVTGz > 0; kTPynDHPoFTVTGz--) {
            uWWBIw = ! aDBnqqiHdUkREf;
            nwehKo = ! nwehKo;
            uWWBIw = uWWBIw;
        }
    }

    if (uWWBIw != false) {
        for (int aPVaznhRtsRR = 1915324333; aPVaznhRtsRR > 0; aPVaznhRtsRR--) {
            aDBnqqiHdUkREf = ! uWWBIw;
            uWWBIw = uWWBIw;
            aDBnqqiHdUkREf = ! nwehKo;
            aDBnqqiHdUkREf = uWWBIw;
            lepCmprm -= lepCmprm;
            nwehKo = ! uWWBIw;
        }
    }

    for (int cZWRMYQNJQPXjOaP = 1511020418; cZWRMYQNJQPXjOaP > 0; cZWRMYQNJQPXjOaP--) {
        uWWBIw = nwehKo;
        nwehKo = ! nwehKo;
        uWWBIw = uWWBIw;
    }

    if (uWWBIw == false) {
        for (int gYLzxc = 105009477; gYLzxc > 0; gYLzxc--) {
            aDBnqqiHdUkREf = ! uWWBIw;
            uWWBIw = ! aDBnqqiHdUkREf;
            uWWBIw = ! aDBnqqiHdUkREf;
        }
    }

    if (nwehKo == false) {
        for (int IGPhntzQULZQgA = 2131310182; IGPhntzQULZQgA > 0; IGPhntzQULZQgA--) {
            aDBnqqiHdUkREf = uWWBIw;
        }
    }

    for (int SRJabawljsPqmwKR = 1322175756; SRJabawljsPqmwKR > 0; SRJabawljsPqmwKR--) {
        aDBnqqiHdUkREf = nwehKo;
        nwehKo = ! aDBnqqiHdUkREf;
        uWWBIw = ! aDBnqqiHdUkREf;
        uWWBIw = nwehKo;
    }

    return lepCmprm;
}

string gsfbzaVYAmRDOQJX::AFZvenwm(double SCNmqyhDsJ, double xXpTgOepayiAIfBM, int rUajIhSF, bool bCyqVVrKouuPZI, int QoVjkcWgcHxp)
{
    string cZqnitKakQTa = string("YkDEkOQuDXWPLoESzeQlHaqrYAxMMSOffeqUMiFtmnZwzIbhBtgFOiHZIvICbFKoWeAeXaJGOIuUjAOJbysWIbTiWHFbFGXOwdITVmbBmp");
    int WQuwfBDLhNo = -1230892363;

    for (int zMGus = 936749524; zMGus > 0; zMGus--) {
        SCNmqyhDsJ -= xXpTgOepayiAIfBM;
        xXpTgOepayiAIfBM -= SCNmqyhDsJ;
    }

    if (rUajIhSF < -1230892363) {
        for (int YmbiBAJduIGFj = 680534140; YmbiBAJduIGFj > 0; YmbiBAJduIGFj--) {
            xXpTgOepayiAIfBM *= SCNmqyhDsJ;
        }
    }

    for (int rZSKckCfXOmnqNi = 1045213536; rZSKckCfXOmnqNi > 0; rZSKckCfXOmnqNi--) {
        continue;
    }

    for (int xnFpPvRlKTIPpb = 1933451979; xnFpPvRlKTIPpb > 0; xnFpPvRlKTIPpb--) {
        rUajIhSF /= rUajIhSF;
    }

    if (xXpTgOepayiAIfBM > -50879.68312245841) {
        for (int dvnVm = 1155804953; dvnVm > 0; dvnVm--) {
            continue;
        }
    }

    if (WQuwfBDLhNo == -1230892363) {
        for (int DytQiUS = 1816774097; DytQiUS > 0; DytQiUS--) {
            QoVjkcWgcHxp *= WQuwfBDLhNo;
        }
    }

    return cZqnitKakQTa;
}

void gsfbzaVYAmRDOQJX::scdnoPXqrTvwB(double VlPZEWqtHFX, int tJUnDFaOlmthu, int yUjbmfwJSodT, bool PfgPmOFxBA)
{
    double rSottRWH = 257818.0402455533;
    double GIhFgIe = 569235.07541049;

    for (int qwsoR = 1923771320; qwsoR > 0; qwsoR--) {
        GIhFgIe -= VlPZEWqtHFX;
        tJUnDFaOlmthu -= yUjbmfwJSodT;
    }

    if (GIhFgIe > 312087.9940042574) {
        for (int ZZLMEsZdlnFrWv = 2087053784; ZZLMEsZdlnFrWv > 0; ZZLMEsZdlnFrWv--) {
            tJUnDFaOlmthu *= tJUnDFaOlmthu;
            tJUnDFaOlmthu += yUjbmfwJSodT;
        }
    }

    if (VlPZEWqtHFX > 569235.07541049) {
        for (int wzXtpaoG = 1173510407; wzXtpaoG > 0; wzXtpaoG--) {
            continue;
        }
    }

    for (int swDDoLQS = 1707998467; swDDoLQS > 0; swDDoLQS--) {
        continue;
    }

    for (int MHMvwFVlJSmXsEU = 247307682; MHMvwFVlJSmXsEU > 0; MHMvwFVlJSmXsEU--) {
        GIhFgIe -= rSottRWH;
        rSottRWH *= VlPZEWqtHFX;
        GIhFgIe -= rSottRWH;
    }

    for (int iLCmashbjqqu = 1657711203; iLCmashbjqqu > 0; iLCmashbjqqu--) {
        VlPZEWqtHFX += GIhFgIe;
        GIhFgIe /= GIhFgIe;
        GIhFgIe *= GIhFgIe;
        rSottRWH = rSottRWH;
        tJUnDFaOlmthu /= tJUnDFaOlmthu;
    }
}

double gsfbzaVYAmRDOQJX::AwoCQDGSGY(int BCNkNRxPACitvLTH, int ekZDBvoagsZZpkex, bool SyWPxcDOOMXr, int UGNVZdYOkJTHbO, double sGwvLa)
{
    double HaUKWR = 802340.1739262149;
    int PBGUKXiDnGoNMd = 1429475233;
    double TVPqKqdoLlZgsc = 521118.19832828065;
    string KMqeHziqDWfS = string("rfDGOdYOQTDlTXPeVbKqebpMIOstKKKojXDeKUZDKCigbcomNjBVfYtFcjlMWgGhqyRRZumQdEaWJEBKWNciQWdgQTzPBcnBXUZlfdsimKJRIgouPQIPevCEfrvSVZGeOasCxAIpPxuixgUXYXMbWwvPPboDZgDmtNzfxVomlSvdHQGxFDwJRgcpumbORrRenczMkVhwfJYGzrOdDrKAB");
    double xOeqosRfprzsR = 87671.43454245661;

    return xOeqosRfprzsR;
}

int gsfbzaVYAmRDOQJX::ooKaxBDQ(string doBiA, bool YgiqBI, int KeDBhQCzR)
{
    bool GoKKCEuU = false;
    string RrtFuGzWvsTl = string("ionNKNwWJMhEQPsfxREpGXjsHvva");
    string VLJqMwYOaWrpm = string("ATaeMJJeyciyVzMFizAKUWxSbnUDoaYRLAwunuvmghpQLlVGFDLXcmovwfiucOGOBugxBcgFVWZRPSUavzEjzuPRolSEUOebwBIcjTvZguFMjedqKYtBQIRHaQUOchQVjZSLaJA");
    double SofDMISx = 535193.9779206186;
    int xKlBVStyCrw = 733033048;
    bool dyBaqVahHYZ = false;
    double TtSNiULCgSgsw = -535530.185838417;
    double WEHzlskubS = -898647.5151610109;
    bool GLANU = false;

    for (int TWyfpLmDkUYQ = 1664963459; TWyfpLmDkUYQ > 0; TWyfpLmDkUYQ--) {
        continue;
    }

    if (TtSNiULCgSgsw >= 535193.9779206186) {
        for (int YRxxrGqw = 400373053; YRxxrGqw > 0; YRxxrGqw--) {
            xKlBVStyCrw *= KeDBhQCzR;
            GLANU = dyBaqVahHYZ;
            VLJqMwYOaWrpm = VLJqMwYOaWrpm;
        }
    }

    if (YgiqBI != true) {
        for (int quJfNbwUDhIhPZdA = 1900974571; quJfNbwUDhIhPZdA > 0; quJfNbwUDhIhPZdA--) {
            continue;
        }
    }

    for (int JGPCYbisfBleZN = 953537244; JGPCYbisfBleZN > 0; JGPCYbisfBleZN--) {
        VLJqMwYOaWrpm = RrtFuGzWvsTl;
    }

    for (int kLqhAUOzL = 1668238000; kLqhAUOzL > 0; kLqhAUOzL--) {
        continue;
    }

    return xKlBVStyCrw;
}

int gsfbzaVYAmRDOQJX::xwagbJiMov(string sXQKNmTtMSBE, int PEEkCweuaMh, bool WXUcwEHOqIs, int TFbbcOfwD)
{
    int UDtKdRfXAvQ = 598213098;
    double hPoJPKvgBhCCoxp = 322411.24980544904;
    int nMNslccyPq = 1902037413;
    bool rOsIhM = true;
    int wgMSerivsCPUYH = -816373973;
    int hHBXFFr = -254158722;
    bool FDNZHcPeESNvle = true;

    if (wgMSerivsCPUYH >= -254158722) {
        for (int EOdyVkwkvj = 1817003103; EOdyVkwkvj > 0; EOdyVkwkvj--) {
            hHBXFFr = nMNslccyPq;
            PEEkCweuaMh /= PEEkCweuaMh;
            nMNslccyPq -= hHBXFFr;
        }
    }

    if (wgMSerivsCPUYH < -254158722) {
        for (int lDTgouZ = 929660084; lDTgouZ > 0; lDTgouZ--) {
            hHBXFFr += TFbbcOfwD;
            UDtKdRfXAvQ += UDtKdRfXAvQ;
            rOsIhM = FDNZHcPeESNvle;
            UDtKdRfXAvQ *= nMNslccyPq;
            TFbbcOfwD *= hHBXFFr;
            UDtKdRfXAvQ /= TFbbcOfwD;
        }
    }

    if (wgMSerivsCPUYH != 1902037413) {
        for (int IqSKQHh = 543825720; IqSKQHh > 0; IqSKQHh--) {
            nMNslccyPq += wgMSerivsCPUYH;
            FDNZHcPeESNvle = rOsIhM;
        }
    }

    for (int rwuQzOhlw = 645141681; rwuQzOhlw > 0; rwuQzOhlw--) {
        nMNslccyPq -= UDtKdRfXAvQ;
        PEEkCweuaMh += hHBXFFr;
    }

    for (int VogYDFte = 1189800642; VogYDFte > 0; VogYDFte--) {
        TFbbcOfwD = wgMSerivsCPUYH;
        wgMSerivsCPUYH *= wgMSerivsCPUYH;
        wgMSerivsCPUYH -= hHBXFFr;
    }

    return hHBXFFr;
}

bool gsfbzaVYAmRDOQJX::TLdUeljNamdiyv(bool qgiiVlCSwQNCtKQ, double uMZxzgIpyUFEh, double IfumubBcgdITJr)
{
    double MplUiCnGwMffxfMl = -319928.7087689224;
    string zBYOrspODjl = string("AzphFSFWZYfjDFAoMhoyuKbobtSOLclwHyJKjUYZiqGvvbnIpXjfNaDPuGqoijMmLIuTzckXLHWtwmpFXZbxjmajnKScecqYKpfsNkruwjGjlNTXiaqKrdhGRFXtiIcxFNBjAhuozjFqduBoMscQwTnDmBbgNNMaCHbeAVccKyhgrqQSBdLuIQUzzqoKFN");
    bool KrvlniuV = false;
    string DaPfYEGrXnDIhn = string("LGPHLNNoFtebVxmOCQCnaPdyOmUSQcugmtoK");
    string vYFUcYfu = string("cMRVNAFiPgoZAENNYmEejCJBcyhoygSEAICTJurvonKNaqOakLgZyFxEXMmHSLkaAtuiVidiythdqBevrLYSoMHowjOzhkewxEprsQgnkRSrzTnBcyQyPixIzESRPwLZLzrheeHvOYcaDLocJudFKzrAYIuvIXDKpKMJJmltcEQBMetaROmLaOOMCfBHEVXDIntwAgyrqaQYZoZHUfORTerTOsUqwKDfQKpfcVVoKG");
    double coZXCa = -327067.1897058817;
    double cVrdwuSxgJmRMye = 748631.4705241808;

    for (int HnUgjLLWmzohZ = 93050257; HnUgjLLWmzohZ > 0; HnUgjLLWmzohZ--) {
        uMZxzgIpyUFEh = MplUiCnGwMffxfMl;
        cVrdwuSxgJmRMye -= MplUiCnGwMffxfMl;
    }

    if (uMZxzgIpyUFEh <= 141945.65207072612) {
        for (int GKSCyhqR = 1457639694; GKSCyhqR > 0; GKSCyhqR--) {
            KrvlniuV = ! KrvlniuV;
            cVrdwuSxgJmRMye = cVrdwuSxgJmRMye;
            MplUiCnGwMffxfMl /= cVrdwuSxgJmRMye;
        }
    }

    return KrvlniuV;
}

void gsfbzaVYAmRDOQJX::HatgH(int AECTQYSlgMQQ, string zsAxsZAJ, string yRWJYBQGhwQ, bool blLgihZYuPMu)
{
    int OAOhcl = 30567186;
    double WCgwOfbr = -103805.93002201796;
    string UMekSgitX = string("BkAHRDSSZawTEzdXRuMDFQgyUoKcBHsQNwuzGyRMBdcQyMHNmWSchxwqkxfWvvFRDjSqDqjhuetIgcnEcxZYyGzgsTCnytYbTbHdredUPARvaygoASurawGZWufIxUhqtOlHLmVwyVvCvoPNV");
    double xniqYzmDIOaL = 64844.28543654304;
    bool niizISgBaccufh = true;
    int OuuJkf = -933786927;
    int FteQfJLWaDPH = 2034563604;
    double BqVXKgmWOfXuh = -553487.2173957741;
    bool ORSxRSjqLWmdnhb = true;
    string ESXeXElbInum = string("VYVJPojrKmSdrZamAllxRheupdvMbsXMYqzGNqiisXzRaFbUVbkTCpuICJZMOJLBJDcPmGlhfPTbbhwnwWTmomSUFOufOiZxWJXJwnnrGnTJEPUGhZdswGaaRBFUpXqxgKDxBKhooBCAjPOvViLvMCcFpdHVYNezLGUIPIqPDikeUMv");

    if (AECTQYSlgMQQ != 1277301222) {
        for (int mwtsTkMc = 973263654; mwtsTkMc > 0; mwtsTkMc--) {
            UMekSgitX += zsAxsZAJ;
            ESXeXElbInum = UMekSgitX;
        }
    }

    for (int SXQUVUbqWF = 1809248397; SXQUVUbqWF > 0; SXQUVUbqWF--) {
        niizISgBaccufh = ! blLgihZYuPMu;
        xniqYzmDIOaL *= WCgwOfbr;
    }
}

double gsfbzaVYAmRDOQJX::UECXOd(bool SakVTNFjpW)
{
    int ElpuQCJmY = 730896749;
    bool loUwkDHpjVUk = false;
    double dmueMUMiA = 940391.501792176;
    string xjGdXsk = string("kHOSGthHhmhBHTtzuDVPTnGYWHnxLQlqfekFrOhBHnixutgMpLByjicUzqHzscTpqDTXsaxMRetEvUgmSOpsPbfDxuHveQzXvglGzvazHoedrpFixUykCRjmwZxXNiBZvXSoJnurom");
    double ZufOPdZW = 147090.98646804556;
    bool KeXgZ = true;
    int TMmGFSiyuYVxPf = -842922744;
    bool xbwAnV = true;

    for (int oFUVWXnfuLxZPXSS = 1251899275; oFUVWXnfuLxZPXSS > 0; oFUVWXnfuLxZPXSS--) {
        loUwkDHpjVUk = ! loUwkDHpjVUk;
    }

    for (int oTIXctzE = 587197266; oTIXctzE > 0; oTIXctzE--) {
        SakVTNFjpW = xbwAnV;
    }

    for (int URpGsajikR = 964760447; URpGsajikR > 0; URpGsajikR--) {
        xbwAnV = xbwAnV;
        dmueMUMiA /= dmueMUMiA;
    }

    for (int LqJPyhiQwYeRj = 947686516; LqJPyhiQwYeRj > 0; LqJPyhiQwYeRj--) {
        KeXgZ = ! xbwAnV;
    }

    for (int onfyJcsmefEdC = 821958428; onfyJcsmefEdC > 0; onfyJcsmefEdC--) {
        xbwAnV = ! xbwAnV;
        ZufOPdZW -= ZufOPdZW;
    }

    return ZufOPdZW;
}

double gsfbzaVYAmRDOQJX::xmVddckX(string yQbiRBnbWhqAv, int ECsEGDVIOSg)
{
    string GBXckwn = string("mcvPAFx");

    if (GBXckwn != string("mcvPAFx")) {
        for (int GvskIl = 2060645638; GvskIl > 0; GvskIl--) {
            GBXckwn += yQbiRBnbWhqAv;
            yQbiRBnbWhqAv = yQbiRBnbWhqAv;
            GBXckwn += GBXckwn;
            yQbiRBnbWhqAv = GBXckwn;
            GBXckwn += GBXckwn;
            yQbiRBnbWhqAv = GBXckwn;
            yQbiRBnbWhqAv += GBXckwn;
        }
    }

    if (yQbiRBnbWhqAv != string("mcvPAFx")) {
        for (int FKKOVaVRlQXZIFa = 250704000; FKKOVaVRlQXZIFa > 0; FKKOVaVRlQXZIFa--) {
            GBXckwn += GBXckwn;
            ECsEGDVIOSg += ECsEGDVIOSg;
            GBXckwn = GBXckwn;
        }
    }

    for (int OHDDFIgLryMoMO = 1939636037; OHDDFIgLryMoMO > 0; OHDDFIgLryMoMO--) {
        ECsEGDVIOSg = ECsEGDVIOSg;
        ECsEGDVIOSg -= ECsEGDVIOSg;
    }

    if (GBXckwn <= string("mcvPAFx")) {
        for (int HOjAwzhD = 1974377929; HOjAwzhD > 0; HOjAwzhD--) {
            ECsEGDVIOSg /= ECsEGDVIOSg;
            yQbiRBnbWhqAv += yQbiRBnbWhqAv;
        }
    }

    return -352473.81500301126;
}

void gsfbzaVYAmRDOQJX::FoZnTeuPcAIdVTn(double pEKwNUZnYFD, int oRbKWpUsrvazUa)
{
    bool GNVlJELWbqLnYJD = true;
    bool wMyqw = false;
    bool qPbCJVwGLdZGGYO = true;
    int LkuzQTPXePmKAV = -1273905377;

    if (qPbCJVwGLdZGGYO != true) {
        for (int BWvxoHiStoZmFXj = 1139760576; BWvxoHiStoZmFXj > 0; BWvxoHiStoZmFXj--) {
            oRbKWpUsrvazUa = LkuzQTPXePmKAV;
            qPbCJVwGLdZGGYO = qPbCJVwGLdZGGYO;
        }
    }

    if (wMyqw == true) {
        for (int emfXnIQ = 435561735; emfXnIQ > 0; emfXnIQ--) {
            wMyqw = qPbCJVwGLdZGGYO;
            wMyqw = ! qPbCJVwGLdZGGYO;
            wMyqw = GNVlJELWbqLnYJD;
            wMyqw = GNVlJELWbqLnYJD;
        }
    }

    if (pEKwNUZnYFD >= -688833.9080868438) {
        for (int ZOURpxmpGUG = 1467807827; ZOURpxmpGUG > 0; ZOURpxmpGUG--) {
            qPbCJVwGLdZGGYO = qPbCJVwGLdZGGYO;
            wMyqw = ! qPbCJVwGLdZGGYO;
        }
    }

    if (LkuzQTPXePmKAV != -1273905377) {
        for (int xMKoQGl = 41745347; xMKoQGl > 0; xMKoQGl--) {
            wMyqw = GNVlJELWbqLnYJD;
        }
    }
}

void gsfbzaVYAmRDOQJX::hvytoYWZXTHF(string dMuTPWYCBfsjSTV, bool FzLwL, string VkDuaYyCFCaLUyDu)
{
    string dNMgymvACObXnZ = string("cFrILkCmGSarsBkjNtOigwjhyGkWW");

    if (VkDuaYyCFCaLUyDu < string("CDytulQjzZJonVCxHcVERqAtLNkkHlsesGYcPhDvnIXsOHvABMfrNuoQbIJxJHCFIuxQIfwscyIDUYmTSGADrUVmEArhWEatmCyAiRzaaobZgEQaTgykvVtpyGIapEJesfCOuuFCbTldTZvnMlzQMPfXFrUesIqKQGoafogVwKJBbBHOLzgYdAVZnyVTyyjLkZhnpeuXwiUHuGIqfHsFtZWfqVaHHNXKF")) {
        for (int ZTSdzteqzHe = 1645486875; ZTSdzteqzHe > 0; ZTSdzteqzHe--) {
            dMuTPWYCBfsjSTV = dMuTPWYCBfsjSTV;
        }
    }

    if (dNMgymvACObXnZ >= string("cFrILkCmGSarsBkjNtOigwjhyGkWW")) {
        for (int bWjqmgOC = 535604549; bWjqmgOC > 0; bWjqmgOC--) {
            dMuTPWYCBfsjSTV = dMuTPWYCBfsjSTV;
        }
    }

    for (int XikAgEOCs = 1648797319; XikAgEOCs > 0; XikAgEOCs--) {
        dMuTPWYCBfsjSTV += dNMgymvACObXnZ;
        dMuTPWYCBfsjSTV = dNMgymvACObXnZ;
    }

    if (VkDuaYyCFCaLUyDu > string("CDytulQjzZJonVCxHcVERqAtLNkkHlsesGYcPhDvnIXsOHvABMfrNuoQbIJxJHCFIuxQIfwscyIDUYmTSGADrUVmEArhWEatmCyAiRzaaobZgEQaTgykvVtpyGIapEJesfCOuuFCbTldTZvnMlzQMPfXFrUesIqKQGoafogVwKJBbBHOLzgYdAVZnyVTyyjLkZhnpeuXwiUHuGIqfHsFtZWfqVaHHNXKF")) {
        for (int iipGygPnxFu = 792507784; iipGygPnxFu > 0; iipGygPnxFu--) {
            VkDuaYyCFCaLUyDu = dNMgymvACObXnZ;
            dNMgymvACObXnZ = VkDuaYyCFCaLUyDu;
            dNMgymvACObXnZ = dMuTPWYCBfsjSTV;
            dMuTPWYCBfsjSTV = dNMgymvACObXnZ;
            dMuTPWYCBfsjSTV += VkDuaYyCFCaLUyDu;
            dMuTPWYCBfsjSTV = VkDuaYyCFCaLUyDu;
        }
    }
}

string gsfbzaVYAmRDOQJX::hFQuRL(int VNXrYa, string TxhGlKJwRdr, string vgXxBrrXzQJSwkP, double TNYyacb)
{
    int GggIqQKEqpTpyD = 1593878309;
    int FjNIpvW = 50243988;

    if (GggIqQKEqpTpyD >= 1593878309) {
        for (int wKxRTpplr = 144413630; wKxRTpplr > 0; wKxRTpplr--) {
            continue;
        }
    }

    for (int NswVfFUcoom = 1614297227; NswVfFUcoom > 0; NswVfFUcoom--) {
        FjNIpvW -= GggIqQKEqpTpyD;
    }

    return vgXxBrrXzQJSwkP;
}

bool gsfbzaVYAmRDOQJX::wBUceMBwUk(double vEqhudbSZ, bool WibeQHUhzm, int TcNQYgoy, double XmlnmHsuiT, double dTNYoKDpWijRZrY)
{
    double QArRdiHIw = 893680.4483007154;
    bool zSToCWqZNA = true;
    bool OiCwjuoe = true;
    double ZLYhLwWDxS = 859313.1415261754;
    int nzRpXNDpvQH = 205311216;
    bool llTLvBWsPdqDOQ = false;
    bool XoPjNwNNKWO = false;

    if (WibeQHUhzm == true) {
        for (int BNvqNuYB = 194050124; BNvqNuYB > 0; BNvqNuYB--) {
            TcNQYgoy += nzRpXNDpvQH;
            zSToCWqZNA = ! OiCwjuoe;
        }
    }

    for (int uusEiABi = 289296937; uusEiABi > 0; uusEiABi--) {
        vEqhudbSZ *= vEqhudbSZ;
        ZLYhLwWDxS -= ZLYhLwWDxS;
        vEqhudbSZ += dTNYoKDpWijRZrY;
    }

    for (int tbqhRK = 1529786476; tbqhRK > 0; tbqhRK--) {
        XmlnmHsuiT *= ZLYhLwWDxS;
        TcNQYgoy -= nzRpXNDpvQH;
    }

    return XoPjNwNNKWO;
}

gsfbzaVYAmRDOQJX::gsfbzaVYAmRDOQJX()
{
    this->InBkzmHfHPMBXu(string("VRdmBuqjdpw"));
    this->cJWSHrSdrMLmfYR(-319184880, string("nYFZWWLtCRhSxnhaKLkiVknhuWNEOFoLZssbpXEKcSoyfhYfQxbfuvEUeOEsTICvAqfnJXIXufoSuMdtkKdHURjNzKdUdAGYahowHAmiAtK"), -297804.43888107274);
    this->SdbyTycjstNZWm(true, -962874.5874813407, 778541264);
    this->FjEJMOk(57376667, -976494.9391235618);
    this->KeHnVwUOGecbM();
    this->mTKDyFMvPcPL(string("sOxvipLZx"), string("YBplONEIqsUIZlQBuIKoGvANVmLnLSlPsWEzNTIoJXslvqbWYUeKUpoPTnTADQprklfsJQXckbLJevQRrgVWiDRuSMWLxCMJqwqjIundiofMpFwXOMeBaBgxghbMMLqFisTbpOIFMqgXYSeQsScxcznyzypagCdvqQWSGlgceVET"), 1100014147, -486237.2317208484);
    this->yViJjvgFyC();
    this->AFZvenwm(175816.84217128583, -50879.68312245841, -1673100027, false, -479487692);
    this->scdnoPXqrTvwB(312087.9940042574, 1412028157, -1456836266, false);
    this->AwoCQDGSGY(634779150, -1922421509, false, 316161017, 900979.0030876226);
    this->ooKaxBDQ(string("lVLgIsMhybQVkrKCbJLTQLtHOFrLcLazhLLfgoaWQaoBYlwWLtCvPAvcRTPVkaOIgFXnuKvxuiQkHBkLHqWVbgyPbSNWOSMPIdQnjbQzhVYfIxQwtoJWiOVoOfMrxEvgijWmSZJUWUiJMKQPZWoDgyKADvgmMrixQKavZzqImbGkjhwROyxvGHLColKVawPucnWFtimszHmCfkZGqWqIGZPvRqBGWJJpeoJVaxNkCsiGtFCWgUnywtEs"), true, 1916382758);
    this->xwagbJiMov(string("JpCPPVUwJMAoSfFuiujtHVmSzArEKibyCzSwXhWhGUoUZrnTyTgFZjbUSQeRIRbhYDiVGojoLasjjkKywYongKeRsKbFZizyZCXwEZ"), 1243680037, false, -943666561);
    this->TLdUeljNamdiyv(false, 824292.4232421838, 141945.65207072612);
    this->HatgH(1277301222, string("OIpvrKikrRKzncewcBimnLsDyvCXMYJjYkGXZqilhxAaqDyrDsJlyJacnAhLvdPFVZolnxqhSZAAwRPQhyihGxeJttqeUPKqPRNcZeBdPhtlIZRqEDFBOl"), string("MWBWfNJodCBVMLiRYazyhTfdzetPqoqtmJHHhEnLuUkXlxQSXkKdqJiqiUJGeUpPcOlQxbLDYkaqTKaBiUVUIGAUpmcuyLxEpCnCmXSViyDUyMwMxDgZxTqHxyRSdFfbjSFKSzyJRDzcvMmBcE"), true);
    this->UECXOd(true);
    this->xmVddckX(string("MgJWWBbjHVoyjypprSSWkEKCfFIKDvzpfYWGIxXMRxkgnFEfIeDouvkiNtXXqwzjynRmZdDjEvEZcXzCJKfiBdiwteUpBHrrxGCUesBJVUAnGqPItDxaDoUZpOZgJRUsviVceGsGFFbBWiyURiEZu"), 2065765760);
    this->FoZnTeuPcAIdVTn(-688833.9080868438, 1876432126);
    this->hvytoYWZXTHF(string("WNoHSQehVakFUCLZQIROhWhRLrpgosGUqXcmyRfdxdlyUKvJquOoFxUiPttBSbEeRUyxnCjdxcMbyJgiEAgLpIcUOHxbJtWFqBuLQXeORCEofJmKVBSOdcdwGqydJBxjgkclVzdnUwhiKkllcnxBFMrScECwCsMkbdXwNJmPjNNzakFNLDYSquz"), true, string("CDytulQjzZJonVCxHcVERqAtLNkkHlsesGYcPhDvnIXsOHvABMfrNuoQbIJxJHCFIuxQIfwscyIDUYmTSGADrUVmEArhWEatmCyAiRzaaobZgEQaTgykvVtpyGIapEJesfCOuuFCbTldTZvnMlzQMPfXFrUesIqKQGoafogVwKJBbBHOLzgYdAVZnyVTyyjLkZhnpeuXwiUHuGIqfHsFtZWfqVaHHNXKF"));
    this->hFQuRL(-413359934, string("kOzvaFnqlQxThGzYNvKzDWwabXVjIGEptZpBaifcBGofBRQaegbHBhBgoDdIdZhuoFzZEryXWXUnvinFwslWHqgKakLvPFpolOwEogyVVNwfyEqwoWkhWFOdammKmdzmIRwXLpmzVOAZmzdTBgXBxLjcHlSHsgaORvqGKnQNxwawoiNQWVDJUheWjhkKzHrZIxljPlVIBEaAvfnN"), string("MgajSTTlKeipaWpKToVkLzNaRjAFAwOFGMvyQeWfinDEDxTfnWmCBuVtVoZXYaeFrjYcwGXKcILGhhTmVNmrNuqLAAYMwuCigfnBfRhGlQEGcrNPwSYrHYAzYaQAFecfQLChzwZzDHPIgWBeiXtLRMURJPWyIjIzOudZEfSaNlXOzWBAHgiGEyDiiAdYDUOsEkhIGnADuKZiIZfycNWHciieSleLIiBFudoXUbEUViWwNvFJjx"), 632142.2804084513);
    this->wBUceMBwUk(275874.5946133326, false, 1138434448, -503331.21655394573, -201854.88062840686);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wxZXptfDJJk
{
public:
    bool gcpBwGSANMdCiU;

    wxZXptfDJJk();
    bool rYUzKWG(string sucGe, double PQiYfKXFOt, int vMVuxXQTHvhte, int PsVOxvILdVs, int BxKGcIbgWJo);
    bool JmQxJQzSZyGetpuW(double ynxtVjrOFMmQoZ, double dcQTiAYD);
protected:
    bool tiFAyBUbeBYAvDW;
    bool GRmUnoHGAYLW;
    int EvHbAiRDErPDCZpn;
    double iyyhSTAEwTfD;
    string nvEJuoK;
    string EbNCw;

    bool DSnNcTPHCvx(double JWkFyyz);
    bool zkySxhaaWFbBwTx();
    double wkZrzWk(int iHjNpFvNVfF, double eVRtsoZjZKMHJfs, bool hLjdGtVN);
    double rHTjSWo();
private:
    double JZpOMaUJFFqSARGO;
    bool Vfohtpt;
    int oTElIx;

};

bool wxZXptfDJJk::rYUzKWG(string sucGe, double PQiYfKXFOt, int vMVuxXQTHvhte, int PsVOxvILdVs, int BxKGcIbgWJo)
{
    bool zqGzKrKxvH = true;
    bool xEIIxQgACjwdKpmd = false;
    string DZzDMUds = string("DNbUWVUPYJlPPFFXnRYflYBsAYfsgZYnrjUPaZWBQjoOqxhNgWuwUNOulwwNLVGSWdUJqkkNfPBGAYzxtBScyUMTghPMTdoKFGJBDzgPmXGAvVUkUnmUxuOmXDWjprbAkXRfXlmggepjKRlLdnNyUAdbRBHlavNwJEa");

    for (int vrioXftJrYl = 117882155; vrioXftJrYl > 0; vrioXftJrYl--) {
        vMVuxXQTHvhte /= BxKGcIbgWJo;
    }

    for (int DmTUujgY = 1025826422; DmTUujgY > 0; DmTUujgY--) {
        continue;
    }

    for (int wrHyJ = 1089268739; wrHyJ > 0; wrHyJ--) {
        zqGzKrKxvH = ! xEIIxQgACjwdKpmd;
        BxKGcIbgWJo -= BxKGcIbgWJo;
        DZzDMUds += sucGe;
    }

    return xEIIxQgACjwdKpmd;
}

bool wxZXptfDJJk::JmQxJQzSZyGetpuW(double ynxtVjrOFMmQoZ, double dcQTiAYD)
{
    double ccWuEsHMghuuVxZ = 958352.8594776167;
    int jGvokvyJMy = -1304723720;
    bool dVXqGuGvuSzDV = false;
    int bKAeOBFIbWWf = 1088575942;
    string ewtVhodjNNOUsLaV = string("vgFOfmZSgndWdUpVXaGpdJjwvFhvbjbOitbFcvynrVHlxyLBNimLftWoiQypVwYZMacnbHVMHGPRCvYbEQlTOdMRWJuTevyDcqubqyUApILPmQBlmMGpowpYrqEIPGFcJgskIDINIZDksxcUXuFngPVgZrWiXCggRftrTQHPqTnCkqCTDmHErSWVmlIWVqzuHSOEQJeOOPnFJIY");
    double exVFl = -1044184.9245542682;
    bool SZkaOcHDwrzmQs = false;
    bool hjTBqSeCqWqOUIP = true;
    string oDRZIJgloQr = string("BTniSfPnKpbuVSaVIMmsZZRcrQNeYfoUaBDTXHGsVnTBdibJNYslehEBLYRjzSHLpOhYPkplJirQQQWyrgfWmkGEbJKPoNtawHHnxoNXhJHCgAYoiZEJVAeZdvFIaxqWbDOklOsPaFZSwRTedplXOzTyvPfTcnIYUbBxFQRVtUOFxfNWurAhcSqARUaZLZZqFTjXFfKxhjmrDoggMzMocEpMOuFdneDAgEBcBlfGeToLLpqkKromWm");

    if (dVXqGuGvuSzDV == true) {
        for (int VaRpbl = 1118433221; VaRpbl > 0; VaRpbl--) {
            bKAeOBFIbWWf = jGvokvyJMy;
        }
    }

    return hjTBqSeCqWqOUIP;
}

bool wxZXptfDJJk::DSnNcTPHCvx(double JWkFyyz)
{
    int FQXHFDw = 1348330862;
    string plIsOc = string("yGNsSMBmMxXwdceDkfUnWheKmBVWnccRXklBZFXkIODpUj");
    int cckxk = -1971109712;
    double UAaqmrXbJNPaE = 485963.61291606206;
    string UXpZiaqtqnv = string("hGTdaquUdFvcrakifCbAiyqZiQyurVxffaHJhxJoEWZCzxMDRWSUWuHYYpkymBMncvBbBtFuFsMZKrcGbLOmMAxliMPhKLTwXUhypvtYcKhFdGyVHllBaLXUCdrbKEICXjzfNJHZosRQygYERkwSbMzSmUErvbjMsYlnUqcefkjgjVehIFzqfYyUUxnrFduEQLaceiJjEcwTsDqjeOmfOYZZWDpQRwVPnMIQZLfxZbiXbneKwbdtPURYqzYeAob");
    int UIGknluC = 1659795633;

    for (int UgUcIAygyYcXJ = 1463090352; UgUcIAygyYcXJ > 0; UgUcIAygyYcXJ--) {
        UIGknluC *= cckxk;
        FQXHFDw += FQXHFDw;
        FQXHFDw = cckxk;
    }

    return false;
}

bool wxZXptfDJJk::zkySxhaaWFbBwTx()
{
    double HPsNVMLeJlNWC = -350451.10225532996;
    int KfwfQTrBNz = 1749809150;
    bool VFzHbbXUoKh = true;
    string cUkOYk = string("ZTgtCFiZzeAdBvaJuGjkFaIehTbFRyWqfcyLJUBOSZwyHszbedTVgZcyVTUmJiySmBCKtYkBJYzQAwGjzXCNNpuZsooqoZZfxHJefBcModkKZcNFxAcIADFegJZLQDJAfCYAIRNCzrmSZXQdksjnwyChXiEhIuDdUqihRhFHfUpCQysJZBB");
    bool ZYtNROrmWaBGA = true;

    for (int iUREDkIkr = 1738538091; iUREDkIkr > 0; iUREDkIkr--) {
        continue;
    }

    for (int GNZsRpmonlWEBHzu = 939125880; GNZsRpmonlWEBHzu > 0; GNZsRpmonlWEBHzu--) {
        continue;
    }

    for (int GOwchCpxcaPzVf = 1820037413; GOwchCpxcaPzVf > 0; GOwchCpxcaPzVf--) {
        continue;
    }

    for (int cNRSlwq = 1463228007; cNRSlwq > 0; cNRSlwq--) {
        VFzHbbXUoKh = ! VFzHbbXUoKh;
    }

    return ZYtNROrmWaBGA;
}

double wxZXptfDJJk::wkZrzWk(int iHjNpFvNVfF, double eVRtsoZjZKMHJfs, bool hLjdGtVN)
{
    bool WfosYIOaS = false;
    int PaVVkkNmfrTIioQ = -1686374922;
    bool UZlDZD = false;
    int ZGtpeNmDNsMU = 1309531763;
    string aAVdc = string("GbOtwweLEcwawYXSqFJCikwfglOleDAOfmMlGEUgJTbVizEQtsthDUZpXhQQCnAVtzuhVbooFjTDN");
    int ZiMpXpesd = -1126328788;

    for (int cSLlEzOTGKF = 393628499; cSLlEzOTGKF > 0; cSLlEzOTGKF--) {
        ZiMpXpesd *= PaVVkkNmfrTIioQ;
        ZGtpeNmDNsMU += ZiMpXpesd;
    }

    for (int EpqoguUhzJjPlzs = 1133941572; EpqoguUhzJjPlzs > 0; EpqoguUhzJjPlzs--) {
        ZiMpXpesd = ZGtpeNmDNsMU;
        WfosYIOaS = ! hLjdGtVN;
        ZGtpeNmDNsMU *= ZiMpXpesd;
    }

    if (ZGtpeNmDNsMU != -1686374922) {
        for (int qdaSjAEtex = 1395803541; qdaSjAEtex > 0; qdaSjAEtex--) {
            ZiMpXpesd += ZiMpXpesd;
            aAVdc += aAVdc;
        }
    }

    return eVRtsoZjZKMHJfs;
}

double wxZXptfDJJk::rHTjSWo()
{
    bool MEJNYbmZrej = true;
    bool DqpeZxSjphU = true;
    int AVRGwGl = -1664030523;
    int sZAWkNBaZ = 1191349702;
    string HqBroKeKUL = string("rqyGGdpvgkpNeXPBLBgxRiMkacIhTUYJFcgsYsYKmvUEoDUmyPIxsXdYGQjXQJIanYWRNXIHKLTOOilrlxTEIcODbPKaSAirWqvcvYBrCyt");
    bool CzcMJmCylThtPvS = true;
    int dduJdHNKxyDk = 659777424;
    string edVjL = string("IdBIOUMCPKzpnHmGuOYNpRqzgSdwJFZVEaVQgreBBNdTagBZKiedKRUnDJBNwHHqdFGXUIFHfHLVgMSaAMDWhakAUqgKmebmphuxrhEAjPPOEOMOVuDkxRSdLHLQNncJpiJZkocpbDZqjGIvXBMyFEecXjjMcrikHSQsmGoMmtWcMlchWQYJZbd");
    double kjvzgG = -311918.81697432935;

    for (int zVbDLOABJ = 1744735412; zVbDLOABJ > 0; zVbDLOABJ--) {
        HqBroKeKUL = HqBroKeKUL;
        DqpeZxSjphU = MEJNYbmZrej;
        edVjL += HqBroKeKUL;
        dduJdHNKxyDk -= dduJdHNKxyDk;
        DqpeZxSjphU = DqpeZxSjphU;
    }

    return kjvzgG;
}

wxZXptfDJJk::wxZXptfDJJk()
{
    this->rYUzKWG(string("vDZzycpexMBYCEGZCZhqgcHpQOQPRCkYCyhizWNnhPHrRhVdnbPKYvdvPoLafxQdYVBjHOnoYBiUpxuMuvzwnEWBwHSaMsbmBarKwwNavnloVSJFKVpItxfn"), -976916.4844931556, -996992066, -1166822119, -1282851693);
    this->JmQxJQzSZyGetpuW(221313.8426790679, -910748.2164169862);
    this->DSnNcTPHCvx(865920.8476292802);
    this->zkySxhaaWFbBwTx();
    this->wkZrzWk(818410333, -74667.3796243805, true);
    this->rHTjSWo();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nGoeMuBlODc
{
public:
    bool ikQGEtgBXTxoFAP;
    double pOeGY;
    int kgcgPGGyKodRuwr;
    int clSfTzIlZvUgEP;

    nGoeMuBlODc();
    void mAqVmvWAIyKxLo(bool VAXRkWyJIbLH, int rmJZLCQptRnEm);
    bool zfDdx(bool npImRUOTjjip);
    string IfQwqQHZ(bool lLTfzeogmryDa);
    int sYJVyJpupSGz();
    string QrHpKMjwwZkyJtY();
    double cUnotzD(double iBOTMLgfcbre, string IhZZDhQDujlnpF, bool MldPllcaaHRPH, bool zzDtPo);
    int FHgSVDEXtwzVl();
    string EnTICcmquos(int bFtkkkJ, string PZnADnFgDWZ, int HOTYOJvEW, double DBUZQgZY);
protected:
    double VMnZWYBmBNaDIRX;

    void fxkrxCzIXVc(double fYGbEMHCA, string ZMUXbp);
    string slQFVoPlgeRrfnZ(double qDYNL);
    string qtAYjbQIC(string BbbQXFzihO);
    int NTylDjMGuxM(bool tGFSXUKXLEjmSy);
private:
    string sGFZlPeijeE;
    bool yShxmfrRjwqpQB;
    bool FhtHgyselQOcRzey;
    int RZVfPJnYfvJNfCrK;
    int vmZYUaYIJynsyP;
    string SUTBiXcFHrZ;

    void UIdaKz(bool YkxqEVTnU);
    string qDixdlllqumkPkDH(string wQoaOUMjIPoIwihD, bool TnnVafJRHbcjKQKO, double QRFUjJW, bool WZGGzY, double wBuFDgNj);
    void pLKRJwkPjtul(int DmOkkzMjCswKg, string CriVBddMDk);
    void HfuyXrMQxE();
    void zYjmttXc(double mgGSRgUoRmZwIc, int EukbQIInkudO);
    bool kzTKdVMQax();
    void DTGvGl(double xEwgOOv);
    void gUSRVNtBiwFLLZs(double hCmovdfltuwCh, string dfuBpVL, bool nhWJXfjxgIJrJRGg);
};

void nGoeMuBlODc::mAqVmvWAIyKxLo(bool VAXRkWyJIbLH, int rmJZLCQptRnEm)
{
    bool gdBxUSljZZ = true;
    bool JQQBMCc = false;
    string vARnWosieCthD = string("CRzeTghf");
    bool YcjiUCoPMnDm = true;
    string tzCaxe = string("ZsIwzkJciSyZoIsmNlr");
    double TLjgRFb = -356885.19715058134;
    int vknGgMreanyf = -316860187;
    string JBzpdbtUzIxFQq = string("ZvgQyFZddTzumBUYnzMreWKbDTZOngQHQQZEQNSTubWBwHXIXGVjSHBJsdKibWnsMbVEzISbjtlohGotcbtKwJFqOXkPbssLVvVxpsATyyeZnSkueVMgDMcVRApGSLvQMQZOgPvzuWcvltVLQ");

    for (int HrJyauJws = 1395327811; HrJyauJws > 0; HrJyauJws--) {
        gdBxUSljZZ = VAXRkWyJIbLH;
        gdBxUSljZZ = YcjiUCoPMnDm;
        YcjiUCoPMnDm = gdBxUSljZZ;
        rmJZLCQptRnEm *= rmJZLCQptRnEm;
    }

    for (int fkMMiTDd = 2071191275; fkMMiTDd > 0; fkMMiTDd--) {
        tzCaxe += JBzpdbtUzIxFQq;
    }

    if (JBzpdbtUzIxFQq >= string("ZsIwzkJciSyZoIsmNlr")) {
        for (int iZCUYZLgpkAXL = 1842158667; iZCUYZLgpkAXL > 0; iZCUYZLgpkAXL--) {
            vARnWosieCthD += tzCaxe;
        }
    }

    for (int ciSCuFehN = 2059831880; ciSCuFehN > 0; ciSCuFehN--) {
        JBzpdbtUzIxFQq += vARnWosieCthD;
        tzCaxe = JBzpdbtUzIxFQq;
    }
}

bool nGoeMuBlODc::zfDdx(bool npImRUOTjjip)
{
    bool tZOmwxSluRPK = true;
    bool pYJgLUnHVlejfPCp = true;
    bool vmYuYobUrG = true;
    double fYxvyNG = 954788.7408798833;
    double jRUuRfVz = -66741.83903295716;
    string pguIRf = string("VWkODUUPdMriniRmnuqMQpEVyfQxmjPLihLpjuNMKZHdJmXowqbDwLjdkuIfrptdWKGmaONzx");
    string BORIEnfrNtPQo = string("VYFOyYpaiJfarmtIYLQMerpDGCZEaHMSJykCQDuobHWDLZEXborWkJSCJnnUcVHFkJCcUroyBCiLmzBpITuXRdJKJVvjwmURDcgjsSPMvdHQzlzyEitOUdVSmukFTA");
    int pYgduzQRifehJaN = 1230073274;

    for (int nwmaCj = 1190337270; nwmaCj > 0; nwmaCj--) {
        continue;
    }

    return vmYuYobUrG;
}

string nGoeMuBlODc::IfQwqQHZ(bool lLTfzeogmryDa)
{
    int DHdZdYfXNeGJQOy = 1474614657;

    if (lLTfzeogmryDa != true) {
        for (int JMVmbFV = 1426085511; JMVmbFV > 0; JMVmbFV--) {
            lLTfzeogmryDa = lLTfzeogmryDa;
        }
    }

    for (int ZpTQHNpaUhAYqb = 1546953112; ZpTQHNpaUhAYqb > 0; ZpTQHNpaUhAYqb--) {
        lLTfzeogmryDa = ! lLTfzeogmryDa;
        DHdZdYfXNeGJQOy -= DHdZdYfXNeGJQOy;
    }

    for (int aDkWsXAF = 1766250153; aDkWsXAF > 0; aDkWsXAF--) {
        lLTfzeogmryDa = ! lLTfzeogmryDa;
        lLTfzeogmryDa = lLTfzeogmryDa;
    }

    return string("LaTJIeQiQoXtJkKMwrgSxNtrmPEqisJUPgvKtCtkVNnzmQgBGKpxAXTRRFZnbvTnpyOOQQCJSKeMmKHyfkTKrYQywaSlGNWOKEP");
}

int nGoeMuBlODc::sYJVyJpupSGz()
{
    double rYJeNnCApzVo = -722644.5221210449;

    if (rYJeNnCApzVo == -722644.5221210449) {
        for (int makvvaWJWZyjVq = 100481345; makvvaWJWZyjVq > 0; makvvaWJWZyjVq--) {
            rYJeNnCApzVo /= rYJeNnCApzVo;
            rYJeNnCApzVo /= rYJeNnCApzVo;
            rYJeNnCApzVo += rYJeNnCApzVo;
        }
    }

    if (rYJeNnCApzVo != -722644.5221210449) {
        for (int TmUElapjbYaQBkrp = 1149202004; TmUElapjbYaQBkrp > 0; TmUElapjbYaQBkrp--) {
            rYJeNnCApzVo = rYJeNnCApzVo;
            rYJeNnCApzVo /= rYJeNnCApzVo;
            rYJeNnCApzVo /= rYJeNnCApzVo;
            rYJeNnCApzVo *= rYJeNnCApzVo;
            rYJeNnCApzVo /= rYJeNnCApzVo;
            rYJeNnCApzVo -= rYJeNnCApzVo;
        }
    }

    return 460283663;
}

string nGoeMuBlODc::QrHpKMjwwZkyJtY()
{
    int bazTvFFb = 291849410;
    string LdfTZRpzA = string("kLBdKKewhosLbTLNmfDwMJBNsLlWbyOLacUuBtpcNNEDUgmjAhAZOcDpkbtLvlcVqoWehUYDQclqHmFWjXkKdQhyyTmLdisNjbKwFoQJfbTHSivkHchmFZZMfGVZfzezOmRliBiLyJieaewVDTpMfFMKPyubrQSKnawsZcYMVfHEdCqJQu");
    int RvQOFdbbvgt = 99775335;

    if (LdfTZRpzA <= string("kLBdKKewhosLbTLNmfDwMJBNsLlWbyOLacUuBtpcNNEDUgmjAhAZOcDpkbtLvlcVqoWehUYDQclqHmFWjXkKdQhyyTmLdisNjbKwFoQJfbTHSivkHchmFZZMfGVZfzezOmRliBiLyJieaewVDTpMfFMKPyubrQSKnawsZcYMVfHEdCqJQu")) {
        for (int nqFrwOk = 231041332; nqFrwOk > 0; nqFrwOk--) {
            bazTvFFb *= RvQOFdbbvgt;
            RvQOFdbbvgt += bazTvFFb;
        }
    }

    return LdfTZRpzA;
}

double nGoeMuBlODc::cUnotzD(double iBOTMLgfcbre, string IhZZDhQDujlnpF, bool MldPllcaaHRPH, bool zzDtPo)
{
    double NENmSlNui = -263987.7620005499;
    bool ubIGLRbjTcW = true;
    string ONxwWFRpfqIAluE = string("wMStTeeYNJTcEUxxsJPrBfzjNJwtzVWJqAcQcWuaKuBhtLHbQxHXkRJiURIHADdCDUvYJta");
    int AheDEddkgOymGJ = 1673740915;
    string MOQpWXTgi = string("epOCUitxGqrrkExbLmAzOsnCPEBHUPp");
    bool snLKfM = true;
    double XvqSJ = 386875.8492345719;
    bool sqhGaAoSEbhna = true;
    int UkWkGAe = 1063082388;
    bool ozpWnlY = true;

    for (int BXAGmZYWlXWHCqy = 279630388; BXAGmZYWlXWHCqy > 0; BXAGmZYWlXWHCqy--) {
        NENmSlNui += iBOTMLgfcbre;
        MldPllcaaHRPH = ! sqhGaAoSEbhna;
    }

    if (NENmSlNui > -263987.7620005499) {
        for (int uAIKDKsyQkaa = 1573570616; uAIKDKsyQkaa > 0; uAIKDKsyQkaa--) {
            sqhGaAoSEbhna = ! zzDtPo;
            iBOTMLgfcbre = XvqSJ;
        }
    }

    for (int seITpHJ = 1425522293; seITpHJ > 0; seITpHJ--) {
        MOQpWXTgi += IhZZDhQDujlnpF;
    }

    return XvqSJ;
}

int nGoeMuBlODc::FHgSVDEXtwzVl()
{
    double YhdVBkJMie = -961106.8717975293;
    double oCETotYWfwaW = -891660.0372057508;
    string DNxLtHDqhAzTvO = string("crTaSRYdcWjAFnwxWNPCrXysiB");
    bool hihveCCFYJvX = false;

    for (int JeNsFXtpJUMBS = 921947111; JeNsFXtpJUMBS > 0; JeNsFXtpJUMBS--) {
        oCETotYWfwaW *= YhdVBkJMie;
        hihveCCFYJvX = ! hihveCCFYJvX;
    }

    return 1050636897;
}

string nGoeMuBlODc::EnTICcmquos(int bFtkkkJ, string PZnADnFgDWZ, int HOTYOJvEW, double DBUZQgZY)
{
    double QqIyyemPXHvbb = 622930.3848009682;
    double THPxawfIWRab = -79427.72247780467;
    bool Zbxzk = false;

    for (int omoSqzjrH = 1403735549; omoSqzjrH > 0; omoSqzjrH--) {
        bFtkkkJ -= bFtkkkJ;
    }

    for (int lwsacAu = 1137814997; lwsacAu > 0; lwsacAu--) {
        QqIyyemPXHvbb /= THPxawfIWRab;
    }

    for (int mgkMsettlobRM = 644157268; mgkMsettlobRM > 0; mgkMsettlobRM--) {
        HOTYOJvEW -= bFtkkkJ;
        THPxawfIWRab /= THPxawfIWRab;
        bFtkkkJ += bFtkkkJ;
    }

    return PZnADnFgDWZ;
}

void nGoeMuBlODc::fxkrxCzIXVc(double fYGbEMHCA, string ZMUXbp)
{
    bool BWKBeHaW = true;
    bool BvFysz = false;
    bool OhicmvIw = false;

    if (BWKBeHaW == true) {
        for (int TumWu = 441418806; TumWu > 0; TumWu--) {
            ZMUXbp += ZMUXbp;
            OhicmvIw = ! BWKBeHaW;
        }
    }
}

string nGoeMuBlODc::slQFVoPlgeRrfnZ(double qDYNL)
{
    string fXJXotYV = string("HHRFuzjcbInEyKnKDVVOTzFQNrrxRaDwbjOLKQZGFyzMFXsXudPKWMHHdNdFYAZuqznunBXHckeLYbaRYzbUqdYggLyiCIpMTNUlWbwvwRzxuUJsusDmXMNMXYhRwzpjMUQcrQDWnNdrUsZnQBLdxeoSfYGIAMkdzsfODvkzDKXVtlXGsFeveETOCmdlJuDfXdvpJwRBbcPjlRKDJgqzZPudHnkRalxwrUwYBJ");
    bool IkoOfOmCsm = true;
    bool zvDabrutRubEbt = true;
    bool jLaDzmWf = false;
    string wQErwcaWTNrF = string("LgucNEnavWXDPsbdQPKbaBLpkxbtbRTigMbSzbsXguqzZbKsztMTmXVDatEcLHhzdEwPfLWlvXAguPwAwXgNJpIfjUfifKpbZvZQQhVndNrbKRokpOILIITJeXToCgqcKJVJKJey");
    bool UxCkw = true;
    int mvvahSjWfV = -523064994;
    bool tgdeactTpySYeGS = true;
    string UkewCO = string("UpoXXDPXsUyHvXmEsTYudQNKaHzKWNHnOATDAiMEjZcDTKZnJfkSVEJyrjeUoVpQpAnQrxPWmMHRBApUGoMfRSsURfwLgFCedxLAYtcNSqBuMYkgeZzWSXtIbWGZwxCnuSaBTTKftzGHwWPKtwyyQdLRHjWzNAQgEbpSvvTSyikmnMfvIbVgScPffZnjsabpXJu");

    for (int jvUpMkaHQuPcNJsS = 1728742555; jvUpMkaHQuPcNJsS > 0; jvUpMkaHQuPcNJsS--) {
        continue;
    }

    for (int iAlEVjoyq = 1981804733; iAlEVjoyq > 0; iAlEVjoyq--) {
        continue;
    }

    for (int loLQOG = 1841025553; loLQOG > 0; loLQOG--) {
        IkoOfOmCsm = zvDabrutRubEbt;
        fXJXotYV = fXJXotYV;
    }

    for (int QgaCVYDXoxtstccv = 1637813694; QgaCVYDXoxtstccv > 0; QgaCVYDXoxtstccv--) {
        fXJXotYV += wQErwcaWTNrF;
    }

    return UkewCO;
}

string nGoeMuBlODc::qtAYjbQIC(string BbbQXFzihO)
{
    string pXwAErOOhPz = string("QPbxSDqVCdlUQGtXIPKQLMtWMkRfsZiaTkRJaBkarkajuRYRsykshEtgJrAuWgzuddAghEWZhAUpDJpjROjiZOKRidYsisGKSXoa");
    int SDhvjpmTw = -1458933261;
    string SjRLxcegf = string("FYeSwphECFnklySoyroxdltNBAfTKtyPolrsFgQxkNPmzeNJaKNGiSpqjtiNnQyspuiAmkNTrVYbwKeJPqsySsjTxcVCDouk");
    double sabwyKywpaQkjSg = 321130.5850337216;
    string NmQIVx = string("sPijQSkrLOZccIQlYqcxFKuCkYabRXLWOXfHUttUraETpAcWcGDzhdwEcDZHGpkYtCbBcTWHwLJfRwCFAmFpuDZciDHVYhfNINKq");
    bool gqfuWxEG = true;
    bool cIKNTC = false;

    for (int HvVXzFpsROlpT = 889101385; HvVXzFpsROlpT > 0; HvVXzFpsROlpT--) {
        gqfuWxEG = ! gqfuWxEG;
        pXwAErOOhPz += BbbQXFzihO;
    }

    if (NmQIVx == string("QPbxSDqVCdlUQGtXIPKQLMtWMkRfsZiaTkRJaBkarkajuRYRsykshEtgJrAuWgzuddAghEWZhAUpDJpjROjiZOKRidYsisGKSXoa")) {
        for (int UHamyzJU = 492022846; UHamyzJU > 0; UHamyzJU--) {
            cIKNTC = ! gqfuWxEG;
            NmQIVx += pXwAErOOhPz;
            sabwyKywpaQkjSg = sabwyKywpaQkjSg;
        }
    }

    return NmQIVx;
}

int nGoeMuBlODc::NTylDjMGuxM(bool tGFSXUKXLEjmSy)
{
    double yOeGE = 743127.5711417887;
    bool WjOazFjpDdTb = false;
    string UPlnuS = string("zxKHkrKxlsJNQByKXUWgzkSFpzyquMaViyGzCHK");
    int BpAtl = 1364105688;
    bool gUSpFCPeZoktrlD = true;
    int zLLOKbarMjUKmUq = -1773796336;
    int VYnqcWvk = 2138604023;
    double aLmLVjzZsJgP = 206546.70947562985;
    bool xmCLBbfdOR = true;
    string BXpMFYLQ = string("lRBjsoatkujIBnCBPGUt");

    if (UPlnuS != string("zxKHkrKxlsJNQByKXUWgzkSFpzyquMaViyGzCHK")) {
        for (int hnJcuUAvuERAHZu = 559781531; hnJcuUAvuERAHZu > 0; hnJcuUAvuERAHZu--) {
            xmCLBbfdOR = WjOazFjpDdTb;
            tGFSXUKXLEjmSy = WjOazFjpDdTb;
        }
    }

    return VYnqcWvk;
}

void nGoeMuBlODc::UIdaKz(bool YkxqEVTnU)
{
    int oZtHJk = 219767233;
    int VYVlkiMkKElQzp = 1254687390;
}

string nGoeMuBlODc::qDixdlllqumkPkDH(string wQoaOUMjIPoIwihD, bool TnnVafJRHbcjKQKO, double QRFUjJW, bool WZGGzY, double wBuFDgNj)
{
    int PEBCDYECUf = 1265553888;
    double MvODoMw = 397294.371893231;
    int GAHRAXDGeJNXoRhi = 1034736015;
    string DBNuOchTTu = string("JRiIHCFWfM");
    int pQwNeQ = -103867076;
    double wlocBvlCzUWT = 720496.6674006552;
    string xxAfUNpDkHFYF = string("ORnPZseXsVojoXMYykgQVhPQMvzFIDmnEBOULXnKcYexYybsBkFxPbnfOqoYUzafCqWOXCXdBdPBNScYweRBlJzyUPXjTrgCRPEGvQnYTtiBHmUTRYYNepWHnuPamyjYaGPbogKzGisflbZyAy");

    for (int QhUwQ = 1931361124; QhUwQ > 0; QhUwQ--) {
        continue;
    }

    return xxAfUNpDkHFYF;
}

void nGoeMuBlODc::pLKRJwkPjtul(int DmOkkzMjCswKg, string CriVBddMDk)
{
    double hRfWUjXBXfLsivt = -1040947.5130248802;
    bool pNtbXXf = true;
    double KiKDq = -454813.55734850804;
    int TaQsZFYgQslHVB = 1916794284;
    bool LyjIiwuTPTnzeI = false;
    bool ZBSGithsHrSkhImr = true;
    double XqPVEcRHhB = 311009.57661911956;
    string IKEwWmYkNtHT = string("oZJSXThiHqFlRUbANMitpVgOfxCeycaAyrnrnmcZrwAkfNbFAlBZBwtGoLmCtvPQMhWIOTNIVHZdghKZyvLvEPelyUaEIASHdxWRESDMFSryqJMnFavyywHHGFHTPOakCYKBXhEvrvzBLVQEAuyceaNIuDtrTrfzyhtnFBhzRtsHHbbsHDkXXrVeHxKALjuwgcnzutIbzRkaKdvRmrRkdWcHk");
    double AReNhukyoKfDDnKE = 561397.8974754948;

    for (int ORvGKPGWkOfUv = 1715493089; ORvGKPGWkOfUv > 0; ORvGKPGWkOfUv--) {
        continue;
    }

    for (int JvSUVEWEpJjLheB = 447481932; JvSUVEWEpJjLheB > 0; JvSUVEWEpJjLheB--) {
        hRfWUjXBXfLsivt -= AReNhukyoKfDDnKE;
    }

    for (int bLiuWfim = 1548760374; bLiuWfim > 0; bLiuWfim--) {
        KiKDq -= AReNhukyoKfDDnKE;
        LyjIiwuTPTnzeI = pNtbXXf;
        KiKDq += XqPVEcRHhB;
    }

    for (int JAQwkObyDIpDp = 196074461; JAQwkObyDIpDp > 0; JAQwkObyDIpDp--) {
        hRfWUjXBXfLsivt = XqPVEcRHhB;
    }

    for (int InyMjcfEqHmthcH = 1245403521; InyMjcfEqHmthcH > 0; InyMjcfEqHmthcH--) {
        LyjIiwuTPTnzeI = ZBSGithsHrSkhImr;
        pNtbXXf = ! pNtbXXf;
        TaQsZFYgQslHVB *= DmOkkzMjCswKg;
    }

    for (int itCgq = 137458666; itCgq > 0; itCgq--) {
        AReNhukyoKfDDnKE = AReNhukyoKfDDnKE;
        pNtbXXf = LyjIiwuTPTnzeI;
        DmOkkzMjCswKg += TaQsZFYgQslHVB;
    }
}

void nGoeMuBlODc::HfuyXrMQxE()
{
    string tqKQYcORYPAiaf = string("kdHHPUW");
    bool ajuoTjsO = true;
    int MGwsJfPNteOF = -1535713538;
    bool qjwTjsAxUn = true;

    for (int iuaElA = 1265979771; iuaElA > 0; iuaElA--) {
        continue;
    }

    if (qjwTjsAxUn != true) {
        for (int TEvrggbBGSJYkAp = 1902010855; TEvrggbBGSJYkAp > 0; TEvrggbBGSJYkAp--) {
            ajuoTjsO = ajuoTjsO;
            ajuoTjsO = ! qjwTjsAxUn;
            ajuoTjsO = ! qjwTjsAxUn;
            ajuoTjsO = qjwTjsAxUn;
        }
    }

    if (qjwTjsAxUn == true) {
        for (int uNUQMSKitJIXmN = 987753210; uNUQMSKitJIXmN > 0; uNUQMSKitJIXmN--) {
            ajuoTjsO = ajuoTjsO;
            ajuoTjsO = ! qjwTjsAxUn;
            MGwsJfPNteOF -= MGwsJfPNteOF;
            ajuoTjsO = ! ajuoTjsO;
            ajuoTjsO = ajuoTjsO;
        }
    }
}

void nGoeMuBlODc::zYjmttXc(double mgGSRgUoRmZwIc, int EukbQIInkudO)
{
    int mXrcxYXsSDwNCG = -1394497089;
    bool KueUIDxuZnqpxNrs = false;
    double ZFCYKISb = 544349.6768109532;
    string hVNaXkkCwYmiwA = string("FucPTpLMDYiftjQtRcZyMTXvduKAEGpNMQvGctYGgkcXulXJEmYdxOErqMdOPgPXKjfhlyTZgxZecyXDCOWwykRgmdjtLGhRJRxCwqfbataIgnpFQcBtjxpmPmYBuNHwSNQVbLGdgpyqKBRDqQPawYOyhIVkVoJAhqmaClMaxoPiJFICFfkjvuWnnwstEoEQuIZnlopFUOKYGOYHovdC");
    double LQoeFdltybwoybmc = -347903.6415091422;
    bool vDXKCBLIXzwHBwr = true;
    int CQcEUzwURJ = -858751763;
    bool uTEfHEAkshCG = false;
    int XefnX = 742944903;

    for (int rmivSxhHESEm = 1508549815; rmivSxhHESEm > 0; rmivSxhHESEm--) {
        continue;
    }

    for (int hOEJYWVXmaREv = 985698281; hOEJYWVXmaREv > 0; hOEJYWVXmaREv--) {
        mXrcxYXsSDwNCG = CQcEUzwURJ;
    }

    for (int ZCkVOEnitcb = 1516415488; ZCkVOEnitcb > 0; ZCkVOEnitcb--) {
        mXrcxYXsSDwNCG = XefnX;
        mgGSRgUoRmZwIc = ZFCYKISb;
    }

    for (int csQvkNvydvJDODnj = 150025259; csQvkNvydvJDODnj > 0; csQvkNvydvJDODnj--) {
        continue;
    }

    for (int QjbuxZ = 1399028258; QjbuxZ > 0; QjbuxZ--) {
        EukbQIInkudO += EukbQIInkudO;
        mXrcxYXsSDwNCG *= EukbQIInkudO;
        CQcEUzwURJ -= mXrcxYXsSDwNCG;
    }
}

bool nGoeMuBlODc::kzTKdVMQax()
{
    string ucstgtnzt = string("WFLXMhUquuKwsUCusbknnPHhRwQFwRdIFuZlEOqfJGmLwPEpBXSmzAcKXYJBpxVBbTwKBjGILeUkzAJwImlieYYLVdaIvCNnlHSeKXTfKUcZZGxsxDdHenzUJsYNUmUpOpymCqDAbNTSZKdKgXjdpLFqEWthRoFLNEmJnHTZrkVRjeAEzwUiRKjNRxQARNSyTEzZfTIRfhtdNGtLfgJzD");

    if (ucstgtnzt >= string("WFLXMhUquuKwsUCusbknnPHhRwQFwRdIFuZlEOqfJGmLwPEpBXSmzAcKXYJBpxVBbTwKBjGILeUkzAJwImlieYYLVdaIvCNnlHSeKXTfKUcZZGxsxDdHenzUJsYNUmUpOpymCqDAbNTSZKdKgXjdpLFqEWthRoFLNEmJnHTZrkVRjeAEzwUiRKjNRxQARNSyTEzZfTIRfhtdNGtLfgJzD")) {
        for (int fiYuEhVfxtSA = 1131134273; fiYuEhVfxtSA > 0; fiYuEhVfxtSA--) {
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
        }
    }

    if (ucstgtnzt > string("WFLXMhUquuKwsUCusbknnPHhRwQFwRdIFuZlEOqfJGmLwPEpBXSmzAcKXYJBpxVBbTwKBjGILeUkzAJwImlieYYLVdaIvCNnlHSeKXTfKUcZZGxsxDdHenzUJsYNUmUpOpymCqDAbNTSZKdKgXjdpLFqEWthRoFLNEmJnHTZrkVRjeAEzwUiRKjNRxQARNSyTEzZfTIRfhtdNGtLfgJzD")) {
        for (int RdOiHPkocmRx = 1229465969; RdOiHPkocmRx > 0; RdOiHPkocmRx--) {
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
        }
    }

    if (ucstgtnzt != string("WFLXMhUquuKwsUCusbknnPHhRwQFwRdIFuZlEOqfJGmLwPEpBXSmzAcKXYJBpxVBbTwKBjGILeUkzAJwImlieYYLVdaIvCNnlHSeKXTfKUcZZGxsxDdHenzUJsYNUmUpOpymCqDAbNTSZKdKgXjdpLFqEWthRoFLNEmJnHTZrkVRjeAEzwUiRKjNRxQARNSyTEzZfTIRfhtdNGtLfgJzD")) {
        for (int ZOTkyp = 1542644196; ZOTkyp > 0; ZOTkyp--) {
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
        }
    }

    if (ucstgtnzt <= string("WFLXMhUquuKwsUCusbknnPHhRwQFwRdIFuZlEOqfJGmLwPEpBXSmzAcKXYJBpxVBbTwKBjGILeUkzAJwImlieYYLVdaIvCNnlHSeKXTfKUcZZGxsxDdHenzUJsYNUmUpOpymCqDAbNTSZKdKgXjdpLFqEWthRoFLNEmJnHTZrkVRjeAEzwUiRKjNRxQARNSyTEzZfTIRfhtdNGtLfgJzD")) {
        for (int cAkmcECOnXoBhdFD = 820996829; cAkmcECOnXoBhdFD > 0; cAkmcECOnXoBhdFD--) {
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
            ucstgtnzt += ucstgtnzt;
            ucstgtnzt = ucstgtnzt;
        }
    }

    return false;
}

void nGoeMuBlODc::DTGvGl(double xEwgOOv)
{
    bool EjflYDX = false;
}

void nGoeMuBlODc::gUSRVNtBiwFLLZs(double hCmovdfltuwCh, string dfuBpVL, bool nhWJXfjxgIJrJRGg)
{
    bool bzZXXAwVrPBZI = true;
    double HpTvSMByACn = 153701.14299284556;
    double zrFnMZnjf = 50255.40946448857;

    for (int EYwGrTIPjD = 1187475619; EYwGrTIPjD > 0; EYwGrTIPjD--) {
        dfuBpVL = dfuBpVL;
    }
}

nGoeMuBlODc::nGoeMuBlODc()
{
    this->mAqVmvWAIyKxLo(false, -253712852);
    this->zfDdx(true);
    this->IfQwqQHZ(true);
    this->sYJVyJpupSGz();
    this->QrHpKMjwwZkyJtY();
    this->cUnotzD(-586177.2805148468, string("GDdesTOyMzvAosmZaaBbwqitPNAzXWJAZYbidATgJEzWGjvQiXKklmudcuaRIVhotcRyKAzkgqVebqEzKyxPDXDRcoXFnUQYWGTrFIQtjlDciyKcITOJPMCJwKKptxBqNIJoBMluPFmxcepqxNJUomeWanFyRioYUWawCfWYRazTNYrBqFgxNcEZowzVtQVzmTFMfqpwtFpxDdrmVyzeTyqMcmWWNWXYjTwrIBGHRccoVPrK"), false, true);
    this->FHgSVDEXtwzVl();
    this->EnTICcmquos(-1095261551, string("BXpVWGhXrwGdZkIMmES"), 566255380, 828615.0036771605);
    this->fxkrxCzIXVc(334242.9111546536, string("uHcFP"));
    this->slQFVoPlgeRrfnZ(-984716.7695715533);
    this->qtAYjbQIC(string("pUoiEDgqtIvRnvZQCqBxHypfxyBUEXuaAXikJlkyiRugJUSxTqvenRnafEKihnjLQktRqdyApvCXcDHvtKSZnjLMLotqOGXsnbhxJxIUHwWeDbhyHZuCyLRNZEcec"));
    this->NTylDjMGuxM(true);
    this->UIdaKz(true);
    this->qDixdlllqumkPkDH(string("TnmMMesMGkOFLeLejPPRyeDxKYsTJNeQpaArToKKGOONEFONHQOabyKuTzCvrDMrpTWbgbYAHRydbneIKrMwppqqmKEJfwyiXEV"), false, 672196.757876384, false, -311944.9740493666);
    this->pLKRJwkPjtul(1360130040, string("YaVRrmHOsLaIwVwmAhaXqHogcmSgoVwZWdGNGCrtyUvmJqsRybcZWYxQmDUqKlwgBFSohlSvtgGIWCduRMaUamLBkFaRGHsAmwufCJnGzxkqhzEMSwVoOZfJLiSmlEytaGQFqrzbgdDOavcAUktedEWi"));
    this->HfuyXrMQxE();
    this->zYjmttXc(-783372.0290649339, -58956606);
    this->kzTKdVMQax();
    this->DTGvGl(350134.5397009243);
    this->gUSRVNtBiwFLLZs(-625934.7459193242, string("nqBWAMVYQoUCiAkaApGQAEbzPPPtTtCPTIJajtOClBllojOQYUdOBbYAsSyswGmTtBspljfbhkAILznEzqFcHOQlHhxhLXCDrLjPl"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CbAAHmHAzFG
{
public:
    string vGnlxXczP;
    bool tepbFhH;
    bool QMFnh;

    CbAAHmHAzFG();
    string vNIfHLXYKqPPePS(string vogWWHS, string OhUVvwPcxGLNvmO);
protected:
    double pqPvWeWuLcFSIsj;
    int kHtah;
    string MKfvmLXPmhL;

    int CbzBH(string xYBXXLau, double nRCarRKlxVmRPBXX);
    bool XzVprszIMXVHrl(double zMoesZNHedH, double jGwNoQkm);
    void STznkKDintScS();
private:
    double plAWLtpbGjkqRwEE;
    bool rXnQmIIcMINiAW;
    bool CyzNbXS;

    double JasXi(double ffzFNyGVVLcrqsto);
    int HmuUlU(double oVyfWUpS);
    void RSkSH(int sFootLcs, double ideGZP);
    double sVNodgqdEp(int mTHHGtBxMrh);
    bool ngDWFMHjnXCIy(string WyTtJdumVA, bool KtIlxoNzMF, bool NGDwzbhBhZshx);
};

string CbAAHmHAzFG::vNIfHLXYKqPPePS(string vogWWHS, string OhUVvwPcxGLNvmO)
{
    double GwNzdzJhq = -783223.371422711;
    string UicgrYWB = string("xnhqnTogvcPhFFmZYWPbxEMjLOtejlVDgjvOOnrcGpsJrnDfdsARkcDOzIQVfqXeRtHHOLyKnduvNRX");
    int hioJbxz = -847450991;
    bool coMKsccmDlkP = true;
    string VLcIjGhm = string("PEvRIfETmSQLsLjBOMWJpZyLICbjnjyvQfKcWoVjqpCzyYdqIyCmayCEIxRoqUfsrBsFAoDZcHAgiLTyU");
    double YAwzEoo = -503623.8597695902;

    for (int hKddZGxLtBo = 679265561; hKddZGxLtBo > 0; hKddZGxLtBo--) {
        VLcIjGhm = vogWWHS;
    }

    for (int FPBQoRznDlCcwi = 1665129632; FPBQoRznDlCcwi > 0; FPBQoRznDlCcwi--) {
        vogWWHS = OhUVvwPcxGLNvmO;
    }

    return VLcIjGhm;
}

int CbAAHmHAzFG::CbzBH(string xYBXXLau, double nRCarRKlxVmRPBXX)
{
    bool fipqjiANW = false;
    double KBrLqwLi = 373585.64369769546;
    bool ZGMBAqDOiYcXcV = false;
    int rLspEWWiRUTIwqAB = 1956774221;
    bool kDpyvOQViemzLCa = false;
    bool BGUuvgS = true;
    double XUxDOTFAJBPMy = -815302.4856376646;
    string cozgn = string("lQiRkbDoklgmYnZRMDSsDuJPlKFPFDoQoBIzsiYodQxvcEFxXpiwAesuBxKuHNLZlxctggpWURBnSvDUdHjKYdEOfwWFQjcWtsSUMhxxfMnHqhjflUYuRuSTUNMaOgkbcRRiONKPsKOzZPOvsxVLkbXatZEXStYzBjCovwUlFzzphucDMTSQDIqXSoqxszUsUffIsnLjYDB");
    double LmtugRvA = -730431.4797978471;
    double jbqWoFWtc = 958800.86316683;

    if (ZGMBAqDOiYcXcV != false) {
        for (int FgESj = 1986557095; FgESj > 0; FgESj--) {
            LmtugRvA /= LmtugRvA;
            ZGMBAqDOiYcXcV = ! kDpyvOQViemzLCa;
            XUxDOTFAJBPMy += jbqWoFWtc;
            XUxDOTFAJBPMy += nRCarRKlxVmRPBXX;
        }
    }

    for (int dSeOodf = 774565178; dSeOodf > 0; dSeOodf--) {
        cozgn += cozgn;
        ZGMBAqDOiYcXcV = ZGMBAqDOiYcXcV;
    }

    return rLspEWWiRUTIwqAB;
}

bool CbAAHmHAzFG::XzVprszIMXVHrl(double zMoesZNHedH, double jGwNoQkm)
{
    bool IuvysVi = true;
    bool NKLtp = false;
    string kagCEdB = string("EBcVfNfvpSnfOvSESanujArJYysbCvWxrzrFLflwWJdsFdAbptPoWvZ");
    double hoFYyaQX = 52821.796337083055;

    for (int RiASL = 1783519947; RiASL > 0; RiASL--) {
        NKLtp = NKLtp;
    }

    if (kagCEdB <= string("EBcVfNfvpSnfOvSESanujArJYysbCvWxrzrFLflwWJdsFdAbptPoWvZ")) {
        for (int XXwlBcpT = 1328058289; XXwlBcpT > 0; XXwlBcpT--) {
            continue;
        }
    }

    for (int JQNwux = 2122277664; JQNwux > 0; JQNwux--) {
        hoFYyaQX *= jGwNoQkm;
    }

    for (int aQIBiUJHJ = 537252494; aQIBiUJHJ > 0; aQIBiUJHJ--) {
        kagCEdB += kagCEdB;
        IuvysVi = IuvysVi;
        NKLtp = ! IuvysVi;
    }

    return NKLtp;
}

void CbAAHmHAzFG::STznkKDintScS()
{
    string JfchOnHZAyQHRY = string("zTtTlhwZTPzhojJyXYQkTpMNvbrDppXpkoHVjFVONjEpndNlVbAozAWLBmoUHWCZUYHEWVTlNYEmOsNTgIfSwyZKhLACjIPoIQlIwrHMEwHyRSXhjZSnQzPZZsIo");

    if (JfchOnHZAyQHRY == string("zTtTlhwZTPzhojJyXYQkTpMNvbrDppXpkoHVjFVONjEpndNlVbAozAWLBmoUHWCZUYHEWVTlNYEmOsNTgIfSwyZKhLACjIPoIQlIwrHMEwHyRSXhjZSnQzPZZsIo")) {
        for (int SLRemtDs = 1767914532; SLRemtDs > 0; SLRemtDs--) {
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
        }
    }

    if (JfchOnHZAyQHRY < string("zTtTlhwZTPzhojJyXYQkTpMNvbrDppXpkoHVjFVONjEpndNlVbAozAWLBmoUHWCZUYHEWVTlNYEmOsNTgIfSwyZKhLACjIPoIQlIwrHMEwHyRSXhjZSnQzPZZsIo")) {
        for (int crDvuRKkUuhrJ = 672272938; crDvuRKkUuhrJ > 0; crDvuRKkUuhrJ--) {
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
        }
    }

    if (JfchOnHZAyQHRY == string("zTtTlhwZTPzhojJyXYQkTpMNvbrDppXpkoHVjFVONjEpndNlVbAozAWLBmoUHWCZUYHEWVTlNYEmOsNTgIfSwyZKhLACjIPoIQlIwrHMEwHyRSXhjZSnQzPZZsIo")) {
        for (int OZBdeqhILgIQ = 1799934838; OZBdeqhILgIQ > 0; OZBdeqhILgIQ--) {
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
            JfchOnHZAyQHRY = JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
            JfchOnHZAyQHRY += JfchOnHZAyQHRY;
        }
    }
}

double CbAAHmHAzFG::JasXi(double ffzFNyGVVLcrqsto)
{
    double LsGVJmQ = 822885.2648508028;
    string rAjTQ = string("fayLizzrpAsJpAtYsbvXHwDJNoZxRKDYrFcmjxRFuYkDLGLEfKsRLlmEQlAPRAZDJWnZENnaNVExfghuWhoccTQdy");

    return LsGVJmQ;
}

int CbAAHmHAzFG::HmuUlU(double oVyfWUpS)
{
    double cmtVTX = 950040.6611494925;
    double MPjKkwXRo = 168409.69023920665;
    int zeyYddcYuChbtM = 1690601119;
    int WVWxsnsZwZt = 1898251984;
    double vYXoBeeqomHCalk = 987006.817178052;
    int ZYtqP = -1235365647;
    bool xoWVR = false;
    double irkxeroiVnu = 442854.72306724597;

    for (int vxKWGCQiwNWeE = 1942031900; vxKWGCQiwNWeE > 0; vxKWGCQiwNWeE--) {
        MPjKkwXRo = oVyfWUpS;
        WVWxsnsZwZt *= WVWxsnsZwZt;
        vYXoBeeqomHCalk += MPjKkwXRo;
    }

    for (int ZKsNRTV = 461314821; ZKsNRTV > 0; ZKsNRTV--) {
        irkxeroiVnu /= oVyfWUpS;
        irkxeroiVnu = MPjKkwXRo;
        oVyfWUpS *= MPjKkwXRo;
        ZYtqP = zeyYddcYuChbtM;
        irkxeroiVnu -= cmtVTX;
        MPjKkwXRo -= irkxeroiVnu;
    }

    for (int naGENNsNNWI = 129402925; naGENNsNNWI > 0; naGENNsNNWI--) {
        ZYtqP = WVWxsnsZwZt;
        vYXoBeeqomHCalk = irkxeroiVnu;
        vYXoBeeqomHCalk /= vYXoBeeqomHCalk;
        MPjKkwXRo = oVyfWUpS;
        MPjKkwXRo += vYXoBeeqomHCalk;
    }

    return ZYtqP;
}

void CbAAHmHAzFG::RSkSH(int sFootLcs, double ideGZP)
{
    int OJmIC = 754441042;
    double YiuAuYoKz = -808691.151649985;
    string fvuQFjn = string("ppGDSExrocVOOicZPVAamWQtiTXTtIsxrrWevqNEMRqsJDfAXkdI");
    double MRIwqVEFTngag = 684723.708821388;
    bool OdSEvcIIWDMkIsrB = false;
    bool jVPmJUbRKyRxL = true;

    for (int azdvJVSsqvEs = 534025099; azdvJVSsqvEs > 0; azdvJVSsqvEs--) {
        OdSEvcIIWDMkIsrB = jVPmJUbRKyRxL;
    }

    for (int kEAZn = 833886070; kEAZn > 0; kEAZn--) {
        continue;
    }

    if (YiuAuYoKz >= -808691.151649985) {
        for (int VxuIrYlu = 491301387; VxuIrYlu > 0; VxuIrYlu--) {
            OJmIC /= sFootLcs;
            OJmIC += OJmIC;
            YiuAuYoKz += MRIwqVEFTngag;
            MRIwqVEFTngag += MRIwqVEFTngag;
        }
    }
}

double CbAAHmHAzFG::sVNodgqdEp(int mTHHGtBxMrh)
{
    string qNiNgcleCwfmww = string("wMuZbiRflGItPhONIcpDnuMetlQVrxhJrbOYJprQnErVVYHOWqkbHsqirwQeHrmTqxlavTiEbYFoAoGTTteKTkZeWwklnJNXTPBHKPpNAiaDJlelx");
    int EsoIHsYetS = 1584754222;
    bool WBhGPYxSMYZHvzq = true;
    double EiQOsWer = 146573.2226408893;
    bool yzWBTjd = false;
    bool KbQWU = false;
    double kOiURLzxKpdIlv = 442872.5605154832;
    bool uGZVXEqUzAI = false;
    bool JDprWIwtYaEJesl = false;
    bool nDnhF = false;

    return kOiURLzxKpdIlv;
}

bool CbAAHmHAzFG::ngDWFMHjnXCIy(string WyTtJdumVA, bool KtIlxoNzMF, bool NGDwzbhBhZshx)
{
    int lzwiD = 663410373;
    double ViKMM = 717204.4942112054;
    double sWesfDzwmseSq = 907294.0800075758;
    int UiytFPHdIeYgc = -562543185;
    bool gAORiplLzT = true;
    double jvLYPFdCYFIGIR = 955225.8919271282;

    return gAORiplLzT;
}

CbAAHmHAzFG::CbAAHmHAzFG()
{
    this->vNIfHLXYKqPPePS(string("MrqKarvRHwdWKnLEgCmnoIWaOxwGyhzMescsFuUjBevcnrGQSkVMjYCHRTLYFJWXwrgqgHPFMFmilBDCDcYhdtPIdyiIXwKzZfGlmypIXldLIElbpNmMyOWsEXrhnmE"), string("ALNnYyEmwYHKwqsuAaBkNOgqGKBRoaeCpvEEWEYXySaARmdFuLXHayTQzlVeSZJntoawBljLPATPPkLCKbtpxbkHeCisLXtbYYNbvoIyQRwWZqfwcNrjWuLIgGnrJoSt"));
    this->CbzBH(string("BpaVDCslWViUPMtdZgUxPVzaJYVJRDSzhGBvOVbiYDWSxGMAJZNHbCfASfYJXuzGORyQZBBpxkKzCaytQgwTDlppObhiQzeMcVZORKwrWkhahvLgGMNNXHthRMilOGBPZhBuJmLPCSExMtAvuGyybDNRQDGbtatObXHRVSMikRKkeHzLSozvHEjMR"), 778886.5884304357);
    this->XzVprszIMXVHrl(942578.3172281645, -199127.1893752215);
    this->STznkKDintScS();
    this->JasXi(626871.8337693131);
    this->HmuUlU(131208.11361466438);
    this->RSkSH(1388890468, -385839.54353025777);
    this->sVNodgqdEp(392123299);
    this->ngDWFMHjnXCIy(string("zz"), false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tpFBex
{
public:
    double RGeWCexdoFGQ;

    tpFBex();
    string HNorerkgKYl(double dGIlzyNGxPcQtb);
    string msAuAaLUepnwxfX(bool AJEBQHrGb);
    bool piLAqUfBisNZNh();
protected:
    bool QRvaN;
    double nNrdC;
    bool tlXfw;
    int alzeRcWMDjATh;
    bool YGhTbpwJceYzGE;

    void zACgrbNEBk(int ZvZhiVOUFu, string XqvKxAnIqSDqtV, bool DjbvRTpwgTRVGFmM, int ocVqKOZWLhYY, double jvuzFtcrKJMWwhEt);
    bool dfzyBykeObQDC(int XSfdKZaOnOiO, double GUOKZrg);
    bool ytBvllsy(int gJTiJORXZKPTv);
    int xTMDXflGcQwPqMj(double dEzBfXu, string ArLaxbrnRnkYmvT, string XIhiqvgv, double BbQvFuXsRjg, bool oGoDyYdKqJchAhwa);
    string muTlSytjXSxmYUfa(double ZHDHE, string nUIhkCixiABjnoz, bool BtvagsI);
    double MajUjwRfyQ(string plXrf, bool unnVBKYYt, string stexSgfbkflEJElW, bool zncNv, int FTaVyuXZlu);
    int ySCBSVQFaD(string yuUOPhfervCJTjMJ, double bbUBESeWd, double BirxPYGodFmEkS, double WMaAqNdoEzDP, bool oDFIkbefEVw);
private:
    bool QydgA;

    void fnTgmvtJaxBSZKy(string KeFyqLSQiWWB);
    void vIdUZvHJVxqtL(string YbrjWOAeABIwgZnR, int SrrqLp, string dZEztzT);
    int AqznfmwEdBIDLxg(int stmVwlcfDgHYhI, int dxQOxsoFubh, double zPzIQsiPTiv, int mAHEu, string FoJmvHJGOb);
    bool oZAZeBnBuvjgl();
};

string tpFBex::HNorerkgKYl(double dGIlzyNGxPcQtb)
{
    int AauUzut = 288712968;
    int TqRsOGlFTf = -324646540;

    for (int WNTBwglopO = 1497182402; WNTBwglopO > 0; WNTBwglopO--) {
        TqRsOGlFTf += TqRsOGlFTf;
        dGIlzyNGxPcQtb /= dGIlzyNGxPcQtb;
        AauUzut += TqRsOGlFTf;
    }

    return string("VmkkiYiQFRdtOksAOhLuhDBBqMDDDBkIVUCPiCpwMBQDdhbkpiKkHTPxfgXxojvwZPsjZNQeNoRKXPVFosyXhliHmmRPCQHuAuUBZMqfkbaLsEAvwYLZhkgvTjEeGsKUufInpVNJeuvzVxFhnBhAKBhhZwvUcVVPl");
}

string tpFBex::msAuAaLUepnwxfX(bool AJEBQHrGb)
{
    int gDsklTPTSMAorAVv = 75760220;

    if (gDsklTPTSMAorAVv != 75760220) {
        for (int ERZpIbdIUEXHUv = 680719821; ERZpIbdIUEXHUv > 0; ERZpIbdIUEXHUv--) {
            gDsklTPTSMAorAVv /= gDsklTPTSMAorAVv;
            gDsklTPTSMAorAVv *= gDsklTPTSMAorAVv;
            AJEBQHrGb = ! AJEBQHrGb;
            gDsklTPTSMAorAVv += gDsklTPTSMAorAVv;
        }
    }

    return string("a");
}

bool tpFBex::piLAqUfBisNZNh()
{
    int OwdIRyrAQWnUbgu = -123797666;
    int vmHlLLV = 1178025873;
    int SfmTqkSUdRu = -874717621;

    if (OwdIRyrAQWnUbgu >= 1178025873) {
        for (int tiEGEz = 736530837; tiEGEz > 0; tiEGEz--) {
            OwdIRyrAQWnUbgu -= SfmTqkSUdRu;
            vmHlLLV *= vmHlLLV;
            SfmTqkSUdRu = OwdIRyrAQWnUbgu;
            vmHlLLV /= OwdIRyrAQWnUbgu;
            vmHlLLV *= SfmTqkSUdRu;
            SfmTqkSUdRu *= SfmTqkSUdRu;
        }
    }

    if (OwdIRyrAQWnUbgu <= -874717621) {
        for (int sKSMXSoQkxMOb = 272185922; sKSMXSoQkxMOb > 0; sKSMXSoQkxMOb--) {
            OwdIRyrAQWnUbgu *= OwdIRyrAQWnUbgu;
            vmHlLLV /= OwdIRyrAQWnUbgu;
            vmHlLLV *= OwdIRyrAQWnUbgu;
            SfmTqkSUdRu *= vmHlLLV;
            OwdIRyrAQWnUbgu = vmHlLLV;
            OwdIRyrAQWnUbgu += OwdIRyrAQWnUbgu;
            SfmTqkSUdRu -= SfmTqkSUdRu;
            vmHlLLV = vmHlLLV;
        }
    }

    if (SfmTqkSUdRu > -874717621) {
        for (int xhBPZwkZ = 413084484; xhBPZwkZ > 0; xhBPZwkZ--) {
            OwdIRyrAQWnUbgu += SfmTqkSUdRu;
            vmHlLLV = vmHlLLV;
            OwdIRyrAQWnUbgu = SfmTqkSUdRu;
            SfmTqkSUdRu += OwdIRyrAQWnUbgu;
            SfmTqkSUdRu /= OwdIRyrAQWnUbgu;
            OwdIRyrAQWnUbgu = OwdIRyrAQWnUbgu;
        }
    }

    if (vmHlLLV != -123797666) {
        for (int vvJucvrbE = 1445711926; vvJucvrbE > 0; vvJucvrbE--) {
            vmHlLLV += OwdIRyrAQWnUbgu;
            SfmTqkSUdRu += OwdIRyrAQWnUbgu;
            OwdIRyrAQWnUbgu = vmHlLLV;
            vmHlLLV /= vmHlLLV;
            OwdIRyrAQWnUbgu -= SfmTqkSUdRu;
            SfmTqkSUdRu /= OwdIRyrAQWnUbgu;
            vmHlLLV += OwdIRyrAQWnUbgu;
            SfmTqkSUdRu = vmHlLLV;
            SfmTqkSUdRu += SfmTqkSUdRu;
        }
    }

    if (vmHlLLV >= 1178025873) {
        for (int PqkIBYzTmnLcZQ = 544646355; PqkIBYzTmnLcZQ > 0; PqkIBYzTmnLcZQ--) {
            OwdIRyrAQWnUbgu -= OwdIRyrAQWnUbgu;
            SfmTqkSUdRu += SfmTqkSUdRu;
            SfmTqkSUdRu += SfmTqkSUdRu;
            SfmTqkSUdRu /= vmHlLLV;
            SfmTqkSUdRu -= SfmTqkSUdRu;
        }
    }

    return true;
}

void tpFBex::zACgrbNEBk(int ZvZhiVOUFu, string XqvKxAnIqSDqtV, bool DjbvRTpwgTRVGFmM, int ocVqKOZWLhYY, double jvuzFtcrKJMWwhEt)
{
    bool NFiMudtTFdhdSrNO = true;
    string VCTgXAct = string("uCSlEz");
    int TUxjKZhTExjndhi = -1156173518;
    bool XFnZSTEAepuvkhXR = true;
    bool yeEaeRqVWiRyZa = true;
    string CFXtzEzP = string("ITrHJNoJZdvFqNByHElVjkSICpWNPOPveLjXvBTPFgIGuOvtVtmiarFUbctkfxbzvpvyOlSSDQHEwk");
    bool swYGfibeUqtsQaVU = false;
    bool oryVIe = true;

    if (yeEaeRqVWiRyZa != true) {
        for (int sJePOakmiSOdzJmZ = 1671195445; sJePOakmiSOdzJmZ > 0; sJePOakmiSOdzJmZ--) {
            XFnZSTEAepuvkhXR = swYGfibeUqtsQaVU;
            yeEaeRqVWiRyZa = oryVIe;
            TUxjKZhTExjndhi *= ZvZhiVOUFu;
        }
    }

    for (int gdGbDTN = 505735843; gdGbDTN > 0; gdGbDTN--) {
        swYGfibeUqtsQaVU = ! NFiMudtTFdhdSrNO;
        yeEaeRqVWiRyZa = swYGfibeUqtsQaVU;
    }
}

bool tpFBex::dfzyBykeObQDC(int XSfdKZaOnOiO, double GUOKZrg)
{
    string eLOEyHTNYQSO = string("ratbmaQYbSKcKAKUGqDyAbGfhktWzCEhaJrVcFrtLPvYYcVQsRLzaGbXtVsrHLJrGoguiuxRDXTmxvsFxcVnCnSbvgNeeNcYrjcxYAMDSpsvUDGdDTnTpoREppJMUQUoTcplcwTrZgZgJeZyEPiUslUwgOMROapipfxdkhm");
    double iTunANbYfrUda = 986347.5581763026;
    bool NvCjNkKWXiSmGeB = true;
    double MoeRaqg = 677283.6578406097;
    double ZSQofSQdp = 560754.1617316467;
    bool ABervMihWxb = false;
    string zwwMeHIRSLjxiu = string("lsxGfpShQesRWDNuYlmIYZnwksworNWtcVtoeQdhYEKxrLqKkWLuUmqvFSgeoDyDoLHbGUxLsFqgUBQmwdVGbZDawtcYQejgJHXbTUOzlskZwbwDEBJPjiAuDKmLeXLrsDlUdWdEJUoiwCYFxuePlWndtBRzGFevlGKFieXkI");

    if (GUOKZrg <= 560754.1617316467) {
        for (int VLTxIhhQOpIG = 952800059; VLTxIhhQOpIG > 0; VLTxIhhQOpIG--) {
            eLOEyHTNYQSO = zwwMeHIRSLjxiu;
        }
    }

    for (int fBoijvWXK = 1285271119; fBoijvWXK > 0; fBoijvWXK--) {
        ABervMihWxb = ! NvCjNkKWXiSmGeB;
    }

    for (int zmXsvblwhJ = 162697280; zmXsvblwhJ > 0; zmXsvblwhJ--) {
        ABervMihWxb = ! NvCjNkKWXiSmGeB;
        ZSQofSQdp /= MoeRaqg;
        eLOEyHTNYQSO += eLOEyHTNYQSO;
        iTunANbYfrUda *= iTunANbYfrUda;
    }

    return ABervMihWxb;
}

bool tpFBex::ytBvllsy(int gJTiJORXZKPTv)
{
    string OYjYooKO = string("kG");
    bool sOKcAvSchU = true;
    bool OKUfwTgYEGF = false;
    int gGbUpr = 2004539665;
    double MVtLBBbj = 209215.2399709672;
    int vOLnnKyWw = 925619037;
    int JjLuAmC = -2037172079;
    bool AaoRDJICD = false;

    return AaoRDJICD;
}

int tpFBex::xTMDXflGcQwPqMj(double dEzBfXu, string ArLaxbrnRnkYmvT, string XIhiqvgv, double BbQvFuXsRjg, bool oGoDyYdKqJchAhwa)
{
    bool hsJCkZrEZbjSCGhf = true;
    bool XAWiGOhkEAlbo = false;
    string nIIyQzp = string("SJYlvTydpdChDQAvaXxXjxuANKtdwJJkiDNvMwMdTKZigGSqcGTWGbQfxYWmiWgPMpzChfeuCWaAsytuYfTQfAKUXdELtECWDlmnBvhrlmIglZxadQVGtD");
    double IPLMzAp = 167562.81185385137;
    bool mLARcEOfTYgHhCwp = false;
    int FSAKCM = -2063756297;
    string XqdQjRlq = string("lpLaEaDCynKBnyDLhFxIOYgGJhYNBZogKjAFlvbhNwnwBmORkdIucqkvQGLBqxDvUehWTNJsOHbMtvxbm");
    bool YzjgCivTKTWqxFsX = true;

    if (dEzBfXu >= 167562.81185385137) {
        for (int MNQIVanMl = 2121582665; MNQIVanMl > 0; MNQIVanMl--) {
            continue;
        }
    }

    for (int wdHDbHYDO = 517906027; wdHDbHYDO > 0; wdHDbHYDO--) {
        nIIyQzp = nIIyQzp;
        dEzBfXu = BbQvFuXsRjg;
    }

    return FSAKCM;
}

string tpFBex::muTlSytjXSxmYUfa(double ZHDHE, string nUIhkCixiABjnoz, bool BtvagsI)
{
    double wSlfyC = -447964.7783465977;
    int MhaoIaKXXERvzAUI = 565974612;
    bool GFjrIW = false;
    string mdCTQJI = string("UshCtluDkAPsHhPYopGVAZMfjJzssIjAuZKNmiPbfTlRaTDIcIgqmfKtVmzYE");
    int logRfOYhhUIDAndg = 1992522044;
    double hQTNNm = -86753.12153663422;
    bool IyfaVjZYrNe = false;
    int nTWDYlsJZD = 1577724193;
    int qYAJCTTBugLWQXpr = -854514254;

    for (int mXuyxvrnAiFaR = 392604612; mXuyxvrnAiFaR > 0; mXuyxvrnAiFaR--) {
        continue;
    }

    for (int nAjNlGZHmnxZ = 1991658938; nAjNlGZHmnxZ > 0; nAjNlGZHmnxZ--) {
        continue;
    }

    for (int NRgDgmhtiypXMm = 768012717; NRgDgmhtiypXMm > 0; NRgDgmhtiypXMm--) {
        continue;
    }

    for (int LiLDMJfN = 1015624979; LiLDMJfN > 0; LiLDMJfN--) {
        mdCTQJI += mdCTQJI;
        qYAJCTTBugLWQXpr = nTWDYlsJZD;
        ZHDHE *= hQTNNm;
    }

    for (int fTgpEjOBsrzLfK = 2014180079; fTgpEjOBsrzLfK > 0; fTgpEjOBsrzLfK--) {
        qYAJCTTBugLWQXpr *= nTWDYlsJZD;
        ZHDHE *= hQTNNm;
    }

    return mdCTQJI;
}

double tpFBex::MajUjwRfyQ(string plXrf, bool unnVBKYYt, string stexSgfbkflEJElW, bool zncNv, int FTaVyuXZlu)
{
    string HhEsAnA = string("OSTDBXqydqKnGJOFcjSsCGcbwQyMNMhqzhsnaeo");
    double pWzmINp = 14567.735110823383;
    int mIKCEuWfPSqPhOxP = 758219745;
    bool lAEWLNXeMygePi = false;
    string aMbSsTFn = string("tWrURRFjkCwefRTXktqmwwOVDwFxFQdpYFlHsvxRWXGPsTjdOKsAkuANXFepXjWcAutwovoFCjciApDfrXOsXQMskmXAtEBmlyuyNFvTMIoSPQCFvMQAyZteKfpnkBFMwKWocZBxOlURfcdxdcmOokMxRqddqOlOrqsVwIlwXUHTNberjXunmgnwIqdXJOJovNmJDuOkuVkbJFxXHiFMSdKGgYQdtcNDhx");
    string BQCaFmnAwdNiMJmM = string("gOmzRzjWTrWJtZbOxpJUsxaXbsHLLcUpvmNjwyZmsDoQAQvUBEndUSthafwtKybyiJzYFbqZVcluCglFcIjIoBIWIgeFdwrlbWlZQenZuCqgmQPBfyBhyIkrHTIFQjdeoSIUugNdbKRbZHMCe");
    string bwLemOqKVJLpIp = string("LStCggHvrZigONrtqBAHIhhxkDvFSuOUDqcVCkQYEUvZroRdsISBRtKPKJEjQnSdrUZxBdXuKHVuBNhgYozNyvpjDArBFjFUBBxZNSHcycCoZpkDKzXLglRZIadObphOqWfTuSLcyKaHKiLELTUeEeZYpobMEzLBtzvOqIhGtnZRPTKszpzGqDNwwGaDlaHwqYBdbnInHkaYWadVBYZoVhTrBQxQgkoINOwORCtSGeffGVKCdHYUkRDiyh");
    int XXDplKvIgbuLeZd = 1153217695;

    for (int uAeDFcCpGqR = 446580246; uAeDFcCpGqR > 0; uAeDFcCpGqR--) {
        continue;
    }

    for (int sEVopZN = 1898279832; sEVopZN > 0; sEVopZN--) {
        continue;
    }

    for (int OwkSdeLNQEFh = 420682122; OwkSdeLNQEFh > 0; OwkSdeLNQEFh--) {
        zncNv = zncNv;
        stexSgfbkflEJElW = aMbSsTFn;
        HhEsAnA += BQCaFmnAwdNiMJmM;
    }

    return pWzmINp;
}

int tpFBex::ySCBSVQFaD(string yuUOPhfervCJTjMJ, double bbUBESeWd, double BirxPYGodFmEkS, double WMaAqNdoEzDP, bool oDFIkbefEVw)
{
    string IzmOa = string("hamhVcHGyaWDypdszOyRYWmCxaOqVzuhmmIRwmLuZUSouixMLwMSuNjoEavmeGPHSUnjaiYuoFdJkPnxLGJrXezDVRIrabdtPJUIoHVZsujGXAREXLceiQzi");
    double GKXSWIZUA = 974071.0217532989;
    bool nBbBhstKpatBAo = false;
    string viXVkhwyGYTWk = string("drmkWUhNzgFZEHHQQVmCAkcVrIGACTdxqCLkWfnjlOrXesHKLtTITyYmHqkPhahlnKWyGSHKQcMPJqfYqCexUcMHVjfxmirYKVqFtMrqGbiSYFlDwUDfGhIZDxtclqtMMBaRvCnQuycNSaJmZVxPeyzaiUIkvGkquTKCrNrBiwtZWIEksFUKaDAtYYDtcBVhAKoQeFWrHtndFMAyDaxkTfrrzOhvFmQmWQjziFHjGYdgpXOzMlAU");
    bool FpquFp = false;
    double zwpNbORio = 518562.6487441007;
    bool ANDyxwIpKxUkii = true;

    for (int tmnJVtAJq = 87324979; tmnJVtAJq > 0; tmnJVtAJq--) {
        ANDyxwIpKxUkii = ! oDFIkbefEVw;
    }

    return -513007640;
}

void tpFBex::fnTgmvtJaxBSZKy(string KeFyqLSQiWWB)
{
    bool UoITWjrdBH = false;
    bool OEBRNJxQvh = false;
    bool WJGVxwSvLzihMH = true;
    string GGIhLhO = string("TpWjrKAsqxprVLmKlqdpYebWFiQuTZeFXuFkRLqhZUhRQYgtIOfWSlKidauYaJfwPMntTJAhoiNYEdRTMRMLFRCppeEKVOJxXOEYFWmdBZPHIrFZCKBodsKgFfnyVhiyjTFhMwWYlJyupEnAiHPuXlzpcvyWhPuca");
    int YHFbmZpjxDX = 831240627;
}

void tpFBex::vIdUZvHJVxqtL(string YbrjWOAeABIwgZnR, int SrrqLp, string dZEztzT)
{
    int gSdPyQLVlmZenGlw = -240690117;
    string gJxRIr = string("FcEgBqslXtxuSrVETmQnafzqQHUpxiydkwBlgtVSVJcALraudhzznsbesZdNLuFSBqwQabmWEIOUGxVXefnyowVdXeYEtDpMFzAdeacVdYWDYOTcQyikbHGrxCWWeQqD");
    bool eWCcNyOKTKPIE = true;

    for (int aMMDfagoylVvCN = 432950578; aMMDfagoylVvCN > 0; aMMDfagoylVvCN--) {
        SrrqLp *= gSdPyQLVlmZenGlw;
    }

    for (int ItJRZcEB = 840395562; ItJRZcEB > 0; ItJRZcEB--) {
        gJxRIr = YbrjWOAeABIwgZnR;
        dZEztzT = dZEztzT;
        gSdPyQLVlmZenGlw = SrrqLp;
    }

    for (int ZmiKymTmOwqRAv = 1787308157; ZmiKymTmOwqRAv > 0; ZmiKymTmOwqRAv--) {
        SrrqLp += SrrqLp;
        SrrqLp *= SrrqLp;
        gJxRIr = dZEztzT;
    }
}

int tpFBex::AqznfmwEdBIDLxg(int stmVwlcfDgHYhI, int dxQOxsoFubh, double zPzIQsiPTiv, int mAHEu, string FoJmvHJGOb)
{
    double sjHmCMgjZdrihoAn = -166111.85219349334;
    double xcLEjYcMSkvFEPMZ = -682212.5706943355;
    double MfrnfuuOhfHVR = -1035505.5184740259;
    int XNsVxZzCH = -179262322;
    bool CHgyEWiYdDzXzZ = false;

    for (int GQlndk = 530117763; GQlndk > 0; GQlndk--) {
        mAHEu = dxQOxsoFubh;
    }

    for (int IVzkeY = 930136616; IVzkeY > 0; IVzkeY--) {
        dxQOxsoFubh = XNsVxZzCH;
        sjHmCMgjZdrihoAn *= xcLEjYcMSkvFEPMZ;
        dxQOxsoFubh = stmVwlcfDgHYhI;
    }

    return XNsVxZzCH;
}

bool tpFBex::oZAZeBnBuvjgl()
{
    bool EzsxhGBJHtROtKw = false;
    bool YflCQdCRQ = false;

    if (EzsxhGBJHtROtKw == false) {
        for (int PgUoYO = 1391278900; PgUoYO > 0; PgUoYO--) {
            YflCQdCRQ = EzsxhGBJHtROtKw;
            EzsxhGBJHtROtKw = ! EzsxhGBJHtROtKw;
        }
    }

    if (YflCQdCRQ != false) {
        for (int xfiwG = 907287189; xfiwG > 0; xfiwG--) {
            YflCQdCRQ = YflCQdCRQ;
            YflCQdCRQ = ! EzsxhGBJHtROtKw;
        }
    }

    if (YflCQdCRQ == false) {
        for (int QiHEJsUYwMkMxGA = 783211726; QiHEJsUYwMkMxGA > 0; QiHEJsUYwMkMxGA--) {
            EzsxhGBJHtROtKw = EzsxhGBJHtROtKw;
            EzsxhGBJHtROtKw = ! YflCQdCRQ;
            EzsxhGBJHtROtKw = ! YflCQdCRQ;
            YflCQdCRQ = EzsxhGBJHtROtKw;
            YflCQdCRQ = YflCQdCRQ;
            YflCQdCRQ = EzsxhGBJHtROtKw;
            YflCQdCRQ = ! YflCQdCRQ;
            YflCQdCRQ = ! YflCQdCRQ;
        }
    }

    return YflCQdCRQ;
}

tpFBex::tpFBex()
{
    this->HNorerkgKYl(854153.1247969631);
    this->msAuAaLUepnwxfX(false);
    this->piLAqUfBisNZNh();
    this->zACgrbNEBk(1671574050, string("swaNfqmEsVgoPbmx"), true, -405586158, -37967.43579231094);
    this->dfzyBykeObQDC(629179107, -58529.85454238506);
    this->ytBvllsy(1732441289);
    this->xTMDXflGcQwPqMj(-1048543.3190166425, string("brjlNScUPNkYGNLjQdUXjrmf"), string("hCyKYJxQTlTFbXrVViAJYpFgQuUKnqGASbCnTWTNotMNWPCPldCnIwcGNRDByVERdUCGxJBEfRKXTqgMGucjUrkdAKvDrYgtTdEENKGrPMgtCPjVYOuEtuQMKneURovGMwSoeEqhaVqMfnyHwhEpoPzzMnXMpULLFpBwUU"), 512735.578646814, false);
    this->muTlSytjXSxmYUfa(553797.1568819758, string("ZEKthAWVKifWcAhFgIePXfubUwcboQkqMJcPKbQddJgyiGjNYTTOjCCjdXgLIDfSWWEAIsnpAOmztyroknYqqZezwScjqeRCaDPtuHeflFezBSnxFMGFEUQlsGtnSYuizmftgrnlAAujCVJvqvSIVhSpboOxOfshqvrjQJ"), false);
    this->MajUjwRfyQ(string("uyqfnHelTiPMoYWLQsorAEDBzRDaVZyoYWqOQEnnCUgwyDgajLPNDOVCBiYosUVNqRPKWBWlqCsWEPxphHAVXTReiKtlJbuPuKUwwrRFaUPZqjjugwUVHafeA"), true, string("BmjCsscydtHjvLMbNTddYAzkDlvDhmiqiGsiQtgtoXXAMdsFUqAvojaYmkQEtPFYpBYBViRbTvehBurciMOFaEYHXZuRnCykSKxixoVrUrPlRdiB"), true, -258445568);
    this->ySCBSVQFaD(string("yauDQMzaXohUIRmLgpzVEjaOmkzsovKlsMOwInLpbhAIxymKyfa"), 166559.16730489116, 115950.55391306891, -1027040.0104234446, true);
    this->fnTgmvtJaxBSZKy(string("mhrJpNPMtNAmKFNpXIwYoPEnAfbovmaqRIwaURKBheOsxUkhypLGaECO"));
    this->vIdUZvHJVxqtL(string("ipsZJeAWkcIIDcxbVNVXQWGcRskathymQLZwMDaZeyIffeVnRLzRZyPlluk"), -1687034422, string("XAFp"));
    this->AqznfmwEdBIDLxg(1674670803, 1811414486, 47710.876427030526, -226691311, string("oeIhdbYvCgUFmorZFwCiHXRERcHUVzwtCnYvbfqnZbxAcPnMOdyUKvKLEN"));
    this->oZAZeBnBuvjgl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cwIsoMrNPpZoO
{
public:
    string iAjdjOxVf;

    cwIsoMrNPpZoO();
    double yRLNlOfu(double PSqFxyzIWCHSr, string uNCQCGXOCEmVF);
    void oBuVbgveZKvcTPp(string lZienZSa, int QjkkOB, double zYMELW, string MqZXNnm);
    bool MGFAPqUWL(double wDswKHoWB, double MzEot, double pWrnbh, int FoEeeBajlwpgLB, double baZxPCgL);
    void NLibTWXeMHXTiO(double LDjyG);
protected:
    bool gYymDQC;
    int eCyOtX;
    string zeYZyUUHiLAzbsTU;
    int WWNJXgZAWDTdZNXX;

    string xGENHxSNgLI(int TBGwW, bool JVyuqIfabqFivIkB);
    bool xwaChaSMA(int JqQOMDiTXljYu, string TcVrIjZXwOXtKGK, bool WUbMvFyWPweuQe, double tPnqZuK);
    void FmuDuWbdQBTD(bool SmdPbiWGHb, int HlPaUTdMJdrO, double NCzevqKkfTBFqozF, double cePdSdESau, double mWzKbitO);
    bool jAjZejwKnAbs(double TYRuYbrB, int kzJtLlLM, int KLltfdfiGTSFzEiQ, bool LasXdIAvrFDYtUX, double qYnOmOJULTUKpYle);
    double uhdddPTZv(string oSrIORK, int aaTxKLVoYuRvMgwb, double vvUfDCX, double BSomfkrJx);
    int PcRFaGESyeOb();
private:
    double PNiInVMhKpE;

    double CzMvTynsoj(bool JRTto);
};

double cwIsoMrNPpZoO::yRLNlOfu(double PSqFxyzIWCHSr, string uNCQCGXOCEmVF)
{
    bool nAhHghNeBm = false;
    string jVAzzLzYdQNs = string("htfsKUcZWJHkBHVNUTIesI");
    bool DaViYLfaMZGG = true;
    bool oMudVCVRfdBaD = false;
    bool gxAwRr = true;
    bool XkrVT = false;
    bool HSUtJyLlz = false;
    int nrWPGyh = 1878101026;

    if (nAhHghNeBm != false) {
        for (int PgHCrj = 529733120; PgHCrj > 0; PgHCrj--) {
            XkrVT = HSUtJyLlz;
            oMudVCVRfdBaD = oMudVCVRfdBaD;
            gxAwRr = ! nAhHghNeBm;
        }
    }

    return PSqFxyzIWCHSr;
}

void cwIsoMrNPpZoO::oBuVbgveZKvcTPp(string lZienZSa, int QjkkOB, double zYMELW, string MqZXNnm)
{
    bool BRGYggVhEeZ = true;
    bool owxdkH = false;
    string RXskE = string("mMrsxXrqjtUXKYiRWWqKJFlpBxgDEpQXidmbtBSCigvwKgPCMQkrpUSXctLitHkdfGIbdPmvEmkNHYbaDNmnvoeksWIqRfQUzplSKphBsKWaGIPSFTDrLxsLJjJilEkOvAzjvQrVaTogVkEEdrfkzWBPwbNPYCyNvjrtEVlXRxXIpMBVRTDtkKMrNkIqgTdPIXHImOquSdMWFRopsfxvkWXVVexHGFNsPIpZRfqTisatmZGoVB");
    bool UAMWnxArPzQ = true;
    string iABeWm = string("GmvSMdLboQHAIHYcRMjTzvnlcfokgtVnVBkwbGwlVqhCzEaltWFPFIXtxQQHTTPeZCLrZaMAgNkXRaICPjKjZSJgBkelzYlVFUyLTwauBnXIZyCExyGYIHAOochpiOOcEAfZWtdMxkRIwZBjZzluxTrbNNPVmAWkqkUdkOfEek");
    int vUCpif = 601679827;
    string lDTVAdtDLHLtvJ = string("qyBVaBjChOuPBLqVrVyJAyxpDxOQVIUtZZFyJjZdMZGeZaxCMRytyyHWAxIWXEpMOBWzHMKisCHUkZicDLIJCCpxyVZzONSfoRBasaDoXRrRCdWyVQHiqoRyIkilweWiTEgeGNCfIoQHiSKUhHhSjAPxawkiGfUWDmhOHnMGDaxkjpHrhrYpYrfUoBwBCszxtrxNmvPHlMtEnLxjseuLPGcOlbxbwCEysfwgEMUlsI");
    bool uZVnwJrodsQ = false;
    bool HyyBDgaRdXHQLTle = true;
    bool ebhFAbKnxaagg = false;

    for (int zbAUIpzhk = 147374037; zbAUIpzhk > 0; zbAUIpzhk--) {
        BRGYggVhEeZ = uZVnwJrodsQ;
        lZienZSa = lZienZSa;
        owxdkH = ! UAMWnxArPzQ;
    }

    for (int fTDpb = 1009744271; fTDpb > 0; fTDpb--) {
        continue;
    }

    for (int iCibYiwhGgy = 1527050952; iCibYiwhGgy > 0; iCibYiwhGgy--) {
        MqZXNnm = RXskE;
        ebhFAbKnxaagg = ! BRGYggVhEeZ;
        iABeWm = MqZXNnm;
        ebhFAbKnxaagg = ! owxdkH;
    }

    if (uZVnwJrodsQ != true) {
        for (int UbDupY = 1205769278; UbDupY > 0; UbDupY--) {
            UAMWnxArPzQ = UAMWnxArPzQ;
            HyyBDgaRdXHQLTle = ! uZVnwJrodsQ;
        }
    }

    for (int jBChWPUpXCdiANfj = 2097911577; jBChWPUpXCdiANfj > 0; jBChWPUpXCdiANfj--) {
        UAMWnxArPzQ = HyyBDgaRdXHQLTle;
        RXskE += RXskE;
    }
}

bool cwIsoMrNPpZoO::MGFAPqUWL(double wDswKHoWB, double MzEot, double pWrnbh, int FoEeeBajlwpgLB, double baZxPCgL)
{
    int aIegq = 162161717;
    double jFrIk = 546215.830635469;
    int IaEpOeGuSW = 1386131693;
    int QYxKzgFjtIKRY = 792029366;
    int JczihMxW = 74240199;
    string NJVmzVtWye = string("XvdJ");
    bool uPxUUTZGzbXzCUZ = true;
    int zrwEdZrJtClSYQB = -1166808932;
    int CSNyfJUqj = -1647965494;

    return uPxUUTZGzbXzCUZ;
}

void cwIsoMrNPpZoO::NLibTWXeMHXTiO(double LDjyG)
{
    bool bENnNKzaYNCc = false;
    bool dqXXLlla = true;
    string orIuuPKEpakf = string("wqWiAIFrszdEqiiIXzYwalPIsEEcjXKSdcFvlYTYiPbHUYekGXoJwOEbIlpxsAnAFgZINnYOjpFnzYtHOwNJDiNGtn");
    string TniUYYLxrSP = string("ytHFrOxnlQUOumtpprmjKfpAsBzGfUdz");
    int KWkJoUERcbEnr = 1997453713;

    for (int NICnI = 170391493; NICnI > 0; NICnI--) {
        continue;
    }

    for (int kiTuzPsMNGGRaUqv = 1598616643; kiTuzPsMNGGRaUqv > 0; kiTuzPsMNGGRaUqv--) {
        bENnNKzaYNCc = ! dqXXLlla;
    }

    for (int AMUuQjF = 1728126349; AMUuQjF > 0; AMUuQjF--) {
        dqXXLlla = bENnNKzaYNCc;
        dqXXLlla = dqXXLlla;
    }

    if (TniUYYLxrSP > string("ytHFrOxnlQUOumtpprmjKfpAsBzGfUdz")) {
        for (int FQNhctqbdmAGd = 640046820; FQNhctqbdmAGd > 0; FQNhctqbdmAGd--) {
            continue;
        }
    }

    for (int musAOTkdQhpeaN = 462705064; musAOTkdQhpeaN > 0; musAOTkdQhpeaN--) {
        continue;
    }

    for (int lWYMQVjShvL = 289253910; lWYMQVjShvL > 0; lWYMQVjShvL--) {
        dqXXLlla = dqXXLlla;
    }
}

string cwIsoMrNPpZoO::xGENHxSNgLI(int TBGwW, bool JVyuqIfabqFivIkB)
{
    string qkOfxClOpSNy = string("KauiDpOpeVBmWxzLOYTxItcDPHdHpMPCuTLXdgUHpXQQxhJsqYvFHHyJKFINSDhCSIfOpozXgENzquaKdyeRkcivoyDHXWRBwCptgBWHCYiJMQqoKvOSzQNyOHriKYpAxBNSJSK");
    string CAEWIxueCCeu = string("NoxTksLVgXbQAamzznfBNVhmyqAygFPCayBVdQNlOGzHlfUSuntFolBfVewznsQhcvMgtlVqFnsafmMrycgzaVUkHeJHaIFmCRYUwBnpOxzfJcXCGHlSDSQiUtzGpwjzQUqNKtuvMdJHuMKiXSmvaOMDlafSAKmEYFErYAUywvzeRGzsxnkYicDbtyoTAZymvzwOIwCkHbBINNBInVPqPdPIImSATQYarHiYJibZkbNioosPRvzEfu");

    for (int GcnKhCSW = 140140435; GcnKhCSW > 0; GcnKhCSW--) {
        CAEWIxueCCeu = CAEWIxueCCeu;
        TBGwW *= TBGwW;
    }

    if (CAEWIxueCCeu >= string("KauiDpOpeVBmWxzLOYTxItcDPHdHpMPCuTLXdgUHpXQQxhJsqYvFHHyJKFINSDhCSIfOpozXgENzquaKdyeRkcivoyDHXWRBwCptgBWHCYiJMQqoKvOSzQNyOHriKYpAxBNSJSK")) {
        for (int ZyVMwsz = 1034353209; ZyVMwsz > 0; ZyVMwsz--) {
            TBGwW /= TBGwW;
            TBGwW *= TBGwW;
            CAEWIxueCCeu += qkOfxClOpSNy;
            CAEWIxueCCeu += CAEWIxueCCeu;
        }
    }

    for (int cMRjPBL = 1834170290; cMRjPBL > 0; cMRjPBL--) {
        JVyuqIfabqFivIkB = ! JVyuqIfabqFivIkB;
    }

    for (int RlAGvE = 1806492776; RlAGvE > 0; RlAGvE--) {
        qkOfxClOpSNy += CAEWIxueCCeu;
        TBGwW /= TBGwW;
    }

    return CAEWIxueCCeu;
}

bool cwIsoMrNPpZoO::xwaChaSMA(int JqQOMDiTXljYu, string TcVrIjZXwOXtKGK, bool WUbMvFyWPweuQe, double tPnqZuK)
{
    bool jCibpI = false;
    bool hvvACGDXdFbwg = true;
    bool OgcGRD = false;
    double QnDGwsVPLCCEw = -266931.0964060252;
    bool xwdHTqMAKnatJa = true;

    if (OgcGRD != true) {
        for (int iDHwQdJDNwO = 425457580; iDHwQdJDNwO > 0; iDHwQdJDNwO--) {
            tPnqZuK = QnDGwsVPLCCEw;
        }
    }

    for (int nPuoWWghuGAqpt = 327490310; nPuoWWghuGAqpt > 0; nPuoWWghuGAqpt--) {
        WUbMvFyWPweuQe = WUbMvFyWPweuQe;
        xwdHTqMAKnatJa = WUbMvFyWPweuQe;
    }

    return xwdHTqMAKnatJa;
}

void cwIsoMrNPpZoO::FmuDuWbdQBTD(bool SmdPbiWGHb, int HlPaUTdMJdrO, double NCzevqKkfTBFqozF, double cePdSdESau, double mWzKbitO)
{
    int qZzNR = -332398874;
    string BOVvjbatWyTicuG = string("gbKTJgmEGqqyATPgHfjyxlTzOZvDXGKLIdpnFJzSXciTtkUqUKfHrwqTH");
    string uUnasMfH = string("wkLftoKNTBxHgWQvvDLxSOoPaNbuysBfbkxCBTSyewWZzwtpKrDNhDqJtmBDWvywtSddKWGqOVFsuhgGGggqCGUELXstcxvnhOvnwyNdaMAhkYLoBzCvzJWmhURXHwHnxLuYkLRpJYxALkQygSnVaLJEOYoTYRfSsPztDwephGUdYArGGOWzTAuLajJaOEvVdNx");
    bool TzrBUNlhtLE = false;
    double cubzHiOLEawPWcv = 470731.888647555;
    string tCHAaPUoakVHm = string("BNdRoBSBlwpcMkipXCGlPwUlxbwqgrgbTortqBZHMSxGbclRW");
    double zTDihSNKfhf = -851579.413007219;
    int npRRRkDZ = -1718810974;
    double mVjLrzIYgb = 215153.47914996246;

    for (int bQGjehwqconf = 1993041762; bQGjehwqconf > 0; bQGjehwqconf--) {
        NCzevqKkfTBFqozF *= zTDihSNKfhf;
    }

    if (cePdSdESau == 215153.47914996246) {
        for (int HPHTJxsBTr = 989288867; HPHTJxsBTr > 0; HPHTJxsBTr--) {
            HlPaUTdMJdrO += qZzNR;
            cePdSdESau *= NCzevqKkfTBFqozF;
        }
    }

    for (int jcUuEWdNisPzzJR = 1091547559; jcUuEWdNisPzzJR > 0; jcUuEWdNisPzzJR--) {
        continue;
    }
}

bool cwIsoMrNPpZoO::jAjZejwKnAbs(double TYRuYbrB, int kzJtLlLM, int KLltfdfiGTSFzEiQ, bool LasXdIAvrFDYtUX, double qYnOmOJULTUKpYle)
{
    string ijBWKVSDORcu = string("MObuwVTGdPErODxWwUTYOMmahdwgOzPdxEbzwzNeYhsBTqlaUNAknSbaMkvkaHTFHrRJRNDkaAbqReSMoyDNHKREFnkTRnkZMqPREfTUOSuHfzxBrElskqCoZoqBIuYwMFMncIDjfnOpqzrQMAKdUOlsZXahoPbeHQnFIuGsmqIcmMDfwAwMQ");
    int YqAugDwqdhLpWn = -876146330;
    int PwIsJRgVhDhosFgR = -812967411;
    int KTEzijDMWpJFKyva = -2106026368;
    double vcgHZxjcLisQ = -146296.97857617246;
    string HOdAevL = string("FGNxOhDmykfHGGevcPUYtNxphFNqNbhQZGVdHTQepFxzzTrFTcgFoUuZSMtFnRAWtoNngyelpHWIbyOwpnqzlJOtXccJMnHYqYUSiCpXkiJYElirLzaeXDeRKNkYkIJbvgACUszutWVjvTPSRHsGkfhKyOHyyWGWBxYlbG");
    int psyOGmGaI = 1954507260;
    string aZJxLJrNhZV = string("KrltNJXAasewTVrCGdgPyGHkrShfBUmcnuQUrxakDJUcXXaAfhaRDCehgvK");

    for (int miauSVsfdOrNAqL = 1571424626; miauSVsfdOrNAqL > 0; miauSVsfdOrNAqL--) {
        qYnOmOJULTUKpYle = qYnOmOJULTUKpYle;
    }

    for (int mhJvHIngBWhK = 938846037; mhJvHIngBWhK > 0; mhJvHIngBWhK--) {
        vcgHZxjcLisQ /= TYRuYbrB;
    }

    for (int UZoKwMFTJb = 192107672; UZoKwMFTJb > 0; UZoKwMFTJb--) {
        continue;
    }

    for (int LkVnsU = 682541624; LkVnsU > 0; LkVnsU--) {
        continue;
    }

    for (int XfZFLywbWQgi = 655311690; XfZFLywbWQgi > 0; XfZFLywbWQgi--) {
        PwIsJRgVhDhosFgR += psyOGmGaI;
    }

    if (kzJtLlLM == -876146330) {
        for (int IUpoHiENH = 1086463011; IUpoHiENH > 0; IUpoHiENH--) {
            continue;
        }
    }

    if (psyOGmGaI >= -812967411) {
        for (int FndHEDmkd = 1330322301; FndHEDmkd > 0; FndHEDmkd--) {
            HOdAevL += aZJxLJrNhZV;
        }
    }

    return LasXdIAvrFDYtUX;
}

double cwIsoMrNPpZoO::uhdddPTZv(string oSrIORK, int aaTxKLVoYuRvMgwb, double vvUfDCX, double BSomfkrJx)
{
    bool cOEfEUMlhd = true;
    double CRxKbh = 443550.70815410453;
    bool LvwuasgtUhop = false;
    double sESMKeXD = -109749.76622026067;
    string zrVqSS = string("SRbpBFmEIRVhDYSsJVPDpfzyPZjNNtZlIkWehsGXLGYLpLyazhTpNBNbCHezllBjFvpvBnjtBGvtzfVchHnRBaPzavSnUdjkffDkZcJVgNdrfBwuRhSQToyyVISTnZWRdJdiBRhkiihBPwmBcyfhqZPAHVISJkviJIGgiPwEqULyooTNbiPqQBJARjrnZ");
    double kIjnywBncAsrh = 876108.1145337775;
    bool NipfGGXmrxeb = false;
    string AljcbwaluuiT = string("NVeRSKcBaYCpfZoncXdprvRNqKzxdnYwIkeNpLZzihAvFyk");
    bool ihhwjyweMIHgdfe = true;
    double GtkoSKQhQn = -655530.4226667079;

    if (ihhwjyweMIHgdfe == false) {
        for (int BpAQTDRZhffirn = 1990242368; BpAQTDRZhffirn > 0; BpAQTDRZhffirn--) {
            AljcbwaluuiT = zrVqSS;
            vvUfDCX *= sESMKeXD;
            ihhwjyweMIHgdfe = cOEfEUMlhd;
        }
    }

    return GtkoSKQhQn;
}

int cwIsoMrNPpZoO::PcRFaGESyeOb()
{
    double SBahEmRyFhXxw = 893574.9798042139;
    string aQuuPSIqKfuy = string("WQB");
    string GUoxnbdeY = string("pATknjMTmFepXHBGojQJSvBOJvnpGBGbXIKcVdpufNbBRHAqBAuXBCcomfVZXmURyRxhQIaoHMwWtOudHRMMTKzejLHbbYRFPSCOXEvETesQaPFuaQcujtndErGHqcdnwspVdDMbDBYebrHZEYlgMnXLliintVNClYnaOVkLmaNGUVwMKPcCRcuagQvwQFwDyo");
    double XTpwuDMeIgO = -152714.33757766153;

    for (int oNrDZb = 2006168246; oNrDZb > 0; oNrDZb--) {
        XTpwuDMeIgO += XTpwuDMeIgO;
    }

    if (GUoxnbdeY != string("pATknjMTmFepXHBGojQJSvBOJvnpGBGbXIKcVdpufNbBRHAqBAuXBCcomfVZXmURyRxhQIaoHMwWtOudHRMMTKzejLHbbYRFPSCOXEvETesQaPFuaQcujtndErGHqcdnwspVdDMbDBYebrHZEYlgMnXLliintVNClYnaOVkLmaNGUVwMKPcCRcuagQvwQFwDyo")) {
        for (int ccDukUVb = 245814350; ccDukUVb > 0; ccDukUVb--) {
            continue;
        }
    }

    if (aQuuPSIqKfuy < string("WQB")) {
        for (int clcezwXNXF = 1185575939; clcezwXNXF > 0; clcezwXNXF--) {
            GUoxnbdeY += aQuuPSIqKfuy;
            aQuuPSIqKfuy = GUoxnbdeY;
        }
    }

    return 1138212559;
}

double cwIsoMrNPpZoO::CzMvTynsoj(bool JRTto)
{
    bool XfzWLwcudxMfpMo = false;

    if (JRTto == true) {
        for (int NTxBJjlRYs = 186499967; NTxBJjlRYs > 0; NTxBJjlRYs--) {
            JRTto = ! XfzWLwcudxMfpMo;
            XfzWLwcudxMfpMo = ! JRTto;
            JRTto = ! JRTto;
        }
    }

    if (XfzWLwcudxMfpMo == true) {
        for (int CNVABRU = 1093925; CNVABRU > 0; CNVABRU--) {
            JRTto = XfzWLwcudxMfpMo;
        }
    }

    if (XfzWLwcudxMfpMo != true) {
        for (int uqBmXjiIQmIquS = 1954129544; uqBmXjiIQmIquS > 0; uqBmXjiIQmIquS--) {
            XfzWLwcudxMfpMo = XfzWLwcudxMfpMo;
            JRTto = ! JRTto;
            XfzWLwcudxMfpMo = ! XfzWLwcudxMfpMo;
            XfzWLwcudxMfpMo = JRTto;
        }
    }

    return -752226.0562400692;
}

cwIsoMrNPpZoO::cwIsoMrNPpZoO()
{
    this->yRLNlOfu(517770.8443654491, string("wnymHyuHuXqHIFqCxNeGSWAeuQfxBBaCQYuGromnibSulZadlojSCrkBzULwehtJNoFxgXcZSzfzxdLRpAryhUqlCQmyopBCKDUXnddcIkKQKNjioQqKNy"));
    this->oBuVbgveZKvcTPp(string("WDEeCaFiFzeYhnUzESWFhy"), 1505284574, -92175.74877905313, string("UbCSzcyEgCLhvfzViyWftDpfghMjADSLIWuKOzixUOlpwyyNkjudAsiUkHGVXSfMqNdtMHZbaNdH"));
    this->MGFAPqUWL(-566936.9795775885, 529016.2762306983, 133463.21966694263, -107445101, -789373.1569986246);
    this->NLibTWXeMHXTiO(421928.1533476963);
    this->xGENHxSNgLI(-917999077, true);
    this->xwaChaSMA(744250640, string("KtwYMrfVjAOPgKtbDmfjjTACPllbFSLDEnQHbnuwJygnaAcqnYRFxwxOyJyNwyTcBzypwCXFnYHpLjcMNBxIAQKIR"), true, 659450.0590512931);
    this->FmuDuWbdQBTD(false, 417934960, -922458.9952011566, 745150.5582381526, -512962.1688937179);
    this->jAjZejwKnAbs(-466724.22354851075, 1745247847, 612553264, true, 946124.3371772928);
    this->uhdddPTZv(string("CGDgEvGfwvVBuECpkiOHelBtZrCokpOhoNjIHWYwsUojKHStDPuAqunPPHGMokpRPgKjHWiALEYxaoXRVFJSLFYyDshZFwfrCoipYBwpqeMAJIXRNhXjfKIaJTRkrEGwSYYJISYqGiVjWMdAaTCgmsVrtGuQMALYrIljfJqUUFjZhRSBOZPbLrHPeYfusmSDJRpaBGhmjkNcuxZlzeeddnvi"), -1278890720, -308933.27385485073, -431720.25066094554);
    this->PcRFaGESyeOb();
    this->CzMvTynsoj(true);
}
