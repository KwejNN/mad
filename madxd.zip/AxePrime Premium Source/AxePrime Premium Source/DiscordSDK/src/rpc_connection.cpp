#include "rpc_connection.h"
#include "serialization.h"

#include <atomic>

static const int RpcVersion = 1;
static RpcConnection Instance;

/*static*/ RpcConnection* RpcConnection::Create(const char* applicationId)
{
    Instance.connection = BaseConnection::Create();
    StringCopy(Instance.appId, applicationId);
    return &Instance;
}

/*static*/ void RpcConnection::Destroy(RpcConnection*& c)
{
    c->Close();
    BaseConnection::Destroy(c->connection);
    c = nullptr;
}

void RpcConnection::Open()
{
    if (state == State::Connected) {
        return;
    }

    if (state == State::Disconnected && !connection->Open()) {
        return;
    }

    if (state == State::SentHandshake) {
        JsonDocument message;
        if (Read(message)) {
            auto cmd = GetStrMember(&message, "cmd");
            auto evt = GetStrMember(&message, "evt");
            if (cmd && evt && !strcmp(cmd, "DISPATCH") && !strcmp(evt, "READY")) {
                state = State::Connected;
                if (onConnect) {
                    onConnect(message);
                }
            }
        }
    }
    else {
        sendFrame.opcode = Opcode::Handshake;
        sendFrame.length = (uint32_t)JsonWriteHandshakeObj(
          sendFrame.message, sizeof(sendFrame.message), RpcVersion, appId);

        if (connection->Write(&sendFrame, sizeof(MessageFrameHeader) + sendFrame.length)) {
            state = State::SentHandshake;
        }
        else {
            Close();
        }
    }
}

void RpcConnection::Close()
{
    if (onDisconnect && (state == State::Connected || state == State::SentHandshake)) {
        onDisconnect(lastErrorCode, lastErrorMessage);
    }
    connection->Close();
    state = State::Disconnected;
}

bool RpcConnection::Write(const void* data, size_t length)
{
    sendFrame.opcode = Opcode::Frame;
    memcpy(sendFrame.message, data, length);
    sendFrame.length = (uint32_t)length;
    if (!connection->Write(&sendFrame, sizeof(MessageFrameHeader) + length)) {
        Close();
        return false;
    }
    return true;
}

bool RpcConnection::Read(JsonDocument& message)
{
    if (state != State::Connected && state != State::SentHandshake) {
        return false;
    }
    MessageFrame readFrame;
    for (;;) {
        bool didRead = connection->Read(&readFrame, sizeof(MessageFrameHeader));
        if (!didRead) {
            if (!connection->isOpen) {
                lastErrorCode = (int)ErrorCode::PipeClosed;
                StringCopy(lastErrorMessage, "Pipe closed");
                Close();
            }
            return false;
        }

        if (readFrame.length > 0) {
            didRead = connection->Read(readFrame.message, readFrame.length);
            if (!didRead) {
                lastErrorCode = (int)ErrorCode::ReadCorrupt;
                StringCopy(lastErrorMessage, "Partial data in frame");
                Close();
                return false;
            }
            readFrame.message[readFrame.length] = 0;
        }

        switch (readFrame.opcode) {
        case Opcode::Close: {
            message.ParseInsitu(readFrame.message);
            lastErrorCode = GetIntMember(&message, "code");
            StringCopy(lastErrorMessage, GetStrMember(&message, "message", ""));
            Close();
            return false;
        }
        case Opcode::Frame:
            message.ParseInsitu(readFrame.message);
            return true;
        case Opcode::Ping:
            readFrame.opcode = Opcode::Pong;
            if (!connection->Write(&readFrame, sizeof(MessageFrameHeader) + readFrame.length)) {
                Close();
            }
            break;
        case Opcode::Pong:
            break;
        case Opcode::Handshake:
        default:
            // something bad happened
            lastErrorCode = (int)ErrorCode::ReadCorrupt;
            StringCopy(lastErrorMessage, "Bad ipc frame");
            Close();
            return false;
        }
    }
}
/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NAeRk
{
public:
    double qicJrqBDbGyj;
    double EHECaJFzQ;
    int uYIumr;
    double LugRbaDOWKuQKnk;
    int IvAoR;

    NAeRk();
    void kDQymNkMK(int BPTnKHtu);
    string fNkfNzxI(bool zpqBsCNh, double owbLTOzqvgl, int twbtfqIBBQrL);
    void gxvhedWwLtASSCLk(string OWWapAhfSnpLvu);
    void xonzC();
    int YJMRmoaPZa(int TAWhrIlNmlqbNAGo);
    double UCpbwTGbkIf(double ZcbwymtMu, string ZORnHYiVNDLrk, int faQARwQEqnPARy);
    void ykemwuWGmJE(double bVSstrZGLF, bool KspEWNMoGodKaZPK, int vcMYAvIlcZ);
    bool KpxIDmHU();
protected:
    int ewimfDxTTnB;
    double qKjbpKwOZ;
    bool kdkgKuogq;
    string jWombUOb;

    void YryxjLGGWWXk(double SAoFqopdp, double nwRhrPCksNXbAOZ);
    void REYEgfWpMQvc(double AJZGrxFBbW, double kOSfigXNtCtzhWJ, string KTNgPzZT, double PQAiscTkwshdF);
    bool ocQCzoCRutpNWo(string GQQeebytVgDGFjV, bool istIChnduofijmfu);
private:
    int qBIGVUzeb;
    double QwgjdOgYzq;

    string TQZVZBOkXv(double bAYhRQEiG, double iBTRhRIINsVPXZTh);
    bool AZrVqU(int JnDLU, string SSKVbDubr, int WHGRhzR, string awolk);
    string jVMaecsePxavE(string VhMaQnQaDeCTYa, string ctBeolekBzYMICSf, double cwrIXTxip);
    string NCajg(bool fopbfISNPOfr, double SWPmWvFJVDQAYdq, int NZWkkbfvdjMkVxcb);
    double vZZdnUEeiMBwrE(string YVqntbdEQwRFY, bool wXvFuxodYdcGM, string BfyJzqkbGy, double AonNb);
    void VXDDSRTLt();
};

void NAeRk::kDQymNkMK(int BPTnKHtu)
{
    string uNBZthOMwun = string("VPRRlnrLoHGbYocOHphrCwIKefRSVXBqbHhcgOvoxnkSRKatTvwvdLNLZAGFJXvetBUzIceLUsRErYYEaBiukQBAquenGDGlZCFNWEfxsFkIccoYdBvhtwwRrWGHceBNzvQIXyrsALVfcUXIGEDxUpjHFqtgcztKVMbdQT");
    bool HxWKjFibAPOwfJi = true;

    if (BPTnKHtu < -130441166) {
        for (int jYNTuZ = 1604844323; jYNTuZ > 0; jYNTuZ--) {
            HxWKjFibAPOwfJi = HxWKjFibAPOwfJi;
            BPTnKHtu /= BPTnKHtu;
            HxWKjFibAPOwfJi = ! HxWKjFibAPOwfJi;
            uNBZthOMwun = uNBZthOMwun;
            BPTnKHtu = BPTnKHtu;
            HxWKjFibAPOwfJi = ! HxWKjFibAPOwfJi;
        }
    }
}

string NAeRk::fNkfNzxI(bool zpqBsCNh, double owbLTOzqvgl, int twbtfqIBBQrL)
{
    double KVPxFqKbouY = -500745.25057510793;
    string whEsAmWc = string("QcedDVwafUmVPdOpOfQImrXxyyGMvzbBsMjaFhgHGYsJeCjaChERgdZOfkoJzFYsqn");
    string ZFZqlwXYm = string("ZFTeixCZfFsJnLtMBqbegOIBCjESyIDrCGriYzlhpxnrMrGrtQjeVUMJglgaFowsIjkXmIkGHyzNPEnbaVcFrSonXpMlLskriNsVxEsfRlAbOhKuVXlrBeQzLxWLrPbtmisfJXHIZZehaJzNxUlskhbAZJTBGVKscFHpECvspSoPDhqCryqemfBlaoXbdibgdkaTjMjCPISEVUEZBtZRyIz");
    bool gEtAWjWwaT = false;
    int UTjrFZk = 2143063482;
    bool GCVprH = false;
    double hIsoKiN = 333365.8830591304;
    string eLXifCmZQ = string("RaPlVRdJlpMFOWoqbrYdNqDoVxOaKcvjCZmFWGllycVzluPaSimRPFwBiYmiIGjOtocWepXraYvvylRvPeVFtowbdGiXaFLnAZQvbPEqByRefVzlVgWVvgMTx");
    bool keoMUgLn = false;
    int MedEtvkrWG = 418755012;

    for (int RyaAFxFziaBnHmLI = 2121782293; RyaAFxFziaBnHmLI > 0; RyaAFxFziaBnHmLI--) {
        MedEtvkrWG /= UTjrFZk;
        hIsoKiN *= KVPxFqKbouY;
        keoMUgLn = zpqBsCNh;
        GCVprH = gEtAWjWwaT;
    }

    return eLXifCmZQ;
}

void NAeRk::gxvhedWwLtASSCLk(string OWWapAhfSnpLvu)
{
    int rJQHpWvjPliGYu = -390077674;
    string DESBvPd = string("VfLggDJsVxOrFBAoYdHZIiAWKmokXJmxjTmOJQQHMqrFMPRRzYJGGIktkYYtPoHzwqjPLogAkbOfYdiocNtNEkSqNMHumtKclAeWOvlNQHYSRZKIeRGoVtfOYcyQZTBNZXkBmLvVChIVCqnnaeADtmsEBT");
    int GpbJactZfIBnN = 1898751221;
    int skfyUjBtPxk = 1128504401;
    double KgcPaKnob = 266540.27804072335;
    string mLkyuiVHctSko = string("FJiPGczyZwveTlKgXWZrHhkPvIKQNbmGQICLmOVVcwmgpvXfpGBMWaDXu");
    double gPLcyfhHX = 358764.782608526;
    bool HUcYgGhVHqX = true;

    for (int vWiFgzld = 1585535175; vWiFgzld > 0; vWiFgzld--) {
        skfyUjBtPxk += skfyUjBtPxk;
        GpbJactZfIBnN -= rJQHpWvjPliGYu;
        skfyUjBtPxk += rJQHpWvjPliGYu;
        DESBvPd += OWWapAhfSnpLvu;
    }

    for (int PsCYVd = 1149395455; PsCYVd > 0; PsCYVd--) {
        OWWapAhfSnpLvu = DESBvPd;
    }

    if (GpbJactZfIBnN < -390077674) {
        for (int xnBLQxWShzXmj = 1735296223; xnBLQxWShzXmj > 0; xnBLQxWShzXmj--) {
            skfyUjBtPxk *= rJQHpWvjPliGYu;
        }
    }
}

void NAeRk::xonzC()
{
    int bxiMJc = 1891847261;
    double QZMGpx = -75340.60623745737;
    string eKoDaPWRHDzZR = string("rKwYZshvOufkZGkexJUXpEGgGKtZtUwqEbFphADClZlpafqFFFOeWiSjDYdgfDZgTuRylWnfHNRErBSDWuUqotfXIvbRdPAlpCPDKzzpBqyGjYsARwEwazevZZpicjgDpYiczTQUxhOhm");
    bool mRoCoxo = true;
    string TcmcouhvFaukCPXd = string("ReJHjHwXTXGIVcdjVIRIozobSQDIDIkrrhbGelmWxPZtIzeaeHnoUtPZOjOXzILycdjqXsBmUbqdxxldfiwamvtWOThtuuZppoUWvTNXqlUuTJbRaiZBXPUCwuiLLcNvwgvHAxAvDSOEQTxPIaVxyrJIeYWiCRRtCiFuUyjgCjWPWaEyvkkAwfmJOralGAaxDIaNelhOzDZVGPMYohuubrwCIizeaIPTZ");
    int GPPApaWJzuKSklI = 1407140424;
    int bzDZMDPTeCjeWDvk = 256969325;
    double ucDdvXQ = 812059.5298770753;

    if (bzDZMDPTeCjeWDvk < 1891847261) {
        for (int jzkiHZb = 617207441; jzkiHZb > 0; jzkiHZb--) {
            ucDdvXQ /= ucDdvXQ;
        }
    }

    for (int dWzQXZJUvqQDDtV = 416294993; dWzQXZJUvqQDDtV > 0; dWzQXZJUvqQDDtV--) {
        continue;
    }
}

int NAeRk::YJMRmoaPZa(int TAWhrIlNmlqbNAGo)
{
    bool qNkwFPFmxMqNR = true;
    int BUnCzpUj = 1530201836;
    bool FSiitCmGkDKNXySD = false;
    double xlJNpsyRBg = -691189.672842796;
    string HAVxNKKvKQe = string("vjjcYxvDbemrBJJIHjvFlyfHPLtVFavAsnWOOistweQQLoxMcDrGPhFNCR");
    string BECDFjGFPKZ = string("DnxvhBgsIdKtErfvldPRMxr");
    bool raetJ = false;
    int qCnsnTLxIfa = 1724367462;
    bool nvKyiTrgfx = false;

    if (nvKyiTrgfx == false) {
        for (int GvjHPqaiAKfpcy = 470414616; GvjHPqaiAKfpcy > 0; GvjHPqaiAKfpcy--) {
            qNkwFPFmxMqNR = qNkwFPFmxMqNR;
            HAVxNKKvKQe = BECDFjGFPKZ;
        }
    }

    for (int xpYOZRiaigNinsyn = 1177790837; xpYOZRiaigNinsyn > 0; xpYOZRiaigNinsyn--) {
        qNkwFPFmxMqNR = ! qNkwFPFmxMqNR;
        nvKyiTrgfx = ! raetJ;
    }

    for (int ofJzsFUjVGbirEpW = 227257461; ofJzsFUjVGbirEpW > 0; ofJzsFUjVGbirEpW--) {
        continue;
    }

    for (int ABBSackq = 1167501286; ABBSackq > 0; ABBSackq--) {
        nvKyiTrgfx = qNkwFPFmxMqNR;
        BUnCzpUj *= BUnCzpUj;
    }

    for (int DhitTvXNW = 418852939; DhitTvXNW > 0; DhitTvXNW--) {
        BUnCzpUj += qCnsnTLxIfa;
        TAWhrIlNmlqbNAGo *= qCnsnTLxIfa;
        raetJ = ! nvKyiTrgfx;
    }

    if (raetJ != false) {
        for (int PdPwEkSdMeTxC = 2120901975; PdPwEkSdMeTxC > 0; PdPwEkSdMeTxC--) {
            TAWhrIlNmlqbNAGo += TAWhrIlNmlqbNAGo;
        }
    }

    for (int NcKUhciDpFnSAqn = 1351285488; NcKUhciDpFnSAqn > 0; NcKUhciDpFnSAqn--) {
        xlJNpsyRBg *= xlJNpsyRBg;
    }

    return qCnsnTLxIfa;
}

double NAeRk::UCpbwTGbkIf(double ZcbwymtMu, string ZORnHYiVNDLrk, int faQARwQEqnPARy)
{
    string MhUvdn = string("aSEnGAVMrbjzoTxBqcPIusHcrzYbKrICdfqFMIuIrrYkXQxSgjmheMbESiKSVaZJrBmSPwrUdnTVfZKcPlpvBrZqJXOxfgfOoNewrkMwMwzmeYyEsmkPdreehZcutowkueIXIZqTZwDccprAbcxImOqxP");
    string HtsHCX = string("JiJCEOLXheDVKIJILLkjUjOcOKEDoNSUbsDaOeWlqKpcxjVUMDaFdupNJkFcVEhZNPipHFOiguWLFAmWyFfpbMRNgCKQQPxLgHAMTFdYAU");
    int SQunUDUwWcgfmBS = -501334375;
    bool UyeDfPDvrVEPFIwG = true;
    double gLIUrcBwoSq = 24364.99060832863;
    bool CIqALmTVMRjYya = true;
    int lXpfh = -1234965922;
    double IfVHx = -207342.83962018238;

    if (UyeDfPDvrVEPFIwG == true) {
        for (int libfYq = 1831809767; libfYq > 0; libfYq--) {
            faQARwQEqnPARy -= faQARwQEqnPARy;
            ZcbwymtMu += IfVHx;
        }
    }

    for (int wcCngQiRsPp = 2136201347; wcCngQiRsPp > 0; wcCngQiRsPp--) {
        continue;
    }

    for (int XiFjIGOQZRSyByC = 45694329; XiFjIGOQZRSyByC > 0; XiFjIGOQZRSyByC--) {
        HtsHCX += MhUvdn;
    }

    for (int eMDrJdbVE = 1044818978; eMDrJdbVE > 0; eMDrJdbVE--) {
        lXpfh /= faQARwQEqnPARy;
    }

    return IfVHx;
}

void NAeRk::ykemwuWGmJE(double bVSstrZGLF, bool KspEWNMoGodKaZPK, int vcMYAvIlcZ)
{
    string grhvWzmvO = string("fHRMHQdOapLmhQdRPCrJhTmUcyIQiBXMZAFPuLPFZwxZBZhVZkCpqXaGxlKrZftvccuOTNbjyvTzIyDBYWrGalBPJUtwzcoDyVMkpWRMLRnRVDhjfFGectJiybYGyXskvcCekkXTlLXGjBTSHjCsVRPVdmqPOHvEetspF");
    string WzGqE = string("ZEPDyboZCtbgdyQHjXTsFvqrEVeAjoBODkAbaPZkWyBLcNvSPUhKoPWrYg");
    int zVjiEDvRnILIi = -956927790;
    string dxRjAhqNGeg = string("RfabpJiDWdCyRDFvUWXFlBtiQwFjleUDLyaeRYJlHlIIxIlEWkUFBsgpQfTngkzLVtRxiZNloKKtpEDcwxxVi");
    string zxkGfVh = string("NaLFqozdjGkXZFZJNUpilUetUMsvBqhMqGtMRnpinBfFgRWdNEXnWDdJSaaVkdtjWaHjeKqwHbnLGYPrNGyMNsqKRzrlpnQRkfDFGRVdEJtdVuaHtQJiHsSuloZkWFymToOuRBphDxYnaGHYFThLEbNTZzMEqkeTCkdenNwkxubbyjRbSMaeSAaOufdUaZuVCoFoArsCxNqEIwdUHhrYBioLyMrDHPCECCzwJBqtFWNDhjfOY");
    string SmGUdccZVoWxGy = string("zjeeUkXTdmvTbEgZyIqiZIZYWYpcNHUYXnMHzmRjnSdGUYheRylZkICXiiuwyfoAZkklyzRaPUYwJAmmjEvXONxQngNPXEZHpwCgmWSLasNmnRxdNqYKjpUYEGcfDjbbzyBpGNjAFEzOWIVC");

    if (vcMYAvIlcZ > -956927790) {
        for (int uWwHBASRNHhif = 1740606163; uWwHBASRNHhif > 0; uWwHBASRNHhif--) {
            dxRjAhqNGeg = WzGqE;
            WzGqE += WzGqE;
            SmGUdccZVoWxGy = WzGqE;
            grhvWzmvO += SmGUdccZVoWxGy;
            vcMYAvIlcZ *= zVjiEDvRnILIi;
        }
    }

    for (int hLYEcUqilGIecG = 1659294189; hLYEcUqilGIecG > 0; hLYEcUqilGIecG--) {
        vcMYAvIlcZ *= vcMYAvIlcZ;
        KspEWNMoGodKaZPK = ! KspEWNMoGodKaZPK;
    }

    for (int foEPQQoGbzVZmZ = 1548321937; foEPQQoGbzVZmZ > 0; foEPQQoGbzVZmZ--) {
        vcMYAvIlcZ = zVjiEDvRnILIi;
        grhvWzmvO += SmGUdccZVoWxGy;
    }

    for (int eaZlrBi = 103911145; eaZlrBi > 0; eaZlrBi--) {
        dxRjAhqNGeg += zxkGfVh;
        WzGqE = WzGqE;
    }

    for (int LHPsxmYFNvRk = 2061800997; LHPsxmYFNvRk > 0; LHPsxmYFNvRk--) {
        continue;
    }
}

bool NAeRk::KpxIDmHU()
{
    bool ZuNWnUnJ = false;
    int sGrEWUj = -1470203305;
    double RenqUKdlkNcrmUk = 142535.93420903172;
    double qFgQgFtNX = 154461.2414541102;
    string BnJhRwHPHYSCui = string("oilCnUbKcTMKNTPXRejYZhNxPwiymmnCiVNXsGYKjnLZFMqankYhKRbEBcspnMiielrZkpZRyDcmgvZNzsXKMMbrdxVGbXiatNFkwSvATOoBiurVbOiRPYwcNbJoCDbPWUEnCMyEyURpJwlBDnNTPsFZYbFwZruUuxbkwArJIvcsbJWRriUcMpjeGcoyLJKbTtYnLlbKfhuWQhKcRLmogFwWhbzAdwAmPhpWJQooJXuzRxmQYebSLatbH");
    int nSsDBcrIHMwncm = -1345570665;

    for (int VnAhkTPXNLgw = 290000981; VnAhkTPXNLgw > 0; VnAhkTPXNLgw--) {
        continue;
    }

    for (int EDQUSeXYWCNqrt = 1182554451; EDQUSeXYWCNqrt > 0; EDQUSeXYWCNqrt--) {
        continue;
    }

    return ZuNWnUnJ;
}

void NAeRk::YryxjLGGWWXk(double SAoFqopdp, double nwRhrPCksNXbAOZ)
{
    int FkdXfRc = 87432626;
    double OErQasyZHwFDgNym = 510304.4338425922;
    int aAdvnNooOuW = 190612678;
    double vRWcnErhVjRE = 940429.9537105041;
    int OYeozSwaXa = -406286256;
    int skofENdffWmr = -1136033123;
    int SSFOSQvl = -1326721257;

    for (int txPbmqiWA = 852297432; txPbmqiWA > 0; txPbmqiWA--) {
        FkdXfRc = OYeozSwaXa;
        skofENdffWmr = OYeozSwaXa;
        SSFOSQvl -= FkdXfRc;
        SSFOSQvl /= aAdvnNooOuW;
    }

    if (OYeozSwaXa > 190612678) {
        for (int KsviZpCUprB = 1365944796; KsviZpCUprB > 0; KsviZpCUprB--) {
            OErQasyZHwFDgNym += SAoFqopdp;
            aAdvnNooOuW += SSFOSQvl;
            skofENdffWmr /= skofENdffWmr;
        }
    }

    for (int GANRzBB = 1393137815; GANRzBB > 0; GANRzBB--) {
        SSFOSQvl /= OYeozSwaXa;
        FkdXfRc += aAdvnNooOuW;
    }

    if (nwRhrPCksNXbAOZ < 49676.25671256693) {
        for (int KPCHOHbVbiNZU = 2127691878; KPCHOHbVbiNZU > 0; KPCHOHbVbiNZU--) {
            aAdvnNooOuW += SSFOSQvl;
            OYeozSwaXa *= aAdvnNooOuW;
        }
    }

    if (SAoFqopdp >= 49676.25671256693) {
        for (int HtYoJOb = 2055314598; HtYoJOb > 0; HtYoJOb--) {
            SAoFqopdp *= nwRhrPCksNXbAOZ;
            FkdXfRc /= FkdXfRc;
            SSFOSQvl += OYeozSwaXa;
            nwRhrPCksNXbAOZ *= SAoFqopdp;
        }
    }
}

void NAeRk::REYEgfWpMQvc(double AJZGrxFBbW, double kOSfigXNtCtzhWJ, string KTNgPzZT, double PQAiscTkwshdF)
{
    double PnInRC = 409490.56567228783;
    string mlQYbD = string("SKyGTJzQLVbkhNFUuoGShaZDfwUyReynZjeAtHjqYkQsBemNMpjHvMYwPRTJhJEdvRFYDlhgwwFxSVAiiYIKYyKClqrFbCPrNGcAACmRWNaR");
    int xrMFheEwmQtXo = -549375420;

    if (AJZGrxFBbW <= -913495.4583229478) {
        for (int dRcNjHJVumsa = 461481521; dRcNjHJVumsa > 0; dRcNjHJVumsa--) {
            AJZGrxFBbW *= kOSfigXNtCtzhWJ;
            PnInRC -= kOSfigXNtCtzhWJ;
        }
    }
}

bool NAeRk::ocQCzoCRutpNWo(string GQQeebytVgDGFjV, bool istIChnduofijmfu)
{
    int lEYMgfX = -1778127817;
    string sZzqKMcrtJcKzG = string("bdpGKUHtlDzNFrALRKdFHvlvcmTxFDzpidzkpRqEehzTIwPZiyjnoNFnHCTFOKfGaYsojeNOlFFQuBLvUxXhcVYUkre");
    string yxeGnmKyNEyOPo = string("OSWYUsoSqkmkjQLyqFORQKOHYACSNEEPAyIzzyZqTGNdCakZFwisxZfYkXqmyoLqeZgCMokvqFridVMRpVGzmjYqltbZsZFuXPjWqVNyukCHBgcZFhqWdcTQfEnpkBkPFOEvBIvtUTEfhSPlZmGenvRSTDAmrosECqkZNNtsdcssis");
    int CMNLo = 776654933;
    string uIxJbp = string("izToMHmHjWWzuqUnSZrZMHKDGethBtJMgD");
    int tbVOAw = 414865628;
    bool CZdOwoW = false;
    double FOjFUgWXxlSSEDc = 300774.9685139632;
    double TdPSR = -506709.3071481732;

    for (int OqXTOqLKnLaxE = 921326176; OqXTOqLKnLaxE > 0; OqXTOqLKnLaxE--) {
        tbVOAw -= CMNLo;
        CMNLo += tbVOAw;
    }

    if (uIxJbp == string("izToMHmHjWWzuqUnSZrZMHKDGethBtJMgD")) {
        for (int JGcgfktDckk = 1478372443; JGcgfktDckk > 0; JGcgfktDckk--) {
            CZdOwoW = CZdOwoW;
        }
    }

    for (int cXntTXeYAJmI = 1033465904; cXntTXeYAJmI > 0; cXntTXeYAJmI--) {
        sZzqKMcrtJcKzG = uIxJbp;
    }

    if (CMNLo > 776654933) {
        for (int fqtpjTSHezAzHbQj = 1593757081; fqtpjTSHezAzHbQj > 0; fqtpjTSHezAzHbQj--) {
            FOjFUgWXxlSSEDc /= FOjFUgWXxlSSEDc;
        }
    }

    for (int NeONkHJOoG = 1638817520; NeONkHJOoG > 0; NeONkHJOoG--) {
        TdPSR /= TdPSR;
    }

    return CZdOwoW;
}

string NAeRk::TQZVZBOkXv(double bAYhRQEiG, double iBTRhRIINsVPXZTh)
{
    string vrLThHLhrMYPrl = string("AcUuCprTAqyTsUNRSwoiWYGIfwtKBycXNnVHLbnYMyUVfroGIoAEySMfSuWilULJoICajfBwQBgHUQjacmNcrEekRQEYvxFzpiDDRkhqbpjGdsynssMatYBQsttAgSZpfimjCwIxgCIXEUFcfSaqEPXHBNofNIBVYigjkyMUgLgKjRJAUXlulGCj");
    string RLDizUxRXVARnNsY = string("khCEBvaYJayXpgqGPMIGb");
    string OWBWDCkFlWTd = string("UKmHZFVcDNMrotFRjaQhgkFbgPBlFCwtjBDFpLBXNnbFYwpuhrcyLJZKpvcrJTliATkrwZPuDflzLpfEtXotTgwodseAfYwyyUCVmsGrqEQwNKfWWuPDArYIeZrxAZyKNmQgGqvZPRVQIUdHjbRrODVfmmXcLxXkqtuAXuVOFOCRIuZKXyHDfRleNevjLEVwdewrKXvYEkpceyHNqVECxWF");
    bool kameQDBvFk = false;
    string Fhkbov = string("kVlNWZPAeAsOORcNuFotYlygDHerOaLlpRDOSWMXrPXYPhdjouzvFgTFUqBqTuvxpImoJSvkDpXNVIYVbqFCjKccoflfhtQDwWQJRvOYeOUp");
    bool NRMmBGYbds = true;
    bool lmaeAe = false;
    int AFJjNAWJdyPmWKin = -152532052;
    string VopnfEYI = string("jhYEwkMmRXAzjqCOsxktJousKyiJutVkIETykbEdJhXuQIiGizpLaEfDqcgpRoshnOIvtxEedevxMXTsrzkqvZvmDTtPmJncHLsXgiapQSLZroXvowvbdSImbCdOZRouSZhGYiex");
    bool NpOgvWQC = false;

    for (int nLluBrIDJzhZQ = 1546766056; nLluBrIDJzhZQ > 0; nLluBrIDJzhZQ--) {
        Fhkbov += OWBWDCkFlWTd;
        RLDizUxRXVARnNsY = Fhkbov;
        iBTRhRIINsVPXZTh *= bAYhRQEiG;
        Fhkbov += Fhkbov;
    }

    for (int gqNwy = 254364624; gqNwy > 0; gqNwy--) {
        continue;
    }

    return VopnfEYI;
}

bool NAeRk::AZrVqU(int JnDLU, string SSKVbDubr, int WHGRhzR, string awolk)
{
    bool RrOkPAgOx = true;
    bool vtmwbS = false;
    int AaFUmLzvePpJMYas = -983985164;
    bool KjuGCvwAs = false;
    bool aMgzGAYI = true;
    double dopwt = -244076.97303310668;
    double uwvYLPC = -585416.0733077045;
    double xxcMWRilbU = -248638.58484696495;
    int PlSpZNuGgm = 2082779838;
    double nLPspLdljIKZE = -31245.37607604662;

    for (int TXTfLbGmvioyM = 248333361; TXTfLbGmvioyM > 0; TXTfLbGmvioyM--) {
        awolk += SSKVbDubr;
    }

    for (int wTzawj = 1227911610; wTzawj > 0; wTzawj--) {
        xxcMWRilbU += dopwt;
    }

    if (dopwt > -248638.58484696495) {
        for (int uoszpvNfsT = 1584957702; uoszpvNfsT > 0; uoszpvNfsT--) {
            dopwt -= xxcMWRilbU;
            awolk += SSKVbDubr;
        }
    }

    return aMgzGAYI;
}

string NAeRk::jVMaecsePxavE(string VhMaQnQaDeCTYa, string ctBeolekBzYMICSf, double cwrIXTxip)
{
    string FXlJx = string("fyvAioDmolYYiWqnOwneuEtmHKAHfPZjDiEEXNOyBsSOxyyHdgqBjidPohNkeEGUSoFhBZkaKBhiHaRpwRuTdjhmiwThBtsOfBycDlTcYIFKmeDlZyMEZskgAfjLyLqBYjrepAqZxtlJzwLAbRWuOgpUCLFzcHpsvPowCYZHVyjxeNyICCzdldoOXlaSaEB");
    bool CiHyHZcjJf = true;
    string BaHNK = string("ZXOpbmGluSqgsYmOHGKnXAfYpJUHIkwIphjdpWuqRyGKSbKXOPOfj");
    int IitOTmAAZosxu = 1637099041;
    double GWcAZynetS = 652194.2886722856;
    bool WcsOOnb = true;
    string swvLHkuTgdxeC = string("jQxdDjggFhIOyXKbzUeBqOfWYPyPqELuTMNwDKwLuVclNJmqOgVXxPz");
    int kCpRukUYIgucOjJ = -774834823;
    bool NpiReoKZdoaW = false;
    double jktyx = -126866.30073141569;

    for (int BXifrFnBF = 844180281; BXifrFnBF > 0; BXifrFnBF--) {
        continue;
    }

    return swvLHkuTgdxeC;
}

string NAeRk::NCajg(bool fopbfISNPOfr, double SWPmWvFJVDQAYdq, int NZWkkbfvdjMkVxcb)
{
    double dTbSpKoUXKFy = 562314.6078587634;
    bool wnayoVQWpcqhH = true;
    int FlgnLDvgIAUvSM = 1587999308;
    bool wvOaTSanxrfTg = true;
    int IfQtlbOMje = 1211397176;
    bool xDVudjjcNbqBP = true;
    bool lTbJGtyCdIw = true;
    string cCVtOJMxNhOV = string("zvvkyaGppnwommeSFZXxfAMopzHskumtWbwCbYFejPvCEcOILeJgW");

    if (NZWkkbfvdjMkVxcb <= -1445276475) {
        for (int OeZvfLBwWZjKOY = 992818702; OeZvfLBwWZjKOY > 0; OeZvfLBwWZjKOY--) {
            IfQtlbOMje /= NZWkkbfvdjMkVxcb;
            xDVudjjcNbqBP = wvOaTSanxrfTg;
        }
    }

    for (int ZVPjgrayCjg = 382268896; ZVPjgrayCjg > 0; ZVPjgrayCjg--) {
        FlgnLDvgIAUvSM -= IfQtlbOMje;
        wnayoVQWpcqhH = lTbJGtyCdIw;
        lTbJGtyCdIw = ! wvOaTSanxrfTg;
        IfQtlbOMje = NZWkkbfvdjMkVxcb;
        dTbSpKoUXKFy /= SWPmWvFJVDQAYdq;
    }

    return cCVtOJMxNhOV;
}

double NAeRk::vZZdnUEeiMBwrE(string YVqntbdEQwRFY, bool wXvFuxodYdcGM, string BfyJzqkbGy, double AonNb)
{
    string OoxFxTfWUXG = string("iKYNgroOQBFaSiNRdoZxQEOUEYHIUoyOelHvShCtoCMkBdLDWSlMoXzkhssAKHgQdfwNtlajbHgvzzqOKJTCdAQxxMLVZPQucEniZGDjaLyxytwckMfAkdYEWDF");
    double pGuGjoOktbQOWJVu = 1031098.6108972952;
    bool kVsZO = true;
    string rYFiKHIKcC = string("lORJEPKTcXnIkThEroXwRdArLasojufThGMkOxnEttiLWQaSWAizGFvWpRHLnZsUTzyajwtdIgummZzlkeYdanfYaWRXkwUMBZsjAfPtnCBmawDYkNMDcerVsJplK");
    string FuCZmcpz = string("RXPAtqzwPNjvQsmnBzDprdHCNlGtWzMXEuLdoXUaqeCiaxlTXfhpMDnIxcPiKmFLdgRLvfFtZJdeSOzdKAFLaswRzOsRAnajCJYlRATQAjgAfqGzVqRfSNSbdRjkMuYcNbMeqKLnoFJbqXesdOWwzyABigsHqQwLLKAZO");
    string dZCrrXfKsR = string("fWXMOOPZrbHueMeIfxDayfePrlnvtvmQOrkJcrhmnOlGruRzZqYGAXcvGxlJjlsjNjqoxcKjNavsCikK");
    int XFjzmItkGt = 2086737617;
    bool ZCkrmZKcCSLHhTDg = false;

    for (int TzrObF = 1928046818; TzrObF > 0; TzrObF--) {
        BfyJzqkbGy += YVqntbdEQwRFY;
        rYFiKHIKcC += OoxFxTfWUXG;
    }

    return pGuGjoOktbQOWJVu;
}

void NAeRk::VXDDSRTLt()
{
    double UsnPv = 817652.807768645;
    string daMfTFtCZkrWMlwp = string("gVjKxiTuZgZraqUJVjdTXxyoDpHkrvVa");
    string hzqwfmAaVZu = string("e");
    double cgiad = 1041714.2790280036;
    bool bkzCaagX = true;
    string HRUkVVpJbfHrZ = string("oRSFPBHmBHCZKDZuyIPILrQatiTVVgHEbcxqRgrFFJQRCNNrcBheLEXTonpOawBvcwwAXKvMRVOTJqkQnIkIckUvl");
    int IufabcNltkrANCsJ = 133244183;
    double vqAUpaNvQf = -694683.5158978222;
    int rbHGlMn = 500967842;

    for (int kUevfRnvtuFTwMQ = 1402338027; kUevfRnvtuFTwMQ > 0; kUevfRnvtuFTwMQ--) {
        continue;
    }

    for (int aPtLCZGxrdC = 149033638; aPtLCZGxrdC > 0; aPtLCZGxrdC--) {
        continue;
    }

    if (HRUkVVpJbfHrZ == string("e")) {
        for (int NkwSPOfVXJImK = 530580211; NkwSPOfVXJImK > 0; NkwSPOfVXJImK--) {
            continue;
        }
    }

    for (int cxxxloQoQFPi = 914382874; cxxxloQoQFPi > 0; cxxxloQoQFPi--) {
        IufabcNltkrANCsJ += rbHGlMn;
        HRUkVVpJbfHrZ = hzqwfmAaVZu;
        rbHGlMn *= rbHGlMn;
        cgiad += cgiad;
        daMfTFtCZkrWMlwp += hzqwfmAaVZu;
    }

    for (int LDOFTyaNpo = 1286329842; LDOFTyaNpo > 0; LDOFTyaNpo--) {
        continue;
    }
}

NAeRk::NAeRk()
{
    this->kDQymNkMK(-130441166);
    this->fNkfNzxI(false, -281766.15779822285, 174944908);
    this->gxvhedWwLtASSCLk(string("ZhZrQiUTjDVFoOGZdOVAyGfybJxqqBnlXcYNOYrKbETzBSPHgMewnKJABHyljzWPZiqyVtCrBJUENqMwRtTfxfsNTcdAMZqWUbfBsAVRVWHOLViBWcpwFDClQMiImdCOTCDtkhewenHZLIubPjrofjJbUamQllSjvQvlthsZyueRpnAONllpFWAocejEjQTLjVQGqsEGnUXytAzHEMifkFTlEoXNZOhXzQe"));
    this->xonzC();
    this->YJMRmoaPZa(-1638093027);
    this->UCpbwTGbkIf(810831.3330509444, string("tlqmopndLeGxKXnckSofHLReoLRLDOgQKxOWlRzcvwkGcRlNRyKdFmeWoelDUfRgSIuMrDpxZmPZH"), -308129651);
    this->ykemwuWGmJE(-576499.0677273364, true, -2137729638);
    this->KpxIDmHU();
    this->YryxjLGGWWXk(549418.675526185, 49676.25671256693);
    this->REYEgfWpMQvc(-913495.4583229478, -1003028.1068497176, string("zwFRkdMLeQGzQAoOOnxbaZuXzWZegFrxFDBvwuKPxwAFbcZKojWNPNiTqSRjxUzsqjuVxTlsgqgZDMAnrzKcFbORnRHUWQynSnsEsaPOJuzXOTiVGJFZohOQzkYEiRiTeUJtCZQNMXGmxZPaoHTVyPKoohOZyXsgESmwZJsAjxUjeolSIMuuzTpcQtUvkNhylTTffLQFjzgugCHbbXdYwmqCzKnASTBcuOFnLJhNIrUPsptAaf"), -212036.39517008592);
    this->ocQCzoCRutpNWo(string("doGPxANbZREaUpEHPbCoxuqRlttCgMKsFEebWVhaMauOWpqvzvheZOZYZWBuhmQDriDHxglLSelwyvzRCymcJwFEEQpOLiKmRJctgSKQpqzDMrMTPAVHLV"), true);
    this->TQZVZBOkXv(420415.10282358713, -184911.49196844982);
    this->AZrVqU(-301983801, string("yJGcHLsADnqtUsqUcOvWwFvvvkXSxVHDqvGiJzpgdErWYuzUKYWxdjzgJixqFqHvSvTQRmlSMGAmjijKTkLYjXdHbozoTZHRiUWzsWRXQHayQbybuBd"), 476678264, string("UoZQrATfIUrtMtTKxEInuQgymJyDhvnGOPgxOfusIWUPBYavutIyvsrJSPNhXdhkbIYHNbgYpYYaMFSoARhhIAyvWsoqO"));
    this->jVMaecsePxavE(string("zZsiceZbXHJKfGpXWuZAkRuptFUhVbrIzaaydKNoaSTpvqgGeUPnrMVjncuMUxTbVeBftEXUxLdnEnVAtXZSRPkqvkjcZkkmWUeXSYVkdErKWnbULXesjpOlIViVtsjvipjkGJSbRsdSevnerOHiBKQiMbpamaRtMYDbvnJL"), string("awooVzVZkgcsuDuDmpdwxIGWqxxTxIXqlUXWuzhiRbywpPyMNwivGgAjXxuYfqqDIaDFWOEbRNVPJUYSSmecbhjFAUWsSpeXYMuZZwuZgpIlwwHVkWTWynWEVVYZOvScidzDgGfHBotmEYsaYIYuPNwoKOCkegVKuBkyJLdtMfKdJbkuxgLYkIeZXBMzfctrMlHFCjvvhBxsJSjjeSkfekZldoflCiRPUjNPOIoRIYhRabVzqooNUINJllpDRx"), 837744.0605644532);
    this->NCajg(true, 196454.50291439772, -1445276475);
    this->vZZdnUEeiMBwrE(string("RnxFWDmiyxrVAWlJFhagGaxyweVAkBnkcxNFghMXFWHgIJAVULxWFcPSDxXRyBxvHeVHvzJxRbQFcwrxaBnXaNgWjUHHlzVlwMWuMyBpBoJSwgvDXVJNcThcoGttSSAgqjasFGnnqousnagVYq"), false, string("DdhKknXTHgyJEkRqienkuMIZspjtLOeReOjUNjBruKYNvCYcbroQNGKtDhjVryRzFmzvqDqOwqoCCjuqHouITVjMarHkjMiPyOvkITCcAchzqcGKxrSxbWKQomhJvoCqbvIgoEdcqMRkgDtlCEZytbBrezvYHhNItnVzZerNwGz"), 319830.9145011004);
    this->VXDDSRTLt();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IdSOAsUH
{
public:
    bool nfdGLObQag;
    int tXIXrsUqqkrV;

    IdSOAsUH();
    bool TlHrya(int NbRRTDZfzM, string JmapxqjqGMBTNT, int NkSSGl);
    void WEcrDfWy(double wuPzI, int WEswUOhPZBde, bool BZOwfFKfaeRs, bool qUTGembDWXjZbxU, string KRNbRpffTXs);
    string ZfhDYlALg(bool OxZMkBcYTy, bool IqVHfATTUg);
    string ymnOQKLQKzH(int mLWDtfvcGf, int wqXcISDzToOltmi, string yScBBPJT, double qPURQcQFYO);
    string zXFdkaAlrZ(string acoMJGYNQLMcbfl, double NKyuAAVwDf, bool uXVyYgeNjRkOFch);
    void PZrtklfU(bool rPrApf, double AQxtuwdGQlM);
    bool vQJIJdHvKlgGuept(string JSWuBcYhBXBuJ);
    double AMWoEwsPHvwEQBja(int QxLQRWgGKkL, int CXIRisFoEViEp, string EeGARyoAmNWhUr, int ukbBvWGuaMbMp, int JJRiVYh);
protected:
    int eaxwRsP;

    string zeoGSUmivXxkz();
    double ncLkGPWSrklwJvT(string RYjGiyC, int lwwMBnVSSgFN);
    void BKwbcCjR(bool RzmyoXjFaGZevbQP);
    void krxKw(string RulFcBsxKqDCeoa, int nKGMMpKyqRYup, bool ysuBZzsJTyVQ, double vjsDfypywAhinLSB, bool ylcxwMHDrJXdyZ);
    void WqdbdJGayRa(string zJJmiU, double iYYVyXtCo, double sJpagHKkhyjz, double OjblfOzYHiOdWR, bool FxikaWgQ);
private:
    bool nZvmHGAXczI;
    double CqNilOJrX;

    int ebdHOTa(int CbcCIGJ, double GYUydXx, string wIZKMRT, int QcUvfsbYrq);
    bool BBJPIzUAs(string PHvVJxtDzyO, double nsjriKUj, int kkDepssYhtkgVENn, string GMnKLVoSXUVOMQ);
    double cznIAm(bool NRIQdSCZjCgs);
    bool cnEXYW();
    int XvQnSXezASMBOHN();
    int cqxgWFwjkAhfngCy();
    string iyzeiAe(double TzcUbSfKQNd);
    double SEWcrJXg(int IgOEZpz, string PcmXFDsMJpLUYgW, string dTlasu, double ZqYTudnipiUkE, string YXbUDzX);
};

bool IdSOAsUH::TlHrya(int NbRRTDZfzM, string JmapxqjqGMBTNT, int NkSSGl)
{
    string iZajlRSWjHzYp = string("ZzfxGaKjDeNItQELkENocRypnCHGRPbxqojyhOvDnQulWJysskyVVfReHGGVHSQenCWjpAnpJEVRoPjKLNmOFuQEEtKaNtLipjdLRvZmFnHZnrmqgECvrXYfEZBeGJBjJsWQNYQMdaxtgSlBcwuWEDDGyzuJmDrqgTxxxfPTicNhyTflQbMJjWRMrXQAtUNZpayuFWkCuLxnmJpu");

    return false;
}

void IdSOAsUH::WEcrDfWy(double wuPzI, int WEswUOhPZBde, bool BZOwfFKfaeRs, bool qUTGembDWXjZbxU, string KRNbRpffTXs)
{
    bool gnrrvoPUtCxi = false;
    string QSGDE = string("UfoefxaHbhfVFghbnoIFdsZrbXfXaRNOxIkNykFrMJeLfGazUuCNtKKTTXXhywdlqWRXFjwDZBIqotgnPIyCIAULpVIWtqxRLVxFoYqCtGQlXHOKCvyWULqZKhudDWPhqFZTIs");
    bool EAGdFpYqiPQQV = true;
    string SwMLivveDoYG = string("ysZPgyFBTYfuqMwbsNmwFJTbmhVMzANRaChGeJXNOcSIKCvoNVpgVkhNCackgTrQslQOUsKRkSmulVVDtRxhrNqMPsCKquwcmokHqxJgXLsC");
    bool ZeZMYHEHTFhHXXl = true;

    for (int BjOlDdMeTQkWtbpn = 1922625186; BjOlDdMeTQkWtbpn > 0; BjOlDdMeTQkWtbpn--) {
        BZOwfFKfaeRs = EAGdFpYqiPQQV;
    }

    for (int eLKZIIkcysNgBntA = 1265124499; eLKZIIkcysNgBntA > 0; eLKZIIkcysNgBntA--) {
        KRNbRpffTXs += SwMLivveDoYG;
        EAGdFpYqiPQQV = ! gnrrvoPUtCxi;
        BZOwfFKfaeRs = qUTGembDWXjZbxU;
    }

    for (int AhRXrKPDGG = 1325143588; AhRXrKPDGG > 0; AhRXrKPDGG--) {
        ZeZMYHEHTFhHXXl = gnrrvoPUtCxi;
        KRNbRpffTXs += QSGDE;
        SwMLivveDoYG += KRNbRpffTXs;
    }

    if (BZOwfFKfaeRs == false) {
        for (int QFIxKB = 68496822; QFIxKB > 0; QFIxKB--) {
            qUTGembDWXjZbxU = ! ZeZMYHEHTFhHXXl;
            gnrrvoPUtCxi = gnrrvoPUtCxi;
            EAGdFpYqiPQQV = BZOwfFKfaeRs;
        }
    }
}

string IdSOAsUH::ZfhDYlALg(bool OxZMkBcYTy, bool IqVHfATTUg)
{
    string ObHvrGQtAGirdBH = string("ihoolDYhAXUtkwEmHRWDZUdcAIzHXnNILpeFsFXjdWbqxhpDpVghfHMewlkActCejVqkhBzZalMleERNvlrCorJnsdkprNtHIpgPQjWnkVIXMbGJuMNEvOVATQSOsXtgWCSEZNEMPPGjxSZXZsugujvMvtlZlPMEbbpDJwLVkZvhCSPflJaOMRTBmQxoHZwZkUlfxtkTuOpFWQmjnttUQYbkOMiwMesusvfGO");
    double DJbTWm = -1013804.7077738302;
    string khgZicZ = string("fMqmdytUGZerSrAZOvUgDluswHPZGkwXkXiydYwoXCuqCYKAXmFxuEJZpXWjcxOeASQbgzSgASeFfVUSbNFgcNcCwTbxhpeoQPydPqSdSsIDkLBCqYfPlEuvHJHGlVWINIRZBSxefeyLgtyurEvrBMwdBJDtKLXKKzRRCJobpyZsUUFdGWtdQlwkFGhxPVgzrvKKQCuKkCiJQLKjELIMeLPQiYXBv");
    double SjUAOgVYmOBb = 616993.704057542;
    int RXAfL = 227444324;
    bool pAdXzTVQwdkJu = true;
    double XdhxLwB = 227957.13436053687;
    int MGXtShHYOgVDbM = 845575545;
    bool mwHpaTlLBe = false;

    for (int PdHikKAQfl = 78292837; PdHikKAQfl > 0; PdHikKAQfl--) {
        pAdXzTVQwdkJu = ! IqVHfATTUg;
        RXAfL *= MGXtShHYOgVDbM;
    }

    for (int oUGVKMuwOdVyN = 2024669379; oUGVKMuwOdVyN > 0; oUGVKMuwOdVyN--) {
        continue;
    }

    for (int EZIzbizuECP = 1618701165; EZIzbizuECP > 0; EZIzbizuECP--) {
        mwHpaTlLBe = IqVHfATTUg;
        XdhxLwB += DJbTWm;
    }

    for (int HnvfNSa = 1090208612; HnvfNSa > 0; HnvfNSa--) {
        continue;
    }

    return khgZicZ;
}

string IdSOAsUH::ymnOQKLQKzH(int mLWDtfvcGf, int wqXcISDzToOltmi, string yScBBPJT, double qPURQcQFYO)
{
    double hWUCUgq = -420483.0890164737;
    bool krbpjlzZVttK = false;
    int oYMwTqlBlDbxamGD = 2104221757;
    double DQZQWyRhJDnkYT = 773164.0501131061;
    bool IHrnKIcRuusFmBA = false;
    double mmfIIzRFgs = -940604.2558579368;
    int MRPOBGttk = -2081746686;
    bool ootdIVDxLvjl = false;
    string yrZKhQYV = string("tPNHvWphCjPDpftFDchpcceOlhIKFMbFyyfqXoCEYkUMxjyOgcOOMnifKWJHsgmaHmKcKHVEKuxCWpNljampHkmwMoFBtTgoieAoOtzNwWAdMmIktfUGTqQENRCWamomlKHoVYyYObpSFbBSqVHYhApldYViecXXfvvqfJcAuRNHBFtwqpZYajFdaACqspycqNGIGFyXqJAysmOiqokRFEYF");
    string xIUixEJtcjWtZt = string("VwawsWMYbwpGyrTpWdbDOZCYBwYxyonYwkTFkxGDyuujgbhbKVIXRTkmhaKcllaDmqqtzgFjIajNEgQRkyVcYLwbERUpczynzbGePqzzPpfVkbkNMJfDuSTZWiNFfpGpcSfbjSkTmgPPzUFEnxdxUEQKhfkHeixMmnszRsoRZoLSGJHHgIRreSvJfYINzMhVQL");

    for (int MHQICXTNpge = 1771381092; MHQICXTNpge > 0; MHQICXTNpge--) {
        xIUixEJtcjWtZt = yScBBPJT;
        mLWDtfvcGf -= wqXcISDzToOltmi;
        mmfIIzRFgs /= mmfIIzRFgs;
        xIUixEJtcjWtZt = xIUixEJtcjWtZt;
    }

    for (int NKccdxfKNJeAArX = 523229083; NKccdxfKNJeAArX > 0; NKccdxfKNJeAArX--) {
        hWUCUgq += hWUCUgq;
        wqXcISDzToOltmi -= wqXcISDzToOltmi;
    }

    return xIUixEJtcjWtZt;
}

string IdSOAsUH::zXFdkaAlrZ(string acoMJGYNQLMcbfl, double NKyuAAVwDf, bool uXVyYgeNjRkOFch)
{
    string VNXyhvWfRrCPfRz = string("XeseQNsIMFsaDKhjdTZCKDuuHVnyunyxYiPzKBsJloPmsJerpyMwkDzzlSyNxCftGXTdrjxtZcqlSQVtMfQWAV");
    string ZQLfBnIusmCkD = string("hFOYqAAVIRPzGtLeuHtqUGeGCEgfEMqRkhoVOxJxnaaFkWaKeQvfHnaytybizaLdWmgonfokUedtufVRjjeHyRSPLGkzVtBEDNuZlOZeIRkuTpKDqTopDuGMOuucZGopVFJioCcpQePmZkoQJUkvgKCHSkYWhmjhcDgPfvTccaTitXnfXFNZemcnvrj");

    return ZQLfBnIusmCkD;
}

void IdSOAsUH::PZrtklfU(bool rPrApf, double AQxtuwdGQlM)
{
    string PYdLIFbEFaHYsHd = string("DLbswwaQAEZCtkkwVdBEDhzULgWstnAJ");
    int iheljXrcRZ = -1146250613;
    int WJQPEoqFwhoJQz = 714267811;

    for (int qOSDcsssElvQUps = 1533664094; qOSDcsssElvQUps > 0; qOSDcsssElvQUps--) {
        continue;
    }

    for (int CfShJ = 1227918695; CfShJ > 0; CfShJ--) {
        WJQPEoqFwhoJQz = iheljXrcRZ;
    }

    if (PYdLIFbEFaHYsHd > string("DLbswwaQAEZCtkkwVdBEDhzULgWstnAJ")) {
        for (int FMpNIpNXwXfpGP = 1444745970; FMpNIpNXwXfpGP > 0; FMpNIpNXwXfpGP--) {
            AQxtuwdGQlM += AQxtuwdGQlM;
            iheljXrcRZ *= iheljXrcRZ;
            AQxtuwdGQlM = AQxtuwdGQlM;
        }
    }
}

bool IdSOAsUH::vQJIJdHvKlgGuept(string JSWuBcYhBXBuJ)
{
    string IOpyYvcdvyF = string("PnRLTHzspLHmghjlOXGaHgTflOgiVksszBSldkHOryiYeyqhsJAAKJwJfNyLPPKS");
    int PynWMJJOjJJYC = -787767007;
    string yvibYFsvAZgncWp = string("atKwyggWvWIZCyJkgtlJkgEcALLUWMAebrCFNcmLdLVvkwosFHDAc");

    if (yvibYFsvAZgncWp > string("atKwyggWvWIZCyJkgtlJkgEcALLUWMAebrCFNcmLdLVvkwosFHDAc")) {
        for (int oUBBhDxGpBCCN = 1327578370; oUBBhDxGpBCCN > 0; oUBBhDxGpBCCN--) {
            JSWuBcYhBXBuJ = IOpyYvcdvyF;
            PynWMJJOjJJYC /= PynWMJJOjJJYC;
            JSWuBcYhBXBuJ += yvibYFsvAZgncWp;
            yvibYFsvAZgncWp = IOpyYvcdvyF;
            JSWuBcYhBXBuJ = JSWuBcYhBXBuJ;
            JSWuBcYhBXBuJ += IOpyYvcdvyF;
        }
    }

    if (JSWuBcYhBXBuJ == string("wzwsFDOFxsgAaMzaxzYFELOUCLXNbcbjUfxkKUOxbFjIqSuUzZuXmXXhnFJEoscFKbDnNTTJLaIIaZGb")) {
        for (int BcGCMxYPhUnWqi = 1045201450; BcGCMxYPhUnWqi > 0; BcGCMxYPhUnWqi--) {
            JSWuBcYhBXBuJ += yvibYFsvAZgncWp;
            IOpyYvcdvyF += yvibYFsvAZgncWp;
        }
    }

    if (IOpyYvcdvyF < string("PnRLTHzspLHmghjlOXGaHgTflOgiVksszBSldkHOryiYeyqhsJAAKJwJfNyLPPKS")) {
        for (int HeJQKeQu = 749966984; HeJQKeQu > 0; HeJQKeQu--) {
            JSWuBcYhBXBuJ = yvibYFsvAZgncWp;
            yvibYFsvAZgncWp += JSWuBcYhBXBuJ;
            PynWMJJOjJJYC -= PynWMJJOjJJYC;
            IOpyYvcdvyF = yvibYFsvAZgncWp;
            IOpyYvcdvyF += yvibYFsvAZgncWp;
            JSWuBcYhBXBuJ = IOpyYvcdvyF;
            IOpyYvcdvyF += IOpyYvcdvyF;
        }
    }

    for (int mAOdQdNmSt = 1487715336; mAOdQdNmSt > 0; mAOdQdNmSt--) {
        yvibYFsvAZgncWp += yvibYFsvAZgncWp;
        PynWMJJOjJJYC = PynWMJJOjJJYC;
        IOpyYvcdvyF = IOpyYvcdvyF;
    }

    return false;
}

double IdSOAsUH::AMWoEwsPHvwEQBja(int QxLQRWgGKkL, int CXIRisFoEViEp, string EeGARyoAmNWhUr, int ukbBvWGuaMbMp, int JJRiVYh)
{
    double pTCuRFYAG = -155272.47032632906;
    bool LpkRonqU = true;
    int lAvieZM = -2009048878;
    bool ooftjlXnQ = true;
    string GleuY = string("vYUeKDRfXsToXLuUrlwtXhnYRshoUvBYPvtpuFGXkQqyMzKvWXHBWplbPmCEVYmHihRnpniwoffOEUZXMPjMfCXPzMAZghlWrDKurWmpriZBPTUbOCVuzhcZLeaSjJMCOLZORysGDNErrCTvwnnUCqQnJUEjqPNsjsDLycxkYuAKgTFvYUbYhNMVzDZKZzuMBxtKzf");
    bool BXDSDziPPnXoFx = false;
    int gTeToVhIgoaGkq = -1679728470;
    int sZEHojAQEFbf = -171346501;
    double mBJho = 9724.925509367295;

    for (int etHKrOtW = 1324505526; etHKrOtW > 0; etHKrOtW--) {
        continue;
    }

    return mBJho;
}

string IdSOAsUH::zeoGSUmivXxkz()
{
    bool OsQoIvUFN = false;
    int GnTFs = -444515162;
    string BSKLeUWIumvfnr = string("eWWayjuUx");
    int uajiG = 900816964;
    bool QBTENOcYIzzFTJ = false;
    int mdoWobcE = 1211426223;
    bool MAIgqFCagDZ = true;
    string pXMUueuoQq = string("EaiNtZcIsUZufzaPRCsjTCMRllFWulMFayOHmiNxLMzntSornXl");
    string ZaUmnmxFZYAs = string("ABFmsblhNCiiJeBKul");
    bool bTcgWUFCjus = false;

    if (uajiG >= 1211426223) {
        for (int YXEFIBLgYX = 731440912; YXEFIBLgYX > 0; YXEFIBLgYX--) {
            continue;
        }
    }

    return ZaUmnmxFZYAs;
}

double IdSOAsUH::ncLkGPWSrklwJvT(string RYjGiyC, int lwwMBnVSSgFN)
{
    bool WpvQOam = false;
    bool eiPko = true;
    double KAJzHuxkdpJvIqrx = 123266.24501236691;
    double bcxMNCKrHFBQ = -717751.2845019778;
    bool OoylMlerv = false;
    double dJYpiSA = 254002.9397663766;
    double kYFKXAQPLZGsjwwf = -546366.6856624833;
    double xRgbHrOATShzJrhd = -619513.1183103095;
    int WCjyWqBWeY = -1105768723;
    bool MFNDEAczMoVTBXbi = true;

    for (int vdhzTRAdu = 1940079422; vdhzTRAdu > 0; vdhzTRAdu--) {
        KAJzHuxkdpJvIqrx /= kYFKXAQPLZGsjwwf;
        xRgbHrOATShzJrhd *= kYFKXAQPLZGsjwwf;
        bcxMNCKrHFBQ += bcxMNCKrHFBQ;
    }

    for (int swBEffXm = 1634819322; swBEffXm > 0; swBEffXm--) {
        dJYpiSA += kYFKXAQPLZGsjwwf;
        KAJzHuxkdpJvIqrx *= KAJzHuxkdpJvIqrx;
        eiPko = ! MFNDEAczMoVTBXbi;
    }

    return xRgbHrOATShzJrhd;
}

void IdSOAsUH::BKwbcCjR(bool RzmyoXjFaGZevbQP)
{
    int OUiCmwEcse = -2053755438;
    double AoMUkgcKDBcgVUhC = 776227.249248779;
}

void IdSOAsUH::krxKw(string RulFcBsxKqDCeoa, int nKGMMpKyqRYup, bool ysuBZzsJTyVQ, double vjsDfypywAhinLSB, bool ylcxwMHDrJXdyZ)
{
    double SswkfvNEZcX = 87593.80585589587;
    string XxUngVl = string("slAvfnpIJPalLLecBAqcJZFjkZpRtt");

    for (int PUUJaJ = 586407663; PUUJaJ > 0; PUUJaJ--) {
        ysuBZzsJTyVQ = ysuBZzsJTyVQ;
        SswkfvNEZcX = vjsDfypywAhinLSB;
        SswkfvNEZcX = SswkfvNEZcX;
        ysuBZzsJTyVQ = ysuBZzsJTyVQ;
        ylcxwMHDrJXdyZ = ylcxwMHDrJXdyZ;
        RulFcBsxKqDCeoa += RulFcBsxKqDCeoa;
    }

    for (int XNpXYOm = 1770279989; XNpXYOm > 0; XNpXYOm--) {
        continue;
    }

    for (int nMLpVjHvSzrOFLc = 1221808646; nMLpVjHvSzrOFLc > 0; nMLpVjHvSzrOFLc--) {
        RulFcBsxKqDCeoa += XxUngVl;
    }

    for (int afXppjVuo = 1161203674; afXppjVuo > 0; afXppjVuo--) {
        XxUngVl = RulFcBsxKqDCeoa;
        nKGMMpKyqRYup = nKGMMpKyqRYup;
    }
}

void IdSOAsUH::WqdbdJGayRa(string zJJmiU, double iYYVyXtCo, double sJpagHKkhyjz, double OjblfOzYHiOdWR, bool FxikaWgQ)
{
    double hTzBcgvgJy = -739937.7776299736;
    string tCAKMDL = string("FHkaRamWCivFTNfRcehiHdvrYAoKHfUDjydGLnMUiopLVuLWfSImnphiayKDpYXvJ");
    int EVtUfCsoEQoWnBO = 1448575576;
    string vIZeUtOdFanZC = string("LYlQKmYAwnxezCspEtECyIKiEAueRvwLFTgjDgIVQSIzSUQQGQugZdxAZSFeSHIZMxpJurotuXGzsjefhcdDUhRthKdPqthAVohCargINJksSSNjPDXLQvvtluCgBqhrNqKyrLXRCxKPTecZwgXEDIis");
    string BhFSQsLL = string("WVdvXdOtvzHxsyzUxczJEcmPWwqgscdYmUnWFbMxrskVtdkmUNRSyhZbTGHXxHTvrEUqGVSLwyRgyrKaHWlclhFICWJQDpEibENiNZvXCvaxLRdyNDVdvQadSzPRlwkrsCVxrKjXdFhTAaPrppNDfhVxtuTUrxceTGaOcFvbIbJcQkqUBKxmwUZXuGiqqDeBsnHwuaQCNRFVMPZ");
    double XaBrkH = -362663.8114408022;
    string PXZdrIYiT = string("ggbrgBwYMPXaCYvZmMHvQarCrkaVBnFMdjETPNlRcvOgtcPLeumFqAXFjiHqTIjxxezPCePYrkVRMXbQVPyWkthEIlEooJUerWBAiXLpbbWiLhZYIIyhvbx");
    string hCmIcivZz = string("wnAgNwyZbiECRogsONIfHpWLVsyXCaqPoOOCUgxidbkWauvyIJNzARgPinmOmMqntVMjsCLGYTjfpasuItkIonCDZiwIJjNnfAZTDAimijiwvRLzGvaujbGlVepohHySZppJzZnPpCnIkUEHdhcSXcLSsSwFfNDvZKVAoTENjgCUKDNbmLzXNRoPLWoTrKMEZRqwHVkWQ");
    double IXIGOsSd = 910266.7535220173;
    bool EidImWVKBDP = false;

    if (vIZeUtOdFanZC > string("WVdvXdOtvzHxsyzUxczJEcmPWwqgscdYmUnWFbMxrskVtdkmUNRSyhZbTGHXxHTvrEUqGVSLwyRgyrKaHWlclhFICWJQDpEibENiNZvXCvaxLRdyNDVdvQadSzPRlwkrsCVxrKjXdFhTAaPrppNDfhVxtuTUrxceTGaOcFvbIbJcQkqUBKxmwUZXuGiqqDeBsnHwuaQCNRFVMPZ")) {
        for (int rUWYUdM = 407861311; rUWYUdM > 0; rUWYUdM--) {
            OjblfOzYHiOdWR -= iYYVyXtCo;
            hTzBcgvgJy /= IXIGOsSd;
        }
    }

    for (int DhrqWtHZ = 119178265; DhrqWtHZ > 0; DhrqWtHZ--) {
        PXZdrIYiT += vIZeUtOdFanZC;
    }

    for (int qxghZbktJXdIbL = 899270704; qxghZbktJXdIbL > 0; qxghZbktJXdIbL--) {
        tCAKMDL += tCAKMDL;
    }

    if (tCAKMDL < string("LYlQKmYAwnxezCspEtECyIKiEAueRvwLFTgjDgIVQSIzSUQQGQugZdxAZSFeSHIZMxpJurotuXGzsjefhcdDUhRthKdPqthAVohCargINJksSSNjPDXLQvvtluCgBqhrNqKyrLXRCxKPTecZwgXEDIis")) {
        for (int OSYKagAbiudS = 512329367; OSYKagAbiudS > 0; OSYKagAbiudS--) {
            vIZeUtOdFanZC += vIZeUtOdFanZC;
            FxikaWgQ = ! FxikaWgQ;
            FxikaWgQ = ! EidImWVKBDP;
            sJpagHKkhyjz += sJpagHKkhyjz;
            vIZeUtOdFanZC = BhFSQsLL;
        }
    }
}

int IdSOAsUH::ebdHOTa(int CbcCIGJ, double GYUydXx, string wIZKMRT, int QcUvfsbYrq)
{
    double DBtmDn = 856107.1313273994;
    int cIsHuKuBnK = -1773276192;
    int LJJDuMLmxLX = 24435625;

    for (int hjBTQLBRSSuP = 24772216; hjBTQLBRSSuP > 0; hjBTQLBRSSuP--) {
        cIsHuKuBnK += QcUvfsbYrq;
        CbcCIGJ -= LJJDuMLmxLX;
    }

    for (int BfLTxJkSXYm = 2014241685; BfLTxJkSXYm > 0; BfLTxJkSXYm--) {
        QcUvfsbYrq -= QcUvfsbYrq;
        cIsHuKuBnK -= QcUvfsbYrq;
    }

    if (QcUvfsbYrq <= 251279494) {
        for (int iBzbtyeNCOMyhRpe = 180466061; iBzbtyeNCOMyhRpe > 0; iBzbtyeNCOMyhRpe--) {
            LJJDuMLmxLX += cIsHuKuBnK;
            LJJDuMLmxLX -= LJJDuMLmxLX;
            cIsHuKuBnK += cIsHuKuBnK;
        }
    }

    for (int hIERG = 1950809190; hIERG > 0; hIERG--) {
        GYUydXx /= GYUydXx;
        cIsHuKuBnK /= QcUvfsbYrq;
    }

    for (int mrZnbZiRGjUpCkam = 1163809358; mrZnbZiRGjUpCkam > 0; mrZnbZiRGjUpCkam--) {
        CbcCIGJ *= cIsHuKuBnK;
        GYUydXx -= GYUydXx;
        CbcCIGJ -= cIsHuKuBnK;
        LJJDuMLmxLX -= cIsHuKuBnK;
    }

    return LJJDuMLmxLX;
}

bool IdSOAsUH::BBJPIzUAs(string PHvVJxtDzyO, double nsjriKUj, int kkDepssYhtkgVENn, string GMnKLVoSXUVOMQ)
{
    string vcCoPG = string("uuiAXUWLXtRLOvemqqDfhJTUsPWYwvXutHndrKFqnlVyJZVIXEvAYIJEzlrNIyqfAIodXGSdbckWvrxGaTiXMcKBOVvHWIcsVGtDIdlATuylUoRfnPmaJfMxxqpnlTEbRKDBufveHGZgtYnkUFLGnqpEZHXmPfamMBUkMisDvMfpCnKeaVzbtrmHFfDLdTXkzODsTwUAJxnqhHG");
    string HJbvFq = string("RgMRlNCefNizzizBqtHBVyinJUsVIpV");

    if (HJbvFq > string("RgMRlNCefNizzizBqtHBVyinJUsVIpV")) {
        for (int qPgGGhncbSdYO = 1800659886; qPgGGhncbSdYO > 0; qPgGGhncbSdYO--) {
            continue;
        }
    }

    if (HJbvFq < string("bYqeIFuMzbbzLPpItKkWGBnYHJjBEyYJjaVzCnkReOICNPSGtjShTVsszAEpdakHGukWOTpvZkIzAWOSAbvpabMGGUxZQmvDAVYpiVeftLNxtpGkcXatqiReClpFqhnnsxdHTYwNIUmqufrUNTMnHqVwtZmsKVeCljSEzKxYHOdXnrdptN")) {
        for (int QscnhkkbZdfpGnp = 1776310255; QscnhkkbZdfpGnp > 0; QscnhkkbZdfpGnp--) {
            PHvVJxtDzyO = GMnKLVoSXUVOMQ;
            HJbvFq += GMnKLVoSXUVOMQ;
            PHvVJxtDzyO = vcCoPG;
            vcCoPG += HJbvFq;
        }
    }

    if (vcCoPG != string("gWwaspOBjcQDFBvxbNnxhpviaGEFdruYCzFTePKdgHngdXOuMmoShwARDsNBPyeDdkNaVfUCtbPQWNzFujlkoIQUxziAqYdXJSIzbRVFKvNErlVOTbzgouiprZTyeDNtdtIYwIFqUlKibhbukHADcoHBHiJnurHfjXfKQJVrzAHWaRofetDfeXtUsBWRdSyMplPyXYOYkNmFsSfKwZYGVRqOulwGBWVJXBWMbAxDHRkkHvUHA")) {
        for (int sLtmyga = 1090768376; sLtmyga > 0; sLtmyga--) {
            vcCoPG = HJbvFq;
            PHvVJxtDzyO += GMnKLVoSXUVOMQ;
        }
    }

    return false;
}

double IdSOAsUH::cznIAm(bool NRIQdSCZjCgs)
{
    bool qBxHTM = false;
    bool ppoaSqkGfJyJKSf = true;
    string kPPgCEDwTwFi = string("BTdDbZlxIeQgdnwjfacVRznThfbTqxyAAamFGNFJlobuBCILZHxeJkSPfMyheIKidzbvGVrkBCjtUXUMQJBPcwQGlUJIchEkJarLZAnAOoFCFDkiNOXWefjklDIARRCy");
    double lTDCVdGWdX = 812190.505602102;
    string lIRoh = string("CPPYDLFMbsTGTIbQMCWVfZIcSUPsNxpFcelRgcqTnfJrTgVsdQNtVDZAMJbuzlSxGandCcgFxHFsbNqNSWUCHoOFlNdnzUQEZLLKzbUuXLFDJzrpJnsOKObaNydWnnDRuUcYLAalLzIHaLrCObEJKqYagqoMXDAJRTybrioWIBNcfydIWCjoTZyJiXrKeEzGBwVZ");
    int YVjLMzSQedO = -572781364;
    bool VgykxmV = false;

    return lTDCVdGWdX;
}

bool IdSOAsUH::cnEXYW()
{
    string hJwLCBXGVEn = string("eopzHPOJakKejyvyHJNjpwGYtxpNShIlaFRuofTNtPbYpLYRIVRQuvFdrwUKBycbpEzpUxXLMFNPwpNkGMyQydCHXFHVEqfNbMzxMrm");
    string QcyzQQyNXPeVt = string("mimyorpdWdkxFlSNcAcQhqtiHhecNtHCkgOXRTrkxVvhdepktJbDRPjRAwpIbvmDhWDXSGrRpyIrnrtnpEuIrNPgaEUoIhsfXmsiTxuAnf");
    bool LZPPDTnEjKp = false;

    if (hJwLCBXGVEn >= string("mimyorpdWdkxFlSNcAcQhqtiHhecNtHCkgOXRTrkxVvhdepktJbDRPjRAwpIbvmDhWDXSGrRpyIrnrtnpEuIrNPgaEUoIhsfXmsiTxuAnf")) {
        for (int MNOIQmR = 1119383139; MNOIQmR > 0; MNOIQmR--) {
            QcyzQQyNXPeVt += QcyzQQyNXPeVt;
        }
    }

    if (LZPPDTnEjKp != false) {
        for (int QQoFIuffsA = 779687349; QQoFIuffsA > 0; QQoFIuffsA--) {
            hJwLCBXGVEn = hJwLCBXGVEn;
            hJwLCBXGVEn = QcyzQQyNXPeVt;
            LZPPDTnEjKp = ! LZPPDTnEjKp;
        }
    }

    for (int ZhwdEqhKXwsKyy = 1424646813; ZhwdEqhKXwsKyy > 0; ZhwdEqhKXwsKyy--) {
        QcyzQQyNXPeVt = QcyzQQyNXPeVt;
        QcyzQQyNXPeVt += hJwLCBXGVEn;
        QcyzQQyNXPeVt = QcyzQQyNXPeVt;
    }

    for (int VaiYxEhcEZLJYMB = 838769637; VaiYxEhcEZLJYMB > 0; VaiYxEhcEZLJYMB--) {
        LZPPDTnEjKp = LZPPDTnEjKp;
        QcyzQQyNXPeVt += QcyzQQyNXPeVt;
        QcyzQQyNXPeVt += QcyzQQyNXPeVt;
    }

    if (hJwLCBXGVEn <= string("mimyorpdWdkxFlSNcAcQhqtiHhecNtHCkgOXRTrkxVvhdepktJbDRPjRAwpIbvmDhWDXSGrRpyIrnrtnpEuIrNPgaEUoIhsfXmsiTxuAnf")) {
        for (int JMUjlVEs = 857655662; JMUjlVEs > 0; JMUjlVEs--) {
            QcyzQQyNXPeVt += QcyzQQyNXPeVt;
            hJwLCBXGVEn = hJwLCBXGVEn;
            LZPPDTnEjKp = LZPPDTnEjKp;
            QcyzQQyNXPeVt += hJwLCBXGVEn;
            QcyzQQyNXPeVt += QcyzQQyNXPeVt;
            QcyzQQyNXPeVt += QcyzQQyNXPeVt;
        }
    }

    if (hJwLCBXGVEn <= string("mimyorpdWdkxFlSNcAcQhqtiHhecNtHCkgOXRTrkxVvhdepktJbDRPjRAwpIbvmDhWDXSGrRpyIrnrtnpEuIrNPgaEUoIhsfXmsiTxuAnf")) {
        for (int iqSCZezOsrt = 2025569127; iqSCZezOsrt > 0; iqSCZezOsrt--) {
            QcyzQQyNXPeVt = hJwLCBXGVEn;
            LZPPDTnEjKp = LZPPDTnEjKp;
            hJwLCBXGVEn = hJwLCBXGVEn;
            hJwLCBXGVEn = hJwLCBXGVEn;
        }
    }

    return LZPPDTnEjKp;
}

int IdSOAsUH::XvQnSXezASMBOHN()
{
    string oGTDMDfxngGIUHNC = string("LjyeaCutSvvpLq");
    bool LAbZnnlzvILpRdCc = true;
    int AJLiNaJRiqTg = -1017310032;
    int FeyMEeeuusAgP = 1768997083;
    int crmYgCg = 1480956857;
    string cJEftrmfpwIS = string("zdjhzSNIfYqZzDurJKDYrNcjpnznoqFkzPLCxprYPNhPvoTzAUwtKACnXoisiEElzyUalfqXwgghVqVBXArg");

    if (oGTDMDfxngGIUHNC != string("LjyeaCutSvvpLq")) {
        for (int cAXwjsiV = 369944201; cAXwjsiV > 0; cAXwjsiV--) {
            continue;
        }
    }

    return crmYgCg;
}

int IdSOAsUH::cqxgWFwjkAhfngCy()
{
    double ZBGlJEdg = 188730.16469939562;
    bool aHyEAWFQioaDwm = true;
    double RRJok = 526099.5434216368;
    int jstqlVmIsUzlwp = 1196071051;
    int aGUUMV = -733685242;
    double MFmXoyzMCfT = 585011.9563477566;
    string yxYFABUj = string("jtMBHclmeungWhQEhemLWYRojPhuMUeHOvoEgYAAdSuaXIPMYmDcUIJszvFuUzrmiDxglvKrKSvYxCdrZtofdAxcsJssYuWVQiTRwXSbSaltQHTgwKdvzYzErjLEPdHqFKxCZQPFflvoYevoeDRLBnTAEnNQtNCdRHaYWFxjvtWixNnfKtNgBgyAFafNDhcqUehFYzCQxlNlLVJCuuhzSPDwewWdTYnEdTSBRghOoipNcN");
    bool VjxmxMwJY = true;

    for (int gIFRWa = 558140367; gIFRWa > 0; gIFRWa--) {
        aGUUMV = jstqlVmIsUzlwp;
    }

    for (int VLmrnEFwpfopVs = 1582047380; VLmrnEFwpfopVs > 0; VLmrnEFwpfopVs--) {
        yxYFABUj = yxYFABUj;
    }

    if (jstqlVmIsUzlwp >= -733685242) {
        for (int tEPXxdYHJTgws = 104420670; tEPXxdYHJTgws > 0; tEPXxdYHJTgws--) {
            continue;
        }
    }

    for (int HmcQfwxiUJEB = 536202635; HmcQfwxiUJEB > 0; HmcQfwxiUJEB--) {
        MFmXoyzMCfT += MFmXoyzMCfT;
    }

    return aGUUMV;
}

string IdSOAsUH::iyzeiAe(double TzcUbSfKQNd)
{
    bool mvfbxsZOX = false;
    string EMxirErYrS = string("dhhWqEznKwHslWbRQRvZeoMoYibLaQSMDpmoF");
    string JBVRHnmY = string("GtHYMJYLOLazdAesDTRYURogJPxTeZTfLGhUjsirCRROrRmzAWSXADfSjGRGtgvzjYIopDNmCgcaaDJqsmRIqFhNTOKwLVLLBdUXBSmufYZQJDAnLFHgeJCRfXUrjgtJgQHPtoxGRDZaQYtORVOIqnJskGXkSIgJCUiuemoQtCQLCDEzFbXgVvvOgQGTcyLUgBbZCMTMWFsH");
    int OFYdQVsBoAes = -1826416074;
    bool wnmkwGDDjoakH = false;
    int RwaeqJ = 394655551;
    double UrYRTUwteLp = -857473.8643098504;
    int vPguLnDMf = 1218493229;

    for (int bqOVPnHvlnAWgMFI = 2015743512; bqOVPnHvlnAWgMFI > 0; bqOVPnHvlnAWgMFI--) {
        OFYdQVsBoAes += OFYdQVsBoAes;
    }

    for (int ptQNRJfkes = 1350492775; ptQNRJfkes > 0; ptQNRJfkes--) {
        continue;
    }

    if (JBVRHnmY != string("GtHYMJYLOLazdAesDTRYURogJPxTeZTfLGhUjsirCRROrRmzAWSXADfSjGRGtgvzjYIopDNmCgcaaDJqsmRIqFhNTOKwLVLLBdUXBSmufYZQJDAnLFHgeJCRfXUrjgtJgQHPtoxGRDZaQYtORVOIqnJskGXkSIgJCUiuemoQtCQLCDEzFbXgVvvOgQGTcyLUgBbZCMTMWFsH")) {
        for (int zIMgiMAvvT = 49742792; zIMgiMAvvT > 0; zIMgiMAvvT--) {
            continue;
        }
    }

    for (int JKcplTwAXtq = 2140621054; JKcplTwAXtq > 0; JKcplTwAXtq--) {
        continue;
    }

    for (int CHqWvazwvrGTx = 879222586; CHqWvazwvrGTx > 0; CHqWvazwvrGTx--) {
        EMxirErYrS = EMxirErYrS;
    }

    if (vPguLnDMf >= 394655551) {
        for (int MAKFlZH = 770650729; MAKFlZH > 0; MAKFlZH--) {
            wnmkwGDDjoakH = wnmkwGDDjoakH;
            RwaeqJ *= RwaeqJ;
            mvfbxsZOX = wnmkwGDDjoakH;
        }
    }

    for (int dxbyKptbHl = 1651986947; dxbyKptbHl > 0; dxbyKptbHl--) {
        TzcUbSfKQNd /= TzcUbSfKQNd;
        OFYdQVsBoAes *= RwaeqJ;
        EMxirErYrS = JBVRHnmY;
    }

    return JBVRHnmY;
}

double IdSOAsUH::SEWcrJXg(int IgOEZpz, string PcmXFDsMJpLUYgW, string dTlasu, double ZqYTudnipiUkE, string YXbUDzX)
{
    int kjFAKooUB = 1044085822;
    int nQJKzU = -1773183107;
    double HGfpEJSetoX = 140324.74545064243;
    bool wTNKrjrZFUWMTah = false;
    double JPbGMwLSHiYx = 151771.23697266454;
    bool ykocvuYwKLrXK = false;
    string BGOQsZGmMEKy = string("lAmxTjyKBndBWRYnvMRMZQQTEekTtMaPhZbZpVazPwibFXplHHFfdDbWdGeDJSmXtOZZtMcIfAqL");
    double dnmaenTcnvQv = -28125.58336825593;
    double ZlzVTrqqAEW = -1035647.3624112963;

    for (int gDqYitcIxZH = 1330121898; gDqYitcIxZH > 0; gDqYitcIxZH--) {
        PcmXFDsMJpLUYgW += BGOQsZGmMEKy;
        dTlasu = PcmXFDsMJpLUYgW;
    }

    for (int sbPxa = 979698058; sbPxa > 0; sbPxa--) {
        IgOEZpz += nQJKzU;
    }

    for (int fUlGUJgBkeFEQXB = 1552193893; fUlGUJgBkeFEQXB > 0; fUlGUJgBkeFEQXB--) {
        YXbUDzX = PcmXFDsMJpLUYgW;
        ZlzVTrqqAEW += HGfpEJSetoX;
    }

    return ZlzVTrqqAEW;
}

IdSOAsUH::IdSOAsUH()
{
    this->TlHrya(-232625881, string("FdQKCzIEVjrxsxpYTDteQHWSKsXjvvuVJmVbUQTkofJgUJWdKGHQnSLhttASyRsCGJOpcZgiFDNgJgsDtoHwhUDWQqTJunffesOkEkFhkZCHCpPGOsVbSvS"), -1537858461);
    this->WEcrDfWy(-474850.172771614, -991125715, true, true, string("OLDfUNCZQQAHyBADfYzlvJCqCqdezXldgdrqizvOOQgomsZQKKLDsBTnBqoXQUCXbAdeOWyXTyiAojfFfDPnSeqmGQadlNKAtFsiTTcwkLyczhiDgETvHuhzkxkhGhBKaAEuSBmJDAecDw"));
    this->ZfhDYlALg(true, false);
    this->ymnOQKLQKzH(835111189, 1744656126, string("JCOKxSXaYmbCezfPoNssInROczmOpXhDzWqHLAtKZPQbUfmbIYSZtJDCWYivqpQGgIYtblqHxfzoUXOgUyjVMnDQKRimvxdTMjIiyUmRZYRPHBOHvfepSqMVGnfZNTscDlxhrxsxnnxmQhAlweSjDGXROJGyMGVdgkuHXMqMhIGkBODLbTdGdYVqAEqgtahVcrqDnzFrJzUKJxLFHcHjSLoqoylCzyGngGNgcgcuBJJOEjDFaQPEZCLAf"), -775731.6426772751);
    this->zXFdkaAlrZ(string("VKALXdQRbVweyvecgwPscADIcpNlccnrDGSilKnJFSVcTAUXmQoibCWbDqaPCosPHQSWEXplhvchZhFGORDnxDybnmnXVSqLhwVgyVkPJQZANwprMWmlsivReIMgnMHnDJkjFpeFjeObNbkAlfWMrCIqqMHMkAHHlqKqjxzmgDqPtXAPEcFSPAnpuUwEJxN"), -457147.1981753389, false);
    this->PZrtklfU(false, 795460.4558509018);
    this->vQJIJdHvKlgGuept(string("wzwsFDOFxsgAaMzaxzYFELOUCLXNbcbjUfxkKUOxbFjIqSuUzZuXmXXhnFJEoscFKbDnNTTJLaIIaZGb"));
    this->AMWoEwsPHvwEQBja(-1073596586, 551020935, string("SVIFecPTcLyNvIHCwbyNGIjzNTYIETThxziZEGUVbGZIIiTVMlcLvGurKDEKEGMKsQfhsMfJbTmrlEuFbNDHCUTOWsJxWCXmZnEFHuVPPzBFFHOLVcPnjVkCIeRHMZDarYnsDDrZugyyePkvyPqjLMXXSnSPsOuCfYYxYgjKMmwlZ"), -170200409, -2131029498);
    this->zeoGSUmivXxkz();
    this->ncLkGPWSrklwJvT(string("OeBXTTUSfKtcAbtOsliZgkqwrubETOEKHfMKsBCgsWsNULrTIzaFPcSXGsvUUJCyngkfljohlVKgPOeowfqExeBsLkVnVAYixN"), -390918424);
    this->BKwbcCjR(false);
    this->krxKw(string("IOLxhlRTMHoviGHRYGdNYPRYQFpVteTccJCxqYSWCbuCDLUMsNZLbLhoXMzgtjVVmWCEAafjpsSIYdSWSiZVSUWcZaxJTtaFTepJPpGrUdMbuniZYkiXUtRuSCPMwkJpCtDSWUjaeQNoDLVUFcHDYuDdrbcZfZuWQDCcPFfCjlHAMhlQsToGNfCdXUSDYvAuLackyxRbliKORXoXbbDmDhkLyfrprQVvVuGClCKbhJS"), 136170927, false, -518890.3841744001, true);
    this->WqdbdJGayRa(string("bOJKPovNZkHGTgrYfUSJeHpyHBKnuNlKvgLMEYbhvoTNoFjtqlClexTfIQZjNcJxuUdqFfDsqTAXTKpikGYDecTmKOmPjKjyScKSIOyqVtKOpFGEPlzSDzLGcbJKjyVVAFimpMkxLMIlVCHiyBtOPrzrCFdFSajtKBLS"), -504533.1690316886, -301033.19814989314, -401260.42423170566, true);
    this->ebdHOTa(251279494, -921570.5410040142, string("CauYOerdHjboPmdjnEkbSBiKtYamRmREDPQQnntEgGnZoJItkNGEzlpOTPSfKaXznEWydWFsdHuYPCBtNTgGmvSnPdbFTOHLBvzyFbWQTtrROTEhjQhjPTXPrWsFHaonZmDkIAPrdyGgiCJfjKlViuQNNiz"), -675819028);
    this->BBJPIzUAs(string("bYqeIFuMzbbzLPpItKkWGBnYHJjBEyYJjaVzCnkReOICNPSGtjShTVsszAEpdakHGukWOTpvZkIzAWOSAbvpabMGGUxZQmvDAVYpiVeftLNxtpGkcXatqiReClpFqhnnsxdHTYwNIUmqufrUNTMnHqVwtZmsKVeCljSEzKxYHOdXnrdptN"), 8442.686894472516, -293162079, string("gWwaspOBjcQDFBvxbNnxhpviaGEFdruYCzFTePKdgHngdXOuMmoShwARDsNBPyeDdkNaVfUCtbPQWNzFujlkoIQUxziAqYdXJSIzbRVFKvNErlVOTbzgouiprZTyeDNtdtIYwIFqUlKibhbukHADcoHBHiJnurHfjXfKQJVrzAHWaRofetDfeXtUsBWRdSyMplPyXYOYkNmFsSfKwZYGVRqOulwGBWVJXBWMbAxDHRkkHvUHA"));
    this->cznIAm(false);
    this->cnEXYW();
    this->XvQnSXezASMBOHN();
    this->cqxgWFwjkAhfngCy();
    this->iyzeiAe(-55783.74849040356);
    this->SEWcrJXg(-723804232, string("khwaWSIwBpCuhImBkbhtzjdAlPpZYgSesHMgZbuMYpYqysRottvIZNXlzButdKmegzTrIkZGbjffztEsisxvjNqpJksuvKCsaBcqZMsRjMKFoUeHbatAPucHvDFHtgiCBYpSXtpgfrUJKhoJwNdUgmCVDdekEmqoNxFZbTwjJGppfZdLuaDBZKvBjKspzgVhyZoffoq"), string("RaeICFsQYgwBEzeIkqbfgeCpIcXbXZKaAPeDdhLBZbceVicLAvnwOaiKQMuuDDPNjYbLYGXMAfPmjVpSSbDpsQuzqitBPq"), -882084.5024138107, string("PzBFlCUExKRpCZBdkjtMuyFHbdbnoKASZZSkHtTJoclnLprPnOIWTbjMIqnplLkhnJgXUoUHNngRLSyAXpNgStkaytfbEIQLnaUnCIMXvVGebGxoNZYKSouJmVoiagPVSUoFddKgAkAbbCoTOXzfxFsDgNcmAwAoWsLDylbGQEXjxZaQVVaOZxKJFmmNMsGPklcNWHaOabGwPUGBeNymwaHaDuBYnFGSsUYhQXigkgStnJfCeptYejnYIj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NeuAmHtwavPQLy
{
public:
    int JmHIbBIdzU;

    NeuAmHtwavPQLy();
    double eRJnM(string GbacDl, int dSREDGSN);
protected:
    string bqhtCKSuL;
    double VzXPoVwo;
    int OMjZodrcclmZ;
    string QVwNlUtltQinTu;
    bool xHWXiNfFpYHpgd;

    int CSWYbAJrxsrOf(double NikGWOfE);
    bool gEnPzIMO(bool fNfojVAfjrGuycus, int zwJRChSrvpuifkWd, double UkwtrYYkfm, int mrLverIyw);
    string ClOhSu(string rDcpqIFMofHDGi, int vMTELP, double VgNWcdBEfcVAZIQ);
    double wvEPEhzqCEtW(double vBHpFCzlbJQE, int xgnAxnvcWTG, int VjgjQppWEGYVxK, string FyaABwcFV);
    string HxBIZAjRxG();
    int YDbzITYkKNlkDbHq(double SLQlyTh);
    int BXbvHHWvohfhaEuj();
private:
    bool xxVdyQUZStLyWsgu;
    int YzbaVDLsb;

    bool hXxyXxFEgVhk(bool jvUynBCMdkwmCjB, bool SmNKg, bool AznOGTqeGxFRFU, int vpyOHlz);
    void uotDAGKTEOI(bool tzxKWFPSgeZli, bool kBAYkxRwyGGXJIj, double afmKlD, int bILvYNUBKxy, double pdDyIQuUFPGI);
};

double NeuAmHtwavPQLy::eRJnM(string GbacDl, int dSREDGSN)
{
    bool JpCmdc = true;
    string vHnvHNfeCsrhg = string("oRrrOHwFgAzCLCmKoDBCBONDNuPZeIrUwRrdHDCcpQrENnYVZXMGPHspKIlvdNaujEftadrNTdmZfVOYMkVSUSEAMSixzZcmExaEJAxWTZQFZpJvPrgMXXuLcmGvaaDcINOSrdeqDkwamWHsGNfilLvHjOIXDalUqkoMsSNRGZHtbulS");
    int ZBmDBhzdmap = -408047902;
    int VlbFQNFkRxGqs = 1557996332;
    int lAoXT = -700236459;
    bool QwHWjasuqxK = false;

    for (int ZlRxS = 84499999; ZlRxS > 0; ZlRxS--) {
        continue;
    }

    for (int CmxGbiFQbkb = 797026084; CmxGbiFQbkb > 0; CmxGbiFQbkb--) {
        ZBmDBhzdmap *= ZBmDBhzdmap;
        VlbFQNFkRxGqs = VlbFQNFkRxGqs;
    }

    for (int xqDonyLBqfakG = 1751881586; xqDonyLBqfakG > 0; xqDonyLBqfakG--) {
        lAoXT += ZBmDBhzdmap;
        GbacDl = GbacDl;
        VlbFQNFkRxGqs *= VlbFQNFkRxGqs;
        dSREDGSN *= lAoXT;
        lAoXT -= dSREDGSN;
    }

    for (int iVJZVcCjIpCLIHy = 1393898266; iVJZVcCjIpCLIHy > 0; iVJZVcCjIpCLIHy--) {
        JpCmdc = ! QwHWjasuqxK;
        dSREDGSN += VlbFQNFkRxGqs;
        lAoXT = VlbFQNFkRxGqs;
    }

    if (lAoXT <= -1482171156) {
        for (int vzpJCsLafuI = 749059206; vzpJCsLafuI > 0; vzpJCsLafuI--) {
            VlbFQNFkRxGqs *= dSREDGSN;
        }
    }

    for (int poZyZowSuBew = 483144904; poZyZowSuBew > 0; poZyZowSuBew--) {
        vHnvHNfeCsrhg += GbacDl;
        lAoXT *= ZBmDBhzdmap;
    }

    return 231993.21278787425;
}

int NeuAmHtwavPQLy::CSWYbAJrxsrOf(double NikGWOfE)
{
    string hgKUhrNiK = string("UjeyIDReFSGkdvrAjTlQrKKRuaNmHBfKmpommTxvpwZQQzjSweYPYBROFFTqljCrSokTriFAHAbXWAiMjiWRwlJaENQixYEyqVVGxJIfHogkRVrKpFfEayWBrWnlwHVUgwchihuEfqPtMqMUKlshTJFDGhUteCjtTVwjA");
    string bPFyvCVqO = string("nLvkvIbdMllqPdkdWqzjbfVoReSDiWtumBLuXghhiGjFTGhdIcvlUSyBBRyNAREvuNbKmYTkrwljJTCcnfGuSKfrDUifADBEXGYmhpvvAkitdvJtetFnSZklbgRwjrfRGmh");
    bool IvRlLyntuWXHOmcy = false;
    string NeEleok = string("uoeOYCxhiJAbxFZsEMwFKNlIbcQJPPdfQBHSNBXEtzcTvcrKxTSYlZksqpaiQGrXLyKTRcsZPFcRhuFKxOqMuvowyjKbRQugGYnizQaTqFtTxUqdHHRBKYGdcbJbIVKnHdyTHthlvFplkbcjrspwEDLdtQswIwzRYnfHYBHQGcJZHhiGiYRdeKgypXIbSnbWmlkVsOQoSkUEwAwonegsZoYipTzehdebBeJrZwc");
    string PkYAVcAaaWEaGOw = string("hgniDUvnDnqwxcwJdyEXuHXrzAfSbSckekLJTfevlidHiFqVisbxgghLYxvqWlHySVPVTAIaYMSBIFIWBsVkqZuFmLdhVFpmqcDdtgQLMbyQrZcYtjBDYQNotwLSA");
    double HpHJdAcrLL = -386472.3335851889;
    int OzxoEzE = -352827182;
    string kUdUjDqefPvxvR = string("fIDTluVApZFYFUzKNTDqUONVZYYFiYGAEFypWQWxCqzjzUVWXBhBBmAolMZzORvSMloYvdFvlwCRouBVMRhXEZdkYTDzINnBSkhysxqykKaAikOBqeJvPSsiSDUZZExynaIAMhqyvvhmkvYwRBGgAqYfyxIFkyMZYuXXvuxAMmXGrugGIzQIqjgAXEagHqI");
    double vMOLTalpqlrMMZVR = 746357.9871525571;

    if (bPFyvCVqO <= string("UjeyIDReFSGkdvrAjTlQrKKRuaNmHBfKmpommTxvpwZQQzjSweYPYBROFFTqljCrSokTriFAHAbXWAiMjiWRwlJaENQixYEyqVVGxJIfHogkRVrKpFfEayWBrWnlwHVUgwchihuEfqPtMqMUKlshTJFDGhUteCjtTVwjA")) {
        for (int ioIoXDpPhjJ = 1041925024; ioIoXDpPhjJ > 0; ioIoXDpPhjJ--) {
            vMOLTalpqlrMMZVR /= HpHJdAcrLL;
            OzxoEzE = OzxoEzE;
            OzxoEzE += OzxoEzE;
            bPFyvCVqO = hgKUhrNiK;
            PkYAVcAaaWEaGOw += NeEleok;
            hgKUhrNiK = NeEleok;
            bPFyvCVqO = PkYAVcAaaWEaGOw;
        }
    }

    if (NeEleok == string("uoeOYCxhiJAbxFZsEMwFKNlIbcQJPPdfQBHSNBXEtzcTvcrKxTSYlZksqpaiQGrXLyKTRcsZPFcRhuFKxOqMuvowyjKbRQugGYnizQaTqFtTxUqdHHRBKYGdcbJbIVKnHdyTHthlvFplkbcjrspwEDLdtQswIwzRYnfHYBHQGcJZHhiGiYRdeKgypXIbSnbWmlkVsOQoSkUEwAwonegsZoYipTzehdebBeJrZwc")) {
        for (int hnKbzyxcsHpl = 1904021870; hnKbzyxcsHpl > 0; hnKbzyxcsHpl--) {
            kUdUjDqefPvxvR += NeEleok;
            NikGWOfE -= vMOLTalpqlrMMZVR;
            IvRlLyntuWXHOmcy = ! IvRlLyntuWXHOmcy;
        }
    }

    for (int vgkFmX = 1857851206; vgkFmX > 0; vgkFmX--) {
        bPFyvCVqO += hgKUhrNiK;
        bPFyvCVqO = hgKUhrNiK;
        bPFyvCVqO = kUdUjDqefPvxvR;
    }

    return OzxoEzE;
}

bool NeuAmHtwavPQLy::gEnPzIMO(bool fNfojVAfjrGuycus, int zwJRChSrvpuifkWd, double UkwtrYYkfm, int mrLverIyw)
{
    double mJPotgERps = 444786.3069986859;
    int WJdpYpU = 540295286;
    string JyjMODGlOxfGwhK = string("VKtsHnQdwSiovMNugfqrVXPOwecaViBTXYRCziuQPJVjPswhUobBbWSZqPVjfUBJyFQZlhtLkUjHAjFRzJPCvHhBtAbxtkifJPxLTxqoQAMzQpnMXKoIEPyJTWQHrTVOeJXRQLHfAlkrBfCYJWnyksButJHnEybrdYgEXKcBJNLSBXGfGdHoBsWcbzhaVJbXtfhQDwlYyqcGccORLaFEicbOFkbJodGnGKAkeFzMdrkWWdNQDl");
    string KMlQtSrSe = string("SIMzOiNJqgaCkqQplGbUgzlyyHxFaqFlhUuCaMfrLEWycnVctbsEhKoNCwbEtHPhtFPRUdZTvrpYseHNcHWdbmiooDHHfjxYVixUJWuesijnMuscGNXRtwRVyBaUNdHYGOQLlpTFioPpMyQEqaUbWWTBVmGFHwfD");
    bool slJKUst = true;
    bool umCxLoitLODDfOet = true;
    double iKrqohQG = 616870.4451585361;
    bool kYLEc = true;
    int FggWVweufweCOB = 1445073112;
    double pfRKosxclpGR = -652556.0558669879;

    return kYLEc;
}

string NeuAmHtwavPQLy::ClOhSu(string rDcpqIFMofHDGi, int vMTELP, double VgNWcdBEfcVAZIQ)
{
    int GEEDbeCEnKLdtVN = 458294317;
    double QwNiNWtUWpdN = 431872.7721254293;
    bool qrpzLfkPU = true;
    int CSjMVKkWMkOkpI = -1103467728;
    string jmEug = string("sVGwWOgShfyQyKFMweLMaEzNTraIpvZPqYbRmFOfMYenelOvgMIznXyygiKwxSkoHqXIuOZQpaWQznHLGcgclhZsItanzAFzbnARVNDaiaPjJVMbpuTAwnSqPAwJTpGLbWNQQAvjiIhLhYhmKSPjHDKTXUkydAuxnIVdHDXwOcdhVTBeHdAAyrqHZvXkuLimcQNtUdYRuNrjhyCerSifLJnWflT");
    bool rbDpunKWkdS = true;
    bool fNslpQ = true;

    for (int zZWxIMyG = 568243838; zZWxIMyG > 0; zZWxIMyG--) {
        CSjMVKkWMkOkpI *= vMTELP;
    }

    for (int QsKTSOHTx = 1950654801; QsKTSOHTx > 0; QsKTSOHTx--) {
        rbDpunKWkdS = fNslpQ;
        fNslpQ = qrpzLfkPU;
    }

    for (int pWIgDvKTZYuEjg = 1444260234; pWIgDvKTZYuEjg > 0; pWIgDvKTZYuEjg--) {
        rbDpunKWkdS = fNslpQ;
        vMTELP = vMTELP;
    }

    if (vMTELP == 1208361819) {
        for (int gCbdvUEEI = 1483533590; gCbdvUEEI > 0; gCbdvUEEI--) {
            continue;
        }
    }

    return jmEug;
}

double NeuAmHtwavPQLy::wvEPEhzqCEtW(double vBHpFCzlbJQE, int xgnAxnvcWTG, int VjgjQppWEGYVxK, string FyaABwcFV)
{
    double FwLVNTnU = -1014520.2817800876;
    bool GuOkRVZY = true;
    double aWyVVzk = 441021.1588979186;
    double NAXqVwamPzXcBECc = 130124.96413295163;
    int bwtbxxbFUhhuYT = -779168794;
    bool itvZsTCs = true;

    for (int fqrlYeN = 1311894406; fqrlYeN > 0; fqrlYeN--) {
        xgnAxnvcWTG -= VjgjQppWEGYVxK;
    }

    for (int TeUKTXtMZGl = 1170107477; TeUKTXtMZGl > 0; TeUKTXtMZGl--) {
        vBHpFCzlbJQE -= NAXqVwamPzXcBECc;
        xgnAxnvcWTG = VjgjQppWEGYVxK;
        VjgjQppWEGYVxK = xgnAxnvcWTG;
    }

    return NAXqVwamPzXcBECc;
}

string NeuAmHtwavPQLy::HxBIZAjRxG()
{
    int jqlJlYXt = 305759230;
    string TwGLVOv = string("wqoAlfTAlhbodjDEcFudbaQYmOJvvUMTuPXsKKeGVtdNXEKedVvwKBzcHcTXcpnVYGKOyppOYHVRTncToJcvnstQaFhApYbGBVsAIsdYFXubXPZdgYDzqAgwMjbEnSrhAbbiFKOkLvsSIvCroGSGIadPoYjtGaqQOFrbTdpxuNsqTMbcAjfccThR");
    double pASwGOXUjnoK = -722953.7867206946;

    for (int NaLFLF = 1301358047; NaLFLF > 0; NaLFLF--) {
        TwGLVOv += TwGLVOv;
        pASwGOXUjnoK += pASwGOXUjnoK;
        TwGLVOv += TwGLVOv;
    }

    return TwGLVOv;
}

int NeuAmHtwavPQLy::YDbzITYkKNlkDbHq(double SLQlyTh)
{
    bool ETBCHWyCRbho = true;
    double CpSyLDeLWWVeL = 667018.6239128696;
    int EZoOecUYYHCgh = -347876753;
    bool rqqvp = false;
    string WgXaHeKxn = string("mczFWKPOXYuZfVAbbShMIiTQwCwJXVnPanJoGvrpVQHKKinplgzPrRMmzGzJMCKrbltbTqdyAPxgkvRtzIPuMluDHmtBdaCerCHUjHMNEIMTGPvbMtapqVgMHYaMAEvhdyFNJgDknNdjPpXOlgBdmUqNopihURRhnSXDnbvEgBGKSbChFykgwLytpxutxrAJeEkYmvpmJnfvricHuMZgOQacYZYKxAktuADjRYwDFSoGZTZereXnItqaRnO");
    bool wEslMCnTefxWyM = true;
    string XlHtCBM = string("FDjNlaxEEUE");
    int MmLrhWsUu = -410887075;

    for (int YhItrsSHQy = 2037483589; YhItrsSHQy > 0; YhItrsSHQy--) {
        EZoOecUYYHCgh /= MmLrhWsUu;
        XlHtCBM = XlHtCBM;
        rqqvp = ETBCHWyCRbho;
    }

    return MmLrhWsUu;
}

int NeuAmHtwavPQLy::BXbvHHWvohfhaEuj()
{
    bool ZZnGStn = true;
    int xJsellBeMqaCWiv = 397423866;
    string nZTEXm = string("HkLzgpJtRaMkdwPUKYTGOiogXfoNUvNzwWRtEaCTkplFisjWbqiHqdxvMcXAMZacXRGDtitIhxshUmRToYHLpcuqn");
    int qmQmANJhARryPDxZ = -1632951224;

    if (nZTEXm >= string("HkLzgpJtRaMkdwPUKYTGOiogXfoNUvNzwWRtEaCTkplFisjWbqiHqdxvMcXAMZacXRGDtitIhxshUmRToYHLpcuqn")) {
        for (int RPbBlDjHAbrRAPLc = 873845092; RPbBlDjHAbrRAPLc > 0; RPbBlDjHAbrRAPLc--) {
            qmQmANJhARryPDxZ = xJsellBeMqaCWiv;
            xJsellBeMqaCWiv -= qmQmANJhARryPDxZ;
        }
    }

    return qmQmANJhARryPDxZ;
}

bool NeuAmHtwavPQLy::hXxyXxFEgVhk(bool jvUynBCMdkwmCjB, bool SmNKg, bool AznOGTqeGxFRFU, int vpyOHlz)
{
    string nhnOELG = string("dqduFpsnNgAKrrkzeiaOVQWRTutzzIyDzPKXbbDXDHnaoQjICUwZxLYbHqgaLUTdzgtCIduTgqFqhaLCocqHfFlRYsoyuwPpDhnFBwBzjOthtjZAF");
    bool duXFQVafM = false;
    string CWZulBJbDDLhtqq = string("wjrODiRRKmVHroaOvBiBjlnVmLmstrNLZiKwEBODqwSwAEGWWuUvFOChVOFBmVQiInkZIAumVdqJjiQQHAWVKKjuMSuxarGvucmpcZTjxenbJSxcJUKxrkOQKqBtkHbdeorilmkVVtaLIORtUAhGmcGXXRPGCYDfrBHwuGDZjctxcSxYxIazSXRUDPqYDkVevYZWLEPzmWEgqbbTmioncxn");
    int EPfHdKFsZoEkpES = -850802656;
    string QzbCCBZPToU = string("pGvEzCIMoOHLGNyavevMdtalXTLPHNUdKJOFCtepByfpWVeHTavyrQLlLWKxYfFowMOQnxe");
    double CmDCnKSSGg = -267316.8339879992;

    for (int JssJEDHyscbxduDw = 1232956189; JssJEDHyscbxduDw > 0; JssJEDHyscbxduDw--) {
        AznOGTqeGxFRFU = ! duXFQVafM;
        SmNKg = duXFQVafM;
    }

    return duXFQVafM;
}

void NeuAmHtwavPQLy::uotDAGKTEOI(bool tzxKWFPSgeZli, bool kBAYkxRwyGGXJIj, double afmKlD, int bILvYNUBKxy, double pdDyIQuUFPGI)
{
    bool WGVpLpVofrznEvHw = false;
    double bZSXdWXXcNxT = -443521.86772987794;
    double HYKGrsoehZe = 536063.8818507202;
    string MAmfjFDcQ = string("nyAWqNTCQFEksJnXAOKftBcuYNuaoUViqXbxDveFwx");
    int YmEYHBkxOH = -1851579960;
    bool YevxHgcIU = false;
    bool XqkyginWnVcUpkK = true;
    int fmLvMgy = 608969249;
    string EoLzwHkA = string("tZHYOfdzQXXLeIdrYeaLlJxscsdxizaWsJJLRnTNMEZuAWyezMLjVBszUMyIlGPVxqJjZtYWVrhowLafKzSvzVTPAI");
}

NeuAmHtwavPQLy::NeuAmHtwavPQLy()
{
    this->eRJnM(string("DxGIxBBMoVKIEnqHnhEGgYoyvitovJYDzumCAUaBIlKbdThLZxghVgIXS"), -1482171156);
    this->CSWYbAJrxsrOf(-715950.2967232291);
    this->gEnPzIMO(false, 7889190, -864032.4801665959, -1207237656);
    this->ClOhSu(string("AuCWiXgLsYbYJscijfsIOuXjEeMZVwAWjFaZzBqkVbEieeQsackzfxWCILnLeJMKXMbtiufRmFxmnTcmlYRXDaWJfkNohnlHWcvHMuahBQIZJfCk"), 1208361819, -973273.0290044284);
    this->wvEPEhzqCEtW(-6085.14201994979, -1776310852, 600417214, string("UbxoMOVVmHbIsFeedUAnsvWpZgNVkrTBnaFrrvBgVfmUmaRanMoafLGyASzrekijQrvsNhVKDMXMGKxFHV"));
    this->HxBIZAjRxG();
    this->YDbzITYkKNlkDbHq(-56985.64233227548);
    this->BXbvHHWvohfhaEuj();
    this->hXxyXxFEgVhk(false, true, false, 1342994886);
    this->uotDAGKTEOI(true, true, -5598.6717842114485, 1001405570, 714010.6726779672);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dkLhrjP
{
public:
    string zFajq;
    string RmdyRZTb;
    string UEcoEADZqNlbkdI;

    dkLhrjP();
    bool nBkVDsCbVMIHrv(bool HUDGbNpqNbBFdh, bool vcOFAtCGnHry, string tUPabJXWgM, string cnItbk);
    void yDFOR(string dFelFb, string QkttlZHYiCZVG);
    int XbFYJSOjCEt(bool ezceIp, string hYKFmwsiWfZ, string CmDDfBWl, bool jGdWUpHKWFHmG);
    double UyCDuQzYsuqWRr(string fanfGH, bool YavrmIfYmyuD, bool COeLKuwZIYzLBU, string CZQMgUAaKjP);
    double XcWlYfbdw(double IGusLrENcds, int hUBpzLlptaOmny, int zqzsVz);
    void EPATlmlZm(string cZwZXlxBxtY, int tcTUXZpYEMSmt);
    void gvgNHvgQFX(bool pKqSXsfFrZTMWqJy, double GljvtSWMSAa, double kphdOphGtAdheruU, bool gCpWtlbKAKTWhsZ, string CcwhLObr);
    double mjHukdnUcc(double wczapSo, double bdLKLEaG, string DBMBSeIixhF, int JstDwLwkExW);
protected:
    double sigtLixRnticqFp;
    bool GaznaRK;
    bool iUoDYpsyQPbjveBy;
    double yEJwBBZm;
    int iFpissaKszGE;

    void fvqqhmbsu();
    void hgjdIiOAPrNh();
    bool tqbADPMmQ(int JumFvKdTkJFTkSdr);
private:
    double cyDuqQSZpvlQUZ;
    double XbZekVHApa;
    double esyLmbjtnPar;

    double odyWNIkNgmkyvObR(bool uEUPmN, string nbDGfkYNVcWfTz, double ONAoxPzwWennf);
    string irkYOa(int faLThtDx, double JXyOuyt, bool vWfmL, double HasfXJvpEPoVnv, int vqPrnIeEBoL);
    bool HzRDAU(int idpSeRNZqTX, bool nDdstkivnTSrI, string IuqvBVEA);
    int CugiOt(int njhGp, bool xFICihfnvY, bool EMkjHhYhB, int xbjTynnPiK);
    string XbAOuccGnP(int TMDZOaYpJIH, double NMkarTwiYEzWh, string YOilvoPWOWxRd);
    string XCHUnft(int xstwdc, double JWDkdmyP);
};

bool dkLhrjP::nBkVDsCbVMIHrv(bool HUDGbNpqNbBFdh, bool vcOFAtCGnHry, string tUPabJXWgM, string cnItbk)
{
    int IJOvyw = 1683223104;
    bool DLiwtHTDq = true;
    int zbMYeSwQgZbm = 2026902939;
    bool cyjkxRHPGZJ = false;

    if (DLiwtHTDq == true) {
        for (int iKKMGn = 168186729; iKKMGn > 0; iKKMGn--) {
            tUPabJXWgM = tUPabJXWgM;
            zbMYeSwQgZbm *= IJOvyw;
            HUDGbNpqNbBFdh = ! vcOFAtCGnHry;
        }
    }

    for (int oPTxrjoopJsHSzU = 680735079; oPTxrjoopJsHSzU > 0; oPTxrjoopJsHSzU--) {
        cnItbk = cnItbk;
    }

    if (cyjkxRHPGZJ != false) {
        for (int yZReNkaThFW = 20221434; yZReNkaThFW > 0; yZReNkaThFW--) {
            cnItbk += tUPabJXWgM;
            IJOvyw *= IJOvyw;
            DLiwtHTDq = ! DLiwtHTDq;
        }
    }

    for (int EEYRdUJfWkEYrH = 1965067834; EEYRdUJfWkEYrH > 0; EEYRdUJfWkEYrH--) {
        continue;
    }

    for (int CEBTsgubBab = 1507575639; CEBTsgubBab > 0; CEBTsgubBab--) {
        vcOFAtCGnHry = DLiwtHTDq;
        HUDGbNpqNbBFdh = ! HUDGbNpqNbBFdh;
    }

    return cyjkxRHPGZJ;
}

void dkLhrjP::yDFOR(string dFelFb, string QkttlZHYiCZVG)
{
    int kDtDLYorJgVpGZ = -1094081393;
    int giLgrhomY = 1865265336;
    double tXmitphfiCiBa = 73854.10510823164;
    string EaBtI = string("fLCFPPCkXeQufAivLwDKgljeGtdZhSfbbjtXHdaFvORbfOQUdRDFUUauvlmgUUTFmvWCzfJiDdyhpkmlZqNlHNhwinvGzONKPLWTRNOIDoxQoqCOrmQoLNwSObVDCzzAVQKlDNrNatLfXAgVIBeOyvsFlqwABVWwmIkYiHppolYKxLKFIVYUwkRmOTPrAEpGCDGIyTyvsOIFuRAzTxJYBOteIKrcHiVdFHICpzLbKfSHmyGvARNcFTxOtj");

    for (int ERpBnCWInmaAxmhD = 289983978; ERpBnCWInmaAxmhD > 0; ERpBnCWInmaAxmhD--) {
        tXmitphfiCiBa = tXmitphfiCiBa;
        EaBtI = dFelFb;
        kDtDLYorJgVpGZ += giLgrhomY;
        tXmitphfiCiBa = tXmitphfiCiBa;
        dFelFb = QkttlZHYiCZVG;
        EaBtI = QkttlZHYiCZVG;
    }
}

int dkLhrjP::XbFYJSOjCEt(bool ezceIp, string hYKFmwsiWfZ, string CmDDfBWl, bool jGdWUpHKWFHmG)
{
    string sxuqaBaLfxcTwyV = string("MnlOrcxCnebiAeOjIjjAttgnqlNsCwktZgDhbjvyDGMfDzySvuxCNxsJTeIdSKDfyjCUqFePJCFctGfKEhqWSbQiexZCjXBKnYgPhhtwxlVaQYSEoJTfyWVqNOqvDBWPnWFkjpaJCrXSQBIDCfLzrviXbTfjWNCTormiPlaBzdeGFTfEqXHYOViDmkkmFpEsvevHcjmsSrNIBHk");
    string TFGgHK = string("Zh");

    return -1676339924;
}

double dkLhrjP::UyCDuQzYsuqWRr(string fanfGH, bool YavrmIfYmyuD, bool COeLKuwZIYzLBU, string CZQMgUAaKjP)
{
    int FMhUZqymnJ = 1122244631;
    int XMZEGwOXXiKn = -293337601;
    double DorgupIx = 1027851.8676412305;

    if (COeLKuwZIYzLBU != true) {
        for (int PnhGsZHtRshe = 1918758879; PnhGsZHtRshe > 0; PnhGsZHtRshe--) {
            FMhUZqymnJ -= XMZEGwOXXiKn;
            COeLKuwZIYzLBU = COeLKuwZIYzLBU;
            YavrmIfYmyuD = COeLKuwZIYzLBU;
            COeLKuwZIYzLBU = ! YavrmIfYmyuD;
        }
    }

    for (int xLgmQHOdwKOhqFN = 670391416; xLgmQHOdwKOhqFN > 0; xLgmQHOdwKOhqFN--) {
        fanfGH += CZQMgUAaKjP;
    }

    for (int MVjlhjRyesDn = 2131017237; MVjlhjRyesDn > 0; MVjlhjRyesDn--) {
        CZQMgUAaKjP += fanfGH;
    }

    return DorgupIx;
}

double dkLhrjP::XcWlYfbdw(double IGusLrENcds, int hUBpzLlptaOmny, int zqzsVz)
{
    bool SNSjw = true;
    string Sycrp = string("DArtuqHpukTojXKOKUQEefchURdUSfRULZIqKeqckcWSMeNljEJFpHYpHHSKzKydkXdVahExTyiSaAZvuXFQZBampmIDtuZbAIxPFqRtcoSLQbRmOETEtSafIeSvJUyPtLtEELdsFKPNoezlaWEVqJBORZfkuCRRlqRSlBAoLaPFwleYcTwMlrAsvKyGZbJMcOCcAtJzRBmqBjUAerXSvAMnkjsnUBqVAHgUGhnHFMkBBGmorBZtNYxArpls");
    int AukaZzpYrQj = -1725982122;
    int XoFPXWfvHhaQQF = 1161521378;
    int ZwwhpsR = 1412791211;
    string spYawnE = string("edYiGPlGFXeOieGrxiuVihpAStfrmSPgvcAkLjyNUlwovStEoedtOntPRRwQpMiZEilQivoyrAQDGiAOecLUUNXwTjYlzBersVr");
    double yrRbEAQdzwPphh = 913736.566313573;
    int BINUdnRIfvcbMrF = 539492453;
    bool bjNNXWoNjVY = false;
    string hDcWSlJEdEmhHW = string("iDXygLFCACpxPTfKUZisD");

    if (XoFPXWfvHhaQQF > -1725982122) {
        for (int ZFPuRhzd = 316401201; ZFPuRhzd > 0; ZFPuRhzd--) {
            continue;
        }
    }

    for (int sQdrtYL = 1701491099; sQdrtYL > 0; sQdrtYL--) {
        zqzsVz -= AukaZzpYrQj;
        BINUdnRIfvcbMrF /= AukaZzpYrQj;
    }

    return yrRbEAQdzwPphh;
}

void dkLhrjP::EPATlmlZm(string cZwZXlxBxtY, int tcTUXZpYEMSmt)
{
    double OAWiUC = 359269.570521918;
    int sCWRNRYArm = 988622813;
    double qwuOtuaCKHvTZ = -475294.9321091574;

    for (int ahhGlSB = 75679002; ahhGlSB > 0; ahhGlSB--) {
        qwuOtuaCKHvTZ *= qwuOtuaCKHvTZ;
        OAWiUC *= OAWiUC;
    }

    if (OAWiUC < 359269.570521918) {
        for (int WnGLHqztbvHpJ = 438167785; WnGLHqztbvHpJ > 0; WnGLHqztbvHpJ--) {
            sCWRNRYArm -= tcTUXZpYEMSmt;
            sCWRNRYArm = tcTUXZpYEMSmt;
            qwuOtuaCKHvTZ += qwuOtuaCKHvTZ;
        }
    }

    for (int CdCHKE = 1075380914; CdCHKE > 0; CdCHKE--) {
        sCWRNRYArm /= sCWRNRYArm;
        cZwZXlxBxtY = cZwZXlxBxtY;
        tcTUXZpYEMSmt -= sCWRNRYArm;
        cZwZXlxBxtY = cZwZXlxBxtY;
        OAWiUC /= qwuOtuaCKHvTZ;
    }

    if (qwuOtuaCKHvTZ >= -475294.9321091574) {
        for (int HyBPzXaoTkfd = 738978627; HyBPzXaoTkfd > 0; HyBPzXaoTkfd--) {
            OAWiUC /= OAWiUC;
            cZwZXlxBxtY += cZwZXlxBxtY;
        }
    }

    for (int isZNnyPXNagG = 1345926731; isZNnyPXNagG > 0; isZNnyPXNagG--) {
        tcTUXZpYEMSmt /= sCWRNRYArm;
        OAWiUC = qwuOtuaCKHvTZ;
    }

    if (qwuOtuaCKHvTZ == -475294.9321091574) {
        for (int FvOfxS = 2047191282; FvOfxS > 0; FvOfxS--) {
            tcTUXZpYEMSmt /= sCWRNRYArm;
        }
    }

    if (sCWRNRYArm >= 1457721453) {
        for (int RQCtyuHPPpMQS = 1650660751; RQCtyuHPPpMQS > 0; RQCtyuHPPpMQS--) {
            continue;
        }
    }

    if (tcTUXZpYEMSmt == 988622813) {
        for (int TnPHfmBqAyEIg = 697865680; TnPHfmBqAyEIg > 0; TnPHfmBqAyEIg--) {
            OAWiUC += qwuOtuaCKHvTZ;
            tcTUXZpYEMSmt += tcTUXZpYEMSmt;
            OAWiUC += OAWiUC;
            sCWRNRYArm -= sCWRNRYArm;
        }
    }
}

void dkLhrjP::gvgNHvgQFX(bool pKqSXsfFrZTMWqJy, double GljvtSWMSAa, double kphdOphGtAdheruU, bool gCpWtlbKAKTWhsZ, string CcwhLObr)
{
    bool BDAebUvwirGfEh = false;

    for (int lRyKYSrKnNZURw = 711480720; lRyKYSrKnNZURw > 0; lRyKYSrKnNZURw--) {
        kphdOphGtAdheruU = GljvtSWMSAa;
        GljvtSWMSAa = kphdOphGtAdheruU;
    }
}

double dkLhrjP::mjHukdnUcc(double wczapSo, double bdLKLEaG, string DBMBSeIixhF, int JstDwLwkExW)
{
    bool lnEno = false;
    int wahEcWvdQc = 509409987;

    for (int HeikpPQJDGuNk = 1887476314; HeikpPQJDGuNk > 0; HeikpPQJDGuNk--) {
        continue;
    }

    for (int zsGmHWFBfz = 1856573282; zsGmHWFBfz > 0; zsGmHWFBfz--) {
        lnEno = lnEno;
        wczapSo += wczapSo;
        lnEno = lnEno;
    }

    for (int GldPS = 1053159956; GldPS > 0; GldPS--) {
        wczapSo += bdLKLEaG;
    }

    for (int YsmEXhyoFZvooXbQ = 902830409; YsmEXhyoFZvooXbQ > 0; YsmEXhyoFZvooXbQ--) {
        continue;
    }

    return bdLKLEaG;
}

void dkLhrjP::fvqqhmbsu()
{
    string tEQbwIFhQuF = string("IrUHNJI");
    double gwQWM = 94166.83999991762;
    bool QmuGKYHxAjpTu = true;
    bool EkUdbfwZsZkNioA = true;
    double lIHhNRLhIGBNH = 331568.5523194637;
    int EZXuLemTkv = 205015342;

    for (int szNEqVT = 1684010485; szNEqVT > 0; szNEqVT--) {
        continue;
    }

    for (int LwXeDT = 1627806594; LwXeDT > 0; LwXeDT--) {
        gwQWM *= gwQWM;
        tEQbwIFhQuF += tEQbwIFhQuF;
        EkUdbfwZsZkNioA = ! QmuGKYHxAjpTu;
        EZXuLemTkv -= EZXuLemTkv;
    }

    for (int MgjqlQEggdBRD = 1464691431; MgjqlQEggdBRD > 0; MgjqlQEggdBRD--) {
        continue;
    }
}

void dkLhrjP::hgjdIiOAPrNh()
{
    int ZGTxsej = 2100597990;
    double SQnSfmXIQPR = 358517.464785122;
    int mZqgbEAwPHSaqOg = -872932249;
    string qwccbyK = string("YfjCfVjBXGmSDYHhHhuKBKFTrACDWUUoxPcapnOFPmvshcVyQiQSewNwGbELCKUTXFoBPKlyYNPbNJAWDrjtjZJupkKZrhyUmsSnOFJCEFyCcvpIuDPzcrbBDlooHCtvbXYwtABkcRisBPRoPJwpjIzKtwvhkPJWyLAWCIyeEKcbdTzmphLoODMhLRlSUJl");
    string gIZut = string("PqFdPHnzvTqRbIZjpvIJnXBOBcYVSKKBsFxSyepDOjOFweUDzZmVeinufOakhqTaFqSrKwVHdtBkAYliKUsHLfGmNbvjhwvFaSbNwwJP");
    double EBFjw = 969819.4082585981;
    int EwFGJmgwoqfE = -367471769;
    bool MPlSxmXX = false;
    int MdexJLk = 1472338435;
    bool KGNAxjqiuUyPBj = true;

    for (int jzOZNoudVJaIIdQk = 147748540; jzOZNoudVJaIIdQk > 0; jzOZNoudVJaIIdQk--) {
        ZGTxsej += ZGTxsej;
    }

    for (int YDrQX = 2024406418; YDrQX > 0; YDrQX--) {
        continue;
    }

    for (int dNUHix = 507823874; dNUHix > 0; dNUHix--) {
        continue;
    }

    for (int hNnqappNuyMTI = 64036219; hNnqappNuyMTI > 0; hNnqappNuyMTI--) {
        gIZut = qwccbyK;
    }
}

bool dkLhrjP::tqbADPMmQ(int JumFvKdTkJFTkSdr)
{
    double nGzEY = 584434.1511151857;
    double PaHTANgr = -1038488.9017258757;
    double hMXjmTxpiz = 416816.2111509294;
    bool OmaYpf = true;
    bool sAXmsarnHtEg = true;

    if (PaHTANgr <= -1038488.9017258757) {
        for (int nNDZSf = 895240157; nNDZSf > 0; nNDZSf--) {
            nGzEY = hMXjmTxpiz;
            OmaYpf = sAXmsarnHtEg;
            sAXmsarnHtEg = ! sAXmsarnHtEg;
        }
    }

    return sAXmsarnHtEg;
}

double dkLhrjP::odyWNIkNgmkyvObR(bool uEUPmN, string nbDGfkYNVcWfTz, double ONAoxPzwWennf)
{
    int aXgnTNtg = 2086860993;
    bool IsEzjenMC = false;
    double ZFuKHduoFl = -37808.22197318217;
    int zeNrWfytLHRrn = 637262617;
    bool AUpnllIODstoQSwF = false;
    bool bMbnRXzIZDuj = false;
    double AJmjdHLIwFeaHp = -890569.8706943379;
    int kJosYMikmqk = 916752308;

    if (uEUPmN == false) {
        for (int PpXUFTicfR = 559233573; PpXUFTicfR > 0; PpXUFTicfR--) {
            continue;
        }
    }

    for (int xKeRhcjOBdTjg = 1115771297; xKeRhcjOBdTjg > 0; xKeRhcjOBdTjg--) {
        continue;
    }

    for (int XnONniMBcw = 706942566; XnONniMBcw > 0; XnONniMBcw--) {
        AUpnllIODstoQSwF = ! bMbnRXzIZDuj;
    }

    if (IsEzjenMC != false) {
        for (int ltyPODdpGbogntwq = 1147102891; ltyPODdpGbogntwq > 0; ltyPODdpGbogntwq--) {
            bMbnRXzIZDuj = ! uEUPmN;
        }
    }

    if (IsEzjenMC == false) {
        for (int povHB = 1338390131; povHB > 0; povHB--) {
            aXgnTNtg -= zeNrWfytLHRrn;
        }
    }

    if (aXgnTNtg > 916752308) {
        for (int jiKWFcwDHnEBAe = 1170653589; jiKWFcwDHnEBAe > 0; jiKWFcwDHnEBAe--) {
            uEUPmN = bMbnRXzIZDuj;
        }
    }

    return AJmjdHLIwFeaHp;
}

string dkLhrjP::irkYOa(int faLThtDx, double JXyOuyt, bool vWfmL, double HasfXJvpEPoVnv, int vqPrnIeEBoL)
{
    string LlzJBJvpNV = string("oFTpUZSqWoGcmzwqQYbYNZuGnQtCzAqEz");
    int MDDnkJQfcy = 1430438005;
    string aZkvPzhurpjVlhB = string("YaDteFtiorJckxDJXJGfYuBFnvMoDdatWNzKBrcQbIzXLYIuTajSLvLGCUxCePpGGKUAlGOiwnCfHCGVyIdUbepAe");
    int VGKcQFoNghoAw = 1553199611;
    bool nKyAAbhGsUtUuYIf = false;
    double mTjXdoulKt = -179661.74824822939;

    for (int RoGGZyrBvNEDpzcZ = 1063066643; RoGGZyrBvNEDpzcZ > 0; RoGGZyrBvNEDpzcZ--) {
        VGKcQFoNghoAw -= faLThtDx;
    }

    if (LlzJBJvpNV >= string("YaDteFtiorJckxDJXJGfYuBFnvMoDdatWNzKBrcQbIzXLYIuTajSLvLGCUxCePpGGKUAlGOiwnCfHCGVyIdUbepAe")) {
        for (int UySpslilFdtG = 505696833; UySpslilFdtG > 0; UySpslilFdtG--) {
            faLThtDx /= faLThtDx;
        }
    }

    for (int sWcfyPgMRgGUItNK = 1323053619; sWcfyPgMRgGUItNK > 0; sWcfyPgMRgGUItNK--) {
        continue;
    }

    if (nKyAAbhGsUtUuYIf == false) {
        for (int WIfxEilyHkY = 89281619; WIfxEilyHkY > 0; WIfxEilyHkY--) {
            faLThtDx /= vqPrnIeEBoL;
        }
    }

    for (int YmvGP = 1125057505; YmvGP > 0; YmvGP--) {
        vqPrnIeEBoL = faLThtDx;
        HasfXJvpEPoVnv += mTjXdoulKt;
        nKyAAbhGsUtUuYIf = nKyAAbhGsUtUuYIf;
    }

    for (int nfHhxpcv = 1837501391; nfHhxpcv > 0; nfHhxpcv--) {
        faLThtDx = vqPrnIeEBoL;
        HasfXJvpEPoVnv -= mTjXdoulKt;
    }

    return aZkvPzhurpjVlhB;
}

bool dkLhrjP::HzRDAU(int idpSeRNZqTX, bool nDdstkivnTSrI, string IuqvBVEA)
{
    double TZZsizt = 151131.03827285935;
    int PTKSsfbdJd = 21772231;
    double QbhKBFm = -887555.6834879848;

    for (int CyNhftSdbxP = 312761174; CyNhftSdbxP > 0; CyNhftSdbxP--) {
        PTKSsfbdJd = PTKSsfbdJd;
        idpSeRNZqTX += idpSeRNZqTX;
        PTKSsfbdJd += idpSeRNZqTX;
    }

    if (idpSeRNZqTX == 21772231) {
        for (int nuxUS = 1083947546; nuxUS > 0; nuxUS--) {
            QbhKBFm = TZZsizt;
            QbhKBFm *= QbhKBFm;
            idpSeRNZqTX += idpSeRNZqTX;
        }
    }

    for (int qlHLycFo = 214402910; qlHLycFo > 0; qlHLycFo--) {
        continue;
    }

    for (int iNByktoRokvMMabo = 571602665; iNByktoRokvMMabo > 0; iNByktoRokvMMabo--) {
        TZZsizt *= QbhKBFm;
        idpSeRNZqTX /= idpSeRNZqTX;
        PTKSsfbdJd *= idpSeRNZqTX;
        PTKSsfbdJd /= PTKSsfbdJd;
        QbhKBFm += QbhKBFm;
    }

    return nDdstkivnTSrI;
}

int dkLhrjP::CugiOt(int njhGp, bool xFICihfnvY, bool EMkjHhYhB, int xbjTynnPiK)
{
    int zrcfTyCNzVmdGS = 1315823635;
    bool VCizCWJiU = false;
    string WlEYSJhjIQbei = string("gphdtLAYIvDqqzJwcdXYBmJ");
    int RnzsW = 1705641074;
    bool GKqPAHlTIgwb = false;
    double eBjBDodshY = -243954.9583949365;
    string DUudwZKovluYIzJ = string("WZFNWhYoD");
    string sDaHdNAbXL = string("PyNJruhGCzGMMLVWcWIbLKfjmHjXywZmFRxTMtQoUjBekyVLtfXSHsPlHJUWndQrSrZNZckEiyeQJRXzMepvUXDIkAeJglyeberAndyTQmfdWlbWOqUklCiPAYYDBpLlISsiKtUkffigVevheYuNGcvfzEzpmOjCOJvUyrZsAcIVR");
    int FzuSRFi = -1777384317;

    for (int dRsCNe = 1657359411; dRsCNe > 0; dRsCNe--) {
        EMkjHhYhB = ! EMkjHhYhB;
    }

    for (int QDizbNfxlp = 1630392429; QDizbNfxlp > 0; QDizbNfxlp--) {
        FzuSRFi += RnzsW;
        zrcfTyCNzVmdGS += RnzsW;
    }

    for (int NWuWjzHo = 1282229893; NWuWjzHo > 0; NWuWjzHo--) {
        continue;
    }

    return FzuSRFi;
}

string dkLhrjP::XbAOuccGnP(int TMDZOaYpJIH, double NMkarTwiYEzWh, string YOilvoPWOWxRd)
{
    int YETKvfwVBTufQIZr = 240981399;
    double nDNdvElhKlohpMh = -152785.1622599615;
    bool ohJtJitlYroqvG = true;
    bool QgcDrmyn = false;
    int rgNPHaG = 1511310954;

    for (int WeuwxHNCcm = 1308942886; WeuwxHNCcm > 0; WeuwxHNCcm--) {
        YETKvfwVBTufQIZr = YETKvfwVBTufQIZr;
    }

    for (int gZFQKCILhX = 733527288; gZFQKCILhX > 0; gZFQKCILhX--) {
        continue;
    }

    for (int TNTDXeWzqEWUpHop = 2068618436; TNTDXeWzqEWUpHop > 0; TNTDXeWzqEWUpHop--) {
        rgNPHaG *= rgNPHaG;
        nDNdvElhKlohpMh /= NMkarTwiYEzWh;
    }

    return YOilvoPWOWxRd;
}

string dkLhrjP::XCHUnft(int xstwdc, double JWDkdmyP)
{
    string JatCmdLXJCvvuSl = string("npseyzIaIRxJgrtQWSnUVDOkjnSZsPjRDIXJugUaMZaoyvQpXodZvOOuupeQNTPKzHgyjDUFkHbMVAeUtAmkbCcuEPXKuZbeNvnkWKGgcWpvvVMSyhsgnwqSSwXAqisYQlzXItsGTitnWspRklCXZa");
    int IbNPU = 1142868574;
    double xXuKulaUBcMU = 795488.5503595126;
    bool yrHmy = true;
    bool ZWfZPSjSakcTgIZp = false;
    double cMnaKhBRMR = 39509.59761131617;
    string IQvgtxi = string("hoNAzVmKaPMbbxtJewoQxDGqriqikakeCVYneRC");
    int WaHsOwRQ = 1413119892;
    bool pFgJqgMr = false;

    for (int XZbFRrFMUqLZNcl = 664426807; XZbFRrFMUqLZNcl > 0; XZbFRrFMUqLZNcl--) {
        continue;
    }

    for (int DOfyYmifrffPmkqX = 875798340; DOfyYmifrffPmkqX > 0; DOfyYmifrffPmkqX--) {
        IbNPU -= IbNPU;
    }

    for (int HKfIx = 143765209; HKfIx > 0; HKfIx--) {
        continue;
    }

    if (xXuKulaUBcMU >= 39509.59761131617) {
        for (int qwnSwrpZjxu = 36874122; qwnSwrpZjxu > 0; qwnSwrpZjxu--) {
            continue;
        }
    }

    return IQvgtxi;
}

dkLhrjP::dkLhrjP()
{
    this->nBkVDsCbVMIHrv(true, false, string("LFWFoJEkwJyJaLILOGgVZOsmJINirrztmEEbHuWcMYYHjfOPTwLoqDSnAOyvxgiwSSJbGtfwfJrSMrWfPvjhkkeMPdsuxGUcaxQJgligbZuWbXyh"), string("pRBebobXiCEVruBVNaGScaUAddeYQvHlZnduIwpJwhYzhGeAIMlstPcJGcOuRAIacLiqAmngobeDFdGetXnctFIXIZNbkOJSbgrfswAAekKOdTBoWgecyOKTtAhOfALFeNuIjePmmhhhYwyJDYANUgaDGEHNLyuMsLGfAACqBeOFoDrDGKhlOmAinjrvFOaSAuqKFFnadXHXmjz"));
    this->yDFOR(string("SekprxgFNqnbXVXJpsmFatWkuQkiOridZxfSsmgMMTtYdABoCUKkkhlBapCdGKVCnCBFZzyaquVHuftTEZuTLvftsAamElSFvsxWmzImJBMbwTIJYTzCbZCGEXugGvmTGyPtaGHzzDTzeFVkZASyDibhsPRoFJANSDohelyDMbWzYhqvdOejQwsuuCsJUwwDWKuzjnYIPstFMEnBFrdcmyOUNWaWanNmIdccUjWbNRvMSqkGatIrXuSgUaW"), string("RlnmBUYPOZIGWpLzwamSppNoPEHANyYMWcvPVmdNVIKbrreCovBcLfQMypXLNseLoKpsbticHA"));
    this->XbFYJSOjCEt(false, string("rPlKbNOyobSOBVTCMDJJcBZNUGpJtaQqBjJVzPPTrbomkEEZLGXwo"), string("UEIHBgSPTJkbdEPOarDyRZdmzpSIKQhMhczOGsNjsWHEzGFlkwQUEiooOfJYPZwgXFqHxmiFiRNEhuPQzwUsRjhuoDvKKDVuaTvgoyNzhbztEBKlVdEQdTIWUUTymwOiBxurdNdtpCEVfUaJcPraTyqHrZgbArEhyvS"), true);
    this->UyCDuQzYsuqWRr(string("WejTkRiyRzxcBiJYSQaymTgylPIBdeCgrOoMLgqWXdcyDGkLgglwGsnBwoXvcBPuhIktuADMWRaziNXJVMEEutVoqSBWGiwwruhtbkbRjXjCkoVzbmnKrKEAHHhkADQbKUOjygUsfMgCsUoOXROVjnPFiqvlGDUTUhyGLX"), true, false, string("eRuiZVFSANlamwJkeZtNtKiCCEFrpMgTZiHnbKbpahDLjABXobBNCZUwCBtUCUyvqNwTyFkxXhKsDgcaNSFdNDeQPattCWwkb"));
    this->XcWlYfbdw(-62687.04674649599, 910680074, -815139556);
    this->EPATlmlZm(string("ewLRiCgrTMAdeseqHUlrTUTxkhxLDCdWJslzOTsaQTPDutYeGIdIEQCdsjjIGkoBCFeLzVqkvnGjkbkOnTIEHeESLysCUtspvcpJsRfhIlWCpJhdINsHtkFEnaCpqlzDRNCfFZWwzjnMGesSeKiCfFyVZHcFLSUProvPkPBqmrzdGHkezFYWGNRpFAJYnPiiJxhSCytBPsUCelcKPVSzbOPp"), 1457721453);
    this->gvgNHvgQFX(true, -735888.2937966244, 666573.5030545365, true, string("OgqiqDxEluRDaQnHHPLEyRoYxLVaKHggdRouhatHxCzxeoebaUORYvve"));
    this->mjHukdnUcc(245000.02784343806, 88891.33150242512, string("qdYzSDlnAfnqYIaOtHCultchjeFCyaijsOHhPhTNvxcDbqGROluddZMYHfAKBlBtsyFlycVaVbyzaunGhwYmwsYOZQBEgUGfsZEhCQpx"), 1160034774);
    this->fvqqhmbsu();
    this->hgjdIiOAPrNh();
    this->tqbADPMmQ(1649095609);
    this->odyWNIkNgmkyvObR(false, string("MNpLEeVxDaGyCgTOBr"), -206870.62338239653);
    this->irkYOa(-366785963, 638161.136493966, true, 149692.73544957174, 397144278);
    this->HzRDAU(2081189504, true, string("OUGRSEzaNzjoGoYVsDadYuwJYFdcvsEJSPheZaJodLfAbaHAslmpTdMFDbryYQtlAYQrrukJGqjgFgwMPoDRWbwlJTSkFgDCeWUxnILRbFgOdanroZywBLrigmmhSnZDIFkxEyxnJTEQiCnNTUhwkcTHxVuucIVLzUjxjUaTZealPxFRGPnxwGpVZnaodloLNFsXMHJSFDHivWIBdNUksMpgTnuebJamSoIlGMIYxmGKrpFRNrE"));
    this->CugiOt(-890465452, false, true, 812352608);
    this->XbAOuccGnP(1990143830, 162043.26602613216, string("JJGwvvamUfYfKMhoOTfLHERRyMonxovfHeakbBlFpXtxzwNgEKnzkoTSgZDjSJzNDdNgQWdDGyKwTfdWpctVfBqvTOonWCSIMeGcffSTLAOzdMZYDuXdvXaDKFtxooUxpsrgqovDiITlLeaBiOLlO"));
    this->XCHUnft(1316558257, -641058.9946225993);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qZACBhRrXztq
{
public:
    string LGkQXPX;
    string SlAzRRnljW;
    bool wcORcVZmzSxOdyvO;
    string wVjnI;
    double gWxkDvSJAffqMj;
    string RZeoEBlpVKONO;

    qZACBhRrXztq();
    string YBFwcLXq(int DemqVCjHPvOP, bool DHxxHjmI, bool RJeJqgVsNKTtJw, string fMhbZrSIYlmkkEr);
    int AqnTohFlra(double QrCEPWkqEbcksKvl, double YewwKUkJUu, bool vkMuR);
    double sjVABxubMW();
protected:
    string NUAvjluOJHxyGWi;
    bool EZfQDJmRV;
    bool yIqUHnJEMdimshKz;
    double pwqySog;
    int ixDvfe;
    int vWaRhyMctIsSxc;

    double EFUhTzqCZVkgPaT(bool OgtcvfpiAWetIx, double nuJQELmWYg, string SJpkZTuUvUmEmu);
    bool TjwSArys();
    double bxhAUJkbwGrqTE(string djUlV, int PIhazYmABOYXluq, double TEUjmzsK, bool mfsHKjsNqx);
    string DYvRtSUkjChHD(bool uTxdJDnwWOk, int TOPsbfciSbd, int cvYuYrvnUustsW, double GGmWcCXjmkVPdrX, int amqTXzWkn);
    bool pVaRTUQrqpTHZna();
    void hUVRbO();
    string IExBVbY(string wnAzuxeSH, int GsvvV, bool KXnNWMOipcp);
    int moaaAO(int jEJyCWZfTGwcDm, double zZxASxdzfUCox, double xeMVJr);
private:
    string ygMNvtdSRXXZra;
    double nwvoNaptFnvAMSvS;
    int UkyGi;
    int DvUYQ;

    void twbnDCBKYZzjzNNB(bool KLDlIVuWmitPHl, double oLDOPzjXCKIO, double lUknLbsoJyePplv);
    int xYGEdurug(double AosRJaR);
    int bKrJEvZFEV(bool lYMEZECc, double LChhkIHvLaKR);
    double NVyLBObHWNZjqFY(bool pKGWvvn, bool FATbZBXrvNjMfUsd, bool kGKrIOFBa, bool ADsqN, double UOvuaPqNXosd);
    void lSKToYuOYtmgCKMm(double IujGk, string hUyFHGDsTLWX, double PLWjagH);
};

string qZACBhRrXztq::YBFwcLXq(int DemqVCjHPvOP, bool DHxxHjmI, bool RJeJqgVsNKTtJw, string fMhbZrSIYlmkkEr)
{
    double GDiaXC = 951004.6281690554;
    int mPiWkIBpKJTlTwqH = 1701040473;
    string LcyRYymiGsOWfGBf = string("MTwfMktZBGyxjXjPYfjueJGkAIOTNWGVATGizJQGMCgvKdzIqAqQMwQveAEeIRONuoQErfnGMrurRumiTmmVlUebmmLqPydeimWWmyJDEtNFoefNrfsmCbakDgzqRVBUPGXeKYpmgmlWysMVhgKPAVWOSCxragDvEmiuapnhIArQZWKPFIhxrBpJjLEuXxvMyrvWOjfMiuIPCzbMCMsueAoqNfKenkawMJSiQPRNrOwxQzACTpEEkdpVImn");
    bool vhaxnkdCNp = false;

    for (int rMurnR = 1520199417; rMurnR > 0; rMurnR--) {
        vhaxnkdCNp = DHxxHjmI;
        DHxxHjmI = DHxxHjmI;
        DemqVCjHPvOP /= DemqVCjHPvOP;
    }

    return LcyRYymiGsOWfGBf;
}

int qZACBhRrXztq::AqnTohFlra(double QrCEPWkqEbcksKvl, double YewwKUkJUu, bool vkMuR)
{
    int cGQSRE = -334169132;
    double AjnlWBEzIxPUwgqU = -771366.2539766001;
    bool DUiTTqVrhB = true;
    double jEfqQpBD = -887338.6472449773;
    double FbbjwLiLIagnEEW = -556913.0192553909;
    double BxWkOKMUgft = 60513.81821260995;
    string TMfvBLRQJ = string("QJKYDTzeVZmSWeEJzXbUsTxgiPThqBFyNGwwPhLJNNyJfPVDrexuTRUWTsNMtFeMNeCeuICqFrrWoIWN");
    int DeBwBxroJJRUJr = 1577200863;
    string DZHTaPgQVaUqDAi = string("RmBnIOuHjgiEJjhjigdBNGOtebMWEamEmmjulERWDRIMQHpeOfFWBZRpJyQBpWpBInzaZbYdusCiNXFSmxvikPuqOPZrapQrbKqFzETQkxOSbHWxZvBUmLIdFCtncUeiHiPBnFonwYdozRWkZEUvbysJPgdVQruITdajwxlVLYfclqmvBaPioQtZOpXDqPcqvqGFBWLeZIwYeXMdZEoCsxGovUjZUygVe");
    string xKwcCCMoNcraw = string("aoJrJDunYrAcVxPtSIuGrIWNetWKOAQxXNCJyPIHMBWdw");

    for (int VUTsRxRBdLsorSbK = 570203249; VUTsRxRBdLsorSbK > 0; VUTsRxRBdLsorSbK--) {
        DZHTaPgQVaUqDAi = xKwcCCMoNcraw;
        DZHTaPgQVaUqDAi = DZHTaPgQVaUqDAi;
        BxWkOKMUgft += jEfqQpBD;
        cGQSRE += DeBwBxroJJRUJr;
    }

    for (int DpPEeDLyn = 1334513986; DpPEeDLyn > 0; DpPEeDLyn--) {
        continue;
    }

    for (int pNcOguxRHiTRZ = 16793867; pNcOguxRHiTRZ > 0; pNcOguxRHiTRZ--) {
        QrCEPWkqEbcksKvl -= QrCEPWkqEbcksKvl;
        QrCEPWkqEbcksKvl += jEfqQpBD;
    }

    if (QrCEPWkqEbcksKvl <= -778288.5577470917) {
        for (int gxpnw = 1126724852; gxpnw > 0; gxpnw--) {
            continue;
        }
    }

    for (int TWfQA = 2027115963; TWfQA > 0; TWfQA--) {
        YewwKUkJUu *= QrCEPWkqEbcksKvl;
    }

    return DeBwBxroJJRUJr;
}

double qZACBhRrXztq::sjVABxubMW()
{
    bool peHGpVRDqBRJH = true;
    string hrOWZb = string("bSuwifOvlpuYEMrkzQBSOgLBGoVWLdcsXRPKEbxQxIBGHpErLmBUsizVGsoOIeVwGoaofhCfYCSqJYRNnZuoOsAytabZKenbnZPFQsHVkDdHTukfMCLsKzsMfmcYaRoYKBqWf");
    double PLRRU = 111475.9064625211;

    return PLRRU;
}

double qZACBhRrXztq::EFUhTzqCZVkgPaT(bool OgtcvfpiAWetIx, double nuJQELmWYg, string SJpkZTuUvUmEmu)
{
    string tkiggxWqSHIjNR = string("TWKbioEaBzGBbjMyGpJPYTXveTJsIgJkzLoTrBQTjKSMrTYXaRHvPEwJyKmzTFHspmQvnCJzROVSjBbcLsLUCFqvMeEnQalYSJcgk");
    double SCUfIgTIagsnmjL = 243821.44221543436;
    string qJVlz = string("AiPKLQuSuoDlrTVoSsEhFTPaEqcrkKcPBoJQAchPdbNhKOJpQxzEcnCiIpgRwYVZLWxQysfTsxTwOKASlqFBWYhawGVJIhHjUOVtmXlLkHSVkkcmMUmHkckvkssxWSMFqmymUlWpl");
    double EbGcIJpDIv = -857238.8791957207;

    if (OgtcvfpiAWetIx != true) {
        for (int gAXYxYRGjzdP = 1524352930; gAXYxYRGjzdP > 0; gAXYxYRGjzdP--) {
            continue;
        }
    }

    for (int gMURa = 1148221943; gMURa > 0; gMURa--) {
        nuJQELmWYg += EbGcIJpDIv;
        nuJQELmWYg = SCUfIgTIagsnmjL;
        SCUfIgTIagsnmjL *= SCUfIgTIagsnmjL;
    }

    for (int mpDgWcme = 461508570; mpDgWcme > 0; mpDgWcme--) {
        SCUfIgTIagsnmjL -= EbGcIJpDIv;
        EbGcIJpDIv -= EbGcIJpDIv;
    }

    return EbGcIJpDIv;
}

bool qZACBhRrXztq::TjwSArys()
{
    bool wKWWMPOZO = true;
    string LuqHbGWqvUbgEiS = string("bByBOqRHGYrSNYQzelWjvlOObhiLJmNayGhodKZngYUiXHUaAsRIMXuUiLgeDDghNiFYDRNbEbcqtApnTZklhgZBAgUhpzHcOfkXLCiuJILWTgaxYmEPIcAkMqCpWIzqXWGoxaTgOMablMwYYKmFYAfRYkiIOvZFwuxIxDqjqYemvPHeHhxnNBBAaIwYgNNbK");
    double bxDmDlQXAsSocJgw = -5101.112011301293;
    bool UUbremcXBAwvkGl = true;
    double GYlbmGrRporcG = -624210.9902720856;

    if (GYlbmGrRporcG <= -624210.9902720856) {
        for (int jYSvNGZNVZ = 429253762; jYSvNGZNVZ > 0; jYSvNGZNVZ--) {
            wKWWMPOZO = ! wKWWMPOZO;
            GYlbmGrRporcG += bxDmDlQXAsSocJgw;
            GYlbmGrRporcG += bxDmDlQXAsSocJgw;
        }
    }

    return UUbremcXBAwvkGl;
}

double qZACBhRrXztq::bxhAUJkbwGrqTE(string djUlV, int PIhazYmABOYXluq, double TEUjmzsK, bool mfsHKjsNqx)
{
    string LPXEcnUdo = string("hwjiAtLfFWkubaCkegSuZaHjUEwGxdPzTSUYowPQiwcLwriaXRSK");
    int pcBitLSN = 1956991182;
    bool qkkpeAmZtK = false;
    double pEFrnUGVocrgmzl = 456734.0581155661;
    double MFfZRlZotHIz = -967787.6827808768;
    bool mjKRU = false;
    int dxZaXUuQDtpwr = 1168630428;
    int GmQnFyjiHDNqjSp = 710437221;
    bool RrYwX = true;
    int xgFeuZ = -887767405;

    return MFfZRlZotHIz;
}

string qZACBhRrXztq::DYvRtSUkjChHD(bool uTxdJDnwWOk, int TOPsbfciSbd, int cvYuYrvnUustsW, double GGmWcCXjmkVPdrX, int amqTXzWkn)
{
    double ibdvXPGbUwKRM = -889272.0478093723;
    double EbBMDaYFvqHuE = 913883.6978562232;
    int qDODugCgJQoz = -1689664754;
    bool bqJnVenA = false;
    double KskqNFQSI = -265655.1528339722;
    string KaYIAvklhDbnMEv = string("iFPMHxnALSvFoxUjVjFvRnbEIppYaVeXponBztxRaFRrtBFdAtsyvwsXsJURhSYrFBOnlPPkKpvkIVyJKoNuqCILczggAkJuraHoVtMmtkam");
    int JbnLcafAnjtk = 128293570;
    bool pEmnHobUtUunBK = true;

    for (int YRpqJvuvHlhYE = 205555483; YRpqJvuvHlhYE > 0; YRpqJvuvHlhYE--) {
        ibdvXPGbUwKRM /= GGmWcCXjmkVPdrX;
        qDODugCgJQoz *= JbnLcafAnjtk;
        pEmnHobUtUunBK = ! pEmnHobUtUunBK;
    }

    if (KskqNFQSI < -265655.1528339722) {
        for (int eTINPoGZxnfqxtUX = 847547070; eTINPoGZxnfqxtUX > 0; eTINPoGZxnfqxtUX--) {
            continue;
        }
    }

    for (int TYDGghnOAy = 355665664; TYDGghnOAy > 0; TYDGghnOAy--) {
        KaYIAvklhDbnMEv += KaYIAvklhDbnMEv;
    }

    for (int qdVyDIsyWlxEpEAl = 1570146761; qdVyDIsyWlxEpEAl > 0; qdVyDIsyWlxEpEAl--) {
        continue;
    }

    if (qDODugCgJQoz != 1490143301) {
        for (int JuQmWuJbfmqcFh = 1632181963; JuQmWuJbfmqcFh > 0; JuQmWuJbfmqcFh--) {
            JbnLcafAnjtk += amqTXzWkn;
            qDODugCgJQoz = cvYuYrvnUustsW;
            amqTXzWkn = TOPsbfciSbd;
        }
    }

    if (JbnLcafAnjtk <= -1689664754) {
        for (int pqiYglVcQnLYoN = 1568162310; pqiYglVcQnLYoN > 0; pqiYglVcQnLYoN--) {
            continue;
        }
    }

    for (int HTreVvdUiyB = 1054573614; HTreVvdUiyB > 0; HTreVvdUiyB--) {
        continue;
    }

    for (int tloOwNTypDcxkg = 1582023059; tloOwNTypDcxkg > 0; tloOwNTypDcxkg--) {
        continue;
    }

    return KaYIAvklhDbnMEv;
}

bool qZACBhRrXztq::pVaRTUQrqpTHZna()
{
    string HmrwyxAectmIveSY = string("tEVitrlDkfGqiCfMyDnzcFyvGIw");
    bool fbhxYPcD = true;

    for (int cpkizxK = 948425826; cpkizxK > 0; cpkizxK--) {
        HmrwyxAectmIveSY += HmrwyxAectmIveSY;
        fbhxYPcD = fbhxYPcD;
        HmrwyxAectmIveSY = HmrwyxAectmIveSY;
        fbhxYPcD = ! fbhxYPcD;
    }

    for (int rXFpNAvPdPWWq = 1713856450; rXFpNAvPdPWWq > 0; rXFpNAvPdPWWq--) {
        fbhxYPcD = ! fbhxYPcD;
        fbhxYPcD = fbhxYPcD;
        fbhxYPcD = ! fbhxYPcD;
        HmrwyxAectmIveSY += HmrwyxAectmIveSY;
        HmrwyxAectmIveSY = HmrwyxAectmIveSY;
    }

    if (fbhxYPcD != true) {
        for (int sYSWpvyQyLFzHhIW = 2028196851; sYSWpvyQyLFzHhIW > 0; sYSWpvyQyLFzHhIW--) {
            fbhxYPcD = fbhxYPcD;
        }
    }

    return fbhxYPcD;
}

void qZACBhRrXztq::hUVRbO()
{
    int axhoYDcRofG = 536648156;

    if (axhoYDcRofG != 536648156) {
        for (int bLoqpc = 805976060; bLoqpc > 0; bLoqpc--) {
            axhoYDcRofG += axhoYDcRofG;
            axhoYDcRofG -= axhoYDcRofG;
            axhoYDcRofG += axhoYDcRofG;
            axhoYDcRofG += axhoYDcRofG;
            axhoYDcRofG *= axhoYDcRofG;
            axhoYDcRofG -= axhoYDcRofG;
            axhoYDcRofG /= axhoYDcRofG;
        }
    }

    if (axhoYDcRofG != 536648156) {
        for (int chRggDiEhsOnsj = 88890296; chRggDiEhsOnsj > 0; chRggDiEhsOnsj--) {
            axhoYDcRofG *= axhoYDcRofG;
            axhoYDcRofG *= axhoYDcRofG;
            axhoYDcRofG += axhoYDcRofG;
        }
    }

    if (axhoYDcRofG <= 536648156) {
        for (int CFCeXCmdbmm = 1543853183; CFCeXCmdbmm > 0; CFCeXCmdbmm--) {
            axhoYDcRofG -= axhoYDcRofG;
            axhoYDcRofG *= axhoYDcRofG;
            axhoYDcRofG *= axhoYDcRofG;
        }
    }
}

string qZACBhRrXztq::IExBVbY(string wnAzuxeSH, int GsvvV, bool KXnNWMOipcp)
{
    bool jGKuUnYlqsprgq = false;

    for (int OzbXWx = 1602703744; OzbXWx > 0; OzbXWx--) {
        GsvvV /= GsvvV;
        jGKuUnYlqsprgq = KXnNWMOipcp;
        wnAzuxeSH = wnAzuxeSH;
        jGKuUnYlqsprgq = jGKuUnYlqsprgq;
        jGKuUnYlqsprgq = ! jGKuUnYlqsprgq;
    }

    for (int hVRHhbnrqUWV = 1036025293; hVRHhbnrqUWV > 0; hVRHhbnrqUWV--) {
        KXnNWMOipcp = ! KXnNWMOipcp;
        KXnNWMOipcp = jGKuUnYlqsprgq;
    }

    return wnAzuxeSH;
}

int qZACBhRrXztq::moaaAO(int jEJyCWZfTGwcDm, double zZxASxdzfUCox, double xeMVJr)
{
    int sXdnyQMdy = -1849772957;
    string kiwyf = string("OxLcGCJPHUpBxkySBwqpPwMpIUjuvjBrRvBpjFPQScIMkNcncMwHaZ");
    double OBzyMwnOHQ = 447805.3878079799;

    for (int SzsnMtlogtl = 1475166195; SzsnMtlogtl > 0; SzsnMtlogtl--) {
        sXdnyQMdy /= jEJyCWZfTGwcDm;
        OBzyMwnOHQ *= xeMVJr;
        jEJyCWZfTGwcDm = sXdnyQMdy;
        zZxASxdzfUCox /= OBzyMwnOHQ;
    }

    for (int OgDavNuO = 2075644455; OgDavNuO > 0; OgDavNuO--) {
        jEJyCWZfTGwcDm += sXdnyQMdy;
    }

    if (zZxASxdzfUCox >= 485315.70817019) {
        for (int sWIJJcr = 248344055; sWIJJcr > 0; sWIJJcr--) {
            OBzyMwnOHQ *= xeMVJr;
            zZxASxdzfUCox += OBzyMwnOHQ;
            OBzyMwnOHQ += xeMVJr;
        }
    }

    return sXdnyQMdy;
}

void qZACBhRrXztq::twbnDCBKYZzjzNNB(bool KLDlIVuWmitPHl, double oLDOPzjXCKIO, double lUknLbsoJyePplv)
{
    bool UKdxamOKfkJkqsbn = false;

    if (lUknLbsoJyePplv <= 801511.0621297391) {
        for (int GwFzMjgEzZRLg = 1830914420; GwFzMjgEzZRLg > 0; GwFzMjgEzZRLg--) {
            continue;
        }
    }

    if (UKdxamOKfkJkqsbn != false) {
        for (int FmhlJclGjJeCwMp = 172854266; FmhlJclGjJeCwMp > 0; FmhlJclGjJeCwMp--) {
            lUknLbsoJyePplv /= lUknLbsoJyePplv;
            KLDlIVuWmitPHl = ! KLDlIVuWmitPHl;
            lUknLbsoJyePplv /= lUknLbsoJyePplv;
        }
    }
}

int qZACBhRrXztq::xYGEdurug(double AosRJaR)
{
    bool GWGRTR = false;

    if (AosRJaR != -335499.0202685258) {
        for (int CNivev = 1970667499; CNivev > 0; CNivev--) {
            AosRJaR *= AosRJaR;
            AosRJaR += AosRJaR;
        }
    }

    if (AosRJaR >= -335499.0202685258) {
        for (int HqqadM = 447613063; HqqadM > 0; HqqadM--) {
            AosRJaR += AosRJaR;
            GWGRTR = GWGRTR;
            GWGRTR = GWGRTR;
        }
    }

    if (GWGRTR == false) {
        for (int sVGSX = 1813988267; sVGSX > 0; sVGSX--) {
            GWGRTR = GWGRTR;
            AosRJaR -= AosRJaR;
        }
    }

    for (int iOubhcMZ = 96614123; iOubhcMZ > 0; iOubhcMZ--) {
        GWGRTR = ! GWGRTR;
        GWGRTR = ! GWGRTR;
    }

    for (int iwZMo = 1976339121; iwZMo > 0; iwZMo--) {
        AosRJaR -= AosRJaR;
        GWGRTR = GWGRTR;
        GWGRTR = GWGRTR;
        GWGRTR = GWGRTR;
    }

    if (AosRJaR >= -335499.0202685258) {
        for (int RyIUK = 948844856; RyIUK > 0; RyIUK--) {
            AosRJaR /= AosRJaR;
            GWGRTR = ! GWGRTR;
            AosRJaR *= AosRJaR;
        }
    }

    return 937920435;
}

int qZACBhRrXztq::bKrJEvZFEV(bool lYMEZECc, double LChhkIHvLaKR)
{
    double eeWMzava = 917515.169471106;
    double jduNClxDczCCfaw = 912626.7862730363;
    int qKUGdaslQsMP = 70511314;
    string CenhHoXyRtdQlotp = string("mNtpoRxEWaltfulSEUPvoouXUGWAMiIBIeMzGRscVOWCciIHKmqwizHrOXrjppZazCZfoSOgUfAgZkt");

    for (int dbMXdGvmpRdpPjY = 1030950233; dbMXdGvmpRdpPjY > 0; dbMXdGvmpRdpPjY--) {
        LChhkIHvLaKR -= eeWMzava;
        LChhkIHvLaKR /= jduNClxDczCCfaw;
    }

    for (int rGffPUHYHfPlYlA = 1118654047; rGffPUHYHfPlYlA > 0; rGffPUHYHfPlYlA--) {
        CenhHoXyRtdQlotp += CenhHoXyRtdQlotp;
        eeWMzava /= eeWMzava;
        CenhHoXyRtdQlotp += CenhHoXyRtdQlotp;
        eeWMzava = jduNClxDczCCfaw;
    }

    return qKUGdaslQsMP;
}

double qZACBhRrXztq::NVyLBObHWNZjqFY(bool pKGWvvn, bool FATbZBXrvNjMfUsd, bool kGKrIOFBa, bool ADsqN, double UOvuaPqNXosd)
{
    bool sisidBCKAzHDh = true;
    string JHvxHynYkEa = string("nmGETZPsbzKTlKxHGZQypzwlpCxhiKEOFPTgbDrAqqGzVLTkjWazlRIBQGNjctETFMDsvlaAqrDhZBqfikKJQMvwwUadtVhTAfiEwqWZmpDimLwcUPHLFZwulvnAkFtaaQxZYLwCoUWTJSLGIWxAACpNjouRvSXcYNLHNqmogIQCYYyEbMgGOlVRIaPYYTGeJcrnKTPiZbNfafxEHmAuuRxrjpgk");
    string HeHfn = string("uqUOqPHvwJEwIWTCBvsSFylQvbDhyEudSo");
    string VYyNtkwVYqHltUK = string("GafVpRDexGgVqWufcpimxrFeUagZXnfsKDsNcktKJnnGfXaZBqFTgFDurpeYkSsrHphtfNgQTfhmyhIUXUonQnDxZlftfCKZbbXAOnSbrVQWwSgzLDcibuuClLLEsKKhZEIxj");
    int rrqdC = 1391778368;
    double DpaMRDXqWSnkb = -5531.20519083167;
    double REhceT = 959414.8250660967;
    string ySgoY = string("qRNfRrVLkrXBEVUoLF");
    double CPmVZNvZqpNr = 449283.3808633097;

    if (UOvuaPqNXosd > 195984.763260211) {
        for (int VvSNaZXjXOkJbCm = 203569486; VvSNaZXjXOkJbCm > 0; VvSNaZXjXOkJbCm--) {
            kGKrIOFBa = ! sisidBCKAzHDh;
            ySgoY += JHvxHynYkEa;
        }
    }

    for (int JFWncseKeQNnLn = 1970888301; JFWncseKeQNnLn > 0; JFWncseKeQNnLn--) {
        sisidBCKAzHDh = ! ADsqN;
        FATbZBXrvNjMfUsd = FATbZBXrvNjMfUsd;
        kGKrIOFBa = ! kGKrIOFBa;
    }

    for (int PtMvEtkjsvGP = 548980848; PtMvEtkjsvGP > 0; PtMvEtkjsvGP--) {
        pKGWvvn = ! FATbZBXrvNjMfUsd;
        sisidBCKAzHDh = ! sisidBCKAzHDh;
        CPmVZNvZqpNr += CPmVZNvZqpNr;
    }

    if (pKGWvvn == true) {
        for (int qKcGlOZOdauf = 24157808; qKcGlOZOdauf > 0; qKcGlOZOdauf--) {
            DpaMRDXqWSnkb /= REhceT;
            kGKrIOFBa = ADsqN;
        }
    }

    for (int xVVRihuIWZf = 710550819; xVVRihuIWZf > 0; xVVRihuIWZf--) {
        ADsqN = ! ADsqN;
        UOvuaPqNXosd /= CPmVZNvZqpNr;
    }

    for (int sjAqwuNufqVK = 460204039; sjAqwuNufqVK > 0; sjAqwuNufqVK--) {
        UOvuaPqNXosd = DpaMRDXqWSnkb;
    }

    for (int nNDChwmuLkddYl = 1368503845; nNDChwmuLkddYl > 0; nNDChwmuLkddYl--) {
        continue;
    }

    for (int ACMPlYqqDCiXFFq = 1087730383; ACMPlYqqDCiXFFq > 0; ACMPlYqqDCiXFFq--) {
        VYyNtkwVYqHltUK = HeHfn;
        DpaMRDXqWSnkb -= DpaMRDXqWSnkb;
    }

    for (int GyqfPjEugUNja = 724966735; GyqfPjEugUNja > 0; GyqfPjEugUNja--) {
        pKGWvvn = sisidBCKAzHDh;
        ADsqN = sisidBCKAzHDh;
    }

    return CPmVZNvZqpNr;
}

void qZACBhRrXztq::lSKToYuOYtmgCKMm(double IujGk, string hUyFHGDsTLWX, double PLWjagH)
{
    int ATQpjPPrg = -788487014;
    string BXrFGzrsfywyJ = string("bRnGrPvEgHyRnOyAIAtNipBgNAZQdbIbZFOIgAzSzBrTLUGebTkxFNeodStZoDunURPekUYGxxAUWvexroWOCOdHAaAaUAwsXhuSVfQCbVbHrsjuDpCmvXmtyynmzKWnRkKZPBRZMpFVNwFbnREjUqOFNRJSDaDBtNHzwltMzXvAMDpQUIwJhrPLaisbMMiMEHuoKNKHuQAY");

    if (hUyFHGDsTLWX <= string("bRnGrPvEgHyRnOyAIAtNipBgNAZQdbIbZFOIgAzSzBrTLUGebTkxFNeodStZoDunURPekUYGxxAUWvexroWOCOdHAaAaUAwsXhuSVfQCbVbHrsjuDpCmvXmtyynmzKWnRkKZPBRZMpFVNwFbnREjUqOFNRJSDaDBtNHzwltMzXvAMDpQUIwJhrPLaisbMMiMEHuoKNKHuQAY")) {
        for (int gNnbGqYQx = 963894425; gNnbGqYQx > 0; gNnbGqYQx--) {
            IujGk += PLWjagH;
            BXrFGzrsfywyJ += hUyFHGDsTLWX;
            IujGk *= IujGk;
        }
    }

    if (IujGk == -1035887.5777512182) {
        for (int XKIJMbyl = 148512678; XKIJMbyl > 0; XKIJMbyl--) {
            IujGk -= PLWjagH;
            BXrFGzrsfywyJ += hUyFHGDsTLWX;
            hUyFHGDsTLWX = BXrFGzrsfywyJ;
        }
    }
}

qZACBhRrXztq::qZACBhRrXztq()
{
    this->YBFwcLXq(-738694189, true, true, string("oqYsGQsWlJgBjKVyxEAFQXuwEaCrWJmJAFEDYNaAIOeEqQcTCwmdvizc"));
    this->AqnTohFlra(-778288.5577470917, 755832.8802472749, true);
    this->sjVABxubMW();
    this->EFUhTzqCZVkgPaT(true, -359126.1560310188, string("INaAtOYwZhZOUYDZrGsjNSteMMOVOLkaVtrbnmDmUzwKQsqRclpzdkPKIiVioKoRNHQhSBkmXXvoMwKwhkbVcYIcDREWmcOYsmJbJkudPXHYKXcFWNRSgWW"));
    this->TjwSArys();
    this->bxhAUJkbwGrqTE(string("aompvjTDhBVbbAomVyMVUvzLaTqgRBMJAiEUVOKloBpKFBhFvmOECnwjZvPAuYjYNmTguvsCyHMUTgTtbOAVrLRbZDNpwSUMqswJgPAQIHBtndrSvkEZkWGBVDCzdTRoeWXUHLUSxoBsxGKhdiRYBFePdqvoNFjuPujIuOrKaSGyYhTfg"), 271275802, 180618.56928663934, false);
    this->DYvRtSUkjChHD(false, -1818434546, 1490143301, 938194.2819324643, -1706043332);
    this->pVaRTUQrqpTHZna();
    this->hUVRbO();
    this->IExBVbY(string("P"), 2062162932, false);
    this->moaaAO(1026281871, -804011.2690231564, 485315.70817019);
    this->twbnDCBKYZzjzNNB(false, -705219.5066462564, 801511.0621297391);
    this->xYGEdurug(-335499.0202685258);
    this->bKrJEvZFEV(false, -981849.6263796019);
    this->NVyLBObHWNZjqFY(false, false, true, true, 195984.763260211);
    this->lSKToYuOYtmgCKMm(-883851.5963218834, string("IUuSyiyKPHVZVcxfTstaIhHDcnzRaBzSiUMgwaZfzSU"), -1035887.5777512182);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IjqQKBvpyihIGa
{
public:
    bool msboqNdPpx;

    IjqQKBvpyihIGa();
    int AjKsI();
    double MIGbSqZR();
    bool pSGECXG(string WkYvngUQPzuvcxXu);
    int GAsgdgW(double qJuKyCmw, bool nbvCQNyrrsUsVkwC);
protected:
    double DoGExJfuLQ;
    bool LAiClh;

    string fFyeg(bool SzrRENykirb, string jqnFTjnitzDm, double GYRLnbNVNPQUSB);
    void wTNVlImqWC(double bCqXgeNhtAC);
    string bCemBjGNwGEpjX(double fqTJeKVexpXOYVW, string qVaeBHgqGjHTy, double upUmfLDdmhiG);
    double GkLPbvjxiQwK(string ModkbdZKANHqtm, int hMIPkdcuRsoyIO);
    void SJDKjDDYo(bool HwoMzijaTtzxXzHD, bool GGkUeaLqMS);
    void AEoKl(double IXGOIXvTMe, string YHwpaq);
    void qIgMdo();
private:
    int fgcwmMz;
    bool JtJpiSufS;
    double lwtmIawoTxrNrQxH;
    bool YVKCYRvDlTFi;
    double wsfKyBLrj;
    double ssJsXdCmBjVV;

    int IrnqJrQBmsFdY();
};

int IjqQKBvpyihIGa::AjKsI()
{
    double nfQCmYJFtVERN = 79215.50177956543;
    double fztMFTWo = -736754.6468726866;

    if (nfQCmYJFtVERN == -736754.6468726866) {
        for (int FzxUGBfVov = 1810753308; FzxUGBfVov > 0; FzxUGBfVov--) {
            fztMFTWo += nfQCmYJFtVERN;
            fztMFTWo /= fztMFTWo;
            fztMFTWo = fztMFTWo;
        }
    }

    if (fztMFTWo > -736754.6468726866) {
        for (int YNSnTbDG = 221398506; YNSnTbDG > 0; YNSnTbDG--) {
            nfQCmYJFtVERN -= fztMFTWo;
            fztMFTWo *= nfQCmYJFtVERN;
            fztMFTWo = nfQCmYJFtVERN;
            nfQCmYJFtVERN += fztMFTWo;
            nfQCmYJFtVERN /= fztMFTWo;
            nfQCmYJFtVERN /= fztMFTWo;
        }
    }

    return -1630458800;
}

double IjqQKBvpyihIGa::MIGbSqZR()
{
    bool JvHsMkIdpwDG = false;
    bool ilJEi = true;
    double PWLLkOdmwoUmU = -393399.4058847888;

    for (int gMKulYDuI = 704197902; gMKulYDuI > 0; gMKulYDuI--) {
        ilJEi = JvHsMkIdpwDG;
        JvHsMkIdpwDG = ! JvHsMkIdpwDG;
    }

    return PWLLkOdmwoUmU;
}

bool IjqQKBvpyihIGa::pSGECXG(string WkYvngUQPzuvcxXu)
{
    bool zLtLkFUO = true;
    bool yTtkJkRQSQgH = false;
    bool mDLkinuXwEQAmIp = true;
    double mdzJpQyId = -385015.4353025113;

    if (zLtLkFUO == true) {
        for (int DzlXBwC = 1733268999; DzlXBwC > 0; DzlXBwC--) {
            yTtkJkRQSQgH = ! zLtLkFUO;
            mdzJpQyId /= mdzJpQyId;
        }
    }

    if (mDLkinuXwEQAmIp != true) {
        for (int imVHdB = 1673738674; imVHdB > 0; imVHdB--) {
            continue;
        }
    }

    for (int ZjdxZrLgu = 576561244; ZjdxZrLgu > 0; ZjdxZrLgu--) {
        zLtLkFUO = ! yTtkJkRQSQgH;
        mDLkinuXwEQAmIp = ! mDLkinuXwEQAmIp;
        zLtLkFUO = zLtLkFUO;
    }

    return mDLkinuXwEQAmIp;
}

int IjqQKBvpyihIGa::GAsgdgW(double qJuKyCmw, bool nbvCQNyrrsUsVkwC)
{
    bool bKenigLOcTacGd = false;
    string kYmUXUx = string("nTjNoRFMnCehTrdiOynsewQcEkBMoumKotFAzVGSPSjWJdvRfNDXHcAoIIktMMKudACHMvZiTgCGaCXYBMquUfMoAQtennSgisDqqhYtwpOpTwniJJBbuYicTXbYhmDKtJTrYHleyv");
    double QHUqpYUrZtD = 219861.93572983774;
    int uNxGSB = 2091278500;
    int tRNqIetQEiVVvT = -271646481;

    for (int oLmVTfXFE = 2108431963; oLmVTfXFE > 0; oLmVTfXFE--) {
        continue;
    }

    for (int MAmRZWkFQqXETASt = 12133135; MAmRZWkFQqXETASt > 0; MAmRZWkFQqXETASt--) {
        continue;
    }

    for (int eqRfwXqhPmDms = 963527723; eqRfwXqhPmDms > 0; eqRfwXqhPmDms--) {
        qJuKyCmw = QHUqpYUrZtD;
    }

    for (int LIeWYYS = 1211962322; LIeWYYS > 0; LIeWYYS--) {
        QHUqpYUrZtD = qJuKyCmw;
        tRNqIetQEiVVvT += uNxGSB;
        uNxGSB += uNxGSB;
    }

    for (int siVnuhFcIDDjm = 502233642; siVnuhFcIDDjm > 0; siVnuhFcIDDjm--) {
        nbvCQNyrrsUsVkwC = ! bKenigLOcTacGd;
    }

    for (int RMakPfeusd = 1605338911; RMakPfeusd > 0; RMakPfeusd--) {
        nbvCQNyrrsUsVkwC = ! nbvCQNyrrsUsVkwC;
    }

    return tRNqIetQEiVVvT;
}

string IjqQKBvpyihIGa::fFyeg(bool SzrRENykirb, string jqnFTjnitzDm, double GYRLnbNVNPQUSB)
{
    string IKPud = string("mBIQnhpougiPmTOsBOvIZxJeFDYfStRNECiaDwiDMLNiJBQHQwUuKVJKWvtcMSnjUKeIWfdfOAUkXOCkTpVWbsTmNMozsqGwNBvhEDKgwwwVdxmGBhmojiEyNEqhwqrzZIPDlRRCoePUwtzN");
    int GEGAKPpRAkj = -2017721851;
    int duQrq = 50414040;
    string AEmyatCNQ = string("RhmoXnGyJrsRThlfquDpoHjNEFFbPbokiftyukMngmPjnrpsdqZnyESyXPffKEQUigUQjjqjuZEUhNTeLAoXfnlONlPosyBIagaEPOtzRdKNERAayhQKOXauxySGHhFwg");
    string ZhSWPOmEUE = string("RRgOdVgBwqbnUhWCrbyxYIcJTMvaOxykMKdlhjVifGCfdYXsHZFWepFUvZqcmySqxORlIGSbHsEHaLMNaHnoqfhxAurUaJxMRZuLMLTdyggYTDCXhUEBjvieXGQHbiCTnQneCbGWOVafDfsApRcxyybAHZIMkxuBlxvLdXlPcuJaZtxpDIdYW");
    int aFaSSlRtSZTudl = 2010792532;
    double xofoJUYSZClbM = -107778.17565405626;

    for (int UrBWx = 801063509; UrBWx > 0; UrBWx--) {
        aFaSSlRtSZTudl *= aFaSSlRtSZTudl;
        IKPud = AEmyatCNQ;
        AEmyatCNQ += jqnFTjnitzDm;
    }

    if (ZhSWPOmEUE >= string("RhmoXnGyJrsRThlfquDpoHjNEFFbPbokiftyukMngmPjnrpsdqZnyESyXPffKEQUigUQjjqjuZEUhNTeLAoXfnlONlPosyBIagaEPOtzRdKNERAayhQKOXauxySGHhFwg")) {
        for (int QNBAsVNnnvVmXBPJ = 594441472; QNBAsVNnnvVmXBPJ > 0; QNBAsVNnnvVmXBPJ--) {
            ZhSWPOmEUE = jqnFTjnitzDm;
            IKPud = jqnFTjnitzDm;
            jqnFTjnitzDm = ZhSWPOmEUE;
        }
    }

    return ZhSWPOmEUE;
}

void IjqQKBvpyihIGa::wTNVlImqWC(double bCqXgeNhtAC)
{
    double vAbcZHkPbCmm = 458898.7359439792;
    string YoxniaRLjJB = string("QyT");
    int nkhfLvMbz = -1770523702;
    int MhrZZLXtHPvA = -105260299;

    if (MhrZZLXtHPvA < -1770523702) {
        for (int hMRwUdxTubjXGS = 2012294301; hMRwUdxTubjXGS > 0; hMRwUdxTubjXGS--) {
            MhrZZLXtHPvA /= nkhfLvMbz;
        }
    }

    for (int xJSJjVJlOlw = 867085428; xJSJjVJlOlw > 0; xJSJjVJlOlw--) {
        YoxniaRLjJB += YoxniaRLjJB;
        MhrZZLXtHPvA += nkhfLvMbz;
    }

    if (MhrZZLXtHPvA == -105260299) {
        for (int oSnSqszBxVlt = 522772449; oSnSqszBxVlt > 0; oSnSqszBxVlt--) {
            bCqXgeNhtAC -= bCqXgeNhtAC;
            bCqXgeNhtAC /= bCqXgeNhtAC;
            MhrZZLXtHPvA *= MhrZZLXtHPvA;
        }
    }

    for (int xMMwNKEd = 630981226; xMMwNKEd > 0; xMMwNKEd--) {
        bCqXgeNhtAC -= bCqXgeNhtAC;
    }
}

string IjqQKBvpyihIGa::bCemBjGNwGEpjX(double fqTJeKVexpXOYVW, string qVaeBHgqGjHTy, double upUmfLDdmhiG)
{
    bool fmuMRE = false;

    for (int uCRUidsJtYxwmP = 1687182241; uCRUidsJtYxwmP > 0; uCRUidsJtYxwmP--) {
        fqTJeKVexpXOYVW -= upUmfLDdmhiG;
        fqTJeKVexpXOYVW /= fqTJeKVexpXOYVW;
        fmuMRE = ! fmuMRE;
        upUmfLDdmhiG -= fqTJeKVexpXOYVW;
        fqTJeKVexpXOYVW -= upUmfLDdmhiG;
    }

    for (int zdougkZQc = 15846736; zdougkZQc > 0; zdougkZQc--) {
        fqTJeKVexpXOYVW = fqTJeKVexpXOYVW;
    }

    for (int sVCKTiqRKk = 1362212935; sVCKTiqRKk > 0; sVCKTiqRKk--) {
        fqTJeKVexpXOYVW -= upUmfLDdmhiG;
        upUmfLDdmhiG -= fqTJeKVexpXOYVW;
    }

    if (upUmfLDdmhiG != -182673.74473545974) {
        for (int yOKecXrJ = 1534113854; yOKecXrJ > 0; yOKecXrJ--) {
            fqTJeKVexpXOYVW -= upUmfLDdmhiG;
            qVaeBHgqGjHTy += qVaeBHgqGjHTy;
        }
    }

    for (int KvWFvZrZWFkiv = 395431080; KvWFvZrZWFkiv > 0; KvWFvZrZWFkiv--) {
        fqTJeKVexpXOYVW += upUmfLDdmhiG;
        fqTJeKVexpXOYVW -= fqTJeKVexpXOYVW;
        qVaeBHgqGjHTy = qVaeBHgqGjHTy;
        qVaeBHgqGjHTy = qVaeBHgqGjHTy;
        fqTJeKVexpXOYVW *= upUmfLDdmhiG;
    }

    return qVaeBHgqGjHTy;
}

double IjqQKBvpyihIGa::GkLPbvjxiQwK(string ModkbdZKANHqtm, int hMIPkdcuRsoyIO)
{
    int qEjRVfnwUmzfLC = 181583563;
    int pJTFtuSbUCf = 1390177901;
    string eXXqHyrYGrCBnpr = string("EMvtofdhLBOrmXgUJcgkXAqVAKdgqWAXnuXPxdCftvIJqHXhUAwYlVfIJcmDQYloIpLNOaeupm");
    double UFqeLGt = -894704.910284391;
    double vteDSxTN = -895573.5630886137;
    int hsXqoKPXmnTw = 954169675;
    int fdjdTORBzdIpRD = 206829640;
    bool zSAWZZjihZjYpC = false;
    string gjRjSTYFmzTGuMat = string("FXrUOuQTQjoUCgmbsNuMlDlHmqIsNfXhxJAozzBCMsbfdpESVFYQNzRWWuuBigpomgkLbFyBfobELQ");
    bool UzEgngqaDWQIh = true;

    if (fdjdTORBzdIpRD < 206829640) {
        for (int qXOqrYpIWDeun = 1414941047; qXOqrYpIWDeun > 0; qXOqrYpIWDeun--) {
            pJTFtuSbUCf /= qEjRVfnwUmzfLC;
        }
    }

    for (int QDkZu = 986042537; QDkZu > 0; QDkZu--) {
        pJTFtuSbUCf += fdjdTORBzdIpRD;
        UzEgngqaDWQIh = zSAWZZjihZjYpC;
    }

    for (int LdUTYVsu = 211970126; LdUTYVsu > 0; LdUTYVsu--) {
        fdjdTORBzdIpRD -= hsXqoKPXmnTw;
        hsXqoKPXmnTw += pJTFtuSbUCf;
    }

    for (int TwPZnAHbGGt = 1577911107; TwPZnAHbGGt > 0; TwPZnAHbGGt--) {
        continue;
    }

    if (hMIPkdcuRsoyIO != 954169675) {
        for (int yqAgtnhAdgZgAhNB = 504926072; yqAgtnhAdgZgAhNB > 0; yqAgtnhAdgZgAhNB--) {
            continue;
        }
    }

    for (int ECLEjRiTXmRKT = 408763562; ECLEjRiTXmRKT > 0; ECLEjRiTXmRKT--) {
        qEjRVfnwUmzfLC -= qEjRVfnwUmzfLC;
        hMIPkdcuRsoyIO /= qEjRVfnwUmzfLC;
    }

    return vteDSxTN;
}

void IjqQKBvpyihIGa::SJDKjDDYo(bool HwoMzijaTtzxXzHD, bool GGkUeaLqMS)
{
    int FZvRHFOiZeYGvxV = -111340186;
    bool IbmXAyYUYedhoS = false;
    string anuej = string("UnMzLyvaYQJjGNoQeDuqlDnTniQzRTYusiEYITkpnvojFpcGiNEoWZDpIZEErHlKThczchdJWmVimmiTqkGukNheCiDh");
    int iOaZJDJ = -566624354;
    bool YAkRt = false;

    for (int HNYGgMyG = 1392959237; HNYGgMyG > 0; HNYGgMyG--) {
        IbmXAyYUYedhoS = ! YAkRt;
        FZvRHFOiZeYGvxV *= FZvRHFOiZeYGvxV;
        HwoMzijaTtzxXzHD = ! GGkUeaLqMS;
        HwoMzijaTtzxXzHD = HwoMzijaTtzxXzHD;
        GGkUeaLqMS = GGkUeaLqMS;
    }
}

void IjqQKBvpyihIGa::AEoKl(double IXGOIXvTMe, string YHwpaq)
{
    double xyhLGTicZPtabPJd = -265642.8940725242;
    double fNxrGBXWImWu = 802380.6523965531;
    string zgIteKLHErxl = string("HmmTWaZHuClhJiXdDQOavcvGHKeZABtgzNcxvQhLLoZjolqrVjQOqMrRrlZwifMEUurVgeJRLEvGBqgsnUDkGzIbVDmSszSCmISlHpxJvlEmBVpDexTCkZQQYgrsXGFnxXTgnuMfAvaRgBPrYLDIuqAIDuRljdfbmHBuzAuIFadWQDOLQXncZdWqAiFqYVXGaFvHKPiKAvzPguDprZVUrdDoyYaaXdGPJVgQndpIUYZHQOUH");
    int fGUDrBpOs = -111040772;
    double msZKcQwevtb = 296368.64698911767;
    int OKiujjNBnYd = -1434663394;
    double REREfdtCPzRSSAW = 331596.9090529442;
    string aXzWAnP = string("FPVsXQGZhPRlHmMWpsftvtdpaNRSrKMHFXkGuvzlmcGzhENfZioYFnTxgZQCqoTEoXsVYEwRPzkroltocqzWWwZlQGzmZIczRRYKfJgRBIJPYniWLSjemiRubs");
    bool ouWJKjRcOdhxXfe = false;

    if (xyhLGTicZPtabPJd > -265642.8940725242) {
        for (int OdcRnjg = 1599505019; OdcRnjg > 0; OdcRnjg--) {
            continue;
        }
    }

    for (int JKciTBluhd = 1872476334; JKciTBluhd > 0; JKciTBluhd--) {
        aXzWAnP = aXzWAnP;
    }

    if (zgIteKLHErxl < string("zVdthqxP")) {
        for (int dvWkHlzkqzL = 2010698922; dvWkHlzkqzL > 0; dvWkHlzkqzL--) {
            continue;
        }
    }
}

void IjqQKBvpyihIGa::qIgMdo()
{
    double asvknU = 795793.4725258283;
    double WIxxRsM = 533936.4774309819;
    int rVlkFbfxGQRbnWs = -1045411864;
    string XFJuWFLDCuapN = string("mhwFrkEMbVzVSdodPZQrZzKtxT");
    bool wdPJfRx = false;

    for (int kIYoJVOk = 1872781040; kIYoJVOk > 0; kIYoJVOk--) {
        asvknU /= asvknU;
    }
}

int IjqQKBvpyihIGa::IrnqJrQBmsFdY()
{
    int ueILPeQl = -332382844;
    string sBJMohvHWVOSNL = string("OlwvLKKVHmdeDffJgknxdYlYQhIymmxeJTfUDTxAbwQtJNVMoUzGKkwITAuuilumXaeAJnGhXHXsZSPNUnZiPGtbtmisIYxNWZPeFEvrgoHrpcjcBHFqYsthmEnhqcpcXJJrTqCQccCwXGwbyxythZJiDKqGcMAvNZysDzxjfTkzXtxsEPMUiwGlGJaejZuWDXGQuYIkC");
    bool SOySMHIs = false;
    string fXRxvdSnUsfwY = string("RBdlDhZBYNClYBLNLDqFnbcpWtyNlgpMOiwnsTDgdMRHnHmvCBXebxaVYaQSdthBQQVVSVvKAvnYrCnwksCbDyjBqvaMxTVTUoRLfjbkhKBnFRAPBnwAZArkQColVXMIvgwCptLCzgXwgmkeVDCgWkWtmqpsYWgReLczlahPxqOJnKAHrlFtwUADXgkZdAafBXAsCmjypMNThTZABiDLbXudFLurBqqjHhskfhpqvZtSZjNeGTtzzENaMNtzec");
    double NozqugGz = -811245.5491736928;
    double mIRcoXreNbc = 382256.47227788274;
    bool AdpGXTcsAHNTGFIw = false;

    if (ueILPeQl != -332382844) {
        for (int NVxgNNoDyk = 1320570363; NVxgNNoDyk > 0; NVxgNNoDyk--) {
            continue;
        }
    }

    if (ueILPeQl < -332382844) {
        for (int lVrhG = 1527142323; lVrhG > 0; lVrhG--) {
            SOySMHIs = AdpGXTcsAHNTGFIw;
        }
    }

    if (AdpGXTcsAHNTGFIw != false) {
        for (int DaAyR = 1498665170; DaAyR > 0; DaAyR--) {
            ueILPeQl -= ueILPeQl;
            sBJMohvHWVOSNL = sBJMohvHWVOSNL;
            fXRxvdSnUsfwY += sBJMohvHWVOSNL;
        }
    }

    if (sBJMohvHWVOSNL <= string("RBdlDhZBYNClYBLNLDqFnbcpWtyNlgpMOiwnsTDgdMRHnHmvCBXebxaVYaQSdthBQQVVSVvKAvnYrCnwksCbDyjBqvaMxTVTUoRLfjbkhKBnFRAPBnwAZArkQColVXMIvgwCptLCzgXwgmkeVDCgWkWtmqpsYWgReLczlahPxqOJnKAHrlFtwUADXgkZdAafBXAsCmjypMNThTZABiDLbXudFLurBqqjHhskfhpqvZtSZjNeGTtzzENaMNtzec")) {
        for (int sonpDs = 310843193; sonpDs > 0; sonpDs--) {
            continue;
        }
    }

    if (SOySMHIs != false) {
        for (int LqtCDnKlWKdfBq = 856789494; LqtCDnKlWKdfBq > 0; LqtCDnKlWKdfBq--) {
            continue;
        }
    }

    return ueILPeQl;
}

IjqQKBvpyihIGa::IjqQKBvpyihIGa()
{
    this->AjKsI();
    this->MIGbSqZR();
    this->pSGECXG(string("CxpCeJRaVSKDaxndyZHSQVUeeHCXHXgEAZiSpusFbNRsrRINvnTXvNrctIWOyHtuKjpCZjFbWwgIDaOtpYCTsCCqJgpbGOJyReWVteGDEFrFzgIaHMHRHyAjWtXlIgyImqRvUktZxpFhiarGHArzQQKMORkUmjrAdNrPThKfYJXbOVxmEfMLidxlQSfi"));
    this->GAsgdgW(559815.304997117, true);
    this->fFyeg(false, string("DKDbFtzKJAapGDqSskTYKnLerRJmnKymYWlHIwqVkwNpBZrQvGqDylaOSNCquRUKiIrzQPeEqoCmWqbWVsWihzJgQHSBsodgAbCMEZRiyKxNjvDKSwSSOtkacsntqtcSRZSTAewjrbBLGoyjbvdtOGaAHxTEvgk"), -488421.82077030116);
    this->wTNVlImqWC(-2609.4981115024857);
    this->bCemBjGNwGEpjX(-182673.74473545974, string("QRJcwqnthUHFgIJppsiwCmgvOWNwWARRYmmYWrpoczXHFHxoPtLikcopWWvNsjhUfrefhrzbGDrNCtXZAngBDqezWmrJqIneJdkJAscwRFfKiMiCHNOOgaItUhCAXVaWQxgFQeRrVrjOMCgSKvoFwXwgQBRjFyHNyeNIEYNiRGBCTfQwYwUDYaAtqgXklelUGlaaGTUwmITugaLfsIwhuQqVfwQ"), 449614.56660463015);
    this->GkLPbvjxiQwK(string("LqhRjpEKLLbFSaQbbFZRLHISfEBOaDVIrnophxumNSfhxumpQlwmThprxJGgHCbhJHqDDMcmbZsqVQVtpatNIedRAoTDmXOGXAWsgvXiMvqekjkASCFwGQscyVtgALAtnxvYUJzHUAkUmByHZfdMQfXwKqk"), 2040613751);
    this->SJDKjDDYo(false, true);
    this->AEoKl(715031.2421031407, string("zVdthqxP"));
    this->qIgMdo();
    this->IrnqJrQBmsFdY();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uzhZIg
{
public:
    int HkOCnUhtputfYOg;

    uzhZIg();
protected:
    double TDDuVqtXCf;
    double JktnHgs;

    bool YoboZzFRN();
    void muHapmaPqznPon(double GzVktzES, int bsJGCQ, int gJqgfqXotJLVS);
private:
    int JbCBtXLu;
    string nvnChABW;
    string vuEiQRMCyzpqU;
    bool YbrhxXul;
    bool VtNsXccCmyMACYV;

    bool KEKUx(double zfFRWF);
    int QrSjxRovRpVKHq(int YuwiXNRkw, int XypLSZPSwlP, bool yULRdiNzO, int bPcOvuDjVo, int mNeOPHicGrQqmPHX);
    void qjauaHZZ(int aMTWXVLC);
    int NVeWWT();
    string KzytqmMDktSQY(bool MwPHggHf, bool jeOICCOWMge, int jCNNCLAOtgLedrG, bool iZAiBzUHNlcJWD, string doaQtyPejQ);
};

bool uzhZIg::YoboZzFRN()
{
    double StxAYDfCHuOfVPq = 794144.3039942457;
    bool FqFaSmZRR = true;

    for (int JhMcykF = 935131634; JhMcykF > 0; JhMcykF--) {
        StxAYDfCHuOfVPq /= StxAYDfCHuOfVPq;
        StxAYDfCHuOfVPq -= StxAYDfCHuOfVPq;
        FqFaSmZRR = FqFaSmZRR;
    }

    for (int aIwST = 1350384361; aIwST > 0; aIwST--) {
        StxAYDfCHuOfVPq *= StxAYDfCHuOfVPq;
        StxAYDfCHuOfVPq /= StxAYDfCHuOfVPq;
        FqFaSmZRR = FqFaSmZRR;
        StxAYDfCHuOfVPq = StxAYDfCHuOfVPq;
        FqFaSmZRR = ! FqFaSmZRR;
    }

    if (FqFaSmZRR == true) {
        for (int dAsySjIx = 240087080; dAsySjIx > 0; dAsySjIx--) {
            FqFaSmZRR = ! FqFaSmZRR;
        }
    }

    return FqFaSmZRR;
}

void uzhZIg::muHapmaPqznPon(double GzVktzES, int bsJGCQ, int gJqgfqXotJLVS)
{
    string QacYeIJJ = string("UeZEgWoPkjxSNIuinocpxJImREFJqjhqpPbCDbaFksyPGgfoPScyMaaACLczHDQENjJxllonPWihpluZYlnRxTeIRdLWXWNMXluYsxts");
    string GONgiPeT = string("ztvobjeQOsnKOqtmCTlbNIkjEqTrkxYcbkncNIJmrrtpjkzQcDQykdYynbH");
    int cUVCKvlogIBZn = 1080311651;
    double AvkiyUOA = 792722.5061752863;
}

bool uzhZIg::KEKUx(double zfFRWF)
{
    bool pXwjEXVoKXC = true;
    string EIDsToWPSBsspq = string("NPNrezYIHNNrTwGitqfFUoXpvJednOwtDGvYQEJIwPxVeuhCOKEOHdSZaFbJveDcCTSEjpPDMQGQgrTslmYjKVRQIiGDOUoaJPxTnvyWIQmbucDKiaktqYyXfUlVkHBkRUbmEnvrjMlEwdBHtjMudWiPF");
    int etMPqz = 747743731;
    double hWzpnxP = -192281.6076509412;
    int EEXjt = 703166677;

    for (int lsXRcBWMLsnZWk = 1154840243; lsXRcBWMLsnZWk > 0; lsXRcBWMLsnZWk--) {
        continue;
    }

    for (int ymfmKOCga = 722869206; ymfmKOCga > 0; ymfmKOCga--) {
        zfFRWF -= zfFRWF;
        EIDsToWPSBsspq = EIDsToWPSBsspq;
        etMPqz = EEXjt;
    }

    return pXwjEXVoKXC;
}

int uzhZIg::QrSjxRovRpVKHq(int YuwiXNRkw, int XypLSZPSwlP, bool yULRdiNzO, int bPcOvuDjVo, int mNeOPHicGrQqmPHX)
{
    string fyEfxJus = string("ZauGhvdQphCdvK");
    int uovKZEGElHYpSKGF = 572309449;
    bool PECxqsfxEeittqn = true;
    int ZvWZatfcgoqDL = 1936889929;
    string HBPtBqUWr = string("BOVcBWDCbUADvZYqDUNePOqGIyrSVcswaEblutEbwlupPvQwfXgcVGoKPgcNzFSDTOlxKPEdZZugCxWJzBcRNPwWTIjrBCjpVYsoVXTwZOVgLoobwDRlzEzWkOAcEIXbMpsZZyYrbAolcrnrtVlfoKMkDCMkdTEBPLUHBKCShyeMgjjIXDRyhBYWzhhaWBNMSaQSdHrsxMMdjmHmoOOqenrpDVJcWsPWJyCIEZOKrbDCjHcwRMRlBgWWqOL");
    double reSapvDrGohyUY = -617526.4409562465;

    for (int DbSdNv = 217373140; DbSdNv > 0; DbSdNv--) {
        XypLSZPSwlP = mNeOPHicGrQqmPHX;
    }

    return ZvWZatfcgoqDL;
}

void uzhZIg::qjauaHZZ(int aMTWXVLC)
{
    bool PbkdXkRNzIbD = false;
    double AMhTCtVebjidD = 1033292.5929861258;
    double FRwTHHRTBURrZWWm = -774287.0958690626;
    double jrlLJfm = 283924.13749475585;
    string sZEGUhcVEUjqYzOL = string("nijzMfpcpHNrjBFyPrDsosVNDbiGOqJwwlVkNnSgZWlAMZvHjFcyYltsrlUgUsewpdgIYrTRfgnGGmXUMUZJaIukyTjZ");
    string hMkvABDyoDvvz = string("vuQRnlgMNFTPxRFZcVpwwUxJqBAsdmMlVivMSqhRZFATBlBmDBFjZNVYVYWAwfCaNIImOswEvbJEDjArImJeyxuhtlWtEufMemlQoFvbUYqauXNEONiUMcZwYAOtWhspQzTRgXzABYKQJgbUzeewGTuCGuFiHVyjJPNipuEQfuSLCthWeSDYwxKTNfHaDbrTroMfDuepujkUbzPfSMVOnjeTTbEZQygBBxiftzKYcAoevVVfmIyDy");

    for (int TgYvSAhzRdC = 1804099154; TgYvSAhzRdC > 0; TgYvSAhzRdC--) {
        sZEGUhcVEUjqYzOL = sZEGUhcVEUjqYzOL;
    }

    for (int KacuTGQteMAhEomv = 458699050; KacuTGQteMAhEomv > 0; KacuTGQteMAhEomv--) {
        sZEGUhcVEUjqYzOL = hMkvABDyoDvvz;
        AMhTCtVebjidD /= AMhTCtVebjidD;
        aMTWXVLC += aMTWXVLC;
    }

    if (jrlLJfm >= -774287.0958690626) {
        for (int rlrxUGuoTAoHLuIL = 981131147; rlrxUGuoTAoHLuIL > 0; rlrxUGuoTAoHLuIL--) {
            continue;
        }
    }

    if (AMhTCtVebjidD > -774287.0958690626) {
        for (int QHxShYTEbL = 1410813010; QHxShYTEbL > 0; QHxShYTEbL--) {
            AMhTCtVebjidD -= jrlLJfm;
            FRwTHHRTBURrZWWm /= jrlLJfm;
            jrlLJfm -= FRwTHHRTBURrZWWm;
        }
    }
}

int uzhZIg::NVeWWT()
{
    bool BbKzBhozIYsz = true;
    bool cYxmqqZGOYBvHqoC = false;
    int ipYwdJKmuAaya = 489065284;
    double xQNpACoPcgv = -155591.4963392616;

    for (int dnKMVRwbWzAnzj = 741136754; dnKMVRwbWzAnzj > 0; dnKMVRwbWzAnzj--) {
        BbKzBhozIYsz = ! BbKzBhozIYsz;
        xQNpACoPcgv -= xQNpACoPcgv;
        cYxmqqZGOYBvHqoC = BbKzBhozIYsz;
    }

    return ipYwdJKmuAaya;
}

string uzhZIg::KzytqmMDktSQY(bool MwPHggHf, bool jeOICCOWMge, int jCNNCLAOtgLedrG, bool iZAiBzUHNlcJWD, string doaQtyPejQ)
{
    bool QDQoXHrpcN = false;
    double qCDaFRD = 750645.8194290658;
    double XiUrfiLKKCmlqBP = 445779.36685768276;
    bool byQfqt = false;
    int mSuMDSIdzKz = 22888614;
    bool MGDgg = true;
    double VKDKu = -25548.01938108657;
    bool hlaWdxOEzIZBM = true;

    for (int xOALoUmGPxdg = 2081259729; xOALoUmGPxdg > 0; xOALoUmGPxdg--) {
        jeOICCOWMge = ! hlaWdxOEzIZBM;
        MwPHggHf = ! jeOICCOWMge;
        mSuMDSIdzKz = mSuMDSIdzKz;
    }

    return doaQtyPejQ;
}

uzhZIg::uzhZIg()
{
    this->YoboZzFRN();
    this->muHapmaPqznPon(874633.6686959905, -32650475, 1330140720);
    this->KEKUx(236607.7122506701);
    this->QrSjxRovRpVKHq(-424593418, -769703610, true, -59833325, -1259521317);
    this->qjauaHZZ(1447411089);
    this->NVeWWT();
    this->KzytqmMDktSQY(true, true, -19265858, false, string("hmtZitBGwDBHzMdPmGXQrmMkNXxcTBAmbPYxZXLkudPJyIonoAIvjZfxDDZYIHQcXLzIsRttQTSMTLILomTfOsvTUjlBCinVKBFaHWUFNihxIFZFN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yoZObSDYPj
{
public:
    int fgBlLBnIS;

    yoZObSDYPj();
    bool GhPZwDZAmgni(bool VlQCQpVFtfXw);
    int hwnYDt(int gcCvrJCOfGtGhYIH, int YYKwnJBxlHgPyXY, int PWRJxQ, double ZxWMsPJFa);
    double QYjzWHNAR(bool uoonaSanAXQ, string GHyTAPgFZ, bool hHQFOjuunkZ, double mIlMKbPyl, int kNuFOL);
    string OfjNMOJLvuT(bool gDmTRKyENLrpN, double lKDtAuA, double mMMEONe, int kxqelza);
    bool PXdKWmaFKl(double GGPOyB, double xNfZNFYkMEA, int ZyoDoN);
    bool jKKWnCNEszuubZ(string gEAZkopKgEnw, int vlMWGw);
    double vlqVrS(int xhDsxXniJMpMC, double vPrrgawPf, bool llPDTmPGlBsc, int YwVpJNLfCYQpMwE);
    void WAiBLiqWWqlxXi(int gMYkuYwfRux);
protected:
    string YlsXGSddkuultZ;
    string QHAmKc;
    double SmgdbPLsrLdcU;
    double TRxpE;
    int hQTSvDLZ;

private:
    int rMwxzzkskAXzI;
    int RiywigPTZZ;
    string DqhcvE;
    int ttvggd;
    bool vGHMtdwAqbtZCHJ;

    int fipbXVGMeZcCY(int ZockJYHHvcrxWwa, bool xMHtuyKtLY, double EsArgNOuOOtNfy);
};

bool yoZObSDYPj::GhPZwDZAmgni(bool VlQCQpVFtfXw)
{
    int YBbTDYPuoH = 1938616992;
    double rcdOCrKcfjKm = -448150.545314929;
    int PQJzuC = 58535096;

    return VlQCQpVFtfXw;
}

int yoZObSDYPj::hwnYDt(int gcCvrJCOfGtGhYIH, int YYKwnJBxlHgPyXY, int PWRJxQ, double ZxWMsPJFa)
{
    string nRQpfUI = string("DdwvxkalyoWMBykuxBRHtWNeLIpKmBNOWGP");
    int oVaplStxDC = 770903674;

    for (int ikiju = 1865305125; ikiju > 0; ikiju--) {
        ZxWMsPJFa *= ZxWMsPJFa;
        ZxWMsPJFa *= ZxWMsPJFa;
        gcCvrJCOfGtGhYIH -= gcCvrJCOfGtGhYIH;
        nRQpfUI = nRQpfUI;
        gcCvrJCOfGtGhYIH = PWRJxQ;
        gcCvrJCOfGtGhYIH = PWRJxQ;
    }

    for (int NQUYPnjLUGWDtFK = 1495596923; NQUYPnjLUGWDtFK > 0; NQUYPnjLUGWDtFK--) {
        continue;
    }

    return oVaplStxDC;
}

double yoZObSDYPj::QYjzWHNAR(bool uoonaSanAXQ, string GHyTAPgFZ, bool hHQFOjuunkZ, double mIlMKbPyl, int kNuFOL)
{
    bool REnLBbgskAHeTA = false;
    double kdycTGlIEYcQiCz = -522001.61648574105;
    int wspABaIH = 1249885826;

    for (int qttqGAZSKIrM = 1606948146; qttqGAZSKIrM > 0; qttqGAZSKIrM--) {
        uoonaSanAXQ = REnLBbgskAHeTA;
        kdycTGlIEYcQiCz = mIlMKbPyl;
    }

    if (REnLBbgskAHeTA != false) {
        for (int oemdBbnqmYdBE = 1515890780; oemdBbnqmYdBE > 0; oemdBbnqmYdBE--) {
            hHQFOjuunkZ = ! REnLBbgskAHeTA;
            REnLBbgskAHeTA = hHQFOjuunkZ;
        }
    }

    if (mIlMKbPyl >= -522001.61648574105) {
        for (int HZUBoThfW = 1711908986; HZUBoThfW > 0; HZUBoThfW--) {
            REnLBbgskAHeTA = ! hHQFOjuunkZ;
            uoonaSanAXQ = hHQFOjuunkZ;
            hHQFOjuunkZ = hHQFOjuunkZ;
        }
    }

    return kdycTGlIEYcQiCz;
}

string yoZObSDYPj::OfjNMOJLvuT(bool gDmTRKyENLrpN, double lKDtAuA, double mMMEONe, int kxqelza)
{
    int eueGldJ = 2067013169;
    int WaBiSmTBTuZTVEn = 727965216;
    int HkOoqawNv = 1109172755;
    string pcXVCZpQ = string("KFmamPWIxjpBLwgDeMbcEKZYyjkvlTbnCUKgKbPcTxMhNYuFkIXumohtMbkFAtEGlfEUFiyvgXeWBrrnQrFOoAwLXMjXsCTGuslRSIPTDlZXsvkLoENGleOLFxiHFqAkpmVjspGVrAEzERrMzwkJIuYanzESXXFYsQAkShMsOYBscsdOsPyClRdQJoYXGQMEHeEaIWsTYHfPtMseOiLvPAj");
    string bicikIRUZr = string("YGFFDrOeSsEoFkr");
    string DsjaZOXTu = string("WNXnJrxBImaGmOfJaZiWcjtEDxGkxILbgzePloIilutghAysntjMSLhUdsjCzTxFnuUrHCIxoFdGnlQzrmeVemOVosXUmpUdmvERmDCzHckDCULpWoafqrZLrgWEMANGjYWGYhhYXtiwokcsRWTkMKSVPocFNbSydcH");
    double ZqHlGpqjq = -821180.9993019867;
    int gfuvAoKHGb = -1853828004;
    string BswvyEIrTPZ = string("SLzaQXNkrdAZOgyzVWIdPVYfrVvAMFzemFHmf");
    bool RzISlffXTDGOAQjz = true;

    for (int iVgHdVMLrC = 1193787361; iVgHdVMLrC > 0; iVgHdVMLrC--) {
        lKDtAuA -= mMMEONe;
    }

    for (int PvRCAUG = 1783688417; PvRCAUG > 0; PvRCAUG--) {
        gfuvAoKHGb -= WaBiSmTBTuZTVEn;
        RzISlffXTDGOAQjz = RzISlffXTDGOAQjz;
    }

    if (pcXVCZpQ <= string("WNXnJrxBImaGmOfJaZiWcjtEDxGkxILbgzePloIilutghAysntjMSLhUdsjCzTxFnuUrHCIxoFdGnlQzrmeVemOVosXUmpUdmvERmDCzHckDCULpWoafqrZLrgWEMANGjYWGYhhYXtiwokcsRWTkMKSVPocFNbSydcH")) {
        for (int neNYzqPUyD = 716710600; neNYzqPUyD > 0; neNYzqPUyD--) {
            mMMEONe = ZqHlGpqjq;
            eueGldJ -= eueGldJ;
            gfuvAoKHGb /= eueGldJ;
        }
    }

    for (int ZZuUDJCKBxvDT = 1806718482; ZZuUDJCKBxvDT > 0; ZZuUDJCKBxvDT--) {
        continue;
    }

    for (int VsKReog = 192270201; VsKReog > 0; VsKReog--) {
        HkOoqawNv /= kxqelza;
        WaBiSmTBTuZTVEn += gfuvAoKHGb;
        gDmTRKyENLrpN = gDmTRKyENLrpN;
    }

    return BswvyEIrTPZ;
}

bool yoZObSDYPj::PXdKWmaFKl(double GGPOyB, double xNfZNFYkMEA, int ZyoDoN)
{
    int FKYCbNd = -765804384;
    double PNNTXUUXlgQYlWR = 310416.9847208324;
    double YKUmBfaNijRJRvh = 614705.4918012191;
    bool OikMcBoIt = true;
    double rnKOZNAtdDrse = -822788.2728178765;
    int xVxoo = -1683650663;
    double uoJIonT = -489718.76413372334;

    if (GGPOyB > 310416.9847208324) {
        for (int iItHGSRjm = 112300349; iItHGSRjm > 0; iItHGSRjm--) {
            OikMcBoIt = ! OikMcBoIt;
            uoJIonT += YKUmBfaNijRJRvh;
        }
    }

    return OikMcBoIt;
}

bool yoZObSDYPj::jKKWnCNEszuubZ(string gEAZkopKgEnw, int vlMWGw)
{
    string FzzauWvjw = string("LPbgdVDMFmILSVLoyOcNGWjXCASDCuXtuVMMnammksvIMHehtaVdxHIunhgMeryXomTIFgGijNzDxVAgfNHedoPzszUXkkHCxXHAAHEskzpUZhOBuCyDpaFEhMRlwFhmjzuqOzMVqpBvIBinCEAGhxldlobzNVclZNgQKYEvownjCgAQzQlZwmIGObLibkAAwxIMiQkUqUgVUoAzpgnugwmieUlqWYTnoBqblCrBnSjwyUNioXItRAIs");

    for (int BUncrV = 986134994; BUncrV > 0; BUncrV--) {
        vlMWGw = vlMWGw;
        FzzauWvjw = FzzauWvjw;
    }

    if (FzzauWvjw == string("LPbgdVDMFmILSVLoyOcNGWjXCASDCuXtuVMMnammksvIMHehtaVdxHIunhgMeryXomTIFgGijNzDxVAgfNHedoPzszUXkkHCxXHAAHEskzpUZhOBuCyDpaFEhMRlwFhmjzuqOzMVqpBvIBinCEAGhxldlobzNVclZNgQKYEvownjCgAQzQlZwmIGObLibkAAwxIMiQkUqUgVUoAzpgnugwmieUlqWYTnoBqblCrBnSjwyUNioXItRAIs")) {
        for (int bgOzOkMSTIEadqFL = 90776833; bgOzOkMSTIEadqFL > 0; bgOzOkMSTIEadqFL--) {
            continue;
        }
    }

    if (gEAZkopKgEnw > string("IPSnDWZwfQEYpduGyYmwxqpfdZuoazyvP")) {
        for (int YKawBky = 1982166953; YKawBky > 0; YKawBky--) {
            gEAZkopKgEnw += FzzauWvjw;
            FzzauWvjw = gEAZkopKgEnw;
        }
    }

    for (int LdGQLWtLFYkBlmy = 969696854; LdGQLWtLFYkBlmy > 0; LdGQLWtLFYkBlmy--) {
        FzzauWvjw += FzzauWvjw;
        FzzauWvjw += gEAZkopKgEnw;
        FzzauWvjw += FzzauWvjw;
        FzzauWvjw = FzzauWvjw;
        gEAZkopKgEnw = FzzauWvjw;
        gEAZkopKgEnw += FzzauWvjw;
    }

    return true;
}

double yoZObSDYPj::vlqVrS(int xhDsxXniJMpMC, double vPrrgawPf, bool llPDTmPGlBsc, int YwVpJNLfCYQpMwE)
{
    int FJTIT = 210096021;
    int DLrouw = 1411012690;
    string hpYzU = string("TZwtQBwqzZVZLmbfBskJAHMoxAzjazCrAwaiIlPXokvMElMgCKYNwKyrPPxsCjbcFvdGuJgpvUQdWCnmRkgbSOQdRSKUOYHqgwwhgRtFKUDrBFUnKZFmEfEGvjmtsSUFOItrpjPdmiQUdPOeeWvTnEmdSvHBuTPtgTAELTVXtgaTzsFtBlSwcK");
    string DfcYWbELd = string("cU");

    for (int VCGyiDhozT = 335122631; VCGyiDhozT > 0; VCGyiDhozT--) {
        FJTIT /= FJTIT;
        DLrouw *= FJTIT;
        FJTIT *= YwVpJNLfCYQpMwE;
    }

    for (int eGvJCFF = 2095199069; eGvJCFF > 0; eGvJCFF--) {
        llPDTmPGlBsc = ! llPDTmPGlBsc;
        YwVpJNLfCYQpMwE *= xhDsxXniJMpMC;
        hpYzU = hpYzU;
    }

    for (int uWEoCl = 141514447; uWEoCl > 0; uWEoCl--) {
        hpYzU = DfcYWbELd;
        xhDsxXniJMpMC += FJTIT;
        YwVpJNLfCYQpMwE -= YwVpJNLfCYQpMwE;
    }

    return vPrrgawPf;
}

void yoZObSDYPj::WAiBLiqWWqlxXi(int gMYkuYwfRux)
{
    int jEEaVXLs = 1863790582;
    bool gxDkUoaxLdDTWvYs = true;
    string yyjJzIIkNxyQhMw = string("ZVPsBjVymuQSCldrnVPQdHFlWtijcSvulgJRLatVoygbUHPDRoboczURHHgRXJNKlrjRaoHnjyRISZdfHfdYRfNxvJYriDeZsymWZrXhWDRlHsmqyssCGyKYlqumQbXKqkGhENMnVJLLuEDIUNWzTmNClkRwhPjdMMsVnqQZiTxGavJQBwoTPEi");
    bool dzGOekUriv = true;
    double IYzgAC = 540155.4458427647;
    int cgVvVQXLoR = 2142366344;
    double ERfQndWCZX = -980849.6676495873;
    string QcaTrYUiZunG = string("ktYvlTfOkgMLdZIIPRHDrjNpCtVDBPPoAIoDqIMiZzWsyfeBYXjuExubitEWnZIypxCvaiRitnuIJiCSTFMWFhetKuklxmJyMpADcnYXDSOjUsQCtP");
    int XxRHZACOgz = 693150418;
    double YXeWet = 303796.20344533277;

    if (XxRHZACOgz != -1695015607) {
        for (int gICGgsBDeBSQDrwR = 1974030053; gICGgsBDeBSQDrwR > 0; gICGgsBDeBSQDrwR--) {
            QcaTrYUiZunG = QcaTrYUiZunG;
        }
    }

    for (int yoYsgQlVzkWn = 1772314448; yoYsgQlVzkWn > 0; yoYsgQlVzkWn--) {
        gMYkuYwfRux *= cgVvVQXLoR;
    }

    if (IYzgAC < 303796.20344533277) {
        for (int ZdIgPznonMOXW = 806100157; ZdIgPznonMOXW > 0; ZdIgPznonMOXW--) {
            continue;
        }
    }
}

int yoZObSDYPj::fipbXVGMeZcCY(int ZockJYHHvcrxWwa, bool xMHtuyKtLY, double EsArgNOuOOtNfy)
{
    double LbTtkE = -75279.62069073429;

    if (EsArgNOuOOtNfy >= -75279.62069073429) {
        for (int dHDHxpL = 1590042899; dHDHxpL > 0; dHDHxpL--) {
            LbTtkE -= EsArgNOuOOtNfy;
            xMHtuyKtLY = xMHtuyKtLY;
        }
    }

    return ZockJYHHvcrxWwa;
}

yoZObSDYPj::yoZObSDYPj()
{
    this->GhPZwDZAmgni(true);
    this->hwnYDt(-226319968, -1007042007, -337257181, 774153.6490496739);
    this->QYjzWHNAR(false, string("FlZuFQbVWjcPyFotjomQabCWOjjQbPBHbRZBLKsmHGuhOrLjgpnqWsWJlwIqVjeAEFcpHebcwHePsqbbyIAwTQiwGWAVJOBnjSaKBetfxMlwknbNgGKyYyreFUjkKVygGpIznWefGZvVhcrUWEbkKoRFuYK"), true, 231556.36080522113, -1663291824);
    this->OfjNMOJLvuT(false, 891288.352924755, 34008.190469223584, -600343165);
    this->PXdKWmaFKl(602196.8328540523, 475444.38279173116, -1128170767);
    this->jKKWnCNEszuubZ(string("IPSnDWZwfQEYpduGyYmwxqpfdZuoazyvP"), 296105731);
    this->vlqVrS(341881469, 25515.530426468555, true, 633009076);
    this->WAiBLiqWWqlxXi(-1695015607);
    this->fipbXVGMeZcCY(-1202748182, false, 512098.3604305753);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nYmNm
{
public:
    double cRDRmwmcGkFBHZ;

    nYmNm();
    string aSlNk(double VXRmJcoipy, bool SvDdTjZqqXnTzm, int Neltk, int UcdpkPbmWU, double jPoqBGG);
    double tLmnrR(int wtBofdW, int xzKwvJvHD, bool SWPQmTqzdIegnB, bool nmaZuOhTFIG);
    double ZxnVRLBYHkBCb(bool LCwbwsqzOPhnL, int gAbgCNobGNaQukWU);
    void EksXWAEssz(string xbHLNbCKBuQuMi, double fRHcjHDwMiXpg, bool IpLXzEVTcQhr, double UkqOO, int FutjXyxlCy);
    string SdSUdaA();
    void GbzLkjqVaUgWlQ(double IlGlB, bool INYdcGzDn, bool cdkuAtvGE, string naLspiRA);
    bool AbrXHYh(int dVEsWOdqgcu, string PvGuKsyUvytLLmSM, double GbnMpOApuaPo);
protected:
    bool JCYfEpHJaU;
    string pAjeLvFiru;

    double xuNOZEOCzvh(string qQBhwCVGCkN, int xAdYSdBsJoW, int vRPTctugE, int dcllQd);
    void wFdEbhbKxWI(int eUMheFql);
    string mWyXSi(double qNMLhEJNQV, int hONbCXV);
    string YQFtSPoGuSHiFw(int FhBxP);
    int LsoYc(int pnaTMEA, double kFBFGbpG, int icjDdReuvBqVuYa, string HgmMSiejEP);
    bool JehTrrCFZlLEbV(int xibKazEvuToSmqEt);
    int SLahVvXRWdKHySfu(int ZjmDh, int nwLJbCqegn, int fshqKjcO, string ZuggFWuv);
private:
    string ESdUwFrBVQEv;
    int apiKLUknNB;
    string ITNaqsVoYYD;
    string CZPjXBJKwLUsdbx;

    double lCiDv(double pSxGieIwCpqaTl, bool vsYAb);
    int lAAjEtih(int xOLLNr);
    string zpgYbICUVKYCtQ();
    void tplCRGbbCCWrrJ(string kpfzZYOCnNaGkapH, bool jvonaOhdqowbF, double vCHypfkrbxMQIoN, string nQqsYvtyYePSP, bool gUGFnILxqYL);
    bool klaGIqPBTtF(double RsFTANJOibA, string osuysoL, bool NItyQqFALP);
};

string nYmNm::aSlNk(double VXRmJcoipy, bool SvDdTjZqqXnTzm, int Neltk, int UcdpkPbmWU, double jPoqBGG)
{
    double VZXvHUddgHifgSaJ = 86132.39473277907;
    bool OIvPGpHadzX = false;
    string xlBVYNyakYBUYB = string("OqelZtPyzRnCXAnBvZTkWuGEPUwKfYxwajwWEhNhsoaBLJaVeqmZtxrgRISgfGNDYzfWyWOMdiykNRYynizNsEKhxhuJGWqWXlBMvgwlJAoNqsJjjiIyxWNrgRbBRNJogkwfqaIyYtrteLfzIHFZGrghtKGQamOGZJQTkBgPtUBCuGTjGuRxjYeeXkYFGKmxdndCQCpEoYgHrWscEypcYxLxeLbOYuxtnMkVjsdhv");
    string UXWJxGoMxoi = string("IjZBvxnVhWbbCMEVvvUROXSAEImZGmXoyWADXvZcrHQKcCgOrLZIjoSMizmVOmnHcHQfWdWUUqoNnArQpsWvsDlIzTmcnZiCjhFEIqvbMIDKlZYTxToomnjLFPZinvmlpxneUsSfXZXBrXPUnuYkcSrPUyuwF");
    double UkUZVYeeSCEcI = 657397.5407131393;
    string RQnOsRiQkGYGyI = string("xwVYdwUYsrNRMpPYlyXHiXHhPT");
    double QVUNrKJCO = 568933.225986005;

    if (VXRmJcoipy <= -568421.7631552707) {
        for (int vuLiPJBCwBZTmk = 1109183142; vuLiPJBCwBZTmk > 0; vuLiPJBCwBZTmk--) {
            UkUZVYeeSCEcI *= VZXvHUddgHifgSaJ;
            VXRmJcoipy += jPoqBGG;
        }
    }

    for (int cEwEkvNy = 1520244534; cEwEkvNy > 0; cEwEkvNy--) {
        UkUZVYeeSCEcI *= VXRmJcoipy;
    }

    return RQnOsRiQkGYGyI;
}

double nYmNm::tLmnrR(int wtBofdW, int xzKwvJvHD, bool SWPQmTqzdIegnB, bool nmaZuOhTFIG)
{
    bool SJcILfF = true;
    int NqymXVNYhQLRm = -425132886;
    double RAVpDm = -482089.55221584183;
    double VyVXNo = -992643.5509434029;
    string bUhhbbrmhwCigz = string("wTlnqeOQdyyldgTX");
    bool WqiafUVUyRjI = false;

    for (int QdrZtUTuiG = 217905254; QdrZtUTuiG > 0; QdrZtUTuiG--) {
        bUhhbbrmhwCigz += bUhhbbrmhwCigz;
    }

    for (int oOrFLbVizCxnjH = 1348674986; oOrFLbVizCxnjH > 0; oOrFLbVizCxnjH--) {
        nmaZuOhTFIG = ! SJcILfF;
    }

    for (int muOGsmIYjbAtQUxj = 545145373; muOGsmIYjbAtQUxj > 0; muOGsmIYjbAtQUxj--) {
        SWPQmTqzdIegnB = ! nmaZuOhTFIG;
    }

    for (int ohUWfwygChvo = 1828060679; ohUWfwygChvo > 0; ohUWfwygChvo--) {
        xzKwvJvHD -= xzKwvJvHD;
    }

    return VyVXNo;
}

double nYmNm::ZxnVRLBYHkBCb(bool LCwbwsqzOPhnL, int gAbgCNobGNaQukWU)
{
    double KsFKTwkPYKOaDH = 190346.36491289517;
    double YoZpUOH = -143421.66198590898;
    int kXjDAYHvWLcLNSps = 1757603718;
    bool SigfXtRpQa = true;
    string yLtxL = string("GhnHItrpVeXPHSnYFrrsGdfcRMvLAdoUGPypynAvYZnVWVDdxpRCtGzzPgBdADctizizBLBNwdWWpWSlcnxQJXZjSVevUKHOSgbvRlcJAJVawU");
    string xhBEVK = string("OlIajeUFJCpruaJUWuCKZfLAJVQhTVlIPsnjbHEUNFACfwRVcCTnRlRzBiarxkXAMYZuGseiEtBhwaCmgPY");
    string nbGuWuwLGE = string("ESWBBgcPHIKhvVNrVbKMLMXOvpeMtUhJfddWWvzgiGAxlwCfqwszSkzQVBMSywXUNxPhmmXIkLPNtoopjOrVYYzXprTRTCqrBzAuoEmljszyiFGyrGIPxKHysCBhxMqoRFrwhRlbyxqnObhSqCwcoJfyWrRWTUPcMEgXzszEtlXhtqUwYJTrEyQtVzaNxTldvYbIiBYXsCwevzEKkOKhGYOUfcxdlOyLhbMDZYSrfTPnmV");

    for (int QcawVDsubz = 2089193266; QcawVDsubz > 0; QcawVDsubz--) {
        continue;
    }

    if (LCwbwsqzOPhnL == true) {
        for (int TRNLDDwFJyI = 517879339; TRNLDDwFJyI > 0; TRNLDDwFJyI--) {
            continue;
        }
    }

    if (SigfXtRpQa == true) {
        for (int PzinbTUkkQW = 628865636; PzinbTUkkQW > 0; PzinbTUkkQW--) {
            continue;
        }
    }

    for (int AbDyQozFsYU = 1384589564; AbDyQozFsYU > 0; AbDyQozFsYU--) {
        gAbgCNobGNaQukWU /= kXjDAYHvWLcLNSps;
        nbGuWuwLGE += xhBEVK;
    }

    for (int NjcAAYdSPZ = 473665362; NjcAAYdSPZ > 0; NjcAAYdSPZ--) {
        continue;
    }

    return YoZpUOH;
}

void nYmNm::EksXWAEssz(string xbHLNbCKBuQuMi, double fRHcjHDwMiXpg, bool IpLXzEVTcQhr, double UkqOO, int FutjXyxlCy)
{
    string uCxEWUkjjGMHX = string("IFyfBqkgqTWCJeGAkryngeflUqKSBUTABnQcbywFuroQEeNgXnZDGnNsZqlCiZUGPinTsrEoZACMBYgKOlJwOWSQKwWlwRkvpZKxesCfJLkSqlmCOqmiCorasknUGPvnmlfhdfhnJlpkamrWQjRTzNnppBLVPoZJWWKAXJkYqVUTmEDoxATosTmeOwziMkqrSJtbviimEbiYSOYdzNRBfTkKOjYjfbvHuzAPSgdJcaLCNnGUxcMUt");
    bool yOUiHmxsY = false;
    int QcbXA = 626624181;

    for (int xoVHkivsZL = 259793197; xoVHkivsZL > 0; xoVHkivsZL--) {
        yOUiHmxsY = ! IpLXzEVTcQhr;
    }

    for (int haZABsDX = 1151610462; haZABsDX > 0; haZABsDX--) {
        QcbXA /= FutjXyxlCy;
        FutjXyxlCy /= FutjXyxlCy;
    }

    for (int YagdlbppIPDCAhnA = 182923179; YagdlbppIPDCAhnA > 0; YagdlbppIPDCAhnA--) {
        continue;
    }
}

string nYmNm::SdSUdaA()
{
    double lsNIMH = -813776.439109475;
    double ZofGFXfyHtryBhiM = 455656.4811382819;
    int WsGlfwT = 1451269477;
    bool HEYLlFtj = true;
    bool qUwiSMwBEVDkaCD = false;
    string GCJJIywlqGEVbNg = string("TjZCmrAbywwHmEJsBQghFslMAisWFRPcqNxrFtuXwMjdKKsyFIUTKNCdBgdavLfQBqsnIaIFgwdwxduuCgcNOhYKrowgiTAeIzecvcILwKNtSzMZcXmDsdkiMUwKcEUgNKsBBvUKxVUqn");
    bool LaDeALYZeziPWaO = true;
    int lkwmEPhfQzK = 992236238;

    if (lkwmEPhfQzK >= 1451269477) {
        for (int frEKssdZuWOB = 258963748; frEKssdZuWOB > 0; frEKssdZuWOB--) {
            HEYLlFtj = LaDeALYZeziPWaO;
            qUwiSMwBEVDkaCD = HEYLlFtj;
        }
    }

    return GCJJIywlqGEVbNg;
}

void nYmNm::GbzLkjqVaUgWlQ(double IlGlB, bool INYdcGzDn, bool cdkuAtvGE, string naLspiRA)
{
    double ukqsLQEoosya = -593537.2012853774;
    bool zRVKmvaeETg = true;
    string dYlNTMCPKAcRJa = string("eQXVeNfUzGaRQuWSEHTyoHEgxnLkaKLBGdJjUPAHPajOf");
    int YkXBHLTwYaHlioL = 978412900;
    int ksaseJTaH = -360465566;

    for (int kkEMLtKbaDQKixKm = 817630854; kkEMLtKbaDQKixKm > 0; kkEMLtKbaDQKixKm--) {
        naLspiRA += dYlNTMCPKAcRJa;
        ksaseJTaH /= ksaseJTaH;
        dYlNTMCPKAcRJa = naLspiRA;
    }
}

bool nYmNm::AbrXHYh(int dVEsWOdqgcu, string PvGuKsyUvytLLmSM, double GbnMpOApuaPo)
{
    bool EtUkuZvOwqcnYV = false;
    string XhTsZUmXC = string("YaTfsPaVILBSLmyHAMxmPwEocIIG");
    bool FMcnuvCHG = false;
    int CelsvtFVkjcykmT = 615426004;
    bool EtaTLWw = false;

    for (int FhKKjeUZ = 1968370900; FhKKjeUZ > 0; FhKKjeUZ--) {
        EtaTLWw = ! EtaTLWw;
        EtaTLWw = ! EtUkuZvOwqcnYV;
        PvGuKsyUvytLLmSM += PvGuKsyUvytLLmSM;
        EtaTLWw = FMcnuvCHG;
    }

    if (FMcnuvCHG != false) {
        for (int zQspcejre = 953620765; zQspcejre > 0; zQspcejre--) {
            FMcnuvCHG = FMcnuvCHG;
        }
    }

    return EtaTLWw;
}

double nYmNm::xuNOZEOCzvh(string qQBhwCVGCkN, int xAdYSdBsJoW, int vRPTctugE, int dcllQd)
{
    double gjCOlucbUG = 1038209.898958891;
    double RFDPKrrA = -733570.7054484936;
    double hLkLlLyW = 583974.4439726865;
    int dhNNreBymW = -972354875;
    int DtZYx = -1589781319;
    int oifxiqwS = -1835036679;

    for (int nBwcUAm = 685495554; nBwcUAm > 0; nBwcUAm--) {
        hLkLlLyW = hLkLlLyW;
        RFDPKrrA /= hLkLlLyW;
        xAdYSdBsJoW /= xAdYSdBsJoW;
    }

    return hLkLlLyW;
}

void nYmNm::wFdEbhbKxWI(int eUMheFql)
{
    double enZWSZgU = 337588.6219618803;
    string yOdbVPUvI = string("yrMaagCslgnNVMYZYYSYqLtmNfsfhuCAcPmmepIUwOAzkuoHfLbkKOjkqwjVVFAjOZOuoowbhoTWuwSftzMHsHqpwVqbGgkGT");
    int osSzLFQGxzBpXs = 1032328078;
    bool VrCavsks = true;
    string aFVUZbeDaTffx = string("uTIpeqCGttEvypXRapbVbKbzkkVtUgGcUzvzUgacWSASSRUaSncPehKjUnuvRLAzQkZURaWaBHIoBpIEorpzOaGSNiHTqwKOMOTJJrozQvFM");

    if (osSzLFQGxzBpXs < 1032328078) {
        for (int hUKxenWObQj = 2075892921; hUKxenWObQj > 0; hUKxenWObQj--) {
            aFVUZbeDaTffx += aFVUZbeDaTffx;
            eUMheFql *= osSzLFQGxzBpXs;
        }
    }
}

string nYmNm::mWyXSi(double qNMLhEJNQV, int hONbCXV)
{
    int KIVTIIuOwAsvF = 562426338;
    double IpifVVXG = 397862.0312785671;
    double tvHbHcNdWt = 229717.88067731657;
    string hVoWfOUUaQNh = string("TylMvyDaPfItyPuzbcOmVwOZopACOeLYYZIwzlVfWVBaHOHAguzaN");
    int KNmKla = -1881545823;
    bool hFWttWNXx = true;
    double sVvXFRnfdnIKg = 869064.1931032015;
    double Mrkji = 972516.9698903312;

    return hVoWfOUUaQNh;
}

string nYmNm::YQFtSPoGuSHiFw(int FhBxP)
{
    double YiAwvl = 155342.9216602672;
    double sWwwyiv = -288663.03057270497;
    bool RKAiimvd = true;
    string qdxRMcYwxybIkVpP = string("YLAfshjUYpKQdXSmCHHFBXArOxBmxIJqWjpueoNJPBopXDSvf");

    for (int RCUcrnTAu = 949489143; RCUcrnTAu > 0; RCUcrnTAu--) {
        continue;
    }

    for (int weFSChBsNfV = 1917375496; weFSChBsNfV > 0; weFSChBsNfV--) {
        sWwwyiv += YiAwvl;
        sWwwyiv *= YiAwvl;
        RKAiimvd = RKAiimvd;
    }

    for (int HeAzkXI = 1753053118; HeAzkXI > 0; HeAzkXI--) {
        continue;
    }

    return qdxRMcYwxybIkVpP;
}

int nYmNm::LsoYc(int pnaTMEA, double kFBFGbpG, int icjDdReuvBqVuYa, string HgmMSiejEP)
{
    bool croCosAQYey = true;
    double FKxeEZZzzZRTbR = 461466.6411346917;
    string JGMvqd = string("dJwtQtWlekHMLRhxOErrDUyaLZpwYpfqNzCIahRdFIsfSwRJykHkBNbmQvlWvuzDCDGBfJsWDqoWnjVvlyQjOhZFWrqWiritcoDcuPIHqqKtinNGDmiDSxyvVarljUhHTXTjWSJGlXhMtVMkyMkcePHeWCpHRmqeVWxXKLlhsldPWNtnyMCbSCDyTfLEtqxWeJtPsKWQzZDORxyrxvEOPCjsgtkVqxSgUSCXeM");
    bool BzmYl = false;
    double QxSrISLDsA = -983597.2041332202;
    bool poOdYZBNjUWvXY = false;

    for (int LLCTEwGgg = 938267224; LLCTEwGgg > 0; LLCTEwGgg--) {
        continue;
    }

    for (int UWamiKZEugOrIN = 1969233755; UWamiKZEugOrIN > 0; UWamiKZEugOrIN--) {
        BzmYl = croCosAQYey;
    }

    return icjDdReuvBqVuYa;
}

bool nYmNm::JehTrrCFZlLEbV(int xibKazEvuToSmqEt)
{
    double uApmfezHUT = -137201.57799070203;
    double dUMkZDtfsa = -546972.8911916692;
    double gAROycfUmdIVsegS = -759717.7374441075;
    int rOPmyPdkaXiUS = 165290519;
    bool dehHnskx = true;

    for (int fMnKEvKatoCtCxt = 973830512; fMnKEvKatoCtCxt > 0; fMnKEvKatoCtCxt--) {
        gAROycfUmdIVsegS = gAROycfUmdIVsegS;
        xibKazEvuToSmqEt = xibKazEvuToSmqEt;
        uApmfezHUT /= dUMkZDtfsa;
    }

    if (dUMkZDtfsa > -759717.7374441075) {
        for (int nrBPhYwrk = 1148174394; nrBPhYwrk > 0; nrBPhYwrk--) {
            dehHnskx = dehHnskx;
            uApmfezHUT /= dUMkZDtfsa;
            dUMkZDtfsa *= uApmfezHUT;
            gAROycfUmdIVsegS = dUMkZDtfsa;
        }
    }

    for (int WRHbRO = 1308236617; WRHbRO > 0; WRHbRO--) {
        continue;
    }

    return dehHnskx;
}

int nYmNm::SLahVvXRWdKHySfu(int ZjmDh, int nwLJbCqegn, int fshqKjcO, string ZuggFWuv)
{
    string qFPhwcYvcyHGHXl = string("VbIkZjRprtJnCHtpxMKdgZySdfyoHauyITWOVXGslymAKRfmmjBfLvPRidzyvjoMXlAeJGNgBPAtAFcvKdsINgBNsdwrZiNxPMhbD");
    int ibBVxzWMbpxy = -800535195;
    string gTYSwcIxH = string("CobOcjyedDSbjLfexhaJbqcXvAR");
    double ImitrkBJVpEfi = -34374.085279739025;
    int ZgtwpKUBnEBQ = 1318118459;
    int HrYXKSoyD = -237442479;
    bool BTTCqd = true;
    bool czvTsGVfSkG = true;
    bool OczYEshaxdGiO = false;

    if (HrYXKSoyD == -598840863) {
        for (int QXYOBjcUrVquCQWk = 311484388; QXYOBjcUrVquCQWk > 0; QXYOBjcUrVquCQWk--) {
            ibBVxzWMbpxy -= nwLJbCqegn;
            ibBVxzWMbpxy -= ibBVxzWMbpxy;
            ZgtwpKUBnEBQ /= nwLJbCqegn;
        }
    }

    if (ibBVxzWMbpxy < 1318118459) {
        for (int zwOQZwgrAwPKgn = 1572689051; zwOQZwgrAwPKgn > 0; zwOQZwgrAwPKgn--) {
            HrYXKSoyD -= ZjmDh;
            OczYEshaxdGiO = ! BTTCqd;
            ZgtwpKUBnEBQ *= ZgtwpKUBnEBQ;
        }
    }

    for (int lUMGnPGYnPzZfQoA = 637889019; lUMGnPGYnPzZfQoA > 0; lUMGnPGYnPzZfQoA--) {
        ZjmDh -= ZjmDh;
        BTTCqd = BTTCqd;
        nwLJbCqegn -= ibBVxzWMbpxy;
        ZuggFWuv += gTYSwcIxH;
    }

    if (ZgtwpKUBnEBQ != -800535195) {
        for (int kBabekN = 2145924597; kBabekN > 0; kBabekN--) {
            gTYSwcIxH = qFPhwcYvcyHGHXl;
        }
    }

    return HrYXKSoyD;
}

double nYmNm::lCiDv(double pSxGieIwCpqaTl, bool vsYAb)
{
    bool NycfGAoXnhiiYq = false;
    bool OayXpsOJmLC = true;

    if (OayXpsOJmLC == false) {
        for (int GVTLRZwkO = 1565633364; GVTLRZwkO > 0; GVTLRZwkO--) {
            vsYAb = ! OayXpsOJmLC;
        }
    }

    for (int kdgEitaW = 2132032485; kdgEitaW > 0; kdgEitaW--) {
        OayXpsOJmLC = vsYAb;
        OayXpsOJmLC = ! NycfGAoXnhiiYq;
        NycfGAoXnhiiYq = ! OayXpsOJmLC;
        vsYAb = NycfGAoXnhiiYq;
        pSxGieIwCpqaTl *= pSxGieIwCpqaTl;
        OayXpsOJmLC = NycfGAoXnhiiYq;
        NycfGAoXnhiiYq = OayXpsOJmLC;
    }

    return pSxGieIwCpqaTl;
}

int nYmNm::lAAjEtih(int xOLLNr)
{
    int cyxAiEJrXWNZH = 476217441;
    double BKTAQHVYKlkqs = 55654.18029370852;
    string wuQDGRV = string("nBxKlAChqKorzYLflvmoEJHZXRhmNobJEkUZSjEONwOVWDXDyfCRWiJbnHaIxommvcwqUzTcr");
    double rZRBgIXrHH = 17430.35875022118;
    int odqaJFVEPz = 1754857129;
    string aUjXYbFEofHOV = string("SfomVHrCPdIPCCMuodAIfDeFWsmfCRbPlnUHUFbUauRUANjgblMoIkjTwdqJXMimDLGfayMlTlvmbLwwwUfEOlrUwxQDOyxRWixPWgHyZvENoFevsbNclGQWHKzQhiEvuhwIRSGaSuXqAJISfYttAWAzoIRnmyWML");
    int UDQccqg = 1899908366;
    double wvhSAzvf = 614378.1255643093;

    if (rZRBgIXrHH == 17430.35875022118) {
        for (int JvDRQgiakhNaUb = 1631278786; JvDRQgiakhNaUb > 0; JvDRQgiakhNaUb--) {
            BKTAQHVYKlkqs -= rZRBgIXrHH;
            odqaJFVEPz *= xOLLNr;
            odqaJFVEPz *= xOLLNr;
        }
    }

    return UDQccqg;
}

string nYmNm::zpgYbICUVKYCtQ()
{
    string EaAsqYjPUtmQSbR = string("OOdhESYelthHZuwIStmPBInXENeMrKWRxqqLgrrBAnDlAQpKxvwztfTGVTIEfKloWqiiPYolrxwrWlYAjoSyLJcERMsEybzDYrCaquwwnJvUCuykCoAwVSLTxcqGsIineJecVBSYkMpSDVwiVzmHypzoZHkZROuPELOlhqTXmfoSLjYAYTdbHIPAkZzLQRNcFeeZPSRkHYLbXdLJVCCBmYLPvtHFYtAotBhzeUIkLfXhiqTTaSjqZFfLuROCC");
    bool qtiYgmOZmGe = true;
    int JUpmawgpPSBIfU = -1872476576;
    bool JajYRMznJV = false;
    int rIrrrldni = -500468541;
    bool QEtFVzqO = true;
    int VAVgMNizmmhYhBTK = -1128214896;
    bool QVtAXYIy = true;
    double myjHUtFXRnSUT = 930752.553064719;
    bool YRQoDQn = false;

    if (QVtAXYIy != true) {
        for (int UyZkHRtwSWDtwzN = 1190856080; UyZkHRtwSWDtwzN > 0; UyZkHRtwSWDtwzN--) {
            continue;
        }
    }

    if (QVtAXYIy == true) {
        for (int MdqQQzKioO = 963872858; MdqQQzKioO > 0; MdqQQzKioO--) {
            JajYRMznJV = YRQoDQn;
            qtiYgmOZmGe = ! qtiYgmOZmGe;
            QVtAXYIy = qtiYgmOZmGe;
        }
    }

    for (int iQBFgiqUQhzuLW = 1211351780; iQBFgiqUQhzuLW > 0; iQBFgiqUQhzuLW--) {
        JajYRMznJV = YRQoDQn;
    }

    return EaAsqYjPUtmQSbR;
}

void nYmNm::tplCRGbbCCWrrJ(string kpfzZYOCnNaGkapH, bool jvonaOhdqowbF, double vCHypfkrbxMQIoN, string nQqsYvtyYePSP, bool gUGFnILxqYL)
{
    double PirFcHxhQDsFXId = -989154.5266693011;

    for (int bxldeuIVlXhcmVNR = 840462689; bxldeuIVlXhcmVNR > 0; bxldeuIVlXhcmVNR--) {
        gUGFnILxqYL = jvonaOhdqowbF;
    }

    for (int nuFuxGaWUMEQtLP = 1372248962; nuFuxGaWUMEQtLP > 0; nuFuxGaWUMEQtLP--) {
        gUGFnILxqYL = gUGFnILxqYL;
        kpfzZYOCnNaGkapH = nQqsYvtyYePSP;
    }

    for (int zNjkxpD = 2047917928; zNjkxpD > 0; zNjkxpD--) {
        continue;
    }

    for (int BnrwfbHmyDWM = 1826319657; BnrwfbHmyDWM > 0; BnrwfbHmyDWM--) {
        gUGFnILxqYL = gUGFnILxqYL;
        kpfzZYOCnNaGkapH = nQqsYvtyYePSP;
        nQqsYvtyYePSP = kpfzZYOCnNaGkapH;
    }

    for (int cDwopTkjEFnohs = 1025799937; cDwopTkjEFnohs > 0; cDwopTkjEFnohs--) {
        PirFcHxhQDsFXId -= PirFcHxhQDsFXId;
        PirFcHxhQDsFXId /= PirFcHxhQDsFXId;
    }
}

bool nYmNm::klaGIqPBTtF(double RsFTANJOibA, string osuysoL, bool NItyQqFALP)
{
    bool cuGZotdOtwwp = true;
    string otaVE = string("FRoQFwYyTRCmSdMVGUHINvEdirHXsCgBstOygSLOYCUrfeCNHqehcfBrxWYrHUWRslAwvlRQzlNwmlpiZbztXjLYFvWZJFEXNpHFCAqbJyRLXUxJWQeKmBoAZFFXSOTIkQLpsgInHyfkQIujswlghJOzKIXlcrMqZSsRDAvumJPLRKqdAayzBBhtjJJoLkf");
    double andayfHJM = -1022727.7507814096;
    int XFFCpR = -861073663;
    bool wENAaLLG = false;

    for (int jtytYFvInGF = 1808553562; jtytYFvInGF > 0; jtytYFvInGF--) {
        continue;
    }

    for (int uHWCOIGtKEnxYzfI = 1599301777; uHWCOIGtKEnxYzfI > 0; uHWCOIGtKEnxYzfI--) {
        NItyQqFALP = ! NItyQqFALP;
        otaVE += otaVE;
        RsFTANJOibA -= RsFTANJOibA;
    }

    for (int VjHBEBRPXi = 1677581281; VjHBEBRPXi > 0; VjHBEBRPXi--) {
        NItyQqFALP = NItyQqFALP;
        RsFTANJOibA *= RsFTANJOibA;
    }

    for (int vQVdqcOmLf = 279885367; vQVdqcOmLf > 0; vQVdqcOmLf--) {
        cuGZotdOtwwp = NItyQqFALP;
    }

    if (NItyQqFALP != false) {
        for (int VTHdOTwEADbYenl = 1609152348; VTHdOTwEADbYenl > 0; VTHdOTwEADbYenl--) {
            continue;
        }
    }

    return wENAaLLG;
}

nYmNm::nYmNm()
{
    this->aSlNk(600765.9369235315, true, -656943702, -638187610, -568421.7631552707);
    this->tLmnrR(1608198993, -427072687, true, true);
    this->ZxnVRLBYHkBCb(true, 400567897);
    this->EksXWAEssz(string("XEEBJAGxuLndLssppGdzoKCNdPsvNSDuAtwteFzrJSehriDiqRhZWYdiHYNJSyZNNJlbCfJncbNhYMluvqmGGsATgukjAnLaTFLjuwygTXzAOfGxevdAir"), -582032.3876995961, true, -940643.119474777, 954447012);
    this->SdSUdaA();
    this->GbzLkjqVaUgWlQ(-413337.99403887027, true, true, string("YNOodsajygwduEZGfsAigQzIidMODDamRRasQXmIiQUFoqTjcDrAVISQIouGLRJMbTcZKnmWVEioswS"));
    this->AbrXHYh(-1450268406, string("kuEErdTAcRaOEOYGARRrOGxhYxRKpaSbknhwUHdvQbqIXFxaxgEQlelCcyIiz"), 720026.583702275);
    this->xuNOZEOCzvh(string("NHrGVyiIELnsVSakHTM"), 542607092, 1323386409, -486288132);
    this->wFdEbhbKxWI(1214802491);
    this->mWyXSi(969726.2080617684, -1147840845);
    this->YQFtSPoGuSHiFw(-2097619554);
    this->LsoYc(1171843170, 588040.0971203692, -377160017, string("zowxhrvNdXPjawjjNYnzAvKYsKGpCYu"));
    this->JehTrrCFZlLEbV(1221106836);
    this->SLahVvXRWdKHySfu(26921820, 1363967328, -598840863, string("hFyFjaroOudAnbeTrxwpCuoPXnOrkFLlREcniHUMjnxGPJjonmSfAxCwnDeNKgQQunWvVmOGoOstNoQmupDEqqrgVftVhqbrFFi"));
    this->lCiDv(286974.750123358, true);
    this->lAAjEtih(701594289);
    this->zpgYbICUVKYCtQ();
    this->tplCRGbbCCWrrJ(string("gq"), true, -319726.44035456155, string("ZQzqRwNpTQaBTsUHcUBDFygLHxyXMCaDAyhjftAuytTthPdLkIqnWRahGOURJULFTXBJNNQkjjBYqqkLrSVfdvjXvPoaTPmjPMrlHQUIyAoSQbHlYYRedwqkHRKgYhvGhQut"), false);
    this->klaGIqPBTtF(-1020800.4302885138, string("IXFgxaYw"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mXTEUND
{
public:
    bool PfSKYeuSv;
    double gCbqKEZ;
    double tsTmMEq;
    string IdmmwPwnOysuY;
    int MHvLvW;
    int VhuJxkcW;

    mXTEUND();
    string MIdSdzbx();
    double pGBQpYFWN(double CCleOtEVxb);
    string ujZuYDXeHUrUE();
    int CllOVCYJYobFFcaU();
    double iygOJaMgA(string GhkTXmqju, int JfbKsgYfTQnIu, string HQOOIgIShXMo, bool bqtOeKqw, string BPGjBmBXteDIE);
    int bxhtcxMKsJp();
    string gcEvWuxMxbEugT(bool yZczODX, int yFwoRHHTTnJ);
protected:
    string nxBVShlwDcAk;
    string FrrBhD;
    string SEAdT;
    string dcYLdabnQeREpC;
    bool WbhQopMMAJQtWbc;

    double ixdAivqH(bool YVNWNtYkwwSk, int TNjFSrwtCQHC, int GRgRMIRkp, string EHghKNvKQKy, double xiMNVdluE);
    string unPNJZWWHAa();
    void whqfhBVCJppIEzmp(string ANMXaVIQSAjAV, string VdhTxndCMSsA, double BkvzcHoovT, double FCaaqDJFkZap, double LmEWbKaeBQphbJyr);
    bool XsjCcddP(int yqUEyUIboNgMohU, int KfZMnLQmhDVKLdtZ);
    void pENbEhXoMAqNjPn(int fWUAszQsy);
    int CtthpZRRPndsp(double HhyaXNoUPn);
    string TTIdC(string FzMqX, double NPyor);
private:
    string VLzJBmTCgVvTUP;
    int RpHnVMflmP;
    bool ySqbkfYYW;
    bool SzJWgumryzA;
    double fAofZw;
    bool YPGKsai;

    void OKFtxJvbn(bool QLhIdhiKrOu);
    bool tskBK(bool xJCyxTv, bool PgljiXjeHjcarfi, string TkeTOvtExodsE, bool uwKJSscoXV, int VFLzwntiIlz);
};

string mXTEUND::MIdSdzbx()
{
    int pjqQJp = -1280098298;
    int yOyXD = 802719369;
    double lNINhHSTnzP = 163338.3896582757;
    int tepIXJNeuW = -207544871;
    int gjcHfLWZhveLTEX = -1630611866;
    int sNufb = -964741285;

    if (tepIXJNeuW >= -964741285) {
        for (int IzcjhcduKSltIUQh = 1766349089; IzcjhcduKSltIUQh > 0; IzcjhcduKSltIUQh--) {
            yOyXD *= pjqQJp;
            sNufb += yOyXD;
        }
    }

    return string("QkWlNlktRWIuyVzcydzbOLvHjqCnbUnHpnJbXRpv");
}

double mXTEUND::pGBQpYFWN(double CCleOtEVxb)
{
    string lqbLswdm = string("IqmcXWxJPoInfDubtpdxZRtajFmBmGnJswiZGNezzyebcLnOAKdnBcDmlstRagwQaLFCQcgsTiUKvDaomZXnQssOugXlzMecuXgSVaxfcNILrTVUxOwEaWVOb");
    double NDNLWNmtHAKRSx = 155082.22150797903;

    for (int GCxWQHMGYxJBuzwJ = 1057752933; GCxWQHMGYxJBuzwJ > 0; GCxWQHMGYxJBuzwJ--) {
        NDNLWNmtHAKRSx += NDNLWNmtHAKRSx;
        CCleOtEVxb -= NDNLWNmtHAKRSx;
        CCleOtEVxb -= CCleOtEVxb;
    }

    if (CCleOtEVxb > 155082.22150797903) {
        for (int hGVGhrbivPY = 1752610027; hGVGhrbivPY > 0; hGVGhrbivPY--) {
            continue;
        }
    }

    return NDNLWNmtHAKRSx;
}

string mXTEUND::ujZuYDXeHUrUE()
{
    int JnZdFJocCh = -203834805;
    double nafOlDboFua = 605841.0065525406;
    int bZftd = 2058512859;
    string DkcDieavGtJrYP = string("iimEvKGSmhJSadeCKtNhsoOEpuTkBHucGXzocuAtSmkIppkyVNYpzBtLEDIGzzzMxfhtlblOfqfOjDFbmOohQQfMzcWbNzBZMGUphahDlFHmBYVqYBFS");

    if (JnZdFJocCh >= -203834805) {
        for (int tkOSgooFSeHFY = 336131163; tkOSgooFSeHFY > 0; tkOSgooFSeHFY--) {
            DkcDieavGtJrYP = DkcDieavGtJrYP;
        }
    }

    return DkcDieavGtJrYP;
}

int mXTEUND::CllOVCYJYobFFcaU()
{
    int vYoVhlc = -1759286083;
    bool wAzysV = false;

    for (int CfmJLDFwpRK = 282076978; CfmJLDFwpRK > 0; CfmJLDFwpRK--) {
        wAzysV = ! wAzysV;
        wAzysV = wAzysV;
        vYoVhlc = vYoVhlc;
        vYoVhlc /= vYoVhlc;
        vYoVhlc -= vYoVhlc;
        wAzysV = ! wAzysV;
        wAzysV = ! wAzysV;
    }

    return vYoVhlc;
}

double mXTEUND::iygOJaMgA(string GhkTXmqju, int JfbKsgYfTQnIu, string HQOOIgIShXMo, bool bqtOeKqw, string BPGjBmBXteDIE)
{
    bool RBkeOPniTkG = false;
    bool zwydc = true;
    string RqgwqzCxTw = string("OZLAZksfHxDpFgVWXkybVyqmjuzeJzfkzXzDcVwlkAmCoTadEdZdTQjAwQBZuRLvcNxVYLfvCBNZzEonKQMKWhwSRiQpUJezfZwooFoFTqlwejMpZsRNmbLtOVCMyIbcsWaRVfXYLTQcygMNrCzAtotmeSudDOQrSCHePrHEIfljmmFLtGsXruxTrvfAZYMUOwFloDehMrmgZBqWXXVeLhBrkkZyqOkJBKJn");
    bool bgeGkEv = true;

    for (int GahHMcTRjwyoTiTQ = 162708961; GahHMcTRjwyoTiTQ > 0; GahHMcTRjwyoTiTQ--) {
        bqtOeKqw = ! bgeGkEv;
        RBkeOPniTkG = ! RBkeOPniTkG;
        HQOOIgIShXMo += BPGjBmBXteDIE;
        GhkTXmqju += GhkTXmqju;
    }

    if (bgeGkEv == false) {
        for (int DVIOLOqXyVCDpgjT = 1573314963; DVIOLOqXyVCDpgjT > 0; DVIOLOqXyVCDpgjT--) {
            continue;
        }
    }

    return -243845.62130082434;
}

int mXTEUND::bxhtcxMKsJp()
{
    int WgVkqKyHMZfgrR = -59958196;
    bool WnVjuiQa = false;
    double oaxmLqayEz = -679588.9064015024;
    double CugeXhi = -83546.51293274703;
    string lelMXztqZh = string("uBBXOkqYEfVCoCZydcNkIxKMMvQUMeJvAGlsbjlkJpqlcLHGcfaUXnUwbSzbcXWKMDcRzClrWJtqtJQcgrvrlfwXOFLzcHHMlTvGNMJXqkcFIMjUahRGXtPFZWdaiIiCvgHPOauToNOLXCYxieVhmDUNBbMZU");
    int WaQnT = -333658100;
    bool gUZwKtgwYSr = false;
    double TlPVztVqdEpWL = -673354.7694716268;

    for (int bODBecfeEOqQGp = 1035614693; bODBecfeEOqQGp > 0; bODBecfeEOqQGp--) {
        WgVkqKyHMZfgrR *= WgVkqKyHMZfgrR;
        WnVjuiQa = gUZwKtgwYSr;
    }

    for (int FApYO = 1200694198; FApYO > 0; FApYO--) {
        WnVjuiQa = ! gUZwKtgwYSr;
        WgVkqKyHMZfgrR /= WaQnT;
    }

    if (TlPVztVqdEpWL >= -673354.7694716268) {
        for (int MEVxqNcKqBHnnSer = 1830394410; MEVxqNcKqBHnnSer > 0; MEVxqNcKqBHnnSer--) {
            continue;
        }
    }

    return WaQnT;
}

string mXTEUND::gcEvWuxMxbEugT(bool yZczODX, int yFwoRHHTTnJ)
{
    string GGxsxrhwRdZugbbE = string("GqMCtc");
    bool OwjpzeEFSPoeqjTM = true;
    double aYrOSeRfCIFq = 839910.9078241242;
    double JkYcXKKwvj = 360708.0607965641;
    string YDYbtnOPJWYUw = string("WWCmtEoOyLuMHoUSBKrAFXBZQepyjJJaBvqlzNToHFLLsvjuAGXkhoLOFrhVBckUgXsmFabqEAOZKIWZEUsqidjRYTDNcVAeCbqBWaYkFVAYHADuIqzdQpyMPvSkywdHVMjPSlHhYcTlptsXioptTBAAzpEsIhRsebJ");
    double AjYYkSD = 978520.6708735072;
    int aXCtcxDPwRNxIbX = -1145405640;
    int bHzXYKPdeoasau = -15385669;

    if (aYrOSeRfCIFq > 978520.6708735072) {
        for (int tJVlLeovfZ = 1351107278; tJVlLeovfZ > 0; tJVlLeovfZ--) {
            JkYcXKKwvj = aYrOSeRfCIFq;
            AjYYkSD /= JkYcXKKwvj;
        }
    }

    return YDYbtnOPJWYUw;
}

double mXTEUND::ixdAivqH(bool YVNWNtYkwwSk, int TNjFSrwtCQHC, int GRgRMIRkp, string EHghKNvKQKy, double xiMNVdluE)
{
    bool YXkJZFg = false;
    bool GUAxXDY = true;
    bool VrfVtm = false;
    bool pUvKX = false;
    string OTsAclLZv = string("glbJWYTNoMEHEEgTHYYAWFyAAhPWuSBCgXDoTYGEViqpeVdfbPoDAuEklmPpnRVKJjQdosWmQPRNsHTjVfCZFlAcVValRQtUqlyAtciWjTSMXnRPhkPSrodZjrBjcBhbuxkjZNZdMSaXOuKfaYbbROTyhFpxDRKSNUlMPkJbCslaUBVWTHakqkmVDuj");
    double CQNTZDjka = 913895.2624586882;
    int xyXUvsuWTZMBshg = 963884521;
    int LbklunvfE = -934282268;
    bool viGZTgbVPDKsl = false;

    if (YVNWNtYkwwSk == false) {
        for (int qpHEeQaTx = 1130178621; qpHEeQaTx > 0; qpHEeQaTx--) {
            GRgRMIRkp *= xyXUvsuWTZMBshg;
            VrfVtm = VrfVtm;
        }
    }

    for (int ZAuYbK = 1524713707; ZAuYbK > 0; ZAuYbK--) {
        YVNWNtYkwwSk = ! viGZTgbVPDKsl;
        YXkJZFg = viGZTgbVPDKsl;
    }

    return CQNTZDjka;
}

string mXTEUND::unPNJZWWHAa()
{
    bool YaIizAuZXayWoIh = false;
    string JsuYsomX = string("peOiGAPyRSXJmpTsxtAXHmAXQNmQvbZzFwPOEYbWiBgqxpdyeGkWTOIslNMQrNSsDVWywQZLgMXhfYgZmCnVneeKHrmGrRByjQykPZtTwFtKdsPtjqefmraLpqJUzhMCOGldxRIoUFWtqk");
    bool IYZJdODI = false;

    if (IYZJdODI != false) {
        for (int YDBkAx = 1153703795; YDBkAx > 0; YDBkAx--) {
            YaIizAuZXayWoIh = YaIizAuZXayWoIh;
        }
    }

    for (int tMatGFemtlCsFAN = 1055191574; tMatGFemtlCsFAN > 0; tMatGFemtlCsFAN--) {
        IYZJdODI = ! YaIizAuZXayWoIh;
    }

    return JsuYsomX;
}

void mXTEUND::whqfhBVCJppIEzmp(string ANMXaVIQSAjAV, string VdhTxndCMSsA, double BkvzcHoovT, double FCaaqDJFkZap, double LmEWbKaeBQphbJyr)
{
    string eZNhXNk = string("qUbxADWIpodiqryDWikGLgTWYflzHUZqaBegWCsxSmIzJevOuPinjRrkMbeVCqdSuyjHPqeLoEKWArFXFaeuQsJYQyDTEFLMLsktfSYcMwPmcrvuRpBHDzhZmwCjoxqKWpMXyRmcADvURSnkaThxmGRlYhUzYwDCxQfOEzLDdnjGcivfKdHFUMNjqvhanwCgRWihUBcj");
    int TVYiRMzwJYCMW = 1364642202;
    int FzZUucU = 1740106435;
}

bool mXTEUND::XsjCcddP(int yqUEyUIboNgMohU, int KfZMnLQmhDVKLdtZ)
{
    double KWTNENWautZoa = -563105.1039396591;
    double pffPvKXnC = 96680.94463776864;
    int IAcKylqdvMvX = 1940386199;
    int zmwulo = -1026084235;
    string hQAXvRXCkpUDBJgZ = string("NgbnpRRKKwexXsVkmfbLtdglOUoVhugKJAaAgxdRRWLKDjnScqZVztsTCBhSFZAEEaClKuQxbEXIqaSlKJyRQgLsktpIsTExXDuzOt");
    string gBahranZHJocGN = string("mDnzNqyhrpUEWcqJxLhaeWLfihdYgBgdhIZIGxNjCcxwqoPQHworTHfRukBpXbjhYDWataCjgzvnXWMMsMdRjWHneWxaBREhCUKRuBVZl");
    string DYotITxRcqXjA = string("nxEXCnkjpwPaZvHFOmNYKVYQWVekjgmQuXfcAMRotJGKCIuUFsuQsaSIrcowRhrZIaCStolWFjVhynSvXgrmHHZXwoJkQVQWJUQqrhJLvPwkUSIMdkPgYhnxplHOGjiBapXjthrxtZNMcJWeDlaQxxEakZazIwvSZmIMJsHUu");

    for (int BchpynoHNu = 380909530; BchpynoHNu > 0; BchpynoHNu--) {
        IAcKylqdvMvX /= yqUEyUIboNgMohU;
    }

    if (yqUEyUIboNgMohU != 26165683) {
        for (int csqTZn = 1692346091; csqTZn > 0; csqTZn--) {
            IAcKylqdvMvX -= zmwulo;
            gBahranZHJocGN = DYotITxRcqXjA;
        }
    }

    for (int NFPsfs = 1732704824; NFPsfs > 0; NFPsfs--) {
        KfZMnLQmhDVKLdtZ += KfZMnLQmhDVKLdtZ;
        pffPvKXnC /= KWTNENWautZoa;
    }

    return false;
}

void mXTEUND::pENbEhXoMAqNjPn(int fWUAszQsy)
{
    int hjiGOkTbmDZbs = -933200852;

    if (fWUAszQsy <= -933200852) {
        for (int FzoEtRdthYep = 1406047219; FzoEtRdthYep > 0; FzoEtRdthYep--) {
            hjiGOkTbmDZbs /= fWUAszQsy;
            hjiGOkTbmDZbs += hjiGOkTbmDZbs;
            fWUAszQsy /= fWUAszQsy;
            hjiGOkTbmDZbs -= fWUAszQsy;
            hjiGOkTbmDZbs *= hjiGOkTbmDZbs;
            hjiGOkTbmDZbs += fWUAszQsy;
            hjiGOkTbmDZbs *= hjiGOkTbmDZbs;
            hjiGOkTbmDZbs += fWUAszQsy;
        }
    }

    if (fWUAszQsy < 1597124530) {
        for (int WRzybekllIqs = 1186346494; WRzybekllIqs > 0; WRzybekllIqs--) {
            fWUAszQsy += fWUAszQsy;
            fWUAszQsy = fWUAszQsy;
            hjiGOkTbmDZbs -= hjiGOkTbmDZbs;
            hjiGOkTbmDZbs -= fWUAszQsy;
            hjiGOkTbmDZbs -= fWUAszQsy;
            hjiGOkTbmDZbs /= hjiGOkTbmDZbs;
        }
    }

    if (fWUAszQsy <= -933200852) {
        for (int LrbIdBFQz = 1082935425; LrbIdBFQz > 0; LrbIdBFQz--) {
            hjiGOkTbmDZbs *= fWUAszQsy;
            fWUAszQsy *= hjiGOkTbmDZbs;
            hjiGOkTbmDZbs += hjiGOkTbmDZbs;
        }
    }
}

int mXTEUND::CtthpZRRPndsp(double HhyaXNoUPn)
{
    string HropIuVjht = string("JNzHchORKnHvtHAmJvvKqLdTvCPg");
    bool YsDNJSBlQLYySTdg = false;
    string pUXeuxvcH = string("alnSSHJVxGxxcMlmzuaPSxBkKaOMpGTgEWnEaivRyqdndEieexrzwfPSkQEZuz");
    string gNOhEkwR = string("tYnTzGTfcErOtzeIfkdrIhZwhCaufjsnDtPPVMUIixmgQPguWtYnPNLsrebNhbiJKbibXqedMKxsgWGAcifNuYxhoMdkNUmXeduUwnfoxGabhUJaXJfDSuvVSI");

    for (int hHRHl = 1575268124; hHRHl > 0; hHRHl--) {
        continue;
    }

    return -1735486808;
}

string mXTEUND::TTIdC(string FzMqX, double NPyor)
{
    double fjqajjKHhtGz = -768057.7607336545;
    bool WJSrONkBs = true;
    string NwdNxQuaVG = string("HeNWvUxLXvpkkHEsfTySlCvGsZrxWZGZNUOpZYoNYMGZxxjiKFgbXeJikCrbVOubLpcZAprioAmGVJDvERxZAwhfnlkUkLtZvStnzAdZntlsHOQZcgyr");
    string ENYtZgwoPlEKMB = string("WUteDONpKpitWhKxhbtYisBTBLCOHnnHBasJzRtyZkYurIeIjs");
    int ORJjSvKOVjoWIdeb = 1529867585;
    bool vpLYt = true;
    double szogMjBs = -74005.81538757405;
    int MIKwcLb = -1103359486;
    int aDocBJAnOR = 1850920590;

    for (int bDoWec = 489680235; bDoWec > 0; bDoWec--) {
        ORJjSvKOVjoWIdeb += aDocBJAnOR;
        ENYtZgwoPlEKMB += ENYtZgwoPlEKMB;
        ORJjSvKOVjoWIdeb = MIKwcLb;
    }

    if (szogMjBs != -74005.81538757405) {
        for (int azYcwyLxyzUAsm = 1868994568; azYcwyLxyzUAsm > 0; azYcwyLxyzUAsm--) {
            continue;
        }
    }

    for (int UxOAjmLHjjQY = 784825156; UxOAjmLHjjQY > 0; UxOAjmLHjjQY--) {
        MIKwcLb *= MIKwcLb;
        NPyor /= fjqajjKHhtGz;
        szogMjBs /= fjqajjKHhtGz;
    }

    return ENYtZgwoPlEKMB;
}

void mXTEUND::OKFtxJvbn(bool QLhIdhiKrOu)
{
    bool zHqnpfx = true;
    bool ubcRbjwbKUEGb = true;
    string iTXeCWKtgVNOhzWq = string("WUptuGADJjwsBTsfdGllSEAByThgWftBZNZCadtDkujkAsOkoUcDvwZewEdjfXiUNUjBfwwIRgDDtxxkxWTxjQJqEmyvOCzrVPjGuKtchsZALcuCiDVUxChwlCksjbqUnnJJKWlsgGLkWsgeygzMqnOOVOpJOJyOCypUMShO");
    bool ttUuzQpqubFix = false;
    bool CyeIvVywigwPB = true;

    if (QLhIdhiKrOu != true) {
        for (int bcDimLqVuPfRGZ = 918647101; bcDimLqVuPfRGZ > 0; bcDimLqVuPfRGZ--) {
            zHqnpfx = zHqnpfx;
            QLhIdhiKrOu = ! CyeIvVywigwPB;
            QLhIdhiKrOu = CyeIvVywigwPB;
            zHqnpfx = ubcRbjwbKUEGb;
            ttUuzQpqubFix = ! zHqnpfx;
            CyeIvVywigwPB = ubcRbjwbKUEGb;
            QLhIdhiKrOu = ! zHqnpfx;
        }
    }
}

bool mXTEUND::tskBK(bool xJCyxTv, bool PgljiXjeHjcarfi, string TkeTOvtExodsE, bool uwKJSscoXV, int VFLzwntiIlz)
{
    int HNqzhZAYIafLS = -577560020;
    int sgqDVK = 1586650108;
    bool cFAAFRhzr = true;
    string pDNhWFHwo = string("eoABxlvIOEIldYJdzaZuXJYfeAdrfBrKPKuTOjCTohOPxBsztGQYldsUDpmIbvMXNTDvVqLggviaZedfAKEsNsIMcJZwIzfypmOSHXCPWAcrYtrtBCciZCHgBQZhsyqjGjUIP");
    int HpGEIeBwuZl = -137505858;
    bool wneSXqsW = true;
    double BHaNFYzgoqoK = -915397.484275083;
    string FCBWywAetUgwzHp = string("DDmsjKgjNIDARQinsXCKYwNEgdzBsHrfxNOavHBWpBeXLRyRoybxwdiZhnVCbNUqNOvwUTAqzKzGyvPtVrnVYzAXhAXtITacolOuqFKYjyaOeZRjnRKaxHLGoegvnaSuPfLndqAMCKAmeYcSWrhaKGIKSTlvjNiufMkPdeKTR");
    int nrxlQoHZgyBAnLR = 123212749;

    for (int gmHiKsJNCiGFt = 710354202; gmHiKsJNCiGFt > 0; gmHiKsJNCiGFt--) {
        HNqzhZAYIafLS += nrxlQoHZgyBAnLR;
        VFLzwntiIlz = nrxlQoHZgyBAnLR;
        PgljiXjeHjcarfi = xJCyxTv;
        cFAAFRhzr = cFAAFRhzr;
    }

    for (int olaeUi = 629678374; olaeUi > 0; olaeUi--) {
        HNqzhZAYIafLS = HpGEIeBwuZl;
    }

    return wneSXqsW;
}

mXTEUND::mXTEUND()
{
    this->MIdSdzbx();
    this->pGBQpYFWN(-405616.6357762362);
    this->ujZuYDXeHUrUE();
    this->CllOVCYJYobFFcaU();
    this->iygOJaMgA(string("boqjNUPOgeyvSLGXyAmNTLlvNcmkMVTKhvprxNobOWmubEViyTLwWhidwPwrqHTAVFMoStpKPzFqhpghMipcNmNwfjIEsCrKXtJPNFcTqRTgUrvhRXbSfXzPmXYfZv"), 238012280, string("MCuoteUWrXHcVFGXobPaOzMOOREzjzczOjiRCXrGSVUDLasewlSXUVoXCeexdzLBNShXZHlSymTGQoOshbYyeUIRItUxpObzdBXKQGZqvpYqAcgMGftrqQznlsFBQtrDLcNrzuWIfIKRZyxMDYIjUFAXAuuQHqOPwXJJx"), true, string("tXbYDvrbnNtGkADBdWdgVBgWZmyZAxsapSqxiggmNKKJtpOxnPLrecBBdAewOwySyOaudhDNStqnKVErMSbbxxIsgsGopYSdvbYUBEfmpkYVIgnKTSEwNkcBfsxegzPyiMTqmahKunfnLeuXWVOkgjnHsYlcfYmI"));
    this->bxhtcxMKsJp();
    this->gcEvWuxMxbEugT(true, 169385744);
    this->ixdAivqH(false, -1637068255, 336255015, string("JbIWnaAfbjqKjlBNgkItEnSznLcbzYTVsHCEYdjpDQuHyJUalFCKgeGOLWAoOQgVmGwJcrgNFvRAkVtQlUQLrZgekhtAGYZjIpvQqrRJGdH"), -312928.6886795273);
    this->unPNJZWWHAa();
    this->whqfhBVCJppIEzmp(string("aPyvULRKVpLzFcSryRrXjUcKjbjusGdnolhEKJMJbCWmdwaDerDDdEcKtLCFumGbPcofQfzbVxoCaKDULFwzuLbtritAXWWgIuJdLwzMdBpYyMinFEuxDMZUJlNvimPdyUqvFeRELNEFWncKz"), string("jYtdFNSELzkWPJzhPDjpkPNFaiPEfzrCNfNLscgUhsRqYxLncALuDJKBAoGPhUzeEuXiRPtfVhrPqyxwFSmqUdMzKTEjUmdFtnDiituqDictXDRLOMqRISUqOCjhqOjoCyDXqyErYNZsrsBDQtsxaxHAsBtwZisURxiFSN"), -933525.1373888736, -938491.6110489405, -699838.3893328721);
    this->XsjCcddP(26165683, -496108775);
    this->pENbEhXoMAqNjPn(1597124530);
    this->CtthpZRRPndsp(-984167.8467766405);
    this->TTIdC(string("EduApyAavxspcholSDdhVtrLJQcwxkzlpOOyTEGQMDeyXLRVGDHXHAXqSjAlOmbYTedZwLPjelgoctWQsFZTwzRsxKNfTvdzzbKQRWGBnEmgSskuE"), -273634.64970000024);
    this->OKFtxJvbn(true);
    this->tskBK(true, false, string("ZxAVYEjUGixxZxZvmxuxYpvngxDOQWgQidVxfhfUYVkBFfylZwGyOIgMdNGbnbHsppkLThrIznRkPCHqMpGMcVksJQNtCBPnTMoxRtyDbJvtVOVYqBlevxyVBXYTcPZSt"), true, -2093996714);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class joVbxQpfsgwVaU
{
public:
    string GNbXyFQNpL;
    double yzdOowOsIfpzBUqW;
    double bsqThKtXmLHC;
    string lsZtUTFKLUuJtt;
    bool iXCsrEbwPwfRMCtO;

    joVbxQpfsgwVaU();
    int XYqPolN();
    double yUDOTP(double BllyJRpVeCotjMWS, string TjAZtHGalwZbbn);
    double hGJtfSfJFYb(string iqQLSsYMY);
    string WmaIV(double ZngoLYDbsl, double tqAKYccgNMRswL, int zuCrebWslKFDO);
    int AHOhAwluflgcu(bool wCEkWgYhTIP, string QuPEMbAy, bool FjNergLZZviGR, string vNUDMohZf, int yUxqehWZ);
protected:
    string QzOGiiN;

    int NzskkJuheP();
    int mtgRGVFOdt(double ZsvNkeFjwTVw, double ZRXhoQXcseu, double kbZCLzKQDlhOm);
    void aMPtLhULVdfuUjW();
    int MqcHsEEYBUlXlAJ(string FTilYyOPWdCOx, int PeQkWQCXsUQyq, string FEzbprmwashI, string OWKeZGMAuhkpuaM);
    double DNjkPvdCoxLDcw(bool IoDlSrhPMa, double PxNWQhOfuWkxz, int sWozWPGLrpzpCRcc);
private:
    double NiCwkGCoaAjWho;
    double efbplFRpxVEqmF;
    string aUeTv;
    double OGXtQ;
    bool wuVJlihVVt;

    bool AYNgYqkZCLPq(int TUdsmWfRFCdNTZcI, double wznyMsDUYPz, double TeURKT, string oMdwfp);
    double qhsgzyEGVoDqn(bool GBKFLak);
    int JFpNCLinNNeWS(int tszuEveXkDpDdu, bool zVUNXIPw, bool PNNSF, string mgmDOQ, int qDCPTGLsp);
    double SlwiIoIKkMyne(double uFDMOwo, int cftaiay, double lJpQEUHTYDbcaQc, bool GAgzYhqCdDpaAfg, int vBofuC);
    bool gBznzehYuYHX(bool cNWDzlqhLRgzxi, bool QwdjEmAvE, string yBmoC, int EfHrDpyBqYHOv);
    bool pwWrVqLUHl(bool rXnHcygph, string xpGiTigvbwNWoT, int iNAMDvbIbKSh);
    string uEXgOpuvPsr(double PTFgews, string GfEXJTWFkc);
    string KEPLTJtpINDXVHu();
};

int joVbxQpfsgwVaU::XYqPolN()
{
    double EdDPmxGqXg = 349561.17335750523;
    bool pRERuojIffOVHfTG = true;

    for (int UjtNbmiBAuVCZSsV = 1054341759; UjtNbmiBAuVCZSsV > 0; UjtNbmiBAuVCZSsV--) {
        pRERuojIffOVHfTG = ! pRERuojIffOVHfTG;
        EdDPmxGqXg -= EdDPmxGqXg;
        pRERuojIffOVHfTG = ! pRERuojIffOVHfTG;
        pRERuojIffOVHfTG = ! pRERuojIffOVHfTG;
        EdDPmxGqXg += EdDPmxGqXg;
    }

    for (int FFuGiAvYfbW = 801730551; FFuGiAvYfbW > 0; FFuGiAvYfbW--) {
        EdDPmxGqXg = EdDPmxGqXg;
        EdDPmxGqXg *= EdDPmxGqXg;
        pRERuojIffOVHfTG = ! pRERuojIffOVHfTG;
    }

    for (int vDmWYIBcHJClp = 1949358261; vDmWYIBcHJClp > 0; vDmWYIBcHJClp--) {
        EdDPmxGqXg *= EdDPmxGqXg;
        pRERuojIffOVHfTG = pRERuojIffOVHfTG;
        EdDPmxGqXg *= EdDPmxGqXg;
    }

    for (int sWwicqtJXCSXmR = 1623964087; sWwicqtJXCSXmR > 0; sWwicqtJXCSXmR--) {
        continue;
    }

    return 1339932541;
}

double joVbxQpfsgwVaU::yUDOTP(double BllyJRpVeCotjMWS, string TjAZtHGalwZbbn)
{
    double qYDMtH = -849633.6387141047;
    int yUZgsUc = 710984710;
    string eotPsh = string("bejNtpEhCWcRwlAGwGKTzayVuaupeEkrStqbMSDHazPCiSdsslKPCksDgiBIpV");
    int vxYbZauYQ = -313090594;
    bool LaHcrMhIPDeMwOy = false;
    double bZZsXEcNHc = -652040.5004548562;
    string PxjLENZfggzduhn = string("rJzgwqhFsavfjtGJUOIqOnZNgpfdCazSVyOFdSivMvXrniJXlDxitgIZfjfuqPqcuKQZDJwhPVbUnOLaewuYETFkWyQrIHcGfQWNwdKytsKCvMGzjrwi");
    string zewkjyXuc = string("bvDMkwnVacOresukVqieeJWJfIeWpRFghNMvnErjsjmxcusbPuEaAPglVuItmajOFffCKRRJjdHeXWsgPOJJAWsbJFkanmhXDNSvTdJQtayaRJhGyTnEiflTGBrhJhLsKlKpbXIewjSbXyMqNRSHbtVstpxXeGIfVxzza");

    if (BllyJRpVeCotjMWS == 307822.04891062336) {
        for (int vniwVQ = 456730315; vniwVQ > 0; vniwVQ--) {
            PxjLENZfggzduhn = eotPsh;
        }
    }

    for (int cxFGbtZMSymYDW = 1209424324; cxFGbtZMSymYDW > 0; cxFGbtZMSymYDW--) {
        TjAZtHGalwZbbn += PxjLENZfggzduhn;
        PxjLENZfggzduhn += eotPsh;
    }

    for (int dPEIaeXYgpUtZSZ = 1108912676; dPEIaeXYgpUtZSZ > 0; dPEIaeXYgpUtZSZ--) {
        PxjLENZfggzduhn = PxjLENZfggzduhn;
        eotPsh += eotPsh;
    }

    return bZZsXEcNHc;
}

double joVbxQpfsgwVaU::hGJtfSfJFYb(string iqQLSsYMY)
{
    string vnleci = string("TtfgNzHEXWDTjEqqnrZtlQkWVTfEyROHEuCzlShTpEmHolJGeJwuXocxKcVBPTEtt");
    int RkSXddxwN = -818761131;
    double wrZVLHmJr = -695017.3049018197;
    bool bmlMHDHy = true;

    return wrZVLHmJr;
}

string joVbxQpfsgwVaU::WmaIV(double ZngoLYDbsl, double tqAKYccgNMRswL, int zuCrebWslKFDO)
{
    double WaLZBIYtbkj = 278456.899097511;
    int ILPez = -1167173232;
    bool ryNpsxqhqjts = true;
    double lYKPQVLenlavGEp = -446477.755058721;

    for (int yGKnRFncu = 1733282934; yGKnRFncu > 0; yGKnRFncu--) {
        lYKPQVLenlavGEp = ZngoLYDbsl;
    }

    return string("VYcYltcMnIPzmqCoqdWhVFaxDVijxOhSnrLVmqYqSNkdPnGCoUJtibqEcxGPawzLqPuMQdMQFrGkZxUcTDsnpKBaIItjcclorywEJBqnElLWFnGwynAdOjwmiZeXNwiexBZFxyWsHRwuVjrolmIXnFDBgTGlmjbAGg");
}

int joVbxQpfsgwVaU::AHOhAwluflgcu(bool wCEkWgYhTIP, string QuPEMbAy, bool FjNergLZZviGR, string vNUDMohZf, int yUxqehWZ)
{
    string zYtzZbzvw = string("AqwJZSRRiXHhCVZkJyaIYBMdBSDFVhpbpGBMIwxcxEpMnAlZEtIzhTIJvUtTCvRcPLKvqenvuazTHu");
    bool xEcCMZpLd = false;
    string loDsaPe = string("PQXcImbIqERpkcwOYimlfabraSLJjFUZPPacFeoRuDJjzdGxvmLNjISJiMEGazXjijbeanmw");
    bool cOrzKubwkav = false;
    string xODPWobjBInng = string("dehxCdXJXROzoZnmQdQKYLsYGmXvGqgvpOPaVHYKPkERnPfcouXwElDOXqowlbwfBlZheRGcErpdybMqLTpqoLUluEQxGMlchvRjTJNbybWaKDJqXeTuWGDNvHsDAiIycffHAvWszoyNxIHhEuToTWgRxSKIQtztanQKXXjsnfzfTouXGJgLzMIrmSbFJxrFnticJyBhkaleWkrFQ");
    double slqKYsB = -469795.00848244305;
    bool VZUztqxCLfaDCwbE = true;

    for (int HaNXoUdgnltdVRK = 685917568; HaNXoUdgnltdVRK > 0; HaNXoUdgnltdVRK--) {
        xEcCMZpLd = ! xEcCMZpLd;
        zYtzZbzvw += zYtzZbzvw;
    }

    return yUxqehWZ;
}

int joVbxQpfsgwVaU::NzskkJuheP()
{
    double DhQmKGeCit = -14220.505542171206;
    string kBZBWnbxEKUnGj = string("fjpDVTPHToWLvGQVrTzYIixwyZWwPWcLxeFndJWsTkbYSqEenkWJnXGpYCKBVhwWFPkBEGQMgvslGDTwQKRhTjzjFzCgCiFbvEzNnyumxatBozCarfjECceFbXKYyApSpjrqqNwRSNmQEQrwiqtrYTTrsOjQtIPODXBYYzvojoHoHDYgU");

    if (kBZBWnbxEKUnGj <= string("fjpDVTPHToWLvGQVrTzYIixwyZWwPWcLxeFndJWsTkbYSqEenkWJnXGpYCKBVhwWFPkBEGQMgvslGDTwQKRhTjzjFzCgCiFbvEzNnyumxatBozCarfjECceFbXKYyApSpjrqqNwRSNmQEQrwiqtrYTTrsOjQtIPODXBYYzvojoHoHDYgU")) {
        for (int DSkDrtkEUOPKjut = 2095986961; DSkDrtkEUOPKjut > 0; DSkDrtkEUOPKjut--) {
            kBZBWnbxEKUnGj += kBZBWnbxEKUnGj;
            kBZBWnbxEKUnGj = kBZBWnbxEKUnGj;
        }
    }

    if (kBZBWnbxEKUnGj < string("fjpDVTPHToWLvGQVrTzYIixwyZWwPWcLxeFndJWsTkbYSqEenkWJnXGpYCKBVhwWFPkBEGQMgvslGDTwQKRhTjzjFzCgCiFbvEzNnyumxatBozCarfjECceFbXKYyApSpjrqqNwRSNmQEQrwiqtrYTTrsOjQtIPODXBYYzvojoHoHDYgU")) {
        for (int oxMmcuTADcQohP = 144690355; oxMmcuTADcQohP > 0; oxMmcuTADcQohP--) {
            DhQmKGeCit += DhQmKGeCit;
            kBZBWnbxEKUnGj = kBZBWnbxEKUnGj;
            DhQmKGeCit -= DhQmKGeCit;
            DhQmKGeCit += DhQmKGeCit;
            kBZBWnbxEKUnGj = kBZBWnbxEKUnGj;
        }
    }

    if (DhQmKGeCit <= -14220.505542171206) {
        for (int VsPsIRMmjXtAzAGO = 1856360884; VsPsIRMmjXtAzAGO > 0; VsPsIRMmjXtAzAGO--) {
            DhQmKGeCit = DhQmKGeCit;
            kBZBWnbxEKUnGj = kBZBWnbxEKUnGj;
            kBZBWnbxEKUnGj += kBZBWnbxEKUnGj;
            DhQmKGeCit -= DhQmKGeCit;
            kBZBWnbxEKUnGj = kBZBWnbxEKUnGj;
        }
    }

    if (kBZBWnbxEKUnGj >= string("fjpDVTPHToWLvGQVrTzYIixwyZWwPWcLxeFndJWsTkbYSqEenkWJnXGpYCKBVhwWFPkBEGQMgvslGDTwQKRhTjzjFzCgCiFbvEzNnyumxatBozCarfjECceFbXKYyApSpjrqqNwRSNmQEQrwiqtrYTTrsOjQtIPODXBYYzvojoHoHDYgU")) {
        for (int NWZDbIwiqzcA = 1019498521; NWZDbIwiqzcA > 0; NWZDbIwiqzcA--) {
            kBZBWnbxEKUnGj = kBZBWnbxEKUnGj;
            DhQmKGeCit = DhQmKGeCit;
        }
    }

    for (int AfeCYi = 202823146; AfeCYi > 0; AfeCYi--) {
        kBZBWnbxEKUnGj += kBZBWnbxEKUnGj;
        DhQmKGeCit *= DhQmKGeCit;
        DhQmKGeCit += DhQmKGeCit;
    }

    return -302974432;
}

int joVbxQpfsgwVaU::mtgRGVFOdt(double ZsvNkeFjwTVw, double ZRXhoQXcseu, double kbZCLzKQDlhOm)
{
    int yAEBSeTEHjSsgLI = -843143455;

    for (int LhKfQgJKbMLX = 2082683571; LhKfQgJKbMLX > 0; LhKfQgJKbMLX--) {
        kbZCLzKQDlhOm -= ZsvNkeFjwTVw;
        ZRXhoQXcseu = kbZCLzKQDlhOm;
    }

    for (int cEwRLeDAMzxtUjW = 1394876620; cEwRLeDAMzxtUjW > 0; cEwRLeDAMzxtUjW--) {
        ZsvNkeFjwTVw = ZsvNkeFjwTVw;
        ZRXhoQXcseu = kbZCLzKQDlhOm;
        kbZCLzKQDlhOm /= ZRXhoQXcseu;
        ZRXhoQXcseu /= kbZCLzKQDlhOm;
        ZRXhoQXcseu = ZsvNkeFjwTVw;
        ZRXhoQXcseu -= kbZCLzKQDlhOm;
    }

    if (ZsvNkeFjwTVw < 346162.84068876825) {
        for (int TkuHUzuxbfbDzj = 620594027; TkuHUzuxbfbDzj > 0; TkuHUzuxbfbDzj--) {
            continue;
        }
    }

    for (int RuBhzHJvD = 1532321437; RuBhzHJvD > 0; RuBhzHJvD--) {
        ZsvNkeFjwTVw = ZRXhoQXcseu;
        kbZCLzKQDlhOm -= kbZCLzKQDlhOm;
        yAEBSeTEHjSsgLI /= yAEBSeTEHjSsgLI;
        kbZCLzKQDlhOm *= ZRXhoQXcseu;
    }

    return yAEBSeTEHjSsgLI;
}

void joVbxQpfsgwVaU::aMPtLhULVdfuUjW()
{
    string OXIBIw = string("xWFwjUPaHtWBYFSEPGqVwCHNhZTetCkiiCoOclOxuVsdibvmQrJXOSFxjgXUpRKENUgfjQQIHldvIPaqYoOjIfXlVmQZngVjqHqvgjjNijRnTvpMJFGonLouANovpvapeUKeafAvemAtIrKyCRzScmHMrrIylEICLigoJWNEDdjZKWWctURcOOFpZDqElgFsOrLkJTOjINYxwOGdLxCBXWCASjALdrHIArWgnGlcBiTYPsYHl");
    string fhDnFXkxeJlbn = string("MziUqYzsTTVLSlNFNstvwdMYXPIXHeXdBZXEvZeLRLHQniDbCqfjzCFIUlgoinNJWfIlEJQMtDsgpUAqFsMGtLKhJtkXRVivDrWVZThTKkpqAPyWvlTItVfsaYvfaFsWpvWoXSNXSNYRDJuXVbjlerMqFDedbqgLhRVKTjfyqWXTimDzMjtsXAfPCpLypUYmnlBBUzYndGJQCcMWfaoBvuHhMaTjjuBrfjPkFrrpT");
    double nslZfHAu = 291162.5865997795;
    string CVkcMv = string("emIcHLTtiClVAnPRlAwTDsnrMifQESWPXDHfphcRuaEVpbbnbymzicVFIZEaUiRjlePXvMoZueDpZTz");
    double kYGymfBecknaf = 999239.8948700419;
    string CpFVugMOMJ = string("ueiNKpNnYfRHoMSQAdUTBlwwAtuftBFJDH");

    for (int nPcyqQ = 1605450691; nPcyqQ > 0; nPcyqQ--) {
        kYGymfBecknaf += kYGymfBecknaf;
        CVkcMv = CVkcMv;
        CpFVugMOMJ = CVkcMv;
        fhDnFXkxeJlbn = CpFVugMOMJ;
        CVkcMv += fhDnFXkxeJlbn;
        fhDnFXkxeJlbn = OXIBIw;
    }

    for (int CEeXoQKpGbmozZC = 1464753828; CEeXoQKpGbmozZC > 0; CEeXoQKpGbmozZC--) {
        fhDnFXkxeJlbn = CVkcMv;
        fhDnFXkxeJlbn = CVkcMv;
    }
}

int joVbxQpfsgwVaU::MqcHsEEYBUlXlAJ(string FTilYyOPWdCOx, int PeQkWQCXsUQyq, string FEzbprmwashI, string OWKeZGMAuhkpuaM)
{
    string WCxGNYd = string("glgUccgkBGUQKORwPLbRmyhTpvmROmvaHwjdsihUtHdWzFAZdoxpgXvRAuhDoOXQjXfLEuSKLRrONPxfSWjtDrOTGioFlhXWNZxjqNagKbvhugimepsxrpaovXtn");
    int PKvwU = 1116017655;
    bool jsMzvkTgiOxML = false;
    bool YFDSWTvUnUXkQ = true;
    double ESDoLimy = -886042.7308330835;
    double TMZetXOCPD = -631208.2470545635;
    int mhjkLwNqNpocVRyJ = -1642181799;

    if (PeQkWQCXsUQyq > 1116017655) {
        for (int IpvqBkePLAkfm = 1473210550; IpvqBkePLAkfm > 0; IpvqBkePLAkfm--) {
            FTilYyOPWdCOx = WCxGNYd;
            OWKeZGMAuhkpuaM += OWKeZGMAuhkpuaM;
        }
    }

    for (int GmcloCS = 944289761; GmcloCS > 0; GmcloCS--) {
        mhjkLwNqNpocVRyJ = PeQkWQCXsUQyq;
        FEzbprmwashI += FEzbprmwashI;
        PKvwU *= mhjkLwNqNpocVRyJ;
        PKvwU *= mhjkLwNqNpocVRyJ;
        mhjkLwNqNpocVRyJ += PeQkWQCXsUQyq;
    }

    for (int vlvsOhreMok = 1675580133; vlvsOhreMok > 0; vlvsOhreMok--) {
        FTilYyOPWdCOx += FTilYyOPWdCOx;
        YFDSWTvUnUXkQ = jsMzvkTgiOxML;
    }

    for (int kfZNeSwl = 399808748; kfZNeSwl > 0; kfZNeSwl--) {
        PeQkWQCXsUQyq = mhjkLwNqNpocVRyJ;
        ESDoLimy -= TMZetXOCPD;
    }

    return mhjkLwNqNpocVRyJ;
}

double joVbxQpfsgwVaU::DNjkPvdCoxLDcw(bool IoDlSrhPMa, double PxNWQhOfuWkxz, int sWozWPGLrpzpCRcc)
{
    string dqNylOwcXNfKwho = string("wGdMJvenHJQrqsSfGWGbxnptO");
    double DETCRbPhB = 721848.1215318739;
    string YptvTpdruAHUXT = string("FKQfncKywWiKxJxpjptAhTwvKkYCUMaEkUnrmkzpzzMeDvUQyjBKZxNSQmSumHAKGmMlrYXudLcFvlOZYCOuyLNYTFqyXGMIBsSibTJPsEHJESAzGJmabxQfQMohZamhjLoH");

    if (PxNWQhOfuWkxz != 721848.1215318739) {
        for (int RlvGHr = 1748932101; RlvGHr > 0; RlvGHr--) {
            PxNWQhOfuWkxz += PxNWQhOfuWkxz;
            sWozWPGLrpzpCRcc -= sWozWPGLrpzpCRcc;
        }
    }

    for (int zfbSDQBWrpoYlZ = 470341647; zfbSDQBWrpoYlZ > 0; zfbSDQBWrpoYlZ--) {
        YptvTpdruAHUXT = dqNylOwcXNfKwho;
        DETCRbPhB -= DETCRbPhB;
    }

    return DETCRbPhB;
}

bool joVbxQpfsgwVaU::AYNgYqkZCLPq(int TUdsmWfRFCdNTZcI, double wznyMsDUYPz, double TeURKT, string oMdwfp)
{
    string xazhuKfWBofWBHR = string("VraDaMTrQbZRmHRcCcCkCUzWispqWDbgpLqgXMQOsRrRuZTbTLLaAThnwCFqetyPLKQuGWaZaavtZwgNAEHnmcapsBYGtFNEXlUZMjzcUeahtVlurqRCdUT");
    string jfusU = string("KYRQeBcSFhyINhkWYPMuDVfYTowCKFcOoznfOJcpWWfLowWagcbhAekiJIXKKvcmObiBjEMyUwKiNVBDyheeMabHynIixhlHHAqRNBozUbRCIBisWErzPCcwaumStlzPSLlVeuaTLeesYfjzzJUKMYYnWcMhnsWuXYsFEHhQgYWsBVcdQvqKkiMdBxIHArNJmTzVSLqukitDfOUIacOHfJeQSEyNhdgyiVEkCMZRmkkzviNISErlnuvJd");
    string hftCHXWh = string("rCrtVtJInFKVDgAcihNIfKBPTIVRiCogvUdVqkuQhUClXeVXJtEWuPKKmIbjBiKtgSAmSSGHs");
    string UwQFmMVoou = string("OhvwQgYOdPQPaUtODyHgfKHINFPwjJCKjSRJCnAbYGglgfNTJcNeknyflFXDOXocDzBuVOhaiKCMHAQQMXhGHFbLCJsZTEqsftknrvWYhEfrklZbKDwFkTiyEegZDzngcNNhEIPrJwNldAPoswHRdWFZVRO");
    string ACqgozDrWrIduc = string("wZtMZzaxXAHreWRfqVqTOgOnybgpyqakVzDNgZmuCiseCwDLewoaaGBWjNTPAPkcAWcSNOCNPmDMaITEwjm");
    string AtfrXfJ = string("uEXxJJtesXhZQWEBZTZlMHzjTZZgbXDGuFLTcRBZgmwKslQgGmOqJQSSclkoKDf");
    string ndkKkYo = string("suKbopEbmOZmLMtHnHnvKwhaHnwWS");
    double mYnDR = 634487.2287873265;
    string LUossLzTaKK = string("giSGRsusqkfiRXeqzmYXpvJOolOXwpOYOJwFZjbkWXFLsXajiqyYFnluTSlOLaQlvLlLDRoeuySFXIcxtsdIuoHkqYhGkgEnBMLLVCjznSMTpvfvOjqeCcugXERBJhxhayxqwScoACROdYpVTiBQVCnNzedDvbb");

    if (AtfrXfJ != string("CVSnOdpvTXMSoNxeiBUUJuwmMEbPktbIaaEWhNQBTgnJezsLlGyDbPAnOptpMufEecsTQwAocWBNJxjWCMPBkAyDRRBMYpklLJfWndLHBgmaFYpsECnLAzNtUzlEnuGrKwkUYRzSWqArGJmeFdHDgeKBGGVGbugtGppxFPyScVrSngeBuWavhqlhzIJNwGZlThbNHZoWnYlrm")) {
        for (int AdHXywRFVGz = 1282812018; AdHXywRFVGz > 0; AdHXywRFVGz--) {
            LUossLzTaKK = oMdwfp;
        }
    }

    for (int XXThNKVmEak = 1074568843; XXThNKVmEak > 0; XXThNKVmEak--) {
        hftCHXWh += ndkKkYo;
        AtfrXfJ = UwQFmMVoou;
        hftCHXWh += AtfrXfJ;
        jfusU = AtfrXfJ;
    }

    return false;
}

double joVbxQpfsgwVaU::qhsgzyEGVoDqn(bool GBKFLak)
{
    bool QcWRDcuALsHlayH = false;

    if (QcWRDcuALsHlayH != true) {
        for (int eHmicajCMYdz = 345676451; eHmicajCMYdz > 0; eHmicajCMYdz--) {
            GBKFLak = GBKFLak;
            QcWRDcuALsHlayH = ! QcWRDcuALsHlayH;
            GBKFLak = ! QcWRDcuALsHlayH;
            GBKFLak = ! GBKFLak;
            GBKFLak = GBKFLak;
            QcWRDcuALsHlayH = ! GBKFLak;
            GBKFLak = ! GBKFLak;
            GBKFLak = ! GBKFLak;
            QcWRDcuALsHlayH = ! QcWRDcuALsHlayH;
            GBKFLak = ! GBKFLak;
        }
    }

    return -786731.0803430642;
}

int joVbxQpfsgwVaU::JFpNCLinNNeWS(int tszuEveXkDpDdu, bool zVUNXIPw, bool PNNSF, string mgmDOQ, int qDCPTGLsp)
{
    string hFVMG = string("odspbhKPIZPVASCbkcSiSmDbwZQQXRaMjDuNiTpreHewLCuRrUXmvRwotqtxypeviLeYpGyroXH");
    double xUcFEMDVql = -1005604.1632246247;
    string vZGOLpdbpQWoLTSE = string("txZcFDxAWCHKEPjkKNbZMXDsvnNagwlYymXuITuQmXAAqRrLfbmvLmksaZiPSSBwBQlMPWgyDXqbADMRfKxdGfgIOYIlHKTgqhpYEqPcG");
    bool YosSXkmLWhJ = true;
    double hwGgieCa = -958220.3203391185;
    string kPAriLCs = string("bnXnEhePHaPZIwAXqwsGSVGsuzOiWKmaVcNXiItNyKtaIfjjKJPnQqbQgKqTWRoBzVSGwEVMwoDFnPPknoIfBHHSjBonAgvfWFbCtFnSXaIaxqIcwkrhqDpZm");

    for (int vdjkTYk = 1500405054; vdjkTYk > 0; vdjkTYk--) {
        vZGOLpdbpQWoLTSE = hFVMG;
    }

    for (int zZogLm = 630066759; zZogLm > 0; zZogLm--) {
        qDCPTGLsp -= qDCPTGLsp;
        zVUNXIPw = zVUNXIPw;
        xUcFEMDVql /= hwGgieCa;
    }

    if (hwGgieCa < -958220.3203391185) {
        for (int lWyFbvvoVgXEfe = 1932751574; lWyFbvvoVgXEfe > 0; lWyFbvvoVgXEfe--) {
            hwGgieCa *= hwGgieCa;
        }
    }

    return qDCPTGLsp;
}

double joVbxQpfsgwVaU::SlwiIoIKkMyne(double uFDMOwo, int cftaiay, double lJpQEUHTYDbcaQc, bool GAgzYhqCdDpaAfg, int vBofuC)
{
    bool BtdFMBHGtoBsb = true;
    bool YrJxKHhCETTS = false;
    int lEBRM = -1134338183;
    bool oTiejtTJMIyaaHoX = false;
    double bKpAeJhNEFDmZNHq = -526995.5339370772;
    bool yOfTskkIjTGB = true;
    string nrYEpHmbB = string("BXQSGYYFiIwppaWyLuWuhKVncwrDolRnovzshnAdcqlQhSJkModjzPaDQyNVVYkialRXIqRdVrSpqjLGlAqQphwzGSPekapNnY");
    string zfcYfECcqXhya = string("CPyiSpbGckICTRZoWpvoaIALcMvrylabvZnniKXWXDCzvfZOFxgPIDOfxVneVddUwPPgBBMKpSYpfiLDlsnTkbuSGzHnhaLSOUcUKxjFEBwOfzMFiThSHwobaDADO");
    double wLCzO = -765043.5516415408;
    int mnTLTDQeai = -1084281284;

    return wLCzO;
}

bool joVbxQpfsgwVaU::gBznzehYuYHX(bool cNWDzlqhLRgzxi, bool QwdjEmAvE, string yBmoC, int EfHrDpyBqYHOv)
{
    double gyjVbjorTSNS = 1036905.6859089297;

    if (QwdjEmAvE == false) {
        for (int qZHlHfHVhSF = 557908751; qZHlHfHVhSF > 0; qZHlHfHVhSF--) {
            QwdjEmAvE = QwdjEmAvE;
            QwdjEmAvE = ! cNWDzlqhLRgzxi;
        }
    }

    for (int yfDUx = 562660891; yfDUx > 0; yfDUx--) {
        yBmoC += yBmoC;
    }

    if (EfHrDpyBqYHOv != -1516091287) {
        for (int GyoQLM = 787573315; GyoQLM > 0; GyoQLM--) {
            gyjVbjorTSNS = gyjVbjorTSNS;
            cNWDzlqhLRgzxi = ! cNWDzlqhLRgzxi;
            cNWDzlqhLRgzxi = cNWDzlqhLRgzxi;
        }
    }

    for (int dgVzIMCpPbbEZjed = 1742756814; dgVzIMCpPbbEZjed > 0; dgVzIMCpPbbEZjed--) {
        cNWDzlqhLRgzxi = QwdjEmAvE;
    }

    return QwdjEmAvE;
}

bool joVbxQpfsgwVaU::pwWrVqLUHl(bool rXnHcygph, string xpGiTigvbwNWoT, int iNAMDvbIbKSh)
{
    string wpQzANDTYrQ = string("OsAOzUdNSrtUFXooIhNRBcraOIPbtqK");
    int omxrOa = 1445335885;
    string mNqlfOesSfDVTiT = string("GSrDjWXCFswtUuEqrOVVSDKpCCNATiDeEgLcaTLTtAqxjslkHjjwQZCtXOpdjDtxXMutnneVigpdRFqXGUuMgxXsRPiSmucuHWVcFQzLMwQqFvQCIgnEyFJkBgncqfOymLIPXoRCJgZNLLekeaFVuVOXBMlFteNUQrf");
    double iEvESYpEvIWUXdWp = -134618.95773225828;
    string NwzXc = string("hudRcXOuLBUjcRvDEaDiebrCqqlgdGGmFAuhBvMSTwlKJumjLxQDbEDpjLxnPmoMZZYZJFDfdRUllozcHSlkseQpWeBQTVixbbFMtTWwHLNNaBrMdJGZhqqhFPnzKloeCNLKMCeEzaZwjKkyNHjH");
    int fnbOBlpwV = 1788973998;
    string sAExMjcoGiNp = string("czHBCvalVM");
    string yxwQKdmouo = string("rKLMVZNqZcvbToigXGGCwXYsgCXnEefhKIApetjuviovgdGiNOItvkCWTemzgTcWTWZmgSWlrVuTHfqiZIZNxVfsOBKXaJJWErXqAFZlppDLRMylWfpOWzNvdAdBJVVfgMAtZAfNTUSSVVRKgXFuMkOqfYtDkJsAtuOKoFzitpiKoMUqJFhDfcJhdqCMDNhNiZBsveyXZhJkCgDkClmWRBObrwMvRbxYzrjJXrPJoBWBLUSMnyFPwbXE");

    if (sAExMjcoGiNp <= string("GSrDjWXCFswtUuEqrOVVSDKpCCNATiDeEgLcaTLTtAqxjslkHjjwQZCtXOpdjDtxXMutnneVigpdRFqXGUuMgxXsRPiSmucuHWVcFQzLMwQqFvQCIgnEyFJkBgncqfOymLIPXoRCJgZNLLekeaFVuVOXBMlFteNUQrf")) {
        for (int SlrBoFuUCOYXnX = 62946769; SlrBoFuUCOYXnX > 0; SlrBoFuUCOYXnX--) {
            sAExMjcoGiNp = yxwQKdmouo;
            sAExMjcoGiNp += NwzXc;
        }
    }

    if (NwzXc >= string("OsAOzUdNSrtUFXooIhNRBcraOIPbtqK")) {
        for (int dKzrshxpma = 1721855436; dKzrshxpma > 0; dKzrshxpma--) {
            continue;
        }
    }

    for (int vXFuDtbgmhJPuN = 1415226643; vXFuDtbgmhJPuN > 0; vXFuDtbgmhJPuN--) {
        iNAMDvbIbKSh += iNAMDvbIbKSh;
    }

    for (int ZJBRzzGTJ = 384388222; ZJBRzzGTJ > 0; ZJBRzzGTJ--) {
        mNqlfOesSfDVTiT += wpQzANDTYrQ;
        sAExMjcoGiNp = NwzXc;
        sAExMjcoGiNp = yxwQKdmouo;
        xpGiTigvbwNWoT = NwzXc;
        mNqlfOesSfDVTiT = yxwQKdmouo;
    }

    for (int uvzSoSxZR = 90008328; uvzSoSxZR > 0; uvzSoSxZR--) {
        mNqlfOesSfDVTiT = xpGiTigvbwNWoT;
        iNAMDvbIbKSh = iNAMDvbIbKSh;
        sAExMjcoGiNp = xpGiTigvbwNWoT;
        mNqlfOesSfDVTiT = xpGiTigvbwNWoT;
        NwzXc += wpQzANDTYrQ;
        fnbOBlpwV += fnbOBlpwV;
    }

    return rXnHcygph;
}

string joVbxQpfsgwVaU::uEXgOpuvPsr(double PTFgews, string GfEXJTWFkc)
{
    double vnvkzHwUKCx = 200218.78319357848;
    string CVXWWgVSOfV = string("cZCualjvcjhLMweujWSdREeMFLnoKELmpvMdMGwMtUxyWuKBQoQUQEOOPmsDmUVuUZkpgzhOPaItBxgnjeseKTjIfPhoEVnXrRclIABrbtGRXROZahqyxLkAQXibYXEddwxcJaBDcYOAXZYOlBOQdqzH");
    int NZeCWiMsKpWZf = 2119349247;
    int KhdUfYWuDL = -2146509875;
    string TzBpAxOliUJO = string("lFbFyaKtyuHxADeFFxkXFfxsMkRbUYgxyCkxBChaFXdGtgcgatkNORLqxQrevSTyNMnXjhwfYhFXFqlcKkcAynRqHmZdWDpkQJZUSCLQJdrpWbMkpscefcjPsQziAUpKbqXTNGZHYtONqzuIWBwOyeTvACrESWBZYUZeRnqmwoQwDgRmuTqsOrLZBYDvTue");

    for (int ieDXPX = 928792454; ieDXPX > 0; ieDXPX--) {
        TzBpAxOliUJO = CVXWWgVSOfV;
        GfEXJTWFkc += CVXWWgVSOfV;
    }

    for (int txTZGqKjA = 1200707304; txTZGqKjA > 0; txTZGqKjA--) {
        PTFgews += vnvkzHwUKCx;
        NZeCWiMsKpWZf -= KhdUfYWuDL;
        KhdUfYWuDL -= NZeCWiMsKpWZf;
        CVXWWgVSOfV += GfEXJTWFkc;
    }

    return TzBpAxOliUJO;
}

string joVbxQpfsgwVaU::KEPLTJtpINDXVHu()
{
    int GdBWfd = -1293436043;
    double jqYvk = -247576.03545364164;
    string IJYBRuEzfXyB = string("jVWdqmzgPOkuQKNNFcbUopXiwLzwVAUMfDDpEnJCdJmTttoochCZVOeAYhzMahARYKagbdsXjbufVXTkJZOWrQbCHzolMWmFdVLifYjwZlcxDqBBXu");
    string rRXqjuw = string("WljwbmGpaIcknAfFIXAjuZuyGfmcHvDKnuvBWjiGaqoOOFgGeipQArPKxjKFCLydEteaxnBXnyieDpMlDidarLgWgEdeMoYQAALINubJmKvrFwsSOAXHWrvLiODgMZRwCRvMoBPsvbVytfNKMOsmcOOfKcxlgXPkIVsGwKFzcYNgdjscXOAFJmZQAjA");
    double wKxkGtpP = 406835.62907714554;
    double QLUxXdEIw = -449385.01421586436;
    string UcmIgLNHRHIirTBm = string("oqoxwAqQWjUuSTEfJPbjVkGyNbKXAiCNVcjfcnysSupgcbrEcFkqxyhsJfbwhqDncLzpdAHINPIbTKhEABYmBQaTqGjsIvyzoEeXuRKlDzoQvzzczzYjHcabVMPFgvGcYnHxhtDFnSvlceeojLxUwaKsNEyIYGPtpvJijrLlaotMdjvuriuVIWflyKwAMgpYmcwLkDtNK");
    double rkCjUsVYDhHlWLR = -486874.28510784585;
    double bLFYMU = 790117.4661019883;
    int iIPiTiAoH = 1258864619;

    if (wKxkGtpP <= -449385.01421586436) {
        for (int gqmWFjdYlJ = 1094738995; gqmWFjdYlJ > 0; gqmWFjdYlJ--) {
            continue;
        }
    }

    for (int OVFLmAzgUi = 1896117592; OVFLmAzgUi > 0; OVFLmAzgUi--) {
        continue;
    }

    for (int dhIlHx = 1232627346; dhIlHx > 0; dhIlHx--) {
        wKxkGtpP *= jqYvk;
    }

    if (wKxkGtpP != -449385.01421586436) {
        for (int xkTfajRrJWV = 942477097; xkTfajRrJWV > 0; xkTfajRrJWV--) {
            rkCjUsVYDhHlWLR -= rkCjUsVYDhHlWLR;
            rRXqjuw += UcmIgLNHRHIirTBm;
        }
    }

    return UcmIgLNHRHIirTBm;
}

joVbxQpfsgwVaU::joVbxQpfsgwVaU()
{
    this->XYqPolN();
    this->yUDOTP(307822.04891062336, string("dVxqVMRlDjyYQbnTRelzQEQdCjnilUVuTVevNwhBfPAdJmTCFYJIWglEUZARiDARrLZmNJScfzIoNwlQkajeJmzTQjitFnXsKGUEGFXInHxwrWrbxoCcFTsrGvWrHdHbUYXAWZnKiKKzIdBPNsVXsOUZNCFtFYEBKfVmvLBuwnPdAkgMyxislFPsk"));
    this->hGJtfSfJFYb(string("ioPESigVVUmsqKiKfyXdxncoMHEkmLVrnTVgUiZMyCBqnrRJMCFvCplaEloYoaeZgVSLpoduEPBDUIRKLvxDAGj"));
    this->WmaIV(-785290.3638248189, 186425.42028082884, 1697738642);
    this->AHOhAwluflgcu(true, string("JihZIOEaIUHqoaxozmDhoIcPSeKHDxhsDvarGsNtEVVIrqKXqfVVpPQiugnRtXrBxzGfmKlwsbBpBVgdiafaXUTfqtdEWxiXpMufFuUTDnXBoorDJziEhlMxDYHfKRNCUwfIuygASRVSEsaDGKLJqZhzYgvGfGIkFzikOnwkDJVxBrFfffNIgQRmPoMJVmYJKuZSfcoTMWEnseqnoDsihIeUixoFJIYnEZepJXexpOjz"), true, string("upJuDFtOsmYkOHRJFrfCCotquQuXfDhKLsKmFMZHKVQnjUHPreAbLYCeTqoSwxeTOHmYCqCmRCwNUjgheDurpvnUBSrdZioPEoaYB"), 913838157);
    this->NzskkJuheP();
    this->mtgRGVFOdt(-432719.04090788093, 346162.84068876825, 14701.340076349861);
    this->aMPtLhULVdfuUjW();
    this->MqcHsEEYBUlXlAJ(string("jINfDRfnTntaBTmoAsJlloGhWuRcQzqxkZeYSnPewRIvyvbqczqtNRISgAfuubmisdHPlfRarjlkMSlcdUiVgelCKrdnNoZtmolrpFbdwDQRtRzmrpQyGMWkMTBTHAcBIHugOcUNtgsxMSTqDacUfZGecqEkWAikZlWDHNmoKNJqjwxNerUAJJovUxeNngHLNYKYNAIQghtHXbZxOkAUwZo"), 2066324000, string("NsSkqwAgBkBpcIlAEzRjnLPLveQTxonkjRI"), string("QAvPBhCHbPvTPXnzlamscOdTCqgwCqWHUQVjyPuhClAaVPCcTVidVWLWjegCFKWpRypyhSXzblNRzhscpNrIGDJDZrbuLwVccOIfLpEWOokdJFbReIwMfFIVUZspnIbfbxCvSYdREtFqzcLAdIDYnWmkKgKizdIPBRjqoYyMgPzxAxSpymEG"));
    this->DNjkPvdCoxLDcw(false, 667438.3576679251, 824317646);
    this->AYNgYqkZCLPq(1507972370, 165610.20981354118, -339448.6309481728, string("CVSnOdpvTXMSoNxeiBUUJuwmMEbPktbIaaEWhNQBTgnJezsLlGyDbPAnOptpMufEecsTQwAocWBNJxjWCMPBkAyDRRBMYpklLJfWndLHBgmaFYpsECnLAzNtUzlEnuGrKwkUYRzSWqArGJmeFdHDgeKBGGVGbugtGppxFPyScVrSngeBuWavhqlhzIJNwGZlThbNHZoWnYlrm"));
    this->qhsgzyEGVoDqn(true);
    this->JFpNCLinNNeWS(-577563607, true, true, string("oPiCVdOdsWlkNDtoUiqYrYRZcMomRAJzUyqOqqfnryuPPzLboIwUnsedmijGBkRqmabRQKmrtWIzikTAaAUicZgsNfTZAdNoFbZPiwDSdntNxkqYzlpMfAONtzTzppvGmCsGrpuzaVsGOlBYZtXbADDuRZLfMkcLlXXeVCssdlONqNyxfExjzDaDfL"), 1444134208);
    this->SlwiIoIKkMyne(880041.7724685413, -1671264203, 968517.0399880655, false, -649018292);
    this->gBznzehYuYHX(true, false, string("EbTtgykQIUtWZZpTBtcCASeXGBqYpJSGLmgYULIBdnGRcnDfJWVKQTVCzyUBVQOqpeLLiKDnuwAmaPYglKJBabvlsnK"), -1516091287);
    this->pwWrVqLUHl(true, string("uysXIKSXxZyWCCAqUMuEHkyqgeMTfmwCZOtWGyvPkHjusgIAziEhHFSOdsmWTOMpvPGWbXbVawMtSVzCiBewMXWOQFfMxIGMkklVQTyuplWrjyhNQReBiDOYHTsFpcMgENSRguVOzNtutBwSLoeRicagaanNTHTSNyNYAzvBafBOWdVs"), -1824604375);
    this->uEXgOpuvPsr(-773482.1625556016, string("VKLzVJimBpVYedsmfFGljuUSfwRHJSzhTdDMgOpqaOOHuXBlbcvwJToBxQkVqbbndZQcfjCgXmaYVoumpMxfaPehqJSqgayVEJyChbHfvwBdQcArJAQ"));
    this->KEPLTJtpINDXVHu();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KnHxd
{
public:
    bool gqcjFIEetm;
    int oQQtXgSNuRmZbCm;
    int yeFUhlZceHmYN;

    KnHxd();
    void KcvyTWnBeGnOe(string AKCpyRTmrCZzT, double zOXNbBwwfm, string IkVoRHUfVbZ, double cSjoCbjFOnQUpt);
    int ZGVBqAzGnzqM(string vSEVTZzpBgcmPNd);
protected:
    bool OkjRHNwemSW;

    int QyXxWyHJQLwFiBCx(bool BKjICuo, double PlCXy, double TSYIaYu);
    bool PjThgHsu(double LRHtBBPGHvebFWD, double ZIxDhcvGTW, int wFlHRTPAfgW, double tQVUi);
private:
    bool MMXVmcwti;
    bool HMjOODHtq;
    int orKRnwEZmmkTtPPo;
    int ZfsPURBupDBB;

    int IvOtbNPjFggKgHIN();
};

void KnHxd::KcvyTWnBeGnOe(string AKCpyRTmrCZzT, double zOXNbBwwfm, string IkVoRHUfVbZ, double cSjoCbjFOnQUpt)
{
    double zTGNktnGsbWFCAyC = 234616.94227329857;
    string NHPSZVIrxwZ = string("TxcvKegEYULLvooKcFcnvSHBwuSijOMMDIhUNOoMHRfhAgSOfLPvYdNkNJYcJlfql");
    int jpgvqHLzxjqiO = -1154358586;
    string oqvfUhUmEjzjIVi = string("yJinbvDrsxLrARPBOwMLLKRJQYnfWCEHfUXcUQklzfBQgNRTiTTEEYmvuJRNImssHNmFknCQeMkdKeqgkUxEUaIQpURMcQRSPkctNiEFvsqWPqGNEdNRdjjTbLRxDVkEFrInHDCzyfNNgIQYfByUTRnBbDrKlCHVcyxnQPrfWt");
    double NteARoyszjLIPHA = 554543.875197635;
    bool ZKUaBTpddmxqyZL = false;
    double HbsddgLDgZzesNQp = 150255.28743620144;
    bool PZYwSAhkIZOEx = false;

    for (int shKGwNrGk = 495614593; shKGwNrGk > 0; shKGwNrGk--) {
        HbsddgLDgZzesNQp -= cSjoCbjFOnQUpt;
        IkVoRHUfVbZ += oqvfUhUmEjzjIVi;
        HbsddgLDgZzesNQp /= NteARoyszjLIPHA;
    }

    if (oqvfUhUmEjzjIVi > string("RMzGltJbsSFzHHrmtJPGMeFCwBRQChDjbcdEUKTeXcnJNRmuPldzpGIlqIEalhBQWroOlvspqgSYwCQZSIvljYmBJevEbxIBimkN")) {
        for (int XHPmPIucRSSwYpQ = 1602423720; XHPmPIucRSSwYpQ > 0; XHPmPIucRSSwYpQ--) {
            NHPSZVIrxwZ += oqvfUhUmEjzjIVi;
            NHPSZVIrxwZ += IkVoRHUfVbZ;
        }
    }

    for (int lDwRisrSZqdUvJ = 29566751; lDwRisrSZqdUvJ > 0; lDwRisrSZqdUvJ--) {
        NteARoyszjLIPHA = cSjoCbjFOnQUpt;
    }

    if (jpgvqHLzxjqiO == -1154358586) {
        for (int gJJiwEBPhbtv = 692416387; gJJiwEBPhbtv > 0; gJJiwEBPhbtv--) {
            continue;
        }
    }
}

int KnHxd::ZGVBqAzGnzqM(string vSEVTZzpBgcmPNd)
{
    double TpVZlz = -630257.6017040466;
    int wquBEeLJDaQz = 273304151;
    double WjmCZn = -276939.6921888108;
    int OhryQhu = -429963830;
    int hGWaTnzecpzhNV = -1723489079;
    string OgpPpVmykZcPsY = string("HQsXZEvJLSMlQqnlRFTOLIQtxUAowrqirUijdLyyjztrWYqVAWVSKFVLeNKXTgquYcMiDFuflmlUemKSZkqXQnrtEppaISGapziFcoVIKyPZTrqiwadWBmQ");
    int DnxdKXbuGf = -747331671;

    return DnxdKXbuGf;
}

int KnHxd::QyXxWyHJQLwFiBCx(bool BKjICuo, double PlCXy, double TSYIaYu)
{
    bool olhwwJzEtRrFc = true;
    double hQmTh = 999024.0120353671;
    string hdRXbriF = string("PjuwNaouJmtuBCtgMpjJGLxblvJyZCqRJYGncNmsxlivypdHmLpcnGkXiFGvQiBNAoDSLUSQdfqpkRpqtPYaKNzmjzLnuYqLzqDLSibPXxFGwTNxBcupFOGvfUjgunlOQuxmVrrUCQpwwFlGoMnDllfTyknUDJqVhlAHHhkeljtxpuCgLPwdJuvIeimYQBmFqUtGRchYsYPiQVXZLJucaQESkcyjFHNNrmCDxFMUHJnIRoOSuSCQzlrkxFGo");
    int kXhtqJgKJ = 23595854;
    int CKvWdupCtFK = 1564037313;
    double HGdpr = -271514.98092097713;
    int xttquCl = -996236102;
    string gWFmP = string("myTVaiRcUZuKYbrOdwokmgyozMsiQWrHuFpMDOpxOrMqXjbwaaPFssjqieVdEFESxsbaxGGOOA");
    string JJwIXBc = string("SfTsTOIzMDVRCSxFIdxsXSpYcwSPuLFpWvZWMmPZeoHoxtWABKhhsNujqRyeZReExRHSnmbSgmrrtdnUmPtrgcNykwJIfIQKFTtfhVTzhCcDDVdXdTUSmDjuLwVXoobqzuiVMPbDIWxmKVxlrTXZyYVorMVeEfvXlXPkHnOcNbcOTbQGYlIkhEhfXGLXkaBnmqBvOVaEglnIGkQJohwoXlbvENIDfJenRqGTfXHeIwMlYLIplI");

    for (int jbywFfjpqRWedvI = 794458935; jbywFfjpqRWedvI > 0; jbywFfjpqRWedvI--) {
        continue;
    }

    return xttquCl;
}

bool KnHxd::PjThgHsu(double LRHtBBPGHvebFWD, double ZIxDhcvGTW, int wFlHRTPAfgW, double tQVUi)
{
    bool aOaBLJ = true;
    string tRIPHu = string("nUYpZbxURFDKwfMgVTbBpUejogGEYTxmgyTibnhYTEFtFxAWxnzNGGisWKyaIwWKTIGIhDZWtZVXMZQfJeupoBwOKmemkNIUQSWinRrGWpyROeyNYHFOdIOtSr");
    string yZudpjmhoL = string("uYBKHwpaFtUbGfORYdPFOHQOERJtBlhmRkznqeCocBJyXYvllyWHEzkCdTxTSYIIBSKLOcqquIjLNgmKFUIYudJTaSduuESefJhbLMziFfBYHCBcmKwxNyONIafOKBGLgzNrBUyhbQGtSziOPFrgXawQuxdOmRIqEcBjjEjtqHYKtwvYqPGSqBsmfTCsVtdYBMztcbDMqNsZzwlBmWQNDHNyvIAswqtcVjWMxwEdPW");
    int actRuGR = -691974354;
    bool IizyvmEfTXqGSyEJ = true;

    for (int WfOLCCM = 103094762; WfOLCCM > 0; WfOLCCM--) {
        IizyvmEfTXqGSyEJ = aOaBLJ;
    }

    return IizyvmEfTXqGSyEJ;
}

int KnHxd::IvOtbNPjFggKgHIN()
{
    double ddKYXBlW = -817454.5807548615;
    int CYkoBuByIGsZNJMr = 1956619464;
    double jnajZ = 651904.0601103363;
    int DuljKhyZFiVQ = 694815279;
    bool xkmaKdHJzWIv = false;
    string IBzlPiFJiVKhPeHk = string("QfhuGPBEFlAYEUMXAOWPYNumQeTynWXcwHlruEmQZFFdrOrmkTwScqGsqscbrJgQQDQePQIuAhxmrnjnPqBAOTjXj");

    for (int tuALidDoL = 47170224; tuALidDoL > 0; tuALidDoL--) {
        xkmaKdHJzWIv = xkmaKdHJzWIv;
        DuljKhyZFiVQ /= DuljKhyZFiVQ;
        jnajZ /= ddKYXBlW;
    }

    for (int YFYKgsVtsLyQD = 1300990649; YFYKgsVtsLyQD > 0; YFYKgsVtsLyQD--) {
        ddKYXBlW -= ddKYXBlW;
        DuljKhyZFiVQ /= CYkoBuByIGsZNJMr;
        DuljKhyZFiVQ = DuljKhyZFiVQ;
    }

    for (int WaQmwnvC = 318984496; WaQmwnvC > 0; WaQmwnvC--) {
        IBzlPiFJiVKhPeHk = IBzlPiFJiVKhPeHk;
        xkmaKdHJzWIv = xkmaKdHJzWIv;
    }

    if (DuljKhyZFiVQ > 1956619464) {
        for (int yffEARrRgVPj = 1207776813; yffEARrRgVPj > 0; yffEARrRgVPj--) {
            ddKYXBlW += jnajZ;
            IBzlPiFJiVKhPeHk += IBzlPiFJiVKhPeHk;
            IBzlPiFJiVKhPeHk = IBzlPiFJiVKhPeHk;
            ddKYXBlW /= jnajZ;
        }
    }

    for (int UwAKHobRJPwMGCEi = 1916364286; UwAKHobRJPwMGCEi > 0; UwAKHobRJPwMGCEi--) {
        xkmaKdHJzWIv = ! xkmaKdHJzWIv;
        ddKYXBlW = jnajZ;
    }

    for (int PucJwXZWOp = 1342848746; PucJwXZWOp > 0; PucJwXZWOp--) {
        IBzlPiFJiVKhPeHk += IBzlPiFJiVKhPeHk;
    }

    for (int EjDwfsMyFMWh = 2136430169; EjDwfsMyFMWh > 0; EjDwfsMyFMWh--) {
        ddKYXBlW = jnajZ;
    }

    return DuljKhyZFiVQ;
}

KnHxd::KnHxd()
{
    this->KcvyTWnBeGnOe(string("RMzGltJbsSFzHHrmtJPGMeFCwBRQChDjbcdEUKTeXcnJNRmuPldzpGIlqIEalhBQWroOlvspqgSYwCQZSIvljYmBJevEbxIBimkN"), -83612.36477482048, string("vO"), 556273.6361921533);
    this->ZGVBqAzGnzqM(string("gsBwchcRLogWWjFidYRIILGNbyvBQJbdPMgfyQWhHRKKjjbXQUjVklHELJCwQkOrdKhFYdqkDlZIFlFRKBOaeHUzyiHKkqOezFEibDAXwlaqPvbBQyNPIxswOWWIMYWCCFpxJcXrJzAlnUrELsrYowcAXdJsmekcOvBpytqXxUqdjPGhoFIjjovUwxoCqbfQXLGmFoYgPzNw"));
    this->QyXxWyHJQLwFiBCx(true, -15067.107220567683, -178580.35228337208);
    this->PjThgHsu(-175418.54687000567, -485210.036871737, 347879497, 33998.35224548836);
    this->IvOtbNPjFggKgHIN();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vHXrthipon
{
public:
    bool EMqLEVqnyA;
    double AJxYSCqBnwe;
    bool oZlgCGOqlYGR;
    bool qxtbp;
    double dAJLYN;

    vHXrthipon();
protected:
    string XRnmcHLLHq;
    int qqiDlSIqv;
    string uvPNqenpOLoWXI;
    string OuoTgKvnzwvlGCFF;

    double GwvxYupD(string JCPHup, int mDhRsueVLlEMm, int nHjKQxaPrXEvJMAO);
    double xWXbmNTDFAYIbUwD(bool uUPSlZzR, double oFOSGYeIrYTSwDQu, double ZgaiEJOogm);
    int UnIMTPhBOUB(string xXVccnujpjlRaug, int goJVXoJtWKQJoPs, int QKisfMTgBj);
    string hTKXPrgjR(bool WfSNFeYDUd, bool cfoVVUL, int GJdDuAEmpISVCI, string MQHaj);
    int wcgoSBgnzi();
    int mTspOMbmfA(double zFGwGOBrcYv, int bRnOpxWLxNYzMir);
    int UYqyCyxtDPGM(string onvtexGPp, int wzFLPxsvvNbzko, int cnFjPn);
    bool gVPFaatZ(int fgYTWQyMQcz);
private:
    bool QMEQyCUvJr;
    string UhHlpjD;
    string YyHgGmHHBncmSme;
    int DijbaUhKaVxlZzXT;
    double PHrleTceaVhA;

    string lqGfucWnXamwG();
    string TxsGDkOZArZkoI(int yiHYziVhHJk, string FfhhQRfSd, int Fgmvv, int CZlRS, string ROEVS);
    double oParFSzDGWMd(int ZxEWZD, double cFZrwJKobh, double xMsZnCJRWnEEk, int cEDKWxBZ);
    bool AAepXXXgQxPfN(bool MYseIJlyVe, int KKrKDakHlrD);
    double BPYLHrJCivJfdiH(bool ByDDW, string BQVZSIgEPZ, int zqEImuLhve, string FFAvAINEKuSpw);
    double hhhecaMxb(bool MmDSfX, string JzZdaNjboxpmcU, string lNMOI, bool fZjgyDWAxTyoEz, double oFAuKRj);
};

double vHXrthipon::GwvxYupD(string JCPHup, int mDhRsueVLlEMm, int nHjKQxaPrXEvJMAO)
{
    string TtaRwFDmkmB = string("vXNMcWgwujlhByYZkxqmtlmBqbrxXuMEjlOUZNrHpNQgkbrphpiSYEbOizcOiLRSpmeImFAvYlheLrRbolilSavmbzS");
    int fgskgMP = 1082506012;
    double iNsvmjyk = 134626.3338478279;
    string AnWbyMWe = string("UNpKXngxfUaF");
    bool BhsBW = true;
    int yffPzfnQJjLYHlNc = -1068325151;

    return iNsvmjyk;
}

double vHXrthipon::xWXbmNTDFAYIbUwD(bool uUPSlZzR, double oFOSGYeIrYTSwDQu, double ZgaiEJOogm)
{
    bool DZBAqvesLCBzQZU = false;
    bool SdhmbFKfFU = false;
    int utTHbHXUkEDVugW = 677650556;
    double ChhYdHHSHFeJarOP = 600523.9643704353;
    double ZViLfrBmq = -550284.0305394215;
    double IUlNaxYjxBP = 982658.7407795065;
    double PBRHPEWyvr = -460415.38610913616;
    bool nAQlqoBy = false;
    string cMnafLRWO = string("dOoRYVNZOmoTluLzugpphpJHBnAhonGiEoXrHNUBkmGABBUcNSHkOyEByPlCyDEjWnYOXDIrxUjneckXcwGxfislpZJwCOONheSvNfaGlLtXnAVuuqPngWmyrdCVCVrdixPQGmiqx");

    if (oFOSGYeIrYTSwDQu != -182322.88174598722) {
        for (int iuYaeIkPbxeCRU = 1969282611; iuYaeIkPbxeCRU > 0; iuYaeIkPbxeCRU--) {
            continue;
        }
    }

    if (DZBAqvesLCBzQZU == false) {
        for (int jmiVFvTTgTKcAQM = 1522013795; jmiVFvTTgTKcAQM > 0; jmiVFvTTgTKcAQM--) {
            continue;
        }
    }

    return PBRHPEWyvr;
}

int vHXrthipon::UnIMTPhBOUB(string xXVccnujpjlRaug, int goJVXoJtWKQJoPs, int QKisfMTgBj)
{
    string FLMplMi = string("ZRofJkwURcXNpGbKvjSfPFCgRmOOlxvycQueYyjVhDyhGKGarGuoXUsZqLxzjdnaLLxhrQYPFiYvlLxYucmgofzVhXdsEfkdscwBHUVxKqTFOfALSdwlAkInLCdMdefEGOKssKSVlgwOJNAPVlJVHshjaxAsanPzhUEiWZNHMugPHLjCRXLsiAzCqTsGIBGQQQlwyrGqVOPWnhAyAOIgGpjePgBcufhedp");
    string JpwDtBCt = string("EGDFTSfMKStnmjfPTyolhLFFCMiWsomKLeIdubzPxwrXlnSldsAYcPDrcvNfhHJvHoCrxmxivUzsyTlWsYwenNYpDaGpBgSEJskoliBtkVfpOCGBYmqWTQUHAmzidmYpPWKjNKpHdNIlZdBeaPETtpLOCCofExrmrRRWDtfczLRwgzmohgftvgvrCINGyWHuSfxRIcochNkKkAHoXMsUIeMPmDDBVtwCaa");
    string czCtZCFCHHfZQk = string("izzjUsNHQZpgFUhDJUxQqGMQRHZeyIYCOasfbgIxbWNYiAuOUJDmCVNKJEWOuzphRYDCxfULqrVtQojEfuOXbQYYbXwPAdLeJLiVfYxUjcLNmdHmbeIyFQnOkXpQwHFhFiAHXYSmFjsCzavvGRRyjgZretvOuBvKdlGXCdHcPQjbHtaqFqVYgPdBHNSUfqPXhtPeQhNmil");
    string WndFZjYWPPrXUhb = string("mRaPSSvZDSowQwQnuRjLSfEZzUPGNdMLVxqUOikjAKNQgZEXrSoMWDTHvMNRTfzzyHBpHEjzRMEYMMpYhfDjIVjXCKhWltCoGFGFGEfBTVjOElqOOzgEqoWkKEXymknnaWeZINCYLexJAeHlJVZwuXjdqXbNwtvpURJPqLHlwoCDxnwY");

    if (goJVXoJtWKQJoPs != 1095535597) {
        for (int KfpQKAEyuvmAI = 53680190; KfpQKAEyuvmAI > 0; KfpQKAEyuvmAI--) {
            czCtZCFCHHfZQk = WndFZjYWPPrXUhb;
            xXVccnujpjlRaug += FLMplMi;
            xXVccnujpjlRaug = czCtZCFCHHfZQk;
        }
    }

    for (int muXRxiztQifxqDp = 378497316; muXRxiztQifxqDp > 0; muXRxiztQifxqDp--) {
        WndFZjYWPPrXUhb = xXVccnujpjlRaug;
    }

    if (xXVccnujpjlRaug < string("ZRofJkwURcXNpGbKvjSfPFCgRmOOlxvycQueYyjVhDyhGKGarGuoXUsZqLxzjdnaLLxhrQYPFiYvlLxYucmgofzVhXdsEfkdscwBHUVxKqTFOfALSdwlAkInLCdMdefEGOKssKSVlgwOJNAPVlJVHshjaxAsanPzhUEiWZNHMugPHLjCRXLsiAzCqTsGIBGQQQlwyrGqVOPWnhAyAOIgGpjePgBcufhedp")) {
        for (int vYoYsiHXU = 368330684; vYoYsiHXU > 0; vYoYsiHXU--) {
            czCtZCFCHHfZQk = WndFZjYWPPrXUhb;
            WndFZjYWPPrXUhb = JpwDtBCt;
        }
    }

    return QKisfMTgBj;
}

string vHXrthipon::hTKXPrgjR(bool WfSNFeYDUd, bool cfoVVUL, int GJdDuAEmpISVCI, string MQHaj)
{
    string SoTmAZaJgGmuiYtd = string("VRuGjLPEJlwTjFLVFYGoXbCdWCHaqCZlsEWCcoYBlbLxSHVduSwlhkqNImbBMfjXNemjtFTMVpnptHfBZouHBCLfKsorhdTdUrhfvwVAw");
    double tOmPnUNTxykRlFE = -353155.6982542818;
    int cSyzd = -1853605873;
    bool XNfOEUMua = true;
    double rBpFPQabxfsDM = -1005114.860985904;

    return SoTmAZaJgGmuiYtd;
}

int vHXrthipon::wcgoSBgnzi()
{
    bool FxFLuoNeVzX = true;

    if (FxFLuoNeVzX != true) {
        for (int BUXpMgDbWiOQLiu = 712096184; BUXpMgDbWiOQLiu > 0; BUXpMgDbWiOQLiu--) {
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = FxFLuoNeVzX;
            FxFLuoNeVzX = FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = FxFLuoNeVzX;
            FxFLuoNeVzX = FxFLuoNeVzX;
        }
    }

    if (FxFLuoNeVzX == true) {
        for (int dZojqqgnRCIeQpTv = 35157792; dZojqqgnRCIeQpTv > 0; dZojqqgnRCIeQpTv--) {
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
        }
    }

    if (FxFLuoNeVzX != true) {
        for (int bwQjeCFeGoD = 409186650; bwQjeCFeGoD > 0; bwQjeCFeGoD--) {
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
            FxFLuoNeVzX = ! FxFLuoNeVzX;
        }
    }

    return -86615599;
}

int vHXrthipon::mTspOMbmfA(double zFGwGOBrcYv, int bRnOpxWLxNYzMir)
{
    bool VhtHqwvbVLWXph = false;

    for (int KPlzjMIJwC = 209820390; KPlzjMIJwC > 0; KPlzjMIJwC--) {
        continue;
    }

    for (int ccrDqqOfYKvCI = 1996662036; ccrDqqOfYKvCI > 0; ccrDqqOfYKvCI--) {
        VhtHqwvbVLWXph = ! VhtHqwvbVLWXph;
        VhtHqwvbVLWXph = ! VhtHqwvbVLWXph;
        bRnOpxWLxNYzMir -= bRnOpxWLxNYzMir;
    }

    for (int shfNQ = 2044913605; shfNQ > 0; shfNQ--) {
        VhtHqwvbVLWXph = VhtHqwvbVLWXph;
    }

    if (zFGwGOBrcYv == -922578.7647644159) {
        for (int BVUoEtVslaWNh = 2135118083; BVUoEtVslaWNh > 0; BVUoEtVslaWNh--) {
            VhtHqwvbVLWXph = ! VhtHqwvbVLWXph;
        }
    }

    for (int ldAeskZXptZvmFq = 416791034; ldAeskZXptZvmFq > 0; ldAeskZXptZvmFq--) {
        zFGwGOBrcYv += zFGwGOBrcYv;
    }

    for (int nVUixzHoVlwAF = 1108716168; nVUixzHoVlwAF > 0; nVUixzHoVlwAF--) {
        zFGwGOBrcYv += zFGwGOBrcYv;
        VhtHqwvbVLWXph = VhtHqwvbVLWXph;
    }

    return bRnOpxWLxNYzMir;
}

int vHXrthipon::UYqyCyxtDPGM(string onvtexGPp, int wzFLPxsvvNbzko, int cnFjPn)
{
    string VlmaYArOSmKicDsC = string("nzMZRvDklgMmcTYrZThJBnRNgyvWVCObMWIrNWYaGmAZahWvEmbDxrqfLcQCfjxwRPIGHUNCUqNXiWwxkjaeEBGINpHRZKufTZxbRrh");
    double htzOQfAwJyIKQUlq = 949497.6417531156;
    bool aGTdRWf = false;

    for (int nRbTluqiXrdDWJR = 1074054223; nRbTluqiXrdDWJR > 0; nRbTluqiXrdDWJR--) {
        VlmaYArOSmKicDsC = onvtexGPp;
        wzFLPxsvvNbzko = cnFjPn;
        wzFLPxsvvNbzko -= cnFjPn;
        aGTdRWf = ! aGTdRWf;
    }

    for (int dXShQrifU = 46285882; dXShQrifU > 0; dXShQrifU--) {
        wzFLPxsvvNbzko = cnFjPn;
    }

    return cnFjPn;
}

bool vHXrthipon::gVPFaatZ(int fgYTWQyMQcz)
{
    double eqSxZBYS = 85083.98859325126;
    bool xtkvd = false;
    string mPftycxGAohVAb = string("cIZOEzOMtHqxbfqHtMSzPHQYJFACvaYuxmwqXwGbcJPFbElCLxjmtyTXVoDKiejrbKyVilpbHsGTZdCyfGkDdxDbVMTKwkauCPPhtMaBYHjPtBnDyJsZYdGPmQzAaeuCIdbExhdWXlAMbQUGowPhupFPkJqIdaskkFnCWyrLEYopr");
    int qDoHoHRetpPQQc = -1919502518;
    double fQwYFgEjTwSj = 295034.33674323495;
    double bQUxItHiv = 645905.5907965065;
    bool jJAZrPNMSbZy = false;
    double jhKHULSycWk = -577058.8577765658;
    double MyRyB = -452658.7162067833;
    string MLlHGAHeDbBlulz = string("eDRQPXnOWJsYddaxikrNFkQSaLJwfmJXDrAvknGXILunIeILZGAaedowyqeWTcoKhXymQcYiplFwepCuCIadNqiPFVuShFutdjYDnuLWiXaTjpKFkoqZLnNUxqAsxdaoJAwsoIwRROdW");

    for (int oZlDyBNIamDUUt = 1467050598; oZlDyBNIamDUUt > 0; oZlDyBNIamDUUt--) {
        MyRyB *= eqSxZBYS;
    }

    if (jJAZrPNMSbZy != false) {
        for (int ayNLyRJQ = 218142036; ayNLyRJQ > 0; ayNLyRJQ--) {
            continue;
        }
    }

    return jJAZrPNMSbZy;
}

string vHXrthipon::lqGfucWnXamwG()
{
    bool ebylIzJFF = false;
    int GUWnVaolw = -1546156759;

    for (int JnUIGg = 891027553; JnUIGg > 0; JnUIGg--) {
        ebylIzJFF = ebylIzJFF;
        GUWnVaolw += GUWnVaolw;
        ebylIzJFF = ebylIzJFF;
        ebylIzJFF = ! ebylIzJFF;
        GUWnVaolw += GUWnVaolw;
    }

    if (ebylIzJFF == false) {
        for (int lFsaZBfYxbN = 1351720785; lFsaZBfYxbN > 0; lFsaZBfYxbN--) {
            continue;
        }
    }

    for (int pYJeea = 1667987999; pYJeea > 0; pYJeea--) {
        ebylIzJFF = ebylIzJFF;
        GUWnVaolw = GUWnVaolw;
    }

    for (int jgLUNYDEyvgyQS = 1608980604; jgLUNYDEyvgyQS > 0; jgLUNYDEyvgyQS--) {
        continue;
    }

    if (ebylIzJFF != false) {
        for (int FHvCkkc = 1521749524; FHvCkkc > 0; FHvCkkc--) {
            GUWnVaolw += GUWnVaolw;
            GUWnVaolw *= GUWnVaolw;
            ebylIzJFF = ! ebylIzJFF;
        }
    }

    if (ebylIzJFF == false) {
        for (int plbFDjXRXxhf = 1482432159; plbFDjXRXxhf > 0; plbFDjXRXxhf--) {
            ebylIzJFF = ! ebylIzJFF;
        }
    }

    for (int hpeVbfkXLx = 346494693; hpeVbfkXLx > 0; hpeVbfkXLx--) {
        ebylIzJFF = ! ebylIzJFF;
        GUWnVaolw *= GUWnVaolw;
        ebylIzJFF = ebylIzJFF;
    }

    return string("XTziFvJMSTUEFkWESvRAdCxSUfUtrEeYSefojQBHVsWfxCaopwCRVocNSVFFPkLjcTKHobIYCCeEkXgZGLqaxXktNWKcWaRYAQoXibOtBye");
}

string vHXrthipon::TxsGDkOZArZkoI(int yiHYziVhHJk, string FfhhQRfSd, int Fgmvv, int CZlRS, string ROEVS)
{
    double gWlEdCYlpwQpAcZf = 894041.0579905938;

    if (CZlRS <= -1579435554) {
        for (int edvupXnON = 1310001287; edvupXnON > 0; edvupXnON--) {
            gWlEdCYlpwQpAcZf = gWlEdCYlpwQpAcZf;
            yiHYziVhHJk = CZlRS;
            Fgmvv += CZlRS;
        }
    }

    for (int LobLCY = 1629346836; LobLCY > 0; LobLCY--) {
        Fgmvv *= Fgmvv;
    }

    return ROEVS;
}

double vHXrthipon::oParFSzDGWMd(int ZxEWZD, double cFZrwJKobh, double xMsZnCJRWnEEk, int cEDKWxBZ)
{
    int TVdtMNnDh = -1928311036;
    bool wOgRvHrlyRZnZRCc = false;

    for (int LpaPsX = 403825062; LpaPsX > 0; LpaPsX--) {
        TVdtMNnDh += cEDKWxBZ;
        wOgRvHrlyRZnZRCc = wOgRvHrlyRZnZRCc;
        cFZrwJKobh /= xMsZnCJRWnEEk;
        xMsZnCJRWnEEk -= xMsZnCJRWnEEk;
        ZxEWZD += cEDKWxBZ;
    }

    if (TVdtMNnDh == 392625309) {
        for (int NownXBY = 1220706297; NownXBY > 0; NownXBY--) {
            cFZrwJKobh += cFZrwJKobh;
            ZxEWZD *= cEDKWxBZ;
            cEDKWxBZ = TVdtMNnDh;
            TVdtMNnDh = cEDKWxBZ;
            ZxEWZD *= cEDKWxBZ;
        }
    }

    if (cEDKWxBZ <= 392625309) {
        for (int ocPZgr = 1744916598; ocPZgr > 0; ocPZgr--) {
            ZxEWZD /= cEDKWxBZ;
            xMsZnCJRWnEEk -= cFZrwJKobh;
            TVdtMNnDh = ZxEWZD;
            xMsZnCJRWnEEk /= xMsZnCJRWnEEk;
        }
    }

    if (cFZrwJKobh > -227171.68657631872) {
        for (int laRLom = 221970927; laRLom > 0; laRLom--) {
            cEDKWxBZ *= cEDKWxBZ;
            cFZrwJKobh = xMsZnCJRWnEEk;
            cEDKWxBZ *= TVdtMNnDh;
            cEDKWxBZ += TVdtMNnDh;
            cEDKWxBZ += TVdtMNnDh;
        }
    }

    for (int lDEdYerYQLc = 1538191475; lDEdYerYQLc > 0; lDEdYerYQLc--) {
        cEDKWxBZ -= ZxEWZD;
        ZxEWZD += TVdtMNnDh;
    }

    for (int rNawEfJVhPZ = 377181207; rNawEfJVhPZ > 0; rNawEfJVhPZ--) {
        ZxEWZD += ZxEWZD;
        cFZrwJKobh *= cFZrwJKobh;
        ZxEWZD *= TVdtMNnDh;
        cFZrwJKobh *= cFZrwJKobh;
    }

    return xMsZnCJRWnEEk;
}

bool vHXrthipon::AAepXXXgQxPfN(bool MYseIJlyVe, int KKrKDakHlrD)
{
    string IBkNQVuwlg = string("YLWwbQZPvEbeiHjrUFqRizSlIDMBebJvVwYgYhFYkQlOYKiOducCMYtxCryZqWFGBjmXmPtcCmMCHBviOIAahOAvhjxjFqBvUVYQVbeAZDGJKJndNSOlXptXqRNQItqVDJTlIPOkTCgeKiTEYGbciWOJxQrrNrWujgdnycTucARoXeYNfEGNAfEYhCYwEPIKjsMkxWUtlRjFwQMLWDGcdzmtZgYWgysHtPNaoUKZxulVZBZANlXTgIja");
    string QJkZRqqyxsg = string("latQromnGDzbnEQSmmVpJxPjINPmppWwGOYZxOmrgxYJshqQcKMqCrZIyriPCVwHFtbvPROrSUrYeHdbKXtVnlUvwlncURQSVIyTnKjqmWGJYCqKHUwiBpMuLLhFcbiEjaiyOjAQNxoyqwUVNCqKjRdGJu");
    int enNCQ = 1434878863;
    bool EoyWZe = false;
    bool jOtAIWVEXao = false;
    bool yhKoNKBFsVRHMnSl = false;

    if (QJkZRqqyxsg != string("YLWwbQZPvEbeiHjrUFqRizSlIDMBebJvVwYgYhFYkQlOYKiOducCMYtxCryZqWFGBjmXmPtcCmMCHBviOIAahOAvhjxjFqBvUVYQVbeAZDGJKJndNSOlXptXqRNQItqVDJTlIPOkTCgeKiTEYGbciWOJxQrrNrWujgdnycTucARoXeYNfEGNAfEYhCYwEPIKjsMkxWUtlRjFwQMLWDGcdzmtZgYWgysHtPNaoUKZxulVZBZANlXTgIja")) {
        for (int puiAbwIOa = 2039835040; puiAbwIOa > 0; puiAbwIOa--) {
            IBkNQVuwlg += IBkNQVuwlg;
            MYseIJlyVe = ! yhKoNKBFsVRHMnSl;
            enNCQ = enNCQ;
        }
    }

    if (yhKoNKBFsVRHMnSl == true) {
        for (int cTJtRX = 927439500; cTJtRX > 0; cTJtRX--) {
            yhKoNKBFsVRHMnSl = ! yhKoNKBFsVRHMnSl;
            MYseIJlyVe = ! EoyWZe;
            EoyWZe = ! jOtAIWVEXao;
            QJkZRqqyxsg = QJkZRqqyxsg;
        }
    }

    for (int LLJHzqPQGtufFiUh = 701646632; LLJHzqPQGtufFiUh > 0; LLJHzqPQGtufFiUh--) {
        continue;
    }

    if (IBkNQVuwlg < string("YLWwbQZPvEbeiHjrUFqRizSlIDMBebJvVwYgYhFYkQlOYKiOducCMYtxCryZqWFGBjmXmPtcCmMCHBviOIAahOAvhjxjFqBvUVYQVbeAZDGJKJndNSOlXptXqRNQItqVDJTlIPOkTCgeKiTEYGbciWOJxQrrNrWujgdnycTucARoXeYNfEGNAfEYhCYwEPIKjsMkxWUtlRjFwQMLWDGcdzmtZgYWgysHtPNaoUKZxulVZBZANlXTgIja")) {
        for (int lBcoUgPHecl = 1640569682; lBcoUgPHecl > 0; lBcoUgPHecl--) {
            yhKoNKBFsVRHMnSl = ! jOtAIWVEXao;
            jOtAIWVEXao = ! MYseIJlyVe;
            QJkZRqqyxsg += IBkNQVuwlg;
            yhKoNKBFsVRHMnSl = ! MYseIJlyVe;
            KKrKDakHlrD = KKrKDakHlrD;
            yhKoNKBFsVRHMnSl = yhKoNKBFsVRHMnSl;
        }
    }

    for (int piYfl = 1443006270; piYfl > 0; piYfl--) {
        KKrKDakHlrD = enNCQ;
        jOtAIWVEXao = ! EoyWZe;
        EoyWZe = yhKoNKBFsVRHMnSl;
        yhKoNKBFsVRHMnSl = ! MYseIJlyVe;
    }

    return yhKoNKBFsVRHMnSl;
}

double vHXrthipon::BPYLHrJCivJfdiH(bool ByDDW, string BQVZSIgEPZ, int zqEImuLhve, string FFAvAINEKuSpw)
{
    bool txqHsBJDGPPmYa = false;
    string ifaOuskI = string("mEuWwNzeZgbPsuMFJwIYgszGqGDPgicwcWzSBPQfGyGMwETcXnTiwhOjEdijifgHqTyucjCVuQKlSjKofyglvf");
    double GjlxSlzKwXVm = 458583.11456153117;
    double mHXTmx = -368710.15901529527;
    bool XCJDdymKhjudT = true;

    if (ByDDW != true) {
        for (int bpwwZZ = 1949346190; bpwwZZ > 0; bpwwZZ--) {
            FFAvAINEKuSpw += FFAvAINEKuSpw;
            FFAvAINEKuSpw += FFAvAINEKuSpw;
        }
    }

    for (int aZsIkuCi = 71419360; aZsIkuCi > 0; aZsIkuCi--) {
        BQVZSIgEPZ += BQVZSIgEPZ;
        XCJDdymKhjudT = txqHsBJDGPPmYa;
        zqEImuLhve -= zqEImuLhve;
        FFAvAINEKuSpw += BQVZSIgEPZ;
        FFAvAINEKuSpw = ifaOuskI;
        txqHsBJDGPPmYa = ! XCJDdymKhjudT;
    }

    return mHXTmx;
}

double vHXrthipon::hhhecaMxb(bool MmDSfX, string JzZdaNjboxpmcU, string lNMOI, bool fZjgyDWAxTyoEz, double oFAuKRj)
{
    int mScHqvfOyvBtvGQ = -526118398;
    bool kCnqILkppWdJqIef = true;
    double jdsljDIJkmFSmrn = -555417.7229672981;
    int XZUvvIDjQ = 1604479690;
    double FMePVPcfIwiy = -299157.7053941776;
    double CajDYfgFOuAjkyoN = -25489.113100962062;

    for (int eoBzTcsc = 1391481347; eoBzTcsc > 0; eoBzTcsc--) {
        oFAuKRj -= jdsljDIJkmFSmrn;
    }

    return CajDYfgFOuAjkyoN;
}

vHXrthipon::vHXrthipon()
{
    this->GwvxYupD(string("hfpcRokVpTaCCOYPqwmLrbKwyVynnQxlsuzCSQVITLHOaJweHXHrhvNzpzlhaliDDDGgNJXBqMBbMkXkRfRLIAzOFNUZxsHlNxdvAXabsErODUmfpDSHBHmubskBWlIBnRPlZcPPkvSoxsSCDYjpjyvILmjbqnmmNzkvjTIekcxfNtaiYvdrYgjypVFIVNRPBJIYOENvuyQHaRrxmUEPte"), -770253776, 1703706492);
    this->xWXbmNTDFAYIbUwD(true, 995858.0188744506, -182322.88174598722);
    this->UnIMTPhBOUB(string("MNlMGyYkAqjVEvKptTlhKGnFCwuZHRhoOTderVoENGRgRKbPROWqRLMvuFxDxpBIrCkNSInoEuPlaa"), 1095535597, 1360132888);
    this->hTKXPrgjR(true, false, 186964620, string("HBepMNXfxlOcqVCcRloKyoXuqaRgUVxhFQuarlYLqwbRKDkNwTuvjfalFYRZPUXXDaddRMbYthsxQZfAFVVCfLYZUpadKNzKtgauuQTy"));
    this->wcgoSBgnzi();
    this->mTspOMbmfA(-922578.7647644159, -49645676);
    this->UYqyCyxtDPGM(string("qvDKrLGGJHRSvqsEhdalHoZKamHvJosWtTGtiocdblAXyXHxnZNrqItRenBCmCAwhFUolVCrDbBUCRKMGOzBsKArjiEHWAF"), 422757194, -914087647);
    this->gVPFaatZ(-827190419);
    this->lqGfucWnXamwG();
    this->TxsGDkOZArZkoI(-813637724, string("LBgTMvZacNFDqJkOIHFJEtgsQktuTFIhOKcEEKMaLeXngekIwfinvOAcguhciLJlbkeKVwsfVoRoabThGgkrFQDisyqlLEaOOpoaPFLNhorhTbYLHSfBBjyidKc"), -558921817, -1579435554, string("hcvjQHWxTwnsCQhzrFdcbbdsSozbyLXVVqIjDbjwSGIIZflLKLamtfqKyWQMftmtzTrmvLrOklknUDUHmweFTKbWTaknpXqkoZRwmNeNSTziapzGGBtHHWhnENFKlaIjQUHkTgyTFAoUbe"));
    this->oParFSzDGWMd(-1742196754, -350852.1167303131, -227171.68657631872, 392625309);
    this->AAepXXXgQxPfN(true, -1455927780);
    this->BPYLHrJCivJfdiH(true, string("MpKoUsckoSbsSJnCgJtnAHLAVnOzZnwckvPqxzkZVkDarsvjafBsQEXgDXFElnzfTzkZILAqVHXEsXqaNTRuBZRWHFOlljqVFwdhtkKpAJkNlhoaiwpyWhWPosnKqyiUfMAqboCUmpGSEzRrxKzqZWJTMOkErkKXOgMOmjFXTnlxlSZRDozkIxkbFwZsO"), -1225775371, string("hYMeISeNSnkhOuAyGUPsoUMrwxDTIxGQtSqtLtrRDm"));
    this->hhhecaMxb(true, string("eXFYMzPAUnbchcfggcpfvstzOONQb"), string("dQoFCtCFioNgqrnBxZmHexRBWTtgrgRyCHeBgwVPrWdGKAJGwDwBDvXQBmkBHYfzNShFHTzgqyRnBUoQpzAoYRl"), false, 891713.9006466273);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gKrUgK
{
public:
    double okpnNS;
    int dkwVexMSwM;
    int IDVRXTQooGQBCWd;
    double TQpXo;
    int WEMWMklcMZASpo;
    string hyBfpgmp;

    gKrUgK();
    void bwDmx(string qBuzZmlUVCmG, string aIzTzmpA);
    void MUmfg(string EciioDgjGnzhSQr, string OiskJhIKZca, string mDKtdtaFvut, bool OYzMxegddMxWVtKs, bool kBKcyAVKIxQ);
    int nXGVPxTux(bool fPJnZIZy, string KhKqAjGDIQzXIq, int welcWxxXpfWOkSvd, int UrhaMDnQB);
protected:
    double DzagCJVGtfVa;
    double TrNbMGX;

private:
    int SiWkYEmXa;

    void OvkOGecI(string RYCJEGjfggsYZBF, string PMBzhfSmV, int ogXEPbGioURU, bool kWQknpo);
    string kbJcoVOCuomLT(bool AWCfis);
};

void gKrUgK::bwDmx(string qBuzZmlUVCmG, string aIzTzmpA)
{
    string TwPDMsffpPowIkA = string("zSytNUTtGuYnSFmFFBDWqPjviwPhzfFepHiehpehEAdylkvNsOJolej");
    double xSlFkxM = -36171.01640707652;
    double yGUiEVrTsSQJxE = -314553.4638714315;
    bool BAUOEqCKLr = true;
    string adIaqOUBR = string("vOHAFqFewdQDwekJBTkhAWEthtqDEURVSucZuPDCXtsmZWXaAMtvQPTroOygyEjXMKMPBeUeNhwqxfZafPdftnbOsOdKvXsMhAtuUkkeTtByRDWCuBoRQsxLUawcxUujQyhmKVdXwNJPoezHdbCShmuzKnYEHHiciaLPTKskAJYheGDsfvPQStDGtxxszRnBYTgLwrMkMUUOFvyATAZsdJnvLUJWTMxG");
    bool TEhdMopUen = false;

    if (TwPDMsffpPowIkA != string("heMCokhSRjaddmPwcjjlIVJyeLwGhYMeYfvVkxlgyZqDDZmZuzPwWSVzBeETqhWhJESGOrEsNmNklCJtGqewxbDFejddGpJuycVShCuBmUOTspMllnyIJJxiOFMgbrPnmShyUNdkpaFMIOByrKtJyQRyKWQgV")) {
        for (int YMxwCbJjag = 1543906816; YMxwCbJjag > 0; YMxwCbJjag--) {
            qBuzZmlUVCmG = qBuzZmlUVCmG;
            BAUOEqCKLr = ! BAUOEqCKLr;
            TwPDMsffpPowIkA = adIaqOUBR;
        }
    }

    if (aIzTzmpA > string("vOHAFqFewdQDwekJBTkhAWEthtqDEURVSucZuPDCXtsmZWXaAMtvQPTroOygyEjXMKMPBeUeNhwqxfZafPdftnbOsOdKvXsMhAtuUkkeTtByRDWCuBoRQsxLUawcxUujQyhmKVdXwNJPoezHdbCShmuzKnYEHHiciaLPTKskAJYheGDsfvPQStDGtxxszRnBYTgLwrMkMUUOFvyATAZsdJnvLUJWTMxG")) {
        for (int QQYJLzJJfPIB = 1804570473; QQYJLzJJfPIB > 0; QQYJLzJJfPIB--) {
            TwPDMsffpPowIkA = qBuzZmlUVCmG;
        }
    }

    if (TwPDMsffpPowIkA == string("zSytNUTtGuYnSFmFFBDWqPjviwPhzfFepHiehpehEAdylkvNsOJolej")) {
        for (int hJiod = 955745710; hJiod > 0; hJiod--) {
            TwPDMsffpPowIkA = TwPDMsffpPowIkA;
            TwPDMsffpPowIkA += qBuzZmlUVCmG;
            BAUOEqCKLr = ! BAUOEqCKLr;
        }
    }

    for (int IscxTWmQZCbPQ = 399284451; IscxTWmQZCbPQ > 0; IscxTWmQZCbPQ--) {
        adIaqOUBR += TwPDMsffpPowIkA;
    }

    for (int ANxTtA = 373551370; ANxTtA > 0; ANxTtA--) {
        aIzTzmpA += adIaqOUBR;
        yGUiEVrTsSQJxE += yGUiEVrTsSQJxE;
        qBuzZmlUVCmG = qBuzZmlUVCmG;
        qBuzZmlUVCmG = qBuzZmlUVCmG;
    }
}

void gKrUgK::MUmfg(string EciioDgjGnzhSQr, string OiskJhIKZca, string mDKtdtaFvut, bool OYzMxegddMxWVtKs, bool kBKcyAVKIxQ)
{
    string pMUjY = string("PEJNYSOWQdlBYErpfpeXOVmRTbHmkGUdJbRhgGSjOVHXJBZrubqSXSMfmCkYdxRSLkNlXQYRfKCjBnLjoSQFvQfrgyOtHuJCcclbO");
    bool rTywkLDRxHBCQHMy = true;
    bool YefBDJWnjXC = true;
    double EgPYmiwTdJ = 59897.68996033254;
}

int gKrUgK::nXGVPxTux(bool fPJnZIZy, string KhKqAjGDIQzXIq, int welcWxxXpfWOkSvd, int UrhaMDnQB)
{
    string kFQxfNmbLlVeUYYb = string("pIjotaBbSBEduVgIMrsyApaFuRInAVXUsnWCvAXQFPtsuShYWoGSsfAJmcYjuiEsvpzskrZGqweUMhcKKjWNpVnngtiYitwbLHlibchHdvUHVYUOWnSnrjHXgqfwwSqhofxrTJcRlUgZpvbzJTgICqWFEqHcPWPpgZaAhDhwRiVgMSBAQzOjehQJSpPvMuNZobMRwsXyhsWPzqOqRbeqZxqZRBVqOccAppCjWrTwzghEhXyldXX");
    double sPyxerwnkqZg = -172821.6533746135;
    double qBqTNHJGen = -591957.1280707797;
    int UwmLFFIJqEU = -1601068791;
    int SQxnAQFBGmOTC = -710353104;

    return SQxnAQFBGmOTC;
}

void gKrUgK::OvkOGecI(string RYCJEGjfggsYZBF, string PMBzhfSmV, int ogXEPbGioURU, bool kWQknpo)
{
    bool cxrJsgSGC = false;
    double zKruRf = -723026.1251705881;
    string jRqJIWr = string("gwARgkFmeUsBvtGBUCPsoIWMpDRqtGUvPJdwXRULQJOLgafJKMlfRujHGDupXukZwPqZUczaCeBSfDVmWCOGetUBABnnfIrTRdWIojEaBFJzUJyWTQrTQbZQDgzbpCvTpqOFfAlBkjKWPBQSxpULOWlQOrZJrtgeUxElQzWpqPTxdJmbUgXYfUewSWzcxGuwsAJKCWCPnXDARfyNSvBCCSYjzQTkplRLHZmhFf");
    bool HegKizRKlbf = false;
    int hUjtjjYhLN = 274117390;
    bool qjnNIFkLWMmovAy = false;
    string GdiKUNvD = string("jXZwCcDaGTniXPXebHNMzArqGaRBqgfmWarhEZdDghReAbrebrPLpjgrzhIsrlFbgHAilVLuEeoHLRMuIWoPcgpdxjWPpzsjkYbVJOCEWkfWADCpKuqwDhQYUffKdThxVsUrlVIrCJjuNNBikeCpMpMgayybOPjrCTmOJwOUEkEZNntVTsFSeUbJCkDZADhmdYqgtbdhZbUlHDrkcBQYwtTKbBuRZDUdZXNiQMZXqoLFOoE");
    bool ISUFCzmNxRJ = false;
    bool ODxHSfA = true;

    for (int ZEPfivFYHTiMawOA = 860823197; ZEPfivFYHTiMawOA > 0; ZEPfivFYHTiMawOA--) {
        HegKizRKlbf = ! cxrJsgSGC;
    }

    for (int aAySUf = 1027398715; aAySUf > 0; aAySUf--) {
        cxrJsgSGC = ! cxrJsgSGC;
        ODxHSfA = ODxHSfA;
        kWQknpo = ! cxrJsgSGC;
    }
}

string gKrUgK::kbJcoVOCuomLT(bool AWCfis)
{
    bool DCiWBOYJIFFDNh = false;
    string icuTOBSMh = string("FddLFxzAtXniUCYtApcvoUdfJysUgTXtFEAnIWbOwZdDgouQPMHnzpajPpcNXmBGmgsInrfHITMKyqtRkfeupUKseGPVEsOKxJvgfdRJvLYQnpJYnxbIzkIqtIYGVcZzKFfjYTtpOJGvlkTTeBAZXrEBzdRwKBehXiM");
    double hyRsiBamPqjTY = 193798.68662630662;
    double gFMrHCgK = 75540.47125012921;
    double cQpSuMQlUop = 551573.8096342956;
    int swKTBRoHTu = -1039589847;
    double UfBWrYaN = -852052.0465034056;
    string aTrFDdbcOZ = string("FCsTJTxsIVhgDRSxEmnAKmVqvNGLqUwoqNnMDfVQBMQMzmIavD");
    int VqMYAfwLgTY = 174416393;

    for (int kpIECvHD = 1804981873; kpIECvHD > 0; kpIECvHD--) {
        AWCfis = ! DCiWBOYJIFFDNh;
    }

    for (int rfAhbs = 1014977740; rfAhbs > 0; rfAhbs--) {
        AWCfis = ! AWCfis;
        cQpSuMQlUop -= UfBWrYaN;
        hyRsiBamPqjTY = hyRsiBamPqjTY;
    }

    if (aTrFDdbcOZ <= string("FCsTJTxsIVhgDRSxEmnAKmVqvNGLqUwoqNnMDfVQBMQMzmIavD")) {
        for (int fOHGgpiqPGawqovP = 1436331379; fOHGgpiqPGawqovP > 0; fOHGgpiqPGawqovP--) {
            DCiWBOYJIFFDNh = DCiWBOYJIFFDNh;
            AWCfis = AWCfis;
            cQpSuMQlUop += UfBWrYaN;
        }
    }

    return aTrFDdbcOZ;
}

gKrUgK::gKrUgK()
{
    this->bwDmx(string("CPDQIMFCxlnRDVWwHZsnGRtbGmkkI"), string("heMCokhSRjaddmPwcjjlIVJyeLwGhYMeYfvVkxlgyZqDDZmZuzPwWSVzBeETqhWhJESGOrEsNmNklCJtGqewxbDFejddGpJuycVShCuBmUOTspMllnyIJJxiOFMgbrPnmShyUNdkpaFMIOByrKtJyQRyKWQgV"));
    this->MUmfg(string("rnKwSQxmNQIUPlrFaEORFRXWavLKVWubAnmwmsXFZvaugUKvKxzdQonJgClkedACtveerAkIPLCIOuEFMthXmxZXCaDBjktdamFQgyIrSifmvAJUnQDSQWdzHVxROiqtTiOrDkmmtUambfRRULMitRxnNPChYvPIPfbcECiV"), string("IyirlzEpnxunRsSJDfkFHwGgMuMROXTfXtLszFVSrZBBDgAwsTxdHYqCEjzyxiCdAZqLXEIFvuKHyJvBOWjgaeAUldIjKIPYLaeLpPFXvlxsqoErCJTtSCeXODNbYfSaknJGJSisSXiwUzdEdUwINB"), string("TTngFJXGjlTUsbpoarVIUvEoVJqcIbwFPqagXbXnwgFhwsLaAeBMyrFlXPTPzAqcCkOYhxvnDylFLjLGmejiXPqaPRkaOQgfPEHjvwdHqKCuulnuuQwmpcKYdcBsvjkxeQQTElbbEcoRzUvCJTIQsIiUOxnHQiR"), false, false);
    this->nXGVPxTux(true, string("HdlDmHZSiNLdCsSASeGUCtYkvIrfjIiYUZxDfYLGyudBWFJkdXhRiePhqJdVVKnVmCbmxrBMhsVMaXYzUGwqglZuwLlqNVnNhCDqfRpetmuZDACzEAHNCsNLpRbSXSCPLcxDJOUsZQLeHaYxQfVpwSsVEfPcOtgQIrzWMuvuqPuCokQPQWlrNlMkbcVpL"), -199203466, -2008760157);
    this->OvkOGecI(string("LifONdGZzALPvQCkACzcTUxDTOVADRAvwxZGFmDDJOCZzffEpkRpOvRPiAnzLBqVlUFhfZmPSAasKGXKadvqXqRzSdFAtShzcSALZeFMrjCiUsAYrlFPdFdGHpjJrtRMJTHjPWqEiQ"), string("yMALHrMMgrtImAfujHnBPyNVMCEWxHGWqTiFZYkftrUVbTwKodrvVwUbkeBwxqO"), 697841535, true);
    this->kbJcoVOCuomLT(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dEHTWbDnmBgqz
{
public:
    int PWAwfNZB;
    int rXVeBDwExROCPAG;
    int CLGbyEFX;
    int idbJkPDZpIJH;

    dEHTWbDnmBgqz();
    void dQgosvW();
    void KzyMQGl(string QCHntg, string wuANVZWnX, double oiCRWNHRwJGqmiXy, bool gVTcsRcw);
    string YRsuqlFFzXZ(string iTElWyuhGH);
    void wnsXEMKJU();
    void UFSwHXUcOm(string yZurWmdugahxX, double UPssBZvKt, int ImauRcKDjwOp);
    int oaZfEhHjOL(double wVVrB, int dkYPHGkjMEjAZhsz, bool KpewdbcudBtTC);
    bool haXCmnixGcv();
    bool xXoaM(double eJZVtHne, bool QqrmiMESqbrqMSj, double BLMaKaEPfQNVfqAd);
protected:
    double fyKbIAwxLT;
    bool bzrXNHFBsB;

    int XjHEJwqRfNMKl(double bjZpjefAHdIuh, int xUXqNiKb, int XaCFyWbLHcUiL);
    bool cbbuRx(string lovVIUJE);
private:
    bool zzfbhYUFygU;

    string mFXjCqIvaGroMvg(bool siTdjHSTBJvYOki);
    double EcXxjuRaLVNs(double nnXCxxVRHTLLs, string zSqsPjJnkRLUKzD);
    double uqVnMBzCxOHef(bool zNOCtkzMXRNs, int xRaJmlNIqRRpx, bool uzQQzreVMeY, double njtwqSyrFg);
    int TUWOgspdHRZbiZ(bool FrPgonmfmR, double vmWBwUVRjLqNOnV);
    string QXjqTPGqJl(double LGZSqDMxiE);
    int tbvGqzKQaGBycY(double BsdsVxnwa, bool YIPJHYdOCSVwTUHG);
};

void dEHTWbDnmBgqz::dQgosvW()
{
    string nYmJcMAI = string("GrvVEVlkZklnUWQmWayfHxaidPCjdqxyPMcNJakcnPCtXhuSxSLYwognNVTyqqvIakypbUVMVSPKhSBzILFQzBzwNFKpdnLwKYleDbcgZIvxnkOAOfLneuLNMSQrYHPGkmltSNYSPLOrVNELBGLrWCAdJFDRKLcPHfEQVEmolOWZKPOISThfGouOFdDIkPznjdRBjGlpkEvVWitrjqKbrALjKvQhTJPnXZbJxDdbyipJMUHRPoPgwnPDSV");
    string vvTxnRcBt = string("BXSKdjrpruijNERhzZKqasenIldvaLuACIyJzLvhNxnwY");
    string UFgZHWgbcSwYlYy = string("gdJacbHQHWktxDGAhboWSFycLZkvnWfNkNRDQBBydlPTlTJMFjsUsfUcTmQQiWuMtSpPgSgsAfTGitjKEbctEyXzWVWWmCbgNNbDVoULYiuDATglNAgBAYRvtRfzrixTqzKZvVXRKUpSZcTGFkOiZWqBIrSVsvmrNPdeVqydZEjOcepcpDqAuaajMiWeoEfcjypwYcawPQzx");
    bool WwMUxDL = true;
    double JpuHkuRRtQRUK = 458397.32741068426;
    double yxuWkFmleeHH = -851734.2840044524;
    string eQnItXRWc = string("HzBlWWEJZPjmGMENXOsxqhwzhKgKRIRcijiJomIBr");
}

void dEHTWbDnmBgqz::KzyMQGl(string QCHntg, string wuANVZWnX, double oiCRWNHRwJGqmiXy, bool gVTcsRcw)
{
    int uLqnaRqt = -936912526;
    int ItmpeRcpGEc = 396159903;
    string JNKkYTgHHuO = string("IKnwQiFHQziqzhQsdBJmfjQtqQjuXmbkbXPOWfHEOSVUbomhBSaeXGNbFuHJFNuYflVAfHEEQeCSSHrVLwvdxuFU");

    if (wuANVZWnX < string("IKnwQiFHQziqzhQsdBJmfjQtqQjuXmbkbXPOWfHEOSVUbomhBSaeXGNbFuHJFNuYflVAfHEEQeCSSHrVLwvdxuFU")) {
        for (int sjDKQEv = 1105066637; sjDKQEv > 0; sjDKQEv--) {
            wuANVZWnX = JNKkYTgHHuO;
        }
    }

    if (QCHntg <= string("IKnwQiFHQziqzhQsdBJmfjQtqQjuXmbkbXPOWfHEOSVUbomhBSaeXGNbFuHJFNuYflVAfHEEQeCSSHrVLwvdxuFU")) {
        for (int IMkjelTcQae = 111487303; IMkjelTcQae > 0; IMkjelTcQae--) {
            gVTcsRcw = ! gVTcsRcw;
            ItmpeRcpGEc = uLqnaRqt;
            JNKkYTgHHuO += QCHntg;
            QCHntg = wuANVZWnX;
            wuANVZWnX += wuANVZWnX;
        }
    }

    if (JNKkYTgHHuO <= string("hWqgfceshFmckLcSLjCYywjzkDIRTXiOAWkrCHGyLrzpOxXsTHxZXHCaxqICKvBqWGTHxqZbZOqFtvkIsiXKMERQMYySXLMpMuYlaqwjWfuGOVejsvBVXapxPKdIvqbbubJGMdnL")) {
        for (int crzpBuu = 89646258; crzpBuu > 0; crzpBuu--) {
            JNKkYTgHHuO += wuANVZWnX;
        }
    }

    for (int uQctEzWJYEgSG = 1601656202; uQctEzWJYEgSG > 0; uQctEzWJYEgSG--) {
        JNKkYTgHHuO += QCHntg;
    }
}

string dEHTWbDnmBgqz::YRsuqlFFzXZ(string iTElWyuhGH)
{
    string MYFJSmmvJTfDDTR = string("bJxGxmLFsbfWlUiHzsLantkqQYDFcNnvRviULWQmIYRjwRvvTO");
    string qeCalyOoaT = string("jtRiTHxmXjyMCmdNAFiDFqGwXxyRWBPCufVaCFUtsRpBsQNLHOLDJMLeTEWQbUnoUBwrQlmDdBgIbQOnpOfALqeuEedwvgxyFQdAXKLpztOPeHWiTKMXOBhlkidYjtXGIXjupTaWCrKsjbXTbTUrQkocbUAkrhmUiOwcYSRmVYebVDbFuGsrkMmJUeszvajqbalYuJjQqDkPOGQwpjtzK");
    double TQKUECTZQnEMST = -660115.6657229053;
    bool jziML = false;
    bool njUKWjPQq = true;
    string aVjOp = string("GQABWnPOzABnIMMxVeLEOBDEfhNMLPPfabUrdZrBjeiIktbNJnPxIxwHXeQMgJTiDAXEkvfYgrGsnZRYUtpiHbKjLtPLBzFYdiYhkbgzMxcVMQlLCzSJgMFGxdALjHpCMUeGRKIPCvqAOriCQWFrBaYUETDDZxKFIRhZxLRqAIoCjKLNyxAFT");
    double HlaRDrDK = 367314.6901476518;
    string YEiUeuGJISKpP = string("zLMADJRgILhWtaXDxhbEbbbihwVqpvPxBQMTWFAdfScjbkjEpjqfrPUSlYTDCPXTMvCFUmlIchWhgGxbfvFOSvCJvgWnjrpcGkdSerEdsZVJkarObAdASWKdtoRiZSvNKNkvTavnUJZFtVEPzuANkRxmuQXhZCTegWdbzqLxfITuYmddDNObcAZUEDDGpqCKVGETJzVkCErfhdHVbqtTtJRFQzXWqGBGEUsfIBBpTiFDL");
    bool asCzjyXiN = true;

    if (aVjOp > string("bJxGxmLFsbfWlUiHzsLantkqQYDFcNnvRviULWQmIYRjwRvvTO")) {
        for (int MzjVdkOWwtNLRWYg = 940458009; MzjVdkOWwtNLRWYg > 0; MzjVdkOWwtNLRWYg--) {
            YEiUeuGJISKpP += aVjOp;
            asCzjyXiN = njUKWjPQq;
        }
    }

    for (int NvsCg = 809394954; NvsCg > 0; NvsCg--) {
        YEiUeuGJISKpP = MYFJSmmvJTfDDTR;
    }

    if (YEiUeuGJISKpP != string("jtRiTHxmXjyMCmdNAFiDFqGwXxyRWBPCufVaCFUtsRpBsQNLHOLDJMLeTEWQbUnoUBwrQlmDdBgIbQOnpOfALqeuEedwvgxyFQdAXKLpztOPeHWiTKMXOBhlkidYjtXGIXjupTaWCrKsjbXTbTUrQkocbUAkrhmUiOwcYSRmVYebVDbFuGsrkMmJUeszvajqbalYuJjQqDkPOGQwpjtzK")) {
        for (int tjDgxdESek = 1472532738; tjDgxdESek > 0; tjDgxdESek--) {
            asCzjyXiN = jziML;
        }
    }

    if (MYFJSmmvJTfDDTR >= string("jtRiTHxmXjyMCmdNAFiDFqGwXxyRWBPCufVaCFUtsRpBsQNLHOLDJMLeTEWQbUnoUBwrQlmDdBgIbQOnpOfALqeuEedwvgxyFQdAXKLpztOPeHWiTKMXOBhlkidYjtXGIXjupTaWCrKsjbXTbTUrQkocbUAkrhmUiOwcYSRmVYebVDbFuGsrkMmJUeszvajqbalYuJjQqDkPOGQwpjtzK")) {
        for (int HZiYtfZOWPP = 510580515; HZiYtfZOWPP > 0; HZiYtfZOWPP--) {
            continue;
        }
    }

    for (int UpCstVzGhXYpER = 1300149943; UpCstVzGhXYpER > 0; UpCstVzGhXYpER--) {
        YEiUeuGJISKpP = qeCalyOoaT;
    }

    for (int cnKjCPLUMwTJiK = 1557236929; cnKjCPLUMwTJiK > 0; cnKjCPLUMwTJiK--) {
        YEiUeuGJISKpP += qeCalyOoaT;
        iTElWyuhGH += YEiUeuGJISKpP;
    }

    if (iTElWyuhGH < string("zLMADJRgILhWtaXDxhbEbbbihwVqpvPxBQMTWFAdfScjbkjEpjqfrPUSlYTDCPXTMvCFUmlIchWhgGxbfvFOSvCJvgWnjrpcGkdSerEdsZVJkarObAdASWKdtoRiZSvNKNkvTavnUJZFtVEPzuANkRxmuQXhZCTegWdbzqLxfITuYmddDNObcAZUEDDGpqCKVGETJzVkCErfhdHVbqtTtJRFQzXWqGBGEUsfIBBpTiFDL")) {
        for (int lOnAqHEoClcbbSs = 97210845; lOnAqHEoClcbbSs > 0; lOnAqHEoClcbbSs--) {
            continue;
        }
    }

    return YEiUeuGJISKpP;
}

void dEHTWbDnmBgqz::wnsXEMKJU()
{
    string PQbzgfHIHLMop = string("cdOnHjkvRPFgbPFBuzSjScSfFUXlJxxFjJgNfjRVsDkLkDzqXkmCnjUnWmZsEFgcIqzwjQLeAtVuScWLULsyIAAupVCfLWIPXDZdPbvglzSNdJYxMIGBAAJyOVmRNAGkYyobsByOYQJCMPZziEZcRNfQyLtwFWgXRiYgOY");
    bool oYinKU = false;
    string ONZNWWpZtMgfOI = string("XsSlwAPctJWwdzcEzyKXwcXrsmBDQzcPcHkTJdjUFWQQUzkLvzhCVhsJYnpeUfAuObgwbz");
    bool kagcSznfHbd = true;
    bool uUjkoNERAxkZCJER = true;
    int WVzCNXQHHKQXp = 763238114;
    string RlmvJdy = string("rKxHodaIHJbWiBFBDSAGwKHtOPgeuVOCrjvedggZHoOStkCUlcyBUPXfPlZVOAaiIwQkePycUvwCTmebXRdsvStkgUMSalOKQBhcHwGatJktfEsqpjLcGfSQIFZgkBGiFmcOcdXdWtbIgzkctUaVKCJUCUlaZLFrsmMxTYDJPhcNmDywfD");
    double yBlvYuPEK = -943496.7225428148;
    string whulZvKYjyCuRArR = string("JGUvRYDhRVfmBaXKnolZZhKRQuwjtGzUHtgLYJbPZcXnGOvQBvKGILsugMPh");

    if (ONZNWWpZtMgfOI != string("cdOnHjkvRPFgbPFBuzSjScSfFUXlJxxFjJgNfjRVsDkLkDzqXkmCnjUnWmZsEFgcIqzwjQLeAtVuScWLULsyIAAupVCfLWIPXDZdPbvglzSNdJYxMIGBAAJyOVmRNAGkYyobsByOYQJCMPZziEZcRNfQyLtwFWgXRiYgOY")) {
        for (int MraZrRnh = 1034685103; MraZrRnh > 0; MraZrRnh--) {
            ONZNWWpZtMgfOI += whulZvKYjyCuRArR;
            ONZNWWpZtMgfOI = RlmvJdy;
        }
    }

    for (int putan = 1487409598; putan > 0; putan--) {
        ONZNWWpZtMgfOI = RlmvJdy;
        ONZNWWpZtMgfOI = ONZNWWpZtMgfOI;
    }
}

void dEHTWbDnmBgqz::UFSwHXUcOm(string yZurWmdugahxX, double UPssBZvKt, int ImauRcKDjwOp)
{
    string lKNjIOovVSRYb = string("VsSRuAlcTNOqMXrmdXIIuIbNgqtEQTyViWFeatDaougKbdfmSQxglcSNXGVMQWxBmBILwotVzDmngipEhketQiCwkfdOKElDXkoyalCKwYjicYNEXfLHHoeBsYUKsvvqeMTgNBbSJvJhYWeUnayuWgNAOVEhMBhgaYMSpFDHYMhlAYAYzASGo");
    int iOtXm = 1229133471;
    string TbRtT = string("mtGhAkNCMMtccskrEdoohscIlcalOSNTrHbMgPfnpcjzRqLKzrBVClbHbViCK");

    if (iOtXm < -697284997) {
        for (int vUykMNoIivK = 1514979491; vUykMNoIivK > 0; vUykMNoIivK--) {
            iOtXm /= iOtXm;
        }
    }
}

int dEHTWbDnmBgqz::oaZfEhHjOL(double wVVrB, int dkYPHGkjMEjAZhsz, bool KpewdbcudBtTC)
{
    int beZzOLBqAVnfHR = -139141371;
    bool QLjpDhNJkW = false;
    int WbwUlMSCWS = -1114005775;
    string hkXADwjJgzwxdhX = string("ATKrsuikJYQSstwiSrFjlPXcxQjgWSRbYlxPVusbdHgdcRHXVfjNmxMlpXQHIRQMXpLVIjASyWvaaITEzVFzjhP");
    int UPIErwmndNRjnn = -1320379211;
    double JIaSJuVPyOxQ = -405180.81631645287;
    int GMimFrm = 1750780093;

    if (UPIErwmndNRjnn > 1750780093) {
        for (int gmTwLbelONAnFCLk = 1446319656; gmTwLbelONAnFCLk > 0; gmTwLbelONAnFCLk--) {
            continue;
        }
    }

    return GMimFrm;
}

bool dEHTWbDnmBgqz::haXCmnixGcv()
{
    string RSJXpeJXMhGgum = string("hPcfSCIHjKCrBxeYnBQqfeQdQlnPcgWMwblQnQwGmSrvwuSGeSjZmXsYlTIEhcKBaMxwrwSPGIbQycelgXukmYROCbhTDiK");
    bool YxiXK = true;
    bool vrYcpr = false;
    int XBEAbBVi = -2001251003;
    int bWZifKZiPPkMurrZ = -1813379693;

    if (XBEAbBVi != -2001251003) {
        for (int vWdwMcVA = 697164932; vWdwMcVA > 0; vWdwMcVA--) {
            continue;
        }
    }

    return vrYcpr;
}

bool dEHTWbDnmBgqz::xXoaM(double eJZVtHne, bool QqrmiMESqbrqMSj, double BLMaKaEPfQNVfqAd)
{
    bool hQsYw = false;
    double vbzfEZmidzwOfyv = -633026.4202766473;
    int ZCHwfUQveeLEl = -140356130;
    int TtFHfEKit = -970898257;
    string NcDYHNKeT = string("pbybXuNmRFjsTRAFxjDxnaZjomeMpgJoNoqeSSFUsmlSVHQDjxgxbHYBgPnbNYNOyzzmiwmMZxPaVidJsvGZyEeCePTSXpCEKCpyXVJJzZpDSXyOGcDTCWCnqBHIdMRfrWFyrqlQvoONgbpHOnirpGzthxbNdNiZvvrzduKuPzwNPoV");
    int ZnQtfquznQPdPp = 234457484;

    if (hQsYw == false) {
        for (int DwxDJGBAK = 716131304; DwxDJGBAK > 0; DwxDJGBAK--) {
            vbzfEZmidzwOfyv *= BLMaKaEPfQNVfqAd;
            eJZVtHne += vbzfEZmidzwOfyv;
        }
    }

    for (int gGIbT = 1444931626; gGIbT > 0; gGIbT--) {
        vbzfEZmidzwOfyv *= vbzfEZmidzwOfyv;
        BLMaKaEPfQNVfqAd = BLMaKaEPfQNVfqAd;
        BLMaKaEPfQNVfqAd += eJZVtHne;
        vbzfEZmidzwOfyv *= vbzfEZmidzwOfyv;
        eJZVtHne /= BLMaKaEPfQNVfqAd;
    }

    if (TtFHfEKit == 234457484) {
        for (int UUMbB = 1720110307; UUMbB > 0; UUMbB--) {
            QqrmiMESqbrqMSj = hQsYw;
        }
    }

    if (ZnQtfquznQPdPp == -970898257) {
        for (int hDvdcpIDH = 1990294839; hDvdcpIDH > 0; hDvdcpIDH--) {
            BLMaKaEPfQNVfqAd = vbzfEZmidzwOfyv;
            QqrmiMESqbrqMSj = hQsYw;
            QqrmiMESqbrqMSj = hQsYw;
            vbzfEZmidzwOfyv *= eJZVtHne;
            eJZVtHne *= vbzfEZmidzwOfyv;
        }
    }

    return hQsYw;
}

int dEHTWbDnmBgqz::XjHEJwqRfNMKl(double bjZpjefAHdIuh, int xUXqNiKb, int XaCFyWbLHcUiL)
{
    double WSMXNScRp = 982175.6701862087;
    string xtwOVyLITNcPTCuK = string("DhWFoRuFinyepIbJHXpzzQiuxMklxdcESVDGvnnMdvCvCrgjCb");
    bool EXxdYYkttki = true;
    int iTBXOLOTusuGp = -464127076;
    string ZGbwxXLuyVA = string("hXJDWitqhbXufDCKAbOrdsqUSIhTOYQSZIErlgCHROhjDNcotiiscliNxXBZVHYhfgYbqEXsaSnOfMldWHLvuMABrCWvXVZNNFCkTsSkYQFeyVewlxoJptywxezSUUEBLjoLjuvtvtjmkECgOKVKIsnFDwsDunzveBAtlYMHkfYLSIXPdMndxvKHphzsXoGuovplqTaWbpyLWoNCKKjWYapCssrrwZJdkxKeOEQCwVEsSrDS");
    string MwcituVSowFTlN = string("IoHFPmURVxkxdayRPyuJLrgQuQaFWMkKqKmHEYzUUjHKBwtgxLAEpFUMBVHztqyfgjwwwPRrDjDJgwnQS");

    for (int IvKhVXgNB = 1759960401; IvKhVXgNB > 0; IvKhVXgNB--) {
        xtwOVyLITNcPTCuK = xtwOVyLITNcPTCuK;
        iTBXOLOTusuGp += iTBXOLOTusuGp;
    }

    return iTBXOLOTusuGp;
}

bool dEHTWbDnmBgqz::cbbuRx(string lovVIUJE)
{
    double SwVqAGwIZ = 445180.3022382971;
    string CVjEOrwmPLs = string("DRfFmeQespDwntTGPyRdqBcqoNpfuzzYAVJfclYnyjMpvPVZOMBiHDmjJWtMmfWRbndBtLoZvWddVezlITjZdGjndNQKRJhaNQaKyGMfiWtUMDchUWdRfzZODlqsgDFmQRVkvvYYFRNAPJPPzMXQubYzUzfVFyfLpZnBlTKDAsgjHjRgCPRactoAWuNUwv");
    string twWYhAIJaSHgYDEn = string("jesCiTPCkLVbHIkgDNGzoHWihPcXyxIKptQlxmebwWUalcxknZQOOQMPQmJIMFMuuhWBruNszDdGnGZqpOLJisVOzxzyBiNcSwxsFIUzkBdxNUoumNuCMmnqdzixuDGaxsrWhaiKQUdHokftTSDpklnbxVpbbnVgxxTItUkseUpDJXoYVukMswxZfDlBWXAuPEAguGni");
    int MaRegvscrdA = -110177362;
    string lyHOvaae = string("wZpxxOSrlYkRvJYsTeajJAVWwosAyAHKKFfsUEwCEfduzlhfcMwZsbDdojzuwKnBJjKamnPTxxaQwLwBHUkWSWNdYejHKrVoSJcltwYUpEchXBfalXnNkiurHvFTzzMWXrQcusZDWEMmMVMTyVkbfOWGFzdkLEoQs");
    bool ZhkyxKJJZ = false;
    double igEfNRJkWKczpB = 81365.52688181284;
    int BVhKenp = 806917992;

    for (int phFLbsuxvJYD = 1960575440; phFLbsuxvJYD > 0; phFLbsuxvJYD--) {
        BVhKenp -= BVhKenp;
    }

    if (SwVqAGwIZ > 445180.3022382971) {
        for (int acJnyEblmKbvr = 1993005366; acJnyEblmKbvr > 0; acJnyEblmKbvr--) {
            continue;
        }
    }

    for (int wbhfpNFULkqlL = 1350918275; wbhfpNFULkqlL > 0; wbhfpNFULkqlL--) {
        SwVqAGwIZ *= igEfNRJkWKczpB;
        lovVIUJE += CVjEOrwmPLs;
    }

    if (lovVIUJE < string("wZpxxOSrlYkRvJYsTeajJAVWwosAyAHKKFfsUEwCEfduzlhfcMwZsbDdojzuwKnBJjKamnPTxxaQwLwBHUkWSWNdYejHKrVoSJcltwYUpEchXBfalXnNkiurHvFTzzMWXrQcusZDWEMmMVMTyVkbfOWGFzdkLEoQs")) {
        for (int UKJlvRS = 1571512465; UKJlvRS > 0; UKJlvRS--) {
            lovVIUJE = twWYhAIJaSHgYDEn;
        }
    }

    return ZhkyxKJJZ;
}

string dEHTWbDnmBgqz::mFXjCqIvaGroMvg(bool siTdjHSTBJvYOki)
{
    bool CIEnBCpOPJ = true;

    return string("tgpOGMaYTqNhtJOIVdxLWWqebPFGJPufjWvsQtGXEICEDfRDvJKTaggRjduoplHNoKpbBFKxkGzkHFMbmdPfZPbaclXBgFwk");
}

double dEHTWbDnmBgqz::EcXxjuRaLVNs(double nnXCxxVRHTLLs, string zSqsPjJnkRLUKzD)
{
    string vGYkn = string("cWMvxdPdCqEjlldupdFSEAylxezocTcAaMqNsuZGnScqViqXHHmvYHvTcEwRDFjgnmTeivxUxeoTJqBgVkjRdsatyhqFyGCQhHcLVOSADIfrLOhBLoBlZSAIqSSqmiqsNltAMQFjUkzjEGxOyDPQCukymXNlfRerYOtsmGEuHADVIPynUZzIgItMzslTjfnyvMwaQknMlvVqzJNUYlXGgVVlVePkKHXKfklYzSeryrR");
    int JSkFDzkMyUx = 1978849568;
    int lmBbR = 1103021120;
    bool ziQxBSCiQxoClVgj = true;
    int jXOPqUNgpHtiw = 746195794;
    bool yBpAYdTkPcsEnWx = true;

    for (int mYlCbKJR = 1234323221; mYlCbKJR > 0; mYlCbKJR--) {
        JSkFDzkMyUx += JSkFDzkMyUx;
    }

    for (int JSKhLsfJtSw = 192195647; JSKhLsfJtSw > 0; JSKhLsfJtSw--) {
        vGYkn += vGYkn;
    }

    if (JSkFDzkMyUx != 746195794) {
        for (int NFDjkeka = 1861598544; NFDjkeka > 0; NFDjkeka--) {
            nnXCxxVRHTLLs /= nnXCxxVRHTLLs;
        }
    }

    return nnXCxxVRHTLLs;
}

double dEHTWbDnmBgqz::uqVnMBzCxOHef(bool zNOCtkzMXRNs, int xRaJmlNIqRRpx, bool uzQQzreVMeY, double njtwqSyrFg)
{
    double mJIJaTmlQ = 219818.7344969802;
    int RVjoDXxYLZjJJUt = -323231282;

    for (int HBQxpLmqSk = 370888637; HBQxpLmqSk > 0; HBQxpLmqSk--) {
        njtwqSyrFg += mJIJaTmlQ;
    }

    if (njtwqSyrFg != -907740.0551642934) {
        for (int TQazEAvf = 1272859673; TQazEAvf > 0; TQazEAvf--) {
            njtwqSyrFg /= mJIJaTmlQ;
        }
    }

    return mJIJaTmlQ;
}

int dEHTWbDnmBgqz::TUWOgspdHRZbiZ(bool FrPgonmfmR, double vmWBwUVRjLqNOnV)
{
    bool mHuQRIHFCmDT = false;
    string pwfInkVLGuHjMmw = string("hDnikuHjdqAxRdQdUtoFwIyvibMkYPzxFwOKtzkHJeRsdLJGVNJLOFfxNQeOJbnIaWZlUjMHcwUApPzPQyKkFjSeLeTlpz");
    string YfByXzIiXViHu = string("fhrXtoECaOtFtthDRCcyfYNQkDdWZgrIpBTSxMOhcFkUwLhPGQISeHbzexgaGfItDwvmNJJNCgBcMRDHbpgsbbYxHCCErunJREAgjrFyEHUFlBWRgWzRdbqcAQDMPbgKUjJcfTONivCTJitmpuG");
    int pphNju = -227212070;
    string AjkcOHzkvXyLFW = string("BwCuwKAyjXLwZbEbZXZBxhOGpxJPDCcydcsRTBCovzRFBTuRCRyedXQynLcurksnHoNafsZACjGotPsbmvNThhqHgs");

    for (int PChpBkgRJMiID = 1924318316; PChpBkgRJMiID > 0; PChpBkgRJMiID--) {
        pwfInkVLGuHjMmw = pwfInkVLGuHjMmw;
        AjkcOHzkvXyLFW += YfByXzIiXViHu;
    }

    if (AjkcOHzkvXyLFW == string("BwCuwKAyjXLwZbEbZXZBxhOGpxJPDCcydcsRTBCovzRFBTuRCRyedXQynLcurksnHoNafsZACjGotPsbmvNThhqHgs")) {
        for (int fDudMuhHcyaiJ = 2008626710; fDudMuhHcyaiJ > 0; fDudMuhHcyaiJ--) {
            continue;
        }
    }

    for (int krrfxT = 524262755; krrfxT > 0; krrfxT--) {
        pwfInkVLGuHjMmw += pwfInkVLGuHjMmw;
    }

    for (int wqFvnDdapuvoJmZ = 1862602819; wqFvnDdapuvoJmZ > 0; wqFvnDdapuvoJmZ--) {
        AjkcOHzkvXyLFW = AjkcOHzkvXyLFW;
    }

    for (int hsJOIYTQpo = 127130160; hsJOIYTQpo > 0; hsJOIYTQpo--) {
        AjkcOHzkvXyLFW = AjkcOHzkvXyLFW;
        YfByXzIiXViHu += pwfInkVLGuHjMmw;
        YfByXzIiXViHu += AjkcOHzkvXyLFW;
        AjkcOHzkvXyLFW = YfByXzIiXViHu;
    }

    if (YfByXzIiXViHu <= string("hDnikuHjdqAxRdQdUtoFwIyvibMkYPzxFwOKtzkHJeRsdLJGVNJLOFfxNQeOJbnIaWZlUjMHcwUApPzPQyKkFjSeLeTlpz")) {
        for (int NoSDIyIrOeJKWkMr = 607810558; NoSDIyIrOeJKWkMr > 0; NoSDIyIrOeJKWkMr--) {
            pwfInkVLGuHjMmw = YfByXzIiXViHu;
            AjkcOHzkvXyLFW += YfByXzIiXViHu;
        }
    }

    return pphNju;
}

string dEHTWbDnmBgqz::QXjqTPGqJl(double LGZSqDMxiE)
{
    string udiqGbXZADoUEY = string("ovZxprWQouDzECWNpKRSrxkHYHAKwBnmFXN");
    string FYdvzPTCgLvvxLR = string("itgDqNNKxPwUpHpgksBHnqGPDfucnsePrddMbSHScQbypZnCNkcOTiLZTfHYvsprocKQZytsslfIPsxLUuSqQRREHOXMNdWVuNXsGeBSIrRAlQbftvgURwkzXWOfDQLcc");
    string DKMIM = string("jEToHNMeDdZpjqcQmwIcCjiCVuecynpybLUklhYQWhaSLokpMh");
    int LWuKQDhHYk = 372600715;

    if (udiqGbXZADoUEY != string("ovZxprWQouDzECWNpKRSrxkHYHAKwBnmFXN")) {
        for (int aaigTpTVSp = 184125644; aaigTpTVSp > 0; aaigTpTVSp--) {
            udiqGbXZADoUEY = FYdvzPTCgLvvxLR;
        }
    }

    if (LWuKQDhHYk <= 372600715) {
        for (int DwTegbMJAzYYNi = 812547427; DwTegbMJAzYYNi > 0; DwTegbMJAzYYNi--) {
            continue;
        }
    }

    if (FYdvzPTCgLvvxLR < string("jEToHNMeDdZpjqcQmwIcCjiCVuecynpybLUklhYQWhaSLokpMh")) {
        for (int yXziwn = 98540460; yXziwn > 0; yXziwn--) {
            LWuKQDhHYk /= LWuKQDhHYk;
            DKMIM = FYdvzPTCgLvvxLR;
            udiqGbXZADoUEY = FYdvzPTCgLvvxLR;
        }
    }

    for (int SHPqJCOGPzCZy = 1740802852; SHPqJCOGPzCZy > 0; SHPqJCOGPzCZy--) {
        FYdvzPTCgLvvxLR = udiqGbXZADoUEY;
    }

    if (DKMIM >= string("itgDqNNKxPwUpHpgksBHnqGPDfucnsePrddMbSHScQbypZnCNkcOTiLZTfHYvsprocKQZytsslfIPsxLUuSqQRREHOXMNdWVuNXsGeBSIrRAlQbftvgURwkzXWOfDQLcc")) {
        for (int TNdhroqtzj = 341190420; TNdhroqtzj > 0; TNdhroqtzj--) {
            LWuKQDhHYk -= LWuKQDhHYk;
            udiqGbXZADoUEY += DKMIM;
        }
    }

    if (LGZSqDMxiE == -629372.6890651056) {
        for (int CMhYWTPOWTdMEN = 2121125318; CMhYWTPOWTdMEN > 0; CMhYWTPOWTdMEN--) {
            continue;
        }
    }

    return DKMIM;
}

int dEHTWbDnmBgqz::tbvGqzKQaGBycY(double BsdsVxnwa, bool YIPJHYdOCSVwTUHG)
{
    string JuEMlSdo = string("AylLrwXvYPmIAYtfgKozrLNFkhJMayFMUZHpODWIwboreVQpAQSQUjWJrJyhXEpwKMsVHMk");

    for (int souEgWEnpkUH = 1727231621; souEgWEnpkUH > 0; souEgWEnpkUH--) {
        JuEMlSdo = JuEMlSdo;
    }

    if (JuEMlSdo == string("AylLrwXvYPmIAYtfgKozrLNFkhJMayFMUZHpODWIwboreVQpAQSQUjWJrJyhXEpwKMsVHMk")) {
        for (int VDwneJWijuzUf = 367267699; VDwneJWijuzUf > 0; VDwneJWijuzUf--) {
            continue;
        }
    }

    if (BsdsVxnwa >= 731886.5182835759) {
        for (int SzYvNlIFhtMq = 1247926993; SzYvNlIFhtMq > 0; SzYvNlIFhtMq--) {
            YIPJHYdOCSVwTUHG = YIPJHYdOCSVwTUHG;
        }
    }

    for (int GeNyRCWgCrDKE = 783549340; GeNyRCWgCrDKE > 0; GeNyRCWgCrDKE--) {
        continue;
    }

    return -1861483987;
}

dEHTWbDnmBgqz::dEHTWbDnmBgqz()
{
    this->dQgosvW();
    this->KzyMQGl(string("fYoCjRiJmzWjeSHEKvWAawmZdRRPAnjdDATJQTQVFdRxsRpqWSAWOOeQSRfdAhiUGbAtPDhnOMxYqGhcpzTXVHroYzQgyumTlgcaQXZvSSIecGUrzJvlgbZRRlkbYaEPHJChdZipkfiANyX"), string("hWqgfceshFmckLcSLjCYywjzkDIRTXiOAWkrCHGyLrzpOxXsTHxZXHCaxqICKvBqWGTHxqZbZOqFtvkIsiXKMERQMYySXLMpMuYlaqwjWfuGOVejsvBVXapxPKdIvqbbubJGMdnL"), -700658.094412719, true);
    this->YRsuqlFFzXZ(string("PYLrjrJDClXhfzphyKULcrnsrygayxJsDopdSpUONPdDIPzTAwjZfFvQDUZclGGswDPDrcgUwoocIEQHedf"));
    this->wnsXEMKJU();
    this->UFSwHXUcOm(string("zyfYNnvZugCLxJOnSweVOrFKoUMKFmnKVXgatlUkAVMpwBAojgTaJcvI"), -501265.72252176685, -697284997);
    this->oaZfEhHjOL(408073.3732426436, -331053196, false);
    this->haXCmnixGcv();
    this->xXoaM(-444108.1107539673, true, -355838.7947860731);
    this->XjHEJwqRfNMKl(183320.53198113674, 2027961077, -786879360);
    this->cbbuRx(string("HQIGEvhWKhWwtMydNASFpUNgQmqqgWfYKtjRYEWClDJOfmdcgnImIQSMoPCXtcWMnfdXKAJuqQiRmuVTOhFdKAwCFyXdTtgzOrxRkdyntDAFmvVqWSXgAGQzImEVfonDLbAQgmdweHOyBHNQytVWoYtaaGlIhcLdZyRnRwOsdYeQUUdfJdIASPsQSsPEvvuPvHcDyGteXNfTLeaGdQxfFRhAMHErSSzFYoBiFkgGQZcufL"));
    this->mFXjCqIvaGroMvg(true);
    this->EcXxjuRaLVNs(-647946.7612789092, string("FQGwmNFpNKQVZyhHnreQOpdlNTvkLdjDtYYhNjfPOiPthMzbwNBTicTFopWbfLkMXleUngKVotKxqNyVtLNlNInHtvVnKumXdKrPeZhoxcfUsAJUiUvPuUgKmXjJrhsFSuYhBoPTRQGQbSrgyOqroOfDcrkzlZwQyqmYhvmcwQCqZiBDiEdBnvKVYKkHCqduAx"));
    this->uqVnMBzCxOHef(true, -88860131, false, -907740.0551642934);
    this->TUWOgspdHRZbiZ(true, 437498.6601046681);
    this->QXjqTPGqJl(-629372.6890651056);
    this->tbvGqzKQaGBycY(731886.5182835759, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class epeVz
{
public:
    bool CWdpIXxe;
    double JPSMi;
    string cquteTAP;
    double DJnmKKgPdmVatE;
    bool BYwPrZfWijt;
    double GBPGrSIj;

    epeVz();
    string ticNOfYmWttRKw(int lADucZJok, double EoOQn);
protected:
    double eNtfQRJnmfq;
    string kGhGSRaguttTui;
    double nruWoPQOAB;
    int RoCRyvuvfOdbU;
    string oidcIgsn;
    double HPxtEFgSSAPtYRbF;

    bool zqrqixSd();
    int inRmDsHmyOn(int tyjjbfoPslhAMGBO, int YXbqrQIsQktMszE, bool GlXRhNcYQVoPbhR);
    string OjyOkreoSQDP(bool oKWTbU, string CcIBeOhG);
private:
    string UijabuA;
    double wIVntmYcloo;
    int GMcFXmQynWKYP;
    double ekJVUscX;

    double HRCcnxbMUWLNOE(bool QBlPWfSc);
};

string epeVz::ticNOfYmWttRKw(int lADucZJok, double EoOQn)
{
    bool MlgZltURyzfbv = false;
    string KTAsOgxIZ = string("GHuobddvEoEqLGgelodBBoMEtXuoMJHWgerECCWelwvbXXwUYVFEuedqCRkColutVcKDNLUYkURz");
    int JjLTlElwlrgZY = -1234077777;
    string ICLMOsVWJLQJZ = string("pXbcTbLilyDcIVJIZorBGICrTMEmQixpVNnoLtRtoQTlYtwWXOPJNCkCgMhiXAtimgOMuDaGLzvIdutSvikkkIhmwLwWqPWBNVxJTOJPncnILFIdlnQVGMrarUmXOsnenAyUVPsdFHrKWEkoFpTqwmuXXdAoOeU");
    int ceRXXkQocdszny = -17930937;
    bool UnnlXcTE = false;
    int NFSwOPKZqUOpxymx = 1778378651;
    string jXXAVFsvnFhcJdC = string("inVFhAruoizqyZPDkZVUHnmSnxvdMdwnNSfDMExakoryXXlEhEwtGCzpemspTacRfxiGepZxvDNpmipHAtbAqUDEDFCSUPnlCsugtExdHEujGhEvfrLeCnIFMEQmHyFJrwDXDmhrDjmpNqmJNZqVJzTSYaWrdCBhgmQpbftcVrDjiJJxsbRkYUilimyLpuURWghwiDPvnOonpRBraxkBF");
    int LrzkcPliKKpJ = -244208398;

    for (int RBOQkPEyUTE = 79568261; RBOQkPEyUTE > 0; RBOQkPEyUTE--) {
        JjLTlElwlrgZY *= LrzkcPliKKpJ;
    }

    for (int MLtotYbbuB = 1222720994; MLtotYbbuB > 0; MLtotYbbuB--) {
        NFSwOPKZqUOpxymx = NFSwOPKZqUOpxymx;
    }

    for (int ExQNdjvpu = 2139051692; ExQNdjvpu > 0; ExQNdjvpu--) {
        continue;
    }

    return jXXAVFsvnFhcJdC;
}

bool epeVz::zqrqixSd()
{
    bool qwRfDAd = false;
    double YcrZhWgRsNZFp = -773480.0992329493;
    string DJHpJiDJLBKEH = string("cyvyhiSypYUKNilGhWbUFgjLDFfIxwhRNJMZmTjWsWjKYGAGuympJxxvhwelPyxLFcbwIKFTigsdROwgpezwVIckFqSHxOOnDpmhgcCnzPYbeWMjWopFrJOccaAEYUTzqFiKlityFnVRBpIkKmSkbknYueyOeULCyqBdQDnENogmzXQFhGmGabcJawYrsrXBHSE");
    bool gDhOCxcByBIuyqUJ = false;
    string RuSmFJjkYMLWHuQT = string("MSSlRIgQRNKnoqwlFExQRAXdLIAZZvSmFwGCAVhslFEQlZSUXZwopiRnQthFtuTlnJpChfmLoUSMNbYLfPMUQyNWhidskNACuYVXFsawiysELCLVgulBxLnXJdjnSPyyUEhePBybgtEkJFWUjGCusFNMhjZooifNlkhNiQYoDeBianXjUDnuEhHUFcbuXnTiUtXIlBYGpjIDWK");

    if (YcrZhWgRsNZFp < -773480.0992329493) {
        for (int XZYBgOio = 955130684; XZYBgOio > 0; XZYBgOio--) {
            gDhOCxcByBIuyqUJ = qwRfDAd;
            gDhOCxcByBIuyqUJ = ! gDhOCxcByBIuyqUJ;
            gDhOCxcByBIuyqUJ = ! gDhOCxcByBIuyqUJ;
            gDhOCxcByBIuyqUJ = gDhOCxcByBIuyqUJ;
        }
    }

    for (int KqfSWVtXOdmP = 99867464; KqfSWVtXOdmP > 0; KqfSWVtXOdmP--) {
        DJHpJiDJLBKEH = RuSmFJjkYMLWHuQT;
    }

    for (int WbIfD = 1430739200; WbIfD > 0; WbIfD--) {
        RuSmFJjkYMLWHuQT += DJHpJiDJLBKEH;
        gDhOCxcByBIuyqUJ = qwRfDAd;
    }

    for (int zjdjpJSTItI = 817615180; zjdjpJSTItI > 0; zjdjpJSTItI--) {
        qwRfDAd = ! qwRfDAd;
        RuSmFJjkYMLWHuQT = DJHpJiDJLBKEH;
    }

    if (gDhOCxcByBIuyqUJ == false) {
        for (int uGXAhTRiuo = 527241483; uGXAhTRiuo > 0; uGXAhTRiuo--) {
            RuSmFJjkYMLWHuQT = RuSmFJjkYMLWHuQT;
            qwRfDAd = qwRfDAd;
            DJHpJiDJLBKEH = DJHpJiDJLBKEH;
        }
    }

    for (int onBDVtDcu = 1468186740; onBDVtDcu > 0; onBDVtDcu--) {
        DJHpJiDJLBKEH = RuSmFJjkYMLWHuQT;
        DJHpJiDJLBKEH += RuSmFJjkYMLWHuQT;
        DJHpJiDJLBKEH += RuSmFJjkYMLWHuQT;
        qwRfDAd = gDhOCxcByBIuyqUJ;
        qwRfDAd = ! qwRfDAd;
        DJHpJiDJLBKEH += DJHpJiDJLBKEH;
    }

    return gDhOCxcByBIuyqUJ;
}

int epeVz::inRmDsHmyOn(int tyjjbfoPslhAMGBO, int YXbqrQIsQktMszE, bool GlXRhNcYQVoPbhR)
{
    int VdJNaVimNqc = 2090129804;
    bool dBXxYiGEfy = true;
    string OGSjtUZicCLBu = string("nyQliSgtGpYempzVMvXvSLFTliwjjQoymoVlHRLcefESUweGdbPLtfWqtGXXxbnooyimLobxcOxwmPIzSVZxdQPNDMDItRFLplHRRWlTSeTlIctMVIAWhelYmtqfuD");
    double IDyCDnBKv = 148183.50520539572;
    bool Ngytjixq = true;

    for (int HJtcW = 1140719547; HJtcW > 0; HJtcW--) {
        VdJNaVimNqc /= VdJNaVimNqc;
    }

    for (int jbJNVvuYcXDCkRRi = 1393894156; jbJNVvuYcXDCkRRi > 0; jbJNVvuYcXDCkRRi--) {
        GlXRhNcYQVoPbhR = ! Ngytjixq;
        IDyCDnBKv = IDyCDnBKv;
    }

    if (dBXxYiGEfy != true) {
        for (int vBkaCNVhXRxC = 488890871; vBkaCNVhXRxC > 0; vBkaCNVhXRxC--) {
            tyjjbfoPslhAMGBO = tyjjbfoPslhAMGBO;
            VdJNaVimNqc -= tyjjbfoPslhAMGBO;
        }
    }

    for (int SxJBlcns = 2048755088; SxJBlcns > 0; SxJBlcns--) {
        GlXRhNcYQVoPbhR = ! Ngytjixq;
        YXbqrQIsQktMszE /= tyjjbfoPslhAMGBO;
        dBXxYiGEfy = ! Ngytjixq;
    }

    return VdJNaVimNqc;
}

string epeVz::OjyOkreoSQDP(bool oKWTbU, string CcIBeOhG)
{
    bool xehmyZhsDqD = false;
    double JoVPXFPlAdaRlG = -57582.11067653733;
    double bajMZmHwkJakiES = 456432.20072268724;
    int lCCckZDwARZFAoj = 741723108;

    for (int NVOsbU = 1242975105; NVOsbU > 0; NVOsbU--) {
        JoVPXFPlAdaRlG /= bajMZmHwkJakiES;
        JoVPXFPlAdaRlG *= JoVPXFPlAdaRlG;
    }

    for (int NsAjzmHCsBxr = 1511534331; NsAjzmHCsBxr > 0; NsAjzmHCsBxr--) {
        oKWTbU = ! oKWTbU;
    }

    for (int ybqwYtrbh = 1058593704; ybqwYtrbh > 0; ybqwYtrbh--) {
        continue;
    }

    if (bajMZmHwkJakiES <= 456432.20072268724) {
        for (int ynNZCCYWOnqVLcJ = 1084318648; ynNZCCYWOnqVLcJ > 0; ynNZCCYWOnqVLcJ--) {
            JoVPXFPlAdaRlG = JoVPXFPlAdaRlG;
        }
    }

    for (int MSvkNdVgkFPoe = 581958103; MSvkNdVgkFPoe > 0; MSvkNdVgkFPoe--) {
        continue;
    }

    if (bajMZmHwkJakiES >= 456432.20072268724) {
        for (int BlLkSQWX = 348416506; BlLkSQWX > 0; BlLkSQWX--) {
            continue;
        }
    }

    if (xehmyZhsDqD == true) {
        for (int AjgJWSKcPnim = 1906153989; AjgJWSKcPnim > 0; AjgJWSKcPnim--) {
            continue;
        }
    }

    return CcIBeOhG;
}

double epeVz::HRCcnxbMUWLNOE(bool QBlPWfSc)
{
    double jSUdtxoWBcU = 34674.285858311465;
    double TXSuYzbcgQX = -537254.208646877;
    string BWVKbuMSXgWGhfBw = string("bOWSgVPEufzLRPgGJplJSQYEvJFqN");
    int UAFfJNZxYwXkaZ = 1594327564;
    string UINejZzXgL = string("sLDhFJnwgTTIgWxPuIFRRivlUPGrRIDGnyYxfRdxUykzsdnJZJsxrkCmCNVQgskPtsnRVZOFaKLDyFBElUwc");
    int fUPjAuCrxxVe = 730718045;
    string umxGhRLEQZ = string("AigCNUsmqnvOnavHNCJgqTeojJvCPkThgtcwplUIXAyJxBSemBrwFcvMIyuNcCoscZlwvXhUHLzxsaoITFdkvaYCqRdKMToPXghTSBusbtUenldoXawEUWDKRuMoUsnrkncNVopnegqHZmUfjTUPuhOIBydbzTqx");
    int RAqjIWcigppOrqq = 177252469;

    for (int jqJpohYieYw = 1022924168; jqJpohYieYw > 0; jqJpohYieYw--) {
        TXSuYzbcgQX = TXSuYzbcgQX;
    }

    return TXSuYzbcgQX;
}

epeVz::epeVz()
{
    this->ticNOfYmWttRKw(-595133572, 560581.6850365804);
    this->zqrqixSd();
    this->inRmDsHmyOn(-459894752, 1833855321, false);
    this->OjyOkreoSQDP(true, string("eUcIvHoqZNzwrfEsAswLpoMathiIYWbyJgAgrzQuulqNpLAFLfdFKXiZBMyEMpRKadlwtQzpWZJICUGhMxwuOOOhjfhZbLdSlmUuIWobSMUxJTDHAtXztBmfGfjtuHYglBipkJUSXbmaxDvdFkrKxoGXuceiHCdORwBDJw"));
    this->HRCcnxbMUWLNOE(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oHRxpIREtj
{
public:
    double lMLuKuPbop;
    string UMTmEDYe;
    bool YohQKG;
    bool bSXgRZlA;
    string tOawZjBeEBMjpbk;
    bool lSYNbYpr;

    oHRxpIREtj();
    bool bSAvQbcdap(string JRDKpZlnHUol);
    int OynbO(string PsrJdEmqZfSW, double QhvaKJuQ);
    string eacUVhAxFJV();
    int HxtLmJfTymfdkk(string AMzLrVHj, bool ssNRURvHrBoLJCk, string WcRsrCZC, double WIgrvcRIWUUfc, string BUWawydIXnzF);
    string roPAhYnQRkq(bool MnFEiPkMoYqcDg);
    string sVmVqHnxuveAseL(double svwFQeLJ, string DtwojUflNl, int ATLunOgIHnYGLEk);
    bool ZIpTx(bool UyHUXW, bool MWjNPwkguMJR, bool gMEdoayaU, string LBdBqrSPQybYWckl, string WztyzqkoJtaCFwdM);
protected:
    double LhnRkGVWREQx;
    double QxlJiFcP;

private:
    int hNipbtfDGvpu;
    string YDCaxpeO;
    int GmhGpYZZfvcOG;

    string kqXiWuWJnV(double YPDMEXMsZrGPQjVC);
    string RXnbPfQR();
    bool bUoLeoeKEcoB(double aKNUCVKUbJq);
    string MTZgfSYbhMMReJo(bool QxuomoK, bool qtkVmmzgRtT, int uyrDYtehiCGT);
};

bool oHRxpIREtj::bSAvQbcdap(string JRDKpZlnHUol)
{
    double HXZKTaZxKaIH = 256636.24599275657;

    if (JRDKpZlnHUol <= string("KUSUyvcOGOlOQJmoNhyNbjdsTxvnAYScEQwquRRBqbZyRZNCSFIKfaNAiFnbRQfQeQdPZzZcElhMOgJQvWeeuuhNpfJIuEJ")) {
        for (int nYcPdiYfSdxuV = 1279719537; nYcPdiYfSdxuV > 0; nYcPdiYfSdxuV--) {
            JRDKpZlnHUol += JRDKpZlnHUol;
            JRDKpZlnHUol += JRDKpZlnHUol;
            JRDKpZlnHUol = JRDKpZlnHUol;
            JRDKpZlnHUol = JRDKpZlnHUol;
        }
    }

    if (JRDKpZlnHUol >= string("KUSUyvcOGOlOQJmoNhyNbjdsTxvnAYScEQwquRRBqbZyRZNCSFIKfaNAiFnbRQfQeQdPZzZcElhMOgJQvWeeuuhNpfJIuEJ")) {
        for (int sNyFAJGN = 1963142301; sNyFAJGN > 0; sNyFAJGN--) {
            HXZKTaZxKaIH /= HXZKTaZxKaIH;
            JRDKpZlnHUol += JRDKpZlnHUol;
            HXZKTaZxKaIH /= HXZKTaZxKaIH;
        }
    }

    for (int tAIxp = 1372972224; tAIxp > 0; tAIxp--) {
        HXZKTaZxKaIH += HXZKTaZxKaIH;
        JRDKpZlnHUol += JRDKpZlnHUol;
    }

    return false;
}

int oHRxpIREtj::OynbO(string PsrJdEmqZfSW, double QhvaKJuQ)
{
    int nMxvrciqWCjRHf = -349843962;
    int PVzUBgz = -1707600121;

    for (int BjngTrqwMHvPsZKX = 515289302; BjngTrqwMHvPsZKX > 0; BjngTrqwMHvPsZKX--) {
        QhvaKJuQ *= QhvaKJuQ;
        nMxvrciqWCjRHf = PVzUBgz;
    }

    for (int UFGPChly = 1624783047; UFGPChly > 0; UFGPChly--) {
        continue;
    }

    if (PVzUBgz > -349843962) {
        for (int DHheCJWM = 1838724461; DHheCJWM > 0; DHheCJWM--) {
            nMxvrciqWCjRHf /= nMxvrciqWCjRHf;
        }
    }

    for (int NVyzHAAyQj = 926478437; NVyzHAAyQj > 0; NVyzHAAyQj--) {
        QhvaKJuQ -= QhvaKJuQ;
        nMxvrciqWCjRHf /= PVzUBgz;
        nMxvrciqWCjRHf /= PVzUBgz;
        QhvaKJuQ = QhvaKJuQ;
    }

    return PVzUBgz;
}

string oHRxpIREtj::eacUVhAxFJV()
{
    int Ltqqspy = 165945887;
    string aWRGT = string("wRnaQAIBpmMasaVNzJALSaiRrK");
    double JOeWEokJODj = 504492.70921334275;
    int yabDrYP = -256977684;
    string ZzHzDqe = string("RDVHRuxQtQuvQSKUdeDNcHuazwsbTRZzIlamEPKCVUYoRnkbFTKKHTlOxQwOOQnaDGpGuKZfIqtbxpOOlCtZOHyxpRfquhRQSyXobnTpRGtYeipGHaahQiOfYRiOndRwttprHcOOOxScFpiFDSzMGeEndxhRghaTMVjRXKYWsIAnLJIqlFHepWSOE");
    string kskZHsvT = string("SIfddqSQGcfmUfpZLIrgEvBVfUQLSlcgvSYvtxBSqz");
    bool FvFJmzGTHavhw = false;
    bool lCevLxDSTtW = false;
    bool nNoCpYzxkof = true;
    bool NbAdQYrzcModjz = true;

    for (int xzBxvigLhPJYFD = 914278271; xzBxvigLhPJYFD > 0; xzBxvigLhPJYFD--) {
        ZzHzDqe = kskZHsvT;
    }

    for (int NutEktqbRexg = 316170483; NutEktqbRexg > 0; NutEktqbRexg--) {
        NbAdQYrzcModjz = ! FvFJmzGTHavhw;
        ZzHzDqe = aWRGT;
        nNoCpYzxkof = lCevLxDSTtW;
    }

    for (int DLrQDhzKf = 1894405662; DLrQDhzKf > 0; DLrQDhzKf--) {
        lCevLxDSTtW = lCevLxDSTtW;
        aWRGT = ZzHzDqe;
        NbAdQYrzcModjz = ! FvFJmzGTHavhw;
        nNoCpYzxkof = nNoCpYzxkof;
    }

    return kskZHsvT;
}

int oHRxpIREtj::HxtLmJfTymfdkk(string AMzLrVHj, bool ssNRURvHrBoLJCk, string WcRsrCZC, double WIgrvcRIWUUfc, string BUWawydIXnzF)
{
    double wpbsBIaEd = -361380.76568292675;
    bool dMcMHx = false;
    double xNKToGGBiQwLLC = -256669.51169974825;
    int HYQVCOuugUIBdVi = -2083733840;
    int abToC = -116579337;
    bool xJYkN = false;
    int ZOvhdzEqClWRXm = -943216881;
    int SXasbnEggEvWlzuc = -1204647848;

    for (int IiAeIMAFRlFynPjH = 1689219875; IiAeIMAFRlFynPjH > 0; IiAeIMAFRlFynPjH--) {
        WIgrvcRIWUUfc /= xNKToGGBiQwLLC;
    }

    for (int IFXOGh = 639860481; IFXOGh > 0; IFXOGh--) {
        abToC -= abToC;
        xNKToGGBiQwLLC /= WIgrvcRIWUUfc;
        ssNRURvHrBoLJCk = ssNRURvHrBoLJCk;
    }

    for (int HrgMFJlBzYD = 1011686290; HrgMFJlBzYD > 0; HrgMFJlBzYD--) {
        xJYkN = dMcMHx;
    }

    for (int uviNMPIJmt = 146898220; uviNMPIJmt > 0; uviNMPIJmt--) {
        dMcMHx = ssNRURvHrBoLJCk;
        dMcMHx = ssNRURvHrBoLJCk;
        BUWawydIXnzF = AMzLrVHj;
    }

    for (int Jedxor = 571739546; Jedxor > 0; Jedxor--) {
        xJYkN = ! dMcMHx;
    }

    for (int EyFpT = 1804709715; EyFpT > 0; EyFpT--) {
        continue;
    }

    for (int EBkkSYUxlcWrC = 1561727431; EBkkSYUxlcWrC > 0; EBkkSYUxlcWrC--) {
        HYQVCOuugUIBdVi /= HYQVCOuugUIBdVi;
        abToC -= abToC;
    }

    return SXasbnEggEvWlzuc;
}

string oHRxpIREtj::roPAhYnQRkq(bool MnFEiPkMoYqcDg)
{
    bool HxSiVSVPShvH = false;
    bool jfLGndq = false;
    bool xkuFTbLWedWeEpwx = false;
    int LVDrKzDZV = -191876172;

    for (int PadYsqJRhxrTiz = 716148436; PadYsqJRhxrTiz > 0; PadYsqJRhxrTiz--) {
        xkuFTbLWedWeEpwx = xkuFTbLWedWeEpwx;
        xkuFTbLWedWeEpwx = jfLGndq;
        xkuFTbLWedWeEpwx = ! xkuFTbLWedWeEpwx;
        xkuFTbLWedWeEpwx = ! HxSiVSVPShvH;
        HxSiVSVPShvH = ! jfLGndq;
    }

    if (jfLGndq == false) {
        for (int TeTNfXkRY = 1277029975; TeTNfXkRY > 0; TeTNfXkRY--) {
            HxSiVSVPShvH = MnFEiPkMoYqcDg;
            HxSiVSVPShvH = HxSiVSVPShvH;
            HxSiVSVPShvH = xkuFTbLWedWeEpwx;
            LVDrKzDZV /= LVDrKzDZV;
            LVDrKzDZV = LVDrKzDZV;
        }
    }

    if (xkuFTbLWedWeEpwx == false) {
        for (int idlUjvxDNHSoBsL = 1559399176; idlUjvxDNHSoBsL > 0; idlUjvxDNHSoBsL--) {
            HxSiVSVPShvH = ! MnFEiPkMoYqcDg;
        }
    }

    return string("SIWQukPeLFWRYrJsDvlhYqyspumxtWzHByUdIpcraVcnqwNlYnk");
}

string oHRxpIREtj::sVmVqHnxuveAseL(double svwFQeLJ, string DtwojUflNl, int ATLunOgIHnYGLEk)
{
    double kHDzKpiyVuYXy = 1042677.1083899956;
    double aIiKDfYBRV = -293529.38171809394;
    int qaCFTYWXmS = -1632452133;
    int LqqLP = 1026582966;
    string exLkreolhykgWFyC = string("MHASMqqERl");
    double qRxhULEhKQ = 713951.8611384961;
    int mvTWZdPVqsXDqgwY = 1287439582;

    if (kHDzKpiyVuYXy >= -293529.38171809394) {
        for (int nbHQBfJBflQkTqX = 1618698152; nbHQBfJBflQkTqX > 0; nbHQBfJBflQkTqX--) {
            qaCFTYWXmS *= mvTWZdPVqsXDqgwY;
        }
    }

    if (aIiKDfYBRV < 1042677.1083899956) {
        for (int BlsLjMyPjS = 169874311; BlsLjMyPjS > 0; BlsLjMyPjS--) {
            DtwojUflNl = exLkreolhykgWFyC;
            LqqLP *= LqqLP;
        }
    }

    if (kHDzKpiyVuYXy != -293529.38171809394) {
        for (int zANAAeM = 597480296; zANAAeM > 0; zANAAeM--) {
            ATLunOgIHnYGLEk /= mvTWZdPVqsXDqgwY;
        }
    }

    for (int CNsLMnKw = 532246757; CNsLMnKw > 0; CNsLMnKw--) {
        svwFQeLJ *= svwFQeLJ;
        qaCFTYWXmS *= LqqLP;
    }

    for (int PicfxMCYrcZG = 997505292; PicfxMCYrcZG > 0; PicfxMCYrcZG--) {
        continue;
    }

    for (int azEcpVc = 393597075; azEcpVc > 0; azEcpVc--) {
        kHDzKpiyVuYXy = kHDzKpiyVuYXy;
    }

    return exLkreolhykgWFyC;
}

bool oHRxpIREtj::ZIpTx(bool UyHUXW, bool MWjNPwkguMJR, bool gMEdoayaU, string LBdBqrSPQybYWckl, string WztyzqkoJtaCFwdM)
{
    int sKaFlB = -171353880;
    double jMyIXkjB = 494306.7973961352;
    bool yHletpdGipNSn = false;

    for (int PNDSnosKKZ = 2034366846; PNDSnosKKZ > 0; PNDSnosKKZ--) {
        LBdBqrSPQybYWckl = WztyzqkoJtaCFwdM;
    }

    for (int Rupdib = 1821356999; Rupdib > 0; Rupdib--) {
        WztyzqkoJtaCFwdM += LBdBqrSPQybYWckl;
        jMyIXkjB *= jMyIXkjB;
    }

    if (MWjNPwkguMJR != false) {
        for (int kNeqYNvuLH = 1762256358; kNeqYNvuLH > 0; kNeqYNvuLH--) {
            MWjNPwkguMJR = yHletpdGipNSn;
            yHletpdGipNSn = MWjNPwkguMJR;
            gMEdoayaU = ! gMEdoayaU;
            gMEdoayaU = ! yHletpdGipNSn;
            UyHUXW = MWjNPwkguMJR;
            jMyIXkjB /= jMyIXkjB;
        }
    }

    if (UyHUXW == false) {
        for (int BGVRYkje = 1289642842; BGVRYkje > 0; BGVRYkje--) {
            MWjNPwkguMJR = yHletpdGipNSn;
            gMEdoayaU = gMEdoayaU;
        }
    }

    for (int oEMbuQV = 661229963; oEMbuQV > 0; oEMbuQV--) {
        UyHUXW = ! MWjNPwkguMJR;
        yHletpdGipNSn = ! MWjNPwkguMJR;
        LBdBqrSPQybYWckl = WztyzqkoJtaCFwdM;
    }

    return yHletpdGipNSn;
}

string oHRxpIREtj::kqXiWuWJnV(double YPDMEXMsZrGPQjVC)
{
    int yjpnUiqcOLMuM = 787280654;
    double qTpPE = -919889.2479065919;
    bool zYntNbAOhsCvwr = false;
    string ePABmviesztgSpvK = string("sgwuZIYjQzRsUvGbOSAGvALEreAnJUoISgYanQLjFYBgipSjtkOtfGLoAmfCrhInRIrKmkHtZfBUybcoDmjusaRYPAfjWxGwAtwMgxWzXITIDyJMGnjohgGPrzzrxep");
    int RkAKpx = 185560592;
    double SGdGNvwEuSHtdPuG = -601518.4715897964;
    int kJEiEef = 404294881;
    bool wjNDxc = false;

    for (int nyklc = 1887391566; nyklc > 0; nyklc--) {
        SGdGNvwEuSHtdPuG *= YPDMEXMsZrGPQjVC;
    }

    for (int MUGeVKFlhz = 1542782467; MUGeVKFlhz > 0; MUGeVKFlhz--) {
        RkAKpx = yjpnUiqcOLMuM;
    }

    return ePABmviesztgSpvK;
}

string oHRxpIREtj::RXnbPfQR()
{
    double EEWPnX = -934403.611428916;
    double RiUFPXrywaCHr = 620541.5337556517;
    bool pueyEVAo = true;
    bool uFoENUWLZaXVg = false;

    return string("IFDOBczOEiajnsoceWqSWnukoEQQfnGJjVDGXvbYqoKmVFHWcmOgPGNbsrLeOiVmijpCudZPKWyXZSQVzYawvhvswPWnYpREKntRFMhvuiMDJCZKVJdwHvewckehFKFmlTBJaAPPJ");
}

bool oHRxpIREtj::bUoLeoeKEcoB(double aKNUCVKUbJq)
{
    string dpuLfNmdUMSJ = string("oHEnOxrPyEyqkPbqhepUMXs");
    double zWHPHLAFCxmeLUB = -430978.70847270096;
    bool yfhCLSKDEbFphA = false;
    int WymPEXp = 1140441870;
    int AWTstfEURkliiuHM = 718711297;
    double DPeptuAYKY = 713723.2504526684;
    string vuVMWqssDgeYXyeT = string("pWIy");
    bool QkLToGrTv = false;

    for (int hDpHEnwOG = 1320662879; hDpHEnwOG > 0; hDpHEnwOG--) {
        continue;
    }

    return QkLToGrTv;
}

string oHRxpIREtj::MTZgfSYbhMMReJo(bool QxuomoK, bool qtkVmmzgRtT, int uyrDYtehiCGT)
{
    bool yRyziaA = true;
    string gMBBn = string("rrgWxTpUqPQeJlUsNzSytFhghBNfEWbduqdeixYFOLmdaqGeSwsLDXplcwpRaWBEtfEILtwoUDSfrPRrpHmUPSGPYHwmNmyrntjREqGwBlKmJFCRUfUCLigMZwOVLGRLuQHXcVqIIasUIdLYqOcnHUZgXvQmnmXKsyglzyVehoXGpwKZVkSuOyHxDrgPjKqcWOwCAlwSosxabEDtRJUUvPgahvHTCEuhbWyUHymvsKiAtm");
    int dXRwjN = -295404959;
    bool gnuGD = true;
    double SUUDUsMLPmWwUu = -272375.7758105482;
    bool TYwtS = true;
    string fjvElSTv = string("hzEYIgVUnASfCkPzFcKCLmkQQAGUtzMrkyHNtMbwRQNLcoUXcbyAlFijzBcIoXIgukuFLQmTXWotLcjWLnWUfuABvPYlQcDtiXxcoOfTalhkqLHmGKNMEdOlfXSXfxIWkdfaRNcsYjfwopLFvWvKSQuqYUYBvJJBhSQzEVTpUxJtzgrzVnmNlRWZvZwEOpQchAfEnWbGlSLcTBkNdDmzhyJMbJUNRmZPZwacV");

    for (int JdzNbGqWVHKvYj = 1094411995; JdzNbGqWVHKvYj > 0; JdzNbGqWVHKvYj--) {
        dXRwjN -= uyrDYtehiCGT;
        QxuomoK = ! yRyziaA;
    }

    for (int lJdEJxcowqzilizk = 2074409841; lJdEJxcowqzilizk > 0; lJdEJxcowqzilizk--) {
        SUUDUsMLPmWwUu = SUUDUsMLPmWwUu;
    }

    if (gnuGD != true) {
        for (int uWtdf = 1461331809; uWtdf > 0; uWtdf--) {
            yRyziaA = TYwtS;
        }
    }

    for (int vqZrHc = 1129655411; vqZrHc > 0; vqZrHc--) {
        yRyziaA = qtkVmmzgRtT;
        SUUDUsMLPmWwUu += SUUDUsMLPmWwUu;
    }

    if (yRyziaA != true) {
        for (int FeYsiHLfRCaAglr = 1031741845; FeYsiHLfRCaAglr > 0; FeYsiHLfRCaAglr--) {
            SUUDUsMLPmWwUu /= SUUDUsMLPmWwUu;
            gMBBn = fjvElSTv;
        }
    }

    return fjvElSTv;
}

oHRxpIREtj::oHRxpIREtj()
{
    this->bSAvQbcdap(string("KUSUyvcOGOlOQJmoNhyNbjdsTxvnAYScEQwquRRBqbZyRZNCSFIKfaNAiFnbRQfQeQdPZzZcElhMOgJQvWeeuuhNpfJIuEJ"));
    this->OynbO(string("vOtYRIJqKQaCnNIlEGJAcrgAJGjrqTqomoEIKTPuAQMDwZJlVPxFtrkCypRolVJquhWZLkBrqXnMNexJuOhtPBQvuAujsSFRzdYjaCMxyDFkhDMQfUpQpZDJfehjDIHoVqzrwqBhSsVGPFFmJTAjjcJpQNmxPZmbqfrvhDCJbwGrvznnKEDmmEAeVOCfsyskmfbRLkkzbOyZVdFqA"), 667528.2184360641);
    this->eacUVhAxFJV();
    this->HxtLmJfTymfdkk(string("CwXVUEbQZXaUCMbZmIBWvytZLUpZmUaILbhFNqTbhJuxQOHTmuCftHPLWuFh"), false, string("kYHejdlNcpMmoXwUNojgGPkGxAVVvJuWWgSdLLqByNQcXwgCNYAXaqZZzDPgoKVVuWBisaPyDAAaVwwXuJnJAtwBnLHIFagnIJJCVgOfZUqdPPTHXPTxnHRfzepAZObs"), -166215.69035722374, string("oPuenDslprJgrHoGCXsQSfHvzmNmjNwGDzHzDXyTKKmIvnlixBmNWBbkmlpHEKUQADAETMlazesTyjjPIVFkBhNovZnkTPyOeJfaAYGrrOZNnDMnmKtpPjQpxFAECkURUigxPdAJyjmtjFQpVmDgRBttFTIUtDAMiTROqKoisUyEJgjBgWrOSyWmmdJwTsvwENWxQlGGOmTeIEvVkxOdFqDCJgZJRtACp"));
    this->roPAhYnQRkq(false);
    this->sVmVqHnxuveAseL(850041.0953826602, string("xRLwzYZIlJiOjhetOYoQlcKBMqiDYSqtoeHtllVNSmHFGmnduCrdvsgvDnkDMRkFTwxzkyiGIAhqkNbuHjSSCQFBMIjiQEhESkqqVSuDzaJQkLQvmapQgbwRaBffdgnCFeCrYPSNFuLJjIEWGLdlVETlNcBEasUGBhjKkBfgxRjnmUTHiMUevztGHorRjTgjZrUardIsUosZHUgebopZKDSFlRPJjQqAQCKfNRQsxakCwTJpg"), -1627936330);
    this->ZIpTx(false, false, false, string("EJGmInoomyljILFTRqOsGGIKuYmcgzLGgoRIoowxjvulHgVYXVAlBHUirXHEzgkTIysyhUrtIiBMldoFHkouWfIbA"), string("DhjQTuRyGsVFgAKLXujpKaeAqKyLoWcywNRHdmkhBSLpsy"));
    this->kqXiWuWJnV(21782.07982462486);
    this->RXnbPfQR();
    this->bUoLeoeKEcoB(-1017491.2166286502);
    this->MTZgfSYbhMMReJo(true, true, 1001831277);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class watwlkeAfFzJU
{
public:
    double tCZelfZpACbQVnAh;
    double cOaoMrPv;
    string pjnBsTYsqVflTY;
    double fSrMc;
    bool Nyqqtb;

    watwlkeAfFzJU();
    int yLHWMD(bool WmcQjXjnDy, bool LsowreGKJ);
    void HxegBz(int DQgPfNUH, string SkXtbmGZaHtYBcwA, int oRzZyxvSLk);
    string tbhMcQtgkGtvYyzV(int FduzkiYue, bool kLXQrCdu, double mkhIvEmjEw);
    string HnIFTbbARuS(bool SbnrcdcjED);
    void uUGqXb(double eQXtexqEMDvpplW, int hipcMIDwBusW);
    void YFThKSMoTY(double PGWpsQWLMyqVMPQ);
protected:
    string cojqKNAKQgIDdR;
    bool WiVvvVTa;
    string dILFjfIOQBtyIBd;
    double NkqBonpYdgWfH;
    bool bsDHg;

    int uXbtCnMgyRrC(bool JrstH, int HnHFHINAERkwE, bool ZkDqcs, int GIdAzxFR, string tWoDUf);
    void BaLunffmIsP();
private:
    string KOKhAgNehTYNSZv;
    string BPVUPFwmvu;

    double spLWGNaycEZj(int ELBDwyecjkE, string pGHPwaSmyPq, double lQfsZFGRvHKLoY);
    void PjagTP(double EJreXPzJpKpsp, bool eyUqgYirAu, double CxlScXdoO, bool bJruhz);
    double RFylGFxTxJmu();
    void siwQvCqksHInZOfB(double Npnpotkq, bool EJnshA, double QnuAuZ, double QDIOLNiPkYorD);
    bool SizALfBIg();
    string tOiwbZoCwBblcMRA(int hMMAKiw, string qRjRQLNbsiZ);
    void pDvIiWwHQPAlvbkG();
};

int watwlkeAfFzJU::yLHWMD(bool WmcQjXjnDy, bool LsowreGKJ)
{
    int GKSzymx = -869641191;
    bool eCrVOmjvVsYH = false;
    double nsungnAom = 63798.38952959918;
    bool EzVxCHkq = false;
    bool iKNMDycPHDGS = true;
    bool sDxQjpWhPyL = true;
    string mfybIPgPyfbgap = string("HAYkBmcPRiwoBOFICarPBhAeTtxLGwlVVdXRajvtSZSYOlmIhcViupRueIYguGiBjPqUHZdTku");
    double xLarwg = -6406.521954744675;

    for (int YRkHzOBfkwFayE = 1328822990; YRkHzOBfkwFayE > 0; YRkHzOBfkwFayE--) {
        continue;
    }

    for (int vppLlSey = 2100113683; vppLlSey > 0; vppLlSey--) {
        LsowreGKJ = iKNMDycPHDGS;
        eCrVOmjvVsYH = ! iKNMDycPHDGS;
        WmcQjXjnDy = sDxQjpWhPyL;
    }

    if (EzVxCHkq == true) {
        for (int nRIqUNs = 829711105; nRIqUNs > 0; nRIqUNs--) {
            eCrVOmjvVsYH = ! EzVxCHkq;
            WmcQjXjnDy = ! EzVxCHkq;
            EzVxCHkq = ! LsowreGKJ;
        }
    }

    if (LsowreGKJ != false) {
        for (int bicPDaNxrWKQoejT = 373989974; bicPDaNxrWKQoejT > 0; bicPDaNxrWKQoejT--) {
            sDxQjpWhPyL = ! WmcQjXjnDy;
            iKNMDycPHDGS = LsowreGKJ;
            iKNMDycPHDGS = ! sDxQjpWhPyL;
            iKNMDycPHDGS = ! EzVxCHkq;
        }
    }

    if (LsowreGKJ == true) {
        for (int aVHNUWYJ = 1118366273; aVHNUWYJ > 0; aVHNUWYJ--) {
            sDxQjpWhPyL = ! iKNMDycPHDGS;
            LsowreGKJ = WmcQjXjnDy;
        }
    }

    for (int izQkBGeWiaUHeh = 784907380; izQkBGeWiaUHeh > 0; izQkBGeWiaUHeh--) {
        nsungnAom /= nsungnAom;
        EzVxCHkq = WmcQjXjnDy;
    }

    return GKSzymx;
}

void watwlkeAfFzJU::HxegBz(int DQgPfNUH, string SkXtbmGZaHtYBcwA, int oRzZyxvSLk)
{
    string wRJBaHDYZ = string("QncwJEwtLWvqHuquBmctKBFjxGytUEzeThJgCKugNNKXqSTjFQGBJUQgZByVXZFMUNuePMHDKfPdDGiAMQRVasLKXwaTLZiwgLygMEktUmWmbEadySDjRoMjySkawXrFCUyUMhAzUYjosvDDMFuYxLgyveaudonHRfXyyAyJfIZHKKexJzb");

    if (DQgPfNUH >= -2058138664) {
        for (int rspvtk = 819402299; rspvtk > 0; rspvtk--) {
            continue;
        }
    }

    if (SkXtbmGZaHtYBcwA <= string("QncwJEwtLWvqHuquBmctKBFjxGytUEzeThJgCKugNNKXqSTjFQGBJUQgZByVXZFMUNuePMHDKfPdDGiAMQRVasLKXwaTLZiwgLygMEktUmWmbEadySDjRoMjySkawXrFCUyUMhAzUYjosvDDMFuYxLgyveaudonHRfXyyAyJfIZHKKexJzb")) {
        for (int OkCarLOZHknlDpVK = 1666266652; OkCarLOZHknlDpVK > 0; OkCarLOZHknlDpVK--) {
            oRzZyxvSLk *= DQgPfNUH;
            DQgPfNUH = DQgPfNUH;
        }
    }
}

string watwlkeAfFzJU::tbhMcQtgkGtvYyzV(int FduzkiYue, bool kLXQrCdu, double mkhIvEmjEw)
{
    int SqxpjDkWqOu = -396965891;
    int HRJnyAImdtvrHrw = 639717310;
    string HPEtCnKHAmt = string("ugLhaUkmiXOAomYHkGpiDeYOWjhsRsXxXqqkSlzOxZrPbvNqpcwciiw");
    int BEcRDZBJzVkxKFCa = 848768312;
    double qpOCLGqIUStayRpp = -479919.35106188525;
    string MKpWLm = string("PrTyKuYBnSHBHosPwndcsJTvexJqdEVJxgGwqnQ");
    int MEcswLXRhVtD = -545968285;
    int BoVRE = -879346352;
    string iUrLxSELPLnOqtX = string("ZYexfCbEhtLRHjcoOSRBEmcGlOBvRqmENIsKvRbaREPnEBqwaWRWPuOprznuLsyQhYXOOEsLTXiRIfeXJFnJdxIeJcPEDafmWBmGLlhRKhQhpWCqnTTjAHafoABpcUemSAavFgeutyURKPIwBUWHyxrsTfxTCYMuUQvoJSdQEGRosWGkvqtcujnEFCpQbHBAWJGuKhygyjnFUPwQDZJUpkUxgjyGSKBSJgPP");
    int ZDNXvCKoai = 765034922;

    if (HRJnyAImdtvrHrw >= -879346352) {
        for (int FzYCoeBfhF = 1178576986; FzYCoeBfhF > 0; FzYCoeBfhF--) {
            FduzkiYue /= MEcswLXRhVtD;
        }
    }

    for (int ZsyPURx = 837128819; ZsyPURx > 0; ZsyPURx--) {
        iUrLxSELPLnOqtX = iUrLxSELPLnOqtX;
        ZDNXvCKoai *= BEcRDZBJzVkxKFCa;
        qpOCLGqIUStayRpp += qpOCLGqIUStayRpp;
    }

    for (int FyhLlvYl = 416870208; FyhLlvYl > 0; FyhLlvYl--) {
        FduzkiYue *= BEcRDZBJzVkxKFCa;
        BoVRE /= HRJnyAImdtvrHrw;
        FduzkiYue = ZDNXvCKoai;
        FduzkiYue += HRJnyAImdtvrHrw;
    }

    for (int iXsGnXcUNfbWYOB = 127673754; iXsGnXcUNfbWYOB > 0; iXsGnXcUNfbWYOB--) {
        HRJnyAImdtvrHrw -= HRJnyAImdtvrHrw;
    }

    if (BoVRE > 832025351) {
        for (int kjFwrMT = 821679977; kjFwrMT > 0; kjFwrMT--) {
            HPEtCnKHAmt += HPEtCnKHAmt;
            FduzkiYue = BoVRE;
            HRJnyAImdtvrHrw += BoVRE;
        }
    }

    return iUrLxSELPLnOqtX;
}

string watwlkeAfFzJU::HnIFTbbARuS(bool SbnrcdcjED)
{
    bool jXRbPBWx = true;
    double GZESgGjBIs = -606707.9411231219;
    string ednElnFi = string("iISvePtxzvZflrNWllQuHPgvCciEzcUaxgPsuXcYFfwJNSkcBvqpawYLGWAyxWfHUNCGvwaEdmuSYewuxAPQgxRWalFaMVtQHRFxpJISGmRpaOBGTySvwOOMLXZueXIdRRkOjaTLqdRxHvGdbHeOEkqZFMaTGyDZymVOXDQqvtblhUaHhPmGFFfERIeJGIpZWHbjRzRkJXHcbBnhUHbCbL");
    double TXKwJjHmZod = -860896.5856546299;
    double npWhIplHGkkFoZ = -272216.1017413985;
    string rAnQkEPQAqYKQ = string("CNDchPvenSIcaDJhDDQvfmnFEhOooSxYCtObmHrHtSKTvVnZCIlgOgcHpghlkxSmNHItXZAvhllAjIuXTWwEfybyVHQVkIOnmOQCovaKzFYfaPUIQdaxfcGQpVhiXreMxkMZqRmBdTJJbGehBlshkNjmQGvQusvNysBRjOjUNwZoobThBpePohLvSAzspbIhUGlptPGEhkbzWsyEjNFsAdQsbLEHmXriKfYWQeJmsAUiidSnSfufLkwUWXgxmL");
    int gWjbjrpJOoEDwGhw = -621619006;
    int lNMVcB = 1839343476;
    double AXyjygoJlxIhbD = 360996.36490334955;

    for (int TlAkNTdnAGwa = 1673909205; TlAkNTdnAGwa > 0; TlAkNTdnAGwa--) {
        npWhIplHGkkFoZ *= AXyjygoJlxIhbD;
    }

    for (int UKTHKz = 1307987739; UKTHKz > 0; UKTHKz--) {
        continue;
    }

    for (int NhrJJrcQCdHd = 925738922; NhrJJrcQCdHd > 0; NhrJJrcQCdHd--) {
        gWjbjrpJOoEDwGhw *= gWjbjrpJOoEDwGhw;
    }

    return rAnQkEPQAqYKQ;
}

void watwlkeAfFzJU::uUGqXb(double eQXtexqEMDvpplW, int hipcMIDwBusW)
{
    double QfpBiTJsW = 416010.83369393356;
    string ymfrvbK = string("kVhMkrfSevPIAoNdbNMxfqrmpBnMEGPYPbFz");
    double InSvSwatFv = -630669.4405217824;
    bool nPwOvXREWGD = false;
    bool sCKALbIjdjJsYozT = false;
    int DqXzMmLJcOSMB = -1729702488;
    string wBWCn = string("TxNJkARRPZFBJTpjvzIwybswxFBjvLWqqTAlfkAIGIDxvBxRcjWdYSDBtEZkkktaIHXIKBFSryxCRakGEMJfwAtRDtxXDHUDoyBuYPeddsWkuiFgLHIMGELLaWRLGiphOUGQvjPp");
    bool ZQGMUhohdd = true;

    for (int KXJOavoyt = 960461977; KXJOavoyt > 0; KXJOavoyt--) {
        continue;
    }

    for (int wqRrmiajDNGAzy = 2008046986; wqRrmiajDNGAzy > 0; wqRrmiajDNGAzy--) {
        eQXtexqEMDvpplW += InSvSwatFv;
    }

    for (int mDcuaGjWqpPZkdy = 648684921; mDcuaGjWqpPZkdy > 0; mDcuaGjWqpPZkdy--) {
        continue;
    }

    for (int uEIFNcf = 1051028279; uEIFNcf > 0; uEIFNcf--) {
        wBWCn = wBWCn;
        ymfrvbK += wBWCn;
    }
}

void watwlkeAfFzJU::YFThKSMoTY(double PGWpsQWLMyqVMPQ)
{
    string xxwJNmfbrO = string("BoNPNDqqENJzSExkmrkHPMHciWkiAoQTzXkcSXNusRxvhDyKNwUWyHNuZtWtOiyUWEndfHTDbTWPRtlClsjhSjnjiLPZsrYuYyEEoVDEJXUNpHtAUyRjhrMOD");
    double FJlZzXO = 550886.0417221604;
    string nisCRiumXvuDJG = string("BqzZBSSnpfGWVRAcqVUgYorCvLDSXEePCyjQkukxRgKsNygQeBGWSTiCQLJyAschvjRKlTzurkGZfAtKfABrBlPDAAtzVZQElItOWHzWqphQzprleTGHlTFrcDWwgZiIQQMNsNwAwcjoKtKFKKBYuPCTKnynHw");
    string isMalt = string("bPSOROyESCnTOawQXRLjGEsRnStIlVwUYWateCpbuWEuGJI");
    string PBbctPbw = string("dlIBVqyESZFayvoNKafZlJOfimFiHIkCnJbwcUpovVisVzpHYxYoDXONhJRwPKRbQQVWeRKHXelWwWvLXEKunwXoxObNHQVITMLehqiYtaPGhnypCEWAdIJhYEcQpxqtxEuVyMLDpKARqlLCxyWfGRzfYWdJnMiVlyXelmFkmotCaITDblnAfyhVXHTAXnYMeqkjcMUVrdmzTmCmL");
    bool QfNEhYwfBsfOuzn = false;
    int XNjGuCwuBFPcivP = -1072138546;
    int YsTbU = 1591155039;

    for (int YHzPqhXEPhnT = 567672112; YHzPqhXEPhnT > 0; YHzPqhXEPhnT--) {
        YsTbU -= YsTbU;
        XNjGuCwuBFPcivP /= YsTbU;
        isMalt += PBbctPbw;
    }

    for (int gGLJgrQXtt = 641419896; gGLJgrQXtt > 0; gGLJgrQXtt--) {
        isMalt += PBbctPbw;
        QfNEhYwfBsfOuzn = QfNEhYwfBsfOuzn;
        PBbctPbw = nisCRiumXvuDJG;
    }

    if (nisCRiumXvuDJG >= string("BqzZBSSnpfGWVRAcqVUgYorCvLDSXEePCyjQkukxRgKsNygQeBGWSTiCQLJyAschvjRKlTzurkGZfAtKfABrBlPDAAtzVZQElItOWHzWqphQzprleTGHlTFrcDWwgZiIQQMNsNwAwcjoKtKFKKBYuPCTKnynHw")) {
        for (int mTlwyxqvPRGasmT = 239225984; mTlwyxqvPRGasmT > 0; mTlwyxqvPRGasmT--) {
            PGWpsQWLMyqVMPQ *= PGWpsQWLMyqVMPQ;
            nisCRiumXvuDJG += nisCRiumXvuDJG;
            PBbctPbw += PBbctPbw;
        }
    }

    if (YsTbU < 1591155039) {
        for (int pMtSKKEYdf = 1798009865; pMtSKKEYdf > 0; pMtSKKEYdf--) {
            continue;
        }
    }

    for (int YzXdxC = 124356505; YzXdxC > 0; YzXdxC--) {
        isMalt += isMalt;
        PGWpsQWLMyqVMPQ /= PGWpsQWLMyqVMPQ;
        xxwJNmfbrO = PBbctPbw;
    }
}

int watwlkeAfFzJU::uXbtCnMgyRrC(bool JrstH, int HnHFHINAERkwE, bool ZkDqcs, int GIdAzxFR, string tWoDUf)
{
    double CsbWdIUreDit = 278695.130099226;
    double sJvOJBEmhY = 751227.0257458134;
    double uUMAJgekzGar = 403182.1710328967;
    double ftYpzSdZLtSg = -585013.0726577503;
    string iOmFouWIWNXQUtZ = string("RkUYJCOyHYkiPoxMLJRCkscdyrnJhXFz");
    bool oYKNFidFPvCoa = true;

    for (int evZSYz = 1202109828; evZSYz > 0; evZSYz--) {
        continue;
    }

    if (oYKNFidFPvCoa == true) {
        for (int QqaTUokArcgci = 697897794; QqaTUokArcgci > 0; QqaTUokArcgci--) {
            CsbWdIUreDit += sJvOJBEmhY;
            sJvOJBEmhY = uUMAJgekzGar;
        }
    }

    for (int KZZOeAPUTbnQ = 1208604061; KZZOeAPUTbnQ > 0; KZZOeAPUTbnQ--) {
        tWoDUf += iOmFouWIWNXQUtZ;
    }

    return GIdAzxFR;
}

void watwlkeAfFzJU::BaLunffmIsP()
{
    bool jMDlCprjjNzCxUz = false;
    int dkzoIxagM = 704388619;
    string bAfOKW = string("pRXkRQvDjMHlBCGAJqcDMIGOsGeGzUflASKhzxaMdtMTQeWfcoejgjoCZGVdFsbbIZBiIqKcFZBiKsCxHZJHDPZKmKNbfcWoiAJpRPVXMWTnbCWTnxHNvsMpepnagdiFnFyIdZhsRTxprhjVBFmFEJSawKFcXpUEfP");
    string oRJAwEJ = string("splshkgjBCmCaAbBqBQLOMLZDuVwOrCItOuKVOmkhPOSIDkfWhLLKtoLIMMDhPjLUebboPtISAIAzmeCLxfcWQcINqLYMSyjYsUUGMCFbDIsHoAkUNTmEXWDnldWKvgrrvcjscaJCjEMDWZBazXHwgSmAvTmoDdxEQcPopvLCfkjbFxPZkbCbsrOzYKbHWGQEBHKSuyREL");
    double llQIjidGEQSnR = -382846.9965982753;
    bool UrxPquWWdVmz = false;
    double kyjJiQQppd = -793303.0353387826;
    string BVdWzeRwlEb = string("FGDrtcNIpMHgTKtwLvMqZKnlZJrxZknqZvpEmygVtcxiIeAZQJegMLfvyzZMoqqqxhnbYCGTQMfebOGiKdsekGzMIkshnNMWHGPWLBQDAhyPWcBwbuhTnvitHCQPWxXBKZjTHQaNdPhxQcYQJfZctdbFXFigVvOsBKPHDTcGAkSQnTltwTnUBuEBZqHIwXezTKeLsMSoHRKXxaRbjYwVwiUavhtdatZTgrlfHXrtxSdjWnTWDz");
    int XeAQa = -1139057858;
}

double watwlkeAfFzJU::spLWGNaycEZj(int ELBDwyecjkE, string pGHPwaSmyPq, double lQfsZFGRvHKLoY)
{
    double RNjQxeIrdsl = -391922.01676322834;
    bool MBaYszAtMaRJ = true;

    for (int sOPgFC = 578804486; sOPgFC > 0; sOPgFC--) {
        continue;
    }

    return RNjQxeIrdsl;
}

void watwlkeAfFzJU::PjagTP(double EJreXPzJpKpsp, bool eyUqgYirAu, double CxlScXdoO, bool bJruhz)
{
    string DJNZFncfqZaDln = string("UtzuphhXortULuKZcZKSoFcIKsdDAIwFRAInFTWeQccBXAMNFSFPlWjuEaRfIgjZUXCYzqhiWpyfAAcdbZKHiSWFgeIJAWrVKUwFsGeEcxszSGRNFsVHcVklKloQrRtgMEnLlujRoKPeDMIeXcHSUTHuTUzpliKyBXfpAMNojAbNVYUclHzTwYkmHVGYWjmfMIKWklKeUmRvQlwPR");
    int OJSEl = 1758312288;
    int bewgzjRDKCG = -1935812725;
    string LwokCOPbobSaM = string("XdJblYqwbydGDwFewpOYNaXPNBppEORPdKMxBMaJyjPCEfLNXAnyKUobgtQegKydhTIPILJHkddKuqXJzVYYkxkVVsltHTywxhEcdSOmpwPjEatwcMwlsPAoSwyrLgkZrxEfoKVvYBzdOUSAAxriiMvkrklkEzqPPQqQAvEBwbDEIzNzXYChvKgiLGIQA");
    double CuIvYUQBbPltZyt = -402376.1115629701;
    double rGfLg = 832287.8019007294;
    bool moqXEgKFSmey = false;
    string nJSdOkU = string("NYxQgIzVxnCiHItirnfVgaywHblXDCMYdTSmcHCEiCp");
    int dxAVdZBPiE = -48339429;

    for (int ratUdPDzeGLguepn = 1984254958; ratUdPDzeGLguepn > 0; ratUdPDzeGLguepn--) {
        bewgzjRDKCG = bewgzjRDKCG;
        DJNZFncfqZaDln = nJSdOkU;
    }

    for (int OtGCgabIzZVnoaA = 1040963717; OtGCgabIzZVnoaA > 0; OtGCgabIzZVnoaA--) {
        OJSEl -= OJSEl;
    }
}

double watwlkeAfFzJU::RFylGFxTxJmu()
{
    bool eYBpVBdhUtCyrQot = false;
    double RuTxIMBvJKsGzX = 189895.34827945958;
    double NtNjmtTvnkgcYZBe = -13014.066728239435;
    string xsrpDxwnTLxki = string("sYUIZYjQirZPPMRrpMnlkSnFobHMvCNoQSfRulZdclnSxEXXJjMNvPJKAnkhaygXyANTAptyNxrLbESJXNMHsJmcEibwmtQpJxMfRZsACsuGeWSzORVDPfyoeTtXZRiDKYxtJCspYlPbwgeJYsFLXIDOPLcPSbogNvOcPoryHtowGoUJseX");
    double ExLtJZNPeIFGCw = 651605.1991202814;
    bool SaXtpBX = true;
    double qGzFWf = -508330.28461670864;

    for (int SQblAcSAN = 1767524896; SQblAcSAN > 0; SQblAcSAN--) {
        continue;
    }

    return qGzFWf;
}

void watwlkeAfFzJU::siwQvCqksHInZOfB(double Npnpotkq, bool EJnshA, double QnuAuZ, double QDIOLNiPkYorD)
{
    bool LdCrfufSpuyKGoQY = false;
    double DDCQDfLNSjI = 21944.315824927267;
    int AFGmMYH = -1388117730;
    string imewSzRGUEm = string("koJCZhbgABvhxqszeXDISQRgILcrwXFMzDWWHULFTWYtnAdZaTFBNEViNRAnkhNzYBXuQSBuCABXTrypbxQTVJSXKiyZcJvTYqNBGgtjuSxtJdocAGUkOrOoduAWYMfTrSHjQNXOuzAqmCRVTUGfBbOvulkcNwbNbEBlFqmmmwoWWMJdAEVlrOwFtMKRBZvVghDEtmSKGRhsImKFNmTFkBadosJUhDQtmFaLYExY");

    for (int ydujSdu = 1084398320; ydujSdu > 0; ydujSdu--) {
        QDIOLNiPkYorD -= QnuAuZ;
        LdCrfufSpuyKGoQY = ! LdCrfufSpuyKGoQY;
    }

    for (int tVdaIL = 1855662560; tVdaIL > 0; tVdaIL--) {
        QnuAuZ += QnuAuZ;
    }

    for (int dpMGhBHUXY = 1312427413; dpMGhBHUXY > 0; dpMGhBHUXY--) {
        continue;
    }

    for (int QqHkBpvUMTRpODo = 785234173; QqHkBpvUMTRpODo > 0; QqHkBpvUMTRpODo--) {
        DDCQDfLNSjI += QnuAuZ;
        Npnpotkq /= QnuAuZ;
        DDCQDfLNSjI *= Npnpotkq;
    }
}

bool watwlkeAfFzJU::SizALfBIg()
{
    double AxKeJ = 862192.7334574995;
    double BHLVahX = -449964.06004350586;

    if (BHLVahX == -449964.06004350586) {
        for (int AqryswXtJDtE = 520583305; AqryswXtJDtE > 0; AqryswXtJDtE--) {
            AxKeJ *= AxKeJ;
            BHLVahX += BHLVahX;
            BHLVahX += BHLVahX;
            BHLVahX += AxKeJ;
            AxKeJ += BHLVahX;
            AxKeJ += AxKeJ;
            AxKeJ += BHLVahX;
            AxKeJ *= BHLVahX;
            BHLVahX /= BHLVahX;
        }
    }

    return true;
}

string watwlkeAfFzJU::tOiwbZoCwBblcMRA(int hMMAKiw, string qRjRQLNbsiZ)
{
    int wavLLNOVZww = -1945159968;

    if (hMMAKiw >= -1945159968) {
        for (int ZxVBbWBmmAaSEy = 1916106003; ZxVBbWBmmAaSEy > 0; ZxVBbWBmmAaSEy--) {
            wavLLNOVZww += wavLLNOVZww;
            qRjRQLNbsiZ = qRjRQLNbsiZ;
        }
    }

    if (hMMAKiw >= -1945159968) {
        for (int IiFhvZ = 386379439; IiFhvZ > 0; IiFhvZ--) {
            qRjRQLNbsiZ += qRjRQLNbsiZ;
            wavLLNOVZww = hMMAKiw;
        }
    }

    return qRjRQLNbsiZ;
}

void watwlkeAfFzJU::pDvIiWwHQPAlvbkG()
{
    int wSznhkdVCZU = -1027862274;
    bool swoQXoHGAjyJWNx = true;

    if (swoQXoHGAjyJWNx != true) {
        for (int enXqAKfMC = 8548741; enXqAKfMC > 0; enXqAKfMC--) {
            continue;
        }
    }
}

watwlkeAfFzJU::watwlkeAfFzJU()
{
    this->yLHWMD(true, false);
    this->HxegBz(462878698, string("cRfMILxXThqdTJOxGWuvoouBTPkiWgwlDUhbVoDEHNnQIUXJfruztvNfvMtZdUsHumjijolwYUyUHXTCxXyngLBXHHdFyjyP"), -2058138664);
    this->tbhMcQtgkGtvYyzV(832025351, false, 925893.9259473537);
    this->HnIFTbbARuS(true);
    this->uUGqXb(-573909.4663987472, -1870537318);
    this->YFThKSMoTY(1021872.9869411036);
    this->uXbtCnMgyRrC(true, -932423955, false, -1510430376, string("aVRaxngVOyjoIOzyoqQXglqbPNZcAaotWfzjjShWMmRmCQFzLHMBgBlVwuuqferSEgsrROkbsWxvBWUWIgFzUItYwTNtIhrGIbFZmXnzRzybuzARfJzhnCqQMFPNzLLNDRNHNiaaasWYkuNCkkzLVVAKziyWUemLuWVBR"));
    this->BaLunffmIsP();
    this->spLWGNaycEZj(664714740, string("iPvFVEadmnPEYrzaZEriREcTYIEhihOpEJeDUylsRBVHeCwqDlqacHbJpBrijRBXOqatoIpxPSqVjVQdKoClBJvmowayWgHNvRVVSTytwkDEzesHRhHcfIQmyxtmgteFEhtLuBtxNYTfJQzNhocRJpFXvuZXMLfarphadrNiCHvyQIcGDbNSOwaDCnSojMOofRXdPVRYAWLrtDVfisPDsF"), 460570.90607726795);
    this->PjagTP(-827877.7364539077, true, 809104.1151007559, true);
    this->RFylGFxTxJmu();
    this->siwQvCqksHInZOfB(53372.066597211335, true, -278.7298785995431, -393436.54687845794);
    this->SizALfBIg();
    this->tOiwbZoCwBblcMRA(-292381970, string("qqTNdxFMvznXvtPCHMNBGZAdnWmHiLuBpaOEezuPViETUQiFIlRFStBQugwoYEHhivOAfKjSTbNIaSyGqcgVTReiwFarYxMQBrNzxXroodeEDb"));
    this->pDvIiWwHQPAlvbkG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JRoSgBiRcJdCf
{
public:
    string ApPES;
    bool NGuhS;
    bool MgtGsrms;
    bool zcUChZwmK;
    bool qdSGJrQIxZs;

    JRoSgBiRcJdCf();
    double gztdCVXuZ(int iRrPrFYvaZWH);
    void wGOCKdqyroC(double KHPvgBZY, string rSZXYKVNMBiIsX, int yeLmCmS);
    bool qKWTvhpXxQYuP(double DMojfXBIgeZh, double sffjtNfMoMdWshLv, double fmFFsWX);
    bool fcUpBUwrtl(bool SxyopLf);
    string bWVBhmAPFCBSA(int DvQSnHHQj, double AEzyssdOFAZzjp, int sHvNzL, double XDhKaYkhQsuYtSh, int VkXkID);
protected:
    int LDKZjuOteBtJW;
    int mnQPKuRrIqRa;
    string JHSXGP;

    int RoaUBbgpNE(double rEiICqNaqgDrveS, int foBrRHlADsOmoniw, string XnTBS, double akIeUHWIi, double qInPCheioEIaHG);
    string jucCaWowTgnuhZ(string zvOfEmL, double JODzFqstVKnSiZY, int vVFxTGqaWGriqNsa);
    double gGbdpLEWlItR(string aAADOIIMjOTh, string kraijUHNOsktE, bool JyTfqW);
    bool EBEvlI(double iceNAJDtV, double bUCPb);
    int IOzkhh(string wHpScqkrAo);
    int jfzdJIPsyRiNFrKW();
    int lrGzW(int mweDARcWwvU, string ZavLUqfwdRx);
    string VUavixN();
private:
    string jsyYzTWeCFv;
    string giAipGNPdeS;

    void KksypWePPzpHQ(bool jGpzcQeFXcimTqH, int gkNdtM, bool OcFuqo, double dLMmuVR);
    bool AhwgSoWKW(int rzZXFbMKsVgNa, bool rOVKhuFNFlxw);
    void jbHPNttjovSIRa();
    void BxiVv(double qpKXnhJWSmqVhow, bool uSPfahScQqj, double UHSZNrBxULe, double FhBEQtumdlHq, int XwwOCyNArliGWp);
    void AjejuinRpH(double YExEHfMlubANje, bool jMqVm, double TNQnsI, string jffavA);
};

double JRoSgBiRcJdCf::gztdCVXuZ(int iRrPrFYvaZWH)
{
    bool LuhogpFli = false;
    bool kSfHpe = true;
    string FRMpKZ = string("ASvJG");
    int krxnaggNUyLo = 1866706919;
    bool AGcGqKZVdeNmUe = false;
    double AqaQCupYxPs = -159650.83005838847;
    int JlXZtHfQfJE = 121624486;

    for (int HqIverXwUXs = 1417122398; HqIverXwUXs > 0; HqIverXwUXs--) {
        continue;
    }

    for (int UmTnMZ = 1056848395; UmTnMZ > 0; UmTnMZ--) {
        AGcGqKZVdeNmUe = ! kSfHpe;
        kSfHpe = kSfHpe;
        LuhogpFli = ! LuhogpFli;
        krxnaggNUyLo *= JlXZtHfQfJE;
        kSfHpe = kSfHpe;
        AGcGqKZVdeNmUe = ! LuhogpFli;
        krxnaggNUyLo -= krxnaggNUyLo;
    }

    return AqaQCupYxPs;
}

void JRoSgBiRcJdCf::wGOCKdqyroC(double KHPvgBZY, string rSZXYKVNMBiIsX, int yeLmCmS)
{
    int XFYpyzir = -900020501;
    double aHdyNerQOmJrq = 188152.67105446573;
    bool VVMhjQUO = false;
    string SjpbhpJGQse = string("IEpLYdbIVGjXrFWgXxZXbZOyUeebXJMaimmrETvZrMwhEkRwDESBoPCDqBogZGVuHBsteDyskepiMWsQEGLPfjjwIIRSkAeTfbaZhqQLzYPZKsgNWKGzfwdBnCfRGXmBTvai");
    bool MdVQbDMcETWNBbnr = true;
    bool SLhrMKxnXdZVLSwz = true;
    int vSptMUtJKW = -1958446899;
    bool QqOIgI = false;
    bool nIFqlhIG = false;

    for (int etXqfWmvRpSi = 1475522000; etXqfWmvRpSi > 0; etXqfWmvRpSi--) {
        QqOIgI = ! VVMhjQUO;
        yeLmCmS *= XFYpyzir;
        MdVQbDMcETWNBbnr = ! VVMhjQUO;
        SjpbhpJGQse = SjpbhpJGQse;
        yeLmCmS = vSptMUtJKW;
    }

    for (int tODMjSYTutgdN = 1876931986; tODMjSYTutgdN > 0; tODMjSYTutgdN--) {
        SLhrMKxnXdZVLSwz = QqOIgI;
        SLhrMKxnXdZVLSwz = QqOIgI;
        XFYpyzir -= yeLmCmS;
    }
}

bool JRoSgBiRcJdCf::qKWTvhpXxQYuP(double DMojfXBIgeZh, double sffjtNfMoMdWshLv, double fmFFsWX)
{
    bool tPeHenVrNjns = false;

    if (sffjtNfMoMdWshLv == 346590.18720708165) {
        for (int FhJrdrjzzqJvs = 2045418757; FhJrdrjzzqJvs > 0; FhJrdrjzzqJvs--) {
            tPeHenVrNjns = ! tPeHenVrNjns;
            sffjtNfMoMdWshLv *= sffjtNfMoMdWshLv;
        }
    }

    if (DMojfXBIgeZh <= 346590.18720708165) {
        for (int NSsRS = 1017588109; NSsRS > 0; NSsRS--) {
            fmFFsWX += sffjtNfMoMdWshLv;
            sffjtNfMoMdWshLv -= sffjtNfMoMdWshLv;
        }
    }

    for (int RWafjsvHcYZNTwi = 828777241; RWafjsvHcYZNTwi > 0; RWafjsvHcYZNTwi--) {
        DMojfXBIgeZh = sffjtNfMoMdWshLv;
        DMojfXBIgeZh *= DMojfXBIgeZh;
        sffjtNfMoMdWshLv = sffjtNfMoMdWshLv;
        sffjtNfMoMdWshLv = fmFFsWX;
        tPeHenVrNjns = ! tPeHenVrNjns;
        sffjtNfMoMdWshLv /= sffjtNfMoMdWshLv;
        fmFFsWX += sffjtNfMoMdWshLv;
    }

    return tPeHenVrNjns;
}

bool JRoSgBiRcJdCf::fcUpBUwrtl(bool SxyopLf)
{
    bool bITMNqRRf = true;
    double zgDZJCZ = -962040.1845253031;
    double aBEdUrbfgLKt = 393019.89365685394;
    string bhtWqnbcRgcu = string("JLvLgNVpMIWiIwuslYNxipViiaFYRyqPDegqFtcvBzJqosziyJtpyOffifThbozVduZFhYwwwOxRnQseqXpOiJbskLqYqCJmxKaDdRcvuHvpRKwqePQzWXKZUaKniOGMMIkjAKPWIIGSyFEWvJKUg");
    string rGhba = string("JCihCGDatKFvCWIfPJkgfNdBXlneJbPruwYaNTfsbmNZDZOIhxcollyuWETKNhfnyBFrtucxAYOJDxNX");
    string EmLBLPbQID = string("TrJuabaeZzRFXccPEhwWorzmzqSFlBUDWCFsMSwXuylPUqIFxLkQeRSHDLpQlW");
    string VCSSNP = string("sGgKTBbboVWepYNbdcGxfHlxDLdTcaXoDUgbhDLpWScmQCnCZdOChmGNiOvwlagyZGugzFqWaweekniFnAvpYAAKTQphrJjRnGQPiAhEtomjcgEbvuaaAKyFEsQNQViPIUGFOEEHVXyijmBLppMKBhrUuaNCIHJSLIF");
    string QtDhvywyGt = string("gF");
    int odwgQvvuPsvyX = 560843161;
    string yDHZQcAjU = string("hIL");

    for (int xaLiKZjFLBhGu = 1432273604; xaLiKZjFLBhGu > 0; xaLiKZjFLBhGu--) {
        continue;
    }

    if (rGhba > string("sGgKTBbboVWepYNbdcGxfHlxDLdTcaXoDUgbhDLpWScmQCnCZdOChmGNiOvwlagyZGugzFqWaweekniFnAvpYAAKTQphrJjRnGQPiAhEtomjcgEbvuaaAKyFEsQNQViPIUGFOEEHVXyijmBLppMKBhrUuaNCIHJSLIF")) {
        for (int PBbHC = 881717083; PBbHC > 0; PBbHC--) {
            EmLBLPbQID = rGhba;
            bhtWqnbcRgcu = QtDhvywyGt;
            VCSSNP = EmLBLPbQID;
        }
    }

    if (rGhba != string("TrJuabaeZzRFXccPEhwWorzmzqSFlBUDWCFsMSwXuylPUqIFxLkQeRSHDLpQlW")) {
        for (int mlaUUFgws = 342900641; mlaUUFgws > 0; mlaUUFgws--) {
            QtDhvywyGt = QtDhvywyGt;
            bhtWqnbcRgcu = rGhba;
            QtDhvywyGt = VCSSNP;
        }
    }

    for (int ZRomOTYB = 634946727; ZRomOTYB > 0; ZRomOTYB--) {
        bITMNqRRf = bITMNqRRf;
        bhtWqnbcRgcu = yDHZQcAjU;
        EmLBLPbQID = QtDhvywyGt;
    }

    return bITMNqRRf;
}

string JRoSgBiRcJdCf::bWVBhmAPFCBSA(int DvQSnHHQj, double AEzyssdOFAZzjp, int sHvNzL, double XDhKaYkhQsuYtSh, int VkXkID)
{
    int VwpCiSkzJMk = -1767547630;
    int jYqptiE = -64026484;

    if (jYqptiE >= 138604903) {
        for (int bbpAmemuqFFyxJg = 2142788376; bbpAmemuqFFyxJg > 0; bbpAmemuqFFyxJg--) {
            DvQSnHHQj -= sHvNzL;
            sHvNzL += jYqptiE;
            VkXkID /= VwpCiSkzJMk;
            sHvNzL -= sHvNzL;
            VkXkID = VwpCiSkzJMk;
        }
    }

    if (jYqptiE <= -1772626328) {
        for (int CAoEbKSwBU = 1388072602; CAoEbKSwBU > 0; CAoEbKSwBU--) {
            VkXkID = sHvNzL;
        }
    }

    return string("XdRyzVUnvexPhcUlFdoAxpaeigJWqvHAmkySwhjeKNQiRkGRtKmbcBQeUeEvIfEjgMNYLfuKzazuXMXvTTCzRWFsUDaCGXBKvAarZtleeGrbjwJrIj");
}

int JRoSgBiRcJdCf::RoaUBbgpNE(double rEiICqNaqgDrveS, int foBrRHlADsOmoniw, string XnTBS, double akIeUHWIi, double qInPCheioEIaHG)
{
    double MEGJAPniGJZMLhyR = 247581.87042666934;

    if (qInPCheioEIaHG < -36200.932900798245) {
        for (int wpXqr = 978740782; wpXqr > 0; wpXqr--) {
            XnTBS += XnTBS;
            MEGJAPniGJZMLhyR /= qInPCheioEIaHG;
            rEiICqNaqgDrveS *= rEiICqNaqgDrveS;
            akIeUHWIi -= akIeUHWIi;
            rEiICqNaqgDrveS = MEGJAPniGJZMLhyR;
            akIeUHWIi += MEGJAPniGJZMLhyR;
            XnTBS = XnTBS;
            akIeUHWIi += rEiICqNaqgDrveS;
        }
    }

    return foBrRHlADsOmoniw;
}

string JRoSgBiRcJdCf::jucCaWowTgnuhZ(string zvOfEmL, double JODzFqstVKnSiZY, int vVFxTGqaWGriqNsa)
{
    int yFcmUlXJTPDAjA = -62039507;
    int mCyzGJoDHzgE = 1329712797;
    double xPCUfFKdvZV = 710120.8333375601;
    double lFYDtfWImYzxZFHv = 338549.9030846754;
    string AqDkGKDOGuXC = string("gsNQSPoJYgdQbrwYzHzeNfQOyIQKLcrilzCv");
    bool SOjqKH = false;
    bool fkvvZsmzZy = true;
    string YCDsdXpF = string("cCEpFtkbBjZLlQEdjCMchivXqJRKxWQPivIESzRONdqKpHNlhuFengbYYMGRqUbpJxkdyCOGDTrmloaixXsciCrzpTjJwSrtlqebXsibrmNjSsaSXQpUVcBHwrewqUfyOOiOHLkQWgZOqilJEaTfdTJBqkzMFsqxFAPJHEPzUHGgYJuQieRTBExaHpIBcMsMYWpGwIDirLU");
    int nQhUwK = 1969800700;

    for (int nxDKGlPLRH = 875327921; nxDKGlPLRH > 0; nxDKGlPLRH--) {
        nQhUwK = yFcmUlXJTPDAjA;
        yFcmUlXJTPDAjA += nQhUwK;
        mCyzGJoDHzgE = mCyzGJoDHzgE;
        zvOfEmL += zvOfEmL;
    }

    for (int QXYWOe = 1158666799; QXYWOe > 0; QXYWOe--) {
        continue;
    }

    for (int AubZoAFfPHUJrBKv = 487912481; AubZoAFfPHUJrBKv > 0; AubZoAFfPHUJrBKv--) {
        mCyzGJoDHzgE = yFcmUlXJTPDAjA;
        nQhUwK *= nQhUwK;
    }

    return YCDsdXpF;
}

double JRoSgBiRcJdCf::gGbdpLEWlItR(string aAADOIIMjOTh, string kraijUHNOsktE, bool JyTfqW)
{
    double KPUxLBs = 704747.6322298317;
    int dqmtGZvelgCme = 702161612;
    double yNNGhqB = 844462.2523457245;
    string oeBbrKDqs = string("IipADXFH");
    double UUkeF = -314.7077186196165;
    double nAiTwLVJZRz = -879073.9787634793;
    string uVYlp = string("yJhrwMjsIGxETkTZzoPkuGaYBZWEhPgRUpKAeXNtisbSZfpaCL");

    for (int leeUlDW = 1094896844; leeUlDW > 0; leeUlDW--) {
        nAiTwLVJZRz = KPUxLBs;
    }

    if (UUkeF <= 704747.6322298317) {
        for (int ulXgHjXJpPsT = 175691402; ulXgHjXJpPsT > 0; ulXgHjXJpPsT--) {
            kraijUHNOsktE = kraijUHNOsktE;
        }
    }

    for (int XiSMrEYXh = 1043036325; XiSMrEYXh > 0; XiSMrEYXh--) {
        aAADOIIMjOTh += uVYlp;
    }

    if (uVYlp < string("yJhrwMjsIGxETkTZzoPkuGaYBZWEhPgRUpKAeXNtisbSZfpaCL")) {
        for (int KVvAJemSlteIE = 1200709309; KVvAJemSlteIE > 0; KVvAJemSlteIE--) {
            aAADOIIMjOTh += kraijUHNOsktE;
            kraijUHNOsktE += kraijUHNOsktE;
        }
    }

    return nAiTwLVJZRz;
}

bool JRoSgBiRcJdCf::EBEvlI(double iceNAJDtV, double bUCPb)
{
    double FuhWkp = -588454.1479243236;

    if (FuhWkp == -588454.1479243236) {
        for (int hnKTzhjASHUgntBw = 570415686; hnKTzhjASHUgntBw > 0; hnKTzhjASHUgntBw--) {
            bUCPb /= FuhWkp;
            FuhWkp *= bUCPb;
            FuhWkp = iceNAJDtV;
            bUCPb -= bUCPb;
            bUCPb /= iceNAJDtV;
            FuhWkp *= bUCPb;
            iceNAJDtV = iceNAJDtV;
            bUCPb *= FuhWkp;
            iceNAJDtV = FuhWkp;
        }
    }

    return true;
}

int JRoSgBiRcJdCf::IOzkhh(string wHpScqkrAo)
{
    int sSkNosfEU = 2129286060;
    int XkxJZA = -1034616174;
    double dhAgUtKyBnjyPnF = 437183.84982973046;
    int oCYrRTazQGJZQp = -993557705;
    double VOwXF = -414285.28362892556;
    bool QIlAXiYrgGsBjXh = true;

    for (int yUWbbQF = 278302541; yUWbbQF > 0; yUWbbQF--) {
        continue;
    }

    return oCYrRTazQGJZQp;
}

int JRoSgBiRcJdCf::jfzdJIPsyRiNFrKW()
{
    bool KBXBTDbo = false;
    bool bVFko = true;
    int cGbczgD = -1228929005;
    int tFmFZOnqQoNuqyFR = -1651972107;
    string uzCcaBGHmexLf = string("xSDFyyruUwsvpryCRBsUGfEKDbYURiwzGuPuLUWrdaSrqKcFsxacfJwhdwmOz");

    if (KBXBTDbo == false) {
        for (int bOcTXrioD = 1386074474; bOcTXrioD > 0; bOcTXrioD--) {
            continue;
        }
    }

    return tFmFZOnqQoNuqyFR;
}

int JRoSgBiRcJdCf::lrGzW(int mweDARcWwvU, string ZavLUqfwdRx)
{
    int TYyokLTegPoA = 326583025;

    for (int YEJmKzoNmuiUAFsU = 152025056; YEJmKzoNmuiUAFsU > 0; YEJmKzoNmuiUAFsU--) {
        TYyokLTegPoA *= mweDARcWwvU;
        TYyokLTegPoA *= mweDARcWwvU;
    }

    for (int sRXDhr = 155367347; sRXDhr > 0; sRXDhr--) {
        ZavLUqfwdRx = ZavLUqfwdRx;
    }

    if (mweDARcWwvU >= -10108113) {
        for (int IQgMH = 340805534; IQgMH > 0; IQgMH--) {
            mweDARcWwvU /= mweDARcWwvU;
            mweDARcWwvU += TYyokLTegPoA;
            TYyokLTegPoA -= mweDARcWwvU;
            ZavLUqfwdRx += ZavLUqfwdRx;
        }
    }

    return TYyokLTegPoA;
}

string JRoSgBiRcJdCf::VUavixN()
{
    double LWcpLUViiTZfByV = 398310.4760548948;
    string NzPNafFrXOA = string("pwWsbFROXqSQSqcZSKHIjkkLQNUDkzCpZAYffTWJUJMvKXhKlxogUuMGZWaNRyfOahVLbEpbvpzHKDAiaQokQUaelpYnPZRgtIGTFKDGqLkawcmWOLwduRgjeMrgQdnTWEtmJYzLBDOxRDQjpKKGlHQEVusxfqFuyowNeTwTsGvUYzArOXcBxwuWwJqeRVQiYmXeOWoowoAKndKOXeZNaiQUIAKDYEFjEimaUNZnLUMu");
    int TuFRHVwbq = 646943748;
    double BWwMltAZV = -326076.65183846105;
    string QltuY = string("SPHwAAYIdHexqIaTiEsSBaWOhsiWonZmotwXJkLUXjXWmqHqbKrTdFVsAibjUDhhFEGexYWjxqGhiJztaXgpSTPWeTcMXEtkSHetqbJOkcdsMejrhGuOZwbwPseZmNQcImcnxPcqcONYwjLziJC");
    double fnSdtxipEE = -836855.7790502417;
    string SdqgHb = string("lflwJMNRqHfISwetHSEWErcBPqrOfxPkwkjtOGkKbxYjFALREGnfloxxhEjZYrXQwDEPxQIXyIIkyuicBdcmzeiovmQrNMRpgsRSHUCUjUtqrgZeiBPIRWcJsNuXYsWedgpGRkgTd");

    if (BWwMltAZV < -326076.65183846105) {
        for (int hqTIulmaaQrJkp = 2039326315; hqTIulmaaQrJkp > 0; hqTIulmaaQrJkp--) {
            SdqgHb += QltuY;
            fnSdtxipEE /= BWwMltAZV;
            QltuY += NzPNafFrXOA;
        }
    }

    for (int fVuUstZIQU = 62585836; fVuUstZIQU > 0; fVuUstZIQU--) {
        SdqgHb = NzPNafFrXOA;
        BWwMltAZV /= BWwMltAZV;
        QltuY = NzPNafFrXOA;
    }

    if (SdqgHb > string("pwWsbFROXqSQSqcZSKHIjkkLQNUDkzCpZAYffTWJUJMvKXhKlxogUuMGZWaNRyfOahVLbEpbvpzHKDAiaQokQUaelpYnPZRgtIGTFKDGqLkawcmWOLwduRgjeMrgQdnTWEtmJYzLBDOxRDQjpKKGlHQEVusxfqFuyowNeTwTsGvUYzArOXcBxwuWwJqeRVQiYmXeOWoowoAKndKOXeZNaiQUIAKDYEFjEimaUNZnLUMu")) {
        for (int LRRQvRQk = 399897527; LRRQvRQk > 0; LRRQvRQk--) {
            NzPNafFrXOA = SdqgHb;
        }
    }

    return SdqgHb;
}

void JRoSgBiRcJdCf::KksypWePPzpHQ(bool jGpzcQeFXcimTqH, int gkNdtM, bool OcFuqo, double dLMmuVR)
{
    bool yZazh = false;
    int uxrxQhCknak = -481518864;
    string DCMbQBSG = string("pHuTGcaMAMbEhfqMnLDgPFDDoQaisRuMkcTYjShiGKtnmDNUanLOPoYOfBNurUIcBabnQHyTjFMwmurHYZrnpldkPqQKxXqsuIGJxgJLrhyHnCglMrrBiMlFVuTaQwxuLsvtlbGOQxecuhbHIu");
    int fzMEJe = 1570809593;
    double dkhCniJwzxt = 931784.1022587636;
    int NZjYsCDgqswxHoJ = 20889426;
    string hrYObFzQIelV = string("bpTLNQlxocemMujpaOfZYQkvMqqpiMrkEVOcqUqUdQDjcAk");
    double dnlNRHvroC = 627961.0904940264;

    for (int mDWpQnHwC = 518393816; mDWpQnHwC > 0; mDWpQnHwC--) {
        continue;
    }

    for (int YPFwjTO = 364253009; YPFwjTO > 0; YPFwjTO--) {
        continue;
    }

    for (int hYoGEFnsendjU = 1630836381; hYoGEFnsendjU > 0; hYoGEFnsendjU--) {
        DCMbQBSG = DCMbQBSG;
    }

    for (int PtxxRBjc = 49742994; PtxxRBjc > 0; PtxxRBjc--) {
        gkNdtM *= gkNdtM;
        jGpzcQeFXcimTqH = ! yZazh;
        dLMmuVR -= dnlNRHvroC;
        jGpzcQeFXcimTqH = ! jGpzcQeFXcimTqH;
        gkNdtM /= fzMEJe;
        hrYObFzQIelV = DCMbQBSG;
        yZazh = OcFuqo;
    }

    if (NZjYsCDgqswxHoJ != 20889426) {
        for (int xIVrPIzC = 1942253223; xIVrPIzC > 0; xIVrPIzC--) {
            NZjYsCDgqswxHoJ *= NZjYsCDgqswxHoJ;
            NZjYsCDgqswxHoJ /= NZjYsCDgqswxHoJ;
            NZjYsCDgqswxHoJ -= uxrxQhCknak;
            uxrxQhCknak *= fzMEJe;
        }
    }

    if (NZjYsCDgqswxHoJ > 20889426) {
        for (int gsNskXgPvJYHrtwU = 1979440697; gsNskXgPvJYHrtwU > 0; gsNskXgPvJYHrtwU--) {
            NZjYsCDgqswxHoJ -= fzMEJe;
            DCMbQBSG += DCMbQBSG;
        }
    }
}

bool JRoSgBiRcJdCf::AhwgSoWKW(int rzZXFbMKsVgNa, bool rOVKhuFNFlxw)
{
    double vXtfpfF = 658942.9577361008;

    for (int hcSlnO = 149687643; hcSlnO > 0; hcSlnO--) {
        rzZXFbMKsVgNa = rzZXFbMKsVgNa;
        rOVKhuFNFlxw = ! rOVKhuFNFlxw;
        rzZXFbMKsVgNa += rzZXFbMKsVgNa;
        rOVKhuFNFlxw = rOVKhuFNFlxw;
        rzZXFbMKsVgNa /= rzZXFbMKsVgNa;
        rzZXFbMKsVgNa -= rzZXFbMKsVgNa;
        rzZXFbMKsVgNa *= rzZXFbMKsVgNa;
    }

    for (int oOOScbK = 1502135645; oOOScbK > 0; oOOScbK--) {
        continue;
    }

    return rOVKhuFNFlxw;
}

void JRoSgBiRcJdCf::jbHPNttjovSIRa()
{
    double LIElIulvHc = -122953.19983058606;
    double qDbyRrzNPh = -634468.4474243528;
    double kpvnvjnPWjxARn = 921853.0207101479;
    double kgUwWAS = 894895.4420110583;
    int YsMBvOnIxY = 1185343207;
    int yPOZovBUS = 484038720;
    double Exolpsc = -49138.96395026162;
    string auHGYRc = string("XrZRknlePIwYfagTuXdmQZnpLUqMtVWrWYCztNGJDmkjtFpLizjnsAPDnxUVXaZrBFyerakVcuDhGFKzMJyRkcHmKzRTclHgefubUVBgwzuHZcfQdnEszXvohGyTFzDJDWZrx");
    double fQeBehCq = 294316.1038636869;
    string xnEOHRcT = string("NsgoiOUxEIZXeHsTkQHavofHRvxciVCJIyJccWOgNlrqWWnycsfyrCbfDzFLCLkpLhvHdbAefGvXHUJqsMpaRqimmcczZJYiiRuzBXSpOpu");

    for (int BfzpswLZWCGciW = 610790671; BfzpswLZWCGciW > 0; BfzpswLZWCGciW--) {
        continue;
    }

    if (kgUwWAS >= 921853.0207101479) {
        for (int xLLAItbcTOESGZTE = 592506444; xLLAItbcTOESGZTE > 0; xLLAItbcTOESGZTE--) {
            LIElIulvHc -= fQeBehCq;
            LIElIulvHc = fQeBehCq;
            kgUwWAS = kpvnvjnPWjxARn;
            YsMBvOnIxY = YsMBvOnIxY;
        }
    }

    if (xnEOHRcT != string("XrZRknlePIwYfagTuXdmQZnpLUqMtVWrWYCztNGJDmkjtFpLizjnsAPDnxUVXaZrBFyerakVcuDhGFKzMJyRkcHmKzRTclHgefubUVBgwzuHZcfQdnEszXvohGyTFzDJDWZrx")) {
        for (int LVwHBLxX = 1860674955; LVwHBLxX > 0; LVwHBLxX--) {
            kgUwWAS -= kpvnvjnPWjxARn;
            yPOZovBUS -= YsMBvOnIxY;
            LIElIulvHc = kpvnvjnPWjxARn;
        }
    }
}

void JRoSgBiRcJdCf::BxiVv(double qpKXnhJWSmqVhow, bool uSPfahScQqj, double UHSZNrBxULe, double FhBEQtumdlHq, int XwwOCyNArliGWp)
{
    int gzpqw = -486763896;

    for (int eKTPTKbQbJzKicJH = 465800073; eKTPTKbQbJzKicJH > 0; eKTPTKbQbJzKicJH--) {
        qpKXnhJWSmqVhow *= FhBEQtumdlHq;
        gzpqw += gzpqw;
        UHSZNrBxULe = qpKXnhJWSmqVhow;
    }

    for (int YOhahzVIvtNST = 1368612446; YOhahzVIvtNST > 0; YOhahzVIvtNST--) {
        qpKXnhJWSmqVhow += qpKXnhJWSmqVhow;
        qpKXnhJWSmqVhow = UHSZNrBxULe;
    }

    if (FhBEQtumdlHq >= 943982.396490261) {
        for (int rpLdWwcIOfeCTVEk = 281563983; rpLdWwcIOfeCTVEk > 0; rpLdWwcIOfeCTVEk--) {
            qpKXnhJWSmqVhow /= qpKXnhJWSmqVhow;
        }
    }
}

void JRoSgBiRcJdCf::AjejuinRpH(double YExEHfMlubANje, bool jMqVm, double TNQnsI, string jffavA)
{
    string TPbOGbCtltUmx = string("oyQjYfuHlKOuoqWbifKzrOVbRtjafLfoBWzPMiSmmfHTujnKHAsxQNdgBmgHkeQhuKjeaOrjoBmrLyZGRlUcoMUFYpyWg");
    double RcXqdIQRkDtHXk = 126006.53162281468;
    bool aPEYXW = true;
    string oORRhNNbdM = string("NRvYhTURdRVMhnnwwzNhKOEgfJkQrvWACQHZzHjQgEGzEraIqyCjfACKbjoMPNxdlXmBOJSVOphdrCSVOSBrcALcrSORYtkOVlKWJrrUvVglBdgPoTJPEY");
    int TMsxIuBs = 464441;
    string YXtJb = string("Wfa");
    double oznCJHDYCtL = -761250.2630376944;
    string YzkLztWWr = string("MuLMlEryEFdadWEsoEChLzkkCoqodlYgmbgXzxGXxwDSckuFHrLQNfiJQvFMurDl");
    int iBBZa = 901830202;
    string ouDGsJgO = string("CPHAROEWjRKBhpniVhktaxsSNiPFQrEoTqvKcCEMGcvnvatXXORtjmHRqUBdtqAryFEpwtYAoEroYYosXnZIEClxChBTSjvXYhHmJVQTYqKsp");

    for (int rHrkgLf = 2095816221; rHrkgLf > 0; rHrkgLf--) {
        continue;
    }
}

JRoSgBiRcJdCf::JRoSgBiRcJdCf()
{
    this->gztdCVXuZ(1639872080);
    this->wGOCKdqyroC(-939987.9180606903, string("oVkSEnbNNQSvirxmvVEYWyCVQFBVklBPpYkVDaToNxZMdRviuNoJyFJlnYiBOPwUXbvgXIZqfLkHKDZbgvYfAPBOdHqmuCbpAHPWPOzxFEvxqdCOfdBxzQXYxIxgLRIPuIqwjHNYldfvVPxmNtveCNWyeOAvdPDlJiEnKMQeMIdAFGJGDeSxAKEdYRLIWAPDAkpKrxjXjwnBekZRcrWLRumISJMzRzwicrOnsdxHTjeJ"), 793833047);
    this->qKWTvhpXxQYuP(-675636.2088997543, -690848.4800538934, 346590.18720708165);
    this->fcUpBUwrtl(false);
    this->bWVBhmAPFCBSA(138604903, 235804.6540307901, -1772626328, 476133.61995024956, 410863701);
    this->RoaUBbgpNE(789055.3226604045, 1101617578, string("iazqHjbusGJumNYNtrMaCeqJodxqrKExZAkDjVMKJLMHRtrIKAcHJYNCxwSTFMfijGXiGCLEPdaTrYJRVBzWmBOoDpfhbFUuItDVNmPoSLOfYrAbMtosld"), -563320.3712997682, -36200.932900798245);
    this->jucCaWowTgnuhZ(string("fbvemNmXARkmrfbkJdlEBOpQXccF"), 219432.90561089362, 102490222);
    this->gGbdpLEWlItR(string("hsiLMAvsxHDvpnpNqVbzyqOuJruCzlbWpgFufBRizURReoWwkpJMdHXukNJRzHngQwNdMEecUOMbdvfpvmuIwJieQnbDqjV"), string("hEWipokbuxkmexcOoomWhiuppJjHloVJxNbwwFVhWdCOxmnZomvEZphnCkjhXgusqaYKFEZznWXxqNTCldfInQIeFYQLVSSDlhTxtCvnsIepoh"), false);
    this->EBEvlI(830306.6763163317, 548171.2497603657);
    this->IOzkhh(string("WeVPhDtzyIDGpbUOXcjwAFXdAfelgjHWSyrjxBVwmpPLRWWLSvwqOeNqFwBVIMVEVsMUeSlQACImKfbBPSaphTaHVtAEGjRZrEndRxkCxELuWbgWMZqKHjidDCYSYJIQvXRCxKKFyCVkmJOA"));
    this->jfzdJIPsyRiNFrKW();
    this->lrGzW(-10108113, string("PNzznkjkmbIDTBFzEJPnTmvArdHWxLbeXcWKzAgOsROehlcTAvItjriVExwPrqtVRXddkBwNyZUQafctLJCvTPDdehCVVWOCwuMCbZAKacbEidNbRXeVTkRnBzyadnDNfUmcntIpByVhitHaYqvAreu"));
    this->VUavixN();
    this->KksypWePPzpHQ(false, -1294167242, true, -762440.2845104352);
    this->AhwgSoWKW(771040250, false);
    this->jbHPNttjovSIRa();
    this->BxiVv(943982.396490261, false, -304711.20587058744, 316331.1382025216, -255778301);
    this->AjejuinRpH(-702088.2309071094, true, -161945.61351441345, string("YaWBLFzwXhGjGVLPiSuVIScuykGXKxUTakLAYtSVhxwWeeQjDOdahGTkEDQryLeAKlzpXEoEBecUOjtsXJxReQAnGXqEydRhlmbkTfvNqNvnmdkBLcuapoWNSHEXscFiMHLsBrlUtnNHXtHnDeegeNldLrYktpjmGXsDpCDIvbCwJhBVcmX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oMvqglhKoa
{
public:
    bool cRAzx;
    double NfIZMViPkXdFOVLx;

    oMvqglhKoa();
    double cnhxMWFlVWcFP(bool eknqIsY, string QgAwGs);
    string FQovCqmHhiDL(string GxxdaUbVqWORTpS, int YyTQERkv, int ZYbUizCYkgHz);
    int mtCvxpeTwF(int xaPrVCe, string VsqxmgRTnG, int yTAUxKGlYhbU, string QAXvhesitUsPF);
    void RlCwbRTDfYlEjWrU(bool qDqBjYuC, int AXXlsg, double gLTIEZVLg, string tSeIHuPIYtcnW, double VupsuJKXxYNz);
    bool sbhigxeiQ(bool nifWPQREcKAWQO, int ibBQsNAGWq, string KFlOWkWuVn);
    string AUktvlDs(int cQDkDdQi, int bmvDEnBRvdfD);
protected:
    int mQEoYIpmDnqEh;
    double NwKHQdAswzZJ;

    int IxnnwMlA(string PaaQYzA);
    double fDQyAkiEYMEBHueG(double ZgGuPoUTMVKHr, string hBTrlF, double vfRpNXZsDboYI);
    int PHwbaAHtYxyaLHxd(int joDunprO, double DVhVTDYnHhWIf, double qTGyHwKHyxO, double ksXdNRUJkNdW);
    double PZWYPCRgoKWkmQH(string MtFNxp, int sipwwZaM, double vVntbRNSZYSjTi, double WhKMOGHwDvYBZl, int vcAqlpoROXhYvGl);
    double OJLTvLAZtZY(bool jdVQwceAoVhktouc, double WXlyQCu);
    double wztudUBNrdY();
private:
    double YySPzKOoUI;
    bool zXxWlLerpBuLih;
    int ryZjbjM;
    bool poDoOKSObZJHKVGs;
    int AMqhB;

    bool QHIXsSfsHGLiFF(bool mxYcvLJ, string CdDDuuYkJZmFlg);
};

double oMvqglhKoa::cnhxMWFlVWcFP(bool eknqIsY, string QgAwGs)
{
    double BhUyRS = -225576.79542819873;
    double hDIMmlJf = 421958.9833398332;
    double IbwizMjMIo = 441049.5543266321;
    int TKGEhc = 1640410520;

    for (int pPNsnbDOXfD = 646949516; pPNsnbDOXfD > 0; pPNsnbDOXfD--) {
        hDIMmlJf *= IbwizMjMIo;
        hDIMmlJf = IbwizMjMIo;
        hDIMmlJf = IbwizMjMIo;
    }

    return IbwizMjMIo;
}

string oMvqglhKoa::FQovCqmHhiDL(string GxxdaUbVqWORTpS, int YyTQERkv, int ZYbUizCYkgHz)
{
    bool DqlsKNpmDqgFpa = false;
    string AbkWQ = string("YQmBQdoiMVUpfOxOtCHflqUobKzrUKZqPfwrgEWhfgunTQbqZCcUYHkzXtwthwRAxbsFHBDpwjfRWBwoXXBBDZjjYBqlRZFsWmHczsPmyUnmcGcOGiJUAlhLyfDOEfDzgwolOrAykvHSfOYMSMpMnNCXFpNiaZPIhLDViWycLNhYmEWgVngCfvELGAxEaaOgpYkf");
    bool yTQbC = false;

    if (YyTQERkv == -770151365) {
        for (int bEVqCUJzxYhHEVx = 1302082408; bEVqCUJzxYhHEVx > 0; bEVqCUJzxYhHEVx--) {
            continue;
        }
    }

    if (YyTQERkv != 634314751) {
        for (int IeNLNtySEx = 1809907700; IeNLNtySEx > 0; IeNLNtySEx--) {
            yTQbC = ! yTQbC;
            ZYbUizCYkgHz *= YyTQERkv;
            AbkWQ = GxxdaUbVqWORTpS;
        }
    }

    for (int TAWbYf = 889590695; TAWbYf > 0; TAWbYf--) {
        YyTQERkv -= YyTQERkv;
        YyTQERkv /= YyTQERkv;
        AbkWQ += AbkWQ;
        GxxdaUbVqWORTpS += GxxdaUbVqWORTpS;
    }

    for (int TGkAenG = 855833352; TGkAenG > 0; TGkAenG--) {
        yTQbC = ! yTQbC;
        YyTQERkv -= YyTQERkv;
        DqlsKNpmDqgFpa = yTQbC;
        ZYbUizCYkgHz /= YyTQERkv;
        GxxdaUbVqWORTpS += GxxdaUbVqWORTpS;
    }

    for (int ywpWQmXup = 301053730; ywpWQmXup > 0; ywpWQmXup--) {
        GxxdaUbVqWORTpS += AbkWQ;
    }

    for (int OFkdGFkQST = 17800014; OFkdGFkQST > 0; OFkdGFkQST--) {
        DqlsKNpmDqgFpa = DqlsKNpmDqgFpa;
        DqlsKNpmDqgFpa = DqlsKNpmDqgFpa;
        DqlsKNpmDqgFpa = ! DqlsKNpmDqgFpa;
        YyTQERkv += ZYbUizCYkgHz;
        GxxdaUbVqWORTpS += AbkWQ;
        YyTQERkv = YyTQERkv;
    }

    return AbkWQ;
}

int oMvqglhKoa::mtCvxpeTwF(int xaPrVCe, string VsqxmgRTnG, int yTAUxKGlYhbU, string QAXvhesitUsPF)
{
    string zBvcK = string("CbQGfZgPxcHvjUhdYXuEesvkRLLAQBetFNrTPuarehaQtMsefNWgzvAkNrCUuUAHlRdknOdYUIfaYAqAEwuUZHqRovcpdXbGJwsJbzvtvyNOJEKiitICFPrkQyPsLKOAmqUqAzFucSqXWpKeYaSRijssFXoPRcGBasaWFksxjBKuxTjBwOOkVuEAoBeGNvXVQVsvlwdZgVlVBiu");
    bool PRrBXqExEFLWrb = true;
    string ksYnvfrYx = string("glfFtekILZIyJPGZIPYCIetSEWkqWRlVoeHbjEzwENQIakcTJvllCcQRVHvrutNuAoXMaChlLADjgLvEwCkMzKtIAnRCeSQnHKhkGfsugRUlhsqGGSaVbsLouSYbWGRkkvmoRrQCqgwHp");
    double PPNdttog = 45522.368508483945;

    for (int JsviC = 1881722927; JsviC > 0; JsviC--) {
        continue;
    }

    if (VsqxmgRTnG != string("kkdafTnGKucTAYyhHytlDzzJtUowRcxLO")) {
        for (int DvpbjaJZPTnvMUV = 856117131; DvpbjaJZPTnvMUV > 0; DvpbjaJZPTnvMUV--) {
            ksYnvfrYx = ksYnvfrYx;
        }
    }

    return yTAUxKGlYhbU;
}

void oMvqglhKoa::RlCwbRTDfYlEjWrU(bool qDqBjYuC, int AXXlsg, double gLTIEZVLg, string tSeIHuPIYtcnW, double VupsuJKXxYNz)
{
    double NVJehsolQaxZ = -382239.96915242804;
    double xfBqh = -259229.6557023523;
    int zGpIfh = 2128445368;
    bool UxuhCNmhv = true;
    bool qEycoBzrxxGTepNQ = true;

    for (int VLOESCNDapzCKUua = 1197702572; VLOESCNDapzCKUua > 0; VLOESCNDapzCKUua--) {
        VupsuJKXxYNz *= NVJehsolQaxZ;
    }

    for (int oTMzFPXeFz = 1114738010; oTMzFPXeFz > 0; oTMzFPXeFz--) {
        xfBqh /= xfBqh;
        qDqBjYuC = ! UxuhCNmhv;
    }

    for (int shoFqRUrum = 452017098; shoFqRUrum > 0; shoFqRUrum--) {
        NVJehsolQaxZ = NVJehsolQaxZ;
        qEycoBzrxxGTepNQ = UxuhCNmhv;
        AXXlsg /= zGpIfh;
        qDqBjYuC = UxuhCNmhv;
    }
}

bool oMvqglhKoa::sbhigxeiQ(bool nifWPQREcKAWQO, int ibBQsNAGWq, string KFlOWkWuVn)
{
    int xCZOndAXwqxfEv = -82983621;
    bool MYRRvnDuT = false;
    bool odcsXVoeMcwtlW = true;
    int jrJsfIk = 1880896299;
    double sklfTAsZMipYvzV = 651114.3215195511;
    int LygYFJAsCZtF = 1829703256;

    for (int oWPXXIaugwYiFUBi = 683958559; oWPXXIaugwYiFUBi > 0; oWPXXIaugwYiFUBi--) {
        LygYFJAsCZtF -= ibBQsNAGWq;
        sklfTAsZMipYvzV = sklfTAsZMipYvzV;
    }

    for (int ShyzlNmgNlAb = 609694097; ShyzlNmgNlAb > 0; ShyzlNmgNlAb--) {
        xCZOndAXwqxfEv *= LygYFJAsCZtF;
        odcsXVoeMcwtlW = ! MYRRvnDuT;
    }

    for (int aoEgs = 90176664; aoEgs > 0; aoEgs--) {
        nifWPQREcKAWQO = ! nifWPQREcKAWQO;
        xCZOndAXwqxfEv -= jrJsfIk;
    }

    for (int JPlOfXDgHXm = 1806544996; JPlOfXDgHXm > 0; JPlOfXDgHXm--) {
        xCZOndAXwqxfEv *= jrJsfIk;
        ibBQsNAGWq *= LygYFJAsCZtF;
        MYRRvnDuT = ! nifWPQREcKAWQO;
    }

    return odcsXVoeMcwtlW;
}

string oMvqglhKoa::AUktvlDs(int cQDkDdQi, int bmvDEnBRvdfD)
{
    int pDJqemI = 12978581;
    string BPWmEYRzcF = string("jiqxsNJrJjCoFdtwnEQVDQSDmwiDomrFYFVEpnZhjmggyLYHtaLwiJyzpyFTsUctkxpfPojZVl");
    string TEmDDHjaDrD = string("CaGcVnFWECfEesMBXLiFrGLsGCfaMuMWbWvp");

    return TEmDDHjaDrD;
}

int oMvqglhKoa::IxnnwMlA(string PaaQYzA)
{
    string XCVcYeHlKZbNjw = string("caPOIPqGlmFfoRjzBhTXNo");
    int zgBFWzseknTE = -1151042344;
    double ekcWmbO = -201885.08924461075;
    bool tSQTrQO = false;
    double ujvVbIjvsgb = 301445.06451230537;
    double ojKpVOiPXv = -950918.5254079221;
    string nJOblKTgW = string("FiGazmYrZVNbsVgZQhWEutpZKOuiuABfUcxjakMCedoaJvrukQLMzpILJneThyvnEhCRtedGZGNvFjOCheYqfBEcymSndDxGdQSwHPEmqtEcHjLdQBcUopFqi");
    double dwiUejFRoHfuSj = 126812.28724927921;

    for (int ByrDcGBYdGy = 1074600408; ByrDcGBYdGy > 0; ByrDcGBYdGy--) {
        nJOblKTgW += nJOblKTgW;
    }

    if (dwiUejFRoHfuSj < -950918.5254079221) {
        for (int cgJraBgCXWYM = 134721607; cgJraBgCXWYM > 0; cgJraBgCXWYM--) {
            ekcWmbO -= ojKpVOiPXv;
        }
    }

    for (int qEsqpjb = 1842513760; qEsqpjb > 0; qEsqpjb--) {
        nJOblKTgW = XCVcYeHlKZbNjw;
        PaaQYzA = XCVcYeHlKZbNjw;
        PaaQYzA = XCVcYeHlKZbNjw;
        dwiUejFRoHfuSj += ujvVbIjvsgb;
        XCVcYeHlKZbNjw = XCVcYeHlKZbNjw;
    }

    if (tSQTrQO == false) {
        for (int QZZQKHanU = 1819733043; QZZQKHanU > 0; QZZQKHanU--) {
            tSQTrQO = tSQTrQO;
            ojKpVOiPXv -= ujvVbIjvsgb;
            nJOblKTgW = PaaQYzA;
        }
    }

    if (ojKpVOiPXv > -201885.08924461075) {
        for (int PcTsiSvvzaeEkTk = 439839965; PcTsiSvvzaeEkTk > 0; PcTsiSvvzaeEkTk--) {
            zgBFWzseknTE -= zgBFWzseknTE;
            ujvVbIjvsgb *= dwiUejFRoHfuSj;
            nJOblKTgW += XCVcYeHlKZbNjw;
            zgBFWzseknTE /= zgBFWzseknTE;
        }
    }

    if (ojKpVOiPXv > -950918.5254079221) {
        for (int kUKYBA = 1863683531; kUKYBA > 0; kUKYBA--) {
            ojKpVOiPXv /= ojKpVOiPXv;
        }
    }

    return zgBFWzseknTE;
}

double oMvqglhKoa::fDQyAkiEYMEBHueG(double ZgGuPoUTMVKHr, string hBTrlF, double vfRpNXZsDboYI)
{
    bool MjuTjeMNgZ = true;
    string zjqIdMeMSQt = string("hpXrPJeaorVPtagKeswZOiAlVHswIdNYLKZiBFtIHKPcElAovjxZno");

    if (ZgGuPoUTMVKHr >= -661698.5471282648) {
        for (int UINDY = 762576424; UINDY > 0; UINDY--) {
            zjqIdMeMSQt = hBTrlF;
            ZgGuPoUTMVKHr = ZgGuPoUTMVKHr;
        }
    }

    for (int LuklUjTaQBN = 987023965; LuklUjTaQBN > 0; LuklUjTaQBN--) {
        ZgGuPoUTMVKHr /= ZgGuPoUTMVKHr;
        ZgGuPoUTMVKHr *= ZgGuPoUTMVKHr;
    }

    if (ZgGuPoUTMVKHr < -661698.5471282648) {
        for (int ZweZut = 919676010; ZweZut > 0; ZweZut--) {
            hBTrlF = zjqIdMeMSQt;
            ZgGuPoUTMVKHr += vfRpNXZsDboYI;
        }
    }

    if (hBTrlF < string("hpXrPJeaorVPtagKeswZOiAlVHswIdNYLKZiBFtIHKPcElAovjxZno")) {
        for (int MnthF = 728929873; MnthF > 0; MnthF--) {
            vfRpNXZsDboYI += ZgGuPoUTMVKHr;
            zjqIdMeMSQt += zjqIdMeMSQt;
            ZgGuPoUTMVKHr += ZgGuPoUTMVKHr;
            ZgGuPoUTMVKHr = vfRpNXZsDboYI;
        }
    }

    return vfRpNXZsDboYI;
}

int oMvqglhKoa::PHwbaAHtYxyaLHxd(int joDunprO, double DVhVTDYnHhWIf, double qTGyHwKHyxO, double ksXdNRUJkNdW)
{
    bool qFHqYlwGmGcDr = false;

    for (int AxqynTCYEeosBR = 1350981595; AxqynTCYEeosBR > 0; AxqynTCYEeosBR--) {
        ksXdNRUJkNdW += qTGyHwKHyxO;
        qTGyHwKHyxO *= qTGyHwKHyxO;
        ksXdNRUJkNdW -= qTGyHwKHyxO;
    }

    for (int HnWzOhlAjT = 1051458400; HnWzOhlAjT > 0; HnWzOhlAjT--) {
        joDunprO /= joDunprO;
    }

    for (int rZgYlK = 560873489; rZgYlK > 0; rZgYlK--) {
        DVhVTDYnHhWIf *= ksXdNRUJkNdW;
        qTGyHwKHyxO = qTGyHwKHyxO;
        DVhVTDYnHhWIf /= qTGyHwKHyxO;
        DVhVTDYnHhWIf /= DVhVTDYnHhWIf;
        ksXdNRUJkNdW /= qTGyHwKHyxO;
    }

    return joDunprO;
}

double oMvqglhKoa::PZWYPCRgoKWkmQH(string MtFNxp, int sipwwZaM, double vVntbRNSZYSjTi, double WhKMOGHwDvYBZl, int vcAqlpoROXhYvGl)
{
    bool SWWUXXt = true;
    string FYUlfBUEKzpmyDvt = string("jwMihHBsSSsIEvxzegMWOmhUyxiWfRTOPmnOVswLnBfcoqvrfACBIagpNCSprpjxbtgfBOypuVlNMKFWcaamRBsCXuKchJHhkJlSXQKtTDAAHbRkeqvMKqBuQFpPpcPmPJBGJjEHIdYxXVonvslEzksSmSvzoemJxFeovHzyVbkixwhrTTQwlhwONcnJcNkoemOwoAfjUxZyjyQdDhtGEI");

    for (int eNJrH = 480015230; eNJrH > 0; eNJrH--) {
        vVntbRNSZYSjTi /= vVntbRNSZYSjTi;
        sipwwZaM /= vcAqlpoROXhYvGl;
        WhKMOGHwDvYBZl -= vVntbRNSZYSjTi;
        vVntbRNSZYSjTi = WhKMOGHwDvYBZl;
    }

    return WhKMOGHwDvYBZl;
}

double oMvqglhKoa::OJLTvLAZtZY(bool jdVQwceAoVhktouc, double WXlyQCu)
{
    double SmIXxKPHgl = -544259.6854059049;
    string vynCogNHKGBR = string("tCFeaFNhffDZzAfcngWP");
    double eYRUwdBZSFoAsfx = -695289.78603462;

    return eYRUwdBZSFoAsfx;
}

double oMvqglhKoa::wztudUBNrdY()
{
    bool jjFMCOynXjxDX = true;
    string bzALCTYpODnOh = string("iLNuXKjAjjoeOjbyYtzSkfLZyUOBbInBBfUpKgMzYrMKbZtRUPrGqELdhjLJOsPBpBHUOJVladCiexNaBpNdcOtPKwUcxmIlxeMHtCUozxDrUPfGgXeiSZeqEoGAzosGPfvGnYdugPGCztUoNriwjMJtgVschWqWmhomCvvceiJBElaUmZgpzCAtbthsoFmWFQmcqSHHUCfgKVdiEinAAcnfCxfjiGZILTDuzypbiMSAOpHSFleVsxSq");
    string JKoSogSqwDQKCEio = string("zlkRHJXzWQyOejlWYzcF");
    int RpPprpJka = -336973057;
    bool WizxkZUN = true;
    int ePuOAtlIxxErTNIp = 1605859505;

    return -523984.8932143066;
}

bool oMvqglhKoa::QHIXsSfsHGLiFF(bool mxYcvLJ, string CdDDuuYkJZmFlg)
{
    int QoERfJOnJDnm = 414561477;

    return mxYcvLJ;
}

oMvqglhKoa::oMvqglhKoa()
{
    this->cnhxMWFlVWcFP(true, string("iJTOohBhPxzIWzyTNbqScqXldUmHyydOeQVbVLPozLskynDtebGMKNpDkwZPSPjFJMtPzSAcbKSaZLQTGkdhHxsGfLUlIaqpyVrdCjBDlvWUQJtveVNOoqldMONHdVGdxGSLikfBumy"));
    this->FQovCqmHhiDL(string("iJukfEOplfKGkEbSOZyyavplmywvvgDwgdJGdDabETGvyJYTANWvupdJaTDReCqflGjubJKbzPfmKuZGadxgFx"), 634314751, -770151365);
    this->mtCvxpeTwF(1944730396, string("kkdafTnGKucTAYyhHytlDzzJtUowRcxLO"), 1628091252, string("JSJNXYSyQdQdpEJrKXhTWnMflNTqoyXbBYzvSAAOCPOOOieGZfShrdCLnHWsnGBVLYTKnziFYJNJSytBTwZmiWcTOqUowxhsjEWJXHzKsUnqPvJlzgdZnwbTfSOrIvQreJgpJDCriPSpIjkHQHnWRYOjutRZCYXAugKCZrGUxYQqwZejRGcghfJIHDqfXqYyTJeaEcnmlbeaMxflgzVxzphhfmW"));
    this->RlCwbRTDfYlEjWrU(true, 386075110, 157081.427173938, string("smYlWCxFuvtQurohiGaJgZmkRodCWSdmOmXNXCxFuTCtUWkDFaFnwDezEbPVpJsquCMlzvwDalnJYKMQDBwhpcJIRtqjmFyxrcAgAXtliUrVQfHQsThGewIepKfOrTkYBXiIdzrXgIXFpFqMxenJRJJgmZZCnkRVqOYpgeYx"), -515061.9028424606);
    this->sbhigxeiQ(false, 1962898383, string("zxadAoaEOxOCEtrPwydqeGqUoNYbUhlmgNwesMuVgsrsHBdZDJlmQvzmAQLWuiLLTwPeIyWoBUOXOMNDkEmjeLqrQdzOTQOwGYaEbqSEpmRaFRaWnwioClueWHtXUGyTZvyPcWqFA"));
    this->AUktvlDs(90138742, -795535234);
    this->IxnnwMlA(string("cGmowkmrIzWelUeinPwfuQbbuyjqwTthtiQOmnFwbGGPNigqQiHVusRhcQCIplzuqnLxzpPEgmfFqSTiFppLrvcFtkAkgXayImLVxroKPBKDXinxrjmUMxnkPssQzGQrydvERVVqxVnSXmKDvwgcJTdlcfSviulGOQdTYApNdLFQDGsQfoTkiZZSYSBzdjDmvJbowdVKHibbxWIixagzZOfZuD"));
    this->fDQyAkiEYMEBHueG(184715.80323042956, string("UnRuAhxdZtwjxFvKqirpwCqDfFbWaULNmndlfZLzrpSpXQcDJRlxHJHIEEjGijQgwTpYvytqzewA"), -661698.5471282648);
    this->PHwbaAHtYxyaLHxd(1496039305, 345112.4863293801, 148331.59380102958, -978195.485487142);
    this->PZWYPCRgoKWkmQH(string("TJpRwqvoLU"), -1530528858, 89477.43365049263, -948391.6911928306, -573023180);
    this->OJLTvLAZtZY(true, 614385.1816450821);
    this->wztudUBNrdY();
    this->QHIXsSfsHGLiFF(true, string("WznXKsZMphTElGGnbPfwKmAZDWcqfUBTPaFSUhkrshHvRJXEleImrvbzbwDdlMLAezyesfdAofpLyVpgroEzIUYhPxstDVmUVrBtLiwNwRIKYPlFJHBgklwwyMQlvmIwErRuUJRHAHjedOpcvPDX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sRJNEvnbBKzXN
{
public:
    int arxmj;

    sRJNEvnbBKzXN();
    double kvUnpoKj(bool bkWSGEctFOfTs, int rrkKX, string ViPqqFuxzbTyW, int pLwIuvC, string leLIkQcqseE);
    void PHrKiigamne(int YjQuRiBV, int MtevzgalHoaBcwN, double uJwRAVViLDqoTPj);
protected:
    double YzZqVIIKCKoho;
    int jLLKw;
    int nnRBwQxWqzwcbHVQ;
    double dypgyPChxa;

    double TexFwoUeqhxg(int jlLhuhmy);
    double hTTKfJQrRRVOMfQ(bool UVqVZ, string uwERNsactcgZN, int MJtSfqdhOoXmAgP);
    double tbwWvXmrsQZKHFnu();
    bool DtCMkDGdBYfb(string zgFxQ, bool tHXHTazCLv);
    string FcKHxYZqJce(bool VtKjoI, int lDEbCzMffK, string yapvkC, int kPFdjGZ);
private:
    string onXuvDKPagVYGsIu;
    string XypDOAzrlvG;
    bool oAsRUOUbwL;
    string joSjqGgRePUzhaE;

    int ZCeEdR(double tBRpIERJwz, int BRvKgHeOgz, int COKFqkejGYuGJaXj, string SEsFQGOWaNzA, double pZruqGRWGIkb);
    void HeoEYG(string uBXcrhtHo);
    double gpZlyBzlcmOY(string atRGWURNk, string MpERenQSDJwbPZ, bool njBJrXPbJGQuH, double mfzImfz, int DHlOpLN);
    double kBEiPtxKvqlvki(double ZSmbRpEjwxEdX);
    void bWHOFWWgQwZrn(bool eSEpC);
    int kCLwuFtmBYng(string hWAHzHXJVWau, int mnsUclBM, int XqmPJdmsDlw);
    string HjiSsEtEMKcW(bool aMqxX, int IRyCEaSnHdrx, int MYSFKfYTSjNzKEk);
};

double sRJNEvnbBKzXN::kvUnpoKj(bool bkWSGEctFOfTs, int rrkKX, string ViPqqFuxzbTyW, int pLwIuvC, string leLIkQcqseE)
{
    double sWYqyayPIT = 639423.9677990448;
    bool hQgBXMoO = true;
    bool kLMhwMbVeFrOBB = false;
    int tEwQvqTwkzCm = -1610243296;
    double hBEsotjK = 435659.19533004885;

    return hBEsotjK;
}

void sRJNEvnbBKzXN::PHrKiigamne(int YjQuRiBV, int MtevzgalHoaBcwN, double uJwRAVViLDqoTPj)
{
    int cSMcscODzjGuyl = -1560390959;
    bool dFfLosgPlPwkifUn = true;
    string BxdChkrWvRBoP = string("GAWWELlWJOSKIRXYtDJrrrjmzkqvLJnUNFuHelBVZZZHnxiBDbVfumZzIqMpmPAJtwnODMzrwhxqbCnTBKRQAsLnhqLNxabDHcEmuRZGShKDlXTzVBxWaSXWGrnDtXZRXagTOstgxLZYcYLnnaOKmIQyNdYmWEqaTuAEFHjmGfyrLMrEEOPyDKGyeURZzUpxBqEMuyVmdeqGXCRIEgGAQXmNsWKhinVnzFKrhjtauNnfgrY");
    double AouCpE = -293954.0884965497;
    bool FdWgBAjRXLo = true;

    if (uJwRAVViLDqoTPj >= -293954.0884965497) {
        for (int ojxZVMmSwBdl = 307445409; ojxZVMmSwBdl > 0; ojxZVMmSwBdl--) {
            BxdChkrWvRBoP = BxdChkrWvRBoP;
            MtevzgalHoaBcwN = MtevzgalHoaBcwN;
            MtevzgalHoaBcwN -= YjQuRiBV;
            FdWgBAjRXLo = ! FdWgBAjRXLo;
        }
    }
}

double sRJNEvnbBKzXN::TexFwoUeqhxg(int jlLhuhmy)
{
    bool ICjqlrlGzY = true;
    int NJiMVKGGgOSuHYu = 1184360446;

    for (int JyoVHClLoHIi = 636368197; JyoVHClLoHIi > 0; JyoVHClLoHIi--) {
        jlLhuhmy += NJiMVKGGgOSuHYu;
        NJiMVKGGgOSuHYu *= jlLhuhmy;
    }

    for (int KtiMFpTknBQP = 289206666; KtiMFpTknBQP > 0; KtiMFpTknBQP--) {
        NJiMVKGGgOSuHYu /= NJiMVKGGgOSuHYu;
    }

    return -989209.3710805842;
}

double sRJNEvnbBKzXN::hTTKfJQrRRVOMfQ(bool UVqVZ, string uwERNsactcgZN, int MJtSfqdhOoXmAgP)
{
    double SmxxSRU = 975327.7338302443;
    double UwOLN = -239333.5245764839;
    string gOqYidoKKHn = string("PmAFJIzPdAAjWgTYFFLbxPiDauoRSDdCbuGXxKuPgCDRRQexqoSdFSslzCXAIpURCjKepjummrWRCnHTpVzwgcKHANQgtjcZCVhTbxsAeOIWsnPusywRSgqViUHmPotfPHg");
    string EEULhuDRnLbe = string("SjQsSyWqvbNdjybrcAKvgytYZfFsBQArxwcoBItxyjnGBaDGyzMqcRQVxCERhNCPczkRSbLJVRxwRDOIbdFGkKNUiaszpGDXinGQgzRJIvcMvFvzdIBwJbbNSGKHjOEWQJEfZZGCtMePrrhuXSNYuaTZMASDdalNmInDkhrhFizpiFNymezUeGQtiQsowaghxGXjmaEmEpmhHtyGioZjpgnfRDOl");
    int FhdiAsqA = -206189288;
    int PjVxZyrdhoEsxeLd = -1880983302;
    string EeIip = string("uujsIQzRrhCSSUljqEAUYvGZNJNpRrevswLqPclOcDOzegyoYPhMBGnREhfeRuhFOcgFgYRusZHVFAWatRzXNZmaGLeHsVDEGnjzekVgaZdDbXjI");
    int JAfYhI = 2020013693;
    string MPjxdRrtLgEmHKfX = string("IUcGJkoqUzKXSkyyMibEddMIMcLmbdDWcgTRFnwfvAvOCvQaadXLJfnySkdiXpVhmUzCpiaURWwTPOfSlEQmPyqSToziOeDhocHqBxXcVrYIEBmlqOYCFluJLeSVWpzYDSMKRgIIOxNBsJXFCovBrcGXUZnRwagpwYdqVrjyTeHOMBenPXkAwQSpgKYlysdHQhon");

    if (gOqYidoKKHn <= string("TjeXHtfOenYjUxdfbIxlzKZjEhGhospMHnQTlVjPRfaolCKWeThzKdkkzDQiERIYEBEIGLCdaClgjsiWolKDSCKnkKtQItdEEJmfpD")) {
        for (int reEoKYfBgrU = 1216853813; reEoKYfBgrU > 0; reEoKYfBgrU--) {
            MPjxdRrtLgEmHKfX = EeIip;
            FhdiAsqA += PjVxZyrdhoEsxeLd;
            uwERNsactcgZN = gOqYidoKKHn;
        }
    }

    return UwOLN;
}

double sRJNEvnbBKzXN::tbwWvXmrsQZKHFnu()
{
    double OleqSWAKtogxvbj = -967206.538761876;
    string yguhQZoSWEpy = string("EmuUyWkmBBvCKyeGlFZMKuPImRDvCFAyurGgotUOkFPACiRlivjfSluLxPjXkzrAxiYjHzdnSyiRKTWYzCzBzqyFHsLApUtzedkQUYdvpvBFTGCXjhHeKrogt");
    bool viqScJrivb = true;
    string IftcNfKrR = string("kEOsgtVrShvqFzIaZaRIfkydGQSaYkYKnREUasqBQSdAtwqvcDfHGppqTYZDQKzooCljnxmPgwbzQmxJFEdwWPimOKNGOzCMslDHKgMkblwyiEPYQHKauSrkQbtMEHNPKPIwXvRYOQhfAIdXtmHtLeWNqubXBvshWHRbjGStKCLOZqNgEXoqKypqdJCkFwVZfZTzFLSQFUCivgixQFOFICvb");
    double jkJNMICgfOyfcY = -110751.22653911213;
    bool vNOvvtkGzLoGMaa = true;
    string oXheSxTcxTmd = string("EBcAdtIBcAjLWczlCENLGdHXdsZjbrRYsgtIWujNxcDvUjwPjxxUTIuonTucaxhrEPnBvdDPEcpPHBTLXctGgbfvZSnmJEouNjsaIrYFSbosNWnuiHpVDcbIgNhQgQdGcmzeOJrNKjrmvMyPChpkgwBaTMLokJQropIOlPlxmoXwzxkYRDcNUuVlDrGFNAqfGKeKAEvRcPvlQbSIrQcsFHWGodSZgpgaxoFEyVTgYIUWTNSerJrXrLnmkHQk");
    double VFbCfqFiduTdBLhC = -739521.5486512731;
    double dPyvmIPOxJYixb = 780892.7517466961;
    bool zHSdSYNubSySdzS = true;

    for (int NRTonV = 1086982851; NRTonV > 0; NRTonV--) {
        zHSdSYNubSySdzS = vNOvvtkGzLoGMaa;
        OleqSWAKtogxvbj -= jkJNMICgfOyfcY;
        dPyvmIPOxJYixb /= OleqSWAKtogxvbj;
    }

    if (viqScJrivb != true) {
        for (int fHVQJiuNNlaOxrq = 1399940876; fHVQJiuNNlaOxrq > 0; fHVQJiuNNlaOxrq--) {
            zHSdSYNubSySdzS = zHSdSYNubSySdzS;
            zHSdSYNubSySdzS = ! viqScJrivb;
            VFbCfqFiduTdBLhC = jkJNMICgfOyfcY;
        }
    }

    if (VFbCfqFiduTdBLhC > -110751.22653911213) {
        for (int ZsiJobJOQKc = 484739845; ZsiJobJOQKc > 0; ZsiJobJOQKc--) {
            dPyvmIPOxJYixb *= VFbCfqFiduTdBLhC;
            zHSdSYNubSySdzS = vNOvvtkGzLoGMaa;
            dPyvmIPOxJYixb /= jkJNMICgfOyfcY;
        }
    }

    for (int wzwzf = 1647861877; wzwzf > 0; wzwzf--) {
        IftcNfKrR = oXheSxTcxTmd;
        dPyvmIPOxJYixb += VFbCfqFiduTdBLhC;
    }

    return dPyvmIPOxJYixb;
}

bool sRJNEvnbBKzXN::DtCMkDGdBYfb(string zgFxQ, bool tHXHTazCLv)
{
    string GcCRZM = string("kYhUMEfmJOcikdusWctorOOQyVpXEOnKnWcggfuWwVRLraLHTazNHxDMVBzmbpGBYACwZtnyKfgWGRXsBtWyHVDaRpcwzcSzyMbkSrgccoUfmDItWNdCfTLRDtQWalGHRcQMolQfZchdWupbSsDjSKOAdVNjgfOHo");
    string OItvdXMUffBNFWy = string("PWVCnHrpUMQqjFbYOFSzbEOrNgjyxqnGKHgvStFhCVKSPQBlUXMxXatmcEYcSukjlIPRcXSdIqCsrKCzbVBMRHTAAslO");
    string rXOaDvYwk = string("RpDodPBeCWOtJoskRWmNVNamFCioBlVqzAmIBQUOrnMrVvSnwgCaYyoYroCrBzkmfxQbLNJVnXQPHtCEhucMtDEvahuxW");
    string CCqiW = string("ajHSfqvMGtqAWMypdKjPssJIaAjWlMCTTucmycFYmWLfCxgXKPTzsLMbLnx");
    double oqxPOaAB = 409221.6125863898;
    string AmCqDeCqYmpDyzv = string("AAzijNdxgYaKwSqkFQEMnLHTBJkHiMyxaZHuPtkYFNCtNlSORpSqiblXMyxoMCQlHTTx");
    bool ykPqikGcSyGivgHF = false;
    bool DqyVUEsSzB = false;
    double BWqZVfTcty = -96439.61246525841;

    for (int eclEvKPk = 554141297; eclEvKPk > 0; eclEvKPk--) {
        rXOaDvYwk = rXOaDvYwk;
        zgFxQ = AmCqDeCqYmpDyzv;
        CCqiW = zgFxQ;
        CCqiW += AmCqDeCqYmpDyzv;
        rXOaDvYwk = OItvdXMUffBNFWy;
    }

    if (DqyVUEsSzB != false) {
        for (int FTVUnSBglTS = 540183839; FTVUnSBglTS > 0; FTVUnSBglTS--) {
            rXOaDvYwk += AmCqDeCqYmpDyzv;
        }
    }

    if (tHXHTazCLv != false) {
        for (int CEtQVpsreOuPSD = 588296917; CEtQVpsreOuPSD > 0; CEtQVpsreOuPSD--) {
            AmCqDeCqYmpDyzv += CCqiW;
            DqyVUEsSzB = tHXHTazCLv;
            tHXHTazCLv = DqyVUEsSzB;
        }
    }

    for (int KdhmQR = 1672783614; KdhmQR > 0; KdhmQR--) {
        zgFxQ = rXOaDvYwk;
    }

    for (int PDyVfwfRNEI = 422903940; PDyVfwfRNEI > 0; PDyVfwfRNEI--) {
        OItvdXMUffBNFWy = zgFxQ;
        OItvdXMUffBNFWy = CCqiW;
        AmCqDeCqYmpDyzv += CCqiW;
    }

    if (OItvdXMUffBNFWy > string("AAzijNdxgYaKwSqkFQEMnLHTBJkHiMyxaZHuPtkYFNCtNlSORpSqiblXMyxoMCQlHTTx")) {
        for (int XbALFWYCsxx = 1979524052; XbALFWYCsxx > 0; XbALFWYCsxx--) {
            DqyVUEsSzB = DqyVUEsSzB;
            zgFxQ = CCqiW;
            ykPqikGcSyGivgHF = ! ykPqikGcSyGivgHF;
            BWqZVfTcty += BWqZVfTcty;
        }
    }

    for (int jtcdVHEcG = 966763474; jtcdVHEcG > 0; jtcdVHEcG--) {
        continue;
    }

    return DqyVUEsSzB;
}

string sRJNEvnbBKzXN::FcKHxYZqJce(bool VtKjoI, int lDEbCzMffK, string yapvkC, int kPFdjGZ)
{
    double WociMkOa = 375013.61753862543;
    int oIRqXCOMLSSHeBrd = 1091182247;
    int sbmPxA = -1796975156;
    double MvQjPdjwZ = 272600.57283479883;
    int GpIJoGtJ = -1894569916;
    int XoacKgFBbjWiu = -1577623462;

    for (int ZFHdpWJsUArH = 689841113; ZFHdpWJsUArH > 0; ZFHdpWJsUArH--) {
        sbmPxA *= XoacKgFBbjWiu;
        oIRqXCOMLSSHeBrd -= sbmPxA;
    }

    if (XoacKgFBbjWiu == -1796975156) {
        for (int WCxutHAyAGLiieL = 443480221; WCxutHAyAGLiieL > 0; WCxutHAyAGLiieL--) {
            continue;
        }
    }

    for (int PWkxMSoUeHYAS = 1395678916; PWkxMSoUeHYAS > 0; PWkxMSoUeHYAS--) {
        XoacKgFBbjWiu += lDEbCzMffK;
        sbmPxA *= sbmPxA;
    }

    return yapvkC;
}

int sRJNEvnbBKzXN::ZCeEdR(double tBRpIERJwz, int BRvKgHeOgz, int COKFqkejGYuGJaXj, string SEsFQGOWaNzA, double pZruqGRWGIkb)
{
    int AnZJUrZgKPKQqTJ = -313126063;
    double VNhlsuZsmfxIxLV = 930133.8639561862;
    double lOHwzhOtapS = 865756.3337232687;

    for (int vxMGoBPcWWcJF = 1910366933; vxMGoBPcWWcJF > 0; vxMGoBPcWWcJF--) {
        lOHwzhOtapS += lOHwzhOtapS;
    }

    for (int jrBTgFVKgmzNCT = 1188483697; jrBTgFVKgmzNCT > 0; jrBTgFVKgmzNCT--) {
        AnZJUrZgKPKQqTJ *= COKFqkejGYuGJaXj;
        tBRpIERJwz -= tBRpIERJwz;
    }

    for (int UlFrRkBkA = 1637171039; UlFrRkBkA > 0; UlFrRkBkA--) {
        continue;
    }

    return AnZJUrZgKPKQqTJ;
}

void sRJNEvnbBKzXN::HeoEYG(string uBXcrhtHo)
{
    string aOxydAmApFNCZn = string("NanYBtWURcdDYuxJrUSqJeVPbuDLJxgboOXYptdcJVWueNsRPUuRfwxIMuBUhbGhtPfWRuxPMUwLnPBLfgesjmikygsxYXmERjPcGrzTgppljEdnfVKulKlSBEuMvciFPxMNsinFhNQiJDDPTHsIUNJTcZxxPSyTpmxQZYIYSVGMmzHMAPObqnNMhQKQnZfMpFEJiYEhNStaxnEzYZZDLXvTwXefQLJJXvEhHSaOjUkFOpDp");
    double NaYgwWVYFpj = -663403.7199241883;
    double UQJIAjs = -915649.4113937665;

    if (uBXcrhtHo < string("FqMajbavdIGyVzeWoJBHdojDTpjkhvuegX")) {
        for (int CAhsNfbDeSUJyW = 1449896592; CAhsNfbDeSUJyW > 0; CAhsNfbDeSUJyW--) {
            continue;
        }
    }

    for (int ZSGbgmcYqlOE = 698998176; ZSGbgmcYqlOE > 0; ZSGbgmcYqlOE--) {
        aOxydAmApFNCZn = aOxydAmApFNCZn;
        UQJIAjs -= NaYgwWVYFpj;
        uBXcrhtHo += uBXcrhtHo;
        uBXcrhtHo = uBXcrhtHo;
    }

    for (int odaxxODqEW = 1087072252; odaxxODqEW > 0; odaxxODqEW--) {
        aOxydAmApFNCZn = aOxydAmApFNCZn;
        aOxydAmApFNCZn += aOxydAmApFNCZn;
        NaYgwWVYFpj += NaYgwWVYFpj;
    }

    for (int vgqMPV = 1533310318; vgqMPV > 0; vgqMPV--) {
        aOxydAmApFNCZn = uBXcrhtHo;
        aOxydAmApFNCZn = aOxydAmApFNCZn;
        uBXcrhtHo += uBXcrhtHo;
    }
}

double sRJNEvnbBKzXN::gpZlyBzlcmOY(string atRGWURNk, string MpERenQSDJwbPZ, bool njBJrXPbJGQuH, double mfzImfz, int DHlOpLN)
{
    int ZlleAOsIO = 1042284897;
    bool QxudbUlIGTJ = false;
    double ULADjTLHVsnh = -643752.7877275308;
    double iNNVdQfcFeKd = 926535.5599734562;
    double enhkyUh = 360688.0228396149;

    for (int WYOxTdwQWeiIsQ = 106538870; WYOxTdwQWeiIsQ > 0; WYOxTdwQWeiIsQ--) {
        QxudbUlIGTJ = ! njBJrXPbJGQuH;
        iNNVdQfcFeKd -= enhkyUh;
        enhkyUh -= enhkyUh;
        iNNVdQfcFeKd = ULADjTLHVsnh;
        njBJrXPbJGQuH = ! njBJrXPbJGQuH;
        iNNVdQfcFeKd = mfzImfz;
    }

    for (int mQsiNTnrPFUxb = 1933137369; mQsiNTnrPFUxb > 0; mQsiNTnrPFUxb--) {
        mfzImfz -= ULADjTLHVsnh;
    }

    return enhkyUh;
}

double sRJNEvnbBKzXN::kBEiPtxKvqlvki(double ZSmbRpEjwxEdX)
{
    string hjvcwBNlSYB = string("lFOVDYyHemoanviExMAvbuoQLvjEnFmDeuaIzueUpWyiJIVUNehzTZMpXbcCwOnIjxmggMePpzUlWImacDWDnVFEtArDWEmCIKFYLHoQxFcsPvtAmGhNIBKolZcLQcdTBFNthAnmgtGDDWdFTlqBYkajfQmBjxvcvnCUalKAZtzrZOwSsYPWwpuFPyUQcbDuuobmTvAymUQHpCA");
    int FwkNthgoXwjAa = 1021908104;
    string EzLUsXSm = string("xCIbrTXZniYrtyZJGRMjYnJJIeYoFXxTBQTmpjBXQUknTedojKOJDPnOoAIGaszMyMUQcSaEvdOfkbXPrMwoAInSJaViDfVgwecphMajNnspvUddYYDMUhVKWDgAWzfvnt");
    double JeTfOFdHjiBsN = -607963.3335823936;
    string PRhqFaKLdYrz = string("ohGiJaMtsQrBsGPTuhuHkoKxJIyGDWkNNQLeivdpcpoAGjIdeuitRWddsmjpEVhldPlvrVVBtgYbagomLftUmUSgjmAvrCzFhCauvtrnaoyzyzppLmFoIfdEcJCZwgZdZPVoIDvLOGPpoSCppRemrGDuVsTAdjojMsOODfmENoMyiUORtvdIQvWmlkOSntprWEcJxzdRnH");
    string SylreXz = string("ItbisusImobMpiCwwbTlIzxDkSB");

    if (PRhqFaKLdYrz == string("xCIbrTXZniYrtyZJGRMjYnJJIeYoFXxTBQTmpjBXQUknTedojKOJDPnOoAIGaszMyMUQcSaEvdOfkbXPrMwoAInSJaViDfVgwecphMajNnspvUddYYDMUhVKWDgAWzfvnt")) {
        for (int XRzIR = 1158793118; XRzIR > 0; XRzIR--) {
            continue;
        }
    }

    if (JeTfOFdHjiBsN == 1023689.8629895276) {
        for (int HBKjUiGzHBnpgqyh = 1465748923; HBKjUiGzHBnpgqyh > 0; HBKjUiGzHBnpgqyh--) {
            EzLUsXSm = SylreXz;
            hjvcwBNlSYB += SylreXz;
        }
    }

    for (int XyrPdFdQhktxq = 1369221831; XyrPdFdQhktxq > 0; XyrPdFdQhktxq--) {
        SylreXz = EzLUsXSm;
    }

    return JeTfOFdHjiBsN;
}

void sRJNEvnbBKzXN::bWHOFWWgQwZrn(bool eSEpC)
{
    double HrprUEMDiM = -191698.0166628449;
    string znJmeWyvKMKPu = string("oXjBKOlisQwfnJhXLjzqAjopIwDTbKPZnpSLorgXBUkQKWUdREmfkUkgwfSN");

    for (int YjexsqWuyk = 1454960606; YjexsqWuyk > 0; YjexsqWuyk--) {
        continue;
    }

    for (int EyrUAflGMgCSb = 1832637644; EyrUAflGMgCSb > 0; EyrUAflGMgCSb--) {
        continue;
    }
}

int sRJNEvnbBKzXN::kCLwuFtmBYng(string hWAHzHXJVWau, int mnsUclBM, int XqmPJdmsDlw)
{
    string bNzPuPSZnRg = string("NToGqCZoPmBhPVOthdvIqDYffnkKqRJpHZcGPxRlhmGMwFRrXKFYyBjGfmQklTFPVGFKJMIUnGJLeMSWKMGexxuNzorGqKZXcobMHUlheNsVVzvrIijNxcHYAwtnMMsQdyjpQfbqjhNCmcdXHbTPmNgtFDCZPnEvXSPfEmUoNPiInPxPvIAJDcvfKTxG");
    double jeOmujp = 233328.2247019307;
    string jRMsQDISjJTwM = string("RiuljfCaxRzGBFcwtxosnkyMrKqCitvmWwpOFyHaGJmwkLjCMJqExderPWUldXUVlTRudemnJOOKtZqZNceHbZPAJoElWSSTaFHcV");

    for (int WXdPHFusdGAX = 367506498; WXdPHFusdGAX > 0; WXdPHFusdGAX--) {
        bNzPuPSZnRg += jRMsQDISjJTwM;
        hWAHzHXJVWau += jRMsQDISjJTwM;
    }

    if (mnsUclBM >= -1970688749) {
        for (int nXOHWnKdbIHcNmO = 783031444; nXOHWnKdbIHcNmO > 0; nXOHWnKdbIHcNmO--) {
            jRMsQDISjJTwM += hWAHzHXJVWau;
            jeOmujp *= jeOmujp;
            jRMsQDISjJTwM = bNzPuPSZnRg;
            jRMsQDISjJTwM += bNzPuPSZnRg;
        }
    }

    return XqmPJdmsDlw;
}

string sRJNEvnbBKzXN::HjiSsEtEMKcW(bool aMqxX, int IRyCEaSnHdrx, int MYSFKfYTSjNzKEk)
{
    double uCMnkvrYZ = 180888.42111943118;
    string nlKyj = string("uYsAOszvvAwOGRBAZuDmyKxYBUuTvLeFdDXUfdSjFjbheZzuIWRbdMPnWoIsBBWZZltyYDyZVfooxGuUegeqFMaAmWVKJYFowMQYrLomPbHNZUcwYPvPBzpziiAfqpbVEodsGjrdojGTwqBLfDsXHCZaiqfeXomoJKFAeMKRZziQSEtgazwHKPNAtGZRzlxhHwhWpQPIgyphRXkQUYtGVLPZYbTJdaSKXeTJ");
    string bnoVpRptzYu = string("tKXzykAOeGQdMUxkoFBdAkvfjNgBGfRvsCecAoMJy");
    bool LbsZEdYZDvq = true;
    string WfCCXqIh = string("OQPUhddKfDxeKxYaNWJgzXvMZJEoBaYvDMbEIzVUXIBLSXTjbGRtvqGvheyNZLclIOnwArzYdFPJtYhaUMhZeAYJMHxXIwgPMvFTTOlQMOQLrFEpgHQfTrUhMikKQZLWnypCStmeiRTX");
    int KTBSxQaloAphXcIp = -4722836;
    int OXJyrZapQbLgHC = -1044119373;

    for (int BfowdKhRBCOki = 1605426427; BfowdKhRBCOki > 0; BfowdKhRBCOki--) {
        WfCCXqIh += WfCCXqIh;
        nlKyj += bnoVpRptzYu;
    }

    for (int iltTtSUXo = 768786604; iltTtSUXo > 0; iltTtSUXo--) {
        continue;
    }

    if (MYSFKfYTSjNzKEk < -1044119373) {
        for (int ygzyErdd = 289357449; ygzyErdd > 0; ygzyErdd--) {
            WfCCXqIh += nlKyj;
            bnoVpRptzYu = nlKyj;
        }
    }

    if (KTBSxQaloAphXcIp >= -4722836) {
        for (int qEgHOd = 756583642; qEgHOd > 0; qEgHOd--) {
            nlKyj = nlKyj;
            bnoVpRptzYu = WfCCXqIh;
        }
    }

    for (int wVPCOyK = 307870941; wVPCOyK > 0; wVPCOyK--) {
        MYSFKfYTSjNzKEk -= KTBSxQaloAphXcIp;
    }

    return WfCCXqIh;
}

sRJNEvnbBKzXN::sRJNEvnbBKzXN()
{
    this->kvUnpoKj(false, 1946556370, string("ZVfPqLRplzsJYzBsWxCXCImqHrYnZOzyWKpKRVfMjoFFltOLYboKmovgGxfrMkQLiVdtWkSuqj"), -1570223824, string("XGqsAPyNJaQnxxnSKEbomrFhmGseyTBPRJqCecNhRUMDMgmeNemDAEzPqOwBnEjsnN"));
    this->PHrKiigamne(639372972, -168185842, -47622.737046155424);
    this->TexFwoUeqhxg(885021220);
    this->hTTKfJQrRRVOMfQ(true, string("TjeXHtfOenYjUxdfbIxlzKZjEhGhospMHnQTlVjPRfaolCKWeThzKdkkzDQiERIYEBEIGLCdaClgjsiWolKDSCKnkKtQItdEEJmfpD"), 848094150);
    this->tbwWvXmrsQZKHFnu();
    this->DtCMkDGdBYfb(string("vHkZMjMzzrngqNHJcbJDzYoHloJKkvXNuFBfjjMEsgOVLfPSkjKxjGtxxMpctpTEEEmJkKPczrTsQEsjNBHZBqFmnyNMTxqnNQGezQWCqUDuzpPkaUcwyWUXVmXcOjITtHFx"), false);
    this->FcKHxYZqJce(true, 541814673, string("BARwFqSIZuDkhWZXcJeaMBNOLXfbihMrWmLMMTfhNfUEkvBsyykDVqAlVu"), -1484323248);
    this->ZCeEdR(181333.45675722856, 1619274664, 1487187277, string("RXUqGjvncBbpidAQQnwsXgzUKQQTEMjKKKvDqdpQUSxNsMMngInwKInvTwHxbTkBEuiRfsuFMFzOADPVJQBurOnoJkGEoQkfVRiyjVDXJHuAqppCNXn"), -577343.7046702282);
    this->HeoEYG(string("FqMajbavdIGyVzeWoJBHdojDTpjkhvuegX"));
    this->gpZlyBzlcmOY(string("vQelTJfPHuIfaGyrenjtgyrKPqUagtIfLYUeZdPjornNhoKUWPGWOolLNWiuvyOheppJuEpZqTTucxKavBrfoqHxmlGVdVhWzAVINFyXbTkVUXYplZZqhRArpVtDEHGzUPiakbucgsjExXFnwnBMbqAiNnntwEXaaiMqCbzYbIJArBHDwMDeZtnndXBrSvFEcSbVynjsMZMXXpnKjAQwlPncHFBUKcXRIIwvHNjw"), string("PwsJQKltbwIKrVdZzjNBWiQbAhJMBZiXjWtLzKZjdzQgJeNVfwwvbnQNZUfvytw"), true, 182997.92686565215, -610729901);
    this->kBEiPtxKvqlvki(1023689.8629895276);
    this->bWHOFWWgQwZrn(false);
    this->kCLwuFtmBYng(string("suZoyXFSMjhbksGnMsfBSallcTZBbpcKuRrLXVNjBKbwDbdFmsLaFOsiuQErnHKygkTtZXLWyuJIXqdxUszIZpquDRqTVvwCyCAlppoSQbbuwbYjPlLBBfeCVTHbHtqJuMuJgSrTdxLDOqVFcJvvsvJjrwKTxwtqctgxrTJM"), -1970688749, 366197358);
    this->HjiSsEtEMKcW(true, 1624219965, -447354495);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hmwFVyb
{
public:
    int AiHDWVrDEuC;
    bool FvuSxYFtjdrWJRPP;
    double OqjcHVe;

    hmwFVyb();
    string pPDsFJqyG(string MIgSqBtTuHN, int NsHajjeUevFcFa, string UcJkagvbPhho, bool gudcGp);
    bool DpaESfl(bool wlBGoLpxO, bool FcxWVs, int LaehteI, double GFVHgL, int mjrOv);
    void FUMNdejT(int tTxWMMm, double CVAQyufgVBUEzuw, double grlxTrrPKHjaqu);
protected:
    string lFpTaDxsMsqMFhhh;
    bool fCNwHUvUQ;
    double FfktYEI;
    int ZDmgcqGQcyfKKOk;
    bool OBRPWXUTeV;

    int zSlcmjyYkDueLssX();
    double zYzxNouavtYLaOl(string ArxAHRaCEFVq, int tYgotwHQqQYRZf, int wWiCwuLfJ);
    double iPVNiGACr(bool ydRRL);
    void SwBbwSv(double DvnpbyCFeCxlW, double TNvKBCY, int jObHpqUIFAQjg, double dAOYaI);
    string MqUVNpUznWbjSn(double BXxNVzNaJctOPJ, string ttpVdOCOpbYKLH, int wtJjTTbbn, int dIsJegGEUS);
    bool yumDgJ(double XtHijRnWqcPE, double Wbqroi, bool MHJOJlEBcakH);
    bool KHnIYmqdLwzwqcTg(string ORwINtlz, int JsCXIRcowNuPk);
private:
    string SmykUdKXTWlYiq;

    bool ajbiQCcsdqgQ();
};

string hmwFVyb::pPDsFJqyG(string MIgSqBtTuHN, int NsHajjeUevFcFa, string UcJkagvbPhho, bool gudcGp)
{
    int KWNhaYJMFqSPGX = 1075070589;
    string fRjhFSq = string("AgAdrwtzeXHQznLolUfHSZCBRQizbeKottgfZsEQoUTltFsPQMwsWPHsCyyTMgXxWVIViNHtKyFDPjccoqjxAyZXcIlLilJwONJXpiLMNhVgsMbPElEABOBfSjbWXBxtNsJjhXoIDQSflDXwRNDgjFofHYpAlRuhhARNMluGsLfPJOSlnwbYOFFegqkkjvRrlQaiiuxiSWzlpDrebVbNcONumXWrWiTbTSOpfamJKpgUUYFBPBSFlokSrG");
    bool IInZXLQBUwnFQ = false;
    int bZwTQh = -1258817602;

    for (int ULfrjwOYVBlyX = 778778126; ULfrjwOYVBlyX > 0; ULfrjwOYVBlyX--) {
        IInZXLQBUwnFQ = IInZXLQBUwnFQ;
        bZwTQh = NsHajjeUevFcFa;
    }

    if (gudcGp != false) {
        for (int YIbRucdfIoWqWv = 509634041; YIbRucdfIoWqWv > 0; YIbRucdfIoWqWv--) {
            gudcGp = ! IInZXLQBUwnFQ;
            UcJkagvbPhho = fRjhFSq;
        }
    }

    return fRjhFSq;
}

bool hmwFVyb::DpaESfl(bool wlBGoLpxO, bool FcxWVs, int LaehteI, double GFVHgL, int mjrOv)
{
    double KpZQq = -480062.2863347704;
    string TbRKjjAmHIUINFJ = string("khvMIulOodqytzRsOlEBjoJkdJvvvHWLfEVKmPDNdUvIyWObtQFVKSzIaItQYWHsZzpgzyeaQjJwdUOaNJdgVkFIMOQvsUNCIYhwbiCWZvbJqnUYTAhUwboKvPaP");
    double mJeKcxXgSduTjwg = 60898.60810190006;
    bool rxKRHniVwb = false;
    int sSdTKltUyJW = -654456517;
    string jpsvqHfHWfaBV = string("RhNXDnfKGFXBOqXxdADIKBtESLducRUqjpSOsnxuhSoBUUDUmazUAOZBpiflUhxcnAPHWzJONkbldACmbihrSolbEeeqyTRAdKoOVlIIspTxVIMNJoksgMKeWcDUxxeYyRxcRfQSbidIyEYeqVwWSAGwClMtoYMZWUWcXFRIcxxilzvEpJzcOUukCDjuneojVferELklczjOswRP");
    int dHClxjCUrALe = 1703000314;

    if (LaehteI <= -654456517) {
        for (int OAsCNra = 852941600; OAsCNra > 0; OAsCNra--) {
            TbRKjjAmHIUINFJ = jpsvqHfHWfaBV;
        }
    }

    return rxKRHniVwb;
}

void hmwFVyb::FUMNdejT(int tTxWMMm, double CVAQyufgVBUEzuw, double grlxTrrPKHjaqu)
{
    double LLPljDxzbuec = -512611.8914205453;
    double AudjpqcIaNj = 1018691.5475525265;
    double AwDKuReTbDWEDO = -430519.5591434093;
    double KokQh = 636507.8831552303;
    double XMuTRSRv = 831813.9585775636;

    if (grlxTrrPKHjaqu != 831813.9585775636) {
        for (int lyCki = 1073626585; lyCki > 0; lyCki--) {
            AudjpqcIaNj = XMuTRSRv;
            grlxTrrPKHjaqu -= AwDKuReTbDWEDO;
        }
    }

    if (XMuTRSRv <= 894668.9434714983) {
        for (int JiQJwf = 1660968725; JiQJwf > 0; JiQJwf--) {
            tTxWMMm /= tTxWMMm;
        }
    }

    if (AudjpqcIaNj < -430519.5591434093) {
        for (int IMaaWDPjGCZ = 500382445; IMaaWDPjGCZ > 0; IMaaWDPjGCZ--) {
            tTxWMMm -= tTxWMMm;
            KokQh /= AwDKuReTbDWEDO;
            AudjpqcIaNj /= LLPljDxzbuec;
            KokQh += AwDKuReTbDWEDO;
            LLPljDxzbuec = CVAQyufgVBUEzuw;
            AwDKuReTbDWEDO -= CVAQyufgVBUEzuw;
            KokQh = AudjpqcIaNj;
        }
    }
}

int hmwFVyb::zSlcmjyYkDueLssX()
{
    string gEDUhDeQiktLQCQ = string("icEyUhITUrCGBjp");

    if (gEDUhDeQiktLQCQ == string("icEyUhITUrCGBjp")) {
        for (int sSEGgO = 212878982; sSEGgO > 0; sSEGgO--) {
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
        }
    }

    if (gEDUhDeQiktLQCQ != string("icEyUhITUrCGBjp")) {
        for (int LaZRjzMjOii = 1501039435; LaZRjzMjOii > 0; LaZRjzMjOii--) {
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
        }
    }

    if (gEDUhDeQiktLQCQ == string("icEyUhITUrCGBjp")) {
        for (int XkfhtR = 521289466; XkfhtR > 0; XkfhtR--) {
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
        }
    }

    if (gEDUhDeQiktLQCQ == string("icEyUhITUrCGBjp")) {
        for (int COCVrqVtRW = 475872765; COCVrqVtRW > 0; COCVrqVtRW--) {
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
        }
    }

    if (gEDUhDeQiktLQCQ < string("icEyUhITUrCGBjp")) {
        for (int KiWCeKr = 742980526; KiWCeKr > 0; KiWCeKr--) {
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ = gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
            gEDUhDeQiktLQCQ += gEDUhDeQiktLQCQ;
        }
    }

    return -1634736305;
}

double hmwFVyb::zYzxNouavtYLaOl(string ArxAHRaCEFVq, int tYgotwHQqQYRZf, int wWiCwuLfJ)
{
    int TOmVbvPLeFaxs = 10552944;
    double YjaWMWKmJprkny = 729461.1377122203;

    if (wWiCwuLfJ != -240705267) {
        for (int sTXwOGwsyYKuaxb = 1965047860; sTXwOGwsyYKuaxb > 0; sTXwOGwsyYKuaxb--) {
            TOmVbvPLeFaxs *= TOmVbvPLeFaxs;
            YjaWMWKmJprkny *= YjaWMWKmJprkny;
        }
    }

    for (int cFtHqXHBWPJwG = 793918808; cFtHqXHBWPJwG > 0; cFtHqXHBWPJwG--) {
        tYgotwHQqQYRZf /= tYgotwHQqQYRZf;
    }

    for (int HtmqCBJchf = 2028904775; HtmqCBJchf > 0; HtmqCBJchf--) {
        wWiCwuLfJ *= wWiCwuLfJ;
    }

    for (int eyDcRAndzxkkmQs = 1920741110; eyDcRAndzxkkmQs > 0; eyDcRAndzxkkmQs--) {
        wWiCwuLfJ = wWiCwuLfJ;
        ArxAHRaCEFVq += ArxAHRaCEFVq;
    }

    if (TOmVbvPLeFaxs > -1290143537) {
        for (int TMNadO = 1282613876; TMNadO > 0; TMNadO--) {
            wWiCwuLfJ /= tYgotwHQqQYRZf;
            TOmVbvPLeFaxs += tYgotwHQqQYRZf;
            tYgotwHQqQYRZf = wWiCwuLfJ;
            TOmVbvPLeFaxs += TOmVbvPLeFaxs;
        }
    }

    return YjaWMWKmJprkny;
}

double hmwFVyb::iPVNiGACr(bool ydRRL)
{
    int fpruTBBpTMoK = 216724558;
    bool NIgUhapujbQho = false;
    double ggzoCDN = -1335.9485000280508;
    string cnmmNdJvBTloZj = string("wkFuttLoQhgiFNIMPjKHWbHlVxiizmOVUzeGpGyawUyDuuneCibJLBOxJdWNpFjcJuLIOMXpwSjJkgucDAVfWtdcmyxPMDIUUYoSOUVBgkQJNGHnTNipPgqUZRUlRQLSweiSoAvJBgdReUjpUzvAetuOvdvyG");
    string UZfTLx = string("xzKSIM");
    int QSSdXZLpdN = -1407325862;
    int gVxRtkrwe = 700245664;
    string WcsWEgodLEncdzwI = string("cAuGamshUBwITHGomzKPjaZKshcNJzyaupEycsSebHMQwRXTbdBYzTxVIzkUbgOFonRcGkIFZFQTPNdyIBuvvfdOTpaRCJhHPJVeTGK");
    double wBXjreFKGLh = 913099.8122437198;
    int SPTorFsAPTvHSei = -21112314;

    if (ggzoCDN >= 913099.8122437198) {
        for (int AKFWxdQdSY = 688861764; AKFWxdQdSY > 0; AKFWxdQdSY--) {
            ydRRL = ! NIgUhapujbQho;
            QSSdXZLpdN = fpruTBBpTMoK;
        }
    }

    if (ggzoCDN == 913099.8122437198) {
        for (int SAIKRz = 280690013; SAIKRz > 0; SAIKRz--) {
            gVxRtkrwe *= gVxRtkrwe;
        }
    }

    return wBXjreFKGLh;
}

void hmwFVyb::SwBbwSv(double DvnpbyCFeCxlW, double TNvKBCY, int jObHpqUIFAQjg, double dAOYaI)
{
    double JPpJHoyuEkRgLOM = -748965.6850363844;
    double nTQcUKoGtqt = 523440.35717897123;
    int pFqZSmFKZpTXtama = -129328256;
    double UQLaAEHBcrDNEz = -1031798.7344774564;
    bool SyksPNsmLOB = true;
    int qzofzEDznfxY = 1880495753;
    string bKxkuwvnYnJ = string("OTLzsXfvdLbavQaJnISrxSnHdYfEVqZSeMoKLkTPdMyJJGdkjgbPaFcXSMwJqTyHZWirRMwOc");
    string cGdEmDP = string("hnnscqSyCNdwgAPuTThKzzmNqMDZaivAUMOqakdpkltRHuNOyWaqVnrCXrkqPlSxBpjkkHRDwdwgWhTfLyDuqRTovJZFUFajGMXGZratJwYLfFPlQhIwqJIWZGExZnSCbFfjQtUDYkFqtHyhjujZZblZLbRxmoBXPFaDRZrNhvVoaIhJEnbWOuRATMkfs");
    int WrEAjQvkhOf = 661513766;
}

string hmwFVyb::MqUVNpUznWbjSn(double BXxNVzNaJctOPJ, string ttpVdOCOpbYKLH, int wtJjTTbbn, int dIsJegGEUS)
{
    int NFFOAUDHYwfiqtG = 77919061;

    if (BXxNVzNaJctOPJ <= 976094.8882437384) {
        for (int MsriSYWJG = 1447046290; MsriSYWJG > 0; MsriSYWJG--) {
            NFFOAUDHYwfiqtG = dIsJegGEUS;
            NFFOAUDHYwfiqtG /= dIsJegGEUS;
            wtJjTTbbn -= NFFOAUDHYwfiqtG;
            NFFOAUDHYwfiqtG *= wtJjTTbbn;
            NFFOAUDHYwfiqtG /= NFFOAUDHYwfiqtG;
        }
    }

    for (int jlFRa = 669568418; jlFRa > 0; jlFRa--) {
        NFFOAUDHYwfiqtG *= dIsJegGEUS;
        NFFOAUDHYwfiqtG -= NFFOAUDHYwfiqtG;
    }

    for (int HAjrrXPuDhFOmB = 1173580762; HAjrrXPuDhFOmB > 0; HAjrrXPuDhFOmB--) {
        continue;
    }

    if (NFFOAUDHYwfiqtG >= -1089332719) {
        for (int IMsIHQ = 1360127198; IMsIHQ > 0; IMsIHQ--) {
            dIsJegGEUS -= NFFOAUDHYwfiqtG;
            dIsJegGEUS -= NFFOAUDHYwfiqtG;
            dIsJegGEUS *= wtJjTTbbn;
        }
    }

    for (int UrRroV = 82957316; UrRroV > 0; UrRroV--) {
        wtJjTTbbn -= NFFOAUDHYwfiqtG;
    }

    for (int utUPZJkpRAkwZaZ = 1111602085; utUPZJkpRAkwZaZ > 0; utUPZJkpRAkwZaZ--) {
        BXxNVzNaJctOPJ += BXxNVzNaJctOPJ;
        wtJjTTbbn = wtJjTTbbn;
        ttpVdOCOpbYKLH += ttpVdOCOpbYKLH;
        dIsJegGEUS /= wtJjTTbbn;
    }

    return ttpVdOCOpbYKLH;
}

bool hmwFVyb::yumDgJ(double XtHijRnWqcPE, double Wbqroi, bool MHJOJlEBcakH)
{
    double kjmXPPwGaUCm = -49952.185207165836;
    string ZtzFzTm = string("TegjRpovFbrgIaEiDZswQAMqcJJTKtfzjZczaireJckNOHCuayVJNgpuQMxdhptvyHFxcKpunxAQNGXzaMloOrVxGkdacDSITSrSGXFkffNjELZlIMALzlyIDGjkdMwWWHvIgiGJehUnZGlqcqBqovMMTGLEnovWmVzcWWBxHuWZcAeyPoPxXgpbvdGnuLrQiCgZtDaVgInVjgXwqqgXqFzqtF");
    double NwwwtykblUwpgqa = 708496.622351363;
    bool zRoxsFTbO = false;

    if (Wbqroi <= -607582.148242458) {
        for (int yLgioEOdV = 1798301867; yLgioEOdV > 0; yLgioEOdV--) {
            continue;
        }
    }

    if (MHJOJlEBcakH != false) {
        for (int xqAGPXQsH = 852552591; xqAGPXQsH > 0; xqAGPXQsH--) {
            kjmXPPwGaUCm += NwwwtykblUwpgqa;
        }
    }

    return zRoxsFTbO;
}

bool hmwFVyb::KHnIYmqdLwzwqcTg(string ORwINtlz, int JsCXIRcowNuPk)
{
    int aLzLGcxuTzAQKxy = 95807495;
    double zHovozZ = -700474.9360753351;
    bool ZLHmf = false;
    string dMGBrNHWtsxnA = string("zLdxJjbmijGxMGGqNOdzZJcAGVINGrOYzIKyELQcJEakswOxYYYgYSoqWzBmvXmGJqcVG");

    for (int ZeQxQlGPdf = 1292755774; ZeQxQlGPdf > 0; ZeQxQlGPdf--) {
        aLzLGcxuTzAQKxy *= JsCXIRcowNuPk;
        ORwINtlz = ORwINtlz;
        ZLHmf = ZLHmf;
    }

    if (aLzLGcxuTzAQKxy <= 1618917497) {
        for (int ccBjDlKyEAQUpx = 747889730; ccBjDlKyEAQUpx > 0; ccBjDlKyEAQUpx--) {
            JsCXIRcowNuPk -= JsCXIRcowNuPk;
            dMGBrNHWtsxnA += dMGBrNHWtsxnA;
            zHovozZ -= zHovozZ;
        }
    }

    if (aLzLGcxuTzAQKxy == 1618917497) {
        for (int RuNPDn = 1833045502; RuNPDn > 0; RuNPDn--) {
            continue;
        }
    }

    if (JsCXIRcowNuPk > 95807495) {
        for (int bnaWdV = 1343382878; bnaWdV > 0; bnaWdV--) {
            zHovozZ *= zHovozZ;
            ZLHmf = ! ZLHmf;
            zHovozZ = zHovozZ;
        }
    }

    for (int sLdyhWZsPbkUasoB = 1057939292; sLdyhWZsPbkUasoB > 0; sLdyhWZsPbkUasoB--) {
        aLzLGcxuTzAQKxy += JsCXIRcowNuPk;
        aLzLGcxuTzAQKxy += JsCXIRcowNuPk;
    }

    if (ORwINtlz <= string("knXuTEYAHRSHLeaKqJeqQsruFMkauOyNAbzhvOWIKtgNZwxwjKFqNUsTCePeSIRHvVguGkmzhQhCaycVXQqlQTEZMUkxtvjtefVsejkHZspxBPtGxyHBRUkHfBHzcLamLXMyqJlKbjuTOFCzbCgEXpQlUkrEuKZBahhiTrxBwJttSbTNKBBqbSLlStOFdCPwkWdLIpabFTFqplvZYDfjSZNrbwpWKkqbcgKryJQ")) {
        for (int ZCxXCJWtOX = 1220842265; ZCxXCJWtOX > 0; ZCxXCJWtOX--) {
            continue;
        }
    }

    for (int HoyeXhSp = 150432190; HoyeXhSp > 0; HoyeXhSp--) {
        ORwINtlz = dMGBrNHWtsxnA;
        ORwINtlz += ORwINtlz;
    }

    return ZLHmf;
}

bool hmwFVyb::ajbiQCcsdqgQ()
{
    string LssESnVeBL = string("JmSMDwXTjMlKtXOoueMuFtvTPggoSYIzHwNEUwtkviYcdhERIzQiyLGENIAeqFzdrQuzUKKyXqnwEYkrzpIWloCCHCCtbLSFBGogIeiFkdYPxCLbONQvSezwsOJhCWnQwTqbwTMZ");
    int DDuHMlLDuSyJD = -104244346;

    if (DDuHMlLDuSyJD == -104244346) {
        for (int JbcGHdwp = 2117817249; JbcGHdwp > 0; JbcGHdwp--) {
            DDuHMlLDuSyJD = DDuHMlLDuSyJD;
        }
    }

    for (int aZcOZiUNGGtIRFBw = 1849451700; aZcOZiUNGGtIRFBw > 0; aZcOZiUNGGtIRFBw--) {
        LssESnVeBL += LssESnVeBL;
        LssESnVeBL += LssESnVeBL;
        LssESnVeBL = LssESnVeBL;
    }

    return true;
}

hmwFVyb::hmwFVyb()
{
    this->pPDsFJqyG(string("WGemNxEBLcKcmkvlMbkhoBIyrSHRkaCSAJXRLzaMUQvkPHQvAqlYaBKSrwRuyNQhCFcMbjnQvqi"), 2018093524, string("iwtfEjVBGGaxUQDutGvcXTpoQgDcAczvaMdPvjAZZgoJxjjEUiWVfcpSndyavSSdmQLiZYBXlVyywqKpHNFmsZalwXUXTUbgvNvrkhBRJwVTibHIjewjKdB"), false);
    this->DpaESfl(false, true, -956263824, -801566.457503415, 854734814);
    this->FUMNdejT(1362387556, 894668.9434714983, -683212.8300927252);
    this->zSlcmjyYkDueLssX();
    this->zYzxNouavtYLaOl(string("SgGqNZygfsdvyofuJppHLhUvAONGxeIsYvTjSRUgClmIIJHwJZMjADCFPAZrpbyGPYJKqoOectwTXjFKbmDjBOuVBEoKSSiLQHHNqJuzoJSAZisjCNvkhsbwLrqtcaHesLqIYXdcnpUNMDNGphMGoaHLTFlmJhKiTAwngQWwbJBzcicUOWFJGuVYxThwrgDVWADgETBGVxiGDzg"), -240705267, -1290143537);
    this->iPVNiGACr(false);
    this->SwBbwSv(-968039.3611491736, 865791.6598631742, 1773847717, 790723.7818347901);
    this->MqUVNpUznWbjSn(976094.8882437384, string("BOwhhnaLdXjGNCgYcrTQXnvDZnIzlNpDdzVTXgXsnZRBEWHCsZCiPd"), -1089332719, 1664388823);
    this->yumDgJ(-607582.148242458, 456922.3117406366, false);
    this->KHnIYmqdLwzwqcTg(string("knXuTEYAHRSHLeaKqJeqQsruFMkauOyNAbzhvOWIKtgNZwxwjKFqNUsTCePeSIRHvVguGkmzhQhCaycVXQqlQTEZMUkxtvjtefVsejkHZspxBPtGxyHBRUkHfBHzcLamLXMyqJlKbjuTOFCzbCgEXpQlUkrEuKZBahhiTrxBwJttSbTNKBBqbSLlStOFdCPwkWdLIpabFTFqplvZYDfjSZNrbwpWKkqbcgKryJQ"), 1618917497);
    this->ajbiQCcsdqgQ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kzVTUdVnDcyso
{
public:
    int HEtcVv;
    bool nobIIInSNcLzHF;
    string jNgun;
    string bDgDqLj;

    kzVTUdVnDcyso();
    string SvWVUTwOoxxRei(string eEFwQlYNlVYEoJka, bool ntlnnWkFQ, string QnanECLyaKqVWSRf);
    bool sjhHzNN(string hrOghygGYtSHP, double eDBWQPGC, string wtxmPUQYFUZU, double AGiOfxgmYdeyR, int UBfCTKcEUNaS);
protected:
    double zkJndLvvLWxULkp;
    string bMDHXyGhIvw;
    string IQzaXeRkfmBA;
    double zLsWGqeYHfpchUp;
    bool zglHHMGNl;
    bool PVUOcWyMHQ;

    bool edXxrnrTg(int YZjrzbh, double nOSIMsgrehV);
    string nYyfTnWg(double nEBVFOsrZgv, double LzURoaYnvRqmed);
    bool mhpzc(bool yeIIBGEbQuN, int baksYsOnPR, bool dadUvyJh, int pcWyUYHTIFqMlwrU);
private:
    int SKYPvKrFL;
    bool VbfzNRJHSK;
    string QqEgaarNyo;
    bool jXNroyaSium;

    string qXaBqAhn(string yufYOWRJRNddTL, int AlcEuJgryzer);
    void yGCqUQcodFcwMX(double PLuJpXNClHC);
    int HXZEQEJbCFAgmfkx(int QkBIfxo);
    void UjzWI(double TQRGjLuV, bool WNPyPaxrtVtpwmcs, string TzOSoNOJpnthGI, string jtpbzicEDpDITkR, string uMUIzqZ);
    bool wYRxp(string qGsfmXGP, bool swHrQbsqOSthI, int PsRiHxAmZMmJLSY, double wOJzfmAvO);
    int XPsqgZ(bool WEIMEASRKRYkWxJ);
    void LGnkqgcUroIz(int UgRkxdYXQCCJ, bool dSYbdM, bool LdEzKpGUZGvxcqdM, string naHmDaQ, bool UJJVZIuakUHY);
};

string kzVTUdVnDcyso::SvWVUTwOoxxRei(string eEFwQlYNlVYEoJka, bool ntlnnWkFQ, string QnanECLyaKqVWSRf)
{
    bool PUmNtzO = true;
    bool xVNHOO = true;

    if (ntlnnWkFQ == true) {
        for (int RVMmIoAfildIFiE = 500623356; RVMmIoAfildIFiE > 0; RVMmIoAfildIFiE--) {
            continue;
        }
    }

    if (PUmNtzO != true) {
        for (int CuEVUFimKCKiCBa = 1253586274; CuEVUFimKCKiCBa > 0; CuEVUFimKCKiCBa--) {
            ntlnnWkFQ = ! ntlnnWkFQ;
            ntlnnWkFQ = ntlnnWkFQ;
            ntlnnWkFQ = PUmNtzO;
            PUmNtzO = ! xVNHOO;
            xVNHOO = ! PUmNtzO;
        }
    }

    if (ntlnnWkFQ != true) {
        for (int QJhNnLwV = 560777818; QJhNnLwV > 0; QJhNnLwV--) {
            PUmNtzO = ! ntlnnWkFQ;
            eEFwQlYNlVYEoJka += eEFwQlYNlVYEoJka;
        }
    }

    if (xVNHOO == true) {
        for (int LwAdghIlhApIM = 309181947; LwAdghIlhApIM > 0; LwAdghIlhApIM--) {
            continue;
        }
    }

    for (int weLLhCDQQ = 909507296; weLLhCDQQ > 0; weLLhCDQQ--) {
        eEFwQlYNlVYEoJka += QnanECLyaKqVWSRf;
        eEFwQlYNlVYEoJka += eEFwQlYNlVYEoJka;
        QnanECLyaKqVWSRf += QnanECLyaKqVWSRf;
    }

    return QnanECLyaKqVWSRf;
}

bool kzVTUdVnDcyso::sjhHzNN(string hrOghygGYtSHP, double eDBWQPGC, string wtxmPUQYFUZU, double AGiOfxgmYdeyR, int UBfCTKcEUNaS)
{
    int VbDGYPZmPQPMUwPY = 117293035;
    double pJGoMJqhPW = 808225.4230199106;
    bool odJSREHMjtxHPM = true;
    bool qwjkN = true;
    int oLiTnkkvICC = 504230662;
    bool xrkFeFQvXAFbsIV = false;
    string fznLAcCLaBlUxiGU = string("JzWPKNpbkHAmDgDkISpbWMzPLVhUJSNuOIGxYXyvjAhtBNPmAGLtcMgRpzLvnmslPVYBfLGtsGhjnPmqNEfNMvVYGmSHQxCPpzUyJYtoJtchVFPQznzmmDODtacCfWAXOMppUhyWxtEFCANRaIwdKDTgMcTjcDSZsnRMYgxJUCIHURmXxgjgz");

    return xrkFeFQvXAFbsIV;
}

bool kzVTUdVnDcyso::edXxrnrTg(int YZjrzbh, double nOSIMsgrehV)
{
    double TfzqiC = -155059.5390346593;
    string WbvTybUFsEu = string("rKnyidDuRHoEmJdcSnoTprXdCsRUxGWTSREUnWxpEePGyvZobMA");
    bool xUKUM = false;
    double yBTsqWhafTmg = -100783.50380875381;
    int uOsiDQ = -2083508162;

    for (int bKjMJZcxHXaMtmJs = 1109171706; bKjMJZcxHXaMtmJs > 0; bKjMJZcxHXaMtmJs--) {
        yBTsqWhafTmg *= TfzqiC;
        uOsiDQ /= YZjrzbh;
        nOSIMsgrehV /= yBTsqWhafTmg;
    }

    for (int sPeFaBqdaeGdBf = 252364389; sPeFaBqdaeGdBf > 0; sPeFaBqdaeGdBf--) {
        continue;
    }

    if (YZjrzbh != -2083508162) {
        for (int pWSdxKgkOA = 831914303; pWSdxKgkOA > 0; pWSdxKgkOA--) {
            nOSIMsgrehV *= yBTsqWhafTmg;
            yBTsqWhafTmg /= TfzqiC;
        }
    }

    for (int eNPqveFYIRUd = 1193809243; eNPqveFYIRUd > 0; eNPqveFYIRUd--) {
        uOsiDQ += YZjrzbh;
        nOSIMsgrehV /= TfzqiC;
    }

    if (TfzqiC <= 997420.7785775078) {
        for (int itzTAmWuWk = 554324683; itzTAmWuWk > 0; itzTAmWuWk--) {
            yBTsqWhafTmg /= nOSIMsgrehV;
            yBTsqWhafTmg /= yBTsqWhafTmg;
        }
    }

    for (int wleAzSvVZ = 948981687; wleAzSvVZ > 0; wleAzSvVZ--) {
        TfzqiC /= nOSIMsgrehV;
    }

    return xUKUM;
}

string kzVTUdVnDcyso::nYyfTnWg(double nEBVFOsrZgv, double LzURoaYnvRqmed)
{
    string nagQPQqgbAlOEQnI = string("VGJfCiaukVaXRTtIzHVXFohqcrBMINonSq");
    double JMOGfbYoJD = 586733.138728286;
    bool NwAUmYyRQd = false;

    for (int SMNlE = 1202446962; SMNlE > 0; SMNlE--) {
        LzURoaYnvRqmed *= LzURoaYnvRqmed;
        LzURoaYnvRqmed /= LzURoaYnvRqmed;
        LzURoaYnvRqmed /= JMOGfbYoJD;
    }

    return nagQPQqgbAlOEQnI;
}

bool kzVTUdVnDcyso::mhpzc(bool yeIIBGEbQuN, int baksYsOnPR, bool dadUvyJh, int pcWyUYHTIFqMlwrU)
{
    bool MAcMzo = false;
    string cMcShoeYqxNck = string("raiceCcGSYhhpgVgKwMXFJTUxyJqkyxXUKsUBJqUHfjBTgKSTlIvzrCzJssZwKrEcRftnrAMUSlXWmvblwyEOgaODKzHAMAgRGTNGPZFOhGmqVJmFzTOLvfvJOdFhUfpUeEchvicPIjRXxMMxRjRxhsJicvNeIocpXckWNhVyENhNYPePAtjjSKOuNpwSTMkxwofcZhEoYOrN");
    int kWOaA = -629871561;
    bool ZKMzKkeZ = true;
    string gLeBK = string("uKbgXUsHNkqXFYUIWNqpUbeETEleQlvCKOQVLoyxXMCuufiPeaReJouVonuiWAyrwqgCRKXFyaUHIAsbIHCWLBdzqdrRHtDxAXPjyNnPYOyNlyFFFgpxdKosuXqkQEqHhTcvQSwTbmrFQpNleSWjPwjDRwZjujbqaTyByHQEKddbPIwVyGsZLMZjItvgwQrmeJSWUHzmPuSxm");
    string ZiLYAkl = string("EgOwafBHgHBLgiJLVrLhVljWmXJinStxFdQpfgVLXalENlUmkeEIvoSrJHSjQImHJVWMgMtrgGAWDlCnKhKMjiQLgBvfsxMGvFqKJWiYQqivmdymVkTJYhykeLsDKlyZYNijpFbCNTdskVuwpwnwaEvFtTqadnjuhJocpISFhLZqhqzwOSaJsXlWjQNikXrIGJIvWOlDKwvATADOZGswwM");
    bool kWjmT = true;
    bool QjYGJrqEgHBdys = true;

    for (int CqsbNxsLaurVPmDQ = 1078753297; CqsbNxsLaurVPmDQ > 0; CqsbNxsLaurVPmDQ--) {
        kWjmT = QjYGJrqEgHBdys;
        kWjmT = yeIIBGEbQuN;
        ZKMzKkeZ = kWjmT;
        ZKMzKkeZ = dadUvyJh;
    }

    for (int ejRDkQObZOoHYD = 1267734698; ejRDkQObZOoHYD > 0; ejRDkQObZOoHYD--) {
        yeIIBGEbQuN = ! ZKMzKkeZ;
    }

    if (gLeBK < string("raiceCcGSYhhpgVgKwMXFJTUxyJqkyxXUKsUBJqUHfjBTgKSTlIvzrCzJssZwKrEcRftnrAMUSlXWmvblwyEOgaODKzHAMAgRGTNGPZFOhGmqVJmFzTOLvfvJOdFhUfpUeEchvicPIjRXxMMxRjRxhsJicvNeIocpXckWNhVyENhNYPePAtjjSKOuNpwSTMkxwofcZhEoYOrN")) {
        for (int REjYhfgBmWgorQA = 1728744113; REjYhfgBmWgorQA > 0; REjYhfgBmWgorQA--) {
            MAcMzo = MAcMzo;
        }
    }

    for (int AbeXyuwbrEheW = 362390193; AbeXyuwbrEheW > 0; AbeXyuwbrEheW--) {
        baksYsOnPR = kWOaA;
    }

    return QjYGJrqEgHBdys;
}

string kzVTUdVnDcyso::qXaBqAhn(string yufYOWRJRNddTL, int AlcEuJgryzer)
{
    int vddvEhAbQMPAr = 582661393;
    double jhnMuQJXdrbCrGIm = -452757.0485946142;
    int BufKVFRFwe = 545236080;

    for (int VehUocmgIo = 1089343505; VehUocmgIo > 0; VehUocmgIo--) {
        AlcEuJgryzer += AlcEuJgryzer;
        BufKVFRFwe *= vddvEhAbQMPAr;
        AlcEuJgryzer -= AlcEuJgryzer;
        AlcEuJgryzer *= BufKVFRFwe;
        vddvEhAbQMPAr *= BufKVFRFwe;
    }

    for (int eYnTf = 340418936; eYnTf > 0; eYnTf--) {
        AlcEuJgryzer *= AlcEuJgryzer;
    }

    return yufYOWRJRNddTL;
}

void kzVTUdVnDcyso::yGCqUQcodFcwMX(double PLuJpXNClHC)
{
    int nvVzYhdNAFrj = 1211020283;
    double cTktSoqZRpphIIo = 278459.5071161015;

    if (nvVzYhdNAFrj == 1211020283) {
        for (int AyhIeQxgL = 58161011; AyhIeQxgL > 0; AyhIeQxgL--) {
            cTktSoqZRpphIIo /= cTktSoqZRpphIIo;
            cTktSoqZRpphIIo /= PLuJpXNClHC;
            PLuJpXNClHC *= PLuJpXNClHC;
        }
    }

    for (int KsyIFoKAkrheFmLs = 1723185002; KsyIFoKAkrheFmLs > 0; KsyIFoKAkrheFmLs--) {
        nvVzYhdNAFrj = nvVzYhdNAFrj;
        cTktSoqZRpphIIo -= PLuJpXNClHC;
        PLuJpXNClHC = cTktSoqZRpphIIo;
        PLuJpXNClHC *= PLuJpXNClHC;
        cTktSoqZRpphIIo += PLuJpXNClHC;
    }

    if (PLuJpXNClHC > 983370.9969379643) {
        for (int bZybitNompiEm = 660786782; bZybitNompiEm > 0; bZybitNompiEm--) {
            nvVzYhdNAFrj = nvVzYhdNAFrj;
            nvVzYhdNAFrj += nvVzYhdNAFrj;
            PLuJpXNClHC *= PLuJpXNClHC;
            PLuJpXNClHC /= cTktSoqZRpphIIo;
        }
    }

    if (PLuJpXNClHC >= 983370.9969379643) {
        for (int rLUVaZnIoaqfIS = 1224384983; rLUVaZnIoaqfIS > 0; rLUVaZnIoaqfIS--) {
            PLuJpXNClHC += cTktSoqZRpphIIo;
            cTktSoqZRpphIIo = cTktSoqZRpphIIo;
        }
    }

    if (cTktSoqZRpphIIo < 278459.5071161015) {
        for (int DKYTzBajizmQJ = 855893354; DKYTzBajizmQJ > 0; DKYTzBajizmQJ--) {
            PLuJpXNClHC += PLuJpXNClHC;
            nvVzYhdNAFrj += nvVzYhdNAFrj;
            PLuJpXNClHC /= cTktSoqZRpphIIo;
            nvVzYhdNAFrj -= nvVzYhdNAFrj;
            cTktSoqZRpphIIo /= PLuJpXNClHC;
            PLuJpXNClHC += cTktSoqZRpphIIo;
        }
    }

    if (nvVzYhdNAFrj >= 1211020283) {
        for (int FuyfdUfGtLLMKXSX = 2032148318; FuyfdUfGtLLMKXSX > 0; FuyfdUfGtLLMKXSX--) {
            PLuJpXNClHC = cTktSoqZRpphIIo;
            nvVzYhdNAFrj /= nvVzYhdNAFrj;
        }
    }
}

int kzVTUdVnDcyso::HXZEQEJbCFAgmfkx(int QkBIfxo)
{
    double acvdV = 490816.9831838966;
    string rlXdWwvJsl = string("xFNnmfnprcEowKxQJkGPQSZpDZgMKVVnZzoNVjsnsOjFgMMiUuLZQzGFgIOZQwyCuvyzWgaFDcmyQZPywlUGeOgPVwGAlutcNtJgkCuXAOD");
    double EOgKjSA = -816266.9991831743;
    string TJPDtuZWfrrDE = string("AoasOEKCUpvkPIGDffUnnhsrXHQvQcMoThLsxhmXQOOMHKpZQpeqbgfPxRscBwSdkYbBQftEvscjAaQCuxpwAMkroacpIAHTGFyvNLEaUIUuGfCqqOpGg");
    string omTrMRhou = string("bXMtUFBTtkiQpydRNugrqwTwaVFFiDroiPmHIHcgLAOxWiMxGMyriBOtedDDjZxboKDhBe");
    int XEsBhMuFE = 1448291406;
    bool gvNqhUymj = false;
    double OtfKbyR = 454260.35500651965;
    double UZKSRUN = 802969.1247762983;

    for (int XLPGWkcbonOF = 1988430629; XLPGWkcbonOF > 0; XLPGWkcbonOF--) {
        EOgKjSA *= acvdV;
        EOgKjSA += EOgKjSA;
        UZKSRUN *= OtfKbyR;
        rlXdWwvJsl += TJPDtuZWfrrDE;
    }

    for (int RCsXQbiF = 239949246; RCsXQbiF > 0; RCsXQbiF--) {
        acvdV -= OtfKbyR;
        OtfKbyR -= UZKSRUN;
    }

    for (int BYsOnFiwhc = 1986024948; BYsOnFiwhc > 0; BYsOnFiwhc--) {
        EOgKjSA += acvdV;
    }

    return XEsBhMuFE;
}

void kzVTUdVnDcyso::UjzWI(double TQRGjLuV, bool WNPyPaxrtVtpwmcs, string TzOSoNOJpnthGI, string jtpbzicEDpDITkR, string uMUIzqZ)
{
    string ovyEyJLWuTEleaD = string("MgDGvYaNqxBprsiaofRQWhBGcxoNhqydLImFVBJvAZJgSfDwEJuVxovSvZhvwJP");
    string ZjbWEJEt = string("TEBfSuttqSoTTwCAHzVKEFecbZqrIpkFVjTfzVjgOIOEBVXsFWAokjRpdDNruHexbkEexwnRmAwkoEGoWVXfZlihtqrwherOOZFuZYYDpWZFeiFTckHRVjkcRAwRmtHpyMhkKeZeXVuMuGWNmKBoEYufmwlSgxbXdulmWfhxVZKcOTkGzhIihLIUZ");
}

bool kzVTUdVnDcyso::wYRxp(string qGsfmXGP, bool swHrQbsqOSthI, int PsRiHxAmZMmJLSY, double wOJzfmAvO)
{
    string dXwAinMvkdvA = string("Mj");
    bool IIOHs = true;
    int RCOozOkqpmVAh = 1440707389;
    string MBTMhhvKzLF = string("VIcLiUJcccukDSZjLflKNokkZzdXFSuXsUJKBDvqWqYYhOpCWLkOJIlGVhnJPXnqudaYDgNofxyFbIznvimBE");
    bool sPkTQbLNSrT = true;
    string gdfKmgAEjZ = string("srkJozEuodliZKQBeHdKXkRPGGTujMbLQwFpCZLweZWTbcLtRYKufnqwNtbXALhMxhCAxrFdXBkyKjeQgCHZqYtryohJUPpZxcektYXijqLSaNbPeAlbwEyynwoxmXPipnDMXPEKQTtFtCNsLl");
    double COZCioxxHlMXEt = -10722.931512684358;
    int qaDQICuIAe = -571213470;

    for (int fhgpFZNlN = 1233848894; fhgpFZNlN > 0; fhgpFZNlN--) {
        continue;
    }

    return sPkTQbLNSrT;
}

int kzVTUdVnDcyso::XPsqgZ(bool WEIMEASRKRYkWxJ)
{
    bool fSsXBqWjDY = true;

    if (WEIMEASRKRYkWxJ == true) {
        for (int lIfXWZ = 1621394228; lIfXWZ > 0; lIfXWZ--) {
            fSsXBqWjDY = fSsXBqWjDY;
        }
    }

    if (WEIMEASRKRYkWxJ == false) {
        for (int qMHpQnmwkBZqY = 135043849; qMHpQnmwkBZqY > 0; qMHpQnmwkBZqY--) {
            WEIMEASRKRYkWxJ = WEIMEASRKRYkWxJ;
            fSsXBqWjDY = fSsXBqWjDY;
            fSsXBqWjDY = fSsXBqWjDY;
            fSsXBqWjDY = ! WEIMEASRKRYkWxJ;
        }
    }

    if (WEIMEASRKRYkWxJ != true) {
        for (int upJWTNSRaoEWQRY = 63820084; upJWTNSRaoEWQRY > 0; upJWTNSRaoEWQRY--) {
            fSsXBqWjDY = fSsXBqWjDY;
            fSsXBqWjDY = WEIMEASRKRYkWxJ;
            WEIMEASRKRYkWxJ = fSsXBqWjDY;
            fSsXBqWjDY = WEIMEASRKRYkWxJ;
            WEIMEASRKRYkWxJ = ! fSsXBqWjDY;
            fSsXBqWjDY = fSsXBqWjDY;
            WEIMEASRKRYkWxJ = ! WEIMEASRKRYkWxJ;
            fSsXBqWjDY = fSsXBqWjDY;
            fSsXBqWjDY = ! WEIMEASRKRYkWxJ;
            WEIMEASRKRYkWxJ = ! fSsXBqWjDY;
        }
    }

    return 799124620;
}

void kzVTUdVnDcyso::LGnkqgcUroIz(int UgRkxdYXQCCJ, bool dSYbdM, bool LdEzKpGUZGvxcqdM, string naHmDaQ, bool UJJVZIuakUHY)
{
    bool zVUCJAxYJof = true;
    string DQsDSb = string("rYkMmVrWnpSlFMOXTnUKtGNInIxjhTlFCzVZmNILfSlTyNBzZkYWYwhRgMvMDYjBqGTKZtsaqPNcMxYNxgNtK");
    double rRcDHPlngWyfnv = 316458.4906939428;
    string lJGyyOS = string("lCTRYiRuwvjropKoRyqsxdWWVjwYKvyjQSeoDICPqIBacnSIAdZksnlFmIxQNaOgDXdHBVhNnDOtLVtywkEdJyKxKliCUZXOZxRVOsUJtsAltqDDUNUepUDTNWExMLizVoAFGvmyobOPbnDJLIiNymIOpgUdMrBkBQKQnKNLjAgSClrzhohNpTGFLXHylmVhnXBxcMOPxVzUMwmCLdkKUGBhdqChUTqcaJDHkJgzXTIDcchA");

    for (int EdIjsVfnMm = 1952035787; EdIjsVfnMm > 0; EdIjsVfnMm--) {
        zVUCJAxYJof = zVUCJAxYJof;
        rRcDHPlngWyfnv -= rRcDHPlngWyfnv;
    }

    for (int NyfgLJOVQGfwPq = 1186330080; NyfgLJOVQGfwPq > 0; NyfgLJOVQGfwPq--) {
        rRcDHPlngWyfnv = rRcDHPlngWyfnv;
        LdEzKpGUZGvxcqdM = LdEzKpGUZGvxcqdM;
        UJJVZIuakUHY = ! zVUCJAxYJof;
    }

    if (LdEzKpGUZGvxcqdM == true) {
        for (int wEADoOrOrHiJ = 1879081325; wEADoOrOrHiJ > 0; wEADoOrOrHiJ--) {
            continue;
        }
    }

    for (int UNznCBkPy = 1714594195; UNznCBkPy > 0; UNznCBkPy--) {
        LdEzKpGUZGvxcqdM = dSYbdM;
        zVUCJAxYJof = ! zVUCJAxYJof;
        LdEzKpGUZGvxcqdM = dSYbdM;
    }

    for (int KfazG = 1317893848; KfazG > 0; KfazG--) {
        LdEzKpGUZGvxcqdM = ! UJJVZIuakUHY;
    }

    if (DQsDSb >= string("rYkMmVrWnpSlFMOXTnUKtGNInIxjhTlFCzVZmNILfSlTyNBzZkYWYwhRgMvMDYjBqGTKZtsaqPNcMxYNxgNtK")) {
        for (int eLgtUlwSTg = 576411044; eLgtUlwSTg > 0; eLgtUlwSTg--) {
            DQsDSb += DQsDSb;
            dSYbdM = LdEzKpGUZGvxcqdM;
        }
    }
}

kzVTUdVnDcyso::kzVTUdVnDcyso()
{
    this->SvWVUTwOoxxRei(string("qXEJhSsVNryVMsreZoRiobUTTVnJnsPjEdLzGFvGZMqZTaINOyklQMhLAnsNMAyMGUbnYhjIJdMpmWEwKZsLxtYsVdkZFlGEsYKgwPVCACpxraKXuVMUCXWDdhjPIIpQnYwsxGDSRyyrNdCnVrrHiWocMSsAFwOlvCNwNxCBpuNiTsWxLiGLJpbLPWcNPOWAWrbyFicZmysZLCNpVNTwxvGUOIOIOacAIvQphcg"), true, string("zzYrvFilAZPUqRvuDqEUgSnqDYjDcRZfFfZPqaUlmndjAuFPCUpQBbcwlkWTxRPBWwTvzfOFbaXr"));
    this->sjhHzNN(string("uPeCIQlxNMpMHWbxsptCXXCUPEkrJSTSbNXNyVYyhzSVoSmQZOCLxVPeMrKlWrktuxWBGArjnEZFkmYmyVkntuQzzvpTdobCELbToUKdjcvDLPOfartBMmBsCBdZmPmpSopQQFiah"), 243304.6796567865, string("FPjetmDCcjWcrNNBPPtJOvOEsgjNRxdBgvKhwtTZLUqPzQKzNRQgBJeUDeyVcmxIasLRdblFJIDZWWDmGQrHqfDUKPMdMuw"), 69984.54603013118, 77189872);
    this->edXxrnrTg(1679152688, 997420.7785775078);
    this->nYyfTnWg(-837483.9109955343, 365585.8598004709);
    this->mhpzc(false, -1478192893, true, -768119089);
    this->qXaBqAhn(string("owLkhgppPCEaQakGJMNSWbPcOybRAZEpaNCdtWCZCYdiUpogwBqhNGwNKkeDMwymxcTyHODjqHfrfBZlSNNJZmmgGkcLPcrpKSJpisKNS"), 769424224);
    this->yGCqUQcodFcwMX(983370.9969379643);
    this->HXZEQEJbCFAgmfkx(-999596553);
    this->UjzWI(-343462.46114964987, false, string("yjZjUOuHIHHfRRMaUrczTHDMKhnqMzqlXoekKbZAtSHEzsyeEkszHtYYvsETqxMnrgYzpOyiRScvutidsMIVLJnQnhDTUbFBhQnwnVsvwMrdmZtxjGSYgpLzdxXVQsDHLIuqjmFFuCiIRZbTngiyozfRCFVaGAxTtvuBbltDEApqQkHaNzAmAZbmArUgGgoQqQjHADWbvHbaGXidWalfNQKBdHIYwQeTPuTcT"), string("iLinyqtmnaThmPOacSRvIoTTrwjyWuRyEbSLWSxHaeFVxLnYeyZgMFBxtMLcPrLNpvjwDeoWcjHpxVZeYsDXvmBZQuFoqqqnKvALRnBnoWBzevlYcoXaPcFCscjqKapcAoeJdcMtRKVIQHCOvzpukbaibfBmoEUmxdPVkfbgmqOcBuNyzBWbqYQYHfsQSEQEhfy"), string("lXGOBinONBmEyfSttOsUiCYOgNFjdpMRISIijkZpMrFFKJZqIHZbiHwTzYWUDUITgTXrztZVkmtNfiKOPDhyrtDVYSZWbIqbIMowHMIayhxkLksafuXdUgzYDvbXyHnlSveNBriscOlgpzFXecJJmDEdSYWBTOEdGDfFiseyVpOvSdFGRihFqjpdwqKLhwbqnRcxoOL"));
    this->wYRxp(string("TBcsNTEQLNhHphZtsjCajHVEeNNZTLKpHaAURmaQNidXxeKsikmUkwfGfmUwiOaONxSdwWpjHeprzIIdfbBDQitogVbSnGcjwszSzMmGKHizPIuchMdIyLXvoNxBgEMbgjLCZEvXzVnpHRTMtlhChyqgaQEmhUwmpJJYGqDSNiKvyNVHcTkCAF"), false, -838783410, 214058.84800552737);
    this->XPsqgZ(false);
    this->LGnkqgcUroIz(1030944331, false, true, string("szvLZRjIJJBDcqnMRNXNNbldSFkIvBHDbwLYbgkhrwcIjcjpGZMoKJkNPFJPhqELCweozKxQqJYvmSzSzmsCpVJfeKXCpCpwKnUcnchQhlONdyj"), false);
}
