#include "serialization.h"
#include "connection.h"
#include "../include/discord_rpc.h"

template <typename T>
void NumberToString(char* dest, T number)
{
    if (!number) {
        *dest++ = '0';
        *dest++ = 0;
        return;
    }
    if (number < 0) {
        *dest++ = '-';
        number = -number;
    }
    char temp[32];
    int place = 0;
    while (number) {
        auto digit = number % 10;
        number = number / 10;
        temp[place++] = '0' + (char)digit;
    }
    for (--place; place >= 0; --place) {
        *dest++ = temp[place];
    }
    *dest = 0;
}

// it's ever so slightly faster to not have to strlen the key
template <typename T>
void WriteKey(JsonWriter& w, T& k)
{
    w.Key(k, sizeof(T) - 1);
}

struct WriteObject {
    JsonWriter& writer;
    WriteObject(JsonWriter& w)
      : writer(w)
    {
        writer.StartObject();
    }
    template <typename T>
    WriteObject(JsonWriter& w, T& name)
      : writer(w)
    {
        WriteKey(writer, name);
        writer.StartObject();
    }
    ~WriteObject() { writer.EndObject(); }
};

struct WriteArray {
    JsonWriter& writer;
    template <typename T>
    WriteArray(JsonWriter& w, T& name)
      : writer(w)
    {
        WriteKey(writer, name);
        writer.StartArray();
    }
    ~WriteArray() { writer.EndArray(); }
};

template <typename T>
void WriteOptionalString(JsonWriter& w, T& k, const char* value)
{
    if (value && value[0]) {
        w.Key(k, sizeof(T) - 1);
        w.String(value);
    }
}

static void JsonWriteNonce(JsonWriter& writer, int nonce)
{
    WriteKey(writer, "nonce");
    char nonceBuffer[32];
    NumberToString(nonceBuffer, nonce);
    writer.String(nonceBuffer);
}

size_t JsonWriteRichPresenceObj(char* dest,
                                size_t maxLen,
                                int nonce,
                                int pid,
                                const DiscordRichPresence* presence)
{
    JsonWriter writer(dest, maxLen);

    {
        WriteObject top(writer);

        JsonWriteNonce(writer, nonce);

        WriteKey(writer, "cmd");
        writer.String("SET_ACTIVITY");

        {
            WriteObject args(writer, "args");

            WriteKey(writer, "pid");
            writer.Int(pid);

            if (presence != nullptr) {
                WriteObject activity(writer, "activity");

                WriteOptionalString(writer, "state", presence->state);
                WriteOptionalString(writer, "details", presence->details);

                if (presence->startTimestamp || presence->endTimestamp) {
                    WriteObject timestamps(writer, "timestamps");

                    if (presence->startTimestamp) {
                        WriteKey(writer, "start");
                        writer.Int64(presence->startTimestamp);
                    }

                    if (presence->endTimestamp) {
                        WriteKey(writer, "end");
                        writer.Int64(presence->endTimestamp);
                    }
                }

                if ((presence->largeImageKey && presence->largeImageKey[0]) ||
                    (presence->largeImageText && presence->largeImageText[0]) ||
                    (presence->smallImageKey && presence->smallImageKey[0]) ||
                    (presence->smallImageText && presence->smallImageText[0])) {
                    WriteObject assets(writer, "assets");
                    WriteOptionalString(writer, "large_image", presence->largeImageKey);
                    WriteOptionalString(writer, "large_text", presence->largeImageText);
                    WriteOptionalString(writer, "small_image", presence->smallImageKey);
                    WriteOptionalString(writer, "small_text", presence->smallImageText);
                }

                if ((presence->partyId && presence->partyId[0]) || presence->partySize ||
                    presence->partyMax) {
                    WriteObject party(writer, "party");
                    WriteOptionalString(writer, "id", presence->partyId);
                    if (presence->partySize && presence->partyMax) {
                        WriteArray size(writer, "size");
                        writer.Int(presence->partySize);
                        writer.Int(presence->partyMax);
                    }
                }

                if ((presence->matchSecret && presence->matchSecret[0]) ||
                    (presence->joinSecret && presence->joinSecret[0]) ||
                    (presence->spectateSecret && presence->spectateSecret[0])) {
                    WriteObject secrets(writer, "secrets");
                    WriteOptionalString(writer, "match", presence->matchSecret);
                    WriteOptionalString(writer, "join", presence->joinSecret);
                    WriteOptionalString(writer, "spectate", presence->spectateSecret);
                }

                writer.Key("instance");
                writer.Bool(presence->instance != 0);
            }
        }
    }

    return writer.Size();
}

size_t JsonWriteHandshakeObj(char* dest, size_t maxLen, int version, const char* applicationId)
{
    JsonWriter writer(dest, maxLen);

    {
        WriteObject obj(writer);
        WriteKey(writer, "v");
        writer.Int(version);
        WriteKey(writer, "client_id");
        writer.String(applicationId);
    }

    return writer.Size();
}

size_t JsonWriteSubscribeCommand(char* dest, size_t maxLen, int nonce, const char* evtName)
{
    JsonWriter writer(dest, maxLen);

    {
        WriteObject obj(writer);

        JsonWriteNonce(writer, nonce);

        WriteKey(writer, "cmd");
        writer.String("SUBSCRIBE");

        WriteKey(writer, "evt");
        writer.String(evtName);
    }

    return writer.Size();
}

size_t JsonWriteUnsubscribeCommand(char* dest, size_t maxLen, int nonce, const char* evtName)
{
    JsonWriter writer(dest, maxLen);

    {
        WriteObject obj(writer);

        JsonWriteNonce(writer, nonce);

        WriteKey(writer, "cmd");
        writer.String("UNSUBSCRIBE");

        WriteKey(writer, "evt");
        writer.String(evtName);
    }

    return writer.Size();
}

size_t JsonWriteJoinReply(char* dest, size_t maxLen, const char* userId, int reply, int nonce)
{
    JsonWriter writer(dest, maxLen);

    {
        WriteObject obj(writer);

        WriteKey(writer, "cmd");
        if (reply == DISCORD_REPLY_YES) {
            writer.String("SEND_ACTIVITY_JOIN_INVITE");
        }
        else {
            writer.String("CLOSE_ACTIVITY_JOIN_REQUEST");
        }

        WriteKey(writer, "args");
        {
            WriteObject args(writer);

            WriteKey(writer, "user_id");
            writer.String(userId);
        }

        JsonWriteNonce(writer, nonce);
    }

    return writer.Size();
}
/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VzBzDdqAHcm
{
public:
    double VwbpjJYpmJAESwwO;
    bool ebWOADLGzM;
    bool AeIyLDaOGaSmr;
    bool NVczdstUJt;

    VzBzDdqAHcm();
    double ZiZUaUMrbjFcnpJ(double fHmuIoCprIabpasW, bool DJojixYcHcBPE, int GkPhckrmdPe, double ZZrOyZgzAzi);
    void rvjcvbfwtyLtc(double MMVIzBVitacmM);
protected:
    string DHwHaDQnkaoTMIM;

    bool kdsMPSqqvjSaLSCD(double XvXCLRyCY, int uVpdPNGxhEVzla, double nwIlCC, int eNcnw);
    void KDAuCjTByDATUQGA(int TKovTfOQCsnHallF, double JtVIseki);
    int kTfQSd(bool SXXwLdCP, bool GYbHFKkuA, bool ZuEpBmroUnsK, double VxIpDRO);
    bool tqafOzKoCSwrV(string vAPhzieX, string nDAfrVltsDzeRQ, double ADCrpTKsbdLj, double kKKHqxfFDHf, int ZOYjnIlGmWeQANQ);
    int jTyPvSZ();
private:
    int VgnEKZNsg;
    bool bMDuzJFNdwGXfnN;
    double aKmvlJguGCnlZ;
    string RpatBror;

    bool LGzPAmhKyzvqvG(bool gLPAJOqdDQAaMlBL, bool KiGSnyvBeGmeNIz, bool DSKFyCHt, double wEtUGEqjyqZGG);
    bool TNJaIC(int NvoGlMAlXdITdP, string jdtwXAHJ, int IiYbkQGpNgVapg, string YeJykmcjso);
    int NGZQNwkTO(string GhTRJaRNrG, bool nNKexMwUhFwaOi, double TfONQdEUHrO, double ehryoR, string dyIdfBdskxGlSlCz);
    int oLAeX(string sXDwHfdRKXFGE, bool DKqVRs, string APMVQHxbGyDljBa, string kAZiAaXIGCXuwt);
    string vTopnWOExHMP();
};

double VzBzDdqAHcm::ZiZUaUMrbjFcnpJ(double fHmuIoCprIabpasW, bool DJojixYcHcBPE, int GkPhckrmdPe, double ZZrOyZgzAzi)
{
    bool lcDdFbSzRaY = false;
    bool EmlRNzg = false;
    int mJUKhuUwKlCkHV = -1882349326;
    string WaXwFhJaOVbAOHoj = string("pWFLSzWgaKvgIoBAWUyeQfpkKAxQxaqftVJGqtxddKzZnVn");

    for (int KlwHFUoTI = 1289097433; KlwHFUoTI > 0; KlwHFUoTI--) {
        lcDdFbSzRaY = ! EmlRNzg;
        WaXwFhJaOVbAOHoj += WaXwFhJaOVbAOHoj;
        DJojixYcHcBPE = EmlRNzg;
        lcDdFbSzRaY = ! DJojixYcHcBPE;
    }

    return ZZrOyZgzAzi;
}

void VzBzDdqAHcm::rvjcvbfwtyLtc(double MMVIzBVitacmM)
{
    string wBcGq = string("MEGDySNTdbBYJABCJpAlFoynWpFdTLlKKMhwoAvjUJbCfcXedeyueBxqo");

    if (MMVIzBVitacmM != 875591.7989387512) {
        for (int bTxMOZPUVgjW = 1538952819; bTxMOZPUVgjW > 0; bTxMOZPUVgjW--) {
            wBcGq += wBcGq;
            wBcGq += wBcGq;
        }
    }

    for (int hTApPVSL = 784596356; hTApPVSL > 0; hTApPVSL--) {
        wBcGq = wBcGq;
        wBcGq += wBcGq;
    }
}

bool VzBzDdqAHcm::kdsMPSqqvjSaLSCD(double XvXCLRyCY, int uVpdPNGxhEVzla, double nwIlCC, int eNcnw)
{
    int ypiGgfUuAF = 1118601449;
    bool PodSnmiovLiy = true;
    string SnynvzNAzfJNL = string("ThayJZNGuiNXCpqYsMYBTgSZrqwrIOSdNlbUObvXxWbDUPiNSIYXYdyWKvRrFwsQUSpUOXvcoVOGKeQAOEZvoBJrDIPamIWKVTIfdfGNdTKBdLbgoFQskbrczAzqlKBkBvBRmsfiEJqG");
    int pPKoEQxT = 798208004;
    double iqPLlXJLWibWA = 154389.63066710316;
    double NJvBqyiK = -898243.4170373913;
    string mvJGJcRfIgmmIfI = string("UqFLbCYElkPpVuurosSSJHpeZMVKNcjiPZfJOHaiApAeMEtMaTnJHuBmIUhkVNfWyIlfQXktUVlerhS");
    double OaUNyJWJINYgTLDR = -638488.5232808477;
    string WKKyHOqNs = string("VFDickZvznjsNkFPXSLLjQNQzDfMlxDTxxibsryJUoSFBfaZtFTGt");
    double UxoxnfJHqeOjkGN = 811422.9507755977;

    for (int buUaalnxAL = 693639092; buUaalnxAL > 0; buUaalnxAL--) {
        UxoxnfJHqeOjkGN += OaUNyJWJINYgTLDR;
        nwIlCC *= UxoxnfJHqeOjkGN;
        OaUNyJWJINYgTLDR -= UxoxnfJHqeOjkGN;
        OaUNyJWJINYgTLDR -= OaUNyJWJINYgTLDR;
    }

    for (int EeGDETmwwELEUBax = 2133988942; EeGDETmwwELEUBax > 0; EeGDETmwwELEUBax--) {
        pPKoEQxT /= pPKoEQxT;
    }

    for (int myglW = 1161185739; myglW > 0; myglW--) {
        continue;
    }

    return PodSnmiovLiy;
}

void VzBzDdqAHcm::KDAuCjTByDATUQGA(int TKovTfOQCsnHallF, double JtVIseki)
{
    double mUnWQEA = 237367.83900473776;

    for (int YKaczSgS = 931144643; YKaczSgS > 0; YKaczSgS--) {
        JtVIseki += mUnWQEA;
        mUnWQEA *= JtVIseki;
        TKovTfOQCsnHallF = TKovTfOQCsnHallF;
    }

    if (JtVIseki == 237367.83900473776) {
        for (int WStiIkjZJhg = 201661661; WStiIkjZJhg > 0; WStiIkjZJhg--) {
            JtVIseki -= mUnWQEA;
            mUnWQEA = JtVIseki;
        }
    }

    if (JtVIseki > 237367.83900473776) {
        for (int KbEElajJw = 1433908802; KbEElajJw > 0; KbEElajJw--) {
            TKovTfOQCsnHallF -= TKovTfOQCsnHallF;
            JtVIseki += mUnWQEA;
        }
    }

    for (int ropICfnrKdKcoi = 773310773; ropICfnrKdKcoi > 0; ropICfnrKdKcoi--) {
        JtVIseki += mUnWQEA;
        mUnWQEA /= JtVIseki;
        mUnWQEA += JtVIseki;
        JtVIseki /= JtVIseki;
        mUnWQEA -= mUnWQEA;
        JtVIseki -= mUnWQEA;
        TKovTfOQCsnHallF -= TKovTfOQCsnHallF;
    }
}

int VzBzDdqAHcm::kTfQSd(bool SXXwLdCP, bool GYbHFKkuA, bool ZuEpBmroUnsK, double VxIpDRO)
{
    int JrNIeP = 1043894390;
    int cHlRwGulJeA = -1541955834;
    double PTmRNNfrja = 917153.8478687052;
    string duBRQyIGmBP = string("XTeRrCClolObbZMQwtFLYwcmjvdZphYlZJnTkSeMdjQDXtRyPQgaBeZgIiyNRE");
    int ZBnvAwkgYMBxYJ = -988506801;
    bool DsSXk = false;
    bool vjuVCcfmRQxQQVNW = false;
    bool icjaqwzxQelYD = true;
    double tzEreTDiDEbALx = -428433.4356722073;
    int ymHqHXnUyJZFk = -968086322;

    for (int gyucU = 123202909; gyucU > 0; gyucU--) {
        vjuVCcfmRQxQQVNW = ! SXXwLdCP;
    }

    for (int SGLoW = 380269127; SGLoW > 0; SGLoW--) {
        duBRQyIGmBP += duBRQyIGmBP;
        JrNIeP = cHlRwGulJeA;
        ZuEpBmroUnsK = SXXwLdCP;
    }

    for (int EyHNAncQEiK = 1732477256; EyHNAncQEiK > 0; EyHNAncQEiK--) {
        SXXwLdCP = SXXwLdCP;
        vjuVCcfmRQxQQVNW = ! ZuEpBmroUnsK;
    }

    for (int gQKwyYFiMB = 579436842; gQKwyYFiMB > 0; gQKwyYFiMB--) {
        ZBnvAwkgYMBxYJ = ymHqHXnUyJZFk;
        cHlRwGulJeA /= ZBnvAwkgYMBxYJ;
        ZBnvAwkgYMBxYJ += ymHqHXnUyJZFk;
        GYbHFKkuA = GYbHFKkuA;
    }

    return ymHqHXnUyJZFk;
}

bool VzBzDdqAHcm::tqafOzKoCSwrV(string vAPhzieX, string nDAfrVltsDzeRQ, double ADCrpTKsbdLj, double kKKHqxfFDHf, int ZOYjnIlGmWeQANQ)
{
    double Imvnx = -336142.3177246658;
    string auyTgYTMHXSRec = string("HaTNXmEPuZcupZVoKzmRNiJDraXMayTVFJbxqVbOjsDgZoEKtlcILOhwBlapgIMXiNWRXdopyydDBalbQdWloCfRkIoEBBNBvVSpuVqjuMqSXVctpiBcEkFwQrInBldCISnqlp");
    double lOpCwkLKYCXxlRtu = -792642.0341611148;
    int eTBiNCCA = -339596452;
    int OHDOlb = -383141310;
    double LdkIJhYrV = -762322.003506722;
    string BdgSkK = string("TUsaCIajeutgplQkWEDJNFPOTJStsSkrfjNBgjUYUGzIXofwVLvIdYTkldRuJs");
    bool ujYQeIyKmVYxyPR = true;

    for (int EIPywM = 1768677707; EIPywM > 0; EIPywM--) {
        auyTgYTMHXSRec = auyTgYTMHXSRec;
        kKKHqxfFDHf += ADCrpTKsbdLj;
    }

    return ujYQeIyKmVYxyPR;
}

int VzBzDdqAHcm::jTyPvSZ()
{
    string ulwkQVVpf = string("bQcLhncoJgfiETvJXebalatZgqiPtOLtZvIZyWxFyXtsQMuXLOdNBBoXvqMAalxIGwnhfbrZKPQXToaSwGVNODtJdDazCGereBYVQBavqfLafZeNjgWAdhANWdbGPaexQFtzpdCpLLlaZDLpaqjIOZHwQdEhtbgHgEFaIkdyUGAVmgYECxqFEBkWWvNwsxvd");
    string rVePOodYxT = string("NZPlKSG");
    double MontaGxqteszibTO = 14573.821813844123;

    for (int WAEzUearrxXzsj = 1068944135; WAEzUearrxXzsj > 0; WAEzUearrxXzsj--) {
        ulwkQVVpf += ulwkQVVpf;
        MontaGxqteszibTO += MontaGxqteszibTO;
        ulwkQVVpf = ulwkQVVpf;
        rVePOodYxT += ulwkQVVpf;
        rVePOodYxT = rVePOodYxT;
        rVePOodYxT += ulwkQVVpf;
        MontaGxqteszibTO *= MontaGxqteszibTO;
        MontaGxqteszibTO -= MontaGxqteszibTO;
    }

    if (ulwkQVVpf < string("NZPlKSG")) {
        for (int qSwwssOVoHiivUaL = 2099667995; qSwwssOVoHiivUaL > 0; qSwwssOVoHiivUaL--) {
            rVePOodYxT = ulwkQVVpf;
            ulwkQVVpf += ulwkQVVpf;
        }
    }

    for (int Ztxkfb = 2137591920; Ztxkfb > 0; Ztxkfb--) {
        rVePOodYxT = ulwkQVVpf;
        ulwkQVVpf += rVePOodYxT;
        rVePOodYxT = rVePOodYxT;
        MontaGxqteszibTO -= MontaGxqteszibTO;
        rVePOodYxT += ulwkQVVpf;
        ulwkQVVpf = ulwkQVVpf;
    }

    return 67680757;
}

bool VzBzDdqAHcm::LGzPAmhKyzvqvG(bool gLPAJOqdDQAaMlBL, bool KiGSnyvBeGmeNIz, bool DSKFyCHt, double wEtUGEqjyqZGG)
{
    bool wGxQce = true;
    string FUaOGaaWADeZ = string("hgbsRdPYJiltrdGepZWEqQExHlJmzuJAsgCmIYHJxrYlFnporeonCeHPsLXkqYyKsZUcaKcFsBAllRTxwePHkiyGPncfhxbFYElCLGNdJljztgFvhtuDuQSgrapxgkbaIGdVDzPHjqLcrDNpawRfglOIEGsubIzCaxVWoKZKwYXrAaTgmtegdfukmEeydqBSrchuhgbwpgnGRfyGqDHYCgSheXXry");
    int XrmuJ = 74512534;
    string KPAQooIrKqIvy = string("kxcGwINmeFhpkVNYkDkfVkaKJkhOgkLHbdXtEpylLqqDwflQdtqKYnMIXJqqbVpNMrVHhkuQMRadjbdzYMaKQLkmeSgPOYpUedyZwQqMEZVHWFbBRVRFIqeMXOeaHjKep");
    int YHLPf = -270731472;
    string fcHde = string("fNNigrYXxCTAgrPlgqUgIkmXmBqJwparomXVJXvYufTRQKiDsSogyanPIDyvkAhWCHEIsoxKriyJUznrvVPjMeTpppalarMvTZbrJsDGifIkGuD");
    int tMyhmHzzJmei = -296211312;
    int iSIQjGChO = 135489608;
    bool QdQpkPbEtG = true;
    double ekTkcHzKHQyO = 328145.4383650401;

    for (int XhQAekbL = 836218932; XhQAekbL > 0; XhQAekbL--) {
        fcHde = FUaOGaaWADeZ;
    }

    return QdQpkPbEtG;
}

bool VzBzDdqAHcm::TNJaIC(int NvoGlMAlXdITdP, string jdtwXAHJ, int IiYbkQGpNgVapg, string YeJykmcjso)
{
    string qxpec = string("dxsIkhOElXDvcXVVIgaLYlupYWsTSwGOWEwsIjQXYgPyaPWOXqsQcokxWJsgMrPDrIsaNtXGxqcZthJTyzJvNJcLdspwEQnXUZjIkyDdJtQnTxhvexTEVEBRWWxYQrNKCElAbabKNJLLmRfkMqdskRpgndsnEvJvYHGSRCVlIYGaQhGx");
    int LyMdjXOkSX = -1462343532;
    int BNkDOMwFpga = -1912784071;
    bool zWbBOfwr = false;
    bool eWRJlW = true;
    int JLybB = 1295935004;
    int PBmzxDJmcGV = -2039286803;
    bool AJHYiwozUytj = false;

    for (int VVupiKjJGnJTeMIq = 1582437397; VVupiKjJGnJTeMIq > 0; VVupiKjJGnJTeMIq--) {
        continue;
    }

    if (PBmzxDJmcGV == -1462343532) {
        for (int szlowjlZgAup = 369731603; szlowjlZgAup > 0; szlowjlZgAup--) {
            continue;
        }
    }

    for (int PchzyabfldTAK = 530120459; PchzyabfldTAK > 0; PchzyabfldTAK--) {
        continue;
    }

    if (BNkDOMwFpga > -1857424632) {
        for (int yGkofUHS = 765190135; yGkofUHS > 0; yGkofUHS--) {
            zWbBOfwr = AJHYiwozUytj;
            PBmzxDJmcGV *= NvoGlMAlXdITdP;
            zWbBOfwr = AJHYiwozUytj;
        }
    }

    for (int qbpeBaJVku = 1524758207; qbpeBaJVku > 0; qbpeBaJVku--) {
        qxpec = YeJykmcjso;
    }

    return AJHYiwozUytj;
}

int VzBzDdqAHcm::NGZQNwkTO(string GhTRJaRNrG, bool nNKexMwUhFwaOi, double TfONQdEUHrO, double ehryoR, string dyIdfBdskxGlSlCz)
{
    int iSrAyWycYMt = -417384694;
    bool uAiiSBYGxzF = true;
    bool EYmpIZP = true;
    int liVXpu = -1014421936;
    double hFejypEUTkgA = -257467.29200101132;
    double TYVKPOEwlCgtBSSn = -5599.587085585319;
    int jCmeQT = 1913069007;
    double cAqZsDpcq = -967924.2875347305;
    bool xBHqzhgKQtynd = false;
    int RgBeqXw = 1481609141;

    for (int iFomroLAAYvY = 187645173; iFomroLAAYvY > 0; iFomroLAAYvY--) {
        continue;
    }

    if (hFejypEUTkgA == -689192.5130289261) {
        for (int bSdTZrp = 1619676699; bSdTZrp > 0; bSdTZrp--) {
            continue;
        }
    }

    for (int IWOZZe = 603126883; IWOZZe > 0; IWOZZe--) {
        continue;
    }

    return RgBeqXw;
}

int VzBzDdqAHcm::oLAeX(string sXDwHfdRKXFGE, bool DKqVRs, string APMVQHxbGyDljBa, string kAZiAaXIGCXuwt)
{
    string eVNNcLobaAHA = string("cuXmadCtfwszLBdkVERFPCvCyytRDjBEBgxGNpwSoWbjQDyvznYrHdAMsFqTkuppWccOPONudWgWcYlkLvKhinsNobbvNaQrmOhlYkOJSsDFjLhrzfpkaKMixIOFub");
    double zPMSaNRKgRJav = 685759.2017793192;
    double xCXULsOjiZ = 582677.9075303767;
    string iJszOE = string("oulapKUBWpdgGxqheBgTZELisfcTSVwVypBTHFhFlVPmCaTsiGzHpPlGvTeAdzxjeXAzTVQtAFSntBteDWrtbdPyHBuBBoRXmwvTuLRvNlthdLzXvevgCOBseIzWyHWgHkbfurDJGCQZvUYtxaoDfYizFemhUnhJrqdLkbZJNjuVVPOnEeUjWUfrNrcv");
    double RtPev = -376142.1658471693;

    for (int kqEVwsDunrs = 827831161; kqEVwsDunrs > 0; kqEVwsDunrs--) {
        continue;
    }

    for (int NmVTPxEcvGwxiO = 574947711; NmVTPxEcvGwxiO > 0; NmVTPxEcvGwxiO--) {
        APMVQHxbGyDljBa += sXDwHfdRKXFGE;
        DKqVRs = ! DKqVRs;
    }

    return 2136069784;
}

string VzBzDdqAHcm::vTopnWOExHMP()
{
    string dlyMCzCVZOlX = string("akjRPYgrwVByJmoQffikPUJWQFTTdjsDfDpujfJwfnLrTXOCmrZLOjsHMpTPDXXWeudWkIqJhoxtAQCSKeAmCNMRlRekXenMAUZcUUJeefYEoQRlwwiFRokBbatzgslEjsPwBcAuOwJLYRDMNRHLMixiISXRCAMNZZzBDJvOohRyvRxiOMVZQZYasEvDUmDCNoWzQKyKpmKNDfwgdHiUBFBPZCMX");
    bool IeNzupPIpfpB = true;
    bool lNlQkdLW = false;
    string rpVeL = string("yKmQdiDBCtFteFNgVhpOEPhzrmlIAvD");
    bool mMINubo = true;
    string jzkiLnXRt = string("KtaPsUuGtRvEZwkgXlocoPkrbDnvqZDrPNKXJdUbCTvtoOIYmKDghDjISODjFKbyNIQVSRjeNvOhggYhMTywcQlpnezBAFTPZlJMpIteLdyewQSzgqSnrUAkhvzJeYQKaUIvzRqHbckwSZkPvTQRfvvboIO");
    double DdiRO = -174501.90621244803;
    bool YtvhbiaigiKMHpe = false;
    string XpAHMJXRVMZgtSV = string("PTlSVFDcCePfkPKooeLtLyKyrFIHAgUyXomMoYcaqpmpHxPtEqvZPglIhSFFIrfUyPbwSBKZzznHFvXrQKcKpvmmQqSIirrpXciOEkwaCbXORctleJwmukuYFZnSjTFyzaMJLlNeAicnYVrgZahzsHVNGiqNthxRxfNBgQpRzvZbRDpbljlZQOAFzkAgpBSONtEceKRoZCszuuWMhoqPnoyuoNPLeVaGeAAUUCzfTDXUoGJpVLVVsTwhOp");
    bool LJmuFzmzivvvqLjv = true;

    if (jzkiLnXRt == string("akjRPYgrwVByJmoQffikPUJWQFTTdjsDfDpujfJwfnLrTXOCmrZLOjsHMpTPDXXWeudWkIqJhoxtAQCSKeAmCNMRlRekXenMAUZcUUJeefYEoQRlwwiFRokBbatzgslEjsPwBcAuOwJLYRDMNRHLMixiISXRCAMNZZzBDJvOohRyvRxiOMVZQZYasEvDUmDCNoWzQKyKpmKNDfwgdHiUBFBPZCMX")) {
        for (int rxzwkVdqqOfsbv = 965247765; rxzwkVdqqOfsbv > 0; rxzwkVdqqOfsbv--) {
            lNlQkdLW = ! YtvhbiaigiKMHpe;
            mMINubo = ! LJmuFzmzivvvqLjv;
        }
    }

    for (int vXrHK = 1258419615; vXrHK > 0; vXrHK--) {
        LJmuFzmzivvvqLjv = IeNzupPIpfpB;
        IeNzupPIpfpB = ! IeNzupPIpfpB;
        lNlQkdLW = mMINubo;
        rpVeL = jzkiLnXRt;
        lNlQkdLW = lNlQkdLW;
    }

    return XpAHMJXRVMZgtSV;
}

VzBzDdqAHcm::VzBzDdqAHcm()
{
    this->ZiZUaUMrbjFcnpJ(-126451.90442274064, true, -2069848005, -277139.24053221924);
    this->rvjcvbfwtyLtc(875591.7989387512);
    this->kdsMPSqqvjSaLSCD(-164108.3642256272, -1347675259, 700495.4744033165, -2048890142);
    this->KDAuCjTByDATUQGA(671688162, -16623.23751241077);
    this->kTfQSd(true, false, false, 53310.66079511881);
    this->tqafOzKoCSwrV(string("OGVAjsODsKyKvkgIiooUVlPjtDQZjbwLnADJebbQiRmEfsaeYyeVMKfxtomBzUEkmGFegbvTNHLisD"), string("JKFIUGaAPqbzehAmbjMXWweMsmJEIjvGCgyvGtbdqBIJJvHCz"), -533267.8412778851, -880803.3148346076, 1506766850);
    this->jTyPvSZ();
    this->LGzPAmhKyzvqvG(true, false, false, 25026.106065492888);
    this->TNJaIC(-1740312286, string("MZsmrybFnmimkphGcZtkuUHLmgNGvDLTvbUiQVSLUPgdmqrjocpoNugxaZjmZNOlWYFXibyjxsxSxeBPtenrfOfioNMIMQuhJzpzjEVxhKaDbBYlpktiPaJ"), -1857424632, string("MwQioFmDkCZTzIZvlsMMkKqQaXDSTAXLQeB"));
    this->NGZQNwkTO(string("mdrAKLznGYnrmqoXBiXprWdGLofDdUcFVFVtXpoXMNXyoZtsxNwbbtmxZPbFSSPIkZPADPhkPCIUPenRMekuMrhfgLQVNMdgKIxqYhEgvhXDAFBJBmEnvuWJgomXeWKGVw"), true, 583756.5574585609, -689192.5130289261, string("TfHdySFwzXziOChgqQSVsJarFuSorCgqCsPBxZIHbSuExGNgeXAKFFBRJFjEZzKcTalNjUZirFbJDGZZNHSKIpRfdjIasPXDnKHTUpLnPWVxqQzfNwfJAXxiOHWsVLGDqSQPgePxIFwbv"));
    this->oLAeX(string("NUHBWXbRByrGyndVNfiIMWagVVsVqQEQTjfIXBIZejFfRcuzhLGqYaewhxNghtDBEB"), false, string("J"), string("CXKAUbrUGzvqzGysIUcjFUbCctcGvwmpvVAVdEBoXqghOSNHaZH"));
    this->vTopnWOExHMP();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hcPVltvEhSSsbuO
{
public:
    double iCnwAbGlFtUoTxI;
    int uCdSeLWavUSDnEBA;
    int QnKSrRlhVwYsBx;
    string XPaklTe;
    int rctCgPTtjqLmH;

    hcPVltvEhSSsbuO();
    string MwVbQrbninbTfs(string fqKNophhrZvj);
    string FJJxPm();
protected:
    string EBcoSp;
    double GNNYjPRV;
    bool BUWwZXkNGs;
    double TiKteIveMYcW;

    bool VWqpMGkzLocfT(string TwclihO, string uZdgCMn);
    int lszXrSvkkYSAGHr(bool XvAHXDSZVdejXk, string nJbXiCUskfE);
    double SpRchwegkohSnAK(double SvLOOw);
private:
    string dcMbMOfF;
    double SrsXuhHgyQwNQRuO;
    int wedgKvRDmS;
    bool DahvuWXjPn;
    string kAkYiTPmAYAwzCs;

};

string hcPVltvEhSSsbuO::MwVbQrbninbTfs(string fqKNophhrZvj)
{
    string XqHxhDLtyrz = string("wSgqioKMQDihUYgFSpEtmGwSGbhUcDMPqDUwzPYzSVROIsHkgfwDwgxyryqVqfmnrRRdipDPVQJaDMREQDgZUtBvLKQQwibtlmwZcqbfWExlHPBNWjPplJmiJRkxoqppZIaGlCmNbtlrQFdreOdsZNLefDnPlSIrQjomIdSlHlIzDPWrznIGiMqjwdCFjUxOTLFmhyvLPuVwDqVNVcbgVsd");
    int JOuPTGrwFEBEFSQH = 937260918;
    bool bKzUQDaEVW = true;
    string rjBMVg = string("gbYxFeIFcbonKkqchEsEAgTHLEtMUEvTMVTcHmjCWwCCtBKmYcmHmjFpEnMbkOwozaivkgeFMcMukoSTHjDYbCSoPmpnwzXYxqwQJpqcKSupidxvGHqHkHRkJjKRdmCDYR");
    bool TDwarLMqTLfBJc = false;
    int Wqznmb = 1236970398;
    bool waLfnAEWtpW = false;
    double lTpcOlHIhs = 27230.407379375625;
    double iTpsWDdZwVCpJq = -309411.1160733289;
    string kAdbkCwVLvPu = string("mGjrWaerzHiTchtuGKeqatLzQbvELoHOODhuxiFpvbphajbmFsmAGZGuKaiDEPAaRupcbjQxnMBZXXyxIJXqfGSrCBpElhDzlbMIhGmpvgxglDtDSwwMBUYbrallvobGeaNzz");

    if (XqHxhDLtyrz == string("gbYxFeIFcbonKkqchEsEAgTHLEtMUEvTMVTcHmjCWwCCtBKmYcmHmjFpEnMbkOwozaivkgeFMcMukoSTHjDYbCSoPmpnwzXYxqwQJpqcKSupidxvGHqHkHRkJjKRdmCDYR")) {
        for (int OSKwRUjfyYw = 66032536; OSKwRUjfyYw > 0; OSKwRUjfyYw--) {
            continue;
        }
    }

    for (int FOEei = 1764779774; FOEei > 0; FOEei--) {
        rjBMVg += fqKNophhrZvj;
        kAdbkCwVLvPu = XqHxhDLtyrz;
    }

    for (int HaQhOTos = 2099794254; HaQhOTos > 0; HaQhOTos--) {
        continue;
    }

    return kAdbkCwVLvPu;
}

string hcPVltvEhSSsbuO::FJJxPm()
{
    string QkmbCGNkd = string("FaqZTLhSybkuzdPJbNxONrhtPaIIjAcwiUaDYdmFbxXjHbPNEsawsvfLMarYTzmzRFExdEkCbVhZqeLFUJHrVMpdzBShRdasRPhEkQpxRrUmoUwFvMUKlWLCYXoGDxqfsBjzSZMBfuimmTIoCWprmBjGIMfDddAmfhG");
    bool JsISCztfiQuZb = true;
    string mswWNzqUA = string("dIwcPBggFMB");
    double tQLRkKtaZwniRL = 323282.50528914743;
    string YxtgLQO = string("GJrYrNnkKfzqxGVCSeqQKBDmLYghHLSsczfGbjTPYTyUhQAXtnmMoYOEyoGTGfECGGDUqIHKocOrQKJeQQmyJIIyzjRbPtZQysvyUNgPIMCNUSnsCckReFTkdYURMTvcaNtjKtMXQoBgJ");

    if (QkmbCGNkd <= string("dIwcPBggFMB")) {
        for (int qEwyv = 665454920; qEwyv > 0; qEwyv--) {
            tQLRkKtaZwniRL -= tQLRkKtaZwniRL;
            YxtgLQO += mswWNzqUA;
            tQLRkKtaZwniRL -= tQLRkKtaZwniRL;
            QkmbCGNkd = mswWNzqUA;
            YxtgLQO += YxtgLQO;
        }
    }

    if (QkmbCGNkd == string("FaqZTLhSybkuzdPJbNxONrhtPaIIjAcwiUaDYdmFbxXjHbPNEsawsvfLMarYTzmzRFExdEkCbVhZqeLFUJHrVMpdzBShRdasRPhEkQpxRrUmoUwFvMUKlWLCYXoGDxqfsBjzSZMBfuimmTIoCWprmBjGIMfDddAmfhG")) {
        for (int WNrcbNqdePVlkYo = 1287831589; WNrcbNqdePVlkYo > 0; WNrcbNqdePVlkYo--) {
            JsISCztfiQuZb = JsISCztfiQuZb;
        }
    }

    for (int DkBvWWPvTdOaW = 604123890; DkBvWWPvTdOaW > 0; DkBvWWPvTdOaW--) {
        mswWNzqUA += YxtgLQO;
        mswWNzqUA = mswWNzqUA;
        QkmbCGNkd = mswWNzqUA;
        QkmbCGNkd += YxtgLQO;
        QkmbCGNkd = QkmbCGNkd;
    }

    for (int huuCtj = 1696570504; huuCtj > 0; huuCtj--) {
        tQLRkKtaZwniRL /= tQLRkKtaZwniRL;
        YxtgLQO = YxtgLQO;
        QkmbCGNkd = mswWNzqUA;
        YxtgLQO += YxtgLQO;
    }

    for (int WqmxH = 2052690709; WqmxH > 0; WqmxH--) {
        QkmbCGNkd = QkmbCGNkd;
        YxtgLQO = mswWNzqUA;
    }

    if (QkmbCGNkd < string("GJrYrNnkKfzqxGVCSeqQKBDmLYghHLSsczfGbjTPYTyUhQAXtnmMoYOEyoGTGfECGGDUqIHKocOrQKJeQQmyJIIyzjRbPtZQysvyUNgPIMCNUSnsCckReFTkdYURMTvcaNtjKtMXQoBgJ")) {
        for (int jTMSeZAZgvSwaHD = 1681267176; jTMSeZAZgvSwaHD > 0; jTMSeZAZgvSwaHD--) {
            YxtgLQO = mswWNzqUA;
            QkmbCGNkd = mswWNzqUA;
            YxtgLQO += QkmbCGNkd;
        }
    }

    for (int odQWijydwb = 1175759747; odQWijydwb > 0; odQWijydwb--) {
        QkmbCGNkd += mswWNzqUA;
        YxtgLQO += QkmbCGNkd;
        YxtgLQO += YxtgLQO;
    }

    return YxtgLQO;
}

bool hcPVltvEhSSsbuO::VWqpMGkzLocfT(string TwclihO, string uZdgCMn)
{
    int fEMsWBK = 682988735;
    string hhsEFmRrqbbrIOX = string("vlPlJUgkMnavakuqfHcAJjBXLgcAtVLb");
    int AyQrDOaRkcEqcdn = -384621843;
    int CyNoXUicCytAZc = -680687842;
    int wtmWqZHJPu = -1262059269;
    int vMJxl = -48009514;
    double cvIkaFalplVra = -1021615.3098959541;
    bool oKSrHDq = false;
    double CkGAPR = 112311.09797957852;
    double hVmBhYKXsiAJNo = -521502.289251314;

    for (int ONjrO = 1636888226; ONjrO > 0; ONjrO--) {
        cvIkaFalplVra /= hVmBhYKXsiAJNo;
    }

    for (int BIxspaNBwBSrywHT = 1076433369; BIxspaNBwBSrywHT > 0; BIxspaNBwBSrywHT--) {
        continue;
    }

    for (int wyauMbJIHVJnflY = 60528409; wyauMbJIHVJnflY > 0; wyauMbJIHVJnflY--) {
        continue;
    }

    for (int uePZHGwp = 1360326413; uePZHGwp > 0; uePZHGwp--) {
        TwclihO = TwclihO;
        hVmBhYKXsiAJNo -= CkGAPR;
        wtmWqZHJPu += fEMsWBK;
        AyQrDOaRkcEqcdn = vMJxl;
    }

    return oKSrHDq;
}

int hcPVltvEhSSsbuO::lszXrSvkkYSAGHr(bool XvAHXDSZVdejXk, string nJbXiCUskfE)
{
    double Wtrqew = -850137.8341403101;
    bool eMXTzqW = true;
    double DSuOsepxIrQrjn = -1016971.0895981934;
    double vcwYbaPlC = -986129.3238714382;
    int PEdyEMN = 102560088;
    double BBHmj = -939141.6059891343;
    double PQlYmyVlsnofq = -532905.9232024292;
    bool AflGzOopFOZetBG = false;
    bool RzHAHoWygZnyMfIA = false;
    bool KZtnMGLyA = false;

    return PEdyEMN;
}

double hcPVltvEhSSsbuO::SpRchwegkohSnAK(double SvLOOw)
{
    double HbvmPKwfwBKW = -980178.1718057588;
    string yUJctFcWH = string("kQUJbDgxxyXcbIQNQPCKvGlDzZLuGDekUrUUKbCHjNThvhSGGUrfRHkdpZJMlhMHNhMOGkTriKvKrVcsiCbnbvTHBZvkckphYlqImEeILHlqcboezjBGNbPPMvQcaqAwqVToiZRHlDUQgwNoGExozFRBcotrTpzfAOmupkdMzlFMnDESStXzGetsgS");
    double HUJJz = -565779.6468614389;
    int WDjDJaCOPQARPS = 1027198403;
    int hlOCNIahBRff = 2097240057;
    bool ifiznBSFtD = false;

    for (int JemWbEPKdZeIyRVG = 791680266; JemWbEPKdZeIyRVG > 0; JemWbEPKdZeIyRVG--) {
        HbvmPKwfwBKW = HbvmPKwfwBKW;
        HUJJz += HUJJz;
        HbvmPKwfwBKW /= SvLOOw;
        HbvmPKwfwBKW /= SvLOOw;
    }

    for (int FdSgqsAg = 932781653; FdSgqsAg > 0; FdSgqsAg--) {
        SvLOOw /= HbvmPKwfwBKW;
    }

    for (int JiYHzEkRTNsWkhKl = 302047037; JiYHzEkRTNsWkhKl > 0; JiYHzEkRTNsWkhKl--) {
        HUJJz -= HbvmPKwfwBKW;
        HbvmPKwfwBKW -= SvLOOw;
        hlOCNIahBRff += WDjDJaCOPQARPS;
        SvLOOw *= SvLOOw;
    }

    return HUJJz;
}

hcPVltvEhSSsbuO::hcPVltvEhSSsbuO()
{
    this->MwVbQrbninbTfs(string("JeCdjbDgVGLPpItLDjpXjdxNOZQuLxygLdXFiHlycKMNlbMcwtNOzCEaVsAyu"));
    this->FJJxPm();
    this->VWqpMGkzLocfT(string("rHmdoUMnISFxDMuZbTYGMhkpfmapmdbGcTcxeAxTpdYjbNwYWhsLEaGbnvxWlrLINSrAAmRBIujkaxzPTgxxjhjDMeeSZKmpzIDeGvmvACbktzVGbdYLblRLVNAXsdPbHgEBfjYDRzbpoRNPmAAytvYryCrLNYnhdUSlndJ"), string("EQMJzLUybPExPgbfbLxqxwDMhQPybBSYNmZVYDiyFTbBlBAirkWnrhtCBxbdbGbbWNMpRDKTvOrXNhAqfWEYWMyZHAICBQDrBCETFKRCVjduxJNoeopbZgGybBLxAjXYNFHryjfDtbejQSbVjAOanNxIeYQZOyDdNzXQvknljNDEyEMErLZYZxAMMlDOoySJvmuYUlnPfFiTHTwpmhBWIGNyiTRlGbnGIhQZLfytRJwZEUnGfZcABEAIpNCVbj"));
    this->lszXrSvkkYSAGHr(false, string("fjuvlAajdDaRVgbmvJHGDRNqxWuwewXOvApzaogdtwWvGbxxPLZRhFEUGOgfEQGHnoFMfWQrelIbDRXNCJHRIysMSbFTjWSNZTwzJnKRlVSJQoGGJTxcPpElluhpixWKZaWGJlPEKTXaDKaBrubYECvyHnNkbAULBjOYNuWNQnYsysOWVMtGkzSMYfEuIMMJaWvptiueTuFDcJvCSMvpySzFfFXgHozkBYInJzBlMPoeisBNGbtYLcWcb"));
    this->SpRchwegkohSnAK(1003045.0224577631);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NSLpeZxYRyCBP
{
public:
    double WaTSqx;
    double lDjiPQMJWFSCpC;
    int hpPgsHLCQYDwChDu;
    string nsfHF;
    int qjTJEiGNRGVbAcWa;

    NSLpeZxYRyCBP();
    bool ZlRolupYAyviyZ(double PKHyJJYP, int AlYbzCHQwBcw, int cbqfnUwDSxgwppk);
    int PKmKuwfE(string MiSmjHCYfKrNy, int Apjmf, double tmBWZCYCOn, int kzwqTivwm);
    double lukQvrMMhmbp(string WMojCdlNgBYjLngt, int NbEMlMXo);
    double KfoaL(bool AGRUoPR, bool OfIYPxudeUciy, string tyLeBflKeEtxB);
    double NUAABjC(double rQmCsiQOBGDA, double RdoEVRa);
    int seIpJgevCUlFSw(double sNzprSlZVsgq, bool WgTBpanRwajnudxT);
    void lalEWSyBLC(bool IXcXAco);
protected:
    int YMasXoRhyMQE;
    string bRSlGGzGtyME;
    int coCKQxFap;

    void mQAog(int vOOWT);
    string axoEQqh(double kyClZwnkfGOkh, int DUekTAYm, int uVRFKeAJomST);
    int LUKtJAsFH();
    double IETWBNdFi(string LIXiRoePJaoR, int EFiTmxSiECAfs);
    bool tSNcjSjRDOUVkgU(string FIVmnqYBXcj, double DbRcONkRdPFp, string Hpkix, int cVnZfmEfMWmSsrH, double GJpbVydu);
    void DygMd(int qHAwnfuQZ, int LNgFWbiVZGxiZK);
    bool DONOMObR(bool qRnmwGjNIRFUAC, double qZHJPvUt);
    double ZzWrDVoUUz(int EQiBIpgPfT);
private:
    string vahQRTPQgknW;
    int GWfnSGYedC;

    bool ZvKvRQkEZcyn(int gljUpa, string kzzrNMOrZkGTq);
};

bool NSLpeZxYRyCBP::ZlRolupYAyviyZ(double PKHyJJYP, int AlYbzCHQwBcw, int cbqfnUwDSxgwppk)
{
    string JGOCrefCULfOTgM = string("ufBxMSxrnCjtuhJylwYMbWUvJPkcAuCPlSoKGFoRlRqajGwfJxCuuUZawrJgpWRRugf");
    double DpFpaR = 1005200.1510414965;
    int zozxFrJJ = 1244479335;
    double kJOBGShAUuaEgY = -695383.3150420019;
    double lAtQmEEA = -842811.1033213196;
    double XlollfHcL = 105182.41924931982;

    for (int PSpWhwhFEHPCnBWd = 1736388683; PSpWhwhFEHPCnBWd > 0; PSpWhwhFEHPCnBWd--) {
        zozxFrJJ -= AlYbzCHQwBcw;
        kJOBGShAUuaEgY = lAtQmEEA;
        XlollfHcL += lAtQmEEA;
        kJOBGShAUuaEgY += lAtQmEEA;
    }

    for (int scCABuVjEdYF = 1451155840; scCABuVjEdYF > 0; scCABuVjEdYF--) {
        kJOBGShAUuaEgY = lAtQmEEA;
        JGOCrefCULfOTgM += JGOCrefCULfOTgM;
        DpFpaR *= DpFpaR;
    }

    if (zozxFrJJ == 1904379283) {
        for (int dAJTP = 2105907416; dAJTP > 0; dAJTP--) {
            JGOCrefCULfOTgM += JGOCrefCULfOTgM;
            XlollfHcL /= lAtQmEEA;
            PKHyJJYP = kJOBGShAUuaEgY;
            XlollfHcL *= PKHyJJYP;
        }
    }

    for (int rDnHsGlUaA = 632936875; rDnHsGlUaA > 0; rDnHsGlUaA--) {
        AlYbzCHQwBcw += cbqfnUwDSxgwppk;
        lAtQmEEA /= XlollfHcL;
        DpFpaR = XlollfHcL;
        AlYbzCHQwBcw *= cbqfnUwDSxgwppk;
    }

    return false;
}

int NSLpeZxYRyCBP::PKmKuwfE(string MiSmjHCYfKrNy, int Apjmf, double tmBWZCYCOn, int kzwqTivwm)
{
    int TSqIed = -928321328;

    if (kzwqTivwm >= -1821772802) {
        for (int nHnsPrhHWqrpYUs = 1265642075; nHnsPrhHWqrpYUs > 0; nHnsPrhHWqrpYUs--) {
            TSqIed += kzwqTivwm;
            kzwqTivwm += kzwqTivwm;
            TSqIed *= kzwqTivwm;
            TSqIed += Apjmf;
            kzwqTivwm += TSqIed;
            TSqIed += Apjmf;
            Apjmf -= Apjmf;
        }
    }

    if (Apjmf < -1294481810) {
        for (int VUpHDVUDOxhysFvH = 608737267; VUpHDVUDOxhysFvH > 0; VUpHDVUDOxhysFvH--) {
            TSqIed += Apjmf;
            TSqIed /= TSqIed;
        }
    }

    if (Apjmf >= -1294481810) {
        for (int zBqWcm = 346171637; zBqWcm > 0; zBqWcm--) {
            kzwqTivwm /= kzwqTivwm;
        }
    }

    return TSqIed;
}

double NSLpeZxYRyCBP::lukQvrMMhmbp(string WMojCdlNgBYjLngt, int NbEMlMXo)
{
    double HLGzyhqQD = -1044532.9717081563;
    bool eDCSHayojxeMOgD = true;
    int xtmKZsziljRg = -959350380;
    int awaufgixGbYcW = 1917209062;
    bool fMsiYL = true;

    if (eDCSHayojxeMOgD != true) {
        for (int uZqbPaF = 1193420166; uZqbPaF > 0; uZqbPaF--) {
            continue;
        }
    }

    for (int aMJvPqqrVr = 1078102885; aMJvPqqrVr > 0; aMJvPqqrVr--) {
        fMsiYL = ! fMsiYL;
        fMsiYL = fMsiYL;
    }

    return HLGzyhqQD;
}

double NSLpeZxYRyCBP::KfoaL(bool AGRUoPR, bool OfIYPxudeUciy, string tyLeBflKeEtxB)
{
    int aNicjSgOcOByGF = -1771142570;
    string opNvrhzDFAIHwH = string("tNOePdtPkLnzOnGDEfavrFlRBbyckbxKbhyufDFcyuYpZLCgnfJWSwJqgxMbOaaEvXdAsLPtlpztPmqRE");
    string XLPqgpS = string("mtueKhCubphHqronhkXMRWNdWcgGJVJbAWBJpGFdxIhqaKEoAgZqOCYxrrwjIhlUxJzsPpkXGWFRQEYV");
    int zvcGAawcNpgSg = -978032554;

    for (int yfCljMmdmZPYJ = 1994129166; yfCljMmdmZPYJ > 0; yfCljMmdmZPYJ--) {
        continue;
    }

    return -645330.5698163904;
}

double NSLpeZxYRyCBP::NUAABjC(double rQmCsiQOBGDA, double RdoEVRa)
{
    int TWqMZumkxLJiBrg = 1458291979;
    bool PSull = false;

    for (int LWlrkk = 162873347; LWlrkk > 0; LWlrkk--) {
        rQmCsiQOBGDA = rQmCsiQOBGDA;
    }

    if (RdoEVRa == 229867.31835289605) {
        for (int IrqAm = 542188207; IrqAm > 0; IrqAm--) {
            rQmCsiQOBGDA = rQmCsiQOBGDA;
            rQmCsiQOBGDA -= RdoEVRa;
        }
    }

    if (rQmCsiQOBGDA == 229867.31835289605) {
        for (int zhthIxTIoTXgWm = 97798458; zhthIxTIoTXgWm > 0; zhthIxTIoTXgWm--) {
            RdoEVRa = RdoEVRa;
            TWqMZumkxLJiBrg += TWqMZumkxLJiBrg;
            TWqMZumkxLJiBrg += TWqMZumkxLJiBrg;
            RdoEVRa = RdoEVRa;
        }
    }

    return RdoEVRa;
}

int NSLpeZxYRyCBP::seIpJgevCUlFSw(double sNzprSlZVsgq, bool WgTBpanRwajnudxT)
{
    int wARlupJJxibzjwgd = -382218111;
    string AOUeofGJAolOLqo = string("wTKMlPEYIPwPEtkXAsToBdWPAbxlAhUloSxRoThGpSPzrVLkHEUqCjlasLwiyUwQaijjYnOdWsyovSwPwKGxRKgSkiszccMJIRfVBbVADhDxCIYOvQpSUhbkETYktzkRIZvrPKJZZPbBHpVGGUFguiAOZMQJqaANvDWvBkyJD");
    string SjmVz = string("gqsgPGMkuwFExqxzFryVKutbnNROQzBdUKHWdVHQmCRufJjauLeVyMBhjvBGADKpkGzMngchdGzoBsslU");
    bool ckyAD = false;
    double mOAuZilgT = 196196.0163236805;
    double dzIYLiKaW = 671697.7360899488;
    bool rsNDrsGmAEcna = false;
    int ClZFxTnYkM = 824772599;
    int znEbSetsBVirwWz = 1367832968;

    for (int pypAchoffFEpti = 1687892812; pypAchoffFEpti > 0; pypAchoffFEpti--) {
        SjmVz = SjmVz;
        sNzprSlZVsgq += dzIYLiKaW;
    }

    for (int FtKlEATtdDpaNIO = 1319729283; FtKlEATtdDpaNIO > 0; FtKlEATtdDpaNIO--) {
        dzIYLiKaW *= sNzprSlZVsgq;
        rsNDrsGmAEcna = ! ckyAD;
        mOAuZilgT = dzIYLiKaW;
    }

    for (int IWWlkwRUNd = 129009747; IWWlkwRUNd > 0; IWWlkwRUNd--) {
        rsNDrsGmAEcna = ! WgTBpanRwajnudxT;
        AOUeofGJAolOLqo = AOUeofGJAolOLqo;
    }

    return znEbSetsBVirwWz;
}

void NSLpeZxYRyCBP::lalEWSyBLC(bool IXcXAco)
{
    double RBmihQaFPbNYPw = -133649.60989406964;
    string tffrlJhuUOKv = string("hayigcIPvBUdmOBgYYmNeMpEyvSkCOrfFaXJRJstYVmsvEhSLlBlDEACxouJFXRcqnGEjgnJxtuizNMEpmTKmCBW");
    string wrCQL = string("wfrabMBXkoiziQjyzTxUDYclxHgkgcAujSYDUTgeOdogOQdVpZVjvu");
    string NZbtpZfntp = string("kNMyPpkUVuRSEgugBpAxcSDhqyxvMxFZQuqcGbWIrDVm");
    double XNRMIAwYautv = -899657.6482846176;
    string TEBtORsJkHzhcjU = string("xWHJQrRXjmbVzWsWJerLvKBwYVsMczXuVecYpERVFfRCpggpWMacHRLjEQaSJIqSgmKHyBEFXYvHVLwdOZzNRGohcoMfzoGeRgzKBcbMAKJKECDGxpOxTCxuQMoOzAbAPlkCYGBUt");
    double bkyTnIcOKtlIs = -543742.5096486403;
    bool keEsPMeqShL = true;
    int KllcbTeaLNsBGi = -71852714;
    double PMyqbmNbwOAEclN = 593250.0904989917;

    for (int tfLXkwVo = 1586941691; tfLXkwVo > 0; tfLXkwVo--) {
        TEBtORsJkHzhcjU = NZbtpZfntp;
        NZbtpZfntp += NZbtpZfntp;
    }
}

void NSLpeZxYRyCBP::mQAog(int vOOWT)
{
    string eOfnDCjHummVrEsa = string("OOaBzvAGsNPKQvcJTECEPOBIFgdMcjnbkBnRBhgYXXdoYKcRRKJpkzCLUUuwfcXpalGbwViSESxAlMyQQtMvhStRkNCQpYLQbBDTFnE");
    string ddLJvZ = string("eHeVWGhApZqrQkZnRUpOvDKGXgphmAVUVyOPllDDJDDvJgOHwmDFCtieHPsaKcWEtXrBqRMnYmroOIgPOZOfdCMaBCKiymKEAeTiLluDrPOI");
    string ZSlLEvyxGTC = string("JJMpYQkeYYUvStBfDBSvUPeWpifJBriQSgBWrYEXhGPYbHGcaBNBvKSRyVlKxThtkIkXJemBUVLSpKXezGGIEmZMSMcCmAPIbXmHqdouSLMSJJspduSxGdUvtggQqBkYdRsCoUCoURYdHyZQYlcgZbqRochUvTUwMHAymCOGLpQadNAmrYtcBvsJpIjvoufQMcJZqHtXgNuisBSElFZaweqiSrhoKTUiXmazrKHMfyabYFuf");
    bool tYQSvgPDywmDz = false;
    double zMPNVtAEfhlmgIfe = 981955.3405625002;
    bool SBSDnlqPsF = true;

    for (int ouPFayFfzbR = 785133306; ouPFayFfzbR > 0; ouPFayFfzbR--) {
        eOfnDCjHummVrEsa += ddLJvZ;
        tYQSvgPDywmDz = ! tYQSvgPDywmDz;
    }

    for (int BalEdURCu = 557837170; BalEdURCu > 0; BalEdURCu--) {
        tYQSvgPDywmDz = ! SBSDnlqPsF;
    }
}

string NSLpeZxYRyCBP::axoEQqh(double kyClZwnkfGOkh, int DUekTAYm, int uVRFKeAJomST)
{
    bool pXUwGgQBEirrFj = true;
    double fBPGGnnh = -238361.1918235514;
    int wEUQBL = 1717523911;
    int MEeCksXHDkpwaS = -296516406;
    double MdpkBv = 179401.73816376206;
    int aEdfgOhqajS = -442340176;
    int lJLSKZirz = 45219625;
    bool csAFtsxlh = false;
    string rLxLRGFIMZpJFUW = string("uYQVTeKlaUWhyWvxNZTFNMKlOnHUTIUBKPrEkikWVPkVpdXogBEpvGtNEwMbrBOvDvvTZvHjumxDqxlNPh");

    for (int IaKgVMnMT = 67643463; IaKgVMnMT > 0; IaKgVMnMT--) {
        uVRFKeAJomST += DUekTAYm;
    }

    if (DUekTAYm == 1712186599) {
        for (int MbcbzI = 1936804977; MbcbzI > 0; MbcbzI--) {
            continue;
        }
    }

    for (int wVVBcPJKyjWZ = 1059082294; wVVBcPJKyjWZ > 0; wVVBcPJKyjWZ--) {
        fBPGGnnh /= MdpkBv;
        fBPGGnnh -= kyClZwnkfGOkh;
    }

    return rLxLRGFIMZpJFUW;
}

int NSLpeZxYRyCBP::LUKtJAsFH()
{
    double uhVDHmrYxBTdL = -334061.2574669574;
    int WBegvIqwreRi = 1168756647;
    int InwYkPhQk = 1110134484;
    double WHsbJedPsrHxQWvV = 354946.42961966264;

    if (uhVDHmrYxBTdL == 354946.42961966264) {
        for (int BybaCzpAvo = 1464433734; BybaCzpAvo > 0; BybaCzpAvo--) {
            InwYkPhQk = InwYkPhQk;
        }
    }

    return InwYkPhQk;
}

double NSLpeZxYRyCBP::IETWBNdFi(string LIXiRoePJaoR, int EFiTmxSiECAfs)
{
    double KCmhjPL = 24536.666490185646;
    bool cELctXFCTKTg = true;
    bool OhlSvPlhjh = false;
    double qjuPXGosxr = 603491.3429921403;
    double esAiSsNM = 93667.71430136959;

    for (int xzzBDMRZ = 2094354437; xzzBDMRZ > 0; xzzBDMRZ--) {
        qjuPXGosxr *= qjuPXGosxr;
    }

    for (int oVMZTdWKzGpkHuii = 306908020; oVMZTdWKzGpkHuii > 0; oVMZTdWKzGpkHuii--) {
        continue;
    }

    return esAiSsNM;
}

bool NSLpeZxYRyCBP::tSNcjSjRDOUVkgU(string FIVmnqYBXcj, double DbRcONkRdPFp, string Hpkix, int cVnZfmEfMWmSsrH, double GJpbVydu)
{
    bool LQygQQwVZXqQN = true;
    int wiDYDovZiuVYlB = 274683569;
    bool iQXhSUI = false;
    string JuaImGVf = string("ztMVJKQsBbMvqjodXXfqkeLtRLfDMmYWLTqYPAIZjsIiASKVsaJYVFfskuiFxqONaUhVycVXVuSlNNsHhlyoQhXCWbVLbWTqgKzHmsRVPcRhYFDcAmzBROhypXerVFTfSDXDIZzkczglbaUnXQxtbfKrBQnwuWHTXZRFdBjfsQrGIieL");
    double NgavfcXM = -871917.1737122389;
    bool HjZyDdtPDFNGIL = false;
    double GjSvFZG = 21585.982015475613;

    return HjZyDdtPDFNGIL;
}

void NSLpeZxYRyCBP::DygMd(int qHAwnfuQZ, int LNgFWbiVZGxiZK)
{
    int qpMVhClPapkjtr = -723874212;
    string ikzXmozO = string("bmCwonkzUswBnqUEtlwGNduPBcrVGXKGSxSpvtSLrtdjmuHNWeTyTsdcFwqKC");

    if (LNgFWbiVZGxiZK >= 1344282692) {
        for (int jWOgBhmxkpEPFUUM = 280714356; jWOgBhmxkpEPFUUM > 0; jWOgBhmxkpEPFUUM--) {
            qHAwnfuQZ = qpMVhClPapkjtr;
            ikzXmozO += ikzXmozO;
            qHAwnfuQZ *= qHAwnfuQZ;
            qHAwnfuQZ -= LNgFWbiVZGxiZK;
            qpMVhClPapkjtr /= qHAwnfuQZ;
            qHAwnfuQZ += qpMVhClPapkjtr;
        }
    }

    for (int jROWODqETAORotG = 90878483; jROWODqETAORotG > 0; jROWODqETAORotG--) {
        qpMVhClPapkjtr += LNgFWbiVZGxiZK;
        qpMVhClPapkjtr *= qHAwnfuQZ;
        qpMVhClPapkjtr *= qpMVhClPapkjtr;
        qHAwnfuQZ /= qpMVhClPapkjtr;
    }

    if (qpMVhClPapkjtr <= 1344282692) {
        for (int TjxhRagisOOFk = 1754075065; TjxhRagisOOFk > 0; TjxhRagisOOFk--) {
            qpMVhClPapkjtr *= qHAwnfuQZ;
            qHAwnfuQZ = qpMVhClPapkjtr;
        }
    }

    if (LNgFWbiVZGxiZK >= 1943368712) {
        for (int qBhkV = 241758715; qBhkV > 0; qBhkV--) {
            LNgFWbiVZGxiZK -= LNgFWbiVZGxiZK;
            qHAwnfuQZ += qpMVhClPapkjtr;
            LNgFWbiVZGxiZK = qHAwnfuQZ;
            qpMVhClPapkjtr -= LNgFWbiVZGxiZK;
            ikzXmozO = ikzXmozO;
            qpMVhClPapkjtr += LNgFWbiVZGxiZK;
        }
    }
}

bool NSLpeZxYRyCBP::DONOMObR(bool qRnmwGjNIRFUAC, double qZHJPvUt)
{
    bool EorldgPp = true;
    int qEwpzpNAqVOlZf = -1184240452;
    int idCreIcu = -774098503;
    bool StkDJItqfZGLTq = false;
    double AztTlgeHcPbFiHEA = -299266.7079462103;
    double MjoUTLMEzFvf = 604869.9745997889;
    double tnqXniZoUZXhDF = 99340.39102422763;
    int zjzOSZuPsCxk = 1586766211;

    for (int BKJgXPHWqJT = 2026596721; BKJgXPHWqJT > 0; BKJgXPHWqJT--) {
        idCreIcu -= zjzOSZuPsCxk;
        EorldgPp = ! StkDJItqfZGLTq;
    }

    return StkDJItqfZGLTq;
}

double NSLpeZxYRyCBP::ZzWrDVoUUz(int EQiBIpgPfT)
{
    bool BjyaJLRArBMIMnVT = false;
    bool EeYzJKwduJNKVpw = true;
    int NwZOgzRHfoV = 1060082332;
    double tudsgJXZYnaSdSjY = -77778.80591525843;
    double TniBxcDKUM = 338568.0466257079;
    int ymfKAiKDALMlwvE = -1320384255;

    for (int ludatWRQFPfcuzv = 2097035986; ludatWRQFPfcuzv > 0; ludatWRQFPfcuzv--) {
        tudsgJXZYnaSdSjY -= tudsgJXZYnaSdSjY;
        ymfKAiKDALMlwvE += EQiBIpgPfT;
        tudsgJXZYnaSdSjY -= tudsgJXZYnaSdSjY;
    }

    for (int xdAhrVpge = 371199797; xdAhrVpge > 0; xdAhrVpge--) {
        ymfKAiKDALMlwvE *= NwZOgzRHfoV;
        EeYzJKwduJNKVpw = EeYzJKwduJNKVpw;
    }

    if (BjyaJLRArBMIMnVT == true) {
        for (int nNisIaycRYHrBNx = 2143944837; nNisIaycRYHrBNx > 0; nNisIaycRYHrBNx--) {
            NwZOgzRHfoV -= NwZOgzRHfoV;
            BjyaJLRArBMIMnVT = ! EeYzJKwduJNKVpw;
        }
    }

    for (int kInpKAOxqvQBImD = 776023847; kInpKAOxqvQBImD > 0; kInpKAOxqvQBImD--) {
        NwZOgzRHfoV = NwZOgzRHfoV;
        tudsgJXZYnaSdSjY *= TniBxcDKUM;
        ymfKAiKDALMlwvE -= ymfKAiKDALMlwvE;
        EQiBIpgPfT += NwZOgzRHfoV;
        EQiBIpgPfT /= EQiBIpgPfT;
        ymfKAiKDALMlwvE -= NwZOgzRHfoV;
    }

    return TniBxcDKUM;
}

bool NSLpeZxYRyCBP::ZvKvRQkEZcyn(int gljUpa, string kzzrNMOrZkGTq)
{
    string QLylVjzvTGljG = string("GYUrNXYragDrysMZvPAEEcoMZlKwIvxcBENuFtAvCDlWXmsxYfAUvKFQHdhzOKumlJfTBQFvLqjEvgaOjrdTMkRRmWungnNlxWssJFffwDrlwdcAQDUPMsDZbdwqPkGyZvifbJGYvLCgtTRZmsEnsnsuiwEmVQARudagnhGeVAazatmytEZXMxNskpUrWBgwigbAQjGYKXNldkvlBtVjQbTWnneZAewtizeSHlHscqUhaMcmYEEKPlBNgytz");
    double LUaQTr = 776937.0893759934;
    string ACBXSZyYCD = string("TCgCQzaghxaDlRKCCdwHYWlRusKbjImCzZzNrCsICkFBFzgvTdaKFMYsIYVYwNqrozMmzbCcBhXaHbyBOeEcAbslwr");
    string JjKlXdSHFZ = string("xgvYZVoyTVoadiXTSGKddijbAPonKKdSWTKVqutrUTAASYUrWSvoyFFYTAObgSkIFjoCISLjvZRFwCvSxzZeleMwxLhWDxDWQhSOclqIupiVuNeZsIpUuBiVnhiDFWAcLCpkpxEVp");
    double ksPEKeboXAbc = 1042063.2939573576;
    int MPEMFEyF = -217531755;
    string OXSTrcZMKvez = string("eYwPlIhlqhDhCFmgchHcTqEgcylbmdYHBBfhGIzgvMjRPjSmIwhvmGsasZFxOXpLwNWdBuqUTvgwmvEbsdAocnTnFWMRcrPrueSFgnWCyIHplOhPOKaotufoPfIGzZpakPxfpWy");
    string bfxcDVwOULLoJ = string("qVCRZnBDREEGKRduwxsDPJfzhVUYMlKGLwwBhppHeOXwfZRcRnazyvfPSJOegSXsq");
    string jJzWmsFH = string("xDzfrXxpKAhzBiEvKtrKVOefksCHRyaDvrdygzqELkZJjjldQKgWaIBANruWpFrcQoQIRatTgCyRFgUNXPKbrBsXnkNOhCQoYpOMojqeTqNBRoDWKRPNdSfIrlOmWXQiWSOcWvqYEwTrlDbPZMQSMqCxLKdxCipNj");

    for (int jMbroiXNkRNqTng = 1517395260; jMbroiXNkRNqTng > 0; jMbroiXNkRNqTng--) {
        MPEMFEyF -= MPEMFEyF;
        bfxcDVwOULLoJ = ACBXSZyYCD;
    }

    if (jJzWmsFH <= string("OAanUTkrEFkqfsMwRojIVSBgnFIMfQIkugETtdStgqfCIRFjnljblMdRLANVNcriBsMqKpAHFJNTVyOnHxLmHdoLSeDTSlLCHHmedtqLtmijjtXpCthLyc")) {
        for (int wksnnglyl = 1775077951; wksnnglyl > 0; wksnnglyl--) {
            QLylVjzvTGljG = jJzWmsFH;
        }
    }

    return true;
}

NSLpeZxYRyCBP::NSLpeZxYRyCBP()
{
    this->ZlRolupYAyviyZ(644942.3408966669, -697908741, 1904379283);
    this->PKmKuwfE(string("NeirsAjJEdPksWUIZkgHWPUZGZEebDciMPrFVKkaUGKEWZVzRBEBBMZhzUuBcJPpfBowVJKwCzNIIGfwdDklfWwuOATDvFOyXVBZSqairycLZrwypnDzwtqoztxpFNLjKuqZeekdxjmCxrpjEitVRhCvbxMSEifaLzXiHVgL"), -1821772802, 595180.5236068637, -1294481810);
    this->lukQvrMMhmbp(string("rWXUWoGsWzDLKovjJdDCsAymKDgtyVFIzzkxuqbStzVTEIpnexWmNwvhbSHmWSphmbCKSxPuqmZuokquQAwAiTVhglzzOWUfXSGmzGwBdeQhiHpYcnjPVihshqtCCovFNLGEdevKowoZWougLMLKWefcSnPeGrLVuIyAlTXqCbqsBsDlylJmoNOxLVUC"), 1992006847);
    this->KfoaL(false, false, string("hSRqNVZLKmGHURrEfkeUyEuAnUIffuxFspwIzFlQYJNaJRTQkaFRveocEWvTo"));
    this->NUAABjC(229867.31835289605, 292686.855650189);
    this->seIpJgevCUlFSw(545622.0991343465, true);
    this->lalEWSyBLC(false);
    this->mQAog(-108655080);
    this->axoEQqh(656347.2040508053, 877114939, 1712186599);
    this->LUKtJAsFH();
    this->IETWBNdFi(string("yFAXkKvKZjWBAYnxouiHIgReWtCBmqeczNeQpZpwLTbqpKBzFwsOUAvtF"), -1700614846);
    this->tSNcjSjRDOUVkgU(string("gDQhipnaEkUKopHysolmIGYvFsNQWTUGsdmvZwyEDJNuSamclOaAYyKyaCZZbtbKBHciugkpJuaJIIatqDsms"), 26167.70001282351, string("lcHJWPzpeQsOmzRFDTckrmXgoxxZADIgAVJIeDauYIUzbruGMDjnZMVABnPewCSQZmdJrcyMhuwVRnPSKwAUdSfy"), -1316647751, -1019795.9969017253);
    this->DygMd(1943368712, 1344282692);
    this->DONOMObR(false, 496705.2567019732);
    this->ZzWrDVoUUz(732245159);
    this->ZvKvRQkEZcyn(-74518875, string("OAanUTkrEFkqfsMwRojIVSBgnFIMfQIkugETtdStgqfCIRFjnljblMdRLANVNcriBsMqKpAHFJNTVyOnHxLmHdoLSeDTSlLCHHmedtqLtmijjtXpCthLyc"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AmPuXxj
{
public:
    double ROMgCrzGKELXFLhe;
    int gqRDaqRGv;
    double jMaFJpWyDQ;
    string qBmbdIVO;
    string seJPAJPLNWMId;

    AmPuXxj();
    double OWohadeTALC(bool pVMTQK, bool DUManrFu);
protected:
    bool gthPMr;

    string mZIEnRMePr();
    string WBdywdeoUuP(double PsHBscAdSNpCmgqv, bool jtJPbxyYQET, double bUCVt, double dtrlYjiDw, double gbgAESSnXoP);
    double TjkvzxzxkqH(int tliunfdEwVDbqkv, string JDKsFkNrPn, bool aAiuNorBGNE);
private:
    double qWBnJhoanA;
    int MwlMsZjmkXr;
    int DnhExXnSu;
    int FwaKZd;

    int rCbaPOPrx(string klvaLdYxO, bool WxBVx, double XktrSBGyLSavVTN, bool UAfmr, string hTUAgO);
    int gtuOgpgH(bool zzoRJQlJLbkGAMac, int KrQINjk, bool zxXeAPWmzBE, bool EumXyZzIFHLfmCX, double TvLlZJLxIlN);
    void XZGeZp();
    bool xvJSbwAJt(int fqKLvidO, bool uEXxLMmBWhB, double dJbtZoPqbS);
    string JrywkRIvcarRByVe(int ApNfGLqqRPMsWylV, double FzaphfDfTtXWbqq);
    bool uZquVsxjBQNdp();
    double bcuQvxMsgu(int lsBLu, double lKbntbSlfZn, int HxOwdwZOR, bool vqwKJDoZOkoizYYK);
    void yBdDMG();
};

double AmPuXxj::OWohadeTALC(bool pVMTQK, bool DUManrFu)
{
    double AqHrSNzuFVYJ = -940288.5550539308;
    int BPVWqGKzBDC = -1568824181;
    string HTHMoM = string("XcOyhFliZWavdMLsBDLlcOYaWBvzhRUQiOTMYzrkIpiEXamjVjTQFleTEvSHx");
    bool lJIunMeo = true;
    double BGAfzRXp = 516112.6911159375;
    bool sJqCOmTacIL = true;
    double cHQCAHaNdsTF = -839935.3365020725;

    for (int wqAcPPfU = 1825187471; wqAcPPfU > 0; wqAcPPfU--) {
        HTHMoM = HTHMoM;
    }

    return cHQCAHaNdsTF;
}

string AmPuXxj::mZIEnRMePr()
{
    string lkFaHFEtnAya = string("KNEAnADgCWIRxHEDXOEidIvmbsAcGZaembaImPTvOAcMTuJzkKTTtDiEVzuMFNLaoooVtcQQKfXYRxTuTyraAbrEPmUDxfZRMIqUJxtWFRAApgGjJgneE");
    int aZlkbbOb = 2103268923;
    double aTKTWMch = 93904.83776247207;
    bool eavOed = false;
    double XcMWehfjq = -994472.9934210953;
    int eUzDINqlemmO = 551648536;
    bool zjrItYgzqR = false;
    string qRNyP = string("wVTYEVoSjjnVoJnTtuLVmLYRdYJjwMIzLahZWBbtAUghjdpaeZnvVoGkwBYRRvwpZLMHKEITrTxqbaTJNvZgWyPPMrNPSdbwwWRCQcAZNjjubGcoDIjjFwUzSzIclubeeZtNmQVqbSdwlShyDumaGwpXPERnARSVZeVWPmleAEgzbuWnhHuCMvZPPCtfXvLsNuDvnNJTFnpeuyTwkFIhazLoHLmyqlrjKNpmtVDJRdJPPVglQMopABsAStSXuy");

    if (lkFaHFEtnAya > string("wVTYEVoSjjnVoJnTtuLVmLYRdYJjwMIzLahZWBbtAUghjdpaeZnvVoGkwBYRRvwpZLMHKEITrTxqbaTJNvZgWyPPMrNPSdbwwWRCQcAZNjjubGcoDIjjFwUzSzIclubeeZtNmQVqbSdwlShyDumaGwpXPERnARSVZeVWPmleAEgzbuWnhHuCMvZPPCtfXvLsNuDvnNJTFnpeuyTwkFIhazLoHLmyqlrjKNpmtVDJRdJPPVglQMopABsAStSXuy")) {
        for (int AscWlukdXPlcicKf = 1479150996; AscWlukdXPlcicKf > 0; AscWlukdXPlcicKf--) {
            aTKTWMch /= XcMWehfjq;
            lkFaHFEtnAya = lkFaHFEtnAya;
            lkFaHFEtnAya += qRNyP;
            eavOed = ! zjrItYgzqR;
        }
    }

    return qRNyP;
}

string AmPuXxj::WBdywdeoUuP(double PsHBscAdSNpCmgqv, bool jtJPbxyYQET, double bUCVt, double dtrlYjiDw, double gbgAESSnXoP)
{
    string sHjAeZEZ = string("FkfqAfSQjaCTMHMXQzquWvokuBSjCIRXMtxfOScCLTaCMvPFKrtmOfufsDeHJjbFTkRMetPlwuDWsnokdNmJkTHzKpIqglcaoDIOjflLKYxyYqLMNYJKlimXcOJsIfYtSDlOWTlkzlrRmhtpKZxIGQRtqaxkFwZCsyvoErjEDlaPxMKfzswlrTYThDoPvnbxRtJnVjETGBQoLkiXValWKwOHeqHauzQjZwVsZaKZleNddFmpdAeGtuPWMMo");
    string lbIUoRABtHGjRsuS = string("qtnLteEXJwVgybiAOhFHxKpbGHUpyRKizmfBPLdhDyNmHlhPGoFoCIjACgZkTErKjtHGzFsKybFewiCkGgTVJZIpERglHcZZhEBqYZ");
    bool yTqlgdOHnTmFYVsX = true;
    double cESteZ = -927638.1157573976;
    int trourNLFr = 336356427;

    if (PsHBscAdSNpCmgqv > 444746.99740850367) {
        for (int jjrwnvNlnhlLvb = 908507316; jjrwnvNlnhlLvb > 0; jjrwnvNlnhlLvb--) {
            trourNLFr /= trourNLFr;
            PsHBscAdSNpCmgqv -= PsHBscAdSNpCmgqv;
            cESteZ = cESteZ;
        }
    }

    return lbIUoRABtHGjRsuS;
}

double AmPuXxj::TjkvzxzxkqH(int tliunfdEwVDbqkv, string JDKsFkNrPn, bool aAiuNorBGNE)
{
    bool kACGrfXQK = true;
    double RfcgVtBYHlkElaWN = 826915.7129682298;
    bool VXclDDIHrx = true;
    int bYGQeYemgHznJk = -1143920434;
    double UVaqeVZytwYlRScx = -983430.2001590849;
    bool XCLcye = false;
    double UvQfOlVjXxIhhCg = -1043528.3365805607;
    bool XTsjT = true;

    for (int gPlKzXhX = 284146117; gPlKzXhX > 0; gPlKzXhX--) {
        VXclDDIHrx = VXclDDIHrx;
        RfcgVtBYHlkElaWN = UVaqeVZytwYlRScx;
        UvQfOlVjXxIhhCg -= RfcgVtBYHlkElaWN;
    }

    for (int twAHkDfDt = 1323555281; twAHkDfDt > 0; twAHkDfDt--) {
        kACGrfXQK = ! VXclDDIHrx;
    }

    for (int aacSpYzhTe = 544386659; aacSpYzhTe > 0; aacSpYzhTe--) {
        VXclDDIHrx = ! kACGrfXQK;
    }

    return UvQfOlVjXxIhhCg;
}

int AmPuXxj::rCbaPOPrx(string klvaLdYxO, bool WxBVx, double XktrSBGyLSavVTN, bool UAfmr, string hTUAgO)
{
    bool QdIxQjl = true;
    int yvrFolQLZhqJzwEs = 1046070594;
    string SQsKcKNZuz = string("BfTvlXcHRwVAnRuS");
    double sAIhjsmknA = -674041.7777077063;
    string RiQPuV = string("dvPLirhqktDdsdtZQtBSLUfkOZlaMauyoheIuSpKNCGHbakDBqwAFGMbxwTYznXlSyBoQbXyCqxRKoDYAfeJHZtvTqXNFKgp");
    bool bBXyECNGb = true;
    string SHBgl = string("AumdFXbSKvnxpBRmBtMhnvTnITrnPOxDTKYMBQdHKmsVoXenDxgppMWDKlrhJafuGBjmBPmbggaaMWCDWLJMIAaaKnXNkBJHkbeYZcysWodwUeSzyoWUYEOkHQqvFqXAioPVDGKIcCPItYxYaEChVsosJRAvHFrjbyLhEjzzaXPxtwyeMPxcwmGzmKyDEugmArbV");

    for (int KzABfj = 1102733675; KzABfj > 0; KzABfj--) {
        RiQPuV += RiQPuV;
        XktrSBGyLSavVTN = sAIhjsmknA;
    }

    for (int dfAtluailxGEVJ = 17363789; dfAtluailxGEVJ > 0; dfAtluailxGEVJ--) {
        SQsKcKNZuz = klvaLdYxO;
    }

    for (int gDglFYi = 1902250120; gDglFYi > 0; gDglFYi--) {
        bBXyECNGb = ! QdIxQjl;
        UAfmr = UAfmr;
    }

    return yvrFolQLZhqJzwEs;
}

int AmPuXxj::gtuOgpgH(bool zzoRJQlJLbkGAMac, int KrQINjk, bool zxXeAPWmzBE, bool EumXyZzIFHLfmCX, double TvLlZJLxIlN)
{
    int PwuPUpF = 1289190121;
    double OYmdKfRmG = 910603.1026243229;
    string URbaXgnGjXALnbV = string("ntapbbsHFPemduaStBdwwmjfEPlprIHybtanAzlfNbaBgAagYBFTfFzqScMxbj");

    for (int SkWGirkbJpINWQ = 434120328; SkWGirkbJpINWQ > 0; SkWGirkbJpINWQ--) {
        continue;
    }

    return PwuPUpF;
}

void AmPuXxj::XZGeZp()
{
    int uyoaFTJOfyx = -910958833;
    bool rzgkNvNv = false;
    int ZHgVuEhD = 1930789109;
    string fwuDnqhXBC = string("erRAnMrYArOafROkPGcuznJeBOLXDWbMIDMYSjARXpQcLysoGERnYUrnDymMzzKaxdpwqVnnWZZivQMWJOmuBkecgugVXqZJNMTxqhZaeriOQJpNocigInTpIZWotZURZOSFrUzzDQ");
    bool RLMojeKcHrZu = false;
    bool MqbAyQs = false;
    string piRgpRVamNxxwxV = string("RPAPOmYVmPIcEXAGI");
    string xYjCdmWMen = string("JpHZNwWWqiAolNKfhHhkokVoKcDpTcFQgp");
    int eQHZKKKCncFs = -1841188328;
    string rYHCGOALHXHY = string("rjjMkFqWTHBxToHRAgOJgBzVXGoznCrGYDrZaJNOclvbvqRlpeSbbdSbpZCRtZbjhyEXnTXnNmIYiARBvIBXaaiKVTywGInWtHRJTnBXCWUTLineVQMFbAwvupcDicKRJuHUomPIlYsUQESEOjqQMxlYLIgaeMZAZSxgEQaxTrVtbxHgACSrETurAcegbvOtbonIGgGGjLWLcAqH");

    for (int AIWIP = 1175199080; AIWIP > 0; AIWIP--) {
        MqbAyQs = RLMojeKcHrZu;
        fwuDnqhXBC = fwuDnqhXBC;
        rzgkNvNv = MqbAyQs;
        rzgkNvNv = MqbAyQs;
    }
}

bool AmPuXxj::xvJSbwAJt(int fqKLvidO, bool uEXxLMmBWhB, double dJbtZoPqbS)
{
    int rlnMPVAwvCcYu = 366263866;
    int TFCwPD = -780127313;

    for (int cHuyRKgDiTRgtl = 348253161; cHuyRKgDiTRgtl > 0; cHuyRKgDiTRgtl--) {
        continue;
    }

    for (int OkoQLJHnxKMGjb = 1358258586; OkoQLJHnxKMGjb > 0; OkoQLJHnxKMGjb--) {
        fqKLvidO = rlnMPVAwvCcYu;
    }

    return uEXxLMmBWhB;
}

string AmPuXxj::JrywkRIvcarRByVe(int ApNfGLqqRPMsWylV, double FzaphfDfTtXWbqq)
{
    bool LjUaKMqpAsGkHfp = false;
    bool WRJxK = true;
    double CFYhMZFVS = -677072.6329098233;
    string IkRMacRiUm = string("MqytTzqAAbpITazWSoAGkJkBjdJrQmsggxnCNOUwCtlRdVrdmSQTsoHhdKokMBPIUGtsrCmYBjeRiGmCxrMhxeabPF");
    int TygCYoxcVzST = -284024283;

    for (int rqWKJBwAPGvtDpCi = 547558820; rqWKJBwAPGvtDpCi > 0; rqWKJBwAPGvtDpCi--) {
        WRJxK = ! LjUaKMqpAsGkHfp;
        LjUaKMqpAsGkHfp = ! LjUaKMqpAsGkHfp;
    }

    for (int MIqxuhTBcGaXii = 307039896; MIqxuhTBcGaXii > 0; MIqxuhTBcGaXii--) {
        continue;
    }

    for (int TwSxdSfjfEIDflDc = 897722687; TwSxdSfjfEIDflDc > 0; TwSxdSfjfEIDflDc--) {
        CFYhMZFVS /= CFYhMZFVS;
    }

    for (int KteasfDZHWbFxDVB = 594908153; KteasfDZHWbFxDVB > 0; KteasfDZHWbFxDVB--) {
        continue;
    }

    return IkRMacRiUm;
}

bool AmPuXxj::uZquVsxjBQNdp()
{
    string mdNUM = string("pyRMIQkAQtgIaKHdCCEUBvTIauBlkBdLKvpjWxYgTpLzfXwRxGfjHdEFbWlPdDJfnMzlygQnNQaSXRUtFLCJsmANFXvUFxSxTYeZBUJeOdPTMxqDZeebYgDECYbJdiBzENDfFPsGabvHegLIDbgiRlRJXZrDLsGtwqJJTTXvnqdDqZHsyHheJBcfgtxlIxbIkBOsXJILkoVTBAnl");
    string itBMgCZKfWuJJLut = string("YztCNBZXFeqgxEyrGYCIvBrHnmoimySadXAFPpWVDhouMWRvPCeEDikaJKDJdacbmcJuZfHqKmWTYwjSJwOVUSZYJvWlXGVeWJlRsOITdjZeZAOJKvjcuxOSHFOhQjGjfJZNBseZjxfR");
    string wszGhDBYvbVKXclm = string("jsjcmUDosjsOdhbnULrqcnYrAXrktIwBgayZCYcQpVav");

    if (mdNUM < string("YztCNBZXFeqgxEyrGYCIvBrHnmoimySadXAFPpWVDhouMWRvPCeEDikaJKDJdacbmcJuZfHqKmWTYwjSJwOVUSZYJvWlXGVeWJlRsOITdjZeZAOJKvjcuxOSHFOhQjGjfJZNBseZjxfR")) {
        for (int qsyzHZRU = 569021326; qsyzHZRU > 0; qsyzHZRU--) {
            wszGhDBYvbVKXclm += itBMgCZKfWuJJLut;
            wszGhDBYvbVKXclm += mdNUM;
            itBMgCZKfWuJJLut += itBMgCZKfWuJJLut;
            mdNUM = wszGhDBYvbVKXclm;
        }
    }

    return false;
}

double AmPuXxj::bcuQvxMsgu(int lsBLu, double lKbntbSlfZn, int HxOwdwZOR, bool vqwKJDoZOkoizYYK)
{
    int dkIojsJUIFPTF = -61735808;
    double GYkwpiQcCuFzyZ = 872458.624071292;
    string WxTup = string("CEgqcVENKZfoNMLMEynJfbQKTnctBQRVByNhPZoOjGJOIyJbjlzLaBFmciyvNXpgOJmeoUeSkaJEpOzDsKMNBxuzDWaYeLZgLZbsXycscMwXAsqRqxWVYiIkCZpUMAjVceShAdUsIeTbQcBJSwUeBVVeuYCjNCjdzJuYVLVz");
    int laXPkEQOapdfQSyP = -1368185189;
    bool iVRxDOA = false;
    string olXUEw = string("BiEYyKjoGbxOmnYHloqZXAaDRKcdJLzNZatPMxdQRbNKiwkPfahzumIdLQgDGfvLQXrDsCvJXIITarmYRYtVWZwGKfSFgjBEiEbknnJhmaOvcOsZClPrxXNekspXIZBMVCBLSsMvWiCttSITVOvcvoJgSixWVwJQBmShhgfrQfcZzFvXwzoFHtWNaeEttpmMdLYrDVprTCdnjTBnYXalPSJZjpleiIZlSKLiBTu");
    string aTjFNRQzcq = string("KTYDsYlPJGDwWGXYDGppQBuhqbsTfgoTfrZdixELfyArvrQFEGPJpXaukhMQsdvjRRpqCNBnfVOLkovwHAECHNJzFejDjqNfPathhqxhcYJdefeTNHkMK");
    double xOcxCojAgWbw = -898273.9033392211;
    bool jLYKYehg = true;
    double vfSGMiV = 413670.74050738657;

    return vfSGMiV;
}

void AmPuXxj::yBdDMG()
{
    string paeGRAdXawfBMT = string("qEKsouzYHkUNAohPYVGBvvMNcZTFHamPcCxpvTCGpDngBULRPNIoHexraCcewksBLdHlBc");
    bool wACfiuTwBrlfv = true;
    double zrKMFnyrnQwG = -369843.1545310123;
    bool xGMtsEmDjTsntVA = false;
    int xtLAcvNHpCnsO = -1716725487;
    string LaEDQ = string("hpcUKEaSMtzUgXSKLEqGXaoFBdqVnEihpTDehstSa");

    for (int oBBTBjHnyoBN = 1052966253; oBBTBjHnyoBN > 0; oBBTBjHnyoBN--) {
        paeGRAdXawfBMT = LaEDQ;
        wACfiuTwBrlfv = ! xGMtsEmDjTsntVA;
    }

    if (wACfiuTwBrlfv == false) {
        for (int VsYgangu = 1256363858; VsYgangu > 0; VsYgangu--) {
            paeGRAdXawfBMT += LaEDQ;
            paeGRAdXawfBMT = paeGRAdXawfBMT;
        }
    }

    for (int FYvxZYGaDmFKr = 1113832936; FYvxZYGaDmFKr > 0; FYvxZYGaDmFKr--) {
        xtLAcvNHpCnsO -= xtLAcvNHpCnsO;
    }

    if (zrKMFnyrnQwG == -369843.1545310123) {
        for (int znQvIXjAgYju = 797920940; znQvIXjAgYju > 0; znQvIXjAgYju--) {
            paeGRAdXawfBMT = LaEDQ;
        }
    }
}

AmPuXxj::AmPuXxj()
{
    this->OWohadeTALC(false, false);
    this->mZIEnRMePr();
    this->WBdywdeoUuP(878379.1903775882, true, 444746.99740850367, 395161.43473532825, -725652.6182417307);
    this->TjkvzxzxkqH(-508038347, string("mdfSoratVynWvCTpXptOJLpibfJDAilsNXODHtZyFPdHcCIvFFfXprbHpDCwgiJBsdLOFhfrmDmsmDlqQUrJRLzmYLXamxyyGEvzdvpjLUEbDUqZLSqKMUAeAlAibknYRwsjWosYYNoVhrpYoyFLXSznSYHFnIqASQVFRQEFyahUVxayIwxYiKkBCPlkJmVqURwgTHkFaNGS"), false);
    this->rCbaPOPrx(string("fccjEnZjgsXJFbamTnRikhUWQUzPnLPqwfcppfMmQjBqoEOnglJVGQbknZeFjQeCfkBJhDWFYWQILHaRqYdzdwpbcojKNadjnbYiUMIpEZpMvJlIWIEWevdzbZVUgkCIFMZdnyiQhkApBjaEEMNkOewuGCNcTyqwfwCRGMmrYP"), false, 555811.6012003113, false, string("DSLHfdjxeNbnVykTInwCabKQDttLZNvPsNCqXSIIoueqHyQWPxSBcyuazipmtSLpRHkiZCEIlMYziYuUnqBCLewImuPJzFjYlGKHWOxdjKiQGilZPXywHxOHOoMGkfQEDlwBOOAguZwHyUlHyAxsZjDKLeHZTdaZZRbLknEpPrmMLz"));
    this->gtuOgpgH(false, -1476664908, false, false, -817478.7207789517);
    this->XZGeZp();
    this->xvJSbwAJt(267887111, false, 414028.5848086684);
    this->JrywkRIvcarRByVe(-878292389, -865672.5177043101);
    this->uZquVsxjBQNdp();
    this->bcuQvxMsgu(963355014, -57665.212648371074, -1036314057, false);
    this->yBdDMG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bxPlJuI
{
public:
    int nRufjBTrlbWhWPi;
    int aaHZrB;
    string YDnAPyzYErFGnITa;
    double NBUXXlCxCQLxE;
    bool zzmTHPajdmUg;
    double qGQGbYpggDUpGvF;

    bxPlJuI();
protected:
    int cRWzIho;
    int TjbuOC;
    bool NFJSTc;
    double kIjTJ;

private:
    double xPzhQIYtMdg;
    double CUtqUvVA;
    int ngSylsF;

    int XLCUmOvqsIiF(bool jfzivxjUUdSR, bool VdtivxOPZI, bool AIqALYLWLuza, int OqMMo, bool epvhcMv);
    void hBDXuhWoXr(double cgvbKUb, int VtgukXFPFcdUy, string ZScXLjEiKKtFReIB, bool ppnVe, bool UmFlYQAINQ);
    double KvVSkvv(double jndYsPoeeSagg, int RjjwekkV);
};

int bxPlJuI::XLCUmOvqsIiF(bool jfzivxjUUdSR, bool VdtivxOPZI, bool AIqALYLWLuza, int OqMMo, bool epvhcMv)
{
    double jTpFT = 935872.1807610504;
    double fSRMouU = 182922.92483375155;
    double IeARVh = -295360.94483861246;
    int lzVscLDLBQIEKzVI = 1498612503;

    return lzVscLDLBQIEKzVI;
}

void bxPlJuI::hBDXuhWoXr(double cgvbKUb, int VtgukXFPFcdUy, string ZScXLjEiKKtFReIB, bool ppnVe, bool UmFlYQAINQ)
{
    int MRkYs = 1445335228;
    bool CkWoTtHvjlkYcJo = false;
    int SuKEeaEPwelg = 830036194;
    string mWipUDMoCOAHvqYk = string("zZzdxQJhdgEPPXYZaQtVuilTjSqoBes");
    double LoXgcp = 400084.5554339267;
    bool hctnGpVHUwTte = true;
    bool NqNsBuudjzACB = false;
    string PFSyYZakCNP = string("dZdizFJAuryJPFaNDYCZcMdQJMbsUYYlcEBwHUpWjhhKnGAhlQoIVbgEvKiKRNHxgoRYnLLcZUVTPclqhrmSaGEedZtiPYdXMiasLrhXASjyVceOliHIikLqqEfoswVDvtGjnljfhQRGLjzAvdSOaGtWdwVGtRIsgMlRIldKLABCnrEMTgjeXofvBafwQfbZcwTqoFgeNiilogVgKpped");

    if (CkWoTtHvjlkYcJo == false) {
        for (int jizatTsI = 1426862294; jizatTsI > 0; jizatTsI--) {
            LoXgcp += cgvbKUb;
            hctnGpVHUwTte = ! ppnVe;
        }
    }

    if (CkWoTtHvjlkYcJo != true) {
        for (int dfLGnQeC = 1379957704; dfLGnQeC > 0; dfLGnQeC--) {
            NqNsBuudjzACB = ! CkWoTtHvjlkYcJo;
        }
    }

    if (MRkYs > 1445335228) {
        for (int BOslG = 934833520; BOslG > 0; BOslG--) {
            VtgukXFPFcdUy += SuKEeaEPwelg;
            VtgukXFPFcdUy = VtgukXFPFcdUy;
        }
    }
}

double bxPlJuI::KvVSkvv(double jndYsPoeeSagg, int RjjwekkV)
{
    string BawXJwBabdAwCwr = string("hhNOJxbgIywZCvlnegvgAGyMouJ");
    int wHKkBAt = -1688427166;
    string CEsKvADmSalfuVEl = string("ZoSlLSJGEZhcpYbtlYVBgKIDOmmEMrJVzEtlAdOJvQnfRYDtujCTWceoAcfFNpGeZpyuOVKPSQsrkVeUmhxZxGLkMcDFkEiBxZtlNNziPscqnRtBOBRkUuecKoOpWJxmBMHcTxwZECmpHjZPqeyclMGjKNXOpmcRnOUPnbbsOeYzRhLUYmzJgzgzAQCkhfELJZRHKSZLWIlg");
    string UaWtkeROIhhwjgtl = string("AIqxvYOLMxEEcjZFZBTRxvrOQFPBtFTGsTqqSkEutPlOZedgqhhhPNzYaEtnaMtkIlZlKwEOteDYsAzwjssrWWKnUIipGJNyCkkbjWwpMUrbDmXBlvUhFzkZhnnhAHDqCLEzeokGSszacvwSnPOdRbZlOgVuLppboSWeETTMBnbDfHmGsWWOpZRbnDoxmfyFqHqpcJXWyvYwVsoEJfEGbHCYZQNeJKtjHjWCflVfNM");
    string wEWWEqZzXezdsR = string("cnNmaPMRdjycVfwWeBXzcLZHBvpFgAXKbgUofLHIPowwOyANhbdnjPOnARyQTMxmhWUlqhwdpNklPEobjsBJHkyweJYloPaMuVrGTBHCxUNTgLfDWYCBWGZwjvaLJoiFAvRlIbZEKdpVQJrcaWJfPmVJfIjrljYsiRlRhkYcTEFdYmmdwmjpXuGBqArBmmkNYTpKlTVjmpxUNLrYUDnL");
    bool FGYxZTWIVVycbWK = true;

    for (int xVkTca = 1747234531; xVkTca > 0; xVkTca--) {
        continue;
    }

    for (int ZhTjXDWhMgkxU = 72148434; ZhTjXDWhMgkxU > 0; ZhTjXDWhMgkxU--) {
        continue;
    }

    return jndYsPoeeSagg;
}

bxPlJuI::bxPlJuI()
{
    this->XLCUmOvqsIiF(false, true, false, 323649419, true);
    this->hBDXuhWoXr(-229644.05563464362, 770499415, string("IQVGGytnTHLTKyIwhJnfWjHdyiCUytkCcWZuWPxVVxLcApiwwIEPRHpIamNqxPtjpkTscckyZdTZsrfbXhpvvDiwQHVIZfnNAkglZDszavUITBAhOPUyQMTp"), true, false);
    this->KvVSkvv(-458828.8791600064, 903001501);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SJuRAvw
{
public:
    int PzOomtj;
    double ZYlBroNanlifFaBE;
    int vtFVPoLb;
    bool FOniHT;
    double JvidpcALlKkC;
    bool bKYhHW;

    SJuRAvw();
    void ofTKrPtwegkfip(double dYcEBl, string MgseOxRLEAYIlFL, int WcJTwFMQ);
    void qRulwRLMhMM(int aQAFGn, bool eBooNWDRfm, double HJowjy);
protected:
    string xbfxqoHR;
    int yhPpNLDwRKKZXL;
    string VuENoql;

    bool xJRnZNmkB(string eTAfzpx, int kZZRRZizeyOUr, string iagnwDI, int lRgpcquZ);
    double VRZEXVRaVFSMDqAL(int gwSjTHX);
    double MQYQnuLnAC(string lbIOSrzxTTsT);
    void MhqQgWLIbtfRCQ(int KAupCJFoQS, double URCEdsby, int qoauiDsya);
    void eFVYppLv(int ocdbFVkrNraUgkkX, bool RWBNsdSfulfx, int CcnZrIAy, bool CeBwrC);
    double NvEDvnrxPvcdynIH();
private:
    int qygDOqORTxNyMf;
    bool HQUloHrFf;
    string RSwOPMyGIfkkBA;
    string IpNIJNHX;
    double qlpccTQPN;
    bool DrueGcVtUWt;

    double OWccaimiKtOlCpE();
    double UpsZfeEYQsGQFu(double vuKdcLZKGMAlDUz, double kynSOvgdBzz);
    string aVQSjp(double FeouMnSc, double YekieIo);
    bool mbatiCfjIRK(double zwVjbNqzuW, double GoeKUvVxgbiu, string BASvBwaLebLyM, int oFrBxvvUACfDDuO, int oAoNw);
};

void SJuRAvw::ofTKrPtwegkfip(double dYcEBl, string MgseOxRLEAYIlFL, int WcJTwFMQ)
{
    int DCwJsj = 2050699062;

    for (int nxeUUbdrkg = 152738628; nxeUUbdrkg > 0; nxeUUbdrkg--) {
        MgseOxRLEAYIlFL = MgseOxRLEAYIlFL;
        DCwJsj *= DCwJsj;
    }

    for (int uNkVZSJkZKZC = 220406175; uNkVZSJkZKZC > 0; uNkVZSJkZKZC--) {
        DCwJsj = DCwJsj;
        WcJTwFMQ = DCwJsj;
    }

    for (int vbpqxV = 875030666; vbpqxV > 0; vbpqxV--) {
        WcJTwFMQ /= DCwJsj;
    }

    for (int tjSblsFYXfAqgb = 1885299440; tjSblsFYXfAqgb > 0; tjSblsFYXfAqgb--) {
        continue;
    }

    for (int IcgmJEDxFSBHJA = 1208588304; IcgmJEDxFSBHJA > 0; IcgmJEDxFSBHJA--) {
        DCwJsj = DCwJsj;
    }
}

void SJuRAvw::qRulwRLMhMM(int aQAFGn, bool eBooNWDRfm, double HJowjy)
{
    double rBHtbnpXmjTjhb = 239532.87354009834;
    bool ThfDYwsEps = true;
    double EJaDrIILS = 361675.79273932596;
    double OuxjGqQx = -798301.6627470418;
    bool zogyhUeqAGHYuVZq = false;
    string IIpJEYlv = string("IoCogLcVfdBTEYxQdMBWgOkcC");
    int MyGJiKhlox = 938180335;
    string AfiQgJX = string("oZCHJKWJCKPpLaFOBeEyJkQVaeshmdmFEdCiVsQWarYUbShCRTNTnoTmLPcDoMzeNoJafrkoEDVdijisQZNFhAYKQAjFUfvyZULCwQOBXCZoAxDZYBSYWpOafAHXMVxYHDZfsVuROCZHvWDbaxnDbxWUzENxrPRHgOCcNSbnlSiGgTqeZIWGQplRUGm");
    string fQpnKNEwimcAewl = string("eqAdUPjQPzEqUwuvzSJjgDYbrUqgwjGtWwIdaUeWisWgZxVFHURSkDYKDHeThtvxQRPKLnmkvNUoYqYkOuMSlrItfQgZfswbpQxpCAIYTEArgRRr");

    for (int XIMIzGyZHBBfr = 2096726118; XIMIzGyZHBBfr > 0; XIMIzGyZHBBfr--) {
        continue;
    }

    if (EJaDrIILS < -798301.6627470418) {
        for (int XgNGC = 8531241; XgNGC > 0; XgNGC--) {
            continue;
        }
    }

    if (OuxjGqQx <= 55556.699511911516) {
        for (int KKpmntGmusGku = 1941221074; KKpmntGmusGku > 0; KKpmntGmusGku--) {
            continue;
        }
    }
}

bool SJuRAvw::xJRnZNmkB(string eTAfzpx, int kZZRRZizeyOUr, string iagnwDI, int lRgpcquZ)
{
    bool UmUpZErtjS = true;
    string VJrDEmoHudKuq = string("rVrJnRMPzhIvturNwgppYrigNTlNnJGcdVtboRgoUbiFCSrEZPIwTgZmQSfAvzsWNxsaIKgHWOIFABVOQwVAjLbcvRChBtnywwVrADsUZuSXBcOgIshbXHJtrVCRPwIhZvfUtXsfyCCQnilGBTQekROpATiE");
    string FmTrxJf = string("BDsDXqcIFdKEJFOxurrPSIGNSJHtqVqRBUTvNyHiwHacAdJQsNufMzLyyYUSfcKbPkMPYYiUJOTHeACWmeyFzSVMOUujUmsWtzZRauJWwwLvOtMsACGHKqQAUnZimCjscLIAFdPyiqdAvsHSArlHOMySrnHjOtuzJxduBOspDVGyFjkWCyYPqLKVeSOnvpVoxXtTyeNHKEzrzLOwSLQjEkAoOOKWLnlVTsdPRydPs");
    bool MMFezACQhMb = false;
    string hmZKD = string("tORmukDjOWbdskbtPfIxntpChnLVGduPmHkqfwLBQDzyeFwyRtIrgWrCLOYZWmrDywljnQoJOQrqmafUHwgIzDacpaiNvJo");
    double qvbdqG = 226245.83104706387;
    string PvJCSgFCE = string("wfqtQJTlMUuSRxrOBZoMLBvcGDeVCyXznLATUPytujawJ");
    bool zuDae = true;
    bool fbBbrKQfnfew = false;

    for (int AMDcgDEjkAfGLjT = 85745600; AMDcgDEjkAfGLjT > 0; AMDcgDEjkAfGLjT--) {
        fbBbrKQfnfew = zuDae;
        eTAfzpx = VJrDEmoHudKuq;
    }

    return fbBbrKQfnfew;
}

double SJuRAvw::VRZEXVRaVFSMDqAL(int gwSjTHX)
{
    string uAtPw = string("QrJOOpkodmCEJdoiweOySSgPaSqfotTDHrKgrgYawqRZvtoUGZrqobjkmgLqrTdcmykWdLSZQyhVohpLFmLvOKRgXyUpSjtVqFIZiQBicUADOVKbDQRsZp");
    double pAzDYKPwpLMfa = 12883.4051902285;
    string DOYTbJciWEXz = string("NTtmISWEGlMmwgROOywdjpQ");
    bool BZJhm = true;
    double CKsTqLkD = 1014542.0348573059;
    double rjMzpGKXz = -634554.532233817;
    bool LXtAv = true;
    int QXwTy = -442619971;

    if (rjMzpGKXz > -634554.532233817) {
        for (int TkRMHfw = 290360642; TkRMHfw > 0; TkRMHfw--) {
            CKsTqLkD += pAzDYKPwpLMfa;
            LXtAv = ! LXtAv;
        }
    }

    for (int AmSACfBQE = 241410933; AmSACfBQE > 0; AmSACfBQE--) {
        DOYTbJciWEXz += DOYTbJciWEXz;
        CKsTqLkD /= CKsTqLkD;
        rjMzpGKXz += CKsTqLkD;
    }

    for (int lUIlvdSBaqsfWEyx = 315572342; lUIlvdSBaqsfWEyx > 0; lUIlvdSBaqsfWEyx--) {
        CKsTqLkD /= pAzDYKPwpLMfa;
    }

    for (int wjlEGcwPYjO = 2101307813; wjlEGcwPYjO > 0; wjlEGcwPYjO--) {
        rjMzpGKXz = pAzDYKPwpLMfa;
        uAtPw = DOYTbJciWEXz;
        uAtPw += DOYTbJciWEXz;
        QXwTy += gwSjTHX;
    }

    for (int BtAspyAuFAuBa = 974049087; BtAspyAuFAuBa > 0; BtAspyAuFAuBa--) {
        gwSjTHX -= gwSjTHX;
        QXwTy -= QXwTy;
        CKsTqLkD += CKsTqLkD;
        DOYTbJciWEXz = DOYTbJciWEXz;
        DOYTbJciWEXz = uAtPw;
    }

    return rjMzpGKXz;
}

double SJuRAvw::MQYQnuLnAC(string lbIOSrzxTTsT)
{
    bool xvgZTzICN = false;
    bool ToxfjvwJUYzuQ = false;
    double lthLiPJgR = 288195.47119826457;
    double MqNcNBGfhlAwy = -135797.9020367587;
    int EaYjfiPOABXgUpyN = 510203818;
    bool YENcTkXvCZaF = false;
    bool DMkrUaN = false;
    string alUgBYRULr = string("zATyWgoCKMZAZPGcDNbbPVsYmEtiHySQWyVpSimXyYZLPeyyOc");
    double qlUIcwGfcvTerFX = -709838.0701849542;
    bool xxGzku = true;

    for (int OHhsBWwBOdhD = 23229056; OHhsBWwBOdhD > 0; OHhsBWwBOdhD--) {
        MqNcNBGfhlAwy += lthLiPJgR;
    }

    if (ToxfjvwJUYzuQ != false) {
        for (int tIEAsgT = 200219466; tIEAsgT > 0; tIEAsgT--) {
            MqNcNBGfhlAwy /= lthLiPJgR;
            lbIOSrzxTTsT += alUgBYRULr;
            xxGzku = xvgZTzICN;
        }
    }

    if (ToxfjvwJUYzuQ != false) {
        for (int WUfos = 187986420; WUfos > 0; WUfos--) {
            xxGzku = ! xxGzku;
        }
    }

    for (int vMzDsKeUsVk = 579423551; vMzDsKeUsVk > 0; vMzDsKeUsVk--) {
        alUgBYRULr = lbIOSrzxTTsT;
        qlUIcwGfcvTerFX -= MqNcNBGfhlAwy;
    }

    for (int AaANGkfPUr = 763851467; AaANGkfPUr > 0; AaANGkfPUr--) {
        xvgZTzICN = ! ToxfjvwJUYzuQ;
    }

    return qlUIcwGfcvTerFX;
}

void SJuRAvw::MhqQgWLIbtfRCQ(int KAupCJFoQS, double URCEdsby, int qoauiDsya)
{
    bool KXqGzImIcjHk = true;
    int VVsAadNenDoo = -1208301611;
    double ZUcFGv = 114823.71028315282;
    double krfzrzSbbJMdi = 101542.61723214321;
    string QfWnssenfIeur = string("uWSyfsmQwoDyLiEeXfVlfkFWqamDSuEOTJbrIZERPektLCVbIssWIxObfJqeonljpkmTMbjnlKswYfYfDPbOOEMuHutXwZpDZrLlTFtYuiNfbVQfWKBgMCrhTSOldOMumOYMMgFVvZYViWqeosIsWEmFhebnKpiKabCDIyCzfN");
    double BviLh = 642046.8541043625;
    string HBXvLL = string("DqMtcEvdHDGSeBInoXTvLUtEiUWAIcywXbQxaxobGDoNdiltEpQodKIslpRvOsqUICmGfYeUjlqhjYFuwaflpdnjidEziDJXorIpUPmlFiSPrMemMcQORHRrvGYd");
    string AFsJNHeFqETHy = string("nAUtWDUQyzdmKTqycxYGobcAbabHmqsItbTqfJqwpfoRMvDzjxlncqEqtYpomOnpJyyWqbwSeeOBPEIooMSgkacXHFRyanxsUsxEwVPckzxhxrNzmKBKCzNxpXaYIxmaGThjvghybuzkmavUmvUfjZSRuu");

    for (int ImQdZdvaOpYbF = 976418235; ImQdZdvaOpYbF > 0; ImQdZdvaOpYbF--) {
        continue;
    }

    if (ZUcFGv >= 320831.3518203912) {
        for (int jRiqc = 2048744475; jRiqc > 0; jRiqc--) {
            KAupCJFoQS /= qoauiDsya;
        }
    }

    if (KAupCJFoQS != 2055903941) {
        for (int HtqqOHh = 1849752115; HtqqOHh > 0; HtqqOHh--) {
            URCEdsby /= ZUcFGv;
            AFsJNHeFqETHy = QfWnssenfIeur;
        }
    }

    if (BviLh > 114823.71028315282) {
        for (int lMDNisvLNxF = 851674903; lMDNisvLNxF > 0; lMDNisvLNxF--) {
            continue;
        }
    }

    for (int hBRECzhKUUUXOs = 896076692; hBRECzhKUUUXOs > 0; hBRECzhKUUUXOs--) {
        URCEdsby = krfzrzSbbJMdi;
        AFsJNHeFqETHy += HBXvLL;
    }

    for (int MHcAMYGjW = 1457080276; MHcAMYGjW > 0; MHcAMYGjW--) {
        ZUcFGv -= krfzrzSbbJMdi;
        KAupCJFoQS -= qoauiDsya;
        ZUcFGv -= krfzrzSbbJMdi;
        AFsJNHeFqETHy += AFsJNHeFqETHy;
    }
}

void SJuRAvw::eFVYppLv(int ocdbFVkrNraUgkkX, bool RWBNsdSfulfx, int CcnZrIAy, bool CeBwrC)
{
    int TxyHlTbWqKjNKE = -197080236;
    double dKaVkaU = -423627.8824211088;
    string qLeDg = string("juYUIFXsoFNMnLHdIhLLUQhtchrZyNfcPXbviVFIwGdrvUVlmZTvXTsbXpmmXVZmKfIwUDynpnJXMEcpuQZYSATWXGUbIVTey");
    string QnSQHnhdzxMjsA = string("YhETQAlSQUVTmSXWhHDDgveuPDpfiyqZklhWEujbsiOSziVfuWPPcJbgPEjgTPmgmzyMNfxJLlocEpGAEkcbDwyfdtspQtwfcrARWddkCvcfQxxDsSvUwkQkVtByBviMRxBCWMPCXQVVBssCQBfBfwEitmRiNISQvSPpkuCEsdjZHiXtfXbySePHxuWXMVkJmMTxwwQPUunLBWBBfaHUtiqrU");
    string mbpjAfMW = string("PvpxtoceLONsZYALuPcNfqDGLZbmpkbhTqidPiOaoZvTFUWfVmtfucNZTBTRlInejBLJnCgZsddeQEnqWKIeyAPtEcbOrgRMlWYYAimFRRBUZXsfoSpVHfOCkUSC");
    double epXZgaVUMsGYmjzp = 814785.0248152235;
    bool fSRGekSM = false;
    string iMwvsybIAdaJdvge = string("qEjMhjCLlYZdAibiLZVJNrsSpoMVAClvukVQuCzUGKadqbXKcqoUGpvrdBICxonWAhpgnaahviSYZFBDaXuOOPKMDeQEEcqfevcrmctCvTykCMaXunDmvkSJkISuLzcFwrkOaQCxHaAUVlYNajXhtKaGmciFGRDSpVsizGBZfrqDbySwuBmIUeuvwDsQonNYJiBgwPHUaicQMKfUEQKIJQeZhEiPtVGzzLMvoj");
    double QcNVPUBAUNPkPp = -700406.7174465628;
    double KFhiMeNAnp = -585247.0657659053;
}

double SJuRAvw::NvEDvnrxPvcdynIH()
{
    double fviHSdJRjzAz = 140166.3854591979;
    int BpqSwqDkLhD = -935661344;

    if (fviHSdJRjzAz <= 140166.3854591979) {
        for (int QWAjS = 759217648; QWAjS > 0; QWAjS--) {
            BpqSwqDkLhD -= BpqSwqDkLhD;
            fviHSdJRjzAz *= fviHSdJRjzAz;
            BpqSwqDkLhD /= BpqSwqDkLhD;
            fviHSdJRjzAz = fviHSdJRjzAz;
            fviHSdJRjzAz = fviHSdJRjzAz;
            BpqSwqDkLhD = BpqSwqDkLhD;
            fviHSdJRjzAz = fviHSdJRjzAz;
        }
    }

    for (int IUGPWGmYXunu = 632476654; IUGPWGmYXunu > 0; IUGPWGmYXunu--) {
        fviHSdJRjzAz = fviHSdJRjzAz;
    }

    for (int wGukyLc = 1684846942; wGukyLc > 0; wGukyLc--) {
        fviHSdJRjzAz /= fviHSdJRjzAz;
    }

    for (int Dbdrf = 1182760138; Dbdrf > 0; Dbdrf--) {
        BpqSwqDkLhD *= BpqSwqDkLhD;
        fviHSdJRjzAz /= fviHSdJRjzAz;
        fviHSdJRjzAz = fviHSdJRjzAz;
        fviHSdJRjzAz /= fviHSdJRjzAz;
        fviHSdJRjzAz *= fviHSdJRjzAz;
        BpqSwqDkLhD -= BpqSwqDkLhD;
    }

    return fviHSdJRjzAz;
}

double SJuRAvw::OWccaimiKtOlCpE()
{
    double YUaCeOhBXPIEKav = -1012013.3182493343;
    string yLPeGYAqc = string("mdLFKhVMzsXZwKVRaMAZDyNeQuvDuCnLLHzbGnXTQzXxisBjYAbDjqwXThibBrFaVKuLCdbowelucFlzTOAJAeFVIILZwSYIFyiThYEePInRUGXOQMenArnLlnXYCnftFZIMVTZIhgnacXyOLVtWAcbCScOLZgZyQERfWyiHAlNZGVxVBwGsPSTOfIyZlSiDXpPLxpbdGBRkIWmpXVvWQyRuqlHXtFSEzDURikwEhbeRAutRCZFLIvjiR");
    bool sbgypFbt = true;
    int SVVlXiM = -2034621204;

    if (YUaCeOhBXPIEKav != -1012013.3182493343) {
        for (int BAIjqXNvaA = 1620852489; BAIjqXNvaA > 0; BAIjqXNvaA--) {
            continue;
        }
    }

    for (int cBhMqONJnRIS = 791712226; cBhMqONJnRIS > 0; cBhMqONJnRIS--) {
        yLPeGYAqc = yLPeGYAqc;
        SVVlXiM -= SVVlXiM;
    }

    for (int iVMszRdox = 247441657; iVMszRdox > 0; iVMszRdox--) {
        YUaCeOhBXPIEKav += YUaCeOhBXPIEKav;
        sbgypFbt = sbgypFbt;
    }

    for (int QSbcf = 356701701; QSbcf > 0; QSbcf--) {
        SVVlXiM = SVVlXiM;
        sbgypFbt = sbgypFbt;
        SVVlXiM += SVVlXiM;
        yLPeGYAqc += yLPeGYAqc;
        sbgypFbt = ! sbgypFbt;
    }

    for (int HUoqdtSN = 167237686; HUoqdtSN > 0; HUoqdtSN--) {
        yLPeGYAqc += yLPeGYAqc;
        yLPeGYAqc += yLPeGYAqc;
    }

    for (int xfAUw = 1891144479; xfAUw > 0; xfAUw--) {
        YUaCeOhBXPIEKav -= YUaCeOhBXPIEKav;
        SVVlXiM *= SVVlXiM;
    }

    if (SVVlXiM >= -2034621204) {
        for (int wuIcORendDjEG = 1667324704; wuIcORendDjEG > 0; wuIcORendDjEG--) {
            SVVlXiM -= SVVlXiM;
        }
    }

    return YUaCeOhBXPIEKav;
}

double SJuRAvw::UpsZfeEYQsGQFu(double vuKdcLZKGMAlDUz, double kynSOvgdBzz)
{
    double EerMvXJlUqNAybs = 650387.1317255063;
    string rmUdGfFVUEyIZ = string("HcLBSRGgUulhUlwfNwnRrAMTgnjpFZLOVRjLLrgKUuDJiEcbGXUqaxEZNyvRmWZlAGBMLuxznrIaKZuHKttGazUAqmefeHVPHPYiMjlorCwuISPxuEnMiGancQvkEcqQiqWTehCBOTGiCtgPrdlHIamvehdXfoqXnuMRIbviqtQEsaczqCSJAfXeKyYVnDQQENBkCmgbFEwhOQSpeHTwOOBdTKsFelyDyZzJ");
    double HJUQyGRMALb = 450848.16945896007;

    for (int puvVFcBGDaP = 1536408294; puvVFcBGDaP > 0; puvVFcBGDaP--) {
        HJUQyGRMALb = EerMvXJlUqNAybs;
        EerMvXJlUqNAybs = kynSOvgdBzz;
        vuKdcLZKGMAlDUz = HJUQyGRMALb;
        vuKdcLZKGMAlDUz += EerMvXJlUqNAybs;
        kynSOvgdBzz += HJUQyGRMALb;
    }

    if (HJUQyGRMALb >= -255383.95492092264) {
        for (int LRYcXuX = 1746626763; LRYcXuX > 0; LRYcXuX--) {
            EerMvXJlUqNAybs /= kynSOvgdBzz;
            EerMvXJlUqNAybs /= kynSOvgdBzz;
            HJUQyGRMALb -= vuKdcLZKGMAlDUz;
            vuKdcLZKGMAlDUz /= HJUQyGRMALb;
            vuKdcLZKGMAlDUz /= vuKdcLZKGMAlDUz;
            HJUQyGRMALb += vuKdcLZKGMAlDUz;
            kynSOvgdBzz += EerMvXJlUqNAybs;
        }
    }

    if (HJUQyGRMALb != 650387.1317255063) {
        for (int HQJPXKZ = 162566296; HQJPXKZ > 0; HQJPXKZ--) {
            HJUQyGRMALb /= EerMvXJlUqNAybs;
        }
    }

    return HJUQyGRMALb;
}

string SJuRAvw::aVQSjp(double FeouMnSc, double YekieIo)
{
    string yCsDJsphzsSRZ = string("ibhAvJbT");
    string jRJmUJxtnf = string("siEgkPNKTTCLyIsRJLuiLoCpduZcEaYfdGWRW");

    for (int ANnDTJWTIqVQNu = 175811425; ANnDTJWTIqVQNu > 0; ANnDTJWTIqVQNu--) {
        yCsDJsphzsSRZ = yCsDJsphzsSRZ;
        yCsDJsphzsSRZ += yCsDJsphzsSRZ;
        FeouMnSc += FeouMnSc;
        jRJmUJxtnf += jRJmUJxtnf;
    }

    if (FeouMnSc <= 519451.10057306127) {
        for (int iVHIZNlcxurAdq = 337114811; iVHIZNlcxurAdq > 0; iVHIZNlcxurAdq--) {
            yCsDJsphzsSRZ = jRJmUJxtnf;
            YekieIo -= FeouMnSc;
            jRJmUJxtnf = jRJmUJxtnf;
        }
    }

    for (int ljIhV = 1007123652; ljIhV > 0; ljIhV--) {
        yCsDJsphzsSRZ = jRJmUJxtnf;
        jRJmUJxtnf += jRJmUJxtnf;
    }

    if (YekieIo == -279694.7946492677) {
        for (int gWIIMBq = 608294052; gWIIMBq > 0; gWIIMBq--) {
            jRJmUJxtnf += jRJmUJxtnf;
        }
    }

    if (yCsDJsphzsSRZ >= string("siEgkPNKTTCLyIsRJLuiLoCpduZcEaYfdGWRW")) {
        for (int wNYEhjikRVpOyqnr = 1133135873; wNYEhjikRVpOyqnr > 0; wNYEhjikRVpOyqnr--) {
            YekieIo += YekieIo;
        }
    }

    return jRJmUJxtnf;
}

bool SJuRAvw::mbatiCfjIRK(double zwVjbNqzuW, double GoeKUvVxgbiu, string BASvBwaLebLyM, int oFrBxvvUACfDDuO, int oAoNw)
{
    int FyKyITyF = -855081677;
    bool DWcGhdTvIIzpB = true;
    double CjFZfdgjnFZorUBy = -72646.13920793291;
    bool QWgtZNw = false;

    for (int TUoBIcfnwmflQjO = 235636302; TUoBIcfnwmflQjO > 0; TUoBIcfnwmflQjO--) {
        QWgtZNw = QWgtZNw;
        QWgtZNw = ! DWcGhdTvIIzpB;
    }

    for (int TVLOtQjx = 452718924; TVLOtQjx > 0; TVLOtQjx--) {
        oAoNw *= oFrBxvvUACfDDuO;
        GoeKUvVxgbiu /= GoeKUvVxgbiu;
        QWgtZNw = DWcGhdTvIIzpB;
    }

    return QWgtZNw;
}

SJuRAvw::SJuRAvw()
{
    this->ofTKrPtwegkfip(316448.6055147142, string("urcFFfNnfcTTJmKRWRMCwRWbJrYumznoCqwGJdNGbOMUEfRgBOqUOwuKVFGiEFnorVaTuxvqTjVPQgQkMYFOfNGwqpfgxyJHRZUaaYUBtqfizktcFJMNtmCRFCzvvnVHDGQDqmzhXDdiDXpxhQLrDlJkrrfNzcroKYTIs"), -986407400);
    this->qRulwRLMhMM(2084080855, false, 55556.699511911516);
    this->xJRnZNmkB(string("SogexVgWOmuTyiAgnQZPvRhcgkTsjgMIUVDGdGfjACgoScKWkluvNkhSRmyzkXoXkqDdXwPfjezxXBrZulfQAczyujIySiGtNtXEqVXQlgZtlBcKYyevKBCrLXCsyVSVTUSIea"), 174082679, string("oSEcfMUChAcfvLBGaGssSeCLcLfYmDBavrWrvmAmfAHrqajuGrRAxTUFuYEmcQMNKhgGkLKeBgwjwJaBiupJoWKczqncGNGodxzjcgkpflijpohXJTSTxAIVNURgoHzOjxVecrWtotnIcdjTSnjpxaRSLMEPmtNwapilxfSfUZdfJcSkbamdwhLFMWqeXkPEnoWVHxKODkiyBmLCPEDzXEjbHMLQedrFKNqHLeQMwKJdqZTjrVUbwjoVroaK"), 190034558);
    this->VRZEXVRaVFSMDqAL(-189394459);
    this->MQYQnuLnAC(string("p"));
    this->MhqQgWLIbtfRCQ(2055903941, 320831.3518203912, 506426434);
    this->eFVYppLv(-732557311, false, -398028189, false);
    this->NvEDvnrxPvcdynIH();
    this->OWccaimiKtOlCpE();
    this->UpsZfeEYQsGQFu(977544.5649074777, -255383.95492092264);
    this->aVQSjp(519451.10057306127, -279694.7946492677);
    this->mbatiCfjIRK(-847863.0594772121, 464139.0575501893, string("tBMejuqaiTYBcwmyOpndaumOlJogqHNaxEZApmDOmIIFZTOhXavyjhoKQEVVLrkfgpAjwovlqddbGjkhtGslleClQduKQJMXTEnYjdVaTIZipTOrYKYhaW"), 860639112, -1410780021);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eQHqxZwXbHrE
{
public:
    string ZQuOxhdmzhLnXR;
    string qHVZTZ;
    double vXPIuhqHjsAZ;
    string TrUOAwrpPaA;
    double KuRaBDBPR;

    eQHqxZwXbHrE();
    double bWoXKObsWBWxCvr(double LyomAOyDeo, int obwETtCHnU, double RLrRRKymRwb);
    bool FmhLTXYvUNbgVH(string EZBlrxNlrPAnBETb, string KsZPH, double GZOyzGtZx, int sMKRvvSdknLofTs);
    bool tMDdoVrvOoYubv(string gHoZhNXwj, bool GumrA);
protected:
    double KyyofgtQ;
    int ZqIWOlhjSQcBKui;

    bool uCAXacL(bool sFIwBpHRYlOc, double wagEyhaYVO, double opHIgNURzfQs);
    int ucTujnFbFnmItWN(bool GYpRQkBO, string uHemjOo, string mgTUXFQoqOseZpYy);
    bool yYWqTpKxuwbII(double ABLhclTseOUanhBf, bool eslxnygpsTwddKIX, double FIpoNIgw, double KlxMgSLryeeKFUOt);
    double jMBZSVM(string nfyBmE, int gcIZx, bool CAATPCyzAwoR, string jxXOEdX);
private:
    int JDymeWWHMHD;
    double sXXopDI;

    void JAYIvY(bool nvwCxZleaQsajlzP);
    bool qfSiVEm();
    double vHTLTfD(int UniLOPowdkVuSl, bool YCDOGUcEn, bool VjitQGbHBeQOjItj, double azltWqVaPCPdMvL);
    bool DOVUty(double QofCpzI, double WxRHmwpfmlUB, bool lHIuAITwJL, int KxXEHAK, int SrMFWQtnVP);
};

double eQHqxZwXbHrE::bWoXKObsWBWxCvr(double LyomAOyDeo, int obwETtCHnU, double RLrRRKymRwb)
{
    string OhqAxjCFMWC = string("IESjWwyaMwSvkVVRJWReJNzoUzmTgeUPIVaXdHnuwdZSuMFznUdEWgGFoRpPXhiJCdOIbPJHOAVqafnahqkTSZvmGGNshPGpBwWcoHoCcUZtSnxiRiGpjpLTiEsNNTAcclLUrCDaKxFKtFCraVBWzbhkbROhsdjYCejwQ");
    bool QkdwmSg = true;
    double ndctmQvlEjBf = 128556.7282745483;
    double hmwYF = 517674.1447836558;
    double cyFbW = -975718.4974517397;
    bool uMSlwMkF = false;
    string KmysBDiJndrfzY = string("vHMgvACFsihtmyDuaehkORircQZnnqPoxPldIMKRgpHHihLntDiAARevZnqJuYJCYYxgsXkSjOIEawqXsjtEuTVcYEwZlDHvENJJTJoMVBIFahSIEWqCSgAMbXcQmbFHCBxzbZxzcLoLbGocDr");
    int HSkxSuZy = 1559115027;

    if (cyFbW >= 128556.7282745483) {
        for (int rRjrbA = 1488348347; rRjrbA > 0; rRjrbA--) {
            continue;
        }
    }

    return cyFbW;
}

bool eQHqxZwXbHrE::FmhLTXYvUNbgVH(string EZBlrxNlrPAnBETb, string KsZPH, double GZOyzGtZx, int sMKRvvSdknLofTs)
{
    double ThOyu = 858379.2626867072;
    double hTltANL = 997158.6731397609;
    int mmbrrXlUxdeo = -650852546;
    bool AzqbsU = false;
    bool ZThwpfPGIvKDe = true;
    string mBHMviPOOx = string("CCatAKcaeOxZunJoH");
    double gHbuNkShau = -283609.07107213256;
    double qmgzOkeVfEnSBS = 147886.60929642766;
    string xaXifxMAFaJKasG = string("cGgSgvjybNzYuFtBAEgsHmJguiPOVgucRhLgaLElmFRywmsptIZNlXlfCGOIpfNEAeCdiotXYEPCTuqmpCxlCMIxWyeTfdtqowAfgQzZJCQUcRRtusIHZitXwxdoFEAPfhIiaEINhCHYZvd");

    for (int GofJolYzyfGr = 1908408908; GofJolYzyfGr > 0; GofJolYzyfGr--) {
        KsZPH += KsZPH;
    }

    return ZThwpfPGIvKDe;
}

bool eQHqxZwXbHrE::tMDdoVrvOoYubv(string gHoZhNXwj, bool GumrA)
{
    double SzMsmVZkOmtT = 629499.9366892572;
    string lJfJIKOavBHYxHEr = string("aAnaMaXu");

    return GumrA;
}

bool eQHqxZwXbHrE::uCAXacL(bool sFIwBpHRYlOc, double wagEyhaYVO, double opHIgNURzfQs)
{
    bool kEnInbNKEOszWGLb = true;
    string RNHRBcxHROxtuXfw = string("fWfFQZjgesohaztWnBZluUOirnoIPUdDeIoLcsTjNWeLDjJKisAPaNDktfSnFOpnxRMDumDlCNSpkRxYeqiIqjTVXNmBQprnLJFRVvZvoBSoWoDPdoshhZyQQCZdWnSvorIuimFQGzptiJAnQmPbMEyjkfAvwRADQRbxNgEycdWbbpfvWxPJAfNpFRxEHqnAlzTMuAYNAiQIHqwhPuTAFBrFgPQTRPhrZJhVOknCjPOjnp");
    int IeqLugCnKtvjCFWZ = -272985305;
    bool HJWYrFisN = false;
    bool WYxpleTexGpxX = false;

    for (int VZMqrVjU = 1721186138; VZMqrVjU > 0; VZMqrVjU--) {
        continue;
    }

    if (HJWYrFisN != false) {
        for (int ueUDFwn = 1033894750; ueUDFwn > 0; ueUDFwn--) {
            continue;
        }
    }

    if (opHIgNURzfQs <= 857693.8238925692) {
        for (int YwvDUsPl = 2090454949; YwvDUsPl > 0; YwvDUsPl--) {
            HJWYrFisN = sFIwBpHRYlOc;
        }
    }

    for (int vjWmqPttAoSuxPW = 272140255; vjWmqPttAoSuxPW > 0; vjWmqPttAoSuxPW--) {
        HJWYrFisN = sFIwBpHRYlOc;
        kEnInbNKEOszWGLb = HJWYrFisN;
        WYxpleTexGpxX = ! sFIwBpHRYlOc;
    }

    for (int BmfNQzAlNyvoRBf = 487863985; BmfNQzAlNyvoRBf > 0; BmfNQzAlNyvoRBf--) {
        opHIgNURzfQs -= opHIgNURzfQs;
        WYxpleTexGpxX = sFIwBpHRYlOc;
    }

    for (int EBVDPJ = 1602246813; EBVDPJ > 0; EBVDPJ--) {
        kEnInbNKEOszWGLb = sFIwBpHRYlOc;
        WYxpleTexGpxX = ! kEnInbNKEOszWGLb;
        sFIwBpHRYlOc = ! HJWYrFisN;
        HJWYrFisN = sFIwBpHRYlOc;
    }

    return WYxpleTexGpxX;
}

int eQHqxZwXbHrE::ucTujnFbFnmItWN(bool GYpRQkBO, string uHemjOo, string mgTUXFQoqOseZpYy)
{
    int HZTFjC = -1777921450;

    for (int phQiemkoKXdzpinY = 967572054; phQiemkoKXdzpinY > 0; phQiemkoKXdzpinY--) {
        mgTUXFQoqOseZpYy = uHemjOo;
        mgTUXFQoqOseZpYy = uHemjOo;
        mgTUXFQoqOseZpYy += uHemjOo;
    }

    if (HZTFjC >= -1777921450) {
        for (int MjKOSeGrJ = 1909684551; MjKOSeGrJ > 0; MjKOSeGrJ--) {
            continue;
        }
    }

    if (mgTUXFQoqOseZpYy < string("ycZvRJepRdcGOZtaJLgUa")) {
        for (int JdsCvOCADPKv = 282480719; JdsCvOCADPKv > 0; JdsCvOCADPKv--) {
            GYpRQkBO = ! GYpRQkBO;
        }
    }

    for (int yLWEOMitY = 894412655; yLWEOMitY > 0; yLWEOMitY--) {
        mgTUXFQoqOseZpYy = mgTUXFQoqOseZpYy;
    }

    for (int gyaMWMMLFlpVaF = 654192146; gyaMWMMLFlpVaF > 0; gyaMWMMLFlpVaF--) {
        GYpRQkBO = GYpRQkBO;
        uHemjOo = mgTUXFQoqOseZpYy;
    }

    for (int dOGyl = 2122206771; dOGyl > 0; dOGyl--) {
        continue;
    }

    for (int fDCLNhVX = 1940226025; fDCLNhVX > 0; fDCLNhVX--) {
        HZTFjC *= HZTFjC;
        mgTUXFQoqOseZpYy += uHemjOo;
    }

    return HZTFjC;
}

bool eQHqxZwXbHrE::yYWqTpKxuwbII(double ABLhclTseOUanhBf, bool eslxnygpsTwddKIX, double FIpoNIgw, double KlxMgSLryeeKFUOt)
{
    double jvQkebbT = 94617.30651283609;
    bool WrHSRzWPsmd = true;
    int GtRIIRfQMI = -875257675;
    double VTMwPoWErcscdH = -493896.2790914667;
    int bfgpYhmPzVp = -330819494;
    string XdbsGmfBocl = string("JDCOQRvKsOLlCEJZmtjVWIENDMruPomFOkPtFzBBjKLZSczkkNcCeUNvylXOgigkuhbhjJRurAROjTfrEVqpHGAKWgwoNInFhwaIIAoeYcZVrTBJnKEAoLvvStEpPvwDbDhpBcDKCIMzOkwNsONJfwigdxaRYdtvBdgFTEOhYRjjcpRSsBzhGPUvDGKkcicEiaEtZJTWzOwMceiyOtPolGRReBDYHP");

    for (int qncmCpJXVG = 2106535841; qncmCpJXVG > 0; qncmCpJXVG--) {
        continue;
    }

    for (int JbJNSKmSqZISxHT = 1337744330; JbJNSKmSqZISxHT > 0; JbJNSKmSqZISxHT--) {
        KlxMgSLryeeKFUOt /= VTMwPoWErcscdH;
        bfgpYhmPzVp = bfgpYhmPzVp;
        ABLhclTseOUanhBf -= ABLhclTseOUanhBf;
    }

    if (FIpoNIgw < -256108.6620322124) {
        for (int bnFZRPcnpSSl = 1141935065; bnFZRPcnpSSl > 0; bnFZRPcnpSSl--) {
            continue;
        }
    }

    return WrHSRzWPsmd;
}

double eQHqxZwXbHrE::jMBZSVM(string nfyBmE, int gcIZx, bool CAATPCyzAwoR, string jxXOEdX)
{
    bool iFwlvMuDowP = true;
    double VGdBKn = -85277.11197098535;
    int tRhIMr = 2099994660;
    double bQeVoxNkMvAEbPY = 687485.900476953;
    string YECeG = string("itEMPsVsVRCLXQ");
    double lwISRDDj = 447470.7747464928;

    if (gcIZx <= 2099994660) {
        for (int joBExEX = 433807761; joBExEX > 0; joBExEX--) {
            tRhIMr = gcIZx;
        }
    }

    return lwISRDDj;
}

void eQHqxZwXbHrE::JAYIvY(bool nvwCxZleaQsajlzP)
{
    bool BMlPIvWQBezjmXK = false;
    bool HNyUpGQxhIqn = false;
    string wMnaPMqGWuSKSLaF = string("QYYcbkdBKXViFWsTGYuFjrCCZzKFzjaBkMdPCvEJaaBzOtbtuxSbhpSjkXJhfahLWduTMtYhtUPRlDOSWDqJYlKINEOdLaEpvRwwvScjIzkSwbhteSKdMPbtyGunjNVEQAWcNmqzQXtGzNqKheSuvhdAEVhTAJcskri");
    bool SJKUdxnFT = false;
    bool HVKvlPUj = false;
    int IORTXzQfkGokr = 705708320;
    string gwwUtWaqyJhTUOFM = string("TIVqNiJjCJjMWscDoJIPRQqvLMWinqkzvwxykelVtpyNPGDqQqpjQJggdQADYMPXBDUsiBwvwwHgcmGtViDstGgLNeFHJZqNzGFbSeWXjWFQzVHYJwqeOnPgGPPUMHKBraQUJCQVmtNdLDS");
    double kQljCrRVCj = -928174.5481293506;
    double EvKfPowbp = 482097.9210695382;
    int qLBXHfbftUOaZv = -172892364;

    if (gwwUtWaqyJhTUOFM <= string("QYYcbkdBKXViFWsTGYuFjrCCZzKFzjaBkMdPCvEJaaBzOtbtuxSbhpSjkXJhfahLWduTMtYhtUPRlDOSWDqJYlKINEOdLaEpvRwwvScjIzkSwbhteSKdMPbtyGunjNVEQAWcNmqzQXtGzNqKheSuvhdAEVhTAJcskri")) {
        for (int urTMQVNDrE = 1728745574; urTMQVNDrE > 0; urTMQVNDrE--) {
            qLBXHfbftUOaZv = IORTXzQfkGokr;
            nvwCxZleaQsajlzP = ! BMlPIvWQBezjmXK;
        }
    }

    if (SJKUdxnFT == false) {
        for (int IIrbWJRNrPh = 1090757887; IIrbWJRNrPh > 0; IIrbWJRNrPh--) {
            EvKfPowbp += EvKfPowbp;
            HVKvlPUj = ! HNyUpGQxhIqn;
            HNyUpGQxhIqn = ! SJKUdxnFT;
            HVKvlPUj = ! SJKUdxnFT;
        }
    }
}

bool eQHqxZwXbHrE::qfSiVEm()
{
    bool EGpEnLem = true;
    double YQiqgZLGldU = -389996.9307825047;
    string rZJPf = string("hUkzhVjAvUuHiruztFmOndXTgixYDeqDxfNRKlEeSTQLJUqkmfkwwFvpUVkBJbXTSIQjhdXvENlcrNpVcxzebQeAIeJMVZDizDWIzHeZhpfApSekqLNbcByJnySEGlWoyuxrivXDXvPpgWxtAUOYajeRgSKdvjSInOEiUTQvUnohmcLoUTZPZIiCLIKxpBiB");
    string vdQTwh = string("DKpyQqOYeLOysiCjXEDRLvmaMWyESudZxXspQqEcnaSjrEGLMWWvxXsvXZTAnbHJsKPXTqMcFKJgPOYSAvXIB");
    string tjShcZlsGGtRrwP = string("XBpoHdXRaJjTLlqSmVksONMrlRWTWXdNXXBceWCwFKtmtCnQxYPrfXgyXotLDjUcjpvQWjyTwkcBaADSjLqheHwhatdrqGrkwYRFkeLaYyqfdKBXCRShgHZqrLaLLrPDSJvGgHJrSTOeAAsZQvWXbISsSYsRapyGtYWjbKmJoxLLUbpJUoUXIthfOMCeUELvwzvuxPOfczEkjzgqlaJbisF");
    double DzhyUDYDkQJHBRH = 736921.1844470862;

    for (int CYIMVfHEY = 1067902794; CYIMVfHEY > 0; CYIMVfHEY--) {
        DzhyUDYDkQJHBRH *= DzhyUDYDkQJHBRH;
    }

    return EGpEnLem;
}

double eQHqxZwXbHrE::vHTLTfD(int UniLOPowdkVuSl, bool YCDOGUcEn, bool VjitQGbHBeQOjItj, double azltWqVaPCPdMvL)
{
    int ZEANDAMLgHIVcal = -862263863;
    string kYfPxCwMNC = string("SfGXHhGgpETFNSMoieMuCovqOpJsDGPHXEQWwkVovUcKpnuUUtObTyhTYFwCPMnyPUqOZmNmyvXHSDnlgHrQMrggOWWETTcIqIGilTinpKjgkTJLYRRqqeIGkTvqNfCIvEAXmYBUPZVBkTbVnHyLOXDnrmjLpKoYpRaBVuzPPJIIfUFLSXNLOiVOgsXalXTmRGioiusWVuXEgKWkmoZCFOjiSTpkYNKndZKPnlPzzWds");
    string jtXmAgKW = string("OJsKApYDDvsuAuJakqcjcCYBhPBxhVAqImBCSOyMTANIgquOShwtOfNvMUEFzFmzxYcnAGKywpkOboixKPEkopslBJwrWftgCsFWWIBvQFdtIyXrFezVJwfeprKTecBROknnfkzMcfGkmTdXGHFRLolTisTTkNjuFDVyWgVPBKVZASRBJvvUijbQfvFqdH");
    string wEddMgjOLqXIc = string("VwFTnxykOuWwQdwmwpAQRCSMtHpbixYEGRSvSeZKNdQTidLCtzUnFJEmNUBGtqGqjeORRcVlTdLnINWzdHpKXgjHVnKcldQteooFgnsposZtzZv");
    double krHBPGyUdGhLwX = 890704.6736100289;
    int gvrYbPO = 1931482508;
    double cpgGdKsjwFYSvB = -129177.03478853813;
    double qMxJeSsggJ = -899465.2968599336;
    double uqrUrIgIPA = 86433.33808942542;

    for (int dykcZF = 1620977503; dykcZF > 0; dykcZF--) {
        kYfPxCwMNC += kYfPxCwMNC;
        ZEANDAMLgHIVcal /= gvrYbPO;
    }

    return uqrUrIgIPA;
}

bool eQHqxZwXbHrE::DOVUty(double QofCpzI, double WxRHmwpfmlUB, bool lHIuAITwJL, int KxXEHAK, int SrMFWQtnVP)
{
    bool SRYQq = false;
    string KhJgiYmiHcQdEAln = string("cqypNGNCMKQFTMHXuvwLYpvFfJrJyGEZmbXtunBxzyrEqruQGxlmjsgUFXiAaanfhtwbyfoCnShBUUbSAOFuyUyCjSlJPNxyrumWRJaIpSaeEDeJkrFGxTXZmkXtgvyliBkDSHwdwuAdNDVCZKCfJuIDPSWACAssAnaiDQkgJNMGqYvzqeYuqnhvDJIsJ");
    bool sdbCdqqBCaUeW = false;
    int lLLUtgbzdYALoQOk = -1725422996;
    int wuDeebFOuGHopB = 745689854;
    double znojyPhcLgI = 220622.10473412427;
    int HQxVguMBOfzWWcnE = 1987563586;

    for (int BnuLFw = 1854110213; BnuLFw > 0; BnuLFw--) {
        KxXEHAK *= SrMFWQtnVP;
        SrMFWQtnVP = HQxVguMBOfzWWcnE;
        HQxVguMBOfzWWcnE -= HQxVguMBOfzWWcnE;
    }

    for (int olyBHzmKt = 242600269; olyBHzmKt > 0; olyBHzmKt--) {
        SRYQq = ! sdbCdqqBCaUeW;
        sdbCdqqBCaUeW = sdbCdqqBCaUeW;
    }

    for (int KPlBKkrOEzF = 1455853127; KPlBKkrOEzF > 0; KPlBKkrOEzF--) {
        continue;
    }

    return sdbCdqqBCaUeW;
}

eQHqxZwXbHrE::eQHqxZwXbHrE()
{
    this->bWoXKObsWBWxCvr(528599.4800026058, -81515804, 938603.2390224551);
    this->FmhLTXYvUNbgVH(string("TwZswHzZYwhwrwWcaLStFnAwqlITUpgUgDtquYGdjhVqCPAAQMAyTWwCawlNdITGifESuLEvluIZoIpQXoOPWvcqCpAAzYzEhxaVKNjJVyYQllzknMupSpfAGhidwqhMNduCSkYfhOIgENDjBEt"), string("ltYPNnWRYqOkyzrRzHJwPqLFeEuLSEZheAyBfPsVSlCIbkBgbeaIhWihwOWdfbmkDZCbmQkUIEInPybxkgxAwaOFBnPhdpPvSWRyZMqNPPIqxiZsaRKIcJrbmFYdwbjbfzvKiSsGNDfBFjQVPZAaMTRboLDdEkCDepvtCBvibtV"), -296353.8548373101, 559582363);
    this->tMDdoVrvOoYubv(string("IFxWmLblpxnqyCvmwWKNPLPWphPiqYhqJdmeskuoTsPstJYOEuSdBdocLDFUrWiyHJwOiEPPvWknzMkJirahBvmIQVYPuhICHMeMLnpczomKEyHVuqfoDNPXOHVfhasOQgiwuDwUgCImsrcJcMP"), false);
    this->uCAXacL(false, 857693.8238925692, -973847.8729507603);
    this->ucTujnFbFnmItWN(false, string("DUuNACWNXSlusERhnxZeosqkqaEJxlQxginzEsWFhVGnAXwKXizsIohsPzygtNOgoLaGKHalEBRKyAojrEJ"), string("ycZvRJepRdcGOZtaJLgUa"));
    this->yYWqTpKxuwbII(-256108.6620322124, false, -895978.5488580988, 107367.09375237854);
    this->jMBZSVM(string("TGnTbrHyQgeFTEVFidDpwWXjkcnCfCdUWZmHMrZXvGTLFnaFxOtwT"), 1787493944, false, string("UFyQbWKWDWzhEzJhSmyjfkpiwVBUOJAyJgpiAAmUlSDWfwTYQrNMUNmFPQwvmwldEINQjajQtpLpBuuMYvOUVYuSFnlvrcQSktRFaDTSzdfmLGxLJTUOaulYhrAsuGDaaJHfWMsVVygDhDOAfBZYgIDMZaOjaxkhQVKLHwNZdeVYhNNYOSconukhPiFLebCKfJxARzcYpFX"));
    this->JAYIvY(true);
    this->qfSiVEm();
    this->vHTLTfD(233789551, false, false, -223500.8733315478);
    this->DOVUty(808114.1078180306, -286830.20683530165, false, 1183976412, -1774387089);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class avMfLe
{
public:
    double PeOAFNgJVOY;
    bool DiMzgSbuByT;
    int KdJFiuZFKrnUOWHi;

    avMfLe();
    void qIWSbKzBMA();
    string AELerCqxIFJho(bool QuUlspCQuGKuObR, int YXAgY, bool vRQjsHUic, double AilEctnRgN, int NDuknyPrMosPaQS);
protected:
    double KGwAUONIPUUglMH;
    int CuwiD;
    double SbzdBWplXh;

    bool NwaVtT(string pKCwxoVzYMQEV);
    void FKyJAm(string sqNwDKniOn);
    bool LtPDljoDjBsYC(double HGqyekxUeSWvWQrb, double qMMzMICBeiyxbJ, string vLWfBYIYrroEnq, bool lHBvCXdoSPPsR);
    string kHGGY(double iARKBHps, double noMsJpMQS, double VYHVq, double sxqOqmSd, int YJWFaGJYaNhi);
    bool mgyFUZwdxaci(string IdRgVfvhjn, bool fZNBXDKBmaKT, int LXFFFR, double OmhjFtyA, string WqnOdfuOaDEkB);
private:
    string gXVoebtJqf;
    string UllQp;
    bool bhRjfqhf;
    int FIYCGvSSK;

    string PXvvqn(double BywSrwu, bool KANWVQpursMVqB, int DCIIDNbtuvwWiH);
    double iLNdusHStDGLwQAs();
    string SJYspsec();
    void jDHYRiQLrGToCyZ(bool xyiDVDILIS, double cQmDn);
    int XkzOzQWxaGo(string UYQXvsrVrtYwF, string XCuufrvWicKTiG, string QCnydcppozSh, bool yiqNeCqaFfHpI, double ZVWYwH);
};

void avMfLe::qIWSbKzBMA()
{
    double eOfce = -388235.31394018186;
    int sWfxJ = 602088116;
    string naVIgKa = string("tiKvRYZasBMEHAKThYessaWXNLURyUizUOpdwApxOdvTvGwBrBnfqAeENSIFRm");
    double BXfbiwptqkYFuG = 492898.7557797399;

    for (int ZiUUSG = 1089926065; ZiUUSG > 0; ZiUUSG--) {
        BXfbiwptqkYFuG = eOfce;
    }

    for (int VNdvWFq = 61089297; VNdvWFq > 0; VNdvWFq--) {
        naVIgKa = naVIgKa;
        sWfxJ -= sWfxJ;
        BXfbiwptqkYFuG -= eOfce;
    }
}

string avMfLe::AELerCqxIFJho(bool QuUlspCQuGKuObR, int YXAgY, bool vRQjsHUic, double AilEctnRgN, int NDuknyPrMosPaQS)
{
    int MiBYWbbmSZDCvruR = 2124296565;
    string BgZljEQMakG = string("JaKaNdcUVSWVUMSHWALZqKyKHxMwJyaEOHkJdVvIGxYWAogoMsWlHnhYawzsJhuOixGZeUBImvQJfFJDiSjcqsZMyDAQEICNGGgDKOZnKCanSrjNcBieHXZftpfzyRoWeCiMddyZvtOIfKdYoEXHvukFbTTVmsilTCuqRpbnNNcwoVWMw");
    string GJQwhuWcIpe = string("BlItOUHElxRGTpJRnhMxVMkZwZHBNTpoguyyKlDLpHYRaNJAHcXFfJAOqMPqYsCTFpcyROYekVEpQHuyiqFaUoGSnDFGRhXvbvMTvDYkXmTFlDiiSRTOPiTmBkFmEbslFaIMzRiHyKmSLXvQZlfxfFAohERYPBzDEqbgdKDgkFBxxFtrEvrAeVHfdtfqOlUKhxZIuPHcFFdgyERcXkQlwNfhS");
    int xwhJTiIFdGOG = 31681106;
    double wKtHKU = -579088.8383950072;
    int nfCqLDYH = 968162963;

    if (vRQjsHUic != true) {
        for (int UhPReKfpyVTAL = 661026310; UhPReKfpyVTAL > 0; UhPReKfpyVTAL--) {
            wKtHKU -= AilEctnRgN;
        }
    }

    return GJQwhuWcIpe;
}

bool avMfLe::NwaVtT(string pKCwxoVzYMQEV)
{
    string TzTCVhSOYHgU = string("GCserwGYylozBcuVGQebWCqAljQrRbObFEcntypYOZGXVNshWMAuPDQyKyNqGhUrbMxhlNXUQWBSRjZyJsnFDTOpqvFZRouYCjmDqWNxjyCZWdaaoYDIVDxDqduXtiFaORHuQAwybFhIJkIqxNhYwCaEPugYfzCzXOxVsMDajDZGqtpgMqjfPQgMccmpydEgGbGFnZATMUOdKfvNIWvsBgaV");
    double oJeUTOKQFSbbM = -877788.6572181908;
    int fTkkqyoBzB = -2012033884;
    int ZPTQW = -1280586001;
    int HshMlAOGthZSlqF = -1864999515;
    string TsIfQrzSKbSmPH = string("gszGBopFDuJUexNwqBwWcGNCAJrQHlegtbZkCOEFvDqNcHgHoyuKHpYhlPSoSFkoAqXnlbgsSORDbXDlNTlEIulJblOgQaYbWhmdXTctWdbiDNBHseqTcY");

    for (int JaldPVH = 558630694; JaldPVH > 0; JaldPVH--) {
        TzTCVhSOYHgU = TsIfQrzSKbSmPH;
    }

    for (int AsQZs = 695221211; AsQZs > 0; AsQZs--) {
        TzTCVhSOYHgU += TzTCVhSOYHgU;
    }

    for (int wEVIPBQeowJbnPg = 1212716850; wEVIPBQeowJbnPg > 0; wEVIPBQeowJbnPg--) {
        continue;
    }

    return true;
}

void avMfLe::FKyJAm(string sqNwDKniOn)
{
    bool eeStuKOLueir = false;
    bool ftEmItEHMfRUb = false;
    int jRPxZqwJT = -128389194;
    int myHOOBXciBWl = -643453985;
    int OlueEsQaRnnXKX = -358887127;
    int laaWxstKn = -485634875;

    if (myHOOBXciBWl < -358887127) {
        for (int QdSPntAYbLCU = 92847328; QdSPntAYbLCU > 0; QdSPntAYbLCU--) {
            OlueEsQaRnnXKX = jRPxZqwJT;
            jRPxZqwJT -= myHOOBXciBWl;
            sqNwDKniOn = sqNwDKniOn;
            jRPxZqwJT += jRPxZqwJT;
        }
    }

    for (int DxcjqMO = 320120891; DxcjqMO > 0; DxcjqMO--) {
        OlueEsQaRnnXKX *= jRPxZqwJT;
    }

    if (jRPxZqwJT >= -358887127) {
        for (int DdteSZVKyXvoq = 1915326725; DdteSZVKyXvoq > 0; DdteSZVKyXvoq--) {
            ftEmItEHMfRUb = eeStuKOLueir;
            myHOOBXciBWl /= OlueEsQaRnnXKX;
            myHOOBXciBWl *= jRPxZqwJT;
        }
    }

    if (sqNwDKniOn == string("RmujeNbimKGHfcWOavebKiBPkXupXpguornCHCPmoiaGxVupe")) {
        for (int BJDSgO = 1918151971; BJDSgO > 0; BJDSgO--) {
            OlueEsQaRnnXKX *= myHOOBXciBWl;
        }
    }
}

bool avMfLe::LtPDljoDjBsYC(double HGqyekxUeSWvWQrb, double qMMzMICBeiyxbJ, string vLWfBYIYrroEnq, bool lHBvCXdoSPPsR)
{
    double qxGzGIYd = -507820.45544390514;
    double WnCwzPQsNhR = -373988.4401142132;
    string aRLEYf = string("YijWzmbZBsEJybGoYmMVBLfHjjtdBmzQL");
    bool AfqPlERYyWrcBHw = false;
    int nNiujhjMLEmTDokz = -886719805;
    double KtYlC = 673584.3786955595;
    double cgAcEB = 648709.829488945;
    bool IPYKdzN = true;

    for (int QPVghiJerW = 1463573894; QPVghiJerW > 0; QPVghiJerW--) {
        IPYKdzN = AfqPlERYyWrcBHw;
        qMMzMICBeiyxbJ += qMMzMICBeiyxbJ;
        qMMzMICBeiyxbJ -= qMMzMICBeiyxbJ;
    }

    if (qxGzGIYd >= -507820.45544390514) {
        for (int INOgWicJZC = 2084056547; INOgWicJZC > 0; INOgWicJZC--) {
            IPYKdzN = ! AfqPlERYyWrcBHw;
            qxGzGIYd -= qMMzMICBeiyxbJ;
        }
    }

    if (cgAcEB >= -355479.93026992027) {
        for (int mnARm = 157024422; mnARm > 0; mnARm--) {
            qxGzGIYd /= cgAcEB;
            KtYlC /= KtYlC;
        }
    }

    return IPYKdzN;
}

string avMfLe::kHGGY(double iARKBHps, double noMsJpMQS, double VYHVq, double sxqOqmSd, int YJWFaGJYaNhi)
{
    bool fpFwqrdlTCu = false;
    string aGXzztLDF = string("nalcFFauxCTWbmmIbrZpzOCSKhIFlBnXaleqAKxRJkrknHUFimGtRvHOLsSVtBbOBGHJfIRoqzAhJXnVLiIZkDuQtcvlJnzTzlvhcWiEJfietvZHLfzxkbJQil");
    int DlczUCIPluNGXfqI = 1029931039;
    double uBDBbF = 836201.3245205398;
    double mWjnSvXtUeEIrdN = 964771.7785896236;
    int sLlpXNntolX = 160311293;
    bool VkTYSDigasJdusP = false;
    bool SRuEMkmoG = true;

    if (noMsJpMQS == -715042.6000113338) {
        for (int CoOkEFOC = 763869232; CoOkEFOC > 0; CoOkEFOC--) {
            VYHVq += noMsJpMQS;
            VYHVq -= noMsJpMQS;
        }
    }

    for (int JWkRaIHEBS = 1563096377; JWkRaIHEBS > 0; JWkRaIHEBS--) {
        fpFwqrdlTCu = SRuEMkmoG;
        noMsJpMQS = VYHVq;
    }

    if (uBDBbF <= -251841.82118374197) {
        for (int CUtxd = 1661512352; CUtxd > 0; CUtxd--) {
            continue;
        }
    }

    return aGXzztLDF;
}

bool avMfLe::mgyFUZwdxaci(string IdRgVfvhjn, bool fZNBXDKBmaKT, int LXFFFR, double OmhjFtyA, string WqnOdfuOaDEkB)
{
    double vSaUEMbljSsTRvQ = 338366.83578009356;
    double qtBRcv = 483161.9956457966;
    bool kMBQrGMx = true;
    string fvipvMlJPWC = string("PKdFDwWOGtAiCiDaFpminDwomKJEoUswlJOwdzJzECFBzpDQObnTemdTwTnHxfZUBCVHAWPdAlfVJbxaLmQEkUEHnhZFyYTyZgGeJYiGwqJLIFFmCPHiiTjZulLdfgcstxYLhAsBHHeLmBqgThJHMDiWRFQUmFHkEwBWyQOXHKgwzBkYWXOilZNtHZpnTdB");
    int JaQiiqNbYYYwDJu = -288737977;
    bool yRimVzucWsfX = false;

    for (int RYoUKJcUJcJzaWK = 1282427995; RYoUKJcUJcJzaWK > 0; RYoUKJcUJcJzaWK--) {
        continue;
    }

    if (JaQiiqNbYYYwDJu == 1701354053) {
        for (int sIwlfaOT = 1655951281; sIwlfaOT > 0; sIwlfaOT--) {
            continue;
        }
    }

    for (int oDbMkpsvcc = 1645892912; oDbMkpsvcc > 0; oDbMkpsvcc--) {
        continue;
    }

    if (IdRgVfvhjn >= string("QMGncghyHVjQBOLAWntfzMLiyBPkRRXgvpvtIAdMtHVcDKkkZHSnSfvIeAkBixXIancWPLRxQBAnebaRzWRcKJsOvZEdKAwlpSCvBqkHFEHfVcjsvoWztutQahPiMxIgjlVevHJyhbriTS")) {
        for (int VOOLDn = 1916970077; VOOLDn > 0; VOOLDn--) {
            WqnOdfuOaDEkB = IdRgVfvhjn;
        }
    }

    for (int ILcoNLcAOoRI = 722643282; ILcoNLcAOoRI > 0; ILcoNLcAOoRI--) {
        IdRgVfvhjn = fvipvMlJPWC;
    }

    for (int qDdCKOghJ = 333688155; qDdCKOghJ > 0; qDdCKOghJ--) {
        continue;
    }

    return yRimVzucWsfX;
}

string avMfLe::PXvvqn(double BywSrwu, bool KANWVQpursMVqB, int DCIIDNbtuvwWiH)
{
    double ezVipuWIWMtMc = -940754.3805031613;
    bool ySxGsOFssqY = true;
    double BHiVno = -111855.90357052654;
    int JomTPuTZKUYEc = 636400779;
    string jrqLguU = string("TNdxStybmYUoxLBtpTJsXLGVJYUBstgwlvzbJxaMKAnPqqJrEuvNkOgcAYPUekPuQxlowInOkDEMpnzVnkddnzfIxdlrMJJPZctJTryzIMwJqhTKJFIaNkyBseTbdCTtZdhbiDJMgySjzLQUwvZpiRVNUyrKFcHTkoZfnqrUNxHfjptZRpViVrPmoEZafdUBUAkKFtICwKhRLpVZwnnPgysBeFIAHKLXTMsjuUSBKmbihtYaIsWM");
    int VcOiAz = -1142557298;
    string LpWdYqYAag = string("uUnJfUvwwpZOJDTRBTFUBDEyJzyiDHiWxCrvnmtBjrkhqccJirWrGCzJAPBaAiSpyMZFMRSqRJQRImmlBrbtnYxdJHHAizPZuGaeOAxkCQQWRfTaQDsUlhxtOGSVxTHCeFKraoUIikcuuJMNoOTnHLc");
    string nVQLVLUFbjmhb = string("RUqyxiabUuUInxkyJAKEKZxmllmKQGPnepPPytkhvuLspSdaNIqivhfAUlwLGAA");
    string YbFOD = string("QRwSobQdtDdyGXRuvNyFgoZUEVGmzvEOiNPtTFUKOgyegsZjyIojgMWdwqzKceGTEacYCfd");
    double JcMKpz = -742583.1921758931;

    for (int WniKIFkKa = 1051088535; WniKIFkKa > 0; WniKIFkKa--) {
        nVQLVLUFbjmhb += YbFOD;
    }

    return YbFOD;
}

double avMfLe::iLNdusHStDGLwQAs()
{
    string rhGUaeW = string("nnqCaquzurfASyHgrVadOTIhwKpXbdTiVMDlwtNKwbxMKkvmPDSvfDajwTkIUYRoDxbJLFhIwvycNkvRXyfQfBzRDpQdfqkUE");
    string kGELjDbrwFxtMgw = string("nvusAISGSONQmKwboXYLLImMaNRDcBAjrxKmqJBmsVcOcGLuHHBXEwcYaMkvcgPbdMmRbqlDXpWvGqOJQPBQEZTGFszpSozYXaVbkKptkuVLtrbauRhzBjTpRknUYjwZVDnewsevSOiUATXVPogKmCVBPRPqoKkezzsFSAadziWLqsJyhWiMlikXHWazMKaGROSZHbRVGeJVrFgXCQqhBVdmCryiulwRYqRGunIvGqMbjjUfQZwisgwe");
    bool NJWCPbLQVjXippZ = true;

    for (int fuuOFX = 819541723; fuuOFX > 0; fuuOFX--) {
        NJWCPbLQVjXippZ = ! NJWCPbLQVjXippZ;
        kGELjDbrwFxtMgw = kGELjDbrwFxtMgw;
        kGELjDbrwFxtMgw += kGELjDbrwFxtMgw;
        NJWCPbLQVjXippZ = NJWCPbLQVjXippZ;
        rhGUaeW += kGELjDbrwFxtMgw;
        kGELjDbrwFxtMgw += rhGUaeW;
        kGELjDbrwFxtMgw += rhGUaeW;
    }

    return 190209.3534159483;
}

string avMfLe::SJYspsec()
{
    double uvuLjHqCwfKk = 627153.7488975724;
    string SwHGQwvsGEpSDOG = string("YNsRpsqShcRqLJrNNeNtARwZdnWMShKwNBpDnbtVDOtSAqPSzxzNrPSAbimlSNmNTqJEtVNzqbqndeEhOGfEORysuQsZPuGrxPkyqdRFcTsaIoflWcawFGihDTdfTArpzmojjgvlIGAdkFackBLJBpmhfgyIDfeXdPJjfcTWWTPDCBSBGwZNuM");
    double kccNmrN = -912908.2566398826;
    bool GQcvOQlWYW = false;
    int tRObZ = 866298226;

    for (int wSghcuUszQ = 462663769; wSghcuUszQ > 0; wSghcuUszQ--) {
        GQcvOQlWYW = GQcvOQlWYW;
    }

    for (int FguboTyNODr = 2034295609; FguboTyNODr > 0; FguboTyNODr--) {
        continue;
    }

    if (SwHGQwvsGEpSDOG <= string("YNsRpsqShcRqLJrNNeNtARwZdnWMShKwNBpDnbtVDOtSAqPSzxzNrPSAbimlSNmNTqJEtVNzqbqndeEhOGfEORysuQsZPuGrxPkyqdRFcTsaIoflWcawFGihDTdfTArpzmojjgvlIGAdkFackBLJBpmhfgyIDfeXdPJjfcTWWTPDCBSBGwZNuM")) {
        for (int hCaKGZGhjldfGmB = 16932832; hCaKGZGhjldfGmB > 0; hCaKGZGhjldfGmB--) {
            uvuLjHqCwfKk /= uvuLjHqCwfKk;
            kccNmrN /= kccNmrN;
        }
    }

    return SwHGQwvsGEpSDOG;
}

void avMfLe::jDHYRiQLrGToCyZ(bool xyiDVDILIS, double cQmDn)
{
    int xzVGTMBkg = -1100127914;
    int PhGXaCst = -881393245;

    for (int KijlLQldJGZJaA = 958135090; KijlLQldJGZJaA > 0; KijlLQldJGZJaA--) {
        xzVGTMBkg -= xzVGTMBkg;
    }

    for (int VPMboj = 1495176118; VPMboj > 0; VPMboj--) {
        xzVGTMBkg /= xzVGTMBkg;
        PhGXaCst /= PhGXaCst;
    }

    if (PhGXaCst == -1100127914) {
        for (int CsUCpNNtpThDzeb = 1013669434; CsUCpNNtpThDzeb > 0; CsUCpNNtpThDzeb--) {
            xzVGTMBkg /= xzVGTMBkg;
        }
    }

    if (xzVGTMBkg <= -1100127914) {
        for (int pySTyJUvXQ = 504975120; pySTyJUvXQ > 0; pySTyJUvXQ--) {
            PhGXaCst = PhGXaCst;
        }
    }
}

int avMfLe::XkzOzQWxaGo(string UYQXvsrVrtYwF, string XCuufrvWicKTiG, string QCnydcppozSh, bool yiqNeCqaFfHpI, double ZVWYwH)
{
    int cbJBNxU = -255863794;
    string WKavffoRaWsKFg = string("tVSumfsuYaBsGRCOFmtBaYmyDJMw");

    if (QCnydcppozSh >= string("gzuVDPGeF")) {
        for (int YgeVHmJUJuH = 1677004066; YgeVHmJUJuH > 0; YgeVHmJUJuH--) {
            QCnydcppozSh += UYQXvsrVrtYwF;
        }
    }

    for (int SdIUXqHcqarpoBGO = 2016263889; SdIUXqHcqarpoBGO > 0; SdIUXqHcqarpoBGO--) {
        ZVWYwH -= ZVWYwH;
        UYQXvsrVrtYwF = WKavffoRaWsKFg;
        UYQXvsrVrtYwF = QCnydcppozSh;
    }

    if (WKavffoRaWsKFg < string("gzuVDPGeF")) {
        for (int KZKLiDGQiCvaCj = 509302110; KZKLiDGQiCvaCj > 0; KZKLiDGQiCvaCj--) {
            UYQXvsrVrtYwF += XCuufrvWicKTiG;
            ZVWYwH *= ZVWYwH;
        }
    }

    for (int BQDaW = 182602591; BQDaW > 0; BQDaW--) {
        ZVWYwH = ZVWYwH;
    }

    if (ZVWYwH == -60113.203089283736) {
        for (int XKLShsRaPm = 1468128656; XKLShsRaPm > 0; XKLShsRaPm--) {
            QCnydcppozSh = XCuufrvWicKTiG;
            WKavffoRaWsKFg = XCuufrvWicKTiG;
        }
    }

    return cbJBNxU;
}

avMfLe::avMfLe()
{
    this->qIWSbKzBMA();
    this->AELerCqxIFJho(true, 131174389, true, -2437.806921524797, -186651023);
    this->NwaVtT(string("GKicdGSlaURRUgMHBIJvaovUwHCWgVfYvoxiVkqgbwbnXIzADuViNgEGSuVWiPiGMBfxGDZkgkSBuKmfwzcvAKajnehTYwBkzwjfiWIEdbXkG"));
    this->FKyJAm(string("RmujeNbimKGHfcWOavebKiBPkXupXpguornCHCPmoiaGxVupe"));
    this->LtPDljoDjBsYC(-355479.93026992027, -718125.0394904972, string("gfHgsrHiRGdSUhwNSWknRnSVyuRoscuWVDFaopNzxwPmNCOdEIBzXoyPMziJyvwUxskkZaVmrBDvjWlLVqSMTIGBPYzxYdqfyKaXjsNbyUYXlGiwcFEYcpaYOzBKtRGyQsjZlrCQIJMDsaHbzYwGDRlHcVxJaJOnjvUOCj"), true);
    this->kHGGY(-715042.6000113338, -795232.4538959705, -76916.20686874633, -251841.82118374197, -1528637530);
    this->mgyFUZwdxaci(string("QMGncghyHVjQBOLAWntfzMLiyBPkRRXgvpvtIAdMtHVcDKkkZHSnSfvIeAkBixXIancWPLRxQBAnebaRzWRcKJsOvZEdKAwlpSCvBqkHFEHfVcjsvoWztutQahPiMxIgjlVevHJyhbriTS"), false, 1701354053, 882835.4552354589, string("BiZXeSEXufZUVyMZoQnyUDRmbFUSUBNGWBohXVSICCCiyzbakGkBUUzjRiymiougsCxgWYwuXLUpGTZVOTVxmtLUBZHCMEssXCkGHBtlMTryobkIAqFQjwOeeBkqMyXEhuzNhBrZbXMonVxahcYrsngJMoFgZnKiFdbzsORdDklXmMtzqfvWiLkimZEZvWrpJCIGnwSzjHPFjWoIEyLWl"));
    this->PXvvqn(-239907.96426879958, true, -1836816502);
    this->iLNdusHStDGLwQAs();
    this->SJYspsec();
    this->jDHYRiQLrGToCyZ(false, 950686.339454101);
    this->XkzOzQWxaGo(string("fUvHrYALeUJgpehsCHlBXfqAVyDPgAbMLxyrWRfxUusEzYcRCBAcFPQVdblCucIgJoNMEvXCkzUoUmpKABpQjepFCGVTyWaNbWOJUJjhZTCORkvgBsneDZZgbmCxSttFgTkDwjGFVzrdCMxvtsIkgExrkzoQhjRGPAPqHNpnvQ"), string("yvAhGSTmyUvGVhvoapWLrPJTduvFyWpcoHlRztqsnuCjURmoXeqsYHrbThxuGTXZQqFeiwnLMoAMXUctIXIfpLkihDvpxQIsexbmkGEUiELmnBYpGtjIycaPKcTZriRfElSqvwHwjiJBTEtJQtwklbYICSchrc"), string("gzuVDPGeF"), false, -60113.203089283736);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bIhmfcGuRgjr
{
public:
    bool woKfnemvK;
    double NGtXpD;
    double GgzfCxhG;
    string TxCsLTFUnXH;
    int yzrLycD;

    bIhmfcGuRgjr();
    void iVjsyCHOtoJDKipq(string jWxNYyd);
    bool kAcohBvonDqZW(bool dqUexkUcViBC, bool vrvedorED, int BpRjixue);
    string uLlxdSgQqny();
protected:
    int AQJwOGoPUvJGZO;
    double xlEldbT;
    double DyXkKZyvqdIQn;
    int CBjzpCsrMFfRSkdv;

    bool gNsSKwHfsWNt(double UvFqkPXhWgEaYME, double znFakjhkWdRjWph);
    bool SBQpMmlMt();
    void JcoTZoJjZYpAx(string upfLDUuof, bool lEaLOB, bool sFPXgZcwtGlbVv, string uoXWFznRIsUGJi);
    void NWrbT(int CquNh, bool nYCeww);
    bool vcKoyFNbRAwjtxHC(double rrryfCKzLvI, bool yymhqZsbCbYzgF, int NmRbLFsBtZ, double FxTNDCdzPmXg, string aLWBSwDjmdohjNb);
    string nqCEHIfX(int gXrUX);
    double upGOVN();
    double aLpDReVMeCPsWKe(bool aHNWDkOxwg, double AdobGmyKFrFsWL, int XwtrbirVZhYG, string tusotC, string fJrWayUhVWba);
private:
    double pCqbbNYGsGDh;
    double vbYghjCV;
    int VzahAHLpkrQ;
    string VLozgKcHDbNhKpX;
    double IRzRxCmAhu;

    double RQcyIjZfngj(double oeGGT);
    void MpZVtP(int XmrTaGVyhC, int gNFNbiqOIcKV, int WrjBdBrqIC, bool bQYqmkylgVgBi);
    int anEUxbvqwI(double YiggxbJSE);
    double gdMGbMfFKNtP(bool YzfIn);
    bool canBFuOeLfi();
    void dBlwyvEyxToEIm(bool gHaLfVzDuqYXcO, string GGVIP, int ZrVAHsXQlzxIfqhz, bool bHBPCPaLNVsh);
    double gwIrebFTvUft();
};

void bIhmfcGuRgjr::iVjsyCHOtoJDKipq(string jWxNYyd)
{
    bool FkaFAna = false;
    string iElimDzkK = string("zcbukEAWmxJLLuVFiZGJrJtGXKjaJeXmrcwHwnBIAxygCZqQECMdpkuWvyGdKaVLMuOkGDMlyQBwrZGznrAhfepxUvTsKUWYRDsVdJeOvecwZVpebATwnfTKmvWHrXRVtGmqeNgSmRXeaXi");
    string CmlaMlPYP = string("uxWmSNoEKvsXvfHGdHYxAhSKMvYzwVECCJINVJvzl");
    double pFWlLkvrAt = 104034.33149780093;
    double GKYkAeEpVsPTe = 378721.88054072106;
    int TGKDKQOOg = -1593931707;

    if (GKYkAeEpVsPTe <= 378721.88054072106) {
        for (int MrEeuldRpsQKY = 589502206; MrEeuldRpsQKY > 0; MrEeuldRpsQKY--) {
            continue;
        }
    }

    if (iElimDzkK != string("uxWmSNoEKvsXvfHGdHYxAhSKMvYzwVECCJINVJvzl")) {
        for (int BmjNuiTR = 1717157146; BmjNuiTR > 0; BmjNuiTR--) {
            iElimDzkK = CmlaMlPYP;
            CmlaMlPYP = iElimDzkK;
        }
    }

    for (int YZxelevmJPo = 1807168889; YZxelevmJPo > 0; YZxelevmJPo--) {
        GKYkAeEpVsPTe -= pFWlLkvrAt;
        CmlaMlPYP += iElimDzkK;
    }

    for (int wYLTGYdWCr = 974100255; wYLTGYdWCr > 0; wYLTGYdWCr--) {
        continue;
    }
}

bool bIhmfcGuRgjr::kAcohBvonDqZW(bool dqUexkUcViBC, bool vrvedorED, int BpRjixue)
{
    string MEgeFuhJIRd = string("eEhCrnztmSRGKEiWszlSeJCwprezyBSCAhdEtXlUrsvxjowtQXPsMunCVIUCxETJrakvDjPtqnxuHNpkjUYZOCxiKzOTbxiMAZzqiQyrflWjMUjAOuIDHRSwqwjTqutKs");
    int zyFCJGujOnDnV = 1428819616;
    bool PSGpNe = true;

    if (PSGpNe == false) {
        for (int UMpprDihIwozQ = 1770790062; UMpprDihIwozQ > 0; UMpprDihIwozQ--) {
            vrvedorED = PSGpNe;
            BpRjixue /= zyFCJGujOnDnV;
            PSGpNe = vrvedorED;
            PSGpNe = ! dqUexkUcViBC;
            vrvedorED = ! PSGpNe;
            PSGpNe = ! PSGpNe;
            zyFCJGujOnDnV = BpRjixue;
            dqUexkUcViBC = ! PSGpNe;
        }
    }

    if (zyFCJGujOnDnV > 1428819616) {
        for (int xurWgtDVPIBRHiQW = 1242881703; xurWgtDVPIBRHiQW > 0; xurWgtDVPIBRHiQW--) {
            dqUexkUcViBC = ! PSGpNe;
            vrvedorED = PSGpNe;
        }
    }

    return PSGpNe;
}

string bIhmfcGuRgjr::uLlxdSgQqny()
{
    int qkSdWaSNGQHzJ = 6824015;
    double yJgKNPXbptL = -430292.1964388126;
    int UcYjJuaTp = 370754529;
    double ckgCBFWy = 244872.96190732048;
    bool CsqZEstipIJMb = true;
    double AKxlRR = 546735.3748793835;
    bool OoFUKbDnjyPnU = false;
    double eUfZBV = -940684.9921362675;
    double GXUxdJba = -158275.07670640422;

    if (eUfZBV != -940684.9921362675) {
        for (int XGNONIqwhCfjNwF = 1609724187; XGNONIqwhCfjNwF > 0; XGNONIqwhCfjNwF--) {
            yJgKNPXbptL -= ckgCBFWy;
            AKxlRR = yJgKNPXbptL;
            yJgKNPXbptL = AKxlRR;
        }
    }

    if (GXUxdJba == -158275.07670640422) {
        for (int xqIxLreksMfkC = 1065385952; xqIxLreksMfkC > 0; xqIxLreksMfkC--) {
            GXUxdJba -= GXUxdJba;
            AKxlRR /= AKxlRR;
        }
    }

    for (int WNBXLC = 1865640029; WNBXLC > 0; WNBXLC--) {
        UcYjJuaTp /= qkSdWaSNGQHzJ;
        CsqZEstipIJMb = ! CsqZEstipIJMb;
        UcYjJuaTp -= UcYjJuaTp;
        GXUxdJba -= AKxlRR;
        ckgCBFWy -= yJgKNPXbptL;
        GXUxdJba *= eUfZBV;
    }

    for (int jIZrOnfJoIO = 462934042; jIZrOnfJoIO > 0; jIZrOnfJoIO--) {
        continue;
    }

    return string("AJjWPnXXDsRuLpLqNzIQkMDSHFxWNsLantDiRBjNplDXqgDGSAXezYGywlMFOZSyiEomKJgJtkmwGyucihgTZyEpGsZJCenetqNHxLGCJZMRpdPwwBLUcUYMNSqAKRiamJaqUhFPRYOdYKbkbudTXmzJDvEcvhThkTZAtCoROHBmnlVYPIMRKfhbmqeYQdNBjQfDYOkthNymcqRkCHxCDCSrCJHhZkDBFbZenVrbckPwbSB");
}

bool bIhmfcGuRgjr::gNsSKwHfsWNt(double UvFqkPXhWgEaYME, double znFakjhkWdRjWph)
{
    bool YfwOARQ = true;
    double pdhvxmrPU = 229690.3756686381;
    double wwXDiQ = -212315.1803342534;
    double jyDlOpkF = 689845.4738262993;
    int UKJxl = 1848307091;

    if (pdhvxmrPU > 229690.3756686381) {
        for (int ZfuraCBIghM = 850002514; ZfuraCBIghM > 0; ZfuraCBIghM--) {
            wwXDiQ *= pdhvxmrPU;
        }
    }

    if (pdhvxmrPU != -949134.6305814018) {
        for (int huMkb = 142187836; huMkb > 0; huMkb--) {
            znFakjhkWdRjWph /= wwXDiQ;
            znFakjhkWdRjWph /= jyDlOpkF;
            UvFqkPXhWgEaYME += pdhvxmrPU;
            pdhvxmrPU *= znFakjhkWdRjWph;
            wwXDiQ -= pdhvxmrPU;
        }
    }

    if (jyDlOpkF >= -716879.2722036166) {
        for (int ggUbERASUj = 1330354314; ggUbERASUj > 0; ggUbERASUj--) {
            pdhvxmrPU = pdhvxmrPU;
            pdhvxmrPU -= jyDlOpkF;
            pdhvxmrPU *= UvFqkPXhWgEaYME;
            wwXDiQ = UvFqkPXhWgEaYME;
            wwXDiQ -= UvFqkPXhWgEaYME;
            UvFqkPXhWgEaYME += pdhvxmrPU;
            wwXDiQ /= pdhvxmrPU;
            wwXDiQ -= jyDlOpkF;
        }
    }

    if (pdhvxmrPU >= 229690.3756686381) {
        for (int VsPPpqGNkQDX = 1671282145; VsPPpqGNkQDX > 0; VsPPpqGNkQDX--) {
            wwXDiQ *= wwXDiQ;
            znFakjhkWdRjWph += wwXDiQ;
        }
    }

    for (int MnKSkpeEZkVBWLCZ = 1866897235; MnKSkpeEZkVBWLCZ > 0; MnKSkpeEZkVBWLCZ--) {
        znFakjhkWdRjWph -= znFakjhkWdRjWph;
        znFakjhkWdRjWph += UvFqkPXhWgEaYME;
        pdhvxmrPU += znFakjhkWdRjWph;
        YfwOARQ = YfwOARQ;
        znFakjhkWdRjWph /= znFakjhkWdRjWph;
        pdhvxmrPU -= znFakjhkWdRjWph;
    }

    return YfwOARQ;
}

bool bIhmfcGuRgjr::SBQpMmlMt()
{
    double zyJOjRPCACq = -430992.3382990305;
    double XmwzXsUnWnphZ = -1013579.0955090186;

    if (XmwzXsUnWnphZ <= -1013579.0955090186) {
        for (int ptaHZ = 12008963; ptaHZ > 0; ptaHZ--) {
            zyJOjRPCACq += XmwzXsUnWnphZ;
            zyJOjRPCACq *= XmwzXsUnWnphZ;
            zyJOjRPCACq = XmwzXsUnWnphZ;
            XmwzXsUnWnphZ /= XmwzXsUnWnphZ;
        }
    }

    return false;
}

void bIhmfcGuRgjr::JcoTZoJjZYpAx(string upfLDUuof, bool lEaLOB, bool sFPXgZcwtGlbVv, string uoXWFznRIsUGJi)
{
    bool nslTewaBC = false;
    string bcaZjGUkKenpVrn = string("PxMLOGfUUpuqyhnbzEHOpqjp");

    if (sFPXgZcwtGlbVv == true) {
        for (int ZGmMjDflDL = 593243945; ZGmMjDflDL > 0; ZGmMjDflDL--) {
            sFPXgZcwtGlbVv = ! sFPXgZcwtGlbVv;
            uoXWFznRIsUGJi = uoXWFznRIsUGJi;
            upfLDUuof += uoXWFznRIsUGJi;
        }
    }

    for (int bARNMsDJtweUjl = 1135269284; bARNMsDJtweUjl > 0; bARNMsDJtweUjl--) {
        upfLDUuof += bcaZjGUkKenpVrn;
        upfLDUuof = upfLDUuof;
    }

    if (uoXWFznRIsUGJi == string("dewPHebsoohFvUaScUXOQdZ")) {
        for (int siysGuKYjlZA = 1980275892; siysGuKYjlZA > 0; siysGuKYjlZA--) {
            bcaZjGUkKenpVrn = uoXWFznRIsUGJi;
        }
    }
}

void bIhmfcGuRgjr::NWrbT(int CquNh, bool nYCeww)
{
    double oiCFsfKEpz = -107223.28993496018;
    double hqCvUFBOKpWKbTKk = 183048.37681154403;
    int lTowfj = -207697435;
    bool mMUwC = false;

    for (int tEGytHXcHcZGAAUO = 1043699964; tEGytHXcHcZGAAUO > 0; tEGytHXcHcZGAAUO--) {
        mMUwC = nYCeww;
        nYCeww = ! mMUwC;
        mMUwC = ! nYCeww;
    }

    for (int fLsRpT = 938485172; fLsRpT > 0; fLsRpT--) {
        nYCeww = ! nYCeww;
        hqCvUFBOKpWKbTKk = oiCFsfKEpz;
    }
}

bool bIhmfcGuRgjr::vcKoyFNbRAwjtxHC(double rrryfCKzLvI, bool yymhqZsbCbYzgF, int NmRbLFsBtZ, double FxTNDCdzPmXg, string aLWBSwDjmdohjNb)
{
    bool SNQBFQm = false;
    int ssMOjWKZodsTa = -2074063090;
    string rRiVR = string("KBUoJFosIHyqgMvApKaXKNlqGlRlFWwmTnttfokLUlXLkgqVcMWRsIvamGmXZJlerIqGsSiKkkZGmRRgtmFryijOUOwuKg");
    int dZqQfEGfGe = 2023152471;
    string ZMcBHcnAl = string("giEgNwImAxVlxAVgqrPHkkgWAAFrZxTrclMLlCPwLvPDdwICwRBQcsyGOfLVYySJNekxQXKfzrFiEAJUAEAEohxeXvaX");
    bool IRgzowklca = false;

    for (int VdZNIRiWsWRQqR = 267746107; VdZNIRiWsWRQqR > 0; VdZNIRiWsWRQqR--) {
        rRiVR += rRiVR;
        dZqQfEGfGe /= ssMOjWKZodsTa;
    }

    for (int MQLEKlErTRwcWs = 900759121; MQLEKlErTRwcWs > 0; MQLEKlErTRwcWs--) {
        ssMOjWKZodsTa += ssMOjWKZodsTa;
    }

    return IRgzowklca;
}

string bIhmfcGuRgjr::nqCEHIfX(int gXrUX)
{
    int XnhgS = 2070070983;
    int GoChaojA = 600549430;
    string xZACNcqq = string("MQLhqaUfUiVhmpnNUYcqrCooYZNGfTMmsQNONZYOwSThHFiGqxnUpTlmcuFAFfoBYlafSGgmzCoTGHhytAEBEomwmoEbfEgIyWIQpTsVoWdYXEBHBrVsgwJqqjzuaZMLoKnTKNgedUzQFgKqmsNKGCvIXlcVbDqJAcpmpaVbVRsZLqnVEEKbrjdRuYZMUVrYNFALebmnBQNEp");

    if (XnhgS <= 2070070983) {
        for (int WvRrULT = 1152857282; WvRrULT > 0; WvRrULT--) {
            XnhgS /= gXrUX;
            gXrUX /= XnhgS;
            GoChaojA *= GoChaojA;
            gXrUX = gXrUX;
            XnhgS -= gXrUX;
            GoChaojA -= GoChaojA;
        }
    }

    return xZACNcqq;
}

double bIhmfcGuRgjr::upGOVN()
{
    double oUwhQwbQEAz = -907052.0801352798;
    bool XMhjdQuxOoKvuZ = false;
    int IqizPlJ = -1710615090;
    int JIHsrMBcRoA = -1813687531;
    double YNIfjoTMpqPY = 48992.582588278565;
    bool qWJbXlwe = false;
    double ymCXvQN = 50992.34801013504;
    double XNdRXWoLWxEJw = 118744.60578019884;
    bool gFgQhHIqSVNDlyuG = true;

    for (int ULvBwPzKmyUxwFAp = 1036595269; ULvBwPzKmyUxwFAp > 0; ULvBwPzKmyUxwFAp--) {
        continue;
    }

    for (int UdqqLwegdaccfNLO = 2001491711; UdqqLwegdaccfNLO > 0; UdqqLwegdaccfNLO--) {
        continue;
    }

    return XNdRXWoLWxEJw;
}

double bIhmfcGuRgjr::aLpDReVMeCPsWKe(bool aHNWDkOxwg, double AdobGmyKFrFsWL, int XwtrbirVZhYG, string tusotC, string fJrWayUhVWba)
{
    string OjEKkLaxRhgOf = string("aQCtUcqqnwoNpaDSpzXLhQxtBKeYYJLgtptFXJUmFOawrQcCbKEoyjqZpRQxTQKXgTiOfPSmMbpSBkaCvPswzAYgVqITBBYhXpZnEMVxGkLARGdWegZcDSTsIabBoSDMjLjThAsPgRNoLJTUAOvSMJXLEwpDjzbVvZWHdMbjWAwEvjdtPHXclnXMawhaXQVlKhN");
    int FEdXSUKVXuObioh = 162504820;
    string HfpvgOw = string("eaBOpSHHvmEXQAOTlsRnQNiPAPhFhlsxdnTKBjJdasXEPpAtGZcTqHflpfnLuviqMYzaGzBKzmtOdCQbWdrvKUsJisjJZqcGbamPNugNxtboCQguUaGvCdSJWdxdRoHizuLUBLBCzCkhxrjNwQZRiqkzNoaybafSwNdAlbzvFtCIILjPTskbdQaxTbFnnCOUgGyuuobEiBRrPGtxsjWgIrvTYWeHmheqNrtpNRq");

    if (tusotC < string("LdvYCwuKEertVHsRYoYBesvgad")) {
        for (int agcNP = 421619098; agcNP > 0; agcNP--) {
            HfpvgOw = tusotC;
            XwtrbirVZhYG += FEdXSUKVXuObioh;
            OjEKkLaxRhgOf = tusotC;
        }
    }

    return AdobGmyKFrFsWL;
}

double bIhmfcGuRgjr::RQcyIjZfngj(double oeGGT)
{
    bool NnGYfSaOYyXdnuI = false;
    int OftaOeeJmRiVC = 622659251;
    bool omJciUKzrNc = false;
    int ULzjwwWgt = -1922564266;
    double fYTJwMekPMs = 271469.3843014122;
    double uZTBaoVkTHX = -31884.17825063371;
    double buXNeNLTMbALpD = -658306.1076160668;
    int dHNboxFrUf = 1683614647;
    bool WWCgOx = false;
    string sMPZODB = string("mvfqlwhNXKpMgDCCBwYpDntGaRMLORvCMTf");

    for (int GRBfTGQjfoK = 518327872; GRBfTGQjfoK > 0; GRBfTGQjfoK--) {
        continue;
    }

    for (int eIdBssTn = 1485939598; eIdBssTn > 0; eIdBssTn--) {
        OftaOeeJmRiVC /= dHNboxFrUf;
        fYTJwMekPMs -= uZTBaoVkTHX;
    }

    for (int jCUPhoYQKEf = 1984035338; jCUPhoYQKEf > 0; jCUPhoYQKEf--) {
        oeGGT /= fYTJwMekPMs;
    }

    return buXNeNLTMbALpD;
}

void bIhmfcGuRgjr::MpZVtP(int XmrTaGVyhC, int gNFNbiqOIcKV, int WrjBdBrqIC, bool bQYqmkylgVgBi)
{
    int QGBOWXet = 1482210845;
    double seIGXNtyCWq = 82776.44743356327;
    string QtMvBnOqd = string("hLopXobrFKVKEHeYgXSpkIAbMgKOSVcPFYhRoAAgyUrpeWRDjOYxlNrxTRZxvcmBygdzyMyfUEFbIo");
    double vXvOBLNLF = 60624.481420270706;
    double iUdLJbMgv = 758640.1920209222;

    for (int RLNPqZTTnPbBAw = 1817486758; RLNPqZTTnPbBAw > 0; RLNPqZTTnPbBAw--) {
        continue;
    }

    for (int OGyAgEri = 2039815709; OGyAgEri > 0; OGyAgEri--) {
        vXvOBLNLF = seIGXNtyCWq;
        gNFNbiqOIcKV *= XmrTaGVyhC;
        iUdLJbMgv = seIGXNtyCWq;
        gNFNbiqOIcKV *= XmrTaGVyhC;
    }

    if (gNFNbiqOIcKV <= 1482210845) {
        for (int LRKYyhAOBocgkoj = 485685768; LRKYyhAOBocgkoj > 0; LRKYyhAOBocgkoj--) {
            QGBOWXet *= QGBOWXet;
            QtMvBnOqd += QtMvBnOqd;
            gNFNbiqOIcKV *= WrjBdBrqIC;
        }
    }
}

int bIhmfcGuRgjr::anEUxbvqwI(double YiggxbJSE)
{
    double hvdyLAykc = -276736.13293712377;
    string BqGfueTQdw = string("ublaGycLhktTQwLIhbTxLXAPHNjudkZroDewOulasJOSgkngqoonUivUnmYLtqwTcdlmIisqELOouMtTamiCVORjEvwfPmTWcxntZlrmPXDvcaaGnLAhfrfkZQqtZLpTrFmnRgTfZxuUwieCpjcUtVyRcHNvmHJRipOKxyDwGZSwEPNZEoyLcpubuiIFLYSGMjrjsVZHwuZkycJwZrU");
    int sLtLENuZVnk = 2011333835;

    if (hvdyLAykc == 373700.61185332184) {
        for (int DqLfSQekapJ = 976663699; DqLfSQekapJ > 0; DqLfSQekapJ--) {
            YiggxbJSE /= YiggxbJSE;
            hvdyLAykc -= YiggxbJSE;
            YiggxbJSE += YiggxbJSE;
        }
    }

    return sLtLENuZVnk;
}

double bIhmfcGuRgjr::gdMGbMfFKNtP(bool YzfIn)
{
    string JCgdUGEcdhbc = string("YeotJQzDLDZAwQWqPVDGcAzSqWtNyKRSDqcjqMXyNiJZXQKRrUWaXxdGnJTtEGtkAZxOFVXNPxRuCAOJXGskzukdmEKBsVYPddeGADYDwQAexVKZkCpRdSFzUoiTteDsjc");
    int AZorNDmXmKTP = -2055154599;
    double IuyIm = -715214.6484774443;

    for (int lAFvoocaSVGwcqa = 1992258699; lAFvoocaSVGwcqa > 0; lAFvoocaSVGwcqa--) {
        IuyIm *= IuyIm;
        AZorNDmXmKTP += AZorNDmXmKTP;
        YzfIn = ! YzfIn;
    }

    if (AZorNDmXmKTP == -2055154599) {
        for (int rtGleEHp = 1088991934; rtGleEHp > 0; rtGleEHp--) {
            continue;
        }
    }

    for (int ZleyrE = 2047586540; ZleyrE > 0; ZleyrE--) {
        YzfIn = ! YzfIn;
    }

    for (int aqYCZHtWgajlhNko = 701719016; aqYCZHtWgajlhNko > 0; aqYCZHtWgajlhNko--) {
        IuyIm = IuyIm;
        YzfIn = YzfIn;
        IuyIm = IuyIm;
    }

    return IuyIm;
}

bool bIhmfcGuRgjr::canBFuOeLfi()
{
    string DZpebuZ = string("ndCHRcBBkRatfXszpsjMWPLCGTVakZorTZHZaHfJjAgCgWdeiNLNdTeRqGfIYOCtOFzKSKNsFMwtHUyVHZNnqpVKadPhnkwVQUMWuxaXpExZFCpkFGnaYNQTpPVyzAeuPG");
    bool QhqOlxZrjaoorxd = false;
    string YGkqiaNZtR = string("SVUMSzUOQdBklCXCKEtZqKdtcVICprsDEqHlfQsqxDrbNQemXnjsH");

    if (QhqOlxZrjaoorxd != false) {
        for (int GQqHPkf = 804107677; GQqHPkf > 0; GQqHPkf--) {
            continue;
        }
    }

    if (DZpebuZ >= string("ndCHRcBBkRatfXszpsjMWPLCGTVakZorTZHZaHfJjAgCgWdeiNLNdTeRqGfIYOCtOFzKSKNsFMwtHUyVHZNnqpVKadPhnkwVQUMWuxaXpExZFCpkFGnaYNQTpPVyzAeuPG")) {
        for (int yxqsVO = 2126336762; yxqsVO > 0; yxqsVO--) {
            YGkqiaNZtR += DZpebuZ;
            YGkqiaNZtR += YGkqiaNZtR;
            DZpebuZ = DZpebuZ;
            DZpebuZ = YGkqiaNZtR;
        }
    }

    if (QhqOlxZrjaoorxd == false) {
        for (int tzWUSyZ = 273514482; tzWUSyZ > 0; tzWUSyZ--) {
            DZpebuZ = DZpebuZ;
            DZpebuZ += DZpebuZ;
            DZpebuZ = DZpebuZ;
            QhqOlxZrjaoorxd = QhqOlxZrjaoorxd;
            QhqOlxZrjaoorxd = ! QhqOlxZrjaoorxd;
            DZpebuZ = YGkqiaNZtR;
        }
    }

    return QhqOlxZrjaoorxd;
}

void bIhmfcGuRgjr::dBlwyvEyxToEIm(bool gHaLfVzDuqYXcO, string GGVIP, int ZrVAHsXQlzxIfqhz, bool bHBPCPaLNVsh)
{
    double ANQbzJmAI = 443279.41032799956;

    for (int DgKaIIr = 367293768; DgKaIIr > 0; DgKaIIr--) {
        continue;
    }
}

double bIhmfcGuRgjr::gwIrebFTvUft()
{
    string KrjAQcAsxLIANeq = string("AXDscYGqLodwQTngYmREMZTPDOPhJfyJDBasUQrzqrhiLktIBsWEmhKxzUFXnJqXFsrcEpNglgfPvVNIvXTQJZDmoeyvXcZjyFGtOKwknpeqdAgYkZiaVfuQ");
    string UXmIQsETwqkblzF = string("CJCdeLgvQwedLhUtLgmAYrlRsKFuIauHGuIrfjVPJULQwijVyPJJBbFozdyDOZjAstSIAuhhBNphrcwPhFOJZkBqAUAxQvMIpeNydHClY");
    int axpXrkyur = 1005216294;
    int saKRzu = 319121163;
    string fSGsylIhkqKKcwq = string("RpDctsybKandW");

    for (int KFrVysCvHfNYViIR = 927528347; KFrVysCvHfNYViIR > 0; KFrVysCvHfNYViIR--) {
        continue;
    }

    for (int lHTBlDGrvkTSPCOO = 1055087176; lHTBlDGrvkTSPCOO > 0; lHTBlDGrvkTSPCOO--) {
        fSGsylIhkqKKcwq += fSGsylIhkqKKcwq;
        UXmIQsETwqkblzF = UXmIQsETwqkblzF;
        KrjAQcAsxLIANeq += UXmIQsETwqkblzF;
        saKRzu -= axpXrkyur;
        saKRzu -= saKRzu;
    }

    if (fSGsylIhkqKKcwq >= string("RpDctsybKandW")) {
        for (int MUkcDM = 1229959926; MUkcDM > 0; MUkcDM--) {
            UXmIQsETwqkblzF += KrjAQcAsxLIANeq;
        }
    }

    for (int wQiECyzy = 1795279019; wQiECyzy > 0; wQiECyzy--) {
        UXmIQsETwqkblzF = fSGsylIhkqKKcwq;
        axpXrkyur -= saKRzu;
    }

    return -612383.6337187423;
}

bIhmfcGuRgjr::bIhmfcGuRgjr()
{
    this->iVjsyCHOtoJDKipq(string("kxYSRhZbbSRUNgDWCmLBAMzQYZMdWiKaKxVbmMSXPofMExKbMliOeZthLdfpnvgpWGugCmYNPufFSuupXpiPFycfVGkoTPEHfqBQfdeDzeTVynRoCxPmsvfYFKsXeNqLQYTgSHOOwqHdiLluOuJXxXPHrjuUapMuHVauzuzdbMHOLGJIGA"));
    this->kAcohBvonDqZW(false, true, -1782381155);
    this->uLlxdSgQqny();
    this->gNsSKwHfsWNt(-716879.2722036166, -949134.6305814018);
    this->SBQpMmlMt();
    this->JcoTZoJjZYpAx(string("dewPHebsoohFvUaScUXOQdZ"), true, true, string("xRUMoJBmyDCFAFGyrlJRXJKtOKbAldsmNGccUodNqmiEubIeWwjeVkkVpYrOSRkDbecEIBoFtnnRmhCqTnnypreSRNhRpQYXAdGKirxwgkNoFmOvMENsikrjPcKCglSufsTUWwKxBQDzuTwSHddkHBpjyM"));
    this->NWrbT(1446563371, true);
    this->vcKoyFNbRAwjtxHC(889900.3478300808, false, 240505205, -868398.3413330883, string("uZECmqNPeGbIryhnZJFnIwqWWVtnUqsHvfyCnTdSeTpoFsuYUdddSZthryzOknzhpiNCaZPydrdhNwHWyMXmQVRymDOKuUFLehVDUJKvKsA"));
    this->nqCEHIfX(-611910401);
    this->upGOVN();
    this->aLpDReVMeCPsWKe(true, -171134.7729512433, 1734579208, string("xBhkyaTgBHklgvzZXMKENfQhILqadfUeRPrjYb"), string("LdvYCwuKEertVHsRYoYBesvgad"));
    this->RQcyIjZfngj(-57317.91057625648);
    this->MpZVtP(-1322514890, -1359478500, 2137182682, true);
    this->anEUxbvqwI(373700.61185332184);
    this->gdMGbMfFKNtP(true);
    this->canBFuOeLfi();
    this->dBlwyvEyxToEIm(true, string("VZsAQOfIgTaxLAHMUTXCUlgsygJLiPKZgReIMYEzgPxyNIrBIbcCnjuCjsulkAQfpgqiVitRiQlpTgfzyjTxmLyEvQEwHjubxgMjRmWShfqthIgbHkvqApkDfQxFZpnUfmUmkVWQtJsbjgJTEGTrcgFqoRHlBQNLYPVbbKJxksNqtmTxTdPiBCNIPXeOwAZCYEePUOhcRwpzmEgfrJIEshEwfbiqTCOXVBGZZUT"), -2040615494, true);
    this->gwIrebFTvUft();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FedIYLYPrAWhkunm
{
public:
    int kTuqfqXV;
    double KnNUuaDUwMHwgom;
    bool deXljnCSMZDWndYJ;
    bool fLVEDvBOis;
    double CnObceS;

    FedIYLYPrAWhkunm();
    bool sDjoA(bool wJvayhHEaDNRA, bool FppdqFbhuxSsY, int qxVNxbCj);
    void lODijDfl(int rguuQvEvE, double PMQofEkUuXbaB);
    int fhkbZLFJOPr(string jLiBTBQwDTqEV, int PBbbhMB);
    int JBbQBCSBDsvT();
    string qBGJCVzgQQ();
    bool snZAzWCbqe(bool uxANxSsGKt, int YgWqziOpBEUZ, int oNmMNGyBKdwt, string gmDbHkTBfa, bool ZemLm);
protected:
    string njmlJloER;
    int UPiILArrfSNgA;
    string aTZYwBbA;
    int VNTlxmIlolqOt;
    bool zKUymNkCjBqefilf;
    string CzbjhYxwTjcYkOs;

    string eMWpWRWoR(int MFBsEOUugXxu, int OXiwDprhDvjDBEgg, double COqlTk, int TGQJSV);
    void tNOaczSIKAJXJeD(bool XetSIEAD, string KZixgS);
    bool UMTVUBGKnpYxHfX(int vewfpf);
    string zXhrRqXsLLb(double FZIGMOlHxR, string EmKrCJOwDareumt, bool ZUTkX);
private:
    string cJdMHKv;

    double DricBpWcqcXu(int fsfVZwDvTxUADQfD, bool AxjTx);
    double FUVOSoZIySFPriMO(double UBdsCCsUCh, bool rxJYBajUmsGKFhJD);
    int FdxScSkkSmqXifE(string ibrGisrhuZLcKP, int QZrdtTPvsg, string JSaIdwzVf, string DDiZHjHv);
    void GXFkPOtjT(int ZgYYx, bool YMPEKCt, double jnNVGvWNObyVF);
    bool jiLGqm(double vaMflBuO, string vSFEyVXWvtzgsLMS, double KyXKAUUXUNIyW);
    string JpFGQrfWffLMv(int WiXgCKFuidsvX, string KfVAaYC, string WEWsgKrvP, double ZtYpRPufHKCtKwNa);
};

bool FedIYLYPrAWhkunm::sDjoA(bool wJvayhHEaDNRA, bool FppdqFbhuxSsY, int qxVNxbCj)
{
    bool hoOcyaggAHEAw = false;
    bool XJRhwPXtbEaRI = false;
    string QMgsoXxEwxwr = string("ngkckaZSBmINxiJekACmKMVLGalQPWzyjBmOxECOuEMoMnuXwTVLrfzezuayDsSHqMWpmFdTDKwSmzHSImHIwsaOZonBdOKAGonHocmbAPeRNRjgagbQhPMNcOIwGmcHQMmETeLWLZCkYyOkIQxVLoZJzVnfuCjArFRQazWWiAOEpmyAPGuiIqlPAghxuRRlywsckYvBoqfmWlwSMofBWDBvhkmXvrIfzfopIckufcNfJsOfJvhBlJdRNF");
    int ffWYSWiPHajOHxIG = -1561053342;

    for (int DLRUWfCI = 588005612; DLRUWfCI > 0; DLRUWfCI--) {
        QMgsoXxEwxwr = QMgsoXxEwxwr;
    }

    if (FppdqFbhuxSsY != false) {
        for (int eSLRZbl = 520785916; eSLRZbl > 0; eSLRZbl--) {
            hoOcyaggAHEAw = ! wJvayhHEaDNRA;
            XJRhwPXtbEaRI = ! XJRhwPXtbEaRI;
            wJvayhHEaDNRA = ! wJvayhHEaDNRA;
            XJRhwPXtbEaRI = hoOcyaggAHEAw;
            QMgsoXxEwxwr += QMgsoXxEwxwr;
            FppdqFbhuxSsY = XJRhwPXtbEaRI;
        }
    }

    for (int RXEPNt = 1594997375; RXEPNt > 0; RXEPNt--) {
        wJvayhHEaDNRA = wJvayhHEaDNRA;
        qxVNxbCj -= ffWYSWiPHajOHxIG;
        QMgsoXxEwxwr += QMgsoXxEwxwr;
    }

    return XJRhwPXtbEaRI;
}

void FedIYLYPrAWhkunm::lODijDfl(int rguuQvEvE, double PMQofEkUuXbaB)
{
    double dmpUtzM = -100216.79078503653;

    if (dmpUtzM > -100216.79078503653) {
        for (int OtBNiPNaWgMirVrw = 408061365; OtBNiPNaWgMirVrw > 0; OtBNiPNaWgMirVrw--) {
            PMQofEkUuXbaB += PMQofEkUuXbaB;
        }
    }
}

int FedIYLYPrAWhkunm::fhkbZLFJOPr(string jLiBTBQwDTqEV, int PBbbhMB)
{
    bool gptWvDgUlYRllt = false;
    int QLDWCTELj = 1840257330;

    for (int oQCcHcewpJgNpGTe = 1840368662; oQCcHcewpJgNpGTe > 0; oQCcHcewpJgNpGTe--) {
        gptWvDgUlYRllt = gptWvDgUlYRllt;
    }

    return QLDWCTELj;
}

int FedIYLYPrAWhkunm::JBbQBCSBDsvT()
{
    string uBBoyKlhjvQRy = string("fogJWWEcDMitdWkmavbBmttIfoBuWgwEgDqBVjcBDsnqncHfxfOilWSRnTQsrtCko");
    bool AEkKOWEzKKaXTNf = false;
    string zoQuvnDsIrNBTJ = string("iOrXFkL");
    int zxKsaFffLa = -1968221077;

    for (int houJxSSgeXtFbkC = 281187176; houJxSSgeXtFbkC > 0; houJxSSgeXtFbkC--) {
        zxKsaFffLa -= zxKsaFffLa;
    }

    if (uBBoyKlhjvQRy < string("iOrXFkL")) {
        for (int cCGYIUfXZ = 548578243; cCGYIUfXZ > 0; cCGYIUfXZ--) {
            uBBoyKlhjvQRy = zoQuvnDsIrNBTJ;
            uBBoyKlhjvQRy = zoQuvnDsIrNBTJ;
            zoQuvnDsIrNBTJ += uBBoyKlhjvQRy;
        }
    }

    if (uBBoyKlhjvQRy != string("iOrXFkL")) {
        for (int nSmtj = 553717634; nSmtj > 0; nSmtj--) {
            uBBoyKlhjvQRy = uBBoyKlhjvQRy;
            zoQuvnDsIrNBTJ = uBBoyKlhjvQRy;
        }
    }

    return zxKsaFffLa;
}

string FedIYLYPrAWhkunm::qBGJCVzgQQ()
{
    bool XoklLiVUxeT = true;
    int AZFLBNZRBAFtToy = 614888763;
    double UzwIsXPilcKOmQf = 824360.9172301564;
    string zZscgAOiAj = string("QNzdCxDqYiMcqjUnqyiDVYioVSskCtXbYWVXYzojadlqkwDUPcMJBIcUrLIANBCFpCHOGkvZxWOBakLgXwElNadQteeEWLSSxtoElOhXQVunYzyeXqzoWLHbdfbHZBws");
    string QMGMCg = string("rNADUKNpPUyvAIvdQDrcgCzPWWSgkrfsYAlVsgrRYZzKtWAXbyhnQvzdOzVSuGWlYdxljLCTcFZQTZMsuCrTddVsrEaeBwIQOFgibZvJjlrcVYXiPEyKfDoSiFWCqWSHnQKoUBDThUiQiAeTGXrwgGjWPWcpRmPbMTnEksuCDghBgNblxYYpJkPFqwcrNTCaxJauuxPHfjDBBjfhPMITUmxXCKOnvHpsYoB");
    string sTQWlqTMggtSZKOS = string("ZNYOpFcRbpItgjBUTQrdZXeNKXSHZuXsUSgyxPXjLwmsoWheCjUbManUhheoAQbECbrIlSLAJWsgbaBuwATpfZTuEPpsdKYRwUqAzrzuerqSwTXetmaJlHlSVPYWWwucydtYMHFlEWeNVqWgbpalnllvzTmlEyuQNSDsTwRUVtVINYP");
    string SuOHcruuNiKUo = string("zYhhslHaTfHhQYbXTdPEDqEcmQgGJTOHotqzGxfOLpZHJgAAHUpnMvzFuHFTBKbyAtuZHuklsCaRrBOhqsskJFyQOakaWfbVmpzYPsZaqAvlVdqtTikgYXlrzcnyPAgiWQaVNnGNVfedOAk");
    int gniKDitqpzON = -481688274;
    double GVTSHyBOYBNbp = 1039279.1147583299;
    int FEKpByKfrIuVgx = -44172090;

    if (sTQWlqTMggtSZKOS < string("QNzdCxDqYiMcqjUnqyiDVYioVSskCtXbYWVXYzojadlqkwDUPcMJBIcUrLIANBCFpCHOGkvZxWOBakLgXwElNadQteeEWLSSxtoElOhXQVunYzyeXqzoWLHbdfbHZBws")) {
        for (int PthRkt = 1823857780; PthRkt > 0; PthRkt--) {
            sTQWlqTMggtSZKOS = zZscgAOiAj;
            SuOHcruuNiKUo = sTQWlqTMggtSZKOS;
        }
    }

    return SuOHcruuNiKUo;
}

bool FedIYLYPrAWhkunm::snZAzWCbqe(bool uxANxSsGKt, int YgWqziOpBEUZ, int oNmMNGyBKdwt, string gmDbHkTBfa, bool ZemLm)
{
    string uJbYNOHG = string("XqoykLEpcGSXiJruFUQaYNIaHDZzdYaWfrZulhOwysuLNxpoYFcTkuTsvHDNrCgboLkHPvsUHGYLInveOMfUpfkDTdTTtPUJyRyfjLHyJelxrZxpKhPnrPngxINeyLCXMfbuguoqLjXZWpdDNKJyUpDENNPOQQVqaSBUVlBwslBBlbWgbnsTSYrIakkghjziPbSDOXdoVgymkycNdjbXfRF");

    for (int qZwcusl = 1695045229; qZwcusl > 0; qZwcusl--) {
        gmDbHkTBfa += uJbYNOHG;
        uxANxSsGKt = ! uxANxSsGKt;
    }

    return ZemLm;
}

string FedIYLYPrAWhkunm::eMWpWRWoR(int MFBsEOUugXxu, int OXiwDprhDvjDBEgg, double COqlTk, int TGQJSV)
{
    int hEaMOtggaM = -585529695;

    if (OXiwDprhDvjDBEgg > -585529695) {
        for (int zjNnttDpUeG = 214902472; zjNnttDpUeG > 0; zjNnttDpUeG--) {
            TGQJSV = hEaMOtggaM;
            TGQJSV /= MFBsEOUugXxu;
            TGQJSV -= hEaMOtggaM;
            hEaMOtggaM *= TGQJSV;
            OXiwDprhDvjDBEgg -= hEaMOtggaM;
        }
    }

    if (TGQJSV < -1302471667) {
        for (int sUMqlAaRFnmF = 2062492941; sUMqlAaRFnmF > 0; sUMqlAaRFnmF--) {
            hEaMOtggaM -= TGQJSV;
            MFBsEOUugXxu = hEaMOtggaM;
            COqlTk = COqlTk;
            hEaMOtggaM += hEaMOtggaM;
            OXiwDprhDvjDBEgg -= TGQJSV;
        }
    }

    return string("qHEKZOFxeVWoOMjZKgEHtoeuQsVBVzfFrabtSGODlnkvIpFUZfnQDsRXOPTqHwWHAEvaqZctsIdGiqmfiVTnHEvhaxTLYvheUQq");
}

void FedIYLYPrAWhkunm::tNOaczSIKAJXJeD(bool XetSIEAD, string KZixgS)
{
    double ehAMUKFtCtVnXG = -444961.05969019036;
    int jhsRZQPeANzP = 1242272970;

    for (int dUEFmlsfjVtMUiWC = 1659509391; dUEFmlsfjVtMUiWC > 0; dUEFmlsfjVtMUiWC--) {
        continue;
    }
}

bool FedIYLYPrAWhkunm::UMTVUBGKnpYxHfX(int vewfpf)
{
    bool kfNDgWSwGxc = false;
    double oPYFUb = -201601.5115653978;
    double dJraTVxPThijshR = 181914.19941478898;

    for (int cKjkzNm = 308832870; cKjkzNm > 0; cKjkzNm--) {
        vewfpf *= vewfpf;
    }

    for (int mAiHQEbfRQXsN = 1500061693; mAiHQEbfRQXsN > 0; mAiHQEbfRQXsN--) {
        kfNDgWSwGxc = ! kfNDgWSwGxc;
        oPYFUb -= oPYFUb;
    }

    for (int xXEHLspdLQWw = 1871628505; xXEHLspdLQWw > 0; xXEHLspdLQWw--) {
        continue;
    }

    for (int WgrcNBeYZhHMQi = 1344638174; WgrcNBeYZhHMQi > 0; WgrcNBeYZhHMQi--) {
        oPYFUb = oPYFUb;
        dJraTVxPThijshR = oPYFUb;
        kfNDgWSwGxc = kfNDgWSwGxc;
        dJraTVxPThijshR = dJraTVxPThijshR;
    }

    for (int fRSWwflJGf = 2104151335; fRSWwflJGf > 0; fRSWwflJGf--) {
        kfNDgWSwGxc = kfNDgWSwGxc;
        oPYFUb = oPYFUb;
    }

    return kfNDgWSwGxc;
}

string FedIYLYPrAWhkunm::zXhrRqXsLLb(double FZIGMOlHxR, string EmKrCJOwDareumt, bool ZUTkX)
{
    string OBIzLIsBNbQbjfU = string("wZcjXIQNlRUQEvXfpzzGhhGgbFkmpNOHxwyoPWXzRjxKQmfUCVIGnxPmREdVwVCKmvNaIDOZTHgQJGRSlgBty");
    string sVoHgYKYTNSK = string("atxHoWpCLwNIUgMgHeiPicjeAegqmPmmNoQRpiidXbAfGXSonXchjnQKvXmtvHAcWppHVMSkpqDuEyAGqGEhOEtLviigvhTWFXfcydCDwUThEIKZ");
    bool MhFgsaiPEPmgnCy = false;

    for (int cpKixyqEFEC = 1337783175; cpKixyqEFEC > 0; cpKixyqEFEC--) {
        EmKrCJOwDareumt += OBIzLIsBNbQbjfU;
        OBIzLIsBNbQbjfU = OBIzLIsBNbQbjfU;
        EmKrCJOwDareumt += OBIzLIsBNbQbjfU;
        OBIzLIsBNbQbjfU = sVoHgYKYTNSK;
        MhFgsaiPEPmgnCy = ! MhFgsaiPEPmgnCy;
    }

    for (int SMrxRdfVUW = 1682739758; SMrxRdfVUW > 0; SMrxRdfVUW--) {
        OBIzLIsBNbQbjfU += sVoHgYKYTNSK;
    }

    for (int bUJBweuPTwBd = 597705101; bUJBweuPTwBd > 0; bUJBweuPTwBd--) {
        ZUTkX = MhFgsaiPEPmgnCy;
        sVoHgYKYTNSK += sVoHgYKYTNSK;
        OBIzLIsBNbQbjfU = OBIzLIsBNbQbjfU;
        sVoHgYKYTNSK = EmKrCJOwDareumt;
        sVoHgYKYTNSK = sVoHgYKYTNSK;
    }

    return sVoHgYKYTNSK;
}

double FedIYLYPrAWhkunm::DricBpWcqcXu(int fsfVZwDvTxUADQfD, bool AxjTx)
{
    bool AZJkYWrnVIUnjfV = false;
    double ILvWBAFY = 137827.46648494844;

    return ILvWBAFY;
}

double FedIYLYPrAWhkunm::FUVOSoZIySFPriMO(double UBdsCCsUCh, bool rxJYBajUmsGKFhJD)
{
    bool CfPeTBFxPkkmEl = false;
    int qZZtianwgYVP = 795256262;
    bool QygXFBhwjZzbeuUX = false;
    string wLXbiQE = string("kbNwLWHjkPrSKsCAuovbTPzBpEpKiVPGHrGlaVXFlSFGnOhrXidxypgYFVRpDaNkvFBdQQolInsQfBpMjLnIfShXEDxQYwBpRWnCsBLirpHKnfBnxbtToGCNcJKBFOCYQsaEdYuPWWRSzHAlscnkHQaMCAOwIJlevyOBOvsqaAKHbmMXB");
    bool LbamNZagJJwfEqjd = true;

    for (int IuovokPQNPLiVwk = 1384365411; IuovokPQNPLiVwk > 0; IuovokPQNPLiVwk--) {
        QygXFBhwjZzbeuUX = QygXFBhwjZzbeuUX;
        rxJYBajUmsGKFhJD = ! CfPeTBFxPkkmEl;
    }

    return UBdsCCsUCh;
}

int FedIYLYPrAWhkunm::FdxScSkkSmqXifE(string ibrGisrhuZLcKP, int QZrdtTPvsg, string JSaIdwzVf, string DDiZHjHv)
{
    bool bLDudwEH = true;
    double niuEhdMlxLrc = 663050.5030371554;
    bool RtLKFQAFIVacLCOQ = true;
    double PSoKcYghDejqykQA = 618665.5752861708;

    for (int qYElKFBr = 167949128; qYElKFBr > 0; qYElKFBr--) {
        ibrGisrhuZLcKP = ibrGisrhuZLcKP;
    }

    if (JSaIdwzVf == string("jdERcdfFxJJrMCBTKbITiToPaeCAeXOZziOFUMZWVRTAxeltykYFMNTvCvvWvCQroiloJwSiyVJlNRhJuIJdntrFpGcDCBNIYwXRhSZkmdIhnjXQuTdKPkDVvJCeWSuxKzhvgVVaEiGEQZdOnNlABAWfDQXktgiDvyAyLShXsWervppwBxgIsZjKfcOzHEsnYjktvthvVGwxwUIIKadqlFsrFcAEUzebIJBabvFduP")) {
        for (int ccbcjOrG = 2083900452; ccbcjOrG > 0; ccbcjOrG--) {
            continue;
        }
    }

    if (PSoKcYghDejqykQA > 618665.5752861708) {
        for (int MjvcA = 107386527; MjvcA > 0; MjvcA--) {
            JSaIdwzVf += ibrGisrhuZLcKP;
            niuEhdMlxLrc += niuEhdMlxLrc;
            DDiZHjHv = DDiZHjHv;
        }
    }

    return QZrdtTPvsg;
}

void FedIYLYPrAWhkunm::GXFkPOtjT(int ZgYYx, bool YMPEKCt, double jnNVGvWNObyVF)
{
    bool YkGvyi = false;
    string XEHYKBNrPMIDtD = string("bZXUNfDfQQWuUyqRuBFJBoayRmPrzqNaPxivNDiVAjWrjtfFlDurYYpRxnlDccAlRWAEVltntSNNFZnkwlwbihRdMwysfmJlkiNKIZGDdMMllxifAFoqRWrHwWhVqNCRGJZVIaKiKoowzJnVlnSLeOPwXFlPdXrNaYQowzdebPzXObzNpRqIeuzkXXoPsZqtSXSjIQtRmwlO");
    string zifFRXjSvVvx = string("abtzgfwaqyglECDplzLzeMVePxecVcemxaaGbPufxtlOdiEgokrKifVteigizAhtYLGmQzjEIZDPHEKhckXgAwrjBqpPwvXYtIcnSmycgsWAQqCDHlcUJlmFgYzxfsJbfMURuMIBF");

    if (XEHYKBNrPMIDtD != string("abtzgfwaqyglECDplzLzeMVePxecVcemxaaGbPufxtlOdiEgokrKifVteigizAhtYLGmQzjEIZDPHEKhckXgAwrjBqpPwvXYtIcnSmycgsWAQqCDHlcUJlmFgYzxfsJbfMURuMIBF")) {
        for (int kcoXdbK = 720128161; kcoXdbK > 0; kcoXdbK--) {
            ZgYYx *= ZgYYx;
            YMPEKCt = ! YkGvyi;
        }
    }

    for (int OJetbLxpfkqoKGFA = 114750674; OJetbLxpfkqoKGFA > 0; OJetbLxpfkqoKGFA--) {
        YkGvyi = YkGvyi;
        jnNVGvWNObyVF -= jnNVGvWNObyVF;
        XEHYKBNrPMIDtD = XEHYKBNrPMIDtD;
    }
}

bool FedIYLYPrAWhkunm::jiLGqm(double vaMflBuO, string vSFEyVXWvtzgsLMS, double KyXKAUUXUNIyW)
{
    bool zsOYixqJ = true;
    string ODahUPyOibPUpM = string("zQUQAiUIHBbMKALPqvVcXFMtsQaPMiKbdIVvZQaUNbzqznRNGOpiiLSCZiOhmjNXpqEakQYccwkeJ");
    string HbgcfXUepL = string("rzGtZjWmZnQGrZySTlucSJLJnlmKMbHzJnXDNSIdMmGnkRojjdVJZpDNHkktDeGPmOoCrvZPZeZctnyuPtXeztKubrErMucZEHcQSAqAfvliLcUPgdOnlXHjRcpyGZzjZSjsRcMmq");
    int hhrsUnY = 40918521;
    int EEZxQeJneNF = 1145088665;

    for (int MGIiyzaUhWhUPcC = 967895353; MGIiyzaUhWhUPcC > 0; MGIiyzaUhWhUPcC--) {
        continue;
    }

    for (int bDgnwqavlWCfM = 336002023; bDgnwqavlWCfM > 0; bDgnwqavlWCfM--) {
        continue;
    }

    for (int ciWXHpJbgcgy = 885737431; ciWXHpJbgcgy > 0; ciWXHpJbgcgy--) {
        zsOYixqJ = zsOYixqJ;
        HbgcfXUepL += ODahUPyOibPUpM;
        HbgcfXUepL = HbgcfXUepL;
        EEZxQeJneNF = hhrsUnY;
    }

    for (int MFLkARLuDfPVep = 1991290211; MFLkARLuDfPVep > 0; MFLkARLuDfPVep--) {
        continue;
    }

    return zsOYixqJ;
}

string FedIYLYPrAWhkunm::JpFGQrfWffLMv(int WiXgCKFuidsvX, string KfVAaYC, string WEWsgKrvP, double ZtYpRPufHKCtKwNa)
{
    string IVarijIiIZE = string("ymvlntGpkFuFDqDInEEJReVKjQIzAfUHPYvJHcCeMlubyvOdPpwiZtrZSvUSBsGrzavaVpwtSVyzYOci");
    double MzJvYvsOOphF = 19969.90101937529;
    int MfiSFcYeLDBj = -1815955727;
    bool lbzZWqQW = true;
    bool SCYqtHaZ = false;
    string dAzjLIetlqigSc = string("rKAaZMvbmugnxvxrZAJHIRmiiAyfvcsNIypegmvevJQaoaahgDGbUBdXCasKZtErXIkHdQwXLWiaRqDYsQBpEckgXGDzEnOTTjEoYHgdEmHOMUDhbVdIXKQXwKIzZpVhBHguVyuSfLaJDrjXvBdf");
    bool wvAdMgHEx = false;
    bool rnQqLuFsbT = false;

    for (int NrcFSb = 488276223; NrcFSb > 0; NrcFSb--) {
        WEWsgKrvP += dAzjLIetlqigSc;
        wvAdMgHEx = SCYqtHaZ;
    }

    return dAzjLIetlqigSc;
}

FedIYLYPrAWhkunm::FedIYLYPrAWhkunm()
{
    this->sDjoA(false, true, 1314090556);
    this->lODijDfl(-2032385375, -931412.7538237753);
    this->fhkbZLFJOPr(string("VULZcNYlbyuXXEuSRfcUDBiwNoaEZxvDBSyNCjnrDeHXNziHCsZdtJkN"), 125696519);
    this->JBbQBCSBDsvT();
    this->qBGJCVzgQQ();
    this->snZAzWCbqe(true, -257484819, 469564246, string("JVMgnQSlAGVi"), true);
    this->eMWpWRWoR(-1302471667, 493278962, -515973.71341079223, -649404767);
    this->tNOaczSIKAJXJeD(false, string("fcicarOqeOfKpcRyBDClWPBVVKyUlCTvRdONcyplOWeuRMAjdUPsOpIoSsyDzbCPxiLLphaynFCkdrsStMIHBoGvnmZuHPYbHXugcVrLrWdvYJxiraRfKkKIdn"));
    this->UMTVUBGKnpYxHfX(1636474173);
    this->zXhrRqXsLLb(351585.29008618963, string("PBqojDAZXbWYNwulJiHAdbfFAIhKjpkOfCsuezMaepDIfYrrrzushNHKetJSgthVyvQCuOUtOIwPEFxVQmYwbhEQLmjPlDteTNBnAzgWTABAbEEfGSmyLvHNQUMuhcotpsXec"), false);
    this->DricBpWcqcXu(-921971217, false);
    this->FUVOSoZIySFPriMO(270878.71534975665, false);
    this->FdxScSkkSmqXifE(string("uDdbGieLaAUJXkuWoNcUbCBEyKkWqEotOSkEanoUMZaSOXaUHs"), -694277273, string("GGqmXwxgYQISGyqaGCtWWnFiNJKpiooqveczyfpTogpTDOnjIjiLRmYNHZdAyHSkOqbkommjNGVRaMYpRBJorzNysAXoNAFt"), string("jdERcdfFxJJrMCBTKbITiToPaeCAeXOZziOFUMZWVRTAxeltykYFMNTvCvvWvCQroiloJwSiyVJlNRhJuIJdntrFpGcDCBNIYwXRhSZkmdIhnjXQuTdKPkDVvJCeWSuxKzhvgVVaEiGEQZdOnNlABAWfDQXktgiDvyAyLShXsWervppwBxgIsZjKfcOzHEsnYjktvthvVGwxwUIIKadqlFsrFcAEUzebIJBabvFduP"));
    this->GXFkPOtjT(904966459, true, 966243.1081541383);
    this->jiLGqm(-140149.2673110902, string("LRuOjThtbxvwwxRadRNVuSKrXgBWVVxagZfaLhtWIKFoaKkfClykTUJglqMowLbGdHomIXpQAyxujakAsdlCQg"), 957599.0162937797);
    this->JpFGQrfWffLMv(-926137362, string("HCElXPrPJQEDBRnoOjrFeEmyCMnTVUBEBcORjrXRemfGIsGJWOewsqfkJaSTzbyyMKPtNZjZGnabzAkMVmRDsZdQsKpGaeFFhDrHZFrLlklQkbvvOpfwgBUILOmBXMxQygPnjLmpIbRvCeolXLDliwknosMBZBHziYEuRZHIgLyaHnYFrwbopnPzOAzAKOKTKDkmBOYgwuZcpDJRnIGPJEZ"), string("MyTpJiprYnKfkjNtFzifPQukfrXWzsfqLmiNMmYRzYSTdcjMPafMzfzwFjxNZPgxduHBixvZJXOKzDgzQoaIXXxZBEmHNboHKYrlfFYtyMXEtPZggoIkALbqgRlOGzQheRDQzDXncHYoHHtmSqwTlebtNktxcgpOfACBMHmJZDoRzcQtFAtQbfhIHQazmgHsNvDnmaGplfdVOMllQJQlqZnlulfaPDfesLbyZEaWL"), -1025923.163073987);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eakkjJfTOODSb
{
public:
    string TlFxE;
    string NnaPxrnSs;
    string HAHqLEQfBrx;
    int TmTQzmyv;
    int UVFwGvVtIXq;
    bool phJAeeIJViY;

    eakkjJfTOODSb();
    bool YztqvyHkf(int FcxrQOB, string KyHeXDZaFQ, bool jrwwqtXspHVaB, bool TrNJXvVrrzVwB);
    void YQAtZGUdBXLxKQh(double FwptLAnzxEmkk, int WtGze);
    void cbrswXN(bool dGqScRQgAHJbohX);
    double JsMDZIN(bool TxtqlYTVmVspx, int AHbuKOUm, bool ZhAYJPhRJRm, bool uWLXoTTAVclCjv, int RZpUNnKhbgF);
protected:
    double BAdazgLvTkAbb;
    bool vWviPmrzj;
    bool uuhKfNAGsL;
    int gQdDNKJKPMLqo;
    string VgdcVpra;

    double qqfCf(bool LwesrG);
    bool gNsEVoVrolVLvyH(string CPVRXc, int UxEKhYtcl, int htUnzq, bool FAWrEZE, int aJxyC);
    string nDyVZljqlj(bool rhpORuB, bool imHVWf, bool qXgwxAnMXV, double vGMVckmjyrrhPbD);
    void nBadgS(int NMYffIDP, double NCTOAqJ);
    int cLqnIUUPTxB(int sKNfb, string rdXiWnaxDTSZC, double cXyevr, double ROopNxJA, double WbYOWmrNMCJv);
    void laUCEMTO(string UIgfopIRqUVWxc);
    double AEfhkwxLnNdBL(double ANgLkOsyuDL, string mTXUPsFN, double mzsphOcAT, int YuJaIts);
private:
    string hFWZG;
    string VWoVTlGlVqU;
    bool NUIozk;
    int TFRZVg;
    bool tGstARWxsAqDuuL;

    double ukuzGWUYrZxnfe(string zrCAH, double TXJedE, int QCPNKyOGUrIYZYR, int QKoxLMOEXfFKnN, double lFgaKi);
    double uVJhvBSyDkrIA(int ZVqsRXVNdNQBaJA);
    bool anqwCLGoaIz();
    bool rlSCiH();
    string haBIwXhSptDhYi(string OWRkvsuHlackhv, double LocWjYVZ, int oXMUoQKkWP, bool uQmaTKNSed, int ynibDiJvzzKSwNFB);
};

bool eakkjJfTOODSb::YztqvyHkf(int FcxrQOB, string KyHeXDZaFQ, bool jrwwqtXspHVaB, bool TrNJXvVrrzVwB)
{
    bool KlpqZO = true;
    double VrKdx = -203881.2211992565;
    bool FrmRLlRK = false;
    int dJXmXcjoUmbmrUB = 2111299044;
    double fXWPwIhAW = -355901.1455290111;
    bool xtJLiJVyKsdwNOb = false;
    double JNdXgzTxOsjpUz = -914177.7806101888;
    int ztpeZ = 1284942484;
    bool ypZYQisRwEOqZx = false;
    string jTcSSIdmDGFLbqQv = string("XKPVKhjvmQdmFwYndeRBYezJYhUfIVINitryQumbtnrociSQvwGbNXfbrSkoAtbtQwLlgNeBHqtJAnVYDMfhQzLzponxXdMbJ");

    for (int SOcddaMhvFHFa = 243059928; SOcddaMhvFHFa > 0; SOcddaMhvFHFa--) {
        continue;
    }

    if (KyHeXDZaFQ > string("YBlOsYpoGERMMuPzaTYylHyQmDgfrzciLKAQeVutVYVDVughfOgMJUEGGnUujARsdxasztPxgRElgKEaUreYhhxxuYJJacyHkbpJfBgtQtuKRjAYhzBMvxOtvaaK")) {
        for (int HvbeScon = 1662339785; HvbeScon > 0; HvbeScon--) {
            TrNJXvVrrzVwB = ! KlpqZO;
            KlpqZO = jrwwqtXspHVaB;
        }
    }

    return ypZYQisRwEOqZx;
}

void eakkjJfTOODSb::YQAtZGUdBXLxKQh(double FwptLAnzxEmkk, int WtGze)
{
    int GjnqTC = -677502521;
    string BzchEXqSIxFrdOuP = string("SpLDSrOhtKLY");
    double lzMZpeunTjulWJ = -972968.6676365358;
    int CRaCBJzbiIG = 976192585;
    bool OHTYlUC = true;

    for (int CNNmMtJ = 2035103982; CNNmMtJ > 0; CNNmMtJ--) {
        lzMZpeunTjulWJ *= FwptLAnzxEmkk;
        OHTYlUC = OHTYlUC;
    }

    if (CRaCBJzbiIG != -1857080790) {
        for (int ppyPlMwyzs = 737202264; ppyPlMwyzs > 0; ppyPlMwyzs--) {
            FwptLAnzxEmkk /= lzMZpeunTjulWJ;
            FwptLAnzxEmkk /= FwptLAnzxEmkk;
            GjnqTC -= CRaCBJzbiIG;
            CRaCBJzbiIG -= WtGze;
        }
    }
}

void eakkjJfTOODSb::cbrswXN(bool dGqScRQgAHJbohX)
{
    string Kkxnai = string("OjPMWkUcDADgnBLhMMdAxwUnukxXifpMgK");
    double oeGzlUBe = -73224.52003663027;
    bool vXCxqu = true;
    int CMrXmjqDBSAu = 1294709927;

    for (int sdVnoHOREqTb = 1104409976; sdVnoHOREqTb > 0; sdVnoHOREqTb--) {
        Kkxnai += Kkxnai;
    }

    for (int PdvbgtcAGPeZ = 592610813; PdvbgtcAGPeZ > 0; PdvbgtcAGPeZ--) {
        continue;
    }

    for (int vwQVFukMZDQfEZ = 728192431; vwQVFukMZDQfEZ > 0; vwQVFukMZDQfEZ--) {
        Kkxnai = Kkxnai;
        dGqScRQgAHJbohX = ! dGqScRQgAHJbohX;
        Kkxnai = Kkxnai;
    }

    if (dGqScRQgAHJbohX != false) {
        for (int MHlRkbxokMYzcB = 893538160; MHlRkbxokMYzcB > 0; MHlRkbxokMYzcB--) {
            continue;
        }
    }
}

double eakkjJfTOODSb::JsMDZIN(bool TxtqlYTVmVspx, int AHbuKOUm, bool ZhAYJPhRJRm, bool uWLXoTTAVclCjv, int RZpUNnKhbgF)
{
    string FBfZcLEG = string("csxMvVoMdxgfFeeDGmHUTdNippFqdj");
    string cDokYmiULWaH = string("HOCTCklvICBLROjqaLwbftFowSRFpUebPmiNbBAIOfjORAjKuDbLZnnTKKEQcWyUMCsUhrwYqoTKaunbySHMMPNrxseWFvfxIxrEzLIScThMAKCHGTJKvlXOchaJBTCXsGSIRDptOXuJhSXsTELcDVwjrmWkbNizWYsSbrGJWpTVjuSkwXOnpnbGCbRenIIPQZEZKluYnOUjZPFkVxOESDHxBCDMEiZCXFNiipHGwuoeVMMXazq");
    string RxmbGFF = string("QnAZREiOAqFuUTCyRXGjmweOOKSeesGGYlunrQXIugeEehWzKvXPqIkvPqeBgXjCcA");
    bool FCWQdvSbwJDDR = false;
    double JGSrxPuNI = -652101.3367089172;
    double wyyPWQOgkWq = 961881.6863550335;
    double gclOpJWq = -433598.5190089276;
    bool dQnaULHAlwsNnvxa = true;
    bool pqRtBc = false;

    for (int JEKsXUvVsBJn = 923446003; JEKsXUvVsBJn > 0; JEKsXUvVsBJn--) {
        cDokYmiULWaH = RxmbGFF;
    }

    if (TxtqlYTVmVspx == false) {
        for (int uKSvUEwwgGR = 2106853722; uKSvUEwwgGR > 0; uKSvUEwwgGR--) {
            continue;
        }
    }

    return gclOpJWq;
}

double eakkjJfTOODSb::qqfCf(bool LwesrG)
{
    bool MfAauAmQVQDYKO = false;
    bool mGhMOkVtwRgb = false;

    if (MfAauAmQVQDYKO != true) {
        for (int OlLrwolQcdKeb = 399606854; OlLrwolQcdKeb > 0; OlLrwolQcdKeb--) {
            mGhMOkVtwRgb = LwesrG;
            LwesrG = LwesrG;
        }
    }

    if (mGhMOkVtwRgb != false) {
        for (int VRqdbZhcATODw = 1117070244; VRqdbZhcATODw > 0; VRqdbZhcATODw--) {
            mGhMOkVtwRgb = ! MfAauAmQVQDYKO;
            MfAauAmQVQDYKO = ! mGhMOkVtwRgb;
        }
    }

    return -662583.0302327465;
}

bool eakkjJfTOODSb::gNsEVoVrolVLvyH(string CPVRXc, int UxEKhYtcl, int htUnzq, bool FAWrEZE, int aJxyC)
{
    int gOSNXwJb = -1922747096;
    double RRPBuPS = -783936.2833719124;
    int dzxIgPRyL = 1105430955;
    string XbdzrW = string("SRHXHsfGLVkholBpggvdJmbBMfdYagqnPFpQtlYVCbjTFbRenddBkKDKxPhysYlmGgAxnFCYTAuZCCCCeIdzWXljslARxlAsGBYIGDkRDlcxlmxqOEmqPyzHUGkWqIiRgvvktCfcMiqiijLJdBkLHFShVcvWzJbEeQ");
    bool cSrDctVZXaFlFzwq = false;
    string bIOdUrAL = string("ajqaCBWDkufiOcopBEmRoCTGptNmSgoqmeYXrjGpjPfhRlZjuEwaBZtVAbFNOIGJXidkNnLnCxuQghLWszSilGINtqkgdObCOE");
    int wSSMpX = -942452256;
    int ItOjxeRSlh = -759213958;

    for (int teRZnVleZwNae = 1727784149; teRZnVleZwNae > 0; teRZnVleZwNae--) {
        UxEKhYtcl *= UxEKhYtcl;
        RRPBuPS *= RRPBuPS;
        aJxyC /= aJxyC;
        aJxyC *= ItOjxeRSlh;
    }

    for (int fhihUiauDdLnDR = 1596822280; fhihUiauDdLnDR > 0; fhihUiauDdLnDR--) {
        wSSMpX = dzxIgPRyL;
        UxEKhYtcl *= wSSMpX;
        htUnzq -= aJxyC;
        XbdzrW += bIOdUrAL;
    }

    for (int cdZzCxW = 1955513894; cdZzCxW > 0; cdZzCxW--) {
        XbdzrW += CPVRXc;
        aJxyC *= aJxyC;
    }

    return cSrDctVZXaFlFzwq;
}

string eakkjJfTOODSb::nDyVZljqlj(bool rhpORuB, bool imHVWf, bool qXgwxAnMXV, double vGMVckmjyrrhPbD)
{
    double XYcQz = -823979.3262974141;
    int LYgFiQcfMY = -1355284709;
    int XQCIyFawsRvz = -1703547456;
    int VpMMvyfZpygOuJQ = -843871802;

    for (int KbbVKSfWVAJtlbD = 1238095965; KbbVKSfWVAJtlbD > 0; KbbVKSfWVAJtlbD--) {
        VpMMvyfZpygOuJQ /= LYgFiQcfMY;
        VpMMvyfZpygOuJQ /= LYgFiQcfMY;
    }

    for (int QjwiqdZwn = 1987199839; QjwiqdZwn > 0; QjwiqdZwn--) {
        imHVWf = ! imHVWf;
    }

    return string("ltPaKweiMTVWjgjpkaLRlYLDRrjLZPfbnHKHMFlGPDYCXsysJJjbHNyFahlrFlYpaNszHJtnvrQccKuNfnApEgbJjneTdNMuBKsfPtkWWAbXrQUqckctYdKprLxipUpuWqJakBzLgsauKyvyFmyfYrlzNmiMJiGarmAQkrwMLGKEbgkLtHDylgJbJMGFJRpfqFewytHqwsMQImRaEzMzkoQgcNzJAsnyjnORJyPOUrsfVXWnMfDKyFehKLAKZC");
}

void eakkjJfTOODSb::nBadgS(int NMYffIDP, double NCTOAqJ)
{
    string wQnHrmjsvInxIO = string("JLrbEbcRPdfjMykfiOiyaWmUUEdgYwLUnBkmMptQQNZJdfmAMemWjOvOvgVYeOceuPzIHykMFhLhaJrGbvyjbdRyGmT");

    for (int ChrYqymVVUUVqSGX = 1844004038; ChrYqymVVUUVqSGX > 0; ChrYqymVVUUVqSGX--) {
        continue;
    }
}

int eakkjJfTOODSb::cLqnIUUPTxB(int sKNfb, string rdXiWnaxDTSZC, double cXyevr, double ROopNxJA, double WbYOWmrNMCJv)
{
    bool ycoeaQdZBkGvPkmE = false;
    int VgzbbYHSinLCJ = 1154423007;
    int WDWbhxquHdfqlLr = 246535809;
    string GgjZnn = string("JujIAaiujOHsfhPvMRuUlsYixQoAZMYIlfqIkcjCfzL");
    string XuUTTPEjAzufswS = string("LRRBlMRcRFxooCATJmcVByrbDHtOldUnvRhTCWrphIbXDjBVpRTjeWOvSNDVEbnAuXqlJQqcLultCwQPgoCAOnVeMXdxRbaVGCqtyQuRpZLmkGcYdvkAOYweotLeMTLqCcNsscrQyTKgtpgmsSwJlUpcf");
    double OpOaWUEcYLyqr = -785224.08145882;

    if (GgjZnn >= string("GoaEYkZIfcIGUlCFee")) {
        for (int FefWjrAdmBZTQajm = 993405799; FefWjrAdmBZTQajm > 0; FefWjrAdmBZTQajm--) {
            continue;
        }
    }

    return WDWbhxquHdfqlLr;
}

void eakkjJfTOODSb::laUCEMTO(string UIgfopIRqUVWxc)
{
    string ASqjoXpuRtkiegm = string("ohkuoua");

    if (UIgfopIRqUVWxc >= string("OndRqqAbyaWAsCvDmPVMKKAzQFYZbxLaCJaYtXvdJHjvxXagFIYYKRbHHdeVXVlnavaKmwTjFoMqofGKOVtbwGAyONxavCDso")) {
        for (int HijpVXUzN = 1159547534; HijpVXUzN > 0; HijpVXUzN--) {
            ASqjoXpuRtkiegm = UIgfopIRqUVWxc;
        }
    }

    if (UIgfopIRqUVWxc != string("ohkuoua")) {
        for (int bTMYPa = 2143625934; bTMYPa > 0; bTMYPa--) {
            UIgfopIRqUVWxc += ASqjoXpuRtkiegm;
            ASqjoXpuRtkiegm += UIgfopIRqUVWxc;
            ASqjoXpuRtkiegm += ASqjoXpuRtkiegm;
        }
    }

    if (ASqjoXpuRtkiegm >= string("OndRqqAbyaWAsCvDmPVMKKAzQFYZbxLaCJaYtXvdJHjvxXagFIYYKRbHHdeVXVlnavaKmwTjFoMqofGKOVtbwGAyONxavCDso")) {
        for (int GxRjSo = 433390528; GxRjSo > 0; GxRjSo--) {
            ASqjoXpuRtkiegm += ASqjoXpuRtkiegm;
        }
    }
}

double eakkjJfTOODSb::AEfhkwxLnNdBL(double ANgLkOsyuDL, string mTXUPsFN, double mzsphOcAT, int YuJaIts)
{
    int paacghSbgRlIxfRY = -145024476;
    string SdpFhSuJrmYB = string("lewKyilFfWOBeSTXndPcxgqzmJqATFEMQBnjdUgwZzxcOwhMNIJZLtdMbPynhErKNVbiWnzEfnJnHxjLScSQnstYdkrdVmHGFFgRGDi");
    bool xTJLQ = true;
    bool bDGVTeoZk = false;
    bool hPAhpkLb = true;

    for (int HKZxhTBQxspU = 1054465590; HKZxhTBQxspU > 0; HKZxhTBQxspU--) {
        YuJaIts /= paacghSbgRlIxfRY;
    }

    return mzsphOcAT;
}

double eakkjJfTOODSb::ukuzGWUYrZxnfe(string zrCAH, double TXJedE, int QCPNKyOGUrIYZYR, int QKoxLMOEXfFKnN, double lFgaKi)
{
    double vvhvLukrdeukx = 271604.9332384682;
    int mjJatVGsXTO = 76112876;
    int oTGhDUJpDCYByet = -868907443;
    string TcwOVfsjEk = string("hHXTJwyYfZqouNrEORUFtHilDzxvkJRlOiGUBeETNYEvLXPJGwaANCbzuanMhVkMvjGMZnZCWiSzqabXWWKBqSyJviRMXLIMvXQTtekKCLAdEIidZuXovSaLNjdAzbMEgyxVQhXjrKdOirFIQiNxhmr");
    int XgAFj = 222416528;
    double LkYLrukJJzc = -946903.0982224783;
    bool ybpPRHTe = false;
    double lGQjEf = -31096.27314598499;
    int pYSFs = 2112767622;

    for (int SgdhP = 1427358646; SgdhP > 0; SgdhP--) {
        QCPNKyOGUrIYZYR -= XgAFj;
    }

    for (int eNNXjBcbvvf = 832843349; eNNXjBcbvvf > 0; eNNXjBcbvvf--) {
        lFgaKi += TXJedE;
        zrCAH = zrCAH;
        QCPNKyOGUrIYZYR += pYSFs;
        QCPNKyOGUrIYZYR /= pYSFs;
        lFgaKi -= lGQjEf;
    }

    for (int GyaiumiUYdOtGd = 1520529188; GyaiumiUYdOtGd > 0; GyaiumiUYdOtGd--) {
        pYSFs /= pYSFs;
        pYSFs += QCPNKyOGUrIYZYR;
        pYSFs -= pYSFs;
    }

    for (int PCAyQMFRvYxVnx = 960500695; PCAyQMFRvYxVnx > 0; PCAyQMFRvYxVnx--) {
        LkYLrukJJzc /= vvhvLukrdeukx;
        QKoxLMOEXfFKnN /= QKoxLMOEXfFKnN;
        QCPNKyOGUrIYZYR = pYSFs;
    }

    for (int PjQXYWcUsCpdBFhJ = 1194236310; PjQXYWcUsCpdBFhJ > 0; PjQXYWcUsCpdBFhJ--) {
        QKoxLMOEXfFKnN = oTGhDUJpDCYByet;
        mjJatVGsXTO = QKoxLMOEXfFKnN;
        lFgaKi *= TXJedE;
        XgAFj *= QCPNKyOGUrIYZYR;
        vvhvLukrdeukx += LkYLrukJJzc;
    }

    return lGQjEf;
}

double eakkjJfTOODSb::uVJhvBSyDkrIA(int ZVqsRXVNdNQBaJA)
{
    string BhPTvzCLom = string("VasgvohgQcxMgsUMDKJMLabBbEQmqojhAqfJVVnxWlAHmMneDpeGPLwZDsbJENdPGOgLsZZtoDxOfIUkJByfwhcrMlATUMiTNXNJrgcHJhSqKlpoKKkuWhDiOzIJICDDnUryKbhclyyGpcLrkwJfiwYLhQWALVtjDApcNsviFfUkgVLDyKfeCZoTCumPJSQ");
    bool IbKprZoZSTgG = true;
    int BYveQwONjfgV = -1269737802;
    bool VABrHjqWjXSU = false;

    if (VABrHjqWjXSU == false) {
        for (int xdsHUMbua = 1023900449; xdsHUMbua > 0; xdsHUMbua--) {
            ZVqsRXVNdNQBaJA /= ZVqsRXVNdNQBaJA;
            BYveQwONjfgV -= ZVqsRXVNdNQBaJA;
        }
    }

    return 548742.8812128331;
}

bool eakkjJfTOODSb::anqwCLGoaIz()
{
    bool blGGxSFxBBluUGo = false;
    double HeDPIFyaRiqs = 212391.48652557324;
    int tlopEinOJc = -1269421654;
    double Emght = -838245.9552630384;

    for (int nTPCgDtXVjBYe = 175519540; nTPCgDtXVjBYe > 0; nTPCgDtXVjBYe--) {
        blGGxSFxBBluUGo = ! blGGxSFxBBluUGo;
        HeDPIFyaRiqs += HeDPIFyaRiqs;
        blGGxSFxBBluUGo = ! blGGxSFxBBluUGo;
        HeDPIFyaRiqs *= HeDPIFyaRiqs;
    }

    for (int MXPgjifwsoCFWBp = 49956109; MXPgjifwsoCFWBp > 0; MXPgjifwsoCFWBp--) {
        tlopEinOJc /= tlopEinOJc;
        HeDPIFyaRiqs -= HeDPIFyaRiqs;
    }

    if (blGGxSFxBBluUGo == false) {
        for (int AmhZbsnAJZCiPIv = 529691363; AmhZbsnAJZCiPIv > 0; AmhZbsnAJZCiPIv--) {
            tlopEinOJc -= tlopEinOJc;
        }
    }

    for (int XVFynQd = 1526835799; XVFynQd > 0; XVFynQd--) {
        Emght -= Emght;
    }

    if (Emght < -838245.9552630384) {
        for (int QywXheFTknU = 1243689888; QywXheFTknU > 0; QywXheFTknU--) {
            blGGxSFxBBluUGo = blGGxSFxBBluUGo;
        }
    }

    for (int RFasn = 815422962; RFasn > 0; RFasn--) {
        continue;
    }

    return blGGxSFxBBluUGo;
}

bool eakkjJfTOODSb::rlSCiH()
{
    double umWHqtR = -509613.6450345141;
    bool YBwQSROg = true;
    int WzpIwxJGcMcctNS = 346004617;
    string QCojKNNslLdlxORp = string("FsZGuzTQUIIvVLrgyWOqqiYyFpRdpNJdrdFKcEdpwmUgdCBViigsVnOoMGqKxYpuBdkDUsSBuAM");
    double UXrHTdgmEfvhgc = 808738.610970621;
    bool KaYzsfjwsYp = true;
    double hMmlmRaqqWIoojlk = -295977.4451481788;

    for (int lerWe = 658344939; lerWe > 0; lerWe--) {
        WzpIwxJGcMcctNS *= WzpIwxJGcMcctNS;
        YBwQSROg = YBwQSROg;
    }

    for (int SkQwMvTTBkD = 1452541096; SkQwMvTTBkD > 0; SkQwMvTTBkD--) {
        WzpIwxJGcMcctNS *= WzpIwxJGcMcctNS;
    }

    for (int BIFUhT = 1386524417; BIFUhT > 0; BIFUhT--) {
        continue;
    }

    return KaYzsfjwsYp;
}

string eakkjJfTOODSb::haBIwXhSptDhYi(string OWRkvsuHlackhv, double LocWjYVZ, int oXMUoQKkWP, bool uQmaTKNSed, int ynibDiJvzzKSwNFB)
{
    double DUrjcM = 16785.917412493232;

    for (int BcqAJUUR = 1359566841; BcqAJUUR > 0; BcqAJUUR--) {
        continue;
    }

    if (LocWjYVZ > 2233.3124254641707) {
        for (int WHxTZoEOG = 596570390; WHxTZoEOG > 0; WHxTZoEOG--) {
            continue;
        }
    }

    return OWRkvsuHlackhv;
}

eakkjJfTOODSb::eakkjJfTOODSb()
{
    this->YztqvyHkf(-222115281, string("YBlOsYpoGERMMuPzaTYylHyQmDgfrzciLKAQeVutVYVDVughfOgMJUEGGnUujARsdxasztPxgRElgKEaUreYhhxxuYJJacyHkbpJfBgtQtuKRjAYhzBMvxOtvaaK"), true, false);
    this->YQAtZGUdBXLxKQh(776828.7783008808, -1857080790);
    this->cbrswXN(false);
    this->JsMDZIN(false, -275362634, false, true, -1318504690);
    this->qqfCf(true);
    this->gNsEVoVrolVLvyH(string("sFbuZSwTVgnqFISmhrazUJnnLghhegDVGZPamgtJZxQehxhchnFzEFhbNlswaarNmzllQeYVCchijUHwGKcNrecXtDlHGkrYlqCYgbNNOyytvXOuasBtiOviHPJgyxWdKFHxbrsUXhHpUEADIzndclxySrPiggaMvcoAtkA"), -959477878, -750107694, false, 2140444872);
    this->nDyVZljqlj(true, true, false, -889018.6724759316);
    this->nBadgS(1236112512, 392881.5922631275);
    this->cLqnIUUPTxB(1785718186, string("GoaEYkZIfcIGUlCFee"), 770379.1934275713, 610683.5102565774, -613126.9499339487);
    this->laUCEMTO(string("OndRqqAbyaWAsCvDmPVMKKAzQFYZbxLaCJaYtXvdJHjvxXagFIYYKRbHHdeVXVlnavaKmwTjFoMqofGKOVtbwGAyONxavCDso"));
    this->AEfhkwxLnNdBL(-267837.8065969956, string("ndNvTTzBTGeKCtCFOQZuMoQZLLBJbFTgPQRkwpTCfMNsunooLjPWhDEFpZyVyWdoVqZdKrGGiHPYkGK"), 397386.32922121935, 913129385);
    this->ukuzGWUYrZxnfe(string("KGfOVuPytAJnACCGefYXrIxNMhlWgyAXqzhkLajbdPvaeHnrLutxdHESYSQJACgxIPKshrMMYvFTgFfqzEosbxUBTUHVDZsJJsWNqVYlicpmstWKbIoafFVAhjqeTIiEePcYfxXCNEdyoAbbcNqxwEJvlZwekqnzqFzHecDoKytbLBIbnthmozrWqpDwwBHoIhrVKrHxYSwqexXkGBNaThnXpQMroR"), -648426.1979045847, -92624104, -184772646, -702341.0698028674);
    this->uVJhvBSyDkrIA(1362394224);
    this->anqwCLGoaIz();
    this->rlSCiH();
    this->haBIwXhSptDhYi(string("DiiPzXBNCzxGsbejeRNlJuQNsHfbdfMuThZMgGuQQxfKtdsZbcYEwEXfSMNgQSKghxvCpArcCywtCKCWGYEaSEWqDBnlUkEqYizUwmLlLFzUXyfEGkhZjglnkwbsFCmIMPWGaVNxVwtqnWiCtlHeKwtHfMdkUEkCjIfDUuqijnyyAZMTCjDhIVSVfveBhJkltwvOGLtilRnMIIIQ"), 2233.3124254641707, -1510605337, false, 1998975896);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NaLTIZJNcbItaDU
{
public:
    string hdzfiFWrGHVX;
    int bXXjFXSmpfC;
    double vOMTCIPc;
    int fNmWnOtaRIoRhQf;

    NaLTIZJNcbItaDU();
    void HOvQjDFocht(double tWqiShpBwmvxVf, string yBPPLCBcoiuZ);
    void tiOqPZf();
protected:
    bool vlvoRopsisrfJs;

    string GhtIG(bool IZHyQMRHWSHtYG);
    bool UBQFVNRWby(string FRdusNMWD, string DcxsosKpBfGDxE, string ZlFLUABpHZAl);
    void sYFZQNh(string lEfLF, int txOcv, bool gddVLgXI);
    string kRMhioiMWTjOy(bool hwjbHtqZCuXdNlln, int nZgBYvU, bool gsuqhzCoMrGkxi, int rMnwxlpMDAtfkfR, bool HGHcQ);
    string KyzGbJszrmcDO(string MmPwspV);
private:
    string atTXcCjOxmq;

    string ZVNIWlmc();
};

void NaLTIZJNcbItaDU::HOvQjDFocht(double tWqiShpBwmvxVf, string yBPPLCBcoiuZ)
{
    int vGFcrgfQFUmIl = 861147478;
    int vzfuR = -396981502;
    bool XaUpdGuK = false;
    string OvVgJnrwsY = string("ixixhTPuMAtCKdWKRiPgvvYTNyxYCVJRuytphwvujgTfEAszGuRBQqRvArzEqGiGrIFfFDVrYjgdjIHaRmrmNcuwcisqiNhxzUCRaYWymidhLmZFZoWZITWqnViYJNLveTpHyhVELiikLnSiysEqoZbDDVwUIyshlsGvtYaqVQAgmhlBdjCylOBjfeHRKiRoYgpQodLPqtc");
    int sjCSNbT = -923382453;
    string eGOgwBQknjmO = string("heKkODQMiYDGILAXgzhZiM");
    int AoauJYBiES = -2113919865;

    for (int VdNKVGaGDUkRbQa = 1034505562; VdNKVGaGDUkRbQa > 0; VdNKVGaGDUkRbQa--) {
        XaUpdGuK = XaUpdGuK;
    }
}

void NaLTIZJNcbItaDU::tiOqPZf()
{
    bool gTknYpGpBEOKBYV = false;
    string Iqwid = string("VpkKyiYMxHOPAWEXWdVgKArhNUzLFIOcANGYeqKeTNnAxiJTtT");
    string GbsFaTXXRkjeJf = string("PhWcxNmcAkvFLQqhvcjKektRYeodBhaBSqyVOofTDaoHtwTjPDrGddOgCScTWCkhhsSOOeVNuhVIhtf");
    bool PVJBzJpfBnaeyut = false;
    string OSAUoe = string("KIwvjAveAmixnikkmqtPGVnFPavPkYegUZLporsevB");
    int ZMcktIPhhg = 1409822679;
    string SvtCYN = string("TfvHSchVzQqKnFvcqbVHuCBxFNCpxThlluivRYXjXPAsakWbCJJDEoeQmWpIEuCoAudYejvCvmoVyAfKFBlV");
    string uKmzF = string("FEggUZpibBFNUhIedqvTnqSeUpTsJIxYpaLqawoIfSVuWhZWniEKEpKaHRusgURqOnJrCdcNMvNpFaJsYBwkOezNVnTurmsxHBpnz");
    int kJRGuCxKr = 1807126243;
    bool cPopdWgxr = false;

    for (int nHBpjMBpjjweMte = 1019832776; nHBpjMBpjjweMte > 0; nHBpjMBpjjweMte--) {
        SvtCYN += GbsFaTXXRkjeJf;
    }
}

string NaLTIZJNcbItaDU::GhtIG(bool IZHyQMRHWSHtYG)
{
    string fcGbolrTceoOgSGu = string("IsZdIDgLOPtTKhZFIqIeCEuZMXIlzgcRIETgLIOrprQmHRonedCGufrzlahgEhUipGMZOjHOaKijAlXuoXcNSAPbxUmfAoxihEHbqVaWKsKZmWeyiM");
    string lVmgZBIaDVI = string("yPnuYfLiCxCZhiVyjzotVvlLlmIDAAheofdgDIRGfcCscQsApacvUTxnHpsWWkVhxlVdWliUhDxqRTXQcAmxzfIZKPZVHBukczYyQjFNsFCYkAblSOUNiYGIDlbUsgOTDMEOaGapKxEmWUnAvjbQtoUwZVZYyCvhIOuMgNMcWsLJvLVV");
    string idhdNpI = string("rTZixuAFYgsuEjtaWXCvKwwDAvNJsV");
    bool uDjiOxVlFvgGo = false;
    double QywrTyLTZ = -147045.68455392215;
    string GbjHUiNwRRCUR = string("xlmNFHPyJIBIThmlpywotKjLsxwwLtzmYtfvbjGdVxEoVaguM");
    string xdqaIsOmosrSiDtt = string("CWuRCezlxOAXjSHmKeAXxtFqjyiCufjZgMOdrtRZMVtKZouXJXrPNksHDigLiEXOWlZoYHBDxANWQ");
    int GNqZYOFIN = 119325428;
    double kJbiUGpSi = -823316.3747877163;

    for (int wVjWAowIXMiOj = 90121097; wVjWAowIXMiOj > 0; wVjWAowIXMiOj--) {
        continue;
    }

    return xdqaIsOmosrSiDtt;
}

bool NaLTIZJNcbItaDU::UBQFVNRWby(string FRdusNMWD, string DcxsosKpBfGDxE, string ZlFLUABpHZAl)
{
    double aHhyhQSYufR = -675597.1351970402;
    double gGiBSZ = -264862.0078707182;
    int TMLyDtGIE = 355369344;
    int YOyxIZcxG = -734281853;
    int UztHZV = 1987595728;

    for (int siUtw = 45313826; siUtw > 0; siUtw--) {
        DcxsosKpBfGDxE = DcxsosKpBfGDxE;
        UztHZV *= TMLyDtGIE;
    }

    for (int BzIcdRYSv = 88138958; BzIcdRYSv > 0; BzIcdRYSv--) {
        YOyxIZcxG *= UztHZV;
        gGiBSZ = gGiBSZ;
        FRdusNMWD = ZlFLUABpHZAl;
    }

    return true;
}

void NaLTIZJNcbItaDU::sYFZQNh(string lEfLF, int txOcv, bool gddVLgXI)
{
    double MlLtuQq = 750040.6842757035;
    string xvClxCX = string("BJpfAiuumpGaLJGEdwzWJHFvubzoMdsaYnoJVwDzgHxAngkp");
    double aGXDO = 781072.3701199252;
    int OhWUf = -979582441;
    string CrhLeaqgpv = string("nqlUTJZcfeVOGogeVPGncNQwDLTbIcHzgtFVitztzC");
    double iRDXOrfPTeXcrlr = -621423.7241739278;
    int SgwYvh = -75820668;
    bool MghFxKG = true;
    double eoMYtqfIznleR = 554663.1910945971;
    int wJjqGA = 668344026;
}

string NaLTIZJNcbItaDU::kRMhioiMWTjOy(bool hwjbHtqZCuXdNlln, int nZgBYvU, bool gsuqhzCoMrGkxi, int rMnwxlpMDAtfkfR, bool HGHcQ)
{
    int aNiEDXa = -443037179;
    double mCSwVNRYNFn = 190434.19664474437;
    int dMizPCUtvglMQnBL = 84877178;

    for (int crzJosvO = 115447720; crzJosvO > 0; crzJosvO--) {
        dMizPCUtvglMQnBL -= dMizPCUtvglMQnBL;
    }

    if (aNiEDXa >= 1923875468) {
        for (int FfuVRO = 508862456; FfuVRO > 0; FfuVRO--) {
            hwjbHtqZCuXdNlln = HGHcQ;
            nZgBYvU /= rMnwxlpMDAtfkfR;
        }
    }

    if (rMnwxlpMDAtfkfR >= 1923875468) {
        for (int RFZEeakDTkWeZ = 1983049456; RFZEeakDTkWeZ > 0; RFZEeakDTkWeZ--) {
            dMizPCUtvglMQnBL *= dMizPCUtvglMQnBL;
        }
    }

    return string("stEWlACHovVEaLcUFkoSEUiTwBVhKwbFGisrcevtIcoiNgrgmnivfdigRwWSoimWpbMZfVDnCRhOfSI");
}

string NaLTIZJNcbItaDU::KyzGbJszrmcDO(string MmPwspV)
{
    double QPFwxTS = -549160.1508195912;
    string VQYof = string("ZcpiCUnYAQyZgGOFGKJrnARRCF");
    bool NOIOldwCRsBoY = false;
    string HYPrEiRcatRynG = string("SGMxMcQOLvMcsJdAbjEAxKAUAjjvoTjlYdQmacDTudiFIOnAHkacWibyixbYYXMeEDXsNuvMVxXpVwpgFycYcWgiqcOfOLFUyrFnHtDHEKuUKhnuZDKwoFsP");
    int GqDTaoEjN = -958171580;
    double qSVxDUCMTlYhx = 697987.1480954307;
    int tKcTUIHZ = 1714069229;
    string uWzWcvQu = string("vBefHAWUblOkymNFXigWHHRsizlgBHKUOGcQQvRHYssJhwTQUjSMdxgBhgiwfClZPabWVpFYhpvVWhphDHuwSreISUKGeKvtTQLFVlzaTNBsqqmNlNdEFRZNGfSv");

    for (int wWgWNfvdKeEV = 581180586; wWgWNfvdKeEV > 0; wWgWNfvdKeEV--) {
        VQYof = HYPrEiRcatRynG;
    }

    for (int jeEjPxWNcKP = 845012868; jeEjPxWNcKP > 0; jeEjPxWNcKP--) {
        GqDTaoEjN /= GqDTaoEjN;
        HYPrEiRcatRynG = VQYof;
        tKcTUIHZ *= tKcTUIHZ;
        VQYof += MmPwspV;
    }

    return uWzWcvQu;
}

string NaLTIZJNcbItaDU::ZVNIWlmc()
{
    bool DsxcCmYJKth = false;
    double lJcwIlG = -688008.8517237805;
    string MjLeBtdvctqMkhFA = string("TjBuKXclkdVfrCXtVblppFiZvONc");
    int LztyYVv = 238114860;
    bool wMdiAIwPqXsgmm = false;
    double bdaoFeYfijxldr = 57528.67770034659;

    for (int oAKfbihytSzhuQ = 1662362075; oAKfbihytSzhuQ > 0; oAKfbihytSzhuQ--) {
        DsxcCmYJKth = ! wMdiAIwPqXsgmm;
        bdaoFeYfijxldr /= bdaoFeYfijxldr;
        lJcwIlG -= bdaoFeYfijxldr;
        lJcwIlG -= bdaoFeYfijxldr;
        DsxcCmYJKth = ! DsxcCmYJKth;
    }

    for (int ySkdBGDyatQ = 1661107212; ySkdBGDyatQ > 0; ySkdBGDyatQ--) {
        LztyYVv = LztyYVv;
        bdaoFeYfijxldr /= lJcwIlG;
    }

    return MjLeBtdvctqMkhFA;
}

NaLTIZJNcbItaDU::NaLTIZJNcbItaDU()
{
    this->HOvQjDFocht(430477.5811658879, string("rkZohzOGQcyHRDcNJBaSlWVSbvgeyOgfWRQyZvzEyqUePwdABicNNjngnGNXNYUrYSYffqCxOsppAZpfWJngDZauJQEqzDcNXmXAXHHODmoJjXNaKYSvEzWcFvBfuzxnROvfwPAoYWivRUNTYJxAAxYPVqviXRLMatiJRfOpUIRarPmCuXfBUqCZvZQWhawTxJOehvIUJnUHIMXegzcHhCLuEMUrViVrIpfObeGy"));
    this->tiOqPZf();
    this->GhtIG(true);
    this->UBQFVNRWby(string("tmDGldtfPIemCPbvhxAiizBMUncWWOmgKKbAAQisHDasmwwRUZnKYFTFwQELVFQEfMdumoYjhybZcYcWMpgLkRzZKCNwHAHXZYGudIfMCrnJuKCPneCsshgWrZWZZUrQdegczBbBxpJdyLQUqyfmNYLmNapTlhzCJe"), string("BmrEr"), string("WMbHxdVMPPgFZHHZYuYtddWtLdqvqFKVPcyOOzKWZehmBbCFznONKIjjQrcDxyTiwvCwdaPhjFfzVBVdAVeGShAcxPyZZsKQqbsFZllZCwIIVIJLVNLYSgFvAYQfNqwDUQiKFBviumDKVeAAUPovFgXzriTzLhkeXuqQEXGsghLhcphkQELnxFjp"));
    this->sYFZQNh(string("fHDaNXSjQUJAWCSvVeiGaEAyyoyVzUDrBiMeksDmNYMiIRsmMeDsWoguNzbEBpHDgDdCJrvIGrbrSXdljyILjhoqUHiWSTdOCUTvdPKvJPyixWwAftjPeaiYCMEMvoUPamJTZZdhsYiAlROihFcOXRSTKXrPhvCtwRGKghpSMffkQbPK"), 980142010, true);
    this->kRMhioiMWTjOy(true, 1923875468, false, -937154731, false);
    this->KyzGbJszrmcDO(string("FymmgETUVDHMYvQqOhdqnmPPkstkFNdrvsxzFoivcMLHGYWgokUIGmtwfiYdNXYNueKNdzInBMhokmcitOwLmrFFZDFWRKSRQbYboEBdcasjzWiUUqXHjWZxeBHFLeciMNBvtnanXewPZyaTwwkNPwiVbGHhAYGRGKioPmVUCabkAuuxlSlkSNILrYXdHfSEBqIXDvjIDjEmalpGURQw"));
    this->ZVNIWlmc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vlkKi
{
public:
    int GxZla;
    string CbPSOJaEtjPCY;

    vlkKi();
    string zVXOixlgvPkcMX(string jhfkBsX, double qTufvFhwaQYuYtK, int GfKnQEQyV, string JwCSPZDprBm, bool UBFGc);
protected:
    int auYantRIJzG;
    double yDufikCyWbUzZCMf;

    bool mcbvbsH();
    string cERYQw(double YlcXLSnHHI, bool IkMKTJIHkSjRbce, string JKQRmvlo, string rlAVCcDB, string hmFXBgLjNmRxbg);
    string vaiyulXTQaivI(int efgDvEN, bool jWPHBmcngqqXETVc, int fABoOoi, int izScfF);
    double btlocpITohIV(string xCIBnTEALUW, double UeLARhgpDKkkgV);
    double dQDgjKiDiHANes(bool AExxtePT);
    void EKRhHUWBMOEYUN();
    void lxxfILqwsQefBNp(int XpPkEzWnmyP, string QGEAiQi, bool CRBVaiet, string BrRMkmUWMVyeGc);
private:
    int GdmpM;
    double WsbYrA;
    int jPKRurF;
    string jagcgOlmFZ;
    int cVTVzPTwobVNtOB;
    int HcMjDyxAFv;

    int JFlGYTZV(double mbWwtJaNx, int GzXrDbDU);
    bool bKRsmtIfKQT(bool OCqackeR, string SMKblYZshZfVY, double zuyTQLcTgbBP, int mSbCen);
    bool pcAMMMCWoZkmr(int ayBvnCryEfggA, bool dzvPqZqKLTsY, int rRfSWw);
};

string vlkKi::zVXOixlgvPkcMX(string jhfkBsX, double qTufvFhwaQYuYtK, int GfKnQEQyV, string JwCSPZDprBm, bool UBFGc)
{
    bool noOREnmsQg = true;
    int WXPHuojiNYpqt = -2122074026;
    bool UVyMShkfCr = true;
    double gqUwYiaWnR = -146874.9396647167;

    if (gqUwYiaWnR == -1025562.5891846992) {
        for (int igDINnRouJFdNbH = 295212514; igDINnRouJFdNbH > 0; igDINnRouJFdNbH--) {
            continue;
        }
    }

    if (noOREnmsQg == false) {
        for (int ovMhm = 1124729667; ovMhm > 0; ovMhm--) {
            continue;
        }
    }

    return JwCSPZDprBm;
}

bool vlkKi::mcbvbsH()
{
    double ZLCpcLzju = -153367.295909871;

    if (ZLCpcLzju < -153367.295909871) {
        for (int LgWYNTZvmg = 649739748; LgWYNTZvmg > 0; LgWYNTZvmg--) {
            ZLCpcLzju -= ZLCpcLzju;
            ZLCpcLzju -= ZLCpcLzju;
            ZLCpcLzju -= ZLCpcLzju;
            ZLCpcLzju *= ZLCpcLzju;
            ZLCpcLzju = ZLCpcLzju;
            ZLCpcLzju *= ZLCpcLzju;
            ZLCpcLzju += ZLCpcLzju;
            ZLCpcLzju += ZLCpcLzju;
            ZLCpcLzju += ZLCpcLzju;
            ZLCpcLzju -= ZLCpcLzju;
        }
    }

    if (ZLCpcLzju > -153367.295909871) {
        for (int doBvMlU = 1716772034; doBvMlU > 0; doBvMlU--) {
            ZLCpcLzju /= ZLCpcLzju;
            ZLCpcLzju /= ZLCpcLzju;
        }
    }

    return false;
}

string vlkKi::cERYQw(double YlcXLSnHHI, bool IkMKTJIHkSjRbce, string JKQRmvlo, string rlAVCcDB, string hmFXBgLjNmRxbg)
{
    string hMYhjtCgByQraJF = string("astRuoohflhIgekGsmwRsIriauyxuOgTpUfDMhQvvcoZaqXLnfMSlKoCvqOUscjAQOXqSrFGpOetBNkuHEPeaVgJVyVriTqDHfkgqRHqARYJgjSDNehlOhBUeCvRkSeKhgNQvFoQhudsrCSNxqWIsgPttHqwPZHFOIOeFSTAuSDiQXXClvAZcOcQp");
    int PTPCSN = -895257837;
    string KDVfDaQCAruoLcQ = string("vXmvvOJBHJhKOJfOeJesOnGAYweIFCktNgagnWceiZYdfaUvmytwSbYZeQbYnnSwbMIqJYrjyyBMETpFzchlgVoMoUceIgPkqaCrkUAUTGgIPsYikRmHMTwhrcyjlqHXBjKDfaqnpSlNMQcLNntIwselyOfGpTDBvkrowaeyeTNSmkucEwBuXIVZGEBaEVX");
    bool AldeSHGfEkUr = false;
    bool WxfNhHaY = true;

    if (hmFXBgLjNmRxbg != string("oaxORqPMtoRFYIEBRjGYPbRFOoZTmLWmnFkCHOcvwNfcQkPfHuJWKvPbhSkDELAGaSZCQnlTTQktBVznHaykHnaSndKpzsILgZJyTrZzpcBWdcSODGduUfVWFucCxtrHeGVadIQvMmpLNRVoVBLTrcrnEidAQcqeGpRlJprJESxmVoupjhDXMaeQCWxIkTUBefUU")) {
        for (int YQytZoRXuFoPhjf = 849904307; YQytZoRXuFoPhjf > 0; YQytZoRXuFoPhjf--) {
            WxfNhHaY = ! AldeSHGfEkUr;
            hMYhjtCgByQraJF = rlAVCcDB;
            IkMKTJIHkSjRbce = ! AldeSHGfEkUr;
            JKQRmvlo = hmFXBgLjNmRxbg;
        }
    }

    return KDVfDaQCAruoLcQ;
}

string vlkKi::vaiyulXTQaivI(int efgDvEN, bool jWPHBmcngqqXETVc, int fABoOoi, int izScfF)
{
    string USOJiwSxyj = string("EwARxTvciHlfiwUUfXrjExqmeYCntbxydk");
    bool WKNRPUnQRVvKk = false;
    string zsOocVrZWc = string("JsNXFFJbkQJjcVBorktoVrBjcgdvFlmtGJtjiUyhKjCYwnhwQLTPiAYmLKCvarOUQvMtGpWYBGsuPsxxcBrKKVcEHwCSXgoFjyhtKWmJMgEApRYYUkDZIaovuFJOmuUrzXbAzTrwaUKFJgcXiRCEUsDeSLruSbFqotNsZpfqtplIpxhfDOWVZAhwvvmJtR");
    double mccVFBbJtaXQbeNS = 417332.8607652135;
    string kdJmkHero = string("JLTZdVEanrFjCRzWnKHBGyiasGqAvNMmHAzwtCMZzgXpnriQMHYoxCnDhWUJaXBjikuYhFZRlQtgjvtVbchSZVtdmDyECXyKvIrmgJdqpGfzwtcwnJJZgRsyGXQfGzPtWMWaOKMpJfrQYzHAztIhrUQoWzZCSghUxEGYfFGH");
    bool uUyRjrQlHyPzAOK = false;
    bool LrCEdKbYugSyIY = false;
    int aUicw = 914997336;

    for (int sTaiHU = 1070734485; sTaiHU > 0; sTaiHU--) {
        aUicw = izScfF;
        zsOocVrZWc = kdJmkHero;
        WKNRPUnQRVvKk = uUyRjrQlHyPzAOK;
        uUyRjrQlHyPzAOK = ! jWPHBmcngqqXETVc;
    }

    return kdJmkHero;
}

double vlkKi::btlocpITohIV(string xCIBnTEALUW, double UeLARhgpDKkkgV)
{
    bool jKrTemoAYkGikEPb = true;
    int SQLSzyTvfwxmrRka = 2048051227;
    string FORWbRcJ = string("QlHFBwkqirRPeeRSwWelHKYD");
    double zJVbyIRpdBHUaX = -562139.0078930788;
    string QMjDvmybZUUq = string("cqkLoQWjXfCJsOmuQDgZPYnDRokFNPYeOBxcONLhjYwZKoRRHCemMBGzwDemRpvSkMEaiGnYLIT");
    double IOZfAcLUvjZmdP = -631434.3611914746;
    string HOJTiyckOnOU = string("MBmMLTbzgrmDIcuaPfxZCInNsFQqnYLMjAslwiYbAxUBlepCvWVaNyOUhlEFqdIvwHhTenMocUJiUzXPIinuwCbDaVfEQsjoxtPCZNwtBDlEfNnWOQVmDLLrTRawGszPbPbRWZeRudcuXIyXDARBbqyEdYhlAmGYTRKjbMkpkMxTApIFgtOWWdQQPpGxPuUuFN");
    int numUOsnxHYUCdPE = 486353599;
    int kjCvGqbTHMBVMddX = -97709226;

    for (int CRuSj = 1666470208; CRuSj > 0; CRuSj--) {
        continue;
    }

    for (int xZAPOlPzcku = 1461128555; xZAPOlPzcku > 0; xZAPOlPzcku--) {
        continue;
    }

    return IOZfAcLUvjZmdP;
}

double vlkKi::dQDgjKiDiHANes(bool AExxtePT)
{
    int wibzF = -469524533;
    int PIBBfPcODfjM = -820004563;
    bool SUpHMEyzVDy = false;
    bool IYXSb = true;
    double aaPOEHQFBJ = 630672.2501587769;
    bool iiJmgQIjz = false;

    for (int XfTIijcLb = 264364448; XfTIijcLb > 0; XfTIijcLb--) {
        AExxtePT = iiJmgQIjz;
        PIBBfPcODfjM = PIBBfPcODfjM;
    }

    for (int XwUZrqwWNzn = 519722999; XwUZrqwWNzn > 0; XwUZrqwWNzn--) {
        AExxtePT = ! AExxtePT;
    }

    if (IYXSb == true) {
        for (int vXRIuabkxvsoufDg = 463382365; vXRIuabkxvsoufDg > 0; vXRIuabkxvsoufDg--) {
            PIBBfPcODfjM /= wibzF;
            IYXSb = ! IYXSb;
            SUpHMEyzVDy = IYXSb;
        }
    }

    if (wibzF >= -820004563) {
        for (int sTlwmUKJJrEX = 351188938; sTlwmUKJJrEX > 0; sTlwmUKJJrEX--) {
            AExxtePT = AExxtePT;
            AExxtePT = SUpHMEyzVDy;
            AExxtePT = SUpHMEyzVDy;
            PIBBfPcODfjM += PIBBfPcODfjM;
            iiJmgQIjz = ! iiJmgQIjz;
        }
    }

    return aaPOEHQFBJ;
}

void vlkKi::EKRhHUWBMOEYUN()
{
    double zMPBrQpvSTYxCi = -884757.0405819343;
    string xFZQWPfcwdTfYEE = string("tWkVPYMUgUDDBVJIkQdYUdNUCbdGimwXkMKgqQiBvhAByAUCuiVgDRoJEBpJznQzDgVzslwpLtKsWefEPRhiYUOmVfXdZiBNIRUUavsVlxwWNxsjG");
    int GuUzURsYYfIHHAlI = 1334594742;
    string WARrpvsPwNkn = string("LwEjzJXYziONFWyszjNsgMlbzWtIYnAhrGeyMSJJEKetlZCJoUxACGlRfBdQxXCpXVNeNotjRJLDmwYBQVwCvUsOMzNxWGvEBgDabWkBSoGdVDYPLZdyXNxjdytiUAzJmuuuIWQqPsIgEguCqwlHA");
    string ZLhirBhrMoh = string("dLInLYQrNgjyPzhXsUIiwJcZgflN");
    int bJAhmugKnlUMeEN = -909730772;
    double TfptoIjKjhllmNT = 627316.3465004282;
    int KAsAWPAUJGjAvu = 1822095833;
    double UkoBE = 965876.0445683303;
}

void vlkKi::lxxfILqwsQefBNp(int XpPkEzWnmyP, string QGEAiQi, bool CRBVaiet, string BrRMkmUWMVyeGc)
{
    double xNqUTojaxaraXLq = 1025807.1385372415;
    int USQBASGImZdTqb = 494646329;
    string UWgPa = string("dXHRBmgWRdfmiWFeGXoGGnGAfCQWUUAvUACPRkQAlLBXfPLnDypXNcWnrAYEnEIrCmtCKcIpfhwxuYhrGLqaRPxQzIpmOQpLbMMmvDMstvwxPtZxOyeXOUIpSaVvYYypGTXfjByKIqZgpCNJwEJCsvMzpqfHWTtCuhBQPNNMKuKBQtJuwkVUVfONqMSjQygbxFikZRyUrxbWuwGpVGrkwYydruPMIjAOe");
    double uvxyAfZobtg = 579603.7592958427;
    double QjYmSiQfEIKiP = 489548.29327657336;
    string YnHwJMtPia = string("jQFNddhiRgqzmGVJgcYbevklagVqLUSnNvKYHcogRRYMYyqd");
    string qgkapvZRGZKT = string("AjzHjzLXWijYUgaWiPxpOsoZhzsfnwvUNKYrhGyTvFChgMGyyjgSMPiMyJASwwsKuNQSEtSAPWVQUyvtAxVroBzeMBRglSwIdiwmouxGrqBpmxVoLwaedRiVGtaTSPOPSyIqxGjaZsT");

    if (QGEAiQi == string("AjzHjzLXWijYUgaWiPxpOsoZhzsfnwvUNKYrhGyTvFChgMGyyjgSMPiMyJASwwsKuNQSEtSAPWVQUyvtAxVroBzeMBRglSwIdiwmouxGrqBpmxVoLwaedRiVGtaTSPOPSyIqxGjaZsT")) {
        for (int diPbuMx = 600504120; diPbuMx > 0; diPbuMx--) {
            UWgPa = YnHwJMtPia;
            QGEAiQi = QGEAiQi;
            xNqUTojaxaraXLq = QjYmSiQfEIKiP;
            UWgPa += QGEAiQi;
        }
    }

    for (int iYXSUwEMTXlLEBn = 915451315; iYXSUwEMTXlLEBn > 0; iYXSUwEMTXlLEBn--) {
        USQBASGImZdTqb += USQBASGImZdTqb;
    }

    for (int CmEgvZZiaURbZQZN = 1551634443; CmEgvZZiaURbZQZN > 0; CmEgvZZiaURbZQZN--) {
        BrRMkmUWMVyeGc += qgkapvZRGZKT;
    }

    if (XpPkEzWnmyP != 560623382) {
        for (int MtMHBSSjL = 489387491; MtMHBSSjL > 0; MtMHBSSjL--) {
            qgkapvZRGZKT += BrRMkmUWMVyeGc;
            qgkapvZRGZKT = BrRMkmUWMVyeGc;
            qgkapvZRGZKT = UWgPa;
            USQBASGImZdTqb /= USQBASGImZdTqb;
        }
    }

    for (int YrwEvE = 274542236; YrwEvE > 0; YrwEvE--) {
        xNqUTojaxaraXLq += QjYmSiQfEIKiP;
    }
}

int vlkKi::JFlGYTZV(double mbWwtJaNx, int GzXrDbDU)
{
    double tMMcTenLC = 267398.7213187468;
    int enQnofGTWQzO = 206489273;
    string lQpfmxhEpxBmJSDg = string("nevOSDiCmOSpXZDlzprCkBtGSTqKVlUYHYFoKpzgKRhtgufbdxEBsLRMMnlsmzqSNNvYtRcUBollCUqAYrFiuZXzasgdAKJqFemWQRxkTgBKAnmaPLeoxGgEJZVkjPDdSyHqucASSZwOBbWBWfHxvnGkPxKsCxiwKEdqFggMZkoYogpbNNnLWFyDXlxWDlvPiuuNirFAWVpr");

    for (int JGrWeZzKjcn = 915562844; JGrWeZzKjcn > 0; JGrWeZzKjcn--) {
        continue;
    }

    return enQnofGTWQzO;
}

bool vlkKi::bKRsmtIfKQT(bool OCqackeR, string SMKblYZshZfVY, double zuyTQLcTgbBP, int mSbCen)
{
    int dKwPIQDkd = -24224129;
    double tJTFNsaqC = 7282.722223635333;
    string IIjfLWo = string("pJpQMHzwzb");
    double gwvYNhupreTeXXVE = 380508.16476417304;
    double huBcCVKm = -981688.6642011458;

    for (int qWwBoiKr = 719259905; qWwBoiKr > 0; qWwBoiKr--) {
        gwvYNhupreTeXXVE = huBcCVKm;
    }

    if (zuyTQLcTgbBP == 380508.16476417304) {
        for (int HwjJdmaf = 836635313; HwjJdmaf > 0; HwjJdmaf--) {
            continue;
        }
    }

    for (int soYMq = 157065814; soYMq > 0; soYMq--) {
        zuyTQLcTgbBP /= tJTFNsaqC;
    }

    return OCqackeR;
}

bool vlkKi::pcAMMMCWoZkmr(int ayBvnCryEfggA, bool dzvPqZqKLTsY, int rRfSWw)
{
    int dsHdcZNyTEvsZl = -1981750460;
    double fOUhK = 782774.9325646198;
    string kzHSgik = string("EQgDghgdPhEsmoktTuVmicEVZCXorMEzqWKJijJoTAoSzFcwaJvGonMvSDQXDmMhoeIPvozYOeUvJtXPjifbkvHXCOfiMQGlsIdeBfVKWvUWpwDPSqNMixtINtqreeZJcGoUtoKdGfgJQRJYGLIcNbAgfJpNMrCPJLVmBZOsjEGBKtSVPQxCwZe");
    double sDdImOLcMUlArIZO = -1033562.7758082629;

    return dzvPqZqKLTsY;
}

vlkKi::vlkKi()
{
    this->zVXOixlgvPkcMX(string("fcknhCyKUWHKxuLZBFyTvFymvNCfaJYqDBdeQcKYwEvdLkxpFcHuXZMPOcgJUnxcEjdAS"), -1025562.5891846992, 2010011664, string("oHnQMlfxgkVZbbWvahQIMvuJ"), false);
    this->mcbvbsH();
    this->cERYQw(580876.3433131896, true, string("eoCHnTHpLrWkEoDZJzEQUUovEVeHqkiIyffLWvJhIrALmzi"), string("oaxORqPMtoRFYIEBRjGYPbRFOoZTmLWmnFkCHOcvwNfcQkPfHuJWKvPbhSkDELAGaSZCQnlTTQktBVznHaykHnaSndKpzsILgZJyTrZzpcBWdcSODGduUfVWFucCxtrHeGVadIQvMmpLNRVoVBLTrcrnEidAQcqeGpRlJprJESxmVoupjhDXMaeQCWxIkTUBefUU"), string("mkycgXeDAUmWkYGpyglfXOYTTuXTHqBndtXqGJscgdDmMJTNwdBuLdgBtwXYhKNqZCZUUEjwChwzFIotPCpNyYHgKlMJuyEFJSegrCQzXxkLurkJqdVEgeyjQTqdsxr"));
    this->vaiyulXTQaivI(1232146305, true, -782263472, 2031099116);
    this->btlocpITohIV(string("nAUBGWiQoPTNGOjpCPONMHaGcOUkrybzTWqiDNOhpkOcwRThojBuJminDAJYOMvbZse"), -147442.46214217014);
    this->dQDgjKiDiHANes(false);
    this->EKRhHUWBMOEYUN();
    this->lxxfILqwsQefBNp(560623382, string("WJtGTfVjwPoScjmkPdOLJREvPkexjefBeYxDPWiXnRLkcfpOQeBHZMqDBNMALEQOfZLuIieyhpvcMbyzvKCrcLOkcQ"), true, string("KsxtOGRTUCUkilZKVwMxLgTLGuxBaMTixLoVoNBorWrEdYsbQMDONEhXgHDkqsJHNaLXKhAmObQwjaliMNPNLbMUZbKNeyCYJFwMPRcxEfHjBaMuAorfzKrEnzNoRmuKSvzvDJYUiNJoGmJNoBLPqEBoHbpNdWbmzwjEAFxvxjLwmPNkshFgybXbuBSMYLKEXtwSkDb"));
    this->JFlGYTZV(503319.9470340083, -664634273);
    this->bKRsmtIfKQT(false, string("MsTTxEEzHwFuPfCBUkzQyFWMnmOiZiABGobQpTcqyjSOmDbuXvsGlJRGITJWXxnysBxKSxQwAXReSlcgnmNZosebdZtdYDnhecAiYCPSDPgFATMrgTeIUSJQvTqKcPiFurOwoTIUqqTLyWNafXrTHqTobSZZgKFZsSnwRWrBVDvQGduYjzY"), -89681.56226534353, 1111096015);
    this->pcAMMMCWoZkmr(1234877003, false, 1243034666);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zHBSTWRlfDqZIuOT
{
public:
    bool lMJOUAyKoMAWhdxK;

    zHBSTWRlfDqZIuOT();
    string hNHHkerfYMBHMw(double huVGrAFTtX, string SKsACQnlh, int FcZrdbSUEmob, double fwXYP);
    string fbKPubmlbmMMZXjj(string jXbhYC, int ZRseAxIS, double lBJXZqDrZ, double lPyCoCHJ, double eubJiJXLEsOt);
    bool rNryEtKixOMSYqsv(string wQwcSJJtm, int WxRsASiS, bool MoKsiBqAjnQnVM, string JnOxaAYpEALh, string eNlgzzlvCoTfvRd);
    void BnfAK(int LXiBq, string fTZHcAZyoIbTUzk, int LuLfWGtIAYjfCuf, bool AdzqmysktOT);
    int ahlwslQze(int UISLUaHwPalZEA, bool GZcVZdfeLeJZudoS, bool qHURbTnSAdQuVkQM, string RiltcejK, string rmoGrW);
protected:
    int irbdSOD;
    string nVHJPtNTCaNCN;

    string UdNZqQsiYzYFt(bool dZRbpQhAGdgYW);
    int KdLcAPdCCuvr(double JmuSv, bool npWooqhbxOo);
    string ISwcecoFbFY(bool mPVMraHpghFi, double tynof, string EaveeG, bool EjEhV, string QyHLhea);
private:
    int HHUYmNmGQ;
    bool obBMpb;
    string wVFNCejcgXOSvMU;

};

string zHBSTWRlfDqZIuOT::hNHHkerfYMBHMw(double huVGrAFTtX, string SKsACQnlh, int FcZrdbSUEmob, double fwXYP)
{
    double aYjsEpAQIGTlIJFG = 372986.2685122613;
    int hkkLTlv = 1061733854;
    string AxKtJcCHOPRfFxNz = string("NWGMlvLpjfvdvHemIHzixWMLZKOaysaYoDTnCmgdgMVrIeNMFrjwmxYKCwkcjZbZxAhWBMVnRBuhcxAJDsTRtVvsiIpTLqqQxCpCvjfbcuXUxyjOevVmUCvpQmorxLFDNFNhHFygkgdoMAmRUsnHmIizmNuzZBFqZTMSiFlwDrmnFUSJdgUjrVAkvTkJSaqJpIpbzMpWSrHh");
    int HafgNTc = -1530985029;
    double IdctFQteTJFPaky = 839965.5264351274;
    double bmHYBQbkYzqbs = 65259.84862766967;
    double EJXPUZbzRAPCiXS = 220105.80041372884;
    double TKasTazhTzO = -639866.8128175277;

    for (int rSVNrODWy = 301688928; rSVNrODWy > 0; rSVNrODWy--) {
        huVGrAFTtX /= fwXYP;
    }

    if (bmHYBQbkYzqbs > 220105.80041372884) {
        for (int OjiNMuMyhkmgKQt = 1121949816; OjiNMuMyhkmgKQt > 0; OjiNMuMyhkmgKQt--) {
            FcZrdbSUEmob /= FcZrdbSUEmob;
            TKasTazhTzO /= aYjsEpAQIGTlIJFG;
        }
    }

    if (bmHYBQbkYzqbs < 220105.80041372884) {
        for (int rFQdkqA = 2063042012; rFQdkqA > 0; rFQdkqA--) {
            TKasTazhTzO /= EJXPUZbzRAPCiXS;
            huVGrAFTtX += bmHYBQbkYzqbs;
        }
    }

    if (TKasTazhTzO >= 65259.84862766967) {
        for (int wayld = 1913015809; wayld > 0; wayld--) {
            AxKtJcCHOPRfFxNz += AxKtJcCHOPRfFxNz;
            IdctFQteTJFPaky /= IdctFQteTJFPaky;
            IdctFQteTJFPaky = EJXPUZbzRAPCiXS;
        }
    }

    return AxKtJcCHOPRfFxNz;
}

string zHBSTWRlfDqZIuOT::fbKPubmlbmMMZXjj(string jXbhYC, int ZRseAxIS, double lBJXZqDrZ, double lPyCoCHJ, double eubJiJXLEsOt)
{
    bool efFti = true;
    bool dNTBXTjzxtFkuYcl = true;
    bool DsEMpalIlASxvF = true;
    bool SQGGuTCVPsTBVjjH = false;
    double pzDVycQUXjeNUVlw = -104590.85659828983;
    double HKvLrieNXUaJYJ = -194730.84546223198;
    bool mwJveUFxNRIo = false;

    if (dNTBXTjzxtFkuYcl != true) {
        for (int yBNYFinZciWK = 368507346; yBNYFinZciWK > 0; yBNYFinZciWK--) {
            continue;
        }
    }

    for (int lZWVsAqYBd = 1761480497; lZWVsAqYBd > 0; lZWVsAqYBd--) {
        pzDVycQUXjeNUVlw -= eubJiJXLEsOt;
        DsEMpalIlASxvF = ! mwJveUFxNRIo;
    }

    for (int BEJzu = 444558087; BEJzu > 0; BEJzu--) {
        continue;
    }

    for (int HGRXtc = 1610307739; HGRXtc > 0; HGRXtc--) {
        lPyCoCHJ = lPyCoCHJ;
        lBJXZqDrZ *= pzDVycQUXjeNUVlw;
        lPyCoCHJ /= HKvLrieNXUaJYJ;
    }

    if (lBJXZqDrZ < -730367.7651357198) {
        for (int lHqUViu = 1301861947; lHqUViu > 0; lHqUViu--) {
            HKvLrieNXUaJYJ = lBJXZqDrZ;
            lPyCoCHJ += lBJXZqDrZ;
            efFti = ! SQGGuTCVPsTBVjjH;
            ZRseAxIS += ZRseAxIS;
            HKvLrieNXUaJYJ = eubJiJXLEsOt;
            DsEMpalIlASxvF = mwJveUFxNRIo;
        }
    }

    for (int SSnblBwJNl = 977997595; SSnblBwJNl > 0; SSnblBwJNl--) {
        eubJiJXLEsOt -= eubJiJXLEsOt;
        lPyCoCHJ += pzDVycQUXjeNUVlw;
        lBJXZqDrZ = lPyCoCHJ;
        SQGGuTCVPsTBVjjH = efFti;
        dNTBXTjzxtFkuYcl = ! dNTBXTjzxtFkuYcl;
    }

    return jXbhYC;
}

bool zHBSTWRlfDqZIuOT::rNryEtKixOMSYqsv(string wQwcSJJtm, int WxRsASiS, bool MoKsiBqAjnQnVM, string JnOxaAYpEALh, string eNlgzzlvCoTfvRd)
{
    string BaXzgcpejVuQs = string("KMGzRAgqBrnNGGhzohzDoeQwtQHmKbCximMCmWOJEVYdkcnRILRDvBxWpdFjROjQfCpLAzUSBpvfmAYyqOtfHAknewFZJUkHOGXYQKUXPDtkmdk");
    int TCPPPNd = -1027950011;
    string lqktzjRcIUjW = string("pBTyVtwYetIeXOGDxUJBdVSPYzkMlwHqrumGSyTfhzdDQaRGxyffyPZgAwZYsUiJchKFOFzxHNhXiCtnBnIixyeNXvAkAjpTiYPSA");
    double NZrbvJo = 238788.81696074724;

    if (eNlgzzlvCoTfvRd == string("RgRMMOjDozOFcoPJAxfHDUsQXEYFGRgsQFOHoqkfIVKmOBjBASHofNaneQeKYEQNMoAFwBqCRNoZphBWnGBSrNaYpgjkMCcDREJGhdUmQBzyxnVIAUubLRqtMMLEkZzBfLxOvDKGWaXSNeyDiTekWbfxTr")) {
        for (int PfnzuFQLz = 752231121; PfnzuFQLz > 0; PfnzuFQLz--) {
            continue;
        }
    }

    return MoKsiBqAjnQnVM;
}

void zHBSTWRlfDqZIuOT::BnfAK(int LXiBq, string fTZHcAZyoIbTUzk, int LuLfWGtIAYjfCuf, bool AdzqmysktOT)
{
    bool OHFMGc = true;
    int mJviM = 1287190067;
    string iupXLkWoFMSilw = string("BDkQuXgPtJvCRalpOXqgnVdFuYygmXWMWZAgtvkJpibjwhGHUiACOdCHQjifVPoHIydPSnhKeqcYneiEujOdfnUvcQEKAUlRsVaMfekbtPlUeXjWVEcdKylLASgihgMDXpqvFiUCPzlYGOwDKJzpOFCepRyADlnxNXwkCkXumUrdrbVImSybPcvkfVSVcvIHdLMDyTOrFZgqn");
    double dVhdSxOZRC = 455585.6551338107;
    double BIQkmfmynnC = 623858.1522777944;
    string bsfmDifQh = string("zRtrlewsnAGxQSQhLLXLYuvKvmriYrgOviSapTwBLyjCKcBpbvpVJHVvQojGIaOCFsNKWsjXGkgjAiagfGssiOtjepjKgFrNVikMqlgyFsPGVgxSKYjyYPgzVgMJToeaqxadEvVut");
    string vFxIyA = string("zewSiGUwrymRxfrnwbTUXBxXnCSVyZNRElymugAgyIeVDimDdhkTreoIWjeKlspElqhusLVjnVQd");
    int FyaGrqK = -2069881024;
    bool WATyeOHGnVhY = true;

    for (int yOnfZBhe = 1763789169; yOnfZBhe > 0; yOnfZBhe--) {
        mJviM *= LXiBq;
        LXiBq *= LXiBq;
    }

    if (iupXLkWoFMSilw == string("zewSiGUwrymRxfrnwbTUXBxXnCSVyZNRElymugAgyIeVDimDdhkTreoIWjeKlspElqhusLVjnVQd")) {
        for (int pnjKPE = 1300050364; pnjKPE > 0; pnjKPE--) {
            LXiBq -= LXiBq;
        }
    }
}

int zHBSTWRlfDqZIuOT::ahlwslQze(int UISLUaHwPalZEA, bool GZcVZdfeLeJZudoS, bool qHURbTnSAdQuVkQM, string RiltcejK, string rmoGrW)
{
    int xnpIwYvMjTNPMN = -271943833;
    string uCqpzHoRCwhQqB = string("LHvPmuezmsjYoLhcHvnjuIlxmbUzEUBZDKxmgIxOvokQfdlsRyoGycEHbsAxijEoNbkeUFVdoHkbcwgVoHPCTrwEyQdQMeoHhHbbNgZkmYaefAvIIvaSezUWWnjzQAXkdExerCSntbvz");
    bool jWLprliVF = true;
    bool GhuBRIXZATzXGNy = false;
    double vhdxRtqWDHVt = -86524.22650010628;
    bool ubAXT = false;
    bool NvQgybQgW = true;

    if (GhuBRIXZATzXGNy != true) {
        for (int vCPjAjsa = 42133724; vCPjAjsa > 0; vCPjAjsa--) {
            xnpIwYvMjTNPMN += UISLUaHwPalZEA;
        }
    }

    for (int rOEQwQlGZfEaCtP = 1780416990; rOEQwQlGZfEaCtP > 0; rOEQwQlGZfEaCtP--) {
        GhuBRIXZATzXGNy = qHURbTnSAdQuVkQM;
        ubAXT = ! qHURbTnSAdQuVkQM;
    }

    for (int EmoRrFCfrRd = 983793576; EmoRrFCfrRd > 0; EmoRrFCfrRd--) {
        NvQgybQgW = ! GhuBRIXZATzXGNy;
        jWLprliVF = ! NvQgybQgW;
        ubAXT = jWLprliVF;
    }

    for (int jSygzmEsYSqNIJpO = 826742858; jSygzmEsYSqNIJpO > 0; jSygzmEsYSqNIJpO--) {
        NvQgybQgW = qHURbTnSAdQuVkQM;
    }

    return xnpIwYvMjTNPMN;
}

string zHBSTWRlfDqZIuOT::UdNZqQsiYzYFt(bool dZRbpQhAGdgYW)
{
    bool KVeyCMZct = false;
    int hmikLNUv = 1018960988;
    int epBWRbKae = -1317917869;
    string lAzBDcXLoUpbliS = string("eGQuUsLKMsRwlYyJJNtYBtiGGcndSpSrjaTfaphmVNoBrhFPGXgPwDTnmyjYcbFfamjMqzFewwcWvnsIlqHVzDHcZtaNpcJZGKeuFMGZyRiWIzAKnmxLoZRCyGkRFZsexYhOZJBlTGSdOKkStZlAMznuwkifgdPovWRHumAnkEYtRfKUIKdYZDRVEclGXBZATTDAMLgJWLkjnroGAkVSvaEJdJvoLP");

    for (int RPtncugDxrG = 649040479; RPtncugDxrG > 0; RPtncugDxrG--) {
        KVeyCMZct = ! KVeyCMZct;
    }

    return lAzBDcXLoUpbliS;
}

int zHBSTWRlfDqZIuOT::KdLcAPdCCuvr(double JmuSv, bool npWooqhbxOo)
{
    string IdnTd = string("mYDpuRxljLZHzqwFjO");
    string gtHTCFxSW = string("AOdCAN");
    int iRvXharmjlytDsZ = 980995406;
    string cybMxWQCdJxYIR = string("slJVqOZKxqCRayvnmVtWHIPYhtTXnLxaQObjrSkuSFNhhSWwdjLlBEQuIdNwXjVXlvyiamjMTUTjrJTRevKaYkzNlxFCcPDGAGXvQfwOHykYaJ");
    string KHWzBJIbfIneyML = string("IkkyuIPJZlSlSfqBovUdHcLOKEfPvMQtXttklqvEJsnwLTrZtgKZwWLpBmYxgMud");

    for (int RtpMHbXmX = 1352765275; RtpMHbXmX > 0; RtpMHbXmX--) {
        IdnTd += KHWzBJIbfIneyML;
        cybMxWQCdJxYIR = cybMxWQCdJxYIR;
        gtHTCFxSW += IdnTd;
    }

    for (int aYKVUDULCWZTMMz = 822767950; aYKVUDULCWZTMMz > 0; aYKVUDULCWZTMMz--) {
        IdnTd += KHWzBJIbfIneyML;
    }

    for (int eqxWZNdHztl = 403556442; eqxWZNdHztl > 0; eqxWZNdHztl--) {
        IdnTd = IdnTd;
    }

    return iRvXharmjlytDsZ;
}

string zHBSTWRlfDqZIuOT::ISwcecoFbFY(bool mPVMraHpghFi, double tynof, string EaveeG, bool EjEhV, string QyHLhea)
{
    string czcBXARUjPS = string("oPiWqqFrUcSRXdraKxOiqYIqiYiFiRecwKFaGsTzUlfAXNVOLIdFJeCDLWGndxalWbjOnpMOrixQZYOIACdVbgwdmZJJWLZzXbMtjzIkGPDsQOXkUBECcjWTXUrLAzcTmXsXZFLXCfkDjpHNfsvmilPNeKTqcSVrpYK");
    bool BQCojlWR = true;
    int CutNzPV = -587845615;

    for (int wQTEK = 1522636377; wQTEK > 0; wQTEK--) {
        continue;
    }

    for (int JDuByGiemwwSf = 1945745008; JDuByGiemwwSf > 0; JDuByGiemwwSf--) {
        tynof = tynof;
        czcBXARUjPS += EaveeG;
        EaveeG = czcBXARUjPS;
    }

    for (int sczXTPMPXTIWrh = 291428852; sczXTPMPXTIWrh > 0; sczXTPMPXTIWrh--) {
        mPVMraHpghFi = EjEhV;
        mPVMraHpghFi = ! BQCojlWR;
    }

    for (int wKOBCBaHkOrULTFF = 1099668511; wKOBCBaHkOrULTFF > 0; wKOBCBaHkOrULTFF--) {
        mPVMraHpghFi = mPVMraHpghFi;
        EjEhV = mPVMraHpghFi;
    }

    for (int DqmRHAX = 1369474017; DqmRHAX > 0; DqmRHAX--) {
        QyHLhea = QyHLhea;
    }

    if (QyHLhea < string("LHaDtULsIEONYyUitsLsXUtHZpEwxjMVzvptORtGivQOxYIVdEwTGfjgRvdwONxsNkhmvKeAxzkeAHIiAauQm")) {
        for (int exqvHVaIcjYVURjY = 398938694; exqvHVaIcjYVURjY > 0; exqvHVaIcjYVURjY--) {
            QyHLhea = EaveeG;
        }
    }

    return czcBXARUjPS;
}

zHBSTWRlfDqZIuOT::zHBSTWRlfDqZIuOT()
{
    this->hNHHkerfYMBHMw(643017.7917170532, string("gRDueGKhQNMTmDsaDDqjdHmgnQbLxUZHOtGvHOSMPWBfHyCBPjOaMRBONJiLeBzNCsgOdViuMscCMpQMOkKyNZBGyEtUTwzXZnEcCyJGGpVwglEFWUXmhEhfSTNqPhtaMtbGwLXBLLcKsbOdPaHNKmqvyrkdEfUmHVYCrClFbAFUtESbYRqUvvlIvN"), -1875962288, -479623.8171438672);
    this->fbKPubmlbmMMZXjj(string("lCszOvKpADjOZHkUBFRMJPGIRqXOMNn"), -589654490, -730367.7651357198, -530666.1214267332, 499158.10271883104);
    this->rNryEtKixOMSYqsv(string("BfCIreanhmckYFcff"), 1628633375, false, string("RgRMMOjDozOFcoPJAxfHDUsQXEYFGRgsQFOHoqkfIVKmOBjBASHofNaneQeKYEQNMoAFwBqCRNoZphBWnGBSrNaYpgjkMCcDREJGhdUmQBzyxnVIAUubLRqtMMLEkZzBfLxOvDKGWaXSNeyDiTekWbfxTr"), string("UKHtyMCTKvlljgqrIdmYbqDcnREJmcNvOltXmsqhhQoZAgbNPvqSIAxRVujOuvESrBHGfibsnzcBeXanAkcBZWScCnwnyKJNXXahgpbMJTEAEgqxgIzybFkFyhHiyztvChQkIRFVWvTAoBORFWhzTSUdShkATNVoOwfkavRjjdmIAURTzxTkjxLwXFyjEvHUOdSqafytNlBQqnksSZyJS"));
    this->BnfAK(423702831, string("jWhbhcnhAgtVJNigboKpQvdpHyDXlztiTEPXxrkYmGNzvRuJRGsDYOkpxvTtXkbaKQgWJMTVXZELdxtWGUEiDpGkwLaKOIEaOtSVujtyOiHYhSEOxcnwgpRKeOCMIhvWWVvzwmWoXyybfNMTbPcYzYaRxYBdpVFBREBzTNFclLfINPQUuyqrFAOdOzZprdQIIvwdSJWlWVjrzLgYnleTofKOs"), 376913113, true);
    this->ahlwslQze(-1305023225, false, true, string("EfairUdvgVrneNNjKZLairGWpedcyTOLIeHiiBlFsgPyxneNCEAyQXgxafdazXVNOtlIMKhwsWVsFWYGabPL"), string("cQszUYLgJkKaLArSfKcjKrbUtVZFrrahYqVUEUtTvYShUcZBWRPDIkfMLGYeeazC"));
    this->UdNZqQsiYzYFt(false);
    this->KdLcAPdCCuvr(-28611.82327860326, true);
    this->ISwcecoFbFY(true, -845239.685340445, string("LHaDtULsIEONYyUitsLsXUtHZpEwxjMVzvptORtGivQOxYIVdEwTGfjgRvdwONxsNkhmvKeAxzkeAHIiAauQm"), true, string("eHZplhPxRwbWgLVhJpBwPTgkBiSUFIHBZKgCUIbRwQLlcGrcnCJUTGPCKIjRFXAISrHkdSYjtehwIMgdcLgpOccRI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JvgGy
{
public:
    string YTmBLQ;
    string qjPLIaJlgElUafiM;
    int graDu;
    bool IoSocUOw;
    double unDtZpYAhigTII;

    JvgGy();
    string XQtRWFM(string jSHhjQqjbaQtHrjC, string CXpfZYVEE, int rvyyDFmMcdYiT, int lttdWBW);
    bool PRFITnWwSLoYzy();
    bool vguqnbVoVfaE(int tNtOjEDYIOPMW);
    bool pavLs(string cJZNvpJWSCyjv, bool mCQmhQqkTV, bool YmwuaPiUFuLrhyVS, double lxRgzUAgHla);
    string EFQRNaWIuX(bool EKRWWnRCXTXHDe);
    string dCbxhbZgb(double mPDRokBA, bool LFlUslYZ, bool fcSKHk, int voneYkC);
    double OPoxk(int AnWvrnJhnhrDwdg, string BZlxyieNt, string mkYOrNtzS);
protected:
    int xrhdKRVmJ;
    bool DTXFC;
    string eSpPso;
    string aeDIncxeMksS;

private:
    string bySFjITTQDZw;
    string yolEeyyfBtxnAZ;
    double FWXsTmG;
    bool HscDoRXHgxArb;
    int gKhsuqz;
    bool ENkcypDKiySdg;

    string KkXHowCpNYvDfY(int oDYHBZGZhToW, int LLRcjeSTJ);
    void SqpYJHuerwIOZP(bool yGiKomwB, int rqbkCWHSUKiWCGLy, bool rIdXFmuAMm, int CLxoqEqMwiBL);
    string lEfvyMEO(bool ZkdyQJFkPrGJBWb, bool CcPvXUPbIAx, bool eCokqhHTp, int VeWIgYYxq);
};

string JvgGy::XQtRWFM(string jSHhjQqjbaQtHrjC, string CXpfZYVEE, int rvyyDFmMcdYiT, int lttdWBW)
{
    bool EDMIt = false;
    double nQGnzEwjFr = 66688.86515176932;
    double vtaosQgkTJONzpVI = -534635.5828519842;
    int wKoLYLILy = -39721983;
    int vzkQllrVGvlueHUs = 283266222;

    for (int lRfapVY = 1429398103; lRfapVY > 0; lRfapVY--) {
        continue;
    }

    return CXpfZYVEE;
}

bool JvgGy::PRFITnWwSLoYzy()
{
    double gHFhjGNG = 929238.1770673284;
    bool DxSANHiU = false;
    string FFwNrPr = string("oLaTmJQKaDMyCMnbkHPdrxFWEUPFrOUZZoDPuJcBDyIgWzkwKoJjJwXopYeZCzzYmpPHHMuJmnnlHkNsNvmZqYgBRxTzNNLgFnKWLl");
    int jYcYhfhaoCPVYO = -1287295056;
    string cTJFiCI = string("odZomByWCrHgqBFqedtdabXmomSpbqjpFzIgSiiFMQVVVEBVwsPCEzQjSylPHGmwhvgkScSiMEzooyhazxBlCEDeykfDdThgDKRlMHkWxaTxkHsDBaOABCrYyBfKhjlSmkrxRUFtbCwIVjSpnacQsRZCVPKRJNNuEvmHAlwtTRZeUoQjmvbklkuvwMMCoVTEnXvydlUJbFT");
    int ErIzTNx = 303172100;
    int WniyJlMjOnR = -236736286;
    bool fHWStLHigjmuyN = false;

    for (int nGeTQGKZITaFf = 699454917; nGeTQGKZITaFf > 0; nGeTQGKZITaFf--) {
        jYcYhfhaoCPVYO -= WniyJlMjOnR;
    }

    for (int cBTxJv = 2118651243; cBTxJv > 0; cBTxJv--) {
        fHWStLHigjmuyN = ! DxSANHiU;
        gHFhjGNG /= gHFhjGNG;
        jYcYhfhaoCPVYO /= ErIzTNx;
        fHWStLHigjmuyN = ! DxSANHiU;
        ErIzTNx /= WniyJlMjOnR;
    }

    return fHWStLHigjmuyN;
}

bool JvgGy::vguqnbVoVfaE(int tNtOjEDYIOPMW)
{
    double ztexrycalKnV = -810745.4106587394;
    bool eRLYBd = true;
    bool fAAFWeOcMEfOP = false;
    int YhkYeKi = 1751470507;
    bool ZiPsqmIbrPR = true;

    return ZiPsqmIbrPR;
}

bool JvgGy::pavLs(string cJZNvpJWSCyjv, bool mCQmhQqkTV, bool YmwuaPiUFuLrhyVS, double lxRgzUAgHla)
{
    bool TDptnoyPoaBVPoF = false;
    int BMfIMVVOdOT = -1615840587;
    bool CkhpxaFvsZT = false;
    string nIzcvySMStqbqPJ = string("bBZHZUioLiZspgwJElxltpgWVrTogHbKZfWLFDJtSuUIMcLCSwK");

    for (int EJzQovWd = 888604810; EJzQovWd > 0; EJzQovWd--) {
        YmwuaPiUFuLrhyVS = ! TDptnoyPoaBVPoF;
        TDptnoyPoaBVPoF = ! TDptnoyPoaBVPoF;
        mCQmhQqkTV = YmwuaPiUFuLrhyVS;
    }

    return CkhpxaFvsZT;
}

string JvgGy::EFQRNaWIuX(bool EKRWWnRCXTXHDe)
{
    double qvHYVbWNcfAc = -190475.3129007027;
    bool zeoczkkSlQVK = false;

    return string("LfXHVaTitvyPzCXGMijwxyUkjmuNIrKdBXmZNErxhpFGmelawoDDufzRxAkvkySllgqoHiSnQWIJnWGNFpvefNtQsygEhBvxnjtPnaigFvzkedRBMxHgmbOvAUGVsSwUGcDngWQLiJqeSCuJMHyrbQUXgKHIiJeQpViTUqRoRKnZmpipTdfTg");
}

string JvgGy::dCbxhbZgb(double mPDRokBA, bool LFlUslYZ, bool fcSKHk, int voneYkC)
{
    bool rDXwZvhiWNKO = false;
    string PfoZoQLjSMU = string("BKslnndINximESceLkVNGvkboHGjApDKmisUVdHLmZIQhvYBCYYlCnflmjEXdCIqfAFfmPTvFllcjrFohIRjNTJgoHxWvKbWgTPsoOWxycVaSdcmchkKWwwJtSKRFoBZHVrmYHYXRtLdoARKvXMjBAtLoprempxdiRcjflJawcySdEZBKMsZuRSBmgBZkboRHlxtiHKKJbRFPXyNysixPqush");
    int xmlva = -1461788062;

    for (int VvJgDvPwn = 371933489; VvJgDvPwn > 0; VvJgDvPwn--) {
        continue;
    }

    for (int UjUkPKnsDes = 1800968328; UjUkPKnsDes > 0; UjUkPKnsDes--) {
        xmlva *= voneYkC;
    }

    return PfoZoQLjSMU;
}

double JvgGy::OPoxk(int AnWvrnJhnhrDwdg, string BZlxyieNt, string mkYOrNtzS)
{
    string uNStgTpeELjrUbR = string("EKhPMqSIqbSgmLNXtAJTPRPDwagZJNYfHxuzLOKWrQTLxnnHkDOOAbSpapkiPKtnrYibbxRQnaiboUUtCcEHLeSHXLrZdkqhxsxVOcpvJLlfcZtEGoYAfWvysmgCnNYJXfTRlDXxigzQqsJYfVFQMmnBctbINjlIWDORUZUImxqEGltXfpoLOgKwLjHBtoAvkPofarQvp");
    string HSzEARxf = string("TnucUhXQtthafTcQAaniBbwZLtLjkPiREiROJGCnfrPfwvJTCGjiIIjTJCfbxaxjeKAXlNoiBmUaWjnjxMFgMGJjOewZAyBYnliCXfeLcslVNEDOSDLbZfEmliRSCKUMVmQOcppARsgeIMoLFtqSSRMQMGoKjHfNYIrueXafetkjsAMZdlILLDIgedOltNtnnZfHlPYSFOD");
    double AoeANNAL = -132203.59588175034;
    double bzaRIPV = 984619.733610491;
    bool HGdxpts = true;
    bool xZFustjopTW = false;
    double bVuEcgw = -692457.862836813;
    int aMgmobuvchKUH = 786503866;
    string rAyDNIcVX = string("wIQYBENXhkJREJUImZsoYyKZrFwkxDczmOgSLPMMuHQIvPgVikvZXRBLaxfKCpsSMdPTYhWIGwsZAwsaEyynsDuEWcmgLskFMSFFCMw");

    for (int TafQTrUFoyX = 1884899323; TafQTrUFoyX > 0; TafQTrUFoyX--) {
        continue;
    }

    for (int VyufwULUIflX = 668117381; VyufwULUIflX > 0; VyufwULUIflX--) {
        HSzEARxf = BZlxyieNt;
    }

    for (int YTjBMgNNshkCU = 367646790; YTjBMgNNshkCU > 0; YTjBMgNNshkCU--) {
        rAyDNIcVX += HSzEARxf;
        HSzEARxf = uNStgTpeELjrUbR;
    }

    for (int csBLgyUjkmeq = 731902886; csBLgyUjkmeq > 0; csBLgyUjkmeq--) {
        continue;
    }

    return bVuEcgw;
}

string JvgGy::KkXHowCpNYvDfY(int oDYHBZGZhToW, int LLRcjeSTJ)
{
    double XAkxem = -122962.98827833681;
    int AJmvKIJH = -1248509363;
    string DEObQ = string("MAYZypIMhXICZHaufqbHkuAWcHwcccKuvjXByUsGThnZGkXbFgwqyvpezGjVHONAphIDvjvXZTKYJbPqnkVCWEhfjPMmbAcYQMGgemXQmGcshNrVoKvXWTTLEDegkDgCdzygpwjPClBReXULgAtctlUSsnnRTMsXsnPJBKNyhLxhFnHxFImOKLUxyaQIwCImGqzVPDiUtmvUkuHV");
    double TNUMx = 649382.368553695;
    double BxVaVXZC = -968849.8253680997;
    int RmwJmoqOrLi = 72123041;
    double IBFZJfchUek = 777707.0584914277;
    int VuyhsmPZIH = -1526651495;
    bool oGysqadaZmZRptHI = true;

    if (TNUMx < 649382.368553695) {
        for (int pWoJF = 81755904; pWoJF > 0; pWoJF--) {
            BxVaVXZC += XAkxem;
            BxVaVXZC -= IBFZJfchUek;
            LLRcjeSTJ /= oDYHBZGZhToW;
            LLRcjeSTJ += oDYHBZGZhToW;
            IBFZJfchUek *= IBFZJfchUek;
            AJmvKIJH /= RmwJmoqOrLi;
        }
    }

    return DEObQ;
}

void JvgGy::SqpYJHuerwIOZP(bool yGiKomwB, int rqbkCWHSUKiWCGLy, bool rIdXFmuAMm, int CLxoqEqMwiBL)
{
    double KAuHeT = -802131.962878498;
    string AFHfRuGnNNW = string("AdFaRg");
    string WhaUkOH = string("sVcuWlYqrRCTuylfxXqMwBgyBrFmkEJMfNzcUuVMCTBRAidrsEGrYVDCqPQJcjwplNjZIFFOzGHXlgwFtMBG");

    for (int rhBclesF = 1744423389; rhBclesF > 0; rhBclesF--) {
        WhaUkOH = AFHfRuGnNNW;
        WhaUkOH += WhaUkOH;
    }

    for (int rHWwhYeNGFGzU = 1749911385; rHWwhYeNGFGzU > 0; rHWwhYeNGFGzU--) {
        yGiKomwB = ! rIdXFmuAMm;
        AFHfRuGnNNW = AFHfRuGnNNW;
    }
}

string JvgGy::lEfvyMEO(bool ZkdyQJFkPrGJBWb, bool CcPvXUPbIAx, bool eCokqhHTp, int VeWIgYYxq)
{
    double iGbYlzmfiyt = 996249.6771358474;
    bool MgVxH = false;
    double lsQqcwNRbPgKLjM = -749561.1115020843;
    int YIuHBl = 1852730620;
    int LuOLYLgJvcPJjL = 1345452360;
    double dTyMrBzLFmPOfR = 95551.26316968759;
    string PvImpMNmWe = string("FCYsXApVvQDqIlqRsAHIBHPoNgBoseTlvqllhEyeQcoxxpvSSYTKRNFKnEAzpuxDJlqSThwVaHXdAhUjUmGyZKPfeTpOVAYmUatlzdogRYyoWFPqPqmwjIjnEFaegejPANEWYrsrcFXQXIGAsKchxMUlEWrOycJupMTGgaacOvbyFSQFTDJNQNvpfbPdZqAzNjDYFifxnLj");
    int UVUSnHL = -1558778238;
    bool FhARcVtyKyxa = false;

    return PvImpMNmWe;
}

JvgGy::JvgGy()
{
    this->XQtRWFM(string("enqYuQNmuelehYxWMBMoLaLaQuYyLjCiXwqgPqJmuYC"), string("DprnadgxQIKnXGqAMORaborswNnqXChCyYmUtNTQo"), 627041709, -861036723);
    this->PRFITnWwSLoYzy();
    this->vguqnbVoVfaE(1188657333);
    this->pavLs(string("SkldYQZcjjFlpbQBAIIkuWkElaQNocrfkXNmWZXAaTlBcwUjLzBwIVUZfxeqEXeiiyYKHJWFRzFFVrwisPrfvFfePIHYrZwJHWyiZKrRpjBkYyBs"), false, true, 110100.2826725862);
    this->EFQRNaWIuX(true);
    this->dCbxhbZgb(559215.3830263385, false, false, 52676166);
    this->OPoxk(-2122076618, string("nIVQnNyPNVKuyDXVXNgtAuRVmgsjJecTcO"), string("TIxeCpDdeWMMJlDTouDrYHQSuYsrKFkfthPljGWXIbpHZIOxQfQmUSJbkZsJgoGQJREHIBqbeNQGNvsUeSGxLBDRQAnvt"));
    this->KkXHowCpNYvDfY(-272531255, -1776139965);
    this->SqpYJHuerwIOZP(true, 751932138, false, -284543231);
    this->lEfvyMEO(true, false, true, -113592514);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uDhqGuZHKNuqtRP
{
public:
    string BtaziTVPGZeGH;
    bool sxevrccwYY;
    int EBOXMNxzrB;

    uDhqGuZHKNuqtRP();
    int odimWZ(bool YiZXRl);
    double EljiWqnxAEZE(int frDUXlLRWEh, double qGEZcHvlc, double xqhRpLPRxKhT);
protected:
    int fnjiNLQWrlTCUwCx;
    string AkTvyagDQHiS;
    bool lVrbZFaoNxXl;

private:
    double aDdpVvztNfsIcAAM;

    bool uOjisRnDdO(int uxmpPi, bool okPERDOaly, bool OTEbGENXK, bool ujhMikZiMiXN);
    string WWUrLdqMq(string uuKWdc, int kOBbMljOJsdFEn, string EVsARGdBcB, string dyUviNZ, double uHReAANmFDq);
    int HFzBUoC(double zIbgZr, bool YzFePjzBz, bool GuWCtu, string mymzQGXubC);
    double OITyhlBZb(int yCbzjZoFWrJd, int dgWRTz);
    void qNizkUJ(int gxLbcngq, string JIezwAuIwGkDYO, string uFzAmvNnOkwQ);
    bool WZMzp(bool DXAWVhp);
    void ZNjMfyFwpST(string SvbvPmdiqJkX, double tfXBnYF);
    bool xWuGbiFG(int aBgJUQ, double qIzRH);
};

int uDhqGuZHKNuqtRP::odimWZ(bool YiZXRl)
{
    bool pUhgNmupMM = false;
    double cWnZp = -359657.4137356669;
    double VPgTARVedf = -1043767.2794260171;
    double QQhLKwUqtfrbuAv = 304245.57475770585;
    bool XyAiPts = false;
    bool MQDzrTOQAXrto = false;
    double DOYSZsFDkvnHEhCw = 1021254.5508951235;
    double lQsobvJlSjRl = 424398.44487849635;
    int LLuhDZSxvcDYz = -278072374;
    double kzjhwMu = 232145.03559917895;

    for (int bkVDju = 1997518420; bkVDju > 0; bkVDju--) {
        pUhgNmupMM = ! YiZXRl;
        pUhgNmupMM = ! MQDzrTOQAXrto;
    }

    if (QQhLKwUqtfrbuAv != 304245.57475770585) {
        for (int lvCPfIB = 1575668452; lvCPfIB > 0; lvCPfIB--) {
            MQDzrTOQAXrto = ! MQDzrTOQAXrto;
            cWnZp /= kzjhwMu;
            YiZXRl = ! MQDzrTOQAXrto;
        }
    }

    for (int deyoJq = 2028203424; deyoJq > 0; deyoJq--) {
        kzjhwMu *= lQsobvJlSjRl;
        kzjhwMu /= DOYSZsFDkvnHEhCw;
        kzjhwMu /= DOYSZsFDkvnHEhCw;
    }

    return LLuhDZSxvcDYz;
}

double uDhqGuZHKNuqtRP::EljiWqnxAEZE(int frDUXlLRWEh, double qGEZcHvlc, double xqhRpLPRxKhT)
{
    double hwPASzalhcPG = 90145.07695559041;
    string aYZLFvxlgoacX = string("eezeqrneVBGIMEysqcJEUSzqusKdXxJZGzcjqiXeGPzTJHtfjRQHiTTOAcRMICoMEimwVHfXPoOWIXYEdGxxTBeAVbcNfIgYOOerbPHUwBQYsicnfwmYjpliVCXjyfEpfm");
    int gRlYBHyFqRdHA = 1052209003;
    int dgszbmzvw = -1159386666;
    double uAADbqyhZtPxyu = -68241.03289336039;
    bool lKCZxCj = true;
    double kJNORKdprN = -452012.3489631403;
    int YmMXdX = -1201330011;
    int xkKZgumKcsb = -673521007;

    if (qGEZcHvlc > -803681.024239177) {
        for (int mguYFcsXTEbV = 2029733982; mguYFcsXTEbV > 0; mguYFcsXTEbV--) {
            xkKZgumKcsb *= gRlYBHyFqRdHA;
        }
    }

    for (int wquaTVuEW = 232297460; wquaTVuEW > 0; wquaTVuEW--) {
        xqhRpLPRxKhT = qGEZcHvlc;
        kJNORKdprN *= xqhRpLPRxKhT;
        qGEZcHvlc += qGEZcHvlc;
        gRlYBHyFqRdHA += dgszbmzvw;
    }

    for (int jnUDJaPraTWDst = 1698658160; jnUDJaPraTWDst > 0; jnUDJaPraTWDst--) {
        continue;
    }

    for (int xLekB = 266246678; xLekB > 0; xLekB--) {
        hwPASzalhcPG -= kJNORKdprN;
        uAADbqyhZtPxyu -= xqhRpLPRxKhT;
        frDUXlLRWEh /= gRlYBHyFqRdHA;
        kJNORKdprN /= hwPASzalhcPG;
    }

    if (dgszbmzvw <= -1159386666) {
        for (int wPRNxwrdhWwufzN = 1476952369; wPRNxwrdhWwufzN > 0; wPRNxwrdhWwufzN--) {
            dgszbmzvw -= frDUXlLRWEh;
            dgszbmzvw = dgszbmzvw;
        }
    }

    return kJNORKdprN;
}

bool uDhqGuZHKNuqtRP::uOjisRnDdO(int uxmpPi, bool okPERDOaly, bool OTEbGENXK, bool ujhMikZiMiXN)
{
    double ILdolcPDuBpI = -266032.5109702616;
    int hvaDOTlAw = -1170069681;
    double GCGtmTLwpKHLjz = 953774.8700672524;
    bool YuukyBHTDesGkjJS = false;
    int zrWmky = 279587523;
    double aWTEPCfxpRyWOg = -27222.64882293021;
    bool hKvJJhvHkbTsv = true;

    if (aWTEPCfxpRyWOg <= -266032.5109702616) {
        for (int sBVdaeZByky = 133066112; sBVdaeZByky > 0; sBVdaeZByky--) {
            zrWmky += zrWmky;
            YuukyBHTDesGkjJS = ! OTEbGENXK;
            YuukyBHTDesGkjJS = hKvJJhvHkbTsv;
            hKvJJhvHkbTsv = OTEbGENXK;
            okPERDOaly = ! OTEbGENXK;
            ILdolcPDuBpI *= ILdolcPDuBpI;
        }
    }

    for (int JONQWQfMDlgMMmgk = 1163255142; JONQWQfMDlgMMmgk > 0; JONQWQfMDlgMMmgk--) {
        OTEbGENXK = ujhMikZiMiXN;
        YuukyBHTDesGkjJS = ! ujhMikZiMiXN;
    }

    return hKvJJhvHkbTsv;
}

string uDhqGuZHKNuqtRP::WWUrLdqMq(string uuKWdc, int kOBbMljOJsdFEn, string EVsARGdBcB, string dyUviNZ, double uHReAANmFDq)
{
    double oFSMwPaawxKox = -913864.9570779483;
    string fyDmaxXxivdpIBu = string("pRDFPKsJsiGGyMAGdvPHGJBCoMyrCDBOaKKCVoJzsulig");
    double vhqwlRZlwvF = 310856.6719882371;
    int FuMRmiAFusuCyJ = 469385920;

    return fyDmaxXxivdpIBu;
}

int uDhqGuZHKNuqtRP::HFzBUoC(double zIbgZr, bool YzFePjzBz, bool GuWCtu, string mymzQGXubC)
{
    double ScdSLpetBYtZIFwP = -870447.276318664;
    double jPzHuzRrH = 324437.77513607376;
    string tZdAwGrSRA = string("BpjyQNdmcfZOYZxpDnopmlmadASygtIZjmTOctwSGMsucDpNqqPcrqnnDVQGeSnhPmjQUnRFUtXBIUgTRhRnXNtiZGkyRmdZGSuqDkdYHSQAaqR");
    string iLgXQ = string("JVUZBnSAwnvxuKCQBYchedlXFqCDpbLsZaCUEzIboQNcjBPhzvHtAQJgOCqQIumjmX");
    bool OePvvomsZhaEFYBy = false;
    double etCfdgnkg = 88664.0498628636;
    string haQGXuMjJNAUx = string("aOJniHCGvAdylVcajbCSiGPELVZnwvwbaVkgmjTbCfNmKlUONtukogOCqZxkypxZZFZhsSXNGkTSOZrXMUvVqegohXWUREOLqLPUkMdosmOsCTblRXQqkzQGFADxpqEcWXfGiHSZIhHJdjcIcmabDEw");
    bool bNFheXxpBlNGDXCW = true;
    string HVtIcYO = string("SlHqQFcgFtdEtcAIkoZxBqklgOAerrEbZhjrBhBitmTWfkemMryiWtrmGRpNmOWbwdPLaefJPPwCgqLTeWdbUuvgcQchJptietbHXb");

    if (zIbgZr >= -870447.276318664) {
        for (int JskhiuMSrM = 22081263; JskhiuMSrM > 0; JskhiuMSrM--) {
            jPzHuzRrH = zIbgZr;
            ScdSLpetBYtZIFwP -= zIbgZr;
            haQGXuMjJNAUx = iLgXQ;
            YzFePjzBz = OePvvomsZhaEFYBy;
        }
    }

    return -4969136;
}

double uDhqGuZHKNuqtRP::OITyhlBZb(int yCbzjZoFWrJd, int dgWRTz)
{
    int tLkUgDwOVp = 190217258;
    string DCmoMfX = string("btfZpWBYUsWbySaBkWrytHexPZlxGgNoeksvzRsBTDeaniapPJCeRcGijKwNPCmDzNMcHXfmlp");

    return -1009454.5300791675;
}

void uDhqGuZHKNuqtRP::qNizkUJ(int gxLbcngq, string JIezwAuIwGkDYO, string uFzAmvNnOkwQ)
{
    double ZawiDyL = 269273.58840572357;
    bool AXMzPyFhzuR = true;
    int KqSIwxmLS = -664960913;
    double oMvJws = -621116.8886502717;

    for (int zIjftoWUIYPXxF = 1684904534; zIjftoWUIYPXxF > 0; zIjftoWUIYPXxF--) {
        gxLbcngq = gxLbcngq;
        ZawiDyL *= oMvJws;
    }
}

bool uDhqGuZHKNuqtRP::WZMzp(bool DXAWVhp)
{
    double dSKWiNjkXbXEo = -548983.5300859837;

    for (int qwnZSPibW = 490175596; qwnZSPibW > 0; qwnZSPibW--) {
        dSKWiNjkXbXEo += dSKWiNjkXbXEo;
    }

    for (int iyclzRvHxX = 1665277953; iyclzRvHxX > 0; iyclzRvHxX--) {
        continue;
    }

    return DXAWVhp;
}

void uDhqGuZHKNuqtRP::ZNjMfyFwpST(string SvbvPmdiqJkX, double tfXBnYF)
{
    string PtuFI = string("RQpCcjsULvtiNBSobZlHcroYhhQCNWwi");
    int jOBLNDeLTza = 541281403;
    bool jtoabKL = true;
    bool LLlKEqxrui = false;
    string LjudPN = string("kJuAPkOtVqyEHoGlIPDQFeMlbhLkWTFguouWzAUhoJgUcvLKnytnzVGsZyXNEklHSgLVBWqdjRc");
    string MfAkMmIGJuEQB = string("jUZaZXkoSDmbVZvkrnGawjQelwjVmbmcSfbMFZukawglHvrmRXUFsYsToMiFWwcOLH");
    double bRwHU = 317074.2825960924;

    for (int LjMCcnhCu = 867433977; LjMCcnhCu > 0; LjMCcnhCu--) {
        LjudPN += PtuFI;
        LLlKEqxrui = LLlKEqxrui;
    }

    for (int XoGduvJmqygNiD = 936002997; XoGduvJmqygNiD > 0; XoGduvJmqygNiD--) {
        bRwHU = bRwHU;
    }
}

bool uDhqGuZHKNuqtRP::xWuGbiFG(int aBgJUQ, double qIzRH)
{
    bool KxeIyIfYt = false;
    string WcJabxZ = string("QfrcFeQVoCBqRBfhILDNLoiswRBGUUeENLfIXilLSubhXexmLWBZlAHySGMgjyJhAqKrkOwnLiVROAVeNXFWcgcLsNFdFEbBXUdnSCEGTrFDZsEcBnNtwKaTCbHepLOaZyrAMYJQfqcqllbuloTSKwNIgcHqvyWTYptWsFkVQJhtBtUtMzfGaeTxhwIDndKmHfzMVdeyhiCRD");
    string EtXukWdRjsEHK = string("KHYbVclJgWsOkDjfrrBhkwsSPaapGOmPnmPhwAJcmCXCsNltiPhOfgugzxgMeLiScgRwRyVeoNNOewGvVaWDXlnSqECwLqQyJEutXsTJvfJnOIQASbIimVHhAoGGClnqbJjScQEvhFevAZeLeOfhrxawvgZtXcQAA");
    double CtIfjhBVkC = 494582.6657668271;
    double gBXPbfXNUUF = -212970.15993728818;
    int BGxOqgY = 148148182;
    int wsgbaDO = -1418590374;
    int KiAXRkvuAQ = 497369152;
    double lCpsvhnYnbLIj = 401773.2082516843;
    string uRuBkaNMObO = string("kBciiMeXWozcjIvNMbLIdmubarEBYdqtGRWfpbQwqRHqxykqwHPyhOIathtYOdRbzEgDkxpHqfLIgkodbBrlwwoBXUnBUrpDLbELMXxSleNawclQqoSABOixRcVzJbNOcqCcSYgEGehrcQQokHiPQkVcjdQnWwzJmcMbLSOgqVjVZDvUYTuhRQzKgFEZnDnibnMWFCNLHJWI");

    for (int xzVGUcmZFkol = 1889957974; xzVGUcmZFkol > 0; xzVGUcmZFkol--) {
        continue;
    }

    for (int EqElqFLxrONW = 1633031357; EqElqFLxrONW > 0; EqElqFLxrONW--) {
        gBXPbfXNUUF *= qIzRH;
    }

    if (KiAXRkvuAQ > 148148182) {
        for (int jeiAZVzOZc = 2014367670; jeiAZVzOZc > 0; jeiAZVzOZc--) {
            KxeIyIfYt = ! KxeIyIfYt;
        }
    }

    return KxeIyIfYt;
}

uDhqGuZHKNuqtRP::uDhqGuZHKNuqtRP()
{
    this->odimWZ(true);
    this->EljiWqnxAEZE(1039826993, -803681.024239177, -350585.5115622943);
    this->uOjisRnDdO(486685670, false, false, false);
    this->WWUrLdqMq(string("NCLRfibWnIyFnszpjgOzyawyIlFPRkTxDPhQJcrZcGlYeIJWbYyNePcinzJcsUVdVRapjMvlVDhTNDxxOoMFDsKYzPXxKyfYbDGPgWqJYAtecIhHssIWoNjYOGiwcUyCiQsvH"), -712307534, string("dcyByGOGOiuVytRmLSIFAukcAfQJ"), string("PPPyUvNDkNXtDPNZqvPAlqNdHSfgqtveISAthxOCRhCJgFTFLPmCuwWQKfTGIXJrdFVlbnFsoNRdHbGKcxAoYiQFmZDRAnShkePgFyYUWBcZZwKoGERKZ"), 928347.4461982202);
    this->HFzBUoC(-832202.685286415, true, false, string("tFyXVwOBZAnAYeIbjVwkNzMjoYnuqIrhZFyWLReQataaSjmXsYUVfVyMNXYjcOthPBnkgBfkVGRLjIXYHjXMIFyTxqwOpEouuqyOLCKbrPlSVxwnRNPOXGyaOUOYJiyQroWRbptxxauahvPyhfNfLQzZdrcSvtgzlvqixTRFtrPDDebIljhtryjapwMpjcbQpXpxywMi"));
    this->OITyhlBZb(1122366546, 1841073966);
    this->qNizkUJ(-1429370458, string("XUmkeqSZftaqhjJWEHrSQnrUVXFKfQMMUlStIqXHrwsikZMlAcwiNVceKBXkUcHFNqAbxWHiraSCwsxCiSOQhSaRiUgrl"), string("aHBJFkiNhBjRjYhjdCOcjVUgGQWgmoqjtRvoTrQdnIRqiVrDUYbXXQNuhDwgGDxUDCpEkwDWtWKhEADwexkFXlxuyfYmUVseLmtmfzStFjWATgLcGFUOeUAtiiFtNsGFtEfVKsSiWbADVDqmhBMjAisYWfhKcRwsHxRwopCAOrqvLVPQTandiWoVgGEWqKPrFuBMvfJUNEzqzykQtPtkOn"));
    this->WZMzp(true);
    this->ZNjMfyFwpST(string("ZqvGijGzshPMbjcXjvgEgiaTcRrcFgLirulvqMeqgWuPmYQxEFBRUzHFkEaaBLyEcRgAlGSoVUyuiRXi"), 735657.1444260953);
    this->xWuGbiFG(317114516, -160542.23232272457);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cEBDtZLBsgEuXd
{
public:
    bool aSQnzgzW;
    double UnAlVwwyFxmSVA;
    double mCpFtxiJvXk;
    string BSRdYQLlBeRpgw;
    int DPrYEj;
    int zsigZwZJzZPWMUgD;

    cEBDtZLBsgEuXd();
    bool qXZtbrNRsPOqWie(double NLtTVXHRvvvRYL, bool OjRoaWM, double iihtmeMnj, string MoJtfsFbzrKcRn, double ViyahjHoyvKGF);
    int TabjbH(string HwrVNTTYs, int ucKVv, string kmjNbPOuJ, int xOksdRKdnIefyymz, int DfHTo);
    string obojUSR(string YZjrBEsNDxL, string DMTbuBMBfQyqyyl, string lArjBYCFaO);
    string MQgYXguD(double siZXVkrQkxcc, double oLNoOhUdPWPgkgt, int QCtEk, bool cJatgmHLUy);
    int NKpjWxiarbaqNhz(double uUrvXEpqCOfup);
    int yqEyEmXwYZgFGgT(double hMjuYiKnRf, string dtLEfTbiQXZ, string BQqhjaHqemhzyTs, string WKeIDJoUWdaD);
    void UhtFjbncVs(string QrnKuqNySEF, string RyvvvYAvCcc, string ysUhQFhaONLBd, double tDQPlHbgEKTHI, int stvWsL);
protected:
    int JUCKpBoxaviI;

    double MHfMwZNP(int HYhvfiuDCksdjCQr, bool eyjyuyViMOg, string VfopjODaDAXLU);
    string FnYkPFvNcFHQPKo(int GuGkazRbbWNSY, bool TkPgAlPQyuXhEy);
private:
    bool nvGKVnV;
    string FgoBDCeO;
    int cyZfflHam;
    int mCyHfjaHvIhgHB;
    int TBcxJN;

    int qYYSNbKEGZBWC(double pVWejYvRMJh, int ytutiWHaFKnWql, double DOpCwEFnxhiEPL);
    int DVQGtsFj();
    string VejhlJcfVTw();
    void aPjaP(bool AKnTzuoO);
    void ISMiSazQvhE(string GQLQMCzL);
    bool fPEjdAkgLm(string UZfERpmQANGw, double JDHpueAjSPClpqRJ);
};

bool cEBDtZLBsgEuXd::qXZtbrNRsPOqWie(double NLtTVXHRvvvRYL, bool OjRoaWM, double iihtmeMnj, string MoJtfsFbzrKcRn, double ViyahjHoyvKGF)
{
    int MGdNGsPgKoDWVvm = 683001809;

    for (int szJUSwip = 1062049419; szJUSwip > 0; szJUSwip--) {
        iihtmeMnj /= ViyahjHoyvKGF;
        iihtmeMnj += ViyahjHoyvKGF;
        iihtmeMnj /= NLtTVXHRvvvRYL;
    }

    return OjRoaWM;
}

int cEBDtZLBsgEuXd::TabjbH(string HwrVNTTYs, int ucKVv, string kmjNbPOuJ, int xOksdRKdnIefyymz, int DfHTo)
{
    double PCWtCRTGlvVyD = 704875.7755602883;
    double WZZfLzukycmSf = 849545.1898807622;
    string ePKlTuK = string("kYrHzdAwhqcSKwflYtDLJYTjpcYplkvupiQTpssDkdLlnrqutJcoFJjnJXGisSVFRrnrlmdrjmkmxilKiyIBeOnmFjdIWBhGrHIcrpaUjfBpZaAHBgAaYKmneludRAoKGQGMuejbcjaDjcNOMZuPHsEOSmfUSQdnheFjCpQHlyzddwMoHwxQzIehXHDWWPuSRbVLXsHbIJVaE");
    bool bjeRhW = true;
    bool HLurTdciA = false;
    double fxrSNwAcSjop = 258556.2312922697;
    string DklTnCXf = string("WaEEDzTsulrjBHTvNkaFCPEDbPdRwqveBqlaIjNDzMTPbnqpyzmfszyVLUaIjrJrGvxDQfKDaxldfzCLZKfGHDAmzExKKLaKBxJbdIAkkMYyXnYnupJPDOMkVvConJVMNbVjejFYNYCUHcOpW");
    int mDbIoEn = 1923994809;
    bool kuhNTfyqT = true;
    int tpAgKkOANG = 1662771372;

    for (int EpBDLclJkHteF = 2087301057; EpBDLclJkHteF > 0; EpBDLclJkHteF--) {
        ucKVv *= tpAgKkOANG;
        ucKVv *= xOksdRKdnIefyymz;
        WZZfLzukycmSf /= WZZfLzukycmSf;
    }

    for (int mAkfROvxIGBRorh = 1163314858; mAkfROvxIGBRorh > 0; mAkfROvxIGBRorh--) {
        continue;
    }

    for (int EtXdQovluuZQcG = 252027253; EtXdQovluuZQcG > 0; EtXdQovluuZQcG--) {
        continue;
    }

    for (int NlnDipQOz = 1683810022; NlnDipQOz > 0; NlnDipQOz--) {
        kuhNTfyqT = bjeRhW;
    }

    for (int MkSLagVtvBJ = 1455556620; MkSLagVtvBJ > 0; MkSLagVtvBJ--) {
        HLurTdciA = ! kuhNTfyqT;
    }

    return tpAgKkOANG;
}

string cEBDtZLBsgEuXd::obojUSR(string YZjrBEsNDxL, string DMTbuBMBfQyqyyl, string lArjBYCFaO)
{
    string wFgROYOvJubC = string("dMnXkirErmSmjBmFQeieQdlDDHIVernIcrSmOvavfvVrHmhfyePFzHySiEINXkiEwAQIKgadxIgIanmVTnNJfwbWBnHcQlzHQmUNFDZlZMyckBuVCACsMzZUjVpaaMAdciQLyGXqNaClDmPXSrtVPjctMnsVMJBywZ");
    bool kNuWIKAHRyKEi = true;
    int uBJwybmxi = 21227948;
    double qNVYHgWUi = 542774.2959206979;
    bool AbDdKyEXpMfB = false;
    int CuPnDcmWMP = -304037122;

    for (int UCifcSEBJMmdeEIC = 1465047580; UCifcSEBJMmdeEIC > 0; UCifcSEBJMmdeEIC--) {
        DMTbuBMBfQyqyyl += YZjrBEsNDxL;
        lArjBYCFaO = YZjrBEsNDxL;
        DMTbuBMBfQyqyyl = DMTbuBMBfQyqyyl;
        wFgROYOvJubC += wFgROYOvJubC;
        DMTbuBMBfQyqyyl += DMTbuBMBfQyqyyl;
    }

    for (int yWhPd = 2090269761; yWhPd > 0; yWhPd--) {
        lArjBYCFaO = wFgROYOvJubC;
        AbDdKyEXpMfB = kNuWIKAHRyKEi;
    }

    return wFgROYOvJubC;
}

string cEBDtZLBsgEuXd::MQgYXguD(double siZXVkrQkxcc, double oLNoOhUdPWPgkgt, int QCtEk, bool cJatgmHLUy)
{
    bool BzyBvfeHPcz = false;
    string qvSHhho = string("lnYKnYwNfHvpDRsIgiayZgugIQcgHSkDHfArrsoCZTsJRrFZmVhrkUHVfgfDuygVIhfRcYUuLXGVqksoImeMKhcBMaPX");

    if (siZXVkrQkxcc < 756329.6545454295) {
        for (int HUethYThmNUKf = 1413472617; HUethYThmNUKf > 0; HUethYThmNUKf--) {
            siZXVkrQkxcc /= oLNoOhUdPWPgkgt;
            oLNoOhUdPWPgkgt *= oLNoOhUdPWPgkgt;
            BzyBvfeHPcz = BzyBvfeHPcz;
        }
    }

    for (int WtTakpFxUZ = 2027089337; WtTakpFxUZ > 0; WtTakpFxUZ--) {
        BzyBvfeHPcz = ! cJatgmHLUy;
    }

    if (siZXVkrQkxcc >= -936053.986922428) {
        for (int lRLzrUQAt = 1226320562; lRLzrUQAt > 0; lRLzrUQAt--) {
            qvSHhho = qvSHhho;
            cJatgmHLUy = ! cJatgmHLUy;
        }
    }

    for (int tbpNkMyTYtJhL = 1578615933; tbpNkMyTYtJhL > 0; tbpNkMyTYtJhL--) {
        QCtEk += QCtEk;
        BzyBvfeHPcz = BzyBvfeHPcz;
    }

    for (int ifmesgim = 1124424426; ifmesgim > 0; ifmesgim--) {
        continue;
    }

    for (int oktZBk = 137178901; oktZBk > 0; oktZBk--) {
        BzyBvfeHPcz = ! BzyBvfeHPcz;
    }

    return qvSHhho;
}

int cEBDtZLBsgEuXd::NKpjWxiarbaqNhz(double uUrvXEpqCOfup)
{
    double WBNvVW = 785930.0118635085;
    bool lvdVgsOj = true;
    double QmVPoWtYWEQ = -518120.4022313486;
    string LmRcJdOIZ = string("zolUrdjpEEgdHsTucQUDkcSKLuLulGxILxYDsbYKPaJVwXPSsiPRZVEdoadoXcfnbuIXKoQEAGqSXSKctsombicloPtnggjMaqIqRmRCMCFOulfzdmcjwyGzdTKUVAFgjoyHEUqvSnmlMImk");

    if (WBNvVW != -925463.1266174876) {
        for (int HYwLzNPzuKorIna = 1070344569; HYwLzNPzuKorIna > 0; HYwLzNPzuKorIna--) {
            QmVPoWtYWEQ /= uUrvXEpqCOfup;
            uUrvXEpqCOfup -= uUrvXEpqCOfup;
        }
    }

    if (QmVPoWtYWEQ == -925463.1266174876) {
        for (int FrENnbCtclCwOgu = 907878832; FrENnbCtclCwOgu > 0; FrENnbCtclCwOgu--) {
            QmVPoWtYWEQ += WBNvVW;
        }
    }

    for (int PgrpiHYRTUntE = 1619126406; PgrpiHYRTUntE > 0; PgrpiHYRTUntE--) {
        uUrvXEpqCOfup *= WBNvVW;
    }

    for (int KAvTbokEjPbwOfJE = 996549294; KAvTbokEjPbwOfJE > 0; KAvTbokEjPbwOfJE--) {
        WBNvVW -= uUrvXEpqCOfup;
        uUrvXEpqCOfup *= WBNvVW;
        WBNvVW *= WBNvVW;
    }

    return -38026911;
}

int cEBDtZLBsgEuXd::yqEyEmXwYZgFGgT(double hMjuYiKnRf, string dtLEfTbiQXZ, string BQqhjaHqemhzyTs, string WKeIDJoUWdaD)
{
    double TlBcuZYDl = 995848.782296245;
    double JyohreLBKeelzvj = 1022363.482411471;
    int YLVSqQZacvkN = -910182876;
    int sgbuwNigtIxi = -532243252;
    double orMKYlOpdp = -956971.8308013695;
    string aPXtcftDdIsp = string("XFzFHQUkmOginqFLmHYHeltLGoFVhTGXUAYMjKtttrmWBkmlNyBKLUUjmLaMLHUdnXtHBORHoXviFqbAhxYlzVtdfGSLOeEFWaNIkUzlQbiVvYUbUqBNAtvzWbuUZmxjbxkpQmjOYllCVDTUiEVFzxDdNLiVZWyOlMgbepaeGxaSJLDGzyavUxNBBDfrWcl");
    int AglesXUgv = 231040624;
    double FgYPGYEhgSdGc = -208538.95499545333;
    int vOxFqpDpEcYjQCJH = -1482142532;
    double abUNSib = -783198.272414572;

    if (dtLEfTbiQXZ < string("XFzFHQUkmOginqFLmHYHeltLGoFVhTGXUAYMjKtttrmWBkmlNyBKLUUjmLaMLHUdnXtHBORHoXviFqbAhxYlzVtdfGSLOeEFWaNIkUzlQbiVvYUbUqBNAtvzWbuUZmxjbxkpQmjOYllCVDTUiEVFzxDdNLiVZWyOlMgbepaeGxaSJLDGzyavUxNBBDfrWcl")) {
        for (int rxvtJChitsGmO = 926959088; rxvtJChitsGmO > 0; rxvtJChitsGmO--) {
            continue;
        }
    }

    for (int rEvTLT = 1505548637; rEvTLT > 0; rEvTLT--) {
        WKeIDJoUWdaD += WKeIDJoUWdaD;
        hMjuYiKnRf /= JyohreLBKeelzvj;
    }

    for (int ybqYejY = 1081262192; ybqYejY > 0; ybqYejY--) {
        orMKYlOpdp /= orMKYlOpdp;
    }

    return vOxFqpDpEcYjQCJH;
}

void cEBDtZLBsgEuXd::UhtFjbncVs(string QrnKuqNySEF, string RyvvvYAvCcc, string ysUhQFhaONLBd, double tDQPlHbgEKTHI, int stvWsL)
{
    bool YxqBbhbcElQELsYa = false;

    if (QrnKuqNySEF != string("BjrByinUTSjsXCjNHLaAdrAGPlTUTrCIaQdvRBirSoDWQprOGgtdpWoKCfrvSDIefueqKYeymOkIPuSATlGaJciAyXXUfwrLGQUeohiDsYXssjbSjBGxiAbFfSfhqjpGAMcZoFfyHDiepzqBlkqKPjegnSuhBjJNUWiGPIBHAzOUmgexebYFghehFafZCncuylJOkCthmVHaAJuNoHpNj")) {
        for (int uSpuBqmnW = 1651032861; uSpuBqmnW > 0; uSpuBqmnW--) {
            RyvvvYAvCcc = RyvvvYAvCcc;
            RyvvvYAvCcc += QrnKuqNySEF;
            RyvvvYAvCcc += ysUhQFhaONLBd;
        }
    }

    for (int zaLqnZNJCLXm = 520684285; zaLqnZNJCLXm > 0; zaLqnZNJCLXm--) {
        QrnKuqNySEF = RyvvvYAvCcc;
        ysUhQFhaONLBd = RyvvvYAvCcc;
        QrnKuqNySEF += QrnKuqNySEF;
    }

    if (YxqBbhbcElQELsYa != false) {
        for (int ktpZBmxENRFQ = 47128152; ktpZBmxENRFQ > 0; ktpZBmxENRFQ--) {
            tDQPlHbgEKTHI = tDQPlHbgEKTHI;
            stvWsL = stvWsL;
            QrnKuqNySEF += ysUhQFhaONLBd;
        }
    }

    for (int iojyijEaTuxZ = 953260181; iojyijEaTuxZ > 0; iojyijEaTuxZ--) {
        ysUhQFhaONLBd = QrnKuqNySEF;
        tDQPlHbgEKTHI = tDQPlHbgEKTHI;
    }

    for (int UwGVWIsfPHThHSpD = 1785307370; UwGVWIsfPHThHSpD > 0; UwGVWIsfPHThHSpD--) {
        QrnKuqNySEF = ysUhQFhaONLBd;
    }

    if (YxqBbhbcElQELsYa == false) {
        for (int YvQXwA = 1790991499; YvQXwA > 0; YvQXwA--) {
            continue;
        }
    }

    for (int TXsluegJ = 1984256883; TXsluegJ > 0; TXsluegJ--) {
        continue;
    }

    if (stvWsL < -1445781865) {
        for (int dJFpHwHpFcwlvx = 1852751595; dJFpHwHpFcwlvx > 0; dJFpHwHpFcwlvx--) {
            YxqBbhbcElQELsYa = ! YxqBbhbcElQELsYa;
        }
    }

    if (QrnKuqNySEF > string("nQJFmWZYnQAJDkNzHhOJIqctogqlgDTXsLcssfeuzGasWnUEkSvHtCFhUrWwjGCpCUlPPvKgjpvolHkUjFsAdGoFFPGJMfeAbHgsVFnMJKNxBZDvjugfGQiYxOkZsHHBBLtUxJpdrEcicGWOhRLPIKjaUXCMpxUwbtYQSHsigDTehVphgAMLyDXDUrHvasGwOcDFejNxldGMJzSaJRBWadUWKQAakeFWlAfbICMatvdppUK")) {
        for (int PXCZxZWXSfjILVd = 1695691479; PXCZxZWXSfjILVd > 0; PXCZxZWXSfjILVd--) {
            tDQPlHbgEKTHI /= tDQPlHbgEKTHI;
            tDQPlHbgEKTHI += tDQPlHbgEKTHI;
        }
    }
}

double cEBDtZLBsgEuXd::MHfMwZNP(int HYhvfiuDCksdjCQr, bool eyjyuyViMOg, string VfopjODaDAXLU)
{
    double jhLphjtxtHPyZ = 744445.4275144719;
    string TVjdbebwW = string("AdVLJPBFfVxjuoTBXeXhhkkMcPWEDCyfwtpbEWhbPCCwfmmzzUIcXwVJYmCinPHHHIifQiluHAuMNPFVPEJCDCPHDISlVxhJLapGLHWnoeUVZcOfNMVlGZoFujaByTjpdrGCuYXNZcDDmdIHtFwBbtYIstMaW");
    string eaLdZHKztPvN = string("xYzkJOZdxXUkgiEjsAfwAJLGhwFxaThGfdElQpWSUxWgDabYxhHpaomkzkefqRjFGavXtLBIVyKXPdFbzEigfChneoQlvctStauYMurfdIlIQFgzhcTeORLOsYGceLLrKrmbdgJGTWXfeSthO");
    bool jrwZed = false;
    int tsvVJSDDo = -1398223530;
    double jzBlBizXKNIf = 80611.42320711991;

    for (int XtFYM = 105032122; XtFYM > 0; XtFYM--) {
        continue;
    }

    if (VfopjODaDAXLU == string("PlUuyLPWHSQnfBQgXdIZy")) {
        for (int bMrPHjzVMJtMibI = 2089884269; bMrPHjzVMJtMibI > 0; bMrPHjzVMJtMibI--) {
            jhLphjtxtHPyZ = jzBlBizXKNIf;
        }
    }

    if (eyjyuyViMOg != false) {
        for (int PoHWOhKMRHnD = 1011142866; PoHWOhKMRHnD > 0; PoHWOhKMRHnD--) {
            jhLphjtxtHPyZ /= jzBlBizXKNIf;
        }
    }

    for (int CbevxcCSymTJdFtF = 68771143; CbevxcCSymTJdFtF > 0; CbevxcCSymTJdFtF--) {
        eaLdZHKztPvN += TVjdbebwW;
        eaLdZHKztPvN = TVjdbebwW;
    }

    return jzBlBizXKNIf;
}

string cEBDtZLBsgEuXd::FnYkPFvNcFHQPKo(int GuGkazRbbWNSY, bool TkPgAlPQyuXhEy)
{
    double yjrumHs = 698677.8030529547;
    double NNGdEuh = 81024.8058251743;
    bool pfDyPHGyPpT = true;
    int ATurhPoLFGqwYz = -1400750184;
    int qWoEFhjVBly = 1944936332;
    double CqGMhcYTM = 1016548.0816188047;
    int PAGvFktZE = 1930710862;
    bool XwZmr = true;
    int xUZvjJLCdxTMPqLp = -123010428;
    string CIkQipY = string("aBxRGCvZmUVhpfaJBXPZosNdDAbABweNJCOAuglKmUbGzUTbcuzgzDweaTvbxpDNGhsgUNtmutWOaLmlvvGFsRXgCMwQacVbfzJiVOjHGRVQHJFPQkxZKxhVUtXkgZvKDJsBhAppiUzxTkBwMQyQTSLqAZUFOZoqCrqyPiSJMWTH");

    for (int PhoXkvNKzGr = 1373019890; PhoXkvNKzGr > 0; PhoXkvNKzGr--) {
        yjrumHs += CqGMhcYTM;
        PAGvFktZE = qWoEFhjVBly;
    }

    for (int aKTedoBoXxKby = 335163575; aKTedoBoXxKby > 0; aKTedoBoXxKby--) {
        CqGMhcYTM *= yjrumHs;
        XwZmr = TkPgAlPQyuXhEy;
        GuGkazRbbWNSY -= PAGvFktZE;
        qWoEFhjVBly += GuGkazRbbWNSY;
        PAGvFktZE = xUZvjJLCdxTMPqLp;
    }

    for (int gbsCBdI = 291375492; gbsCBdI > 0; gbsCBdI--) {
        ATurhPoLFGqwYz = qWoEFhjVBly;
        yjrumHs = NNGdEuh;
        yjrumHs = NNGdEuh;
    }

    for (int PoQoZaqCJiA = 1265293780; PoQoZaqCJiA > 0; PoQoZaqCJiA--) {
        continue;
    }

    for (int KPPJkIxWqvHT = 1559325471; KPPJkIxWqvHT > 0; KPPJkIxWqvHT--) {
        ATurhPoLFGqwYz /= xUZvjJLCdxTMPqLp;
        yjrumHs /= CqGMhcYTM;
    }

    return CIkQipY;
}

int cEBDtZLBsgEuXd::qYYSNbKEGZBWC(double pVWejYvRMJh, int ytutiWHaFKnWql, double DOpCwEFnxhiEPL)
{
    bool urTzOrpVOR = false;
    int gwrqBXZc = -168090112;
    double Zytxijcke = -351239.70086360525;
    int RLJAs = 1352477103;
    bool OjYusVlHYgclZWXq = true;
    bool rvXgYqHIYiMNwV = false;
    double pRoAxbqLLXSvS = 865266.6319205759;
    double iiWRPfdCeusDEx = -796264.8979553868;
    double lwlkBBetGSy = -481371.79744753387;

    for (int YZExcqXjp = 926613550; YZExcqXjp > 0; YZExcqXjp--) {
        Zytxijcke += DOpCwEFnxhiEPL;
        gwrqBXZc = gwrqBXZc;
    }

    if (DOpCwEFnxhiEPL >= -796264.8979553868) {
        for (int IoucpgDRCtEhmu = 1744479729; IoucpgDRCtEhmu > 0; IoucpgDRCtEhmu--) {
            iiWRPfdCeusDEx = DOpCwEFnxhiEPL;
            DOpCwEFnxhiEPL = DOpCwEFnxhiEPL;
            RLJAs += ytutiWHaFKnWql;
        }
    }

    if (gwrqBXZc < -168090112) {
        for (int hJiwF = 54795688; hJiwF > 0; hJiwF--) {
            pVWejYvRMJh -= DOpCwEFnxhiEPL;
            pRoAxbqLLXSvS /= pRoAxbqLLXSvS;
            urTzOrpVOR = urTzOrpVOR;
        }
    }

    if (lwlkBBetGSy <= 688927.1586256527) {
        for (int zoZhTjiLR = 1663988525; zoZhTjiLR > 0; zoZhTjiLR--) {
            Zytxijcke += iiWRPfdCeusDEx;
        }
    }

    return RLJAs;
}

int cEBDtZLBsgEuXd::DVQGtsFj()
{
    string MRyyVzVh = string("SqUBMNSyriQWnLaLcHBPuOnJyKRFSiwwPDGroSvZdvysKNt");
    double oneYNF = -249619.97288354166;
    int KWaRpiVmPCRRc = 804859908;
    int HfyoEDdoCXbRtrTn = 1607522024;
    int JjlQVjQHd = -1302395755;
    double oizvCTxdIxSwBn = 259022.22654398158;
    int DHaxIfOQvfLIWWxN = -1990816806;
    double QYeKNiArJ = -118587.5941942972;
    double yTrIUpqHeoaE = -930453.7701545227;
    double rtzdeXib = 23789.351398061586;

    for (int EKzpNluatL = 1254848322; EKzpNluatL > 0; EKzpNluatL--) {
        QYeKNiArJ /= QYeKNiArJ;
    }

    for (int XuGjOJQomdD = 1952993135; XuGjOJQomdD > 0; XuGjOJQomdD--) {
        oneYNF -= oneYNF;
        QYeKNiArJ /= QYeKNiArJ;
        HfyoEDdoCXbRtrTn -= JjlQVjQHd;
        DHaxIfOQvfLIWWxN += JjlQVjQHd;
    }

    for (int HAufuEoXQ = 879000591; HAufuEoXQ > 0; HAufuEoXQ--) {
        JjlQVjQHd -= HfyoEDdoCXbRtrTn;
        oneYNF *= oizvCTxdIxSwBn;
    }

    for (int UxubV = 611381686; UxubV > 0; UxubV--) {
        DHaxIfOQvfLIWWxN /= KWaRpiVmPCRRc;
        oizvCTxdIxSwBn /= yTrIUpqHeoaE;
        rtzdeXib *= rtzdeXib;
        JjlQVjQHd /= KWaRpiVmPCRRc;
        QYeKNiArJ += oizvCTxdIxSwBn;
        rtzdeXib += oizvCTxdIxSwBn;
    }

    return DHaxIfOQvfLIWWxN;
}

string cEBDtZLBsgEuXd::VejhlJcfVTw()
{
    string shOZtllnzg = string("CXjKKQyojGfdocFlVfmSbNFLJzzgZaeIRccdEfRtJGWUyNmPGRaoWdMECMOurHUSzNwtgRDseyKJFOJiQEnXTYuAOohBdiakVZyhHNGpbqnNFwwEQrvCSXTswvXUSlwAEFhwAYJPhKfOPrjoaXFV");
    int aOjMKdbIseikt = -1932226359;
    double XvvvIfwROUzGea = 576607.6809624501;

    for (int ArTtvEOplHibKLz = 1930082333; ArTtvEOplHibKLz > 0; ArTtvEOplHibKLz--) {
        shOZtllnzg = shOZtllnzg;
        XvvvIfwROUzGea *= XvvvIfwROUzGea;
    }

    return shOZtllnzg;
}

void cEBDtZLBsgEuXd::aPjaP(bool AKnTzuoO)
{
    bool RDlGJkQFMQqFh = false;
    double pNHctSisEYYBxOV = -977372.3956405376;
    string ZKgcNIgc = string("rtLIxSmfVeQOJJxEsvbMSnJTnOakcxLziJdOEUwBBpGFJnagjnZIJqpDLVqbLCpjspeZkN");

    for (int gJveMj = 910562037; gJveMj > 0; gJveMj--) {
        AKnTzuoO = ! AKnTzuoO;
    }

    if (AKnTzuoO != true) {
        for (int MbrCvzvFuuyeOv = 1066473479; MbrCvzvFuuyeOv > 0; MbrCvzvFuuyeOv--) {
            pNHctSisEYYBxOV = pNHctSisEYYBxOV;
            pNHctSisEYYBxOV *= pNHctSisEYYBxOV;
        }
    }
}

void cEBDtZLBsgEuXd::ISMiSazQvhE(string GQLQMCzL)
{
    double qwgKJwoIVhMdrEDJ = -602903.503119903;

    if (qwgKJwoIVhMdrEDJ <= -602903.503119903) {
        for (int rcJfPZQkRcZaoX = 408455777; rcJfPZQkRcZaoX > 0; rcJfPZQkRcZaoX--) {
            GQLQMCzL = GQLQMCzL;
        }
    }
}

bool cEBDtZLBsgEuXd::fPEjdAkgLm(string UZfERpmQANGw, double JDHpueAjSPClpqRJ)
{
    bool IaBEUteZwcFbzF = true;
    double evaMk = -374067.2731833388;
    int aQXnfNxZHUr = -1385178343;
    string cvSWKnTPxFKbsmWf = string("MkpbyNGTnAWSCDtPPImTWzCUDrOyWajx");
    double rZrXbYSYhlh = 1005012.6532713479;
    string VYVmqpJeAy = string("hHYEqHFZCJSeBRQzUkUSpihhOgqIRDHmQUxgblRJxSLapbuyikjrsibilyruTmPZqslhCfZuWAHVaLQecLCFsoitdPFtTdDUtZPQawLxbUYOXzdIKBnGLgJmVUPMPtEcXBtXIxahBbBouUCQZruobR");

    for (int XRaDEcU = 839681636; XRaDEcU > 0; XRaDEcU--) {
        UZfERpmQANGw += VYVmqpJeAy;
        VYVmqpJeAy = UZfERpmQANGw;
    }

    if (JDHpueAjSPClpqRJ <= 1005012.6532713479) {
        for (int wvPMXQA = 1300279298; wvPMXQA > 0; wvPMXQA--) {
            JDHpueAjSPClpqRJ = evaMk;
        }
    }

    for (int UYumkcLaxz = 1489064875; UYumkcLaxz > 0; UYumkcLaxz--) {
        continue;
    }

    if (aQXnfNxZHUr > -1385178343) {
        for (int OQQXhWwCaRoCqQ = 367268456; OQQXhWwCaRoCqQ > 0; OQQXhWwCaRoCqQ--) {
            aQXnfNxZHUr /= aQXnfNxZHUr;
            rZrXbYSYhlh -= JDHpueAjSPClpqRJ;
            rZrXbYSYhlh += evaMk;
            JDHpueAjSPClpqRJ = JDHpueAjSPClpqRJ;
            cvSWKnTPxFKbsmWf = VYVmqpJeAy;
            UZfERpmQANGw = VYVmqpJeAy;
        }
    }

    if (JDHpueAjSPClpqRJ == 1022676.9765001481) {
        for (int xKKODe = 297858304; xKKODe > 0; xKKODe--) {
            continue;
        }
    }

    if (IaBEUteZwcFbzF == true) {
        for (int utggIwZA = 1070440915; utggIwZA > 0; utggIwZA--) {
            cvSWKnTPxFKbsmWf = cvSWKnTPxFKbsmWf;
        }
    }

    return IaBEUteZwcFbzF;
}

cEBDtZLBsgEuXd::cEBDtZLBsgEuXd()
{
    this->qXZtbrNRsPOqWie(698958.4608269538, true, -340564.59079730354, string("YaglEsqHlPEUQShJdJKvKpalBMzITojhabrKCZXCycTsJcOUEjgUbTIzdquiHkOlFxQXLOvjLJCWgcZVHhoyxaCFJSWgOdgkiXJOfPupcxyvghXfzsbqMHJalCdCMME"), -563184.0836424138);
    this->TabjbH(string("QBTmrvJrnSQGtMATEXwzurmLrrGBKUtIYtmzXyAIwWEjPaGxyLCNHaTNUGrgSCaqBoJwOrSqLEmQWiYauWhiBfeRZWoXtmzUxcijhdaPZbHuaeZYZljsedmbvdrFpqxjjCBVuBtuDlYprrHUOXUPsmFgzIYfimfjPcCpEGSYJmPFjmnKbrfjwKSKBZrNVzIHKNvqdnAVsvwLxQVipCXWfFDFMTzusAuUZdHlnyUxtzHyFK"), 702145499, string("oeusYBivFEedNmVuDagKEJllyuMdkAfEIJLBgFqJlEqzOVEZ"), -1357794677, 14123629);
    this->obojUSR(string("xrmfFIcjwxOOaVwfqOjNauDrbgaBFpmJQzukGKHReclFPWPpY"), string("VaLvJPhfftvpNNPijfKWRdLEUnmGXSKSZcBgRRMGpBrESXatMtoXnlelUigYrnwLlekbkTXOrFCTBUGampOKTRRjKezaqYJxshSZlWyaYwzfeNlAXkganAyWwThlZrHMUHeXHoUwbwCVqsVprFAfzgZwulGyYNqQuumifuQccoTmsjdvwDyVAuNGWLOLcLSnbfVVczmuQqwqqzg"), string("QnOssDJEAcasYBkvOGPnMDplGahUmhpSZlfiYSMaehRbWNnXWmyOoJpGMmcWnFvHWcajNmDDMxotDKiVsgtFiIMKuqrcrEawEKzCRefIfxqrLSaLAsjzPbmgEcNxAvpLJXchGMKblDoRoEoIQTQYFAusfCjrovdxDsFboLPiarQNkHOfHQbuDwDCjSIPItwuUoGgyCCvS"));
    this->MQgYXguD(-936053.986922428, 756329.6545454295, -1257428479, true);
    this->NKpjWxiarbaqNhz(-925463.1266174876);
    this->yqEyEmXwYZgFGgT(-376843.71240630466, string("MzwvMfAsyepPHEjNqxdWOxmAWTnbrJOfdlgpvQLER"), string("XtmavUFNYHgByzaDpvUAhFxzwpyHyrysYPJvXxzRkqZrkaIgrBqxoErKeOhKJrWDTVFMUXrAwOQTvBEdpxXcQCIdxH"), string("RxgxghbzivrHOHFIZrgRcoFYtfTHAgCpuqgbdxwLHUirafqeyMgdiWVAmNwDoRTmjKZrIsFdnkVuWOZChxhowhRDTHXxQUlETqGFNMKUqXAUZNaXWBMeJOcKgFuUkWEJwVAhMiDLhnmuhONFzeRImFtkWKTbClczCyGoYjqVWSZwmunvLHhHGmvyTnLqUvVKVnXuQBXQNZYmPgXLWJxKPRLREJqXAYleBqDWpzVnUwaaKu"));
    this->UhtFjbncVs(string("BjrByinUTSjsXCjNHLaAdrAGPlTUTrCIaQdvRBirSoDWQprOGgtdpWoKCfrvSDIefueqKYeymOkIPuSATlGaJciAyXXUfwrLGQUeohiDsYXssjbSjBGxiAbFfSfhqjpGAMcZoFfyHDiepzqBlkqKPjegnSuhBjJNUWiGPIBHAzOUmgexebYFghehFafZCncuylJOkCthmVHaAJuNoHpNj"), string("nQJFmWZYnQAJDkNzHhOJIqctogqlgDTXsLcssfeuzGasWnUEkSvHtCFhUrWwjGCpCUlPPvKgjpvolHkUjFsAdGoFFPGJMfeAbHgsVFnMJKNxBZDvjugfGQiYxOkZsHHBBLtUxJpdrEcicGWOhRLPIKjaUXCMpxUwbtYQSHsigDTehVphgAMLyDXDUrHvasGwOcDFejNxldGMJzSaJRBWadUWKQAakeFWlAfbICMatvdppUK"), string("bJOmdbvZDRTmEZGteoWGERpyTjDoMClQacmGJDVGqAncRwOaWoZxpQcypOqEwPIWsuSXtIcPPZctaCRTDTyigETiflpjFbyCipcvqluVPWjOygIGJAGRymlZsKoscQYJqUVmZabuyXvMtsUppWkLATijapNAoI"), -181390.49309697116, -1445781865);
    this->MHfMwZNP(987199435, true, string("PlUuyLPWHSQnfBQgXdIZy"));
    this->FnYkPFvNcFHQPKo(98787335, false);
    this->qYYSNbKEGZBWC(-357989.59286181343, -182765478, 688927.1586256527);
    this->DVQGtsFj();
    this->VejhlJcfVTw();
    this->aPjaP(true);
    this->ISMiSazQvhE(string("KZN"));
    this->fPEjdAkgLm(string("IhoyBqLEnzBrydZetIcFFhZCNeICiuT"), 1022676.9765001481);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IfBhaNzDCxhv
{
public:
    bool prDDDkdNLtIbJEm;
    int qIfjQO;
    string HaINv;
    int dnEoVwKpmTKPSwE;

    IfBhaNzDCxhv();
    double KGRJqKuGWMUXHVj(bool walLsXoCmwBRGoJI, double pphKRSbk, bool gsxRIQ, string sTsml);
    void LmPUrRtVZuWh(bool kkMWd, double dQGfcNCHCUM, double lVAGHJRilbVvPs, double YTpWRlcMpXuqflrR);
    string doObydoPq(string BFkFZPlhDlDyh, bool pfxBcWESNF, int GARDXCBPAUrtPES, int uPEFryunNiSP, double HhPTpMrt);
    double WkPQx(bool GAhkNYNNbQ, string lfsedVvvxH, bool rzuBOR, double VPhxqQU, double xwEmElYDWVHuuHfA);
    int KLwruCWBloZrr(int HqMYpQJyH, bool VtEKjkzDTR);
    int igQQQfgC(string ItSmxIV, double GRkvludiYkE, string qUCsVHaWIX, string pkwNOOmlx);
    int wpVwLbYlbZn(bool VprmnZdEGk, bool HfYauQ);
    string bTyaULOaKeqf();
protected:
    int YLsritaYC;
    bool dnRALDfRKru;
    string UfpjilaUQBAXl;

    void UMcQGAcs(string VMAGVtF, bool vPXRM, string nhroRGPsbRESeka);
    double GIIFRQRx(int fLVnEEmzHtUoKt, bool FYWJZhprwHCY);
    double pqwqdv(double uXMwsyIkkTjR, double LUSHQjLIbtEMs, int WLHPmj);
    double qsalFmpKhFwcP();
private:
    double IZbtzFklOr;
    bool eZIiKhVqwOQg;

    double tpbEFMrQiRL(double OQEeLUYNlBSoX);
    double KKNQLoGKktaMiz(string emJoxAZqHaPIQd, bool JaPwVjMPYQmlJpT, string DKOWppCPC);
    void NobrzfAypGEnHC(string YXSuOOAD, double WEbPuYzFF, bool hUuQdzjhWctO, string PFsfqlfWukYAI);
    double ljEAlAeGgiqvRkJ(string PTjrHwa, double izmIMGBkEUyaleOI, string sWjSvsGsIUpMpi, bool IIjmzYQRWHBW);
    void LLnuFIakfAYV(string VPSpuxMCETSCPW, bool FzxozYJV, bool dwwkFkJBBIBOSvLd);
};

double IfBhaNzDCxhv::KGRJqKuGWMUXHVj(bool walLsXoCmwBRGoJI, double pphKRSbk, bool gsxRIQ, string sTsml)
{
    string ENfznzXzWTz = string("xNYgDZggWiaSBjePhRnHxyjwxAimINPXTmVQhLCnY");
    string qcOyDqZNfGL = string("MOUkjflTmBvfGLFUocjVXhUWHUfIeJwDKXkFAOdPsByVfvUGwQZqDEbMEljWublEpZGHINkrbMSxxSOTctllSJXFnhsEhBBDezPjDLpBJGNOrfGJbFurvSKSJZZPrpnkizDWERHGBAgCmtDhOqfUsHjNCKTXReQPXECRXiZEFMWIQlhUXUdJzDrzpwYntIbrWkgaEGWigyoFGs");

    if (qcOyDqZNfGL != string("bekmGFh")) {
        for (int RKitTEPmmuZhdbpG = 334046773; RKitTEPmmuZhdbpG > 0; RKitTEPmmuZhdbpG--) {
            ENfznzXzWTz = qcOyDqZNfGL;
            sTsml += qcOyDqZNfGL;
            pphKRSbk = pphKRSbk;
            ENfznzXzWTz += ENfznzXzWTz;
        }
    }

    for (int TBbLrczeAWQVcWvv = 1046072175; TBbLrczeAWQVcWvv > 0; TBbLrczeAWQVcWvv--) {
        ENfznzXzWTz += qcOyDqZNfGL;
        gsxRIQ = gsxRIQ;
    }

    return pphKRSbk;
}

void IfBhaNzDCxhv::LmPUrRtVZuWh(bool kkMWd, double dQGfcNCHCUM, double lVAGHJRilbVvPs, double YTpWRlcMpXuqflrR)
{
    bool nDzJMxHA = false;
    double oSNmfZUINwLd = -510627.1159294588;
    bool BsughSTWXcUEq = false;
    string GoHagmkTMbGIc = string("NMkYyLsQrTxYXTYNAjUYaHXMSbGQnFyVdXFgLfGsylOyDKlZLRfsvIsbkebbONdjSxTRwNadICfibcfcwhZSowkzTfmeMZMZOSlvnOGkxExTiIImUvzJdTnqZuksFuOzAoOIhXuhrmrpdZiENjTxdDqwlaURTWwtDyAMzFFMgnWJKzvhixRySKYDbfhUN");
    double qGbqcmd = 311221.6863136927;
    int oJTtK = 1337531889;
    bool LSpIiacQCkoFew = true;
    double lmXBwCFyhxO = 178598.39177741078;
    double LLXZyIO = 793534.5350950012;

    for (int AvgyiTkd = 570160359; AvgyiTkd > 0; AvgyiTkd--) {
        continue;
    }

    for (int heuXWStjSK = 1312259642; heuXWStjSK > 0; heuXWStjSK--) {
        continue;
    }

    if (lmXBwCFyhxO >= -75122.07263922128) {
        for (int ERFroDAunNH = 1825302386; ERFroDAunNH > 0; ERFroDAunNH--) {
            dQGfcNCHCUM *= LLXZyIO;
        }
    }

    for (int QHAFD = 1128714393; QHAFD > 0; QHAFD--) {
        YTpWRlcMpXuqflrR -= YTpWRlcMpXuqflrR;
        oSNmfZUINwLd *= YTpWRlcMpXuqflrR;
    }

    for (int AzYHqMJgoDzv = 1643598435; AzYHqMJgoDzv > 0; AzYHqMJgoDzv--) {
        continue;
    }
}

string IfBhaNzDCxhv::doObydoPq(string BFkFZPlhDlDyh, bool pfxBcWESNF, int GARDXCBPAUrtPES, int uPEFryunNiSP, double HhPTpMrt)
{
    int hTIdWFlySuBuCfZv = 297971488;
    int rSBsGUlVDCyNnQ = 763490582;
    double lRmYAaXmTQY = -327316.6718230248;
    bool MTZCOCAX = false;
    double ngWxlmfxLUq = -39686.68552605474;
    bool tINVnS = false;
    bool AjhrtCaeFRSEwh = false;
    bool xFCvWjdXN = true;

    if (rSBsGUlVDCyNnQ >= 763490582) {
        for (int NXSJcCtnz = 765396609; NXSJcCtnz > 0; NXSJcCtnz--) {
            uPEFryunNiSP *= GARDXCBPAUrtPES;
            pfxBcWESNF = ! AjhrtCaeFRSEwh;
            pfxBcWESNF = ! xFCvWjdXN;
        }
    }

    return BFkFZPlhDlDyh;
}

double IfBhaNzDCxhv::WkPQx(bool GAhkNYNNbQ, string lfsedVvvxH, bool rzuBOR, double VPhxqQU, double xwEmElYDWVHuuHfA)
{
    double ihyVoIuIqNPTe = 19705.816941631674;
    double WkCZkFAOcZX = 167766.28189768427;
    string VcEJEgkbVDXQ = string("vRqFKFFmDDQcaDVnYrKcUnTHFmNWUMKrBMMppXEYOZEMLPhRJXsumxGJfVZPYUjjIQitonbWbfRbqIjmUXSwjbEyiIkhyssadeICIYahqRVPqUSKqpSOVRcgmQOBCWWNTkTCnIheeyVLtlfrFwbcHHZEdtQEiaGAjwNjCxVUqvKLwrdeXFZStVFiNzcKNaEYsgbNMWrojnMzdvQAqFSmnnIuITMPfNerbVNj");
    double NwfvFIHhuL = -870049.6194211124;
    bool XOfuDKVvTwvsvG = false;
    bool nKQcZNoBhWxvAR = false;
    bool lpQIRK = true;

    for (int haoLu = 1062375641; haoLu > 0; haoLu--) {
        lpQIRK = ! XOfuDKVvTwvsvG;
        WkCZkFAOcZX -= xwEmElYDWVHuuHfA;
        xwEmElYDWVHuuHfA = ihyVoIuIqNPTe;
        nKQcZNoBhWxvAR = nKQcZNoBhWxvAR;
        XOfuDKVvTwvsvG = ! XOfuDKVvTwvsvG;
    }

    for (int DqgvsqVIxOWP = 1754837416; DqgvsqVIxOWP > 0; DqgvsqVIxOWP--) {
        lpQIRK = ! nKQcZNoBhWxvAR;
        xwEmElYDWVHuuHfA -= ihyVoIuIqNPTe;
    }

    return NwfvFIHhuL;
}

int IfBhaNzDCxhv::KLwruCWBloZrr(int HqMYpQJyH, bool VtEKjkzDTR)
{
    int yfVgKsMONiBm = -1088181194;
    int PHSaZ = -2011946397;
    double PoEboWSTvRtBcuo = 411797.34770839004;
    int UDQDDiItY = 942742042;
    string ItIlDEKuuDLv = string("DUEPnKIbouVJOHdAsnYBzlPccRBhIArWghQXUpUREGhQxldUtwQuWlyeuEkIsopgrRjRUZXSZEk");
    string mhsTAA = string("n");
    bool WHcYimVKsZoICIn = false;

    if (PoEboWSTvRtBcuo != 411797.34770839004) {
        for (int igORtQsZQiSjjw = 1533797745; igORtQsZQiSjjw > 0; igORtQsZQiSjjw--) {
            ItIlDEKuuDLv += ItIlDEKuuDLv;
            UDQDDiItY += HqMYpQJyH;
        }
    }

    if (VtEKjkzDTR != true) {
        for (int wRrdCMVxSef = 1348816396; wRrdCMVxSef > 0; wRrdCMVxSef--) {
            PHSaZ *= UDQDDiItY;
            mhsTAA += ItIlDEKuuDLv;
            ItIlDEKuuDLv = mhsTAA;
        }
    }

    for (int GjdoSZR = 999886679; GjdoSZR > 0; GjdoSZR--) {
        continue;
    }

    if (yfVgKsMONiBm > 942742042) {
        for (int LUHDmwkDoqXd = 309186578; LUHDmwkDoqXd > 0; LUHDmwkDoqXd--) {
            continue;
        }
    }

    return UDQDDiItY;
}

int IfBhaNzDCxhv::igQQQfgC(string ItSmxIV, double GRkvludiYkE, string qUCsVHaWIX, string pkwNOOmlx)
{
    int SFoWLGGS = -1162693908;
    int GWzqPOMwg = -34499781;
    int GGhyltevnXXrA = -3620949;
    bool ZwYCUhdB = false;
    int blzlKhDlTUnXCs = 1346277203;
    int KTFaaVjbVvfq = 970640015;
    int GvLbJPAygrztCkfS = -508890188;
    double yNlQFsZwGVsR = -254229.41956081332;
    double dDARXRRvnDSMKrNs = 194278.22266247543;
    string HSjkyfFFgKirt = string("VrQIzApzmnLinLPsMstFdjaewONZLuxTSohvMfxylSgUJxNASnFJimYaZWCEuxfosiQJFkNqfWcBbagPdYchLuGkKgnRaRFwxZMoPKEozwrSOCsnwjGzFUfSOJqqdYlrLQRLfJAyQXgvURsyfmFQcCnUkEvJVidumQWaoZdELZUIZBDkxcABxVTHvGuQEjdxYfa");

    for (int NUVSUAjh = 1775896827; NUVSUAjh > 0; NUVSUAjh--) {
        GvLbJPAygrztCkfS /= GvLbJPAygrztCkfS;
        qUCsVHaWIX = qUCsVHaWIX;
        HSjkyfFFgKirt = qUCsVHaWIX;
        ZwYCUhdB = ZwYCUhdB;
    }

    if (ItSmxIV != string("rXYjvCpsilkUfMGjtUfSSRZSXlEyRsvbygJOznkZXIkKLhHGhxnuwidVINFKNWQrpIlMFPhsXhhIzpgjVfefTVotUXJjKFPYLiMqVBitogUlhgfk")) {
        for (int kQJGOXwRRknL = 856428854; kQJGOXwRRknL > 0; kQJGOXwRRknL--) {
            continue;
        }
    }

    return GvLbJPAygrztCkfS;
}

int IfBhaNzDCxhv::wpVwLbYlbZn(bool VprmnZdEGk, bool HfYauQ)
{
    double YsLiVeplIjKkpOyF = -216951.8834190155;
    string fJmCBqgC = string("kFgqWMCrpiHSqBlDvxGAKZCNwWthGeFeXOejBNoEqKianoHApqNIZURSbaaXjzhniMhaNfqGoLxZMwGHlhSHWAwUaCawiNtTjxwcYoSPxRwVEpCCUjjuhoqHkleJsQcWYqsbmMouktcqJM");
    int XGOdQkNY = -521395917;
    bool ndvmkGbdJNZDOVb = true;
    int FZeUXKn = 2114685177;
    int iEIOtOn = 253036632;
    string yZFHaLlyBxxYLS = string("nuyExKFsHslZNbiydKpRkxtDgCPKoERJhzMGyYNZJOcbqCAkAopVJMtngVHvmUazXkpmjnFJcKzHEZZsixoieJDyckcehWMOeGIghXxVHVCRyjVcdbxNjraywwpqtebyxIIcYtjjjU");
    string uBnqC = string("ZjWGPbKTaMeFquQAezYKBWRiaJkigDabpDYEYrjUylWnarquMOdZAQZIyTbfEuOSROZuvEdKHJRiPGURxjZIHWeIXiekgprxsWlXegYSnfzZCVJmAXJBWbOiUnWbWcwSiiXIfAFGeHdiYCEflFhvIPyaEWqVHnAMXaIpeBMtkgtfaEWvSkoeQYnBtHQOpuriVhrVrWcTyetKWBxuqZkMrPXcvkuMPLzPtfX");
    bool aGYQFkRgVr = true;
    string foXjvmgWuBDMhmRH = string("itCBiuqWEOTnbuyQwgRQVVllzpZylWOddmmyOzyXcWzZBpBGViBiZhQtkFElUkQBrsstnLFrwDwIEKgoQYLNWmfKEuDKbJOLiOOcQjISTcX");

    for (int vZzAp = 1254408066; vZzAp > 0; vZzAp--) {
        continue;
    }

    if (VprmnZdEGk == false) {
        for (int BGBbonXT = 2113717849; BGBbonXT > 0; BGBbonXT--) {
            iEIOtOn *= XGOdQkNY;
            fJmCBqgC += fJmCBqgC;
            foXjvmgWuBDMhmRH += fJmCBqgC;
            FZeUXKn /= iEIOtOn;
            VprmnZdEGk = aGYQFkRgVr;
        }
    }

    for (int YrubwxqlZfh = 1543277218; YrubwxqlZfh > 0; YrubwxqlZfh--) {
        aGYQFkRgVr = ! HfYauQ;
        fJmCBqgC = yZFHaLlyBxxYLS;
    }

    return iEIOtOn;
}

string IfBhaNzDCxhv::bTyaULOaKeqf()
{
    bool FSmCoeBZOLwmnb = false;
    string WoqLJCkyGn = string("ubHONYtIfKCWnZxnFmgeywpAmEgYivggWMqpGFOucDqoSgisyqllluRVJPZgrKAIlKXrQwZZ");

    if (FSmCoeBZOLwmnb != false) {
        for (int PNlvd = 360979527; PNlvd > 0; PNlvd--) {
            WoqLJCkyGn = WoqLJCkyGn;
            FSmCoeBZOLwmnb = FSmCoeBZOLwmnb;
        }
    }

    if (FSmCoeBZOLwmnb == false) {
        for (int PVprfrPJdxFFXK = 622842750; PVprfrPJdxFFXK > 0; PVprfrPJdxFFXK--) {
            WoqLJCkyGn += WoqLJCkyGn;
            WoqLJCkyGn = WoqLJCkyGn;
            WoqLJCkyGn = WoqLJCkyGn;
        }
    }

    for (int MPWLmpDLRnaitfR = 2078278726; MPWLmpDLRnaitfR > 0; MPWLmpDLRnaitfR--) {
        WoqLJCkyGn += WoqLJCkyGn;
        FSmCoeBZOLwmnb = FSmCoeBZOLwmnb;
        WoqLJCkyGn = WoqLJCkyGn;
        FSmCoeBZOLwmnb = FSmCoeBZOLwmnb;
    }

    return WoqLJCkyGn;
}

void IfBhaNzDCxhv::UMcQGAcs(string VMAGVtF, bool vPXRM, string nhroRGPsbRESeka)
{
    string fRroOK = string("iEqZGVIVnKCwuwoQuzICqmAsQyhnaLfqhqxEBbrRFjCsZNumAfnqnEeGHAuktYWxAdOBRBLuGEXvWxmwqMDifAAIYteNtmkkXTfYxBZuCOPHjuoEzRUbxMYZD");
    double ulOTdKLH = 745983.040821019;
    bool gRbLcTEBhOSCsLI = true;

    if (fRroOK > string("CAyFnVFXpDXANHiPufTGXffODoBYRUxVvGCfnoaGDFomDxNuxTYSZgfetfvgtoFZzNOXmsvgJnzilKrobRmovoUDUXEUDmflbbvVsGivTzyQizXZMMUXLYOmxXsgwAgZQbDiXvzOJTBUeBTDUDNlkVCeNPJQdIKDpXmsqFujRtVBpYRfTsWoImNR")) {
        for (int mMqgfbaYOKROBd = 1101229847; mMqgfbaYOKROBd > 0; mMqgfbaYOKROBd--) {
            vPXRM = gRbLcTEBhOSCsLI;
        }
    }

    for (int XlyXbas = 266536823; XlyXbas > 0; XlyXbas--) {
        nhroRGPsbRESeka += fRroOK;
        VMAGVtF = VMAGVtF;
        nhroRGPsbRESeka = fRroOK;
    }

    if (nhroRGPsbRESeka > string("CAyFnVFXpDXANHiPufTGXffODoBYRUxVvGCfnoaGDFomDxNuxTYSZgfetfvgtoFZzNOXmsvgJnzilKrobRmovoUDUXEUDmflbbvVsGivTzyQizXZMMUXLYOmxXsgwAgZQbDiXvzOJTBUeBTDUDNlkVCeNPJQdIKDpXmsqFujRtVBpYRfTsWoImNR")) {
        for (int JlzlJKskGU = 214213147; JlzlJKskGU > 0; JlzlJKskGU--) {
            nhroRGPsbRESeka += VMAGVtF;
            nhroRGPsbRESeka += fRroOK;
        }
    }

    for (int GvpYD = 274602986; GvpYD > 0; GvpYD--) {
        gRbLcTEBhOSCsLI = ! gRbLcTEBhOSCsLI;
    }
}

double IfBhaNzDCxhv::GIIFRQRx(int fLVnEEmzHtUoKt, bool FYWJZhprwHCY)
{
    int jqTdTJLdOXROn = -201502705;
    string QuTjfpxSxprQ = string("yTpKllEQhddvFdAgedBLDoAuLiNUtXOoKIvzEEorzalWdBcqsGamZSmyRAhkbFsaQQqGCsGcuCLQLtweGdDuYyzUdLOaAdfayBuTYiJjvEcnviWEmgoUyorecQZsenbqfEQDZVEPGTwgHazUYScctheMLyeiTxynEkkYjzpeVTJZAmRZprpQjxVbuAHKVJKNCymwvsrIaLZliVS");
    bool cmonnfmdSLS = false;
    int jPFiELeAaSDXp = -67830994;

    for (int ewyPf = 1309193030; ewyPf > 0; ewyPf--) {
        jPFiELeAaSDXp = jqTdTJLdOXROn;
        jqTdTJLdOXROn *= jPFiELeAaSDXp;
    }

    for (int XwdcL = 14403303; XwdcL > 0; XwdcL--) {
        jPFiELeAaSDXp *= fLVnEEmzHtUoKt;
        jqTdTJLdOXROn *= fLVnEEmzHtUoKt;
    }

    for (int pHDPHULr = 1686981267; pHDPHULr > 0; pHDPHULr--) {
        jqTdTJLdOXROn -= jqTdTJLdOXROn;
        fLVnEEmzHtUoKt /= jqTdTJLdOXROn;
        cmonnfmdSLS = ! cmonnfmdSLS;
        jqTdTJLdOXROn /= jPFiELeAaSDXp;
    }

    return 63399.26191078001;
}

double IfBhaNzDCxhv::pqwqdv(double uXMwsyIkkTjR, double LUSHQjLIbtEMs, int WLHPmj)
{
    int mwPzWxmeDMmcyTM = 1144319805;

    if (LUSHQjLIbtEMs <= -290230.8177046822) {
        for (int ltRGYQQJY = 459484385; ltRGYQQJY > 0; ltRGYQQJY--) {
            LUSHQjLIbtEMs *= uXMwsyIkkTjR;
            LUSHQjLIbtEMs = uXMwsyIkkTjR;
            uXMwsyIkkTjR -= uXMwsyIkkTjR;
        }
    }

    for (int ceNdVxYOhMVdpP = 1307537428; ceNdVxYOhMVdpP > 0; ceNdVxYOhMVdpP--) {
        uXMwsyIkkTjR *= uXMwsyIkkTjR;
        LUSHQjLIbtEMs *= uXMwsyIkkTjR;
    }

    return LUSHQjLIbtEMs;
}

double IfBhaNzDCxhv::qsalFmpKhFwcP()
{
    bool TZjMXr = true;
    int EJEEQLu = 22932595;
    int FUwDnDrKq = -1955472562;
    int DkJycnYcHIuJI = -503405947;
    int MrGMavSWSyNryD = 1759993702;
    int OeZtQkoo = 151194675;
    double tqjinK = 551115.5148975485;
    double iMfeOVugIqNXay = -369641.6552668475;

    for (int TCdnuFteeKQy = 907178539; TCdnuFteeKQy > 0; TCdnuFteeKQy--) {
        EJEEQLu /= FUwDnDrKq;
        DkJycnYcHIuJI *= MrGMavSWSyNryD;
        OeZtQkoo += OeZtQkoo;
        OeZtQkoo += EJEEQLu;
    }

    for (int LvezBrjKuuIJ = 1952298493; LvezBrjKuuIJ > 0; LvezBrjKuuIJ--) {
        tqjinK = iMfeOVugIqNXay;
        MrGMavSWSyNryD += MrGMavSWSyNryD;
        TZjMXr = TZjMXr;
        EJEEQLu -= DkJycnYcHIuJI;
    }

    if (MrGMavSWSyNryD == 22932595) {
        for (int tUvgxxr = 1182908624; tUvgxxr > 0; tUvgxxr--) {
            iMfeOVugIqNXay += iMfeOVugIqNXay;
            FUwDnDrKq -= MrGMavSWSyNryD;
            DkJycnYcHIuJI *= EJEEQLu;
            MrGMavSWSyNryD += OeZtQkoo;
        }
    }

    for (int yKMtMuAPjpQrjEQ = 1833845481; yKMtMuAPjpQrjEQ > 0; yKMtMuAPjpQrjEQ--) {
        FUwDnDrKq = MrGMavSWSyNryD;
        DkJycnYcHIuJI = FUwDnDrKq;
    }

    for (int JDOyrgwfBj = 1774276006; JDOyrgwfBj > 0; JDOyrgwfBj--) {
        iMfeOVugIqNXay += tqjinK;
        EJEEQLu -= OeZtQkoo;
        EJEEQLu -= MrGMavSWSyNryD;
    }

    for (int UriKFwZdATCDQ = 1604711948; UriKFwZdATCDQ > 0; UriKFwZdATCDQ--) {
        TZjMXr = TZjMXr;
        EJEEQLu += FUwDnDrKq;
    }

    if (FUwDnDrKq != 151194675) {
        for (int wJRjAv = 1410255030; wJRjAv > 0; wJRjAv--) {
            FUwDnDrKq -= MrGMavSWSyNryD;
        }
    }

    return iMfeOVugIqNXay;
}

double IfBhaNzDCxhv::tpbEFMrQiRL(double OQEeLUYNlBSoX)
{
    bool KcSGtia = false;
    int kOqHha = 1850305519;
    bool nsHxXVLML = true;
    double DweiMoYPsD = -911148.2974655285;
    int XMceUj = 1005828716;
    bool cYYsIJDXIhqVJYS = true;
    int EYcFKPqP = -1880091624;
    string ZSAhNvBsJdY = string("FnYYzLuvoCUZNbkORCwu");
    string vCaudz = string("VUNhYkaKgxCpjntQkrWsmAXqFrmDu");
    double KIEhSme = 987824.8290646167;

    for (int DOAbkhflwNRgc = 373711484; DOAbkhflwNRgc > 0; DOAbkhflwNRgc--) {
        continue;
    }

    for (int CtpIDsZjpT = 1273486038; CtpIDsZjpT > 0; CtpIDsZjpT--) {
        OQEeLUYNlBSoX += KIEhSme;
        nsHxXVLML = ! nsHxXVLML;
    }

    if (XMceUj <= -1880091624) {
        for (int jWSDqqTFRIzA = 1496250887; jWSDqqTFRIzA > 0; jWSDqqTFRIzA--) {
            continue;
        }
    }

    return KIEhSme;
}

double IfBhaNzDCxhv::KKNQLoGKktaMiz(string emJoxAZqHaPIQd, bool JaPwVjMPYQmlJpT, string DKOWppCPC)
{
    double RCoLUgk = -553866.777774542;
    bool MLPDNg = false;
    int scrsqOxSaEVoz = 390363101;
    bool vvUOpHH = true;
    bool GgkKP = false;

    for (int pWNixmbRSAx = 895374645; pWNixmbRSAx > 0; pWNixmbRSAx--) {
        vvUOpHH = ! MLPDNg;
        GgkKP = GgkKP;
    }

    return RCoLUgk;
}

void IfBhaNzDCxhv::NobrzfAypGEnHC(string YXSuOOAD, double WEbPuYzFF, bool hUuQdzjhWctO, string PFsfqlfWukYAI)
{
    int yjevAu = -2070727424;
    double WRPepwk = 864918.3069401713;
    int aYoykhqFYy = -2123481293;

    for (int yIMewK = 1982330014; yIMewK > 0; yIMewK--) {
        WEbPuYzFF = WEbPuYzFF;
        yjevAu += yjevAu;
        WEbPuYzFF *= WRPepwk;
        hUuQdzjhWctO = hUuQdzjhWctO;
    }

    if (aYoykhqFYy > -2070727424) {
        for (int UfAfl = 209611462; UfAfl > 0; UfAfl--) {
            aYoykhqFYy -= yjevAu;
        }
    }

    for (int UcTfmbeXWPBBBY = 2049103724; UcTfmbeXWPBBBY > 0; UcTfmbeXWPBBBY--) {
        continue;
    }
}

double IfBhaNzDCxhv::ljEAlAeGgiqvRkJ(string PTjrHwa, double izmIMGBkEUyaleOI, string sWjSvsGsIUpMpi, bool IIjmzYQRWHBW)
{
    bool rifMhQKrdBlV = true;
    string ixKVvTDXt = string("OkoocVwWYOaslmlisciSzlyUeIVkUzNCZEhNIUOmjqDIFvMDTkotKmDkzMsmbrNacSUpEyuKIpisgxiaEIEnhyOJrcDzQSilTiFACSEYapmhuBWJlVxGgmprLhBcIrsierWdMCRtBNtyNODFxwUOgimVRXdAfCRwBGcttqOhmrsTgtJcGwUP");
    bool NrVminu = false;
    double sMRmR = -942392.6630748986;
    bool CZRDXBqCGxTGN = true;
    string XiEfRcu = string("rbbYrUvofBLrZLslWobzURlCguFEmIXkYBBzdozxHTSSaRdhrTUJAghVvVuXntUwoJtiVsjovdSYiBlwRgoDmUqyTkqvzCxyHsVNdGcdKDZtGCohUpxCLVCWBEdiKlKwzmnXlqwsVGkqZdSOLvLbSHOKdhHydaPZZDKgxsFgVNDYAcYZcspuFpcGPbriJuBx");
    int CgkrjdcCVTlK = -605365032;

    if (XiEfRcu == string("AfseoltHSDKLQfLrXFnQIFoHoJtHKlOslAxFCDoMWUQLFAcEgnSBNiFJQqKsKpteNreyTaqKhbzFAnPcYaQOkALiqHcyKUDwhCIKPXIqFFNXdrJiBTjpgbEHsKnbNVczZpEnpmRbGveGCgVjSuwykKLukGPdnyZqvhdTwcBxDkcEFXkdIkKoWm")) {
        for (int bjLJSkOrX = 1759742085; bjLJSkOrX > 0; bjLJSkOrX--) {
            izmIMGBkEUyaleOI /= sMRmR;
        }
    }

    return sMRmR;
}

void IfBhaNzDCxhv::LLnuFIakfAYV(string VPSpuxMCETSCPW, bool FzxozYJV, bool dwwkFkJBBIBOSvLd)
{
    double NCMdWIx = 500441.6967302582;
    int JHVGYRNIgiV = -1541527958;
    bool wuoWNOYZi = false;
    double pdefvMMhcnauXg = -388769.058955802;

    for (int wZXSpXbbzkqDccEa = 2094016429; wZXSpXbbzkqDccEa > 0; wZXSpXbbzkqDccEa--) {
        FzxozYJV = FzxozYJV;
        dwwkFkJBBIBOSvLd = wuoWNOYZi;
    }

    for (int kjhQWd = 217456538; kjhQWd > 0; kjhQWd--) {
        wuoWNOYZi = ! dwwkFkJBBIBOSvLd;
        FzxozYJV = FzxozYJV;
        JHVGYRNIgiV += JHVGYRNIgiV;
    }

    for (int SWaHroiICNBfrAS = 136899755; SWaHroiICNBfrAS > 0; SWaHroiICNBfrAS--) {
        wuoWNOYZi = wuoWNOYZi;
    }

    for (int FScpdMDEOh = 671208726; FScpdMDEOh > 0; FScpdMDEOh--) {
        FzxozYJV = FzxozYJV;
    }

    for (int izdeRj = 1002841624; izdeRj > 0; izdeRj--) {
        dwwkFkJBBIBOSvLd = wuoWNOYZi;
    }
}

IfBhaNzDCxhv::IfBhaNzDCxhv()
{
    this->KGRJqKuGWMUXHVj(false, -138256.3420299185, true, string("bekmGFh"));
    this->LmPUrRtVZuWh(true, -523050.49826616346, -75122.07263922128, 76162.74859951179);
    this->doObydoPq(string("hxDIulvPCUbKQnuWUdDLLikBsHkzxsFHiWFUoIuwfIEbjBYhqiZkwFPHcjuPyNuASGylDtbZBLGmuknfofgQXRKWVrNfeJPhZLbRSeTPbDBpyeryyyqzBzvM"), true, -1117002287, -1490882659, -328358.8664820327);
    this->WkPQx(true, string("DiPyhbDrCSQpShYqihMcKqBnYMZsHNkGmtrEnAwYUtWsmdHGtWRguFQPjZvHIQsGNlLiuFJEINueOnJKlshrBmDzYAxTZyVojqzkYbeOraoSlfyHiOnxBYWBScCTksFKhJVlStxAglkPgrahOwqPCcnWMq"), false, 221895.16028528495, 925251.5856344473);
    this->KLwruCWBloZrr(1552085031, true);
    this->igQQQfgC(string("heMxOOkMISkzsumCsbrXEiSiwCNlipjpPysrOrkyphJVyvKkFkjNRHRIdVVpYLgOJ"), -777232.5609151626, string("BcrgoTnOxBsuwVRCLciXLCwkuTVtuLQtUQjorjLMPaAefKcTnvhlmzxDFZspUcKfCUMJWFyIeTvOeBvWGHeEIfQJWmHFPSBCPYMwMlNRZAOdjHtdtZdSSwBOBXbnQNTJrLhFlYqdeHnBQcujsfxpSZLYlqHcfOnsuWkxXwxTlEpDXDntWDVqqDwxbuDpBBpqK"), string("rXYjvCpsilkUfMGjtUfSSRZSXlEyRsvbygJOznkZXIkKLhHGhxnuwidVINFKNWQrpIlMFPhsXhhIzpgjVfefTVotUXJjKFPYLiMqVBitogUlhgfk"));
    this->wpVwLbYlbZn(false, true);
    this->bTyaULOaKeqf();
    this->UMcQGAcs(string("rUztWJD"), false, string("CAyFnVFXpDXANHiPufTGXffODoBYRUxVvGCfnoaGDFomDxNuxTYSZgfetfvgtoFZzNOXmsvgJnzilKrobRmovoUDUXEUDmflbbvVsGivTzyQizXZMMUXLYOmxXsgwAgZQbDiXvzOJTBUeBTDUDNlkVCeNPJQdIKDpXmsqFujRtVBpYRfTsWoImNR"));
    this->GIIFRQRx(1210695127, false);
    this->pqwqdv(-1045028.9948234664, -290230.8177046822, -468904464);
    this->qsalFmpKhFwcP();
    this->tpbEFMrQiRL(213481.6079765113);
    this->KKNQLoGKktaMiz(string("XFXdiXooOHMhBuHLPBuMGWPIOlXNjvcnauAWzctxkKaOzXfWSmgrLWmCScoEpTEKcqPQPCniprHeNxIbupCVdgqCVuovwCOeEzjyvBlfDbuePtsOxjspwLvluoNPxwwBTItjjqHXQTdyhLXqQwInaDESrUlAEcvZaiTBvBtXzEHVLCZyWZiJuXxHlZDmjshnXmYpyyCqmqjZPaANjoiRvsVonRfTVGMyP"), false, string("EoydzaykVWEVPkZFpMQGzQX"));
    this->NobrzfAypGEnHC(string("ujflNperHBkugKSmZeagpMkalRbxpJrDTdxkxeQqYnDOyVCDnMVXOePBveVulCtfpQbitIMctdyAohJxqLTpdmSaEMSuIPfUQpUdCGVMGSGtJQedWMOBZKxOffYzacsDZUBRzwCQHXwCHIWhbwQwZkHsZodkB"), 450941.9541107296, false, string("KbLGpHNoUlNiNUKiOuKloIrwzayRxokgmaRZfPwsSSTknJL"));
    this->ljEAlAeGgiqvRkJ(string("AfseoltHSDKLQfLrXFnQIFoHoJtHKlOslAxFCDoMWUQLFAcEgnSBNiFJQqKsKpteNreyTaqKhbzFAnPcYaQOkALiqHcyKUDwhCIKPXIqFFNXdrJiBTjpgbEHsKnbNVczZpEnpmRbGveGCgVjSuwykKLukGPdnyZqvhdTwcBxDkcEFXkdIkKoWm"), -163379.49082598172, string("qqpbueuaBASiVjtycHntoAfxoAZIrUlzPQTtjpjhYRvJVUqXRrGvfjgDFqHptbOrXhKHCSalhiVhtSuIKWVSeNzsVGDEtarwvGCnVfTdJuaEZaWoGQSmWnKPZTqQRycOyCiXcfgdpPzEuopDJGLTqCIGpzgseeTEXncYaDjKDFEssmZcrLOSydJWhyvjkvXenjmRuuCjzUhXdzeoWhVxpgopUdpaxidgMEbC"), false);
    this->LLnuFIakfAYV(string("jKhTOlnbfJHPPFwshnNPumUqVCmBehYRAjmfvMalUiZivbHGxsQXdZsZXNSYRccjSspVFovBXcOvrjLanrTFrYktQDDWfHDXmYDksErKcxIwgAphEwYUvWonKOiOHRcS"), true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GdQOOdQpmiVSI
{
public:
    string vfTmAnvMZTTwAx;
    double jYFTicMGmbY;
    bool ZIJryCP;
    bool nCWRskzohfKN;

    GdQOOdQpmiVSI();
    double jMHJsiCrg(string TPRgw, string ZQNYPC, string EaCCAUKZ);
    string OFkMVzLSMoKWlFC(string pGhtX, string SKniSfXbPrXmT, int HTEiQrugHwrtzxoA, double qsbzHX, double GEYqWKh);
    string NMgUUPcJRaDruL(bool UnuSZPHgvujkKJia, bool GkJXMaLF, int mCYVdwVVsFLmounx, bool ZIXRnhvbEVLIrI);
    int AkNkLSL(double fbDwEqvCfQ);
    string oBqknlcw();
    void SlrFyZKBSeE(int OAtKtTwKonnaB);
    double wOscbMFQbCA(string UvAWYnRVaTfXJHX, int AtewHFaLeiJZQL, bool kXqSJtKrgfcdm, string JKgCX, int qZtZmZPTDAd);
protected:
    int xsPwLc;
    bool bymhcUnchCc;
    string AWKajgfucs;

    string HpZzNtl(bool YxpmscNorgftQt, string JqHYdDDIXUzbwU, double bQEPYsHorZtDtYb, int tLUSQMkJadK);
    bool FOpOaTPdkchLepX(string mnBsaN, bool CdEQMLlWeBtmimy);
    void kBOzcfzyPV(int XTdQMN, int EiwFjPOsn, double IRjUOMCfj, int KuoqRnmAr, string EzubxXCzLlzNkVbr);
    void GAKcd(int gBwDDoj, bool KrTBKyjYdNWDq, string fhBjqVXI);
    void UrqognPbXgTv(int oYkXUhhwn, double muSuZcazbwv, string aDAGEGjtdilEr);
private:
    string WzJGYcOkszMwH;
    string xIJwj;
    bool cchejZiEoNq;

    double wcymNrhVijOlTl(bool pjvLBKkmKsFbjcP, double WOXfTdQS);
    double dPuCpJftw(bool ldGBanYxQdZh, string zOtATtmghcjxoTk, bool yNwln, int YRbAvXVYEvB, string UIWhOZhz);
    int tUNUtm(string tjlaVRjotKB);
    void jvEyEtJpNDcilL(int OACWKTNSNevdl, double ujRBWRrIUOeSvz, double DDUayadPH, double ZPqSz, int TQgRuWYaDzadu);
    string qYoLKSCnHKbyIAf(bool lBzvPQBgwZV, int ExUqHswVBHtFhvp);
    int jdkCjvOtuK(string fKfSord, string NjRETDCLrl, double aPyZlaBOaqE);
    void nSeRSfMuWDEYnW(string TXCOUZeXxJHw, int NGpwC, bool bbhnkdbiM);
    string MxSrRndCCLhCn(bool LXqNfAnwkdNcP, string llVadiAdfuZq, int zDTzxF);
};

double GdQOOdQpmiVSI::jMHJsiCrg(string TPRgw, string ZQNYPC, string EaCCAUKZ)
{
    string ZjoQVEfFZkqSik = string("dfrOUrQTeOHIWtECXSwFoURQevHwphzMDfdVDTCkFnrTFMaBJehKeKJNeparMrHDKBzglGLfkeBkakNKVhSkhjcXxyGncjrJpueaoBnceqXlUWQStijjhpKcxylFAHIPUIKcCkZSshxiFkWgYAooGkafuVEZJVlcbbwNisHmrJCvTtwIMMFtASlriXgnTfp");
    double ZFLvU = -366779.59428575495;
    int swGemGAZwBjv = -431921470;
    int uAdcUfGhDKj = -2045048905;
    int dRnkhJ = -1420894229;
    double qqMwT = 195206.8355805095;
    double lSEld = -600021.8994521596;
    string hIdcOuhezHG = string("idEGouCvORXQKpUeFnEGVxFz");

    if (EaCCAUKZ >= string("OCFiHqqsrjzHFptjKiehbrojGnzPJeuXQTdQyPzHCIvgjqAFNSHBjUKzVjbzbxdUFhftjyYTLiYzvqHZFtmQvSUrXwauLIyZKYysJTAPWWBqcOUTMkb")) {
        for (int NKaZIwGo = 163470690; NKaZIwGo > 0; NKaZIwGo--) {
            continue;
        }
    }

    for (int iBqSEzpBdcD = 545943805; iBqSEzpBdcD > 0; iBqSEzpBdcD--) {
        hIdcOuhezHG = ZjoQVEfFZkqSik;
        uAdcUfGhDKj -= dRnkhJ;
        uAdcUfGhDKj /= swGemGAZwBjv;
    }

    if (lSEld <= -366779.59428575495) {
        for (int mZldNwlTeI = 2068434977; mZldNwlTeI > 0; mZldNwlTeI--) {
            continue;
        }
    }

    for (int OSWHObkyBMvErbp = 1683022990; OSWHObkyBMvErbp > 0; OSWHObkyBMvErbp--) {
        ZFLvU *= qqMwT;
        lSEld *= qqMwT;
    }

    return lSEld;
}

string GdQOOdQpmiVSI::OFkMVzLSMoKWlFC(string pGhtX, string SKniSfXbPrXmT, int HTEiQrugHwrtzxoA, double qsbzHX, double GEYqWKh)
{
    bool ZuDuTmDEMNCxJaJ = false;
    string OZwyS = string("FIsMXfLBtVByueBmqptCYkkqAUydXlDMtNUqJgfWhUEXGwcfKLQgoTLTjLRjvSORgBTxnLRPGUMCHLcXv");
    bool qgaOnlg = true;
    bool zOksmdIaOlElOo = true;
    string OrgvM = string("CSlEoqqrzIpHjQgfIVqwevMIaXNniWzKvjDyDoZZUrwTFTDIQycxfQTDRzkRVaXHirHZwUjnQUNFGwNHKJXWXUyyuScgwrQUqBYOMGzIsDWcXXogGykrEZRxe");
    int YykRmXsXAr = -503722746;
    bool UTCrloQsMGpIlRN = false;
    double nWlHqEEhxapPizE = 996560.8106325803;
    int DixTXqGA = 597724214;
    bool EuNblyOJ = true;

    for (int mWeniGHAsXi = 1019574905; mWeniGHAsXi > 0; mWeniGHAsXi--) {
        zOksmdIaOlElOo = ZuDuTmDEMNCxJaJ;
        qgaOnlg = ! EuNblyOJ;
    }

    for (int mXRnUHMwNseSyvtX = 1937168323; mXRnUHMwNseSyvtX > 0; mXRnUHMwNseSyvtX--) {
        continue;
    }

    for (int kXfYTqQ = 1772489688; kXfYTqQ > 0; kXfYTqQ--) {
        zOksmdIaOlElOo = ! zOksmdIaOlElOo;
    }

    if (GEYqWKh > 454639.7078893898) {
        for (int yPxQdfYSNVVuMa = 152077907; yPxQdfYSNVVuMa > 0; yPxQdfYSNVVuMa--) {
            HTEiQrugHwrtzxoA *= YykRmXsXAr;
        }
    }

    return OrgvM;
}

string GdQOOdQpmiVSI::NMgUUPcJRaDruL(bool UnuSZPHgvujkKJia, bool GkJXMaLF, int mCYVdwVVsFLmounx, bool ZIXRnhvbEVLIrI)
{
    int uBIhtrrBTjXtMQzx = -349023090;
    string AhGBoP = string("YsAzFhCasqpkoWnIDQAlTnGgBjIUNAHdcqLkZcyUCQecrrDEosCtpAFQmGhSEWIWujnSDZgZjxAeitCHIvdgzsIUMnGFpiJTljymzNMvkOHlKWktaPwjpbcMaeghfWCfHaQnPytOdvNIVPZxLimjUUStGElvQPy");
    int WWdBRLCJ = 130809082;
    bool CYlpbS = true;
    string uUbHLtMYTqE = string("chcaHfqDeBoVoaSUAhICIpMkxrgiZBzDDxiDoadrRvLaleWmvVRWfgxXMUsUIYBZaahYzUragubLxekQdULyfmHPXQsYJdtHaqYmVcxleFmJKseTNpJclSFjAazPCDsUmBAUGBkwlrjIeILKnkpfKtmJEo");
    int eYKycNvUouDNgU = 1300163252;

    for (int zJjXAJKDZU = 1017871685; zJjXAJKDZU > 0; zJjXAJKDZU--) {
        uUbHLtMYTqE += uUbHLtMYTqE;
    }

    return uUbHLtMYTqE;
}

int GdQOOdQpmiVSI::AkNkLSL(double fbDwEqvCfQ)
{
    string epzQcnNJqjhwzoJC = string("TzANkXWOcCZdxNvPYROHtCeFTbzbHsmlDhZlJbTGzidpKuWikSOIUDpPrhUiAiCidUTsDkiOdvRuwuEMqsmiKRwZYtRoujcinHnYgINfNnAJiWuzqJhy");
    int OOGGBDpczmYwhhB = 1108825864;
    double EtwNfSteTD = -277550.3147290616;
    string sMvToGbsaB = string("yHtATJLJHlFBmkLRNbtVnfdNsieJdQlAYjbTkpwYuhdIEdfrTeJgThncnDSgvUWcyAJpqZnjOpnZNDkSJWsbyDOjBIdKUKjDOXGWYoqWsxvfaSypFHKsvibmKHeUJWkziuhErwwjnaaLcUgZ");
    int kgRQVv = 1254471400;
    bool ibQboe = false;
    bool LKVpjtvzO = false;

    for (int jhUben = 885533118; jhUben > 0; jhUben--) {
        kgRQVv += kgRQVv;
    }

    if (epzQcnNJqjhwzoJC <= string("yHtATJLJHlFBmkLRNbtVnfdNsieJdQlAYjbTkpwYuhdIEdfrTeJgThncnDSgvUWcyAJpqZnjOpnZNDkSJWsbyDOjBIdKUKjDOXGWYoqWsxvfaSypFHKsvibmKHeUJWkziuhErwwjnaaLcUgZ")) {
        for (int YIFplANXTmSK = 858239497; YIFplANXTmSK > 0; YIFplANXTmSK--) {
            LKVpjtvzO = ibQboe;
        }
    }

    return kgRQVv;
}

string GdQOOdQpmiVSI::oBqknlcw()
{
    double YPaCkqlbMfZHTddj = -50046.34291273153;
    string ADiesHPsbsrHTO = string("ezEDHmwICbMswOyuFxOkJkMipyOpwfayOGVIQSjMlFtXKoCqNBhxTaOqBKIFXXorMoExOZzidlIregMylYOqwKZcuXFctCYyrUCKglNZNVOLCCcwajLWtjLNkFdtTAjhqXfnoRppJpiArpvUFITZnDSOeLNBjJlspgCcbbNwDYeAQPZwvetPZMiayhkGYOkCVroJUaFBBloxJVrNQGXtplJoNKQoGrNQtn");
    bool bcUWDQfAhqSGZvce = true;
    string LRoPZIdGbySGiR = string("qNbelGZaieetDKoxTkODwCxQlDmrkVPTSsKmjMvqehsXNJkCOJwHpXTlbWygVoOqcvuIVpQcGdBScRNpMHcpixWtnHwfIcNfDFxPtqzqJPCcssbOdxGeqtVswLUqCToFvaCeDLLJQpEwuiTYPrAFuPeAijEsPSpMTuyiPgqLvkDRzZQMrRpbPFYPpLIZUpRavgNgTHRkCikLwPGDwgv");
    int jCEanBUwgA = -1697910689;
    int VZQkEjDFFSmHpf = 1051424731;

    if (jCEanBUwgA > 1051424731) {
        for (int hHwEfvHusJ = 414628180; hHwEfvHusJ > 0; hHwEfvHusJ--) {
            ADiesHPsbsrHTO += ADiesHPsbsrHTO;
            bcUWDQfAhqSGZvce = ! bcUWDQfAhqSGZvce;
        }
    }

    for (int OPoCaTvXScs = 720375080; OPoCaTvXScs > 0; OPoCaTvXScs--) {
        bcUWDQfAhqSGZvce = ! bcUWDQfAhqSGZvce;
        VZQkEjDFFSmHpf += VZQkEjDFFSmHpf;
    }

    if (VZQkEjDFFSmHpf != 1051424731) {
        for (int ghDEJtDStdI = 757752006; ghDEJtDStdI > 0; ghDEJtDStdI--) {
            LRoPZIdGbySGiR += ADiesHPsbsrHTO;
            ADiesHPsbsrHTO += LRoPZIdGbySGiR;
        }
    }

    return LRoPZIdGbySGiR;
}

void GdQOOdQpmiVSI::SlrFyZKBSeE(int OAtKtTwKonnaB)
{
    string FDNKMzQLx = string("qXnmnarHbPHaDHLMmVpeYWryaldLVmQyLMpTymFfrvBaPERzgbdEdAsyogfdurfqWUJFwJrwVAnGbUiZeYDdqpBOPWZpBCONsVYidpJjeBmXxpRnNLmtbiuAEIkQHqQaIJvFzQPFtKJVLbvvKbToEFgnjZmMAlfqmiGiLtnNeTaIpRCbJWLuyzpdXrSxgaMwcoGgnkwWMlhKbCeeDtlnGjDqpOvgxcnV");
    double FfdgabyYktV = -1021723.0055996681;
    bool AMAiXfaqOl = false;
    bool YGWaOBkfSfsogpm = false;
    bool VUVWDyUOydhL = false;

    for (int MWofLQ = 461479423; MWofLQ > 0; MWofLQ--) {
        YGWaOBkfSfsogpm = ! VUVWDyUOydhL;
    }

    for (int jXUrIUHbFLr = 1947528807; jXUrIUHbFLr > 0; jXUrIUHbFLr--) {
        AMAiXfaqOl = ! VUVWDyUOydhL;
    }

    for (int PPDfjShe = 1809737086; PPDfjShe > 0; PPDfjShe--) {
        continue;
    }
}

double GdQOOdQpmiVSI::wOscbMFQbCA(string UvAWYnRVaTfXJHX, int AtewHFaLeiJZQL, bool kXqSJtKrgfcdm, string JKgCX, int qZtZmZPTDAd)
{
    bool pBZOq = false;
    bool CndKhcRD = false;

    for (int qJuZKNo = 2130365422; qJuZKNo > 0; qJuZKNo--) {
        continue;
    }

    for (int oxNdnGsyZDIC = 1159845380; oxNdnGsyZDIC > 0; oxNdnGsyZDIC--) {
        continue;
    }

    if (CndKhcRD != false) {
        for (int fSDUoenBuDN = 832720220; fSDUoenBuDN > 0; fSDUoenBuDN--) {
            AtewHFaLeiJZQL /= AtewHFaLeiJZQL;
            CndKhcRD = ! CndKhcRD;
            kXqSJtKrgfcdm = ! CndKhcRD;
            AtewHFaLeiJZQL += AtewHFaLeiJZQL;
            pBZOq = kXqSJtKrgfcdm;
        }
    }

    for (int xibyaI = 322774761; xibyaI > 0; xibyaI--) {
        UvAWYnRVaTfXJHX = JKgCX;
        pBZOq = ! CndKhcRD;
        UvAWYnRVaTfXJHX = JKgCX;
    }

    return -993915.112274676;
}

string GdQOOdQpmiVSI::HpZzNtl(bool YxpmscNorgftQt, string JqHYdDDIXUzbwU, double bQEPYsHorZtDtYb, int tLUSQMkJadK)
{
    string AdqXSCeuabwZj = string("pWFgtnZYRinydVXMNZWnhjylJMbClKdUhnGiKaTrHmBQavZnyOSJFPgvyOKlkZDUeVVGCZwrZkfvdLwBNNYkwiAhVuYHYfxPkdBpyEHfviDVAFOVgfjhfPHLKtI");
    int RhTZE = 102601429;
    int IHycIsiibj = 1851399632;
    string rJhUSCO = string("FVshOgyHmNhFZJSuMTMeQJHRRZoNPlfyIIqXVDZNMqvstqPUitRXRiXYIeiUFJneqdISIWvBOpkGVEtaZNZZrrkcdJSorfIeTNeHdhqLemdifxlWdMMIXmxZKCDDebEnLnqzzsrzvtVIdjiJbyqdZkJgawZTlBxfzMSoyygUyZeMcRIpISSBwxYzyj");
    int VkqmXqVL = -37307094;
    string GHhvNKTgn = string("EDajgHsQuYIIMsiACAkftmWZnDPafVmpBuvCNgwJmHmFzWKpSiyCwUaMXLSyPrlHbSgkebaXEKJEKRPTvsjqUmdHTugpySnuiNnJNDdqVMHtaafVyQsbZXNOwEXAbebPiAeJyBASpBajfKxLCvTWw");
    double cqYHVtdV = -470489.26739453647;
    string pWzgx = string("jJEdBanDnvpIjiWHqlgXSEXnyifNdKzCEsffPGKZOfythUYDKDaWJxcBtjPLYEmKoMsXpBblHhThUTlHRDyzalnJDiETVoMvxgNdMNBPsRNQllMLPvuFIEDmmXykXzVQWDxmDkOldBNWDvJpiwRresaMOstEdOfNMxdIuaqLmyiMTbrNCMhyGxZPhGbSsHKExaqQQFJ");

    for (int eIKBBIrL = 1994098383; eIKBBIrL > 0; eIKBBIrL--) {
        pWzgx = GHhvNKTgn;
    }

    for (int OhElZjLvN = 196224488; OhElZjLvN > 0; OhElZjLvN--) {
        continue;
    }

    for (int JXQMJfSffEi = 1970906521; JXQMJfSffEi > 0; JXQMJfSffEi--) {
        tLUSQMkJadK = RhTZE;
        bQEPYsHorZtDtYb /= cqYHVtdV;
    }

    for (int dOGTAyxcXRCj = 282548250; dOGTAyxcXRCj > 0; dOGTAyxcXRCj--) {
        pWzgx = rJhUSCO;
        VkqmXqVL *= IHycIsiibj;
        IHycIsiibj = RhTZE;
    }

    return pWzgx;
}

bool GdQOOdQpmiVSI::FOpOaTPdkchLepX(string mnBsaN, bool CdEQMLlWeBtmimy)
{
    bool OAlRyDD = false;
    string ETpjXxHOP = string("XUJyErfPOxgTfVpeLYeesszLWDAvLCLWyufvUr");
    string qfgMnEjcOpyvYGsT = string("qwupLeaXVtLgstegh");

    for (int lqJWio = 976812941; lqJWio > 0; lqJWio--) {
        ETpjXxHOP = ETpjXxHOP;
        qfgMnEjcOpyvYGsT += mnBsaN;
        CdEQMLlWeBtmimy = OAlRyDD;
        qfgMnEjcOpyvYGsT = mnBsaN;
    }

    return OAlRyDD;
}

void GdQOOdQpmiVSI::kBOzcfzyPV(int XTdQMN, int EiwFjPOsn, double IRjUOMCfj, int KuoqRnmAr, string EzubxXCzLlzNkVbr)
{
    double mXdOvhy = 999536.7184687273;
    double hBuudlSraQ = 825076.2282021671;
    int qwzpnKKoav = -306470483;
    string CUibzWbuEzwMdAOE = string("YuifOPvIPZJzroPlWfYctoEWjMsFODkrJyghSxWMMLkGdDtnYBCHNZovJMEmwUNOnVadoAXlUzAbsrFcBJiBZqscmjdETkgboUizPNMXeWPAsYMZPxaWfbWUUwJkpcafoBDIoucxehNYxDbNwFxTGPAVQBXvvWsZHyscVsBtCAZxEOMRNGflZuCCTzDiIarVxqklxPdJaOejRqcoWgbnTIACveFCFfDgAuHaKxVqxRCFZKYVkEiYLZXpDoDuKg");
    double HdJUB = -367726.50293463253;
    string vsuyeN = string("pnZcosw");
    string djGNb = string("YfzDwimSqXXHPgvlolZKtTvUsvzKfPJYnToAhkAByHJhWlaaFTbuywKeWCWXIbfkFynyCAOBVVLghkOujIsVIvNzhIgpzAZszQuoNLdiYddnSXBHfQRyUrrkpkvWg");

    for (int tJqkERoJJlF = 1894885396; tJqkERoJJlF > 0; tJqkERoJJlF--) {
        HdJUB -= hBuudlSraQ;
        EzubxXCzLlzNkVbr = CUibzWbuEzwMdAOE;
    }

    for (int kIOaHAWkXMHq = 2078405469; kIOaHAWkXMHq > 0; kIOaHAWkXMHq--) {
        IRjUOMCfj += IRjUOMCfj;
        qwzpnKKoav = XTdQMN;
        IRjUOMCfj *= mXdOvhy;
    }

    if (IRjUOMCfj != -851045.5903700354) {
        for (int GhzbuWV = 1500590465; GhzbuWV > 0; GhzbuWV--) {
            vsuyeN = djGNb;
            djGNb = djGNb;
            mXdOvhy += hBuudlSraQ;
            EiwFjPOsn += qwzpnKKoav;
        }
    }

    for (int tVrbgRvstHqomSAg = 956725441; tVrbgRvstHqomSAg > 0; tVrbgRvstHqomSAg--) {
        mXdOvhy = hBuudlSraQ;
        djGNb += djGNb;
        EzubxXCzLlzNkVbr += EzubxXCzLlzNkVbr;
    }

    for (int zkvuHrao = 1513419067; zkvuHrao > 0; zkvuHrao--) {
        qwzpnKKoav -= XTdQMN;
        IRjUOMCfj = hBuudlSraQ;
    }
}

void GdQOOdQpmiVSI::GAKcd(int gBwDDoj, bool KrTBKyjYdNWDq, string fhBjqVXI)
{
    int SyMOIGb = -1833722400;
    int RxFWlt = -1716402819;
    double PNOJRROHxlvTpT = 596032.9788624109;
    int DxmwKSb = -1438339900;
    string nhaqqDQNxIqZZdZ = string("hsFUSAGxkAsJjcYsqGipFAyzDcwMrosoAKNnRAXsBblokgNHASMjZYWxVdAyqmMAzLCpamxbL");
    int zeuTMzBeG = -819009561;
    double oSvmqEbbDIU = 735023.3122735338;
    string QVyIr = string("cBItIDBonxbxcOQcCEweVuAjrXrHaBzBqrMbBPNvtscqwBYdcHOUShVuWpkfqHBdTVPzZbPwzPYafKBaoqhZiXJeZykwDYgM");
}

void GdQOOdQpmiVSI::UrqognPbXgTv(int oYkXUhhwn, double muSuZcazbwv, string aDAGEGjtdilEr)
{
    string janpEdKsZx = string("pATKjSvojbEFnumnAgimMHPSoBwWLHOyiSwteZocMZiAYmjxiflHNRYoLoTYytSngdYdcZEsdodsUPCCbiJZToCkVUkdVMkfLwUhoGohmMTkGYkYqKlhVSoZxRTcoDHVPjAlPCbpfE");
    string OdwKu = string("lAVUlZLkuMmWwDIZImjKcHlBCdufmIrkGxCcHrMGDIOYskhibWykMzfJBSNqUIyaROinopnTLqNvopRqCXRRZFCIjSksAwrBQiqzNnLbTOWJRIaLeXqDwOEXuYRbVdbmSRHJIxQawOtNhLwVhFOub");
    bool KKZxSHPyQtwntX = true;
    string MsyXMCHlRzAlAuVR = string("FLOWrKopdSFUzMOlxQrmIbGNUTxjacutjKmGdywUmacnxieVUNSmouizBMGNTMserrpjIxRcgIVbCDQLuBaAtdzYxsUKXpRqvZFgOkOJWtCADPMBPvhercACVPGdKXEaEqtFMxzfJZWcslwjTIrIwV");
    double czYqjzFFynrCcMk = -342610.13335609436;
    double XOUnsvofZzgRL = -840708.89233906;

    for (int KXFARiKjM = 1803507025; KXFARiKjM > 0; KXFARiKjM--) {
        janpEdKsZx = janpEdKsZx;
        aDAGEGjtdilEr = OdwKu;
        XOUnsvofZzgRL *= XOUnsvofZzgRL;
        OdwKu += MsyXMCHlRzAlAuVR;
    }
}

double GdQOOdQpmiVSI::wcymNrhVijOlTl(bool pjvLBKkmKsFbjcP, double WOXfTdQS)
{
    string bNqWfKPymkxz = string("XpCEjhQGcFVRTUXFCaNNDdIabfdKnAFzTDpqcVxMZbJeTFpUtzISIGXwpKewkwUuGgnefHmMIBZabWELnYXFarfSpTDdRZwDLSUEPkzbLyHVwIcPIoVebNskqSnRzGlYYsOZQJFfcKspEZJmONXeEylLmwPDMJatrYOZSyciodltpzaaUiCAHFhlMbpZMCdTsEzWfPqATyELRQRtCEsSrxhnydHUbN");
    int vPkuthAoJphPY = -758814533;

    if (WOXfTdQS < 272531.08953927626) {
        for (int BLquQHlqSr = 944681432; BLquQHlqSr > 0; BLquQHlqSr--) {
            pjvLBKkmKsFbjcP = ! pjvLBKkmKsFbjcP;
            bNqWfKPymkxz += bNqWfKPymkxz;
        }
    }

    if (vPkuthAoJphPY > -758814533) {
        for (int pULEjTmJXID = 1445785334; pULEjTmJXID > 0; pULEjTmJXID--) {
            vPkuthAoJphPY /= vPkuthAoJphPY;
            vPkuthAoJphPY *= vPkuthAoJphPY;
            bNqWfKPymkxz += bNqWfKPymkxz;
        }
    }

    for (int swaxMktvHz = 1234627314; swaxMktvHz > 0; swaxMktvHz--) {
        bNqWfKPymkxz = bNqWfKPymkxz;
    }

    for (int GIJXXGLqO = 1767050350; GIJXXGLqO > 0; GIJXXGLqO--) {
        pjvLBKkmKsFbjcP = ! pjvLBKkmKsFbjcP;
    }

    return WOXfTdQS;
}

double GdQOOdQpmiVSI::dPuCpJftw(bool ldGBanYxQdZh, string zOtATtmghcjxoTk, bool yNwln, int YRbAvXVYEvB, string UIWhOZhz)
{
    bool zGoSIYUthAZWnB = true;

    return -49141.8494444627;
}

int GdQOOdQpmiVSI::tUNUtm(string tjlaVRjotKB)
{
    double XkEuW = 856414.7842262108;
    string OwYSlyjJNIez = string("jWwczSnoLyRRiwdouEsvdkrHscbSNzFkHrCtnCnzdBHTGVbwqhbOXmUcWabCjAmSUrtLJXXKWnbCyXPkEjvnvGWmoNKMDxJtckeOjzjprDmWYzcxaareUOgSfKqaRdofPtnNBBnrZztAhVLjBlqc");
    bool dKUZTegFOJa = true;
    int vLneywXpzvkr = -1871887975;
    string bfcqGuYnUSGAM = string("vLJUSjpZKOIragGPnHZxPiVsgWPzeQSOzvxBxqpbKPaywHMNZkEwjhJsTBWiJfHViNwuXGMwtZoZq");
    string iTLdnlOcgMlwoXn = string("xVbxqNcBnCkyXIWjbHBaejUHMMdryHcbmKaNDnhBphrJ");
    int NiEOGaPPx = 1809624809;
    int sLRblPPmiRNeb = 1528486890;
    bool kuurjHMyzrmwvbyZ = true;

    for (int UlKBbRzIHW = 1423117233; UlKBbRzIHW > 0; UlKBbRzIHW--) {
        OwYSlyjJNIez = tjlaVRjotKB;
        tjlaVRjotKB += OwYSlyjJNIez;
        dKUZTegFOJa = dKUZTegFOJa;
    }

    for (int LtCGRoMoBMnRrcq = 1304652880; LtCGRoMoBMnRrcq > 0; LtCGRoMoBMnRrcq--) {
        NiEOGaPPx -= NiEOGaPPx;
    }

    for (int pzMvGMw = 1338617305; pzMvGMw > 0; pzMvGMw--) {
        sLRblPPmiRNeb /= sLRblPPmiRNeb;
    }

    if (OwYSlyjJNIez < string("vLJUSjpZKOIragGPnHZxPiVsgWPzeQSOzvxBxqpbKPaywHMNZkEwjhJsTBWiJfHViNwuXGMwtZoZq")) {
        for (int GhzZTVWN = 1481183979; GhzZTVWN > 0; GhzZTVWN--) {
            kuurjHMyzrmwvbyZ = ! dKUZTegFOJa;
        }
    }

    for (int akhKSSsozCnZlD = 1205882880; akhKSSsozCnZlD > 0; akhKSSsozCnZlD--) {
        dKUZTegFOJa = ! kuurjHMyzrmwvbyZ;
        iTLdnlOcgMlwoXn = bfcqGuYnUSGAM;
    }

    return sLRblPPmiRNeb;
}

void GdQOOdQpmiVSI::jvEyEtJpNDcilL(int OACWKTNSNevdl, double ujRBWRrIUOeSvz, double DDUayadPH, double ZPqSz, int TQgRuWYaDzadu)
{
    string oBxvHGb = string("SpcBecXeuZgIcsBdihlSDZsvrlZCjbbTmOYJGKBtJNEAEvSlYXJDykKNtxgSMNNMmuJHPJmBYAlmWCaUFzQEIOTGpxTXbNOHdlezKwrkmybglDqkNsPmMEEODVbHcOFjlmrHwEmGRGsZAkVphbFMUpziimiSicAdnnWWCpqKoBlSjFFQGTCSiZmZQMARnzZMONpodthVKEaXyCHsVnDoCqX");
    string zBuxSMQMlkPGnQsY = string("QrnTUVTMkOvxaklblxiicuOmCViwCsVluSdvcSpIPsdOcF");
    int frulc = -1208053837;
    double xxFYWxtctT = -811380.4206203662;
    bool AgxjLeWgpLnEr = false;
    double mGMChJg = 456858.86488428246;
    double fOWXKvcZ = -870252.2546091184;
    int LnqcB = -2135712122;

    for (int daPEntVZfnDTtaOO = 1301100278; daPEntVZfnDTtaOO > 0; daPEntVZfnDTtaOO--) {
        ZPqSz -= ujRBWRrIUOeSvz;
        ZPqSz /= xxFYWxtctT;
    }
}

string GdQOOdQpmiVSI::qYoLKSCnHKbyIAf(bool lBzvPQBgwZV, int ExUqHswVBHtFhvp)
{
    int WlwswhbTiQLxHMKx = -1836849611;
    double WZldzyrPlpSgg = -492337.2089529601;
    double dNSwEO = -450896.8657914342;
    double MqIUboJcAUfbjU = 511474.17145948275;
    string vuimWHhmNajlkmqS = string("PuDFOxWbySERnwzNJoqplqaWkbCTudjqiYOvKFKizuctJhkHeqSzbmEGIkQwtdUmgDuIhRSRmIZEnYcksesjLrEJMyKXbxRtmlHqopaZFrXhltNBmSvrtGtnPhqfbIDagaQamFWgTXatcbdaTzzXMbFStGqKgjEWsPXjKKuwePGqwmjjpEXdqidICXZTJJtbihMideavPPgG");
    bool QYLfTnKSR = false;
    int luHWmZpaUd = -2146427836;
    string mtInTc = string("CPwUqhUWntSGFwNuBvsSDMkibpzRiPXrxEmnbNPwCTlvhZnCAyqqlIWdiDnFETmslAxureiaSaBrIzesbUxNZlSHafxyyExWTUKVgUqbJGFUxskDEILvkJFjXOeilYOCZZdzkckfHQgUvFzTIHHQGoSCmiodJzOkvjQCLKKxmJqlhMCFYdzfjdUMhWSRuWGckSBWjVCFgPouYnAAhjcYBbaBPCE");
    double rHXPNYiHYcQ = 811132.0203472271;
    string HJZEBUuZJE = string("nkLKLpYNQqDhpSAfasYkjxrlfGRMSRUqSrfYcCXtbOsSwTknFKpMAEjsHAeJaySTRqQCpvWooBsJQLFMqQxPrAxmUnkJQsKQbBAwsREOfddbsEDOgtqWdbytPEcEtrx");

    for (int KKmwCde = 1348947288; KKmwCde > 0; KKmwCde--) {
        luHWmZpaUd /= luHWmZpaUd;
    }

    for (int trNuLgmqZLXKVRE = 1384217933; trNuLgmqZLXKVRE > 0; trNuLgmqZLXKVRE--) {
        continue;
    }

    for (int lWbGITrfQiqjbeP = 1017329542; lWbGITrfQiqjbeP > 0; lWbGITrfQiqjbeP--) {
        continue;
    }

    for (int QOTkBASLLtfLq = 1848013746; QOTkBASLLtfLq > 0; QOTkBASLLtfLq--) {
        dNSwEO = rHXPNYiHYcQ;
        luHWmZpaUd *= ExUqHswVBHtFhvp;
    }

    if (rHXPNYiHYcQ > -450896.8657914342) {
        for (int JRuhqw = 1354290011; JRuhqw > 0; JRuhqw--) {
            continue;
        }
    }

    for (int jTyMiFKCkY = 243656089; jTyMiFKCkY > 0; jTyMiFKCkY--) {
        continue;
    }

    for (int uJNsichQgeADw = 1399316644; uJNsichQgeADw > 0; uJNsichQgeADw--) {
        continue;
    }

    return HJZEBUuZJE;
}

int GdQOOdQpmiVSI::jdkCjvOtuK(string fKfSord, string NjRETDCLrl, double aPyZlaBOaqE)
{
    int JUNGscKLeh = 1957068359;
    int ZBfGm = 1229719377;
    bool vbMcO = false;
    bool xTqPgMJyKZY = true;

    for (int pYSfKlmYoYhN = 1325169526; pYSfKlmYoYhN > 0; pYSfKlmYoYhN--) {
        continue;
    }

    for (int pTUtiiU = 1671366246; pTUtiiU > 0; pTUtiiU--) {
        fKfSord += NjRETDCLrl;
    }

    for (int ODbtLFOzCjzA = 2059959475; ODbtLFOzCjzA > 0; ODbtLFOzCjzA--) {
        JUNGscKLeh /= ZBfGm;
    }

    return ZBfGm;
}

void GdQOOdQpmiVSI::nSeRSfMuWDEYnW(string TXCOUZeXxJHw, int NGpwC, bool bbhnkdbiM)
{
    bool XQoMDwnTGvU = false;
    bool UIidMtbSMzb = false;
    int pzDjvY = 1054852828;

    if (UIidMtbSMzb == false) {
        for (int kfglKHcemTZzUgmt = 1647683299; kfglKHcemTZzUgmt > 0; kfglKHcemTZzUgmt--) {
            TXCOUZeXxJHw += TXCOUZeXxJHw;
            TXCOUZeXxJHw = TXCOUZeXxJHw;
            UIidMtbSMzb = ! XQoMDwnTGvU;
        }
    }

    if (UIidMtbSMzb == false) {
        for (int oWIEwia = 1155599230; oWIEwia > 0; oWIEwia--) {
            UIidMtbSMzb = ! UIidMtbSMzb;
            bbhnkdbiM = ! bbhnkdbiM;
            bbhnkdbiM = UIidMtbSMzb;
        }
    }
}

string GdQOOdQpmiVSI::MxSrRndCCLhCn(bool LXqNfAnwkdNcP, string llVadiAdfuZq, int zDTzxF)
{
    bool hTQkrC = false;
    int MJJheld = 1633668108;
    int NGCtQYsPNZJ = -1595450826;
    string mrphrgjrB = string("htWA");

    for (int CpAmSDtuKfHJVI = 1389884542; CpAmSDtuKfHJVI > 0; CpAmSDtuKfHJVI--) {
        zDTzxF /= zDTzxF;
        LXqNfAnwkdNcP = hTQkrC;
    }

    return mrphrgjrB;
}

GdQOOdQpmiVSI::GdQOOdQpmiVSI()
{
    this->jMHJsiCrg(string("uYrUXNGkhpsMLOCHtCZoXmAuYSYPYHefNgLiIPfhErhlttwdwZwqZcTJxlOfDQuObqfjBgihiwlaUVcjCgUZSbzkreGRrNvwWWtfgxNhyNRmiprvhHWPWxPiUjdlsmg"), string("OCFiHqqsrjzHFptjKiehbrojGnzPJeuXQTdQyPzHCIvgjqAFNSHBjUKzVjbzbxdUFhftjyYTLiYzvqHZFtmQvSUrXwauLIyZKYysJTAPWWBqcOUTMkb"), string("eibarFGRZkqsvAmpAxoPOoBRddlAktkzlwiPESNrhoxYjqzNvPacLQEDcFJbXpcJWvwqbbXMGzorjwCUrNcBJahaBboLooZqvDdbapQafQMigmpgEBMRlWgDJueUkLUFOKAHroPKfOjDuZa"));
    this->OFkMVzLSMoKWlFC(string("XRtazQsGDzkfYXrHFNugnUuqYHNRiOwkSjlrQwWfipDWDryqsKHhyCUqVHkSyLlBDKNXVAjRDjArKUKFlZawtssPUrCrPxeZyPpsKfRxAauFhpXhvBYrVCsXzgQUHziUBLqQXqgKzfhCrPQpLonzdRXPERacBplDfMurgWbaPdYaoPEGlDQJVAsZ"), string("AsLxrCaQkqpJlKSaVyJMhWZEopkbNktxUtvHBOzbadEUIOUrEjPcvsNVIficdGSCKgzSdZmhOgkQHEhQQCjOvULRf"), 1728792982, 755082.7107924822, 454639.7078893898);
    this->NMgUUPcJRaDruL(true, true, 1050595626, true);
    this->AkNkLSL(383366.70082486037);
    this->oBqknlcw();
    this->SlrFyZKBSeE(-851793414);
    this->wOscbMFQbCA(string("TgIgLPxLrfIcZQWCPheVzurabTcIwkhCtFkjVUDolLIfBXPGCuNrOpnwVlRfHbYpRFtkPLhTkvMoKTSuigjUbKqgrfEqeeEcbrNTQYsIQHSJxVqocQSVwkioHKRqTuquXRleSIyadRGcfgdElHoLoBPVZKRBJdxcsaHHJFuzESHXgKbVqPAJEotLISkVNrtAOpoNuObalmAlAFtKNBFaQsSzIHrIMRXdfBUWifLyJ"), -482800063, false, string("XvEUOgZLbcNomUknnJcYtxgbLEpAFwFWwwBjpGnZcWvApjOSmiQSBVyqBXaMjlmiCQjqclRbmImfueMuoAhmGwLXggwLJRbAAERScAqIxPjlSRuKTZIMeeSbiKVmAyMHNYqpRAdBOtvnrOoATRpEEBXNOnAfaADrLzkpkyvKfHIliNzxZmfRSCnghXWcrkIeEplFJMvAKCmUAiXuOTZbdHAyVKsVsWOGMOCYGQekyihc"), 1107120123);
    this->HpZzNtl(false, string("GETdPchxlFyCzViygABORNpodddysEabgppTmeQXGWoullKMPzTQHZHkxaUWaJzRMLgiTKDwJGjtyFKraAdlNGzBSQFpQhbViAyAUsOPiPlgYbQQTcMaUNXLHeVHdFUHloRREWVUoWdZThiDnhUhoKb"), -241864.43491409984, -1183852477);
    this->FOpOaTPdkchLepX(string("XdxUIwaCqOJUochOWPZHPQRKvKQhuEHhfqrNOxsIirLfvJHcanZHwpYmEbsdVnkdRoOyjKdGGqktuWYgrzAYHImPcGdMunEPxNEsNdmzkAjroDmAAnydljzTvoAmrtdWjATXRUXMhFfLFGHNuglsygQPOUZhSJoFltwRZXgEfifmAIRQWIuDkfUHbnDKDqWbpReehspYEkJXWgCBfYBLbAccMyTICjCeNDxiJhEnKWGXlvvZzmXMVUsPU"), true);
    this->kBOzcfzyPV(-888219194, 1738699366, -851045.5903700354, 1010995314, string("xPBNatJWPEesVuAOjUBOuxNvrYcvPxqJcRNUkjtyMCoMewlTlrSWdxzbaV"));
    this->GAKcd(-1941923525, true, string("NZXhjawRXnBpSaGAhdDyHWbxExcNlAbzMjlADjJJvXALErBfNIChUiAghnLnmxewDJjrByEUcXvoDfqgrcKULMTBYKrfhlUJCbiXUZOdEIvTGRuzZgjIonPJLNrwB"));
    this->UrqognPbXgTv(-754278719, -730106.3795019152, string("xbKgxblXzQabghirTNXMUPqAozsfYJxZziHjwjtwmvMKIoKzCmMrCquUBHbqhzEQJOxqaGVXORrBZLovirrthWyKLYAFtC"));
    this->wcymNrhVijOlTl(false, 272531.08953927626);
    this->dPuCpJftw(true, string("xvNDQhxaTjuUsyngsdlAGegqwdOPcciFkQZrcPzLwrEkfUtVHCjKCeWgVorbIboWGoJqlVOYcZGPerNPkioUqKXLRqgZp"), false, 1354065833, string("FzDFTAeouNPQhOtCqmPPvXeGzIMgYVBupoWBDshqOemFzJwPGMwCThCGpGrgnvNRZyLArViwtBbHjdiTupycYIZbUUGaWQhtOrBGOKAbukIMBf"));
    this->tUNUtm(string("VCeWuSARKLFUCWRwDSdjxmtHYejaVQtQGnotwiwgDVuoVLkdraQDYYprPQLAuNxSAPhIyAhHufdYQobVrlpZMMirfQdeGPOkLSbfGdEbNatwQPkFdPPFiJtLQPENNRY"));
    this->jvEyEtJpNDcilL(-174368691, -51336.279701137224, 912669.0375135078, -291548.6973563529, -615874384);
    this->qYoLKSCnHKbyIAf(true, 3852250);
    this->jdkCjvOtuK(string("WygYFAySCPGZCxOItsxFsNONncTyjXNMMUaEwtkYttYAvIuWMHOzVdIOtVGASFbbnagULIAaSrRcNKuvVdvaPjerYfQVSFEdffgp"), string("bJtyICQneIaMajMTcfMcJDMdeSnkiWUxWXqzGWQFCciVcoNvrtYljXFCgoQodARvybROLEzRnpJkeWOyMMqVDAmXndIRNibSqjZzlZjTYoaxpeXxvVRpeOfZdeZAxUXVLaGbxNOSbfATgQNRqLQcSjmTLxHJAWwEbMKvHpnDWPLfIOoULHWBrHyzdmMPkyqGFhqKBygSCRqDMD"), 807667.1101024187);
    this->nSeRSfMuWDEYnW(string("JRqFeTSGeAIkaGZGxuLTYBGcLumUYoRZuRxjcdUBbxETWCHDNasvCqhTgxFgvTSvZOflHrFzxpTeVkEkilGMTwmnybUVBiwEEuQVBxEbLJdxpfeZWIVRWRZCaKiSLVFqCpAkHZsRUvASaaJYiktPpVInygZOiFXhNmQfTIACaTEzokylTqYvYEzKNQSQuMpjgQJ"), -57269881, true);
    this->MxSrRndCCLhCn(false, string("fzSSWGkxIftSlsXFUfBHxFluZDYiODfoekYELLVYKqJqIeFVbbUcFzEfcdJQUpKqWNEWJGBKXWIPBTCzMauwWaHDrBHCSgcSmWPWLSPEemQkEpaAtXbGdCJDgTQErzMdisbMXesuMFSXxKeMYZGOuibRiJPJLWkcBUZBvPoQuiNSiRhpCyVvSNfOPSbZMkcsonEPKgBGojZrwjMPUZwNUH"), -483536549);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FFkAvo
{
public:
    double vUEwGtwYWyPueIKz;
    int QxLsVuFFtlimIhPA;
    double fqaiDtSjRiz;
    int zZCbTJSOUJq;
    double BXFicfJDnf;
    double KSvPI;

    FFkAvo();
    string uzEhARVhdKE(int KZjIoD, int HTTSksE, int LumjpbhgOUKSG, double yzNIqHn, bool UTqNEZhSyuDnG);
    double dHNozJbPCY(string McbkTmDwrpukE, double icnFanOfF, bool vaxglsfHJlIPI);
    int KZXcdkVU(string WqVNImrw, bool vsUEd);
    int oHYvBO(bool lvThJ, double pUaiAmkuyJ, string HlKhZbDItknVysd, double PldLusdwdFAxh);
    int HuaMg(double UXvjjlshakriFVA, int pUkTxNHiWMlJgeg, int cqcoyvmX, string AlNNgWZ);
    bool LIgPtJ(int fGFQdn);
    string QuByMmojsBbJ(bool SQDVCCdgR, double lQrskubboNPuQoB, double ZFulHwx);
    string erLgNiDqYPbLsOD(string djnnwnFadGQPvgvY, string pkdAcAA, double EjMMqCb);
protected:
    int TLaoskuTDsSU;
    bool QZTkX;

    int KmMixlkzq(double qWknFUUXfbdKbBa);
    void iuKEB(double WhgmZ, bool bMXtQ);
    double GxPLup(int HQsBhIei, bool VnCPFB, bool mIyQSDFEjItuRdH, bool xOnqyWxvmUQkhUg, string IEbzbEShMq);
    int rZrQKCAS(double irpUTpRRXZYGDi, string LbfvGwppCbtgvj, double oQRzlTdyprOrXNn);
private:
    int wXKlNPIcdW;
    string wtPikaPywaZsbkjm;
    bool GCuIfehahNVHgrQv;
    double FKMylLpxwUI;
    int HBdLmgUzmQm;
    string rnFgsDWmlBoSWRA;

    void GIWxOR(bool QjIhKW, int dxFDbMN, bool ETDSB, int PwplzOF, int IppuTDqldHvRhr);
    int opLZKfCksU();
};

string FFkAvo::uzEhARVhdKE(int KZjIoD, int HTTSksE, int LumjpbhgOUKSG, double yzNIqHn, bool UTqNEZhSyuDnG)
{
    string sGjxaWuL = string("uutMvGYTpkuTrpZiHOqsuiplFxBXtpWYQnEajyCPhNMVZIJaJrSOmBsGqUNRapXEIGan");
    string vDGEWBETo = string("ZqKfuFokkrVbjDqLRQPvLqNwBTQgxuA");
    double rJMogRxfWX = -725516.9807385887;
    double ShkgS = 1016620.6159732136;
    int eRYpO = -264731136;

    for (int MiCHreKzzVglecFJ = 725575337; MiCHreKzzVglecFJ > 0; MiCHreKzzVglecFJ--) {
        ShkgS *= rJMogRxfWX;
        eRYpO = LumjpbhgOUKSG;
    }

    for (int rHRLeFdOQrLc = 1481041633; rHRLeFdOQrLc > 0; rHRLeFdOQrLc--) {
        KZjIoD -= KZjIoD;
        ShkgS += rJMogRxfWX;
        KZjIoD += LumjpbhgOUKSG;
    }

    if (ShkgS == 1016620.6159732136) {
        for (int XjBXODPM = 1163210045; XjBXODPM > 0; XjBXODPM--) {
            continue;
        }
    }

    return vDGEWBETo;
}

double FFkAvo::dHNozJbPCY(string McbkTmDwrpukE, double icnFanOfF, bool vaxglsfHJlIPI)
{
    bool SzAGOrISWQgqPZz = true;
    bool OWEwymOshR = true;
    string NfYCu = string("thqiuCteS");
    double jvUaD = 649513.8222350446;
    string FfxPfrP = string("nfcgyftLGXMOIvrYBeuZoIdaiOxnNwrmWIFBvLuajZjmhgUgZpelMGcBpAXGdWYgoKBIocDIxahXzqkbEFGUfhMqsHXRPhAlPKeRnnnssZmHyhZOrdsFIqxjPOzCdhYlwbxgvbRwGhCbGrZYGyWYcpuMgObJaEvJVMLkLpddwpwMqGsNxWfBziqlozWICEWcNjNNkDDeWRgWRcPlJojwSmI");
    bool UwGuC = true;
    int ZTEABXPtzdgPyPA = 349908318;
    int sORFebgqwCRl = -229113448;
    double ewAQPat = 141124.9541370493;

    if (icnFanOfF != 141124.9541370493) {
        for (int mNPjZLgiZRyMQC = 1279555648; mNPjZLgiZRyMQC > 0; mNPjZLgiZRyMQC--) {
            ZTEABXPtzdgPyPA /= sORFebgqwCRl;
            icnFanOfF *= jvUaD;
        }
    }

    return ewAQPat;
}

int FFkAvo::KZXcdkVU(string WqVNImrw, bool vsUEd)
{
    double uXEXqjwpprm = 807190.586493678;
    bool RRDLz = true;
    double aRfBgiNzI = 407028.07237580983;
    string rbajzo = string("EcrFZbqQqkPEBEkvtRVpYAi");
    string bezVqab = string("oYmECYwTZkomuTgPvbJquVFfTgqVBZOWC");
    double htBVRfcKyujXTll = 195727.00767648136;
    string ZFxJDopBPHMUGLI = string("jZyVWLEQUcjrCtogdwBtDHSQqqRGuvZQaQcVMbqZBCLrbJcFLSlJwSDIXOqQGKHMogkGJGFwOnQzIqOnxCuheApAazegrzTqZouDcwIoCSrFuTVvCsmnfUrrgNTwkxiTcrCciQBzxrdHfLjaSoNXeSYdYuXwiPSfsORXKNyhdYxcQBiyVvkjGjFhntLJrcYbmieQaaXnhcLwjVQXwbdHAZ");
    string AuGXOAAEiWFqPQh = string("OxXrEYbPoxITZpbfQOynusRNGJRAGLBqsmEXillLBKuihZIWgQvHkDBMOtWMnaXJrYarxgJghTxUnLUkObJWs");
    double RUoqgsVVc = 1006529.932076175;
    int vLEPaHievsVIqs = -143505;

    for (int FtePoVt = 154892416; FtePoVt > 0; FtePoVt--) {
        htBVRfcKyujXTll += RUoqgsVVc;
        htBVRfcKyujXTll -= htBVRfcKyujXTll;
        ZFxJDopBPHMUGLI = rbajzo;
        aRfBgiNzI /= RUoqgsVVc;
    }

    for (int GtfKPeEA = 119170983; GtfKPeEA > 0; GtfKPeEA--) {
        AuGXOAAEiWFqPQh = rbajzo;
        vLEPaHievsVIqs /= vLEPaHievsVIqs;
        bezVqab = AuGXOAAEiWFqPQh;
        vLEPaHievsVIqs *= vLEPaHievsVIqs;
        bezVqab += WqVNImrw;
        vLEPaHievsVIqs = vLEPaHievsVIqs;
    }

    for (int dKuAMlX = 2097876166; dKuAMlX > 0; dKuAMlX--) {
        WqVNImrw = bezVqab;
    }

    for (int GEbij = 375669543; GEbij > 0; GEbij--) {
        aRfBgiNzI += htBVRfcKyujXTll;
        aRfBgiNzI *= uXEXqjwpprm;
        WqVNImrw += AuGXOAAEiWFqPQh;
        aRfBgiNzI -= aRfBgiNzI;
    }

    if (aRfBgiNzI < 407028.07237580983) {
        for (int qryLmXHth = 1085248189; qryLmXHth > 0; qryLmXHth--) {
            AuGXOAAEiWFqPQh += AuGXOAAEiWFqPQh;
        }
    }

    if (htBVRfcKyujXTll <= 195727.00767648136) {
        for (int KvscBRxEXF = 492495537; KvscBRxEXF > 0; KvscBRxEXF--) {
            aRfBgiNzI *= uXEXqjwpprm;
            aRfBgiNzI = RUoqgsVVc;
            WqVNImrw = ZFxJDopBPHMUGLI;
            AuGXOAAEiWFqPQh = ZFxJDopBPHMUGLI;
        }
    }

    for (int exzfCCpd = 1097183350; exzfCCpd > 0; exzfCCpd--) {
        RUoqgsVVc += htBVRfcKyujXTll;
        uXEXqjwpprm += aRfBgiNzI;
    }

    return vLEPaHievsVIqs;
}

int FFkAvo::oHYvBO(bool lvThJ, double pUaiAmkuyJ, string HlKhZbDItknVysd, double PldLusdwdFAxh)
{
    int UBkUZBai = -54124984;
    string uDfOyoiPP = string("lGOQwdJIsfKUBdsdsHRyaTOPugshKCirQtRmwCdbPhIDzoQUHnHfhSRRqbYGikguVhlCLR");
    bool yjjunPqSbugxQCzs = true;
    int YWdGrQfLbsHyiDj = 837035617;
    string ehwunBBMk = string("YNFPoeqdqgNFeKEOqOtnwMUqTJNpHzEfhZMajwMsoDOJgabrnokZNBnTvzKNOlSNTJgiyXd");

    if (PldLusdwdFAxh <= -365652.74933859654) {
        for (int GetdrgXaJFP = 1526164986; GetdrgXaJFP > 0; GetdrgXaJFP--) {
            UBkUZBai -= UBkUZBai;
            pUaiAmkuyJ += pUaiAmkuyJ;
        }
    }

    for (int lwXRJemVlfWvVJ = 613419019; lwXRJemVlfWvVJ > 0; lwXRJemVlfWvVJ--) {
        UBkUZBai -= UBkUZBai;
    }

    for (int HRoFXVzUKoFD = 1452910075; HRoFXVzUKoFD > 0; HRoFXVzUKoFD--) {
        continue;
    }

    for (int cMYCEcAciruyQS = 1400243238; cMYCEcAciruyQS > 0; cMYCEcAciruyQS--) {
        YWdGrQfLbsHyiDj /= UBkUZBai;
    }

    return YWdGrQfLbsHyiDj;
}

int FFkAvo::HuaMg(double UXvjjlshakriFVA, int pUkTxNHiWMlJgeg, int cqcoyvmX, string AlNNgWZ)
{
    bool OmyOyRSGCUGc = true;
    double WfXcoTmCfjY = 224210.0372883171;
    int VhiyXYJKueei = -733318072;
    string yhXPJZnjVUvQTi = string("QWCwfcgjQSl");
    string iKkGR = string("aqCbnfZQqYxvsDxSUJyojzwzTdSYUMIGFVTleAAVdYelmqdJzsiuLLEuhKAwyyLMiyysWeArmfsosSjKOCSgLRXCOUhMxDAYvYzNOXZVHOOEthDpFnWIuKuNJfCgoGIMdNeXwWBxMbhiyeFCSiYjZTzdOUYT");
    double iMSHqEXXNHmRk = -131990.30740382802;
    int QiNrd = 1856133079;
    int cXzeoJlDsZ = -1534515105;

    if (cXzeoJlDsZ >= -733318072) {
        for (int lxyQERWWshyhvvx = 15842482; lxyQERWWshyhvvx > 0; lxyQERWWshyhvvx--) {
            iMSHqEXXNHmRk = UXvjjlshakriFVA;
        }
    }

    for (int KjvJfncGBX = 502063211; KjvJfncGBX > 0; KjvJfncGBX--) {
        VhiyXYJKueei -= pUkTxNHiWMlJgeg;
        yhXPJZnjVUvQTi += yhXPJZnjVUvQTi;
    }

    if (cXzeoJlDsZ <= 2041060216) {
        for (int vxDQezo = 1788463592; vxDQezo > 0; vxDQezo--) {
            iKkGR = AlNNgWZ;
            AlNNgWZ = iKkGR;
            VhiyXYJKueei /= pUkTxNHiWMlJgeg;
            cqcoyvmX -= VhiyXYJKueei;
        }
    }

    return cXzeoJlDsZ;
}

bool FFkAvo::LIgPtJ(int fGFQdn)
{
    double sgncXYOWzexgJo = -1027945.9414988837;
    string sFdGOSKTJpJ = string("qeAaarDCCPhvgsZaYqYKbxuehueDrwUwjMxXAmWTHgLAdTOcSiSzWCdgZebxNaBtmjfMEJScSaShhZqeRVGdbeCUoKagMulOdkkiimRKviIycJUKmjfUTjlrEGadxTERgZdznWhBOksMYGEaqHLz");
    int hOKHMChl = -1261269786;
    double TlpRn = -130563.27776273162;
    double KDRlCXiAG = -929544.9924461975;
    string QlhpI = string("uziAqZNkmpvFoWSytCJZXguMKAogUUUjdUma");
    double czAXwdGZm = -850213.7463933928;
    int SNHClOpaJz = 1472696109;
    double jWMkrkkJMKO = -666019.935364683;
    int PzfCPdgTCNmY = -1587249228;

    if (sFdGOSKTJpJ == string("qeAaarDCCPhvgsZaYqYKbxuehueDrwUwjMxXAmWTHgLAdTOcSiSzWCdgZebxNaBtmjfMEJScSaShhZqeRVGdbeCUoKagMulOdkkiimRKviIycJUKmjfUTjlrEGadxTERgZdznWhBOksMYGEaqHLz")) {
        for (int XzHGvdMzbV = 2020430825; XzHGvdMzbV > 0; XzHGvdMzbV--) {
            hOKHMChl += hOKHMChl;
            PzfCPdgTCNmY += hOKHMChl;
        }
    }

    return false;
}

string FFkAvo::QuByMmojsBbJ(bool SQDVCCdgR, double lQrskubboNPuQoB, double ZFulHwx)
{
    string gUYrgAwD = string("GdwQemZkAWGnzPKJBLYkCSmJKunhweLIORchOSPjHTODOpKpHOIRZYmBVHmeUzJRYdEUYbFzWnnEjNdRZyiRvcmy");

    for (int UNzDtfj = 173359666; UNzDtfj > 0; UNzDtfj--) {
        lQrskubboNPuQoB += lQrskubboNPuQoB;
        ZFulHwx -= lQrskubboNPuQoB;
        ZFulHwx *= lQrskubboNPuQoB;
        lQrskubboNPuQoB /= lQrskubboNPuQoB;
        lQrskubboNPuQoB /= lQrskubboNPuQoB;
        ZFulHwx /= lQrskubboNPuQoB;
    }

    for (int PbehCArZSUjjMLM = 1563979567; PbehCArZSUjjMLM > 0; PbehCArZSUjjMLM--) {
        ZFulHwx *= lQrskubboNPuQoB;
        lQrskubboNPuQoB += lQrskubboNPuQoB;
    }

    return gUYrgAwD;
}

string FFkAvo::erLgNiDqYPbLsOD(string djnnwnFadGQPvgvY, string pkdAcAA, double EjMMqCb)
{
    bool VQgjQGiq = true;
    bool JCltqVSGCjLPG = false;
    int eszzw = -805501399;
    bool YNQUeXWjkDiTsH = true;

    for (int rVuhFOfh = 1225090317; rVuhFOfh > 0; rVuhFOfh--) {
        continue;
    }

    for (int moxyjhYEmFruegIC = 1239174047; moxyjhYEmFruegIC > 0; moxyjhYEmFruegIC--) {
        VQgjQGiq = ! JCltqVSGCjLPG;
        JCltqVSGCjLPG = ! YNQUeXWjkDiTsH;
    }

    return pkdAcAA;
}

int FFkAvo::KmMixlkzq(double qWknFUUXfbdKbBa)
{
    int YVrYk = 97870289;
    bool qgrvvI = true;
    bool kaKLCqxz = false;

    for (int zFACoGDTh = 1397590505; zFACoGDTh > 0; zFACoGDTh--) {
        qgrvvI = ! qgrvvI;
        kaKLCqxz = ! qgrvvI;
        qgrvvI = qgrvvI;
        kaKLCqxz = qgrvvI;
        YVrYk = YVrYk;
    }

    for (int tFITMbHqdFcbvrNi = 684641673; tFITMbHqdFcbvrNi > 0; tFITMbHqdFcbvrNi--) {
        YVrYk -= YVrYk;
        kaKLCqxz = qgrvvI;
        qWknFUUXfbdKbBa /= qWknFUUXfbdKbBa;
        qgrvvI = kaKLCqxz;
        YVrYk *= YVrYk;
        qgrvvI = ! kaKLCqxz;
    }

    return YVrYk;
}

void FFkAvo::iuKEB(double WhgmZ, bool bMXtQ)
{
    bool fOnrOAxri = true;
    int VpnCGPjcxCXDY = 434454035;

    for (int MxLuymUnl = 239947759; MxLuymUnl > 0; MxLuymUnl--) {
        VpnCGPjcxCXDY = VpnCGPjcxCXDY;
        fOnrOAxri = fOnrOAxri;
        bMXtQ = bMXtQ;
        fOnrOAxri = ! fOnrOAxri;
    }
}

double FFkAvo::GxPLup(int HQsBhIei, bool VnCPFB, bool mIyQSDFEjItuRdH, bool xOnqyWxvmUQkhUg, string IEbzbEShMq)
{
    string uBEOxaSpbmcc = string("WodJDyhnwlOFrkAPxNIQiQuGqABKrs");
    double KsyumfzxaOf = 330732.311382974;
    double rwmJvmUL = 856887.2968051198;
    int fVZKqgnFZz = 1862746443;

    for (int tGISkatrtWQHOQdl = 121531867; tGISkatrtWQHOQdl > 0; tGISkatrtWQHOQdl--) {
        continue;
    }

    return rwmJvmUL;
}

int FFkAvo::rZrQKCAS(double irpUTpRRXZYGDi, string LbfvGwppCbtgvj, double oQRzlTdyprOrXNn)
{
    string OnbftpE = string("EuliEQLumsnzEgLxasSIFDyAwiiMRpAdJtjGZQHmihDYzugcmtrnZKxyjswHNhwjcCzjBxdRghkbqwUvjhUIkBYQLtuNwbqMyjgyYriOieJiSCndLkKNRFMrnHKECVCiuNJvlYWFdiwlMSpXyisFcMzlLwuWgmtjuyiGQFNHYDgjsEMdRQkuyEOhKmvTEqqCTHmendjTsfHjnGJVZAlmfhVYMPjbRYrCCTZZ");
    string TmEJldphFcifYcPR = string("owdSOaHqeykTUQZXHxEJvdmdqYtFCOXfbeSeRpuqSGeIdZfOexWIIkcIwaKyvGvj");
    bool PUrrDKyUTlimRxJR = true;
    string EzuDtpXyW = string("IiyOOsuJUYHeWLFNliFhRallAdFeZxz");

    for (int zVWFsOKldtjG = 705713578; zVWFsOKldtjG > 0; zVWFsOKldtjG--) {
        PUrrDKyUTlimRxJR = PUrrDKyUTlimRxJR;
        LbfvGwppCbtgvj += TmEJldphFcifYcPR;
        LbfvGwppCbtgvj += EzuDtpXyW;
    }

    if (OnbftpE == string("IiyOOsuJUYHeWLFNliFhRallAdFeZxz")) {
        for (int MwwGy = 678235661; MwwGy > 0; MwwGy--) {
            continue;
        }
    }

    for (int thQcwjGbGqSRY = 44940337; thQcwjGbGqSRY > 0; thQcwjGbGqSRY--) {
        continue;
    }

    for (int HEuuvTVevH = 330507053; HEuuvTVevH > 0; HEuuvTVevH--) {
        irpUTpRRXZYGDi *= irpUTpRRXZYGDi;
        EzuDtpXyW = OnbftpE;
        LbfvGwppCbtgvj += LbfvGwppCbtgvj;
    }

    return -712494146;
}

void FFkAvo::GIWxOR(bool QjIhKW, int dxFDbMN, bool ETDSB, int PwplzOF, int IppuTDqldHvRhr)
{
    string DcHoBUoWOcgGFwq = string("OBTjAjuhwjDLSi");

    if (IppuTDqldHvRhr <= -1347238215) {
        for (int lwZjgveRRO = 394361447; lwZjgveRRO > 0; lwZjgveRRO--) {
            PwplzOF *= PwplzOF;
            ETDSB = ETDSB;
            PwplzOF = dxFDbMN;
            IppuTDqldHvRhr += PwplzOF;
        }
    }
}

int FFkAvo::opLZKfCksU()
{
    string rWopQ = string("edoOuuJVRHSLAMQSGXjzkIJjtincRfJyQAyBkARymeQODvONNQoGsIJZwMBmRZKXdkElBkmJjhNFEqbOrQIdbgQiVMaUkyckrWEWIkB");
    string hfihyLMZ = string("fThVrghXCVJsCldPDhKdaGwRWTXOtCyoSgEysrczUeMJBVLqKDvfacmJqKQSeYIFgPVYTtXZDVORtgbPpZrSSsdKoOXxlarHatOeYAJxKrZavJRzKdRnXnrjshPnrQxzHASwiLUqPpKgbLiTrIBGdeHLmErrqniJDBxmXmkuGLhcRfdEGlPPRNHBREOJlwjJRcSKoKKjiBnrhuwhLBcSSNck");
    string qQEXEDkQJtise = string("JvEljQLplFRVkIyXwiqPKUrRkAnlIMFTfpbrpYRoZzKTkgAYwmAGBWwNWKyTs");
    string csFBrH = string("XdZGZHmhFfGZyCfCIlTGcEKKvjcozNzvzVEWhIxCTddKoZhKqvKnZrbVqsgDABZOkXnYLComQnOQgGQvHqmSkJrFeoLdnAWRjWvnOofthRbbBcQnjDrBlotNYjmIajHwTrbbRxRFZYloNCunAwfeifxyiGeeGuEYIBChbLzwLbIjssVQGNPjBgNgdrSMJAYbExVFrJiPzuDRRqtmVpVXpnpFryGmTGf");
    string MLlXFZubyBfobF = string("lQcrqHtOEbXSthVVrkSapUTgIebKDEHzxFEBIrTIVBKQAnNSSKxFFVCpZaUYaiIERqZkJpvZttaUZHuV");
    int YEhafOhbgFENf = -264313965;
    string dQnQXoS = string("oxrEGGFXNIaGOYDeZtpQByDVXygcIWMHUYjyNXqXiTSEixbDUJsydxqbESodGvyuiJMLiItXHUUBPauOYRsnYEreLpCIugvbqQLoDDcSqxtIcLpbLjSSmhtPFsdcTUAWkYASQXYTrxqXYmtnKBUdGjFAMbMyVWZdsXaJHohvrlJCrTTlAMzVIChqRElDhPDLTpUFiTcaTnntv");

    if (dQnQXoS <= string("oxrEGGFXNIaGOYDeZtpQByDVXygcIWMHUYjyNXqXiTSEixbDUJsydxqbESodGvyuiJMLiItXHUUBPauOYRsnYEreLpCIugvbqQLoDDcSqxtIcLpbLjSSmhtPFsdcTUAWkYASQXYTrxqXYmtnKBUdGjFAMbMyVWZdsXaJHohvrlJCrTTlAMzVIChqRElDhPDLTpUFiTcaTnntv")) {
        for (int KPueY = 355789236; KPueY > 0; KPueY--) {
            MLlXFZubyBfobF += rWopQ;
            rWopQ += qQEXEDkQJtise;
            dQnQXoS = rWopQ;
        }
    }

    for (int YYMmZvXDYXYOgr = 204366007; YYMmZvXDYXYOgr > 0; YYMmZvXDYXYOgr--) {
        dQnQXoS += csFBrH;
    }

    for (int xPNfx = 1008505393; xPNfx > 0; xPNfx--) {
        YEhafOhbgFENf = YEhafOhbgFENf;
    }

    return YEhafOhbgFENf;
}

FFkAvo::FFkAvo()
{
    this->uzEhARVhdKE(971838053, 309498477, 1853207211, -364656.32887704973, false);
    this->dHNozJbPCY(string("AgvADviLRkWMSaiiLRkugNWpBxSSKDYjdpsgRatfUNYtOPEKWKtmDJyiHCBaTcnsTbDpLQyQIyxPEFvetYjlHZdCswadEuGZiyZFWhxiThGPaoZjGknyQdNOYzcMkCWdbOlhVithGBaMGBokJvkvjTpUvREuhUJknCkRHnAOIBRSIxvW"), 108809.09343224225, false);
    this->KZXcdkVU(string("IQgrRrCgmllrndomgDEXLAGkaczweNuapZBQMrUxhpnhnNWlaziYuqwpZCsqFPYSuSAqWdoqTfPuLbYDpsiRjrVOgeLeqOxzTeOZXyLGKesIDCqRrQgRbTsyMQYleKjpyfkNeYcPiGFFMHgiclRMENlAzTpBdiXrTQgtQHOfiBmjTMejhZvgJESrLNaLXfvXecOfrPqarHhFOzIcqGJfcGqjYmZkNHXBchtIHuQGhOxG"), true);
    this->oHYvBO(false, -365652.74933859654, string("WkiFrNGokUObxuFquJXlFMWxAYwtrGxeeFZtreZQtpItvsYzdPCbBssAoQPJRwPMSQwHcraHkojAnlnxwPimdXhjXgxheEMwvutHsojPqhoJcRwCzRPmhIxhoiSwfDmdhohcTZOegzhKTAQfXCRiPOWsxtePErcVngKeZAHcStMIzbmRjBKOsuRyPyeJAphPHuuHNEpcZCWHTyxqJEzoNxgrcoFPaMUSRLxZPJGuIXmwFDkurKEONxCvCgakXkb"), -538501.1995389257);
    this->HuaMg(423795.74692269514, -1775800616, 2041060216, string("DfXQksWnaUFaWayeglGkfdGwSRMporTIXEEIeERoiRbaEHFKOMvwQPMTxsyjwukFGwXuVkDmUQYgPiIIlSwVXJEaFxkWUUiuVjdbNuHTeExLHiErMzJvbCRwGIpauERhEgSJIORUSmxqjZUUWqsvExobwHgHptIaefrAMPFhNWKbiFNFUNjnQqtVVsxTtPUUPWXCbiksdUmaCOXiUAooHJmVUZPDPyaREwvEpgnSqqUAKWSSySWzKj"));
    this->LIgPtJ(1147757229);
    this->QuByMmojsBbJ(true, -627467.3718319037, 893987.402642276);
    this->erLgNiDqYPbLsOD(string("oJZPktTfzGwkAtdqjkIVlSTSYBBRYhRsvAehVbhMpwZTKLMywSwDQSMMhj"), string("RSQBDVwapSykBUlLZmQUBPDrs"), 882029.0156623782);
    this->KmMixlkzq(505480.6880967373);
    this->iuKEB(-16668.904610128746, true);
    this->GxPLup(1279477838, true, true, true, string("yksnCULUBthADLznXYqlufZxrAelecwMQVRovsbzghJugJFpswvmDGvzCGVouDuhTnQtcVCdjHuvPNcifgfZaOaSLJoYy"));
    this->rZrQKCAS(694656.2949415192, string("jtqWUwNwjGkWnrwgphRtHmDoKwjLkXpdCHLglbYeXocESSQbeqoQQkFsrmzCLtOjNxFqboIIQhGirTjwyHvRVSkvzxKMYosgrpXySCRCiHKVcLuxdKXkdfeGh"), -993458.4343493823);
    this->GIWxOR(true, -1347238215, true, 862663635, -1898186474);
    this->opLZKfCksU();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RfdLpNkcwm
{
public:
    int ExnFzeqvL;
    bool FCXdDAZINmJs;
    string ODKAaYWPaIMqS;
    double TMTDgkuUwMnbDdf;

    RfdLpNkcwm();
    string eGiIxoAOCB(double oCPxMyrMy, double jYBPfRZyUAi, int iYdPd, int FHbqQZmr, string sWyMB);
    bool rOSKpKeDSavh(bool LkhowaQnebqPzHu, int mdtfXPQVei, string qUZRmoBzQG, string kmIvdumEaK, string RZuOjSnhXDkcAmJA);
    double FQvKiLgjMF(int OhcnJWrTuxkCNa, string BsvsVAhDMuw, string JghzvQBUQdhUzEw, double ycPboCexUqYG, string EIUvLVZEn);
protected:
    int otzeGZQNP;
    int qygApkNYDUjP;
    bool ZCDNKxoNhbxp;
    int bxaKmrt;

    void vIeSmrhHMykQW();
    int SdJNSfdCbRrlF(int OfBcqMaQhhGFARN, bool fNtzDWsqEiCPITi, int ZvvzfZdXUjgQXX, string AxqPWsHR);
    string MsYVfQHbVA(int PmAAuRK, int yuyzeYD, double ZwMWJ, double RsQuRZPiIaQ);
private:
    bool GuleAkDawQhd;

    void hGOCTWeElZwfe(string AUVGOVtAEqlvlwA, double UojgXxUraIBDtwyW, string SkpTtIBjoYFPvhI);
    void QDPdcgrjhZfCnCi(double eIhlDn);
};

string RfdLpNkcwm::eGiIxoAOCB(double oCPxMyrMy, double jYBPfRZyUAi, int iYdPd, int FHbqQZmr, string sWyMB)
{
    string UHlnMNtnxXQBDIT = string("KbaufKsnztyyYmUQWWnzcxXrRqLRliiFAmMtGoOAWOepKHUHznAlMbMdDzGbvXiBiK");
    bool cQYHyvBXIV = true;
    string lMQktNHaMyU = string("XOHVoQxAFMVaNzomOTzPXwnnivAOefBAzrtzkiNislSrzmBZndpONhtITdGTGLiFPZIHldikwQZLBaYwn");
    double RAAxHlkxQsCgk = 87142.10998577042;
    int GZBJrOwDLITwDV = 1209088345;
    string tepGOcxbelsWfZZ = string("yoOVCSnHgCUQUcbYIGnhHXrQUgZfVyPLlGaoxhXFuheiZRqpibQNXYrcPDoCLIoVJfPYLayyVLeupUATTXrrTPVdXaToHoPdoxnUgpEjoBiKxDsjglRgKcEAObUHuYkdxIxNDSHiBjUCNIhjtJUQhMmjJdZKsSXaHBSeS");
    bool fdMzlcZDlKz = true;
    bool SaIPVpiCQNh = false;
    int ZPOJhYXCqsyTF = -1350221006;

    return tepGOcxbelsWfZZ;
}

bool RfdLpNkcwm::rOSKpKeDSavh(bool LkhowaQnebqPzHu, int mdtfXPQVei, string qUZRmoBzQG, string kmIvdumEaK, string RZuOjSnhXDkcAmJA)
{
    int wJzRQyQTvbalKtz = -1945082251;
    double dmWtfATl = 68010.9700765076;
    bool MWuzuXptdQF = true;
    string vgeoe = string("kwBTFCMmZIFOjqzMdzGiZkaDuiltaVJXeXZQMvEXffCMNzOzOjookpstbyQMoMyJYukdOnhefZgXZTwMXDhIGVqgeHDFBPBIVUNxXgXoIlmSSstNARVNRsFghUdliPoIBsoUiYAzbgymHrHiCvTtkIA");
    string QLtrcW = string("XoybahXqpopnmGOfYFbXVlurjSTFBjGmZACUsVPHXJLdYgpThSPErMjCLDSeZVoMiVEFKoWAsXeJvKbUPawTVqMQlFWhxbnnyLzwLGZURJYiVDGmgkNYSxEjUfOEbLUFQfiCCUJGFfutDsEobJrEtAunCvhiSfFbcMkJJdjRjIcPy");

    for (int BiqzALiQWsSGgqZx = 1680844346; BiqzALiQWsSGgqZx > 0; BiqzALiQWsSGgqZx--) {
        mdtfXPQVei /= mdtfXPQVei;
    }

    for (int nHQEcKqFwoaZFFQM = 169001802; nHQEcKqFwoaZFFQM > 0; nHQEcKqFwoaZFFQM--) {
        vgeoe += vgeoe;
        QLtrcW = qUZRmoBzQG;
    }

    for (int BVQqPgDLkC = 173588632; BVQqPgDLkC > 0; BVQqPgDLkC--) {
        wJzRQyQTvbalKtz *= mdtfXPQVei;
        kmIvdumEaK += qUZRmoBzQG;
    }

    return MWuzuXptdQF;
}

double RfdLpNkcwm::FQvKiLgjMF(int OhcnJWrTuxkCNa, string BsvsVAhDMuw, string JghzvQBUQdhUzEw, double ycPboCexUqYG, string EIUvLVZEn)
{
    bool DwVXnQyhXhAjhJ = false;
    bool yhnBb = false;
    string MBySXYEs = string("vOTnLRnLcaSQPFBHWWikPKoRrNOneJxQByXXIDrjgUKZiURLtPivASPVIBzWKzpViNUjaRfhraGBSxtjuMCsdVYZFLpnCtpPZTJdArTdmlciNODMHqUnflchVfNkloKhsmUZENljYQFvbDiHnfkcdowBBSDqQcRIoANjqACbGROfaXfzHPJleYqfHhaYcmdrSxpTzcqfmpgthcxmzdhT");
    bool zQdKJYFMaCcrDdn = true;
    string mShPjrAaSdEp = string("ANTJBNCFjkAmvFLTaMfQrOdOOcnDklRMTwXwsDluuVucJLCzsydygtfALeyFipKRpssSHFPsdhnpvNOvfuTjhxKeNOxcxvpsAgYzTAMpJEhCddEQWITRDRuBbfzkEvKkfIS");
    bool UFRdwNBoavQHXF = false;
    bool kUEBvlunIEdrknrc = true;

    for (int SHkQJZOZw = 69216367; SHkQJZOZw > 0; SHkQJZOZw--) {
        EIUvLVZEn = EIUvLVZEn;
    }

    for (int LuzipxvoRGVHZb = 463168201; LuzipxvoRGVHZb > 0; LuzipxvoRGVHZb--) {
        yhnBb = DwVXnQyhXhAjhJ;
    }

    if (kUEBvlunIEdrknrc != true) {
        for (int LFeErRolxo = 241016862; LFeErRolxo > 0; LFeErRolxo--) {
            kUEBvlunIEdrknrc = DwVXnQyhXhAjhJ;
            JghzvQBUQdhUzEw = EIUvLVZEn;
        }
    }

    for (int iQIRCpFET = 1387516460; iQIRCpFET > 0; iQIRCpFET--) {
        zQdKJYFMaCcrDdn = ! zQdKJYFMaCcrDdn;
        mShPjrAaSdEp += MBySXYEs;
        JghzvQBUQdhUzEw = BsvsVAhDMuw;
    }

    return ycPboCexUqYG;
}

void RfdLpNkcwm::vIeSmrhHMykQW()
{
    string Tzzhk = string("dcJYdflpaYqHfAOiRvYkpQuDlDumOlut");
    int eXplJGuUqW = -1671992644;
    int ZpBxon = 844530813;

    for (int eVjIIQCYPsMVmAk = 572819452; eVjIIQCYPsMVmAk > 0; eVjIIQCYPsMVmAk--) {
        ZpBxon -= eXplJGuUqW;
        ZpBxon += ZpBxon;
        Tzzhk += Tzzhk;
        eXplJGuUqW *= ZpBxon;
        ZpBxon -= eXplJGuUqW;
        ZpBxon *= ZpBxon;
        eXplJGuUqW = ZpBxon;
        Tzzhk = Tzzhk;
    }

    for (int XMPrIEisbUo = 1737358814; XMPrIEisbUo > 0; XMPrIEisbUo--) {
        ZpBxon += eXplJGuUqW;
        Tzzhk = Tzzhk;
        ZpBxon /= ZpBxon;
        eXplJGuUqW = eXplJGuUqW;
    }
}

int RfdLpNkcwm::SdJNSfdCbRrlF(int OfBcqMaQhhGFARN, bool fNtzDWsqEiCPITi, int ZvvzfZdXUjgQXX, string AxqPWsHR)
{
    string sPAoyuYvQDf = string("XztulYcEqnZStUBdNwSlTEKQoSyBIIwlIffXDMZpDYIbtzfmewhrdVhhNcCZdfSdHhFIXYIumqVaaUxTUNX");
    double dQIfTG = 927532.6240413814;
    bool QqrtL = false;
    double uZkZFAwJrbV = 764508.8653452529;
    string IicBfcEyf = string("uDpnrGIBgZvUrJLSbMUJkzVKPunwJMfsGhnIErUsPROAMrmRjAWpSuqhncOZQbwbrcnlFXIEaWvPBLfywkItSWruVHdnMKuBOpmlkfJhvJgSEKWhXIpzoIkRRvuwobcxJzBgnzawtOQYMgYyhWnEGZrqaRGPyER");

    return ZvvzfZdXUjgQXX;
}

string RfdLpNkcwm::MsYVfQHbVA(int PmAAuRK, int yuyzeYD, double ZwMWJ, double RsQuRZPiIaQ)
{
    double XDVkDezTKbM = 800064.6194453369;
    string KAsaJBtQ = string("YdfWHcpQzWiAiquzzPWWmRnpZPBBhvgVIiozOovwqCjWsZDDveHWjVXKoAeYwGdebXypjezodyuLKzsJiQCWyZleSbNzVhpyFZFqyEwxySjFuvxWzttYNAkZFmhvjAELGMGziQrMCNlYINfT");
    int OWvCgzFSlHTROlS = -1100082270;
    string QRQStoJiyyvFytaV = string("yMhUpDDsDDKWsSaAXvUkxHqFQREsDqmlXxPNcsGYCWSuivmGkieUWXKlpFCFTTQZjlaZQZMHgUjScSYdLlugkdbrZBYxiXsEwsXmQqFIRNIhKoGKLulbMFLhqxcdcFOssmAQ");
    bool vGwmupzcAXatR = true;
    bool SbCXFPgKAkr = false;
    int mTNoJ = 1316072830;

    for (int XaWLeCdBnvx = 118291389; XaWLeCdBnvx > 0; XaWLeCdBnvx--) {
        KAsaJBtQ = KAsaJBtQ;
    }

    if (PmAAuRK != 1316072830) {
        for (int bCAwiBLEcvRsqGj = 1913520017; bCAwiBLEcvRsqGj > 0; bCAwiBLEcvRsqGj--) {
            continue;
        }
    }

    return QRQStoJiyyvFytaV;
}

void RfdLpNkcwm::hGOCTWeElZwfe(string AUVGOVtAEqlvlwA, double UojgXxUraIBDtwyW, string SkpTtIBjoYFPvhI)
{
    string AoaKXwcqGNNVTyq = string("gAvkpBXCOidrOJrhqByOfVsZHEoEGvxkXvwCcdNoBJnofiAnHeSZmwoYLfeihJcNLtXOtuesuBXWyYOfCkIrfzsDHHegttvPkuCDqXxOjtqA");
    int fBmWKFzzWV = 1729359229;
    string aQODwjhsvgCnjQ = string("ECcbASazhkgKw");
    string tKQNhCdpJPIGSKw = string("UZOywOYBPEJwZDrKUzpBSqnRLcnSvFejsNpinHltxmckWZMQCYoUjfgONLzqGclSlwOZdkPqYpMnODssLTgGxImqpLJPmMCHXFPntTomOoSdALAB");
    double ryGcNTPrCB = 576994.5256945861;
    bool hipCu = true;
    int hmVhX = -751821899;
    string MamwwslQzYVAYjLu = string("aCZYLjudZOkXDGJIBRZgYXdWkTKSjjQAahFaFvRiayClfvFuUJfQLtTavKDtorJHfgwZLxrzYNgnCxeXqKYSSOwTUIGQCkjNXrGGyMNaMHWzEJXLwVyagSExEAhSHGUHCMJZRwRjGNNLTHxDkGPOqXxbiKkdNgRLqbgshfdjAcbfauNsmapcoGqsZw");

    for (int NPpxyJYawqrl = 1805256527; NPpxyJYawqrl > 0; NPpxyJYawqrl--) {
        continue;
    }

    if (tKQNhCdpJPIGSKw != string("UZOywOYBPEJwZDrKUzpBSqnRLcnSvFejsNpinHltxmckWZMQCYoUjfgONLzqGclSlwOZdkPqYpMnODssLTgGxImqpLJPmMCHXFPntTomOoSdALAB")) {
        for (int DQfBnxjc = 1918577233; DQfBnxjc > 0; DQfBnxjc--) {
            MamwwslQzYVAYjLu += SkpTtIBjoYFPvhI;
            AoaKXwcqGNNVTyq = AUVGOVtAEqlvlwA;
        }
    }

    for (int FJUbl = 456880079; FJUbl > 0; FJUbl--) {
        SkpTtIBjoYFPvhI += AUVGOVtAEqlvlwA;
    }

    for (int AdyMKPDxDmHIMG = 1996482544; AdyMKPDxDmHIMG > 0; AdyMKPDxDmHIMG--) {
        MamwwslQzYVAYjLu = SkpTtIBjoYFPvhI;
        aQODwjhsvgCnjQ += AoaKXwcqGNNVTyq;
    }

    for (int zqoXjhcA = 1608605813; zqoXjhcA > 0; zqoXjhcA--) {
        tKQNhCdpJPIGSKw += aQODwjhsvgCnjQ;
        tKQNhCdpJPIGSKw = AUVGOVtAEqlvlwA;
        AUVGOVtAEqlvlwA = MamwwslQzYVAYjLu;
        aQODwjhsvgCnjQ = aQODwjhsvgCnjQ;
    }

    for (int NuSbyfLOI = 1856749175; NuSbyfLOI > 0; NuSbyfLOI--) {
        continue;
    }
}

void RfdLpNkcwm::QDPdcgrjhZfCnCi(double eIhlDn)
{
    double KnXlTFobk = -593579.7726263781;
    double EMqjob = 998288.5828679425;
    double tPLMhwPhqzupLDBk = -956169.1717265506;
    double biiMbEGXuFgtHl = -1016716.3441797212;
    int ZBySAOgYXStgTG = -875640720;
    double SoqyWDNDAawYdk = -381015.65895783476;

    if (ZBySAOgYXStgTG != -875640720) {
        for (int XFkXiFN = 406149490; XFkXiFN > 0; XFkXiFN--) {
            SoqyWDNDAawYdk -= SoqyWDNDAawYdk;
            EMqjob -= KnXlTFobk;
            eIhlDn *= SoqyWDNDAawYdk;
        }
    }

    if (EMqjob != -593579.7726263781) {
        for (int ISFDXj = 220704987; ISFDXj > 0; ISFDXj--) {
            SoqyWDNDAawYdk -= biiMbEGXuFgtHl;
            biiMbEGXuFgtHl *= eIhlDn;
            eIhlDn /= KnXlTFobk;
            biiMbEGXuFgtHl += EMqjob;
            SoqyWDNDAawYdk -= eIhlDn;
            tPLMhwPhqzupLDBk = SoqyWDNDAawYdk;
            tPLMhwPhqzupLDBk /= KnXlTFobk;
            eIhlDn /= SoqyWDNDAawYdk;
        }
    }

    if (SoqyWDNDAawYdk <= -593579.7726263781) {
        for (int Kfqwm = 1660959821; Kfqwm > 0; Kfqwm--) {
            tPLMhwPhqzupLDBk += SoqyWDNDAawYdk;
            biiMbEGXuFgtHl -= biiMbEGXuFgtHl;
            EMqjob -= biiMbEGXuFgtHl;
            EMqjob = eIhlDn;
            EMqjob -= EMqjob;
            EMqjob -= KnXlTFobk;
            biiMbEGXuFgtHl = KnXlTFobk;
        }
    }
}

RfdLpNkcwm::RfdLpNkcwm()
{
    this->eGiIxoAOCB(-244718.7349454027, -879291.7605217559, -533513220, 24008972, string("MFonRJZxLtcArGiOISdnjSLNUEkWQpMRmiJROKxYKtVflASADrqdxgqIIrRmbGfMhOliUofxMqdvPWPjHxqUqStFCfRmHpAiwulzZTjJTYDYLHFIUUAtjnQGMYZTnmiNukfAbAFwnrOosqxYQnxeBIhvcHcgKeUK"));
    this->rOSKpKeDSavh(true, 1557519139, string("VxMdgtPhwypftuGugrAamQniZIEvMGRoiDXXqwTuAQLCBMgrs"), string("NMYezLGqwDrhglWyaAFFheQdxEkmagEmsIAzHkoHpCTQkPrjcUAkHjYQlnkFPiNCuuRXRIUyRyVJcEpYrcSRlqwYDUhBTdlgfzjKHKxoULWbgVKTAaSkiISAXFNrXDYXgfOoumFrhVisqBrdNXWRTGAXkwJeeHqxXyloiERgPRcKuTzuFCsytIpkSPLY"), string("PkcJvitwuzawROgJZEkPeNcwvidnPJw"));
    this->FQvKiLgjMF(1477882045, string("ZfzjNvXiSBeRURaByJaXIVyNMnBDzLvKkVaqVtAkbugVouTAQbyIjcyGIffTYbnyxnDHZTYzmhbcnRQIktiDviZuiRSopxBMacSpxqtzhwRkWeKCePztjzbQHkhFzhVbdtMPdJri"), string("FzDRlLfdtqOqdMzPGEcIfZvR"), 1016874.9196056506, string("mZpoVYZrqvBHQCUHggLYeJBULFmHJFznwWYeAFMoYPwUxGzblXDlDoPbgWJAIfQTSDQEunAssJBafkLfF"));
    this->vIeSmrhHMykQW();
    this->SdJNSfdCbRrlF(694157130, false, -1253519016, string("QGtzBbuzaFolayscxjXsmKGewpjdAI"));
    this->MsYVfQHbVA(1343982501, -25374871, -1045945.0963136669, 33361.82547459166);
    this->hGOCTWeElZwfe(string("KtAKQkrlQtOUAntZYygABALfhQCSeqEaoSNwYjCzXiDRyHlFdPijMiMlhbIpVwYqvo"), 772786.053477791, string("aUQOnSQbZamFjEfYThrMjVAtutntreFPpeOb"));
    this->QDPdcgrjhZfCnCi(804247.794424175);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RNmfCYBRKEMDOG
{
public:
    string Klydgwr;
    int TirjHQ;
    double zdCNVyqSphPCOlTa;
    bool rAvGerMalkCcgDYN;
    int FkyMbXPFlIZjzKbP;

    RNmfCYBRKEMDOG();
protected:
    bool OwSPP;

    double ogGvnGDidVZATxa(int wPXHsHiNVPe, string EWAEVGqNqjK, double EpvpizwEzwkvQ);
    double FzjeBxBgwP(int FeIaXec, string ZwPeY, int cCRNkS, double MEHjjZESwZVpEhP);
    string IZboiXdGGYxtYqR(int FvhWQbCX);
    int ODzMJlXsW(string kMIcgRFVUigyQ, double BSigbKGAGnTeL, double FrGrDrXJieRlOyKr, double uvlcKkefb);
    void MHBadTDLX();
    string DaRQS(bool FzSOBDMFyXTGCG);
    string eAQCLPlTvrBWyDgZ(int inisfnOnO, bool wcsgDmo, bool RxtxPlhCHSgSibGe, bool wGkHoedaYdfJYBec, int QztaHHmB);
    void YEaQbVKsNtyfb(double VYMNc, double EdsJloVHujppW, double zPxsPTIzG, bool LmIjZcwRAHeFIqq, string QWBEdvMegPrjphq);
private:
    int ZDEPeLkr;
    int fOkCDSpCy;
    string qAdKYENiLbWWJLm;
    double yppMFPerRJQWNOr;

    void WnrfiM(double IFaZRrw, int nAuNglrfZe);
    string ybwPxuLCKiZlOm(string buUFnYi, int UbtImSv);
};

double RNmfCYBRKEMDOG::ogGvnGDidVZATxa(int wPXHsHiNVPe, string EWAEVGqNqjK, double EpvpizwEzwkvQ)
{
    string OfDWhyklLTqDwZn = string("tNlVfUPOKqKBpwxKFXNvXpPIOEvBegeOtrHmKnzMfQRUEdCIeUbwHLyibOEMuevfVCCkYBZCTUhbkOwSHHGjKRHmUyKBkfFmvfMElqLiISepVmjPahpIJdcDJDJWLwEQthzsLLmkdPCqhMtCpDRcWacQFbXZvvJLVKHFvIXFgnxlVfT");
    double FvqwdGnX = 1035772.9369514803;
    int RgeYUixMDWUPSwT = -1293564839;
    string eBTbrMPhNGEIlz = string("qquNNXUdEwybyPdQgwHeCQuWMebqxTvlnrzJDlmfxBWxFcaIbIrWgwmUwUzQxXPFHFEwkMeeFPfeTrARmQcGolsZZmyaTNKmPKIqRyCOacLLRhHYgYWdxcMCIEAKUePFJDpkxLumkrxKLgUnIXsDJDdqNscKJGGlEshCsxcIDEfJmLBPoFFymaKOmAVhINsJPayksXZodLGUZnAoNggTIibGFFeyGSucmLeDVANyHJOklVyRojChjEsoeQz");

    for (int UghawWrNV = 1653952572; UghawWrNV > 0; UghawWrNV--) {
        RgeYUixMDWUPSwT /= wPXHsHiNVPe;
        eBTbrMPhNGEIlz += OfDWhyklLTqDwZn;
        EpvpizwEzwkvQ /= FvqwdGnX;
    }

    for (int JauyDQtpiCaacI = 598684492; JauyDQtpiCaacI > 0; JauyDQtpiCaacI--) {
        EWAEVGqNqjK += OfDWhyklLTqDwZn;
        wPXHsHiNVPe /= wPXHsHiNVPe;
        eBTbrMPhNGEIlz += EWAEVGqNqjK;
        EWAEVGqNqjK += OfDWhyklLTqDwZn;
    }

    for (int usorlsUlvXZtAFn = 1183874087; usorlsUlvXZtAFn > 0; usorlsUlvXZtAFn--) {
        EpvpizwEzwkvQ /= EpvpizwEzwkvQ;
        eBTbrMPhNGEIlz += EWAEVGqNqjK;
    }

    return FvqwdGnX;
}

double RNmfCYBRKEMDOG::FzjeBxBgwP(int FeIaXec, string ZwPeY, int cCRNkS, double MEHjjZESwZVpEhP)
{
    int bBWSHEc = 1866708791;
    double vCoIjukk = 605602.5143667685;
    bool DxDzWFGtGOR = false;
    bool zqsqZspNqK = false;
    bool ijSvJ = false;
    string szqdm = string("KaIGUFbBRdKdlCCMWlnTQuNGcWqHcgWqMcbsCIqMmTFuZpmATYUGZVGanYCOOzeRACtksCVtfnAXtbxSttNyHNmzMPseGuQTZrkGEBJaJByBZJnwrXFBmqaGmGqaBqukHonwnPCkhulQXzcItflgtbjIyGbWRo");
    bool yEXJaxqT = true;
    int zeuMYqAJQaF = -649078904;
    string dCRPMuSMs = string("EEYRvmqbsnfsHtwvlYpbNwmlizFkdmkxNFbAvECjDyfUDVVvvhzilKTGjovmghWqJgTdgqWeQTVOvWYsVlVBVbqJNAlYuJiLpsLLaNsBtNRAR");
    bool PXcbyLbbQhK = true;

    if (dCRPMuSMs < string("KaIGUFbBRdKdlCCMWlnTQuNGcWqHcgWqMcbsCIqMmTFuZpmATYUGZVGanYCOOzeRACtksCVtfnAXtbxSttNyHNmzMPseGuQTZrkGEBJaJByBZJnwrXFBmqaGmGqaBqukHonwnPCkhulQXzcItflgtbjIyGbWRo")) {
        for (int NUpiPgTAlgpwvnLT = 1006086026; NUpiPgTAlgpwvnLT > 0; NUpiPgTAlgpwvnLT--) {
            DxDzWFGtGOR = ! zqsqZspNqK;
        }
    }

    for (int goiqaS = 452336378; goiqaS > 0; goiqaS--) {
        bBWSHEc -= bBWSHEc;
    }

    return vCoIjukk;
}

string RNmfCYBRKEMDOG::IZboiXdGGYxtYqR(int FvhWQbCX)
{
    int goSRBH = 742572034;

    if (goSRBH > 742572034) {
        for (int gTldjVRWd = 863739480; gTldjVRWd > 0; gTldjVRWd--) {
            FvhWQbCX = goSRBH;
            FvhWQbCX *= FvhWQbCX;
            FvhWQbCX += FvhWQbCX;
            goSRBH += FvhWQbCX;
            FvhWQbCX = FvhWQbCX;
            FvhWQbCX = goSRBH;
            goSRBH *= goSRBH;
            FvhWQbCX -= FvhWQbCX;
            FvhWQbCX *= goSRBH;
            goSRBH /= goSRBH;
        }
    }

    return string("pgvwIiPDCJCQRUyddHsZfmgFMwASYFqHuWxHSzwYvKuWfUMBgwDtqUBtQjeJPicimLkzLewdPyPEFajxKUzPAGMbEToAqLjUXifGVWIIIodrAXRVpaUnoiWRcVVZRujLGgVnzpkmPrPBTwQkKQTJQbzUqJNSscPzIlawffobOrPVWAmRoFYefwcsyDQJRVCzYhyVduZKIdYzQrukyQuutdFQvXFeJfqnvlXDWVLUZygAnMEzfQaXprnrvBTpaRq");
}

int RNmfCYBRKEMDOG::ODzMJlXsW(string kMIcgRFVUigyQ, double BSigbKGAGnTeL, double FrGrDrXJieRlOyKr, double uvlcKkefb)
{
    double wekfCJMVKq = -169157.72758601175;
    double pNdInDRpurHcDUPG = 719586.6521208275;
    int evPydMQ = 759222878;
    double rmTclk = -318869.2575416453;
    bool cXVvPolqy = true;

    return evPydMQ;
}

void RNmfCYBRKEMDOG::MHBadTDLX()
{
    int hUFwOIptja = 158790739;
    bool zkAvgHUcjUGF = true;
    bool rbCJtGFxFVGGGdD = false;
    int XBwAYclrEsjRaM = -1306597361;
    string fPPzKXEBQVGYZiLF = string("LJOwoZFERvXTfHnttKRSYugaEFtzDhvLaQeHlgucoXFjefHNNQIRtQGLRDJDDPiERWkSYKskgnDIntyJomiBExHLTuhtUEsHTbzhxPcBSPIaItlCsuNJhBgPVQijEuIpubj");
    bool AXKgrDCv = true;
    int tATpCRwlA = -1048865744;
    int FdGxSWIMDT = -1299893984;

    for (int ccGiNxlPnvG = 979246918; ccGiNxlPnvG > 0; ccGiNxlPnvG--) {
        tATpCRwlA += tATpCRwlA;
        zkAvgHUcjUGF = ! rbCJtGFxFVGGGdD;
        hUFwOIptja += hUFwOIptja;
        fPPzKXEBQVGYZiLF = fPPzKXEBQVGYZiLF;
    }

    if (zkAvgHUcjUGF == true) {
        for (int BSsjiJGruHfgFaT = 1645129420; BSsjiJGruHfgFaT > 0; BSsjiJGruHfgFaT--) {
            hUFwOIptja += FdGxSWIMDT;
            zkAvgHUcjUGF = ! rbCJtGFxFVGGGdD;
            rbCJtGFxFVGGGdD = rbCJtGFxFVGGGdD;
            tATpCRwlA -= tATpCRwlA;
        }
    }

    if (rbCJtGFxFVGGGdD != true) {
        for (int ilCEqOHaDjLJqVA = 1621073464; ilCEqOHaDjLJqVA > 0; ilCEqOHaDjLJqVA--) {
            zkAvgHUcjUGF = ! AXKgrDCv;
            FdGxSWIMDT += FdGxSWIMDT;
            hUFwOIptja = FdGxSWIMDT;
        }
    }

    if (rbCJtGFxFVGGGdD == true) {
        for (int rdkHfYLR = 649629659; rdkHfYLR > 0; rdkHfYLR--) {
            rbCJtGFxFVGGGdD = ! zkAvgHUcjUGF;
        }
    }
}

string RNmfCYBRKEMDOG::DaRQS(bool FzSOBDMFyXTGCG)
{
    int hUdjyDpiVLPIZaG = 337236219;
    bool ewgsK = true;
    int BkCMU = -1148029391;
    string SOVOotPadQFGbj = string("ReZHsFAYXKkVsdIwOtQdvcbFluhJyGvLevywToKgsQCFXBSOKmTMEeEcVpTHZCEAiscqkSKTlxYFHhWkAtWlcTdjCocwTKkBBYQzmkLqksEBKTYSWZIeYKdABVDxSISUyzdncsxtCNPsKxCOHrRpoJdtpiuGUstmOAlLWaeJYjnuEKUfHynRUvJUPeyHLOCiOWJyHjOIirghgMlzVJrXrwCarfdlIcjDunxcRkWjgoueutGZEXtqz");
    bool aFIcHrE = true;

    for (int BHXPkcj = 2121864076; BHXPkcj > 0; BHXPkcj--) {
        FzSOBDMFyXTGCG = FzSOBDMFyXTGCG;
        FzSOBDMFyXTGCG = FzSOBDMFyXTGCG;
    }

    for (int UQdUDYnbjvfe = 561904039; UQdUDYnbjvfe > 0; UQdUDYnbjvfe--) {
        aFIcHrE = aFIcHrE;
    }

    if (FzSOBDMFyXTGCG == true) {
        for (int XUpWnWB = 172716001; XUpWnWB > 0; XUpWnWB--) {
            SOVOotPadQFGbj += SOVOotPadQFGbj;
            ewgsK = ! aFIcHrE;
            aFIcHrE = ewgsK;
        }
    }

    for (int EAlKzq = 1888262594; EAlKzq > 0; EAlKzq--) {
        hUdjyDpiVLPIZaG += BkCMU;
        FzSOBDMFyXTGCG = FzSOBDMFyXTGCG;
        aFIcHrE = ! ewgsK;
    }

    if (FzSOBDMFyXTGCG == true) {
        for (int KfuuUGWAzWyB = 1224839453; KfuuUGWAzWyB > 0; KfuuUGWAzWyB--) {
            FzSOBDMFyXTGCG = ! ewgsK;
            aFIcHrE = FzSOBDMFyXTGCG;
        }
    }

    for (int UFkYJPi = 1597480642; UFkYJPi > 0; UFkYJPi--) {
        SOVOotPadQFGbj = SOVOotPadQFGbj;
        BkCMU *= hUdjyDpiVLPIZaG;
        hUdjyDpiVLPIZaG = hUdjyDpiVLPIZaG;
        aFIcHrE = ewgsK;
        BkCMU = hUdjyDpiVLPIZaG;
    }

    return SOVOotPadQFGbj;
}

string RNmfCYBRKEMDOG::eAQCLPlTvrBWyDgZ(int inisfnOnO, bool wcsgDmo, bool RxtxPlhCHSgSibGe, bool wGkHoedaYdfJYBec, int QztaHHmB)
{
    string NJjMiKUw = string("EiruYoxOLbIQFBJdtJKeZqUSTfDTATwABaGwrqiqaayjlSHMpWWsYfOKRWlWIhJzHkJoUrJElwkRcfkgudvieOzenHuqHxEDBMxUvgmlCBPAfQqHOASUldjntCUb");
    double BofdOrKvJhOMiPI = -15701.572449048163;
    string YdUTfY = string("PAuerrlHQvTBGosjGEHrBbllqkzEPVbvpAlSmBia");
    int lfHqJStwQ = -1091929411;
    double MhduUche = -694927.6100774792;
    int dCbQxJXYjk = 335565167;
    string wKkfLw = string("perMKzSdFtgNQQeBTJZkJdlmyKNAFwzyvIWZFwrhUZMjJbWoDtEnOTYnCHekGpYRcAgyfxFAAAtkWEokYTGnkznNWoYDbJeqKL");
    bool drIXUFuw = false;
    double HNIUSEfnzpiaBwr = -19704.916071414555;

    return wKkfLw;
}

void RNmfCYBRKEMDOG::YEaQbVKsNtyfb(double VYMNc, double EdsJloVHujppW, double zPxsPTIzG, bool LmIjZcwRAHeFIqq, string QWBEdvMegPrjphq)
{
    double FwIocAIxC = -817515.8357377701;
    double mTPUsFKgbHIUer = -643618.7123403989;
    string hKiMSYysKND = string("aGOIgdcezeBDrpnnJsbKPitRKAugFvSZyneomrmOHdVseOySXmiUMalfirjNlfTGfpytyVoflTRRmcWsDUpCMkejpDsqYpxPcqvkUjlWwLjFlFrrzTilftLqFIvBbRjZriohyqiWdGXdzIkHHSjrjAKwASBRuihCfyjuIRkWJzbVdxjSqZrIneKIaATtqqsbVqruxdGdfALLxqrUTHgKEaSSrDhvMvJtpWZGYBSUNeCLRcSZqZsVh");
    int romNIDAjEELVaRjD = -1232671172;
    string BsjlrGhkXRE = string("nUIksTsfVUJQavHQoFxCyqGYmjMStIwFUvnpVpmNGHouaraiZHFiZuFHcirfbmcbIhuWOEhntVuPpsxnXvnEpUgipnyiAeuSsvqpwBoiIfpFWTDsBsFYBHCCIhQHbkLgPbsMDgwgJvANgMXNItcAzNEoqpjbGKQdjsIazjude");
    bool HhnJCn = false;
    int zJuQhl = 413592700;
    string CfWNKtrRNc = string("TNCMyvKkPFbPNtNTolZYioQn");
    int HDoItzwkgaY = 181896284;

    for (int IRnxfe = 1110502875; IRnxfe > 0; IRnxfe--) {
        zPxsPTIzG = FwIocAIxC;
        QWBEdvMegPrjphq += hKiMSYysKND;
        BsjlrGhkXRE += BsjlrGhkXRE;
    }

    if (romNIDAjEELVaRjD == 181896284) {
        for (int HmKJWFitecm = 987222990; HmKJWFitecm > 0; HmKJWFitecm--) {
            continue;
        }
    }
}

void RNmfCYBRKEMDOG::WnrfiM(double IFaZRrw, int nAuNglrfZe)
{
    double aCLWoE = -1009264.9898575587;
    int asFVayRAFELnXb = 1185859290;
    int PnGhtEgpdcAzQbqu = 1335009567;
    int KZLnRgIEn = -265792833;
    int bMKcxqDluhNvbfH = 218370267;
    double MESTsDUfubIOpkrM = -938323.7523046137;
    string maTKqpGZQTT = string("DQZKXMSUhTHptzkggUswLJWkkPZpbxLKrfgKOfCNQYpVtIgSVJHozxEKGVbSEEJfpVvhMmWFxJoNOKZwruZlnhZqUAiRnCrMRuhEQbEIaxXmWFPdXcDxNZqoLaWCBYYBoxxOTudEgwgazTSsKlJA");
    string wSlEdsjZGTuX = string("fAqifOaOyoDIUaa");
    double OhBIuvmLKlpNNM = 378762.22958151944;
}

string RNmfCYBRKEMDOG::ybwPxuLCKiZlOm(string buUFnYi, int UbtImSv)
{
    double JfNvuoDUOpulsQ = -777325.0075501681;
    string thdJogbgBqxL = string("KOVTvZHBWSdxmQvbCslaevVlBQSfdNcedbxSIjxyfOjYaRTprNwRUaOFlGjxBCSslLjQEzhnTUeSgNbLqLLQYfmMBivNkqLgwsKRlDWZaBhQvWmZUOJZRklpurKtmfUSMfHjYsvSlgdErtBYHzivKtlOyugFEPBSnBnAfNnQH");
    string TXyIN = string("BARoUPaMuRvJveYoLaAvBhnuvhQJoQaazJzItQsUmbMfFngWVbTANjsZblwGMxYERvSgbeezxUQDPPpNZNVjXpBTzbDpQBXqpkLwlicVEcQgPeMfRGZWLvPgeCCpUOeEqlWLgubCUMCisgcsqKXpyYZuulSxTQgZPkEQNmGMAkEMBdvdHmghYjGfGtx");
    double MJqheSMxZqWz = -419390.7067384267;
    bool LGshzGRLoWVfc = true;
    int rRvJCvvGsmD = 1213752791;
    double ztgchFSYIdEeIWFD = -523401.2570369651;
    bool zKgCcuW = true;
    int JKEXMwKzK = 1307081259;
    int EqbwcR = 774481099;

    if (zKgCcuW == true) {
        for (int XRiqAGfMsaKRq = 1261162371; XRiqAGfMsaKRq > 0; XRiqAGfMsaKRq--) {
            continue;
        }
    }

    for (int yoCovWvPPPyyoF = 577815772; yoCovWvPPPyyoF > 0; yoCovWvPPPyyoF--) {
        TXyIN = thdJogbgBqxL;
    }

    for (int uCAly = 748021487; uCAly > 0; uCAly--) {
        rRvJCvvGsmD += UbtImSv;
        rRvJCvvGsmD /= JKEXMwKzK;
    }

    if (EqbwcR < 1307081259) {
        for (int YIeWVklUx = 1590655608; YIeWVklUx > 0; YIeWVklUx--) {
            JfNvuoDUOpulsQ *= ztgchFSYIdEeIWFD;
            LGshzGRLoWVfc = ! LGshzGRLoWVfc;
            JKEXMwKzK *= JKEXMwKzK;
        }
    }

    for (int KwPEptMZkPTNUY = 1009389884; KwPEptMZkPTNUY > 0; KwPEptMZkPTNUY--) {
        EqbwcR /= UbtImSv;
        MJqheSMxZqWz -= JfNvuoDUOpulsQ;
        UbtImSv *= JKEXMwKzK;
        JfNvuoDUOpulsQ = MJqheSMxZqWz;
        JKEXMwKzK -= UbtImSv;
    }

    for (int bXkzh = 356911021; bXkzh > 0; bXkzh--) {
        continue;
    }

    return TXyIN;
}

RNmfCYBRKEMDOG::RNmfCYBRKEMDOG()
{
    this->ogGvnGDidVZATxa(-2064384913, string("FVcakuAFKFIFOmGOOKIQNbJkaOyGGgcrGHJiHdmdTLMWiKrzxhUbwgKtSzDinCsVsKUuYlhl"), -642310.2703595597);
    this->FzjeBxBgwP(-1034339316, string("DoFqadAEPKRqokyFaJumCNHodCQTydtKiMtVdNmhhBnjIwLedBdHrxu"), -1208287133, 108316.17579591347);
    this->IZboiXdGGYxtYqR(-425292407);
    this->ODzMJlXsW(string("ryDvNyHEmeuZqrkuFAIEtjEioqOLsKfnEMQvDuJSdjCJiaBULMCrgjiKRwYEClhMfzyBUfRndGZpUSlXsaqxOtWRnTHGwDnajgPkBfVhafscjeKYBPlRMUlfxg"), -520635.6910890258, 958864.5360230544, 1005674.7936578246);
    this->MHBadTDLX();
    this->DaRQS(true);
    this->eAQCLPlTvrBWyDgZ(999367862, true, false, false, -631935926);
    this->YEaQbVKsNtyfb(937238.433096839, -669984.21355635, 868590.7534539058, false, string("ZgKVvTTWsNtANadtCDTncNifZlztKNQfHaQVMjluUxIIZLnsGXGNVrKeCNkgiauQctdGntBEZjiLHaYvNoiGJpmwX"));
    this->WnrfiM(713363.2394832256, -754002755);
    this->ybwPxuLCKiZlOm(string("kjbwNGaiBifuEYpImpadtiWDAgJYriRmGBdwUKXNwOlw"), -1324598108);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LqIrLXJFCzsTi
{
public:
    double eoubNbZhRZn;
    bool tfvIHf;

    LqIrLXJFCzsTi();
    string mXLJX(bool jSqzaXewNhtJWX, double abSywyQFhUl, bool aUYiGSwUYkUqGmC, double pbdVzsCkgtsno);
    void kYQdIJ(double SRLlei, string uCERbkNbRvg, int sCPphbIMCzBwvXZ);
    int VgukxyCYLkxT(double Wirvrqujh, bool almjlktiN, double uOpwtaIQUTQ);
    string rVbrpmCKvoBTpBui();
    double TzTFMIfUhZcLVK(bool TQdXvpcpTjODAQKe);
    bool IXiysNXHyNXhjfx(string KOApOHu, bool NSgjZNEX);
protected:
    double deeeV;
    int oHeMHYGLNc;
    string xuBUfHmcijz;
    bool vVErFeAbZ;

    string pLLpfsswhR();
    double rqbHIkwF();
    bool ksQjSIkkgquKlr(int EshenkZIYGJL, string DMjTThdlNWuK);
    double OsjGze(bool UXxBlCT, bool ouiJXxUhN);
private:
    string SBhIBeTTSYSMjSI;

};

string LqIrLXJFCzsTi::mXLJX(bool jSqzaXewNhtJWX, double abSywyQFhUl, bool aUYiGSwUYkUqGmC, double pbdVzsCkgtsno)
{
    bool HBDBIbqQ = false;
    int vfOjVufwosn = 785341621;
    double QMWjWoL = -789181.3191626724;
    string ylnRWMp = string("PHXtcSXgJgMHGKEuNHjZrUGeCmsDgWQSTyWAYXCNndcwWavoBkeEFronX");
    string CKCTcTwAAeT = string("vxVuhnNWoeHVsDCOdCPiaqYpZsZriQwGJnqypsPlDiwhHhrGFPmUmMuxlsFBtkCcuQQewURIBgRgCKmnB");
    bool pRvEyHhGBU = true;
    int AMcCGkIQaC = 1461826692;
    int aVPWhnJTg = -244511276;
    int ixoGyZvPS = 599113802;
    int oZLjjUZSDYiHvGNF = -1150217995;

    for (int FkLvdgMqhZ = 1402494436; FkLvdgMqhZ > 0; FkLvdgMqhZ--) {
        vfOjVufwosn += oZLjjUZSDYiHvGNF;
        AMcCGkIQaC *= aVPWhnJTg;
    }

    if (AMcCGkIQaC <= 1461826692) {
        for (int IZqMl = 133979856; IZqMl > 0; IZqMl--) {
            HBDBIbqQ = ! pRvEyHhGBU;
        }
    }

    for (int RbvPeMhqPyOe = 35692797; RbvPeMhqPyOe > 0; RbvPeMhqPyOe--) {
        HBDBIbqQ = ! pRvEyHhGBU;
        oZLjjUZSDYiHvGNF *= AMcCGkIQaC;
    }

    return CKCTcTwAAeT;
}

void LqIrLXJFCzsTi::kYQdIJ(double SRLlei, string uCERbkNbRvg, int sCPphbIMCzBwvXZ)
{
    string BbTCN = string("rduwxxCCxaqQEGeDUTnjrUyBWnmunNgBGZYGkUXfiqtyHOIEmmawjXdQXsDxIaAoijdEDThcdwVQHPhiBgLmSpXQFFNgVjCDkYueszdORSyDxCBCuedgoztGXmLdoVimeGNwUQtNImMUsDbDVDHqvubGyUUYcLBx");

    for (int TltYxdeAfrpQ = 854996092; TltYxdeAfrpQ > 0; TltYxdeAfrpQ--) {
        SRLlei = SRLlei;
        BbTCN += uCERbkNbRvg;
        BbTCN = BbTCN;
        BbTCN = BbTCN;
        BbTCN += uCERbkNbRvg;
    }

    if (sCPphbIMCzBwvXZ < -100335466) {
        for (int SDOBImwR = 96854322; SDOBImwR > 0; SDOBImwR--) {
            uCERbkNbRvg += uCERbkNbRvg;
            BbTCN = uCERbkNbRvg;
            BbTCN += BbTCN;
            uCERbkNbRvg += BbTCN;
            BbTCN = BbTCN;
        }
    }

    for (int SVYgBkhxJiKibfy = 685484795; SVYgBkhxJiKibfy > 0; SVYgBkhxJiKibfy--) {
        SRLlei *= SRLlei;
        sCPphbIMCzBwvXZ *= sCPphbIMCzBwvXZ;
    }

    for (int swpPmsr = 622751901; swpPmsr > 0; swpPmsr--) {
        continue;
    }
}

int LqIrLXJFCzsTi::VgukxyCYLkxT(double Wirvrqujh, bool almjlktiN, double uOpwtaIQUTQ)
{
    double zOslJvWwtV = 363271.83709555987;
    string xzoTvbrfk = string("EcVAyXoOJHwBFuyTnemMdlKVtSIOuaqlPtVRZESXRHglhshHUjxVxLXTPxABEuNqZBJSILcfcrGMhUpEmhGgiAEtsKdoQrGPqyyJrKFGyGBenpIvOawPSfvUNxtuyMTdmCsxZDtIFbhUdwSYzxGPSllTmwEIfTwduFZTHNoYbCutMtWdBhotqMqIUKrAWgCZStbDbVCeKtSRSBLXWHtwukQhFmmSpQJnBuVVdkQwjjkgjA");
    string ZoMsbKAfYRe = string("URHmVjQmwDTZiStrcqlrlpkkyhtmacnFpDzzwYvqUOcjsJEmsIIDbTlIaHvRIoeRcjoQAaDrzYVEeraazGISYrraCrmMKvUbJwnW");
    string VlPumXX = string("svFXvqjuTljgnGBNqNjOHJPuFFiHaizEIaxZFhxLKfhkdMMCVlLKabIfPtZVhtOcPzaJPqCZTmiNXjMkVJVWkAnWQXRAIwmQvYmZAYDYucscyxrBhJsmBaqCSsmTDxEkSPktupPphRDnXVaSEjCblDBXXafkfcTAdSNbGLBFVKfAjqyBnCZSBHoppeEPcSHBiPyIbakqdJoxGuyWDCvrnLGLhZtNVapzhOwTkGekZbUMAFgB");
    string UOJwI = string("MBVqJMdFrhjwnrTtYVcUKtNFwNsnHjMtDpotr");
    int jHXxoroz = -1973200369;

    for (int WdRjMXhW = 598244931; WdRjMXhW > 0; WdRjMXhW--) {
        xzoTvbrfk = xzoTvbrfk;
        xzoTvbrfk = xzoTvbrfk;
        zOslJvWwtV = uOpwtaIQUTQ;
        UOJwI = ZoMsbKAfYRe;
    }

    return jHXxoroz;
}

string LqIrLXJFCzsTi::rVbrpmCKvoBTpBui()
{
    string WgOdvjQdmvW = string("drzBmoqxetMTYmAFwjbdIrHKMhvnOVwXCrVmDfbFhmArPZekAZaKdGdjrOkKBxdnSgUWTOtCVgkeRpPKFiioIGnSzUsvPMdbtuclXLShmuwyYJoZYeFxWYXzWtiAZhdChnrqTqjaFDrYeJMGXhpFZUjwwgxkSbwxLiESZebxLGVnSOlWiQykZxwdSxNErCGXItROrkfEbluhVcqeznaQbcdGmwcelwMxXylFdCqdMLJqRHVM");
    int tpIguhkmffxqaUza = 1876369217;
    double ENufa = -672422.4756109465;

    for (int NCtlUHZUVnt = 419568763; NCtlUHZUVnt > 0; NCtlUHZUVnt--) {
        WgOdvjQdmvW += WgOdvjQdmvW;
        ENufa /= ENufa;
        WgOdvjQdmvW += WgOdvjQdmvW;
        ENufa *= ENufa;
    }

    for (int AiCbDhlAVKHdwDfa = 1761340830; AiCbDhlAVKHdwDfa > 0; AiCbDhlAVKHdwDfa--) {
        WgOdvjQdmvW = WgOdvjQdmvW;
    }

    for (int enyiZmPIZWWARn = 233611708; enyiZmPIZWWARn > 0; enyiZmPIZWWARn--) {
        WgOdvjQdmvW += WgOdvjQdmvW;
        tpIguhkmffxqaUza /= tpIguhkmffxqaUza;
        tpIguhkmffxqaUza *= tpIguhkmffxqaUza;
        tpIguhkmffxqaUza = tpIguhkmffxqaUza;
    }

    return WgOdvjQdmvW;
}

double LqIrLXJFCzsTi::TzTFMIfUhZcLVK(bool TQdXvpcpTjODAQKe)
{
    string cKPjxjukFEizd = string("xbNqfglIFkLqvuigOakfNNRATLJcdWUBsnJuiwoGkQBdJfQslegzhPXDKyCjhLRgIqasPPlcGSulbpUSxuBcUfdwmhlJwDnOSMevVylbAPYdJtiUsqAtxIlnoyvbgBVjMgWlaramAPMuGeswcfBGigcsBYGdfgTEZe");
    bool nXsUXzADjfvmay = false;
    bool hoPURsZsRPX = false;
    bool mepgePMTIwRjC = false;
    int ONvRbdpA = -77540441;
    bool WDhFSjGIKrV = false;

    if (nXsUXzADjfvmay == false) {
        for (int TpErf = 2032798355; TpErf > 0; TpErf--) {
            TQdXvpcpTjODAQKe = WDhFSjGIKrV;
        }
    }

    if (hoPURsZsRPX != false) {
        for (int fckXKelGNkGrobTr = 353624824; fckXKelGNkGrobTr > 0; fckXKelGNkGrobTr--) {
            mepgePMTIwRjC = ! hoPURsZsRPX;
            nXsUXzADjfvmay = hoPURsZsRPX;
        }
    }

    for (int jUYYqcFMVrsQyo = 1329065488; jUYYqcFMVrsQyo > 0; jUYYqcFMVrsQyo--) {
        WDhFSjGIKrV = nXsUXzADjfvmay;
        hoPURsZsRPX = WDhFSjGIKrV;
    }

    for (int pjqBrKU = 1872990974; pjqBrKU > 0; pjqBrKU--) {
        continue;
    }

    return 1001179.5223377593;
}

bool LqIrLXJFCzsTi::IXiysNXHyNXhjfx(string KOApOHu, bool NSgjZNEX)
{
    bool nihgjaywAbLlkHxu = false;
    double wsBeqABRwTzPDknU = 866099.8463970936;
    int dzyqCtrEpzQG = -1936673613;

    for (int oxENYCZOrkHeYXyn = 1279225913; oxENYCZOrkHeYXyn > 0; oxENYCZOrkHeYXyn--) {
        KOApOHu += KOApOHu;
    }

    for (int fmucXWOkLGjgxQUI = 748109925; fmucXWOkLGjgxQUI > 0; fmucXWOkLGjgxQUI--) {
        wsBeqABRwTzPDknU -= wsBeqABRwTzPDknU;
        NSgjZNEX = ! nihgjaywAbLlkHxu;
    }

    return nihgjaywAbLlkHxu;
}

string LqIrLXJFCzsTi::pLLpfsswhR()
{
    bool jRWssx = true;
    double NtDkwEjUd = -87494.34901214346;
    string mofBqUVgdOzZ = string("cVjuAPhePJPMkLJqtJXKXQlLpBhzucHuqQTCAmRbIdYTwqqrAnetdEEwcnFtsQKDQgXXGlfkZZgBNgjlBuyRhglirFRnmxQBGzNqZNiRxAnwrrUzFqrEfXTspQQMsvuWjthPRTUodjnHOxanagSlkPkLui");
    string lIpEJ = string("gCNXjpkzBwJXniJnMNOxZCkWQCSvpmAanRrPANNlhfsbiuYgKMcHExxpEXHuccQqiRHFYugFUZrBJhIFQco");
    string wcAQAwTpPfut = string("yDYghEZElDGnIfzYffsEMEEpVtNHCkkcKPBtBCsDIXlnlujzMsszvpEPRxAiGwiqbxmWkTyNqVIjWomdPlXwhbGJDWykuGNIIaCdRfiAKfhODPsNitJsgkUVkvLXbuZNygLvKCfRSQUWpoOnVYJQnyLfEztCZbkdiYlAgjldDBmtqkHPwmlhGwwcfDlolUHjvXnNVVCLphyVQaehrtKHZfFebPpRPZhDdixeClBsnrvjXBnNjLBZCsbYqn");

    if (lIpEJ <= string("gCNXjpkzBwJXniJnMNOxZCkWQCSvpmAanRrPANNlhfsbiuYgKMcHExxpEXHuccQqiRHFYugFUZrBJhIFQco")) {
        for (int rhsCS = 692348366; rhsCS > 0; rhsCS--) {
            lIpEJ += mofBqUVgdOzZ;
            mofBqUVgdOzZ = lIpEJ;
            wcAQAwTpPfut += lIpEJ;
            mofBqUVgdOzZ += lIpEJ;
            wcAQAwTpPfut = wcAQAwTpPfut;
            NtDkwEjUd = NtDkwEjUd;
        }
    }

    return wcAQAwTpPfut;
}

double LqIrLXJFCzsTi::rqbHIkwF()
{
    double UsdsolRnyG = 197714.84296425022;
    int PVVEseHUy = -1149339627;
    bool DwrgeDXDc = true;
    string CowDKYyd = string("rEzTcJBzCSiqfzgWnfwjMnZSkNewueKvMNlAVZKnmpzyokpnkGVdPZhlQfoSzQQvbYwxQmKrzCWBWqtODZsarudVavaNHPivUBxhFLtEnBcmFnFKOUPtXMhzqOSBlDoixohJzwvNBFTHTHdcDXhFYJqZUVGthABPKavhdUgNCWKWjskfNeMXjZVVZvogtIlQuoOsYFowa");
    bool dLJkAYRUewtqfLn = true;
    bool rrayUMarJ = false;
    int bZkCfvPH = -417932722;
    int lNOFgzpKB = -186682123;
    string ULvzWpRMhkwA = string("dDwsjicXQHZaJKEJEzPlMKkcHnocuvZnvXIZQQoDDriniQRCjTivlQNzSoJQIuGjlUSleBuNtSvRpzmMbkwzVdDbCknrEXtkjbTogWWmZOdfZXrBjjsWXXSfWDdLyGiyiSIaktgzetzvrdsIWVZxtrGKKztmaCKMLBPaLEKrtZfSacNOkrzfxQqLwSKtwQKfOrcLkjrQSikwrJjFaHDemXsDIIekFDztpfYWYtY");

    for (int lcVeuAZ = 977918386; lcVeuAZ > 0; lcVeuAZ--) {
        rrayUMarJ = ! DwrgeDXDc;
    }

    return UsdsolRnyG;
}

bool LqIrLXJFCzsTi::ksQjSIkkgquKlr(int EshenkZIYGJL, string DMjTThdlNWuK)
{
    double FJCDEbIEJv = 838103.2255548709;
    int CHQtaxtZSuIOhy = 1503174121;
    double pjNDPLYmvXorCFiK = 522530.4712793879;
    int AQwLPoycOk = 1960034598;
    string DxLKlRY = string("tmOWdXKzidUamzWQfiPuLzwqiKwZfAYlLFFIiCiYpqtKRazkCCYFwOaWBEjXykQdbcFYPoFDiIjvJLgQmNlQSnYhvvornnIgYooGnfBueavQgATmHVkSNvNcZPlHyqXzvVyqLdPGvznXCORJkvaJGHQbNNLpVmemJoqNrDCFYCxHqXgFXULfZxsmKqQzAuPIkwkppuPBDEaPMAVZDtPtEleYrejhNXRxM");
    string PlvHXSoHcCN = string("nlGqZpHMcVPaTOZzBXlsozREQuvoMCyKDeKXpQmoVhzUcsccFliGLlgvKlRhXIXntDPtpnuekxLWRNHJKFrllKjKUDGiiNnHFBWWZYvPfOdZxSjSBaYbdhmrwIBfBCdxncKMJnBNHzJVJRjuvincqBmSPivCInteKbC");
    string KjOVCVrIQjIR = string("cuhkplziMtXhGqSWuXTBwuxtMrfvXWJUHbkuhZZBIVRmVemHESFoGMmF");
    string sdrblujMEwVSDvX = string("WuLZQnSballYhQschivQhFARKhWULcnNjzfkByBZIDvYBGCTxCoXqFNoHqEoODSJDzpsKcQeGAiZBZYZvQGDjvjfeehBpWkHtKZjQzIssqZNqHpJrZkqHhoAijTfHDXaaXYGuCPuWIqkHQwlZHmwGksBxbqhTCuvqPqmnNEhZULjvbKkwnzGnLAkoqaTQplaDNvpYrymcfEwbKzrlLCqkWodDIMGeKdbyQymNjwSzVGUSuxghpw");
    double AviWHLcAvUzsQCw = 312950.6662889596;

    if (sdrblujMEwVSDvX == string("tmOWdXKzidUamzWQfiPuLzwqiKwZfAYlLFFIiCiYpqtKRazkCCYFwOaWBEjXykQdbcFYPoFDiIjvJLgQmNlQSnYhvvornnIgYooGnfBueavQgATmHVkSNvNcZPlHyqXzvVyqLdPGvznXCORJkvaJGHQbNNLpVmemJoqNrDCFYCxHqXgFXULfZxsmKqQzAuPIkwkppuPBDEaPMAVZDtPtEleYrejhNXRxM")) {
        for (int zguPVGiLDyPOADc = 1877788209; zguPVGiLDyPOADc > 0; zguPVGiLDyPOADc--) {
            pjNDPLYmvXorCFiK -= AviWHLcAvUzsQCw;
        }
    }

    for (int lJlEi = 175824125; lJlEi > 0; lJlEi--) {
        pjNDPLYmvXorCFiK /= FJCDEbIEJv;
    }

    if (KjOVCVrIQjIR != string("WuLZQnSballYhQschivQhFARKhWULcnNjzfkByBZIDvYBGCTxCoXqFNoHqEoODSJDzpsKcQeGAiZBZYZvQGDjvjfeehBpWkHtKZjQzIssqZNqHpJrZkqHhoAijTfHDXaaXYGuCPuWIqkHQwlZHmwGksBxbqhTCuvqPqmnNEhZULjvbKkwnzGnLAkoqaTQplaDNvpYrymcfEwbKzrlLCqkWodDIMGeKdbyQymNjwSzVGUSuxghpw")) {
        for (int xHUJQa = 2129351165; xHUJQa > 0; xHUJQa--) {
            AviWHLcAvUzsQCw += AviWHLcAvUzsQCw;
            sdrblujMEwVSDvX += DMjTThdlNWuK;
            PlvHXSoHcCN = PlvHXSoHcCN;
            sdrblujMEwVSDvX = DMjTThdlNWuK;
            KjOVCVrIQjIR = DMjTThdlNWuK;
        }
    }

    for (int FjRrdumf = 934780122; FjRrdumf > 0; FjRrdumf--) {
        PlvHXSoHcCN = DMjTThdlNWuK;
        sdrblujMEwVSDvX += sdrblujMEwVSDvX;
    }

    return true;
}

double LqIrLXJFCzsTi::OsjGze(bool UXxBlCT, bool ouiJXxUhN)
{
    bool mWkqzaYvPv = false;
    string hsiPFLxJxTtAf = string("DSbxCbCDxxSEGpafuJCzEPAQHywqrTPCKMoCnpEUzOiNhbcHElpRBVkScoEbLVqhCdhGXhosxHZItqpDtzuewjmmpREZhzIGUaIIeepxdRB");
    bool vFTcmhUESAJ = false;
    double rDwAFrSvcsJNmu = 6413.302438863569;

    for (int xOdBoePlrGOmga = 2027853784; xOdBoePlrGOmga > 0; xOdBoePlrGOmga--) {
        UXxBlCT = ouiJXxUhN;
    }

    if (ouiJXxUhN != false) {
        for (int otSic = 437273097; otSic > 0; otSic--) {
            rDwAFrSvcsJNmu += rDwAFrSvcsJNmu;
            mWkqzaYvPv = ! ouiJXxUhN;
            vFTcmhUESAJ = UXxBlCT;
            vFTcmhUESAJ = UXxBlCT;
            ouiJXxUhN = ! UXxBlCT;
        }
    }

    if (mWkqzaYvPv != true) {
        for (int WbntUTsrhqMB = 530050203; WbntUTsrhqMB > 0; WbntUTsrhqMB--) {
            continue;
        }
    }

    for (int IiRuyzzIthttE = 1336291945; IiRuyzzIthttE > 0; IiRuyzzIthttE--) {
        vFTcmhUESAJ = mWkqzaYvPv;
        hsiPFLxJxTtAf += hsiPFLxJxTtAf;
        rDwAFrSvcsJNmu += rDwAFrSvcsJNmu;
        ouiJXxUhN = ! ouiJXxUhN;
        ouiJXxUhN = ! mWkqzaYvPv;
    }

    return rDwAFrSvcsJNmu;
}

LqIrLXJFCzsTi::LqIrLXJFCzsTi()
{
    this->mXLJX(true, 1027721.3983330989, false, 681258.4741323863);
    this->kYQdIJ(291017.06462316896, string("FppdmmWoWcRfbCDrdiMkmebDWlueAlaEblVWNEebemLeuPwSPCVqKSYHmGQyQzfyXrnCFnlwPlmDfMtRZflKfxvnsTnrnxXDBRFFzHqjUGXCpgUcPOCxGasg"), -100335466);
    this->VgukxyCYLkxT(-169286.33422972137, true, -627237.5655578038);
    this->rVbrpmCKvoBTpBui();
    this->TzTFMIfUhZcLVK(false);
    this->IXiysNXHyNXhjfx(string("TWcWfpjUBKqtODnebqZwNDncqcJbSGoCvrkouPOfBXoHSNTDhXpZWjUCujfoWBcfpwxgdWuEvwcoIfJZaZSOKiyqDNmZfYLsCNcQzDxceDdCQZZJjzVybHxHEiYeWdukTuYEURxKWBWKYVsZLqoeXBixVZTttE"), false);
    this->pLLpfsswhR();
    this->rqbHIkwF();
    this->ksQjSIkkgquKlr(1422616732, string("skYwIREcdhVDS"));
    this->OsjGze(false, true);
}
