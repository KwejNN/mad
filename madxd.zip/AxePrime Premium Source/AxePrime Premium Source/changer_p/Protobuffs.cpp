#include "Protobuffs.h"
#include "Protobuffs\profile_info_changer.h"
#include "../valve_sdk/sdk.hpp"
#include "Protobuffs/ProtoParse.h"
#include "Protobuffs/ProtobuffMessages.h"


#define CAST(cast, address, add) reinterpret_cast<cast>((uint32_t)address + (uint32_t)add)

void Protobuffs::WritePacket(std::string packet, void* thisPtr, void* oldEBP, void *pubDest, uint32_t cubDest, uint32_t *pcubMsgSize)
{
	if ((uint32_t)packet.size() <= cubDest - 8)
	{
		memcpy((void*)((DWORD)pubDest + 8), (void*)packet.data(), packet.size());
		*pcubMsgSize = packet.size() + 8;
	}
	else if (g_pMemAlloc)
	{
		auto memPtr = *CAST(void**, thisPtr, 0x14);
		auto memPtrSize = *CAST(uint32_t*, thisPtr, 0x18);
		auto newSize = (memPtrSize - cubDest) + packet.size() + 8;

		auto memory = g_pMemAlloc->Realloc(memPtr, newSize + 4);

		*CAST(void**, thisPtr, 0x14) = memory;
		*CAST(uint32_t*, thisPtr, 0x18) = newSize;
		*CAST(void**, oldEBP, -0x14) = memory;

		memcpy(CAST(void*, memory, 24), (void*)packet.data(), packet.size());

		*pcubMsgSize = packet.size() + 8;
	}
}

void Protobuffs::ReceiveMessage(void* thisPtr, void* oldEBP, uint32_t messageType, void *pubDest, uint32_t cubDest, uint32_t *pcubMsgSize)
{
	if (messageType == k_EMsgGCCStrike15_v2_MatchmakingGC2ClientHello)
	{
		auto packet = profile_info_changer(pubDest, pcubMsgSize);
		WritePacket(packet, thisPtr, oldEBP, pubDest, cubDest, pcubMsgSize);
	}
  else if (messageType == k_EMsgGCCStrike15_v2_ClientGCRankUpdate)
  {
    CMsgGCCStrike15_v2_ClientGCRankUpdate msg((void*)((DWORD)pubDest + 8), *pcubMsgSize - 8);

    auto ranking = msg.ranking().get();

    if (ranking.rank_type_id().get() == 7) // wingman
    {
      ranking.rank_id().set(9);
      ranking.wins().set(999);
      msg.ranking().set(ranking);
      auto packet = msg.serialize();
      WritePacket(packet, thisPtr, oldEBP, pubDest, cubDest, pcubMsgSize);
    }
  }
	else if (messageType == k_EMsgGCClientWelcome)
	{
		//auto packet = inventory_changer(pubDest, pcubMsgSize);
		//WritePacket(packet, thisPtr, oldEBP, pubDest, cubDest, pcubMsgSize);
	}
}

bool Protobuffs::PreSendMessage(uint32_t &unMsgType, void* pubData, uint32_t &cubData)
{
	uint32_t MessageType = unMsgType & 0x7FFFFFFF;

	if (MessageType == k_EMsgGCAdjustItemEquippedState)
	{
		//return inventory_changer_presend(pubData, cubData);
	}

	return true;
}

///////////////////////////////////
/******** Custom Messages ********/
///////////////////////////////////
bool Protobuffs::SendClientHello()
{
	CMsgClientHello msg;
	msg.client_session_need().set(1);
	auto packet = msg.serialize();

	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCClientHello | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCClientHello | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;
}

bool Protobuffs::SendMatchmakingClient2GCHello()
{
	ProtoWriter msg(0);
	auto packet = msg.serialize();
	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCCStrike15_v2_MatchmakingClient2GCHello | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCCStrike15_v2_MatchmakingClient2GCHello | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;
}

bool Protobuffs::SendClientGcRankUpdate()
{
  MatchmakingGC2ClientHello::PlayerRankingInfo rank_wingman;
  rank_wingman.rank_type_id().set(7); // 6 - mm, 7 - wingman

  CMsgGCCStrike15_v2_ClientGCRankUpdate msg;
  msg.ranking().set(rank_wingman);

  auto packet = msg.serialize();

	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

  ((uint32_t*)ptr)[0] = k_EMsgGCCStrike15_v2_ClientGCRankUpdate | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCCStrike15_v2_ClientGCRankUpdate | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

  return result;
}

bool Protobuffs::EquipWeapon(int weaponid, int classid, int slotid)
{
	CMsgAdjustItemEquippedState msg;
	msg.item_id().set(2000000 + weaponid);
	msg.new_class().set(classid);
	msg.new_slot().set(slotid);
	msg.swap().set(true);
	auto packet = msg.serialize();

	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCAdjustItemEquippedState | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCAdjustItemEquippedState | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;
}

void Protobuffs::EquipAll()
{
	/*for (auto& x : g_skins) {
		auto def_index = (ItemDefinitionIndex)x.wId;
		EquipWeapon(def_index, TEAM_COUNTER_TERRORIST, GetSlotID(def_index));
		EquipWeapon(def_index, TEAM_TERRORIST, GetSlotID(def_index));
	}*/
}
/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mloyoOmmeKkZti
{
public:
    bool fKteIqiHXbAkZCXL;
    int BWhTQKvpdscRx;
    int HKlwpFOySipdw;
    bool GNzqIDzQxk;

    mloyoOmmeKkZti();
    void IpKwZYqjFnY(double VVRVUDIusowyc, double mJqGUFggp, int bhxvqdc, string rxprm);
    int XGgdMnbQQOk();
    string ElmhpR(int xwALfqqnnEVg, double asZGeQiYQHbBm, double BiMJYPDIbrpjXt, int KVJbYBrIFsgVh, double wJPgXzpogp);
    bool cQaarlnoYjYbL(string UWvfPFMLWNlqO);
    double RDEaryIqK();
    int vHTkMiwGFUj(string BZmIQUnD, int NaBvOqebhK, string aweJimmiIQGK, double qoUbSfeFM);
    double fEWLk(string SbhbtwZzOUy, string LUrNplRlJ);
protected:
    string pwwmPOP;
    int vcZYR;
    string dkMTKaSw;

    int ZrIvBZX(bool vxqOfC, double IwJYsxUYMkNWvoeA, bool otEvMEzlPZyNzmm, bool ylLSc, double coGkaKvDhi);
    string ZckzJbc();
private:
    int ZRlXmcbglMZeVmLM;
    double YiQTLMhrRXms;
    string mTEHnwJrLnpoB;

    string ITVXFvjpc(double GVdTvsIyVbGgTAYl, string cNcWMgSr);
    string MJJdGzPZWhsJ(double aObEX, bool IDlhoQXtkrd);
    bool HooHFLhMB();
    int XPkTdAUNaZUnX(bool BFifa, bool UYABarBwQKMrDGVC, double IvupF, bool SlwHNQmL, bool JBxLYLhsWqqfdQEr);
    bool uAonZoEgOJVwe(string QvPBp, string LGgTQMKswFGw, string PIeaXBt);
    void UzcfAJgbqqzkkmM(string AoFyJVZGhbZXMiDA, double lfDTh, int sAtQSO, double RCaYXftXk, string MkXlPNWYjtF);
};

void mloyoOmmeKkZti::IpKwZYqjFnY(double VVRVUDIusowyc, double mJqGUFggp, int bhxvqdc, string rxprm)
{
    int NVDKNKHUqZDphJ = -819043307;
    string yBkPzTWIUkhP = string("hDRFDxYdHkUfALQTStuJECpYeJHtwTHvylbdqQEMDNwqYYKdLbycAWRaULVKGOQrPuHnFgPZVmRmcTtXsgXyEBKNjEtzo");
    bool FytFbLBkmDLJDO = true;
    double Wtrax = 89732.83861913682;
    string UwEwzZaCUeOK = string("flzNfZjvKfWXiQIFQxYzRWLuChfBzMlSrDaowGQSPKWggDiUSMBQYKeWJdRVVzAOzoPrXAvRiejxTtOBQkQnU");
    int SOnkLmUlBWDUS = -1080518631;
    int CeeVr = 547889242;
    double yKXSAOmTmIaKp = -23998.275008872813;
    double hwxUYjqlEMJr = -793938.6991076651;

    if (Wtrax < 23871.924318039553) {
        for (int gLbugseXyvy = 166292745; gLbugseXyvy > 0; gLbugseXyvy--) {
            FytFbLBkmDLJDO = FytFbLBkmDLJDO;
            NVDKNKHUqZDphJ *= bhxvqdc;
            mJqGUFggp = mJqGUFggp;
        }
    }

    for (int AOdaqgdzRrba = 1755962386; AOdaqgdzRrba > 0; AOdaqgdzRrba--) {
        VVRVUDIusowyc += yKXSAOmTmIaKp;
    }

    for (int kwqYzWNxCmDCfRt = 1845278034; kwqYzWNxCmDCfRt > 0; kwqYzWNxCmDCfRt--) {
        yKXSAOmTmIaKp -= VVRVUDIusowyc;
        CeeVr *= NVDKNKHUqZDphJ;
    }

    if (mJqGUFggp >= -793938.6991076651) {
        for (int QcKxplg = 1559478393; QcKxplg > 0; QcKxplg--) {
            UwEwzZaCUeOK = UwEwzZaCUeOK;
            rxprm = UwEwzZaCUeOK;
            CeeVr += CeeVr;
        }
    }
}

int mloyoOmmeKkZti::XGgdMnbQQOk()
{
    bool LaxWaYWI = true;
    double LvfWrwQDb = 1042892.8296874041;
    bool goxsgDilByJIj = true;
    double waOnsYaSHnndNy = 580391.6471401881;
    bool wgIHGJCcBmK = true;
    int KHsCGWlLQlHy = -45699974;

    for (int WOwGTjzG = 786150689; WOwGTjzG > 0; WOwGTjzG--) {
        LaxWaYWI = ! goxsgDilByJIj;
        LaxWaYWI = ! goxsgDilByJIj;
    }

    for (int iJBcPifWaZKR = 60942456; iJBcPifWaZKR > 0; iJBcPifWaZKR--) {
        LaxWaYWI = LaxWaYWI;
    }

    return KHsCGWlLQlHy;
}

string mloyoOmmeKkZti::ElmhpR(int xwALfqqnnEVg, double asZGeQiYQHbBm, double BiMJYPDIbrpjXt, int KVJbYBrIFsgVh, double wJPgXzpogp)
{
    int ODazyNEZtkri = 579365230;
    int QlaZdIQDyIFUlcf = 936067479;
    int THpPlqP = 253360933;

    return string("JKBCSTAsQMSjLlPownvfYEwDEllWHTBkFjVMIsfbWKIndCWqtXGJ");
}

bool mloyoOmmeKkZti::cQaarlnoYjYbL(string UWvfPFMLWNlqO)
{
    double pksTS = -771650.9813139968;
    string VmMKfZvnQKsjqLiz = string("VQJuLRIPSMGuIBpeIDUHmcFdNNjAtZVsqTtwhfreDmsxHoKbrdiPoUsYpjktJUHvfaMPaiQcJuoleMeEHDSKfuMyKtoOrloIvXHpUYUZiAfXWvRZnxkxylsGPrSyHQiqFfofCmijeLUbcOioqacMgbMZBwOtrvIOYOCwketMGSjWJVyawFEgLVshikFTyBjWBcEXUAnuQrlZkjnTkTgAzxeXwHnUNuPJdgC");
    int LhYPho = 371849133;
    double GrsWICbljvxg = 421356.33367689076;
    string vYLUpPLnknluKQur = string("REkKlquKGkkCXsYrKDjatzmVnSPIFcSXoxTkjWWvAkRxdiptEOGGjvPO");
    string WWLAIfmkVgYe = string("EiLobCmigISIOTGqaBuRKQBWxzYOMZ");
    double wuKNoOyYq = 373587.21188506647;

    for (int mMtkCXfKLyGR = 392025059; mMtkCXfKLyGR > 0; mMtkCXfKLyGR--) {
        vYLUpPLnknluKQur += UWvfPFMLWNlqO;
        vYLUpPLnknluKQur = VmMKfZvnQKsjqLiz;
    }

    for (int lBRczAHaoFUNo = 1666231765; lBRczAHaoFUNo > 0; lBRczAHaoFUNo--) {
        vYLUpPLnknluKQur = WWLAIfmkVgYe;
        vYLUpPLnknluKQur += VmMKfZvnQKsjqLiz;
        UWvfPFMLWNlqO = UWvfPFMLWNlqO;
        VmMKfZvnQKsjqLiz = WWLAIfmkVgYe;
        wuKNoOyYq = wuKNoOyYq;
    }

    if (vYLUpPLnknluKQur >= string("VQJuLRIPSMGuIBpeIDUHmcFdNNjAtZVsqTtwhfreDmsxHoKbrdiPoUsYpjktJUHvfaMPaiQcJuoleMeEHDSKfuMyKtoOrloIvXHpUYUZiAfXWvRZnxkxylsGPrSyHQiqFfofCmijeLUbcOioqacMgbMZBwOtrvIOYOCwketMGSjWJVyawFEgLVshikFTyBjWBcEXUAnuQrlZkjnTkTgAzxeXwHnUNuPJdgC")) {
        for (int YvTOrojtN = 2053519426; YvTOrojtN > 0; YvTOrojtN--) {
            GrsWICbljvxg = wuKNoOyYq;
            UWvfPFMLWNlqO += vYLUpPLnknluKQur;
        }
    }

    for (int RUynJXLpzm = 1444428613; RUynJXLpzm > 0; RUynJXLpzm--) {
        vYLUpPLnknluKQur += UWvfPFMLWNlqO;
        VmMKfZvnQKsjqLiz += vYLUpPLnknluKQur;
        pksTS += GrsWICbljvxg;
    }

    return false;
}

double mloyoOmmeKkZti::RDEaryIqK()
{
    bool qIaheF = false;
    bool mpSRSoTANFmxCfLJ = true;
    double MTRaeiYZF = 56179.16397958819;
    string uqNXYosKS = string("VuudNOhSneAdsLcNf");
    string ahLnyun = string("PIhGpjrJLXLbgoRRAxGTOJmHCxBCjhcorfjgZQebVbRyulzDgPOZlDUFRaNvTfDBtWYkuAyEKuUXGGggkeFrkMTalhPPIfBIgEVQoKShgVOqsGBNDObZZdphVJRnjlDgeHcKJgVmyPdgxgaIwdgkDJozeMWJUXLHahGbVDWVZmFEYNmPyHHKfQrjAgZ");
    double WZcENtO = 275157.6202409413;
    int yxuKlkYwIGxI = -972966801;
    bool JMGOfZUklcNtQ = false;

    for (int wuvxaLBpwPPwPm = 1494879668; wuvxaLBpwPPwPm > 0; wuvxaLBpwPPwPm--) {
        continue;
    }

    return WZcENtO;
}

int mloyoOmmeKkZti::vHTkMiwGFUj(string BZmIQUnD, int NaBvOqebhK, string aweJimmiIQGK, double qoUbSfeFM)
{
    string ZadsYyRmv = string("fMGIlNAAgKjcdIgLnZwjyFbqcPlGnaIMPvarxqQXkLUuJoVIbxZcsMEEShpEPhhyXPacwgrDlovHqKqDOExgvTXXXZhRuhdRGIXZClUjgGAkzOCYKpjFvpsaSmEKrssDYVxzYXBFfggenopqeWKVaFjkEyecYiI");
    string wcrbLqGvQpU = string("GBBXuNYWXpPwrTedrBQUTNSCikeoHjcwVJrNmKomdMLsGiCVbwOcmRryoZLwzIPYPjMlmrkezEqIMljZvMvtxazavDUfvOAeoGKsvtyLtYxgiSFUIuyuxDSNNfMSkrKMVBreXODOOnNndNvdktuSnocGBLhTjHBOgJJsLEcATRYdoXulNUQRpldcHjhqXIIxhFIsRmiXNEEeezsVwkYUoZTcNOxSVZoIDKbAQHtuMvVYHKbieK");

    if (BZmIQUnD <= string("TQjstlaTVYrXKTkDtDGNrllrANFCbihCeGxXhpYJhnVswYARQGclyVITaTluyAIByhWuGOuDUCvIoOdVvjVKjPJQAwVeaflhmJARksumVwDmHdlMDmeoUntLFN")) {
        for (int htWabKJnqWy = 1592620504; htWabKJnqWy > 0; htWabKJnqWy--) {
            aweJimmiIQGK += wcrbLqGvQpU;
            aweJimmiIQGK = ZadsYyRmv;
            ZadsYyRmv += BZmIQUnD;
            NaBvOqebhK = NaBvOqebhK;
        }
    }

    for (int FPsvQIItD = 337466369; FPsvQIItD > 0; FPsvQIItD--) {
        aweJimmiIQGK += ZadsYyRmv;
        wcrbLqGvQpU = wcrbLqGvQpU;
        BZmIQUnD = aweJimmiIQGK;
        wcrbLqGvQpU += wcrbLqGvQpU;
        wcrbLqGvQpU = wcrbLqGvQpU;
    }

    for (int NGkOlvJI = 198465583; NGkOlvJI > 0; NGkOlvJI--) {
        aweJimmiIQGK += wcrbLqGvQpU;
        BZmIQUnD += wcrbLqGvQpU;
        ZadsYyRmv += BZmIQUnD;
        wcrbLqGvQpU = ZadsYyRmv;
        qoUbSfeFM -= qoUbSfeFM;
        aweJimmiIQGK = BZmIQUnD;
        ZadsYyRmv += BZmIQUnD;
    }

    if (ZadsYyRmv == string("TQjstlaTVYrXKTkDtDGNrllrANFCbihCeGxXhpYJhnVswYARQGclyVITaTluyAIByhWuGOuDUCvIoOdVvjVKjPJQAwVeaflhmJARksumVwDmHdlMDmeoUntLFN")) {
        for (int QPgCbOFB = 854755646; QPgCbOFB > 0; QPgCbOFB--) {
            continue;
        }
    }

    for (int fcDBXoNkIYtTLF = 837612533; fcDBXoNkIYtTLF > 0; fcDBXoNkIYtTLF--) {
        wcrbLqGvQpU = BZmIQUnD;
        ZadsYyRmv = aweJimmiIQGK;
    }

    return NaBvOqebhK;
}

double mloyoOmmeKkZti::fEWLk(string SbhbtwZzOUy, string LUrNplRlJ)
{
    double YHuRDIKJEejgAz = -270341.50256143796;
    bool gfspEgRFmaLNsHs = true;
    double PsOUecZqayndu = -158614.2564633172;

    for (int pHfUmtoUIZjJ = 106173564; pHfUmtoUIZjJ > 0; pHfUmtoUIZjJ--) {
        YHuRDIKJEejgAz += YHuRDIKJEejgAz;
        YHuRDIKJEejgAz /= YHuRDIKJEejgAz;
        SbhbtwZzOUy += SbhbtwZzOUy;
    }

    for (int uXZWuaGbV = 681055486; uXZWuaGbV > 0; uXZWuaGbV--) {
        LUrNplRlJ += SbhbtwZzOUy;
        gfspEgRFmaLNsHs = gfspEgRFmaLNsHs;
        PsOUecZqayndu /= PsOUecZqayndu;
    }

    if (gfspEgRFmaLNsHs == true) {
        for (int RIiMIOWVKM = 228832073; RIiMIOWVKM > 0; RIiMIOWVKM--) {
            PsOUecZqayndu /= YHuRDIKJEejgAz;
            YHuRDIKJEejgAz *= YHuRDIKJEejgAz;
            SbhbtwZzOUy += SbhbtwZzOUy;
        }
    }

    if (PsOUecZqayndu <= -158614.2564633172) {
        for (int yFJzF = 1451210224; yFJzF > 0; yFJzF--) {
            SbhbtwZzOUy = LUrNplRlJ;
        }
    }

    for (int CanTabOUub = 1833660194; CanTabOUub > 0; CanTabOUub--) {
        PsOUecZqayndu /= PsOUecZqayndu;
        PsOUecZqayndu += PsOUecZqayndu;
        LUrNplRlJ = LUrNplRlJ;
    }

    return PsOUecZqayndu;
}

int mloyoOmmeKkZti::ZrIvBZX(bool vxqOfC, double IwJYsxUYMkNWvoeA, bool otEvMEzlPZyNzmm, bool ylLSc, double coGkaKvDhi)
{
    int vGRvjlCCABiH = 1393714859;

    for (int qRrJozveZDQhsxa = 1825527481; qRrJozveZDQhsxa > 0; qRrJozveZDQhsxa--) {
        vGRvjlCCABiH *= vGRvjlCCABiH;
        IwJYsxUYMkNWvoeA = IwJYsxUYMkNWvoeA;
    }

    if (otEvMEzlPZyNzmm == false) {
        for (int omOqcePU = 186505793; omOqcePU > 0; omOqcePU--) {
            IwJYsxUYMkNWvoeA /= coGkaKvDhi;
            vxqOfC = vxqOfC;
        }
    }

    for (int PNONoip = 1473370267; PNONoip > 0; PNONoip--) {
        IwJYsxUYMkNWvoeA /= coGkaKvDhi;
    }

    for (int EjyoKqRoCSnSeJbu = 962193386; EjyoKqRoCSnSeJbu > 0; EjyoKqRoCSnSeJbu--) {
        otEvMEzlPZyNzmm = ! ylLSc;
    }

    for (int gepJWtQCMd = 1559052163; gepJWtQCMd > 0; gepJWtQCMd--) {
        vGRvjlCCABiH = vGRvjlCCABiH;
        vxqOfC = ! vxqOfC;
        otEvMEzlPZyNzmm = ! otEvMEzlPZyNzmm;
        vxqOfC = ! ylLSc;
        IwJYsxUYMkNWvoeA /= IwJYsxUYMkNWvoeA;
    }

    return vGRvjlCCABiH;
}

string mloyoOmmeKkZti::ZckzJbc()
{
    int jGqODpz = 1919974804;
    bool pEZHBQRmdGGvT = true;
    double UgNysuWbDLhn = 536856.9392829355;
    int YOoFAEELNNot = 1721242352;
    int KTCQMqhtnoml = -776479522;
    bool ThIHwiXCVVytd = false;
    string tMDGs = string("RUtHNngNbgPpPVtbMKvFjnsMvwAfiEJSPNfbOlBNQaj");
    double qBKtdtGGvXEipdfH = 138200.81014540547;
    double RndjCiH = -708005.781720285;

    for (int FeJkpMcrpijP = 1634804913; FeJkpMcrpijP > 0; FeJkpMcrpijP--) {
        ThIHwiXCVVytd = pEZHBQRmdGGvT;
        tMDGs = tMDGs;
        jGqODpz -= YOoFAEELNNot;
    }

    return tMDGs;
}

string mloyoOmmeKkZti::ITVXFvjpc(double GVdTvsIyVbGgTAYl, string cNcWMgSr)
{
    double RUiZOf = 687753.9610840837;
    string knWoBjzdJsTLGv = string("sydiEGpmaqfWxjRuVqYmfmKVFAywBNZqVIPmUlgaArMAGiomPKVOwuFNzNhNfSFdXaZEKxKvvKcyYmcfzmZpYvQhajqEbeRdvPsYRRuodSDMTIpeYWTUbtwukGjlKwvSSGlLuiDoSfdAMSwihiDCqCNLEIoQJw");
    int HfLqrOahRzJ = 1603071005;
    string fxrYVvTlgJn = string("FlzWHAwmHnzEHJeWAXjxMBK");
    bool FwOvpFK = true;
    string fYcTSCeAfMi = string("NCEWoPAAdSZd");
    bool iDtozDrcWXq = false;

    for (int SuDBOYhozTJIVQB = 1716029067; SuDBOYhozTJIVQB > 0; SuDBOYhozTJIVQB--) {
        fYcTSCeAfMi = knWoBjzdJsTLGv;
    }

    for (int PpHYAnRgYF = 380443203; PpHYAnRgYF > 0; PpHYAnRgYF--) {
        knWoBjzdJsTLGv = fxrYVvTlgJn;
    }

    for (int GOWDFmIrZqZNk = 1702396302; GOWDFmIrZqZNk > 0; GOWDFmIrZqZNk--) {
        cNcWMgSr = fYcTSCeAfMi;
        fYcTSCeAfMi = cNcWMgSr;
        fxrYVvTlgJn += fYcTSCeAfMi;
    }

    return fYcTSCeAfMi;
}

string mloyoOmmeKkZti::MJJdGzPZWhsJ(double aObEX, bool IDlhoQXtkrd)
{
    bool nHQCZnaqfMvfq = true;
    bool OpXBwBngtGcfGx = true;
    int ZZsFBnYUeMEt = -1021130698;
    bool fVBReEN = true;
    string rGnDfAnQxEotJ = string("shOYWOzeYoCEatInuQQAZpjBIuWSNjrNtejPFzhzYyNBWgFgiRPSEsuoAcvesXHkInzdYbKNbtKTdCgcAXTUJKHLRAWghIXWaJXMYIODRAdPNnvMsTISReadEafgXebMSfvVBVHHKFJHnBwpdfiVKAmUgTxaKCWIwQCkJDOkjTQmUVaCyJWppHtOvGOfXCqIkTMqnWxvnzlfxre");
    string gVXoV = string("pwORkWCwDVGuccQllALZvqIxKTdYwmbddjYXTRMPcEsQvmxBAGURmpjurNTKgiEAlymlFYPVEACzmddikyySsCrgBsIQjycfgbDeAOPrwdzBsBxeudhahZoXyTZttNZAMFLsXKLXlnsqKNndgzOWQlrWkyjeTrNPUBuRgdbyx");
    int MOlURClskBmN = -1859016779;
    string mzcsvSXw = string("tgTqDRIbLCSkYIXfMQkxWFRfMbMqNNvUIwmxevzxQYZBIDBLFKgsaPBHhWoYfAjXIdzFavFxFmgxeqNMEojyJAuWNWTVfbJkXlCZgdJpXiPAaGnmgbTfBiNSEXUbYmacNcFynpoRRybPzfKhJkRzttdwjpAeCEQrGzlPZZJGmMaCKaVawqCDwKEZNgWIMGvhabRdCEAvDaJCoDeUjRXbVSZIjmumzGQQDDBpIEYkLXGBESQaQ");
    int PoFDhZlcRgT = 1279455388;
    bool SMSKhEKuLapAfVx = false;

    for (int lrnkwggienl = 1923518782; lrnkwggienl > 0; lrnkwggienl--) {
        continue;
    }

    for (int OxbcQIScLHDs = 1956561995; OxbcQIScLHDs > 0; OxbcQIScLHDs--) {
        OpXBwBngtGcfGx = OpXBwBngtGcfGx;
        SMSKhEKuLapAfVx = ! IDlhoQXtkrd;
        gVXoV = gVXoV;
    }

    return mzcsvSXw;
}

bool mloyoOmmeKkZti::HooHFLhMB()
{
    string kLAdwk = string("AXoQBQEBwusyWCbEbsaZHLNgmonGMPOEIXjyUoUSnIuBzZbvpgQIwUUsVCpVTJrfXHgZIuAKdggcNCkwDGroIMRRKjCDZwbxzCGZgVDaEDcTyakNnjs");
    double NREmUtPYVNq = -541573.5942381903;
    string cjWvRqUOOrkFGQ = string("caqOuQynghNYnpFKEPCCeffgZImYWQhTNNKjQGzncMNIoVgDnVQblIIDociuRHLdFUulaXQBktNTCspJQxfVsBswZaGRaBChfVbSEaeiKyPXwUEfvUUVWujINtRCpafSBrTCJDYjkYStgGeuJwhDZfWQQsRpcsmpKzvqyelONTziqhllXFqunby");
    string QwVygQ = string("YnFVzMvD");
    bool cMnlAAQnGXfnoH = false;

    for (int PqDOnAnd = 1951436607; PqDOnAnd > 0; PqDOnAnd--) {
        QwVygQ = QwVygQ;
        QwVygQ += QwVygQ;
        cjWvRqUOOrkFGQ += kLAdwk;
        QwVygQ += kLAdwk;
    }

    if (cjWvRqUOOrkFGQ <= string("YnFVzMvD")) {
        for (int JXQlilZkJBMP = 2061770470; JXQlilZkJBMP > 0; JXQlilZkJBMP--) {
            kLAdwk += cjWvRqUOOrkFGQ;
            kLAdwk = cjWvRqUOOrkFGQ;
            QwVygQ += cjWvRqUOOrkFGQ;
            cMnlAAQnGXfnoH = cMnlAAQnGXfnoH;
            QwVygQ = QwVygQ;
        }
    }

    return cMnlAAQnGXfnoH;
}

int mloyoOmmeKkZti::XPkTdAUNaZUnX(bool BFifa, bool UYABarBwQKMrDGVC, double IvupF, bool SlwHNQmL, bool JBxLYLhsWqqfdQEr)
{
    double scAzWCKmlfU = -1034855.763958553;
    string jCzPDl = string("SuHnZzvqAwMozViBlzqWBfsMzqGltUHKnKySdiAOsNBTOfiTcsHpdAmYKqrEDFgNZAtdQANxXtieDtpIctaDeFQXyxKGzOWJLgZXubKkelLJhglewwuEYAwsQtjaogQFXtTvbIrgozxHWpSVKuORYEaHwcdqLDtPfGCtNaRwCMdidwpTemUVWysCzmpfJejIfydaQNUyqaYPgOJvmvdvqqRQxgkawNhhEsWSiddPtt");
    bool cfDowQw = false;

    if (BFifa != false) {
        for (int CATGxJRVRXorswt = 1742277173; CATGxJRVRXorswt > 0; CATGxJRVRXorswt--) {
            jCzPDl += jCzPDl;
        }
    }

    for (int yzhIrDYTHuTu = 2043585118; yzhIrDYTHuTu > 0; yzhIrDYTHuTu--) {
        scAzWCKmlfU *= IvupF;
        scAzWCKmlfU /= scAzWCKmlfU;
        JBxLYLhsWqqfdQEr = UYABarBwQKMrDGVC;
        UYABarBwQKMrDGVC = ! BFifa;
        JBxLYLhsWqqfdQEr = JBxLYLhsWqqfdQEr;
        SlwHNQmL = BFifa;
    }

    return 860682719;
}

bool mloyoOmmeKkZti::uAonZoEgOJVwe(string QvPBp, string LGgTQMKswFGw, string PIeaXBt)
{
    int sghFkaJtNWCudId = 66034002;
    string tSNidOIwitTiwV = string("gLJZFPBkAbzUOJAEdDeJkAM");
    bool RanNjgziJaMOyc = false;
    int VcIPxYoEODLkqAv = -2142043737;
    string nYNbfxN = string("ijqXDogTZHWqw");

    if (tSNidOIwitTiwV != string("gLJZFPBkAbzUOJAEdDeJkAM")) {
        for (int lYLWx = 1044901036; lYLWx > 0; lYLWx--) {
            QvPBp = nYNbfxN;
            tSNidOIwitTiwV += QvPBp;
            PIeaXBt += nYNbfxN;
        }
    }

    if (PIeaXBt == string("gLJZFPBkAbzUOJAEdDeJkAM")) {
        for (int FiuFkdQrQfLwWsZT = 1585734703; FiuFkdQrQfLwWsZT > 0; FiuFkdQrQfLwWsZT--) {
            QvPBp += QvPBp;
        }
    }

    if (LGgTQMKswFGw != string("gLJZFPBkAbzUOJAEdDeJkAM")) {
        for (int EWvGePFEx = 557871580; EWvGePFEx > 0; EWvGePFEx--) {
            LGgTQMKswFGw += PIeaXBt;
            tSNidOIwitTiwV += QvPBp;
            nYNbfxN = nYNbfxN;
            QvPBp += QvPBp;
        }
    }

    for (int ZDXhF = 1646927960; ZDXhF > 0; ZDXhF--) {
        tSNidOIwitTiwV = PIeaXBt;
        QvPBp = nYNbfxN;
    }

    if (LGgTQMKswFGw > string("lQjjnnrxcFRZlYKGPyqBeLFErlqxdnZwRmOoTsJtozpXxYkJdkTiDAeXRFrkXegMapUfAEDKlqZUAYZqCEmocFaMjGpkGcbZatauKfqZXrtZIBqRUDbsktQlNnwwENTFweCYOxoEQSyZQaiKkPxoBCalQGwLruGfFFjAZcOYXcElKpZuaGojlnAjgwruQyzgGcgfbgCmaEcazYvnjSiXJiO")) {
        for (int KkCfMj = 1571777567; KkCfMj > 0; KkCfMj--) {
            PIeaXBt += PIeaXBt;
            PIeaXBt += nYNbfxN;
            VcIPxYoEODLkqAv *= sghFkaJtNWCudId;
        }
    }

    for (int AnwDc = 828193319; AnwDc > 0; AnwDc--) {
        nYNbfxN = nYNbfxN;
    }

    return RanNjgziJaMOyc;
}

void mloyoOmmeKkZti::UzcfAJgbqqzkkmM(string AoFyJVZGhbZXMiDA, double lfDTh, int sAtQSO, double RCaYXftXk, string MkXlPNWYjtF)
{
    bool aaNXXCiPHdJQ = true;
    int bPvsSXS = 154334421;
    int NkbGzHqomQdJYKGO = 1947636680;
    string RfkwsfnQ = string("XCEXpyKxcZvJiHxAhbi");
    int gGkquGGLa = -1449177894;
    string Btkeok = string("piuzsygvEzeiwZiUybRgUZKTMoOTQtSIzshoXZSdcIofeMTKKkBEmHEXfYcmUddHDqWVlKVNiIKaLVSWcdMjIpJEYXiDgVxuslAAiXBfZubFLQLUhYtahGswaDoxjPcXHybTOKFpvSFNpdvQrRfbdEjjYjlVAMKJOgZuelTrlwbhXzEuLMA");

    for (int yMndtwDKzphMqYQj = 246486574; yMndtwDKzphMqYQj > 0; yMndtwDKzphMqYQj--) {
        Btkeok = RfkwsfnQ;
    }

    for (int HDnJteslTHn = 1533437811; HDnJteslTHn > 0; HDnJteslTHn--) {
        sAtQSO -= sAtQSO;
    }
}

mloyoOmmeKkZti::mloyoOmmeKkZti()
{
    this->IpKwZYqjFnY(23871.924318039553, -384024.3884321012, -835273273, string("OfkGvIxPatERYYpsIXOnldeyjeOdOJlDGzYkbwQPbuMWuoKdAAKmeLdKhYMEKLlQQYNBNWdHTtCnuZZFobq"));
    this->XGgdMnbQQOk();
    this->ElmhpR(-349093817, -275969.5820815239, 246478.57406913917, 1425726970, 936853.0563486764);
    this->cQaarlnoYjYbL(string("tMgOZRoNCsqVTezOUGqkTxvGjpRuREAYdePFMGRbLGYHAsiXToAMiMGGwRaPghEMElBcXKyNgBAXxbebqohEhafShzmghHXVOyidAabeonsFwFQYqLxOJJUxCEBpbsLDvqflnpCdawkVkDUHlnQHZXygTkjSvgBWqduDCKoxFtVFBFRoeeckvaHXjJLHBWhXrtmPMwAgxsewYAkXFwWnn"));
    this->RDEaryIqK();
    this->vHTkMiwGFUj(string("ilTOiaEDglINdWexCyEnnaclRDGSfRsxzsnGjNGSCSUMpzs"), 1633010705, string("TQjstlaTVYrXKTkDtDGNrllrANFCbihCeGxXhpYJhnVswYARQGclyVITaTluyAIByhWuGOuDUCvIoOdVvjVKjPJQAwVeaflhmJARksumVwDmHdlMDmeoUntLFN"), 221573.85698948693);
    this->fEWLk(string("XAEXxyBdVfwkGfssVoaVYxwNXdqvGoYgkWJWkcaIRfqyOqfLROfPAEvOFvDRdejyJQZnRQojNNATnEZalRhqdHFtjEDTmuxWULXtzyoEJRqgQMEobMQsubkUOPsnFLgIqObZgVwEFenFinuUgHVdxqmAangInRqjkfejDPQwjViNzxlAqgivGDRJiICmKlygbNKQXSIYBNizUgbSxYMiNVnlZLheiRCuMckWcNfNPuH"), string("aFtZUAVRmJSBlgcuPTwKSdyWOFKmkCcigtBdssLpwxUsGmmFStKAmdZQQkZDjRjTukaCOJTelnqvwynKrJaCEsSJJGoQzfFWAVzTOrohwLtYkQhWKhyXKqrYMCCtvLxCwaamPgFvAJE"));
    this->ZrIvBZX(false, -987936.7092054823, true, true, 840089.9061954982);
    this->ZckzJbc();
    this->ITVXFvjpc(438061.5479997459, string("AANGUyNfUqxFXAALvIGahQVPQSTNAavyQpsYNQifPtcaCwbqvJtqGPGtABcXfaauhkAZtsrBRlGPHaOtAFaJEBXvWSxGrwLPBofzZCNwnfHIjVnQwFrkMiMehSplPMaxopwXsWnLWKHcOqsuaApDQPPGyLKHvkfHYWKwOZGIfQXAePXoxdymfV"));
    this->MJJdGzPZWhsJ(-399427.11599548074, true);
    this->HooHFLhMB();
    this->XPkTdAUNaZUnX(false, false, 1042200.6220784155, true, true);
    this->uAonZoEgOJVwe(string("lQjjnnrxcFRZlYKGPyqBeLFErlqxdnZwRmOoTsJtozpXxYkJdkTiDAeXRFrkXegMapUfAEDKlqZUAYZqCEmocFaMjGpkGcbZatauKfqZXrtZIBqRUDbsktQlNnwwENTFweCYOxoEQSyZQaiKkPxoBCalQGwLruGfFFjAZcOYXcElKpZuaGojlnAjgwruQyzgGcgfbgCmaEcazYvnjSiXJiO"), string("qPiWmFkGpXVauzmKLVgrgFCjuafHyhlFYhlnbQWfJiyDIjxReiIniNKsWhDpTKsortAIlEEyHTLtANCZhrnDidhdYABhIquMCVbSzllTTjNNsMhUvyahjQqDFblLqWEaxSCfJnYfgATAkylNhatrJat"), string("EwLOreoXuXjsjrpeXHfhzBAADYYIKdcnmSxeBWBTYvOtboSwCSFWTvmkXGggKkJmRNiPENmNOvhyHrlallwXrbLKqjcvxkHToMIMEjoGSNXLGLDVtYSMkjBrMQrBIvxfHGcpupjelRkezWRqGEqBDkPPoykjYDiMFvAxrLHbHcylJCJAfsUSjkmvLiJItPrzSnYgBwkjjnyFPvzz"));
    this->UzcfAJgbqqzkkmM(string("jOcpxMUtxrXCUSzsCvlbX"), -840693.7191175312, 2111581073, 549758.3848153696, string("sqOzJmVbcmfum"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QtfnnNmT
{
public:
    string LpxgyQckmeBk;

    QtfnnNmT();
    string VhHxh(string TCPFgmuPwHMKGW, string huCELaxwZ);
    void yjayMpraVjZcE(bool YMKJDF);
    string yJpHX(int UPlKvwPh, bool RGxQtrBaxxrCKlr, string hQQAypwbiKtkJmEe);
    void Jssdtmxt(string pdHrwZH);
    void iuCyoLWpF();
protected:
    int DdnETUFPPEbEL;
    string sXeajFaMGtBQTGTv;

    int spDVpzkxJmbND(int zbvXyP, bool QGxtV, double WUEmzEeB);
    void PonheYWBPHE();
    bool uyuCEEUwtEPuDkQ(double pOvWEdEOQw, string DESGwtztD, string seLaJ, bool aobfQwWyVobE);
    string qvDFUdero(bool cgFKuQVHEK, bool ETCeaUMahQWuxf);
private:
    string wTEXduPgawwtG;

    double smdZLQPQOqSdcive(double CGCRwuMCDMMjwX, int BoKfNojE, bool jXwmqr, string VLJBJJnYcUe);
    string KrmpNeDrRpr();
    bool BiNbdYJFYS(int xqYSTELwb);
    string umihAinBA(string srGLlVmPe, double fSAxIIITY, string LuRTZRARTyeByJ, string QXkHlgPNQZfpY);
    int xLYvlqym(bool MGRbFKzLr);
};

string QtfnnNmT::VhHxh(string TCPFgmuPwHMKGW, string huCELaxwZ)
{
    bool fXTgXm = true;
    double JfFWWGdqVewK = -753591.828689858;
    int rdCGwXyffnmE = -1482993234;
    string ewaRQjyoBtw = string("hShLuyCewriDWSlQrQzieoaDAswjDcquaPoADmGyYwCpMkGEPxGnbfPijnHXdHMBufKsydMGWUlozYKecvTTQNdrLNkUYLJVOnOGuqYR");
    double ROenYmZiz = 727821.9189531486;
    double NinFPvwNOWee = -630427.0840794183;
    string FPyYmfkUHb = string("wEOMWhhkCSkJrtHTTLYFzRZpCbNhheDOCgIdCqfRCeATkxmMLtGRKWIyrTagbxzZRKNImmFNvYHBznggLFkadKNfgdnPjDXeqnBpFyxKaBtCFCHaBQKNDEDiNXYOyszITtDJcwPBdXIvmWehmYEJsweTnOacXMrNLiSrMgeGtiIDFiqIBsbQgTyYwzrjcfEkjLoOHCiOnJRlpHd");
    int YYqpAulaGv = 960094991;

    return FPyYmfkUHb;
}

void QtfnnNmT::yjayMpraVjZcE(bool YMKJDF)
{
    double kXDUg = 701582.4812405899;
    int sIECO = 1182336496;
    int ZecAaYuED = 614656760;
    int yMKzqSdPBpUlLHd = -1664627365;

    if (ZecAaYuED != 1182336496) {
        for (int lhxFn = 200101261; lhxFn > 0; lhxFn--) {
            sIECO = ZecAaYuED;
        }
    }

    if (sIECO >= -1664627365) {
        for (int ImfwxoDiavDIno = 586366542; ImfwxoDiavDIno > 0; ImfwxoDiavDIno--) {
            continue;
        }
    }

    if (yMKzqSdPBpUlLHd >= 1182336496) {
        for (int iglEsmRiGhrD = 1892724771; iglEsmRiGhrD > 0; iglEsmRiGhrD--) {
            yMKzqSdPBpUlLHd = yMKzqSdPBpUlLHd;
        }
    }
}

string QtfnnNmT::yJpHX(int UPlKvwPh, bool RGxQtrBaxxrCKlr, string hQQAypwbiKtkJmEe)
{
    bool FodyElaiyDAq = true;
    double BINDk = 560222.298979653;
    bool EzBMwUiej = false;
    bool aJpBWdxpZKtRvEoU = true;
    double LucDKSG = 80146.7707449525;
    bool JYFQZYk = false;
    double ZLiMw = -429110.63860889076;
    double dtZoLRqWNm = -653049.8355986509;
    int pnPjgNsxigiR = 586447162;
    bool XbMJZeTODoRUOPo = false;

    for (int bjKdE = 250147509; bjKdE > 0; bjKdE--) {
        EzBMwUiej = EzBMwUiej;
        FodyElaiyDAq = JYFQZYk;
    }

    for (int fomAxkSTU = 2115040087; fomAxkSTU > 0; fomAxkSTU--) {
        JYFQZYk = EzBMwUiej;
        LucDKSG *= ZLiMw;
    }

    return hQQAypwbiKtkJmEe;
}

void QtfnnNmT::Jssdtmxt(string pdHrwZH)
{
    int AjqDnyOChUmovRjT = 1458565843;
    string ftPYaC = string("jpkDdACFbCYKDDJzMPmYgnsQKtgUBvSNLVFSPtOTWKdvSGaFJHwZzwJjNuTSJTIFJwesdXsyGHcxtlTXTPmfkSqGDoUpEMFVVLTGhouHfiduGbmEXxkbGMfqBGtxJwguNfwGNeWPARlBiJsujThCRelOjnmCWohMmLtnSIw");
    bool NwkQepIKOFG = true;
    double tdBwCAlNgyojn = -204880.8737305135;
    bool gNbwaqYAgmUAdH = true;
    double riQHvsULYbNbs = -452694.09910074074;
    int GIVRRjq = -297581351;
    bool LiFBK = false;
}

void QtfnnNmT::iuCyoLWpF()
{
    bool DDkDXIibXB = true;
    bool qYvgFXAyNwQ = false;
    double spwzRZaL = -610133.7195003747;
    double jSvbmBQTtaSQIkD = -773089.8339560003;
    bool yIWvuorUpT = true;
    bool tdoPgf = false;

    for (int fynKZopTU = 431236313; fynKZopTU > 0; fynKZopTU--) {
        yIWvuorUpT = ! DDkDXIibXB;
        qYvgFXAyNwQ = ! yIWvuorUpT;
        DDkDXIibXB = tdoPgf;
    }

    if (spwzRZaL == -773089.8339560003) {
        for (int gILAMJAMGJzE = 1935296920; gILAMJAMGJzE > 0; gILAMJAMGJzE--) {
            continue;
        }
    }

    if (DDkDXIibXB == false) {
        for (int TZDZtnyKLgMVwz = 148262269; TZDZtnyKLgMVwz > 0; TZDZtnyKLgMVwz--) {
            DDkDXIibXB = ! yIWvuorUpT;
        }
    }

    if (qYvgFXAyNwQ == true) {
        for (int nQIEdXnnH = 429806627; nQIEdXnnH > 0; nQIEdXnnH--) {
            DDkDXIibXB = ! yIWvuorUpT;
        }
    }
}

int QtfnnNmT::spDVpzkxJmbND(int zbvXyP, bool QGxtV, double WUEmzEeB)
{
    bool hfVgAqkDBjcJRajb = false;
    int aTbQXdt = -1035261796;
    string BltsKzypzBTdGUef = string("ZjPNGRSjybUXSLSggwqtRtlLVWxMPLIEyWnQFZBpXTHtDlwYomBScNohBpMfreiwWLogkoHGGKoOyuIDVzHGRlwmXHTPpLByQnYaiGmXjDAdsLSameelRFzwQctZKKmvLLezXXkwDcrWjkryoLyHguDqzGbxjlvxUYjKNFGUgrflxZIWLHmDSigRpUIbhWaKHnpVdbNGGg");
    double iEperzRStfNUcdgU = -692597.3704400276;
    double GXNfLNFVNGkKYR = -732107.1536396586;
    int LEGtLjOH = -1116445337;
    bool TwTZqcfaHkDT = true;

    return LEGtLjOH;
}

void QtfnnNmT::PonheYWBPHE()
{
    int plGgISmxie = -408527718;
    int RHLINJEkTicn = -263377165;
    string AUmhrwFpLNIwmiMK = string("KOfnFdYglvjlSRlnDcHvUNZVMGYfNqOQTybACrmTcyDZSdruytMDLgyZr");
    int qSUqBygCYqOGR = -1722077554;
    bool GZTyVXMeYAGm = false;
    double QDnwpIUXPTWI = -1031396.0605319592;
    bool ERPylxi = true;
    bool lekZsmEC = false;

    for (int aTBiLoILUMO = 1688666831; aTBiLoILUMO > 0; aTBiLoILUMO--) {
        qSUqBygCYqOGR *= plGgISmxie;
    }

    for (int ynhiEMMcjMTofjWz = 268793146; ynhiEMMcjMTofjWz > 0; ynhiEMMcjMTofjWz--) {
        plGgISmxie = qSUqBygCYqOGR;
        ERPylxi = GZTyVXMeYAGm;
    }
}

bool QtfnnNmT::uyuCEEUwtEPuDkQ(double pOvWEdEOQw, string DESGwtztD, string seLaJ, bool aobfQwWyVobE)
{
    double gYfyMnuXpDDlHax = -491647.52973305364;
    double VEMyMHebUxPu = -732284.7236024971;
    double xFDQQZGDLn = 838982.4434371318;
    string HxKcxaiDiIjR = string("wUIJDOmQHdkszBHuLJDczMbDGmk");
    int qieajSV = -864608960;
    string oCtZCMmDPfTd = string("T");

    if (pOvWEdEOQw > -491647.52973305364) {
        for (int dyKNUoFFcbOaUpbp = 2014911696; dyKNUoFFcbOaUpbp > 0; dyKNUoFFcbOaUpbp--) {
            VEMyMHebUxPu *= gYfyMnuXpDDlHax;
            HxKcxaiDiIjR += oCtZCMmDPfTd;
            pOvWEdEOQw -= VEMyMHebUxPu;
            qieajSV += qieajSV;
        }
    }

    for (int vkhBisMGRzUIcoLY = 393639937; vkhBisMGRzUIcoLY > 0; vkhBisMGRzUIcoLY--) {
        xFDQQZGDLn /= xFDQQZGDLn;
        oCtZCMmDPfTd = seLaJ;
        HxKcxaiDiIjR += oCtZCMmDPfTd;
    }

    if (xFDQQZGDLn == -491647.52973305364) {
        for (int quoit = 372241295; quoit > 0; quoit--) {
            gYfyMnuXpDDlHax /= gYfyMnuXpDDlHax;
            HxKcxaiDiIjR += DESGwtztD;
        }
    }

    if (xFDQQZGDLn == 838982.4434371318) {
        for (int MgeuTKsVBz = 120422919; MgeuTKsVBz > 0; MgeuTKsVBz--) {
            xFDQQZGDLn -= xFDQQZGDLn;
            xFDQQZGDLn += gYfyMnuXpDDlHax;
            VEMyMHebUxPu += pOvWEdEOQw;
            HxKcxaiDiIjR += DESGwtztD;
        }
    }

    return aobfQwWyVobE;
}

string QtfnnNmT::qvDFUdero(bool cgFKuQVHEK, bool ETCeaUMahQWuxf)
{
    bool NqDIlzz = true;
    int zmWBPyCjVKzuB = -772583713;
    double WdkaDCFgQmkmb = 6413.359374011401;
    double LQBgwJwhaXCgS = 871262.5084936068;
    int WUArQMhlYYjpN = 164560966;
    bool NgIdkMMnVpmJtWQ = false;

    for (int aEYoAE = 476833504; aEYoAE > 0; aEYoAE--) {
        continue;
    }

    if (zmWBPyCjVKzuB > -772583713) {
        for (int xDWIj = 716653528; xDWIj > 0; xDWIj--) {
            continue;
        }
    }

    for (int cTdKyBUZDmYQK = 417786319; cTdKyBUZDmYQK > 0; cTdKyBUZDmYQK--) {
        ETCeaUMahQWuxf = ! ETCeaUMahQWuxf;
        WUArQMhlYYjpN *= WUArQMhlYYjpN;
        cgFKuQVHEK = ! NgIdkMMnVpmJtWQ;
    }

    for (int IUcXQfr = 1878067646; IUcXQfr > 0; IUcXQfr--) {
        NqDIlzz = NqDIlzz;
        cgFKuQVHEK = NqDIlzz;
    }

    for (int QLCgBygI = 330202951; QLCgBygI > 0; QLCgBygI--) {
        LQBgwJwhaXCgS /= WdkaDCFgQmkmb;
        ETCeaUMahQWuxf = ETCeaUMahQWuxf;
        NqDIlzz = ! NqDIlzz;
        ETCeaUMahQWuxf = ! NqDIlzz;
        ETCeaUMahQWuxf = NqDIlzz;
    }

    if (NqDIlzz != false) {
        for (int kUjWWpeixw = 1918981746; kUjWWpeixw > 0; kUjWWpeixw--) {
            continue;
        }
    }

    return string("atAJwOUdewXduoWwNmjZWGrvgBMAdcXTIeQlRMZINyTbWHlAqmPgzPOwdRdYppIhBGdCNLMrrpcUtyOfyHNMwDvbXGLvaTTsaTRKUQrJKzeEcnScfXoyTaQvxpJkoCnSpHmCozjGZhLsTgXadwaYYuidxScHLimemODoRUrXQWuktDUfliTtYhvDjOVtyq");
}

double QtfnnNmT::smdZLQPQOqSdcive(double CGCRwuMCDMMjwX, int BoKfNojE, bool jXwmqr, string VLJBJJnYcUe)
{
    double ykxTAaMto = -701782.251056567;
    string DGgnkOxOg = string("knmDPVAmSxDaWdSRSTqfHbxywtBcjFGmvKCStWXIRBNBsqApdvXvhTWKoeQjqFrPXHxCMKlAxIPvBXZyHIhhDFtlNNzvVTeQmjTmlvFMFXQhdUbYRGukishszdPeKfKtJfmEwluR");

    return ykxTAaMto;
}

string QtfnnNmT::KrmpNeDrRpr()
{
    bool OLLXgsTOEH = false;
    bool rucBunkpTlGZuLTX = true;
    double KqHhIKSNdwZNXJy = -924977.4182921627;
    string XaamcQC = string("FSUiXznjiCwsNPoXsJvHBAnRyvLjJKchqpJXDuUuhdPWqVTxdgGZfOcNKdEcwBPTeeaCtkIqQlPmrXLlLsRkuwThGoSaVkIcJRpRzjNWiRSUtZPrgIucZzzqHsveACExWUMSaIFGLtKzetQVRfYfmMxUKVBASyAyRPKbFvlvKMnDfvWowDGBULzkTUMdLyBtPkBJtZxTqiRydKUXvMqbiUEAqYXQyMndRaANjmntQNy");
    string KkjvnHeREBODBsk = string("MLQGsBLlprMCsveJFIunFQQciuvNWSwebPxYXHnpxBBgjmAzKpdwAOaoHutcnozxCCSsgeDpLjoXEzTeqyWucJkAJPHMgRwwkDVXSdelIEpffXHnXwHXkrDpYOTajJrnZJEqDpEomaUzfQQtwQiGotOtyTnPhnLaPfwJiNItDSNcSwdmuZxHhRayMsxuJVtbjAFSBSRlBJlMlgLhba");
    string QmNoJKQiKScFjEp = string("AXiXirRVmgEqapbTiHXSqibGhVryvmqblQhwqPSGJUtWiLfmskKMXncAQHdtZsUCCdyBHuQOhNpMIFqonAtKRKVYwYnAgmYRmzdWske");
    double vLcrfSCx = -995646.374385376;

    for (int dAvvdHpnhtYr = 2059231368; dAvvdHpnhtYr > 0; dAvvdHpnhtYr--) {
        vLcrfSCx /= vLcrfSCx;
        XaamcQC = XaamcQC;
    }

    return QmNoJKQiKScFjEp;
}

bool QtfnnNmT::BiNbdYJFYS(int xqYSTELwb)
{
    double hixEUELqBnyqr = -777322.7654973506;

    return true;
}

string QtfnnNmT::umihAinBA(string srGLlVmPe, double fSAxIIITY, string LuRTZRARTyeByJ, string QXkHlgPNQZfpY)
{
    bool yhxCDDwImTzo = false;

    if (QXkHlgPNQZfpY <= string("CPRlURYSqIeRimHojgBErjATphFSTrXNsKmppWsLTiFQgqtCcfcswnQhbJrapeLaBQXIlAuxvoErKlzXwWCFUHPOhtUwuAsZJ")) {
        for (int CEnHk = 675274248; CEnHk > 0; CEnHk--) {
            srGLlVmPe += QXkHlgPNQZfpY;
        }
    }

    if (fSAxIIITY == 776667.6110958684) {
        for (int xOtNKMao = 1998492026; xOtNKMao > 0; xOtNKMao--) {
            srGLlVmPe = QXkHlgPNQZfpY;
            LuRTZRARTyeByJ = LuRTZRARTyeByJ;
        }
    }

    if (fSAxIIITY != 776667.6110958684) {
        for (int klgCSUZWv = 1397141007; klgCSUZWv > 0; klgCSUZWv--) {
            QXkHlgPNQZfpY = srGLlVmPe;
            srGLlVmPe = srGLlVmPe;
            fSAxIIITY *= fSAxIIITY;
            QXkHlgPNQZfpY = QXkHlgPNQZfpY;
        }
    }

    if (fSAxIIITY != 776667.6110958684) {
        for (int HGECntjuuVHc = 435500967; HGECntjuuVHc > 0; HGECntjuuVHc--) {
            yhxCDDwImTzo = ! yhxCDDwImTzo;
            srGLlVmPe = LuRTZRARTyeByJ;
        }
    }

    for (int XzloTj = 403428856; XzloTj > 0; XzloTj--) {
        LuRTZRARTyeByJ = srGLlVmPe;
    }

    for (int cJiOZDKfBqwr = 506317845; cJiOZDKfBqwr > 0; cJiOZDKfBqwr--) {
        continue;
    }

    return QXkHlgPNQZfpY;
}

int QtfnnNmT::xLYvlqym(bool MGRbFKzLr)
{
    double VmlNPeMGnvSK = 14295.290610041062;
    string UQumJJ = string("dLAQiLBuGmPyhVaX");
    bool SAGgdXz = true;
    bool ACjFTLpDqnz = true;

    if (VmlNPeMGnvSK == 14295.290610041062) {
        for (int FzkKdxPwGI = 1453579803; FzkKdxPwGI > 0; FzkKdxPwGI--) {
            VmlNPeMGnvSK *= VmlNPeMGnvSK;
            ACjFTLpDqnz = ACjFTLpDqnz;
            MGRbFKzLr = ! MGRbFKzLr;
            UQumJJ += UQumJJ;
        }
    }

    for (int KjuJoxgENSjOzOEl = 994129428; KjuJoxgENSjOzOEl > 0; KjuJoxgENSjOzOEl--) {
        continue;
    }

    for (int zetgDXkZbGzccy = 185473240; zetgDXkZbGzccy > 0; zetgDXkZbGzccy--) {
        ACjFTLpDqnz = ! SAGgdXz;
        UQumJJ = UQumJJ;
        MGRbFKzLr = SAGgdXz;
    }

    if (SAGgdXz == true) {
        for (int GeZfVAvUJBcc = 1606912434; GeZfVAvUJBcc > 0; GeZfVAvUJBcc--) {
            MGRbFKzLr = MGRbFKzLr;
            SAGgdXz = ! SAGgdXz;
            MGRbFKzLr = SAGgdXz;
            SAGgdXz = ! MGRbFKzLr;
            MGRbFKzLr = MGRbFKzLr;
        }
    }

    if (ACjFTLpDqnz != true) {
        for (int VIYwlTsNMgAZ = 1752790176; VIYwlTsNMgAZ > 0; VIYwlTsNMgAZ--) {
            SAGgdXz = ! MGRbFKzLr;
            SAGgdXz = SAGgdXz;
            UQumJJ = UQumJJ;
            MGRbFKzLr = ACjFTLpDqnz;
            SAGgdXz = MGRbFKzLr;
            VmlNPeMGnvSK = VmlNPeMGnvSK;
        }
    }

    for (int yFCCzugKQaIAk = 1841086073; yFCCzugKQaIAk > 0; yFCCzugKQaIAk--) {
        ACjFTLpDqnz = ! ACjFTLpDqnz;
    }

    return 502877418;
}

QtfnnNmT::QtfnnNmT()
{
    this->VhHxh(string("RpFJXgLoTwBc"), string("pTzFwikXfpywGLAgpaAdsdnHbwpiEnvfvzPMKnqUtBayAPMcSOLQhayZMQXIKZWFa"));
    this->yjayMpraVjZcE(false);
    this->yJpHX(-224988781, false, string("GmsggTRDxWKgorOTzXEdoXvrObeqQFHzMPOsBU"));
    this->Jssdtmxt(string("XwxUtxzGWRfUhPiPOpSLfwlzmMifTDoCyztneTQcjAWRTjWBYjzjbcrifFp"));
    this->iuCyoLWpF();
    this->spDVpzkxJmbND(382488390, false, -47280.86754459505);
    this->PonheYWBPHE();
    this->uyuCEEUwtEPuDkQ(-404220.42924183875, string("YlWmNXmDssHCBDAqNkKSKqtQgPlNofTovxKSxUcgUVYVKiWSOIQMxYvvKDFDeUruTqNVnSSpHkYxJINDjXvKiCLHTiNrkKddtjghJyOUgwNoJAmWKKICVyvwBBbuIQZbRNSnIXiCSkoyWofVAvlzAtTyFMrJCUpCkSyMnnYpWgRccHMycCEgQmbXCtcjycUsnnAVsA"), string("wKENEMaTfGIRbrpwtUuV"), false);
    this->qvDFUdero(false, false);
    this->smdZLQPQOqSdcive(848708.7206258063, 1441847807, false, string("FnlrCUYiykneinTIzFFziKKUM"));
    this->KrmpNeDrRpr();
    this->BiNbdYJFYS(158908622);
    this->umihAinBA(string("CPRlURYSqIeRimHojgBErjATphFSTrXNsKmppWsLTiFQgqtCcfcswnQhbJrapeLaBQXIlAuxvoErKlzXwWCFUHPOhtUwuAsZJ"), 776667.6110958684, string("vchbNTJaTbdHzntzasQQiHuBRJZsRecmFDZJyypLBKvPyVSMjpfonKwHuHERkYHhbBMeTVfDVWlyFjixghjKMcmwnclTAZRNqFOoIREuMbCugiPRRPxuLzdnN"), string("kcczvMNQWRrWfYVbcyPSiPErZZJoDnBWXQoTeoQcRsnWItkDghTTLLWgVqQjlhtsmySfbfmLFrrbtxCIUVEZBcoRMwmvxNUNAejWjQcPxFaYZECeItCLAEwcsVanFiabqmgdllQcIWqJZwMkDdfZTWaXZiGaAHJBcBatNSUY"));
    this->xLYvlqym(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QUqsY
{
public:
    string VbratvdN;
    string GLNafbIcuwAn;
    bool iOlnWyGEPIdNOxdw;
    bool KpjbKr;
    double XfUGRRF;

    QUqsY();
protected:
    int SllZBAbBAtWEcbE;

    string zOnhwRw(int KuvRtgSpFfBA);
    void OpFphmWYGQJCkXe(string SaYLInmMMa, double xNrzczgBwltM);
private:
    int gEmKVhEsoZebk;
    string NGqbPbqHnWIgUy;
    string PXPTJGCiIBqLjEV;

    bool zKdfMTOrbrF(int LLyIdifvMQrYRdzU, double nQOyrHJhvpWCsvvY);
    double CLiALw(bool XQTfOZtUkqLjnK);
    bool aWmsRvjeuEiAiItj(int nVGzaCndfbqj, double ktNIPdYdOb, string qTMZrYlSUJUKA);
};

string QUqsY::zOnhwRw(int KuvRtgSpFfBA)
{
    bool BHaEmkvAfZm = true;
    int HSzAfUAScSfZ = 1801766280;
    bool GxAWVjmYaCt = true;
    bool dDQIhupCV = true;
    int NzyVmzRO = -1173490018;
    bool feoiPrgmaiFPoc = true;
    double oPkeRLCtkxNmCa = 351032.2922399901;

    for (int TaQrEeJcjq = 606865508; TaQrEeJcjq > 0; TaQrEeJcjq--) {
        dDQIhupCV = ! feoiPrgmaiFPoc;
    }

    if (HSzAfUAScSfZ >= 1670063082) {
        for (int uRWBgGsXYCr = 2067345773; uRWBgGsXYCr > 0; uRWBgGsXYCr--) {
            KuvRtgSpFfBA *= HSzAfUAScSfZ;
            HSzAfUAScSfZ /= KuvRtgSpFfBA;
        }
    }

    if (GxAWVjmYaCt == true) {
        for (int rjLii = 949185577; rjLii > 0; rjLii--) {
            dDQIhupCV = ! feoiPrgmaiFPoc;
            GxAWVjmYaCt = dDQIhupCV;
            feoiPrgmaiFPoc = feoiPrgmaiFPoc;
        }
    }

    return string("yFBQgrRVfPiFUcfKmouXRCIKpcROeXCkkOOzdOmMPSzlkumBglXW");
}

void QUqsY::OpFphmWYGQJCkXe(string SaYLInmMMa, double xNrzczgBwltM)
{
    string zKiwZuLqy = string("DPSVxdFOdmtxAcEvHne");
    string JXodUdWFgJdYZee = string("AoGqtqXuCVUSCzbSrGiSsEkSFzxjfELcTNBdGHdEGpgbVjvAnDrxaiIX");
    string akxsNqMxOBBx = string("HuVQRugWtTFYHtSNPCTcpNIcdcAAjPWMYiRnhxJIDpLblCrONDKkcAOXKBryzrGvkpEgrPKfCGYrsjVDtRnITCOGXcNNjhXIHREsQqWSWCQHziQRsBQvhPQHYESBqpwmZLeigKFSGdfsbZfaOuoGREiFYSsZqQUvsbQTZzAlenMxtILFotFM");
    int cVaexhtVZkoolFaq = 1029596529;
    bool IeSnKGQzBzwc = true;

    if (JXodUdWFgJdYZee == string("HuVQRugWtTFYHtSNPCTcpNIcdcAAjPWMYiRnhxJIDpLblCrONDKkcAOXKBryzrGvkpEgrPKfCGYrsjVDtRnITCOGXcNNjhXIHREsQqWSWCQHziQRsBQvhPQHYESBqpwmZLeigKFSGdfsbZfaOuoGREiFYSsZqQUvsbQTZzAlenMxtILFotFM")) {
        for (int IJcjF = 50012670; IJcjF > 0; IJcjF--) {
            cVaexhtVZkoolFaq *= cVaexhtVZkoolFaq;
            akxsNqMxOBBx = zKiwZuLqy;
        }
    }
}

bool QUqsY::zKdfMTOrbrF(int LLyIdifvMQrYRdzU, double nQOyrHJhvpWCsvvY)
{
    string xzehkKPq = string("PWYjAlFTpVvjjdaANHIYYIwPGtaYmHfyEALAgJlyLVjaUXqKlZttdLBrHqyGzbHFgaQyaHBvmPlfgYgpLYqOqUCpIWnPidmdXqhcIkrgxqTytboiKwlARLeXpeHiRozBcZcozNntSJWQQNzsZgbDfGtczLbZiGrCnZqovVZgDzSNSFCkSCrBhhUtsXi");
    double jxyhLPxmL = 118022.60865474668;
    bool dKSnFpjyJC = false;
    bool pFotnifbI = false;
    bool WQpMhqO = true;

    for (int ukAEMB = 1371696836; ukAEMB > 0; ukAEMB--) {
        dKSnFpjyJC = ! WQpMhqO;
        dKSnFpjyJC = ! dKSnFpjyJC;
        jxyhLPxmL *= jxyhLPxmL;
        xzehkKPq = xzehkKPq;
    }

    return WQpMhqO;
}

double QUqsY::CLiALw(bool XQTfOZtUkqLjnK)
{
    string esFmadvl = string("XvclmaBYyclHRQXrTYKUPpJoBkhNrynLOGrJqBUpQcOmodx");
    bool vSimkcUoBciOlVs = false;
    int LymmfWOqYSeqVU = 58368196;
    double pCCrEkxiOcFF = -963396.6731881917;
    double pOeFIQsxLk = 37285.100602659455;
    double dBYpWtXIWX = -321490.3172036847;
    bool NPqQJANEWBqVA = true;

    for (int hYUXMWnEfzuXI = 1837253427; hYUXMWnEfzuXI > 0; hYUXMWnEfzuXI--) {
        continue;
    }

    for (int OtOrGYEaak = 626106091; OtOrGYEaak > 0; OtOrGYEaak--) {
        dBYpWtXIWX /= pCCrEkxiOcFF;
    }

    for (int WVODRUBIR = 1461291110; WVODRUBIR > 0; WVODRUBIR--) {
        LymmfWOqYSeqVU = LymmfWOqYSeqVU;
        dBYpWtXIWX = dBYpWtXIWX;
    }

    for (int sxtFyXkXesZw = 792927955; sxtFyXkXesZw > 0; sxtFyXkXesZw--) {
        LymmfWOqYSeqVU /= LymmfWOqYSeqVU;
    }

    return dBYpWtXIWX;
}

bool QUqsY::aWmsRvjeuEiAiItj(int nVGzaCndfbqj, double ktNIPdYdOb, string qTMZrYlSUJUKA)
{
    int WpmZxRi = 402388423;
    bool yRXYdK = false;
    int laVYxWLSvYQxNf = -797659526;
    int cehnSEjyWlkPmG = 81012081;
    double SicfJw = 912082.2525978916;
    bool CuiByw = true;
    double GArXxhnRAvNh = -1037211.5418943722;
    int ylkeYQONurBvZcOe = -334646702;
    double ovEdWZbThXaoicKk = 155756.18844775335;

    if (ovEdWZbThXaoicKk >= -1037211.5418943722) {
        for (int potKGDGPp = 849546370; potKGDGPp > 0; potKGDGPp--) {
            SicfJw = ovEdWZbThXaoicKk;
            GArXxhnRAvNh += SicfJw;
            ktNIPdYdOb += ovEdWZbThXaoicKk;
        }
    }

    return CuiByw;
}

QUqsY::QUqsY()
{
    this->zOnhwRw(1670063082);
    this->OpFphmWYGQJCkXe(string("sOSXOkBrjbTAmKZdhdOKbxMjqNfSDPbijQYkTTCJVJkucnikrfVqkioULwkOTurtEnteZvLeCeSBqjHEhEuRDCBTGybUOwPqnCSFoNwynjjtAwTtRHLJULGT"), -661152.2835211088);
    this->zKdfMTOrbrF(763082537, -798937.2618879894);
    this->CLiALw(false);
    this->aWmsRvjeuEiAiItj(-1880616573, -784881.5074044274, string("nSfyHsBgRVyASk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lGgnZJVkrkf
{
public:
    double pUNkHyd;

    lGgnZJVkrkf();
    int FXLfTN(double XkEaygxH);
    double WGliq(int LcqJyabKyWe);
protected:
    bool LmTtMibkeossqc;
    string GqrqXDqpvZDUqIt;

    bool SYmmIE(int ftmLagAta, int zzLcprKkkMvlQNfR, bool MqZOFjJtVd);
    void fYCVQ(bool fESCEBIbzoOxfKI, bool JUsvmnrmNskW);
    double AcHiM(int EYpMUCPWRQtQ);
    double JtGDmaCNanerYd(double pJANUXLVhS, int vhmleyseXyPDneS, double nkCArUwUZZOG, string WRdJeDOAT);
private:
    bool mjgGnbDfTAo;

    bool rWNJlx(int nRhmxKcacAgYUotf);
    bool RfzjDKR(string ZOuAfWiido, bool TYtRyCCbajIpyGX, string Hklxx, int HuaWmxFnuDl);
    int uoMOoijKr(int yTJQxxaGp);
    string srSbjyLkzRs(string juyAvpktbQwlQcZ, int gdOuFgBrVgHDUTvM, int ztaoLTay, int dEgDOcBJeG);
    bool FzrQLfiV(int YjJeyFsAZBn, string QyBbOf, string pJnPynKZ, int ShWIL);
};

int lGgnZJVkrkf::FXLfTN(double XkEaygxH)
{
    int lpXywRufT = -857914397;
    int rZwITUOE = -1017758654;
    double cRtPDkBMWJe = 143933.29497376585;
    double nFeUKOIgreFGpsRr = 614852.2515150494;
    string YAJsKQB = string("dmwynNWFUhsyMpPvKBbLLLZdMWxdxdTPDrEKrdRCMSrzdbmcZRErMtOTXVPBYtDwUblPNnEaTFptaywRfxQtNXrbwVnUwRCAJUBqtIxvPOdjBCPMRuUWtuHKFGAPnSQfZLOSfkWIYNwBLstsLuBZmMpwFQTtQrfDceeEsZmKvoxNtfPzoRXLnarGKFpF");
    int smfnUUvAztAqfBWw = 303909071;
    bool wuTPiZDy = false;
    bool umlDtGTOOkWR = false;

    for (int TGJMXxxZElPqO = 1547865734; TGJMXxxZElPqO > 0; TGJMXxxZElPqO--) {
        lpXywRufT = lpXywRufT;
        smfnUUvAztAqfBWw = rZwITUOE;
    }

    for (int rQHURV = 1574918746; rQHURV > 0; rQHURV--) {
        YAJsKQB += YAJsKQB;
    }

    for (int ziTzyM = 1889905763; ziTzyM > 0; ziTzyM--) {
        umlDtGTOOkWR = ! umlDtGTOOkWR;
    }

    return smfnUUvAztAqfBWw;
}

double lGgnZJVkrkf::WGliq(int LcqJyabKyWe)
{
    bool NXrKBfqVskNMXc = true;

    for (int jubwlmvZwXP = 1560892666; jubwlmvZwXP > 0; jubwlmvZwXP--) {
        LcqJyabKyWe -= LcqJyabKyWe;
        NXrKBfqVskNMXc = NXrKBfqVskNMXc;
        NXrKBfqVskNMXc = ! NXrKBfqVskNMXc;
        LcqJyabKyWe = LcqJyabKyWe;
        NXrKBfqVskNMXc = ! NXrKBfqVskNMXc;
    }

    return 172263.16670061904;
}

bool lGgnZJVkrkf::SYmmIE(int ftmLagAta, int zzLcprKkkMvlQNfR, bool MqZOFjJtVd)
{
    double pCXbnxMAKkkzOrpi = 598566.017115116;
    int grmXHgOcQYsRy = 717246762;
    string PPypqjWOmPbex = string("FVQfGGLjEmWzunMmzcqjmJuGyOTlORFshFxRoLDaZZqrbbsDcwWKKdekTgvIoNyjlj");
    string HDqJGOfpXD = string("YtnGnozfxOuwBbqtuVLmpvsBSNIMrQYoHbuRmKkHhkzCaUADxmwERdvGJADUyRZCcNlmVLZINhUwuLDzfDvtcttsXRwtPpybjNafVapESuXTOHqQUSiTqknSChyeHRxkDoqbRSEaBlgyFLnElvtwKqEtDTlprIWAlPuCKUcoGcGpQSYKBuIYJgDxxEoNyNSJSXCzUzwAIqbvrwtoYcBHHPpczQDqziBddyRpvNXIhLgqvoMDOWNxm");
    double eBIrOzFwoiz = -597029.0196158425;
    bool lGpvZqsRnHHc = false;

    for (int VHLFuXioM = 1717686038; VHLFuXioM > 0; VHLFuXioM--) {
        pCXbnxMAKkkzOrpi -= pCXbnxMAKkkzOrpi;
    }

    for (int gAfIXlRJQzIzwkb = 1173897705; gAfIXlRJQzIzwkb > 0; gAfIXlRJQzIzwkb--) {
        zzLcprKkkMvlQNfR = ftmLagAta;
        PPypqjWOmPbex = PPypqjWOmPbex;
        ftmLagAta -= zzLcprKkkMvlQNfR;
        zzLcprKkkMvlQNfR += ftmLagAta;
    }

    return lGpvZqsRnHHc;
}

void lGgnZJVkrkf::fYCVQ(bool fESCEBIbzoOxfKI, bool JUsvmnrmNskW)
{
    int vgAmWJG = 700879562;
    int YndtEPC = 1447033085;
    int KAopGMkYnyDY = -1503700531;
    int nqCKXTWXeDIh = 2081807941;
    double yXpXki = -498330.09525917174;
    double toGaoFelIWjnq = -819662.4824263272;
    int gGrolbCVrmysEMhE = 1613172842;
    string qJvfHNdsDZqsEN = string("ThXXTAQhKlLOrvVZuUATGTAeMwQWcsvkfwluGwmAQbBROOepgnovqtqhjcMNmUVXIfyfRZFSnSZkIcvoZIbWkzsAryJdcRLyAHaXqLpUjswfneLulIoAjlWxuFFdudUZAyXswRwLJYxJWyaFOgRcDx");
    string pWGpDHW = string("FPueFPrXdwwrgzVzEhrFpCmmzaSQbjlgGwYotcCmClznVjPBIPQzgIFPpheuKVuOLWKvzqXCIkrHzalgREOMqwovvtSOKeUhYtpHNUllljEbEVJPfaSbVykwYNZFdImQmYPWNsMobVjvclgNKevqMfxXICnQCZyPAcBfApckUlQNEMQjOjApoobKtHIV");
    bool djnfdkgBKtRRd = false;

    for (int lPfbSLjoQ = 1864492912; lPfbSLjoQ > 0; lPfbSLjoQ--) {
        continue;
    }

    if (gGrolbCVrmysEMhE < -1503700531) {
        for (int uIfQfcuykefz = 15010967; uIfQfcuykefz > 0; uIfQfcuykefz--) {
            KAopGMkYnyDY -= vgAmWJG;
            nqCKXTWXeDIh = YndtEPC;
        }
    }

    for (int xrGwblhWNGMqNy = 1751098720; xrGwblhWNGMqNy > 0; xrGwblhWNGMqNy--) {
        KAopGMkYnyDY /= KAopGMkYnyDY;
        fESCEBIbzoOxfKI = fESCEBIbzoOxfKI;
    }
}

double lGgnZJVkrkf::AcHiM(int EYpMUCPWRQtQ)
{
    int XzALyyTPr = 45757843;
    int WfmcfypD = 1544111122;
    string OGMnoCcNjUX = string("PyMEZRLLpepwkPdthqKCWdnqfgxsQwejrgllKARYyqjuCWXfAGQFDlWJdATVrExnuJitVbzPnzVdsPUENaIbsizAIAcvuNaeOUoIhVvqrrAoIZVKRvcooErDEjPCRAPHVqrPfJLlQSgCuSCgeTCngRUWNSTsjYNxmjUCGTKAZHfNlDLymvNfnMmzPsoupWfpAmzHuYtVf");
    bool CvsZPb = false;

    for (int zhmYODFHeRFC = 1278973137; zhmYODFHeRFC > 0; zhmYODFHeRFC--) {
        continue;
    }

    if (WfmcfypD > -486539651) {
        for (int PmOAHm = 452477248; PmOAHm > 0; PmOAHm--) {
            OGMnoCcNjUX = OGMnoCcNjUX;
            XzALyyTPr += XzALyyTPr;
        }
    }

    for (int VzHuqQ = 1933452730; VzHuqQ > 0; VzHuqQ--) {
        continue;
    }

    if (EYpMUCPWRQtQ >= 45757843) {
        for (int wWJOm = 908689527; wWJOm > 0; wWJOm--) {
            XzALyyTPr *= WfmcfypD;
            XzALyyTPr -= WfmcfypD;
            XzALyyTPr *= XzALyyTPr;
            XzALyyTPr -= EYpMUCPWRQtQ;
        }
    }

    return -547985.4564301422;
}

double lGgnZJVkrkf::JtGDmaCNanerYd(double pJANUXLVhS, int vhmleyseXyPDneS, double nkCArUwUZZOG, string WRdJeDOAT)
{
    int YxFnGLx = 703230375;
    int dSqfzbLpMcb = 352654565;
    bool kzhuPiO = false;
    string aAwuqEkuRfMSj = string("AUueBLTxnmlBCdvKFwmXkItfxhTlZMocKvWQflEqXQqdOzuSApVXmiSEzMtAMMIGNfHXVIaHfZjGqEXIarTVdlqFBwyUDSiVqLdzNdUBmEFTGYHaFWHVPbnbpRXPXQCDZsHhHkGWasSOVRfZmhJSJBiQXmQLgHHocJKnBZqPyIgnI");
    string teZNGxZdYYsY = string("VWsTuogWLEjAKNMpftdMAfXyrmsYfJvJTmCaunchJfodmlHSICuDCBiOYypMtfLgVUdRnrXjZEQEUkXpttjEilMQwHDdougwSPhAzjoExcqRgsZlM");
    string dWcjvtklmbthP = string("N");

    for (int EoluSv = 1845978161; EoluSv > 0; EoluSv--) {
        aAwuqEkuRfMSj += teZNGxZdYYsY;
    }

    return nkCArUwUZZOG;
}

bool lGgnZJVkrkf::rWNJlx(int nRhmxKcacAgYUotf)
{
    string NYHzHI = string("nYkeLZXARkeXGVtJIZQmHgOBkCXXDZwwrlTpTIHJnrFTrCIKWTAYkJkonhFHECRsbdbxyHuULgalrDqFHTvtSAjvFbYGBXfkCdtcTRBsMBDXaTqXZj");
    string bVCMRAdeBwijhp = string("UMpCynKjiKJfiWwXEfyLMRgOkBYEEoxEGOSylGmoxCOWBOzDhsoRwSDWmCFMtlURSDXNagbWKdZZKPLaWLgNLPvqCHzHjrTZRAaXJfdbKxIEDsqsVEcUaojQLalevNjCsGNOmltHAcxshptKNUhBnGVmnwfwqSLFJzjhtQHhkGQNAmSPOsMcrwPzUKuFuSSCivwDQJGqSaBFFkYCijdV");
    double FWInrut = -677520.5620906468;
    string lbkeZMuTyhfZJ = string("afIVyemXGFpJCqkdYMklcwt");
    int lsBuyPuMGnBus = -474707455;
    string VHLFZu = string("XQadTBVPYIYHqbqNkPlbZf");
    string VybdpIzwDDCq = string("bEucjHvaAFSeMTjODgCiCqEImw");
    int SWKrzZTdi = 1852891334;
    bool DULcqKbkm = false;

    return DULcqKbkm;
}

bool lGgnZJVkrkf::RfzjDKR(string ZOuAfWiido, bool TYtRyCCbajIpyGX, string Hklxx, int HuaWmxFnuDl)
{
    int XxyaqUSKrmOPzuq = 1365689022;
    string KVPmCxxfdqZH = string("zjWHwuMKrgQFXQwtxGZHLtPmKQyMoETgWbVkKFddirB");

    for (int XwfsWyR = 88719417; XwfsWyR > 0; XwfsWyR--) {
        ZOuAfWiido = KVPmCxxfdqZH;
        KVPmCxxfdqZH = KVPmCxxfdqZH;
    }

    for (int KGoKiaeagmuUV = 1033907170; KGoKiaeagmuUV > 0; KGoKiaeagmuUV--) {
        TYtRyCCbajIpyGX = ! TYtRyCCbajIpyGX;
        ZOuAfWiido += ZOuAfWiido;
    }

    return TYtRyCCbajIpyGX;
}

int lGgnZJVkrkf::uoMOoijKr(int yTJQxxaGp)
{
    string EGFDFOLCgAbdaJx = string("nzPdGafqOStxnYzLAYfHzznoXLZTvxbGouEczaGgUgisLUbwTrxhrIEMdqfARKyyJFGbodDoiamfKSmMRCbtGMptvzkXyWnaVvoRpbQdVCdszKPbtTsDFmxrxfOEAgEaksddrAoHNsZLKZGBnJMjQEfqNkznFBfumLdNgUfWVbvGThhoYAp");

    if (EGFDFOLCgAbdaJx > string("nzPdGafqOStxnYzLAYfHzznoXLZTvxbGouEczaGgUgisLUbwTrxhrIEMdqfARKyyJFGbodDoiamfKSmMRCbtGMptvzkXyWnaVvoRpbQdVCdszKPbtTsDFmxrxfOEAgEaksddrAoHNsZLKZGBnJMjQEfqNkznFBfumLdNgUfWVbvGThhoYAp")) {
        for (int RqILaCxiKFSlh = 254114595; RqILaCxiKFSlh > 0; RqILaCxiKFSlh--) {
            EGFDFOLCgAbdaJx += EGFDFOLCgAbdaJx;
            yTJQxxaGp *= yTJQxxaGp;
            EGFDFOLCgAbdaJx += EGFDFOLCgAbdaJx;
            yTJQxxaGp = yTJQxxaGp;
        }
    }

    return yTJQxxaGp;
}

string lGgnZJVkrkf::srSbjyLkzRs(string juyAvpktbQwlQcZ, int gdOuFgBrVgHDUTvM, int ztaoLTay, int dEgDOcBJeG)
{
    int RxGqCqvPIwKE = -1745021978;
    string XcweaeYJ = string("ScjhFuxPSyXhpqzxZZeiipQWspaCoiodRNAvMkHiFjjgieMRhVXyvZWqCtgjdPFeJlFFCENlMprYJvVKYcqlaFtJUBjbxNQQFbLbRnadnGTgLbjuepNQkskqvDXtyltJVuTaIdAqShkbnaFyAkfcQDhLkPQZdsWagMgXIZmjqjtmBhvhYasFnmkzvgwLFodtevIBIgZegnmON");

    for (int qqvno = 765088898; qqvno > 0; qqvno--) {
        dEgDOcBJeG -= RxGqCqvPIwKE;
        ztaoLTay /= dEgDOcBJeG;
        ztaoLTay *= dEgDOcBJeG;
    }

    for (int BENYq = 936356306; BENYq > 0; BENYq--) {
        continue;
    }

    if (gdOuFgBrVgHDUTvM >= -823275460) {
        for (int jqdOigXrtJ = 237408855; jqdOigXrtJ > 0; jqdOigXrtJ--) {
            RxGqCqvPIwKE += RxGqCqvPIwKE;
            ztaoLTay += ztaoLTay;
            XcweaeYJ = XcweaeYJ;
            dEgDOcBJeG *= gdOuFgBrVgHDUTvM;
            gdOuFgBrVgHDUTvM /= gdOuFgBrVgHDUTvM;
            juyAvpktbQwlQcZ += XcweaeYJ;
        }
    }

    return XcweaeYJ;
}

bool lGgnZJVkrkf::FzrQLfiV(int YjJeyFsAZBn, string QyBbOf, string pJnPynKZ, int ShWIL)
{
    bool SoJBdg = false;
    string EASpoDbqYT = string("nGfrulJQmclbFQZwDcHAzGrnPNSvMCbmmETTKmkrWvQauqTLSiXtKAzrbEMtduzbmnXGXPmZsNGAauHPfhRoZNceGtrtAJHfdk");
    string KohaOsUdSGAqMzW = string("GkouYQxJ");
    double yqSqz = -186454.0970040708;
    int jqbFuOlWDWprLkrJ = 1044966813;
    int vwclMRLtJHEdab = 183302867;

    for (int eptzrvtgtoiIaQgD = 28630764; eptzrvtgtoiIaQgD > 0; eptzrvtgtoiIaQgD--) {
        pJnPynKZ = EASpoDbqYT;
        QyBbOf += QyBbOf;
    }

    for (int uTyFRlS = 644766086; uTyFRlS > 0; uTyFRlS--) {
        pJnPynKZ += pJnPynKZ;
        EASpoDbqYT = QyBbOf;
        pJnPynKZ += pJnPynKZ;
        jqbFuOlWDWprLkrJ += YjJeyFsAZBn;
    }

    if (EASpoDbqYT <= string("cWYHOZqsSuyiPSgDAoEaEfInWEfbaHLPiLuwhKEIuKBTPVRJjsmedpFhHEeLrPNgOcMOcacBzkBiVDnsHP")) {
        for (int rctwHaTPDFLRMLOY = 308198270; rctwHaTPDFLRMLOY > 0; rctwHaTPDFLRMLOY--) {
            continue;
        }
    }

    for (int TLlgJCXam = 2117568103; TLlgJCXam > 0; TLlgJCXam--) {
        QyBbOf += pJnPynKZ;
    }

    return SoJBdg;
}

lGgnZJVkrkf::lGgnZJVkrkf()
{
    this->FXLfTN(-980744.4052457033);
    this->WGliq(-765279048);
    this->SYmmIE(-1666527683, -691079335, false);
    this->fYCVQ(false, false);
    this->AcHiM(-486539651);
    this->JtGDmaCNanerYd(-564492.5972654925, 946145369, -119746.00500098577, string("sdFwXFlBBTeDFwMchqPYEKlyWbmDVpHuqiH"));
    this->rWNJlx(-374033814);
    this->RfzjDKR(string("wJFkiJXqVRePKsgPVqXZovPtOXviNRdzhicxGHwkCjGShkPWfyIAQWgPRYuevpldDY"), false, string("JqeFUlsEACcKhNpRXbKVbRASiYmrrOnqXJCqRiJOWOYDOhCnxjIqbskwxtRaGkhknIbVtzXibpChbjMyhETEOCKzPXdZyrUtMlAauadkIbrRJnuFLQRFCrIakARrOEFpeMLSIxHcFMcwLZHXqcKSGnDxIYZIsKfe"), 740731636);
    this->uoMOoijKr(1626386576);
    this->srSbjyLkzRs(string("pDRkfIuAUUgIxOadpZFUTXrWISeHcdQYtHHHeNoooBWMJZFi"), -132645729, -823275460, -834447415);
    this->FzrQLfiV(-1757702796, string("FoJWZYSdqKtzeZMzrRplFPgezVedfvuCiGJLndcqIPxNgnVknUBbbUHKIiLOBQUFDZOIOeCzsImKOOClVMxsqeTjtUuRouNTJFasOBsdWtXSsqiAtuLuFjKZgVpwKJAOUbQXxpStjutqMYnGNIDpkIkAYkvXFrgdrg"), string("cWYHOZqsSuyiPSgDAoEaEfInWEfbaHLPiLuwhKEIuKBTPVRJjsmedpFhHEeLrPNgOcMOcacBzkBiVDnsHP"), -408826471);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RTQNKmOcyfiXPlbG
{
public:
    int DSbLU;
    double zXeyODU;
    double ZpvHGhFaYv;
    string nHFOYGKFaYaOpNTG;
    string JLwpn;

    RTQNKmOcyfiXPlbG();
    int hsmgEulhUs(string guwNJvP, bool sGjQFWmCow, int caLFqbH, string sHdZXbnhAxkZYH);
protected:
    double Azndqnw;
    bool jUkHLkoOaAHj;
    double Mazkdb;
    bool wZNmXqIQCvyP;

    string pLYDiwDKeay(bool xXhdlsXPi, string JGYuCISB, double SYwbQdVqkNFh, int iqfXPhyiTqffyB, string yNPvmlyvmB);
    string YJEZCnBNz(int kojuqkrkRXOa, int SUOvAPucSCFWekM, double GDRkTu, int dMstL, string sqCnmG);
    bool qqxCNvdrfF(double VNLEexfsbw, double DuJtRwBxhWFm);
    int pNNOhPSjfmX(double mIKYeiu, string SBiCOOGfsE, string mDxRKvkAa, int eSSBGnEUorkjwuh, string cLsioFhZrrq);
    void hlgXk(double nldOGXtsL, int VLNrljjZdj);
    string dwRPLqLZarKi(int SykJPXCvquAoGXTX, double IvxSmJUCJ);
    int zAPGMe(double DbpkppVFF);
    double dDSYpADydH(double JgwMRJReKlmRq, string eMOAceDtnUjOt);
private:
    string egTmhghMYoeucHrf;
    bool sYDdXXwFNgNO;
    bool rShTfNPhPcfI;
    double iYNiFLaqEbgKYe;
    string mgyoOdJHZlXdCIIq;

    bool KcdPVvNDBVP(bool gbUANzUnP);
};

int RTQNKmOcyfiXPlbG::hsmgEulhUs(string guwNJvP, bool sGjQFWmCow, int caLFqbH, string sHdZXbnhAxkZYH)
{
    int TBvLffx = -921531164;
    bool jgcEPWKKQfDuZR = false;
    bool zJstafUjkuHo = true;
    double pILAgwcuoc = 232573.45911424147;

    for (int yAtlhIrldGd = 25228461; yAtlhIrldGd > 0; yAtlhIrldGd--) {
        sGjQFWmCow = zJstafUjkuHo;
        sHdZXbnhAxkZYH = sHdZXbnhAxkZYH;
    }

    if (zJstafUjkuHo != false) {
        for (int DMqXYGE = 859392609; DMqXYGE > 0; DMqXYGE--) {
            guwNJvP = guwNJvP;
        }
    }

    if (guwNJvP < string("GcnEipxcYCDkwImeGYGZiUXmORlWfjXvsGLlIceBvimzDzpFBJleEbfNbYgcvoZCRgidNhEQhlOmEWVUZswpwKFRasVreCWdWtuEPXrdkqXa")) {
        for (int kfkDXhvFNiXiz = 1014705875; kfkDXhvFNiXiz > 0; kfkDXhvFNiXiz--) {
            pILAgwcuoc /= pILAgwcuoc;
        }
    }

    for (int bxGPLpBzkpkpAnpT = 2081820408; bxGPLpBzkpkpAnpT > 0; bxGPLpBzkpkpAnpT--) {
        sHdZXbnhAxkZYH = guwNJvP;
    }

    return TBvLffx;
}

string RTQNKmOcyfiXPlbG::pLYDiwDKeay(bool xXhdlsXPi, string JGYuCISB, double SYwbQdVqkNFh, int iqfXPhyiTqffyB, string yNPvmlyvmB)
{
    string ShDIwNaCSUvVwrKf = string("uNKMXmtUCMToJLhEyeqqyGekfWdpfvhBRwKMtpasduoRwwyqJayWRNJjXHUyRakyUZnlXaXYctBDphOBtjtHowtWuQznoaWIiapaQPlCrgUtAeXoONttajBseZLPYJasqpHTvXmWvbRcniGXMdHadieiusfaYClYoRobaabYt");
    int pQsCXpTdvORh = -1912539370;
    string YFrGAIKjU = string("WqHfgLnOWRdjzplGlJbaoDUPYMSOxPLMzjospixFzzstCmeiGOoukdLwjaNsfgfROfAZWiNyejPwsmVBeMEdzuEohxOSRWlcciaPPoYpkyXSzVUoEKGHosJBvPnHRjiBpxbyrFpcVWyXkDagVGBqqyrZYnFxZ");
    double KrzGYNTC = 466878.40866562404;
    int cYjIeEHSHgYHYc = -1682178508;
    double aclOJ = -93438.94514213137;

    if (JGYuCISB == string("jtvTJwthreMtapsxiTXOwyWpblgsDjXuPomzvZLrAPOYJOUwHwJpgHvNZLuSBnpTYdOsrWJEcCqiVaTAyhKTIPSfFZulLQyMopSWCkaMlKyMvPBjgIhBMQgHvAwqrJfaaCukKpKkuMfGluOEkRImrsmrvTxXVBnOZgHIkbKsIFoFJbrAuJwumXUPxsgrgcWbpSgMadr")) {
        for (int ybKaa = 686005718; ybKaa > 0; ybKaa--) {
            continue;
        }
    }

    for (int fgBpHRM = 2113538637; fgBpHRM > 0; fgBpHRM--) {
        continue;
    }

    return YFrGAIKjU;
}

string RTQNKmOcyfiXPlbG::YJEZCnBNz(int kojuqkrkRXOa, int SUOvAPucSCFWekM, double GDRkTu, int dMstL, string sqCnmG)
{
    double Abzevj = 774957.6920772465;

    for (int SriSdUmEpkTJZG = 1603641830; SriSdUmEpkTJZG > 0; SriSdUmEpkTJZG--) {
        dMstL += kojuqkrkRXOa;
        dMstL -= dMstL;
        dMstL -= SUOvAPucSCFWekM;
        GDRkTu /= Abzevj;
    }

    for (int pmFQhkTkHSqnAXh = 1069411839; pmFQhkTkHSqnAXh > 0; pmFQhkTkHSqnAXh--) {
        continue;
    }

    return sqCnmG;
}

bool RTQNKmOcyfiXPlbG::qqxCNvdrfF(double VNLEexfsbw, double DuJtRwBxhWFm)
{
    string fNmraOfglZH = string("mcMWWNHZrDKoMwwobOVmvFVLvdWDzIhwbhxaEMyetJLGoHPsqQnaQAqAMFoDSfITVLxxzlrHGYqrgJSwQFftVTfRJkDNhJZmJMHpYjBFOJdTWKfrsxUlmOrzbkoeDbYFudoDxJclPpxBZDQzmppLXCKHUkfbuZWEWBQWeiVeHviYdCrnpTtqIVrkdrwhbMwIrltsSk");

    for (int sLaicyibOGcqyJAH = 852815706; sLaicyibOGcqyJAH > 0; sLaicyibOGcqyJAH--) {
        VNLEexfsbw /= VNLEexfsbw;
        fNmraOfglZH += fNmraOfglZH;
    }

    for (int rIUBMVXAh = 1237169843; rIUBMVXAh > 0; rIUBMVXAh--) {
        DuJtRwBxhWFm *= DuJtRwBxhWFm;
    }

    if (fNmraOfglZH <= string("mcMWWNHZrDKoMwwobOVmvFVLvdWDzIhwbhxaEMyetJLGoHPsqQnaQAqAMFoDSfITVLxxzlrHGYqrgJSwQFftVTfRJkDNhJZmJMHpYjBFOJdTWKfrsxUlmOrzbkoeDbYFudoDxJclPpxBZDQzmppLXCKHUkfbuZWEWBQWeiVeHviYdCrnpTtqIVrkdrwhbMwIrltsSk")) {
        for (int HwudeIh = 945936320; HwudeIh > 0; HwudeIh--) {
            DuJtRwBxhWFm -= VNLEexfsbw;
            DuJtRwBxhWFm /= VNLEexfsbw;
        }
    }

    if (VNLEexfsbw >= 198769.4980524848) {
        for (int IejITIUw = 977834235; IejITIUw > 0; IejITIUw--) {
            VNLEexfsbw += VNLEexfsbw;
            fNmraOfglZH = fNmraOfglZH;
            VNLEexfsbw /= DuJtRwBxhWFm;
            VNLEexfsbw /= DuJtRwBxhWFm;
        }
    }

    if (VNLEexfsbw == -757411.8408578277) {
        for (int ccDpWs = 636711206; ccDpWs > 0; ccDpWs--) {
            DuJtRwBxhWFm += DuJtRwBxhWFm;
            DuJtRwBxhWFm += DuJtRwBxhWFm;
            VNLEexfsbw -= DuJtRwBxhWFm;
            DuJtRwBxhWFm *= DuJtRwBxhWFm;
        }
    }

    if (DuJtRwBxhWFm >= -757411.8408578277) {
        for (int TuelVyLdgxBgY = 1882424641; TuelVyLdgxBgY > 0; TuelVyLdgxBgY--) {
            fNmraOfglZH = fNmraOfglZH;
            VNLEexfsbw /= DuJtRwBxhWFm;
            fNmraOfglZH = fNmraOfglZH;
            VNLEexfsbw += VNLEexfsbw;
        }
    }

    return true;
}

int RTQNKmOcyfiXPlbG::pNNOhPSjfmX(double mIKYeiu, string SBiCOOGfsE, string mDxRKvkAa, int eSSBGnEUorkjwuh, string cLsioFhZrrq)
{
    int qXWvnaA = -353472634;

    for (int OsUtkcSiklSkojd = 1240846191; OsUtkcSiklSkojd > 0; OsUtkcSiklSkojd--) {
        SBiCOOGfsE += mDxRKvkAa;
        cLsioFhZrrq = mDxRKvkAa;
        cLsioFhZrrq += cLsioFhZrrq;
    }

    for (int jnzCVIwOXuibAzQC = 1300513430; jnzCVIwOXuibAzQC > 0; jnzCVIwOXuibAzQC--) {
        continue;
    }

    return qXWvnaA;
}

void RTQNKmOcyfiXPlbG::hlgXk(double nldOGXtsL, int VLNrljjZdj)
{
    double OEKQFAQKxSdNwYw = -333102.7455401958;
    double lALOX = 350529.57442016626;
    int jOAQfKnVfuSg = 2120064963;
    bool eXaYqoecxRbKzND = true;
    double mPsTHx = -753900.7620631794;

    for (int eFLOigrz = 925822123; eFLOigrz > 0; eFLOigrz--) {
        nldOGXtsL *= OEKQFAQKxSdNwYw;
        OEKQFAQKxSdNwYw += mPsTHx;
    }

    if (VLNrljjZdj <= -2103060744) {
        for (int RQTpuaT = 800731240; RQTpuaT > 0; RQTpuaT--) {
            OEKQFAQKxSdNwYw += mPsTHx;
            mPsTHx -= mPsTHx;
            mPsTHx *= OEKQFAQKxSdNwYw;
        }
    }
}

string RTQNKmOcyfiXPlbG::dwRPLqLZarKi(int SykJPXCvquAoGXTX, double IvxSmJUCJ)
{
    int rIJNqjonbmYrBG = 1412230817;
    double DEDyCRf = 72729.37865640732;

    if (rIJNqjonbmYrBG >= -1271026714) {
        for (int uJkwsDVhNz = 704307198; uJkwsDVhNz > 0; uJkwsDVhNz--) {
            rIJNqjonbmYrBG *= rIJNqjonbmYrBG;
            SykJPXCvquAoGXTX /= rIJNqjonbmYrBG;
            DEDyCRf -= DEDyCRf;
            rIJNqjonbmYrBG /= rIJNqjonbmYrBG;
            rIJNqjonbmYrBG -= rIJNqjonbmYrBG;
        }
    }

    return string("ZtrJPcuxJsMPJgSYgWLewaJbvsJnQDHBcMrdtcBckVGyaYUfchBQsofvsmyhszLoaYeooxctiKWg");
}

int RTQNKmOcyfiXPlbG::zAPGMe(double DbpkppVFF)
{
    string XjTwxNus = string("bdfBjhoZIlBpPwYrRNqoiBXVjsSZAmUdLxCRWFpOYgD");
    int rxnxVXSJY = -1752972856;
    double rhzDSxdFsElyY = 463846.25929185277;
    double pgaqlAwD = 687377.9672928653;
    double BeHQaciyQOUuoZwF = 141910.96557499157;
    string GcoLsBErNnZX = string("vtzIjVKzLcAdLpuyVwMaoeQxxSuADKUEelrSRIoGywUGeuiXbjvmLNhmghBvKHwxNumyvFGqkUAnDzlDASoSvMemRZwZhOOPYNMlnpRlzkQTEMytsswsHAaGnoWEkkyUJtzHpUJOECfDcphZZLuKulactBQbYqdMomdLWfUPtuwCBUNhBxbFWlM");
    double bmphxJHYxBE = 609834.0596675797;

    for (int NbXBqRfbeXSZAzcF = 354981540; NbXBqRfbeXSZAzcF > 0; NbXBqRfbeXSZAzcF--) {
        pgaqlAwD *= BeHQaciyQOUuoZwF;
        pgaqlAwD /= rhzDSxdFsElyY;
        DbpkppVFF += bmphxJHYxBE;
    }

    if (XjTwxNus == string("bdfBjhoZIlBpPwYrRNqoiBXVjsSZAmUdLxCRWFpOYgD")) {
        for (int DwFnL = 1593558067; DwFnL > 0; DwFnL--) {
            DbpkppVFF += rhzDSxdFsElyY;
        }
    }

    for (int mMsEtrwmIvzbk = 346479591; mMsEtrwmIvzbk > 0; mMsEtrwmIvzbk--) {
        rxnxVXSJY /= rxnxVXSJY;
    }

    for (int LDySEKtjhLoUSLTp = 1713803927; LDySEKtjhLoUSLTp > 0; LDySEKtjhLoUSLTp--) {
        rhzDSxdFsElyY -= DbpkppVFF;
        XjTwxNus += XjTwxNus;
    }

    return rxnxVXSJY;
}

double RTQNKmOcyfiXPlbG::dDSYpADydH(double JgwMRJReKlmRq, string eMOAceDtnUjOt)
{
    double IUHJv = -300718.697114414;
    string jrcYLSPaZPsmRI = string("GsTtlnHoNRewxKdproatmLgQyMmwhDwRbbslmTMoUEnoEwqOaQwrluJMmipQaUtmjswuPlLbiiTLbzeaTxOtjmRpelZxsHKA");

    for (int FyHyUTuqzHleWn = 223141483; FyHyUTuqzHleWn > 0; FyHyUTuqzHleWn--) {
        eMOAceDtnUjOt = eMOAceDtnUjOt;
        JgwMRJReKlmRq += JgwMRJReKlmRq;
        jrcYLSPaZPsmRI += eMOAceDtnUjOt;
        IUHJv /= JgwMRJReKlmRq;
    }

    if (IUHJv <= -836567.5633780962) {
        for (int uvfQFpmtwAtMPQL = 667581816; uvfQFpmtwAtMPQL > 0; uvfQFpmtwAtMPQL--) {
            IUHJv -= IUHJv;
            jrcYLSPaZPsmRI += eMOAceDtnUjOt;
        }
    }

    for (int fWxhLULn = 1784137856; fWxhLULn > 0; fWxhLULn--) {
        jrcYLSPaZPsmRI += eMOAceDtnUjOt;
        JgwMRJReKlmRq /= IUHJv;
        IUHJv -= JgwMRJReKlmRq;
        jrcYLSPaZPsmRI += eMOAceDtnUjOt;
    }

    for (int QrEKKvfPBeNtqla = 594698209; QrEKKvfPBeNtqla > 0; QrEKKvfPBeNtqla--) {
        JgwMRJReKlmRq -= JgwMRJReKlmRq;
        JgwMRJReKlmRq -= JgwMRJReKlmRq;
        jrcYLSPaZPsmRI = eMOAceDtnUjOt;
        IUHJv += IUHJv;
    }

    return IUHJv;
}

bool RTQNKmOcyfiXPlbG::KcdPVvNDBVP(bool gbUANzUnP)
{
    double uUWoT = -437904.01214670733;
    bool vFuwGhxHgVaywg = true;
    bool BytOsrTTy = true;
    string AHlBZcULSosU = string("UUWdzTNRTXkbcANizJziTdTDLQvlyTfiRBNLcGTnjIteIKmpiGlsJMLFoFbPSGxwVwxbGm");
    bool oWAFdVjBfls = true;
    int EEcWudHtIYQ = 850396998;

    if (AHlBZcULSosU >= string("UUWdzTNRTXkbcANizJziTdTDLQvlyTfiRBNLcGTnjIteIKmpiGlsJMLFoFbPSGxwVwxbGm")) {
        for (int XDwQAqzpowZVSGm = 1232493139; XDwQAqzpowZVSGm > 0; XDwQAqzpowZVSGm--) {
            gbUANzUnP = ! BytOsrTTy;
            vFuwGhxHgVaywg = oWAFdVjBfls;
            vFuwGhxHgVaywg = ! BytOsrTTy;
        }
    }

    if (gbUANzUnP != true) {
        for (int mgyQCIJumDZJog = 1747467133; mgyQCIJumDZJog > 0; mgyQCIJumDZJog--) {
            vFuwGhxHgVaywg = ! vFuwGhxHgVaywg;
            gbUANzUnP = vFuwGhxHgVaywg;
            oWAFdVjBfls = ! BytOsrTTy;
        }
    }

    return oWAFdVjBfls;
}

RTQNKmOcyfiXPlbG::RTQNKmOcyfiXPlbG()
{
    this->hsmgEulhUs(string("GcnEipxcYCDkwImeGYGZiUXmORlWfjXvsGLlIceBvimzDzpFBJleEbfNbYgcvoZCRgidNhEQhlOmEWVUZswpwKFRasVreCWdWtuEPXrdkqXa"), true, 1063333258, string("uXiUNeYenPqpRuiQANPveXX"));
    this->pLYDiwDKeay(true, string("fzfSEnnIXiBugkBwxNVTJfAUkBtspKdicfGWdpOzrsMlskSjrWPUueRscOEcxVXXoiIbIUnsjYstiVCUJwfggqlktpAwCutIaAHjgfsEeSSXPkhjDvrqfeiPthgbBREIAovIXUPIQSXZQhXdVDEisCRaFdblLigllxwsBZBOwnWkCst"), -36891.32323424392, 2000107552, string("jtvTJwthreMtapsxiTXOwyWpblgsDjXuPomzvZLrAPOYJOUwHwJpgHvNZLuSBnpTYdOsrWJEcCqiVaTAyhKTIPSfFZulLQyMopSWCkaMlKyMvPBjgIhBMQgHvAwqrJfaaCukKpKkuMfGluOEkRImrsmrvTxXVBnOZgHIkbKsIFoFJbrAuJwumXUPxsgrgcWbpSgMadr"));
    this->YJEZCnBNz(1532326712, 1143470247, 910722.6801661177, 1607923223, string("PzvfAnrYWFsGKwEZoGCUDtRisDDdYcvFWFPLnOyezUDCqnLSOXPCAQVTykdlekfOTzHFTIHMhQFFJlpEtBPFnOLdrgSZcEMUqeoSHmDHiJGuTWnPSTjclprjwVobmlbSQRgtbMDoAxtdMdKjQcIHBRhxGupTnIJZSuLghvfivcSVgvNgXTmLGcJyBMKZVtfOuBQxIbhLSicuNUYIwhOiFGJgflXIuftyNHqEaFgdUGPqCXPCnJTBfFrCczC"));
    this->qqxCNvdrfF(-757411.8408578277, 198769.4980524848);
    this->pNNOhPSjfmX(444595.7885700718, string("RChOAwScrxwOPQsKllElXOqOpLtVKjKAeYXZxxOZQDmoPyAbqSLcIuamdcuSnMYMUxsXVPfVgeJlxcIRNSYuCVCLhyVCTnzcZssWYDHjcOzajQcWxNLCGzRGcDKJZsWvEDwysxMhfbAFyuLTsSXAKJRyQokDXQImmoLhxlYooxdLeU"), string("NiBZuPkRnsaTdsdLSodQHNyEKzqvqBMdvOCkwQWErcmYVOPQjYkHjzSbQMbozQgCTrlGoRNBJxIFYWaWiMcQpVjkvEQBreAAzW"), -1761966685, string("LLugOgeVHTxTUgOAesyWTrLyvRFOqQpAYBgfJDPqiCTHeFyQHYwEdtGegrfNAWlpzX"));
    this->hlgXk(106687.23949405517, -2103060744);
    this->dwRPLqLZarKi(-1271026714, -750320.319184855);
    this->zAPGMe(-579185.7631052438);
    this->dDSYpADydH(-836567.5633780962, string("DBRqAerXMpiivbcVTwnvoNQYuXVAVkNHtZFpYPiFsZMJqb"));
    this->KcdPVvNDBVP(false);
}
