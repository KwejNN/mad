#include "profile_info_changer.h"
#include "../../valve_sdk/sdk.hpp"

#include "ProtoParse.h"
#include "ProtobuffMessages.h"
#include "../../options.hpp"



std::string profile_info_changer(void* pubDest, uint32_t* pcubMsgSize)
{
	MatchmakingGC2ClientHello msg((void*)((DWORD)pubDest + 8), *pcubMsgSize - 8);
	MatchmakingGC2ClientHello::PlayerCommendationInfo commendations;
	commendations.cmd_friendly().set(g_Options.Profile_Info_Friendly);
	commendations.cmd_teaching().set(g_Options.Profile_Info_Teacher);
	commendations.cmd_leader().set(g_Options.Profile_Info_Leader);
	msg.commendation().set(commendations);
	MatchmakingGC2ClientHello::PlayerRankingInfo ranking;
	ranking.account_id().set(g_SteamUser->GetSteamID().GetAccountID());
	ranking.rank_id().set(g_Options.Profile_Info_Rank_Combo);
	ranking.wins().set(g_Options.Profile_Info_Win);
	msg.ranking().set(ranking);
	msg.player_level().set(g_Options.Profile_Info_Rank);
	msg.player_cur_xd_level().set(g_Options.Profile_Info_XP);
	if (g_Options.time != 0 && g_Options.ban != 0)
	{
		msg.penalty_seconds().set(g_Options.time);
		msg.penalty_reason().set(g_Options.ban);
	}
	return msg.serialize();

}










#pragma region Helper Functions
std::string Field::getBytesVarint32(uint32_t value)
{
	uint8_t bytes[kMaxVarint32Bytes];
	int size = 0;
	while (value > 0x7F) {
		bytes[size++] = (static_cast<uint8_t>(value) & 0x7F) | 0x80;
		value >>= 7;
	}
	bytes[size++] = static_cast<uint8_t>(value) & 0x7F;
	return std::string{ reinterpret_cast<const char*>(&bytes[0]), (size_t)size };
}

std::string Field::getBytesVarint64(uint64_t value)
{
	uint8_t bytes[kMaxVarintBytes];
	int size = 0;
	while (value > 0x7F) {
		bytes[size++] = (static_cast<uint8_t>(value) & 0x7F) | 0x80;
		value >>= 7;
	}
	bytes[size++] = static_cast<uint8_t>(value) & 0x7F;
	return std::string{ reinterpret_cast<const char*>(&bytes[0]), (size_t)size };
}

uint32_t Field::readVarUint32(void* data, size_t& bytesRead)
{
	auto ptr = reinterpret_cast<const uint8_t*>(data);
	auto value = 0u;
	auto bytes = 0u;

	do {
		value |= static_cast<uint32_t>(*ptr & 0x7f) << (7 * bytes);
		bytes++;
	} while (*(ptr++) & 0x80 && bytes <= 5);

	bytesRead = bytes;
	return value;
}

uint64_t Field::readVarUint64(void* data, size_t& bytesRead)
{
	auto ptr = reinterpret_cast<const uint8_t*>(data);
	auto value = 0ull;
	auto bytes = 0u;

	do
	{
		value |= static_cast<uint64_t>(*ptr & 0x7f) << (7 * bytes);
		bytes++;
	} while (*(ptr++) & 0x80 && bytes <= 10);

	bytesRead = bytes;

	return value;
}

Field Field::ReadField(void* data, size_t& bytesRead)
{
	unsigned field = *reinterpret_cast<uint16_t*>(data);
	unsigned type = field & kTagTypeMask;

	if (field == 0xffff) {
		bytesRead = 0;
		return Field();
	}

	if (field & 0x80) {
		field = ((field & 0x7f) | ((field & 0xff00) >> 1)) >> kTagTypeBits;
		bytesRead = 2;
	}
	else {
		field = (field & 0xff) >> kTagTypeBits;
		bytesRead = 1;
	}

	size_t length, sizeDelimited;
	std::string value, full;
	switch (type)
	{
	case WIRETYPE_VARINT:
		readVarUint64((void*)((ptrdiff_t)data + bytesRead), length);
		value = std::string{ reinterpret_cast<const char*>((void*)((ptrdiff_t)data + bytesRead)), length };
		full = std::string{ reinterpret_cast<const char*>(data), bytesRead + length };
		bytesRead += length;
		break;
	case WIRETYPE_FIXED64:
		value = std::string{ reinterpret_cast<const char*>((void*)((ptrdiff_t)data + bytesRead)), 8 };
		full = std::string{ reinterpret_cast<const char*>(data), bytesRead + 8 };
		bytesRead += 8;
		break;
	case WIRETYPE_LENGTH_DELIMITED:
		sizeDelimited = readVarUint32((void*)((ptrdiff_t)data + bytesRead), length);
		value = std::string{ reinterpret_cast<const char*>((void*)((ptrdiff_t)data + bytesRead)), length + sizeDelimited };
		full = std::string{ reinterpret_cast<const char*>(data), bytesRead + length + sizeDelimited };
		bytesRead += length + sizeDelimited;
		break;
	case WIRETYPE_START_GROUP:
		throw("WIRETYPE_START_GROUP unrealised");
		break;
	case WIRETYPE_END_GROUP:
		throw("WIRETYPE_END_GROUP unrealised");
		break;
	case WIRETYPE_FIXED32:
		value = std::string{ reinterpret_cast<const char*>((void*)((ptrdiff_t)data + bytesRead)), 4 };
		full = std::string{ reinterpret_cast<const char*>(data), bytesRead + 4 };
		bytesRead += 4;
		break;
	default:
		throw("Unknown type %i", type);
		break;
	}


	return Field(field, type, value, full);
}

#pragma endregion 

#pragma region Field Definition
Field& Field::operator=(const Field& f) {
	this->tag = f.tag;
	this->value = f.value;
	this->full = f.full;
	return *this;
}

Field::Field(unsigned field, unsigned type, std::string value, std::string full) {
	this->tag = { field, type };
	this->value = value;
	this->full = full;
}

template<typename T>
Field::Field(Tag tag, T value) {
	auto wireType = kWireTypeForFieldType[tag.type];
	full = getBytesVarint32(MAKE_TAG(tag.field, wireType));

	switch (wireType) {
	case WIRETYPE_VARINT:
		full += getBytesVarint64(static_cast<uint64_t>(value));
		break;
	case WIRETYPE_FIXED32:
		full += std::string{ reinterpret_cast<const char*>(&value), 4 };
		break;
	case WIRETYPE_FIXED64:
		full += std::string{ reinterpret_cast<const char*>(&value), 8 };
		break;
	}
}

template<typename T>
Field::Field(unsigned field, unsigned type, T value) {
	auto wireType = kWireTypeForFieldType[type];
	tag = { field, (unsigned)wireType };
	full = getBytesVarint32(MAKE_TAG(field, wireType));

	switch (wireType) {
	case WIRETYPE_VARINT:
		full += getBytesVarint64(static_cast<uint64_t>(value));
		break;
	case WIRETYPE_FIXED32:
		full += std::string{ reinterpret_cast<const char*>(&value), 4 };
		break;
	case WIRETYPE_FIXED64:
		full += std::string{ reinterpret_cast<const char*>(&value), 8 };
		break;
	}
}

Field::Field(Tag tag, std::string value) {
	auto wireType = kWireTypeForFieldType[tag.type];
	full = getBytesVarint32(MAKE_TAG(tag.field, wireType));
	full += getBytesVarint32(value.size());
	full += value;
}

Field::Field(unsigned field, unsigned type, std::string value) {
	auto wireType = kWireTypeForFieldType[type];
	tag = { field, (unsigned)wireType };
	full = getBytesVarint32(MAKE_TAG(field, wireType));
	full += getBytesVarint32(value.size());
	full += value;
}


float Field::Float() {
	return *reinterpret_cast<float*>((void*)value.data());
}
double Field::Double() {
	return *reinterpret_cast<double*>((void*)value.data());
}
int32_t Field::Int32() {
	size_t bytesRead;
	return static_cast<int32_t>(readVarUint64((void*)value.data(), bytesRead));
}
int64_t Field::Int64() {
	size_t bytesRead;
	return readVarUint64((void*)value.data(), bytesRead);
}
uint32_t Field::UInt32() {
	size_t bytesRead;
	return readVarUint32((void*)value.data(), bytesRead);
}
uint64_t Field::UInt64() {
	size_t bytesRead;
	return readVarUint64((void*)value.data(), bytesRead);
}
uint32_t Field::Fixed32() {
	return *reinterpret_cast<uint32_t*>((void*)value.data());
}
uint64_t Field::Fixed64() {
	return *reinterpret_cast<uint64_t*>((void*)value.data());
}
int32_t Field::SFixed32() {
	return *reinterpret_cast<int32_t*>((void*)value.data());
}
int64_t Field::SFixed64() {
	return *reinterpret_cast<int64_t*>((void*)value.data());
}
bool Field::Bool() {
	size_t bytesRead;
	return !!readVarUint32((void*)value.data(), bytesRead);
}

std::string Field::String()
{
	size_t bytesRead;
	void* data = (void*)value.data();
	auto length = readVarUint32((void*)value.data(), bytesRead);
	auto value = std::string{ reinterpret_cast<const char*>((void*)((ptrdiff_t)data + bytesRead)), length };
	return value;
}

#pragma endregion

#pragma region ProtoWriter Definition
ProtoWriter::ProtoWriter()
{

}

ProtoWriter::ProtoWriter(size_t maxFields)
{
	size_t vector_size = maxFields + 1;
	fields.resize(vector_size);
	fields.reserve(vector_size);
}

ProtoWriter::ProtoWriter(void* data, size_t size, size_t maxFields) : ProtoWriter(maxFields)
{
	size_t vector_size = maxFields + 1,
		pos = 0,
		bytesRead;

	if (data == nullptr)
		return;
	// parse packet
	while (pos < size) {
		auto field = Field::ReadField((void*)((ptrdiff_t)data + pos), bytesRead);
		if (!bytesRead) break;

		auto index = field.tag.field;
		if (index >= vector_size) throw("fields range error: field[%i]", index);
		fields[index].push_back(field);
		pos += bytesRead;
	}
}

ProtoWriter::ProtoWriter(std::string dataStr, size_t maxFields) : ProtoWriter((void*)dataStr.data(), dataStr.size(), maxFields)
{

}

std::string ProtoWriter::serialize()
{
	std::string result;
	for (auto& f0 : fields) {
		for (auto& f1 : f0) {
			result += f1.full;
		}
	}
	return result;
}

void ProtoWriter::print()
{
	auto data = serialize();
	void* mem = (void*)data.data();
	size_t size = data.size();
	int j = 0;
	for (size_t i = 0; i <= size; ++i) {
		printf("%.2X ", *(unsigned char*)((uintptr_t)mem + i));
		j++;
		if (j == 16)
		{
			j = 0;
			printf("\n");
		}
	}
	printf("\n");
}

void ProtoWriter::add(Field field)
{
	fields[field.tag.field].push_back(field);
}

void ProtoWriter::replace(Field field)
{
	fields[field.tag.field].clear();
	fields[field.tag.field].push_back(field);
}

void ProtoWriter::replace(Field field, uint32_t index)
{
	fields[field.tag.field][index] = field;
}

void ProtoWriter::clear(unsigned fieldId)
{
	return fields[fieldId].clear();
}

bool ProtoWriter::has(unsigned fieldId)
{
	return fields[fieldId].size() > 0;
}

Field ProtoWriter::get(unsigned fieldId)
{
	if (fields[fieldId].empty())
		return Field();
	return fields[fieldId][0];
}

std::vector<Field> ProtoWriter::getAll(unsigned fieldId)
{
	return fields[fieldId];
}

template<typename T>
void ProtoWriter::add(Tag tag, T value)
{
	fields[tag.field].push_back(Field(tag, value));
}

template<typename T>
void ProtoWriter::replace(Tag tag, T value)
{
	fields[tag.field].clear();
	fields[tag.field].push_back(Field(tag, value));
}

template<typename T>
void ProtoWriter::replace(Tag tag, T value, uint32_t index)
{
	fields[tag.field][index] = Field(tag, value);
}

void ProtoWriter::add(Tag tag, std::string value)
{
	fields[tag.field].push_back(Field(tag, value));
}

void ProtoWriter::replace(Tag tag, std::string value)
{
	fields[tag.field].clear();
	fields[tag.field].push_back(Field(tag, value));
}

void ProtoWriter::replace(Tag tag, std::string value, uint32_t index)
{
	fields[tag.field][index] = Field(tag, value);
}

void ProtoWriter::clear(Tag tag)
{
	return fields[tag.field].clear();
}

bool ProtoWriter::has(Tag tag)
{
	return fields[tag.field].size() > 0;
}

Field ProtoWriter::get(Tag tag)
{
	if (fields[tag.field].empty())
		return Field();
	return fields[tag.field][0];
}

std::vector<Field> ProtoWriter::getAll(Tag tag)
{
	return fields[tag.field];
}

#pragma endregion




#include "../Protobuffs.h"






















#include "inventory_changer.h"




template<typename T>
inline std::string get_4bytes(T value)
{
	return std::string{ reinterpret_cast<const char*>(reinterpret_cast<void*>(&value)), 4 };
}

template<typename T>
inline CSOEconItemAttribute make_econ_item_attribute(int def_index, T value)
{
	CSOEconItemAttribute attribute;
	attribute.def_index().set(def_index);
	attribute.value_bytes().set(get_4bytes(value));
	return attribute;
}

inline CSOEconItemEquipped make_equipped_state(int team, int slot)
{
	CSOEconItemEquipped equipped_state;
	equipped_state.new_class().set(team);
	equipped_state.new_slot().set(slot);
	return equipped_state;
}

static std::string inventory_changer(void* pubDest, uint32_t* pcubMsgSize) {
	CMsgClientWelcome msg((void*)((DWORD)pubDest + 8), *pcubMsgSize - 8);
	if (!msg.outofdate_subscribed_caches().has())
		return msg.serialize();

	auto cache = msg.outofdate_subscribed_caches().get();

	static auto fix_null_inventory = [&cache]()
	{
		auto objects = cache.objects().get_all();
		auto it = std::find_if(objects.begin(), objects.end(), [](decltype(objects.front()) o)
		{
			return o.type_id().has() && o.type_id().get() == 1;
		});

		// inventory not exist, need create
		if (it == objects.end())
		{
			CMsgClientWelcome::SubscribedType null_object;
			null_object.type_id().set(1);
			cache.objects().add(null_object);
		}
	};

	// If not have items in inventory, Create null inventory
	fix_null_inventory();

	// Add custom items
	auto objects = cache.objects().get_all();
	for (size_t i = 0; i < objects.size(); i++) {
		auto object = objects[i];

		if (!object.type_id().has())
			continue;

		switch (object.type_id().get())
		{
		case 1: // Inventory
		{
			if (true) //g_Options.skins_packet_clear_default_items
				object.object_data().clear();

			clear_equip_state(object);
			//apply_medals(object);
			//apply_music_kits(object);
			add_all_items(object);
			cache.objects().set(object, i);
		}
		break;
		}
	}
	msg.outofdate_subscribed_caches().set(cache);

	return msg.serialize();
}

static bool inventory_changer_presend(void* pubData, uint32_t& cubData)
{
	CMsgAdjustItemEquippedState msg((void*)((DWORD)pubData + 8), cubData - 8);
	// Change music kit check
	if (msg.item_id().has() && (msg.new_class().get() == 0 || msg.new_slot().get() == 54))
	{
		auto ItemIndex = msg.item_id().get() - START_MUSICKIT_INDEX;

		if (ItemIndex > 38 || ItemIndex < 3)
			return true;

		/*g_Options.skins_packets_musci_kit = */msg.new_slot().get() == 0xFFFF ? 0 : ItemIndex - 2;

		return false;
	}
	// Change weapon skin check
	if (!msg.item_id().has() || !msg.new_class().get() || !msg.new_slot().get())
		return true;

	return false;
}


static void clear_equip_state(CMsgClientWelcome::SubscribedType& object)
{
	auto object_data = object.object_data().get_all();
	for (size_t j = 0; j < object_data.size(); j++)
	{
		auto item = object_data[j];

		if (!item.equipped_state().has())
			continue;

		// create NOT equiped state for item
		auto null_equipped_state = make_equipped_state(0, 0);

		// unequip all
		auto equipped_state = item.equipped_state().get_all();
		for (size_t k = 0; k < equipped_state.size(); k++)
			item.equipped_state().set(null_equipped_state, k);

		object.object_data().set(item, j);
	}
}

std::vector<uint32_t> packets_medals = { 1372, 958, 957, 956, 955 };
int packets_equipped_medal = 874;

static void apply_medals(CMsgClientWelcome::SubscribedType& object)
{
	uint32_t steamid = g_SteamUser->GetSteamID().GetAccountID();

	CSOEconItem medal;
	medal.account_id().set(steamid);
	medal.origin().set(9);
	medal.rarity().set(6);
	medal.quantity().set(1);
	medal.quality().set(4);
	medal.level().set(1);

	// Time acquired attribute
	medal.attribute().set(make_econ_item_attribute(222, (uint32_t)std::time(0)));

	int i = 10000;
	for (uint32_t MedalIndex : packets_medals)
	{
		medal.def_index().set(MedalIndex);
		medal.inventory().set(i);
		medal.id().set(i);
		object.object_data().add(medal);
		i++;
	}

	if (packets_equipped_medal)
	{
		medal.def_index().set(packets_equipped_medal);
		medal.inventory().set(i);
		medal.id().set(i);
		medal.equipped_state().set(make_equipped_state(0, 55));
		object.object_data().add(medal);
	}
}

static void apply_music_kits(CMsgClientWelcome::SubscribedType& object)
{
	uint32_t steamid = g_SteamUser->GetSteamID().GetAccountID();

	CSOEconItem music_kit;
	music_kit.account_id().set(steamid);
	music_kit.origin().set(9);
	music_kit.rarity().set(6);
	music_kit.quantity().set(1);
	music_kit.quality().set(4);
	music_kit.level().set(1);
	music_kit.flags().set(0);
	music_kit.def_index().set(1314);

	// Time acquired attribute
	music_kit.attribute().add(make_econ_item_attribute(75, (uint32_t)std::time(0)));

	int selected_musickit_gui = 16;
	for (int i = 3; i <= 38; ++i)
	{
		if (selected_musickit_gui != i)
		{
			music_kit.attribute().add(make_econ_item_attribute(166, i)); // Music kit id
			music_kit.inventory().set(START_MUSICKIT_INDEX + i);
			music_kit.id().set(START_MUSICKIT_INDEX + i);
			object.object_data().add(music_kit);
		}
	}

	if (selected_musickit_gui)
	{
		music_kit.attribute().add(make_econ_item_attribute(166, selected_musickit_gui)); // Music kit id
		music_kit.inventory().set(START_MUSICKIT_INDEX + selected_musickit_gui);
		music_kit.id().set(START_MUSICKIT_INDEX + selected_musickit_gui);
		music_kit.equipped_state().set(make_equipped_state(0, 54));
		object.object_data().add(music_kit);
	}
}

static void add_all_items(CMsgClientWelcome::SubscribedType& object)
{
	int l = 1;
	for (auto& x : g_skins) {
		add_item(object, l, (ItemDefinitionIndex)x.wId, x.rarity, x.paintkit, x.seed, x.wear, x.stickers, x.sticker_wear, x.sticker_scale, x.sticker_rotaion, x.name);
		l++;
	}
}

int RandomInt(int min, int max)
{
	static auto random_int = reinterpret_cast<int(*)(int, int)>(GetProcAddress(GetModuleHandleA("vstdlib.dll"), "RandomInt"));

	return random_int(min, max);
}

static void add_item(CMsgClientWelcome::SubscribedType& object, int index, short itemIndex, int rarity, int paintKit, int seed, float wear, int stickers[4], float st_w, float st_sc, float st_rt, std::string name)
{
	uint32_t steamid = g_SteamUser->GetSteamID().GetAccountID();
	int c = RandomInt(20000, 50000000);

	CSOEconItem item;
	item.id().set(c + itemIndex);
	item.account_id().set(steamid);
	item.def_index().set(itemIndex);
	item.inventory().set(c + index);
	item.origin().set(24);
	item.quantity().set(1);
	item.level().set(1);
	item.style().set(0);
	item.flags().set(0);
	item.in_use().set(true);
	item.original_id().set(0);
	item.rarity().set(rarity);
	item.quality().set(0);

	if (name.size() > 0)
		item.custom_name().set(name);

	// Add equipped state for both teams
	TeamID avalTeam = GetAvailableClassID(itemIndex);

	if (avalTeam == TeamID::TEAM_SPECTATOR || avalTeam == TeamID::TEAM_TERRORIST) {
		item.equipped_state().add(make_equipped_state(TEAM_TERRORIST, GetSlotID(itemIndex)));
	}
	if (avalTeam == TeamID::TEAM_SPECTATOR || avalTeam == TeamID::TEAM_COUNTER_TERRORIST) {
		item.equipped_state().add(make_equipped_state(TEAM_COUNTER_TERRORIST, GetSlotID(itemIndex)));
	}

	// Add CSOEconItemAttribute's
	item.attribute().add(make_econ_item_attribute(6, float(paintKit)));
	item.attribute().add(make_econ_item_attribute(7, float(seed)));
	item.attribute().add(make_econ_item_attribute(8, float(wear)));

	// Time acquired attribute
	item.attribute().add(make_econ_item_attribute(180, (uint32_t)std::time(0)));

	// Stickers
	for (int j = 0; j < 4; j++)
	{
		item.attribute().add(make_econ_item_attribute(113 + 4 * j, uint32_t(stickers[j]))); // Sticker Kit
		item.attribute().add(make_econ_item_attribute(114 + 4 * j, float(st_w)));     // Sticker Wear
		item.attribute().add(make_econ_item_attribute(115 + 4 * j, float(st_sc)));        // Sticker Scale
		item.attribute().add(make_econ_item_attribute(116 + 4 * j, float(st_rt)));        // Sticker Rotation
	}

	object.object_data().add(item);
}

static TeamID GetAvailableClassID(int definition_index)
{
	switch (definition_index)
	{
	case WEAPON_BAYONET:
	case WEAPON_KNIFE_FLIP:
	case WEAPON_KNIFE_GUT:
	case WEAPON_KNIFE_KARAMBIT:
	case WEAPON_KNIFE_M9_BAYONET:
	case WEAPON_KNIFE_TACTICAL:
	case WEAPON_KNIFE_FALCHION:
	case WEAPON_KNIFE_SURVIVAL_BOWIE:
	case WEAPON_KNIFE_BUTTERFLY:
	case WEAPON_KNIFE_PUSH:
	case WEAPON_ELITE:
	case WEAPON_P250:
	case WEAPON_CZ75A:
	case WEAPON_DEAGLE:
	case WEAPON_REVOLVER:
	case WEAPON_MP7:
	case WEAPON_UMP45:
	case WEAPON_P90:
	case WEAPON_BIZON:
	case WEAPON_SSG08:
	case WEAPON_AWP:
	case WEAPON_NOVA:
	case WEAPON_XM1014:
	case WEAPON_M249:
	case WEAPON_NEGEV:
	case GLOVE_STUDDED_BLOODHOUND:
	case GLOVE_SPORTY:
	case GLOVE_SLICK:
	case GLOVE_LEATHER_WRAP:
	case GLOVE_MOTORCYCLE:
	case GLOVE_SPECIALIST:
		return TeamID::TEAM_SPECTATOR;

	case WEAPON_GLOCK:
	case WEAPON_AK47:
	case WEAPON_MAC10:
	case WEAPON_G3SG1:
	case WEAPON_TEC9:
	case WEAPON_GALILAR:
	case WEAPON_SG556:
	case WEAPON_SAWEDOFF:
		return TeamID::TEAM_TERRORIST;

	case WEAPON_AUG:
	case WEAPON_FAMAS:
	case WEAPON_MAG7:
	case WEAPON_FIVESEVEN:
	case WEAPON_USP_SILENCER:
	case WEAPON_HKP2000:
	case WEAPON_MP9:
	case WEAPON_M4A1_SILENCER:
	case WEAPON_M4A1:
	case WEAPON_SCAR20:
		return TeamID::TEAM_COUNTER_TERRORIST;

	default:
		return TeamID::TEAM_UNASSIGNED;
	}
}

static int GetSlotID(int definition_index)
{
	switch (definition_index)
	{
	case WEAPON_BAYONET:
	case WEAPON_KNIFE_FLIP:
	case WEAPON_KNIFE_GUT:
	case WEAPON_KNIFE_KARAMBIT:
	case WEAPON_KNIFE_M9_BAYONET:
	case WEAPON_KNIFE_TACTICAL:
	case WEAPON_KNIFE_FALCHION:
	case WEAPON_KNIFE_SURVIVAL_BOWIE:
	case WEAPON_KNIFE_BUTTERFLY:
	case WEAPON_KNIFE_PUSH:
		return 0;
	case WEAPON_USP_SILENCER:
	case WEAPON_HKP2000:
	case WEAPON_GLOCK:
		return 2;
	case WEAPON_ELITE:
		return 3;
	case WEAPON_P250:
		return 4;
	case WEAPON_TEC9:
	case WEAPON_CZ75A:
	case WEAPON_FIVESEVEN:
		return 5;
	case WEAPON_DEAGLE:
	case WEAPON_REVOLVER:
		return 6;
	case WEAPON_MP9:
	case WEAPON_MAC10:
		return 8;
	case WEAPON_MP7:
		return 9;
	case WEAPON_UMP45:
		return 10;
	case WEAPON_P90:
		return 11;
	case WEAPON_BIZON:
		return 12;
	case WEAPON_FAMAS:
	case WEAPON_GALILAR:
		return 14;
	case WEAPON_M4A1_SILENCER:
	case WEAPON_M4A1:
	case WEAPON_AK47:
		return 15;
	case WEAPON_SSG08:
		return 16;
	case WEAPON_SG556:
	case WEAPON_AUG:
		return 17;
	case WEAPON_AWP:
		return 18;
	case WEAPON_G3SG1:
	case WEAPON_SCAR20:
		return 19;
	case WEAPON_NOVA:
		return 20;
	case WEAPON_XM1014:
		return 21;
	case WEAPON_SAWEDOFF:
	case WEAPON_MAG7:
		return 22;
	case WEAPON_M249:
		return 23;
	case WEAPON_NEGEV:
		return 24;
	case GLOVE_STUDDED_BLOODHOUND:
	case GLOVE_SPORTY:
	case GLOVE_SLICK:
	case GLOVE_LEATHER_WRAP:
	case GLOVE_MOTORCYCLE:
	case GLOVE_SPECIALIST:
		return 41;
	default:
		return -1;
	}
}


























#define CAST(cast, address, add) reinterpret_cast<cast>((uint32_t)address + (uint32_t)add)

void Protobuffs::WritePacket(std::string packet, void* thisPtr, void* oldEBP, void* pubDest, uint32_t cubDest, uint32_t* pcubMsgSize)
{
	if ((uint32_t)packet.size() <= cubDest - 8)
	{
		memcpy((void*)((DWORD)pubDest + 8), (void*)packet.data(), packet.size());
		*pcubMsgSize = packet.size() + 8;
	}
	else if (g_pMemAlloc)
	{
		auto memPtr = *CAST(void**, thisPtr, 0x14);
		auto memPtrSize = *CAST(uint32_t*, thisPtr, 0x18);
		auto newSize = (memPtrSize - cubDest) + packet.size() + 8;

		auto memory = g_pMemAlloc->Realloc(memPtr, newSize + 4);

		*CAST(void**, thisPtr, 0x14) = memory;
		*CAST(uint32_t*, thisPtr, 0x18) = newSize;
		*CAST(void**, oldEBP, -0x14) = memory;

		memcpy(CAST(void*, memory, 24), (void*)packet.data(), packet.size());

		*pcubMsgSize = packet.size() + 8;
	}
}

void Protobuffs::ReceiveMessage(void* thisPtr, void* oldEBP, uint32_t messageType, void* pubDest, uint32_t cubDest, uint32_t* pcubMsgSize)
{
	if (g_Options.Profile_enable && messageType == k_EMsgGCCStrike15_v2_MatchmakingGC2ClientHello)
	{
		auto packet = profile_info_changer(pubDest, pcubMsgSize);
		WritePacket(packet, thisPtr, oldEBP, pubDest, cubDest, pcubMsgSize);
	}
	else if (g_Options.Profile_enable && messageType == k_EMsgGCCStrike15_v2_ClientGCRankUpdate)
	{
		CMsgGCCStrike15_v2_ClientGCRankUpdate msg((void*)((DWORD)pubDest + 8), *pcubMsgSize - 8);

		auto ranking = msg.ranking().get();

		if (ranking.rank_type_id().get() == 7)
		{
			ranking.rank_id().set(g_Options.wingman_rank);
			ranking.wins().set(g_Options.wingman_wins);
			msg.ranking().set(ranking);
			auto packet = msg.serialize();
			WritePacket(packet, thisPtr, oldEBP, pubDest, cubDest, pcubMsgSize);
		}

		if (ranking.rank_type_id().get() == 10)
		{
			ranking.rank_id().set(g_Options.danger_zone_rank);
			ranking.wins().set(g_Options.danger_zone_wins);
			msg.ranking().set(ranking);
			auto packet = msg.serialize();
			WritePacket(packet, thisPtr, oldEBP, pubDest, cubDest, pcubMsgSize);
		}
	}
	else if (messageType == k_EMsgGCClientWelcome)
	{
		auto packet = inventory_changer(pubDest, pcubMsgSize);
		WritePacket(packet, thisPtr, oldEBP, pubDest, cubDest, pcubMsgSize);
	}
}

bool Protobuffs::PreSendMessage(uint32_t& unMsgType, void* pubData, uint32_t& cubData)
{
	uint32_t MessageType = unMsgType & 0x7FFFFFFF;

	if (MessageType == k_EMsgGCAdjustItemEquippedState)
	{
		return inventory_changer_presend(pubData, cubData);
	}

	return true;
}

///////////////////////////////////
/******** Custom Messages ********/
///////////////////////////////////
bool Protobuffs::SendClientHello()
{
	CMsgClientHello msg;
	msg.client_session_need().set(1);
	auto packet = msg.serialize();

	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCClientHello | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCClientHello | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;
}

bool Protobuffs::SendMatchmakingClient2GCHello()
{
	ProtoWriter msg(0);
	auto packet = msg.serialize();
	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCCStrike15_v2_MatchmakingClient2GCHello | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCCStrike15_v2_MatchmakingClient2GCHello | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;
}

bool Protobuffs::SendClientGcRankUpdate()
{
	MatchmakingGC2ClientHello::PlayerRankingInfo rank_wingman;
	rank_wingman.rank_type_id().set(7); // 6 - mm, 7 - wingman

	CMsgGCCStrike15_v2_ClientGCRankUpdate msg;
	msg.ranking().set(rank_wingman);

	auto packet = msg.serialize();

	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCCStrike15_v2_ClientGCRankUpdate | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCCStrike15_v2_ClientGCRankUpdate | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;
}

bool Protobuffs::EquipWeapon(int weaponid, int classid, int slotid)
{
	CMsgAdjustItemEquippedState msg;
	msg.item_id().set(2000000 + weaponid);
	msg.new_class().set(classid);
	msg.new_slot().set(slotid);
	msg.swap().set(true);
	auto packet = msg.serialize();

	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCAdjustItemEquippedState | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCAdjustItemEquippedState | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;
}

void Protobuffs::EquipAll()
{
	for (auto& x : g_skins) {
		auto def_index = (short)x.wId;
		EquipWeapon(def_index, TEAM_COUNTER_TERRORIST, GetSlotID(def_index));
		EquipWeapon(def_index, TEAM_TERRORIST, GetSlotID(def_index));
	}
}
bool Protobuffs::FixSendClientGcRankUpdate()
{
	MatchmakingGC2ClientHello::PlayerRankingInfo rank_zone;
	rank_zone.rank_type_id().set(10);

	CMsgGCCStrike15_v2_ClientGCRankUpdate msg;
	msg.ranking().set(rank_zone);

	auto packet = msg.serialize();

	void* ptr = malloc(packet.size() + 8);

	if (!ptr)
		return false;

	((uint32_t*)ptr)[0] = k_EMsgGCCStrike15_v2_ClientGCRankUpdate | ((DWORD)1 << 31);
	((uint32_t*)ptr)[1] = 0;

	memcpy((void*)((DWORD)ptr + 8), (void*)packet.data(), packet.size());
	bool result = g_SteamGameCoordinator->GCSendMessage(k_EMsgGCCStrike15_v2_ClientGCRankUpdate | ((DWORD)1 << 31), ptr, packet.size() + 8) == k_EGCResultOK;
	free(ptr);

	return result;


}




