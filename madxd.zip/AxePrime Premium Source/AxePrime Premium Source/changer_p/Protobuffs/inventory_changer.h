#pragma once
#include "ProtoParse.h"
#include "ProtobuffMessages.h"
#include <ctime>
#include <algorithm>
/*enum TeamID : int
{
	TEAM_UNASSIGNED,
	TEAM_SPECTATOR,
	TEAM_TERRORIST,
	TEAM_COUNTER_TERRORIST,
};*/



#define START_MUSICKIT_INDEX 1500000
#define START_ITEM_INDEX     2000000

static void clear_equip_state(CMsgClientWelcome::SubscribedType& object);
static void apply_medals(CMsgClientWelcome::SubscribedType& object);
static void apply_music_kits(CMsgClientWelcome::SubscribedType& object);
static void add_all_items(CMsgClientWelcome::SubscribedType& object);
static void add_item(CMsgClientWelcome::SubscribedType& object, int index, short itemIndex, int rarity, int paintKit, int seed, float wear, int stickers[4], float st_w, float st_sc, float st_rt, std::string name);
static TeamID GetAvailableClassID(int definition_index);
static int GetSlotID(int definition_index);
static std::vector<uint32_t> music_kits = { 3, 4, 5, 6, 7, 8 };

