#pragma once
#include <string>
extern std::string profile_info_changer(void* pubDest, uint32_t* pcubMsgSize);
