#include "discord.h"

void Discord::Initialize() {
	DiscordEventHandlers Handle;
	memset(&Handle, 0, sizeof(Handle));
	Discord_Initialize("667304081366188063", &Handle, 1, NULL);
}

void Discord::Update() {
	DiscordRichPresence discordPresence;
	memset(&discordPresence, 0, sizeof(discordPresence));
	discordPresence.state = "axeprimeyazilim.xyz";
	discordPresence.details = u8"AxePrime Yaz�l�m";
	discordPresence.largeImageKey = "axepremuf_custom_";
	discordPresence.largeImageText = "https://axeprimeyazilim.xyz";
	discordPresence.smallImageKey = "axepremuf_custom_";
	discordPresence.smallImageText = u8"AxePrime Yaz�l�m - Aray�z";
	discordPresence.partyId = "ae488379-351d-4a4f-ad32-2b9b01c91657";
	discordPresence.spectateSecret = "MTIzNDV8MTIzNDV8MTMyNDU0";
	discordPresence.joinSecret = "MTI4NzM0OjFpMmhuZToxMjMxMjM= ";
	Discord_UpdatePresence(&discordPresence);
}