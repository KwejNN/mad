#pragma once
#include "../DiscordSDK/include/discord_register.h"
#include "../DiscordSDK/include/discord_rpc.h"
#include <Windows.h>

class Discord {
private:
public:
	void Initialize();
	void Update();
};