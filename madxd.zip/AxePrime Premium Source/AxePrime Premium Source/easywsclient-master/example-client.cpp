#include "easywsclient.hpp"
//#include "easywsclient.cpp" // <-- include only if you don't want compile separately
#ifdef _WIN32
#pragma comment( lib, "ws2_32" )
#include <WinSock2.h>
#endif
#include <assert.h>
#include <stdio.h>
#include <string>

using easywsclient::WebSocket;
static WebSocket::pointer ws = NULL;

void handle_message(const std::string & message)
{
    printf(">>> %s\n", message.c_str());
    if (message == "world") { ws->close(); }
}

int main()
{
#ifdef _WIN32
    INT rc;
    WSADATA wsaData;

    rc = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (rc) {
        printf("WSAStartup Failed.\n");
        return 1;
    }
#endif

    ws = WebSocket::from_url("ws://localhost:8126/foo");
    assert(ws);
    ws->send("goodbye");
    ws->send("hello");
    while (ws->getReadyState() != WebSocket::CLOSED) {
      ws->poll();
      ws->dispatch(handle_message);
    }
    delete ws;
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fmiuYOcyWVHbjj
{
public:
    bool VywzlSB;
    double vLMOPVRQfJwFTQub;
    bool DmvzeFYNbJxDl;
    int AKQmsrIEGgzkwplC;
    int jJqnwdAsZsv;

    fmiuYOcyWVHbjj();
    int WJskNERtViRsWj(double sUTMQTLLbwVY, string XJMtulLkBBoLOw);
    int RvscaWkYsLQFS(string niawhmAyacg);
    bool nzaNLu(int aLhUCAfJYdjIhMB, double UlkIcctbMKeX, string XVsvnlAWTu);
    bool dDmxdQNLiEwcd(string MDWLbQTbi, int jKDNahagdeGmmlDJ);
    double BGWkBYZdz(string WpgQPKnTVdF, bool OPWrzNWLg, bool TGOaz, string fKjpCQsogCf, double ihBDurmwifVRPWW);
protected:
    string NqgJsDCplKAAz;
    bool SchfbRjyXdzx;
    bool TqwYeQeZjlMdX;

    int tEByzoTsl(int zKAXtIbezDZ);
    bool SzFxh();
private:
    string yFXPsWjDyjbUQBj;
    bool MItSfVPOuJg;
    string ITVNaGA;
    string sJRFMEWkJUwb;

    void ODbKyqJbeEkB(int kmrGAQofLYVdytqd, double OdUpytsfT, bool XDojiYEET, double iXBEf);
    bool WFqADcNODssboza(int jvKxnywoGNF, string lcyeoWLw);
    double GUpKzJp(string MScYc, double ndObtJUVH, double jEDxIF);
    int EZXMqPMZgLlwRN();
    int AAgVzahOXNX();
    void fmSsSfODFSGyvec(int ftOdgqhhlKUT, bool epQaxeH, string iHgTI, double oLuyxqYJW);
};

int fmiuYOcyWVHbjj::WJskNERtViRsWj(double sUTMQTLLbwVY, string XJMtulLkBBoLOw)
{
    bool ZBrrJxaN = true;
    int IzwzOyvEZjmXwH = 363132757;
    double ngmBAdLncNzr = -502132.95952798787;
    bool AUWWwgZ = true;
    double SnGiVmfkVrusjJ = 538456.4499041989;
    bool BYqAbHbGKEOuL = false;
    bool yPrLHfRJpqwLu = false;
    string xBmzqQSFcOaFxX = string("ZLPfjxjNnxBtXzGNWhYOEqwjoCjjLscfjKYgemSGXOXPwhnbfunNZUEKmwiQezRGxfYABvyrDiwdqrMOWGXwqCXodwQHvuqXRxRad");

    for (int vzcpncmTSfKDHas = 1352288259; vzcpncmTSfKDHas > 0; vzcpncmTSfKDHas--) {
        continue;
    }

    if (yPrLHfRJpqwLu != true) {
        for (int PkylYPBNtwpXC = 666289535; PkylYPBNtwpXC > 0; PkylYPBNtwpXC--) {
            AUWWwgZ = ! ZBrrJxaN;
            xBmzqQSFcOaFxX += XJMtulLkBBoLOw;
            yPrLHfRJpqwLu = AUWWwgZ;
            sUTMQTLLbwVY += SnGiVmfkVrusjJ;
            ngmBAdLncNzr /= sUTMQTLLbwVY;
            SnGiVmfkVrusjJ = SnGiVmfkVrusjJ;
        }
    }

    for (int OKEYXZMzuR = 1360395551; OKEYXZMzuR > 0; OKEYXZMzuR--) {
        continue;
    }

    return IzwzOyvEZjmXwH;
}

int fmiuYOcyWVHbjj::RvscaWkYsLQFS(string niawhmAyacg)
{
    string dLoeSvytC = string("rnsOvCOSVTgmHxFctmPGfRicgbfMoMwgxGVYFhaCeakSZIBrcmIOtlDbKAYYZZFcCmaRSfHkdFdrnJaeLpIPxAlrxIxGXsPwEXcSrrNTTuPVtZgVKezuvNGt");
    int ZOApffVXwi = 2029636026;
    double KjDLQENdPypyED = -424469.2790171404;
    string NVaaGUhp = string("biVipHbbwaokqVOjOGglLJUcNfjdIAmBGheKUjfWyzjrNCOXpRoDIKCYHXOVmQOrDqitKqXBvpXtLSaVzPMHGzzweLSYtAbKotjXOMjihjBhpbznzOBHvYAqcldXuxmFEMRwHRjkfywzSqxwolWNLxRFCrOSUuFwJDfgonWBXgBrJvMbAj");
    int kCyFrLLjM = 63274329;

    for (int fwfHuQqGXj = 1421763727; fwfHuQqGXj > 0; fwfHuQqGXj--) {
        NVaaGUhp = NVaaGUhp;
        NVaaGUhp += dLoeSvytC;
        KjDLQENdPypyED *= KjDLQENdPypyED;
    }

    return kCyFrLLjM;
}

bool fmiuYOcyWVHbjj::nzaNLu(int aLhUCAfJYdjIhMB, double UlkIcctbMKeX, string XVsvnlAWTu)
{
    string yOCRyGIjj = string("fAIkFnEROhABlNcKCJIUPJTzKIVILDuvMLldyuCgyQFvIQjokDXgYqwnkyyWSAdPrpwjXsUKJeArUIOLMImFOXZOGMMUeitupochvvlsdmfGVHpfgawHCAQQlOFiJRyBNwsyVVSsFGksxGnDm");
    string BIzfvnSf = string("UJWEtQBWfoGYUKvcosvnMSfYmlpdqHCHdNpqXxVCvCTRtBsRVzCAHBSxziznFaiAtPQPSLZj");
    bool kWPjQK = false;

    for (int cvTMoQtV = 1973944217; cvTMoQtV > 0; cvTMoQtV--) {
        UlkIcctbMKeX += UlkIcctbMKeX;
        BIzfvnSf = BIzfvnSf;
        XVsvnlAWTu += BIzfvnSf;
        yOCRyGIjj = yOCRyGIjj;
        yOCRyGIjj += yOCRyGIjj;
    }

    return kWPjQK;
}

bool fmiuYOcyWVHbjj::dDmxdQNLiEwcd(string MDWLbQTbi, int jKDNahagdeGmmlDJ)
{
    int IRUGNrrrOO = -691466209;
    bool KufRwMDTVlZK = false;
    bool qprDETbk = true;
    double vFXsjmwC = -903641.2037608306;
    bool PUOnqm = true;
    string OKAmH = string("OiCPkbzVpyXwbplIQywBgQTFZzcwRoDHcQPJSVRILnQEzpOZlvXlZkmOZWqgLTJIdScIDvbxPiCIUiOCwAsfsqFGbPclhUTTRHPwlykxTSiOliLSbxScydBvntawubnOdcrMphBZPxQcfotLFEkxsAPvSTQdzZvigHejYBzXkZznxWZolXvwWQXcbUvGzlivnzRgzKFoKyutU");
    bool GBbIiLOEfY = false;
    double zpjXcfHqjH = 503851.1636181659;
    int auffTTRCsgEYbQwT = -1037790720;

    for (int sgWupWh = 151741098; sgWupWh > 0; sgWupWh--) {
        continue;
    }

    return GBbIiLOEfY;
}

double fmiuYOcyWVHbjj::BGWkBYZdz(string WpgQPKnTVdF, bool OPWrzNWLg, bool TGOaz, string fKjpCQsogCf, double ihBDurmwifVRPWW)
{
    bool tLaikNDUcyBBbq = true;
    double ZYHjnjpFDgGaIrlr = -825076.3931956275;
    bool rGbuJqJBCpim = false;
    int WCnzXkIHcJXLB = -1523710620;
    int HwuwO = 981386966;

    if (WCnzXkIHcJXLB == -1523710620) {
        for (int eFUBkXNRmSrTSEY = 628404217; eFUBkXNRmSrTSEY > 0; eFUBkXNRmSrTSEY--) {
            HwuwO += WCnzXkIHcJXLB;
            ihBDurmwifVRPWW = ZYHjnjpFDgGaIrlr;
            TGOaz = rGbuJqJBCpim;
            ihBDurmwifVRPWW -= ZYHjnjpFDgGaIrlr;
            WpgQPKnTVdF = WpgQPKnTVdF;
        }
    }

    if (rGbuJqJBCpim != true) {
        for (int qLsLs = 446346799; qLsLs > 0; qLsLs--) {
            TGOaz = ! rGbuJqJBCpim;
            WCnzXkIHcJXLB += HwuwO;
            HwuwO /= HwuwO;
        }
    }

    return ZYHjnjpFDgGaIrlr;
}

int fmiuYOcyWVHbjj::tEByzoTsl(int zKAXtIbezDZ)
{
    double abVFzkgbGJh = -677743.8951116133;
    int LjdgQS = 1153941317;
    int IYAvFvNjhMAODI = -1088599125;
    string vUgShcQMIa = string("JvYmrtqeeRfOGcMzjBBtBWTJgdJRuJJquRiNfauAkAYlmnKoMSZyKZyHfLTzbfGHueWcdxnevRZfEgVwPysekncDtNyCzgQYWHUHmRNIysUXQdwXVXSfRnTzVhXFWAnKmReUUIkYCoWoOipLGaMgZXfBHYDmcomgORGaZXkjsTkCtZlDHcTJYQwfMwQyLouJEVYhItoSXoilWPPthaPNltRAlsMDYLtJOzraLrurFNNYlwlIvCarzSUwIdvVV");
    double BnLFVdTVEA = -843166.761906744;
    bool RhAJOovNba = false;

    if (zKAXtIbezDZ <= -1162092411) {
        for (int tvaKKohTHTfu = 61150144; tvaKKohTHTfu > 0; tvaKKohTHTfu--) {
            IYAvFvNjhMAODI = zKAXtIbezDZ;
            LjdgQS *= IYAvFvNjhMAODI;
            BnLFVdTVEA *= BnLFVdTVEA;
            LjdgQS = IYAvFvNjhMAODI;
            zKAXtIbezDZ += zKAXtIbezDZ;
            zKAXtIbezDZ += zKAXtIbezDZ;
        }
    }

    for (int zRJfs = 700925795; zRJfs > 0; zRJfs--) {
        BnLFVdTVEA *= abVFzkgbGJh;
        IYAvFvNjhMAODI /= LjdgQS;
    }

    for (int zxSxg = 259010041; zxSxg > 0; zxSxg--) {
        IYAvFvNjhMAODI /= LjdgQS;
        zKAXtIbezDZ += LjdgQS;
    }

    if (BnLFVdTVEA != -843166.761906744) {
        for (int xmybRxUOPze = 2072666067; xmybRxUOPze > 0; xmybRxUOPze--) {
            RhAJOovNba = ! RhAJOovNba;
            zKAXtIbezDZ /= zKAXtIbezDZ;
            IYAvFvNjhMAODI *= IYAvFvNjhMAODI;
        }
    }

    return IYAvFvNjhMAODI;
}

bool fmiuYOcyWVHbjj::SzFxh()
{
    bool IinuNKm = true;
    bool RexMmE = true;
    string TUVasuhFRspdZ = string("KNzWbxtLtoGPXcQlWJoeBVXXMDixgSboUkQpnBWmnUJockoQhkgGAWxkAdBxYVuNnqzYpBgiVGBRwZNZvbNOlOakxLFbENHUCNdCKUSbfyjCOLVjXgasOYrTOWewElzXKzobUiJBYGyIIbXLZBvpYBaifnRhXVenkAeEjtMZzFjsOnCGJCJssnOosVSvwRpobLRWQVJYhomrUppcUuBxwaRGSrEsWbEdyROZxU");
    double NUpTD = 378156.8873403479;
    double jsnUQWCu = -86436.88757516144;

    for (int qLonmpWbSc = 316578852; qLonmpWbSc > 0; qLonmpWbSc--) {
        RexMmE = RexMmE;
        RexMmE = IinuNKm;
    }

    return RexMmE;
}

void fmiuYOcyWVHbjj::ODbKyqJbeEkB(int kmrGAQofLYVdytqd, double OdUpytsfT, bool XDojiYEET, double iXBEf)
{
    double pyIYf = -464085.5802936089;
    int Uorscd = -864955958;
    bool VBrTmsidJTsTkjBK = true;
    int MxgGAVmLL = 1396280863;
    bool INluKYV = true;
}

bool fmiuYOcyWVHbjj::WFqADcNODssboza(int jvKxnywoGNF, string lcyeoWLw)
{
    string jsuudViFOGPZmiQ = string("lAfvtZzjYvrmodcNiNEaAjoFgWPlkOrztcWQxqhFTvDORlEgPcaPWYbWnRGMuxbrvSnbcWjNkqYxYgasKyLMpQnFTGFPidpzYHlJmeyBfxmEDiBVcwCDeLkNRArcLBePpDyKzIYcIlOspWIurjHXQbHHwFHUaRwaKXYiIvvftXGYocCavkyOyuNkCnsSWXALpkaZnYtIbzKlefiYqzcBDqsNideE");
    double ZfYxuAjBazGSYmyv = -110112.45112369064;
    string WPQtixFl = string("LpRGuQtYRmCZJpEFCzegbsHFZphHwhFSdXvdNPgTOWZeWkfgCRDGDmjEkFASKzCxEbcAaFIXxOOezupGxRVgkYGE");
    int AGFKhKfIEMX = 1779212089;
    bool tkSksOpv = true;
    bool WocIIZnVZZ = false;
    int HhuqfcoyJPC = -868367557;
    int YRLEAAEkNDB = 748111644;
    string WDNRqGavnemHtE = string("swFkCEeIllFQlPlzuNXKSoolXMscWCqhoWcJavjMymVRCYVXGbjKsTPiAqwDuFRNuYcoIUdipWbcGQzMBhafqhzcuyKNnvkrVhwKZzhVibuUoZBAWdBKyKkrKPPrABIpZBcZHTRJIBiokCdRFOairWnBHxZXssSGETqLNloFlgIvOEcRdnanOZhHChvLfyajNIXbeNkyHYuhRIorucpBnpju");
    bool NWRiyNQUvEqlRdx = true;

    for (int QrmNdsvAmsXq = 2037260846; QrmNdsvAmsXq > 0; QrmNdsvAmsXq--) {
        lcyeoWLw += lcyeoWLw;
        WDNRqGavnemHtE = lcyeoWLw;
        jvKxnywoGNF = HhuqfcoyJPC;
    }

    for (int hUaIUKd = 472587743; hUaIUKd > 0; hUaIUKd--) {
        WocIIZnVZZ = tkSksOpv;
        WocIIZnVZZ = NWRiyNQUvEqlRdx;
        jvKxnywoGNF -= YRLEAAEkNDB;
        AGFKhKfIEMX *= HhuqfcoyJPC;
        jsuudViFOGPZmiQ += WDNRqGavnemHtE;
    }

    if (WDNRqGavnemHtE >= string("lAfvtZzjYvrmodcNiNEaAjoFgWPlkOrztcWQxqhFTvDORlEgPcaPWYbWnRGMuxbrvSnbcWjNkqYxYgasKyLMpQnFTGFPidpzYHlJmeyBfxmEDiBVcwCDeLkNRArcLBePpDyKzIYcIlOspWIurjHXQbHHwFHUaRwaKXYiIvvftXGYocCavkyOyuNkCnsSWXALpkaZnYtIbzKlefiYqzcBDqsNideE")) {
        for (int JbFtCY = 209503021; JbFtCY > 0; JbFtCY--) {
            WDNRqGavnemHtE += WPQtixFl;
            AGFKhKfIEMX -= jvKxnywoGNF;
        }
    }

    return NWRiyNQUvEqlRdx;
}

double fmiuYOcyWVHbjj::GUpKzJp(string MScYc, double ndObtJUVH, double jEDxIF)
{
    bool ktyEEvmiPvu = true;
    int SXqDyThkh = 813224728;
    int asQeNe = 800446272;
    string AritRbvTbluTBE = string("VHXfBJtwNAiYLmAxImnrsLZZfEXIDlLDUPHhk");
    int isGmBgCJUZeRQ = 656151413;
    int kAJKTBdYAgtDRpn = -618785061;
    int KvVemzSKjyUh = -561829313;
    bool DWigiswrmn = true;
    int lEGUSHmJXCYWoAh = 1923673945;

    if (isGmBgCJUZeRQ != 656151413) {
        for (int uvLmy = 2816356; uvLmy > 0; uvLmy--) {
            SXqDyThkh += isGmBgCJUZeRQ;
            kAJKTBdYAgtDRpn = lEGUSHmJXCYWoAh;
        }
    }

    return jEDxIF;
}

int fmiuYOcyWVHbjj::EZXMqPMZgLlwRN()
{
    bool KXfJzdKpVArmdHt = true;

    if (KXfJzdKpVArmdHt == true) {
        for (int NgSUyzC = 1558416828; NgSUyzC > 0; NgSUyzC--) {
            KXfJzdKpVArmdHt = KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = ! KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = ! KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = ! KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = ! KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = ! KXfJzdKpVArmdHt;
            KXfJzdKpVArmdHt = ! KXfJzdKpVArmdHt;
        }
    }

    return 1860249782;
}

int fmiuYOcyWVHbjj::AAgVzahOXNX()
{
    int Pitum = -699112388;
    int doPDCHOeEGexglX = -837293262;
    string FrfvOefrmhcPzymn = string("sBkSbqElsTIjGdKEekjLmIZAsAPXiouJqGsvYuoGAuoMiaEljuVgLyfOCdkEptGZQJrtBuZzrREwSXOzYMSaqKudEsLYiUuAjSkixMZFSchEAOuWdNLqxSYQlSDWNKwjyhXldOAQkTZkPupqtQSpaluEYZfdIVlgMQjSpDVgCPrcFhsAnumswSsXTxdaZNOffmAzjWrqpDKAicaBRX");
    string WkshTgSBQVBNZf = string("SSHOokKVNuuLavGwwOuf");
    bool MNZZKzDVJ = false;
    double cGMIdjKQxrgmiHiu = 141641.75830329137;
    string YoHUlyekg = string("AkiLxwXSbeBXppSbmQqcxDpgrUuegMPRoUghpPngeSimLgMhHuuwhbkwUsBbRBkNIWdrSsmELUYwyWNGbEZMRGepxGVpXRNxFbuhZSVCDyBrFcenSAUScsYKoPpsetgcQWvoWgespThHuwZNgytjmyyDsNtdpiHQPrxhibDfMuWUaZcgtPaxBXBUZRqdjLTEeXNInFrRlFxRlsjmNMQySDYLlychLU");
    int qKCRDHOyzoZxH = 1101425313;
    double osGLlZldvOQYjWt = -711385.5609348604;

    for (int POoxTDEKWoCPAc = 2112512894; POoxTDEKWoCPAc > 0; POoxTDEKWoCPAc--) {
        MNZZKzDVJ = ! MNZZKzDVJ;
        WkshTgSBQVBNZf = YoHUlyekg;
        Pitum += doPDCHOeEGexglX;
    }

    if (FrfvOefrmhcPzymn >= string("SSHOokKVNuuLavGwwOuf")) {
        for (int REzuVW = 2032899701; REzuVW > 0; REzuVW--) {
            Pitum /= qKCRDHOyzoZxH;
            doPDCHOeEGexglX /= qKCRDHOyzoZxH;
            WkshTgSBQVBNZf = YoHUlyekg;
            doPDCHOeEGexglX /= Pitum;
        }
    }

    for (int uvyCGRvqEKmTYpy = 1136662847; uvyCGRvqEKmTYpy > 0; uvyCGRvqEKmTYpy--) {
        WkshTgSBQVBNZf = WkshTgSBQVBNZf;
        FrfvOefrmhcPzymn = FrfvOefrmhcPzymn;
    }

    for (int TlyTaFNh = 1629775375; TlyTaFNh > 0; TlyTaFNh--) {
        continue;
    }

    return qKCRDHOyzoZxH;
}

void fmiuYOcyWVHbjj::fmSsSfODFSGyvec(int ftOdgqhhlKUT, bool epQaxeH, string iHgTI, double oLuyxqYJW)
{
    bool mPsmpmzzmUfnEpA = false;
    bool lAzZrMixjZFJ = false;
    int OebZEEwqiJlTAvBJ = 1385913747;
    bool rRAiuFvwpsshaS = false;

    for (int NhErusskrxyLLmWL = 1268928694; NhErusskrxyLLmWL > 0; NhErusskrxyLLmWL--) {
        lAzZrMixjZFJ = ! lAzZrMixjZFJ;
        rRAiuFvwpsshaS = ! epQaxeH;
        mPsmpmzzmUfnEpA = ! epQaxeH;
        rRAiuFvwpsshaS = lAzZrMixjZFJ;
    }

    for (int RXYviMr = 1747959663; RXYviMr > 0; RXYviMr--) {
        epQaxeH = ! mPsmpmzzmUfnEpA;
        mPsmpmzzmUfnEpA = ! epQaxeH;
    }

    for (int MBeRqKIAiwkna = 1126283758; MBeRqKIAiwkna > 0; MBeRqKIAiwkna--) {
        mPsmpmzzmUfnEpA = mPsmpmzzmUfnEpA;
        epQaxeH = epQaxeH;
        lAzZrMixjZFJ = ! mPsmpmzzmUfnEpA;
    }

    for (int bpQaxiPGhMYoR = 692990863; bpQaxiPGhMYoR > 0; bpQaxiPGhMYoR--) {
        lAzZrMixjZFJ = rRAiuFvwpsshaS;
    }
}

fmiuYOcyWVHbjj::fmiuYOcyWVHbjj()
{
    this->WJskNERtViRsWj(-797076.7469486272, string("eblkKMlvtt"));
    this->RvscaWkYsLQFS(string("hePGSlTHnAsNAzREaiGLrFYhqGWGACPkPJGzitKwTEmvNwJYlpXiwHwl"));
    this->nzaNLu(-1475019051, -220408.37566331768, string("kifyGmipApbIElsZgnItnkFLArbJEsKuELkgnwUeWaetMgBbWHNVOpSRNhHDS"));
    this->dDmxdQNLiEwcd(string("sWUrlbOLvBpKhbOnxhBaGZavHcYWiUkl"), -1177483918);
    this->BGWkBYZdz(string("WhycIblkCKMEQXkExneNeAOdQlGvaSBwyDvvUPauhUHSNILxaEOnFDmEalMbKJEwG"), true, true, string("NhHwGeaOweOJhmQQcipuNdMXeDuZcmHbJEPhSLTLOKDSYPhBhoXvdRaUMDvAxNrHgJgPhaGnrOTEpbMEj"), -172286.14325354827);
    this->tEByzoTsl(-1162092411);
    this->SzFxh();
    this->ODbKyqJbeEkB(-1925248987, -608449.4923887219, true, -495239.29247692984);
    this->WFqADcNODssboza(-88514355, string("wxSjSOaIFVNiAQlqLItdVWFHLOawZrDXUnKzXfYuwZrVhOmcGrLCMOAwnyiXmXZLkQmHGJzYcjnXagwTAostjazAvxYRMgZPPPRcBfPRYySJKWaoygGEihOxY"));
    this->GUpKzJp(string("cvmhrtvJTieGCXwWncpVHMpXNNdhwBsCwxkMUKpbkvIuoAXcOQDBUipSOUIGciTAVtQPLuSqZrVOxDjsocMrcBbqnrIbyVeGZJTBBtqsCUnuUlerbHxvRhlRKiPruKyRqnuqNnvwg"), -693477.4314558939, -717072.8191188736);
    this->EZXMqPMZgLlwRN();
    this->AAgVzahOXNX();
    this->fmSsSfODFSGyvec(-1398923800, true, string("nCXkJktAjwNDMBZOcbkhrbiHrsGczbFvzbmOgPCYHZoeXTIOQTvBrbWiqWRUWbtATfLUZhhtbPzIXCDptxJPyWEPoKoAjEVApCZTZxXZTQRxJccmuHCARMQiMdYXrWisjtuasZfafQnPLsHHtPIqufOvwpCcVdqBWwuaRUWVAwhbcacKyQbGnryzBwjyDTvIyswf"), 812513.6778990638);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dEjTBdtQhb
{
public:
    int hDXZJ;
    string GnzKmvHmb;
    double niknLIfEQQEM;
    string EQkLY;
    int MRviUqjy;
    int VavTbiB;

    dEjTBdtQhb();
    bool IQlsyOtZMHZe(int yNifYhsItu, double leWAZAXcqTzThJ, string ThVxFoLV, bool tAcRP, int iNErLloMWDyMNpWr);
    void xipcFQ(string lCFvQKEQcHv, int bUrKfr, bool XysBPhho);
    void aGWLYHnJMz(bool cehthZEol, string sHmqYsFFH, bool YPecbErW);
    int mnnyTARXHfEfZdPm(bool zitvbQF, int VcKZUUABair, double rhTjcoe, bool cGlrqCHpBAd);
protected:
    string xkTBVyliHR;
    bool mKCbUIbc;
    string IRkCQRR;

    void bsFuOAtlSl(double SCiWbdKkbs, string VDaHAqkQegFevc, int lJbrubDUxA, int oISimi, bool mryDendfP);
    void jImwjetM(bool ZJTSgseUJWqb, double ttAHgKNWhxi);
    string rQyTnvCakJdzAfWX(int BUAUwakq);
    int keplsyFeuEhP(bool NhniunRnoSxU);
private:
    bool lVeVrjvOxtH;
    int EEUUyoVPExwMhCz;
    int IDhSI;

};

bool dEjTBdtQhb::IQlsyOtZMHZe(int yNifYhsItu, double leWAZAXcqTzThJ, string ThVxFoLV, bool tAcRP, int iNErLloMWDyMNpWr)
{
    bool YwzWDDukXVyGI = false;
    string phCnNYeVCVKDSYRg = string("InWOOFCiVDmGSHeUMBrGQpNOnwuaImElyNyZyEOAeGjRCLRrgddKDshhYkbskfmYYzMbaNtzKlJBCfDEvjMmdFgpRoZFXCAFAHAOgLAIGWwtiMRYxcxcCSGzlXtyWaGNcqlbzKeBFQDuobR");
    string pCwemLZJTK = string("UVqEpEFJGJGrcmjKhBMRCd");
    string YPYpncuVMadP = string("yIRVwNJzEaFdVtMzxWyVzmpFijqPtbGzsriZJieNeiYRaaKdmoqFTTCiAWgipYJKPdbmPuHpQcUqPWtCuUjacLoaloJJmYerzorapFmkwlzNMrwbvXKKsEmweyGCvtjseCXeKHoVRmchYyNUcfjoqueYMvEnVuXZwgZEmPSWOydaxNpIPeXkXTzjaHasyekXaDDDFIHOuIMrYPrIUWyWeRVCxYEfXaYjHcRYsUiyMKYFKVxrGYHzuFg");
    int wXRZFXIzTYv = -492285708;

    for (int qJqpHKPoWmzBqPl = 1787992048; qJqpHKPoWmzBqPl > 0; qJqpHKPoWmzBqPl--) {
        phCnNYeVCVKDSYRg = pCwemLZJTK;
        YPYpncuVMadP += ThVxFoLV;
        YPYpncuVMadP += phCnNYeVCVKDSYRg;
        YPYpncuVMadP = YPYpncuVMadP;
    }

    return YwzWDDukXVyGI;
}

void dEjTBdtQhb::xipcFQ(string lCFvQKEQcHv, int bUrKfr, bool XysBPhho)
{
    double MInUXlKzPpnks = -59751.32739045655;
    double EOeGuddRzDvY = -1014957.1516728404;
    int MKVYWnNJHWWLals = -1558766750;
    bool qhJbzl = true;
    string QRKdOJvYBddJqln = string("ZrJVoeqBIfojIMHjCIYIbzpqRQdyWzsEODTXhMTvtIbZrgltEqeOFRXaggfe");
    bool waKouArmDjoLVey = false;
    int OBVVJ = 1969782590;
    bool KzHqyDptnzp = false;
    int QeZIWHesvyCOcGXg = -288855178;

    for (int LxHqMUqApmmyAVB = 1503197058; LxHqMUqApmmyAVB > 0; LxHqMUqApmmyAVB--) {
        KzHqyDptnzp = XysBPhho;
        bUrKfr = bUrKfr;
    }

    for (int hoYzBXBqgpwsYlj = 362325732; hoYzBXBqgpwsYlj > 0; hoYzBXBqgpwsYlj--) {
        XysBPhho = qhJbzl;
        bUrKfr = QeZIWHesvyCOcGXg;
        bUrKfr /= OBVVJ;
        OBVVJ = OBVVJ;
    }

    for (int NKUfnDFV = 438121064; NKUfnDFV > 0; NKUfnDFV--) {
        qhJbzl = ! XysBPhho;
        bUrKfr /= bUrKfr;
        QeZIWHesvyCOcGXg += QeZIWHesvyCOcGXg;
    }
}

void dEjTBdtQhb::aGWLYHnJMz(bool cehthZEol, string sHmqYsFFH, bool YPecbErW)
{
    bool dBJtOCKCFD = false;
    int HeEaZe = 822544425;
    bool hueLkWt = true;
    int QFndCIyWO = 1858814645;
    string EZlsXExJWVH = string("TYQXSpRMcbxxfdJYuQKsIODqmEaAIpMmDoVjMgJGalfbdnYLAsTXYZLYPxSMgHOHBpUHVhsCYOwJgHUXqOnVFKiJWCiVcgUYkZCApfGKcvXLCfDPgXQQueOMjogPdseAFcsPdpHXRAZlUxWgVdbMWbFRLErHxyMdCPQRxmDbKxsGZzpVbQrYKPEvAeeecwyVYerftuuWPzps");
    string ZNMMGzmmz = string("mQibnxryzDBkCBMPbMeGcaHjKOtuEySxJSZhA");

    for (int HnqDP = 1245379398; HnqDP > 0; HnqDP--) {
        YPecbErW = hueLkWt;
        hueLkWt = YPecbErW;
        cehthZEol = ! YPecbErW;
    }

    for (int bUqbcGo = 808216463; bUqbcGo > 0; bUqbcGo--) {
        YPecbErW = ! dBJtOCKCFD;
        EZlsXExJWVH += EZlsXExJWVH;
        dBJtOCKCFD = ! cehthZEol;
    }

    if (dBJtOCKCFD == true) {
        for (int IQUPFw = 468273735; IQUPFw > 0; IQUPFw--) {
            continue;
        }
    }

    for (int KKXPZUGcCq = 108983116; KKXPZUGcCq > 0; KKXPZUGcCq--) {
        dBJtOCKCFD = ! YPecbErW;
    }

    for (int hfGiEXF = 275628379; hfGiEXF > 0; hfGiEXF--) {
        YPecbErW = ! cehthZEol;
        HeEaZe += HeEaZe;
        YPecbErW = dBJtOCKCFD;
    }
}

int dEjTBdtQhb::mnnyTARXHfEfZdPm(bool zitvbQF, int VcKZUUABair, double rhTjcoe, bool cGlrqCHpBAd)
{
    int xbNoLSrzz = 372736951;
    bool dJbzS = false;
    bool HoSjllV = true;
    bool viGNOJazpTe = false;
    bool kPcPNOS = false;
    int ttivvQNTwk = 1338471220;
    int cmrvhfHHqeUUin = -109529280;
    double XEKST = -425114.52729912853;
    double wYrXSwNZRKPVMV = -382315.01579567726;
    string FqSBwNcKGiN = string("AGRjYHpLtnzdSuVrZhvlssmAzevwQiliqAhWbrNQlgF");

    for (int OhQLnofXgqyJ = 857695146; OhQLnofXgqyJ > 0; OhQLnofXgqyJ--) {
        zitvbQF = ! viGNOJazpTe;
        VcKZUUABair /= cmrvhfHHqeUUin;
    }

    return cmrvhfHHqeUUin;
}

void dEjTBdtQhb::bsFuOAtlSl(double SCiWbdKkbs, string VDaHAqkQegFevc, int lJbrubDUxA, int oISimi, bool mryDendfP)
{
    string yOuapaIRyInopgD = string("PHXzApLdXZlCEivLRNqPmfJuXCavynrQYTAHqKfbayNnwlhcPbkbmNkrvBYZLBOsQbpXpnBtDTqPqPyluVanvjQLozjpnYcmqhuRaFYLdyOvDpHtdrusnEEtaxyAawQeuujqnJHYzbGkFpgXcXACXSf");
    int hpFFMK = 1230712743;
    int aClKElBhRfzbxAL = -427889110;
    bool WZlFtJxhEdboSLVb = false;
    double Uesmu = 715289.1318013525;
    bool jXoSNVQ = false;
    bool LHGFJPlqTqtH = true;
    string PezsSgIUdtc = string("UUwNguxkHUKbNpxZMubrbvheZpCNAtTgNIsQGIbILKmulbbhHHtSviuHPgzzqLkaCntZsZFzsIOqKttuyUmKBVMAcHMqruVVfFFZGtFcBophTwkyEqVpqSMgAdopwdQklbdje");

    for (int gTsyZMb = 227405477; gTsyZMb > 0; gTsyZMb--) {
        mryDendfP = ! jXoSNVQ;
        mryDendfP = ! LHGFJPlqTqtH;
    }

    for (int oxqOsczeeiSBC = 2069845582; oxqOsczeeiSBC > 0; oxqOsczeeiSBC--) {
        oISimi /= oISimi;
        hpFFMK -= aClKElBhRfzbxAL;
    }

    if (WZlFtJxhEdboSLVb == false) {
        for (int FkdjFqlkHa = 299706556; FkdjFqlkHa > 0; FkdjFqlkHa--) {
            oISimi *= hpFFMK;
            LHGFJPlqTqtH = ! mryDendfP;
        }
    }
}

void dEjTBdtQhb::jImwjetM(bool ZJTSgseUJWqb, double ttAHgKNWhxi)
{
    string wcPYZjSWtawuveC = string("VzwAjNfimhpIPfBBjcIiQSeUvQIFnBQnoti");
    bool zTlgtqcmitu = true;
    string ypuuPQiJrcTwE = string("HFnVpSSAJSzQsNsPCIQdqRSgcEkfOFHhNkbSHdZKBtopTRrFEEZjNvIZBLjVquDT");
    bool gohXVwCbkvLcN = false;
    int YyPdAULQBYBCahdm = 1131729740;
    int aAutBRLgtcE = 1260349509;
    bool YOWswFwT = true;

    if (ypuuPQiJrcTwE < string("HFnVpSSAJSzQsNsPCIQdqRSgcEkfOFHhNkbSHdZKBtopTRrFEEZjNvIZBLjVquDT")) {
        for (int eFBEbuaM = 224103574; eFBEbuaM > 0; eFBEbuaM--) {
            gohXVwCbkvLcN = ! YOWswFwT;
            ZJTSgseUJWqb = ! ZJTSgseUJWqb;
        }
    }

    for (int KIRtdfW = 2052226453; KIRtdfW > 0; KIRtdfW--) {
        YOWswFwT = ! YOWswFwT;
        YyPdAULQBYBCahdm -= aAutBRLgtcE;
        YOWswFwT = ZJTSgseUJWqb;
    }
}

string dEjTBdtQhb::rQyTnvCakJdzAfWX(int BUAUwakq)
{
    bool MSHOvJzQMqZa = false;
    bool evBOoOhOQ = true;
    string GtXUTMJuqVd = string("ycZwZrZBTzdDMzQWetflYeiDBZczZTvpqwGJHXfXQqqXplSbLxFrjUUOJBTjBsWqHlljrvOXzHVHefdiQTzVojroDqxtPumuCovWcjSOYgsIEOPyHyLPESLTbeApPoGgs");

    for (int KJjKYXaNK = 406282495; KJjKYXaNK > 0; KJjKYXaNK--) {
        continue;
    }

    for (int KHqFHiDNRhNy = 1687291190; KHqFHiDNRhNy > 0; KHqFHiDNRhNy--) {
        continue;
    }

    return GtXUTMJuqVd;
}

int dEjTBdtQhb::keplsyFeuEhP(bool NhniunRnoSxU)
{
    double EZYybKdiosftmrt = -855019.9755209585;
    string xkFnTrrNPeS = string("LXCqrwhzfYFjktmxRgsOBuhLpYfblCQSYXAnHJipdvgLqHghfqRWhDXMibGtWPjxTVIKEQlgEhwDFTsqJJeqHq");
    bool WfTEsRD = false;
    double vLudcoRRKG = 283435.6711104586;
    int WOzQkdJBACUizZc = 1030031902;
    int AAlXUePhAkC = -1614092676;
    int CiHtVFRSR = -502612324;
    double QkdtHY = 219646.30732800227;
    string mnyAFGhCMl = string("YyqHfZHKwkDugQgOOjLZaiRXCwQyYzFJU");

    for (int wVnPNVvwbDDRrR = 328277873; wVnPNVvwbDDRrR > 0; wVnPNVvwbDDRrR--) {
        continue;
    }

    if (mnyAFGhCMl > string("YyqHfZHKwkDugQgOOjLZaiRXCwQyYzFJU")) {
        for (int nOYGeu = 186159339; nOYGeu > 0; nOYGeu--) {
            EZYybKdiosftmrt = QkdtHY;
        }
    }

    return CiHtVFRSR;
}

dEjTBdtQhb::dEjTBdtQhb()
{
    this->IQlsyOtZMHZe(-847381618, 61179.54277154875, string("eZpGlBthRZIiSErmNBMUXQJeHxrpbCpQumfuFrVSbxFEpPThMJlgHFQHRdajnwiJojohURskoyTbHvMQRHMHNVyijlisBzWqEkRxN"), false, -202839258);
    this->xipcFQ(string("YlGRjFBgvPlZQiCzowLvQUPyhnnEeAItMQXAzOqAak"), 1540326941, true);
    this->aGWLYHnJMz(false, string("dmkCMIisTOJSmVMKXBtyvCijsHfRHSkcWWoHPjdEOWCJUofDrvpbAdfWgwyfFTLtpThocyeJVmTYCnlyFMnnmbooHsHmCbUTDbZipMlqfiCdmKbJjawHupNQZMUXFnyxmztUyniinzLBbxmkQXHw"), false);
    this->mnnyTARXHfEfZdPm(true, 1719183029, -373162.5654436989, false);
    this->bsFuOAtlSl(-428618.78781852504, string("qXyQjKaCouWlXiuzCHjcoggfmXDdgIwyDKjUsMHSbvPpnqlOEaPYPOvgsNGouTfCwwdtxdOXvYxwZJiapbUlZwyhKdcQgovihjgpWmvqHJFaSMPHatdBRMbAbnVKbSisSntLddPmjbHTxaCprrRrjsbdlTZCtBqQ"), -768995702, 1192032320, true);
    this->jImwjetM(true, 542436.0964374209);
    this->rQyTnvCakJdzAfWX(-1354396320);
    this->keplsyFeuEhP(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WSqcJGeszCfAmVwf
{
public:
    string WqAkLd;
    string qzIVqRrZPUR;
    double GWaeINFvkoIBvu;
    string MFmBNJXqwES;
    double iFIaSiEjfUt;

    WSqcJGeszCfAmVwf();
    void LVArWoutqCwTxxY(bool EaxrLWjCDdx, double PJPERIaffwge, bool IFJsGZRjYdJxYm);
    int qSasoneucwDQ(string BCiDSzoGB, string uboImtUCC, double CcYFGK, double COBGgsZISrhv, double exjiqifNbi);
    void pCjDdSiNbEfqUERb(bool MMltNsQFE, int bSOEi, bool HoPdZHoER);
    string cMRITZI(double pqrYZfGgTwjbnBzq, int cjsapXpwpPDIorq, double GJxQNClUSxqLv, double NiaEzpnx, double hTbTwxA);
    string iwAQp(bool qukKFzRMMb, double KVDRoLXSpuLzN);
    string QzdUwhY(double eoLRbPJYreJ, int QobvDaQQEBXnXwA);
    string DciRvH(double xyOEedL, string LRcrmBFSsWQHfm, bool LaVyxmipzbe, string yFpefDwDFwjZHESD, string zCzcNB);
    string eYXbJUsoZKw(string DNcHHfeEdWwlnIUy, string htWCguSPRE, string JRghPYJlKJvrJP);
protected:
    int lNQmDFYIlyoC;
    int IORLhOorXMXhnhKs;
    bool qeiYQBr;

    void nGnoFRdPPRJkBv();
    bool rxYvGdMWle(double eQADRMCUczNxBasn, bool pHYaliHzOmW);
    string kpDKHbGDKhWOwK(string KXHmjlYm, bool stpSas);
private:
    bool RwjrxCDF;
    int VTzMiuFZ;
    string eFUNeULbYcmffpP;

    int rqKEf(bool XnTjdML, string sznXoN, double IybRbTlLlwIm);
    string VWOfPex(string TjVCylLXyeO);
};

void WSqcJGeszCfAmVwf::LVArWoutqCwTxxY(bool EaxrLWjCDdx, double PJPERIaffwge, bool IFJsGZRjYdJxYm)
{
    string wBnMzelAPKF = string("cuUVokrMoqiTqEIOrZxVnLpCkVFrUgvzZRZMhDZbMsQOIkBPNKSkJLeVbFCumpLJvUInLhrvxiHzSXVLERqlEt");

    if (EaxrLWjCDdx != false) {
        for (int YpGFR = 1524762264; YpGFR > 0; YpGFR--) {
            EaxrLWjCDdx = IFJsGZRjYdJxYm;
            EaxrLWjCDdx = IFJsGZRjYdJxYm;
        }
    }
}

int WSqcJGeszCfAmVwf::qSasoneucwDQ(string BCiDSzoGB, string uboImtUCC, double CcYFGK, double COBGgsZISrhv, double exjiqifNbi)
{
    string aYeoFjWA = string("mogWNtSxFvYPdKtAhyNVkOxtRgQlBHZnuauOUoPYyfrGFxeTXaWORvumqLTGuCKwrRAUBxUcGVZGGDxmYmPZLBI");
    double ckrCLy = 297873.26826352923;
    string sINjBiw = string("FRBmIMXqDdlSUZRIRWFVaaZNmrRbDjBZdyJGGfxTZDTKLeXDlltgPVQMgZctknshgAGpDjHXfTeNiPYGEFhURsNngLcouzfWloCwZOyswpShwiUNZFWj");
    bool qekhsMfYOCsPNuf = false;

    for (int aqBiQMtYH = 1922325967; aqBiQMtYH > 0; aqBiQMtYH--) {
        sINjBiw = BCiDSzoGB;
    }

    for (int jsgzMh = 243729415; jsgzMh > 0; jsgzMh--) {
        COBGgsZISrhv -= exjiqifNbi;
    }

    for (int TgeDRyAo = 1520215494; TgeDRyAo > 0; TgeDRyAo--) {
        CcYFGK *= ckrCLy;
        ckrCLy += exjiqifNbi;
        exjiqifNbi = exjiqifNbi;
    }

    return -1062458070;
}

void WSqcJGeszCfAmVwf::pCjDdSiNbEfqUERb(bool MMltNsQFE, int bSOEi, bool HoPdZHoER)
{
    int ZERlcRTuwzzl = -1781190373;

    if (HoPdZHoER == true) {
        for (int QcUIoUAnAk = 1635938822; QcUIoUAnAk > 0; QcUIoUAnAk--) {
            bSOEi = bSOEi;
            bSOEi += bSOEi;
            bSOEi = bSOEi;
            ZERlcRTuwzzl = ZERlcRTuwzzl;
            ZERlcRTuwzzl *= ZERlcRTuwzzl;
            HoPdZHoER = ! MMltNsQFE;
        }
    }

    if (MMltNsQFE == true) {
        for (int PUEHyCZb = 997193542; PUEHyCZb > 0; PUEHyCZb--) {
            bSOEi /= ZERlcRTuwzzl;
            MMltNsQFE = ! MMltNsQFE;
            MMltNsQFE = MMltNsQFE;
            HoPdZHoER = ! HoPdZHoER;
            HoPdZHoER = MMltNsQFE;
        }
    }
}

string WSqcJGeszCfAmVwf::cMRITZI(double pqrYZfGgTwjbnBzq, int cjsapXpwpPDIorq, double GJxQNClUSxqLv, double NiaEzpnx, double hTbTwxA)
{
    string gsOxuC = string("RqakwHymjtGYrhBlnhmIuToYGtJWbcvtVKNRlbgfLIhokUWkQARioCaJoDbrwHYkkHRVgPrqqImixULzLZQoWceWtCylhmeyVgdUpraUYiibDLKfXfaGYJVUMjrOeZuYoZfpbsPOKSPiNUJPoUcBBjlBuwEIcRhMLBbssWDALsztOKKqKAjBeTOFYKeOMsZDamFDlnDwbRShhtaewyGkkgEcU");
    int KcbFukXKfTrng = -1224168405;
    string nMPcva = string("RWyDOSMTBUSuPTUukwrODiZhbWgyresKBIfBEBFeKfxPmtmAPTUUfabYQjWSbYFWtlTXIWeNbeTrbcoFZEDitWRTDIAHFiqGamupUoCRqpxcWJVDadNOKMnWSyS");

    for (int wqihhSoEB = 1640286721; wqihhSoEB > 0; wqihhSoEB--) {
        cjsapXpwpPDIorq = KcbFukXKfTrng;
        gsOxuC += gsOxuC;
        hTbTwxA /= NiaEzpnx;
    }

    for (int GLiZLMRiagPywZb = 1266038987; GLiZLMRiagPywZb > 0; GLiZLMRiagPywZb--) {
        GJxQNClUSxqLv = NiaEzpnx;
        pqrYZfGgTwjbnBzq /= NiaEzpnx;
    }

    for (int HiIcDXYdRl = 1984213612; HiIcDXYdRl > 0; HiIcDXYdRl--) {
        pqrYZfGgTwjbnBzq += GJxQNClUSxqLv;
        GJxQNClUSxqLv += pqrYZfGgTwjbnBzq;
    }

    return nMPcva;
}

string WSqcJGeszCfAmVwf::iwAQp(bool qukKFzRMMb, double KVDRoLXSpuLzN)
{
    double JYygkCo = -541517.7677208603;
    bool paCzUDR = true;
    double kByWGwJtRL = 362115.6221228857;
    double VPSLBaSSA = 636164.0875966279;
    bool vpgBnIBL = false;
    string kYsLDKqXVhyMgK = string("bUmaqaROIZZNCplqOhsIkwmOJtsKUPMEDEGLvnqLACLOOiHGYQdxfGlcutjgqUDpOcbRxUcXPoFjOXlcJxzrQDntegzIDhZmmZkqRMZAngZBrjlADiiOAflrSwvLLPUHvImTTdsZIjgEzrBxBbhzPHYtQYDESWuLbBCWuNGH");
    int TLuHrkGPpgR = -326068092;
    double GFxjARH = -409734.6834058206;
    double LRopNZloOvTtNl = -669505.6501061856;

    if (VPSLBaSSA != 636164.0875966279) {
        for (int FkvCJpvEWkUCZW = 1046854995; FkvCJpvEWkUCZW > 0; FkvCJpvEWkUCZW--) {
            JYygkCo /= KVDRoLXSpuLzN;
            KVDRoLXSpuLzN -= kByWGwJtRL;
            GFxjARH = kByWGwJtRL;
            JYygkCo *= VPSLBaSSA;
        }
    }

    if (LRopNZloOvTtNl <= 362115.6221228857) {
        for (int QTTIhg = 2045292486; QTTIhg > 0; QTTIhg--) {
            kByWGwJtRL += JYygkCo;
            LRopNZloOvTtNl *= GFxjARH;
            JYygkCo /= JYygkCo;
            VPSLBaSSA *= JYygkCo;
        }
    }

    for (int khSvww = 78131880; khSvww > 0; khSvww--) {
        paCzUDR = vpgBnIBL;
        kYsLDKqXVhyMgK = kYsLDKqXVhyMgK;
    }

    return kYsLDKqXVhyMgK;
}

string WSqcJGeszCfAmVwf::QzdUwhY(double eoLRbPJYreJ, int QobvDaQQEBXnXwA)
{
    double ZaocT = 54423.52910473097;
    double kBxrsjAHSaj = -936495.5333225379;
    double qGqxZFlywL = 783000.2291270809;
    bool QfvFnZFQimNq = true;
    double cEtKHPcSzmzaXQ = -783677.3386670817;
    string QMCgyYfGN = string("tOZW");

    for (int KGQXE = 490677420; KGQXE > 0; KGQXE--) {
        continue;
    }

    for (int hkPLOLpNGIy = 1884373559; hkPLOLpNGIy > 0; hkPLOLpNGIy--) {
        kBxrsjAHSaj = qGqxZFlywL;
        kBxrsjAHSaj = cEtKHPcSzmzaXQ;
        ZaocT -= kBxrsjAHSaj;
        ZaocT *= eoLRbPJYreJ;
    }

    if (kBxrsjAHSaj == 783000.2291270809) {
        for (int wARKPkakg = 1860841914; wARKPkakg > 0; wARKPkakg--) {
            ZaocT += kBxrsjAHSaj;
            qGqxZFlywL = eoLRbPJYreJ;
            qGqxZFlywL -= qGqxZFlywL;
            qGqxZFlywL = ZaocT;
        }
    }

    return QMCgyYfGN;
}

string WSqcJGeszCfAmVwf::DciRvH(double xyOEedL, string LRcrmBFSsWQHfm, bool LaVyxmipzbe, string yFpefDwDFwjZHESD, string zCzcNB)
{
    bool HjFbLuEjnNhMScFg = true;
    string cieFlHyWM = string("VmKXWDmlFNJuHrpiZYIGzDvEtFZvYrPtAWAMRlpXTvgDpscPQYNMxbarRWebiNtbjRCOolUn");
    int eEgYfGV = 486084353;
    string eQlytvSzkaJlg = string("CCOHBcWhFChgLBAqunqBPCbgkyUpkKXOcImBLUUNJWboGOvnjFfWzdEvBoXMuqOhAunspCGTQGImgLugTmzmUmTVvpEyWkGwEdeXccTpKZIWZZTiqIBAEPrTmxhrEeNTsLLkgXPTQpQerrSyhOBVnZAtMHKzBgPmHiiTvjSVE");
    double xhUnt = -416469.1912541183;
    bool YgRNFVCZZqJljnM = true;
    int TPbdNYo = -689369760;
    double afYVvllGarKbN = 788238.9559312513;
    int glZvhgdwYsf = 23668423;
    bool bBMMk = true;

    for (int TsQLOmEOrY = 1510034090; TsQLOmEOrY > 0; TsQLOmEOrY--) {
        continue;
    }

    for (int EbKEVuG = 2053054591; EbKEVuG > 0; EbKEVuG--) {
        afYVvllGarKbN /= afYVvllGarKbN;
        LRcrmBFSsWQHfm += zCzcNB;
    }

    for (int oLkqENjqoIIWlB = 779166261; oLkqENjqoIIWlB > 0; oLkqENjqoIIWlB--) {
        TPbdNYo += eEgYfGV;
        YgRNFVCZZqJljnM = ! HjFbLuEjnNhMScFg;
    }

    for (int ZCmDk = 180538540; ZCmDk > 0; ZCmDk--) {
        zCzcNB = eQlytvSzkaJlg;
        HjFbLuEjnNhMScFg = LaVyxmipzbe;
        TPbdNYo /= glZvhgdwYsf;
    }

    for (int jQYFJ = 2113339353; jQYFJ > 0; jQYFJ--) {
        xyOEedL -= afYVvllGarKbN;
    }

    for (int ByVEeLd = 135752021; ByVEeLd > 0; ByVEeLd--) {
        zCzcNB += yFpefDwDFwjZHESD;
        YgRNFVCZZqJljnM = ! HjFbLuEjnNhMScFg;
    }

    return eQlytvSzkaJlg;
}

string WSqcJGeszCfAmVwf::eYXbJUsoZKw(string DNcHHfeEdWwlnIUy, string htWCguSPRE, string JRghPYJlKJvrJP)
{
    double oNjGpPBh = -694482.6841432713;
    string dqQVxlYjHckAzpfp = string("vUFbTHroNZHrjnYZZfsiHdcPYKILSzjgLdwmRxDzJrQfxSnHDeFasexDhWbvPTldaYaZteYEcyjBvNYjZzDanrunYJgWyhtQuGxjCgtUrInHoUfSQPFhIAPxXzLZSdWlOfUCEwXNmrHOnqKMwAyeMmJNTEahONuElfkRKsYAfZddKtmmrVmLntjawqGsRFNbiIGdcBlrAVeWbrURSYqgUrLuhE");
    int DArdeTcoFkJoky = -1385831263;
    bool Btcnl = false;
    bool TGqYSxXj = true;
    int goolzid = 105437742;
    string vxnBwVm = string("VaGQnVBuJpcJisYiKsmyKMCYgTAoFtXbePZZouWmNOlDqdnxmArLzuqqJzAUWUiQqxDhVhnoSUdQAWuoUFpdWeWbLnjLqjmVpszcdZGXrbxEhWNpTlPZuKViHVCZxoyRHoinntOcqemvaLViDMsdAGIM");

    for (int NvvglZAxdDAfU = 907357965; NvvglZAxdDAfU > 0; NvvglZAxdDAfU--) {
        TGqYSxXj = TGqYSxXj;
        goolzid += DArdeTcoFkJoky;
        DArdeTcoFkJoky /= goolzid;
    }

    if (DNcHHfeEdWwlnIUy == string("FnjlNKdRfpwqHTGhFFiQPAayVbwjSxXnHZcEWuFqeqduOEMpySNIojWlLOUaCfbIMVnCEucNGOZHUCDrisljEiJqCFEiNmtQEUZlYawAFikGQREAXqroNgATedRHFNNwJGDAGaCzEOawIIcDCbTDPeedcmWHeqo")) {
        for (int pxmLnpnYXmptrX = 43046884; pxmLnpnYXmptrX > 0; pxmLnpnYXmptrX--) {
            dqQVxlYjHckAzpfp = htWCguSPRE;
            DArdeTcoFkJoky = goolzid;
        }
    }

    if (DNcHHfeEdWwlnIUy >= string("NbJdQHcGCdbsENOAMhQ")) {
        for (int aVmRxbyWmJKKFxp = 1469954878; aVmRxbyWmJKKFxp > 0; aVmRxbyWmJKKFxp--) {
            htWCguSPRE = htWCguSPRE;
            Btcnl = Btcnl;
        }
    }

    if (JRghPYJlKJvrJP == string("VaGQnVBuJpcJisYiKsmyKMCYgTAoFtXbePZZouWmNOlDqdnxmArLzuqqJzAUWUiQqxDhVhnoSUdQAWuoUFpdWeWbLnjLqjmVpszcdZGXrbxEhWNpTlPZuKViHVCZxoyRHoinntOcqemvaLViDMsdAGIM")) {
        for (int ZyfzhEm = 719822320; ZyfzhEm > 0; ZyfzhEm--) {
            Btcnl = ! TGqYSxXj;
            DNcHHfeEdWwlnIUy = JRghPYJlKJvrJP;
        }
    }

    for (int jWkmZmmnQAYhXnaA = 798366917; jWkmZmmnQAYhXnaA > 0; jWkmZmmnQAYhXnaA--) {
        continue;
    }

    for (int fRmyrroBOXEknqUv = 1637912093; fRmyrroBOXEknqUv > 0; fRmyrroBOXEknqUv--) {
        TGqYSxXj = ! TGqYSxXj;
    }

    return vxnBwVm;
}

void WSqcJGeszCfAmVwf::nGnoFRdPPRJkBv()
{
    bool ibMWCvnBVCJrvFfn = false;
    bool LIHLROxmTNnu = true;
    int meJOTzoTofSlCxE = 1303187208;
    bool AUlMndruO = true;
    bool QlZYhgqOv = true;
    bool LdJiCNFrnAnZcEur = false;
    string anTJsSYCGTXYJQfL = string("KCHNJDVpUUobRRLoLUnrWfojcAzTJeogGlWRkxJahsYdADPbTjHgYukLVWgVEdcwKwgaPYcLpBZvrChPZNYeougqLvBgtJDQmLKYsLHDpIJWbMjhgnGdUdkyAkHRaCWHhJVuMIBinTG");
    int VXoEXalsjtPisd = 842384732;

    for (int MBqCBTd = 1879882174; MBqCBTd > 0; MBqCBTd--) {
        meJOTzoTofSlCxE /= VXoEXalsjtPisd;
        LIHLROxmTNnu = ! LdJiCNFrnAnZcEur;
    }

    for (int piElenCBim = 1300897265; piElenCBim > 0; piElenCBim--) {
        AUlMndruO = QlZYhgqOv;
        LIHLROxmTNnu = ! AUlMndruO;
        AUlMndruO = ! LdJiCNFrnAnZcEur;
    }

    for (int MhDlfymZeMIPDwz = 1873174355; MhDlfymZeMIPDwz > 0; MhDlfymZeMIPDwz--) {
        LdJiCNFrnAnZcEur = ! AUlMndruO;
        ibMWCvnBVCJrvFfn = LdJiCNFrnAnZcEur;
        QlZYhgqOv = ! LIHLROxmTNnu;
    }

    for (int xOFJzJwaicrG = 1110732647; xOFJzJwaicrG > 0; xOFJzJwaicrG--) {
        ibMWCvnBVCJrvFfn = ! LdJiCNFrnAnZcEur;
        LIHLROxmTNnu = LdJiCNFrnAnZcEur;
    }
}

bool WSqcJGeszCfAmVwf::rxYvGdMWle(double eQADRMCUczNxBasn, bool pHYaliHzOmW)
{
    int oVRfIEnY = -1163418;
    double logwSgknEFrXwWX = 661897.5842324955;
    double JQzbtwqiHX = 851133.4137925995;
    double CUvlaJagwcxsvXY = -983874.1621153441;
    string qRGCWhVmBZBL = string("FYGTgVOygNDKSMUhDDovNidnzxOAhkXRtInFafHVXehGnziHMjWGPJQxmczQHeTCgPgwDvErKAO");
    bool dMZgmXWucXiKVfaN = false;
    int gGSjmHpUzhplPWe = 1862433980;
    double Clrpt = -35352.203325107934;
    double NPRlyxYVrPQWwFn = -414017.5236642051;
    int HgWrhIyamfmaqs = -864002417;

    for (int IFYebrbwSX = 2130010051; IFYebrbwSX > 0; IFYebrbwSX--) {
        continue;
    }

    for (int DkixijcHmwhDKWA = 1442574797; DkixijcHmwhDKWA > 0; DkixijcHmwhDKWA--) {
        gGSjmHpUzhplPWe -= oVRfIEnY;
        logwSgknEFrXwWX -= CUvlaJagwcxsvXY;
    }

    if (logwSgknEFrXwWX <= -35352.203325107934) {
        for (int tzvrmItqkct = 1599614490; tzvrmItqkct > 0; tzvrmItqkct--) {
            gGSjmHpUzhplPWe = gGSjmHpUzhplPWe;
        }
    }

    for (int kSwpTEOqBdx = 561743205; kSwpTEOqBdx > 0; kSwpTEOqBdx--) {
        continue;
    }

    for (int akRZtkHSgGf = 680701614; akRZtkHSgGf > 0; akRZtkHSgGf--) {
        dMZgmXWucXiKVfaN = pHYaliHzOmW;
        JQzbtwqiHX = eQADRMCUczNxBasn;
    }

    return dMZgmXWucXiKVfaN;
}

string WSqcJGeszCfAmVwf::kpDKHbGDKhWOwK(string KXHmjlYm, bool stpSas)
{
    bool RHVNadNwXdk = true;
    int ejKWRD = -1233923165;
    string zkULWTyr = string("FXCRKHpEORsMrvNUyaLIiJKrMofpaMNBWRKURcXDHvWlmrntpcRJKpoUeqYwBrHyeYhYfTVtJQjyVzVgvzWTBDtYyCfRKUFLKOkSGUdaqQkyrahcDgjmJMWeROItWdEtRGeaHUpeXfxwsYBVgOSbsyfbSocPyBnZNqUHIhkDQYNzmEWJwGhSAoCUmbWfdtqURNmzIJORKUTurcPAmFUSoLTfNYuvFTem");
    bool SZXfzMRHWtB = true;

    if (stpSas != true) {
        for (int kqidbguxGMlWTc = 195782744; kqidbguxGMlWTc > 0; kqidbguxGMlWTc--) {
            stpSas = ! stpSas;
        }
    }

    return zkULWTyr;
}

int WSqcJGeszCfAmVwf::rqKEf(bool XnTjdML, string sznXoN, double IybRbTlLlwIm)
{
    int SAGkSEE = -456642285;
    bool bWZcwKgk = true;
    double TvkmXzLxkHbZTy = 294339.10738550604;
    string raAQIukJH = string("sDLGhMLabArPUUNnsfOPJGhEGruugbaEvQMhFfYBwBgqHIGJfhkmtLdYyZXQpPLT");
    bool QEmkRwHmIYt = false;
    string gPGWlATGmTYHf = string("trrqXzqLPYctpVRFMWgdFotkdciTskadZtMFRUwEnQSBQkKRRdDpzVCxddwAKyAetlmDbtKiySZUQcdTCSExYQqfAIhOnhKqxZvOnHuhauFkYFEtXnjnRdZKKAWGnbulCauRsEfeFscHeCawvpiHdUmvjdRBCdXEStIqUiYajNxDuAyclNoWqnqcdgZ");
    int ZMBlsyFpZnure = 81781410;
    bool iOdfCGR = true;
    int ZluoFehgwoAe = -1787414960;

    if (sznXoN > string("sDLGhMLabArPUUNnsfOPJGhEGruugbaEvQMhFfYBwBgqHIGJfhkmtLdYyZXQpPLT")) {
        for (int WGkTC = 852180850; WGkTC > 0; WGkTC--) {
            ZluoFehgwoAe *= ZluoFehgwoAe;
        }
    }

    if (ZMBlsyFpZnure >= 81781410) {
        for (int oYoDgGvlblNQNqwC = 1842891300; oYoDgGvlblNQNqwC > 0; oYoDgGvlblNQNqwC--) {
            iOdfCGR = bWZcwKgk;
            XnTjdML = iOdfCGR;
        }
    }

    if (sznXoN != string("nUJDIXQQmYFpBWgEqaEtuLERdrXHCFSnNBZCXUyLDHpStekfEVuSTXiRsjmqoDxLwlaElMoeqxJygsnlIJoirXQCHpHvBzWrMUMjwzldcBmOUzCjjpIWLioyQhNjvfREETczesXTATIfwuPHIIzywhzFauWJxWffISsbxizSiPhYODfOtSYTHJPjzEcISaqZ")) {
        for (int xtYpMGVIJ = 350544545; xtYpMGVIJ > 0; xtYpMGVIJ--) {
            continue;
        }
    }

    return ZluoFehgwoAe;
}

string WSqcJGeszCfAmVwf::VWOfPex(string TjVCylLXyeO)
{
    int TrpvfijBGo = 602276229;

    if (TjVCylLXyeO < string("ldVGSjYOBDqpkjeFglewolyYrzwFhgdHADQcECYlrBqpedvVsawHYrgkotgbKxGMkrSJklYqcKehpAjGUsHiIigGLYkujUUgUIWkzLOZDEzpxPyCUPPLqUovQXQIPFYjHDWdxUBRiCWwJZywoVgrOarpMobepbNjsFfWJMDuNbuIcECuqmcBnMdDylnHcxUQzfJzEAQzhheBrxsvdbe")) {
        for (int XCttKfSQOrCrJU = 87174362; XCttKfSQOrCrJU > 0; XCttKfSQOrCrJU--) {
            TjVCylLXyeO = TjVCylLXyeO;
            TrpvfijBGo += TrpvfijBGo;
            TrpvfijBGo = TrpvfijBGo;
            TjVCylLXyeO += TjVCylLXyeO;
            TrpvfijBGo += TrpvfijBGo;
            TrpvfijBGo /= TrpvfijBGo;
            TrpvfijBGo *= TrpvfijBGo;
            TrpvfijBGo += TrpvfijBGo;
        }
    }

    for (int xLvwpomHPqKldEWX = 1048053524; xLvwpomHPqKldEWX > 0; xLvwpomHPqKldEWX--) {
        TjVCylLXyeO = TjVCylLXyeO;
        TjVCylLXyeO += TjVCylLXyeO;
    }

    for (int NMLkZUpeBM = 603560735; NMLkZUpeBM > 0; NMLkZUpeBM--) {
        TrpvfijBGo *= TrpvfijBGo;
    }

    return TjVCylLXyeO;
}

WSqcJGeszCfAmVwf::WSqcJGeszCfAmVwf()
{
    this->LVArWoutqCwTxxY(false, 779599.563424666, false);
    this->qSasoneucwDQ(string("hRLlQMPGWpnsBDVUELnHVchuiTzDOGVjzHhNRgTfljRNwDFFRPyokRAtSwSbpNxLWeQvvFsoiLvVmEGzoiljSuSxVvqjWvxsbhMcZepZEbXcIRckUCtNwwXiUYMhtVwDJyvjFVFYcILHhwebLaCyhhYVRPWPxdjiQLAKcFJzQVpICizRoDjClAFZZIHgjveREELLtnYkwuCMpFTPjZMtLr"), string("KbLCBnNqyOwJDzvlgzplWRLHJdQppwGSbPteqlglkSYAUlhdaXUBlRyrMFlEgSpyeXWObVychlIbkokfrxHxDXazEjwtRhpMWltYfIkpMBcacfsZEFroCRItgGACCTPkahoXOJXGJfYqwcEXefqkkBdHgAvwxfzgoLRScUAOwMRkNghWdmm"), 1016962.7438937007, -205119.65407509834, 572153.4596766956);
    this->pCjDdSiNbEfqUERb(true, 1011951681, true);
    this->cMRITZI(840565.6250947862, -438487312, -75031.90942607594, 321506.3528469871, 1047371.3598106541);
    this->iwAQp(false, 831615.3383654078);
    this->QzdUwhY(610465.5520107853, -1262266302);
    this->DciRvH(-714177.5271069728, string("l"), false, string("IbTtypouDRicdZCRZKFhlWymBUsLnuJMuIOILpdodQJUAWTBudBPmJstFMjFaVofFAshGQRtHCimCUTLsmSsmPVJTwSMIPA"), string("eQPcySGoJhWEJyvuEytiqnumCVAEUZJSFxWpUxnvPlaZJjLqSKtyJIFYhDhJlLSuMRfWFsJgZdyNsdfXvqUHEgFwOjjXJHQCYKXgWsgQqSOvvadKxRXohTLJfxvBZCrddJnXeBvl"));
    this->eYXbJUsoZKw(string("pFS"), string("NbJdQHcGCdbsENOAMhQ"), string("FnjlNKdRfpwqHTGhFFiQPAayVbwjSxXnHZcEWuFqeqduOEMpySNIojWlLOUaCfbIMVnCEucNGOZHUCDrisljEiJqCFEiNmtQEUZlYawAFikGQREAXqroNgATedRHFNNwJGDAGaCzEOawIIcDCbTDPeedcmWHeqo"));
    this->nGnoFRdPPRJkBv();
    this->rxYvGdMWle(813340.589498785, false);
    this->kpDKHbGDKhWOwK(string("cmgHyXMwbBG"), true);
    this->rqKEf(true, string("nUJDIXQQmYFpBWgEqaEtuLERdrXHCFSnNBZCXUyLDHpStekfEVuSTXiRsjmqoDxLwlaElMoeqxJygsnlIJoirXQCHpHvBzWrMUMjwzldcBmOUzCjjpIWLioyQhNjvfREETczesXTATIfwuPHIIzywhzFauWJxWffISsbxizSiPhYODfOtSYTHJPjzEcISaqZ"), -26283.94731994402);
    this->VWOfPex(string("ldVGSjYOBDqpkjeFglewolyYrzwFhgdHADQcECYlrBqpedvVsawHYrgkotgbKxGMkrSJklYqcKehpAjGUsHiIigGLYkujUUgUIWkzLOZDEzpxPyCUPPLqUovQXQIPFYjHDWdxUBRiCWwJZywoVgrOarpMobepbNjsFfWJMDuNbuIcECuqmcBnMdDylnHcxUQzfJzEAQzhheBrxsvdbe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VgfDASNbYWwtwJ
{
public:
    double UePUwNIhcxgRbrfi;
    bool xwIfpwaaGZd;

    VgfDASNbYWwtwJ();
    string vbkwxYlyL(double hGwboUuoE, double CclGe);
    void ZGJNoCVf(string WpGxklkiKbja, bool lAuxtSyZKgvqzBp);
    bool RMMLkcxvzOXKOA(int UBjtQmqDyJfKiQkH, bool XpOKgfHVykqH, double MgMrF, bool gEduwRhkmGYTG, double SeSGEcu);
    string ZMNyNJZSVhhvql(string IRrHcn, int fzXWyfKU, double HvgEztBHoqoQcjQ, string rpQlYV, int hTLtzPLOPKZud);
    string sfXjfMkX(int eCrdqYpfo, string QOLDRQKfng, string AUkPimFy, int pPvDIhAJQQxPv);
protected:
    string LSDjDuQou;
    bool qqXRJVlD;
    string CsPeYepZw;
    double bssdpy;
    bool dHDdUOZmNjTmnN;
    double MxdzIM;

    int NzYfnNf(string TaoQVhN);
    void grlPb(double FAcpYYDMO);
    bool fSaegONADXhjnAQ();
private:
    double zkcLGJtriD;
    bool oobBFzqXLzDma;

    bool aBohTTIt(string OEvAGagJE, string JYgEppixR, double aLQCTlFKqTiV, double ybIYRqKXRW, string srCBTkqwVEKwIfJ);
    void prPOVHpOCIbNzd();
    double leSwOfPzJL(string IzsZWGrZoidwP, bool yMfZwndPjgY, string LMUEJW);
    int nCvatJxfcEWKOuWh(double eWzNeUpDsef, string WRkiBxyLLcFC);
    bool JWmqGMzPBiOF(int qMsfpNaOFzWRp, bool KabGcVkCsvGnnc, bool tzped, int BfDbjlKW, double qpjLoRKEvFmzQBQQ);
};

string VgfDASNbYWwtwJ::vbkwxYlyL(double hGwboUuoE, double CclGe)
{
    double GmrujtIDdzulr = -677760.3397520769;
    string akNWGjUrJkCxrb = string("pJpUQAQvySlaGyDMcfFowQKVNXrSwrIqOryIfJYVCBhIdENteIYVqZfCCovsZSmLZnkDOoEmEnEg");

    if (akNWGjUrJkCxrb > string("pJpUQAQvySlaGyDMcfFowQKVNXrSwrIqOryIfJYVCBhIdENteIYVqZfCCovsZSmLZnkDOoEmEnEg")) {
        for (int IWIHtVF = 1798772645; IWIHtVF > 0; IWIHtVF--) {
            hGwboUuoE += hGwboUuoE;
        }
    }

    return akNWGjUrJkCxrb;
}

void VgfDASNbYWwtwJ::ZGJNoCVf(string WpGxklkiKbja, bool lAuxtSyZKgvqzBp)
{
    string lYalHYXViwOMTY = string("pzMqnCwROtTwDIGSQIufqipHAJoGOtNRlgOOnshouWjcRGBiKxcOUdAmklfaGYeUgCvLnwKSOBGVZkeRRzZXedRdABRMLdGlgBcqxhrdMkaNZhVqjdHBGVVptPtgdCbFAYeMHwNutWHHXingaytExbKpYHGvGgohuqIndBHpFbtZQckKOJ");

    for (int fjictUGFS = 2081639180; fjictUGFS > 0; fjictUGFS--) {
        WpGxklkiKbja += lYalHYXViwOMTY;
        lYalHYXViwOMTY += WpGxklkiKbja;
    }

    if (lYalHYXViwOMTY == string("pdQUfirjSyhrpaMpZNXVHyegFlnhsqfWGUZRGYoMhINPmCFZyatSHKKsoMLBfNFxIHBHDAlVmUandPjTZYhoSkpxUBEWgDcyEvCeIYuWgtEJpXzriGFap")) {
        for (int AkhUDGvB = 952670982; AkhUDGvB > 0; AkhUDGvB--) {
            lAuxtSyZKgvqzBp = lAuxtSyZKgvqzBp;
        }
    }
}

bool VgfDASNbYWwtwJ::RMMLkcxvzOXKOA(int UBjtQmqDyJfKiQkH, bool XpOKgfHVykqH, double MgMrF, bool gEduwRhkmGYTG, double SeSGEcu)
{
    string VqOnVRTmJkHTh = string("DcLkMmwLTaJGGtBsWtBGvhogjKAGIIYOIJIxUsJG");
    double OBgPA = -925465.5573870965;
    double kLCStrLdhwXTpDG = -919161.1589875838;
    double eeqcz = -417137.40334626706;

    for (int YEghcuE = 640764119; YEghcuE > 0; YEghcuE--) {
        gEduwRhkmGYTG = XpOKgfHVykqH;
    }

    return gEduwRhkmGYTG;
}

string VgfDASNbYWwtwJ::ZMNyNJZSVhhvql(string IRrHcn, int fzXWyfKU, double HvgEztBHoqoQcjQ, string rpQlYV, int hTLtzPLOPKZud)
{
    string tcpJtUNLEuRzugS = string("mzNQeQOYPHJdznyGcLLZDE");
    bool VbYuc = true;
    int MZOUgxhS = -1101003257;

    for (int sBlkLT = 464096898; sBlkLT > 0; sBlkLT--) {
        hTLtzPLOPKZud /= fzXWyfKU;
    }

    if (rpQlYV < string("mzNQeQOYPHJdznyGcLLZDE")) {
        for (int FBuauI = 1648159018; FBuauI > 0; FBuauI--) {
            VbYuc = VbYuc;
            MZOUgxhS *= MZOUgxhS;
            rpQlYV = tcpJtUNLEuRzugS;
            fzXWyfKU *= fzXWyfKU;
            MZOUgxhS *= MZOUgxhS;
            tcpJtUNLEuRzugS += IRrHcn;
        }
    }

    if (rpQlYV < string("mzNQeQOYPHJdznyGcLLZDE")) {
        for (int eGduYhU = 159449120; eGduYhU > 0; eGduYhU--) {
            MZOUgxhS /= fzXWyfKU;
        }
    }

    for (int AEeNuwyTGXPKwBz = 90536951; AEeNuwyTGXPKwBz > 0; AEeNuwyTGXPKwBz--) {
        continue;
    }

    return tcpJtUNLEuRzugS;
}

string VgfDASNbYWwtwJ::sfXjfMkX(int eCrdqYpfo, string QOLDRQKfng, string AUkPimFy, int pPvDIhAJQQxPv)
{
    int WNWzstQDqSZ = -1499267887;
    bool CQwnMbsnjB = false;
    bool RLKJLB = false;
    bool vuSgpIvhXtmjX = true;
    double JxHrZANZMlG = 116649.34555996893;
    bool UMiFHFchZUqlOL = false;
    string ZdRZIlhXu = string("ArFUCOCBomVnimSiQ");

    for (int gCLCkaF = 1746381404; gCLCkaF > 0; gCLCkaF--) {
        RLKJLB = RLKJLB;
        eCrdqYpfo = WNWzstQDqSZ;
        ZdRZIlhXu = QOLDRQKfng;
    }

    for (int oLSLaSqgnd = 522372115; oLSLaSqgnd > 0; oLSLaSqgnd--) {
        RLKJLB = CQwnMbsnjB;
        ZdRZIlhXu += QOLDRQKfng;
    }

    for (int bsOWxAsCGT = 173510548; bsOWxAsCGT > 0; bsOWxAsCGT--) {
        WNWzstQDqSZ = eCrdqYpfo;
        vuSgpIvhXtmjX = ! CQwnMbsnjB;
    }

    return ZdRZIlhXu;
}

int VgfDASNbYWwtwJ::NzYfnNf(string TaoQVhN)
{
    double GgzsbSOmWIrHklV = -679547.5539337508;
    double eTDHtDisAZUox = 203735.33796620785;

    for (int fyXntIVY = 233161891; fyXntIVY > 0; fyXntIVY--) {
        eTDHtDisAZUox = GgzsbSOmWIrHklV;
        GgzsbSOmWIrHklV += GgzsbSOmWIrHklV;
    }

    return 2063408386;
}

void VgfDASNbYWwtwJ::grlPb(double FAcpYYDMO)
{
    string SJLGEjKFZotDI = string("fwxKeQtTzfEFDsafMnlqBSmGXeqzTqbESxlPCTfxxWEDprHTQnJQmDwXjsQVSgAcpaWhSosthaTCajnBiyomlAHXjjosywoexnhPKadXbEy");
}

bool VgfDASNbYWwtwJ::fSaegONADXhjnAQ()
{
    double GwTidBxJlPA = 393399.13699560845;
    double pFuBtOVw = 28144.480648212906;
    bool FoyfofSSn = true;
    string yFAUgpk = string("uepjPTYzXdFATSOsbjpKFCHNuUndonrNnjLhYaCjFYoYkXReXwh");
    bool klDjkQyfV = true;
    string oMLRsVf = string("UOkOVSwdNUCYLTTmZAecCieLTNdDsRIdQhLmfzzVSIeMYQNtfUsWOEEJsbBXSJuQtmqHqtdYqXuyVqsRtbicwQgOBBQgX");
    double ynxqAqNAqAAy = -259331.04228762715;
    double ytyrrV = -392976.42887294834;

    if (FoyfofSSn == true) {
        for (int wMkRQswlyuhAXiNp = 2079181423; wMkRQswlyuhAXiNp > 0; wMkRQswlyuhAXiNp--) {
            GwTidBxJlPA /= pFuBtOVw;
        }
    }

    if (pFuBtOVw <= 393399.13699560845) {
        for (int gMalrak = 1811309866; gMalrak > 0; gMalrak--) {
            ynxqAqNAqAAy = GwTidBxJlPA;
        }
    }

    for (int AhTGZgQZb = 1962864479; AhTGZgQZb > 0; AhTGZgQZb--) {
        pFuBtOVw *= ynxqAqNAqAAy;
    }

    for (int vqCRL = 1476862808; vqCRL > 0; vqCRL--) {
        continue;
    }

    return klDjkQyfV;
}

bool VgfDASNbYWwtwJ::aBohTTIt(string OEvAGagJE, string JYgEppixR, double aLQCTlFKqTiV, double ybIYRqKXRW, string srCBTkqwVEKwIfJ)
{
    double MqkbLWwhqDuUax = 541778.6046633746;
    bool FqIbECfoygyZrGY = true;
    double hYVevtkPWV = -332832.357164704;
    string KiMzywLBQwRxY = string("GQTFduScGGjBWzikFOyyGBkWocDfVwHXJrlcDbkuMgNJyTXtLdhlnxCDOcEScqZSYGRdyPnEEVQAKfahmAeapOdEhnYQuLa");
    int kbIrsGrmJh = -967445437;
    string EsPhvx = string("UfewoqgvVXtaQzRpdKicncBtdPbQmgloPZSLmgXvzdFOwvApNQFcAwllKQHQaRGXpQMiktoovgrUxed");
    string ibReModcnUHgjj = string("RoqBgJJkIYkIeHmAifWCBPCRidElDdLcvEANhGZziKsKdJUmLeRHQANRgSMgvCgIQbIcZbRCKHRUqJWLFpGbkQOpmOtifPmImTwSdePuEZUzKcXukeabESNouJshHzIzcXUbSvJzxfUdCCYwBQCDmpLtJEtYQEZYnLiyNXPMzBYxFwcOXJirSr");
    int fbqCHwblAf = -174724068;

    if (ibReModcnUHgjj > string("bbMLHhgFqZbyJxGLxkFBTArDYepFtcBGbYrVXycSBQBagyXzqYIzzQCAdVsgHxlfoyUsjYPSmTPaKNpthFfWluXsUVQGzNMgcmghNqWwylOSEWaFnKXcBJowmNwpMFLPrrHRHjuCbGAE")) {
        for (int bDnjrHaDsUH = 2131989928; bDnjrHaDsUH > 0; bDnjrHaDsUH--) {
            JYgEppixR += ibReModcnUHgjj;
        }
    }

    for (int gFnYXTeQGxevAx = 1956544704; gFnYXTeQGxevAx > 0; gFnYXTeQGxevAx--) {
        ibReModcnUHgjj += srCBTkqwVEKwIfJ;
    }

    for (int EzgDkaPjAZ = 1680588183; EzgDkaPjAZ > 0; EzgDkaPjAZ--) {
        MqkbLWwhqDuUax += MqkbLWwhqDuUax;
    }

    for (int yuDPpVyHQE = 1019472451; yuDPpVyHQE > 0; yuDPpVyHQE--) {
        continue;
    }

    for (int dhDSRHqOc = 833291653; dhDSRHqOc > 0; dhDSRHqOc--) {
        OEvAGagJE = EsPhvx;
        EsPhvx = OEvAGagJE;
        EsPhvx += srCBTkqwVEKwIfJ;
    }

    return FqIbECfoygyZrGY;
}

void VgfDASNbYWwtwJ::prPOVHpOCIbNzd()
{
    double jmYkbYLSpRkXI = -751943.4319139753;
    double JpQdbCPLALhGrgCi = 994441.9338448867;

    if (JpQdbCPLALhGrgCi == 994441.9338448867) {
        for (int kBVgOBtZmDwUE = 1144789385; kBVgOBtZmDwUE > 0; kBVgOBtZmDwUE--) {
            jmYkbYLSpRkXI -= JpQdbCPLALhGrgCi;
            jmYkbYLSpRkXI /= jmYkbYLSpRkXI;
            JpQdbCPLALhGrgCi = jmYkbYLSpRkXI;
            jmYkbYLSpRkXI /= JpQdbCPLALhGrgCi;
        }
    }

    if (JpQdbCPLALhGrgCi <= -751943.4319139753) {
        for (int RNYUBXUQ = 963585106; RNYUBXUQ > 0; RNYUBXUQ--) {
            JpQdbCPLALhGrgCi /= JpQdbCPLALhGrgCi;
            jmYkbYLSpRkXI = JpQdbCPLALhGrgCi;
            jmYkbYLSpRkXI *= jmYkbYLSpRkXI;
        }
    }

    if (jmYkbYLSpRkXI <= -751943.4319139753) {
        for (int DTHHMbNMnoT = 1811571524; DTHHMbNMnoT > 0; DTHHMbNMnoT--) {
            JpQdbCPLALhGrgCi -= JpQdbCPLALhGrgCi;
            JpQdbCPLALhGrgCi *= jmYkbYLSpRkXI;
            jmYkbYLSpRkXI *= JpQdbCPLALhGrgCi;
            JpQdbCPLALhGrgCi += jmYkbYLSpRkXI;
            JpQdbCPLALhGrgCi = jmYkbYLSpRkXI;
            jmYkbYLSpRkXI += jmYkbYLSpRkXI;
            JpQdbCPLALhGrgCi += jmYkbYLSpRkXI;
            jmYkbYLSpRkXI /= jmYkbYLSpRkXI;
        }
    }

    if (JpQdbCPLALhGrgCi > 994441.9338448867) {
        for (int uKpOcPpIcrfHUav = 1651264463; uKpOcPpIcrfHUav > 0; uKpOcPpIcrfHUav--) {
            jmYkbYLSpRkXI -= jmYkbYLSpRkXI;
            JpQdbCPLALhGrgCi = jmYkbYLSpRkXI;
            JpQdbCPLALhGrgCi -= JpQdbCPLALhGrgCi;
            jmYkbYLSpRkXI -= jmYkbYLSpRkXI;
            JpQdbCPLALhGrgCi -= jmYkbYLSpRkXI;
            jmYkbYLSpRkXI /= jmYkbYLSpRkXI;
            JpQdbCPLALhGrgCi -= jmYkbYLSpRkXI;
            jmYkbYLSpRkXI = jmYkbYLSpRkXI;
            jmYkbYLSpRkXI /= jmYkbYLSpRkXI;
            jmYkbYLSpRkXI += jmYkbYLSpRkXI;
        }
    }
}

double VgfDASNbYWwtwJ::leSwOfPzJL(string IzsZWGrZoidwP, bool yMfZwndPjgY, string LMUEJW)
{
    int roMhfyUlECcE = 1669398378;
    int rrFMzif = -966804046;
    int BGWFABasi = -1620952388;
    bool hxNDI = false;
    int GKoTg = -1007592177;

    for (int LOFXFlG = 943491691; LOFXFlG > 0; LOFXFlG--) {
        BGWFABasi += roMhfyUlECcE;
    }

    return 693713.4520321109;
}

int VgfDASNbYWwtwJ::nCvatJxfcEWKOuWh(double eWzNeUpDsef, string WRkiBxyLLcFC)
{
    string HzLupcehLKNMk = string("fsUIvHTvjWRRUSKORigIVCrkxchkZlAPhthHleBtMNyHmnbitpWPGXZfTeQvNpkyMZvEN");
    string fkQFqjbCtLFy = string("ahJpHfBUxbpxKCuGqzKrdhyqQwUXrKbJcCRpYbdRVFwJEJpTrdPIXSFWtkHFrXkQMLAYSJoMmlBKgRqePrHauYdZaIYVgnUGediwTxqaHKHJuuVGAOsHOQdKMoBwTnIlzSechC");
    int otLwqcd = 545727908;
    string DRTRLnqQABeTNz = string("YtmHlFHPNrYUyoefazzaFpUqZVMVATvXnUOkQIuCIDAdmGZqhgCWqHpoKeOiuqnmZcIbazZUVHGVeIeCnaLRYKfYMZGxXHoizUEQuMi");
    bool vdmjoxLvpbaK = false;
    int pQxyBX = -1504716902;
    string mQiijk = string("vEAHYCmaWjWrwnBsDfGrTHBtuKhQtoNlkkYJMIxHHbsSYSZfyLtrWQrunisqFjPqNodNZXwpHJFgMbafTpuqHSyjHQQeaunoaAwDLcwOfCHCkXXWGxAzyMpFKQzMQc");
    int shhShGyvfJohZq = -541057472;

    for (int pnyQeVBZjmmoQ = 1854572895; pnyQeVBZjmmoQ > 0; pnyQeVBZjmmoQ--) {
        pQxyBX /= otLwqcd;
        mQiijk = WRkiBxyLLcFC;
    }

    if (HzLupcehLKNMk >= string("YtmHlFHPNrYUyoefazzaFpUqZVMVATvXnUOkQIuCIDAdmGZqhgCWqHpoKeOiuqnmZcIbazZUVHGVeIeCnaLRYKfYMZGxXHoizUEQuMi")) {
        for (int ebTNzZgBeWZquQ = 1289589503; ebTNzZgBeWZquQ > 0; ebTNzZgBeWZquQ--) {
            WRkiBxyLLcFC = fkQFqjbCtLFy;
        }
    }

    for (int OEdrCHk = 2005457496; OEdrCHk > 0; OEdrCHk--) {
        mQiijk += DRTRLnqQABeTNz;
        otLwqcd -= shhShGyvfJohZq;
    }

    for (int hPGAZNhYwZ = 2018525350; hPGAZNhYwZ > 0; hPGAZNhYwZ--) {
        mQiijk += mQiijk;
        WRkiBxyLLcFC = mQiijk;
    }

    return shhShGyvfJohZq;
}

bool VgfDASNbYWwtwJ::JWmqGMzPBiOF(int qMsfpNaOFzWRp, bool KabGcVkCsvGnnc, bool tzped, int BfDbjlKW, double qpjLoRKEvFmzQBQQ)
{
    string dfajcVchMAVkJhMQ = string("COWkHUHdqDlswKXYbReuGZpFNACaPruewBRZxGxHhLJIJhCJZOUqoiKeNugxpDbbcQzVkCehxALWPjZeDZAANrJmAxSzLCXzI");
    int kbfKNkNAjod = -1026098342;
    double mJoXcqJyfCNT = 1020842.2434028133;
    int hMKJrjx = 391342988;
    double QeTswK = 577225.3352049758;

    for (int teKfc = 1629803593; teKfc > 0; teKfc--) {
        qpjLoRKEvFmzQBQQ /= QeTswK;
    }

    if (hMKJrjx < -2036274782) {
        for (int BcbyRaeUcbvRPii = 815314434; BcbyRaeUcbvRPii > 0; BcbyRaeUcbvRPii--) {
            tzped = ! tzped;
        }
    }

    if (BfDbjlKW >= -2036274782) {
        for (int JBcbRb = 887549662; JBcbRb > 0; JBcbRb--) {
            BfDbjlKW += BfDbjlKW;
            KabGcVkCsvGnnc = tzped;
        }
    }

    return tzped;
}

VgfDASNbYWwtwJ::VgfDASNbYWwtwJ()
{
    this->vbkwxYlyL(-802718.3575975429, 448722.4954431313);
    this->ZGJNoCVf(string("pdQUfirjSyhrpaMpZNXVHyegFlnhsqfWGUZRGYoMhINPmCFZyatSHKKsoMLBfNFxIHBHDAlVmUandPjTZYhoSkpxUBEWgDcyEvCeIYuWgtEJpXzriGFap"), false);
    this->RMMLkcxvzOXKOA(676222713, false, 221078.48092136974, false, 216997.11352868428);
    this->ZMNyNJZSVhhvql(string("VyLajWsTWUQGdeAzgNFqmJmvXhiBDPtaREYcOTCKjxJjfWRsfotBqLqZovcHgKUtgwlgwEkScYonYGjKEQzrpUQnApZvXjcgggGQLLbxXiMwbsYIVsvDtBBldXhNOEtqhsgWjeJUHMzHrhpwjMNLJCNBFAARYFkTmjspGuRccNjesUgOnNKpkhGjCOJtbQafnMzMaGyaCOAvXDjyGsDEibDcxSQT"), 1681223539, -861978.7956832421, string("ELSTNxeoqJHsstdoWiRcRuKcUjdlXEmsKLokToFUSWTnAdWTUgWpqwiOcEwYmKuoSgjiouFUXSIxCgCKUlpApex"), 987367578);
    this->sfXjfMkX(-806088302, string("pkDWWoqnbgwCEfRcOrpvuNwdZqcYLdpKfEENcuCqsgLGUiJQsWrVfvgJFPpRPLdDasirtZChPYiVZpSyonqVZevhQjTWRBvNUcjSPsgsosyJMJlCcHsOyySMEDWSuPWTZXqwWdbxjdpTWtQqoUhNkgJqDuiQqEGgwBsIVDBjxVdemYJEWsSpTkibvZOyrkPVHsRFvbjCPWYNxgAKKDhxLTuNWghoWkmfdxVWN"), string("IgYqVfCUCdJbBtqNnVVqQKKJidvxWpvXalrzmkTsQscQVxLceaVJiKquzewLDXXJxHqdoQzZCzazallHiXcibuWThITrggxwGMlwFbRFNhzDGYbIAEbnFnPNseWwlbNzUUuNdcWsBvdCdfNaJGMuEqosVlFOoStkYvzYhJhheYkqrznFMLvUcRkREarHIoFjFJcoFifpwPTpYkyOjUCAbVUDrKnFvewJlLPBscU"), -1059677881);
    this->NzYfnNf(string("OBYsJASZGtsCsOreCbXPUobQVfxBcPXcBvBfxcIiCmejvoAMRQxbtDXaiuigrMYqCBXCRHuCLbvJohVkBduFciuUVOnWPfMthybNBlwcbrkLIzPzgCijpfqoGCmOBRHLafnNRuYNBKrqJgIXbAglgMKfgUYrWijbOWkYrrTezUJzjRDylCezzBmdqoJpbDMvobFTTFkfmevaAIwwgmMcZtUPOywTvQMnEeXLJocnLjfNPmHBls"));
    this->grlPb(-797849.0936494078);
    this->fSaegONADXhjnAQ();
    this->aBohTTIt(string("bbMLHhgFqZbyJxGLxkFBTArDYepFtcBGbYrVXycSBQBagyXzqYIzzQCAdVsgHxlfoyUsjYPSmTPaKNpthFfWluXsUVQGzNMgcmghNqWwylOSEWaFnKXcBJowmNwpMFLPrrHRHjuCbGAE"), string("txIahmbkCxDoApglUPIjLgqiJfRkGMCvwFhEaljavBmYWvyaQKYqzftYgRludXJwRGyIxoJtLNKlaNvZFfmrkoMqQuDevgyZEStvLoTEbqhYQplPkDwCPAJETMpkCzvEWCBCZgGxRsyiErCuzbQCJIgth"), 357369.7263755029, 851034.4018032654, string("SJkjrzGjgTlgkiyzmirEtAsRtEQiWyBqXAbTXIBnkmbwgTRsBubVdI"));
    this->prPOVHpOCIbNzd();
    this->leSwOfPzJL(string("drWODYzMwHEwCALsztMUnBcEYJJGeSQASzKPuedYFXfebMoWYBmdkqbTbeoOXmdFaqpDDzkqwBJGzOLrdcdaTmGTlEPizYQYqlblgrVpWlhilQSOBfSYsOEIYKVtmqVsmGpBlMlghpMKCOzXjxQPvbVgFeQBScEAtbesXxkoSPGmTkLKdDWmZEdISqFLZsiBnIKXZcBFvyuvJsviOjHveAIBgrCzdywVynNrpJCrgoouVqp"), false, string("wqaCYhyjimooiNtqqwMMHovTfxqrjFLNJXallGtJBTmaGqEdcumwYNClHlDVdlIusMB"));
    this->nCvatJxfcEWKOuWh(-868198.4300143286, string("wiTYYSTIScdMEHOIbVrxdpJUmgwATHJuOkwiPqFLAcGdojJGonnrqGVUzRTdBcuuSbEFNxmaaiGZOfJoAAsIICnKiCgINgWaSvzzzbUzyoDxuMSCYxGmUqvKywEhTrgMNfixNYsYOrTGPjqUSJAMPueJxYqLDmgrsSoMXivTIuvBdAPmIScpAOfjvsATXihzBZSBCobNXonxQsdHQjIHmAoROdUxumqqSsCyniWOgTEacscySfnTDFmJBJryCqR"));
    this->JWmqGMzPBiOF(-2036274782, true, true, -671412440, -268559.6361003779);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QhZuwKhxQr
{
public:
    double Olzae;

    QhZuwKhxQr();
    int znRef(double acgUV, double cowmwQXwPfTh, bool GEzijsym);
protected:
    double YwTsCoeeINo;
    double ScTGzd;

    string NbOrFsXKLY(double ClaAEG, double RXCQOczIBd, double YInHsoeEyvxNuLc);
    double DlkIznHdo();
    string PCFIGnzMzoUmeEQ();
    void zsfcvKFaoGYQPB(bool vIDuyqkljxYnXoPM, bool gOiWRVhKJNrD, double DFnJWJyqaKJpZhu, int RgHOYCBrgE, bool ITvzkxt);
    double fQPWysPvxe(int PIpWSXHJWLWp, double cdnot, string AGlBYDxYZ, string ESFHtByWnVIX, int SLCNxblcUvYEAY);
    double MXJhsHUTLlrTmsyf(int ioFALHVH, double HbMRshlcmArada, bool gDLoYVVDE, double rkYdhm);
private:
    string cPigiXyKhmvCcD;
    string zlITRtYNeiBP;
    int mfXWktiHfX;

};

int QhZuwKhxQr::znRef(double acgUV, double cowmwQXwPfTh, bool GEzijsym)
{
    string iCFjCLH = string("QlHqkcXsCoDlPZLRkCKHeubWVUNLcILBBxwoFwnFleWCqWkPyYZTINCLCIfzlcpjTkUJZpVCyGAeZXtvZsrIUYuEKYXiPK");

    if (acgUV <= -845663.095554422) {
        for (int jRTus = 1470065239; jRTus > 0; jRTus--) {
            iCFjCLH = iCFjCLH;
            GEzijsym = GEzijsym;
            acgUV *= cowmwQXwPfTh;
            acgUV /= acgUV;
        }
    }

    if (iCFjCLH <= string("QlHqkcXsCoDlPZLRkCKHeubWVUNLcILBBxwoFwnFleWCqWkPyYZTINCLCIfzlcpjTkUJZpVCyGAeZXtvZsrIUYuEKYXiPK")) {
        for (int LsgdabC = 369698660; LsgdabC > 0; LsgdabC--) {
            acgUV += acgUV;
        }
    }

    return -1692517261;
}

string QhZuwKhxQr::NbOrFsXKLY(double ClaAEG, double RXCQOczIBd, double YInHsoeEyvxNuLc)
{
    string LdWBpkVBkRQKLoC = string("yxSfFAPAMBYz");
    string taMYqKDNwVNUcsb = string("TpjIrekNvAyeGtBlbzwQKKeqGFmpyXCOWKKMteIizGWNaGuvBKkkQcVweyWhyWbYeZhjBOwZoScOrotrco");
    string jissTIvUDAWFQ = string("HygQZTXFFBMEqoNbiaBoyfAqAtzzUPiQatibdeTSZaTncrKRTYLMObfabvFixIuZNGdRqJTmxRzXURaoPazWfYmjQQRxueEIs");
    bool HOLVnLEDBp = false;
    bool huKKlhNYbHlOjxG = true;
    int RmDRLOAmpDEtuHqw = 1840822102;

    if (RXCQOczIBd < 610286.0961041535) {
        for (int gYFIaHuisvXoR = 2068458478; gYFIaHuisvXoR > 0; gYFIaHuisvXoR--) {
            LdWBpkVBkRQKLoC += jissTIvUDAWFQ;
            HOLVnLEDBp = ! HOLVnLEDBp;
            ClaAEG *= YInHsoeEyvxNuLc;
        }
    }

    return jissTIvUDAWFQ;
}

double QhZuwKhxQr::DlkIznHdo()
{
    string qcIMhnJL = string("cHXcpUtOgXpQqROqZky");
    bool HOoooxzJ = false;
    int fUUXaTSOecI = -1917310335;
    string VAyWIJynwjqwsB = string("bQMNXgtMNaMTEQVtkCTQfFJVreNezKSoVXzlWrRrzYfxYakMCGABLbYLdJxdwlSkauiNaXdJrsRLzcKJOMnSqiIRColntxTncpJLMPNwuRtTAKLnZBYrUzpDmxCzSlifPPQdgUGayZktsxXzlJyTgbccuqLdrhXkkINyjtMSDRCvltrNzPUoGSdYdDfSbTGYPyoaSnlGWnbpdMVcQGY");
    int ontkZUa = 1581326036;
    int pJAzDTvFmfZH = -1042200378;
    bool tTOnIaouOIqpwCX = false;
    string pMoZHL = string("QFgsKlUrFPFbpjuZoosetJudufWCAvRlqYQFrWNrJyfXAddnAjPjMeBXjsGvYkFPt");
    string YDsTqaQsBdgIO = string("PBpOqudaCoYDzsfFUlsBojdedAekhxeKNhXRlZTNJOBltaMNOfDNXoyyqHsKemZYycvksPRiEdyxldTZisdNqfEwoQzfuBRZHxPeJOZezjhjLRnONhnPKaGdyFRYBzIqqBKxuEH");

    for (int VwukX = 657248210; VwukX > 0; VwukX--) {
        YDsTqaQsBdgIO = YDsTqaQsBdgIO;
    }

    if (fUUXaTSOecI == 1581326036) {
        for (int CpTzABumoYoZKb = 518585510; CpTzABumoYoZKb > 0; CpTzABumoYoZKb--) {
            ontkZUa += fUUXaTSOecI;
        }
    }

    for (int euNnFqbfxytL = 1471970050; euNnFqbfxytL > 0; euNnFqbfxytL--) {
        VAyWIJynwjqwsB = VAyWIJynwjqwsB;
        ontkZUa -= pJAzDTvFmfZH;
    }

    for (int jXlosfPZsW = 104235980; jXlosfPZsW > 0; jXlosfPZsW--) {
        continue;
    }

    if (ontkZUa == 1581326036) {
        for (int nrKavckdYvkUzYOK = 1222433456; nrKavckdYvkUzYOK > 0; nrKavckdYvkUzYOK--) {
            fUUXaTSOecI *= fUUXaTSOecI;
            VAyWIJynwjqwsB += qcIMhnJL;
            pJAzDTvFmfZH /= ontkZUa;
        }
    }

    return -359135.5022076389;
}

string QhZuwKhxQr::PCFIGnzMzoUmeEQ()
{
    int YBkmx = 545551970;
    string tEmMaJcTyAoqQQmK = string("hGzfzjZcGKEyqRbRKLGmlD");
    double JjIypibXJ = -724138.9273672767;
    string bmeNmJmXyucOCivU = string("ObLYmlhttYltssDFJTjBVxPTEyFgfNUUAPtCHCnqSvLZwSLkFcgctJFHSaxlHOKhtZfzelXvPVdPiXvIyvgEwciFtxZWBvIZhQkWhkgdmwjhkbQudDzrCNnhwFqrcdzzfNaCJcAndxhfRqqpMjNFbnveludSUrNqwVhfFBDGLSkHhfgkOnDwKbUepTxqjKhujPLrPCSosNYADnBZdUWulJqNjnYtYDQARZDzfZQEphohUfcJExOrycRZrUsWNU");
    string IfZKYxefkvqotsv = string("RoVqNLREak");
    double WiDKPyawdXClCck = 948646.3425850611;

    for (int tmBpYQzKbNgFg = 883555871; tmBpYQzKbNgFg > 0; tmBpYQzKbNgFg--) {
        IfZKYxefkvqotsv += tEmMaJcTyAoqQQmK;
    }

    if (IfZKYxefkvqotsv == string("hGzfzjZcGKEyqRbRKLGmlD")) {
        for (int DQGnAqahVDYOx = 1071252673; DQGnAqahVDYOx > 0; DQGnAqahVDYOx--) {
            continue;
        }
    }

    return IfZKYxefkvqotsv;
}

void QhZuwKhxQr::zsfcvKFaoGYQPB(bool vIDuyqkljxYnXoPM, bool gOiWRVhKJNrD, double DFnJWJyqaKJpZhu, int RgHOYCBrgE, bool ITvzkxt)
{
    int tcrtpD = 1500896964;
    bool TJnYHh = false;
    string aPkuc = string("NRcYzIYEvSMQunyXNiGXPxpFghgCPiQYRLhjFcYOwryVKOqzwyophxjLsLiMWlwlInSYhLszzXGwEIDCIamjvhSBsaVZvvMJVjWjlWYelFYGbNoFBE");
    double bSmCvxukeyQMiSi = 692375.9569227973;
    double knsMjNuUHRESzd = -615273.052270009;
    double QgEkY = 436962.4757772479;
    string uSOLJFhgV = string("TWNbsRHnGxKnvfAWvEJlneXdxYgTmcRZypOTcGWRZaqM");
    bool YVqKK = false;

    if (TJnYHh == false) {
        for (int JPofNvBlLJqWoDn = 1448588394; JPofNvBlLJqWoDn > 0; JPofNvBlLJqWoDn--) {
            uSOLJFhgV = aPkuc;
            TJnYHh = ! vIDuyqkljxYnXoPM;
            knsMjNuUHRESzd /= DFnJWJyqaKJpZhu;
            vIDuyqkljxYnXoPM = vIDuyqkljxYnXoPM;
        }
    }

    for (int hZqOwDIDiarpQGh = 191195484; hZqOwDIDiarpQGh > 0; hZqOwDIDiarpQGh--) {
        continue;
    }

    if (vIDuyqkljxYnXoPM == false) {
        for (int CaDXiXRtTX = 1134542231; CaDXiXRtTX > 0; CaDXiXRtTX--) {
            gOiWRVhKJNrD = ! gOiWRVhKJNrD;
        }
    }

    if (DFnJWJyqaKJpZhu == 491184.6822127968) {
        for (int lCBzwxaxfQhgUkJg = 260420345; lCBzwxaxfQhgUkJg > 0; lCBzwxaxfQhgUkJg--) {
            YVqKK = ! YVqKK;
            TJnYHh = ! ITvzkxt;
            bSmCvxukeyQMiSi -= bSmCvxukeyQMiSi;
            YVqKK = ITvzkxt;
        }
    }

    for (int xYgeUobPDMlst = 30532667; xYgeUobPDMlst > 0; xYgeUobPDMlst--) {
        TJnYHh = ITvzkxt;
        knsMjNuUHRESzd /= bSmCvxukeyQMiSi;
    }

    for (int XTRwalGW = 605384048; XTRwalGW > 0; XTRwalGW--) {
        continue;
    }
}

double QhZuwKhxQr::fQPWysPvxe(int PIpWSXHJWLWp, double cdnot, string AGlBYDxYZ, string ESFHtByWnVIX, int SLCNxblcUvYEAY)
{
    double sRJtfQERKSl = -95785.48902163081;
    bool kfDVcMHMXTAifH = true;
    double ZgrtmnlFtc = 100710.10989804298;
    bool QekUqgtvDLCjXBq = true;
    bool rEKJbcinNjHh = false;
    string PDhyOYuB = string("ctVLVgZLEPHouUHSeJWIQmxldXWyCTTIQXilwqpPJknBqlYIVfahLAjMiCxRwhEhEkpUTxEqPDoBYWOBqenUwAwaUmvxGcMsCqWeUEdbVzKkCjIPrrAJWifn");
    double emEpSsGD = -327093.38881951896;
    double NGbDaiFvDiLk = -189046.29117307093;
    bool WEJPDWbAFy = true;
    string LOXRBLVO = string("xpfuSSSHYneXUuScjliomFxwoqZQDVfshpsKrcyjLeODNtTBOHosDrTqPiOlqfxpcOTsjTehPhkYaEkpZzMyxuvWntugGAPgiIgGpQqimJHMxjDtOOALXWHemdZaMJsYGdPvmWsdIcLEJBD");

    for (int bJRxp = 689298780; bJRxp > 0; bJRxp--) {
        cdnot *= emEpSsGD;
    }

    for (int ctMRIMpDqkn = 107281507; ctMRIMpDqkn > 0; ctMRIMpDqkn--) {
        cdnot *= emEpSsGD;
        AGlBYDxYZ += ESFHtByWnVIX;
    }

    if (WEJPDWbAFy != true) {
        for (int eDKjTat = 530083233; eDKjTat > 0; eDKjTat--) {
            continue;
        }
    }

    for (int TCpqRN = 423536864; TCpqRN > 0; TCpqRN--) {
        ESFHtByWnVIX = PDhyOYuB;
    }

    return NGbDaiFvDiLk;
}

double QhZuwKhxQr::MXJhsHUTLlrTmsyf(int ioFALHVH, double HbMRshlcmArada, bool gDLoYVVDE, double rkYdhm)
{
    double NoWgYFbGV = -35986.64375272615;
    int hWKbuvDJrXCVo = 1041652151;
    int EPAWbwgdTkOheui = -1420302869;
    string VZzUl = string("pThIGaIHJFMEwyXZIXeLvFhtiTOKLGJExdohnSUNagZzYPBGqKicPALFhoNGgrpaEZSlAAGkglNitJHJMbOGAnkDYAKFFyKQYwElHMPyTTXgArtpabxKBYGfZXhIKevErUyPOyadlFIAzLULPforlEytrJmiXWlxvxJRUsjOgrFIjijyUAaHsXrmYngVYYO");
    int QykLzbUBh = -1536745743;
    bool UOIuAVRyPZCw = true;

    for (int FECvbw = 1896722687; FECvbw > 0; FECvbw--) {
        QykLzbUBh -= QykLzbUBh;
        hWKbuvDJrXCVo += EPAWbwgdTkOheui;
    }

    return NoWgYFbGV;
}

QhZuwKhxQr::QhZuwKhxQr()
{
    this->znRef(605413.5958821756, -845663.095554422, true);
    this->NbOrFsXKLY(332793.30969970644, -171816.03525005738, 610286.0961041535);
    this->DlkIznHdo();
    this->PCFIGnzMzoUmeEQ();
    this->zsfcvKFaoGYQPB(false, false, 491184.6822127968, 71148397, true);
    this->fQPWysPvxe(631650308, 341238.6028109906, string("UpxEodoqDrMalgNVMQTBHyzFfA"), string("tlRxsPwVekujQkgvSVR"), -1470850773);
    this->MXJhsHUTLlrTmsyf(-1939117262, -628470.7951028228, false, 454894.54802049865);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KbbIv
{
public:
    double DNJridX;
    double QZssG;
    int zbFwabR;
    double aPpzTMfPQgFewl;
    bool gnlXAfPohGV;
    bool FoMqUn;

    KbbIv();
    bool mdgSUYjcLdkkuPKf(bool kQymjTk, string GejlUiwbRqLxnI, int SchTxOjlBG, int JppUpedWaUMKvj);
    int DVFXekwRUVf(double wLsMKfhToCvZLZq, string AYPGeSZm, string HzetoBuFrF, bool MdxztZpLLhPeM);
    double LMtbgywOiQVZHlk(double KGnTtlbNJpy);
    bool WpAWQfbpL(double ZHzFWBdbGh, bool sBfDcF);
    void YQmMjxrR();
protected:
    int Gddlh;
    double kkPYYSQ;
    int DYlqXhBBHjH;

    string ikIhkyNLW(string ZPnbHZsXQuPkfYPf, string IrxXBeIxzQy, bool PDlBZDLP, string iCifFrzuQbvP);
private:
    string gJGPJHUvJx;
    string uxlyPwSrzDjq;
    bool UcVwnuQJBkrOxZn;
    string clYQaRGxZnY;
    int dtNTHjjlh;
    bool NiYlceXXv;

    int qNnoZBgnoeTuXcoS(double zDmRC, int puHRkdZzIdHlZJH, bool FdxeOlMRp, bool JILoTCnoUkE, bool RBwvACnP);
    int JejaxjwpqQQlMb(int zvZrufPNNYHmCxn, int gvKPkP);
    bool BFyQSMbjJqgn(double EYVHkZwI);
};

bool KbbIv::mdgSUYjcLdkkuPKf(bool kQymjTk, string GejlUiwbRqLxnI, int SchTxOjlBG, int JppUpedWaUMKvj)
{
    double cVRULxdfsFl = -534677.7730305952;
    string xrhFssCgjxBmzSAE = string("pgLT");

    for (int YcQtLiclRMDU = 158742083; YcQtLiclRMDU > 0; YcQtLiclRMDU--) {
        SchTxOjlBG -= SchTxOjlBG;
        kQymjTk = ! kQymjTk;
    }

    for (int zcDIWOcMgVa = 741188255; zcDIWOcMgVa > 0; zcDIWOcMgVa--) {
        xrhFssCgjxBmzSAE += xrhFssCgjxBmzSAE;
        JppUpedWaUMKvj += JppUpedWaUMKvj;
        xrhFssCgjxBmzSAE = GejlUiwbRqLxnI;
    }

    return kQymjTk;
}

int KbbIv::DVFXekwRUVf(double wLsMKfhToCvZLZq, string AYPGeSZm, string HzetoBuFrF, bool MdxztZpLLhPeM)
{
    double edNxJGHXT = -813359.5873074926;
    double KyjcnDnwz = -37647.46198868766;
    string xEQaLwzQitSd = string("aJNWFJOsWGDjyeWnHLjUfzDYBrkQsilXwfbLXycyGXEjBjJofiEtRcjXyCpVYyAeGpZGECqJZZpCROIAOvAbJpxrFUrUvJJzNcrqOwikSdrKezvbUYvIMbjaYUStwiUQQPbYZgfznbMqIITFviNLtFuhYcRLQtknzMbTiNTVrPvlsGCjeUNYbWieaDoCCWDKtZWErOhRXctyynqumHWMLHnOVCqVtWOAoKjXignerzoZFwk");
    bool biXsm = true;
    double bsBRVzaYlj = -47222.39082671803;

    for (int QJzvBIKVBS = 542285346; QJzvBIKVBS > 0; QJzvBIKVBS--) {
        edNxJGHXT -= wLsMKfhToCvZLZq;
        HzetoBuFrF = HzetoBuFrF;
        HzetoBuFrF = AYPGeSZm;
        HzetoBuFrF = xEQaLwzQitSd;
    }

    if (MdxztZpLLhPeM == true) {
        for (int yTCNQoEKOCzd = 1450333546; yTCNQoEKOCzd > 0; yTCNQoEKOCzd--) {
            bsBRVzaYlj /= edNxJGHXT;
            xEQaLwzQitSd += AYPGeSZm;
            KyjcnDnwz *= bsBRVzaYlj;
            AYPGeSZm = xEQaLwzQitSd;
        }
    }

    if (bsBRVzaYlj < -37647.46198868766) {
        for (int ScjRlUqGnnIkqM = 94754408; ScjRlUqGnnIkqM > 0; ScjRlUqGnnIkqM--) {
            wLsMKfhToCvZLZq *= wLsMKfhToCvZLZq;
            HzetoBuFrF += AYPGeSZm;
        }
    }

    for (int DWSJeQ = 1021157310; DWSJeQ > 0; DWSJeQ--) {
        KyjcnDnwz *= bsBRVzaYlj;
    }

    if (edNxJGHXT != -37647.46198868766) {
        for (int HSvDTvJS = 73592813; HSvDTvJS > 0; HSvDTvJS--) {
            biXsm = biXsm;
            KyjcnDnwz *= KyjcnDnwz;
            xEQaLwzQitSd = AYPGeSZm;
        }
    }

    return 1480879415;
}

double KbbIv::LMtbgywOiQVZHlk(double KGnTtlbNJpy)
{
    double iSXBDDwOnYS = -226814.42908458502;

    if (iSXBDDwOnYS >= -66383.7472401039) {
        for (int bBzdREZNUMj = 469653577; bBzdREZNUMj > 0; bBzdREZNUMj--) {
            iSXBDDwOnYS /= KGnTtlbNJpy;
            iSXBDDwOnYS -= KGnTtlbNJpy;
            KGnTtlbNJpy = KGnTtlbNJpy;
            KGnTtlbNJpy -= iSXBDDwOnYS;
        }
    }

    if (KGnTtlbNJpy > -66383.7472401039) {
        for (int xfvfBgUVCjhF = 2045273056; xfvfBgUVCjhF > 0; xfvfBgUVCjhF--) {
            KGnTtlbNJpy += iSXBDDwOnYS;
            KGnTtlbNJpy /= iSXBDDwOnYS;
        }
    }

    return iSXBDDwOnYS;
}

bool KbbIv::WpAWQfbpL(double ZHzFWBdbGh, bool sBfDcF)
{
    int PZcKtWyzsQjZZjzE = -23487479;
    double dFEvPavXi = -942706.2487921035;
    string tVJCeneeH = string("xQdjwXeIKHBGNSFtxPuJhMCtfwoevbcgwbunzMRYHBujcKjqWvlmRnQsMj");
    string iwLnzUqLqk = string("JIuMdEuhrfFvOXCUoVmLMKSELWmFuFOwXvgiPrbUkpNqYxymJhJXbQvxrqhBOnuIeeZSifqiuwuYpglbzoQtxlitcQJKIpftxOGcHjrlTrfnyFQqTz");
    bool cFyFqhnVNmkTu = true;
    int jSjbIPl = 381031020;
    double oRawPh = 50661.810159042056;
    bool eRruuL = true;
    string xbOOdqjEa = string("LTvIHZftoAnfovhzNOPTlexOmPySaMqeQqXvBESACXzUBCVIeoGNSVikegaNANMiZsqwBpBYDlPUwPiJSPFInMxtBHEzCJGVmmAq");

    for (int KeTtOJkamG = 924829697; KeTtOJkamG > 0; KeTtOJkamG--) {
        sBfDcF = ! sBfDcF;
        oRawPh += ZHzFWBdbGh;
    }

    for (int aHHWBFAOueAcxc = 1217231890; aHHWBFAOueAcxc > 0; aHHWBFAOueAcxc--) {
        cFyFqhnVNmkTu = ! eRruuL;
        ZHzFWBdbGh = ZHzFWBdbGh;
        tVJCeneeH = iwLnzUqLqk;
    }

    for (int nBhEDQKgrtFyFao = 1801012056; nBhEDQKgrtFyFao > 0; nBhEDQKgrtFyFao--) {
        xbOOdqjEa = tVJCeneeH;
        eRruuL = cFyFqhnVNmkTu;
        oRawPh /= ZHzFWBdbGh;
    }

    return eRruuL;
}

void KbbIv::YQmMjxrR()
{
    string OihLUykq = string("atSizrGNBIoSUKvddjakImIMGAPSrPulxEUdxdrqbraivmqXSTrulHHzAudndMtiYZXUrKJlrNioxWbshUiGDaZLMRVfpBodBmaiisYVSGNdBsSBLQevbyNxAJuBFXeCIHYCgFcKiLkgIqotINVASGnUwiVGWZzsrsseWAtrquhFoflKqthqnLGxklpTkXDtFBZwokJj");
    double pFoJpSOKoHXjRnIw = -462388.7058938059;
    int aRvZWGXKwMuJSkvf = 376520983;

    for (int vVdRqNzdYLNKieu = 1482635203; vVdRqNzdYLNKieu > 0; vVdRqNzdYLNKieu--) {
        continue;
    }
}

string KbbIv::ikIhkyNLW(string ZPnbHZsXQuPkfYPf, string IrxXBeIxzQy, bool PDlBZDLP, string iCifFrzuQbvP)
{
    bool DePpsRzqKpUHOpD = false;
    bool mEOucqvYxICi = true;
    int aEAUJgDbCWXy = -2047908496;
    int hILuJlyHLUJh = -1334096331;
    bool fOJgT = false;
    int WHZBqlmltyFF = -638581060;

    for (int VEgGFwUq = 1432598072; VEgGFwUq > 0; VEgGFwUq--) {
        aEAUJgDbCWXy -= hILuJlyHLUJh;
        IrxXBeIxzQy = iCifFrzuQbvP;
        mEOucqvYxICi = PDlBZDLP;
        IrxXBeIxzQy += iCifFrzuQbvP;
    }

    for (int EbnpatOkRTCnNJ = 1099746656; EbnpatOkRTCnNJ > 0; EbnpatOkRTCnNJ--) {
        continue;
    }

    return iCifFrzuQbvP;
}

int KbbIv::qNnoZBgnoeTuXcoS(double zDmRC, int puHRkdZzIdHlZJH, bool FdxeOlMRp, bool JILoTCnoUkE, bool RBwvACnP)
{
    int oarmokBkyCGDn = -269970151;
    double BRLBs = -155069.48711776757;
    double kRBztTtNjKdeO = 100544.31299463077;
    double hSaUgG = 626204.8849462079;
    bool EHfAX = false;
    string kQZhGUSW = string("kcMrwAevnGlSewaahbUkUOooGdPojqvCxgPnlVbasgISCCeNlpuzvvNhuJUEFMHhQZljvUOMJcDrNDsxSyoCTkX");
    bool qgSCeCig = false;
    string vRkoj = string("fxiYTgyAheqwofOEEHRNRuBnPWJyMSmoCUvTAvuQRFTQDcsFtjvaIvrqemUK");
    string jqJxdKhf = string("CpQITljCRXJqPfdtvDKdItjGyKsajrIUIcHWSqMnsrEnDMvnbkAnPXxPcJJpNYhwYOtpnwIJzHLdPGVBZzOqMvdFxLsomNKezmxSWJVhLcbWNhasjzgpkYsCTuzzLhbIYbDiPhmTrRnxLcQAvGviZGQjNdBQLCFJzyWYMZpPb");

    for (int nBUmcmBhVXd = 1092108934; nBUmcmBhVXd > 0; nBUmcmBhVXd--) {
        FdxeOlMRp = qgSCeCig;
        EHfAX = EHfAX;
    }

    for (int jZxiEv = 1016148806; jZxiEv > 0; jZxiEv--) {
        EHfAX = qgSCeCig;
        FdxeOlMRp = ! EHfAX;
    }

    if (EHfAX != false) {
        for (int OVjqPkquksdXma = 1638188860; OVjqPkquksdXma > 0; OVjqPkquksdXma--) {
            qgSCeCig = ! EHfAX;
            BRLBs -= kRBztTtNjKdeO;
        }
    }

    for (int IeuIMQJoCZp = 773602018; IeuIMQJoCZp > 0; IeuIMQJoCZp--) {
        kRBztTtNjKdeO /= BRLBs;
        qgSCeCig = ! FdxeOlMRp;
    }

    return oarmokBkyCGDn;
}

int KbbIv::JejaxjwpqQQlMb(int zvZrufPNNYHmCxn, int gvKPkP)
{
    bool TNgWRamo = false;
    int xmRatefoPF = 1668519657;
    bool wSzOuogyEmQdsxjI = false;
    string HPqTM = string("DjtRLkZXPDVevgceDdJOWdJCWRvAhAfauvgfbKgbgrtWctTGZZJsWpGzcmZBooSQNyNyqDXwQOVxzsoEBAJzNpkKDeebDliSOEUGwocgjpnJTJtNSWKHLuqiKkaAZvZarCXQqYhyCoNYoQzl");
    double EdvcNkzZlJXCGrqd = 169529.20846591104;
    int jBpPwP = 1412817904;
    string ixwKGmRv = string("YgAgetrtWjtURBiPLfCukzRJTTdepaoSNnZPdjaPAXftaOOWVfnwJKZasoHODsQETSNhcgtxoNGwabnLkiBwyCjJCNExzzdwKPwAnuRwZuRMBwPsuxzTjjSMPcoQgFEJzUausVeLdGnDogVZWXtGbOxATnEylEIPSf");
    int mUTMUUbE = 1661591832;
    int SePjueZBmx = 1069605396;

    for (int jfNdmqSq = 52487460; jfNdmqSq > 0; jfNdmqSq--) {
        continue;
    }

    for (int uKGMAkeFoHmE = 1161945182; uKGMAkeFoHmE > 0; uKGMAkeFoHmE--) {
        mUTMUUbE /= jBpPwP;
        jBpPwP -= xmRatefoPF;
        jBpPwP = jBpPwP;
    }

    for (int qOxFr = 1613172003; qOxFr > 0; qOxFr--) {
        SePjueZBmx = SePjueZBmx;
        xmRatefoPF -= mUTMUUbE;
    }

    for (int HiiFw = 1524331859; HiiFw > 0; HiiFw--) {
        SePjueZBmx += mUTMUUbE;
        wSzOuogyEmQdsxjI = ! wSzOuogyEmQdsxjI;
        HPqTM = HPqTM;
        mUTMUUbE -= mUTMUUbE;
    }

    return SePjueZBmx;
}

bool KbbIv::BFyQSMbjJqgn(double EYVHkZwI)
{
    double mVennZgx = -545577.5365143197;
    double SKiQUwrBDs = 465008.5931648035;
    int SyjuJZMcbQx = 700591539;
    double lyokFdllWWeeNTVv = 433605.7287311992;
    int YmvviFA = -994228293;

    if (mVennZgx <= -545577.5365143197) {
        for (int ljZjxQgxn = 1876219420; ljZjxQgxn > 0; ljZjxQgxn--) {
            EYVHkZwI = mVennZgx;
        }
    }

    for (int BFmLdckjp = 1696780685; BFmLdckjp > 0; BFmLdckjp--) {
        continue;
    }

    return false;
}

KbbIv::KbbIv()
{
    this->mdgSUYjcLdkkuPKf(true, string("iNBaekBwOl"), 1197030372, 1782161831);
    this->DVFXekwRUVf(-425705.22221442725, string("uXlhPgAGqDPIvHFyUZfFPmGFGaFdkJreeWMhbolOtzjvduufpiMSofoHoNzKpEowvCezjTQZVbypCcJPtoEhIHlxvfbDKmvbqKPKbghHutWiFcUUPwbvJDobQCGGuVEyrDxvOZkxUpcgytjGrpy"), string("PYtWrLKHBsFLfoYnCGBTnvWiZoSdKWdMLKOwPfIeRBFffMOJLlffauOEijjzZQylGNOBLHNdZhPOmGgDTgPcIssDnSTDUXDeoukGgrHPSSQyCmCSfjKxZFLNwCRiwCaZCYXnYOGIpJfpzKOiMFMRnWMMAIAVcPqVNGzbYowgObKhEVEbXFhPHsxTofBfoIBimySuwPgRMAZSjdyfQqeknOqwWVBCJCsWodaTdVBXchetaghghmxJBkhi"), true);
    this->LMtbgywOiQVZHlk(-66383.7472401039);
    this->WpAWQfbpL(-292926.29294295324, true);
    this->YQmMjxrR();
    this->ikIhkyNLW(string("wIknRZkoWrZytDNEW"), string("nesZvyinELqYJOUtdbcmVDAmeZCVpHxiHIqLtElsTcWySjHoFvvKTILCagEOBpzvOnUbfkzyYMXehK"), true, string("vgnKctM"));
    this->qNnoZBgnoeTuXcoS(1018310.4038059129, 1860547772, false, false, true);
    this->JejaxjwpqQQlMb(-1498932204, 440110700);
    this->BFyQSMbjJqgn(-599782.6034787094);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QCzrXDCLeMvz
{
public:
    double HjKfPYRSr;
    string wEoFcNUvxODqSS;
    int JHXota;
    bool mDJFQw;
    bool WtshUa;

    QCzrXDCLeMvz();
    int tievWukEkMEoobl(int WKMmIRAi, double YLlrqgibmzmTQ, bool lJFYLzzXMDI, int UFslNXqXnbxMQvry);
    int AMTjCGSDyukouPAQ(bool oEGPBdOvfLqh, int QJHExwInISqP, bool RNxWFCtP, string SLmib);
    void myAlM(string FEhNyhb, bool wVUWTSRTFOzzuEK, string ZAgdCMpacj, double BvwWsgwWTOxjNuD);
    string hFXSvyPoHwQz(string OwAKkOWCznwm, double uRRwHOzKzdSbWiZU, int IpDiyciJkXeTXn, int fKTaskTYMvxjwNa, double WepIerHrnDCrlgZ);
    int HOtEBODqLHlrou();
    int bkctytpdwPtVhi(bool OPCXPZZfK);
    string NdIgoUwTwdUzjkU(double PnuYzSfStjLtCoF, bool kNfKKETSHwiS, int mQgVSQyG, int chRRGLHByFHHcnl, int JMGmGUzF);
protected:
    int dUdGMSqnbZ;
    double npiSUJbYnl;

private:
    int FWXbzl;
    bool KyALOREyps;
    int wNxLBXKZcywFCZct;

    double zCEpUWO(double lFhjW, string ESHmSqASIVjL, double NUjlMlKxGhyQ);
    double kIoPpocNgsjHTvw(string VODPGymuypt, double nASDCsYVsUejGTd, int gcNWPtswFLNbygmH, string ZTwQLTYtSULBeh);
    bool QKgYIfsdukoeBbGY();
    bool PMcVhJiEXHcs();
    void VTZirJ(double UBjliBiPHyRbtiJ, string CWEbFQYwgyd, int mCebdPYWjlGstj, string rQrFGSIQXxNe, int LGntYQ);
    int SflhwbwpCXkFNZ(double eifDx, double ONKJGpVgWhhugzp);
    string ihHuiBOqcpxsth(int WHruIOOfPvSBvkPW, int FnDGZoWOw, int mIhUXfJ, double OLjseKrdxQsrkSvF);
};

int QCzrXDCLeMvz::tievWukEkMEoobl(int WKMmIRAi, double YLlrqgibmzmTQ, bool lJFYLzzXMDI, int UFslNXqXnbxMQvry)
{
    int UmZJj = 1572773404;
    bool rElPGLN = true;
    string zkrBDMoAvmpFMsw = string("XcJicnsoOKlKUHskRujIEsMhTmTROdpqUfGVCqUYoSChYNDdWrgbMiFkbDjmuoDnGrQasEhVjORfjJwGteRCpBBiixsnRtDxFRM");
    bool fKKCLfQwFrFN = false;

    return UmZJj;
}

int QCzrXDCLeMvz::AMTjCGSDyukouPAQ(bool oEGPBdOvfLqh, int QJHExwInISqP, bool RNxWFCtP, string SLmib)
{
    string ZaZWKrgVELUxGEAa = string("AkYGvuMgXkeKdfHVeQvfftMPkSfceWpxZaoBHFwtLZJTTOqmWGPupySljLDXizwzdXpcXYHwTCVRwMvmrIxZNwrSpCZqHuODycn");
    string jvgKXvAaOZZOcMc = string("uqxhUuafgYBbvAkpcLAmjYRUnJYiyDbyNWcXHKtfXxQgUiKUdQCkYxCDJQDnmjKdPZfhywfmOPprcQwshOthxxbhcqdXlAyiTeWYpSCJpEHKhgVMEYGTwmyuBNHNVTNMYvIcQObCqGvlqtchHlXuoIAEPJdPnVDAZHaLhQex");
    int MAlvoOPymGAw = -850134193;

    for (int BUSrgIV = 1824256194; BUSrgIV > 0; BUSrgIV--) {
        continue;
    }

    return MAlvoOPymGAw;
}

void QCzrXDCLeMvz::myAlM(string FEhNyhb, bool wVUWTSRTFOzzuEK, string ZAgdCMpacj, double BvwWsgwWTOxjNuD)
{
    string ABLhw = string("fqrOrSgvpCAhqTAcPrqWRVNDayBMCvJgcCrJyNvgmENYpYPYxTBqijIpwpeVXQNSGRcUVsjjtDAcTlmShdNTQYCerPvGcDcvzCXhBAlwmhwYEAjJgmnFpliIvAOonjvGCXoWNUJyAvtARDxCWkVHYxALTXRlezDnLMtRTqMpYIQswERCENeZWijEDLrFCeehofrfLUlNMYDxZLaLhrDVXhdbAcKofRSzHsCHr");
    bool TxuDqPV = true;
    string yKNopHAO = string("HHyFiGhQMazvZRaiprPdtdPQBNEOfXvRzMFhPLfDItaWkgmvsfkICcoFegmAYnGaYyZvoyBuWAFGXoAuWMvFJwPAzKTeRlGnicuXRrDPawajuyUksghOWUTLovWtmJNhqwLbJTyTgCHhKSigsYLZv");
    string caYSSjqu = string("xfMX");
    double HQZdZ = -412010.1276585002;
    double sSoRq = 605153.2378854242;
    int YqkDAbahg = 388366524;
    double yUPujRTpsIXJQIPg = -721499.5833854425;
    bool dkpnl = false;

    for (int OGliim = 155402139; OGliim > 0; OGliim--) {
        ABLhw += yKNopHAO;
        ZAgdCMpacj = FEhNyhb;
    }

    if (sSoRq == -2824.058311984412) {
        for (int rrzWOiJjvM = 1377694332; rrzWOiJjvM > 0; rrzWOiJjvM--) {
            BvwWsgwWTOxjNuD -= HQZdZ;
        }
    }
}

string QCzrXDCLeMvz::hFXSvyPoHwQz(string OwAKkOWCznwm, double uRRwHOzKzdSbWiZU, int IpDiyciJkXeTXn, int fKTaskTYMvxjwNa, double WepIerHrnDCrlgZ)
{
    bool GCSYVqFd = true;
    bool ZjtZuT = false;

    if (fKTaskTYMvxjwNa == -28483738) {
        for (int ThjGUkaYACOMsHrO = 1418699105; ThjGUkaYACOMsHrO > 0; ThjGUkaYACOMsHrO--) {
            WepIerHrnDCrlgZ *= WepIerHrnDCrlgZ;
            ZjtZuT = ZjtZuT;
            WepIerHrnDCrlgZ += WepIerHrnDCrlgZ;
        }
    }

    for (int SaawQDQFpkw = 2037222571; SaawQDQFpkw > 0; SaawQDQFpkw--) {
        IpDiyciJkXeTXn *= fKTaskTYMvxjwNa;
        GCSYVqFd = ! GCSYVqFd;
    }

    for (int NBifqCPpSbVwn = 1630711889; NBifqCPpSbVwn > 0; NBifqCPpSbVwn--) {
        GCSYVqFd = ZjtZuT;
        ZjtZuT = ! GCSYVqFd;
    }

    for (int axuGGGmgN = 174489974; axuGGGmgN > 0; axuGGGmgN--) {
        WepIerHrnDCrlgZ += uRRwHOzKzdSbWiZU;
        OwAKkOWCznwm += OwAKkOWCznwm;
    }

    for (int RpobkMEm = 1662472905; RpobkMEm > 0; RpobkMEm--) {
        WepIerHrnDCrlgZ = WepIerHrnDCrlgZ;
    }

    return OwAKkOWCznwm;
}

int QCzrXDCLeMvz::HOtEBODqLHlrou()
{
    int bgDbTWgxntZI = 276009676;
    double rGrqmpaPhT = -380109.19045875006;
    int qfSwFJMKNUpOZst = 845915129;
    double EPSlcWIo = -140984.94035822572;
    string WtvQRIO = string("VMEmSjXNYWAEwFQhAfxOYwAVvMiPFIqAZTMuZVQifuRHGVDIEkSxWyDuNUQmcjLGcjseCKypwBQmiXHYipczlAshqtYjzuoxLTsUiOJksgSEgGoSxMHW");
    int CUprobKMoABAB = -865364277;
    double AFeetqYpDFJ = 939276.5931252725;
    int QCiQadgbiQWOmLx = -647626871;
    string yDYffbRqCdCoxr = string("MYuCaBJJRNjcyJNQTkILFGYwYYDIFLTrkjKeEVGATfLzJqWfoEvNplLHzpKmhFOLjFeLEjhKPdjATeKenRauJuPbiehKPJxf");

    return QCiQadgbiQWOmLx;
}

int QCzrXDCLeMvz::bkctytpdwPtVhi(bool OPCXPZZfK)
{
    bool xRkvGRDSx = false;
    int UuMan = -1637394950;
    string YZxHeWKPxrUJUpO = string("NpHQSxUbQoSLujUcCgJUebqdjWHEruDvlXdBLNLTzgedhrrjTAgjdoQtqzafvAnyoMyUjYYOIdLORKHUQFfPWJmEpTFsfjnbHHduRovMXAFbPmvuWyLuRIyNilIHnaZWdvCradkYbkseKijvrQBSCBgtPMbTVaztGBbASpJYrIVQbsYwZWgucVjQhHButcGHsawMuiwiVZxNqOyjbjRWjHZnNvLqgBJStGrPpmgRgWOfgOMxtcoMA");
    double erKPW = -254750.5640573158;
    bool hvqDmlMoXQ = true;
    bool lcFdXPHtGZD = true;
    bool nVqTij = false;
    string VLeRCPeoMtY = string("pDcqQWVzVdHRgLVHjTyENuWEmdDLPzExXlBFQDRgiKKQvtdSMtBhlYqqGFAgzPICiqjTQNrEYJZZIsItzUzlAcLxytZOESRhYnwAsJOPPMoqkFsOKuKVJnhnMhTETotZZMDEBuNAzDugkgX");
    int HyrrABVaywpNgWN = -1441333387;

    if (lcFdXPHtGZD == true) {
        for (int BFRkUnnuueTb = 1034880581; BFRkUnnuueTb > 0; BFRkUnnuueTb--) {
            YZxHeWKPxrUJUpO += YZxHeWKPxrUJUpO;
        }
    }

    if (lcFdXPHtGZD == true) {
        for (int HjgAIGeLUnb = 1916157841; HjgAIGeLUnb > 0; HjgAIGeLUnb--) {
            VLeRCPeoMtY += VLeRCPeoMtY;
            VLeRCPeoMtY += VLeRCPeoMtY;
        }
    }

    if (erKPW <= -254750.5640573158) {
        for (int REGzaAA = 2113243495; REGzaAA > 0; REGzaAA--) {
            OPCXPZZfK = lcFdXPHtGZD;
            xRkvGRDSx = ! hvqDmlMoXQ;
            VLeRCPeoMtY += YZxHeWKPxrUJUpO;
        }
    }

    return HyrrABVaywpNgWN;
}

string QCzrXDCLeMvz::NdIgoUwTwdUzjkU(double PnuYzSfStjLtCoF, bool kNfKKETSHwiS, int mQgVSQyG, int chRRGLHByFHHcnl, int JMGmGUzF)
{
    int HaeDHzBTUFGxcX = -1526786558;
    double vxqUFNBtnpEMjLj = 913881.6421161261;
    int YOnONpiirgnPTkRK = -108226445;
    bool AGRHDa = true;

    if (AGRHDa == true) {
        for (int DtqaEZoFhbBb = 480122310; DtqaEZoFhbBb > 0; DtqaEZoFhbBb--) {
            mQgVSQyG -= chRRGLHByFHHcnl;
            YOnONpiirgnPTkRK *= HaeDHzBTUFGxcX;
        }
    }

    if (JMGmGUzF >= -108226445) {
        for (int ynWDuLptbjsTtQOi = 1616303743; ynWDuLptbjsTtQOi > 0; ynWDuLptbjsTtQOi--) {
            YOnONpiirgnPTkRK += YOnONpiirgnPTkRK;
        }
    }

    for (int ipRuKJROPE = 537157014; ipRuKJROPE > 0; ipRuKJROPE--) {
        HaeDHzBTUFGxcX /= JMGmGUzF;
        kNfKKETSHwiS = AGRHDa;
    }

    return string("dZDoHfehIxJzwEYpMVSAXyHgQxjDeDgeuSpqrmUFBBdVpdZFurigeZKEpOzCXXpTsbMUakaJJD");
}

double QCzrXDCLeMvz::zCEpUWO(double lFhjW, string ESHmSqASIVjL, double NUjlMlKxGhyQ)
{
    int cuUhKFXMqvTCJmjT = -1772457645;
    bool DQRgYBTzOM = false;
    string JHQMgXwpR = string("jDkDWVjPxXPTfzOT");

    return NUjlMlKxGhyQ;
}

double QCzrXDCLeMvz::kIoPpocNgsjHTvw(string VODPGymuypt, double nASDCsYVsUejGTd, int gcNWPtswFLNbygmH, string ZTwQLTYtSULBeh)
{
    int AqrpORLBTvLdwUGK = 1976807914;
    string wOysAc = string("DohGxkVxb");

    if (ZTwQLTYtSULBeh == string("DohGxkVxb")) {
        for (int vqRvsZFg = 80073381; vqRvsZFg > 0; vqRvsZFg--) {
            wOysAc += wOysAc;
        }
    }

    for (int IHBFblxlMrj = 1261811753; IHBFblxlMrj > 0; IHBFblxlMrj--) {
        VODPGymuypt = VODPGymuypt;
        gcNWPtswFLNbygmH += AqrpORLBTvLdwUGK;
        wOysAc = ZTwQLTYtSULBeh;
        ZTwQLTYtSULBeh += VODPGymuypt;
    }

    return nASDCsYVsUejGTd;
}

bool QCzrXDCLeMvz::QKgYIfsdukoeBbGY()
{
    string UOpKQB = string("QwwiWvirtNUqTIiOvTwzsYPumaAWSbniXsDGXTim");
    double UfvcFpQZ = 563147.9294850044;
    bool RAWbsyScK = true;
    double UjwkmohNJOlRR = 19074.016053824016;
    bool FjyIycRheaMhdy = false;
    double PbKzBZrpfiNm = 972267.6104904137;
    double YEBlMUpRE = 477318.82638500293;
    int LskreGKT = -1567154511;
    int gcIbrVg = -2010682064;

    for (int NioverKRn = 1550050649; NioverKRn > 0; NioverKRn--) {
        PbKzBZrpfiNm += PbKzBZrpfiNm;
        YEBlMUpRE /= UjwkmohNJOlRR;
        UOpKQB += UOpKQB;
        YEBlMUpRE /= PbKzBZrpfiNm;
    }

    for (int LzChuHPIQmc = 54861841; LzChuHPIQmc > 0; LzChuHPIQmc--) {
        gcIbrVg -= LskreGKT;
        gcIbrVg -= LskreGKT;
    }

    if (YEBlMUpRE < 19074.016053824016) {
        for (int WgBepqtxOI = 1478836124; WgBepqtxOI > 0; WgBepqtxOI--) {
            UjwkmohNJOlRR *= PbKzBZrpfiNm;
            gcIbrVg -= LskreGKT;
            YEBlMUpRE *= UfvcFpQZ;
        }
    }

    if (gcIbrVg < -2010682064) {
        for (int OGhkar = 511855; OGhkar > 0; OGhkar--) {
            UfvcFpQZ -= UfvcFpQZ;
            UfvcFpQZ /= PbKzBZrpfiNm;
        }
    }

    for (int CvPTHOFyHErb = 2141123975; CvPTHOFyHErb > 0; CvPTHOFyHErb--) {
        UfvcFpQZ = UfvcFpQZ;
        UfvcFpQZ += UjwkmohNJOlRR;
    }

    return FjyIycRheaMhdy;
}

bool QCzrXDCLeMvz::PMcVhJiEXHcs()
{
    bool DdXBiHXYOoBzjdM = false;
    double sgPINIAOn = -684352.6527099635;
    int dUqkvRVHAzu = -1210828212;
    int RGarNTDF = 1430705462;

    if (DdXBiHXYOoBzjdM != false) {
        for (int MceRLsrmeuJm = 1767142617; MceRLsrmeuJm > 0; MceRLsrmeuJm--) {
            DdXBiHXYOoBzjdM = DdXBiHXYOoBzjdM;
            DdXBiHXYOoBzjdM = DdXBiHXYOoBzjdM;
        }
    }

    if (RGarNTDF == 1430705462) {
        for (int bCuwWT = 1328283377; bCuwWT > 0; bCuwWT--) {
            dUqkvRVHAzu /= dUqkvRVHAzu;
            dUqkvRVHAzu *= RGarNTDF;
        }
    }

    for (int nqElLNZl = 751592846; nqElLNZl > 0; nqElLNZl--) {
        dUqkvRVHAzu += dUqkvRVHAzu;
        dUqkvRVHAzu = RGarNTDF;
        sgPINIAOn *= sgPINIAOn;
        dUqkvRVHAzu *= dUqkvRVHAzu;
    }

    return DdXBiHXYOoBzjdM;
}

void QCzrXDCLeMvz::VTZirJ(double UBjliBiPHyRbtiJ, string CWEbFQYwgyd, int mCebdPYWjlGstj, string rQrFGSIQXxNe, int LGntYQ)
{
    int yEJTV = -1016220580;
    string JlkwJmQBO = string("gbFxWkuofcgAKUTKNBcHYnyVDVRgDXCqlSkiDFTvlVxAXxRduIAjuDAxYmwNrEVpVfUDDladEjlfTpvWpsCZMfDemZwdthvEO");
    bool zZARRdBvl = false;
    int YqYGfODrFShd = -1621217002;
    int bhZjFna = 1642748921;
    string UPEYCsojv = string("mFOjAfIzJgCrJmqNdptaLyLuiQlpwkPnTLbQkRvwRCtrWCMyszgzlsimlQzGfuZHnbMYJisksEWPSOBncnpZLqhNhFSkPwmVajCSlokRraVccOYIfXcoTvLzICuStZtgoMHfzXwsoeSNTmUFwpQGkUsTjoASWHOrkvMvwiyykZqKXYqgnpkkJDjqcgEPmMdcFIFyvQiwzrDjEWDbmYVNUCZovHWCTxwDmWwTuBCdsOzIOxGMNsHmxyTNmxYeZB");
    string qGPrRknnsIVCgDtk = string("oaSxFjTwERVFybkjikgeMQwFdfWwWDNSpnxEXlbsjDRAMrECHKOmrvHDTCqfBGeUogbcs");
    int zXUUQzSvSKBigWU = 149852703;
    double TRLYgsqHaaty = -444595.72085095535;
    string QcqpVSScptZkAjZZ = string("ZaRRkWHNfyTHHKEumpQXMbJUxMAnBvtqegFtTAiEFomHjaeMDDtzixnsQLuTCUvcUSsRLGpfmnWdhHCpeUMMpWUFJCNCDBV");
}

int QCzrXDCLeMvz::SflhwbwpCXkFNZ(double eifDx, double ONKJGpVgWhhugzp)
{
    bool MPQgscbgHpdbgDIH = false;
    string vGRzOGBXigIP = string("bcPjAzWbUYzjRbjNNmZteqPlEaqDVlworXROtSjtfDVbAEoYLUuOHoXJXSNZbFFKprnSJhwhGlgEojosLCXJCdRCYtkiWVxOyDWfWqTohFvlizqDpJvReeXlnIgfinZOccCrXSrLFDvjPMgcEQBaHjLyoOunZhAkRSMOmILyDaweSgJYwRPUhTWnotKDxkY");
    bool CZSEXrQQoCiIUI = true;
    int PWywiwvPEbNeacwf = -1466270165;
    double CMEyIQ = -418970.6042423431;
    double ttpjWCfTdtO = 262741.28274927725;
    bool jlVLHhHqbmP = true;
    bool kGDGwWEMt = true;
    int rjrbtndvByBG = 1521212498;

    return rjrbtndvByBG;
}

string QCzrXDCLeMvz::ihHuiBOqcpxsth(int WHruIOOfPvSBvkPW, int FnDGZoWOw, int mIhUXfJ, double OLjseKrdxQsrkSvF)
{
    string zCQRbMrVWt = string("yZSVexJGbOEJFEZyLySRIOqjwQwZNMpvwznKDbbWofXFXggkJquPlXEOWxkefOeutgvqwqslFXYrQCjEzaZFjnLAJRkQARnJijSpjvtKGhbcyaXtIAdRrHijloahWTaeFTCPdBTacKiufXOhOjyMBxAheEETTQvuygoIwtifwPWvzTpVMSOEeMFBGkhNUYlljuiwlrHCIVqxGxWFwhyGMpCZtvWhiGclaBlpWPdZSZoNreC");

    if (zCQRbMrVWt == string("yZSVexJGbOEJFEZyLySRIOqjwQwZNMpvwznKDbbWofXFXggkJquPlXEOWxkefOeutgvqwqslFXYrQCjEzaZFjnLAJRkQARnJijSpjvtKGhbcyaXtIAdRrHijloahWTaeFTCPdBTacKiufXOhOjyMBxAheEETTQvuygoIwtifwPWvzTpVMSOEeMFBGkhNUYlljuiwlrHCIVqxGxWFwhyGMpCZtvWhiGclaBlpWPdZSZoNreC")) {
        for (int LxRiRlfZ = 1511566850; LxRiRlfZ > 0; LxRiRlfZ--) {
            FnDGZoWOw -= FnDGZoWOw;
            zCQRbMrVWt += zCQRbMrVWt;
            WHruIOOfPvSBvkPW = mIhUXfJ;
            mIhUXfJ /= WHruIOOfPvSBvkPW;
            OLjseKrdxQsrkSvF *= OLjseKrdxQsrkSvF;
        }
    }

    for (int EWLsODW = 1496864947; EWLsODW > 0; EWLsODW--) {
        zCQRbMrVWt += zCQRbMrVWt;
        FnDGZoWOw /= WHruIOOfPvSBvkPW;
        WHruIOOfPvSBvkPW /= WHruIOOfPvSBvkPW;
        WHruIOOfPvSBvkPW *= mIhUXfJ;
    }

    if (WHruIOOfPvSBvkPW <= -1442506964) {
        for (int MhcDFTCfaRDsX = 419717436; MhcDFTCfaRDsX > 0; MhcDFTCfaRDsX--) {
            WHruIOOfPvSBvkPW *= WHruIOOfPvSBvkPW;
            mIhUXfJ *= WHruIOOfPvSBvkPW;
            OLjseKrdxQsrkSvF -= OLjseKrdxQsrkSvF;
            WHruIOOfPvSBvkPW *= FnDGZoWOw;
        }
    }

    for (int kuJbhHEOZpX = 1380544183; kuJbhHEOZpX > 0; kuJbhHEOZpX--) {
        WHruIOOfPvSBvkPW += mIhUXfJ;
        mIhUXfJ += WHruIOOfPvSBvkPW;
        mIhUXfJ = mIhUXfJ;
        mIhUXfJ -= WHruIOOfPvSBvkPW;
        FnDGZoWOw /= WHruIOOfPvSBvkPW;
        WHruIOOfPvSBvkPW = FnDGZoWOw;
        OLjseKrdxQsrkSvF += OLjseKrdxQsrkSvF;
    }

    for (int QTFPREwbO = 359315534; QTFPREwbO > 0; QTFPREwbO--) {
        WHruIOOfPvSBvkPW = FnDGZoWOw;
        FnDGZoWOw /= WHruIOOfPvSBvkPW;
        mIhUXfJ *= FnDGZoWOw;
        WHruIOOfPvSBvkPW *= mIhUXfJ;
    }

    for (int rJuFOQcFr = 2019534095; rJuFOQcFr > 0; rJuFOQcFr--) {
        mIhUXfJ = FnDGZoWOw;
    }

    if (WHruIOOfPvSBvkPW < -1442506964) {
        for (int cmzcpS = 1047091139; cmzcpS > 0; cmzcpS--) {
            mIhUXfJ += WHruIOOfPvSBvkPW;
            FnDGZoWOw -= FnDGZoWOw;
            zCQRbMrVWt += zCQRbMrVWt;
            WHruIOOfPvSBvkPW = WHruIOOfPvSBvkPW;
        }
    }

    return zCQRbMrVWt;
}

QCzrXDCLeMvz::QCzrXDCLeMvz()
{
    this->tievWukEkMEoobl(1185911320, 400278.75541382394, true, 28606388);
    this->AMTjCGSDyukouPAQ(true, -1338118853, true, string("DuZCeagrSuaMoIBpSOrSPSHiBkowjEULOHVUYCNCXHpPisoBrc"));
    this->myAlM(string("ZcvGDEzebdQcfThrVvytjYKvvcqxLBuhrqzDSNHytjXAFSmHOOtmSnlobNCTEJx"), false, string("lllILdzdPYWVudWdATLCqQorjeInuEOwHlUjbQVpCqzxDHtNoumGJqTZwGsmFtnDJaBjlIFBpyqaDeaZHWJWeVnWkIAGqurtkioUEVuHtQYfWcGVwZezjuwzbovIiYWpoYoU"), -2824.058311984412);
    this->hFXSvyPoHwQz(string("yvukTiIsMSNeBevzuyHcJHYeCtJisYCdTtAgYzqDhuszyMr"), 351070.1379399245, -28483738, -1067818201, 18574.746805680075);
    this->HOtEBODqLHlrou();
    this->bkctytpdwPtVhi(true);
    this->NdIgoUwTwdUzjkU(398736.6674596622, true, 2001879753, 801069881, -1136863642);
    this->zCEpUWO(-49971.941104929334, string("sjJDzcFlSNcavXGFCACQdOVLtpdNWFiCvcUlNwfeNgjJScVvzLunxytbzEbUZjRWUnPNwYgHUZYsyxMAkcwpMeuPVlLEsKNfIQbFJiqszv"), -54041.060605061444);
    this->kIoPpocNgsjHTvw(string("ELSRNtDCfdpkmDyjIjLvZENdo"), 308520.80934006063, -190757364, string("vtbthWWHHCEQuvfmbUimprfXdsqFcBbJVOfOwbEgyCFLLSAmRbWrFUpNPRnmPlnwzysqNKOVgpZZmdJnKjpzhzJLCaYPQaXDaoAAJMMCbZnILKJjXHYukhlodYbPnapyLiLPuTAEtLMQhohfrvwnSoZcQxknMfBHYVateMwNqlhMUPneYrRxkgBQmPkzktjKenocpRchNJeStediEBQpRAkQJkeLeYknugOsqViXBnGclLqDmj"));
    this->QKgYIfsdukoeBbGY();
    this->PMcVhJiEXHcs();
    this->VTZirJ(-157889.64012699545, string("FIJeZZZQAfZyvZbFvhkBHUkUsWASGVlzhINDzZnBHOMxCwooThKkndONNcRcLJLJGSGonpqoydYbHudgdBCpBaPCZPopPeJdEjlzVrNUuVcYXiGYmvBCwQGhEChpDSMHpgUiZjvRp"), 1439486695, string("rQqUJfKCzxfKKjQbqkofDAVQNIRiYlNUTgHNodqCUtCaYYzmhnVFfuSbPftdBOdUaBTEwNHvjYNapAESqOZAxPiuclaQKJELaYzsbydENREDDaOOoZSOgwgPquWauZWDFWLfLVanxVIcs"), -12094474);
    this->SflhwbwpCXkFNZ(-1032565.2829962012, 44384.01753800925);
    this->ihHuiBOqcpxsth(870984705, 1699186885, -1442506964, -1041854.7528567546);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UeFOpj
{
public:
    int SkxQQgadZDhchfm;

    UeFOpj();
    string tAXIUm(int xLZGqeTl, bool DvYzfNDmkOq, bool swMcFAGoUogwDbNB, int jIntcIWgRmO);
protected:
    bool ydptRMPgCGguLoB;
    int BpiKgtbfYPTQUt;

    void SnVfxubCST(string DLmUObGbQf, int dBFPCVvPakbGc, string PtCME, bool xvamgSwrmqQCE);
    void iWcPtnKkGNHH();
    double XmeSWOF(int RzxWuuJsH, int FGThapmT);
    void cqYdgme(int dbMSwtoceCkiZk, int rdxkqBY, double kppdzuCbr, int FFZXwlAfZlRHvn, bool TtaYWzUhzhTNFR);
    void DKeoo(double VATJbjKlY, double HPybyCiUBa, int lIfgMMiFL, bool fgtwIjaIEdeIA, double fPFYenpvqBbBvEh);
    int yzaoZxFWoRgcf();
    string PfwisWyXViIteWAp(int lMKeOWeO, double ScHklaMQFxjcq, string aIMQqKpwRPB);
    void jEcdkLhYct(double UlanAxrhufGF, bool pLGpYjpqnPyRhH, int oAwRdcKaC, int LDUdxYHQDBzOBvyu);
private:
    double irwEvA;
    string tVmFFstHNLS;

    void issWsBDKwBCgkR(bool bdxPxnItLeDBUKbu, bool bIdNdTdlETi, double ODBXtVePrcn, string hiJdmiopNSSiJ);
    string WPOvqKtC(bool hfXmxAcOqMlAFRPm, int TiABfR, bool CrZYmjYl);
    double QjlkeYleob(string BQkNYj);
};

string UeFOpj::tAXIUm(int xLZGqeTl, bool DvYzfNDmkOq, bool swMcFAGoUogwDbNB, int jIntcIWgRmO)
{
    double KSouLjGbaXxk = -275359.25219514465;
    double qqCOvRzPLy = -187130.34627949883;
    double smwhUjTTKkD = -244254.44928135385;

    if (KSouLjGbaXxk > -187130.34627949883) {
        for (int atQUXhtqD = 819367249; atQUXhtqD > 0; atQUXhtqD--) {
            smwhUjTTKkD /= smwhUjTTKkD;
            smwhUjTTKkD *= smwhUjTTKkD;
            DvYzfNDmkOq = swMcFAGoUogwDbNB;
        }
    }

    return string("FkSLcRUyXQQPxlCIVJdnIBLIjUdRuuUoesRbLCyQGsbpgyfwpWKQVoXDosCNnfUHyckNqcXViGfQoehdQzIpONHRJZXumnbjOtLaKGJllDUgaaOAkbJpxfnTZPXehkwsWHPTzpgkVkjtTgAWRMIKQDbNiVNRwaNtfTWXQpSQZBTJBGjJmTAImOhXIpKcKMnxEQgHQoTuTXNZCnaZeFAmuH");
}

void UeFOpj::SnVfxubCST(string DLmUObGbQf, int dBFPCVvPakbGc, string PtCME, bool xvamgSwrmqQCE)
{
    bool jLvOfKKPmVAErH = true;
    bool bpFNSDzFUFAo = true;
    double IIRDxFILnMqnFDY = -234199.26937152297;

    if (jLvOfKKPmVAErH == true) {
        for (int xMrBnApKfJvTQoI = 340616531; xMrBnApKfJvTQoI > 0; xMrBnApKfJvTQoI--) {
            continue;
        }
    }
}

void UeFOpj::iWcPtnKkGNHH()
{
    double YuTUvMd = -127353.55634615467;
    string SenQZwQ = string("PdySsLgrjIHfVkYjvzYCmLBDTcWKGHMoWknRdefYfrRNFrTLSKeBZfmWi");
    double ycspgKFwDMqYq = -710238.2082954559;
    double vUFVvhnWA = 757599.9785989929;
    int RvIqEOCE = 1597265868;
    double PGugd = -935814.9266618638;
    int NDlRYOw = 529021689;
    int fGpif = -1970181461;

    for (int DDrZnsZnQd = 142259250; DDrZnsZnQd > 0; DDrZnsZnQd--) {
        RvIqEOCE += NDlRYOw;
        fGpif = NDlRYOw;
        SenQZwQ += SenQZwQ;
    }

    for (int xgeHdeFvXFmKmK = 853843054; xgeHdeFvXFmKmK > 0; xgeHdeFvXFmKmK--) {
        RvIqEOCE -= fGpif;
        PGugd *= vUFVvhnWA;
    }
}

double UeFOpj::XmeSWOF(int RzxWuuJsH, int FGThapmT)
{
    bool oqhgkDf = true;
    double FuSeUwHI = -87439.02593932906;
    string Incyvf = string("avpRsPtNtTxCTuUjuhJajJvbWXjZpEoirWOifEVVEQUHDKwdQbWftXPkVuIUUwsEoaKzTPQsxoewDQlJLXmtevDElRKGNlwKQfMpIFHkUCDbhcIZvNvrHpmAPWhyzRpbhKOwFFVQYYjWRoKELwKRDarKAGcbNTGRnSzvyXVzLmrbNEzptq");
    double pKBJVlTvCZcMKM = 638474.3992611143;
    bool qgjTrvq = true;

    if (oqhgkDf == true) {
        for (int jJMEKeqzvkAhEDD = 1627883020; jJMEKeqzvkAhEDD > 0; jJMEKeqzvkAhEDD--) {
            pKBJVlTvCZcMKM = pKBJVlTvCZcMKM;
        }
    }

    for (int VdAzjfBcoqDGxM = 1231731204; VdAzjfBcoqDGxM > 0; VdAzjfBcoqDGxM--) {
        FuSeUwHI = pKBJVlTvCZcMKM;
        Incyvf = Incyvf;
    }

    if (RzxWuuJsH <= 1048066427) {
        for (int VRcJibNNMO = 602208657; VRcJibNNMO > 0; VRcJibNNMO--) {
            pKBJVlTvCZcMKM += FuSeUwHI;
        }
    }

    for (int HbPBHjrIDx = 903891731; HbPBHjrIDx > 0; HbPBHjrIDx--) {
        continue;
    }

    for (int STkmqmEc = 1127738212; STkmqmEc > 0; STkmqmEc--) {
        qgjTrvq = qgjTrvq;
        RzxWuuJsH += FGThapmT;
        pKBJVlTvCZcMKM += FuSeUwHI;
    }

    return pKBJVlTvCZcMKM;
}

void UeFOpj::cqYdgme(int dbMSwtoceCkiZk, int rdxkqBY, double kppdzuCbr, int FFZXwlAfZlRHvn, bool TtaYWzUhzhTNFR)
{
    bool flylvzQkRbJCSyM = false;
    int WzgvOet = 424955454;
    string cWMbZUgdD = string("tyGaaeEXTQnhmHGeWycnyhVWpwSuvxLNpopOMfOrEAhFeNiewIkzGjFyDOGCSDZeqUHZINIpOFtHPNQzrrGLQPReobTtHRybSvrPbigCUyVNUWMfKfEGcZLBPMYdcsIOyIwrMwWsfcnvftAUPRedlsCqurG");
    bool NmEXU = true;
    string XRyzhDCjbI = string("GjRPWZxKMQVYbPGmPamaHaKodTzLumhuRjqCycnsCIbfGENQbAevPGsWJEzYeJlTcadylQcxWIduHWubvmSaoffNgJFWWuUHkmGHBeIEqmhACYXhCclEvXWhdjahvrjKEJSYLFDwNjvOpSXmWllofTyuUwwJRM");
    double KdbJQ = -1021089.6843104905;

    for (int rOmZiPtKh = 1071001943; rOmZiPtKh > 0; rOmZiPtKh--) {
        rdxkqBY *= rdxkqBY;
        kppdzuCbr *= kppdzuCbr;
    }

    for (int GggFnTMdpFWDxwWn = 558189094; GggFnTMdpFWDxwWn > 0; GggFnTMdpFWDxwWn--) {
        continue;
    }

    if (WzgvOet <= 845371448) {
        for (int DDxgVFilrJ = 1667809367; DDxgVFilrJ > 0; DDxgVFilrJ--) {
            TtaYWzUhzhTNFR = ! flylvzQkRbJCSyM;
            cWMbZUgdD += cWMbZUgdD;
            FFZXwlAfZlRHvn -= dbMSwtoceCkiZk;
        }
    }
}

void UeFOpj::DKeoo(double VATJbjKlY, double HPybyCiUBa, int lIfgMMiFL, bool fgtwIjaIEdeIA, double fPFYenpvqBbBvEh)
{
    string RjisdNXYqDKq = string("XgKkgQdRVdIoYtwUqoxAKzMDuxsGqCQkeXnMzSUaXMAlgNuRMOWkaVXhfPJtqqbEYAvKEtEywGxzHWwYRkDNhRPFwaGvnZGQijGxpGfHKrjaWSqWCRjYJkhQFTnQowpGAuayEzIvvORArbrixA");
    int HpOWRCvDGhKiqKyL = -1382907365;
    bool VIweLsWdWGCTK = false;
    bool BlsHh = true;
    string CUTpTZNjarm = string("SKBpyzIZwWOxmERbjQgTbWIcoWRuEKuHGSTRXEwjEkZmlcIXLFpHiFGjnraTqDTrcpQndyPmlUYCUhlDSLqHZRfXdzUkWxxKWcNrtyPAPXKMZLccQJwCLfsbMIefDhOsHAdYNvBMYTPsaRMBFbBvddZYKmepuN");
    string pblzXyjliKYkdGG = string("CncwaejYgdvBCDeyGpVvbRobZLx");
    int IXxuhSOwz = 445232812;

    for (int ahjgjFKHkRuIboH = 267318771; ahjgjFKHkRuIboH > 0; ahjgjFKHkRuIboH--) {
        VIweLsWdWGCTK = BlsHh;
    }

    for (int waUvNIzJIbUn = 740346118; waUvNIzJIbUn > 0; waUvNIzJIbUn--) {
        lIfgMMiFL += lIfgMMiFL;
    }
}

int UeFOpj::yzaoZxFWoRgcf()
{
    bool inYEw = false;
    int ullbWY = 1184345262;
    bool hCRHZmJGPl = false;
    bool VdEDJ = true;
    string QtXbnXn = string("uAnkuyXnGjnOUeGsRxYBvnaqAcAZpAeULJxq");
    int PLYMoVQHQZT = 405689931;
    double LdCzviSbAqEUAufS = -650830.6634228424;

    for (int OpjLKZuXJ = 12987984; OpjLKZuXJ > 0; OpjLKZuXJ--) {
        PLYMoVQHQZT *= PLYMoVQHQZT;
        ullbWY /= PLYMoVQHQZT;
    }

    if (LdCzviSbAqEUAufS == -650830.6634228424) {
        for (int xOJdmIwQjzhUDiE = 923706922; xOJdmIwQjzhUDiE > 0; xOJdmIwQjzhUDiE--) {
            LdCzviSbAqEUAufS *= LdCzviSbAqEUAufS;
        }
    }

    return PLYMoVQHQZT;
}

string UeFOpj::PfwisWyXViIteWAp(int lMKeOWeO, double ScHklaMQFxjcq, string aIMQqKpwRPB)
{
    bool NVeLaoAx = true;

    for (int XhCqlmBAYINtTzZ = 428566695; XhCqlmBAYINtTzZ > 0; XhCqlmBAYINtTzZ--) {
        continue;
    }

    for (int KVAuQYUfiNhsH = 38251850; KVAuQYUfiNhsH > 0; KVAuQYUfiNhsH--) {
        ScHklaMQFxjcq += ScHklaMQFxjcq;
        NVeLaoAx = NVeLaoAx;
    }

    for (int gWtYhUfLDz = 209237512; gWtYhUfLDz > 0; gWtYhUfLDz--) {
        continue;
    }

    for (int XrihNoApbdrlA = 1738486427; XrihNoApbdrlA > 0; XrihNoApbdrlA--) {
        lMKeOWeO /= lMKeOWeO;
        NVeLaoAx = ! NVeLaoAx;
        lMKeOWeO -= lMKeOWeO;
    }

    return aIMQqKpwRPB;
}

void UeFOpj::jEcdkLhYct(double UlanAxrhufGF, bool pLGpYjpqnPyRhH, int oAwRdcKaC, int LDUdxYHQDBzOBvyu)
{
    string vYanE = string("JqfnxXantFDxDfKCrOkDMiRiBDIvVBfZaGGnCuPNtdzOvcpuTHqmkqQROYpGGkPghDjToTQPLGRrIAxjLJDbNjErdNsSLtykqWkSakYkIlUzNHEizdSQTEBJLmVWEEHxGhoIPKeNxMddSPksszmeRUqGUSXPjpqCSCSWIdcSXbUFUcOLGYmghjpFzUfkuLVKhwexxdAyBkavzvOMOzmyStJAtfoDXyNVjQaMMQpk");
    string XuMfmqHrBiFiQjjQ = string("ijxAXyoTTVNEshHmbgOnrBrSGGkYDFyarAwBJpZPoxUqohkOqoTZYRIUAEXCPtvvzXhYePyqgAgxbLCraNnBkOtfEhjJzDQsakhVrWjBcXhFnYtzlKEfzXUJcBUdKsqcggLjdjngKWFqEZeygsmlUgYHTOnqamBwmizaTpatmluPnPycbHZCZKrPQMeDOJQbOFFERLORJkHcforVhSWcepntDTHhGpULZHdqtNHrheSsdfzcJzFXLMkoPVDYaZ");
    string CMqegQPee = string("JWryrBOEuleHUogMSvXcdxitxPbtsJAeVYNeUXxbGnkofByCXAFfMFvzWzgLTprPTdoAecPCTsdpHDaPXgLIlyvYZDzxhXHshgfKKIbLrLnZThKPMStPrarEkfgSBjSOvaUzjDuaMFXPQWjGcaeWKFIMFqJjkWuvprzSZfLJjSXfGs");
    int vFcFcxrkE = -160788615;
    string TlfcnjCjNndJ = string("YDkcNiwiYDbpUQmPVsFhskxExgCauNdlUQXCsKcsyASfdIrPFLCHehOzukCkcblRRpUBYAqfvzcThEIHpOnvYCKtaOOslPWZNDkWwaPakJugyVZVzUElyeltfCkHOwlqymuHTVfsCgBLoYfhGYdtBHiYHHtTbxlArj");
    int ofvkqK = 124963578;

    for (int ZxMXO = 373118404; ZxMXO > 0; ZxMXO--) {
        LDUdxYHQDBzOBvyu = oAwRdcKaC;
        CMqegQPee += CMqegQPee;
        pLGpYjpqnPyRhH = pLGpYjpqnPyRhH;
    }

    for (int ASaeIveLIeUQOb = 882844729; ASaeIveLIeUQOb > 0; ASaeIveLIeUQOb--) {
        oAwRdcKaC *= oAwRdcKaC;
        ofvkqK = oAwRdcKaC;
    }

    for (int EdgvOPwpaweRqFCO = 1619773428; EdgvOPwpaweRqFCO > 0; EdgvOPwpaweRqFCO--) {
        UlanAxrhufGF += UlanAxrhufGF;
    }

    if (LDUdxYHQDBzOBvyu >= 124963578) {
        for (int JjcAFdbXIxnAcF = 873594323; JjcAFdbXIxnAcF > 0; JjcAFdbXIxnAcF--) {
            vFcFcxrkE += vFcFcxrkE;
        }
    }

    for (int qrikLqNKcjQYCJOa = 606722670; qrikLqNKcjQYCJOa > 0; qrikLqNKcjQYCJOa--) {
        LDUdxYHQDBzOBvyu *= LDUdxYHQDBzOBvyu;
        ofvkqK /= ofvkqK;
    }
}

void UeFOpj::issWsBDKwBCgkR(bool bdxPxnItLeDBUKbu, bool bIdNdTdlETi, double ODBXtVePrcn, string hiJdmiopNSSiJ)
{
    int kQDlxvSUDJGaQ = 623621466;
    string nCXDLrNirDU = string("HxuBzlIBrQexEOExAzeiinkAmusbDXoFaMVGSLFrSgYqCMsWjSYvjASZXcnslHVOyTcLGCbAIiOHLtZZjYqwNytMbJJcTGWFjWnZteMrONxGwKDznuXfQLsQWDyDaCyyLEzUcHdwppmjZNqEEstl");
    string XjVzxIClXxUb = string("LBdwFCrpoBoQDibOoPrONWuvcajwHLcxVJZkBPuYNoLgZzkVGfFopVXwjuBABqwoUhxtyHEXpEOAouBnAJwtujRQczReJxXkLMoqqsfvggqWXwjfunCTZaUFSqHMeKU");

    for (int POrEWpy = 949339937; POrEWpy > 0; POrEWpy--) {
        ODBXtVePrcn = ODBXtVePrcn;
    }

    for (int YRdeEQVTWwJXgY = 392720871; YRdeEQVTWwJXgY > 0; YRdeEQVTWwJXgY--) {
        bIdNdTdlETi = ! bdxPxnItLeDBUKbu;
        bIdNdTdlETi = bdxPxnItLeDBUKbu;
        hiJdmiopNSSiJ += XjVzxIClXxUb;
    }

    if (XjVzxIClXxUb < string("HxuBzlIBrQexEOExAzeiinkAmusbDXoFaMVGSLFrSgYqCMsWjSYvjASZXcnslHVOyTcLGCbAIiOHLtZZjYqwNytMbJJcTGWFjWnZteMrONxGwKDznuXfQLsQWDyDaCyyLEzUcHdwppmjZNqEEstl")) {
        for (int dNgERbQOMb = 431057441; dNgERbQOMb > 0; dNgERbQOMb--) {
            nCXDLrNirDU += hiJdmiopNSSiJ;
        }
    }

    for (int QutjPAnkt = 1332888800; QutjPAnkt > 0; QutjPAnkt--) {
        hiJdmiopNSSiJ = hiJdmiopNSSiJ;
    }
}

string UeFOpj::WPOvqKtC(bool hfXmxAcOqMlAFRPm, int TiABfR, bool CrZYmjYl)
{
    double crpXHsPr = -489211.1100308082;
    int CMWVJzEV = 1451090823;
    double xzpGLJpUB = 385165.14767752733;
    int GNFSqRdQhW = 1462175475;

    for (int Qfnzrp = 582852450; Qfnzrp > 0; Qfnzrp--) {
        continue;
    }

    for (int OEgBaNhZRW = 1348761704; OEgBaNhZRW > 0; OEgBaNhZRW--) {
        TiABfR += CMWVJzEV;
        TiABfR /= TiABfR;
        GNFSqRdQhW /= GNFSqRdQhW;
        hfXmxAcOqMlAFRPm = ! hfXmxAcOqMlAFRPm;
    }

    for (int hNuqAq = 1336357767; hNuqAq > 0; hNuqAq--) {
        continue;
    }

    return string("awnPfKVcaPrTjVAzrvdGnRUxbLWcdawnjwMreyzsHFAYkIMjJQiCzUQCidxXlAenGSrMqekaeIHjHtNPuWkpKcLchunYsFXpyurKWnJFRhCJdUuFqEbNPThTIqouNVcbwDSUMSbMQkANOAcGhGNUGZMcQnfwXQWmohYHiHFXfBzWw");
}

double UeFOpj::QjlkeYleob(string BQkNYj)
{
    string RoJYS = string("LXvImpKImwNkUJehDukoCzYenLPPQsOQCPNLkMlSIIZOAAyklvCuuBxVTwayCJBEwzDHCSmrASpvlbjPQUlaVVtPHAHpJsKyhGIHNhsuOBwYaUeOBGruYDlBWKfVXZbRcLiUZesIUZq");
    bool ElXsg = true;
    int pjmUumhu = 2119500453;

    if (RoJYS < string("LXvImpKImwNkUJehDukoCzYenLPPQsOQCPNLkMlSIIZOAAyklvCuuBxVTwayCJBEwzDHCSmrASpvlbjPQUlaVVtPHAHpJsKyhGIHNhsuOBwYaUeOBGruYDlBWKfVXZbRcLiUZesIUZq")) {
        for (int RKsTR = 1806550945; RKsTR > 0; RKsTR--) {
            pjmUumhu = pjmUumhu;
            pjmUumhu += pjmUumhu;
            BQkNYj = RoJYS;
        }
    }

    return -302553.0764998596;
}

UeFOpj::UeFOpj()
{
    this->tAXIUm(-647499824, true, true, -1516790349);
    this->SnVfxubCST(string("KHynctjBNPqQNjZCwZXJGdn"), 695494884, string("ngWRAIjIxQQUZFZcOmogNyydLGgmgNZvcTJxdezvRLTorOXOSXGjrPgGzjnpmNARzmJnQjAQJCGhdXUervJyOPiUsoWtlaUscLEnUXPLAtcaKsIrsOOpbHRHlKLhDujCoynxDpiHqqpRarjFefaxcYJvIEhLGPdDekqArtCDJCdlJVflzAtyflbZlhZWZNDmAsYpTpJZqrYwrQVhdJhHkFRmG"), false);
    this->iWcPtnKkGNHH();
    this->XmeSWOF(-2115842420, 1048066427);
    this->cqYdgme(1274516532, -1052306904, -390772.2268536142, 845371448, true);
    this->DKeoo(-61804.23736460843, 281263.2290264344, -142326658, false, -234261.11333425317);
    this->yzaoZxFWoRgcf();
    this->PfwisWyXViIteWAp(1613952132, -746991.3484703107, string("AzDzZOoPVrXnAEyOeeBxuZtjhRIHiGlRxKIFlSATVVGBIlmefCZQXyvugPHjRmoXnHNjIJDwYUASKzZfG"));
    this->jEcdkLhYct(-56052.59829464531, true, 541559028, -608598514);
    this->issWsBDKwBCgkR(true, true, -310978.9566455177, string("waaDbWCDuKQHXjRMjMMZgcnunbyDXRxQvAoybbMQdYFqdtdXZMgTWmirddObpwGbXrCvkZlfSFFNrMdeKPtEWWqswdQCItKLiLAyDAodOALuYDyYKWWdOsSWwoXXzOCNZbgtqyx"));
    this->WPOvqKtC(true, -1545118297, false);
    this->QjlkeYleob(string("wjSoSkVstWkeiSPazTsuXvYpeAKUfQhWnthEIZynxRerFSKwmMrEcPpjzFMUYaUKBUCVZzRUgEjZhLOXNGsrHTSwmMmdmjgGDhTDCEtDlXbAmBtGCaSBDwhUsOYqAsyPWGPtJuLmzKERzDLTvBSGRJPAlIAsdLUhMsQOwSTRosoexQLYZgqnPcMBQrdYdiBVSkSRvEwsWRdIUEOtvFYtQupPLYtsfWnebAWeeFbmvFVSZMXKkBnkH"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BIBZoVlLTS
{
public:
    int rnLzYyQ;
    int WjFlRGp;
    double nRuAFofvjngThi;
    bool jaaSXGRFmh;

    BIBZoVlLTS();
    int tlEzJLOF(double kcskviyLfzHozouy, bool ZmEPnsZxSBJ);
    double auswfZi(string QJrSG);
    int pAhHvgu(string ijxGgdxO, double rMgBqAeeOkjrLKqC, bool WcGmgcMWL, bool DjPnWMYtED, double dkjvm);
    void IkUKLH();
    bool voVfTvUHheeLKe();
protected:
    string eGAdLZTZlzUgkvh;
    int tUWYJx;
    string fHQhRRgnFpgcEW;
    double IXaRsfgnwCJ;
    string MvmcYVPpix;
    int YnPmkI;

    void DpAhxromuhfar();
    int wMvmYsOkikVS(double ViOqPHZhjMyOhu);
    double tZmEqgX(double GHCyYZxCyXuMO, int WJOIz, int lSZovAImVCAxIT, int rlsSUjBBaxEZbH);
    int bJjpesZDLHUhEx(bool BAYWpzQVkDJ, bool ASewGQLEW, int DQfiUPOMTfZDHFs);
private:
    double slawAEAiUfzC;
    int VrCbMm;
    bool ioSZhOkGTdDAC;

    bool nwXVYXzyzy(double UnYlXFDbRyX, double VhxkKWpmijrUpR, bool SFcUwjHaABZZC, int BQlMgWWeqheOFkri);
};

int BIBZoVlLTS::tlEzJLOF(double kcskviyLfzHozouy, bool ZmEPnsZxSBJ)
{
    int BOnOBbeDNqRU = -330684534;
    string WuXBlcmsruvbjUn = string("wAlMZXJkcrAFwFtyXPYcmgsvHKbiYRcJMowfMaaoMGYWPtzpkPJOqgvoRTBvgiJuguLghbRmBiIJAKCEqTorQHTqOOPFHGBBvWamubiMfWkIEIAQNWRQfshuxkWVPJIzrXMlwPGdiZyxwgzDxknFryqXSmdwqNnBKjGnZtrdiQuFcuLOvALOxLGUlJWycZUhhMcSuQfobCgWigVfetJYBoKJcwAwwRJyALMSCxZXGQptzhFwzgcDXOohfz");

    for (int gAojTeiugAidbB = 819775516; gAojTeiugAidbB > 0; gAojTeiugAidbB--) {
        WuXBlcmsruvbjUn += WuXBlcmsruvbjUn;
        BOnOBbeDNqRU /= BOnOBbeDNqRU;
        ZmEPnsZxSBJ = ! ZmEPnsZxSBJ;
    }

    if (ZmEPnsZxSBJ != true) {
        for (int OjIVBlihxI = 2013443956; OjIVBlihxI > 0; OjIVBlihxI--) {
            kcskviyLfzHozouy += kcskviyLfzHozouy;
        }
    }

    for (int IeNHLehPkMIyMJ = 1895230829; IeNHLehPkMIyMJ > 0; IeNHLehPkMIyMJ--) {
        WuXBlcmsruvbjUn = WuXBlcmsruvbjUn;
    }

    return BOnOBbeDNqRU;
}

double BIBZoVlLTS::auswfZi(string QJrSG)
{
    bool LiDzDUCivF = true;
    int nasLSrZUZu = 744363132;
    string ArPmUabQd = string("EBxaXTvOfYkhkmxijwkdKPwfddvmjFiwbiozjOsSjWXzDniUXyNQmBcwJbMFPTlvAnXDBeXsPgOrjxuZQeLwVrVMAWaxcCRYgIIkFvveXjaNWVEwaBylErEAocLRznjEbNblvqesiAIJzyLWtcajOmnYxEkckSIORqBalEleCGxomXoIyTXjWvvWXswPWPsDcsoZWOxyuDYQSjvVdAzeEMdyMKp");
    double KEiWAMCbitHW = 899078.503161608;
    int YrtdUxBYObjgXXi = -406880689;

    for (int xJEuluAgf = 373784248; xJEuluAgf > 0; xJEuluAgf--) {
        ArPmUabQd = QJrSG;
    }

    for (int HitQtpoXxm = 951660107; HitQtpoXxm > 0; HitQtpoXxm--) {
        ArPmUabQd += QJrSG;
    }

    for (int jiCTJHsVNs = 598320616; jiCTJHsVNs > 0; jiCTJHsVNs--) {
        continue;
    }

    return KEiWAMCbitHW;
}

int BIBZoVlLTS::pAhHvgu(string ijxGgdxO, double rMgBqAeeOkjrLKqC, bool WcGmgcMWL, bool DjPnWMYtED, double dkjvm)
{
    bool yLWSEmdbLRyiT = true;
    bool LyXGkAHXqZ = false;
    bool cqBCVbhkIPYQZHq = false;
    bool WPBjchEjGrZoTRX = false;
    int YDIRAsC = -1323750174;
    int ZHejmytmmmmff = -587937638;
    double SaiJCISTWijnEcz = -477478.2057933917;

    for (int YqTYTvpRmz = 890709183; YqTYTvpRmz > 0; YqTYTvpRmz--) {
        yLWSEmdbLRyiT = LyXGkAHXqZ;
    }

    for (int ewLBQaIxW = 560930860; ewLBQaIxW > 0; ewLBQaIxW--) {
        cqBCVbhkIPYQZHq = ! WcGmgcMWL;
        YDIRAsC += YDIRAsC;
        dkjvm = SaiJCISTWijnEcz;
    }

    for (int FeOADZkOY = 1644024688; FeOADZkOY > 0; FeOADZkOY--) {
        LyXGkAHXqZ = ! DjPnWMYtED;
        DjPnWMYtED = yLWSEmdbLRyiT;
        ZHejmytmmmmff = ZHejmytmmmmff;
        cqBCVbhkIPYQZHq = yLWSEmdbLRyiT;
        cqBCVbhkIPYQZHq = yLWSEmdbLRyiT;
    }

    for (int DbWRxMcgWaXWFE = 365991112; DbWRxMcgWaXWFE > 0; DbWRxMcgWaXWFE--) {
        continue;
    }

    for (int MBcNPNt = 1386244051; MBcNPNt > 0; MBcNPNt--) {
        continue;
    }

    for (int CEMfbsPGIPemVVC = 1959529315; CEMfbsPGIPemVVC > 0; CEMfbsPGIPemVVC--) {
        yLWSEmdbLRyiT = ! DjPnWMYtED;
        rMgBqAeeOkjrLKqC /= rMgBqAeeOkjrLKqC;
    }

    for (int BLYjRDoftRd = 1106250679; BLYjRDoftRd > 0; BLYjRDoftRd--) {
        LyXGkAHXqZ = ! WPBjchEjGrZoTRX;
    }

    for (int zRTXpuREX = 1805058235; zRTXpuREX > 0; zRTXpuREX--) {
        rMgBqAeeOkjrLKqC += dkjvm;
        WcGmgcMWL = ! WcGmgcMWL;
        yLWSEmdbLRyiT = ! WPBjchEjGrZoTRX;
    }

    return ZHejmytmmmmff;
}

void BIBZoVlLTS::IkUKLH()
{
    double kuzUUiWicteW = -890502.7542649866;
    int EfehjJgqbdpTJjmR = -771564879;
    string txuMsLKIfFqGmZ = string("PDYiHWMuVJCipLpvpnUVJQuPTTQHwUVqOAyrfxQLZEEMpUiAnNvnHzVsPgtPSQHHIob");
    int vAELiduNYTGt = 1662619016;
    int JoYZTldUsRgiY = 1330973277;
    int CbUxRMjZbKCEI = -735460675;

    if (JoYZTldUsRgiY >= 1662619016) {
        for (int JrdZyzuwyXKS = 158165945; JrdZyzuwyXKS > 0; JrdZyzuwyXKS--) {
            JoYZTldUsRgiY += JoYZTldUsRgiY;
            vAELiduNYTGt /= EfehjJgqbdpTJjmR;
            CbUxRMjZbKCEI = EfehjJgqbdpTJjmR;
            vAELiduNYTGt /= vAELiduNYTGt;
            JoYZTldUsRgiY *= JoYZTldUsRgiY;
        }
    }

    if (JoYZTldUsRgiY <= 1662619016) {
        for (int XobKDSQnj = 1119906816; XobKDSQnj > 0; XobKDSQnj--) {
            CbUxRMjZbKCEI = CbUxRMjZbKCEI;
            CbUxRMjZbKCEI /= EfehjJgqbdpTJjmR;
            EfehjJgqbdpTJjmR /= vAELiduNYTGt;
            JoYZTldUsRgiY *= vAELiduNYTGt;
            CbUxRMjZbKCEI /= JoYZTldUsRgiY;
            JoYZTldUsRgiY *= vAELiduNYTGt;
        }
    }

    if (EfehjJgqbdpTJjmR > 1662619016) {
        for (int RrmiXHxCwUbwwtWE = 253823950; RrmiXHxCwUbwwtWE > 0; RrmiXHxCwUbwwtWE--) {
            CbUxRMjZbKCEI /= EfehjJgqbdpTJjmR;
            JoYZTldUsRgiY = EfehjJgqbdpTJjmR;
            vAELiduNYTGt *= EfehjJgqbdpTJjmR;
            kuzUUiWicteW += kuzUUiWicteW;
            EfehjJgqbdpTJjmR *= JoYZTldUsRgiY;
            CbUxRMjZbKCEI *= EfehjJgqbdpTJjmR;
        }
    }
}

bool BIBZoVlLTS::voVfTvUHheeLKe()
{
    int fKtRZfVPeSZz = -711038438;
    string ybLOyZAztLQK = string("fRcOevxyrijLMZGawBXfLBCSthxgcvtdOqMVzeyLVaqFaWgWxJRUTQHgjjxxPrKqvXWifnTaFkNKDaNMciZyhsLkHsHQvZJAbKculYqdEJMksqwQojOiIZDbAzMmTQEtDCjvJEQLuWSCmVpRyWBfnHbrbyKEASAFdDisyIPApFcBIDEXZWKeCzAEfVbnDKcRGMZOmAOhCzy");
    bool ycZUhTl = true;
    string fJzCfk = string("xhOnrjvwMObTVTeqEVEQttNgcHuNUjfbHgcXodNTVAItyCeDgSmmFtVpbuPQdmtpFzIJbYDDElwmtofwRJhunpcaPpHdeuOCKClfjqmPudQLathIXZuDrbEUFZMoNYpu");
    string ORKkgXPu = string("htZnbKJuQZXhgwjlAXSJCRVRdWlxzvFHvrSPEBvHrYeetZfiOOmOZtjuVLbPZGvsqXMcNUapGNuYxWqdBuWDWDArEowIVQyThPoSZSkOGCRtKBDwW");
    string GITHj = string("GASDUUqHeiPtOtDBxnBOenYuzPbWBPcSAjpayCCDHIFiVSgDwartjtbIDtvDTjxKGUYPFDAoJvxdslBcCkNIUzAZrDzVdWMAoGFVdGwHHDJfNVVfYtgNtsovHvlPcYAleOPQmwMugCBxgRdcEwUoxYAMrnEoRPRoxyDkoUDKRxKqufRIyzxCBORhGUnKPkhKJGagrcqdJjGPIjW");
    string GbdUySAQplBbVI = string("ljAgBGqCfQZGafwNqZiws");
    string quHSqNdqJBMAES = string("olFqvaFOqZJjOXngyRaNKJwCsoNuVupUPdlrFvcnhLCqXLcQqgWiyQBtKyPvseEDVFTfrNuEetgrfZOliemLzXNcvBVppJoJEPdJnxYgphhVPAWMVCrAYzfsHkkslJNMtyMNuYbExCDXZtGRexnhsGXVMpyWduzriFNNaiXCoyKnsCVVWEobdbMRwSiPwSKjYqWWgGSsvBKGtjqeIWzDFMeJdyQvneMdopUtJg");

    if (quHSqNdqJBMAES == string("xhOnrjvwMObTVTeqEVEQttNgcHuNUjfbHgcXodNTVAItyCeDgSmmFtVpbuPQdmtpFzIJbYDDElwmtofwRJhunpcaPpHdeuOCKClfjqmPudQLathIXZuDrbEUFZMoNYpu")) {
        for (int FDerVjcWxRmqM = 498743274; FDerVjcWxRmqM > 0; FDerVjcWxRmqM--) {
            ORKkgXPu += quHSqNdqJBMAES;
            ORKkgXPu += GITHj;
            fJzCfk = ORKkgXPu;
            fJzCfk += quHSqNdqJBMAES;
        }
    }

    return ycZUhTl;
}

void BIBZoVlLTS::DpAhxromuhfar()
{
    bool sybcVjFeDuWmewM = false;
    int JzTNczJiYqPpwU = 2139928702;
    string rHjjsOpBcncbCZQu = string("lPZVcVvfNmMBzraYoTUAgABcedNdNVeDBoObbBLfsYgDTXQUikYljRIlHGkXqbNxZyKtVrPVsgYdSqeHwsWKIhTQdKWgYccEOJeOrnuCVSsFbqavsxaqNggBVLyHrMYTHOEFZLyMDGXYppwyuYWBdGRmieDAxQIzyKzEZWehYoHMnSHqiYmCVimdeAeFEgbwAQWVFKOvFoiDISC");
    bool oZKHCQ = false;
}

int BIBZoVlLTS::wMvmYsOkikVS(double ViOqPHZhjMyOhu)
{
    int gJXsNFnvBhtjrox = -451061415;
    int fCJxIIzM = 502188366;
    int NNQrBx = 1357162449;
    bool uPNnU = false;

    for (int LtnemRomYwuDSIo = 1560076409; LtnemRomYwuDSIo > 0; LtnemRomYwuDSIo--) {
        fCJxIIzM -= fCJxIIzM;
        NNQrBx *= gJXsNFnvBhtjrox;
        NNQrBx *= gJXsNFnvBhtjrox;
    }

    return NNQrBx;
}

double BIBZoVlLTS::tZmEqgX(double GHCyYZxCyXuMO, int WJOIz, int lSZovAImVCAxIT, int rlsSUjBBaxEZbH)
{
    int DTlpJy = -1429721592;
    string wZptbzEZ = string("GJCAkkDAqkrhZPjiKsaHlvuzpAlapVNqpPpBDbFIVcSZcvXLNpuToRxlMOehbZ");
    int fBqYxnYnJ = -1459742711;
    string vdcqGbyLNLjIncn = string("BNFNoGflrOqaIsuRkMqdvwQlAzUziLqqJZSFyCqYgVytUjHrEkXksDfjrTEgltErcHjfbSKUUqDTJZrnABooiponGMaplHlqoUInBXqLWElOSntfkcAXpbBMLVUtqFIwBkZNRhxZlEmIsdPisdSJGMiIDTbQOWwVbFusblmsEnYojYtgXjZkYyVQLyOAwrImVqdKHXkIulgwIoWjojKMDQQKceHyqJNFLkcwwcfNKKZZGsoU");
    string ErfZuT = string("lMxaurFtRggtpudYaoYTRPZzWcIillCuxfRTVUeVoIMGuRzSZDGFUpIpFKyswZDRDjZCuyVbAtAqkxszJCMCmnmuvkOkqlEvUwNtbHoZdCOLIGlZMFCIlLJOKUSrUQAKxmegRTBrbfEkOxngzoSdvIjNVAaGTQTBUfYPnzbvkqYwSxJpSHhIpuSIpisGZNFTELffbn");
    bool yRYXoO = false;
    int HEJZoSPFfzRznigj = 265637583;

    for (int DuTTbHEVbNqr = 135215073; DuTTbHEVbNqr > 0; DuTTbHEVbNqr--) {
        lSZovAImVCAxIT -= DTlpJy;
        WJOIz *= fBqYxnYnJ;
        DTlpJy += WJOIz;
        rlsSUjBBaxEZbH = fBqYxnYnJ;
        rlsSUjBBaxEZbH *= rlsSUjBBaxEZbH;
    }

    if (lSZovAImVCAxIT <= 361772939) {
        for (int bYxJRkP = 1940840959; bYxJRkP > 0; bYxJRkP--) {
            DTlpJy -= rlsSUjBBaxEZbH;
        }
    }

    for (int oaXgFXmLmw = 609558897; oaXgFXmLmw > 0; oaXgFXmLmw--) {
        HEJZoSPFfzRznigj *= rlsSUjBBaxEZbH;
        WJOIz /= rlsSUjBBaxEZbH;
    }

    return GHCyYZxCyXuMO;
}

int BIBZoVlLTS::bJjpesZDLHUhEx(bool BAYWpzQVkDJ, bool ASewGQLEW, int DQfiUPOMTfZDHFs)
{
    int WmNsNwvlrlZo = -1619034130;
    bool QKFxQsjhUyj = true;
    string igKKlBNyoM = string("MgocdZFMWQFAVxziijqAPmZKKqaChARrdHBnyhiktBLSxqdZRSqoMbcSbIJfAtLyExPjpFMUSlMLjTfPKVZDLGVaVUXmZgBjeeYPrSIQFDiSbpbOvNfNLSsRIwoWykZPKPKfEaYdjqciIMqCHyGnkAmhBKnAjeVDSxwfnsktpnplqOTmCaMUslfoUsxvcQeDQekBtatOqCaBJq");
    string ZXMmpYi = string("emeRqmIXppBVLjaaZoRzxVkkFHjdQBFWhptDAEyxrVTdkfaDCUkGUFQAqPKqLuqeFIjtMOpjZIFQLoaIZv");
    int OyLxDmk = 148099643;
    bool CXLvZf = true;
    int YTkBTXszhVrYDz = 1409542646;
    string CruglfMrHxQdtECj = string("dqJJNBAnTiNbyRWhMHnbXmxAVRQY");
    int RzFvxXqzvDSIDJ = -311566825;
    string VjKloeFhAvs = string("FWdIHPexKs");

    for (int FbELKI = 1523989735; FbELKI > 0; FbELKI--) {
        igKKlBNyoM = ZXMmpYi;
    }

    if (VjKloeFhAvs == string("FWdIHPexKs")) {
        for (int qZSBPCyOyc = 1338242584; qZSBPCyOyc > 0; qZSBPCyOyc--) {
            ZXMmpYi = VjKloeFhAvs;
        }
    }

    return RzFvxXqzvDSIDJ;
}

bool BIBZoVlLTS::nwXVYXzyzy(double UnYlXFDbRyX, double VhxkKWpmijrUpR, bool SFcUwjHaABZZC, int BQlMgWWeqheOFkri)
{
    string aEbHJmmQ = string("MVJTGOEWxpnRKihfWpQgEIOJWoCnYbcogIZpmODhwSfTHPkJmurmsYQerDhRiALuLWzPtKcRVaiyWBzpjnhucOfUEcVkDDHIvektOMymejcepxibaQCDTSqcOeqd");
    string bGvhYsMRaOWkLK = string("wsMGMxjSlqbUjpPvxedPIvrWMuQZGmtkDguxBZBZMcmkTaZPBbeHooRfBTOZnoeVhSVFhEbOMfpkEobUyQMEeQSEBVqDjVsLDqvPMzhmbJGAWSImvaPnfCaFgaYmbAcfEGiZpOHwpEhIppuByXlWmeQigSHpvwDrRAssRScajgsduubpRMgUTEDxckIrSbXJsqvGKGfLNBGmjMCwpgxMosrJaaPqftttTCpRaSI");
    double sfhoPl = -716333.7985834886;

    for (int OOMzRbsE = 187327589; OOMzRbsE > 0; OOMzRbsE--) {
        VhxkKWpmijrUpR /= VhxkKWpmijrUpR;
    }

    if (VhxkKWpmijrUpR <= 419137.46909901366) {
        for (int ciCcAs = 1124620041; ciCcAs > 0; ciCcAs--) {
            sfhoPl += VhxkKWpmijrUpR;
            sfhoPl = UnYlXFDbRyX;
        }
    }

    return SFcUwjHaABZZC;
}

BIBZoVlLTS::BIBZoVlLTS()
{
    this->tlEzJLOF(-244217.9271367774, true);
    this->auswfZi(string("WmzNcjHkBNO"));
    this->pAhHvgu(string("VNckGWdIEApBMZKsfQyWxPVfGMjgvBYpMWxfkDefNbOKmqTYAnwGnxCQMmURvmOmWRywtLrthsHCxOWPXMTJuXHEAwgzfVLypGGfCCCAKKYlmQjxIJqyRJWdDSjVrqDEFzMXbddAYZBFDFmKMPLjbodPkQjYQbNtAaJKNkZxOQILDbEhtIDExvOQeClIKLyEoIEKSIZfvxmVkbEEbbSEBAUCGjeSzUqNwtXKWYZISQRdiJMFLxgPPMxBH"), 999756.0516366252, false, true, -410273.54296555655);
    this->IkUKLH();
    this->voVfTvUHheeLKe();
    this->DpAhxromuhfar();
    this->wMvmYsOkikVS(-163281.92843616894);
    this->tZmEqgX(337230.1885912483, 361772939, -724058094, -1617984600);
    this->bJjpesZDLHUhEx(false, true, -2072984448);
    this->nwXVYXzyzy(419137.46909901366, -834731.8980929524, true, -1043135377);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zNiEVEiniCChcnq
{
public:
    bool ccSYNGddSONmpzvE;

    zNiEVEiniCChcnq();
protected:
    double IRmSVCY;

private:
    string AoZTt;

};

zNiEVEiniCChcnq::zNiEVEiniCChcnq()
{

}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NYXEjPOFTChtXBB
{
public:
    int rdoLkcFF;
    double itlLXBTc;
    bool CFwKVTksNvBO;

    NYXEjPOFTChtXBB();
    int qEFINGGZXHebE();
    int PdYMuyArYV(string caJoMQjbaHPJNNUL, string UdSDoMu, bool PGnGYLg);
    int uOMqDwBSyCCVmq();
    double JLJQMpuZ(bool azkgCmdjFa, int cvrZIjgITXd);
    string iFElHBJnaNEds();
    string owtVyCNAiU(int HoaOfH);
    void JKmEATFFH(string ObCCwOOSJMCP, double SFDWnvcgLCpwr, int OnrtMugP);
    bool bEzKc(bool XEpTGIBLPLTYPs, bool riWLdKxDyrLz, string fWhKBnAAWaQJfKzX, bool rlfUGuollmE, int xVVEwvFC);
protected:
    int EjWFSJiCfPqKcjFy;
    string MWIUVLqBv;
    string TRdcGOJ;
    bool DcFtwTwFDI;
    int aAHSnKhPegRlW;
    int qIArAitoksLHwA;

    bool QytjFPQQYvJx(int sogAsndxKq, int ndlnGASGEfTMz, int fSFvCbHRYtwb, string CWwzYJFBXoZFh);
    void KlaahOTQTZPdr(int FAkqFPaUJ);
    void jTqWDbw(int NoYXIcjHiCvyhK, double sJDedyO, bool AIObNedIDf, bool DYzmpu);
    string PvFvMg(string uWqMhNFNxTrA, double gRwRlHnXhvHMpXO, int XnuqQ, string SxjkrmQyJ);
    string NFBUtiWg(bool wvVsCyUbTc, string VtSMGeMWkcL, bool vfoukWErnIHf, int hoSXcMMqPf, string jnWLO);
private:
    int QsEEKb;
    double lXFUEZkfl;

    bool qiZwoJjWwnACWfLs(int euGSCBtSwAVyPjsR);
    int mMDbUCrZdUqoTG(bool IevAHcmQ, string FoRwJlYawk, int DYnueRf);
};

int NYXEjPOFTChtXBB::qEFINGGZXHebE()
{
    int zXiSfvcZb = -1664306195;
    bool TLOHePFz = false;
    string ncdgundkaFBWusEv = string("lZHsahkjPVJPRcazVhwSDefOaNeXjRLDpQdGhrknWbdtQZvnPzYnxdUEfqoMyWVdBdRAbLICnncBVLsqrfzaGZPWcMqciYtVbnmZCLlOGoowBJgjgePchlMbYSdpLDeTnLKSjqsKnguKgmfoChqtuZhbdpYmNKeKrfeVgYCcVJXa");

    if (ncdgundkaFBWusEv > string("lZHsahkjPVJPRcazVhwSDefOaNeXjRLDpQdGhrknWbdtQZvnPzYnxdUEfqoMyWVdBdRAbLICnncBVLsqrfzaGZPWcMqciYtVbnmZCLlOGoowBJgjgePchlMbYSdpLDeTnLKSjqsKnguKgmfoChqtuZhbdpYmNKeKrfeVgYCcVJXa")) {
        for (int UHbaIFvXFvpm = 850148167; UHbaIFvXFvpm > 0; UHbaIFvXFvpm--) {
            zXiSfvcZb *= zXiSfvcZb;
            ncdgundkaFBWusEv = ncdgundkaFBWusEv;
        }
    }

    return zXiSfvcZb;
}

int NYXEjPOFTChtXBB::PdYMuyArYV(string caJoMQjbaHPJNNUL, string UdSDoMu, bool PGnGYLg)
{
    bool daDDOXPWN = true;
    string OcRjhIFdxYYvjxn = string("xsCmBjEuKJUGcAdOABOtWmhkBBuLbFyIywHvkhxTpLTIoapPRrJQhurKbzGEqTobUuDOSQdXjgiHihakWaIOYctUNpufUuPrHUrwrrFMIzpYiJvoqgfvWaZZCVTbASdopZPFNZGFLJGFYkKaSPENsKvIVAiOMQhZylgOspjBmTvmrhbOPsOIwKFhyelYpqR");
    int SdHfXjsuzhfbz = 345724657;
    bool ROLRGJTPtu = true;
    bool cXzsezFk = true;
    bool KSEOgpHjv = false;

    for (int HiTKoGaDfOfYwKuk = 798647918; HiTKoGaDfOfYwKuk > 0; HiTKoGaDfOfYwKuk--) {
        daDDOXPWN = PGnGYLg;
        SdHfXjsuzhfbz *= SdHfXjsuzhfbz;
        PGnGYLg = ! ROLRGJTPtu;
    }

    if (SdHfXjsuzhfbz >= 345724657) {
        for (int QPiMAIAjD = 1603999497; QPiMAIAjD > 0; QPiMAIAjD--) {
            caJoMQjbaHPJNNUL = UdSDoMu;
        }
    }

    for (int TcyICyg = 1971633745; TcyICyg > 0; TcyICyg--) {
        UdSDoMu += UdSDoMu;
        ROLRGJTPtu = ! ROLRGJTPtu;
        OcRjhIFdxYYvjxn = OcRjhIFdxYYvjxn;
        ROLRGJTPtu = cXzsezFk;
    }

    for (int nqquLil = 1971430628; nqquLil > 0; nqquLil--) {
        ROLRGJTPtu = ROLRGJTPtu;
        ROLRGJTPtu = ! PGnGYLg;
    }

    return SdHfXjsuzhfbz;
}

int NYXEjPOFTChtXBB::uOMqDwBSyCCVmq()
{
    bool TqNFloRVsl = true;
    string ElwehtTbsOHJLMk = string("wwUmritElSUykVliPhCcEceoadEPHCXNvuoizhGqEAwSGdkkGpaTdTktkGaXIQhMLaiDjfeWckonQW");
    string LYzEohI = string("kkoXiVcIQtofsTXSiRMnhXBFKzZnGfwEPgUpFbzQHHtbZJVAMCTYfkAZczrJHihfxwefadzLrvEhAwSjmFoPxswABitbpnJldXJNITAvodsLZMfRYqzRMpxHTjYkUdPtpYEtcZNPIjifqhfmPOpoQ");
    double gKZURrSxzgXvB = 469198.94545427844;
    double fqcgrmUQzdsthDkx = 914162.6869147054;
    string YpNbGBqi = string("FCvfCVvgWKLDaqoCVJUYmrAclUlAgOqUHLEyVMHkALuAEstomGNKIwGtrYhRLYuXWMVErTEgaKYTWKaGJgJnVMidxsydRMlAqQzUguGJuPFOikZqnZunFZWuvqxzmYbkUMKOaTWRgmPsoZUVIcjhgUIFerzTBbXwqePDOdnNGFpwBAnXFZajaDBPGjhcXeUupQlmodvpQVeoMaqDiLDUCvWIoyuUsTDgacylGcrkivffhcBZH");
    string pUcoceMNrrMF = string("uAIEvmCzkuJPyrZWFtVrQLSFwdAeJnFOWIsPeltojPaJKAueNXyqIduJPtyPOuDYRD");

    for (int VQmDfmaAYIZT = 2136802262; VQmDfmaAYIZT > 0; VQmDfmaAYIZT--) {
        fqcgrmUQzdsthDkx = fqcgrmUQzdsthDkx;
        pUcoceMNrrMF += YpNbGBqi;
        YpNbGBqi = YpNbGBqi;
        ElwehtTbsOHJLMk = YpNbGBqi;
    }

    for (int GQXQWN = 1238133042; GQXQWN > 0; GQXQWN--) {
        continue;
    }

    for (int hndNQDIkeSbFPSL = 1068869114; hndNQDIkeSbFPSL > 0; hndNQDIkeSbFPSL--) {
        fqcgrmUQzdsthDkx /= fqcgrmUQzdsthDkx;
    }

    return 2096658178;
}

double NYXEjPOFTChtXBB::JLJQMpuZ(bool azkgCmdjFa, int cvrZIjgITXd)
{
    int fIkQXyWBM = -1540327668;
    double DzFgJplliDHQcqA = 766158.6141707149;
    int erWEYtjKk = 728987870;
    string CrGMmTy = string("MFtWRBlARsjWuTYcEspecoHlBqHYUDJctEsZGvVpaLcukSpnqAtQjyRxRyeJwfgyyJGQHHKKUyXzSpEqFFZRGTIcGFaIBOeSmsEPNvXVikTSfESFCYvnJKf");

    for (int aMkQdQYHA = 1496831631; aMkQdQYHA > 0; aMkQdQYHA--) {
        erWEYtjKk = erWEYtjKk;
        fIkQXyWBM -= cvrZIjgITXd;
    }

    for (int rgnKcSmuOCFOTFie = 1657341444; rgnKcSmuOCFOTFie > 0; rgnKcSmuOCFOTFie--) {
        continue;
    }

    for (int WYEguVaESqsgy = 943670249; WYEguVaESqsgy > 0; WYEguVaESqsgy--) {
        erWEYtjKk -= fIkQXyWBM;
    }

    return DzFgJplliDHQcqA;
}

string NYXEjPOFTChtXBB::iFElHBJnaNEds()
{
    string kTkRo = string("cIBxppGuyfezRUtNlAXcFiKtukNPRDycPyMEN");
    double zZTyUVAI = -515919.6701469445;
    bool BdmfevJj = false;
    double VzLGAzsUFryJ = -83608.50639991807;

    if (BdmfevJj != false) {
        for (int DLXpcDtMTCeYlgV = 1739348841; DLXpcDtMTCeYlgV > 0; DLXpcDtMTCeYlgV--) {
            VzLGAzsUFryJ *= VzLGAzsUFryJ;
        }
    }

    if (VzLGAzsUFryJ < -515919.6701469445) {
        for (int ZbJMk = 1462498528; ZbJMk > 0; ZbJMk--) {
            zZTyUVAI *= VzLGAzsUFryJ;
            VzLGAzsUFryJ = zZTyUVAI;
            VzLGAzsUFryJ += VzLGAzsUFryJ;
            VzLGAzsUFryJ += VzLGAzsUFryJ;
        }
    }

    for (int ujGwHanByR = 1478919690; ujGwHanByR > 0; ujGwHanByR--) {
        zZTyUVAI -= zZTyUVAI;
        VzLGAzsUFryJ += zZTyUVAI;
        zZTyUVAI = zZTyUVAI;
        VzLGAzsUFryJ -= VzLGAzsUFryJ;
    }

    for (int vJCJUmWvR = 1942749948; vJCJUmWvR > 0; vJCJUmWvR--) {
        VzLGAzsUFryJ += VzLGAzsUFryJ;
    }

    return kTkRo;
}

string NYXEjPOFTChtXBB::owtVyCNAiU(int HoaOfH)
{
    bool brhQvTNQj = true;
    string TZvOs = string("uxUqXQOHgIlhXYJHaaZvAyweNGYFBDPOhtiIlTPnqyzJXeOkXNDfbcMoIzgvNaHywACGDieGRWyjjdRacurBggMbPPzmAAFiPuvhWayiMcPpAsAxiMaFWlSkTqSSXVyhavwrrXFnZflhkNSAkAMPQujxlKTmeGBGQZEdCskYIgCgBeAEsDCp");
    string YDwgWeZtjWDZmtgJ = string("uscCPsYocWZdtVkENitCqDEnqbeEyRXoacyfnqtuWgBESpNHjCxcEglxeRvvgHtKBXJafSWXFBfvHQurwMOqAxwQxTjkXnfiLWBhWAZjU");
    bool NyvbpBF = true;
    string msZeHqkVxPlxEFY = string("tvNvYGVaLSwlXPDCuSFsGgtgIAkhBXgDSHNpdsMRlLqKSQpALWnzkCvwrEHUJoXMHcPvYgYaCbINsgRzTCIBoJKMhfACusNQNWwgkIgYmsUDoRIudJFkOFNeJtQhGcZbSTuNUyHocNeylURhhOBdvwpXSznyewwCq");
    bool ZaucZyeLkIDJOLwn = false;
    int FZHTeGZfHos = -1941291320;
    int cJNcPTV = 563077805;

    for (int bOhqBLZuuKXvn = 1352831459; bOhqBLZuuKXvn > 0; bOhqBLZuuKXvn--) {
        FZHTeGZfHos -= cJNcPTV;
        FZHTeGZfHos += FZHTeGZfHos;
        NyvbpBF = brhQvTNQj;
    }

    for (int TnzEynIuL = 1659423753; TnzEynIuL > 0; TnzEynIuL--) {
        continue;
    }

    return msZeHqkVxPlxEFY;
}

void NYXEjPOFTChtXBB::JKmEATFFH(string ObCCwOOSJMCP, double SFDWnvcgLCpwr, int OnrtMugP)
{
    double UGmoLDF = -486466.76652762893;
    string zmZLXPczfMvZVI = string("CjvmTzwjckvPZKlicodvFeQPMrNMYgokZbvPWiOLGhYgwilsanqqBdofZcPwsmKYzIDYisOjZLhpCDiUFNipDazHTrhsbpMGoMgjXPcvOMPGGjPlkNDkhlcSEBZaapneSwkJXyVDUXHGfMiMHdvOHMPSqXDvKUFkEopXABkMjPVAFZWcXsMRsLtcIWwjMbWmBqWZMoCgXEITjgLqqXnvLlW");

    for (int KHPbwwbxaUsOMv = 1282642168; KHPbwwbxaUsOMv > 0; KHPbwwbxaUsOMv--) {
        UGmoLDF /= UGmoLDF;
    }

    for (int rnlBjyVuCwUFot = 743230138; rnlBjyVuCwUFot > 0; rnlBjyVuCwUFot--) {
        OnrtMugP = OnrtMugP;
        OnrtMugP = OnrtMugP;
        ObCCwOOSJMCP = zmZLXPczfMvZVI;
        zmZLXPczfMvZVI += zmZLXPczfMvZVI;
    }
}

bool NYXEjPOFTChtXBB::bEzKc(bool XEpTGIBLPLTYPs, bool riWLdKxDyrLz, string fWhKBnAAWaQJfKzX, bool rlfUGuollmE, int xVVEwvFC)
{
    string NmNWBZBS = string("zcVfNtqPGcmIhYDWAyjkheJcJxMxnVvXhzzjdrPZnSRTgaViAHIuLsyqfqEQlPrbXtSZmeESTgrVVUaDEgLesMEfaTvzomeyDfdvhSVaRa");
    double TwrIujM = 702632.8348487064;
    string XmYAIYiDekQzgL = string("ObDhMOYeKtElgWuFwHAJMKGVeZAmlNNtDYBwCImwHmatVxIGVQpHeVjSxFprCXFljEsdbuUDuOAubQmiCdIjWgHoXsoMcFpRNedLdfBnZUhGETRVYFKHobtXhBwwkaNTxQkapdZxw");
    bool ffzbpKPIJnSgN = false;
    string GuNMieNqHImazH = string("CGYYEQHoagyynWQAqbkAPJNiHsxOmrMKzrrBlIlZetXmjrwZqqkWBruiWZHnOLxvIlmQmzIMZqBDMZdvcVlYNfIFfKUVeoFUROgRBTsRRPQNfPkgkHtdcpgMgsHdjypyqVoQfzLAjOJDXGRmMq");
    double XjCHyRfOdP = 1032409.1220029782;
    bool FfqsciJOAJRK = false;
    bool dZeuCxnGh = false;

    for (int CtDlcHk = 607671212; CtDlcHk > 0; CtDlcHk--) {
        XmYAIYiDekQzgL += NmNWBZBS;
        dZeuCxnGh = ! riWLdKxDyrLz;
        dZeuCxnGh = rlfUGuollmE;
    }

    if (XmYAIYiDekQzgL < string("zcVfNtqPGcmIhYDWAyjkheJcJxMxnVvXhzzjdrPZnSRTgaViAHIuLsyqfqEQlPrbXtSZmeESTgrVVUaDEgLesMEfaTvzomeyDfdvhSVaRa")) {
        for (int gvRKCoPaIQq = 1821495476; gvRKCoPaIQq > 0; gvRKCoPaIQq--) {
            riWLdKxDyrLz = ! XEpTGIBLPLTYPs;
        }
    }

    for (int pUqgeStQxZos = 1286573791; pUqgeStQxZos > 0; pUqgeStQxZos--) {
        xVVEwvFC *= xVVEwvFC;
        TwrIujM = XjCHyRfOdP;
    }

    for (int xfXwNKbIxeel = 79644577; xfXwNKbIxeel > 0; xfXwNKbIxeel--) {
        dZeuCxnGh = ! XEpTGIBLPLTYPs;
        FfqsciJOAJRK = ! FfqsciJOAJRK;
    }

    if (XjCHyRfOdP == 702632.8348487064) {
        for (int IpgjXnRDAr = 294512234; IpgjXnRDAr > 0; IpgjXnRDAr--) {
            dZeuCxnGh = riWLdKxDyrLz;
            riWLdKxDyrLz = rlfUGuollmE;
            dZeuCxnGh = ! ffzbpKPIJnSgN;
            FfqsciJOAJRK = ! rlfUGuollmE;
        }
    }

    for (int wNeKxfHUjOGXAMl = 605565412; wNeKxfHUjOGXAMl > 0; wNeKxfHUjOGXAMl--) {
        ffzbpKPIJnSgN = ! FfqsciJOAJRK;
    }

    return dZeuCxnGh;
}

bool NYXEjPOFTChtXBB::QytjFPQQYvJx(int sogAsndxKq, int ndlnGASGEfTMz, int fSFvCbHRYtwb, string CWwzYJFBXoZFh)
{
    bool szDosyKzNjzPvaF = false;
    double VNVrl = -445336.7415755674;
    int QqSNuM = 418589637;
    int ejAKnve = 1688626822;

    if (QqSNuM == -773534865) {
        for (int sRFNoqVYSklmL = 1079873261; sRFNoqVYSklmL > 0; sRFNoqVYSklmL--) {
            continue;
        }
    }

    if (QqSNuM >= -773534865) {
        for (int tuYVQSj = 1051421599; tuYVQSj > 0; tuYVQSj--) {
            ejAKnve = ejAKnve;
        }
    }

    if (fSFvCbHRYtwb < 418589637) {
        for (int RhNUTOBqd = 1306632880; RhNUTOBqd > 0; RhNUTOBqd--) {
            ndlnGASGEfTMz /= fSFvCbHRYtwb;
            ndlnGASGEfTMz -= ejAKnve;
            sogAsndxKq += ndlnGASGEfTMz;
            ejAKnve -= sogAsndxKq;
        }
    }

    if (fSFvCbHRYtwb != 1688626822) {
        for (int ztgMdfKAM = 31462733; ztgMdfKAM > 0; ztgMdfKAM--) {
            sogAsndxKq += ndlnGASGEfTMz;
            QqSNuM *= ejAKnve;
            QqSNuM /= sogAsndxKq;
        }
    }

    for (int vPdMJPNfJ = 976259808; vPdMJPNfJ > 0; vPdMJPNfJ--) {
        ejAKnve -= QqSNuM;
    }

    return szDosyKzNjzPvaF;
}

void NYXEjPOFTChtXBB::KlaahOTQTZPdr(int FAkqFPaUJ)
{
    double XilKqMTceMRL = -902748.3085629212;
    string etlpAuj = string("YJWXiTWjcddFtJBRemXMQgucCfupJNfZbbTvSiodNfyAqkAzRjbkCYHaFCzaUlPpwGTCYxOiXJxsymNPFAjFYVVavjtGjzRFopdPJmeMaolKOpYDsruhtJyhKSCLYyuBeKXplYjvttUIXYSOeSVHyLWPCpwCMAEZsvczkZJhtEbjlLYUqhhplvkXvQHlDHhRt");
    string RGWeYH = string("wycHZXWzihLeGiuoguAZTslfxEyiHKFVottiigDPoEOxkPueKCXxGOcCqFeXvYDTRrQkjqIchbsjIbZEBzJMHUJPGqFeNNUTQlXuhRzImokSlpplJgOWxBJwaJzAXvrhWKnBYIPZaMswWDbbYXPnZ");
    string mjXPuuJFe = string("hrddRXyTvKQfDqWbcUgBJQlVcCfLWNBhcALoNwnmBlRmsuuqPGVhdfHWpYnwxKULVyilIxLMgtbbmnndOvduCWHsSzlMkTqtEOrtJRGesoZMRXnBVNtYlVAqfxclYEvERkKxfVzfDSOSabOEgdZVGHfTIOgHDVlDPpSNRJwLhkSIoXYiZXwTVgsK");
    double DmVZRsHduhjQLPOx = -157835.25100956275;
    string unwzsSVzAchu = string("RxMKWERJsvSgxgvJaWtPnqFCIbZpddmKSdDxMOlgSfCyRDznbwcFqoMeOdogtFAOZFzkxqvmpALcOIRkaKcptJlVLjeznojgeHMmcMUxXIKofkWzuGjmasFbZWKnjNzHZZZuDiniBQYFBPLHIEWIkfiVjPquSKNhy");
    int RGYUZdSraXzLbKj = 1530693820;
    double qVXcIltKPbbXLYLG = -336560.3684427502;
    double elSDtQiUi = 486162.4247542971;
    string MgAog = string("UKlvTuqjhJKwFauSoDoueEaSuaScrrVDiBcYPHdkxTVBlTpVXZhRQnpHmcRkYoHVlFeMVFHgxIujHWRSKOeWMVgJFPcIUXkEqKEtHMAPwypOurdDczfPNJGEkBKtNbPNcZRDGUGQlVMLokrJbBDB");

    if (elSDtQiUi >= 486162.4247542971) {
        for (int SKHTB = 1595260720; SKHTB > 0; SKHTB--) {
            XilKqMTceMRL += elSDtQiUi;
        }
    }

    if (mjXPuuJFe <= string("wycHZXWzihLeGiuoguAZTslfxEyiHKFVottiigDPoEOxkPueKCXxGOcCqFeXvYDTRrQkjqIchbsjIbZEBzJMHUJPGqFeNNUTQlXuhRzImokSlpplJgOWxBJwaJzAXvrhWKnBYIPZaMswWDbbYXPnZ")) {
        for (int YQziuIpUIWIZqbb = 2060998684; YQziuIpUIWIZqbb > 0; YQziuIpUIWIZqbb--) {
            RGYUZdSraXzLbKj -= FAkqFPaUJ;
            DmVZRsHduhjQLPOx += qVXcIltKPbbXLYLG;
        }
    }

    if (unwzsSVzAchu == string("RxMKWERJsvSgxgvJaWtPnqFCIbZpddmKSdDxMOlgSfCyRDznbwcFqoMeOdogtFAOZFzkxqvmpALcOIRkaKcptJlVLjeznojgeHMmcMUxXIKofkWzuGjmasFbZWKnjNzHZZZuDiniBQYFBPLHIEWIkfiVjPquSKNhy")) {
        for (int oDcUadLkoUIKESOe = 1269094154; oDcUadLkoUIKESOe > 0; oDcUadLkoUIKESOe--) {
            unwzsSVzAchu = etlpAuj;
            mjXPuuJFe += unwzsSVzAchu;
            qVXcIltKPbbXLYLG = qVXcIltKPbbXLYLG;
            RGWeYH += mjXPuuJFe;
        }
    }
}

void NYXEjPOFTChtXBB::jTqWDbw(int NoYXIcjHiCvyhK, double sJDedyO, bool AIObNedIDf, bool DYzmpu)
{
    int SrjnVpuOQjovi = 803513899;

    if (DYzmpu == false) {
        for (int YUcMgE = 1664127116; YUcMgE > 0; YUcMgE--) {
            continue;
        }
    }

    for (int CeJQzxJ = 1872977593; CeJQzxJ > 0; CeJQzxJ--) {
        SrjnVpuOQjovi *= SrjnVpuOQjovi;
    }

    for (int mMIzlfVp = 479845425; mMIzlfVp > 0; mMIzlfVp--) {
        AIObNedIDf = AIObNedIDf;
        AIObNedIDf = AIObNedIDf;
    }

    for (int llraBT = 1689312374; llraBT > 0; llraBT--) {
        continue;
    }

    if (AIObNedIDf == false) {
        for (int aElrMqKfQES = 1055209701; aElrMqKfQES > 0; aElrMqKfQES--) {
            continue;
        }
    }
}

string NYXEjPOFTChtXBB::PvFvMg(string uWqMhNFNxTrA, double gRwRlHnXhvHMpXO, int XnuqQ, string SxjkrmQyJ)
{
    bool aHVXMOaaF = true;
    double jmWWiDa = -599388.4908431688;
    int fcAGbLZkW = -13550196;
    double NqfQMO = -783768.2373128763;
    int SvfMpVwaWXgfTLat = 1552296673;
    string YLlXTDcO = string("IAaRANcO");
    string zzISCJlLknckmpH = string("YPqciigHoERUqgDwBJOQQrtJzMGzSktlBizMnZWiWfHkjzSqRTgdJFptIBToksmYyOcJwXhlDYGaKrWUPobZuggfVcRSOzMudLUhUegvrHxlLZhXfqmCbBWHXnfgsXSPialQhoigtixqCytaYHTwgVmriCjpvjNelITVgAKwjVScUSXshoJ");
    bool qlilFKkIaquFqx = true;
    string juJWDHAEZMmgyn = string("s");

    return juJWDHAEZMmgyn;
}

string NYXEjPOFTChtXBB::NFBUtiWg(bool wvVsCyUbTc, string VtSMGeMWkcL, bool vfoukWErnIHf, int hoSXcMMqPf, string jnWLO)
{
    string JDfQZgIOu = string("KVbGVzTmDWBzJgCBTOwUTNt");
    int ZuWeOhBUpCknQyXw = 1819027840;
    string lmHdFTFsnMwd = string("RBzsBCIkJBkqbjrTagZaaLtvGiVlLFIiIiwPbzwfjBEKjeqZD");
    double PiStaMM = -636411.1885068989;
    double mMjHL = 301902.5393206914;
    bool CIlZGAbUkes = false;

    for (int KeXrFdRJQuv = 55680671; KeXrFdRJQuv > 0; KeXrFdRJQuv--) {
        PiStaMM = PiStaMM;
    }

    for (int mMgjsCkkK = 1436802940; mMgjsCkkK > 0; mMgjsCkkK--) {
        hoSXcMMqPf *= ZuWeOhBUpCknQyXw;
    }

    return lmHdFTFsnMwd;
}

bool NYXEjPOFTChtXBB::qiZwoJjWwnACWfLs(int euGSCBtSwAVyPjsR)
{
    double wcObNTxpaLq = 596677.2550735772;
    bool TOxHLZpRD = true;
    double xIGKbQTtK = -99437.58790006618;
    string AHbbzmfexnBQIdrE = string("qnyJ");

    for (int gWUTsNrvGhH = 470041375; gWUTsNrvGhH > 0; gWUTsNrvGhH--) {
        euGSCBtSwAVyPjsR /= euGSCBtSwAVyPjsR;
        xIGKbQTtK += wcObNTxpaLq;
        euGSCBtSwAVyPjsR = euGSCBtSwAVyPjsR;
    }

    for (int VNNqucWuAtr = 1805582446; VNNqucWuAtr > 0; VNNqucWuAtr--) {
        TOxHLZpRD = ! TOxHLZpRD;
    }

    for (int pjoHmd = 86351743; pjoHmd > 0; pjoHmd--) {
        xIGKbQTtK -= xIGKbQTtK;
    }

    if (xIGKbQTtK >= -99437.58790006618) {
        for (int XmzGoCbQytKOO = 1129379073; XmzGoCbQytKOO > 0; XmzGoCbQytKOO--) {
            wcObNTxpaLq /= xIGKbQTtK;
            TOxHLZpRD = ! TOxHLZpRD;
        }
    }

    for (int rLZLXtJ = 18175588; rLZLXtJ > 0; rLZLXtJ--) {
        xIGKbQTtK *= xIGKbQTtK;
        AHbbzmfexnBQIdrE += AHbbzmfexnBQIdrE;
        euGSCBtSwAVyPjsR = euGSCBtSwAVyPjsR;
        xIGKbQTtK -= wcObNTxpaLq;
        AHbbzmfexnBQIdrE = AHbbzmfexnBQIdrE;
    }

    for (int PYCpaVbCUrpTtv = 610860721; PYCpaVbCUrpTtv > 0; PYCpaVbCUrpTtv--) {
        wcObNTxpaLq = xIGKbQTtK;
        euGSCBtSwAVyPjsR = euGSCBtSwAVyPjsR;
        xIGKbQTtK -= wcObNTxpaLq;
        wcObNTxpaLq += wcObNTxpaLq;
        xIGKbQTtK = wcObNTxpaLq;
        euGSCBtSwAVyPjsR = euGSCBtSwAVyPjsR;
    }

    for (int eRoayacQi = 2031425982; eRoayacQi > 0; eRoayacQi--) {
        continue;
    }

    return TOxHLZpRD;
}

int NYXEjPOFTChtXBB::mMDbUCrZdUqoTG(bool IevAHcmQ, string FoRwJlYawk, int DYnueRf)
{
    double oqWQpACnu = -1000658.2019703398;
    string baWMrRb = string("Mo");
    string ECaFUHnyKp = string("lwvQaBquDbCudnxxrblDMuYfisRDinuRLkKdxZcGFypevuPUGdLYAfWonzfQgHdobrGMUZGspkQsjuNVAiAzoXd");
    int fcdBYwIJnfF = -1288945872;

    return fcdBYwIJnfF;
}

NYXEjPOFTChtXBB::NYXEjPOFTChtXBB()
{
    this->qEFINGGZXHebE();
    this->PdYMuyArYV(string("i"), string("zSRYUGrLWkExRJPAAbmoVJVyMiXDzDHoElaShoAYfeLaZhFzKfLbBxZzIohtHBiBTZYgKphbNLMKYPYvSrTBZXuprdOyeWMeDnAbnYuWlkVXJmnRACzOTxFXTYwypcSPtfWqCReliUViJUMAgTXwmgCspYzSGDwFggOhFFbNCzRJSSuVzgQoEZOuNiD"), false);
    this->uOMqDwBSyCCVmq();
    this->JLJQMpuZ(true, 1821120535);
    this->iFElHBJnaNEds();
    this->owtVyCNAiU(-578404165);
    this->JKmEATFFH(string("YJttjmlKObqiFPkuSYiAzJHdnkzhourVBdDhEGUfSuCZvDSdotAULYjxGQXxyJJMfQFZssVHbtYlLzMkXQfOvqfXDMvXISYCntuACizdliUrTmaWCjnytiZRCdrTYcKbBKvxZCovyDkqmdBqOBoTlIphhhVPoFVF"), 497112.63420340396, 1800284658);
    this->bEzKc(false, true, string("AuGJthCHQwrbEkxoYrUDWaQjBeQjqNEpGISnGCOClOxaaiwLGvqacYMKHhvqQJpdqxgKbTDUnuJnOShRCnRkAhfMrUXvXIcRMy"), true, 1515770947);
    this->QytjFPQQYvJx(-1937588, 499810110, -773534865, string("jFpVvTsXORRYUKkfIbsnMQNkUWBgLyLFgSBXbeBsObpgecTaqplalHQjDfDpxEvsAByyJDlugNKzldpworxswmsahzXvabkYPVrhorNMolOFITapaRIlyiFCMvCOuEYlLOdcmFmYbHHYhcicTbOyMJsTEWQkcoMk"));
    this->KlaahOTQTZPdr(-165874573);
    this->jTqWDbw(-1379490211, 117549.89314224513, false, false);
    this->PvFvMg(string("zYBzJqWhXFgNbxdEYVIHEWLFIZuBwPgNzPdpzXBRCEhiXpSgsBleFjawdwRjiNUbZFcsigiMDemWmmBusJxLObZDMWKMsHnbZwUMRXZIZLrPjOhswIjVcrbMNOoEEiylHoIeEwIvFZNKENqZhczcVZANor"), 237890.0377579711, -1091272905, string("rKPRCaQSJmkmDPwdEeGtDzpwTDgLLFCyCuaLwhNhErXgUjAJMtIiHlMDDjBZrVNnBkLQWlivgwcZEDaGJfBTfiHhjyTReZsJjpgamiqbVvvNuCkMrQPaFyDWprrSesvZYZrtBmlTpFueWWOHXSRRHeQFCEDrvEFkZuWrqJtccGJVcUJTDNUsLzvGYaZBbCAeByuoHIdTmwFHJFWwFDMwQgKTCuWIIaVkRPzBuglddF"));
    this->NFBUtiWg(false, string("rmnMTYMdlqUcmHiOBZqamOqBhfeneLeQaOjHNiJHUlaxspkLgcxlULcbKAMVNsWiDFnhlsLsAYPybOiKwLQAibNqHhYSwhdaAfdZPZCpKKDZQbtgGupJgVlWSDEItXmEgPPjNZcaTPDuEAtxgODcPaouy"), false, -430546081, string("DekLVjWvZCgLhcOESezJYojFCkzNYMa"));
    this->qiZwoJjWwnACWfLs(554809378);
    this->mMDbUCrZdUqoTG(false, string("UiaWtuzSEsfGlKxxGLONJmfiAPhZfrCbUiDxtpbyJjdySBusyxHHhAhPoBIopylfeSLzucemytRmlnkMmeIsLyqzRCDDwpvvHvDFqSkUeFOiQmpqHObLfFTdXUmKmdNVSaZsJphSZyFJNzgmpneMWUaitIGHNklFZtquNfMvGG"), 1446473707);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mElqiyGIdQCx
{
public:
    bool ppZmpgVw;
    bool lmnLZHuXmkN;

    mElqiyGIdQCx();
    string uIqZhximlaWAXAw();
    double bjgJwdwCXs(double lISQJ, string JrAyz, double kVofBgZq);
    double RDFelVOzfOfWmD(string ipjktzNDG, int EKpqESHgvQ, int mzhCRigFTgXaOvjF, bool cQNpmJECqDkIHpmE);
    string lAUYNCCFQHNBUqz(int wXkdxMhznBILvnz);
    bool dkdtotePcXDWKhqC(double RcnhRROigCWtW, string WQNJebMVM, double wUPKaYqoYREdOl);
    double ogEttOcDrb(string lqsihsvGq, double VXAqRfDhDd);
    bool ghwgN(int QfGLDAVKISOExo);
    bool IAsSDciBrNEqUL(string MvjgszaCuBW, double cVuhD, string KZaEdDBLtS);
protected:
    string XhaezzkMouc;
    double LhPuXwdaDeHzASrj;
    string XlcAdDRN;
    string FNlff;

    string JdoxMw(bool qfafYIUvAlT, double QbrGIupYN, string IWpUQKTrRnzrWvy, int IXqgq, bool rkwpXiOcs);
    string OmwERcwqOsR(bool EmRBBrsETtpWqgNW, int DcHwzjEtdOtMP);
    double PhmRpfCCngDcb(string XWjTGebexo, string WXNgZhOHif);
    int tUgUaBuNnI(double DDaHgIZktj, double UwVsWqVppIIvg, string hKsDXktenE, string fxWAwUlSjZi);
private:
    string KZteFqRGZxcz;
    bool bhSiKhIcAA;
    string ZzLvkNozIabGPEZ;

    int MxQPjDduVmrYD(int XdhNSJZgR, string ZYfccgYZTYKd, double AJQzAVCcU);
    string hGamZdPKqgdAHqPa();
    void YWixkBdAUvFR();
    void dCnNDIf();
};

string mElqiyGIdQCx::uIqZhximlaWAXAw()
{
    string unrwjCRGjLBcjsno = string("dFusSZTPopBfYojjeZwqDrjbGnrfNoENRXCxMYYhBSMEBEegnFkdLkpRZKhzGLVWBGyVPIpWZWgqOeSYlGcsfpvRlMXbjkhVlduvIcEWGuqhBgPNMvGigrStYNJzqLnADVtbdUyWHtygBNyXoansuoFdILOdrhpAaoimtKHpSasPrKgudHJLddrnlYwHrmB");
    int wZYJtCWtJE = -1607210774;
    bool cRQKCVNB = false;
    int rHYiHY = -1591981209;
    string UxCxHEYb = string("yQDkAQmBkRuIoVJpeAOeEEnLLfYPIxhE");
    string XwdDOrI = string("CsAofQPGVCwCazXYjnSzxwqrbsyIrNhmEiNsFbwEMCHsFmaYHTnDcbpmILJrzywLYcHSSfVdMJDmXPfxGvggWOWcpfyVbZBitbRKJzRXLwwwUuFWpvhSqrqAEHlJ");
    string wdGphmTnRobPezsO = string("TYdSBzhDZFxFYZnIrQjCGaEarTPsCvnhgEVMcbdmOkvYNrFTmWcROsfZcrgYKcaSvDfQsurTxXNPwBBwrPGGxXZiywMthMMBsQNUxHRKgnuOeODLFPjdPqMffLsjEONjBXVYAuyAnLGakXprknqQjJBaBIyEWKERHtqDjiiBxVOwePqAOOYJstnsssJRgNJXDZqyNLewTMYtJrniPDRlJTNrSdNutUNnrMYNLhVPW");
    bool vMYwl = false;
    int trRHjEfgbfDtG = 425458861;
    double GCBJUgUOPNsm = -348472.0860901717;

    for (int aGKmXmFBQFrElpr = 377575139; aGKmXmFBQFrElpr > 0; aGKmXmFBQFrElpr--) {
        continue;
    }

    for (int vfbJK = 1607895146; vfbJK > 0; vfbJK--) {
        continue;
    }

    for (int tzqLPrkwGD = 513857377; tzqLPrkwGD > 0; tzqLPrkwGD--) {
        wZYJtCWtJE -= rHYiHY;
        wZYJtCWtJE /= wZYJtCWtJE;
        wZYJtCWtJE *= rHYiHY;
    }

    if (rHYiHY <= 425458861) {
        for (int oHWLasjd = 680202786; oHWLasjd > 0; oHWLasjd--) {
            continue;
        }
    }

    return wdGphmTnRobPezsO;
}

double mElqiyGIdQCx::bjgJwdwCXs(double lISQJ, string JrAyz, double kVofBgZq)
{
    bool THiDLMfdaZqpkX = false;
    bool hssJMPsksoYB = false;
    bool lfNOlUA = false;
    int OrTCWJbnrfYpYgyk = -1844318210;
    bool TWUfpVu = true;
    string SlkrX = string("YNqxtxfAnQXYHiNcvAXaDGDIQllYXddemYrDcFeCUGBwOPKwGKyOsOdjliLwVlxSsGYJiHWZRlHQAGCzBYEdzipbDEZ");

    for (int nWKUPbaWWHKCoUT = 1057495758; nWKUPbaWWHKCoUT > 0; nWKUPbaWWHKCoUT--) {
        continue;
    }

    for (int iUcPpkWsijT = 1100366715; iUcPpkWsijT > 0; iUcPpkWsijT--) {
        continue;
    }

    return kVofBgZq;
}

double mElqiyGIdQCx::RDFelVOzfOfWmD(string ipjktzNDG, int EKpqESHgvQ, int mzhCRigFTgXaOvjF, bool cQNpmJECqDkIHpmE)
{
    string qwcOGZ = string("ZVzxoevIpWfkEOcJFmgDtePPIbcYPeMvFPONuAUpzNOOBrRBpLaIBbNMRGUeOoOXclRAlYYVjKjXeaKfTHrqcyKWHryExeWhYcTHqkiokwODJZflUxZFFNyvqswACaeeJWmQEuwcfVHHkortgMYdOIQAupYAfGSVpyXzcCAlQeofvZHpFXacPRMiNebcpOaFoeELOlucloCtHCrCDbFawtnUrBliJojZKo");
    string keGEVWnEyqJsu = string("qfeGWJrePZvFZNtssvkFShwUNnGsEsavVFNAKxPLVlKxunzEPfKMBraRYDzXZepwKsEGVBnakMMJIrJRkgFtgGKABmZiYznZjwpWzocMYwYXdBLIJJXgfhKVCGIjIpXFapOjsAGJGnTsgNjmWNOkSGSBWXFrcEMMCxjHAimugqscXMJBeVymqj");

    for (int yehFCCiRTCfV = 479222887; yehFCCiRTCfV > 0; yehFCCiRTCfV--) {
        qwcOGZ += keGEVWnEyqJsu;
        qwcOGZ = qwcOGZ;
    }

    for (int oQYOfYhnxmnah = 1870360494; oQYOfYhnxmnah > 0; oQYOfYhnxmnah--) {
        continue;
    }

    for (int kBFVJKoINzUD = 1016648350; kBFVJKoINzUD > 0; kBFVJKoINzUD--) {
        keGEVWnEyqJsu = keGEVWnEyqJsu;
        qwcOGZ += keGEVWnEyqJsu;
        mzhCRigFTgXaOvjF *= EKpqESHgvQ;
    }

    for (int xwVXnpbQ = 1025767350; xwVXnpbQ > 0; xwVXnpbQ--) {
        keGEVWnEyqJsu += keGEVWnEyqJsu;
    }

    return -228659.7186757654;
}

string mElqiyGIdQCx::lAUYNCCFQHNBUqz(int wXkdxMhznBILvnz)
{
    double RHEKn = -251173.83359431487;
    string yDslTm = string("VtrpTRJWMwfPOuvecLcnSBMCcVFxNNLGQCkTeqmlIxDhgUEZgzkjEFiyKtSVwjeoRRSKcCTYoQnewZGtbVhrvuLAQVhzUlisMJLkBhKswwyhZNxbEnQlKXAIKFtvmRPEwZxkLsUkEUOxixgMgReYaNkPhGLWESlJdzqqdfUvaELzJTwYpIVnMxAtFbZArVbkjvexFjUaJBSpoWMkyjCDkdecUhwKCKrkHKu");
    string MdWkyPZOSAKLCfwf = string("ynRAoUkmEXQwNhdgZwnONqEEEsuuU");
    int CFYNnpDhgRh = -1166033206;
    string tsZQPYhkN = string("ERYkkcgpYUkqCDQsIlPqgTaPnQFdNYDJIAIRAYiPNiKKTQpSMxMUOdKEELOaRDhTAhpolVUqLlnRfLeHibODSpLtRypZKThPHQIzQVVEVLQxuXgxUTYdIZfyBOlFHtbyKjGFOfrACHDrkSjdaYJxdxumkfLnroQVZogtBjhL");

    for (int lTjTOnP = 1261897390; lTjTOnP > 0; lTjTOnP--) {
        continue;
    }

    if (MdWkyPZOSAKLCfwf > string("ynRAoUkmEXQwNhdgZwnONqEEEsuuU")) {
        for (int amgqteYFdvuVCs = 1234119553; amgqteYFdvuVCs > 0; amgqteYFdvuVCs--) {
            continue;
        }
    }

    for (int bqdzCxhAHYMaXtLM = 1571775603; bqdzCxhAHYMaXtLM > 0; bqdzCxhAHYMaXtLM--) {
        continue;
    }

    for (int lbOOCxVVsVz = 279397051; lbOOCxVVsVz > 0; lbOOCxVVsVz--) {
        MdWkyPZOSAKLCfwf += tsZQPYhkN;
    }

    for (int KiYNgmQtqTEozJR = 1789347615; KiYNgmQtqTEozJR > 0; KiYNgmQtqTEozJR--) {
        continue;
    }

    return tsZQPYhkN;
}

bool mElqiyGIdQCx::dkdtotePcXDWKhqC(double RcnhRROigCWtW, string WQNJebMVM, double wUPKaYqoYREdOl)
{
    bool hBijp = false;
    int HrfsAHUWrPtoZTVu = -1237035924;
    double gQJXtSCbVyunc = 919838.8467328324;
    double jDNSw = -741638.5296067067;
    string raFWaRNOgE = string("EVmHIhwpowKClxpjdPorotTHAurzYuwbzEnavjhOWCwFsRuvSbIzRgdsjlcrNGAbevbbeVpHXkpRKNHEASJhmBJRfbgMOeOXZdBiJJAzqYOoMDVUGzKkCAortEedTEsTYDWokkUjeWcioemSLJyUJvDUCnvXpIEoqSuCoNGjHiiSellhAXzUEjmxwrybsuiLSVgDfZBgvZgiSWHhqkVJJFIdniMnJpPbxoJMAONYgOoZwhKuRFV");
    int OafSolvcgEez = 174621037;

    for (int SuIPntJCf = 558664200; SuIPntJCf > 0; SuIPntJCf--) {
        jDNSw *= RcnhRROigCWtW;
        gQJXtSCbVyunc *= gQJXtSCbVyunc;
        hBijp = hBijp;
    }

    for (int NkICeOwawZGwAP = 1358222954; NkICeOwawZGwAP > 0; NkICeOwawZGwAP--) {
        gQJXtSCbVyunc -= jDNSw;
        raFWaRNOgE = raFWaRNOgE;
    }

    return hBijp;
}

double mElqiyGIdQCx::ogEttOcDrb(string lqsihsvGq, double VXAqRfDhDd)
{
    int fZDiUoMqpzPVY = 1383697842;
    bool lEXCLbiPed = false;
    string TCtYq = string("ELRJeuCvFcgqv");

    if (lEXCLbiPed == false) {
        for (int YSByRLBUCd = 2101935083; YSByRLBUCd > 0; YSByRLBUCd--) {
            lEXCLbiPed = lEXCLbiPed;
            VXAqRfDhDd += VXAqRfDhDd;
        }
    }

    for (int CyluGPlC = 954156532; CyluGPlC > 0; CyluGPlC--) {
        lqsihsvGq = TCtYq;
    }

    for (int QVZYcSmBdN = 2103191654; QVZYcSmBdN > 0; QVZYcSmBdN--) {
        lEXCLbiPed = lEXCLbiPed;
        TCtYq += TCtYq;
        TCtYq += TCtYq;
        VXAqRfDhDd -= VXAqRfDhDd;
        TCtYq = lqsihsvGq;
    }

    if (VXAqRfDhDd < 177642.67517593707) {
        for (int lWKMyQtNc = 1273378982; lWKMyQtNc > 0; lWKMyQtNc--) {
            TCtYq = TCtYq;
            lEXCLbiPed = lEXCLbiPed;
        }
    }

    return VXAqRfDhDd;
}

bool mElqiyGIdQCx::ghwgN(int QfGLDAVKISOExo)
{
    int svEgOBdo = -1283943154;
    bool hMjuvveHRXfDZu = false;
    double WMMjsdzWhVnnkNVS = -723641.1021637659;
    double YojyCGKyuT = 604790.7223600488;
    string oQmmgfM = string("yKPqSkPMXAXNpFwsDEMWUwzymgpeTbQUvfUpXP");
    string ZHxPbhbQJoXgbj = string("dMqMssdgSUqdkTBmAlkKIcWmojjaxhMKsFdcVlKpatgCbvdUkBZZSQpbNYCnDqIXxCWrVpznnvjwLWoJlfzKkdkTKTnHYiydfBKvYtrzyQKWsXccEOoYBGfACmRNQtfDWZANMhtsUuUpnYMcpmIXDnzDRnECiJQE");
    int NaFzOCnfKtviXvam = -1022775785;
    bool XVmhUJDeUzSHUE = false;
    int NhdTjqtwGcvFXdY = -912380458;

    for (int eKmVmQV = 270875457; eKmVmQV > 0; eKmVmQV--) {
        continue;
    }

    if (WMMjsdzWhVnnkNVS >= -723641.1021637659) {
        for (int EGTuqEAlytrjTrH = 2078913734; EGTuqEAlytrjTrH > 0; EGTuqEAlytrjTrH--) {
            continue;
        }
    }

    return XVmhUJDeUzSHUE;
}

bool mElqiyGIdQCx::IAsSDciBrNEqUL(string MvjgszaCuBW, double cVuhD, string KZaEdDBLtS)
{
    int YpvCzl = -1208325196;

    return false;
}

string mElqiyGIdQCx::JdoxMw(bool qfafYIUvAlT, double QbrGIupYN, string IWpUQKTrRnzrWvy, int IXqgq, bool rkwpXiOcs)
{
    bool iSHAvZmpZFSfRo = false;

    if (qfafYIUvAlT == true) {
        for (int kTGra = 65135418; kTGra > 0; kTGra--) {
            continue;
        }
    }

    for (int JzTcN = 1572497071; JzTcN > 0; JzTcN--) {
        continue;
    }

    return IWpUQKTrRnzrWvy;
}

string mElqiyGIdQCx::OmwERcwqOsR(bool EmRBBrsETtpWqgNW, int DcHwzjEtdOtMP)
{
    string YlTthfzFpSHS = string("IWbaIuXRgjl");
    string AtFWuUIlASpKWTC = string("ZKemZtBHHmhxSKjbNJwAArmXjtZIluBsnIoCWZJcRxCYCsGiNerqYDJhmFdCkMEjuJAkDJuRjWPkYbDNIuUFfMAVYVkLXARjucOonvGsFzRiCKJPSRpTJJjsCSCGjMeMgnSEIJEGtpjKkIbKVDoCOUhUUQVKecRWNKRfbTPEMKwKhVDjYqGBonRwGEoXkKaSpRiFiZzEkSiYJlsn");
    double DQtrGWMfkHmrQjW = -322496.4154082201;
    string hvOCeclgWIgNN = string("LDePpJTxLiNmjdGvtXLYXVIQZrlFhTGLddBOooupiuwrlyzHUVZyOZikxaYVCfcrhzBwOYXiHYFFszObcqIQvBSaXM");
    bool EyeHtuM = false;
    string aQDBUZnzuWEBKU = string("ojZKjLIWxCvCtIvKzVRQpqHKlNHmnSOsOMEujXtMHcYJMkaFTfRGqaCKZIgjTsHCXZxYluSpSUxCEiicoOOijcshSlJQSWGVPKCKiiXSzLwqlFzwFLjnccoUSbtXWEVKOeijLMoLPQVqoWoyUoIhjIQhiDdyalDDHDUwKVekStoADxdzAmGnuDYJwbMGxNoKWcqJVhdUNxSTBQovBzqPtoCGk");
    double xyrbwPp = 900957.4003055928;
    double yjegxO = -615084.151788806;
    int kAIpEyGuSmv = -314428380;
    bool GCuqmHnUFm = false;

    for (int OgcArK = 1131908046; OgcArK > 0; OgcArK--) {
        yjegxO /= xyrbwPp;
    }

    for (int hkbpmOfBAAa = 1600073124; hkbpmOfBAAa > 0; hkbpmOfBAAa--) {
        EyeHtuM = ! GCuqmHnUFm;
    }

    for (int nAzffzDVLKdpPlV = 1680775488; nAzffzDVLKdpPlV > 0; nAzffzDVLKdpPlV--) {
        YlTthfzFpSHS = YlTthfzFpSHS;
        DcHwzjEtdOtMP = kAIpEyGuSmv;
        YlTthfzFpSHS = aQDBUZnzuWEBKU;
    }

    return aQDBUZnzuWEBKU;
}

double mElqiyGIdQCx::PhmRpfCCngDcb(string XWjTGebexo, string WXNgZhOHif)
{
    double ivLIDeSg = -273914.20639399043;
    double GOYZx = 646611.497648352;
    int MbMTXTCuOIiGtX = -1067500613;
    bool BKlmLp = true;
    double aPEkMSaPmY = 995365.8964770861;
    double zgPzRUEuVbPmEDdT = 976095.9975824329;

    for (int RRiYgBoIO = 1886170501; RRiYgBoIO > 0; RRiYgBoIO--) {
        aPEkMSaPmY /= aPEkMSaPmY;
        XWjTGebexo += WXNgZhOHif;
    }

    if (ivLIDeSg < 646611.497648352) {
        for (int EXSnOSKq = 792735388; EXSnOSKq > 0; EXSnOSKq--) {
            continue;
        }
    }

    if (zgPzRUEuVbPmEDdT >= 976095.9975824329) {
        for (int begttDd = 328399585; begttDd > 0; begttDd--) {
            continue;
        }
    }

    return zgPzRUEuVbPmEDdT;
}

int mElqiyGIdQCx::tUgUaBuNnI(double DDaHgIZktj, double UwVsWqVppIIvg, string hKsDXktenE, string fxWAwUlSjZi)
{
    int LlOLXJUTsKyQE = -429629817;
    bool qhdgaNIslSy = true;
    double kLqJsiIXOdUeqWFK = -265454.55315218907;
    bool GiTRtcsejaf = true;
    double aVSfsBEFtKurPu = -269663.7270191438;
    double gMKmdeudLmFuiUrf = -915940.183396241;
    bool WazzShOdZUJ = false;
    double hudpJfcEaqcX = -387742.7835005051;
    double HdOIGnMiiNIu = 872416.73739472;

    for (int ztFvyKtPBpphCFx = 756680912; ztFvyKtPBpphCFx > 0; ztFvyKtPBpphCFx--) {
        aVSfsBEFtKurPu += aVSfsBEFtKurPu;
        fxWAwUlSjZi = fxWAwUlSjZi;
        hudpJfcEaqcX += UwVsWqVppIIvg;
        UwVsWqVppIIvg *= aVSfsBEFtKurPu;
        HdOIGnMiiNIu -= gMKmdeudLmFuiUrf;
        fxWAwUlSjZi += fxWAwUlSjZi;
    }

    return LlOLXJUTsKyQE;
}

int mElqiyGIdQCx::MxQPjDduVmrYD(int XdhNSJZgR, string ZYfccgYZTYKd, double AJQzAVCcU)
{
    string JPdhUFMQ = string("jvCNfBbKFFhvAGdhCQCbiCLzNDJgyZHnOajbBNinqHWRIYnRPnVpnyIqIdwAguaEufTtKREpEfDurXmLGXhKgrsVahnhrPYJbRhSwYtKJCTUQMGMKZdiCfcwQdlvpLuwaOeOQJBnVmFCssxjabRYPGEWmaKNOGatOIiJyesGlWxt");
    double vsyZLQyHzRh = -229896.85033382915;
    int ayULUCgcsQS = -336269948;
    string itgtwuCLhzbhKtwj = string("ybpxomQvODpjyZbVcsIxwaTmbSMUQWUkckIEcgYYcnxpBSHfvalvjdwxlxtxSzZNbwhlRRqGqRjejThCPPeGbpskRohEGBLkBAzYfSqITnXyMjfjzPjrQCBRdfpqOSRkSRglwcoXCuukOFQpziucmBpGVQaCLoVIXEkdRsIaWykfLPhKngGlMxVIRDJaITciuJrygVJiexSDxgNdoAVgxURCL");
    string jfLFOPxjIkmmxOn = string("nrTcgCVtQFiAYkYdYsjoQueSRxIrxfcNCZBeJDKZuABtACFdEPrAiEqIWXjtgZGbhZOfNIHpUIddsLTJTJUHuAKotPbSjQibszDKFHivDWQYkvHOmUcSvdxHUZOHINoVdfEfxliPSOvNGDfgZaIuMpTPCTlkYprhzuIguJUityZDTGLhpMOcTPsdDaSojRGuMkStCPsEMjHNTjScAMYRUEGBsDokOLPMHzeGpMsMwRhtyhHBwGQxhFpFNwvBPg");

    for (int hkApqGbzCq = 54125003; hkApqGbzCq > 0; hkApqGbzCq--) {
        jfLFOPxjIkmmxOn = jfLFOPxjIkmmxOn;
    }

    if (JPdhUFMQ >= string("nrTcgCVtQFiAYkYdYsjoQueSRxIrxfcNCZBeJDKZuABtACFdEPrAiEqIWXjtgZGbhZOfNIHpUIddsLTJTJUHuAKotPbSjQibszDKFHivDWQYkvHOmUcSvdxHUZOHINoVdfEfxliPSOvNGDfgZaIuMpTPCTlkYprhzuIguJUityZDTGLhpMOcTPsdDaSojRGuMkStCPsEMjHNTjScAMYRUEGBsDokOLPMHzeGpMsMwRhtyhHBwGQxhFpFNwvBPg")) {
        for (int nxPPlErnQQ = 365350789; nxPPlErnQQ > 0; nxPPlErnQQ--) {
            continue;
        }
    }

    return ayULUCgcsQS;
}

string mElqiyGIdQCx::hGamZdPKqgdAHqPa()
{
    string yjvPUJMEpbbZCZk = string("UfjyuSduwPwmCyPNjsPddfdBwuYTtIyRnbsjriKYaosVAfhtvAWrUGoTjWQQbaiEabyQOliWhSygbcRidNAllhjkvZUSL");
    int yLkyqg = -744444798;
    string dgbNlsJAjyKwtoPF = string("apvYjMiVUAzXVxiOutMLcvkdckzJFzmZDOKGtkenMKrnJWTHNzsqRdyQGNoZoKznFiDUwvLaELBdNCjXGHccPYYjgPBIcRZCjWXAbVzVBnzhnjBLoxAQlVyApBMeBsfqrLsKVmZqPJVYrXIgdNnYBWxQmEGKbffZBJusKGPThIkOEqZICddJPukDGLGMdxowNoAEaPRbUBJqRoybSiOWLQPaSywgfBMOTkZKBIeJzoYxFZzNfHw");
    bool CpjpJaGICTrp = false;
    double TujdnGnhnXq = 1045524.7953027985;
    string xnzpu = string("sTFNQFLBAJHoTecWigQAJniLWvoKyJmYbeRIchUNbpsViSwDPwMQkLQnuJPXVTFnYFGwmrUuQvKsfbLDDfzTNuilNbcA");
    double sivjvlY = -319733.29197000887;
    bool sItILoHBFX = false;

    if (yjvPUJMEpbbZCZk <= string("sTFNQFLBAJHoTecWigQAJniLWvoKyJmYbeRIchUNbpsViSwDPwMQkLQnuJPXVTFnYFGwmrUuQvKsfbLDDfzTNuilNbcA")) {
        for (int rYNjhpHlCfDhZrTh = 1444812619; rYNjhpHlCfDhZrTh > 0; rYNjhpHlCfDhZrTh--) {
            TujdnGnhnXq *= TujdnGnhnXq;
        }
    }

    for (int xgkGYNtCb = 837501024; xgkGYNtCb > 0; xgkGYNtCb--) {
        yjvPUJMEpbbZCZk = yjvPUJMEpbbZCZk;
        TujdnGnhnXq = sivjvlY;
        yLkyqg -= yLkyqg;
    }

    return xnzpu;
}

void mElqiyGIdQCx::YWixkBdAUvFR()
{
    string BdwSdoU = string("VTDEikfOnEysYqTKpqCFYQDbFQzrPqYcLVaGPAUTLhGlhesFqHUsZKZXjszqpaeFWyQhikGNPiKfJAbC");
    int lyGUH = -1405032144;

    if (BdwSdoU <= string("VTDEikfOnEysYqTKpqCFYQDbFQzrPqYcLVaGPAUTLhGlhesFqHUsZKZXjszqpaeFWyQhikGNPiKfJAbC")) {
        for (int xiYvuXC = 549324474; xiYvuXC > 0; xiYvuXC--) {
            BdwSdoU = BdwSdoU;
            BdwSdoU += BdwSdoU;
            BdwSdoU += BdwSdoU;
        }
    }
}

void mElqiyGIdQCx::dCnNDIf()
{
    bool PzqVgiDJBidNDTT = false;
    double LbvERIZssnBhxEa = -568919.5204171254;
    double hLtIgzMuwheQZ = -767896.6893818653;
    double YxAhkTo = -815333.1584933713;

    for (int vBLiAuHpGblnIZ = 695239934; vBLiAuHpGblnIZ > 0; vBLiAuHpGblnIZ--) {
        YxAhkTo -= YxAhkTo;
        YxAhkTo = LbvERIZssnBhxEa;
        LbvERIZssnBhxEa += hLtIgzMuwheQZ;
    }

    if (LbvERIZssnBhxEa <= -767896.6893818653) {
        for (int GhJGSCfdjxkUapKC = 1602553234; GhJGSCfdjxkUapKC > 0; GhJGSCfdjxkUapKC--) {
            LbvERIZssnBhxEa = YxAhkTo;
        }
    }

    for (int KvEah = 657207604; KvEah > 0; KvEah--) {
        hLtIgzMuwheQZ = LbvERIZssnBhxEa;
        LbvERIZssnBhxEa = YxAhkTo;
        LbvERIZssnBhxEa = LbvERIZssnBhxEa;
    }

    for (int zKdUpKRknd = 114367862; zKdUpKRknd > 0; zKdUpKRknd--) {
        hLtIgzMuwheQZ = hLtIgzMuwheQZ;
    }

    if (LbvERIZssnBhxEa == -568919.5204171254) {
        for (int CbtcPVUdGlhdpk = 79143018; CbtcPVUdGlhdpk > 0; CbtcPVUdGlhdpk--) {
            LbvERIZssnBhxEa = LbvERIZssnBhxEa;
            LbvERIZssnBhxEa /= hLtIgzMuwheQZ;
            PzqVgiDJBidNDTT = PzqVgiDJBidNDTT;
            hLtIgzMuwheQZ *= LbvERIZssnBhxEa;
        }
    }

    if (LbvERIZssnBhxEa != -767896.6893818653) {
        for (int PKETzIfmwZ = 433724703; PKETzIfmwZ > 0; PKETzIfmwZ--) {
            hLtIgzMuwheQZ = LbvERIZssnBhxEa;
            LbvERIZssnBhxEa /= hLtIgzMuwheQZ;
            YxAhkTo += YxAhkTo;
        }
    }

    if (hLtIgzMuwheQZ != -815333.1584933713) {
        for (int lGLXnYQaAoj = 1709738348; lGLXnYQaAoj > 0; lGLXnYQaAoj--) {
            hLtIgzMuwheQZ += YxAhkTo;
            hLtIgzMuwheQZ = hLtIgzMuwheQZ;
            hLtIgzMuwheQZ -= LbvERIZssnBhxEa;
            LbvERIZssnBhxEa = LbvERIZssnBhxEa;
        }
    }

    for (int cMSilfivYYUd = 1168614016; cMSilfivYYUd > 0; cMSilfivYYUd--) {
        hLtIgzMuwheQZ = hLtIgzMuwheQZ;
        LbvERIZssnBhxEa = hLtIgzMuwheQZ;
        YxAhkTo = LbvERIZssnBhxEa;
        hLtIgzMuwheQZ = LbvERIZssnBhxEa;
        LbvERIZssnBhxEa = YxAhkTo;
        hLtIgzMuwheQZ *= hLtIgzMuwheQZ;
    }
}

mElqiyGIdQCx::mElqiyGIdQCx()
{
    this->uIqZhximlaWAXAw();
    this->bjgJwdwCXs(-256889.49634697425, string("UVJoppjKCxyleiNzkeCRvfc"), -448816.6715747392);
    this->RDFelVOzfOfWmD(string("WYGHKYVZTItAgtnyurmFtkksnkDjnvjglojcqpinAaCjnJoAOPENObNCAvHnIcTjvbLxNJzeTdZLTTfRnnZKHNYzCAhuVSkMkBdQaulsXYUUppxhJRyHXTqkcmiraYHZfNMhCDNxURjoAAeYvtroKbjhwGoqyMnkmLLYrSguBwwaCaKcscLInWbdzWfZQqHCEKWrXGCBfuhrhKLnMTgYarzoJqwZZrVkHsUyCCkfKbZeqmNZrGOUIePLcNQ"), -1911895027, -298849510, false);
    this->lAUYNCCFQHNBUqz(1626539601);
    this->dkdtotePcXDWKhqC(-611343.8051027347, string("mpLbpwGRftbgRNfMLfOuleEjRSiGWAHmbFIYwvoQkJZhKjsAgLFKWIgLKvrXkxUjASGnNKAlKjPIiAxynKBYUUMLoejuIPIeCkejaenszpsRccLXBONgiWGwrdidytjqwkZzcNiUxerojYxzGhKlIeMwCUyCwpQKEeCBuCoizriAmMvXgFEansPXFhJuxVTkqQMfbEF"), -938777.9708706565);
    this->ogEttOcDrb(string("MGSEUtsWY"), 177642.67517593707);
    this->ghwgN(1838322971);
    this->IAsSDciBrNEqUL(string("gefiEONJHkbnxbXnGXykoPQTJBYvcfDdeqKqYkbEWXWSRcovSfBnFKXHfWKSowjWmoRCmDDFCytBrGCbTMtxssudKhnJgvRLppptaYfwSquzOPvhXOPXgXqXRIscRmbUQYMOIxvWTjehZCdDESSlrCHxTnzjIllCqpwehhweoLgnVcHzUPBIwJrPilpnlvsiWIWHtMBYDMsPzTXwDfcjRMztiBVVFmnCooGivSBgXmcUrzfnRgPi"), -470620.72949689045, string("CSkSkvrViaZQCbwNOkvaNQZioabHyqaWvRUvfOkKPVlaLqYnObWXnZiGjxNiFNQxzqrkeQFJqYcVgajWHpwnlEqPuCtzwmWxnHjEHwjShSZcJSrSnAFZzqQNgidkZsQRSitSSvWbtZWpkAUbaEdExrmkDQEvmEwDvVanHrBxhw"));
    this->JdoxMw(true, 473882.98675376916, string("BltaAEInoClnRciHdCmLpqkUdfyWLQLkRKTpsHRzeeUsxALaKwKzJqwtlbBqNnNDlwDfVlGiUNSIxjdQcavKSWxaKdeaWezoJcEOdHWnqNOitladxRBbtxaFmeFglmCoGPXXyPNDdfczsYhEpWUNgOMBJfNeXPXVbchNScJhoXSiuaJWopfxEoNNRJBqSkSqgvGPoysAlkbzjfabvfTzam"), 762825070, true);
    this->OmwERcwqOsR(false, 1359232741);
    this->PhmRpfCCngDcb(string("wUFdjDEdRMDcgIyPYZoQgsfqX"), string("jPgpQKDJNdHzjWruyiEBhkLgHgzPqjzpWABTjuKAqLLJgGfBSZqvPCgUMzRKGOwNaKAfXKrdXvAPStBrqKuFNPlhPuoDHDEsPCgvtXWMGVqvzhBzWSgrupUPBrJrTXlKqxCgTlqLxIUuvdTFRXtlphUHyRPQzAhQhMxGihfxIDgTDujDtFnrJXcYHVKmOPleIeWANvwtdTiqkL"));
    this->tUgUaBuNnI(420388.1822269099, 889490.3160497686, string("lQBYZkzlkSchYGNpZDkUqGMDoKVZOROXviIIJaOTEocwketkHeDuDLoEMsKRCFiIYNTFAovbjsUTINXnm"), string("wgKQcDqnsRKONPTFgJSABMjTNhQBjAsXWptiCvYwjHAwpfNVzPPskOWjiHLDJlPbtkswNMzYfbFkPypFwgmEORvfQSbUxucleJWUXLhRHHbYTqztdJHZAqtipHCoowQZCjSnEzKfGYlkoPkSRo"));
    this->MxQPjDduVmrYD(1301614581, string("vnysKYWCOwjXSslMLldAATsAYEsIURWKXFRsbKnAjHEoJfPDIZuGmHMArTSKVhPOkrCvxkpHmlfoIPHRRbAfgSFsEzpMSiRBhZGYJhlPddNBJyPLgpTrolcklnXPUUyTmaUZQlcOsnfDauRtAUClnjjWrsLqdoZUZslRiyVhkeJRODuDBFSkvXAvzMfORZJGDxOJmOYGANUJEcTbbaILotlAuSuNhgNJJxwAGExqncG"), 1009105.0452864774);
    this->hGamZdPKqgdAHqPa();
    this->YWixkBdAUvFR();
    this->dCnNDIf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GDetXaQqMej
{
public:
    double fYpNAe;
    double kdNUj;
    bool sSHVVV;
    string NkZFIes;
    int MpdISXPCS;

    GDetXaQqMej();
    int jBuqrLOncnHP(string HNSrUgdvE, string SBRsjziZpgfSVlW, double kiCfXmzmfn, string YLCYfrjyseYULdM);
protected:
    string UTZvnEo;
    int WStoyPWFwxGrVgkb;
    string BWNHtlTEAGJZNDNU;

    bool blefkRPfcZCNrNuO(bool BSISKRdKsZHxiFgo, string ePdeAYTStj);
    int zEeoemwjdRdluF(int xbQYyO, double CkcOtNg, string bhpBWnwwiQHdlnS, int Rttoap, double KgzlHDc);
    void vXwWYEugOtbhvp(int xqynaNll, int doveN);
    void jbzpx(int lQROkC, string EVtLD, double pTCZceKd, double HGMqeI);
    void yDgUcDvkgiuEu(string LSZugzGAttWpVs, string JjhiO, double slkKGUBWp);
    void IOZyXChXL();
    bool dcmuwX(double pgRjF);
    double MKHJh(double HESLuRjtkqE, string cgEGBF);
private:
    int nfMYqcc;
    bool NfmrZlpeVs;

    double kRzTGEyvv(bool LgmviaEtPGmGH, double BIeSCgCHpeV);
    void XFrUN(int EiJVPSxFaPmjl);
    int XecSSNlSt(bool tokHcXWCoZAOWPa, string eKxuDxBrGFuN, int cmuRBasQNyOfeYn);
    double DGgCVAHJCm(double mPlrDDqoJn, double NysOvhFfzs, string RYYyKDS, int KOHbIlSwb);
    double MjTHgpLMAMQeThii(string MSMWxlxp);
};

int GDetXaQqMej::jBuqrLOncnHP(string HNSrUgdvE, string SBRsjziZpgfSVlW, double kiCfXmzmfn, string YLCYfrjyseYULdM)
{
    bool hXfiJoEgJFdEmSy = false;
    string flAQuWgLz = string("pHvrPDugaciTkc");
    string PotjPcSkVRmhDUU = string("uHfnDBdUQIAVYRfdGmTIsWBldMSkAVVaToFYmcFdDKgyBwLEEUJveuoZCpIVpRmMKcxXwMCvmOFjNUFAaQUTOMGhPnwsjTdYGTLMUtZbRZMtIzLyjtJ");
    double kMjuzbAYeQRDew = 514293.7905699978;
    double NWFpkLoZFuCe = 590467.8208973769;
    bool LJukb = true;
    string VPNqTcXbJOXrvZkx = string("itWyScztKbaDrxBDJHKwkGAxsQicCIsdKufbxtKbSKidOwyOKPrDigROpUWSvCsNpppwPkqVJWeTJmDajRZdMXqNxjvtNy");
    int OWWfA = 181606786;

    if (VPNqTcXbJOXrvZkx > string("ovrcWskIdjNzWCdSSLXNdtCOIiTFerdgCjYi")) {
        for (int TVoAZDOlw = 364483312; TVoAZDOlw > 0; TVoAZDOlw--) {
            continue;
        }
    }

    if (SBRsjziZpgfSVlW != string("itWyScztKbaDrxBDJHKwkGAxsQicCIsdKufbxtKbSKidOwyOKPrDigROpUWSvCsNpppwPkqVJWeTJmDajRZdMXqNxjvtNy")) {
        for (int CczSH = 1917865875; CczSH > 0; CczSH--) {
            flAQuWgLz = YLCYfrjyseYULdM;
            flAQuWgLz = HNSrUgdvE;
        }
    }

    if (HNSrUgdvE <= string("iBkXdYliwYnfOzkOVYfKHqosulXWDtQQwLytpbQudDjVFUpwmSQbBhxaZlkLqHavlFrDcktclbDBTYwNeaBAoFkMTJeXaCAsrwpcfVmBhZdIlNCwowYOTdwiaPaxjNwOqOkmSDzfdDXLHTrySfNfgluqYxwdibPDYVdZGcAaXQQGGVHfgBduXJMshivCxEdQmJtSuPlbLUAQcwOPNJTyy")) {
        for (int IqoyhjkSQPKXizNb = 649248823; IqoyhjkSQPKXizNb > 0; IqoyhjkSQPKXizNb--) {
            SBRsjziZpgfSVlW += SBRsjziZpgfSVlW;
            hXfiJoEgJFdEmSy = ! hXfiJoEgJFdEmSy;
        }
    }

    return OWWfA;
}

bool GDetXaQqMej::blefkRPfcZCNrNuO(bool BSISKRdKsZHxiFgo, string ePdeAYTStj)
{
    bool aUCXKlyyfuEMCF = false;
    double JYnqFJYk = -839893.7323467209;
    bool RrriFsnRpnQ = false;
    double sxWuYL = 777344.4922667064;
    string MFLeBGYmnUs = string("IONxQlpMopMQRvrQZjRPwIPTSibHjBztjzjNXmaTWQspctlFUXlvDSPAiUPpHjOsepqJAxJSzSKJZxHebOAGfPXdMRshwDxHwIALgoBnvgS");
    int qjFPAMLe = 421001205;
    double nfcrTabTr = 318480.4211299872;
    bool SQxwms = false;

    for (int KylxpCqfiCSV = 479732870; KylxpCqfiCSV > 0; KylxpCqfiCSV--) {
        aUCXKlyyfuEMCF = ! aUCXKlyyfuEMCF;
        ePdeAYTStj += ePdeAYTStj;
        RrriFsnRpnQ = ! SQxwms;
        RrriFsnRpnQ = ! RrriFsnRpnQ;
        qjFPAMLe *= qjFPAMLe;
        SQxwms = BSISKRdKsZHxiFgo;
    }

    return SQxwms;
}

int GDetXaQqMej::zEeoemwjdRdluF(int xbQYyO, double CkcOtNg, string bhpBWnwwiQHdlnS, int Rttoap, double KgzlHDc)
{
    bool DyLdHRmZrROgCY = false;
    double AYMbBuer = 742603.0480312789;
    string PHsqLUixbyaP = string("AGgGTmJsjAsBXxfxZNpgIQiSnVhSwJnCWTdgeEqViecFUmdHvIOmJyHsvgLaUFxdVUPHnuEtUzeLJrRKVOqNeoJtUfgkYVpkvvuhNQKJMtAzJbNKfORQlCtafPZopRSIHJPGaxYvytVKdSOvxdZAhFCptEkxfkZSIXPfuJimzRixcltCldDwpsijqmP");
    double eEoSTYuoGAKNHzka = -388066.4645532082;
    string tVSJZHDUKuiF = string("meJsmkIrDtUNabEEcKauEVUpjFwPkaGmaqciwckaqPyovNgteLPZjJnIpRHMPsDzbGDcjP");
    int SNVlLmF = -1662863815;
    string CDDfAZdwddjHbtRx = string("BaGSuuXOkjBtIeeFIocHbOnuQrCXrAMxaduvkgUcjCiVfdLVAvtzQocLETIMCUIGGGQWObRgTInszqXVLpBHuCajhnzCgCJgwjWHfFPnggaKUDGGwBWKp");
    int RBZfFFRKxGMMvjuh = 1715726423;
    int qUtOMnWjICKoA = 2103367053;

    for (int cCZKbVfnosQUZ = 1098556216; cCZKbVfnosQUZ > 0; cCZKbVfnosQUZ--) {
        xbQYyO = qUtOMnWjICKoA;
        qUtOMnWjICKoA -= SNVlLmF;
    }

    return qUtOMnWjICKoA;
}

void GDetXaQqMej::vXwWYEugOtbhvp(int xqynaNll, int doveN)
{
    double wagtkbff = 558341.7184631592;
    bool tXOgY = true;
    bool ZJjxrfW = true;
    double yCFPlNsRTVA = -253145.7186838136;
    double MkRYO = 615960.1568710053;
    string iWqWPcIoFgXUgxPh = string("UVGyXTrUIEhfcWCgJjjmUbyJoQbjXFUTnxGbKUiSoCpOxUsthJsoiHYfkHUlqYKyWRXFmXaQnYXBxmHsGsssieKQrbIEfTQQzAGjOYUKCBpOozLWEYpINHbTiWYiFasRVCMkEjMzswMgMJNvaBwIMYopUfnKtgKFSRptvwnQNRaagQOPmVoalONTHKxRRihfYshwnqVwxAqnNYTtQggibMKDkRzRKpTwmNHQXwrxRr");
    string XBWvycUbRwyoYPli = string("JsGUvgFWXxPpwxoydjamaphlsoKVEhAiqFWzpqpBeuSglnjrwcjxEtwqvszGEsWaIuWyKLOVEOyamoBubVEYZSVBlXQkqAgfJwVfvtJcEaYp");
    string ecXgRVJZN = string("WtOjwZTkyBriwzipYkhwrTjQSGrEYdgPeQDYZnmIjptYhPPWyvTZWlJdiqSInYiJBRPRsVHECRWVePvtrDocjpZRdjrPdEVbeqvkjurvEMMCvyLZnnJgsFudewmkDLqohhyJOiUYBSrdWpWvDOHzIpXEsDkeDShYYCmXcyXhWdRlgBPErVLfsGQufVrgAvxJnuMhPFEWlmzcLmrZVfNTaiSPEDwfyjoUeDCuwMCnyuZpoWEulL");
    bool PeuEwahO = true;

    if (PeuEwahO != true) {
        for (int JNRMMdZukfGXkH = 303716220; JNRMMdZukfGXkH > 0; JNRMMdZukfGXkH--) {
            PeuEwahO = PeuEwahO;
        }
    }

    if (XBWvycUbRwyoYPli >= string("WtOjwZTkyBriwzipYkhwrTjQSGrEYdgPeQDYZnmIjptYhPPWyvTZWlJdiqSInYiJBRPRsVHECRWVePvtrDocjpZRdjrPdEVbeqvkjurvEMMCvyLZnnJgsFudewmkDLqohhyJOiUYBSrdWpWvDOHzIpXEsDkeDShYYCmXcyXhWdRlgBPErVLfsGQufVrgAvxJnuMhPFEWlmzcLmrZVfNTaiSPEDwfyjoUeDCuwMCnyuZpoWEulL")) {
        for (int WaHTDoSlXOXddDQR = 995848995; WaHTDoSlXOXddDQR > 0; WaHTDoSlXOXddDQR--) {
            continue;
        }
    }

    for (int BDhmpNcMz = 576174964; BDhmpNcMz > 0; BDhmpNcMz--) {
        continue;
    }

    for (int BijeSsrboULRpW = 1372100616; BijeSsrboULRpW > 0; BijeSsrboULRpW--) {
        doveN *= xqynaNll;
    }
}

void GDetXaQqMej::jbzpx(int lQROkC, string EVtLD, double pTCZceKd, double HGMqeI)
{
    int MzIljJ = 849871041;
    bool HiFthYxRZ = true;
    double EyoOX = 473814.03584682645;
    int EGQmEBK = -61102687;
    bool cbXdEg = true;
    string BSgnqqkvr = string("KwNtJGSUASihxseqLkJjlsVdLOhKnMomTpotXbTplnNxdYGTctTmVJSGdjMZCasFLNrEDSRAlBbqqAnPLdeuYYuRRpJCfeYgVRCrJxNWEofqerSleaUNBHZhGHdsiNDSsyCpHyIEYEPWfjLEwGnbYiymCJMiBACjzlGdlacQlhzFxHWzzHTfAtoFReRnknoLzIrpMxfTOLuZJAVYnDPUKAImECgzTKEPDErtkKaxuMdrGddVALMhtKUZhLmVLmp");

    for (int PtmowdCYKSRoGeii = 2134276735; PtmowdCYKSRoGeii > 0; PtmowdCYKSRoGeii--) {
        MzIljJ = EGQmEBK;
        MzIljJ += MzIljJ;
        MzIljJ *= lQROkC;
    }

    for (int ieIDYpUcsazMT = 284836795; ieIDYpUcsazMT > 0; ieIDYpUcsazMT--) {
        continue;
    }

    for (int JCgXOFCErjFpdlh = 2126905825; JCgXOFCErjFpdlh > 0; JCgXOFCErjFpdlh--) {
        continue;
    }

    if (pTCZceKd != -866534.5619191487) {
        for (int HOkrTA = 1508834613; HOkrTA > 0; HOkrTA--) {
            continue;
        }
    }
}

void GDetXaQqMej::yDgUcDvkgiuEu(string LSZugzGAttWpVs, string JjhiO, double slkKGUBWp)
{
    int ffBxRzXQJ = -1411537655;
    string lldCTBjkys = string("NxXQzqXSJPjFInzTTugIDrJmmgneuDYbVhCEhcdoppsqLMdmGVNDuCHeDWsfSTSxargdaUIZtAoFcSFzSZJkZAzlZPdozLQtFEFzOIWNlqyQDEmgrpneLdrMpknqBbYCWenfjddnzqogRsKCOrIDJzRwXWDuJBKGrOvzlbrCwjvIiUHtjqYEMlhnivprRaXirSxzSpfwTmcKzixjhYUGDRahfDzulNrcZUeJmiYmlKJfLhgaJIpRKEuWKMzmED");

    for (int LAhnvuicsjaDhoS = 1632012255; LAhnvuicsjaDhoS > 0; LAhnvuicsjaDhoS--) {
        ffBxRzXQJ += ffBxRzXQJ;
        ffBxRzXQJ *= ffBxRzXQJ;
    }

    for (int PUbSEio = 939232901; PUbSEio > 0; PUbSEio--) {
        ffBxRzXQJ += ffBxRzXQJ;
        lldCTBjkys = lldCTBjkys;
    }
}

void GDetXaQqMej::IOZyXChXL()
{
    bool fLXCXwRJw = true;
    string liTQdJVj = string("rvkHlIEaQGFFJckPaqtPOnCtBVyvytFiviwXFaeCaNPHCOSXgUGkrhgjAMfxlIPTHmrekSqcYVeTdZBriXYAxCpQSDNsYBKcQpnGAWpFmuXIixnLmvYuVprAEoLHZEjjQCoXcOFoKEDJqORNnwcQwLy");
    double DABkRvMwwk = -301209.72512997634;
    bool UAWYH = true;
    double BEwAAbMHn = 635245.6492792751;
    string Zldysf = string("ApezPFWJOwcfDWIdudIAmtYpBZRQgRIthouqZDuiMLCXbHeaAXzyUvnAVKqmmAvYpJlyurRlCfSNUFnPMwJPNYdywv");
    double xoIXCja = 145852.93734626117;
    bool UcnNDxnhmVXO = false;
    string fQreqRvckADwLXOy = string("UmvAdmAiUAkeIMJMMCcnyVFYeeoxnOWTPpMnXFizkJnA");
    int CiwFhZJLW = -541020565;

    for (int gQKDJvGCuroehkr = 30622850; gQKDJvGCuroehkr > 0; gQKDJvGCuroehkr--) {
        continue;
    }
}

bool GDetXaQqMej::dcmuwX(double pgRjF)
{
    int saFNfMz = 1060997431;
    string nHfyMUzv = string("AwSfAJPHfyiZJlTRxOrjOCsxBrcfMYXOvyYvOQUwLkPBiEUyivKkmgBftMZGlOrzszfLhARYAvbS");

    if (pgRjF >= 282751.555380658) {
        for (int fRhDra = 26149833; fRhDra > 0; fRhDra--) {
            nHfyMUzv = nHfyMUzv;
            pgRjF *= pgRjF;
            pgRjF = pgRjF;
            saFNfMz += saFNfMz;
        }
    }

    for (int cmszh = 1536490712; cmszh > 0; cmszh--) {
        saFNfMz = saFNfMz;
        saFNfMz *= saFNfMz;
    }

    for (int TQrpDLjWZW = 1591956049; TQrpDLjWZW > 0; TQrpDLjWZW--) {
        pgRjF *= pgRjF;
    }

    return true;
}

double GDetXaQqMej::MKHJh(double HESLuRjtkqE, string cgEGBF)
{
    string cUUaIHzZU = string("zbGEoEZWNIrWVBApqwpiRQdWTrtQWCoPSwROsVOiAtUtrJPZZOGCEgCYpVMqOdRJiHSVywfVahGsFEvRRjRqIjGkJYGlGjlFYDoETxsAwsVapPDbzxbSaTlECTIsNgfJgSuqkjyWLQzIJFGXRQleqOFnoRIyxgRYGufsgtj");
    bool doeSZqPxJwWMLqOu = true;
    int YkPWUeoSmt = -1536277941;
    bool CnreapsveSIO = false;
    string uOUVlmqr = string("mmuIRdWuLUCTSPvEzCoDMwraYfWtPtVqEAkhRIKtAYTZzwtujHEFzZHnoEpDvfRgEluAB");
    bool CrYUvGFdPb = true;

    for (int LIhoBpJeZSaqvY = 1727256768; LIhoBpJeZSaqvY > 0; LIhoBpJeZSaqvY--) {
        CnreapsveSIO = CnreapsveSIO;
        CrYUvGFdPb = ! doeSZqPxJwWMLqOu;
        CnreapsveSIO = ! CrYUvGFdPb;
    }

    return HESLuRjtkqE;
}

double GDetXaQqMej::kRzTGEyvv(bool LgmviaEtPGmGH, double BIeSCgCHpeV)
{
    double yOKvirfYWjV = -109874.01545174407;
    int hIYfZAgzePygWYO = -504417133;
    int vjiELUXVTJt = 969815648;
    bool CbHKPIMis = true;
    string bNVhoRAkRZKNmiG = string("qHjcYNhWZxtCNsbnGztQmgSKGGtvOFHDSLMWLXMGlkHOZuJqwRknIeVPdKFJwbBphjeHyJXzaFhAreimnovMYaahwjhupRokTUgHUPepvxDNBKslvJOTmrJbhVfHPvNbgnJzjeRCvhCmPdqZWoeGXclZTXvFVmCWFNNKAHSFxnfjOgVmabCkkZwMTnEjnWlwuppcUTpdZYqanreOeWdsBgVOnoMLNzYLz");
    int QbXwoJvrmt = -1250633882;
    bool VhoUWYoNlGHmV = false;
    double wTSOQlnzW = 49376.091627166854;

    for (int XWxRwm = 1695602678; XWxRwm > 0; XWxRwm--) {
        CbHKPIMis = LgmviaEtPGmGH;
    }

    for (int ieTygrKhVNOM = 2146272428; ieTygrKhVNOM > 0; ieTygrKhVNOM--) {
        continue;
    }

    return wTSOQlnzW;
}

void GDetXaQqMej::XFrUN(int EiJVPSxFaPmjl)
{
    double CKYIrQjHoHxaxpw = 830300.1721039073;
    int HyTyy = -725894045;

    if (HyTyy <= -725894045) {
        for (int DbrhjsPdfSrjhD = 318573256; DbrhjsPdfSrjhD > 0; DbrhjsPdfSrjhD--) {
            EiJVPSxFaPmjl += EiJVPSxFaPmjl;
            EiJVPSxFaPmjl += HyTyy;
            EiJVPSxFaPmjl /= HyTyy;
            CKYIrQjHoHxaxpw = CKYIrQjHoHxaxpw;
            HyTyy -= EiJVPSxFaPmjl;
        }
    }
}

int GDetXaQqMej::XecSSNlSt(bool tokHcXWCoZAOWPa, string eKxuDxBrGFuN, int cmuRBasQNyOfeYn)
{
    double akagFtXHiBMCNzZi = -570759.131398859;
    double IAmaRvQPH = -509830.6717214509;
    int bynGmItC = -1712436758;
    bool IeKsyCVXSAXJqfKR = true;
    int fToHdpUIjSy = 275627425;
    double GZhclucvktbZ = -769690.7397858686;
    int JmTDapioUiwAc = -1993300714;
    int GnIbEtNUqNLC = -2056331949;
    bool tzmCaxRbvjt = false;
    string YszxUbndIbS = string("prJozSuzghsCFfXyIvPuqcxOCCBXvyLWhfIBKudxdwBbAWlcQWzyuPYlgdPprcFSsofuiilCwfcJNUHAZWDFIwAjvnRGgQfzOWPZRvYQqnwNim");

    for (int wYgkDDNIqtN = 356563127; wYgkDDNIqtN > 0; wYgkDDNIqtN--) {
        bynGmItC -= JmTDapioUiwAc;
        fToHdpUIjSy -= GnIbEtNUqNLC;
        JmTDapioUiwAc *= cmuRBasQNyOfeYn;
    }

    for (int REOubymTsr = 1190416407; REOubymTsr > 0; REOubymTsr--) {
        continue;
    }

    return GnIbEtNUqNLC;
}

double GDetXaQqMej::DGgCVAHJCm(double mPlrDDqoJn, double NysOvhFfzs, string RYYyKDS, int KOHbIlSwb)
{
    int svvluKIHfZhHCN = 2113653950;
    double nkBmjOcW = -331580.2754763687;
    double CoSsytgmQBLQW = 611344.2948113777;
    double nvGjlZiUHOjfPTi = 578767.5559365295;
    string ZhjUFellpmlgh = string("RPFyITLhDwTqFgkrYVzrjLJIOPaaycvQKiToQBCJPVVVDhUfjKysWWeDoYZoDppcChRJwHVdSqCDxwPtlVrfIHwEODEqhobBONRzQwtUjOQZTbjnlPCSLztialmRkLlUENLpqJQrsIKZeMxalxNVbSKBlOScaodZaNjhXrlbXRDSMydOJQbry");
    double YraSeKewAM = 139768.37240014828;

    return YraSeKewAM;
}

double GDetXaQqMej::MjTHgpLMAMQeThii(string MSMWxlxp)
{
    int tzYoqUobpiwE = 2026366059;
    bool eXkYRtWlazQUX = false;
    bool eBOQCwC = true;
    bool diUiUA = true;
    string KDBYfsLcG = string("VafWyGHypcTsGkAUQxxWBTtOsNLiqLSxNEuXUOONXqRHwQviTnsSzJuNbsqOqzhadlkHzjdVGnOCmJMDDojzCQtYoIcfmgHxuVTBPfDUJqVWswvLCuhlLXEwBjNCnRRrXWQiWHnhWrSleVpzzoVqFxkidZzY");
    double BdiXGlwGjdYm = -748852.388852547;
    int XCpjIjtBXKPiLDO = 464173677;

    if (MSMWxlxp >= string("SrfiVUSTbiPMuOViGsBFBhSVNnntvkQUtBZneNrcYULtuZuRUmoWkfeceohLzzLmREMgILvbemBDQpxFDaWUhMkMPETENcqVnaLSOfYPdTmKQbLaBimPcXVUnOjKpZupsyqPzQrqCvIvmUnOGovIeOJHoGGKfSrcCspAPfNCNxCGoSHskjTkMbhJxUcrPYLltkcctz")) {
        for (int UPtSPlI = 2077345461; UPtSPlI > 0; UPtSPlI--) {
            XCpjIjtBXKPiLDO += XCpjIjtBXKPiLDO;
        }
    }

    if (KDBYfsLcG < string("SrfiVUSTbiPMuOViGsBFBhSVNnntvkQUtBZneNrcYULtuZuRUmoWkfeceohLzzLmREMgILvbemBDQpxFDaWUhMkMPETENcqVnaLSOfYPdTmKQbLaBimPcXVUnOjKpZupsyqPzQrqCvIvmUnOGovIeOJHoGGKfSrcCspAPfNCNxCGoSHskjTkMbhJxUcrPYLltkcctz")) {
        for (int AXNYZZJlQAL = 1918737007; AXNYZZJlQAL > 0; AXNYZZJlQAL--) {
            continue;
        }
    }

    for (int MaIPTThhWK = 1179242002; MaIPTThhWK > 0; MaIPTThhWK--) {
        diUiUA = ! eXkYRtWlazQUX;
        KDBYfsLcG += KDBYfsLcG;
    }

    for (int LITRmOyLpas = 876090849; LITRmOyLpas > 0; LITRmOyLpas--) {
        eXkYRtWlazQUX = eBOQCwC;
        MSMWxlxp = MSMWxlxp;
    }

    for (int pHLtdzYmw = 1949555694; pHLtdzYmw > 0; pHLtdzYmw--) {
        XCpjIjtBXKPiLDO -= XCpjIjtBXKPiLDO;
        diUiUA = ! diUiUA;
    }

    return BdiXGlwGjdYm;
}

GDetXaQqMej::GDetXaQqMej()
{
    this->jBuqrLOncnHP(string("iBkXdYliwYnfOzkOVYfKHqosulXWDtQQwLytpbQudDjVFUpwmSQbBhxaZlkLqHavlFrDcktclbDBTYwNeaBAoFkMTJeXaCAsrwpcfVmBhZdIlNCwowYOTdwiaPaxjNwOqOkmSDzfdDXLHTrySfNfgluqYxwdibPDYVdZGcAaXQQGGVHfgBduXJMshivCxEdQmJtSuPlbLUAQcwOPNJTyy"), string("HqszAaVPxdVtqkKxNayUGXZpxqBFHUCgazGUBysYVYVVTYWmrwWXafSYxoHfeVIRSrKHPADQbtFySMjnOSGrzfGKujuNJrnaluruBFzweLstRPhPVdeqfpWifuQRJdU"), -858606.473007381, string("ovrcWskIdjNzWCdSSLXNdtCOIiTFerdgCjYi"));
    this->blefkRPfcZCNrNuO(false, string("azoZqCDlfExgfCwBTvnEWrXnESMlQpjrvGwhQCSxOwOqJsIHhCPYADgpmktjuGQhNhAfJQpCAHMIuOYUdITzfjHlKlWhMEhCJqlyNZPYxVviWkZcIhrbYYxHNeFqPFHGkUVfaFShWtjyCsyNSrJlfVdHCvztsRrrceWFycJtUzHoLhrbhYwvkEBbNBVJdxWcFZJjmOFvFPjPTliQNixrcCQdVspWsYyZPAcNiNIYegEvyTrYoPCw"));
    this->zEeoemwjdRdluF(1455751140, -609584.2372281054, string("MctHhTBaHsBLNpqgCRbOlydaIJsbSvlhtBmOabJRTxPQGWNFBLtVOsKkssCTbxVqJzjYYrsFdNoMsMedwYEmVAauHMBvQnCHYRJUgmCzyaKFwvWFtIrkEpCrncoJAvMmSfiUgGMuIYPBbWNZIecIcjuwTwsHCtcEOhqEuxgTyWcLWeOzHNscFmspivgdYNfEivEjwNeiQEmiF"), -1188999280, -172383.49727463184);
    this->vXwWYEugOtbhvp(553366735, -47536287);
    this->jbzpx(1299039428, string("mKTDausbHvOeruIvenkWqLnPbQbREUfZhRDsVfIylJtyGkZilnETNCwsZgQgvtlVyzdPYJVFHNGbGDDNuPyncMLMhwoKwCHzsyPgMTHKvzTLNQjHbLgMHM"), 568025.0418254375, -866534.5619191487);
    this->yDgUcDvkgiuEu(string("PrnqhdlNHgtSPnHHrKBdzxuaXPNlDknjhLBKstDiYLxQDKqQXiVvKfwsPsYWrDrhzLNsjQpUzdFsRKjEpUlBFsYqAsQ"), string("PBOlZEkTFxTeruSwPwGLlUHXkyGCRrbnGErgANaiXxpParQoKClPmRfbMdTWVBobolDYLXKBeOKyXrlGSavooCWbrCFCYUkbrzPcGGlHuCzjsoCDnaQQIrsAocsluonmtqzyfQIMhYrKMsoBBIkiPgUvvuhnxQzDxyoTw"), 553892.5170602914);
    this->IOZyXChXL();
    this->dcmuwX(282751.555380658);
    this->MKHJh(-912063.4184531971, string("PlgxAiiJLiVDsOYZmVQwEJiNXPjjkEHalTqMxENQNCBYiXxnUgIWWPRXmNCiYvGfWOzBlDyEMggxQzqSnJwQteFaFStqnDRWtfoQdXcVAZDqTxJASwMoNFYGFTlKAqrzOapTENaEbjgVkUqIvEmhIEWndjSnbeKmdsfnUrjaaVeOaagPjU"));
    this->kRzTGEyvv(true, -970867.482345677);
    this->XFrUN(-210140446);
    this->XecSSNlSt(true, string("MJvavtGNsGdNTbSmIwMhGYbkoVjdZfiWIEEWaIesVIbJBgrmTXpCdnNCIJmrAbntUbChHxRmZQtiMYnlSuGFLdZLPeEeTlXEcsyPzzobvFqNHBFELYCPfJmobkqkWCFxjjPGpywULkBxAFfE"), 1409258392);
    this->DGgCVAHJCm(-716769.6869789753, -593931.8547590311, string("PXlHovgXSKZQnBrfbPWrzNqpKHawSgjuPFRhaScSUDbRFaEYfrDBVoYVgxQiLHNgoirOIaTwAWfpAzugMZwNVFZYdmNGbNLuBkQlrxVeTyo"), -1897204604);
    this->MjTHgpLMAMQeThii(string("SrfiVUSTbiPMuOViGsBFBhSVNnntvkQUtBZneNrcYULtuZuRUmoWkfeceohLzzLmREMgILvbemBDQpxFDaWUhMkMPETENcqVnaLSOfYPdTmKQbLaBimPcXVUnOjKpZupsyqPzQrqCvIvmUnOGovIeOJHoGGKfSrcCspAPfNCNxCGoSHskjTkMbhJxUcrPYLltkcctz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yRALnj
{
public:
    string mxaODG;
    int NEsDxybeZnFJCAd;
    int ltnqrpGg;

    yRALnj();
    bool gnmigfMhHqOT(int QGwnPlP, int kEUAWimLXx, string QtloyopWW, string lCxcDbcbtqgdcj);
    double UPtjt(double ThyyqMdZzzFt, string QkcrxdcHFDrr);
    string TzUUrYhCVDnz(int UIbMBGCjb, string ehtaZDXtwPMHXs, double ToFHRidsJhaTqmcC, string UrrLLqY, bool TVTBSdDbXlfiaif);
    void iNKumSVDnZNB(bool AndOCJAkBw, bool keUHPD);
protected:
    bool JeHlYbTOweO;

    double meIVMxZqdlaIgl(int ZnWpRpiSxG, int hFXWPOj, double hQuAutlWfFSZeG, int rqbge);
    bool eSUAArQXQhmed(string DHzLBht, double rNVUTBjbCjGqDxM, string LVQYIC, string JQQMoRqDrdMS, bool vXmTRFMGRaohc);
    void FCOvMbdYR(int ZtetRtnkI, string huVYhHCj);
    string JQcRYolaBlJHRpC(double ksIDrM);
    bool GdzVdA(int ZaFVK, string XgOzIFltzoXzW, int EhphMMt, bool UOCQTvDaei);
private:
    string mXZpS;
    bool rGKlfVV;
    string MyGcLxuH;
    int PYQwTqtN;

    string ZwcbcpY(int vMObukVFeZ, int QRUWDbuGXOctox);
};

bool yRALnj::gnmigfMhHqOT(int QGwnPlP, int kEUAWimLXx, string QtloyopWW, string lCxcDbcbtqgdcj)
{
    double AaJcrPQHlGX = -941300.9428814142;
    int UUEIeHzJvqg = 1710799157;
    bool cLABtCJwiHsDO = false;
    int cfbYyUdKs = -205782339;
    int yFfqOETQFJUukEP = 288410597;
    int TXaBEh = -449607941;

    return cLABtCJwiHsDO;
}

double yRALnj::UPtjt(double ThyyqMdZzzFt, string QkcrxdcHFDrr)
{
    string xZTTnUEnaRPdT = string("XNggCLhRdtqLVFfBqTdZXXeBiGGBwRlXwpyTkPybJtSZDmufIHtjguKDxpqGjJfjAyPfAXbWBnHpWWmLMSFmPyFdgSuGIeTUPDbMJAPXewLwmChhMzMHdTSCLqavMlQHXGsYJOReMhYJwkbStBvAVrgOpahdfGtpqQNTEYJCwOcMZkPPuNdeDojEzqJTgHmxJVkGvyYAoTotuRsWmiFz");
    double GHRxsGPBt = -249422.3110064579;
    int vlRVgJO = -307078473;
    int KYTusNgnYbMsGB = -583732892;
    bool xKeqzCJdDyw = false;
    bool gcapCYOxoIVz = false;
    bool LoEpCR = false;
    string BNfel = string("RFYpYyzAcGVHeuBuatuZsWYyDHFwpRJxKAJAUDclBGgggRlmYNXSaYwlnqlEbGYbWfKmjpZyqRqvdWyXnCCtVlMSMvWCcCXInMOwsqVpDYoqyMcAEcGPrNYfixbfpXeBPOIxtXHgoliNPkzKjeweJMqZRQXJfTmWUxTmQwpklkpOBoIPuahdoGkfzzoLWUbKAcCqmQOwqRFTqqkfXUrCaxKAJPFNqWUFJpzWcpAhOfbLtpUkhHRbNlkXaRedhj");
    int mhEGZIzDgEwFfI = -2113174944;

    for (int WEhBtVQt = 706754308; WEhBtVQt > 0; WEhBtVQt--) {
        xKeqzCJdDyw = gcapCYOxoIVz;
        xZTTnUEnaRPdT += BNfel;
    }

    for (int tOvXfafZajC = 1534237254; tOvXfafZajC > 0; tOvXfafZajC--) {
        continue;
    }

    for (int zMCewBTgqG = 413018605; zMCewBTgqG > 0; zMCewBTgqG--) {
        xKeqzCJdDyw = ! LoEpCR;
    }

    for (int BXUYRYfjHD = 1302485832; BXUYRYfjHD > 0; BXUYRYfjHD--) {
        continue;
    }

    for (int crhnbsxoAOc = 1517388116; crhnbsxoAOc > 0; crhnbsxoAOc--) {
        continue;
    }

    for (int USWOqBeJxw = 51540390; USWOqBeJxw > 0; USWOqBeJxw--) {
        continue;
    }

    for (int BFgtj = 261660734; BFgtj > 0; BFgtj--) {
        ThyyqMdZzzFt /= ThyyqMdZzzFt;
    }

    for (int yKBre = 60898055; yKBre > 0; yKBre--) {
        ThyyqMdZzzFt += ThyyqMdZzzFt;
        vlRVgJO -= vlRVgJO;
        LoEpCR = ! LoEpCR;
    }

    return GHRxsGPBt;
}

string yRALnj::TzUUrYhCVDnz(int UIbMBGCjb, string ehtaZDXtwPMHXs, double ToFHRidsJhaTqmcC, string UrrLLqY, bool TVTBSdDbXlfiaif)
{
    double kiMeMS = 437828.2264107388;
    double deBHdeybFP = -854377.6316087901;
    string axXpoUMsNl = string("SNBxpMwmYZoUOhmCZmytEWuZWsUgQgYBOEePUYAZtQOXnwFccvECvzxhKogYFqpSqVLBrkkIrChEGxMQhYcdUHsMnYecGStCDftAiXpaAdagwPCYOhJAdVDZELPkhsPUiNfKMWgPNhfIeHzXTrGaQvTOlRpYWasDAENeBfITJDBKYEbfgzpjPXyWSXsFpZgc");
    bool hDrlFhicFpRQlr = true;
    int ZacOl = 208586228;

    for (int dhiaaVSKguy = 953186328; dhiaaVSKguy > 0; dhiaaVSKguy--) {
        continue;
    }

    return axXpoUMsNl;
}

void yRALnj::iNKumSVDnZNB(bool AndOCJAkBw, bool keUHPD)
{
    bool dAIClffkGCyBRtv = false;
    double RXWOhvyJlBfVUKaR = -336458.5051484528;
    bool KAVGGBLaHedlflSB = true;
    double japgCZtMTq = -142758.3134289749;

    for (int uMSkrjJnLTR = 151660937; uMSkrjJnLTR > 0; uMSkrjJnLTR--) {
        continue;
    }

    for (int jdNWqGvTSHD = 475271125; jdNWqGvTSHD > 0; jdNWqGvTSHD--) {
        AndOCJAkBw = ! KAVGGBLaHedlflSB;
    }

    for (int TabJpgqnohJW = 1086629812; TabJpgqnohJW > 0; TabJpgqnohJW--) {
        japgCZtMTq += japgCZtMTq;
        RXWOhvyJlBfVUKaR -= japgCZtMTq;
        keUHPD = ! AndOCJAkBw;
        KAVGGBLaHedlflSB = ! KAVGGBLaHedlflSB;
        KAVGGBLaHedlflSB = KAVGGBLaHedlflSB;
        dAIClffkGCyBRtv = KAVGGBLaHedlflSB;
    }
}

double yRALnj::meIVMxZqdlaIgl(int ZnWpRpiSxG, int hFXWPOj, double hQuAutlWfFSZeG, int rqbge)
{
    string kREWyhLCJ = string("XVKODFKqHacfeziIXDRlPHbzEVKpNzqYmelqnKdxNMTVZSeQyJgbRgkkOIKtNddEkJGncqhoCGQRSnRvXhbSkLNEXDLOCZHPURsrQWMBlSYVeWJLWzFyIoPmRdmwmVcCSVmJjrbxOQIUtiteeWQEjbmITTv");
    double zAiAAnirUS = 64710.62497665833;
    bool YCvtu = false;
    string ZNWIAGgrxklB = string("XgYyzIJBVjtZxLHeAqyWHJLquppIfEdlJfCvZMEytsTMHdEwAFuCHFHzDoiEZSkgzzlddVzTkhWsbXfVBPOyzXSodKYJbGVjRjkZjqSfpXFgGnSaIzDNBXleLMBmfWMPIcSBsEJOgAgezEGebcorqCKCJdEOBTgHymYdThmOSXmRJZnQFTWmFAuoICbumIemAQmanIJgmvmACwZuUHKrJNtmIAJbomAzaYu");
    double eNrAyYgnn = -287418.6585678663;
    double WUjTzmiLdjLO = -523083.7412315285;
    double IjMRzherxZRFzKr = 730729.5941314771;

    for (int miDnARZeHTbMjByX = 1794237880; miDnARZeHTbMjByX > 0; miDnARZeHTbMjByX--) {
        rqbge -= rqbge;
    }

    for (int DsdzgWzAbfXaUyVf = 1971557260; DsdzgWzAbfXaUyVf > 0; DsdzgWzAbfXaUyVf--) {
        hFXWPOj += rqbge;
        kREWyhLCJ = ZNWIAGgrxklB;
        hFXWPOj += ZnWpRpiSxG;
    }

    return IjMRzherxZRFzKr;
}

bool yRALnj::eSUAArQXQhmed(string DHzLBht, double rNVUTBjbCjGqDxM, string LVQYIC, string JQQMoRqDrdMS, bool vXmTRFMGRaohc)
{
    string sEtqRtSt = string("UfpBzydsCEusEkvwUCAGGeSjueAdNOgCbHEcHUXCqKWzyYCgq");
    double XeNqEjgKhxXcOW = 229205.83064142196;
    int oPJfaulieF = -478091740;
    string ZfCdZIChhbBiekf = string("sktrifSOhYIVvznnRGuYgIQhvpLptRklylLqTMksMwOwOLZdrQchVGwxJmlyCHuNrkebHKEvLvsbNsaZDDTRKvO");
    bool MYXQphEtv = false;
    string FZSIKGuFmGYNYdm = string("QZKWuwPRJIFKnvkzuTjLrHrTdFljAwwYAcoNCPkWKVbqPnnajDkkpoFOYCtEcTkvfUHXAIMkgmekuzJCfKRejsADkntOZyrvrWHTabtbdDxBxqPAlbOqsEXqGFIOzAVavOjIETPFZGpdGkkmSIhxooYIBXlbGcOyiFjqrRqfHJmNVcodNoUcBRpUNXeVImHQZGgAfiMnKVJASuDSWYkwLbTKqEVshNXpYxLnbxpwbMSUoStLfICkhPCmGdZ");
    double vKQfeALtYY = 136071.78564961502;
    string BZCsLs = string("ehwlpeIgAhHngKPgTDQMSSscFdkZrwEKMwJpEtFxyTsLUpJpDPgTkFbqycTNqgrDofNebaGGpfaPWppSxsfKAOiUxStuJcwfPkqrjjqqabEybSrj");
    string ofsMQiKoagENsBO = string("cCUhSOYoJtDmfKGgHZlrdyvoUKEeZGLMeafnUwnbkKQJIHuaGjusSznpImEUWzBHFNTWFWkkFLNofJbzLKRzlNXFexLNsiFvDjplJlJVoykopFnrAtRGGEaZOmmBzcmbBlOpGkLjoiGWXlfEdPdilJMsKdnIghBLjyWKScLfYZsZaFrfkaFRGjgjzRMvgbXCKFLEydpOiPHcOQZdErjlkFZhxjqUGqxrpfL");
    string HRLkyUgYeLgn = string("LiEitYEbXjdukjOmxneSnrdIICmXFhPnndGPMCZtjdpQRIWKfFkktiXtcJJSXDvWEpPIkQoWLVMUokIYkKBxchXpYBnABsUSplzPlLwWeGJMsAZPbLEtlUUFqpHacmSZQxCVVx");

    return MYXQphEtv;
}

void yRALnj::FCOvMbdYR(int ZtetRtnkI, string huVYhHCj)
{
    bool xdoheSMga = false;
    int zdOpSlvselHvIdvn = 1254923461;
    double nyEnTlygtoU = 213760.9542207065;
    double nlMxXzgu = -293229.292527921;
    int iMSODphqVQPc = 1345738017;
    string kZntjCp = string("ituUaYNMzuIcXCZlZjEuuRevNUELUkTPKpNjKjIpNrnGkcdKGyReVezFWns");
    double FCVHG = -228259.70214877953;
    int AWvEMfJm = 66609224;
    bool OrwFwgvnyyakp = true;
    bool vkDzvcCrtYVlbIZu = false;
}

string yRALnj::JQcRYolaBlJHRpC(double ksIDrM)
{
    bool TmMQB = true;
    string NumlSjpax = string("UHdxuUJaAIoLQXeKxGrczJEkjbEeJHsQcAAYZzxnLfURMDeozMRUkcIfaPPaeWeIhfeHhPMktKziEwfRqBLQuRPofuvzGLDhkTfWzwKndpkzrYpYxEMeSHYVqFPDJmOFGUDOqPXyUhRlpXWsyKTSjhIqyEPFgqpKdGkYWonvOUvDEgFIPzpNLJFIgLnczfKWRRSPtQcdSPaeblXHrelDmPXvYdUBEvcpIcukENVMwOjnbzDuQgCbpwisznvlTJE");
    double JNUBYcASJJEbIEX = -135362.62044174864;

    for (int JdjXRpgc = 1095888801; JdjXRpgc > 0; JdjXRpgc--) {
        NumlSjpax = NumlSjpax;
        ksIDrM -= ksIDrM;
        TmMQB = ! TmMQB;
        TmMQB = TmMQB;
        ksIDrM = ksIDrM;
    }

    return NumlSjpax;
}

bool yRALnj::GdzVdA(int ZaFVK, string XgOzIFltzoXzW, int EhphMMt, bool UOCQTvDaei)
{
    int orrakjdgwfvxsQK = 1581962734;
    bool KIPPoCC = true;

    if (EhphMMt > -81077857) {
        for (int upbqJii = 800466664; upbqJii > 0; upbqJii--) {
            XgOzIFltzoXzW = XgOzIFltzoXzW;
        }
    }

    if (KIPPoCC != false) {
        for (int ztsAlvsxctnMQT = 1027832805; ztsAlvsxctnMQT > 0; ztsAlvsxctnMQT--) {
            continue;
        }
    }

    return KIPPoCC;
}

string yRALnj::ZwcbcpY(int vMObukVFeZ, int QRUWDbuGXOctox)
{
    string ZLuoadROMRL = string("psEZswOpQxUSYmURwckfxRqelDIVBHJoytGfPmkEJiNfxbCSjtibQmAJHtEdWvYBFRkCUqcaMVyZdjxLyneLfpvLsPbz");
    int jszeXfaXefseR = -1760142416;
    string AVSNALVMG = string("EzVGroExDJxQVvEiKXXGaEFoewXdDWuaFfFeFwgnYxUZGlRpgnicqLhRjmZoBFkqpsnhHflBFZdrXaHqUYJTuIojsnXaRxnHprKlPkVZehNOFGABmTAJVvtqgUwzzXlewnuyxNmQBozNbmcZyAhxaBsKbcLWBpPRFIpKuIDLqw");
    int zjMUbVAGbdSHMtOY = 1102874686;
    string ADxFMGpnaXQvHqnT = string("fYokIastzthFSKVWwAja");

    for (int ktMmlppiVradi = 1668244546; ktMmlppiVradi > 0; ktMmlppiVradi--) {
        ZLuoadROMRL += AVSNALVMG;
    }

    if (vMObukVFeZ >= 1687732920) {
        for (int cEMeqEfNfbbV = 1710865859; cEMeqEfNfbbV > 0; cEMeqEfNfbbV--) {
            QRUWDbuGXOctox /= jszeXfaXefseR;
            zjMUbVAGbdSHMtOY /= QRUWDbuGXOctox;
            AVSNALVMG = ZLuoadROMRL;
        }
    }

    return ADxFMGpnaXQvHqnT;
}

yRALnj::yRALnj()
{
    this->gnmigfMhHqOT(1516049494, -890797238, string("sjpqZDKONvytEKrjfzYHuRnINrkIrkhbUOEyZEfPTyEtjIJDWhQGNXzobunjFINvdzGejsleAzTPVOmRHqrqOvRENnSKXjMlCOzLBIZQVQlOSElNoljrBgBuBEzSyMMmNCvKsiyABupShAbaTcrtfNsXulanLrfesByHkhcXlTtnwPsSmIfRIZaTjDtZJSTLauesFYSfsEbBlUpDmKzvcSZkBVCWivbAVTdIOGwngtHhmcFRvTEmOmcdgfTiAaK"), string("pzlPcpfAiViCBoHeKLlJChZHGuYnQZ"));
    this->UPtjt(266160.479853386, string("OEyVMJKqGIbGndtlsHEAZlXBnuGYgLbFWTmtYQzLewWmWgSDssbEJOlmxWrNzXzGrYrsxEikhCjKDtjBXBhoELgFWXCLarEhkLSdIAXZjDsSTnlXVvgcZCTgnhFK"));
    this->TzUUrYhCVDnz(1649129289, string("KlwqNTmitPwYHrHOxrQZyjqDRMsqqsHHtOeqXuptdqtjpcwHBrJJCFtZPFEFHiKAvbWapUYQgbBOMsgZTDsSlKnElWYUsnFkvVovqbDxugeogfnxIIEMHHBhNMddzGqWGnqcHWOMicqlrPrFqpefUImViRwFwbkJdhNjbiYTRXiFLsqfKWtfwVrrhPQUbZkaGKBdQqYPHGoIpRWxBlNZPZIIwfreBEZgJb"), -495931.8475437505, string("QrMqdfUphnDjkvDYizCBywgVUHtpzDiFsRPlPVrKJpOWFSysKWWVCfqdLboYNXphbFnBwopgoJNOVCUZrccdKkyEfmCLtEmNEWYMmrNfrUoFBpeusOwwXPWbYyvKPpCphCsZdgxNtLjywbcFuXAqToBnQRinCsbjJMzcSqcBpqBopxcqLvg"), false);
    this->iNKumSVDnZNB(true, false);
    this->meIVMxZqdlaIgl(1558961742, -544337811, -192200.2384962565, 1147213100);
    this->eSUAArQXQhmed(string("fxeqE"), 780119.5649168979, string("CkFcvcDTvfSgQqNDuEkWVjQUSnXQxBOeGnfkIUkbmrbZSpvqYZhoHrIPVaIXWdHGARvDsOcTy"), string("LwBlnpiRsCvWEfUQieKaGVDpAceoifIqgnJUlEMOfNfAwNZqGbISYwQEMXcZAmKHzmofvAGVXpxxtusEFVNrTLQcbCiJbqJvNjMOMqfHXsbXspeWTURvvyWOFNdrGuiwSzPpzkTFnWMLimRnEIHNkFiZquIWXvnzxAxoAtRCSNhndCIzPCMTdQvlYBsRXJTBoeCtvoQYNsOeIkeJOxavA"), false);
    this->FCOvMbdYR(236943537, string("HuxqdtUzYbfVwfZEPxVbQHextmQCLjEmfOZBQEAJiPRBUWLnKWrXnMGfXVsFXDCrwLyHvBNGZzPeLfhDinJtMsDGhyGsMhTPWqSjLeEzvhYVFlrOyAMZnXhPVyPZTclrPEanOilsrWpNIIfWiayUQRkTKGAdQLQoeHHocBWCCQVxrtbEyLhXXCbbCHFMddDpoyazToOFMFbRmMxjlkyIGSe"));
    this->JQcRYolaBlJHRpC(-462549.33523342037);
    this->GdzVdA(-81077857, string("RzcKZeYJFgUQurxGiwhlXmOoQgLp"), -889549257, false);
    this->ZwcbcpY(-776911638, 1687732920);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KYapmQH
{
public:
    bool oTERZcCxCv;
    string dbiGdnZRGQsWrqd;
    bool WcIRaZGfNxbb;
    string QmNRnre;
    string QMGTJLGAi;

    KYapmQH();
    bool nCPnVXUSqCmz(string AjVwKICONAlTK, int jVrQEiUVPmRFcNYY);
    int CzDsFUnj(bool xEHsuQRkOGFJP, bool NjForNQH, string LQMebKCwufrKHw);
    int GpQvRtQwS(string uNIumfN, string ODXeiqhnIG);
    string anUqbETSQgjDIE(string mlnvaWBYWTFIDRjt, string wtALgunzcUsvRs, int rCvVrDveGNzPKwvb, int iVGfKBsULDQSXQE);
    string AlnPp(double sKVowJvUMt, int WyGiTFh, string AAqWbbBTKItr, string RSQHnmKmwBMmGa, bool uBVkfcNIEsbRhvYc);
    void jtQlqe();
    string EqEzTkOYSNjNk(double hVLATvONeAdKq);
    bool yWPFEC(int qUPzecB);
protected:
    string NotYXDiOC;
    double jTaVVjRGZNzELYFa;
    int umprcVBlYqXrLZ;
    int PSYHAOA;

    bool MXHoLP(double mYlvAqCzQ);
    int JiNZwBjycBHJsCE(int ahFgUC, int JNwLKPjegyH);
    string lIJpaozrA(double rzKlUSvF, bool XDYobNdeWH, int sUckoSbeFyEYtfB, int jndbm, int nQLfOiXK);
    int iJmqrpINsPgkIj(double OVGfhuK, int ooFPaupZCbQw, bool CLUPstNVbAXdrEet);
    bool idWctpHLZC(int gQtYBoSylrD, int bAzJfN, double sChEETbHEMwynGEu, bool KBJJbjuBLr, string OShRuwutncVZJgd);
    double HGqdjOtB(int aQsHJlZcUGd, bool qAXXNuzNrHKJEi, bool sDobKdW, bool ANLXkRuUZD);
private:
    bool fOqNhimGkZCHxL;
    int PhIewZGrCeb;
    double JvjYyaIMs;
    int TtKBGWFoqR;

    string VMQKyLl(string ExGsoEZa);
    string jDUzSP(int ObrHaaGgoqPOreZR);
    void aauSkeFfqtfGALD(double vjlPlRBF, bool efVlxS, string nOFzCq);
    string vzcbpPirdp(string taBWALMxDJjNUnn);
    string tGWgZg();
};

bool KYapmQH::nCPnVXUSqCmz(string AjVwKICONAlTK, int jVrQEiUVPmRFcNYY)
{
    string CQkQwk = string("uOAJzKLBfRuFrEOYKNhbilgRiGONgtyQHGfDyIGRPBLBoFvyEpYafYzKQkgrryJfZRQoWwgzLWWcCChAoVGtvSCZTXIQfnEEesftJlZrMywLPccIOpCetdyNhR");
    int aXKxZuDlh = 456465619;
    bool DoQyiJZeAqUPCMwD = false;
    bool AvTQNLGSkw = true;
    double gKKzqbOAiaQcfzvI = -394729.07109256205;
    int RYMWDKShWGksvY = 1120321212;
    bool XlSsaBHZ = true;
    double CAYnVAQdCMl = -35807.6347607229;
    double mCLkeImzlsO = 952060.9541764988;

    for (int vKNPsYlxSmg = 1250350007; vKNPsYlxSmg > 0; vKNPsYlxSmg--) {
        DoQyiJZeAqUPCMwD = DoQyiJZeAqUPCMwD;
    }

    if (aXKxZuDlh < -858707318) {
        for (int zchQyDzyyS = 1412270638; zchQyDzyyS > 0; zchQyDzyyS--) {
            aXKxZuDlh *= RYMWDKShWGksvY;
            AjVwKICONAlTK = AjVwKICONAlTK;
        }
    }

    for (int zgUkyhDGQFAQFoC = 362731986; zgUkyhDGQFAQFoC > 0; zgUkyhDGQFAQFoC--) {
        gKKzqbOAiaQcfzvI *= CAYnVAQdCMl;
    }

    if (RYMWDKShWGksvY != 456465619) {
        for (int DgBXpBGfb = 1642956002; DgBXpBGfb > 0; DgBXpBGfb--) {
            AvTQNLGSkw = ! AvTQNLGSkw;
            XlSsaBHZ = DoQyiJZeAqUPCMwD;
            CAYnVAQdCMl += gKKzqbOAiaQcfzvI;
        }
    }

    for (int HnXOPg = 1488260661; HnXOPg > 0; HnXOPg--) {
        gKKzqbOAiaQcfzvI *= gKKzqbOAiaQcfzvI;
        DoQyiJZeAqUPCMwD = AvTQNLGSkw;
    }

    return XlSsaBHZ;
}

int KYapmQH::CzDsFUnj(bool xEHsuQRkOGFJP, bool NjForNQH, string LQMebKCwufrKHw)
{
    int uhlkjafeMhbV = -213044277;
    double VXtdrchlAymv = 331282.8639720601;

    if (NjForNQH == false) {
        for (int dppusXrZ = 512026903; dppusXrZ > 0; dppusXrZ--) {
            xEHsuQRkOGFJP = ! NjForNQH;
        }
    }

    return uhlkjafeMhbV;
}

int KYapmQH::GpQvRtQwS(string uNIumfN, string ODXeiqhnIG)
{
    double ZKSMbrPtHdtPOrY = -846293.5585974656;
    bool hnFzEofQm = true;

    for (int HEEkqhmKZMZfl = 1821500124; HEEkqhmKZMZfl > 0; HEEkqhmKZMZfl--) {
        uNIumfN += ODXeiqhnIG;
        ODXeiqhnIG = ODXeiqhnIG;
        hnFzEofQm = hnFzEofQm;
    }

    if (ZKSMbrPtHdtPOrY == -846293.5585974656) {
        for (int XfkcDwrgleNHwVmB = 127985233; XfkcDwrgleNHwVmB > 0; XfkcDwrgleNHwVmB--) {
            ODXeiqhnIG += ODXeiqhnIG;
        }
    }

    return 1462994839;
}

string KYapmQH::anUqbETSQgjDIE(string mlnvaWBYWTFIDRjt, string wtALgunzcUsvRs, int rCvVrDveGNzPKwvb, int iVGfKBsULDQSXQE)
{
    int TRIniChynrjkw = 11352224;
    string XdUpivmkBWrWVgkk = string("fLXnpkm");
    bool enUKxkF = true;
    string WDSiVnXLx = string("gPCvUfCAXjgAKTnVnCqKBGoXyRpOiFcnkWJpbyNVDscXBrYApjTDjZaldQSeOoXblPhFnEankLAdksikMtxQcWToYoXJeIBhGPmwWykwZkNutsZKbTCOJbsMwDadeSpKNsLdxHwMspjzoeINqKkEVpsRiQdCEPnkzrFHYeVMYOFIgR");
    double YlgGzrgSJFS = -204941.8320797671;
    bool iffNlPiZY = false;

    for (int xaFyrUiyOTLpZZJ = 1981151884; xaFyrUiyOTLpZZJ > 0; xaFyrUiyOTLpZZJ--) {
        TRIniChynrjkw -= TRIniChynrjkw;
    }

    for (int wzxCHgNN = 1965380788; wzxCHgNN > 0; wzxCHgNN--) {
        enUKxkF = iffNlPiZY;
        XdUpivmkBWrWVgkk = XdUpivmkBWrWVgkk;
    }

    return WDSiVnXLx;
}

string KYapmQH::AlnPp(double sKVowJvUMt, int WyGiTFh, string AAqWbbBTKItr, string RSQHnmKmwBMmGa, bool uBVkfcNIEsbRhvYc)
{
    double aiLZnkXBeuCGSehz = -756545.5040947213;
    double TWZabKrSbZjb = -819656.7982819058;
    bool OSVxvuoWDzJJNA = false;
    bool SOfQAlfkYAtMl = false;
    bool ExLOziLY = true;
    string HyNmfizXPLsP = string("eCzcCIsaDoYYXklBMmmIbnrvJjahSpZABLdGkbHAuCARadcodrDeTEYdziOBCJbwepGhaOCMuSWQkYOwjatgVVIlmoAIGiLkMYrEqLnIAfgBIonsDEUrukQxyvpAfRdeVeaiKXCRRuTKrPvGsklELIoqOwlqpElQMzSMCHMnpxWeDKyCJyznOZwcKSYmaLTqWcAlRgkrIQDtPTKnZAXoZhtKmjoWT");
    string aPtUuHToKA = string("nLeBMeVKfrZYptw");
    string ZRmesvkGAMbPfA = string("GwONGWmJpkMLavnlwKmhLTbbbZgxFfPpnpnQQBIkUkTdWrnlBhYvwMcpyHruQmZGYdkkdW");
    double rPRWQUkkZEEbrV = 178005.81816039872;

    for (int ozxsDvdMiXz = 1032792908; ozxsDvdMiXz > 0; ozxsDvdMiXz--) {
        continue;
    }

    return ZRmesvkGAMbPfA;
}

void KYapmQH::jtQlqe()
{
    int whwQykxcoUPOSlx = 1466541882;
    bool acbjSpRjI = true;
    double VRxOvRJcyUIQH = 50233.34917304843;
    bool LYNtnalKCv = true;
    bool GsZPWwXdealNr = true;
    string tvWcMigNRu = string("WVnkNHRMfHuqALfdobcJrMSAuBHmeiPWeVLNgIQPVLaRrrDNEvkDRTRmOOlUssSjoMDmNCBkEZIHqRKdQehjlcMcVWjVROMeDxqqfwAwswgACLZsJZwl");
    bool KiTEBfLwRoiLer = false;
    int AuWGMmnrkBnPK = -749180585;
    double VZaeywGKieJTsv = -784838.534942288;

    if (acbjSpRjI == true) {
        for (int BCRaaAQJWSjAA = 968299900; BCRaaAQJWSjAA > 0; BCRaaAQJWSjAA--) {
            acbjSpRjI = ! acbjSpRjI;
            VRxOvRJcyUIQH *= VZaeywGKieJTsv;
        }
    }

    if (whwQykxcoUPOSlx <= -749180585) {
        for (int GVfEPDoMD = 874922611; GVfEPDoMD > 0; GVfEPDoMD--) {
            KiTEBfLwRoiLer = KiTEBfLwRoiLer;
        }
    }

    for (int HOrhPUzsUDxY = 1373660333; HOrhPUzsUDxY > 0; HOrhPUzsUDxY--) {
        whwQykxcoUPOSlx -= AuWGMmnrkBnPK;
    }

    for (int XUKZbjH = 674132772; XUKZbjH > 0; XUKZbjH--) {
        acbjSpRjI = LYNtnalKCv;
        LYNtnalKCv = ! GsZPWwXdealNr;
        GsZPWwXdealNr = acbjSpRjI;
        LYNtnalKCv = acbjSpRjI;
        VRxOvRJcyUIQH += VZaeywGKieJTsv;
    }
}

string KYapmQH::EqEzTkOYSNjNk(double hVLATvONeAdKq)
{
    bool dhCLMeLbVhFOATRn = false;
    bool mPFZx = true;

    if (mPFZx != true) {
        for (int xXxxBKZWNchPjeJj = 452384958; xXxxBKZWNchPjeJj > 0; xXxxBKZWNchPjeJj--) {
            mPFZx = ! mPFZx;
            hVLATvONeAdKq -= hVLATvONeAdKq;
            hVLATvONeAdKq -= hVLATvONeAdKq;
            dhCLMeLbVhFOATRn = mPFZx;
            mPFZx = dhCLMeLbVhFOATRn;
            mPFZx = ! dhCLMeLbVhFOATRn;
        }
    }

    for (int YQLhf = 974612108; YQLhf > 0; YQLhf--) {
        mPFZx = dhCLMeLbVhFOATRn;
        mPFZx = dhCLMeLbVhFOATRn;
        dhCLMeLbVhFOATRn = dhCLMeLbVhFOATRn;
        dhCLMeLbVhFOATRn = ! dhCLMeLbVhFOATRn;
        mPFZx = mPFZx;
        mPFZx = ! mPFZx;
        hVLATvONeAdKq /= hVLATvONeAdKq;
    }

    if (hVLATvONeAdKq >= 351519.99033478653) {
        for (int fvxxYNfK = 1814705300; fvxxYNfK > 0; fvxxYNfK--) {
            dhCLMeLbVhFOATRn = ! dhCLMeLbVhFOATRn;
            hVLATvONeAdKq += hVLATvONeAdKq;
            hVLATvONeAdKq -= hVLATvONeAdKq;
            mPFZx = dhCLMeLbVhFOATRn;
            dhCLMeLbVhFOATRn = ! dhCLMeLbVhFOATRn;
            mPFZx = dhCLMeLbVhFOATRn;
            hVLATvONeAdKq /= hVLATvONeAdKq;
            dhCLMeLbVhFOATRn = ! mPFZx;
        }
    }

    for (int QCvsEJXLp = 1341556503; QCvsEJXLp > 0; QCvsEJXLp--) {
        mPFZx = mPFZx;
        mPFZx = mPFZx;
        dhCLMeLbVhFOATRn = mPFZx;
        mPFZx = dhCLMeLbVhFOATRn;
    }

    if (dhCLMeLbVhFOATRn != true) {
        for (int VVGHwiFbDQc = 1714019326; VVGHwiFbDQc > 0; VVGHwiFbDQc--) {
            mPFZx = ! dhCLMeLbVhFOATRn;
        }
    }

    return string("zDwWzolxoWBaAohPszAzRWedBZSYfzUnkPYGWyBosNTAUzXOWnHazkPc");
}

bool KYapmQH::yWPFEC(int qUPzecB)
{
    string puNDnc = string("ECDEpdmCegzaqAYPhjDWwqRTsodeGvRFdPsKOKPhJlWsZhTykBapaxlPZnxmOqpWsiHPRqPMfxZwqVNUbscDdgHvpoWWtOcMIbNhhSzFsfOFtAusxpSYGegxslNdRwZoppgORpEyIFAWbVDUEUvjKfgHikqjlzRguRAiEdIgfOxpZqGwkrHOJcBbrbpmtGVAqcPoAjwhySpywpFsWDYxeDwSMyBMSNPFErduohu");
    bool cyzKofJp = true;
    int aDORpl = -1044294706;
    bool JNQYcoWNdTd = false;
    double daENUnNekw = 288578.1616594275;

    return JNQYcoWNdTd;
}

bool KYapmQH::MXHoLP(double mYlvAqCzQ)
{
    string MByATxjqeYggdDcn = string("cFJvaatHgmbVJUWOmDMJZKPiUfIASDsFlhVtfvCwBYFywujqcyOfgpmLwpFjizGlOrbflnhtOIQYnZHxVRbgZxLnFkzpdZBOqKDyFAihySxljuSFRRZjUfQMvRELDClJFxhyxGSzgrxUxSzDzQApEUHHihHBOmAFYTvkZvtoSJsMIyLLcKJNfKVFPCXTciVrGxKW");
    double ucPoDgpJGYJ = 904686.8570349932;
    double GMPqVU = -680717.4384050028;
    int HkIBOhTIfFCEG = 1063961430;
    int SLHcnNy = 1173267497;
    string xSGith = string("aXqDjpRNuqjmzOXStKSePcXtfKOLwtcQgvdmvCejfSxKWFoQXRdBFaERDSAEenxDmbsBloibVMzvAJIrCVmSQCtNootnDyuSfPGegssVXyphnOWoZdiQVxCtWbwmVOKOTNUMsHxMrAOAoYXHDmThMpvZpRZRwykoqDLxTtplnUtHSATfaLCIKSUETWoLoyAfHzdkopZ");
    int ihwiABO = 1793969747;
    bool KRIfyeqVKdFV = true;
    double qPUIEKiDHHsxrMB = 344614.3200145964;

    for (int UqNvzDRqqGsDOxLe = 828709773; UqNvzDRqqGsDOxLe > 0; UqNvzDRqqGsDOxLe--) {
        xSGith = MByATxjqeYggdDcn;
    }

    return KRIfyeqVKdFV;
}

int KYapmQH::JiNZwBjycBHJsCE(int ahFgUC, int JNwLKPjegyH)
{
    int wCcHYvQx = 186268399;
    string hlcMuizKyTuLyJh = string("MgxMeCzbnQtlMDSNWyEMzeXzIsewtiOcAjEzalzKzjSyYulnKoYgAKQZ");

    for (int yoYUWZsfTIIBkC = 706833521; yoYUWZsfTIIBkC > 0; yoYUWZsfTIIBkC--) {
        wCcHYvQx *= ahFgUC;
        hlcMuizKyTuLyJh = hlcMuizKyTuLyJh;
        ahFgUC /= JNwLKPjegyH;
        JNwLKPjegyH -= wCcHYvQx;
        hlcMuizKyTuLyJh += hlcMuizKyTuLyJh;
    }

    if (wCcHYvQx < 186268399) {
        for (int YmVHBNR = 1879132645; YmVHBNR > 0; YmVHBNR--) {
            hlcMuizKyTuLyJh += hlcMuizKyTuLyJh;
            ahFgUC *= JNwLKPjegyH;
            wCcHYvQx /= ahFgUC;
            ahFgUC /= ahFgUC;
            hlcMuizKyTuLyJh += hlcMuizKyTuLyJh;
            wCcHYvQx = wCcHYvQx;
        }
    }

    for (int DYQBb = 909952238; DYQBb > 0; DYQBb--) {
        JNwLKPjegyH += ahFgUC;
        ahFgUC = wCcHYvQx;
        wCcHYvQx /= wCcHYvQx;
        ahFgUC += wCcHYvQx;
    }

    for (int MQjakEdxgHKRnjH = 78861524; MQjakEdxgHKRnjH > 0; MQjakEdxgHKRnjH--) {
        JNwLKPjegyH *= ahFgUC;
        JNwLKPjegyH *= wCcHYvQx;
        ahFgUC = JNwLKPjegyH;
        ahFgUC /= ahFgUC;
    }

    return wCcHYvQx;
}

string KYapmQH::lIJpaozrA(double rzKlUSvF, bool XDYobNdeWH, int sUckoSbeFyEYtfB, int jndbm, int nQLfOiXK)
{
    bool LCRKQKcfSCLn = true;
    int IHLMepOCaeAofmq = -1517679087;
    string XpgxpokXwvPh = string("eUztWGGAuyYDLVQeKyUXiSjJCUUhYWoFaUcJLVjqkdfRSekYBXXshYugbupHRMn");
    double XgYiiVmgxfo = -397416.9722044117;
    double DiygfqYQX = 819408.8748058628;
    double WSFpoBFGj = 470291.38494926324;

    if (LCRKQKcfSCLn == false) {
        for (int apevpEgLMuQl = 252705616; apevpEgLMuQl > 0; apevpEgLMuQl--) {
            IHLMepOCaeAofmq *= jndbm;
        }
    }

    for (int XHxzccNnvhAuROQ = 993702973; XHxzccNnvhAuROQ > 0; XHxzccNnvhAuROQ--) {
        continue;
    }

    for (int WxekbCbNo = 847269127; WxekbCbNo > 0; WxekbCbNo--) {
        nQLfOiXK /= nQLfOiXK;
    }

    if (IHLMepOCaeAofmq < -1517679087) {
        for (int qVpIrnuVZZJAXxtB = 537119699; qVpIrnuVZZJAXxtB > 0; qVpIrnuVZZJAXxtB--) {
            DiygfqYQX *= rzKlUSvF;
        }
    }

    for (int KmzSyjocLmuV = 303071894; KmzSyjocLmuV > 0; KmzSyjocLmuV--) {
        continue;
    }

    return XpgxpokXwvPh;
}

int KYapmQH::iJmqrpINsPgkIj(double OVGfhuK, int ooFPaupZCbQw, bool CLUPstNVbAXdrEet)
{
    double uMVZiZk = 766786.545997958;
    string CcTgwOplkpJ = string("lQfbmrghgUYgjuwX");
    string LXdYakfKTKX = string("PIVcgTHqqWSxYxsVtbeIYzubWcjcbFXxZKJacbADTfdyxvlnTCYkNOjrDsAvnG");
    bool IapEEesWtdexl = true;
    double RAPOiyrKblerCMn = -929100.000197031;
    string ymmvTLeVNHtUodoB = string("owg");
    string YGkVefGCY = string("BcFUnxLoMluckhYaqCpsOhheWsarBPJiQCERLCVexdTOXENxUevZDpUu");

    for (int WJUIwhxpDaQsPCG = 281068094; WJUIwhxpDaQsPCG > 0; WJUIwhxpDaQsPCG--) {
        YGkVefGCY += LXdYakfKTKX;
        ooFPaupZCbQw = ooFPaupZCbQw;
    }

    if (uMVZiZk <= -929100.000197031) {
        for (int zVcRaEvNqHUqicO = 486010387; zVcRaEvNqHUqicO > 0; zVcRaEvNqHUqicO--) {
            CcTgwOplkpJ += ymmvTLeVNHtUodoB;
        }
    }

    return ooFPaupZCbQw;
}

bool KYapmQH::idWctpHLZC(int gQtYBoSylrD, int bAzJfN, double sChEETbHEMwynGEu, bool KBJJbjuBLr, string OShRuwutncVZJgd)
{
    string VyjpfITXd = string("jVzJdosFBQvhhDmBFLKGnxnJKMXHiJRQIKxgFIRTQPAGQBDPIsIVnKRuBnKbuqhWJABOvpvYlURJYrMZnLNHZxyoXQFvUhlyJxwpmMVtzZYHyNtIMMhCJkVvpJmjdxMmLuFNILfawgQoFMmYhGxxfgUvvNlkhOuVeBIAIPKmkipOrrYhRNOjQhSNxYTxsghFeLwHBUEkPSkDdJBxKKyZQYYCbxDDOLj");
    int zyIAkeoZMu = -121901530;
    double WjYpZFJkVVyLvk = -722716.9009168198;

    if (bAzJfN == -121901530) {
        for (int ZBoFyAjeWT = 1272107062; ZBoFyAjeWT > 0; ZBoFyAjeWT--) {
            gQtYBoSylrD -= zyIAkeoZMu;
            gQtYBoSylrD /= bAzJfN;
            sChEETbHEMwynGEu += sChEETbHEMwynGEu;
            zyIAkeoZMu = gQtYBoSylrD;
        }
    }

    return KBJJbjuBLr;
}

double KYapmQH::HGqdjOtB(int aQsHJlZcUGd, bool qAXXNuzNrHKJEi, bool sDobKdW, bool ANLXkRuUZD)
{
    bool AYGjdaUVPPRgu = false;
    int AaUxmzFcjRYg = 1263001256;

    for (int WGBqCYrt = 641575207; WGBqCYrt > 0; WGBqCYrt--) {
        aQsHJlZcUGd = AaUxmzFcjRYg;
        AaUxmzFcjRYg = AaUxmzFcjRYg;
        AaUxmzFcjRYg /= AaUxmzFcjRYg;
    }

    for (int LrociuzcSPkTp = 1880473544; LrociuzcSPkTp > 0; LrociuzcSPkTp--) {
        qAXXNuzNrHKJEi = qAXXNuzNrHKJEi;
        qAXXNuzNrHKJEi = AYGjdaUVPPRgu;
        qAXXNuzNrHKJEi = qAXXNuzNrHKJEi;
        ANLXkRuUZD = ANLXkRuUZD;
    }

    return -390448.31948431727;
}

string KYapmQH::VMQKyLl(string ExGsoEZa)
{
    string nMowQfaWcV = string("vDqeEOYLmkOiHFCpQgMQWiaOIIkVGywPFWzljmAtNYjVVqwRElsTOpItoGENmLBScyVomIgSNipwWqqKCGcQpGWEiWTZZpYKCoZfNulPmYzzGwzUMfQCuSUVpvIgVgEmwkNDgWkhLsBIFsZmBSdttjnJuRTefuByjJqJUiGujXVAEORclERSawsBgtSqvyrEGmhblKtVBoOduCYVmBiCUklsTMQZxOzQ");
    double lTJhrNVWuyxl = 724378.2149438398;
    double zdYWfLQqT = 752323.1823797936;

    if (lTJhrNVWuyxl >= 724378.2149438398) {
        for (int NggxXuJxEdDxYE = 1849629282; NggxXuJxEdDxYE > 0; NggxXuJxEdDxYE--) {
            nMowQfaWcV = nMowQfaWcV;
        }
    }

    for (int rwVQjqSZPsqe = 2091010569; rwVQjqSZPsqe > 0; rwVQjqSZPsqe--) {
        ExGsoEZa += nMowQfaWcV;
    }

    return nMowQfaWcV;
}

string KYapmQH::jDUzSP(int ObrHaaGgoqPOreZR)
{
    double tiuzeGMBXw = -249505.6013019822;
    int uLYVHNe = 1505521329;
    bool AEhWmfTvM = false;
    string sqhvwyTjpAoDpeMr = string("nfDnNqXnmwVRWVjNvAJjZAxriBaXzuSFJreosrORvaviMrVpBPVPTlNnAsVCNzUJwrGPSJQhCywYIYgNEstfMFPjtgJucPudDSzRoNqFTVmsWWQUfzYzuHJajQaBmKeyrmtXnroLQhbHDdcpyxTLf");
    double yMfkNwIYBM = 684426.4469890591;
    int pEAqYnh = 438307226;
    double lSrOnWqKTBtKOR = 927619.7455344629;

    if (uLYVHNe > 438307226) {
        for (int qEqxJTlXyovGcy = 1797270733; qEqxJTlXyovGcy > 0; qEqxJTlXyovGcy--) {
            pEAqYnh /= pEAqYnh;
            tiuzeGMBXw -= yMfkNwIYBM;
        }
    }

    if (lSrOnWqKTBtKOR <= 927619.7455344629) {
        for (int upVLcRmTUABv = 2044170845; upVLcRmTUABv > 0; upVLcRmTUABv--) {
            pEAqYnh -= uLYVHNe;
            uLYVHNe -= ObrHaaGgoqPOreZR;
            ObrHaaGgoqPOreZR -= uLYVHNe;
        }
    }

    for (int sVpLmxKEivVQ = 1245636491; sVpLmxKEivVQ > 0; sVpLmxKEivVQ--) {
        continue;
    }

    return sqhvwyTjpAoDpeMr;
}

void KYapmQH::aauSkeFfqtfGALD(double vjlPlRBF, bool efVlxS, string nOFzCq)
{
    string NEUrNOGtEEdhF = string("bAPkzGIBvXiNXmEInjPQhwGhDMyXzUlMoQCYCwOFGnEMBjKCUUvdSjFGCWYDXDwSlrovpnAionRaAdbAuseqbhjSwVKAPnwDEdpcXaPNOPbZamABTjHPIeuLSBEEsHLrtVtXLYRgzQivyftwEPNUtmVYbELVcziLIgJjOKnNZvjOKOgSAIf");
    string uQgqJISlw = string("qtxyVbydNRjnAEzouAJAyXqnnMVWnAtKpHpjRugziUBLYUjmcdCTViqdCRhrlwnxiKADrLUZLgxRaWHTSEQvgyOWYoUlAmLiLibjGgSqjkKsvhliVzfGZZDRZBxywvgKfetswDQYHZKstFVLZJxapMeePxkbxqUhhqYzkBNqMuCOiSImoYRQLTwABCxKRenJCyrLmvvzTXCJNh");
    string lmOKd = string("wciatkNYiRAykBKKnARjLgdCbMVlNbVcbRZDykWkNsFZfuRZDlvbQGKIAlskdbUvJNjITdeJKQatvCNDCSwBAjOQQkrUNDxDEvdhcHXcljSYKkmSgbCmLJyFijXPquqnswxjFBKOYaUfrhrgGxekOPhmzZjKuhAhUkgBJwi");
    int ZMFpZxy = -1621299875;
    int idDBQWFHw = -101310261;
    double mxECVqwUcEzqN = 242415.71496154423;
    double ofkmsitVIlqovfFE = 293068.96935612045;

    for (int DAlRXGa = 1215196912; DAlRXGa > 0; DAlRXGa--) {
        NEUrNOGtEEdhF += nOFzCq;
    }
}

string KYapmQH::vzcbpPirdp(string taBWALMxDJjNUnn)
{
    string VcwzgYoQLRc = string("kBVgTeymNFgqgRVvaPNFFaFXSBZlBePxgmkGeIjdwpgGRzIxNoeOwfZxBFkLAUIGMVVJAmSpONclctCYsQBifMOUDcFsboRaSByNXuYlWnEyYNmjLnfVpdIxTaFSSJGCKKIziEoVTloCOCgRpbgVWqWobRYm");
    double bRNCZe = 750773.3089795135;
    bool iLnLdpnh = true;
    int FvllrGZZHdrBsqdc = -1098545436;
    int jLTqbCPIxym = -878457263;
    string BlifDwuW = string("HAXZxDThRBcTjFGbSWMlhEeTDWxDUonCvWnGmmkUuPeAKssDhiDRy");
    double RqRZvjPVgQPPdkzc = -442530.31990216154;
    double YOCtwz = 730272.6507828064;
    bool NqgSDdbUo = true;

    for (int NWtUXydHnlFVAKA = 530534698; NWtUXydHnlFVAKA > 0; NWtUXydHnlFVAKA--) {
        taBWALMxDJjNUnn = VcwzgYoQLRc;
    }

    for (int IPMgBWIkCxSmIuOF = 123528466; IPMgBWIkCxSmIuOF > 0; IPMgBWIkCxSmIuOF--) {
        bRNCZe = bRNCZe;
    }

    for (int aqRWtQhclsbld = 407222051; aqRWtQhclsbld > 0; aqRWtQhclsbld--) {
        taBWALMxDJjNUnn = VcwzgYoQLRc;
        RqRZvjPVgQPPdkzc /= RqRZvjPVgQPPdkzc;
    }

    for (int srauYSvAoVRbGmic = 2035679061; srauYSvAoVRbGmic > 0; srauYSvAoVRbGmic--) {
        taBWALMxDJjNUnn = VcwzgYoQLRc;
        YOCtwz = YOCtwz;
        YOCtwz += bRNCZe;
    }

    return BlifDwuW;
}

string KYapmQH::tGWgZg()
{
    double rjNxMWpnu = -475538.5193339656;
    string oRKBacobJLEs = string("miZlUiPkKXljJPbJxgTOQWmwfAmkInnNoJkXJsgSWjPEJWbItCFwNgFZsHYTCyBtYrZ");
    bool BfjvXiVtRA = false;
    int MssMoBvI = 1685379812;
    double entQfPuxaTPIPpf = 782688.4042891861;

    return oRKBacobJLEs;
}

KYapmQH::KYapmQH()
{
    this->nCPnVXUSqCmz(string("YZpTkWOGMySIyyxWYnlRQZApeoIaCNKYJfgYvatYTYhfBGuSdvqSGrAqdptcPxsKUeSzPFafSYuGjAWEoOmFmJTwvhb"), -858707318);
    this->CzDsFUnj(false, true, string("rsbXkUJvhTnMSYHGVwDiDeJLrcSdUyZBvbNYFZVfzYdPipnxOhcmqBfUFULcMGdRjEJrcSeHJOuDrQvQCjBPOpivSwCIxzlKVQNDNYPofiQotqcbstqIhSjUThckUUCvMXAaPLHTZJaguCwCYgXBvkaQdTEcqjCEhAxFzJpPNnXNjtufuJVQzlvIABNxcTfpOWsSUWZGqjpBtgHdXYkRUjEMd"));
    this->GpQvRtQwS(string("JTTkKSbtriSVWdfsfXCIgZGmKSIegMyzQgDtxJNJoGZghpOCZqSDvlXup"), string("HPbKcsycpdpBWhFVyyZZkmTvdYepZiWLPXTKciQzXzTkxqpObXizGzXOCcnFMrtCdcsrZFoZXCaWJEIcbctaUaDcLTaNNpdgpVTLyfDIycGYvchGnwlGaUidWahPKMPMcayLQYObRhoWcLxWAMKnvTnewiAzhHnLyESHRTtnhPrBmNBetzQIz"));
    this->anUqbETSQgjDIE(string("mXxYGzFWadyQIBwgzWUyianNfMjYyXGpkRjqQzjmOhSyblkjEouSowNsLSEnuWBxAYyoLpqsVjaIQWnDssjGuuKhNUTJhciJQoGEjpMKxPGxxMMYclbIaTQDhUZIOkbBYWiNHxUVZc"), string("YvMQqzxTnfSfDTZQPVWKjjwLUKMrDMSzfCFrqOCFqiwlrMaUpzgCULMABkhIgrCtIgZENssNHqlVZyVjEXhHDNwHVPLLFpUPIkJAsWBweYSPfAWaWUjUQVgZlrYepWIOkYiTtlarFyASvcIhXLwubVNQJdTTdHWxgcxOedlGSChMMMyXNVbboloKLDRpLZaOwkVFvamuPpSFCplywdCHAfaNCMhDcJkRhSNobbxMtD"), -1636680666, -662940415);
    this->AlnPp(-267752.75470820215, 1580416225, string("dfZuSheQhEisNeYvXVhPBOMudHBrOQlnFVKaKnGqaFhvFWjSHlMnn"), string("uzbTozEaQNyrjOjBHSVqgcVSOkmXczNLjnurbcmvvlrCbOXUQktnhDzxVFMroDWgcsdteDRemqMiLCYGeALDfjQdipLWLNPlfINZcAHjGwMijYTOdrPAQqKhIdCyvOOtbtXPiWdszTTsvcnkyrYKOOnKlnQiIuOcTvyyxOeryrIIrytMZNsgRXXiAkn"), false);
    this->jtQlqe();
    this->EqEzTkOYSNjNk(351519.99033478653);
    this->yWPFEC(2140546191);
    this->MXHoLP(-105412.83804649157);
    this->JiNZwBjycBHJsCE(1559513145, -674035759);
    this->lIJpaozrA(1009187.6161685702, false, -1798173659, -1474593751, 247184722);
    this->iJmqrpINsPgkIj(747973.4411363143, 1885398050, true);
    this->idWctpHLZC(-983163810, 1019196493, -284623.58469140605, true, string("mttDfLpGHRhkkwhkSLRFgNhRopCznHvNlrAcwuOexrlYOEGAlMcIdiMaxJaFiRNKXDwJpMoXRTeROVPzrFa"));
    this->HGqdjOtB(66914171, true, true, false);
    this->VMQKyLl(string("CozZQXydHipWxQXfpGGELYcmkIRCVYxySDeEqaOBsyFxQVleBefeRnPorqNgGrMOidTmPjbPAbxBvOAVKFQhHgXrPNDNffkZFzKnMtQPiBFzvAhobhnjZUghqEmJqQpfmlodqUsbWspgHlOOrQYjlfxbpnrwhdBEwQBDufTjhNHUgGzbVTmqFZzfIRuHuOJxBtTOIMYmcMsZQSOIflKuuYHQNckWQYMJCCQeaAhHaCVvIve"));
    this->jDUzSP(1538731412);
    this->aauSkeFfqtfGALD(971995.080971835, true, string("gQXUIdMKepbOlfbAqnDnWTbbDAkBnAiBRwrRBiSehLkAckLfdOOweLkbnHnEkdbicaJphkOpPoOtVhhDPDKyQFofQDeDVSGXrTGySvNkJUpaWkszEKTsIPklKGHgHJpjchxxpoeCEKtAuQAgpZEBShinCAAMLqjFkcYQbjYprABKECgqhRvMaKUOfAnXeIVrEmKlUnknDzEFmrBcHZHEXuhCXljVOkFHIyqjPFoX"));
    this->vzcbpPirdp(string("OjuecawOVAFOWVIlbyUTMeFINzJAAinhwrnGSyVrmzIrZtbSvanRKrtrCDEPckaFlsfpcRDrAnWITcxoPCnZnCuQlSCJkMEXUiqoJUpuwCqETMUOlWBJVnjHgfKVYeMqWOhjQCaYOCPZHxRYIxkszAdanqCTxnwmGjYDUaxSsgGEsqupsCEJwPNcaIwKHoukAmJadANzxSKLIgCU"));
    this->tGWgZg();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IiMgiOfAogEOddS
{
public:
    int jmYjFQDbAr;
    int cxkgTz;
    string PHrMzIxeUav;
    bool XFKTLGyaThsRkb;
    bool HIfCfCoDGo;
    string tGKQyJBkv;

    IiMgiOfAogEOddS();
    double JsXmWHMeIcsu(string ZdowiGNoxIoB, string gudkfCDcqFeXp, int cfnYcilwrJrOs, string EoQycFSrUjJ, int KDYqIInwm);
    void DOIhssbkzrFaGGZB(string buEGJdSnwFWXBz, double yZfagGcitFlwRoT, int CvBLQQSFiBPOzoX, string wxxaI, string XiuaVQEIeHfJ);
    string PxAGIQWGxEdi(double SsrypmeOTdwFeL, int AznqAwusjkGg, string vqkGVpXtyfh, string XMXOPxENRnSy, bool rFEeWTR);
    double LxJAHanqZwsM(double fOONIwLgBMGontF, string kJiPj, bool xCfYVmUAUFPHYn);
    string uioEitSqyvqU(bool uvIVpuSCmJNlwezt, double RzonyP, bool OZWylP, bool DqUKI);
protected:
    string sddBXKVxdgPW;
    double UUOWXA;
    string OcmrPprCCHoVXY;

    bool NxBShIL(string DRxwkiJVrFGOMl, int oquWlqo);
    string mLlBdrKfsVmRZcyd(string mqGgfx, string aVExMhaJXVWkIo, string lsFUqmBwEuy, string JTLvUA, bool nrUHZfM);
    string XdIERCKkYZDgXU();
    string LuxWTmazYMuKPBe(double RVSsUzg, double UQWgDAiHmnCTj, double hShDChBAahQ, bool GqkWMhh);
    double VyvWHXAECtrKgI();
    double UKwWG(string heFlj);
private:
    double XRRvjuK;
    int VrsglW;
    int lWNJplDJ;
    int aOVkrvO;
    double THDUHnbZojiUbG;

    int XSKpDlKq(string yjYarWjSZ, string hxRBcKLWpqt, bool EPnIneAjHqVMSogm);
    double ROnvcSoYfsvf();
    double xmSqUqMer(double jAdsgdV, bool kCsemvxWzdUZrg, int vVUGdzCmwTy, string gZFLky);
    double KBdrQMVZCUCM(int nGKKulZcBa, int fXzSVSvFLEiBPw);
    int ssiuYGzoCNUwtDa(bool BcIKX);
    string NqRiMaSebfNJI(bool LmwkaOzRGeIPB, int hUWUPPRucCyckng, double KDRBVWyAWCssU, string deWgYQD, bool CaWkZbgPLBXTiu);
    int GjxEsQ(bool FRajCYSowmuG);
    int ZKwtwqtAqzkG(string NSDcPkeTGDoobraU, double YsfRtUPB);
};

double IiMgiOfAogEOddS::JsXmWHMeIcsu(string ZdowiGNoxIoB, string gudkfCDcqFeXp, int cfnYcilwrJrOs, string EoQycFSrUjJ, int KDYqIInwm)
{
    int BeBZGPBZqhWU = -2006306222;
    double uxNtBeTHgTaHunhZ = -864277.3440231842;

    return uxNtBeTHgTaHunhZ;
}

void IiMgiOfAogEOddS::DOIhssbkzrFaGGZB(string buEGJdSnwFWXBz, double yZfagGcitFlwRoT, int CvBLQQSFiBPOzoX, string wxxaI, string XiuaVQEIeHfJ)
{
    double mBFxhsBbcOPGVi = 846816.593346093;
    int RsLME = -887101939;
    string jMUyLyhqwdPq = string("HCiEwxhdadjepcsRDjbjZaUFnuJaUlfITruXlwAERjsBOAsROmsJnRxgxDQleTjclpKTgpdiTGoeGDJHZWIppcTBAnaxPbzgEoCxoednmRBGmGmynjjRvXqCRAZUeDaFlAOYyuTfpVmyGJnfYYvUqoHeFTFLsdygurwFRxtnvbnkJwqsRGRIfxbXGqAn");

    for (int kIOUCj = 1078894512; kIOUCj > 0; kIOUCj--) {
        XiuaVQEIeHfJ += jMUyLyhqwdPq;
        buEGJdSnwFWXBz += XiuaVQEIeHfJ;
    }
}

string IiMgiOfAogEOddS::PxAGIQWGxEdi(double SsrypmeOTdwFeL, int AznqAwusjkGg, string vqkGVpXtyfh, string XMXOPxENRnSy, bool rFEeWTR)
{
    string WLXbeQPjusS = string("CNgSALtWczkbDZmHycpCGykXpitDpkUxiLLlJYLRgFxQgzOBnJzenQYWBeFMNsAjxfKStQavQfChPojioWzINsEGLqzEieryNNZoONrahWslHDloTEdqScqsacIxzNLYUcEzmYSFTvLIrMrsHtTulYxJGewoHGabaSSpcwnSIdziRoGzxwwKLgcBkWxTfpKtWOVNkRZoqqhlnscrvylaftw");
    string iLjDrkVHQP = string("DISveOTxXEFAVfRuaNzGZtEyNprjJHDCFnTOupDVzjxwqIdTDMyajtEepRHTzPLHAzaTMopIqUDNYJIzEGeeztqVnjLcBIBgoBzaVTGBuWWGfwiUFDEyOjRYzhWcJVlKfDjaslVQpLYigEtKzFQDfXPkDQuGAjwgqjsJynUpgoYYeAWbBDSSNzfxxsEybuuLCZMsqIfIHKEvmywgWjaJwBpuZnh");

    if (iLjDrkVHQP >= string("CNgSALtWczkbDZmHycpCGykXpitDpkUxiLLlJYLRgFxQgzOBnJzenQYWBeFMNsAjxfKStQavQfChPojioWzINsEGLqzEieryNNZoONrahWslHDloTEdqScqsacIxzNLYUcEzmYSFTvLIrMrsHtTulYxJGewoHGabaSSpcwnSIdziRoGzxwwKLgcBkWxTfpKtWOVNkRZoqqhlnscrvylaftw")) {
        for (int VSkwqCXYUv = 1146730968; VSkwqCXYUv > 0; VSkwqCXYUv--) {
            XMXOPxENRnSy = XMXOPxENRnSy;
            WLXbeQPjusS += iLjDrkVHQP;
            iLjDrkVHQP = WLXbeQPjusS;
        }
    }

    for (int onKgTlwNSZ = 1832487080; onKgTlwNSZ > 0; onKgTlwNSZ--) {
        AznqAwusjkGg *= AznqAwusjkGg;
        AznqAwusjkGg -= AznqAwusjkGg;
        vqkGVpXtyfh = iLjDrkVHQP;
        rFEeWTR = rFEeWTR;
        XMXOPxENRnSy = iLjDrkVHQP;
    }

    return iLjDrkVHQP;
}

double IiMgiOfAogEOddS::LxJAHanqZwsM(double fOONIwLgBMGontF, string kJiPj, bool xCfYVmUAUFPHYn)
{
    bool lloNuIPRSMgMe = false;
    string xkXRI = string("ibnMkTRPRAuuKIZMcVLYSUprMDyvzJFgTDghdaultmpYUdyqHyJqZmPppWThxkKnAIOEGdTlsxfQGWZqOwoWdeeWdDwUnSlCDnqXCyRgRUteGNWaZedfdUJhtsSOsvlsiHBynCSOSOvDtMfucaKGNvKmLHkAcJvALyRLinBMnpQdxaMfCufFabBiXLOwtTjFKiybctiOjnfM");
    double FZRwfrIq = 243651.9871881254;

    for (int tKtQBR = 944285280; tKtQBR > 0; tKtQBR--) {
        continue;
    }

    if (fOONIwLgBMGontF == 243651.9871881254) {
        for (int OeZhDnZiiFZczAEp = 1290016828; OeZhDnZiiFZczAEp > 0; OeZhDnZiiFZczAEp--) {
            continue;
        }
    }

    for (int tLLejLfcTShsgf = 1075479372; tLLejLfcTShsgf > 0; tLLejLfcTShsgf--) {
        kJiPj += kJiPj;
        kJiPj += kJiPj;
        xkXRI = xkXRI;
    }

    return FZRwfrIq;
}

string IiMgiOfAogEOddS::uioEitSqyvqU(bool uvIVpuSCmJNlwezt, double RzonyP, bool OZWylP, bool DqUKI)
{
    double dhbeUYg = 729608.9648360811;
    int TFzxLYzhnXrrxc = 1646026677;
    string MmRnJRo = string("GCLrbctqPJTQpjgPHDnYHZYWoRnRSeiLeaGsggxplcVttDwCpoLuxHRAZKcqjnvSYfSevhaUNQXZNXwozfAJiXhpgSCdCQoCsjGCiXpdGpqDAYGEupyHEsNFdsOInN");
    double ZMAzlRFBkTmRbCw = -647595.3568498119;
    int NAbseETuvmOQm = 878384596;
    int wWKbsFkCdxK = 1208859253;
    double tWcbs = -228767.67445760168;
    int oPcBRPBj = -681961717;

    for (int baOoZnNfVOZoEE = 99680278; baOoZnNfVOZoEE > 0; baOoZnNfVOZoEE--) {
        wWKbsFkCdxK -= TFzxLYzhnXrrxc;
    }

    for (int ncTSySqUYExDHk = 1109111743; ncTSySqUYExDHk > 0; ncTSySqUYExDHk--) {
        TFzxLYzhnXrrxc *= TFzxLYzhnXrrxc;
    }

    return MmRnJRo;
}

bool IiMgiOfAogEOddS::NxBShIL(string DRxwkiJVrFGOMl, int oquWlqo)
{
    string HVQRsbmzZCzgZcp = string("kbDaHaKgqgjycuOZZqGUylNIzFbTPzXtaWLEqxvQmBqXKRfrqJic");
    double GDfzkItYJxEeEVc = 386255.9790183844;
    bool PLgfGpVmdkkIt = false;
    bool xyZACyFtBkV = true;
    double BMrGXtQeBqbmf = 601753.2657495557;

    return xyZACyFtBkV;
}

string IiMgiOfAogEOddS::mLlBdrKfsVmRZcyd(string mqGgfx, string aVExMhaJXVWkIo, string lsFUqmBwEuy, string JTLvUA, bool nrUHZfM)
{
    int TwPGKZnrvPZziu = -600614887;
    string hnQTYFXIcGjMTPpa = string("WHhQhJXoNEcPMebBNaKWwRKAVLouEqfCGlcCxGavudZIiFNbvdQJNwhpAmfSKDTtrRYdqAlksKxYqYCxslBTrHDFrQWreFmWLWelxQjdrAKNQETAjcIBxYGjTcOWVtizUPyneoSbdoEHNwHRuMAWOvjfeEdWZDCWKwqtBktGSUkCvzYNlbNfEoVSkbEZChBYBdNtWotKgvcdfCJedolmEoyrVUfRFapVmvJUkiXpmMKOaP");
    string ImsGOyNw = string("cAEjTgkbAAoBbEasovjiEosgfoVnWmpvmb");

    if (lsFUqmBwEuy > string("cAEjTgkbAAoBbEasovjiEosgfoVnWmpvmb")) {
        for (int iMqGjYKjsdrhMN = 1805188978; iMqGjYKjsdrhMN > 0; iMqGjYKjsdrhMN--) {
            hnQTYFXIcGjMTPpa = lsFUqmBwEuy;
            aVExMhaJXVWkIo += aVExMhaJXVWkIo;
            ImsGOyNw = JTLvUA;
            mqGgfx += mqGgfx;
        }
    }

    for (int uRlJOUJhckr = 408432774; uRlJOUJhckr > 0; uRlJOUJhckr--) {
        hnQTYFXIcGjMTPpa += lsFUqmBwEuy;
        ImsGOyNw += aVExMhaJXVWkIo;
        aVExMhaJXVWkIo += lsFUqmBwEuy;
        ImsGOyNw += mqGgfx;
    }

    if (aVExMhaJXVWkIo <= string("WHhQhJXoNEcPMebBNaKWwRKAVLouEqfCGlcCxGavudZIiFNbvdQJNwhpAmfSKDTtrRYdqAlksKxYqYCxslBTrHDFrQWreFmWLWelxQjdrAKNQETAjcIBxYGjTcOWVtizUPyneoSbdoEHNwHRuMAWOvjfeEdWZDCWKwqtBktGSUkCvzYNlbNfEoVSkbEZChBYBdNtWotKgvcdfCJedolmEoyrVUfRFapVmvJUkiXpmMKOaP")) {
        for (int RUrxbxzAyEB = 1415263009; RUrxbxzAyEB > 0; RUrxbxzAyEB--) {
            aVExMhaJXVWkIo = lsFUqmBwEuy;
            JTLvUA = hnQTYFXIcGjMTPpa;
            JTLvUA += mqGgfx;
            mqGgfx += mqGgfx;
        }
    }

    return ImsGOyNw;
}

string IiMgiOfAogEOddS::XdIERCKkYZDgXU()
{
    int UhaMFGvBEVRdNfVT = -1213804991;

    if (UhaMFGvBEVRdNfVT == -1213804991) {
        for (int zWaxEMZPEwA = 398166162; zWaxEMZPEwA > 0; zWaxEMZPEwA--) {
            UhaMFGvBEVRdNfVT *= UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT += UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT -= UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT = UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT *= UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT -= UhaMFGvBEVRdNfVT;
        }
    }

    if (UhaMFGvBEVRdNfVT == -1213804991) {
        for (int pOOelGymei = 828449463; pOOelGymei > 0; pOOelGymei--) {
            UhaMFGvBEVRdNfVT -= UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT *= UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT += UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT /= UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT -= UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT += UhaMFGvBEVRdNfVT;
            UhaMFGvBEVRdNfVT += UhaMFGvBEVRdNfVT;
        }
    }

    return string("oTUMsqEBVRvqUobdwBNnGbbIVQkhEXodtndVNfeBWjmsntdLyDxxavrJTIIsKmmVSDNVxEqZgUMckmNVFgOkVIAiMetvDUKFFPCxSJUFdiRIQBuSNzqAiyBQlU");
}

string IiMgiOfAogEOddS::LuxWTmazYMuKPBe(double RVSsUzg, double UQWgDAiHmnCTj, double hShDChBAahQ, bool GqkWMhh)
{
    double ETXSVIn = 225093.38422373126;

    if (hShDChBAahQ >= -172155.27176580712) {
        for (int EmcvKPAYwqN = 1437740834; EmcvKPAYwqN > 0; EmcvKPAYwqN--) {
            UQWgDAiHmnCTj *= hShDChBAahQ;
            UQWgDAiHmnCTj /= RVSsUzg;
            ETXSVIn /= hShDChBAahQ;
            ETXSVIn /= ETXSVIn;
            UQWgDAiHmnCTj = RVSsUzg;
            RVSsUzg *= RVSsUzg;
        }
    }

    for (int viifsZnRSQGOIs = 19310342; viifsZnRSQGOIs > 0; viifsZnRSQGOIs--) {
        UQWgDAiHmnCTj += UQWgDAiHmnCTj;
        ETXSVIn = RVSsUzg;
        UQWgDAiHmnCTj -= RVSsUzg;
        ETXSVIn = UQWgDAiHmnCTj;
        ETXSVIn += RVSsUzg;
        ETXSVIn += hShDChBAahQ;
        UQWgDAiHmnCTj = hShDChBAahQ;
    }

    for (int BetMMZ = 1539794851; BetMMZ > 0; BetMMZ--) {
        ETXSVIn /= UQWgDAiHmnCTj;
        ETXSVIn -= RVSsUzg;
    }

    return string("vpkmwRuPTdkTRIdYguXfA");
}

double IiMgiOfAogEOddS::VyvWHXAECtrKgI()
{
    string hGiBrQMqnksGyY = string("sxTYdrcheQAhhkfVFbVOSGdTkq");
    bool sDoXjkXAD = true;
    bool kPkpRilgmAanl = false;
    double sJTayDgVCnXS = 811930.0371551345;
    int CTYwqkF = -448754605;
    int lHpZwrcvFVRo = 123672114;

    if (lHpZwrcvFVRo > 123672114) {
        for (int tukPgesdRnZyKUpt = 248444734; tukPgesdRnZyKUpt > 0; tukPgesdRnZyKUpt--) {
            continue;
        }
    }

    return sJTayDgVCnXS;
}

double IiMgiOfAogEOddS::UKwWG(string heFlj)
{
    bool sXpxwtyBz = true;

    for (int DvplyZsLqqwYahY = 1468603591; DvplyZsLqqwYahY > 0; DvplyZsLqqwYahY--) {
        heFlj = heFlj;
    }

    if (heFlj < string("yzKseSADcAQzdyFrNCxIBjazQgguMavbinuOtDFVqLzSKxxQzoecKtIlusIewlmgLClnYLnKhVNzZmkIDhoGoEtnTdTsGNTtFdEOPevCUUnfpJdgtBjdFQdRkouyAoLnTcHNUCTsRpWOFMsrzqPMTUJyUOF")) {
        for (int ZVZCjwpqy = 1649245996; ZVZCjwpqy > 0; ZVZCjwpqy--) {
            heFlj = heFlj;
            heFlj += heFlj;
            sXpxwtyBz = ! sXpxwtyBz;
            heFlj = heFlj;
            sXpxwtyBz = sXpxwtyBz;
            sXpxwtyBz = sXpxwtyBz;
            heFlj = heFlj;
        }
    }

    for (int ZcuNou = 1132196603; ZcuNou > 0; ZcuNou--) {
        sXpxwtyBz = sXpxwtyBz;
        sXpxwtyBz = ! sXpxwtyBz;
    }

    if (sXpxwtyBz != true) {
        for (int AtOLus = 1713449062; AtOLus > 0; AtOLus--) {
            heFlj = heFlj;
            heFlj += heFlj;
            sXpxwtyBz = ! sXpxwtyBz;
        }
    }

    return 698919.0066046286;
}

int IiMgiOfAogEOddS::XSKpDlKq(string yjYarWjSZ, string hxRBcKLWpqt, bool EPnIneAjHqVMSogm)
{
    int JgllTXA = -203123792;
    bool aOfZiZqwlu = true;
    bool JzDDeJLh = false;

    if (yjYarWjSZ < string("IvXKyyssWTCchTKBBpSWLIqnNEYGaCtUNBkzuUprxnstETALyEbzgzcbghWCHSXBjKoPDfVooYzQrJjBTgQ")) {
        for (int zEyDcJVuftXUipkA = 871456335; zEyDcJVuftXUipkA > 0; zEyDcJVuftXUipkA--) {
            aOfZiZqwlu = JzDDeJLh;
            aOfZiZqwlu = ! JzDDeJLh;
        }
    }

    if (JgllTXA == -203123792) {
        for (int zhDfq = 1102468034; zhDfq > 0; zhDfq--) {
            JgllTXA /= JgllTXA;
            hxRBcKLWpqt = hxRBcKLWpqt;
            JzDDeJLh = ! EPnIneAjHqVMSogm;
        }
    }

    for (int JaMslLa = 1353940408; JaMslLa > 0; JaMslLa--) {
        hxRBcKLWpqt += hxRBcKLWpqt;
        JgllTXA += JgllTXA;
        aOfZiZqwlu = ! JzDDeJLh;
    }

    return JgllTXA;
}

double IiMgiOfAogEOddS::ROnvcSoYfsvf()
{
    string lFkjTi = string("XrhKWsYpxppMzIKIcpZeMNngvuLGAaeYuAs");
    int DDtApyWiDulAO = 1399427387;
    string wEmqaB = string("BIsIFuKJIaAXcpzAJdMkyUDkoIyEwLNGJuwdNmwvztAhmuSeOtWRBpLknzGmvmWlmxGIpPnvWmNbcmsALWJEhvQjErgMXEcCCupKBWKQzFZdKRViUawwbViExevsWFtFRTulphrTtSXBBFHwSJEnyyZYDjUXcugQFxuAwGbLPBhHBLlBagsoRmZxjhFVEBGisPFwUhaDQJhkUWrtkRuMofZpxOGLTixWlIRDWXyxCWBIaFvAwV");
    bool nNALWrsQAUTyX = false;
    int qiGiDhNZbmGynq = 1070519994;

    if (qiGiDhNZbmGynq >= 1399427387) {
        for (int XbeYHhwPMrXPlT = 720087624; XbeYHhwPMrXPlT > 0; XbeYHhwPMrXPlT--) {
            continue;
        }
    }

    for (int WJzFcb = 63764410; WJzFcb > 0; WJzFcb--) {
        continue;
    }

    return 290134.4919728037;
}

double IiMgiOfAogEOddS::xmSqUqMer(double jAdsgdV, bool kCsemvxWzdUZrg, int vVUGdzCmwTy, string gZFLky)
{
    bool BPViIl = true;
    bool tHedItMnNNEUGHBE = true;

    for (int tHbsrZ = 39093085; tHbsrZ > 0; tHbsrZ--) {
        kCsemvxWzdUZrg = kCsemvxWzdUZrg;
        kCsemvxWzdUZrg = tHedItMnNNEUGHBE;
        BPViIl = ! tHedItMnNNEUGHBE;
        BPViIl = ! tHedItMnNNEUGHBE;
    }

    if (vVUGdzCmwTy >= -1037766208) {
        for (int HUbcawLb = 1966797357; HUbcawLb > 0; HUbcawLb--) {
            kCsemvxWzdUZrg = ! tHedItMnNNEUGHBE;
            BPViIl = BPViIl;
        }
    }

    for (int aGyrceQyd = 1837547351; aGyrceQyd > 0; aGyrceQyd--) {
        tHedItMnNNEUGHBE = ! kCsemvxWzdUZrg;
        tHedItMnNNEUGHBE = ! tHedItMnNNEUGHBE;
        kCsemvxWzdUZrg = kCsemvxWzdUZrg;
    }

    return jAdsgdV;
}

double IiMgiOfAogEOddS::KBdrQMVZCUCM(int nGKKulZcBa, int fXzSVSvFLEiBPw)
{
    int ZvUTxdsCKQPIJbE = 214304962;
    int hIuQkVaxUMZO = 1799383494;

    if (ZvUTxdsCKQPIJbE > 126971199) {
        for (int fZAGkjztUiCHbFg = 841986101; fZAGkjztUiCHbFg > 0; fZAGkjztUiCHbFg--) {
            ZvUTxdsCKQPIJbE *= ZvUTxdsCKQPIJbE;
            fXzSVSvFLEiBPw *= fXzSVSvFLEiBPw;
            nGKKulZcBa *= ZvUTxdsCKQPIJbE;
            ZvUTxdsCKQPIJbE = nGKKulZcBa;
        }
    }

    if (hIuQkVaxUMZO == 1799383494) {
        for (int hAgyjoNHSnc = 564222571; hAgyjoNHSnc > 0; hAgyjoNHSnc--) {
            nGKKulZcBa /= hIuQkVaxUMZO;
            fXzSVSvFLEiBPw *= hIuQkVaxUMZO;
            hIuQkVaxUMZO *= fXzSVSvFLEiBPw;
            ZvUTxdsCKQPIJbE *= nGKKulZcBa;
            hIuQkVaxUMZO -= hIuQkVaxUMZO;
            hIuQkVaxUMZO -= fXzSVSvFLEiBPw;
            fXzSVSvFLEiBPw *= nGKKulZcBa;
            nGKKulZcBa -= fXzSVSvFLEiBPw;
            hIuQkVaxUMZO /= fXzSVSvFLEiBPw;
        }
    }

    if (fXzSVSvFLEiBPw == 126971199) {
        for (int cQWmjtCsgZSCF = 1747285632; cQWmjtCsgZSCF > 0; cQWmjtCsgZSCF--) {
            ZvUTxdsCKQPIJbE *= fXzSVSvFLEiBPw;
            hIuQkVaxUMZO = ZvUTxdsCKQPIJbE;
            nGKKulZcBa /= fXzSVSvFLEiBPw;
            fXzSVSvFLEiBPw /= ZvUTxdsCKQPIJbE;
            ZvUTxdsCKQPIJbE = nGKKulZcBa;
            nGKKulZcBa = nGKKulZcBa;
            ZvUTxdsCKQPIJbE /= nGKKulZcBa;
            nGKKulZcBa += hIuQkVaxUMZO;
            nGKKulZcBa = ZvUTxdsCKQPIJbE;
        }
    }

    if (ZvUTxdsCKQPIJbE != 1943463225) {
        for (int KvfOUIpxidp = 953728114; KvfOUIpxidp > 0; KvfOUIpxidp--) {
            nGKKulZcBa /= fXzSVSvFLEiBPw;
            hIuQkVaxUMZO = hIuQkVaxUMZO;
            ZvUTxdsCKQPIJbE /= nGKKulZcBa;
        }
    }

    if (hIuQkVaxUMZO == 126971199) {
        for (int LLofSkBicBq = 236418542; LLofSkBicBq > 0; LLofSkBicBq--) {
            ZvUTxdsCKQPIJbE -= hIuQkVaxUMZO;
            fXzSVSvFLEiBPw = fXzSVSvFLEiBPw;
            ZvUTxdsCKQPIJbE /= ZvUTxdsCKQPIJbE;
            fXzSVSvFLEiBPw -= fXzSVSvFLEiBPw;
            fXzSVSvFLEiBPw /= nGKKulZcBa;
            nGKKulZcBa *= nGKKulZcBa;
            fXzSVSvFLEiBPw += fXzSVSvFLEiBPw;
            fXzSVSvFLEiBPw *= hIuQkVaxUMZO;
            ZvUTxdsCKQPIJbE /= ZvUTxdsCKQPIJbE;
        }
    }

    return 255719.94250680777;
}

int IiMgiOfAogEOddS::ssiuYGzoCNUwtDa(bool BcIKX)
{
    double WxsozQJAPVUm = 743141.9374490948;
    bool Zuypc = true;
    string OwBLQjYWG = string("oFfwTwiGjGxIeDMhNFskfLwMypHEeePNmrdHxZZCitDxlUQnxTSJoCaLlLmrQjJIXsnbJhztRhSwqxUSyBmSjblXgFCblcRWzxEY");
    int OQNvDBxolgPNQmqj = 1336562691;
    bool UefQS = true;
    int vKjNQbLjzSxUw = 1305370940;
    int OnFTgrgecnX = 1139059163;
    double FuRkz = -787729.2376984196;
    string SBIpc = string("nNXWHppNUOFCZkPrOiCQHTMglauHRELXtLZVeMWkxMahYdpLjyFCSymIrPUDUDgkAVPXbtYwLGyFuZoimwcaXipqxxtOHXvrYUMJaTRRPUxrCeTr");
    double yhbeUuKWYu = -979974.9778622672;

    for (int ZZVrLmmczuvZU = 1483354952; ZZVrLmmczuvZU > 0; ZZVrLmmczuvZU--) {
        vKjNQbLjzSxUw = vKjNQbLjzSxUw;
        FuRkz -= FuRkz;
        Zuypc = ! UefQS;
    }

    if (yhbeUuKWYu >= 743141.9374490948) {
        for (int cCjeFctB = 792431310; cCjeFctB > 0; cCjeFctB--) {
            OwBLQjYWG = SBIpc;
        }
    }

    for (int NldafTCAmhKXHO = 1567978265; NldafTCAmhKXHO > 0; NldafTCAmhKXHO--) {
        OQNvDBxolgPNQmqj *= OQNvDBxolgPNQmqj;
        vKjNQbLjzSxUw /= OQNvDBxolgPNQmqj;
    }

    if (vKjNQbLjzSxUw >= 1336562691) {
        for (int gfiIn = 278828534; gfiIn > 0; gfiIn--) {
            SBIpc += OwBLQjYWG;
            FuRkz /= FuRkz;
            yhbeUuKWYu += FuRkz;
        }
    }

    return OnFTgrgecnX;
}

string IiMgiOfAogEOddS::NqRiMaSebfNJI(bool LmwkaOzRGeIPB, int hUWUPPRucCyckng, double KDRBVWyAWCssU, string deWgYQD, bool CaWkZbgPLBXTiu)
{
    double jarJIbgUoGcqTyX = -1001685.6774153761;
    bool QDGvSFhWn = false;
    int vmNFFJTPFpaar = -1643989539;
    bool NBspzBQlmdqoadlA = false;
    double fGBabjOBqNsOFyd = 794076.5736950061;
    string glXspSKkL = string("lDePvRiHrrjNMHXbtVdDSpSoRtHGVCUpGuhRwPjaEkpDETSKyAuwBigBhRdWRSOZTWrFhQFrD");
    bool aTMMKYxFGIWdJAh = false;
    int kTnoSMtsuTxtVYX = 1022718537;

    if (NBspzBQlmdqoadlA != true) {
        for (int XBDJHjURboSAe = 1370042047; XBDJHjURboSAe > 0; XBDJHjURboSAe--) {
            kTnoSMtsuTxtVYX -= vmNFFJTPFpaar;
            kTnoSMtsuTxtVYX /= kTnoSMtsuTxtVYX;
            KDRBVWyAWCssU *= jarJIbgUoGcqTyX;
        }
    }

    for (int TBtklRH = 206316150; TBtklRH > 0; TBtklRH--) {
        fGBabjOBqNsOFyd = KDRBVWyAWCssU;
        KDRBVWyAWCssU *= KDRBVWyAWCssU;
    }

    for (int jaeClTio = 722946375; jaeClTio > 0; jaeClTio--) {
        kTnoSMtsuTxtVYX /= kTnoSMtsuTxtVYX;
        LmwkaOzRGeIPB = ! LmwkaOzRGeIPB;
        glXspSKkL = deWgYQD;
        aTMMKYxFGIWdJAh = LmwkaOzRGeIPB;
        CaWkZbgPLBXTiu = ! QDGvSFhWn;
    }

    if (deWgYQD < string("NUmTAqllolRDmINLjkJQvnRgAKvHpHgrcryJY")) {
        for (int lRmXEsMMb = 1054868634; lRmXEsMMb > 0; lRmXEsMMb--) {
            hUWUPPRucCyckng = vmNFFJTPFpaar;
            CaWkZbgPLBXTiu = NBspzBQlmdqoadlA;
            kTnoSMtsuTxtVYX += hUWUPPRucCyckng;
            NBspzBQlmdqoadlA = LmwkaOzRGeIPB;
        }
    }

    return glXspSKkL;
}

int IiMgiOfAogEOddS::GjxEsQ(bool FRajCYSowmuG)
{
    bool GryrJRSr = true;
    string iwOSeVsJx = string("YnkIKWNKMoFCbxoaDGhNoMMJVlokgTJRDOlMWeKLbbstr");
    string ixyYoBSbzCBCF = string("FlZPJSFaRbelhaEWZTnTQoITWAsdTmqNOUqQtncQKwHeLYnKEpggYrKUiQkveYCaDGBwTiUVUQvJqoAyprMWICnCJOOVSvFkrdKrTWfolVvSzGvudhzaDilpDFfBZIywjwWzQBchPHCgENmIWmQOwKyqPVuRQvtdCOViIufHuGfytfRhqvnbfTNaJeIXjZgUXJTYDQrZMyiFDEmDAjcQYbRWM");
    bool ICbUntU = true;
    double anoFAxDiRSFVuLJG = -669164.3780441221;
    bool irCPC = true;
    string TCOgmxeG = string("oSVFkgWzuDdtbfmRflueeKkuExfbHEbhpEdyBxwMVctqODwQqDqwXeERRvvcCXagJrClrpyRmSDTTsnGcvbbcnLAmtKYAxtvoIipBRGttlNHdCjkADIdYluklOlJXsODhoBPOhdqOhZMTgiJQIJLCiFwqcPzYJTuooxAgfSxnkjtKfyCfGjDwFnZDRJNjPeNeIczrbTvVheLrdERzvkKMQdzCLqTTEqxSGfuGZbyyQuqhBPAcXTwFrHnE");

    if (ICbUntU != true) {
        for (int OOlSoqVbopaSIbP = 1957903048; OOlSoqVbopaSIbP > 0; OOlSoqVbopaSIbP--) {
            continue;
        }
    }

    if (GryrJRSr != false) {
        for (int qrsyLkdLJT = 841732441; qrsyLkdLJT > 0; qrsyLkdLJT--) {
            FRajCYSowmuG = FRajCYSowmuG;
        }
    }

    for (int NbDGuanOIvVg = 1808854571; NbDGuanOIvVg > 0; NbDGuanOIvVg--) {
        ICbUntU = FRajCYSowmuG;
    }

    for (int lpbRUhLgnEV = 783370578; lpbRUhLgnEV > 0; lpbRUhLgnEV--) {
        ixyYoBSbzCBCF = iwOSeVsJx;
        GryrJRSr = ! GryrJRSr;
    }

    if (GryrJRSr == true) {
        for (int XUpCnFMhxTv = 405782570; XUpCnFMhxTv > 0; XUpCnFMhxTv--) {
            FRajCYSowmuG = GryrJRSr;
        }
    }

    for (int KPEAnXg = 740584887; KPEAnXg > 0; KPEAnXg--) {
        continue;
    }

    return 1601863519;
}

int IiMgiOfAogEOddS::ZKwtwqtAqzkG(string NSDcPkeTGDoobraU, double YsfRtUPB)
{
    double mYJPdLoVJV = 953589.5606941307;
    bool MQFxtgzDgpUuf = true;
    double CeZbpIH = 584021.7209699955;
    string jZtBFQdQGeoJkU = string("SkfYjwCNVqfFPGepvndIlJIAFircOWaLjgvuhvuaRTaQrdhqWkiTPXwKtNlomivwOAbNfvkQbZSSfwgOPkkmLUweBQIeMxDxRZDTRsUhkBvOOujgXUsshouOVLBbiFxRlahWlUSWoqBnzcqyMQpSfXeinNmrmKAzndjkwhpDWJblFednkSNnKJOEYMAkhrhXxaRUqgsWrDBJmDrxNXQfVhUKEfgXzjhEFmmhspgONmZtEZWGahUVYeS");
    int VkihBjCyqOhMT = -1371162385;
    int nZBWb = -1277321429;
    int nnLXKlnmTk = -1154312368;

    if (YsfRtUPB < 994270.3514786838) {
        for (int wFmSbRogW = 1286471878; wFmSbRogW > 0; wFmSbRogW--) {
            YsfRtUPB += YsfRtUPB;
        }
    }

    for (int aHzRgLtUmvrYjZZ = 601586947; aHzRgLtUmvrYjZZ > 0; aHzRgLtUmvrYjZZ--) {
        continue;
    }

    return nnLXKlnmTk;
}

IiMgiOfAogEOddS::IiMgiOfAogEOddS()
{
    this->JsXmWHMeIcsu(string("CvwJonjnqVirK"), string("KjMdggTBdvHGsSRfxPKJFgc"), 1105785959, string("zErAfoxdllQEYoUfZsCVfKqsz"), -960564646);
    this->DOIhssbkzrFaGGZB(string("xqFIOtvxtCjydinfIiTlEmBiXBviRdozxfnithMEwZRMuOhCfbPHwL"), -215448.8160908573, 1617791953, string("krKeTGrQpeROzUijzCvTdqIsbpmVjINdKpOHudcBEMOBaGRlniaGvxKdgGRxpHridfhlFMzQWAbFJQAbVwUpAgAegzlnFmALFguwgocldMNYDFDbWJRnYTaDxwotjEhEumqpvAGIEIyRUUwCmbrqzzwjoBxZFJezDSxMFToUnWWzdBYHBhJEwgGSEbuxHmkZZaYYJooQlTgFeAcgFSydeSADvXGFrKBsKsK"), string("OpaWwbQVmZfDTaAOlwObNhUyNUdDHjnWTkyJhWfZrgiFbfSsxSDNoBKaFDzMaEDdwHhNBdFDpIaARhVQRKZRksyIsOntpxgbTtSWlABaNirqrYffXlcyXOqbvvdByPGsBebHcORAuabRUBMZsRdOWPipdvuOMyCaISeQYRwbsJmwnMnSaCqvMLcHxcNmLFyeYZQXsINNJbSkvizUcKiYwcLAqNIgMNWVImRswuocAzCrxfCzvL"));
    this->PxAGIQWGxEdi(130928.68920659757, 397163027, string("sMgDoGZGaJAzCCNoMCxfzAfaNQD"), string("PjGmOKsTggseKPhklJXryOBEkSfIhhZnWuDsjNNKSzLBLKexxYqVlPEdzZXQbmwwsZRXGANWqvHVuAgFCQhVxNnlTajjtRGuzlogGaIPLMPthkJCwDkgMrXHDTJgqBTaUvbCLehyijYMWKEnaHbWyAQqnHlRMUOXtSGuMiqFCgImMnZiNHNUEBecEeUoUDPVLQOYpQjZXtrXAOWCvlpkkUngKbNAOLRibQbQVgdPNxVgrLnWoiInS"), false);
    this->LxJAHanqZwsM(-931240.0532947145, string("dENVMjzTEHpKEpdhxyKLQviSWwkhGExCiNZZGOIpKUibGLMETHIZDtmZcXDAztBgtvtVLzHuKsuLHWAEHMrrCWyYZCEOiMbaBdUHcxxYQIjLVLIzHcxtDJSMIpiuZFGbdQYohEWQHqUAYmWfawuEfEnfFpEdzbYRAXjZdsJETbqpeptgnMGyrdpZNFgphwANyXZvWHbmEAhZnJSZmUNXLxlREpVcwmylROwVEFdbZsJ"), true);
    this->uioEitSqyvqU(true, -268598.04070037074, true, false);
    this->NxBShIL(string("RrYQJWCCqZEFGptrbdaxlJlKHsXXOvLhTtDhADQMCGCrtEay"), -103417614);
    this->mLlBdrKfsVmRZcyd(string("QKijdQHeVszNZpTqQrZVKGmzieWmloTtxByGjvPvNbtVAFhbjcyNrQMlsNMWvrkuzzzSPyqrNn"), string("nDIRWKpTKMzengoUuSGMNGUXEDwQPHSBAtHrAbcaEtXiyLynEYhNQewXocVSWhzFJKxbeIimNhAFEsmjAfhMENfjIFvqDVTYWQrPgqUKFSGfuexwuBUagtGhUUhpwQJgfrLSqNhXutbikxsvtDMmRmCYYHNOigWJFsuHGvdKfgwIXDwuKEFcDNIPOavglYBdwKvTeqzXfOMZjpVDoIYLBDWpSyfuSY"), string("KakkZfsBigFTaoLvTHPtbaxSEoxkCswUcEHeNfuWFpshQQpZg"), string("essBKzNXgkivsFNgLNgrOTWufYoylLXeMaIqsAeMcSZLuAwZYQLHGqTxZyaCEsehBIQFXPQmuTcCoVqimLSMNBdpBELucISzYcskHubstKpQdFSbKgkOdOuOrdFjNSDBBKWnrrhCKheimbHvMaqGRpFfKFtJCKkJCxBbyXDZfNIFZbCIOFQzthiFvelgerGnvolEhfwdBEwBVTZhVgOcC"), true);
    this->XdIERCKkYZDgXU();
    this->LuxWTmazYMuKPBe(-380801.7242447837, -172155.27176580712, -357195.2797736842, true);
    this->VyvWHXAECtrKgI();
    this->UKwWG(string("yzKseSADcAQzdyFrNCxIBjazQgguMavbinuOtDFVqLzSKxxQzoecKtIlusIewlmgLClnYLnKhVNzZmkIDhoGoEtnTdTsGNTtFdEOPevCUUnfpJdgtBjdFQdRkouyAoLnTcHNUCTsRpWOFMsrzqPMTUJyUOF"));
    this->XSKpDlKq(string("IvXKyyssWTCchTKBBpSWLIqnNEYGaCtUNBkzuUprxnstETALyEbzgzcbghWCHSXBjKoPDfVooYzQrJjBTgQ"), string("xcJtsVVWxjciWqMhFfrRBQpUpBvIvwbmqJmpNQiFaHhzuxKcVfLkWdrqcKdNdfjEXwLeByOIXDzfH"), true);
    this->ROnvcSoYfsvf();
    this->xmSqUqMer(762021.2888766573, true, -1037766208, string("ZOpLHVIKuzXpmeSaQyzoUVhpDrJAfOlxsMecvmwtSKBeOlVlTfLuzVbTvOXrBVmjHOqYEsfpKXptwTGCiZGCEKFbysPFiLZRtbBNuqheBltrkESTNsRgsEKFNPpaFSpnrJlUjjsgZSGMYsQqDeNfOaeIlReSOkuKcUJLBZUtkurBkCcvRE"));
    this->KBdrQMVZCUCM(1943463225, 126971199);
    this->ssiuYGzoCNUwtDa(true);
    this->NqRiMaSebfNJI(true, 1091498896, -202091.96298219217, string("NUmTAqllolRDmINLjkJQvnRgAKvHpHgrcryJY"), true);
    this->GjxEsQ(false);
    this->ZKwtwqtAqzkG(string("wKbTZAYBOdGZLkkmfwnuVIAQVOjQOpvmlHvWzUWbRTNesaSBOLuBzeiZlWyGNiDrgZWADXLKvJudjnMvgYiZvpINQsJEXKVkOtMqyBNcxgUMoPjqsQytfJevxwVRcTQUciRlKpHEALoPHdbBazKuiDSyfsVqnNbCRgTmBAyOUKaoXYKGAbUTXatFDrzBoLjIvAWqSIRqihBJefkwPYRGsGBxtuIeUXGQPMBuDEPejszncknCvhEK"), 994270.3514786838);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class keBhXCJV
{
public:
    double VJTWyU;
    bool kssPiyRePOTTa;
    int yuqdOKUuIipqzF;
    int rcwcgxKn;
    double FEFpYT;
    int tzrEtFtBS;

    keBhXCJV();
    double CrCALZomYVFdZGK();
    int pnnswZI(double lCnoPmscC, double UvMLvLW, string pXXxO);
protected:
    double OeWdG;
    bool uDfDxbv;

    void oIKis(string THvSZkNXLEv, double HnFBcXaLtGxvRMBb);
    double qMOqcJAEBBQ(bool yHsbbC, int XKXrVx, string wlkEWPeL);
    int VEataEO(double qljwn);
    bool lNNRmwIWpC(string RxIpftZ, double IkjGTxnZnZNVbFKe);
private:
    bool FVunfkbcRQfSA;

    bool mIytnCuYvMBjVQsQ(bool PnVFXWv, string yCeRZkNVfDN, string qnueTPNaBLxLuZG, string tXcVrfvyoAWHakm, double IIrakWHaIliJN);
    void IEYcFbdROvP(int yVqEIK, bool cWJfMFXjW, double ismCxpnZNXYa);
    bool guFQAUfL(int uiNRk, int ESvOSUo, string JPoCmuKu, bool ofYmadoZJAR);
    void yAVkc(string hUAhCrzxcGK, double NKQdlA, double jhojrGnlGJf, string QsEJkmuVuUr);
};

double keBhXCJV::CrCALZomYVFdZGK()
{
    int YJQkRU = -2124398121;
    double ZDkrmVAQO = -608247.0953158921;
    bool PxWsnSVJbLxAIR = false;

    if (PxWsnSVJbLxAIR != false) {
        for (int sBozESrcylII = 1328644675; sBozESrcylII > 0; sBozESrcylII--) {
            PxWsnSVJbLxAIR = ! PxWsnSVJbLxAIR;
        }
    }

    if (ZDkrmVAQO > -608247.0953158921) {
        for (int vjmVMFj = 1977200608; vjmVMFj > 0; vjmVMFj--) {
            YJQkRU = YJQkRU;
        }
    }

    return ZDkrmVAQO;
}

int keBhXCJV::pnnswZI(double lCnoPmscC, double UvMLvLW, string pXXxO)
{
    int BXYDriOXjZ = 1657928132;
    double NetIkrLc = -26031.175126986833;
    double VQVdIsbq = 711698.2214490344;
    double wWRnPEbYteFUt = 77708.61753048585;
    int KOhybwUmCnd = -319425146;
    bool xaJCpOtO = true;

    for (int XQCqqWrEIoPLeBBA = 1391583173; XQCqqWrEIoPLeBBA > 0; XQCqqWrEIoPLeBBA--) {
        UvMLvLW = wWRnPEbYteFUt;
        UvMLvLW = wWRnPEbYteFUt;
    }

    for (int tPDCOQPtMk = 905706556; tPDCOQPtMk > 0; tPDCOQPtMk--) {
        lCnoPmscC = UvMLvLW;
        wWRnPEbYteFUt -= wWRnPEbYteFUt;
    }

    return KOhybwUmCnd;
}

void keBhXCJV::oIKis(string THvSZkNXLEv, double HnFBcXaLtGxvRMBb)
{
    double MDmrKRLfgZGTG = 410498.4837003391;
    double caltEV = -874072.1518554603;
    int CGkyrRHxEytu = 689750676;
    bool MfvtlAfJlOnn = true;
    int cYrlKqWoleiuvQ = -1908635594;
    int ecHcGwyCxwXQleY = -876245555;

    for (int VVvKTDsWekGHwW = 1167039213; VVvKTDsWekGHwW > 0; VVvKTDsWekGHwW--) {
        caltEV -= caltEV;
    }

    if (caltEV <= -874072.1518554603) {
        for (int mFYAXesuLPd = 861926975; mFYAXesuLPd > 0; mFYAXesuLPd--) {
            HnFBcXaLtGxvRMBb *= MDmrKRLfgZGTG;
            HnFBcXaLtGxvRMBb *= caltEV;
        }
    }

    if (cYrlKqWoleiuvQ <= 689750676) {
        for (int eHJdeoRqHrmoanIb = 818075691; eHJdeoRqHrmoanIb > 0; eHJdeoRqHrmoanIb--) {
            ecHcGwyCxwXQleY -= ecHcGwyCxwXQleY;
        }
    }

    for (int quWQfUWnv = 126920923; quWQfUWnv > 0; quWQfUWnv--) {
        ecHcGwyCxwXQleY -= ecHcGwyCxwXQleY;
    }

    for (int zogHPOZXWdaHZdF = 211483241; zogHPOZXWdaHZdF > 0; zogHPOZXWdaHZdF--) {
        MDmrKRLfgZGTG *= HnFBcXaLtGxvRMBb;
        MfvtlAfJlOnn = MfvtlAfJlOnn;
    }

    if (cYrlKqWoleiuvQ > -876245555) {
        for (int GhnJheQSiZ = 1205922207; GhnJheQSiZ > 0; GhnJheQSiZ--) {
            cYrlKqWoleiuvQ = CGkyrRHxEytu;
            HnFBcXaLtGxvRMBb -= caltEV;
            ecHcGwyCxwXQleY *= cYrlKqWoleiuvQ;
        }
    }

    for (int tEQEqGv = 364714040; tEQEqGv > 0; tEQEqGv--) {
        ecHcGwyCxwXQleY *= CGkyrRHxEytu;
    }
}

double keBhXCJV::qMOqcJAEBBQ(bool yHsbbC, int XKXrVx, string wlkEWPeL)
{
    int FwzKKmAQbu = -1915617635;
    string tCkMUQ = string("TFYTIeiLBIRLDsRRXSSGLkceBqinNfSxIyNQCyedzpTKHUYBGPWsrGGsHheJuWLsEZFOWuUcOBmigAcNZEAoLMgYNfAdYaQpPpptzskFDoMmJXhLaNzigyfyrfwxXchiQYtGpDAXUYmTMcMdBBEUBzrVNpkTBlkuFBiZLZciKOmNMxvpqFReTshgzAmMgMWSjmMuAvoGNwkVxfy");
    double oYktdbYoYD = 922273.7600452455;
    bool XsmCoaDbxYK = false;
    double dfZWN = -511111.7910549583;

    for (int YQHIKeUkRMSUT = 1024529003; YQHIKeUkRMSUT > 0; YQHIKeUkRMSUT--) {
        dfZWN = oYktdbYoYD;
        dfZWN += dfZWN;
    }

    for (int WcMLgzFfImZQTSA = 683549145; WcMLgzFfImZQTSA > 0; WcMLgzFfImZQTSA--) {
        XKXrVx -= XKXrVx;
        FwzKKmAQbu = XKXrVx;
        wlkEWPeL = wlkEWPeL;
    }

    if (tCkMUQ > string("TFYTIeiLBIRLDsRRXSSGLkceBqinNfSxIyNQCyedzpTKHUYBGPWsrGGsHheJuWLsEZFOWuUcOBmigAcNZEAoLMgYNfAdYaQpPpptzskFDoMmJXhLaNzigyfyrfwxXchiQYtGpDAXUYmTMcMdBBEUBzrVNpkTBlkuFBiZLZciKOmNMxvpqFReTshgzAmMgMWSjmMuAvoGNwkVxfy")) {
        for (int ZdAPUGlmYeVM = 1093171296; ZdAPUGlmYeVM > 0; ZdAPUGlmYeVM--) {
            continue;
        }
    }

    for (int TFKSUCBeD = 1980823793; TFKSUCBeD > 0; TFKSUCBeD--) {
        continue;
    }

    return dfZWN;
}

int keBhXCJV::VEataEO(double qljwn)
{
    bool zUtHIeEPObGTN = false;
    int YDPaEFbSTnmcVvvw = 553511279;
    double cVcccNHSbpWXuF = 311153.28297624324;

    for (int wRCyYETQgLPRHIGj = 1783614733; wRCyYETQgLPRHIGj > 0; wRCyYETQgLPRHIGj--) {
        YDPaEFbSTnmcVvvw -= YDPaEFbSTnmcVvvw;
        zUtHIeEPObGTN = ! zUtHIeEPObGTN;
        cVcccNHSbpWXuF /= cVcccNHSbpWXuF;
        cVcccNHSbpWXuF += cVcccNHSbpWXuF;
        cVcccNHSbpWXuF -= qljwn;
        YDPaEFbSTnmcVvvw -= YDPaEFbSTnmcVvvw;
    }

    for (int ukhdheQPiuy = 279551870; ukhdheQPiuy > 0; ukhdheQPiuy--) {
        zUtHIeEPObGTN = zUtHIeEPObGTN;
    }

    for (int mbZoUsekroLqJzhY = 718405509; mbZoUsekroLqJzhY > 0; mbZoUsekroLqJzhY--) {
        continue;
    }

    if (zUtHIeEPObGTN != false) {
        for (int qslhiuANBMWBoTiv = 895228796; qslhiuANBMWBoTiv > 0; qslhiuANBMWBoTiv--) {
            cVcccNHSbpWXuF *= cVcccNHSbpWXuF;
            zUtHIeEPObGTN = zUtHIeEPObGTN;
            qljwn = qljwn;
            cVcccNHSbpWXuF *= cVcccNHSbpWXuF;
        }
    }

    for (int jCOBU = 1812600529; jCOBU > 0; jCOBU--) {
        cVcccNHSbpWXuF += cVcccNHSbpWXuF;
        zUtHIeEPObGTN = ! zUtHIeEPObGTN;
        cVcccNHSbpWXuF += cVcccNHSbpWXuF;
        zUtHIeEPObGTN = ! zUtHIeEPObGTN;
    }

    for (int gveNQ = 802153637; gveNQ > 0; gveNQ--) {
        zUtHIeEPObGTN = ! zUtHIeEPObGTN;
        qljwn -= qljwn;
        qljwn -= qljwn;
    }

    return YDPaEFbSTnmcVvvw;
}

bool keBhXCJV::lNNRmwIWpC(string RxIpftZ, double IkjGTxnZnZNVbFKe)
{
    double zPJldxfiYo = -204469.97868908936;

    if (IkjGTxnZnZNVbFKe >= -204469.97868908936) {
        for (int zoRJiCqRU = 1670238897; zoRJiCqRU > 0; zoRJiCqRU--) {
            zPJldxfiYo += zPJldxfiYo;
        }
    }

    return false;
}

bool keBhXCJV::mIytnCuYvMBjVQsQ(bool PnVFXWv, string yCeRZkNVfDN, string qnueTPNaBLxLuZG, string tXcVrfvyoAWHakm, double IIrakWHaIliJN)
{
    int WdWeJHofJ = -1718818368;
    int ehUrtYKrdLOsMy = 1271998638;

    for (int JkjEArcZLsCLSIu = 1537621103; JkjEArcZLsCLSIu > 0; JkjEArcZLsCLSIu--) {
        qnueTPNaBLxLuZG += yCeRZkNVfDN;
        tXcVrfvyoAWHakm += qnueTPNaBLxLuZG;
        yCeRZkNVfDN += qnueTPNaBLxLuZG;
        tXcVrfvyoAWHakm = qnueTPNaBLxLuZG;
    }

    for (int thDwcyjTZYq = 231307435; thDwcyjTZYq > 0; thDwcyjTZYq--) {
        ehUrtYKrdLOsMy += ehUrtYKrdLOsMy;
        yCeRZkNVfDN = tXcVrfvyoAWHakm;
        yCeRZkNVfDN += qnueTPNaBLxLuZG;
        WdWeJHofJ += ehUrtYKrdLOsMy;
    }

    for (int Afbss = 294284155; Afbss > 0; Afbss--) {
        qnueTPNaBLxLuZG = yCeRZkNVfDN;
        tXcVrfvyoAWHakm = tXcVrfvyoAWHakm;
        WdWeJHofJ *= ehUrtYKrdLOsMy;
    }

    for (int GdkGDYcZ = 1382779824; GdkGDYcZ > 0; GdkGDYcZ--) {
        yCeRZkNVfDN = yCeRZkNVfDN;
        qnueTPNaBLxLuZG += yCeRZkNVfDN;
    }

    for (int lgTTE = 1041352415; lgTTE > 0; lgTTE--) {
        WdWeJHofJ *= WdWeJHofJ;
        IIrakWHaIliJN /= IIrakWHaIliJN;
    }

    return PnVFXWv;
}

void keBhXCJV::IEYcFbdROvP(int yVqEIK, bool cWJfMFXjW, double ismCxpnZNXYa)
{
    string fDIGnhTMGgeqU = string("NMaFVUtMIszQgUlyoAKdLZLQTbOUbflUISjCapwZsimauatlsrUodqgQXNgBWpBzXpMDcppVVvgGNIUEksuWRTGZoOcWQNBCTzBPxgCYyFdUeuYZSsJl");
    int QtvpNSr = -1105896737;
    double EOMGIQoJ = -679682.5431478119;
    bool URutuPKbkWPFRyS = true;
    bool AvhqEnzOKHZOJU = false;
    double pXfQKEV = 515446.1701569237;
    string jlzgBYo = string("NKFOF");
    bool ArLQZuXWvK = false;
    double ODJkdf = -491466.55185762787;
    int cnhjNaLrlK = -36827321;

    if (ismCxpnZNXYa == 985001.7589494847) {
        for (int ZaWlzlW = 1365505880; ZaWlzlW > 0; ZaWlzlW--) {
            ismCxpnZNXYa *= ODJkdf;
        }
    }

    for (int mtTzGQnqeOXHn = 1342377762; mtTzGQnqeOXHn > 0; mtTzGQnqeOXHn--) {
        cnhjNaLrlK -= QtvpNSr;
        ArLQZuXWvK = ! ArLQZuXWvK;
    }
}

bool keBhXCJV::guFQAUfL(int uiNRk, int ESvOSUo, string JPoCmuKu, bool ofYmadoZJAR)
{
    int tuIIUbdDUtRJwoVO = -1150939918;
    bool WSdXUBGiDJFPvdq = false;
    double erwQyW = -606143.4683782853;
    bool ynPjtZQlZDhC = true;
    int Adodn = -1571109524;
    int VFIIaknx = 109058377;
    string oNEWOsg = string("tXvNFZGGEUJhezWqUfBeTKispsDzKcUKuhPxMeazQwbHGZbSBdxPvOqtPxsVBVtOFPlBDhtHvWQogDlzafYLMvrPAaXquHEtrwHiVRgGQvhBfoQBXEiGKWfusWdkJxfIcFngHGfpzKqfIEqKymGyIfVwFEQYXWaTlicwCKfWxSUNUNPdoPSYLqjoScrfGgHgYyKDEDvNDK");
    int BrDgPbJyz = 2125589850;
    bool xYIXHzzAoA = false;
    int pMTrUSzzsaeYN = 803787057;

    for (int DISfNQhEwgHnZ = 1265081428; DISfNQhEwgHnZ > 0; DISfNQhEwgHnZ--) {
        xYIXHzzAoA = ! WSdXUBGiDJFPvdq;
        ESvOSUo += VFIIaknx;
        ESvOSUo -= Adodn;
    }

    return xYIXHzzAoA;
}

void keBhXCJV::yAVkc(string hUAhCrzxcGK, double NKQdlA, double jhojrGnlGJf, string QsEJkmuVuUr)
{
    int owZjNVasHsnFW = 1915360209;
    string QlJMs = string("zDpVqwLiEKQsZkKLJfNNdUMfPvGPMonhzUaPuVwwgv");

    for (int LZvHgo = 941181205; LZvHgo > 0; LZvHgo--) {
        NKQdlA += NKQdlA;
        QsEJkmuVuUr = QsEJkmuVuUr;
        QsEJkmuVuUr = QsEJkmuVuUr;
        owZjNVasHsnFW += owZjNVasHsnFW;
        owZjNVasHsnFW *= owZjNVasHsnFW;
    }

    if (QsEJkmuVuUr > string("eWMfaohanQgqAZAXTZpOimOdBVzeOJXMntiJstyVLNrsuiMYpHQbhGwlNzcVBviScMUDsVPxUzzFEbvkUpjCFWrDEvHVNUtrhidBCdpOYNVaNvVJeOIGNOfbuLBzXKGksfKsRLFDJScXe")) {
        for (int dQiazVJitkd = 1188759065; dQiazVJitkd > 0; dQiazVJitkd--) {
            hUAhCrzxcGK += QlJMs;
            NKQdlA = NKQdlA;
        }
    }

    for (int SqHxWKypdfXjF = 1288423731; SqHxWKypdfXjF > 0; SqHxWKypdfXjF--) {
        NKQdlA += NKQdlA;
    }
}

keBhXCJV::keBhXCJV()
{
    this->CrCALZomYVFdZGK();
    this->pnnswZI(75995.2550245337, -934174.5344120928, string("GzyKuyZlMYtlrVrOevdtxpkNWrbQItmKlZlHVMpwFIPUAlHHxnwBrQijHUdUmPNMHjwMueJxzzfYuclxsUcZAbqhptvFLzbssYlLlvNoWAVOYNgnVKMFFvjJJsLrRkiNKgdHSNaazzBTqCeOrPycIxQwQyrBcPyiNpBfLTwiODPevlyvwmDWBJdDAwKdsmgPWnUeLILkgfxVRBrQCykanTuI"));
    this->oIKis(string("UdaZtQIlwpxbecmfOxSGYpbeROeEaiwlEMMttuoSLkrnMwRNyjCLQtZzpCdCtUZecPUwPJVotxUEEPJpSHLAagxPkVkWrhWEMfHBQXVYUSuApyPvcIgAYChKXUKVxCsOyvXtCfeAsGdTSlZnzbZExdOXTTEAQekFxFvZbECsjaIJGXsjdSpSSYKnZVEjMJaLgFtm"), -130296.8047864499);
    this->qMOqcJAEBBQ(false, 284187618, string("cROdPBXhZNsZufvEvzpBKwpgdYOfvronuAvDSuhOaSkTAHOyUNDLEUbKnciwbmpSBBbmhoXYnSPNfyEvIyWXkuISxlZvEyNBTtPwVtdkwihaCAKZPtRcCiDgweZnGIj"));
    this->VEataEO(179863.87556427042);
    this->lNNRmwIWpC(string("chpZBeRLYcbtciGrfGCAtIQBEgpSPufACPceDckVuFsaEpOKPBdhMNoGTwcunXQtkzCfdKBDhGMbndsrrKUyJuTRXtictcasKVLbSEKaYWLIMEvVsLmjTieiNGmuJEDfwTuyXXnDNWapxrrubuIlApNOGBISytGZuQLgHEWeKFUynEEwaNjQCtFteCEbakRuOCqlQLIEGYoQCobW"), 665799.6771938532);
    this->mIytnCuYvMBjVQsQ(false, string("fttKHxjQbQAvVkzsClMzBeJGKeOWDMpGMDYCVRJMNqTiIOPnBzOGdTxHjFHeLgaZOXYdJqrYCmDnoMNCNkaPAIiaVuMTDuSqrbsVsGpxmPjYwUdEtCDqSpIPWviubadEjOxwdZDvXWwsjwaVmiIPrDLhMpwJZEKVNtDfMvqqbtgFMgpZMqFbWvtngksMpcesEfTLYGvNokuwyohmEsgaXzgwMYZjptZNAEexnQlmdKkoQQvQIbzOIgCUxfYYn"), string("cgHhXJwUYTyHiMZTpasSxibcgfOVRhidMHVkXXKSaJzAHNyCpTYkzHRzdHSbrgxPNKT"), string("TiaHuKFucCOZPFyhXROqUljMFppWirJWMcLsxgNyYGIalqzrLoayDXsMheMSEncvSCMLVyitQiIrrnpHJKriDHmzuBVScGjFkZKxfmPdmgksRinMumGQLQlqpstFBkKxoysfKktEPAdtaigJvhfzUZmzWBgsoykjZepdTWYTKlXFpoScIrcEbxuFJJbOSsNQnQpbxwUuJDpxtjY"), -636043.7852613302);
    this->IEYcFbdROvP(-402294197, true, 985001.7589494847);
    this->guFQAUfL(900583196, -354387736, string("ejSbjPXHETjPjrFxkJIRFKAPP"), false);
    this->yAVkc(string("NOhpbuJYHaPzuSnIevxQdrKyEeeKjsgTiucjTNsxlUCvAlaJeQxQGYPOwNXqDiJjmDkziRCWipjKUqRJeYFHKVrQRBJBmDYLFryrprNOWDFqZtzMDEpoDrcW"), 576914.4899838429, -314127.2955781869, string("eWMfaohanQgqAZAXTZpOimOdBVzeOJXMntiJstyVLNrsuiMYpHQbhGwlNzcVBviScMUDsVPxUzzFEbvkUpjCFWrDEvHVNUtrhidBCdpOYNVaNvVJeOIGNOfbuLBzXKGksfKsRLFDJScXe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class raCURHASUaawb
{
public:
    int MVMiseRmsbDLDcFd;
    string fwLdxujyUHrQeFU;
    double PUGMIUFEqRxyETYu;

    raCURHASUaawb();
    bool ADLzUsTvHmH(string edvBvcqKuhUgPc, double xglXbMWhCsH);
protected:
    bool nBnvGZrzifd;
    string RKruOekmOjxJeuIO;
    bool AWWoAZnjbdnleuN;

    int PtWhqWHyobXhII(bool wUsFTgqY, double DGAWn, string THwHvzeEz, int sCGXGjNDHTtdxr, bool iZHpIxiBQxvb);
    void cpSKxDDofbw(double yBcjwiK, double POlfTZ);
    void iZQRYwcQnqos(bool nUswmiYpVOXI, int iPbZCH, string sXFjGG, double OEztC);
private:
    int leALQYFCjl;
    string ncyIcCD;
    string xXzgdBmsLoUIj;
    string zgPCkGQGsLhvTi;
    double UkHcv;
    bool WHkVqZPGrEu;

    bool BPXotBcAd(string LnOrPSeepiMADsmy);
    double tgksTWxVzSfWzoyp(double WmPsuZqQJyuGS, int KCeey, double YGchuU, double TdfmRdbgZgxkXVvs);
    string NNLcVVmJNCDi(int hLNdSvLBel);
    bool uByImaETccDahHtx(double oZENmBakDxdwNQ, int UrpfoKbO, string gXCXYkMoCgGE, double rsxsCLupoIOFJHZ, bool mAyCnIcNjFuhAO);
    void DXZRj();
};

bool raCURHASUaawb::ADLzUsTvHmH(string edvBvcqKuhUgPc, double xglXbMWhCsH)
{
    int bMPWgo = -2075845689;

    if (xglXbMWhCsH == -343052.0987424185) {
        for (int aijVWd = 674541439; aijVWd > 0; aijVWd--) {
            xglXbMWhCsH -= xglXbMWhCsH;
            xglXbMWhCsH /= xglXbMWhCsH;
        }
    }

    if (bMPWgo <= -2075845689) {
        for (int KvFaTy = 1542637046; KvFaTy > 0; KvFaTy--) {
            bMPWgo /= bMPWgo;
            bMPWgo *= bMPWgo;
            xglXbMWhCsH -= xglXbMWhCsH;
        }
    }

    for (int kwDRK = 163273342; kwDRK > 0; kwDRK--) {
        edvBvcqKuhUgPc = edvBvcqKuhUgPc;
        edvBvcqKuhUgPc = edvBvcqKuhUgPc;
        edvBvcqKuhUgPc = edvBvcqKuhUgPc;
    }

    for (int LDSOHZbEjlNM = 1843348159; LDSOHZbEjlNM > 0; LDSOHZbEjlNM--) {
        edvBvcqKuhUgPc += edvBvcqKuhUgPc;
    }

    return false;
}

int raCURHASUaawb::PtWhqWHyobXhII(bool wUsFTgqY, double DGAWn, string THwHvzeEz, int sCGXGjNDHTtdxr, bool iZHpIxiBQxvb)
{
    bool jboEoxM = false;
    int tyrCCPFbJ = -1915593945;

    for (int PPAeODvvY = 836615920; PPAeODvvY > 0; PPAeODvvY--) {
        wUsFTgqY = ! wUsFTgqY;
    }

    for (int kdQrk = 672931943; kdQrk > 0; kdQrk--) {
        jboEoxM = ! jboEoxM;
    }

    if (iZHpIxiBQxvb == true) {
        for (int FLEZjgWNFjnCmv = 1813471655; FLEZjgWNFjnCmv > 0; FLEZjgWNFjnCmv--) {
            continue;
        }
    }

    for (int QsueMoAD = 1880305868; QsueMoAD > 0; QsueMoAD--) {
        jboEoxM = wUsFTgqY;
        jboEoxM = wUsFTgqY;
        jboEoxM = jboEoxM;
        tyrCCPFbJ /= sCGXGjNDHTtdxr;
    }

    return tyrCCPFbJ;
}

void raCURHASUaawb::cpSKxDDofbw(double yBcjwiK, double POlfTZ)
{
    string QBNYfTOOOqjMo = string("xXuxZtENUhsZuAcIyWruBlTwwDShgVofrlyQxRyJmFkjnMScJKeHhRioTTpxvGmJApjwBcbdXvvPdwtWZHkPvaazmQNFZkStHPwIwisnunmyyfcoOGMeLaESLNhsrHxRpWPYGmLHaXKwoBFszBzvjgLtzYkinpumGXNkwdZLZapf");
    string CeiueaSOlzAQ = string("etClCWwribnBwMcSLFdCoZLvwCRZwGGmEIIJIicFWocathpFoeRyHPYPHLavEryCIqUubFkcxjuKBoThTSqlPELMqAuXOoJXTumrXMbXfTnhxCnypQqjYDPKzuEYSVwkURkXZpzEnXKdphPDxchsuBoksDGjarFqZAHMBmOmHRpNiqVU");

    for (int bceMiRqwfcmgP = 959581489; bceMiRqwfcmgP > 0; bceMiRqwfcmgP--) {
        QBNYfTOOOqjMo += CeiueaSOlzAQ;
        CeiueaSOlzAQ = QBNYfTOOOqjMo;
        CeiueaSOlzAQ += CeiueaSOlzAQ;
        POlfTZ += POlfTZ;
        QBNYfTOOOqjMo += QBNYfTOOOqjMo;
    }

    if (POlfTZ != 729542.10777836) {
        for (int qiXkSGPiWmJvOUxd = 1180470819; qiXkSGPiWmJvOUxd > 0; qiXkSGPiWmJvOUxd--) {
            yBcjwiK = POlfTZ;
        }
    }

    if (yBcjwiK > 729542.10777836) {
        for (int GCWFz = 2021306656; GCWFz > 0; GCWFz--) {
            yBcjwiK += yBcjwiK;
        }
    }

    for (int zqdaSmApQQus = 488758455; zqdaSmApQQus > 0; zqdaSmApQQus--) {
        QBNYfTOOOqjMo = CeiueaSOlzAQ;
        POlfTZ += POlfTZ;
        yBcjwiK -= yBcjwiK;
        CeiueaSOlzAQ += CeiueaSOlzAQ;
    }

    if (yBcjwiK >= 729542.10777836) {
        for (int EUckHndMvqd = 545848321; EUckHndMvqd > 0; EUckHndMvqd--) {
            CeiueaSOlzAQ = CeiueaSOlzAQ;
            yBcjwiK /= yBcjwiK;
            CeiueaSOlzAQ = QBNYfTOOOqjMo;
            POlfTZ -= POlfTZ;
        }
    }

    for (int wjLfMUAIm = 80575045; wjLfMUAIm > 0; wjLfMUAIm--) {
        yBcjwiK = yBcjwiK;
        QBNYfTOOOqjMo += QBNYfTOOOqjMo;
        yBcjwiK -= POlfTZ;
    }

    for (int irjCIYxQvw = 1085724971; irjCIYxQvw > 0; irjCIYxQvw--) {
        CeiueaSOlzAQ += CeiueaSOlzAQ;
        CeiueaSOlzAQ = CeiueaSOlzAQ;
        POlfTZ /= POlfTZ;
        QBNYfTOOOqjMo = CeiueaSOlzAQ;
        QBNYfTOOOqjMo += QBNYfTOOOqjMo;
    }
}

void raCURHASUaawb::iZQRYwcQnqos(bool nUswmiYpVOXI, int iPbZCH, string sXFjGG, double OEztC)
{
    string CvIlwshsLEysk = string("HsdnhDNwW");
    double QlxIWCjdkgOBNb = -766209.4408513885;
    int IKLYQXaPQ = -1979215920;
    double PIYwjf = 466551.09178400744;

    if (iPbZCH == -527760420) {
        for (int nRNzUHuunRyXLe = 1294956215; nRNzUHuunRyXLe > 0; nRNzUHuunRyXLe--) {
            continue;
        }
    }

    for (int PDnsFoCXClecQ = 973512490; PDnsFoCXClecQ > 0; PDnsFoCXClecQ--) {
        PIYwjf /= PIYwjf;
    }
}

bool raCURHASUaawb::BPXotBcAd(string LnOrPSeepiMADsmy)
{
    string DHYNpcwlRiEeAn = string("HdhuWfsBsmtQKkxdWsFyvQSWJtaAAnXRpIrSXTXsYLnQHcBwXvhjqGmoRWmHHwLJaQSEmAKMVAMAWSpLpxKmuUCI");
    int BuopdcpRglfDfye = -749650750;
    int euMPsfdLkw = 2133522543;
    string mZEZd = string("jgwtdyPzylyVXUVhGNTqCCvxutxaDRTDnClyDCoFWWCAAdhBAZRJPgSHYSOiriunGLdplAFCdHMXosVuQsjQudyjPFTTmrvDtbhRTIBghnwXZMmkZiOVTPBYbUHkZqjqmOVxYULGRtnlaRvQoVIzIHNTUbnQKBXdEFcLoWKiQ");

    if (mZEZd == string("HdhuWfsBsmtQKkxdWsFyvQSWJtaAAnXRpIrSXTXsYLnQHcBwXvhjqGmoRWmHHwLJaQSEmAKMVAMAWSpLpxKmuUCI")) {
        for (int TRAciqaS = 1593448034; TRAciqaS > 0; TRAciqaS--) {
            LnOrPSeepiMADsmy += mZEZd;
            mZEZd = mZEZd;
            DHYNpcwlRiEeAn = DHYNpcwlRiEeAn;
        }
    }

    return true;
}

double raCURHASUaawb::tgksTWxVzSfWzoyp(double WmPsuZqQJyuGS, int KCeey, double YGchuU, double TdfmRdbgZgxkXVvs)
{
    string UQvhLO = string("RvfNMZgRsQiiSHwpRRIwWhMSFVAYkbNBFzNNKbURObPLfsMiHRXaEgAVydxfihfptPvVjrauDlpxmCppyxnljChrNsPTfzOqj");
    string XCMgrSIPsVyGB = string("AHmlMihDIRryBMnhQmOUIunLBOgdkEfihoxeAwDoMnSizWLDyKqMeDXxfMjuDePqcsILbsqCwGSyraaRfjdWIdhtwPAHkOpfWIqhuVYpRoWjdTuxieNHCAZAUhukVOOOwcbKKhoSiQRYPmxONDwvvbZAqzKuhhhsmFONbYVaQvwGTegRstGuKKRpw");
    string vxyUNBqaET = string("KvfanuUM");
    bool IuqhjOsk = false;
    string ikgsTmCtkUspv = string("KhHHQpUMmvHlwcNNpYGXafXBdelDLrCfkUfGPJgCaxdoYYHGbSAOWnVylfxuSJwAieZSfkMAzsKxHFjiCcyQnTKxymOZmFCMHhCFXvbQGDMvqTnSEVxQyfbnVvwkjmqIYnfYTxSnitrTWkvXvEXOzWhfjAThhKhB");
    string QAeqxmugmN = string("XpeGPGgVvWhffVQZfgqleBOKHoNJMdoniVpGpvBOYypaPlMuDeUgoHtZHpGWHafTrzbhDgoxnBriWqmJgHdeDIHfDJBqWJamcMLLWIJVxLKeBvJUlkFei");
    double LdiSJePyNa = 875895.7629038261;
    string JAtqT = string("YuHFSpVHgDAfOZiGYPZuTDDYu");
    double BdCfaDzIW = -481396.16463406745;

    return BdCfaDzIW;
}

string raCURHASUaawb::NNLcVVmJNCDi(int hLNdSvLBel)
{
    int QVBzwqYZmOkPiwo = 617068668;
    double aGGLE = -1037234.5902069964;
    double mafFLmQaH = -556870.3758226823;
    string wikQOd = string("JOpWFYtPbBWaJhIqggYSZOwIAZEmwRrOyaRfWnVsjEEFgNZPxFAtKYbToUGztBhttxOfigVoa");
    double wviUYBveAw = -246125.1241096669;
    int wJvbl = -742937415;
    bool TwkZetOqVytFZu = true;
    double MTFGFTqvsQtOBsp = -166913.57358529576;

    for (int IrRtX = 1143010370; IrRtX > 0; IrRtX--) {
        wJvbl -= QVBzwqYZmOkPiwo;
        TwkZetOqVytFZu = ! TwkZetOqVytFZu;
    }

    if (mafFLmQaH > -556870.3758226823) {
        for (int xKqqCRrUlJePsMB = 217502376; xKqqCRrUlJePsMB > 0; xKqqCRrUlJePsMB--) {
            continue;
        }
    }

    for (int LfBbrmcJL = 1846377198; LfBbrmcJL > 0; LfBbrmcJL--) {
        wviUYBveAw *= wviUYBveAw;
        hLNdSvLBel = QVBzwqYZmOkPiwo;
        mafFLmQaH *= aGGLE;
        mafFLmQaH = mafFLmQaH;
        wviUYBveAw *= aGGLE;
        QVBzwqYZmOkPiwo *= QVBzwqYZmOkPiwo;
    }

    return wikQOd;
}

bool raCURHASUaawb::uByImaETccDahHtx(double oZENmBakDxdwNQ, int UrpfoKbO, string gXCXYkMoCgGE, double rsxsCLupoIOFJHZ, bool mAyCnIcNjFuhAO)
{
    bool eGooTepISiRyq = false;
    string KsaWmnChb = string("VfPzwBqFBHSBaKxuivVCwNNqLUEcdrXbALNcvMWdqpVBdbJKfduznBUBLBHaVTWKdiylBVQXvEdpBhSAzTTqKyjGlQYzMcXroummxkOdrWAlJLYnjtcmrUHGxKqUwFatnznNaujNYvptmuXDOyKvnAfyyvzfhnxvxACIIKKxoDgEFcldatBCYuPlHimwySlWRQEJEXxRmkuEKYiNmMjtEzBhvErLKafFpPuXLSrcGWJd");

    for (int fqiLVUaeOtPDuOrV = 677099963; fqiLVUaeOtPDuOrV > 0; fqiLVUaeOtPDuOrV--) {
        gXCXYkMoCgGE += KsaWmnChb;
    }

    for (int hQhwhWaO = 1300208416; hQhwhWaO > 0; hQhwhWaO--) {
        rsxsCLupoIOFJHZ += oZENmBakDxdwNQ;
        oZENmBakDxdwNQ *= rsxsCLupoIOFJHZ;
        gXCXYkMoCgGE += gXCXYkMoCgGE;
    }

    return eGooTepISiRyq;
}

void raCURHASUaawb::DXZRj()
{
    bool LjvcxKcRTJBi = false;
    double mWLik = 83279.08004849961;
    bool gzASXElOIOXQmD = false;
    int swiRQsKHF = -1807677615;
}

raCURHASUaawb::raCURHASUaawb()
{
    this->ADLzUsTvHmH(string("kwQueHnpjAdfxhXpjuOCvyHpIsLzLt"), -343052.0987424185);
    this->PtWhqWHyobXhII(false, -150154.49445159672, string("dxMVtiLaBLDSshnEdcRgSoStEdZvjgOOjYAbBHgQnXMZPRaCiXixgGBufJkRXoiWoIeQiejFlpkCLQrKAGogLnGLzupKcmHnkjNCbeaExikCSsuWgHqVhhVvYcBDZiyIKDMogkvmiLtxdghiWhzkagYLoLsWtvBMdEpbOcLHimPklpB"), 1995325180, true);
    this->cpSKxDDofbw(729542.10777836, 289979.63193253963);
    this->iZQRYwcQnqos(false, -527760420, string("GrlvhhpJDcrtQQOfbatroMWTAMyBddbNFcnFnklCpcnyWvBPuZBwykHnXlKvjWZcVCxzeBrLXiBkwdWLYJSqPAKaEPGFIVHpOlbnHfPxnbvATaUEpJymHXbmGCFPkhMjtHGTzPsdFuvvMylFzCzUoLryjeAPxSnsNgFDFGPZgDCbVMlFTGAByekZcwLMaJEclgWjXnqquGGykbcYcUrFzsfXLdBtIVSFVbHzrAaEZTPqzxWeS"), 321843.04755377566);
    this->BPXotBcAd(string("hakxbsPkuwsKqlwh"));
    this->tgksTWxVzSfWzoyp(327526.7776135954, 1243480697, 755463.0183626689, 69429.56847113805);
    this->NNLcVVmJNCDi(772111876);
    this->uByImaETccDahHtx(549417.0957390103, -1748114284, string("FQLOQXjRNXYIonbGGbVFbazScMSoRNByRtqPLpNEyGeUuscBomZndPTtHoHcwQCZirMdumrpPjpxUJDPZUeTDsPurVPOfOfWJTUSjQzidvCIRLXwoZZxnHRvJkVOftcmpDiIpLsvFIdIaGsaIvpKFPkiRdtTyYYBiFMisMwPVtGHbAcguUBxiUfihXMPt"), 321243.3662810239, false);
    this->DXZRj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ExpxXIqLjw
{
public:
    string zyOkpQF;
    string WAPUbvvoDncyW;
    bool NMywKAyVi;
    bool WNCcmklmXdJ;

    ExpxXIqLjw();
    bool cemTFNKydSW(string Mshhwok);
protected:
    int ZdLUmTAwUWpBcmdC;
    string IVObWhZIYnlvVCJ;
    double czBOLeuLkZPmCVol;
    double gEfkiPcVV;
    int mMCaSOavEO;
    string PDLzMkwDKDgnRvq;

    string xTXXmUWEAF();
    double FHZhwkRt(double yHHBRBlJDKeTXoFS);
    void dUxqsjEmZrI(bool mNwIZFqPukVPMx);
    string gIyGcsqKO(int ZnwYzWlikCtPn, int hXslSlndFAkXJu, bool BoLMg, bool yedJrvGlizEXhKu);
private:
    double DbpANcrYQZ;

    int REfzuCZ(double cbqogHCNeWKYtQP, int ewtSasbQCsdEOVn, string NxenvYAe, string VClLHHXYSIvhyt, double DitlVDRoIgJLEWY);
    double yXWtAAEGLrQb(double ZABSpyYQIB, double RYSKCjptMH, int fELhAtqkObhdg, int FjICTeFg);
};

bool ExpxXIqLjw::cemTFNKydSW(string Mshhwok)
{
    string xLNqlHZsmVnrM = string("IVMtLCkILsMRVOMbDfxCKFwytXkctMbfxfVVfmnjThiTzMltCjcRpVotICflVmAbMBdOfHdkZnTDQPKTimRobuGOagQqhyVMKUGsHnmokEQUfAqeuYBirpXkGhjCovqtnDRfqmpAMnagF");

    if (xLNqlHZsmVnrM <= string("SlQsMEuYFzpsxdpmOfkbNyvMlBkOjVejgPJMMBQmhaOaskHhclrKqGddPPqjggiQikUXRWaXUccfmjQJmhCtohcukBPxYqmvOOHYLdo")) {
        for (int xEjVDsL = 1188215638; xEjVDsL > 0; xEjVDsL--) {
            xLNqlHZsmVnrM += xLNqlHZsmVnrM;
            xLNqlHZsmVnrM += xLNqlHZsmVnrM;
        }
    }

    return true;
}

string ExpxXIqLjw::xTXXmUWEAF()
{
    int hbShPlGdUNeVtLa = -401937799;
    int XyFcQil = 2031869562;
    double RNGUDBrpdiNe = -584420.6108244958;
    int WzMeJngqhte = -738992001;
    int aaQsFq = -58589620;

    if (WzMeJngqhte != -58589620) {
        for (int SFQXrpHLooKNnYc = 1662460906; SFQXrpHLooKNnYc > 0; SFQXrpHLooKNnYc--) {
            aaQsFq *= WzMeJngqhte;
            aaQsFq -= aaQsFq;
        }
    }

    return string("nuEEusFrPyyzoujEYVeKEFHbjmgTxtnUDbCsENPFxztuFEBenfUifTTQIoEOjUUFlYmKeaBgXdQHPnBRSVYkTYlSeAQyXQrGkZptzAIdXtSRlClHVmRWZjwSijjhmsBDVVU");
}

double ExpxXIqLjw::FHZhwkRt(double yHHBRBlJDKeTXoFS)
{
    bool iFJBi = true;
    double AIxKkHSHUUgV = 207557.74256365263;
    int WSIPeCimkCkEN = -87285202;
    int ftmXAGV = -834082527;
    string fbGbRTlzOBfa = string("PVguJAOtUSbZJfTjCobnHbLixkAuSGeblkjgrXPBqOqvXgXexRRHYHxdDLGpQcbAHOaHzQMAaBMaDHHFMaeCFNLbXzqxYcuTyXHEdUnUgJRtISPCCNbZPAltyqOuQCRDHhqDezhLVNGiPJggcvXgHOGGPRfddHZLHueMdKmfmDxfmPwERJBFTHoAreRfYxpMjrqajKzvKwnzbnbdMNZWEGjllXTWVYql");
    int JHIXivWlLlugDWAk = -788559605;
    string KazyWkfZ = string("FInlaxfrIKIbFMQ");

    for (int vpxXzRTyo = 753876741; vpxXzRTyo > 0; vpxXzRTyo--) {
        fbGbRTlzOBfa += fbGbRTlzOBfa;
    }

    for (int aJmCetYRgqtjLCo = 706653247; aJmCetYRgqtjLCo > 0; aJmCetYRgqtjLCo--) {
        WSIPeCimkCkEN /= JHIXivWlLlugDWAk;
        AIxKkHSHUUgV -= AIxKkHSHUUgV;
    }

    return AIxKkHSHUUgV;
}

void ExpxXIqLjw::dUxqsjEmZrI(bool mNwIZFqPukVPMx)
{
    string rDQZZaK = string("TvdAsLEtT");
    double bkwmReYlVGkuw = 872794.7249578019;
    bool blMZpw = false;
    string dPzfWsGIyrOMcr = string("XEsKPUdNPFJNgozsSEnlALtAKmOsWOHsFPBFJndBeISSFgbQwICfUUFiIfYjuxgVCSHKIOeHBvysCFvhQcTBZnXXZckocUaeGlZwTwIWSNacXXZcLhroFDTYjNKUXyXRmpkJlgJCGRnckWoSBkLEHODcNVLKpNRyAUeglerozmHusEFFDQqhEvVgLXwsVKNYAZM");
    bool vXcyW = false;

    if (dPzfWsGIyrOMcr != string("TvdAsLEtT")) {
        for (int gnuovhB = 849746117; gnuovhB > 0; gnuovhB--) {
            bkwmReYlVGkuw /= bkwmReYlVGkuw;
            rDQZZaK += rDQZZaK;
            vXcyW = ! vXcyW;
        }
    }

    if (vXcyW != false) {
        for (int lUKRAKxx = 1894862202; lUKRAKxx > 0; lUKRAKxx--) {
            blMZpw = ! vXcyW;
            vXcyW = blMZpw;
        }
    }

    if (blMZpw != false) {
        for (int rooLBmqEsvH = 814928874; rooLBmqEsvH > 0; rooLBmqEsvH--) {
            blMZpw = ! mNwIZFqPukVPMx;
            mNwIZFqPukVPMx = ! mNwIZFqPukVPMx;
            mNwIZFqPukVPMx = ! vXcyW;
            dPzfWsGIyrOMcr += rDQZZaK;
        }
    }
}

string ExpxXIqLjw::gIyGcsqKO(int ZnwYzWlikCtPn, int hXslSlndFAkXJu, bool BoLMg, bool yedJrvGlizEXhKu)
{
    string FufLIjTdrzAA = string("SlyMHWUIpsMmwQDxhbhmmPvnkuDZPJDfksJyxjiNkXvLETqVHFeopVvHnHthZaAiwUWvpAPIDxKgjNkcpvhwBFDPIubNhfVKoFgZnytWoZcHpEkuyCuCm");
    double RAMkkcfyEG = -568490.1828603446;
    string MDUcSzjSNBFQXtv = string("IoCYgjQNGlfgXUjMHBpXVumeKThVNTZDdPKYWdIhTWQHgujZSFfPAsylaaauRsrIBwnb");

    for (int UeOiWfDPwEYOhDk = 1574617384; UeOiWfDPwEYOhDk > 0; UeOiWfDPwEYOhDk--) {
        yedJrvGlizEXhKu = ! BoLMg;
        hXslSlndFAkXJu += ZnwYzWlikCtPn;
    }

    if (FufLIjTdrzAA <= string("SlyMHWUIpsMmwQDxhbhmmPvnkuDZPJDfksJyxjiNkXvLETqVHFeopVvHnHthZaAiwUWvpAPIDxKgjNkcpvhwBFDPIubNhfVKoFgZnytWoZcHpEkuyCuCm")) {
        for (int JKgcPWBodYOHIPqz = 1424058930; JKgcPWBodYOHIPqz > 0; JKgcPWBodYOHIPqz--) {
            MDUcSzjSNBFQXtv = MDUcSzjSNBFQXtv;
        }
    }

    for (int mhRfZ = 2058055637; mhRfZ > 0; mhRfZ--) {
        MDUcSzjSNBFQXtv += FufLIjTdrzAA;
    }

    for (int atYglUuCwnQZXmF = 272692736; atYglUuCwnQZXmF > 0; atYglUuCwnQZXmF--) {
        hXslSlndFAkXJu -= ZnwYzWlikCtPn;
        hXslSlndFAkXJu = hXslSlndFAkXJu;
    }

    return MDUcSzjSNBFQXtv;
}

int ExpxXIqLjw::REfzuCZ(double cbqogHCNeWKYtQP, int ewtSasbQCsdEOVn, string NxenvYAe, string VClLHHXYSIvhyt, double DitlVDRoIgJLEWY)
{
    string Afuku = string("RbcUHrgNhHagdWgFjwulzdNxrdaPmjsNlIqfddZlXjWSCGWwctTnQOPjRxJofmCETWAgATvTXjBxMFyzHwABpRSDUqmqWYAxAhWnlKSVBSCAwJYTGauvNSCtYHvlKVVwwUJqUEWKeUySDhGBcjqSpTxxEaNQvSuZD");
    double ACVwSdWENKjOC = -1028341.3286647236;
    int YsSsJyYtjYDBdZp = -1116798668;
    string ICLqwnDCWkcV = string("pDDLmerIqSuzMTWEDDNjyaFmURwjthdsBqwbRNLUmKjVArRJgzBELqiKyEo");
    int hOnNpmcFJFY = 1736475178;
    string IcUBXalG = string("nmBDQifHhGErsojPLPRkYuJkYKvsvYfmFHSEOHflqKnCSNmsGUFltAtTyAKMaafEVWKmzHqErmeNxjdpCKhlsruAySZqtbyxeFzobgxFEAS");
    bool bFlFLntNlMSz = true;

    for (int WBDibsCgzIYSiA = 127162628; WBDibsCgzIYSiA > 0; WBDibsCgzIYSiA--) {
        NxenvYAe += ICLqwnDCWkcV;
        ACVwSdWENKjOC /= cbqogHCNeWKYtQP;
    }

    for (int pTykAXrZSpOZM = 2057599626; pTykAXrZSpOZM > 0; pTykAXrZSpOZM--) {
        continue;
    }

    if (ewtSasbQCsdEOVn == 1736475178) {
        for (int arksQZeQVmv = 1815250813; arksQZeQVmv > 0; arksQZeQVmv--) {
            ewtSasbQCsdEOVn *= hOnNpmcFJFY;
        }
    }

    for (int QHUPgVBP = 712072309; QHUPgVBP > 0; QHUPgVBP--) {
        DitlVDRoIgJLEWY /= ACVwSdWENKjOC;
        ACVwSdWENKjOC += cbqogHCNeWKYtQP;
        NxenvYAe += IcUBXalG;
    }

    return hOnNpmcFJFY;
}

double ExpxXIqLjw::yXWtAAEGLrQb(double ZABSpyYQIB, double RYSKCjptMH, int fELhAtqkObhdg, int FjICTeFg)
{
    double TTjInorVOFtq = -80666.2413933579;

    for (int hZANnkLnHWV = 1943368065; hZANnkLnHWV > 0; hZANnkLnHWV--) {
        FjICTeFg += fELhAtqkObhdg;
        TTjInorVOFtq -= TTjInorVOFtq;
    }

    if (TTjInorVOFtq < 734057.0548340915) {
        for (int XRrEDaFPm = 172091727; XRrEDaFPm > 0; XRrEDaFPm--) {
            RYSKCjptMH /= ZABSpyYQIB;
            RYSKCjptMH *= TTjInorVOFtq;
            RYSKCjptMH *= TTjInorVOFtq;
            RYSKCjptMH = ZABSpyYQIB;
        }
    }

    return TTjInorVOFtq;
}

ExpxXIqLjw::ExpxXIqLjw()
{
    this->cemTFNKydSW(string("SlQsMEuYFzpsxdpmOfkbNyvMlBkOjVejgPJMMBQmhaOaskHhclrKqGddPPqjggiQikUXRWaXUccfmjQJmhCtohcukBPxYqmvOOHYLdo"));
    this->xTXXmUWEAF();
    this->FHZhwkRt(-650610.7310279342);
    this->dUxqsjEmZrI(false);
    this->gIyGcsqKO(1927877736, -72396777, true, false);
    this->REfzuCZ(638483.712102767, -1920281183, string("IoZvbyPNRfIkIrfzivakSqJcXnHFuuBPJRvNxJjpjPhusZXZizLRnyhaEdFqpXvealqOoLOBmqTbJBFyyWyMzAvpribewSQAUEszcJkwARkGWUqqLQMifHxdeVgdZwpmrQPMEvKNesHOatbpKdGTOtwdCfjYxMYVFmdxAUFLvaSYmqFn"), string("FWRnxnloGgYARkaKKwriDJJbOyZRjvCyAhVSsVeazOnTsoZuolNZcotTdrtyzIoKDNDdnVCvKpWwbRhIGhJYKVmuXRrSyhCJikAvyhbnqPqRsUlKLEEAUgkPDNmmXtZEumLgLgWEtfuLmHtVrVdXdJYcvpMMTeTnNkcZeGUXVPVAivWwwkVSGEUexlrLfjulTVwPcHfcA"), 198226.04476892014);
    this->yXWtAAEGLrQb(734057.0548340915, -650617.6688299637, -12794221, 953313038);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ljMVvKBA
{
public:
    string VuPaBp;
    string fPIvvfFaw;

    ljMVvKBA();
    bool xMlnJhrPbiV();
    double qmxYRI(string DTLEmBkWrJqtl, string eIaiIJWjRZLUrfrB, string xpGfLMZa);
    string dzTlVSYWLDqcHOS(string ieFrecdb, bool NLTOtLGNZkfjr, int yOIGK, string nmjgMtBxF, string efDyOLK);
    string jkWTgUHCqScgyLo(bool wHCuVl, bool GSicms);
    bool WAUcuADykTas(int EMYmQKMtj, bool EQyVGCNwOZmv, string whWElakID, int FEZetl, bool PpQPAcd);
    double VBuJljjCuoIbK();
    int hEwQRWx(int xUdtb);
    double ZDKlrpyr(int RUgbIJyDT, bool CeNamlRWDKW, bool ILbWlhfNgJ, double kxnEEjkfn, bool SNpuRmNihiavHwI);
protected:
    string QpROzyRTREeAT;
    int uDZnGYHOuChwDq;
    double CSpZtRzFj;
    int MeTozbdWwEY;

    string EfKtyKqI(double xXHiRlD, string XeAzDivaJEzIq, int naNkpO, bool ePuLIbIVEWnhpzm, bool CbwTJqokIKfb);
private:
    double ipGdJWsmKNsQ;

    double KNCmF();
    bool oIVuAEjucUQzWyKt(string VDGVfhGQLPf, double IXXbKGTT, string urRjWGSfNcDK);
    string ynjvXUobeS(string CwwobcDst, int TGfZvhGvRMymaaQV, bool UXLLi, double SSdGbFSqRyCPSh);
    bool wysrY(string oRCiBTLqXXnLdKgT);
    void WwiCQRJhOzvgC(string acTjRKyi);
    string dCzNeuoE(bool GEFtKubZICNqHn, bool BOKJgjhCi, int qKHZDRscYly);
    void BjOhlw(double KQFiPBWKcLksKZQ, double TlgfxdVAmzMBRQXO, double NgQENEfhZpWayHUo);
    bool JFHfkuti(bool XGAIGPiBZu, double lFFRJDAD, double uQTwUj, double EKMEBxa, int JNVGHNYzDPfHvPTn);
};

bool ljMVvKBA::xMlnJhrPbiV()
{
    double KELfcOfL = -408601.6476576466;
    int TwQdCDDzTLZG = 1750595803;
    bool krbJXbUrg = false;
    int wrGLWI = -322194401;
    string StkTNmMb = string("benEPhZJBSZFzVFlmLySIOfDLfYZijItXQW");
    int eRJZcmPQYj = -200706393;
    string LUznmHeAkbFqD = string("uRvQgsPmufoGCtDZhXjHPerGzmCEtvwMdXvtniBOVmPGUKLuYJRnkHmReaVHmgiEykzeFpNkJHMDQ");
    double sAvTK = -816550.6835864219;

    for (int ILItmdpvRJ = 868608275; ILItmdpvRJ > 0; ILItmdpvRJ--) {
        continue;
    }

    for (int jKbBv = 1173514649; jKbBv > 0; jKbBv--) {
        wrGLWI = TwQdCDDzTLZG;
    }

    return krbJXbUrg;
}

double ljMVvKBA::qmxYRI(string DTLEmBkWrJqtl, string eIaiIJWjRZLUrfrB, string xpGfLMZa)
{
    string ELlRqha = string("KHAJXURWOPbvHsdFWXeZBTgpJAhtIdCtvfyZnQqSyVkvKSbEApDlybPSNhJSVdlRLEmFMaFRhvxMdPgcAzGkLjGBglujTkcKQJnsLbZKRtlSOQskggCfZKRsQyqzXKlkwTIPdLZoZJnszOJwqZvuLFrkFbJtGOulaXHJKZQhoYlCjLlTOZFkTzMgJUzrbMXVeHAAXwoTxfUfhlnKUbNDebQWJYVwNmva");
    bool tRnKaDywHkWJGEhS = true;
    int OXdaD = -505942124;
    string fYRyc = string("fTpEbttvjNphepxbsvmPNaaPmJXbDiynkujtCYrTrwQwqzRKKLVbkANFIyCJNRslfzRtNNpkIGlmsSbPokXppsEdagcjqAHGUkcvEXSshWggEOWRoqwHfjjrPoNqgFbPifJYmJogYjdrIHwghZVyFXSrkebskizgSbzMnlRqpKIYdFmjgJbvOzsmESfyFJgWJqvFBrvgTDmGeKPQfKKKOWPcSKtagr");
    double CVFXeEBtiYvAwuyf = 557412.9916866298;
    bool gnkqEeQeAu = true;
    bool yCUmI = true;
    bool WKqJAiZgHeI = true;
    string JSxRUMs = string("UhrsRJKjTIXrGpNRXEtYUFJsBMMwbCBhgFOWPUrJflJqQRDtoSftDblDoaZC");
    bool tqdEuwjjTAeVzUkc = true;

    if (tRnKaDywHkWJGEhS != true) {
        for (int hzUxeoRjiug = 1250443368; hzUxeoRjiug > 0; hzUxeoRjiug--) {
            continue;
        }
    }

    if (fYRyc == string("fTpEbttvjNphepxbsvmPNaaPmJXbDiynkujtCYrTrwQwqzRKKLVbkANFIyCJNRslfzRtNNpkIGlmsSbPokXppsEdagcjqAHGUkcvEXSshWggEOWRoqwHfjjrPoNqgFbPifJYmJogYjdrIHwghZVyFXSrkebskizgSbzMnlRqpKIYdFmjgJbvOzsmESfyFJgWJqvFBrvgTDmGeKPQfKKKOWPcSKtagr")) {
        for (int pbdmmYj = 71146798; pbdmmYj > 0; pbdmmYj--) {
            gnkqEeQeAu = yCUmI;
            JSxRUMs += fYRyc;
        }
    }

    for (int jDIKGaZYu = 245477982; jDIKGaZYu > 0; jDIKGaZYu--) {
        DTLEmBkWrJqtl += xpGfLMZa;
        yCUmI = ! tRnKaDywHkWJGEhS;
        ELlRqha = JSxRUMs;
    }

    return CVFXeEBtiYvAwuyf;
}

string ljMVvKBA::dzTlVSYWLDqcHOS(string ieFrecdb, bool NLTOtLGNZkfjr, int yOIGK, string nmjgMtBxF, string efDyOLK)
{
    int EcqJeobka = 1581150895;
    double GLItfcyutMAh = 869831.7913704192;
    double jzfpg = 997730.3178631024;
    bool zpqFKxIDsxmHjXd = false;
    bool KHTEINgzjCV = true;
    double nfQHP = -992630.8082439265;
    double KJGQzQb = -49447.79034667641;
    bool OpVkwVrgf = false;
    int BNBbmZMmqJu = 1562562955;
    string PwUNUYfbj = string("qPmlNucmxrbiEazoBATqLtmDoMukVTiRlYlQtsasEogDCYSnyhbIBLGCLvqGUBtSbvDQlmqiUOxXeofkpQmlblKhBNEStA");

    if (KHTEINgzjCV == false) {
        for (int eTFrgceLJtQQhl = 416462946; eTFrgceLJtQQhl > 0; eTFrgceLJtQQhl--) {
            KJGQzQb *= KJGQzQb;
            NLTOtLGNZkfjr = OpVkwVrgf;
        }
    }

    for (int nPhFclVAjAYyy = 1358091619; nPhFclVAjAYyy > 0; nPhFclVAjAYyy--) {
        NLTOtLGNZkfjr = ! OpVkwVrgf;
        OpVkwVrgf = ! KHTEINgzjCV;
    }

    for (int EVaWOyHLCGQ = 1660413424; EVaWOyHLCGQ > 0; EVaWOyHLCGQ--) {
        NLTOtLGNZkfjr = ! NLTOtLGNZkfjr;
        jzfpg -= KJGQzQb;
        ieFrecdb += efDyOLK;
        yOIGK *= yOIGK;
    }

    for (int aBUcxBsdEeqKjkOE = 377039082; aBUcxBsdEeqKjkOE > 0; aBUcxBsdEeqKjkOE--) {
        OpVkwVrgf = OpVkwVrgf;
        KHTEINgzjCV = zpqFKxIDsxmHjXd;
        ieFrecdb += efDyOLK;
    }

    return PwUNUYfbj;
}

string ljMVvKBA::jkWTgUHCqScgyLo(bool wHCuVl, bool GSicms)
{
    string kXGipNPgvFqZ = string("RGsGhsHPbmgvGJfHlycAjyWcyoKhfERPSwiCLJUeTjPLtMMuCWULjbGPUjRQNCqFFRlnXMSYMOlLegbDPZSyGXrbVtCqgpTCDnzLLDTibnMlsAPdGExcpifYNYaKYjKJDIazaFhiMAQUjFaKJsEnVZyZrCxKrqHdzPLrmtebIHLqQqbqmZmhvOQeAkB");
    bool ZSCAmhtbS = false;
    string nFAinfosCmTBmf = string("jmBteIFKyDpiSmTagtHtaCnMIbzUsugCViguuIHkEKTOisqSzulieUopG");

    for (int ZVNblgABsw = 1113643215; ZVNblgABsw > 0; ZVNblgABsw--) {
        wHCuVl = ! GSicms;
        GSicms = ! wHCuVl;
    }

    return nFAinfosCmTBmf;
}

bool ljMVvKBA::WAUcuADykTas(int EMYmQKMtj, bool EQyVGCNwOZmv, string whWElakID, int FEZetl, bool PpQPAcd)
{
    int XVFETWNwMbkYuEi = -1590509610;
    string KOtPwFmFftK = string("SuBCFkQleotUohLnYtIUjWnXKcOgIkuzuCTTNsALtEjUkAWagUxesPGbPeuVHkziuHlMMafOElziwpwcWjiQsIHysmGVHHsrOifnAXToKwVDXDkTYsdZbsNOKstvBSrfWVtuiaOvbKGjwYagboVWdKSUWfesolUwGQJFQqQutoRche");
    bool JHFLH = true;
    double GxzrKcfOZLRMR = -66211.32073172831;
    int FGdRNeYzaGn = 1145610059;
    bool WmjId = true;
    double ixCutZbIfcKQoLC = 795840.0727167604;
    string fYejpXfhnzjSM = string("SAqahPjkBMqotTBejeFvVAISXiPRYrnNHpfBPHwYgqLljghweEhofVowErqJGlqiLxCSsjWNSbvZJVXkRCtwjiFidbIPWZZDJNOqjQCsyzgBfCCWikDeSVEMwLzyrdiSGZLmloDcbTkhWSeEecAgXgIKqfRLgUtwUVkMdQuymknAnwexGmNlYVJgHjyASZyYSCtCgPtJVMjqSklocRpLLoyVSUETJHOXoqoaTVA");
    bool oRDjIaxZ = false;
    bool RvmndRuxUojo = true;

    for (int xABfqNH = 1386802926; xABfqNH > 0; xABfqNH--) {
        continue;
    }

    for (int bdeUiHq = 886505691; bdeUiHq > 0; bdeUiHq--) {
        oRDjIaxZ = ! WmjId;
        WmjId = ! RvmndRuxUojo;
    }

    for (int uEpMBpH = 1690081296; uEpMBpH > 0; uEpMBpH--) {
        continue;
    }

    if (EMYmQKMtj > 1145610059) {
        for (int GKOeEQCOYCEDx = 1693553793; GKOeEQCOYCEDx > 0; GKOeEQCOYCEDx--) {
            continue;
        }
    }

    if (whWElakID > string("qodsFJaCtrIYEbOtayLZfFOBVVOJcvEvAXoVLTHqPYrYXBhoObNqdLGDtcSMWUKTrloYlrisyiBxxjVNvbHLxNgfewwdowcDUVBtZSnDxGNdQkWkoMKOHUflWUwQUqvQrxjVOjNUzEPuNEmUymFEgUNPBTSJw")) {
        for (int gZsioxRjDKlUEOX = 1520137666; gZsioxRjDKlUEOX > 0; gZsioxRjDKlUEOX--) {
            PpQPAcd = PpQPAcd;
        }
    }

    return RvmndRuxUojo;
}

double ljMVvKBA::VBuJljjCuoIbK()
{
    int KOFuvdkQPq = -478817543;
    bool qsTZnYvcn = false;
    bool gYDkeHTAOVmrD = true;
    int TMjJBCp = 2004460194;
    int QGbIPpaSu = 244722219;
    int tnyYO = 731549699;
    int uhCopp = -1848461944;
    double mTxdSsH = -456247.29762466927;
    bool FbWVBqTIJTLOsAz = true;
    bool nlKGQV = true;

    return mTxdSsH;
}

int ljMVvKBA::hEwQRWx(int xUdtb)
{
    double qfdpxxkAKSN = -900250.2128071139;
    string QxyLTdRyhtfM = string("KVOkssjYkTpuwHNxHeNQBBgliUTYhceYaTXazYjzZWqzsYcHvNktQepVhwULvLqDUUhPGkVVtAwfNriWYQDbnfCNyIryMzdWhGfQSLKVeNXTkjsmwpllgbxtunMrauRreyuXyGwnHxWEiLzhhawYZAKhOWBsTusmbOgU");
    bool OjEnZSgQZ = false;
    string UchbrVZsSdG = string("jSdSIAAxMYmqpBYXioNPOYaEMHAzxIjhyCGvfLoelEgfkOlMBksPLxDLQqlLRvRshzbwxskbpyJZaKlBAlBbeHjIoaQoIAIRrMdGwYUYfayOYtrDytfqVoFuLRlRmDifQuLodpqeneRFYkrXgfxICTeYDZgnawLFslFRUYyqRIRSyYPiOPjYfPMdDsEaQOWuIdtpywcaMpFpoxxRITQMfZOIe");
    string FgHGVQdi = string("lonExOzzWxRGWRdnpsTjtjOpZsfhCLUGeDdknPnppRiyknBJJidNSeAbcrgLVihlDFetWSCTtrhzZKboxjFpHoCU");
    double jTAVAe = -10627.164172412013;
    bool KpRjXKFDGl = true;
    bool anKaYQ = true;
    bool qCSJbOwthoRbO = false;

    return xUdtb;
}

double ljMVvKBA::ZDKlrpyr(int RUgbIJyDT, bool CeNamlRWDKW, bool ILbWlhfNgJ, double kxnEEjkfn, bool SNpuRmNihiavHwI)
{
    bool jDgLytQtXKBdhGx = true;
    bool GRyJngvqinjdRRvk = true;
    double kPlxIkrcq = -393515.9881905803;

    for (int wLuyRk = 487171849; wLuyRk > 0; wLuyRk--) {
        CeNamlRWDKW = CeNamlRWDKW;
        SNpuRmNihiavHwI = SNpuRmNihiavHwI;
        ILbWlhfNgJ = SNpuRmNihiavHwI;
    }

    return kPlxIkrcq;
}

string ljMVvKBA::EfKtyKqI(double xXHiRlD, string XeAzDivaJEzIq, int naNkpO, bool ePuLIbIVEWnhpzm, bool CbwTJqokIKfb)
{
    double Dhdgj = 700513.264300289;
    int gnJvLCvg = -1126465608;

    if (xXHiRlD >= 700513.264300289) {
        for (int DmAMuIG = 568071416; DmAMuIG > 0; DmAMuIG--) {
            CbwTJqokIKfb = CbwTJqokIKfb;
            gnJvLCvg += naNkpO;
        }
    }

    if (gnJvLCvg == -2100013768) {
        for (int IXznsUTPTbIRSM = 1017612628; IXznsUTPTbIRSM > 0; IXznsUTPTbIRSM--) {
            ePuLIbIVEWnhpzm = ePuLIbIVEWnhpzm;
        }
    }

    if (xXHiRlD == 700513.264300289) {
        for (int zVpGYiKynw = 51265280; zVpGYiKynw > 0; zVpGYiKynw--) {
            xXHiRlD /= Dhdgj;
        }
    }

    for (int UIWifQjFwDCkIeo = 537104347; UIWifQjFwDCkIeo > 0; UIWifQjFwDCkIeo--) {
        continue;
    }

    for (int UYZHzcgF = 1364319972; UYZHzcgF > 0; UYZHzcgF--) {
        xXHiRlD -= Dhdgj;
        CbwTJqokIKfb = ! CbwTJqokIKfb;
    }

    return XeAzDivaJEzIq;
}

double ljMVvKBA::KNCmF()
{
    bool HnqmfMaW = true;
    int eoyZiUHfR = -2085371620;
    int gUTniIXfZHlZLG = 374519223;
    bool pHenJXi = false;

    if (pHenJXi != true) {
        for (int XnUaUSsJAdRLEHEb = 2042916615; XnUaUSsJAdRLEHEb > 0; XnUaUSsJAdRLEHEb--) {
            pHenJXi = ! pHenJXi;
            HnqmfMaW = HnqmfMaW;
        }
    }

    if (HnqmfMaW != false) {
        for (int rTbMBy = 891030809; rTbMBy > 0; rTbMBy--) {
            eoyZiUHfR = eoyZiUHfR;
            eoyZiUHfR -= gUTniIXfZHlZLG;
            pHenJXi = HnqmfMaW;
            gUTniIXfZHlZLG += gUTniIXfZHlZLG;
            HnqmfMaW = pHenJXi;
        }
    }

    for (int hEJeOtCHShVo = 186191645; hEJeOtCHShVo > 0; hEJeOtCHShVo--) {
        eoyZiUHfR += gUTniIXfZHlZLG;
        HnqmfMaW = ! pHenJXi;
    }

    for (int nGEkvZDP = 1381707636; nGEkvZDP > 0; nGEkvZDP--) {
        HnqmfMaW = ! HnqmfMaW;
        eoyZiUHfR -= gUTniIXfZHlZLG;
    }

    return -32564.07856487456;
}

bool ljMVvKBA::oIVuAEjucUQzWyKt(string VDGVfhGQLPf, double IXXbKGTT, string urRjWGSfNcDK)
{
    bool PzgVYPiaoOtv = true;
    bool yyeSVFoAiXKG = true;
    int ZwhbEYCWPvb = -764316157;
    int WBshXaOAmbJDknf = 731732329;
    int BajyTiDtZuiNZH = -858373217;
    int QBnsTdQvRToRx = 736609485;
    string kWupi = string("vjTHDOgKBrSnhsgDubehWRiastjnLOVPXSzkVXrWPIOvWTmpHiOSFJefGChinftCEOURgROIvxCUoaUYuhLlAZUUZwYBXCQuQjkfhjhmruvejOHSauFOZAOCtmyErAFIuKBrsHZQYQeMyeXWosRnPvbpEMfOFkHOKvFcCEywYBMAmIqCpvM");
    bool qtWVFTiT = true;
    int evyLEIUVtKHVu = 799950804;
    bool djYXRgF = true;

    for (int UVDUp = 1590768119; UVDUp > 0; UVDUp--) {
        QBnsTdQvRToRx += ZwhbEYCWPvb;
        BajyTiDtZuiNZH = ZwhbEYCWPvb;
    }

    if (VDGVfhGQLPf < string("MtcClQiVcFIZVIhhKUUxblxJKCKLeFTVuraAONLKdcofKQfRFQIqzrReeRFiklWgWBluZzRsHYLIqRaFNAKeHCLXARUuRzxzFTnzVZSswVopVvCUDhbKfDqALWwUFkcdmUqTalDFduzDZggYgBtNWOxbxgHNDWpiwJhBTiewXWCtQguHmdgocbBvCvdjPoCtcNvGfxxbgzZiEdaFpUsFKhoCjcsEL")) {
        for (int eZjmb = 1546886933; eZjmb > 0; eZjmb--) {
            BajyTiDtZuiNZH /= ZwhbEYCWPvb;
        }
    }

    for (int vhaegmoMVAzNLF = 180763887; vhaegmoMVAzNLF > 0; vhaegmoMVAzNLF--) {
        continue;
    }

    if (ZwhbEYCWPvb == -764316157) {
        for (int GFDwBtEAHk = 1635140305; GFDwBtEAHk > 0; GFDwBtEAHk--) {
            IXXbKGTT = IXXbKGTT;
            qtWVFTiT = ! djYXRgF;
        }
    }

    return djYXRgF;
}

string ljMVvKBA::ynjvXUobeS(string CwwobcDst, int TGfZvhGvRMymaaQV, bool UXLLi, double SSdGbFSqRyCPSh)
{
    string KvdSg = string("kTuEcawSUTNiWLTfqrkUOePhfVQTGchdauKsmmEBipNFTgifnApVwtMMfUArJhStbEgkFttguCJGWyIsTVsnUSmxBhjTESMsrHiZngPjlZHOotGEgndZfkOXGAaOUJPFhumWsJQldfFBNFOIUsiijLmiusvHuSUQnpxNTLrHjxmVagixkooeaEjWzJjDYEvUJNsLGMxKIiIcebCVkvmsbCVRIXQQYEasFYvpeJPBMgkBNjdq");
    string ZKzPcJQ = string("uabkxwqmjNcUROmttDjhnfjMByvINhIWApaJhdoIkCOdNNsEQqkmTzPYGowetzoDIxhlHgCnpwWgZqLIMwCvtkJQzadXCIBfDLOSWJJpsFQZGDCfNnB");
    string ZZUcSfCruqr = string("pkkggJRiuLSExFJduUXFPHuQgaFlbewIjMzdIiakmcPKRBnexjOGSOdDXBDbWsaqrvsWOOjMJVJSOZGBJEXAjqLpxpYSjZHnztsJBepFAPbQpHuInctUMKapaQQqnT");
    double FfoxRzksOArv = 49500.707300605616;
    double jxMrHUreP = 510877.50876199343;
    double oUbmIkguCgLm = -78449.16324106396;

    return ZZUcSfCruqr;
}

bool ljMVvKBA::wysrY(string oRCiBTLqXXnLdKgT)
{
    bool YCZLdtCdSYCMaSch = true;
    int jDQcJoVB = -31616921;

    return YCZLdtCdSYCMaSch;
}

void ljMVvKBA::WwiCQRJhOzvgC(string acTjRKyi)
{
    bool EmlyWcueIGrsXXI = false;
    bool yZybPCY = false;
    string pkPeWObeQWfBenC = string("qHyHReOnhUBvFCboupopNQOApQYixjwVaCiaLRDGnKItgyLFsPcCaKlYBbFSZJhSsiQzPrCZWYGFoyXqDyZtJUHCYqimTLkmBqxABK");
    bool jcylcA = true;
    string hRdvzcfqnzrCFN = string("DSFuiSbyMVYRRTTbngiZvLuNoKfwmtNYLBXJEMTIgQ");

    if (pkPeWObeQWfBenC <= string("HSFtTTPcSOKSvMnlnybbMyFlmowPFfmxTIfIESejKrgDHlIVMDPUUkstNpQJuSdKPHAkDeR")) {
        for (int DzxZldH = 1638862337; DzxZldH > 0; DzxZldH--) {
            pkPeWObeQWfBenC = hRdvzcfqnzrCFN;
            jcylcA = ! EmlyWcueIGrsXXI;
            yZybPCY = ! yZybPCY;
            pkPeWObeQWfBenC = hRdvzcfqnzrCFN;
        }
    }

    if (yZybPCY != true) {
        for (int cXQhmbimk = 294397492; cXQhmbimk > 0; cXQhmbimk--) {
            EmlyWcueIGrsXXI = ! jcylcA;
            pkPeWObeQWfBenC += acTjRKyi;
        }
    }

    for (int hegkrdDS = 1811903440; hegkrdDS > 0; hegkrdDS--) {
        jcylcA = EmlyWcueIGrsXXI;
    }

    if (yZybPCY != false) {
        for (int OlXFtgQo = 766889694; OlXFtgQo > 0; OlXFtgQo--) {
            continue;
        }
    }
}

string ljMVvKBA::dCzNeuoE(bool GEFtKubZICNqHn, bool BOKJgjhCi, int qKHZDRscYly)
{
    string RsAkLibRuKsp = string("jtUlVRBNGoaPVEwWgJmwkmWrmtHbmOTFBsqaBoSKWnAaAfluojidGlqVMGHhzWKyKLFjwevFggzozAdLNjcdYOUnWhVdIpJmXcpfAvlRnmGQFEDn");
    double YljpiLIbSmcQM = -194760.96665401934;
    int RtlbCLEdVQ = 879065033;

    if (YljpiLIbSmcQM <= -194760.96665401934) {
        for (int WysNkCkvrmxUch = 1313962293; WysNkCkvrmxUch > 0; WysNkCkvrmxUch--) {
            BOKJgjhCi = ! GEFtKubZICNqHn;
            GEFtKubZICNqHn = ! GEFtKubZICNqHn;
        }
    }

    for (int mtnaOAVYtR = 1907695150; mtnaOAVYtR > 0; mtnaOAVYtR--) {
        BOKJgjhCi = ! BOKJgjhCi;
    }

    return RsAkLibRuKsp;
}

void ljMVvKBA::BjOhlw(double KQFiPBWKcLksKZQ, double TlgfxdVAmzMBRQXO, double NgQENEfhZpWayHUo)
{
    string mRPkTUKNEJ = string("sPZtDuffQJcZZcmAxIGOlBDRqrsrGgvMBaiPayjccPnSELIBcajVgYCRlalpDkhNFdpJsDnVmDTDUrYaCMcDFEmidnqgKLvvH");
    bool EnCXlSttyr = false;

    for (int jeXZGck = 768592493; jeXZGck > 0; jeXZGck--) {
        continue;
    }
}

bool ljMVvKBA::JFHfkuti(bool XGAIGPiBZu, double lFFRJDAD, double uQTwUj, double EKMEBxa, int JNVGHNYzDPfHvPTn)
{
    string IImzlVdLfZuD = string("kTgoXlTarkbwMspzIGnZ");
    int NxRuTJISSD = 1699017915;
    string gzSaMOJYoqvYk = string("RCvueFycQdmLdiqUxFUjrYNfxJPkzVKJfpHVkJeRtyrcRixnWGBWZeyYHbmLAsBhNtVIZmmt");
    double vwUoRlZTRfLCpSUz = 683558.5326294723;
    int OUEcbIXpyI = -272031825;
    double cElRv = -804161.7354392818;

    for (int WWXfkHGrNuyqJ = 253223095; WWXfkHGrNuyqJ > 0; WWXfkHGrNuyqJ--) {
        continue;
    }

    if (NxRuTJISSD < -272031825) {
        for (int rDRMKPYd = 452761487; rDRMKPYd > 0; rDRMKPYd--) {
            cElRv -= lFFRJDAD;
            uQTwUj -= lFFRJDAD;
        }
    }

    for (int AbMXaH = 1014972068; AbMXaH > 0; AbMXaH--) {
        lFFRJDAD /= uQTwUj;
    }

    return XGAIGPiBZu;
}

ljMVvKBA::ljMVvKBA()
{
    this->xMlnJhrPbiV();
    this->qmxYRI(string("JelbRznvuBnDOnXACclxJZvtcn"), string("ZinGPnAeRjPEaGFwlNusDNTxrceTXTaQylwFlXpOFdNNszvjeCTVlOoPSpaARgezISdSlCOwBaMMAmscjflLSNpSYyePgbeAFQHuzf"), string("ebSKOyOBfMZnuZIMaVtqjplehfrUoPHZuSsuppnkiKpsoMnUQzYvbthwBAagGXjjdFxqkftYzUYupiVMiECzQtInSUyIngnnDBEHUoBeGlAMrREBQ"));
    this->dzTlVSYWLDqcHOS(string("mTOIJolomZpxXVvjSBgwnFizfXHmyICTZoTLCiiCjyNdUPRvQznjZbePrFvffriDVizMMoKcFsGUBWmGLlNkkXRwNGnfYnZkhOiYSxOgHdNaIoLkvKYVzshtwFcclVINfENzOhPtWcpJLFvVwytDJyqSEwgzvQBWhUpGUMzchMmgqBcprqtHEHWMIVqOZCLdyDEq"), false, -1519338743, string("IaCceFBXTRIzQYrfJUobyoiPnohkJZyiXuBoXqNASwSsnelLkktfqJpVC"), string("XokIBrHJzLQABzbxTdXkepbeQNLWAEZsYbeeMDUQQCynVxTNdwuTTNUyfGnWCwgQxOdrcGZbfqgWeyEcxBeRGOyKnRwrsCNkmmdaMJMShSIgvOEp"));
    this->jkWTgUHCqScgyLo(true, false);
    this->WAUcuADykTas(-643507271, true, string("qodsFJaCtrIYEbOtayLZfFOBVVOJcvEvAXoVLTHqPYrYXBhoObNqdLGDtcSMWUKTrloYlrisyiBxxjVNvbHLxNgfewwdowcDUVBtZSnDxGNdQkWkoMKOHUflWUwQUqvQrxjVOjNUzEPuNEmUymFEgUNPBTSJw"), -52527321, true);
    this->VBuJljjCuoIbK();
    this->hEwQRWx(-162697000);
    this->ZDKlrpyr(-30985683, true, true, -678730.2257740897, false);
    this->EfKtyKqI(-674492.678961595, string("qlunsiMVdaNmyXeiaCAlezsZHcidMCeJWzUIZAkjHGLgEYDsmmHOYQbEwKorLtPRmdZtrCvhWFbRkbxmCvQtkwjNgcVepYRDOwkIbrSgbNtnrZZGnpEyDnbkFCOzvDrXWJoRrhIYGkVlsVhcFJLwrRkmRGdXKXQcREAHmRMjQUFigpemoFDWYnWpoJigOC"), -2100013768, true, true);
    this->KNCmF();
    this->oIVuAEjucUQzWyKt(string("QrMhppJygeAqtWaACffzWNMLrqFbLVHyTWBowJxMaWrWCd"), 924700.1951859648, string("MtcClQiVcFIZVIhhKUUxblxJKCKLeFTVuraAONLKdcofKQfRFQIqzrReeRFiklWgWBluZzRsHYLIqRaFNAKeHCLXARUuRzxzFTnzVZSswVopVvCUDhbKfDqALWwUFkcdmUqTalDFduzDZggYgBtNWOxbxgHNDWpiwJhBTiewXWCtQguHmdgocbBvCvdjPoCtcNvGfxxbgzZiEdaFpUsFKhoCjcsEL"));
    this->ynjvXUobeS(string("rcKSclXXgddrEqQZCZpiQrvXSV"), 1617734646, true, -373738.27177073923);
    this->wysrY(string("mwiVoEVodDCfyoOGyVQYOYBJxdI"));
    this->WwiCQRJhOzvgC(string("HSFtTTPcSOKSvMnlnybbMyFlmowPFfmxTIfIESejKrgDHlIVMDPUUkstNpQJuSdKPHAkDeR"));
    this->dCzNeuoE(false, false, 423340926);
    this->BjOhlw(803732.9733651902, 885936.1782366524, 487120.57597684173);
    this->JFHfkuti(false, 954617.7545527866, -706549.44869983, -253864.08398118446, -1844164695);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BSYnSOvDX
{
public:
    int HXhLnM;
    double pudZwkhdefhzEk;
    bool YRiifGplf;
    bool Baphno;
    bool gqbRpoWHHJqeCt;
    int uSGgaH;

    BSYnSOvDX();
protected:
    double UOAotAmiKjYOvhTg;
    bool KWUuUFVAfhmGFQlL;
    bool BchkHmhmlm;
    double gSkhaL;

    double gxdrfaRqFlr(int RZwxqJpDbChN, double wpUHRPnrgBkcPgo, double CcDtTZTKYbbK, bool VCrOBSEIywu);
    void oiecFNUmqmrSu(int tPKHn, int CZwOQtOkHruKov, int cgVwgNJHKITVTIzB);
    bool pCimFm(double cJGJarfYaS, double jdTMyCn);
    string CJumSWPAFIJW(int rvnlZRoU, int CAvDQWgI);
    void phQtgDgPDJi(string kShshNuTQkLcbay, double tPmZvsWtGy, double ydTgSClx);
private:
    int EVyKgATubMhEz;
    int jFdkNHOULPIVSaAY;
    string YfCEZQlEfpZBdV;
    int MzzWECATjKKDGSWU;

    string ITyRobqUo(int uOUpMFocCsP, string oRKzNFJEzl, int jbyRBpz, string fkwszszBQdHlWozh);
    bool FdiImeadm(string Yuylqhyho, bool eyezHbJgK, double EOkWfTnIm, string xzXtuwCyyHt, double VzfWql);
    double kLAWYNpPWWH(int vxfFSoeaqHfpC);
    int fhTwiCfHCCfsfdsE();
    double hbYQihkLQTkhZp(int EtLrZS, int fuKRAmI, bool YcGnMTaDhRZEU, bool CsLbksrnEcSnRv, int jxFrXQ);
    double nmDzvqsVjem(string fyrqyqr);
    int FDAmnboSXkzy();
    double NpnCfrYKtfOGxkS();
};

double BSYnSOvDX::gxdrfaRqFlr(int RZwxqJpDbChN, double wpUHRPnrgBkcPgo, double CcDtTZTKYbbK, bool VCrOBSEIywu)
{
    string tMoeuEVDEFL = string("KTSLZKUrqhwqVhkWRDmtKAGSiXXXgdOfjAwcgtsaaXRkYoRAaXoqMrKKmpKkMjrJzErHXBwszNwJquYjrROVKCEcPFzPKpnprWYanyjrDNhEsTIVCaVxAzZdCZSJAkQFJSQUeAENzBq");
    int hNgeRXO = -628506063;
    double MTbsQGDiH = -305340.1264848264;
    string KsebRzNGGwOqTtg = string("RMIyYhjdOgEuZfaSsjftXWSwIwKwqpHlrhUvwsnsXmvFBoiTKY");
    double WVbOINMHYVfupUB = 110883.41170126993;
    double DuyYgLoSLL = -313427.8747353962;

    if (DuyYgLoSLL != -313427.8747353962) {
        for (int nomMXbKJwfpQ = 648132975; nomMXbKJwfpQ > 0; nomMXbKJwfpQ--) {
            CcDtTZTKYbbK *= DuyYgLoSLL;
            KsebRzNGGwOqTtg += tMoeuEVDEFL;
            DuyYgLoSLL = WVbOINMHYVfupUB;
            RZwxqJpDbChN *= RZwxqJpDbChN;
            RZwxqJpDbChN += hNgeRXO;
            WVbOINMHYVfupUB += DuyYgLoSLL;
        }
    }

    return DuyYgLoSLL;
}

void BSYnSOvDX::oiecFNUmqmrSu(int tPKHn, int CZwOQtOkHruKov, int cgVwgNJHKITVTIzB)
{
    double hnwqJpWGxiYYmTZ = 499289.1980043845;
    bool nuxDHbcQmeyfpI = true;
    bool QziqI = false;
    double QTCvQFdlO = -928891.9963197346;

    for (int NWvZqOWbEFKdxeN = 2136105248; NWvZqOWbEFKdxeN > 0; NWvZqOWbEFKdxeN--) {
        continue;
    }

    for (int LImHtlMzTS = 1990651876; LImHtlMzTS > 0; LImHtlMzTS--) {
        QTCvQFdlO += QTCvQFdlO;
        cgVwgNJHKITVTIzB += CZwOQtOkHruKov;
        QziqI = QziqI;
    }

    for (int JrxvdkjVV = 2101174202; JrxvdkjVV > 0; JrxvdkjVV--) {
        cgVwgNJHKITVTIzB -= CZwOQtOkHruKov;
        hnwqJpWGxiYYmTZ = QTCvQFdlO;
    }

    if (QTCvQFdlO >= -928891.9963197346) {
        for (int XLIwZLwWbMuK = 264873786; XLIwZLwWbMuK > 0; XLIwZLwWbMuK--) {
            continue;
        }
    }

    if (CZwOQtOkHruKov <= 545852860) {
        for (int AJoXrAFpkN = 225167626; AJoXrAFpkN > 0; AJoXrAFpkN--) {
            continue;
        }
    }

    if (QziqI == true) {
        for (int VwLjAw = 203854086; VwLjAw > 0; VwLjAw--) {
            cgVwgNJHKITVTIzB *= tPKHn;
        }
    }

    if (hnwqJpWGxiYYmTZ > -928891.9963197346) {
        for (int cONxpkbwhF = 1375274534; cONxpkbwhF > 0; cONxpkbwhF--) {
            continue;
        }
    }
}

bool BSYnSOvDX::pCimFm(double cJGJarfYaS, double jdTMyCn)
{
    string AZizrhZToQ = string("hfatzPHLIaoTTjlJVQSZWDlNdzUowhgUyuGYyeNmmAINaGJcphDhqvewybCRwzhRZGHGyhbKMkYclLAEyFhqVjqzcTULUaCYnjSyiqjYnmklNXUJNVGcRKdUUqGoNIybkwjqQrjdGMOHEUAEeYRECZQelydfZBWcefXkufnvuhu");
    double LBXRbmd = 699766.9609477998;
    bool bKVqppOSv = true;
    string GipyeyndJbkxesg = string("FOXPWUPjKOONJjypuUXkHNdEidQOudVQZnAgePdjZiTPxDvcgGCVNcExAAhfsVjXZkHXXIzIqyWeMxLVhgnECvVCedmAXlFcQUxiFmMSjZMJaXHHYHirfPlaHgGsjmEvcKhnSJpTyePLKxdFgBgRfoCNjhPgzSJwGLvkoLjJosaSSLjbMPZRNifRmrpWjfMbkmHUypCbYgqOCCtUMPVWUtsstlFroJjZSJOXAdg");
    int qdTih = -619622648;
    bool WhrTqxOljwTkEZzw = true;
    bool dGlMorOToKGg = false;

    if (dGlMorOToKGg == true) {
        for (int ykXbiSgV = 637805840; ykXbiSgV > 0; ykXbiSgV--) {
            AZizrhZToQ = GipyeyndJbkxesg;
        }
    }

    for (int kXPxZILAThUy = 1423619111; kXPxZILAThUy > 0; kXPxZILAThUy--) {
        bKVqppOSv = ! dGlMorOToKGg;
        jdTMyCn /= LBXRbmd;
    }

    if (LBXRbmd <= -998269.8900235894) {
        for (int VvrDRUNqVx = 639971122; VvrDRUNqVx > 0; VvrDRUNqVx--) {
            bKVqppOSv = WhrTqxOljwTkEZzw;
            bKVqppOSv = dGlMorOToKGg;
        }
    }

    for (int jdpDtaORhQ = 529344833; jdpDtaORhQ > 0; jdpDtaORhQ--) {
        continue;
    }

    return dGlMorOToKGg;
}

string BSYnSOvDX::CJumSWPAFIJW(int rvnlZRoU, int CAvDQWgI)
{
    string CHQnVNTeak = string("uFQQmjNVHMHFa");
    bool gNTNHbMHFgTigUYb = true;
    bool ROLmub = false;

    if (ROLmub != false) {
        for (int SPvWJkrT = 1368070250; SPvWJkrT > 0; SPvWJkrT--) {
            rvnlZRoU += CAvDQWgI;
            rvnlZRoU *= rvnlZRoU;
            gNTNHbMHFgTigUYb = ROLmub;
            ROLmub = gNTNHbMHFgTigUYb;
        }
    }

    return CHQnVNTeak;
}

void BSYnSOvDX::phQtgDgPDJi(string kShshNuTQkLcbay, double tPmZvsWtGy, double ydTgSClx)
{
    double evCoeqmiiyIfRV = 91300.28136603127;
    bool msvqBWUuoTgOoIX = true;
    double TlUJxb = -704593.9624461634;
    string oVzZi = string("EGBEqvVOYuPidhdQeuHvrDAfYStdBhbycdrHmOksccDukfbiySzYIuqTceVMZGILryEyRinpPTnpDVwVEnHnkBxlkBdWtqobHMqjOXEWXUIZNqDpZsLOihCkoANhcpwmDKbpBjtwgdOBlOkYJoUpTfBqJHKhrNkqwaGMZOIuXwQySKKZojvleJyUnVJOKlkQaAHjJbYHfTVGtdVmAHIWZFPqaBUaJJuPoLxIOFTodNLeZSHGGNiJRy");
    double gunnNdwF = -502574.18795270496;
    int dHvqBvYOKrJRdOc = 2085098599;
    string gKXhpNXHGdaaWI = string("lVpDswfpXjQNrzkBaZHzBgjXVLrsiZLOiDVyXtWNnPaPMTXTQKXMMnYXWSeGQeIRAlLPhuqbtMSDgruDTtNbWRmsnnDXKnrFPTUUPYAoGrMjwBtqJgBPlSdANiyIaMpJNAsYDFjmDSPbzeEdpPPHkdylxCKknKWGQlPsHQgGTQbahHMRUUgfHfrxdHsCFmbMVawpetMOtuUjJpxKVmEgnbmJ");
    string SmZkS = string("vhMKwuGBBITHzaaOqLOSNYlHrBkcSgBZbqruLWHLDriUSTYGbpQZCJAgSgLmLvGkxJfdPQFccXGIWHpIfOqfCbdOuGMctetcAnzEEpqlZPbWjJMJJcdxXZCUvbfDTlEPPSYtQILnMSsTgssuNzvblTZZGBmYEGeWlcwxcLZpBahuoEXOmQkjTn");

    if (gKXhpNXHGdaaWI < string("EGBEqvVOYuPidhdQeuHvrDAfYStdBhbycdrHmOksccDukfbiySzYIuqTceVMZGILryEyRinpPTnpDVwVEnHnkBxlkBdWtqobHMqjOXEWXUIZNqDpZsLOihCkoANhcpwmDKbpBjtwgdOBlOkYJoUpTfBqJHKhrNkqwaGMZOIuXwQySKKZojvleJyUnVJOKlkQaAHjJbYHfTVGtdVmAHIWZFPqaBUaJJuPoLxIOFTodNLeZSHGGNiJRy")) {
        for (int ZpmNxjrg = 1915352076; ZpmNxjrg > 0; ZpmNxjrg--) {
            tPmZvsWtGy /= ydTgSClx;
        }
    }

    for (int vvDrRouGx = 84186247; vvDrRouGx > 0; vvDrRouGx--) {
        TlUJxb -= ydTgSClx;
    }

    for (int DmMWMpVt = 1803003399; DmMWMpVt > 0; DmMWMpVt--) {
        ydTgSClx /= evCoeqmiiyIfRV;
    }

    for (int SdpUU = 322975168; SdpUU > 0; SdpUU--) {
        ydTgSClx += ydTgSClx;
    }

    for (int AVtkv = 597867978; AVtkv > 0; AVtkv--) {
        continue;
    }
}

string BSYnSOvDX::ITyRobqUo(int uOUpMFocCsP, string oRKzNFJEzl, int jbyRBpz, string fkwszszBQdHlWozh)
{
    double KlEluId = 937766.4868336436;
    int gnbzQzPbO = 2076507271;
    double mnSAmplid = -821671.7669031194;
    bool xehPtkstQZccAcMS = false;
    string xnNbZ = string("diEoMCxhMdDSWNEdebeDeMGETEVBMZtaUTGAGZMyXpcLnMUmesKnnQOLVvlJlbheIFexrxbIlidVayPYjSFlqFYHvXLdIryIEPfyvqdEObcrAZQzAjIceaPdGwcAEuecmrNzXSUrEhWURJRtqzFRkGHODYxEMEfBzXuMPQOiFDvwNaCkbLVncKdVxGfCKqUwGq");
    int CSSmdw = 858080111;
    int lQnHGWsr = -2025744200;
    bool Dymjs = false;
    double qUcVaTUne = 232597.5827875873;
    string ePMwOWCxbBrcgTL = string("NYHviJzjChoyabnXYBGpYqhToRMHtSAzVQABKUFxUmbiYiJHoXgPXHsVpFhBZQtmTgMbbagHHKriu");

    for (int jvsuykR = 2041351037; jvsuykR > 0; jvsuykR--) {
        jbyRBpz += jbyRBpz;
    }

    for (int YbiWl = 121931942; YbiWl > 0; YbiWl--) {
        lQnHGWsr *= jbyRBpz;
        lQnHGWsr += uOUpMFocCsP;
    }

    if (oRKzNFJEzl != string("NYHviJzjChoyabnXYBGpYqhToRMHtSAzVQABKUFxUmbiYiJHoXgPXHsVpFhBZQtmTgMbbagHHKriu")) {
        for (int BusoXvNFtfTbko = 268352802; BusoXvNFtfTbko > 0; BusoXvNFtfTbko--) {
            jbyRBpz *= lQnHGWsr;
        }
    }

    for (int KILXrVLUC = 1799600750; KILXrVLUC > 0; KILXrVLUC--) {
        lQnHGWsr *= CSSmdw;
        uOUpMFocCsP -= CSSmdw;
    }

    for (int qlKYKureHleiRJha = 1237238410; qlKYKureHleiRJha > 0; qlKYKureHleiRJha--) {
        Dymjs = ! xehPtkstQZccAcMS;
    }

    return ePMwOWCxbBrcgTL;
}

bool BSYnSOvDX::FdiImeadm(string Yuylqhyho, bool eyezHbJgK, double EOkWfTnIm, string xzXtuwCyyHt, double VzfWql)
{
    bool JqrpdZpYlNmw = true;
    bool GFyHWADHsGwf = true;
    int LDBHoXkpE = 395003198;
    string bBWTWeUyOqtlMe = string("kwheZreLkZxHlhkJHzbTaycMwAkjDQShBERGIPFJHiNXIFmTJevtrkblBiblPhiCSBYSYoYhWFXexXVMinyAfxytZjSWXWvznOzqviZZzjUYZtVRXbMMyfCIaBGNOtZKALbTZEMJkytgLOdEnWaZtiHeiSLXfOxsEWmBfXCNMHVVQYxaiYzNAoBbvfqlXdeqowqfDKVftKcKsUizSNMKEX");
    string YmHzJS = string("tVVgKbBzLVojJxBshvszOGgNdxVRzUHiRThzbOiCPmYjsdzKzWIFVEQcUuJfEMCkAVKAIeUlklAlpWa");

    for (int vqLOhQZPKnPi = 260632689; vqLOhQZPKnPi > 0; vqLOhQZPKnPi--) {
        GFyHWADHsGwf = ! GFyHWADHsGwf;
        GFyHWADHsGwf = GFyHWADHsGwf;
    }

    for (int gBBLvh = 392852506; gBBLvh > 0; gBBLvh--) {
        xzXtuwCyyHt += bBWTWeUyOqtlMe;
        bBWTWeUyOqtlMe += bBWTWeUyOqtlMe;
    }

    if (eyezHbJgK != false) {
        for (int vacAYpJxav = 845890289; vacAYpJxav > 0; vacAYpJxav--) {
            YmHzJS += bBWTWeUyOqtlMe;
            bBWTWeUyOqtlMe += bBWTWeUyOqtlMe;
            bBWTWeUyOqtlMe = xzXtuwCyyHt;
            EOkWfTnIm /= EOkWfTnIm;
        }
    }

    for (int cPvzzgOWnB = 2020014573; cPvzzgOWnB > 0; cPvzzgOWnB--) {
        xzXtuwCyyHt += bBWTWeUyOqtlMe;
        GFyHWADHsGwf = ! JqrpdZpYlNmw;
    }

    return GFyHWADHsGwf;
}

double BSYnSOvDX::kLAWYNpPWWH(int vxfFSoeaqHfpC)
{
    string yeQxIKTppzVRR = string("zNGpwkwddaapbacjzSioSDUdvbKQnMBpxSuGAmEmUmiToLLjjYigkzniWZkFiCrwfpvgWIOHgPZKxYyFEOwxnDGnNAmKNCnMucdYoSJbgqxowqeoBJpbYhtPpbBUbQeiocJiFkZldOzLGWqYDfQkUhDZbtnUAhcSUbJFaixKHCdXwNpQKdEKxfcYJXJFZFvKDAoPqFDqxigJJHusajSguzonRZkY");
    double OmpJFoclwhhV = 461325.14593297115;
    double TgXRkVJzew = 494176.69664121576;
    double YvtichdhKfQElTdk = 153940.19979602456;
    bool HXGoun = true;
    double igfJMPl = 1010463.4958976465;
    double FhECHPvuEMVBrcDv = 667258.4707725013;

    if (FhECHPvuEMVBrcDv == 1010463.4958976465) {
        for (int tsoQjfCDkO = 2080086320; tsoQjfCDkO > 0; tsoQjfCDkO--) {
            TgXRkVJzew += FhECHPvuEMVBrcDv;
            TgXRkVJzew -= igfJMPl;
            FhECHPvuEMVBrcDv /= TgXRkVJzew;
        }
    }

    for (int oBsPHUOMFgKOYrz = 1385085679; oBsPHUOMFgKOYrz > 0; oBsPHUOMFgKOYrz--) {
        YvtichdhKfQElTdk -= TgXRkVJzew;
        TgXRkVJzew *= FhECHPvuEMVBrcDv;
        OmpJFoclwhhV += OmpJFoclwhhV;
    }

    if (igfJMPl <= 153940.19979602456) {
        for (int PBwqNHx = 1486827172; PBwqNHx > 0; PBwqNHx--) {
            FhECHPvuEMVBrcDv *= YvtichdhKfQElTdk;
        }
    }

    if (OmpJFoclwhhV >= 494176.69664121576) {
        for (int HuSfn = 195488845; HuSfn > 0; HuSfn--) {
            YvtichdhKfQElTdk = OmpJFoclwhhV;
        }
    }

    for (int FwmlIiKZQFP = 62632294; FwmlIiKZQFP > 0; FwmlIiKZQFP--) {
        FhECHPvuEMVBrcDv -= FhECHPvuEMVBrcDv;
        OmpJFoclwhhV += YvtichdhKfQElTdk;
        TgXRkVJzew -= OmpJFoclwhhV;
    }

    if (YvtichdhKfQElTdk == 461325.14593297115) {
        for (int nCqmgPAaMO = 1305402244; nCqmgPAaMO > 0; nCqmgPAaMO--) {
            OmpJFoclwhhV /= YvtichdhKfQElTdk;
            YvtichdhKfQElTdk = OmpJFoclwhhV;
        }
    }

    return FhECHPvuEMVBrcDv;
}

int BSYnSOvDX::fhTwiCfHCCfsfdsE()
{
    double ptqsPZXe = -78210.1944753952;
    int uiSsUYZPzLfFVAF = 35429621;
    bool NcEDxtBFyjKsJtY = false;
    int svdrfAgnVcaltH = -434841096;

    for (int JlTFEF = 1420188116; JlTFEF > 0; JlTFEF--) {
        uiSsUYZPzLfFVAF += svdrfAgnVcaltH;
        svdrfAgnVcaltH *= uiSsUYZPzLfFVAF;
    }

    return svdrfAgnVcaltH;
}

double BSYnSOvDX::hbYQihkLQTkhZp(int EtLrZS, int fuKRAmI, bool YcGnMTaDhRZEU, bool CsLbksrnEcSnRv, int jxFrXQ)
{
    double LXzOrw = -988656.0046321467;
    double BREwyeeHoslgUU = 579156.4526249948;

    return BREwyeeHoslgUU;
}

double BSYnSOvDX::nmDzvqsVjem(string fyrqyqr)
{
    string bhzOEXFGUYwAx = string("zLVFICBZpcUqBHlIKhCjgvYYlcsLtmkJBHeivLzFPueBIlhABrdqIjrzjQQMBJQDguVbqJNnKDjGvjZbljVRmjSOfeWkuPAvoDDZcbxtwOxDsjpqnSafVYLkazBveBoCMaTFwqyTkKrTBhrIBPuYCUPetLuIdsvtnbqctLSlWjYVtkTuNYjRosKSeloXaxlDNvrdNdKgeqyPIskikQkQPrtJWTCXFmkVdY");
    string mEnakNvrZO = string("xLsc");
    bool rFFJUB = false;
    double iFGzT = 697415.3699774789;
    string gavVhIaUYQDtK = string("GQpBOrOlENgBaVpGEMLZlsPsYtWnAQbWtsBcMfJSOMRotFjIZfdhyBMZAlYNPKcfRkTPCOagQvmlJWpR");
    int wqVMwv = -1768227064;
    bool WakmiMCKJEyjdKuB = true;

    for (int MpHAgLKQoIVTYuiO = 957237337; MpHAgLKQoIVTYuiO > 0; MpHAgLKQoIVTYuiO--) {
        gavVhIaUYQDtK += mEnakNvrZO;
    }

    for (int NenGUegnUzvUZW = 1128185921; NenGUegnUzvUZW > 0; NenGUegnUzvUZW--) {
        mEnakNvrZO += fyrqyqr;
    }

    for (int WELGTo = 1800102060; WELGTo > 0; WELGTo--) {
        fyrqyqr = gavVhIaUYQDtK;
        gavVhIaUYQDtK += mEnakNvrZO;
    }

    if (mEnakNvrZO != string("GQpBOrOlENgBaVpGEMLZlsPsYtWnAQbWtsBcMfJSOMRotFjIZfdhyBMZAlYNPKcfRkTPCOagQvmlJWpR")) {
        for (int PBUqOPyuia = 883218477; PBUqOPyuia > 0; PBUqOPyuia--) {
            rFFJUB = ! WakmiMCKJEyjdKuB;
            fyrqyqr = fyrqyqr;
            wqVMwv = wqVMwv;
            mEnakNvrZO = fyrqyqr;
            fyrqyqr = gavVhIaUYQDtK;
            mEnakNvrZO += mEnakNvrZO;
        }
    }

    for (int uhipo = 1544278054; uhipo > 0; uhipo--) {
        gavVhIaUYQDtK = gavVhIaUYQDtK;
    }

    for (int muzInWStnIX = 1451412022; muzInWStnIX > 0; muzInWStnIX--) {
        iFGzT += iFGzT;
        fyrqyqr += mEnakNvrZO;
        fyrqyqr = mEnakNvrZO;
    }

    for (int NjsWxmyODhdleuNu = 1164611413; NjsWxmyODhdleuNu > 0; NjsWxmyODhdleuNu--) {
        WakmiMCKJEyjdKuB = ! rFFJUB;
        WakmiMCKJEyjdKuB = ! rFFJUB;
    }

    return iFGzT;
}

int BSYnSOvDX::FDAmnboSXkzy()
{
    bool TroipFtCQUJANw = false;
    bool DnRMshCHRZNXDeMY = false;
    bool Nuyccrk = true;
    int HDTQncZ = -1749012159;
    bool FhIHhjlVxbHHHZ = false;
    bool cukHXKsTg = false;
    string CzZvEFNyzuysVW = string("LGosGYhJbCbVPCXeuDYYjFCvdKSbctQiOFmoUjefvHJeIqzhftJtRaRagklnaIrLeyLjmtAzwNqGvIFwcnLCEiaYCJaHsryudTitAGnurFMThCKlApDydKyNXWRtneDrZoVrHbFkJqnMzUmcZJvlDbBlupJMRSHTElmfya");
    double mPWVmkA = 525564.0864907291;
    double ymSnacgVBmZXi = -255948.6946713808;
    bool bIViHshvlugFoxx = false;

    if (cukHXKsTg != false) {
        for (int zQPEEuwH = 32357221; zQPEEuwH > 0; zQPEEuwH--) {
            TroipFtCQUJANw = cukHXKsTg;
            bIViHshvlugFoxx = bIViHshvlugFoxx;
        }
    }

    if (FhIHhjlVxbHHHZ != false) {
        for (int LqZlxnHwxY = 44299274; LqZlxnHwxY > 0; LqZlxnHwxY--) {
            TroipFtCQUJANw = TroipFtCQUJANw;
            bIViHshvlugFoxx = ! bIViHshvlugFoxx;
            Nuyccrk = ! bIViHshvlugFoxx;
            TroipFtCQUJANw = ! FhIHhjlVxbHHHZ;
        }
    }

    for (int JkbgrunV = 1240220961; JkbgrunV > 0; JkbgrunV--) {
        continue;
    }

    return HDTQncZ;
}

double BSYnSOvDX::NpnCfrYKtfOGxkS()
{
    int mjxCq = 1482354193;
    string EBdMugmTNAKNFMm = string("tTKErJPtpVZtRGWwDxMMVoZsvSgtfxmSYQmcCjwEydBMhxKvFfRFSFbvfulWDAufjgNcwDUPSONZYJAcPODKlRuYpMprhBuLxISQICyUOyobGDSnTWbfaJXiiQoEsUUjStIIZGMnmwqCfDIOZUcMVbNVcFPVBuNDwDDwmgPJtwFRpaOypIvKOujfbRIJXxZDOGVzpDqtyNPVWikLeGWzKDFF");
    int aEaXbMWfV = -864816159;
    string GtLwPZMKQdzy = string("mBSXOJGlHsu");

    return -99450.63148775614;
}

BSYnSOvDX::BSYnSOvDX()
{
    this->gxdrfaRqFlr(-649388087, 1016664.8489626737, 481296.90690570173, true);
    this->oiecFNUmqmrSu(-309440192, 119616704, 545852860);
    this->pCimFm(-998269.8900235894, 735035.4131825665);
    this->CJumSWPAFIJW(-498918237, -641246073);
    this->phQtgDgPDJi(string("YHShiwfWxNZBzuYZBsORZlcGVTGdlwYIjrfYoQTNpYcgijyHFgTCPQlzlVVrlADPHeeSATobGQHKyLoHvnPWUyxBSOQRRd"), -366978.8143351487, 201230.94060004925);
    this->ITyRobqUo(-570707897, string("RzGtQpJJnZysGLfLxwNJBwURElOnoFzUPDpkWYDnUsWenCjnoONkjMuOepuydbRSdNiGGszbiPBrxtwkKIlkhPjqMeamgyPSfGWsrhXrhDpgDxLVShANXrZdScoTilbxjnuEzNTIZBDTMSgyKybVjOhsZNNRBJtNrMquMKqSxNRuogONagKdgSaKebAZmxOakDAHCZhfmZqFIhxFEIKXIbVR"), 1351734625, string("itxJRKZFIDhOxteCkbiWiAcrACWEmmMngiAUGDkQoILxKZymZnhyYmNrEcjvjzxzKoMxsoiejQGrUoTfhUleyYjJxNo"));
    this->FdiImeadm(string("XxihOcRcwtxRrxsfNHskXfltzRyKEJuBDEjBZXDPPTHjtpGYuRlWKErouCAzkMjSJXulJlHygOnydrsHOrwZmwawHNVRsGPLcPnOTkJKkpSDQvcFIKMbEYXcwOhPXDYBiljjATawAavcSsVRBMCRwOsXqYBWVpIrFozulBWwPAalhwxauApFHwYWPRgRWYlJFkNahUytQmLPDjSHRYvauNNoBqEKsxXFNVGtzvoioecJayK"), false, 618467.4451073278, string("wxMfgysuPRiaETRDzMvhrbqvpbCxegdnQTTWQnHBNtaoDXXwc"), -476385.8637608522);
    this->kLAWYNpPWWH(2076276663);
    this->fhTwiCfHCCfsfdsE();
    this->hbYQihkLQTkhZp(-1948570211, 545531041, true, true, 1391894259);
    this->nmDzvqsVjem(string("qTnIPyjyuGVxEVcctCTZwNwbuFBINKHQRyQcafRSwVrzavukwunMhFiPhyYTrdNtOPFxcDdvQQPPEJAvAVvFZeKiRxqvBgVdCKLGzyozFLLvvfpvaAfAbIXfsg"));
    this->FDAmnboSXkzy();
    this->NpnCfrYKtfOGxkS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pKJcwkgFeAFpaepf
{
public:
    int cfQsCBLYNRpStclT;
    double KXNxXgnMfVn;

    pKJcwkgFeAFpaepf();
    double wulbeVvaia();
protected:
    double BHliYVHH;
    int xMClPgg;
    bool hZWdHGaIsP;
    bool pIQfDfEPUnsTn;
    double JSmMCrAIPkdwhI;

    double WPZgqLps(double rsuVmdWNoZX, double ClteFyOXzw, int cerOWi, bool wkANmJtbogYsPC);
    void Xywclv(string MRGHDZUTDZusJvC);
    bool HNfVJdRkHTMbUd();
private:
    string RWtpiuoJL;
    int kCjTBnBvfGtF;
    double xdLKTBx;
    double AjgWvZ;
    double ifetPU;

    double pXNQtMg(string tmzwpI, double hcnTsyhg, string cOlRDmIdie, bool YPoCoj, int verLzAw);
    int BYyTk(string SsnsAvpTUzOBpJK, double FukiEY, int KGEPGrFxavMuryqG, bool RLEdMYNpryOGk);
    bool cYfVJvsK(bool wMfDxfSXVTjfsye, bool yZPmSPWEc, int qfOnrNhTf, string DjScHSFudhmDgLJe, int xoYjtxubeYZlGSfO);
    int zxhEMRJdPIm(double TumsdIsw, bool qiktQwP);
    int CIHPhNeTTVpObSG(string KAGCpJGOo, double CeFMtQEKH, double vROmsWhmtRJtOIW, string uEvTpNIQktKdjwHw);
    int VIGNTOGvbtegF(bool KaLFqmaUcx);
    bool UVlSC();
};

double pKJcwkgFeAFpaepf::wulbeVvaia()
{
    double TrWNsSlHyMi = -545512.3925288484;
    bool qRbkOciIMiNkehi = true;
    int VwayuAR = 676060587;
    string xFvozokPS = string("nwQQzTFYSBjEFMlNqmfBwVikpYDPTvnJzJcMZcpHgOqscBvmPiYDAXfNqtNmOpJuapbTUsDjYuxpxvAToGYhJQeJKLpwWQEgpCphyzRuwiGXkLbMoEAQNEpZAC");
    int FiQIOTCc = 55846416;
    double fNFNADfmwIXiH = 575843.4989516468;
    double zvfcW = 34895.72896665572;
    int wuILYXCqDqm = -1157039255;
    double InnRHSNOUvEc = -957616.4331511019;
    string Yjetb = string("gqbxJxiZyDGyxIXBEqhZOVqKVLwtJTWdbguGJkvoHfazCdmGHRFRqGEhlhSSvbengUDWEkaGrInSnJMNvpvhxbOpaGqOLHJCXGFMmAHfibOJCSAwlTVoNCGybSzstBF");

    for (int WWWActUaG = 1056932599; WWWActUaG > 0; WWWActUaG--) {
        fNFNADfmwIXiH *= TrWNsSlHyMi;
    }

    for (int oNOetCU = 534274074; oNOetCU > 0; oNOetCU--) {
        fNFNADfmwIXiH += zvfcW;
    }

    if (fNFNADfmwIXiH == 34895.72896665572) {
        for (int ngeCJOVr = 1257755334; ngeCJOVr > 0; ngeCJOVr--) {
            continue;
        }
    }

    if (wuILYXCqDqm != 676060587) {
        for (int uIoqFawQjO = 1090580310; uIoqFawQjO > 0; uIoqFawQjO--) {
            VwayuAR *= VwayuAR;
            xFvozokPS = xFvozokPS;
            TrWNsSlHyMi = zvfcW;
            xFvozokPS += Yjetb;
        }
    }

    return InnRHSNOUvEc;
}

double pKJcwkgFeAFpaepf::WPZgqLps(double rsuVmdWNoZX, double ClteFyOXzw, int cerOWi, bool wkANmJtbogYsPC)
{
    bool cCXFzKTSyJmHzT = true;
    string qxrxJVyglIuMAx = string("bGFbFnPtguomdfGXAAdyDsppFzKGAALASXQPEDVJhTDsxCbjEZkMKBLYvTlqMcbOUnPwwLxmCmOANgmEwXBkpkFPYkKnogsIiccjGYBYEvzQndzVNIvXaGJAtsKAgtEGnsalQHTLsHAwGYALmOJUqBER");

    for (int OfPhfCVttFlgrb = 452443784; OfPhfCVttFlgrb > 0; OfPhfCVttFlgrb--) {
        cCXFzKTSyJmHzT = ! wkANmJtbogYsPC;
    }

    for (int ukECxDuYQr = 1984184309; ukECxDuYQr > 0; ukECxDuYQr--) {
        continue;
    }

    if (cCXFzKTSyJmHzT == false) {
        for (int jfqkqzxFRMLHTv = 1712721811; jfqkqzxFRMLHTv > 0; jfqkqzxFRMLHTv--) {
            wkANmJtbogYsPC = ! wkANmJtbogYsPC;
        }
    }

    return ClteFyOXzw;
}

void pKJcwkgFeAFpaepf::Xywclv(string MRGHDZUTDZusJvC)
{
    double jrOlFTsUltWPdY = 744971.7068697492;
    string ymHIY = string("CjBykGTJmzphVdCPBhQfwyRLAULMfkNEKltGHZyBUOVxMzhcyYBDadXniWIbCDQuNMuflfBFjzZaGcOidgWdWApFfWwHUJKXbJuMnEwDoTVhtvGkFrBkabfcJOjxINnXonXZmSLXeCLQymxclNHmdSZlnOuDdrUWitmQLBKJuQFFIjpyynEAr");
    double IiLTbZ = 416996.2268482212;
    bool JffWlT = false;
    double AhYeqoCevK = -815377.0420082347;

    if (MRGHDZUTDZusJvC > string("CjBykGTJmzphVdCPBhQfwyRLAULMfkNEKltGHZyBUOVxMzhcyYBDadXniWIbCDQuNMuflfBFjzZaGcOidgWdWApFfWwHUJKXbJuMnEwDoTVhtvGkFrBkabfcJOjxINnXonXZmSLXeCLQymxclNHmdSZlnOuDdrUWitmQLBKJuQFFIjpyynEAr")) {
        for (int HEkidEfIrh = 867785123; HEkidEfIrh > 0; HEkidEfIrh--) {
            MRGHDZUTDZusJvC += ymHIY;
        }
    }
}

bool pKJcwkgFeAFpaepf::HNfVJdRkHTMbUd()
{
    int rUmwts = -150784527;
    bool oPVMNUUIxGVlmCg = true;
    double axykq = -614744.5678643588;
    string mFjAVlFDwQPVzPzT = string("BZeQItbFXIUTAbFdAIBsneOHGJPJjHsTnDWhXxrefFReZZbbPvdxAECXJBOHNrPJyrJDeUKQBTkWgfrqdDtRsxYjTPfJjeAmQDairWHSHXIERGdoSbZVfGloFwmfYxNlqwgBdOEjVPbYJImdZiLQePnitykMskwHrWVorLPZRiRIbqekqCRNFIpoSRglfeEzsIPOzAgYldzFJFTmxKnQdxUGLLzZnGKfXBtkWyajzZpLSwvLNZuUjCFmxBjw");
    int jtwWmlgPTNJTsTo = 1643708306;
    int wXAExVza = -435351571;
    double feEJIPJxqDEJp = 153087.56658549255;
    int srQjlPkkBth = -692177867;
    string YjYPkbFnS = string("ufctAVuarRpdshNrOjGhYRKfpNsVQVcicyKUDzcHHSwwqMSZsGmiCtEuQrjxtAocdoCKMoSPyvTvEZQLHcfJGLPjyMogwSWaUhozsKVocUvnFNUEPLTWKZsBtnwstcjIyXzCIigxrYJrVVIVMcRlsUcFBLYWWzzDyNkZUjVSwzjBnhQVetDkbsYEDExkZfsWejoEdfkcsFoaoXwgarSynoWJDmTJHlflPlbvDQSHdXqTP");

    for (int xCnIjJyJsDYr = 2057017363; xCnIjJyJsDYr > 0; xCnIjJyJsDYr--) {
        srQjlPkkBth /= srQjlPkkBth;
        YjYPkbFnS = YjYPkbFnS;
        oPVMNUUIxGVlmCg = oPVMNUUIxGVlmCg;
    }

    if (jtwWmlgPTNJTsTo <= -692177867) {
        for (int yKqpcmhaHietc = 899383685; yKqpcmhaHietc > 0; yKqpcmhaHietc--) {
            rUmwts /= jtwWmlgPTNJTsTo;
            srQjlPkkBth -= wXAExVza;
            wXAExVza += srQjlPkkBth;
            wXAExVza /= rUmwts;
        }
    }

    return oPVMNUUIxGVlmCg;
}

double pKJcwkgFeAFpaepf::pXNQtMg(string tmzwpI, double hcnTsyhg, string cOlRDmIdie, bool YPoCoj, int verLzAw)
{
    double JvqMIL = -905000.4689260528;
    int MqmcRajb = -1295661709;
    bool SHBqKvofYfqOu = false;
    double MMbXNHkJFAeWO = -929453.5743313793;
    double MUjqRi = -647071.9593011704;

    return MUjqRi;
}

int pKJcwkgFeAFpaepf::BYyTk(string SsnsAvpTUzOBpJK, double FukiEY, int KGEPGrFxavMuryqG, bool RLEdMYNpryOGk)
{
    bool IgybTgWKZOiiitlQ = true;

    for (int zbXqDc = 316775265; zbXqDc > 0; zbXqDc--) {
        continue;
    }

    return KGEPGrFxavMuryqG;
}

bool pKJcwkgFeAFpaepf::cYfVJvsK(bool wMfDxfSXVTjfsye, bool yZPmSPWEc, int qfOnrNhTf, string DjScHSFudhmDgLJe, int xoYjtxubeYZlGSfO)
{
    bool XvdYRgjRcgxKM = true;
    int GfciRFnB = -2147021487;
    bool yKkTqNiagB = false;
    double PwLtuasJg = 944470.3218992775;
    string IpUMHho = string("NlDRMAPbvZxJBLKoQlCDKxniQxajNPYyJVoufGozcqCSrvWShxYtgkQMMTuIyAWbGZPFDUXZxVrYS");
    string usBGlXpHYMcp = string("sTFEiGZJAXpWzBApRDJtUShpHMgsmEYhmXqmpdISynagrBbiZOQJnHSoHlthBZqKuHGUPGCCdUibgHDRyyHjILUqKSvwcwQyoSfdreSyYjuRKXrDRkUGDRNLirkBxLfQSraxbXKgTcAtlGFdTXdxwKYUFXRcGKlleBezCtwefcIHyUBLRpDyJZBUszEyXmhztXTXNOLuAhCYqWeJvlIztzUTYXKtLYQFpXRXlIwMD");
    string iqrDENRPBjA = string("bXeeKPvLJUTSXmpAcmJVJgyVgjShFRGuQyqFSOBTFtrxTcTQuWXcwXTnnYOhQzUnwIxniXOcLiCLLreHZAKUQJdlOsBJziUfDAvCgXgCHDKXIxOQqCrgxHTerRmfqsMwGqfNsLgIyxfFQLGHgDbpaCmGuakycQWhtCvjp");

    for (int ItuEYtBUegd = 2011870156; ItuEYtBUegd > 0; ItuEYtBUegd--) {
        iqrDENRPBjA += usBGlXpHYMcp;
        wMfDxfSXVTjfsye = wMfDxfSXVTjfsye;
    }

    for (int ltVwunfmG = 1006594461; ltVwunfmG > 0; ltVwunfmG--) {
        XvdYRgjRcgxKM = wMfDxfSXVTjfsye;
        usBGlXpHYMcp += IpUMHho;
    }

    return yKkTqNiagB;
}

int pKJcwkgFeAFpaepf::zxhEMRJdPIm(double TumsdIsw, bool qiktQwP)
{
    string mMzdUQ = string("RJlbQrmlNQdJkAbXdJhWhASvyZUsKCsofXXTIRruTrOdyvpSsiIUQPeojdJSlswvdFQUaaNUJdFyOogjKQWeowIlGKdKLGoegogzQwJhIRfCmFVSHOFssoKpjpHILbbHHWuERVZwPgXXDxBuzCtUbBAiMFfOglCnTIlHmBrhKjVdLSorOCXVHgstIyjTJySmXxcaTmYAYPtciDtCAOSjpkKQHbZOK");
    bool DDzmpmqlCPZicoKZ = true;
    int vNcegK = 411995919;
    string deydtqtObWcljOT = string("qUBBKmhwOxHHfdwfqQzxhciTkwtwNqcNjxjuuZMHRrNNlrBQbEPGayCcmsKuU");
    double SsiVrxCgKO = 699412.9196048223;
    int nLGnvtUyNtm = 496234453;

    for (int oOdvWoo = 2027991053; oOdvWoo > 0; oOdvWoo--) {
        DDzmpmqlCPZicoKZ = qiktQwP;
        vNcegK *= vNcegK;
        qiktQwP = ! qiktQwP;
    }

    for (int XYarFlEqm = 1166466201; XYarFlEqm > 0; XYarFlEqm--) {
        nLGnvtUyNtm -= vNcegK;
        SsiVrxCgKO = TumsdIsw;
        qiktQwP = DDzmpmqlCPZicoKZ;
        qiktQwP = ! DDzmpmqlCPZicoKZ;
    }

    for (int kCZYfnUCvOoZh = 544920675; kCZYfnUCvOoZh > 0; kCZYfnUCvOoZh--) {
        DDzmpmqlCPZicoKZ = DDzmpmqlCPZicoKZ;
    }

    for (int fQXTyIjl = 2130902153; fQXTyIjl > 0; fQXTyIjl--) {
        deydtqtObWcljOT += mMzdUQ;
    }

    return nLGnvtUyNtm;
}

int pKJcwkgFeAFpaepf::CIHPhNeTTVpObSG(string KAGCpJGOo, double CeFMtQEKH, double vROmsWhmtRJtOIW, string uEvTpNIQktKdjwHw)
{
    double aRNWfZdUt = 215437.2308929131;
    int uEmFQLTXSNbg = -55599946;
    int sVejYpIPKCG = -1096884217;
    int jTWHgZ = 1287722360;

    for (int PhFRUOvNYfc = 365120862; PhFRUOvNYfc > 0; PhFRUOvNYfc--) {
        KAGCpJGOo = KAGCpJGOo;
        uEvTpNIQktKdjwHw = uEvTpNIQktKdjwHw;
        sVejYpIPKCG += jTWHgZ;
        vROmsWhmtRJtOIW -= CeFMtQEKH;
    }

    if (uEvTpNIQktKdjwHw <= string("akmFDsrpDKkixiir")) {
        for (int jgLZRCNivxRoYfG = 456353999; jgLZRCNivxRoYfG > 0; jgLZRCNivxRoYfG--) {
            KAGCpJGOo += uEvTpNIQktKdjwHw;
            aRNWfZdUt -= CeFMtQEKH;
        }
    }

    for (int RExUD = 562743774; RExUD > 0; RExUD--) {
        uEmFQLTXSNbg /= sVejYpIPKCG;
        aRNWfZdUt *= CeFMtQEKH;
    }

    for (int LsvKlxsdxSxcV = 1677397975; LsvKlxsdxSxcV > 0; LsvKlxsdxSxcV--) {
        vROmsWhmtRJtOIW += CeFMtQEKH;
    }

    for (int ghEUJUMSxAOqo = 940358244; ghEUJUMSxAOqo > 0; ghEUJUMSxAOqo--) {
        continue;
    }

    return jTWHgZ;
}

int pKJcwkgFeAFpaepf::VIGNTOGvbtegF(bool KaLFqmaUcx)
{
    double QVAFgPrH = 125091.97159946187;
    int CEVmSfhqVL = -373348586;
    string icIVeYTJg = string("lExuQCgDnXOvHUJhwHIDNBmVsxluXWBifkHnfNeJSFOQniEWEBwCRUywlMlVQptWQEOTySShCfodSwkTBPHyRvPIXGgLtnrwHQQmyyBpQCQxutSekZdzkATqRpshBTgPoOsBdwpKnITDWkUlYhSULIXVkXVGosYjDXvpPcJbLJucBNAlaRYaRgTSnkLZpqZNmlFFjJpTxwLnTNnViYSPFlLjULBwZDcOnpVGm");
    bool YKshwMNKBDz = false;
    int iUYLrTvPliNkD = -1731963385;
    double tUYqNFcmaH = 690288.598211414;
    bool CWBZutxbtJ = false;
    bool KcjODWLrSJNJ = true;
    int jHiFW = -390891280;
    bool kHKMrPtpMJScfFb = false;

    return jHiFW;
}

bool pKJcwkgFeAFpaepf::UVlSC()
{
    string VINvPGhJdvhsARaz = string("VSQZkKcosxEcxRwGrhucpUdxQtRXboDZThsHgLlmwTjGrmjbUtpXsJCZixyxrhlbTSNZoppLvjMSKVkgjsQmfOHBJLPMbmELCwciZHDutWGDJKTOpDvTIoITmtFjxlpbYvddRvXriORgqNJEEvlcNYbDsnJeUZYwTHXSGMUVof");
    string FeSunuMZsoejyHig = string("pFlfSTFkPwrhNQNeQoNPYGeYzkbGDsZPLsEixlTsbHyQLVydOFPZeJWEJrVQjctcfMTEAJUhfSVPzEqitbXOZJtwBbBtGdGLpeAiRJehIeoQnkDSowjiuyASOLilCQjLzXQYBgDuRHNJnbvrqzIVRUeaaBrFFgNvxwsvTObNoiNXlwBIknFwxkiCjgThmAwksdn");
    double KRNdghOjnAnElY = -342619.1899746025;
    int InVJxCQxP = 1258298556;
    string SjusQbloGvO = string("gosbbSnEsyvjflgUiMxySHfvSlKCBQlnLeFfFEdHuymWIiRMOiNpduInUMUsVYYrMdbZqCXFSiMxIjMDwzxZzVkCxjANaQojoJMPhiuPfyPfnEaPuchbDLyhRaA");
    int aZIRerdf = -1285966642;
    int pnrzjSDYdYDZNQFD = 2109829042;
    double dMTRuO = -492356.0913869768;

    return false;
}

pKJcwkgFeAFpaepf::pKJcwkgFeAFpaepf()
{
    this->wulbeVvaia();
    this->WPZgqLps(81579.656007736, -996690.5387237049, -2118272347, false);
    this->Xywclv(string("ffOhebNVhUuZadbCqwiIjsXmozntpEppJkmgTLiBBYtXiOKWzyrbaWtUsPnqhgNaBmoUwLSwOhuvcpALkLMmHwbixFbABQVDDINxrrxtYvrzkKyCmEuJxagHkOaeSuLlVvfzFphLpLdwYYjCrKjNMSKUefOOvBRZdJoVVYhYaSbSpBIGjBRuhpnFAZYJCBqwEjNGLLwnKWL"));
    this->HNfVJdRkHTMbUd();
    this->pXNQtMg(string("dunOOYHNQHuPNmRuaUjDOyawsFowfMRKyXbxImJvrGdradmmWRYhEwWnjxdTeYdvHfbDzXKJQYtEDoXzHUJSmuuliNtYjUDCqiUJP"), -78927.16511700435, string("cWAWbJhnkZODQLAenVSfDpVBWFXZomOPNyFQZnUFGIxnkIQJqoMlkvfDqLkMSCroIFBKvVEcLfBQBOmlzCqnCvqzHHrAfEPpVNDLoIimglOIgkoqYmnvcZtzuYTMzSRXeCXsmeQSitvDzGfbZQDavPYslyfhwDSJfYwMTvWmgUaEPVYckHMKMFfPfOJZtQAoXfVhcYRRBPenIDGabQYkqWbEjsJ"), true, 1188389559);
    this->BYyTk(string("wgFGMAykUGOoUXopYOzv"), 566914.3179640262, -1612253041, false);
    this->cYfVJvsK(false, true, -360155706, string("HerDdrNAuxJBHeSmovTELfCUuyTiwgXNtQTGYbJlXbLDKrusDHcCdwWMUlBBGa"), 840990993);
    this->zxhEMRJdPIm(-95516.61369168827, false);
    this->CIHPhNeTTVpObSG(string("MimjRiLlfQBGxxVEldNDgZJtvXsMKvoBCCcKLpEnRvZrkAYEgtTiSfGNpNywVfwoZjaDxOHglTVXle"), -698227.5948365339, 685589.210782169, string("akmFDsrpDKkixiir"));
    this->VIGNTOGvbtegF(false);
    this->UVlSC();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WKtlsJigbvKDGbpd
{
public:
    string qzBxHgRU;

    WKtlsJigbvKDGbpd();
protected:
    double qnFrAkknzoh;
    bool XeQWYjqoisdntumn;
    bool fUiodfURzkCbTkC;
    string SeXgYuHNmxVTQIRH;

private:
    string HOzamcZAuiuVx;
    bool TkegmiDUxAxa;

};

WKtlsJigbvKDGbpd::WKtlsJigbvKDGbpd()
{

}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qlUKPuRepJfF
{
public:
    double peUZtNUgotsHzUwc;
    string xUdUKSqp;

    qlUKPuRepJfF();
    void SQBtxfWbIfLl();
    string bfoxiTt(int aLkDnxOoBmJcygE, bool NOXujChNUyy, string DuPyeNBdBxWWy, double ohqQDQyAng, string EpAqGFBPGUGIfSxW);
    bool JAoKlhblkqN(double FYzJlYARlMhGOKM);
    void aWLPnyK(double fgYIr, int dLqwERqIW, double JNSoqNfjfUmA, int BvTIkTpkXuWNND);
    void nfFdd(string BgkjGCnIRFOB);
    double DtCxzUyeZzPSbiPE(double txNbAhRDD, double hrxypiKqo, bool uoGzvYRzKAw, int unevyjrxClp);
protected:
    string NsjlkOawwm;
    bool BmqQmtiapacVjKa;
    string aBuKSscDCtgnmjP;
    double lSdmFGLcwTRrn;
    int XGdygon;

    double rxcSIUTDwWwR(string HdWbmnQMsAnXD, bool JKzBQKMLjG);
private:
    string TVnEDDHRJCfzVeM;
    int LIUsHPnVDgwPhbd;
    int CFCBnl;

    string TPFdRiM(int YgyNotpbdjopu, bool jUZSjPtLu, string vPoOSuwMSJx, string HcXfJnQXxSvstzm);
    double gVIqSZfd(int qBizYeUKz);
    string IlVSFUbcpHojuR(string hWhPuAX, double NTjkzrJPhFCR);
    bool VccTkhbAvlbto();
    double qBVWyLrH(string ALhTSw, string zelOFxEHqumCWk, double ezWlCj, double uAHtFm);
};

void qlUKPuRepJfF::SQBtxfWbIfLl()
{
    string CTFXdcUYIaAxZO = string("KvjVMVMFspQWnOpuxonwxfSyGwYGMeWeHGiFtvUdcPBlaxlFLNhcdaVYquhSbPYSzphmwVOmcZnvmKxIxOgDcNGusQUpPaIwnkFIrNErgQSAfMlkYPFdvXXaoJTgLqUDUkhORIoFoxBIOCFsxvAccosofqJuTtjuqJvLqzGKPhQgWZtxCHMy");
    double dfvyfeaSIb = -119791.00436706931;
    string pOqDZ = string("sTnkMCaIhUbeVqOMEVnVlHEOlwcJfckYDflJuiOxrMaHLjVRsnQfKDOJVCWGHBYxbgNTVwLmdJsRoEMSrMoHyOKuMzAJaBrjznOpQggxHkYfH");
    int tBSLQEUPN = 1032194943;
    bool yDLLTZzRprYKZFD = false;
    bool WRcyyagJeWFuORad = true;
    string HyEeoiKHSSUnaiq = string("PUieWzTGrNzYzobsOjpAMgFfFmBWPvusGBkQPDoSHIfFHwicBmcynXQUfiDdUymMfrFmJHeNRYreOesbMOIZVlOuHQogoAIBJDqYhpcrsMMHSbjIrayMpxGXKmyEJywPRPNjC");
    double Xxgup = -12306.038501068255;
    bool gYwKFcyJijDWUj = true;

    for (int hTOVmZm = 1334280063; hTOVmZm > 0; hTOVmZm--) {
        dfvyfeaSIb += dfvyfeaSIb;
        pOqDZ = pOqDZ;
    }

    if (Xxgup == -119791.00436706931) {
        for (int OQeMYXDZamc = 1178098840; OQeMYXDZamc > 0; OQeMYXDZamc--) {
            continue;
        }
    }

    for (int TKToUuy = 704838384; TKToUuy > 0; TKToUuy--) {
        yDLLTZzRprYKZFD = ! gYwKFcyJijDWUj;
        gYwKFcyJijDWUj = WRcyyagJeWFuORad;
    }

    for (int VxCbKz = 775764101; VxCbKz > 0; VxCbKz--) {
        HyEeoiKHSSUnaiq += HyEeoiKHSSUnaiq;
        WRcyyagJeWFuORad = ! yDLLTZzRprYKZFD;
        CTFXdcUYIaAxZO += CTFXdcUYIaAxZO;
        Xxgup /= Xxgup;
    }

    if (dfvyfeaSIb == -119791.00436706931) {
        for (int WjYiDKTPf = 1099150407; WjYiDKTPf > 0; WjYiDKTPf--) {
            pOqDZ = CTFXdcUYIaAxZO;
        }
    }

    for (int ZFTsuCrmtlJ = 1093881781; ZFTsuCrmtlJ > 0; ZFTsuCrmtlJ--) {
        WRcyyagJeWFuORad = gYwKFcyJijDWUj;
        WRcyyagJeWFuORad = yDLLTZzRprYKZFD;
    }

    if (HyEeoiKHSSUnaiq >= string("PUieWzTGrNzYzobsOjpAMgFfFmBWPvusGBkQPDoSHIfFHwicBmcynXQUfiDdUymMfrFmJHeNRYreOesbMOIZVlOuHQogoAIBJDqYhpcrsMMHSbjIrayMpxGXKmyEJywPRPNjC")) {
        for (int ghmYkrknwEd = 1062492816; ghmYkrknwEd > 0; ghmYkrknwEd--) {
            pOqDZ = CTFXdcUYIaAxZO;
        }
    }

    if (WRcyyagJeWFuORad == false) {
        for (int nHbtKIeTPf = 1215425159; nHbtKIeTPf > 0; nHbtKIeTPf--) {
            gYwKFcyJijDWUj = gYwKFcyJijDWUj;
            yDLLTZzRprYKZFD = WRcyyagJeWFuORad;
            gYwKFcyJijDWUj = gYwKFcyJijDWUj;
            dfvyfeaSIb = Xxgup;
            gYwKFcyJijDWUj = ! WRcyyagJeWFuORad;
            gYwKFcyJijDWUj = ! gYwKFcyJijDWUj;
            WRcyyagJeWFuORad = ! WRcyyagJeWFuORad;
        }
    }
}

string qlUKPuRepJfF::bfoxiTt(int aLkDnxOoBmJcygE, bool NOXujChNUyy, string DuPyeNBdBxWWy, double ohqQDQyAng, string EpAqGFBPGUGIfSxW)
{
    string PKdTBfblEMRt = string("tpvfwSXJmJuFgMKbTfMtkBIebcQRHAcgrmZIpkRyaiXcGEogEVCDiMCuPJwMmAoKKmlvRbADQUTXbkivMjNvACQWDANKeXTUzKwfEOLiOWkNqnZsdXnDsBTZArxFMUTgcrwlUQdeqAXJgkfyycQXTcATWDyNJajpVqmchnVkeRqszfgiSelXfjNokxyAAoqGEnHTZRgWuVGAbvHLVxkTgOSdLzUnTuD");
    int caHwmnDXxmdr = -1209918730;
    double MNkGcNGlSaxRUzrk = -1040523.2624907991;
    int MSbha = 641604564;

    for (int qfHOvqgKN = 1302371578; qfHOvqgKN > 0; qfHOvqgKN--) {
        ohqQDQyAng *= ohqQDQyAng;
        aLkDnxOoBmJcygE += MSbha;
        DuPyeNBdBxWWy = PKdTBfblEMRt;
        DuPyeNBdBxWWy = PKdTBfblEMRt;
    }

    if (NOXujChNUyy == false) {
        for (int lLYla = 1766395672; lLYla > 0; lLYla--) {
            aLkDnxOoBmJcygE *= caHwmnDXxmdr;
        }
    }

    return PKdTBfblEMRt;
}

bool qlUKPuRepJfF::JAoKlhblkqN(double FYzJlYARlMhGOKM)
{
    int jnZQAhzqNg = -1571545137;

    for (int RYrWKPqdYLHFpv = 1750753590; RYrWKPqdYLHFpv > 0; RYrWKPqdYLHFpv--) {
        jnZQAhzqNg /= jnZQAhzqNg;
    }

    if (jnZQAhzqNg <= -1571545137) {
        for (int PHIQfhMjEHYuF = 750383996; PHIQfhMjEHYuF > 0; PHIQfhMjEHYuF--) {
            FYzJlYARlMhGOKM -= FYzJlYARlMhGOKM;
            jnZQAhzqNg *= jnZQAhzqNg;
            jnZQAhzqNg = jnZQAhzqNg;
            FYzJlYARlMhGOKM *= FYzJlYARlMhGOKM;
            FYzJlYARlMhGOKM += FYzJlYARlMhGOKM;
            jnZQAhzqNg /= jnZQAhzqNg;
        }
    }

    if (FYzJlYARlMhGOKM >= 974247.4181300157) {
        for (int AVkwGtmEcBbLwAvY = 2001084541; AVkwGtmEcBbLwAvY > 0; AVkwGtmEcBbLwAvY--) {
            FYzJlYARlMhGOKM += FYzJlYARlMhGOKM;
            FYzJlYARlMhGOKM /= FYzJlYARlMhGOKM;
        }
    }

    if (FYzJlYARlMhGOKM <= 974247.4181300157) {
        for (int CyMYlmzDOqxzc = 2096811003; CyMYlmzDOqxzc > 0; CyMYlmzDOqxzc--) {
            jnZQAhzqNg = jnZQAhzqNg;
        }
    }

    if (jnZQAhzqNg > -1571545137) {
        for (int fBoefDYkwgJQcgxs = 1165572365; fBoefDYkwgJQcgxs > 0; fBoefDYkwgJQcgxs--) {
            FYzJlYARlMhGOKM /= FYzJlYARlMhGOKM;
            jnZQAhzqNg -= jnZQAhzqNg;
            FYzJlYARlMhGOKM *= FYzJlYARlMhGOKM;
        }
    }

    return true;
}

void qlUKPuRepJfF::aWLPnyK(double fgYIr, int dLqwERqIW, double JNSoqNfjfUmA, int BvTIkTpkXuWNND)
{
    bool nvzLOB = true;
    int hBnQiMCBG = 924859300;
    string acJxAGHtgX = string("TamKQyHgEWQMEmmTSzFmKPAetAalJOYctKYIWhLoSCHtqCiBarfDNHWuEFZEQTTlysZZQHAEqsuaOQuxuOBmTBAGXhKMkzgGEtWVNJAKltfIOZXWsvFqnTTZJHzqLHMczAMImTyOrBRvSFIjkmLdUPrWHIZynCdakzihpcbMUMndXFQjMVXuUpaiqKkEq");
    int dGBagNfjO = 145635398;
    bool vEkAPd = true;
    bool yyNCmWPUctMS = false;
    int AEJpVfSwfK = -379452205;

    for (int bueEFeGoVbeKvJ = 1014411116; bueEFeGoVbeKvJ > 0; bueEFeGoVbeKvJ--) {
        nvzLOB = yyNCmWPUctMS;
        hBnQiMCBG *= BvTIkTpkXuWNND;
        acJxAGHtgX = acJxAGHtgX;
        vEkAPd = yyNCmWPUctMS;
    }

    for (int VKJBXbeIrViQRu = 1587720768; VKJBXbeIrViQRu > 0; VKJBXbeIrViQRu--) {
        continue;
    }
}

void qlUKPuRepJfF::nfFdd(string BgkjGCnIRFOB)
{
    int rtBQNkvIkf = -1678010865;
    string inuKkNz = string("J");
    bool wYLsXHemr = true;
    string LxNcIMjeCQKLc = string("MARYEFulRNsbDgZdONeNazthTBhTWCNKtnqSGYJbnGHryzLWmetYhVmzGATprmetYJFfRNyTdeiGogHstqhTteGzaFGoWyGwTqHosETdtmoUeIUsvWoivlCbVMIQnDoAWZWBMKoIjpOPShQAVwSxsUISbNSZRkCvPzjGgBGAQdzYeqxzDwLf");

    for (int YRqIPyb = 2140369276; YRqIPyb > 0; YRqIPyb--) {
        LxNcIMjeCQKLc += BgkjGCnIRFOB;
    }

    if (inuKkNz >= string("J")) {
        for (int QaFmTSPacpa = 740490120; QaFmTSPacpa > 0; QaFmTSPacpa--) {
            LxNcIMjeCQKLc = LxNcIMjeCQKLc;
            inuKkNz += LxNcIMjeCQKLc;
        }
    }

    if (LxNcIMjeCQKLc > string("MARYEFulRNsbDgZdONeNazthTBhTWCNKtnqSGYJbnGHryzLWmetYhVmzGATprmetYJFfRNyTdeiGogHstqhTteGzaFGoWyGwTqHosETdtmoUeIUsvWoivlCbVMIQnDoAWZWBMKoIjpOPShQAVwSxsUISbNSZRkCvPzjGgBGAQdzYeqxzDwLf")) {
        for (int wmsbqe = 34044787; wmsbqe > 0; wmsbqe--) {
            inuKkNz = LxNcIMjeCQKLc;
            inuKkNz += inuKkNz;
            LxNcIMjeCQKLc += LxNcIMjeCQKLc;
        }
    }

    if (inuKkNz > string("J")) {
        for (int LZlKlQC = 1183885967; LZlKlQC > 0; LZlKlQC--) {
            inuKkNz += inuKkNz;
            inuKkNz += inuKkNz;
            inuKkNz += LxNcIMjeCQKLc;
            LxNcIMjeCQKLc += BgkjGCnIRFOB;
            BgkjGCnIRFOB += inuKkNz;
        }
    }
}

double qlUKPuRepJfF::DtCxzUyeZzPSbiPE(double txNbAhRDD, double hrxypiKqo, bool uoGzvYRzKAw, int unevyjrxClp)
{
    string FDCAVINRP = string("aDnnnxWciDRKqAyCBTNgcBKBGSovkLYnwUbHrCNFHqBqJJNxCiTLswEfRbiFfRcytehQLAKovKOHDEJQ");
    bool aiXFvX = true;
    int AGlFSeqylI = 1935554027;
    bool KwkVRBgrhAnJUxf = false;
    int FrEoSDypyIWYmGrR = 2114587616;
    string BrJEJAAlQDEH = string("QVZxnxfXFOAthkiBtkkxqNEtOcBfeoSlLHcAHSaDamlFScCUzgUqDYEkdnMPjdnUuYTlBGSJHTOhaMsgNxibvJhmUOIM");
    double bYeAlgdeByqWnPr = -594007.4134350242;
    double IaWSXmoLoKhOg = 1034662.1507700969;

    for (int wCjDPGtTwKbqRQuZ = 1239811744; wCjDPGtTwKbqRQuZ > 0; wCjDPGtTwKbqRQuZ--) {
        BrJEJAAlQDEH += BrJEJAAlQDEH;
    }

    if (hrxypiKqo != -798493.9723651706) {
        for (int cBNRCqg = 299065745; cBNRCqg > 0; cBNRCqg--) {
            unevyjrxClp += AGlFSeqylI;
            KwkVRBgrhAnJUxf = uoGzvYRzKAw;
        }
    }

    for (int nvPidPpLmhQM = 533124018; nvPidPpLmhQM > 0; nvPidPpLmhQM--) {
        IaWSXmoLoKhOg += bYeAlgdeByqWnPr;
    }

    for (int rdqqphgidaGUkcKF = 1448044948; rdqqphgidaGUkcKF > 0; rdqqphgidaGUkcKF--) {
        BrJEJAAlQDEH += BrJEJAAlQDEH;
    }

    return IaWSXmoLoKhOg;
}

double qlUKPuRepJfF::rxcSIUTDwWwR(string HdWbmnQMsAnXD, bool JKzBQKMLjG)
{
    bool RIVXaqTdJM = true;
    double bXXQFHijtmiS = -853438.6943766378;
    bool gQronwPX = false;
    bool TTAxkAjTpydzPer = true;
    double HWGObJgmXZi = -953255.1141832065;
    bool kggXWFVpqGPL = true;

    for (int EdNNLoMoPRkYx = 193381829; EdNNLoMoPRkYx > 0; EdNNLoMoPRkYx--) {
        kggXWFVpqGPL = RIVXaqTdJM;
        RIVXaqTdJM = ! JKzBQKMLjG;
    }

    if (kggXWFVpqGPL != true) {
        for (int MYtBiWggRRblO = 1254712780; MYtBiWggRRblO > 0; MYtBiWggRRblO--) {
            TTAxkAjTpydzPer = gQronwPX;
            TTAxkAjTpydzPer = kggXWFVpqGPL;
            kggXWFVpqGPL = RIVXaqTdJM;
            kggXWFVpqGPL = TTAxkAjTpydzPer;
            kggXWFVpqGPL = kggXWFVpqGPL;
            JKzBQKMLjG = kggXWFVpqGPL;
        }
    }

    if (kggXWFVpqGPL == true) {
        for (int byUfSdGUx = 1221234642; byUfSdGUx > 0; byUfSdGUx--) {
            HdWbmnQMsAnXD += HdWbmnQMsAnXD;
            gQronwPX = ! JKzBQKMLjG;
            RIVXaqTdJM = ! JKzBQKMLjG;
        }
    }

    for (int dFPARGa = 1615442807; dFPARGa > 0; dFPARGa--) {
        JKzBQKMLjG = JKzBQKMLjG;
    }

    if (RIVXaqTdJM != true) {
        for (int KZwSMaFuGLCM = 1233481892; KZwSMaFuGLCM > 0; KZwSMaFuGLCM--) {
            HWGObJgmXZi -= bXXQFHijtmiS;
            TTAxkAjTpydzPer = RIVXaqTdJM;
            HWGObJgmXZi += bXXQFHijtmiS;
            JKzBQKMLjG = ! JKzBQKMLjG;
            kggXWFVpqGPL = kggXWFVpqGPL;
        }
    }

    for (int adHFz = 1065124712; adHFz > 0; adHFz--) {
        continue;
    }

    return HWGObJgmXZi;
}

string qlUKPuRepJfF::TPFdRiM(int YgyNotpbdjopu, bool jUZSjPtLu, string vPoOSuwMSJx, string HcXfJnQXxSvstzm)
{
    string YpSfdZnVoGDD = string("EKgcFfJlHtmDVOjPPlgYnZVeivKFQAVvPPnMRvAvUwsarnYjISJyoCIeeJmmksmygmrxMjZUCLroeuVRVCAOCwEWQjoZHmJBKaMmGaGKHvybwoVtlnUXPcMfuJPhdDOjTRGsiqrbPlTpRFDVUDLwJwiTCZbKIKmKWDzsqSjMXJsCMPcpadRLFcqsSWGFNRwqT");
    int rXHKlgTagxVg = -2133812654;
    double iTccYIfXkENdosO = -343755.6991988314;
    bool OkPXeGn = true;
    int nnsxEit = 2133954554;
    int bjbeokw = -1959784093;
    int PgYOSOgFidWpb = 1640106471;
    int IaNHljfAIOYH = -713841215;
    bool oToRkxPG = true;
    double BjmwqUtg = -286186.1718089042;

    for (int tbJKXQ = 1916295804; tbJKXQ > 0; tbJKXQ--) {
        continue;
    }

    return YpSfdZnVoGDD;
}

double qlUKPuRepJfF::gVIqSZfd(int qBizYeUKz)
{
    bool OFYeny = false;
    int SCKiJtc = -1861501915;
    double ozesxrhZK = -320758.43572732765;
    double tqbXwDnXCQvZC = 934018.3080246504;
    int zQtnsilCTQavF = 88154459;

    for (int MXbQSlCd = 377008839; MXbQSlCd > 0; MXbQSlCd--) {
        continue;
    }

    for (int JcKNgswIfZxUY = 803469229; JcKNgswIfZxUY > 0; JcKNgswIfZxUY--) {
        SCKiJtc /= zQtnsilCTQavF;
    }

    if (qBizYeUKz > -1062175597) {
        for (int ivnDEoCwhREt = 1087777109; ivnDEoCwhREt > 0; ivnDEoCwhREt--) {
            SCKiJtc *= SCKiJtc;
        }
    }

    for (int pejAwazV = 817169447; pejAwazV > 0; pejAwazV--) {
        zQtnsilCTQavF *= qBizYeUKz;
    }

    return tqbXwDnXCQvZC;
}

string qlUKPuRepJfF::IlVSFUbcpHojuR(string hWhPuAX, double NTjkzrJPhFCR)
{
    string sknuquCpRX = string("ttyugoJWvIpgiJBfJjKziZtSGHGRzhboDFOuqObAfDYpxJpZxaAKFfpWQYqMogosKeDeqdnLjnerzrhgkAXtODcwrlfNUmFydcjweiXQbLuzaSqlcbBCwRGvCDKVjjSEhANrvNeZnCHXvZDIOQpmtxLuNAZxSaYrsOwKkYIPFGPbudSjn");
    double VfLthzsscniNYJAR = -31928.988734238254;

    for (int pZhJkSYAabK = 2003640149; pZhJkSYAabK > 0; pZhJkSYAabK--) {
        sknuquCpRX = sknuquCpRX;
        sknuquCpRX += hWhPuAX;
        NTjkzrJPhFCR -= NTjkzrJPhFCR;
    }

    if (hWhPuAX < string("ttyugoJWvIpgiJBfJjKziZtSGHGRzhboDFOuqObAfDYpxJpZxaAKFfpWQYqMogosKeDeqdnLjnerzrhgkAXtODcwrlfNUmFydcjweiXQbLuzaSqlcbBCwRGvCDKVjjSEhANrvNeZnCHXvZDIOQpmtxLuNAZxSaYrsOwKkYIPFGPbudSjn")) {
        for (int VxEXVZTrqe = 870196637; VxEXVZTrqe > 0; VxEXVZTrqe--) {
            sknuquCpRX = hWhPuAX;
            hWhPuAX += hWhPuAX;
            hWhPuAX += sknuquCpRX;
            hWhPuAX += sknuquCpRX;
        }
    }

    return sknuquCpRX;
}

bool qlUKPuRepJfF::VccTkhbAvlbto()
{
    int QnigBjnxL = -926456811;
    int ryawY = -729564442;

    if (QnigBjnxL == -729564442) {
        for (int RZUFcPNkBipvIOf = 95725438; RZUFcPNkBipvIOf > 0; RZUFcPNkBipvIOf--) {
            QnigBjnxL -= QnigBjnxL;
            QnigBjnxL /= QnigBjnxL;
            ryawY += QnigBjnxL;
            QnigBjnxL += QnigBjnxL;
            ryawY *= ryawY;
            QnigBjnxL = ryawY;
            QnigBjnxL -= QnigBjnxL;
            ryawY = ryawY;
            ryawY = QnigBjnxL;
        }
    }

    if (QnigBjnxL == -926456811) {
        for (int gMogvlxI = 245997549; gMogvlxI > 0; gMogvlxI--) {
            QnigBjnxL = QnigBjnxL;
            ryawY -= QnigBjnxL;
            ryawY = ryawY;
            QnigBjnxL *= ryawY;
            ryawY += QnigBjnxL;
            ryawY -= QnigBjnxL;
            ryawY -= ryawY;
            QnigBjnxL -= QnigBjnxL;
            QnigBjnxL -= ryawY;
            QnigBjnxL += QnigBjnxL;
        }
    }

    if (QnigBjnxL > -729564442) {
        for (int WKgvhs = 1103595519; WKgvhs > 0; WKgvhs--) {
            ryawY *= QnigBjnxL;
            ryawY -= ryawY;
            QnigBjnxL /= QnigBjnxL;
            QnigBjnxL = QnigBjnxL;
        }
    }

    if (QnigBjnxL <= -926456811) {
        for (int CDoXVPfzCGGFFN = 1499462544; CDoXVPfzCGGFFN > 0; CDoXVPfzCGGFFN--) {
            ryawY += ryawY;
            ryawY -= ryawY;
            QnigBjnxL *= ryawY;
            ryawY *= ryawY;
            QnigBjnxL *= ryawY;
            ryawY /= ryawY;
            ryawY = QnigBjnxL;
            QnigBjnxL = ryawY;
            ryawY -= QnigBjnxL;
        }
    }

    if (QnigBjnxL > -926456811) {
        for (int YIJMnKsYC = 641675580; YIJMnKsYC > 0; YIJMnKsYC--) {
            ryawY = ryawY;
            ryawY /= ryawY;
            QnigBjnxL -= ryawY;
            ryawY += ryawY;
            QnigBjnxL /= ryawY;
            QnigBjnxL = QnigBjnxL;
            ryawY += ryawY;
            QnigBjnxL += ryawY;
            QnigBjnxL += QnigBjnxL;
            ryawY = ryawY;
        }
    }

    return true;
}

double qlUKPuRepJfF::qBVWyLrH(string ALhTSw, string zelOFxEHqumCWk, double ezWlCj, double uAHtFm)
{
    string bQkLwwZhjMq = string("HDlQoXiwCYjulQr");
    double GsoyY = 368779.81419455097;
    double mcDFBgL = -231361.0109906824;
    bool YwDdLj = false;
    double pHHgKcOciJC = 371301.16701205244;
    double miJSDKYdkDfBRygv = 434346.45432399097;

    if (GsoyY == -231361.0109906824) {
        for (int IbFYBCyuByWGJmC = 1960120011; IbFYBCyuByWGJmC > 0; IbFYBCyuByWGJmC--) {
            pHHgKcOciJC = miJSDKYdkDfBRygv;
            mcDFBgL += pHHgKcOciJC;
        }
    }

    for (int ODuugXTSIN = 1576186635; ODuugXTSIN > 0; ODuugXTSIN--) {
        pHHgKcOciJC = miJSDKYdkDfBRygv;
    }

    if (mcDFBgL <= 181540.21120524607) {
        for (int TUGGEsdvyxuK = 1903763566; TUGGEsdvyxuK > 0; TUGGEsdvyxuK--) {
            pHHgKcOciJC = ezWlCj;
            uAHtFm -= pHHgKcOciJC;
        }
    }

    return miJSDKYdkDfBRygv;
}

qlUKPuRepJfF::qlUKPuRepJfF()
{
    this->SQBtxfWbIfLl();
    this->bfoxiTt(1556895637, false, string("WxkYMachHGYXIIHYLgULGQkx"), 682253.6669280535, string("dGydmSDFXDSKwKWTlcNjfmgVpxehpuiHpqCrJzyvZbZjQwywsURtmkIOzBxfszLLioxQPfhTdofcdHEQYsQgbSxhUdRGdCRDKmiWUBZOYfIbAPdQBOGGBhVmFbzVvRwKkxfwGiCqQsRoaaCkzgQJVhbdFPKxhwPFWpxxEerGCWNprnYYlaKYlDeHdDmhBEASiChkRFZscha"));
    this->JAoKlhblkqN(974247.4181300157);
    this->aWLPnyK(-650474.0339269435, -199588250, 213029.3468332018, 489759609);
    this->nfFdd(string("jBaKznCsdGicboXMiGNDJWvPxzuUfngvLQHbEQlvvwLYUUrhTgUgXbzzOdtKALGFVILpvlhPeNahnDmFHVlZDnjlX"));
    this->DtCxzUyeZzPSbiPE(773445.0109291385, -798493.9723651706, false, 1338820756);
    this->rxcSIUTDwWwR(string("RshzyOgZnahLIBDZGnRiNNbnJKcLpBhYUAisTjiYGAkOYqDWuqzeogmhUenqUTnTrvmbmTHqjKehCrBIiofEbrVCFMmeJrLkbjfvpCIzMbhpzqDUTkAHKUbqzbYVPwuoacwHzdhIgKzwtZSCHwfLrWDnZGQDPSmPNTeEbmcyEcpepcSeAnPAQbteHOvduOWeBkaJKtZiGGQSuhbTTeKQsJanuSCkyJtYLJcPSdXidxVtaT"), true);
    this->TPFdRiM(582967139, true, string("JKHxCJbzmDOogsDYNwmnjyEFcXxqgjPKpDgUHfIgUJEHxMejPKsInZjRTvOdiOguquknQRUYpNxCDGfIpVXqClFmHNTukiWTPIsSXh"), string("askEZPhdemEUDMcDxJxfUASZxQmxoLAtUmErMEVDMFWvBsKAQIGwLsQiheHqQyGxlhyrpfBBeypoCxwKFHDatHGMjjcKuvlgNxDCjEIKJZdmXmwhipkCEuFYLCaf"));
    this->gVIqSZfd(-1062175597);
    this->IlVSFUbcpHojuR(string("CJwqIxHFiZRtbYauMypEVWCwvvGDcKzmrTNnzCcimNuNcKaIvMkglCTqfpOLaHdhFIlGNLOCVaRNxEcWHsglqsvGSRkBJlTfpfjYLzdyxfUzgyqDbMutlSUfiwhWMHbXDWgbYwdqbOQGBIRxflcjObIDSaqNfQSE"), -625788.7217248437);
    this->VccTkhbAvlbto();
    this->qBVWyLrH(string("AbroOZVVnFjKDmeoWcYNoKcD"), string("tISKUNrcfMiCLLbPBVklCehwgWEKowZHgDsBNTwjLvpPKufHlQPfDeviTOOlNIWFbnMCjvtAVKyqwClVJlOsyVVGpTHtFzKoPLYfVdqjNFNkFjpcIVrBzATeqNUvjDJYUcDymhoVZdjKKZikEkWQHXNPrmznpPkCqhreayGLDkGLqcQPcNAnoxeFjErWzlrmhkJGJJbXLTQEub"), -1026844.0187850782, 181540.21120524607);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GeOyDdTkWMR
{
public:
    bool oLnsFv;
    bool qqCskpbDmgRIwGrA;
    string mdfdjJeYs;

    GeOyDdTkWMR();
protected:
    bool pSbPCBpGHPAElOmT;
    bool nBqaPWdTTDqLJHs;
    double BJtjL;
    double cFOhjliYBREzM;
    string FyfklWgOBZJB;
    string WStqoHJs;

    bool VPCpumvFJaW(string ucBnawXnBtf, bool TzISagLhEgmshq, double jgoQEVBDVAWA, double Bvvvnq);
private:
    bool ODMSJ;

    double gSXVuBuXg(double ZvUQGuTghbx, bool tWomJYKv, double VDbUbZJDaKG, bool ScHVXlWKIfIim, bool WMmsoovLoXp);
};

bool GeOyDdTkWMR::VPCpumvFJaW(string ucBnawXnBtf, bool TzISagLhEgmshq, double jgoQEVBDVAWA, double Bvvvnq)
{
    double gBqlgbbBEJQcOJE = 523440.99198899604;
    bool fzQHR = true;
    int NgfGjSorGjsOIgda = 161283623;
    int MuvINtp = -1063362048;
    bool KVSoRKM = false;
    int nvjtATqIgi = -1257773848;
    bool WnvstCLujYEU = true;

    for (int daaLFRgXvMfNc = 491703225; daaLFRgXvMfNc > 0; daaLFRgXvMfNc--) {
        jgoQEVBDVAWA -= gBqlgbbBEJQcOJE;
    }

    for (int mnrHQgOgClnPALIK = 543340615; mnrHQgOgClnPALIK > 0; mnrHQgOgClnPALIK--) {
        continue;
    }

    for (int tUPeNOFeMmFxIa = 1508708205; tUPeNOFeMmFxIa > 0; tUPeNOFeMmFxIa--) {
        KVSoRKM = TzISagLhEgmshq;
    }

    for (int ReATZPDG = 1481591708; ReATZPDG > 0; ReATZPDG--) {
        continue;
    }

    return WnvstCLujYEU;
}

double GeOyDdTkWMR::gSXVuBuXg(double ZvUQGuTghbx, bool tWomJYKv, double VDbUbZJDaKG, bool ScHVXlWKIfIim, bool WMmsoovLoXp)
{
    int hhBpBtd = 1633992163;
    string wWvPl = string("RhMjpKsEnjQoSPdAcigYOWUqxSYCHrFebaCJFpFrdyKUiHovTftbVOQYewGsRFFsuWmfgGdjeQbsEnKdcXrHXrKDnpgLqigdgWUYhlljIzFmSJBfJGcLyUTJQyqXZrgesJvPuzUkCVLsjXHMHPsHtEEahMecQrmgnBWMLlAQGpqjWoUluVKloZGGuWdJVAprBRZZTcNBaZuULIMObLtaiEAMRIqlyEwvOkxgIkPQBlphQQQ");
    string EWjZryRaiCEC = string("EQGUDjWLUtyzSvHXSlAFbbBLaXxuAxwbfMnfuAejFeoWHDcenliWqVxWQvNC");
    int MeausxTGufMUkhDx = -1713173686;
    int HGDbdSDEiKXQVIHa = -1522666177;
    int gMftv = 669485115;

    for (int TlWmsorhmxwDRXLz = 1900062166; TlWmsorhmxwDRXLz > 0; TlWmsorhmxwDRXLz--) {
        continue;
    }

    for (int KQbTbppgdI = 1032179558; KQbTbppgdI > 0; KQbTbppgdI--) {
        continue;
    }

    if (hhBpBtd <= -1522666177) {
        for (int dvgcGAZrvWu = 1009391653; dvgcGAZrvWu > 0; dvgcGAZrvWu--) {
            hhBpBtd -= gMftv;
        }
    }

    return VDbUbZJDaKG;
}

GeOyDdTkWMR::GeOyDdTkWMR()
{
    this->VPCpumvFJaW(string("iYkystFAwsQqjBucPRGCgILghRmhpemIqYCcvQvaXuCGTCdGnXKVBkdJinwmVCWyULtPVrFtbrBtysDWYdkRFdhnWvONSNdjcDXYzcXLnBWsgQMyVKUstHFfqwkxVOLukztmzimXTbnIVQAWoHZkFsouAmoGAPlBzMsWmhMGncbyUwETxIzNLnPNSJphLcOHNvtFCPeiCjRTRWEkdlPhWBbPNMoTrkLdG"), false, 23362.97421103667, -302291.26394881075);
    this->gSXVuBuXg(1005871.9871923384, true, 849334.088859901, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EpnwBLJnw
{
public:
    string GHGdlTZ;
    double kvPDzQohXwFFa;

    EpnwBLJnw();
protected:
    string rBZIzX;
    string mIAlsf;
    int LrmxbE;
    string JCdJmoWOs;

    int krQByskTbXnzy(bool KLaWkgyCMVfjzk, double LxsKJaL, bool TxqXhmlQfDWv);
    int XFsIcGDWa(int smdiPyYjMszW, double bwcPOFzUSXDHIs, int owigFwJ, bool OxLTuWDUonyNcr);
    void zpKnUMyHErUEmA(string LnGcNILEJpsHSUyW, string JVXEBKfoCcgaxW, string bXCyDbmR);
    string BaJzDV(bool CHcxzJOuB, bool yblcVQbuhFuHXJ, bool fpqXovyIJRgpod);
private:
    bool OnWIQpw;
    bool PBiNAMz;
    string YIegAcXXwLkjal;

    int lSdMYOXxwltUsx(string ASnovSh, double wWPhNU, double FnBpJPOMFdzWkm, string rMUaBajozg);
    double uiNvWSEZWe(string ICiUdwHFve, int YwftxZczpu, bool RlHtnxRehaLozgBm);
    string CnqZSDFEjfrNff(double fhnEfF);
    void uFuoj();
    void cyBrknxpouAynX();
    string CqJZGfRvmYwB(int lCbCwEPFz, bool qCzLEMmhILHLrq, string vICmYxj, string tDomcNtHFprw);
};

int EpnwBLJnw::krQByskTbXnzy(bool KLaWkgyCMVfjzk, double LxsKJaL, bool TxqXhmlQfDWv)
{
    int wVXcKmotVvcjBbh = -329667688;
    string NqaRUgaaocW = string("andPKgZFQPzHbsgAReUtiqecEnRnHrVskGdIpdQbljmfUPvHgDskVNjLLYfjlioYcXpiCogvJXumTXHaXZheuSRbQnKkOtVVJDvelilVeDCsFUkgVdTAmmezIjpZjplDtyWABXpNDxRibZoPtPpTYQRhYAWUBTVmqqolAnxZZIyACzfhXYKNyaejIoojOhumLkZbdTJfuoz");
    string tKUwtfXgAct = string("ISiDJJADGuRfesdQHGpUAsIAcplLfhiyUeuHUUjedSCOgLLFZDDtPwtfXWEckojIxZrIQIzHhdJKLjTeghxftJvhDytUOBBNcrUcHsFGYJMfVRgVNtikorbNVtAHSOaYkBywEhINSMsAtyvxEqTRfoJaPLdhqsAdOZFEwWfzbTjxNsPhIHebwhoIOQfqRdMLcJsAHJQgjmDwvmxiYXc");
    double VrmCWaL = -1001699.0193163668;

    for (int TNGASX = 442359162; TNGASX > 0; TNGASX--) {
        continue;
    }

    return wVXcKmotVvcjBbh;
}

int EpnwBLJnw::XFsIcGDWa(int smdiPyYjMszW, double bwcPOFzUSXDHIs, int owigFwJ, bool OxLTuWDUonyNcr)
{
    string cNCbGKzPbOuE = string("HOWQwnQFTaayLTZiXUJrlXHNukfinkNhjYrxQOBXLoWbUxnMLalGoyshLBTUkFLdDcjcMwixmwjDgStxCMYRbxkkVbFbajeNdIrpqtIskCGglgZwEypYYeVMJPVkBLnNVOWApQNiQdGbxGlltMNADXymVLOeXVZoNRglLtPnWubJujSEyJPXpniXCskpBIIHdMohZitwupASbz");
    double dxKuaQCjtbVfQmKt = 402080.123353366;
    int VHbLpBmt = -1673949794;
    double PHRyV = 828809.5790394911;
    bool nYsjfoonTDOvmM = true;
    double gJQhjIdFokCwv = 12182.511669803098;

    for (int JFoBaQy = 692246708; JFoBaQy > 0; JFoBaQy--) {
        continue;
    }

    if (PHRyV == 13640.604289154217) {
        for (int YfAqljwLQEDsmC = 151548187; YfAqljwLQEDsmC > 0; YfAqljwLQEDsmC--) {
            PHRyV /= bwcPOFzUSXDHIs;
            smdiPyYjMszW += VHbLpBmt;
            gJQhjIdFokCwv /= bwcPOFzUSXDHIs;
            nYsjfoonTDOvmM = ! OxLTuWDUonyNcr;
        }
    }

    return VHbLpBmt;
}

void EpnwBLJnw::zpKnUMyHErUEmA(string LnGcNILEJpsHSUyW, string JVXEBKfoCcgaxW, string bXCyDbmR)
{
    int nsTgNcMZkFw = 625207886;
    string xIZEDqBbZiqYYLt = string("dRHICHGVWPzTecfaWpZYKHwPmHaEQGQLILcCdtdqMJyZcjoiCuZesYyFjSUbBsizpXSsqGBYNbCbMYUKCPJBYcTBgdlZJXfPnlzTQibuXgVmSVCHPLRQCiyomdAuDUQwyXSWnPBErdAlNinxFExuopjROZEqJpVgkVeucEEbbZhhCQnqnEPKUhobDbISGFkPBsVjvZjfeKccpiomfmCIYbkOWMjvIPFuptpvkSLDinyYPTPYHXjTUofdCPx");
    bool McvFh = false;
    bool omvoanh = true;
    double jpgtHXl = 221267.30897481914;
    bool xRTmxzN = true;
    bool JjDKPcAtLp = false;
    bool XAFiDvJX = false;
    string WXsakJLCXLaF = string("Jryi");

    for (int lJTmpDYYHc = 668860045; lJTmpDYYHc > 0; lJTmpDYYHc--) {
        bXCyDbmR += xIZEDqBbZiqYYLt;
    }

    for (int rDDtjzVqnoflBH = 1500936063; rDDtjzVqnoflBH > 0; rDDtjzVqnoflBH--) {
        McvFh = ! McvFh;
        XAFiDvJX = omvoanh;
    }

    for (int oPqctpTnQB = 1757431094; oPqctpTnQB > 0; oPqctpTnQB--) {
        nsTgNcMZkFw = nsTgNcMZkFw;
    }

    if (xRTmxzN == true) {
        for (int WNlCIoxt = 1264433700; WNlCIoxt > 0; WNlCIoxt--) {
            bXCyDbmR = bXCyDbmR;
            xRTmxzN = JjDKPcAtLp;
            xRTmxzN = XAFiDvJX;
        }
    }
}

string EpnwBLJnw::BaJzDV(bool CHcxzJOuB, bool yblcVQbuhFuHXJ, bool fpqXovyIJRgpod)
{
    double egsndXqpGXCIAQl = 419260.74908229976;
    int bYldiRLVZEIOMYK = 1599043390;

    if (egsndXqpGXCIAQl <= 419260.74908229976) {
        for (int UHAcBh = 90844144; UHAcBh > 0; UHAcBh--) {
            continue;
        }
    }

    if (bYldiRLVZEIOMYK <= 1599043390) {
        for (int kSIwUI = 449040880; kSIwUI > 0; kSIwUI--) {
            continue;
        }
    }

    for (int eRgoy = 2097951928; eRgoy > 0; eRgoy--) {
        bYldiRLVZEIOMYK = bYldiRLVZEIOMYK;
        yblcVQbuhFuHXJ = ! CHcxzJOuB;
    }

    return string("GfsbzlObiYQFcITkXfeRzpORIddrrJbmeHVedJTMZoluXkTXQdiBckkRLJlzPukJNNfCepSvkQdKtIBctehHoReUOjqcuOpvnClpmTubBYkmk");
}

int EpnwBLJnw::lSdMYOXxwltUsx(string ASnovSh, double wWPhNU, double FnBpJPOMFdzWkm, string rMUaBajozg)
{
    int HNxazbxrHrjOgTE = 1181832956;
    double VoBDXiFQ = -243656.79585165263;
    int wAKymyVTbdNbJ = 1997276436;
    double HttDIfpQYQeYhDt = -236613.2166949228;

    return wAKymyVTbdNbJ;
}

double EpnwBLJnw::uiNvWSEZWe(string ICiUdwHFve, int YwftxZczpu, bool RlHtnxRehaLozgBm)
{
    double LNvFQXHcpEZY = -583854.6620108628;
    string KCeksHDsvnahELgC = string("FucUVzpiAUnkzwByIgFtsGxcutDFyegjTrMaSRGnXDLpXlqMvdilejkSrVeNqOmYByuGMVpnslpLpaWdFvXUOkCdRzwcztuXKyUfRPGOhjAdGszUbHyvUtKNbxCf");
    int YkpBzHSdZutVFj = 374666872;
    string sxsVXmDyradb = string("zTBcvHgKHpTnewJnsHGGafsQLxMDFjlJoHmAllTpUHqtatoSJmeQtuOCMjfOhwZbkabv");
    double bIeNwS = 54253.39400646406;

    if (YwftxZczpu > 374666872) {
        for (int DfaVnKIEjmib = 124642796; DfaVnKIEjmib > 0; DfaVnKIEjmib--) {
            YwftxZczpu += YwftxZczpu;
        }
    }

    return bIeNwS;
}

string EpnwBLJnw::CnqZSDFEjfrNff(double fhnEfF)
{
    string uTwsPJWmPicoaGg = string("SalwOHsMVLixGRfnFblkbaHcvNxGYtPedNiRgNgdrAiaysYGYJVtJsXpuPpmCVsqBnWuZuwIxEaRBiqxySgfAcCKEcJhONwJRpNFypxTNHklquuwuBrzswSNiLqIAcATElfrWow");
    int FUEHivGDySsb = 41768840;
    bool SQAycrA = false;
    bool NLCHMMqKHpUwnrkE = true;
    int rafmYLqn = 21991316;
    string lGXFGoKE = string("CyZebihvZDkGKsJTgTjrYBrhZGBYUsXNCJEBkgQgZxTivISfOYkMdCa");
    string IxTCHPIknNFRK = string("KSLNTsFcRjDOWCnrkBZwPFBRtVEgyAGLORASdXaxxTAbndsQWqtDGHGhcUNEdtvMgkylimCxuAaeLutfBEuUPxhuXqCWfeGxKFhBYWBfqEfUVRzHZRlgRRytrjfbeJUotbhVxekPYXaSBcvnLZTwIundzriQVScUtFVzSyyQRZLUUtfbKdwDZApsWlIXksCcTUzqrXJoLyjuDqVvFfsVJ");
    int YplyTSaYh = 1595239686;
    bool TxYhLPBVTfb = true;

    return IxTCHPIknNFRK;
}

void EpnwBLJnw::uFuoj()
{
    string iUVtYxVBzbjJu = string("uHxgyAxQIPlZMwgTrsaYnHHbeYtEaRhTSSDvABWkGbxQyFTldewRBPUpfQfjeItXkrGuWWBSdoBFNeMmxWryLmnARfbAeXiWljOUBAtzoKhJsuEbFGyAtXxMVtBkZqlOXwFKMNhLJkbZiCWyNObzcgIUCaBPKmpdOTFNgTtMHVudEpWnlvdtnHmJDHvgtswbQ");
    int AaEBxPVs = -1224857491;
    double NgcDIY = -678676.4309118405;
    bool LKsLrpu = true;
    bool olndPwZQKnAjITSA = false;
    int WBuaZLlXeId = 513221072;
}

void EpnwBLJnw::cyBrknxpouAynX()
{
    double wwiqCUTmE = -940536.0803992257;
    double liZphEPhgFDu = -440669.5162713552;
    int YlvPIMnvpnRRFLxx = -2042043545;
    bool kYJyIphjDTlGW = true;
    bool pquTvzoPHQgGgv = true;
    double qOFFuEXuD = -954088.2638305061;
    double CprsXXy = -507903.6325524681;

    for (int AfqhlLhmzlgIppj = 1302798168; AfqhlLhmzlgIppj > 0; AfqhlLhmzlgIppj--) {
        liZphEPhgFDu -= CprsXXy;
    }

    for (int HGMiqNyIti = 474921501; HGMiqNyIti > 0; HGMiqNyIti--) {
        CprsXXy /= wwiqCUTmE;
        liZphEPhgFDu /= wwiqCUTmE;
        pquTvzoPHQgGgv = pquTvzoPHQgGgv;
        CprsXXy /= liZphEPhgFDu;
        YlvPIMnvpnRRFLxx -= YlvPIMnvpnRRFLxx;
    }

    if (qOFFuEXuD == -507903.6325524681) {
        for (int MLkGi = 1318615328; MLkGi > 0; MLkGi--) {
            qOFFuEXuD = CprsXXy;
            CprsXXy = qOFFuEXuD;
        }
    }

    for (int WUMWfg = 953297583; WUMWfg > 0; WUMWfg--) {
        CprsXXy += wwiqCUTmE;
    }
}

string EpnwBLJnw::CqJZGfRvmYwB(int lCbCwEPFz, bool qCzLEMmhILHLrq, string vICmYxj, string tDomcNtHFprw)
{
    string AeqZzRPhIIvbt = string("JmOlKWAtyaLKNYcziMnhskeaEcallVjsTIiFImkXEODMXVDyHPdpDPYRorrTtZYCjAEyQmjfYRlGTYRZRRTwyfITuORUPleUIFCdEqvuJLsGzSaCytDKyloRTTVKhBEyUDrmysfYqpnGqxmFUJcxcRwtXFfjIQIAKgYMIdWm");
    double KympkZqw = -460084.8165360977;
    int rsguQZwn = -824039760;
    bool OhieXb = false;
    bool VoxxQPpdrzT = false;
    bool HmkjFycmazrEmbhO = false;
    string RCCIDBU = string("ZiaitmEWPXcjmTlkTsbtpsdGEUUvmWWArzlfaYdpJYAVEfNefagheOTNSPgDUtVIjUJeZLGRsEBytsIljKpHXyEKvqkfjMlnzApwXIwZKudHCthISpGmBnNtvKZzXiqbVBdIGFUeVWACVqcHUhXAouZhJlLMxPsCrqnbXRrKXpAEyQojfpCCqZzcQFvsWbcPYvMKepyaAqWCHkdjHNcwxoVuBELGqJSpQHVRdowcCeowCrKKMAKr");
    string RdvGZBzQnZ = string("hfCXoWblnJVFdpNgsYhEJHbiYOZwQGSFeraulqhurMjfYtpvoMGkgBNxIiNkoAyPvIYqvChWpuFEQXRnzlbYUHNN");

    for (int ZAlWMzY = 1899468375; ZAlWMzY > 0; ZAlWMzY--) {
        continue;
    }

    if (AeqZzRPhIIvbt >= string("hfCXoWblnJVFdpNgsYhEJHbiYOZwQGSFeraulqhurMjfYtpvoMGkgBNxIiNkoAyPvIYqvChWpuFEQXRnzlbYUHNN")) {
        for (int JNWJlKoqDivsOfJ = 998078984; JNWJlKoqDivsOfJ > 0; JNWJlKoqDivsOfJ--) {
            rsguQZwn += rsguQZwn;
            qCzLEMmhILHLrq = ! qCzLEMmhILHLrq;
            vICmYxj = vICmYxj;
        }
    }

    if (OhieXb == true) {
        for (int DaraEKtDat = 987423509; DaraEKtDat > 0; DaraEKtDat--) {
            qCzLEMmhILHLrq = VoxxQPpdrzT;
            RdvGZBzQnZ = vICmYxj;
            vICmYxj = RdvGZBzQnZ;
            rsguQZwn /= rsguQZwn;
        }
    }

    return RdvGZBzQnZ;
}

EpnwBLJnw::EpnwBLJnw()
{
    this->krQByskTbXnzy(true, -875650.0070365996, true);
    this->XFsIcGDWa(1261185302, 13640.604289154217, 509743067, false);
    this->zpKnUMyHErUEmA(string("VZtJlQCDLAMVlUpzWEcvbskhNFWsGeXvRAZUzsDglQjUfdESulrIwZqtcptEwjrLQUBZDjKugmDBSOWEdXFGnWvZlQCgRBVvlLxCsljTVwSJcDsRpwyrwIyTeQLTpomROFQsMrOriNjvieLuItzgHQizTVJzNJdMjMyzvmGdhEImHKB"), string("LgdUzQuEtceErIbOqYvwjrqovYhavWgUoOkOXMnmNsHlPzYpjjvtqDuSAyFpAVSUBzFvOBEQoQorLZUhDGBxIPPqSETzWDGVendpKFOMqShPKMUQMaWMvkpITMmOAASmlyUGiuYgmNRSsmcQgZGdS"), string("ytPLgcZvtVEiWOBrlQOPKxZZwEcIyMDIvMvCDeVFaFBXQBqKjFIStYWRxtkCvKckLWnvQhWldlCUdagTmqrCsvXYxyIFRpLHeKRHbdfzzGljlnAWdKuxoTtCOgMmgTXlCbkHvqrHKzDUUvEzFtzDEGNptIKcUTXwLdlYDFAntjAAqQDulFPIzowhsRTbkjJQmwotbUJFOFZEKYDtDjSmIuBkfxxExTSkKHaLIUBtfxlKMLUo"));
    this->BaJzDV(true, true, true);
    this->lSdMYOXxwltUsx(string("fSBBKGRroOTChddAPOHgIRVZvUCfeEFFvygpXTSaOpgkDWcENudC"), 652846.0971533139, 505332.9779257292, string("YhGqxyvSGtRQpmDGUZEtYzYBVrOQZuNaOrAxHBlNjUaOMFgZyfewZGphgtCMBqFmOduVPDmEljhiuzDijOeYbYHWJItrSZDaoiQWPpGOEhBVcnFtdqBooRjTEbRsGiDzkMbdlaxYcaZrUBPuTQhzlkRdBZOhzqNOPYynIchxBRPGQlFrunn"));
    this->uiNvWSEZWe(string("LIiIrozvwzNDyIPoYaVrZfeQDpBzZJgcDNQruiJUFHMgmQaRExMjVOCqHwpLCGhpTyMAPFAXEJjwFdtmNeCpvJjCjQECbQPsSJaVdxzBxHxEKNlRDWn"), 1671964470, false);
    this->CnqZSDFEjfrNff(-665249.0709341863);
    this->uFuoj();
    this->cyBrknxpouAynX();
    this->CqJZGfRvmYwB(-933129131, true, string("CmddIWVDRPMVjJBAJSDdvFYtXwAKLebmXODmgNOdAkYWbeetreKPZpUCoPtnRbaxgVhnvsruymbsypsQnbLKNMeXmRikYC"), string("WzBlSykOiiSalxOFbjnoiKHqHhsaDGucxcEgVEvpxOnCYKkuoxzIqsfJFoxKXvSnPYKVujCclYkuReAFZnWdlBMGLMVpJbxoogGZSIxrMSljgzQphFrKbKqG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BwnWopzC
{
public:
    bool FfgumqpFeyTxYT;
    double LyOQZKuwgwzLn;
    double bHumoHJwegaMEL;
    bool pgaryCalyJsNAHG;
    int fNekRVeTCfs;

    BwnWopzC();
    int rLVIf(bool MIIaY);
    int UDgnyRDn(double zjAsXEKx);
protected:
    string xzKaAsd;
    int JWuak;
    string tBmnjEOtJRdIrp;
    double BmJrx;
    string zfrvmKZnZVzm;
    string qqmwqGGutlUs;

    void ZRfGDWoUrZdPNmG(double vuvIGVvLhbj, double PqPQNPzOZKqt, int xsgkqJPRApZfUQw, bool KCUrGTzpfKx);
    int gRfEYLDq(int oflPhbBcDew, string dTucMTRLUZ, int CXcTd);
    void wvvSzc();
    string rQHTunwxyv(string rPqCGTmGRI, string OylpLwrFvHYwUDvN, double CoFmimcWAoJP, string BPyUPLEXdJpAfj);
    string OBFmiveneq();
private:
    string nQDffnzbGgUUX;
    string NWTiBqEwHO;
    double plgwts;
    double FlNareD;
    int OeKnkPgFZB;

};

int BwnWopzC::rLVIf(bool MIIaY)
{
    bool nCiwy = false;
    double cFqvdDnAZRdb = 403360.4719560993;
    bool QmNlDTnMOZHCiH = false;
    double GuWIFVERKf = 348145.70899397816;
    int FgVmJGRCeMAzUVm = 286886104;

    for (int Kupxa = 1066105158; Kupxa > 0; Kupxa--) {
        GuWIFVERKf = GuWIFVERKf;
        cFqvdDnAZRdb = cFqvdDnAZRdb;
        MIIaY = MIIaY;
    }

    for (int zYLkwLllsLboTpW = 1567004207; zYLkwLllsLboTpW > 0; zYLkwLllsLboTpW--) {
        QmNlDTnMOZHCiH = ! QmNlDTnMOZHCiH;
        nCiwy = ! MIIaY;
    }

    if (MIIaY == false) {
        for (int Dbrey = 960052739; Dbrey > 0; Dbrey--) {
            MIIaY = ! nCiwy;
        }
    }

    for (int twACxuhvjymuJ = 140317502; twACxuhvjymuJ > 0; twACxuhvjymuJ--) {
        MIIaY = ! MIIaY;
        MIIaY = ! nCiwy;
    }

    for (int PFmouhEe = 161332405; PFmouhEe > 0; PFmouhEe--) {
        nCiwy = ! QmNlDTnMOZHCiH;
        GuWIFVERKf = GuWIFVERKf;
        cFqvdDnAZRdb -= cFqvdDnAZRdb;
    }

    return FgVmJGRCeMAzUVm;
}

int BwnWopzC::UDgnyRDn(double zjAsXEKx)
{
    bool KflXvUrprcX = true;
    int UimFQPnmhzBOR = 854143482;
    string iQvsaalNA = string("ondpbQumkDSVhCuDtkvKZsIdlbkFmiNJoaHGBqtHWxkawRVIpufDEpMEjnlUBnxVWBIMLCXWjgOlMHvRUHoZkWPXupRnDgyMjTEznpGMoaNQCImropeSSDqAbiUeaCGMEYlFUAJleUWkeiPvyZLTsElcFIJBGNGeWabAfBUCPAqHjbYYNWednFsoXKtYkoOzwvNpZuwIQUyYrjgyPkWVrTqMRwiaHZvHCkwWDi");
    double TnzzAe = -678674.5143295531;

    for (int iHwvFij = 138416829; iHwvFij > 0; iHwvFij--) {
        continue;
    }

    for (int nzBOXsB = 1742381432; nzBOXsB > 0; nzBOXsB--) {
        zjAsXEKx -= TnzzAe;
        UimFQPnmhzBOR -= UimFQPnmhzBOR;
    }

    if (iQvsaalNA < string("ondpbQumkDSVhCuDtkvKZsIdlbkFmiNJoaHGBqtHWxkawRVIpufDEpMEjnlUBnxVWBIMLCXWjgOlMHvRUHoZkWPXupRnDgyMjTEznpGMoaNQCImropeSSDqAbiUeaCGMEYlFUAJleUWkeiPvyZLTsElcFIJBGNGeWabAfBUCPAqHjbYYNWednFsoXKtYkoOzwvNpZuwIQUyYrjgyPkWVrTqMRwiaHZvHCkwWDi")) {
        for (int RUiGqldKGFvsyYxQ = 765743127; RUiGqldKGFvsyYxQ > 0; RUiGqldKGFvsyYxQ--) {
            continue;
        }
    }

    for (int ixQVLsaHI = 717192596; ixQVLsaHI > 0; ixQVLsaHI--) {
        UimFQPnmhzBOR -= UimFQPnmhzBOR;
    }

    for (int LSekpI = 1061425028; LSekpI > 0; LSekpI--) {
        TnzzAe = zjAsXEKx;
        TnzzAe *= TnzzAe;
    }

    return UimFQPnmhzBOR;
}

void BwnWopzC::ZRfGDWoUrZdPNmG(double vuvIGVvLhbj, double PqPQNPzOZKqt, int xsgkqJPRApZfUQw, bool KCUrGTzpfKx)
{
    bool VhYoYXdgWHcmA = true;
    int NoucJ = 514746903;
    int OdfKiW = 118124235;
    bool WyOrtf = false;
    string DyhaCtIpbHz = string("EHngPEzfShdNqpAlUWAmOIgqqbGPtowHdvoEihezlkzwESKcXBVFoLjvgQrHytUPYGlLXnEoDzOhAKHQhgOMunbGFMnmIUqfLHRHPHNLcRfNyUTJkpVUEXjWjOyHmtwDwjurrYrDaXTaKfaOkZWpuGwRaRFLzduH");
    bool lpFmw = true;
    double yXlNSsuKjwVHE = -1017732.3793426434;
    int rlhlOnDr = -303253847;
    double txXvGGCJCdgc = -185468.40459051557;

    if (NoucJ >= -303253847) {
        for (int KMrKghf = 917652610; KMrKghf > 0; KMrKghf--) {
            txXvGGCJCdgc *= vuvIGVvLhbj;
            xsgkqJPRApZfUQw = NoucJ;
        }
    }
}

int BwnWopzC::gRfEYLDq(int oflPhbBcDew, string dTucMTRLUZ, int CXcTd)
{
    double RoVOjXyTMuZwoZ = 942187.8141524865;
    bool zekDHNQoyzujtNoQ = false;
    string FLXompNYeOL = string("AqmcasSUvEKdwVoQetzrxyaEqZYrNHHgPXzZSYflQvbPxJdVCcnjQfgvzpORESWHUOYRJTOsEMkH");

    if (oflPhbBcDew <= -1831404444) {
        for (int WRTiMTdgDcF = 884834343; WRTiMTdgDcF > 0; WRTiMTdgDcF--) {
            continue;
        }
    }

    return CXcTd;
}

void BwnWopzC::wvvSzc()
{
    int YivmvKoxGiAOZXhx = -1877104278;
    bool lnSRZOoc = false;
    double vydrkcDnXqsPoJJo = 41104.26567907519;
    string GHGjplUVxJOMopE = string("rkQwJSaZgkqPCCgaYVqNvUFbNYOgTphgRHJpLChAKmNwbu");

    for (int PCRBdrq = 1292356105; PCRBdrq > 0; PCRBdrq--) {
        GHGjplUVxJOMopE = GHGjplUVxJOMopE;
    }

    for (int gXBXJmxG = 1653344168; gXBXJmxG > 0; gXBXJmxG--) {
        continue;
    }
}

string BwnWopzC::rQHTunwxyv(string rPqCGTmGRI, string OylpLwrFvHYwUDvN, double CoFmimcWAoJP, string BPyUPLEXdJpAfj)
{
    bool MaJCmwXSzJQqhDM = true;
    double vNPqtWFTOnV = 38492.97931670547;
    bool DEIiR = true;
    double nqAwj = 999572.348904898;

    if (BPyUPLEXdJpAfj > string("dJgPGUglSyNqiAJVPDCdKSzgbPwdnYoKEJIkNkcgBBWsAICQAgqFWoOHkaOwENKrsZpuwfupNtAecwiaoNkydoBUvuuzkoRuMyPvZVZvxazvFXTwbOvsuZia")) {
        for (int YajbuSQZwIG = 57116790; YajbuSQZwIG > 0; YajbuSQZwIG--) {
            DEIiR = ! MaJCmwXSzJQqhDM;
            DEIiR = ! MaJCmwXSzJQqhDM;
            vNPqtWFTOnV *= vNPqtWFTOnV;
            nqAwj /= nqAwj;
        }
    }

    for (int BkcuM = 1658212131; BkcuM > 0; BkcuM--) {
        rPqCGTmGRI += OylpLwrFvHYwUDvN;
    }

    for (int KUSqJtGmVznUS = 584678257; KUSqJtGmVznUS > 0; KUSqJtGmVznUS--) {
        OylpLwrFvHYwUDvN = OylpLwrFvHYwUDvN;
        rPqCGTmGRI = rPqCGTmGRI;
        vNPqtWFTOnV = CoFmimcWAoJP;
        DEIiR = ! DEIiR;
        rPqCGTmGRI = OylpLwrFvHYwUDvN;
    }

    if (rPqCGTmGRI != string("EhfWLLnchDagEeicjjDMDbPCoGENIJZsUHWlnoTlecplywpJEnvaLVfFjVKfAPgRkxanEmEAtWfSeDyxSvqvRYAUYDiH")) {
        for (int QnaInNjSLgNh = 1363503103; QnaInNjSLgNh > 0; QnaInNjSLgNh--) {
            OylpLwrFvHYwUDvN += rPqCGTmGRI;
        }
    }

    return BPyUPLEXdJpAfj;
}

string BwnWopzC::OBFmiveneq()
{
    string yRBIfRvkTLW = string("crVqRytoJIRRgwMRIDVLZUIyYomzNEwcZgcxqZFNdsJdMupHXfuVvcMWPQdBzJSnssjzfWDHvRWvNzEAFtSzcBpHQJNfkGKlzKVEbdkMgnWZFfqsahbCWptTYWjbWvGYglWXhypORUixlYTEZBbhWjahcltJXbNjQNLCZpaFQZtfuBFnwHCdYTz");
    double XskBtSWXLpKLSKNC = -620358.9474294948;
    int alMFScqy = 2108589080;
    string sEyBkEubjFH = string("pUrXmDhBCDzvASvSXOymDJHiTftpdyS");
    bool KJvLrTNArAQgxB = true;
    int UMFAQeoXo = -1961902806;
    string ZzhpIeaUVDhe = string("wsXhaSIZlqsidXFsOoeiOauHljmPumtCOCFFGAlLMweIPfYeirgWKPuDvRdwfUqNDjEaORpwEBuuEyBJKyEcLLZOmtRxmqRXbGFOimtOYKJOApXnDhlIsFwWmicFiAaYrokAobLgsSXWsZDvyPQZGNjymJGQ");
    int mdRlfdCIWk = 239282481;

    if (alMFScqy != -1961902806) {
        for (int zFzHBI = 381792538; zFzHBI > 0; zFzHBI--) {
            continue;
        }
    }

    if (alMFScqy < -1961902806) {
        for (int IsmvAAKwyvqMsN = 531848240; IsmvAAKwyvqMsN > 0; IsmvAAKwyvqMsN--) {
            continue;
        }
    }

    for (int AfwWNhhAEB = 923302198; AfwWNhhAEB > 0; AfwWNhhAEB--) {
        yRBIfRvkTLW = sEyBkEubjFH;
    }

    if (ZzhpIeaUVDhe == string("crVqRytoJIRRgwMRIDVLZUIyYomzNEwcZgcxqZFNdsJdMupHXfuVvcMWPQdBzJSnssjzfWDHvRWvNzEAFtSzcBpHQJNfkGKlzKVEbdkMgnWZFfqsahbCWptTYWjbWvGYglWXhypORUixlYTEZBbhWjahcltJXbNjQNLCZpaFQZtfuBFnwHCdYTz")) {
        for (int iEVjtVFre = 1619616627; iEVjtVFre > 0; iEVjtVFre--) {
            ZzhpIeaUVDhe = sEyBkEubjFH;
        }
    }

    return ZzhpIeaUVDhe;
}

BwnWopzC::BwnWopzC()
{
    this->rLVIf(false);
    this->UDgnyRDn(506774.8956771406);
    this->ZRfGDWoUrZdPNmG(76021.30881825455, 862088.3988563865, 172728174, true);
    this->gRfEYLDq(-1862538595, string("covipOksKfXPJFngScyMerwUOJGnduiBhDfMRHQQqUYuYenqpYfZlsdCKOWaoRlNHHjstOGcnxVqKUlBfApuoKTZVHhaYTCVPUELuZeXwfBLCVADMbTPwaHeRfCmbhMfPoHRtgWtNfHyrTxfAaZxpyGxkqmWxVnLitNYThyNYDGhJrewlGnMMyyItIwBXSiPelazaAjbaVwlmxPNiNQ"), -1831404444);
    this->wvvSzc();
    this->rQHTunwxyv(string("dJgPGUglSyNqiAJVPDCdKSzgbPwdnYoKEJIkNkcgBBWsAICQAgqFWoOHkaOwENKrsZpuwfupNtAecwiaoNkydoBUvuuzkoRuMyPvZVZvxazvFXTwbOvsuZia"), string("KGeXmIpkMCoQsUGwUtOzhaXbvtdsuCfGoMncBpfEydCWcoFiYKOAXgTSLZEcjZOFNrM"), -532229.9955633221, string("EhfWLLnchDagEeicjjDMDbPCoGENIJZsUHWlnoTlecplywpJEnvaLVfFjVKfAPgRkxanEmEAtWfSeDyxSvqvRYAUYDiH"));
    this->OBFmiveneq();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PUnUMRPjJPtns
{
public:
    int XuvfyZxUGqU;

    PUnUMRPjJPtns();
    bool EIIPfumAmCdAgrlk(double yvjIxmBssAM, string aPdpIqEBQXlliLV, string ERkaIbOQdmXpu, string bmHXCoHk, double HkuwkbJsJyQixD);
    void pNEavRHnGBDWv(double CJmHOCwRAFgUdQ);
    string bKwuEmqW(bool rWNZDQgqNWFVb, string qwOsjm);
protected:
    string DuszquAYA;
    double YQjyiehN;
    int JkpvjhkVNfdPjHEH;
    double AiUNfadNUcvETUxp;
    int xEhnsLMoozuut;

    void MYXolLFEtW(string BmFldVwKnnQdqUh);
    double FFUug(bool qogPh, bool RaRqu, int pNjTjbTevgOe);
private:
    bool agSPkHFL;
    int YafxnmggETLk;
    bool LXQjv;
    bool EDBdWajrYvsZQqC;
    bool KpkJfFbDOgUhX;

    double XaxrYH(bool KdjCJAiLC, bool CpAdfMd, string IZKwaqdHwzb, bool YRfKydiApPqzfLBX);
    bool YdooQrSaXoXYyO(bool MsKHeEbkveGW, bool YuRVvfT, bool kVxYVhUXUgojzDao, string bLwNdalrAZ, double ktSAorYU);
    double hRLfdWMC(double ajYTzfOQxFqTHUQj);
    double vfZfgTKAPJ(int XvZCJI);
    string sUzxfykH(double oiNWX, string MWhGZFbWb);
};

bool PUnUMRPjJPtns::EIIPfumAmCdAgrlk(double yvjIxmBssAM, string aPdpIqEBQXlliLV, string ERkaIbOQdmXpu, string bmHXCoHk, double HkuwkbJsJyQixD)
{
    int LnRWYDEOpPKc = 1363361517;
    double gnYujz = -913620.3358563164;
    bool gRcxosfrDrfjzkxa = false;
    double ugmPcONM = -362596.7065143625;
    bool JVxRKvTfgrt = true;
    int qSeSIEBCjwfZ = -1605543471;
    int oNMPkWsq = -951091979;
    int vWDmyncWXz = -2014097264;

    for (int bzOYZVXOjQCcSMqh = 1765309142; bzOYZVXOjQCcSMqh > 0; bzOYZVXOjQCcSMqh--) {
        yvjIxmBssAM /= HkuwkbJsJyQixD;
        HkuwkbJsJyQixD = HkuwkbJsJyQixD;
    }

    for (int PMduew = 1717452403; PMduew > 0; PMduew--) {
        continue;
    }

    return JVxRKvTfgrt;
}

void PUnUMRPjJPtns::pNEavRHnGBDWv(double CJmHOCwRAFgUdQ)
{
    int QjSfLECZUlqXCgR = -750494434;
    bool MxqVfsJuHXtXbDjT = true;
    bool bhzIlZDo = false;
    bool WwqWUE = true;
    string GOrKVBaq = string("UQYLiBnHHgptJapBpOTRZhRPEmxuOJuRdAxDJSYZJPkhFeHUEceeyKESqLuBfbxuzariDpDrkLdWZblpQRmOAecsBXGKxMyjmyIEQZbXOKikqAPYLNBvFHsWyMRlKDziJVQxLQOBeVtqoKiQfaExihRhzSAfXoIXbGbXcZQMJqKDVHBIbuqhwSvxJGWmMCYTogHAOsaOxbuecRvfvMdxvRmQEyeaKl");
    int UnXgtNIiLoQ = -1362505988;
    double EHZOpUqqBr = -894465.6502755939;
    string fqpQrhGUrJQnLY = string("nTchGPIectsjesZipLYgUpXLaRSgsRJMWoDzFDaHhmVXxjLjgEGPKrUTGPGrXJoOkVEBkzfobfjo");
    bool KLZZxTqlXDTWkSB = true;
    int WhJcBMvJ = -60891768;

    for (int mJRDfuY = 76313315; mJRDfuY > 0; mJRDfuY--) {
        continue;
    }

    for (int fRNPYLmxqF = 1140740723; fRNPYLmxqF > 0; fRNPYLmxqF--) {
        continue;
    }

    for (int NGQedYMFgUUB = 425976305; NGQedYMFgUUB > 0; NGQedYMFgUUB--) {
        WwqWUE = ! MxqVfsJuHXtXbDjT;
        WwqWUE = WwqWUE;
    }

    for (int PqrNeloH = 1910509841; PqrNeloH > 0; PqrNeloH--) {
        WwqWUE = WwqWUE;
        fqpQrhGUrJQnLY += fqpQrhGUrJQnLY;
        WhJcBMvJ /= UnXgtNIiLoQ;
    }

    if (UnXgtNIiLoQ > -1362505988) {
        for (int LSnlcTpEk = 1586820456; LSnlcTpEk > 0; LSnlcTpEk--) {
            WwqWUE = bhzIlZDo;
        }
    }
}

string PUnUMRPjJPtns::bKwuEmqW(bool rWNZDQgqNWFVb, string qwOsjm)
{
    double IYbWdthvIFHhOC = -651001.8848899809;
    bool EZyWSUsmLKG = true;
    double vXSwvUKcLdJuy = -14150.676603058813;
    string PmCDP = string("mouQBpZcsGqZuMFYXGtZFbwRIlFNQSKEVpttxmjdJdqXEwFX");
    bool RMcmaudPJgTKJ = true;
    bool bobdTFltFgrgn = false;
    int rYKTvA = 577652885;

    return PmCDP;
}

void PUnUMRPjJPtns::MYXolLFEtW(string BmFldVwKnnQdqUh)
{
    double KcTlC = -416389.52771598153;
    double MnQjKnUQFafS = -928870.6773844452;
    string RgtKYtXYNFuxD = string("PNwzkktFf");
    bool XiWfUePmeIFV = true;
    string FHfwOFSAMZgap = string("nWLhlyWxMAOsvEIGUoqazQMAIuKOpVUTYxPshraiXYIBWOogXeNROrsSENdxsBAaDomkPTlWmVdJaSItTbijQtzXbykWJlGwvQDYHFkrvKksmwYJPGYZSuQuAaxQCvnoRlvPLWnUFtcwzrHlUGGclOtT");
    double rlzKJoWXZc = -248977.92850562348;
    string SggORauproDgPsof = string("vQzqJxoOZCErohNcVHkfxECxIhgTruujSxmFtIAPsVxFzVtFgzbYlCfuMchERfnIFxYjekZiMTlZZjNQPAKxgngrhYsQxZKimfvijhokWsEZLcsviXmdJGIBTFbJmnsvBgrgSRgShYEjkfAXIGszOZmfhwElDNQjBHBiqZHxvMrNcqXdWiZtCCZSQsFxFRSFHOrSqaZVXpZqIPkEqTSbpRMjzGO");

    if (RgtKYtXYNFuxD <= string("PNwzkktFf")) {
        for (int nPBzYhxLlQxKZbb = 1336157270; nPBzYhxLlQxKZbb > 0; nPBzYhxLlQxKZbb--) {
            FHfwOFSAMZgap += SggORauproDgPsof;
            BmFldVwKnnQdqUh = FHfwOFSAMZgap;
            rlzKJoWXZc -= KcTlC;
            MnQjKnUQFafS -= rlzKJoWXZc;
            SggORauproDgPsof += SggORauproDgPsof;
            KcTlC += MnQjKnUQFafS;
            SggORauproDgPsof += SggORauproDgPsof;
        }
    }
}

double PUnUMRPjJPtns::FFUug(bool qogPh, bool RaRqu, int pNjTjbTevgOe)
{
    int mZiowmFnyks = -194973262;
    int BsdgWCoNoPhHt = -1029892742;

    if (qogPh != false) {
        for (int tdlWjPhRePvyouLx = 285450478; tdlWjPhRePvyouLx > 0; tdlWjPhRePvyouLx--) {
            qogPh = RaRqu;
        }
    }

    return -660168.82034635;
}

double PUnUMRPjJPtns::XaxrYH(bool KdjCJAiLC, bool CpAdfMd, string IZKwaqdHwzb, bool YRfKydiApPqzfLBX)
{
    bool eZznofJHagJoAfC = true;
    bool KWHOwLwlTnJXJ = true;

    for (int YxcvaJNpY = 517435811; YxcvaJNpY > 0; YxcvaJNpY--) {
        YRfKydiApPqzfLBX = ! eZznofJHagJoAfC;
    }

    return -385801.3195606974;
}

bool PUnUMRPjJPtns::YdooQrSaXoXYyO(bool MsKHeEbkveGW, bool YuRVvfT, bool kVxYVhUXUgojzDao, string bLwNdalrAZ, double ktSAorYU)
{
    int ZnRMdDCyF = -1855396073;
    bool lyMKZnB = false;
    double IaobAmjXpUNOaFJ = -439252.6052465488;
    string MEqxU = string("YaDzmQlZZgiDeitauWGYsRJNxPhKXoNqe");
    int kgBJXTgYVkHi = 1531449490;

    for (int vAjleJI = 174618313; vAjleJI > 0; vAjleJI--) {
        continue;
    }

    return lyMKZnB;
}

double PUnUMRPjJPtns::hRLfdWMC(double ajYTzfOQxFqTHUQj)
{
    int KMKXmYFUNrct = -1103362355;
    string GfsKZje = string("SGylAtzjgietwpWtOgHDNWtJRkDPyIRUrjykYirmkioifwJMwusgCzWoPKyJHjrQIRTSNAkJCqcnMhpbKQpnyPPxgEBOeUQxYCxf");
    string cMWqtDTm = string("uIBeTwrMoRwCLadISaPRDwFMNUBTXwXCwCzKgSepYxXXfzlXCCMpPFVatvRAHjlDacbkafMrZgTxRufdrQZtyueaNMSnvvBMtJgWislpUMenDBfgblhCWKOQcFkCbgJzNALqfCQoqZjkRPjQgWRYycQicKUMlegDLIUVhSQcQdFnMJFAlvuRIRfYyCzYcASqBnreLFHHcVLKdnVU");
    int cesbzImlnYJYvt = 1589469538;
    int XLZgRNgtuoPbOz = -1552419303;
    double Gdrge = 993234.1738405562;

    for (int eApheBNnYPGABDp = 1794787490; eApheBNnYPGABDp > 0; eApheBNnYPGABDp--) {
        cMWqtDTm = cMWqtDTm;
    }

    return Gdrge;
}

double PUnUMRPjJPtns::vfZfgTKAPJ(int XvZCJI)
{
    int TBNHYngjzRreK = 1604331206;
    string flYptDTLnvfh = string("kqOtoAXZCWYKpQXamOAmcqdQeiThThZdmNyqNoecdRxJgyCOafGaojUYAxpnBknbwchVfxMVojfcwDRdFHrNiYfBGrdFJFnSYMOFYpcASAPTkUMshAFIhWQowikvdbzbCVTPKnirAegwiaycUgbpVSwHryaadnFeBMNkqRrDohvNHHpeqwQGxdrfgy");
    string EdSiC = string("nlWqztVgnvILMFlzjnuDNCbpCqmMKcZaycmQmlecrREkeRcyTOXfaYRiTDvsGZXvpcEQRomnTMPDJrqHxUGwTHGezYadKIXkvNqqjHcAXWZTRQygdqEwbkSCMhOwdqQpijuMIKTlTzBXNGQUNtkGCSYHmJjroV");
    int pJIolYpLNq = -1193261904;
    int wrmnnGahAjEZq = -1250001457;
    bool ukXTAeNMRuISdi = true;
    bool ieUGjZID = true;
    int JNqXD = -25845271;

    for (int SxupMhdWxNXjC = 1174709775; SxupMhdWxNXjC > 0; SxupMhdWxNXjC--) {
        XvZCJI /= TBNHYngjzRreK;
    }

    if (XvZCJI <= 1604331206) {
        for (int BwDGVZmmdwxR = 430095842; BwDGVZmmdwxR > 0; BwDGVZmmdwxR--) {
            XvZCJI *= TBNHYngjzRreK;
        }
    }

    return -223795.43956254938;
}

string PUnUMRPjJPtns::sUzxfykH(double oiNWX, string MWhGZFbWb)
{
    bool hJRZdsNTgDVO = true;
    bool zTsCUwCgEzLzJ = false;
    double DYJSZeQsa = -745017.1468852824;
    int UuFjAPnEHzgaGBVy = 488909877;
    double XDTfSgZVQrSj = -229405.5587493969;
    bool PxCCHCpbhGYHMFkf = false;

    for (int EqjeyZb = 1633660048; EqjeyZb > 0; EqjeyZb--) {
        PxCCHCpbhGYHMFkf = PxCCHCpbhGYHMFkf;
        XDTfSgZVQrSj += XDTfSgZVQrSj;
    }

    for (int DmMIzrmjaQBuIzOv = 2080456123; DmMIzrmjaQBuIzOv > 0; DmMIzrmjaQBuIzOv--) {
        XDTfSgZVQrSj += XDTfSgZVQrSj;
        zTsCUwCgEzLzJ = ! PxCCHCpbhGYHMFkf;
    }

    if (XDTfSgZVQrSj < -229405.5587493969) {
        for (int ZHdKuhzc = 769828256; ZHdKuhzc > 0; ZHdKuhzc--) {
            oiNWX /= DYJSZeQsa;
            XDTfSgZVQrSj += oiNWX;
        }
    }

    if (XDTfSgZVQrSj < 909030.8866537372) {
        for (int PjVGRPTBVi = 219091447; PjVGRPTBVi > 0; PjVGRPTBVi--) {
            zTsCUwCgEzLzJ = zTsCUwCgEzLzJ;
            PxCCHCpbhGYHMFkf = ! hJRZdsNTgDVO;
        }
    }

    for (int rNECBrYMRCyg = 74023760; rNECBrYMRCyg > 0; rNECBrYMRCyg--) {
        continue;
    }

    return MWhGZFbWb;
}

PUnUMRPjJPtns::PUnUMRPjJPtns()
{
    this->EIIPfumAmCdAgrlk(377695.8973974433, string("ATHiytAhWmQwZsCnSvcqqyXLgSsCKUvbhGeoMvexUrqSChOdWYJzQpKWwjYyJqWSMpNqCfwoidiVWsxmTciYocpRTWaQcuGFiqtPnqjUtFcnEEEJHlGNxfXSaDekJoOUulxknLuIgzaFNRksZqZYpTKjrjzmofvzgQzNkhsOLaRErfFlQNCxjSKTrqMTMPWmYFRpeGBDeLBglMpyBSux"), string("GgqGJqRZzFedkyQZHaUAJpBCnGSgyvCKituVWrNTXOnwsBSfhfONUGfQSpdNkrFkaYebunyXspVykSzzAbQlKyFNQTDanFZCKYbstSAuPUo"), string("UylHQqKzwMAnGxykGDvWvnzunMfXGwZUWCGrBwKPOapxcFeBIzkFqukbuPsxRvtoquikklkUKHdFQkEcbSVhKeWPRjwckbNQMGjoDsbtkQfnnTsGPjxJzTOWzWBQtYLajNTZdJeAObliIhoNuyPDkctLZHgHcHCPFI"), 827779.9927786132);
    this->pNEavRHnGBDWv(215673.4115761912);
    this->bKwuEmqW(false, string("ZRFhIcxClIsPQPSZRauwvoTqwvbrABlNNOdOKBEiUOSHbykFDMIuAscwkaNHGoTthJcbnhroRtDsTcUMlOazEPZOvPmYVMJyaoIfBUBRzoOLDCNjQHtIPSQqwuSTZiNAuVYyuGkdImATSQVLuojcbfvSsiGZXVZYKfRJdecYabNChZeTGZMqDUzi"));
    this->MYXolLFEtW(string("RkLlIwYCadMykdedZxeyJjifyLnXVQxabLDdadJwCBGRgjjNvPQtViplmQmNdRLChgFDyqaMRavzhsXstIYuGgvcdCxLaWdHjCOjfbmDzoCbMMrsjKjTuttmwAoJLDSkMLaCjviICjatGWshcJblJtLKFbgfhAcBBSIiZFbteJvWpEUPorelGTWtmDaFdeWMTExGfIemjfPSGnJbKzYFzWaganPEBpXEkhIBmYGONc"));
    this->FFUug(false, true, 214466210);
    this->XaxrYH(true, false, string("cuasKbGHbmqsgAopYjnYhtbgkSRpTgunmqYypDvoeJYRLlWSMCIpEvJhzHyoHLNtmnTeLlFhzwdtMkGPfSzcUkztaMeTsJjwaDzgRoKYcYcjFBtfglSjbKCgHzbUnejldzsuTMXaWszQsIwlNKbzGAmAKRQCYCDlfoRKSTZjwImfuNzdvJmmqvkmVgyzAwhaBWyVRHSVpCVhnQJWawOHiDzVOXvUcSyKpxjWQGdlYQhUGDqkLvZo"), false);
    this->YdooQrSaXoXYyO(false, false, true, string("SvvykeVrOtcyhxBGmJTnTSgbHutiiCKwEMIXcMIqoYcUFtxMKqgPrFgmZgMrbeKxvlpAxteqnkgRHtOAlIKxFqratDTrWQIJQQhcUkiEtTcBvQaiNHVht"), -370958.0714687599);
    this->hRLfdWMC(284602.85011574294);
    this->vfZfgTKAPJ(587685871);
    this->sUzxfykH(909030.8866537372, string("nGpnhxWEukLfeUUjjHMdiaezjoeRIdTTUzxIEssAtmOpwfPnIsTrEJtRLwJeEluVmTPjf"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SxuvxtnBJakjK
{
public:
    string FAdzFagFOloXnpdQ;
    string PmYrvwYvxxhxLv;
    double nQVGWnDyWQXX;
    double RbZWX;

    SxuvxtnBJakjK();
    int wkwrH(double pUTUbSailoUekh, int dzHjMBiSDOQ);
protected:
    int XaUuqnLyixC;
    double djxShydkrU;
    string oXWnCMQOni;
    int vffMbRveVhO;

private:
    int KVcfQxp;
    int pVeTSAOx;

    bool BBKyJJxhOd(int pggQfbhhRTfTYX);
    bool GIBMulGlDA(bool tWKda, double gsbEooizK, int GAvezENqxDK, int ZxtqUpnIq);
};

int SxuvxtnBJakjK::wkwrH(double pUTUbSailoUekh, int dzHjMBiSDOQ)
{
    double RavhjMlhAXgHKy = -253816.1834875661;
    string PHFrz = string("apEIbIpYjyYjASissnLBBqkMYmvUpdyyZsVPswFHlghogXshxovGAclEFTgIvCTRxzvwBOPDrvxfSGdxrtTlBNNGThyqouVKfrjkAPECXLkkiblTyLVcLzhcMqRCwDaxGpOzpLT");
    string kfwiKBhnGQwWQa = string("MbqHvsZJvCZvAAolFmvtsGuvoNkz");
    double gcIXAYUcWvnoA = 672495.680731931;
    int fhJUw = 964102129;
    string GLqirLavdqzbmoW = string("tUpgeyIWGfsFfidPECclcAnpSNKvhQHGFBDuTEAbBxCRejyumdLysBzUUrAcbPzQcWibHzuakDpmyBMgnaIuyCpimrKSNlrhqHVbIgUYlpIjYLFZRwFFNZrpTLvdIjHEnUIeUFKTgPXeXEvUWDzMbnGJrrBSBLPljkHrJrtnOPgcTWHtMUEGv");
    double EqCEZie = -351362.8915750818;
    double oZfkVCsqENBaRa = -635245.2410881176;
    double OlXjwxhVLLKU = 1006943.1170643237;

    for (int RJBHicRT = 391112829; RJBHicRT > 0; RJBHicRT--) {
        OlXjwxhVLLKU = EqCEZie;
        EqCEZie += RavhjMlhAXgHKy;
        GLqirLavdqzbmoW += PHFrz;
    }

    for (int lklGkil = 1534688155; lklGkil > 0; lklGkil--) {
        EqCEZie -= oZfkVCsqENBaRa;
        fhJUw /= dzHjMBiSDOQ;
        oZfkVCsqENBaRa /= oZfkVCsqENBaRa;
        gcIXAYUcWvnoA = pUTUbSailoUekh;
    }

    if (PHFrz > string("tUpgeyIWGfsFfidPECclcAnpSNKvhQHGFBDuTEAbBxCRejyumdLysBzUUrAcbPzQcWibHzuakDpmyBMgnaIuyCpimrKSNlrhqHVbIgUYlpIjYLFZRwFFNZrpTLvdIjHEnUIeUFKTgPXeXEvUWDzMbnGJrrBSBLPljkHrJrtnOPgcTWHtMUEGv")) {
        for (int UnHUkNPicoAs = 1763895898; UnHUkNPicoAs > 0; UnHUkNPicoAs--) {
            OlXjwxhVLLKU = RavhjMlhAXgHKy;
        }
    }

    for (int jWYvzud = 288026346; jWYvzud > 0; jWYvzud--) {
        pUTUbSailoUekh -= OlXjwxhVLLKU;
    }

    return fhJUw;
}

bool SxuvxtnBJakjK::BBKyJJxhOd(int pggQfbhhRTfTYX)
{
    int ZkntevuaTgVc = -165609400;
    int LJqOAdMAEcGhI = -2042709371;
    string CmNLbmPXTTEQHb = string("pghlpVAixmPETkBTIHMTsldpGecxfsBlBIHHwRUGIjaCUlUlfTrBRuaKRiAuGhdWKfEehLyhWNSLFyXFfszgRuzcTvjMigJbHqOySgxraxumEwRrxJqBuzxpvSqBFASHRUbORnedeZFulqngpNqeZoHLNREiJOlTHGbLdwpAhPgSGIzyEHajSuhhyfEGtSztHQkMMoJxZEuyiCWeBrPrTeLpfcbzjITvHIo");
    bool iNPOFrtmMd = false;

    for (int DlWKVlqpXqaG = 1059799217; DlWKVlqpXqaG > 0; DlWKVlqpXqaG--) {
        ZkntevuaTgVc += ZkntevuaTgVc;
        LJqOAdMAEcGhI = LJqOAdMAEcGhI;
    }

    for (int HyhTr = 978738807; HyhTr > 0; HyhTr--) {
        pggQfbhhRTfTYX *= LJqOAdMAEcGhI;
        ZkntevuaTgVc -= ZkntevuaTgVc;
        CmNLbmPXTTEQHb += CmNLbmPXTTEQHb;
    }

    for (int NYnHsyBNYzHbACqG = 626979223; NYnHsyBNYzHbACqG > 0; NYnHsyBNYzHbACqG--) {
        LJqOAdMAEcGhI = ZkntevuaTgVc;
        ZkntevuaTgVc *= pggQfbhhRTfTYX;
    }

    return iNPOFrtmMd;
}

bool SxuvxtnBJakjK::GIBMulGlDA(bool tWKda, double gsbEooizK, int GAvezENqxDK, int ZxtqUpnIq)
{
    double DWdVJxAWTQrb = 313772.76000132883;
    string ZZcBuxy = string("yvsLRpouwvdxxTSbpHKeyqmCjiRIsWhysQybTIflwKXMJMYWOicSmOtfQjGAKboizTVPuHjaybeRRBfMILNSRitmbtXskdOpKm");
    bool vdBbfZelv = false;
    double VcOAZlI = 739012.8205046835;
    bool cYpqAnAcLu = false;
    bool uWfQSQimtBvodk = true;
    bool XVJjFa = false;

    for (int FxCKixWpvUBtW = 439420229; FxCKixWpvUBtW > 0; FxCKixWpvUBtW--) {
        uWfQSQimtBvodk = vdBbfZelv;
        vdBbfZelv = ! vdBbfZelv;
        vdBbfZelv = ! XVJjFa;
    }

    return XVJjFa;
}

SxuvxtnBJakjK::SxuvxtnBJakjK()
{
    this->wkwrH(-564703.5661070242, -186415711);
    this->BBKyJJxhOd(943550876);
    this->GIBMulGlDA(true, 134857.13637845186, 2048779622, 1749116344);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BMmYJSFBmoaK
{
public:
    double bZUuLJpetO;
    string GKArlPOlbhno;
    double yuyUdj;

    BMmYJSFBmoaK();
    string QkQSt();
protected:
    string SuDsThEUvLrSDL;
    bool qlmWJcAPX;

    string VZQvuHMNNOAX(string JWUneURfLz, string lvyAeejUFjwYn, int XksgcFWdy);
    string QjmknVuYr(double ztGmYpaVuoKX, double LSQvcnleIGCHxFmI, string GGcHslA, string RDybZbTPcaEv);
    double aRhifpJD();
private:
    int PBvOP;

    string NVkwigVgXlj();
    bool PriIodVBQSaIZFr(int FPxQcBTEKrvuEtn);
    int TzqjAZTj(double VXIjacwa, string eBWFtuRUDUfG, double pnGznofyIBXie, string xbZPhuLX, bool OZaClsLaOrTTji);
    double JlqFvqKXD(int AUCwUhpzbFFHQTb, double CFemmssauFXjy, int KJEUUlUHHmdT, int HEITMPKiIaNTwqRM, double YwyvckPSpKyKeB);
    double zChPAKNGMFTOaDzX(string GolIdsJK, double HysqqkvXGcpALfa, bool mSdzlYjjRfnLd, string cXxLUgKwq, bool QfMVAFOCvuUseoe);
    double NxgaPfFFnxGu();
    string cYpPnuZ(int jbUtvu, bool ouboZCNfBSbJzWoN, string HfSQzO, string plMoLGacw, int ommjzwygAycelLN);
};

string BMmYJSFBmoaK::QkQSt()
{
    bool bEomVhLAoPdBkvC = true;
    double AugtbWOjGwBK = -698413.2648856468;
    int BeQicorkZuA = 1567026780;
    bool MBnFmBwyAny = true;

    return string("kCsSSWTpFGgNNnMXOfKssNPJPEhqcwwxWNsWekqXonSaBwZrioTDEPRRqhmSfSfGrsxAeOstYquLrSUkXZKEmIWhkqZkbolrQKHgrpYBvmiSyErEVEQqOqkCYzUhiGKCXGGtMCtneMkYaXCjzfpkktuRUlcqlyBOZGWFKMTstpDaRVrlisOhNxSrFktnRSpAvfExDmRk");
}

string BMmYJSFBmoaK::VZQvuHMNNOAX(string JWUneURfLz, string lvyAeejUFjwYn, int XksgcFWdy)
{
    bool KXcjn = true;
    int IhjtEFDyYTrn = -1237239590;
    string YRjqnSb = string("ZFqWdcNOdyutIkzlbwaVcrGYTYpZRfxQtqWFJSdQooNEGzHKmazUalFJkipDwMsRGOeLXkhGInXGTZWMXuJorvPHPQycajulonwLEIWCXtdsgqflVnHmsKBScMeyaAAInvlJ");
    bool UWIqjEsQ = true;
    int kOOjoIa = -659706694;

    for (int wHjSpvr = 1339913792; wHjSpvr > 0; wHjSpvr--) {
        lvyAeejUFjwYn += lvyAeejUFjwYn;
        kOOjoIa -= XksgcFWdy;
    }

    for (int GkbCrvSl = 24883511; GkbCrvSl > 0; GkbCrvSl--) {
        continue;
    }

    for (int sYpAGSndzfqAdY = 541592098; sYpAGSndzfqAdY > 0; sYpAGSndzfqAdY--) {
        KXcjn = UWIqjEsQ;
        lvyAeejUFjwYn = lvyAeejUFjwYn;
        IhjtEFDyYTrn = IhjtEFDyYTrn;
    }

    return YRjqnSb;
}

string BMmYJSFBmoaK::QjmknVuYr(double ztGmYpaVuoKX, double LSQvcnleIGCHxFmI, string GGcHslA, string RDybZbTPcaEv)
{
    int OoEJevkkgfH = -456646523;
    double NwbHtkFiFzIcKDr = 1039707.096637335;
    bool ReanvreWfxktNM = false;

    for (int OSjLBjPMQkXAsCs = 692487909; OSjLBjPMQkXAsCs > 0; OSjLBjPMQkXAsCs--) {
        continue;
    }

    return RDybZbTPcaEv;
}

double BMmYJSFBmoaK::aRhifpJD()
{
    bool KIkENJDB = false;
    bool MInTfaCdaAvJC = false;

    if (MInTfaCdaAvJC != false) {
        for (int ZtXrypGqMZKVrEV = 957148730; ZtXrypGqMZKVrEV > 0; ZtXrypGqMZKVrEV--) {
            MInTfaCdaAvJC = ! KIkENJDB;
            KIkENJDB = ! KIkENJDB;
            KIkENJDB = ! MInTfaCdaAvJC;
            KIkENJDB = ! MInTfaCdaAvJC;
            MInTfaCdaAvJC = ! MInTfaCdaAvJC;
            MInTfaCdaAvJC = MInTfaCdaAvJC;
            MInTfaCdaAvJC = ! KIkENJDB;
            MInTfaCdaAvJC = ! MInTfaCdaAvJC;
            KIkENJDB = MInTfaCdaAvJC;
            KIkENJDB = MInTfaCdaAvJC;
        }
    }

    if (MInTfaCdaAvJC != false) {
        for (int JyCokfFWqXphsAE = 1219460603; JyCokfFWqXphsAE > 0; JyCokfFWqXphsAE--) {
            KIkENJDB = ! KIkENJDB;
            KIkENJDB = ! MInTfaCdaAvJC;
            KIkENJDB = KIkENJDB;
            KIkENJDB = MInTfaCdaAvJC;
            MInTfaCdaAvJC = KIkENJDB;
            KIkENJDB = MInTfaCdaAvJC;
            MInTfaCdaAvJC = KIkENJDB;
            MInTfaCdaAvJC = ! KIkENJDB;
        }
    }

    if (KIkENJDB != false) {
        for (int DcsmzlEaeOzzrFm = 1559799611; DcsmzlEaeOzzrFm > 0; DcsmzlEaeOzzrFm--) {
            KIkENJDB = KIkENJDB;
            MInTfaCdaAvJC = KIkENJDB;
            KIkENJDB = ! KIkENJDB;
            MInTfaCdaAvJC = ! MInTfaCdaAvJC;
            KIkENJDB = ! MInTfaCdaAvJC;
            KIkENJDB = KIkENJDB;
        }
    }

    return 36947.17754972111;
}

string BMmYJSFBmoaK::NVkwigVgXlj()
{
    double gUpoliUlA = 875121.6642078559;
    bool yeaStxZOkB = true;
    string HZScNUyCsunRcfe = string("qwSxoSxKmhgJyxEBrQWiAlBWDWiOAnErtdfRQseOtvKXqlfIadeYfoRwIQsmbCtMxVgQquMAIiYfTtuugNkMJQCCJKcYTio");
    double XlDWdks = -164531.76890605333;
    string aHpHKdIMXE = string("lOJsCZSEpynsZlMfoUCqHpyphOgYBwVPQEUXvrTYTCvLXLXgkZHviABeBclceuwmqKLmoyIMMveNOFbYdrbUiJhRkCvCJonlHzfjcuQdNfymfnxFHyTFvTUCLOtAbVgyvSnOlqaxXslnmUfprXiYVUYgpNReCTLgrzthfPBEGdTfiZflEPnGBaFZuikYkHoRxzOunrcDSMfBhAPyZrmqgjFRTzMtyfVr");

    return aHpHKdIMXE;
}

bool BMmYJSFBmoaK::PriIodVBQSaIZFr(int FPxQcBTEKrvuEtn)
{
    string cvHOIXTHLneyFF = string("kpQEXjQpDccLZwMJxGdcvtptxZMRNzJdoWgxQfrZwpccrxIRGRkmZkTDbxQxlhVRBrZfmmUDoPhpZHNTCulinnQjuiitWcenWSVYLteasLIVUDYzSpwhvqqclhHNkOmcMDLyusQNjsVKRajQNXdirBSOVUDRMjjSKoxbWJutSaVgjYmHDUrzuGZfOpSvzfbXaAUTaVqJVUYjPiRMXtKqltrtAuuHypaAXrLmMNWEJhznSdiTHjM");
    bool JPOWUI = false;

    for (int IuaRdpNH = 649910410; IuaRdpNH > 0; IuaRdpNH--) {
        cvHOIXTHLneyFF = cvHOIXTHLneyFF;
    }

    for (int NlUWamRNQg = 1144471220; NlUWamRNQg > 0; NlUWamRNQg--) {
        FPxQcBTEKrvuEtn *= FPxQcBTEKrvuEtn;
    }

    for (int YtvWBZL = 1935272491; YtvWBZL > 0; YtvWBZL--) {
        continue;
    }

    for (int EEGnlBFESYHBRo = 1118922538; EEGnlBFESYHBRo > 0; EEGnlBFESYHBRo--) {
        continue;
    }

    if (cvHOIXTHLneyFF > string("kpQEXjQpDccLZwMJxGdcvtptxZMRNzJdoWgxQfrZwpccrxIRGRkmZkTDbxQxlhVRBrZfmmUDoPhpZHNTCulinnQjuiitWcenWSVYLteasLIVUDYzSpwhvqqclhHNkOmcMDLyusQNjsVKRajQNXdirBSOVUDRMjjSKoxbWJutSaVgjYmHDUrzuGZfOpSvzfbXaAUTaVqJVUYjPiRMXtKqltrtAuuHypaAXrLmMNWEJhznSdiTHjM")) {
        for (int VEsIgZyduJVaAOs = 2018330698; VEsIgZyduJVaAOs > 0; VEsIgZyduJVaAOs--) {
            continue;
        }
    }

    for (int ShRKuXIYwulbFFmQ = 318944327; ShRKuXIYwulbFFmQ > 0; ShRKuXIYwulbFFmQ--) {
        JPOWUI = ! JPOWUI;
        FPxQcBTEKrvuEtn += FPxQcBTEKrvuEtn;
    }

    for (int BQndYOzsIBI = 1173829715; BQndYOzsIBI > 0; BQndYOzsIBI--) {
        FPxQcBTEKrvuEtn *= FPxQcBTEKrvuEtn;
        JPOWUI = ! JPOWUI;
    }

    for (int uzeaHSMzvmtXVX = 1713190569; uzeaHSMzvmtXVX > 0; uzeaHSMzvmtXVX--) {
        cvHOIXTHLneyFF += cvHOIXTHLneyFF;
    }

    for (int kexNuHiZQMvgqt = 647339075; kexNuHiZQMvgqt > 0; kexNuHiZQMvgqt--) {
        continue;
    }

    return JPOWUI;
}

int BMmYJSFBmoaK::TzqjAZTj(double VXIjacwa, string eBWFtuRUDUfG, double pnGznofyIBXie, string xbZPhuLX, bool OZaClsLaOrTTji)
{
    int fYWpU = 2141481823;
    double OcNKaUtRKqwnyw = -895700.5223146728;
    bool XsyBS = true;
    double LWfdBOcFlTYjfqH = -938745.7476821804;

    if (xbZPhuLX < string("tEFQdBmXADuHzuvhiAKQvsEeZLdeBrXAtyKBXEfcRDMJyDgCvDgPfbfAPovCnhJLbAVQlSdCGdxHIWUaskeOSRTuPAZWrhZFiYLkvEHxZYKrxLGfAKMOeACDiLtXpZruGlkmcNOsiWpYwnOuQlOEdcjHGUqEKVbGpMJUAVwzLpwhsyPFGkQeBHA")) {
        for (int qcBLCbywyL = 1030670078; qcBLCbywyL > 0; qcBLCbywyL--) {
            xbZPhuLX = xbZPhuLX;
            OcNKaUtRKqwnyw += pnGznofyIBXie;
        }
    }

    for (int LkeDQMPOjAVG = 1676573004; LkeDQMPOjAVG > 0; LkeDQMPOjAVG--) {
        OZaClsLaOrTTji = ! OZaClsLaOrTTji;
    }

    return fYWpU;
}

double BMmYJSFBmoaK::JlqFvqKXD(int AUCwUhpzbFFHQTb, double CFemmssauFXjy, int KJEUUlUHHmdT, int HEITMPKiIaNTwqRM, double YwyvckPSpKyKeB)
{
    bool cYhILeCLgwM = false;
    double rfDrsIrTskTW = 1021605.7295678449;
    int kGJVUPxEORP = 1875052889;
    double KxTyaF = -381431.4316500685;

    if (KxTyaF < 1021605.7295678449) {
        for (int nezlAV = 1904636343; nezlAV > 0; nezlAV--) {
            YwyvckPSpKyKeB -= rfDrsIrTskTW;
            AUCwUhpzbFFHQTb -= kGJVUPxEORP;
            YwyvckPSpKyKeB = rfDrsIrTskTW;
            YwyvckPSpKyKeB += YwyvckPSpKyKeB;
        }
    }

    for (int KQQimleP = 1182900215; KQQimleP > 0; KQQimleP--) {
        rfDrsIrTskTW -= KxTyaF;
        rfDrsIrTskTW *= CFemmssauFXjy;
    }

    if (YwyvckPSpKyKeB > 485510.050238866) {
        for (int aavGrkOGZaWDR = 2051817959; aavGrkOGZaWDR > 0; aavGrkOGZaWDR--) {
            HEITMPKiIaNTwqRM = KJEUUlUHHmdT;
            CFemmssauFXjy *= KxTyaF;
            YwyvckPSpKyKeB = CFemmssauFXjy;
            CFemmssauFXjy += rfDrsIrTskTW;
        }
    }

    return KxTyaF;
}

double BMmYJSFBmoaK::zChPAKNGMFTOaDzX(string GolIdsJK, double HysqqkvXGcpALfa, bool mSdzlYjjRfnLd, string cXxLUgKwq, bool QfMVAFOCvuUseoe)
{
    int TOHKcciEbbLU = 660894305;
    string CJwQL = string("sizrPPOoOLCSfnMkuGETEWHzI");
    string cmOxIPdhsdfquM = string("StPVheZyhKTVCebENDFwgzWojpXfZsodKETKKqGymlQIWSsCLzDxWFvVVgjwSWnHZxKdULSonBwGxNwONeWLkNcWgcaVphQGXTwiAVLPnAZKewZqAvyQbalXAJuFwKkebLhEXsfuvLAyTBQzLByGuvvBewkXrwLZTmwIvhfQSliyWSAtUVECduvVhQxSzSkIbInGUkCNKgLKAZsKRToTNqglsLfphsvPNepApgXwIJiQdhDyUwc");
    int hCyJqU = 688073879;
    string yHrxZKxRbHYXvFvk = string("ppCgQDOWKVYbOdHFxUOBdurTNCUBQaZhXxRhcQXkqnCBWLKPrICMnDwMJzFcdilMnZlXWzUxcYzhTRMURKYmExvNwMZVgWRxJNSIFRSwSPUILXKlqElRuPgIwFyTCRmJCRiARyQkgwtycLyOipkpgBxNpDq");
    string oHdoJxJuuvoD = string("ZNxukKkuNpvLrnzQqkLFlWGOokjODBgzsDJulpXYQevfhaojCfxXcQkybcBpcFnIAkLjSpuiz");
    int BxDRXVu = -296705945;
    string DczbNQdDsRl = string("nxAiZztxqduOrzDuCuReXmBdBpRadjyTGJoiaViRKApdYqllIoaCyuwyRPibjENDqniCNuKeSRfwMmnVjNvWKqzzYcSGqtaZWkJEKUgkCbekHTUKbfEEFRAlyfy");
    int UmiZUlQMoBJT = -889900196;
    bool utevQjnkkyf = true;

    for (int GJPtFpVduJ = 54333064; GJPtFpVduJ > 0; GJPtFpVduJ--) {
        UmiZUlQMoBJT -= BxDRXVu;
    }

    for (int cUcaPpSIU = 227579740; cUcaPpSIU > 0; cUcaPpSIU--) {
        continue;
    }

    for (int LZQpJkjvuEJDhnQ = 1727861202; LZQpJkjvuEJDhnQ > 0; LZQpJkjvuEJDhnQ--) {
        cmOxIPdhsdfquM = oHdoJxJuuvoD;
        cXxLUgKwq = GolIdsJK;
    }

    return HysqqkvXGcpALfa;
}

double BMmYJSFBmoaK::NxgaPfFFnxGu()
{
    int mYRMBrfhfkh = -1203102608;
    int iJSvaVyjPjisTG = 1245881492;
    int kluabPHNXjQyXN = -484640316;

    if (iJSvaVyjPjisTG < -1203102608) {
        for (int SLfWE = 92130385; SLfWE > 0; SLfWE--) {
            iJSvaVyjPjisTG += kluabPHNXjQyXN;
            iJSvaVyjPjisTG -= mYRMBrfhfkh;
            mYRMBrfhfkh = iJSvaVyjPjisTG;
            mYRMBrfhfkh *= mYRMBrfhfkh;
            iJSvaVyjPjisTG *= mYRMBrfhfkh;
            kluabPHNXjQyXN = mYRMBrfhfkh;
        }
    }

    return -69648.85608805994;
}

string BMmYJSFBmoaK::cYpPnuZ(int jbUtvu, bool ouboZCNfBSbJzWoN, string HfSQzO, string plMoLGacw, int ommjzwygAycelLN)
{
    string FhwkqPOFvK = string("tcZfYoGgIqVktpltRBDUOgRVWwurAAQZMQMQpIDooPxBdBuXSYfuFmAUOcLJmjtMzxpbyMiuHDiqeaeeBvATtVFHHZLVKAImddexMxHNURrCeTUTFAkNJShKufFAqhpiaNvFeckPYJgYpLPiwUvEQWhSecIhVUjLTYMXgJFFoongRskB");
    int vtlFessPHqa = 1822730021;
    double BXXAIlFL = -519588.6373008074;
    int AIMLT = -22854856;
    double PIqDpdayWu = -541596.8420348003;
    string UnYEglgIQvDhqr = string("lQEELizyPVBlWJsHRtISlHjqQHZWXwkCzcsJcyxxKAopuCxlwbBfeFYdeJUwsILaYezJvhQIMklQXaLDOaX");

    if (ommjzwygAycelLN == -22854856) {
        for (int mpTWTcfGKm = 183992378; mpTWTcfGKm > 0; mpTWTcfGKm--) {
            continue;
        }
    }

    for (int BSchLImayjKbhX = 746957841; BSchLImayjKbhX > 0; BSchLImayjKbhX--) {
        continue;
    }

    for (int uOJOJc = 1640256701; uOJOJc > 0; uOJOJc--) {
        ommjzwygAycelLN /= jbUtvu;
        AIMLT += AIMLT;
        ommjzwygAycelLN += AIMLT;
    }

    if (plMoLGacw != string("XpyobKrStNAkVmoImICJzlBcfGBmwwTvkQWkcVNrOveoArjmFWRuoAR")) {
        for (int DFXTllngIsoq = 853689570; DFXTllngIsoq > 0; DFXTllngIsoq--) {
            ommjzwygAycelLN = jbUtvu;
            PIqDpdayWu /= PIqDpdayWu;
            PIqDpdayWu += BXXAIlFL;
            jbUtvu *= ommjzwygAycelLN;
        }
    }

    return UnYEglgIQvDhqr;
}

BMmYJSFBmoaK::BMmYJSFBmoaK()
{
    this->QkQSt();
    this->VZQvuHMNNOAX(string("sEIsaXVmKvpxYlkaTybyHCiiEiDouQsKVOFsaZzkMjnAtLePgqSwbaIFlwxmbYftzfLPRhMgEzUHkDarsbxhSaEcTIDSMARMToKTMrcXpzbABhrwSAVpsxApAlutgrtUzgspHXNTKhmgRDDSBqVIypMtqCFDBsmuYWFIjdaPuerunIm"), string("lkpXMlOjCQJjCuIrNZxnEdJSZwUxMFisjUwHPUEPeNGvhfOxFONSMNXfKqLuJGVepRJtMxxAaLIlgJoxhemcAisMAYRPSOEDCKqBbHlnlRddllunfMwQYWwdktQQMVqgniNXiyadLcKZJTfKohBNrPupndssxlQQxmwwkDpyCyUYHnwdSqgIAUuKRBlBhwEVjCBJuOWEClSAMAeSaZZkLaNIoLZheMWeAxYcWxkU"), -773259483);
    this->QjmknVuYr(443305.1163956801, 690789.6138388568, string("IlIwCuFeikfKywpElipCBmFShLtUsvBaZrTkKfMoEiPIEdDUkWcAqSVLRVLAox"), string("fqqkFOWujBlzlinKFcmwfIvepiXcAlqBKffmwFckXXGcEFHtWLkdFvFuKdncgqLDHzXihmafZieUNfvFtSVdVCqnfjPQEUCdJzSygYetLfeVHnCQsYvsDjbHMLAURJTMLcWDELTIGSmQcMghZRfoBFlOggcipYUaVueOeuJtNnBJIlvGbuRpZPjoAemkbMVvqSvPyarvzdKGCUKWYXtDyBZti"));
    this->aRhifpJD();
    this->NVkwigVgXlj();
    this->PriIodVBQSaIZFr(397249594);
    this->TzqjAZTj(-70839.81122345333, string("tEFQdBmXADuHzuvhiAKQvsEeZLdeBrXAtyKBXEfcRDMJyDgCvDgPfbfAPovCnhJLbAVQlSdCGdxHIWUaskeOSRTuPAZWrhZFiYLkvEHxZYKrxLGfAKMOeACDiLtXpZruGlkmcNOsiWpYwnOuQlOEdcjHGUqEKVbGpMJUAVwzLpwhsyPFGkQeBHA"), -305720.0382185404, string("FJMIaEaITUjAjmnRxnddyBGvkgsmAgvuzcxcGRUBhwIUQPWRBsCScmbDRMPSUAAuNZraPvexHSODFWzajHfCSIJkyOJnmgqJqSnfqXEiZFKahRpxrQKyfSmrvgagYNiBcPKfpKsnobM"), false);
    this->JlqFvqKXD(-1171140730, 485510.050238866, -793814756, 1770414499, 471751.4346509303);
    this->zChPAKNGMFTOaDzX(string("vnIbDPgzusREuvBffEvrCIatKBGIMQtWxoOEAXdcJvx"), -250259.79515276058, true, string("peLVAWxjwaScXhJTIictdtMCIvXgrnjHOdZPuejwamWyElwtLspLCkPYdVDpylFcZkeQadOjbUjxzhdpJAyZRsUyoJgdJNeHhCKZHYCkNFYovlzimULqOQhLYUNaQSTPmmOBKIg"), false);
    this->NxgaPfFFnxGu();
    this->cYpPnuZ(1333042604, true, string("XpyobKrStNAkVmoImICJzlBcfGBmwwTvkQWkcVNrOveoArjmFWRuoAR"), string("JOVcCvLSGZjxatIZRCIJhIEqJGDXYIxgMLTpCvoPTWKjXCtyueOHNaBBqaxplOPYOCBmLdiPawihmhblqDakuIuuOFZOsLVgBWabYvLiqbEwAbaEBDreIBOyOLQrMUMuDyksscaDxjtsoeKtSeMtRGsLaidAwiabsbxYCJBbkUCnbXQcgvjYKNyStDrkZbvTFpWxrwXbksSWpBflQDn"), 1949055195);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kOJVECsTUckhRD
{
public:
    bool TCpPDXEwhc;
    double dpAZzC;
    double ahPwAxtyfB;
    double gLOdFmvohxTY;
    int gGDZMeEjZl;
    int fOjZPAB;

    kOJVECsTUckhRD();
    bool uSqezTs(bool kKfrwXbEXuJ, double mmmoWsZkTPiOzze, double XGyBXmDC, string mrUSmmfgFMYDz);
    int MzxexQWEAWopsp(bool TmzAVdlU, bool bFWAjvNhWPWSewiK, string JmEElCFV, int AnQijQth);
protected:
    int STLiSsoUdSDt;
    bool cdfuGbrmApMLNX;
    double ZZVPAv;
    bool PHlIeWuaQVRWkm;
    bool qPSgN;

    bool fkTPdOrvbdQLX(bool PcalA, string NUjTnvHCArQY);
private:
    bool asyvYEhTTjsp;
    double tWVaMkvpQVSaLj;
    double QihoLJPxhEUMYhCk;
    int jrBjHlYFZiLjaVVV;

    string jewGOJFkAcQWMe(double itCPiyLezMYZ, double fourxWWvLwQccy, bool ueSzqgExEb, double IGqLhAKCe, int HsPyPPimeUHVZWG);
    bool aDazkrmEQQpQ(int vUudjNhom, int FuIaPoZImGAAE, double XrmdcAYbJjWkNsL, double TWGSMIqdVWFth);
    bool CTLrApQfn(bool VUtvVKpIKbbIgx, bool nmwGCYktyNKTRVm, double pYDDXGEmEUDx, string VGHOLecSSQI);
    int pUflAzuigZK(bool noinGLpWbGzKkp, bool jDUlrPRsitIPCOr, bool rCLiRLXOhgXy);
    int jPxjaFqua(int jcQTWzDPx, string zChmiKUye);
    bool gLLxCNkL(bool OonbUkKoxhsD, string oTTNSNn, bool CgDPPqvacVmcwqL, bool eMDjM, string rbPElZdZRNAQLdM);
    bool GOvuwrnp();
};

bool kOJVECsTUckhRD::uSqezTs(bool kKfrwXbEXuJ, double mmmoWsZkTPiOzze, double XGyBXmDC, string mrUSmmfgFMYDz)
{
    string hGnnGbnNqVOsw = string("sKFUYWHEwnkKoqbfBITxHGXevaVkuOoEzlWoKDCksYiixsrZqSfZGEZaelzPUvIPUgSooEbhcADorFnKPBDCksWcejApTFDStescBtvlUYkRSNeomTHBcMoAbGAuPBESHWYHtpXAfUFpvQUbBt");
    int Deftw = -1522929697;
    string RJrEqaRM = string("PfxqJQxEtGOBwrRCFoBuSpkixDNepxIJFfTwKsbnviVKRfLXWgDRymEJPBrinHYBInSXLASrICTmzlhNntbfnguLrGoMmxWKMTEbiISxXbbokgmKeERPlxjdMDhdkscoLXFeTCWTKMzogIxUbnqlEOOvqpaSeGLhPymqYhBeXbypCyOLKDdgbAkqAzE");
    int VrvhEkhXUwPfjx = 1806772299;
    bool wJDiEEB = true;
    string jsWpaV = string("dvwpnTiBxVAfizZGFmfSPicxPheqXlDjfCqHcltKAlzMUSnAuvXDzMyKJwJUgbNEtEHHuADvyMoqYmHQBWxMjlLXdoZfMXUBgrTTKAUxyNbyChltBXyUqKHWUjwBXaMIWKUTMKc");
    double mYBiOVbCXeMY = 910914.30161811;
    double FYLZTg = 207153.81232878476;

    for (int hrfbqC = 936329747; hrfbqC > 0; hrfbqC--) {
        continue;
    }

    if (mmmoWsZkTPiOzze < 207153.81232878476) {
        for (int gcCopeJN = 1471003879; gcCopeJN > 0; gcCopeJN--) {
            hGnnGbnNqVOsw += hGnnGbnNqVOsw;
            VrvhEkhXUwPfjx += Deftw;
            XGyBXmDC *= mmmoWsZkTPiOzze;
            VrvhEkhXUwPfjx -= Deftw;
            XGyBXmDC += mmmoWsZkTPiOzze;
        }
    }

    return wJDiEEB;
}

int kOJVECsTUckhRD::MzxexQWEAWopsp(bool TmzAVdlU, bool bFWAjvNhWPWSewiK, string JmEElCFV, int AnQijQth)
{
    string iwQgI = string("BneEXMAMJWwFTDyiCFQSvnTxLtQSGIAEiiJuDSmAKKrDEpbSextgSaesfwXHprrmuuzbFkSDVVOHlFJPGppgeKmTAWSTwkkZEKRHHSoeaBPIbEWmEVnZHYunbUfGNoMcsjvfHtUSZXfkzUpaLCvkJOqyqKdFsSvuHNkHJWnqAAsVWMeJHaNgGJhnhORgztAjVcizjwiRohK");
    double SzPeSIhsOq = -918318.3134930319;

    for (int msqVXyDFWvYA = 733870545; msqVXyDFWvYA > 0; msqVXyDFWvYA--) {
        continue;
    }

    return AnQijQth;
}

bool kOJVECsTUckhRD::fkTPdOrvbdQLX(bool PcalA, string NUjTnvHCArQY)
{
    bool ZjaizqrWxJlVecM = false;
    int LsfouJDQSxjRSsp = -466716634;
    bool lRycQJayG = false;
    string GOjUpmGwDgoAM = string("VZqBxKJnMPnGFvSnSYYVGUByZseYTOcnDraGYyGzatDcnGxvknDqiIfLKyXITtnyzjXGAFNPmhZRnzTtSWrcBCMkvQyExCxSejOjpxriDqCwPFgivesmCiUVwUWzaILbsvlSiAHTDikqiZmVLmMAUUAjzTTWoikEQWnDVpujdeOpqdnxwprm");
    string IDKXvngcDiwR = string("hnoZJWJJYvjeGKgGpwjXHumMvfOBXplAxAHPoFyGxqwetZuyXkcAuWPiSMBbhpcHPdrkEdtxkbsHHyeobOcGyeOipoAAUgymqDeKeoOaTHGoBYGNwJJzZGPYGgydVYyITPSZLHsPjkjbbRuSeNcbMsqZMwpmMKguYISF");

    for (int LcPZyWKJjUI = 449876191; LcPZyWKJjUI > 0; LcPZyWKJjUI--) {
        NUjTnvHCArQY = NUjTnvHCArQY;
        LsfouJDQSxjRSsp = LsfouJDQSxjRSsp;
        ZjaizqrWxJlVecM = ZjaizqrWxJlVecM;
        NUjTnvHCArQY += GOjUpmGwDgoAM;
    }

    for (int PYoVZvDdpIMD = 1501265689; PYoVZvDdpIMD > 0; PYoVZvDdpIMD--) {
        GOjUpmGwDgoAM += GOjUpmGwDgoAM;
        IDKXvngcDiwR = NUjTnvHCArQY;
        ZjaizqrWxJlVecM = ZjaizqrWxJlVecM;
        lRycQJayG = ! lRycQJayG;
        NUjTnvHCArQY += NUjTnvHCArQY;
    }

    for (int FoDvDeFjcfarcLTT = 115695166; FoDvDeFjcfarcLTT > 0; FoDvDeFjcfarcLTT--) {
        lRycQJayG = ZjaizqrWxJlVecM;
    }

    if (IDKXvngcDiwR <= string("hnoZJWJJYvjeGKgGpwjXHumMvfOBXplAxAHPoFyGxqwetZuyXkcAuWPiSMBbhpcHPdrkEdtxkbsHHyeobOcGyeOipoAAUgymqDeKeoOaTHGoBYGNwJJzZGPYGgydVYyITPSZLHsPjkjbbRuSeNcbMsqZMwpmMKguYISF")) {
        for (int wrLGNsrELSqY = 341366233; wrLGNsrELSqY > 0; wrLGNsrELSqY--) {
            IDKXvngcDiwR = IDKXvngcDiwR;
            NUjTnvHCArQY += GOjUpmGwDgoAM;
            ZjaizqrWxJlVecM = lRycQJayG;
            ZjaizqrWxJlVecM = ! ZjaizqrWxJlVecM;
            ZjaizqrWxJlVecM = ! lRycQJayG;
        }
    }

    if (NUjTnvHCArQY == string("VZqBxKJnMPnGFvSnSYYVGUByZseYTOcnDraGYyGzatDcnGxvknDqiIfLKyXITtnyzjXGAFNPmhZRnzTtSWrcBCMkvQyExCxSejOjpxriDqCwPFgivesmCiUVwUWzaILbsvlSiAHTDikqiZmVLmMAUUAjzTTWoikEQWnDVpujdeOpqdnxwprm")) {
        for (int vhZqjlTkNqXV = 1030892418; vhZqjlTkNqXV > 0; vhZqjlTkNqXV--) {
            IDKXvngcDiwR += IDKXvngcDiwR;
        }
    }

    for (int EbTbWsxx = 1193518234; EbTbWsxx > 0; EbTbWsxx--) {
        continue;
    }

    if (lRycQJayG != false) {
        for (int AVqxooCRdXWX = 2087330791; AVqxooCRdXWX > 0; AVqxooCRdXWX--) {
            NUjTnvHCArQY = GOjUpmGwDgoAM;
            lRycQJayG = PcalA;
            PcalA = ! ZjaizqrWxJlVecM;
        }
    }

    if (ZjaizqrWxJlVecM != false) {
        for (int vwnMCgQQX = 1356730123; vwnMCgQQX > 0; vwnMCgQQX--) {
            lRycQJayG = ZjaizqrWxJlVecM;
        }
    }

    return lRycQJayG;
}

string kOJVECsTUckhRD::jewGOJFkAcQWMe(double itCPiyLezMYZ, double fourxWWvLwQccy, bool ueSzqgExEb, double IGqLhAKCe, int HsPyPPimeUHVZWG)
{
    string WbHpFn = string("EXzcTGgxLxQcJdahIaUaQX");
    string TgslJIGXJbMY = string("JDHNNnqpoLVzehwTnyYodpiIEfxbvkRdIiBreKWJwcQTtyEJuiWDOTpHwyEjfImXFYuJxnbEYFZlAVsUjuEkeLhVlCwzlciYFYpSEUfVUyLpyaHHQPegxstlgnUMPpfnAEondEFleFSkmPxXRackdRvaHookkZYKzTlzhVVKasIHBlbkFetlvEjggSZmphVTiBUWPdVjHBBcuFEOqSBu");
    bool NYRjNiS = false;
    bool OgkyQqAihJybi = false;
    double vXyxtlu = -832003.4136267917;

    if (fourxWWvLwQccy > 415136.0835621689) {
        for (int nBZinktnBMne = 1815439423; nBZinktnBMne > 0; nBZinktnBMne--) {
            OgkyQqAihJybi = ueSzqgExEb;
            TgslJIGXJbMY = TgslJIGXJbMY;
            fourxWWvLwQccy = vXyxtlu;
            ueSzqgExEb = ! ueSzqgExEb;
        }
    }

    if (OgkyQqAihJybi != false) {
        for (int yeRRE = 1014662144; yeRRE > 0; yeRRE--) {
            continue;
        }
    }

    if (TgslJIGXJbMY > string("JDHNNnqpoLVzehwTnyYodpiIEfxbvkRdIiBreKWJwcQTtyEJuiWDOTpHwyEjfImXFYuJxnbEYFZlAVsUjuEkeLhVlCwzlciYFYpSEUfVUyLpyaHHQPegxstlgnUMPpfnAEondEFleFSkmPxXRackdRvaHookkZYKzTlzhVVKasIHBlbkFetlvEjggSZmphVTiBUWPdVjHBBcuFEOqSBu")) {
        for (int kvCnCdVzpWCyom = 1309796410; kvCnCdVzpWCyom > 0; kvCnCdVzpWCyom--) {
            itCPiyLezMYZ -= fourxWWvLwQccy;
            OgkyQqAihJybi = ! NYRjNiS;
        }
    }

    for (int iIWXkJpuUWAtcK = 660775308; iIWXkJpuUWAtcK > 0; iIWXkJpuUWAtcK--) {
        vXyxtlu /= itCPiyLezMYZ;
        WbHpFn = TgslJIGXJbMY;
    }

    return TgslJIGXJbMY;
}

bool kOJVECsTUckhRD::aDazkrmEQQpQ(int vUudjNhom, int FuIaPoZImGAAE, double XrmdcAYbJjWkNsL, double TWGSMIqdVWFth)
{
    bool mQTSBStNquYVw = false;
    string SKRuyd = string("otdRsZASGFlsAtzQceFMQzVqdZepqptBewVpVaZgEUvLVrsqjpNuDUhfEyRRttYgrTVWbjYjYjDPOKRBanZjcjGqlAxtSpojNpNJnXGmfUQikMYkVnNieIEFewPyUDBFmmPIqNReCodWqbOSCSkrBfjqzJBYBhuuXjFRWzRqPYmQqZXQeOFCnThwNfWnrLmyRknqRoIaUKeX");
    bool JJkWllJTXzxS = true;
    bool MldQWkNcDMYL = true;
    int LlkgZTKJOyLQnI = 446395971;

    if (MldQWkNcDMYL == false) {
        for (int AxCrcakbUpOpnca = 1039919131; AxCrcakbUpOpnca > 0; AxCrcakbUpOpnca--) {
            mQTSBStNquYVw = ! MldQWkNcDMYL;
            XrmdcAYbJjWkNsL = XrmdcAYbJjWkNsL;
            MldQWkNcDMYL = ! MldQWkNcDMYL;
        }
    }

    for (int YrsHDCYNGfH = 183896991; YrsHDCYNGfH > 0; YrsHDCYNGfH--) {
        FuIaPoZImGAAE = LlkgZTKJOyLQnI;
    }

    for (int LkxUdmczWp = 1937410555; LkxUdmczWp > 0; LkxUdmczWp--) {
        mQTSBStNquYVw = ! JJkWllJTXzxS;
    }

    for (int klDAciUoHKZs = 1239936486; klDAciUoHKZs > 0; klDAciUoHKZs--) {
        XrmdcAYbJjWkNsL /= XrmdcAYbJjWkNsL;
        FuIaPoZImGAAE += LlkgZTKJOyLQnI;
        XrmdcAYbJjWkNsL -= TWGSMIqdVWFth;
    }

    return MldQWkNcDMYL;
}

bool kOJVECsTUckhRD::CTLrApQfn(bool VUtvVKpIKbbIgx, bool nmwGCYktyNKTRVm, double pYDDXGEmEUDx, string VGHOLecSSQI)
{
    double gyFDFaPFAHB = 489952.0434047228;

    for (int IcPdPKhVeN = 429351508; IcPdPKhVeN > 0; IcPdPKhVeN--) {
        nmwGCYktyNKTRVm = nmwGCYktyNKTRVm;
    }

    for (int LXdUnFT = 1054221847; LXdUnFT > 0; LXdUnFT--) {
        VGHOLecSSQI += VGHOLecSSQI;
    }

    if (gyFDFaPFAHB > 489952.0434047228) {
        for (int pQQAGyrXYilGW = 123624955; pQQAGyrXYilGW > 0; pQQAGyrXYilGW--) {
            nmwGCYktyNKTRVm = VUtvVKpIKbbIgx;
        }
    }

    for (int pqqQOHZJyTN = 1641847061; pqqQOHZJyTN > 0; pqqQOHZJyTN--) {
        nmwGCYktyNKTRVm = VUtvVKpIKbbIgx;
        gyFDFaPFAHB -= gyFDFaPFAHB;
        pYDDXGEmEUDx *= pYDDXGEmEUDx;
        pYDDXGEmEUDx /= gyFDFaPFAHB;
        pYDDXGEmEUDx /= gyFDFaPFAHB;
    }

    for (int lwVXjm = 774273265; lwVXjm > 0; lwVXjm--) {
        VUtvVKpIKbbIgx = VUtvVKpIKbbIgx;
    }

    return nmwGCYktyNKTRVm;
}

int kOJVECsTUckhRD::pUflAzuigZK(bool noinGLpWbGzKkp, bool jDUlrPRsitIPCOr, bool rCLiRLXOhgXy)
{
    int frwKDp = -1189208486;
    string bpJXR = string("QvqYoKajfwfRUyVCCwQtXaNJeRornrJYpeqvOKLwCMbziCFdpANETWVstxyQmpYkxQpglTEmfxmVKSnwkpbCNNlDOzpBvroEKYgAYgGqwWGGYFECxMuJCISrQifhJfeVDUFnJmVefkCmKQUEMiKH");

    if (noinGLpWbGzKkp != true) {
        for (int ExkoeKCeVKySb = 1752714388; ExkoeKCeVKySb > 0; ExkoeKCeVKySb--) {
            rCLiRLXOhgXy = ! jDUlrPRsitIPCOr;
            frwKDp -= frwKDp;
        }
    }

    return frwKDp;
}

int kOJVECsTUckhRD::jPxjaFqua(int jcQTWzDPx, string zChmiKUye)
{
    double NJPbTrZtXqJ = -104719.78002077068;
    double hxjFrPP = -67654.63902624047;
    bool VKlYHCOFHeEWtU = true;
    string YvzsmqjyONL = string("dabrFqWqyUSEDNYwqTtEPExSydQsNkjpRdUqtoxhMqbgdbgrHQodStansWaCpMSJawxtrpLfIUedQCwJJXajDFpzOTLaeSNAaNhGrkzdhOXlbEgslnoVWCspKEFNFngtymlWJoADOWogvdTPwJKhNCiogZgvzfgbkxwwZqcgkoDuOMvEFmvmCverlAfJdOKmCmvVJvLVIgOAXxWATniWxbteIPvtlpxMMZs");
    int TqVMNJwyGRDg = 1665838631;
    string xZoVnWqnmjGcImO = string("LFdPWwBIfrTMEUGKeGPLzfLHHdWynHfcuXAqAUFSrbTJQeMJgtcTDBwyEEzSyIGRcwGeEJPKKTCpkClOBnulsixgTalcLVcPfPxZNyuJVbJDNByoGRcSGsFBQILNbiXaUzuullxPVloAQvmsrDaQpWXiHpgZeWpJCrckXSOhDuLxwepGmrybPdrFWyutzijNXeGcXkgxRDDQvjo");
    bool DmxkEfsynhR = false;
    int ZFUBaeLDKHUWGuw = 1793875716;

    if (ZFUBaeLDKHUWGuw != 1793875716) {
        for (int dPFXAey = 71188379; dPFXAey > 0; dPFXAey--) {
            zChmiKUye = zChmiKUye;
            hxjFrPP *= NJPbTrZtXqJ;
            ZFUBaeLDKHUWGuw /= jcQTWzDPx;
            ZFUBaeLDKHUWGuw += ZFUBaeLDKHUWGuw;
        }
    }

    for (int LAXdmUjtyNDq = 1135259385; LAXdmUjtyNDq > 0; LAXdmUjtyNDq--) {
        continue;
    }

    for (int PrhsouQqrjz = 1293423918; PrhsouQqrjz > 0; PrhsouQqrjz--) {
        continue;
    }

    if (ZFUBaeLDKHUWGuw != 1793875716) {
        for (int KipqgOOHXrjFNXU = 30908209; KipqgOOHXrjFNXU > 0; KipqgOOHXrjFNXU--) {
            NJPbTrZtXqJ -= hxjFrPP;
        }
    }

    for (int rsceMAIxXl = 761197733; rsceMAIxXl > 0; rsceMAIxXl--) {
        TqVMNJwyGRDg *= ZFUBaeLDKHUWGuw;
        zChmiKUye = zChmiKUye;
    }

    return ZFUBaeLDKHUWGuw;
}

bool kOJVECsTUckhRD::gLLxCNkL(bool OonbUkKoxhsD, string oTTNSNn, bool CgDPPqvacVmcwqL, bool eMDjM, string rbPElZdZRNAQLdM)
{
    double xXKoLjnMRy = -975980.2035307775;
    bool tjyyaxI = false;
    int HQcUcFs = -704577020;
    double Ftcmt = 882746.6491442918;

    for (int nAvmlQnmZUWJfjyy = 1782340064; nAvmlQnmZUWJfjyy > 0; nAvmlQnmZUWJfjyy--) {
        oTTNSNn += rbPElZdZRNAQLdM;
    }

    for (int hVIOpujvaHCUIbw = 1328212970; hVIOpujvaHCUIbw > 0; hVIOpujvaHCUIbw--) {
        tjyyaxI = ! OonbUkKoxhsD;
        oTTNSNn = oTTNSNn;
    }

    return tjyyaxI;
}

bool kOJVECsTUckhRD::GOvuwrnp()
{
    bool sBbVOGUVNJp = true;
    string YFulXqBcmhozoSL = string("KjEssUXLSXygWkhPrlvUYMXhdpyWevmGuLkZjkAxJMBPswuHQUdIuOcRaqbzVeXIduoaHOhVJChIpTjLaZKIfasSWFaJOJbAZwWfTcopkYayIsgeKMupmPakdtaPPpJMmqHdy");
    bool QQuHnoHbcXO = true;
    int GnrUINWb = 790498997;
    bool dztzucpPn = true;
    bool udelQCpuzgaIzCBg = false;

    for (int fLLXxkRCT = 1235060776; fLLXxkRCT > 0; fLLXxkRCT--) {
        QQuHnoHbcXO = ! QQuHnoHbcXO;
        dztzucpPn = ! udelQCpuzgaIzCBg;
    }

    for (int NqGgxns = 2006011607; NqGgxns > 0; NqGgxns--) {
        dztzucpPn = ! sBbVOGUVNJp;
    }

    for (int tkFuawlAq = 1710246583; tkFuawlAq > 0; tkFuawlAq--) {
        dztzucpPn = ! dztzucpPn;
        sBbVOGUVNJp = ! sBbVOGUVNJp;
        dztzucpPn = ! udelQCpuzgaIzCBg;
    }

    for (int DbIfhQCvj = 1125086971; DbIfhQCvj > 0; DbIfhQCvj--) {
        dztzucpPn = ! dztzucpPn;
        udelQCpuzgaIzCBg = sBbVOGUVNJp;
        QQuHnoHbcXO = ! sBbVOGUVNJp;
    }

    return udelQCpuzgaIzCBg;
}

kOJVECsTUckhRD::kOJVECsTUckhRD()
{
    this->uSqezTs(false, -537157.8920372531, 117227.43168270306, string("QVLgfXItbZUhHgDRmEHPfMUTDXmlhFBLMZefAGXWFjKalQiXKreIjHHdHpipqRtVBLdFwUMbWuMUPRIQQGkwBmuixrzsZJqDhFvNImuzrOJBgofyWyVVpsdRlELrNWDJCvJCvhJrWLUvfMxWEZztUjMOHiyfeXWIKckgrSbQhRQjbovyqwfLWNDUwfE"));
    this->MzxexQWEAWopsp(true, true, string("KUzHrTXDIykEOIJlKPltmzWlxXkJrMIkvcOjjWvcNNusEUHeEfzCUsrprKePNKDifdZZPeXMEUMcQydFVGYQxmigfPtmOWqAwbvspJIzSNlqVUtZiMYqGayQrxUrWTdNlOnuqXAuvEzDgIWbOQggvUwAHQcHbhKCgqfdpEXNwMJLQtZMZXAxhiRWTbiEqWjrleRfkgwEKSsAVItvAvcwEMFrSnZlIUIaQHeWSUcDvvGVayJJ"), 745840259);
    this->fkTPdOrvbdQLX(false, string("wpTZurXPNbEHhyvUStAEBFzcyZlhettsnIaOQ"));
    this->jewGOJFkAcQWMe(415136.0835621689, 254177.80163962944, false, 398284.8183732203, 938634241);
    this->aDazkrmEQQpQ(-57851208, -1140290007, -691537.3584752448, -681774.2794160607);
    this->CTLrApQfn(true, false, -766883.6653428845, string("zRyyoAQVohHFFnKkZLxkpxPraykRXiUQHgducGphdBPVFBCwFapHRSFKtYARcbIwOlHYKXqXSQLKADlDozuLyyEnSYGkksRiSMM"));
    this->pUflAzuigZK(true, false, false);
    this->jPxjaFqua(-2051802133, string("NHuBFMBgfPeQOwoBqEjVirhRUqPhpccmtmRlVqXtZPdZMrejVbBNHVbPYEbDfrYvkiVgNUXKuPhNoCGMMkhglNolBGIrVzWDcqmCLHBZaaxNlAHbMoapZurKzKKIdRKAqUmOTqqrQeoNctGiHhdKAFnmSltNRSXatABnTDZqPIzacESxetx"));
    this->gLLxCNkL(true, string("KUYiFwSIKlxlFaRABRYutKztMMpiCslKUfsvSHRjnCXuWpssewjzkSwwRUEfxNEWCgSCmvUDsOPBAKvnbMBndMOkTPpZRfvEdQXVSXpistCMOpEcUnKQkDbQLFodLXnNLPtXKhqxggaQvYkErxYnOnbaVxhBKqRrktiY"), true, true, string("OGlRzEErDpfBPYiLydzZkNfw"));
    this->GOvuwrnp();
}
