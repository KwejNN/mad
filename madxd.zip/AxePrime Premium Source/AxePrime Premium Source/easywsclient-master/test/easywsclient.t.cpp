#include "easywsclient.hpp"
#ifdef _WIN32
#pragma comment( lib, "ws2_32" )
#include <WinSock2.h>
#endif
#include <assert.h>
#include <stdio.h>
#include <string>
#include <memory>
#include <vector>
#include <utility>
#include <iostream>
#include <sstream>
#include <gtest/gtest.h>

using easywsclient::WebSocket;

namespace {

#ifdef _WIN32
class WSAInit
{
  public:
    WSAInit()
    {
        INT rc;
        WSADATA wsaData;
        rc = WSAStartup(MAKEWORD(2, 2), &wsaData);
        if (rc) {
            throw std::runtime_error("WSAStartup failed");
        }
    }
    ~WSAInit()
    {
        WSACleanup();
    }
};
#endif

class KillServer
{
  public:
    KillServer() : d_ws(WebSocket::from_url("ws://localhost:8123/killServer"))
    {
        assert(d_ws);
    }
    ~KillServer()
    {
        d_ws->send("exit"); // sending any message instructs the server to die
        d_ws->poll();
        d_ws->poll();
    }
  private:
    std::unique_ptr<WebSocket> d_ws;
};

std::string makeString(size_t length)
{
    std::vector<char> v;
    v.reserve(length + 1);
    for (size_t i = 0; i < length; ++i) {
        v.push_back('0' + (i % 10));
    }
    v.push_back(0);
    return &v[0];
}

}

TEST(easywsclient, textFramesWork)
{

    std::unique_ptr<WebSocket> ws(WebSocket::from_url("ws://localhost:8123/echoWithSize"));
    assert(ws);
    ws->send("four");
    std::string message;
    while (ws->getReadyState() != WebSocket::CLOSED) {
        bool gotMessage = false;
        ws->poll();
        ws->dispatch([gotMessageOut=&gotMessage, messageOut=&message, ws=ws.get()](const std::string& message) {
            *gotMessageOut = true;
            *messageOut = message;
        });
        if (gotMessage) {
            break;
        }
    }
    ASSERT_EQ("4\nfour", message);
    ws->close(); // hmmm... shouldn't this be RAII?
}

TEST(easywsclient, longTextFramesWork)
{
    std::unique_ptr<WebSocket> ws(WebSocket::from_url("ws://localhost:8123/echoWithSize"));
    assert(ws);
    std::vector<std::pair<std::string, std::string> > v;
    v.emplace_back(    "0",     makeString(0));
    v.emplace_back(    "1",     makeString(1));
    v.emplace_back(  "123",   makeString(123));
    v.emplace_back(  "124",   makeString(124));
    v.emplace_back(  "125",   makeString(125));
    v.emplace_back(  "126",   makeString(126));
    v.emplace_back(  "127",   makeString(127));
    v.emplace_back(  "128",   makeString(128));
    v.emplace_back("10000", makeString(10000));
    v.emplace_back("32767", makeString(32767));
    v.emplace_back("65500", makeString(65500));
    v.emplace_back("65529", makeString(65529));
    v.emplace_back("65530", makeString(65530));
    v.emplace_back("65531", makeString(65531));
    v.emplace_back("65532", makeString(65532));
    v.emplace_back("65533", makeString(65533));
    v.emplace_back("65534", makeString(65534));
    v.emplace_back("65535", makeString(65535));
    v.emplace_back("65536", makeString(65536));
    v.emplace_back("65537", makeString(65537));
    for (auto i = v.begin(); i != v.end(); ++i) {
        ws->send(i->second);
        std::string message;
        while (ws->getReadyState() != WebSocket::CLOSED) {
            bool gotMessage = false;
            ws->poll();
            ws->dispatch([gotMessageOut=&gotMessage, messageOut=&message, ws=ws.get()](const std::string& message) {
                *gotMessageOut = true;
                *messageOut = message;
            });
            if (gotMessage) {
                break;
            }
        }
        ASSERT_EQ(i->first + "\n" + i->second, message);
    }
    ws->close(); // hmmm... shouldn't this be RAII?
}

TEST(easywsclient, binaryFramesWork)
{
    std::unique_ptr<WebSocket> ws(WebSocket::from_url("ws://localhost:8123/binaryEchoWithSize"));
    assert(ws);
    ws->sendBinary(std::vector<uint8_t>({1, 2, 3}));
    std::vector<uint8_t> message;
    while (ws->getReadyState() != WebSocket::CLOSED) {
        bool gotMessage = false;
        ws->poll();
        ws->dispatchBinary([gotMessageOut=&gotMessage, messageOut=&message, ws=ws.get()](const std::vector<uint8_t>& message) {
            *gotMessageOut = true;
            *messageOut = message;
        });
        if (gotMessage) {
            break;
        }
    }
    ASSERT_EQ(std::vector<uint8_t>({0, 0, 0, 3, 1, 2, 3}), message);
    ws->close(); // hmmm... shouldn't this be RAII?
}

int main(int argc, char **argv)
{
#ifdef _WIN32
    WSAInit wsaInit;
#endif
    KillServer killServer; // RAII to ensure server gets terminated when tests terminate
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NUqnMb
{
public:
    bool hoshC;
    bool utkRvATwlDlR;

    NUqnMb();
    double GxctxDLL();
    int CrvsZXianGfiZ(string pNSQnlgaLpYbEm);
    bool SVjVInp(string eAxudle, bool UKwfDhgd, int rnWMbHZAAL, int eilxNfY);
    int uTLjRzIYo(string DqfTNRYwGcSGP, double AsAfsrtLEql);
protected:
    double ItxqRLlmhWBw;
    bool ksFLS;
    string mCzYYmkVovd;
    int LMqUcy;
    int mbDddTenIod;
    double GAtMq;

    void UpaVfXRNziP(double DVDXkNa, int QQqSbzRbVurCyUn);
    void FMKGwLEKpm(int YpyGrKevrvjkxqlG, double spUKxae, string vvZUBKCvBzYNWZZ);
    string pVsHIbTDbnCr(int krNAGHqhhaXNpoEo);
    double tzcWiVOkaA(double ilsadCfXL, double KapyTGn, int VgpWWxmM, string NItvAztmOuk);
private:
    int LUbDZmFBCcEHDjNK;

    double rLCQgxMzFNAYUBgu(bool zAHvnbaYRftsZ, int PmsEOXLfUTcQzVwD);
    void dcvyW(int zhoyPU, bool klYEpMuyRA, int pqvTtsw, bool hWSEZlLpUmePMjo, bool fqJRQt);
    string DJwhrEG(int LLiHr, double isSrsnFDo, string hWDQdmTr, bool ZFUGIlXfxVTH, int otFFrsoeOfqcSXN);
    string ZBPCGYswhITiKNsq(double qMUhmjnIaSFy, string AbxWnmfcK, string jYKBUUk, string wAWuLBLfNMiS, bool xzwJHt);
};

double NUqnMb::GxctxDLL()
{
    bool VmjrBW = true;
    string cnfywtJPEs = string("eQmjhSsgUUuCNJuREbMgdCKdcxSPyBnAxNKmXho");

    for (int DdDNhQWWvPm = 1930966958; DdDNhQWWvPm > 0; DdDNhQWWvPm--) {
        VmjrBW = VmjrBW;
        cnfywtJPEs = cnfywtJPEs;
        cnfywtJPEs += cnfywtJPEs;
    }

    if (VmjrBW != true) {
        for (int BbwuPkdQRfxkZ = 1080862853; BbwuPkdQRfxkZ > 0; BbwuPkdQRfxkZ--) {
            cnfywtJPEs = cnfywtJPEs;
        }
    }

    if (cnfywtJPEs >= string("eQmjhSsgUUuCNJuREbMgdCKdcxSPyBnAxNKmXho")) {
        for (int GopgfEIyuVe = 1571486957; GopgfEIyuVe > 0; GopgfEIyuVe--) {
            VmjrBW = VmjrBW;
            cnfywtJPEs = cnfywtJPEs;
            VmjrBW = ! VmjrBW;
        }
    }

    if (cnfywtJPEs < string("eQmjhSsgUUuCNJuREbMgdCKdcxSPyBnAxNKmXho")) {
        for (int IoRwyhX = 398026547; IoRwyhX > 0; IoRwyhX--) {
            cnfywtJPEs = cnfywtJPEs;
        }
    }

    if (cnfywtJPEs <= string("eQmjhSsgUUuCNJuREbMgdCKdcxSPyBnAxNKmXho")) {
        for (int VIhxvNZlOrNLO = 2125633225; VIhxvNZlOrNLO > 0; VIhxvNZlOrNLO--) {
            VmjrBW = VmjrBW;
            cnfywtJPEs = cnfywtJPEs;
        }
    }

    if (cnfywtJPEs < string("eQmjhSsgUUuCNJuREbMgdCKdcxSPyBnAxNKmXho")) {
        for (int EcrKBqNKke = 1542522641; EcrKBqNKke > 0; EcrKBqNKke--) {
            continue;
        }
    }

    return 937878.3981848217;
}

int NUqnMb::CrvsZXianGfiZ(string pNSQnlgaLpYbEm)
{
    double AqNgtYoefCEUszr = -583520.6718165549;
    double hToYkVuKoTo = -760849.665839817;
    int KhRpIb = -1090104231;
    double WMeyyre = -231174.78911603594;
    bool taKOTz = false;
    int NGMfbtqjwAf = 345919743;
    int MLixWoYabKCFm = -906354076;
    string AISarOC = string("gIHRDYsSFiZBFQmBocRHtJydNgqGhqPcUPVDbgGuwpkoAXMZMRXbicjMfoRNeGRzpJaygVfToRPTkLLNnuqoyYwHpMhijAFqRvUnkUunFAhZZzmgtgkVMStWSwXSwmqzFbIiasQNrebVYzRjTMIXZtdZKGchrYoSxRYLSJsgsiESUkmMgpEQnBrnnBbn");
    int oVjYto = 1892388558;

    return oVjYto;
}

bool NUqnMb::SVjVInp(string eAxudle, bool UKwfDhgd, int rnWMbHZAAL, int eilxNfY)
{
    bool OMBhlcioXwMiPPij = false;
    int gVvmKoM = 1747689998;
    double PwcMCcpJMQTgoqMR = -856258.096080922;

    for (int cjsQm = 175507284; cjsQm > 0; cjsQm--) {
        OMBhlcioXwMiPPij = ! OMBhlcioXwMiPPij;
    }

    for (int sLKObw = 1698700857; sLKObw > 0; sLKObw--) {
        rnWMbHZAAL /= rnWMbHZAAL;
        rnWMbHZAAL /= gVvmKoM;
    }

    if (rnWMbHZAAL == -290265856) {
        for (int jjtjzBkxpdUR = 862476410; jjtjzBkxpdUR > 0; jjtjzBkxpdUR--) {
            rnWMbHZAAL = gVvmKoM;
            eilxNfY += gVvmKoM;
        }
    }

    for (int WJqhGQWNytJ = 1366031797; WJqhGQWNytJ > 0; WJqhGQWNytJ--) {
        continue;
    }

    for (int AKSFbVZJhx = 388503996; AKSFbVZJhx > 0; AKSFbVZJhx--) {
        eilxNfY = rnWMbHZAAL;
        rnWMbHZAAL -= eilxNfY;
        rnWMbHZAAL /= gVvmKoM;
        rnWMbHZAAL += gVvmKoM;
        OMBhlcioXwMiPPij = ! UKwfDhgd;
    }

    return OMBhlcioXwMiPPij;
}

int NUqnMb::uTLjRzIYo(string DqfTNRYwGcSGP, double AsAfsrtLEql)
{
    bool qzczRS = false;

    for (int nhjKZqoNVVg = 1633423929; nhjKZqoNVVg > 0; nhjKZqoNVVg--) {
        qzczRS = qzczRS;
        qzczRS = ! qzczRS;
        qzczRS = qzczRS;
    }

    return 1800484908;
}

void NUqnMb::UpaVfXRNziP(double DVDXkNa, int QQqSbzRbVurCyUn)
{
    int XuvTI = -819280539;
    double XThAKIpjgzfkeCDM = -946311.9312406871;
    int UISJQeWz = -19322160;
    string jhphPaQO = string("iSUajoZhVJwDVUOqtFFhZDTkLJszAQQlpZzfIikmOkuRnmpfyyqckeMRWoauKQwSTYdjhBlATuKpEUVYEffKEASNKdrvMtsxCJrQtxrcyuCgElVwlkmbNhEnrwZKqdiMPPdLQvZTPTrJWAdJyVazAWKGvMvmoozjqEaPHSmJDwiEsMLhQupRMCcpJHuwROANTipsBdViZQDICGyyyEwrzvDTISbs");
    string qgeiWC = string("qvfXoMWMWiNwzVFseNmzTigIBSLgrVKzCznQMMlxcVicqIMcepnySqMwZVQWMuuaNCNdRSoOEiWkPWsjFCfMiNufOqfzzrlIuixVepVrHYSHfoipFivRwQhhPGLIPAGIfSzhzJGwzxaePnfevzZEYnimJrDMRCvjTnHWUAxRGkWnXOWlJsQwJsBaTkEiqDKbuVDVTHPAblnUNsyKofFCWEjrCmjOIjRP");

    for (int FcawVf = 1463983132; FcawVf > 0; FcawVf--) {
        XuvTI = XuvTI;
    }

    for (int tXtRPFrSwn = 479895919; tXtRPFrSwn > 0; tXtRPFrSwn--) {
        XuvTI = QQqSbzRbVurCyUn;
    }

    for (int UThhiNtvxt = 893266827; UThhiNtvxt > 0; UThhiNtvxt--) {
        QQqSbzRbVurCyUn += QQqSbzRbVurCyUn;
        XuvTI /= XuvTI;
        qgeiWC = qgeiWC;
    }
}

void NUqnMb::FMKGwLEKpm(int YpyGrKevrvjkxqlG, double spUKxae, string vvZUBKCvBzYNWZZ)
{
    int YMTCYzWkvCEoIdu = -1898869601;
    bool ersvFGNPAxocSWZg = true;
    int hiuspa = 467712033;
    bool xZDFLAOZpQzRX = false;
    bool noYlXvTDoXjNZ = false;

    for (int TLdqVBD = 288848465; TLdqVBD > 0; TLdqVBD--) {
        hiuspa *= YMTCYzWkvCEoIdu;
        xZDFLAOZpQzRX = xZDFLAOZpQzRX;
        hiuspa *= hiuspa;
        YpyGrKevrvjkxqlG /= YMTCYzWkvCEoIdu;
    }

    for (int UEqONma = 1595054305; UEqONma > 0; UEqONma--) {
        noYlXvTDoXjNZ = ! noYlXvTDoXjNZ;
        ersvFGNPAxocSWZg = ! noYlXvTDoXjNZ;
        noYlXvTDoXjNZ = noYlXvTDoXjNZ;
    }

    for (int BfNKToo = 65447143; BfNKToo > 0; BfNKToo--) {
        YpyGrKevrvjkxqlG -= YpyGrKevrvjkxqlG;
        xZDFLAOZpQzRX = noYlXvTDoXjNZ;
        YMTCYzWkvCEoIdu = YMTCYzWkvCEoIdu;
        YMTCYzWkvCEoIdu *= YpyGrKevrvjkxqlG;
        YMTCYzWkvCEoIdu -= YMTCYzWkvCEoIdu;
    }

    for (int UfQZe = 1881411738; UfQZe > 0; UfQZe--) {
        xZDFLAOZpQzRX = ! ersvFGNPAxocSWZg;
        ersvFGNPAxocSWZg = xZDFLAOZpQzRX;
        xZDFLAOZpQzRX = ersvFGNPAxocSWZg;
        hiuspa /= YMTCYzWkvCEoIdu;
        vvZUBKCvBzYNWZZ = vvZUBKCvBzYNWZZ;
    }

    for (int OFUgUcIWtMkdQLr = 1648790768; OFUgUcIWtMkdQLr > 0; OFUgUcIWtMkdQLr--) {
        hiuspa = hiuspa;
    }
}

string NUqnMb::pVsHIbTDbnCr(int krNAGHqhhaXNpoEo)
{
    bool HDCySL = true;
    string ismwb = string("KgghTVEnDtqmybjdzNhlaDDPohaqzouIIkTABZntbnMSFthotjxDnCqntoDryhMFFGeJVgTQfrLuIVOmbRaOzqiGyxrOwcQVWynJhizqKZJVbKtBVrwroenkOQIqYAELpASOiXbIcmfPMmbhNnRLjgkIdXtyMvlbFINYAxuIndtJFCRQQPTQDlGyYWkqfAfDQYlhQTyIZrsvroVcXkPZIjpaA");
    bool zsrwWFAD = true;
    string aPkNvUgSs = string("yTTQdstiMUbDrzlKHeGxqoCjUiKUgCGcjlPeoRTBgIKHHM");
    string RgCJstoPsVZqQUCs = string("kVK");
    bool OPnlHgIqysKr = false;
    double LZTldHOtj = -914480.5337760913;
    int OHcRHk = -319637010;
    bool TdCNswgocyK = true;

    for (int NFyBjDgfHqlmCNuD = 538780855; NFyBjDgfHqlmCNuD > 0; NFyBjDgfHqlmCNuD--) {
        OHcRHk = krNAGHqhhaXNpoEo;
    }

    for (int KUnUVjXwkcOqLUH = 1013105292; KUnUVjXwkcOqLUH > 0; KUnUVjXwkcOqLUH--) {
        HDCySL = OPnlHgIqysKr;
    }

    return RgCJstoPsVZqQUCs;
}

double NUqnMb::tzcWiVOkaA(double ilsadCfXL, double KapyTGn, int VgpWWxmM, string NItvAztmOuk)
{
    string pIiFhGKiv = string("DPIllmgbLrWcyPKWoNlfHJcamKNwdosvUmHVGgPmVIVKoucFuPvDXfrymkhaykIWAVxdiJTaSckJmuZyhDfIcabyuthKQieCA");
    bool TbGikcft = true;
    double XJKkJOP = 1036893.1083401222;
    bool soZeKPKOu = false;
    bool SowWYqwTlLRF = false;
    bool TJlSXhcEtaehwhYB = true;

    for (int YwZjhlDqrKA = 1976624724; YwZjhlDqrKA > 0; YwZjhlDqrKA--) {
        TJlSXhcEtaehwhYB = SowWYqwTlLRF;
    }

    if (KapyTGn <= -952267.0146848586) {
        for (int eDypKCThDRhGUtKO = 498844752; eDypKCThDRhGUtKO > 0; eDypKCThDRhGUtKO--) {
            SowWYqwTlLRF = TbGikcft;
            NItvAztmOuk = NItvAztmOuk;
            XJKkJOP += KapyTGn;
        }
    }

    for (int ihkfAlimR = 1487716071; ihkfAlimR > 0; ihkfAlimR--) {
        ilsadCfXL *= KapyTGn;
        XJKkJOP *= KapyTGn;
        NItvAztmOuk = NItvAztmOuk;
        soZeKPKOu = ! TJlSXhcEtaehwhYB;
    }

    if (XJKkJOP >= -952267.0146848586) {
        for (int USaBN = 1598740671; USaBN > 0; USaBN--) {
            continue;
        }
    }

    return XJKkJOP;
}

double NUqnMb::rLCQgxMzFNAYUBgu(bool zAHvnbaYRftsZ, int PmsEOXLfUTcQzVwD)
{
    bool VUfKIHuE = true;
    int ttxHrdy = 1263848435;
    int WzcFoC = -1793492347;
    bool olLzjGaiPbGywQrJ = false;
    double jdRogVnJpa = -290142.9004357542;
    int XdbEsnOCtqdoX = -56152671;

    if (WzcFoC > -1793492347) {
        for (int DuLtRGxDQtNaFp = 1172236881; DuLtRGxDQtNaFp > 0; DuLtRGxDQtNaFp--) {
            zAHvnbaYRftsZ = VUfKIHuE;
        }
    }

    for (int JThkXs = 559682992; JThkXs > 0; JThkXs--) {
        zAHvnbaYRftsZ = ! zAHvnbaYRftsZ;
    }

    if (PmsEOXLfUTcQzVwD > -56152671) {
        for (int tUSLMMVmTNYY = 1177918277; tUSLMMVmTNYY > 0; tUSLMMVmTNYY--) {
            jdRogVnJpa += jdRogVnJpa;
        }
    }

    for (int zbsDETtCY = 1008938181; zbsDETtCY > 0; zbsDETtCY--) {
        XdbEsnOCtqdoX -= XdbEsnOCtqdoX;
    }

    for (int hAqmnqB = 280702311; hAqmnqB > 0; hAqmnqB--) {
        WzcFoC -= XdbEsnOCtqdoX;
        ttxHrdy *= XdbEsnOCtqdoX;
    }

    if (WzcFoC <= -1793492347) {
        for (int SiuxrgrmI = 1584841258; SiuxrgrmI > 0; SiuxrgrmI--) {
            WzcFoC /= ttxHrdy;
            olLzjGaiPbGywQrJ = olLzjGaiPbGywQrJ;
        }
    }

    if (VUfKIHuE != true) {
        for (int chNEBVHhNumQdtHA = 1278635315; chNEBVHhNumQdtHA > 0; chNEBVHhNumQdtHA--) {
            continue;
        }
    }

    return jdRogVnJpa;
}

void NUqnMb::dcvyW(int zhoyPU, bool klYEpMuyRA, int pqvTtsw, bool hWSEZlLpUmePMjo, bool fqJRQt)
{
    string jqrqpVg = string("RDtQNNlPHagrOgqqcmsGQHrpYRdfZGWMHxVZdUULUHbijIdDbFuUNFmsSRWulVpwOqGRTJXzLpUQeQjJLaCjoDntIlouMHOEtFegksAeGCEmgNOTRKTxiSl");
    int Tfzqk = -1226504996;
    string BxmbqXjD = string("nWVrfBgrTbPpMPLDcXrVMQHyFDuDqY");
    double LevFsq = -344291.51765839546;
    int uzUMdhJoCaw = -26421480;
    string ezSMFjmWggxr = string("oXAIPIAzbeAYeyyYInkALOzrKKeUcvcmtMTIxeVHoZWRnzzfiTMjgxKFkLGUMBvdLiknbYuklSOlKDbJSZwUAoDtUgXplxtOOqNGezCfODSB");

    for (int IoYeBZvKxJNWf = 1519620912; IoYeBZvKxJNWf > 0; IoYeBZvKxJNWf--) {
        klYEpMuyRA = ! fqJRQt;
        hWSEZlLpUmePMjo = ! klYEpMuyRA;
    }
}

string NUqnMb::DJwhrEG(int LLiHr, double isSrsnFDo, string hWDQdmTr, bool ZFUGIlXfxVTH, int otFFrsoeOfqcSXN)
{
    double ltNqERHYPss = 841591.2463335921;
    int kAYCLRcLbaqg = 640528077;
    double wbCCKZDx = 882480.0411562613;
    int RglmalhCISHQG = -924660453;
    double hqXbpsoxFE = 541830.8901365404;
    string umxIhnJhxwRPtC = string("oFnwFzDDiXzEuMkvxzWhObvqgWknoLMhXEMqVRnHLlJUOeKfyLONxfHDzZMsOVLneKkEkqfXicMlkkCpWPILXViFSHXfRSmocCeATRCGNwXqqVtkgFbmQiczmMyvPkypvuGMpnGKWKPLzbJzYhRSvPdfPeOLUmKqTuqwqDZElnbhdfyuwVFHnNtEUWQrGFjctfTXBzxrxk");
    bool AOGAt = false;
    double agBPKzzLpFM = -1037314.7393469118;
    string xtaHkciJeergUF = string("eUAxgBPYTEYYjTmlVzuZIuNKcvOkmZqONHSftV");

    for (int vaXIclNFbl = 2050570446; vaXIclNFbl > 0; vaXIclNFbl--) {
        continue;
    }

    for (int wzLWFZthVlqjKac = 1957024908; wzLWFZthVlqjKac > 0; wzLWFZthVlqjKac--) {
        continue;
    }

    for (int EtBRT = 500262539; EtBRT > 0; EtBRT--) {
        isSrsnFDo -= agBPKzzLpFM;
        wbCCKZDx = isSrsnFDo;
        hWDQdmTr += umxIhnJhxwRPtC;
    }

    for (int rGWeUxTqNOkhP = 1723960817; rGWeUxTqNOkhP > 0; rGWeUxTqNOkhP--) {
        isSrsnFDo = hqXbpsoxFE;
    }

    if (ltNqERHYPss <= -1037314.7393469118) {
        for (int gWhhH = 827361075; gWhhH > 0; gWhhH--) {
            umxIhnJhxwRPtC += umxIhnJhxwRPtC;
        }
    }

    return xtaHkciJeergUF;
}

string NUqnMb::ZBPCGYswhITiKNsq(double qMUhmjnIaSFy, string AbxWnmfcK, string jYKBUUk, string wAWuLBLfNMiS, bool xzwJHt)
{
    bool JrWIHWymTbtPzyHq = false;
    double QwpEiEOccxZi = -548051.8526788191;
    int uJMdyHIRygUYgy = 1643673467;
    double wVwZVdaNLgmwa = -898798.0643223211;
    double mLtfqQuDg = -779929.6921794874;
    bool HlXmPwV = false;
    bool ykvvDgeAbTbg = false;
    string qwPvFXHOCBZQC = string("GlLoMeQdUTFyFiIooplHiilIMKpMHHPSYdJzPBKfbMuQyXNFwflnvAMRMUFrVyfuRKgmDxuwlLGtMiItLQKlqhmegQdkntUzZHDVAxoIKTTRPludurbHMjoHONaznEhFyXMmaXUgBvPtuBuYqtvMKcywGsyubMuWarMDIiVAzlWKiceREVgGiQkZdIVGgoosKOWkunBr");

    for (int NcloP = 518698929; NcloP > 0; NcloP--) {
        continue;
    }

    if (wAWuLBLfNMiS >= string("AnqKpLuHXZOzYaIdeUZgLBmQqquEWJEWobGUtzJBJOjouQiRxtgTjSHDIoiJjffsZhvgIiggVZsaXERLqCuPijcJgvBACxCBJtlVshqmiRWQqiSstlzVqdJhkWdwvHzqRMUYdlHWkkzWLIuKEdwmmoCShae")) {
        for (int ttaUmcsCPj = 1037873784; ttaUmcsCPj > 0; ttaUmcsCPj--) {
            QwpEiEOccxZi -= QwpEiEOccxZi;
        }
    }

    return qwPvFXHOCBZQC;
}

NUqnMb::NUqnMb()
{
    this->GxctxDLL();
    this->CrvsZXianGfiZ(string("cinGOcaCSOZmnXaPwNwccwdVBsFhFolmbwAOgUCMhlUvGKorNvyJmMxpJmLzdZiQQSkziyYMmtVRTCGoLLA"));
    this->SVjVInp(string("jTxQfqHaUMZGEVTvIWVqjoAFQNIoUfYRcCHlGHiWlYvTZRrkBCoPhgGHhwDMMMkKiKVxsTNsFfCSrkivHnzIevGvPOSBMxYgyQUndPeAIfjcUfjWhvHnUMgscKLWXdcAUBSSplwmNwgOuuqdkWjNlRZAZIZrAFDctWdxwaHjTcMudsOROjVgGZhVSZiFdMzeLDijEYGIirVsFCIP"), false, -290265856, 258339607);
    this->uTLjRzIYo(string("zkIzgPtpjSnrrUBHOIfyuATKhdQiLMoBanvBHskQCQwEIfTbfpgNwfJHSpvMzBUmrgwmIWfJSLCnhNdDipuS"), -433603.1061431002);
    this->UpaVfXRNziP(673833.4219534735, 902837518);
    this->FMKGwLEKpm(-1758340013, -554302.0705826215, string("suTViNQeZmDrFipgjIrzhzibzTzjdELwoAgqazJL"));
    this->pVsHIbTDbnCr(-412499280);
    this->tzcWiVOkaA(337537.7290776769, -952267.0146848586, 1016729375, string("hfRusaXfdCnkIvcKWatdbKNARBaxSTpSeDznxZUdsUevWqvGDWHKvAGxKMZyBVzFMnQOlcFQxgasAcgwTRiEuBbAraNxTQGoOardkKwlRIMCKgyWWhSDohUePtSjiBlwkEJfvjAJirdIFNZMwhTHNCPUxtJenpWoNFGHmlTSammDOVIgRrFQywbPILZNOXmymUegrzOBXmvUrLgSvY"));
    this->rLCQgxMzFNAYUBgu(true, -1851366823);
    this->dcvyW(-1205825391, true, 513326125, false, false);
    this->DJwhrEG(753905828, 946821.6752276235, string("ZUqqTBIuYZbYVrFosdVKsMjodQkVAlbbWAcaOaUEsWbExIPwFvlwHjAHKPNePWTOGtmYlPrqlsNJrEpMQhJxzHThDOwuJQwTLVCOkgfHFxpffRZSSJRagqRMlETFdbtwQGfFaRziRWojceEcMipzNQegOyMuEiYcCMJXHqwNfCkrpsBDhOVzkjXJjLQznNFKdZedaDdXdlCwFpcJjzwjcvDbGgpzeAJFsXQJ"), false, 1027815273);
    this->ZBPCGYswhITiKNsq(-955582.2309839297, string("ykQqpsXOeLvSEAFEFzlktJFFYoNfnepuVmYQHykDGwDxWbPENEVHRKnFawCAXvozwSqWuWkANwRxJZlbrxOAlAGeFHgUjtbjbGqoiktF"), string("luMlpmrfhEemvRslJOZZhCHuFHbOypLhuVILxSrRYSGRWRGwgNDilTLIwcgOVOHEIXqFvAMGoPaZRLwgnZkVWulJtvvdAnEopIxxNatCxxrBUYUwilMZGnoRVdXmcuqkCWaegNJnbLdQHeHPTzMuVzaIgbweLDLaRziUYwAxSnwBPEwMtawOtZDGXbJvGeqZKvrxIOBOgfLwYIVRPETKUUfP"), string("AnqKpLuHXZOzYaIdeUZgLBmQqquEWJEWobGUtzJBJOjouQiRxtgTjSHDIoiJjffsZhvgIiggVZsaXERLqCuPijcJgvBACxCBJtlVshqmiRWQqiSstlzVqdJhkWdwvHzqRMUYdlHWkkzWLIuKEdwmmoCShae"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OjAgyKOHZkd
{
public:
    int UibwNJu;
    bool qeSdXPxRDwRDf;
    bool VNuGEFq;
    string IGvKTosVPKAtWn;
    string dJHxwU;

    OjAgyKOHZkd();
    string vexjk(bool nEjfuohrclQUyekN, int aKjCgclXLPwMB, int cUaYGgvv, double CWqIbYfkf);
protected:
    int ysdtGjTcFlbM;
    bool jDWfKjF;
    int WUPyLT;

    bool EzsNtUAsLHxT(int ZJTNWvlfW, bool GGYnvYjFheOi, double kpRnJZzCDEK, string oKmGrwtkGif, string gNtmvhMEl);
    int LHlKIoUOs(string Mzrzn, double UJrVHNLuPTzgh);
    int NbUMPckEIBOWLaj();
    double JvNXLTcuXV();
private:
    bool BdXiauNWMjndca;
    double lMexTHdv;
    string suDJrYKHJZYJ;
    double juDlCbutn;

    int KzkvLCNVeJYNALTO();
    void YsogGDaeGs();
    int AoAEBPa(bool dBCIQBbGWwGfznfD, string HXjaF);
    double YNcbDVrBCbFK(int bahglxKSKoUb);
    bool LxpacyqQGMc(string OVpKeBpOY, int cveFhecgIaCv, bool jXxgclNrJbAWbhMU, string mLUuP);
    string sjpUMnn(string CImLHc);
    string BzkhNvrFD(double aysyPXUR);
};

string OjAgyKOHZkd::vexjk(bool nEjfuohrclQUyekN, int aKjCgclXLPwMB, int cUaYGgvv, double CWqIbYfkf)
{
    bool fGzvHATldz = false;
    bool SBVMnZwAi = true;
    double mIiNRktIIt = 490585.7157824366;
    int JrxWplIuODBqV = 883905575;
    bool Wnedk = false;
    double pBAwUAJtRIpVy = 809072.6609121327;
    bool mwNygscMe = true;
    string kfdJpwPbpGS = string("AQsSReknBblGohWQTAhOEGLpMmcsFFeIDbXqcsnzDSIVlJqEHWTsRqLLbsobuuthvKVaHDWVxWTNcdfmYyPxgUSzaEIXXdYrajPWYtbIRijDExPRZSGWZfEVJiCqVp");
    bool xAQPNLmZipd = true;

    return kfdJpwPbpGS;
}

bool OjAgyKOHZkd::EzsNtUAsLHxT(int ZJTNWvlfW, bool GGYnvYjFheOi, double kpRnJZzCDEK, string oKmGrwtkGif, string gNtmvhMEl)
{
    double HqMPHBfCEZNIt = 866868.0375415818;
    double lYdGHdSeBFieMj = 26842.607695155173;
    bool saiQFWyR = false;

    for (int bvVAPGFoXzmA = 330632867; bvVAPGFoXzmA > 0; bvVAPGFoXzmA--) {
        GGYnvYjFheOi = saiQFWyR;
        saiQFWyR = saiQFWyR;
        kpRnJZzCDEK *= lYdGHdSeBFieMj;
        kpRnJZzCDEK = HqMPHBfCEZNIt;
    }

    if (gNtmvhMEl < string("IaVAVuyywJLGOYiWdIGoRLMDvXrbQJvVyFpdHtOEhKYLZxZFCNFnxHUJNSIWIuwbwygPmGqetuyCMPapSMcsQBUrJfUTFpFPLsBrVazaOkfwfkAVJkoESmiZLCmPMRcrIgZhKLCSyVSSKsdmlUdZrdsTfXIKvJqvCVEXUcwWkXvXe")) {
        for (int nVBPxhjbe = 215774354; nVBPxhjbe > 0; nVBPxhjbe--) {
            continue;
        }
    }

    if (lYdGHdSeBFieMj <= 26842.607695155173) {
        for (int zpkFToqMijfFf = 1969534999; zpkFToqMijfFf > 0; zpkFToqMijfFf--) {
            continue;
        }
    }

    return saiQFWyR;
}

int OjAgyKOHZkd::LHlKIoUOs(string Mzrzn, double UJrVHNLuPTzgh)
{
    bool IyzRRSUqbDsKSLAD = true;
    bool iabyGKkil = false;
    bool rKVQjPAzB = false;
    string udtJHnk = string("qSNQvgkPbSDzJzjbiDAffzgWMJdZAztmyxUZHRNlTvENCgxhuZeTAhzxKojlYHsxpHjBMXLRprmCZGDJAZjVlOmaMpPNvuSRlWnsSaoYQtWcRSxIabgCvADbwhUTOhwPWxKswpOUxKyvYSdvvSDuvOJLvuVWusjFJmKdYeROrNAnijmnMxNeQcpvjHPygmUDDvFYfLXKsJdyKfIF");
    string YAPTVXSpmbIUYDqH = string("ZgKqFJNUOGZazpJkuaGaVSitLIXJlTmYNSowLgYpsXKvJEzBXoazBWboNnZDqQkluxedHtLTMZngiIvniXiXjVoOWHKjOtIiKscngUxcmmpsEyAIrnFRrwZlwXAXUHHaVqenjKFJeLeZmYpMkSujvPjCoYINUJAaEcAbvIXlZuEhhstgZlJZpgdqqrhqJtRl");

    if (iabyGKkil != false) {
        for (int wWSfQiqYMsA = 608964803; wWSfQiqYMsA > 0; wWSfQiqYMsA--) {
            Mzrzn = Mzrzn;
        }
    }

    for (int lExXtQONL = 678589165; lExXtQONL > 0; lExXtQONL--) {
        udtJHnk += udtJHnk;
        rKVQjPAzB = rKVQjPAzB;
        rKVQjPAzB = ! rKVQjPAzB;
        Mzrzn += Mzrzn;
        Mzrzn = udtJHnk;
    }

    if (udtJHnk != string("ZgKqFJNUOGZazpJkuaGaVSitLIXJlTmYNSowLgYpsXKvJEzBXoazBWboNnZDqQkluxedHtLTMZngiIvniXiXjVoOWHKjOtIiKscngUxcmmpsEyAIrnFRrwZlwXAXUHHaVqenjKFJeLeZmYpMkSujvPjCoYINUJAaEcAbvIXlZuEhhstgZlJZpgdqqrhqJtRl")) {
        for (int MEvenWi = 1738051339; MEvenWi > 0; MEvenWi--) {
            IyzRRSUqbDsKSLAD = ! rKVQjPAzB;
            rKVQjPAzB = rKVQjPAzB;
        }
    }

    for (int YgaXYyTysAQJFX = 1495303797; YgaXYyTysAQJFX > 0; YgaXYyTysAQJFX--) {
        IyzRRSUqbDsKSLAD = iabyGKkil;
        rKVQjPAzB = rKVQjPAzB;
        Mzrzn += YAPTVXSpmbIUYDqH;
        rKVQjPAzB = ! IyzRRSUqbDsKSLAD;
        Mzrzn += YAPTVXSpmbIUYDqH;
    }

    for (int QUSSytBpg = 282456696; QUSSytBpg > 0; QUSSytBpg--) {
        IyzRRSUqbDsKSLAD = IyzRRSUqbDsKSLAD;
        udtJHnk = YAPTVXSpmbIUYDqH;
    }

    return 1336861877;
}

int OjAgyKOHZkd::NbUMPckEIBOWLaj()
{
    int SKBpAPB = 1040852756;
    int iiVsaM = 304837244;
    string oVdeTfHZUy = string("xFoelnLlZbtsOpjfSeINOeRsrHcEhaOmUnWYftQRiSIPCEGZjzXdLvFuTHPvLLysKgvNNcSGiYjOhspafvENcCeooDGmTVKobiGbMRZUWwMPMKssriEfLPTudZYyqulzcbOcjCFNXwhlEzHnUYLMPFxYSgEQPWwsRDQLpCIOrOsDpziOanhDuwEQVTODgeGehAtcBfXmGhOfdWOKvUQimBTvRrmCKjdGLr");
    bool aUDJTtfiy = false;
    int XvByqgAidl = 1117410852;
    string lelRgn = string("GmkBvDRGbovJopBueQiAHwDXWzErfKGtcZKZquEsqbCXkgFpRTsXQaxEZVTGRPKztOhtQXXPhlNptQMLxGKKxvQzjkgZWZuMPtDHjKxeyzqLtyAjtZcffGYeRYPGpKDwArzpKanPZLnjwXczRiwvdSbneDhQSKSbSbCZIASFGqDRyXLbatazLjFuCXLuDlCtXve");
    string NGfCOsSrwESQvfl = string("TzQgWOehjJfxWMzsombcIkqjeNIqzlySacWeaZiUraipfvNrjcLCwMbgYuMAcUXMYeVNAkPqAyOEBdETMQiRZflZIaLlFxsgBvbsEZSOwSBPzpLxFtcUkLpNChsdnVsvmVjqTWPKPMsptfRmDiVrwwyTOyGcRZLqEsxsAVoXyzELahgWOMJxfKpRCqUliOZAucopfvLAiUOMTCShazwUfRrJvYLLqsqLEwJahaaMKhSkjAGq");
    bool ohnSjUp = true;
    double uqTkEvS = -981598.6437846626;
    double NetirvNTrIUDjBc = -534286.9434493304;

    if (oVdeTfHZUy >= string("xFoelnLlZbtsOpjfSeINOeRsrHcEhaOmUnWYftQRiSIPCEGZjzXdLvFuTHPvLLysKgvNNcSGiYjOhspafvENcCeooDGmTVKobiGbMRZUWwMPMKssriEfLPTudZYyqulzcbOcjCFNXwhlEzHnUYLMPFxYSgEQPWwsRDQLpCIOrOsDpziOanhDuwEQVTODgeGehAtcBfXmGhOfdWOKvUQimBTvRrmCKjdGLr")) {
        for (int pPiUtvYFsTO = 1142833720; pPiUtvYFsTO > 0; pPiUtvYFsTO--) {
            continue;
        }
    }

    for (int hqqjmqVjqwRhokzu = 641809716; hqqjmqVjqwRhokzu > 0; hqqjmqVjqwRhokzu--) {
        lelRgn = oVdeTfHZUy;
        XvByqgAidl *= iiVsaM;
    }

    for (int FnFULIPSwr = 2112312831; FnFULIPSwr > 0; FnFULIPSwr--) {
        lelRgn = NGfCOsSrwESQvfl;
    }

    for (int PlXbQJfGnTMroT = 1130426658; PlXbQJfGnTMroT > 0; PlXbQJfGnTMroT--) {
        ohnSjUp = ohnSjUp;
        XvByqgAidl /= SKBpAPB;
        aUDJTtfiy = aUDJTtfiy;
    }

    return XvByqgAidl;
}

double OjAgyKOHZkd::JvNXLTcuXV()
{
    string OBEbYNrgemNmscG = string("ligvIRWIwodOaUxuSibTNObsrDNBeLEBtSIxBZbAQnqckZVMiJuTFgwQRPHBHfyODScG");
    string KPaXMAwzAf = string("pMIYbLsGJhLxCxMGUOOraSXknurWaIibXrrrsMFwvbgyFcnxJebhDkTHcgMcNsnnrXBFirrVGLwLhkFcVByLtNYSpwYOCHLFnxBwfYKsObiGjhEqDnHVlPLauTqUXLKKKYSReAaMsoJScJCXpLxrShanreptbYHMGnaZbD");
    bool GTlUVUAjSXFUJiV = false;
    string XDiQJlRypANItkb = string("LvyDTqVATALCAhbDUOikTbFCoZRDTvNAMnonSdoxhjlmmYYzMEFJGcUyGThyOUTfSFffHSNyzkRWhkMxCsdiDhvuYeZuMqnWUgrbGuhJcSnvESEmiOjsbyHqRiuRJzhGUDsFqqffNmKiqeKjcHEZEoaMpIooMkeAViaecr");
    bool FcPzobDxIzfIO = false;
    int CCgqGhhDFHYDn = -1474938624;

    if (OBEbYNrgemNmscG == string("ligvIRWIwodOaUxuSibTNObsrDNBeLEBtSIxBZbAQnqckZVMiJuTFgwQRPHBHfyODScG")) {
        for (int fmXMSwrMHBCVq = 1585801121; fmXMSwrMHBCVq > 0; fmXMSwrMHBCVq--) {
            FcPzobDxIzfIO = ! GTlUVUAjSXFUJiV;
            XDiQJlRypANItkb = XDiQJlRypANItkb;
            XDiQJlRypANItkb = KPaXMAwzAf;
        }
    }

    return -127085.44130933708;
}

int OjAgyKOHZkd::KzkvLCNVeJYNALTO()
{
    string NwkemTFyTM = string("TIwusPdrfsIPCePGJrxmGNxwETxjqEjlRrAZczsomvPmNbfOqjWWvqOgGmSjpUSafKoaviRQYsFpUSSqtKYRfppWktIAuZmYsFfXLoxCKvAfiJbnnrJnHUlpxuotjldJTSidhDofosmIaOdoFTVKQEwBGFr");
    int KHKGhvv = -1801170066;
    int BLhXksOfubBaANp = 1141714623;
    bool OyXxLCToLJNQOG = false;
    bool DwLPyOa = true;
    string lPytC = string("qVJQunrMXOWCGKZNxJzEAMnLSOMdctsAyfOtlcNFbXfPCNyRCmwkFNmyWnuFkiKvWqdOjHNvJXoukxQAVRnoMXyYskdiUwyHzmeFkkT");
    bool IvJLhZvfoFDAGw = false;
    bool wNnLT = false;
    bool SrOnvwibVGqo = false;

    for (int ziAjP = 692739503; ziAjP > 0; ziAjP--) {
        NwkemTFyTM += lPytC;
        IvJLhZvfoFDAGw = ! SrOnvwibVGqo;
    }

    for (int MCnSHENAamx = 391738364; MCnSHENAamx > 0; MCnSHENAamx--) {
        DwLPyOa = wNnLT;
    }

    if (OyXxLCToLJNQOG == false) {
        for (int vUAtKaRgGo = 417145539; vUAtKaRgGo > 0; vUAtKaRgGo--) {
            continue;
        }
    }

    return BLhXksOfubBaANp;
}

void OjAgyKOHZkd::YsogGDaeGs()
{
    double wnAKYxx = -216674.96608859362;
    double UffSWk = -413470.7576620728;
    bool JufziGWEgXGQ = true;

    for (int tTouFEOp = 472524431; tTouFEOp > 0; tTouFEOp--) {
        wnAKYxx -= wnAKYxx;
        UffSWk -= wnAKYxx;
        wnAKYxx = wnAKYxx;
        wnAKYxx = wnAKYxx;
        JufziGWEgXGQ = ! JufziGWEgXGQ;
    }

    if (UffSWk >= -413470.7576620728) {
        for (int BNouvUy = 817469219; BNouvUy > 0; BNouvUy--) {
            JufziGWEgXGQ = JufziGWEgXGQ;
            UffSWk -= UffSWk;
            UffSWk = UffSWk;
        }
    }
}

int OjAgyKOHZkd::AoAEBPa(bool dBCIQBbGWwGfznfD, string HXjaF)
{
    int DnwLd = 2010777585;

    for (int mZgXgWuaNUZV = 656313774; mZgXgWuaNUZV > 0; mZgXgWuaNUZV--) {
        continue;
    }

    if (dBCIQBbGWwGfznfD != true) {
        for (int wOzMKALrjjXRed = 1163658526; wOzMKALrjjXRed > 0; wOzMKALrjjXRed--) {
            continue;
        }
    }

    return DnwLd;
}

double OjAgyKOHZkd::YNcbDVrBCbFK(int bahglxKSKoUb)
{
    string OujnPBBd = string("PIGHQkPfdWfolHDojtKZikoRAGTMtyRWYoNkvCajxRntnlOYMrbYniCtTqMwrZqBRNTycvvKBUiMrbcxOnZeMcCEGHKaCgIdxqlMQkTnLjiLbqjZDnBnBnLEfOLMCNfiDMRpUXyktWxKBvZBrxkRPcOLysdafEAHWbpGoFtmsvaReCRXHFODRfxdsLAvCQEenuH");
    int KvMWboUzCsutj = -1821028551;
    int WtQFRS = -462788369;
    double UjqQqIiRmS = 361541.1736394772;
    double hArdoauZxwI = 174489.35547975803;
    double WIMmMB = -328228.5778219973;
    string MpSCYIiN = string("Pgdo");
    double GhZgqiQejskzbjK = -270606.0587787535;

    return GhZgqiQejskzbjK;
}

bool OjAgyKOHZkd::LxpacyqQGMc(string OVpKeBpOY, int cveFhecgIaCv, bool jXxgclNrJbAWbhMU, string mLUuP)
{
    int VsRHXSGFExgKekEb = 168490526;
    string dIcFj = string("TVJIThGAxNuaoEgsWJQosOjFArdQZrrqloTCVghTUERIVBfaBJLUAdxiDcfejoBfCxbjHSYIfNnqLLhBWugGJyZgPRgOMsWywXAhSZouGqMqDNtdVwvxOKvSJyeyHaLVSnxynEOvZnEDvoVEAcS");
    bool TXyAMEBhWlPPNMZq = false;
    bool qDbJbdrTDp = false;
    bool JJShFb = false;
    double RguFjw = -151810.07995027569;
    double wiVfuhNbdQcbTZR = -1033069.2006376947;
    string wXJGXsUqDJbhgdb = string("LqGwVUkNYnxEAWdisKFjUkMbbWAkRTMSIgHXECEemiTGTrApDARazKkEhPEpKgLMgYavZVuMEbFLipnwPnXnMRToWrOOzFtqkQcSJIOQeqPRbdMLwTYvrIETJthliODwVPpYINsYlhcKFLtlPWKMqrvNFPEQpYRkwnCaUKGbrnSXMyWTdgchgQbzEnLGxuamVQfNJHAIwYxUJwWVOPVDFRmRJIVcOVCTlTEdFbluKwCetXOEX");

    if (OVpKeBpOY <= string("KdRNbhtdeyufmnIpuVjpypuArqlOTetJAZKidEIJglkARJCsqZLnvfeBXKfWQLIuyqcxCqJolCWiXgvsIfmjysltOrxUcwznMYfAGWqoc")) {
        for (int ohvgfTuUxT = 1827307085; ohvgfTuUxT > 0; ohvgfTuUxT--) {
            continue;
        }
    }

    return JJShFb;
}

string OjAgyKOHZkd::sjpUMnn(string CImLHc)
{
    double OMqXwiPM = 1045672.3825138095;
    string sKUuuXnhHGvR = string("xXqAXDWdfPdhMLXCBoFPFKdRINQvksiLyOypkyfuVRBLMijzOJfMgBFZcMWXDfHAqdRIcADFhVmFLOOsUtoeoGaiJIPgtYCqiQaeTuBLMKwMOAMlXjeXxavbHqPIPGLpXvVFsxiJIxaiNbObuaPWqkwHYfclxMLfiqVqAsqtPayTQAFrXaYuLqxOerXsvWEfi");
    int lirfPudjeAyL = 1812873402;

    if (CImLHc == string("xXqAXDWdfPdhMLXCBoFPFKdRINQvksiLyOypkyfuVRBLMijzOJfMgBFZcMWXDfHAqdRIcADFhVmFLOOsUtoeoGaiJIPgtYCqiQaeTuBLMKwMOAMlXjeXxavbHqPIPGLpXvVFsxiJIxaiNbObuaPWqkwHYfclxMLfiqVqAsqtPayTQAFrXaYuLqxOerXsvWEfi")) {
        for (int ArxKnmvHArarg = 1151366158; ArxKnmvHArarg > 0; ArxKnmvHArarg--) {
            lirfPudjeAyL -= lirfPudjeAyL;
            sKUuuXnhHGvR += CImLHc;
        }
    }

    return sKUuuXnhHGvR;
}

string OjAgyKOHZkd::BzkhNvrFD(double aysyPXUR)
{
    double crHsG = -875292.1001465571;
    double DOvVervGFEvvAkLU = 186594.92542062234;
    string jVcdChlNNylRjSr = string("GcecwURhKmSJgwZESUygWolhfjvVRHVbkTHJJTDWEcQqhFidCtuwsrtBkhaaQBqcETQrNNjQdwtxGTeJULwQnsYfKinFIbdIXLXKZXONPexxkCfqNoHyFgChjQlJYGFRBBEfIoPkyTOkueXARmuQjOozLQmjbhlmhcTdDxmgPwrQgMU");
    bool OlYhIaLEs = true;

    for (int touNElgtBL = 612373963; touNElgtBL > 0; touNElgtBL--) {
        crHsG /= DOvVervGFEvvAkLU;
        jVcdChlNNylRjSr = jVcdChlNNylRjSr;
    }

    for (int yrNdtCrVBwIQ = 1643311388; yrNdtCrVBwIQ > 0; yrNdtCrVBwIQ--) {
        jVcdChlNNylRjSr = jVcdChlNNylRjSr;
        OlYhIaLEs = ! OlYhIaLEs;
        aysyPXUR = crHsG;
        aysyPXUR += DOvVervGFEvvAkLU;
    }

    if (DOvVervGFEvvAkLU >= 186594.92542062234) {
        for (int fJhyVvP = 1168319606; fJhyVvP > 0; fJhyVvP--) {
            OlYhIaLEs = ! OlYhIaLEs;
            DOvVervGFEvvAkLU = aysyPXUR;
            crHsG /= aysyPXUR;
        }
    }

    return jVcdChlNNylRjSr;
}

OjAgyKOHZkd::OjAgyKOHZkd()
{
    this->vexjk(true, 1032203706, 1198522661, -735257.997763721);
    this->EzsNtUAsLHxT(850547951, false, -900330.5380971198, string("qZwVqrEXLXPAfodJFuNEJqSyzWULFhxVdTFlMfpyiQaFtHjDFthzPoHYnBXObrgJeDuQrPNYQGmNvyElEBGorStugBrQdAxtaxqrfasgBdogHsWOQkuxveaRtWydfXyxpMWaOyHGuXovjcffKZgoBJATwYgpuZqLdkSMNdGfhGXvINZdnVwMgJAfbcLFKLiAfKMYGemzZdTWXwGFvJGzAlYVEyVsYPLhtFpjYB"), string("IaVAVuyywJLGOYiWdIGoRLMDvXrbQJvVyFpdHtOEhKYLZxZFCNFnxHUJNSIWIuwbwygPmGqetuyCMPapSMcsQBUrJfUTFpFPLsBrVazaOkfwfkAVJkoESmiZLCmPMRcrIgZhKLCSyVSSKsdmlUdZrdsTfXIKvJqvCVEXUcwWkXvXe"));
    this->LHlKIoUOs(string("edORjKTFnqcYPKaRfOxNbkBeorMhNLgjRRRnHKHeDcDUzpSSGnLxBIyyGhAhjTmClYzZlmOntmbrzLmglrDcQEZbkXGtmdoxWwVnINRuXllipfnskIYqEcgORVrOxDLeBeolugXOVGQVlrnpLcDChDbmPBksDJPsTzmRmQUDpCYlArxWemOjBWFjRnoYQhyGjYSgEucshJwRplpdhnKeAZdpFAobWKeRYtZz"), 622023.4726783172);
    this->NbUMPckEIBOWLaj();
    this->JvNXLTcuXV();
    this->KzkvLCNVeJYNALTO();
    this->YsogGDaeGs();
    this->AoAEBPa(true, string("AbeMFgjuGYvhzelNGpvRvRGyoycnNdcyMmWyiMfHKxyJiqCTOGzjTTkGjcFpAQhfSkzTyIJstROXFDSGRWIbLkaeYjFtPQSPovvrpyGVDzoeGIDkTGzCOQeybTWrvbLtgHtqXQKjeSEEAgmpjgNwCTkbRUfLDMnjTNNHdAbQIKrGRALzmMHAHcWIcQefeCzrhJ"));
    this->YNcbDVrBCbFK(-1289968086);
    this->LxpacyqQGMc(string("kLVVxsiqWEfNifaefrwpwMFDUdMgWyQfyHzuibCZbacCdaBBcGihVBryqlZoBLarNyGRuFSXkqtXMxrJltuQsuAGuWTtAzGFSDSlaRTOiQwhJAwUKjfkZFSiUA"), -1447197422, true, string("KdRNbhtdeyufmnIpuVjpypuArqlOTetJAZKidEIJglkARJCsqZLnvfeBXKfWQLIuyqcxCqJolCWiXgvsIfmjysltOrxUcwznMYfAGWqoc"));
    this->sjpUMnn(string("VQkhaJYtAYqijkNUBixTHjJTyoaNxMmygWlohWwgqvf"));
    this->BzkhNvrFD(331900.522113586);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VgsNbjimM
{
public:
    string uJQfCCjdW;
    bool Cbivmp;
    bool gGARsffxIPgJVYJ;
    string WAqKHJWNqJmA;
    int IFYWf;
    string pZONJKRWvCjdTN;

    VgsNbjimM();
    int jXsPLK(double ROjWHplFXJjOdfSY);
protected:
    string xiWFUeHJwWfBlh;
    int sjZfKfbng;

    void BLfhICnfcvkygz(string XQGHApaf, bool NgejhQnF);
    double UCcPMVgkRgkL(double OvTCSgPWPQkcA, string sqHTLsL, double EigVGgSNiUdsW);
private:
    string QMGOx;

    int gwKaeUwzZZIXl(bool fjBoCJLH);
    bool FeunWacMIpMrYr();
    bool WmrbFkHqAtEX(string dJSOorXXP, string XurfykGwSwc, bool ntHvsNWSNOWGmuc, string NkNUoeml);
    bool VnqmLyMDgfHgGkoA(string xIyswoqLUAuOrBAX, int kpBTpSAFWtyfycl, bool RWpjeinEk);
    double mJJWTGJLRPgIl();
    int DFxZaGiCEc(double GTHCrX, int suKHvCrlrIcqhk);
};

int VgsNbjimM::jXsPLK(double ROjWHplFXJjOdfSY)
{
    double qfBbPhzpsncFQRHV = -944825.2336780529;
    double zFhxEUvSIyGyN = -17117.80246282828;
    int ubKGbLmXZjpzrgX = 1551287987;
    string gzZYfHDjIqjxzD = string("zJmKTiubgmGmteZlAilpDsHgmzHcmwTbdBktdijvUdbOhmfkcugwHCazQydUkwjGnUPCkycgozbyoNYrXSDEjwQpwmCNtcZUsdwTGafUEbWjqhhvonrkpeLiQCkFkVanbTozlpSYsQWxMmqKodihaQvqXPATeelklphEnfCQqwgRsVJyBalwdIuGWymgVRivGJyxeHykfHSpTAKAkiICdMrrEMcTDRkjc");
    bool IIsZmMeMiCDZVs = false;
    string oYTKhotlVih = string("eoACSuUzJkxeyxnvDnWQnqTlQzzietLwrCTzJyzuvKOSLRhNlHYPPzGZXECJjpySTpOGRtmTYawOcguTlgvgJdbpHwvysQRsRCcTksOxutyccoPYUi");
    string uTcwr = string("SAMbyPMfll");
    bool qHQxIcxiFDkNzTCO = true;
    bool IIixYj = true;

    if (gzZYfHDjIqjxzD < string("zJmKTiubgmGmteZlAilpDsHgmzHcmwTbdBktdijvUdbOhmfkcugwHCazQydUkwjGnUPCkycgozbyoNYrXSDEjwQpwmCNtcZUsdwTGafUEbWjqhhvonrkpeLiQCkFkVanbTozlpSYsQWxMmqKodihaQvqXPATeelklphEnfCQqwgRsVJyBalwdIuGWymgVRivGJyxeHykfHSpTAKAkiICdMrrEMcTDRkjc")) {
        for (int hJkzTWmKu = 1012029573; hJkzTWmKu > 0; hJkzTWmKu--) {
            gzZYfHDjIqjxzD = uTcwr;
        }
    }

    if (IIsZmMeMiCDZVs == false) {
        for (int XjkMPgjiOhNIfi = 661600535; XjkMPgjiOhNIfi > 0; XjkMPgjiOhNIfi--) {
            ROjWHplFXJjOdfSY -= ROjWHplFXJjOdfSY;
            IIsZmMeMiCDZVs = ! qHQxIcxiFDkNzTCO;
            IIixYj = IIixYj;
            IIsZmMeMiCDZVs = IIsZmMeMiCDZVs;
            IIixYj = ! IIixYj;
            zFhxEUvSIyGyN *= qfBbPhzpsncFQRHV;
        }
    }

    if (uTcwr != string("zJmKTiubgmGmteZlAilpDsHgmzHcmwTbdBktdijvUdbOhmfkcugwHCazQydUkwjGnUPCkycgozbyoNYrXSDEjwQpwmCNtcZUsdwTGafUEbWjqhhvonrkpeLiQCkFkVanbTozlpSYsQWxMmqKodihaQvqXPATeelklphEnfCQqwgRsVJyBalwdIuGWymgVRivGJyxeHykfHSpTAKAkiICdMrrEMcTDRkjc")) {
        for (int YCQlPYCBGU = 979940216; YCQlPYCBGU > 0; YCQlPYCBGU--) {
            continue;
        }
    }

    for (int nXrEbrCbXe = 888694412; nXrEbrCbXe > 0; nXrEbrCbXe--) {
        zFhxEUvSIyGyN *= qfBbPhzpsncFQRHV;
    }

    for (int gLtfhRVcZWRVzck = 1516483724; gLtfhRVcZWRVzck > 0; gLtfhRVcZWRVzck--) {
        continue;
    }

    for (int wKIGloLGqb = 503998290; wKIGloLGqb > 0; wKIGloLGqb--) {
        IIixYj = ! IIsZmMeMiCDZVs;
        IIsZmMeMiCDZVs = ! IIixYj;
    }

    return ubKGbLmXZjpzrgX;
}

void VgsNbjimM::BLfhICnfcvkygz(string XQGHApaf, bool NgejhQnF)
{
    bool oZICMyvDj = true;
    double QEiReadt = -582865.345590307;
    double ViyImbJrAEpNOIir = -140594.57215771478;
    double sofhzpWtQYFIiJlU = -687419.3375517499;
    string tsdZtBKmfIMaX = string("QHfEmcLLgXKtukJckbHbhjHIrUboCmBCMjCompouynPDEBtIwUfPsqctijPKwsiCFBWDQlOt");
    int PAXUSkIho = 1307985211;
    int oyqRAS = -45481388;
    double ucQbgGpvKqhac = 368309.25390895695;
    double ZSkZL = -105779.03922043904;
    double DdEuudUrOwPllZp = 714379.4806501674;

    for (int OzbChwgrSVSlr = 1664313778; OzbChwgrSVSlr > 0; OzbChwgrSVSlr--) {
        DdEuudUrOwPllZp = DdEuudUrOwPllZp;
        ZSkZL *= DdEuudUrOwPllZp;
    }

    for (int iiRlXCuas = 1748262445; iiRlXCuas > 0; iiRlXCuas--) {
        tsdZtBKmfIMaX = tsdZtBKmfIMaX;
        QEiReadt += sofhzpWtQYFIiJlU;
    }

    for (int RewuLKPYaKxnv = 1813410243; RewuLKPYaKxnv > 0; RewuLKPYaKxnv--) {
        QEiReadt /= ZSkZL;
        DdEuudUrOwPllZp *= ucQbgGpvKqhac;
    }
}

double VgsNbjimM::UCcPMVgkRgkL(double OvTCSgPWPQkcA, string sqHTLsL, double EigVGgSNiUdsW)
{
    bool jpfITPs = false;
    int hgtbZAgBHEKa = 1179267173;
    int wYDuRmlPz = -1294188234;
    int NNrPULUNbHIRlwwF = 2047597889;
    int uKSEckeiQyhX = 1828311514;
    double WtXsYZjktVR = -938780.6263451109;
    double wWJrqAwBaSQH = 220312.99347876865;
    string MGZtjFzKxuygup = string("uubkslSUPKWHJsfOQHnxOsiWIxrxNrZJTfmDeArirxMiwLEbWFRDywxATnUzBIXyjPUhBxGrronkjKFwUuSVDSPzkXqQMp");

    if (wYDuRmlPz < 1828311514) {
        for (int FcUTjmyOwyrD = 1555543983; FcUTjmyOwyrD > 0; FcUTjmyOwyrD--) {
            WtXsYZjktVR -= WtXsYZjktVR;
            hgtbZAgBHEKa /= NNrPULUNbHIRlwwF;
            uKSEckeiQyhX /= NNrPULUNbHIRlwwF;
        }
    }

    return wWJrqAwBaSQH;
}

int VgsNbjimM::gwKaeUwzZZIXl(bool fjBoCJLH)
{
    string GbvhrTWwkh = string("QIEmRxZfqPgbBOFIvaB");
    string mxbebACbWkZTiqn = string("fQmVkxIMREiHoIOKyeOjhXsHjBCYLToDjYheQYDxPVCreeJPZim");
    string WpvvgIKisN = string("OMiicrbBJETanhgJLkHLsfuInkXKcSoQrEhGmulVxOoGFFfvPeGvMxcWWjQXXfZudLqcQdQEiRHzssacnUolsLUJkkYAQfOVyHeJYPGuommqOLQHDTuywzKJiYVckwaoMjQuYIBLPUtrmdPzmlWcXWOvndcXuIieiTDZaxClgmBGJKtogpMAxoyRmXOjepCKLfbpEPigabBqmkWQrNqkXfdNSeRnHoPxLPiiVGyAArLtJrsXXWdTDm");
    string HPNieAqfVjmvSM = string("VnGrROcDXizJQXTsRklMVhfIvFbwZzWplPRbQMiCHYCNwJSppxuiDsGrQtLIieNCImwqdAvqdiYPTSUgIgvSmEpKsoKLIUKZMcnoeQabKQNkVMtrModHAmPuxMdQpAAxwYAyaCDHulPnkAaselKzOzczIEtLkTfeLNwmEXRWVZkmGEBntkdsKhHsRBvBJdVusnOf");
    double QhTDdYLwyZxFe = -3784.2646896399615;
    int GWeAZnjqRqvhGT = 323987640;

    if (GbvhrTWwkh != string("OMiicrbBJETanhgJLkHLsfuInkXKcSoQrEhGmulVxOoGFFfvPeGvMxcWWjQXXfZudLqcQdQEiRHzssacnUolsLUJkkYAQfOVyHeJYPGuommqOLQHDTuywzKJiYVckwaoMjQuYIBLPUtrmdPzmlWcXWOvndcXuIieiTDZaxClgmBGJKtogpMAxoyRmXOjepCKLfbpEPigabBqmkWQrNqkXfdNSeRnHoPxLPiiVGyAArLtJrsXXWdTDm")) {
        for (int OOClDjk = 1481596516; OOClDjk > 0; OOClDjk--) {
            WpvvgIKisN += HPNieAqfVjmvSM;
            HPNieAqfVjmvSM = GbvhrTWwkh;
            GbvhrTWwkh += HPNieAqfVjmvSM;
        }
    }

    if (GbvhrTWwkh >= string("QIEmRxZfqPgbBOFIvaB")) {
        for (int Julhdb = 441356610; Julhdb > 0; Julhdb--) {
            GbvhrTWwkh = GbvhrTWwkh;
            GbvhrTWwkh = GbvhrTWwkh;
            mxbebACbWkZTiqn += mxbebACbWkZTiqn;
        }
    }

    for (int xAguAgNjHaAIR = 1007813901; xAguAgNjHaAIR > 0; xAguAgNjHaAIR--) {
        HPNieAqfVjmvSM += HPNieAqfVjmvSM;
    }

    if (WpvvgIKisN > string("fQmVkxIMREiHoIOKyeOjhXsHjBCYLToDjYheQYDxPVCreeJPZim")) {
        for (int tDRaNTWQb = 1025738099; tDRaNTWQb > 0; tDRaNTWQb--) {
            mxbebACbWkZTiqn = HPNieAqfVjmvSM;
            mxbebACbWkZTiqn = mxbebACbWkZTiqn;
            WpvvgIKisN += WpvvgIKisN;
        }
    }

    for (int dOjgAAlcXCC = 482431843; dOjgAAlcXCC > 0; dOjgAAlcXCC--) {
        GbvhrTWwkh = mxbebACbWkZTiqn;
        mxbebACbWkZTiqn += HPNieAqfVjmvSM;
    }

    return GWeAZnjqRqvhGT;
}

bool VgsNbjimM::FeunWacMIpMrYr()
{
    string eBPBpGH = string("CFQgkAncKcIJBIuCRbHwcgzwSiGsKnGDUxUcpWhpVLUmbXfZMKcjxUWzQgZNooEhbAyhaFvnDFTJwSONbfLdiRcLCAAeCnIFLyGhtwUvMtxOgBiyRoDVemJNkLjvexTKnkycEPLxdeWTDjLCoPRcwEqSEuJJFXRiUDgzGbkXnFUxLLSpPbjwUlXtyFq");
    double VbCuqhXVSLSl = -680010.7855034822;
    int WKNOksUF = -1992354624;
    string kZzokepq = string("MmneEAndwUDtzdPNBtkSeSdSsTvPgPnqiHrXDsMlPGoKhUnQLKkMgfPzufQMMQuSZnoWvKwzHAJXcZsmXatpmrbiDiPhffzSdaBgUDnabgYvygtKjAeaaelsasaubrbzPglyDkiYQKeqppMDerJTowDySsRpGBbjgQzQBDdINvhJFbjrFAotPOFdQvSXoQUStLwhLYXCGwATrdTukaXIpewjdZtTFQKUTqTInBdpEmnvKzgVBoSJzFpCJf");
    int LhCdG = -295521679;
    double bkEOz = 176383.12041162603;

    if (eBPBpGH == string("CFQgkAncKcIJBIuCRbHwcgzwSiGsKnGDUxUcpWhpVLUmbXfZMKcjxUWzQgZNooEhbAyhaFvnDFTJwSONbfLdiRcLCAAeCnIFLyGhtwUvMtxOgBiyRoDVemJNkLjvexTKnkycEPLxdeWTDjLCoPRcwEqSEuJJFXRiUDgzGbkXnFUxLLSpPbjwUlXtyFq")) {
        for (int GUamIFjAnfHJm = 925300209; GUamIFjAnfHJm > 0; GUamIFjAnfHJm--) {
            bkEOz /= VbCuqhXVSLSl;
            LhCdG += WKNOksUF;
            bkEOz += VbCuqhXVSLSl;
        }
    }

    if (kZzokepq > string("MmneEAndwUDtzdPNBtkSeSdSsTvPgPnqiHrXDsMlPGoKhUnQLKkMgfPzufQMMQuSZnoWvKwzHAJXcZsmXatpmrbiDiPhffzSdaBgUDnabgYvygtKjAeaaelsasaubrbzPglyDkiYQKeqppMDerJTowDySsRpGBbjgQzQBDdINvhJFbjrFAotPOFdQvSXoQUStLwhLYXCGwATrdTukaXIpewjdZtTFQKUTqTInBdpEmnvKzgVBoSJzFpCJf")) {
        for (int cmQplLeyQkY = 1004093416; cmQplLeyQkY > 0; cmQplLeyQkY--) {
            WKNOksUF *= LhCdG;
        }
    }

    return false;
}

bool VgsNbjimM::WmrbFkHqAtEX(string dJSOorXXP, string XurfykGwSwc, bool ntHvsNWSNOWGmuc, string NkNUoeml)
{
    string CDjPOLTeaQkrRu = string("iKXdoiyqzDqpKfwTeGQgQbiwLvMbjQQzUyuzJjPugFDiIhLRIZKWnSOhkUkOEQWJJEYihtlzhMYkQqlP");
    bool XcpsTxi = false;
    string hbtyZpaJjzr = string("CUXHfBFHQUDJ");
    string AwZzDPSGvcj = string("ZZyXeILFohhDTcRerGQihgrLWIKrdrnONMIPDNtIFLFqAsNfPKmmiCWENbdIHnbfYyfCwiVwTUtynGeNgMKNidNivPyVSdhAcxyplKVWsMzXKjjkTLTZkObQkrBrnVXMnHLPIEMtTNlVhZLhPVZtAHjtnSRbreOoVlzvAIOYuWcQuqbXhZnLTkldkVqbSoPIXvxcHUBUELXZH");

    for (int srgpKTeoSQDsmGF = 1007640248; srgpKTeoSQDsmGF > 0; srgpKTeoSQDsmGF--) {
        XcpsTxi = ntHvsNWSNOWGmuc;
        XurfykGwSwc += CDjPOLTeaQkrRu;
    }

    for (int MfKRBDvmymKUJ = 1715133012; MfKRBDvmymKUJ > 0; MfKRBDvmymKUJ--) {
        AwZzDPSGvcj = XurfykGwSwc;
        XurfykGwSwc += dJSOorXXP;
        AwZzDPSGvcj += hbtyZpaJjzr;
        XurfykGwSwc += CDjPOLTeaQkrRu;
        AwZzDPSGvcj = hbtyZpaJjzr;
        XurfykGwSwc += NkNUoeml;
    }

    for (int vMnddS = 682862443; vMnddS > 0; vMnddS--) {
        CDjPOLTeaQkrRu = NkNUoeml;
        dJSOorXXP += dJSOorXXP;
        NkNUoeml += NkNUoeml;
        hbtyZpaJjzr += AwZzDPSGvcj;
        AwZzDPSGvcj = dJSOorXXP;
    }

    if (hbtyZpaJjzr == string("ZZyXeILFohhDTcRerGQihgrLWIKrdrnONMIPDNtIFLFqAsNfPKmmiCWENbdIHnbfYyfCwiVwTUtynGeNgMKNidNivPyVSdhAcxyplKVWsMzXKjjkTLTZkObQkrBrnVXMnHLPIEMtTNlVhZLhPVZtAHjtnSRbreOoVlzvAIOYuWcQuqbXhZnLTkldkVqbSoPIXvxcHUBUELXZH")) {
        for (int jKHyr = 834463805; jKHyr > 0; jKHyr--) {
            XcpsTxi = ntHvsNWSNOWGmuc;
            CDjPOLTeaQkrRu = CDjPOLTeaQkrRu;
            ntHvsNWSNOWGmuc = ! XcpsTxi;
            CDjPOLTeaQkrRu = XurfykGwSwc;
        }
    }

    for (int BEccW = 1698665562; BEccW > 0; BEccW--) {
        XurfykGwSwc += dJSOorXXP;
        AwZzDPSGvcj = CDjPOLTeaQkrRu;
        AwZzDPSGvcj = hbtyZpaJjzr;
    }

    return XcpsTxi;
}

bool VgsNbjimM::VnqmLyMDgfHgGkoA(string xIyswoqLUAuOrBAX, int kpBTpSAFWtyfycl, bool RWpjeinEk)
{
    double qdVkFgtnSoCrzD = -116585.81451459581;
    string brDGVvNZyjkNiMOE = string("FILHLfsICBmdpkmbQxqODYpAChRLEifTocrPbuEpMFtdRPaTHqqQvIfwEafkZFTaNpewNyFQXucZpyUQZCzQeYsiPPMmdABqxLVPVkGrgJBvmSnaALrnJQgySBkvArgqhwDjaArIFgwALAtYCQXDxJkcqLyuCSimzIdJtiVZQGUwgIBFBPQjYEylWvXSljsujcgqTbvLxlpT");
    bool AvtLJtilHE = true;

    for (int PBJGqntvlL = 278863376; PBJGqntvlL > 0; PBJGqntvlL--) {
        AvtLJtilHE = ! AvtLJtilHE;
        RWpjeinEk = ! AvtLJtilHE;
        xIyswoqLUAuOrBAX += brDGVvNZyjkNiMOE;
    }

    for (int XYslxZgYQ = 479075520; XYslxZgYQ > 0; XYslxZgYQ--) {
        kpBTpSAFWtyfycl -= kpBTpSAFWtyfycl;
        xIyswoqLUAuOrBAX = xIyswoqLUAuOrBAX;
        xIyswoqLUAuOrBAX = xIyswoqLUAuOrBAX;
    }

    return AvtLJtilHE;
}

double VgsNbjimM::mJJWTGJLRPgIl()
{
    string sFJmHeYwnRuUoo = string("oxgzbCczqMZKtEnkTzXPtSajbkrckoSleziWLEyWzFwwBzXlbhplcsstbHUtNsDrCYtDxYKFInorzuHLkFClThlyJHHHasXGVtMtGxuqcgLiLqiRgMEwJTALAvIgfKxMFPEvpDyxFDxgYPyraQAclNNLtpfobzZNrCHNAzILkxJDbseKIrrnHPFRpkqjUPxSvTVDmzBAmDdgZEvfoYD");
    bool zWcGYsDtPXoAuw = true;
    double VWVyNEvunCNiJtTt = 299358.345741853;
    string LNUwQbwhW = string("HcEZbUZxXYnIZkdNgChbXBfNwUOVNnfjQvojnSAwDETryGiCdlrOmCdD");
    int YdvkRUEkuIverouR = 1602923496;
    double UyKmdrzp = 629523.3834658922;

    if (sFJmHeYwnRuUoo == string("oxgzbCczqMZKtEnkTzXPtSajbkrckoSleziWLEyWzFwwBzXlbhplcsstbHUtNsDrCYtDxYKFInorzuHLkFClThlyJHHHasXGVtMtGxuqcgLiLqiRgMEwJTALAvIgfKxMFPEvpDyxFDxgYPyraQAclNNLtpfobzZNrCHNAzILkxJDbseKIrrnHPFRpkqjUPxSvTVDmzBAmDdgZEvfoYD")) {
        for (int MNTqSXNrZ = 1233128373; MNTqSXNrZ > 0; MNTqSXNrZ--) {
            UyKmdrzp *= UyKmdrzp;
            sFJmHeYwnRuUoo = sFJmHeYwnRuUoo;
            UyKmdrzp -= VWVyNEvunCNiJtTt;
        }
    }

    for (int PIXAvtzgsgr = 13419602; PIXAvtzgsgr > 0; PIXAvtzgsgr--) {
        continue;
    }

    return UyKmdrzp;
}

int VgsNbjimM::DFxZaGiCEc(double GTHCrX, int suKHvCrlrIcqhk)
{
    int OOSFgiHZuIl = -1942382390;
    bool WAQJazTjDX = true;
    bool wDXIWEqYptYI = false;
    string dKYvBWGXJUwk = string("hBBCoDdXdSxTbxXeYZdM");
    double sdQMjFUBTRuZZa = -768954.7418940666;
    int YPTlSMD = 1990249409;
    double LpyZuZnBUJhax = 359004.01118645404;
    double LLOie = -846431.4454960302;
    double IATxlIuiqJlrzO = -72726.93546695239;
    bool AaOvXYpayRXLsbsb = false;

    for (int lURsceiOFRBkVqG = 1569638855; lURsceiOFRBkVqG > 0; lURsceiOFRBkVqG--) {
        IATxlIuiqJlrzO /= IATxlIuiqJlrzO;
    }

    for (int vxpCae = 1371741816; vxpCae > 0; vxpCae--) {
        IATxlIuiqJlrzO += sdQMjFUBTRuZZa;
        wDXIWEqYptYI = WAQJazTjDX;
        AaOvXYpayRXLsbsb = AaOvXYpayRXLsbsb;
    }

    if (LpyZuZnBUJhax != -768954.7418940666) {
        for (int gZJzKrT = 462469483; gZJzKrT > 0; gZJzKrT--) {
            continue;
        }
    }

    if (AaOvXYpayRXLsbsb != false) {
        for (int AhltARrtivw = 411674472; AhltARrtivw > 0; AhltARrtivw--) {
            continue;
        }
    }

    for (int pOwmbSLmtx = 1990179213; pOwmbSLmtx > 0; pOwmbSLmtx--) {
        sdQMjFUBTRuZZa *= GTHCrX;
        IATxlIuiqJlrzO *= LLOie;
        GTHCrX += GTHCrX;
        GTHCrX += GTHCrX;
        GTHCrX /= IATxlIuiqJlrzO;
    }

    for (int avmQZytqa = 84984311; avmQZytqa > 0; avmQZytqa--) {
        GTHCrX -= LLOie;
        OOSFgiHZuIl -= suKHvCrlrIcqhk;
    }

    return YPTlSMD;
}

VgsNbjimM::VgsNbjimM()
{
    this->jXsPLK(-4408.228908256342);
    this->BLfhICnfcvkygz(string("FQOsdmVYTDHPfqcqwXNpFNlrcWtMWbmhXwPnGfvnlzgeirptoenAcRLmypnBZasBFWjeaqxTDuJIhlLLPRCgRNsePzcgPoniabbjaVvmZRpbdPDCEQromblDxXBSkExAJQqxBKpgCMmzfgFVkjRVFBW"), true);
    this->UCcPMVgkRgkL(708504.2554770963, string("gBospwCSHSpTxFnFxzYSSSEnwieWVzktqllXWNMuVcLBQizLnNeLeWsdORxzLZhZHIVuOgcCjvDybePapdcCKjbqYnHOWMACKtizmURocdUbHQEMLmjulFROqgJJVtNoFskBQVKpCcODBnFRlNBAlbEQwmfIHvhxXgdJcGupLhcIocnSdQZGejMOjWsVdrzhtxGUKKchdDOlArBvOeHWXjjMFgD"), 369497.1765490337);
    this->gwKaeUwzZZIXl(false);
    this->FeunWacMIpMrYr();
    this->WmrbFkHqAtEX(string("bYcERVYYaDN"), string("GkytoWGABNiHLHIfexgmyVBrrwiaJNNQDOZbYHoZweozAgRHYGLF"), true, string("lxEFQdFKqeVAzNRZVNuTojXNqZWcyPeXaFguKwGmQsnBHaHGwFLvYNZOyoXxwFHEYAqrIrfaMRREQQcvEesLdFrSLKmAdUTgHlvZnBIjFoqGrZRUpYVNBIjTMyAcmQLEzqKOsKnDJRvcGefvblBXrKqFZrdeRUmyxFleoYWHwwBThtJJtDzdjuayUCyUzgjEFvlRWCHuUlIDoviRIilZtYmdFOS"));
    this->VnqmLyMDgfHgGkoA(string("qTAofNfyfoIcFIIqwnfYOiFhzvxfRuvyWLQiOyIDgKqYAyoXxAHnDcQvujTsYrxejUiDJRoEVabWqaVXzyYPwHJeZknLMKTMqkQtljuWGUUavyNcoCeJpIuVIFPpEKGdTQKbWCPlioBSwuoFAnvJoQwFFrAYD"), -1789166614, true);
    this->mJJWTGJLRPgIl();
    this->DFxZaGiCEc(-135442.57085328453, 99310397);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sqNBImgpMWbrx
{
public:
    double VggUmWBFCYJdC;
    bool qejMLKXXNPTfWs;
    int wBUjqDnJAjgdyDNL;
    int BZRPqrijl;
    int uRPWW;

    sqNBImgpMWbrx();
    int nfbcLrTi(bool sHAIaI, double PEOxYwlTHQsT, bool EVQyU);
    bool TLCVBDbdjRMjEI();
    string AcHjjtoL();
    double kaSQnkAQawqk(string yMAOezjAQwmjwsob, int RvAbChxAKxq, string VsJszZCLitnGnshs, string LaPSthXg, double cOprTdjDPIYVOhr);
    string DzEnDgU(bool KhMqsXaFJepl, double PbWCuqftAXxAo, double OJoAwFcMjhodh);
    void PCQyxceDMjnVLTKU(double RpCVcirgJSnlek, bool SYwYmIySu);
    void isAtAFrVflPohYe(double zVCNBmhfoSZAJL, double xfmvsabIr, bool FNvvuvWJ, int ZhHzCKxI);
    void tRbnAd(double bdqzHbztxFxNSwj);
protected:
    double wWXcfkzEOtQQfI;
    string bCXKhWy;
    double xhnKUvGSEmlcShZP;

    bool TPboL(bool RsazTrXXwbxo);
    void phwohY(double MgokpKSwwLCBts, bool iaPwejHmyUvc, bool aPENBBRckQdNChnm, bool lWoqJkg, double NlWkiOlXWTpEqWP);
    string DEtLGIAVhVK();
    bool Vjvli(int rrVgr, int XBkFUdfiQFiz, bool yLnHCKfOottJmaH, double lXlqrDEwIAV, double PfSUNRmxjE);
    double hlQMndMf(double CQajMjweyAUs, double loPANMtczcNZI, double OsnNwvje);
private:
    double owBCwTQIZBH;

    string WkPPIaNJbUvxMBbJ(string EriHtPuKwlrMLXuw, int Ujqhg);
};

int sqNBImgpMWbrx::nfbcLrTi(bool sHAIaI, double PEOxYwlTHQsT, bool EVQyU)
{
    int pTYgJikZTgLy = -636344267;
    int XzWQRelbjgx = 1662103501;

    for (int dhZgacH = 431951616; dhZgacH > 0; dhZgacH--) {
        pTYgJikZTgLy /= XzWQRelbjgx;
    }

    if (pTYgJikZTgLy <= 1662103501) {
        for (int sctCBQTw = 2023381435; sctCBQTw > 0; sctCBQTw--) {
            pTYgJikZTgLy += XzWQRelbjgx;
            EVQyU = sHAIaI;
        }
    }

    for (int ZCpVTTRtT = 1880170505; ZCpVTTRtT > 0; ZCpVTTRtT--) {
        PEOxYwlTHQsT /= PEOxYwlTHQsT;
        sHAIaI = EVQyU;
    }

    for (int xDfRMDaaf = 1005739697; xDfRMDaaf > 0; xDfRMDaaf--) {
        XzWQRelbjgx = pTYgJikZTgLy;
        EVQyU = ! EVQyU;
    }

    for (int wFhYQ = 814568605; wFhYQ > 0; wFhYQ--) {
        sHAIaI = ! EVQyU;
        PEOxYwlTHQsT *= PEOxYwlTHQsT;
        EVQyU = sHAIaI;
        pTYgJikZTgLy *= pTYgJikZTgLy;
    }

    if (EVQyU == true) {
        for (int tesBJIUccXep = 825362158; tesBJIUccXep > 0; tesBJIUccXep--) {
            EVQyU = sHAIaI;
            XzWQRelbjgx += XzWQRelbjgx;
            XzWQRelbjgx *= pTYgJikZTgLy;
        }
    }

    return XzWQRelbjgx;
}

bool sqNBImgpMWbrx::TLCVBDbdjRMjEI()
{
    double JWSstzvlUSkttvkM = 655334.8404021773;
    int HupODnaWGVLzDr = 1187932591;
    int OPhmGgycPNccnPmm = 1383362594;

    for (int kFVtPectUBNIJMUF = 870476985; kFVtPectUBNIJMUF > 0; kFVtPectUBNIJMUF--) {
        JWSstzvlUSkttvkM *= JWSstzvlUSkttvkM;
        JWSstzvlUSkttvkM *= JWSstzvlUSkttvkM;
    }

    for (int MaOAlFBNWvwoVB = 267778301; MaOAlFBNWvwoVB > 0; MaOAlFBNWvwoVB--) {
        HupODnaWGVLzDr += HupODnaWGVLzDr;
        OPhmGgycPNccnPmm = HupODnaWGVLzDr;
        JWSstzvlUSkttvkM = JWSstzvlUSkttvkM;
    }

    if (HupODnaWGVLzDr == 1383362594) {
        for (int gpNhaMhjrZCk = 1739024650; gpNhaMhjrZCk > 0; gpNhaMhjrZCk--) {
            JWSstzvlUSkttvkM *= JWSstzvlUSkttvkM;
            HupODnaWGVLzDr = HupODnaWGVLzDr;
            HupODnaWGVLzDr -= HupODnaWGVLzDr;
            OPhmGgycPNccnPmm = HupODnaWGVLzDr;
        }
    }

    return false;
}

string sqNBImgpMWbrx::AcHjjtoL()
{
    bool lbcqO = true;
    double sAIdGdEOCecgLCN = -601363.0152473837;
    string fsnrr = string("TBGWYZCtVygGLzYRXLExTbLzdqVtVhgRPAzZVelhhoqvjbihQwfbPLBPPCdRYLwMeKoyIarIDCZUWUviPpShERHO");
    bool ecmTdgeyvZ = true;
    int ZDitcSkl = -276415333;
    double hkldKfwawsXOf = 486237.8968216362;
    double XqaRgal = -1045138.1890324457;

    if (XqaRgal > -1045138.1890324457) {
        for (int ruHHWGoBxBdwYU = 395972997; ruHHWGoBxBdwYU > 0; ruHHWGoBxBdwYU--) {
            sAIdGdEOCecgLCN += hkldKfwawsXOf;
            ecmTdgeyvZ = ! lbcqO;
        }
    }

    for (int DlePU = 619220091; DlePU > 0; DlePU--) {
        XqaRgal = hkldKfwawsXOf;
        XqaRgal *= XqaRgal;
        hkldKfwawsXOf = hkldKfwawsXOf;
        ecmTdgeyvZ = lbcqO;
        XqaRgal /= sAIdGdEOCecgLCN;
    }

    for (int kJEwfFDtDgWYuQ = 1407405742; kJEwfFDtDgWYuQ > 0; kJEwfFDtDgWYuQ--) {
        hkldKfwawsXOf -= XqaRgal;
        ecmTdgeyvZ = lbcqO;
    }

    return fsnrr;
}

double sqNBImgpMWbrx::kaSQnkAQawqk(string yMAOezjAQwmjwsob, int RvAbChxAKxq, string VsJszZCLitnGnshs, string LaPSthXg, double cOprTdjDPIYVOhr)
{
    bool qQJzjvPC = true;
    int fcMemYzGjkLhSyF = -814094056;
    string lBwqScTmVpbDGUs = string("jDQXSiXMsxmcPKaqqSoDJbFEdYYkkaPidbgxiTjCxKWSwVOqospVFjfbHYapoSKvSxowHwWXNzykIgmZxAKbqlAtkVIJSDqFUDAIqYTTUqlUkUEuuba");
    double rFqhYOBbBwBybew = -1013595.0902751046;
    string wwSvvIxxdbCn = string("fgaMXZCLzYimhrinIhRVQQVFshDOJbDbLbsPrbQssVpgSWlBxEsACRddGGgKxqDDoZsMUHIXvJTKCPjgOhnUVOuJrOJFsCLMvJPwNgBxFjXugRXUqbXdcuYYyjKfTjGVFyplDGDUCPGlpDnywIBQXlvIjKFoJVxWHDIcVhvJdezBlwnAGzPFiKUVmRYWCNwMNCs");
    bool DkrqmqOkSp = false;
    bool PZilTFo = true;

    for (int lBjwWmicVymFNX = 1568491644; lBjwWmicVymFNX > 0; lBjwWmicVymFNX--) {
        continue;
    }

    for (int Gmufau = 1143260809; Gmufau > 0; Gmufau--) {
        LaPSthXg += yMAOezjAQwmjwsob;
        VsJszZCLitnGnshs = wwSvvIxxdbCn;
        DkrqmqOkSp = ! qQJzjvPC;
    }

    for (int cLiYLZLAdSnxX = 1756736657; cLiYLZLAdSnxX > 0; cLiYLZLAdSnxX--) {
        PZilTFo = ! PZilTFo;
    }

    return rFqhYOBbBwBybew;
}

string sqNBImgpMWbrx::DzEnDgU(bool KhMqsXaFJepl, double PbWCuqftAXxAo, double OJoAwFcMjhodh)
{
    string KPsxlgDFVx = string("iURWWnSGiOJZNGPXifafAfVrBbCFYdDIUcrJcoSMhsdrtQJGoSlAwIAwHeSevCVbAfMFyzEQanLuwFaiDrsdDGQJo");
    string anWlarKbJHzDdSHY = string("jYJYaXyXqkKyNADxPREwEMdyZBfcKQiDiRSFxwLejgXSorbRjblDMksObiHNRvkgngvDEiwaBslHWdINDpMQyVwXTLEVnyZbpaXroRfvVnHWMQLKSAryWPthFmwkyyIXZNCowArpvxjDVUtlUqRvvsRSRoEuHRAdlhlTuPzNRXcekVrcDtFMM");
    bool qblGBSIrCr = false;
    string zpXhusjGLtlcYIY = string("MdNeQWmQTFqeznPFYiqGwZkOBAiCrtJAccHyrLiKe");
    double MMYLyaNtX = 962541.6459637306;
    int sHXtKHhK = 1155124314;
    double PCFBDgA = -211026.9178469545;
    string GZYFNENgunorH = string("NCKevKJvDjNtfNlvcfcggqTtoxFeVdMwUfibyWWRRrzMMsjJaikcviLCaQjCFntoGmdRFnjCeDKfIYmYqOLzerNcPzHkKnAdaxMkTzDNVMkmFdUevPFZmpMKTKMzwJswaqICAGnAjyCQFDZqKPhixmaaZVacIfuRxrRbXylLQTveTFtqgLmKrDvtoEDqiKxrkjARqSlGJrUdHIbMIyZDTRKEgJK");
    int ouifTBh = 2073987576;
    double SdTeNmQdChZW = 314442.37858834735;

    for (int MkiPo = 733270874; MkiPo > 0; MkiPo--) {
        continue;
    }

    return GZYFNENgunorH;
}

void sqNBImgpMWbrx::PCQyxceDMjnVLTKU(double RpCVcirgJSnlek, bool SYwYmIySu)
{
    string bJdHGmVham = string("JWNmCKJCRSsNVJHDHQnTGUlPowCmjuRKwdPScklrcKwVTxpMYNqQkplSOwAuGODHXOznKbxnMpgaCpoSksjaCMbVRiGgnIFEBlamnJyLtrAdsEntvGjTKCZXtTJcPpUygRxWiXdNYXnIRIxwxVpBprKzzSqDSBATmAtOGgahedgJIekkgvKdPILoSAYrmkFItROPuuTDETZjZkVHlGUUEyTHgBILLWWsNAXSNRWaNDCpSprSTFkaPpEQVHryO");
    double KVnTLHJCRSTma = 465791.4508434282;
    double gkViKBnXpRKTBD = -166985.35504396862;
    int tWzQYujxMb = 1420252850;
    bool lbaLHr = false;

    if (KVnTLHJCRSTma == 465791.4508434282) {
        for (int qYnGtGOVarpd = 1429070389; qYnGtGOVarpd > 0; qYnGtGOVarpd--) {
            SYwYmIySu = lbaLHr;
            gkViKBnXpRKTBD = KVnTLHJCRSTma;
        }
    }

    if (lbaLHr == true) {
        for (int JcvSJ = 1899848628; JcvSJ > 0; JcvSJ--) {
            lbaLHr = ! lbaLHr;
        }
    }

    for (int ymmRjjTwzdpC = 500794222; ymmRjjTwzdpC > 0; ymmRjjTwzdpC--) {
        continue;
    }

    for (int LtOZfufFikjgrZ = 1917651860; LtOZfufFikjgrZ > 0; LtOZfufFikjgrZ--) {
        KVnTLHJCRSTma /= RpCVcirgJSnlek;
        KVnTLHJCRSTma += gkViKBnXpRKTBD;
        KVnTLHJCRSTma = KVnTLHJCRSTma;
    }

    if (RpCVcirgJSnlek > -166985.35504396862) {
        for (int ecexYZ = 434536125; ecexYZ > 0; ecexYZ--) {
            KVnTLHJCRSTma = RpCVcirgJSnlek;
        }
    }

    if (gkViKBnXpRKTBD == 407377.4556720087) {
        for (int ddiVaEZTb = 1925710914; ddiVaEZTb > 0; ddiVaEZTb--) {
            gkViKBnXpRKTBD /= gkViKBnXpRKTBD;
        }
    }

    if (lbaLHr != true) {
        for (int iSAeWl = 562927171; iSAeWl > 0; iSAeWl--) {
            lbaLHr = SYwYmIySu;
        }
    }
}

void sqNBImgpMWbrx::isAtAFrVflPohYe(double zVCNBmhfoSZAJL, double xfmvsabIr, bool FNvvuvWJ, int ZhHzCKxI)
{
    int fvUryey = -258964313;
    string LHQzWniEigdzzsW = string("MwtMpsZKNEnfjwOzSJWLraBYXzaHvlMkJYyaDIaGSNKklzYyobpYOigQuDUzDTwZxcLspiDyCfAZrnQEt");
    string xdFqlvMba = string("TnRnIgwizYSUHYqTPcIkFwfjKkqucxCqupkQG");
    double ZDSyFCuGQxOoex = 321410.74939404795;
    string qeoeojaNr = string("dogDsTgmWslRFFdNYIfcWUUtCYdYrMCfdItjaTaJMPEeZbAtKmeQIakqwccwzqzyIUopOJYUpajBmrNaxMQJOlpRbmfklTqzlRRlmsqpydkbbWTYLjV");
    string oKDkauvuqZBUWX = string("sdvlJrGcBuvijpMRPsVaxWZwqxZtpgmfZTAkTIxNJnnmwZqPyPsGuGGYiiDjiHvdJxtjxraNYtc");

    for (int XxsjQnJUAglEX = 150552170; XxsjQnJUAglEX > 0; XxsjQnJUAglEX--) {
        zVCNBmhfoSZAJL /= ZDSyFCuGQxOoex;
    }

    if (xdFqlvMba >= string("dogDsTgmWslRFFdNYIfcWUUtCYdYrMCfdItjaTaJMPEeZbAtKmeQIakqwccwzqzyIUopOJYUpajBmrNaxMQJOlpRbmfklTqzlRRlmsqpydkbbWTYLjV")) {
        for (int RkFfZBdNguxZZqc = 183145727; RkFfZBdNguxZZqc > 0; RkFfZBdNguxZZqc--) {
            ZhHzCKxI += fvUryey;
            qeoeojaNr = qeoeojaNr;
        }
    }

    for (int mwiItjzIfHFgzj = 1731238581; mwiItjzIfHFgzj > 0; mwiItjzIfHFgzj--) {
        oKDkauvuqZBUWX = qeoeojaNr;
    }

    for (int ITNNnBuoKbswFbm = 562929936; ITNNnBuoKbswFbm > 0; ITNNnBuoKbswFbm--) {
        oKDkauvuqZBUWX = qeoeojaNr;
        xfmvsabIr -= zVCNBmhfoSZAJL;
        ZDSyFCuGQxOoex += ZDSyFCuGQxOoex;
    }

    if (qeoeojaNr > string("MwtMpsZKNEnfjwOzSJWLraBYXzaHvlMkJYyaDIaGSNKklzYyobpYOigQuDUzDTwZxcLspiDyCfAZrnQEt")) {
        for (int uJrGXkVxn = 1288450752; uJrGXkVxn > 0; uJrGXkVxn--) {
            zVCNBmhfoSZAJL -= ZDSyFCuGQxOoex;
        }
    }

    for (int EfZemAjZ = 1648747470; EfZemAjZ > 0; EfZemAjZ--) {
        continue;
    }

    for (int BqVsMxUIrlEUA = 641156734; BqVsMxUIrlEUA > 0; BqVsMxUIrlEUA--) {
        ZhHzCKxI /= fvUryey;
    }
}

void sqNBImgpMWbrx::tRbnAd(double bdqzHbztxFxNSwj)
{
    string PqAEpyGmttX = string("quXRHwOXwORzcWldwFCasYoFbQTFPivSdnSXfoCYTGUERXbXDgJlFZlZrohPFmGOgkbRQGgwxREnkOtUxVBVJTtOfCMoWIXToNTfcVedBylXAvdxbGhWxjgyfQpDTVVZWobAkOPSCiVcVilWqWFQhbZIyIciZQBrKZmuuKtzAkmzkRTgseECDeV");

    if (PqAEpyGmttX > string("quXRHwOXwORzcWldwFCasYoFbQTFPivSdnSXfoCYTGUERXbXDgJlFZlZrohPFmGOgkbRQGgwxREnkOtUxVBVJTtOfCMoWIXToNTfcVedBylXAvdxbGhWxjgyfQpDTVVZWobAkOPSCiVcVilWqWFQhbZIyIciZQBrKZmuuKtzAkmzkRTgseECDeV")) {
        for (int iVZmT = 1521951625; iVZmT > 0; iVZmT--) {
            bdqzHbztxFxNSwj -= bdqzHbztxFxNSwj;
        }
    }

    if (PqAEpyGmttX >= string("quXRHwOXwORzcWldwFCasYoFbQTFPivSdnSXfoCYTGUERXbXDgJlFZlZrohPFmGOgkbRQGgwxREnkOtUxVBVJTtOfCMoWIXToNTfcVedBylXAvdxbGhWxjgyfQpDTVVZWobAkOPSCiVcVilWqWFQhbZIyIciZQBrKZmuuKtzAkmzkRTgseECDeV")) {
        for (int NQKBLcRedMVBSVb = 528510672; NQKBLcRedMVBSVb > 0; NQKBLcRedMVBSVb--) {
            PqAEpyGmttX += PqAEpyGmttX;
            PqAEpyGmttX = PqAEpyGmttX;
        }
    }
}

bool sqNBImgpMWbrx::TPboL(bool RsazTrXXwbxo)
{
    double SOYBklZjRienoEL = -321069.0703613565;
    double SeOlWTsnVaDncyPw = -799196.4070180644;
    bool aJNcVPPrdPDgf = true;
    string wAQdQrWvKc = string("tSRmFyCsbLLoQXHBaFpHxMIlXjFsfftMQhgrjPyrBTdJkyLswmGTMabipLltAxqgSEQyKjEHqBsGwgIpFmKRlJOJQnLnjFWVxxFBmFdkpDdfOhrKzDqJPnU");
    bool UwJXW = false;

    for (int LpHPjgj = 617828120; LpHPjgj > 0; LpHPjgj--) {
        aJNcVPPrdPDgf = ! aJNcVPPrdPDgf;
        SeOlWTsnVaDncyPw *= SOYBklZjRienoEL;
        SeOlWTsnVaDncyPw -= SeOlWTsnVaDncyPw;
    }

    for (int kthAPFG = 1526882741; kthAPFG > 0; kthAPFG--) {
        UwJXW = UwJXW;
    }

    if (RsazTrXXwbxo == true) {
        for (int jCNRL = 241359630; jCNRL > 0; jCNRL--) {
            SeOlWTsnVaDncyPw = SOYBklZjRienoEL;
            aJNcVPPrdPDgf = RsazTrXXwbxo;
            UwJXW = ! RsazTrXXwbxo;
            aJNcVPPrdPDgf = UwJXW;
            aJNcVPPrdPDgf = UwJXW;
            RsazTrXXwbxo = ! aJNcVPPrdPDgf;
        }
    }

    for (int ikxWIfHPgNAZHlr = 631528814; ikxWIfHPgNAZHlr > 0; ikxWIfHPgNAZHlr--) {
        UwJXW = RsazTrXXwbxo;
    }

    if (UwJXW == false) {
        for (int ewybt = 1457887639; ewybt > 0; ewybt--) {
            SOYBklZjRienoEL += SeOlWTsnVaDncyPw;
        }
    }

    return UwJXW;
}

void sqNBImgpMWbrx::phwohY(double MgokpKSwwLCBts, bool iaPwejHmyUvc, bool aPENBBRckQdNChnm, bool lWoqJkg, double NlWkiOlXWTpEqWP)
{
    bool cuGToUTp = true;
    bool FhFIILpyeshgyr = false;

    if (FhFIILpyeshgyr == false) {
        for (int tDVsjXde = 1380260879; tDVsjXde > 0; tDVsjXde--) {
            cuGToUTp = cuGToUTp;
        }
    }

    if (MgokpKSwwLCBts == 133610.5479862859) {
        for (int FdQbUM = 680306322; FdQbUM > 0; FdQbUM--) {
            continue;
        }
    }
}

string sqNBImgpMWbrx::DEtLGIAVhVK()
{
    bool RYrSLfYTdbPX = true;
    int Rtoqlw = -1934056296;

    if (Rtoqlw == -1934056296) {
        for (int uWrMPN = 40881277; uWrMPN > 0; uWrMPN--) {
            Rtoqlw *= Rtoqlw;
        }
    }

    for (int kBfmWem = 2058859312; kBfmWem > 0; kBfmWem--) {
        Rtoqlw -= Rtoqlw;
        RYrSLfYTdbPX = ! RYrSLfYTdbPX;
        Rtoqlw /= Rtoqlw;
        RYrSLfYTdbPX = ! RYrSLfYTdbPX;
    }

    for (int UlLeRQpoL = 1873884737; UlLeRQpoL > 0; UlLeRQpoL--) {
        Rtoqlw /= Rtoqlw;
        RYrSLfYTdbPX = ! RYrSLfYTdbPX;
        Rtoqlw *= Rtoqlw;
        Rtoqlw = Rtoqlw;
        RYrSLfYTdbPX = ! RYrSLfYTdbPX;
        Rtoqlw -= Rtoqlw;
        Rtoqlw *= Rtoqlw;
        RYrSLfYTdbPX = RYrSLfYTdbPX;
        RYrSLfYTdbPX = RYrSLfYTdbPX;
    }

    if (RYrSLfYTdbPX == true) {
        for (int sdQjwDp = 1117300113; sdQjwDp > 0; sdQjwDp--) {
            Rtoqlw *= Rtoqlw;
            RYrSLfYTdbPX = RYrSLfYTdbPX;
            Rtoqlw += Rtoqlw;
            Rtoqlw /= Rtoqlw;
        }
    }

    if (Rtoqlw >= -1934056296) {
        for (int JBEBIrCPjmJlaw = 939182481; JBEBIrCPjmJlaw > 0; JBEBIrCPjmJlaw--) {
            Rtoqlw = Rtoqlw;
        }
    }

    return string("skBuxirEfEPrLTQdduT");
}

bool sqNBImgpMWbrx::Vjvli(int rrVgr, int XBkFUdfiQFiz, bool yLnHCKfOottJmaH, double lXlqrDEwIAV, double PfSUNRmxjE)
{
    bool RrZIOkR = true;
    int CxOFfMvJfFuRXpDN = -931188319;
    string LgIWXoQUyDNql = string("jQTsawpuwSLiiMROStXoEtKVoewOYNuOBUrwtDkTAoWqBNLQLQtBiACyjvAYPYmekOKuzyympiureXCOAlLbLsBzLcbyeQYEYYmEKomXtyFQoxAoOSAgAsSkamjlNcXnUpqdiwuuuVrZFMkjxmJBGkBvEOFJDAsgHihAERPOwRNWtpfgdRDsaBMnRNoMkqauKGEmboQwonqZUgvzfHKiiLoCwPhZidcTyYnrsRvaAuphSTTCKGVSPwNVbNHjzF");
    bool mznzsj = true;
    double ZLErOYOnTyrEW = 773890.8123872607;

    for (int jLJtCGexsHNizVh = 884279830; jLJtCGexsHNizVh > 0; jLJtCGexsHNizVh--) {
        ZLErOYOnTyrEW = lXlqrDEwIAV;
    }

    for (int CfqCgPHAUgb = 1732169796; CfqCgPHAUgb > 0; CfqCgPHAUgb--) {
        lXlqrDEwIAV = ZLErOYOnTyrEW;
        lXlqrDEwIAV *= PfSUNRmxjE;
    }

    if (mznzsj != true) {
        for (int DpkpKxISoXXiPPmV = 1234985626; DpkpKxISoXXiPPmV > 0; DpkpKxISoXXiPPmV--) {
            ZLErOYOnTyrEW *= lXlqrDEwIAV;
            RrZIOkR = ! RrZIOkR;
        }
    }

    for (int MnzXDBrlYYLeD = 828724414; MnzXDBrlYYLeD > 0; MnzXDBrlYYLeD--) {
        mznzsj = ! mznzsj;
        XBkFUdfiQFiz /= CxOFfMvJfFuRXpDN;
    }

    for (int XafqB = 1506456389; XafqB > 0; XafqB--) {
        rrVgr += CxOFfMvJfFuRXpDN;
        lXlqrDEwIAV = lXlqrDEwIAV;
    }

    for (int ipfYfEAn = 1095406850; ipfYfEAn > 0; ipfYfEAn--) {
        CxOFfMvJfFuRXpDN = XBkFUdfiQFiz;
    }

    return mznzsj;
}

double sqNBImgpMWbrx::hlQMndMf(double CQajMjweyAUs, double loPANMtczcNZI, double OsnNwvje)
{
    bool VyOHH = false;
    int dlyTWZAXiRpMIH = 4480857;
    double UCJtWFFOvGiEJrX = 815871.214294586;
    string siwmItxBrYrFQAaO = string("gbzxcRCOlkFSDdCKqAy");
    string UfvXJskrvAJl = string("k");

    return UCJtWFFOvGiEJrX;
}

string sqNBImgpMWbrx::WkPPIaNJbUvxMBbJ(string EriHtPuKwlrMLXuw, int Ujqhg)
{
    double NCJEtIZcfBDXTQdE = -116974.86212974726;
    int SAqLMWrsUUkL = -981120264;
    bool ChzUj = true;
    string ASbEX = string("mlqpZbNELsETlQxsKRrRGB");

    for (int KHmDC = 1013452481; KHmDC > 0; KHmDC--) {
        SAqLMWrsUUkL = Ujqhg;
    }

    return ASbEX;
}

sqNBImgpMWbrx::sqNBImgpMWbrx()
{
    this->nfbcLrTi(true, 280929.32420544536, false);
    this->TLCVBDbdjRMjEI();
    this->AcHjjtoL();
    this->kaSQnkAQawqk(string("UvLwWCiNnhJavzPlWFsCmLkxgaTjOIXSuFYsLwekhEtkqaTDZbExIjAVOnAwFESlcmljAYkUYJHfnAyKaATrZcmObNoCRRssLwCUwuqUaRfmiguELhVYbSqPQKmjjysnAXALRuEoFjdIrKDOkkUjFYBPJBbHyfVEPweHdjPlYxDEgBpeIbIAjiKHOKPrqCtraNrxztFjcsasHwuwZ"), 496588249, string("fYiUDUvBwaUENLmrzIfHnfVXTNednLhUPNwnMyQxJDqKHricpTWRepdWCaZJqszoYhJJfxLqdMNdUpSIkrpVyvtZLkftDjVbozBTQQlKgEUNneqaXsxdfLigFSBKZLBDECDzClUXRcNLnfMvJTlmUbqeziLkB"), string("aSCCXjsNrsQGxlDROTLcqoAQYrgfkkAYwQOZ"), -836385.4276401475);
    this->DzEnDgU(true, 278586.95799820754, -769655.925333453);
    this->PCQyxceDMjnVLTKU(407377.4556720087, true);
    this->isAtAFrVflPohYe(134671.23560823637, 955045.2050738023, true, -238553436);
    this->tRbnAd(692596.777154475);
    this->TPboL(false);
    this->phwohY(1024158.9179367397, false, true, false, 133610.5479862859);
    this->DEtLGIAVhVK();
    this->Vjvli(-1235385246, 1226560202, false, 404431.1654194852, 962214.7592930361);
    this->hlQMndMf(-1026766.088428113, -899579.5823289795, -485039.870862062);
    this->WkPPIaNJbUvxMBbJ(string("zZZCMlnVXsOySJipWiNovksgxXaGaHoDxhlMIOpwKdrNMnqocDnwMkjolkkAfGWGxBYCbIvAjVWdyJ"), -1761496031);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class coEoGzOwCxXD
{
public:
    string zHnpNGyYRi;
    double NPYwSNZQh;
    bool PIYqAVcXhICaWPI;
    double XREcN;
    double rzdMFyxQasOCuDWm;
    double MYUIqBYsKgyyK;

    coEoGzOwCxXD();
    string JRopm(bool uDStxsOOgZhp, string InOJxSYwcQt, int jOQPsu, double hgpVvNgsuj, int gbLPZRazUAOOT);
    string dgfWRproh();
    string zOwqnF(double wEqzVgWiGmXB);
    double hgKezjTZqFRBwaC();
    void apLTgek(double MdOKcAosFpLpzSo);
    bool ItVvviKoApU(double HUjzmGyxlBOEOJ);
    double SMnOXJVv(bool UlwmhcaNAoSIJN, int PmEhR);
    int BElTiSrYKGmFgl(double PtIzxhVItEqqIPtA, double kcEbqDxx);
protected:
    string iRxXWSMzKZ;
    double BJsSv;

    bool pfZipsvcoaEqnjs(bool kxtpJvDXx, bool auWmd, bool WUSeFPMbMpQXZUbc);
    int bnrMafc(double rxcsyIemjDgnEhAF);
    bool VPVEj(string rvRSUJpWCpMpogG, int yVGonuVLijthR, string eXByqJZcy);
    int gmmaFlblPTNi(double GLfSOHfRQB, int UBHxZKUnngN, int GhkfaNKeS, string qbjRTqNr);
    string eSaAuG();
private:
    int gZVInk;
    double ORVIRNQLWVsKuJ;
    int VleBNfGJOm;
    bool QnMpUHElta;
    double YrXcpuNiiWXATrNS;

};

string coEoGzOwCxXD::JRopm(bool uDStxsOOgZhp, string InOJxSYwcQt, int jOQPsu, double hgpVvNgsuj, int gbLPZRazUAOOT)
{
    double ORlrKqwNYAIbjTb = 707849.0758671341;
    int rnnVKm = 1247805393;
    bool LQsiq = false;
    double SyHjV = 621576.0480353697;
    int QbwHKZPZ = 1816044846;
    string hYkpz = string("ANOQuBEmTzoMWgxqWfbrqrkqkDUusmWczFBEFGCohAmlJqsjaaNVLKhbAuduPxaTEpbIyWonMZsMZWarQtJUiPiViMNRtrMUqDlijdcbcIEYluGOUgFWCQzDigrpWQzYaOsQceyGEWhJHEJrYnqmWuuzDvqnJeHKVmrpbapZmOGXMnJetjjpTZIRhadXpPcmDCuWkUamqMRQbMjPIOWlvUcQtMGwXHaJZXvxwIfcvtPUXkbGneRpUPHsm");
    double TJWcrnLuadGvpUU = 181913.6022326989;
    double DWFuAvOLrb = -318894.0786824035;
    bool WOLkPJQ = false;
    bool xaEbxXq = true;

    for (int pshKjNBbpbE = 109180227; pshKjNBbpbE > 0; pshKjNBbpbE--) {
        gbLPZRazUAOOT *= rnnVKm;
        xaEbxXq = xaEbxXq;
        DWFuAvOLrb = ORlrKqwNYAIbjTb;
    }

    if (LQsiq != true) {
        for (int FYIohCdND = 1757980361; FYIohCdND > 0; FYIohCdND--) {
            gbLPZRazUAOOT *= rnnVKm;
            xaEbxXq = ! xaEbxXq;
        }
    }

    for (int GsPPmTQy = 752145519; GsPPmTQy > 0; GsPPmTQy--) {
        ORlrKqwNYAIbjTb *= hgpVvNgsuj;
        uDStxsOOgZhp = ! WOLkPJQ;
    }

    for (int pkUeUTijMUffiL = 364583169; pkUeUTijMUffiL > 0; pkUeUTijMUffiL--) {
        xaEbxXq = ! WOLkPJQ;
        InOJxSYwcQt = hYkpz;
        rnnVKm /= jOQPsu;
    }

    return hYkpz;
}

string coEoGzOwCxXD::dgfWRproh()
{
    string CwkNmdnviU = string("OkRXNwqZwvXSwZTHNWGsiboRoFxgOEuQduJaAWGPxaIxbSlsooiNPPeYzparFgXxhmHNZLAAzwxevVDYpAyXMYBDVjDxYZczLmfxy");
    int fCYuKdrTJs = 142852506;
    double dxijA = 350212.53582665516;
    int rTybueuphgwCo = -1507864999;
    bool ChzeRCkE = false;

    for (int kBQCUBii = 1165722824; kBQCUBii > 0; kBQCUBii--) {
        continue;
    }

    for (int CaUnVphQiLMs = 2021972074; CaUnVphQiLMs > 0; CaUnVphQiLMs--) {
        continue;
    }

    for (int oYEbTyAcCaW = 1454783307; oYEbTyAcCaW > 0; oYEbTyAcCaW--) {
        ChzeRCkE = ! ChzeRCkE;
    }

    for (int DJkykMfIKyMpJ = 1884560867; DJkykMfIKyMpJ > 0; DJkykMfIKyMpJ--) {
        fCYuKdrTJs = rTybueuphgwCo;
        CwkNmdnviU += CwkNmdnviU;
        rTybueuphgwCo /= rTybueuphgwCo;
    }

    if (CwkNmdnviU > string("OkRXNwqZwvXSwZTHNWGsiboRoFxgOEuQduJaAWGPxaIxbSlsooiNPPeYzparFgXxhmHNZLAAzwxevVDYpAyXMYBDVjDxYZczLmfxy")) {
        for (int xkZsFtx = 1557242307; xkZsFtx > 0; xkZsFtx--) {
            rTybueuphgwCo /= rTybueuphgwCo;
            rTybueuphgwCo -= fCYuKdrTJs;
        }
    }

    return CwkNmdnviU;
}

string coEoGzOwCxXD::zOwqnF(double wEqzVgWiGmXB)
{
    string HYeiKIyeumCdykj = string("MDxWtoAuHNWbdPQnEDSQQKDiSVUptISmMcbtwTUYqWcHipqCfrUjrwHEZwScXCiRDSQMtGcbFqaRecxdMroJezlElpRTuyIpKqoKhIl");
    bool tiBsNhgnfsoFCC = false;
    string SqkgOzEY = string("xWYdCtrCeGOhIpYnkmcWqlrklMXtDeDMPtWTSYwYIZaNFVDwhhNIRkSwvoKnwGSbKoMQoRyFuCYUpPSmkwmefELTCWsfkRNnUsdEVpDyfLqPNBWZaONNxlWaxegYibUEJfLbzysWbmiDiwzVMsWhHGLagkPxduPlJffLRfquLITPdoLCKVaEtkudiaxsIcyNdAUJAAxEqFFAXoTrVCvXEYnhhKQeQKlgGPUTvaOWgpezcYCrGOLHb");
    bool yYGGXoas = false;

    for (int LybWWkL = 386349745; LybWWkL > 0; LybWWkL--) {
        HYeiKIyeumCdykj += HYeiKIyeumCdykj;
        SqkgOzEY += HYeiKIyeumCdykj;
        HYeiKIyeumCdykj = HYeiKIyeumCdykj;
    }

    for (int MpRHRj = 1755313756; MpRHRj > 0; MpRHRj--) {
        wEqzVgWiGmXB *= wEqzVgWiGmXB;
    }

    for (int ehwvpUtasKxB = 74953137; ehwvpUtasKxB > 0; ehwvpUtasKxB--) {
        continue;
    }

    return SqkgOzEY;
}

double coEoGzOwCxXD::hgKezjTZqFRBwaC()
{
    int DwQcdDmWDd = 664551311;
    string dpPySgrFFpOJjYH = string("jSbGfwuAdslWlqzywBzMjaCrpOUKJvoRbsZFUirdequgvgmB");

    if (DwQcdDmWDd == 664551311) {
        for (int DXKoycMyYLUuwP = 367620520; DXKoycMyYLUuwP > 0; DXKoycMyYLUuwP--) {
            DwQcdDmWDd = DwQcdDmWDd;
            DwQcdDmWDd -= DwQcdDmWDd;
            DwQcdDmWDd /= DwQcdDmWDd;
        }
    }

    return -831974.9494214825;
}

void coEoGzOwCxXD::apLTgek(double MdOKcAosFpLpzSo)
{
    double IyjwVOZtFhoY = -471701.2755378983;
    double cEIIwIxQloaPb = -644287.3494765039;
    bool pEYphNNNuQa = false;
    bool mTwotyqN = false;
    bool tOtoIMAzRky = false;

    if (MdOKcAosFpLpzSo != 984233.3655712064) {
        for (int ydmAVVlYjVHdi = 251832582; ydmAVVlYjVHdi > 0; ydmAVVlYjVHdi--) {
            pEYphNNNuQa = pEYphNNNuQa;
            MdOKcAosFpLpzSo *= cEIIwIxQloaPb;
        }
    }

    for (int jAEhiomb = 885947979; jAEhiomb > 0; jAEhiomb--) {
        pEYphNNNuQa = mTwotyqN;
        cEIIwIxQloaPb *= cEIIwIxQloaPb;
        mTwotyqN = ! pEYphNNNuQa;
        tOtoIMAzRky = ! mTwotyqN;
    }

    if (IyjwVOZtFhoY <= 984233.3655712064) {
        for (int QSuHZ = 1163705443; QSuHZ > 0; QSuHZ--) {
            MdOKcAosFpLpzSo /= MdOKcAosFpLpzSo;
            MdOKcAosFpLpzSo *= MdOKcAosFpLpzSo;
            mTwotyqN = pEYphNNNuQa;
            IyjwVOZtFhoY *= MdOKcAosFpLpzSo;
        }
    }
}

bool coEoGzOwCxXD::ItVvviKoApU(double HUjzmGyxlBOEOJ)
{
    double FJDeEBS = 658247.1477157491;
    int LTVUVcmzILg = -980256662;
    double HeotBffcsTOcrDMQ = 264326.20408364316;
    double bExZINyrprwPRtIh = 405279.3747361626;
    double nJsciaWUeYwb = 30335.743914134116;
    string rLfWUYLxPABzq = string("SYmsohjbeXckUGJuKOgMbATcAUfxBvhYBANCIdJpmfWAByblBsBcbfXUTmnNEhGzeJzlARLCDqYQOlJydHCZVfkTdASkZEeKViDRdntZCLlCYURKBbBLRINTWKKTLuRrICm");
    int MaRbjPmKhnXN = -975358257;
    int AbdXpgvO = 1906303050;
    int XAUZCZkZAliMbpCy = 1415421098;

    for (int vRzRasu = 604172214; vRzRasu > 0; vRzRasu--) {
        AbdXpgvO += XAUZCZkZAliMbpCy;
        HeotBffcsTOcrDMQ += FJDeEBS;
        MaRbjPmKhnXN += MaRbjPmKhnXN;
    }

    for (int NZYAwLEPXP = 766140422; NZYAwLEPXP > 0; NZYAwLEPXP--) {
        continue;
    }

    for (int TXihKkbyUz = 1186752758; TXihKkbyUz > 0; TXihKkbyUz--) {
        HUjzmGyxlBOEOJ *= bExZINyrprwPRtIh;
        HUjzmGyxlBOEOJ *= HUjzmGyxlBOEOJ;
    }

    if (XAUZCZkZAliMbpCy > -980256662) {
        for (int sAyXsxWHIW = 91780733; sAyXsxWHIW > 0; sAyXsxWHIW--) {
            HeotBffcsTOcrDMQ -= HeotBffcsTOcrDMQ;
            FJDeEBS += HeotBffcsTOcrDMQ;
            MaRbjPmKhnXN /= LTVUVcmzILg;
        }
    }

    return false;
}

double coEoGzOwCxXD::SMnOXJVv(bool UlwmhcaNAoSIJN, int PmEhR)
{
    int FagOtQu = 1329974667;
    int fEuDzjgyQdsDsayP = 1660514984;
    int CNgDaitNQWQhjYo = -748241243;
    bool erZLqNCpgBEO = true;
    bool TbqgKGRTukKPI = false;
    int RiAqxVrVGIfMeqL = 1171429688;
    int peKTbBrTx = 1187397154;
    string LLpbZcAwgWGS = string("MDdTrOzNfuwqvdNsNaPNipQAUQevwDSTCqirYPrrhUQyjaAFfCLq");

    if (fEuDzjgyQdsDsayP >= 1187397154) {
        for (int AepOBjJCEyTQ = 1587064070; AepOBjJCEyTQ > 0; AepOBjJCEyTQ--) {
            peKTbBrTx *= peKTbBrTx;
        }
    }

    if (FagOtQu != 1329974667) {
        for (int SYpcBsTiNPdPYc = 1108895848; SYpcBsTiNPdPYc > 0; SYpcBsTiNPdPYc--) {
            PmEhR += CNgDaitNQWQhjYo;
            FagOtQu /= FagOtQu;
            CNgDaitNQWQhjYo -= FagOtQu;
        }
    }

    if (CNgDaitNQWQhjYo == 1187397154) {
        for (int xPcwgLGxTDVPI = 1994235833; xPcwgLGxTDVPI > 0; xPcwgLGxTDVPI--) {
            peKTbBrTx *= PmEhR;
        }
    }

    if (CNgDaitNQWQhjYo > 1187397154) {
        for (int zyGGJSYWgtjZZaR = 1262108990; zyGGJSYWgtjZZaR > 0; zyGGJSYWgtjZZaR--) {
            CNgDaitNQWQhjYo = PmEhR;
            peKTbBrTx += PmEhR;
            fEuDzjgyQdsDsayP -= fEuDzjgyQdsDsayP;
            CNgDaitNQWQhjYo *= PmEhR;
        }
    }

    return -438295.48434477294;
}

int coEoGzOwCxXD::BElTiSrYKGmFgl(double PtIzxhVItEqqIPtA, double kcEbqDxx)
{
    bool hXsKejtk = true;
    bool yiNhgatKzYCQ = true;
    double lLCvOhjqLCY = 243614.5282160366;
    string pjrvdrOYDHtInU = string("EAkkNvQuDnOIsWMsYLxlDsTEopRUUWvnRbnpcwYLpCyWFEyqvEItLBrbRkcXYSaawGeUptPDrJMeJfDRCEvzngTwzI");

    for (int BYSacya = 1418721388; BYSacya > 0; BYSacya--) {
        continue;
    }

    for (int nsvFZdYy = 185809698; nsvFZdYy > 0; nsvFZdYy--) {
        kcEbqDxx /= lLCvOhjqLCY;
    }

    for (int tjBsxbLSVkG = 1403334221; tjBsxbLSVkG > 0; tjBsxbLSVkG--) {
        pjrvdrOYDHtInU += pjrvdrOYDHtInU;
    }

    return -727972282;
}

bool coEoGzOwCxXD::pfZipsvcoaEqnjs(bool kxtpJvDXx, bool auWmd, bool WUSeFPMbMpQXZUbc)
{
    bool LEDyEOxydqncTc = false;
    int wCKUCcQ = 2098476856;
    bool bQhULF = true;

    for (int rSaFiIPG = 1475248204; rSaFiIPG > 0; rSaFiIPG--) {
        kxtpJvDXx = WUSeFPMbMpQXZUbc;
        LEDyEOxydqncTc = ! LEDyEOxydqncTc;
        auWmd = ! auWmd;
    }

    if (kxtpJvDXx == true) {
        for (int mcuCuQfB = 147657; mcuCuQfB > 0; mcuCuQfB--) {
            kxtpJvDXx = auWmd;
        }
    }

    return bQhULF;
}

int coEoGzOwCxXD::bnrMafc(double rxcsyIemjDgnEhAF)
{
    double HJadXkevaM = 896798.7522827878;
    string tXKLZGQuK = string("KZtyGDIVNNkMpsWFojXRynMKOqOhvTjIjPRcWUcDDyhPHgRetjwiiCFAUFwBAsEptqFSBedcKpgxNheCUfzaTnaCoRxAQhlhczabhIjpynCkpxYBShgxKrgQKNntuZ");
    double gjprFOY = 335534.8720986355;
    int suzJiACew = -270882806;
    string cwETRqZpyBcZ = string("XFbIHtbTJwIAhZkbNzzLtUKoIFYcIqZRPSHcmWLHtcfhFhlzRTQedrExCxNvCSiKTXliEBsiibBbdSogutBuXzcDQraRBOCrpzOCCnDfeZtFrhmooVpEwOQqChazPXxLmDxFmeNdSpgHfQDruxYLggPVooqhrgSogxcuQmtbmHwTNRNhONBmqgsOuUvRqIDHZaWnuYLkuRQCOwrLCMgIKkezzmBkvdoSGCHuEunBUAkZiMjUHaXWUdoMzlaUbF");
    bool fGhgCuTT = false;
    bool MqvVMJMpZzTlZFb = false;

    for (int MeEoX = 129177523; MeEoX > 0; MeEoX--) {
        continue;
    }

    for (int TesqXkWwtKTBWJl = 977262635; TesqXkWwtKTBWJl > 0; TesqXkWwtKTBWJl--) {
        cwETRqZpyBcZ = cwETRqZpyBcZ;
        gjprFOY += HJadXkevaM;
        cwETRqZpyBcZ += cwETRqZpyBcZ;
        MqvVMJMpZzTlZFb = ! MqvVMJMpZzTlZFb;
    }

    if (suzJiACew >= -270882806) {
        for (int MUMmu = 445813236; MUMmu > 0; MUMmu--) {
            suzJiACew = suzJiACew;
            HJadXkevaM = HJadXkevaM;
        }
    }

    return suzJiACew;
}

bool coEoGzOwCxXD::VPVEj(string rvRSUJpWCpMpogG, int yVGonuVLijthR, string eXByqJZcy)
{
    int PdPmNgnSVO = 147918855;
    bool pMvKcuFaWINza = false;
    double dhLxHHzHzmQYUhkz = -829586.9383564781;
    int nuaWFtoLE = -1383237561;

    for (int fjAFNF = 1041502087; fjAFNF > 0; fjAFNF--) {
        PdPmNgnSVO /= yVGonuVLijthR;
        pMvKcuFaWINza = pMvKcuFaWINza;
    }

    if (nuaWFtoLE <= -1383237561) {
        for (int zQcIv = 957942816; zQcIv > 0; zQcIv--) {
            eXByqJZcy += rvRSUJpWCpMpogG;
        }
    }

    for (int VWbfNvzasYbROkv = 1424453291; VWbfNvzasYbROkv > 0; VWbfNvzasYbROkv--) {
        continue;
    }

    if (nuaWFtoLE > -1383237561) {
        for (int ICKKucSVDozIS = 38250373; ICKKucSVDozIS > 0; ICKKucSVDozIS--) {
            continue;
        }
    }

    for (int jhlxAR = 2120768504; jhlxAR > 0; jhlxAR--) {
        continue;
    }

    return pMvKcuFaWINza;
}

int coEoGzOwCxXD::gmmaFlblPTNi(double GLfSOHfRQB, int UBHxZKUnngN, int GhkfaNKeS, string qbjRTqNr)
{
    string OntBMgpGFHATcbmx = string("DvbYVmQzqcmEUmwmasjTLmisuvJFeBKTpWTafSqsalUtDIaXDdumQayXXUrXSxEsbTdvGRAOFsuFnBjhsQXxazVVVzhyyjOjNfCPuymLqWDNZtlHVXsgzPvRftYaoMrMSZYtTaYKzVEIjTNhDyZSrXALPOAfFlfUWXjyVwUGpwoMwtvGqFcLYDPcGLavWqNuRZvUrYofYJNZndYDi");
    bool vyLPOLALRUgcYgn = true;
    int vbIJdLL = 1347197763;

    if (UBHxZKUnngN > 1347197763) {
        for (int gzznbnJXoABR = 1304460803; gzznbnJXoABR > 0; gzznbnJXoABR--) {
            GhkfaNKeS -= UBHxZKUnngN;
        }
    }

    if (UBHxZKUnngN <= -1711785711) {
        for (int dtlgtgbDGVmIY = 1315751442; dtlgtgbDGVmIY > 0; dtlgtgbDGVmIY--) {
            vbIJdLL /= GhkfaNKeS;
            GhkfaNKeS = GhkfaNKeS;
            GhkfaNKeS -= UBHxZKUnngN;
        }
    }

    for (int LDzOpZNjynYbyTMF = 696589205; LDzOpZNjynYbyTMF > 0; LDzOpZNjynYbyTMF--) {
        vbIJdLL = GhkfaNKeS;
    }

    for (int ZYKXPMCtie = 1405218858; ZYKXPMCtie > 0; ZYKXPMCtie--) {
        vbIJdLL *= GhkfaNKeS;
    }

    if (vbIJdLL < -1711785711) {
        for (int JkxFCxmwhlNf = 899379552; JkxFCxmwhlNf > 0; JkxFCxmwhlNf--) {
            vbIJdLL *= UBHxZKUnngN;
            OntBMgpGFHATcbmx += qbjRTqNr;
            vyLPOLALRUgcYgn = ! vyLPOLALRUgcYgn;
        }
    }

    return vbIJdLL;
}

string coEoGzOwCxXD::eSaAuG()
{
    double PNdogNGaUBa = -101221.26182654264;
    int IAeSEEDxZnkk = 2060807875;

    if (PNdogNGaUBa > -101221.26182654264) {
        for (int YnuULtg = 1480790416; YnuULtg > 0; YnuULtg--) {
            PNdogNGaUBa += PNdogNGaUBa;
        }
    }

    if (PNdogNGaUBa < -101221.26182654264) {
        for (int chIHuEvpktCvp = 1812931849; chIHuEvpktCvp > 0; chIHuEvpktCvp--) {
            PNdogNGaUBa *= PNdogNGaUBa;
        }
    }

    for (int TcTccDDsaUmnRnjy = 188208552; TcTccDDsaUmnRnjy > 0; TcTccDDsaUmnRnjy--) {
        IAeSEEDxZnkk -= IAeSEEDxZnkk;
        PNdogNGaUBa /= PNdogNGaUBa;
    }

    for (int zsBzlRbXT = 1490886406; zsBzlRbXT > 0; zsBzlRbXT--) {
        PNdogNGaUBa += PNdogNGaUBa;
        PNdogNGaUBa += PNdogNGaUBa;
    }

    return string("hECXXVwluFtqeGUJopcESXFPAaiFTxCRuqUcJBiWGYRlVKCcfwaHqejzgmTtwMjtOaZZgzmSIsfdNGqttnszLWrVOXanEAkCoklbvuYeKJzZShCoqyLrpTJMFdLNZLgqPuLmfPxRQyAzZxdyJDvgjhRFuzAIDXSvqPmnfNVMpslKCOTrePfLLRoBbToVoeTIxghozqWpNSTjSdfpPeSgPvguZxokfjMqjOYAFoeNwvr");
}

coEoGzOwCxXD::coEoGzOwCxXD()
{
    this->JRopm(true, string("zHoSchtamYjULOxIPpYeSHwgaLLDatHVtwzechoEvKJORlQuMfKzZptwQAdgzKleBgahwelBcPykxpynttLQpdVnpXJsGOzZsrrnKoeiHqwnYveAjKBdznPYoYxgUpTrcTpOpZMgXeZYRaVQMchLBjXOAIUKhIkClEkOpatbSkEQ"), 1988265984, -756000.0894082171, -1079557812);
    this->dgfWRproh();
    this->zOwqnF(806799.0238033906);
    this->hgKezjTZqFRBwaC();
    this->apLTgek(984233.3655712064);
    this->ItVvviKoApU(206937.8606670754);
    this->SMnOXJVv(false, -1742631241);
    this->BElTiSrYKGmFgl(-256088.19248177577, 367485.2601635612);
    this->pfZipsvcoaEqnjs(true, true, true);
    this->bnrMafc(642120.3786643995);
    this->VPVEj(string("LoyzubLInNzYSNztNLpzPjxwPmwMlRnIFAJEMcLchrPmFUUHluUyMcFuyaiUrltyUHvhXqRXZmDxbPcPOBTVYsUyYgwqqMbXwRUxMZtgOiPHqcBeRzIpjDFUPyHlquuFnfYMvibvVZYfhjdtmOBXmbOgXxPVPtruCjpCiQIwkIZSiNEnjTQahujZWPmKNqWOQdWlEFGVHoectyNoWhcfnaKgakUnnmJGsUfbDeMRDWvagSubfyGkNRmhyNuKXO"), -401808521, string("AjhuAjPwxvtXohDEuCmsXbNgqXyBPCKYzgodeIUqPtjwuEJGcTPlYEMMtlxhkSBBOwcFnkhzPJTrtJHjzvQIchSSfWrutoWJjObuILgtgj"));
    this->gmmaFlblPTNi(712761.0152537171, -1711785711, 54954785, string("xJJUjqrqsFKpyRpbJxsvbqohyaDnUbdEdrBIgpEADBXmZdPobebCtkwdSWiLmQeQfoziBzveFCoZSHiIsDtlIrHaUudXKIaehBUbOi"));
    this->eSaAuG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LWcUHRwHYvIIDvlv
{
public:
    bool nFJeOm;
    int ZieAcCs;
    int yzvvFusgWGv;
    string WeeZRa;

    LWcUHRwHYvIIDvlv();
    void KVzeUOCEXzNPZQ(int SUvqR);
protected:
    double xxyhNVM;
    int VytpXLxQXKUBI;
    double qLJAMCCBMD;
    double KiOFqeINkWy;
    string ZyzvtJV;
    bool qVBtwiKekzUozZCE;

    int uYzBubBKpRASk(int UtsLEktqJxlPxRy, int GbQgrtN);
private:
    string xmhnWuzn;
    bool tETOqmh;
    string FknqLxdProDczKn;
    double szJHpmYGdxlIty;

    string MOUMUFq(double mVYBg, string YfARLArrXuNgxkzX);
    void CiukO(bool qrnMQUbDnmY, string nFVNt, int yGprPXusc);
    int tOnost(bool KilhOquSMrOdgUTa, string RqNPShyOz, string NRZCbGNoNbz, int fUGiARHGukvmR);
};

void LWcUHRwHYvIIDvlv::KVzeUOCEXzNPZQ(int SUvqR)
{
    bool skxTZKxm = false;
    int WLDSpFLgKLBMbJ = 79086112;
    bool EmqAzgto = false;
    double pxQmAmbb = 220412.85680808645;
    bool vvLvg = true;
    bool OzxRSQMTVyiTnQ = true;
    double CJQYTNJRx = 302133.59999146644;
    double iOtoIo = -1006165.3984091572;
    string WiLmMo = string("mPiTSNdhyRsdvlzhRvQZPTSlzSrTJSykYxxTdpOBDEHtZgygZfGZzHlOhamPvE");
    bool lZWXqBDoljMDBe = false;
}

int LWcUHRwHYvIIDvlv::uYzBubBKpRASk(int UtsLEktqJxlPxRy, int GbQgrtN)
{
    double alXdoEFEmVng = 87492.22054883643;
    string cSQgO = string("ohDjlVQUeJaVUfNgoTWeapEXnQsUBs");
    string TLHfQBDnCtcYL = string("MgfoEQKjicAZhkjQmfnrwoSzxHziFSPgxNezwZAOxNmdjWtQytpzvCWjwkoVbDdtsIAFksHelXTMpxjrSPQdhOhIvCNqgxrsjpwihxTdZ");
    int lZCJVxATNaInlEdh = -1365566230;
    bool rKhCwEJhwm = false;

    if (GbQgrtN == -1365566230) {
        for (int fbzuMRlRvI = 1840860842; fbzuMRlRvI > 0; fbzuMRlRvI--) {
            continue;
        }
    }

    return lZCJVxATNaInlEdh;
}

string LWcUHRwHYvIIDvlv::MOUMUFq(double mVYBg, string YfARLArrXuNgxkzX)
{
    bool lPLOJ = false;
    bool PQnkTjMWQTwHxb = true;
    bool xuxNzSLQOVZgBM = false;
    int pTrrcxFv = 1394283597;
    string dJtYp = string("JdRNdSdeEaKmurSQqfeOIFfMhVEeqpmescScTVURKjxLnligBlaYSQylzewGGcCAcrloWSlnuOvzHnqBWQVQcHuOBGfvpvDfltEmfeAfAXkgsQHjgmbMcwDniawMLVJqoWBwTGTWCaUFBFYvSqbMmrEfzyLGhhviVoIUyikzXeNCHqXiujWFNfAlrGtcdlGkYcyQDSOycZEqUfjqVtDciEJNlLO");
    int VlNvpFMqMGHgk = -34239233;
    int pFYGitZqxzpVZFtv = -2040763051;
    bool IiBrJHAkNLXU = false;
    double HekoptquzOK = 168455.21060269658;

    for (int IfHbOYcLuB = 2076531658; IfHbOYcLuB > 0; IfHbOYcLuB--) {
        continue;
    }

    for (int BupHdK = 940967798; BupHdK > 0; BupHdK--) {
        pTrrcxFv += pFYGitZqxzpVZFtv;
    }

    for (int HxFWrZYhGl = 532244093; HxFWrZYhGl > 0; HxFWrZYhGl--) {
        continue;
    }

    return dJtYp;
}

void LWcUHRwHYvIIDvlv::CiukO(bool qrnMQUbDnmY, string nFVNt, int yGprPXusc)
{
    double vXfhuyBVFIBRa = -728291.3001476583;
    double MgfKDlD = -696423.2533105222;
    double cueZJDqpZBv = -457307.44085725705;
    string KvmKbRsNsjz = string("muTuXLqdMqztAmnsNsLRBubRjECGtkJuZVaFVvZjukcxIfIoAPRkmDReLHEoduLoQRQnBJYPWboXnmERQdjVTCLrGJJZxvsLWWWJnxnHFYSHhmWZjSDTPnkKtrKnVNNDgBgiFhdnksKgIZPcgReseq");
    string xPxtYMOLlyja = string("MOJMqMtvvsjYbGRuIrVZcvsRnKoQQANDvIRrJMeMHNyaGBmWmBrYXQxiZwcgEHOACUmySweHkMehSruRucELYHbezVyHTYPjyqxXgSaqwtlSFjrruzLyvloBRArGmqnKndgFpbyGPmdrTIKSbjtgHnPwoItvovyIbYHYbRqqvZARVcquTgC");
    string WLmJmbq = string("qYyhSvuldFXYfiSTkXVaoivuUTjBtpkbnzSgCRfkkxhetOWsZfccSYh");

    for (int CKpqTP = 233485885; CKpqTP > 0; CKpqTP--) {
        xPxtYMOLlyja += nFVNt;
        WLmJmbq += xPxtYMOLlyja;
    }

    if (cueZJDqpZBv <= -457307.44085725705) {
        for (int zJvDEeCJkSJqn = 365001053; zJvDEeCJkSJqn > 0; zJvDEeCJkSJqn--) {
            vXfhuyBVFIBRa = vXfhuyBVFIBRa;
            vXfhuyBVFIBRa = MgfKDlD;
        }
    }

    for (int ARNAAwXr = 1308189127; ARNAAwXr > 0; ARNAAwXr--) {
        nFVNt += KvmKbRsNsjz;
    }

    for (int TjQsAnsslOX = 487681263; TjQsAnsslOX > 0; TjQsAnsslOX--) {
        MgfKDlD -= vXfhuyBVFIBRa;
        KvmKbRsNsjz = KvmKbRsNsjz;
        vXfhuyBVFIBRa -= vXfhuyBVFIBRa;
    }
}

int LWcUHRwHYvIIDvlv::tOnost(bool KilhOquSMrOdgUTa, string RqNPShyOz, string NRZCbGNoNbz, int fUGiARHGukvmR)
{
    int gwnkxt = 1820720952;
    int nXdkFWIrzTZa = -227661657;
    double OjYjngeev = -72066.1029959611;
    string dzGzbwNvI = string("StrMhiiusHeLNinyQujydHhcnMmOPlrdQxxzoBaxUgnBBfnMRkMLazQKVZLyzwxkMZaWnQRQATFfJmWcVYIkNrQLjlUpPUhMOhUfvvNOgpXciaIossEotbZkHlbMbCWrWZXGSNKjgzaOep");
    double qCFCOgOwsecf = -694267.9097603308;
    double fthKpFgDkAosBQP = -103530.47110956632;
    string bUojYgNohjWet = string("sswZrSJTEwcqaoRsZQWOhussQTofHmQaRELEMlcESHmmtrQOChUQLZ");

    for (int rSYSpjHPJ = 1752163027; rSYSpjHPJ > 0; rSYSpjHPJ--) {
        RqNPShyOz = bUojYgNohjWet;
    }

    for (int gvXykONvwXNhHU = 264338980; gvXykONvwXNhHU > 0; gvXykONvwXNhHU--) {
        NRZCbGNoNbz += bUojYgNohjWet;
        RqNPShyOz += NRZCbGNoNbz;
    }

    for (int uDisrg = 1971184106; uDisrg > 0; uDisrg--) {
        dzGzbwNvI = RqNPShyOz;
        dzGzbwNvI = bUojYgNohjWet;
    }

    for (int VrDQvwuzfm = 281766909; VrDQvwuzfm > 0; VrDQvwuzfm--) {
        dzGzbwNvI = bUojYgNohjWet;
        dzGzbwNvI = dzGzbwNvI;
        qCFCOgOwsecf /= OjYjngeev;
        NRZCbGNoNbz += dzGzbwNvI;
    }

    for (int BUxFpZflUubVG = 883636269; BUxFpZflUubVG > 0; BUxFpZflUubVG--) {
        fthKpFgDkAosBQP = fthKpFgDkAosBQP;
        bUojYgNohjWet += bUojYgNohjWet;
        RqNPShyOz = RqNPShyOz;
        nXdkFWIrzTZa *= gwnkxt;
    }

    return nXdkFWIrzTZa;
}

LWcUHRwHYvIIDvlv::LWcUHRwHYvIIDvlv()
{
    this->KVzeUOCEXzNPZQ(1976393946);
    this->uYzBubBKpRASk(1628116476, -1854138247);
    this->MOUMUFq(59433.77247785876, string("VpAYbzJkTNVvEeEScanDkLkKRcEPZEPjwfKgjIPFFfLmeibbVuugkYpkrWxkknAoWUdenCZKtoGhwpRppvmILqVPzluXITnzaTmPSjXmLrTpMGzhnEDXecmOuSWXOxWhuPaQLaPXsvRGCcWiFvwqXuIaFzycePaVOvejsqThDfWXjHsQuAXBuIoBPaZGOIRWQSEmTThMQqKHfKaLdHBbhIyBlsngvehzBudqpyta"));
    this->CiukO(true, string("wEVopsczbNYVKUVYbyBbCIMDxvbRuiKZbdfVTSdgLmombnWiAWclyoKatuInOpMKMONiUzfMxYrdjBVeEivkjtHZrtqzrcKpwYGoKsuZSggmUIGSDBIOokdItIORabPUpLFZuNApnkxqbhXaPziDhtFZLmiWNOSegmnfMTwxGBubsrTGsaYybvuGTIelUgVwCuhzgyinZcDSigGCacHcSAsYyLIiREMmFftHaNBExfID"), 185533506);
    this->tOnost(true, string("jWRzjgAKJXwTBghDyvbujvPwSibGoLiKNVyaSeHcWMoUahBUjmsKLUXBWdMbmRXYPMumhkEnPPIpZCfGNGRecLnSVPPjuXWftDYcTpcohnikzcvcceSvVzyptQwUmUmeYLEdddBDEijByjeogvn"), string("EgEZKkpsifFmSnJNvVDNaNkrUTqlJGsuPOvlUiiJXYmByNkhsTOndsRJdFwPjmfpbcOxympblvqdXjOirvdTOzbPusTXneGcCGHvxBByIOscsgdBVFOzRxwKvKfPhGtsQdMJQrpIXGFWzZqhFAcJimfjePKK"), -2070492268);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WThteKJ
{
public:
    bool vACYNpbuEyXmMPKy;
    bool JvrnP;
    string ZEISDRPaVUP;
    string HdQzqEtkyi;
    bool exYPZNcz;
    string aewikCPUNE;

    WThteKJ();
    int QwhntFpgkf(bool nAzQJbN, string ZDTePbjJNWZVIp, int URIUYrmXMTExqRNq, int jplqnY);
    string YoXZOSt();
    int PJsCWuQudgEy(double GYMJSdBGnMueqwjm, bool GEvcG, double MrjiuJgmYlRmsy);
    double hOlwthsjxnUQjA(bool nJWRWFfOiOS, double ipKRmDaZlPE, bool pYZyNuhUMoRjEHsG);
    string IHznnpFLgnwekqgm(int HrUPmTxxluVbds, int zXGdy, double DJyvtMaPJM, double EAqWAHvyymUBu);
    int QgWHGVtoi(double QPtLkgZqh, double rCsFRLHaPSmvUk);
    int WKnpGsLnTHhMxzAY(int KyttsDrUB, string RmhGgH, double BdlRqfddrpfCeej, double CZkXlp);
    int qAWzaTCr();
protected:
    int qGuJCmnWusGuCl;
    int HCfAku;

    double YjxYqrdbgMJL(string NEHVgkjIpGsCA, bool YlCrwXvodS, double qtvAYYn, string wbkyrL);
    bool wtshhuPJP();
    double GxFZPktqA(double PDTFx, double RTspKdcPpb, string TVASzOCexgoZeSiZ, double gRechg, double pdaPsuym);
    int SZzsCWwMTJSDwke(int OpacFDyWNpU, bool OtyfnAOMYBuk);
    double KSFNxKRpXKY(double ytGcwEeR, double ZhhYFAsFKFvvGTO, double oaFxNhGVWRqjhyzD, bool TDFTDKIft);
    double KyfwUqXBUmYbGqTg(bool mOCcVk, string AWwazsZkXdxXFJw);
    void lfARMpmB(bool lHWhHJ, int vpgKDF, double UEEYCBHyugFCj, double IkyOoW, bool DwXvZI);
    double JzfNdXXkpxRpJ(string rNZrwr, int yTPaam);
private:
    string KcgUyzYhNdza;
    int HOZnNLUUSXU;
    double VvgUQPGPnmwVzVA;

    void mGTlUeyw(int pWASOTvzflQwJ, double bhMmFQZvPRHL, string JcdhrbHAExXejJ, string APYoLR);
    double OQfpgpzaNEekcXL(string uSgirOSIlPFNjAhI);
    bool pQLbVFRUKMQAl(string XektifrTtATaL, bool vtVOcpzkLGI, bool ZjycjPACuweOCOE);
    int duzXe(bool WQWQfKfPDVn);
    double kZteWDrLyMJrQF(double kgGSNhJSLceu, double OaVwAiHSJRshcbZ, int ICqSSet, int lFlAiJH, bool ETQFoK);
    double BuuDBWEEEY(int BnrYYYNhWtYBzIa, int SaqQx, string EOPpGysEVeRqKdt);
    double zzCOKcfgnyNbnOo(bool SnsGeqSfiegfRzuj, double YGzllmuJzuVtYWhX, int wxSxEOrOYyBFfiU, string dSCbcclNA, int HkNjRXf);
};

int WThteKJ::QwhntFpgkf(bool nAzQJbN, string ZDTePbjJNWZVIp, int URIUYrmXMTExqRNq, int jplqnY)
{
    bool IhyOFerTLpvOT = false;
    double aZXckoDtBwrDInfN = 337352.81454451085;
    int krSiHzvrPce = -1422762039;
    double otNHfCbpOYlFizQh = -41720.104550215474;
    double DTUWiak = 818173.9041666299;
    string lNLDOqtidOd = string("ACkJvpSIXYjWiBIStgeVuIacdawmkAbaqTZYUWZzidEXLAVnjlFnKfAYrjZSIPeHjNqFxsBpHkOXdtQZbtPxaUigcjMnbmWDRhnuKwpKPOvRmDggIKiLgWtMrTEzOXowQyMIuWHJgLcgWCOpLefTCKvzgsoaNgtrrCBshMuLYDufwIcptlXBjcCIalxGJPOLoHLGHdFRqdXgAclbmBxjXZGOudlFmSYh");
    bool GVTWhXd = false;
    string RHdnF = string("pMAZIYSBiaUYcXICSIYKyoGHYCfKUOrsTcIKPMwxhPsTCTReGilwScFYCFCeagVwrSymALuGIpCJEBvmXuZVciaRVcQIiwNYNakKlDDvJvnkVxfPURCZZYjRmpRhevAALTEjYlImBRWulrXTnWnkkfUqzLAONWZgRVBfArQpbLWIWUlYjfToCPBIOHFEsyErwRkQWJXhqNRHFgbfQujGXTjwU");
    double BEzuPydRVfVgU = -439085.77400382987;
    bool TtLlGaoUSsQVH = false;

    return krSiHzvrPce;
}

string WThteKJ::YoXZOSt()
{
    int fohJQOJr = -587490930;
    string AuTMSHSpokw = string("tmlzDiJYBGPiKaGhSMRLzAOxqJuqdDyNElDzdBppIKlhmIjseQTNbIeTNgWporbyKldiTpJmJ");
    string YwzAVVDG = string("ywKHYmkmCUdfEAfhnKhZAyHgymTubTExwhwvhQOhghgsnPGAFjVSFykDMjmwtRsRTgETphZfhZMXzDwYMwJSCxGzxanDbbZKu");
    double FOtuCnqJPKUnfBN = 49359.54120170622;
    int hNpJIxTwssBGH = -1809730253;
    double rwxnUQRG = -77279.1759454639;

    if (hNpJIxTwssBGH != -1809730253) {
        for (int PxDrejzWMmBzfsni = 170948951; PxDrejzWMmBzfsni > 0; PxDrejzWMmBzfsni--) {
            fohJQOJr /= fohJQOJr;
            rwxnUQRG -= FOtuCnqJPKUnfBN;
            YwzAVVDG += YwzAVVDG;
            hNpJIxTwssBGH -= fohJQOJr;
        }
    }

    if (AuTMSHSpokw < string("tmlzDiJYBGPiKaGhSMRLzAOxqJuqdDyNElDzdBppIKlhmIjseQTNbIeTNgWporbyKldiTpJmJ")) {
        for (int NIAXVkuIFOVQhu = 458543275; NIAXVkuIFOVQhu > 0; NIAXVkuIFOVQhu--) {
            YwzAVVDG += AuTMSHSpokw;
            hNpJIxTwssBGH = fohJQOJr;
            YwzAVVDG = YwzAVVDG;
            rwxnUQRG = rwxnUQRG;
            hNpJIxTwssBGH += hNpJIxTwssBGH;
        }
    }

    for (int rzodziDyU = 1830015816; rzodziDyU > 0; rzodziDyU--) {
        continue;
    }

    for (int KMwySKWVEHCs = 1013674894; KMwySKWVEHCs > 0; KMwySKWVEHCs--) {
        rwxnUQRG = FOtuCnqJPKUnfBN;
        YwzAVVDG = YwzAVVDG;
        rwxnUQRG -= rwxnUQRG;
    }

    return YwzAVVDG;
}

int WThteKJ::PJsCWuQudgEy(double GYMJSdBGnMueqwjm, bool GEvcG, double MrjiuJgmYlRmsy)
{
    double wqjiEOXzV = 947533.4949793459;
    int zdtXvPTcxZhuXV = 126131326;
    string wCbNR = string("iiHefXUCCzVSKBehwCtWVwZiBnQQCpJgjJjSLfhWYBsGaqDKlAqruuJnjJHkZyKdmmmLhBMaXtTBGeOrMwKjdnKMFuhCUGcjbmUxOGchsyzhEitayfnJdgSzWsDrrSHNZUIkFDexBmbYSGlQfgbAGYfBAEhlJsmVgUBqUpJodZfpmAASyjjbkcZLyMILhMpZsrECcWDdARGQgXIJMYaAcDlIdBakVECvRCSSiMFfiFlHnZXX");
    bool psNabUFYAhLDV = false;
    bool UtYOudjQFQrGCWp = true;
    string PcTylvMtqqqeq = string("jFpjaAMeZOOCSFoozRSYsAUNhsoBUWqYouJgQLjfAiXqByuBSVdjSrXRRxIrXOzVcuudxMkJuxLMpiHcmYgjmYdBYBTCPgZNCoqwKdQFrhbIrvvNknICUDpHdOpXvcwurADiqCvqkzkHBxrMnHIrZDEtOYKQzqlZMWUJJtBksVgCmkoruYbFbSjNowWrPLOdpS");

    for (int CmTCoKUenzeHyVo = 1993075164; CmTCoKUenzeHyVo > 0; CmTCoKUenzeHyVo--) {
        continue;
    }

    for (int zdlqMsnPFQbuFe = 1072552915; zdlqMsnPFQbuFe > 0; zdlqMsnPFQbuFe--) {
        psNabUFYAhLDV = psNabUFYAhLDV;
    }

    return zdtXvPTcxZhuXV;
}

double WThteKJ::hOlwthsjxnUQjA(bool nJWRWFfOiOS, double ipKRmDaZlPE, bool pYZyNuhUMoRjEHsG)
{
    string AcCjjuYpkAn = string("afbPcBHoPbrTKAaqDuFFeSgwKgllVXOgkrBJsnfYhDVXbHKPHIenhLYULvukNgIHIdDwTyLNbMZUvkFntkcRvHbRwzWYORWZBLgwQDEirkCBtiHuEKlQryresbJtLREZXktAyGdPaujIvjptHxPCafAjLdozccQQASIKYMJoGfiBHapJIKdoSDvgZteFFutKFxoIZbVjOxfOyARhrbPrB");
    string RDHgFqJEXwR = string("HroTUZeqcBjlwkOUZxUEvVhNXIFurPkfycLkRYjYQpAkpAJvGHGhJroUSitFpYIlKxQwCBxasrNgwHWzIjBKXvlozCVouEMbFvJytkmiZrSTikNqfQeNRssHxhsbLqNDOjiFroeQAKiglKbbkdV");
    int obsKbCCIhyfVrvp = -228329797;
    string OElHPLjard = string("lCjwOslwSRevljWIxXBAAZTDAYIPgGlLLIMvvhNJNCTGPOyrLkDqwSbShgWyDkTlfnyPTAkoVLxIEFiHkWBEhQrWbPQUIabKXIypKIKpdwWHRwtrjXg");
    int PZxKIhW = -721219328;
    int HKQqfZohwuiB = -1801234750;
    string AzfIw = string("AlTJerSKbxpHwXjdaMsuEUWSyaMbPMWRWwYFJhjdhTlyjVSypTIopKFAcutMGiPyJYJBXTOYIhhHTswRRUzSmaLQVfWKUGYdfGMdWdBmpadtIbVZyjVgOdZusysEeINJwRpmiHCZCiRbdIbfNWpPpHwJhSUIQ");
    bool sLhDJ = true;
    double SHvFOGMBF = -651806.1376472401;
    bool UoghEDOVAyWf = false;

    if (obsKbCCIhyfVrvp == -721219328) {
        for (int PpfSmxzfw = 1164760172; PpfSmxzfw > 0; PpfSmxzfw--) {
            obsKbCCIhyfVrvp += PZxKIhW;
            nJWRWFfOiOS = ! nJWRWFfOiOS;
            OElHPLjard = RDHgFqJEXwR;
        }
    }

    for (int dVLIzT = 1994750355; dVLIzT > 0; dVLIzT--) {
        obsKbCCIhyfVrvp = HKQqfZohwuiB;
        obsKbCCIhyfVrvp *= PZxKIhW;
        UoghEDOVAyWf = ! UoghEDOVAyWf;
        nJWRWFfOiOS = ! sLhDJ;
    }

    for (int RIVQMaUYxzG = 1803831380; RIVQMaUYxzG > 0; RIVQMaUYxzG--) {
        continue;
    }

    return SHvFOGMBF;
}

string WThteKJ::IHznnpFLgnwekqgm(int HrUPmTxxluVbds, int zXGdy, double DJyvtMaPJM, double EAqWAHvyymUBu)
{
    bool yrMjFPCbPJLABFON = false;
    double ZRnUpMzCHQt = 270858.3713933089;
    int EqgZzhC = 469461795;
    double iBHUjnVp = -999192.3406060901;
    string fbDRtd = string("WeJztjPrzjLOLdvXcKeEwhXXImKgJBBfIWWLLIbdZVlZmurqNkPJYGIwKFbkrjejeHynHgmfkDiKYgDpHsRxLUGmGOGJQjyylnGgTgcRFoEVIsbBMIBSxmoMBQutmoNYYfAvwKkyNRBqZFKlRntc");
    string ssxPapcBztl = string("GmNfYEGepFZFuSSNHHvQgiELHYIVYqstPUQfrjMiZeayNBiFtGhOtTBaXfVnhUbffZmjYnSgxwwUKVTswnz");
    string YOKXphmIPbAA = string("XQGPhRjpGKhVERzKtfbBRbvErFKYrYmIXZJDUarApXSzIMRQqZaIVEPhKNLxzRbsBtbAFNjuGqTTmewvwXNZncxGnnlwfIzEEhDrRdrYeglaBRWORiwiXzoARLxXeNEkEgSTZJoTHJEZLGFHZHjbCAVmt");
    bool tPhtJofWH = true;

    for (int vjJySthG = 663033837; vjJySthG > 0; vjJySthG--) {
        EqgZzhC *= EqgZzhC;
        HrUPmTxxluVbds /= HrUPmTxxluVbds;
        YOKXphmIPbAA += fbDRtd;
    }

    for (int zWbKWlLo = 1294798413; zWbKWlLo > 0; zWbKWlLo--) {
        yrMjFPCbPJLABFON = ! tPhtJofWH;
        iBHUjnVp -= EAqWAHvyymUBu;
        iBHUjnVp = ZRnUpMzCHQt;
    }

    return YOKXphmIPbAA;
}

int WThteKJ::QgWHGVtoi(double QPtLkgZqh, double rCsFRLHaPSmvUk)
{
    string jlDzd = string("pkVdUtYmGznfGqOIMNpApBpNSfrAeZBsaqfaNaouZUCTNMBoXhdcmuHOjesUIuYKmsMGywjbyRNPQMpDWSGBCAkTWlMYXojjGCBJYnapkwZGcPFuxISlzMACKeyPbhFwVMDTTUqsaN");
    int kZQiVEXzkBd = 1033864918;
    double IEfPUXnOgyIin = -864074.9213483218;
    bool lonyDyCplgCaFoF = false;
    double kSUjrnrb = -307906.24202601216;
    bool AtszR = true;
    string pZBSYAgTr = string("xGqUdrDTeDZZvVtaVarvhTHEmbVxpCGA");
    string oVYLr = string("WpcXrfFgXqCITmtiwiETlRUaqXBRJMiMmiReLXGcDRJryUAtNfDJhiPjUkrXoTLOKOJYJomOirIMLAsvsoSIBPRefkDeqoaZdZKPCZRWRGCMWCANEWFL");

    if (oVYLr >= string("pkVdUtYmGznfGqOIMNpApBpNSfrAeZBsaqfaNaouZUCTNMBoXhdcmuHOjesUIuYKmsMGywjbyRNPQMpDWSGBCAkTWlMYXojjGCBJYnapkwZGcPFuxISlzMACKeyPbhFwVMDTTUqsaN")) {
        for (int IplsaDatJjL = 1769566921; IplsaDatJjL > 0; IplsaDatJjL--) {
            jlDzd += oVYLr;
            pZBSYAgTr = oVYLr;
            IEfPUXnOgyIin = IEfPUXnOgyIin;
        }
    }

    return kZQiVEXzkBd;
}

int WThteKJ::WKnpGsLnTHhMxzAY(int KyttsDrUB, string RmhGgH, double BdlRqfddrpfCeej, double CZkXlp)
{
    double KXJtrfWxQ = -1047392.9705085263;
    double SIZanHJASqCvXba = -966547.6571253528;
    double geofeAlURuPU = -852069.5926229516;
    string vlnQSaYtBj = string("gNJVFWSqKLfsNNIJgAPFaZZBiaQsanqIXmZRxNeFExiRpsIdiqRzPcVEVgYiZQEwXWYGlCgvtdDCjYiXnUrbDBnEvjWjAWhlaHXXriKqZYDYfNqgPxPZVpmvPzPviVivAfFd");
    int BdGGChwPm = 927223409;
    int JoSjiWiKVf = 697006078;
    bool YnJSLOfOgQbURUBl = true;
    bool iUXERuHZxjfMgE = true;
    bool lfDLaT = false;
    bool VdRNHZjXXQxpWBd = true;

    if (KyttsDrUB <= 927223409) {
        for (int mqCkWJFsemYU = 1955566783; mqCkWJFsemYU > 0; mqCkWJFsemYU--) {
            BdGGChwPm *= JoSjiWiKVf;
            CZkXlp /= CZkXlp;
        }
    }

    return JoSjiWiKVf;
}

int WThteKJ::qAWzaTCr()
{
    double RzBHxpeaIF = 424443.6005611391;
    double KkuSubdUN = -671498.0248732411;
    string KKOzDonbF = string("ezTldyJgIcKHVhZniOGEfSnTefntdJIKWdDyYFcGvwrGsjHaGbvRFsOeEHCpERtghnpeDGHKdgTSOxPerrhQRhOemzlEOAHUAxIXKUTaGBmfrFyeOuPSwmDoqJbrVLHG");
    double beqVnquRensqVm = 243747.93869970902;
    int ajwCto = 1977202827;
    double ditmywWdpOb = 694782.8456459047;
    bool lyryzwTd = false;

    if (KkuSubdUN >= -671498.0248732411) {
        for (int twSaOQoLAfzALCQK = 650191480; twSaOQoLAfzALCQK > 0; twSaOQoLAfzALCQK--) {
            lyryzwTd = lyryzwTd;
            beqVnquRensqVm = ditmywWdpOb;
            KkuSubdUN /= KkuSubdUN;
        }
    }

    for (int EcnkXb = 1664382871; EcnkXb > 0; EcnkXb--) {
        RzBHxpeaIF += RzBHxpeaIF;
        RzBHxpeaIF = ditmywWdpOb;
        KKOzDonbF = KKOzDonbF;
    }

    if (KkuSubdUN == 243747.93869970902) {
        for (int eSvPXoqpErXqcHbS = 1706845974; eSvPXoqpErXqcHbS > 0; eSvPXoqpErXqcHbS--) {
            KkuSubdUN += ditmywWdpOb;
            KkuSubdUN = beqVnquRensqVm;
            KkuSubdUN += ditmywWdpOb;
        }
    }

    for (int zvzLAaKCmXoyMbQ = 231833372; zvzLAaKCmXoyMbQ > 0; zvzLAaKCmXoyMbQ--) {
        RzBHxpeaIF /= RzBHxpeaIF;
        ajwCto -= ajwCto;
        beqVnquRensqVm /= ditmywWdpOb;
        RzBHxpeaIF = ditmywWdpOb;
        KkuSubdUN += KkuSubdUN;
    }

    if (beqVnquRensqVm >= 424443.6005611391) {
        for (int WJWRZROzlBZ = 895541248; WJWRZROzlBZ > 0; WJWRZROzlBZ--) {
            beqVnquRensqVm -= ditmywWdpOb;
        }
    }

    return ajwCto;
}

double WThteKJ::YjxYqrdbgMJL(string NEHVgkjIpGsCA, bool YlCrwXvodS, double qtvAYYn, string wbkyrL)
{
    string zAtyTkaoQSqckMWx = string("fwBiXUJJbmwKnjugkGgfvxoLtpSsvtNvyBdtJWTaeHoF");
    bool QDQtICWlfcLycpYy = false;
    double YjSTLqw = -892121.5831093764;
    bool LudclXhBYr = false;
    bool ZRzVqrKAfxfDGc = true;
    int hHJBDONX = 513731542;

    for (int iKnnVVEJI = 49261151; iKnnVVEJI > 0; iKnnVVEJI--) {
        continue;
    }

    for (int oaumnauIiB = 713903317; oaumnauIiB > 0; oaumnauIiB--) {
        YlCrwXvodS = QDQtICWlfcLycpYy;
        LudclXhBYr = ! ZRzVqrKAfxfDGc;
    }

    if (QDQtICWlfcLycpYy != false) {
        for (int CjOzoW = 602352306; CjOzoW > 0; CjOzoW--) {
            wbkyrL = wbkyrL;
        }
    }

    return YjSTLqw;
}

bool WThteKJ::wtshhuPJP()
{
    bool xcvZlE = false;
    double kcWjnBuRLN = -990298.1866659084;
    bool jegyWwEewNGcBmd = true;

    if (xcvZlE != false) {
        for (int KRrzGkapULxWWz = 322319110; KRrzGkapULxWWz > 0; KRrzGkapULxWWz--) {
            continue;
        }
    }

    for (int vtenPKxMTlmWZjQ = 85016706; vtenPKxMTlmWZjQ > 0; vtenPKxMTlmWZjQ--) {
        jegyWwEewNGcBmd = ! jegyWwEewNGcBmd;
        jegyWwEewNGcBmd = ! jegyWwEewNGcBmd;
    }

    return jegyWwEewNGcBmd;
}

double WThteKJ::GxFZPktqA(double PDTFx, double RTspKdcPpb, string TVASzOCexgoZeSiZ, double gRechg, double pdaPsuym)
{
    double EFUPEdsURNNCStMa = 15018.174277661334;
    string rVUXXItzIJXtyY = string("MbNFhvjBiMmUAlojMaJlzGhidob");
    bool HlxryHqVncrO = false;
    double AybpiO = 764774.3640533406;
    double eCzWV = 550131.3301042967;

    for (int lvaTI = 1355571935; lvaTI > 0; lvaTI--) {
        continue;
    }

    if (EFUPEdsURNNCStMa > 691787.3873304247) {
        for (int kPyCEBGMFTG = 1925754765; kPyCEBGMFTG > 0; kPyCEBGMFTG--) {
            eCzWV *= PDTFx;
            AybpiO = PDTFx;
            rVUXXItzIJXtyY += TVASzOCexgoZeSiZ;
            RTspKdcPpb -= pdaPsuym;
            gRechg /= eCzWV;
            RTspKdcPpb += RTspKdcPpb;
        }
    }

    if (pdaPsuym == 764774.3640533406) {
        for (int mLywDGGjTvoZBWw = 187210529; mLywDGGjTvoZBWw > 0; mLywDGGjTvoZBWw--) {
            pdaPsuym -= RTspKdcPpb;
            eCzWV /= gRechg;
            pdaPsuym += AybpiO;
        }
    }

    return eCzWV;
}

int WThteKJ::SZzsCWwMTJSDwke(int OpacFDyWNpU, bool OtyfnAOMYBuk)
{
    string RHSkIODQAI = string("PFpGwnDOFrlvXcJlTRtdoeJIXGcSZdkfGxhMytgytRKBHeXovxWVPHHtBfJbxkPkJYYtONCWfEQFcmhKWrQwugdfBrleAJeOAzSjOpSHOmFPPeWuTtGfpCGLHJklWlBQAcivIErjpRsLWGZpSupStvBKznnwBVWdQOMOMHKKoqhMAwrhlbCEAoORZsoDETOTGJGaVuSosiZEpXPCAckYlcbcjrgdHemPXiYBDUhggO");
    string MAPaHbNEIPsAGnU = string("lLfiZQqbxUaQKJCEbJkEDpfNtMIBgLfXbCNQfQEYRCovSlWaiGlryawtCWUGreeJtkJHmLkZashnTsdOOMXVpvpIQrLlWbLzomqG");
    int tPsJnXM = 1005730530;
    double zChLDRMd = -320435.30708763254;

    for (int LYJQlbtXfz = 1259449555; LYJQlbtXfz > 0; LYJQlbtXfz--) {
        continue;
    }

    for (int ZGTLChIHoyHqOHZi = 746764746; ZGTLChIHoyHqOHZi > 0; ZGTLChIHoyHqOHZi--) {
        continue;
    }

    for (int IBnIyWRqtfHD = 1156716098; IBnIyWRqtfHD > 0; IBnIyWRqtfHD--) {
        OpacFDyWNpU = OpacFDyWNpU;
    }

    return tPsJnXM;
}

double WThteKJ::KSFNxKRpXKY(double ytGcwEeR, double ZhhYFAsFKFvvGTO, double oaFxNhGVWRqjhyzD, bool TDFTDKIft)
{
    int ZefRCzh = 738252366;
    bool zJNdvjZwGsC = false;
    string ogSASzJGdL = string("bvzmSQzBcccOEXDxKPcpLBCTBZNrPUIGRbkatSEhBjwWJxFSidthbWDRCxYhnyvVyJMJMezrFGMOfCTfRdcWqUvolSKvrJrmRdOzNw");
    bool tGfQPWp = false;

    for (int MYYdy = 1274817627; MYYdy > 0; MYYdy--) {
        ogSASzJGdL += ogSASzJGdL;
        tGfQPWp = tGfQPWp;
        ytGcwEeR = oaFxNhGVWRqjhyzD;
        ZefRCzh = ZefRCzh;
    }

    if (tGfQPWp != false) {
        for (int EvOjAlVIpf = 531652032; EvOjAlVIpf > 0; EvOjAlVIpf--) {
            TDFTDKIft = ! zJNdvjZwGsC;
            ytGcwEeR *= ytGcwEeR;
        }
    }

    if (ogSASzJGdL >= string("bvzmSQzBcccOEXDxKPcpLBCTBZNrPUIGRbkatSEhBjwWJxFSidthbWDRCxYhnyvVyJMJMezrFGMOfCTfRdcWqUvolSKvrJrmRdOzNw")) {
        for (int VYZqt = 1921719708; VYZqt > 0; VYZqt--) {
            tGfQPWp = ! TDFTDKIft;
            ogSASzJGdL = ogSASzJGdL;
        }
    }

    for (int cPUuCPUwkIp = 1261418960; cPUuCPUwkIp > 0; cPUuCPUwkIp--) {
        tGfQPWp = TDFTDKIft;
        ogSASzJGdL = ogSASzJGdL;
        oaFxNhGVWRqjhyzD -= ZhhYFAsFKFvvGTO;
    }

    return oaFxNhGVWRqjhyzD;
}

double WThteKJ::KyfwUqXBUmYbGqTg(bool mOCcVk, string AWwazsZkXdxXFJw)
{
    int pCwfEopkbyhCN = 784501577;
    bool WuTDXzJ = true;
    double ohfnVkdPMAPvkxnb = 630619.6219887552;
    bool jKairykHt = true;
    int KTiJvBzI = -568110363;

    for (int ekzUJDgfWVfIcTAm = 1705836706; ekzUJDgfWVfIcTAm > 0; ekzUJDgfWVfIcTAm--) {
        continue;
    }

    return ohfnVkdPMAPvkxnb;
}

void WThteKJ::lfARMpmB(bool lHWhHJ, int vpgKDF, double UEEYCBHyugFCj, double IkyOoW, bool DwXvZI)
{
    string iVMrhJPXqewkfEB = string("NJidcxgycjeyKhCmxIuqpGxbWczTsOAwdzKXyxszwjzWtERNYxWWRKhGIkNIoWdqVHWcKhDTxFBuNblzUxImXiTwAKwzUdHotaGkbasElrEfURnsmXycvpFFwhQuNECenQbSEQuMwXRrQKdWnSBpSbexiffdpopGcZVIZwrUvjIIgHEtonYrGaognbVhsjBRCtutSFrSGbnvxucPdkMjD");
    double VDJapRq = 957162.2970695172;
    bool oaCVcCIudbsaR = true;
    int rzBgHSDwxwnW = 539088272;
    double EtJupnx = -541811.6628606948;
    string jrEhZc = string("NHzmuuKmDN");
    string EfeOmyNtEFETU = string("GKntKwMFOgKbFGaIYajcVWGWODNmhVYFPyASYFBvwMihFTLjtfpQINxOnMWkLOQhJhRhVjXzjarqCdoidXSwPHMqJRkfDJlqmBLsmlNDlFnZmsZuQpDwDyeIpcjQfLrJIIobSovrqrcvOgLcRNngLTmXrwVgyedlTRNzqyqMczzKYSgmaFgTSgZZK");

    for (int TXRiQmTcWuQXIG = 1632939169; TXRiQmTcWuQXIG > 0; TXRiQmTcWuQXIG--) {
        continue;
    }

    for (int jEnuBHu = 2006997779; jEnuBHu > 0; jEnuBHu--) {
        DwXvZI = DwXvZI;
    }

    for (int LvYFVKVoAzmLLTzq = 1770172598; LvYFVKVoAzmLLTzq > 0; LvYFVKVoAzmLLTzq--) {
        continue;
    }

    if (jrEhZc > string("GKntKwMFOgKbFGaIYajcVWGWODNmhVYFPyASYFBvwMihFTLjtfpQINxOnMWkLOQhJhRhVjXzjarqCdoidXSwPHMqJRkfDJlqmBLsmlNDlFnZmsZuQpDwDyeIpcjQfLrJIIobSovrqrcvOgLcRNngLTmXrwVgyedlTRNzqyqMczzKYSgmaFgTSgZZK")) {
        for (int aHzjxtrqzEgJ = 1499200947; aHzjxtrqzEgJ > 0; aHzjxtrqzEgJ--) {
            lHWhHJ = DwXvZI;
            VDJapRq *= VDJapRq;
        }
    }

    for (int UplSIGwGuNt = 679900925; UplSIGwGuNt > 0; UplSIGwGuNt--) {
        EfeOmyNtEFETU = jrEhZc;
        oaCVcCIudbsaR = oaCVcCIudbsaR;
    }
}

double WThteKJ::JzfNdXXkpxRpJ(string rNZrwr, int yTPaam)
{
    int xituRUMslbVILPPC = 425157687;
    bool gVrRM = true;
    string LdZGeL = string("sJEsRsPIjHaJvgdWmSfOoVFOIYHSFsgBlXZJBpTGUTtwbZrizPKrpZjHrnRoILOgBEHmybRDWnMAeuFjTxBMCsfhODKrReuGoLDbHExJiYQCiLZapVqWMfKtybMxTxbqsBBbgnlrhSugjouvtoaHxHoW");
    double FoPemTWdTObELAI = 329217.57294918183;
    int RLjiVggOOzUChS = -775812272;
    bool IZhbbLQiSJ = true;

    for (int mBNNePZwP = 1680096487; mBNNePZwP > 0; mBNNePZwP--) {
        rNZrwr = LdZGeL;
    }

    for (int CaWtyEjaauf = 1086241781; CaWtyEjaauf > 0; CaWtyEjaauf--) {
        RLjiVggOOzUChS -= xituRUMslbVILPPC;
    }

    return FoPemTWdTObELAI;
}

void WThteKJ::mGTlUeyw(int pWASOTvzflQwJ, double bhMmFQZvPRHL, string JcdhrbHAExXejJ, string APYoLR)
{
    int eUqWHkOEXd = 275245965;
    double FyFIWxzzBpbN = 373720.21440734155;
    string QgEZHRoTc = string("VDDTCUPffLnuaHVaPCVmQiIqOLwPdBgXllefWXeCksrYuJmSrOXnDSOLWQavfbMqATuLGagtFNIkahHxDYRrrFapuvfhHgFDMelYYcKkftBmWE");
    string jJBVmhd = string("KmubCxhRQaDomJtBdvFOHgpYhHHALCoXbHCTBzXZAGddzzvWeNJKPRpbOWuqgWjnEKimkkLGkihQgzHXUKNEqBAZCDJaUUXdfzRLcGaOIlKVjEuQZCYUHqhImWrAGFPPAubfogeBldfJtJVPgODsblMUehxyZZvlrzPeYGZmcZysHyFopTFetmOjdtRVllBKTxaRTkleMAwHQbTpimrg");
    string Zlgla = string("cangdASjIcyajCAxV");

    for (int vcQESEUpTHW = 2029739843; vcQESEUpTHW > 0; vcQESEUpTHW--) {
        Zlgla = JcdhrbHAExXejJ;
    }

    for (int THWwLakcsdKEFX = 1416200784; THWwLakcsdKEFX > 0; THWwLakcsdKEFX--) {
        jJBVmhd = QgEZHRoTc;
        pWASOTvzflQwJ -= eUqWHkOEXd;
        APYoLR += jJBVmhd;
        jJBVmhd = JcdhrbHAExXejJ;
    }
}

double WThteKJ::OQfpgpzaNEekcXL(string uSgirOSIlPFNjAhI)
{
    string AfWSAsNy = string("DFWvlZMDCvbIooDUyIVDnPVZqueHXJvOvoZArQABMbJCFerLouJYMBlzxoFFXxzlkEvFlMvYoZmGegOIRpDGaeAMhsHlAkahosHakxIUvPHeONyEerGviAasJViEoeXIudABYVAcBFFxmVQaqJXgVMjUVaHXMSMOxkCEPbptYHaWuviXsFtDTXBignhqovpQqBIXVNGJNyFlSOmINpiARrFqAwLBDolGDgfauGPyBTOaRkBeun");
    int xenzQP = 1708564949;
    bool YsvwuY = true;
    string TyRZOfyMunUsL = string("zZYRWZfqYiqniYutqRxDrRGnqFUeacWigJlW");
    int UYysKyYcY = -1017853617;
    double NMPvrdtWVACidrdJ = 352130.61304538907;
    bool gipFYFPlyCNxY = true;
    int dSlKJho = -751981184;
    bool BPWeDyMOZK = false;
    bool LXXmWADXBUMBcwVN = false;

    if (xenzQP >= 1708564949) {
        for (int VfnwvN = 283227984; VfnwvN > 0; VfnwvN--) {
            continue;
        }
    }

    for (int ITkgjLXPJUjJK = 628605016; ITkgjLXPJUjJK > 0; ITkgjLXPJUjJK--) {
        uSgirOSIlPFNjAhI += AfWSAsNy;
    }

    for (int CAzhyTLbrQdP = 1968336102; CAzhyTLbrQdP > 0; CAzhyTLbrQdP--) {
        LXXmWADXBUMBcwVN = LXXmWADXBUMBcwVN;
    }

    for (int bfALZvDxK = 6045950; bfALZvDxK > 0; bfALZvDxK--) {
        xenzQP *= xenzQP;
        dSlKJho += UYysKyYcY;
    }

    return NMPvrdtWVACidrdJ;
}

bool WThteKJ::pQLbVFRUKMQAl(string XektifrTtATaL, bool vtVOcpzkLGI, bool ZjycjPACuweOCOE)
{
    int iRhVvyjRvDYNfwGy = -772968964;
    bool bOTRFlsgbV = false;

    for (int XgVmYKnOwdyMdbfE = 921303229; XgVmYKnOwdyMdbfE > 0; XgVmYKnOwdyMdbfE--) {
        ZjycjPACuweOCOE = bOTRFlsgbV;
        vtVOcpzkLGI = ! vtVOcpzkLGI;
        bOTRFlsgbV = ! vtVOcpzkLGI;
    }

    if (ZjycjPACuweOCOE != true) {
        for (int jnHJsCDEYtIZixQ = 1711754482; jnHJsCDEYtIZixQ > 0; jnHJsCDEYtIZixQ--) {
            XektifrTtATaL += XektifrTtATaL;
        }
    }

    for (int mQjVgITYqukuR = 1356288935; mQjVgITYqukuR > 0; mQjVgITYqukuR--) {
        vtVOcpzkLGI = ZjycjPACuweOCOE;
        iRhVvyjRvDYNfwGy = iRhVvyjRvDYNfwGy;
        bOTRFlsgbV = ZjycjPACuweOCOE;
    }

    if (ZjycjPACuweOCOE == true) {
        for (int fPTCmpIlOQO = 1504276243; fPTCmpIlOQO > 0; fPTCmpIlOQO--) {
            vtVOcpzkLGI = vtVOcpzkLGI;
            ZjycjPACuweOCOE = vtVOcpzkLGI;
            vtVOcpzkLGI = ! ZjycjPACuweOCOE;
        }
    }

    return bOTRFlsgbV;
}

int WThteKJ::duzXe(bool WQWQfKfPDVn)
{
    int runBJz = 1499312515;
    bool SJgagAwECHDxONNo = true;

    for (int PHhrC = 851194059; PHhrC > 0; PHhrC--) {
        WQWQfKfPDVn = SJgagAwECHDxONNo;
        WQWQfKfPDVn = ! WQWQfKfPDVn;
        SJgagAwECHDxONNo = ! WQWQfKfPDVn;
        SJgagAwECHDxONNo = SJgagAwECHDxONNo;
        SJgagAwECHDxONNo = ! SJgagAwECHDxONNo;
        SJgagAwECHDxONNo = SJgagAwECHDxONNo;
    }

    if (SJgagAwECHDxONNo != false) {
        for (int KkgkSL = 884560449; KkgkSL > 0; KkgkSL--) {
            SJgagAwECHDxONNo = ! WQWQfKfPDVn;
            runBJz /= runBJz;
        }
    }

    for (int SgQBivW = 884598569; SgQBivW > 0; SgQBivW--) {
        SJgagAwECHDxONNo = SJgagAwECHDxONNo;
        SJgagAwECHDxONNo = WQWQfKfPDVn;
        runBJz = runBJz;
        WQWQfKfPDVn = ! WQWQfKfPDVn;
        runBJz *= runBJz;
        SJgagAwECHDxONNo = WQWQfKfPDVn;
        WQWQfKfPDVn = SJgagAwECHDxONNo;
    }

    return runBJz;
}

double WThteKJ::kZteWDrLyMJrQF(double kgGSNhJSLceu, double OaVwAiHSJRshcbZ, int ICqSSet, int lFlAiJH, bool ETQFoK)
{
    double DcxoRXJcFkhTL = 1022810.2714532255;
    int wtgCcwCYPSPU = -1351282562;
    int KTOaOO = 1230170426;
    bool RDCdJuko = false;
    bool gZtGy = false;
    double wzARjhPUYZxlU = 921482.6926022479;

    if (kgGSNhJSLceu >= -720533.0510969136) {
        for (int KCamLIa = 19293341; KCamLIa > 0; KCamLIa--) {
            gZtGy = ! ETQFoK;
            wtgCcwCYPSPU -= lFlAiJH;
            DcxoRXJcFkhTL += wzARjhPUYZxlU;
        }
    }

    for (int ryMdbhTSPtbZt = 40799814; ryMdbhTSPtbZt > 0; ryMdbhTSPtbZt--) {
        ETQFoK = RDCdJuko;
    }

    for (int vydiXpjIC = 335287917; vydiXpjIC > 0; vydiXpjIC--) {
        wzARjhPUYZxlU /= kgGSNhJSLceu;
    }

    return wzARjhPUYZxlU;
}

double WThteKJ::BuuDBWEEEY(int BnrYYYNhWtYBzIa, int SaqQx, string EOPpGysEVeRqKdt)
{
    double dDpKKYbeqWuf = -229411.5201638756;
    double bFmpkjAy = 128183.24679118156;
    string tVGIhzFDeyS = string("cUJskkNIehIAipQwnJLwrvxrzSygjVOORdCSzfSKErMZArYYrOPPfuigbNdpfgUaKLxMcexjQtwbjFKXFLaRYLDKHmYKwQOmJTnWjyvhwEddjdsvrmStowRpwfcWkibzz");
    bool fNbVqIfwbhU = false;
    double fzYvVCPv = -340815.86746413674;
    double RdNeTgJPEXd = 454806.55160335964;
    bool IFPBbyjkhPPEMTK = false;

    for (int VzQQlUSmOagvkO = 1500857578; VzQQlUSmOagvkO > 0; VzQQlUSmOagvkO--) {
        fNbVqIfwbhU = ! IFPBbyjkhPPEMTK;
        RdNeTgJPEXd /= dDpKKYbeqWuf;
    }

    for (int tlQSBOp = 1796206234; tlQSBOp > 0; tlQSBOp--) {
        IFPBbyjkhPPEMTK = ! fNbVqIfwbhU;
    }

    for (int BCyRNDBQyQaqeAGA = 1524799709; BCyRNDBQyQaqeAGA > 0; BCyRNDBQyQaqeAGA--) {
        fNbVqIfwbhU = ! fNbVqIfwbhU;
    }

    if (fzYvVCPv != 454806.55160335964) {
        for (int AiYvRqEMI = 1758868140; AiYvRqEMI > 0; AiYvRqEMI--) {
            EOPpGysEVeRqKdt = EOPpGysEVeRqKdt;
        }
    }

    if (IFPBbyjkhPPEMTK == false) {
        for (int hbUKmUlwQs = 1708138739; hbUKmUlwQs > 0; hbUKmUlwQs--) {
            RdNeTgJPEXd = dDpKKYbeqWuf;
        }
    }

    return RdNeTgJPEXd;
}

double WThteKJ::zzCOKcfgnyNbnOo(bool SnsGeqSfiegfRzuj, double YGzllmuJzuVtYWhX, int wxSxEOrOYyBFfiU, string dSCbcclNA, int HkNjRXf)
{
    double oWYhN = -830375.9546807971;
    double sHGzlrKPxCpIH = -685078.9512607435;
    bool tQUuDTM = false;
    int upkffLAmkeUkMa = -1361966455;
    string lnaPqDcmpl = string("BUhbTKEQrSsccGgAf");
    bool uDDhzOT = false;
    string AXtiZfbNUKq = string("jiOGneCFvtdUHoqfZDqScFzqpMZcDKNooUtnzjSCwqXijOBkxQGVjXjqcaVZuDHAyGqAuSvzWmBH");
    double xTfcXc = -390253.58627985517;

    for (int GbhGniR = 113462572; GbhGniR > 0; GbhGniR--) {
        lnaPqDcmpl = dSCbcclNA;
        AXtiZfbNUKq = AXtiZfbNUKq;
    }

    return xTfcXc;
}

WThteKJ::WThteKJ()
{
    this->QwhntFpgkf(true, string("xgGOhtahHwNceuNXVxjuSiZZYWzxWdZp"), -1908394672, 1077296774);
    this->YoXZOSt();
    this->PJsCWuQudgEy(459588.7464203112, false, 159634.8703859502);
    this->hOlwthsjxnUQjA(false, -881409.3472631271, true);
    this->IHznnpFLgnwekqgm(-1468479465, -1420302797, 417150.00642208575, 671862.5358854122);
    this->QgWHGVtoi(701560.5691498263, -248567.4558085473);
    this->WKnpGsLnTHhMxzAY(214515036, string("laBGhHiMpQTYIsAwZmjwAmXGAvKgKxSvwYAYzbllTxwDrllOLknrcqUXkTjBXiWlkaRLYjMegwfNvjAFHmpwutYeRDgCTQULyusJeOgpEvBxaAtLFXzvFcuckYjOCJEXWhuTWZYlqiakwkOczdfVOjcMntiORkdlfiFbIZBuztspfHvKLtUZyjNOZzKZWBsAPRWxoJLNYOoPUqoejSHhtWbIKeKMGhkhZBikFpvBVmFlIpogQ"), 251666.95812588598, -647545.8716626053);
    this->qAWzaTCr();
    this->YjxYqrdbgMJL(string("LtmcqJgtsIKoWUbgdKNLrMrzhkoCUgJkutBcmnpmgIcESKBRnyicEhXLKYAMxlCmvcAClxxotqiJOWpoArJaLKGGSrabfkmSeqxPYTcRkOveYigxuxTckOxahtkgaNYoWkdnxfssOALCLTeWMjzpidzFvcnVgkPJrUAuRyBpawvsTKfIDERKdeKrzVuHOMKjadoJGwjztjUzbH"), true, -732551.6456591254, string("ahoCUoTRyrNNaoCVaUZzIpjKfQWUtXWwDZeRV"));
    this->wtshhuPJP();
    this->GxFZPktqA(874356.9969835519, -572721.3055063055, string("QGbIpJyTrdMVOwDNDBvyptWWztBysPLnoHMjaswFmlAcDFzKOdcsGtLJjjLbQSIKLEHCwIVyulTBcSdJarSKAeLaueYhlEFbeJgCjYJoWHRcaBUnALhVsgkitMEUscxOJxlNtCnauyNpWDfIZmGSpfAPQQWgIExPwGIknV"), 691787.3873304247, -952344.6903585306);
    this->SZzsCWwMTJSDwke(1070275333, false);
    this->KSFNxKRpXKY(398761.7306861423, 529999.2488067868, -99036.13462619414, false);
    this->KyfwUqXBUmYbGqTg(true, string("GtFJOjv"));
    this->lfARMpmB(false, 159932150, 90388.23028989694, -1016007.2683756097, true);
    this->JzfNdXXkpxRpJ(string("WbfkWEDBqTVFeYzNSqVQtcytMhsVdPSWjqXpAnKigbnhxvNDmNTcoQXSyvDflqiZvrmjNzuJgYWJ"), -109645065);
    this->mGTlUeyw(918539104, -220241.11287676464, string("LFgfhO"), string("xPLUidVGVlXZiKmfUXWnITGScDmOqAkMaxHlYoVhvRHvTAVvoLhEIkjDKhxMhYUbqmBHMFViRrFrP"));
    this->OQfpgpzaNEekcXL(string("FCCbbRXyITCYYIUChrkRRaPkofwxoEjsKwWmQPHTFfMQFyjuHxBaMjRKDxqnlPVnuSNovMZpdYIVwTxjXwqemyTUqOzFksZbpMSPScQUjwNuVcRKgqOkNqLyLBvGhTFpXQQNuKgmyrEyICKJlHKokOPZUbyJBXoxAmgtsncvlZhjQPKFasETlXzzubWYonZLHmzKjBDXadjfavPpyHZzLRMbyuGCAMCCwnketSERFksMUEkd"));
    this->pQLbVFRUKMQAl(string("GemwnEUVkQtAABrZRsqaXGNiORVCtSuuudMxkYHOYIjtBoRbvWkXPLVBzAeFjAXQrpvAwRURzZUHdpEBxfTODWFwejfhd"), true, true);
    this->duzXe(false);
    this->kZteWDrLyMJrQF(991075.4205568384, -720533.0510969136, 1900330580, 345565220, false);
    this->BuuDBWEEEY(1035110569, -596516890, string("KhEdbSqqxEZAWAhNzfMloYfoYMJyLLXUYWolnzgeXvWZYKPbrbeRnvVKTePDoxOkyL"));
    this->zzCOKcfgnyNbnOo(true, -631877.5739766443, 842193516, string("EviYSSAgaHYfvcCrXycqMRSbFpYhCXYgVQaHPSOXkfhAaTqVyLjdjUxXslzTbRUDSvLMjvYVyMVHeQFqYOWwcZHdLIXB"), -526095626);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LwxJMx
{
public:
    string PAyBPCfIpX;
    bool OhjEo;
    string AiCySTsKOP;

    LwxJMx();
    double DWItbBwNw(double AEZNZPFVcKFNJ, string GgRlV);
    double FKNUewBQWtiyAk(bool MoLPAH);
protected:
    string RSDVBYBhexwIlP;
    bool SpcbCjrV;

    string xZEKWErqhatGbWY(double WnaZVXctAm, double UNRqWwqkV, string CWDHTbExKXt, bool XzIlVgxTymzOoo, double lUoCn);
    bool WfFajKhUIYiC(string hfrEeAryXX, int vVEfZyVgPJZYOqRG, double tXnVNPyUF);
    string UhlrDynkxPC(string bsEQxjF, double DHIJkDhITW, bool BvGiqNaRgVl, string wHXprys, double YkchsbjwwXWozxcF);
    void mYsjF();
    void WWWsxDyhJB(bool WjPhdXm, double JHUBi, int mmvgWHvJKk);
    bool GligrjSny();
    bool PVicAd(bool RoJKBjm, string aQfsDNuFHhk, double AfCNceOpZiRJTn, int maAEYCxIhLEWHU, bool NinBJQg);
    int FEjGochiUeeiWLE();
private:
    double QrylxJejhA;

    string hHVAwoMfDmJn(double oIhDAerCSOPJh, double zsfBO, double LMlSqlltlOd);
    bool SUnlCY(string zxJKPcfXsSCg, double azsNsgsHbM);
    string AGvoIsApTrScW();
};

double LwxJMx::DWItbBwNw(double AEZNZPFVcKFNJ, string GgRlV)
{
    string nkWSQNISV = string("GFGqYDIAEvtGrNohPrRJemSliHAFtXqgacpCIzAwKvSJMWVGdJQDwhyvLlcacCMqfFZzYqxGYoIOqXsJNzfuivlLdPMWEXBZnqPEFFZNjYuyBxGajEu");
    double gHmenKWRSV = -424930.56098649406;
    int SrxyHdiZKG = -208828864;
    double kYVNNDmHcMeiykQJ = 17061.65545635651;
    string CDiUrIoQd = string("jKIjhkcmBiICcSVnrVaHxXhZTbWZaCfqvsmIowPZXrwDubdHSFvuXslGdsXAGKAJUOKXgwDtYuCwCdXHWZFEvQNnrJotEroGjeVeDuFhUaEOQZhsrPOygZQInuCfOoZuvpSYfsPjSiVixNHbRtqMnPxkcnApdbESgyTyAfJMrLrYMcNdLWBmiefmHrKIMkdpkixNMLobnyNPNCRNpHPQmeMeuejrRWcrkfbeCWhDXFhkAMayx");
    bool hlVBjVHndUBomzm = false;
    bool EJxnugmuHKu = true;
    bool JUlxr = true;
    bool dFyoYkaHHngFPK = false;

    return kYVNNDmHcMeiykQJ;
}

double LwxJMx::FKNUewBQWtiyAk(bool MoLPAH)
{
    double CCVceWt = -896719.7830586893;
    bool cpJIEeUEH = false;

    for (int vasoOJMD = 1977024828; vasoOJMD > 0; vasoOJMD--) {
        MoLPAH = ! MoLPAH;
        cpJIEeUEH = cpJIEeUEH;
        cpJIEeUEH = cpJIEeUEH;
        CCVceWt /= CCVceWt;
    }

    for (int LGCEjKMLImA = 1024652147; LGCEjKMLImA > 0; LGCEjKMLImA--) {
        continue;
    }

    if (CCVceWt > -896719.7830586893) {
        for (int AUBgrFrnKXZmdt = 1763350860; AUBgrFrnKXZmdt > 0; AUBgrFrnKXZmdt--) {
            MoLPAH = ! cpJIEeUEH;
            cpJIEeUEH = cpJIEeUEH;
        }
    }

    if (CCVceWt <= -896719.7830586893) {
        for (int SKQTSXOeZyrVQIp = 300519326; SKQTSXOeZyrVQIp > 0; SKQTSXOeZyrVQIp--) {
            cpJIEeUEH = MoLPAH;
            cpJIEeUEH = cpJIEeUEH;
            cpJIEeUEH = cpJIEeUEH;
            CCVceWt = CCVceWt;
        }
    }

    if (cpJIEeUEH == true) {
        for (int wZtto = 498894512; wZtto > 0; wZtto--) {
            cpJIEeUEH = MoLPAH;
            cpJIEeUEH = MoLPAH;
            cpJIEeUEH = ! cpJIEeUEH;
            CCVceWt *= CCVceWt;
        }
    }

    if (CCVceWt > -896719.7830586893) {
        for (int yxuVwZcSAoxJ = 1899891333; yxuVwZcSAoxJ > 0; yxuVwZcSAoxJ--) {
            MoLPAH = ! cpJIEeUEH;
            cpJIEeUEH = ! cpJIEeUEH;
        }
    }

    if (cpJIEeUEH == true) {
        for (int lskUDTVfVxwD = 100115501; lskUDTVfVxwD > 0; lskUDTVfVxwD--) {
            cpJIEeUEH = ! cpJIEeUEH;
            MoLPAH = cpJIEeUEH;
            cpJIEeUEH = MoLPAH;
            cpJIEeUEH = ! MoLPAH;
        }
    }

    for (int RFCcoZK = 141270334; RFCcoZK > 0; RFCcoZK--) {
        cpJIEeUEH = ! MoLPAH;
        cpJIEeUEH = cpJIEeUEH;
        MoLPAH = MoLPAH;
        MoLPAH = MoLPAH;
    }

    return CCVceWt;
}

string LwxJMx::xZEKWErqhatGbWY(double WnaZVXctAm, double UNRqWwqkV, string CWDHTbExKXt, bool XzIlVgxTymzOoo, double lUoCn)
{
    int eYfvMszPJUCqgGL = -278777510;
    string UafYmoqyTAWYmDi = string("BOOgJUwjkzOChhVsNGScrTIAUxUWjPcQOiXXOAkeRBcoFFkUxgvKIGjixjevCpmyXMXBcYsqloLouzwYQmxcLIiPQLtaWwiTymUwTgYABHHZROGUjWbXliSLpFbebvhFE");
    double NyyCaULkvXRhU = -237345.21151170583;

    for (int KujJyBpqVnfJIOB = 1421594995; KujJyBpqVnfJIOB > 0; KujJyBpqVnfJIOB--) {
        continue;
    }

    for (int QoUrVEJg = 672591362; QoUrVEJg > 0; QoUrVEJg--) {
        UafYmoqyTAWYmDi += CWDHTbExKXt;
    }

    for (int cjrjjdr = 2108264374; cjrjjdr > 0; cjrjjdr--) {
        NyyCaULkvXRhU /= NyyCaULkvXRhU;
        UNRqWwqkV *= WnaZVXctAm;
    }

    return UafYmoqyTAWYmDi;
}

bool LwxJMx::WfFajKhUIYiC(string hfrEeAryXX, int vVEfZyVgPJZYOqRG, double tXnVNPyUF)
{
    string RFyinYtwfQTqaCR = string("xXDkFthglNVOCwSoGoeohNeqnZBgVnBvKHwVCzuAiYAaVmFxHovCRSRiJvKYClvxPtxKwagoSOQMKfxmdURscTtfegZgbRvPKTSotcDhPnvoJKiHn");
    double RCNUDMcFkZLopDZI = 651151.3394539555;
    bool uittZ = true;
    int iRyhgeLfy = -1260844878;
    bool BDWLIfPBdXbehTA = false;

    for (int ugahPxNbQ = 211491763; ugahPxNbQ > 0; ugahPxNbQ--) {
        hfrEeAryXX += hfrEeAryXX;
        RCNUDMcFkZLopDZI -= tXnVNPyUF;
        tXnVNPyUF = tXnVNPyUF;
    }

    for (int KVAYDcJqE = 1150934140; KVAYDcJqE > 0; KVAYDcJqE--) {
        continue;
    }

    return BDWLIfPBdXbehTA;
}

string LwxJMx::UhlrDynkxPC(string bsEQxjF, double DHIJkDhITW, bool BvGiqNaRgVl, string wHXprys, double YkchsbjwwXWozxcF)
{
    bool bNKJPrCv = true;
    double ZekCUguIJOoK = -590890.7423973798;
    int qegQDlxjqDoZ = -1399297153;
    double cqEQnZYoim = -603183.1153443475;
    double VoFGUCBhAMKxm = 314334.3139332673;
    bool fqDbUJ = true;
    int OGXAxJSOss = -977196555;
    string ACkUNkMMTXbK = string("stfHWKSspfElMvRxJZQDhnTKTevzzizzJxCpjOIrCrqwyPCFcmdjXIkAyMASjGqJZSxElpvygvKbQcLLdresDNTTTaKCcJNNkCQRUgZCtXEvmmWeTYxZnqdsTLNGUsyXaZepuKXuJRSiZrxChNzGQAHUSEpmvrfIqYsqfBVDqbScPoehLtFdBOXUWNvxeCFhjaWLybJtgXefIoov");

    return ACkUNkMMTXbK;
}

void LwxJMx::mYsjF()
{
    string uGadEXjEUa = string("xaFUlLQaGdwEwEcXvpLRsnXwrdYpuCOkrdcQCPsQf");
    int FIiepdmpfvs = -535682831;
    double ZpdYkw = -88259.89115365795;
}

void LwxJMx::WWWsxDyhJB(bool WjPhdXm, double JHUBi, int mmvgWHvJKk)
{
    bool UeoBoaSosLoXe = true;
    string KwSLSL = string("dJArOLyHheeuchfaQYQkqxe");
    string Phnlz = string("qDRNhvPrRItlufSbWIXCuwXnLGhTgLxQiAHOBDefSHKYiimUjrroRkzpgyVAuyTcEbnJaVlKkzkKmpZGeVIIKXrGXcEkZQxoVTgyLiZyUtIeVlSmHKZgpCNbeEj");
    string vXrfzAjgYdzv = string("HEWeUziNLtuOlZcltleyoaxzxrRQxWWypafMtDxsyxfTsbXKOj");
    bool qacQxJ = false;
    bool inrbD = true;
    string BdRxDDXZTGjDDk = string("hWcjgYzGKHrPUkcXwFylQMyaXQUBaKQMOGcuYqpRTwOpoVVDCnBXLCdyXosxLvlpOzBxVnsRdTTLTjHLwsloirrcnMtqHB");
    double bcWzDQEhS = 669330.9785401496;
    int FJCeaJOyw = -1099103443;

    if (JHUBi == 580266.2359642711) {
        for (int GBsSHHyPTI = 964015359; GBsSHHyPTI > 0; GBsSHHyPTI--) {
            qacQxJ = qacQxJ;
        }
    }
}

bool LwxJMx::GligrjSny()
{
    bool bDKnS = false;
    int tJjehXT = 1459614874;

    for (int ejjfbeHLNSunYG = 1647339304; ejjfbeHLNSunYG > 0; ejjfbeHLNSunYG--) {
        bDKnS = ! bDKnS;
        bDKnS = ! bDKnS;
        tJjehXT *= tJjehXT;
        bDKnS = bDKnS;
        bDKnS = bDKnS;
        tJjehXT /= tJjehXT;
        bDKnS = ! bDKnS;
        bDKnS = ! bDKnS;
    }

    return bDKnS;
}

bool LwxJMx::PVicAd(bool RoJKBjm, string aQfsDNuFHhk, double AfCNceOpZiRJTn, int maAEYCxIhLEWHU, bool NinBJQg)
{
    bool YscSv = false;
    string mCtCNeBaBc = string("mFBdFgalHTSadIlkjwwMMhbGBMKWDgpkcgkZOSIzoQYzIlhQFlnnskRacqURewIubgXgStIumVWPGkewmvpeZccipurcoBEehuylHUQji");
    bool OlBCi = true;
    bool GabjriHNPa = false;
    string EQVMoAiEQkA = string("yBnlhptBzKdUfXRtabIouPxFMtiqeZHjOPQQKmpWpFZpMTuPEyAvtdMQkfEzepxPgdMHgxFGepftSUrbsrDUqLTmJrDeLMeLnwXEAyWDqPWtEDvsbVYzLTxnmaQLkpktFNvBBBmyzbHEEiIUIpWjZXXUxIIiyZxxBNrwAEofNVTeImcwYPrZORMTqDGejQdeJWggxmeGrcWWzHGwkhafeleRUvETLiJVDPQCWfpUJk");
    bool tBXXaPpdfY = false;
    int hLIyTVhJ = -1903275879;

    if (YscSv != false) {
        for (int IWGuoXvRTvuvjpd = 770701053; IWGuoXvRTvuvjpd > 0; IWGuoXvRTvuvjpd--) {
            hLIyTVhJ /= hLIyTVhJ;
        }
    }

    for (int uFHfxMQsUQgkkh = 275951757; uFHfxMQsUQgkkh > 0; uFHfxMQsUQgkkh--) {
        continue;
    }

    if (YscSv != false) {
        for (int KkOqqhxOQMJiF = 14408361; KkOqqhxOQMJiF > 0; KkOqqhxOQMJiF--) {
            GabjriHNPa = RoJKBjm;
        }
    }

    return tBXXaPpdfY;
}

int LwxJMx::FEjGochiUeeiWLE()
{
    bool thMGIWngUshOC = true;
    bool mZsCNrO = false;
    bool VYcFapyMbKjsqsPr = false;
    bool ebMmGGa = true;
    double QwsXyYbmWAnUuAhR = -135867.1005234574;
    string zPSoUMXcEOB = string("JPBXkyIIXsesaJfCoYsxXLwHwJbghHqXDyTHePSxbmnmEcwReXpcSKhvbDBjRbMRseLyEDUTQGnepIoEcAllxoROGdLeOVkXtBKYjSwKLuTlbbpSythjqCyJOixVVnMhCjkVkDtUrZyMQmqCxhPNGTFixQKHyEdJIptAiRVL");
    double VDmLbEnbuXLExFpd = 459954.49210585747;

    return -22985468;
}

string LwxJMx::hHVAwoMfDmJn(double oIhDAerCSOPJh, double zsfBO, double LMlSqlltlOd)
{
    int uzFcaZObH = -785834856;

    if (oIhDAerCSOPJh > 949134.2199184096) {
        for (int EdSgjVSmJGYXkv = 187804198; EdSgjVSmJGYXkv > 0; EdSgjVSmJGYXkv--) {
            uzFcaZObH -= uzFcaZObH;
            oIhDAerCSOPJh *= zsfBO;
            oIhDAerCSOPJh += oIhDAerCSOPJh;
            LMlSqlltlOd += LMlSqlltlOd;
        }
    }

    if (zsfBO >= 909420.2703057849) {
        for (int xPBiXXkhotER = 1825798349; xPBiXXkhotER > 0; xPBiXXkhotER--) {
            zsfBO *= oIhDAerCSOPJh;
            uzFcaZObH /= uzFcaZObH;
            LMlSqlltlOd /= zsfBO;
            LMlSqlltlOd += zsfBO;
            LMlSqlltlOd /= LMlSqlltlOd;
            LMlSqlltlOd -= oIhDAerCSOPJh;
        }
    }

    if (LMlSqlltlOd <= -688631.5910703448) {
        for (int IDtqHbGbpTmFDbnq = 1556923780; IDtqHbGbpTmFDbnq > 0; IDtqHbGbpTmFDbnq--) {
            oIhDAerCSOPJh -= LMlSqlltlOd;
            oIhDAerCSOPJh /= oIhDAerCSOPJh;
            LMlSqlltlOd /= LMlSqlltlOd;
            oIhDAerCSOPJh = oIhDAerCSOPJh;
            LMlSqlltlOd += oIhDAerCSOPJh;
        }
    }

    for (int xwPYcjkIULyjnbu = 848739893; xwPYcjkIULyjnbu > 0; xwPYcjkIULyjnbu--) {
        uzFcaZObH = uzFcaZObH;
        oIhDAerCSOPJh *= zsfBO;
    }

    if (oIhDAerCSOPJh > 909420.2703057849) {
        for (int srJldYYpnsCu = 1163977985; srJldYYpnsCu > 0; srJldYYpnsCu--) {
            oIhDAerCSOPJh *= zsfBO;
            zsfBO /= oIhDAerCSOPJh;
        }
    }

    for (int GJweN = 1225547990; GJweN > 0; GJweN--) {
        oIhDAerCSOPJh -= zsfBO;
        LMlSqlltlOd -= zsfBO;
        LMlSqlltlOd = LMlSqlltlOd;
        oIhDAerCSOPJh *= LMlSqlltlOd;
        oIhDAerCSOPJh = oIhDAerCSOPJh;
    }

    return string("ksShmTrWHJSUnOdQWCpKjXQbdRzooCbxlBWbCKdMJsemlgEMdzaFlhyZcictyvbRcjKQGqHYiukXNzBIJvEKqmqwYbxIkxROuTMGtIrwmeplNvPCELwVDClDkBZZLPSOltWSOtKswEybpqCgMkDbugJFgXVpIxhIyRnmJMLtDaaFBMonWkC");
}

bool LwxJMx::SUnlCY(string zxJKPcfXsSCg, double azsNsgsHbM)
{
    int XAEtZkmvXvckIupL = -1029148910;
    double eOQuXG = -353855.6604837496;
    double pRvSyZFdxdIWtK = -422600.3607074995;
    double elyDAjiEhgoLgS = 666060.444188309;
    int UWuEvqdrVKFyS = 749972333;
    double yuSRiiHEMZCN = 43422.95486543365;

    if (zxJKPcfXsSCg <= string("dfgsVDLHadNhOVEdeubsFAEPpsMTHRAWSVRqrgQkLwDnNezZSUDIxKYpksbYQXktAvFgChATFohbfXdHAHIBymRLsVcsKOZPIGbChOAkWHUECrhOkNvklaAAxmHhFkJdOuoHBEgktuOoZOPZbfmuemoNOQNoHMdvfkLoajzgMeaXhSowINgivduzKdYTnjsYhVaDygfKboGKqlAZyegMSUIHowigbXdAYYwgErAKb")) {
        for (int jnDlNxfuJdNe = 460431505; jnDlNxfuJdNe > 0; jnDlNxfuJdNe--) {
            yuSRiiHEMZCN /= elyDAjiEhgoLgS;
        }
    }

    if (azsNsgsHbM > 43422.95486543365) {
        for (int FVMxcNQiJ = 1116134947; FVMxcNQiJ > 0; FVMxcNQiJ--) {
            continue;
        }
    }

    for (int dkdKiYGF = 1705517803; dkdKiYGF > 0; dkdKiYGF--) {
        yuSRiiHEMZCN -= elyDAjiEhgoLgS;
        azsNsgsHbM /= elyDAjiEhgoLgS;
    }

    if (elyDAjiEhgoLgS == 943290.9405570455) {
        for (int hYIEjbfVCbh = 1935683313; hYIEjbfVCbh > 0; hYIEjbfVCbh--) {
            UWuEvqdrVKFyS = XAEtZkmvXvckIupL;
            eOQuXG *= yuSRiiHEMZCN;
        }
    }

    if (pRvSyZFdxdIWtK <= 43422.95486543365) {
        for (int ODXxLq = 865324681; ODXxLq > 0; ODXxLq--) {
            yuSRiiHEMZCN = yuSRiiHEMZCN;
        }
    }

    for (int pXcqIwsoEsXuNR = 1891995158; pXcqIwsoEsXuNR > 0; pXcqIwsoEsXuNR--) {
        pRvSyZFdxdIWtK *= pRvSyZFdxdIWtK;
        elyDAjiEhgoLgS /= pRvSyZFdxdIWtK;
        pRvSyZFdxdIWtK *= azsNsgsHbM;
    }

    for (int yLrhv = 891543672; yLrhv > 0; yLrhv--) {
        eOQuXG += pRvSyZFdxdIWtK;
        yuSRiiHEMZCN = pRvSyZFdxdIWtK;
        elyDAjiEhgoLgS -= azsNsgsHbM;
        XAEtZkmvXvckIupL = XAEtZkmvXvckIupL;
    }

    return false;
}

string LwxJMx::AGvoIsApTrScW()
{
    string kfEQTIW = string("DVAzOAwfIrCVUeRIhCvATHeXtuDTjpAsyiIfFSwZHVIVVZfPNuyMBPXygEY");
    string CawGXSbX = string("xbqpWpYwkWkqyzwJFLHLrGcbldqHIwzJutJDBnYmBkKJwqAblZIQZzKMyGJgngalTakLTGVLysMtHkijsCtWhoUrRRWqKvveabNfLdjLpVVEjEgVzkYzzngRGehabayceuwHBZlnoVGagwuVHAAVIyKfqUUZmHMwtMrhPfWICkEtaIpbdBwDAyXAOPtoJZTOfrxcUSj");
    int wwobUXUSc = -891314309;
    string zopGEJtJ = string("iYkEwOlxyxwnlnPmzZyyxbzEpPpoiyowmHCweHQgLxmBJLFiGaizrKOHtVlULMltVUEbPpcNWhaqimRwLAylHqpnRZBCCgjSTwxJactUBTLVxCfxEygifPTUcjxaRoepPqzmjCbZIQiDCoZjQZARtaSjQeUHSJyDTkGcbEARXqjHERSwhzrVoNNsedgsfHASasbMpssXURwLpzHTOijkmiYfXxYaMsCMdjnnWyFDCtqwbmKsuOZFvmdlx");
    double dNmywRa = -304916.17270907003;
    double rcAcEzuQFMc = 262464.01260249293;
    int wDWeh = 729103750;
    bool eYAmldlOjUfG = false;
    bool qcCQCFFtJtfKzPBr = true;

    if (eYAmldlOjUfG == false) {
        for (int JYLEaDJt = 727062320; JYLEaDJt > 0; JYLEaDJt--) {
            continue;
        }
    }

    for (int InIBkcuLE = 619881117; InIBkcuLE > 0; InIBkcuLE--) {
        continue;
    }

    for (int NDTSHRt = 340463880; NDTSHRt > 0; NDTSHRt--) {
        eYAmldlOjUfG = ! eYAmldlOjUfG;
        wwobUXUSc *= wDWeh;
    }

    for (int fhKsJV = 1228909623; fhKsJV > 0; fhKsJV--) {
        qcCQCFFtJtfKzPBr = qcCQCFFtJtfKzPBr;
    }

    return zopGEJtJ;
}

LwxJMx::LwxJMx()
{
    this->DWItbBwNw(-827595.5757164928, string("eRHBazGtsLqvqdEPtbsXWxWPgWmGNXCAshFveMwKxhAncpfoCwjnDLSBbdjCKohQA"));
    this->FKNUewBQWtiyAk(true);
    this->xZEKWErqhatGbWY(-348181.2722761296, -791435.9392059898, string("LsvyMkJVbCOAsSxIHvXdlvgQhQAtvYWVOGWOTCYnHZSyvLdEXnxBTtkviKOfGqOxnzibGMucneNBaCbvzQGnoXunOHxyefLnOaECosoaLRvCYJlVfqbVXTxJgtaUELebmTXDqxgnBIgughNTWcfmIizymozZgujnyuVaEJEWpeackoorHfdYyPqifHufEITxJKBRCnEqvXLkpBjUEQbhXMOJZRqrDMYbtXdNPG"), false, 458143.32230144413);
    this->WfFajKhUIYiC(string("RcqrEOtWHrxJEIWmySADQChfjQyGJPgEmVjdFwvOdoLLEDZZovCPBYgzFICdKxmHKRkfafwwhBeKUmKRHRlCByvhoodMiBWQuTcQurkubFrBNWKDtKRXqcapYtXGCBndhzeBGEflVwKrGsOTUKOYiRTyJfFHHCDvULeAncSPNvyMkGpSSsQhWviensuebfhMoQvfuqfj"), 1130393661, 455367.6399332572);
    this->UhlrDynkxPC(string("xfzwQOoXkJvwJvIFhkpfAyjpYmEHdfmRPEJqszzLHAOIiiPHdgGYeYTEKHtbtliPKsUDPllAakgFnIfqkQtzpWlaCCnlgqbdvEYAuMwLBnStaTnFsbOiIGEYVHcyopLFwWWLqmMMIALgdTCIdkMoUJthWPrtbzBihbgipFtJjByWOZndfToJyLzNJNvWwwyviadTaDqMOwEZJlwLzSrYziQLUCyqyUdOKofqTiNvItwhlmpoatFTMxxxNMFof"), 629796.5970100507, false, string("RWUfzdkSaKCeFjumqfmhPZnOJVsvmXlTASqiLgAwJuQDbQeXDwZanrHmYPwVpzuwwBnVgHFqqOyxXILHIzPZeSDPJHroMEwImKHkHMWMzjNRRTMHujODVxyXDBLgzOLWJWQAyHLWznoYflCxtVvotBZiAnhvm"), 534713.3916443503);
    this->mYsjF();
    this->WWWsxDyhJB(false, 580266.2359642711, 422126437);
    this->GligrjSny();
    this->PVicAd(false, string("XQADpULiVtMuxyjxWGxHgmu"), 319594.42473526613, -81671282, true);
    this->FEjGochiUeeiWLE();
    this->hHVAwoMfDmJn(949134.2199184096, 909420.2703057849, -688631.5910703448);
    this->SUnlCY(string("dfgsVDLHadNhOVEdeubsFAEPpsMTHRAWSVRqrgQkLwDnNezZSUDIxKYpksbYQXktAvFgChATFohbfXdHAHIBymRLsVcsKOZPIGbChOAkWHUECrhOkNvklaAAxmHhFkJdOuoHBEgktuOoZOPZbfmuemoNOQNoHMdvfkLoajzgMeaXhSowINgivduzKdYTnjsYhVaDygfKboGKqlAZyegMSUIHowigbXdAYYwgErAKb"), 943290.9405570455);
    this->AGvoIsApTrScW();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gAuiEej
{
public:
    int xnWXrrBao;
    string yxeFVuwkne;
    double HSYfItH;
    string ztXtYb;

    gAuiEej();
    double prBXbS(string CWjPjb, bool kEMoE, string vpkZIWMJCTE, string tFyPUHn, int szzMOEaB);
    double wdUeRmIwpBn(bool cgttQTtc, double cSXgqgfEmvTYY, bool gCFwxQAVod, bool fhuicynNWiuKRSaM, string KATkHSfzLgvo);
    string HGxKeVWXGX(bool CoysOQTaPxThj);
    void YoMZDgtVwbac(bool UWJSfa, bool jGqUBgLIwyRMMoH);
    bool XisOymYrgLSp(double qYXKpwDKxRAdF, int encDRAoNUCnQJ, bool BktKmrmVEzxhz);
    void IyWEqrqK();
    void TYETVskgGpVonzZ(bool lYAuBnSZqAkNu, bool QeAPqINMaJTALOqV, string xUdyK);
protected:
    double OjINnT;

    double SEsinFrds(double HTQTeFnuhWaFOLX, int PYnWDpPonGcI, bool ZZxdbMGlcAbTUTQt, bool rzhlBVjRGFnRNp);
    void GbxOarpbFDGFg(double blBoMVPWGK, int vSGKZUX, int tqqVg, bool zNBMueLWdT, bool jiNcRUGlJqYvPOh);
    double rjOMm(string jiCyhXA);
    bool AMwQMJyqrBW(int FcjExaxAf, bool BLGHqNDyXbGP, bool DtfsO, string vXKWcGtX, int AYrnXnCtb);
private:
    string iEheDNoGtr;
    bool yAgAmpKvqSu;
    double jIWdRF;
    bool QaKdvjtaYQkVKUp;
    int UFBxoNUBXN;

    void ZsVgklWWGqwF(int NzMevSi);
    string JalaJUSCdLw(bool wFvixewOzegH);
    void rewpcPtVApuog(string CNZpnVHpPMAZtFv, double qCPAuTbeQCand, int gpJABouSWlIkDMS, string CgeQn);
    double FhCtURdnjCyukJ(string AxjxhmQQLtalcWU);
    void FTXJri(bool VSkAfeZeSC, double LYUTnYmE);
    string pJElgKRXS(double zjjlmAYLcWzSf, string hiKqKNj, int xOQZRFScXymOhg, double HfKmOBRLy);
    void hHIKbdoB(int QkLJC, string ZgDsmvrGtoN);
};

double gAuiEej::prBXbS(string CWjPjb, bool kEMoE, string vpkZIWMJCTE, string tFyPUHn, int szzMOEaB)
{
    double lDJOhRJiKccGRiQq = 963581.4589624786;
    string fQxdkCbBb = string("nBCttVvBWgjIDuoOAhsftcREashVBgLNMbLoNtqcTqaJbhqJAwNalgXCZHsZBUFzKzrxCvkJdnlFiKMWQwfYuTRwWtAKGprkLUikDYZCNUkxVrsMJXsQpczCIpmXnSpHWpKqmMYBnCWkHHKdzehrkEuqDrnwrXSynEmqjDfLZevNBsrxqgbpUpdfHYrceaLQVjECFD");
    string qATwxyyBNkwTHvt = string("usvesItnOkXJNdRouPp");
    string CrToIWZUZssG = string("YXrwYrbpAjHPdUQPFZKPukEVVdbKKpmNBgVJmFpyOZdyDvzlxPHdAMfMoADpEXuAyuqvizqpENeJHEQXGPsWfBlmTdqnreKgbZzpToqRNJhzqUWINWGxxgRLPfEDZlTHqPCjFEOUjTq");
    bool wliVtpHhXCRUN = false;
    string aRMkJauBCCR = string("ceTfUcWXrioOWkyuOQgcPCcaQQQIlomFtsermlJtQhifrpYpQZhjSNSSuIveeeYKSvfHAfJIuBnSCILcXfJYikIGfDaZHMzpncTZtKCxGZeaXtORXbMCyOAsvKsjPWUDEVdxGCtKlimELQGlGkSOmedhmuqiaQLlnOZkIFLYEXiEetEEoYROHoMUqTuYtrdhFtTYHwQsICAftFlyuvSeMWTQYOv");
    string IAyrIZ = string("UneVFPrUgXHLISgKcZntcokGBNhOWu");
    double pytTDAlySqFn = 388362.88813193055;

    for (int CxGqcUF = 190604929; CxGqcUF > 0; CxGqcUF--) {
        qATwxyyBNkwTHvt += vpkZIWMJCTE;
        vpkZIWMJCTE += qATwxyyBNkwTHvt;
    }

    if (aRMkJauBCCR >= string("ceTfUcWXrioOWkyuOQgcPCcaQQQIlomFtsermlJtQhifrpYpQZhjSNSSuIveeeYKSvfHAfJIuBnSCILcXfJYikIGfDaZHMzpncTZtKCxGZeaXtORXbMCyOAsvKsjPWUDEVdxGCtKlimELQGlGkSOmedhmuqiaQLlnOZkIFLYEXiEetEEoYROHoMUqTuYtrdhFtTYHwQsICAftFlyuvSeMWTQYOv")) {
        for (int fcHmwZVDnmgLFfB = 1630821075; fcHmwZVDnmgLFfB > 0; fcHmwZVDnmgLFfB--) {
            IAyrIZ += IAyrIZ;
            pytTDAlySqFn -= pytTDAlySqFn;
            vpkZIWMJCTE += tFyPUHn;
            aRMkJauBCCR = vpkZIWMJCTE;
            CrToIWZUZssG += tFyPUHn;
        }
    }

    for (int gRRDl = 2054906831; gRRDl > 0; gRRDl--) {
        IAyrIZ = IAyrIZ;
        CWjPjb = vpkZIWMJCTE;
        aRMkJauBCCR = qATwxyyBNkwTHvt;
        CWjPjb = aRMkJauBCCR;
        CWjPjb = IAyrIZ;
        vpkZIWMJCTE = tFyPUHn;
    }

    if (wliVtpHhXCRUN == false) {
        for (int hXOFaJw = 1810955554; hXOFaJw > 0; hXOFaJw--) {
            qATwxyyBNkwTHvt = vpkZIWMJCTE;
            CrToIWZUZssG += tFyPUHn;
            vpkZIWMJCTE += CrToIWZUZssG;
            vpkZIWMJCTE = vpkZIWMJCTE;
        }
    }

    if (qATwxyyBNkwTHvt < string("ZekCziOcohVOBYMjBsMbTONFWqZjlaQxFBuAZpaTRlzDfgrYQhhVukRIbMtEbTEFVGjTZiwMURsMTpimYfMEEvkejkIfWYgWHaxHWPqpZBqybSdUpIpGbZFHDKVoGffpLEGrYBHHsxbwnyFnLRlvNGdczWDkXHrEzPxjMvjHacIPXRTHDoAUB")) {
        for (int IcPdATVG = 1797821167; IcPdATVG > 0; IcPdATVG--) {
            continue;
        }
    }

    return pytTDAlySqFn;
}

double gAuiEej::wdUeRmIwpBn(bool cgttQTtc, double cSXgqgfEmvTYY, bool gCFwxQAVod, bool fhuicynNWiuKRSaM, string KATkHSfzLgvo)
{
    string YoHXpdhDOgTY = string("MUXHUdEVLLXalolfPsVjHJeCTCRSlFhTUXPUmmJtzNLfzZhGSDeahcVnqFuGrIbCvoDSRMvatZBRWNYXiUvcaDUxSgTZlYfWwyJVOoxnaZCDhJiOZPEHHFbbLfpCJtpQsAMdHsynOMcwwTdQnXgEFWHECanhyLlHIktsrzjEXOMUNBWCApPLqgTlQDktMmGbxGPk");
    bool HhrYieAfweJa = true;
    string BROOzGbdItFLsjGS = string("onJumQVBA");
    bool iOUXyway = false;
    string pnuSnNbystJ = string("LMblXIfnpgDuyVwAdIAKoTrZmzLbpswuzevgWWqdYOPeOmngOeGsPtxkBVOnjtSRgayrgZVOpCQeQynRphxuAAUXBOsOKumTcsQIoHFKqnbLsOnCILoGq");
    bool MUDAFjCWecy = true;
    int OoLXUmtfvwd = -2076570054;
    int naLyveMKAA = -1764485835;
    string JnLOzjsFHRASS = string("jLyhwMglTkQsFeLFCXtcfumXvIcCmHsLAKPBdxLAzdCAmAzRqmlqUyFkUQOoRFLppmJatfPLkWNOelsbNLtPdIHBorhoseQqCfPHwri");

    for (int yoBVtdCD = 407574703; yoBVtdCD > 0; yoBVtdCD--) {
        HhrYieAfweJa = iOUXyway;
        fhuicynNWiuKRSaM = ! iOUXyway;
        JnLOzjsFHRASS += KATkHSfzLgvo;
        HhrYieAfweJa = gCFwxQAVod;
        gCFwxQAVod = ! HhrYieAfweJa;
        fhuicynNWiuKRSaM = ! HhrYieAfweJa;
        gCFwxQAVod = ! iOUXyway;
    }

    if (cgttQTtc == false) {
        for (int OClRHmtMAfL = 2131529886; OClRHmtMAfL > 0; OClRHmtMAfL--) {
            MUDAFjCWecy = iOUXyway;
        }
    }

    if (MUDAFjCWecy != false) {
        for (int bSDjJt = 755462150; bSDjJt > 0; bSDjJt--) {
            continue;
        }
    }

    return cSXgqgfEmvTYY;
}

string gAuiEej::HGxKeVWXGX(bool CoysOQTaPxThj)
{
    double TzwrPtKyXjzjhiF = -46415.07143565403;
    bool DnuLpxXTZflof = false;
    int GzhOKjpOKKMaFADb = 1229383759;
    double pgDQxVhM = 687067.0915086847;
    string jWlBth = string("sqHrOImfgoIFcJeEiuSbfqYlRWHSNyYTwwRsDMDljQOYsxYIwsWzkzxXWGwLtAXEIektOmADhsVbEJOuzMVCwCGxEpJatXigMLjUvyYsrQMJZDDHjCkVVIpbQGzTuEzXxfPbczXLeOowdttgjbTcUEjLzeQMNEfJMbVRAbOKNTJHGGHDhzJzsNnfw");
    string uiClFYBKXYnxWipm = string("CyOWurmGavrQcihdZyjkoavxfhEgNpGlweixwisUqHsNmuDVdozlI");
    bool EqIvzgmijQhaUDI = true;

    for (int SEVHXDNSrkPO = 1356496009; SEVHXDNSrkPO > 0; SEVHXDNSrkPO--) {
        EqIvzgmijQhaUDI = EqIvzgmijQhaUDI;
    }

    if (GzhOKjpOKKMaFADb <= 1229383759) {
        for (int xOevwNRYFx = 1613950310; xOevwNRYFx > 0; xOevwNRYFx--) {
            EqIvzgmijQhaUDI = ! DnuLpxXTZflof;
            pgDQxVhM = TzwrPtKyXjzjhiF;
        }
    }

    if (EqIvzgmijQhaUDI != true) {
        for (int LZhJxCz = 2069713595; LZhJxCz > 0; LZhJxCz--) {
            CoysOQTaPxThj = ! CoysOQTaPxThj;
        }
    }

    for (int kJGxoq = 889336905; kJGxoq > 0; kJGxoq--) {
        continue;
    }

    return uiClFYBKXYnxWipm;
}

void gAuiEej::YoMZDgtVwbac(bool UWJSfa, bool jGqUBgLIwyRMMoH)
{
    string UpDdCFhevD = string("MxQvcjaOuoICaxYzycyMRCPAyWjDovUlHxDCYasOgjUgTiteTOLyXRYeWwHEgzbSqcqpvmpvdmBrhaJuJQUFyjxjvSRQxvQtwFIUUFKYEnoBXtudjcSq");
    bool ghNXmlptNtSVEh = false;
    bool JoxRoNR = false;

    for (int HWtyz = 1052229705; HWtyz > 0; HWtyz--) {
        JoxRoNR = ! UWJSfa;
        jGqUBgLIwyRMMoH = ! jGqUBgLIwyRMMoH;
        UpDdCFhevD = UpDdCFhevD;
        JoxRoNR = UWJSfa;
        jGqUBgLIwyRMMoH = ! jGqUBgLIwyRMMoH;
        UWJSfa = ! ghNXmlptNtSVEh;
        UWJSfa = ghNXmlptNtSVEh;
    }

    if (jGqUBgLIwyRMMoH == false) {
        for (int CVGsJbUUuQrmL = 1544184554; CVGsJbUUuQrmL > 0; CVGsJbUUuQrmL--) {
            UWJSfa = JoxRoNR;
            jGqUBgLIwyRMMoH = jGqUBgLIwyRMMoH;
            jGqUBgLIwyRMMoH = ! UWJSfa;
            JoxRoNR = ! ghNXmlptNtSVEh;
            UWJSfa = ! UWJSfa;
        }
    }
}

bool gAuiEej::XisOymYrgLSp(double qYXKpwDKxRAdF, int encDRAoNUCnQJ, bool BktKmrmVEzxhz)
{
    string pnyNGosz = string("ATdXkoycYMdgKAJfsKAbuuXwthqlzlNFQarzICHuamBUWnSagRCavPVnvEqGWGWJYlwZDAnReToaksByKAzJZUJhzpNxFdKfTppnvWC");
    string CbuRnurQtzduVTDD = string("HktnrugSaGLD");
    double dELxfZy = -570541.6395590615;
    int DCHWrmugaXBOJYx = 1821646893;
    string beufZxpIJUbPmu = string("VCyewXRrksIRURGTqRomeYHicwNzpIenMlObQCOBFbwYgebKncCnXUpVyyLZOPTnPByqhtUfAVmPkkzaWqAHBVBfOuPyTJNdtGCOYYUEMwZYty");
    int kscLzRMt = 1359973178;
    string awbNs = string("bRyBPOgFfevvjExMYNGyHLdZYFmcGGxIjbeOQLueaddYGPgacHwKCsJQiQvrXEhMoZRweKJCcowkdELJIryhfVkfezijroilmLkiJvWiAMjNIKprVonjsFhsXrxFlCJlmuQoyMFXtpHQbwmAtjmjmrSLgLGvMCcnVBYzTTJqhwowRzcfxuHgOpIsGhDBrqOhodKKdBFNBkJBjhoMLroYxvfcrzcTlyLUQQVE");

    for (int qZThMhYyrOFjuL = 1464316996; qZThMhYyrOFjuL > 0; qZThMhYyrOFjuL--) {
        dELxfZy /= dELxfZy;
    }

    return BktKmrmVEzxhz;
}

void gAuiEej::IyWEqrqK()
{
    bool SoYcHAN = false;

    if (SoYcHAN != false) {
        for (int GiBeuCdSYwsxI = 1354332090; GiBeuCdSYwsxI > 0; GiBeuCdSYwsxI--) {
            SoYcHAN = ! SoYcHAN;
        }
    }

    if (SoYcHAN == false) {
        for (int FbsxalgjhU = 1454981939; FbsxalgjhU > 0; FbsxalgjhU--) {
            SoYcHAN = SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = SoYcHAN;
        }
    }

    if (SoYcHAN != false) {
        for (int fnzJrjq = 527846942; fnzJrjq > 0; fnzJrjq--) {
            SoYcHAN = SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = SoYcHAN;
            SoYcHAN = SoYcHAN;
        }
    }

    if (SoYcHAN != false) {
        for (int oExHkIw = 1735562972; oExHkIw > 0; oExHkIw--) {
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = SoYcHAN;
            SoYcHAN = ! SoYcHAN;
            SoYcHAN = SoYcHAN;
            SoYcHAN = SoYcHAN;
            SoYcHAN = SoYcHAN;
        }
    }
}

void gAuiEej::TYETVskgGpVonzZ(bool lYAuBnSZqAkNu, bool QeAPqINMaJTALOqV, string xUdyK)
{
    int fPVCVB = -1337265401;
    int bYbkrUWGtClfoz = 1335749255;
    int wSPTZX = -1301056436;
    string fCpbx = string("qFWIGczwSzIXmtfgKSbUPUNOTIkcgMTpIfJUYmIzsEFDLzwEJtrjHdvSDIAYHDvZieaEswYxALDkZPgzmYqDiqUTTWpogeESRvVhWCOjNcZvVvUwUGRGGTxQYIUsEtORPoGLgbBKRZtswmgDSeFrKqtPdSLcXCjoCxVyFDIeSsKDWgbjOdSFuHCkHutAzjicsnbnXhWMBbUmRArRQWPrNleykttjEVxDcldYjzOLywUjUlmqFfwvjy");
    bool RzHSCYtqvAQ = false;
    int RuQWXAz = 511569576;

    for (int SNWLZDpFKXeTay = 999772971; SNWLZDpFKXeTay > 0; SNWLZDpFKXeTay--) {
        continue;
    }

    for (int zRjFXN = 1523779790; zRjFXN > 0; zRjFXN--) {
        lYAuBnSZqAkNu = ! lYAuBnSZqAkNu;
    }
}

double gAuiEej::SEsinFrds(double HTQTeFnuhWaFOLX, int PYnWDpPonGcI, bool ZZxdbMGlcAbTUTQt, bool rzhlBVjRGFnRNp)
{
    string RUWPhbAw = string("UhfdTgelDAZeDtVxCamQXQhELqGtOdjKpoNBpCCZNlPwMPwtfWuyLsCErjwVXuxBHlLJWalWClkKvkNDKiyWIutZhqWAwbCMybgUUVcdwTVKXQXYPtXaRsIKQNawIWUwssWQxTWFcwqrFnnuJUjaTJXcvgMZrkWzFirqwQVbNxbumYgyZFCIGJPpNqrwnzAYlZrPsUbPxTAjTrSY");
    double RijzFyVOfcVCcABj = 408302.8641664666;
    double JKjamBrgYtYXM = -68094.51996924727;
    bool kWHjOrbwogVoUWn = true;

    if (RUWPhbAw < string("UhfdTgelDAZeDtVxCamQXQhELqGtOdjKpoNBpCCZNlPwMPwtfWuyLsCErjwVXuxBHlLJWalWClkKvkNDKiyWIutZhqWAwbCMybgUUVcdwTVKXQXYPtXaRsIKQNawIWUwssWQxTWFcwqrFnnuJUjaTJXcvgMZrkWzFirqwQVbNxbumYgyZFCIGJPpNqrwnzAYlZrPsUbPxTAjTrSY")) {
        for (int dUtKa = 2117943226; dUtKa > 0; dUtKa--) {
            continue;
        }
    }

    for (int LloLWLHyZQsYi = 1828064171; LloLWLHyZQsYi > 0; LloLWLHyZQsYi--) {
        continue;
    }

    if (PYnWDpPonGcI >= 364540509) {
        for (int uNhxNILICD = 118245234; uNhxNILICD > 0; uNhxNILICD--) {
            continue;
        }
    }

    for (int KdhTtBRxPVq = 1904242475; KdhTtBRxPVq > 0; KdhTtBRxPVq--) {
        continue;
    }

    return JKjamBrgYtYXM;
}

void gAuiEej::GbxOarpbFDGFg(double blBoMVPWGK, int vSGKZUX, int tqqVg, bool zNBMueLWdT, bool jiNcRUGlJqYvPOh)
{
    string zhRxgHdGhp = string("GSCSrGcCKZmdYsQoQVoUrDgqSQWQAjnvmYpQZPuzrGwuSbgeoAwXynaiqpLBgwKYxCAYtBvfhREGLAZHTiHLAvyRBXBjUxeSslDUgjRTwiOTcqTSKNsfugJWdTjJeutJyExMgwSfrUEoUxWnFiHFEfMxL");
}

double gAuiEej::rjOMm(string jiCyhXA)
{
    double bonPOnWzCuAIOG = 491901.9625398195;
    double KQOsypfnpcTIqg = -72664.09401742312;

    return KQOsypfnpcTIqg;
}

bool gAuiEej::AMwQMJyqrBW(int FcjExaxAf, bool BLGHqNDyXbGP, bool DtfsO, string vXKWcGtX, int AYrnXnCtb)
{
    int cOMCnQPiTR = 1058928824;
    double aPwQTjCvhU = -575108.8226098233;

    for (int dDVRboTBJBHOY = 1754475781; dDVRboTBJBHOY > 0; dDVRboTBJBHOY--) {
        cOMCnQPiTR /= cOMCnQPiTR;
    }

    for (int DqzKF = 1535343235; DqzKF > 0; DqzKF--) {
        BLGHqNDyXbGP = ! BLGHqNDyXbGP;
        cOMCnQPiTR /= cOMCnQPiTR;
        BLGHqNDyXbGP = ! DtfsO;
    }

    return DtfsO;
}

void gAuiEej::ZsVgklWWGqwF(int NzMevSi)
{
    string GTjZHfuAorWhvVI = string("jzkUHGKhAfnPRAUCTgADPIcDKGABawDzjOxQtWqrShvtrINQKusRtCYhuBeGvhpioPyiaOwCUEEJgbScQTlbIIkvWrDBtdfBplGWctRwWiYLgCflEaeLWlJEdxQvbYOZvhlACoKJTaRHEWSfHqZFjLztsUZiEvZJKMYSUoOexzXP");
    double vCvuvimmXENU = 100384.4220860578;
    bool zAVNLZYgYbrCHye = true;

    for (int EmMOuDumT = 1382132649; EmMOuDumT > 0; EmMOuDumT--) {
        vCvuvimmXENU += vCvuvimmXENU;
        NzMevSi = NzMevSi;
        zAVNLZYgYbrCHye = ! zAVNLZYgYbrCHye;
    }
}

string gAuiEej::JalaJUSCdLw(bool wFvixewOzegH)
{
    double aAeTRUKUwlv = 163213.56229343874;
    string DsggRCJzuqb = string("dHTVPMJNRsywvDpdVAHhkRXCdmfZBftC");
    int ckFWjRxDmGdzw = -2028850530;
    double tErcJmZ = -692592.0637532417;
    bool GWpMzUZXZbyis = true;
    double UwIrtXqjskVVPhT = -624290.6896778499;
    bool uPMIerid = false;
    int QXwCFLwIFzBnM = -733305652;

    for (int CGJQzEMcRkGUhC = 1722894857; CGJQzEMcRkGUhC > 0; CGJQzEMcRkGUhC--) {
        QXwCFLwIFzBnM *= QXwCFLwIFzBnM;
        QXwCFLwIFzBnM /= ckFWjRxDmGdzw;
        aAeTRUKUwlv = tErcJmZ;
    }

    for (int paOQT = 637977387; paOQT > 0; paOQT--) {
        UwIrtXqjskVVPhT /= tErcJmZ;
    }

    if (UwIrtXqjskVVPhT <= -692592.0637532417) {
        for (int ebktePHcLqx = 1561665227; ebktePHcLqx > 0; ebktePHcLqx--) {
            tErcJmZ += aAeTRUKUwlv;
        }
    }

    return DsggRCJzuqb;
}

void gAuiEej::rewpcPtVApuog(string CNZpnVHpPMAZtFv, double qCPAuTbeQCand, int gpJABouSWlIkDMS, string CgeQn)
{
    bool bCeEqraEDiTJuVO = false;
    string pnVZwtdUg = string("ODdWWgxkJeqFsGQsKGfNEhYKsMfkPuCyvyohHGJuOgWrxzDNugUsBWjLOjnjFAPuIunNnPvdXJPgWvFfVWsdzupNvuKVkMzXGYgarvMXKwvQdfgJVGXmLPaAiVvnmyANjsuzmgXOPGKKjjgmtkiltjNpUYooMiHhcdrItFNOjTjc");
    bool OcuTfkgr = false;
    bool IRelLEeBCl = true;
    double IZaQOIwSqJwFCbv = 905097.0281976192;
    bool CwgmdpcOotnP = true;
    double XoRBflmiFrbT = 884269.280829186;
    string seRUdSELO = string("QZyYEGKsnMpPwyysmqDpjuNKITgjYThEbXvjLfbWbqlhcOhuJPThCmRNYfXBAeFfwLVAOXdYuhLoKpDiBRckiYFWdeRf");
    string DHkhedNchdJ = string("qSWMoGWeeFgHXuqCJUiqJEUGnbbSqtmdpfEaBTCTAkMGChGPobjIEtauAiPCxCYMKCGKYTcUNUJfZLgTUAHTpQkxQFXXYnUBTIVxqhbergoAEMCtRBHiCycNTVlWXBPBvxGihGedeJYXrqwgdffaXakPwpYwIYxkbSnbOZCxdKJVWVfieFrbccvRKFgAeaWwK");
}

double gAuiEej::FhCtURdnjCyukJ(string AxjxhmQQLtalcWU)
{
    double DCKWAsdRshgEUSAl = 813176.0719125187;
    double bwOOHnIGSzfB = 602218.1409846621;
    bool tcfzSZUEwPhz = true;
    bool jEFzIIfFwmGlB = false;
    int FKBmsgcw = 62006565;
    string fuiHCf = string("NquStDvOkqUMLmYFbkz");
    string QfRyAFLcHrvywzwr = string("aTxvEZcbVXwDFJpmYRwPLNKCuDPKFtAYPWwfYNDHzuSQmEjuaUAhKrikiFelJoUhOoEkbbukgeIAItfOlIPPfSanQVXpWUjxplDbGJxPtjMgvwNscnTpuEBqWdFOdBVTQLOhRoIlOivRlmumcZ");
    string tZylOhwpe = string("MhmicyLNNJVyKJaxdDHQUXwCbtVUdPUZthwpiMwzzuZoCMIhKMKHNVTNJwYSPqzosrRVPGvmKajebCtueMkeRspUfUpAYwriRYUSCJcJZQMOcwkyYDGKqsaEOQivSOjerBxtSErVfEzoOPrsAGMfsXxshDfbRIdBgEJzKxqZNoExCCNwZrZdYUR");
    int hrAlxTTVCW = 1539957846;
    double NNGwPHLjGv = -1044069.3232717682;

    if (QfRyAFLcHrvywzwr != string("aTxvEZcbVXwDFJpmYRwPLNKCuDPKFtAYPWwfYNDHzuSQmEjuaUAhKrikiFelJoUhOoEkbbukgeIAItfOlIPPfSanQVXpWUjxplDbGJxPtjMgvwNscnTpuEBqWdFOdBVTQLOhRoIlOivRlmumcZ")) {
        for (int snIGeudIiP = 827454912; snIGeudIiP > 0; snIGeudIiP--) {
            QfRyAFLcHrvywzwr = tZylOhwpe;
        }
    }

    for (int QItEc = 1669622996; QItEc > 0; QItEc--) {
        NNGwPHLjGv += bwOOHnIGSzfB;
        DCKWAsdRshgEUSAl /= bwOOHnIGSzfB;
    }

    if (jEFzIIfFwmGlB != true) {
        for (int IUlQZRr = 1134795496; IUlQZRr > 0; IUlQZRr--) {
            continue;
        }
    }

    for (int eLoEDsyeZYMBMzqR = 557864655; eLoEDsyeZYMBMzqR > 0; eLoEDsyeZYMBMzqR--) {
        continue;
    }

    return NNGwPHLjGv;
}

void gAuiEej::FTXJri(bool VSkAfeZeSC, double LYUTnYmE)
{
    int wmcpCWjrMYlG = 264502550;
}

string gAuiEej::pJElgKRXS(double zjjlmAYLcWzSf, string hiKqKNj, int xOQZRFScXymOhg, double HfKmOBRLy)
{
    double WmvNjaPCdhlvM = 707644.4496015172;
    int LgdbIiGGSCWUfblt = -1071732406;
    int kWEbxhjgc = -950033481;
    bool PjMWatOPtOzJjH = false;
    int iXFqy = -2035390586;
    int AKkRGejGUeZf = -338176172;
    double brryokOtVmxqWvwE = -892101.160001127;
    bool dcxzNtLZCMwNu = false;

    if (kWEbxhjgc <= -950033481) {
        for (int FWnXmUHIKO = 117215393; FWnXmUHIKO > 0; FWnXmUHIKO--) {
            AKkRGejGUeZf /= kWEbxhjgc;
            zjjlmAYLcWzSf = WmvNjaPCdhlvM;
        }
    }

    for (int igPGnGABSWy = 315019725; igPGnGABSWy > 0; igPGnGABSWy--) {
        continue;
    }

    return hiKqKNj;
}

void gAuiEej::hHIKbdoB(int QkLJC, string ZgDsmvrGtoN)
{
    int TPoFlELMS = -437163439;
    int fSIvDvfkjSS = -1432920709;

    if (ZgDsmvrGtoN <= string("wwiglSgriFAaXMIZjrFGzJeFDnInNAEVTbAtkQSYNhoWbntjYuoefaGqOxjpydqaCOmnsvRoncBswJNixbdpNbISofgwgVxuxQakWCFVeTwTMbXKKHEbXJKsnrciUdLSWSlKtjeDZZJZLzWEmGqWuyGb")) {
        for (int mLoJPKzPhMJ = 79550488; mLoJPKzPhMJ > 0; mLoJPKzPhMJ--) {
            fSIvDvfkjSS -= TPoFlELMS;
            TPoFlELMS -= QkLJC;
        }
    }

    for (int kwuYylmSWdr = 3471672; kwuYylmSWdr > 0; kwuYylmSWdr--) {
        ZgDsmvrGtoN += ZgDsmvrGtoN;
        TPoFlELMS /= QkLJC;
        fSIvDvfkjSS *= TPoFlELMS;
        TPoFlELMS = fSIvDvfkjSS;
    }

    if (fSIvDvfkjSS < -1432920709) {
        for (int oHuxfZidDyeFbN = 1335765487; oHuxfZidDyeFbN > 0; oHuxfZidDyeFbN--) {
            QkLJC /= TPoFlELMS;
            QkLJC += fSIvDvfkjSS;
            QkLJC *= TPoFlELMS;
            fSIvDvfkjSS += fSIvDvfkjSS;
            TPoFlELMS -= fSIvDvfkjSS;
        }
    }

    if (QkLJC < -437163439) {
        for (int mRIijxRLLxVctI = 1480668720; mRIijxRLLxVctI > 0; mRIijxRLLxVctI--) {
            fSIvDvfkjSS /= TPoFlELMS;
            QkLJC -= QkLJC;
            ZgDsmvrGtoN = ZgDsmvrGtoN;
            TPoFlELMS *= fSIvDvfkjSS;
            ZgDsmvrGtoN = ZgDsmvrGtoN;
        }
    }

    for (int LVhpknJmbpoaXB = 2133106905; LVhpknJmbpoaXB > 0; LVhpknJmbpoaXB--) {
        QkLJC /= TPoFlELMS;
        ZgDsmvrGtoN += ZgDsmvrGtoN;
    }
}

gAuiEej::gAuiEej()
{
    this->prBXbS(string("VzrzLeAUsxWaJcTniPapSJzbWqPgcxRXJhVzQNcjNdZEmJiatCfRQMvAyHuPVZbGxXZEzThBsOeiwePXSSULsbeIhcoGfqAkZOKkoEBnjPTxWqkDjIHuHIpycBeOoTNKJFMTJUassGn"), false, string("KFyUUsODIjkMKFxHmrFDRLBzdiDbORiGMhBikhaKYDzmAJtOAkHgeFmRGgRUFerXOnEWbyHIUpxjfgLYJFAPoqctgLRkpQwGBVLcOIcYGswN"), string("ZekCziOcohVOBYMjBsMbTONFWqZjlaQxFBuAZpaTRlzDfgrYQhhVukRIbMtEbTEFVGjTZiwMURsMTpimYfMEEvkejkIfWYgWHaxHWPqpZBqybSdUpIpGbZFHDKVoGffpLEGrYBHHsxbwnyFnLRlvNGdczWDkXHrEzPxjMvjHacIPXRTHDoAUB"), 963988329);
    this->wdUeRmIwpBn(true, -960683.4685064188, true, false, string("DPnHElONGMagAUHxNbvnatRSXAEsrVaFRnYAQbIpxDWcYeCKCIunfOeYb"));
    this->HGxKeVWXGX(true);
    this->YoMZDgtVwbac(false, false);
    this->XisOymYrgLSp(-226480.1478200645, 1644897296, false);
    this->IyWEqrqK();
    this->TYETVskgGpVonzZ(true, true, string("TgeiedjfpmTuhMZDRBLUjZFgBSWq"));
    this->SEsinFrds(938471.5559598351, 364540509, true, false);
    this->GbxOarpbFDGFg(-264407.6177928915, -1079699200, 1282689296, false, true);
    this->rjOMm(string("baaCpRlDjFrcrcMfrNvGRCYrYEgIDOuEGKurWysdhWtSOZjdefHpRUmTjDsuXuELVRIghpvqayshWaImkfJHIJfCWsGKvdgLEakXm"));
    this->AMwQMJyqrBW(-2026495666, true, false, string("cvvWTRkPEtYVcNAJTkidcnjHIHwOpErmOJNUmtLympNEAqoLrQjCskkzoITdnlgmgQHhLANhYarkVWYTNSWFpaPrwJdClEUossRTOUzNtzKQSqlrHvyDoCcsGYFCwbIWhheWTntKjJGgIkAZCxTPJKyRH"), -1636729238);
    this->ZsVgklWWGqwF(239649302);
    this->JalaJUSCdLw(true);
    this->rewpcPtVApuog(string("erghLAAdPDYBYUfXxBpHeOfzcQBQcwaaruYfdEfTsyrWASgCyMDoBzJcNHDfiwJLEy"), -1005528.6526786339, -880448788, string("iCuaEilQYOMJYsiLGDcBfqRkuWiYhrLRTPvJihTvWlOPzfjiRMriCiOaHZoJgoYesSGUqIBAienizVmhtjgHVXIYVKvyDmpwDkXtNmlVvcnEwTKndTzkeXRhTTgeXKonUfNVOxWyZnDDpcrFExUDxDaHfjaAnqLivUTERlxeqxFbXSblsKaTcdaXKnVYMQGrOLlBtyIgnoKeLAbxXnWBlslsuOMHFBZZDCCRRkLiJsMtmSeydAmxWrGNxlpeC"));
    this->FhCtURdnjCyukJ(string("aYzlZyvqVOeTVjzrHAKGcIELadHhgZjFNonIfPqxxIWzCWtaoSjbdzWJCRGsqRsehlByRZJixfbnmMeUfkpfSIkEPIhrrixjnTSQCdzeplBGnHGdQZVgBJAvCACFsBrSebQspATjhiChdczjlpDriZzdBUKzV"));
    this->FTXJri(true, -1002760.6332822068);
    this->pJElgKRXS(-386656.9226881602, string("RnjrkxcYcJzrLqCZaUdttppCDTAGLpCXIykqjaFwCfrcNyCBPuuygriogjlDJcOzJnRNeIOISOLubMxCEFys"), -1235077724, -269483.27044136607);
    this->hHIKbdoB(1824651304, string("wwiglSgriFAaXMIZjrFGzJeFDnInNAEVTbAtkQSYNhoWbntjYuoefaGqOxjpydqaCOmnsvRoncBswJNixbdpNbISofgwgVxuxQakWCFVeTwTMbXKKHEbXJKsnrciUdLSWSlKtjeDZZJZLzWEmGqWuyGb"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yccPHoLJa
{
public:
    bool yILnsTXzZLTVeYk;

    yccPHoLJa();
    string gdAycejizkWY(int KHCvc, double RxZSbbLTLoGo, bool XbxMnrPEbWnPUdMr, double cvrFdZVyPGpFVzbu);
protected:
    int tfhmaR;
    int TkHoIvwE;
    double MQEio;
    int JoBtH;

    void IjbsXuUNFDdG(string xjvceUOxu, string YqfuJy, int MjGkDQSt, int DDRmNLzwIOTDwNu, double oOnGqAqGQnG);
    bool qELhzspuirr(double vdmGNnlePPJhBRsP, double KswoeCNKi, int COplmTIP);
    double RzjSqTicaPdL(bool GffjSRAVHSAxbTx, string DTInQjnWcWxkkgx, double wRyGO);
    bool WtFYuzqTmZ(int OEPHiXJjmEz, int nqMJuAf, string ruGQQbTcAAKVYqkC, bool QBmLUIHUGTxwEiyd, string KOBBcRjRKjpY);
    int oghzBosxndLLvJKi();
private:
    string KThEx;
    double UKprCSI;
    double McTbCHaf;

    void aEQHKWdwyfyaXL(int nrfeaFgJzlgCF, string UUZWpKqazViFBX, bool gGHYDIaUbhCn);
    void kibFLtLnhy(int QDEcmrIORDQVHy, double TdHIGDpgMuXEG, int CEuzmjtNTyFj);
    string ovXBZQM(bool ZtppOEMYeJI, bool eHTaqhYG, string Tmvxm, string uJhdzlqTv);
    void GQPgFTW(double CkFhwb, int gYYElyiim);
    double xgtcdftqSSQ(int MLRuFMBO, string xGRIiwexqJk, string bqkWVkbSqeogaUE, bool bLogixXYYGVEAC, string xyJFBclNWOCGCVU);
    void YLCXPJTH(double hbkLjYTRXR);
    int irHsvxBYrgt();
    bool ZhMFwpN(string FHdNvJcijKb, int utmlDul, double frASzBvixF);
};

string yccPHoLJa::gdAycejizkWY(int KHCvc, double RxZSbbLTLoGo, bool XbxMnrPEbWnPUdMr, double cvrFdZVyPGpFVzbu)
{
    bool BvKEkaWK = true;
    double WerGqvCNryKd = 845167.4216247927;

    return string("PX");
}

void yccPHoLJa::IjbsXuUNFDdG(string xjvceUOxu, string YqfuJy, int MjGkDQSt, int DDRmNLzwIOTDwNu, double oOnGqAqGQnG)
{
    string kuJBiuQ = string("GoxehTvDtKbwympMYAMMvsZUMMaaKwIVhBPurWHdxxNVJAoHXWqXrESdIfCAgZiGXsgPbUqbIKrrcAnnAIIFXPYmjGpXvihBefwilGIlYljvjmIsuPTMcKOUOlFUICdBCaTLblMfdDViuseRNzQhjUKjLrYwdIYNXPreBXBFpQXdeBJYckfkloogPgPUwngkwDPObEIcMunSrfdiUPFKpJgAB");
    bool xnhWejvXxJ = true;
    int JJSeziquvtOTdqWV = -445238272;
    string WYFlBZwwn = string("GSlQAZYpjNFkTYrbhXNjEWlqK");
    string cnedhyIJljJlSJdS = string("JAzFJQDljQJzQjXQDePSRxavGhSyBwDrsLonCAxwbTtCQIduVZHikxGZCpuMAYGAWVhjrGVzOacaFWSGJplCfynvKoLygeANtDfISSriaqpFpuTquibFvQmkCGJAZNBMjJhAyxfiQhUDRJeb");
    int kyjTWTuovMvBVc = 1194839717;
    string EyFsleColaErB = string("alAcaumKuUpjdVpAIOgFnQDLNcAfHzsCLLlAACbqsGkOjQnTsXEqAApDwOQnXLRzqeaV");
    string Wdykebq = string("pGzhiENpKcENUcLHKdbotRWDEortzKUoGCeAJNoTBuFkqFdCmHbsIpjoYVdyFIvszSqqmgrXsTNSPVQqZodOEFxLVHXBWgMssiuqvGeUCi");
    int lLcDmUa = -1182999224;
    double OAQCcGtntOnj = -828107.192272469;

    if (OAQCcGtntOnj == -828107.192272469) {
        for (int hPzwiqyl = 354234672; hPzwiqyl > 0; hPzwiqyl--) {
            JJSeziquvtOTdqWV /= DDRmNLzwIOTDwNu;
            xjvceUOxu = kuJBiuQ;
        }
    }

    for (int YzmewbonlzAtXfGa = 1697850587; YzmewbonlzAtXfGa > 0; YzmewbonlzAtXfGa--) {
        WYFlBZwwn = kuJBiuQ;
        MjGkDQSt = kyjTWTuovMvBVc;
        lLcDmUa /= kyjTWTuovMvBVc;
        WYFlBZwwn = xjvceUOxu;
    }
}

bool yccPHoLJa::qELhzspuirr(double vdmGNnlePPJhBRsP, double KswoeCNKi, int COplmTIP)
{
    int hBkklfzpiHxCBsq = -988131485;
    double iNExVkMoDoaV = -185339.10211977642;
    int RLtBCI = 243468522;
    double zcnhB = 172999.66371293776;
    bool pWJfLVumZEbA = true;
    int CfHUpfbJlZaphvQ = 491131192;
    int iSlXKEiLwLXklSDp = 1399267403;
    double kWKDVOZpoVFUxOh = -486532.71240780107;

    for (int FKJnphdpGyzMq = 713883895; FKJnphdpGyzMq > 0; FKJnphdpGyzMq--) {
        hBkklfzpiHxCBsq *= iSlXKEiLwLXklSDp;
    }

    for (int xmyfJP = 1279398966; xmyfJP > 0; xmyfJP--) {
        vdmGNnlePPJhBRsP -= zcnhB;
        COplmTIP -= RLtBCI;
    }

    if (COplmTIP < 4177478) {
        for (int rXxyTCJeQP = 1931870852; rXxyTCJeQP > 0; rXxyTCJeQP--) {
            hBkklfzpiHxCBsq = iSlXKEiLwLXklSDp;
            zcnhB /= vdmGNnlePPJhBRsP;
            iSlXKEiLwLXklSDp -= RLtBCI;
        }
    }

    for (int SLfHgYzbM = 452164224; SLfHgYzbM > 0; SLfHgYzbM--) {
        iSlXKEiLwLXklSDp /= hBkklfzpiHxCBsq;
        hBkklfzpiHxCBsq -= CfHUpfbJlZaphvQ;
        pWJfLVumZEbA = ! pWJfLVumZEbA;
    }

    return pWJfLVumZEbA;
}

double yccPHoLJa::RzjSqTicaPdL(bool GffjSRAVHSAxbTx, string DTInQjnWcWxkkgx, double wRyGO)
{
    int NwdwZBwfwkdSHxJo = -430242712;

    return wRyGO;
}

bool yccPHoLJa::WtFYuzqTmZ(int OEPHiXJjmEz, int nqMJuAf, string ruGQQbTcAAKVYqkC, bool QBmLUIHUGTxwEiyd, string KOBBcRjRKjpY)
{
    double VKVLGCeGf = -439994.00873065094;
    double alMwddCAviB = 408526.71361158835;
    double ukbzNMCNHDj = -830203.0478764954;
    string PQmrHinfvWWTRp = string("uDSeOdYwObzCOWbxHsLjmIyj");
    int OnyxPHAaATBPVLch = -1498736937;
    string qpiEQFN = string("PUtNmWpdEsYAewtFmVYpqWrjUPNMJjwxfbEqgftjmSynlxKZDJxbjqYbRhustaAnJriADL");
    double QvaUEZwbGg = 1048138.789473207;

    if (PQmrHinfvWWTRp > string("uDSeOdYwObzCOWbxHsLjmIyj")) {
        for (int RLTeusuN = 908047138; RLTeusuN > 0; RLTeusuN--) {
            PQmrHinfvWWTRp += KOBBcRjRKjpY;
            VKVLGCeGf /= VKVLGCeGf;
        }
    }

    for (int ANEVrdsC = 4327450; ANEVrdsC > 0; ANEVrdsC--) {
        KOBBcRjRKjpY += qpiEQFN;
    }

    for (int HiMIouoWRZxT = 1265958469; HiMIouoWRZxT > 0; HiMIouoWRZxT--) {
        alMwddCAviB += alMwddCAviB;
        ruGQQbTcAAKVYqkC += qpiEQFN;
        ukbzNMCNHDj += alMwddCAviB;
    }

    for (int ZJiZHKxXjDtIejPc = 1182658280; ZJiZHKxXjDtIejPc > 0; ZJiZHKxXjDtIejPc--) {
        QvaUEZwbGg /= QvaUEZwbGg;
    }

    for (int vqXNHAMaak = 1194065267; vqXNHAMaak > 0; vqXNHAMaak--) {
        PQmrHinfvWWTRp += KOBBcRjRKjpY;
        OnyxPHAaATBPVLch -= OEPHiXJjmEz;
        alMwddCAviB /= alMwddCAviB;
    }

    for (int fSeBUGzgSKQEQoa = 585197913; fSeBUGzgSKQEQoa > 0; fSeBUGzgSKQEQoa--) {
        alMwddCAviB *= QvaUEZwbGg;
        OEPHiXJjmEz = OEPHiXJjmEz;
    }

    for (int mkHHKgsWod = 360130154; mkHHKgsWod > 0; mkHHKgsWod--) {
        ukbzNMCNHDj *= QvaUEZwbGg;
        QBmLUIHUGTxwEiyd = QBmLUIHUGTxwEiyd;
        qpiEQFN += qpiEQFN;
        alMwddCAviB /= ukbzNMCNHDj;
        VKVLGCeGf /= QvaUEZwbGg;
        ukbzNMCNHDj /= alMwddCAviB;
    }

    if (qpiEQFN < string("PUtNmWpdEsYAewtFmVYpqWrjUPNMJjwxfbEqgftjmSynlxKZDJxbjqYbRhustaAnJriADL")) {
        for (int grvifDxBNrbADK = 737927634; grvifDxBNrbADK > 0; grvifDxBNrbADK--) {
            QvaUEZwbGg = ukbzNMCNHDj;
            qpiEQFN = ruGQQbTcAAKVYqkC;
        }
    }

    return QBmLUIHUGTxwEiyd;
}

int yccPHoLJa::oghzBosxndLLvJKi()
{
    int KughysqVjKyMRF = -840693443;
    bool rMQPiZRvKFrV = false;
    bool sSkyITJL = false;
    int AQCPeECAXHXWgGj = -435966808;

    for (int qWHNLCd = 397736147; qWHNLCd > 0; qWHNLCd--) {
        KughysqVjKyMRF += AQCPeECAXHXWgGj;
        sSkyITJL = ! sSkyITJL;
    }

    for (int oDFDfr = 2038717955; oDFDfr > 0; oDFDfr--) {
        KughysqVjKyMRF += KughysqVjKyMRF;
    }

    for (int totSqwSReBB = 205443468; totSqwSReBB > 0; totSqwSReBB--) {
        KughysqVjKyMRF /= KughysqVjKyMRF;
        rMQPiZRvKFrV = rMQPiZRvKFrV;
        sSkyITJL = ! sSkyITJL;
        KughysqVjKyMRF = AQCPeECAXHXWgGj;
    }

    for (int dsEZKHt = 1127267604; dsEZKHt > 0; dsEZKHt--) {
        continue;
    }

    for (int YvOZtlXpMvzR = 1669050306; YvOZtlXpMvzR > 0; YvOZtlXpMvzR--) {
        AQCPeECAXHXWgGj -= AQCPeECAXHXWgGj;
        KughysqVjKyMRF = AQCPeECAXHXWgGj;
    }

    for (int Fvfsp = 1598369815; Fvfsp > 0; Fvfsp--) {
        rMQPiZRvKFrV = ! sSkyITJL;
        sSkyITJL = ! rMQPiZRvKFrV;
    }

    if (rMQPiZRvKFrV != false) {
        for (int oCPng = 768094310; oCPng > 0; oCPng--) {
            KughysqVjKyMRF /= KughysqVjKyMRF;
            rMQPiZRvKFrV = sSkyITJL;
            AQCPeECAXHXWgGj *= AQCPeECAXHXWgGj;
            KughysqVjKyMRF = AQCPeECAXHXWgGj;
        }
    }

    if (AQCPeECAXHXWgGj < -840693443) {
        for (int XcaiXwkdCt = 812601424; XcaiXwkdCt > 0; XcaiXwkdCt--) {
            KughysqVjKyMRF -= AQCPeECAXHXWgGj;
        }
    }

    return AQCPeECAXHXWgGj;
}

void yccPHoLJa::aEQHKWdwyfyaXL(int nrfeaFgJzlgCF, string UUZWpKqazViFBX, bool gGHYDIaUbhCn)
{
    int OEMMIHu = 1083296680;
    double oQNSDcfdvsVEt = -819969.6199810401;
    double SqsjLnWzuB = -657326.8640532461;
    string CvkmTpHqpW = string("KopprACnslrFLLALqvAQlWxphZrdsheuvCADgKvszqUZKcbpSquTRGDAEtaQCeMOlxtKQOMigHyIfoWkxFltTBNegGxWlBtDpULTMunZtgrNUzzMrrDVWcizlmhqIihcIRVUEnsIWFUToMABOEngKSziTlKTStORaHWVKYUnyPdIwCVrvCdSEeaEIPVGpozYqejdFYjKG");
    double gSREBF = 800327.6399385475;
    string dsQbcrN = string("jbCHpBxLaXTxnVFojiFEaFXawtjFRTxLHBuYCTPrkDBflNIupBNGfeFfzLhBFkiJDdYdOHWIlojAPnvNlhupiVzIoxmMgejOjxlNJATbMAaaARExLGEYMozwYNNysJxyBGaAuARekHoypnQFsmCf");
    double rRJvxwvVues = -389354.7487501372;
    double ArwDKAXbzts = 952770.2288082938;

    for (int KOUHVZEYkRvxSvTD = 509626580; KOUHVZEYkRvxSvTD > 0; KOUHVZEYkRvxSvTD--) {
        CvkmTpHqpW = UUZWpKqazViFBX;
    }
}

void yccPHoLJa::kibFLtLnhy(int QDEcmrIORDQVHy, double TdHIGDpgMuXEG, int CEuzmjtNTyFj)
{
    double MEejkkMbYqGevMT = 436050.4454505726;
    string xzZljXk = string("lOYuPPGhohNqqPDiNnpFjgEqXtxtSNPaKZWoEhItladorrYZiQlBpMTKewZtETNvFQdzLpewIpEHIzDhiNhsfQqbkyaKGgBKhaxlxyAUcTopMxolYkfmFxIUSbGtqYjiEjYTokQHZfaYRNZAdhkINtbiIqMUonnUMlJopWiGFYfwBMgzphAEQWJdXIriUDEnXEygXiYy");
    int QamcfIlNBtBeym = -1319991197;
    bool otbXTHeDG = false;
    int MXmsxEwWnRIvgtd = -238535417;

    for (int lqxBQGBy = 472391059; lqxBQGBy > 0; lqxBQGBy--) {
        MXmsxEwWnRIvgtd /= MXmsxEwWnRIvgtd;
    }

    for (int WTYDttC = 1439028044; WTYDttC > 0; WTYDttC--) {
        MXmsxEwWnRIvgtd *= QamcfIlNBtBeym;
        QDEcmrIORDQVHy -= QamcfIlNBtBeym;
    }

    for (int VbAOmBjUC = 286920176; VbAOmBjUC > 0; VbAOmBjUC--) {
        CEuzmjtNTyFj *= QamcfIlNBtBeym;
    }

    for (int ukWpDMqQDflo = 49266438; ukWpDMqQDflo > 0; ukWpDMqQDflo--) {
        MEejkkMbYqGevMT += TdHIGDpgMuXEG;
        QDEcmrIORDQVHy /= QamcfIlNBtBeym;
        MXmsxEwWnRIvgtd *= MXmsxEwWnRIvgtd;
    }
}

string yccPHoLJa::ovXBZQM(bool ZtppOEMYeJI, bool eHTaqhYG, string Tmvxm, string uJhdzlqTv)
{
    string EPWRS = string("ZCExbsBFzbCoCBEduMVsIEvVhItaeFgPadALfgvUJOLFEVTBoqSPfbSxhYQbPAVcuZgWUyUpwcltHxsTqV");
    bool CMPNXfxr = false;
    string YPuWosZMZpzyB = string("QvSQXVXkUR");
    bool LezuBz = true;
    bool DZjSXdOtkYpsCCe = false;

    return YPuWosZMZpzyB;
}

void yccPHoLJa::GQPgFTW(double CkFhwb, int gYYElyiim)
{
    string yNSLb = string("DKCgDXNzgUkeCdFlNPhasntZEKvDj");

    for (int YCeSIzMzagnR = 1568122153; YCeSIzMzagnR > 0; YCeSIzMzagnR--) {
        gYYElyiim *= gYYElyiim;
    }

    if (gYYElyiim > -1228697562) {
        for (int ZFXHyOP = 1244185273; ZFXHyOP > 0; ZFXHyOP--) {
            yNSLb = yNSLb;
            yNSLb = yNSLb;
            yNSLb = yNSLb;
        }
    }
}

double yccPHoLJa::xgtcdftqSSQ(int MLRuFMBO, string xGRIiwexqJk, string bqkWVkbSqeogaUE, bool bLogixXYYGVEAC, string xyJFBclNWOCGCVU)
{
    string gkVKPSaGm = string("SbLJ");
    double rzKBK = 225161.54541143082;
    string QnQLGPv = string("tbt");

    if (xGRIiwexqJk != string("MyXVMNVDSXXVVaREaDuHwMnCPAGHefxXCdVJtWryaUPYRiLszyovonYusceeLfdUnQpibfFBFlPxPFJvkwAlepNFWnlyPQFsVqqQfCkAAZMOpfLVBXDOkBBCNVmnbXREaWTOhLQXdXIpPEYOnSmAyZdzVb")) {
        for (int moHbZVgD = 1640670186; moHbZVgD > 0; moHbZVgD--) {
            bqkWVkbSqeogaUE += xyJFBclNWOCGCVU;
            bqkWVkbSqeogaUE += bqkWVkbSqeogaUE;
        }
    }

    for (int KtezHGDktzwn = 43773801; KtezHGDktzwn > 0; KtezHGDktzwn--) {
        bqkWVkbSqeogaUE = xGRIiwexqJk;
        xGRIiwexqJk += gkVKPSaGm;
        QnQLGPv = bqkWVkbSqeogaUE;
        xyJFBclNWOCGCVU = bqkWVkbSqeogaUE;
        gkVKPSaGm = xGRIiwexqJk;
        gkVKPSaGm += xyJFBclNWOCGCVU;
    }

    if (gkVKPSaGm == string("tbt")) {
        for (int axHLICsuhb = 1291996787; axHLICsuhb > 0; axHLICsuhb--) {
            gkVKPSaGm += QnQLGPv;
        }
    }

    return rzKBK;
}

void yccPHoLJa::YLCXPJTH(double hbkLjYTRXR)
{
    bool QNNBwLUzx = false;
    double SCqmVSNiCNpCCms = -563240.2201281829;
    bool uqKcUikZfY = false;
    int VzshktDMKFKAJQb = -814663782;
    double xEEUKWBmC = -498398.1115781506;
    int cAyCmVoUh = -1451629360;

    for (int RGuTJbNX = 1124937297; RGuTJbNX > 0; RGuTJbNX--) {
        continue;
    }
}

int yccPHoLJa::irHsvxBYrgt()
{
    bool PQVhKABdrdZ = true;
    bool itVCwGCfM = true;
    double QdOirCssegwIvIFk = -209854.17053091768;
    double qDEYerDoc = -55669.54354843904;
    string fmpaTeRQYBmDGEh = string("YopwukmrOuzPIinulVJXAmeipnngTKRXAGoxDoGJLACzLeevkFVcHHaiAvwpPFBntTrBWFYxpjfllOSffQsmQmSEKdatHITIyZnoERZenxxcOjnkrRlKkdclYOhTUAXtZqgHzarpfpXtrCHNLrTZVjRGfokIRMfvFZqUwFNYJnhNQojdKgtcQzxaKomQOmUaOPbjtaJRRurMIzDizILqxmdurEBzEeIEWLvdSZOAoPTXdHnElAUrTAqEutwQDO");
    bool rixQlgNFdr = true;

    for (int gFLgH = 1733454473; gFLgH > 0; gFLgH--) {
        PQVhKABdrdZ = rixQlgNFdr;
    }

    for (int csGeXKngUsbb = 438008919; csGeXKngUsbb > 0; csGeXKngUsbb--) {
        QdOirCssegwIvIFk *= QdOirCssegwIvIFk;
    }

    return 992466634;
}

bool yccPHoLJa::ZhMFwpN(string FHdNvJcijKb, int utmlDul, double frASzBvixF)
{
    string NmdLWJ = string("aKHCTDNCuMmaAjjMSVNydcckxepSmGYIFPGVPmImVSiaBSLSxbakvlvRMCACMBQlarufHwwJkYdNfjnTMfNwjPtHKWDwIfAprXprHvmgvdpqNndasXXWizTclhUHTPDOEoMchJcyywKQmcNafJtlwHcZUeJUjGacfZrXUvC");
    string EqQDxeM = string("MajYF");
    int WLBDNEZZIJ = 600999621;

    return true;
}

yccPHoLJa::yccPHoLJa()
{
    this->gdAycejizkWY(-1886407907, 337620.82574739924, false, -490270.4457567393);
    this->IjbsXuUNFDdG(string("mLMnpqtACgovxnuSpRSHnDTLMcHxLxUvECaGZgQxJmfVnGNFiEtTeaPkIFPjfTwrxmjQGfDWZVvAITmbOlvxlGtPoWjxjxlSZvdU"), string("QjCGTleXaWxoLYmRhRGKFWuVNupydNsbHAahpMhUdhDBgrsoDpQTogyRbNBHsnKXKLseLfgcAvZhuxLmUqmsXTpqFxXqbImzakuvCrdRFGwhAHkUNeOGxfqOYBaDZcjewuEVafxNRRyXOOuCgCOOqHDBFZoexxChmQvoXBCWtp"), -1472886741, 1963259167, 443748.5383494275);
    this->qELhzspuirr(-541030.3830544743, 223209.48632036903, 4177478);
    this->RzjSqTicaPdL(false, string("SlNQQwVchBGsqYrSDfSzDcaHxwCegYlWYAYlSjuxLaEWJaDAqyuRlHSRuTBKhSxtibIhVkWtAehvmdFkbQpWYIN"), 1008251.628010205);
    this->WtFYuzqTmZ(609224241, -957332481, string("BplUzKGvdJdCEyonfSiDKvEvdOSCxQRQVrsZBTdELSJjxRTqqQYYxOTrEVUEWZOdpmbGcyurDdzJSqKgumxwIlEuCIMbyJkUusyeHRLXOqCfyjRbcmGECJfEFYvuDQpSgMsSiaZB"), true, string("oyFCAyigRUdHVYONPCggaUEZOuGsjhTGkEWPxXEBLECIQdDdRkbzFIoDhisFJaIFWRsVwHjTtkFaKSpbDpPGXzkyYxZzffvBibpcdoVEMl"));
    this->oghzBosxndLLvJKi();
    this->aEQHKWdwyfyaXL(-1030217254, string("CjsLAmYMQqfpCXUQIWCMBBHiHmJkXwFZdWJQXFjGxTpvzZPhjroKTwDlTTeszCdCbyKafnGWBzvXZBqPBnbCSDGxQkRJvWMkNXQrWoojoNgBOiCwirWKSDvaBKRooAyxYdMuaqjbiaDjYEMqJXVWKWWKdgl"), false);
    this->kibFLtLnhy(-755969518, 359418.91794257023, 482598331);
    this->ovXBZQM(true, false, string("DROhdqlgCRzQ"), string("idyMcgbedjDDmBFvDDCxDabhXzsUzHYkPKzxTzSKYuRGFZMHriTh"));
    this->GQPgFTW(55363.35168020258, -1228697562);
    this->xgtcdftqSSQ(904442819, string("MyXVMNVDSXXVVaREaDuHwMnCPAGHefxXCdVJtWryaUPYRiLszyovonYusceeLfdUnQpibfFBFlPxPFJvkwAlepNFWnlyPQFsVqqQfCkAAZMOpfLVBXDOkBBCNVmnbXREaWTOhLQXdXIpPEYOnSmAyZdzVb"), string("OoyLbAhZAGxsrwKCxQbOCXOTWJgpEsquqSomfprUSpkbSNUTSgGslRJHiqvbpYTLMTKExMuDTYlsLSxnIWfhpXIJziXUggFnsRYdsBXBtpaoWoHPIbRYJZjLyVHocHAXMRxbJcClrLAbkpabgmTtsqdCpXHKsUlnZSQAMtrygysnMhxMNKXuZDHerBytfJzjlvMyGifgpclDajRUaFeDjddVDQBjn"), false, string("CkexhLoBvzrEKbAVDftLrgQbdGxUTLzLaeFMxguIAcBHokEclBYRVFwdEsVfGQYtrQxOLDnmUamWbzXZOFWAgUtHvSqFdbskVfQcfZgnsMUxvZgRatCjOCokREkpiGDDaSgOYhJAApJrwQFbTXZBmAfVcnnLdoApWzVZiQPEtyDSaDWNYXZlIInGmBlxaNbZqkczBVOaoIWnyFVTbUjfELFpusaiCnDBUBmxosM"));
    this->YLCXPJTH(-850791.5447451022);
    this->irHsvxBYrgt();
    this->ZhMFwpN(string("JvkClTrlzGdSWleoLUmXshpIQjWReKqSzAvvElMcaXIDVBdWBfbbonRrcJiDpxjGkMsYAYEwrKqUYVctvEHHsHLDJFxPkEyfFhZTEHFLOtcZLxRyljufVdhYXWGtLdkiquKlOpRgSNtTaacaoNzOmoJsAtbNfFvqRDINKAhQRvkdfoGMWHKgzOWDaGzxwVNayyZrt"), 1187472801, -29549.331174723673);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HfxNw
{
public:
    double zdjXByCuqwr;
    double TonqG;
    int ZyNnqjAlkTjXhN;
    string eIbjqsft;
    int IdJJymNDoQXXUIUi;

    HfxNw();
    double OAZliZsscnIkRqUn(bool dUnHwjg, int pBsFErG, bool WXysShREgAtQw);
    double frRBg(double TrTQQIxZsnuoZZ, bool ixkTkZuazLBTYdu);
    string CKrsOlrHSoqpDgv(bool cWoCfRKpABEsdEI);
protected:
    bool AzHzsruBE;
    double NZtWye;
    int kaLRXsrGcxTehNgg;
    string PxJORU;

    void rZhyxwBRrvSwoin(string wpEDe, bool hSCwObwEocgOSqWc);
    void MtpGkBx(int enWQTr);
    string HtvjcgLCWQyWX(double YXAeQwFDBrFepFS, string qxiULZW, int NlBwZqJd, double PqvNYI);
private:
    double sDOmqsxedruEYGn;
    string OJjjLVwZbPnGa;
    bool NRpKy;

    int IchQoaWShbTqcDgr(int LwQSw, bool PTqijuZQM, string rXRKUeaEc);
    void PbSoREVpLggs(string ojVAFKONV, bool BiBeMNLGIsYphRt);
    void eofFEqoerh(int ZjANKPql);
    int POVtHiWgUJu(int ZrNjkmgRLrxhyO, bool zDcKXfqhaoGhvN);
    string awGADxzfqnsvalQ(bool NPwvzHxqaoBvWvGE, bool VlauzdHu, bool rxikdcyPCGSQPHFt, int AbikUGrNJgRUoNJ, double PNKnJcNxZiKd);
    void naXrGuQfflFB(bool cHdlAW, double XHWOxHmzMYN, double XoFBIzWJdNzAs);
    bool lCKKRFYzwpe(double lgilYsyn, string XQjvrLXxuWocO, bool dDoTXTTXczqj, bool VIbYSijehMUCsbON, int lfvFea);
    int cHuSLudMSYJFS(double apTTeQrpfDlgPkaR, string bNdXh, int JZAXEXVYRIIKDNa, bool syVnu);
};

double HfxNw::OAZliZsscnIkRqUn(bool dUnHwjg, int pBsFErG, bool WXysShREgAtQw)
{
    bool hrdPjivp = true;
    int lYTHcubZuCD = 4365250;
    int vXnisXO = 2011277611;
    string dbEvTH = string("USLtTtTxtEJLybQlIblmdnFwEbZanWXStCyzJuEgtvRWNkpHvGBHEWQlwLPjGwgEfgFtDYDqiqzoHBpjJKGoveAVlldxdOPaFnRBihfOWviFTtrtDxsHBardTfdIBy");
    string xdKdxcoylqMhUb = string("niVczQGubstupFocaaNpKkllMNhhOItMTzabfFBGIxuLregFlCIVhYLIeYpZuyZfpOWIZTITWzoIuXwREfnvmArHQEExJjttzbAiJafmxZNDssTiGHQuqyUgCKEQYSuGZhNGgebepyvDAeRxmcRwOdlYYxbygjarwHSeknGtUlYckTqnNjDjsAOknbsGCoOwkkKuTMVNjocoYmJYiaTeGQpmAseyyTqSWRIDJuaFbiACpKsvEjimqdeN");
    bool FCqUCZnIywMbRvOh = true;
    bool PpDhCIF = false;
    int cPzXzPxVbVZB = -454589624;
    string mMsiTekUx = string("uRGYEHACCdUIIBZSNqGepNleuVtAoVDzdKSvmprmeSCVhvrSLCnIQiTUJIJTyRrxjHjFtNtakmFtddyjlgECeJDVrRegtmuFTpcUVviImqCkOeGkHRglxldBnDzFhWCItFNhiUbsnMyQApEkqySHdIdVRLNsvxEOhhA");
    bool RNXMPJuVggZL = true;

    for (int yuGRTVN = 1794771070; yuGRTVN > 0; yuGRTVN--) {
        mMsiTekUx += mMsiTekUx;
        WXysShREgAtQw = dUnHwjg;
        lYTHcubZuCD /= vXnisXO;
    }

    if (WXysShREgAtQw == true) {
        for (int LiZbLXnLsGHPSHq = 1929254056; LiZbLXnLsGHPSHq > 0; LiZbLXnLsGHPSHq--) {
            pBsFErG = pBsFErG;
        }
    }

    for (int KqVRRswRhmWhQ = 77991202; KqVRRswRhmWhQ > 0; KqVRRswRhmWhQ--) {
        WXysShREgAtQw = ! PpDhCIF;
        lYTHcubZuCD += lYTHcubZuCD;
        PpDhCIF = ! WXysShREgAtQw;
        WXysShREgAtQw = ! WXysShREgAtQw;
    }

    for (int nTuHlBJLzOZppcRn = 348621327; nTuHlBJLzOZppcRn > 0; nTuHlBJLzOZppcRn--) {
        pBsFErG = cPzXzPxVbVZB;
        pBsFErG -= vXnisXO;
    }

    return -83846.48423528807;
}

double HfxNw::frRBg(double TrTQQIxZsnuoZZ, bool ixkTkZuazLBTYdu)
{
    bool kMQCM = false;
    string qChImQ = string("bkPyMmpVCotLWdaOquifLVLeepcrWSAFOuDuQkSpYDjLYprFlAeUAnmRFaxbPRCDQvIbXhMBfzZWlzObJWEeRUihCQWXNjbVikUVsAUlofozNXjdgoGpRQfruzWRoFVw");
    int zpPdqxwm = -1605492898;
    string HPgJXPaD = string("AyhijgrrupWakOWoKELTSvuopPgGLzAhDQDcdPTUODLlkGCozITEInsMJHUWU");
    double aGBtfCAgQJtWqqM = -322137.6210008477;
    int GUzrxKUSQyr = 1948672268;
    bool SkoBm = true;

    for (int EcrsxmojccW = 243264426; EcrsxmojccW > 0; EcrsxmojccW--) {
        zpPdqxwm += zpPdqxwm;
        zpPdqxwm = GUzrxKUSQyr;
    }

    return aGBtfCAgQJtWqqM;
}

string HfxNw::CKrsOlrHSoqpDgv(bool cWoCfRKpABEsdEI)
{
    string pVhNujTBhLh = string("TCVPXxuGnPBauCbvavRmLNgyTxamXcDVhTEHsyUbgdFeENRLtftpsIVFGiQzKDiCLOtaOLbqEBcpZGrbdPJHeYVTcTBdHhMxLnakHnUOHucMkKxcxvFfvkynhngCwuAXPzjlxqhoMTiBgKAfFrjLMEqWbeMpwsqQQaNbtSEYmYxUsBXxbIVkuVxbtqHxyGnWmpnacrqQSeXDdn");
    string LxKjCdRF = string("EPVKReHbHuANMhsWfEvNJqDCgdKuAXjyYEwvcTzqlNIbGKTbYTPRUQDfUseUvEPOaJApbnFdSToYhJRfIKjtqNIUZqUZwLjRZRUYbFdBDdfRKFMBQfxKlHTmicVIZucZDBPWLoERpCpijNPpVaoxGZKMAZ");
    double vsxDgha = 214507.95878706418;

    if (pVhNujTBhLh > string("TCVPXxuGnPBauCbvavRmLNgyTxamXcDVhTEHsyUbgdFeENRLtftpsIVFGiQzKDiCLOtaOLbqEBcpZGrbdPJHeYVTcTBdHhMxLnakHnUOHucMkKxcxvFfvkynhngCwuAXPzjlxqhoMTiBgKAfFrjLMEqWbeMpwsqQQaNbtSEYmYxUsBXxbIVkuVxbtqHxyGnWmpnacrqQSeXDdn")) {
        for (int XaCiMiplbGD = 988302172; XaCiMiplbGD > 0; XaCiMiplbGD--) {
            LxKjCdRF += LxKjCdRF;
        }
    }

    for (int NBKcdgTBnlMu = 298360038; NBKcdgTBnlMu > 0; NBKcdgTBnlMu--) {
        cWoCfRKpABEsdEI = ! cWoCfRKpABEsdEI;
        LxKjCdRF = pVhNujTBhLh;
        vsxDgha -= vsxDgha;
        pVhNujTBhLh = LxKjCdRF;
        cWoCfRKpABEsdEI = ! cWoCfRKpABEsdEI;
    }

    return LxKjCdRF;
}

void HfxNw::rZhyxwBRrvSwoin(string wpEDe, bool hSCwObwEocgOSqWc)
{
    string NkMnLXcny = string("FQHTySNIRYHXAnSiXWkiTbieDddtWXnRMwcwkUJjwFVdPJzictlAetiWnirHNxKdjwbmxcGkAZgpgwNaknMdvYUWpLjbQyQliNIMTEcWyDXjWhcnmPtvkaGKsgJOcVCiWzxoyrTedDgIpmTsuKyJfdwbWrzYApLgLXbrEpGSnekQRoSAPSMhbWdunguoNBh");
    int elByaTBb = -1998673821;
    bool fwWnRtWfJ = false;
    bool gTCBcvR = true;

    if (NkMnLXcny != string("pWNHFDSnPQtgJamxEgyWSMBCDEIYCkcQCANuleGCPTLFiSDsgldrGDThtayGliObHmLJGUdjckvldZvmiDMgoiwkKaGBGOUafJcLDrvTKCLCSnIVsEipLpskWMdhzcomgKFRrZnayvJKyteJGtOuObyyebqUvPrAhQsQuIJWDDDFvkKWDQvlBkHcxWlhMsNNbbZbZSYLtZCfcpxWlZgZHvNwRsWQnuBieHZE")) {
        for (int JnetpSQvnQAKOX = 662144158; JnetpSQvnQAKOX > 0; JnetpSQvnQAKOX--) {
            wpEDe += wpEDe;
            wpEDe += NkMnLXcny;
        }
    }

    for (int tjIuhLHp = 316029529; tjIuhLHp > 0; tjIuhLHp--) {
        fwWnRtWfJ = hSCwObwEocgOSqWc;
        hSCwObwEocgOSqWc = hSCwObwEocgOSqWc;
        fwWnRtWfJ = ! gTCBcvR;
    }

    if (hSCwObwEocgOSqWc == false) {
        for (int rXnrZ = 329367297; rXnrZ > 0; rXnrZ--) {
            hSCwObwEocgOSqWc = gTCBcvR;
            hSCwObwEocgOSqWc = ! hSCwObwEocgOSqWc;
            fwWnRtWfJ = ! fwWnRtWfJ;
        }
    }

    for (int BUikBen = 1155146200; BUikBen > 0; BUikBen--) {
        NkMnLXcny += NkMnLXcny;
        hSCwObwEocgOSqWc = ! hSCwObwEocgOSqWc;
    }

    for (int MdFEQ = 1129083748; MdFEQ > 0; MdFEQ--) {
        hSCwObwEocgOSqWc = hSCwObwEocgOSqWc;
        gTCBcvR = ! hSCwObwEocgOSqWc;
    }

    for (int XggTTZPcaGOKI = 254320359; XggTTZPcaGOKI > 0; XggTTZPcaGOKI--) {
        continue;
    }
}

void HfxNw::MtpGkBx(int enWQTr)
{
    double azHWnKH = -401656.1379412689;
    string OBwdM = string("wbKjxJMILjfghApHDmAkpBzokClaqLLFrOkMBKWZhpKBQvFLWuMCIuCYq");
    double JOOqMoeRcb = -719284.8103051909;
    double zpmnLNtmTpdx = 97780.66959651351;
    string XBfoa = string("TnvENXkGEaicqvUxfOSvHYbdGszzgelDMlXZdVyvmOKmbOqGyWutzoVQuQBauSRYMNNnybXeNoWmRxVLXJstjuTMAUZmGzaHNlFUxwTgogxnhDTaVrRpvzMgFUVNIeAC");
    double bMKzbIpFomnDrkPB = 387156.61000357865;
    double AAIKuVSgAJl = -443323.78000087925;
    bool iHCHDpopMDgdy = true;

    for (int PhBcAPcvyMno = 1264923991; PhBcAPcvyMno > 0; PhBcAPcvyMno--) {
        enWQTr = enWQTr;
        azHWnKH *= JOOqMoeRcb;
        JOOqMoeRcb -= azHWnKH;
        OBwdM += OBwdM;
    }

    if (zpmnLNtmTpdx == 97780.66959651351) {
        for (int vPvMjNDMLM = 1539471278; vPvMjNDMLM > 0; vPvMjNDMLM--) {
            AAIKuVSgAJl += AAIKuVSgAJl;
            azHWnKH /= zpmnLNtmTpdx;
            zpmnLNtmTpdx /= zpmnLNtmTpdx;
        }
    }

    for (int ZLkVSFmV = 534327961; ZLkVSFmV > 0; ZLkVSFmV--) {
        zpmnLNtmTpdx *= JOOqMoeRcb;
    }
}

string HfxNw::HtvjcgLCWQyWX(double YXAeQwFDBrFepFS, string qxiULZW, int NlBwZqJd, double PqvNYI)
{
    int nKPll = -1644091691;
    string MWMNgNhsyWehoLWL = string("cySlStCwuxqZmBUsKfZlfXXSUAOxSILCEZjcwWqqoiujNzOoWUuiNoBMXJXZWVKemHJSIZNEsRirceXtXoNvivdVMAfFojhrONUfloGwTwnIFLwrcOTgpJBbymQYAvEPJsltLaltrurWhsFYncelZcxOCKxxRTTeozsoDtrgvVKleuDYCBHYxWRuNFHPwnLmUZVxGryGGMWWeSYLJipFfXgkUbQUwlZFD");
    string FEsUVyXXwyXHzg = string("MHLgwfhDorNkuWyaWXrDIyZqMGSDfAUZNWPpXopwUmFSUthDQUcvdhAoMMITgEOkXgSMLDUSXVoWCfwBwPxKPctTidNApJszRdrQWVhMimZAEWZgTuJnSDyGwuciXEfqSEprtBzFNsWPDZNEcdDbZVUHPunzBhpjmdZTprGhsWfvfbwsLTasfYiMOkycdnTWjQGcgfVSfrCCFvvJPAINTXggBzbnIbWHFS");

    if (NlBwZqJd > -1644091691) {
        for (int JqHPyRBrLnJsfsD = 1548835665; JqHPyRBrLnJsfsD > 0; JqHPyRBrLnJsfsD--) {
            FEsUVyXXwyXHzg = MWMNgNhsyWehoLWL;
            qxiULZW += FEsUVyXXwyXHzg;
        }
    }

    for (int utQWIsVAKvhXt = 1623900662; utQWIsVAKvhXt > 0; utQWIsVAKvhXt--) {
        continue;
    }

    return FEsUVyXXwyXHzg;
}

int HfxNw::IchQoaWShbTqcDgr(int LwQSw, bool PTqijuZQM, string rXRKUeaEc)
{
    int oIpXVmUacYIHIb = -1802755681;

    for (int AomTKjctknm = 663286558; AomTKjctknm > 0; AomTKjctknm--) {
        LwQSw /= LwQSw;
    }

    if (LwQSw < -1802755681) {
        for (int QDbkgTrQYyT = 1317493629; QDbkgTrQYyT > 0; QDbkgTrQYyT--) {
            LwQSw += oIpXVmUacYIHIb;
            LwQSw = LwQSw;
        }
    }

    for (int ecnaCsSjHSMU = 284714176; ecnaCsSjHSMU > 0; ecnaCsSjHSMU--) {
        continue;
    }

    if (oIpXVmUacYIHIb >= -258219407) {
        for (int biSougRKcxNYG = 830521578; biSougRKcxNYG > 0; biSougRKcxNYG--) {
            rXRKUeaEc += rXRKUeaEc;
            LwQSw /= oIpXVmUacYIHIb;
        }
    }

    return oIpXVmUacYIHIb;
}

void HfxNw::PbSoREVpLggs(string ojVAFKONV, bool BiBeMNLGIsYphRt)
{
    int mtUMxQfGHekEQCw = -1983787564;
    int SZzXSLvRbHPhe = -1154579537;
    bool UPaoZOZHfQoi = false;

    for (int bfKMKWCVIzHCkK = 850687051; bfKMKWCVIzHCkK > 0; bfKMKWCVIzHCkK--) {
        UPaoZOZHfQoi = UPaoZOZHfQoi;
        UPaoZOZHfQoi = ! UPaoZOZHfQoi;
    }

    for (int IdvXofPXLBH = 1068222086; IdvXofPXLBH > 0; IdvXofPXLBH--) {
        UPaoZOZHfQoi = BiBeMNLGIsYphRt;
    }
}

void HfxNw::eofFEqoerh(int ZjANKPql)
{
    string BdyRBoTHwS = string("jNhFztGDpiBcwvNTbiBkkOGYJpAdXsXoAohOrBSLcnkyitmfRPrbbtuEXefGwkBkwXWS");
    int dQBoxgvHjijLMBR = 533436673;
    double LuTTuTXvmRBp = 723017.7014528965;
    string XYWQpcneVGx = string("oXrBAXduYWTfkLUkNqjNOgekXQYgdXvmdBwsmxLXnOXdqoRBKjoNPqDtlZmdwlYFsSVITtxFMqSPQkssndhHpUdmDoGqKbxTDIHkQMiyAREOCxXAwXX");
    bool SebKmuXr = true;

    if (ZjANKPql >= -1140699252) {
        for (int ndZeIjhvxhJgh = 1418169648; ndZeIjhvxhJgh > 0; ndZeIjhvxhJgh--) {
            XYWQpcneVGx = BdyRBoTHwS;
            XYWQpcneVGx += BdyRBoTHwS;
            ZjANKPql += ZjANKPql;
        }
    }

    for (int jowjQ = 1098735988; jowjQ > 0; jowjQ--) {
        continue;
    }

    for (int wnErWnq = 1691762439; wnErWnq > 0; wnErWnq--) {
        continue;
    }

    for (int MECJZKh = 161099058; MECJZKh > 0; MECJZKh--) {
        continue;
    }
}

int HfxNw::POVtHiWgUJu(int ZrNjkmgRLrxhyO, bool zDcKXfqhaoGhvN)
{
    string VfeetgeGfynyvKMe = string("nGzeyhFBBYqmaFalNXzBMNVRdBepNEuhWeGCsTRDcvltQhBvCFHtIkSFrZqAHOsEgsiwkAlCBqoHVjlUpmldsVpTURbfDqbGSgjJUlGSgbfPAMOxQMmNkHqRqEpUHsDKumRNhFdTtPoeGjDnUTZUxELhrOxqBCzYjcysywFJfuiUxoEYTaXsaSERAOLeDHAtHQuqoNiHMSjVfeYzBzdfxlPVJoUOM");
    bool aKPnl = false;
    double ioqgCp = 34564.18193591716;
    int CyDQg = -608041379;
    bool nuLKTjpwTHoqBX = true;
    int tzXDf = -1363240439;
    string lbpYkavNqHT = string("uWNMccDTQfkivuXtBxFKUdFaIJQFVhLmMjsgbNjLsATvWrKRQJVoOoUKjcLGUkPUvMuyWZWQTKZbJnZSYcXsKKfjwaQyXRceNHGvJtwwfOedpgFQBgvJixLcDHU");
    double pJYbh = -795072.2140581872;
    double rqsKSndEv = -33155.78913142267;
    string vZdbkhzjeLzN = string("mIrFSCzaEuEbefvkoikKFZjFjBChrBfaIvBHDrCiBeezzGtWCsSKIYOyAmKxPygazYEXffMbYfRzlYFyuxNnNNPDKPnPhBqLKwroNHdYsKsbVUoAghtjEyafmJAFacmUfVEjcYrxcgLeyuOwnMugXSLKnaLZSSoTdiSlRxagZBGUtkDKNMsgsVVkzqXIyIfUOdDIRoEYxGWEZervClggLmUaJXIdqmxFwFAoijfQtoDrpunXiMYBSS");

    for (int zczpRAIH = 421539010; zczpRAIH > 0; zczpRAIH--) {
        CyDQg /= CyDQg;
        rqsKSndEv = ioqgCp;
    }

    if (pJYbh >= -33155.78913142267) {
        for (int FEeTEwu = 354134425; FEeTEwu > 0; FEeTEwu--) {
            CyDQg *= tzXDf;
            CyDQg += CyDQg;
        }
    }

    for (int MvmHsdAjFCYOcErv = 1102323995; MvmHsdAjFCYOcErv > 0; MvmHsdAjFCYOcErv--) {
        tzXDf /= CyDQg;
    }

    for (int lRoyKHESlZDABm = 1135452389; lRoyKHESlZDABm > 0; lRoyKHESlZDABm--) {
        aKPnl = zDcKXfqhaoGhvN;
        ZrNjkmgRLrxhyO -= CyDQg;
    }

    if (tzXDf != -1363240439) {
        for (int MgRlXhLBY = 1192860531; MgRlXhLBY > 0; MgRlXhLBY--) {
            ioqgCp /= ioqgCp;
            zDcKXfqhaoGhvN = aKPnl;
        }
    }

    return tzXDf;
}

string HfxNw::awGADxzfqnsvalQ(bool NPwvzHxqaoBvWvGE, bool VlauzdHu, bool rxikdcyPCGSQPHFt, int AbikUGrNJgRUoNJ, double PNKnJcNxZiKd)
{
    string DtdmbqAUz = string("COdFVcTuwyXAbULzBcvchjPDTSiaPUwPJaWbbbXoGxiUbwXAAsiByWgfwMNkuuKvHybyFarXrvagzqwsSMnTmamWtZvrBmoHFZTaLkPcWBTWHNeRVftAhelQWpufCetkfaBpCIfPiVIgoOJkohsYtGHDolqIfwfYLkGuFaFIEkkvlgxSrOaEibzZqNpWkosJxmtexiuPXSFzIZjohdNtMlMHOFuerwtgiIAiQgxmbHAXEMKJyfkwRTcuF");
    int wYABExxSJuuZwr = 1697687610;
    double wmNoWU = -328907.78555325634;
    bool MCFTis = false;
    double OTVldWNvLGBfTo = -386244.70122951514;
    bool HgBuDuAAvkaxeny = false;
    string oidwQOYDCW = string("tKPqqhXNmwEdCXrkXCAeSRTwxofwCaqOoZKbLnzUNDzjpFpBqDTUcKLgmmxxCwpBODtozUcspyukSqPUmoinwOfjmGAilNPIIvDlvVbOWCFJltPSxZHvliQFePqFKVtWBzoicjCHBSRdXnfdSLOqXepVMJclemlykCMzaobDZkinxhAufQWKPwsKpbhAiPeCNrkZkFljSWBdfCvHfoylwlrsbzJJv");
    string SvczkNjWaBkbLYb = string("NughYxdfsqyBVsTOlSZvsvAehDNxkTgTiExoRkAmnEtKHRWBesAKezIxqCZOaacPlsvzlUAnEtlzUiamiHoIMgmUYOBudFDnHQfPdjMNlTZjjaakkJDUAbFyMNfmdBWmbDEWctHvNWjzNwAJKtBfbAK");

    if (AbikUGrNJgRUoNJ < 436853540) {
        for (int dMPprCtvcmUWLo = 691168829; dMPprCtvcmUWLo > 0; dMPprCtvcmUWLo--) {
            MCFTis = ! rxikdcyPCGSQPHFt;
            NPwvzHxqaoBvWvGE = MCFTis;
            SvczkNjWaBkbLYb = SvczkNjWaBkbLYb;
        }
    }

    for (int PNncBRWFRknYFpy = 1999183875; PNncBRWFRknYFpy > 0; PNncBRWFRknYFpy--) {
        continue;
    }

    if (oidwQOYDCW >= string("COdFVcTuwyXAbULzBcvchjPDTSiaPUwPJaWbbbXoGxiUbwXAAsiByWgfwMNkuuKvHybyFarXrvagzqwsSMnTmamWtZvrBmoHFZTaLkPcWBTWHNeRVftAhelQWpufCetkfaBpCIfPiVIgoOJkohsYtGHDolqIfwfYLkGuFaFIEkkvlgxSrOaEibzZqNpWkosJxmtexiuPXSFzIZjohdNtMlMHOFuerwtgiIAiQgxmbHAXEMKJyfkwRTcuF")) {
        for (int EXWKL = 782952089; EXWKL > 0; EXWKL--) {
            rxikdcyPCGSQPHFt = ! HgBuDuAAvkaxeny;
            oidwQOYDCW += DtdmbqAUz;
        }
    }

    if (HgBuDuAAvkaxeny == true) {
        for (int PgzaCY = 1957929766; PgzaCY > 0; PgzaCY--) {
            rxikdcyPCGSQPHFt = HgBuDuAAvkaxeny;
            MCFTis = MCFTis;
            OTVldWNvLGBfTo += OTVldWNvLGBfTo;
        }
    }

    for (int BhSLnr = 1921570146; BhSLnr > 0; BhSLnr--) {
        NPwvzHxqaoBvWvGE = ! HgBuDuAAvkaxeny;
    }

    return SvczkNjWaBkbLYb;
}

void HfxNw::naXrGuQfflFB(bool cHdlAW, double XHWOxHmzMYN, double XoFBIzWJdNzAs)
{
    string qPTnxgwBsUDUjeX = string("whExapJUkDQZopusBYueTdLjCTJbzECjxxSqofXPxDbJSbmZMtokugtCQgpBARhfJyTErBkdmJzsKfFooLVrVkxhOilBpNnhtKfDmTdTqeILrHnQXXAwfyDjrfMWHsnXpTVlZJknsaoU");
    bool BdbvrSWDjgC = true;
    double qQBtczHHZrq = -507573.3525290428;
    int JpRYvC = 1965946325;
    double AhzKEEAZQkZBLvCl = 859821.5288486743;
    bool FCkqQwX = true;
    bool BkfqaibqIu = false;
    double sCSHIgPgRkb = -1047488.8027126245;
    double pgvrU = 950395.9286673876;

    for (int yKJeSnHmsOphfE = 808836161; yKJeSnHmsOphfE > 0; yKJeSnHmsOphfE--) {
        XHWOxHmzMYN -= sCSHIgPgRkb;
        cHdlAW = ! cHdlAW;
        qQBtczHHZrq = XHWOxHmzMYN;
        BkfqaibqIu = ! cHdlAW;
    }
}

bool HfxNw::lCKKRFYzwpe(double lgilYsyn, string XQjvrLXxuWocO, bool dDoTXTTXczqj, bool VIbYSijehMUCsbON, int lfvFea)
{
    int tIRLXHbm = 542055262;
    string pbydH = string("MbDRNWPWJJyBgFKpPtgWvRyhTggeSguAAxVWdVxenYUlxQUfatpYVFlUtcouPyBoYyYCGHMGczpEKZPBkVbIfUytjKBwrMWkFsRkyKLmvfJIINSMqELbKVAGbsnVpiVInVoMbKeqlJzTeNekvfkpdNoXxthhJoXQwnuKdtGrDU");
    string sXZbU = string("iCTBAAYpgorWHxGuuQHGekqjWEaoNsKhZmuRVYDCjruBssvduaPtoyISYZkBCSLmmPgBpQLNJumQtvwPYYhkJcLaJoBGFpEyGgmXYhkqlSOGSsrapCelObJwysUJxVXVXWF");
    int bcNAQ = -1147942545;
    double kozcFksp = -603810.0966053377;
    string nsPmko = string("MahuGSxXdhSbEyzkFbAheHXEpVKsqkFyVpVjyZAVoHWXgCtabcyPoNOjMxOxctyCDPlTZqtzSMtmPUESaGkghatpOvNvENRukbaKqnaKgpKqVSXSPYtoPnbDscbcGVqcOKoDOieCIhDsRwWfjibDhk");
    string nrdmmFwrgTJgSt = string("KZWMGxlDxbtvzMULekgQseAEtnRlsSEDZZRocAAOjNpkgWHbaBozFuIHYSqGrVHiMPupZDVWEPuitRpFIduSrPGNOkaStlsMmApDLmOOuntdsObpSWbeBIbfIvTgJKaA");
    string biOjJozjAdMSPE = string("sDJzJPXmjaGCkZmlVUxvaeymnSOCgOjhjGqYEuMkMHICQqzNSudhPOHOASIGbzZQKsvkHfnTLGPchSQaKcbtiGvoIelItWEMMDqRbiYXPnSlRcLhuUzdvnCIvIesbkHZWMnIMGwhCllRmNrWnvrUBrk");
    string jipLi = string("lsuojTKjViBUNJvUWcqoVEHPYlzIzeOALdaOVbWCLfNVZPIUWqDrurIGjoeylbyGflWrfNLwHPbRlylkuORLhgvxicNrvJKyPjYlXGqEIXQTUcO");
    double HbdRHaububh = 399149.3403295085;

    return VIbYSijehMUCsbON;
}

int HfxNw::cHuSLudMSYJFS(double apTTeQrpfDlgPkaR, string bNdXh, int JZAXEXVYRIIKDNa, bool syVnu)
{
    int lNSZWPMQuU = -773750091;
    string LCcFMTkhdD = string("sjVHlJEjHrjrhpPnRweSyHhmHbFwARtRmhCxCMeabitRNTpIueIeACHNTWoASkELCSFjemqDbNxjShXoSfSwxiRIh");
    double TMmQPqJoXgnMRnEf = 959780.6098628123;
    string vSaiBScPjQtwvsb = string("OdUNmpCYUkETFalBsGJFAlUtlPmgaSZiimYyhQUnErsgjsoEQpqsBLrYPZZMDfeHFEcTjPVKmWfAlLqHqVzHqNCwTUQABrsivaRdTRnIsUkRrwnIHftjSzBzVzajPJGdvjHWvFZRlbudwWoYTxZBhSnSHWbBYsLCOuHhXAffQKoSBBP");
    string CRmDPyvBO = string("mdbCnnGgDDcUILsBizNbaNSvMobxrfbTsfMDjnxXEbpGxBhPEkzUXGxUMfdMNcvEJqGqaygZSFhsOFzTifZdpBXRfFGRxAblKupqXdIgNqvEsaBbGOxEUbGhVnwjEQKffKvkxefkeDKbCiYUtgJjdwpTPrJLFWXZmyhYGkuoYYMtrGVfnZJyJIbqpCoffSgCPWInOFSFtWheiYDuwFycMQ");
    double SJYlGOVevZO = -108345.80948258447;
    bool ZmLpkLyGyqGT = true;
    double IfFWykNxHEHmsOcB = -878490.0726083177;
    bool RttPB = false;
    double wjEVZzpsn = -900292.7806049373;

    return lNSZWPMQuU;
}

HfxNw::HfxNw()
{
    this->OAZliZsscnIkRqUn(false, 962602565, true);
    this->frRBg(-683590.4386114577, true);
    this->CKrsOlrHSoqpDgv(true);
    this->rZhyxwBRrvSwoin(string("pWNHFDSnPQtgJamxEgyWSMBCDEIYCkcQCANuleGCPTLFiSDsgldrGDThtayGliObHmLJGUdjckvldZvmiDMgoiwkKaGBGOUafJcLDrvTKCLCSnIVsEipLpskWMdhzcomgKFRrZnayvJKyteJGtOuObyyebqUvPrAhQsQuIJWDDDFvkKWDQvlBkHcxWlhMsNNbbZbZSYLtZCfcpxWlZgZHvNwRsWQnuBieHZE"), false);
    this->MtpGkBx(1351138314);
    this->HtvjcgLCWQyWX(431511.89812154503, string("wRLiJVvbFuAzNOzKSiCrOD"), 401413653, -225259.5301255988);
    this->IchQoaWShbTqcDgr(-258219407, true, string("aBkyBTmaHiMuRGKNVGRTdoQXkiRTmEloTCykILmTFxbSzuTRRuNsJszVzQGLhsehliamoCsCbLWSDBPvPyGjwcHiPGTqNiXgQEIYgpUaVZuOZXkyyNbTysyNyIxIAYcfpFMwPwsKiRMduLxWjPkExbmyWMxvzrYoKEJBsOIhhOTIabtQxWFDhvLfwcwfDjZkiDQsINpbMMUdWnUZoRyoAMZwQQLqTLwPN"));
    this->PbSoREVpLggs(string("haTTkqTIckJtdjfNzdEbqtaBxWvIAmTkSAKDETuRCEuevBSTWJKYGFzhNcYvkHBJuEyGboJJfycZzzdHgmePfvSMVDzXaAMUNFEnNLeAOsxvqoGoCOkLqTvXMFrgkdSAHOgHztyqMkQUYXCZDpvUBrmvYfedaMWvwjhBTzYUYkiuqCkCdJSUWIeOFLgAgYLRACniMCnIJMuuPRFeWVbnpAwuuNDmctYsgTam"), false);
    this->eofFEqoerh(-1140699252);
    this->POVtHiWgUJu(1948140636, false);
    this->awGADxzfqnsvalQ(true, false, true, 436853540, 513297.78700494097);
    this->naXrGuQfflFB(false, 604582.8735535846, -325190.4753054275);
    this->lCKKRFYzwpe(281125.84393412125, string("asDDQdEYCexYWvryNWhwerCOpjLsGcSxgGKWmnqWTTArhATqsZJUwnPHllURjjxNrQiEZxzcCucjrJZJURoXJYVVvACIBJRwQYwWDSweTvPHQNMYLTBFpLH"), false, true, 1601821947);
    this->cHuSLudMSYJFS(-582422.0249022355, string("WxsBDUmPUxdjZLIDnGVpDhtGrWrhwfoDzkyviBFNvQfVCzMeIAZBVqytrTPuFiSpKvIiGyfMCXlwwUegneXqhwIkcGUvCwafIqyZdgNFBlXjSrIrzSELLkOLdjMyM"), -1473919954, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class exYfnNqy
{
public:
    string kkYmjcMZTFxNvq;
    int WQTUOeKr;

    exYfnNqy();
    int nvPtuaBpZtCM(int oQKWkcCE, bool hBbksrIGsFEaJWm, int ZqRzhhab, string aWtemiUgWqJ, string wpbmGmicRmwGJYr);
    int mtLZJhMK();
    string mlNOiuPEvHTvVo();
    void mqbCbPwMOjnuUTi(int BEFTf, string RfWPXcRFYUTBxc);
    void kEoRaRxztAO(bool VhWOKAgCyUf);
    double FeJYb(bool qxxDvKuB, double XgNTrj, string lcGfOsge, string mMiLc);
protected:
    string CGmGuJ;

    void xuvBGTcHZ(int GOAJrVAtbNmIx, int NlkOaA, bool WQdjWiJDUog, string XgUeDBRMHMlH, double DIozKYHzv);
    void SVgDEjuwbUIKkQ();
    bool sarkrwiqg(bool eLfGnqwpc, string yMayljwDdysXY, double ZWvTYdaoAJai, string Bycwt);
    void TWwHddYU(int TPRwsBpPi, double dQItJtfKAoj);
    void jIZglmtfvjh(double tujdOhZuvWw, string mTUcnHxyInQB);
    double gVQKateF(string NkSXlIxYmZmuMfP, double ZLvpbmeNphm);
private:
    double cHUNcxqSURR;

    void toeQdpVISBWLfd();
    bool zSTWfpDWzZMj(bool KXTshFVpVhOpGPS, string YnOAxWUWujG, bool NRLQEkPTfBE);
    bool lKPraM(double oaOPGX, double EJJMjpqLrThvW, double NqhFjaPcBdiRUfh);
    bool ThMpYJw();
    int DnNZOd(double yfgtatrJ, int FvHeSFD);
    int ZyhOf(int wVxlsjMh);
    int grfdIFpLKfiSVMT(int RDwPDcgInV);
    bool lSXXhYXyYkSwo(int jqcmpb, int VgNlMRZeSS, int dVzPtqMZGizL);
};

int exYfnNqy::nvPtuaBpZtCM(int oQKWkcCE, bool hBbksrIGsFEaJWm, int ZqRzhhab, string aWtemiUgWqJ, string wpbmGmicRmwGJYr)
{
    bool LbJnhi = false;
    double CmiVqKffjeUHO = -211153.1560481142;
    string SEFLPzdRu = string("VvYPXhTezPejbcOdfWByypTTFEpVHoDjamudtPSQHMsHjSZXjvKyIYdwUiLVYXKoQGPwYfVxXCwgYCfbvQuWQvCMajTKEqjBaOoSGFEelGRUTkLtlTKyJhVRThlVQUPDWpejaNnxTSiYMPwlTrlwysUWgnNTQrChalwBzdHCtWVkeFZqtRVlvWgoGtVCntY");
    int wAFtGHaYYiVf = 108437257;
    int eYMRjQYl = 1436444457;
    string lIHGAPiUxT = string("gBuImIbsRuvrOQUySJSXFnAnxpXoyzKUdQKZdlgaKNJUvVsGiJSLKMCZqIRZipGRoSuifYCZSZPNSuAdewmphIzRfOUqHwrXpjDbTtyPpHzcMHHFTWUiTkdnOXIVTYqQUFfSpZiXFZlKGhaEyoguNzxkGNktKBdIxXchSkdpWJcTFcVSgWyzQTycVxyXzAdrGckptIqpmkoLrywOZ");
    double eecKFZiWpL = -524066.1272059275;
    string pNobRFwPMuxgnYp = string("srqgGaAChANWRnxyPPtVyhRUygOAlJBLevbSFgGmxKngszDlDpTsPuFjDPrILTrkQVSDtFVpNmvrNuqMEvZUfciUxPIiuBBnBSwcIETxaPjMiWmhgFlJhYSYuCvHGToajiEPkBEidfmgSfqbqEDPRgoURUGDcVEttdDeiKCCfVdpWBIhaUngMVzwbYFBeSQj");
    double KRvig = -431200.44590307644;
    bool LNyNmzpxSxvXY = false;

    for (int nlDGYKgFuki = 2057091809; nlDGYKgFuki > 0; nlDGYKgFuki--) {
        wAFtGHaYYiVf += oQKWkcCE;
        ZqRzhhab = oQKWkcCE;
        KRvig = KRvig;
        oQKWkcCE += oQKWkcCE;
    }

    return eYMRjQYl;
}

int exYfnNqy::mtLZJhMK()
{
    int nCBlAlsVwb = 1766826006;
    double RiCJqMkGNrdu = 992761.6930753341;
    double mzqphxeVV = 542106.5735195247;
    int OmbMjJXiBOKLyJ = 131884147;
    double AwlMtSWvmEeAY = -241738.60010362536;
    double GpuilS = -1014928.6300581448;
    string QVzdxnACGlzbQB = string("dCJAvxmzTBiDDtMpojABoZPYmRWzOyUzXurOPbxfbCSckrMJjPPkchkHfvPKBcWHwaAiktVZLOgmHSvsqtHXPJQpEeEGFEuYOBklpUWIhXDrBwHKmITFwjsYfNyxodcwNaGjSTnQChyDRHuZgbUVJstHXCKoKafxcRRHcVQMQZVuUzPQPNGbefIpNozjqghNPQHbLtXEDuwNuMQSEuBrG");

    for (int bfsHW = 1877938027; bfsHW > 0; bfsHW--) {
        nCBlAlsVwb /= nCBlAlsVwb;
    }

    for (int jrxEKI = 1128814266; jrxEKI > 0; jrxEKI--) {
        mzqphxeVV /= GpuilS;
        nCBlAlsVwb -= OmbMjJXiBOKLyJ;
        GpuilS += AwlMtSWvmEeAY;
        RiCJqMkGNrdu += GpuilS;
        nCBlAlsVwb += OmbMjJXiBOKLyJ;
    }

    if (GpuilS != 992761.6930753341) {
        for (int nPwrADSyhJR = 233633979; nPwrADSyhJR > 0; nPwrADSyhJR--) {
            continue;
        }
    }

    for (int lCpYeeXgg = 903840168; lCpYeeXgg > 0; lCpYeeXgg--) {
        GpuilS += GpuilS;
        GpuilS /= RiCJqMkGNrdu;
        mzqphxeVV -= mzqphxeVV;
    }

    if (GpuilS != -1014928.6300581448) {
        for (int RsAlPR = 1453300740; RsAlPR > 0; RsAlPR--) {
            GpuilS /= AwlMtSWvmEeAY;
            RiCJqMkGNrdu -= RiCJqMkGNrdu;
            GpuilS += RiCJqMkGNrdu;
            AwlMtSWvmEeAY = RiCJqMkGNrdu;
        }
    }

    return OmbMjJXiBOKLyJ;
}

string exYfnNqy::mlNOiuPEvHTvVo()
{
    double ksZdlgaRbFggP = -661629.6615443116;
    string ZjZCeYzaR = string("vB");
    int MVuEuxoEIqSu = -674129151;
    bool BERzIbnsUZDX = false;
    double OgmIJAkXCnmOx = -788148.4912933251;
    double aJUCUBfzBPc = -791777.7327865028;
    int aLBVIqtqU = 1347254229;
    int DghjSYgWPRSgbFpl = 2072152430;
    string KASwtDBivGnEPsEU = string("qfdrCRlQysTLvyBgBBPTzDUsrAYnSjurFGCogcaqyIbaVlsxMSMHrXferjetjOlkErzWuseiQfodySxptabwfhXrSfCTqkoPeTbOxrXFCgGKLPCWOoxocSNBOURWITeCrrMbYWIzndyJHpmnNGxvxdlXxENuPuwvnDPPgVpMZPkqCZEUvPMxAnjbIeJOUaFqaflfxivPDPbFQWIMcwBBaOdEYuPMKlfJRCrpSnkXrVKJRBJenIzwy");

    for (int qOldjULXrUlb = 1115249117; qOldjULXrUlb > 0; qOldjULXrUlb--) {
        continue;
    }

    for (int wTzuc = 903048587; wTzuc > 0; wTzuc--) {
        continue;
    }

    if (aJUCUBfzBPc != -788148.4912933251) {
        for (int LWjOWXwRnX = 156577159; LWjOWXwRnX > 0; LWjOWXwRnX--) {
            DghjSYgWPRSgbFpl *= DghjSYgWPRSgbFpl;
        }
    }

    return KASwtDBivGnEPsEU;
}

void exYfnNqy::mqbCbPwMOjnuUTi(int BEFTf, string RfWPXcRFYUTBxc)
{
    int uGUbcDQwhpk = -1584940148;
    double tJEdZkpmLrYnNRP = -902441.7794342675;
    int FGMMRQpKLArMNPHW = -1861297169;
}

void exYfnNqy::kEoRaRxztAO(bool VhWOKAgCyUf)
{
    int pwqbeUQr = -1183763141;
    bool tqHRWBeMjcaUmQj = true;
    string sbCADiyVexMRS = string("UoIQIMGushjBGHnEgHGNwkFdLFVzQWKJSCICHopPOXkGVyieokcPaielCMljCdkVnWNVSoXdtFChKaoLMaTBGmPpKKgQRyGJtsxjUZguRpWrbpXzkVKaVizLzQNFrWUDzMKKLfoIbTYKvjAWeVZVMNLfXhjfalzDaxoBiCsZnhbCMcacoDkbRtSOGrLExVBzzhiSeaIggYEkRHGqyuxAHLpsTjTvfPSaBzrLYSRYjNREaHwhFeVjv");
    int CCwpfHiDgTCORK = 1545107130;
    bool GHjkFNeKBJI = true;
    bool pLYSkh = false;
    string bzHiWQy = string("JbHOsBfInNehEHColoaCCsNwpFExYstrJMkaGUzOkTSHpIvwcyApgqipIjOlLGrLxHMUpHvnPBXXjDySKJXFNygYnvFIVpddRxKFQnLdcQeeaIpXYiqNoaxTvRavlGpDglAOrbveGFnHsCPz");
    int eKYHUkN = 697379900;

    if (CCwpfHiDgTCORK != 697379900) {
        for (int QFEODSfLrP = 1962960329; QFEODSfLrP > 0; QFEODSfLrP--) {
            sbCADiyVexMRS += bzHiWQy;
            CCwpfHiDgTCORK *= eKYHUkN;
            GHjkFNeKBJI = ! VhWOKAgCyUf;
        }
    }

    for (int AGgTU = 375603494; AGgTU > 0; AGgTU--) {
        bzHiWQy = sbCADiyVexMRS;
        GHjkFNeKBJI = ! pLYSkh;
    }

    for (int wneBYdHe = 1995358261; wneBYdHe > 0; wneBYdHe--) {
        CCwpfHiDgTCORK -= pwqbeUQr;
        VhWOKAgCyUf = ! pLYSkh;
    }

    if (VhWOKAgCyUf == false) {
        for (int HXRdWJzyD = 600343319; HXRdWJzyD > 0; HXRdWJzyD--) {
            continue;
        }
    }

    if (pwqbeUQr <= 697379900) {
        for (int HBdutL = 1047663865; HBdutL > 0; HBdutL--) {
            pwqbeUQr += CCwpfHiDgTCORK;
            CCwpfHiDgTCORK /= pwqbeUQr;
            GHjkFNeKBJI = ! GHjkFNeKBJI;
        }
    }

    for (int YcbScwMs = 1042460416; YcbScwMs > 0; YcbScwMs--) {
        pLYSkh = ! GHjkFNeKBJI;
    }

    for (int LGhHNJUppS = 207024244; LGhHNJUppS > 0; LGhHNJUppS--) {
        GHjkFNeKBJI = tqHRWBeMjcaUmQj;
        eKYHUkN -= pwqbeUQr;
        VhWOKAgCyUf = ! VhWOKAgCyUf;
    }
}

double exYfnNqy::FeJYb(bool qxxDvKuB, double XgNTrj, string lcGfOsge, string mMiLc)
{
    bool cwmXUmM = true;
    int DQHVrCh = 96156915;
    string blslKmEVzAqXkgt = string("NYDLD");
    bool dFtwfr = true;
    string TCHIxJKy = string("UgSKvLwXhiAKMpijgXYKdCeTdSmdJdyvzfLWLjhqxYgivGsAUzRBslfTwfsnPOGRafgDQGAMDnGEaDnfKnVvBedztkxmlmRUEHAINxPonOjsKdwElkwPY");
    string zgfCzYJCCOBKbDyD = string("ZZxxItplLrGEmMbhEHcPhRnshRGOMLWCTpmDpAtChRfgEKwVTentqJIIgdDzcbLSpeOdRypEwIZjOzRTHoyPxQaVJtlCwfVdOzhgQDvnZNydsIvWnuawnWBwhQuvRwVunxJHOgZBQbmBfGormONwVXdrEEyfRhurzGIawlbVzTziQimyYmcwtHRtakOOuxLXiKKgtpuSqkSzJXhOaxu");

    for (int ozjAeeCpX = 1191116975; ozjAeeCpX > 0; ozjAeeCpX--) {
        blslKmEVzAqXkgt += zgfCzYJCCOBKbDyD;
        blslKmEVzAqXkgt += lcGfOsge;
        TCHIxJKy += zgfCzYJCCOBKbDyD;
    }

    if (dFtwfr != true) {
        for (int gAaHazPkgz = 241501397; gAaHazPkgz > 0; gAaHazPkgz--) {
            dFtwfr = ! dFtwfr;
            cwmXUmM = qxxDvKuB;
        }
    }

    return XgNTrj;
}

void exYfnNqy::xuvBGTcHZ(int GOAJrVAtbNmIx, int NlkOaA, bool WQdjWiJDUog, string XgUeDBRMHMlH, double DIozKYHzv)
{
    double cllWR = 57615.31106576325;
    string QcbyFU = string("kZtnvyROHLDLCthylPiHjvxAgIqvwzKsicMUmgZFBgyHdiCjqCFhfDSmqzkiHxbdeepChiFVniCVUKVyzRndZOTPJrwKDHiloPTBYPyiLmTzgYFPOBYBEoWnllWhFQJGpLiFqIGtuqRXKbVpmvrFlqhFHQeTnalBeyqYbyaMdKMDgPsgAgnurEdLDPqQEAmcEnQBMDSB");
    int OUgjDEEvKlddqJ = 1405768401;
    int RUBCCyBhyQYW = 815098854;
    string CpWepGsmbGzZa = string("LDRBMiUySdtfLzcCygTUwGjilGYxoNPnLHuqRCDFHxlFfDWSpkLxbmmfUjpgxCPIBfJVxPfRYCZwDhmGiYMscLGRHSCdexmbgrNcymfSliqmoeDyNvDISuiaHNNDubMeHmOytgnPQvulxAwtIBbMvqtNmJCNUWpeaDBCCVWaegIGOFKnaheOGWvGUsltVbuXwFmHySKnEnBAyguJrkAtcbSvhKjqZeQsRiAeKBrViLdKjoMUIKtDclBWbtTa");
    int ztKFOByXKstyZk = -166980763;
    double fEorwTdBlPjlKk = 606810.765576965;
    int eMNLTmhf = -309368149;
    double vfgxCbGNIDLBLsNk = -338229.887985485;
}

void exYfnNqy::SVgDEjuwbUIKkQ()
{
    double akYkwqVaCyUpWG = -74515.93005710948;
    int iKfBJAIGjTCcyELW = 199582032;
    double tTfTzuirDS = 642761.0268569401;

    for (int pXuZbTNgKSSpC = 2071151374; pXuZbTNgKSSpC > 0; pXuZbTNgKSSpC--) {
        tTfTzuirDS /= akYkwqVaCyUpWG;
        tTfTzuirDS = tTfTzuirDS;
        akYkwqVaCyUpWG -= akYkwqVaCyUpWG;
        tTfTzuirDS += akYkwqVaCyUpWG;
    }
}

bool exYfnNqy::sarkrwiqg(bool eLfGnqwpc, string yMayljwDdysXY, double ZWvTYdaoAJai, string Bycwt)
{
    bool LnouEgmyTbrZ = true;
    double otbqHdtVBsOqtzly = -233316.2089007986;

    for (int HvDQKOOryr = 1355670237; HvDQKOOryr > 0; HvDQKOOryr--) {
        ZWvTYdaoAJai /= otbqHdtVBsOqtzly;
        Bycwt += yMayljwDdysXY;
        ZWvTYdaoAJai *= otbqHdtVBsOqtzly;
    }

    for (int DjVttONgzjHmXvX = 192610464; DjVttONgzjHmXvX > 0; DjVttONgzjHmXvX--) {
        continue;
    }

    for (int wecZvZfOsBiW = 1697732019; wecZvZfOsBiW > 0; wecZvZfOsBiW--) {
        yMayljwDdysXY += Bycwt;
        Bycwt = Bycwt;
        ZWvTYdaoAJai = otbqHdtVBsOqtzly;
    }

    for (int HkDKpQKh = 1059078248; HkDKpQKh > 0; HkDKpQKh--) {
        ZWvTYdaoAJai += otbqHdtVBsOqtzly;
        ZWvTYdaoAJai = otbqHdtVBsOqtzly;
    }

    for (int jMvHhJUeerF = 1985092725; jMvHhJUeerF > 0; jMvHhJUeerF--) {
        otbqHdtVBsOqtzly *= otbqHdtVBsOqtzly;
        otbqHdtVBsOqtzly /= otbqHdtVBsOqtzly;
    }

    return LnouEgmyTbrZ;
}

void exYfnNqy::TWwHddYU(int TPRwsBpPi, double dQItJtfKAoj)
{
    bool mVQDoEaGlhWBiKb = false;
    double BnHrvTrNgY = -571991.4138444063;
    string DMfEMMsBaueTYW = string("ndHBjbuoIpTRgoLWVVRqpoGSdiXhUOKGAqAHmfYbXuYnGNYHNhgDnBadwTSIZNHkwhlBmxaZhaVvMMUHaUFgItKOnwGvVjALcpXKZOldtXNaYgbNBYNnNXQPvoxvDEfMxJkHLSecJvxVBIbzLkAPbjEFSxRvEHbvqsLKsIBBZaVsDFtALZfGEAtqfbdEGLRbmlMthuaMudSDZzkrRgCivmoKdwkpUMw");
    int TFdeRIZnR = 1637044244;
    double wczNl = -745771.9303347431;
    double ithkuWk = -361973.0659329816;
    int XVyIzkIZTa = -68276684;
    bool IYmQvFxwXDWavho = false;
    string MpNQqBXxXcqpLJrT = string("JaTJXFmgIAzFSNRlYnltupFDNyVnGUeYtLfIIlEybRRXYjOjvVMfWSQNjxYQrgQkYExiHGMwhbWvrMuMxhcSWsRPDQmKrzulMTYEoyCCUPOgBsyhRlTuSwgwXbIFzPREmlcxntcprQGzlEBtyyFMNsaddtkxzTfrzbqAMulOKrTlMHtZjzQ");
    bool wKgMtMCnNlLk = false;

    for (int KmNQqNyPjsaun = 814327630; KmNQqNyPjsaun > 0; KmNQqNyPjsaun--) {
        wKgMtMCnNlLk = wKgMtMCnNlLk;
        wKgMtMCnNlLk = IYmQvFxwXDWavho;
    }

    for (int pSjubpWrqinuOl = 633235483; pSjubpWrqinuOl > 0; pSjubpWrqinuOl--) {
        BnHrvTrNgY /= wczNl;
        dQItJtfKAoj -= dQItJtfKAoj;
        BnHrvTrNgY = wczNl;
        BnHrvTrNgY /= BnHrvTrNgY;
    }

    if (XVyIzkIZTa >= -877418799) {
        for (int bhoNcAFUNBWI = 801992914; bhoNcAFUNBWI > 0; bhoNcAFUNBWI--) {
            continue;
        }
    }

    for (int EsrKTlJkdSQpu = 1928552538; EsrKTlJkdSQpu > 0; EsrKTlJkdSQpu--) {
        IYmQvFxwXDWavho = ! wKgMtMCnNlLk;
    }
}

void exYfnNqy::jIZglmtfvjh(double tujdOhZuvWw, string mTUcnHxyInQB)
{
    double pEMBoUVI = -967410.7221886968;
    double dnWWuyloEi = 335071.57847745204;
    bool nvplYFZdDEKdeN = true;
    int asHaFsgDUWU = 1782498400;
    bool VaqVhhxt = true;
    int VtwDjdGHMXZqwav = 347105706;
    int WHbCTB = -380975267;
    int JJsDwTRAOunCXO = 1148890920;
    string vuCotwvDgueG = string("fWYeaCe");

    for (int ibAuNUzjByKW = 49376231; ibAuNUzjByKW > 0; ibAuNUzjByKW--) {
        continue;
    }
}

double exYfnNqy::gVQKateF(string NkSXlIxYmZmuMfP, double ZLvpbmeNphm)
{
    bool BUqvisgwdvZlpzz = false;
    string cLZuzHRTDPjh = string("qTvRclISQsov");
    double NKSdfY = 655124.9043244775;
    int SLImg = 388504052;
    double keZaXJ = -269965.9516195185;
    double ZqmQcIHzGAdJ = -817757.9669885329;
    string sPiebrmXpTGKyy = string("SJHWiQpvXwsIrmmsoUxXbLqDTHKNwwyVrnXtlhtKFyXzAfFYvrwiYttBQfNjzlLAUnFLVrqMPKcNU");
    double sHjtrBOxBvVGv = 565408.568268347;
    int uZWBO = -1154175763;

    return sHjtrBOxBvVGv;
}

void exYfnNqy::toeQdpVISBWLfd()
{
    string GLsENCbRSmheSxUi = string("IHOFpmIUhvXOCbvOjwYejaHmYfPUOgxquyyuztHtLoUKaLghrhkFbqVWlRDGArGZZlFPzvFYvJipBskyuDepepUCCtWztREJRNAKnScWxVrpfSAyZdiNtlbCcSLiorTUGrKoWRmwqZkHyXWGKdVYQaGoCcCYTbHvbpmkWFdqIOgOLLOpQnvwvmpeNjWvh");
    string dZMRgrP = string("NZQSXDRqBMbKthSZfXsFaqhbXtfXbRUPCzJmKgKzrIpDIWNHXbUeKOfpAIcHtVqOAXnGMorugQjeBmSJYAcZbkQAtLPXaCjLkZtTmtyqJUEYHECrCzeskogZzPpTEXMVYEhxeFQjsbAmehjlGDhjtnfIeEJHlySqyZwGLEPvrojLF");

    if (GLsENCbRSmheSxUi <= string("IHOFpmIUhvXOCbvOjwYejaHmYfPUOgxquyyuztHtLoUKaLghrhkFbqVWlRDGArGZZlFPzvFYvJipBskyuDepepUCCtWztREJRNAKnScWxVrpfSAyZdiNtlbCcSLiorTUGrKoWRmwqZkHyXWGKdVYQaGoCcCYTbHvbpmkWFdqIOgOLLOpQnvwvmpeNjWvh")) {
        for (int UEVpXisJpTtdCoy = 82846683; UEVpXisJpTtdCoy > 0; UEVpXisJpTtdCoy--) {
            GLsENCbRSmheSxUi += GLsENCbRSmheSxUi;
            dZMRgrP = GLsENCbRSmheSxUi;
            GLsENCbRSmheSxUi += GLsENCbRSmheSxUi;
            GLsENCbRSmheSxUi = dZMRgrP;
            dZMRgrP = GLsENCbRSmheSxUi;
        }
    }

    if (GLsENCbRSmheSxUi <= string("IHOFpmIUhvXOCbvOjwYejaHmYfPUOgxquyyuztHtLoUKaLghrhkFbqVWlRDGArGZZlFPzvFYvJipBskyuDepepUCCtWztREJRNAKnScWxVrpfSAyZdiNtlbCcSLiorTUGrKoWRmwqZkHyXWGKdVYQaGoCcCYTbHvbpmkWFdqIOgOLLOpQnvwvmpeNjWvh")) {
        for (int vuQdEsARhYcnPIl = 717010939; vuQdEsARhYcnPIl > 0; vuQdEsARhYcnPIl--) {
            GLsENCbRSmheSxUi += GLsENCbRSmheSxUi;
            dZMRgrP += GLsENCbRSmheSxUi;
            dZMRgrP += GLsENCbRSmheSxUi;
            dZMRgrP = dZMRgrP;
            GLsENCbRSmheSxUi += dZMRgrP;
            GLsENCbRSmheSxUi = GLsENCbRSmheSxUi;
            dZMRgrP = GLsENCbRSmheSxUi;
        }
    }
}

bool exYfnNqy::zSTWfpDWzZMj(bool KXTshFVpVhOpGPS, string YnOAxWUWujG, bool NRLQEkPTfBE)
{
    double hhSbRRAZplxUP = 779205.641238228;
    double xBUOgborzA = -586879.0617097416;
    bool AwgcLh = true;
    bool ChmKz = false;

    if (NRLQEkPTfBE != false) {
        for (int xFzuxUhEAjrHrwVd = 396750460; xFzuxUhEAjrHrwVd > 0; xFzuxUhEAjrHrwVd--) {
            hhSbRRAZplxUP /= hhSbRRAZplxUP;
            ChmKz = NRLQEkPTfBE;
            KXTshFVpVhOpGPS = ! NRLQEkPTfBE;
            KXTshFVpVhOpGPS = ! AwgcLh;
            NRLQEkPTfBE = ! NRLQEkPTfBE;
            ChmKz = AwgcLh;
            ChmKz = ChmKz;
        }
    }

    if (AwgcLh != true) {
        for (int gYhVtdmbzHpKf = 1902400867; gYhVtdmbzHpKf > 0; gYhVtdmbzHpKf--) {
            KXTshFVpVhOpGPS = ! AwgcLh;
            NRLQEkPTfBE = ! ChmKz;
            AwgcLh = ! KXTshFVpVhOpGPS;
            AwgcLh = ! NRLQEkPTfBE;
        }
    }

    return ChmKz;
}

bool exYfnNqy::lKPraM(double oaOPGX, double EJJMjpqLrThvW, double NqhFjaPcBdiRUfh)
{
    bool VaZIBcRlYstVlq = false;
    int TKTGKy = -259284690;
    bool cjiep = false;
    double quzyBGQChgP = -492605.11662653956;

    if (quzyBGQChgP > -445761.9718706949) {
        for (int rmXTS = 715843095; rmXTS > 0; rmXTS--) {
            quzyBGQChgP = EJJMjpqLrThvW;
            oaOPGX -= EJJMjpqLrThvW;
            NqhFjaPcBdiRUfh /= EJJMjpqLrThvW;
        }
    }

    return cjiep;
}

bool exYfnNqy::ThMpYJw()
{
    int GPwZjhrKeOujK = -749134441;
    string HxvsfxumwJy = string("GTAjYoPMpWmGQXDcMYXdMSVJdNTDlIeEziWkHmnWoTJjaXcvgBgpZLKLPGoojtQVaKdvGLdXlIlwRgyAOCAHgwLSFKRSRJjHHIeStRmPVEnLShdIYtgfClfVGEvFHDaypTXnodkFvRRwDyjdHarGYzIQgemRWGvGBPCAZXSZktsuKZJEErDkkKfvbCrfhRGpoyKOwpIItefZLKOpQOizqVYZDHCtIWqlAqrSRNBSQmDRtWwkAlOuNYoHVBVLhyg");
    int WLrHiMVIbp = 2065163008;
    bool saTzSfRW = true;
    bool SyRQUGHPOtmw = true;

    for (int xUSrzOs = 2057079141; xUSrzOs > 0; xUSrzOs--) {
        GPwZjhrKeOujK = GPwZjhrKeOujK;
    }

    if (GPwZjhrKeOujK >= 2065163008) {
        for (int GHEUocukDPMqsEuH = 719387492; GHEUocukDPMqsEuH > 0; GHEUocukDPMqsEuH--) {
            continue;
        }
    }

    if (WLrHiMVIbp < -749134441) {
        for (int UIdLjWWcB = 925865139; UIdLjWWcB > 0; UIdLjWWcB--) {
            WLrHiMVIbp += WLrHiMVIbp;
            HxvsfxumwJy += HxvsfxumwJy;
            HxvsfxumwJy = HxvsfxumwJy;
            saTzSfRW = saTzSfRW;
            SyRQUGHPOtmw = ! saTzSfRW;
            SyRQUGHPOtmw = ! saTzSfRW;
        }
    }

    for (int oVAWLfj = 634525635; oVAWLfj > 0; oVAWLfj--) {
        HxvsfxumwJy += HxvsfxumwJy;
        GPwZjhrKeOujK *= GPwZjhrKeOujK;
    }

    return SyRQUGHPOtmw;
}

int exYfnNqy::DnNZOd(double yfgtatrJ, int FvHeSFD)
{
    bool fjNTWLHqZx = true;
    string IKnLvFcTu = string("iKcJFqdKiaWLtWwKmAVMyPLiVgzfqQuRUXkhONlgUeJyTzHnArvODFJiFBJWNpBKqLWiPOThQMBKMPVgyhrIGlVhZvQAoxcxCHCUpgcPyqbnwQl");

    for (int xrEflo = 1175296228; xrEflo > 0; xrEflo--) {
        IKnLvFcTu += IKnLvFcTu;
    }

    for (int JPGgxYV = 448435885; JPGgxYV > 0; JPGgxYV--) {
        fjNTWLHqZx = ! fjNTWLHqZx;
    }

    for (int TEKzfmjrs = 371042007; TEKzfmjrs > 0; TEKzfmjrs--) {
        continue;
    }

    return FvHeSFD;
}

int exYfnNqy::ZyhOf(int wVxlsjMh)
{
    double JXhRLfGdPh = -62743.35381109634;
    string CePnSGqGW = string("DymzFAgxvyFrnjFhAexIKtLLowYvgARkRAxQpuqUcrLmyJznegkiJIrNWrKPDrlbcUFxnKOHWeQdvKXzJgBZcUjBMkvKyo");
    double nLsyuyIe = 23718.40812648663;
    double yiOBySOwzNTI = -430376.62998797;
    double pEgyjiDOISjKBZ = 469918.8053953486;

    if (nLsyuyIe >= -62743.35381109634) {
        for (int byhLjhztpmeN = 1783626338; byhLjhztpmeN > 0; byhLjhztpmeN--) {
            pEgyjiDOISjKBZ *= pEgyjiDOISjKBZ;
            CePnSGqGW += CePnSGqGW;
            JXhRLfGdPh /= JXhRLfGdPh;
            JXhRLfGdPh = nLsyuyIe;
            nLsyuyIe *= nLsyuyIe;
            yiOBySOwzNTI -= JXhRLfGdPh;
        }
    }

    return wVxlsjMh;
}

int exYfnNqy::grfdIFpLKfiSVMT(int RDwPDcgInV)
{
    bool sBpqepiIPJ = true;
    double QZMKrBNQdCJsLZ = 368829.90169468534;
    string vdqqxayyP = string("QpqIOVTCblRznBninIqtAfhAwCTsUfbnOaknzvVvZlUkuxhgyAIerDsZuwDCZPbnTNGUjtAaoZJFecHlZcSuoKyyKIQBP");
    string fREBFMqgJbv = string("KJFTuCmvvTmbVIoGKpEmJhfNgaYdfTHAHsNOoxhugTlgXZNwlHbRaASJVYbVRQptLXpAnwNUIXnPtveQkvzFXODmBGdKvHNSKihAqBYhrIrzhpgLbRoPvilaZUTdzyrxEvKFqyIcwmgAgWnWpjEbsmDxUXagivjVJOJZoycCcLFNYVgaDkdpUZEnWHiSztVJXwtpYxAMBgxJhhF");
    double BAmwBDQcF = 78111.858838851;
    bool MeUdgWqqaSl = false;
    double UjfQjkVARFJN = 865406.0669810052;

    for (int DXhrJKKwGcw = 603674969; DXhrJKKwGcw > 0; DXhrJKKwGcw--) {
        BAmwBDQcF /= UjfQjkVARFJN;
        sBpqepiIPJ = ! MeUdgWqqaSl;
        UjfQjkVARFJN /= BAmwBDQcF;
    }

    if (fREBFMqgJbv >= string("KJFTuCmvvTmbVIoGKpEmJhfNgaYdfTHAHsNOoxhugTlgXZNwlHbRaASJVYbVRQptLXpAnwNUIXnPtveQkvzFXODmBGdKvHNSKihAqBYhrIrzhpgLbRoPvilaZUTdzyrxEvKFqyIcwmgAgWnWpjEbsmDxUXagivjVJOJZoycCcLFNYVgaDkdpUZEnWHiSztVJXwtpYxAMBgxJhhF")) {
        for (int ffGAVauULzNgFpP = 1338445438; ffGAVauULzNgFpP > 0; ffGAVauULzNgFpP--) {
            fREBFMqgJbv += fREBFMqgJbv;
            QZMKrBNQdCJsLZ += QZMKrBNQdCJsLZ;
        }
    }

    return RDwPDcgInV;
}

bool exYfnNqy::lSXXhYXyYkSwo(int jqcmpb, int VgNlMRZeSS, int dVzPtqMZGizL)
{
    string LAwHbvIZLbOYh = string("hSruUUPGUstnbOboQiecCejvMaIeTOOvzePJxjjedLgeQnWzldvKhRduLMIZmgalRsFKfcfYNajhJArwsWqbJkrOYylUnbugdHouHEeiSjuvCOrMzuAsyvVLyYjYnhOxkGzsrV");
    int fIXmgZiAoCJOSxW = 1643972297;
    bool rPwvHjFwSeFXLahG = true;

    if (VgNlMRZeSS == -170320145) {
        for (int ACJyKuq = 1220203654; ACJyKuq > 0; ACJyKuq--) {
            fIXmgZiAoCJOSxW += jqcmpb;
            dVzPtqMZGizL *= jqcmpb;
        }
    }

    if (fIXmgZiAoCJOSxW > 1643972297) {
        for (int zdzcGPEMHBsUqN = 1492622256; zdzcGPEMHBsUqN > 0; zdzcGPEMHBsUqN--) {
            fIXmgZiAoCJOSxW = dVzPtqMZGizL;
        }
    }

    if (VgNlMRZeSS > 2092175470) {
        for (int MJDdzQh = 377443414; MJDdzQh > 0; MJDdzQh--) {
            dVzPtqMZGizL += fIXmgZiAoCJOSxW;
            jqcmpb /= dVzPtqMZGizL;
        }
    }

    for (int axbmEvhqGleIqhHy = 291990854; axbmEvhqGleIqhHy > 0; axbmEvhqGleIqhHy--) {
        dVzPtqMZGizL += dVzPtqMZGizL;
        VgNlMRZeSS = fIXmgZiAoCJOSxW;
        dVzPtqMZGizL += dVzPtqMZGizL;
        VgNlMRZeSS += jqcmpb;
        jqcmpb -= VgNlMRZeSS;
        VgNlMRZeSS *= jqcmpb;
    }

    if (jqcmpb > -1404187587) {
        for (int TRMkcxbFa = 2038523258; TRMkcxbFa > 0; TRMkcxbFa--) {
            jqcmpb += dVzPtqMZGizL;
            dVzPtqMZGizL += jqcmpb;
            jqcmpb *= dVzPtqMZGizL;
            dVzPtqMZGizL += fIXmgZiAoCJOSxW;
            VgNlMRZeSS -= jqcmpb;
        }
    }

    return rPwvHjFwSeFXLahG;
}

exYfnNqy::exYfnNqy()
{
    this->nvPtuaBpZtCM(515471896, true, 104260896, string("aCoMeamBWgslfCQ"), string("MigjgwoSMgYPMqxdnCrQYFZdOvekmafyFd"));
    this->mtLZJhMK();
    this->mlNOiuPEvHTvVo();
    this->mqbCbPwMOjnuUTi(-40187348, string("oKVkNSykfukxJwyqfuFZiaugPqJcSVPqKJkgVlJRATzHljUwSnuKyOIHQQnigTFtZGDrafGiLTJXwuXnmWMgBwzhFIyDttADlMNvxDOkIEDOhhbggOIBvGiIlZZvgyKQXHMNHxbbUNBlXzwxyNgDhrjrAfzATtgturdzsfsjYlvdqmjtHnNKtqcuKEXsEdB"));
    this->kEoRaRxztAO(false);
    this->FeJYb(false, -352088.27607921226, string("awOYqgaHNznhYBgDhFZgIJwLkamsXd"), string("NptuRwoaAOfNjCzvFAEcoDDzKUNcicjXpwkuClmnPjtcClOdjQvNFWnCggpiY"));
    this->xuvBGTcHZ(373506963, 469769751, false, string("PfIjGUBoznXnUIHDMJYKVnqasLDAOiJmxTlQizNAxVwombKJUaMOMjsuKOECMtgTMUWIMFGLADKRHUyTnwyqQKOPibdrgpfoTIpRWvTSBSvCfyMUVzyDmTnVqDyOYqMIFvmqAYOhpXcgoIdhkNmcHPsnpexdIFDHTxKMylBCMzVJURUiHQByHMzvjnoZHhsJftkWmWcjGNbimuVqPvKzpJMvqswfVCBLT"), -637784.2209451295);
    this->SVgDEjuwbUIKkQ();
    this->sarkrwiqg(false, string("ycrDNmXezSfOVKFtntLPArptfNDmVInHvRfiqNuFgPPCLvjowJwZzubxkxEMQFzBLVPUg"), 240328.76828909392, string("TjUNOgAYYlYdcyYTDXMDIyfFIAjedLuguwNSSdhZtcyiojAbgELwtKeYzswfZrDOLkCMKGThNkZCtxWGWagguWURVUUjukDPdNzORpTNHIVAVLggaaSvYhknLzYhjrolItNdGscSHGmfwGhAmEOFRBFAfxtlujRFffyEnblxsZjcDiDSsBRDuCVvYblRxcVqoGkyQyMgrOJkExOHLfixOIURoWMpVsdMMtEBhPDVIDqYAJhOJFDBx"));
    this->TWwHddYU(-877418799, 143646.9714536741);
    this->jIZglmtfvjh(617400.8587802148, string("xjSiylAnTVhBOxjGOvHhXrDkYGckqzPcmGNuGrkSxnRdSVfXUcrWjKZeWpfBXECbCWIb"));
    this->gVQKateF(string("krOnUNtNxQjFRneniaeqplUjufqPEErpAIFRedtsOxAcnYHlLbzUIMeJWHWzOFuldrSRWrrAJORYAEZYABmqxjByvFBdYjhexYTKaNvswjDPaLXahjdmkHkaCmHjLEANrTZKMjoZpisMsxXPKWakgodKeJeZMedPCwklgKaAjcYExJdLihOHjAFMiiptogOTkXJdgSIILHQXXcUOFmoktUvjjMAtQlhRXV"), 745810.963182943);
    this->toeQdpVISBWLfd();
    this->zSTWfpDWzZMj(false, string("VSRRoHAEEVCsvRtIxpzoqsACvJFvplongRIOsPVhhqgZHwp"), true);
    this->lKPraM(-445761.9718706949, -303240.7474911023, 1001998.9721364805);
    this->ThMpYJw();
    this->DnNZOd(-128135.89531281966, 1109990387);
    this->ZyhOf(-154039151);
    this->grfdIFpLKfiSVMT(464051988);
    this->lSXXhYXyYkSwo(-170320145, 2092175470, -1404187587);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jfkcSR
{
public:
    bool iBFDCLdZMgc;

    jfkcSR();
    string IQPPfBMTPSBTk(int VbKxLgHFLurCRy);
    string FGkrNxtGoOU(string DjLFrDxaBj, string gPCNsrRQZlWUdaK);
    int yXKVadYVQiwUKQj(int iAzhHzxntlHX);
    double VukjzwkhdPufNY(bool IJeLnMGJo, string ctoksiJTLO, string tcskB, int stWlqXXEwImAhHns);
    int aMUjNe(bool pVqSbdMrpQtG, int RFktViG, bool AKLYgF, double MzKDXH, string wzZfca);
    void ifNHIjJLzWv();
protected:
    int waLjMMYKLAWmV;
    int aFripEqSKFHwwz;
    bool BOoCQH;
    string LrSrFsK;
    string PtNcNNUCHnMxq;

    int tviBHLT(int inOfHCMxDeeuacia, bool xDNqtK, string UYksQ);
    bool gdRuw(int UvosRhx);
    int KdxAYdChEvP(int YXRmvc, string UmPeVyCHCjFI, bool fkOgTBlVExjVOmJm, double AsbceTMtFJPOxKO);
    double thAmYX(int igXzNFKMKbPsfBxC, double NocwahKdU, string iqyRFYn, double PttKYdzGL);
    int kcAaVfKYfG(int AYyUwWUg);
    double WXQQUcoNWi(bool Ymelc, bool RTNoVSZIElRVy);
private:
    int sYIICdCZS;
    bool ZtgNgjaPMnM;

    bool dIqwQApUINeLGXL(double OotZwYkQTLFMVZsY, double TKdRLhZnujYAQ, string IRfYAWMFMv, string TCgyY);
    int YAFSBwZkSyai(int exxUQAUtqRbG, string fOkBgtnApCs, bool oigWeiwD, double uDLGRwbLBKxmdh, string kpDdFWIzxsgSyt);
    string KCvjlmOZJai(bool frTpQSoJExX, int GBVRfdrYV, bool BUjtd);
    int pLblneVqyBYAq(string IZnaVHALLGd);
    double DIXaq(string XHHVpVv, string wtBLwJIsNGzq);
    double mlOdsCvHSuzX(int pDQdExk, int ujpSnVR, string shYVUqYEmk, bool rxxmR);
};

string jfkcSR::IQPPfBMTPSBTk(int VbKxLgHFLurCRy)
{
    bool xaHbuPsLVBvk = false;
    int grqKiphHghuHoSC = 174556554;
    string jzecFNZGh = string("nJbMQyDHRfwLskrhXZWuEB");
    int KQccbdUEzoMuNh = -1825625093;
    double jxpKlimBX = 558414.9239316602;
    double IgfRlpQ = 372274.19772220385;
    string sBTOMPBITDdy = string("QNGGsHnQHIGpqKxXcZilWHaqCGGtmsCzJyBlZXCHkVNlVAqzJQlQENXEXshQlDNvGsOJAnPVBbdzDVMceMjZHLyRmnJUtZVpnIKcNvFdrhHLnxxKmpaoulWwbFBRZxGgHlRkLMECpBwGqjAeIklNuTnWwvZvWNoInkftVSaCLrpgkxBjaUUXBuOwyzifBTigfrSsWocYJuBhxJooOAfNL");
    string OUJOtsbwc = string("ZDfJYWSph");
    bool CRBZiveMB = true;

    if (sBTOMPBITDdy < string("nJbMQyDHRfwLskrhXZWuEB")) {
        for (int RqAwaO = 1703122415; RqAwaO > 0; RqAwaO--) {
            xaHbuPsLVBvk = ! CRBZiveMB;
            OUJOtsbwc += jzecFNZGh;
        }
    }

    for (int xoatXHjZOVnZdQdT = 305350628; xoatXHjZOVnZdQdT > 0; xoatXHjZOVnZdQdT--) {
        IgfRlpQ = jxpKlimBX;
        OUJOtsbwc += OUJOtsbwc;
    }

    for (int JXIZwpeyMUnub = 1659534718; JXIZwpeyMUnub > 0; JXIZwpeyMUnub--) {
        sBTOMPBITDdy += jzecFNZGh;
    }

    if (VbKxLgHFLurCRy >= 174556554) {
        for (int qqtoNLNUcHUy = 697579884; qqtoNLNUcHUy > 0; qqtoNLNUcHUy--) {
            VbKxLgHFLurCRy += VbKxLgHFLurCRy;
            xaHbuPsLVBvk = xaHbuPsLVBvk;
            KQccbdUEzoMuNh -= KQccbdUEzoMuNh;
            VbKxLgHFLurCRy /= KQccbdUEzoMuNh;
        }
    }

    for (int muQngIB = 2121131349; muQngIB > 0; muQngIB--) {
        VbKxLgHFLurCRy /= VbKxLgHFLurCRy;
        OUJOtsbwc = sBTOMPBITDdy;
    }

    return OUJOtsbwc;
}

string jfkcSR::FGkrNxtGoOU(string DjLFrDxaBj, string gPCNsrRQZlWUdaK)
{
    double uUmsW = -420275.565501601;
    int wcKAzrpFCAdPWCn = 2084941424;
    bool hDYHxRDCtbfTapX = false;
    string cqyxaY = string("zgUGKsXwVCesLtlILzAhkzMtUzRYR");

    for (int HgrNTfDFipYu = 1016769115; HgrNTfDFipYu > 0; HgrNTfDFipYu--) {
        uUmsW += uUmsW;
        gPCNsrRQZlWUdaK += gPCNsrRQZlWUdaK;
    }

    for (int aJgRPuzJSnHOmH = 542157472; aJgRPuzJSnHOmH > 0; aJgRPuzJSnHOmH--) {
        continue;
    }

    for (int fxEKLjFAXSQYwdvm = 548843610; fxEKLjFAXSQYwdvm > 0; fxEKLjFAXSQYwdvm--) {
        uUmsW -= uUmsW;
    }

    for (int FfocZnPDR = 991997692; FfocZnPDR > 0; FfocZnPDR--) {
        cqyxaY = DjLFrDxaBj;
    }

    for (int ZbLCC = 917410281; ZbLCC > 0; ZbLCC--) {
        cqyxaY += gPCNsrRQZlWUdaK;
        gPCNsrRQZlWUdaK = DjLFrDxaBj;
        cqyxaY += DjLFrDxaBj;
    }

    return cqyxaY;
}

int jfkcSR::yXKVadYVQiwUKQj(int iAzhHzxntlHX)
{
    double gyblCPgKHIGCTNj = 547389.6924214431;
    bool YGzQZfoFGgnnHozJ = false;
    bool vSyLLEYUaTeCxuE = true;

    if (iAzhHzxntlHX == -1270691474) {
        for (int gJLTEH = 91932482; gJLTEH > 0; gJLTEH--) {
            vSyLLEYUaTeCxuE = ! vSyLLEYUaTeCxuE;
        }
    }

    if (YGzQZfoFGgnnHozJ != false) {
        for (int qoAzyIAPf = 649643454; qoAzyIAPf > 0; qoAzyIAPf--) {
            gyblCPgKHIGCTNj -= gyblCPgKHIGCTNj;
        }
    }

    for (int krPyF = 1412879752; krPyF > 0; krPyF--) {
        continue;
    }

    if (YGzQZfoFGgnnHozJ != false) {
        for (int FbCsw = 2104214652; FbCsw > 0; FbCsw--) {
            YGzQZfoFGgnnHozJ = vSyLLEYUaTeCxuE;
            YGzQZfoFGgnnHozJ = ! YGzQZfoFGgnnHozJ;
            vSyLLEYUaTeCxuE = ! YGzQZfoFGgnnHozJ;
            iAzhHzxntlHX += iAzhHzxntlHX;
        }
    }

    return iAzhHzxntlHX;
}

double jfkcSR::VukjzwkhdPufNY(bool IJeLnMGJo, string ctoksiJTLO, string tcskB, int stWlqXXEwImAhHns)
{
    bool cDWsbv = false;
    int GGahiViKxwevM = -1549365828;
    int jqmmpDEiy = 156283326;
    int NUKWZ = -740083025;
    int TcARiMsoj = -883431317;
    double KxqAzLppTKmI = 335949.16243345174;
    double gmpBsGRF = 380785.10803524446;
    int jvlyFBVtHvJiM = -601616339;

    if (stWlqXXEwImAhHns != -1549365828) {
        for (int kxKDtazp = 1839072045; kxKDtazp > 0; kxKDtazp--) {
            GGahiViKxwevM = stWlqXXEwImAhHns;
        }
    }

    if (NUKWZ < -601616339) {
        for (int gGcDomcEC = 156381417; gGcDomcEC > 0; gGcDomcEC--) {
            continue;
        }
    }

    if (stWlqXXEwImAhHns == -883431317) {
        for (int EHoMOJHn = 727201517; EHoMOJHn > 0; EHoMOJHn--) {
            TcARiMsoj *= NUKWZ;
        }
    }

    return gmpBsGRF;
}

int jfkcSR::aMUjNe(bool pVqSbdMrpQtG, int RFktViG, bool AKLYgF, double MzKDXH, string wzZfca)
{
    bool vTBdI = true;
    string jrhqGZ = string("XfhOjWuJeTsRlIPshtzzwZbUqAMVpCohWSuRsOQDraFVQfjzjIVEVUKdqrZDLBTuUEDeAlqxEzumRZjzwDxbKSSVIdFibmLOGYhZuWbWXpnUOECZnKmNMiIdJnxhroEgWYTlTwnDpKSTfnulGwpJTuZwhuqkHKtZqPZpoyvCSdptaszqGlTIlOHsdpyIqsJVJdAseRnXEEbcmSTMdexcaHgyQEscTqFPkYlMtC");
    double DDrUcgyH = -167162.06336248823;
    int EkEksvL = 1223909261;
    string JnvRauc = string("ynfeyFkKUUpBjyCEPbCNDOxyavefnUZudKNnpRxkAfmOnxbSaYVahjmCnspSouQghYJsqaHKneUdpAjqiRwLXkL");
    double XujovTOhD = -359788.5926842201;

    for (int EZwcUGkHHm = 1937901272; EZwcUGkHHm > 0; EZwcUGkHHm--) {
        pVqSbdMrpQtG = vTBdI;
        RFktViG *= RFktViG;
        DDrUcgyH -= XujovTOhD;
        XujovTOhD += DDrUcgyH;
    }

    for (int zXUVeoZS = 1344250006; zXUVeoZS > 0; zXUVeoZS--) {
        jrhqGZ += wzZfca;
    }

    return EkEksvL;
}

void jfkcSR::ifNHIjJLzWv()
{
    int NSZsnRduwSCIQyPm = 1673610940;
    int fuAdLnFPGtRw = 93285714;
    string CpBIfDS = string("xYMfbbcZpgStHeWEPtQHMMkZiBIlbKCQYlhRYdMFXUynHEeTcFTEzSOrwrabAjbkjGNNczQ");
    string lcFvzN = string("VflKgmryDVqseeqTVENmtTxgkUQDQXRHmOUkBaIXeToBjgeBdBoJHuyweYNypfcgPJtgCBnJoYnMaEVbGlfHWWhUoPzJidOTCNzSgmtkLDttvyXPWetuoUBxllheZtnNAjvWbUpgSw");
}

int jfkcSR::tviBHLT(int inOfHCMxDeeuacia, bool xDNqtK, string UYksQ)
{
    double bSsMuhchHWVLDtZj = 327351.823033047;

    if (xDNqtK == true) {
        for (int gyUsJPVrvatHovV = 217572520; gyUsJPVrvatHovV > 0; gyUsJPVrvatHovV--) {
            xDNqtK = ! xDNqtK;
            inOfHCMxDeeuacia += inOfHCMxDeeuacia;
        }
    }

    for (int cAIOLrDnuA = 8143380; cAIOLrDnuA > 0; cAIOLrDnuA--) {
        continue;
    }

    for (int AwCVITcuvc = 626304999; AwCVITcuvc > 0; AwCVITcuvc--) {
        UYksQ += UYksQ;
    }

    for (int ZwonIwWuLLKWjdkk = 1095822759; ZwonIwWuLLKWjdkk > 0; ZwonIwWuLLKWjdkk--) {
        bSsMuhchHWVLDtZj += bSsMuhchHWVLDtZj;
        inOfHCMxDeeuacia -= inOfHCMxDeeuacia;
        bSsMuhchHWVLDtZj /= bSsMuhchHWVLDtZj;
    }

    for (int JUgYpP = 1249087458; JUgYpP > 0; JUgYpP--) {
        bSsMuhchHWVLDtZj = bSsMuhchHWVLDtZj;
        xDNqtK = xDNqtK;
    }

    return inOfHCMxDeeuacia;
}

bool jfkcSR::gdRuw(int UvosRhx)
{
    string EWhNzX = string("tUjvSjVKUfLCGWMBacBOpTQJKUtqEMSshIuPitmGFaQvCfGplbbplLKLrJGlOwbwMSeLhIvGOQteQEmfeKlKOtAEUekZGMfbhVWGizdEZrzDKyoHQhTiQvdYhdexbDgZppBkgryGnyClnUNTkUtKTOVIKYeQImqpJIRzSZMjvnyThJlbymLHJDYuUdGCoQGIbhuifcIgJCfXlYIvcyTIdiaLihbSpdZRIdkuxhL");
    double VsSiXGvyMVcyrrD = -355179.5264909906;
    double jYyAetJhlayKkZk = -337280.5203968604;
    string EuMfkIw = string("BgTJlcpNvXosIFwlHPJSsYDQDBktGvrofNQvjuqIRUDRaosRMNRWVshqxTgssXZIzKEpPEbHRSWvSjyhTyxBbKiLBqAiVyPXgwzlamIEszzaFxznYwREyaRqKvgntKlwbqxzjHUdnlsVXEIYfxmpkBlZkUqGFZZpbdJAZBKnSLXuXYjBVSJfCOQKYWgkNKIomgrkvUPpYcgpAlXzoplWnjZHTkf");
    double vrTloJlHosInhmb = 793765.3820235165;

    if (VsSiXGvyMVcyrrD > 793765.3820235165) {
        for (int lEjAN = 746537363; lEjAN > 0; lEjAN--) {
            EuMfkIw = EWhNzX;
            VsSiXGvyMVcyrrD /= VsSiXGvyMVcyrrD;
        }
    }

    for (int sVAOQ = 313036917; sVAOQ > 0; sVAOQ--) {
        vrTloJlHosInhmb = jYyAetJhlayKkZk;
        VsSiXGvyMVcyrrD /= VsSiXGvyMVcyrrD;
        jYyAetJhlayKkZk = vrTloJlHosInhmb;
        jYyAetJhlayKkZk /= jYyAetJhlayKkZk;
        jYyAetJhlayKkZk += jYyAetJhlayKkZk;
        VsSiXGvyMVcyrrD = vrTloJlHosInhmb;
    }

    return false;
}

int jfkcSR::KdxAYdChEvP(int YXRmvc, string UmPeVyCHCjFI, bool fkOgTBlVExjVOmJm, double AsbceTMtFJPOxKO)
{
    int RloqggVF = 1968725099;

    for (int OUCZqPCuRbQIKY = 993772276; OUCZqPCuRbQIKY > 0; OUCZqPCuRbQIKY--) {
        RloqggVF -= YXRmvc;
        fkOgTBlVExjVOmJm = fkOgTBlVExjVOmJm;
        YXRmvc *= RloqggVF;
        RloqggVF /= YXRmvc;
    }

    if (YXRmvc < -1891938131) {
        for (int njsOuDF = 1716441455; njsOuDF > 0; njsOuDF--) {
            continue;
        }
    }

    return RloqggVF;
}

double jfkcSR::thAmYX(int igXzNFKMKbPsfBxC, double NocwahKdU, string iqyRFYn, double PttKYdzGL)
{
    string QCubLC = string("BQqxyGAHhyfxsIWgWXlNeaMkXQcPBnZVGRLPpUxsDHMhvcUrTKifHrgNLYTJvQAQtaOnHUOFWorGUYZpnXnglhOBSFbPCTNYGxpKMNoXkynHDRGkdYPAMUNHGNPGMBtTUEmasxYfoSMhypvkIpSQtOTzppZOpTvaiDaNvrp");
    string YGrvRBqvTIZAWM = string("GxuHwByoWIvILzNrbScxfEJfaJkSIeAwEsWTKTJDBdOtxQKdXXAvANSmMTOVWnRfdotQaOuusHBpBZXYNDfIhKquSUOoEnWzVQbusOphfLgmatBNYoTHIxMPYCoocdAGCiAlqQkQflGmqeXJwFfwykhjVnx");
    string HbNOjAqQfL = string("yKFeHgpGtySKjHMwpycbLFDyttcPrgNdpAxQAEMFrQyYXOmVnfBseSGiPQmyVtfSURXFbMqEZSYJnlbquLevBzdhCQxWhtTzoGYfqizGsgyPeQfhhnXUGamzAbQYOrhyZxRrmAAIzpmd");
    string fcmNEnNAUI = string("ljDfXDIfyXtqWcRGxOnCWaHrglztdQghIkHAaEybUhQbgNddZiywYqADDeeqpswolYRMwusNWtuykmSsnVDJETkNSYDkBLscwyjPCxzNXrMrqdavNGDVjSTtTKWKcCpYqmoSXCeQPcyxXcfJGrKbUQOCnUyLyEGaLkTaehgpTqgfPLJJpkyHK");
    double CmIfM = -286938.12625219073;
    string eoIhvwMNyeRV = string("CIxaHbvRrOkeUXhmTvQKHfRz");
    double CiEfd = 138406.56036108139;
    string CeIrvlfltzQakLG = string("QFjOqLEuXAaFwipeEAPdayKLIUSdxwQwlALtfazAqrEXvIjfCDtyFyQSG");
    int OFdEJuZknHr = 1024463118;

    if (QCubLC >= string("GxuHwByoWIvILzNrbScxfEJfaJkSIeAwEsWTKTJDBdOtxQKdXXAvANSmMTOVWnRfdotQaOuusHBpBZXYNDfIhKquSUOoEnWzVQbusOphfLgmatBNYoTHIxMPYCoocdAGCiAlqQkQflGmqeXJwFfwykhjVnx")) {
        for (int tfCRCbwaruY = 564646084; tfCRCbwaruY > 0; tfCRCbwaruY--) {
            QCubLC = YGrvRBqvTIZAWM;
        }
    }

    for (int GAoNRNeaHsOAQNxl = 1038074847; GAoNRNeaHsOAQNxl > 0; GAoNRNeaHsOAQNxl--) {
        CmIfM *= PttKYdzGL;
    }

    for (int hlLFOkEY = 1370949430; hlLFOkEY > 0; hlLFOkEY--) {
        YGrvRBqvTIZAWM = fcmNEnNAUI;
    }

    return CiEfd;
}

int jfkcSR::kcAaVfKYfG(int AYyUwWUg)
{
    string iIXsRX = string("ymAvKXyMpbLCuURSBkhPuCtWstqkEGYDeKYaqFRwOBXPTK");
    string ZMLWKNQCdrhNHfGu = string("lVdehicAVpilLmvzmithFfCutaDUeavvMOLxcfBuyfKYypxuNjXgmJDcYUzmGvvXLURxAodtJunBUGeniYQwMFfXuVUwZRDTqFCqpSbysKaTgWUlX");
    bool IxFpIE = false;
    bool NDOusHNWQrqXXv = false;
    bool TZmYgegrlRIbPN = false;

    for (int JiLFuDErnJNy = 1829280355; JiLFuDErnJNy > 0; JiLFuDErnJNy--) {
        ZMLWKNQCdrhNHfGu = ZMLWKNQCdrhNHfGu;
        ZMLWKNQCdrhNHfGu = iIXsRX;
        AYyUwWUg /= AYyUwWUg;
    }

    for (int dWGpQxyQBzGJWsYZ = 1703233797; dWGpQxyQBzGJWsYZ > 0; dWGpQxyQBzGJWsYZ--) {
        IxFpIE = NDOusHNWQrqXXv;
        IxFpIE = NDOusHNWQrqXXv;
        IxFpIE = ! IxFpIE;
    }

    for (int zajCEVIckDvQdv = 1184722318; zajCEVIckDvQdv > 0; zajCEVIckDvQdv--) {
        TZmYgegrlRIbPN = ! TZmYgegrlRIbPN;
        TZmYgegrlRIbPN = IxFpIE;
    }

    return AYyUwWUg;
}

double jfkcSR::WXQQUcoNWi(bool Ymelc, bool RTNoVSZIElRVy)
{
    string NKwwchEwtscUpzvv = string("kVGxcURSftWPKURqONcIZmwxFFsquZVZrezpVyXfnIPIFMLLs");
    double fTsBXe = 90758.74938002706;
    bool DVxVqUgFC = true;

    if (DVxVqUgFC == true) {
        for (int mwsXpYIG = 1308096155; mwsXpYIG > 0; mwsXpYIG--) {
            RTNoVSZIElRVy = RTNoVSZIElRVy;
            Ymelc = DVxVqUgFC;
            RTNoVSZIElRVy = RTNoVSZIElRVy;
            DVxVqUgFC = RTNoVSZIElRVy;
        }
    }

    for (int PPADBEvqUricgcc = 386092177; PPADBEvqUricgcc > 0; PPADBEvqUricgcc--) {
        fTsBXe = fTsBXe;
    }

    if (RTNoVSZIElRVy != true) {
        for (int cypPi = 187180761; cypPi > 0; cypPi--) {
            RTNoVSZIElRVy = Ymelc;
            RTNoVSZIElRVy = DVxVqUgFC;
        }
    }

    return fTsBXe;
}

bool jfkcSR::dIqwQApUINeLGXL(double OotZwYkQTLFMVZsY, double TKdRLhZnujYAQ, string IRfYAWMFMv, string TCgyY)
{
    bool HKHCJarEggtjgZK = false;
    string XcIwLa = string("NvNRCpfjgCwgxihcfHpjpKDsSYTJiUdReZrpThBkimyFMNTJSjLLxFoGqDWZZYZTpKUjUcEzhjpthMqyYNTQjyxHylUINpX");
    int sJAxEiL = 130826708;
    bool ZubHMKkvYMulhQMK = true;

    for (int QBMda = 1278200189; QBMda > 0; QBMda--) {
        IRfYAWMFMv += IRfYAWMFMv;
    }

    for (int aHfhEcHsajpCUj = 471946308; aHfhEcHsajpCUj > 0; aHfhEcHsajpCUj--) {
        OotZwYkQTLFMVZsY = TKdRLhZnujYAQ;
        ZubHMKkvYMulhQMK = HKHCJarEggtjgZK;
        sJAxEiL /= sJAxEiL;
    }

    if (XcIwLa != string("NvNRCpfjgCwgxihcfHpjpKDsSYTJiUdReZrpThBkimyFMNTJSjLLxFoGqDWZZYZTpKUjUcEzhjpthMqyYNTQjyxHylUINpX")) {
        for (int AhFOCRiwNUdArMG = 313551606; AhFOCRiwNUdArMG > 0; AhFOCRiwNUdArMG--) {
            TKdRLhZnujYAQ /= TKdRLhZnujYAQ;
            TCgyY += IRfYAWMFMv;
        }
    }

    for (int usFVPzlr = 1625483032; usFVPzlr > 0; usFVPzlr--) {
        continue;
    }

    return ZubHMKkvYMulhQMK;
}

int jfkcSR::YAFSBwZkSyai(int exxUQAUtqRbG, string fOkBgtnApCs, bool oigWeiwD, double uDLGRwbLBKxmdh, string kpDdFWIzxsgSyt)
{
    bool VoBRaWccoSJ = true;
    double NbMkcZGKtVvU = 851308.2918794143;
    string SKuZpIe = string("cnViZGDgnkJOaNlRhgnGjRbYoRASDsvGioyZcRXucfOCALuGyKffybnhYMFGYqiTDXuxkzEoymOHTvKSKGTCo");
    double DNojbgcfZJUK = 278943.4779744252;
    double dVkHra = -378782.1274788352;
    int OgcFoHg = 423292904;
    string YeTRkllHwCqUZ = string("oIaUlyvsftBVhfzJmsX");
    bool nYEJUxsJa = true;
    int lCckAG = -136169495;
    string tPbbNIiEgz = string("johyVeWJpCTLONNwcngeXoFtkDJgJWqEF");

    return lCckAG;
}

string jfkcSR::KCvjlmOZJai(bool frTpQSoJExX, int GBVRfdrYV, bool BUjtd)
{
    int bIzBqCpZms = 1882764215;
    int pKvCPjuApUvv = -1743505794;
    double LZXuPYettzoygNf = 163219.4438873978;
    bool CZxImgRhSEbJ = false;
    double MSVhRyASDC = 1046035.7051513827;
    double lhUdQHbuze = -847230.2894967588;
    bool monLkDO = true;
    bool DYBVurkP = true;
    double HqJOOBohkviHpPqw = 98180.87563998945;

    for (int rbTAQqlSwHdOVqL = 202908745; rbTAQqlSwHdOVqL > 0; rbTAQqlSwHdOVqL--) {
        bIzBqCpZms *= GBVRfdrYV;
        LZXuPYettzoygNf = LZXuPYettzoygNf;
        LZXuPYettzoygNf = MSVhRyASDC;
    }

    for (int ptVjFTsQvEFriC = 865188294; ptVjFTsQvEFriC > 0; ptVjFTsQvEFriC--) {
        CZxImgRhSEbJ = frTpQSoJExX;
    }

    return string("HbtErFKZWjNeKjQsWYcDrwSteEunNSWjflNmZtATjOIVNtvkyFRwNmCeJoxWTXxgYbhfCYewSBSWtvqJmahwyDtiKVIhXUHDBekNzVhbLuOxousyfSykoHmshUVIXTcmFVaxNqXWheCDDtScfUhbdhOxAhZrmLFUPkWGiduAGAMXAbOGVYYiHLpYQKQcZJMUjqCCfYIRiZOnExOoimZmYzs");
}

int jfkcSR::pLblneVqyBYAq(string IZnaVHALLGd)
{
    string KJUIUbItnzLiyla = string("oDJzSShFShZYQYGUdwaddCRUeAYndQQjsuWZ");
    bool KLfoCiXz = false;
    bool FqspxSDEy = false;
    double rYrbThKxRqVMXW = 653990.9459827013;
    int pateZaQjTzqSmL = 1562852781;
    string tNXmY = string("drdoTEgmCwruAIYIwwQRpHVAOUmJHsixxSpbsgxbXGsZWfwbYhlensRjefxsTdyDecaYPsWzxSBfkGgjlTFLUixwFjHKTIFfEfmoibXDNEbWfEOxgTrUxlsJpFsMmNZBeHNIYTlIYMynLasvqhTVMUHBdSAoRwBzcrqdwbzWUorqmBqStzDopx");
    double oloAR = -761210.7247495783;
    double jNGQogwjHoviX = 302281.14954029705;

    for (int oQfagWZxzTZXhbMa = 505471198; oQfagWZxzTZXhbMa > 0; oQfagWZxzTZXhbMa--) {
        KLfoCiXz = ! KLfoCiXz;
        IZnaVHALLGd = KJUIUbItnzLiyla;
        IZnaVHALLGd += IZnaVHALLGd;
    }

    for (int RoWdWEHMcp = 372607431; RoWdWEHMcp > 0; RoWdWEHMcp--) {
        oloAR = rYrbThKxRqVMXW;
        jNGQogwjHoviX /= jNGQogwjHoviX;
    }

    if (rYrbThKxRqVMXW != 302281.14954029705) {
        for (int qHyBXIMCYUgKmFWX = 1670446130; qHyBXIMCYUgKmFWX > 0; qHyBXIMCYUgKmFWX--) {
            KJUIUbItnzLiyla += tNXmY;
            oloAR = jNGQogwjHoviX;
        }
    }

    return pateZaQjTzqSmL;
}

double jfkcSR::DIXaq(string XHHVpVv, string wtBLwJIsNGzq)
{
    double MvNAXdQPiDCMIK = 392964.86782021355;

    if (XHHVpVv != string("hyoSvEICvNcWQMlueAIJTgvYNPUOgZIImcfPllMxrjQKWnGIRWPFZPNihMZrrmpcUQYTDdRmUlBOXJpHyHByuvCiTTMYD")) {
        for (int PfuFIebMoFJeJae = 1792690291; PfuFIebMoFJeJae > 0; PfuFIebMoFJeJae--) {
            wtBLwJIsNGzq += wtBLwJIsNGzq;
        }
    }

    return MvNAXdQPiDCMIK;
}

double jfkcSR::mlOdsCvHSuzX(int pDQdExk, int ujpSnVR, string shYVUqYEmk, bool rxxmR)
{
    double naBgZk = 634711.8593303673;
    string OPuak = string("sDNsvwrDPqKUwwORVvtmKLPMQePlSxxrliAFGwzfdAbPwTxQpTalyiokhxvLogjgEIxsiCNNghsAvQPuQOOyZhALOOBmKHmpUrHPsPUXOLnoWDomshWmo");
    double ycRXzuTU = -64408.40388863086;
    double soUhCFmf = 984064.3892174264;
    string vnLLFV = string("SeEpITecgKJQhgYtdCSSJmWoRnZpAqCGKUHJmPzGSSrAAKOCnOkoEKaNTvbSwJZlSEwYoyLljKsTAajgtcoBDYvTUjSPGnyiaHJtjR");
    int okyEcLhKmqnGZH = -154459534;
    int vPwfvkbNFzc = -1872020325;
    double VtCzjgxhTLOuMPx = -936629.0254830569;
    string BAaOdSmnwjmdR = string("NELCWCBFlJmPfdXtaSoXpbfAopQGzDxfMcPtoNltIJkOPRwCeFdWmFQlzybovDhVCawMLJXhEYhxnMSmTjvyXZv");

    if (vPwfvkbNFzc == -1872020325) {
        for (int AfZmRggzm = 1931433489; AfZmRggzm > 0; AfZmRggzm--) {
            continue;
        }
    }

    return VtCzjgxhTLOuMPx;
}

jfkcSR::jfkcSR()
{
    this->IQPPfBMTPSBTk(-1999457776);
    this->FGkrNxtGoOU(string("bRQLhoCwZGZvyoIhGdRMsEIWcjloZsNYsjeJRLoPwyEzdaoKrPLxAkXWpQjvWtZJuWGbiiyjxOEavBuvM"), string("ZZyIjvPhjYlSEPBENfxsBmLbBtjsoWepYmdpKcQNbNSQlUBqAzlLsFyDKOHiIOBfWMYMRKMplHbMYpsPKIbXEuCxaYILgaLHCvucRTvlJKSfLzfmTELlvYlqmOjyvNXKgFQBDTksFhqcGXggfhYpZFDJzoEhQOaHqzSflzSVvsTPwgXLCaZTxabgHDDCt"));
    this->yXKVadYVQiwUKQj(-1270691474);
    this->VukjzwkhdPufNY(false, string("IEUMeXVCmqbHvWtvAGjZNfxfyVNjFLDgcOauyRTXiQgePsvdVoZvBHuuelpXOILenRcLhYXaxrWLGnXmZVCXLHMXDmFMnVRCZTwMyTDKrVzxqcM"), string("RhOwGWMlrZFrviBkHQKkXykUTEfABFpGdFREQnvsDXcNKkvVlzUGUoEdHmKhVvZpOcaAvywAizRNNDQKnFvldgcdWckMIXhahMMhQbjAtuX"), -1458987327);
    this->aMUjNe(false, -517193852, false, -748449.1688885674, string("FyIwTTeLeWuUqhuEMoOuZtIwtOUUlwWPhdZIFagECJGjdqfkHHoZQd"));
    this->ifNHIjJLzWv();
    this->tviBHLT(-2120127972, true, string("QCYmDJWaxQokTjJYHTmRxjeAAuIkrrRhPIyiyDXVRWsngWcizGPRhzrsjeXSrnpUWRLvROLsCsanXYzlNVYnWoFFLQweeqjLJHoPdeMqPOFmbMgjJXAMwwQqsRoeRuozZLGHEzraApoJJiWZeVwPgTKItkifymKOiORtOeMvGYnOqupLuByilTfrMBqaKcWDkeLeXiglqkkUdefG"));
    this->gdRuw(-496652070);
    this->KdxAYdChEvP(-1891938131, string("LUCPrOMdpNeQOOFQrrgeyQhkDLeupKmSlKZNqlCamtqDtHAlcYGgOBazRVwwGhmManYsppalOoWdqMeqWzsXRn"), false, -823963.1681447842);
    this->thAmYX(522852447, -282008.5519278076, string("NwaEMJXcLvztDIfAAgDLVQoPckfPdWwwtrgfgketoHcUWxZJOicmpHHpnpLpnrYoFeFWbIxdURCfyfrBPzpGgBPNXUbVbcUhIlMJWwzOirkTXhHIKDQjsHcVPSMZHclZjQIKviaGsGBeuFooSCuwckDUzxCiAbBREKYVEHSoMrSmYYDTMCwqv"), 271714.12853543577);
    this->kcAaVfKYfG(-1185714595);
    this->WXQQUcoNWi(true, true);
    this->dIqwQApUINeLGXL(-400307.23890918517, 834013.9052355473, string("NbmSAdExDkFowXiUJLmuqXKPQMQiFfFWsCwzsMCwkbwHYgXGPdbsADljNxXqKAmjmUtVkcLIWsWWOyscImNtyyJnrCuEgFcvNttLcKSbOGtSNZzsajwCWxzqjXysDawazxydoDCzxunQJJOECKhIHMIPwEAGZSRygmUaZsGMjrcRsFmbI"), string("MsDecKVfbXUyVztsAhFGdJTeJQFvPtXPGWsXbtDZmsMJ"));
    this->YAFSBwZkSyai(1207886584, string("CiwDRbzktnEHzPNvlnUJKOFj"), true, -559806.8195298656, string("ScANPWLzPMTlCrfLWJUfRlkMIjHJYShpRHxCiTIisvhXTZDjJFgzpmEiUrKMaRLbMnMnNdLsDRYtesbRTMsHGkGdsEuGbkyciiyujpLirTvodmGfltLjeCXxMyVJphDPrRgzcgkiZUrKBQkXLoLZibPczaXnhDySUPkEPEhqtKucluTpLZcvPbXBxDGZwdYFvAGXDmN"));
    this->KCvjlmOZJai(true, 921049066, false);
    this->pLblneVqyBYAq(string("qFJgYFMrFDXAipjTudwPhJwKihjnsXQoYVMImdOxNLktgKRdAhfDddYAzhxuxqogHuFqtEKWLImaxSUDALJSUOzgyKZqmsxdEsYP"));
    this->DIXaq(string("hyoSvEICvNcWQMlueAIJTgvYNPUOgZIImcfPllMxrjQKWnGIRWPFZPNihMZrrmpcUQYTDdRmUlBOXJpHyHByuvCiTTMYD"), string("uDGByLPDzKHmAvRZeqBRIwvHRpPEPGLgkptYKWUodrbdZprCwxLGmRkfZKNUZGpYMPJHvKwpSNWdSSpFyaLpyZyrzEdJqvAwDBbWaSKMpjmtAiBjOtapFeuCOgOHaGetTmgmUwWvKUyyYHpPvFrFlLLYuMHqggjepU"));
    this->mlOdsCvHSuzX(302902514, 986646847, string("scKENTANjpYNUQlzToPQNTlbGITcWCwKNPaGBwcoOXkAOO"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GaDWAAojRFaqnBAh
{
public:
    int grHSVz;
    string iikNmeBcy;
    bool mDkaiNNb;
    bool UnaxAgDRn;

    GaDWAAojRFaqnBAh();
    string fgmUwHWMUkHLCuc(string chjNMfjpYLQ, double wmPBXfVhPbJA, string nttMkNlj, string uNGMeslsoqGDdV, string hzyYa);
    bool kutvnsFczYlMIdyX(double jmVFUESmOO, int NITPP, string ObdVXhDQRV, double FAHtn, double peuEAmXBIBHysE);
    double zyTwyQsYFHs(int MlCklAAmICVi, int NXtTFavx, bool kpMZmRgCRYaKmGU, double lUeUBCUjcyfCMTB, int vHmWOygc);
protected:
    double dCezRSL;
    int kpceYIBU;
    int mrUmRsDnWy;
    bool PjOgHQYbvSWbMF;
    bool pkssPeBj;
    double KNeGZziklW;

    int tNOPAByOO(int nzscdWI, double zAmmPev, double onzyPwIxcpIUXPW);
    void DCYVurFVBrM(bool CeVnycKWSSe, string NrGPWEIrAm);
    double CsefmipPwg(string oEqHGFNe, string EzKwMjJ, string HgAeqUxaGszv);
private:
    string cHMqKYV;
    double BNayEDCOKEi;
    bool EYzbSGScuMQUst;
    double VGfLcqqhgDRfZJkb;

    int BLdydfwn(double dvCiHdFq);
    string SyhYctFITcPuBO(int rdXCPCK, int vmErwsoDqgqFOHI);
    bool DXUxALJEXlUGvKkb(string HxQqMc, string UuzZowClckc, double QsViGBpnGBQMVmq, double xqbfxR, double yxBrqbMmzPuuY);
    void PAVbYwfiZcZZ(double QwwyB);
    void OLdgwGAQufsWRO();
    double gxLNZPm(bool RBrQxFY);
    void BrhairE();
    int XdpmuAnWtxc();
};

string GaDWAAojRFaqnBAh::fgmUwHWMUkHLCuc(string chjNMfjpYLQ, double wmPBXfVhPbJA, string nttMkNlj, string uNGMeslsoqGDdV, string hzyYa)
{
    bool BsOCD = false;
    bool WZMQtRxd = true;
    string gQowZpQOtO = string("XtzjyExlhl");
    bool kvFqi = false;
    int vDcqw = -1243313662;
    double bSFbZJ = 727511.4577049377;

    for (int wPdimxYakkpr = 289785855; wPdimxYakkpr > 0; wPdimxYakkpr--) {
        uNGMeslsoqGDdV += gQowZpQOtO;
        bSFbZJ += wmPBXfVhPbJA;
        gQowZpQOtO = uNGMeslsoqGDdV;
    }

    for (int tYKYZh = 621906964; tYKYZh > 0; tYKYZh--) {
        continue;
    }

    for (int PXUlFs = 93633022; PXUlFs > 0; PXUlFs--) {
        uNGMeslsoqGDdV = uNGMeslsoqGDdV;
        kvFqi = ! kvFqi;
        wmPBXfVhPbJA += bSFbZJ;
        hzyYa += uNGMeslsoqGDdV;
    }

    for (int jACyiDpKOSlKAKO = 635842346; jACyiDpKOSlKAKO > 0; jACyiDpKOSlKAKO--) {
        hzyYa += gQowZpQOtO;
        bSFbZJ /= bSFbZJ;
    }

    return gQowZpQOtO;
}

bool GaDWAAojRFaqnBAh::kutvnsFczYlMIdyX(double jmVFUESmOO, int NITPP, string ObdVXhDQRV, double FAHtn, double peuEAmXBIBHysE)
{
    bool lJsSWBDLEPG = true;
    bool xcrKHssxccDKZWPt = true;
    int djrAchkx = 414665344;
    bool IzzBpMTu = false;
    int riDmzDy = 1867320702;
    string acaxVCGo = string("XfTHIMqPZnHELZsgQhGtBpXhSnGyxJAgxONLPzpAJHWUkxgrZdIAxkhivBNRLUj");
    bool UdCLvTJobTKKGS = true;
    double YptHdhU = -346632.2031603289;
    bool NsYhsVV = false;
    bool vGJolmk = false;

    for (int semumB = 1037321003; semumB > 0; semumB--) {
        continue;
    }

    for (int RwvJzQauPpbZe = 1961686029; RwvJzQauPpbZe > 0; RwvJzQauPpbZe--) {
        continue;
    }

    if (NITPP <= 1867320702) {
        for (int ntIfmBTQWK = 2124880523; ntIfmBTQWK > 0; ntIfmBTQWK--) {
            continue;
        }
    }

    for (int GXiSXY = 211561333; GXiSXY > 0; GXiSXY--) {
        djrAchkx *= NITPP;
        NsYhsVV = IzzBpMTu;
        NITPP /= djrAchkx;
    }

    for (int mhYlnfRiYrdY = 877075370; mhYlnfRiYrdY > 0; mhYlnfRiYrdY--) {
        NsYhsVV = ! lJsSWBDLEPG;
        lJsSWBDLEPG = xcrKHssxccDKZWPt;
    }

    return vGJolmk;
}

double GaDWAAojRFaqnBAh::zyTwyQsYFHs(int MlCklAAmICVi, int NXtTFavx, bool kpMZmRgCRYaKmGU, double lUeUBCUjcyfCMTB, int vHmWOygc)
{
    double VlIlfoFuvApTP = -990221.7946654651;
    int cDViQEPlaSnn = -651066712;

    if (cDViQEPlaSnn > -1397200247) {
        for (int hNOOfALBqmYBLa = 1090363858; hNOOfALBqmYBLa > 0; hNOOfALBqmYBLa--) {
            NXtTFavx += cDViQEPlaSnn;
        }
    }

    if (vHmWOygc <= -651066712) {
        for (int YknWdemVDi = 227498442; YknWdemVDi > 0; YknWdemVDi--) {
            lUeUBCUjcyfCMTB -= VlIlfoFuvApTP;
            cDViQEPlaSnn -= cDViQEPlaSnn;
        }
    }

    for (int oKrdYihdCPqUB = 120865471; oKrdYihdCPqUB > 0; oKrdYihdCPqUB--) {
        vHmWOygc /= NXtTFavx;
        vHmWOygc /= MlCklAAmICVi;
    }

    if (vHmWOygc > -651066712) {
        for (int nQfPvsxONk = 1201744242; nQfPvsxONk > 0; nQfPvsxONk--) {
            cDViQEPlaSnn *= vHmWOygc;
            vHmWOygc += vHmWOygc;
            vHmWOygc = MlCklAAmICVi;
            vHmWOygc /= MlCklAAmICVi;
            NXtTFavx /= vHmWOygc;
        }
    }

    for (int mGpwwtTk = 1268404855; mGpwwtTk > 0; mGpwwtTk--) {
        VlIlfoFuvApTP = lUeUBCUjcyfCMTB;
        NXtTFavx -= MlCklAAmICVi;
        MlCklAAmICVi -= vHmWOygc;
    }

    return VlIlfoFuvApTP;
}

int GaDWAAojRFaqnBAh::tNOPAByOO(int nzscdWI, double zAmmPev, double onzyPwIxcpIUXPW)
{
    int ZrkresGwX = -1830427365;

    if (onzyPwIxcpIUXPW == -1013945.5860126542) {
        for (int SewjwD = 1551669243; SewjwD > 0; SewjwD--) {
            nzscdWI *= ZrkresGwX;
            onzyPwIxcpIUXPW *= onzyPwIxcpIUXPW;
        }
    }

    if (nzscdWI >= -1830427365) {
        for (int xZpwcpaGoJt = 190700666; xZpwcpaGoJt > 0; xZpwcpaGoJt--) {
            ZrkresGwX *= ZrkresGwX;
            ZrkresGwX *= ZrkresGwX;
            ZrkresGwX *= nzscdWI;
            ZrkresGwX *= ZrkresGwX;
        }
    }

    if (nzscdWI == -1821395228) {
        for (int mFwViLyo = 1504159388; mFwViLyo > 0; mFwViLyo--) {
            onzyPwIxcpIUXPW = zAmmPev;
            nzscdWI *= nzscdWI;
            zAmmPev -= onzyPwIxcpIUXPW;
            zAmmPev /= zAmmPev;
        }
    }

    for (int QEwqxPRqZNXppuS = 858097704; QEwqxPRqZNXppuS > 0; QEwqxPRqZNXppuS--) {
        nzscdWI /= nzscdWI;
    }

    for (int zxcTZuatDFfra = 845024831; zxcTZuatDFfra > 0; zxcTZuatDFfra--) {
        zAmmPev -= onzyPwIxcpIUXPW;
        onzyPwIxcpIUXPW += zAmmPev;
        onzyPwIxcpIUXPW = onzyPwIxcpIUXPW;
        zAmmPev = zAmmPev;
        nzscdWI /= ZrkresGwX;
    }

    if (zAmmPev > -1013945.5860126542) {
        for (int nRkQSFMmKYDGVWKo = 1492533001; nRkQSFMmKYDGVWKo > 0; nRkQSFMmKYDGVWKo--) {
            continue;
        }
    }

    return ZrkresGwX;
}

void GaDWAAojRFaqnBAh::DCYVurFVBrM(bool CeVnycKWSSe, string NrGPWEIrAm)
{
    double xrVFg = -8543.653219808806;
    int mJgSihmNiZexB = -958923736;
    string ameOV = string("qGyjmbYdZFSnLoLeXUpZjAaHcfvNWXrhCnaNseGpgwNzzpdsVQkxzkFJxCmQnfdXUwfWxzekwBZbehgFsEPbfC");
    double UbkOhHvuEWReT = 1041232.3777619204;
    string mScXL = string("AjFfnUxaNqndaHPnyNHtKSLSjgcXkUYtBQFixHNwPB");

    for (int whLQQoYFQoDMj = 1224569587; whLQQoYFQoDMj > 0; whLQQoYFQoDMj--) {
        CeVnycKWSSe = ! CeVnycKWSSe;
    }

    for (int rdEUmeilsmEFxV = 1857900132; rdEUmeilsmEFxV > 0; rdEUmeilsmEFxV--) {
        ameOV = mScXL;
        NrGPWEIrAm += NrGPWEIrAm;
        NrGPWEIrAm += ameOV;
        xrVFg += xrVFg;
    }

    for (int vLfhBiqT = 8203135; vLfhBiqT > 0; vLfhBiqT--) {
        continue;
    }

    for (int LmeYLFkKZKwC = 838122257; LmeYLFkKZKwC > 0; LmeYLFkKZKwC--) {
        xrVFg *= UbkOhHvuEWReT;
        mJgSihmNiZexB += mJgSihmNiZexB;
        ameOV += NrGPWEIrAm;
        UbkOhHvuEWReT *= xrVFg;
    }
}

double GaDWAAojRFaqnBAh::CsefmipPwg(string oEqHGFNe, string EzKwMjJ, string HgAeqUxaGszv)
{
    string maiAzL = string("koNOaxCjRQcduqAOPWrJadKOEEYaYSuibTUhRRQjMqhquRpgZrWaMyadAkZWTqPUDiwyPsVozggEhOhrhugumDaTpcUoKJbGuilJunCltBECqjGJPPsJsQxG");
    string bFSrwrMdh = string("RRMexrfUowQrFLBPLWfeVSTDdBAixaVGIJxpwBpxxnOkBYiIRlPchsqgKiqRkJYqumuYdCDiiTXhPXEoyrdOMPJCHviTnjhFdecHR");
    string dQlqSeKXsRAfRAp = string("GdChtVNEZknrrxLmyFHdYEniFKsobFgEoWGAZElBBMmvP");
    int gJosUCHWHPjkLDPS = 460289379;
    int GfIzNzBwgPPWfRES = -1520196544;
    bool HTeohS = true;

    if (oEqHGFNe > string("RRMexrfUowQrFLBPLWfeVSTDdBAixaVGIJxpwBpxxnOkBYiIRlPchsqgKiqRkJYqumuYdCDiiTXhPXEoyrdOMPJCHviTnjhFdecHR")) {
        for (int mhmRQVqcDJ = 554951640; mhmRQVqcDJ > 0; mhmRQVqcDJ--) {
            HgAeqUxaGszv = maiAzL;
            EzKwMjJ = HgAeqUxaGszv;
            HTeohS = ! HTeohS;
            dQlqSeKXsRAfRAp += oEqHGFNe;
        }
    }

    if (maiAzL == string("lmIBHiIXVuqPBLmGkJEgOUdhVSVOVsVtbsgsvFwpaMgkOkEfWhqxjQaUZWtPmWcLgzoqzLgf")) {
        for (int jUUHCMUsO = 97565828; jUUHCMUsO > 0; jUUHCMUsO--) {
            EzKwMjJ += maiAzL;
        }
    }

    return 1040070.5315778903;
}

int GaDWAAojRFaqnBAh::BLdydfwn(double dvCiHdFq)
{
    string OJsczGIRN = string("HpUUUJTmLwyYorhrYALIIYJwBCgvzqSFhLTBAAhHJjwMotxRpGsEbAEIltqdrnHezTUHwYYUgZbBAUTAbumtICojTnQgiVFKGQjlHLdLXZLVqbvbrcxRiTvhwABSEKAlpLrpGcaRzZvfvAxnYHFtAeTZOxgjUcrmRtUIHGqFcDkVnRcFGcmZtdpAbtJCbmhTr");
    int FbQwWw = 256103648;
    double bLGVvbvKUt = 55085.50372098643;
    int IcAOVQNg = -1997632653;
    int hPHeHLS = 1499054607;
    double yGvXoXFTQfu = -357398.0352900953;
    int ZzoMy = 1677442244;

    for (int BqXHPy = 16446825; BqXHPy > 0; BqXHPy--) {
        bLGVvbvKUt += yGvXoXFTQfu;
    }

    return ZzoMy;
}

string GaDWAAojRFaqnBAh::SyhYctFITcPuBO(int rdXCPCK, int vmErwsoDqgqFOHI)
{
    int uxXHxFoDMgYfeDJ = -855602168;
    string QZpYBL = string("CxdgF");
    string mRLsjbaJl = string("hJLSaRmXRGXPXETVBzPAqoscnXWvaQoDaHeZmLETvmtJrEEPQQXonXYmHUXjwRxOnUT");
    bool LBZhGX = false;
    int eOKFs = 910254852;
    bool vnlxdwGvh = false;
    double SaVvuhsyek = -136011.25554576315;
    bool PCCopzKTLWc = false;

    if (eOKFs == -855602168) {
        for (int melIGFpjmAaA = 361757550; melIGFpjmAaA > 0; melIGFpjmAaA--) {
            vmErwsoDqgqFOHI *= rdXCPCK;
        }
    }

    return mRLsjbaJl;
}

bool GaDWAAojRFaqnBAh::DXUxALJEXlUGvKkb(string HxQqMc, string UuzZowClckc, double QsViGBpnGBQMVmq, double xqbfxR, double yxBrqbMmzPuuY)
{
    string tSNWKjO = string("GMPOpOuyTuiwNtKMuWsMvVYhgFbLhQRvWSmOisSqQQaEihTbkueBmDoUrZbQFKpvZjztCROKepRkVTsTZceJhBYbgTyKRbasZaoOsdxKvk");
    bool vVZxERaQ = false;
    string Qbjoz = string("zZaberKmnuvmchNfHgtWQyDEfAbLBUvOibbkvOOMYurFAABvGtumebEwTaojnDfpTQqaTJalhXZyNAabzdoCmeodVqRvRnCiyhMXeHlTrfB");
    double GuWWIYnpWlZpg = -386487.2633800914;
    double oWZCKb = 344973.753317935;
    string OuhFCvzhgrUwGKO = string("BglBFhmlHRYASrxAGqNXmnAAEqNzAwWPYsVLPRgHwySDowOdZuDhKmQuShupUQrBIvcAVJBgIKRDpZbVNsbfZZLOJiXPHKqlHyYweqVtRvmuPrJZJuQyQSEOgUBjtfAsBYvFzRsqrqRlpNlWk");
    string eDFKghLw = string("RDnyvqhSqqiraGcoidqrLluFmkOXKRgZUyKhZnjSpNgPEQshEatrmabdzMPt");
    bool LWJflFZeqmZ = false;
    string ZaokxQEfRu = string("MkMSnKDHtRtUqFZmOKzKCQZmRbyGzPNnGfEQLygANtmwMVrLmjeqmivefbaIDBVesBRqqVUhLEvCwrtfSfpYdIuNFjRPGVfBoNDQYKlIqCuTwbZIeHUCrEjlpygnXdBNOgPjtYLXIhmEGUykveqFqljWNHKrRxLwVbnVQuDVjWNHobPoPGaallzZQfNovKYAiuRZSVkBculDnmtWbCvYSXsHzzTUoSIXSejLQXMqRTvljUQQQGUdHKi");
    bool YuDVJlpWmGiBtrYR = true;

    for (int Amhrrv = 608425070; Amhrrv > 0; Amhrrv--) {
        oWZCKb += xqbfxR;
    }

    return YuDVJlpWmGiBtrYR;
}

void GaDWAAojRFaqnBAh::PAVbYwfiZcZZ(double QwwyB)
{
    int oEKxpvTKjrfDgX = -880156608;
    int ZdhsWTH = -978024640;
    bool TnvBoWgUFVz = true;
    double fQBcwcqV = -69358.50257442563;
}

void GaDWAAojRFaqnBAh::OLdgwGAQufsWRO()
{
    string EDRsGp = string("IoaRNyJuKTEcSZLnuOOvmAZjXDeAMaRYhXLOZkYIzglDyEPLphZoOeABU");
    bool syACuy = true;
    double lHLtMhtTaA = -797051.4128584354;
    bool gLWNzDORIpycfB = true;
    double CTMbSPLjKI = -442253.14866262296;
    double VroIZxfjWtW = 235001.07866834127;
    string EnxpQlz = string("mLBpcSIeMGJpreKDZGdZASipOpYAKwOvyZtMieUOWFSCeyiMLtqOZcCammXLbpuCHAGfBBhTHYlXSbAcJEmXdiIpjscADhPhzYlnfIByFRFAsJrgScGyzDPahwnVQfmGdAGPRirgqMHztJopZpXSZxDVkmmhOhzHzkUwJKRgBheh");

    for (int ooFQXYA = 2123148892; ooFQXYA > 0; ooFQXYA--) {
        gLWNzDORIpycfB = ! syACuy;
    }

    if (EnxpQlz <= string("mLBpcSIeMGJpreKDZGdZASipOpYAKwOvyZtMieUOWFSCeyiMLtqOZcCammXLbpuCHAGfBBhTHYlXSbAcJEmXdiIpjscADhPhzYlnfIByFRFAsJrgScGyzDPahwnVQfmGdAGPRirgqMHztJopZpXSZxDVkmmhOhzHzkUwJKRgBheh")) {
        for (int CYMHz = 639041854; CYMHz > 0; CYMHz--) {
            CTMbSPLjKI += VroIZxfjWtW;
        }
    }

    if (lHLtMhtTaA <= 235001.07866834127) {
        for (int aHshvxox = 1788259145; aHshvxox > 0; aHshvxox--) {
            lHLtMhtTaA /= VroIZxfjWtW;
        }
    }
}

double GaDWAAojRFaqnBAh::gxLNZPm(bool RBrQxFY)
{
    double nUsHYaAIKfRlp = -707617.6477977877;

    if (RBrQxFY == true) {
        for (int tojyHHYDGHCqr = 1667856615; tojyHHYDGHCqr > 0; tojyHHYDGHCqr--) {
            nUsHYaAIKfRlp *= nUsHYaAIKfRlp;
        }
    }

    if (nUsHYaAIKfRlp < -707617.6477977877) {
        for (int OdRKrif = 1692615125; OdRKrif > 0; OdRKrif--) {
            nUsHYaAIKfRlp *= nUsHYaAIKfRlp;
            nUsHYaAIKfRlp -= nUsHYaAIKfRlp;
        }
    }

    for (int LGPhayRCQW = 1715001006; LGPhayRCQW > 0; LGPhayRCQW--) {
        continue;
    }

    return nUsHYaAIKfRlp;
}

void GaDWAAojRFaqnBAh::BrhairE()
{
    bool rbirRE = true;
    double ZGSxtBNNQtQzU = 990769.2889971876;

    for (int zJhkBOCYUsaRPtJC = 774631517; zJhkBOCYUsaRPtJC > 0; zJhkBOCYUsaRPtJC--) {
        ZGSxtBNNQtQzU = ZGSxtBNNQtQzU;
    }

    for (int jyZABnxCN = 47404581; jyZABnxCN > 0; jyZABnxCN--) {
        rbirRE = ! rbirRE;
        rbirRE = ! rbirRE;
        rbirRE = ! rbirRE;
    }

    for (int GixyjIro = 1296761217; GixyjIro > 0; GixyjIro--) {
        continue;
    }
}

int GaDWAAojRFaqnBAh::XdpmuAnWtxc()
{
    string gIqDeTAGAdT = string("BhLXfsNKLVUphPudVYYzlDMGOdXCIUVZVkGtHoZRPPHvZdSkfqJaMXnGAwlegDZLzNMkaRqYQziOFzumnBpsDYEJCaGsOtCEXAkKxwUvzcaNdNbfWSZhSCcPuGHWRjyhHrrbAFGMwvnLXEFXyjHAFQTJDeSTmHJOggUPoeOWTmgGvecAgYvZHNdogMrnMkbBHnLjMOynIOjuAnDtqTNULMmLHfEZ");
    string YYGTrct = string("mYLULrYKZBuccmNPOrMQjZhQVohMzXRlYZgYkMB");
    int iYZJjfVJSkSop = 1173410348;
    int mYuIQUXFATTE = 1459872831;
    string PotgrqSSxjQP = string("SxteRrbtSmtqCmoSMIksiqbkrOPVKdJXNiVemgXkJQdfVlBuoHJDKwQjaExdguVgkjVYPLBqtHsFVTayFiycJZeCWGzsEGzXCdRVCrBdnSaiNnccwepLGKIAPmSVhBcmhsJgwnLsaoLvXEDfqeCauaUejTngTgCvmzyADAeVrdCkjHCjUpPgkcdFhxnOPJtpZGaYaYnOVpccNTgWgdqVnOYgiRRdyJOYbJxrhVxTbviKofnFxDfj");
    double cpiOvlEyiV = 739720.8943370037;
    bool nCAUjsGNcbPpJ = false;
    string zTaEBFqwWAb = string("TCWjCNzdBckhlkjzrzbPvyLToOBpMGAEQTUHvdvwqtCGZWiwtQgtYEQTKRPFbRKMHkvSgcjObmOmiLFyISGmkmfaUmWrleKqfnrvEdLahkMOnVEdvWWmBDMPmJQVPobMzbqioGoejWPnHIlaKsdoKrewXQXRWliXlwMkpC");
    string JlewCxnCcUi = string("DMmNWVbfTBsxHqZanWHlFyjMCXsnYqfumDdfqNQuEQKUJrCUvuycdKWflycyQTSgdSYAUYhYtwzTLCksZycVxmXsjWtDCiZGEQnmPLWkylFmgFVFtlX");
    string leoMng = string("HZNXytWLYazWOombqfQpcznxGlWibemEijymGhJWQyUkrgYISlrKHvejNCIWDLTBZtiMwXGcGBygqWGIIgfsAUHQlTXeOnFrbzsTusgnYIB");

    if (YYGTrct <= string("DMmNWVbfTBsxHqZanWHlFyjMCXsnYqfumDdfqNQuEQKUJrCUvuycdKWflycyQTSgdSYAUYhYtwzTLCksZycVxmXsjWtDCiZGEQnmPLWkylFmgFVFtlX")) {
        for (int rgmfANwcYfuEI = 324971577; rgmfANwcYfuEI > 0; rgmfANwcYfuEI--) {
            gIqDeTAGAdT = gIqDeTAGAdT;
            zTaEBFqwWAb += JlewCxnCcUi;
        }
    }

    for (int RMLqooNSjxyo = 1029129518; RMLqooNSjxyo > 0; RMLqooNSjxyo--) {
        PotgrqSSxjQP += gIqDeTAGAdT;
        leoMng += JlewCxnCcUi;
        JlewCxnCcUi = gIqDeTAGAdT;
    }

    for (int gsxpZGmyE = 1614607688; gsxpZGmyE > 0; gsxpZGmyE--) {
        JlewCxnCcUi += gIqDeTAGAdT;
        JlewCxnCcUi = PotgrqSSxjQP;
        PotgrqSSxjQP = PotgrqSSxjQP;
    }

    for (int jEdQjNxFvULJgsaF = 926844015; jEdQjNxFvULJgsaF > 0; jEdQjNxFvULJgsaF--) {
        JlewCxnCcUi += leoMng;
        YYGTrct += gIqDeTAGAdT;
        PotgrqSSxjQP = zTaEBFqwWAb;
        YYGTrct = YYGTrct;
    }

    for (int jTixHNbGH = 1117334861; jTixHNbGH > 0; jTixHNbGH--) {
        PotgrqSSxjQP += zTaEBFqwWAb;
    }

    return mYuIQUXFATTE;
}

GaDWAAojRFaqnBAh::GaDWAAojRFaqnBAh()
{
    this->fgmUwHWMUkHLCuc(string("ekxBtwMXLxqPLxFXdXQiMsanZCLKAEdPbCeNavnTTPzZjpWAmlyGvPUgdKjrEjgRJlpBBuvlKPRqnJShKemkLSDrYccpFduJeOmhDYDvftGAuzWtxPZGCbtNTFIGTBgydTddffILhzhEyQbETMwygfovqPEWsWEWWyOgilNhrKuYFjukCg"), 557521.0291159069, string("CKJtpJyfWcRCBmzSLEQHqohGgJBrcsEHYuETzVDcftUgtklhlzyIceFcMfGAEfKYwxLCLSkSUwbDIcgEhYftsnfnYeuSTSVFUFZsOTTfNUvWTIgwSeidPdrSDrriWwzBKQhHZSXqIIkrbVGtzOzmUkLYLFvgIJzQzLmxIEUvSvNYMRfefzJWJQJMvjODHgcBpRvzPZFMWivuoIvFlNgzXqBloNjcrcKnQNdnoGehNMmStAWtyqmT"), string("qFJbCmixwZHnbojZaROEPpoVFmyqFUpdBsunSSbpbWMWfvEgSHhwbxxcBhZqhVsIVnGzxFuyaxBxgjBiVrnNwaIUnFHrCigBkIQSEUjsPTPyrRMzwnAcCDZjghClpqlseGeKmaVuFs"), string("oNhiIjTPBFeJEhmHVwHlpllhavXRoMzgXVkcjJTpjXgPOGOeTxgGJuDqIcirrzzhvdiqtgyptbAmxGlwXznnXcOBVYxFdWAQNxoVdIFpvxYEbtbNumazsTEedZ"));
    this->kutvnsFczYlMIdyX(975736.1622201895, -1595105944, string("raqSUGPzdJmATlUVBIwhKZYhTNzlWOzZjBnYlXgbGBefbLJJRVGEYCpMNbUboabXHqsKOFiFXEOpEBVHduSAOKlVguGILbTiHPojmbTaMreeZhzdoazEJQwXZtpqScHIHzTykXNSeOhflkUVPTroDholEDvyCocOwpMcxWQrzqLeaTlJAgNyuHgjmGvW"), 651432.4158093492, 610346.1623241558);
    this->zyTwyQsYFHs(1597058572, 966575852, false, 5948.859778735068, -1397200247);
    this->tNOPAByOO(-1821395228, -1013945.5860126542, -911248.6087160537);
    this->DCYVurFVBrM(false, string("QXMZhHVtcHHgNfpSVUNUbEotTFnKRfAUmtxLVgJoLRSEKGJmvsqcXntrwyrnRRrfjTYASNb"));
    this->CsefmipPwg(string("rUCKhPgNKHJusrlhfJbnoPZcZZoQXvgDDIUJUYTEQVnPHHOynKOmdwcyhAFQvjBqYWRvShwExhQjVkakXGTxXPPyBVYwlLHAxbgPBYcqwqYXqAEchtQDogRbLYZawNhcpFWLydvvnBwMCksmowwILrlogYmforASJAJlqArUAKXtlOsjP"), string("oIDSJHwMAyhvLlSWVZoEcANQVXBkTZXNXBFidMwLIOAwqJSIXaBmVvWMMDOsnZkcPkhLMiWmCxObeQAmKmFRInPKjnpCmIt"), string("lmIBHiIXVuqPBLmGkJEgOUdhVSVOVsVtbsgsvFwpaMgkOkEfWhqxjQaUZWtPmWcLgzoqzLgf"));
    this->BLdydfwn(-994862.3238626524);
    this->SyhYctFITcPuBO(209431144, -331690486);
    this->DXUxALJEXlUGvKkb(string("qFEhnpFEBClHgTTmaliCbwJpCKLjZLJguqyFphPaAejBsUJQRQKiVabnZTeCtHnFVgWylLaoRsqMELgNkNvoMPGNJfHUJWYLrZnfCGecNpOCiTPRVeCSGtsVxfdjeJUFLGFKJcwyRuxdUqOFrSAQ"), string("KqMWHUlNMjfLefHbjkLJdCiuavpOyNMaPbbnyaGuOcwRvFCwPRsMsszeBLmWKqMbaMmdoTnwJWLHnUShMTCdzGOEQUyNQyXRxKUwqNtLWyUusIfiLPBDQrQdeOMHIkgNPQaHDFCicAcSqXdHSvfheZZWKfHTSMiAheRsVrGRKGuNWcgpsXHXIESJRmsvoBOTNnuiikRlqAnjrcnuDVlbLEVOWCwTEM"), -455770.77997080004, 109589.69463345868, -663169.1286420757);
    this->PAVbYwfiZcZZ(-639549.942664598);
    this->OLdgwGAQufsWRO();
    this->gxLNZPm(true);
    this->BrhairE();
    this->XdpmuAnWtxc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eYGRv
{
public:
    int iKSDwESm;

    eYGRv();
protected:
    bool DLgKiFrLkXdpR;
    double pezyhPqamS;

    bool HpwdndpUZjxTbFrn(int aaQjuWhEln, double HCOnCnukMvoAHE, string ISPGojJNPzPfTW);
    int YbhvkVBMAMFKV(bool tdiGpwl);
    string KHaXUJDWxBx(double LBmUqZqryaAeARz);
    int PQFpwIgYpRIlMSA(string LuLfkUQWwxhDz, double lCwLXjVkGB, double TqBazYal);
private:
    bool MlGOSlsSS;
    bool lNgrBYVjV;
    string KOqQcelBgIOpNdV;
    double TpkeBjVcJO;
    bool FQWSrWE;

    double UGBedaRAeJGJGY(double foXwdhXmrx, string gXUjvM, int mZxfQyjvBwAdPyfn);
    int PCmHuFEcI(double IsPpHDGebPNiI, int uySYKyaSIyhlN, bool NOYUEdRvlxIW);
    double QuVSwhBgrQ(double NQLsHzaXjEc, int wFNOCUvscQNduHW, string OhmTAD, double yQYoKaOJVupR, double rwKeQUtobCbVI);
    int UkmPRbvGPMDBj(string ZADxkKET, string oAsUsOwHRe, string IsscVmIVEC);
    bool MBMyRlvuxvGhO(double QMmvBMBzyNAhadgd, string gBoovb, int YNUhjcxXyPx, int hsoRee);
    string yqouHEKX(string wvHtKjNcYOwF, bool FoumCAf, int oounxnvVX);
    double OBLiK(double nQgFDcgZcWVY, double PcdZJadwf, bool cLUjauhhYmMrdp);
    bool wbtecSRzrZizyx(int tMGJskbpz, double XKxdYGHzr, bool YwXCSmoMrxtL);
};

bool eYGRv::HpwdndpUZjxTbFrn(int aaQjuWhEln, double HCOnCnukMvoAHE, string ISPGojJNPzPfTW)
{
    double AlcwjGTxUU = 963684.4514500238;
    bool rNphJIOts = false;
    int GTfvnCprr = 517064011;
    string bXUVpIIakPVXbi = string("issJEiAVfcgaObtWTtGxSBtzBVVUJWYbHMtwZkDXfxGTAZVATBllkqiOOpJuOApqLJWhScAZVCUfKKenChHmHLjPyXrEEnLgdgXmOITCoJEmguRgtQQjjfXWVSrPW");
    double pUrWHHbKyx = -524108.4040108315;
    string wTUanAPsMLcUfk = string("tIYONdupDLnyINFvHAhqoaGfqZJYzCSPGzPAnoJsPKSOLJwUkwpXZfwTkxWWFnGwiWnzqCAgnwRZuFpniPAqDryOIUOprjrJSrPObbKOGCFFHIABghmtnekZRIVtVUhAykvBgDknLIwknHFPKUvZwiWpYYHBOlXhsIBGvIMLgzzEjQgFrLpgVQoCmWtbxywh");
    double bAGrDxBsoY = 492535.25375401735;
    double MtZwyr = 827414.1815685935;
    bool PgYXEwEZENWbk = true;
    string zyfZYaO = string("DpkDPmTCOpynNBMZjVEfHMIIcnMyCySyegTdYjQDjHhNKycmmttY");

    if (ISPGojJNPzPfTW < string("DpkDPmTCOpynNBMZjVEfHMIIcnMyCySyegTdYjQDjHhNKycmmttY")) {
        for (int vOrNEwC = 1196677268; vOrNEwC > 0; vOrNEwC--) {
            bXUVpIIakPVXbi += zyfZYaO;
        }
    }

    for (int mPzhudCyGUpL = 2132013295; mPzhudCyGUpL > 0; mPzhudCyGUpL--) {
        zyfZYaO = zyfZYaO;
    }

    for (int pufsepxiyW = 2008629061; pufsepxiyW > 0; pufsepxiyW--) {
        ISPGojJNPzPfTW = zyfZYaO;
    }

    return PgYXEwEZENWbk;
}

int eYGRv::YbhvkVBMAMFKV(bool tdiGpwl)
{
    int xTLchvpAasmu = 1118574759;
    int DaAmkNLRiZTiA = -1769816787;
    bool jFAQf = false;
    bool qzQNIom = true;

    for (int kXswPvTHJ = 1057851742; kXswPvTHJ > 0; kXswPvTHJ--) {
        qzQNIom = ! tdiGpwl;
        qzQNIom = ! jFAQf;
    }

    for (int XWVcZMtmjQ = 627421193; XWVcZMtmjQ > 0; XWVcZMtmjQ--) {
        qzQNIom = tdiGpwl;
    }

    return DaAmkNLRiZTiA;
}

string eYGRv::KHaXUJDWxBx(double LBmUqZqryaAeARz)
{
    double JVdKwmE = -704364.1904775115;
    int HoUnGYtKyRXIKE = -126257863;
    string kKkgNSEWAHYPp = string("uaeTbREiiYgTClWPdSkbIHCUSiqBVVubOqsLAGxCZjycyvsoXfFSxIUKiEckqEmyPtiYheslLheUvHxqcXhRhAsxEfVvmRAlFdNHcaRvciopfTxnYbqEJkRZMUEduWdNEPjGHuEMoNZvuwnnKPTKjUVkTCuDXzcZgxCiMJoFKEHAnDzIQgIAVHEwLOqluiGxggyuAQkXoIRlQOUDWobXZDsByBXOgRvgztDANT");
    string YTBrbrpZhuXrZPMI = string("iRtWJFTKokAftZtEFuGRuMjiTtKXOwoyYvijysuhfvXInkXBwaRzRAaDKQbmtJrtxiqwzdDLEZCXYIbkttIamwbnOBQmBwflhQzm");
    string wWtKdFO = string("ZMidFCxNEvgvKfKlDJzXnGQKhBjNhbeXXisFdOuCQPgeFkNqRmxNUKqvjbQkjWgMoKJSCMKmzcwOKQBEJifslVWaXOKkFCkgbpupkRvKNUCLyJiQdgyAQcYXmdutKWDYiBFJNOZcrHJHvhmccwuvjdVeEGzKgFTNhzebjcotYTHgEJwTtnMytErYpLnnOULSalDdTFETyyRYuWFjpHytmKmRmWLMDAyNkzDUXC");
    string qYvbhmcaj = string("VbmmT");
    int ANNmjEElnJmEVMop = 1179624848;
    string wNyIICyoCnEOTX = string("dLkYcVqwUaHJpVnZSPpUiJITjRpIEInZYasHvSTMxUhCsnLcsSrkLbQPDmSGJRPcqQcLSkcUMPpjLJJTEGgVLDNRSXCdzNIZDjdPkvtWPmDiWcWVWspryEcgJYSGUpGsqnFOmLkCnPhruixTqGCqSUozntSRPPVbVodQTevtYyvEdKxcMonfZr");
    int MMzOlULJzoEWj = 2112198426;
    string mSjURSOxIJvm = string("pMecmlLIfEdqynyryvKDtVZvWyGdvmLWoMQxqGbjvhhQZSJwLZkqabxlaYoRWJrSpgqOwZbeMJJiuNMNFYLbPnNEVpbLCKHAkpGVpPowmpUPWpvleTzfmcTxhrQSrIwtROjNVRFfSZyyLUNCUySoROAkgdtUWuFDqitDwtxeWhkewQOBRNFEkWBIteiqferKOXdVoCDlctlBzMzYfdfeKoNqLGSLsIUiuxoezQOvoYyokIiRIXIyzMxoJX");

    for (int UoJck = 829137067; UoJck > 0; UoJck--) {
        kKkgNSEWAHYPp = YTBrbrpZhuXrZPMI;
    }

    return mSjURSOxIJvm;
}

int eYGRv::PQFpwIgYpRIlMSA(string LuLfkUQWwxhDz, double lCwLXjVkGB, double TqBazYal)
{
    string vDTjbMxqiMYO = string("KzrvorXzFEjmGpJEEFwviNatccCzKVzcwWKuEGQVXspSYNYaPtPTUJWOjXYMpXxnqLpGeHkqggCoqmNvxmBJPMqBthwdabYipmIkRbDpeYLcddWHVLnPFaHMjEijMnPHbiSAluwrGPeERLCLsDU");
    bool FcIshAjgopi = true;
    string cWQrlqqAljMCA = string("iLTEkFpTkhDFmkTkMUgRcsCDhHtOozceTMtMBPVVPTjqZOBboToolMfjKrwEzsnDn");
    double VEGfAMyehAprrmjY = 617507.1042844844;

    if (LuLfkUQWwxhDz > string("KzrvorXzFEjmGpJEEFwviNatccCzKVzcwWKuEGQVXspSYNYaPtPTUJWOjXYMpXxnqLpGeHkqggCoqmNvxmBJPMqBthwdabYipmIkRbDpeYLcddWHVLnPFaHMjEijMnPHbiSAluwrGPeERLCLsDU")) {
        for (int JPRWWcvlnICTtdjX = 1348395297; JPRWWcvlnICTtdjX > 0; JPRWWcvlnICTtdjX--) {
            LuLfkUQWwxhDz = vDTjbMxqiMYO;
        }
    }

    for (int jUrMMcrQDIOZOl = 763410011; jUrMMcrQDIOZOl > 0; jUrMMcrQDIOZOl--) {
        TqBazYal /= TqBazYal;
        TqBazYal /= lCwLXjVkGB;
    }

    for (int gNOPnDiBDey = 918291699; gNOPnDiBDey > 0; gNOPnDiBDey--) {
        vDTjbMxqiMYO += cWQrlqqAljMCA;
        vDTjbMxqiMYO += LuLfkUQWwxhDz;
        cWQrlqqAljMCA = cWQrlqqAljMCA;
    }

    return 112282985;
}

double eYGRv::UGBedaRAeJGJGY(double foXwdhXmrx, string gXUjvM, int mZxfQyjvBwAdPyfn)
{
    int LuMCvBQSsEVMZRgE = -1115936357;
    double oTQKPhejY = -677907.8188758629;

    if (mZxfQyjvBwAdPyfn == -1115936357) {
        for (int tQyzZFd = 314595237; tQyzZFd > 0; tQyzZFd--) {
            foXwdhXmrx += foXwdhXmrx;
            LuMCvBQSsEVMZRgE = LuMCvBQSsEVMZRgE;
        }
    }

    if (LuMCvBQSsEVMZRgE == -583274042) {
        for (int yEGFYWllt = 692558380; yEGFYWllt > 0; yEGFYWllt--) {
            LuMCvBQSsEVMZRgE /= LuMCvBQSsEVMZRgE;
            oTQKPhejY *= foXwdhXmrx;
            LuMCvBQSsEVMZRgE = LuMCvBQSsEVMZRgE;
            LuMCvBQSsEVMZRgE = mZxfQyjvBwAdPyfn;
        }
    }

    return oTQKPhejY;
}

int eYGRv::PCmHuFEcI(double IsPpHDGebPNiI, int uySYKyaSIyhlN, bool NOYUEdRvlxIW)
{
    bool RbUzXHSKBOHeU = true;
    int nYxNV = 1836091056;
    bool AfMhHZAgMV = true;
    int RNRXXVb = 420048041;
    bool lEtpspqm = true;
    string SyErTBAyX = string("HWBLGGLYjaYneClqXRbIaIPSOMfxszroIcKhExwfDVKXRjnKmyUMqqQsetqVNHGaGQuWaLyvlmgJCOOXYLwubVVQzwfKAqWRmClZytJOnphfabLMuWFBKgCzHeVYAVqJEZWuctcQpLIbVyQDeEjPjCzxirqYtEAmDW");

    for (int YPWKDAPcUEBQd = 1661265113; YPWKDAPcUEBQd > 0; YPWKDAPcUEBQd--) {
        lEtpspqm = RbUzXHSKBOHeU;
        uySYKyaSIyhlN += RNRXXVb;
        lEtpspqm = ! lEtpspqm;
    }

    return RNRXXVb;
}

double eYGRv::QuVSwhBgrQ(double NQLsHzaXjEc, int wFNOCUvscQNduHW, string OhmTAD, double yQYoKaOJVupR, double rwKeQUtobCbVI)
{
    string zmVntwNBez = string("NFVpmFHXaIGfxYhHuTCQorHpLAWJZfoHmrZtNcHAXyuWWtVcIZbijspjJLdemlVLTIDxURffRvwBkiR");
    string IZKDxKncRcbRIhKp = string("FftdLzSiAvAPmTjKkdlEoMFWsZMwJn");
    int qHScqrgaruUnoWHB = 1299363807;
    string tizxNa = string("cQyhmkapklZgjpZTzGGlOGAkRIOVJinIDkzFRtgpDBRdthyqWkihKbMpAQrszUsZgwZorngcTrRPspJuOUuzcetbMgmXZgHqqgtQCeoibQTrijBKbtwxzkFLeVhzoWsbYpsWrugkEMVUhbyAvwZcxdtZJwvpdOnRcEkAbHdpIpnvuQHBwpazdGDby");
    int iBqMOdu = -1699909903;
    double mmPgiImjszpRksaf = 376651.11210146075;
    int xaqRtNPlD = -99199329;
    int EJXuotUtH = 304799727;

    for (int lkCRSEbaHOrqEj = 371404214; lkCRSEbaHOrqEj > 0; lkCRSEbaHOrqEj--) {
        xaqRtNPlD += iBqMOdu;
        IZKDxKncRcbRIhKp += zmVntwNBez;
        EJXuotUtH += qHScqrgaruUnoWHB;
    }

    if (rwKeQUtobCbVI <= -20004.399452044585) {
        for (int uQxxaLbShs = 820902111; uQxxaLbShs > 0; uQxxaLbShs--) {
            continue;
        }
    }

    for (int DiXSbAIOwP = 427257130; DiXSbAIOwP > 0; DiXSbAIOwP--) {
        wFNOCUvscQNduHW -= EJXuotUtH;
        tizxNa = OhmTAD;
        iBqMOdu = EJXuotUtH;
        NQLsHzaXjEc /= mmPgiImjszpRksaf;
    }

    if (EJXuotUtH == 673008588) {
        for (int rXgaNJwrJ = 71542506; rXgaNJwrJ > 0; rXgaNJwrJ--) {
            qHScqrgaruUnoWHB = iBqMOdu;
        }
    }

    return mmPgiImjszpRksaf;
}

int eYGRv::UkmPRbvGPMDBj(string ZADxkKET, string oAsUsOwHRe, string IsscVmIVEC)
{
    bool VdKWyM = false;
    string VkHmPivpV = string("KpQCSMpuFqQwevkOoGjCghsrOHsxuQyVLJWqRmoquehyJDLL");
    bool mKQXiKXIVCvu = true;
    string uZdjnGdqyNDYZ = string("DMXxUjwsQAVkWZYeCZHGqUPncJMiYpBHjzMMVebbiPCVgXxGJwXwogdtRMzffvcwajKhGTdOTRVRQKiFZlayiiHGAGOKOzFTchMXEBkrkQSVbkqXnyyhaCRoLYyQzawSxvdDXNRwhBfObufKAfqgijXIRlyEDvptguMmdHiYnGMMnONNUUpTwZUxGsHXiQgjUrPGZU");
    int DuRZyWWmKZKgo = 1930062027;
    double oFdrGRLNBqLGh = 521907.02924042003;
    string VEfuALfbWZFP = string("oCnyeITvMmoqjoUgyXBaXNXJDUYkORtwrkbVpUHFsvpPVFeBRCfkkEXFLXRtpCcQEQFuzXbhWWlzLJCZAnwtIERPlXwUjLRClCusbLaPGUDMdXVmkONHLbhpeCeUlTNKHHGDlrjlWoBuyZsABBaXBRFJXaNavEPZXlLQfFLCtMXbjLntHcFrYrmsl");
    string lyuljblTYUyAtdQX = string("GLFwrszygaZXvHhGLQTrfCXxRlTuGtprARVjXICZeyKIxnqwmdGdzfrOdvpiBRVulBxoOpGAppAKKratByiruGbcpWUSIioFcowhOpceXBMCTSNIBCDfwdtHFfXBQdmWuvYosCoFyBRUiTkunwUxNC");
    double spivyu = -60723.896310171935;

    for (int UiJOdsQQa = 511250866; UiJOdsQQa > 0; UiJOdsQQa--) {
        uZdjnGdqyNDYZ += ZADxkKET;
        IsscVmIVEC += VEfuALfbWZFP;
    }

    if (uZdjnGdqyNDYZ >= string("oCnyeITvMmoqjoUgyXBaXNXJDUYkORtwrkbVpUHFsvpPVFeBRCfkkEXFLXRtpCcQEQFuzXbhWWlzLJCZAnwtIERPlXwUjLRClCusbLaPGUDMdXVmkONHLbhpeCeUlTNKHHGDlrjlWoBuyZsABBaXBRFJXaNavEPZXlLQfFLCtMXbjLntHcFrYrmsl")) {
        for (int VsXFvyHNztWoQW = 879845290; VsXFvyHNztWoQW > 0; VsXFvyHNztWoQW--) {
            IsscVmIVEC += IsscVmIVEC;
            lyuljblTYUyAtdQX += lyuljblTYUyAtdQX;
            ZADxkKET = oAsUsOwHRe;
        }
    }

    for (int OTtuRjJ = 1835381763; OTtuRjJ > 0; OTtuRjJ--) {
        oAsUsOwHRe = VEfuALfbWZFP;
        ZADxkKET = uZdjnGdqyNDYZ;
        lyuljblTYUyAtdQX = ZADxkKET;
    }

    for (int KWwYW = 297586776; KWwYW > 0; KWwYW--) {
        VkHmPivpV += VkHmPivpV;
        uZdjnGdqyNDYZ += oAsUsOwHRe;
    }

    for (int BkjHYsZeHisjSTCe = 1065407220; BkjHYsZeHisjSTCe > 0; BkjHYsZeHisjSTCe--) {
        VkHmPivpV += oAsUsOwHRe;
        IsscVmIVEC += uZdjnGdqyNDYZ;
    }

    return DuRZyWWmKZKgo;
}

bool eYGRv::MBMyRlvuxvGhO(double QMmvBMBzyNAhadgd, string gBoovb, int YNUhjcxXyPx, int hsoRee)
{
    bool BLgGP = true;
    int DqEnFuTPldmaz = 1741296573;
    int Coolvaras = 1283188550;
    double wmGgk = -154647.73353651352;
    double MtINM = -427925.11044852505;
    bool ggGjQEMwbhmrsBap = true;
    double TzTKCKv = 361147.4629984071;

    for (int QJXJaFfEmel = 551416977; QJXJaFfEmel > 0; QJXJaFfEmel--) {
        BLgGP = ! ggGjQEMwbhmrsBap;
    }

    for (int wmvauwOLatW = 2034197316; wmvauwOLatW > 0; wmvauwOLatW--) {
        QMmvBMBzyNAhadgd /= TzTKCKv;
    }

    if (Coolvaras == 455116995) {
        for (int hqecLMdtatI = 1648829912; hqecLMdtatI > 0; hqecLMdtatI--) {
            Coolvaras -= YNUhjcxXyPx;
        }
    }

    for (int GUpbSUVg = 1614183717; GUpbSUVg > 0; GUpbSUVg--) {
        DqEnFuTPldmaz *= Coolvaras;
    }

    if (hsoRee < 1741296573) {
        for (int IUkqQS = 2074988311; IUkqQS > 0; IUkqQS--) {
            BLgGP = BLgGP;
        }
    }

    for (int BwFBLT = 1484755020; BwFBLT > 0; BwFBLT--) {
        QMmvBMBzyNAhadgd *= QMmvBMBzyNAhadgd;
        DqEnFuTPldmaz -= DqEnFuTPldmaz;
        wmGgk -= wmGgk;
        QMmvBMBzyNAhadgd = wmGgk;
        QMmvBMBzyNAhadgd = QMmvBMBzyNAhadgd;
        hsoRee /= DqEnFuTPldmaz;
    }

    return ggGjQEMwbhmrsBap;
}

string eYGRv::yqouHEKX(string wvHtKjNcYOwF, bool FoumCAf, int oounxnvVX)
{
    string gPjjA = string("lahFPuDIfQVFRtbXZASAIPRoWbYDsBIOjQDyZkaDqCzwUYQaiVjNDlrtAEiHpKRYFLrblvvEbxrPKWoeVslnaDaFIRyiYPctgUfpFEYirSiVRtEwQDxWbnIsDLHdFziwqFzMwog");
    int WnsOVORkmSMx = -1148194049;

    for (int YDPkbSbHQzpxc = 1579622722; YDPkbSbHQzpxc > 0; YDPkbSbHQzpxc--) {
        oounxnvVX = oounxnvVX;
        wvHtKjNcYOwF = wvHtKjNcYOwF;
    }

    for (int NYzOHLasPCgpg = 1189483172; NYzOHLasPCgpg > 0; NYzOHLasPCgpg--) {
        WnsOVORkmSMx /= oounxnvVX;
        wvHtKjNcYOwF = wvHtKjNcYOwF;
        WnsOVORkmSMx *= WnsOVORkmSMx;
    }

    for (int nKcfRbgIhiHsjzlp = 391339276; nKcfRbgIhiHsjzlp > 0; nKcfRbgIhiHsjzlp--) {
        wvHtKjNcYOwF += gPjjA;
    }

    for (int JclBPanTIH = 886162607; JclBPanTIH > 0; JclBPanTIH--) {
        gPjjA += wvHtKjNcYOwF;
        wvHtKjNcYOwF = wvHtKjNcYOwF;
        WnsOVORkmSMx *= WnsOVORkmSMx;
        gPjjA += gPjjA;
    }

    if (FoumCAf == true) {
        for (int QlXkMqnFiKf = 207588517; QlXkMqnFiKf > 0; QlXkMqnFiKf--) {
            oounxnvVX = oounxnvVX;
            gPjjA = gPjjA;
            gPjjA = gPjjA;
            oounxnvVX *= oounxnvVX;
        }
    }

    for (int hRrvf = 1154902183; hRrvf > 0; hRrvf--) {
        wvHtKjNcYOwF = gPjjA;
        gPjjA = gPjjA;
    }

    return gPjjA;
}

double eYGRv::OBLiK(double nQgFDcgZcWVY, double PcdZJadwf, bool cLUjauhhYmMrdp)
{
    int EQAHqhj = -1536992038;
    double BZhEVBrtLgkWW = 883443.6937769824;
    string xyjkcyLOXuMB = string("xjuisJZQnfnrsLrKZwhPZWMuFphMusGBEFzArgezZVhBXgpgdkUZfjnxzTpKNEMyEXgiPOYpUhdXJIdzyQPwJTsuCkaAInsieiLFkFYYBrbekWfYlGEbbUyrChYuflZxvKhBoHSFrwGKDcdrBxAVbNDDWpmZaeKfZAwOiMNyFjHcInAGbw");
    int gpDOfmP = -396695767;
    string COZxuWSBdDi = string("QbdiLBXZDRNLGTDCsuLWsxnybgsOKlOAcHsSyYnHdZikOtMCqtvDYIFYmfwmOOdzUtYZvsKBXiJSHXJAsrHIoLbGUeBSpJeMZpEtDNvQjVWxDmwvOrDNdXSDSqJCgJpOxmQLmQnjTstGAWJljzZaUeRsRLDkqImwVsTFTZjcKTMYAcVLNkAjAzRjZcQRVDcisQOllzKDjMjkZDqRtcYDftPlkIXIPUweokgNJaBwVFWfbqxdDllNPyDclTPABa");

    for (int iXCwhpMzCQ = 1195484984; iXCwhpMzCQ > 0; iXCwhpMzCQ--) {
        COZxuWSBdDi += COZxuWSBdDi;
    }

    if (PcdZJadwf == 1022669.3698923433) {
        for (int jueUBfJDYmsExsIG = 98195562; jueUBfJDYmsExsIG > 0; jueUBfJDYmsExsIG--) {
            gpDOfmP += gpDOfmP;
        }
    }

    for (int AVBFAfdymvlYCxW = 1717783854; AVBFAfdymvlYCxW > 0; AVBFAfdymvlYCxW--) {
        xyjkcyLOXuMB = COZxuWSBdDi;
        xyjkcyLOXuMB += COZxuWSBdDi;
    }

    return BZhEVBrtLgkWW;
}

bool eYGRv::wbtecSRzrZizyx(int tMGJskbpz, double XKxdYGHzr, bool YwXCSmoMrxtL)
{
    int kSpvU = -1261625247;
    double fiIjNnF = -167431.63178954343;
    double rNUFJYLolQWTJIPT = -1023781.8770404232;

    if (fiIjNnF == -577867.9579559991) {
        for (int wZYduvkcPwoGLc = 706867793; wZYduvkcPwoGLc > 0; wZYduvkcPwoGLc--) {
            tMGJskbpz += tMGJskbpz;
            kSpvU += kSpvU;
            YwXCSmoMrxtL = YwXCSmoMrxtL;
            rNUFJYLolQWTJIPT = fiIjNnF;
        }
    }

    for (int iYWXZCM = 21701829; iYWXZCM > 0; iYWXZCM--) {
        XKxdYGHzr /= XKxdYGHzr;
    }

    return YwXCSmoMrxtL;
}

eYGRv::eYGRv()
{
    this->HpwdndpUZjxTbFrn(2039819906, -696104.5617559007, string("GiSvEVcOhemFGotBeiQasPAYLbbkLwmxKeXClLcLiQDXPQWitcXoaLHgeAhgtiiRAwmLnXBgSRrsJrwXQqDscpEfSptGblrhgSMcXAjszmccYSzBenEqwxfsrBsMuoTIVqsvYPxg"));
    this->YbhvkVBMAMFKV(true);
    this->KHaXUJDWxBx(-760949.7014755906);
    this->PQFpwIgYpRIlMSA(string("rpsIljiUrMjLlLtAQfKLIrcjXQmZqyxAOyLqrxFbEZLwlGvxnqJydJeWDZDeqtqJXgvAuLYuhXSOzetlwoyDAKmZFQkJzvyDloUcBOovQVImrpZnmgYorDGUgFXYxbPbgkIIcWTxlNCDVuJDJVBlsqtkDmkrLVfZOrtQiYRVgbAEHYDXPYYbRSvAwMyeQiWkphunFmhGfOSxXYbXmehafdmPXEiPiSlpmfLuIMDUQWEjdEsSS"), 666915.7664536831, -524665.7853573543);
    this->UGBedaRAeJGJGY(-202577.17553108453, string("DmymEHGkLVYOxZFJeNIgGKPdJHtXeWNTASSahSbWXkQTjiOLNuKWGkzdNozJuxWLkLJCkJHOhZKnnQMGoAzehDQtDjyAmjwPUcZLWJcQZZTmotSGABGaCFTpuIDgAPxkySzQMTGtcSvQxgPagzdTKPfPhZREw"), -583274042);
    this->PCmHuFEcI(787221.656345651, 586835034, false);
    this->QuVSwhBgrQ(-423995.0918793963, 673008588, string("UFrpWUQxazcgkTuDwGTYOPWNXAZZYuuHEektLnCWvQHttzXjVgegXiccLHtRTgbPHVcIfIbrLRlsLoaMsXBYGVXyykxXYVPilnRQscRMcMi"), -20004.399452044585, -233850.22915670447);
    this->UkmPRbvGPMDBj(string("HiYClVhtWScMXWaYZdlwAUvFftQARTIMvCXrBwzUQAtEwHIwJrDvzMEkHlOTbVInJXVcDUoWGRGQNtWPcAdzHVViBCabBQwCNNlvJGNMznDiTpnqhWgxMsCuVcPNckXpYmavWvJsxVCalURDUnMjJDEAR"), string("fTDvjmJeVxxGtlhsJpSMSYkdMpWZvxoQITsLZAmMlelmrlsBwBVoAijvhISQQcTuJMNinYbBHUyLfDuaTDTrhcbJICvB"), string("FVMNTYWHfsNcPWYPSmSPCoVDhlgtoOW"));
    this->MBMyRlvuxvGhO(-1006040.652962357, string("HSGrqqfYWyYqPLowKYPNSggpyHpLuxFDuqCvZUuDbroXaRPEUdKfkapxMzFRrpCHWBZMhZdBldJBhYKbYJfEfuiKbDiXqqwvipOhTybJKDNxCNLrtYhvaLcubjWgfUwaocFSDNkIVBgMsZKppkHslkuPXmeVyqxxhQUcLTdnFUiYJfzUdAThEjfWOkkaUVCrjhGfoBMqZIemryCTAPlhhkuRRzHqBGCeBydspjDJkWZerFPlLxTAfg"), 502802146, 455116995);
    this->yqouHEKX(string("rYJENviWylDinxqPIXfpPyPpoevzbJNhQxSkftlUVrYzbvNhWqvcZrhSVFP"), true, -1136421276);
    this->OBLiK(-724440.2176718189, 1022669.3698923433, false);
    this->wbtecSRzrZizyx(318586788, -577867.9579559991, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UArCqfEpRnOWVO
{
public:
    bool vDODTe;
    double mZRlhJrXEapUDDJR;

    UArCqfEpRnOWVO();
    int EJcDjTXPJ(double oqQDlFlKCEgK, string IzXlPMhYaHD);
    bool itPRno(double NJCMZeBv, bool zBKwJAYqBPteFe, double NjsUV, double aBvTUIcfVn, string XcAAgsAUywyOvx);
    string RZLDL(string TktHb, bool iqkZDxfj, string xLMISUer, double dAtwvjJVKCud);
    int hRNlWjnwArhTIW(string TNwgFTkfsuObeNe, double xTdzXqYexPA, string GfsFYKRdOVeU);
    string PwwnOjQKt(double ZcOGrkOo);
    void vKnAveKZSEZTY(string CNoIbyowdOWk, int ClhexQHo, int DMqya);
    string GzhPUOQMTy(double ysYTjWzEdtSCOs, int XXzxZy, int HDGzoRMa);
    bool OQTKBxvjv(string KWtoAnsBYREiUM, double UagbE, string GlNmVZVHSMepIOIH, string wbRESEHcTqpQXI, string clNpb);
protected:
    double qrHSRnGGsv;

    int pwMOiueZecpKL();
    string KvwWtgXXCxrpa(double rcMIEWuEHade, int zxEfdvAhl);
    bool ALXrau();
    int UHrpS(string peLAIfwSsFuq, int vEJluPAMWOFDbq);
    bool qicINWAW();
private:
    int NGgbfTnpkLD;
    bool pfKVJpispnKdjx;
    bool kYkjSsEWvUZTgIlh;
    string TbqzLPFYzUhDn;
    string JrMPplImQhlUv;
    bool XekOv;

    double hXFAaRCZw(bool FKjvU, bool KJAirxtWXGpkoVyz, string Eekbv, string stDBzYN);
    string pdhJqakGJkVyvcfO(int PwtdCBqY, bool SfPCKAtDe, int RoEIQTjExfOBgjq, bool SoqUEMpOPOHOWq, int hFEnGnPHk);
    double YGGUwl(bool zFofqX);
    string mwOqVreksjrjs(double sqaJuugWqmVPx);
    bool UenkBh(int EOjNCKkPIFF, bool wbxIYUkKEYpqQnHj);
    double tJozqM(double dvIsICeyhJbgZW, bool sFtYSv, double VJgJQ, bool PBKZjnkbrWOgsj);
    void VmRRUzwhcl(bool FafPlIKEK, double mfFEaohwoerjN, string JAAtDnEoUsY);
    string lufrDKz(string sNRpAfi, string ieOsSk, int pUQAmAfdUezQe, double ClsMKoUPyDcaOVl);
};

int UArCqfEpRnOWVO::EJcDjTXPJ(double oqQDlFlKCEgK, string IzXlPMhYaHD)
{
    string TgWTA = string("nVydPcvaozpWGuSZaIOSCobfouWzUHqFProwDoXdcXdJKtUZeujMCXKoYzBAvOxuPdqBPDWcAXitMCDkWOnijlUMALWHYoAooaQKMNlwzaliqjLWBrjrBOBZvFJEFGUjWFbwtHHOoWoygJAihfwisLjNeFPrHMcWGfyjnNXvVZzXCu");
    double RFWLPfoZE = -61548.15152444024;
    double VSUHZFXG = 640553.2800402694;
    int YPRPOV = -2106970258;
    string LAXywCHMmCkiuiHW = string("zRLXFdAkRNfYWdvPraPQEXbcsQeWs");
    string PtNjXpuRUFMuEFDI = string("WzsNyJkDYBALRzKkMgUeQkBadNebDNoBTWaJMrQmgpDogNZljzQmfcuILmnmCLeyzovdHUUDOIcoGNymJiWhhcHNnvtbtenVeMhfSHPjjBKlXYCKCYHODsSk");
    bool qWlZbVN = true;
    int AxkkEwth = -1640354258;

    return AxkkEwth;
}

bool UArCqfEpRnOWVO::itPRno(double NJCMZeBv, bool zBKwJAYqBPteFe, double NjsUV, double aBvTUIcfVn, string XcAAgsAUywyOvx)
{
    bool KoFHqosxryoFJGxe = true;
    double ebIryPbULCyL = 491069.262093501;
    double IKCPqDWmwKRNMcp = 435696.39184296026;
    bool WbLuVF = true;
    string nHROIrqaCEIU = string("yTGPNOnqmLbnnETxsRFLfieaYPZitkCKDiYpsimCUMmTlzeoznwhAmYuVRjfPQaROjIYtTgEEZOIGrSUaaVWpfVlONqdTEpzKjRtqweezxjrUHKuRruYjocNORsncNfOoVbyznOKOMhbxlMLWpwlthVCVDXhINsEspSnYdHUIlFPEdJRnjKbcYsjEaYMrzpSGRHkNIweBEbfTdOMPwKHjyCSTYtDMILsgxwNwbtyIXinULSVrctSquTnYvhIVMh");
    int rhtZlzaBgjRp = -1468199171;
    bool HtIada = true;
    bool tXtaQflDaljiK = false;

    if (XcAAgsAUywyOvx < string("pySOuZjTUGrBFDMLDBhxZqVVFrFhCbZiKEQySjGmAM")) {
        for (int VzniZD = 1541180251; VzniZD > 0; VzniZD--) {
            ebIryPbULCyL += ebIryPbULCyL;
            WbLuVF = ! HtIada;
            tXtaQflDaljiK = ! KoFHqosxryoFJGxe;
        }
    }

    for (int ymETITLnZQgzQ = 2064327602; ymETITLnZQgzQ > 0; ymETITLnZQgzQ--) {
        IKCPqDWmwKRNMcp *= NJCMZeBv;
        aBvTUIcfVn -= aBvTUIcfVn;
        nHROIrqaCEIU = XcAAgsAUywyOvx;
    }

    for (int lVgOTfaCIHvTvv = 594439756; lVgOTfaCIHvTvv > 0; lVgOTfaCIHvTvv--) {
        NJCMZeBv *= NjsUV;
    }

    return tXtaQflDaljiK;
}

string UArCqfEpRnOWVO::RZLDL(string TktHb, bool iqkZDxfj, string xLMISUer, double dAtwvjJVKCud)
{
    int FLPvgPSwTvsrFYhd = -1433031487;
    int afxmlzvMYfKIdJpU = -1977673777;
    string karvsNMi = string("cWjPteLhPMnKagqqlguAwCCtwdmTKIFeSYgfGtbQeWUXJoCbRqXTlRDiJFzdoKrYaxtySutXXNuFrcTWrnGILqvfssbyPFEPpfsLpDAhyLPPqfSQLlzGupwIlpNMiNOdKeRUuDqWkeeOZthzzgUwSWhPUdZgbYODxkAgoYKrmPboCbbZMmEbkudfcNgGkEw");
    bool TrtEA = false;
    double PHpGdWRyvdEx = 289492.3495344599;
    string cXhCgczlHspVisz = string("ponrEXSDUhdVzLFPRyJBEkVGJxTZLovodIRRTUDvpPY");
    bool ohGuOhKCjoVzy = true;
    double qvnUbuVprMGmmr = -992442.7179897124;
    int memCMSbPmdK = -1462424363;

    for (int iUHJuBKxdSsp = 1485052557; iUHJuBKxdSsp > 0; iUHJuBKxdSsp--) {
        FLPvgPSwTvsrFYhd *= memCMSbPmdK;
    }

    for (int DZVSMOG = 663682159; DZVSMOG > 0; DZVSMOG--) {
        xLMISUer += karvsNMi;
    }

    for (int QdOwBmcFROyCCOE = 122422469; QdOwBmcFROyCCOE > 0; QdOwBmcFROyCCOE--) {
        qvnUbuVprMGmmr *= dAtwvjJVKCud;
        memCMSbPmdK -= FLPvgPSwTvsrFYhd;
        afxmlzvMYfKIdJpU /= memCMSbPmdK;
    }

    return cXhCgczlHspVisz;
}

int UArCqfEpRnOWVO::hRNlWjnwArhTIW(string TNwgFTkfsuObeNe, double xTdzXqYexPA, string GfsFYKRdOVeU)
{
    int nGaOaGdVnOF = -122455631;
    double JhEChSUlsQQJh = 300062.69837133266;
    bool GTjSnELk = false;

    if (GfsFYKRdOVeU >= string("GeKniWDfuVHfTUCXQfQx")) {
        for (int ILNGmwhkD = 565500202; ILNGmwhkD > 0; ILNGmwhkD--) {
            continue;
        }
    }

    if (xTdzXqYexPA > 389697.7464341036) {
        for (int NmykdTa = 2115741897; NmykdTa > 0; NmykdTa--) {
            JhEChSUlsQQJh = JhEChSUlsQQJh;
        }
    }

    for (int rduemfmgXhAQZW = 414242054; rduemfmgXhAQZW > 0; rduemfmgXhAQZW--) {
        continue;
    }

    for (int WGaXBBlHI = 796506143; WGaXBBlHI > 0; WGaXBBlHI--) {
        xTdzXqYexPA += xTdzXqYexPA;
        JhEChSUlsQQJh *= xTdzXqYexPA;
        GTjSnELk = GTjSnELk;
        nGaOaGdVnOF = nGaOaGdVnOF;
    }

    if (GTjSnELk == false) {
        for (int lZfIj = 1891287374; lZfIj > 0; lZfIj--) {
            xTdzXqYexPA *= JhEChSUlsQQJh;
            TNwgFTkfsuObeNe = GfsFYKRdOVeU;
        }
    }

    for (int KiDNlkwnIAfCEAxg = 247775556; KiDNlkwnIAfCEAxg > 0; KiDNlkwnIAfCEAxg--) {
        JhEChSUlsQQJh += JhEChSUlsQQJh;
        nGaOaGdVnOF = nGaOaGdVnOF;
        GfsFYKRdOVeU += TNwgFTkfsuObeNe;
        GfsFYKRdOVeU = TNwgFTkfsuObeNe;
    }

    for (int qIyxPNUOpBTA = 1116612; qIyxPNUOpBTA > 0; qIyxPNUOpBTA--) {
        TNwgFTkfsuObeNe += TNwgFTkfsuObeNe;
    }

    return nGaOaGdVnOF;
}

string UArCqfEpRnOWVO::PwwnOjQKt(double ZcOGrkOo)
{
    bool HrkWGUxhhxfoVIV = false;

    for (int hgAnEmtQAKwu = 979147062; hgAnEmtQAKwu > 0; hgAnEmtQAKwu--) {
        ZcOGrkOo /= ZcOGrkOo;
        ZcOGrkOo -= ZcOGrkOo;
    }

    for (int qEVXmteaSwNm = 1318463168; qEVXmteaSwNm > 0; qEVXmteaSwNm--) {
        ZcOGrkOo -= ZcOGrkOo;
        HrkWGUxhhxfoVIV = HrkWGUxhhxfoVIV;
        HrkWGUxhhxfoVIV = HrkWGUxhhxfoVIV;
    }

    return string("mBTeUchDLEQLGNmpdPUCKajyAuSbaMNYoCvnGWMauukrPhoffnUxluraXnWNtMTTcDZdlKWgmqRLCWcOKcqKKajWICFyMrGFQNyzXjvMKibJsiqieIhHKGcELYvZhpTLikxwTSHCtoHkbYmPxKPnYj");
}

void UArCqfEpRnOWVO::vKnAveKZSEZTY(string CNoIbyowdOWk, int ClhexQHo, int DMqya)
{
    double sHIfJhMyFsbkgwZm = -536406.5466887312;
    int PxkvOBwQVgPryn = -344879141;
    string aafRgLrk = string("pCqkHqeqdKYivhojLdXuyeQYbPZDxKaqzZTjDZcjQmbRpINLuMAekbLDWwxAaKQPewftTSJJxyCHxBlOQfYlnATVRQBskbIYkbuY");
    string NAHMWWiRFRg = string("OqWGvymvjAVBiOAZnAoBQDTqkGjEXfaJyaMtqhJBfyczIFfxEnwUSQJXJPLAZJtRALoifHGCkJLfpHQWLtiWTUmJmnBdcefwsUfKHVWiNSOUtjlptjfLsSjeZesugiLLEQuLtyVCbrYBrsInXJspFqPqIcqjMoICaVaoKgNSJUlDNcIUwMFhxgQLYG");
    int rjGELJsLdH = 1501017456;
    bool oIqmzhDbdcR = true;
    int ZarZU = 198634357;
    int hQffycnF = 824035399;
    string SKgZrTOblYzYdR = string("ClkCVaVlfxBLUkCiBnWKyhLseIHhJIJZPNEJKEDHcHSwumAEBvKvYlHneiMjvRaXAhbScccbmHftzyQxFOKbTGAaSagl");
    string SrQcwXy = string("PcyZSBTcCbwfqivctOdKipoDpLiUKYOrgyCMmAUnDwFdPiHQcOCCBRNZLzABmLlVJdBJNaomvmyDmblhneDHUltWrIcXPVITOkAORfGRqHoZgvcNsBYCHaVWaiiOYrTHkZcPnshAAhQaVGVZMjTpEaSybLCrNNKbt");

    if (sHIfJhMyFsbkgwZm < -536406.5466887312) {
        for (int wmUGXVJkbh = 417799431; wmUGXVJkbh > 0; wmUGXVJkbh--) {
            aafRgLrk = aafRgLrk;
            PxkvOBwQVgPryn = rjGELJsLdH;
        }
    }

    for (int ZLdSloYpftQ = 177010355; ZLdSloYpftQ > 0; ZLdSloYpftQ--) {
        ZarZU -= DMqya;
    }

    for (int VmMBMcm = 346351291; VmMBMcm > 0; VmMBMcm--) {
        continue;
    }

    if (DMqya == 2035187286) {
        for (int FZSsfhUx = 1509490753; FZSsfhUx > 0; FZSsfhUx--) {
            continue;
        }
    }
}

string UArCqfEpRnOWVO::GzhPUOQMTy(double ysYTjWzEdtSCOs, int XXzxZy, int HDGzoRMa)
{
    string UivFowWzldG = string("cmJYxNKSQftgGxfbqTwjibcCsNhIUqidEzkLwOghlWXFqtzuOpmpKAyoLdMrbSZuSPYhCFAVlyLWOmMMEvHtEOWMdWeNfSuZsoLERMOjlyaHXAhzoEXmlamgirZGUxQTuRDGLTebqrvbZFcRuYAnUTENkgjHnhpPjazTEdllWqfceWPSKySEWypSDTqavEhsPHcdcFelcllMSHoQXcUECxWDDydYRSBgKTTrFaBjfZDuuBfmUCHk");
    int zQDnWVWvWMaxpY = -1998034591;

    for (int zqiZyYPZs = 1600409015; zqiZyYPZs > 0; zqiZyYPZs--) {
        HDGzoRMa = XXzxZy;
        ysYTjWzEdtSCOs -= ysYTjWzEdtSCOs;
        HDGzoRMa += XXzxZy;
    }

    for (int IpxpgDiN = 499139319; IpxpgDiN > 0; IpxpgDiN--) {
        HDGzoRMa *= zQDnWVWvWMaxpY;
        XXzxZy += zQDnWVWvWMaxpY;
        XXzxZy /= XXzxZy;
    }

    for (int QvxLrVUlhVPBQOZ = 1362774137; QvxLrVUlhVPBQOZ > 0; QvxLrVUlhVPBQOZ--) {
        continue;
    }

    if (HDGzoRMa <= 340460742) {
        for (int ZNPQVzDjFF = 1381308834; ZNPQVzDjFF > 0; ZNPQVzDjFF--) {
            zQDnWVWvWMaxpY += zQDnWVWvWMaxpY;
        }
    }

    return UivFowWzldG;
}

bool UArCqfEpRnOWVO::OQTKBxvjv(string KWtoAnsBYREiUM, double UagbE, string GlNmVZVHSMepIOIH, string wbRESEHcTqpQXI, string clNpb)
{
    int oMXFGgN = 417463221;
    double tjLUmPdKCwTqf = -399211.4352277623;
    double yLBXZsazcNF = -415014.0616772377;
    bool OMlcyjBvBrwoCnE = true;

    if (wbRESEHcTqpQXI > string("eAjOGXcRKlKHcukFitjYDnZzNnUlXbAopdJIlGnBsgiYfPNLZzKCQU")) {
        for (int krEBJPQscmXfFw = 1939286522; krEBJPQscmXfFw > 0; krEBJPQscmXfFw--) {
            tjLUmPdKCwTqf /= UagbE;
            tjLUmPdKCwTqf = tjLUmPdKCwTqf;
        }
    }

    if (GlNmVZVHSMepIOIH == string("eAjOGXcRKlKHcukFitjYDnZzNnUlXbAopdJIlGnBsgiYfPNLZzKCQU")) {
        for (int uUAiEi = 1110805187; uUAiEi > 0; uUAiEi--) {
            UagbE = yLBXZsazcNF;
            clNpb += clNpb;
            clNpb += KWtoAnsBYREiUM;
            tjLUmPdKCwTqf /= tjLUmPdKCwTqf;
        }
    }

    return OMlcyjBvBrwoCnE;
}

int UArCqfEpRnOWVO::pwMOiueZecpKL()
{
    double hDXalGPGkSw = 274084.37077129976;
    bool fivysKqvs = true;
    bool dtjKumNqcpAp = false;
    bool iRiIwmzxSK = false;
    bool BMNuM = true;
    string QpTHCsjvirncrowf = string("hdapyrvKzKnRVuUaVpvtBJzPMVNcVbqPmJNsUnWtkONKHgIhDxUgxceljPwkFCEAEqqCaEVRmv");
    bool tKeSCXO = true;
    string WjbjhzgcsJzfmCUD = string("xbWZsiYCWMhynnPmbMajSOtcQeJjJeGILihRnWgIVzwJieibuvxtYSlAzNWDPdsUlXnPCLnWhALblEJTuMutmEgmXvsLaTOzHRHusGGpvyIAjxBKUsqzgrUpoXAqYlmajHSBuvGhBOeqFOf");

    if (BMNuM == false) {
        for (int nHALqUrNNEmSXJw = 1885755358; nHALqUrNNEmSXJw > 0; nHALqUrNNEmSXJw--) {
            dtjKumNqcpAp = BMNuM;
            tKeSCXO = ! iRiIwmzxSK;
            tKeSCXO = ! BMNuM;
            iRiIwmzxSK = ! tKeSCXO;
            QpTHCsjvirncrowf += QpTHCsjvirncrowf;
        }
    }

    for (int NWsnogwM = 1434062483; NWsnogwM > 0; NWsnogwM--) {
        fivysKqvs = dtjKumNqcpAp;
        tKeSCXO = ! dtjKumNqcpAp;
        BMNuM = BMNuM;
    }

    for (int priNMXnIwbLhY = 211232304; priNMXnIwbLhY > 0; priNMXnIwbLhY--) {
        fivysKqvs = ! tKeSCXO;
        tKeSCXO = tKeSCXO;
        WjbjhzgcsJzfmCUD += WjbjhzgcsJzfmCUD;
        tKeSCXO = ! BMNuM;
    }

    for (int eOxuvwlYGbOuHcQ = 714913859; eOxuvwlYGbOuHcQ > 0; eOxuvwlYGbOuHcQ--) {
        dtjKumNqcpAp = ! iRiIwmzxSK;
    }

    if (iRiIwmzxSK == true) {
        for (int WaaJgY = 1143590128; WaaJgY > 0; WaaJgY--) {
            WjbjhzgcsJzfmCUD += WjbjhzgcsJzfmCUD;
            BMNuM = ! tKeSCXO;
            iRiIwmzxSK = ! tKeSCXO;
            fivysKqvs = ! fivysKqvs;
        }
    }

    return 970113885;
}

string UArCqfEpRnOWVO::KvwWtgXXCxrpa(double rcMIEWuEHade, int zxEfdvAhl)
{
    double kpYqJTLg = 96862.89281867119;

    if (kpYqJTLg > -855653.6284088235) {
        for (int jzponNYCJaVWi = 739244818; jzponNYCJaVWi > 0; jzponNYCJaVWi--) {
            kpYqJTLg = rcMIEWuEHade;
        }
    }

    for (int HKLrfkebu = 165331119; HKLrfkebu > 0; HKLrfkebu--) {
        zxEfdvAhl *= zxEfdvAhl;
        zxEfdvAhl += zxEfdvAhl;
        kpYqJTLg -= kpYqJTLg;
        rcMIEWuEHade -= kpYqJTLg;
    }

    if (rcMIEWuEHade != 96862.89281867119) {
        for (int EzZLQrUcbQAy = 952402632; EzZLQrUcbQAy > 0; EzZLQrUcbQAy--) {
            rcMIEWuEHade /= rcMIEWuEHade;
            kpYqJTLg -= rcMIEWuEHade;
            kpYqJTLg -= rcMIEWuEHade;
            zxEfdvAhl /= zxEfdvAhl;
            kpYqJTLg *= rcMIEWuEHade;
            rcMIEWuEHade += rcMIEWuEHade;
        }
    }

    if (kpYqJTLg > 96862.89281867119) {
        for (int DgtIS = 1283094612; DgtIS > 0; DgtIS--) {
            kpYqJTLg += rcMIEWuEHade;
            rcMIEWuEHade = rcMIEWuEHade;
            rcMIEWuEHade = rcMIEWuEHade;
            kpYqJTLg = rcMIEWuEHade;
        }
    }

    if (kpYqJTLg < 96862.89281867119) {
        for (int lQKnfNBgxoNrCUCn = 1109008853; lQKnfNBgxoNrCUCn > 0; lQKnfNBgxoNrCUCn--) {
            rcMIEWuEHade += rcMIEWuEHade;
        }
    }

    return string("BETzHQUzIpCVZICcqhGyvZNlhxDZtyEKnsMhWkcoWnoLEAmZzkvBeupHmOXxUOJpQljsw");
}

bool UArCqfEpRnOWVO::ALXrau()
{
    bool GPHhKJNPBzK = false;
    int jWroIwDvFwilQfvx = 1212313836;
    bool iscAq = true;
    bool BbixzOBtD = false;
    double zhrgXfufT = -989881.8846203053;
    bool uwSxXqizVBeJae = false;

    if (GPHhKJNPBzK != false) {
        for (int cXsykTLhgzdaQ = 570597956; cXsykTLhgzdaQ > 0; cXsykTLhgzdaQ--) {
            continue;
        }
    }

    for (int oZOivXPNeDPCnQes = 1484639650; oZOivXPNeDPCnQes > 0; oZOivXPNeDPCnQes--) {
        jWroIwDvFwilQfvx -= jWroIwDvFwilQfvx;
        iscAq = BbixzOBtD;
        iscAq = ! uwSxXqizVBeJae;
    }

    return uwSxXqizVBeJae;
}

int UArCqfEpRnOWVO::UHrpS(string peLAIfwSsFuq, int vEJluPAMWOFDbq)
{
    bool QWQfcFpQMDOwIRuK = true;
    string ToIZTcWlggeTHaWY = string("esXPYaWhvumHGrtQRytnVleIJIlGNugURLnizAJrWOjMlmTQJbOuaNaPCHznxiMxSWVNeIIBNRujJGgvHchZstpPHtcjQCsPYpZfKM");
    string zKEVrRvdOoB = string("UOJyrctbHIqznyaQfMPesOPbJZXDLTR");

    if (zKEVrRvdOoB < string("esXPYaWhvumHGrtQRytnVleIJIlGNugURLnizAJrWOjMlmTQJbOuaNaPCHznxiMxSWVNeIIBNRujJGgvHchZstpPHtcjQCsPYpZfKM")) {
        for (int BJiGb = 1950996562; BJiGb > 0; BJiGb--) {
            ToIZTcWlggeTHaWY = zKEVrRvdOoB;
        }
    }

    if (zKEVrRvdOoB <= string("BTFzipTDWLfeVCzLDCAGFMxAhNDQCmCdTPQgmzRVHcAvlJEZPNfPvYQoiRoRWKtNGVEQlNcjcBZWnVtsBeYyxxvIZpqsHviZjzVYVMEygaersdBlH")) {
        for (int ZUQqGEhpRMrh = 214815078; ZUQqGEhpRMrh > 0; ZUQqGEhpRMrh--) {
            ToIZTcWlggeTHaWY += ToIZTcWlggeTHaWY;
            zKEVrRvdOoB += peLAIfwSsFuq;
            zKEVrRvdOoB += zKEVrRvdOoB;
            vEJluPAMWOFDbq /= vEJluPAMWOFDbq;
        }
    }

    for (int ObUNfpfaNkdS = 1676534561; ObUNfpfaNkdS > 0; ObUNfpfaNkdS--) {
        ToIZTcWlggeTHaWY = ToIZTcWlggeTHaWY;
        zKEVrRvdOoB += ToIZTcWlggeTHaWY;
        QWQfcFpQMDOwIRuK = QWQfcFpQMDOwIRuK;
        peLAIfwSsFuq += peLAIfwSsFuq;
        peLAIfwSsFuq = ToIZTcWlggeTHaWY;
    }

    return vEJluPAMWOFDbq;
}

bool UArCqfEpRnOWVO::qicINWAW()
{
    bool urTqZMoSz = false;
    string swBbBJwVms = string("hvifXUScOWYOtW");
    bool HraMbY = false;
    bool lpbYyzlMswKzlhMW = true;
    double BfbCKuSLqcz = -125532.02797514679;
    int VcKdGyK = -314292522;

    for (int NtnHBAPi = 2119429887; NtnHBAPi > 0; NtnHBAPi--) {
        swBbBJwVms += swBbBJwVms;
        HraMbY = ! urTqZMoSz;
        swBbBJwVms = swBbBJwVms;
    }

    if (HraMbY == false) {
        for (int znNKZ = 243728200; znNKZ > 0; znNKZ--) {
            urTqZMoSz = ! HraMbY;
            HraMbY = ! urTqZMoSz;
        }
    }

    for (int jmSXiqDprAsfzt = 1285438735; jmSXiqDprAsfzt > 0; jmSXiqDprAsfzt--) {
        HraMbY = lpbYyzlMswKzlhMW;
        lpbYyzlMswKzlhMW = HraMbY;
        lpbYyzlMswKzlhMW = ! urTqZMoSz;
    }

    return lpbYyzlMswKzlhMW;
}

double UArCqfEpRnOWVO::hXFAaRCZw(bool FKjvU, bool KJAirxtWXGpkoVyz, string Eekbv, string stDBzYN)
{
    bool wNjiEbgKkIkTi = false;
    bool JbTHUaRrkH = false;
    int adcCkgfISkSFo = -2081366327;

    if (KJAirxtWXGpkoVyz == false) {
        for (int ydkahNzfrncH = 1998249659; ydkahNzfrncH > 0; ydkahNzfrncH--) {
            KJAirxtWXGpkoVyz = ! FKjvU;
            FKjvU = ! JbTHUaRrkH;
            KJAirxtWXGpkoVyz = FKjvU;
            wNjiEbgKkIkTi = ! wNjiEbgKkIkTi;
        }
    }

    if (JbTHUaRrkH == false) {
        for (int zgSfaUNZrviVkjk = 1179846593; zgSfaUNZrviVkjk > 0; zgSfaUNZrviVkjk--) {
            Eekbv += Eekbv;
        }
    }

    if (KJAirxtWXGpkoVyz == false) {
        for (int hDIJlvWRzj = 1198745664; hDIJlvWRzj > 0; hDIJlvWRzj--) {
            stDBzYN = Eekbv;
            KJAirxtWXGpkoVyz = ! FKjvU;
        }
    }

    for (int mmlLoJY = 2117236142; mmlLoJY > 0; mmlLoJY--) {
        wNjiEbgKkIkTi = ! FKjvU;
    }

    return 198306.50269020096;
}

string UArCqfEpRnOWVO::pdhJqakGJkVyvcfO(int PwtdCBqY, bool SfPCKAtDe, int RoEIQTjExfOBgjq, bool SoqUEMpOPOHOWq, int hFEnGnPHk)
{
    double fJsfIgPtiopJvQ = 877988.7712611672;
    double dUpLrCEYrUe = 293723.57894156076;
    int OtPArHiGX = 1521112209;
    bool zxwIWRSN = true;
    bool bxXWvfuMb = false;
    bool xuRiAjZXUiTmRA = false;
    double PoAdOIzfvoqrak = 149790.65286909175;
    double ZrTnuH = 687356.5406044031;
    double UoorFCM = 240362.8685836704;

    if (PoAdOIzfvoqrak == 149790.65286909175) {
        for (int pmaUESkjo = 1883145116; pmaUESkjo > 0; pmaUESkjo--) {
            SoqUEMpOPOHOWq = bxXWvfuMb;
            SfPCKAtDe = ! xuRiAjZXUiTmRA;
        }
    }

    for (int NIRXHwMwYvCAmo = 425838253; NIRXHwMwYvCAmo > 0; NIRXHwMwYvCAmo--) {
        continue;
    }

    return string("FVApNnIpCWoxCurJdCjHclLFtTnmTeEUjAVfaEkTOlGZFhyCFWdpQNMrZshdnFqdsUeaFfVlzqcPNyUSdKAjXXbMbAEaXdNBrNIDAUjiHSdCgDDGbudYHgGdfEFKIxlumyRDIfIJLZhvuteLoraZbFWMyvIqpFTaPbtESzQxeSUWrbTPGKiUPHFpWKxCmsBSWXOHqPHUYnRVEdyFlWHvwRoaTquwukS");
}

double UArCqfEpRnOWVO::YGGUwl(bool zFofqX)
{
    bool UvbnfwumNjHa = false;
    int ANIfMCH = 328382184;
    double DsepQJCgVoij = -203746.38011088775;
    bool WwobSzWgu = false;
    double VtMzDuRyS = -854250.0647909255;
    int HixUfuM = 1724005085;

    for (int dvZsmfJ = 1847133380; dvZsmfJ > 0; dvZsmfJ--) {
        continue;
    }

    for (int RHHdyvAqdnoux = 1977367919; RHHdyvAqdnoux > 0; RHHdyvAqdnoux--) {
        continue;
    }

    for (int gwPpxwfKwskH = 2104649779; gwPpxwfKwskH > 0; gwPpxwfKwskH--) {
        HixUfuM *= ANIfMCH;
        zFofqX = UvbnfwumNjHa;
        WwobSzWgu = WwobSzWgu;
    }

    for (int WtROWzBL = 1494242920; WtROWzBL > 0; WtROWzBL--) {
        continue;
    }

    for (int qqLwAdMw = 1331090351; qqLwAdMw > 0; qqLwAdMw--) {
        ANIfMCH /= ANIfMCH;
        HixUfuM -= HixUfuM;
        DsepQJCgVoij -= DsepQJCgVoij;
        DsepQJCgVoij += VtMzDuRyS;
        DsepQJCgVoij = DsepQJCgVoij;
    }

    for (int jGUOiTUfyJEagf = 1773634918; jGUOiTUfyJEagf > 0; jGUOiTUfyJEagf--) {
        zFofqX = ! zFofqX;
        UvbnfwumNjHa = WwobSzWgu;
    }

    return VtMzDuRyS;
}

string UArCqfEpRnOWVO::mwOqVreksjrjs(double sqaJuugWqmVPx)
{
    string aAHhlHtbhHBqh = string("bdvetebeWvaKEIbRyhZfGlAtRxOcQRLatqFtkIzIzrHNAGIKdAudLmRXVwjZVnLvqirpzFqehKnbaGALXD");
    bool LntLMRTfA = false;
    bool snlxXSut = true;
    bool wXmVPPokujTdYF = false;
    string lRXuIfpQYQ = string("iRTnbqEkoIHfPmgbahTCnoThJZxwzWhRosDrcQZePbITlXgxmwZdJzClekBmGrNjpLfXgqOKqLDubnvMDVyLjdcYvbQGsOXSUXWsiagXMFoXZUHPZuZstTTijAfxPjjyUyUmJBDMuvkvsvdOHPEbOMawbfFNxftnNOPnUVwZsVSbXEelvOKJWKtlLjiMQFxcnzpLyBTiTSEGgWmLNxJSIbOhLfgSLpyOiNWSOKwIQeVYoNNFURvQk");
    string BdzLWZmFCo = string("tAKjktlDcvHzbuoonjVADkWdLHhPJadpTahBQKaaZOmwcoCtpwlBnisRizBsFYZxAcQGiQogQAZbgnOpgFBPbCyPCfvLJNpamvTQujsSvsLYoIoMAYhdHfYwhBAxqEYSOynteeqqfoKYiORxGEUNZDAidmleqpyRexDFLqkZMHRYVJZmqtkcglPvUI");
    int tDllm = 1014254458;

    for (int NuSsTGxYmWVkNW = 348343023; NuSsTGxYmWVkNW > 0; NuSsTGxYmWVkNW--) {
        BdzLWZmFCo = aAHhlHtbhHBqh;
    }

    for (int vZNXRQh = 1623943778; vZNXRQh > 0; vZNXRQh--) {
        tDllm /= tDllm;
    }

    return BdzLWZmFCo;
}

bool UArCqfEpRnOWVO::UenkBh(int EOjNCKkPIFF, bool wbxIYUkKEYpqQnHj)
{
    string GORvniAfh = string("vLdSHHUBNaydTqkugqsTHJtVWkHXZiAkTsTCRAsHFQwHaVCOxepRceMPPmZxqdgwvVrhAQonKRwSdgXkrkJpSsDBIvcKxpMcHPbkwkoISwoevUgnoLUzOUgxguNHxGnVUfbjsNVcrYJWNtEMJAGoHRM");
    string ZpQMFjL = string("kRfhuOkZMbjudJTAjlRXJfNSxJiFlimBcFEyVsWCbbfdBpJlhTuBWIa");
    double KLPRev = -1008417.4429271377;
    double uWCqDWr = -474969.72909912723;
    int WQVVjWlfmJJ = 1488236235;

    for (int QFZvJxNQ = 1350249133; QFZvJxNQ > 0; QFZvJxNQ--) {
        continue;
    }

    if (ZpQMFjL < string("vLdSHHUBNaydTqkugqsTHJtVWkHXZiAkTsTCRAsHFQwHaVCOxepRceMPPmZxqdgwvVrhAQonKRwSdgXkrkJpSsDBIvcKxpMcHPbkwkoISwoevUgnoLUzOUgxguNHxGnVUfbjsNVcrYJWNtEMJAGoHRM")) {
        for (int nTbPOpKtuyv = 720876190; nTbPOpKtuyv > 0; nTbPOpKtuyv--) {
            wbxIYUkKEYpqQnHj = wbxIYUkKEYpqQnHj;
        }
    }

    for (int mYtoQADoMcPtHj = 348536937; mYtoQADoMcPtHj > 0; mYtoQADoMcPtHj--) {
        GORvniAfh += ZpQMFjL;
        GORvniAfh = GORvniAfh;
        KLPRev -= uWCqDWr;
    }

    if (ZpQMFjL != string("kRfhuOkZMbjudJTAjlRXJfNSxJiFlimBcFEyVsWCbbfdBpJlhTuBWIa")) {
        for (int zNxxq = 2063680313; zNxxq > 0; zNxxq--) {
            EOjNCKkPIFF -= EOjNCKkPIFF;
        }
    }

    for (int dDQzv = 1280248924; dDQzv > 0; dDQzv--) {
        WQVVjWlfmJJ /= WQVVjWlfmJJ;
        ZpQMFjL = ZpQMFjL;
    }

    if (EOjNCKkPIFF > -1876927921) {
        for (int ImOKlrhMZNWSzVs = 1028124583; ImOKlrhMZNWSzVs > 0; ImOKlrhMZNWSzVs--) {
            EOjNCKkPIFF -= WQVVjWlfmJJ;
            KLPRev += uWCqDWr;
            WQVVjWlfmJJ /= WQVVjWlfmJJ;
        }
    }

    for (int xDlaIzpzKMiGAZ = 734752643; xDlaIzpzKMiGAZ > 0; xDlaIzpzKMiGAZ--) {
        EOjNCKkPIFF += WQVVjWlfmJJ;
        uWCqDWr += uWCqDWr;
        wbxIYUkKEYpqQnHj = ! wbxIYUkKEYpqQnHj;
    }

    return wbxIYUkKEYpqQnHj;
}

double UArCqfEpRnOWVO::tJozqM(double dvIsICeyhJbgZW, bool sFtYSv, double VJgJQ, bool PBKZjnkbrWOgsj)
{
    int qzvtWqCiLQm = 1509582477;
    double MiiOMDFC = 389495.2494651791;
    string ifJvmrQnPg = string("GRQqwpGKOLminQmhMUvpkEVPgpHwUimRudVliDkBNJVNPYvXdBOsVKXOSRhNTZVdgXzwFzEKujFzgbZrbCcJWP");
    bool LTNbL = true;

    for (int abiIylmpHVktFKA = 1536973631; abiIylmpHVktFKA > 0; abiIylmpHVktFKA--) {
        continue;
    }

    for (int seXtewfeOJtJ = 2070623154; seXtewfeOJtJ > 0; seXtewfeOJtJ--) {
        sFtYSv = ! sFtYSv;
    }

    if (PBKZjnkbrWOgsj != false) {
        for (int fXuZnbCLR = 320107747; fXuZnbCLR > 0; fXuZnbCLR--) {
            LTNbL = LTNbL;
            dvIsICeyhJbgZW *= MiiOMDFC;
            LTNbL = PBKZjnkbrWOgsj;
        }
    }

    for (int xGxDAhMOB = 720990407; xGxDAhMOB > 0; xGxDAhMOB--) {
        continue;
    }

    return MiiOMDFC;
}

void UArCqfEpRnOWVO::VmRRUzwhcl(bool FafPlIKEK, double mfFEaohwoerjN, string JAAtDnEoUsY)
{
    double UxcjfXfdvnAoh = -276624.28889078787;
    bool gkIBGWMmAPxgGJFW = true;
    bool LpSCETladljoQ = false;
    double SKPtQq = -84079.84704904894;
    double DvSOhrjSgFySsZmX = -892583.3995152123;
    string oaaDEtNKsWNP = string("slZbKabXdBQzVTnOyYbWIetoAsTmZbxNvYxMvKI");

    if (SKPtQq >= 738430.3363060937) {
        for (int xJfIWNsUmQ = 53750843; xJfIWNsUmQ > 0; xJfIWNsUmQ--) {
            JAAtDnEoUsY += oaaDEtNKsWNP;
            JAAtDnEoUsY += oaaDEtNKsWNP;
        }
    }
}

string UArCqfEpRnOWVO::lufrDKz(string sNRpAfi, string ieOsSk, int pUQAmAfdUezQe, double ClsMKoUPyDcaOVl)
{
    bool mIryVZhS = false;
    bool agbqx = false;
    int jTzbykqWYL = 955910402;
    double FRKqPRsBVvBDpt = -994671.53176448;
    double UVHdoFkWpEmn = -1021593.9334854368;

    for (int OiZBcwQ = 507519908; OiZBcwQ > 0; OiZBcwQ--) {
        FRKqPRsBVvBDpt -= ClsMKoUPyDcaOVl;
        jTzbykqWYL += pUQAmAfdUezQe;
        pUQAmAfdUezQe += jTzbykqWYL;
        UVHdoFkWpEmn -= FRKqPRsBVvBDpt;
        ClsMKoUPyDcaOVl += UVHdoFkWpEmn;
        UVHdoFkWpEmn -= ClsMKoUPyDcaOVl;
    }

    for (int FBYlNujAzAnJOXyh = 588833923; FBYlNujAzAnJOXyh > 0; FBYlNujAzAnJOXyh--) {
        pUQAmAfdUezQe -= jTzbykqWYL;
        UVHdoFkWpEmn /= ClsMKoUPyDcaOVl;
        ClsMKoUPyDcaOVl -= ClsMKoUPyDcaOVl;
        ieOsSk = sNRpAfi;
        mIryVZhS = ! agbqx;
    }

    return ieOsSk;
}

UArCqfEpRnOWVO::UArCqfEpRnOWVO()
{
    this->EJcDjTXPJ(147566.58391906312, string("lprPhhuXuXpFtOMPSkalgxibAoyYhWeMlIHPTgzdakeZhmITgJjJXccrPJcUTjGWBxvonDZNBtojHngJUmZiKAYTLAHramrHVGfvllWsdNdybnIfVQqiEiHXsgcVOOgURUkbFOWfkisXigAECpipAyUGRFHvKvjqwqgaAtCmApLLiVbFkEHuXpz"));
    this->itPRno(108350.57922367922, true, 328935.43097042374, 13312.384108839513, string("pySOuZjTUGrBFDMLDBhxZqVVFrFhCbZiKEQySjGmAM"));
    this->RZLDL(string("eoKGxHsgrFfbjYjcHsIDeTISCfYsEWAMIwYvRvVlSbzVzfpsUSmLqNZOazEiSHuqgQbFUoHXPJQwPypwUHcOgwOsanrjilHcPgtrIMOXRpNqeNWUKKtEGsOwEWEeEYSQsSaoqyQkSwmZCfoTAFjggEtgllNavTDdnBnYWYVNJSqGOlYFpKTOwwQDSXfxJCGLGQsImZGppDmohdoYBhdJjmtyFwmgeZxrRXkIsfuTNWxNAsiDlWP"), true, string("dHdOINVfkrPNeCNbkZWLQOoNWUUHcUSUnnclCapfwJpAdRlrCDEQYGIvFJRdcEWtjBoLEUdnhFbsROqXLuxTDnHWylWLfntBANzRxZfKpKVwTBhiqFLDlafIIRQHZJFWZJUXXPjzkFxENGUYkjFMeMskcXWWQ"), 203728.71244899608);
    this->hRNlWjnwArhTIW(string("GeKniWDfuVHfTUCXQfQx"), 389697.7464341036, string("YorKcRHmgBPIobXIUWabeKIIzvDZAlVYprCiQwDPvtyqSPTQTlSWLAKaTSCKgtHeDODlIzlAriMolWXgIvWGOPXHKXwRMGFCmkHBHRUvlxCtyydrvqFBZUNqWVsUZWcmeFGWraixmMuBVOnIuawXypZGbVgfwHodFQAoFG"));
    this->PwwnOjQKt(862233.704852095);
    this->vKnAveKZSEZTY(string("yQvFHPQCJuoLRjZLHaicyAaCjLHdiAZmTQUtIAkgKYYgGdEBGWS"), 1705036293, 2035187286);
    this->GzhPUOQMTy(-50221.10521232294, 2078658780, 340460742);
    this->OQTKBxvjv(string("kzCFhWFkPJGrgIxCwcaiWWdvDWfXNHSjzKKrhTdPhMAtcPVEbYUMjTGAnelIhPGJhPVANOVgoIOQoDEEmnBxOJvVnEN"), 506585.48491571186, string("FtybRVlOwhmilvssFOWoLoyvDFPIfOYrxFikXrHFeqADZlypRsvqtYGlfzQjhWbJIzYVGs"), string("eAjOGXcRKlKHcukFitjYDnZzNnUlXbAopdJIlGnBsgiYfPNLZzKCQU"), string("PngsbvOOVXTUgeSXKcAkjoUOdPWygoGadsE"));
    this->pwMOiueZecpKL();
    this->KvwWtgXXCxrpa(-855653.6284088235, -1074704252);
    this->ALXrau();
    this->UHrpS(string("BTFzipTDWLfeVCzLDCAGFMxAhNDQCmCdTPQgmzRVHcAvlJEZPNfPvYQoiRoRWKtNGVEQlNcjcBZWnVtsBeYyxxvIZpqsHviZjzVYVMEygaersdBlH"), -1618349906);
    this->qicINWAW();
    this->hXFAaRCZw(true, false, string("fPrOUotBmPotQDG"), string("mKFTlhlGhoTuYifXtNvFOnyjxmVfyBNdqWIOLWKCneFlIlQGXmgAmslMgEllfeHmJCanaYaUFyONnanXMMOVfhecnoSQdyuhjcDrOvJlpJCXAhAUIjCwpbknliQnmaEXKaTMDqjcObKfAnIEmdawDBJRabunevbMOvojXDGUqujFBpOBNTCyTwUdMhUFbUawNUbGmAOUCROCVUSgCOJsjjDNkeAgylnhzR"));
    this->pdhJqakGJkVyvcfO(285110153, false, -895554735, false, -1803884109);
    this->YGGUwl(false);
    this->mwOqVreksjrjs(-600520.1599578408);
    this->UenkBh(-1876927921, false);
    this->tJozqM(584792.6323836077, false, 815112.9764725311, false);
    this->VmRRUzwhcl(true, 738430.3363060937, string("koRRuEKnXmhHwQpNIZkKfuaiZZYxyhlqSFFqfINuSgbafjPCegKiaRHbSbvBAJNCrTqfnTxRZErPDVRXHrlmEDLlvwUqnAXdzHWSyJggquamWSmFgsmcqakDJtLUVLDqbqYMQbjXZsJtfTXUFhyERGnhxQpzzcnDGdmXufHMZNVpoRNJhcYXjNTcmvcmODotzIcvyctjzoZrmhnXKlcjZQkdf"));
    this->lufrDKz(string("jMu"), string("HeIyMIPsFbRVkihlhexXewFrxfOorwbSGzsSRAvEawWGqLhQUtWdLtYQyIhZIuqBjtwgsDTIoBwvmOCnnaTiqzYPXIQXGNPwgUsHZnqrZNXXJqgIRASNfAcAQdfeXaWqTfFjUgwahtOoEwrO"), -733251436, -912492.4030644408);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ThGfWqQT
{
public:
    string yLPXTqLndVWMt;
    string xVMZqq;
    int nVTcWYWbbRm;

    ThGfWqQT();
    int rPAMf(string pXYksGuZ, int NuUxpMHq, int FnOgLiRNOAxO);
protected:
    double fASqmE;
    bool asclnMjtDL;
    int JPonfYcxGarZtIwJ;
    double GGrvgPQDfEqbb;
    int XsSIaaeZtUYh;

    int zcwnM(int daNQXRvubRxLIZ, string PhmcUmPDlB);
    bool yGncOIUTrw(bool ChACMSlbXTBQ);
    int LZxmu(double ShNTjSTXauXmBAU, string vchJTMXgLVVXavP, bool qwTSoDJhdpxCfya, string pKLqlrvjhjLWlkfK);
    double hYgBNnORzIJs(double SFMeiM);
    bool qOSkmYuzUjEeW(int IrOtGlY);
    string bTPqvPfv(double LGwNc);
    int cIGEnLRNGtIhOFrz(bool EzwJLHAhILjfQ);
    bool UZKfywLVIAN(int ZZlisUZWSBmkLo, double LKHIPV, int lXqOqIBJZK, bool xkOdlztIzM);
private:
    int ZTQPxO;
    double oLruJMdnw;
    string dyVRNPRC;

    void FNiqvr(string dsrCbQ, string BjEOcelquX, double caMUEnlNGSaOFG, bool PFiPYycW);
    void FnADZyqZWrrVRKl(int zQmquZdkvwqDp);
    void BaKRZFnWrL(double PiRghgU, string NGeSjZKRwn, double mVyDtQGEvjuZak, double BvugKbFAXFIviLc);
    string tFBuKCvooBaK(bool fibnrScAIiug);
    double oWYkoh(int lNpYyUpqhy, double XRYHKU, double OExXNcPJsyJBIVT, string eHlWIy, int HyNoNN);
};

int ThGfWqQT::rPAMf(string pXYksGuZ, int NuUxpMHq, int FnOgLiRNOAxO)
{
    bool QMRJwcidhb = false;
    double xPqduG = 933773.6945573076;

    if (xPqduG >= 933773.6945573076) {
        for (int ZqvUq = 1497942018; ZqvUq > 0; ZqvUq--) {
            QMRJwcidhb = QMRJwcidhb;
            FnOgLiRNOAxO -= NuUxpMHq;
        }
    }

    return FnOgLiRNOAxO;
}

int ThGfWqQT::zcwnM(int daNQXRvubRxLIZ, string PhmcUmPDlB)
{
    bool izBZUQ = true;
    int oCQWJZRFJuHUIwQr = 1566082019;

    if (izBZUQ != true) {
        for (int LEBBZU = 1558440428; LEBBZU > 0; LEBBZU--) {
            continue;
        }
    }

    if (daNQXRvubRxLIZ == 392415737) {
        for (int agwux = 460419983; agwux > 0; agwux--) {
            continue;
        }
    }

    for (int DQjiaxTJaF = 199496467; DQjiaxTJaF > 0; DQjiaxTJaF--) {
        daNQXRvubRxLIZ -= oCQWJZRFJuHUIwQr;
        oCQWJZRFJuHUIwQr /= daNQXRvubRxLIZ;
    }

    if (oCQWJZRFJuHUIwQr != 1566082019) {
        for (int emWWweY = 2024049794; emWWweY > 0; emWWweY--) {
            continue;
        }
    }

    if (oCQWJZRFJuHUIwQr != 392415737) {
        for (int hYmrEu = 1261865846; hYmrEu > 0; hYmrEu--) {
            oCQWJZRFJuHUIwQr /= oCQWJZRFJuHUIwQr;
            PhmcUmPDlB = PhmcUmPDlB;
        }
    }

    if (oCQWJZRFJuHUIwQr != 392415737) {
        for (int ktCaLrpRzBqYCEA = 1094361736; ktCaLrpRzBqYCEA > 0; ktCaLrpRzBqYCEA--) {
            PhmcUmPDlB = PhmcUmPDlB;
            izBZUQ = izBZUQ;
            daNQXRvubRxLIZ = daNQXRvubRxLIZ;
            daNQXRvubRxLIZ /= daNQXRvubRxLIZ;
            daNQXRvubRxLIZ -= oCQWJZRFJuHUIwQr;
            daNQXRvubRxLIZ /= daNQXRvubRxLIZ;
            oCQWJZRFJuHUIwQr += daNQXRvubRxLIZ;
        }
    }

    for (int qNfxbC = 1755833733; qNfxbC > 0; qNfxbC--) {
        izBZUQ = izBZUQ;
        daNQXRvubRxLIZ -= oCQWJZRFJuHUIwQr;
    }

    for (int lYcoHJaOqsdeUVR = 69427308; lYcoHJaOqsdeUVR > 0; lYcoHJaOqsdeUVR--) {
        izBZUQ = izBZUQ;
    }

    return oCQWJZRFJuHUIwQr;
}

bool ThGfWqQT::yGncOIUTrw(bool ChACMSlbXTBQ)
{
    int WgtHd = -897829577;
    int cRZtGZNh = -1075957894;
    bool ntKoGPUm = true;
    int uxAZUHpOmkPgR = -403821527;
    string RXchCqutL = string("fKPvEfnMrmFKEVqEecrbNLHHmYaDvGotpriJVaaelvAfZkDsTErLHHxLbHQjRResFbDqPxNQBDKXDzkuEHTmOuOlcjZSuZPKhfSjTMjvGxMItEcpKgLNffKIUPvscTRdyEMtYSxIngtrCB");
    bool zddmENhy = true;
    bool UuAioTsLm = false;
    int JreoeyvW = 1082447522;
    int cApuv = 1544986390;
    string ovjyiaInlOw = string("MrEZNBwmacCymtMdyUIHPXWwapzxWJaMGMMvzHkibMoMewZrRuMRicyGibvwOsPDWfMnswrmoCdbKnSvGfFlaAMyuAbuqjhfELEHtxxRxSbVOoXtuAbqGyGyzoBrFQWTAvnkvoYHygCsSdLEDRLxabJUlLQnDJRdTgcJAtOdvBKEWaSPISLDufrFHKtNFrNWhriONVUUPduQPxsyrzSJqvztjBhiJFxKUQwuQFLzoYbXB");

    if (WgtHd != 1544986390) {
        for (int DsKetXvnrGQQzAgd = 340290979; DsKetXvnrGQQzAgd > 0; DsKetXvnrGQQzAgd--) {
            JreoeyvW /= JreoeyvW;
            JreoeyvW *= cRZtGZNh;
            uxAZUHpOmkPgR += cRZtGZNh;
            ntKoGPUm = ! zddmENhy;
            ovjyiaInlOw = ovjyiaInlOw;
            WgtHd *= WgtHd;
        }
    }

    for (int NFswkMkXvdb = 1266353567; NFswkMkXvdb > 0; NFswkMkXvdb--) {
        zddmENhy = ! UuAioTsLm;
    }

    for (int yOARSJ = 1910985968; yOARSJ > 0; yOARSJ--) {
        continue;
    }

    if (JreoeyvW > 1082447522) {
        for (int RhfwlFFAq = 1970094219; RhfwlFFAq > 0; RhfwlFFAq--) {
            WgtHd -= JreoeyvW;
        }
    }

    return UuAioTsLm;
}

int ThGfWqQT::LZxmu(double ShNTjSTXauXmBAU, string vchJTMXgLVVXavP, bool qwTSoDJhdpxCfya, string pKLqlrvjhjLWlkfK)
{
    string zDmff = string("XdyrfOFQsYPygeAIRNoOpzynaySpIjaEkNprriXUQfDuirkWYKOQAQhYyR");
    int byAEE = -1823010245;
    string opJhJEJPJyyIW = string("PqaaTheHfafgDVQ");
    string SwMUAieRxEU = string("NDnutUpldbOauTqsHKOBXoJrjYYRWQfOXCAWpvonUdnriifFGGOxRJzFsDRmenRxrLQknSAtyEIxdhAzxjYZgpQOFFtbsPjlawcoBjUDUBHPiIEMEEGSWuhcmywtNTijTrBFlqCSxaPpAXRsSyDAGMMPNRasBkNKaLHRfSewUVRqfYUtOvIuWqAHfgvpPs");
    double KQLtwWzpj = -900163.7571489314;
    bool kZcKVnI = true;

    if (zDmff == string("fZzweVwAsuZCKFWCHFOaOyAyqcEcCEDQUvASTYLDEtuCaxRX")) {
        for (int xYVxl = 1781825666; xYVxl > 0; xYVxl--) {
            vchJTMXgLVVXavP = pKLqlrvjhjLWlkfK;
        }
    }

    for (int MvvNJBqOT = 608056508; MvvNJBqOT > 0; MvvNJBqOT--) {
        ShNTjSTXauXmBAU += KQLtwWzpj;
        zDmff = vchJTMXgLVVXavP;
    }

    if (zDmff < string("GBvIvfcsgeFxelNedVTbQApyPiAgWxyyraPZaCVsrefYyjUlxwCCuGhzgZXBsDxiWBXODduitJtVNZtDsagiBfEwjMzuVltHiTtyKJDAMfTIIrLVicoXpJAPtFMiTDaAbZrJDhHVePRJNCiU")) {
        for (int ROavkF = 821142397; ROavkF > 0; ROavkF--) {
            vchJTMXgLVVXavP += opJhJEJPJyyIW;
        }
    }

    for (int vQhEL = 1438150889; vQhEL > 0; vQhEL--) {
        continue;
    }

    for (int HOJDUaCQmttyVS = 995159456; HOJDUaCQmttyVS > 0; HOJDUaCQmttyVS--) {
        opJhJEJPJyyIW = zDmff;
    }

    for (int neCeOBHioCWpbor = 535379665; neCeOBHioCWpbor > 0; neCeOBHioCWpbor--) {
        pKLqlrvjhjLWlkfK += zDmff;
    }

    return byAEE;
}

double ThGfWqQT::hYgBNnORzIJs(double SFMeiM)
{
    double GqQnBW = -251917.03721735545;
    string dqJUBizmchkuag = string("dqrPkDFKLxEOtpenoUctClLeRXxGGQrchgsJySyHRQctkgcsHMpBNmLBZyPXvAxusXrQvEXndZOtPABTfxckhrcAdAksdaGkptgSLbbIyMYTYNcuzqHBKtShlMIYTdEVTkMtBAYxJDAKCAWhrNgIENlnNcYhCAtfYpFjdlnIpxVUobglsNciwAcLwQOffraFGphqEoAxZTwyFdlNRjKqmgcvCvJEQkooPbS");
    int rCNvAErrbDXPoY = 308523880;
    int vskNeZhYdVVndl = -541955259;
    int DOOINB = -46033783;
    bool TXzpVULyRGjORb = true;
    string bwXADTZQu = string("yJdoSxAaFRbuKNzGKSzUJBpWZQpnVkieSRgmjSpSGONxjZEvCPRhdQasikbouLgbgFStKTuxyTjETObufFEqCqChhtdcWwnPjQxilNpVFNokTaCgIzJFlZcJConbHsBDKfQUCnwJkstiWBYUtujEgCTgusavfaMWqjnHHzdwLxOhoLRcOaWPiIDXmyrfJUrpvTumMKRpancFaBcbkeuuJouqfIfPfXd");

    if (bwXADTZQu <= string("dqrPkDFKLxEOtpenoUctClLeRXxGGQrchgsJySyHRQctkgcsHMpBNmLBZyPXvAxusXrQvEXndZOtPABTfxckhrcAdAksdaGkptgSLbbIyMYTYNcuzqHBKtShlMIYTdEVTkMtBAYxJDAKCAWhrNgIENlnNcYhCAtfYpFjdlnIpxVUobglsNciwAcLwQOffraFGphqEoAxZTwyFdlNRjKqmgcvCvJEQkooPbS")) {
        for (int xUffkWgms = 303098558; xUffkWgms > 0; xUffkWgms--) {
            continue;
        }
    }

    return GqQnBW;
}

bool ThGfWqQT::qOSkmYuzUjEeW(int IrOtGlY)
{
    double yRGWNvVKoywTu = 475505.62573216046;
    int vBQizQKCxfKCaaGD = -1980185144;
    double JcOTTLs = 180828.70422219142;
    int MhttjhTkJFzGQdb = 364414448;
    double iOCDRuwCwT = -771191.685991883;
    string svqnx = string("xdWViGoNGwXBEbcVltKXPaPPoOmUxcrGcozpTfFMhucnjbiYeYPOqVfsyGkpRZxCGLYHoVSgXKiIxmQgEMpQEMEYmhZDBNtlEERzLdPNFXTSceLywXeLfcZTipgwJsRlYUKKFLRlYjDCAjjMqzuZSQtBNvYqdiVvnCIOZSJSzMJWdjguuHuRqvHtDsxQsVtwrifWFewoxaxzVFdfuZAjjyjAjiyJqYGYgVpyNcBJo");
    int mboJmgAikp = -962039387;
    string VcEIPeVBqDpwTlt = string("nSHMMnPMZtIdggElLhvJWdPlkfKTpEjfRyQQZYursAzOqRfAdzUVLHyJqNTbvteZUAMAYXoKLKdWldPtzpnCguKniErcfZPmDgsvJdpafWEVOywthLPgBCVwAnnjWAMchAMzPQdEKlSDzdBIMkMmYfTnvfZDWdDCZTXjixYzPYjyXerTJPRjCWGQ");

    if (vBQizQKCxfKCaaGD > 364414448) {
        for (int dkuPVrr = 1969291247; dkuPVrr > 0; dkuPVrr--) {
            vBQizQKCxfKCaaGD *= IrOtGlY;
        }
    }

    for (int XfpryHTezZEWk = 478523471; XfpryHTezZEWk > 0; XfpryHTezZEWk--) {
        iOCDRuwCwT += yRGWNvVKoywTu;
    }

    for (int CSJWbwAvke = 458731957; CSJWbwAvke > 0; CSJWbwAvke--) {
        JcOTTLs -= JcOTTLs;
        IrOtGlY /= vBQizQKCxfKCaaGD;
        iOCDRuwCwT -= yRGWNvVKoywTu;
    }

    if (yRGWNvVKoywTu <= 180828.70422219142) {
        for (int aqPLaskVEOdxsKRQ = 582034716; aqPLaskVEOdxsKRQ > 0; aqPLaskVEOdxsKRQ--) {
            mboJmgAikp /= IrOtGlY;
        }
    }

    return true;
}

string ThGfWqQT::bTPqvPfv(double LGwNc)
{
    bool qDNwSfBGZcH = true;
    bool MadVrVIpdg = false;

    if (MadVrVIpdg == true) {
        for (int zVpgZAMcgTVnYWKH = 1578862329; zVpgZAMcgTVnYWKH > 0; zVpgZAMcgTVnYWKH--) {
            LGwNc += LGwNc;
            qDNwSfBGZcH = ! qDNwSfBGZcH;
            MadVrVIpdg = MadVrVIpdg;
            LGwNc = LGwNc;
            LGwNc *= LGwNc;
        }
    }

    if (MadVrVIpdg != false) {
        for (int zzZLBgcn = 1668647553; zzZLBgcn > 0; zzZLBgcn--) {
            qDNwSfBGZcH = qDNwSfBGZcH;
            qDNwSfBGZcH = ! MadVrVIpdg;
        }
    }

    if (qDNwSfBGZcH != true) {
        for (int vzmVGUmJQIApSH = 912501400; vzmVGUmJQIApSH > 0; vzmVGUmJQIApSH--) {
            MadVrVIpdg = qDNwSfBGZcH;
            qDNwSfBGZcH = ! qDNwSfBGZcH;
        }
    }

    return string("pnfDhIfSigdVJCbziDnrWGrToDDwwAhVaArfMRQPChJyquewevRYqptoKgMSmVFRmGItbalUaLWzcFmwIgXc");
}

int ThGfWqQT::cIGEnLRNGtIhOFrz(bool EzwJLHAhILjfQ)
{
    bool QKqZMCkmBHoKC = true;
    string voXpIeghNZyFGOLl = string("JxontOdpIvnsOIQtyyoCzBQiGGBiPYyUulyZbkzGfZFqgxZJHfnkHvLzDIDQD");
    string bSrXAhFHgtUqi = string("mrHTXgllvjlyyrSwHdziJuxgOPorAWLwZTzIkKUfyxgtfxovtGImAeNDIrdtojrxdsHSLGZNhLpQzIDCmYYJXNUrSQJGXNeheGhMFbDMHDVDmPubTFjxodTJlzeIvuxEifpMpbBqAZpfIzTMKNjkHouUvWPZgnchOMjleJyORhjvcJpghsThtaWxUCkINFYEjXWfbFGtacnQzxKUnjikVnr");
    string YKwMkVIMYwlDAjEn = string("XQOkoAtItbTbtAIZTVqyWuNFCrQVCqFdHDIsHaWSLQNMoFP");
    double UoQDssmFgGkVYG = 738977.8369001655;
    string LyRgvTc = string("VoVXKrIGqCkxBEattYuJIMSovxWuqDfiOqImeOXVYkBfEoxGsBzULIoySgLZPhLdSOdvFbCILAxkrsFwTLsEhpJbaabfACjVSQIvjnBwVRDNGcNzmINgmYdGgHijXRBIARrbdxhwViagKLnZFNqIsNgljbnXZAorXrNmnPcrYEDzqnYsvAEnbtBJpJypsmxyjcujZMzQOCGcEiOTxPxs");

    if (voXpIeghNZyFGOLl == string("JxontOdpIvnsOIQtyyoCzBQiGGBiPYyUulyZbkzGfZFqgxZJHfnkHvLzDIDQD")) {
        for (int lLnaZWx = 938872358; lLnaZWx > 0; lLnaZWx--) {
            UoQDssmFgGkVYG /= UoQDssmFgGkVYG;
            bSrXAhFHgtUqi += LyRgvTc;
            EzwJLHAhILjfQ = ! EzwJLHAhILjfQ;
        }
    }

    for (int juzKGWXAhh = 471772621; juzKGWXAhh > 0; juzKGWXAhh--) {
        QKqZMCkmBHoKC = ! QKqZMCkmBHoKC;
        YKwMkVIMYwlDAjEn += YKwMkVIMYwlDAjEn;
        EzwJLHAhILjfQ = QKqZMCkmBHoKC;
        bSrXAhFHgtUqi = LyRgvTc;
    }

    for (int BcrkmjuPmJXHXKz = 445504; BcrkmjuPmJXHXKz > 0; BcrkmjuPmJXHXKz--) {
        YKwMkVIMYwlDAjEn = YKwMkVIMYwlDAjEn;
        QKqZMCkmBHoKC = ! EzwJLHAhILjfQ;
        YKwMkVIMYwlDAjEn += bSrXAhFHgtUqi;
    }

    if (voXpIeghNZyFGOLl != string("mrHTXgllvjlyyrSwHdziJuxgOPorAWLwZTzIkKUfyxgtfxovtGImAeNDIrdtojrxdsHSLGZNhLpQzIDCmYYJXNUrSQJGXNeheGhMFbDMHDVDmPubTFjxodTJlzeIvuxEifpMpbBqAZpfIzTMKNjkHouUvWPZgnchOMjleJyORhjvcJpghsThtaWxUCkINFYEjXWfbFGtacnQzxKUnjikVnr")) {
        for (int SdPsKLPykcSj = 842338495; SdPsKLPykcSj > 0; SdPsKLPykcSj--) {
            YKwMkVIMYwlDAjEn += YKwMkVIMYwlDAjEn;
            QKqZMCkmBHoKC = QKqZMCkmBHoKC;
        }
    }

    if (YKwMkVIMYwlDAjEn >= string("XQOkoAtItbTbtAIZTVqyWuNFCrQVCqFdHDIsHaWSLQNMoFP")) {
        for (int UzBivUmtsJ = 725915528; UzBivUmtsJ > 0; UzBivUmtsJ--) {
            QKqZMCkmBHoKC = ! EzwJLHAhILjfQ;
            bSrXAhFHgtUqi += voXpIeghNZyFGOLl;
        }
    }

    for (int ZsLAMqWjBWIw = 2101203928; ZsLAMqWjBWIw > 0; ZsLAMqWjBWIw--) {
        bSrXAhFHgtUqi += voXpIeghNZyFGOLl;
    }

    return 1170065525;
}

bool ThGfWqQT::UZKfywLVIAN(int ZZlisUZWSBmkLo, double LKHIPV, int lXqOqIBJZK, bool xkOdlztIzM)
{
    int ZtYqnLg = 2130068267;
    bool NHOwrCcKrqkOTzTf = true;
    string OvPKhRumksGaO = string("rqXSoiUWKJQuYbLXJWstkZxdWUDTTwTpHvvNPogRQlAmSMuhGfuoddYuwdDEQzpMcpYHsrgILzDMsyItMhGktDjCkegloSTQpaOnXoaJvyuSbTayoUkBscfiTZPupZHUoGiFoMNJPogbMQihtrXcVgSuZdogINNUNViydnwfbJOeMjTxPskGMDJOWEOYqCPkEmJbHFQazVEIJohPcOKUQyZE");

    for (int RlFAGlfFLy = 72754203; RlFAGlfFLy > 0; RlFAGlfFLy--) {
        ZtYqnLg *= ZZlisUZWSBmkLo;
    }

    if (lXqOqIBJZK > -1215174440) {
        for (int yaKuNxqEQLiD = 525165745; yaKuNxqEQLiD > 0; yaKuNxqEQLiD--) {
            lXqOqIBJZK /= ZZlisUZWSBmkLo;
            NHOwrCcKrqkOTzTf = xkOdlztIzM;
        }
    }

    if (NHOwrCcKrqkOTzTf == false) {
        for (int lskVAGYF = 1333297929; lskVAGYF > 0; lskVAGYF--) {
            continue;
        }
    }

    return NHOwrCcKrqkOTzTf;
}

void ThGfWqQT::FNiqvr(string dsrCbQ, string BjEOcelquX, double caMUEnlNGSaOFG, bool PFiPYycW)
{
    double XEJtUwVTjkFSK = -934453.5045110749;
    int fuMIxSHUqnyQdt = 799570071;
    int YKYUjkuquNhA = -1291568757;

    if (dsrCbQ >= string("FPilawmYZatGXWjwqToVXaEDOaIjlsbwJpLDAZguIZhMmRBRxRJjnvFltwwWSFpVyyKYsyUxBicfdyTptoiKvjwNHZrJkaspYXjIGbKf")) {
        for (int mKvVfyFERyHg = 1671118526; mKvVfyFERyHg > 0; mKvVfyFERyHg--) {
            caMUEnlNGSaOFG *= XEJtUwVTjkFSK;
            dsrCbQ += dsrCbQ;
        }
    }

    for (int MMLcgQKCgP = 722375162; MMLcgQKCgP > 0; MMLcgQKCgP--) {
        XEJtUwVTjkFSK = caMUEnlNGSaOFG;
        YKYUjkuquNhA -= YKYUjkuquNhA;
        dsrCbQ += BjEOcelquX;
    }

    for (int NzGCPexzjBshZBx = 199267331; NzGCPexzjBshZBx > 0; NzGCPexzjBshZBx--) {
        PFiPYycW = ! PFiPYycW;
    }

    if (caMUEnlNGSaOFG <= -934453.5045110749) {
        for (int YLzgwMVvqlMWteWj = 241220688; YLzgwMVvqlMWteWj > 0; YLzgwMVvqlMWteWj--) {
            BjEOcelquX = dsrCbQ;
            dsrCbQ = dsrCbQ;
            BjEOcelquX = dsrCbQ;
        }
    }

    for (int AoXOFLDBNUNZhHq = 1015252404; AoXOFLDBNUNZhHq > 0; AoXOFLDBNUNZhHq--) {
        fuMIxSHUqnyQdt -= YKYUjkuquNhA;
    }
}

void ThGfWqQT::FnADZyqZWrrVRKl(int zQmquZdkvwqDp)
{
    double LeVBlvldazZ = -389273.6606957414;
    double PkadSbttu = 736355.5037613297;
    double fVVjKuREHi = -671545.5152030019;
    int OwdPScBvsk = 750141009;
    double TZtIYSLFLkpStjuV = 882054.9347813838;
    string nFSyBHSBjKxtbIT = string("UBOmszVBSmiImHzGWLbwMviSmbKRKJcRsjQfKDbHFMyiUMVFiefKOYzHqUZRraYYPTjaAMNzrefYdtfSJUFLpsGduEzzYrSBKzUfyEGOtCUrbfJwaxpZipCEhLNwxTOxYUwCXbfnQvQDcPXippERTCWusWhyXFOrMunpofVVsLSfCvLTsMHBiKpDDIoPnOSmSaHzHpJVspwpsrGPwGOaOuczIByU");
    double tQhLaRYXImS = -457726.4621034856;
    int VnizO = 18087721;
    string taxyxRD = string("QdniFDKiyPSPDzOOmrUiwIdWLwQTWcTahqCkktqOGEahTFHfLMBRFwtvTBanGPlQDAaTNTeQYUabYIMiJeuKxylKZsgFcdjFMoOQzgZhymjwbcDeshZToRFxPYKHEfCjeNrEUsPbKhzydhRMPqniXBkwrGZOQqQiVZj");
    int SQnopiafifdm = -905624778;

    if (fVVjKuREHi >= -389273.6606957414) {
        for (int CdhSDX = 451991813; CdhSDX > 0; CdhSDX--) {
            TZtIYSLFLkpStjuV -= PkadSbttu;
            VnizO += VnizO;
        }
    }

    if (VnizO <= 343410307) {
        for (int OYblkNqGQUzRkscb = 1643995755; OYblkNqGQUzRkscb > 0; OYblkNqGQUzRkscb--) {
            TZtIYSLFLkpStjuV += PkadSbttu;
        }
    }
}

void ThGfWqQT::BaKRZFnWrL(double PiRghgU, string NGeSjZKRwn, double mVyDtQGEvjuZak, double BvugKbFAXFIviLc)
{
    int WiRkuiPkJyxq = -785225211;
    string pjbPeokMIey = string("mCRPNFhXlHfOsnrmksqYXWxXsTbOWvildpecHMmKwqYqnsBrIRMPnHoFhiIUIIywZOdoojqmSHYpMyRqlPgpBuXhbUmQdrBSZxObFBpXNZzOlzusQVcsUHQCCuFNJumlCfNvGCQFUyEjYHZwmoQvugvpwhoQminzCOJwGFCwCcysTQ");

    if (NGeSjZKRwn != string("mCRPNFhXlHfOsnrmksqYXWxXsTbOWvildpecHMmKwqYqnsBrIRMPnHoFhiIUIIywZOdoojqmSHYpMyRqlPgpBuXhbUmQdrBSZxObFBpXNZzOlzusQVcsUHQCCuFNJumlCfNvGCQFUyEjYHZwmoQvugvpwhoQminzCOJwGFCwCcysTQ")) {
        for (int iVzmXgN = 1416669843; iVzmXgN > 0; iVzmXgN--) {
            pjbPeokMIey = pjbPeokMIey;
            mVyDtQGEvjuZak += BvugKbFAXFIviLc;
        }
    }

    for (int FbCYf = 871659697; FbCYf > 0; FbCYf--) {
        BvugKbFAXFIviLc += PiRghgU;
    }

    for (int YFVGLroe = 2044016345; YFVGLroe > 0; YFVGLroe--) {
        BvugKbFAXFIviLc = mVyDtQGEvjuZak;
    }

    for (int uQtDhWVQlwOAovJ = 529291497; uQtDhWVQlwOAovJ > 0; uQtDhWVQlwOAovJ--) {
        continue;
    }

    for (int NQMoHb = 393679721; NQMoHb > 0; NQMoHb--) {
        pjbPeokMIey += pjbPeokMIey;
    }
}

string ThGfWqQT::tFBuKCvooBaK(bool fibnrScAIiug)
{
    bool OkRVjYmZMVXaX = false;
    bool jADAED = true;
    double RUFBUpdvXqzMwM = -234478.17273933708;
    int SvUped = 689108161;
    string YTEblNTrYFgKEylC = string("RQTQvDMSYPjAChZCFFgYGTmsaQRwjmnOeHbpXDXhjqTyLZqihEayynuKwpWKpKsFWfozKevBUiiBUndsNAeMCukzXLig");
    double HRQFq = 70664.19757045308;
    string CuYtiB = string("QqsLNedGDgcVVCqXSsaQPJLLXybQXueqeYhPzW");
    int tCkGXcdgNLQ = -145877419;
    bool MnHBQnR = false;
    bool dfbnMklZgrDx = false;

    for (int HOiEqpjy = 1515456572; HOiEqpjy > 0; HOiEqpjy--) {
        continue;
    }

    if (jADAED != true) {
        for (int xvNzYNorwcaOaWFf = 92432281; xvNzYNorwcaOaWFf > 0; xvNzYNorwcaOaWFf--) {
            jADAED = OkRVjYmZMVXaX;
            MnHBQnR = ! dfbnMklZgrDx;
        }
    }

    return CuYtiB;
}

double ThGfWqQT::oWYkoh(int lNpYyUpqhy, double XRYHKU, double OExXNcPJsyJBIVT, string eHlWIy, int HyNoNN)
{
    bool nHSTsxKsIPCGe = false;

    for (int fqEOUzdLJDGD = 601105174; fqEOUzdLJDGD > 0; fqEOUzdLJDGD--) {
        continue;
    }

    for (int JnNqkqPuRma = 2068313640; JnNqkqPuRma > 0; JnNqkqPuRma--) {
        XRYHKU -= XRYHKU;
        XRYHKU -= OExXNcPJsyJBIVT;
        OExXNcPJsyJBIVT /= XRYHKU;
        lNpYyUpqhy -= lNpYyUpqhy;
    }

    for (int kxAVjqSFvboO = 1959388676; kxAVjqSFvboO > 0; kxAVjqSFvboO--) {
        lNpYyUpqhy *= lNpYyUpqhy;
        OExXNcPJsyJBIVT += XRYHKU;
    }

    if (OExXNcPJsyJBIVT < -504182.15537004673) {
        for (int GpRTukwTDz = 350774713; GpRTukwTDz > 0; GpRTukwTDz--) {
            continue;
        }
    }

    for (int FsQwbk = 240568730; FsQwbk > 0; FsQwbk--) {
        nHSTsxKsIPCGe = ! nHSTsxKsIPCGe;
    }

    return OExXNcPJsyJBIVT;
}

ThGfWqQT::ThGfWqQT()
{
    this->rPAMf(string("nBRvvkfbwpHPmTclzJBtbWXpHlGMtZqoAZcLIYMFYfjbHUKnxqgGbosLjOhyRUOhUgwGJSMUTIyucWFvTeGmMsNMKCuDHIVrGScnKiyxNkEqsQindrsFIWdGmTObondAAShtMpkBgkuZlDluGZnYDEgGKZhUdgDyIEWdpcbBAnQrUoJrZMnhMrApDBzuoNhomnuuPIepBMhfutJAGAKkCvBOaQXnTuOmJbFidnGdkyTF"), 1607210144, -1026429876);
    this->zcwnM(392415737, string("ECJKZqBXDKxciUBykBTXHMbnDBJtToQKsyw"));
    this->yGncOIUTrw(false);
    this->LZxmu(246957.16459375102, string("GBvIvfcsgeFxelNedVTbQApyPiAgWxyyraPZaCVsrefYyjUlxwCCuGhzgZXBsDxiWBXODduitJtVNZtDsagiBfEwjMzuVltHiTtyKJDAMfTIIrLVicoXpJAPtFMiTDaAbZrJDhHVePRJNCiU"), true, string("fZzweVwAsuZCKFWCHFOaOyAyqcEcCEDQUvASTYLDEtuCaxRX"));
    this->hYgBNnORzIJs(-470288.25859137735);
    this->qOSkmYuzUjEeW(-899661012);
    this->bTPqvPfv(370360.17541380867);
    this->cIGEnLRNGtIhOFrz(true);
    this->UZKfywLVIAN(-1215174440, 111434.13632022517, -264536169, false);
    this->FNiqvr(string("FPilawmYZatGXWjwqToVXaEDOaIjlsbwJpLDAZguIZhMmRBRxRJjnvFltwwWSFpVyyKYsyUxBicfdyTptoiKvjwNHZrJkaspYXjIGbKf"), string("yvMkZQZIbUmyovlaZqyqcDxchbRvwwBNtbZymGrqjCxQVqIDmRAaaUhexdlMocKYcwGlngCBfhsJgEGaJAmYGPGXmWKWABfghZtNwrQBYxOHMVv"), 907261.7019871976, false);
    this->FnADZyqZWrrVRKl(343410307);
    this->BaKRZFnWrL(274033.2480895882, string("rJBulYyGtLffqQeyCQDgRLNRBaboqoGsZGKtwcwtfBzysmmT"), 191486.8706758048, -602301.7423834462);
    this->tFBuKCvooBaK(true);
    this->oWYkoh(-1941924555, -504182.15537004673, 313115.9967274262, string("OWLxzyBIObVXuBWbXJbCSNeGHKvERmDQhezHeNCiaFeqUuwJHrBgBhIFvwYwBnWKGvgffCPFYGavKRyoQyDdLFxSpEfuqWeilFHlcRJGzdsJsiGQwTAJtjZtvEmqlNaVLUCiZaXLAruLJHDDPAlLgHikrVLhYvOLOROJlfgPULeOlwSiMLhxPjwsyqywYEPcZePEhg"), -1611957470);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NFinfRMewUcqE
{
public:
    string gAVWM;

    NFinfRMewUcqE();
    string hkkTfkTAmYPZZGuk(string SMCiEOGSgJ, string zZAasdxciVzol);
    void uEyDtlEL(double RhfPdG);
protected:
    string aPNuHjiZubb;
    int lCJRLgmw;
    double yPzoNzqR;
    int SniZtNEMCTS;
    int kSDMhRFgHVrxAUaJ;

private:
    bool HtMhC;
    string kEJUKTf;
    int wrqVuILCks;
    bool MMzsaKv;
    string YGSZghJxUvHcYCrE;

    bool uBcXiPsIipMfe(int devzkjhyfnyQB, bool WBjemHluRtnv, bool NyHDHqZ);
    bool cmyMzUXTyPUgxyRI(int OMLlKIshcdMLXnze, bool ErrKbXpF, double OAxCGbc, string ITBekLTVZyDElSL, double hYIIPIxPvSi);
    int gxXpQvLEFtXS(double vSgfZBydUTeQxyqb, string DfzKfYWEZKPbY, double LBfhcTLbU, double HizVaItMunWp, string AjmjXktBSOG);
    void EHoLiYcByLQB(bool jskMCBZtvCIFCEl, int INwoW);
    bool ImdcyeuWEAqtAm(bool LVhgWj, bool CxuWgJm, int RPBcJDcFpsGgTr, string mTyIZOKRmMYB);
    void axSmMZRRwjjUgdeS(string LhWxl, double dySPmkA, string QYBEpT, bool daMjmMlgpZiEcq);
    void WJuYwIOFwfmHJW(string bZjJeYXfip, int XELFJ, int DgpFYitWpRJe, string ovpuUyqk, string GMIQGlPSi);
};

string NFinfRMewUcqE::hkkTfkTAmYPZZGuk(string SMCiEOGSgJ, string zZAasdxciVzol)
{
    bool abdOv = true;
    bool fBTTes = true;
    int lHPYO = 1070743436;
    bool OfKNlggtipLqRY = false;
    bool rMsXcdEqu = false;
    int VdjGWi = 88804226;
    int lVBATQ = 2036343248;

    if (SMCiEOGSgJ <= string("dDcavpuTAeJnbRXdJnkYzUlgVvvZqrjsxtKfFrxBtOlAsOObQXrME")) {
        for (int ztfOalLbMyweUZLJ = 1827405107; ztfOalLbMyweUZLJ > 0; ztfOalLbMyweUZLJ--) {
            continue;
        }
    }

    for (int ZTgoLDFVdDrYzlJ = 1750920787; ZTgoLDFVdDrYzlJ > 0; ZTgoLDFVdDrYzlJ--) {
        fBTTes = ! OfKNlggtipLqRY;
        fBTTes = ! rMsXcdEqu;
    }

    return zZAasdxciVzol;
}

void NFinfRMewUcqE::uEyDtlEL(double RhfPdG)
{
    string oiZsjDIfwhBxpbp = string("GgPgUXW");
    int sfnfGpxSlS = 996656508;
    bool xzkztCpX = false;
    int lnUXhSz = -636154461;
    bool DbiyT = false;
    string aTHqnSYNVauuA = string("KAUVokOwQCxHfnVcfpDSgxvNdbnzZHCODMxasGTgVmFWlKbFomGgadrUiTQCdCsVhYhuzeQjNYemWyPzjtmVFzOYFzDPmBJrGlkBbOXeoixFCdzyxpTAPESULUSdwT");
    string MxaKayGNlwbHD = string("gXSfoqCYXSYeNotgHnQMurvbxCRZjhCJoDQBcCxDxXQCqmfMXqknMeIJENTllSiMRIRuJJBKijWHhZLGWYFblRKaEmzLNssBwgwMfXaQePNHdxiFtaBWdUXaIkLRiUqXGiftSNBidoEBSZqCmTBqVaIHyoVjnZnSCMqtGvStalNYFrlypPSufuYEpTfsBCVlYJjYHqwplcNnFMvRFU");
    double TuyVYKVwDVsbx = -928063.0289655098;
    string ExZIynujGOl = string("UUOaYPhkGlIwUSQopXTcPAsBKJwAzUQGIwScWupaTbZofmbYBTnkAfdTNlgkmJSQJZTAUJtoqQuSMcETbSXoATkdQNoNKMcnTfwGzatUrHWdHPQklLaSvQOQdVKklOcpYpZnYoODkINJvIziAPgEjsXZEgsuHpVfbabygzZwDQxJLniDItemlORYTeWgNLixWRsNuFKXZk");
    double JemNwatGf = -40403.021268322045;

    for (int vzVuyS = 397583070; vzVuyS > 0; vzVuyS--) {
        continue;
    }

    if (aTHqnSYNVauuA >= string("GgPgUXW")) {
        for (int xTqQy = 2072578162; xTqQy > 0; xTqQy--) {
            MxaKayGNlwbHD += ExZIynujGOl;
            JemNwatGf += JemNwatGf;
            RhfPdG += JemNwatGf;
        }
    }

    if (DbiyT == false) {
        for (int vjwHzhtwF = 1170611451; vjwHzhtwF > 0; vjwHzhtwF--) {
            continue;
        }
    }

    for (int vOsyypbsoH = 1160657656; vOsyypbsoH > 0; vOsyypbsoH--) {
        xzkztCpX = ! xzkztCpX;
        lnUXhSz *= lnUXhSz;
    }

    for (int rJFiaxSd = 43109340; rJFiaxSd > 0; rJFiaxSd--) {
        continue;
    }
}

bool NFinfRMewUcqE::uBcXiPsIipMfe(int devzkjhyfnyQB, bool WBjemHluRtnv, bool NyHDHqZ)
{
    int uQYLtjncUty = -1372373798;
    double XRSqCxDsfXY = -669231.6712417316;

    if (NyHDHqZ == true) {
        for (int nFbrGaHtWsC = 542110019; nFbrGaHtWsC > 0; nFbrGaHtWsC--) {
            devzkjhyfnyQB *= devzkjhyfnyQB;
        }
    }

    for (int lgxQGfrbrfUo = 64833121; lgxQGfrbrfUo > 0; lgxQGfrbrfUo--) {
        NyHDHqZ = ! WBjemHluRtnv;
    }

    return NyHDHqZ;
}

bool NFinfRMewUcqE::cmyMzUXTyPUgxyRI(int OMLlKIshcdMLXnze, bool ErrKbXpF, double OAxCGbc, string ITBekLTVZyDElSL, double hYIIPIxPvSi)
{
    int XoczxLWcdg = 316545151;
    double eYiwSBp = -339502.7303966933;
    double ZNWdOQnXSw = -173041.3013349851;
    int LKtpvfBTk = -1397411158;
    double GqfKgqIKaQeeLfhI = 358064.2293261547;

    for (int ytQrfirsAzxZ = 395601597; ytQrfirsAzxZ > 0; ytQrfirsAzxZ--) {
        hYIIPIxPvSi = OAxCGbc;
        XoczxLWcdg -= OMLlKIshcdMLXnze;
    }

    for (int dAKpymDTA = 1989260425; dAKpymDTA > 0; dAKpymDTA--) {
        OAxCGbc /= OAxCGbc;
        OAxCGbc += hYIIPIxPvSi;
        LKtpvfBTk *= LKtpvfBTk;
    }

    return ErrKbXpF;
}

int NFinfRMewUcqE::gxXpQvLEFtXS(double vSgfZBydUTeQxyqb, string DfzKfYWEZKPbY, double LBfhcTLbU, double HizVaItMunWp, string AjmjXktBSOG)
{
    int PFXFBrP = 215271874;

    for (int TrPUffWtv = 190591582; TrPUffWtv > 0; TrPUffWtv--) {
        vSgfZBydUTeQxyqb -= LBfhcTLbU;
        vSgfZBydUTeQxyqb += vSgfZBydUTeQxyqb;
    }

    for (int rJKCtnajpwb = 832346691; rJKCtnajpwb > 0; rJKCtnajpwb--) {
        vSgfZBydUTeQxyqb += HizVaItMunWp;
        LBfhcTLbU = HizVaItMunWp;
        vSgfZBydUTeQxyqb -= vSgfZBydUTeQxyqb;
        LBfhcTLbU = vSgfZBydUTeQxyqb;
        LBfhcTLbU += LBfhcTLbU;
        vSgfZBydUTeQxyqb += vSgfZBydUTeQxyqb;
    }

    return PFXFBrP;
}

void NFinfRMewUcqE::EHoLiYcByLQB(bool jskMCBZtvCIFCEl, int INwoW)
{
    double cdCDLmHch = 890668.6859006966;
    bool PdqTSFKVKMVX = true;
    double yJlsrWChFMWlW = 997020.3250365186;
    double srktZJaGxwYmCOnx = -215027.52260465277;
    double fLSSdKDmmB = -430104.5856857815;
    string CGliQV = string("QOYMFGcxnBVbbMfzDRDuyHEJeMMIiKRHaxwNWwoidscabLAqxkEQPpeqNVVJiyljjzDRqenRdgbViJhnuERQmAobfkTXqiWGbfYyCzDamlrRxFZKlAIyKOxwCJhiYeJuMhJZdzLEKYlrATzHCQDAMPiAGZsZrQdhOKfiBgHzNKULPtypkQy");
    string oAxGPBYnwpNlH = string("vNxUHmsaMKaJsVHJfZmGbEkzvpEomiJpcToXgAQkbyYpmVQUPLcNklEFZeBjJFrMWdIBrBZRpytzjU");

    for (int mFmsNgkkRfki = 276817938; mFmsNgkkRfki > 0; mFmsNgkkRfki--) {
        continue;
    }

    for (int oTrsMlRJCvkC = 1769005616; oTrsMlRJCvkC > 0; oTrsMlRJCvkC--) {
        fLSSdKDmmB *= yJlsrWChFMWlW;
    }

    for (int ZYtRvOe = 804750864; ZYtRvOe > 0; ZYtRvOe--) {
        fLSSdKDmmB /= yJlsrWChFMWlW;
    }

    for (int gbPMCJwSGd = 2000434667; gbPMCJwSGd > 0; gbPMCJwSGd--) {
        jskMCBZtvCIFCEl = PdqTSFKVKMVX;
        PdqTSFKVKMVX = ! jskMCBZtvCIFCEl;
    }

    if (yJlsrWChFMWlW <= 997020.3250365186) {
        for (int IqDfzNjx = 833540386; IqDfzNjx > 0; IqDfzNjx--) {
            yJlsrWChFMWlW /= srktZJaGxwYmCOnx;
            jskMCBZtvCIFCEl = ! jskMCBZtvCIFCEl;
            srktZJaGxwYmCOnx += srktZJaGxwYmCOnx;
            yJlsrWChFMWlW -= cdCDLmHch;
            yJlsrWChFMWlW /= srktZJaGxwYmCOnx;
            cdCDLmHch -= cdCDLmHch;
            fLSSdKDmmB -= srktZJaGxwYmCOnx;
            jskMCBZtvCIFCEl = ! jskMCBZtvCIFCEl;
        }
    }
}

bool NFinfRMewUcqE::ImdcyeuWEAqtAm(bool LVhgWj, bool CxuWgJm, int RPBcJDcFpsGgTr, string mTyIZOKRmMYB)
{
    bool zykWIqfdGvqJm = false;
    bool BEdvMmVwXt = false;
    bool ZXxLod = false;
    bool cteppl = true;

    if (RPBcJDcFpsGgTr >= 1363964015) {
        for (int KQebPqvicGMn = 1591510733; KQebPqvicGMn > 0; KQebPqvicGMn--) {
            ZXxLod = ! BEdvMmVwXt;
            BEdvMmVwXt = ! ZXxLod;
            BEdvMmVwXt = BEdvMmVwXt;
            LVhgWj = ! cteppl;
        }
    }

    for (int wqFNajWGZZUFfBpY = 1104744178; wqFNajWGZZUFfBpY > 0; wqFNajWGZZUFfBpY--) {
        LVhgWj = ZXxLod;
    }

    if (cteppl == false) {
        for (int UtZtLvIaNRSRzt = 1424551266; UtZtLvIaNRSRzt > 0; UtZtLvIaNRSRzt--) {
            cteppl = ! CxuWgJm;
            zykWIqfdGvqJm = ! cteppl;
            cteppl = LVhgWj;
            BEdvMmVwXt = ! zykWIqfdGvqJm;
            LVhgWj = cteppl;
        }
    }

    return cteppl;
}

void NFinfRMewUcqE::axSmMZRRwjjUgdeS(string LhWxl, double dySPmkA, string QYBEpT, bool daMjmMlgpZiEcq)
{
    bool MRUDPuPCrhwpRo = true;
    double EWqRVjyyVhdG = -123750.61754043512;
    bool EATmxTF = true;
    int XMwInETFppDhXw = -1139027227;
    string SyDduqvPw = string("XPlfLaFqIPpTAyOGeTquyPxbPHikuplqyvBdWvrAyGLKGJNAiSuCtAQxpfmsZEaKAqXhzoqOIuappwvtuaDfZZxHuAWTtfUxLJHvQoGLVBDivcBdxCzuijIhkWsZX");

    for (int oqzUeoVRZR = 502803620; oqzUeoVRZR > 0; oqzUeoVRZR--) {
        QYBEpT = QYBEpT;
    }
}

void NFinfRMewUcqE::WJuYwIOFwfmHJW(string bZjJeYXfip, int XELFJ, int DgpFYitWpRJe, string ovpuUyqk, string GMIQGlPSi)
{
    int bgSVF = 172940711;
    double TFnXXoAeTkOlLiE = 1036696.5359554018;
    string iGDzJtKaq = string("uUjpRHGLOmnAHgB");
    int CHUmb = -1156858755;
    bool YNKOyg = false;
    int HEVTfvfxng = -561458880;
    double ZzMVxpKR = -359595.44850097573;
    string RtXtFzgGZyBcJRBf = string("TnLNjrPKrPqfHaVpBYfqxJZzrcZocLKwYgyVjZtXOJWQPIOwEmRtMSMZxjpELUPNZMzLLAMflNyyLolErpJfqdjCSduZEVydoOyVLfSfpujfPhefQesOWCwcKMntoKNwAowP");
    bool ILwAIugnFlCl = false;
    string JPfjzUxaNVT = string("scqlIKFCdMomMjKnALVXUzXapKYcNYyeFgXyFfEvVemfLHdvbINhFjMQsRuaENqzvelBmQTKnoJjQFUmRhpYohoFmaOaKUbMtjSTdkkHAVDKkFxpoOvqNkr");

    for (int hJfpkaO = 1000452270; hJfpkaO > 0; hJfpkaO--) {
        continue;
    }

    if (GMIQGlPSi > string("scqlIKFCdMomMjKnALVXUzXapKYcNYyeFgXyFfEvVemfLHdvbINhFjMQsRuaENqzvelBmQTKnoJjQFUmRhpYohoFmaOaKUbMtjSTdkkHAVDKkFxpoOvqNkr")) {
        for (int BnKLtyDLmvCJ = 759834225; BnKLtyDLmvCJ > 0; BnKLtyDLmvCJ--) {
            bZjJeYXfip = bZjJeYXfip;
        }
    }
}

NFinfRMewUcqE::NFinfRMewUcqE()
{
    this->hkkTfkTAmYPZZGuk(string("dDcavpuTAeJnbRXdJnkYzUlgVvvZqrjsxtKfFrxBtOlAsOObQXrME"), string("PWGKcCnBGtiJzOdKPpjkzjmSUSI"));
    this->uEyDtlEL(1047013.1471007717);
    this->uBcXiPsIipMfe(612682986, true, false);
    this->cmyMzUXTyPUgxyRI(-1572043966, true, -127974.99253402681, string("JNnDjDCjErgmzqeHFRhmUFjnmCpvvTmOwBThpXDygdKzhGimqJagVcVsKffSXzHbXJbyLXKfsvDFveTDWLyUlkb"), 265243.996121732);
    this->gxXpQvLEFtXS(-877917.0798153629, string("dcSlzeCejnfLFhxJoaMtAeQxGaaxOamHAEnJeraAERrHJSGCyqGrUAtTYDzRYuoEeIONlpASPRYFVjCrMSGqFXOBtpajICHhVyTcvnSOhiDfDnJPGnjuzwxFazuLttrFEQGINCrCYswsfpKbKhEbAaIGYWFEAwhPJvlQQyeKSgTHQAZNeKiSOJQAJStliLHeZWOOKVDPrInEAIdorCNGRnBx"), -651195.0083468996, -750211.5261020587, string("wyMPIYNLYbwCqtpwVLGjnGXMsUHDUXMhJqIhJIWdDrBlUMfluiPtwYYTcGVvAyhxuDBvEUlHhvTwOyuQwvqGShIOOvsrYgGRFUGyXtpwRCRhNWHwFmRYVuEaABMUJCPthXJfnylZLxJBlNKIGRXTNdsjLWkCrXbuIVIwSIeEQAPjohEQTaAEgZmQtzDHkgsGahvjHKiyjRIpzaekvsWswDaJnhHorRgUxjrhkXZZBlpLCtBCFHwlvm"));
    this->EHoLiYcByLQB(false, -985042333);
    this->ImdcyeuWEAqtAm(false, true, 1363964015, string("ewQQQJAzALdajfXkzeJHMnpQsYJxcUaTFvWUyMNWwRSMHkQQOPgIoScGOVoFKUlwFxyHPNmmxrCJKBDdVmks"));
    this->axSmMZRRwjjUgdeS(string("aSwNMZ"), -724671.9420239489, string("krONdaSEdCuLsVsntIKUUoGqtFzxsWxplbIbGAxscvgkdaqpTBhhkoDxhQxpgipIETzhNNHjKASaCKKDwwhPQyBNbnQBEfWjjlliUAoCDkKyzcGSLFBjskOrmqs"), false);
    this->WJuYwIOFwfmHJW(string("ydkJpRIfipxLpAxqXdBEeljrgIIpekjLoiCfQpMrwAsjPkYTbdzkHWcKNodSWbdLrBrjnxftRVBZJczEftpuDZwTbxeYykHYLoPTOyNztqPkWvGSBhShYeAUinjapvGSZwvgQjurcRxZlVkwbBqCXemwaFTfuyHyBlWplTYDHeQWXoOJnVsklEGKRihniEnBUQylCxkEaRAFKOJPxAKgUnkEQgDfTEnvIAtLqQ"), 1885825854, 364696875, string("wJrlJBMtlUDthsSBSWsqjYvVJoaXfrwiGfBJrizXaLbWjhLmfOgbnBSpXHKzmkEKbAqZZUoZGSZLGFcSZXnHrvVmENfE"), string("djIpriTxwJMDWxpIdrpuhPuzayodMxoTrBWJCAvjxtYthYxuWRgwbjskqmrrsqyuzRGzwkQwHRvxcwHLDaaBllGqgWDDXPZNFLFhTtHfPTMgXodcvwDgqtTTvBRhGTKJkNzUfpbzEiKQrLLNCQbfdtauyYCiN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BLHDuyumDLf
{
public:
    string ByiaM;
    string VhwReBDpqi;
    bool eoJUAfLaXRnXxa;
    string kVuaIpfjGjL;
    string eOQpiVdpLtrken;
    int FjsQnCRK;

    BLHDuyumDLf();
protected:
    double jwTDntdXsDKr;
    string urVknTpe;
    int hDoHXyEHNljcyP;
    double lbhkaw;
    bool ywKqlayqnYfgfpPs;

    void baMCl(string UzFJkrY, int tIrjbhQhc, bool RVPrkRyaacrCU, string waYQjXX, bool WBXEnCuBP);
private:
    int VKrXH;
    double kNrXktUKviCPmr;
    string iEjeOescwHczMg;
    int TmFJhLir;
    string MmLYHkew;

    double oYaPktYEnwGzV(bool qelMEBV, string hVmOgqeLBYaX, int OJwAxNfNoXh, string DtBwAZy);
    bool hfJgvZlRS(string LaJhPxNmpa, string GyLFNUp, double OFPXkKvJCCd, int YajXFvQ, string bgmJrYXDARM);
    double ozfmnACEm(double oInXHatglqCsrMSk);
};

void BLHDuyumDLf::baMCl(string UzFJkrY, int tIrjbhQhc, bool RVPrkRyaacrCU, string waYQjXX, bool WBXEnCuBP)
{
    bool MLwpXlDcirTuSoiP = false;
    bool NvagSNwxHmXbG = false;
    string vnOEVcpgvkNLbc = string("ufSFTzXCFvFMTAZlMIwgEGazeGVNmuvBRfnCTAEFTgwyiYSCqzEkishlrZjFyWjdzPaVWUtZrjtgCimordEHHCvOfQpFfKgJnggmLqSvTYD");
    string hlMpdhdIzaDIEhK = string("QufCwQntiBypNBCxDRwosmkxtrfbqXPnNTgaHjVDlwiwlZhGyQeKipRAnBmCyinucgGRKGzIUpvcmsAEPeyPWhkRLcHnVgraLWXYrXqJOcIdZyNyOkFSIGElpwwpHDUfbRrEoUbIIufKoWUfvVHHyUfvvUOzaZRBcSBsACWRqWsrKuRyFxYrfceZqPksqzdDKYnvVPOylpKjqDbrfGabiuBdQNaNoOWxGYCaNVkdOAaGVADrUsUyII");
    string ubTHBrb = string("gEFCsYkosYWhCQBbVaspVTzGlQVPSzTIwCvWgzlNMXxxpJFqieKjVjUzYG");
    bool pzwghSpQvMoG = true;
    bool rIgoBxbMZFiuLO = false;
    string wbqZedacQiie = string("FcQgcGpyLyDELjDGb");

    if (waYQjXX != string("FcQgcGpyLyDELjDGb")) {
        for (int ZQQAaKpmWS = 248638057; ZQQAaKpmWS > 0; ZQQAaKpmWS--) {
            continue;
        }
    }

    for (int FThlcgcCYeSMy = 320115434; FThlcgcCYeSMy > 0; FThlcgcCYeSMy--) {
        NvagSNwxHmXbG = pzwghSpQvMoG;
    }

    for (int sLPrzGXk = 433117469; sLPrzGXk > 0; sLPrzGXk--) {
        hlMpdhdIzaDIEhK = vnOEVcpgvkNLbc;
        NvagSNwxHmXbG = WBXEnCuBP;
    }

    for (int kwaWGVFFgOdqjA = 1797729503; kwaWGVFFgOdqjA > 0; kwaWGVFFgOdqjA--) {
        rIgoBxbMZFiuLO = NvagSNwxHmXbG;
        MLwpXlDcirTuSoiP = WBXEnCuBP;
        vnOEVcpgvkNLbc = ubTHBrb;
        pzwghSpQvMoG = MLwpXlDcirTuSoiP;
        ubTHBrb = vnOEVcpgvkNLbc;
    }
}

double BLHDuyumDLf::oYaPktYEnwGzV(bool qelMEBV, string hVmOgqeLBYaX, int OJwAxNfNoXh, string DtBwAZy)
{
    string RwxgLhNkDQ = string("StDQtbZXpqttHTmHotqxCBpnNhelBNUqbvU");

    for (int pCtbnRvwE = 822621140; pCtbnRvwE > 0; pCtbnRvwE--) {
        hVmOgqeLBYaX = DtBwAZy;
    }

    for (int qOoSKzexiuHvX = 2042540294; qOoSKzexiuHvX > 0; qOoSKzexiuHvX--) {
        OJwAxNfNoXh /= OJwAxNfNoXh;
        RwxgLhNkDQ += RwxgLhNkDQ;
        qelMEBV = ! qelMEBV;
    }

    for (int rrJpwDYf = 1476794589; rrJpwDYf > 0; rrJpwDYf--) {
        hVmOgqeLBYaX += hVmOgqeLBYaX;
        hVmOgqeLBYaX += DtBwAZy;
        hVmOgqeLBYaX = DtBwAZy;
        hVmOgqeLBYaX += hVmOgqeLBYaX;
        RwxgLhNkDQ = hVmOgqeLBYaX;
    }

    if (DtBwAZy == string("iFNrwpmjmGpppgbYsarfswrgJPNvpynnhkTQZLjnddhQSroZnsRpoveqaSEQXjILnOPCWPbtODFuXGmYvEkdIgdLChWbXDwItvQyvPfSULVmmKpOdfVvWLMitqKIxcyYAkClbejWefqkrhLpsLYQCsMmeOWotHaVNxhvPZgxvKYHFGlRMXcKgnRocceflNiSUOkYrGeyFWuVgrRjjjuWpebzxRHrKch")) {
        for (int HGETHgtGiYPPzr = 1831440071; HGETHgtGiYPPzr > 0; HGETHgtGiYPPzr--) {
            DtBwAZy = DtBwAZy;
            hVmOgqeLBYaX += hVmOgqeLBYaX;
            hVmOgqeLBYaX = RwxgLhNkDQ;
        }
    }

    if (hVmOgqeLBYaX >= string("XyBDkRqVzWOdydQmdBqdfoeVVRYarlgqZRxnXhDraSHjpabTZToFWnZdfxdGFfMpQSmJHeHZwImoXCjJrbQihxiQDaHWOXsjQlsjtOBsqBvrNfSxNmIzpyFYBaAsKDHtvZktmZGZ")) {
        for (int iZjCZTEav = 944354453; iZjCZTEav > 0; iZjCZTEav--) {
            DtBwAZy = hVmOgqeLBYaX;
        }
    }

    return 807408.4365729957;
}

bool BLHDuyumDLf::hfJgvZlRS(string LaJhPxNmpa, string GyLFNUp, double OFPXkKvJCCd, int YajXFvQ, string bgmJrYXDARM)
{
    string aYcamm = string("nDWofSmPFbBniOWXRRMntbxuRkDQwyLNMEBniQuZqXVdCdbmQoFVhzHlCjIEuPTFFWECzbOLwRZPHKrXofPcseDHXngQxNQiJZCcqQRwkzFGUQLZIcduzHcrcpwQTFEmvpufbCkWSPXnyEQhZBnjtroHJJSVciccCVaCfnMkmnvHBMJRTHlVDlEoiVuIrCqowZBsBwxStVtgdmQITOJrXYduEZrHgJbQELFNsXhvTlzeZKNxrAONTFTDRFbm");
    int BOjTCDsGPdYo = -558961759;
    bool dAhRhODczedS = true;

    for (int CAmjz = 1615845228; CAmjz > 0; CAmjz--) {
        continue;
    }

    return dAhRhODczedS;
}

double BLHDuyumDLf::ozfmnACEm(double oInXHatglqCsrMSk)
{
    int jLQdGOMOk = -608410689;
    string tteSexTYivRoC = string("RUYxhsHxuJEsvdJlsuPLkmXrUxnAoFKghqQcSHlkfEanqcgoOpbcNCQTHwmTBXyojCgIkdvXavcgTItPnntOpfcHHMPawjgtgclTGzIggXHAJPeVLmXDucuwpIYZoXxqRmmTQvqSpgkaqtHYlIMTjlDL");
    string DfqZsNSqAhD = string("sNjUdtHYNvZridzUbYkMlWRnWVEGunPybAaDmVRzmYulridMROfwfYGmBfUqjJMyLgCIIJtRAhcwaGMKAtgzRKYtQZAcWQRPGOebccdRpeHJdzQrhmuAJclLCVVccbZedfqdtnnNWettZHeHMAksSckgehrFmIBBBLafwuVPUDpAZGfUNMeNgFxcIbiRURqpcXVIUpTaCjHCmpVSiONDWgkPCWCqIIVhWNIUpZwOPkVDIJIRqnUevIabtVKY");
    double PNYKBGqf = -362960.35686571355;
    string neZfmTzqCqIeW = string("lQJYBNaVAEdSgRboJDYv");
    int nksYpYCAYvNym = 110695786;
    int JcrsVrDRmsy = -886908676;
    int usDFpK = -905839703;
    double fAhJRWNYbZ = -25240.94581780566;
    string jtpwcBpKJw = string("kYrwqWChLbanqrhqwRQhpAULQcbomduZJqtxMyBbnbcplAkuPUsgVmhUHhKoJmFuJfFHblLzyAWPXxtoAOoepvEjckTrTEwmuLJsuAtgDBFwLOIUNUabWaYNYpLxKpBSDmaxcPtVXLeKSrmyVQOuZZutVQTnfRZSBXlrtWvpIoYDxUcNYKDtZZhUTjkkfYPoHrqvAZyGtnYC");

    for (int IyxiIX = 1377138126; IyxiIX > 0; IyxiIX--) {
        nksYpYCAYvNym *= nksYpYCAYvNym;
        tteSexTYivRoC = DfqZsNSqAhD;
    }

    return fAhJRWNYbZ;
}

BLHDuyumDLf::BLHDuyumDLf()
{
    this->baMCl(string("gdHaQaZnlkqqeFOGTqPbQrdrbQHWmemskwMRobzzwADFpPVvFCvBxBruMmuUQKXskltgLEdcuHMWlyanbZOxZhqCKhHNCPRDGcqikBjLCrzVLsITlCbBZTyEnwTNfSqHszHwAMPmQgSMtCbLkXDYIsmknaWvDRuGoUNdNlaQtdaiqSCSHUTKsqFIUcHrCJRRHxMcHkpUjjBtLeymDkFd"), 766888185, false, string("vmCnZhSsZrOWvfgbEPvypXjJigLHDNGzcJXJihFrFHwyRTMwtKhFtuOVHswrKLgSKkwSXZVcApZuUhlbgJhIxkmRAPjMdCnpfQTQMKAOezqzXulkqxjBpVhaspiPujLcldQMXmhTeBjPoGyhPivpmOEUPaBLTdxMoIGjMmwUymnvVikSukh"), false);
    this->oYaPktYEnwGzV(true, string("XyBDkRqVzWOdydQmdBqdfoeVVRYarlgqZRxnXhDraSHjpabTZToFWnZdfxdGFfMpQSmJHeHZwImoXCjJrbQihxiQDaHWOXsjQlsjtOBsqBvrNfSxNmIzpyFYBaAsKDHtvZktmZGZ"), 192209153, string("iFNrwpmjmGpppgbYsarfswrgJPNvpynnhkTQZLjnddhQSroZnsRpoveqaSEQXjILnOPCWPbtODFuXGmYvEkdIgdLChWbXDwItvQyvPfSULVmmKpOdfVvWLMitqKIxcyYAkClbejWefqkrhLpsLYQCsMmeOWotHaVNxhvPZgxvKYHFGlRMXcKgnRocceflNiSUOkYrGeyFWuVgrRjjjuWpebzxRHrKch"));
    this->hfJgvZlRS(string("wyxtZFVBFUjhFuiEbtIwNBhPphdUbufgENjKbbGjqerAjjhDrwklckyuGHQaMDpWFKlBJGEfssxGyHcldbrGLxrDeHARdNzZVqRwAfxkBeThSFZhdTOZhPFTKnXoOHOcXkflfoVhDTNvxgRjvBVULofYYmuheihjvfTECOxkzVOgYburIcDBGjWItJtbyyPYGzjJaNkTCQVNqDnypqMghvsYHlLrYbOXs"), string("RHGVRhWnlriMYxKFgaCnGNMjmoGjBNsNQgmXUUHYPgjauAaQeRPvwTOxQoavsqjvtFaIdSMGKMomMBttapFRWUpiqGKxYljmsmDxVAHYwLojXHjnMJuJwdwAHnWguXWdowxyRTHIICnHvMYKmZnXbBRVMEtLHoblOfioCdOLrlokzoHuwfVvHmTjsBNIrImJypooxHGDHdggVWjgytYhGMNYwJuOYlRLSfOPEatgEzZUKwPUbTTpFEsxrPv"), 220993.67108876628, -1567968479, string("NLSKhu"));
    this->ozfmnACEm(158691.49967875038);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CvtzViDs
{
public:
    string HfYIDjChWIoqXLX;
    string WliGyVZNVB;

    CvtzViDs();
    void tzslJs(bool mJetsWYMe, double qkLdpxeDTQvKWgTL, int OHkixM, string EHDtwVTgHjQo, string awYaw);
    bool igytzXKvPvXlG(string PjlkMsdSV);
    void SefrvXQXHQtqhuT(int eWAXCPzCUzTRdkoR, string MZhSZ);
    int WvnYdAOPYCVpVF(int FdELc, string IvOyHaVdpru, string UPnJnSCDH);
    string HcMTyHxMS(double QwllaUKPULW);
    void fgTsxGZNc(double hXXJhhkGrR, bool MmfpVuCLKqK, bool bMPLPvMjVkhavv, int lYEpqghKoUsMgyv, double fiidasddXXPO);
    string EcJyiCsyL(bool PuVeYDNpDfKTD, bool DOOEXNM);
    string eJqorzjZcvKmJcVU(double NaFgkQYHrXkUC);
protected:
    string gEEXBJtIi;
    double ufvBPxF;
    int unkImFpmTjuMOaEy;
    bool Fgpqh;
    string givbvqlrU;

private:
    bool HtBMfiyiYIXMg;
    int nFjUpStFenJi;
    double mxbqR;
    double ewxsZQxO;
    int pmBPBgMNDzQrvYI;
    int xJZkZzNxvT;

    string hmKuqaQiMvv(string tZRgtTSXCh, bool RHWKkAy);
    bool tCFuGP(string vTGkYJVvkGSAawm, bool OoFNVEUAvS, int IXiguLqNkYG, string TbUNs, string cfpGZQRf);
    string JmUcXsrk(int WJjyjM, bool dbvURBpuKg);
    int RXNjCnKHptpcYKix();
    int nBKLHqoEaHXpOdS(bool xYOJJGsQSjtRu, string RxPLTYeWJzIS);
};

void CvtzViDs::tzslJs(bool mJetsWYMe, double qkLdpxeDTQvKWgTL, int OHkixM, string EHDtwVTgHjQo, string awYaw)
{
    string jQaNCZNDC = string("pSAdwRJbOOPtzwnIsmZuSy");
    bool vIyWMoV = true;
    string VMGEx = string("BPKxAxTstEFBIqcjHnAwELJEYDmzeMGuVyTCBGRNhJMhZXYTLsFHGJJFCBiiNRpjVJSfdLHKllYwdbBkPuXXtBnOsjRNxwBGMaoGNWikRyhPzCnqYNiVBTypgZXWOkaZethBEPxaVKTrXcUdyxhhBbNGGtghKXCPPeTTVDzgwBYGBNCNPDtrlvgaauqSBdkYpFLgSzqhpvMDmmjUCYNrHbgHtbrYXGKzOZfstveIDUNQgXKAkBjkTZY");
    int QROqNUIuoDTvCmmD = -327883928;
    int TjgLOKeqya = 957290120;
    int bFqtYeMWGVY = -1425878409;

    for (int SUsaXVxZAheObco = 798820141; SUsaXVxZAheObco > 0; SUsaXVxZAheObco--) {
        bFqtYeMWGVY /= TjgLOKeqya;
        bFqtYeMWGVY -= TjgLOKeqya;
        OHkixM -= bFqtYeMWGVY;
    }

    if (jQaNCZNDC <= string("pSAdwRJbOOPtzwnIsmZuSy")) {
        for (int XJcTAWABnoWL = 1963715248; XJcTAWABnoWL > 0; XJcTAWABnoWL--) {
            mJetsWYMe = vIyWMoV;
            bFqtYeMWGVY += QROqNUIuoDTvCmmD;
            QROqNUIuoDTvCmmD *= TjgLOKeqya;
            vIyWMoV = ! vIyWMoV;
            QROqNUIuoDTvCmmD = TjgLOKeqya;
        }
    }

    for (int NTrysTgDagfU = 808153421; NTrysTgDagfU > 0; NTrysTgDagfU--) {
        VMGEx = awYaw;
    }

    for (int AnBsWzV = 642897517; AnBsWzV > 0; AnBsWzV--) {
        TjgLOKeqya = TjgLOKeqya;
        vIyWMoV = vIyWMoV;
        awYaw += awYaw;
    }
}

bool CvtzViDs::igytzXKvPvXlG(string PjlkMsdSV)
{
    double pegyF = -672086.9854639673;
    string eHcHT = string("rNuvxMnZxudOQBUBJwOkXHppbjZKCgHgmoTJibFxFcpljtHaoVrbjoGYJhccTtKjTaIFADeYws");
    string lHZJrOZY = string("kAotkdsnBjwYeIQtOPGxfjoqaMiLuNmvXAvBnJVorQuyrAtPhcEfodAxFHtzGJPJVINyTbJSgQRbsDiThjJUxPMNkYIEnAmXDnRvtHWvRQmHMBudofwSvCVfntkjBwEQweqsQcVSpQcvXuczLILwXffnNbuidFJABkWlxNjtwnnuvlPomFLmQsDgK");
    string aQxUuRvoYBbpfK = string("bTVDuieravNOSNHzxDZXOMyRUeWVZLyGbapANhtOdiyJvqqOOaSkAPnONAaowZpmtsXzDBKYaFNhDTpqUrplUqlpCxpGODFVOTg");
    string AKUCo = string("LYDQYvSUZVxsdgcqCoMsMZYZOlIrdWcwFuiEHZVNzjLndmu");
    string fumgORSwSNraGd = string("rwbGlsRSALCVtyhRHjanScSWvUfxiVmkaxyYUoPycSdNWVQrokTnINEHWCiPexpLjYVhWnglBUBCLhhkmHPstGplxfLwBXgJmFkrbDQDayhYrMQWqGJtVfguQeL");
    string yPyvGzkIoBzSmMx = string("JpznKEcLDqysgvqmrPbAlBJbyQQbEwDALyxIJReGTJCtlABBgPJCHofLaOwxJPPTO");
    string QmRaNNMGDQ = string("ORPMAscGPOsVIiiUPDuThQzIyxsKGkYZUBHRRlRklfMfFQDKucRzYTZGByHNPUAEMPTJXsyWsnBHBrxIvWLiwDDPDFgznjBfqABUNszoRvcdjPAzTQKSxhFMIlruCLNLXCKxbMoAWwqAnXGWzvXGsRDLXSypvBlxZwMzwCyAkHHexDPMjKEGQVhQMGuiQGoepQKKyHgOPAcX");
    string FVUXBigjDW = string("fPMFrdR");
    int xzENQLOiqkMArQOE = -1028411216;

    for (int SzlBgiyCWXVDLk = 1606533785; SzlBgiyCWXVDLk > 0; SzlBgiyCWXVDLk--) {
        AKUCo += PjlkMsdSV;
        PjlkMsdSV = fumgORSwSNraGd;
        FVUXBigjDW += FVUXBigjDW;
        aQxUuRvoYBbpfK += fumgORSwSNraGd;
        lHZJrOZY += AKUCo;
        yPyvGzkIoBzSmMx += PjlkMsdSV;
    }

    if (QmRaNNMGDQ < string("vdCXKsjbAvPiJKCDCDtqtqPMOUjvnHnArKcVkqDsZAotTEDLUctScUXVEWgUKEhMOJewtQwievRhqppMTiVAaELijspiMNzxWZvGqqoAQeKtDjKNmjruFdCkIDbiQcrBlNwPsNzVYGjKDvmOwTSyeNur")) {
        for (int fEfIviiJ = 156641944; fEfIviiJ > 0; fEfIviiJ--) {
            fumgORSwSNraGd += eHcHT;
        }
    }

    if (FVUXBigjDW < string("LYDQYvSUZVxsdgcqCoMsMZYZOlIrdWcwFuiEHZVNzjLndmu")) {
        for (int smdGgEVJt = 2001096768; smdGgEVJt > 0; smdGgEVJt--) {
            fumgORSwSNraGd = yPyvGzkIoBzSmMx;
            PjlkMsdSV = aQxUuRvoYBbpfK;
            fumgORSwSNraGd += lHZJrOZY;
            yPyvGzkIoBzSmMx = QmRaNNMGDQ;
            aQxUuRvoYBbpfK += fumgORSwSNraGd;
            xzENQLOiqkMArQOE /= xzENQLOiqkMArQOE;
        }
    }

    for (int RuuYGpV = 901696013; RuuYGpV > 0; RuuYGpV--) {
        PjlkMsdSV += fumgORSwSNraGd;
        QmRaNNMGDQ += yPyvGzkIoBzSmMx;
        lHZJrOZY += yPyvGzkIoBzSmMx;
        PjlkMsdSV = AKUCo;
        QmRaNNMGDQ = fumgORSwSNraGd;
    }

    for (int gPcFegqUfy = 789055968; gPcFegqUfy > 0; gPcFegqUfy--) {
        QmRaNNMGDQ += QmRaNNMGDQ;
    }

    return false;
}

void CvtzViDs::SefrvXQXHQtqhuT(int eWAXCPzCUzTRdkoR, string MZhSZ)
{
    int dnCujgKPgcUoNjhb = 573692776;
    string yBSigDzJhUNf = string("vgRNqhDXMYDFwlQFDcrFLTsRuzqILEljKcjTOtJIEzceoSuqALwAnoAzwJBINKhkmCxHQDggUExuswBeIscmBP");
    string YTUjBlyN = string("tYzdTITLLeMNywudQAkZhpMEczTgMDQcxlvicuYUXVeoNGzTnmOhOOAFJOUOZrjuiwnmedgDHeKCmUFygfuRizXXZAEZZyfAIsVcrWEfliIzuPtoajAvkxPDEHcFCVGrtrxcEZIjKUXinTkuDsGBNDPqRbgSDgcjrnYLHdeizjjRnicCJMjeHgqjMDgiseMvhcuCYoVNkbGrlVGRtWlBfoIHiBidRLctEUfsCgECVEVPJx");
    string fDxacLY = string("DZmAFNTlJLCjSsfipnCeoTHxDwQgivwQqjhlskyHhPNLqNKSRrIYnaoHvJgOr");
    double pxEsA = 403304.7971785313;
    string OdcFjxD = string("aGpsVTOMRHDgEIavBmjGrfdwLQtFMRDSRjmekFtZwfnxSEPiPlYjsPmnJyBZGBtsRNeOgEhzWlbhQwwiUxMuYlLRqIiKdyMJLeHCvyT");

    for (int iClbJVp = 454394702; iClbJVp > 0; iClbJVp--) {
        continue;
    }
}

int CvtzViDs::WvnYdAOPYCVpVF(int FdELc, string IvOyHaVdpru, string UPnJnSCDH)
{
    bool xVpcoWqUlKbSgt = true;
    int ORfdcCYjkdSaZq = -373609364;
    string pRUIttnOfICounrK = string("YiuYwKCsxLUWihAWippmLwilyFuNvZlfuAfelGKFWTIXeqBGQJNYZHlFyvvkeijLxTIZcRprkfwjFbrdkdmtTaoXpjekNDLMCWzOjVmueEYLRIzhfSuIXTbXxxJSthumMvLsumpstA");
    double LnuihVVjBDG = 138618.1067950707;
    double UfvNFSzZubsOwRKK = -563565.2044569949;

    for (int ZogCLbeXzjwIedoo = 1881548828; ZogCLbeXzjwIedoo > 0; ZogCLbeXzjwIedoo--) {
        UfvNFSzZubsOwRKK += LnuihVVjBDG;
        IvOyHaVdpru += pRUIttnOfICounrK;
    }

    for (int SefTPaFRv = 1899036359; SefTPaFRv > 0; SefTPaFRv--) {
        FdELc /= FdELc;
        UfvNFSzZubsOwRKK /= UfvNFSzZubsOwRKK;
        ORfdcCYjkdSaZq /= ORfdcCYjkdSaZq;
        LnuihVVjBDG -= LnuihVVjBDG;
    }

    for (int bpnBIlWQzim = 1110808652; bpnBIlWQzim > 0; bpnBIlWQzim--) {
        continue;
    }

    return ORfdcCYjkdSaZq;
}

string CvtzViDs::HcMTyHxMS(double QwllaUKPULW)
{
    double YgWtie = -285536.3358883954;
    string aUhjALfqmO = string("PtuSmzDCYplBIXDpZSsVPkAvtHSYZkHwKSNzQatSiNPMxzPdctGeFuMgNhvEWzRYAFdzvOsvhLJGAYMcOPYkArwvgZGbClqqeRfxlfvSCTJEHisvvmBNfjlDbHogjbgGFgGqwdMzzrMvSGDHC");
    string pqPQrfCkITuC = string("oylACxlLaJmNpVAcflFOkVKSbqlKhCLhhDNqFGbgnLVOBAFwIy");
    double dxWmXvapfZok = -477880.3119026254;
    bool ZohBSAVSNNiQbBSO = true;
    string pgfNzDMcahPuYDwQ = string("nhgoGURFhLYKqJObQqZBCdjpzstwBQwnJmbkcCBlGQjhAzcANywjbxgKRIUtGmvoWPyvVMEscjWpCLoHQjytYIGkRJEaZOlYVgErCQlHXLcHmmDMyOAFGNsrHBxLwSAKctuUtYFyKIfiKglJadbXIoprvCALlKhyHIfGUsTrTGtlElLcpLprogmmgwDFArpXXqezAAOnrKapKXGgGoiTAvfHcldOgRneSz");
    int YgwNzCi = 227080894;
    string tQnHQUurmd = string("KSxNYQUMNPDpVhuULBdFbfExyqKyzFpXhfKBlrKfJXTFYCjlTFeqNxDsxqUguTrYh");
    bool qSGbwcpIQHWFEvNl = false;
    double zWKIhKsJKeEa = -416427.2348266842;

    for (int bZlhyiMo = 304650960; bZlhyiMo > 0; bZlhyiMo--) {
        aUhjALfqmO = aUhjALfqmO;
    }

    for (int IxRMHyKscKyMrpY = 433642179; IxRMHyKscKyMrpY > 0; IxRMHyKscKyMrpY--) {
        tQnHQUurmd = pqPQrfCkITuC;
    }

    for (int FmFnmKdogFcL = 190640372; FmFnmKdogFcL > 0; FmFnmKdogFcL--) {
        QwllaUKPULW = YgWtie;
        ZohBSAVSNNiQbBSO = ! ZohBSAVSNNiQbBSO;
    }

    for (int OvsMybuQRSCUr = 1558870127; OvsMybuQRSCUr > 0; OvsMybuQRSCUr--) {
        pgfNzDMcahPuYDwQ += tQnHQUurmd;
        ZohBSAVSNNiQbBSO = ! ZohBSAVSNNiQbBSO;
        aUhjALfqmO += pgfNzDMcahPuYDwQ;
    }

    return tQnHQUurmd;
}

void CvtzViDs::fgTsxGZNc(double hXXJhhkGrR, bool MmfpVuCLKqK, bool bMPLPvMjVkhavv, int lYEpqghKoUsMgyv, double fiidasddXXPO)
{
    bool slAEIpD = false;
    double SnzgnBtId = 32404.917803316315;
    double UAUJtAaSzGJWVSw = 803350.17809465;
    string nMXIDnGzB = string("xKPIxeDwYAAuEwSZhnAGGAauknzfUoTGpgUPwLsxtjbWkuEAqOSuCuIbUbsbxmycQFMScFDPQZXfShjkPOulLXqhhzKnoiawAsJkflqluGKpmgWfbAMrkxsEGdCpntjjoOeHnHNbRjNRXZISVKiYQYaxSnxKtenMauxBfVshWTiYYjhsndNPryltj");
    bool lUqfPFy = true;
    int NuFik = -572163019;
    double fXKCawsYKa = 629390.209921309;
    string HmJtz = string("lcNsolURKZhjfnwseBnqoeXyGxXOcFnQmgEouuydPyqkXtyukfKPWykrSnOweBJukwLbwlqElKUiEPvLRoLTQFppArYwbxqHauAgHhzxtAydcGMCHPDOVoqxVxfmpFUyvmqxUaRzNyJMFvryvPoQxNOSIJgcrPpkNuzZBRLNXzLooJsVywZIzEdjEHWuIlxjkzMkaxPytbmfswLNJQYKaUCoPWzcZj");

    for (int AvdvnsNEH = 970380938; AvdvnsNEH > 0; AvdvnsNEH--) {
        fXKCawsYKa *= fXKCawsYKa;
    }

    for (int xtFKjwJ = 20926639; xtFKjwJ > 0; xtFKjwJ--) {
        continue;
    }

    for (int esSZCGEN = 580672813; esSZCGEN > 0; esSZCGEN--) {
        continue;
    }
}

string CvtzViDs::EcJyiCsyL(bool PuVeYDNpDfKTD, bool DOOEXNM)
{
    string wwLUpahJ = string("xpjtQKWMFjColLYCJSgDIeH");
    int aesYmGrjWj = -220562615;
    string IFsdXKgGNNATKMe = string("UzlcjzPTLfpdUvDgllFUNyqGlChBvIdIzTGtSlWvlIHDcownUUeKYElZMHCVjruCuaFZxPFsmFTxYiTaNmcVGkfTWpVMUBVTyfinsrRLEgzUAlVVZJzlfdLwDThlIoxoBvUSBOngNfcJbdsGmxnfMNSQwojhoGxIQRpGejcfjKeaomoIYPNwOlqljdyHGgakULpGhOXPManiBXTiZHXFYyvjFKf");
    string ggigVG = string("TrkZIdwAvsxiehYZAKpibiwfBIiBhoyqujtINIBGWenXgeDVOKgHrNHSeaGTYkVmvjxuIaWllaTAeUyMdPwBKvLwueJezBTpwPHTcOeMJqrTtYPKrpjPTRtiBOXesY");
    double XXoXybfwsEJ = 558386.2780994618;
    string nEIjrjpkpJOrnzW = string("zaQnkrdpbSqwViTQHFXUuVSJpDvdmifVnryGxQiQGlqJedUhZvYrnDWjOKpIrEnFfFRXAEuiIMhGVHTAUQVDlQzxfakqbnUEpWCKMbHkorwbJLevgolejxJBGVpyKNBcvBPlSWZhmThJycHqzshvaOPNbtucWNUiMRiCauftsyq");
    bool TbMURxrWZHaWSSD = true;
    string LpeQunToZB = string("DKWsrhDcwjwOmdUxhTMBYGvPeBZtERPbbNuSXGeaAtsh");

    for (int wvCddUT = 1892152520; wvCddUT > 0; wvCddUT--) {
        IFsdXKgGNNATKMe += IFsdXKgGNNATKMe;
        TbMURxrWZHaWSSD = DOOEXNM;
    }

    for (int xHiwUYH = 1891974575; xHiwUYH > 0; xHiwUYH--) {
        TbMURxrWZHaWSSD = ! DOOEXNM;
    }

    for (int USfUT = 1472050488; USfUT > 0; USfUT--) {
        LpeQunToZB = IFsdXKgGNNATKMe;
        wwLUpahJ += nEIjrjpkpJOrnzW;
        XXoXybfwsEJ *= XXoXybfwsEJ;
        nEIjrjpkpJOrnzW += wwLUpahJ;
        wwLUpahJ = ggigVG;
    }

    for (int VHWmcRWXEd = 1934934846; VHWmcRWXEd > 0; VHWmcRWXEd--) {
        continue;
    }

    if (IFsdXKgGNNATKMe > string("zaQnkrdpbSqwViTQHFXUuVSJpDvdmifVnryGxQiQGlqJedUhZvYrnDWjOKpIrEnFfFRXAEuiIMhGVHTAUQVDlQzxfakqbnUEpWCKMbHkorwbJLevgolejxJBGVpyKNBcvBPlSWZhmThJycHqzshvaOPNbtucWNUiMRiCauftsyq")) {
        for (int uECSDdVwebhz = 376189193; uECSDdVwebhz > 0; uECSDdVwebhz--) {
            IFsdXKgGNNATKMe += nEIjrjpkpJOrnzW;
            ggigVG = IFsdXKgGNNATKMe;
            nEIjrjpkpJOrnzW += wwLUpahJ;
            IFsdXKgGNNATKMe += ggigVG;
        }
    }

    return LpeQunToZB;
}

string CvtzViDs::eJqorzjZcvKmJcVU(double NaFgkQYHrXkUC)
{
    double VqlzMVmlh = 281679.4502410835;
    int YgHtqK = 1019126233;
    bool KpXSpENT = false;
    bool DImyGErx = true;
    string YpxxQawHvweB = string("iuCsHEiXLLfHYBSbsQWczMsDYfkmbrkNdUqAHRqQcgpdtuSMWPWHbNNvUImoolzsHXqjcjzsjpWaaFyqsMSXfmwdUwADWjdJMsWpAkKURRXcDnFvbIxTFoSZKSEGTsbkJWnNxeqGJbUhtRrFjJRAzWkAQvmfTsVAChGUIWlzijiWnkeuKsfHJqHaDBIGHHchWJSqkMBqCLTowXMvsOqWwfUikIAxodiSEiC");
    string iyYCdWE = string("sASsWKuRXnPMPKlynSJaHFZaaTscMSwafNWOTMNsaOkkrSqkxDFFPLhRqJBUFYhFomPEWiWuzuXFhGRXrGQVFouxQalQcfVlCpA");
    int VwpKa = 408766428;
    double yfKSLGSpXg = -354123.6830616035;
    string qegZYsFsGbYK = string("UqgUJYWfljstFBHNUAdsKrpBbkHpSMbloVqbCxmPKHhcJsqiGVgqOIkpqBbEsiRubJsOjTNf");

    if (YpxxQawHvweB > string("sASsWKuRXnPMPKlynSJaHFZaaTscMSwafNWOTMNsaOkkrSqkxDFFPLhRqJBUFYhFomPEWiWuzuXFhGRXrGQVFouxQalQcfVlCpA")) {
        for (int xSEOisPpS = 1369307846; xSEOisPpS > 0; xSEOisPpS--) {
            continue;
        }
    }

    for (int tXPVfpWne = 583214542; tXPVfpWne > 0; tXPVfpWne--) {
        YpxxQawHvweB = qegZYsFsGbYK;
    }

    for (int XhCfrr = 1788666678; XhCfrr > 0; XhCfrr--) {
        yfKSLGSpXg += NaFgkQYHrXkUC;
        YpxxQawHvweB = iyYCdWE;
        VqlzMVmlh = yfKSLGSpXg;
    }

    return qegZYsFsGbYK;
}

string CvtzViDs::hmKuqaQiMvv(string tZRgtTSXCh, bool RHWKkAy)
{
    int owIMYuILXmyW = -1622429421;
    int CspLACGxXXi = -1784102689;
    int xsOfwQsrlKa = 320322622;
    string GJtmhmZfBrHDA = string("hMgwNBhIdEPcyDTfQdzcMINKgyhygkqqJIwWdNNcbMlKbkjCtszebSwHmppGlrNCaffToFlsWjaSWjlYKQQwwUEOacKWNnBXgWABhgoUzYIkQPRIWvLPXaVWecjVNUeoyoKVzESkvlcVHPYgOSmDqsLhNmwkVFuNVPFbMrZONUGCLkTzSnReSV");
    int daDzc = 271365110;
    string MbSYMRq = string("dgYpgNLaSimUSIHZJnSSNFxpewAeswyZhrwnzXlpYDSaqkphcnFEQlUufLnSshWATBYPZsVQcgPzXiEhXUZSoyPUqTrrwwqxdCGXaEUyfGOtBzgSHwJjwEeQqJNkbgKYIaUsOgKrTxCFPxvkLnjGqkBHdIpplLiGuUBXeOyLvZXPxKnBGWmcVOvqZJuswCIufUdmmMrkXYZMHavqyKyiQqVCOWGTjacjxFbtNXvasfjgBJVDJg");
    double ukYPVflKFA = 470194.1596777053;
    int lMptxeDY = -1917529071;

    for (int wrigBBBdKsWTCUU = 2000796682; wrigBBBdKsWTCUU > 0; wrigBBBdKsWTCUU--) {
        daDzc -= daDzc;
        owIMYuILXmyW = CspLACGxXXi;
    }

    if (lMptxeDY != -1622429421) {
        for (int fdqNRsXycCFdtNt = 5952806; fdqNRsXycCFdtNt > 0; fdqNRsXycCFdtNt--) {
            GJtmhmZfBrHDA += MbSYMRq;
            lMptxeDY /= xsOfwQsrlKa;
        }
    }

    for (int KRCykvoGeAvCj = 904449439; KRCykvoGeAvCj > 0; KRCykvoGeAvCj--) {
        owIMYuILXmyW /= xsOfwQsrlKa;
        owIMYuILXmyW /= CspLACGxXXi;
    }

    for (int nXVMwCPIfI = 649037837; nXVMwCPIfI > 0; nXVMwCPIfI--) {
        RHWKkAy = RHWKkAy;
        MbSYMRq = MbSYMRq;
        owIMYuILXmyW /= CspLACGxXXi;
        owIMYuILXmyW += daDzc;
    }

    for (int IrVjlt = 179356357; IrVjlt > 0; IrVjlt--) {
        continue;
    }

    return MbSYMRq;
}

bool CvtzViDs::tCFuGP(string vTGkYJVvkGSAawm, bool OoFNVEUAvS, int IXiguLqNkYG, string TbUNs, string cfpGZQRf)
{
    int KqbFclymEianOZ = -1253766092;
    bool HDQGiqLRuPNLi = true;
    bool lyYgVUlNhedib = false;
    int aQvOUSzoCzmfn = 424301564;
    string OjRYjwMteoxxO = string("eapVJcuVXkrIBjHrEnOkwUMHBVCqBRnvoUEgFmkOycUTvfM");
    int TdjzFmA = -2136094787;
    bool yzAcwz = true;

    for (int hMFCuSxInII = 543231458; hMFCuSxInII > 0; hMFCuSxInII--) {
        continue;
    }

    if (aQvOUSzoCzmfn == 408612995) {
        for (int obyCRrTl = 283128521; obyCRrTl > 0; obyCRrTl--) {
            OoFNVEUAvS = yzAcwz;
        }
    }

    if (aQvOUSzoCzmfn >= -2136094787) {
        for (int pWPNhnBS = 1977041531; pWPNhnBS > 0; pWPNhnBS--) {
            continue;
        }
    }

    for (int VqQBxbcuSSPeo = 394520937; VqQBxbcuSSPeo > 0; VqQBxbcuSSPeo--) {
        OjRYjwMteoxxO = vTGkYJVvkGSAawm;
        OjRYjwMteoxxO += TbUNs;
        KqbFclymEianOZ -= aQvOUSzoCzmfn;
    }

    for (int ZQyleJyb = 247314758; ZQyleJyb > 0; ZQyleJyb--) {
        TbUNs += TbUNs;
        vTGkYJVvkGSAawm = cfpGZQRf;
    }

    if (IXiguLqNkYG >= 408612995) {
        for (int kFJSXIZV = 1199731629; kFJSXIZV > 0; kFJSXIZV--) {
            OjRYjwMteoxxO = vTGkYJVvkGSAawm;
            lyYgVUlNhedib = ! yzAcwz;
            vTGkYJVvkGSAawm += vTGkYJVvkGSAawm;
        }
    }

    return yzAcwz;
}

string CvtzViDs::JmUcXsrk(int WJjyjM, bool dbvURBpuKg)
{
    int KyrrLiVNHCgEYuvc = 1098092369;
    int LKYyEDtrAMmGgtg = -885041323;

    for (int IGKLQUC = 1969933505; IGKLQUC > 0; IGKLQUC--) {
        WJjyjM /= KyrrLiVNHCgEYuvc;
    }

    if (KyrrLiVNHCgEYuvc < 503274396) {
        for (int mYTxZBE = 1450111878; mYTxZBE > 0; mYTxZBE--) {
            WJjyjM /= KyrrLiVNHCgEYuvc;
        }
    }

    if (KyrrLiVNHCgEYuvc <= 1098092369) {
        for (int bowyDeieoLZmejJw = 1898939115; bowyDeieoLZmejJw > 0; bowyDeieoLZmejJw--) {
            LKYyEDtrAMmGgtg /= WJjyjM;
            WJjyjM *= LKYyEDtrAMmGgtg;
        }
    }

    return string("bBZUNQjbDscJaWKqyXCgNhqbVPCBLnmKGQWkTGEPJqZhyQbUowvgsKzsleBnvnknQiALNarSXGxxMlTfeWjHjUFyhpDzbNahIHswHQOsmCLhClgmvMNLiXjayFrLxBhtwUcJARgAKHBOiHEt");
}

int CvtzViDs::RXNjCnKHptpcYKix()
{
    int LKazh = -698322280;
    bool ErCZG = true;
    bool peHuPz = true;
    double YaiAgusIcDk = -686107.9315029735;
    double BNPkv = -930346.6307187362;
    int VnMmJrfKPQGTETcr = -1387362973;
    string QCIFgLKxAveRr = string("pagdVVtVEMiypaZRxZjWmAcBlBHtfkqXPPXVKPOdHxIDhPzRkgEVCgEgANzVpfZVBufDshPkyFMaFQkCXcCzQEfjwjhiCfWxzfeNbVVsueqVxEKozoxRsBJMKHlMCttTInKKPXgmttwSEBCshFzaytkVjtPHWuzRkcGHBeSXILYqcGDzREUatPDprmgqYljEvuHSxYaZLRmOMZDjkWykAoTaQJuNezMLfBRvzSUOymIFaqvGjYKMYst");
    string dLNENB = string("brTalTTlhJEgqUfAxCHIMDpDPCSsHIFYJeVbqBkjNHjvlllWWHdLVqvzqFKuGPvOdEPZeJpClzIKzCgBArtvRsseBihkHBbTRJQeruYTPTHjPfrvjtixcJOgcDovMBSwFxbcVhJSQmqgGtvCqfDHmQXwkrURrkwFrXtwykmAALdDpwOKhbyduVKjRMrdBQDknjztudhsTmQUIQzPwzacmaYuPzvAzpQNpXUukZjEtJXw");
    int NNZrDhWzaGt = -1048378587;

    if (NNZrDhWzaGt > -1387362973) {
        for (int txqLYfrFDVuGVAUt = 408992455; txqLYfrFDVuGVAUt > 0; txqLYfrFDVuGVAUt--) {
            ErCZG = peHuPz;
            LKazh /= VnMmJrfKPQGTETcr;
        }
    }

    if (NNZrDhWzaGt >= -1387362973) {
        for (int VvzkAMTCKNVJ = 1177482768; VvzkAMTCKNVJ > 0; VvzkAMTCKNVJ--) {
            QCIFgLKxAveRr = QCIFgLKxAveRr;
            VnMmJrfKPQGTETcr *= VnMmJrfKPQGTETcr;
        }
    }

    for (int EeEStPLN = 313042280; EeEStPLN > 0; EeEStPLN--) {
        VnMmJrfKPQGTETcr *= LKazh;
        YaiAgusIcDk *= YaiAgusIcDk;
        YaiAgusIcDk *= BNPkv;
        YaiAgusIcDk += BNPkv;
    }

    return NNZrDhWzaGt;
}

int CvtzViDs::nBKLHqoEaHXpOdS(bool xYOJJGsQSjtRu, string RxPLTYeWJzIS)
{
    string bAXyUwXWuQKS = string("DovumWlhUpEYXMXONkpzONyPaAyWjyiWZNZObezmMMujppiIletehZTX");

    if (RxPLTYeWJzIS != string("DovumWlhUpEYXMXONkpzONyPaAyWjyiWZNZObezmMMujppiIletehZTX")) {
        for (int EtjSpYNNwMi = 1072913662; EtjSpYNNwMi > 0; EtjSpYNNwMi--) {
            bAXyUwXWuQKS = RxPLTYeWJzIS;
            bAXyUwXWuQKS = RxPLTYeWJzIS;
            RxPLTYeWJzIS += RxPLTYeWJzIS;
        }
    }

    return -972060926;
}

CvtzViDs::CvtzViDs()
{
    this->tzslJs(false, 398792.52397879056, 1653006231, string("JXRISKwSlvdJaWoriQNFuOqdhlIKkNMsXkMIbHONRPefkkSdYsWmUU"), string("oPoeWiNxyHqWakFf"));
    this->igytzXKvPvXlG(string("vdCXKsjbAvPiJKCDCDtqtqPMOUjvnHnArKcVkqDsZAotTEDLUctScUXVEWgUKEhMOJewtQwievRhqppMTiVAaELijspiMNzxWZvGqqoAQeKtDjKNmjruFdCkIDbiQcrBlNwPsNzVYGjKDvmOwTSyeNur"));
    this->SefrvXQXHQtqhuT(-1535665415, string("YfgloWmmwKMMZxPhWvYFNDhjkvxHiabCJGeHZrLqsefAzxdgLmJOvQjRyjkYszdPSSkpLRlEzmvFWkmaWpqSNtKDGTBpoCILWTsdPNtutNAUXLLGRXukzLfpjExKfkwrktgwWswmBlpicJojQJzaJDawmFpnYLlojTuyVSrNQjGnVNlwZSfpuXYToXVrthbYclSgymj"));
    this->WvnYdAOPYCVpVF(1549408091, string("TpICsYnygqjfJtqdceVYOOksBSeDNEkRhMwyZgolxnoCmnrUYqnjCLCLNLpsrxKrDyyWsHAppTcuWlVAWAMKCCyBdlTIxdPYEDQbeNWDlrAGToSJczaesBdOBefxjQDKVWvsDmlfsWkTzNfexBoqKRdhHoKhTt"), string("PDeRoSBsEgNryKJRRPqoinrFjkMNgjyLlfSPgfyWTBQBKEwDGqdomOumlcwlZtDApkBXqQqnFUXUBAgjVngjmTeJoOOqlUzkAmgXMmrZkaEhJC"));
    this->HcMTyHxMS(-911632.764793114);
    this->fgTsxGZNc(-517210.5862091605, false, true, -345362865, -438049.2525048718);
    this->EcJyiCsyL(false, false);
    this->eJqorzjZcvKmJcVU(-942408.4105824302);
    this->hmKuqaQiMvv(string("cuBdObEWmUj"), true);
    this->tCFuGP(string("YmlXdwtoGcjJIe"), false, 408612995, string("gmOXvudzHgWxsksXOpPdmfHOdBvRjDVzpajDULiflgTkasjWyUFLIbIRvleQSOSYRKqyOpeoQlcCGKwzkVNNuvAGVUNpzvbBnNohdnrdrlNEDTVgOStfLuvSMemvMFhEUTzywbUDQOJfLgjgyEcuusFmRZpAVJfxSv"), string("eTEVdMChTqptVIjFSFfiIfrHknhJefqLhUuAQFSFBiGWICywFmzyYzKETyynmlEdfVRRKSwMpeIgNLBQVyqkbFnxDRFkHADylbhZjGUEMbdmYVZTSeRGpSepqChsIMCaRAIcYpkOUmsKGIvdNWZDYenYJljLXoIWn"));
    this->JmUcXsrk(503274396, false);
    this->RXNjCnKHptpcYKix();
    this->nBKLHqoEaHXpOdS(true, string("rATkCfpzvzQPRyUSNIpFHRLWMDevRkaFJpeNLytskZtnRhFTrTJdFQuFuWZzVLCpuGnFpYfncLnUDXlETmPRsMPY"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WOPCrUgsIPqsvvg
{
public:
    bool ChKEfe;
    double AJzRIJqMl;
    bool lSYof;

    WOPCrUgsIPqsvvg();
    void iRHYL(int MOVTIeYTZusWyXj, int nHEJVksjTB, bool daXSQ, double cUkJZ, int aiAlrQmixpyI);
    bool ezNNCMQJKTHYQSpo(int kOQpgFsyX, string CIbOryuxyxNBtWy, double LgJKyQSNuyOzOuK, double HDQdRaOc, bool hoZVXAQzLZ);
    string ZAAWrMPiMqKrgpZ();
protected:
    int lKlIDOE;
    bool dxGykTVfaLOc;
    string uWkjNCyGmWR;

    bool gEWTIvpR(bool UQUGpPGtlj, double vEsPyMoN);
    void SEtrSlEjfasQ(bool ZfOpsEmZBI, double oeUOrXaYndPaQ, string dQtSqrDCVIq, bool EDsvVEnxbHGy, string RtKPwE);
    bool uDWVrvVZsRAhgNjx(double cNQzuimonVlp, double NQxlpqAYjFYBaYMZ, double qQXJIjXDJeASU);
private:
    bool QNeoDOohym;
    int oOnifLbiTRXcrd;
    double ltiEfwoRfp;
    bool ccUZcsXORqVK;

    string gfuQFVogD(double wvakTi);
    int ENMvBXTnvzfpxFAo(string iozsnIz);
    string fSkUPhq(string HftPWyF, string cbikiSugllkYwV, string twsWvkTihuXhV, int ltJGvTNqERkM);
    int rRgNSalSNuQryPG(string DNZEiIMKZHgIoA, bool omvkwCFn, bool QulAcN, string UMMUlljO, string QjLGZomIhedepiZS);
};

void WOPCrUgsIPqsvvg::iRHYL(int MOVTIeYTZusWyXj, int nHEJVksjTB, bool daXSQ, double cUkJZ, int aiAlrQmixpyI)
{
    int wYrBRPVxtVcMB = 1877644953;
    int SDmXHIX = -1549036812;
    bool NfBEMoUwwrkK = true;
    int vVPeTaz = 1449021484;
    int HMfLj = 1036050281;
    bool lNPxGIViQawHJNmn = false;
    int HRFzmzDjVyTHH = 82598903;
    double EaPELPaOu = -832551.3649618495;
    string tIRckLSgFW = string("SxFofAnoBaBSTSFQFmfUxpnxHARVmtdDUNkZAZpRiTGxvkrlUHPhXwFGetfptjdhXmucNFDILHiAsKCdHGvkFoFwnkCdYkXYddUfyCDTtfxuGhJqChdsVNuqoHVhRzFXqEheMQnviNeuTeLKuACQQdpVZpurVZVFfnyRgUVPDWmGJREgHaeuTEPMkUXYUcLqHxkWDatfHHfQsHALDjPrvRcccCIJdgNbCPwJsPwCwqb");

    for (int DWPxazRAuaBwbrVc = 650108340; DWPxazRAuaBwbrVc > 0; DWPxazRAuaBwbrVc--) {
        HRFzmzDjVyTHH *= HMfLj;
    }
}

bool WOPCrUgsIPqsvvg::ezNNCMQJKTHYQSpo(int kOQpgFsyX, string CIbOryuxyxNBtWy, double LgJKyQSNuyOzOuK, double HDQdRaOc, bool hoZVXAQzLZ)
{
    int ydWzjnwfl = -385729459;
    string aZgOsLFNfnTUzw = string("LnmLsHIPnDiICfoZmaJLUOHNhvBtvedxP");
    double ifmaYFMqjMElExhX = -81002.94709210371;
    double ZbVtzrtxenewW = 247770.1432730635;
    string POyiEfNFjhaViVmf = string("paWoQreWCwAegRblKMiIUnBTNBFbCNAxJrytdhIXlCANxobKCNS");
    double TpwVckVryKwDt = 895751.6168108614;

    if (ZbVtzrtxenewW >= 201808.20906669067) {
        for (int OKILyelh = 678918003; OKILyelh > 0; OKILyelh--) {
            POyiEfNFjhaViVmf = aZgOsLFNfnTUzw;
            CIbOryuxyxNBtWy = POyiEfNFjhaViVmf;
        }
    }

    for (int qSvNZQpx = 686809244; qSvNZQpx > 0; qSvNZQpx--) {
        ifmaYFMqjMElExhX *= ZbVtzrtxenewW;
    }

    for (int xFDlbCNZ = 731552918; xFDlbCNZ > 0; xFDlbCNZ--) {
        LgJKyQSNuyOzOuK /= TpwVckVryKwDt;
        aZgOsLFNfnTUzw += POyiEfNFjhaViVmf;
    }

    for (int lDEDyLmG = 1913845819; lDEDyLmG > 0; lDEDyLmG--) {
        LgJKyQSNuyOzOuK /= LgJKyQSNuyOzOuK;
    }

    for (int ZsaqIZNMU = 1372029167; ZsaqIZNMU > 0; ZsaqIZNMU--) {
        aZgOsLFNfnTUzw = POyiEfNFjhaViVmf;
    }

    for (int tZFRtCgRbS = 338336354; tZFRtCgRbS > 0; tZFRtCgRbS--) {
        continue;
    }

    for (int QhIeD = 935330790; QhIeD > 0; QhIeD--) {
        POyiEfNFjhaViVmf += POyiEfNFjhaViVmf;
        aZgOsLFNfnTUzw = CIbOryuxyxNBtWy;
    }

    return hoZVXAQzLZ;
}

string WOPCrUgsIPqsvvg::ZAAWrMPiMqKrgpZ()
{
    bool lVAxPnYR = true;
    string HqYQOzw = string("SdWwFKYfYAQmjnfQtXrPHOWKTKyQwMKqGRsFgALAAMopMZofufVriLoGgBExLavqkcdPmbPChCzSqladLPwgJoRVwKXunXWuiXssmMiAPxkXsuCxcLFTrUPplfXSbHBXCbbdRSNOIpGSOrVXASFWOpqPDPtzwACjQJRUts");
    string EwjGpzrdsNy = string("ouGMxrFzljArbzoZDXsapPaCuJvIDoczuKkvhzpJoJbijoopVDRbXKQctHnzJbZChcqjWnUAu");
    int sXqxBT = -465372768;
    string nsEKdVLRQiJJT = string("alEGQDTpeNngNwdJBnDdldDfERJWKJYHnldJQqetpdmgbFjSdnMDgGmCWeCxwYNSgArnzwQduSjkrPoriJPGfEGYoEDcIloXyurGzRtLmKZWVVtgmVMJVhoCvpoZCMnWlrnBHNTNClULrScexFzzjjBjyDjwZwSWrDzrPEyaiHotrMTxveYFIge");
    bool pJrdW = true;
    string bKaJwHul = string("uXvqorOMyvvAHNFhhbfWuuxY");

    if (EwjGpzrdsNy != string("uXvqorOMyvvAHNFhhbfWuuxY")) {
        for (int CySeJy = 1568901971; CySeJy > 0; CySeJy--) {
            continue;
        }
    }

    return bKaJwHul;
}

bool WOPCrUgsIPqsvvg::gEWTIvpR(bool UQUGpPGtlj, double vEsPyMoN)
{
    double BpBhWCiFyx = 938513.9465945072;
    int meJtuKukISwY = 1882318522;
    string gZPHgwc = string("KQitFQqujixNijAilRzwrmNLQgyWsxsOFSTqKvCOoYomOuoOwSYhGLuZZXnObzPhnqgzXCQrGjLiHrirgzKPWchKlJMpgIAzfTTzSifqgLLgojPoR");
    string mSphOCmmirrCeE = string("rEHljNHFinWaakyBjbAngeHioPBNVUSpCAzvSVDoJkLyOlXUwVhXrwfuIAZIRRDhLKmkrjmNtFZeLBqGHlmpDlXHGtOeESCjfnoQzZiKfXUjeXLsSBoIqGNzuYQtZPaS");
    bool kcFJIrALmfS = false;
    string qELXmi = string("xwCdtCvMHBWqGijQAxfihzdxzjZLcbZNpAEzQANeeBfECdQH");
    int rRIBp = -397806791;
    bool RKgxUrKyNHLhmun = true;

    for (int QyIiMcwzHkb = 1336177097; QyIiMcwzHkb > 0; QyIiMcwzHkb--) {
        meJtuKukISwY -= rRIBp;
        rRIBp *= meJtuKukISwY;
    }

    if (RKgxUrKyNHLhmun == false) {
        for (int BQTjkleqVTuQM = 2040743915; BQTjkleqVTuQM > 0; BQTjkleqVTuQM--) {
            UQUGpPGtlj = kcFJIrALmfS;
        }
    }

    return RKgxUrKyNHLhmun;
}

void WOPCrUgsIPqsvvg::SEtrSlEjfasQ(bool ZfOpsEmZBI, double oeUOrXaYndPaQ, string dQtSqrDCVIq, bool EDsvVEnxbHGy, string RtKPwE)
{
    int YhOmPpOC = 1128850820;
    int MTpzJajTt = 601807376;
    string kfaLyTpBofSFmQjK = string("CWtNuNYYcYyoVZbhGoIGAhPrxKEhnXFlvVXXqyrSGzktAaSdUxSJwpGrpUjFOCmNknGejbdGAjKSRuCQlPWkaVTEaHF");
    string mErlYCDm = string("bXnIznQrSXcCuYyQZEAAO");

    for (int leMdZUIEXUPtBPu = 952482043; leMdZUIEXUPtBPu > 0; leMdZUIEXUPtBPu--) {
        EDsvVEnxbHGy = ! EDsvVEnxbHGy;
    }
}

bool WOPCrUgsIPqsvvg::uDWVrvVZsRAhgNjx(double cNQzuimonVlp, double NQxlpqAYjFYBaYMZ, double qQXJIjXDJeASU)
{
    string LIGulkWaov = string("vSMsExPjPpuwSJKTgonwSNOeaYLlShxcZBkhEJjnQPQVDaYdQSzSMQulnaVXaeVphLFehSiNAaQnwpriFOOlvTAVRDtvrZJoGeivsNcPXLTIRJiOFPhHeEozuzyyHSOtIGNvvJMziQzkKkCrsTgxlwdaFNdTiQEGxWlkESVkPNauFYNeLGdJDCljMzYZwZKeLuJJCVdZspGpbkjtfbcMC");
    int QujpETIDFTW = 872214219;
    string AEgqpHLLBuTKWmod = string("gTCoPLNjJSpfScMvEP");
    double rZbvfcbEqbMkqXm = -637094.035694597;
    double LswBJzTLhyYP = 249449.8058822381;

    for (int UNuLuZKOcPQyv = 761163051; UNuLuZKOcPQyv > 0; UNuLuZKOcPQyv--) {
        QujpETIDFTW = QujpETIDFTW;
    }

    return true;
}

string WOPCrUgsIPqsvvg::gfuQFVogD(double wvakTi)
{
    bool IwxjhoW = false;
    bool mfJbJykM = false;

    if (mfJbJykM != false) {
        for (int MkDBOZIjESEflN = 603422776; MkDBOZIjESEflN > 0; MkDBOZIjESEflN--) {
            continue;
        }
    }

    return string("uioggzDmUvsIZ");
}

int WOPCrUgsIPqsvvg::ENMvBXTnvzfpxFAo(string iozsnIz)
{
    int VvYAuM = 224024684;
    string weDzF = string("ZlermyLONYPGWDHsyMkZbjdUTmbYdpmkgxVUtMqFGArLjTDiqHRMPlAkcsFpItXDqtyLstQbGMjQTOfCrpjSWObKrNsYbdqTHPNCAhzWzjdRujtFvfLDODbJDjTLBQCGisDJKmtSeQKdIiJfJCPPWoWsYrqliBbOzmzVOIZZzjbQRelekWmVQJipqYxrsTexbUbPDvbnEBWAKAYtudpMrnwxonFZPxfJTDuidcHnrShzYOmxaVwmFArsrFep");
    string HDZghgwDmTv = string("GQDZcaicJMihnPRndhFukMIThYQHvCrCtfYMLKkcIGsQTTSyzNxxINjoGJEtjKxqBZFcPUhjFNvaLsIpsJWdnpuXRryjdTdYKYWOKbQlHMBfbpcOnOeMpjxUakkrXJzQyAwEKcLGSkWttHhhhBrHcAGiyXITeERdzbKhCvtCNlpzUKeloyMOv");

    if (iozsnIz == string("GQDZcaicJMihnPRndhFukMIThYQHvCrCtfYMLKkcIGsQTTSyzNxxINjoGJEtjKxqBZFcPUhjFNvaLsIpsJWdnpuXRryjdTdYKYWOKbQlHMBfbpcOnOeMpjxUakkrXJzQyAwEKcLGSkWttHhhhBrHcAGiyXITeERdzbKhCvtCNlpzUKeloyMOv")) {
        for (int zJgaZvICXhfnY = 1779674700; zJgaZvICXhfnY > 0; zJgaZvICXhfnY--) {
            VvYAuM -= VvYAuM;
            HDZghgwDmTv += weDzF;
            weDzF += HDZghgwDmTv;
        }
    }

    for (int cqRmHctap = 2140040296; cqRmHctap > 0; cqRmHctap--) {
        HDZghgwDmTv += HDZghgwDmTv;
        HDZghgwDmTv += HDZghgwDmTv;
        weDzF = HDZghgwDmTv;
        iozsnIz = weDzF;
        HDZghgwDmTv = iozsnIz;
    }

    return VvYAuM;
}

string WOPCrUgsIPqsvvg::fSkUPhq(string HftPWyF, string cbikiSugllkYwV, string twsWvkTihuXhV, int ltJGvTNqERkM)
{
    double fVDBuxiug = -686045.0201030385;
    bool aOCsEYjJWG = false;
    double maGJlHvMse = -912519.8075263955;
    double HQpUkUNBiyZA = 176243.88630445988;
    string OAGOTCOQ = string("TGlJCqPkEHrDqKTVRbsmkdLvIMKAQDpMOXmrfskfQMUUTVouawdOnLsXDxceYwHGMArKXugXKrSXnfqsrmkDLjjBOMdSHRAmJKKXFvpdjvjHrzJRZSKDkxEiFtTDbvaltlWimFcYCFCXoPcGbVsddqJcWvgFwyvXVsghEInmVyWoHEjTUiuZHRXtOw");
    int igohxhqjtdpRIfy = 2104824088;
    string QehpwUdpFlxLOQCu = string("nWiecUhhzmRqVlOQnbeyIagRKhvIGhcMQhcRprsDsOtdsfXfjFggOFCdVdtpuyrfupxOIQezKyPYTRMZHgBRcWKxOLWRnOmbWnpMAEFyCpnCXhadlDFTaTuZrFTQ");

    for (int FBgShrKmBI = 646930610; FBgShrKmBI > 0; FBgShrKmBI--) {
        continue;
    }

    for (int Bdqql = 1169141576; Bdqql > 0; Bdqql--) {
        twsWvkTihuXhV = twsWvkTihuXhV;
    }

    for (int TEnIXZIPTvicMEzR = 74963461; TEnIXZIPTvicMEzR > 0; TEnIXZIPTvicMEzR--) {
        OAGOTCOQ = OAGOTCOQ;
        HQpUkUNBiyZA *= maGJlHvMse;
        HQpUkUNBiyZA -= maGJlHvMse;
    }

    for (int jkwHZOXId = 775873745; jkwHZOXId > 0; jkwHZOXId--) {
        twsWvkTihuXhV = HftPWyF;
        cbikiSugllkYwV += cbikiSugllkYwV;
        cbikiSugllkYwV = OAGOTCOQ;
        igohxhqjtdpRIfy = ltJGvTNqERkM;
    }

    if (QehpwUdpFlxLOQCu < string("nWiecUhhzmRqVlOQnbeyIagRKhvIGhcMQhcRprsDsOtdsfXfjFggOFCdVdtpuyrfupxOIQezKyPYTRMZHgBRcWKxOLWRnOmbWnpMAEFyCpnCXhadlDFTaTuZrFTQ")) {
        for (int ihkQfxHkL = 60998816; ihkQfxHkL > 0; ihkQfxHkL--) {
            fVDBuxiug -= HQpUkUNBiyZA;
            twsWvkTihuXhV += QehpwUdpFlxLOQCu;
            cbikiSugllkYwV = QehpwUdpFlxLOQCu;
        }
    }

    for (int snlKwjXthsA = 1217886628; snlKwjXthsA > 0; snlKwjXthsA--) {
        QehpwUdpFlxLOQCu += twsWvkTihuXhV;
        HftPWyF += QehpwUdpFlxLOQCu;
    }

    for (int fxQvYiVViu = 194956106; fxQvYiVViu > 0; fxQvYiVViu--) {
        OAGOTCOQ = cbikiSugllkYwV;
    }

    return QehpwUdpFlxLOQCu;
}

int WOPCrUgsIPqsvvg::rRgNSalSNuQryPG(string DNZEiIMKZHgIoA, bool omvkwCFn, bool QulAcN, string UMMUlljO, string QjLGZomIhedepiZS)
{
    int qAvEsyFMeqV = 342474682;
    string DYBaWDxS = string("yffckeAISIFhuLmLJlbzxdacMbKKHBztRwkYpEwrsWSxyhRQceXIYgnYPWqmyWHDWcTTRHgzLbbsGZcHLobGJCtTsodJUXnuovooQlZOuPIReGxjJWTrAXbbFnXDkwxfYUAGZfFutSYkeaMI");
    bool xEkUtFqAIGkDBY = true;
    bool XcRbVZGWwdLzEP = false;
    string SblsRi = string("EiDcFpkfgmWjbNNjXGYAcGuuyfbfbmJdmueQGOKxEfHmwFFIgJaIvZQRPNHExRLAgQmnJEkaWCuYJtXPKqAgRdYEGSvSYVwPYAIsGRgrYDnGMaKP");
    string RvpveYOAexIwhZz = string("PdJpDXzROcQWFizCNhgNVQwqMugKIcjIIGxJnJyZuOucEyHBNiArPVAoXAoAhyoiVuznXbBOWfSlaZriGYqWlIpQHOxbIeRBGcOVVfRpaNVRBuLSlpjPitZTnKNvnuosCpeTFtvDbvBdOiCQUSTQUpxm");
    bool TKlqIhEZgivvSUCa = false;
    string lYAAnL = string("NFnHIXvUukUOXVMegSgKGEWolyFgATXoxtiugqucZaxeWlqGcRfySjXHwrIglelUbxweueXfEs");
    bool wohKh = true;

    for (int VlTEILPmt = 466665693; VlTEILPmt > 0; VlTEILPmt--) {
        XcRbVZGWwdLzEP = ! omvkwCFn;
        QjLGZomIhedepiZS = UMMUlljO;
    }

    return qAvEsyFMeqV;
}

WOPCrUgsIPqsvvg::WOPCrUgsIPqsvvg()
{
    this->iRHYL(757610481, 1731690421, false, 871451.32313067, -30852636);
    this->ezNNCMQJKTHYQSpo(838153462, string("owtEPqLDKmiDcYlwlOROgRuQGDzJgeLuqIzlAvyEOljwfcPyDEdqtuYyjnmKdHHLuwHubouObGkiWLmqSZgLErWOAGQDhDifdMLEVQP"), 201808.20906669067, -456355.35917737405, true);
    this->ZAAWrMPiMqKrgpZ();
    this->gEWTIvpR(false, 852467.0843525198);
    this->SEtrSlEjfasQ(false, 635480.2463673439, string("ZqcAdYvBMKjrzysJXXXpPwrILTJBjbzUelNeaUVLPdOGgAfLHSqblxuqNacnBSmTtrcnydGhagxuyTMoFMmjEjizTeZGtUgZneoEhkNHdgIndUguicsBMsNsuQDStLYSFggeBlXzBoAxDBnCXAchhVUlmytbqlXrXVBTTNOetUGtFcxsPrNMIsKNGFObHzlnIuGHwrkRHnXCeoxBoTMqLNOJCzbDfDBSaXqNEpsQuSk"), true, string("THZxJquHVVVsSjSHONkhhdBSQnvzokQHIcUxMfZjmMcvHnkhhsUQjBModGk"));
    this->uDWVrvVZsRAhgNjx(-988170.4222896645, 299979.21260442183, -427460.64249854774);
    this->gfuQFVogD(347803.4904720224);
    this->ENMvBXTnvzfpxFAo(string("heuUHHBHjlowDVxPeSyePDYhecfcXHnjmyflBiHiiAQwIZ"));
    this->fSkUPhq(string("yxmTazAHzariDKdRExQgfqJZKsPXfpfYSSdxdusUdBHxydVMpiqMccbswvhZzkOGMzPWhSLlCnu"), string("KFyQsxWKDQucc"), string("mkdgslpVIPlCHCUoIbXRRnydGlnopHiqaECqNwVkzQbThLXyAeRSfAcqhMxargqNhqVNDoqkfQbCYzWLCeqKMdunFZpbHioiqiflJTgcZCIdhajPqgmIKVNHLDuiCCsHpxkNSENqLMzHMAmd"), 953513444);
    this->rRgNSalSNuQryPG(string("wgOmPdBttuoGlApCyOLSLnBdPESzaswenoxsbdkhGsxiPxOTHUtSIQnLoXSMhZBCEPuvjjNlzbwCwHgxCWwVQCNEdJRcBpzTQVTlbbfbwEeVUMIpzGoGVDgZQDjtYTjCDBJJdblhHcWqfUPYqrWSYGavvRnHtEvdQIrMwwacbjUSB"), false, false, string("jyzPyAlXQfqQDkLtoXAyAujIGpkXaKHeWGnlEriEXUgj"), string("SfiaVvuMwizxKEc"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iSvXkjhUyLLg
{
public:
    double fPtOdFoEm;
    bool SodTyGjbvJ;
    string ikBgytMu;
    int sTidaldtdpT;

    iSvXkjhUyLLg();
    double AIZNZ(int liiryx, string QgVqn, double PmXwRdJww);
    bool DeGGKyopDkAGVG(string QCsProgIuMTdew, int OmyoPPWi, int IRNhtQb, string YqAtgiPOfflprIyW);
    bool raXQQedTgRhLY(int tMBbtYY);
    string uNoLzUnUvnWR(bool pHaxumrWIYPaP, bool abNpIDyEfLCNNcB, bool RYybCSCGhiDmc);
protected:
    double FCguHiianr;
    string tGReNVHPEzhI;
    string uElPoCsB;
    string nhWzJiSsQFH;

    double SVcDSWVTE(int KXOhStUY);
    string fyZIDNtOgQjoJcT(bool TLYSWqXH, string qTrFCVLu, double GskDgjwgOb, string boEqOweimlOxO);
    void tjCxWNbthLxaoTMY(double gQomagvLHzP);
    int bMaDUxtygA(string IbXMOhSDQJI, string ipvAkP);
    void arSgWlxKYrIg(int QRmNr);
    string AEBZXGGmXuIh(bool RxKJUVWeqSeWid, int EFCqqPlKvryWF, string BGJwykbYhPjDxnmT);
    void WTdtubKuXmz(double mtFkkTGavASygcW);
    void yqBzUnquYuLqHZs(string dMdkbzNUjKFVBQ, int jstuuAUlKqNfk);
private:
    string PXLOTjryLrniej;
    double UhhbwJ;
    int ufwbkEBsIVpo;
    double qBTCAbb;
    double mVLuFcdEmqQ;
    int MHGTmMTMQlVql;

    bool vQVmqD(double ZphXtNbtCokPO);
    int ErJNsrotqjtTOrLc(bool eAAGnmnFaIfE, int MuuZtaZKY, string lIwtRYYrsDn, bool hHIwnmNJxt, string cfIIgiykjh);
    string vgmDSoyEHmZqRAO(double kigxeTlxJHHQAY, double UWbUa, string WsGKkcWR, int imAVwCIsXHcJjMye);
    string gkiGzMkr(bool cYJEYdcPzLxBEFbR, bool UZtrjEjssTLS);
    string MVECBjijPFlSudrw();
    double wSfdfuTquizhsK(double cvxWAybMmyyCA, bool CTgkxetcmf, string htINfPKo, int OdJwBFqvTvI);
    int oyRbFVUW(bool QpCwANfcNlL, double ByMzxBmuA, double AbIPUfXovk, string WdXuZqMxoFae);
    void DjpCvfJpZfzmWNI(int curosxJvGZTp, int XvEtk, int bZcwOsClTQ, bool XrsxKvmqfqqF, double PiaPRhE);
};

double iSvXkjhUyLLg::AIZNZ(int liiryx, string QgVqn, double PmXwRdJww)
{
    string kjyExodK = string("geXkcxpKVsbsVBiEYGTJyCGCclmHEZfTjtWduyVwHWNytAbNAeMCzzFjZASHXAUFppYZkeVQpakcTGDVpnbOdGAQdvWlHmDByFKvZoyoTOMVKegCOmOLGhlWUcvtHBIfghWmQJyiwbnsEkmNUJMUZBBnGoMknpaoc");
    int LLAyFpK = 1952576871;
    double ljfzDJIGyFk = -550797.02314605;
    bool IUqEKmwfQuJmfUsX = false;

    for (int hydWNcJCiASA = 1766546629; hydWNcJCiASA > 0; hydWNcJCiASA--) {
        kjyExodK = kjyExodK;
        kjyExodK = QgVqn;
    }

    return ljfzDJIGyFk;
}

bool iSvXkjhUyLLg::DeGGKyopDkAGVG(string QCsProgIuMTdew, int OmyoPPWi, int IRNhtQb, string YqAtgiPOfflprIyW)
{
    double VJPOksUnB = 458569.1930871792;
    double lLQfiINoW = 574028.260420066;
    double ymWRPrf = 887473.9004160252;
    bool NJhZyGv = false;

    return NJhZyGv;
}

bool iSvXkjhUyLLg::raXQQedTgRhLY(int tMBbtYY)
{
    string fEGKqtfpybPmr = string("ZEcnxPnHBPgBdXHwvjOxqTZrPQrBaRtMqNAXxfKDZHsCEEbxqNLpidskVcRmqQUheagPZeBVNHSyUssoDkwsZtwANtmnzxazeIQKwxnztWvVWqUHipJCYCPUfowAOHbWUWNtigyGFbSeeZCK");
    string WspMJq = string("aGJkEGLcaxFfpzbEdSSbcSKWoDmfgAb");

    return true;
}

string iSvXkjhUyLLg::uNoLzUnUvnWR(bool pHaxumrWIYPaP, bool abNpIDyEfLCNNcB, bool RYybCSCGhiDmc)
{
    bool kopSBp = true;

    if (pHaxumrWIYPaP == true) {
        for (int loHQlNnXbODe = 1696057489; loHQlNnXbODe > 0; loHQlNnXbODe--) {
            pHaxumrWIYPaP = pHaxumrWIYPaP;
            pHaxumrWIYPaP = RYybCSCGhiDmc;
            RYybCSCGhiDmc = ! RYybCSCGhiDmc;
        }
    }

    if (pHaxumrWIYPaP != true) {
        for (int VcdhFK = 1614715056; VcdhFK > 0; VcdhFK--) {
            RYybCSCGhiDmc = ! pHaxumrWIYPaP;
            abNpIDyEfLCNNcB = abNpIDyEfLCNNcB;
        }
    }

    if (pHaxumrWIYPaP != true) {
        for (int aImWkB = 1654965893; aImWkB > 0; aImWkB--) {
            pHaxumrWIYPaP = ! kopSBp;
            RYybCSCGhiDmc = ! RYybCSCGhiDmc;
            pHaxumrWIYPaP = abNpIDyEfLCNNcB;
            RYybCSCGhiDmc = abNpIDyEfLCNNcB;
            RYybCSCGhiDmc = ! pHaxumrWIYPaP;
            abNpIDyEfLCNNcB = kopSBp;
            kopSBp = RYybCSCGhiDmc;
        }
    }

    if (kopSBp != true) {
        for (int nGfMIVm = 560838141; nGfMIVm > 0; nGfMIVm--) {
            pHaxumrWIYPaP = ! pHaxumrWIYPaP;
            abNpIDyEfLCNNcB = ! kopSBp;
        }
    }

    return string("KJBRWwAfSOeegvDSEGNVhfJLPpInYWLEZefgqiMEGTsaMVqgvxfgoroWgTIHCZUCUbgIFxMnWPBBuSVRwJGpXshDvRj");
}

double iSvXkjhUyLLg::SVcDSWVTE(int KXOhStUY)
{
    string cKFgsmBTmvGSUDS = string("afQTWpMrqnNXyVvPodcIgVJnlUkVNnoCAjQYGiIQQpzzRIFAHfgdBiekHoXjITtgffWSLpsKEPLsWKapMvwLXsdWMkQzcxcQvTeypdyuDebQwMwfcCjccGpbhwqCzPXRpSAZSnEYLleLFvSlqriabfoaNxeIGdpAuNktsxGZkRKScHhgbXHkcgSJipRoZMKodRfZh");
    string ZAWOoPiJxR = string("TRfodEiNlMOchjJJhIMpHZrQEeFswWLiEFUZFibPYBkJswPXlkBjjNgZqYUSWUfzUwsjRuSicbVZIIeILPsHpHwFDNgyFPMeDPdSIqUBkspUp");
    double lImpP = -322550.30804433324;
    int lHaPHjw = 1246102777;
    double hkmRf = -517307.2446429427;

    for (int VkWZeu = 1036617803; VkWZeu > 0; VkWZeu--) {
        cKFgsmBTmvGSUDS = cKFgsmBTmvGSUDS;
    }

    for (int txPUnmVWAkgTVfVy = 526304741; txPUnmVWAkgTVfVy > 0; txPUnmVWAkgTVfVy--) {
        hkmRf /= lImpP;
        cKFgsmBTmvGSUDS = ZAWOoPiJxR;
    }

    return hkmRf;
}

string iSvXkjhUyLLg::fyZIDNtOgQjoJcT(bool TLYSWqXH, string qTrFCVLu, double GskDgjwgOb, string boEqOweimlOxO)
{
    double FLtFITwQd = 199443.07392383862;
    bool hXxSAwYejUB = true;
    int WmmHgH = 747179187;
    int tmTLtwksvUyIk = -511593511;
    int axyhXSh = -1269614599;
    double MdAZovynGs = 774466.7930246288;
    bool fTCznHf = false;

    if (hXxSAwYejUB == true) {
        for (int ByCuaGljqGOhGUT = 547572366; ByCuaGljqGOhGUT > 0; ByCuaGljqGOhGUT--) {
            TLYSWqXH = ! TLYSWqXH;
        }
    }

    for (int HaIqSoKZgjdbX = 344856441; HaIqSoKZgjdbX > 0; HaIqSoKZgjdbX--) {
        WmmHgH /= axyhXSh;
        qTrFCVLu = boEqOweimlOxO;
        fTCznHf = ! hXxSAwYejUB;
    }

    return boEqOweimlOxO;
}

void iSvXkjhUyLLg::tjCxWNbthLxaoTMY(double gQomagvLHzP)
{
    double fcRrcaMGfebSGSad = -291267.50633320806;
    double MYuiDS = 41190.352481996415;
    double JZcPeYMgmVWcb = 776250.0729345549;
    double ElvGHeSeqH = -664188.7750515777;
}

int iSvXkjhUyLLg::bMaDUxtygA(string IbXMOhSDQJI, string ipvAkP)
{
    bool NXuNBSmKLofzxQF = false;
    int BHtAD = 1941780330;

    for (int jVdtGQWfj = 1480282090; jVdtGQWfj > 0; jVdtGQWfj--) {
        ipvAkP = ipvAkP;
        NXuNBSmKLofzxQF = ! NXuNBSmKLofzxQF;
        IbXMOhSDQJI = IbXMOhSDQJI;
    }

    if (NXuNBSmKLofzxQF != false) {
        for (int TfPIxiSSeqb = 1230882711; TfPIxiSSeqb > 0; TfPIxiSSeqb--) {
            ipvAkP = ipvAkP;
            BHtAD -= BHtAD;
            NXuNBSmKLofzxQF = NXuNBSmKLofzxQF;
            NXuNBSmKLofzxQF = NXuNBSmKLofzxQF;
        }
    }

    if (ipvAkP < string("slxjrpXITtuUOjetBIZhvpuGHBMTwhnpHzoHibSDZojLmQoXtLIyVOMuQGoTPjydZePjeqxarkjGhqVCntWCwINSSbYKcTrMAZpKvIdAJMZgGmqKvjzzAAtIERwql")) {
        for (int XgjsYOlksAlmWe = 147712341; XgjsYOlksAlmWe > 0; XgjsYOlksAlmWe--) {
            NXuNBSmKLofzxQF = NXuNBSmKLofzxQF;
        }
    }

    if (BHtAD <= 1941780330) {
        for (int UuAbbFDajglUYU = 146268579; UuAbbFDajglUYU > 0; UuAbbFDajglUYU--) {
            BHtAD *= BHtAD;
            IbXMOhSDQJI += ipvAkP;
        }
    }

    return BHtAD;
}

void iSvXkjhUyLLg::arSgWlxKYrIg(int QRmNr)
{
    string RabSfGDScbudg = string("QpHuSMpbHN");
    string FZjznAV = string("ECxEgfBrAqAwINsugilWPVFKDWsTncWcVCyjYxyIyfmZuWWonWhkyeRyJLEFBvlfYUPShwcEFVVMLmTKnFbPibBLIHFAPoRyjNFdQVkMPqhmePkFOxGbEUufCaRQbAIgJqadyobauMmjwdjIwxmYLFBRhPPwdrTWRNhTcesVsNWIbS");
    bool PzpkQHblXQ = true;
    string EVVhqZmSkqYioYO = string("dMNCuFCKrVeslrirNrEOVczHEXoHWnQusbXzdkJvoWwgyaGDZmRJnTKvZLftSOAcrHbEobceohgYQfvmhbMdRkglRYzuuZhHchrjebmjUbMkXQPAhzpVoxztTWxXLLxvufiqfQucCmIfdPMWEoMEPaSUHHJvGUiKWZyVbytORHCSIloxnBCJJSycphFtVjNSQXrvOnIJEueSFsMLFJUMqiGdfbMVZFzZRrzIofpTGOKzhNT");
    double OmEtLCKAXqIMw = 740432.2431133634;

    for (int XoQxfIdkVvccmdj = 1550480287; XoQxfIdkVvccmdj > 0; XoQxfIdkVvccmdj--) {
        FZjznAV += EVVhqZmSkqYioYO;
        EVVhqZmSkqYioYO = FZjznAV;
        PzpkQHblXQ = ! PzpkQHblXQ;
    }

    if (QRmNr > -177119470) {
        for (int OLuaiDTBSBPlW = 1176344545; OLuaiDTBSBPlW > 0; OLuaiDTBSBPlW--) {
            PzpkQHblXQ = ! PzpkQHblXQ;
        }
    }

    if (FZjznAV >= string("QpHuSMpbHN")) {
        for (int IDsSmSVsCESqOxHq = 495658166; IDsSmSVsCESqOxHq > 0; IDsSmSVsCESqOxHq--) {
            FZjznAV += RabSfGDScbudg;
            EVVhqZmSkqYioYO += EVVhqZmSkqYioYO;
        }
    }

    for (int kKTFWMhlKxpU = 617394426; kKTFWMhlKxpU > 0; kKTFWMhlKxpU--) {
        EVVhqZmSkqYioYO = EVVhqZmSkqYioYO;
        EVVhqZmSkqYioYO += FZjznAV;
        EVVhqZmSkqYioYO += FZjznAV;
        EVVhqZmSkqYioYO += EVVhqZmSkqYioYO;
    }

    if (PzpkQHblXQ == true) {
        for (int oTwKr = 1174617343; oTwKr > 0; oTwKr--) {
            continue;
        }
    }

    if (RabSfGDScbudg > string("ECxEgfBrAqAwINsugilWPVFKDWsTncWcVCyjYxyIyfmZuWWonWhkyeRyJLEFBvlfYUPShwcEFVVMLmTKnFbPibBLIHFAPoRyjNFdQVkMPqhmePkFOxGbEUufCaRQbAIgJqadyobauMmjwdjIwxmYLFBRhPPwdrTWRNhTcesVsNWIbS")) {
        for (int AsMziZgox = 729591864; AsMziZgox > 0; AsMziZgox--) {
            FZjznAV = RabSfGDScbudg;
            RabSfGDScbudg += FZjznAV;
        }
    }
}

string iSvXkjhUyLLg::AEBZXGGmXuIh(bool RxKJUVWeqSeWid, int EFCqqPlKvryWF, string BGJwykbYhPjDxnmT)
{
    int xvIHovJCMy = -2066845911;
    bool HYWrNrF = false;
    bool MecyD = true;
    string aVpkbEj = string("YVbmXpTQDAhqwKEifUoCqhrqWmpYSpUjpaApDidNLETlZuRSsQvpwSLGvCgNmWMeCcqpV");
    double KZCypZiUlcLCFRPt = -45835.8409603377;
    int muSuzfTZpuM = -1977238214;
    bool hTQpwg = false;
    string DgxBQUXkzhs = string("uWgWrXgMYWhdTATwEGRIohdDBlUFrBlRmsitUBQwRGKHoSIPTkRjAnazXEczbGvIgITkmnqCCWbEhHboLRVZbXysAeSOxwrDQWXOodtLrzwMTQfYxRdhAUiEQWJzwVdWBnvbeJeBdzlhJiGOXRehJEPdzkXgtYjFmiAVgCUTRyqgVqnLHgrKyyIg");
    double kSjihFKkiDNN = 453125.8899591769;

    for (int uYVpSt = 1247761427; uYVpSt > 0; uYVpSt--) {
        xvIHovJCMy -= muSuzfTZpuM;
        BGJwykbYhPjDxnmT = aVpkbEj;
        EFCqqPlKvryWF += muSuzfTZpuM;
    }

    if (kSjihFKkiDNN < -45835.8409603377) {
        for (int VjBoLDUzzZcjxgxH = 2109364798; VjBoLDUzzZcjxgxH > 0; VjBoLDUzzZcjxgxH--) {
            HYWrNrF = hTQpwg;
            MecyD = HYWrNrF;
        }
    }

    return DgxBQUXkzhs;
}

void iSvXkjhUyLLg::WTdtubKuXmz(double mtFkkTGavASygcW)
{
    bool qhbyzFOYCYYgjchb = false;
    string REYqLfzYS = string("CPQHlbsGHXqCCdFshbmLNlRqqyhVprsZHHLKAknxaqbpjxrekDPfWQlytLGctNPmpstviyGCFdCD");
    bool WkaIYUrSKVHlVQ = false;
    bool TncBef = true;
    int BxZNnOeyuQP = -1827346315;
    int OLjDv = 1303033513;
    int ZVVbmubi = -1214591542;
    double LwgTFKvZ = -115847.86187687315;
    string HYfVMnimAmXYXa = string("lGglExsVcqKgbcXyITUWKlh");

    for (int KQsWQLkB = 2047160026; KQsWQLkB > 0; KQsWQLkB--) {
        BxZNnOeyuQP = OLjDv;
        REYqLfzYS += HYfVMnimAmXYXa;
    }
}

void iSvXkjhUyLLg::yqBzUnquYuLqHZs(string dMdkbzNUjKFVBQ, int jstuuAUlKqNfk)
{
    bool bByHTpof = true;
    string kMFMpHHsVp = string("yLhxlmcBArqIOoFibjMRZDfIGNhwIiUsiLqIRCVNaqiQfyZImvRYEicDGjEsUrzXunoNVCNBMyuMBAnspLSlYoPfPcskXUFRhCNxNTHGvZsEUuyhlmbGQVTNIkgtbnJZmduinCfeEUlXdAZCEMQWYxfnTsjllggjYsoNFNtnyYaDrMOszjgePBcTrCpHsfKqFKQDUTWuAz");
    string zpIcGvtxjiKxZVXx = string("WadrHMOdvsHErCwHYtvmozIDJsJTEVGOrWNhVtTFxSFOpuQePCSibcSrUUBQntcammtwWGxxVxGcaFGwEYZEcTaqVWMflSVHUvfxrDYvuPMkHWtDHYrCRnBvTEMyFvXpUpsWymdEQbuWdBwcCqgDRwUIENFYVTSKvTmXWTZtEwVbicBGqjmLRXxiRmwjJivnvrUypDKYXrxsRbYVDsmcPUwlZYyGpqIhUagqijtFDLxPLldQyBBaTEfuUbfdDe");
    double bgWzMWY = -186764.7679441959;
    int bmCzIulB = -1531836789;
    double SOPNQGiBnscgwhoH = -662663.3641979573;
    int fKgwpTIZowZ = -1174637096;
    string JfcDgSuSG = string("SLgrbtGSdcCJlNeJdufmgW");
    bool wVcgStiBtwwdBv = true;
    string LboQv = string("RIiZGwQamoYYRkrVuMOVGYLWruLafjKgwulyfulPptCDVKMdjNSAcmUWTJpilSvFTzgzGhjADdklglAekiIxzoMdNTaCZQKfWBrvlCUGdtAUhljuOdXGMTOdYhWjawKISLfCQtuZ");

    for (int NMyxDQFYeINZEEgD = 223202009; NMyxDQFYeINZEEgD > 0; NMyxDQFYeINZEEgD--) {
        dMdkbzNUjKFVBQ += zpIcGvtxjiKxZVXx;
        kMFMpHHsVp = JfcDgSuSG;
    }

    for (int nViYSCLfKpIScs = 192113259; nViYSCLfKpIScs > 0; nViYSCLfKpIScs--) {
        bmCzIulB -= fKgwpTIZowZ;
    }

    for (int dVhuhrAIXfvTL = 1590531388; dVhuhrAIXfvTL > 0; dVhuhrAIXfvTL--) {
        LboQv = JfcDgSuSG;
        jstuuAUlKqNfk /= jstuuAUlKqNfk;
    }

    if (bmCzIulB == -1174637096) {
        for (int nFLDkou = 1056173596; nFLDkou > 0; nFLDkou--) {
            bgWzMWY = bgWzMWY;
            JfcDgSuSG = dMdkbzNUjKFVBQ;
        }
    }

    for (int EGmTOh = 467184219; EGmTOh > 0; EGmTOh--) {
        JfcDgSuSG += JfcDgSuSG;
    }

    for (int BevNkKrVApvtC = 1561715400; BevNkKrVApvtC > 0; BevNkKrVApvtC--) {
        continue;
    }
}

bool iSvXkjhUyLLg::vQVmqD(double ZphXtNbtCokPO)
{
    int pLXVKwFCwgKY = -1554735628;
    bool hcMkBO = false;
    double xGmyItGdvqOflshc = 592951.9756178329;
    double YUewDni = 792526.4935692942;
    bool yuCzND = true;
    double nwSeOnE = 250496.50684372304;
    int WNUIpYrIPoBq = 241340114;
    int uKipBpMAzgf = -1246759225;
    bool pryCdRyHcSxsd = true;

    if (nwSeOnE < -1040780.3902986567) {
        for (int nXJzMD = 903784220; nXJzMD > 0; nXJzMD--) {
            continue;
        }
    }

    return pryCdRyHcSxsd;
}

int iSvXkjhUyLLg::ErJNsrotqjtTOrLc(bool eAAGnmnFaIfE, int MuuZtaZKY, string lIwtRYYrsDn, bool hHIwnmNJxt, string cfIIgiykjh)
{
    bool EjLNbBhQGBA = false;
    double bnGvW = -879432.9843820276;
    bool jMChTT = false;
    int NvHRWOhJI = -762413229;
    bool pNCTJ = true;
    int yMVuLkWbpMPDJMZk = -739612345;
    double NkCumFDLc = -953301.0636257959;
    bool sbKfTCmxTn = false;
    string CQmNQafk = string("DZqnYNqjtoHpMvDjGtZqihRPZyvsSSXMTtEqoGDhFbmzmiAUgBCjkjiRTEDrTCgRGDGPYhbCAXAeuRjFVIGwAZlxvuiMwwGeBjrQsCPILsDGZdYYXCFXktcSFmcBkimNYpUjLtVvQmYxNiIHDtPWSHDZtlWTIzgNpZgimdpKysocVkONKQPTphJKaBSFVssTFAKmaax");

    for (int fcLOwooBLr = 1265684666; fcLOwooBLr > 0; fcLOwooBLr--) {
        eAAGnmnFaIfE = ! pNCTJ;
    }

    for (int eVUZQGjbIvoHEDv = 663445411; eVUZQGjbIvoHEDv > 0; eVUZQGjbIvoHEDv--) {
        sbKfTCmxTn = hHIwnmNJxt;
    }

    return yMVuLkWbpMPDJMZk;
}

string iSvXkjhUyLLg::vgmDSoyEHmZqRAO(double kigxeTlxJHHQAY, double UWbUa, string WsGKkcWR, int imAVwCIsXHcJjMye)
{
    double iGkhVJnnQo = -688560.6011966282;
    double lnnXX = 140388.24088334243;
    int mfsJgCmNEpRu = 794889087;
    bool ITQxqIIS = true;
    string ViqQVgBVGpyeX = string("eFWIpvtKHkxDTCXRz");
    string BmvLjRjtSp = string("EmvYkINfxdqHjFIhiNdxZhMXmRUREtOPlguvPLIgOpIvSJihvAMVXWTkZxfYKoJUXOYHINeZEcJEWodeMJmIXCJpwgmfKcMXgndMa");
    double IzTlpoY = 979422.2300089019;
    double aKRflb = 151913.10656005342;

    for (int KywXEojE = 1340443039; KywXEojE > 0; KywXEojE--) {
        continue;
    }

    if (lnnXX <= 979422.2300089019) {
        for (int zhXsPzNaOLpQia = 1331904960; zhXsPzNaOLpQia > 0; zhXsPzNaOLpQia--) {
            continue;
        }
    }

    for (int pAvWM = 933387642; pAvWM > 0; pAvWM--) {
        kigxeTlxJHHQAY *= kigxeTlxJHHQAY;
        lnnXX += UWbUa;
        ViqQVgBVGpyeX = BmvLjRjtSp;
    }

    for (int gHWvl = 816672321; gHWvl > 0; gHWvl--) {
        kigxeTlxJHHQAY *= IzTlpoY;
    }

    return BmvLjRjtSp;
}

string iSvXkjhUyLLg::gkiGzMkr(bool cYJEYdcPzLxBEFbR, bool UZtrjEjssTLS)
{
    bool PIoxVFXW = true;
    double DeebmUyAXaSp = 332634.8439112364;
    string kMIEaHecCn = string("HHZJGXMoURyUuyiNB");
    string DHJLg = string("FvJXNyuCzPgJQuVfafUuivkfFDopzXnWjDsEHoWLyHhMFLueBVsmPdOPR");

    for (int HKmynSjDKVjeefhD = 518580750; HKmynSjDKVjeefhD > 0; HKmynSjDKVjeefhD--) {
        PIoxVFXW = UZtrjEjssTLS;
        cYJEYdcPzLxBEFbR = PIoxVFXW;
        kMIEaHecCn += DHJLg;
        DeebmUyAXaSp += DeebmUyAXaSp;
        DHJLg += kMIEaHecCn;
    }

    if (UZtrjEjssTLS == true) {
        for (int RQKuXEReTyCRYf = 45049568; RQKuXEReTyCRYf > 0; RQKuXEReTyCRYf--) {
            cYJEYdcPzLxBEFbR = PIoxVFXW;
            cYJEYdcPzLxBEFbR = UZtrjEjssTLS;
        }
    }

    for (int MbGSoGnBT = 79028419; MbGSoGnBT > 0; MbGSoGnBT--) {
        UZtrjEjssTLS = UZtrjEjssTLS;
        DHJLg = DHJLg;
        cYJEYdcPzLxBEFbR = PIoxVFXW;
    }

    for (int aNwIWEQy = 1515868462; aNwIWEQy > 0; aNwIWEQy--) {
        DeebmUyAXaSp /= DeebmUyAXaSp;
    }

    return DHJLg;
}

string iSvXkjhUyLLg::MVECBjijPFlSudrw()
{
    double nEuUmEjswtSzD = 493998.2688995724;
    bool JoERnx = false;
    int LJDAd = 1935133284;
    string IMbgENyIlxUpzrbi = string("xxlXoOieCodlNF");
    string iSWwh = string("qSJljnvkHHFuccFGAkAAvUxjomdNnJTZFepNgsWWbWWsKmrWqqriSPGQQJQYGCjRkVigxbkVaebUhaqznGOmWROvAOCCehdCyoxpEjqyMdJlfaDcAscAAnRRUFJCfwYeUnRWnJxlfMFliKpNlLBMXGWhYeGvOVliIexOxaYvHtBCEEBbaAAqVqDMcAdWbyOSykOWuNjFAkwfiikFydcCYAccjjdMJCm");
    string UcMIULNT = string("YGTdmaqojSHNBwFUoKpwQqOfIWrMRAMlFHrwOHCvEcyXmZMBWVqmpbSrRYaHeOWriqdVGXCoKRmEmbPAWExwylUvdiAahhYowJupCmqWpTJLpyhIUxkmnfWcZvkqlVLChhCCDlyPDqULfdBUzjPCbICEuXatxxbkAqWofzFkvSlWSGj");

    return UcMIULNT;
}

double iSvXkjhUyLLg::wSfdfuTquizhsK(double cvxWAybMmyyCA, bool CTgkxetcmf, string htINfPKo, int OdJwBFqvTvI)
{
    bool pOhutwh = true;
    bool QPJIbHdnZ = true;
    double jmHKVfgxmJuEIxbQ = -1037064.1959845603;
    string VoOMctCYE = string("MeZaLOrpwwZNREJLGqCdWJmbtvPQCAAZAotLQYbFsDqdSWDZqqaLVFMWGHoxfIWZjVUESfZlGQtsoCdqBZUNSyNVdTENPiuUSszHNbfnmZeLxqXVGCEbZjMyrvWucWur");

    for (int QBtFfYnFJtl = 861181017; QBtFfYnFJtl > 0; QBtFfYnFJtl--) {
        CTgkxetcmf = ! pOhutwh;
        pOhutwh = ! QPJIbHdnZ;
    }

    for (int jRaRcWevex = 1225240709; jRaRcWevex > 0; jRaRcWevex--) {
        cvxWAybMmyyCA -= cvxWAybMmyyCA;
    }

    for (int cYpNVYLZBIc = 1903856262; cYpNVYLZBIc > 0; cYpNVYLZBIc--) {
        cvxWAybMmyyCA = jmHKVfgxmJuEIxbQ;
    }

    for (int qrefHbhySrByCdrN = 1301839946; qrefHbhySrByCdrN > 0; qrefHbhySrByCdrN--) {
        OdJwBFqvTvI -= OdJwBFqvTvI;
        CTgkxetcmf = QPJIbHdnZ;
    }

    for (int qntHmZpoGPWFLw = 2099287760; qntHmZpoGPWFLw > 0; qntHmZpoGPWFLw--) {
        CTgkxetcmf = QPJIbHdnZ;
        pOhutwh = CTgkxetcmf;
        htINfPKo += htINfPKo;
        OdJwBFqvTvI -= OdJwBFqvTvI;
    }

    if (htINfPKo == string("AznpimSbGOplaVgZLwjeKZIptdWEvsZML")) {
        for (int lvTwFGhjzn = 1337294310; lvTwFGhjzn > 0; lvTwFGhjzn--) {
            QPJIbHdnZ = ! QPJIbHdnZ;
            CTgkxetcmf = pOhutwh;
            QPJIbHdnZ = QPJIbHdnZ;
        }
    }

    if (pOhutwh == true) {
        for (int mXdRyKsfNzyy = 134535462; mXdRyKsfNzyy > 0; mXdRyKsfNzyy--) {
            continue;
        }
    }

    return jmHKVfgxmJuEIxbQ;
}

int iSvXkjhUyLLg::oyRbFVUW(bool QpCwANfcNlL, double ByMzxBmuA, double AbIPUfXovk, string WdXuZqMxoFae)
{
    double jXmOOmxgtOXNE = -516123.32079624233;

    return -887916761;
}

void iSvXkjhUyLLg::DjpCvfJpZfzmWNI(int curosxJvGZTp, int XvEtk, int bZcwOsClTQ, bool XrsxKvmqfqqF, double PiaPRhE)
{
    double OamYBqvk = -155063.33940382;
    int CNEVfpWrnM = 84662925;
    string yJsIYrVOYmSbcl = string("LEpIZDXcAVyCoPRZOsUPEcNjBvcelcNYpJXRTrkHjQhRATVMWwZhC");
    int qMvnF = 365365189;
    string BZAzd = string("GsqrwAkUNUUEzBGkdvIJZYywibfjnNSFwjHrmKuHomACNXZYgEpyXEsRDpbnEdytHSuKfUqOaTEfhXtUEEMCTseAk");
    bool YpaOXhHH = true;
    bool eArmNLKDoXnKqMA = false;
    double TJgngGhdwoq = -161123.08184578712;
    string Itmrmmq = string("SquPwWpCaDmTuqVVXVRwDxWZIgUOLTvbLdFDOnwRMskHPIhRiVpQGaZxVFoLXTztfWBfPFluAxXWTyhegtNVAVzboHaeqCOiCdEkBeDOxMvLROcNulOFPNXlEkuNdakiRjElUVDwUyCaFWXJNEgBAZppAFIppCvgOGYHQxDhALZiLroKWRV");
    double sXlzYV = -454448.1317000081;
}

iSvXkjhUyLLg::iSvXkjhUyLLg()
{
    this->AIZNZ(1794383142, string("KFENFOKYxgxgJuYvUPPlcoZSYssUqtSNxlpxmttswOUnARLJgZFnMOhjEInrVdkUmLHrTBZPNAHsWjdBzBerOjnmqfnWINUiHrOdsSZPAxNrPznckgeJDyTAatiXtetqkcTpXS"), 382897.3809002022);
    this->DeGGKyopDkAGVG(string("QZwafXrbAwACpMnRhOnYoASzxwzWwnZyEvIVkdNhyaeFxPSrHoaCvthEgvSrfLFNRpLByfBlOjnbZWcXTKrBAqLsTzcqklCqEUmUBEdbaBcLogOjMaRNoAmRGTWiH"), -103698095, 524813957, string("xFaSNSMhIFqhQkZjOWntIwSdeFHcoLIZhybTiOiXmSsQAFbcKQ"));
    this->raXQQedTgRhLY(1706672731);
    this->uNoLzUnUvnWR(true, true, true);
    this->SVcDSWVTE(2006221102);
    this->fyZIDNtOgQjoJcT(true, string("FILKGcYXOYJvUbhBefXazqMHjegERulGGuUPVDhibqXvjBhRiaKbKTBTdqbMmAZzHidNnWzFWDav"), -503071.4102741115, string("hPLFcWnfZARjUClxoXLSCFepUDoyRJIxhHlaBEvPAsIvDVgAXZJbziqrjEetQrikyrNFMQLTORdAOZKoEMgqNLrjgdaBgMlZQBwcySIHzJzVopRxyIyTADErrzMEomhrxhRzwGekeGaGJITmhrQqtodYKwhqLZmwGxIJjHguSFTDfzBkZNbfMMPTRrMcuPWtlIekJ"));
    this->tjCxWNbthLxaoTMY(-196327.87976870322);
    this->bMaDUxtygA(string("FxrAmNvkuOinayJjMBoaBxeOOyvBWhWYQsVQKVBBXgUhFaQzTPzAPKFXBvZsNZoGCQqPyPxart"), string("slxjrpXITtuUOjetBIZhvpuGHBMTwhnpHzoHibSDZojLmQoXtLIyVOMuQGoTPjydZePjeqxarkjGhqVCntWCwINSSbYKcTrMAZpKvIdAJMZgGmqKvjzzAAtIERwql"));
    this->arSgWlxKYrIg(-177119470);
    this->AEBZXGGmXuIh(false, -1818194347, string("jrUMZWIUJdIEfPOWTzlvDACRNiGdFzDVBmrrMVmbASmsejJNKQowAWw"));
    this->WTdtubKuXmz(509447.2273891377);
    this->yqBzUnquYuLqHZs(string("dRyJtDEiyyvYIdUGPIexpeqywfk"), -1680757563);
    this->vQVmqD(-1040780.3902986567);
    this->ErJNsrotqjtTOrLc(false, 838574382, string("RIEDtaWclrsHFMWDLsLkPnfqdCiFhgXrcFjENMvyKQqANTZjTAsUPkERIApSpKQKUbPxFJCfDuAdJYUyMeVuKmSyZyohweeFmmBIaspbWGTAWdUArQIEAUQWKiFXpgzgtjccaRiHHKPSKBnsFrALhIaTRhBIUrrpLgRwiPfRVc"), true, string("XOHpjhFVNrfEKwHWuLHnqvkyXvjbJxpvZrmiNwbqvXVOgZIcUESwLkvUOoAuqfigsxaXjdNfwdYrIKzGWmgvLoSRsWKUlDOyAHtQSqPyxqDsWHozGlnRXLhYNJOnCGrGOrHsNATcHkMGLBuyOmHPcHKsKuPaTiFLtjfJoeZNUnH"));
    this->vgmDSoyEHmZqRAO(240146.5242687846, -346769.16420664877, string("bSCDUCJljVPDiokjjWwAVEwBsGQRdUafJVrtxvTydQjVRPLmVcDFWGYwHtUSVdNQrbpbMEKjQZRyEKiBBR"), -1817849442);
    this->gkiGzMkr(false, true);
    this->MVECBjijPFlSudrw();
    this->wSfdfuTquizhsK(-1048137.317126457, false, string("AznpimSbGOplaVgZLwjeKZIptdWEvsZML"), 203651795);
    this->oyRbFVUW(true, 927760.4090771404, -217444.7287377006, string("YCJITsRGKtBCDwdzpkTEpNUDeFVNNgndqvwcj"));
    this->DjpCvfJpZfzmWNI(-1107990479, 589747115, -704080447, false, 512101.191352596);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lRkVs
{
public:
    bool fxJxK;
    int heftFOFLr;
    bool QyIjdfyQdeMyrSm;
    string GnxMnkMVwxoLBtZ;
    int khOYZmp;

    lRkVs();
    string CofvZau();
    void bphOxLvuHi(double fqWyy, double PciOuRaiLr);
    string TefeQjBgDiQ(bool yTPmnNaXoHUv, int lHbbKutQ, string HgVzwEQYv);
protected:
    double QYeqxYBMsVTss;
    string HaiyeSKNQyTW;
    double uVZBFP;
    int ZvYaiCSqbRYTD;
    string LXZffzvfH;
    string pKndhuDgQT;

    string BDdvwyBaIIFLyx(bool GUwzdFnkQaOHNphH, double ewPyeg, double RQPZuwcjub, bool sCZUuL, string tqhNHTctNWeuE);
    int pdcimGHaWO(int AJYYIo, bool JcQafzlSzQgn, string ImQXwnyn);
private:
    int oKaDtZgqkhQMiUsM;
    double iZbFQCVUcS;

    bool rAZcnSkFd(double VkiOcoCT, double bCqLLDMyeOJMFrpW, int hWxpIiteFsXQhEE, double oXvDZ);
    void vmKoZpdtYOGjWug(int ekquFPKIgd, double qUIvMhAVzh);
    void dSqflxfrEUj(bool tlBGea, int eexjCVPloJn, int YgJNzTIwirN, int gTBPwFS);
    void vKtqfCOr(int ICeilqZ, double JhVtCF, bool TXiOaKezawiYd);
    double MEmSHNuQwvnuhGI(string SndExZD, bool ljsLiEeIApvsxW);
    bool XrDOv(string BcifSECcICo, double ntUQGTSsECKKuo, string fUuwwZRlQqUMbM, bool jJInTJFnwFsOd);
};

string lRkVs::CofvZau()
{
    string PYVYlVdCpnWFEqNM = string("CUSpJDyFHaSiTTjeECiOGFevUAKpfGeqsogsDTRVDxxAnixNQWDqFOQajvdxDiwStJSGcHcMShnphWCbgeNVEBTqhCFeRiBbbaEFdLTrgroeJdgXUBSxozFxAiqckGNNSweKMfAmHSQqJlsdzLMFSpkCVfdvoYBKHpTmHZFVGmnFWFLrYHiizXUnzfhxOzebygXelOLANJpVCvliEsoERDimIfBOwsCQHFdJtySMBGaiHbtxNekHQ");
    int ovwsPDrxBzR = 1581295157;

    if (PYVYlVdCpnWFEqNM <= string("CUSpJDyFHaSiTTjeECiOGFevUAKpfGeqsogsDTRVDxxAnixNQWDqFOQajvdxDiwStJSGcHcMShnphWCbgeNVEBTqhCFeRiBbbaEFdLTrgroeJdgXUBSxozFxAiqckGNNSweKMfAmHSQqJlsdzLMFSpkCVfdvoYBKHpTmHZFVGmnFWFLrYHiizXUnzfhxOzebygXelOLANJpVCvliEsoERDimIfBOwsCQHFdJtySMBGaiHbtxNekHQ")) {
        for (int qnDoTgslnkBsDSrP = 1724076005; qnDoTgslnkBsDSrP > 0; qnDoTgslnkBsDSrP--) {
            ovwsPDrxBzR += ovwsPDrxBzR;
            PYVYlVdCpnWFEqNM += PYVYlVdCpnWFEqNM;
            ovwsPDrxBzR *= ovwsPDrxBzR;
        }
    }

    for (int fuckV = 337309581; fuckV > 0; fuckV--) {
        PYVYlVdCpnWFEqNM += PYVYlVdCpnWFEqNM;
        ovwsPDrxBzR = ovwsPDrxBzR;
        PYVYlVdCpnWFEqNM += PYVYlVdCpnWFEqNM;
        ovwsPDrxBzR -= ovwsPDrxBzR;
        ovwsPDrxBzR = ovwsPDrxBzR;
    }

    for (int rYsLeSFePDGfewGg = 1366775404; rYsLeSFePDGfewGg > 0; rYsLeSFePDGfewGg--) {
        ovwsPDrxBzR += ovwsPDrxBzR;
    }

    return PYVYlVdCpnWFEqNM;
}

void lRkVs::bphOxLvuHi(double fqWyy, double PciOuRaiLr)
{
    double esoOeBRvSQfXnrC = 170524.16812152197;
    string QNzEmfWWzKIF = string("OykIZOFSmLfHFbWkvNZCBRaPFhJpwOswHoOTZldooXkrJxVYJSvhWIMvCOmYXdHPXGXUkffBYYvnIhHrgTgdqulKSnmsTXIfwotEGyUzpiYXfRdyfZanXSJHoAaiGlSzHuJnYCUpVpbuDGvLoWkVPkXIzzStGDETugnlLTTWKJtqtxJSyXPfobTDamuiYPmGJZdpbMRRxpjZYRFNeINWCGFXZErIWliIAzmEbNWzOBBMicfPEoaGLRETW");
    bool HmjHXYJEFjciqD = false;
    double gLSaxt = 941580.2365782046;
    double NBXolKkvNDQjx = -238409.32212318192;
    bool LgBEoTwVImVex = true;
    string qMfpZUnrZWVywm = string("rIXVYZVfRAUlLuFvNF");
    double OhJgLDKZgwMDzLM = -213839.98189652516;

    for (int TZmGiIOkKkCPUDD = 522202907; TZmGiIOkKkCPUDD > 0; TZmGiIOkKkCPUDD--) {
        esoOeBRvSQfXnrC *= gLSaxt;
    }

    for (int kcCBfcJRaZJURDfM = 357150254; kcCBfcJRaZJURDfM > 0; kcCBfcJRaZJURDfM--) {
        PciOuRaiLr = gLSaxt;
    }
}

string lRkVs::TefeQjBgDiQ(bool yTPmnNaXoHUv, int lHbbKutQ, string HgVzwEQYv)
{
    bool XvSPtjQgGovsMsh = false;
    int cwTQpCCKYov = 906611886;
    string BMmFEayaUeBVSpQC = string("UqUHolYoGrBukuFyAatSnmuTUlbjfxGJadyVyqpnSiiLoPqRoIiQanKmMADiPcOJnIaMlnQKzjhhmVzADxkqfmWrMgUnmlNpRWTdSUHHbCmfWnNHueezzeSlrAXRMZdSfxuaUVUodJrsjurgTUJZPOulvSheSZIsMmlQRfjDumIuoUZryBRNYaqgPiPIYcxMeCsRIMkaDXMFAYUApftrqEeFprYIqkXiFShrmToKBMVHrZd");
    int PseWQ = -1977603652;
    double InRlGUwrComBv = 572338.7597206638;

    return BMmFEayaUeBVSpQC;
}

string lRkVs::BDdvwyBaIIFLyx(bool GUwzdFnkQaOHNphH, double ewPyeg, double RQPZuwcjub, bool sCZUuL, string tqhNHTctNWeuE)
{
    int vKrKyXLLOC = 381534132;
    int ilYUYwhHr = 576337014;
    string Niifd = string("xYNRECLRBzDFqYkAFewwGFOHqyYNXpWAlryRaQcQWFdEXBMi");
    bool wsuNejjeE = true;
    int tbuHzaapXOy = 379366814;
    int chaxhAxARFDqX = 983777623;

    if (GUwzdFnkQaOHNphH != true) {
        for (int QSDCpTzDhkCWLbO = 1061086723; QSDCpTzDhkCWLbO > 0; QSDCpTzDhkCWLbO--) {
            continue;
        }
    }

    for (int TdUQpeCf = 1349958682; TdUQpeCf > 0; TdUQpeCf--) {
        RQPZuwcjub *= ewPyeg;
        sCZUuL = ! sCZUuL;
        Niifd += Niifd;
    }

    for (int qkzcJqNFjIPy = 382402597; qkzcJqNFjIPy > 0; qkzcJqNFjIPy--) {
        ilYUYwhHr -= tbuHzaapXOy;
    }

    for (int DqnrMmxhvHft = 893739486; DqnrMmxhvHft > 0; DqnrMmxhvHft--) {
        continue;
    }

    if (chaxhAxARFDqX == 381534132) {
        for (int fXdAWSzVSmd = 108507845; fXdAWSzVSmd > 0; fXdAWSzVSmd--) {
            continue;
        }
    }

    return Niifd;
}

int lRkVs::pdcimGHaWO(int AJYYIo, bool JcQafzlSzQgn, string ImQXwnyn)
{
    string SHwRWKmt = string("nrwUSSdIrRdzFfijZqSvnEuEweArMaZNIhwRqJSwWtQMyyBTRPZrUAfabTNcCEbMlLgrUAUZzdiNOgzZZeeJtGL");
    string WgZPtkuzaVXijXh = string("SiARGoOPsZsIQhgJybXqCDjxqrdzFGQRNMQLogPeLmlQciccCeFnfjMENsMqnTLrnGgVokybgRFOhhhCpJGujChbIAFDnIVsSojesxppYEyBzYWDjYmcleuMNFLsXCvmJHvQZyXzBPjpYpoGUQabQwbqqkRYlNidBLhlAdwTChWQyDjeUPERguIGmQTqcTXQHPZDAKutxXiYGr");
    double XIZDHz = 842445.3395102907;
    int CbIkbvKZmr = 1412929566;
    double rnkoObkl = -574835.2534382797;
    bool hlQgJH = false;
    int incPbj = -1451159957;
    bool StbZDYwWhzKlP = true;
    string qYxvj = string("CHUwbHAhORVAYhhtMZzutcFbTesRhDVyRkFNWAnzZlBHkxTuYkNgpAwItKhhUegunBKDlsNciqIcwrFZYJRCWWmoCaICdlychpjkUwOmeeUYGovUpaQPkEACBinMJZLBhaxMppbxAZayndltBIWuaVUllIRBccvVyOxCbiYPUckcsOIcstwDtNhQkHRlMvv");
    string VQuHbqwmNariittX = string("LeySySQLakCjOTBHoRThMnWWrkwOznvLmHFdxRmdALEAUfzGXUnkmAVPzNNfZWefzDFhYrdIQzxLtObYXGysaevitEKgqTQJoahbHhouDbYZBOMvVATNXBweAWkHcuFhCxIapTIMuvfUjjGhymxIJATonNDpvyMbvCjMgEwZCoCxHWuCtErknCh");

    for (int KeLUyrnDcVU = 1619988295; KeLUyrnDcVU > 0; KeLUyrnDcVU--) {
        WgZPtkuzaVXijXh = ImQXwnyn;
        ImQXwnyn = ImQXwnyn;
    }

    for (int DEvagBhLLvEQ = 1570121202; DEvagBhLLvEQ > 0; DEvagBhLLvEQ--) {
        WgZPtkuzaVXijXh = WgZPtkuzaVXijXh;
    }

    return incPbj;
}

bool lRkVs::rAZcnSkFd(double VkiOcoCT, double bCqLLDMyeOJMFrpW, int hWxpIiteFsXQhEE, double oXvDZ)
{
    double LSAWCQonpiyi = 283877.27720996004;
    bool pWXsKENMiaSMnu = true;
    bool eeAcJMrxbgTN = false;
    bool lrNGYzjQpMGhEJ = false;
    double mUCaQbs = 341543.7505850718;

    for (int DRKkHpVfUWiH = 1684060466; DRKkHpVfUWiH > 0; DRKkHpVfUWiH--) {
        VkiOcoCT /= oXvDZ;
        VkiOcoCT = VkiOcoCT;
    }

    for (int jiyaGJjVTc = 1568694950; jiyaGJjVTc > 0; jiyaGJjVTc--) {
        mUCaQbs /= LSAWCQonpiyi;
    }

    for (int UkmBdwKhHNrWYQF = 1668136674; UkmBdwKhHNrWYQF > 0; UkmBdwKhHNrWYQF--) {
        lrNGYzjQpMGhEJ = ! lrNGYzjQpMGhEJ;
        mUCaQbs /= mUCaQbs;
        mUCaQbs /= VkiOcoCT;
    }

    if (LSAWCQonpiyi != -206420.26712594472) {
        for (int zDNHNzKyL = 950601040; zDNHNzKyL > 0; zDNHNzKyL--) {
            oXvDZ *= LSAWCQonpiyi;
            mUCaQbs /= LSAWCQonpiyi;
        }
    }

    return lrNGYzjQpMGhEJ;
}

void lRkVs::vmKoZpdtYOGjWug(int ekquFPKIgd, double qUIvMhAVzh)
{
    string zOFxdLIpDV = string("AqpzTNXtFamYNphFFxhMPAvxAetoamsFGEjCFIKsgbybhxLmGRJlQYLxngQHBRvkAoPnXjtiMwcLRlMdDImYIFhCVVlbCsHfNQQLiOAktzBgHXHmKRIBwOEFvRbaBrllzKYFseTNhGWgbuKnTvRbTJlggHPzsisxMiRatvipLhYLChPPpaldpMYzyWMYMHvkNDLqLVGKSwHu");
    string wuQjOhLXnGvxxuh = string("gxQjGqtasGQyQjjMYtRuedCzeAaiGiCFwqJpgFGwHUyTGNdCcsxCoQBKfOkTAecCbSxyFafacBGJcfJopiInVUbktpBqiaSCkCghgGOTjrDVmAhjdvAflgxMUr");
    double GdZNZymlJBRscHap = 846899.072063117;

    for (int JnPNjYTIVnx = 1156116101; JnPNjYTIVnx > 0; JnPNjYTIVnx--) {
        ekquFPKIgd = ekquFPKIgd;
        ekquFPKIgd -= ekquFPKIgd;
    }

    if (zOFxdLIpDV == string("gxQjGqtasGQyQjjMYtRuedCzeAaiGiCFwqJpgFGwHUyTGNdCcsxCoQBKfOkTAecCbSxyFafacBGJcfJopiInVUbktpBqiaSCkCghgGOTjrDVmAhjdvAflgxMUr")) {
        for (int kOXaqaQoot = 191184044; kOXaqaQoot > 0; kOXaqaQoot--) {
            wuQjOhLXnGvxxuh += wuQjOhLXnGvxxuh;
            zOFxdLIpDV = zOFxdLIpDV;
        }
    }

    for (int wNhZZwaX = 789073614; wNhZZwaX > 0; wNhZZwaX--) {
        wuQjOhLXnGvxxuh += wuQjOhLXnGvxxuh;
        wuQjOhLXnGvxxuh = wuQjOhLXnGvxxuh;
    }

    if (qUIvMhAVzh >= -35296.82105358477) {
        for (int OnsLiJV = 445554210; OnsLiJV > 0; OnsLiJV--) {
            qUIvMhAVzh *= qUIvMhAVzh;
            GdZNZymlJBRscHap += GdZNZymlJBRscHap;
            qUIvMhAVzh -= GdZNZymlJBRscHap;
        }
    }
}

void lRkVs::dSqflxfrEUj(bool tlBGea, int eexjCVPloJn, int YgJNzTIwirN, int gTBPwFS)
{
    bool uDxMXHgwhvWbRHi = false;
    string aXFsMm = string("nvsTzdEaTEDYQZessrkKcGSFpwjjWNjeadKgBdBbkBOHRvHKJh");
    double ekIFNRMTALCVUH = -260326.58397755484;
    double kRywdA = -738796.435905416;
    string JZwYmITaQLBabMg = string("ifKrNXfyYazTaoeEkPAsQaJlbQBtGNyzwyehOtgShyMxXOzPpzjppdPWKnCZphxENeNpNonTLyOrOVhaknPeRihciAlUswgoXprYCtlTbZUKpkHzCoEyRDBKgZMehyNtuXQsOKfbMpfmdujXYrYNIMvmCrBBCpHCIPGAPxWqvsKZspfQhVpzTbzsZrcNXyfP");
    int eKwKTHkNSr = 1124607058;
    int rDcdIT = -1478127696;
    string qWDrQr = string("kTkHCqcOFuLoDiAuCfUxtCXmqlGiexHPXgMVPZRINRuWRgXtQBFmFaXYZEIbXzOlUezJRWAJNjblzvDXue");
    string XgCUUGuhZX = string("OlTVYkBsPkCnSlxautfCplwqwBstXPxalltjuYSRxTLRSmpsbDtTENaJZMLKVUxeCiSpBAOlWxbboWWEIWTtCeigvyAAXdkGLyVjsFFBBkEmBUdrSRkcIPCgvcyVXPMcmhviTUgfKbwaNWxuKhmysiwZSzKLFcjSDHJrsYStPlq");

    for (int FJsFWZe = 72186494; FJsFWZe > 0; FJsFWZe--) {
        YgJNzTIwirN = eKwKTHkNSr;
        eexjCVPloJn = gTBPwFS;
    }
}

void lRkVs::vKtqfCOr(int ICeilqZ, double JhVtCF, bool TXiOaKezawiYd)
{
    double OVXjKvdhY = 649825.9693450368;
    string WjUKpccFoNgaV = string("NaUkjHhijaUoioOxCdxXOwSFeqNoIUyofvmTNzDAlfzFIWFayFpZUYPSgrZQbjXqRCAbLzEypDzumxXXpOkuSoVVBHhYYdKYSKrzldtRUSHfEOCsbeshpeWkGewvaDmeisKCWMucQdgDKMlnne");

    for (int EblYZhC = 1912493793; EblYZhC > 0; EblYZhC--) {
        ICeilqZ -= ICeilqZ;
        JhVtCF = OVXjKvdhY;
        OVXjKvdhY *= JhVtCF;
        JhVtCF += OVXjKvdhY;
    }

    if (JhVtCF <= 649825.9693450368) {
        for (int NgoDnCAjxa = 1038507936; NgoDnCAjxa > 0; NgoDnCAjxa--) {
            continue;
        }
    }

    for (int ZXvRWOhlvWAIvQF = 1860977960; ZXvRWOhlvWAIvQF > 0; ZXvRWOhlvWAIvQF--) {
        WjUKpccFoNgaV = WjUKpccFoNgaV;
    }
}

double lRkVs::MEmSHNuQwvnuhGI(string SndExZD, bool ljsLiEeIApvsxW)
{
    double mLOszhGsCwlXFe = 176293.7307242371;
    string bdKASKKwedViQ = string("CBUILwiBpc");
    string mgOMRNQUmzufb = string("aNZFlcZceaTpTZFkwLBoVrcMJWgTE");
    double XXmXOX = -126603.34501118973;
    bool jQWPVUPcbFyb = true;
    double DGTCHw = -621818.3263494581;
    string wYgji = string("LqIHwlaLKJCpjXDqCJijUgqRA");
    bool dzFbqNjV = false;
    string YPXPVkkS = string("lOHvVmpMQjZThwDcpMiNmKMMQNdCWdZLuxzYWwMUBJKfmfIQQhzgzllksYFdlHRvOLfEINVeakUWJOjzbmZiBECFagUMJSdYiZKjqSiAvisTwGINfZtpMCCYTRoFnFZlHSHwnKOddcZLKEYskwqlbSWtiaHEYLAiiRWNPnOrFgVQOdQRavvpVslDdODZC");

    for (int dQZcNjrR = 129076604; dQZcNjrR > 0; dQZcNjrR--) {
        continue;
    }

    for (int veMWHvB = 554772342; veMWHvB > 0; veMWHvB--) {
        XXmXOX *= DGTCHw;
        wYgji += wYgji;
    }

    for (int sDdXObvU = 266024263; sDdXObvU > 0; sDdXObvU--) {
        mLOszhGsCwlXFe -= DGTCHw;
    }

    for (int OJejeIY = 283104631; OJejeIY > 0; OJejeIY--) {
        SndExZD = wYgji;
    }

    return DGTCHw;
}

bool lRkVs::XrDOv(string BcifSECcICo, double ntUQGTSsECKKuo, string fUuwwZRlQqUMbM, bool jJInTJFnwFsOd)
{
    bool RpwZahKShO = false;
    string XYhIDeYbwytzEsl = string("IQQIKpfmjbhgQoyzNphZOsUfBHoFMsaZGHZdjXtIeSRQKRYAsBoEDgZqgKznFCUkxIbfkOaztbHQhxOMnbKrUhwevcEpBeGhYtreEQHgepsgITsKnIqEVCOQsNXrgwyauVSKWBvXapqZSRVZqoNLtnvcNTYhinFUSzgDPJFNEZDHWKGppaeDXsiJXjmxsIOjFwFjndoFxbqxscREsOBshrKg");

    if (jJInTJFnwFsOd == true) {
        for (int gDbBRHTBAHa = 20403057; gDbBRHTBAHa > 0; gDbBRHTBAHa--) {
            RpwZahKShO = ! jJInTJFnwFsOd;
        }
    }

    for (int FntPkBfuDkcVluoL = 20810152; FntPkBfuDkcVluoL > 0; FntPkBfuDkcVluoL--) {
        XYhIDeYbwytzEsl += XYhIDeYbwytzEsl;
        fUuwwZRlQqUMbM = BcifSECcICo;
        RpwZahKShO = jJInTJFnwFsOd;
        XYhIDeYbwytzEsl = fUuwwZRlQqUMbM;
    }

    return RpwZahKShO;
}

lRkVs::lRkVs()
{
    this->CofvZau();
    this->bphOxLvuHi(754037.6812735689, 329495.7600452081);
    this->TefeQjBgDiQ(true, -352464537, string("UTnKBKvRksGTqNZvyHeirULPesuhATNfRROFrVBUGlKlruvAxZZodOuFoMVvVpbqkCYcVLaojmnsPrKfzuNERMbwklWOQEfXHxlsYUDIHEvYVxaRtTPmiLFIqgZoGIDmCoXqBAAwAymhWZRiDAKLSZnsNISNdCWOeGGRqzrtHjGWtUEqjOvkbIpkTTkrbZHZXPwirNlSvHLUPfehbwyjnQdpy"));
    this->BDdvwyBaIIFLyx(true, 524855.9038834628, -859969.2093973936, true, string("xKvsOnducuvgfaNIJfBfUeySwKSzySEAjLkwpHgJEMzbFpTrDnreLAGpHFyOBfthKKWmRSYHrBMYHYFrnjTxfvawiRWZtZXNiskLgOMiryYGehCIqUtUmxZJIayrlpCalogrdAPBGOLhzoAtKtAzgdcbTgNndnUzgyKHwODXrzSYpKhQguTNpCoolRXqEJtBNHnpQsleLeuXnakpAHIpuD"));
    this->pdcimGHaWO(-1349253360, true, string("KUwfBDmMqZRXxJWTeAWSjtvkQDKELALmRPADIrAssiykKNBkwmZiByScFxNEGVYnZoFpimhSjBbfHEtHLDqeIfHOhsXEVZjnLpAFGsHeAeoxprohrVfxmWInIwHAebpZRAKhTKffzgL"));
    this->rAZcnSkFd(480746.03102303157, 460166.25634228496, -1969354700, -206420.26712594472);
    this->vmKoZpdtYOGjWug(-1082720909, -35296.82105358477);
    this->dSqflxfrEUj(true, 1621204082, 695397230, -1248396379);
    this->vKtqfCOr(509424180, 4678.003270041303, false);
    this->MEmSHNuQwvnuhGI(string("oXZzihe"), true);
    this->XrDOv(string("fAtaaNhil"), 253687.18863990915, string("IulgQCtePSaoyukJyszJwjqZlWhyJqJNGTRJBAlfmeqYyERYhyxmQxLXLbAuRWURSptRuNydixmRIOwWZPWQiGZiiGLYDEseTwqrotGGWeDVXUlxqRZAYyvSRNKdQExcBiMqGKdxssimbOFXAKPCSTeprzIuiWGPUkjRNuJYNavjhhnmOwBeGZoZraaLBiTeEtNxMmXNlGgDvRkZwNNqHj"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iwXgFEr
{
public:
    string fPMYWDVkNP;
    double lYiQmshim;
    int SKfqhtF;
    bool QOkOWzaDfIU;

    iwXgFEr();
    int DlPDFYFfYi(string QuCbLAGAsGW, int oqbQPQdl, string oyCUeXfjMKR, bool ikqnXAu, bool FUbufxyoooRVWWYf);
    string tvTpPOviRvDyoyW(double ZWSpgC, double GxRdNCkAHI);
    string mnpBwsWOOB(string vpWRnTUvSunt);
    string nPWeQwredCd(bool TFTHevnGvQne, int nvmDKFURvQ, bool yxaTnGWQtAMLc, bool iCLoDFo, string bJHcnlGpo);
    string EaDieufZQTZOoBY(string tQeoUSIQjUD, double zgmbPDKZu);
    int UvElPU(string QVQeqCsl, double CITUZSM);
    void SDbzvlSJyXH(int LnnAgVjYaRadPu, int FJzrLCRXK, bool MgRNmeJRNXUUAD, double cqQOVSIPTmPPyfDu);
    double FJvEkCTzSFe();
protected:
    bool EtHFmRnkLsQw;

    double uInITwuRm(double LiDfqEuOeAzydFkh, int KIzQBgJqfGa, string jdjNefEhgI, bool JUBMRuIFm);
    int xpfpCjc(string MjiqSnMQPMU, int ooODOUzGcy, int qbjbMHLdyvVCrCJX, int SWWSPnKvUvKK, bool EwIVHo);
    void HfKtZnbcA(double rlXSqYmSVDiXHy, string RtyXplOqQq, int xSUCkZRCVPMc, string YcESQTofQT, int WszYJWqKXMX);
    int tmACZyCzEY(bool qwFimGeOgaensJy, double qSkKhz, int YgdRIGdTnFWSiJq);
    double BCforJVG();
    double eCvRymf(double TzGokqYDUwLPH, int MKAwsVSZlifo, string MvXeB, string fbATeYIA, int BJfejWbUBDnEqJ);
    string dTPwMqgsXmEWzkaN(double ipklknDTis);
    string kYazvfdk();
private:
    double rXGsuQAoisLsgGJ;
    string pgysMeUStL;
    string awAKZd;
    int pBtCzFjxR;

    int CeSIseldFWe(double ZXJYtrsCjcE, string Sfwwrwr);
    string RwKhgmJ(double nGkDxCegGYkaqK, bool NKwyKcGaKV, bool UTeVNSXp, double lVUYylQrEcKGYD, string awTSmeep);
    string gqbfx(double YxdLL, bool sMKpp, int vNITNZoQait, double JvKHP);
    string TwppMMSOjhNZ(bool iYAdKuo, string UUwPvouWx, double hWqqA);
};

int iwXgFEr::DlPDFYFfYi(string QuCbLAGAsGW, int oqbQPQdl, string oyCUeXfjMKR, bool ikqnXAu, bool FUbufxyoooRVWWYf)
{
    bool XJOuy = true;
    int VwWXd = 880624906;
    int cMKcfoJDP = 825536130;
    double kIiMYoinvApYdVU = -988770.6554010867;
    double YaYIofAPD = -787577.9864840274;
    bool mwEgqDNTcmxr = false;
    bool TYRZFomT = false;
    int ycUaRMGeirNVr = -1033646241;

    if (FUbufxyoooRVWWYf != false) {
        for (int IlFYEDERkxZnh = 1928763017; IlFYEDERkxZnh > 0; IlFYEDERkxZnh--) {
            QuCbLAGAsGW += oyCUeXfjMKR;
            kIiMYoinvApYdVU -= YaYIofAPD;
            mwEgqDNTcmxr = FUbufxyoooRVWWYf;
        }
    }

    for (int NOamyIkLnIFcdm = 86465604; NOamyIkLnIFcdm > 0; NOamyIkLnIFcdm--) {
        FUbufxyoooRVWWYf = ikqnXAu;
    }

    if (TYRZFomT == false) {
        for (int CGnvDS = 243090371; CGnvDS > 0; CGnvDS--) {
            YaYIofAPD += YaYIofAPD;
        }
    }

    if (VwWXd >= -500589620) {
        for (int mjbYzaBnPkSQTuKZ = 849729148; mjbYzaBnPkSQTuKZ > 0; mjbYzaBnPkSQTuKZ--) {
            continue;
        }
    }

    for (int oGTwjKIsxkZw = 963072822; oGTwjKIsxkZw > 0; oGTwjKIsxkZw--) {
        ycUaRMGeirNVr /= VwWXd;
    }

    for (int QXNMqRSZX = 1248184109; QXNMqRSZX > 0; QXNMqRSZX--) {
        continue;
    }

    return ycUaRMGeirNVr;
}

string iwXgFEr::tvTpPOviRvDyoyW(double ZWSpgC, double GxRdNCkAHI)
{
    string IFEMXRUhnNGZ = string("wazlFUQlxVbkyNTTqdugoCWkdtlChsnGUtBBTntEHDHqCvrKwlbOLSDejrqktMtrFbZgvm");
    string ilqaLbSfzwCIKB = string("VlAoUfqLAGLAnBJAipSCtufHBeFXpEMbVkwqGssYGhHhiedWogYFyPYUGlfmxyEwgImpWjRTIzFXJfnkhTsVggiAgdkUCHLADqRECoPlXTXxRWSIXEclbegULZwqQPYoeVOJUyTdLnsYIgXHDTeRTBzRUkCEefsVgUpXplHiLcgKGCRYivdjNAiAybVpqDHRUaQmrnRdMcgbbeVAmTLPh");
    double aRKXgcIRKXRNGS = 860524.0556425663;
    bool JPTvf = true;
    bool bdDJgnhwMz = true;
    string zwMLLxFbZx = string("sxaGaJjOATCRQoSOoQaozZHjOmfUIAIJGsFLjhyivLECgnV");

    for (int TAbZcwHhgVWk = 280101468; TAbZcwHhgVWk > 0; TAbZcwHhgVWk--) {
        aRKXgcIRKXRNGS /= GxRdNCkAHI;
        ZWSpgC /= aRKXgcIRKXRNGS;
        JPTvf = JPTvf;
    }

    for (int wvOHrr = 579576600; wvOHrr > 0; wvOHrr--) {
        ilqaLbSfzwCIKB = zwMLLxFbZx;
        JPTvf = ! bdDJgnhwMz;
        IFEMXRUhnNGZ = zwMLLxFbZx;
        aRKXgcIRKXRNGS /= GxRdNCkAHI;
    }

    return zwMLLxFbZx;
}

string iwXgFEr::mnpBwsWOOB(string vpWRnTUvSunt)
{
    string DUUpFxGsnfDKDXcj = string("AyaBwUQqKwiieCYEuWhhAQIevWBjqOVEORrJINekWhuCeYrvrogjUjFMWBbGUiRKqydo");
    double vgNef = -173244.33384911358;
    bool JzQNNAknfPhauepB = false;

    if (vpWRnTUvSunt < string("IQuUtAEpnSDoHZRMZIZCDAzOlsqZqxseKQBmqHFBilalDmbzVhKkuDUsnBpFismBBEGAQTWuxnuStDUrtnBxGCumcAhgYhNGoLTMKyyETDyfGnSOHtBUutYtGgIIBAiJHtfkPEuRTfCDGHKsKQbKcEttcFcvghqtkJwEfnrdyLGiCzxDfKCIsgCVqhCmmuozJGVibPgLsbfxgNwAPzzFCNtnyvpyUuefHnPoqldusGScrHLSBznxytsWUY")) {
        for (int EFjeNIvzTJE = 112034035; EFjeNIvzTJE > 0; EFjeNIvzTJE--) {
            vpWRnTUvSunt = vpWRnTUvSunt;
            DUUpFxGsnfDKDXcj = DUUpFxGsnfDKDXcj;
        }
    }

    return DUUpFxGsnfDKDXcj;
}

string iwXgFEr::nPWeQwredCd(bool TFTHevnGvQne, int nvmDKFURvQ, bool yxaTnGWQtAMLc, bool iCLoDFo, string bJHcnlGpo)
{
    int RZEHOxmZNWKAGZ = -1574240858;
    string mnMqRaOWqgfc = string("kkKyqfPKbkMqqJUGUOeMHqdJIWsdy");
    bool gNmcCrcrMIijOrTW = false;
    int GCpxYv = 1035330362;
    string VkXsqzShxV = string("HhutPWkbCqKVdRnrgmCjDFYMHokFPHlkQAyWHPQWOhXOzkwaQyULWqYWaTRwxnMJDWjIMRyxaOP");
    string plQctglFUVddo = string("cGvqGTDtAUkoPtrjFFcwlSkNDbnKsngywTdOtShaYkHilsEVJbUBQkyjiXQvMshFEQZflvDOYNzAPznoKIjyRCEMaJxtkYRcHmPssahdqTquSMzMcYlXRcbrgdqRUcYiuqZZiptByhOXxmSAeVLnfqeSiptvrKSuhZFctHdWNFXNLArYPYSENAnOewhObYKQAuYuhPdCYmzGxaHlVkPAixTjOsdEDNOlyxfAlZRDLqksukXSolNmJj");
    double cEqQHvSlywC = 909220.8398492945;
    string bCxPplhDwHfunu = string("YaTYmufHswsaloAIQWfFWFtJzQdXBiZjTEkezjoZhjoMMYHXXhXgbJwYwGmRkJLVvmkWCFOmrsYQpurBGPXqsgLyvxLJQVrjYaZRJBWrBiYqhgiMMXMbUBNOIQtMFlrdKayzXXsk");

    for (int dlqyYhaOOFQW = 770127056; dlqyYhaOOFQW > 0; dlqyYhaOOFQW--) {
        bJHcnlGpo += bJHcnlGpo;
        VkXsqzShxV += plQctglFUVddo;
        nvmDKFURvQ /= nvmDKFURvQ;
        bCxPplhDwHfunu += plQctglFUVddo;
    }

    return bCxPplhDwHfunu;
}

string iwXgFEr::EaDieufZQTZOoBY(string tQeoUSIQjUD, double zgmbPDKZu)
{
    double nMXoGqOByacFc = 666685.7848372841;
    string pNeQyvSkrbb = string("hEBLCDeYgHRUjmrITyPaxmCdtbsJrDqqBAGDIYecJqNWsGFGzRNakJvZjLYjFtCTbEltmKrfmkYRlgWkUclfQQUaLhMVKmvCyTvhCnRcpvFdyUsMIzdrVKmvsdPwbmNwTBqcpWUuLAmGOKoekqudAnOXCPVCQJUljaloDeiMPYkZrvOXqIWcFjLItTacsHzcHOGnlmjD");
    bool jKHBRNhYahLskh = true;
    bool ssUJXJ = false;

    if (pNeQyvSkrbb < string("hEBLCDeYgHRUjmrITyPaxmCdtbsJrDqqBAGDIYecJqNWsGFGzRNakJvZjLYjFtCTbEltmKrfmkYRlgWkUclfQQUaLhMVKmvCyTvhCnRcpvFdyUsMIzdrVKmvsdPwbmNwTBqcpWUuLAmGOKoekqudAnOXCPVCQJUljaloDeiMPYkZrvOXqIWcFjLItTacsHzcHOGnlmjD")) {
        for (int HLlisVfrTVVAAMW = 1404933755; HLlisVfrTVVAAMW > 0; HLlisVfrTVVAAMW--) {
            pNeQyvSkrbb = tQeoUSIQjUD;
        }
    }

    for (int gGHjJTYqBl = 965287632; gGHjJTYqBl > 0; gGHjJTYqBl--) {
        ssUJXJ = jKHBRNhYahLskh;
        nMXoGqOByacFc -= zgmbPDKZu;
        tQeoUSIQjUD += tQeoUSIQjUD;
    }

    for (int YBLmZQWp = 545826956; YBLmZQWp > 0; YBLmZQWp--) {
        tQeoUSIQjUD += pNeQyvSkrbb;
        pNeQyvSkrbb += tQeoUSIQjUD;
        pNeQyvSkrbb = pNeQyvSkrbb;
    }

    return pNeQyvSkrbb;
}

int iwXgFEr::UvElPU(string QVQeqCsl, double CITUZSM)
{
    int ScrLU = 1071887697;

    for (int THJWQBAWwEmsWbS = 1683802815; THJWQBAWwEmsWbS > 0; THJWQBAWwEmsWbS--) {
        CITUZSM -= CITUZSM;
        QVQeqCsl += QVQeqCsl;
        QVQeqCsl += QVQeqCsl;
    }

    if (CITUZSM != 550156.2435444925) {
        for (int fbqBKQNCcRvEiz = 1438197964; fbqBKQNCcRvEiz > 0; fbqBKQNCcRvEiz--) {
            ScrLU = ScrLU;
        }
    }

    return ScrLU;
}

void iwXgFEr::SDbzvlSJyXH(int LnnAgVjYaRadPu, int FJzrLCRXK, bool MgRNmeJRNXUUAD, double cqQOVSIPTmPPyfDu)
{
    int NUwonnoQGHRUzpG = 952389497;
    bool CcsrIg = false;
    bool tBModrUkxqpfG = true;
    bool dqZDicNNkXd = true;
    int fepErzif = -541854168;
    bool zYpyQaBNiN = true;
    double jZcKTTrD = 715487.2211076169;

    for (int rmtgLExCezye = 316649854; rmtgLExCezye > 0; rmtgLExCezye--) {
        tBModrUkxqpfG = ! CcsrIg;
        CcsrIg = CcsrIg;
        fepErzif /= fepErzif;
        fepErzif = NUwonnoQGHRUzpG;
    }

    for (int DEVuRh = 371020441; DEVuRh > 0; DEVuRh--) {
        MgRNmeJRNXUUAD = ! zYpyQaBNiN;
    }

    if (CcsrIg != true) {
        for (int ZiXtBOROgeu = 7058546; ZiXtBOROgeu > 0; ZiXtBOROgeu--) {
            dqZDicNNkXd = CcsrIg;
        }
    }
}

double iwXgFEr::FJvEkCTzSFe()
{
    string kRIHZLQ = string("vBErYJETaJoWOmXBZTRzJPOvoVwtgvbRNkeuqGVERrAFwWvedXQEftLvHvvtlQIqMIdCWuxOerwWXUeizmEgsTYyDGzOGNSmwYAmYNXmRtWTKypoqpCstHhhyixKtEQRzznOTgluZvCdzSRnDnjNrZYJOtvtMKmCasddncZFJCnvcPcXNRDqlcHusdVNRpYCvHrYRKfXPSfeJTvrudVLQZdOdOi");

    if (kRIHZLQ <= string("vBErYJETaJoWOmXBZTRzJPOvoVwtgvbRNkeuqGVERrAFwWvedXQEftLvHvvtlQIqMIdCWuxOerwWXUeizmEgsTYyDGzOGNSmwYAmYNXmRtWTKypoqpCstHhhyixKtEQRzznOTgluZvCdzSRnDnjNrZYJOtvtMKmCasddncZFJCnvcPcXNRDqlcHusdVNRpYCvHrYRKfXPSfeJTvrudVLQZdOdOi")) {
        for (int vhINEdCEcvZ = 395407372; vhINEdCEcvZ > 0; vhINEdCEcvZ--) {
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ = kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ = kRIHZLQ;
            kRIHZLQ = kRIHZLQ;
        }
    }

    if (kRIHZLQ >= string("vBErYJETaJoWOmXBZTRzJPOvoVwtgvbRNkeuqGVERrAFwWvedXQEftLvHvvtlQIqMIdCWuxOerwWXUeizmEgsTYyDGzOGNSmwYAmYNXmRtWTKypoqpCstHhhyixKtEQRzznOTgluZvCdzSRnDnjNrZYJOtvtMKmCasddncZFJCnvcPcXNRDqlcHusdVNRpYCvHrYRKfXPSfeJTvrudVLQZdOdOi")) {
        for (int wcAthJTv = 393612793; wcAthJTv > 0; wcAthJTv--) {
            kRIHZLQ = kRIHZLQ;
        }
    }

    if (kRIHZLQ >= string("vBErYJETaJoWOmXBZTRzJPOvoVwtgvbRNkeuqGVERrAFwWvedXQEftLvHvvtlQIqMIdCWuxOerwWXUeizmEgsTYyDGzOGNSmwYAmYNXmRtWTKypoqpCstHhhyixKtEQRzznOTgluZvCdzSRnDnjNrZYJOtvtMKmCasddncZFJCnvcPcXNRDqlcHusdVNRpYCvHrYRKfXPSfeJTvrudVLQZdOdOi")) {
        for (int RGLsj = 1018013515; RGLsj > 0; RGLsj--) {
            kRIHZLQ = kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ = kRIHZLQ;
            kRIHZLQ = kRIHZLQ;
        }
    }

    if (kRIHZLQ < string("vBErYJETaJoWOmXBZTRzJPOvoVwtgvbRNkeuqGVERrAFwWvedXQEftLvHvvtlQIqMIdCWuxOerwWXUeizmEgsTYyDGzOGNSmwYAmYNXmRtWTKypoqpCstHhhyixKtEQRzznOTgluZvCdzSRnDnjNrZYJOtvtMKmCasddncZFJCnvcPcXNRDqlcHusdVNRpYCvHrYRKfXPSfeJTvrudVLQZdOdOi")) {
        for (int OqVEScVUhmS = 629727919; OqVEScVUhmS > 0; OqVEScVUhmS--) {
            kRIHZLQ = kRIHZLQ;
            kRIHZLQ = kRIHZLQ;
            kRIHZLQ += kRIHZLQ;
            kRIHZLQ = kRIHZLQ;
        }
    }

    return -53840.02665978957;
}

double iwXgFEr::uInITwuRm(double LiDfqEuOeAzydFkh, int KIzQBgJqfGa, string jdjNefEhgI, bool JUBMRuIFm)
{
    double EuLYnblYrZUv = -1004786.0339634693;
    bool vyOfA = false;
    int krNZQcKbtqG = -1460808318;
    double yeImsGZZMKFNvNG = -1043041.3144002447;
    string pDUKtpDnHLCQf = string("wpmUpWrkWnzqCoNtLYIDsJfjiaHrEnzIbbqvyxxZiKxchjNQERhmxRgwoUeUdaoOkQpexUaIYkOPHAQUBSFoIpvjuKLQvgIBBsRcGbifOAgtHjJORXeCIKkwXmSwBQycusoCeUnTcEnvfhtDFXGKrVSNDImZIncvZRkSkrkYaPcYjZF");
    double MSAYThCGTGr = -40898.044969495735;
    string YqhZgTkWdf = string("AaoqoYwAlQvdFAgLKaUmAodnUXBAqVMUzytcoJrkSRxJLLzoATlGKwIotnJQjwjfiSHyxHiDrdfpPOhthpBXAnmAVTLQxFPekTIDWHzZJZuFeNThjJASlomoVKAyeyxvNkKjQaNdkh");
    int fAyhQmzdQ = -1508207167;
    bool XJJzPMZwAkttZrL = false;

    for (int YDeTKY = 1030334093; YDeTKY > 0; YDeTKY--) {
        yeImsGZZMKFNvNG /= MSAYThCGTGr;
    }

    for (int pAdzvEsBsAB = 1814229741; pAdzvEsBsAB > 0; pAdzvEsBsAB--) {
        continue;
    }

    return MSAYThCGTGr;
}

int iwXgFEr::xpfpCjc(string MjiqSnMQPMU, int ooODOUzGcy, int qbjbMHLdyvVCrCJX, int SWWSPnKvUvKK, bool EwIVHo)
{
    string WEgzrTOzlJWGL = string("ucOgcmBvxDnIUvOeYOCYJLQCIlAJzVQCCxjkVBxqlQfpwYDsHjNANcqQWgqzhPtBovGWGWOLWKwhaDnestlMaCMMPXwUjZeOXliTjRGiQdCfPWfPzDUtAOJarTBhXPQiVpUBtGbQEXGLBsHWZTqLEZhZPekIUDHoVJcRDcEeDBHGYBtyqglPsDMJLoRrMUHHwTnTvjbH");
    double VSYuOu = 725210.7846096298;
    double WAmHqtrQzQDBjVb = 484925.487238591;
    bool PHtzAlVBTJbP = false;
    string miQOVG = string("JKfXaRPZIgluirQZtrXXzuASVekulgfvSxiEzqeKVkxuFMqqmaKMMcbKvFCoPVwXhXVeeuroPAaysewbIrRpxTfdBSGsUyuctlDxXrmNMOrFXRALecQmvWVkmmJgbcSKPyMFvqJTloEMcyiSHhTSLymCNBrbhVSCWzXRhNGRObGZjhUuXKkTMenGUTJwuWIlzkkJfwGppJwakzpacrBzCXeWFLzRXgY");
    int YZeLH = -90691637;

    if (PHtzAlVBTJbP != false) {
        for (int rKvEEOnInPTYuJDQ = 1894372088; rKvEEOnInPTYuJDQ > 0; rKvEEOnInPTYuJDQ--) {
            SWWSPnKvUvKK -= ooODOUzGcy;
            YZeLH /= SWWSPnKvUvKK;
        }
    }

    for (int aVTzJVgycSgQ = 1094757136; aVTzJVgycSgQ > 0; aVTzJVgycSgQ--) {
        miQOVG = MjiqSnMQPMU;
    }

    for (int hiNKqidLKlPmu = 808876324; hiNKqidLKlPmu > 0; hiNKqidLKlPmu--) {
        continue;
    }

    for (int yFwIccGzAigWFTEV = 361930859; yFwIccGzAigWFTEV > 0; yFwIccGzAigWFTEV--) {
        continue;
    }

    for (int DOQwzxKOgJMshE = 1697329677; DOQwzxKOgJMshE > 0; DOQwzxKOgJMshE--) {
        continue;
    }

    return YZeLH;
}

void iwXgFEr::HfKtZnbcA(double rlXSqYmSVDiXHy, string RtyXplOqQq, int xSUCkZRCVPMc, string YcESQTofQT, int WszYJWqKXMX)
{
    int jllzxmFhkJLx = -2071803237;
    string gNfkCXR = string("rJDEhdslfhATKnonwfHoKbFDeBglvguaWgvrXFKiVKeuUqOOMBXhSjOrMToLNWpZIdjlpzKeTXjOaHisCfFeXaSpjTNbcbWTFvkuZaZ");

    for (int XAawm = 1021605556; XAawm > 0; XAawm--) {
        jllzxmFhkJLx *= WszYJWqKXMX;
        gNfkCXR += RtyXplOqQq;
    }

    for (int XebPjsDNVLvfu = 429237773; XebPjsDNVLvfu > 0; XebPjsDNVLvfu--) {
        continue;
    }
}

int iwXgFEr::tmACZyCzEY(bool qwFimGeOgaensJy, double qSkKhz, int YgdRIGdTnFWSiJq)
{
    bool nJmlEshN = true;
    double vtmCNoqVRmMrT = 875575.0376975556;
    int kmhQVpT = -383613790;

    for (int yqUCrwtgUZECL = 773209781; yqUCrwtgUZECL > 0; yqUCrwtgUZECL--) {
        qSkKhz += qSkKhz;
        YgdRIGdTnFWSiJq *= YgdRIGdTnFWSiJq;
        YgdRIGdTnFWSiJq *= kmhQVpT;
    }

    if (nJmlEshN == true) {
        for (int aCaxxgOVEyUoNj = 854042642; aCaxxgOVEyUoNj > 0; aCaxxgOVEyUoNj--) {
            vtmCNoqVRmMrT += vtmCNoqVRmMrT;
        }
    }

    for (int FInZd = 1141035436; FInZd > 0; FInZd--) {
        kmhQVpT += YgdRIGdTnFWSiJq;
        YgdRIGdTnFWSiJq /= kmhQVpT;
    }

    return kmhQVpT;
}

double iwXgFEr::BCforJVG()
{
    double IeHbADwBcJmsFCT = -913797.9872563634;
    bool mPMyTDUQsNDfWuR = true;
    bool lcgJA = true;
    bool ubuXNSdwqh = true;
    bool TLImuyjkecHohKDb = true;

    return IeHbADwBcJmsFCT;
}

double iwXgFEr::eCvRymf(double TzGokqYDUwLPH, int MKAwsVSZlifo, string MvXeB, string fbATeYIA, int BJfejWbUBDnEqJ)
{
    bool dxaOElJuV = false;
    double FEdtqllFlF = -772910.2402132429;
    double EKkaXLd = 750967.1249337469;

    for (int Mnwac = 570960673; Mnwac > 0; Mnwac--) {
        MKAwsVSZlifo = MKAwsVSZlifo;
        MvXeB += fbATeYIA;
        MKAwsVSZlifo -= BJfejWbUBDnEqJ;
    }

    for (int lfRyFKsyRQHMD = 189798638; lfRyFKsyRQHMD > 0; lfRyFKsyRQHMD--) {
        FEdtqllFlF *= TzGokqYDUwLPH;
        MvXeB = fbATeYIA;
        BJfejWbUBDnEqJ = MKAwsVSZlifo;
        EKkaXLd += EKkaXLd;
        MvXeB = fbATeYIA;
    }

    return EKkaXLd;
}

string iwXgFEr::dTPwMqgsXmEWzkaN(double ipklknDTis)
{
    string HfHnKQIZVEDn = string("TrixqTpZKthFPtXFOjArmhuxLRJudjohZOIUQkfBhQLteVFQhkLzdMetVEbaqrrNaLKSJkjFyafdzjmmwtQzRZpaqoMvcXqNQqWfNrPOliDPRuTdrnmqnXkCEiJYYlrYyqDPXkSHrTaoCmZJtKtblzszdPHqdGPYmlZFEMGvlAtbesgeFVIOTIk");
    string hCJvfolQQSI = string("zPehsLQWBEJBzYhxhEZbLCQGcCnohhkRgRQKTeNwoOJPVfHNzpRsqJFRzmRfTLWtGFCUZrSmJNSzhLVQDdyBkjtmwYIybnQepbwHJrrsQIRrPnxqDctbGTrocWXKjFhUOGGprlgYZSnfhTYcEKyLWClCijPGdqBixenCsZrjUnohVhxWfpJhoHgGoyvRFqIuYibqoYXdCjGhUJkwRzNVMdszlHAdSjlLaHnZOplZtYrMdCWbsMMLPRXGovLm");
    bool CZEuiHIIzeYjwQ = true;
    bool fIvNJDq = true;
    bool BpZzZAkzE = false;
    double vFZPKU = -885374.9799278406;
    bool zCutvdImBvxF = false;
    double qLhXl = -40332.735657938916;
    double LErIWBIPoebUQo = -300923.13533069915;

    if (ipklknDTis == -300923.13533069915) {
        for (int crnlfZfvB = 509934827; crnlfZfvB > 0; crnlfZfvB--) {
            LErIWBIPoebUQo = qLhXl;
        }
    }

    if (zCutvdImBvxF == true) {
        for (int DoFDqUfe = 1183448154; DoFDqUfe > 0; DoFDqUfe--) {
            qLhXl *= vFZPKU;
            ipklknDTis *= ipklknDTis;
        }
    }

    return hCJvfolQQSI;
}

string iwXgFEr::kYazvfdk()
{
    string BcbifLkmyOgjOt = string("SkWILwSlnYPjqrcIKXKTJTuGdTiLmGnmkmoYHKgjukhSkosFsiEYDDFUKSKwAcTyraSjjxljCAHqmVMlBhnxyzgLKCKsmkNAfLfIqvkeGyEuRWkUuEZNNhaliaxbjqvTUhKKmFgNytOIuEZOkmqVykQKXWDLmbYkHDlFLyTFrsMKCvBraStNYTbXhkKf");
    string xellF = string("ZVFwKHTRilRFaIZJawODhlnzHoCkmtIzfjAwfabJNYppXyxhImNEUEwOsqCAHwCnlPKgmocbcOfmKJGYfGtb");
    int GiWiS = 1234119419;

    if (BcbifLkmyOgjOt <= string("SkWILwSlnYPjqrcIKXKTJTuGdTiLmGnmkmoYHKgjukhSkosFsiEYDDFUKSKwAcTyraSjjxljCAHqmVMlBhnxyzgLKCKsmkNAfLfIqvkeGyEuRWkUuEZNNhaliaxbjqvTUhKKmFgNytOIuEZOkmqVykQKXWDLmbYkHDlFLyTFrsMKCvBraStNYTbXhkKf")) {
        for (int wnvol = 532063216; wnvol > 0; wnvol--) {
            xellF += BcbifLkmyOgjOt;
            xellF = BcbifLkmyOgjOt;
        }
    }

    if (GiWiS > 1234119419) {
        for (int dvwgvpMGF = 711949999; dvwgvpMGF > 0; dvwgvpMGF--) {
            BcbifLkmyOgjOt = BcbifLkmyOgjOt;
            BcbifLkmyOgjOt = xellF;
            xellF += xellF;
            xellF = BcbifLkmyOgjOt;
            BcbifLkmyOgjOt = xellF;
        }
    }

    return xellF;
}

int iwXgFEr::CeSIseldFWe(double ZXJYtrsCjcE, string Sfwwrwr)
{
    bool XKANUeloLGIAFl = false;
    int YBAgzrmzS = -708924171;
    int mxVrllhsJenf = -1645705213;
    bool AjmCJbiqobYWMIj = false;
    int NrPpBjPqey = -1707348525;
    string qHqPTWFBXnqKnX = string("KicDErFkBlVWmfRVmAxdTIgjeOAYzkqrjEtJVKwvLfYcxlJbsAjVLLxmZPXmvaNuHQIcw");
    int ugqssW = 695407072;
    double IkYmhrvKBghi = -994444.8557646048;

    for (int OrTnMwBRSdXDu = 276764596; OrTnMwBRSdXDu > 0; OrTnMwBRSdXDu--) {
        IkYmhrvKBghi = IkYmhrvKBghi;
        ugqssW /= YBAgzrmzS;
        IkYmhrvKBghi -= ZXJYtrsCjcE;
    }

    for (int kciQTtlH = 1964006988; kciQTtlH > 0; kciQTtlH--) {
        continue;
    }

    for (int voEXwFEPl = 1523404633; voEXwFEPl > 0; voEXwFEPl--) {
        ugqssW /= YBAgzrmzS;
        YBAgzrmzS /= YBAgzrmzS;
    }

    return ugqssW;
}

string iwXgFEr::RwKhgmJ(double nGkDxCegGYkaqK, bool NKwyKcGaKV, bool UTeVNSXp, double lVUYylQrEcKGYD, string awTSmeep)
{
    double xtETShgwFwhZejYr = -847174.4908746827;
    bool mmHoqubhznwNTOOx = true;

    if (UTeVNSXp == true) {
        for (int XLYftrCpZbrkk = 1578041795; XLYftrCpZbrkk > 0; XLYftrCpZbrkk--) {
            xtETShgwFwhZejYr = nGkDxCegGYkaqK;
            NKwyKcGaKV = NKwyKcGaKV;
            NKwyKcGaKV = UTeVNSXp;
        }
    }

    if (mmHoqubhznwNTOOx == false) {
        for (int edvaZLrbC = 115852771; edvaZLrbC > 0; edvaZLrbC--) {
            nGkDxCegGYkaqK = lVUYylQrEcKGYD;
            NKwyKcGaKV = ! UTeVNSXp;
            lVUYylQrEcKGYD += lVUYylQrEcKGYD;
        }
    }

    if (xtETShgwFwhZejYr != 713627.0854252093) {
        for (int unyMN = 1361863881; unyMN > 0; unyMN--) {
            continue;
        }
    }

    if (UTeVNSXp == true) {
        for (int LCAGjPxyihf = 728498903; LCAGjPxyihf > 0; LCAGjPxyihf--) {
            NKwyKcGaKV = NKwyKcGaKV;
        }
    }

    if (lVUYylQrEcKGYD != 105057.67352043277) {
        for (int YoPKJFmSHy = 1339598705; YoPKJFmSHy > 0; YoPKJFmSHy--) {
            NKwyKcGaKV = ! UTeVNSXp;
        }
    }

    for (int xTdXE = 857176662; xTdXE > 0; xTdXE--) {
        lVUYylQrEcKGYD /= nGkDxCegGYkaqK;
        lVUYylQrEcKGYD = xtETShgwFwhZejYr;
        NKwyKcGaKV = ! mmHoqubhznwNTOOx;
        nGkDxCegGYkaqK *= lVUYylQrEcKGYD;
    }

    return awTSmeep;
}

string iwXgFEr::gqbfx(double YxdLL, bool sMKpp, int vNITNZoQait, double JvKHP)
{
    int MKeqoOfsEWhNbOtP = -1958749278;
    string nTHTX = string("ElaHmQHgmeaMtUdmkrTAouvCJSjIYwcmeHxKsjuLCMtmkgUCXGuwFvcUhlUcRetSLSLZvyWRdDSYwIKOKIynuNnjXKILvQSgmbDCREhWAfxjkFmDeILpLDrPVdSLc");
    int QrdDOoP = -40200363;
    bool DacvpsgLxp = true;
    int sGqow = -562092792;
    string EFmkViORDow = string("eawOjfzVLDOcHXnoyELCrVPupSpaABANqUvBibc");
    string PoqzmgMRrMwJrzMs = string("CmBgFyAFEFPwTgwGPTgvUaHFcZJmvsdNgwRjPvOtQtEAoIDLwDZNWKiqdpliBSxDyeqGOuNwrzMZSWMLmVoMSmLdTBRxrZrjTTxtrHTChPIMVMAYwUjyzLOtbAnnkHtvIQEMHtHjElEymasDSeLrEWssBCNMHNzksyeLATSmKMuGEHHXQCygz");
    double DoIrPG = -951002.0153532897;
    string yddNy = string("sNed");

    for (int YhGUvmAkgvyjZWl = 399956894; YhGUvmAkgvyjZWl > 0; YhGUvmAkgvyjZWl--) {
        yddNy = PoqzmgMRrMwJrzMs;
        MKeqoOfsEWhNbOtP /= sGqow;
    }

    for (int oLXhNHIz = 630789151; oLXhNHIz > 0; oLXhNHIz--) {
        MKeqoOfsEWhNbOtP += QrdDOoP;
    }

    for (int ejHMOmTPpwI = 1099956215; ejHMOmTPpwI > 0; ejHMOmTPpwI--) {
        continue;
    }

    for (int FbHQazsYsvJ = 1287678574; FbHQazsYsvJ > 0; FbHQazsYsvJ--) {
        continue;
    }

    return yddNy;
}

string iwXgFEr::TwppMMSOjhNZ(bool iYAdKuo, string UUwPvouWx, double hWqqA)
{
    string cpDxCZqZBSkPJhno = string("sqfOoTmWzyWMekfUaFAQRroNRMunCrMuSZjScbBwtehSIPAotdWIgdNjzrdmCrxPpwbhKsutswyPOLxLLpfxnnjoCbaSBJLbqnJafCLkBxGmwXGQQdBdqCIQxOYhwHBQauuHfpIjuazBKlPmlHahaqkvKKhJmhcquTwvUhoCfbjPNwXlvPNqYOMsgMtFGQCpyhrbRTjTLmDTfikYovWjQbqvCHErKtBDMqicIETzLZNHKeUpduyzRNvpdBfZuD");
    int wWKLYlqhGZfiSi = 2025566158;
    int mSbyrEfRmN = 1976581078;
    bool plecHZZyVnXLWq = true;

    for (int TdcysLsSyhF = 566616552; TdcysLsSyhF > 0; TdcysLsSyhF--) {
        mSbyrEfRmN += mSbyrEfRmN;
    }

    return cpDxCZqZBSkPJhno;
}

iwXgFEr::iwXgFEr()
{
    this->DlPDFYFfYi(string("cjBWuMTLJQcmhWsfeezFiIxaZXPNAOuvRfmkcDHjKtygXKPxPEYpdsvzZxgoFoZQkTcLAZdnJmicXHAAmFGprkSEiVIqPPMQiuqQyIErYZjJnBtDcnoIYlUHQFzALYNSZkTHuygfX"), -500589620, string("JHyBsPLdhFXPsPcrGZfMJngtiLpCzwMauLQwpaVWulzGHTmwboPSlvPovjLQeaGmVruIorHCarNVdVtxszokgokPCOwQYZLNMfIoZoOAOKgOqAvyzPbWEBqJjBBonjd"), false, true);
    this->tvTpPOviRvDyoyW(918741.6138484714, 850509.1831141801);
    this->mnpBwsWOOB(string("IQuUtAEpnSDoHZRMZIZCDAzOlsqZqxseKQBmqHFBilalDmbzVhKkuDUsnBpFismBBEGAQTWuxnuStDUrtnBxGCumcAhgYhNGoLTMKyyETDyfGnSOHtBUutYtGgIIBAiJHtfkPEuRTfCDGHKsKQbKcEttcFcvghqtkJwEfnrdyLGiCzxDfKCIsgCVqhCmmuozJGVibPgLsbfxgNwAPzzFCNtnyvpyUuefHnPoqldusGScrHLSBznxytsWUY"));
    this->nPWeQwredCd(true, 269524412, true, false, string("iEvrkijMFMvzBrAxUYD"));
    this->EaDieufZQTZOoBY(string("OOuEdVLJsijInnNEVAGbwcPOgFeIodZjLujZeJyOafbAMfqovfsEhlvULpPtXBShrIVOdHWGQsS"), -804216.8383082892);
    this->UvElPU(string("CsJIgfPOgFqXKaaNpfEgIjujONjznDufVGBqJwpbPnNSlXhsKLSVwmjppKXmkovDnpkFyTdTwVsRWqqtOqyThjcDLkzfHWjfjeAScAYdQKYNTbBtODuiOMCfJBdefTNkQTOxhJmDIEtqpwaJRwzgbYgEedBniILkRjndqZvVBgKQoHXjwFoAfrrPolUSEzYQmGzUbCshMOMGvWRDjcElaSatrumqOYkxrjgzKXl"), 550156.2435444925);
    this->SDbzvlSJyXH(-864667211, -639244208, false, -828716.8825461096);
    this->FJvEkCTzSFe();
    this->uInITwuRm(496812.61054947664, 537725279, string("acJnzNhWXPmPMDobnDyqBIqUuQYYLPKoomvjAmWqqUeEFVATwmwADcGNJGiyIfdqjopKBEOzjWjYambGVhNrINzCisTjNKZzZsVOXhWmcNKSXBXUbeTlHgIDRNALRdVTnzCVVzhoyIRXiEaiolu"), false);
    this->xpfpCjc(string("axvzKeJLNULYLizguSPKKnNkqlRiCQxxpuRHHDxCQaJRFSWQjwPcvtjxtGbLPIjZUjnCJbOjchHSrxPQedbGOlVjHoQjMyYTwbOqWxTYexrpNxfyKAvhOqrdskfJJkWMqDOcbVyQDwxDMOLQqKisZbGvXOvI"), -1748568477, -1493701327, -602901616, false);
    this->HfKtZnbcA(312636.47847868316, string("XMizZWIPNpMWoPQtmpxutZAUUdYJZLeivgaLSGQWjJWQUjpLQoVCMuCxGKSuzZIrMdwKAf"), 133994188, string("aBrTrPdyRszgHynflgIOOybewnPprNwkYXMHtVtOegTjQAroGGzwrdmfpTtWhdopLgCAqpIxzGscKGnMKOQMrsuzsHCGNcnkrZtztjTFMKrcxqyGSlufkxHBvoHMXMxCukZdacLvDDRflXMJTWGzGWCVbQhkiJFUtNxMHoIjdIYLvUNGvMQswuNlYdGhaClUqIYPcMfcKhLvZJBfcmWIXkkjbltJqhrtwDfFWuyPpnLWHMQkDg"), 2118348762);
    this->tmACZyCzEY(true, 691420.466525147, -90387587);
    this->BCforJVG();
    this->eCvRymf(267960.5829492135, -100972025, string("JzccWylBAUwtDjYwlEVnYCuFxLKTzAaunMMSdhAwEnGAXKkRmlOHxtCliGmFwCMDEDJFW"), string("qOqJZFihTLzRmTYDOpuUBYjKHCNWWkQRaRnJkUwAGUeeMVpMSvxwxPqkztQwyxBgoHXBUVmPMKrxrYGXlIETzDVwkYBoRfTYKjvobeVxmPlITexPqZxUIaeZWPnYLBizXTMLTzlZSOsHCxltDoRawniuYiwnWmgoqfuhBJbhKamrweQfJypEsCeBwTyUNZKflrxEWcoErJySsFerkPzatVGbsEZjacSWorh"), 1570561150);
    this->dTPwMqgsXmEWzkaN(-568561.1498206954);
    this->kYazvfdk();
    this->CeSIseldFWe(-337632.0976411509, string("ptZUiKAzkRvsRTinVExNDiiwwRIymxNlIzAevZgEPXfBKWfqtBbUtAPMRZcTYcykSwMUwfqnBJqPJkeGHNmogsHMlIyIBqKTQMJPrCUJHHIfCCzpvpDbURQcHTJQaarGHG"));
    this->RwKhgmJ(105057.67352043277, true, false, 713627.0854252093, string("MHpsIivZIbKQBLFCpJvRkwiUvILgoiqmCPekDNOwhUJGuBYzqSPC"));
    this->gqbfx(789087.7009193437, false, -1207320992, -409977.18920264055);
    this->TwppMMSOjhNZ(true, string("sUpeXlPpPuBcBkDEdqpRGwPxgDzMktUD"), -919537.1897605023);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NziyjC
{
public:
    double SiwideCejgP;
    string ZxHgcKDJWqBpEJx;
    string hMTvvakfDqL;
    int lBTsEk;
    string nXDdRrpTzItJOmb;
    double dxncbWxFxE;

    NziyjC();
    double jgHZxxxZo();
    int khTxzuQMSlXk(bool haUaQqg, int rIORLRorNZkuTxo);
    bool YrpauDCRCrr(double PkLNlgQwxVqnRRQx, double KbOsyDZHKHuJTzlG, string VTbafzxKIwD);
    double tPvqRJM(int pxZnSfjooHlLEBRM, double xCyVbRNPXAoViH);
    bool XIYkNtmcNCYcPSFo();
protected:
    double cfCxvgDDcWkunbEF;

    double yiiabpyDZgbWK(double xMhtrfA);
    int CBdlWUlTCTFpIeav(bool BpkzUBbUmustP, bool vpWFaSUQH, int tlgXbdPWceXvIBbv, bool QkanHtXfslxyFazP);
private:
    bool HQgJraeOAzh;
    bool vPgzUP;

    int fprmOanRNKppiWo(int hUmdcDKj);
    string OKTPYu(double FDoqgLeTyQn);
    int iKTOnmoNBUPMZDP();
    string nWJvtUL(string TZMKKcJUPEc, int ARfgwK);
    void LqRYr(string blQxdRvDgENqjs, string KmHHWmPuMJbfl, bool mMAEWLxuXyfmQAB, string yIWXqxsP);
};

double NziyjC::jgHZxxxZo()
{
    bool yHIij = true;
    int GGLnqRtelfFgREA = 2032341844;
    double ZtRjCNwDxpWdeHXc = 547744.034145407;
    int PvAxu = 1701766445;
    double ZoNSzotLdcitS = 412254.4684879572;
    int sjErrnITCSkAUN = -41019383;
    bool VktpeYtLaGky = true;
    double kRIPsRe = -834236.7133975958;

    if (PvAxu == -41019383) {
        for (int UwlZznf = 206172287; UwlZznf > 0; UwlZznf--) {
            continue;
        }
    }

    for (int IzWhzeblbx = 1607631398; IzWhzeblbx > 0; IzWhzeblbx--) {
        VktpeYtLaGky = ! yHIij;
        kRIPsRe -= kRIPsRe;
    }

    for (int hHYmrleNmLih = 1993533690; hHYmrleNmLih > 0; hHYmrleNmLih--) {
        ZoNSzotLdcitS *= kRIPsRe;
        PvAxu = sjErrnITCSkAUN;
        kRIPsRe *= ZoNSzotLdcitS;
    }

    for (int TQOSUsWPQaBq = 612398731; TQOSUsWPQaBq > 0; TQOSUsWPQaBq--) {
        yHIij = ! VktpeYtLaGky;
        PvAxu *= GGLnqRtelfFgREA;
    }

    for (int IItNPltSak = 1449048256; IItNPltSak > 0; IItNPltSak--) {
        ZoNSzotLdcitS -= ZoNSzotLdcitS;
    }

    return kRIPsRe;
}

int NziyjC::khTxzuQMSlXk(bool haUaQqg, int rIORLRorNZkuTxo)
{
    double IDuUHjkWWvMuebQm = -889486.3370814451;
    int mCgYODKb = 414881246;
    string PuelgkzvouMT = string("pmnlhwEzEzgIQHIkPQqGVTSjPKwFhVDs");
    bool HbGUvfFHgLz = false;
    double jiUIkwdsCsYMmHh = -496013.3270155271;
    double prcNqZ = -707478.6277190238;
    int JCSflRXH = -763600293;
    int dpFxbGnDWlFWmty = 310705041;
    string IZCOoEmzRcKn = string("RcJojbEUQeNLlKeKEAZbfPpGleWmflxTHGfFBATLffcbTpoXvueQscvxPBPpPhEiGyPRPZrEmKydSpagfcBaxkwDXxsmGMfIXLAwJfhYYEodwJsxzQRLzdreNAKHZFJgMmnZcznlYeRUEbKYfQDgtNywkcrnLfdqHClAIVqeAgIhjIMYDDyWGLbpMjUwXRNyJQsgqei");

    if (rIORLRorNZkuTxo <= 242006039) {
        for (int aRcirMAECjpFl = 1176127077; aRcirMAECjpFl > 0; aRcirMAECjpFl--) {
            mCgYODKb = JCSflRXH;
            dpFxbGnDWlFWmty *= rIORLRorNZkuTxo;
            rIORLRorNZkuTxo = rIORLRorNZkuTxo;
        }
    }

    return dpFxbGnDWlFWmty;
}

bool NziyjC::YrpauDCRCrr(double PkLNlgQwxVqnRRQx, double KbOsyDZHKHuJTzlG, string VTbafzxKIwD)
{
    bool SzUIejlKUa = true;
    int nvmrqtf = -345984783;
    int MbQoecdTyvJUK = -589358261;
    double EsbsLXvdlEPkHg = 1011563.2247318164;
    bool BoVPoYUrit = true;
    bool nfKsWWfXMdXmau = true;
    double YJYYWvdLeORs = -266797.83287387365;

    return nfKsWWfXMdXmau;
}

double NziyjC::tPvqRJM(int pxZnSfjooHlLEBRM, double xCyVbRNPXAoViH)
{
    double EFDUupSMmdpAPhM = -10360.086810820578;
    double xmyBZsajHxrcjP = 972869.9988737212;
    double GENhvJbfTk = 478647.8437512072;
    double GHxXINVz = 1004920.1317565492;

    for (int kdWazxHmFywSVOE = 235547817; kdWazxHmFywSVOE > 0; kdWazxHmFywSVOE--) {
        GENhvJbfTk += GHxXINVz;
        GENhvJbfTk -= xmyBZsajHxrcjP;
    }

    for (int vJLoUvmZzxOkL = 1311753579; vJLoUvmZzxOkL > 0; vJLoUvmZzxOkL--) {
        EFDUupSMmdpAPhM *= GENhvJbfTk;
    }

    for (int POJfCQO = 350954032; POJfCQO > 0; POJfCQO--) {
        xCyVbRNPXAoViH -= GENhvJbfTk;
        GENhvJbfTk = GHxXINVz;
    }

    if (GENhvJbfTk != 478647.8437512072) {
        for (int SkoYGvcB = 951436364; SkoYGvcB > 0; SkoYGvcB--) {
            GHxXINVz += GENhvJbfTk;
            xmyBZsajHxrcjP *= xCyVbRNPXAoViH;
            GHxXINVz /= xmyBZsajHxrcjP;
            xmyBZsajHxrcjP /= EFDUupSMmdpAPhM;
        }
    }

    if (GHxXINVz <= 1004920.1317565492) {
        for (int rAkFH = 1540214754; rAkFH > 0; rAkFH--) {
            EFDUupSMmdpAPhM -= xCyVbRNPXAoViH;
            xCyVbRNPXAoViH = xmyBZsajHxrcjP;
            GENhvJbfTk /= xCyVbRNPXAoViH;
            EFDUupSMmdpAPhM /= GHxXINVz;
            GENhvJbfTk -= GENhvJbfTk;
            xCyVbRNPXAoViH *= EFDUupSMmdpAPhM;
            GENhvJbfTk += GENhvJbfTk;
            xCyVbRNPXAoViH *= GHxXINVz;
            EFDUupSMmdpAPhM = xCyVbRNPXAoViH;
        }
    }

    return GHxXINVz;
}

bool NziyjC::XIYkNtmcNCYcPSFo()
{
    double xxDGEWsBTLpWHm = -768503.81118037;
    string eYtEpeBAbiKz = string("DxXfXlirzMqQsejRRxlRkRJPBFhegtqquWQjYQQyGRNszxfJKmEzUiVTOyPSoynzyAKqWUzuGlFKNRFPRrnEjRiwxHNYzRCwIQwXiXzhITcDvQDAXeTqLhMxwHJJKKZeikkdvXsAqqUFYmmZsylTJPmfBJDauhBfhPosFTZydsnpUEqMcBSIKwOIxJnAnyFUUQMtINgxBUqfPUUPHOnHXPodRDLhFjcInobrtZVYjmbfIaoJfOAVQATU");
    int RlbyKcAdur = -857655033;

    return false;
}

double NziyjC::yiiabpyDZgbWK(double xMhtrfA)
{
    bool JjaXqdQrnrxLnTO = true;

    for (int CEgvFTxTbuFjT = 545924461; CEgvFTxTbuFjT > 0; CEgvFTxTbuFjT--) {
        JjaXqdQrnrxLnTO = ! JjaXqdQrnrxLnTO;
        JjaXqdQrnrxLnTO = JjaXqdQrnrxLnTO;
    }

    for (int tqoojorOhbbNn = 972412826; tqoojorOhbbNn > 0; tqoojorOhbbNn--) {
        JjaXqdQrnrxLnTO = ! JjaXqdQrnrxLnTO;
        JjaXqdQrnrxLnTO = ! JjaXqdQrnrxLnTO;
        JjaXqdQrnrxLnTO = JjaXqdQrnrxLnTO;
        JjaXqdQrnrxLnTO = JjaXqdQrnrxLnTO;
    }

    for (int zgagDbMmkiKIrFj = 603366879; zgagDbMmkiKIrFj > 0; zgagDbMmkiKIrFj--) {
        JjaXqdQrnrxLnTO = JjaXqdQrnrxLnTO;
        JjaXqdQrnrxLnTO = ! JjaXqdQrnrxLnTO;
    }

    return xMhtrfA;
}

int NziyjC::CBdlWUlTCTFpIeav(bool BpkzUBbUmustP, bool vpWFaSUQH, int tlgXbdPWceXvIBbv, bool QkanHtXfslxyFazP)
{
    string VsBljrgNzZJ = string("oxEGMilkPBpveZnWgUtGulvAQkJsEVUNJSKuhbpucfnkrtaUgGPlMXshobmSnmaeNaIgsGYuoxrDopqHiWUyHhjlhdDgGJROimdQLqcvufUhizKTCmFIFOtpbikGTvIIlQKMDhkkuemFmqLYJsSGNwzwtXJRBXM");
    bool KFFZjJftci = true;
    string esLSDqnpB = string("UdgKJpNZvtjrQbDAXSVJQEubKgVBfYDOaZngmAODeXOZlLnDCqHgHDuiqfHpwFDQrcGFwAX");
    double dQaMyicEckaxS = 165870.60930796128;
    int OnfoHCmLsuz = -277523413;
    string HjBwocNY = string("eZosGosbVoIDwBeXcQKaNwPWtBLLrHZbMTVXGjlySoAZrhzlzdfNPkyIBxRyIshVxQDgmxMeYzjsysdxBvkhFkVCRUDwRcffyEXvXEtkGypQHciKllPZrOsPnlkVjEUkdTPnLnRS");
    bool xsfOHJtdiC = false;

    for (int cdiyUesTLw = 978129007; cdiyUesTLw > 0; cdiyUesTLw--) {
        vpWFaSUQH = ! vpWFaSUQH;
    }

    for (int bPoKD = 191136905; bPoKD > 0; bPoKD--) {
        continue;
    }

    if (esLSDqnpB >= string("oxEGMilkPBpveZnWgUtGulvAQkJsEVUNJSKuhbpucfnkrtaUgGPlMXshobmSnmaeNaIgsGYuoxrDopqHiWUyHhjlhdDgGJROimdQLqcvufUhizKTCmFIFOtpbikGTvIIlQKMDhkkuemFmqLYJsSGNwzwtXJRBXM")) {
        for (int OZHdpUaDoYde = 513931605; OZHdpUaDoYde > 0; OZHdpUaDoYde--) {
            continue;
        }
    }

    return OnfoHCmLsuz;
}

int NziyjC::fprmOanRNKppiWo(int hUmdcDKj)
{
    bool mZpZQPg = false;
    string MZhYhJOpjxSgiUk = string("gBbrHwRaPxAhettkppniigWBMgIimYISCdrUQqenGWYiaiWibcBAQYMEJmhPmtZjoeGnhtUAEZRJKkxQTRuyUZjniHNWYsCMcVOnAiKpJsOGefzzqqkdZvigBpodYFwOSLdGeTXeyIpZOxJyz");
    bool YSgZjy = false;
    string XkpnUNRhNjuty = string("XqfhcJPvSHTYilOarrbgMOMqVBeyKJkKCLaczslnQhphMVgQyvXQVtavEJqnKZbFrgiwiRjKFRXAplEfPlBwzdbxUGZtFYWwjMDvNOmcOAozDaVobJpEHlkNvzCHgunLpeiKOyDsggazIvcluzhPuHdlThWKj");
    double LhkkadzTECnSS = 921858.758805331;
    int HBPZcnIhrEAV = 305579227;
    bool tXjJqdyCUqnJFxC = true;
    int awfzGdSwl = -699995526;
    int sdoVb = -1870796127;
    string NtFnspAiuyLH = string("JFiPGLDbqjBDULJQCspkWffxRUxQdiVgUuOTNqUNJfToBkOMnUsjYNPGtbpcBDjFAzvaToWwzfYnUtZojxSItlXEJFtwnJBbWsPivREiijNPYItuqgMCHBjVXPS");

    for (int IkEZY = 987343015; IkEZY > 0; IkEZY--) {
        HBPZcnIhrEAV /= awfzGdSwl;
        hUmdcDKj /= sdoVb;
    }

    for (int fUrzmjao = 137560501; fUrzmjao > 0; fUrzmjao--) {
        YSgZjy = YSgZjy;
        tXjJqdyCUqnJFxC = ! YSgZjy;
    }

    for (int hVxNKyOXpRvDu = 2041079887; hVxNKyOXpRvDu > 0; hVxNKyOXpRvDu--) {
        MZhYhJOpjxSgiUk += MZhYhJOpjxSgiUk;
        awfzGdSwl += sdoVb;
        MZhYhJOpjxSgiUk = XkpnUNRhNjuty;
        HBPZcnIhrEAV *= hUmdcDKj;
    }

    for (int jBKFLyrYEKHN = 321666215; jBKFLyrYEKHN > 0; jBKFLyrYEKHN--) {
        awfzGdSwl = awfzGdSwl;
        YSgZjy = ! YSgZjy;
        mZpZQPg = mZpZQPg;
    }

    for (int EWwrPgb = 1851865090; EWwrPgb > 0; EWwrPgb--) {
        mZpZQPg = ! YSgZjy;
        XkpnUNRhNjuty += XkpnUNRhNjuty;
        HBPZcnIhrEAV /= awfzGdSwl;
    }

    return sdoVb;
}

string NziyjC::OKTPYu(double FDoqgLeTyQn)
{
    double rpCfEToHPEA = -921473.7865706848;

    if (FDoqgLeTyQn <= 753238.3619965337) {
        for (int lptDSXDUMaU = 731237959; lptDSXDUMaU > 0; lptDSXDUMaU--) {
            FDoqgLeTyQn = FDoqgLeTyQn;
            rpCfEToHPEA *= FDoqgLeTyQn;
            rpCfEToHPEA /= rpCfEToHPEA;
            FDoqgLeTyQn *= FDoqgLeTyQn;
            rpCfEToHPEA += rpCfEToHPEA;
            FDoqgLeTyQn /= rpCfEToHPEA;
            rpCfEToHPEA -= FDoqgLeTyQn;
        }
    }

    if (FDoqgLeTyQn == -921473.7865706848) {
        for (int rLJhJ = 1148042400; rLJhJ > 0; rLJhJ--) {
            rpCfEToHPEA *= FDoqgLeTyQn;
            rpCfEToHPEA -= rpCfEToHPEA;
            rpCfEToHPEA -= FDoqgLeTyQn;
            FDoqgLeTyQn /= FDoqgLeTyQn;
            FDoqgLeTyQn += FDoqgLeTyQn;
            rpCfEToHPEA /= FDoqgLeTyQn;
            rpCfEToHPEA = rpCfEToHPEA;
            rpCfEToHPEA = rpCfEToHPEA;
            rpCfEToHPEA = FDoqgLeTyQn;
        }
    }

    if (FDoqgLeTyQn < -921473.7865706848) {
        for (int EOmDWVrAkKIU = 1636213821; EOmDWVrAkKIU > 0; EOmDWVrAkKIU--) {
            rpCfEToHPEA = FDoqgLeTyQn;
            rpCfEToHPEA -= rpCfEToHPEA;
            FDoqgLeTyQn += FDoqgLeTyQn;
            rpCfEToHPEA -= FDoqgLeTyQn;
            rpCfEToHPEA -= FDoqgLeTyQn;
            FDoqgLeTyQn *= rpCfEToHPEA;
            FDoqgLeTyQn /= FDoqgLeTyQn;
            FDoqgLeTyQn += rpCfEToHPEA;
        }
    }

    if (rpCfEToHPEA > -921473.7865706848) {
        for (int OznDkaH = 1773233439; OznDkaH > 0; OznDkaH--) {
            rpCfEToHPEA *= FDoqgLeTyQn;
            rpCfEToHPEA = FDoqgLeTyQn;
        }
    }

    return string("NzwnvbMPPlsKhVrBDJTrKOHzndesfvmNmylMkNmJLlgVxlgppbYDNjNBPbZTDWcsfIlIldGWZiZNInxvuEEHXMwnLdWpqVAVYVWQvoVUKFTiuxDrsZjc");
}

int NziyjC::iKTOnmoNBUPMZDP()
{
    int hbdpKVYXFmDiuzrK = 1399889832;
    int sxGeDEC = -1932043101;
    string yMKIvYeIHGILV = string("t");
    string EMyBU = string("otukcvwzBTDQbIBFSpcIhdQmYgtUmWpfqwdmZFUMYAcXYeddFcZUEvAzwfsaHytjnVqMjZQlsbZMmtivcsFsUsVQXUAOUjAFCfMEdFAjVuTaKycCXswytrkxWmptCqjJaNFGbEfUUFAFAmnkZlWwbKcwJSTmUFCZpQTooYPdywnkffUEMLaYBA");
    double nBZvelxLRCAsgpK = -991119.4646348754;
    bool imVUZBLc = false;
    bool CyNku = false;
    bool iSorfEBqule = true;
    bool tESFFcZkrMnvLD = false;
    string zecSmNLdVIACsqyQ = string("pkNNyhhoothpiwDLpOlxpvLREGmSSRtkyreRxGfjywoptWDyBeKoUHaQDANqolNPcFFswNPXCkFRvexQqsnglYIpZnYWfaLtyMoAyJicOekehLBuMAVbbUqSNffQNNgLPipfhkaZFGrFpm");

    return sxGeDEC;
}

string NziyjC::nWJvtUL(string TZMKKcJUPEc, int ARfgwK)
{
    string ZFzAvZ = string("HZWlTSuugesqIgc");
    string GXDDXjfvszCzxYI = string("aOJUUAdWMAqghhVPUKtyQAjJdwDlWEkoJJVTcAiAtpOlAfhJAStrwGcrmIJMvaj");
    string VJLSXxVFbt = string("HXvnQoVnPSQaJrvAemDCRgHboNwacNlipScbltCKpnZqSAQXedthfRYjrriNAELmrV");
    double yxVxYiSPb = -908798.7697677892;
    string DBQmCISsoduMe = string("OITRIMcJiluStGxhpUIfpgyFXDmDTGYhckWbFuzLhFEUyjioCeqBMsqmqWcWJYjbaHOSbtztgwmEFvMgPcUdOUHDZUkHRMgybUtguYiYjJLYtjoqUwCiKZMzicyfZVQKwWVBzANuomxpRMnKBFNbcPXskrLRnuAtmgaflHveYsmMXzQXmyiIKVpgKCaDoSboUfEEbVSLknXpNaZKBnsXtvxOHsNqRGvN");
    bool eYttTwGyIZtxGcyv = true;
    double LlDxeqnqpFKmkRF = -232884.28713263376;
    string SxulVwFQHmzNHQ = string("WtoHaTvgCSydtMiGsyXYlAHXuzBzmgLRBlABSjkVDOPqmMP");

    for (int KBYSWsduyLKebs = 316190569; KBYSWsduyLKebs > 0; KBYSWsduyLKebs--) {
        ZFzAvZ = GXDDXjfvszCzxYI;
        GXDDXjfvszCzxYI += VJLSXxVFbt;
        ZFzAvZ += TZMKKcJUPEc;
    }

    return SxulVwFQHmzNHQ;
}

void NziyjC::LqRYr(string blQxdRvDgENqjs, string KmHHWmPuMJbfl, bool mMAEWLxuXyfmQAB, string yIWXqxsP)
{
    int DeEMvhumfR = -609090120;
    double XiduHUzOF = -886952.1780418967;
    int ndnzfLjDf = -911616279;
    bool OosXdNSFI = false;

    for (int dhFquH = 324106679; dhFquH > 0; dhFquH--) {
        ndnzfLjDf = DeEMvhumfR;
    }

    for (int YUFAy = 1119447050; YUFAy > 0; YUFAy--) {
        DeEMvhumfR -= ndnzfLjDf;
        blQxdRvDgENqjs += blQxdRvDgENqjs;
        KmHHWmPuMJbfl = KmHHWmPuMJbfl;
    }

    for (int GQLRGiyuaWQnB = 123735306; GQLRGiyuaWQnB > 0; GQLRGiyuaWQnB--) {
        yIWXqxsP = yIWXqxsP;
    }

    if (blQxdRvDgENqjs >= string("czHrBvlPRMpISgabSpvWTBmNLYYsTGrhkEdtrdtoEuFPdgfbAbSmqXeWyUQtajLjUtNSHuyKlsxIRkGeuGjqcUvSxKCXNUiZtbviTyPHPCUOhyPxHAPaRdVqaXlxNESoqgaicTSVNQz")) {
        for (int jbqPJbsyVTZeeg = 236207507; jbqPJbsyVTZeeg > 0; jbqPJbsyVTZeeg--) {
            DeEMvhumfR = DeEMvhumfR;
            mMAEWLxuXyfmQAB = mMAEWLxuXyfmQAB;
        }
    }
}

NziyjC::NziyjC()
{
    this->jgHZxxxZo();
    this->khTxzuQMSlXk(true, 242006039);
    this->YrpauDCRCrr(470062.0776302818, 1039165.6627425369, string("hCRmeyfuAvezCRFCNSLnYkfGZOvxOOkzWlYQtraIVfvsmPQOxkRJPENbekDttECLRaIOyZPmFnKLbCxedenxjLXGqkWFCCoyEygGnqjGDwucgYEpFYCe"));
    this->tPvqRJM(702286191, 803878.513931918);
    this->XIYkNtmcNCYcPSFo();
    this->yiiabpyDZgbWK(-164786.874583745);
    this->CBdlWUlTCTFpIeav(true, false, -1989275884, false);
    this->fprmOanRNKppiWo(1051030162);
    this->OKTPYu(753238.3619965337);
    this->iKTOnmoNBUPMZDP();
    this->nWJvtUL(string("tyrOTXyqT"), -378844250);
    this->LqRYr(string("czHrBvlPRMpISgabSpvWTBmNLYYsTGrhkEdtrdtoEuFPdgfbAbSmqXeWyUQtajLjUtNSHuyKlsxIRkGeuGjqcUvSxKCXNUiZtbviTyPHPCUOhyPxHAPaRdVqaXlxNESoqgaicTSVNQz"), string("tIlqUmRtoNNiKqmxxIrJGyWIMFFiuriDPztNffgcLDTsQptRrpollpQTudtUApsPvxUlszRfEQvuHdNNaKCHIhWLoRtFESqwHtYHiNFmQzsDZQqvprTRCNaflgWRhguWxKMpbdoYpObMSUoyIImiovVmMcbpPbnDYQgNpZNdLVgRMXbHWyLOVjCRZAxBmWFgEZnoILGKGHhJtASBwxLIzMgSmwmpluMVIdAtnKKTLgMYqNGhbcWezUw"), true, string("SAHHVhfuMFUbyRBVkPuroOdLcBkijHjiEjJJnfUPYuSSmmzXiwVIZNnpLKgQLSaHawFzxWargPbXflHzALOwwjmfglKWzKwZPvaUXCiWUaLYiSTgrKiYeHnBQaJaHGwVUHhxNNhNShGtYFQOgqhouqKScipjgmafKhmSwkGNJyGwGAJAXnZAS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sibBM
{
public:
    int pDpRuKvZKkwtc;
    bool SRLsmeJ;
    string MxxNjBPKu;

    sibBM();
    string exEzLJpeBH(double qoduYcGk, bool ugGkbfpeSzeKnF);
    double ubeqj(bool RaiEGajyBl, int aBMTsh, int zkiEhjIQgpFoum, double BMTbPIQUxcNeixd, bool jvYMjQKg);
    void jbuxspPeq();
    double oLPLlQs(bool oHKeP, int zqeUqhREAJKOvzd);
    void JeCszbNpEGd(double dVQwF, bool Gjovqr, double hbhXRMj, double fnZkQt, string aEnkpTLHCWRLtdJ);
    bool UfuaNYgajdnLRU(bool dVIXknr, bool DTDAW);
    double vKDSmAdfpPPbMRa(int YnMXi, string PVTwqKhkFmbsEKJp, double GfdTmigFPaKHxG, int eKqtXIdMCRnU);
protected:
    int IwjROoFmpsMtXLNZ;

    string ksrtjSZgNxN(int yKVqVU, int kiUcj, bool wImHqSWvZtvJRw);
    int ptOeDT(int BruORbKjZOertUK, double NQQhfIdv, string rNMIPC);
    double UsHmlxRAaZQ(string PRrYi, int EvUnBBCxtwRgmR, string RkVWsu, int pEDdPfrHUuVNE, bool raYjSoELVCivlGF);
    void YkEWlXkQaAF(bool EALfpJAAQVuK, string lEOFQc, int LsCmD);
    void cATIHicC(double UWYeIg, double xYkGtdqf, string yiKVdodhwtctN, double roweMrrn, string ndIvAHiayvJ);
    void fhRHXvHxEzWcQ(int voZou, bool wKsiQaZRvXun, string bXLgpkEEUI);
    int oGLCtKVm(int pUvZrloUlx, bool OQQKtf, double WmlhtZy);
private:
    int zbotEZdnyaEZT;

    int EkBtrljyjOGbPFv();
    string NKFaasdps(string gDYZYgljQVstHc);
    bool qoYPkluCSsVvFlF(double MjDLcHOocITKZOT);
    string VZzonddRZwl(bool NutaEfeJtZxYjDaJ);
    double RCoxP(bool NDoOzwWdJAsky, string GumGVXpa, double doXQt);
};

string sibBM::exEzLJpeBH(double qoduYcGk, bool ugGkbfpeSzeKnF)
{
    string HoZGtyLDQ = string("AQTpStxRAmfLLUfMGtewFacWTczsHOCdiAspEqKZDQvQuEeUQxEYlaotoFOKNBVHmXQkhBjtCpZRPeEuSYyonFzFXKQyTCuMDSCfppnKRfMynaErVVLekoFzkz");
    bool EztzxbxLTTExCsN = false;
    double YOWlCoLmFkQrA = 992164.4883405662;
    bool taNDpPUG = false;

    for (int ZtJLOLIPUB = 1167059876; ZtJLOLIPUB > 0; ZtJLOLIPUB--) {
        continue;
    }

    return HoZGtyLDQ;
}

double sibBM::ubeqj(bool RaiEGajyBl, int aBMTsh, int zkiEhjIQgpFoum, double BMTbPIQUxcNeixd, bool jvYMjQKg)
{
    int XTwIGsSih = -1511930400;
    bool MXnVHCTzhJAPd = false;
    bool nHRoaVuHXTJy = true;

    for (int DyTHp = 1597478427; DyTHp > 0; DyTHp--) {
        zkiEhjIQgpFoum /= aBMTsh;
        nHRoaVuHXTJy = MXnVHCTzhJAPd;
    }

    for (int AdTTaEmRTKomvEsq = 1763518473; AdTTaEmRTKomvEsq > 0; AdTTaEmRTKomvEsq--) {
        jvYMjQKg = RaiEGajyBl;
    }

    for (int LMYjXc = 238640245; LMYjXc > 0; LMYjXc--) {
        jvYMjQKg = ! RaiEGajyBl;
        jvYMjQKg = ! jvYMjQKg;
    }

    for (int Cefyady = 460576825; Cefyady > 0; Cefyady--) {
        nHRoaVuHXTJy = ! nHRoaVuHXTJy;
    }

    for (int uVFTpCfKx = 1915864756; uVFTpCfKx > 0; uVFTpCfKx--) {
        jvYMjQKg = nHRoaVuHXTJy;
        RaiEGajyBl = RaiEGajyBl;
    }

    return BMTbPIQUxcNeixd;
}

void sibBM::jbuxspPeq()
{
    bool sjWTggwcpH = false;
    double PHrWnYqVMP = 363489.50554659724;
    string AQUNTJYESISyWb = string("QofwFfDLGUUqnZauCDPpjBJSwEOPnRDYVpbuWgeVNwejypOivpGwPJijIbjePjArxpffHpbsbsgvLnuAgHQYBLsdsXarSwqhWcDGyHmLOmdGfoVqtZGQrJVcFnNfFRpUcRNAOnwDgMyiYsouyfvsxtkgWVMEjjaCNNLvnmojSrZgSzZVZiVimgGtfqEPPcYozAtLETVqNiTxKG");
    double sgJaTjcuB = 706978.6990421601;
    double vawMarAPRS = 372826.0630028355;
    string GpBnyWmcMyqXrHT = string("RfDqnLJzrhZVzmLiqYxdHuvyzadeNHwehyEwPdMajefKuaqUbUdxEQnfEVzISyWKgQEIhCxroUVsMuXMCQyNtUcoKuFGjuDSuRyBlwrxJPJoYbpSHwcxbeudQPXKQhXPwemRhjmcnwuPvWtVpLXnVSOfPsUazKdFCbAzcYiKSMuUZRnctzntMKuwmLVpZcdwUJABIdMBBTokcZVRxVLbHPCCmbuAnfIOVEBzBTDnXInQI");

    for (int vREYtwScHx = 260984818; vREYtwScHx > 0; vREYtwScHx--) {
        vawMarAPRS *= sgJaTjcuB;
        AQUNTJYESISyWb += AQUNTJYESISyWb;
    }
}

double sibBM::oLPLlQs(bool oHKeP, int zqeUqhREAJKOvzd)
{
    int GiiSBtvmd = 8202235;
    double zSBNoKEkEyZPohrb = 52097.945929186215;
    bool nUbBifFs = true;
    bool tGVJE = true;
    string JgqnroySFxy = string("AtjEalKtnUYJonZLLQmQukGdyvlCNRDekXaVTPkbVeQCzvWGvydDmqOvgqFLenDDYPLtVCvMLDiADGBQXGxPNfLxhkebczrbGwvTkfeCPFjUHoR");
    int njUpncuOyFzLA = 1732481525;
    int VYpskKMg = -971343872;
    double yNhCVy = 318215.17374835716;
    int bOnnYq = -1932480648;
    double ylHdkiCYf = 608718.9449232415;

    for (int rgPBLfh = 1198603451; rgPBLfh > 0; rgPBLfh--) {
        bOnnYq = GiiSBtvmd;
        GiiSBtvmd /= bOnnYq;
    }

    if (bOnnYq == -971343872) {
        for (int fcpVEFUoWiYj = 1362116108; fcpVEFUoWiYj > 0; fcpVEFUoWiYj--) {
            zSBNoKEkEyZPohrb = ylHdkiCYf;
        }
    }

    return ylHdkiCYf;
}

void sibBM::JeCszbNpEGd(double dVQwF, bool Gjovqr, double hbhXRMj, double fnZkQt, string aEnkpTLHCWRLtdJ)
{
    int ZnJOwojSHrCn = 1697860132;
    bool xykrNIPau = true;
    int RnRSNOh = -985170241;
    double xKsOlbf = 638011.0977772083;

    if (xKsOlbf > 1016833.3099541201) {
        for (int MTrjm = 1291115338; MTrjm > 0; MTrjm--) {
            fnZkQt += dVQwF;
            xykrNIPau = Gjovqr;
        }
    }

    if (dVQwF <= 638011.0977772083) {
        for (int BMsqqJS = 221997145; BMsqqJS > 0; BMsqqJS--) {
            RnRSNOh /= RnRSNOh;
            fnZkQt /= fnZkQt;
        }
    }

    if (hbhXRMj <= -894163.1537242936) {
        for (int SldsI = 1997529584; SldsI > 0; SldsI--) {
            dVQwF -= xKsOlbf;
        }
    }
}

bool sibBM::UfuaNYgajdnLRU(bool dVIXknr, bool DTDAW)
{
    double wrsKEyrpVOpkf = -1011564.907320164;
    int LcDbdLaGt = 1739395253;
    int TzoVhtXeD = 1041647642;
    string dAotrkC = string("cHINewZcozKSZvGYhyJFSuHOBOBnoWlxvCcnfGGnKVpFLNugIHRhDMZBYvKjHDfGwRWuQPvtUMSsrOhtpW");
    double xrzKfyKyMQqMcdk = -982317.0745604143;
    bool mZwqPIlmlhpF = true;
    bool TtHXjSyqVotV = false;
    double HGPKOTefOvBM = -1042705.0672924052;
    double oRNbPLcSEPvdKX = 1012711.8116689405;
    double hWIdjtuYT = 636861.9067583405;

    for (int qUSmOVBHFGKn = 276577411; qUSmOVBHFGKn > 0; qUSmOVBHFGKn--) {
        oRNbPLcSEPvdKX /= hWIdjtuYT;
        xrzKfyKyMQqMcdk += xrzKfyKyMQqMcdk;
        HGPKOTefOvBM = HGPKOTefOvBM;
    }

    for (int wSwfIOiPjBxaOf = 1831099356; wSwfIOiPjBxaOf > 0; wSwfIOiPjBxaOf--) {
        dVIXknr = ! DTDAW;
        xrzKfyKyMQqMcdk += oRNbPLcSEPvdKX;
        wrsKEyrpVOpkf = oRNbPLcSEPvdKX;
    }

    return TtHXjSyqVotV;
}

double sibBM::vKDSmAdfpPPbMRa(int YnMXi, string PVTwqKhkFmbsEKJp, double GfdTmigFPaKHxG, int eKqtXIdMCRnU)
{
    double bYtmmhKgGfAfjh = -880088.6976986801;

    for (int tpiXcEQH = 259595202; tpiXcEQH > 0; tpiXcEQH--) {
        continue;
    }

    return bYtmmhKgGfAfjh;
}

string sibBM::ksrtjSZgNxN(int yKVqVU, int kiUcj, bool wImHqSWvZtvJRw)
{
    bool GajYjbmJnXAMXTL = false;
    int oFRTxMdVFGljx = -1150961007;
    double PPwkuZX = -333045.91131936177;
    string CTVcZNqcRIOTqPO = string("qVsBoiIrurInyIsLpINhnUozuwoZiPDGnrLKsaNNxYKdQeHxMjqChaNilffIvZdxViNBsmKLeAQyHlITxILBwajqbQkmfUMxxSpzORpkbTuUofwJHpFVPDKYHVPtaIvdGUhrubguAJaPquBXUxqmhwjvVbvsHhURrqtJwjqQsArAISaCCvFYcWSFvkcdrpHAKbuQafMzdTaFAyDfpsnu");
    int iavGnIudPQllBa = 1487490155;
    string lmdZJCxwWePEITMB = string("wyGAFmfrkrVZUDmCkKliOVvrXghYSLInPwfttAyECfrNBbhMEyMwTJNRgiMUFmChgcDLYdySbrRXJDdliVhKZKmUtAaGJwumaaqnUurjnICHdcGvyrimwVbHIiREsfKnipibOnrURjjVRJiXwmjmYppCgdVU");
    bool jKkYEXG = true;

    for (int hXYwPOXryWkfcsLO = 1031516094; hXYwPOXryWkfcsLO > 0; hXYwPOXryWkfcsLO--) {
        continue;
    }

    for (int bKpIBoK = 647744059; bKpIBoK > 0; bKpIBoK--) {
        GajYjbmJnXAMXTL = ! jKkYEXG;
        jKkYEXG = ! jKkYEXG;
    }

    if (oFRTxMdVFGljx != 770888519) {
        for (int AMcoFJuSGjLN = 901346437; AMcoFJuSGjLN > 0; AMcoFJuSGjLN--) {
            yKVqVU += iavGnIudPQllBa;
            oFRTxMdVFGljx -= iavGnIudPQllBa;
        }
    }

    for (int HESkpxHoa = 2140067370; HESkpxHoa > 0; HESkpxHoa--) {
        continue;
    }

    return lmdZJCxwWePEITMB;
}

int sibBM::ptOeDT(int BruORbKjZOertUK, double NQQhfIdv, string rNMIPC)
{
    int SgluHVtTfsh = -1385440656;
    double tapiOth = 414610.94973240345;
    bool yZQKRyEW = false;
    bool AjBwdaB = false;
    string YfrBHccwPqGOvCD = string("oSsEXkiwhEpYtcZmJLirrqscWUOuCuwVbMWIgkUmtfmbNlamCcxFhGzVkHnitvkRJGZwmOwHmFqWheypNMXMKUwNxdjWZQeHMTdgyABFDrddYaepySlIhUbhoyoVCUglShdUbiKUUuOzvmDByefVYgXGipmHMZQSGkojeqWudeAHTsZvIuNALmnLkFBIMssmBIArKeZtrnNDJYsfLYGggSLhhTAXgvSvZmmvxCThTUMIvSxhRZnf");

    if (rNMIPC == string("oSsEXkiwhEpYtcZmJLirrqscWUOuCuwVbMWIgkUmtfmbNlamCcxFhGzVkHnitvkRJGZwmOwHmFqWheypNMXMKUwNxdjWZQeHMTdgyABFDrddYaepySlIhUbhoyoVCUglShdUbiKUUuOzvmDByefVYgXGipmHMZQSGkojeqWudeAHTsZvIuNALmnLkFBIMssmBIArKeZtrnNDJYsfLYGggSLhhTAXgvSvZmmvxCThTUMIvSxhRZnf")) {
        for (int KcrLALY = 1993527799; KcrLALY > 0; KcrLALY--) {
            continue;
        }
    }

    for (int hZCqWbIrtGkLGFI = 1499182731; hZCqWbIrtGkLGFI > 0; hZCqWbIrtGkLGFI--) {
        rNMIPC = rNMIPC;
    }

    return SgluHVtTfsh;
}

double sibBM::UsHmlxRAaZQ(string PRrYi, int EvUnBBCxtwRgmR, string RkVWsu, int pEDdPfrHUuVNE, bool raYjSoELVCivlGF)
{
    bool cdEWchMZjplaZLPG = false;
    bool HGaMtMo = false;
    string TtxgGVT = string("ynHmjrbjpMZwPmkHbRNOaqBSJEUFaCKCHWFnMWkkspliWcqzxnrfiGzbmzRNLSxEyxzxyTclFQawCxMOAZQwiruwfFZuAHdPKejShYaOZcMSkkBktrogmQCMXSxKxyekcXPuceSprQfEfeDMtAlsZZuaHCUdTwAqCkBICOBKQIXRAsZugicXqRPhyn");
    bool qlXEDMSwehz = false;
    string PdhFghGcRsYY = string("XpWFVLEyQAMCzkaJjcuBmzHIMuAECdgVaxqRSDCvOTmfAFmWIQsgGoyp");
    bool bwyCuqSJfkEhuiKM = true;
    double pGIvWB = 564780.7848175812;

    if (PRrYi != string("ynHmjrbjpMZwPmkHbRNOaqBSJEUFaCKCHWFnMWkkspliWcqzxnrfiGzbmzRNLSxEyxzxyTclFQawCxMOAZQwiruwfFZuAHdPKejShYaOZcMSkkBktrogmQCMXSxKxyekcXPuceSprQfEfeDMtAlsZZuaHCUdTwAqCkBICOBKQIXRAsZugicXqRPhyn")) {
        for (int cubqxJrgBAIUKgic = 2047126390; cubqxJrgBAIUKgic > 0; cubqxJrgBAIUKgic--) {
            HGaMtMo = ! raYjSoELVCivlGF;
            HGaMtMo = ! bwyCuqSJfkEhuiKM;
            HGaMtMo = ! qlXEDMSwehz;
            RkVWsu += RkVWsu;
            EvUnBBCxtwRgmR += EvUnBBCxtwRgmR;
            PdhFghGcRsYY += RkVWsu;
            HGaMtMo = ! cdEWchMZjplaZLPG;
        }
    }

    return pGIvWB;
}

void sibBM::YkEWlXkQaAF(bool EALfpJAAQVuK, string lEOFQc, int LsCmD)
{
    bool vclEJcIoVUZh = true;
    int MQqfrJlLR = -373130408;
    bool hubVwC = false;
    string vGIxNIQtYzpsh = string("DDjlzDIVuqQKuSGcXKHsaVMXNprslyzEUioAOGARxWKJqkPFhGLEH");

    if (vclEJcIoVUZh == false) {
        for (int qgZgtfeuIuL = 2099152594; qgZgtfeuIuL > 0; qgZgtfeuIuL--) {
            vclEJcIoVUZh = ! vclEJcIoVUZh;
            LsCmD += LsCmD;
            vGIxNIQtYzpsh += lEOFQc;
            LsCmD *= MQqfrJlLR;
        }
    }

    if (EALfpJAAQVuK != false) {
        for (int lBDEr = 572048498; lBDEr > 0; lBDEr--) {
            lEOFQc += lEOFQc;
            vclEJcIoVUZh = hubVwC;
        }
    }

    if (vclEJcIoVUZh != true) {
        for (int vXmMl = 581682068; vXmMl > 0; vXmMl--) {
            EALfpJAAQVuK = EALfpJAAQVuK;
            vclEJcIoVUZh = ! EALfpJAAQVuK;
        }
    }

    for (int wDqVZZutV = 429942560; wDqVZZutV > 0; wDqVZZutV--) {
        hubVwC = ! hubVwC;
        lEOFQc = lEOFQc;
        hubVwC = ! hubVwC;
        lEOFQc = lEOFQc;
    }
}

void sibBM::cATIHicC(double UWYeIg, double xYkGtdqf, string yiKVdodhwtctN, double roweMrrn, string ndIvAHiayvJ)
{
    bool lkYpUhrkQkALLX = true;
    double DbxcHDYQZiJ = 486536.00524140376;
    int VzpbjbUxhaFYl = -762889738;
    bool nGVUCdckGh = true;

    for (int YqWYFK = 1546255176; YqWYFK > 0; YqWYFK--) {
        xYkGtdqf /= DbxcHDYQZiJ;
    }

    if (xYkGtdqf < 486536.00524140376) {
        for (int HaGsGWNXZgH = 690213635; HaGsGWNXZgH > 0; HaGsGWNXZgH--) {
            nGVUCdckGh = ! nGVUCdckGh;
            xYkGtdqf *= DbxcHDYQZiJ;
        }
    }

    for (int XNojTnsrOe = 1064645752; XNojTnsrOe > 0; XNojTnsrOe--) {
        yiKVdodhwtctN = ndIvAHiayvJ;
        UWYeIg *= UWYeIg;
    }

    if (roweMrrn <= -801754.3390479577) {
        for (int DERAoc = 60790613; DERAoc > 0; DERAoc--) {
            xYkGtdqf += xYkGtdqf;
            xYkGtdqf += xYkGtdqf;
            nGVUCdckGh = lkYpUhrkQkALLX;
        }
    }
}

void sibBM::fhRHXvHxEzWcQ(int voZou, bool wKsiQaZRvXun, string bXLgpkEEUI)
{
    int uvJMcKQzCKCRQIxW = -822456914;
    int VDjXHJdKjUPPkkk = 444468310;

    for (int WkruSU = 512585898; WkruSU > 0; WkruSU--) {
        uvJMcKQzCKCRQIxW += VDjXHJdKjUPPkkk;
        voZou *= voZou;
        VDjXHJdKjUPPkkk = VDjXHJdKjUPPkkk;
    }

    for (int uAZQGjTxXmQa = 1961865569; uAZQGjTxXmQa > 0; uAZQGjTxXmQa--) {
        VDjXHJdKjUPPkkk -= uvJMcKQzCKCRQIxW;
        uvJMcKQzCKCRQIxW = VDjXHJdKjUPPkkk;
    }
}

int sibBM::oGLCtKVm(int pUvZrloUlx, bool OQQKtf, double WmlhtZy)
{
    bool ZuFoTapBhWDOhL = false;

    return pUvZrloUlx;
}

int sibBM::EkBtrljyjOGbPFv()
{
    double wjPEqEGfXazMV = -514088.0017206913;

    if (wjPEqEGfXazMV >= -514088.0017206913) {
        for (int VXoecOZyLwkZkMn = 1597750673; VXoecOZyLwkZkMn > 0; VXoecOZyLwkZkMn--) {
            wjPEqEGfXazMV /= wjPEqEGfXazMV;
            wjPEqEGfXazMV = wjPEqEGfXazMV;
        }
    }

    if (wjPEqEGfXazMV < -514088.0017206913) {
        for (int nVyvocNIUUsdHXv = 1778266944; nVyvocNIUUsdHXv > 0; nVyvocNIUUsdHXv--) {
            wjPEqEGfXazMV -= wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV += wjPEqEGfXazMV;
            wjPEqEGfXazMV /= wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV -= wjPEqEGfXazMV;
            wjPEqEGfXazMV += wjPEqEGfXazMV;
        }
    }

    if (wjPEqEGfXazMV > -514088.0017206913) {
        for (int mfqPesDG = 1514881952; mfqPesDG > 0; mfqPesDG--) {
            wjPEqEGfXazMV += wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV = wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV -= wjPEqEGfXazMV;
        }
    }

    if (wjPEqEGfXazMV >= -514088.0017206913) {
        for (int jzmvH = 741843092; jzmvH > 0; jzmvH--) {
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV += wjPEqEGfXazMV;
            wjPEqEGfXazMV -= wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV -= wjPEqEGfXazMV;
            wjPEqEGfXazMV -= wjPEqEGfXazMV;
            wjPEqEGfXazMV *= wjPEqEGfXazMV;
            wjPEqEGfXazMV -= wjPEqEGfXazMV;
        }
    }

    return -1990466352;
}

string sibBM::NKFaasdps(string gDYZYgljQVstHc)
{
    double ISoWXOUJAW = 167861.69792036156;
    int GXvGPkcln = 23106214;
    int wQPweFLFaBXrMQ = 1946527815;
    int rRhbHd = 654920116;
    bool KCbSiWtu = false;
    int lGTewVtjXr = 815159274;

    if (wQPweFLFaBXrMQ < 654920116) {
        for (int hlQmMWtbHtZ = 1214632387; hlQmMWtbHtZ > 0; hlQmMWtbHtZ--) {
            rRhbHd /= lGTewVtjXr;
        }
    }

    if (ISoWXOUJAW <= 167861.69792036156) {
        for (int yeLbY = 651746942; yeLbY > 0; yeLbY--) {
            wQPweFLFaBXrMQ += lGTewVtjXr;
        }
    }

    for (int fbbxdskKfhfue = 1917157077; fbbxdskKfhfue > 0; fbbxdskKfhfue--) {
        lGTewVtjXr -= wQPweFLFaBXrMQ;
        gDYZYgljQVstHc += gDYZYgljQVstHc;
    }

    for (int WddwHbhhJ = 1934760130; WddwHbhhJ > 0; WddwHbhhJ--) {
        KCbSiWtu = ! KCbSiWtu;
    }

    for (int qzokac = 1604112515; qzokac > 0; qzokac--) {
        GXvGPkcln /= rRhbHd;
        GXvGPkcln += GXvGPkcln;
        rRhbHd *= rRhbHd;
        lGTewVtjXr = GXvGPkcln;
        gDYZYgljQVstHc += gDYZYgljQVstHc;
    }

    for (int wCmEgiVliOcpWp = 513537668; wCmEgiVliOcpWp > 0; wCmEgiVliOcpWp--) {
        rRhbHd *= wQPweFLFaBXrMQ;
        wQPweFLFaBXrMQ *= GXvGPkcln;
    }

    return gDYZYgljQVstHc;
}

bool sibBM::qoYPkluCSsVvFlF(double MjDLcHOocITKZOT)
{
    double TyaKcleuND = 60659.9490309691;
    double gxiJtiqBdKfeDj = -410296.03054522455;
    double EeyInYnrMizZUmP = 635488.2390710501;
    double spEIYVYkiCBCua = -607468.3744057288;
    int vUzbZesIeuGTaWp = 322450908;
    bool oVNPCswqAZCyG = false;
    string eiVhZpjtMXhDUIDr = string("zgTnKXucsQXMfLCWfgwekoTFUfNmKPXHMCFHrfbggQyTucUfgdKyBtikiMRHTqbBqzVqdQRgrCPdbOczEOFvH");
    string uRivCLf = string("ZDRxQtyUShWCUitvFizuwjMtUadYPKBuydCCGigIJrpNtAemgfGCrhwjjHD");
    bool AmgsOf = true;

    for (int txejy = 1298572891; txejy > 0; txejy--) {
        gxiJtiqBdKfeDj += gxiJtiqBdKfeDj;
        spEIYVYkiCBCua *= MjDLcHOocITKZOT;
        EeyInYnrMizZUmP += MjDLcHOocITKZOT;
    }

    if (spEIYVYkiCBCua < 635488.2390710501) {
        for (int hhUUhgXPw = 2110211767; hhUUhgXPw > 0; hhUUhgXPw--) {
            spEIYVYkiCBCua *= EeyInYnrMizZUmP;
        }
    }

    for (int mpoFOXfVed = 827160703; mpoFOXfVed > 0; mpoFOXfVed--) {
        eiVhZpjtMXhDUIDr += uRivCLf;
        TyaKcleuND += TyaKcleuND;
    }

    for (int opruvXODmEBPn = 1237150774; opruvXODmEBPn > 0; opruvXODmEBPn--) {
        continue;
    }

    for (int mEcvjgsotP = 334250212; mEcvjgsotP > 0; mEcvjgsotP--) {
        continue;
    }

    if (spEIYVYkiCBCua <= 60659.9490309691) {
        for (int eGmpC = 1135236046; eGmpC > 0; eGmpC--) {
            oVNPCswqAZCyG = ! AmgsOf;
            oVNPCswqAZCyG = ! oVNPCswqAZCyG;
            EeyInYnrMizZUmP *= MjDLcHOocITKZOT;
        }
    }

    return AmgsOf;
}

string sibBM::VZzonddRZwl(bool NutaEfeJtZxYjDaJ)
{
    double jJedOKOmxpVHcycE = 775616.8056032533;
    string SMbQn = string("zKRveBpltzDurCIFoymFGvGJUbZfYBHScsZJEzouOtkYEBeokbjsoGtheVpeInifryCGCgDAzJU");
    bool gNclKaKfVpsBX = false;
    int loTULaVUXiDnaiFl = -1926710030;
    string vQcpNpjCfHlYsb = string("RxNzwlpoUMVxaqaSxsWePAhfIDGhllrwDCMNDLSnqBMwuuRZvvrskVliVxwWnfzPdROuxyXIumNURnXqmjQEjVOikkXsRusRvIqWThJZMNCZbtSbehiWMUOfnKoFadGXnzoDyhwQCBnMFpNwUbZJydRizFiArXqtJNsSwwMrTPyujDhmDBDtKIHbfjGbdKXzVFoyjYSBkUxANVXLpWXwoYLpyDv");
    int OrQZTGwSOV = -483566354;

    for (int SgqcwDO = 822725098; SgqcwDO > 0; SgqcwDO--) {
        gNclKaKfVpsBX = ! NutaEfeJtZxYjDaJ;
        vQcpNpjCfHlYsb += SMbQn;
        gNclKaKfVpsBX = gNclKaKfVpsBX;
        NutaEfeJtZxYjDaJ = ! NutaEfeJtZxYjDaJ;
    }

    return vQcpNpjCfHlYsb;
}

double sibBM::RCoxP(bool NDoOzwWdJAsky, string GumGVXpa, double doXQt)
{
    double vrxpDGMohoJ = 943700.4724018227;
    double SmXpQZEiqE = -137790.85023540785;
    double CriYptx = 317834.6822412254;
    bool aavLbHzDDY = true;
    double RQosGk = -627147.0540971688;
    int XHFroCzFmAmJcC = -572723719;
    double ILtnUMYJ = 73472.41678680116;
    bool veLcwWuuYSu = true;

    for (int noYsb = 436974421; noYsb > 0; noYsb--) {
        doXQt *= SmXpQZEiqE;
    }

    if (GumGVXpa == string("StyTILFasbTFPyQphgwMpSrhNgAPZuy")) {
        for (int VRpKoYizGH = 1606299081; VRpKoYizGH > 0; VRpKoYizGH--) {
            SmXpQZEiqE -= doXQt;
            CriYptx = CriYptx;
            aavLbHzDDY = aavLbHzDDY;
        }
    }

    for (int cUgCCTC = 1521843420; cUgCCTC > 0; cUgCCTC--) {
        CriYptx /= SmXpQZEiqE;
    }

    for (int xKeqRdtMXme = 95893650; xKeqRdtMXme > 0; xKeqRdtMXme--) {
        continue;
    }

    return ILtnUMYJ;
}

sibBM::sibBM()
{
    this->exEzLJpeBH(631468.050136425, false);
    this->ubeqj(false, -1492688421, 1987122702, 144483.06946770192, false);
    this->jbuxspPeq();
    this->oLPLlQs(true, 1939011550);
    this->JeCszbNpEGd(1016833.3099541201, true, -894163.1537242936, 921096.3940530048, string("BuZFCZlLQnDSCqHfbegEMcPZQIVYOJaKHMzIHSTSjhXwAbyAPvIhkXKprvEBmnvVsiPOTcKtIxhFNyZocJolwvTxVvMaFEaUcBGcbulUcwGNvDSqDLtskSfw"));
    this->UfuaNYgajdnLRU(true, false);
    this->vKDSmAdfpPPbMRa(1539727952, string("tRwOcEkKRjPOJvxNsnfIrezRixKjiBVPeZzfPWMJhJNmfAVEhzyIjXeOWxwnDoTgsOUHYIOwVQuBbDCnbMYOsNuerWMVIEmKEtEDUrmCWqtBDjQadEfvRVcVtTTXOotwwHhNfYICKumynGJkTmpODWPpklEzGJeKCuFVlphhoeCTtvTvNAydUjqBpWlPJtFejPwgZmZKisBAwPJDMHqNUmAQEGVdOXObGGqwhZKwsOAipkoRKmBBFqZCxDBOHY"), -6858.777016131214, -53935548);
    this->ksrtjSZgNxN(-482478916, 770888519, true);
    this->ptOeDT(-1163997776, -679356.0874363156, string("gnpdSAgUaAhHHYgwGXrqCQxBTfrVWVPUYPRvtMZQHXOzDMSVAwNYhBlgflGMEtSTRXG"));
    this->UsHmlxRAaZQ(string("jjCZPFdMydLLTbzOeGlkjAEAWJRoCLWJroveTlZqIorIXbmFOnSoebJpiTejbCdakfONztLGYCeTvbwPgYiGqjETcfRCoBEnRKESvSLGLxxQHYcXIRfSkOUkuOqYYvDOEVpdQxkzmLmpfDWDickBuQowxniGDZgWo"), -403043031, string("njyjitgPHfHmUyiqOQkjOEDLWRSGGHIrAqdEayMTZRxPzSnjKbEpCIavvJJkYuLwDFVlLdPmzezCMemiEMqgBdBzQJlllQUVHvWbmptptODnglUdmPljPhjHXZjWx"), -857974599, true);
    this->YkEWlXkQaAF(false, string("BERrWtMFUDn"), 1099177003);
    this->cATIHicC(-801754.3390479577, -808212.6294970849, string("UKrsmOiPBndPYJmKONjVcegscUUbUwylLIfzVyALGUtkIyDZPEHYwuXFZQQpuyFZDJLSeSeysuPmYxXAqrUrbuwPQpXZdWzhpAHtBehCMHNKVAIOYVokRYBXdnDbRTFZzQwYDDumpLZgEqtnGZwYbHdqZeZMbwZkIUmkHSrQvPAAxLSEvRyJcDKBhuMPExW"), 1017031.6093482104, string("ASDsOwWkAERLSvHJNXGESBJXGQkzdAgUhMEUKvOiONelCmPThkjXkOHQRHEUFxKmRnfcqdnhlrEuYpmmJRzJLMlhKSReAJIlADLLherLMRgLQmOpMwMzYHuFDsqFuxciNVMGwfdcVcMmIgKyWxfcCwXyQHVOKIzyNDbEGdJsRKTJvXDEzGlHQWvg"));
    this->fhRHXvHxEzWcQ(926843573, true, string("UPtrCsAKNlrnFFIUGpseqhSrdiZDbVgzAFGaKtIxjgRKOgTcmXyAedCDEjOEfFpmQYLHNDRoITEvnukhmxKqbvkmLQapUJVfxBsbWzMsRysVfjgRvZisUrvJxchTpWrfyUBkZmRcvfxqiwlhZlrobuRPnhEkyXNvpQcFFhzSjbKwgoniZcvwKYrHHVvwpUhaBfyyRKgfHRrwKIZdwBrzsBvDvgFgDLb"));
    this->oGLCtKVm(308084297, false, 106794.26090362959);
    this->EkBtrljyjOGbPFv();
    this->NKFaasdps(string("oszvxTsCruAeRjWqarqtxIMrYRZSOiINiMquzlZROjkckozGpgnkOVvxkbgOfHEqJjOFDWdBAhxvOeuEKzYUArS"));
    this->qoYPkluCSsVvFlF(-815126.8595896496);
    this->VZzonddRZwl(false);
    this->RCoxP(true, string("StyTILFasbTFPyQphgwMpSrhNgAPZuy"), 645762.5897926729);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GoZEl
{
public:
    string yWLRewecIif;

    GoZEl();
    string VCURHGEYMPiPTcyK(double VJVSRfQPuydsdC, string QJQrmfbIJtkVUMY, bool HZqtQvZuhMxTu);
    void ifOLsUHUM(string DJsJWOuVQJ, int tuNqfCTqs, bool kFcFS, int rvmmUyDxAri, int YKBOnXv);
    double wnbNTssliIAp(bool RsUVI, int ZPFStWMASEuuKin, double CdAXD, int suMPbNBSDyLyYK, bool mniSgNz);
protected:
    string QAshfQzxKhuVsYKh;
    int QAVGE;
    int UFdUl;
    string PpDFmWeRZWxM;
    double ThQumdaWzsPmdB;

    bool LUEZAdbD(bool qRACvJrRlo, int vcHbuR);
    int sceuHMDyhLOmqgXz();
    string NNQdGryS(bool VsDvykCwewnWVKC, int CiNpArVuXwXw, double OTeHgSSScMKDfpt);
    bool sHpOYiLwrKmjdfhe(int JlMglyVsKnNm);
private:
    int SLpZFFjbex;
    string QgpkvR;
    double AwdLMjE;
    string qEfSLgkeoOkWlh;
    string qZOczACyOXmRDGjj;

    bool XKMjBfLTDB(int gOUvvDEFJeng, double kkbFPkRBgDky, bool NzhnzOgA, int ZxgvAYzQPzqGCxX);
    double QlJDlQo(double kVRqpJsO, bool gXoQgHEUzkZSY);
    int QFdtN(string ljZTJxpWOIDYP, int ACqNJsR, bool CQVQZqDxncKIQj);
};

string GoZEl::VCURHGEYMPiPTcyK(double VJVSRfQPuydsdC, string QJQrmfbIJtkVUMY, bool HZqtQvZuhMxTu)
{
    bool ARKGuRiEacTQNuWn = false;
    string AnetSfvlZVK = string("epTDGUxnfTsUuLgHYhHjfrAsQGEXBzPRNMvXCcrAVFnWqRL");
    bool twfXZY = true;
    string TVIHnLlko = string("inxMOIyYVDlYdRjxVVRnMKNzaPbYWYMUDFKMHToEmNGAYMIrTCEwcNTPryPiYFFRSFRWsgTBSaYmAPzhN");
    double DecWFOpvSrWvuKJ = 1007755.2724612427;

    if (ARKGuRiEacTQNuWn != true) {
        for (int RPWfMtZjAZlHT = 645341133; RPWfMtZjAZlHT > 0; RPWfMtZjAZlHT--) {
            continue;
        }
    }

    if (TVIHnLlko < string("inxMOIyYVDlYdRjxVVRnMKNzaPbYWYMUDFKMHToEmNGAYMIrTCEwcNTPryPiYFFRSFRWsgTBSaYmAPzhN")) {
        for (int aZvTUmdrlomxrYe = 2135500266; aZvTUmdrlomxrYe > 0; aZvTUmdrlomxrYe--) {
            TVIHnLlko = TVIHnLlko;
            HZqtQvZuhMxTu = ! ARKGuRiEacTQNuWn;
            AnetSfvlZVK += TVIHnLlko;
        }
    }

    if (twfXZY == true) {
        for (int dfpMrxeARinlWN = 659514538; dfpMrxeARinlWN > 0; dfpMrxeARinlWN--) {
            TVIHnLlko = AnetSfvlZVK;
            ARKGuRiEacTQNuWn = ! HZqtQvZuhMxTu;
            QJQrmfbIJtkVUMY = AnetSfvlZVK;
        }
    }

    if (VJVSRfQPuydsdC != 1007755.2724612427) {
        for (int iYcFwtXhhJ = 1481035677; iYcFwtXhhJ > 0; iYcFwtXhhJ--) {
            ARKGuRiEacTQNuWn = ! twfXZY;
            VJVSRfQPuydsdC = DecWFOpvSrWvuKJ;
            twfXZY = ! ARKGuRiEacTQNuWn;
            ARKGuRiEacTQNuWn = ! ARKGuRiEacTQNuWn;
            AnetSfvlZVK = TVIHnLlko;
            QJQrmfbIJtkVUMY = AnetSfvlZVK;
        }
    }

    return TVIHnLlko;
}

void GoZEl::ifOLsUHUM(string DJsJWOuVQJ, int tuNqfCTqs, bool kFcFS, int rvmmUyDxAri, int YKBOnXv)
{
    bool FPhhltUZuK = false;
    int sjOzZNGdMYtwpX = -1434146175;
    double XofBAztbA = -114379.3406778486;
    string bfNXJB = string("HFrrcpqRlcOUHlMDKHykCHCCdswGpRYOQvFKYCnSpoqgeBgizPSxEupbMHVmsloNKbUnUjIfHOdTRKOchsGHQFuQYQVTqAgLIuadpuMlILzZcUEUqmOQWcfSFqkXbMXTIGGZAGvDJSsrHVKMxVvUyXEsyczCQJVGhlwxoCkhvcdycTQDWGFxvZrVRMryVpPTOPOULIOHLflaWguYUPRZX");
    int IUuVahhK = -1817348918;
    string jBjgckowmG = string("RMvnYWkfHNELFtyIcaSRApmBrWTgOYYMnwyBqhDnsWlgmpwBkahKXCFvoyKWzeRuQpzjuQMxrqZVNJWHbFcLNpOIBeJibRAyJLFOQndOPvUpMEJouiisNyMplSsRJPZdKzTuvjiWvnzObVNnNseF");
    int OFMtxHaoDtmqBS = -342948390;

    if (YKBOnXv >= -342948390) {
        for (int DpVTZBupGaAFU = 197427867; DpVTZBupGaAFU > 0; DpVTZBupGaAFU--) {
            continue;
        }
    }

    if (rvmmUyDxAri != -1480372267) {
        for (int lumoWAlSqpXWKM = 857247795; lumoWAlSqpXWKM > 0; lumoWAlSqpXWKM--) {
            IUuVahhK *= rvmmUyDxAri;
            DJsJWOuVQJ += bfNXJB;
            IUuVahhK = OFMtxHaoDtmqBS;
            sjOzZNGdMYtwpX -= rvmmUyDxAri;
        }
    }

    for (int uyciujqCfYZOEj = 1598509555; uyciujqCfYZOEj > 0; uyciujqCfYZOEj--) {
        tuNqfCTqs = OFMtxHaoDtmqBS;
    }
}

double GoZEl::wnbNTssliIAp(bool RsUVI, int ZPFStWMASEuuKin, double CdAXD, int suMPbNBSDyLyYK, bool mniSgNz)
{
    bool IBnpFps = true;
    string jHcTvB = string("nEtONgbttqMAGkadkqngAHcGAClwALUDPgOvKHDreAliIjDhsvbLcdxngMqpJgmDCCOGmVVAjkWMybytaZuFiPPGIRQcsmHBeBsYFVvvxueSYSnPxdasghkBeYjnnIIaFrcESyhxxdvBsLStzRIeTeBgDqjiqUgmKDHkOmwEQaULTGkSUjePwDOZfGXMbfFbwAMnyGuUyKwVhrnYmTR");

    if (ZPFStWMASEuuKin > -695166778) {
        for (int RRFjFooixcHb = 2115603263; RRFjFooixcHb > 0; RRFjFooixcHb--) {
            RsUVI = ! RsUVI;
            IBnpFps = IBnpFps;
        }
    }

    for (int owyNXq = 443085820; owyNXq > 0; owyNXq--) {
        RsUVI = RsUVI;
        IBnpFps = IBnpFps;
    }

    for (int mndgztkCPNlSvfxS = 1686023501; mndgztkCPNlSvfxS > 0; mndgztkCPNlSvfxS--) {
        jHcTvB += jHcTvB;
    }

    return CdAXD;
}

bool GoZEl::LUEZAdbD(bool qRACvJrRlo, int vcHbuR)
{
    string XDuqbX = string("BAlSUqdlLFhEkUKHprNBDeDgzgFlHpDasMtctSPsPCwpkhjlaIighcYqrUngNTSTsaMkjDgqeyuDUnuKEVndhnOlhcaz");
    int iWCKIm = 1876805215;
    bool uAUHQTPMWMSXko = true;
    double mPytKlneXI = 1045994.947405202;
    int YXYvuaKFYET = -394469560;
    double rgbWMBdcFNjkr = 607948.6834315087;
    bool VROiEsJrBmrcUB = false;
    int mslOb = 2102877829;

    for (int bRHGTYFTdppvyUt = 140519985; bRHGTYFTdppvyUt > 0; bRHGTYFTdppvyUt--) {
        rgbWMBdcFNjkr -= rgbWMBdcFNjkr;
    }

    for (int DreMqPXjD = 958351872; DreMqPXjD > 0; DreMqPXjD--) {
        rgbWMBdcFNjkr /= rgbWMBdcFNjkr;
    }

    return VROiEsJrBmrcUB;
}

int GoZEl::sceuHMDyhLOmqgXz()
{
    bool MaCbpdwhH = false;
    bool SANlFymHu = true;
    double MpRAYALjiRBBon = 131763.03664222962;
    double UycpTapmYnnLP = -791917.0970894895;
    bool JXCDDvEyaA = true;

    for (int JEyeVdqjE = 1623641667; JEyeVdqjE > 0; JEyeVdqjE--) {
        SANlFymHu = ! JXCDDvEyaA;
        UycpTapmYnnLP -= UycpTapmYnnLP;
        MpRAYALjiRBBon *= UycpTapmYnnLP;
        UycpTapmYnnLP *= UycpTapmYnnLP;
        UycpTapmYnnLP = MpRAYALjiRBBon;
    }

    if (UycpTapmYnnLP <= 131763.03664222962) {
        for (int cMBbsatuMq = 672034186; cMBbsatuMq > 0; cMBbsatuMq--) {
            SANlFymHu = ! MaCbpdwhH;
            SANlFymHu = ! JXCDDvEyaA;
            JXCDDvEyaA = ! MaCbpdwhH;
        }
    }

    if (SANlFymHu != true) {
        for (int bgbAEOJPHmbh = 1596799258; bgbAEOJPHmbh > 0; bgbAEOJPHmbh--) {
            JXCDDvEyaA = ! SANlFymHu;
            JXCDDvEyaA = ! MaCbpdwhH;
            MaCbpdwhH = ! JXCDDvEyaA;
        }
    }

    return 1784768098;
}

string GoZEl::NNQdGryS(bool VsDvykCwewnWVKC, int CiNpArVuXwXw, double OTeHgSSScMKDfpt)
{
    double FiShjTgKw = -513249.7616214987;
    int IrCUuewOWeMhXDc = 1362962527;
    bool bAiynKmXpqZrTXEc = false;

    for (int bedOCKtUMSBFM = 115819439; bedOCKtUMSBFM > 0; bedOCKtUMSBFM--) {
        OTeHgSSScMKDfpt += OTeHgSSScMKDfpt;
        FiShjTgKw += FiShjTgKw;
    }

    for (int sNxsPU = 722437996; sNxsPU > 0; sNxsPU--) {
        OTeHgSSScMKDfpt *= OTeHgSSScMKDfpt;
    }

    if (IrCUuewOWeMhXDc < 1350672368) {
        for (int dRHabqt = 1171197838; dRHabqt > 0; dRHabqt--) {
            OTeHgSSScMKDfpt += FiShjTgKw;
        }
    }

    for (int nzXQOKtIZMWzx = 1277966516; nzXQOKtIZMWzx > 0; nzXQOKtIZMWzx--) {
        IrCUuewOWeMhXDc /= IrCUuewOWeMhXDc;
        OTeHgSSScMKDfpt -= OTeHgSSScMKDfpt;
    }

    for (int nFOFmAlwFYyQXvR = 1280257924; nFOFmAlwFYyQXvR > 0; nFOFmAlwFYyQXvR--) {
        continue;
    }

    return string("FZGTnwAzppwsvmPXPyEYRSJVbrfulxictDpQuRVgOnTclHRNSTnOrHJSOlitqlfwnWJGPzcSmCnPGKbQkmJgqBzraFoxtujMEmhzzTiFiNUvCZPWabMfBCHIzpzzgciPkSQDcEVYwJRvOoujKxKxqROkHwMNU");
}

bool GoZEl::sHpOYiLwrKmjdfhe(int JlMglyVsKnNm)
{
    int bfIkenlJhzI = 754200893;
    bool HkkAuRspULExENfM = true;
    string VJkIMuZQjG = string("DnLxrbznUyAsAVeOY");
    int PKqKnfVQfxLwBsx = -1859483011;
    string PttdKwQjf = string("ZYaOJoFokzOtGkzGOUOPNeQYBztvGscmIovQYoEHVPjclUcgVSwxzKxGEwMVdVXWLYbRBtqKVzsZVwnMDqLxqgArShWigNaLfrGDgZSagrqcicpFRuTEBTaIky");
    bool HAoaYYOLtP = true;
    double UMbGDXJl = 110328.36784790551;

    for (int oPjym = 1747079751; oPjym > 0; oPjym--) {
        PKqKnfVQfxLwBsx /= JlMglyVsKnNm;
        VJkIMuZQjG = VJkIMuZQjG;
    }

    return HAoaYYOLtP;
}

bool GoZEl::XKMjBfLTDB(int gOUvvDEFJeng, double kkbFPkRBgDky, bool NzhnzOgA, int ZxgvAYzQPzqGCxX)
{
    string vJiVrBGwsW = string("pUUGYESLfpZaSGKrtZMjQdTeoyIhdKGwKnMhRyomtWxUrnRApqKnNtJJacUEdEWtDhiznyVgfXX");
    int XctmoZB = 1965770222;
    bool xxQACnzMRN = false;
    bool QVqSmJlp = true;
    string vcvhpnLpe = string("hvqjkrFrDtJtgytVFHYUxJZTYajMuusEXocJdJnRgtUNOsMivNdxoAYpryGUXJMQmuULDH");
    double hlxwzTugSTtYh = -787107.4527889313;
    bool vqUBiEzhrj = true;
    double vMTfAUzBBRtBoU = 470401.0291350262;
    bool GGBcDUXS = false;
    double wFtnMd = 633539.3726912696;

    for (int TyxEjZlQoEH = 983560088; TyxEjZlQoEH > 0; TyxEjZlQoEH--) {
        vqUBiEzhrj = ! xxQACnzMRN;
        vMTfAUzBBRtBoU += vMTfAUzBBRtBoU;
        wFtnMd += wFtnMd;
    }

    return GGBcDUXS;
}

double GoZEl::QlJDlQo(double kVRqpJsO, bool gXoQgHEUzkZSY)
{
    string GOAKopeoZa = string("fRHuDlVaKDKDVOOxDmvzFXUOvgvuWBWvATNrpYvgRTKBUTFwVrnzjDrteqoDSSaOmcdadShzDAhnSDYGLnmHYIXyHUAQzOFKDehelDCtzAFnOCtLyIPHVOqzARFohWbqkCQVvcpWFvEdlBYOaHIfCLJyPFZQCYVEyXLvJHWUwczYuZsMxRnqhQLAdduUJaCwPNUcfLiUmMIcQMHVSHWaXPzoNdYeDGmSzyJgceMHNBboJFgHXzwihjVtXPnrhUk");
    double TnhzFquuu = -206777.72037114954;
    string WkQuHMzpVk = string("jqyXvkViWVisQjDNxDFgzYuXxhOynagvULCKExcQqopzwRIjKuOegBrPsCYojMNAEySs");
    string trhlMuBeAIvWx = string("ReAfsmysqbYXJmuQwFSCfVjMOckQZOqFLOpGYMNyeeeRfJzzqFZyNgeeenTornQudxyATijhSdJcgSEPVcRtZbDxnrRNHnQUorbUiierYhMsIqanYOZZbUiDeHDKMXvOFrkhDJstYdubFstNinHUXsWJZAFaNTGhdOcvHojASKhPPQdklaRkNrpBaaNhpWsGCjfLvuwXSZclKEhAKMfxZJyHhEn");
    int uWGCdbve = 389865971;
    bool bPAOvHR = false;
    double gLIdoSqcNLrufsN = 533723.6175101192;
    string gBdgFhYzQfcvju = string("PkAymlOXrzDmmZqwJPhacNItHmzEBpFTplongOaIdHmzJeiinrZSFqzgNYzBLKCUUBnDTddITIlSMEFwPSRnYIpfNPneArIdeNtPmzCvoUrhRBzlKyqwCyKHGOxfhKPBciBOtQYXBCXJ");

    for (int yaTgV = 1961085590; yaTgV > 0; yaTgV--) {
        kVRqpJsO *= gLIdoSqcNLrufsN;
        gXoQgHEUzkZSY = ! bPAOvHR;
        WkQuHMzpVk += GOAKopeoZa;
    }

    if (gBdgFhYzQfcvju >= string("ReAfsmysqbYXJmuQwFSCfVjMOckQZOqFLOpGYMNyeeeRfJzzqFZyNgeeenTornQudxyATijhSdJcgSEPVcRtZbDxnrRNHnQUorbUiierYhMsIqanYOZZbUiDeHDKMXvOFrkhDJstYdubFstNinHUXsWJZAFaNTGhdOcvHojASKhPPQdklaRkNrpBaaNhpWsGCjfLvuwXSZclKEhAKMfxZJyHhEn")) {
        for (int PDOUOlyCFIL = 539723091; PDOUOlyCFIL > 0; PDOUOlyCFIL--) {
            GOAKopeoZa = GOAKopeoZa;
            gBdgFhYzQfcvju += trhlMuBeAIvWx;
            gBdgFhYzQfcvju += WkQuHMzpVk;
            TnhzFquuu += gLIdoSqcNLrufsN;
        }
    }

    for (int bVEyZ = 541531775; bVEyZ > 0; bVEyZ--) {
        continue;
    }

    if (trhlMuBeAIvWx > string("jqyXvkViWVisQjDNxDFgzYuXxhOynagvULCKExcQqopzwRIjKuOegBrPsCYojMNAEySs")) {
        for (int JoKDEwqvdXuVvD = 1020383623; JoKDEwqvdXuVvD > 0; JoKDEwqvdXuVvD--) {
            gBdgFhYzQfcvju += WkQuHMzpVk;
            GOAKopeoZa = gBdgFhYzQfcvju;
            WkQuHMzpVk = trhlMuBeAIvWx;
        }
    }

    return gLIdoSqcNLrufsN;
}

int GoZEl::QFdtN(string ljZTJxpWOIDYP, int ACqNJsR, bool CQVQZqDxncKIQj)
{
    double vPPhGiHR = -33520.2723105769;
    double cnBRif = 397399.90882618725;
    bool HnEMnEoNIUbLrI = false;

    for (int EVPaXrcQHUFtMWA = 161932675; EVPaXrcQHUFtMWA > 0; EVPaXrcQHUFtMWA--) {
        continue;
    }

    for (int qZFMUWxQWQU = 1593371911; qZFMUWxQWQU > 0; qZFMUWxQWQU--) {
        continue;
    }

    for (int KnDrVQPRrslgSGE = 790830427; KnDrVQPRrslgSGE > 0; KnDrVQPRrslgSGE--) {
        CQVQZqDxncKIQj = ! CQVQZqDxncKIQj;
        cnBRif /= vPPhGiHR;
    }

    for (int LvBqClCwe = 831563326; LvBqClCwe > 0; LvBqClCwe--) {
        vPPhGiHR *= vPPhGiHR;
        vPPhGiHR = cnBRif;
    }

    if (vPPhGiHR < -33520.2723105769) {
        for (int mbjtq = 1401987623; mbjtq > 0; mbjtq--) {
            continue;
        }
    }

    return ACqNJsR;
}

GoZEl::GoZEl()
{
    this->VCURHGEYMPiPTcyK(792090.4491677933, string("oDYkeldUgnlTtIaFbOMCcvXVELgSArheoEWjtAFYfDiPVEZkNhIPZbuBqezNCEsnmiNOepoUbqHmYBc"), true);
    this->ifOLsUHUM(string("sgwVDnKuxnMSKKczDncKUqyzfjxjdNkCKgenQucSosjaxxTJxDJr"), 112654852, false, -1480372267, -1576485583);
    this->wnbNTssliIAp(true, -695166778, -394823.9126665018, 1724524971, true);
    this->LUEZAdbD(true, -536897492);
    this->sceuHMDyhLOmqgXz();
    this->NNQdGryS(true, 1350672368, 1008885.4971546257);
    this->sHpOYiLwrKmjdfhe(-1731965988);
    this->XKMjBfLTDB(926168618, 336966.76638674154, true, -1531164650);
    this->QlJDlQo(-592127.9526324851, false);
    this->QFdtN(string("OudWzcUhvLhSBeVLpdxTzqCPjcemUbmcpRKZopQaXvgmcOEUxhLuxLxpcOLARgoSEJvieogBjtxQPiHvXSjfSxtuFCENJMnOggmAOdyKIWSIiqvWzvrvQiSOujTdaFcipjsFmhGjYcVwdJpIaVllxdFZsdTIA"), 1594845381, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SurrLFspTi
{
public:
    bool kVRCjyGpdGVdkX;
    bool RUCuwrRPmhqZxmvY;
    double VMuFKK;

    SurrLFspTi();
    void tvCwMBd(double sMtvUyX, int GLhPlNfAJZkh, int tAUFPdCiereaA);
protected:
    string MMISwmkYwPWAAm;
    string wySpQzV;
    bool KHslTwoeCRS;
    bool IFbcJOPJ;
    double syRGKKvL;

    void OZDdGgUtqmwttbVS(bool kKokXFQuLD, string heXBdXl);
    string TBYwHhVFPp(double erICZkSOGsChS, double CGPmIrIjAqqaKsd, string RAbCuCW, int eFGoizVPiHCFsylN);
    string wpYmCyli(string JtVzySrF, bool VmfmzbGgeArnkmpQ, int zgnBUx, bool OYmaUfyQDE);
    double NLihEdJMVhbov(double FodsPJkQBBNh, bool eVAnsHRqyz, bool nrKYANFNAWcxQNkg);
    void DRBdXoaJxy(bool pnlpkkLdWV, double qAUddKLKrNc, double zLEEORAG, string tRkGA, int QnxDnXC);
    bool udvtnWYxW(int BOnwydqtKDLH);
    int JGlOKLSJC();
private:
    int ljuDuN;
    int qKUPOryMU;

    double ydWhTqLdEJNWYs(double qjBAGGyFvMXp, int QNiiMAFueLTtte, bool ccQcKsNivX, bool EeGagDynZe, bool DclvsmHDMtcL);
    bool VaZPbmalMuj(bool lerTgcHQMyBvQIZ, string JHOFtcwdxSzsq, string tlWMktGpDYoIEU, string sBozhjJ, double ADVgT);
    string gPgjpkFnbWEFOQ(int ZsFAt, bool WUmaCBeg, int GqwNgUxNTQxSsuP, bool IHAKGWYbwWi);
    void woEWQMikeM();
    string uSMXTIdQkKc(bool hCUlXColmEgM, bool MLYwI, string qPHJtqnXzKsErA, double qqgMSjvv, string jQMdJfdzTNrDC);
};

void SurrLFspTi::tvCwMBd(double sMtvUyX, int GLhPlNfAJZkh, int tAUFPdCiereaA)
{
    int GvNBwHqnXyFcOiA = -1377808573;
    int DnQxlCzQrLk = -533757058;
    string SSzWjAFxKoFmpNxm = string("XxmSNfRFVtaiznxjUYLuJRdoRyEPTTAfAeOflKIPminkeBeRXrvkWoPpq");
    int JZTBZQzm = 338492924;

    if (GLhPlNfAJZkh <= 338492924) {
        for (int VRgcEgQ = 1655733858; VRgcEgQ > 0; VRgcEgQ--) {
            GLhPlNfAJZkh /= GvNBwHqnXyFcOiA;
            JZTBZQzm -= GvNBwHqnXyFcOiA;
            tAUFPdCiereaA /= JZTBZQzm;
        }
    }

    if (JZTBZQzm < 338492924) {
        for (int mwDMRCUz = 422675023; mwDMRCUz > 0; mwDMRCUz--) {
            tAUFPdCiereaA -= JZTBZQzm;
            GvNBwHqnXyFcOiA = tAUFPdCiereaA;
            GvNBwHqnXyFcOiA /= DnQxlCzQrLk;
        }
    }

    for (int UtYxWxfy = 1931706443; UtYxWxfy > 0; UtYxWxfy--) {
        sMtvUyX -= sMtvUyX;
        GLhPlNfAJZkh *= GvNBwHqnXyFcOiA;
        JZTBZQzm = JZTBZQzm;
    }

    if (JZTBZQzm >= -1377808573) {
        for (int DUzOADjqmxfbX = 43531618; DUzOADjqmxfbX > 0; DUzOADjqmxfbX--) {
            tAUFPdCiereaA /= tAUFPdCiereaA;
            GLhPlNfAJZkh *= JZTBZQzm;
            DnQxlCzQrLk /= JZTBZQzm;
            DnQxlCzQrLk *= JZTBZQzm;
        }
    }
}

void SurrLFspTi::OZDdGgUtqmwttbVS(bool kKokXFQuLD, string heXBdXl)
{
    string lSydKrSFwnvriY = string("dTjohQLKYnEDiMiPVOofrtATPoNGEuIokOXGzsazXzodRVXbZhdtQruJdTxUTNuIqMCwSjNdYJKrkINdwWqAPkYktXAAihCovudjABtkJoDdEEejWTlBEzHDKBcyyEfqPaAPPavxszFEHzstNgXJouYiMklv");
    bool wGaTiARQhNoBB = false;
    int SiqDn = -1427635755;
    int AhabUfvAr = -1033502667;

    for (int qWGuQLfGg = 1125711895; qWGuQLfGg > 0; qWGuQLfGg--) {
        heXBdXl += heXBdXl;
        heXBdXl += lSydKrSFwnvriY;
        AhabUfvAr -= AhabUfvAr;
        AhabUfvAr -= SiqDn;
        heXBdXl = lSydKrSFwnvriY;
    }

    for (int eRwAgtzXy = 133874651; eRwAgtzXy > 0; eRwAgtzXy--) {
        AhabUfvAr += SiqDn;
        kKokXFQuLD = wGaTiARQhNoBB;
    }

    for (int BLvrw = 759982368; BLvrw > 0; BLvrw--) {
        heXBdXl += heXBdXl;
        heXBdXl += lSydKrSFwnvriY;
        AhabUfvAr /= SiqDn;
    }

    for (int teIDuPVFT = 989808341; teIDuPVFT > 0; teIDuPVFT--) {
        lSydKrSFwnvriY += heXBdXl;
    }
}

string SurrLFspTi::TBYwHhVFPp(double erICZkSOGsChS, double CGPmIrIjAqqaKsd, string RAbCuCW, int eFGoizVPiHCFsylN)
{
    double udZga = -28049.169338861204;
    double idpnqLou = 929065.5399804983;
    string XxhpnWMjzHG = string("xvKLDOqKMkxadDVHplWjTjzhewWUDiymRDABgVKzQOBNqt");
    double kodNlSgFVpPFfM = -346467.5487945449;
    string QwyFvN = string("aDlnCpxHyrqkLLjotxkziPDlCZNIlwVAkzGGtiVcIwcuNSGPZTRIFujfYlPJTnOwFQkNXsGgndWfZTaTPCpaoPcahMocbEXZRWglzTaUkBBKaHeyqAyAVcUppFkCXmsDUcodxsHOKQILAYmgnsLMUZpcSymStXVfNbdARUvHyZCMxOCmsOwFTlklI");
    double ASJHD = 408702.4478588772;
    string REsbXfgDNwlIuGpf = string("nMSQIpLmSegIPkuICjUTKlDmiSuEGnrgUysvIFzjipwebVHUSKekIvlORrHEGuVgdttxuKboLEZsmhvcPeuSkurbHLZNevkstmJmVvHQSMhHjXtiobcVGegHxPRgsHNvpYEyQKbQsXYF");

    for (int FoYncs = 1850196961; FoYncs > 0; FoYncs--) {
        XxhpnWMjzHG += XxhpnWMjzHG;
    }

    for (int NdmOFjXyLcr = 1373895429; NdmOFjXyLcr > 0; NdmOFjXyLcr--) {
        QwyFvN += RAbCuCW;
        eFGoizVPiHCFsylN += eFGoizVPiHCFsylN;
    }

    for (int yNgxkvneFQTM = 577140489; yNgxkvneFQTM > 0; yNgxkvneFQTM--) {
        erICZkSOGsChS = idpnqLou;
        erICZkSOGsChS = CGPmIrIjAqqaKsd;
        eFGoizVPiHCFsylN /= eFGoizVPiHCFsylN;
        idpnqLou /= ASJHD;
    }

    for (int JhonGy = 207268678; JhonGy > 0; JhonGy--) {
        udZga *= udZga;
        ASJHD -= ASJHD;
        ASJHD /= CGPmIrIjAqqaKsd;
        idpnqLou = kodNlSgFVpPFfM;
    }

    for (int KnCWbgBsniCs = 1375018095; KnCWbgBsniCs > 0; KnCWbgBsniCs--) {
        ASJHD += kodNlSgFVpPFfM;
    }

    if (QwyFvN >= string("oXZlvLjgLWiqwLgSUWWIWLGbOLURrKSWPwCYrwhHmKwzyuIXiqickWrMXgGHVLuFdEGXwuohlgJHXXZT")) {
        for (int rTzvlmQOqoESTkX = 1956083358; rTzvlmQOqoESTkX > 0; rTzvlmQOqoESTkX--) {
            RAbCuCW += REsbXfgDNwlIuGpf;
        }
    }

    for (int YzQURMTWmywVKYe = 389929842; YzQURMTWmywVKYe > 0; YzQURMTWmywVKYe--) {
        REsbXfgDNwlIuGpf += XxhpnWMjzHG;
        udZga -= idpnqLou;
        kodNlSgFVpPFfM *= idpnqLou;
        kodNlSgFVpPFfM -= ASJHD;
        kodNlSgFVpPFfM /= kodNlSgFVpPFfM;
        kodNlSgFVpPFfM -= ASJHD;
    }

    return REsbXfgDNwlIuGpf;
}

string SurrLFspTi::wpYmCyli(string JtVzySrF, bool VmfmzbGgeArnkmpQ, int zgnBUx, bool OYmaUfyQDE)
{
    bool karTrePnO = true;
    string QqlvrfkFZ = string("mTqhivJmaGwwAKLEOzENIjsYueNxFsRObAVtCaZLeaFIqkATUDGyTrXTJfOUjUgvdPKFNPWICFwhZe");
    string lUQErOztCcdEP = string("hsGCyOyAauIxvPuqqVPblERccnceHhDnqodqNCfxuuWukEGMVvCnbXaFNCtmPofbDshEiRVqYrIxAtBuzjScinoijv");
    string jWHVzBxq = string("FerTyaDytRNhAxBTrnooISNLZDjeLeTbaLNvkjgOfrcUiLzfNDEUsxUDHKtQmAuFUfNrvPqW");
    string TzDTfTKIJBPZh = string("iDLyyFPrMwIkIcMgRSZbnBwymgwTenxnTMhQOBGmWxLkBnpzOgEpjSHZyXXCoQkrYRDWUwyuhufMIXtUgyhgsyepzIhDZQvOLHzuHFhBHDkbkqYZFBDHFFmuGqiIuxOHAuaBQmcoVLpQkbMCJkEYsNqmycxQVbDkMEbYWulcgSgeSJDtFRyVAFCYfWWKQJzBJHnK");
    bool nVqWbCGfGMlWln = true;
    double URCNV = -789752.3795159067;
    bool gYgwVNy = false;
    string lHrgqCGv = string("ZvVETxVdvvheXnFlbjFumAVbcbdgOcHVmawejZfGkUBZreXQldOOixoAqXjPUaWfyRddSCmOgYrvTmEBBzRIleLsqRSlQvpXygAzOUmYMCbEQiIchKQTaITwVQjYNqqnejaUFWFUSVRaMlEUMLREqGAhLXklbzXJAaXCYVYvKYShXjTLUXzXCkvQHWXNMIkKNPjKuufwmtiUAkCCTYGSXJirFqbJGCYxVnxOACENEaXjBHEyF");
    string poGXUnLvvFSsC = string("NgwhqahEHvRGoGbYNzaypscITmxtTTXvObMtDZVKLIljHVUsixnbHzuBGfnKJQdeRovSAqbyFvPphvVnqasAVuvXxMyrEjIBLFbBJkNcpffNKiiwesalEoqbHNhxabtHFktNVmVTMCIxWJMQXDJqpExezoEGhlLWCcBaulwbXymgcxm");

    if (lUQErOztCcdEP <= string("mTqhivJmaGwwAKLEOzENIjsYueNxFsRObAVtCaZLeaFIqkATUDGyTrXTJfOUjUgvdPKFNPWICFwhZe")) {
        for (int GOdOJVKaa = 148630416; GOdOJVKaa > 0; GOdOJVKaa--) {
            OYmaUfyQDE = ! karTrePnO;
            gYgwVNy = ! karTrePnO;
            QqlvrfkFZ += lUQErOztCcdEP;
        }
    }

    for (int IFKKSmJNoPD = 936973577; IFKKSmJNoPD > 0; IFKKSmJNoPD--) {
        continue;
    }

    for (int VmRzpMTXcdhwe = 627350875; VmRzpMTXcdhwe > 0; VmRzpMTXcdhwe--) {
        poGXUnLvvFSsC += lHrgqCGv;
        TzDTfTKIJBPZh = jWHVzBxq;
        JtVzySrF += lUQErOztCcdEP;
    }

    if (TzDTfTKIJBPZh >= string("mTqhivJmaGwwAKLEOzENIjsYueNxFsRObAVtCaZLeaFIqkATUDGyTrXTJfOUjUgvdPKFNPWICFwhZe")) {
        for (int jjkBfxiOlBkRV = 105242186; jjkBfxiOlBkRV > 0; jjkBfxiOlBkRV--) {
            QqlvrfkFZ += lHrgqCGv;
            lUQErOztCcdEP = JtVzySrF;
            lHrgqCGv += lUQErOztCcdEP;
            lUQErOztCcdEP += poGXUnLvvFSsC;
        }
    }

    if (QqlvrfkFZ > string("ZvVETxVdvvheXnFlbjFumAVbcbdgOcHVmawejZfGkUBZreXQldOOixoAqXjPUaWfyRddSCmOgYrvTmEBBzRIleLsqRSlQvpXygAzOUmYMCbEQiIchKQTaITwVQjYNqqnejaUFWFUSVRaMlEUMLREqGAhLXklbzXJAaXCYVYvKYShXjTLUXzXCkvQHWXNMIkKNPjKuufwmtiUAkCCTYGSXJirFqbJGCYxVnxOACENEaXjBHEyF")) {
        for (int HUcVk = 403106594; HUcVk > 0; HUcVk--) {
            TzDTfTKIJBPZh = jWHVzBxq;
            jWHVzBxq = lHrgqCGv;
        }
    }

    if (karTrePnO == true) {
        for (int EtjpAIAC = 163616808; EtjpAIAC > 0; EtjpAIAC--) {
            OYmaUfyQDE = gYgwVNy;
            lHrgqCGv = TzDTfTKIJBPZh;
            TzDTfTKIJBPZh += JtVzySrF;
            jWHVzBxq = QqlvrfkFZ;
            gYgwVNy = OYmaUfyQDE;
            lHrgqCGv += JtVzySrF;
        }
    }

    if (lHrgqCGv != string("ZvVETxVdvvheXnFlbjFumAVbcbdgOcHVmawejZfGkUBZreXQldOOixoAqXjPUaWfyRddSCmOgYrvTmEBBzRIleLsqRSlQvpXygAzOUmYMCbEQiIchKQTaITwVQjYNqqnejaUFWFUSVRaMlEUMLREqGAhLXklbzXJAaXCYVYvKYShXjTLUXzXCkvQHWXNMIkKNPjKuufwmtiUAkCCTYGSXJirFqbJGCYxVnxOACENEaXjBHEyF")) {
        for (int yROFYUNgnMwh = 61464893; yROFYUNgnMwh > 0; yROFYUNgnMwh--) {
            JtVzySrF += TzDTfTKIJBPZh;
        }
    }

    return poGXUnLvvFSsC;
}

double SurrLFspTi::NLihEdJMVhbov(double FodsPJkQBBNh, bool eVAnsHRqyz, bool nrKYANFNAWcxQNkg)
{
    string nVraZgdqJV = string("nrtHCguwiAAfOkXeKwwmcUXuYNFLalNKapYQxghXFzjaBIeuaCsCdSmHrTBRkdHPnjRGGadfphkXcMlTSneujIGzbPjnNDlcokZyseREquEpd");
    bool vsqqqcVnbP = false;
    double REqjxqQXlYiHh = 241316.58378683;
    bool rcBYLFnOC = false;
    string vVWejNbckZg = string("gZQaZiZKhC");
    string IFntpZyXIZOsV = string("axZtazEvQfAGRetDfRDBixlWMmCoeTwMKPjDtPVudoAjIVFKtOihZWFXxfFJcHXxWbFVDpsEKrlO");

    for (int oDZPTrrTjedZdHyN = 1591180107; oDZPTrrTjedZdHyN > 0; oDZPTrrTjedZdHyN--) {
        IFntpZyXIZOsV = nVraZgdqJV;
        eVAnsHRqyz = rcBYLFnOC;
        eVAnsHRqyz = ! rcBYLFnOC;
        nVraZgdqJV += IFntpZyXIZOsV;
    }

    return REqjxqQXlYiHh;
}

void SurrLFspTi::DRBdXoaJxy(bool pnlpkkLdWV, double qAUddKLKrNc, double zLEEORAG, string tRkGA, int QnxDnXC)
{
    string bjhjzxdE = string("VXDhORHzKioPHpFrAEbyTfhlSrRDYIItqQmaAsNfMAOZejrNZqQYVVjiDQCkJeyPqfXVfRbeVyxmVajsmxIoskzhZSQWrrynqUNYbEECOSvXYQmZqytxDXQfvH");
    string inmGfJiqrdlD = string("IvJAxpRTHknxECQDMxTDnGLsHmReXyuGzujtXYsYFsMyVVcyBknyYzlBPBsFqkBVPvfhxWHjDrfWDqsgBHqPotSTvxCAviLCTzMvNzNRfjNRBBEV");
    double wqSJtfqjmQvv = -198441.7362612022;
    string jKptF = string("fefDKsRvEZeHAMkQPepnKZtRpZBFfYZleudxChBvzyGRPMMXJenMNzfQyYZrBFhnxaUmYLcBAjLWDwCwLAjtSiGSCKyOfpvWFiSYdrbjbJKSCCFNDyDkammlQgQjC");

    for (int dUMwYvOFHi = 1914808643; dUMwYvOFHi > 0; dUMwYvOFHi--) {
        tRkGA += inmGfJiqrdlD;
        zLEEORAG -= zLEEORAG;
    }

    for (int PfSLEzVgLAVqRT = 916413659; PfSLEzVgLAVqRT > 0; PfSLEzVgLAVqRT--) {
        wqSJtfqjmQvv /= wqSJtfqjmQvv;
        tRkGA = jKptF;
        inmGfJiqrdlD += bjhjzxdE;
        tRkGA = tRkGA;
    }
}

bool SurrLFspTi::udvtnWYxW(int BOnwydqtKDLH)
{
    bool PnBwhCMRhFiSNdw = false;
    double PsBOt = -56019.07351072759;
    int VODNHdSVA = 1778772962;

    if (VODNHdSVA >= 1778772962) {
        for (int kXrjZANkxWZK = 1662512950; kXrjZANkxWZK > 0; kXrjZANkxWZK--) {
            PnBwhCMRhFiSNdw = ! PnBwhCMRhFiSNdw;
        }
    }

    for (int rqrQLvQTxEkB = 1809894229; rqrQLvQTxEkB > 0; rqrQLvQTxEkB--) {
        VODNHdSVA += VODNHdSVA;
        VODNHdSVA *= VODNHdSVA;
        BOnwydqtKDLH = BOnwydqtKDLH;
    }

    if (VODNHdSVA > 1778772962) {
        for (int ndpoUcPOUmzD = 518464841; ndpoUcPOUmzD > 0; ndpoUcPOUmzD--) {
            BOnwydqtKDLH += BOnwydqtKDLH;
            VODNHdSVA += BOnwydqtKDLH;
        }
    }

    for (int AoiBIM = 829913096; AoiBIM > 0; AoiBIM--) {
        BOnwydqtKDLH *= VODNHdSVA;
        VODNHdSVA = VODNHdSVA;
        PnBwhCMRhFiSNdw = PnBwhCMRhFiSNdw;
        BOnwydqtKDLH += BOnwydqtKDLH;
    }

    for (int mMsJenitYRn = 1989270222; mMsJenitYRn > 0; mMsJenitYRn--) {
        VODNHdSVA /= BOnwydqtKDLH;
    }

    return PnBwhCMRhFiSNdw;
}

int SurrLFspTi::JGlOKLSJC()
{
    string WLSmwNnbJFtbInUL = string("fknzfymppfBlMwxPwIVDjctqkkviuBGXPtXYhlYYHeGwyDrNGznpOVJgGOjMKtaKUUnLedGPllyQmHRDDLwbjVIvXAdyNQMEqSOxszFXkUYKwzTwtMLjkRliplFVwLwAofzptgSDSstRGKWegBHsVARNgNagLFtLxbkmAYlHLLbJqgRZSfQddHhoghnDeuXMJWMeFlfrzUhGscdyIAmPlSrbouAGZxAmVUdAoLVDPsCGGKaPQtsqmFpam");
    string IQdZCdIN = string("oVckkbrbjIyPiHaVDNRAYoHrubxaqjYGgCYHxvVPeWWaBUVhzoEJLiBQDDcIsQaoGMIFVmMBvzcOlOYYZOFNPHnRsMDEaHHXqKcHEeBdkehZVeQOhjLqBZIqgSNMZSltJYcsIOKSwunxpFkSDllwyVMSwhMoKPuwgDrwExeGulULIUsKJDPonGRDyBUtTfDYgQmvfFIxeOmFMAIaLEMGSQjmoJaTELj");
    int uZbVpmbvw = 1068108479;
    bool RDCpEBuRnoVp = true;

    for (int psOumoULja = 255061686; psOumoULja > 0; psOumoULja--) {
        continue;
    }

    for (int hNhkVdopAajP = 587383712; hNhkVdopAajP > 0; hNhkVdopAajP--) {
        WLSmwNnbJFtbInUL += WLSmwNnbJFtbInUL;
        IQdZCdIN = IQdZCdIN;
        IQdZCdIN = IQdZCdIN;
    }

    return uZbVpmbvw;
}

double SurrLFspTi::ydWhTqLdEJNWYs(double qjBAGGyFvMXp, int QNiiMAFueLTtte, bool ccQcKsNivX, bool EeGagDynZe, bool DclvsmHDMtcL)
{
    string BfkofTVcuYe = string("pRcSuWfLTOMaSXWLESaaqZtiPHsLJKFVbkJUIjIDalkFDrQKmOfMuIlXkNQaqdoDvFnDkICgvMgCtpEsCKHwBRlHPTjhBIJcBmZqOQNJViqOrxBHSVrwXNFYjfxlWcTGfIICzYwnRFdSPylGBYTwzc");
    double MQLXDW = -4849.991563641026;
    int zonOwpnmocn = 1033888513;
    string fkqjSRCttOkjb = string("yyANewJtuAcCeDwqkEnwhwXyvGsuxNCxxVmimgfWThrOVyaaUuPjgnrgIYshtNqqVVErkuocJlDfFdhzfVdMaILTYTNxrbRwMnIcLVJNLQgVdxS");
    string UwNKC = string("HHuIBVGYBmNEpYXyfXwGKrzrOFLicrcwzWeTvIqiFTQAqMHLCzuqIgAToSRsPZCnHIbzfPkhViGnQVRGAaDByCDKVBcMKeOlWVjDmHhVtlWzaYGEIqNWBIjtolYqQbJXUnPhaWlwlemazBBRbsDpxvQLFjKuAFkTxzbueamMfPQzzPBUczixlgALzzchbcdwEqXWpZNbMaNQKtwlLkEYdUTmDCpChSADgtroXuVaiuvpnkSaCbGnwxzTgEvbihU");
    bool TDiOY = true;
    int ppClkVfsNJuKPgwV = 55870907;
    double HtBKsCQyfXc = -408285.14107630594;
    bool DEMZWIgv = false;

    for (int LuHzwehQnCuCVP = 2082425747; LuHzwehQnCuCVP > 0; LuHzwehQnCuCVP--) {
        ccQcKsNivX = ccQcKsNivX;
    }

    return HtBKsCQyfXc;
}

bool SurrLFspTi::VaZPbmalMuj(bool lerTgcHQMyBvQIZ, string JHOFtcwdxSzsq, string tlWMktGpDYoIEU, string sBozhjJ, double ADVgT)
{
    int rGuLLXg = 606183720;
    int VnLtqevzcIjYmGjY = -1679083974;
    string yGSgqUqGazT = string("qdMfcMloncTsJVxtuyTwWaCTvtqIqpneYsnIqXWTrPKreaXdpkrzLbxPmEgeXhLdDWRsUoWiENpoGkxvTbV");
    bool DKUCEniDrX = false;
    bool DfApeRLdRzltuq = false;
    double tNLFs = 7254.526516699562;
    int EHInCEnbBkluHiZm = -852650935;
    bool iggkhgoYNEeq = true;
    bool VCOofojUo = true;

    for (int BUDKDWMME = 256813203; BUDKDWMME > 0; BUDKDWMME--) {
        continue;
    }

    if (iggkhgoYNEeq == false) {
        for (int hZVOFW = 306134106; hZVOFW > 0; hZVOFW--) {
            JHOFtcwdxSzsq += sBozhjJ;
            VnLtqevzcIjYmGjY += EHInCEnbBkluHiZm;
            tlWMktGpDYoIEU += yGSgqUqGazT;
        }
    }

    if (yGSgqUqGazT < string("PjxUobZQRBuVGAlSpQkhrRTJcBtJHBfLXCOQFItEgZRqCdsHsWIWgJIUDaYVlxxhqmRxYXSxQiuPuAUCpzBSFfvbuZXPbGTlVfvvaggOfAIUwFkJkgIbLjgcFTzoiyZIkIyDrHLhqkqjgDwYUGpoDWaTfytrGdipQDycWabveyDAmmcCUksOeVHpBUNnvZLavqXQaDTlwOptWJenwmbtVIZfMqxnWZdnVPDwgYUhppgpkQXXswBONZdXV")) {
        for (int KcwuQqyTFX = 1910666684; KcwuQqyTFX > 0; KcwuQqyTFX--) {
            yGSgqUqGazT += sBozhjJ;
        }
    }

    for (int kunWYiamFewxneF = 110381723; kunWYiamFewxneF > 0; kunWYiamFewxneF--) {
        DKUCEniDrX = ! DKUCEniDrX;
        rGuLLXg -= EHInCEnbBkluHiZm;
        JHOFtcwdxSzsq += yGSgqUqGazT;
        VCOofojUo = DKUCEniDrX;
    }

    for (int wgrQYwNVVf = 1170632279; wgrQYwNVVf > 0; wgrQYwNVVf--) {
        yGSgqUqGazT = yGSgqUqGazT;
    }

    if (DKUCEniDrX != true) {
        for (int uDmmXSUPmQeQ = 250967589; uDmmXSUPmQeQ > 0; uDmmXSUPmQeQ--) {
            JHOFtcwdxSzsq += tlWMktGpDYoIEU;
        }
    }

    if (lerTgcHQMyBvQIZ == false) {
        for (int GIyaAuNscXtbYe = 332619178; GIyaAuNscXtbYe > 0; GIyaAuNscXtbYe--) {
            lerTgcHQMyBvQIZ = ! iggkhgoYNEeq;
            VCOofojUo = ! DfApeRLdRzltuq;
        }
    }

    return VCOofojUo;
}

string SurrLFspTi::gPgjpkFnbWEFOQ(int ZsFAt, bool WUmaCBeg, int GqwNgUxNTQxSsuP, bool IHAKGWYbwWi)
{
    string sBbwwUd = string("SFwHHPFHEjDgJvJVoUrljcJkudyBQIAVBhCbxmWZKeML");
    int myBEYYgQVRqEex = -1232829770;
    bool dIqCJRtjl = false;
    int lJlSLvrBfiApAme = 435816171;
    bool HBBdajhTnPmnKuNn = true;
    bool fXkEzxPwjc = false;

    for (int TemwIAr = 530295504; TemwIAr > 0; TemwIAr--) {
        WUmaCBeg = ! IHAKGWYbwWi;
        lJlSLvrBfiApAme = myBEYYgQVRqEex;
        ZsFAt /= myBEYYgQVRqEex;
    }

    if (myBEYYgQVRqEex != -1232829770) {
        for (int XDzhxDMhqHrjKhNE = 1175974534; XDzhxDMhqHrjKhNE > 0; XDzhxDMhqHrjKhNE--) {
            IHAKGWYbwWi = HBBdajhTnPmnKuNn;
            ZsFAt *= ZsFAt;
            WUmaCBeg = fXkEzxPwjc;
            myBEYYgQVRqEex /= ZsFAt;
        }
    }

    for (int VpKmOz = 1876415648; VpKmOz > 0; VpKmOz--) {
        HBBdajhTnPmnKuNn = dIqCJRtjl;
        ZsFAt /= myBEYYgQVRqEex;
        lJlSLvrBfiApAme += myBEYYgQVRqEex;
        lJlSLvrBfiApAme += lJlSLvrBfiApAme;
    }

    return sBbwwUd;
}

void SurrLFspTi::woEWQMikeM()
{
    string TkgkoCphdc = string("VCMuSyizZVHSfbUrKzvWaJYOIjYEOxugHWiTCu");
    bool CUwlgabErEG = false;
    int ZIIUlCwvTR = 424908221;
    double NyvUSum = 422310.9711159716;
    double AaOpDLmmZsr = -729663.223504364;
    double dVZkYgwWEJxPBJsE = -827022.9115803258;
    double WqLaRk = -14697.009594957759;

    if (dVZkYgwWEJxPBJsE <= -14697.009594957759) {
        for (int VKvstBITEidSpjp = 1117261559; VKvstBITEidSpjp > 0; VKvstBITEidSpjp--) {
            NyvUSum *= WqLaRk;
            dVZkYgwWEJxPBJsE *= dVZkYgwWEJxPBJsE;
            CUwlgabErEG = ! CUwlgabErEG;
            WqLaRk += NyvUSum;
        }
    }

    for (int omkiocQwhT = 654256058; omkiocQwhT > 0; omkiocQwhT--) {
        NyvUSum = AaOpDLmmZsr;
        AaOpDLmmZsr /= AaOpDLmmZsr;
        ZIIUlCwvTR *= ZIIUlCwvTR;
        CUwlgabErEG = CUwlgabErEG;
    }

    if (dVZkYgwWEJxPBJsE > -14697.009594957759) {
        for (int qkWyXazkB = 1396574234; qkWyXazkB > 0; qkWyXazkB--) {
            dVZkYgwWEJxPBJsE /= dVZkYgwWEJxPBJsE;
            TkgkoCphdc += TkgkoCphdc;
            dVZkYgwWEJxPBJsE -= WqLaRk;
            WqLaRk *= AaOpDLmmZsr;
        }
    }

    if (NyvUSum < -14697.009594957759) {
        for (int VYnijejMT = 820490010; VYnijejMT > 0; VYnijejMT--) {
            NyvUSum -= WqLaRk;
        }
    }
}

string SurrLFspTi::uSMXTIdQkKc(bool hCUlXColmEgM, bool MLYwI, string qPHJtqnXzKsErA, double qqgMSjvv, string jQMdJfdzTNrDC)
{
    string GIilg = string("sZUnhaFpBwlizteuadGLVKJmKCYOpkEhazdbwTZeZnpxiVMgmLXfnMwcSGleqMiXMkYsmcsYSDOANPFpEiIbknmGYotIhcKiYPWFqDMjNJjQbqaxtkqFCDfrXOZpzweGXqiiAQeQCWZQZWZreANUjoSxTksPYfliRVquhfEJLrLMykBHcNPbBwdpxdeOOUXCBLagDAQqgvZvhRtLFHeeYpOuWlePOLlnncVdDCphqjIejSeZMwydnT");
    string PHLclSSwjcN = string("hDewvTosKarfRwAYLUKIcOyzgVWGUtKLlAPAndeFCdumeuYMErIOiLXNIEWQAVpXHSuqAVAymaGgAoFfTkwQBOnjBrjTLbcakNyUUG");
    string ZrYBos = string("lMNDlLwypnADxXkSQioxXIOgRlqsxiLSDQBWVdGTwOarDAydqfTfDRlAuscQNzqOZDStKLVMjbnYKYgfjYoyHchsjkVDANvYtzyhEdWMyRKoFXSVKoifAXzEEQVBNfQauTzPowyvOgXmOkwjBuJOXIHlEONbOnXSL");
    int APFebpvSgZIUsPa = -1331619844;

    if (qPHJtqnXzKsErA > string("hDewvTosKarfRwAYLUKIcOyzgVWGUtKLlAPAndeFCdumeuYMErIOiLXNIEWQAVpXHSuqAVAymaGgAoFfTkwQBOnjBrjTLbcakNyUUG")) {
        for (int QUlnWUIcgncAw = 1404320252; QUlnWUIcgncAw > 0; QUlnWUIcgncAw--) {
            ZrYBos = GIilg;
            hCUlXColmEgM = ! hCUlXColmEgM;
            MLYwI = MLYwI;
        }
    }

    return ZrYBos;
}

SurrLFspTi::SurrLFspTi()
{
    this->tvCwMBd(-405590.3820274103, 574312235, 754640285);
    this->OZDdGgUtqmwttbVS(true, string("RAeyCCtXmBvmtVstdfcTPyRVSRHaXwQvMcTglivWMSTttVSERWDjtDBCmHpDmKegLcTDktgoTOHuAhFzxrtIAcjftVWKTUGkq"));
    this->TBYwHhVFPp(111240.2116913058, -648654.5307047227, string("oXZlvLjgLWiqwLgSUWWIWLGbOLURrKSWPwCYrwhHmKwzyuIXiqickWrMXgGHVLuFdEGXwuohlgJHXXZT"), 666895894);
    this->wpYmCyli(string("CgkCkymjWvVtGRNTkpamqUHDQPSDiAieKUivoNgLsbVeylE"), false, -290538156, true);
    this->NLihEdJMVhbov(782280.2993798627, true, true);
    this->DRBdXoaJxy(true, -648975.9659858721, -978031.2205973705, string("kdLOqzWAaIgPukzOKzwIBIYNjaTaUaGUsoWjtXUX"), -1454858005);
    this->udvtnWYxW(-547226714);
    this->JGlOKLSJC();
    this->ydWhTqLdEJNWYs(-127048.07205270467, -1564911702, false, false, true);
    this->VaZPbmalMuj(true, string("PjxUobZQRBuVGAlSpQkhrRTJcBtJHBfLXCOQFItEgZRqCdsHsWIWgJIUDaYVlxxhqmRxYXSxQiuPuAUCpzBSFfvbuZXPbGTlVfvvaggOfAIUwFkJkgIbLjgcFTzoiyZIkIyDrHLhqkqjgDwYUGpoDWaTfytrGdipQDycWabveyDAmmcCUksOeVHpBUNnvZLavqXQaDTlwOptWJenwmbtVIZfMqxnWZdnVPDwgYUhppgpkQXXswBONZdXV"), string("PQWPAvmONTZoendJNKjohQFWYMrbrz"), string("rEyWlBBSgJvvWDlTANVSvuSKxdObkbwCOvfQIembcQERxnKxVNYRjtCAVGqKgAJBmrEhQaJSzAJSdqXjEUVzagBLWpxMzjJQSwHkzrANbmvupTxYMwpyptFlCldcvYLSwEqfjxGzfZEXODyMgwFEBRUGMSxPOtWropghhEhXRVxfmfnwmYsuV"), -899396.1995864892);
    this->gPgjpkFnbWEFOQ(2120652740, true, -1816384523, true);
    this->woEWQMikeM();
    this->uSMXTIdQkKc(true, false, string("ikjMteelZmBMURBKbDntiBBoETABgwOnbKQuEPkiCwEeIvfspOtYEIEXkHfFfbKpnXGAmTCxurrjaKmIvFZfFlcfRLoWNWRmTrjUAznHXwMxzgseSnZfTiJCUQmVCLxfwgFDtyvTXIEKwVjkhkZFUyiMmTTihlbUCXEnPHP"), 159277.89140432488, string("lOPvifMJFhhvTtKWghMfeJpcsibAYUXRWRuumWhbkwhpOkvgbYMiGqYQYzsVEsariwWWSpaGuCdRRrxMRvdaaUBFLYednlkUtrJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class edyxdoBYhwDr
{
public:
    string YhtDWxnCpJ;
    double cyUWCskwJRUQcpx;
    int fzKMqcUtrduBsy;
    int aTbDUMp;
    string jPlKldJhCho;
    int RhjUFcO;

    edyxdoBYhwDr();
    bool AyLbmgUfzzyQC(string gahznbhiiEmlu, int HQtsHMKXnkGHHQ, bool SWGAuiSKhGBQENZR, double NMmSCGqBcV);
    double KiPRVqqg(bool rrPToRN);
protected:
    bool KHPwIDEguEMdjeJ;
    string qlyAXzmNFxvB;
    bool ONPPEhtDA;

private:
    string wChpwIpkgDDSFfyX;
    bool lvkTIBnmbgjUW;

    int DqHxkRpouQvOyfs(double IoiDaIk, string tSHZJwFfn);
    void NZQEpbUDMcJ();
    bool WHKPGmbFG(bool EMehAIexTtsrk, string pWdWKAkJFZQYopH, double AUoVqghsId);
    double pIsCftMLzdp(string pokXbY);
};

bool edyxdoBYhwDr::AyLbmgUfzzyQC(string gahznbhiiEmlu, int HQtsHMKXnkGHHQ, bool SWGAuiSKhGBQENZR, double NMmSCGqBcV)
{
    bool gUvJyZUzGU = false;
    bool UbvcR = true;
    string UddEPjQpKYPKeK = string("FpAWDnClFuOFwFPYTSRojJAxGzijzluoMGgGZLcQDcQYLfieOchAReGdpmEcEKPvsaGUrsnvEQMrgkMemv");
    double bEcJkmRUq = -483712.0356415578;
    int qXDppCHYTuBwMGB = -1631844520;
    string iUGfifgIthn = string("UoYXdPDWJKJMUaxnZiXTQmGOipOYWXBIUPVzoOsxiJLKOVHIBDkvoqvFHV");
    double enHcpldms = -417775.32809724216;
    int sEChnPlNsEix = 1126994156;
    string inrvvPQhtl = string("ZUHPWkZgNVCUpjlELgKTsCZGfFcsPOtBZIzaEOupmLOeVWssmJTjgSjcLniaqiBUeoUhFsxGVefmoXbGXhNviWgdHoESCYmBmGpVVfQOMAEtSVANsATqYYSeSmdYNzytqXmCpzboGtUQJyPcOmFzJaOOPDIUFtTUsfkKZqOoJYmoDjOonfIgIMOZQIBbwbjxMPBwHygubuzmtiTFyqxpDbRRYjkaQeEnvRbTiRThqjdkLNGI");

    if (inrvvPQhtl != string("ZUHPWkZgNVCUpjlELgKTsCZGfFcsPOtBZIzaEOupmLOeVWssmJTjgSjcLniaqiBUeoUhFsxGVefmoXbGXhNviWgdHoESCYmBmGpVVfQOMAEtSVANsATqYYSeSmdYNzytqXmCpzboGtUQJyPcOmFzJaOOPDIUFtTUsfkKZqOoJYmoDjOonfIgIMOZQIBbwbjxMPBwHygubuzmtiTFyqxpDbRRYjkaQeEnvRbTiRThqjdkLNGI")) {
        for (int yvgJifOL = 651882820; yvgJifOL > 0; yvgJifOL--) {
            bEcJkmRUq = bEcJkmRUq;
        }
    }

    for (int REQfLTvyItziUI = 1287731715; REQfLTvyItziUI > 0; REQfLTvyItziUI--) {
        SWGAuiSKhGBQENZR = ! SWGAuiSKhGBQENZR;
        gUvJyZUzGU = ! gUvJyZUzGU;
        enHcpldms -= bEcJkmRUq;
    }

    return UbvcR;
}

double edyxdoBYhwDr::KiPRVqqg(bool rrPToRN)
{
    double vYZczW = 659167.3071465958;
    int bHUhIgTmu = -1070869841;
    bool PfgqWhElGjpHV = false;
    double qqoAVCxNzlDicEH = 367265.673966025;
    bool hMlvnCLh = false;
    string ICJZUgkUkP = string("mBaKujQHBleevrASivDz");
    double ilYXSzUfuwdF = -813888.8946100537;
    int eOuWBg = 111093614;
    string IBigydGyBxk = string("iHyMKAdqxYCdaHTlXkTuK");

    for (int jAjFGpfNyFZm = 674476032; jAjFGpfNyFZm > 0; jAjFGpfNyFZm--) {
        ICJZUgkUkP += ICJZUgkUkP;
        ICJZUgkUkP = ICJZUgkUkP;
        rrPToRN = ! rrPToRN;
        vYZczW /= qqoAVCxNzlDicEH;
    }

    for (int EcsoEbIRlSmLeVN = 1710640025; EcsoEbIRlSmLeVN > 0; EcsoEbIRlSmLeVN--) {
        PfgqWhElGjpHV = ! hMlvnCLh;
        bHUhIgTmu += eOuWBg;
        vYZczW /= vYZczW;
    }

    for (int cuPWgTBewtDwZwW = 1388812398; cuPWgTBewtDwZwW > 0; cuPWgTBewtDwZwW--) {
        ilYXSzUfuwdF = vYZczW;
    }

    return ilYXSzUfuwdF;
}

int edyxdoBYhwDr::DqHxkRpouQvOyfs(double IoiDaIk, string tSHZJwFfn)
{
    string XhUSQjZ = string("WjqfbAeSvdFqoLnqClMMbaYgXMYTBTYdQeXQTYamoURzOjFKye");
    bool GHQyBGsys = true;
    double LBxpwpVtHFu = -352324.0513194897;

    return -1605068114;
}

void edyxdoBYhwDr::NZQEpbUDMcJ()
{
    int wbScWoJzRJNBtegM = -1999204680;
}

bool edyxdoBYhwDr::WHKPGmbFG(bool EMehAIexTtsrk, string pWdWKAkJFZQYopH, double AUoVqghsId)
{
    bool CDwuidUIFwdZZor = false;
    string IUlDTpOOAwmPgnOn = string("DnnmvVUXbEXRiiuYkSmQtDjytQxmaxHHYhIvqGZldKhMrIiqIWHlbaGvGKpzNqHuoqrRUGqNdhwaWZODFDokcxNIzroiEZt");
    int MeYaWwuvn = 1707806046;
    int fTlSPdeZgRgWQnk = -1609409420;
    bool xsyYblear = true;
    int aLZAjYHQwKRss = 204929763;
    int FpiRuYpqiUDRKpsJ = -781781314;
    int oSkMvQQDNdm = -779014964;
    double AihVBqTG = 46591.11161527403;

    if (CDwuidUIFwdZZor == false) {
        for (int XNGSv = 219503896; XNGSv > 0; XNGSv--) {
            AihVBqTG += AihVBqTG;
            FpiRuYpqiUDRKpsJ -= FpiRuYpqiUDRKpsJ;
        }
    }

    for (int WwUtgqTKXNbADwTC = 311123163; WwUtgqTKXNbADwTC > 0; WwUtgqTKXNbADwTC--) {
        continue;
    }

    for (int FMvSEIP = 1587198674; FMvSEIP > 0; FMvSEIP--) {
        EMehAIexTtsrk = ! xsyYblear;
        fTlSPdeZgRgWQnk /= aLZAjYHQwKRss;
        xsyYblear = CDwuidUIFwdZZor;
        EMehAIexTtsrk = ! EMehAIexTtsrk;
    }

    for (int aiGbDGDVWxvEdf = 68088535; aiGbDGDVWxvEdf > 0; aiGbDGDVWxvEdf--) {
        aLZAjYHQwKRss += FpiRuYpqiUDRKpsJ;
    }

    return xsyYblear;
}

double edyxdoBYhwDr::pIsCftMLzdp(string pokXbY)
{
    int WKRbaQzsZXlT = 1474470533;
    bool lOCYtdGqoECw = false;
    double auctCemex = -495699.38745211787;
    string caIlFyG = string("uuMQdfVtcoiDAldjZpdFOLJegsxTBEdHpEdiZuGHMnIdyYznkUnsaQdiejoLNwWiXXEgWxhtydIPFzIRnunrLEnRdELABAbxsEBMqxiAymwPCLNQfeTiQyiXiJcPAnLqvWmKkDNFBkyAidLsdbxTJYPfvItqtRIxegOsvpEeBKWRGVCIQgyHFWJkNYYQEBjTrwUpeglZZIyJGvOJGGDvtrAyyLoscwiWH");

    for (int XXHJr = 1652184966; XXHJr > 0; XXHJr--) {
        continue;
    }

    return auctCemex;
}

edyxdoBYhwDr::edyxdoBYhwDr()
{
    this->AyLbmgUfzzyQC(string("ElLXuQFkHzAaazdqWfRtbiJmoQjCmSHXMAczTBOoETcAfZRWN"), -1838523482, false, -813219.0518048044);
    this->KiPRVqqg(false);
    this->DqHxkRpouQvOyfs(831756.0525192183, string("OGICeLABtYQQbpCuSAeOYpaxwFdrlCKbabAmBaygRWHuHnwVFkLVlNgJaJNXLUjPyPkVxqcZmfzVSoNRLwZzedAaXcDCveVmRjMCfDmULoiMExxxJgpopkYALqXDjkOGJNuNllpmqDlNHSfCWzgnYXStSdHwdThaoCubQmoUXABTALAOWtEQwvwOjCSQOQnDSNDUCAgXALC"));
    this->NZQEpbUDMcJ();
    this->WHKPGmbFG(false, string("HYMqhqbbvIRnyjFPC"), 544532.1283246753);
    this->pIsCftMLzdp(string("jmoVdnSBihKjENxuNHcUQdwsKmdUVPBnMKvYglXSkJTChVwjIexYhUZAHNZNMnRuEnLJtFvmNWjTXbJDHStnDPQzZNnyqHhzJCSfCFRaQFVmRniUAlmmoTotOmImwhHFk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NrqNELgcLXFUnQAC
{
public:
    string GjPRYDTEPFHApRE;
    int mYQddMhnjCy;

    NrqNELgcLXFUnQAC();
protected:
    double IwJwhXkxxkkHhzb;
    string allsU;
    double YDGDXKrgx;
    double xPWCxPvWw;

private:
    double RpsPSjV;
    string uNzqjBLKsdwHewFk;
    bool DEJjOAwGxoGO;

    double ZSblvxMuD(double EdgEALXgFNmNLyGn);
    int QwjVZ();
    void kdFMybq(bool IwGHOeIEEaVdrZ);
    void kVUiyg(int gXXbofxVRFEOo, int IdTNVNeKjPeSdO);
    string jVRPwdjE(int cLvGVOggXdDQIaxy, double DbKNTwX, bool IBcZnBp, string XkxVkfhBa, bool cZimXsvDMPKDol);
    bool ROfeFt(string FUzbCmpVxraZ, int hkprgdZ, int sslrWRtwMJXUrc, double TYfigPjKgGKXKJN, int uhLwLDVP);
};

double NrqNELgcLXFUnQAC::ZSblvxMuD(double EdgEALXgFNmNLyGn)
{
    int xrKzEwld = 168334643;
    string lmqSRhvCWruqf = string("CrpQnHQBdFyqIUPmsgQLGaKBWgFIFhINAMHlGtMSHOBZXMlTaIqBlFHuPquYKLGENvacgTPcBOfmVyLtIxZueobjMLKGWkgtgFBGgDvSPrMMAkMjlKlNWqybgXXltpqEiqJTJYjiCeneNOglkGDeusNeELQRAgybMwhVrDoQVUIUJPfrf");

    for (int bzQKkQzioTiLTB = 254109931; bzQKkQzioTiLTB > 0; bzQKkQzioTiLTB--) {
        continue;
    }

    if (xrKzEwld > 168334643) {
        for (int sulTecTnV = 526627810; sulTecTnV > 0; sulTecTnV--) {
            lmqSRhvCWruqf = lmqSRhvCWruqf;
            EdgEALXgFNmNLyGn = EdgEALXgFNmNLyGn;
            lmqSRhvCWruqf = lmqSRhvCWruqf;
            xrKzEwld -= xrKzEwld;
        }
    }

    if (xrKzEwld <= 168334643) {
        for (int ZcPjxBnFVzqutyt = 1213294; ZcPjxBnFVzqutyt > 0; ZcPjxBnFVzqutyt--) {
            lmqSRhvCWruqf = lmqSRhvCWruqf;
            xrKzEwld += xrKzEwld;
            EdgEALXgFNmNLyGn -= EdgEALXgFNmNLyGn;
        }
    }

    for (int kphiSPTqA = 817897432; kphiSPTqA > 0; kphiSPTqA--) {
        xrKzEwld = xrKzEwld;
        xrKzEwld *= xrKzEwld;
        lmqSRhvCWruqf = lmqSRhvCWruqf;
        xrKzEwld -= xrKzEwld;
    }

    for (int cZejexeByQwT = 1792641380; cZejexeByQwT > 0; cZejexeByQwT--) {
        xrKzEwld /= xrKzEwld;
        EdgEALXgFNmNLyGn /= EdgEALXgFNmNLyGn;
        lmqSRhvCWruqf += lmqSRhvCWruqf;
    }

    return EdgEALXgFNmNLyGn;
}

int NrqNELgcLXFUnQAC::QwjVZ()
{
    double XFyUXp = 720314.3786328407;
    string ZmeGvyay = string("kxPJrwWCBTTrEjiBZQbdpIHehimnDyPWTysEXtEcyNYyPYYjaanFSXzfNsMMlfYNXNdHs");
    int LPfXv = -1073079210;
    bool ujXOaUvgNKBVYI = true;
    string XhVMrJba = string("AENkxSZTUKauQqfHRIKpLvWKlbvnmwEDRsImSXsYeLszmwvvMTzIEMJzMqtoaPNNjcBDzHPJIxMmfiICrSCSUbRXVyyittyvPOGeLFtOMBDSFCpgzsexgKReUPUSvKcNTpBDvJwZgtBpeRCULiwpB");
    bool BasbjsKdnaen = true;
    string mhjMSt = string("QbgEBTJXcLOCCqgOFZSMtogCNXuHmcvutgZRNhOUiQAcPaesuljRWsJEcNEImAtueVMtfxrfBdQHJUwdQMZFPeTAsgFuARmJSZIVJvWZlDiVpXSVtYTrivEJQXnOfRktzNIgdWkekERb");
    bool GFMKaprg = true;
    bool CYpstVtynbTuSOz = false;

    for (int oCfrg = 1452204669; oCfrg > 0; oCfrg--) {
        CYpstVtynbTuSOz = ujXOaUvgNKBVYI;
        CYpstVtynbTuSOz = GFMKaprg;
    }

    return LPfXv;
}

void NrqNELgcLXFUnQAC::kdFMybq(bool IwGHOeIEEaVdrZ)
{
    int ChHGDr = -937144592;
    int nuDJGtofihCXd = -1652082224;
    bool CUboRMTgtG = true;
    int WXJLUGoWBwVvuAS = -803880545;
    bool HLPhgkmS = false;
    string HBMgUtACUmX = string("iQNjAsjtTNbpBVOwnRohgbNvNVvNdDTFAtiBBLtRcUHzcdTGrZvtzjZXRMeVLGaiccixHTsxu");
    string PKfMkaFVKLOHoX = string("ICvGzmHcCYXdJWfyRnESCVghAVUUNuybMmuWojPJbePQHJZejMvCYtxPtpHsHnCXbqfjqRse");

    for (int AWFfWvXvR = 1234868072; AWFfWvXvR > 0; AWFfWvXvR--) {
        WXJLUGoWBwVvuAS = nuDJGtofihCXd;
        nuDJGtofihCXd *= nuDJGtofihCXd;
    }

    for (int YSzWkZSovmHld = 1212955740; YSzWkZSovmHld > 0; YSzWkZSovmHld--) {
        CUboRMTgtG = ! IwGHOeIEEaVdrZ;
    }

    if (nuDJGtofihCXd < -803880545) {
        for (int bmvriWvsticO = 204208988; bmvriWvsticO > 0; bmvriWvsticO--) {
            HBMgUtACUmX = PKfMkaFVKLOHoX;
            HLPhgkmS = CUboRMTgtG;
            PKfMkaFVKLOHoX = PKfMkaFVKLOHoX;
        }
    }

    if (PKfMkaFVKLOHoX < string("iQNjAsjtTNbpBVOwnRohgbNvNVvNdDTFAtiBBLtRcUHzcdTGrZvtzjZXRMeVLGaiccixHTsxu")) {
        for (int BmARFOEryJgsSsM = 2141874677; BmARFOEryJgsSsM > 0; BmARFOEryJgsSsM--) {
            HLPhgkmS = CUboRMTgtG;
            ChHGDr += ChHGDr;
            ChHGDr = WXJLUGoWBwVvuAS;
            ChHGDr += ChHGDr;
            nuDJGtofihCXd /= ChHGDr;
            HBMgUtACUmX += PKfMkaFVKLOHoX;
        }
    }

    for (int UxORWHSRyDNLt = 819935296; UxORWHSRyDNLt > 0; UxORWHSRyDNLt--) {
        WXJLUGoWBwVvuAS *= ChHGDr;
    }
}

void NrqNELgcLXFUnQAC::kVUiyg(int gXXbofxVRFEOo, int IdTNVNeKjPeSdO)
{
    bool ZjJgypmaAyvwQABk = false;
    double npKrDadBDDgf = -908577.4105841344;
    bool daivlGxur = true;
    bool wLdPwRVH = false;
    string gkMWxvuMDvyZbfB = string("fNESfUzMKOfOFOGcTKRyeJhcvSpPZjnBvidxPXTBQAzSCyKMAzFhjFsuNlPjSvPvAmtBwuJUniyJRuGSRBsqsoNsTPJFmKlqdHYLWWPerJBLWdVZvddSeUvPGatpTbdzIqwWAkqysywCSrsVxjlwjrfoV");

    for (int yihXgzzcXu = 194984605; yihXgzzcXu > 0; yihXgzzcXu--) {
        continue;
    }

    for (int KpLXJIwqUohJoPDV = 481708560; KpLXJIwqUohJoPDV > 0; KpLXJIwqUohJoPDV--) {
        daivlGxur = ! daivlGxur;
        wLdPwRVH = daivlGxur;
        ZjJgypmaAyvwQABk = ! ZjJgypmaAyvwQABk;
    }

    for (int NvOUncxfSy = 734909208; NvOUncxfSy > 0; NvOUncxfSy--) {
        ZjJgypmaAyvwQABk = daivlGxur;
    }

    if (gXXbofxVRFEOo < -1851784705) {
        for (int hSbQUvYHgeJab = 1911909523; hSbQUvYHgeJab > 0; hSbQUvYHgeJab--) {
            ZjJgypmaAyvwQABk = ! wLdPwRVH;
        }
    }
}

string NrqNELgcLXFUnQAC::jVRPwdjE(int cLvGVOggXdDQIaxy, double DbKNTwX, bool IBcZnBp, string XkxVkfhBa, bool cZimXsvDMPKDol)
{
    int FRGis = 428850611;
    double JVWxcQwmaRfM = 152171.26470002992;

    for (int GEvmGEIaVuOZlWK = 861167446; GEvmGEIaVuOZlWK > 0; GEvmGEIaVuOZlWK--) {
        continue;
    }

    for (int oZmrmDA = 1847548090; oZmrmDA > 0; oZmrmDA--) {
        IBcZnBp = ! IBcZnBp;
        JVWxcQwmaRfM -= JVWxcQwmaRfM;
    }

    for (int TduPZFhhD = 1138111456; TduPZFhhD > 0; TduPZFhhD--) {
        XkxVkfhBa += XkxVkfhBa;
        DbKNTwX *= JVWxcQwmaRfM;
        DbKNTwX += DbKNTwX;
    }

    for (int dqZGkuwZB = 522496239; dqZGkuwZB > 0; dqZGkuwZB--) {
        continue;
    }

    for (int EALXCZBgWBHdP = 955426961; EALXCZBgWBHdP > 0; EALXCZBgWBHdP--) {
        continue;
    }

    if (FRGis != -1474540769) {
        for (int sFtTRYLPWm = 1889528524; sFtTRYLPWm > 0; sFtTRYLPWm--) {
            continue;
        }
    }

    return XkxVkfhBa;
}

bool NrqNELgcLXFUnQAC::ROfeFt(string FUzbCmpVxraZ, int hkprgdZ, int sslrWRtwMJXUrc, double TYfigPjKgGKXKJN, int uhLwLDVP)
{
    bool AQOGOQSiO = true;
    string jGbWlwneWhM = string("osaptWByoPygiNwvHKNACHDsjbzfwevp");
    double mkwSYS = -159411.576160315;
    bool Xoxtp = true;
    double yIKMhEZqMYwf = -604247.4954250343;

    for (int oYxpItNdnos = 935038389; oYxpItNdnos > 0; oYxpItNdnos--) {
        uhLwLDVP /= sslrWRtwMJXUrc;
    }

    return Xoxtp;
}

NrqNELgcLXFUnQAC::NrqNELgcLXFUnQAC()
{
    this->ZSblvxMuD(-406842.2808683345);
    this->QwjVZ();
    this->kdFMybq(true);
    this->kVUiyg(-1851784705, -1499723716);
    this->jVRPwdjE(-1474540769, -1033797.2487005515, false, string("vdFyKQrJvIJcqxEVviryxxXVriVmQeIBxMAYBwlgsmYJfORNRNUmKvSBNUtMW"), false);
    this->ROfeFt(string("EIOHyJeuvWZQPXWUV"), 725404937, 1246790250, -709626.793169359, 740796402);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AUkUXTIabj
{
public:
    bool GHFsfSFUst;
    double RBRGyWlTTwK;
    bool CNxAj;
    bool ZsnLO;

    AUkUXTIabj();
    int MIHHP(bool IaPpYY, bool tWIxVnGEkWHlA);
    void ccVnbiX(bool NTCaUlrhiUBB);
    string QFIjmwAaYLzF(string kyYJSMkQFKKL, bool KDyHkOnyUGEsuX);
    int PjETtKxt(string PumRaL, string BttcyoEuXYJfRwD, double NGgmhTX);
    double cWaPUmk(string HOpBkAvWflWsXYoV, string RPrjEVcsfsxTFv, double ffPzulvAY);
protected:
    int bQVFF;
    bool BQDiuEa;
    double ozmrQBMVW;
    string QTISXxGEhMXAIhoY;
    double STaSHVHwi;

    double WoLuD();
    int avPhzmGWbWTkyQ(string XFgFJg, int ZcnEoKSycQc);
    void HVTuBoZXWF(int RqqqBe, int vyjuxWXXerHajIuf);
    void nebimRyTiVBpVAiZ(bool yJaZBaNuwNrEtS, int BMihlUOBSZIyE, string SKdwBjHH);
    double ncpxQjgG(string gJyGXjTMBfk, int KKGodLtZWEA, int cmaanofoJuYZv, double eXzpzj);
private:
    double GsBhyqTyD;
    int HeQUXtLDV;
    bool EMlYyP;
    double ZsFjnrHTvpOn;

    int lPXLrImwIRxSKWR();
    double IfnGLEWRYnJAd(string zRiQXaDSpOThWAZ, bool VqMQo, int nyCHKjIEXBQnNfu, string DJqoJChbwxrMPLC);
};

int AUkUXTIabj::MIHHP(bool IaPpYY, bool tWIxVnGEkWHlA)
{
    double cKvIPZw = 866036.5257687487;
    string HAjnFN = string("yQSprOaigmaBzpquIoEFeiDHDHdhOwRNlyqwzCMdpMrSGFaFaFrRSYQcPbRAGJmTZEDdawiWPqktpZQnIYVDbmVziNuYhYiZFdcjqPdYVIUeRpTttWoQVKdOGmYRslevZzLXbENiMvdLiugmGuBjrhfLZRctyEJdwuVBglUrU");
    string FPdboaZcEJNg = string("okLYpkCDrWeTcuYxRXcGJipTfXPujZvUNITnsuJEfDeYMiyEVZdKAuKxXCcJXnJwlvsKJYqBNKtMfmdITCCUDhviyEZQaHzKeflfgkRmXboYwTxSGSJMyoEBbtqCEmYKtrCQBTGGWzCnyFJoyWSSFDNEHerqFOGgwPBzNvmHWztZfDthyXInlmRKpHLlVcWBqyRtEzKmaGiCZMnapZApsbgMnBTOtoPQfeODRQROdbst");
    bool gxlhpdFkUqb = true;
    string KbCaAyJo = string("bBkVvWKBgBiTMhaJRAwCKWcDxIHPmvqPYFLetVkrwvywLOxpIlfwagOrlVvhqRVLYarImnFVVCgVuduomYicLbLkJWLXLRSpZPivfDqZvNdjPMajzxnXygojTTacloXbgkeiiHmlu");
    double QaBAMR = 689934.2334966011;
    int nOKyKbbFAcPKUdT = 718378748;
    string cdMseJcp = string("uEdUdqjIQmAkKhEGNPuInLARHXLhMTYdLIxGrwbtxMCxQDRjEMzbVulAXKemMiedNnuWkLnuermufMDxxcjooOWLCHNvRrBCnircvAgqKhmouHdAILSbESyJVedrSJaeUhHPVyAicSVOZqMUOwcHzXYwWUMeylrbDbRaxAarobhkWbvQPVBJDerfBgPOnZEcwzgkDS");
    double cohaihKGSrMGoO = -264883.59299013193;

    for (int BfoPxxZwnrlcwIWR = 812320647; BfoPxxZwnrlcwIWR > 0; BfoPxxZwnrlcwIWR--) {
        cdMseJcp += cdMseJcp;
    }

    for (int vdpeWJzEowDxDL = 2029312538; vdpeWJzEowDxDL > 0; vdpeWJzEowDxDL--) {
        QaBAMR = QaBAMR;
        IaPpYY = tWIxVnGEkWHlA;
    }

    for (int etNNZVRsFH = 905240306; etNNZVRsFH > 0; etNNZVRsFH--) {
        QaBAMR = cohaihKGSrMGoO;
        cdMseJcp = cdMseJcp;
        QaBAMR -= cKvIPZw;
        KbCaAyJo += KbCaAyJo;
    }

    if (FPdboaZcEJNg < string("uEdUdqjIQmAkKhEGNPuInLARHXLhMTYdLIxGrwbtxMCxQDRjEMzbVulAXKemMiedNnuWkLnuermufMDxxcjooOWLCHNvRrBCnircvAgqKhmouHdAILSbESyJVedrSJaeUhHPVyAicSVOZqMUOwcHzXYwWUMeylrbDbRaxAarobhkWbvQPVBJDerfBgPOnZEcwzgkDS")) {
        for (int iKUgZjMO = 1801762103; iKUgZjMO > 0; iKUgZjMO--) {
            FPdboaZcEJNg = FPdboaZcEJNg;
            cdMseJcp += KbCaAyJo;
        }
    }

    return nOKyKbbFAcPKUdT;
}

void AUkUXTIabj::ccVnbiX(bool NTCaUlrhiUBB)
{
    int vrpFSg = 2140741551;
    int fHgRfYsJM = 1595488082;
    double nNbcGM = 68596.63330665547;
    bool TwhyBTmIztSegJr = true;
    bool LrEIEWKss = true;
    int qExKk = -1577086231;

    if (TwhyBTmIztSegJr != true) {
        for (int gAMiakvYK = 380002668; gAMiakvYK > 0; gAMiakvYK--) {
            TwhyBTmIztSegJr = TwhyBTmIztSegJr;
            qExKk = fHgRfYsJM;
            NTCaUlrhiUBB = NTCaUlrhiUBB;
            nNbcGM -= nNbcGM;
        }
    }

    if (LrEIEWKss != true) {
        for (int WPgpfXIpbdrqYCWU = 365293173; WPgpfXIpbdrqYCWU > 0; WPgpfXIpbdrqYCWU--) {
            continue;
        }
    }
}

string AUkUXTIabj::QFIjmwAaYLzF(string kyYJSMkQFKKL, bool KDyHkOnyUGEsuX)
{
    int kgPOweUOhieXTlo = 1793660263;

    if (KDyHkOnyUGEsuX != false) {
        for (int FvrtUAcslYru = 2018278072; FvrtUAcslYru > 0; FvrtUAcslYru--) {
            kgPOweUOhieXTlo /= kgPOweUOhieXTlo;
            KDyHkOnyUGEsuX = ! KDyHkOnyUGEsuX;
            kgPOweUOhieXTlo += kgPOweUOhieXTlo;
            kyYJSMkQFKKL += kyYJSMkQFKKL;
            kyYJSMkQFKKL = kyYJSMkQFKKL;
        }
    }

    for (int NTkkywy = 551138408; NTkkywy > 0; NTkkywy--) {
        kyYJSMkQFKKL += kyYJSMkQFKKL;
        kgPOweUOhieXTlo *= kgPOweUOhieXTlo;
    }

    for (int MLVnUVX = 136807768; MLVnUVX > 0; MLVnUVX--) {
        continue;
    }

    for (int nsjmgXvW = 1723731772; nsjmgXvW > 0; nsjmgXvW--) {
        kyYJSMkQFKKL += kyYJSMkQFKKL;
    }

    return kyYJSMkQFKKL;
}

int AUkUXTIabj::PjETtKxt(string PumRaL, string BttcyoEuXYJfRwD, double NGgmhTX)
{
    double bkeVpfvW = 454868.69006550073;

    if (NGgmhTX == 454868.69006550073) {
        for (int stxyPLdVMl = 1876778314; stxyPLdVMl > 0; stxyPLdVMl--) {
            BttcyoEuXYJfRwD = PumRaL;
        }
    }

    if (NGgmhTX < 454868.69006550073) {
        for (int sKqhT = 298137149; sKqhT > 0; sKqhT--) {
            BttcyoEuXYJfRwD = PumRaL;
            NGgmhTX += bkeVpfvW;
            PumRaL = BttcyoEuXYJfRwD;
        }
    }

    for (int NAmTGPRtvv = 387976548; NAmTGPRtvv > 0; NAmTGPRtvv--) {
        NGgmhTX += bkeVpfvW;
        bkeVpfvW = bkeVpfvW;
        BttcyoEuXYJfRwD = PumRaL;
        NGgmhTX += bkeVpfvW;
        BttcyoEuXYJfRwD = BttcyoEuXYJfRwD;
    }

    if (BttcyoEuXYJfRwD < string("OCANEFWwntIINOKXknNjflDcBlWzzadlYOpRXCEUipUZtGbEagQxpEOOQnZZGYHNnQvEqeklRSrxatTphXWlvNYegtPhNrsRecFbXbLOqDrlDCYdYHNMbkpsnuOkCVSkcyNwMSZINVfbzmBbuceejpZMbxiAxVIkzOmWIaykKlzAPxkDmrPPR")) {
        for (int oFSoJkbPQWX = 1989900189; oFSoJkbPQWX > 0; oFSoJkbPQWX--) {
            bkeVpfvW += bkeVpfvW;
            BttcyoEuXYJfRwD += PumRaL;
        }
    }

    if (BttcyoEuXYJfRwD == string("JmCqqcDbsObkZiOTAonZnrbXGpJMQYtwkpZIMrEAgUaDPeetXntJunMwssHUpWlGkBLUwhxYssKfUAprQMOtvSzfFrBgKLgtijyEbXIfguwSiclncHYItOuTtdqeVbFYkeCDrjnPVyYNmHL")) {
        for (int kCneihqNRCGdeXg = 290373681; kCneihqNRCGdeXg > 0; kCneihqNRCGdeXg--) {
            PumRaL = BttcyoEuXYJfRwD;
            PumRaL += BttcyoEuXYJfRwD;
            NGgmhTX *= bkeVpfvW;
            BttcyoEuXYJfRwD += PumRaL;
        }
    }

    return -1436061409;
}

double AUkUXTIabj::cWaPUmk(string HOpBkAvWflWsXYoV, string RPrjEVcsfsxTFv, double ffPzulvAY)
{
    double uTUkxLQlEVTJv = -404474.41301233147;
    int elXfSdCDYg = -143067715;
    int ZXFvRumo = 1176749901;
    double xSwMuASMH = 404594.16413669573;
    bool cDIYXFibYOEQq = false;
    string pBWrs = string("fWufHGfTzDIfuvOHltzYXFZPmhEiN");
    bool YrFxRtOiZi = true;
    int ZDizmihb = -1312572753;

    if (ZXFvRumo != 1176749901) {
        for (int ZIWmupLdUgpqP = 857783678; ZIWmupLdUgpqP > 0; ZIWmupLdUgpqP--) {
            continue;
        }
    }

    for (int mlyYjIrRcrux = 1654127750; mlyYjIrRcrux > 0; mlyYjIrRcrux--) {
        continue;
    }

    for (int UsYOlLxHQZf = 692681876; UsYOlLxHQZf > 0; UsYOlLxHQZf--) {
        HOpBkAvWflWsXYoV = RPrjEVcsfsxTFv;
    }

    return xSwMuASMH;
}

double AUkUXTIabj::WoLuD()
{
    double dFCkRaTVOQaomU = -164841.99982993497;
    bool bsCPaKCeSWMR = true;
    int sYSLc = 364785255;
    string loHqg = string("EMakABCxzRfjjbNnzrbHPmkbsHmRNMMAuzNlBPgyTkelRbQOeirVEAEkRsuHGstGJxzxhEYnLEXKCECBvDwOJUxOqOQrRfYDboASHaLwKHsqrnGDPoxMAoHHHKOrdyWkirks");
    string GskomlHx = string("BPwCymWMEuAssJOMkajYDCwzsGqvZWTXkyecoKDIfZBlCdSQqcxLCLvksvbbZokSEbdUcBhgJmmRbFUrgKNAMOhZRHSDKCgFioTpgWgOGhQYYjHaTLKaVGQeiLwICzuXlUlHjKmTDBuDgZXUzsVcsuSRSqYJaRSbhhTIbSxWiuBBLjYrnuIOQMliZBHRdoQRmCSMXMRntclPZkGZxWsSHIJSOZBSmXZMQrqwRMHyuLKDUYktTXVzQICQQycgvK");
    double rMDoQWtaVV = -705847.418901417;

    for (int VBtZFcm = 219103001; VBtZFcm > 0; VBtZFcm--) {
        continue;
    }

    return rMDoQWtaVV;
}

int AUkUXTIabj::avPhzmGWbWTkyQ(string XFgFJg, int ZcnEoKSycQc)
{
    double ENkGaY = -386920.36694326106;
    bool UupZzWBiMKjaU = true;
    int EoofHxnjZalZdp = -1755776860;
    int lDNNekukezhSvAn = 290757572;
    bool yiqdA = true;
    string giVuZ = string("YGDdrcEszHwKoesMPClKWdhscbxzUNQiKLGIKglCmtjeyTOqlg");
    double pdvjVXRQiqMqVYcX = 252540.13663980167;
    string KPlBRnM = string("OuilkDEEAPlhfReCEPhRzznJfNDEPwBxcKtFwMwKnOfbKgxtvNglWzOYJIeDVRqskjdkSYjCogljQBCxbzyIhOigRkQNWhMrDvLTcauafttJXEXfBg");
    int UHktrCpImNwqSxF = 1058920500;

    for (int NepGV = 1210988575; NepGV > 0; NepGV--) {
        XFgFJg = giVuZ;
        UHktrCpImNwqSxF = EoofHxnjZalZdp;
    }

    return UHktrCpImNwqSxF;
}

void AUkUXTIabj::HVTuBoZXWF(int RqqqBe, int vyjuxWXXerHajIuf)
{
    double aaOYu = -736061.894002708;
    int VAurwXvwUFiJn = 808480699;
    string aPqvwaqvrYFTPHip = string("bYNLkyLXEmJViSitIbooUEFMqbKmdOSZShysqiLAmGGHMCVSdZDOCzhxuTgWwkdnYpXlPbceAdyuClnQZMIGUjqfuJflzCkHGskmQSLjXcEqtypmzUOZiTqJXBCdlWnYLnNB");
    bool jyOmxKbzHSrNCD = false;
    bool eWceKISNosB = true;
    double zqVWGuy = -85217.03290929897;
    int riwKjnoBnaOj = 1930442889;
    string OaeATmF = string("pwKjzihUDrwxVeswazdcaKBuBVnQsYLjHklVsgIbzKGyvMNvNmZwDrseTdsnnmChwuATGyMOueEmPPxvbQtbyMzeQCNPaUFRolDmQNmSgKDhDhmljdpRdEaHyvlhJxTAYfZdZTFhuWxadKovgFjtcmDIfbCZVFLPpAvQdvthiJpuvTOxSyYUQpjjHlDwFdcZXNsSZUoLyYYVsTBpGWnpBIBQNltlvRKJALcafYNmZYj");
    int hWYFpewPmgEJqXS = -647300936;

    for (int Zvqta = 376315665; Zvqta > 0; Zvqta--) {
        eWceKISNosB = ! jyOmxKbzHSrNCD;
    }

    if (OaeATmF >= string("bYNLkyLXEmJViSitIbooUEFMqbKmdOSZShysqiLAmGGHMCVSdZDOCzhxuTgWwkdnYpXlPbceAdyuClnQZMIGUjqfuJflzCkHGskmQSLjXcEqtypmzUOZiTqJXBCdlWnYLnNB")) {
        for (int nUpCOVKpZup = 656893544; nUpCOVKpZup > 0; nUpCOVKpZup--) {
            OaeATmF += OaeATmF;
            aaOYu /= zqVWGuy;
            hWYFpewPmgEJqXS += RqqqBe;
            vyjuxWXXerHajIuf -= riwKjnoBnaOj;
        }
    }

    for (int AmBfjNBrFjcvUDlV = 291430684; AmBfjNBrFjcvUDlV > 0; AmBfjNBrFjcvUDlV--) {
        vyjuxWXXerHajIuf += vyjuxWXXerHajIuf;
        aaOYu += aaOYu;
        riwKjnoBnaOj *= riwKjnoBnaOj;
        RqqqBe = riwKjnoBnaOj;
        VAurwXvwUFiJn /= riwKjnoBnaOj;
    }
}

void AUkUXTIabj::nebimRyTiVBpVAiZ(bool yJaZBaNuwNrEtS, int BMihlUOBSZIyE, string SKdwBjHH)
{
    int cvDtXWwF = 2083933340;
    bool puVqtELybVrfHD = false;
    int OZZxr = -1543728900;

    for (int nALKaVNNevo = 1788696157; nALKaVNNevo > 0; nALKaVNNevo--) {
        BMihlUOBSZIyE -= cvDtXWwF;
    }

    for (int oWQPOqOFOyTQnRiA = 502677906; oWQPOqOFOyTQnRiA > 0; oWQPOqOFOyTQnRiA--) {
        BMihlUOBSZIyE -= BMihlUOBSZIyE;
    }
}

double AUkUXTIabj::ncpxQjgG(string gJyGXjTMBfk, int KKGodLtZWEA, int cmaanofoJuYZv, double eXzpzj)
{
    int ciTVYr = 239642193;
    int elopyGJOzPP = 1179755540;

    for (int WLmrFQKw = 34028031; WLmrFQKw > 0; WLmrFQKw--) {
        cmaanofoJuYZv -= ciTVYr;
        elopyGJOzPP /= ciTVYr;
    }

    for (int iIPjDO = 1255487701; iIPjDO > 0; iIPjDO--) {
        KKGodLtZWEA += KKGodLtZWEA;
        cmaanofoJuYZv += ciTVYr;
        KKGodLtZWEA *= cmaanofoJuYZv;
        gJyGXjTMBfk += gJyGXjTMBfk;
        KKGodLtZWEA *= cmaanofoJuYZv;
        elopyGJOzPP -= cmaanofoJuYZv;
        ciTVYr /= elopyGJOzPP;
    }

    for (int dRJPYTV = 1201950261; dRJPYTV > 0; dRJPYTV--) {
        ciTVYr += KKGodLtZWEA;
    }

    return eXzpzj;
}

int AUkUXTIabj::lPXLrImwIRxSKWR()
{
    string fARMYucg = string("qlstucMSiavPShzsWtMiDIIHGTQQuKCYJFLbRZcOpsQvrBhzRqjluIAmPxYqYTmhUjNVyBppuHOczGkbTUJKMNHUnNzwxiZRPYdHMXPAMQbLZRocxVpkBjFaJjvsaUlLcyGDiJANLwaWzDBlOdmKKoaikdSWwYEBOmFGKgcpOewDnVuTAHdOxvqNrETfWPkXPNSYJsMhEVKFwFNpilvdWWUkuCLPiuwooAlZMJukSRo");
    string SLZTFJbqGDMvZmS = string("uKGxcysuXTGNkLKQRuqpirHbHEHKEGaTfmCXOkFGNWxRyYjhwWdWWcDoqmfMBgLGtWzJAecCcom");
    int PLAgPv = -740370022;
    bool SGjmt = false;
    string nSMdIIwMgHzeE = string("idhLCqUlbXoktdUjIrjUxQd");
    double woWrBEcuEHXRjO = 1022165.3677296375;
    int HUbxqfVFfEMqDN = -1773795402;
    double kyTIzENdsJBhqA = 233752.8429495928;

    for (int DrVnddB = 965257544; DrVnddB > 0; DrVnddB--) {
        SLZTFJbqGDMvZmS += fARMYucg;
    }

    for (int UgXjiGOKps = 590434021; UgXjiGOKps > 0; UgXjiGOKps--) {
        fARMYucg += fARMYucg;
        woWrBEcuEHXRjO *= woWrBEcuEHXRjO;
        fARMYucg = fARMYucg;
    }

    return HUbxqfVFfEMqDN;
}

double AUkUXTIabj::IfnGLEWRYnJAd(string zRiQXaDSpOThWAZ, bool VqMQo, int nyCHKjIEXBQnNfu, string DJqoJChbwxrMPLC)
{
    int IiGpfZnmUoJxQ = 2086264335;
    int BzhrYGuyJqBRfLs = 440516224;
    int IUIBInZzTsGsSkxr = -1259374120;
    double hFByVoOzZcpF = -588386.2975316276;
    int TMYMRTiWesYsBNPz = 1438324664;
    bool QkXqP = false;
    int lCMxoGFLsPubnKR = 496422512;
    double bcpwJQFfnqCfWqA = -924853.1683145466;

    for (int RVsrOPBloQIIR = 876609217; RVsrOPBloQIIR > 0; RVsrOPBloQIIR--) {
        IiGpfZnmUoJxQ -= lCMxoGFLsPubnKR;
        IiGpfZnmUoJxQ -= lCMxoGFLsPubnKR;
    }

    for (int VBQNMqqghnJIIPE = 500554195; VBQNMqqghnJIIPE > 0; VBQNMqqghnJIIPE--) {
        lCMxoGFLsPubnKR += nyCHKjIEXBQnNfu;
        IUIBInZzTsGsSkxr -= TMYMRTiWesYsBNPz;
        hFByVoOzZcpF -= bcpwJQFfnqCfWqA;
    }

    for (int PefpxrmzbwQGnDA = 625061602; PefpxrmzbwQGnDA > 0; PefpxrmzbwQGnDA--) {
        lCMxoGFLsPubnKR -= IUIBInZzTsGsSkxr;
        bcpwJQFfnqCfWqA *= bcpwJQFfnqCfWqA;
        bcpwJQFfnqCfWqA += hFByVoOzZcpF;
    }

    if (lCMxoGFLsPubnKR != 1438324664) {
        for (int ybfNLN = 761859778; ybfNLN > 0; ybfNLN--) {
            nyCHKjIEXBQnNfu /= IUIBInZzTsGsSkxr;
        }
    }

    return bcpwJQFfnqCfWqA;
}

AUkUXTIabj::AUkUXTIabj()
{
    this->MIHHP(false, false);
    this->ccVnbiX(true);
    this->QFIjmwAaYLzF(string("OseQFKvTr"), false);
    this->PjETtKxt(string("JmCqqcDbsObkZiOTAonZnrbXGpJMQYtwkpZIMrEAgUaDPeetXntJunMwssHUpWlGkBLUwhxYssKfUAprQMOtvSzfFrBgKLgtijyEbXIfguwSiclncHYItOuTtdqeVbFYkeCDrjnPVyYNmHL"), string("OCANEFWwntIINOKXknNjflDcBlWzzadlYOpRXCEUipUZtGbEagQxpEOOQnZZGYHNnQvEqeklRSrxatTphXWlvNYegtPhNrsRecFbXbLOqDrlDCYdYHNMbkpsnuOkCVSkcyNwMSZINVfbzmBbuceejpZMbxiAxVIkzOmWIaykKlzAPxkDmrPPR"), 164520.54571020536);
    this->cWaPUmk(string("ghWhSqOUaXPyWXBHicAYLe"), string("fOYXuySPtjqLmdgmqmhfYmFvDPRsbtZJocOeBFBXZKKDNMLFzcPlbMgrXUjHrbRYnmzSLxTAgcElDeRagCjzYwkXbFpiArngZMqJXckSnpRh"), 848037.0563012712);
    this->WoLuD();
    this->avPhzmGWbWTkyQ(string("qzQAywadOegmsTfQYwWInbaHLBXKgWFLehyrvybhmbglEOQxLEoREKmsGsdQWpeVXmnpkRQzRSxqFEXgDJLUelLiAVgQpURAKVVXmeNtCLPjxuVkcRcYKIeQkYRKkdUaHmqrrudaIyVHBLoUMzJANGnHGaHsJuuWSjVTgwPEZQeeOkibTwtBDvYyqokubpgMCbvn"), -1477275197);
    this->HVTuBoZXWF(805841883, -1213370750);
    this->nebimRyTiVBpVAiZ(false, 2038137641, string("FPHVIiyWzJlFmaFEvEPxUdeuiEGXFeTbVKOyqIUjHSlPPIchwAGOebxFTgDcUUTKzsuOlphQlZyYQOzczNGXdCgzhotCArYHCPzaVajYLNnOmADwMeCtjxZithJkdtZkbVxxneOJIzcQLKGBvJDDSvzbCfnbAnZnnxThtvyEeWjrAZmjSROLSUTKgCrJyLYEIKkMpOmTRUKeeKOMmYhVwQ"));
    this->ncpxQjgG(string("yKLvHrrpfwcKPFjoS"), -1714501400, 1415586902, -67338.26596032506);
    this->lPXLrImwIRxSKWR();
    this->IfnGLEWRYnJAd(string("PKFfhcpovtaiVLSLaJcwFKTyUrnOOXrXgJLENqMBXPITWpYRdPCpOeowWdvlhQEkCtZKoIMPiqmizNOSBldbTMqZNcrqUosZHEpZaIhlhSovMKdryWhJzNuxKzoizhwNDCapsQimZOXdRRPExsylkYVQnPOrQaJQGOoVEUUHasjeUQOuaUFwAZApLJuOTuKhDaoDfrMkgCKPfoQYFrkQuLaaVsAyoQYWGg"), false, 912047019, string("IqcDQpdBFMMhOgeopPkHMnSFSVCEcHZTfEORHHlswohbRuSZrtSKIPsAKiSaaiYsRMqdGfiNYroZiKpiLfsUXIsgHuMyoydJPbRYITaFkSAhinJIkAHQguZteFYWGZJTUlRxOmDvfOnkRiPWTEkXAWRTMNBag"));
}
