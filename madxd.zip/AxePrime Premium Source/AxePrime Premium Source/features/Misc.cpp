#include "Misc.h"
#include "../config.hpp"
#include "../options.hpp"
#include <string>
#include <time.h>
#include <chrono>
#include "../helpers/input.hpp"
#include "../Atakan75.hpp"

std::vector<std::string> ChatSpam =
{
	"Linear | Premium CS:GO Cheats",
	"Get Good Get Linear",
	"Get Linear Free Here www.LinearYzlm.xyz",
	"We dont get any VAC Alert cause we are using our own methods."
};


void Misc::SolEl()
{
	Atakan75Protect::prtct();

	static auto left_knife = g_CVar->FindVar("cl_righthand");

	if (!g_LocalPlayer || !g_LocalPlayer->IsAlive())
	{
		left_knife->SetValue(1);
		return;
	}

	auto weapon = g_LocalPlayer->m_hActiveWeapon();
	if (!weapon) return;

	left_knife->SetValue(!weapon->IsKnife());
}

void Misc::SohbetSpam()
{
	Atakan75Protect::prtct();

	static float nextTime = 0.f;
	float flServerTime = g_LocalPlayer->m_nTickBase() * g_GlobalVars->interval_per_tick;

	if (nextTime > flServerTime)
		return;

	nextTime = flServerTime + 0.5f;
	if (g_Options.misc_chatspam == 2)
		g_EngineClient->ClientCmd(std::string(std::string("say ") + g_Options.spam).c_str());
	else
		g_EngineClient->ClientCmd(std::string(std::string("say ") + ChatSpam[rand() % 4]).c_str());
}

void Misc::Kick(int userid)
{
	Atakan75Protect::prtct();

	char command[1024]; sprintf(command, "callvote kick %d", userid);

	g_EngineClient->ExecuteClientCmd(command);
}