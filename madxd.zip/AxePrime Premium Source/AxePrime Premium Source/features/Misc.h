#pragma once

#include "../singleton.hpp"
#include "../valve_sdk/csgostructs.hpp"
#include "../hooks.hpp"

class Misc : public Singleton<Misc>
{
public:
	void SolEl();
	void SohbetSpam();
	void Kick(int userid);
private:
	QAngle m_aimPunchAngle[128];
};

