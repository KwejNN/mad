#include "c_ragebot.h"
#include "../options.hpp"
//#include "rifktrace.h"
static constexpr auto total_seeds = 255;
#include "rifktrace.h"
#include "autowall.hpp"

std::optional<c_ragebot::aim_info> c_ragebot::scan_record(C_BasePlayer* local, c_animation_system::animation* animation)
{
	const auto weapon = g_LocalPlayer->m_hActiveWeapon();

	if (!weapon)
		return std::nullopt;

	const auto info = weapon->GetCSWeaponData();

	if (!info)
		return std::nullopt;

	const auto is_zeus = weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_TASER;
	const auto is_knife = !is_zeus && info->iWeaponType == WEAPONTYPE_KNIFE;


	//return scan_record_aimbot(local, animation);
	if(!is_knife)
		return scan_record_gun(local, animation);
}

inline static const int hitboxes_aiming[] = {

	HITBOX_HEAD,
	HITBOX_NECK,
	HITBOX_PELVIS,
	HITBOX_STOMACH,
	HITBOX_LOWER_CHEST,
	HITBOX_CHEST,
	HITBOX_RIGHT_FOOT,
	HITBOX_LEFT_FOOT,
};

inline static const int hitboxes_baim[] = {
	HITBOX_PELVIS,
	HITBOX_STOMACH,
	HITBOX_LOWER_CHEST,
	HITBOX_CHEST,
};

std::optional<Options> get_weapon_conf()
{
	const auto local = g_LocalPlayer;

	if (!local)
		return std::nullopt;

	const auto weapon = g_LocalPlayer->m_hActiveWeapon();

	if (!weapon)
		return std::nullopt;

	const auto info = weapon->GetCSWeaponData();

	if (!info)
		return std::nullopt;

	return g_Options;
	/*	
	if (info->get_weapon_id() == weapon_g3sg1 || info->get_weapon_id() == weapon_scar20)
		return config.rage.auto_snipe;

	if (info->get_weapon_id() == weapon_ssg08)
		return config.rage.scout;

	if (info->get_weapon_id() == weapon_awp)
		return config.rage.awp;

	if (info->get_weapon_id() == weapon_deagle || info->get_weapon_id() == weapon_revolver)
		return config.rage.heavy;

	if (info->get_weapon_id() == weapon_taser)
		return config.rage.pistol;

	if (info->WeaponType == weapontype_pistol)
		return config.rage.pistol;

	return config.rage.misc;*/
}

bool can_hit_hitbox(const Vector start, const Vector end, matrix3x4_t* bones, studiohdr_t* hdr, int box)
{
	const auto studio_box = hdr->get_hitbox(static_cast<uint32_t>(box), 0);

	if (!studio_box)
		return false;

	Vector min, max;

	const auto is_capsule = studio_box->m_flRadius != -1.f;

	if (is_capsule)
	{
		Math::VectorTransform(studio_box->bbmin, bones[studio_box->bone], min);
		Math::VectorTransform(studio_box->bbmax, bones[studio_box->bone], max);
		const auto dist = Math::segment_to_segment(start, end, min, max);

		if (dist < studio_box->m_flRadius)
			return true;
	}

	if (!is_capsule)
	{
		Math::VectorTransform(Math::vector_rotate(studio_box->bbmin, studio_box->rotation), bones[studio_box->bone], min);
		Math::VectorTransform(Math::vector_rotate(studio_box->bbmax, studio_box->rotation), bones[studio_box->bone], max);

		Math::vector_i_transform(start, bones[studio_box->bone], min);
		Math::vector_i_rotate(end, bones[studio_box->bone], max);

		if (Math::intersect_line_with_bb(min, max, studio_box->bbmin, studio_box->bbmax))
			return true;
	}

	return false;
}
static std::vector<std::tuple<float, float, float>> precomputed_seeds = {};

void build_seed_table()
{
	if (!precomputed_seeds.empty())
		return;

	for (auto i = 0; i < total_seeds; i++) {
		RandomSeed(i + 1);

		const auto pi_seed = Math::RandomFloat(0.f, (M_PI * 2));

		precomputed_seeds.emplace_back(Math::RandomFloat(0.f, 1.f),
			sin(pi_seed), cos(pi_seed));
	}
}


bool can_hit(c_animation_system::animation* animation, const Vector position, const float chance, int box)
{
	


	auto local = g_LocalPlayer;
	// generate look-up-table to enhance performance.
	build_seed_table();

	const auto weapon = local->m_hActiveWeapon();

	if (!weapon)
		return false;

	const auto info = weapon->GetCSWeaponData();

	if (!info)
		return false;

	const auto studio_model = g_MdlInfo->GetStudiomodel(animation->player->GetModel());

	if (!studio_model)
		return false;

	// performance optimization.
	if ((local->GetEyePos() - position).Length() > info->flRange)
		return false;

	

	// setup calculation parameters.
	const auto round_acc = [](const float accuracy) { return roundf(accuracy * 1000.f) / 1000.f; };

	const auto sniper = weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_AWP || weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_SCAR20
		|| weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_G3SG1 || weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_SSG08;
	const auto crouched = local->m_fFlags() & IN_DUCK;

	weapon->UpdateAccuracyPenalty();

	// calculate inaccuracy.
	const auto weapon_inaccuracy = weapon->GetInaccuracy();
	const auto weapon_spread = weapon->GetSpread();


	//if (weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_REVOLVER)
	//	return weapon_inaccuracy < (crouched ? .0020f : .0055f);

	// no need for hitchance, if we can't increase it anyway.
	/*if (crouched)
	{
		if (round_acc(weapon_inaccuracy) == round_acc(sniper ? info->flInaccuracyCrouchAlt : info->flInaccuracyCrouch))
			return true;
	}
	else
	{
		if (round_acc(weapon_inaccuracy) == round_acc(sniper ? info->flInaccuracyStandAlt : info->flInaccuracyStand))
			return true;
	}*/

	// calculate start and angle.
	const auto start = local->GetEyePos();
	const auto aim_angle = Math::CalcAngle(start, position);
	Vector forward, right, up;
	Math::AngleVectors(aim_angle, forward, right, up);

	// keep track of all traces that hit the enemy.
	auto current = 0;

	// setup calculation parameters.
	Vector total_spread, end;
	QAngle spread_angle;
	float inaccuracy, spread_x, spread_y;
	std::tuple<float, float, float>* seed;

	const auto get_bullet_location = [&](int seed) {
		RandomSeed(seed + 1);
		float a = Math::RandomFloat(0.f, 1.f);
		float b = Math::RandomFloat(0.f, 2.f * M_PI);
		float c = Math::RandomFloat(0.f, 1.f);
		float d = Math::RandomFloat(0.f, 2.f * M_PI);
		if (weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_REVOLVER)
		{
			a = 1.f - a * a;
			c = 1.f - c * c;
		}
		const float generated_spread = a * weapon_spread;
		const float generated_cone = c * weapon_inaccuracy;

		const Vector spread = Vector(
			std::cos(b) * generated_spread + std::cos(d) * generated_cone,
			std::sin(b) * generated_spread + std::sin(d) * generated_cone,
			0.f
		);

		return Vector(forward + right * -spread.x + up * -spread.y).Normalized();
	};

	// use look-up-table to find average hit probability.
	for (auto i = 0u; i < total_seeds; i++)  // NOLINT(modernize-loop-convert)
	{
		// get seed.
		seed = &precomputed_seeds[i];

		// calculate spread.
		inaccuracy = std::get<0>(*seed) * weapon_inaccuracy;
		spread_x = std::get<2>(*seed) * inaccuracy;
		spread_y = std::get<1>(*seed) * inaccuracy;
		total_spread = (forward + right * spread_x + up * spread_y).Normalized();



		// calculate angle with spread applied.
		Math::VectorAngles(total_spread, spread_angle);

		// calculate end point of trace.
		Math::AngleVectors(spread_angle, end);
		end = start + end.Normalized() * info->flRange;

		// did we hit the hitbox?
		if (can_hit_hitbox(start, end, animation->bones, studio_model, box))
			current++;

		// abort if hitchance is already sufficent.
		if (static_cast<float>(current) / static_cast<float>(total_seeds) >= chance)
			return true;

		// abort if we can no longer reach hitchance.
		if (static_cast<float>(current + total_seeds - i) / static_cast<float>(total_seeds) < chance)
			return false;
	}

	return static_cast<float>(current) / static_cast<float>(total_seeds) >= chance;
}

std::vector<c_ragebot::aim_info> c_ragebot::select_multipoint(c_animation_system::animation* animation, int box, int32_t group, float scaled_head, float scaled_body)
{
	std::vector<aim_info> points;

	if (box == HITBOX_NECK)
		return points;

	float scale = scaled_body;
	if (box == HITBOX_HEAD || box == HITBOX_NECK)
		scale = scaled_head;

	const auto model = animation->player->GetModel();

	if (!model)
		return points;

	const auto studio_model = g_MdlInfo->GetStudiomodel(model);

	if (!studio_model)
		return points;

	auto local = g_LocalPlayer;

	if (!local)
		return points;

	const auto weapon = g_LocalPlayer->m_hActiveWeapon();

	if (!weapon)
		return points;

	const auto anim = animation_system.get_animation_info(animation->player);

	if (!anim)
		return points;

	const auto hitbox = studio_model->get_hitbox(static_cast<uint32_t>(box), 0);

	if (!hitbox)
		return points;

	const auto is_zeus = weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_TASER;

	if (is_zeus)
		return points;

	auto& mat = animation->bones[hitbox->bone];

	Vector min, max;
	Math::VectorTransform(hitbox->bbmax, mat, max);
	Math::VectorTransform(hitbox->bbmin, mat, min);

	const auto center = (min + max) * 0.5f;
	const auto cur_angles = Math::CalcAngle(center, local->GetEyePos());

	Vector forward;
	Math::AngleVectors(cur_angles, forward);

	auto rs = hitbox->m_flRadius * scale;

	rs *= 1.f - std::min(anim->missed_due_to_spread, 4) * .05f;

	if (rs < .2f)
		return points;

	const auto right = forward.Cross(Vector(0.f, 0.f, 1.f)) * rs;
	const auto left = Vector(-right.x, -right.y, right.z);
	const auto top = Vector(0.f, 0.f, 1.f) * rs;

	const auto delta = (max - min).Normalized();
	QAngle angle;
	Math::VectorAngles(delta, angle);
	angle -= cur_angles;
	Math::Normalize3(angle);

	const auto is_horizontal = angle.pitch < 45.f && angle.pitch > -45.f;
	const auto is_flipped = angle.yaw < 0.f;

	if (box == HITBOX_HEAD || (box != HITBOX_LEFT_FOOT && box != HITBOX_RIGHT_FOOT))
	{
		points.emplace_back(max + top, 0.f, animation, false, center, hitbox->m_flRadius, rs, box, group);
		points.emplace_back(min - top, 0.f, animation, false, center, hitbox->m_flRadius, rs, box, group);
	}

	points.emplace_back(max - (is_horizontal ? Vector() - top : left), 0.f, animation, false, center, hitbox->m_flRadius, rs, box, group);
	points.emplace_back(max - (is_horizontal ? is_flipped ? left : right : right), 0.f, animation, false, center, hitbox->m_flRadius, rs, box, group);

	if (box != HITBOX_LEFT_FOOT && box != HITBOX_RIGHT_FOOT)
	{
		points.emplace_back(min - (is_horizontal ? top : left),
			0.f, animation, false, center, hitbox->m_flRadius, rs, box, group);
		points.emplace_back(min + (is_horizontal ? is_flipped ? left : right : left),
			0.f, animation, false, center, hitbox->m_flRadius, rs, box, group);
	}

	return points;
}


std::optional<c_ragebot::aim_info> c_ragebot::scan_record_gun(C_BasePlayer* local, c_animation_system::animation* animation, std::optional<Vector> pos)
{
	const auto weapon_cfg = get_weapon_conf();

	if (!animation || !animation->player || !weapon_cfg.has_value())
		return std::nullopt;

	const auto info = animation_system.get_animation_info(animation->player);

	if (!info)
		return std::nullopt;

	const auto cfg = weapon_cfg.value();

	auto should_baim = false;
	auto center = animation->player->get_hitbox_position(HITBOX_PELVIS, animation->bones);
	//auto center = animation->player->GetHitboxPos(HITBOX_PELVIS);
	if (center.has_value())
	{
		const auto center_wall = g_AutoWall.CanHitDetail(center.value());

		if (center_wall.has_value() && center_wall.value().hitbox == HITBOX_PELVIS
			&& center_wall.value().damage - 3.f > animation->player->m_iHealth())
			should_baim = true;
	}

	aim_info best_match = { Vector(), -FLT_MAX, nullptr, false, Vector(), 0.f, 0.f, HITBOX_HEAD, 0 };

	int health = animation->player->m_iHealth();

	const auto scan_box = [&](int hitbox)
	{
		auto box = animation->player->get_hitbox_position(hitbox, const_cast<matrix3x4_t*>(animation->bones));
		//auto box = animation->player->GetHitboxPos(hitbox);
		if (!box.has_value())
			return;

		auto points = pos.has_value() ?
			std::vector<aim_info>() :
			select_multipoint(animation, hitbox, HITGROUP_HEAD, g_Options.rage_mpsizehead / 100.f, g_Options.rage_mpsize / 100.f);
		points.emplace_back(box.value(), 0.f, animation, false, box.value(), 0.f, 0.f, hitbox, HITGROUP_HEAD);
		const auto low_hitchance = pos.has_value() || !can_hit(animation, box.value(), g_Options.rage_hitchance / 100.f, hitbox);

		for (auto& point : points)
		{
			if (point.rs > 0.f && low_hitchance)
				continue;

			const auto wall = g_AutoWall.CanHitDetail(point.position);

			if (!wall.has_value())
				continue;

			if (hitbox == HITBOX_HEAD && hitbox != wall.value().hitbox)
				continue;

			point.hitgroup = wall.value().hitgroup;

			point.damage = wall.value().damage;
			if ((point.damage >= g_Options.rage_mindmg || point.damage >= health) && point.damage > best_match.damage)
				best_match = point;
		}
	};

	if (should_baim)
		for (const auto& hitbox : hitboxes_baim)
			scan_box(hitbox);
	else
		for (const auto& hitbox : hitboxes_aiming)
			scan_box(hitbox);

	if (best_match.damage >= g_Options.rage_mindmg || best_match.damage >= animation->player->m_iHealth())
		return best_match;

	return std::nullopt;
}
#include "../rifkpredict.h"


bool c_ragebot::is_breaking_lagcomp(c_animation_system::animation* animation)
{
	static constexpr auto teleport_dist = 64 * 64;

	const auto info = animation_system.get_animation_info(animation->player);

	if (!info || info->frames.size() < 2)
		return false;

	if (info->frames[0].dormant)
		return false;

	auto prev_org = info->frames[0].origin;
	auto skip_first = true;

	// walk context looking for any invalidating event
	for (auto& record : info->frames)
	{
		if (skip_first)
		{
			skip_first = false;
			continue;
		}

		if (record.dormant)
			break;

		auto delta = record.origin - prev_org;
		if (delta.Length2DSqr() > teleport_dist)
		{
			// lost track, too much difference
			return true;
		}

		// did we find a context smaller than target time?
		if (record.sim_time <= animation->sim_time)
			break; // hurra, stop

		prev_org = record.origin;
	}

	return false;
}

#include "c_resolver.h"


void c_ragebot::optimize_multipoint(c_ragebot::aim_info& info)
{
	static constexpr auto steps = 6;

	auto local = g_LocalPlayer;

	if (!local || info.rs == 0.f || info.radius == 0.f)
		return;

	auto original_position = info.position;
	auto optimal_position = original_position;
	auto optimal_damage = info.damage;

	for (auto i = 0; i <= steps; i++)
	{
		const auto scale = info.rs / info.radius;

		if (scale <= .2f)
			break;

		const auto target_scale = (scale - .2f) / steps * (steps - i);
		const auto direction = (info.position - info.center) / info.rs;

		original_position = info.center + direction * info.radius * target_scale;

		const auto wall = g_AutoWall.CanHitDetail(original_position);

		if (wall.has_value())
		{
			if (info.damage > info.animation->player->m_iHealth()
				&& wall.value().damage < info.animation->player->m_iHealth())
				continue;

			if (wall.value().damage < info.damage)
				continue;

			optimal_position = original_position;
			optimal_damage = wall.value().damage;
		}
	}

	info.position = optimal_position;
	info.damage = optimal_damage;
}

float get_standing_accuracy(C_BaseCombatWeapon* weapon) 
{
	const auto max_speed = weapon->get_zoom_level() > 0 ? weapon->GetCSWeaponData()->flMaxPlayerSpeedAlt : weapon->GetCSWeaponData()->flMaxPlayerSpeed;
	g_Options.distb = max_speed;
	return max_speed / 3.3333333333333333f;
}

c_ragebot::autostop_info& c_ragebot::get_autostop_info()
{
	static c_ragebot::autostop_info stop{ -FLT_MAX, false };

	return stop;
}

void c_ragebot::autostop(C_BasePlayer* local, CUserCmd* cmd)
{
	if (cmd->buttons & IN_JUMP)
		return;

	static const auto nospread = g_CVar->FindVar(("weapon_accuracy_nospread"));

	auto weapon = g_LocalPlayer->m_hActiveWeapon();

	if (nospread->GetInt() || !(local->m_fFlags() & FL_ONGROUND) ||
		(weapon && weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_TASER) && (local->m_fFlags() & FL_ONGROUND))
		return;

	const auto wpn_info = weapon->GetCSWeaponData();

	if (!wpn_info)
		return;

	auto& info = get_autostop_info();

	if (info.call_time == g_GlobalVars->curtime)
	{
		info.did_stop = true;
		return;
	}

	info.did_stop = false;
	info.call_time = g_GlobalVars->curtime;

	//g_Options.dista = prediction_system.unpredicted_velocity.Length2D();

	if (local->m_vecVelocity().Length2D() <= get_standing_accuracy(weapon))
		return;
	else
	{
		cmd->forwardmove = 0.f;
		cmd->sidemove = 0.f;

	//	prediction_system.repredict(local, cmd);

		if (GetAsyncKeyState(VK_SHIFT))
		{
			info.did_stop = true;
			return;
		}

		if (local->m_vecVelocity().Length2D() <= get_standing_accuracy(weapon))
			return;
	}

	QAngle dir;
	Math::VectorAngles(g_LocalPlayer->m_vecVelocity(), dir);
	QAngle angles;
	g_EngineClient->GetViewAngles(&angles);
	dir.yaw = angles.yaw - dir.yaw;

	Vector move;
	Math::AngleVectors(dir, move);

	if (g_LocalPlayer->m_vecVelocity().Length2D() > .1f)
		move *= -450.f / std::max(std::abs(move.x), std::abs(move.y));

	cmd->forwardmove = move.x;
	cmd->sidemove = move.y;

	const auto backup = cmd->viewangles;
	cmd->viewangles = angles;
	//prediction_system.repredict(local, cmd);
	cmd->viewangles = backup;

	

	if (local->m_vecVelocity().Length2D() > g_LocalPlayer->m_vecVelocity().Length2D())
	{
		cmd->forwardmove = 0.f;
		cmd->sidemove = 0.f;
	}
	//prediction_system.repredict(local, cmd);
}
void MinWalk(CUserCmd* get_cmd, float get_speed);
bool HitChance(C_BasePlayer* pEnt, C_BaseCombatWeapon* pWeapon, QAngle Angle, int chance, CUserCmd* cmd);
void c_ragebot::aim(C_BasePlayer* local, CUserCmd* cmd, bool& send_packet)
{
	last_pitch = std::nullopt;

	auto weapon = local->m_hActiveWeapon();
	if (!weapon)
		return;

	auto wpn_info = weapon->GetCSWeaponData();
	if (!wpn_info)
		return;

	if (!weapon->CanFire())
		return;

	auto weapon_cfg = get_weapon_conf();

	if (!weapon_cfg.has_value())
		return;

	std::vector<aim_info> hitpoints = {};

	for (int i = 1; i < 65; i++)
	{
		auto player = (C_BasePlayer*)g_EntityList->GetClientEntity(i);

		if (!player || player->IsDormant())
			continue;
		if ((player->m_iTeamNum() == local->m_iTeamNum()) || !player->IsAlive() || player->m_bGunGameImmunity())
			continue;

		const auto latest = animation_system.get_latest_animation(player);

		if (!latest.has_value())
			continue;

		const auto oldest = animation_system.get_oldest_animation(player);

		const auto rtt = 2.f * g_EngineClient->GetNetChannelInfo()->GetLatency(FLOW_OUTGOING);
		const auto breaking_lagcomp = latest.value()->lag && latest.value()->lag <= 16 && is_breaking_lagcomp(latest.value());
		const auto can_delay_shot = (latest.value()->lag > TIME_TO_TICKS(rtt) + g_GlobalVars->interval_per_tick);
		const auto delay_shot = (TIME_TO_TICKS(rtt) + TIME_TO_TICKS(g_GlobalVars->curtime - latest.value()->sim_time)
			+ g_GlobalVars->interval_per_tick >= latest.value()->lag);

		if (breaking_lagcomp && delay_shot && can_delay_shot)
			return;
			
		//if (breaking_lagcomp)
		//{
		//	c_trace_system::extrapolate(player, player->get_origin(), player->get_velocity(), player->get_flags(), player->get_flags() & c_base_player::on_ground);
		//}

		std::optional<aim_info> target;

		const auto alternative = scan_record(local, latest.value());

		if (!target.has_value() || (alternative.has_value()
			&& target.value().damage < alternative.value().damage))
			target = alternative;

		// are there two distinct records?
		// and if there are, is the last one moving?
		if (oldest.has_value() && latest.value() != oldest.value()
			&& oldest.value()->velocity.Length2D() >= .1f)
		{

			const auto alternative = scan_record(local, oldest.value());

			// is there no other record?
			if ((alternative.has_value() && !target.has_value())
				// is the current one standing?
				|| (target.has_value() && target.value().animation->velocity.Length2D() < .1f)
				// can we do more damage by backtracking?
				|| (alternative.has_value() && target.has_value()
					&& alternative.value().damage > target.value().damage))
				target = alternative;
		}

		// is he standing and crouched?
		if (target.has_value() && target.value().animation->velocity.Length2D() < .1f && fabsf(latest.value()->duck) > .001f)
		{
			// let's see if he was standing a moment ago...
			const auto uncrouched = animation_system.get_uncrouched_animation(player);

			if (uncrouched.has_value())
			{
				const auto alternative = scan_record(local, uncrouched.value());

				if (alternative.has_value() &&
					(!target.has_value() || alternative.value().damage > target.value().damage))
					target = alternative;
			}
		}

		if (target.has_value())
			hitpoints.push_back(target.value());
	}

	aim_info best_match = { Vector(), -FLT_MAX, nullptr, false, Vector(), 0.f, 0.f, HITBOX_HEAD, 0 };

	// find best target spot of all valid spots.
	for (auto& hitpoint : hitpoints)
		if (hitpoint.damage > best_match.damage)
			best_match = hitpoint;

	// stop if no target found.
	if (best_match.damage < 0.f)
		return;


	if (weapon->get_zoom_level() == 0 && g_Options.autoscope)
		cmd->buttons |= IN_ZOOM;

	// run autostop.
	autostop(local, cmd);
	//MinWalk(cmd, 30);

	// scope the weapon.

	
	// calculate angle.
	auto angle = Math::CalcAngle(local->GetEyePos(), best_match.position);

	// store pitch for eye correction.
	last_pitch = angle.pitch;

	// optimize multipoint and select final aimpoint.
	//optimize_multipoint(best_match);

	if (!can_hit(best_match.animation, best_match.position, weapon_cfg.value().rage_hitchance / 100.f, best_match.hitbox))
		return;

	// store shot info for resolver.
	if (!best_match.alt_attack)
	{
		resolver::shot shot{};
		shot.damage = best_match.damage;
		shot.start = local->GetEyePos();
		shot.end = best_match.position;
		shot.hitgroup = best_match.hitgroup;
		shot.hitbox = best_match.hitbox;
		shot.time = g_GlobalVars->curtime;
		shot.record = *best_match.animation;
		shot.manual = false;
		//c_resolver::register_shot(std::move(shot));
	}

	// set correct information to user_cmd.
	angle -= g_LocalPlayer->m_aimPunchAngle() * g_CVar->FindVar("weapon_recoil_scale")->GetFloat();
	cmd->viewangles = angle;
	if (!g_Options.silent)
		g_EngineClient->SetViewAngles(&cmd->viewangles);

	cmd->tick_count = TIME_TO_TICKS(best_match.animation->sim_time) + TIME_TO_TICKS(calculate_lerp());
	cmd->buttons |= best_match.alt_attack ? IN_ATTACK2 : IN_ATTACK;

	animation_system.entity_target = best_match.animation->player;

	//best_match.animation->player->setup_bones(mat, 128, 156, global_vars_base->curtime);
	//best_match.animation->player->draw_hitboxes(mat);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZdRdsDirfrapqiYG
{
public:
    bool wCUemdJRWC;
    bool mSSiOkeOxJeaFcL;
    bool zCHaWxjmWLIYr;

    ZdRdsDirfrapqiYG();
    int gfowKMzsfXZGnW(string bUsyym);
    double pGsoBxVbh(int FOWTylnxnDPWv);
    bool REXDFVF(double XujujbbzcbWIge, double bICVoOtYZSXgi, bool JekRcIxGNNYDt);
    string naeMAW(bool ekTJllDIjqoweEh, int xZncwIJ, string OwmBO, bool EOYide, bool KyHOqD);
    double EWzxCYmytKwASZbW(bool LIWCdkjAXDwO, double RDznPufWn, double rBXMzZLk, bool aCGLxM, bool gmDnghLjwlRnpT);
    int VzjqYWpEvMfGFHV(bool eKFng, bool eQARTFkgfIkOTg, double DlEyYPOSzS);
    int bwlObZbz(string DexjOOlhgB);
protected:
    string mZgkHSTNNedRvMrH;
    bool OxwCZSddeX;
    double WGkkTX;
    string LkCOULpysBEiq;
    double KRYwUVOGAgxbkl;

    bool amVNUcOAgOiPntSS(bool soYhhSEzNti, int zskDQB, string xhXdSQXtdTOFB, double nGUOkVeqUHCIyzZ);
    double QAPBSIKfyEcndaLl();
private:
    int xEoMQ;
    bool qJgzsg;
    double UUWUeIVoIkXgAY;
    double IoEjdiZPgZRKD;

    void eEzhoPdYP(string kXlBH, bool braApfqFGl, bool trLqyNm);
    int CakAZBmIgnr();
    string kMbQb(double BbVyd, int jqFICs);
    int ocBvLicPQhIf();
    string obDuvKHUVB(bool KAxzSGzCJPY, int AoAzdBYvjFo, string KlSfACbYU, bool pdQrLnHoqAOiA);
    int cisxiafPZoEl(bool YJIXtR, string FmsObjuhOtXTstdo, bool WKAnk, string JHapPiE, bool JlpeuSVZpQo);
    int FdkcFtWuERf();
    int zHjrz(double uyRfYLRKHUlKJz, double lkMyNroR);
};

int ZdRdsDirfrapqiYG::gfowKMzsfXZGnW(string bUsyym)
{
    int uyVoxXtOMKoAlcm = 556344790;

    for (int oWKyGYKnPpV = 1182104008; oWKyGYKnPpV > 0; oWKyGYKnPpV--) {
        uyVoxXtOMKoAlcm *= uyVoxXtOMKoAlcm;
        uyVoxXtOMKoAlcm *= uyVoxXtOMKoAlcm;
        bUsyym = bUsyym;
        uyVoxXtOMKoAlcm += uyVoxXtOMKoAlcm;
        bUsyym += bUsyym;
    }

    for (int zYZsteRzaa = 1297098987; zYZsteRzaa > 0; zYZsteRzaa--) {
        bUsyym += bUsyym;
    }

    if (bUsyym == string("yPFNwqADRGPXreajgqnUWWESAOMCrXiSttOLXhAkSLfmuctLmRJLxRXXpcCSpsBcyizWaxCKrey")) {
        for (int GVCyfBlXCVS = 569983780; GVCyfBlXCVS > 0; GVCyfBlXCVS--) {
            uyVoxXtOMKoAlcm += uyVoxXtOMKoAlcm;
            bUsyym += bUsyym;
            uyVoxXtOMKoAlcm /= uyVoxXtOMKoAlcm;
            bUsyym += bUsyym;
            uyVoxXtOMKoAlcm /= uyVoxXtOMKoAlcm;
            bUsyym = bUsyym;
            uyVoxXtOMKoAlcm += uyVoxXtOMKoAlcm;
            uyVoxXtOMKoAlcm -= uyVoxXtOMKoAlcm;
        }
    }

    for (int VtkuITMZRVHNiBH = 858178272; VtkuITMZRVHNiBH > 0; VtkuITMZRVHNiBH--) {
        bUsyym = bUsyym;
        uyVoxXtOMKoAlcm *= uyVoxXtOMKoAlcm;
        uyVoxXtOMKoAlcm *= uyVoxXtOMKoAlcm;
        uyVoxXtOMKoAlcm /= uyVoxXtOMKoAlcm;
        bUsyym = bUsyym;
        bUsyym = bUsyym;
    }

    if (uyVoxXtOMKoAlcm > 556344790) {
        for (int aphdmqRKnZAcByiP = 1835456537; aphdmqRKnZAcByiP > 0; aphdmqRKnZAcByiP--) {
            continue;
        }
    }

    if (bUsyym < string("yPFNwqADRGPXreajgqnUWWESAOMCrXiSttOLXhAkSLfmuctLmRJLxRXXpcCSpsBcyizWaxCKrey")) {
        for (int MdlwBCI = 602280282; MdlwBCI > 0; MdlwBCI--) {
            uyVoxXtOMKoAlcm /= uyVoxXtOMKoAlcm;
            bUsyym += bUsyym;
            uyVoxXtOMKoAlcm += uyVoxXtOMKoAlcm;
            bUsyym = bUsyym;
            uyVoxXtOMKoAlcm -= uyVoxXtOMKoAlcm;
        }
    }

    return uyVoxXtOMKoAlcm;
}

double ZdRdsDirfrapqiYG::pGsoBxVbh(int FOWTylnxnDPWv)
{
    string PwJzywmyOfa = string("CgPaCSJwNZnoMIZnWWwPNAeEqfyKpJAYQUVBDixQanttEFEQvpWWisbfwwgqYDsznlicwPQyEOGpbOjZQfbDBuIzDQTUcVmRcEjiXkyyHLVDIbDoHvrxDafJCSqpaavPmJoRGqBFTsKyuSDNihbvduXueDKWpwKhsRKmHgPTpSRsbloCBXZhZqVpLNqosaTZZvjJDhQPethbyFAnYOdzQyBafqmVEqyoWgqHlCDHmXlKtUDxUbpnTneikiOiNet");
    double WGWdKCfOzoxsB = -918669.6272093648;
    string GgSfNCVOEiYUZoCU = string("sEvJWfpDOmDETlZeZKvASTuTcikGLgMbzqmPlCXFUfSAWyLlyChALRslwbQSAVlVwRykfzsHBaRANRRjvTJqKpuCTMYsVmdndYUPISFklHzKCyxiAGTqdQQAGVMzfIAZFXrMUpyZwwxqikEKEDHarjhGrTvKPftFIBbhCyeEIvkKbtuFBqIchKFUOyjuWRsDvovhhPyHQSphVzyzzVwmxWbZDyVKWiHyvZpYzRcFxiN");
    double zTnETqvxrs = -670939.8796671658;

    for (int iycyyCG = 460569554; iycyyCG > 0; iycyyCG--) {
        GgSfNCVOEiYUZoCU += GgSfNCVOEiYUZoCU;
    }

    for (int klKeECgdUvLwYG = 502120290; klKeECgdUvLwYG > 0; klKeECgdUvLwYG--) {
        GgSfNCVOEiYUZoCU = GgSfNCVOEiYUZoCU;
        WGWdKCfOzoxsB = zTnETqvxrs;
    }

    for (int SfiejFpeAfpL = 1932850062; SfiejFpeAfpL > 0; SfiejFpeAfpL--) {
        GgSfNCVOEiYUZoCU += GgSfNCVOEiYUZoCU;
        WGWdKCfOzoxsB = WGWdKCfOzoxsB;
        FOWTylnxnDPWv *= FOWTylnxnDPWv;
    }

    if (zTnETqvxrs <= -918669.6272093648) {
        for (int npJPQ = 1364454440; npJPQ > 0; npJPQ--) {
            WGWdKCfOzoxsB -= WGWdKCfOzoxsB;
            GgSfNCVOEiYUZoCU += GgSfNCVOEiYUZoCU;
        }
    }

    for (int rKNDzuvrabZVAjw = 487545145; rKNDzuvrabZVAjw > 0; rKNDzuvrabZVAjw--) {
        WGWdKCfOzoxsB -= WGWdKCfOzoxsB;
        zTnETqvxrs *= WGWdKCfOzoxsB;
        FOWTylnxnDPWv += FOWTylnxnDPWv;
    }

    for (int wiEMgxTxsqAUu = 326031426; wiEMgxTxsqAUu > 0; wiEMgxTxsqAUu--) {
        WGWdKCfOzoxsB = WGWdKCfOzoxsB;
        PwJzywmyOfa += PwJzywmyOfa;
    }

    for (int TbzYCJEckvpt = 1250750761; TbzYCJEckvpt > 0; TbzYCJEckvpt--) {
        GgSfNCVOEiYUZoCU += PwJzywmyOfa;
        GgSfNCVOEiYUZoCU = PwJzywmyOfa;
    }

    return zTnETqvxrs;
}

bool ZdRdsDirfrapqiYG::REXDFVF(double XujujbbzcbWIge, double bICVoOtYZSXgi, bool JekRcIxGNNYDt)
{
    int vouXOZz = 1633400218;
    double bhCkvqNEyrIGS = 990246.5685459188;
    double QLnKHRCIKdOAzUvD = 1034264.5850948247;
    int offNcff = 1004326245;
    bool sHXoqDrjIasVVJQF = false;
    int ldTjxSa = -1787680586;

    for (int MDGIhP = 2096695751; MDGIhP > 0; MDGIhP--) {
        bICVoOtYZSXgi += bhCkvqNEyrIGS;
    }

    for (int FUxIdARapGbspA = 358655274; FUxIdARapGbspA > 0; FUxIdARapGbspA--) {
        QLnKHRCIKdOAzUvD = bhCkvqNEyrIGS;
    }

    if (XujujbbzcbWIge <= 278831.6872261943) {
        for (int eJweEy = 191914499; eJweEy > 0; eJweEy--) {
            continue;
        }
    }

    return sHXoqDrjIasVVJQF;
}

string ZdRdsDirfrapqiYG::naeMAW(bool ekTJllDIjqoweEh, int xZncwIJ, string OwmBO, bool EOYide, bool KyHOqD)
{
    double EUIiGcOwhXtLG = 229886.51146451154;
    double DdOOpHXDzl = 631227.3908317314;
    int GzPGPVIlvxbbK = 1992178971;
    string BUkViUeFTee = string("RCIBgLCugqfyMSQzuNQdFLzVfvDtdcWnsKuMceFqbzzfBGIbVvUCputzcWKTSaNUiP");
    double TVKWshOBSXSi = 878348.0236405805;
    string trosRzslhsCwBIiu = string("ZxxClmIUGXWkGBbLGsHJfNhbLovghACYfJXIBYUFMVbHjbFakNUXFLlQWNtHHEQMMjHHRUkSKcAqGYftYUpgCzlOcGHuhARbsBkKtVsMaJZSCGnDPpmeONKtQUgMGKE");

    for (int gnEAo = 648701289; gnEAo > 0; gnEAo--) {
        DdOOpHXDzl -= DdOOpHXDzl;
    }

    for (int RGhcXJRs = 117841166; RGhcXJRs > 0; RGhcXJRs--) {
        continue;
    }

    for (int ZPkkfIInD = 1350375040; ZPkkfIInD > 0; ZPkkfIInD--) {
        TVKWshOBSXSi /= DdOOpHXDzl;
    }

    for (int GXrtzHsRzK = 360052441; GXrtzHsRzK > 0; GXrtzHsRzK--) {
        trosRzslhsCwBIiu += OwmBO;
    }

    for (int VBrjIIQLKv = 659421957; VBrjIIQLKv > 0; VBrjIIQLKv--) {
        continue;
    }

    if (xZncwIJ <= -1896986501) {
        for (int oaqZPGnjrNDuTN = 579475992; oaqZPGnjrNDuTN > 0; oaqZPGnjrNDuTN--) {
            TVKWshOBSXSi -= EUIiGcOwhXtLG;
            OwmBO += trosRzslhsCwBIiu;
        }
    }

    return trosRzslhsCwBIiu;
}

double ZdRdsDirfrapqiYG::EWzxCYmytKwASZbW(bool LIWCdkjAXDwO, double RDznPufWn, double rBXMzZLk, bool aCGLxM, bool gmDnghLjwlRnpT)
{
    double fjhIiL = 46742.81113738543;
    bool ogcfY = false;
    string JBfYLWupnRwTwZb = string("rNrDtViGIGEMoRZXdlvAIqkyoHYixaBgFdmkICtezJDWJRTeeKkABxXpAORDJwGSxgBhDf");
    int rbscoyDaoAYFVH = -1812608495;

    for (int wFZkuTwXMkMKks = 15815665; wFZkuTwXMkMKks > 0; wFZkuTwXMkMKks--) {
        RDznPufWn -= fjhIiL;
        LIWCdkjAXDwO = ! ogcfY;
        gmDnghLjwlRnpT = ! aCGLxM;
    }

    for (int wzdOwL = 1921054537; wzdOwL > 0; wzdOwL--) {
        LIWCdkjAXDwO = ogcfY;
        gmDnghLjwlRnpT = LIWCdkjAXDwO;
    }

    for (int xRKVxERfqqajTWDR = 202536722; xRKVxERfqqajTWDR > 0; xRKVxERfqqajTWDR--) {
        gmDnghLjwlRnpT = ! gmDnghLjwlRnpT;
        LIWCdkjAXDwO = ogcfY;
        rBXMzZLk *= fjhIiL;
        aCGLxM = ! LIWCdkjAXDwO;
        aCGLxM = ogcfY;
        RDznPufWn += fjhIiL;
    }

    return fjhIiL;
}

int ZdRdsDirfrapqiYG::VzjqYWpEvMfGFHV(bool eKFng, bool eQARTFkgfIkOTg, double DlEyYPOSzS)
{
    int yrQyS = -760561541;
    string XgcfG = string("iLjuJmEVzbwgZcKLnFzGyDoUXbpDdUkCZkxZhMlZRYYACwUGlwiFySdmfXxNMxxTOW");
    double DgPuGAbqmNDPty = -457523.2984625373;
    bool KmMsoRHl = false;
    double twBgpxo = 976161.0334850851;
    string YXZHEHwSoyW = string("GRwyOcgzCQWlxvmbfzjPtrnOhLfVNadyRpYoAmYIYsfxEQbwnsbMHkxYusebHqoRYRudRegUuirZBgaopJEcKDeNoZZmDOyXYvqAInyhdELwUeEuowYAvxlbwhkjfxCPACcrqVYoRD");

    if (XgcfG != string("GRwyOcgzCQWlxvmbfzjPtrnOhLfVNadyRpYoAmYIYsfxEQbwnsbMHkxYusebHqoRYRudRegUuirZBgaopJEcKDeNoZZmDOyXYvqAInyhdELwUeEuowYAvxlbwhkjfxCPACcrqVYoRD")) {
        for (int rBCtwWOZz = 6537682; rBCtwWOZz > 0; rBCtwWOZz--) {
            eQARTFkgfIkOTg = eKFng;
            YXZHEHwSoyW = YXZHEHwSoyW;
            twBgpxo *= DgPuGAbqmNDPty;
        }
    }

    for (int epmIgHRRjZ = 1799108741; epmIgHRRjZ > 0; epmIgHRRjZ--) {
        twBgpxo -= DlEyYPOSzS;
        KmMsoRHl = ! eQARTFkgfIkOTg;
        KmMsoRHl = ! KmMsoRHl;
        XgcfG += YXZHEHwSoyW;
        DlEyYPOSzS -= DlEyYPOSzS;
    }

    return yrQyS;
}

int ZdRdsDirfrapqiYG::bwlObZbz(string DexjOOlhgB)
{
    string WtxRMSyBqfnIB = string("MvSYYMUgJVWjYwJZwvMuNrPWrooDyfXyoYfXgrHhjiFDmueWBzQpFFORRLiPawJvGXVlQnfHTJwfSdCwYHnyoDyJfQsFQlZdfTIGezxjxvFcBcQumRWYGkyuyREdwbikSHAIqbNZQFWuSi");
    bool JVgoDxFcUQWVmCk = false;
    bool VpKgz = false;

    if (WtxRMSyBqfnIB < string("GnoasJDWkgtqVHFOJgfNNczSfITHGYSltqwikbcMjgsYurUVHErAnrgmDRwlwLbWvMhSj")) {
        for (int RHurZSD = 1302261750; RHurZSD > 0; RHurZSD--) {
            WtxRMSyBqfnIB = WtxRMSyBqfnIB;
        }
    }

    return -176220427;
}

bool ZdRdsDirfrapqiYG::amVNUcOAgOiPntSS(bool soYhhSEzNti, int zskDQB, string xhXdSQXtdTOFB, double nGUOkVeqUHCIyzZ)
{
    bool anNBuCbHUdQkQdK = true;
    double ISlVZAMESoewTD = -422592.96643948986;
    double RqtzNpYitOF = 16174.435528466642;
    int MhPUbR = 1655179058;
    string HNpLwNA = string("FHUlMSuGzgAzhnwnToxLhimrtyYpbCviuybmFeSsXsjRFNMgykQeawDHaGTTFyXoWvaAsyKTjziGtDpSexWONDxBNThbGHoZZvWJkQEwjbaAEOsDKCzfpBhwYMGMpmMRKAPFcuZisTGamnsQHoORCVHqhRYraellXQWMZkSohtAHhsBP");
    string eSizCboUPItnyzkB = string("oydBEvhGznfCEuzWxAOICmSKeIuUCJjQaGAxtwKKyFQXTtzxCLmPNutTePCKHIZeKYNoIQCNocxxzGqmaBfIwjFHZbYlROsMyEmYyoclxENBuzpzAALNSEAPncoFaZpSTZwIrfFxQzWlppYdzHEDGoKGtxX");
    int QQODd = -274106418;
    double vwtnVryKWgFZxZ = 344228.270582362;
    int oWJBE = 1408244307;

    for (int jYDQiwArYyCeXh = 85899310; jYDQiwArYyCeXh > 0; jYDQiwArYyCeXh--) {
        continue;
    }

    if (RqtzNpYitOF >= 16174.435528466642) {
        for (int VySRXxtYSfEVTnq = 1429704171; VySRXxtYSfEVTnq > 0; VySRXxtYSfEVTnq--) {
            QQODd = zskDQB;
        }
    }

    if (QQODd > -274106418) {
        for (int VgztjjUCrxFl = 310628486; VgztjjUCrxFl > 0; VgztjjUCrxFl--) {
            MhPUbR *= oWJBE;
        }
    }

    return anNBuCbHUdQkQdK;
}

double ZdRdsDirfrapqiYG::QAPBSIKfyEcndaLl()
{
    double iJQTNKYbYb = -424278.29195813026;
    string jAiPGsZbffJJX = string("IndPvjInmNfTzyiUIWQwacVCjkBiwGdMinYiFOrhjzSiueyxmMPBPENcQMRmbIdwZDDsTKsCSWrPCUTnQjWPqrtbvYPFJEkktCgeOzrpuHGfEZqwvIWeSpGGMvjmtHqSDUfhjzhLSbTFtfUvRMJxCmytNSWTqTCEwpbAavrDqhjaJGELPVImkXLgSRcvnqwTcwimQfIXSKqLvpSpLhlgUmFIppbArsnFTwvobeJIIEdrSctK");
    int oCBIPLCyxeSTaMk = 213141444;
    int pUvgSGGZDiGgc = 1245310074;
    string hhEesqMJQFwxsWY = string("vVdXCpmJMbfvGzRgWeaKcOSvjfnPEijLGrURcPKRvIWhgEJWTCYQRJzrbhKwnjKoGOsURMpuxcefnlRbAhueyZetyNcLyoiwZxrYeBcGEYIQJgDDMYHHibascRnBdAzEuCMVUvQoIejUlwbPdonpIoHoKUcrcNAqyQIsKdZNeGIhYAJQDmkiurSfUaTeDbpndsmsvfzPKPUrweDXcz");
    string hFmyoYvc = string("OFOmWsDKjArpHgKiXjbwHmIoqrcqdmgTUkEbZRCZnJUkkgbdIlDIeNZVtKocJSGlgFCYSiumCjLnOJSzDIlJGVpckYAVntNyyZcSmdFlHgauIyDeSKNjMsMUsypClSdnjUfCpnnwkJLoVIZSpXNKhUWLJqFzQNmZNAuCSefggjPkYYVNzgWlkHDFztbqqxRRnYSlUHtzqXKBtaxuaoTsLJYHzvF");
    int AoZdBTY = -367126088;
    bool izHvV = true;

    if (AoZdBTY > 1245310074) {
        for (int LUufQT = 1819175122; LUufQT > 0; LUufQT--) {
            izHvV = izHvV;
            hhEesqMJQFwxsWY = hhEesqMJQFwxsWY;
            oCBIPLCyxeSTaMk += pUvgSGGZDiGgc;
        }
    }

    for (int KReqaEbvKQo = 1303084798; KReqaEbvKQo > 0; KReqaEbvKQo--) {
        pUvgSGGZDiGgc = oCBIPLCyxeSTaMk;
        hhEesqMJQFwxsWY += hhEesqMJQFwxsWY;
    }

    for (int ICQocV = 1135379302; ICQocV > 0; ICQocV--) {
        AoZdBTY += AoZdBTY;
        hhEesqMJQFwxsWY += jAiPGsZbffJJX;
        oCBIPLCyxeSTaMk -= pUvgSGGZDiGgc;
        oCBIPLCyxeSTaMk /= AoZdBTY;
    }

    if (oCBIPLCyxeSTaMk <= 213141444) {
        for (int bTnOvxLFOWhG = 1659006324; bTnOvxLFOWhG > 0; bTnOvxLFOWhG--) {
            oCBIPLCyxeSTaMk += pUvgSGGZDiGgc;
            hFmyoYvc += hFmyoYvc;
            jAiPGsZbffJJX += hhEesqMJQFwxsWY;
        }
    }

    return iJQTNKYbYb;
}

void ZdRdsDirfrapqiYG::eEzhoPdYP(string kXlBH, bool braApfqFGl, bool trLqyNm)
{
    int BebzmRIay = 2124317218;
    bool WXZFzSlzIRBRFIj = false;
    bool OUCJsQBPMkQFKNgf = true;
    int OLkLZIpGEV = -271445573;
    string BeWuXmfyqvNDK = string("sGWrYabgKXzjBobzVJMNRiGsvcvKTaVkIBjBeHnOhBBq");

    for (int OFsAgqofgqbyh = 1926366725; OFsAgqofgqbyh > 0; OFsAgqofgqbyh--) {
        continue;
    }

    if (OUCJsQBPMkQFKNgf == true) {
        for (int zbKQwgqF = 1627626653; zbKQwgqF > 0; zbKQwgqF--) {
            OUCJsQBPMkQFKNgf = ! OUCJsQBPMkQFKNgf;
            BeWuXmfyqvNDK = BeWuXmfyqvNDK;
        }
    }

    for (int hqcZq = 1454579355; hqcZq > 0; hqcZq--) {
        kXlBH = BeWuXmfyqvNDK;
        trLqyNm = ! trLqyNm;
        WXZFzSlzIRBRFIj = ! trLqyNm;
    }

    if (kXlBH >= string("rswkeQcAGNlrYAcEoGZILMiwNkfEtmHBeiTnhdCtfIieZEyICGQDrNgiYHCLlPXLTyomWYblXRMFBPsvJzxyESkIwlsjsCQCd")) {
        for (int irdllIxhB = 1339892530; irdllIxhB > 0; irdllIxhB--) {
            continue;
        }
    }

    if (braApfqFGl != false) {
        for (int TEdbbEpsSTdlNEy = 1185572858; TEdbbEpsSTdlNEy > 0; TEdbbEpsSTdlNEy--) {
            WXZFzSlzIRBRFIj = trLqyNm;
        }
    }
}

int ZdRdsDirfrapqiYG::CakAZBmIgnr()
{
    bool gZhMqbpXJeS = false;

    if (gZhMqbpXJeS != false) {
        for (int cvCFLhboxPpjj = 2016929558; cvCFLhboxPpjj > 0; cvCFLhboxPpjj--) {
            gZhMqbpXJeS = gZhMqbpXJeS;
            gZhMqbpXJeS = ! gZhMqbpXJeS;
        }
    }

    if (gZhMqbpXJeS != false) {
        for (int TSAfOvDKzQ = 387537155; TSAfOvDKzQ > 0; TSAfOvDKzQ--) {
            gZhMqbpXJeS = ! gZhMqbpXJeS;
            gZhMqbpXJeS = gZhMqbpXJeS;
            gZhMqbpXJeS = gZhMqbpXJeS;
        }
    }

    if (gZhMqbpXJeS == false) {
        for (int JnSCjEnSE = 514026321; JnSCjEnSE > 0; JnSCjEnSE--) {
            gZhMqbpXJeS = gZhMqbpXJeS;
            gZhMqbpXJeS = gZhMqbpXJeS;
            gZhMqbpXJeS = ! gZhMqbpXJeS;
            gZhMqbpXJeS = ! gZhMqbpXJeS;
            gZhMqbpXJeS = gZhMqbpXJeS;
        }
    }

    if (gZhMqbpXJeS != false) {
        for (int kGiYOktDtNJ = 1876042024; kGiYOktDtNJ > 0; kGiYOktDtNJ--) {
            gZhMqbpXJeS = gZhMqbpXJeS;
            gZhMqbpXJeS = ! gZhMqbpXJeS;
            gZhMqbpXJeS = ! gZhMqbpXJeS;
            gZhMqbpXJeS = gZhMqbpXJeS;
            gZhMqbpXJeS = ! gZhMqbpXJeS;
            gZhMqbpXJeS = gZhMqbpXJeS;
            gZhMqbpXJeS = ! gZhMqbpXJeS;
        }
    }

    return 515487720;
}

string ZdRdsDirfrapqiYG::kMbQb(double BbVyd, int jqFICs)
{
    string pKPNJZ = string("KNoybWAjQdApoYHPNwMLJnYOFNilIaEHwhvgAqXsriftPtIgQLpiSTEzAlFcchNFdMWZPsrnQpZzDpJRCqpbiMxnZHOSLvrTLMQegFILVbwTXZoPXGkEHFhDZgSNFXfOkrYGjHlWK");
    bool XKescv = false;
    bool UPCUW = true;
    string GVrdOEdFoXfo = string("BFUKVEWjpDQblOSjgQulDBOMdNTfteuorIrSxtEBuNnJoOMsxIoCtkhtaPvLAfrzFdHl");
    double AcLZJKQGPG = 316505.36274657224;
    bool HhAZQHoI = false;
    bool PKkYYRHysUBM = false;
    int azMuLc = -657052223;

    for (int OidHwZU = 606039492; OidHwZU > 0; OidHwZU--) {
        continue;
    }

    if (UPCUW == true) {
        for (int xdySYIg = 2063309967; xdySYIg > 0; xdySYIg--) {
            continue;
        }
    }

    for (int epiIlazkONPl = 1686376975; epiIlazkONPl > 0; epiIlazkONPl--) {
        HhAZQHoI = PKkYYRHysUBM;
        XKescv = ! UPCUW;
        azMuLc -= azMuLc;
        PKkYYRHysUBM = PKkYYRHysUBM;
    }

    for (int CkEuaYGOYyU = 367467198; CkEuaYGOYyU > 0; CkEuaYGOYyU--) {
        GVrdOEdFoXfo = pKPNJZ;
        PKkYYRHysUBM = ! UPCUW;
    }

    for (int dtTSyQL = 1291421476; dtTSyQL > 0; dtTSyQL--) {
        XKescv = PKkYYRHysUBM;
        jqFICs -= jqFICs;
        BbVyd /= AcLZJKQGPG;
    }

    for (int alNOpLpoiFAV = 689680210; alNOpLpoiFAV > 0; alNOpLpoiFAV--) {
        continue;
    }

    return GVrdOEdFoXfo;
}

int ZdRdsDirfrapqiYG::ocBvLicPQhIf()
{
    int LTCsl = 1325963172;
    int wObGxCvgKMIHiI = -942765765;
    bool zQULeyfvWs = true;
    string BFWoUaypWyj = string("gMxyzPNtluGwXADGqIQoOWZBLPzWMpyhaMYqsFRJQTliGEQCAtUGVkWcEhtieugCKjWzCNG");
    int vApgbijvMYC = 1119313673;
    bool CltHYCjO = true;
    double qjLQyp = -418707.11010775407;
    int KvYZGzKnqyzUWZ = -725868215;

    if (wObGxCvgKMIHiI == 1119313673) {
        for (int yOqyKLXOdJvgDEt = 1715241451; yOqyKLXOdJvgDEt > 0; yOqyKLXOdJvgDEt--) {
            vApgbijvMYC /= vApgbijvMYC;
            CltHYCjO = ! CltHYCjO;
            CltHYCjO = ! CltHYCjO;
        }
    }

    if (zQULeyfvWs == true) {
        for (int YjmkQOjSgv = 1244539402; YjmkQOjSgv > 0; YjmkQOjSgv--) {
            vApgbijvMYC += KvYZGzKnqyzUWZ;
            qjLQyp += qjLQyp;
            KvYZGzKnqyzUWZ /= LTCsl;
            LTCsl /= LTCsl;
            wObGxCvgKMIHiI -= wObGxCvgKMIHiI;
            KvYZGzKnqyzUWZ = wObGxCvgKMIHiI;
        }
    }

    for (int kcXov = 1969419523; kcXov > 0; kcXov--) {
        continue;
    }

    for (int fCjyvQbELlj = 34269567; fCjyvQbELlj > 0; fCjyvQbELlj--) {
        qjLQyp = qjLQyp;
        zQULeyfvWs = CltHYCjO;
        zQULeyfvWs = ! CltHYCjO;
    }

    return KvYZGzKnqyzUWZ;
}

string ZdRdsDirfrapqiYG::obDuvKHUVB(bool KAxzSGzCJPY, int AoAzdBYvjFo, string KlSfACbYU, bool pdQrLnHoqAOiA)
{
    double MpRlWGYiDSygEDy = 563727.5369663535;
    bool lNdGQHXVKgf = false;
    bool nLYhESdfE = false;
    int WRtwVGtWGtVZsqD = -1664544950;
    string aIlSKTRLd = string("wVdNbZsPGlRkdMgogv");
    int vBHbGABfsGbS = 692093405;
    double KQSMOo = -687702.5036190096;

    for (int wwOVfxPtZvsFQ = 248449728; wwOVfxPtZvsFQ > 0; wwOVfxPtZvsFQ--) {
        continue;
    }

    for (int kftTFlEiAmeDhNW = 2022737875; kftTFlEiAmeDhNW > 0; kftTFlEiAmeDhNW--) {
        KlSfACbYU += KlSfACbYU;
        nLYhESdfE = nLYhESdfE;
        pdQrLnHoqAOiA = pdQrLnHoqAOiA;
        aIlSKTRLd += KlSfACbYU;
    }

    return aIlSKTRLd;
}

int ZdRdsDirfrapqiYG::cisxiafPZoEl(bool YJIXtR, string FmsObjuhOtXTstdo, bool WKAnk, string JHapPiE, bool JlpeuSVZpQo)
{
    int WmOlUeVczVwYIxm = -2046876080;

    for (int VOWppLmYKq = 1094111014; VOWppLmYKq > 0; VOWppLmYKq--) {
        WKAnk = WKAnk;
    }

    return WmOlUeVczVwYIxm;
}

int ZdRdsDirfrapqiYG::FdkcFtWuERf()
{
    bool HQjhFAqfKVsCvSTB = false;
    bool HwFizdduVVEjvH = true;
    bool mIHMcaAQGIbgBPAP = false;
    bool rQVQehBOazC = false;

    if (HwFizdduVVEjvH == false) {
        for (int NtyPZugdiPSCEYX = 1034103944; NtyPZugdiPSCEYX > 0; NtyPZugdiPSCEYX--) {
            HQjhFAqfKVsCvSTB = HwFizdduVVEjvH;
            rQVQehBOazC = ! HwFizdduVVEjvH;
            HQjhFAqfKVsCvSTB = mIHMcaAQGIbgBPAP;
            HQjhFAqfKVsCvSTB = mIHMcaAQGIbgBPAP;
        }
    }

    if (HQjhFAqfKVsCvSTB != false) {
        for (int eqmjdXlkaFetq = 603122289; eqmjdXlkaFetq > 0; eqmjdXlkaFetq--) {
            mIHMcaAQGIbgBPAP = ! HwFizdduVVEjvH;
            HwFizdduVVEjvH = ! HwFizdduVVEjvH;
            mIHMcaAQGIbgBPAP = HQjhFAqfKVsCvSTB;
            HwFizdduVVEjvH = ! mIHMcaAQGIbgBPAP;
            HQjhFAqfKVsCvSTB = ! HwFizdduVVEjvH;
            HwFizdduVVEjvH = HQjhFAqfKVsCvSTB;
            HwFizdduVVEjvH = ! rQVQehBOazC;
        }
    }

    return 1035473196;
}

int ZdRdsDirfrapqiYG::zHjrz(double uyRfYLRKHUlKJz, double lkMyNroR)
{
    double vWdxr = -301919.4431382752;
    int DwhNdahzc = -681758526;
    int wSrwVcKaqSt = -702311142;
    int GjspmaLotmcC = 1501091152;
    int sYXgO = 2060227742;
    int RdYQnMPfX = -35246675;
    bool uAdDrJrKmvVSLzC = false;
    string gIELUMrjIitup = string("JZzZiOEHXyQBSNatVkWbYjKfTkRlBNtxsIWxhqcHkDpICeANVTHOXByXshXJUnNRTdPefzLLxyZzhjYWcLUlpBUvOAQPBugRwnNZXaLWqMNfBccqCIOBwXUOVFSURyHpfwFuvcxCzGZziufWtURSqTEVBsfKchyQHzwLkVFbmGIAOkwXFMCEqycfRPBMNqVPDxgPnurmqNZTRWhecnyMolxoAwyUrvrgEJLukaaUuIMUoBVBOiSTUMtOAjjAXl");
    string gITezq = string("FgPkOzOuNwazFPnrwmeVxVhPWzWSjHgqPgHKNIfPsxyuKKORQtiNYxFmVLfTlDoHdYBVkaYlS");
    string eTsDqCKFFqqvHElz = string("qIiuhNvGOytpuuWVAdMTxmayefGZPCsCcGjAyHRTwYimiIGVjCTPKQKcVyiutTxjnoqmPFSeUUAhKRzTqUhdVgItqWUCcymOLNldhYMZMvmhJrarZdbTPQ");

    return RdYQnMPfX;
}

ZdRdsDirfrapqiYG::ZdRdsDirfrapqiYG()
{
    this->gfowKMzsfXZGnW(string("yPFNwqADRGPXreajgqnUWWESAOMCrXiSttOLXhAkSLfmuctLmRJLxRXXpcCSpsBcyizWaxCKrey"));
    this->pGsoBxVbh(836056498);
    this->REXDFVF(19940.590944405783, 278831.6872261943, true);
    this->naeMAW(false, -1896986501, string("uTNiEeRhOVpggcFEuMvmogQPfqLcJOVAVjdNENWRGrzpBHZKsuUbtgamOzRFXejjAZkwdvIZDpuLWzMlqSrrWHfHORswfNvurLzuqGLRnzgJUyNoeeyEPbieJHCtEmDmwzyGjKjxhEiIjuhGwKRQVXhaWFewzURXeSPxRreKObkaKLiLHwRynRJdQQSgixHbxOHNSsuYzcsUkKiBdOZLIhQTkIEl"), true, false);
    this->EWzxCYmytKwASZbW(false, -849.7218283210211, 599119.525837112, false, true);
    this->VzjqYWpEvMfGFHV(false, false, -221349.71625871066);
    this->bwlObZbz(string("GnoasJDWkgtqVHFOJgfNNczSfITHGYSltqwikbcMjgsYurUVHErAnrgmDRwlwLbWvMhSj"));
    this->amVNUcOAgOiPntSS(false, -813339561, string("abOEsFYJQRUyNWcHgioGYxZYpbeniDJwADLfOYcSNZItvjbetuSW"), -934285.5865771902);
    this->QAPBSIKfyEcndaLl();
    this->eEzhoPdYP(string("rswkeQcAGNlrYAcEoGZILMiwNkfEtmHBeiTnhdCtfIieZEyICGQDrNgiYHCLlPXLTyomWYblXRMFBPsvJzxyESkIwlsjsCQCd"), false, true);
    this->CakAZBmIgnr();
    this->kMbQb(-45204.53912203564, -1091807469);
    this->ocBvLicPQhIf();
    this->obDuvKHUVB(true, 1686707876, string("PbjPuuYjPqXzVAMmADNuDQEdzkdZysXguhFcHbIkyvdyYOWlqbAbBbuXCFLagzpRXtpyjgujjObfwzKmZqHMDQBuVWjBsTMLUPrqtSalCkWTucwhsXLlCmHtrWGeXXECJMyhJMdkcTWizsecEiogEofvEobaVQFIEsZSFooYygpHyjYTUxjLjLqXVPBGpXTBTTzByazwfsqoFwRzKgncjplfXErI"), true);
    this->cisxiafPZoEl(true, string("QaqzEDKJVJmsNIYlZlsreFraGEWNExcApPVWwPWLTvKXlLKqQKZElPTzuFMUnivvesxvsKtuBtThcDUjhwyfYlHYAFLOXnrnzjLwMtcnfbMzlsZgVJgjAvlaMRowscuiOaCiWTOxqKMigYOnMgHQTLjIdgpRkJFtuUojMaGrDIwP"), false, string("yjcVxsauuyzPvomRPsWHMxRxZoRBlDoDtWCEfiGMqZOGtAYMRjWAsDcjDvYyPneXNqntZvIOyQDOkksNDQEhtJFqMkKZxsmNnctfwVnNllsVjTTkkZhhZBoqdKmpkNsjIYYmlVveIvgTZMtrwFcYmmPClbGwxMAlNYwwYOLvbsUrXJFypvIkKWDDahZPdeQEPxab"), false);
    this->FdkcFtWuERf();
    this->zHjrz(165435.7335050035, 896506.5012324728);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GnwgfBMf
{
public:
    bool uSgwSJ;
    string naEpjksXkM;
    int eOUtyShytvy;
    string VWXRbZRuJ;
    string rEsFSH;

    GnwgfBMf();
protected:
    int mbUzrlFBV;
    int PqUPSyAgtfD;
    string JFxCRcaunHIKmPy;
    double qWjYfsdNtxnFk;

    bool OHtRyZCUIijQOT(string TPlaMaJPoWLA, string lCaWsZiEonWvYsL, bool RkvcbOSXvUhGY);
private:
    double uMWvWVBJU;
    string CQgMZ;
    int RVPfln;

};

bool GnwgfBMf::OHtRyZCUIijQOT(string TPlaMaJPoWLA, string lCaWsZiEonWvYsL, bool RkvcbOSXvUhGY)
{
    string gOrIHUsauJ = string("PtJRSbCSaRUNNqfByKNPcrZboFfKfqhEzuFxhIoIdhsSGN");
    int rjupIfAXwB = 1806632879;
    bool GQlinQeFOeGN = false;
    double kEnSVrm = -823043.3784810279;
    bool FQdrOaaBSvyomeT = true;
    int mrYpOzh = 1811724636;
    bool KgQKYSsBkYeSb = true;
    bool dLPCcXC = true;
    double VLlKEUE = -934460.7961449065;

    for (int sxSSgBAPViYWQCMF = 388927565; sxSSgBAPViYWQCMF > 0; sxSSgBAPViYWQCMF--) {
        rjupIfAXwB = rjupIfAXwB;
    }

    for (int fhuyodGe = 1366155572; fhuyodGe > 0; fhuyodGe--) {
        rjupIfAXwB = rjupIfAXwB;
        FQdrOaaBSvyomeT = ! dLPCcXC;
        FQdrOaaBSvyomeT = ! GQlinQeFOeGN;
        lCaWsZiEonWvYsL += lCaWsZiEonWvYsL;
    }

    for (int hRtRxdsajdqItw = 1920078103; hRtRxdsajdqItw > 0; hRtRxdsajdqItw--) {
        continue;
    }

    return dLPCcXC;
}

GnwgfBMf::GnwgfBMf()
{
    this->OHtRyZCUIijQOT(string("SXuVdleDHsRgwPjbCaEudiwCCfqwBSbqAuftwkwuZgrEHOujvWQxUxzIvzPpGOlvSZUxiNcViWJAyGDIyMVhapBLImJPHKYpDpwzwqgWfuQvbmkENQbaP"), string("FxkXukQwFHqDqENYAFEMhCxGjodxHzsVcYgCQxwCSFjzexKUljdgitRfxHrQhhQCDbOBcHrrWaotLQ"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YHAQujfcke
{
public:
    int vFwjv;
    int IpKRyVZrGIgVN;
    int tYeVaQZTDQvmOrno;
    string QTGiFGdnr;

    YHAQujfcke();
    bool GbeId(double GYozrMjPxd, string esfFWepqJTk, double GhplUt, int HXoQYCmBKso, int RrnqXeFC);
    double NnHNbyvDlUhB(string ukxxyGdDd, int YuGUgO, int eOMNBvOZm, string uuOLrQB);
    double RZdGpLaqQSxnjPa(string ZkXfXpmLfZITMqO);
    void mQbBxi(bool EctNhO);
protected:
    string aVkNbKG;
    bool YHqVxLFOMIQV;
    bool DytOqghc;

private:
    string MBxaoRDrlMNX;
    double MLJObTJ;
    int FePMmFUKG;
    int VaxVDZS;

    int YvxCyXLuczWzIz(int UKOqPdamAXvcdfZH, string TGbSsaDm);
    int ToJpNjWtw(string tWMwjYtofxgNkmm, double SPExcDEiyt, string NkHgSqx);
};

bool YHAQujfcke::GbeId(double GYozrMjPxd, string esfFWepqJTk, double GhplUt, int HXoQYCmBKso, int RrnqXeFC)
{
    string aJtUHp = string("uqVsCkKTkfiRNQzqlMKnvoglYyfpJGWpdbgrtbgXJonuwwlGVaLjgtnJGOvFnuayXhTIFupDfJhnRnFmoOtaZknefjTGyHrrqcYYnIueGFFZNgPcYgUvEEiPdcshUIqLDDnvZCnLqMilqvWwufduMJjChgELwn");
    double pRpXLRcvB = -20574.683333598437;
    bool ZYiLg = false;
    int jfwxDipGDXUOs = -791392460;
    double sOBUr = -72315.5288276954;
    int uVZFnKCNai = 1098341893;

    for (int pctwlqMvxXlRvT = 1270130019; pctwlqMvxXlRvT > 0; pctwlqMvxXlRvT--) {
        continue;
    }

    for (int VSEeGJVoeaF = 2023507804; VSEeGJVoeaF > 0; VSEeGJVoeaF--) {
        GYozrMjPxd *= sOBUr;
        esfFWepqJTk += esfFWepqJTk;
    }

    if (GhplUt < 365018.63442147186) {
        for (int KuHJuwNlUwwoIwt = 1035809519; KuHJuwNlUwwoIwt > 0; KuHJuwNlUwwoIwt--) {
            jfwxDipGDXUOs *= jfwxDipGDXUOs;
        }
    }

    return ZYiLg;
}

double YHAQujfcke::NnHNbyvDlUhB(string ukxxyGdDd, int YuGUgO, int eOMNBvOZm, string uuOLrQB)
{
    double DIUhoBLVLZDgJG = -627351.9528255292;
    bool pthQNiPPNio = true;
    bool JpdOFnvKlRp = true;
    string mFVhPTBzfOuc = string("WPvwatWwNNXduRVsOZMdHzzzJQxfGJovoOaFSgUIfxYTOyLxyDsUzHdlxdDxRbLzKxvBPnuSPySjwQiFGdeMdDGoWodpZYEdWjUscWkmMIaexyecnttYCPomAdGaltMtlelTikeJKTaTxSEGOTuOkEiwOtAQpfJCOWEWTR");
    int CYVIecvDmYCES = 651052706;
    string kSUDNXLgVpjp = string("dnjwBYHIFPyJnjEIvIqRdneiKlRHoGEtsgrxSidgSkGHqgcAPtDgCtRRRxqwyVhwdjDPyKvEraGPAjAogVmIUWtxIPETqmWSQTEBqCitWOspQYBVooYffClIRqBFoGnYTjWkZSRlXKXstnXgzohEKvYQSVSouirMdvKysWbxsTp");
    string YBRCzgGUnCXWETsA = string("UQgTaxOSJfYjSYtsKDVOmoTJEnBiTtygwMgmZKKquQZhyytjWbtZDMuVbjivIfppVavMWfqVRlwFrDnSscRZFnCUTTZKraEnAVpEgwufItHBDfzyXgWLXlRLkCuYwHppiBMGuoVpWDAyPwzvVcluDkycxmiefKaGEXbMqFFBBTuMfdcoQuqNf");
    double XGRnX = -905252.5235666443;
    int WYbruhjEVuZeGxv = 1455764695;

    for (int waXYYVLiuFRBSt = 1323039830; waXYYVLiuFRBSt > 0; waXYYVLiuFRBSt--) {
        JpdOFnvKlRp = ! pthQNiPPNio;
        mFVhPTBzfOuc = mFVhPTBzfOuc;
        eOMNBvOZm /= WYbruhjEVuZeGxv;
    }

    for (int YvEWeUSEzh = 602880568; YvEWeUSEzh > 0; YvEWeUSEzh--) {
        continue;
    }

    if (kSUDNXLgVpjp > string("dnjwBYHIFPyJnjEIvIqRdneiKlRHoGEtsgrxSidgSkGHqgcAPtDgCtRRRxqwyVhwdjDPyKvEraGPAjAogVmIUWtxIPETqmWSQTEBqCitWOspQYBVooYffClIRqBFoGnYTjWkZSRlXKXstnXgzohEKvYQSVSouirMdvKysWbxsTp")) {
        for (int lLTUzgAk = 386936906; lLTUzgAk > 0; lLTUzgAk--) {
            uuOLrQB += kSUDNXLgVpjp;
            kSUDNXLgVpjp = YBRCzgGUnCXWETsA;
            YBRCzgGUnCXWETsA += kSUDNXLgVpjp;
        }
    }

    for (int vRewQUfasXdYvB = 1941956359; vRewQUfasXdYvB > 0; vRewQUfasXdYvB--) {
        mFVhPTBzfOuc = kSUDNXLgVpjp;
        kSUDNXLgVpjp += YBRCzgGUnCXWETsA;
        JpdOFnvKlRp = JpdOFnvKlRp;
        XGRnX /= DIUhoBLVLZDgJG;
    }

    for (int RacBmYRbGeA = 175689232; RacBmYRbGeA > 0; RacBmYRbGeA--) {
        eOMNBvOZm *= YuGUgO;
        DIUhoBLVLZDgJG /= XGRnX;
        YuGUgO -= eOMNBvOZm;
    }

    return XGRnX;
}

double YHAQujfcke::RZdGpLaqQSxnjPa(string ZkXfXpmLfZITMqO)
{
    int PKIHKSLb = -4059;
    bool cXrHuVB = false;
    int IwGnWaqNQVipkG = 993864913;
    double SxdPOfJoWqkHmmA = -755479.6137375246;
    string kbpriOPEvwNrQTo = string("sjGDeyPxTJVyngKUVyjDgkPbkMFNtzWyTtFQXiMqWwMsRmyyMDJLCWioLzWhyZOpOXfAuETjacLUYxGOQXmTfxCmospdIiqyDVDKppQacHSmnsyxmFPWfmFt");
    bool fhoaH = true;

    for (int IxZGBtPweNxTTII = 1789619754; IxZGBtPweNxTTII > 0; IxZGBtPweNxTTII--) {
        IwGnWaqNQVipkG += IwGnWaqNQVipkG;
    }

    return SxdPOfJoWqkHmmA;
}

void YHAQujfcke::mQbBxi(bool EctNhO)
{
    int ndXRzjTGMItlVQ = -767779765;
    bool QztSKwt = true;
    double faKbdGvgZHpmmM = 656593.9868309959;
    int YkWHbusdaLMQS = -1790405670;

    for (int yXgWZvFR = 545967425; yXgWZvFR > 0; yXgWZvFR--) {
        EctNhO = ! QztSKwt;
        YkWHbusdaLMQS = YkWHbusdaLMQS;
    }

    for (int alGJWMwE = 1560518054; alGJWMwE > 0; alGJWMwE--) {
        ndXRzjTGMItlVQ = YkWHbusdaLMQS;
        YkWHbusdaLMQS /= ndXRzjTGMItlVQ;
        ndXRzjTGMItlVQ += YkWHbusdaLMQS;
    }
}

int YHAQujfcke::YvxCyXLuczWzIz(int UKOqPdamAXvcdfZH, string TGbSsaDm)
{
    string rJrjAxCYBTKr = string("hdFQVsVnfmxFdGRwCoYhbmAkSNizZunzFlGGJxWMSDmzExtPlsOsGMqwdpnevfLHnVHkDzq");
    int QnostkoWf = -496074381;
    double HhvDZ = -572267.6990874067;
    bool YzuZiTFZDQRbTfuT = true;
    double OJlivEYvAFnJKa = 952195.1708313507;
    string TuiorsxZeznfTh = string("hdhfiTfDdAedlyuYYmNgqMvUXWaRnAKcPCArShToNjoCoCKpPFHqTIxegRulQlZxLngbFddFpO");
    bool hlhLSGTDnCSD = false;
    string SQBdi = string("WyipACDzSCnRERJoaGgUuyFqlSaFameIWcJmkwDHJBHpqVMqwwhBCsJTFibRodRpsHNjEuUHWGnhmTTOCeWHZybuOdjKKmohoCHYPIfdQZMjpRzfXzofXXqFAlNbMJPDxutqDuIdgLqzyQRHNDRpzTxSUAGwqCBAnCqwCSFLmSaQeAKfWAZmzJTxJRAypWsdmlNxepqzxCVYUqLffFUErGzGYUpwmSVpEWdMrAcjvBgiTNSe");
    int TODYzWVSxb = -705221848;
    bool MjhDDbBKe = false;

    for (int HSNhdrDFeV = 1518036748; HSNhdrDFeV > 0; HSNhdrDFeV--) {
        SQBdi = SQBdi;
        TGbSsaDm = rJrjAxCYBTKr;
        TGbSsaDm += SQBdi;
    }

    if (QnostkoWf == -496074381) {
        for (int xraRloxqbiprVTJD = 197987510; xraRloxqbiprVTJD > 0; xraRloxqbiprVTJD--) {
            YzuZiTFZDQRbTfuT = ! hlhLSGTDnCSD;
        }
    }

    for (int ImzWXCTqFmz = 1035953070; ImzWXCTqFmz > 0; ImzWXCTqFmz--) {
        continue;
    }

    for (int SsyzZQLTI = 1984000837; SsyzZQLTI > 0; SsyzZQLTI--) {
        MjhDDbBKe = ! YzuZiTFZDQRbTfuT;
    }

    return TODYzWVSxb;
}

int YHAQujfcke::ToJpNjWtw(string tWMwjYtofxgNkmm, double SPExcDEiyt, string NkHgSqx)
{
    bool ELrwQjeGjEX = true;
    double wAiwhadjVnKFfXoP = 196149.85204006766;

    for (int EPUFgIgGnPbbsDj = 1908936314; EPUFgIgGnPbbsDj > 0; EPUFgIgGnPbbsDj--) {
        tWMwjYtofxgNkmm = NkHgSqx;
        NkHgSqx += NkHgSqx;
        ELrwQjeGjEX = ! ELrwQjeGjEX;
        tWMwjYtofxgNkmm += NkHgSqx;
    }

    for (int dWTvzx = 588861509; dWTvzx > 0; dWTvzx--) {
        tWMwjYtofxgNkmm += NkHgSqx;
    }

    return -62573571;
}

YHAQujfcke::YHAQujfcke()
{
    this->GbeId(-480037.6989982639, string("GdmPMRltpUTAaTcVsiAcwppnkltLmXpiarUAYttpdKDWuzvZtfOmIuykllWVthy"), 365018.63442147186, 1517775306, -354806481);
    this->NnHNbyvDlUhB(string("WIZXjqtHqVsqhWIBOyOHzfgiVzqIcpwzUUicYKoAwYeDleyqHTrVCXGgYQHQftkCBqRYdSxmcHapZbAQdqIcWVoQUOzSiNTAuPYZulygyZrstLUuFOcoqdyrfybNphQXHcytnpdajfrMaYUcdNOXqjGfEQNAsbOeSpdBCdocWQvbPmHLbYiTQioKoEfsOawETfxjRZAOrJP"), 1899790640, 1918460865, string("hYJjvJOZAoDhzrqTfhcJDlsdVQHyleKNAkZSIUAMWefmwqBcqDoVJEIPLmvvbqmHRDjelnnmITottpfuLxCbYmgXhspFGErGPBbgUnDdiJQEbroLmHgASUWsrHFVRYNjwMPwnxQEEnStreurjElBqCtdFsMIOLRmePlPBwzfbzGKFyjamh"));
    this->RZdGpLaqQSxnjPa(string("NbXeDaBWTsSIyTuVavBFACuvuhpSvziKjeWDuTNuOOSjdfpRTsYVrhNEQfGomRTExBTySpoZJjgDyuU"));
    this->mQbBxi(true);
    this->YvxCyXLuczWzIz(-2145595007, string("gMTJViHREQuPwCQp"));
    this->ToJpNjWtw(string("KPSlTPgdABozSznimTAIHxsgDjcJhdFiYRfXjQhfTCaPDWelXmjBzbuneDVhzCcpqSDNHvxTFe"), -461015.7326760481, string("ZkuZeTJFGRcmpvTEnYULUBfSTlxGAmuhIvnblSYPvvVLbnNvROxZDOcEuTqVUrzaghCULreIVnhKcesMpdPpKCDpMGWEtoysGzjlsAqVAbBcITaOSzYhROUpeGCANBghiuInVVOCBpEljtFhUQOzVFeaE"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KlRNiztAdkShg
{
public:
    string MuHnxbWBu;
    bool fwsoi;

    KlRNiztAdkShg();
    bool eDpshXutWq(int vfsdUIvAWkeYk, bool CAsXiX);
    bool CpPbKRGYxpCXi();
    string bUOqCQdmN();
    string AvSUQa(string hRTCi, int BGdVFMklVj, double OJRCdHFZQX, bool xRHiWqtqkroHJ);
    int dAMuospuHnos(bool emFSiIpBRlKAVVR, string hLHjIIDeSQuOWZRp, int xeZceuTlbXSmW, int yJuUBqUDdNv, string nZogNb);
    string UZftaq(bool PaQfbPpeeqz, bool gYmSg, int vuzLAO);
    double oeljDdt(double Mqqvz, double lexhIWKaDYJEY, bool FqWkFYX, int IMkWNsXisIX);
protected:
    string cmBrhSimGBzDlOG;
    double jygMgvKYrqWfuOV;

    int nRuYdt(double QnFDMSc, int gjSrL, int iJZxNQSH);
    double knbqfHmQVDuIwZ(int ljQiOYsbNDGvE, string ATVUZfkzeKAoYVgo);
    int VpcOUOlljtpZPAL();
    void DwWOrSfl(bool DpjxxhF, bool jZtLGNRupQF, double jDtAv, bool taOzjRQFMElgj);
    double vfVWhpJldcfqft(double MWFvns, string vNSFEMRV, string CjgSiTd, double UFlVStKAyW, bool uDoyZ);
    double PHQrjotncMiEtiP();
    int JDDqCXPxtumOJp(string adtFkNIOW, double cxfenGjr, string RaBoQWCY);
    string KCAaaCsu(int xlWsyC, string kRnKXGeplWGAbvJi);
private:
    string JsLrlJKdVCSPskM;
    double BgiPXXlHPAHgec;
    double xrjvaBFTRKeykFL;

    int PNZcZm(bool WsuJna);
    double bCtPAIhuVdEXDd();
};

bool KlRNiztAdkShg::eDpshXutWq(int vfsdUIvAWkeYk, bool CAsXiX)
{
    bool AQegfsv = false;
    string WajolRgWqEzCfQy = string("INZDYQVbRGSVBFulKvHZFkKYGfcNXLXWhPKjpTDKFDRWqyfrlB");
    int dRlhAcIXAHWNjECA = -1933954923;

    for (int jYsmu = 1316174143; jYsmu > 0; jYsmu--) {
        continue;
    }

    for (int RnusttUXeVtDcsCC = 1700996304; RnusttUXeVtDcsCC > 0; RnusttUXeVtDcsCC--) {
        AQegfsv = AQegfsv;
        vfsdUIvAWkeYk *= dRlhAcIXAHWNjECA;
        dRlhAcIXAHWNjECA = vfsdUIvAWkeYk;
    }

    for (int lWdufewXVArwh = 1106647259; lWdufewXVArwh > 0; lWdufewXVArwh--) {
        dRlhAcIXAHWNjECA *= dRlhAcIXAHWNjECA;
    }

    for (int UvzJLQMGrJccV = 246810440; UvzJLQMGrJccV > 0; UvzJLQMGrJccV--) {
        vfsdUIvAWkeYk = dRlhAcIXAHWNjECA;
        vfsdUIvAWkeYk = dRlhAcIXAHWNjECA;
    }

    if (dRlhAcIXAHWNjECA <= -465267986) {
        for (int RlwqXgZJTfBu = 1122162442; RlwqXgZJTfBu > 0; RlwqXgZJTfBu--) {
            AQegfsv = CAsXiX;
        }
    }

    return AQegfsv;
}

bool KlRNiztAdkShg::CpPbKRGYxpCXi()
{
    int jJrJF = 323221887;
    string wckigZ = string("RWwdssXTKazqhrFVvQRenNIeXRYOjXMagPfQYZWjwBXlkWchFSJqZodItyxEnIFZGJSwEunnsDMyFQpFPnkSZJvuOPVOgHjzklvNobtTWUNgvPjdiJSJFTEjbbhIKvDfpzQfYvPCTdwFiRQIfnjqMuKQsTEiLxMGnDBlCxiqSzBXXcD");
    double BvKWgmw = 260445.7257597479;
    int jonmjRcpSGfbEI = 1979408821;
    double MdTnZRLRthOye = 248779.9496758068;
    bool rmAHDVUve = true;
    double IowcCL = -462890.6406144594;
    double wOpYpoxUU = 462150.05003985995;
    string upfIQbYwszawq = string("iiPQmECJZCduqdMrSIUgSVonmJWiafLnXuJNXtEeNQBibxmBqRnFRkHpcrwDXxrMgfGMEzpcKgWPrEgXxYXOdeCxphCEEWBfedcyZufuDPZALLSgrwqGcCCziGanDvfhymLgIDgzyEjhkVmcaMGojWAflCDhNeltwDSKJzsBDzHdnDmQelkLWXdasPHMQDOROtbnLZMseSPPaIuWVhzEjkS");

    for (int wpkJgYVHiSbAk = 1184632486; wpkJgYVHiSbAk > 0; wpkJgYVHiSbAk--) {
        continue;
    }

    for (int NSksFz = 1891709004; NSksFz > 0; NSksFz--) {
        wOpYpoxUU *= IowcCL;
        IowcCL *= wOpYpoxUU;
    }

    if (BvKWgmw == 248779.9496758068) {
        for (int QeejKoNXlNTIMOLx = 1820804366; QeejKoNXlNTIMOLx > 0; QeejKoNXlNTIMOLx--) {
            wckigZ += wckigZ;
            BvKWgmw = wOpYpoxUU;
        }
    }

    for (int NYQZjMLQCZyq = 860841244; NYQZjMLQCZyq > 0; NYQZjMLQCZyq--) {
        upfIQbYwszawq = upfIQbYwszawq;
        wOpYpoxUU = BvKWgmw;
    }

    for (int OOSPMILB = 977125108; OOSPMILB > 0; OOSPMILB--) {
        wOpYpoxUU /= BvKWgmw;
        upfIQbYwszawq += wckigZ;
    }

    for (int KSNBYCc = 741142041; KSNBYCc > 0; KSNBYCc--) {
        BvKWgmw *= MdTnZRLRthOye;
        IowcCL = MdTnZRLRthOye;
        jonmjRcpSGfbEI /= jonmjRcpSGfbEI;
    }

    return rmAHDVUve;
}

string KlRNiztAdkShg::bUOqCQdmN()
{
    bool RzHAbQIuIWm = true;
    string uNqmwliTMpJWi = string("bLIBjLHUNTmcfjkJIWvBGjRSlkHwqpRAcBzWnbykJEiSjUMPmFgsTvNTPnCvZBbqTEfAFeGZPGBGFqfoWxcHHAvLiNUGBdyXwiyFuykhdussddMmGwNKZbFTJKffjoHnEdgoSYHqEWgVvtIYQgJKQfPCOKceyIBqljGIuwupGkVWi");

    if (RzHAbQIuIWm == true) {
        for (int csKle = 312064939; csKle > 0; csKle--) {
            RzHAbQIuIWm = RzHAbQIuIWm;
            RzHAbQIuIWm = RzHAbQIuIWm;
        }
    }

    return uNqmwliTMpJWi;
}

string KlRNiztAdkShg::AvSUQa(string hRTCi, int BGdVFMklVj, double OJRCdHFZQX, bool xRHiWqtqkroHJ)
{
    double JZDrTC = 798649.5815901827;
    bool GwzETwPK = false;
    double SKwHgz = 404378.49371449806;
    int sezIOkSoJvlMA = 369134974;

    for (int fFdOOu = 1812921031; fFdOOu > 0; fFdOOu--) {
        sezIOkSoJvlMA -= sezIOkSoJvlMA;
        SKwHgz /= SKwHgz;
        BGdVFMklVj += sezIOkSoJvlMA;
    }

    for (int EjIvq = 292331389; EjIvq > 0; EjIvq--) {
        continue;
    }

    if (OJRCdHFZQX < 451369.7993324306) {
        for (int pVGmsoD = 980473388; pVGmsoD > 0; pVGmsoD--) {
            BGdVFMklVj = BGdVFMklVj;
            SKwHgz -= SKwHgz;
            JZDrTC -= OJRCdHFZQX;
        }
    }

    for (int wzjVfMMLLJCLx = 924874941; wzjVfMMLLJCLx > 0; wzjVfMMLLJCLx--) {
        xRHiWqtqkroHJ = GwzETwPK;
        xRHiWqtqkroHJ = ! xRHiWqtqkroHJ;
        BGdVFMklVj = sezIOkSoJvlMA;
        JZDrTC /= SKwHgz;
    }

    for (int nrWWXrfAyxPOCe = 101943697; nrWWXrfAyxPOCe > 0; nrWWXrfAyxPOCe--) {
        OJRCdHFZQX *= OJRCdHFZQX;
        xRHiWqtqkroHJ = ! xRHiWqtqkroHJ;
    }

    return hRTCi;
}

int KlRNiztAdkShg::dAMuospuHnos(bool emFSiIpBRlKAVVR, string hLHjIIDeSQuOWZRp, int xeZceuTlbXSmW, int yJuUBqUDdNv, string nZogNb)
{
    string cbnDn = string("LcqYxRuWAlgAwOzEydGAWlBlOYapKaRIgjAauADcazMGINTdmEOOBYIpleopQowQzryRcZJlQIEvWZDwHhGKkoxROWjpsiYJbegAmoaAWLaHnXBndocaJGcMdBVpIamkZNsLJpdaFxsqdbiiBFTLvhnMmRUQqwSSqFalOGw");
    string YHNxN = string("zzApkKTviruRCtvwVlyjKxJrlZdmTXHBYMzZQfqVQhpopBiMzcoBkakNltXfgXWnkwFxBLHhkgL");
    bool RgXMdksSCX = true;
    string dGwToMJHawm = string("TxGaEhpQOdtrD");
    double GjiOxGjwQgrp = 667815.3386491423;
    string VyYBDPW = string("TZwuwwmGtUscfBUeYniCKgFHDfadifASfUqBALJnaRhWLaweIHnGXfvcvZfsdFYixCZpUsHNmRfATONYlNDGAtafJHoUTYbpxErrVhDFrqJiCrOwbXWLUJlmWVsPKWcsrfwMhTehjBiTLTTXxmGgzRgwaWYvJqIrLjyQuKptSaIClnzrUNeKVixKXyOVSrOwwbiHqkzhWNNEgStrgJuZdfdhWOwTDCUxc");
    bool zbHOK = true;
    string ApFoVlZflvzlifEa = string("wxpYmNcdmVioraztoZKWxavAwIJqZdKjfgDlanHCTIUwqbWvkPbaJPTmBzhrhnGKehKZEdguDWdZUXyNvP");
    double GovJobsSgWg = 941472.1587162962;
    double YcZkfmpOQyNEhA = -954258.2935231347;

    for (int VxbhcK = 604422160; VxbhcK > 0; VxbhcK--) {
        YHNxN = ApFoVlZflvzlifEa;
        RgXMdksSCX = ! emFSiIpBRlKAVVR;
        VyYBDPW += dGwToMJHawm;
    }

    for (int gVaXcBIuOfdo = 1021607721; gVaXcBIuOfdo > 0; gVaXcBIuOfdo--) {
        YcZkfmpOQyNEhA += GjiOxGjwQgrp;
        GjiOxGjwQgrp = GovJobsSgWg;
    }

    if (YcZkfmpOQyNEhA >= 941472.1587162962) {
        for (int zxDjH = 2061087280; zxDjH > 0; zxDjH--) {
            VyYBDPW = VyYBDPW;
        }
    }

    for (int eIhVRC = 428734499; eIhVRC > 0; eIhVRC--) {
        nZogNb = dGwToMJHawm;
    }

    if (GovJobsSgWg != 941472.1587162962) {
        for (int fnBFqjskn = 1975372398; fnBFqjskn > 0; fnBFqjskn--) {
            VyYBDPW = ApFoVlZflvzlifEa;
            yJuUBqUDdNv += yJuUBqUDdNv;
            YHNxN = cbnDn;
        }
    }

    if (dGwToMJHawm < string("ByEoyRZbVfZHSXXNYvoBZyasVIfskJnAYgGrjFUyNYpLNjVzgUtBqUlnaxuIyjsbYCcxGYWg")) {
        for (int gqowQfbDgzepF = 316193576; gqowQfbDgzepF > 0; gqowQfbDgzepF--) {
            YHNxN = dGwToMJHawm;
            RgXMdksSCX = ! zbHOK;
            zbHOK = ! zbHOK;
        }
    }

    for (int FrleUTpk = 526964298; FrleUTpk > 0; FrleUTpk--) {
        emFSiIpBRlKAVVR = zbHOK;
    }

    return yJuUBqUDdNv;
}

string KlRNiztAdkShg::UZftaq(bool PaQfbPpeeqz, bool gYmSg, int vuzLAO)
{
    string yqwOiVHJXaImDEqe = string("ILoqlKnWayKYBwBeIXukzuXYDUrTDQuaSmxqPiRpyEQcRcuQUOwdkhUPLZzvrZhPOFtgxhOrEGmRpEiLBoueIPfjiLqPPFtEudcewJMSxSkwhXvhyJcgOegCMAystfAGKfdzpYrsAFPjibGgWnsTSiADadplFHXaBoPcwjWuECcLYDWaBinjXtlrFHFSLVZZFQBlRdfr");
    string OMdUvzbrugr = string("HuHQtQIZbtnWUqqNvTKdDFBbtbTtAFqEtWyRdgzsQwVSNlXANRelFuOVqptfkZdzkZZksnKDMkHSEVeSPCrmOAKZQjVZDsbinfAaeOLwMHMiOKZrWzsRLVkXJOevVfuRftnePcNaxVnbDRjnIvQTOchtTLFcrJhSmnMukyrtNsMuqEXNdoC");
    string eoQmxHOoTQ = string("UFaVHhfvZSvKlxOVUwzvceqFnABBQtaDBSfDUlWQpTTjznbiSHTjPTUNKlwTlQxTSBhVxinOHojLTyvFMZWLuNxDMrulygPzvuKgEmdjmaUIkrVtNnIMFIjPyoxNsvVJkuuwLFpHMOOL");

    if (PaQfbPpeeqz != true) {
        for (int MvNZdfgZD = 189438004; MvNZdfgZD > 0; MvNZdfgZD--) {
            continue;
        }
    }

    for (int UOMVwm = 1566888108; UOMVwm > 0; UOMVwm--) {
        OMdUvzbrugr = eoQmxHOoTQ;
        yqwOiVHJXaImDEqe = eoQmxHOoTQ;
        gYmSg = gYmSg;
        PaQfbPpeeqz = ! PaQfbPpeeqz;
    }

    for (int PxCUCMINCTASDy = 1860228285; PxCUCMINCTASDy > 0; PxCUCMINCTASDy--) {
        vuzLAO /= vuzLAO;
        gYmSg = ! gYmSg;
    }

    for (int YnmIwPEzTTqcwuCX = 1929409595; YnmIwPEzTTqcwuCX > 0; YnmIwPEzTTqcwuCX--) {
        PaQfbPpeeqz = ! PaQfbPpeeqz;
    }

    for (int uuuNPn = 1147978045; uuuNPn > 0; uuuNPn--) {
        vuzLAO *= vuzLAO;
        PaQfbPpeeqz = PaQfbPpeeqz;
        PaQfbPpeeqz = gYmSg;
        gYmSg = ! PaQfbPpeeqz;
        eoQmxHOoTQ = eoQmxHOoTQ;
    }

    return eoQmxHOoTQ;
}

double KlRNiztAdkShg::oeljDdt(double Mqqvz, double lexhIWKaDYJEY, bool FqWkFYX, int IMkWNsXisIX)
{
    bool ptWQFthYUvh = true;
    string OeCqqhyHo = string("vfWlVrWVmkJBFdqdrSvcMtbfjuUsamUObxvZnxBmJBrlwpjVtChwmQGwfvyvcQJTKKAgKUXCROFJgajqFpnXQRoeVVaphpaKdNNzquONZFiLemfDQtOpysMSKctvLUtDzxyoGRMQEPEcWyDnVYAxSfvaNDFLWITRSejiRmIpDSKWQrNcLwNTLtKuVBPFeNDAPQ");
    int VcUTo = -274942910;
    int NuaMqjylPdiJGIe = -2049349685;
    int gVEvxxEgt = 1485006040;

    return lexhIWKaDYJEY;
}

int KlRNiztAdkShg::nRuYdt(double QnFDMSc, int gjSrL, int iJZxNQSH)
{
    int ehOCdFWFPFPSz = 2056834575;
    string ZMNEcmDNXL = string("gxCmQHBzJby");
    bool dXWqKsJFGOuy = true;
    double fpSlI = 799198.2336614402;

    for (int KQGOuRhJKcWnWa = 1922873251; KQGOuRhJKcWnWa > 0; KQGOuRhJKcWnWa--) {
        continue;
    }

    return ehOCdFWFPFPSz;
}

double KlRNiztAdkShg::knbqfHmQVDuIwZ(int ljQiOYsbNDGvE, string ATVUZfkzeKAoYVgo)
{
    string jGMfSDVh = string("HO");
    double WTFoG = 546153.5426334318;
    string jcsLJlBqEFdG = string("btPuaVitiAUzDsLtOsYxobQNHbgUrhIcHvGkbpaHXrjiYdvKhtaUSKpqZnJBhDoWrqhVIhJcDMMqtUKNOpxeAsvGNPYiceMMAHmUYzWUgTPOGupOXZYomUIduOctvKCTTshWLWYTdtTZJZTlLFPLNqNVuHtnndqWQmeitIMFipxjikalltjCJFJYHZzHKSLyXRvtES");
    int PjbLXQxhmAWauTYT = 1297669851;
    double mTzhsCxbmT = 211918.69859971578;
    bool qwbGPzsLULFFNGjc = true;

    return mTzhsCxbmT;
}

int KlRNiztAdkShg::VpcOUOlljtpZPAL()
{
    double UqDwRUAbXPkL = 836717.3296312552;
    int pbpoktX = 1817609092;
    int AdkJYPiRyUnLEFWy = 668286687;
    bool rXWAqTt = false;
    double rIILzqoYtj = -578038.8698969195;
    double SyykUPe = 997470.0652120605;
    bool oLeGQQ = false;
    bool mbUflGtuQeSfrcl = false;

    for (int RnoPswXJihFBTdE = 91679995; RnoPswXJihFBTdE > 0; RnoPswXJihFBTdE--) {
        continue;
    }

    for (int CWgSRyLRouTEmI = 1740140044; CWgSRyLRouTEmI > 0; CWgSRyLRouTEmI--) {
        continue;
    }

    return AdkJYPiRyUnLEFWy;
}

void KlRNiztAdkShg::DwWOrSfl(bool DpjxxhF, bool jZtLGNRupQF, double jDtAv, bool taOzjRQFMElgj)
{
    int hkomnDmaY = 145074564;
    double RSdElugxhoqjzS = 968350.6159697525;
    double QQaKyEFbTqmitN = 323236.3583468271;
    int YUrSKHyCPmBVbDm = 1984644545;
    int daCUQZvOtnxDQkDs = -924519451;

    if (DpjxxhF != true) {
        for (int eNleDpO = 2125839870; eNleDpO > 0; eNleDpO--) {
            DpjxxhF = ! jZtLGNRupQF;
            jZtLGNRupQF = jZtLGNRupQF;
        }
    }

    for (int LTSeSVVnCUH = 1995786679; LTSeSVVnCUH > 0; LTSeSVVnCUH--) {
        jDtAv += jDtAv;
        DpjxxhF = DpjxxhF;
        taOzjRQFMElgj = jZtLGNRupQF;
        QQaKyEFbTqmitN += QQaKyEFbTqmitN;
    }

    for (int uTWsPzxnTYf = 1226476844; uTWsPzxnTYf > 0; uTWsPzxnTYf--) {
        continue;
    }

    for (int brxay = 1910565430; brxay > 0; brxay--) {
        taOzjRQFMElgj = jZtLGNRupQF;
        taOzjRQFMElgj = ! DpjxxhF;
        jZtLGNRupQF = ! DpjxxhF;
    }
}

double KlRNiztAdkShg::vfVWhpJldcfqft(double MWFvns, string vNSFEMRV, string CjgSiTd, double UFlVStKAyW, bool uDoyZ)
{
    double LICWUPMoYWojQnRG = -274095.0169207933;
    bool OSHxOAoWjxCxWaJu = false;
    string dOOnMOXAnlXxAvw = string("NHEdIrIecoeIDyZbautchWXVAOggWSIqqBVFNbXinZQLGXwOFxECsqPhWCmLxSuIttqrpuvABTpwrOboUciOhoYuBsEiJiEIvhrkeUWJNZZOpIppZYSGTmA");
    double oIoeiiATNCA = -269668.22877297766;
    int LUBHchIqt = 739076167;
    string nzaqVwa = string("gBQBvwIWsMeHWbpiWxCCOjTTNAEuSncviZqAwOuQWamBCmZbKZmOWqcYDZbbcCVqiJtejFGjRMAoLoDeLaWjwxUxqCTcYMyLWEtLJoqxtBeipiZvAbtVQDPcCmJWUbXwByfTzJTuroR");
    double ttVaZlbJqa = -696394.9908567471;
    bool gVkBnkCBZBZ = true;

    for (int idotzuvfshGLqos = 1348217089; idotzuvfshGLqos > 0; idotzuvfshGLqos--) {
        vNSFEMRV += CjgSiTd;
    }

    for (int BIWKzzhWsxwtuBNj = 547362157; BIWKzzhWsxwtuBNj > 0; BIWKzzhWsxwtuBNj--) {
        ttVaZlbJqa = oIoeiiATNCA;
    }

    for (int KyQDbzOzBzefX = 627354861; KyQDbzOzBzefX > 0; KyQDbzOzBzefX--) {
        UFlVStKAyW = LICWUPMoYWojQnRG;
    }

    for (int IIkPgCGUamuNjgru = 105723061; IIkPgCGUamuNjgru > 0; IIkPgCGUamuNjgru--) {
        MWFvns /= oIoeiiATNCA;
    }

    if (ttVaZlbJqa != -696394.9908567471) {
        for (int eavVOYMKTYQrdpB = 629639113; eavVOYMKTYQrdpB > 0; eavVOYMKTYQrdpB--) {
            UFlVStKAyW = ttVaZlbJqa;
            UFlVStKAyW -= MWFvns;
        }
    }

    return ttVaZlbJqa;
}

double KlRNiztAdkShg::PHQrjotncMiEtiP()
{
    int fWScdd = 1135839355;
    bool RCyQVsGFG = true;
    bool dQeya = true;
    int FbUouniWlxqqPhfE = 83195557;
    bool BolKRfd = true;
    int dIKdta = 1098413031;
    string zUjjuHzJQUW = string("fQZnSvphOmzbwomfZBTUzLhMaqYEteGXamEcZcmHYhfdMBFfd");

    return -13287.854022708112;
}

int KlRNiztAdkShg::JDDqCXPxtumOJp(string adtFkNIOW, double cxfenGjr, string RaBoQWCY)
{
    bool wclTvLKqcYdHThN = false;

    for (int rGjBNFXqZKHGem = 1693972655; rGjBNFXqZKHGem > 0; rGjBNFXqZKHGem--) {
        wclTvLKqcYdHThN = ! wclTvLKqcYdHThN;
        adtFkNIOW += RaBoQWCY;
        wclTvLKqcYdHThN = ! wclTvLKqcYdHThN;
        RaBoQWCY = adtFkNIOW;
    }

    for (int XjtsirrMVX = 1646242728; XjtsirrMVX > 0; XjtsirrMVX--) {
        cxfenGjr /= cxfenGjr;
    }

    if (adtFkNIOW == string("gSspilqewbHBIbLtRiEAIFCcfzKoNHdFBTIaNSnhfbQZdIsWaYElcIaPbrYzpACFvwOauxjtwIzuVNXZiFEeXlITHGssLKSTUNAhFsIjRvXiCNVzkAHTtsRoXRPJGrUgTDmSnWGZphsRuXKXmvWuAihnatNNJFvWLBObFSEuStwNTykZiYoQUIXLNSixgjuQYlUiqgkISvTwRXBNrUBGKCHrvwTVRXVbUU")) {
        for (int AukYJQYkReqMbA = 118394721; AukYJQYkReqMbA > 0; AukYJQYkReqMbA--) {
            adtFkNIOW = RaBoQWCY;
            adtFkNIOW += adtFkNIOW;
            adtFkNIOW += RaBoQWCY;
            cxfenGjr += cxfenGjr;
        }
    }

    for (int MPjbkVVDZquapD = 1329248045; MPjbkVVDZquapD > 0; MPjbkVVDZquapD--) {
        RaBoQWCY += RaBoQWCY;
        wclTvLKqcYdHThN = wclTvLKqcYdHThN;
        RaBoQWCY += adtFkNIOW;
        wclTvLKqcYdHThN = ! wclTvLKqcYdHThN;
    }

    return 1750376387;
}

string KlRNiztAdkShg::KCAaaCsu(int xlWsyC, string kRnKXGeplWGAbvJi)
{
    bool QlhBHPAQ = true;

    for (int SyDKcNirWfwC = 1800351523; SyDKcNirWfwC > 0; SyDKcNirWfwC--) {
        kRnKXGeplWGAbvJi = kRnKXGeplWGAbvJi;
        xlWsyC *= xlWsyC;
        QlhBHPAQ = ! QlhBHPAQ;
    }

    for (int ejoIg = 166965700; ejoIg > 0; ejoIg--) {
        continue;
    }

    if (kRnKXGeplWGAbvJi >= string("ygugGItrPOgFhKbnIrvuRfMyRVlleMwrrrWwULWViKfRsEPxncinFCPsezdJocyakvCkkPmugfRkZqsPqRGgKOrzwgCEDRdRESbVsWJiXFAfKiWfTtRTSQpoGbPgyLUZQPCOifesTRARJQeuopZcGD")) {
        for (int ETnMPUSiWGNldj = 69080378; ETnMPUSiWGNldj > 0; ETnMPUSiWGNldj--) {
            xlWsyC *= xlWsyC;
            xlWsyC = xlWsyC;
            kRnKXGeplWGAbvJi = kRnKXGeplWGAbvJi;
        }
    }

    for (int YdQGXfVTCMKFDYUu = 2046125559; YdQGXfVTCMKFDYUu > 0; YdQGXfVTCMKFDYUu--) {
        QlhBHPAQ = ! QlhBHPAQ;
    }

    return kRnKXGeplWGAbvJi;
}

int KlRNiztAdkShg::PNZcZm(bool WsuJna)
{
    bool vEpZZYEQTYn = false;
    bool cjtPzpx = true;

    if (WsuJna == false) {
        for (int xHufNC = 1229625470; xHufNC > 0; xHufNC--) {
            vEpZZYEQTYn = WsuJna;
            cjtPzpx = ! vEpZZYEQTYn;
            WsuJna = ! cjtPzpx;
            cjtPzpx = vEpZZYEQTYn;
            cjtPzpx = vEpZZYEQTYn;
            cjtPzpx = vEpZZYEQTYn;
        }
    }

    if (vEpZZYEQTYn == true) {
        for (int VesbwNkvRLZAEHAl = 1090248008; VesbwNkvRLZAEHAl > 0; VesbwNkvRLZAEHAl--) {
            cjtPzpx = ! vEpZZYEQTYn;
            vEpZZYEQTYn = vEpZZYEQTYn;
            WsuJna = ! WsuJna;
            vEpZZYEQTYn = ! cjtPzpx;
            vEpZZYEQTYn = ! cjtPzpx;
            vEpZZYEQTYn = ! WsuJna;
        }
    }

    if (WsuJna == true) {
        for (int SZUMkheLZgRLDP = 618333304; SZUMkheLZgRLDP > 0; SZUMkheLZgRLDP--) {
            cjtPzpx = ! WsuJna;
            vEpZZYEQTYn = ! vEpZZYEQTYn;
            cjtPzpx = cjtPzpx;
            vEpZZYEQTYn = ! WsuJna;
            WsuJna = ! cjtPzpx;
            WsuJna = WsuJna;
            vEpZZYEQTYn = vEpZZYEQTYn;
        }
    }

    return 465959029;
}

double KlRNiztAdkShg::bCtPAIhuVdEXDd()
{
    double rKdhppqFo = -138246.216208661;
    string hSZlUjOprXvYpxTW = string("SNEscjiPxCyUlnRFqGafDGphWFCpZTRtotfXCdaImDzTAktUklKVtXVepToThnzKIebaklTiRnkepEWrRojZnejhjlJAZfOoqnNoTLhLHMPRRVfbWFbcoJbqSPKMhTHISzcFqIyuHufKLVXmKjFSZnkaKHvsnrWSilQOlmvengpCOOFZoxuevfMquhyGnpMKSUxPmMTUnZtAUamVQRSulyRhdHQYzEiHASRIWEvBuRiehprJ");
    int jCHihUafdFaJAz = -1216594549;
    bool Odyzz = false;
    double XbHaJAkVYRo = 623175.1487047919;
    double yVChDTbqa = 543978.8219406978;
    bool quRQdcrYapW = false;
    bool FkwkfHxkxsvJ = true;
    bool LOsGPdjKR = true;

    if (yVChDTbqa != 623175.1487047919) {
        for (int hTjLiwbkWyqhdYrn = 1927389695; hTjLiwbkWyqhdYrn > 0; hTjLiwbkWyqhdYrn--) {
            LOsGPdjKR = ! LOsGPdjKR;
            Odyzz = quRQdcrYapW;
            quRQdcrYapW = ! Odyzz;
        }
    }

    for (int mkRfLTzwBB = 608846893; mkRfLTzwBB > 0; mkRfLTzwBB--) {
        Odyzz = ! FkwkfHxkxsvJ;
        Odyzz = ! Odyzz;
    }

    for (int jUvJfPZmxG = 218037503; jUvJfPZmxG > 0; jUvJfPZmxG--) {
        quRQdcrYapW = ! quRQdcrYapW;
        Odyzz = ! quRQdcrYapW;
        quRQdcrYapW = ! FkwkfHxkxsvJ;
    }

    return yVChDTbqa;
}

KlRNiztAdkShg::KlRNiztAdkShg()
{
    this->eDpshXutWq(-465267986, false);
    this->CpPbKRGYxpCXi();
    this->bUOqCQdmN();
    this->AvSUQa(string("wkxvkqMKxoUhxArNLYcdqrHVuqafmSJLFMMYQL"), -1026456459, 451369.7993324306, true);
    this->dAMuospuHnos(false, string("ByEoyRZbVfZHSXXNYvoBZyasVIfskJnAYgGrjFUyNYpLNjVzgUtBqUlnaxuIyjsbYCcxGYWg"), 817859108, -1481130539, string("UsyYDZodwisKtgjJbxwWHdlSlieJNBOmqAIefbbQJFnKJWqgnKhuZGWLoRmJpzfyhJysVxFathbfpebuyxTjiGn"));
    this->UZftaq(true, false, 388578233);
    this->oeljDdt(-991737.2351491568, -439661.5605785755, false, -1496319615);
    this->nRuYdt(914411.3814832303, -1347441, -1404207456);
    this->knbqfHmQVDuIwZ(-1900385238, string("yixZWClUrThcqgKvOLazvYTTMjZeFpZQHCTgpQAwXGUbcqsTHkREksQbJqfwuELlySZdklgozkcTmXeEEBqYRpWkmNVYUKHPKYvKztDZnTAMcAeYlxoWUnkRHvUXQvQy"));
    this->VpcOUOlljtpZPAL();
    this->DwWOrSfl(true, false, -781441.0415666207, true);
    this->vfVWhpJldcfqft(583397.4245399685, string("KbwTsbMUJxREuxQDdiPJLchNgYWGrnckAUvSGDGzMniBDOiXtgOvMObVOSDHviLFHzfDCqktVaTJFDxKbhZlacnaZlhOTiphDxxuDhDQfRyFFdrmIZYHcXQsSfMa"), string("LwKEuhLHaFkqWniWakRYudNmwmiyHCSZoCdpRgVFagONLUHcyWISuAzrrjsVWJFPODBblxJLpkgEeFHclxTxqmJkmKVrBXzkOlHMvPtAzHivjiDnjRLmMYsqnivQbRSPUWUGBpKkQXQNDGuofxYdOujtbAsXQyylTaBJtYMrFYeRPUHZWaCQoaSyOzpmCcBQRBtvscGwfMJjmQsSBIYEXLzYUREMsTAh"), 298709.32607551245, false);
    this->PHQrjotncMiEtiP();
    this->JDDqCXPxtumOJp(string("gSspilqewbHBIbLtRiEAIFCcfzKoNHdFBTIaNSnhfbQZdIsWaYElcIaPbrYzpACFvwOauxjtwIzuVNXZiFEeXlITHGssLKSTUNAhFsIjRvXiCNVzkAHTtsRoXRPJGrUgTDmSnWGZphsRuXKXmvWuAihnatNNJFvWLBObFSEuStwNTykZiYoQUIXLNSixgjuQYlUiqgkISvTwRXBNrUBGKCHrvwTVRXVbUU"), -487355.0777613206, string("pYkgWsahSTcvieureFjypyXFThRoEMKNPUDZwfCBkVhnblMtkgrATtyYExhJCvXEHYGXKhmZfxeolUWzZbXdJLwzmyAocoIUAoWIZ"));
    this->KCAaaCsu(-1515783204, string("ygugGItrPOgFhKbnIrvuRfMyRVlleMwrrrWwULWViKfRsEPxncinFCPsezdJocyakvCkkPmugfRkZqsPqRGgKOrzwgCEDRdRESbVsWJiXFAfKiWfTtRTSQpoGbPgyLUZQPCOifesTRARJQeuopZcGD"));
    this->PNZcZm(true);
    this->bCtPAIhuVdEXDd();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class adRZVplIgKjoXqYL
{
public:
    double ZmCcZSqqrj;
    int etEaLhTHGBiU;
    bool kjWCdyID;
    bool PHUEczryG;

    adRZVplIgKjoXqYL();
    double ZZZaQwJ(bool MOUIjsPaO, bool auZemHdN, bool KOwje);
    string DLeFSZFlBMzdzzKv();
    bool UmsCdLAZwYNdnbJl();
protected:
    double deknoDnniJClp;

    void WBdaNReMwTbCc(double nLgdvazSkgaLgeK, double dIjIcMGXDIbHx, double RuqMGmeiilzM);
    int OmBEYo(int exuahb);
    string lEZwPQZSzJSYG();
    int GGPknjJoEDs(bool czTHydX, string tQDMA);
    bool cgqTiJtMHVlKjUnW(bool EaBcDRN, int XldoLZ);
    double htdnaQoBzkz(bool lAgUsNxd);
    double oImypk(double tpBHYuaQMBlwUh, bool xinJwrZyJFANGC, int RkLXWZAtJZB, int TFnstEzDcDH, double fUiPaNvShFFU);
    double PxVXutuHf(string WSHmppBotATV, double BMjdqzTy, int axCgK);
private:
    int ZTBOIWbPp;
    double JQQDZEyzZrAbHI;
    string zkkKI;

    int qwRMsRdTRyEorVo(double OfuzesvaYItvI, bool RkUURqVmSPeWwg, bool JGeWqIfx);
};

double adRZVplIgKjoXqYL::ZZZaQwJ(bool MOUIjsPaO, bool auZemHdN, bool KOwje)
{
    int VEjgdzhmUMcGAcfM = 1702305193;
    int gahxjMcnRtFA = -1218151898;
    double UqNvuWK = 817190.5729780098;

    return UqNvuWK;
}

string adRZVplIgKjoXqYL::DLeFSZFlBMzdzzKv()
{
    int cDHpVaArHeFM = 1362088490;

    if (cDHpVaArHeFM != 1362088490) {
        for (int dmGJSuCavWuQKl = 1599833212; dmGJSuCavWuQKl > 0; dmGJSuCavWuQKl--) {
            cDHpVaArHeFM -= cDHpVaArHeFM;
            cDHpVaArHeFM = cDHpVaArHeFM;
            cDHpVaArHeFM *= cDHpVaArHeFM;
            cDHpVaArHeFM /= cDHpVaArHeFM;
            cDHpVaArHeFM *= cDHpVaArHeFM;
            cDHpVaArHeFM *= cDHpVaArHeFM;
            cDHpVaArHeFM -= cDHpVaArHeFM;
        }
    }

    if (cDHpVaArHeFM == 1362088490) {
        for (int HIgtBGKszkvCK = 1334929698; HIgtBGKszkvCK > 0; HIgtBGKszkvCK--) {
            cDHpVaArHeFM += cDHpVaArHeFM;
            cDHpVaArHeFM -= cDHpVaArHeFM;
            cDHpVaArHeFM /= cDHpVaArHeFM;
            cDHpVaArHeFM *= cDHpVaArHeFM;
            cDHpVaArHeFM -= cDHpVaArHeFM;
            cDHpVaArHeFM += cDHpVaArHeFM;
            cDHpVaArHeFM /= cDHpVaArHeFM;
            cDHpVaArHeFM += cDHpVaArHeFM;
            cDHpVaArHeFM *= cDHpVaArHeFM;
            cDHpVaArHeFM = cDHpVaArHeFM;
        }
    }

    return string("nvlcmBDyvXvihjKwyTDRsuYywYJlMfVfBFVgGcuYzPyYJTjqCFKIkcYXtoAbGmDMzWEAqzNFeByRWRAlNUGxgxGPWeKrnozVmjmEzOVqYNGPvHPCgGYRPrLTreZOAMNywaGjxbcMsFdvOrgLGyodAuPoGmFWbwEgAFhemoYPZNfwLLgIrPLlkeZkhaOINsDoRMfewbzJFwpqcDTKtQrKqPRszzdmjBrzwsAP");
}

bool adRZVplIgKjoXqYL::UmsCdLAZwYNdnbJl()
{
    string JosqhYoxdG = string("KTQBPfUjuHEVaMHZbwlvwbHcoAgIYCkXMZsvxsmlBAhCZqZxctbNOTojfHlgCxrDfiEpHEaraHpyEDFsWwFaknTxkgRftDxYYvZOEFFppfvRyCap");
    double wjZKrTyJuPQVmpmq = 331994.7141066846;
    bool SAWWcUj = true;
    bool XvcAuccUgoJxv = true;
    string HCVqiksEtDvdY = string("KcfPFUbRDzSfLvxgNRXTmxsuRxvFTiINa");

    if (HCVqiksEtDvdY == string("KcfPFUbRDzSfLvxgNRXTmxsuRxvFTiINa")) {
        for (int HMDpKGpFXvZCZMG = 1107317452; HMDpKGpFXvZCZMG > 0; HMDpKGpFXvZCZMG--) {
            SAWWcUj = XvcAuccUgoJxv;
            SAWWcUj = XvcAuccUgoJxv;
            SAWWcUj = ! XvcAuccUgoJxv;
        }
    }

    return XvcAuccUgoJxv;
}

void adRZVplIgKjoXqYL::WBdaNReMwTbCc(double nLgdvazSkgaLgeK, double dIjIcMGXDIbHx, double RuqMGmeiilzM)
{
    bool YnVLYg = false;
    int KhOgEabjnlaMwEk = 1985587760;
    double pSZuReRGg = 259777.13823813622;
    double oWzhc = 193353.48547112726;
    string KsWBA = string("BiPpgXyAfhCKeCrGNPYbzMrkyESTfBEgtGXqbFEWkbUkGpTEAqHJmvrIqSQzFVQzjcynzViYnkdABeJWtIzfLYUwSdgGabYtBBPDkSBVmgkPcpnObAXznsArVGnbpYCGoKHYgllkXafYyMmXyzCNwZbviRxfrEKKkvGIepDPic");
    double bMaxpdp = 464483.64719899965;
    bool GLLZrugsmmgEg = true;
    string RoLvlUnPjEg = string("lZwSJUawCsuSJYWesuLBsGbrbuVNkFdLxtGCWoypxTgceQlUikUCxzEkQYBrjAisqRwxVKVdSEdhGlFFYQZJrRJcmasHFwbDUKrwWxJCDcGHuzsQeXDJNxZJyWgPMQEemgubsVGVdgiBAeEqeFZtyRbmVEyKaamrbDLotMmFQtlkrvwqfacpXHjGjkAFvYXO");
    double QaBlnyHMEFfiG = 210435.87734289843;
    double ocuBKFuaVVbO = -679529.6159897887;

    for (int UUiah = 1802362601; UUiah > 0; UUiah--) {
        pSZuReRGg *= RuqMGmeiilzM;
    }
}

int adRZVplIgKjoXqYL::OmBEYo(int exuahb)
{
    double YyrbALf = 344332.17434153665;

    return exuahb;
}

string adRZVplIgKjoXqYL::lEZwPQZSzJSYG()
{
    int zLhIBN = 1397582779;
    string OhdIDKeoxtlS = string("SMVVyrfZWMfjXXAXUidUgkSeBkBGhQhaRQICVzeYhyOCvbgbPycFALwhNrbSkizDKtCtseevTZCyAcYLaDOKNAICSUgaBWYuIWAQdNZVTdLMUIHZrsHJlXnJHaeGIQbIOkjgHaHwLoZBOoTVAXEmyrqrcLiXTNYCJSQqSdytctuAjooeIGcIcPhQImExPuACzVJmpk");
    bool ooXiaVHudJC = true;
    string rfaKN = string("jSXEtoolVGcGaaEtzPEcJJWhrkBlcUXRqdyQvkCzrtscMjPYqEtTDHoIjieysDGrrMyCxivjWNUFzGyOlIPrUsRGhjsTFzlVRYHRyYqaiFKtboXwQiDeJnwANsfcTsQHMYHbhHNUxPzRIlMmUhXDyrdMzsJFpwxyeuxmTsbbRTyXSvKomxZhKvhVJoisMDdFgFWmdMzHSRoHbcemvYyVLDIVFGMUvdTVifGsVwnekaeJXsN");
    bool PCXwnQrpFewQObhz = false;
    bool MZHAExl = false;

    if (PCXwnQrpFewQObhz == false) {
        for (int UdmoluKNVoDUvoM = 1833820370; UdmoluKNVoDUvoM > 0; UdmoluKNVoDUvoM--) {
            continue;
        }
    }

    if (OhdIDKeoxtlS >= string("jSXEtoolVGcGaaEtzPEcJJWhrkBlcUXRqdyQvkCzrtscMjPYqEtTDHoIjieysDGrrMyCxivjWNUFzGyOlIPrUsRGhjsTFzlVRYHRyYqaiFKtboXwQiDeJnwANsfcTsQHMYHbhHNUxPzRIlMmUhXDyrdMzsJFpwxyeuxmTsbbRTyXSvKomxZhKvhVJoisMDdFgFWmdMzHSRoHbcemvYyVLDIVFGMUvdTVifGsVwnekaeJXsN")) {
        for (int ipEObGygb = 1223116708; ipEObGygb > 0; ipEObGygb--) {
            PCXwnQrpFewQObhz = ! MZHAExl;
            OhdIDKeoxtlS += rfaKN;
            ooXiaVHudJC = ooXiaVHudJC;
            OhdIDKeoxtlS = OhdIDKeoxtlS;
            ooXiaVHudJC = ! PCXwnQrpFewQObhz;
        }
    }

    if (zLhIBN != 1397582779) {
        for (int Gpwbqzc = 2035022864; Gpwbqzc > 0; Gpwbqzc--) {
            OhdIDKeoxtlS += rfaKN;
            PCXwnQrpFewQObhz = ! ooXiaVHudJC;
            PCXwnQrpFewQObhz = ooXiaVHudJC;
            ooXiaVHudJC = PCXwnQrpFewQObhz;
        }
    }

    for (int aYQhFSt = 888282937; aYQhFSt > 0; aYQhFSt--) {
        zLhIBN = zLhIBN;
        OhdIDKeoxtlS = rfaKN;
        rfaKN += OhdIDKeoxtlS;
        PCXwnQrpFewQObhz = MZHAExl;
    }

    return rfaKN;
}

int adRZVplIgKjoXqYL::GGPknjJoEDs(bool czTHydX, string tQDMA)
{
    bool jUWUkRBkHUF = true;
    string MaqvKD = string("duKpdIfMnGDoCufOmnqPImkPtVbWXuXxlGkcfUhdmqYBNprhlLmqEGrMEGwQeSMODUJZPidhQSyIRuqNLAOFAkWWoScajAvKtLkuYuVOOuKSVYHukpxSgZMBLUJlYpeaEVBYV");
    bool zthXFXilDypObln = false;

    for (int ejcdr = 2052572676; ejcdr > 0; ejcdr--) {
        czTHydX = ! jUWUkRBkHUF;
        jUWUkRBkHUF = ! czTHydX;
        MaqvKD = tQDMA;
        zthXFXilDypObln = ! zthXFXilDypObln;
        jUWUkRBkHUF = ! jUWUkRBkHUF;
        zthXFXilDypObln = jUWUkRBkHUF;
        jUWUkRBkHUF = ! czTHydX;
    }

    for (int dkkwkUHJcU = 1934504437; dkkwkUHJcU > 0; dkkwkUHJcU--) {
        jUWUkRBkHUF = czTHydX;
        tQDMA += MaqvKD;
    }

    for (int EbppMxEiPpKpJAP = 1566779769; EbppMxEiPpKpJAP > 0; EbppMxEiPpKpJAP--) {
        zthXFXilDypObln = zthXFXilDypObln;
        MaqvKD += MaqvKD;
    }

    for (int BomEQQFk = 906530344; BomEQQFk > 0; BomEQQFk--) {
        czTHydX = jUWUkRBkHUF;
        czTHydX = jUWUkRBkHUF;
        MaqvKD += tQDMA;
        jUWUkRBkHUF = czTHydX;
    }

    for (int RtiGEfjfFQIHF = 1066781846; RtiGEfjfFQIHF > 0; RtiGEfjfFQIHF--) {
        tQDMA = MaqvKD;
        MaqvKD = tQDMA;
        jUWUkRBkHUF = ! czTHydX;
        zthXFXilDypObln = ! jUWUkRBkHUF;
        tQDMA = MaqvKD;
    }

    return 1847780746;
}

bool adRZVplIgKjoXqYL::cgqTiJtMHVlKjUnW(bool EaBcDRN, int XldoLZ)
{
    bool TlYahQlzDSDYAv = false;
    double TydcdOf = -507360.4079942988;
    bool njJNPHUVGWXln = false;
    string GQVoSMPoHfyoVQFe = string("cGgqwWJtQAbvBnDDMSAyVxtgSFAXtzPrSLFPdjEbUegQfNuZNIYMSNjPMDJbDsbiIgKtIlSDNDhYRSTnnhdmvmlkCBlVqgLXchJSibJVPcpDanWzStNIYwUSsUoMvmSFOSsApGUknKLyzFkcmbswwyaNtPByYVZhjGDHzmFyxfCxDRgEDykxUIBvbpAprbadcrSzTcxkLjiwbwauLM");

    if (GQVoSMPoHfyoVQFe <= string("cGgqwWJtQAbvBnDDMSAyVxtgSFAXtzPrSLFPdjEbUegQfNuZNIYMSNjPMDJbDsbiIgKtIlSDNDhYRSTnnhdmvmlkCBlVqgLXchJSibJVPcpDanWzStNIYwUSsUoMvmSFOSsApGUknKLyzFkcmbswwyaNtPByYVZhjGDHzmFyxfCxDRgEDykxUIBvbpAprbadcrSzTcxkLjiwbwauLM")) {
        for (int iWWhQ = 753070408; iWWhQ > 0; iWWhQ--) {
            TlYahQlzDSDYAv = TlYahQlzDSDYAv;
            TydcdOf = TydcdOf;
        }
    }

    for (int qtlWRnPNmWQiY = 1442677473; qtlWRnPNmWQiY > 0; qtlWRnPNmWQiY--) {
        continue;
    }

    if (EaBcDRN != false) {
        for (int LjjZrPprZxiKkQB = 2137644472; LjjZrPprZxiKkQB > 0; LjjZrPprZxiKkQB--) {
            continue;
        }
    }

    for (int pUcqipLlCa = 1158271119; pUcqipLlCa > 0; pUcqipLlCa--) {
        njJNPHUVGWXln = TlYahQlzDSDYAv;
        EaBcDRN = ! njJNPHUVGWXln;
        njJNPHUVGWXln = ! TlYahQlzDSDYAv;
        GQVoSMPoHfyoVQFe += GQVoSMPoHfyoVQFe;
        EaBcDRN = TlYahQlzDSDYAv;
    }

    if (GQVoSMPoHfyoVQFe >= string("cGgqwWJtQAbvBnDDMSAyVxtgSFAXtzPrSLFPdjEbUegQfNuZNIYMSNjPMDJbDsbiIgKtIlSDNDhYRSTnnhdmvmlkCBlVqgLXchJSibJVPcpDanWzStNIYwUSsUoMvmSFOSsApGUknKLyzFkcmbswwyaNtPByYVZhjGDHzmFyxfCxDRgEDykxUIBvbpAprbadcrSzTcxkLjiwbwauLM")) {
        for (int sdEdv = 1510405371; sdEdv > 0; sdEdv--) {
            continue;
        }
    }

    if (EaBcDRN == false) {
        for (int aZsKQDFV = 2112155922; aZsKQDFV > 0; aZsKQDFV--) {
            TydcdOf *= TydcdOf;
            GQVoSMPoHfyoVQFe += GQVoSMPoHfyoVQFe;
            njJNPHUVGWXln = EaBcDRN;
        }
    }

    for (int kLcHIuhdPVJvD = 1049623613; kLcHIuhdPVJvD > 0; kLcHIuhdPVJvD--) {
        njJNPHUVGWXln = njJNPHUVGWXln;
    }

    return njJNPHUVGWXln;
}

double adRZVplIgKjoXqYL::htdnaQoBzkz(bool lAgUsNxd)
{
    double uNavnqgQMzcu = -738339.5502843643;
    string CDEbPEozXrMlX = string("FU");
    bool WuqCBpRUnpAZf = false;

    if (WuqCBpRUnpAZf == false) {
        for (int YJeGTxVHY = 727989686; YJeGTxVHY > 0; YJeGTxVHY--) {
            continue;
        }
    }

    for (int hyxFTBlVde = 944972534; hyxFTBlVde > 0; hyxFTBlVde--) {
        WuqCBpRUnpAZf = ! lAgUsNxd;
        uNavnqgQMzcu /= uNavnqgQMzcu;
        lAgUsNxd = ! lAgUsNxd;
    }

    for (int kieWqp = 1083236701; kieWqp > 0; kieWqp--) {
        lAgUsNxd = WuqCBpRUnpAZf;
    }

    for (int xAUpTgrm = 1784985205; xAUpTgrm > 0; xAUpTgrm--) {
        lAgUsNxd = ! lAgUsNxd;
        CDEbPEozXrMlX += CDEbPEozXrMlX;
        uNavnqgQMzcu += uNavnqgQMzcu;
    }

    return uNavnqgQMzcu;
}

double adRZVplIgKjoXqYL::oImypk(double tpBHYuaQMBlwUh, bool xinJwrZyJFANGC, int RkLXWZAtJZB, int TFnstEzDcDH, double fUiPaNvShFFU)
{
    bool XbcfCLmAYVxAySYo = true;
    string dLCPdR = string("etMxCzLRGzZZGiSODmVWveVRszreMHTNANmOaqQtKpXhrpoaHgeKKblVmzPPPDEwanWVMMesxJNjYFzuckIpzJUBKcTZfgJaoEEcCVWLIlcqpCBJtpom");
    int GSaFcSEXBuzPsg = -1123588472;
    bool sIipHtoIWPHll = true;
    string wfnGBlRAmOeAEirC = string("qPJPNoDhYuzkcyFOVoDSFKVeEGJcXKNIVdqQwVRupRpogxhunoeS");
    double MgZyMjjvLTQLMv = 294971.49614408764;
    bool CthZxwWdttcxSd = true;
    int mDGwLbP = 1374612147;

    for (int upnxSwBZzAy = 1965326016; upnxSwBZzAy > 0; upnxSwBZzAy--) {
        sIipHtoIWPHll = ! CthZxwWdttcxSd;
        TFnstEzDcDH /= GSaFcSEXBuzPsg;
        dLCPdR = wfnGBlRAmOeAEirC;
    }

    if (XbcfCLmAYVxAySYo != true) {
        for (int pQUmOyRhy = 1690690828; pQUmOyRhy > 0; pQUmOyRhy--) {
            mDGwLbP *= TFnstEzDcDH;
            GSaFcSEXBuzPsg = GSaFcSEXBuzPsg;
            xinJwrZyJFANGC = ! CthZxwWdttcxSd;
            RkLXWZAtJZB = GSaFcSEXBuzPsg;
            XbcfCLmAYVxAySYo = xinJwrZyJFANGC;
        }
    }

    if (RkLXWZAtJZB <= 335345978) {
        for (int drtkfjhBjfvhK = 1465445379; drtkfjhBjfvhK > 0; drtkfjhBjfvhK--) {
            continue;
        }
    }

    return MgZyMjjvLTQLMv;
}

double adRZVplIgKjoXqYL::PxVXutuHf(string WSHmppBotATV, double BMjdqzTy, int axCgK)
{
    double UnbhAj = 731024.8281832258;
    int iXRKlJaAssJPqLdZ = -2006627479;
    bool mmjLnU = false;
    string zCijJmdCiYaB = string("hFIRbXVabpH");

    if (UnbhAj <= -705568.6164319771) {
        for (int BQldWynZn = 329813122; BQldWynZn > 0; BQldWynZn--) {
            UnbhAj *= UnbhAj;
        }
    }

    if (BMjdqzTy < 731024.8281832258) {
        for (int jXdEK = 702897020; jXdEK > 0; jXdEK--) {
            continue;
        }
    }

    for (int WZTpB = 847931043; WZTpB > 0; WZTpB--) {
        continue;
    }

    return UnbhAj;
}

int adRZVplIgKjoXqYL::qwRMsRdTRyEorVo(double OfuzesvaYItvI, bool RkUURqVmSPeWwg, bool JGeWqIfx)
{
    string FRVbha = string("WZfDsWPeteWoLRYSFablfugcKrbdNkgBXYaYZllfVUInVSAbQgEftfnUabmeDevYbPqzGTDDdSL");
    string VEJJI = string("zvEQmvzlHOGmHAUSbQIUXzPnmSkkoPpfrGspXwYDuyWMqsDVaDptLAByohhskKXUPTJNPHlkYzuEmaqDaXaJAiPmZoDGFiTJixdEixwAsxdLfGOvTUIwmeKyqHyaOGAqNtoNQskRYIOIuWpdrajjADklONjCwHROisheQFFoWRvyFL");
    int wMsczGQqsVQ = -1573902183;
    bool vLOZipQJ = false;
    int FltmbiKhfSpDXl = 1033531262;
    bool blbDBBRHdjeM = true;
    string BugptzVHjpPXyH = string("QzOjVUQaDWsNHSXeUQViPsfOxQdJuruMgmQLVgHVSknvpXtIdVJGSvcj");
    double hOZMAP = 1026598.1523086528;

    return FltmbiKhfSpDXl;
}

adRZVplIgKjoXqYL::adRZVplIgKjoXqYL()
{
    this->ZZZaQwJ(true, false, true);
    this->DLeFSZFlBMzdzzKv();
    this->UmsCdLAZwYNdnbJl();
    this->WBdaNReMwTbCc(703219.489825335, -1011293.0821248468, -787080.1247396538);
    this->OmBEYo(-1850892954);
    this->lEZwPQZSzJSYG();
    this->GGPknjJoEDs(true, string("ugsooiDjbRBgOhPIjsjNqCsMwBdtLOVhJRqpLwUCnpePenBlGIWEGSXHGiZwbnPjknpLkdgKTgcEfYx"));
    this->cgqTiJtMHVlKjUnW(true, -574129580);
    this->htdnaQoBzkz(true);
    this->oImypk(792026.4842386693, true, 335345978, -324312459, -523429.03115703433);
    this->PxVXutuHf(string("RMJqVyERfzfITgcjbeaDQhfownOZENoAHyuvdNKpxEZPcmCCXDGYVmLpFOjTgLqxnVJVruwkcwpHAYcSRpMhzFCrMFpmzNeiJkLgGmrQuiSISYNvMYJMYFpLqtBUHJyTSGrXjNtGrQANR"), -705568.6164319771, 1702054458);
    this->qwRMsRdTRyEorVo(-615159.9755334874, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eHaglouOLHkwU
{
public:
    bool KHoRBPLQrCJXAiH;
    bool AbLQYUyJEmyMCNjm;
    double enkonZmeOHzO;

    eHaglouOLHkwU();
    void iPZEvrAEtnMxej(double RVuSTeeXxRyBN, int AlwYzHlWb, bool IKBxbC);
    void qvASz(int MPRdx, int tOwlizJSGiAAqi, int OASpniI, double bDOFzj);
protected:
    bool pikxczfPC;
    double WErrQrEfqV;
    double iYSCCUHXa;

    int hHSmFhAQmrWPcomN(bool PqFldBuKapT);
    bool uFPfRjlDZqAphjTg(double EvvfhkRXYt, bool BjPHobWuxvZB, double lwolayBqsGhOo, int uJMDnlLlwlrxMtUX);
    string aYfrOydMWJxQzP(bool mVxYJonm, double KcFcXIbCY, double GFjrznKJgUuvI);
    bool gJpDUZJGD(int mWwMHQ, string PmTOe, double JfSoUq, bool LgjplVvV);
    void xgAEOUjDNJA(string euFuFRNB, int uSiJeoOUxTzyB, int fjFkpyWeYCR, bool cASAGkQdayBdOCF, double BOTtLVKBDsTznKq);
    double eYMXA(string GCkeCJWreFwJ);
    void aSPBaAO(string CSZeEtGDPPhj, string jfHUoErJENYVvquf, int BWzwBVPcchGy, string yzjLCLu);
    bool fwkmRtDRhyyVtTg(bool mPXKFdRACGGL, bool yzPekpftxrLS, int WoFsYiUhp, double iZywVTEzvdgA, double mBnAtNHrZ);
private:
    double ycltQicyBOEjILCT;
    string VyRDEnwZyB;
    int JvhOdPmjxiK;
    double hMcrWlhrOX;
    string wXrUyZsfx;
    string UAMtKGPjpI;

    int NIgKEKQCHj();
    string UpSzxgZVsVLrmBXd(bool hUCFFPJgVRc);
    string SniiEAAdTqCSdS(bool banZvV, double BXHaIPlcCkBaxsq, double QtNPNNDuvq);
    int AjNoGVlejbIOyHn(string CoJazdLJi);
};

void eHaglouOLHkwU::iPZEvrAEtnMxej(double RVuSTeeXxRyBN, int AlwYzHlWb, bool IKBxbC)
{
    double SUiZuFvFmHCONh = -103292.88577264277;
    double KTFzdIklqO = 467702.0729433125;
    double TxQTJp = -162150.83737560012;
    bool GNiclrvCUvTY = false;
    int hBhpCkucLJtI = -2074379668;
    bool RYZpO = true;
    int mwBywHcqav = 1995574976;

    for (int YDSTH = 2057819530; YDSTH > 0; YDSTH--) {
        IKBxbC = RYZpO;
        KTFzdIklqO -= KTFzdIklqO;
        GNiclrvCUvTY = ! GNiclrvCUvTY;
    }
}

void eHaglouOLHkwU::qvASz(int MPRdx, int tOwlizJSGiAAqi, int OASpniI, double bDOFzj)
{
    double JDzEAYeYcC = 624760.1838782516;
    double mITMqVhjGstKpl = -54437.195083148494;
    string PtuUk = string("THaLerBbDquOTIEPblqfEpIOeUVePEHSIXNjtExulkeGAamrlhrkpyJPSksMDgpVmZueJclNqXrTwTOPhLagQydURqsaatZzerCDRIEeACJSrbJl");
    double FiDzWeNPmdElLG = 464308.1292430733;
    bool xHUkAjkchHEr = false;
    string SluTmFGjcZZe = string("jdlfbyKaecHnUlDjigWnuZrExwDt");

    for (int YwkWNQF = 1076405701; YwkWNQF > 0; YwkWNQF--) {
        continue;
    }

    for (int fDQrx = 329314536; fDQrx > 0; fDQrx--) {
        bDOFzj *= JDzEAYeYcC;
        tOwlizJSGiAAqi -= tOwlizJSGiAAqi;
    }

    for (int kikKg = 1780058411; kikKg > 0; kikKg--) {
        bDOFzj *= JDzEAYeYcC;
    }

    for (int dKTNzjJUUJq = 484607030; dKTNzjJUUJq > 0; dKTNzjJUUJq--) {
        PtuUk = SluTmFGjcZZe;
        SluTmFGjcZZe = PtuUk;
    }

    if (FiDzWeNPmdElLG > 464308.1292430733) {
        for (int bULNGJFVajbhfrN = 1868889616; bULNGJFVajbhfrN > 0; bULNGJFVajbhfrN--) {
            bDOFzj -= FiDzWeNPmdElLG;
            xHUkAjkchHEr = xHUkAjkchHEr;
            MPRdx -= OASpniI;
        }
    }

    for (int HtzdK = 614555979; HtzdK > 0; HtzdK--) {
        JDzEAYeYcC /= mITMqVhjGstKpl;
        mITMqVhjGstKpl -= JDzEAYeYcC;
    }
}

int eHaglouOLHkwU::hHSmFhAQmrWPcomN(bool PqFldBuKapT)
{
    string eIcTVduBxCY = string("mRzOMUYovkjQicuiEKKBRkUrohJrQFpqDixqWxxDRmPkGfU");

    if (eIcTVduBxCY < string("mRzOMUYovkjQicuiEKKBRkUrohJrQFpqDixqWxxDRmPkGfU")) {
        for (int DDtbY = 2001398470; DDtbY > 0; DDtbY--) {
            eIcTVduBxCY += eIcTVduBxCY;
            eIcTVduBxCY = eIcTVduBxCY;
            eIcTVduBxCY += eIcTVduBxCY;
        }
    }

    return -916788980;
}

bool eHaglouOLHkwU::uFPfRjlDZqAphjTg(double EvvfhkRXYt, bool BjPHobWuxvZB, double lwolayBqsGhOo, int uJMDnlLlwlrxMtUX)
{
    double tZcyFvXgHp = 509474.1646640141;
    bool aLSBzNAgLvZL = false;

    if (lwolayBqsGhOo >= 745164.909659891) {
        for (int hUnGbDlcvC = 1194945048; hUnGbDlcvC > 0; hUnGbDlcvC--) {
            tZcyFvXgHp -= tZcyFvXgHp;
            lwolayBqsGhOo *= EvvfhkRXYt;
        }
    }

    for (int BTQlORckIegnd = 1075180956; BTQlORckIegnd > 0; BTQlORckIegnd--) {
        EvvfhkRXYt /= lwolayBqsGhOo;
        tZcyFvXgHp -= tZcyFvXgHp;
    }

    if (tZcyFvXgHp == 509474.1646640141) {
        for (int QnWRXMeyhugGKAo = 1360954168; QnWRXMeyhugGKAo > 0; QnWRXMeyhugGKAo--) {
            continue;
        }
    }

    if (tZcyFvXgHp >= 509474.1646640141) {
        for (int GLMjniTOcfMfNxb = 880461431; GLMjniTOcfMfNxb > 0; GLMjniTOcfMfNxb--) {
            BjPHobWuxvZB = BjPHobWuxvZB;
        }
    }

    return aLSBzNAgLvZL;
}

string eHaglouOLHkwU::aYfrOydMWJxQzP(bool mVxYJonm, double KcFcXIbCY, double GFjrznKJgUuvI)
{
    string BsedxjmrmGEwpg = string("DnMZZUupphJnqYWhTfukNhEZAfnjBJsVWrEtaEIIZIqoxVwXSxPnyqGePZzgWrzBuPWWwTqVABWxhMusARHQkxZixClHsUxOIxvNUiWi");
    double GQoGNwAe = 26499.834778267643;
    bool EitOCp = true;

    for (int kjuWBZtUVexHY = 514105513; kjuWBZtUVexHY > 0; kjuWBZtUVexHY--) {
        mVxYJonm = ! mVxYJonm;
        GFjrznKJgUuvI = GFjrznKJgUuvI;
        GFjrznKJgUuvI *= KcFcXIbCY;
    }

    for (int PoutpgJBcE = 860556356; PoutpgJBcE > 0; PoutpgJBcE--) {
        EitOCp = ! mVxYJonm;
        GFjrznKJgUuvI *= KcFcXIbCY;
    }

    for (int laUcPpfFHakT = 147598207; laUcPpfFHakT > 0; laUcPpfFHakT--) {
        GFjrznKJgUuvI *= GFjrznKJgUuvI;
    }

    for (int xCyscp = 486426876; xCyscp > 0; xCyscp--) {
        mVxYJonm = EitOCp;
    }

    return BsedxjmrmGEwpg;
}

bool eHaglouOLHkwU::gJpDUZJGD(int mWwMHQ, string PmTOe, double JfSoUq, bool LgjplVvV)
{
    int kDXYq = -550977505;
    double tSALlHHDH = 781567.8841751814;
    string HfgBbC = string("hNIyITOxBSTIGewCqhccwkpmdznOjZgSXSkZnZkftotGSQRUUhvzxSqJPPQUcLfGLfUXULmikBsGH");

    for (int UdfCyJXWIQIvVekr = 934017948; UdfCyJXWIQIvVekr > 0; UdfCyJXWIQIvVekr--) {
        mWwMHQ -= kDXYq;
        HfgBbC = HfgBbC;
        mWwMHQ += kDXYq;
        JfSoUq *= JfSoUq;
    }

    for (int AZVKWHdTdRzJYZG = 1913468583; AZVKWHdTdRzJYZG > 0; AZVKWHdTdRzJYZG--) {
        tSALlHHDH *= JfSoUq;
    }

    for (int odoIhx = 1168171259; odoIhx > 0; odoIhx--) {
        continue;
    }

    for (int JbauaQRPtlgm = 1500634699; JbauaQRPtlgm > 0; JbauaQRPtlgm--) {
        kDXYq -= mWwMHQ;
        JfSoUq += tSALlHHDH;
    }

    for (int EmVfTciFBEaejy = 1762979098; EmVfTciFBEaejy > 0; EmVfTciFBEaejy--) {
        HfgBbC = HfgBbC;
        mWwMHQ = mWwMHQ;
    }

    if (PmTOe <= string("hNIyITOxBSTIGewCqhccwkpmdznOjZgSXSkZnZkftotGSQRUUhvzxSqJPPQUcLfGLfUXULmikBsGH")) {
        for (int YstgBE = 2011644803; YstgBE > 0; YstgBE--) {
            continue;
        }
    }

    if (HfgBbC == string("C")) {
        for (int LbCniHZFPGIxQGHe = 1778600468; LbCniHZFPGIxQGHe > 0; LbCniHZFPGIxQGHe--) {
            tSALlHHDH /= tSALlHHDH;
        }
    }

    return LgjplVvV;
}

void eHaglouOLHkwU::xgAEOUjDNJA(string euFuFRNB, int uSiJeoOUxTzyB, int fjFkpyWeYCR, bool cASAGkQdayBdOCF, double BOTtLVKBDsTznKq)
{
    bool tvMumvVHBjlJc = true;
    double isSYQhyQYZMJ = 209556.330471495;

    for (int YpbvM = 1267537222; YpbvM > 0; YpbvM--) {
        BOTtLVKBDsTznKq += BOTtLVKBDsTznKq;
        uSiJeoOUxTzyB = fjFkpyWeYCR;
        isSYQhyQYZMJ = isSYQhyQYZMJ;
        cASAGkQdayBdOCF = ! cASAGkQdayBdOCF;
    }

    for (int jrEEyPGO = 288532030; jrEEyPGO > 0; jrEEyPGO--) {
        tvMumvVHBjlJc = cASAGkQdayBdOCF;
    }

    for (int jcTQxmuzZnjoUA = 663163923; jcTQxmuzZnjoUA > 0; jcTQxmuzZnjoUA--) {
        continue;
    }

    for (int vwtUSckAXvvFu = 1332473171; vwtUSckAXvvFu > 0; vwtUSckAXvvFu--) {
        continue;
    }

    for (int ydYSxggcXWJbuQ = 212600045; ydYSxggcXWJbuQ > 0; ydYSxggcXWJbuQ--) {
        continue;
    }
}

double eHaglouOLHkwU::eYMXA(string GCkeCJWreFwJ)
{
    bool MGkbni = false;
    int AMAtiMhaFRcbZ = -1310842210;
    int lOGNNnfaDMAFS = 1129391268;
    int WwVYyhPLT = 2048252199;
    bool tgBMAe = false;
    string pIswp = string("ppsRhApkZBQrjLEKJEARQLybLYVtwYXuHRoTXjuNITjKaaucvTRjepJhDGCMBcfnMEwyEZVnDMxoUPgDGKGZfNMUiixzGyjrnYoVNIpGhlbRtHKyMKlTiNnKMXfrghBBhuPlTTKssuLcJLFIWFVjurEepMHyvyWrOVaDvvHIGnKFPZtHxSJxprloIOruulKQQChSXrMuEPOFVSHJmHxlddsCSIINY");
    int VqmMEgktTP = 1700293907;
    string qdcYpach = string("frydrZrdqapnJZMuJJMWqdVHjQszuaIKhmwDHKTUsbvp");
    bool JxmIuPycwwwX = true;
    string fUCCdVQMfaRHN = string("jreAVyaKDxdTvluvrOyAVkJOZFgSRDnTeyMZxLtzeQKVCTCeCIglLlWjUtNFdfuypRRfFdOtTyTzbQeUrkbYFQeWHeViHXmVjAnZ");

    if (WwVYyhPLT > 2048252199) {
        for (int AcJUkNDgcVxSd = 1132747503; AcJUkNDgcVxSd > 0; AcJUkNDgcVxSd--) {
            GCkeCJWreFwJ += qdcYpach;
            tgBMAe = ! JxmIuPycwwwX;
            pIswp += fUCCdVQMfaRHN;
            WwVYyhPLT /= WwVYyhPLT;
        }
    }

    for (int GmMqugFB = 261628206; GmMqugFB > 0; GmMqugFB--) {
        MGkbni = ! JxmIuPycwwwX;
        MGkbni = ! tgBMAe;
    }

    return -735412.2047868677;
}

void eHaglouOLHkwU::aSPBaAO(string CSZeEtGDPPhj, string jfHUoErJENYVvquf, int BWzwBVPcchGy, string yzjLCLu)
{
    double szCgG = 925717.6602162924;
    int mhmDHEImLCCeHreE = -1828996463;
    bool NXapw = false;
    int GXZITDAHloVV = 794033600;
    double FprYYVJ = -714540.1845047225;

    for (int PEcXrsf = 236767791; PEcXrsf > 0; PEcXrsf--) {
        CSZeEtGDPPhj = yzjLCLu;
    }

    for (int BHQgIB = 1820851283; BHQgIB > 0; BHQgIB--) {
        BWzwBVPcchGy += mhmDHEImLCCeHreE;
        CSZeEtGDPPhj = jfHUoErJENYVvquf;
    }

    for (int cMoYrmCCmDBVV = 962721074; cMoYrmCCmDBVV > 0; cMoYrmCCmDBVV--) {
        szCgG /= szCgG;
    }

    for (int XwmjTa = 1926125118; XwmjTa > 0; XwmjTa--) {
        yzjLCLu = yzjLCLu;
    }

    if (BWzwBVPcchGy >= -1828996463) {
        for (int VApRUHnQUQzD = 1897091395; VApRUHnQUQzD > 0; VApRUHnQUQzD--) {
            CSZeEtGDPPhj += jfHUoErJENYVvquf;
        }
    }
}

bool eHaglouOLHkwU::fwkmRtDRhyyVtTg(bool mPXKFdRACGGL, bool yzPekpftxrLS, int WoFsYiUhp, double iZywVTEzvdgA, double mBnAtNHrZ)
{
    string eQOSrDJC = string("mnlWDxiUuVLAlJIPmnLHRkskbBUGoTuaghPLSFvyZCkzQWPCyLlXRqtyuqsNjrvcFYIDPOCVHyCIDzuTEsoDIYejkQWIWcaEqKDjGaqIvrgtiULoPCdcuTAxnwtmhGHKjVfBQMbUIWZGduVhKELgKOUAEvBiPtqEbdxViMU");
    bool uvdOtROMFkjL = false;

    if (uvdOtROMFkjL != true) {
        for (int NrwvzujNVgab = 411929603; NrwvzujNVgab > 0; NrwvzujNVgab--) {
            continue;
        }
    }

    for (int eiWhlBeiD = 1945496033; eiWhlBeiD > 0; eiWhlBeiD--) {
        uvdOtROMFkjL = uvdOtROMFkjL;
    }

    return uvdOtROMFkjL;
}

int eHaglouOLHkwU::NIgKEKQCHj()
{
    bool GBCuF = false;
    bool JsjCtpeJklEIbkYV = true;
    string mWPRpg = string("WFauXJwSaJfrsebpazChVjrsAPFHUnuyQQOkKNyOmwDVaCQikEYiQvKgJUjzUdVGauhHDOfUXTrHPjENiBObHcoiLGMccsaInoJvKIwptKlTgBPVFDx");
    string XhSAdQoLhpR = string("teoRIxmZufGKJBffwsCxTdxTxaGhxAitZdLSFrHGAQFklutTkhlNBDpbEHBDeUdDHpXsjC");

    for (int lVPwFZzi = 1356914907; lVPwFZzi > 0; lVPwFZzi--) {
        XhSAdQoLhpR = XhSAdQoLhpR;
        GBCuF = JsjCtpeJklEIbkYV;
    }

    if (XhSAdQoLhpR < string("WFauXJwSaJfrsebpazChVjrsAPFHUnuyQQOkKNyOmwDVaCQikEYiQvKgJUjzUdVGauhHDOfUXTrHPjENiBObHcoiLGMccsaInoJvKIwptKlTgBPVFDx")) {
        for (int haYGbmVaDVSuoQAQ = 612810542; haYGbmVaDVSuoQAQ > 0; haYGbmVaDVSuoQAQ--) {
            continue;
        }
    }

    if (XhSAdQoLhpR == string("teoRIxmZufGKJBffwsCxTdxTxaGhxAitZdLSFrHGAQFklutTkhlNBDpbEHBDeUdDHpXsjC")) {
        for (int MEnWwkBClpMYRQjX = 1161513936; MEnWwkBClpMYRQjX > 0; MEnWwkBClpMYRQjX--) {
            GBCuF = ! JsjCtpeJklEIbkYV;
        }
    }

    return 1514040898;
}

string eHaglouOLHkwU::UpSzxgZVsVLrmBXd(bool hUCFFPJgVRc)
{
    bool yoLjKeWtHHl = false;
    double zhyIUKnJmMePC = -395187.88595120027;

    for (int ZBzBTRCCh = 1479109725; ZBzBTRCCh > 0; ZBzBTRCCh--) {
        continue;
    }

    if (hUCFFPJgVRc != false) {
        for (int SmSRtondcUEX = 586225932; SmSRtondcUEX > 0; SmSRtondcUEX--) {
            yoLjKeWtHHl = ! yoLjKeWtHHl;
        }
    }

    return string("rYIUUQjtLnjHGcJQxvSfXFgcLsawRqSdkQuBezhTiRsjrVvLhmjIerONfUOnBdaafQcNLwSUVOjyCxXRNUrLxvLDOfTeJhXqfowXthjNpHTemxQLYFbldLsDJFLeGAtmgfYrDaeuoBlBnyYhqXWbZQUrvjYzjSVsUjwCKMCmRqNSBIsKJTtwCiLJsnKuyNrXfcqLfOgjbdcrmYvaQeoHqHjuLyQcbQPqZadmSmK");
}

string eHaglouOLHkwU::SniiEAAdTqCSdS(bool banZvV, double BXHaIPlcCkBaxsq, double QtNPNNDuvq)
{
    bool ADWZsWRDedFHuq = false;
    string ZiFCYikZgvbT = string("bZKoRXOwxBtQsmfRKLlGGRJXKKWflMJvLpDjiecadyeclwfLaClUpzQgXvwom");
    bool fGyYziYCtVdXv = false;
    string fpnMAb = string("yiIHQCtQipiyWOZBuPheHsxZmidFlDApJxcCSyTndiEkFDbtPhQchuVreBNasZLSPVfPqbbGyuDFwavlXKsbZxtYG");
    int ukevuCU = 190096316;
    int xdCNdRZAzALleNWl = 1071369627;
    string siBHp = string("LFyMAHilhejNBBeOnmXgEbkmmhkiQeuwnTDQmTdYARZtDvxcfJmwCwhEEmvqBxqxOcMdvPTxBviVOtKhUPkPJPrppfpXuYQgVrBWhcnOLwZHkidIzhPJTmvWhsTXbxrJiMWvkSIPQmmROWOlsYUPtqOHto");

    for (int dUpHXizKHNRXF = 612660377; dUpHXizKHNRXF > 0; dUpHXizKHNRXF--) {
        continue;
    }

    if (siBHp < string("yiIHQCtQipiyWOZBuPheHsxZmidFlDApJxcCSyTndiEkFDbtPhQchuVreBNasZLSPVfPqbbGyuDFwavlXKsbZxtYG")) {
        for (int BWAQkJBPLkgNACuu = 1984958707; BWAQkJBPLkgNACuu > 0; BWAQkJBPLkgNACuu--) {
            ZiFCYikZgvbT = ZiFCYikZgvbT;
            BXHaIPlcCkBaxsq /= BXHaIPlcCkBaxsq;
            ukevuCU /= ukevuCU;
        }
    }

    for (int rlRvknXUkM = 1779299693; rlRvknXUkM > 0; rlRvknXUkM--) {
        fpnMAb += ZiFCYikZgvbT;
    }

    if (fGyYziYCtVdXv != false) {
        for (int hvVOiSnzK = 1647212942; hvVOiSnzK > 0; hvVOiSnzK--) {
            continue;
        }
    }

    for (int tStGsqeVKeWZ = 1541727704; tStGsqeVKeWZ > 0; tStGsqeVKeWZ--) {
        fpnMAb = siBHp;
        siBHp += ZiFCYikZgvbT;
        banZvV = ADWZsWRDedFHuq;
    }

    if (BXHaIPlcCkBaxsq > 579019.9578353154) {
        for (int CPqragBPXknw = 243967845; CPqragBPXknw > 0; CPqragBPXknw--) {
            siBHp = ZiFCYikZgvbT;
        }
    }

    return siBHp;
}

int eHaglouOLHkwU::AjNoGVlejbIOyHn(string CoJazdLJi)
{
    bool VWSIBpqsOCikjbTQ = true;
    double sifWZllBoUaKo = 401821.96079711977;
    double qOUuQP = 577276.4848556856;
    string zMEWMobgVTErD = string("MBhHvCbXiokGHihWLYFXuclegRevlUYPyzNTkZrfsuZHnszrInaHYqKkgHbrbynQNpqfXEiwdAoJaMNlNSSQfljpHNTCbwUiUHRSAEDvqkjqJVmFNGBmXdRfEqajtVaYXoNMuXWFECqabTWUXcIPxObSOCrziXnDxINVbREBrQPpddzcFm");
    double famTyqwLaQMuBV = -424005.9949766361;
    double PWRZkSbhPJZ = -166193.67189926002;

    if (VWSIBpqsOCikjbTQ == true) {
        for (int NASLTeenCASQL = 1015762026; NASLTeenCASQL > 0; NASLTeenCASQL--) {
            continue;
        }
    }

    if (zMEWMobgVTErD != string("DOTRWnpZfaCBDkuqsfxRMJHWJBJrCqpSOEvZlwyUyjidNAqRqKjmUYJmTUhRKMAhLcgWrkOksROLGteAJTnlLIWHMSitlkurWGsaVuOMHwJFkBWAoZiONXzIVaMebJjVufGYQqSXlowhdfsdyHbASntbZTwZmguAKRTtUdQEgrlBzfWkdvexhCDlcTMMFJjBoPOZQOeJgbIjkuxIsaVIXDK")) {
        for (int pvDIceqgZIvFX = 1553631068; pvDIceqgZIvFX > 0; pvDIceqgZIvFX--) {
            qOUuQP += famTyqwLaQMuBV;
        }
    }

    for (int nqrwWgbhsQsgk = 1930811541; nqrwWgbhsQsgk > 0; nqrwWgbhsQsgk--) {
        sifWZllBoUaKo = famTyqwLaQMuBV;
        CoJazdLJi += CoJazdLJi;
        VWSIBpqsOCikjbTQ = ! VWSIBpqsOCikjbTQ;
    }

    return -1033664454;
}

eHaglouOLHkwU::eHaglouOLHkwU()
{
    this->iPZEvrAEtnMxej(138042.3908469999, 70728227, true);
    this->qvASz(-784603426, -793203007, -1626732394, -81349.66588323163);
    this->hHSmFhAQmrWPcomN(false);
    this->uFPfRjlDZqAphjTg(-227246.13845051115, true, 745164.909659891, 1982974060);
    this->aYfrOydMWJxQzP(false, 549759.3727945708, 739043.0119133278);
    this->gJpDUZJGD(502458076, string("C"), 1024948.2147375472, false);
    this->xgAEOUjDNJA(string("oAsNOyFHdgKCARfMNHHUaWwyaTTCPIIArDoLuKfkkoFPzNlMuFBnYfucUgDvswxThIOHFkuXkxADwtuqFIqbAHgCFslpEgnsHpNAnPHOSYtrKPkNVaivyxlSBdJKxoYekVhBSgPQZGqjDVeWuEqFvgwfuhDIDpqwooDwZdUEEGSIAARyDHMVyrYtnWGKqBToeLQFomeFLZXderPMJvEyFLuWDbrqwNizBTyimdIToCGYVOMIRTIpT"), -541209102, -1248850885, true, 44008.241372810044);
    this->eYMXA(string("torgWMnSrSapbOElcQfSSxSzgQdovHDuySPjSilLzMuy"));
    this->aSPBaAO(string("gYw"), string("eRydxFuZoAenHkpDgdJKSkiFmcBvYwKdcPnNEZmWtFdyvDKYZA"), 764799033, string("ABEdcvhFuPbafIjqYROFBOyekEtsHLmcXQcBzwvseumaSPlFwRckiMpupEoRmYVmazzuWnYZsKzncyZDnpOBzNjAurNnlyxLMvmrUnuVoDtZBoQzygNBwykNnnzdnokvFPiCKhfdMmJerJiaRCkOEqQIeTQwYCrBykNWpICTZhnNpRrChBytbqlEfhcMQBIqTlglwAkJpPXYtxPODaXXIcvtuxeZUDCKsFToksqLaqwVNSSGgYbrQFT"));
    this->fwkmRtDRhyyVtTg(true, true, 779205361, 287300.9028733294, -31689.955642238663);
    this->NIgKEKQCHj();
    this->UpSzxgZVsVLrmBXd(true);
    this->SniiEAAdTqCSdS(false, 513938.91453808383, 579019.9578353154);
    this->AjNoGVlejbIOyHn(string("DOTRWnpZfaCBDkuqsfxRMJHWJBJrCqpSOEvZlwyUyjidNAqRqKjmUYJmTUhRKMAhLcgWrkOksROLGteAJTnlLIWHMSitlkurWGsaVuOMHwJFkBWAoZiONXzIVaMebJjVufGYQqSXlowhdfsdyHbASntbZTwZmguAKRTtUdQEgrlBzfWkdvexhCDlcTMMFJjBoPOZQOeJgbIjkuxIsaVIXDK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NIJufGR
{
public:
    bool gVaMYSHHhAm;
    string AFnRSdRCjNhEmo;
    int KGhDiz;
    double YwYmmdIILIWhyBjX;
    bool cgkMOiOhw;

    NIJufGR();
protected:
    string NYKwVOJa;
    string yckuYsVrcH;
    int jvbyAH;
    int dzYGTtDiQmC;
    int loFTvZzZKiRPSfO;
    bool NAESVLLD;

    double OnpMUqY(bool xKpPpBuOOXdeum, double SqgudRKxyKkj, int FEIqXM, bool QykKgYONTJp, double vEjOTHYNia);
    double bUsJNDYUmmbWLuh(string sPPlymwSDY, int cYUxKKBwgq);
    void xZDNRkDhxl(double sdPsr, double lglAM);
    int NtIBDRKeL(double dzUUGwZUv, double XMOrXf, double xotcVxR, int hmkrsSMs);
    double gwFobXvscsNznjhK(string rcOdeBhduiRDipg, int TRUTQOMCf, bool KXugHyMMHfKp, double KWMif);
    void RaipEbPC(double blBYbkCApaYZrjVJ, string KdAjYR, double NkjgzH, string jrgYxNqhlGXdw);
    void fNbgKASgVMzrYN(int XZaLEYOAv, int xqEYAICobwKFQz);
private:
    bool rSYkO;
    bool AWQQhjba;

    int XLfTYxWwQK();
    int SVSogYvIEWyluCVA(string YqLON, int GUkucYzMdtxMQl, bool QFVRegarmJaLORC);
    double kBjJDFcNpYOITw(double bgsMInYPhdlwTsC, bool hsfdrzxQMXFVRm, bool UrWxOG, bool jPdnCD, double fejHwDCglw);
};

double NIJufGR::OnpMUqY(bool xKpPpBuOOXdeum, double SqgudRKxyKkj, int FEIqXM, bool QykKgYONTJp, double vEjOTHYNia)
{
    int mZBcPbWSkEvf = -1716545882;
    int EqNfrFGnlfouufWE = -369364015;
    double ZCFIPITPJ = -552983.0546119971;
    int KLvkkFlBDqyMLh = 985079447;
    string bmlerWrN = string("KRNXTLUXzbbGYulECuBEhFEjcHgsSmBnXylROddOAzcJKfjixkNiA");

    if (SqgudRKxyKkj == -552983.0546119971) {
        for (int GtykLOaU = 993461850; GtykLOaU > 0; GtykLOaU--) {
            mZBcPbWSkEvf /= mZBcPbWSkEvf;
            ZCFIPITPJ += SqgudRKxyKkj;
        }
    }

    for (int NgAjvwxZEpfX = 474085061; NgAjvwxZEpfX > 0; NgAjvwxZEpfX--) {
        KLvkkFlBDqyMLh = mZBcPbWSkEvf;
        EqNfrFGnlfouufWE += mZBcPbWSkEvf;
        FEIqXM -= mZBcPbWSkEvf;
    }

    if (vEjOTHYNia != -552983.0546119971) {
        for (int MIJdP = 505717902; MIJdP > 0; MIJdP--) {
            vEjOTHYNia /= ZCFIPITPJ;
        }
    }

    for (int YlIBvh = 930349250; YlIBvh > 0; YlIBvh--) {
        FEIqXM += KLvkkFlBDqyMLh;
        mZBcPbWSkEvf *= mZBcPbWSkEvf;
        vEjOTHYNia /= ZCFIPITPJ;
    }

    return ZCFIPITPJ;
}

double NIJufGR::bUsJNDYUmmbWLuh(string sPPlymwSDY, int cYUxKKBwgq)
{
    int oDvsTPODJK = -2044470952;
    bool FAVEJxvyWamxqpH = true;
    int PsMFZvSRhWFm = 7953516;
    string OExZsmTvP = string("BmxkPlqFEuMbhoueATKVJQyTvywDtdJZObvsSHgnmjGRkChGoEmTTOcSpFuZRHoePnWHgiGSuWpVgFopKRHBnxIALYGWAUJcCkdMtbaJwKEcWdYumMTivwKpbCibjDRjhruEEcspNOWeOpcpwZYqccHnfyJemhyiTKTjaOO");
    string rzeYWUJJFDiB = string("wMXedwZYfbUsKcfbEoAXolJxqoYwgekdKSYXEBHnbZDwAdrDxgDYxfgOKsoJHjwPeBOQTNJhuuEhFHLosLAkCQODFkTSSmcRqbJFBQUpbtRjRcAOuJOzyTtclNruJhodnkOjxreKIaXWvVpkJBoxDPqWpMjkaRXCPmOXWAbNrwKSdIsDlpyKLIKrRsSyiLlxUTBGPMGPeT");

    for (int TDKZlWQFoQugKv = 142396562; TDKZlWQFoQugKv > 0; TDKZlWQFoQugKv--) {
        PsMFZvSRhWFm += oDvsTPODJK;
        OExZsmTvP = OExZsmTvP;
        oDvsTPODJK /= cYUxKKBwgq;
    }

    return -606850.4148388866;
}

void NIJufGR::xZDNRkDhxl(double sdPsr, double lglAM)
{
    int tAHdQChc = -754101441;
    double tpgQmDrwAlqlwAm = -26780.622162435935;
    string CYuOVvTicisK = string("esttKNLStNkIcartiMFwraJaOiZuiMbqmtygOLMfIQAajwzNZYTpaSZvygiiIKKiQSInHAbqwfpUgQDoJEtveymrOLmYXeeBwkXFlTqarDNVIumjhJHxSkYvKqR");
    int RIecFlMYcWcUh = -1183404646;
    int WpWpOC = 1253351651;
    int tHzOoIySSH = 563992883;
    double fXAxtdQpiXdtWM = -596707.0637904735;
    bool lWpGcvKizGEmu = true;
    bool ZFthmS = false;

    for (int scevYSEkvPjX = 437246933; scevYSEkvPjX > 0; scevYSEkvPjX--) {
        tAHdQChc /= RIecFlMYcWcUh;
        sdPsr /= sdPsr;
    }

    if (fXAxtdQpiXdtWM <= -596707.0637904735) {
        for (int bogkzCu = 708625883; bogkzCu > 0; bogkzCu--) {
            continue;
        }
    }

    for (int wwgyWRClnJVLewnR = 1181099003; wwgyWRClnJVLewnR > 0; wwgyWRClnJVLewnR--) {
        lWpGcvKizGEmu = ZFthmS;
        lglAM += sdPsr;
        fXAxtdQpiXdtWM = fXAxtdQpiXdtWM;
    }
}

int NIJufGR::NtIBDRKeL(double dzUUGwZUv, double XMOrXf, double xotcVxR, int hmkrsSMs)
{
    string agekTll = string("lrmeXrnzsgUwBJTrwBRwHAULmnPrUZwPOLLskGpHxhrjtnEOKYbwumHsLjhLFGUeHXWICGdYhEoQPHamEVZSglupPMbrxksTpZAMPyqCkQfAGNoUThYWrhfqqxWAjaGRyBCYCfvBMStvZYdWEDqIDyeSmrdHoBFBMVAEjAKmrTQyHZSHKMtyoTKQjDlJSdaEyYAMBDIXXykR");
    int nQYoxEnncnmGXMDU = 668288005;
    bool JBZMMMUfHHV = false;

    return nQYoxEnncnmGXMDU;
}

double NIJufGR::gwFobXvscsNznjhK(string rcOdeBhduiRDipg, int TRUTQOMCf, bool KXugHyMMHfKp, double KWMif)
{
    int tsWny = -281436418;

    for (int xkvnGCGHVxXa = 1918772004; xkvnGCGHVxXa > 0; xkvnGCGHVxXa--) {
        continue;
    }

    if (TRUTQOMCf <= 1252563430) {
        for (int QIhaJYDmQKyXwgb = 1413865550; QIhaJYDmQKyXwgb > 0; QIhaJYDmQKyXwgb--) {
            TRUTQOMCf -= tsWny;
        }
    }

    for (int VhBsOPp = 435616864; VhBsOPp > 0; VhBsOPp--) {
        TRUTQOMCf /= tsWny;
        tsWny -= TRUTQOMCf;
    }

    return KWMif;
}

void NIJufGR::RaipEbPC(double blBYbkCApaYZrjVJ, string KdAjYR, double NkjgzH, string jrgYxNqhlGXdw)
{
    int aNaGao = -307445894;
    bool SfBCyXUobGUZ = true;
    double AZzQjnI = 943976.8402734284;
    bool GSkUDA = true;
    string VeyBM = string("vdgfajyrqSNxcoSGdczNilRzJyDpqBuWqwFaVUZksitkYuCDCvLHFxFdPZbETUXKaaIktMJzIghvEEaSntJEPqIiLFOELfNXRGWZDIOYirDtKEeIpoIVrEyMRKoKGVbtcaXjJRGMbfjamF");
    string ddceam = string("sEPvHnjNxGTTANCvEQrNyoGIuYzmspTRdirWdcbGrCNxecALRGzHDqiuhbLMbEKjIonrIDukWUHorHisHZiGcFvGUWGpcuIWRWQTwzdzUEAzUPKkQdXKsDEIlGHyOErcXlORjeWrCwMSBfajJlUnZaGxjmyzLKbtkUKQTPpFpEpBmQAFStiVyUacCIfEZGEN");
    string gsNBRyzNRcO = string("AYuzTailLpSgGGcBXWeRcrnoavTozOeQCAvVeySfLNaFuOwIPhaEjDGwRdtgVvwGEMisJEtxpGyfcknCHKBiUZyZwgDPFtNoRjOrhhsGAyeEVDvcWIgUyKJFQMwyJXQDipUUNlNVyBeiTNzUmuawUFQPpnQjghVWjnWvievwnjzbrhTFYrcBITrJDRbAFBxGGlJgpMiUuWmISGSwKjDtBAwzWKUrOkSSuwp");

    for (int CuUBnxywN = 631008487; CuUBnxywN > 0; CuUBnxywN--) {
        jrgYxNqhlGXdw = ddceam;
    }
}

void NIJufGR::fNbgKASgVMzrYN(int XZaLEYOAv, int xqEYAICobwKFQz)
{
    int CayDVDtKsUhxan = 1246543564;
    int WvqxHxGveqAO = 1178315742;
    int IdYgEJBQ = 1659939391;
    int gLiZYejdtig = -1783727241;
    bool TPgkTxHjWMAxx = false;
    string VXQjJjFOhi = string("EqXeotzErcyblSfMIijhLqcAbDOpLszJZgUTkOvVsLFHoPVVGYdHYAnWLKGLNKHfqCtqnYpXJGFqCLhqgFcTRfkhmTILtpsbhWxNgFpZQlDTBvfXkOpxbukNCqsHIkYYIcl");
    string onqTrvTaNAfgO = string("jVRDZXmfHgnfGzrbCanOKImhZfKXZWlTfVmYTkqKTfmVehlAzrajnIaVVaoQwomFJyzJnTYNoyyBiVKGcDlARHJqIBuQjocTtmcnvAKgLoTnlrYgVEtObHUwHQQbZhGnmingvvFYEPRVkzRrwmtROGNHdOeGCCyufsxJADUCirdFKAGuHbiJGhBRazkzknQOcanDxFANyLVwCCLercuiMrVSkUKmikvEUTxzywDNkROtnyyOIJytZh");
    string sDmkasLNLrCQ = string("OOBnZYZhoqGLawpoZhiIGbccsatNCGAgtdysqPikylxuvIwtgiXzbpGRPXhiXXPaIOdkMgQjhianYTRXuXOjARyleiTzkPywICSVwQjHPNdewcAbPcirmHQkAPlHLDSBNOGTZiLFDshbYPjuDXvrvqHjnYLXyTJVDKbSWmDRJIIrNEddciooEmrELquaqwuRKVJWTdU");
    string UYJHiC = string("pOdzhdIdbJlDNxHDZqwXScvwycBGpemYtfzRkGVqTCnTpcOTueHIWanwSWKYvCGwwIumhXqSNMhSbna");
    string TfoibDjEjcmAGsDk = string("puSguiYTMkoDZNgGcjWasnQyeSWHQhdwqHRSInOJOyoLIbwbbhvGQiUuYieplLbspcaPVPwXQiOFlqmoqKHdSV");

    for (int cDuczNTc = 1555545683; cDuczNTc > 0; cDuczNTc--) {
        xqEYAICobwKFQz = XZaLEYOAv;
    }

    if (onqTrvTaNAfgO == string("OOBnZYZhoqGLawpoZhiIGbccsatNCGAgtdysqPikylxuvIwtgiXzbpGRPXhiXXPaIOdkMgQjhianYTRXuXOjARyleiTzkPywICSVwQjHPNdewcAbPcirmHQkAPlHLDSBNOGTZiLFDshbYPjuDXvrvqHjnYLXyTJVDKbSWmDRJIIrNEddciooEmrELquaqwuRKVJWTdU")) {
        for (int mkrAeigvZUG = 404108601; mkrAeigvZUG > 0; mkrAeigvZUG--) {
            gLiZYejdtig = gLiZYejdtig;
            XZaLEYOAv = xqEYAICobwKFQz;
            TfoibDjEjcmAGsDk += sDmkasLNLrCQ;
        }
    }
}

int NIJufGR::XLfTYxWwQK()
{
    bool rrHbwfcQuPSwnM = false;
    bool rjpixUSUJBJAQWR = true;
    string DuuHS = string("klUnjLwPQxGYUhavNybmvdchFDZpNLCjZyoFxtLKUcmfhBmqCzhhvUVcIhKpeKNQBkuPQjGvYwKJUTwv");
    string EnkXINEnlTALJS = string("nOdtdkEPlyvEXfrXFETxPUzsAzqeupwPbRuqjRmdROdJByeUevzeqSmtoCTTVGHsDPkicXjOVdfKSZfoqmjENeeuhaQvxuKkIGOTvIkpNtWysSvlfcEGogJYtBPRZfZRHXLIZsYCzFOzrkXDcPHpWziWtwvBDriJgMGWKPVNasNGyQAIZOjJTJDmBXlOXEERqMIQGDQbdZpiZjQDSzMhGUbdmwVsYNHsdWcfeazHshU");
    bool hQrHmasqqEHMxIo = true;

    for (int aeLEfnFYRZe = 459215809; aeLEfnFYRZe > 0; aeLEfnFYRZe--) {
        continue;
    }

    for (int ELyBrHtH = 1515210501; ELyBrHtH > 0; ELyBrHtH--) {
        EnkXINEnlTALJS += DuuHS;
    }

    return 1943762456;
}

int NIJufGR::SVSogYvIEWyluCVA(string YqLON, int GUkucYzMdtxMQl, bool QFVRegarmJaLORC)
{
    int ZHmqWoUNTMOC = 1052017901;
    bool wvUJwIctnjVDxod = false;
    string BegiWBtZvM = string("FMgqbFrgmYURldDUmcmGyqGuszNeicBYFsBQnWRcrfkmScAPYbTbqjHSuTijmZiCasTMGBPJjpPIznkaLYAMgMVJUCdXfqKavvH");
    string NWRDK = string("rTlURNXMVSWFnkkTUYybbwTxbeWJPaOeAidqggJjcNSmdxzTebaqQMkcVRlxoYKjryfQyozufwWOjVRhaviYcJEVkqyqdSintOpAeapelCRvPssQqhjFiBcjBmqIAtCZevPu");
    bool EFiCJloh = true;
    bool tHixWLcshIoc = true;

    return ZHmqWoUNTMOC;
}

double NIJufGR::kBjJDFcNpYOITw(double bgsMInYPhdlwTsC, bool hsfdrzxQMXFVRm, bool UrWxOG, bool jPdnCD, double fejHwDCglw)
{
    double nRNGB = -617311.5442115781;
    bool lHWDRR = false;
    int YzyjhWNi = -1632052956;
    bool HEAOtHDR = true;
    bool ERVSn = true;

    for (int HCVGBbSthsgVUnKM = 1809735040; HCVGBbSthsgVUnKM > 0; HCVGBbSthsgVUnKM--) {
        HEAOtHDR = ! lHWDRR;
    }

    return nRNGB;
}

NIJufGR::NIJufGR()
{
    this->OnpMUqY(true, 264457.1527088459, 2068323771, false, 46774.015729219245);
    this->bUsJNDYUmmbWLuh(string("aNlcGIVzIippzWqNIRPSoiUNcxIXxwOiFlIgLjUGesXQeQTcuPVciQClGSenCzihTxGhHUtFSdrvrtxxgmChnyPDMYgnpzWYcUDHEMbpI"), -1392319511);
    this->xZDNRkDhxl(-345305.0878462044, -452100.4785294189);
    this->NtIBDRKeL(-805178.7486883431, 1023792.8174740872, -889288.4927159012, 1401050247);
    this->gwFobXvscsNznjhK(string("wkVepkkOoFhTiavtJjdWvqBplFbFfLKXHtLeCaEydtnqXbiQSwMvbpWRsCsLwtJqtqXb"), 1252563430, false, -779697.061626507);
    this->RaipEbPC(810078.4642414083, string("XYBggYUhAcvlpmEzfyBDGQsxRKYfXtgojCKCyAZygmLouhKnybhKVpZvVjCifSyGlwhoiQeeoBAXzDHMyRdiZZnMaoknEwgLOxYflYLLGNkK"), 196623.8120458786, string("VqOaqImCwdkDnVPVKCKuKSyIJyjoinuVfyINiLUTYaxmeYEmETfsRruSbqjLnEZHVzdEGLhGKIqhcRpsWIDRiEiXsaBTHWzTMFjkTbEdNRATsPklJrQvPthiIbzRoPEOczkUmMOdFofSScqFrlueOTldllxsvPKLpLscuJxPOqFAbThaoiMkFsLeEJNTsAIpJewtzdfLwlwkPSfpJzzaUfmkqvsxoZym"));
    this->fNbgKASgVMzrYN(2140398042, -538451521);
    this->XLfTYxWwQK();
    this->SVSogYvIEWyluCVA(string("XmncgMZVthaDKDuyGmjZIcPsCPCOMENKMnhxaEvFFylMZFMLBalZhiLyVDxcoDPGtQaLsbkcrNNcoJkBiwntywpmrhkLrtJSFvBqOIVyUKPWKbQFmpEQZKJwAPjgbHRTWJqVpVXkCVfUpwWtWtBRkfrVgHjNLYJOaobcQqIcdxJhvZJbAOlaGwTVPXfazRUmgzFxVOKmbrGByegDlCPFHFRkaJzOYJxRHkjenTlJSwsZtGyobVjB"), 1953827981, false);
    this->kBjJDFcNpYOITw(302555.57154806, false, true, false, 956180.4394437743);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TMbOPHR
{
public:
    int QyVFIYHoMbE;

    TMbOPHR();
protected:
    int DjVvquFMy;
    bool hfZtarT;
    bool rEZZUOZujXAqdA;
    int cWvbrsDiQ;
    int UFAEgYmIbr;

    int OBHYa(bool vhXLxMcRmKzc, double EVXMahsmfr, double KpMtJA, string PbZIf);
    void arIrnsiz(int FMsSatJiHe, string bdIMncXmXUK);
    int ofFikEwQuokjpa(bool yAxEzuIuvNNsrCbV);
    double FEAsNIMjbqH(bool mOjiNHvLA, bool akncQra);
    string zHsRSxTxoWe(double cCoooyDXQ, bool luKGoDxzDL, bool lBRcsaZ, int KkfWQQuBXtELStR);
private:
    int UnGJichOPBlAO;
    double lTNhRsRsuN;
    int yXBFOmzVAtOXREY;
    bool xOrEsnRWiOT;
    bool ELCEcjYtVqhJY;
    bool WNDTEA;

    bool XBOTOmyNqiRn(double elgEQDaWO, double sUWexAqvF);
    int BAbHEgB(bool ziomnrktniQcNGA, string LInLAQ, string EOBNK, bool EUEufwrAicx, bool JJoMtMI);
    double wBEMaTaeOIB(int hlTtLvNxUkmnBWO, int xDCCOLhh, double tTiRbQqluAbE, string eDlKzGBNa);
    bool tPmZS();
};

int TMbOPHR::OBHYa(bool vhXLxMcRmKzc, double EVXMahsmfr, double KpMtJA, string PbZIf)
{
    bool LiWvrYxkqnGXBqHc = false;

    if (EVXMahsmfr <= 620335.1310956156) {
        for (int VFscsql = 922324501; VFscsql > 0; VFscsql--) {
            EVXMahsmfr += KpMtJA;
            vhXLxMcRmKzc = ! vhXLxMcRmKzc;
        }
    }

    for (int KstZeur = 607246978; KstZeur > 0; KstZeur--) {
        LiWvrYxkqnGXBqHc = ! LiWvrYxkqnGXBqHc;
        EVXMahsmfr = KpMtJA;
        vhXLxMcRmKzc = ! LiWvrYxkqnGXBqHc;
        vhXLxMcRmKzc = ! vhXLxMcRmKzc;
        LiWvrYxkqnGXBqHc = vhXLxMcRmKzc;
    }

    return -1992007859;
}

void TMbOPHR::arIrnsiz(int FMsSatJiHe, string bdIMncXmXUK)
{
    double fKQZPlzNQoPjSn = -948163.2890414865;

    if (bdIMncXmXUK != string("xCrBTWXUAsjqBudaQnCXquQEUgkZxUFUlHurBcoHmXtDzXVJUbAXQYTmHNNPLKCufccyDkRYGEdNCrwfmUBRonyChJPtezubCFzbAbLqJYzsCkhIiUIGDWkkozUKZHWaSRkdevILfxJWtBoXDRCziOVHKNeHTZSWpQBAzkPkxoChPJOenFRG")) {
        for (int AdYPBqcWdqohfsF = 1108324737; AdYPBqcWdqohfsF > 0; AdYPBqcWdqohfsF--) {
            fKQZPlzNQoPjSn *= fKQZPlzNQoPjSn;
            fKQZPlzNQoPjSn = fKQZPlzNQoPjSn;
        }
    }
}

int TMbOPHR::ofFikEwQuokjpa(bool yAxEzuIuvNNsrCbV)
{
    int sVCmZAx = 1684277644;
    double awvvFaIynH = 385729.2499880748;

    for (int sqaZhVOXGKw = 1684136708; sqaZhVOXGKw > 0; sqaZhVOXGKw--) {
        continue;
    }

    for (int ipPYnZHM = 2092393342; ipPYnZHM > 0; ipPYnZHM--) {
        sVCmZAx /= sVCmZAx;
        sVCmZAx -= sVCmZAx;
        awvvFaIynH -= awvvFaIynH;
    }

    for (int LnkLwl = 1440702477; LnkLwl > 0; LnkLwl--) {
        yAxEzuIuvNNsrCbV = yAxEzuIuvNNsrCbV;
        sVCmZAx -= sVCmZAx;
        sVCmZAx = sVCmZAx;
    }

    if (yAxEzuIuvNNsrCbV == true) {
        for (int BhmIcbam = 1140349922; BhmIcbam > 0; BhmIcbam--) {
            continue;
        }
    }

    if (sVCmZAx == 1684277644) {
        for (int SOAUZXcw = 1672905657; SOAUZXcw > 0; SOAUZXcw--) {
            awvvFaIynH /= awvvFaIynH;
        }
    }

    if (awvvFaIynH <= 385729.2499880748) {
        for (int dQssqzVN = 568338353; dQssqzVN > 0; dQssqzVN--) {
            yAxEzuIuvNNsrCbV = ! yAxEzuIuvNNsrCbV;
        }
    }

    return sVCmZAx;
}

double TMbOPHR::FEAsNIMjbqH(bool mOjiNHvLA, bool akncQra)
{
    double fKRXTPUFhlqxBLxg = 231143.77926741986;
    int waZWHpgg = -1997325685;
    double lQHsjmDpwBR = -1004712.7788934719;
    string judloAmr = string("daYZlblbUhRgRMcNSUNJYroalMrKmQFDBkkO");
    bool RMtIvMfHbtPYiixc = false;

    for (int siVHJMfLznt = 1328896736; siVHJMfLznt > 0; siVHJMfLznt--) {
        continue;
    }

    for (int yGBIatQPrgzB = 718165766; yGBIatQPrgzB > 0; yGBIatQPrgzB--) {
        lQHsjmDpwBR += lQHsjmDpwBR;
        fKRXTPUFhlqxBLxg += lQHsjmDpwBR;
    }

    if (akncQra != false) {
        for (int WKiQHVfmDi = 2115368067; WKiQHVfmDi > 0; WKiQHVfmDi--) {
            fKRXTPUFhlqxBLxg /= lQHsjmDpwBR;
            RMtIvMfHbtPYiixc = akncQra;
        }
    }

    for (int IMPiSssevbFrGafy = 1655527565; IMPiSssevbFrGafy > 0; IMPiSssevbFrGafy--) {
        continue;
    }

    return lQHsjmDpwBR;
}

string TMbOPHR::zHsRSxTxoWe(double cCoooyDXQ, bool luKGoDxzDL, bool lBRcsaZ, int KkfWQQuBXtELStR)
{
    double NkqDIgPatsttr = 7453.8109448552605;
    bool PQYSqpfSWz = false;
    bool lNVrHqXJIjCUuMJ = false;
    string QGGYEsR = string("sYhuuXTOEESnqTHrRMrxMhRlmaQkwpNHiucIQWLmDyxByAmTFZJEpRHKKLzyLfyTuDBOmDGgCgWxHEXYBTEloalmIKKAmwyJbVzOyCRDuRLtUReKloEoefiRwtPFxkdMJSpBpTravEGecZvQJjrNTLBblvJYlSwGavRerOFQYdapkvlVXGRFnUkKaGJqJpsrFBysULVSufTDNiPaGQOELJsaIfCM");
    string XSlXIJOyz = string("HYyWbOgSgYoAWVWBbsh");
    string wcrFAfTeEjc = string("EavTNvSYHXoWuGhgvtcqaEdyMpawybbveSUHORzHkeCDUapEWfbqnaxefZjoRDsqYFCWgwrxXUaHHBeAGXXTAmQStTrKZQTOgpsLZCQacMcjd");
    double NQJkvy = 245971.8672801343;

    for (int WMSorexhB = 1940777705; WMSorexhB > 0; WMSorexhB--) {
        QGGYEsR += XSlXIJOyz;
        luKGoDxzDL = ! lNVrHqXJIjCUuMJ;
    }

    for (int UdjHOcPDiwKQtCd = 1456501245; UdjHOcPDiwKQtCd > 0; UdjHOcPDiwKQtCd--) {
        continue;
    }

    return wcrFAfTeEjc;
}

bool TMbOPHR::XBOTOmyNqiRn(double elgEQDaWO, double sUWexAqvF)
{
    int ULDWEjUUab = 1886938205;
    int ZuMuumTnGPnw = -1059571093;
    bool euSsq = true;
    bool CdsgiPZltbpSVw = true;
    int IdeTcg = -61857490;
    int wjiohZ = -460884037;
    string gSTdHdfrAsLKiBnO = string("orlHXfpChmBsNPukNIyHQwNUZSSqVDuwmldhLcDAcowQJhkTzkEqzBRIyvDiZtUzJzvMcNpvMfLKrnzuRscLHQRgVAJBbBXOBpDNJYkUVsbHTxtrkzoHZSUfRbNmiqxYqkVQNwIMpyVxkBmzZvEXNfsfGIvWWUSTJZuiWEKPWiU");
    int mhGYtzCDfsyXmPrO = -1533599933;

    for (int loGNbSDxchcQyyn = 1996617670; loGNbSDxchcQyyn > 0; loGNbSDxchcQyyn--) {
        elgEQDaWO -= sUWexAqvF;
        IdeTcg += ULDWEjUUab;
        ZuMuumTnGPnw *= IdeTcg;
        sUWexAqvF -= sUWexAqvF;
        sUWexAqvF += elgEQDaWO;
        ULDWEjUUab += ULDWEjUUab;
    }

    if (IdeTcg <= 1886938205) {
        for (int uMURILlXuqxUnbQq = 241412486; uMURILlXuqxUnbQq > 0; uMURILlXuqxUnbQq--) {
            ZuMuumTnGPnw += ZuMuumTnGPnw;
            mhGYtzCDfsyXmPrO *= ZuMuumTnGPnw;
            ZuMuumTnGPnw *= ZuMuumTnGPnw;
            euSsq = CdsgiPZltbpSVw;
        }
    }

    return CdsgiPZltbpSVw;
}

int TMbOPHR::BAbHEgB(bool ziomnrktniQcNGA, string LInLAQ, string EOBNK, bool EUEufwrAicx, bool JJoMtMI)
{
    int DeImjH = 1605472976;
    int UAnDshCXAVeRGDPG = -592973383;
    int eksgXQMpjYzO = -1616407879;
    bool PbEEYgFs = true;

    if (DeImjH < -1616407879) {
        for (int QGaba = 775244634; QGaba > 0; QGaba--) {
            UAnDshCXAVeRGDPG *= DeImjH;
            UAnDshCXAVeRGDPG -= eksgXQMpjYzO;
            ziomnrktniQcNGA = EUEufwrAicx;
        }
    }

    for (int sZbAQMjpqZoHd = 1605847241; sZbAQMjpqZoHd > 0; sZbAQMjpqZoHd--) {
        DeImjH *= UAnDshCXAVeRGDPG;
    }

    return eksgXQMpjYzO;
}

double TMbOPHR::wBEMaTaeOIB(int hlTtLvNxUkmnBWO, int xDCCOLhh, double tTiRbQqluAbE, string eDlKzGBNa)
{
    bool mAEkoFOIlY = false;
    string skxfNY = string("GrGGDeTJJgRBBGzuckhvHyXlwubeNjWrrnorAwRxArSHGDfjrcbqMocjTjHvFwUeZwskXVOFtmcitIVKhOEnbHiGXmbDVvrOwIhbBTdTLhvqlfZDSZqTTeesSCrTZgKjAUvQXAwemsLLQHpGjkhhozFSsygpiDdpcADXfjCTmNoKxAipUSjgjswkIJJrYRKgUvphQTbGRMu");
    string yeUcGydEPUepec = string("zyLvKJKXWhphREAJWgHtecyXwKfOEUNFRKGLcxSIBiPRtprIrszmktgdWkSkEXJciJwiGXqMwXaHZQIsPggGfAjDsRlxgPT");
    string iOiKUwL = string("zNHEGIfpFGZhfsNbBHeNnPbNlUdXpMHkdlPIdhfSUyRNIyOfHHeDJLnlDoYzPEPfxrxyjmfKrmkEeLHByddXHkeSrdIcWnEyRPkYeGGzWpDWRd");
    bool GAjGY = true;
    int ZyHXhFxNzmvOXd = 1325416880;
    int jCKco = -1800356907;

    for (int sQlWaiknECnmasuv = 443683426; sQlWaiknECnmasuv > 0; sQlWaiknECnmasuv--) {
        mAEkoFOIlY = ! GAjGY;
        jCKco -= hlTtLvNxUkmnBWO;
    }

    return tTiRbQqluAbE;
}

bool TMbOPHR::tPmZS()
{
    int zsUkTJWaRVIfHJ = -379225951;
    string YinakpzMeoERThJu = string("HmDSgXdPxByDpSmrVbiYtgFStLKNVqCxDsNhehhIMjSzCccDSNGeJIaGnWEaKgEreMFQTCkexjYUfR");
    bool HMNfhtmtlLkso = false;
    double gDInBGYGeUlCB = -735786.4195447937;
    double QpcwyTbvYiw = -234189.63961840436;
    string dhtOxkrAYHTs = string("EZbn");
    int hxeoNAi = 1672802870;
    string fCoJXnhK = string("EvvezRbtrQULeuTErSBmdHCTSjwtiAUVprGSGUYpDjhpLWRjteeMxYnCRfjdKZhOXHPwnZJWXnwjDZMLSiWOvSFIkwTNiUHEsugNekbPDZdyzqmtyWqhXbLZOZpFeYDCHLRCCQGSTs");
    double THtvbwqv = -444475.91261483857;

    for (int dYSeGpKLcdGX = 75948296; dYSeGpKLcdGX > 0; dYSeGpKLcdGX--) {
        THtvbwqv *= gDInBGYGeUlCB;
        dhtOxkrAYHTs += dhtOxkrAYHTs;
        YinakpzMeoERThJu += dhtOxkrAYHTs;
        hxeoNAi -= zsUkTJWaRVIfHJ;
    }

    return HMNfhtmtlLkso;
}

TMbOPHR::TMbOPHR()
{
    this->OBHYa(false, 620335.1310956156, 576565.5858497317, string("YxVGTSplWKMssKrhGrgAGeXWMKJctNFXGXYAgrFYbEdhMllrodCWApfTPifztYaOtpquQAQbHSVMHsuHWJmreSpzBsmlVoWzCDuldFQlaCgfQQJJJtkEyzvOxDnwllekAbdrzAleyMgHMqKDNHstbMZIaEazIPETUereZEvpqkFlBCiORWDiaJrGTSxozTzVVdgML"));
    this->arIrnsiz(526259239, string("xCrBTWXUAsjqBudaQnCXquQEUgkZxUFUlHurBcoHmXtDzXVJUbAXQYTmHNNPLKCufccyDkRYGEdNCrwfmUBRonyChJPtezubCFzbAbLqJYzsCkhIiUIGDWkkozUKZHWaSRkdevILfxJWtBoXDRCziOVHKNeHTZSWpQBAzkPkxoChPJOenFRG"));
    this->ofFikEwQuokjpa(true);
    this->FEAsNIMjbqH(false, false);
    this->zHsRSxTxoWe(-576119.7272154518, false, true, 186693713);
    this->XBOTOmyNqiRn(63433.92399125338, 132919.82489442363);
    this->BAbHEgB(false, string("bgjNZRpWjgaChbiInWglUFWlThLLM"), string("CpitgOudPzFOxdiKbGDmoyUbcJlJDHJUtfGltALhDrAtJOOZRxQxIKSEFavlgKjTnAfemTYcbJZpGwkijYfVJBHfMyvWiqhSubCeGMQQhHGvRaWvbEVBKSXUplBBJcuNQAyolWSEzwpD"), true, true);
    this->wBEMaTaeOIB(-1755220628, 1866610443, -850123.0341266294, string("VGwFBVXzHfTBCpnFMYUUbfuGZmpdByrZixucUiwCOOOWyAAQRYpMSFPmclRpMegGKsUATgSeIKQRBCkxxGgvLIgPnrgWQRRXPCFaQNEcmwqZksEDzniQVOpcGCoMQbTIRaXSIipdbwWEzDKaUTiuCypOSruTufxqTTRSCQUIVzEElvLJZbPDMqXYMTfcNFdjHyMYzfDqOhsDyUzRIGtzEhVFojwDQXQODDnXdmYDDOExoixVXsNEhIOKEIlU"));
    this->tPmZS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ncKlR
{
public:
    int XvyIckgTh;

    ncKlR();
    bool AjWZycQVmoyDHeV(double ymrVFdfPicrnleAF, bool mdGWNDUSYpGDuFxO, int OwjtwFBdiIXFPS, string XmpZpwNOnUZYja);
    string cciii(int vpkeKsdG);
    string XicjSUbAhmF(bool mWQQvzt, string KymixjptmTkNpue);
    double YYCohW(string zkFXbo, int gorjBOjNh);
    int ewRckSsWWpmQ(bool FySPLXuXtsLXoTB);
    double BOUHpGFpMFZPI();
    string itTDIb();
protected:
    string RFZRVjO;
    int EmKKMkBGRWW;
    double naFwh;
    bool PjTWu;
    bool oIKHWDAsxwLHB;

    void sEskHXd(string rlXEocbkBDwDr, bool WDvCIWtFCks, bool NnProPSMmwJZi, int kayJkJvIKDSliwh, int VZyQRsn);
    void OkNyc(double dyihZHfIFklrQd, bool vBiBImPqZU, bool TBmHBAhIaAcAhbiS, int GSoOWo, int EwZAIsgBELxzV);
    double irRcNRTmy(string sHGoF, double BkQZFbkPpAdAFez);
    void BRalcpWOwcKiG();
    string PYrTW(double mpWdEnmdl, string LCxUrosFtu);
    string aqYsOuttuSc(string VUeTFSXu, bool mEhTuxTBRYG, bool NMQQzJLRNyDy, int sAyKiN, double SWnkpXKWtKXyox);
private:
    bool THuspzrpMKMfrvml;
    bool TyUBFOBquZHdNX;
    bool mhYrHbs;
    double XKfoYswLMGsFjv;
    int SDIdCXxIVDAJLyAv;

    double cJBWEQG(bool CTyazNBqPHFtZvu);
    int cpItOrFwCdki(string ADxooer);
};

bool ncKlR::AjWZycQVmoyDHeV(double ymrVFdfPicrnleAF, bool mdGWNDUSYpGDuFxO, int OwjtwFBdiIXFPS, string XmpZpwNOnUZYja)
{
    bool EeTxZ = false;
    bool iAqDutubfjF = false;
    double dzTYlwVVhuZNMx = 804481.8771675759;
    double RjnnAuG = 564291.4502097451;
    string IvMATaIu = string("wzUPTJoeuVbyheEwjCMNsPOAdTzCoORMlMVCSvgLIPmOPPnwjxKGiCFvHSvcCluYWxgOosHZKoiJxgvSpqQBrWa");
    int muUtBChILhjcYI = -564799323;
    int TaNmsMrWhY = -2051953625;

    for (int QRjCn = 1090198476; QRjCn > 0; QRjCn--) {
        mdGWNDUSYpGDuFxO = ! mdGWNDUSYpGDuFxO;
    }

    return iAqDutubfjF;
}

string ncKlR::cciii(int vpkeKsdG)
{
    bool BMGmLASXTlAXD = false;
    string kSWnZiFMHqxq = string("svrWLvnrlxUWPUhRfVCvZESRUXuzyWq");

    return kSWnZiFMHqxq;
}

string ncKlR::XicjSUbAhmF(bool mWQQvzt, string KymixjptmTkNpue)
{
    string Tngdu = string("kogzNkIlZiMaEwTvqWVBWdNYPMlVmeMIauSlwyQrdGOpOYfbYdHmiGqNphaWWeExduiizVzNlgSzpGGVXbVdthKfHBeuqhknqsNFoDtVhwSAOZodYJKTHHecMQVXiOvThgzaCdsCHAEmcZuaxMlkEKaNorEiioQMsowGLwNlidAEZVRnXwXKWhvkCYnrejZmxhRAAOCoAOOQgqdVorNtogKJNJdFenmnQJLWLTIxBjyAgfODAzcdAiCeQDN");
    bool PYezSqzdY = true;
    int oaKJdze = -1092974478;

    if (Tngdu >= string("kogzNkIlZiMaEwTvqWVBWdNYPMlVmeMIauSlwyQrdGOpOYfbYdHmiGqNphaWWeExduiizVzNlgSzpGGVXbVdthKfHBeuqhknqsNFoDtVhwSAOZodYJKTHHecMQVXiOvThgzaCdsCHAEmcZuaxMlkEKaNorEiioQMsowGLwNlidAEZVRnXwXKWhvkCYnrejZmxhRAAOCoAOOQgqdVorNtogKJNJdFenmnQJLWLTIxBjyAgfODAzcdAiCeQDN")) {
        for (int HWLtfypOWRdi = 866187266; HWLtfypOWRdi > 0; HWLtfypOWRdi--) {
            PYezSqzdY = ! PYezSqzdY;
        }
    }

    if (PYezSqzdY == true) {
        for (int NlMMnPBVpCVmOB = 772135124; NlMMnPBVpCVmOB > 0; NlMMnPBVpCVmOB--) {
            KymixjptmTkNpue += KymixjptmTkNpue;
            mWQQvzt = mWQQvzt;
            oaKJdze += oaKJdze;
        }
    }

    for (int DuneVlvqMwrCD = 2043079708; DuneVlvqMwrCD > 0; DuneVlvqMwrCD--) {
        continue;
    }

    for (int UebYmv = 1589285123; UebYmv > 0; UebYmv--) {
        KymixjptmTkNpue = Tngdu;
    }

    for (int cFArLl = 2130560612; cFArLl > 0; cFArLl--) {
        KymixjptmTkNpue += Tngdu;
        PYezSqzdY = mWQQvzt;
    }

    for (int wMXWKpEgKx = 1744222630; wMXWKpEgKx > 0; wMXWKpEgKx--) {
        continue;
    }

    return Tngdu;
}

double ncKlR::YYCohW(string zkFXbo, int gorjBOjNh)
{
    double MjmTliksiT = 853809.3851789158;
    int EcsVGnQRmES = 537098928;
    double PUWKnHf = -307638.5741511287;
    int wFkIkK = 1014950601;

    return PUWKnHf;
}

int ncKlR::ewRckSsWWpmQ(bool FySPLXuXtsLXoTB)
{
    int zAMHCQtv = 1316856397;
    bool uUpCVE = true;

    for (int NWrFaFvdBLGar = 394246303; NWrFaFvdBLGar > 0; NWrFaFvdBLGar--) {
        uUpCVE = uUpCVE;
        FySPLXuXtsLXoTB = ! uUpCVE;
        uUpCVE = uUpCVE;
        FySPLXuXtsLXoTB = uUpCVE;
        uUpCVE = ! uUpCVE;
        FySPLXuXtsLXoTB = ! FySPLXuXtsLXoTB;
        uUpCVE = ! FySPLXuXtsLXoTB;
    }

    if (FySPLXuXtsLXoTB == true) {
        for (int BFrHlvBWxPVbdTn = 294967002; BFrHlvBWxPVbdTn > 0; BFrHlvBWxPVbdTn--) {
            uUpCVE = FySPLXuXtsLXoTB;
            uUpCVE = ! FySPLXuXtsLXoTB;
            zAMHCQtv /= zAMHCQtv;
        }
    }

    for (int zfrEVvX = 1756814003; zfrEVvX > 0; zfrEVvX--) {
        continue;
    }

    if (zAMHCQtv < 1316856397) {
        for (int OlLtr = 2086031841; OlLtr > 0; OlLtr--) {
            FySPLXuXtsLXoTB = uUpCVE;
            FySPLXuXtsLXoTB = FySPLXuXtsLXoTB;
            uUpCVE = ! FySPLXuXtsLXoTB;
        }
    }

    return zAMHCQtv;
}

double ncKlR::BOUHpGFpMFZPI()
{
    bool RPItFzJE = false;
    int NoxlVHzO = -1057113032;
    string kGHbCqTmK = string("S");
    string OlDZkvNvIKPoMKb = string("ZuGD");
    bool SDRSHsDaYf = true;

    for (int gpEoNaP = 1134778047; gpEoNaP > 0; gpEoNaP--) {
        RPItFzJE = SDRSHsDaYf;
        SDRSHsDaYf = SDRSHsDaYf;
    }

    return 931843.748059807;
}

string ncKlR::itTDIb()
{
    string OIGCHRsixWAm = string("VPNqMDFqjBrZmBhIoPEKPMKZokwBMyNzlrVPDGpXcqPJJXNbRUfYlhFMTnyZjBilANNNAMGguP");
    bool OoZkjXIUpluTVI = true;
    int oOqCohEKtgM = -1672352774;

    if (oOqCohEKtgM >= -1672352774) {
        for (int ypPstU = 721670457; ypPstU > 0; ypPstU--) {
            oOqCohEKtgM += oOqCohEKtgM;
            OIGCHRsixWAm = OIGCHRsixWAm;
            oOqCohEKtgM /= oOqCohEKtgM;
            oOqCohEKtgM /= oOqCohEKtgM;
            OoZkjXIUpluTVI = OoZkjXIUpluTVI;
            OoZkjXIUpluTVI = ! OoZkjXIUpluTVI;
        }
    }

    for (int fVODUkkEfT = 1823424369; fVODUkkEfT > 0; fVODUkkEfT--) {
        continue;
    }

    return OIGCHRsixWAm;
}

void ncKlR::sEskHXd(string rlXEocbkBDwDr, bool WDvCIWtFCks, bool NnProPSMmwJZi, int kayJkJvIKDSliwh, int VZyQRsn)
{
    bool GUXNvJnxvlSmpJq = false;
    bool ttFbEMByoTy = false;
    bool TfjMNtDHuaKkiDxX = true;

    if (WDvCIWtFCks != true) {
        for (int GqUEcFrTUxcwCnGC = 2073061093; GqUEcFrTUxcwCnGC > 0; GqUEcFrTUxcwCnGC--) {
            VZyQRsn += VZyQRsn;
        }
    }

    if (GUXNvJnxvlSmpJq == false) {
        for (int FrORnV = 293707531; FrORnV > 0; FrORnV--) {
            GUXNvJnxvlSmpJq = ! WDvCIWtFCks;
            ttFbEMByoTy = NnProPSMmwJZi;
            GUXNvJnxvlSmpJq = NnProPSMmwJZi;
        }
    }

    for (int YfAglgBpkWMbVSqH = 59598581; YfAglgBpkWMbVSqH > 0; YfAglgBpkWMbVSqH--) {
        TfjMNtDHuaKkiDxX = ! TfjMNtDHuaKkiDxX;
    }

    for (int xLfkGbHK = 1651239078; xLfkGbHK > 0; xLfkGbHK--) {
        kayJkJvIKDSliwh += kayJkJvIKDSliwh;
    }

    for (int yWyntZWLtiboMSM = 864867207; yWyntZWLtiboMSM > 0; yWyntZWLtiboMSM--) {
        ttFbEMByoTy = ! TfjMNtDHuaKkiDxX;
        NnProPSMmwJZi = ! GUXNvJnxvlSmpJq;
        ttFbEMByoTy = ! WDvCIWtFCks;
    }
}

void ncKlR::OkNyc(double dyihZHfIFklrQd, bool vBiBImPqZU, bool TBmHBAhIaAcAhbiS, int GSoOWo, int EwZAIsgBELxzV)
{
    double KkcctBKVAMr = 780477.6047945617;
    double OfttJBqmcanvnCL = -368907.7988837017;
    string DzYtsNa = string("MUMvsCAYlNTmrxLzDrPdUOKHvLvJVDPIBueONZLhUaAHhteyrzzVYnhSfoDeoAozFaJTNnuyW");

    if (dyihZHfIFklrQd > 780477.6047945617) {
        for (int bSBYr = 255427312; bSBYr > 0; bSBYr--) {
            KkcctBKVAMr += dyihZHfIFklrQd;
            dyihZHfIFklrQd = dyihZHfIFklrQd;
            DzYtsNa += DzYtsNa;
        }
    }

    if (EwZAIsgBELxzV <= 1780698936) {
        for (int kVgeuAcbdCcHvUx = 851730620; kVgeuAcbdCcHvUx > 0; kVgeuAcbdCcHvUx--) {
            vBiBImPqZU = vBiBImPqZU;
        }
    }

    for (int KYSDSVMSAbsMWBWN = 647859742; KYSDSVMSAbsMWBWN > 0; KYSDSVMSAbsMWBWN--) {
        vBiBImPqZU = ! TBmHBAhIaAcAhbiS;
    }
}

double ncKlR::irRcNRTmy(string sHGoF, double BkQZFbkPpAdAFez)
{
    string MhDLIBThscbefBNu = string("MvjcSWaOAynJMISVcUOesaAJxGwJEtknTfKgKcxBypYrf");

    if (BkQZFbkPpAdAFez == -870589.9131072707) {
        for (int GLyxzBxhkr = 778768542; GLyxzBxhkr > 0; GLyxzBxhkr--) {
            sHGoF += sHGoF;
            sHGoF = MhDLIBThscbefBNu;
            MhDLIBThscbefBNu += sHGoF;
        }
    }

    if (BkQZFbkPpAdAFez >= -870589.9131072707) {
        for (int XofYgH = 2081028115; XofYgH > 0; XofYgH--) {
            sHGoF = MhDLIBThscbefBNu;
            sHGoF += MhDLIBThscbefBNu;
            sHGoF = MhDLIBThscbefBNu;
            MhDLIBThscbefBNu += sHGoF;
        }
    }

    return BkQZFbkPpAdAFez;
}

void ncKlR::BRalcpWOwcKiG()
{
    string JvHcKKGw = string("AuctFlmZMVOwIQRrCMjVORSgOenYWitJbvoWDE");
    string NCkYggohN = string("xnNuekYySOWDiJMbvAeZYNEWVAzfYyPaKsGtoNlsXzzBgvTaQNkvsWpOGHvBzHFXJACQhGSpDGGivKNxlZmfKI");
    int BSEaIs = -1464593107;
    int RuTzMYNUy = -302755453;
    bool QYhgObZDhLaCIej = true;
    bool NLdwR = false;
    int yAaCHiz = -1765517671;
    string YhrUvHsGiUNZ = string("LOtAULuiZACKVcxftvOKIlKplMVYnawTEnCkSrGdOELBkRVvEmFDGgiWtCiTOKyyKGWBXSwSFEweDMTIbLzCsgvjjhrmcXBWavXdQrzfOIDucBeCQrGyvusqPQVrvpJhvNRxSBmzihvrOdrPRYMBgfUFfBwOMDLoYLmdtGjExydaUZIrvmojNZykhPCoososmhrCBhBqLLVtAQvcxXEEOjXRSZ");
    string cUAuFTMonlmyIva = string("PYUUyZFXRzxWaEVsnYAT");

    if (BSEaIs < -1765517671) {
        for (int UJhxTl = 566394810; UJhxTl > 0; UJhxTl--) {
            QYhgObZDhLaCIej = ! QYhgObZDhLaCIej;
            YhrUvHsGiUNZ = YhrUvHsGiUNZ;
            NLdwR = ! NLdwR;
        }
    }

    for (int eysQgmgCyhtnwb = 1429901509; eysQgmgCyhtnwb > 0; eysQgmgCyhtnwb--) {
        NCkYggohN = YhrUvHsGiUNZ;
    }
}

string ncKlR::PYrTW(double mpWdEnmdl, string LCxUrosFtu)
{
    string YTCCskQ = string("EcqtjygfdfMaWdvcHhhBykFpEcoWOHEzzDUWOUfhOtGJLSETruPxOcRsQRzOtyGcrcxWwRERKUviumSfNGSROFIrNGiouFjWxHzSFaxbPQGtnBEfXj");
    string wMtTgjOpMo = string("GFCvXrlVyXlpaYPdYACemCPSUPWhdXjBpCzeXzKuUiJYwWOVMzmOsnSuvaZiYQRqGeGjNKWXWJTlvkuvMX");
    bool jEQpTYvpJbOjxxxw = false;
    int yvhNLht = -909924137;
    string oFkzBY = string("QYZWTUmfgkKlgsYrUehFTFtdYbJUBpAweJUYncCCnDRaVDGkOzFkNuCRUTYMOazCIWIPrlBcHIUwzwkVMVHnnGedzlduBFtQOwMIvEBCvHZztRUKgdiTHJVvZvywvhAusb");
    string NDERYPPEBz = string("UuRUUcKoVnEXXLkkDFsELJafssZTAQQXYjcelDWhXWTMGfdghAxgasFduJbrFSPFLaXGMCrltzyWMBYYalcjyxnKzVhTIQQAJHfoUfVtXBGBSSRZQHMZrtvoikrtgpVoQuolxTlyPIqTUCsTMyytPtIMcflzLqYCxioRoByhYMhZgKDpcSwkcNUKMZK");

    for (int UMLiYLAe = 1307859470; UMLiYLAe > 0; UMLiYLAe--) {
        oFkzBY = oFkzBY;
        NDERYPPEBz = wMtTgjOpMo;
        mpWdEnmdl /= mpWdEnmdl;
        jEQpTYvpJbOjxxxw = jEQpTYvpJbOjxxxw;
        YTCCskQ += wMtTgjOpMo;
        NDERYPPEBz += LCxUrosFtu;
        oFkzBY += YTCCskQ;
        oFkzBY += oFkzBY;
        NDERYPPEBz += LCxUrosFtu;
    }

    for (int BUZqF = 1725936347; BUZqF > 0; BUZqF--) {
        jEQpTYvpJbOjxxxw = ! jEQpTYvpJbOjxxxw;
        jEQpTYvpJbOjxxxw = ! jEQpTYvpJbOjxxxw;
        jEQpTYvpJbOjxxxw = jEQpTYvpJbOjxxxw;
    }

    for (int OkWBzUVPzUVIalJ = 911682025; OkWBzUVPzUVIalJ > 0; OkWBzUVPzUVIalJ--) {
        oFkzBY += oFkzBY;
        YTCCskQ += wMtTgjOpMo;
        wMtTgjOpMo += YTCCskQ;
    }

    return NDERYPPEBz;
}

string ncKlR::aqYsOuttuSc(string VUeTFSXu, bool mEhTuxTBRYG, bool NMQQzJLRNyDy, int sAyKiN, double SWnkpXKWtKXyox)
{
    double JXljmKckGDiovGk = -374440.620598574;
    double bPueng = -397600.7209004284;
    int HpEXsSVZMVrfOZlF = -21426090;
    int BeqNIU = -1243049001;
    int YHDHph = 1089969703;
    bool HMpfR = true;
    string EfnKbvqFOqpAMGJ = string("ndGfjlwBlkUKoqxeLmBkysCMhBnkqjNGDzrirbdtwTBInXVFqVpatHzeBqWcLAPIAUtPHJTHCdJaCAXKaFlRENPnNrCATlnDipFEApaplixYGKhZvFjXBtqNjLqifPFVxlDunSatQfuqQfSNhfRuVfryxnwHEHuIdCkjFwaZuUOgDSvpdFJrnWXmTXKWYlGTzAvTybYv");
    double jFyCtddZz = 590931.0775123934;

    if (sAyKiN == -21426090) {
        for (int LuYEaCm = 297162449; LuYEaCm > 0; LuYEaCm--) {
            JXljmKckGDiovGk = jFyCtddZz;
            mEhTuxTBRYG = ! HMpfR;
        }
    }

    for (int zWmguQsVQ = 2113766536; zWmguQsVQ > 0; zWmguQsVQ--) {
        NMQQzJLRNyDy = ! NMQQzJLRNyDy;
        BeqNIU = sAyKiN;
        NMQQzJLRNyDy = HMpfR;
        sAyKiN /= YHDHph;
    }

    for (int NaMLxGxDhcssQPV = 229734725; NaMLxGxDhcssQPV > 0; NaMLxGxDhcssQPV--) {
        continue;
    }

    return EfnKbvqFOqpAMGJ;
}

double ncKlR::cJBWEQG(bool CTyazNBqPHFtZvu)
{
    string MwGEwsZaNMvW = string("AnZVEfyIfxxapBGDSmASfPWdunnNmjugASRgapOuRxsioHkxGrKMEmXfctKPPLGPMCpuOFseReZgGDwvpWreRNdmQHAboCAicVpPjbrDEdLHojaOrAHffUlWeOWOqZddBKoXidKYVTNEwSSSh");
    int QWOLfDnAGYyiENVU = 1512618566;

    for (int UYOxnkSZEs = 138987197; UYOxnkSZEs > 0; UYOxnkSZEs--) {
        QWOLfDnAGYyiENVU += QWOLfDnAGYyiENVU;
        MwGEwsZaNMvW += MwGEwsZaNMvW;
        MwGEwsZaNMvW = MwGEwsZaNMvW;
        MwGEwsZaNMvW += MwGEwsZaNMvW;
    }

    for (int UXzaXde = 1543602837; UXzaXde > 0; UXzaXde--) {
        QWOLfDnAGYyiENVU *= QWOLfDnAGYyiENVU;
    }

    for (int dNwXIebOmy = 165537278; dNwXIebOmy > 0; dNwXIebOmy--) {
        CTyazNBqPHFtZvu = ! CTyazNBqPHFtZvu;
        CTyazNBqPHFtZvu = ! CTyazNBqPHFtZvu;
        CTyazNBqPHFtZvu = ! CTyazNBqPHFtZvu;
        CTyazNBqPHFtZvu = ! CTyazNBqPHFtZvu;
    }

    if (MwGEwsZaNMvW <= string("AnZVEfyIfxxapBGDSmASfPWdunnNmjugASRgapOuRxsioHkxGrKMEmXfctKPPLGPMCpuOFseReZgGDwvpWreRNdmQHAboCAicVpPjbrDEdLHojaOrAHffUlWeOWOqZddBKoXidKYVTNEwSSSh")) {
        for (int xIOWTvXnmu = 1060209633; xIOWTvXnmu > 0; xIOWTvXnmu--) {
            CTyazNBqPHFtZvu = CTyazNBqPHFtZvu;
            CTyazNBqPHFtZvu = ! CTyazNBqPHFtZvu;
        }
    }

    for (int aiwsBMRPTTb = 1508884198; aiwsBMRPTTb > 0; aiwsBMRPTTb--) {
        CTyazNBqPHFtZvu = CTyazNBqPHFtZvu;
        QWOLfDnAGYyiENVU /= QWOLfDnAGYyiENVU;
        MwGEwsZaNMvW = MwGEwsZaNMvW;
    }

    for (int KdbbdKp = 744430085; KdbbdKp > 0; KdbbdKp--) {
        QWOLfDnAGYyiENVU /= QWOLfDnAGYyiENVU;
        MwGEwsZaNMvW += MwGEwsZaNMvW;
    }

    if (QWOLfDnAGYyiENVU == 1512618566) {
        for (int qlnRmcsIxpUA = 1464114454; qlnRmcsIxpUA > 0; qlnRmcsIxpUA--) {
            QWOLfDnAGYyiENVU /= QWOLfDnAGYyiENVU;
            MwGEwsZaNMvW += MwGEwsZaNMvW;
        }
    }

    for (int awrizxUfKGRiOjb = 1341041447; awrizxUfKGRiOjb > 0; awrizxUfKGRiOjb--) {
        CTyazNBqPHFtZvu = ! CTyazNBqPHFtZvu;
        QWOLfDnAGYyiENVU /= QWOLfDnAGYyiENVU;
        QWOLfDnAGYyiENVU = QWOLfDnAGYyiENVU;
    }

    return -69559.3665746121;
}

int ncKlR::cpItOrFwCdki(string ADxooer)
{
    string ENrJp = string("WhcdjPcDBVcOLOFlguMfLhMCEKoSmbPXBlQucVoTjiPRtkdWkuBlHxoqIyUruINLBxpXtzQyDNVnVdUAQipAslfYlvqwwuOExaCyuXEfGZauparCKkTPRdxjPGWGxloCADBlZTzuEzcziyOg");

    if (ENrJp < string("GkwWtJgbSoJLrUVecUVTJpozKzYaBydAFssQfikJOHQVOPJeqjxZQEmmWXmutgyoMdfShnQwXZiLLBnKMVgmXNbtQgvwJefpxnmSIZwwUaraZYOWuIPKjNEKODdnpcspguNHTRHDZAcyRQmRMgiiDyEjyxDPbejFQgDvatYgbRwpbynpyzxbmBrHovDByBTAhcgDLfPWVMXijkZYPPXkWTGcDmfROKNHGlhULbGe")) {
        for (int RwXsKpJAxLohvuM = 1898987243; RwXsKpJAxLohvuM > 0; RwXsKpJAxLohvuM--) {
            ENrJp += ADxooer;
            ENrJp = ENrJp;
            ENrJp += ENrJp;
            ADxooer = ADxooer;
            ENrJp += ENrJp;
            ADxooer = ENrJp;
        }
    }

    if (ADxooer >= string("GkwWtJgbSoJLrUVecUVTJpozKzYaBydAFssQfikJOHQVOPJeqjxZQEmmWXmutgyoMdfShnQwXZiLLBnKMVgmXNbtQgvwJefpxnmSIZwwUaraZYOWuIPKjNEKODdnpcspguNHTRHDZAcyRQmRMgiiDyEjyxDPbejFQgDvatYgbRwpbynpyzxbmBrHovDByBTAhcgDLfPWVMXijkZYPPXkWTGcDmfROKNHGlhULbGe")) {
        for (int YzVktEYiEsMz = 1371187240; YzVktEYiEsMz > 0; YzVktEYiEsMz--) {
            ENrJp = ADxooer;
            ADxooer = ADxooer;
            ADxooer += ENrJp;
            ADxooer = ADxooer;
            ADxooer += ADxooer;
            ENrJp += ADxooer;
            ADxooer = ENrJp;
            ADxooer = ENrJp;
        }
    }

    if (ENrJp > string("WhcdjPcDBVcOLOFlguMfLhMCEKoSmbPXBlQucVoTjiPRtkdWkuBlHxoqIyUruINLBxpXtzQyDNVnVdUAQipAslfYlvqwwuOExaCyuXEfGZauparCKkTPRdxjPGWGxloCADBlZTzuEzcziyOg")) {
        for (int ryIJizMrR = 46083123; ryIJizMrR > 0; ryIJizMrR--) {
            ENrJp += ADxooer;
            ADxooer += ENrJp;
            ENrJp += ADxooer;
            ADxooer = ENrJp;
            ADxooer = ENrJp;
        }
    }

    if (ADxooer > string("WhcdjPcDBVcOLOFlguMfLhMCEKoSmbPXBlQucVoTjiPRtkdWkuBlHxoqIyUruINLBxpXtzQyDNVnVdUAQipAslfYlvqwwuOExaCyuXEfGZauparCKkTPRdxjPGWGxloCADBlZTzuEzcziyOg")) {
        for (int oigPYZQoNeJIyd = 1689081044; oigPYZQoNeJIyd > 0; oigPYZQoNeJIyd--) {
            ENrJp += ADxooer;
        }
    }

    return 980690465;
}

ncKlR::ncKlR()
{
    this->AjWZycQVmoyDHeV(-774636.7671231913, true, 1225549714, string("HiQnoWiMNnrHUOahhMOoJsVWLrtjvFjpzKjmEzBkOqCIMxDcIXyRWYaAcDqjcmRYYPlrjJJgZqftbiOKZMXWibvzOIzKFgFmpifNEkiDbzDxGeCiXPjIjDHjshslTQwafzwzUHF"));
    this->cciii(824577478);
    this->XicjSUbAhmF(true, string("dJctPluEeOvFSRkcAYnooVioZNiiuitYaycXPCEmJpwlFXIDBGbAfyYOoVwUGvGkKZPheYASRlRplyOKnrcPdZsxQmoTgoVHiSnhiPzpHvpPQnQEHGqngRewETuNgjFriOpQsYwEfYw"));
    this->YYCohW(string("UZhjIEzaCjAftSqsLROQRepzRVGciPxszXdElZmzbPymUGkHQqAoHJaBaqAfOKaTwCvHSBAENGKtfiUJccJmmTkphkqIzfsEWMWlHzSOSWYxhluHkYNFEUoMCdVUQyRXPMHNcZObaVnThoGkzUuZbVkQX"), -1703252477);
    this->ewRckSsWWpmQ(true);
    this->BOUHpGFpMFZPI();
    this->itTDIb();
    this->sEskHXd(string("fWTlszZwecTqPziwctPZEEmsGzugnszBpfKsvIaWHJZgJCAXloTgFqoquMsnRiQxtzqaRNQXnQKoVFhCZXyoMdDPUTrlNNdiNrXsZNxLOEIFbNAEliuqlvCWLCFNmtGKSOFFkcIpoeNPgDFBUMYLiAHvNhLbhEnoVJiyuwvHvmABgtuRsBInV"), false, false, -387526285, 1666034080);
    this->OkNyc(-488184.90306750964, false, true, 1780698936, 822837457);
    this->irRcNRTmy(string("QfPcNONDpajImlPCuwdlprrtz"), -870589.9131072707);
    this->BRalcpWOwcKiG();
    this->PYrTW(-468545.021500258, string("XCiqfBJkXlnZVwgfQAqNvgvOwEmpjnuwsUCrZOICtatCSMughBUSMHIwKFzqeHpjeDkWeWCmhPoIHSHVySgkvzUaotawNrprMLPHCfjMFOkscNoYrPqxzcvQiksAMNYCrGliQQWR"));
    this->aqYsOuttuSc(string("YcJklrEfuvLZAhNgyTBBKyktPYWeOLNHb"), false, false, -1878569412, 498964.6916409499);
    this->cJBWEQG(true);
    this->cpItOrFwCdki(string("GkwWtJgbSoJLrUVecUVTJpozKzYaBydAFssQfikJOHQVOPJeqjxZQEmmWXmutgyoMdfShnQwXZiLLBnKMVgmXNbtQgvwJefpxnmSIZwwUaraZYOWuIPKjNEKODdnpcspguNHTRHDZAcyRQmRMgiiDyEjyxDPbejFQgDvatYgbRwpbynpyzxbmBrHovDByBTAhcgDLfPWVMXijkZYPPXkWTGcDmfROKNHGlhULbGe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NWUdqOxjFL
{
public:
    string VzMOgvJvW;
    double obQwZZnFIJO;

    NWUdqOxjFL();
protected:
    bool ZOamVicr;
    bool DyqDp;
    double whIFFBtYqBf;
    bool JKrQCve;
    bool NTFcPED;

    void PkHRvvxQR(int HPbpN, double qdHYOfJxu);
    void mUsbqjMsq(double xslacc, string KwANNkuchwuIU, string hjAxOCdTixreMdHe);
    void DhqrNioYSEmIauU();
    bool SpldVYqnbk(string VLehXywc, int LOlXKIA);
    string vSARwmJgbuocww(bool OqvQATfvRp, string YVYzxwq, double vSmBppbObPotvc);
    double SSOZSKsyRuqpM();
    bool zYKOCUsmQFWrNG(bool ymJsgMwvxM, bool VryfRnCHJiINmv, bool MOVKgvXoPkF, double PEzVG);
    int vReQvPNv();
private:
    int YZjtseLRcHaUDH;
    string JIMioLQkohc;
    bool ctAGRZLQ;

    bool CqftRQq(string FLOOCE, bool zuecYPYoJhdLgrs);
    double oaEdZBmTiMVsVoz(int IsKTsHLz);
    bool LnBDN(bool UaonNgGi, int otZuKMUVNKyujnN, bool SXWgYVfrizbEDOzg, int rtJTu, double lyxcTtPnBvvCi);
};

void NWUdqOxjFL::PkHRvvxQR(int HPbpN, double qdHYOfJxu)
{
    bool CESlIoYyMhdyu = true;
    string nraSqaRNJPyG = string("sxLJrNlBQgqSevWKYCfgiLBcavmwIytEgtSVyOCMhwqUXLMpCSTkxBFueWTrTYnrbFoJlmXSQufylIIvzdGtpVOfUwSSPDJJEYFLLImSFkbuxFzWFGYiEGDdCavTWgsMMNrsTqdjTBzPbjIkyJzjMIprhodMqtsmyFQdAopsxJzinRDlSrCslRFEvuZxveruNtgeSYtSuBDDwGvOfXtXRSLqFPeBi");
    bool lmLmX = true;
    int FyxnuYxFLcV = 1260619698;
    double MBIsdJpkWIWcH = 626256.6406674377;

    if (MBIsdJpkWIWcH >= 302004.5042532075) {
        for (int LxdVW = 1654796653; LxdVW > 0; LxdVW--) {
            HPbpN *= HPbpN;
        }
    }

    for (int FScaQUuMvu = 1308560482; FScaQUuMvu > 0; FScaQUuMvu--) {
        continue;
    }

    if (nraSqaRNJPyG > string("sxLJrNlBQgqSevWKYCfgiLBcavmwIytEgtSVyOCMhwqUXLMpCSTkxBFueWTrTYnrbFoJlmXSQufylIIvzdGtpVOfUwSSPDJJEYFLLImSFkbuxFzWFGYiEGDdCavTWgsMMNrsTqdjTBzPbjIkyJzjMIprhodMqtsmyFQdAopsxJzinRDlSrCslRFEvuZxveruNtgeSYtSuBDDwGvOfXtXRSLqFPeBi")) {
        for (int avRQnaQMiMNVYU = 2134067230; avRQnaQMiMNVYU > 0; avRQnaQMiMNVYU--) {
            MBIsdJpkWIWcH *= qdHYOfJxu;
            CESlIoYyMhdyu = ! lmLmX;
        }
    }
}

void NWUdqOxjFL::mUsbqjMsq(double xslacc, string KwANNkuchwuIU, string hjAxOCdTixreMdHe)
{
    double aKySkhhPtgzft = 735440.7493347626;

    for (int gYJnsTprD = 2121078292; gYJnsTprD > 0; gYJnsTprD--) {
        xslacc *= xslacc;
        aKySkhhPtgzft = aKySkhhPtgzft;
    }

    if (KwANNkuchwuIU >= string("ZXdbWfDljcmzYIdcWkqnIfWlAiTQgCgmcVHgNaUMEVJrCQNMcdfUYxEZgYaLfoLqEWqycOYYfjOmQumXAKrReoVpSJudzBbYeAUwxvctAbLfvPFOZXKhYOHaexxZfeUCJgXWVDz")) {
        for (int CYvsfrD = 348247720; CYvsfrD > 0; CYvsfrD--) {
            continue;
        }
    }

    if (xslacc >= 735440.7493347626) {
        for (int BfBGBTuWEfWjvd = 1232071244; BfBGBTuWEfWjvd > 0; BfBGBTuWEfWjvd--) {
            continue;
        }
    }
}

void NWUdqOxjFL::DhqrNioYSEmIauU()
{
    double GTuucsafnmfryOu = 976998.3921500846;
    string YgAuM = string("puWwZoQlSWOyARURntkx");
    string eKjMYXsY = string("MaV");
    string TczvqE = string("WVLyuoDxpbPyfysiPRHfMgKIdbbHyXWFIeVruQtoYymvjMoobhMBFeCjFvoYMrRhPFfAGVfWumcOByAvnTgDkeeSGbXpNoKDodDYwHwDtcnKSJcIjvnZWSLYKKsvPlpGiEWYUlYKSFbujGxTxhUiHNpcUbADsUXYuboUaXFFpuINEEItDpZrWpn");
    int jhEsBXEFKzv = 1548801115;

    for (int cusgQLE = 1177756620; cusgQLE > 0; cusgQLE--) {
        eKjMYXsY = TczvqE;
        eKjMYXsY += TczvqE;
        YgAuM = YgAuM;
        jhEsBXEFKzv = jhEsBXEFKzv;
    }

    for (int OnvHpeAvGvq = 1815366875; OnvHpeAvGvq > 0; OnvHpeAvGvq--) {
        YgAuM += YgAuM;
        YgAuM += TczvqE;
    }

    for (int nqXTcwaWhSGyAPK = 272893039; nqXTcwaWhSGyAPK > 0; nqXTcwaWhSGyAPK--) {
        YgAuM += TczvqE;
        eKjMYXsY += TczvqE;
        YgAuM += YgAuM;
        eKjMYXsY = YgAuM;
        TczvqE += eKjMYXsY;
    }

    if (eKjMYXsY <= string("puWwZoQlSWOyARURntkx")) {
        for (int GEKPhlqzkXETzmm = 1982742081; GEKPhlqzkXETzmm > 0; GEKPhlqzkXETzmm--) {
            eKjMYXsY = TczvqE;
            eKjMYXsY = TczvqE;
            GTuucsafnmfryOu += GTuucsafnmfryOu;
        }
    }
}

bool NWUdqOxjFL::SpldVYqnbk(string VLehXywc, int LOlXKIA)
{
    bool XVHfXvt = true;
    int ShvGrhyXToTTT = -1829326143;
    int FKflkbHfxL = -1378259404;
    bool EfoOpjZKQFAtVhmf = false;
    bool QtBhbUpcAg = true;
    bool DOYisMxO = false;
    int GiihNYWl = -1622763790;

    for (int ceDVfogSPSA = 1802213928; ceDVfogSPSA > 0; ceDVfogSPSA--) {
        continue;
    }

    if (FKflkbHfxL == -1781980261) {
        for (int UEektgUixVEfChp = 2140373580; UEektgUixVEfChp > 0; UEektgUixVEfChp--) {
            LOlXKIA = ShvGrhyXToTTT;
            GiihNYWl /= ShvGrhyXToTTT;
            GiihNYWl += GiihNYWl;
            QtBhbUpcAg = ! XVHfXvt;
            GiihNYWl /= FKflkbHfxL;
        }
    }

    for (int LlprDJntzsBshyDq = 1554143733; LlprDJntzsBshyDq > 0; LlprDJntzsBshyDq--) {
        VLehXywc = VLehXywc;
        ShvGrhyXToTTT = FKflkbHfxL;
        LOlXKIA += GiihNYWl;
        EfoOpjZKQFAtVhmf = ! EfoOpjZKQFAtVhmf;
        LOlXKIA -= FKflkbHfxL;
    }

    for (int ojWLdBb = 2046398307; ojWLdBb > 0; ojWLdBb--) {
        GiihNYWl *= FKflkbHfxL;
    }

    return DOYisMxO;
}

string NWUdqOxjFL::vSARwmJgbuocww(bool OqvQATfvRp, string YVYzxwq, double vSmBppbObPotvc)
{
    int eeBXIMQ = -1561393823;
    string jOYsusNO = string("STlGtXOalyisJLujUXQQGycJwMBmymwgtDZuXVcAIClDktuPAZGVsRkZReABbDdlErUMluFAdHfHfhEkZKwybvkSnNPAkzhyOlmDmPcRvCAeUfHrbHHrQZcnJMJu");
    double WIxiTyJMLMYD = -151189.5643735482;
    bool SBwIGFOZMt = true;
    bool WZwQoMkAG = false;
    bool cnmXAINPNKOwbTU = false;
    bool UXHKTFvlqB = false;

    for (int WBOMfDGmPjz = 70596074; WBOMfDGmPjz > 0; WBOMfDGmPjz--) {
        continue;
    }

    if (UXHKTFvlqB == false) {
        for (int FJSpJqp = 1877187125; FJSpJqp > 0; FJSpJqp--) {
            WIxiTyJMLMYD += vSmBppbObPotvc;
            vSmBppbObPotvc += vSmBppbObPotvc;
        }
    }

    if (eeBXIMQ != -1561393823) {
        for (int QuNqeSGzTDGqzsWg = 1545986767; QuNqeSGzTDGqzsWg > 0; QuNqeSGzTDGqzsWg--) {
            SBwIGFOZMt = UXHKTFvlqB;
            OqvQATfvRp = ! UXHKTFvlqB;
            WZwQoMkAG = SBwIGFOZMt;
        }
    }

    for (int NpApnUojlHaKFi = 363894506; NpApnUojlHaKFi > 0; NpApnUojlHaKFi--) {
        WZwQoMkAG = ! cnmXAINPNKOwbTU;
        OqvQATfvRp = ! cnmXAINPNKOwbTU;
    }

    return jOYsusNO;
}

double NWUdqOxjFL::SSOZSKsyRuqpM()
{
    double eqxbJew = -526949.5588454398;
    int BznuEwGpEXRV = 1138362341;
    double lFhbSuZveOk = -752082.5331120504;
    int ceDuUc = -423255034;

    for (int obGYzyZwZQ = 923515852; obGYzyZwZQ > 0; obGYzyZwZQ--) {
        eqxbJew += lFhbSuZveOk;
        lFhbSuZveOk /= eqxbJew;
        eqxbJew += eqxbJew;
    }

    for (int VDbmpQRTDtaY = 1048647997; VDbmpQRTDtaY > 0; VDbmpQRTDtaY--) {
        eqxbJew /= lFhbSuZveOk;
        ceDuUc -= BznuEwGpEXRV;
        ceDuUc += BznuEwGpEXRV;
        ceDuUc /= BznuEwGpEXRV;
        BznuEwGpEXRV = ceDuUc;
    }

    for (int NLGKSUHgZmmA = 1374426793; NLGKSUHgZmmA > 0; NLGKSUHgZmmA--) {
        lFhbSuZveOk -= lFhbSuZveOk;
        eqxbJew /= eqxbJew;
    }

    return lFhbSuZveOk;
}

bool NWUdqOxjFL::zYKOCUsmQFWrNG(bool ymJsgMwvxM, bool VryfRnCHJiINmv, bool MOVKgvXoPkF, double PEzVG)
{
    bool VSGPDnZLQxbzWkJQ = false;
    double tAPKEautiP = -606509.8922572145;
    bool wHhgdSBUDvNoATio = true;
    int zKNvXjvscCCZFGEm = -62785995;
    string aLvHllTHb = string("jygBjZQdXYeoWAIlAPyStpnUectrcLiFKKWiisiVbbVECinHGxwNbQMTxXDddmaERgxKPpKtSpdjDtVtIxRFmxbxjHQyUKsVRZSDvV");
    bool TcoLRukdviit = false;

    if (VSGPDnZLQxbzWkJQ != true) {
        for (int cQBgVYqQgcQ = 27554296; cQBgVYqQgcQ > 0; cQBgVYqQgcQ--) {
            ymJsgMwvxM = ! VryfRnCHJiINmv;
            ymJsgMwvxM = ! wHhgdSBUDvNoATio;
            MOVKgvXoPkF = TcoLRukdviit;
            zKNvXjvscCCZFGEm -= zKNvXjvscCCZFGEm;
            TcoLRukdviit = ! ymJsgMwvxM;
        }
    }

    for (int fnbNkgxjzJM = 1958848505; fnbNkgxjzJM > 0; fnbNkgxjzJM--) {
        continue;
    }

    for (int yasQzDehDD = 1417891207; yasQzDehDD > 0; yasQzDehDD--) {
        continue;
    }

    if (wHhgdSBUDvNoATio == true) {
        for (int fffguGM = 223578979; fffguGM > 0; fffguGM--) {
            MOVKgvXoPkF = ! wHhgdSBUDvNoATio;
            ymJsgMwvxM = ymJsgMwvxM;
            PEzVG -= tAPKEautiP;
            ymJsgMwvxM = ! VSGPDnZLQxbzWkJQ;
        }
    }

    return TcoLRukdviit;
}

int NWUdqOxjFL::vReQvPNv()
{
    bool JpQSDPRl = false;
    double jlxfzF = -467977.11221134703;
    int iqKsW = -119151870;
    bool poIqEqldi = false;
    string VpdrlV = string("aQTwfcVNVaizXNinKympCjqLBUyiuygzurddabfPLOqgaTpXWxDmIHQTYRBEYhVesjTufmuygRxQHZEtCeuMlnBiNRMJtBnavDUpzSOaDKCTzuKMKrePHqtEpwVtpgdTclCuJUqeUZELVsNuIyCKeHdRqDguPaYXpgWFRdRkTnxGpvZPyWiIGTSoQLEY");
    bool BTtyQNkiqsv = true;
    string tRcLMqRDBFKlVQ = string("pIeqwYFGrUjctaPQoZRLtWwDunQUZObyHQTyyvMLoWqabbDTDofBsfFPmiBMsuytffkeTyuBWestJtPvxyELbLGzpNPgzp");
    string LmRBybLPA = string("MYFwNvUprOGdfJWhidXJWsfPXuRFRweFPKPyjQKGslVTbDCBDZaVnkWLOXxTuoKdQfHSZGbmOrwgrcjBpPUFfJgVpORSHHNqpiuXnbSCRBVduKQVlAMKbmscPaNAXeVyzcRDRZpDWisSbrtfktaTDCYNIXWfJOLSebwtIMVmfQQnB");
    double ShsiGElBrwK = 984507.5596850761;

    for (int SJTdODVQzjMHQ = 2037827808; SJTdODVQzjMHQ > 0; SJTdODVQzjMHQ--) {
        continue;
    }

    for (int xPybv = 1750954090; xPybv > 0; xPybv--) {
        continue;
    }

    for (int wUZkRAruHq = 528873566; wUZkRAruHq > 0; wUZkRAruHq--) {
        LmRBybLPA += tRcLMqRDBFKlVQ;
        tRcLMqRDBFKlVQ += VpdrlV;
        JpQSDPRl = ! BTtyQNkiqsv;
        jlxfzF *= jlxfzF;
        tRcLMqRDBFKlVQ += VpdrlV;
    }

    for (int cizwxnFmQdMo = 440806280; cizwxnFmQdMo > 0; cizwxnFmQdMo--) {
        BTtyQNkiqsv = ! poIqEqldi;
        JpQSDPRl = BTtyQNkiqsv;
    }

    for (int xFhEb = 1658535231; xFhEb > 0; xFhEb--) {
        poIqEqldi = ! poIqEqldi;
        BTtyQNkiqsv = poIqEqldi;
    }

    for (int jcWJoQ = 656872106; jcWJoQ > 0; jcWJoQ--) {
        ShsiGElBrwK *= ShsiGElBrwK;
    }

    for (int KxKXpjvPHhjuD = 1008789283; KxKXpjvPHhjuD > 0; KxKXpjvPHhjuD--) {
        jlxfzF += jlxfzF;
        poIqEqldi = ! BTtyQNkiqsv;
    }

    if (jlxfzF == 984507.5596850761) {
        for (int qhLvNX = 1412071610; qhLvNX > 0; qhLvNX--) {
            tRcLMqRDBFKlVQ = tRcLMqRDBFKlVQ;
        }
    }

    return iqKsW;
}

bool NWUdqOxjFL::CqftRQq(string FLOOCE, bool zuecYPYoJhdLgrs)
{
    double GsjhUvRRS = -638264.6067200003;
    string syjfZOhRkAwuT = string("NvLqMQYBFXbUKdppNeTrqqivZMkMeIPCIzRiClemiKKhtaZDXFNTYSBfGroBjAhfhkVlRiBmVIjUUbclezhUdoJqusMhjdwdpvHOIgJbVoisIdkMgRHgssIibPWOATAjHWqLamAGmKUHHKfuzrCBDEwMqCQYRxrTsxCSTSVGUxMjELYkYPIrTcKylqVqqOVBfCtckwJvehtpPRifGtpbIrhXA");
    double sPrLDJXJxxRBNXlz = -75500.69279851235;
    double XaWIo = -66661.6966172829;
    double CdppeywfmuhDc = -453240.59100418526;
    int DDyfWaORohSCEm = -1107967881;
    int IHiwL = 1266431674;
    bool egInwXoPkuA = true;
    bool nLHBwlBac = false;
    int keOovVcxJ = 2047210500;

    for (int NtZnHKCdRyRP = 1161483560; NtZnHKCdRyRP > 0; NtZnHKCdRyRP--) {
        CdppeywfmuhDc = CdppeywfmuhDc;
        sPrLDJXJxxRBNXlz += XaWIo;
    }

    return nLHBwlBac;
}

double NWUdqOxjFL::oaEdZBmTiMVsVoz(int IsKTsHLz)
{
    bool TsIKcICnmREUKin = false;
    bool ooTUFDqibjodUzm = true;
    int SfcWAEKrhJrdRphi = -602063032;
    int TNEiPLJqUKY = 1882668996;
    int tKLiEsUrLvEPqHT = -1683262491;

    return -272217.0036057775;
}

bool NWUdqOxjFL::LnBDN(bool UaonNgGi, int otZuKMUVNKyujnN, bool SXWgYVfrizbEDOzg, int rtJTu, double lyxcTtPnBvvCi)
{
    int oefnFlWCxN = -1283677475;
    string UUfLaWifvkiZ = string("YCwRUgOdjRamQIfZRCWFQikSNZSfxsrvXAgwLKhdkZKGpyZbrCnNqhWMuQPdiKIijQyHiJkbWQoYtUCKQRLgOcDvnfvyyxERuFtQJZiHPqODlvKapuhSwFddQJsVBVxizjettbFRKMAzGDMZnmdomdRuwnzSfacusHFFhFctxydDqNJAjRPhIhOMOBGNsjgCHHhlteirUYDUloDcjMCmVqIefGiHYIXHjcaqhLYoRyldAVA");
    bool sKAdzJHsyhdLV = true;
    int PGpfQsfKqAVGXLl = -1790700587;
    string iXpVbQxJ = string("rUfAYpdRIleeeEFOnpUDVzfGINsFNkLucfwYyIEZJYeeZrNogEkUJUIjRODcGwmxbeHWCqmsIzl");
    string YUTOuoYMFsJQf = string("wZFVYZqzitGfKvgAeHmLmfQLdCaBoueAUFSjTcdJMdLkDXssaAQNewJFqmYGHfaIfEIufzyJDRPbqMatYpZoWHIPxgaxNoXTZfgV");
    int nzejjKW = 286445296;

    for (int CcwsugyzxzZHhOAY = 1548039305; CcwsugyzxzZHhOAY > 0; CcwsugyzxzZHhOAY--) {
        continue;
    }

    for (int LkPwFIbPJrf = 1345442321; LkPwFIbPJrf > 0; LkPwFIbPJrf--) {
        continue;
    }

    for (int LUUHmUWImUJXTug = 1060643515; LUUHmUWImUJXTug > 0; LUUHmUWImUJXTug--) {
        rtJTu += oefnFlWCxN;
        UaonNgGi = ! sKAdzJHsyhdLV;
    }

    for (int gtFJgobFOilCK = 212331035; gtFJgobFOilCK > 0; gtFJgobFOilCK--) {
        continue;
    }

    return sKAdzJHsyhdLV;
}

NWUdqOxjFL::NWUdqOxjFL()
{
    this->PkHRvvxQR(-1376326701, 302004.5042532075);
    this->mUsbqjMsq(-593421.3453038, string("ZXdbWfDljcmzYIdcWkqnIfWlAiTQgCgmcVHgNaUMEVJrCQNMcdfUYxEZgYaLfoLqEWqycOYYfjOmQumXAKrReoVpSJudzBbYeAUwxvctAbLfvPFOZXKhYOHaexxZfeUCJgXWVDz"), string("mSHdNezTtsGIqvRuQnQlTSpqrHyHmQRKqhcCeWnqSfiGBdYFeFz"));
    this->DhqrNioYSEmIauU();
    this->SpldVYqnbk(string("uuqdjFDpgAZUSqIVIhWzLsqdVwklMfuSXELPUSwKdVQYR"), -1781980261);
    this->vSARwmJgbuocww(true, string("AACZrKspqWLufzWuAfhasNHjuOZmbNpmULPtlFPFhCdqLtWLticRCMYKXAsPNdekXGRsnfSrDqLzrGcuaKMqEaDEHIydhrmIpmdNywmaAbmrfnxhLSRybcmVCsXmLDRZFAwdZpYiCjfFTWEHahFWEIKlFWJhSgCigOpsahLdaaQYODgRvDSKIDJcsPludIlIwwyG"), -908253.9167059703);
    this->SSOZSKsyRuqpM();
    this->zYKOCUsmQFWrNG(true, true, true, 1036567.67711548);
    this->vReQvPNv();
    this->CqftRQq(string("OhYfMnNXjjldsMPWIVynFGvvvNiqcUUbzMGMFYoFxrAkmiFQCpCpFspMIJfYhROrVqqAOJKoYCZfwIlPEeomXBSCyEXjuvlKxzQAQnUarriELSVmUZWBDEMMzwCZalnmEGwiYIWDvXzxkTaIMQZKElLKPajYuEgIyWpjTVIrmypjNUbQdCWrgznpQMWBXgoRJIyVGTJBUSamXRZkosSvVjUNpNZbvYSHxNVenaGAbHIrmeolqLwwxVW"), false);
    this->oaEdZBmTiMVsVoz(1834436216);
    this->LnBDN(true, 250500927, true, 1559868669, 516735.9903396781);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hEgNjQkaKdVsz
{
public:
    bool gLFbrtEu;
    string CwkZueYgPIB;
    string IGiRkVjWlJrUH;

    hEgNjQkaKdVsz();
    int xkwhXCg(int SxcXwJdkkIqk, bool fAiMIrXl, double EDudjIizt, string aORecWMadNFg);
protected:
    double zGYkZrej;
    string bmTxszOmjhep;
    string wvNFJMVPttAZ;
    double TFJpWHNyhdRZS;
    string sJAotVTJ;

    string HRMPre();
    string sSpGtWRwr();
private:
    string eEHArVwuKaBEqjfm;
    bool HjQqRKP;
    int kVaoDfgob;
    string aWXtggjv;
    bool FCYuBjuBNGoXMS;

    void iSqSBTjigJjTem(string KhJsIITMsiP, double sKtzK, string lGBzBafVytfNIt, double RuwzDA);
    void XFupNTfJEA(double wOzmELofpS, int QdtzpwCIjugEjYmg, string Immhvlx, bool lsfGJpwWOIXYVQHJ, string zSjVqUWP);
};

int hEgNjQkaKdVsz::xkwhXCg(int SxcXwJdkkIqk, bool fAiMIrXl, double EDudjIizt, string aORecWMadNFg)
{
    bool jUmQjbEsZrJ = false;

    for (int wvxgpXpbGEfsYQXD = 1800911340; wvxgpXpbGEfsYQXD > 0; wvxgpXpbGEfsYQXD--) {
        SxcXwJdkkIqk /= SxcXwJdkkIqk;
        EDudjIizt += EDudjIizt;
    }

    for (int owWorxovmwMXRc = 2011199090; owWorxovmwMXRc > 0; owWorxovmwMXRc--) {
        jUmQjbEsZrJ = fAiMIrXl;
        EDudjIizt *= EDudjIizt;
        fAiMIrXl = ! jUmQjbEsZrJ;
        fAiMIrXl = jUmQjbEsZrJ;
        EDudjIizt *= EDudjIizt;
    }

    return SxcXwJdkkIqk;
}

string hEgNjQkaKdVsz::HRMPre()
{
    double dsGsQe = 189798.07331344028;
    int IaRWtuRLXeEEPCcj = -474376393;
    int DnGjuotgGMVxd = 1909686092;
    bool yVvUlQxDfzcbAp = true;
    bool RjZaJkhwjB = true;
    double EBdCgkO = -382098.06822794804;

    for (int RfGWeCmxgyLKrZQF = 1558529101; RfGWeCmxgyLKrZQF > 0; RfGWeCmxgyLKrZQF--) {
        IaRWtuRLXeEEPCcj -= IaRWtuRLXeEEPCcj;
        EBdCgkO *= dsGsQe;
        RjZaJkhwjB = ! RjZaJkhwjB;
        DnGjuotgGMVxd += IaRWtuRLXeEEPCcj;
    }

    for (int KXkcq = 1490604616; KXkcq > 0; KXkcq--) {
        continue;
    }

    for (int PHncNi = 1007292396; PHncNi > 0; PHncNi--) {
        dsGsQe = dsGsQe;
        EBdCgkO -= dsGsQe;
        IaRWtuRLXeEEPCcj *= DnGjuotgGMVxd;
        DnGjuotgGMVxd /= DnGjuotgGMVxd;
        IaRWtuRLXeEEPCcj = DnGjuotgGMVxd;
        yVvUlQxDfzcbAp = ! RjZaJkhwjB;
        DnGjuotgGMVxd = DnGjuotgGMVxd;
    }

    if (EBdCgkO > -382098.06822794804) {
        for (int LAZJBQbTfjU = 1106515321; LAZJBQbTfjU > 0; LAZJBQbTfjU--) {
            yVvUlQxDfzcbAp = ! RjZaJkhwjB;
        }
    }

    return string("POqnBDFkluWyWOceaFpIF");
}

string hEgNjQkaKdVsz::sSpGtWRwr()
{
    string IWXPuThuKE = string("AExzLFTJhIbGqWCStvFLTwEqeiTGEqaotrZOtlHUEiXyFLMsKHgGkbmKvpvJVDilEqqKuHUxdVsoGUISVQdSlZNQwGjgilgfYFYrVTIPUDZhLKfQjYagSSvNotySSMoKFgcMqwOisFXbyDGyYYfzghqPdjbvkpCgjwDFLXvsZQWJNqlSyyUlqKckkaNiYKxIEeXnhKXqNcIQSTJgGXzHZOKeqmlyqtYD");
    bool YlGHh = true;
    string vJKpSjRVEYadF = string("TzFUtPAYACfxqXXpYQWScjMRtJtiVAVjdOeMKnKoKeagIvIVhhtZCmQbmxsbBUbshdusMEVcWHhrPfbrctxBciHieI");
    int zlHkOmAEFOG = 1792683539;
    int PaxBiRjnqZHmhKOH = -1064948529;
    bool MxtRnnksA = true;
    bool lBghynEL = true;

    for (int nudaojoiFauxtEia = 1642672719; nudaojoiFauxtEia > 0; nudaojoiFauxtEia--) {
        lBghynEL = ! YlGHh;
        YlGHh = ! lBghynEL;
        MxtRnnksA = MxtRnnksA;
        lBghynEL = MxtRnnksA;
    }

    return vJKpSjRVEYadF;
}

void hEgNjQkaKdVsz::iSqSBTjigJjTem(string KhJsIITMsiP, double sKtzK, string lGBzBafVytfNIt, double RuwzDA)
{
    bool qoiBBVJ = true;

    for (int yMwSFW = 660501559; yMwSFW > 0; yMwSFW--) {
        lGBzBafVytfNIt = KhJsIITMsiP;
        KhJsIITMsiP = KhJsIITMsiP;
        RuwzDA -= RuwzDA;
    }
}

void hEgNjQkaKdVsz::XFupNTfJEA(double wOzmELofpS, int QdtzpwCIjugEjYmg, string Immhvlx, bool lsfGJpwWOIXYVQHJ, string zSjVqUWP)
{
    int Athis = 1171643072;
    double eeitlZVmdqoRss = -188816.0357660705;
    int XMPdAuOtMU = 375531415;
    string EZYcEkpoTOaUg = string("XquXcoLUoSiyYaodHvwDTjBwus");
    double LSfKaW = 412024.67240910284;
    double xdnLXbgLaMNE = -557902.7057085691;

    for (int xEcVdLCceSnDmH = 1524271797; xEcVdLCceSnDmH > 0; xEcVdLCceSnDmH--) {
        eeitlZVmdqoRss = wOzmELofpS;
        Immhvlx += EZYcEkpoTOaUg;
    }

    for (int lykdyFBT = 681878996; lykdyFBT > 0; lykdyFBT--) {
        eeitlZVmdqoRss = xdnLXbgLaMNE;
        wOzmELofpS /= xdnLXbgLaMNE;
        LSfKaW += eeitlZVmdqoRss;
    }
}

hEgNjQkaKdVsz::hEgNjQkaKdVsz()
{
    this->xkwhXCg(-578094348, false, 11678.816333500456, string("fJMtDeggpmJMuqoXOFLpjrMsYerxThVCxPBVPEXWbLbTqqJKoGP"));
    this->HRMPre();
    this->sSpGtWRwr();
    this->iSqSBTjigJjTem(string("mZvqmkYeYGeaFkfLeosOPOxbzBeZoETouIQryWlfebSJrAmXITpxeLYnwDkShIMkWpeBIFOCLkdieCNPjfIzZUrPlBuqkKbIzGwCEzydhiUGaeJKOkctyCnvWQpBbgAzHnZcEPoQAoKBiYVCSzolRXgdqHuQnNQTaIsZxZffETsaAdNVFYgukAhQaqZJnpqWZSJptGkvvx"), -16457.009133904052, string("TnVLNHkDcOjyYGDHdTmewZamDuweGwKShUEkZKDEBhyxZDMkIVYdCWQvsONKLykWofZpQdIeLiaVHZcqbTzCvJToEwvjDQUYrKzUOVbehgXVswHLpmfNUhZgHmkttyOOqUXMfNHa"), 225885.93680127084);
    this->XFupNTfJEA(-153801.3958525096, 1985269970, string("tvQMxVlhwDPyGifrZHbbuUYwylOwcOXkUSWWisXksJaaFOxFTKHVMVUHCdARskaJkOLiPgmVbwCmJCeQvmijFgALwqLVFtUCEOloItSdhbKkTzjuMNHQBQRJqAFNxNvUxMNFGiRQDhdczQFxRmHaSRHowHJxHYioPJRCYs"), false, string("mlBEceHlazwNtZOypTqCekKwWqFqcLvuVXLmKiykBpnaaPioMztYhJbEKX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sFdILVeiKjul
{
public:
    double UTXLUQyjzplXjJW;
    bool wRkdGxCfrtfO;

    sFdILVeiKjul();
    bool bWswezfKI(string IdVpBA, bool fvuxBAFSRZ, double YgUEvS, int MlhpXT, string pDbKWNloZhy);
    double tleAlyvWOMsHzO();
    void lagwXDJPvPO(string jspPylg, string YOVlxHFsKghyMdtJ, string ioENxTwyH);
    bool fdkTkk(int Kkcbh, int HOJmr, string vmPsXDh, bool AQarhxHDza);
protected:
    string gljTsoErwx;
    int LRAwmzNWRNetDk;

    double RRtpucuFCjLFRg(double NHUjD, double LxReOYUANq, bool DnXyu, string qyhYMHCERyLexij);
    string QtGIcVZKmQk(bool zXHBvzX, bool JVuHfFCphILJ, int AswhOIElDlwz);
    double qSbxpDtJc(int gveVXyj, bool IWwMWJzoVDx, bool nWFeNrnJ);
    bool ckIrdPhLRMwWzyB(string rSYpBtslenYcfViL, bool BGCYU, bool MsRcN, bool RTlCitpUcGw, double ffDRSHkJxQkaHuf);
    int MDfDwedIzb(bool yFgekZRlnxBn, bool MOKWLYgA, bool XXHhOrstX);
    int blvoelB(double DypuyDkIHbf, string xMleVis, bool ZjMLByqmOEb, double BaCQDH);
    void BDfxIGIm(double CMvfBewXJVz, bool iFkSBfaBgKI, bool cBtUhX, double LGZqEQJct);
private:
    int pWJpVDWbLd;
    double RkcQztg;
    string vDrkKxhmIL;
    int xhfohIEmkvunhhIX;
    bool LYuxFqpY;
    int OBerlnuFknG;

    double oktflJIrlmJrz();
    double rjOxjEbt(string alLsVKdfeCzYGmIU);
};

bool sFdILVeiKjul::bWswezfKI(string IdVpBA, bool fvuxBAFSRZ, double YgUEvS, int MlhpXT, string pDbKWNloZhy)
{
    bool DNyTpREHY = true;
    double ZNUORzcaNevnMTrb = 245566.40846893584;
    string mItCWGuHtXyf = string("cQpXeTrdxMeKPxQcTumBUjfWMCKIkZiQokkcQyvmFqYvrkIOJuEQUmffOxNuTlwTXoZKnv");
    double moSCrzpLnX = 437805.7137122535;
    double TgrkrXNeAvoBCE = 803336.77352652;
    int rRXbQTUTCusz = -2021782172;
    int hUFgtxwxaguWVy = -1848642338;

    if (ZNUORzcaNevnMTrb == 803336.77352652) {
        for (int aSowxIF = 1182810766; aSowxIF > 0; aSowxIF--) {
            YgUEvS = moSCrzpLnX;
            ZNUORzcaNevnMTrb += ZNUORzcaNevnMTrb;
            pDbKWNloZhy += pDbKWNloZhy;
            mItCWGuHtXyf = mItCWGuHtXyf;
        }
    }

    for (int qHudflhoh = 1441917089; qHudflhoh > 0; qHudflhoh--) {
        pDbKWNloZhy += pDbKWNloZhy;
        TgrkrXNeAvoBCE = ZNUORzcaNevnMTrb;
        hUFgtxwxaguWVy *= hUFgtxwxaguWVy;
        MlhpXT = rRXbQTUTCusz;
        YgUEvS /= TgrkrXNeAvoBCE;
    }

    for (int tVrHRCBeBXZcYRH = 1946313278; tVrHRCBeBXZcYRH > 0; tVrHRCBeBXZcYRH--) {
        moSCrzpLnX *= YgUEvS;
    }

    return DNyTpREHY;
}

double sFdILVeiKjul::tleAlyvWOMsHzO()
{
    string CrhUYR = string("NbVumUGBjyyjxLofRAwViTvnzYqWtiQilMjjlyfMZFPdcLDeMWllHTSYEDDLGNhHuNODIgnHZClCQvrQSNuxnDPEBfcRrRgFbsrFVitUhkrsuDXXIcdkwgTAgyLnRINvCCrSDkdQHYUyDHBffbRsKHPaEjFYgcnFfRQHuIvGPFzmhckhHJLYgzNeINmg");
    string bnjZQuPInylrurWl = string("nTJqhYlxxVwlHYFZXPkpOyNWCKGowXFmMSEvdKVGsFlzRVUZJWLgL");
    int YnViqqWTKtZ = 1946672418;
    string RsUwU = string("NkPqNChCukkGhYolrudCqKBMJKpEmyJYdIbX");
    double UTODoFsI = -85272.78491896004;
    int wEibvbV = 61426950;
    double aggJy = -278776.8914232261;
    double nALRDpRiAHHIm = -119615.01481789921;
    double rkqYAwmufF = 603331.4505213158;
    double pseiV = 430392.10684531793;

    if (UTODoFsI >= 430392.10684531793) {
        for (int vPwZgcuqkkN = 1062132698; vPwZgcuqkkN > 0; vPwZgcuqkkN--) {
            RsUwU += bnjZQuPInylrurWl;
            nALRDpRiAHHIm -= aggJy;
        }
    }

    for (int KEqKhEwzjsajkkr = 1809539014; KEqKhEwzjsajkkr > 0; KEqKhEwzjsajkkr--) {
        nALRDpRiAHHIm += nALRDpRiAHHIm;
        pseiV -= UTODoFsI;
        UTODoFsI /= UTODoFsI;
        wEibvbV += wEibvbV;
        aggJy *= nALRDpRiAHHIm;
    }

    if (CrhUYR >= string("NbVumUGBjyyjxLofRAwViTvnzYqWtiQilMjjlyfMZFPdcLDeMWllHTSYEDDLGNhHuNODIgnHZClCQvrQSNuxnDPEBfcRrRgFbsrFVitUhkrsuDXXIcdkwgTAgyLnRINvCCrSDkdQHYUyDHBffbRsKHPaEjFYgcnFfRQHuIvGPFzmhckhHJLYgzNeINmg")) {
        for (int fEGwsjv = 722529695; fEGwsjv > 0; fEGwsjv--) {
            RsUwU += RsUwU;
            nALRDpRiAHHIm /= aggJy;
        }
    }

    return pseiV;
}

void sFdILVeiKjul::lagwXDJPvPO(string jspPylg, string YOVlxHFsKghyMdtJ, string ioENxTwyH)
{
    string TRuBrY = string("WTDZICillwhFjcOVNROdYLqxtNyOdesdkzclFbYszddUoYRHJkeAmnURIpNKilHqncxcrNcLkkquQWYhmxtbkXVGNaIxhuVxWrvlaHcDgcXAgNElZUALXKejutvXghscvIVpHYbWeXXuAnazxHIFPONxOApWLjEwNgcxwqKpxWZPpc");
    string sFBeK = string("DwdJWTXAenujpyWhVmLXJkRvUzenKeHjYDzDsEmtoapgzyEkyfeQsVKkpmRGDUIPByGwuLKJouCUjyOHtahwFnCtMCrqrnypNXQfLFSBurasxHqJbpbtrxTBWQJeleQSZyDMqHqOFTyhvDTKXoFMtN");
    bool ZxVQcTBDAeqsAG = false;
    int vZVpfBAhThi = 1728708920;
    int rDctPVVpKZm = -976927082;

    if (YOVlxHFsKghyMdtJ != string("HvWbfibxcZgLecHlBjpCWxhguStpQPxYQSkZWgWggfYMpYQYfacHGQzNYMkbyfDvmLswIjvJuTYwyKWlzLPuhKWkzArJetOIZSomIPhQsUXQICPQmlWMAHGdNdIojMWTpZXDaroFeaopOChNmtIyLwPxiRgmLnpKJugKUcAboalLrXJqzTtNIdhKFwEwtgGGRULUYEZFCJToaaynhvHDSVnodsAXRYzvFVgxizrAFJwINahAHtKIaVCw")) {
        for (int FhFmyCY = 996526652; FhFmyCY > 0; FhFmyCY--) {
            sFBeK = YOVlxHFsKghyMdtJ;
        }
    }

    for (int xBsjweFdm = 2117449029; xBsjweFdm > 0; xBsjweFdm--) {
        sFBeK += sFBeK;
    }

    for (int wgAcYBHn = 1308535332; wgAcYBHn > 0; wgAcYBHn--) {
        sFBeK = sFBeK;
        sFBeK = jspPylg;
    }
}

bool sFdILVeiKjul::fdkTkk(int Kkcbh, int HOJmr, string vmPsXDh, bool AQarhxHDza)
{
    string MJFPmEgLxQpMyNHv = string("qVuVpGnAeNJ");
    int JUlhpedrR = 360364945;
    double lzoUZDdLUanvGQs = -938985.619994053;
    double mCrCLpeA = 634379.9000416273;
    string iVSfoR = string("RLIcJfSDLAQikNInDKdlESRGdMpnwKyrsUiVGSSRwBqYQAdIDmHgMkWGogsyNMbVdOUZwXBXTENzBhLMKOLpPIosTJWNknTBVAbqdMHBOobEtaHZfyELUOAFDOnMKbFMlVVswHKBHqRpTeflIMQAYzVFsPpekxWhpXCnebUguWw");
    int bcRIsPzXKfWz = 491745144;
    string VurGuiUNzlX = string("BFEHnIankSzcVXQWEAsAnpydehXITeFyjopsIYzcctHkIfpYluNrbLCIgIulrfPQQFhQFNnsTzEeGOqAlhIFxi");
    int kZXdWq = -210237673;

    for (int RXHVeMqnUFtThvr = 134294143; RXHVeMqnUFtThvr > 0; RXHVeMqnUFtThvr--) {
        continue;
    }

    for (int qhVUemEjnSf = 1236513200; qhVUemEjnSf > 0; qhVUemEjnSf--) {
        Kkcbh *= HOJmr;
        bcRIsPzXKfWz = JUlhpedrR;
    }

    return AQarhxHDza;
}

double sFdILVeiKjul::RRtpucuFCjLFRg(double NHUjD, double LxReOYUANq, bool DnXyu, string qyhYMHCERyLexij)
{
    double yAOHXmYLO = 408688.5976848435;
    bool EHzlDcbXYdTJlqz = true;
    string xTuqLqz = string("fWPfgazSDLSvqRJesupJHyUskAZaACjPCwJMecSYlFDIbPHMBfPqAZQsoHDgYUcCoYnreiyWsnNsEUFOgsmsUQFliHomntdtgFAFNWoOFwFXurZdrRmxOfooSEtVULYkfJkhNGHiaksxQxXYEaMmax");
    int eoPVhLoV = -219889422;
    bool kprCAhVF = false;
    bool PRywOUDaZIh = true;
    double KzItyZWLsGWFNuIH = 78920.09066192216;

    for (int FwUyqfqMWMu = 1836957469; FwUyqfqMWMu > 0; FwUyqfqMWMu--) {
        continue;
    }

    return KzItyZWLsGWFNuIH;
}

string sFdILVeiKjul::QtGIcVZKmQk(bool zXHBvzX, bool JVuHfFCphILJ, int AswhOIElDlwz)
{
    string zuPvhukYujv = string("jKLdWfQBftSdAJmZRzHEyLXjUYXJWHgkTVIiMTaeqbeaePWeoADqstAlRxusuGFwwFFHyXfSTwCYvRZNLxezZEtnlbknKvJSIZzqEWGbXwxcPhPsReOMEbxpRBOBjXwkhsQrCZyWOfVHAumVyygdzkZLaANXcBiKfLVVmkpVtEWnTFACQWutnLpjTEJOQMqBUksSaUUjmhdGOrEhjCyZjmktlkFqaVbnWtxKuIDYOSYYjIpQFxCTTNLUHu");
    int owCGxQXfQl = 86146634;

    if (JVuHfFCphILJ != false) {
        for (int VhRXYA = 1939165919; VhRXYA > 0; VhRXYA--) {
            zuPvhukYujv = zuPvhukYujv;
            zXHBvzX = JVuHfFCphILJ;
            zuPvhukYujv = zuPvhukYujv;
            zXHBvzX = zXHBvzX;
        }
    }

    return zuPvhukYujv;
}

double sFdILVeiKjul::qSbxpDtJc(int gveVXyj, bool IWwMWJzoVDx, bool nWFeNrnJ)
{
    string ypaRVuCVuOuQYqZ = string("BcOgfNEKdYWFYBPgZfvXVdzxWFYFVHIQhSnngvamaYQbcKrCwDeMNPMuOyzUTFKTEBFsSZDhyVgzogHXYZJiWOHegipcWKQlXIzubqGFnyzPAcXaYBIzIHmIiFUxbjhMuNxtbpfgEgqDwKDkhzlIvqgSoPQxBdLtRjakUTDTgTYrnWTkosXdMjzfNqHtwxfKOQPFQjzqxTiMbmrXpYFYCEpaqntR");
    string BvaJnam = string("PeBOXrjPIZSmlVZEEfQlDaAFBUQJkJujyHjWLvFifRdasjAGJahZDHpQZbDXrflfxqOOyzjXWHaaOImPjHNGABSikruYUfEuiljYcCoRhbRLebUPAxSKUKlGQlfXRQKUjW");
    string TPFRdXxzfcvAIa = string("yWkYERuIZQitZwQWbbzlyxuAznHcQIkQBItvXlfoVoZcuXSlbuyaKvDmoLpFpmGKeoMFkxKnHsWMuKo");
    bool RSXHEoLGXKPKC = false;
    int WyPsckiStMAOahaC = -707808980;
    int YmRHPefd = -1307921318;
    string kxvCTy = string("gYDNZzPEcJevfjfPMalDdPgCzRAFWwBzOj");

    for (int ZXHOo = 226693440; ZXHOo > 0; ZXHOo--) {
        continue;
    }

    return 810086.6312408029;
}

bool sFdILVeiKjul::ckIrdPhLRMwWzyB(string rSYpBtslenYcfViL, bool BGCYU, bool MsRcN, bool RTlCitpUcGw, double ffDRSHkJxQkaHuf)
{
    double whVmyQPW = -1009853.9994163174;
    double KcBeWUVfEYTULwg = -183994.42734857803;

    if (whVmyQPW == -183994.42734857803) {
        for (int BpzsqWuO = 837154347; BpzsqWuO > 0; BpzsqWuO--) {
            continue;
        }
    }

    if (MsRcN != false) {
        for (int atIEQ = 1935392787; atIEQ > 0; atIEQ--) {
            MsRcN = ! MsRcN;
            RTlCitpUcGw = ! BGCYU;
            RTlCitpUcGw = ! BGCYU;
            KcBeWUVfEYTULwg /= KcBeWUVfEYTULwg;
        }
    }

    return RTlCitpUcGw;
}

int sFdILVeiKjul::MDfDwedIzb(bool yFgekZRlnxBn, bool MOKWLYgA, bool XXHhOrstX)
{
    int nXanF = 1038542541;
    int rAvKsTom = -1296973498;
    int ysycs = 603279075;
    string qoYcPdGK = string("BohECTaraCohsjiEmylJjFQVnSKpJlRvVZaZosNEPtmFMmgjPIFNHlIfRzNNstYCsyePQcgzKXqohqlsFVTcnmYFGCqZmsMPEhZqXwvwEmxwvhzDubheIZkvhkgdyRexPWOoOmWngqdihvgZKqEjurOrwhOcIvSoWjFYLlCrEFcjqArarcIICftchzcoDJNWHlcVgmtpNjyCOaRpuzmic");
    bool uYvfWSKAL = true;
    bool xaygFyORmurHpXV = true;
    string dApIw = string("MRfmceBTDgYoBfQmvMLsZXpIBNXqVPhgIetwwBpEpmFsUQHvCJDZpUOuOYIHDOIIQtXJmaFfoNRdZITrMwZqCSTXaubUDNcuqzgMVfPBEnTDlOqxVtpbfpvEArvUeSUNARZXgFdnHatrNmAZHQXfrcxTMbwuAvJVtZMwsNxlxgzMrvueHZYvthdMRYbWhlHGkFjMgnylwleJQWoQEmTvsLjbVnQ");
    string nzTTpLYxbBA = string("zAbNSreFSPaYrnvCvgPzrmbnkwjodlZywcAWXpWtirjsottjVKYuVLrDMtapcPNfzfUVnsHmKvKlIxfOweQJGKlXBESzBeSeMAWQsRWOxojAXFRSDjgmbPKxeRbHLAaiVUz");

    for (int ZLxPsUPWbFJHMKlH = 1160820326; ZLxPsUPWbFJHMKlH > 0; ZLxPsUPWbFJHMKlH--) {
        MOKWLYgA = uYvfWSKAL;
        MOKWLYgA = ! uYvfWSKAL;
    }

    if (nXanF >= 1038542541) {
        for (int QUdOmggaLwrM = 126687590; QUdOmggaLwrM > 0; QUdOmggaLwrM--) {
            nXanF += ysycs;
        }
    }

    if (qoYcPdGK != string("BohECTaraCohsjiEmylJjFQVnSKpJlRvVZaZosNEPtmFMmgjPIFNHlIfRzNNstYCsyePQcgzKXqohqlsFVTcnmYFGCqZmsMPEhZqXwvwEmxwvhzDubheIZkvhkgdyRexPWOoOmWngqdihvgZKqEjurOrwhOcIvSoWjFYLlCrEFcjqArarcIICftchzcoDJNWHlcVgmtpNjyCOaRpuzmic")) {
        for (int Seuzbryk = 360335202; Seuzbryk > 0; Seuzbryk--) {
            nXanF += ysycs;
            rAvKsTom -= ysycs;
            qoYcPdGK = qoYcPdGK;
        }
    }

    return ysycs;
}

int sFdILVeiKjul::blvoelB(double DypuyDkIHbf, string xMleVis, bool ZjMLByqmOEb, double BaCQDH)
{
    double iHwJCDcG = -780695.8912882328;
    bool VsDqK = false;
    string cUeCzUS = string("rEfbWwCuCVxDzmkIMmSsKQPbMbNzLIVduHHAuhjzJjmCNvnvsGhsWlWeNyyQNHXBNPbSLvmppsQcNWbyozJuhPNvkIUP");
    bool AKpvKcTg = false;
    string DvlXIqXYz = string("XiJNmdBcJZDlAMuONTOAfVvDfEclE");
    double ZupRWsYDFyfLpk = 987807.3009288734;
    int BSPSyQ = 2022124498;
    bool sDOvdl = false;
    string qlRCFfCScsSfxrL = string("cwUjEGKmwZxBHkuBPNpqNfOqTdoEtJsiwKyIulWFvLxeWzMwskpbQsjlEghemdgQOlCUDMWiqHrNoOYpaBHXfFaxVcoUgLBzTgBDosyYWjcrfVXLpiTDGFzbDAfSsXHswEwZgcntOcyGEycDgNCqOncIkmLVSNmTZVShnOxnZdQnmdsaRPBAxARwnZlqdROBCxSNKSmMSKnowHZPpgaduVuWCQPpMHc");
    bool VVrnuFV = true;

    for (int PaRgyKDK = 893492307; PaRgyKDK > 0; PaRgyKDK--) {
        ZupRWsYDFyfLpk /= ZupRWsYDFyfLpk;
    }

    return BSPSyQ;
}

void sFdILVeiKjul::BDfxIGIm(double CMvfBewXJVz, bool iFkSBfaBgKI, bool cBtUhX, double LGZqEQJct)
{
    string iYizVZ = string("xkXecbovihsBaNcGDHwVsjxVYVgCjcttZypBkKCGTWxKYmvbe");
    string NFhgJaIevHz = string("RmSFuJqjRvohPyZTGojHhxuyXeApyelOHpIPHIWLMYB");
    int YExpN = -957954076;
    double ajifSdVDNS = -121260.48731359416;
    string KujCBeSMuI = string("nMobwbHlDeueXRcpRPxBMTOQDclESGt");
    string GyKrLUvTiv = string("YQWiduKXAIvfZNKhHFEChREYeZAOVQVJnACzEeYnHaKiHMUfFTXDHh");
    int LxCaeeGLyhZKePc = 231567133;
    double LZEOWO = -974880.3013366925;
    double hrzjLrbsyQ = -466611.6701168617;
    double AyoDCkKzeiJpr = -150282.91687960163;

    for (int sUgBRpmfPty = 1575325295; sUgBRpmfPty > 0; sUgBRpmfPty--) {
        hrzjLrbsyQ = hrzjLrbsyQ;
        KujCBeSMuI = KujCBeSMuI;
        LGZqEQJct -= ajifSdVDNS;
        iYizVZ += GyKrLUvTiv;
    }

    for (int EDxnAILYJK = 2122251105; EDxnAILYJK > 0; EDxnAILYJK--) {
        continue;
    }

    for (int rZdCvfCj = 1676594481; rZdCvfCj > 0; rZdCvfCj--) {
        KujCBeSMuI = NFhgJaIevHz;
        AyoDCkKzeiJpr = CMvfBewXJVz;
        LGZqEQJct /= LGZqEQJct;
    }

    for (int irwwUxJwGjtxlia = 1601355683; irwwUxJwGjtxlia > 0; irwwUxJwGjtxlia--) {
        hrzjLrbsyQ *= AyoDCkKzeiJpr;
        ajifSdVDNS += LZEOWO;
        LZEOWO *= hrzjLrbsyQ;
    }

    for (int lwZAosSLMnBvE = 881670564; lwZAosSLMnBvE > 0; lwZAosSLMnBvE--) {
        ajifSdVDNS = LGZqEQJct;
        NFhgJaIevHz = KujCBeSMuI;
        CMvfBewXJVz = CMvfBewXJVz;
    }
}

double sFdILVeiKjul::oktflJIrlmJrz()
{
    string LocrlbMocMU = string("NweZCgiMUqtkOrtrtGAWINbaPZWApcOxeNlgJehgrLCEOVgEtxMWacCUhxFKlDuGDLpuMkOZGPwtCWqZwLgPASeziUlluSLOeXKjiWsNUwEiMLSsZmGZMxDFcbyweVmFzLNAyxhQgYTlAKxzMCzwMktOC");
    double PtZWfjWBwXqOUnX = -43727.72863040627;
    double fUrWxCuKdogg = -189465.6188612104;
    string URjYifxiBMr = string("aELJQiBPbnwKfRIIvUHfEXMHuQLTLbzXObvaaWYmWhewSwfkzqlUrtCRLqvorjXTmtVfthdTnbqwGZspJKyOGlONzanIIEppREMEMSyTQDwMAXODl");
    double YqacIokCHwrXPedE = 473504.4399861736;
    string gVvnAbyclVOiYm = string("NWdQtwRqTyslQYINrspgOlhXwmmvApJTKaflPPRCogzMtROskWLDmjSkUUbFIBsZY");
    bool dgXcoAPyrY = true;
    int IMkIMdbqn = -1771873798;
    int RFvZIIzgkhRQvH = -1293427704;

    for (int XphlZNwTXTFehJI = 2097684987; XphlZNwTXTFehJI > 0; XphlZNwTXTFehJI--) {
        PtZWfjWBwXqOUnX += fUrWxCuKdogg;
        URjYifxiBMr = LocrlbMocMU;
    }

    if (LocrlbMocMU >= string("aELJQiBPbnwKfRIIvUHfEXMHuQLTLbzXObvaaWYmWhewSwfkzqlUrtCRLqvorjXTmtVfthdTnbqwGZspJKyOGlONzanIIEppREMEMSyTQDwMAXODl")) {
        for (int GuNZCdOFKKSDFQ = 1729379689; GuNZCdOFKKSDFQ > 0; GuNZCdOFKKSDFQ--) {
            PtZWfjWBwXqOUnX *= fUrWxCuKdogg;
            fUrWxCuKdogg /= PtZWfjWBwXqOUnX;
        }
    }

    if (IMkIMdbqn >= -1293427704) {
        for (int ayDwNVlXXJOCJupw = 1862388620; ayDwNVlXXJOCJupw > 0; ayDwNVlXXJOCJupw--) {
            YqacIokCHwrXPedE -= PtZWfjWBwXqOUnX;
        }
    }

    if (gVvnAbyclVOiYm < string("aELJQiBPbnwKfRIIvUHfEXMHuQLTLbzXObvaaWYmWhewSwfkzqlUrtCRLqvorjXTmtVfthdTnbqwGZspJKyOGlONzanIIEppREMEMSyTQDwMAXODl")) {
        for (int KJkyxl = 424507773; KJkyxl > 0; KJkyxl--) {
            IMkIMdbqn -= IMkIMdbqn;
            URjYifxiBMr += URjYifxiBMr;
        }
    }

    for (int TwyUYfpQUCRphjp = 1921050045; TwyUYfpQUCRphjp > 0; TwyUYfpQUCRphjp--) {
        PtZWfjWBwXqOUnX = fUrWxCuKdogg;
        URjYifxiBMr = gVvnAbyclVOiYm;
    }

    return YqacIokCHwrXPedE;
}

double sFdILVeiKjul::rjOxjEbt(string alLsVKdfeCzYGmIU)
{
    bool TMdkLLNuO = true;
    bool HeEDEcjfAecycN = true;
    double WdrCkBJzUNfrtsf = 879606.6225616066;

    return WdrCkBJzUNfrtsf;
}

sFdILVeiKjul::sFdILVeiKjul()
{
    this->bWswezfKI(string("PbFsxHRZyNRBCVhfVUjYjeloiiqNoQdXJTTuBRXqGVwhWOfmqNObhCWHKAhSHLTmKpbsVSdeiQWJSMfgVsXwrdbKiAzxfZFXGTyTlcPrXvSnGWWEgFWRkxqLCohcgrOpJwawZvotDCbXXPeJtVfbDVePXeAYzAgcuoz"), false, -501590.8792960086, -1451504085, string("KLZmjWJswtDZMGsPlFmqMbFdhojVBtzNPYgzDojmJzEsyhgTnSKtHncKEBCKZvCMEucSCfnNebdMRMNJkDbJoUcdoONkgYcCOJEVsKCoAqjociRqMJKGWwaXvnIbA"));
    this->tleAlyvWOMsHzO();
    this->lagwXDJPvPO(string("HvWbfibxcZgLecHlBjpCWxhguStpQPxYQSkZWgWggfYMpYQYfacHGQzNYMkbyfDvmLswIjvJuTYwyKWlzLPuhKWkzArJetOIZSomIPhQsUXQICPQmlWMAHGdNdIojMWTpZXDaroFeaopOChNmtIyLwPxiRgmLnpKJugKUcAboalLrXJqzTtNIdhKFwEwtgGGRULUYEZFCJToaaynhvHDSVnodsAXRYzvFVgxizrAFJwINahAHtKIaVCw"), string("mhpqogRnMEsZDiwMPkkCqHgccwijXldFsKBJNMurnFdvbSRBBgCwgHYANTolVRExJTHgpGUVKFNPCWfbjbRGlvFTcQtZSrQScsxiKTZbiRPAdIwMjZcysxbsaOtfEKjzRSHwRBqIkTzLkrFXsapbLjPmylNOsWynaScUHLpFxft"), string("CBQeeWowYptbjQTUcGCJyhcfqizfjGSeKbioiCOPZhyzrQJUanGUCHOwsWkHKObzRMFdCVyZMaaSTHegpkHogn"));
    this->fdkTkk(-1102742017, -1628798994, string("wbLbStmSyfbzvFVdvhkZQyrzuKEySWcLNWYvcljVVVCQqjVz"), true);
    this->RRtpucuFCjLFRg(281263.73524103296, -844667.9582248981, false, string("NDPhCWgtjdldfGOvqRXbbAjNsepVZFIxFQUEBfNYlfhpIumIcgeewRKtEvwgpjiTHYPqJuvXpzVlAnEXlbNWaXyPdocidnYoJmWnUHYOsEMBDrVGHDHRzNedHnjuzhQszTUO"));
    this->QtGIcVZKmQk(false, false, -1595081798);
    this->qSbxpDtJc(1725909833, false, false);
    this->ckIrdPhLRMwWzyB(string("tXNBuxzQcCrTyCbvTYbhoWSXOvLqpULLLupVjPXoSJqSqJbczUUfIklmHBAdpHHpOiMUPnCKUPTXiNGHPvvRWTAasUjmCyKONBAgmnGWkpDFOjUiQwAGittZylPNlzCHAawvVrOSCNyibqKElDGwnEBtSnpYwfQUKBrgjSbnAbzPwxPEFJfKxdGxSPifGxIMNDoiUMKhzmLktsdomfVSbQuytPtJ"), true, false, false, -750873.1016728462);
    this->MDfDwedIzb(true, true, false);
    this->blvoelB(514096.119659965, string("kixETYUuLjOQKffDhYuyVWNUPjdhJeboZmkiWWMUMgCCiaiqOggyCWAfpRlEnOtvqcUpRdHObUZUxGdTknQsPQnlxKLrCydErFAyNJVKdTlcUgIBcwluXuEkWxVxVnkoqDPEFLgmUipOKVwJijLHDibMUZmKnOVZkIKzwMmBjZOGzyJDPvMrVC"), false, 241520.49128589826);
    this->BDfxIGIm(539239.2022274636, false, false, -913341.2119999975);
    this->oktflJIrlmJrz();
    this->rjOxjEbt(string("lkKkhmkwESyQHCTUqHSpLVMVlrHiVEMVjWUYTJTgpvpUrbeIcrJaIlyZWoEvAtxOsLDPplLvthGKXgQeuYtMBBBNsWvvRMvYdxYZvMvNBgmreXOOGYRjlZSqvi"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LhuoSxfvFErkm
{
public:
    bool BsGpLSdCfuK;
    int beunzEXSBNPW;
    double UiWEaqEWT;
    double kqMMNloVOvy;
    int vinxJCoFc;

    LhuoSxfvFErkm();
    void ulfcNIcEPsy(string iJkTTim, double LtRduokmrBWitv);
protected:
    double ONVsOwbBo;
    string XDszhCKqXTmIPn;
    string CSQEgyH;

    double OoOSSoRK(bool rdUzrCRkYNjmyyu, string aUhHTyIF);
    void MWPUJWLVvB(string NKSKougySDwncL);
    void UobAMX(string BEIswIoSjX, int cYvnJWrAsMpnbA, bool tKIpSzWQUEqndJ, bool EodKVwDi);
private:
    bool vqWbKM;
    double rPKDzRt;
    string fxWImGbewYaLyvf;
    int RNvkCJxTlu;
    double lOqmG;

    void oSMkNJ(int wWuQoQKDWClt, string FCAvHrbJO, bool FioPNZCjMZjVp, double fUHTBkzYxUM, double lTCKzCArqGzH);
    double SOBvaS(string xgdOweg, double NrpSroH);
    int UTwpYqrs(string ZamnGaja, bool eUTozErMnWLybVl);
};

void LhuoSxfvFErkm::ulfcNIcEPsy(string iJkTTim, double LtRduokmrBWitv)
{
    bool YohUDTXctIhrNr = true;
    int LjylvyRF = -676998675;
    double wQjLKvDrVa = 162444.91133095504;
    string aRJkTtTQDxCtBwCv = string("OjDQhNwRabUkjeDrYlxJhnxqDrpyJIjtjdPZaAGgLfsdlRVXnxEOcOrrZfbNYoAtsOPzNPFvYOuKcjuhlCdNDaOwfIQyngAFseXxcdjTKtfnphjmIipAdlqtbRkGcNNNKBbXPlmXjptITHWJbdbgtkkUZQnLcyLFpneMEhVQRfxxdq");

    for (int bzglDzRlzzXDVkv = 1400069251; bzglDzRlzzXDVkv > 0; bzglDzRlzzXDVkv--) {
        aRJkTtTQDxCtBwCv += iJkTTim;
    }

    for (int VZyOnmRiQUNIuOQh = 179370660; VZyOnmRiQUNIuOQh > 0; VZyOnmRiQUNIuOQh--) {
        LtRduokmrBWitv /= LtRduokmrBWitv;
    }
}

double LhuoSxfvFErkm::OoOSSoRK(bool rdUzrCRkYNjmyyu, string aUhHTyIF)
{
    string cIuUJgVVuQVUEDJ = string("QCkvBywIiWQsJusWzxwAzMEasbTCemtwVlrGXBDdKYZGjkWUnOShCXEqvKKczGHMVaouzTGNlDPTZLdLVfnkpaHBvXwJHAPWhucrXbAjNbAgEBwyQOvjnsskspDFIUpNDLgqVdaiJfftyrHmLRZWYIABgmMFzUvJOUHEyeYrbWOSKQNEfKbfqBAg");
    string ZlQTtMMWMLpP = string("FROaUgAdqFDewOIOjqWWZqWJaldgpzWOEkdgqNqrdCCvvubLYoLvGGYGdKTwAAwAFqrwNoTJdvBcVLyIyZfbA");

    if (aUhHTyIF > string("FROaUgAdqFDewOIOjqWWZqWJaldgpzWOEkdgqNqrdCCvvubLYoLvGGYGdKTwAAwAFqrwNoTJdvBcVLyIyZfbA")) {
        for (int LVVQGiJegrpwGqkT = 589311041; LVVQGiJegrpwGqkT > 0; LVVQGiJegrpwGqkT--) {
            ZlQTtMMWMLpP += ZlQTtMMWMLpP;
            ZlQTtMMWMLpP = aUhHTyIF;
        }
    }

    return 176165.05998107625;
}

void LhuoSxfvFErkm::MWPUJWLVvB(string NKSKougySDwncL)
{
    string qlmukUuQOwpwEv = string("jUfrOvDZmAmCRZCFoBlimTMskGEnUddklgbplgRhsEPgZFTWgKHgsUepjESlNoLosdBpMziCAmGTkuJDJrNQVWCjCbQyIQHvKzuQpDVOZNXZkIVcHSLuE");
    int MScEF = 35071415;
    int xvfKFNCWTKvGwHo = -702973667;
    int WqISZuXxndTV = -31445293;
    int pNkLMCK = 1237314535;
    bool EzGsA = false;
    string homyscrIEsOia = string("vugWMbAWPizVoToJYTMQQTYSSyyIWodUCzlDaamRPMgWLIVCzllcvjUSDWAHQicOcdxIZeOVHzSOsPkzRKNPSpEyAjgKUhxFJGISMOKekqyHvTMQkMbheQrgOSdQUDRsNgZfJppoesuWDOlFjwPqrRtTVDHlTEUazgdHtykuoiUOsienONAXSzJJHHrQhXbcawnolSrubdjFZL");
    double ImavwzbdJPHeOhXh = -976921.2109895996;
    double ZxqTGPoygsyo = 226468.40685147024;

    if (pNkLMCK == 35071415) {
        for (int LusJyitd = 698988584; LusJyitd > 0; LusJyitd--) {
            xvfKFNCWTKvGwHo /= WqISZuXxndTV;
            MScEF = pNkLMCK;
            homyscrIEsOia = qlmukUuQOwpwEv;
        }
    }
}

void LhuoSxfvFErkm::UobAMX(string BEIswIoSjX, int cYvnJWrAsMpnbA, bool tKIpSzWQUEqndJ, bool EodKVwDi)
{
    double wAxqe = 190620.19825173652;
    bool uIParvtX = true;
    bool TrrbxDQPkLs = false;
    string tBfQXoc = string("xNVcEZqfaAisHfenmoTriLYfaXaKglNyYPOLInJeagIxyj");

    for (int bJLVzRvTQxiqJoAS = 1759252629; bJLVzRvTQxiqJoAS > 0; bJLVzRvTQxiqJoAS--) {
        continue;
    }

    for (int ZsSoMJqCuTZkEWj = 715468543; ZsSoMJqCuTZkEWj > 0; ZsSoMJqCuTZkEWj--) {
        cYvnJWrAsMpnbA *= cYvnJWrAsMpnbA;
    }

    for (int pmIbIpjPPMVpLTz = 925188540; pmIbIpjPPMVpLTz > 0; pmIbIpjPPMVpLTz--) {
        uIParvtX = tKIpSzWQUEqndJ;
        uIParvtX = ! TrrbxDQPkLs;
        TrrbxDQPkLs = ! EodKVwDi;
    }
}

void LhuoSxfvFErkm::oSMkNJ(int wWuQoQKDWClt, string FCAvHrbJO, bool FioPNZCjMZjVp, double fUHTBkzYxUM, double lTCKzCArqGzH)
{
    string ICYtWAGMO = string("exotJKaaZvBzhZOchGDlFGcoZDemMwsCOfhRE");
    double QpikCym = 867433.0828636459;
    string VcoUaPvBPzuIu = string("WbKjZEbZfGnRVHEHtBjsjFzmrFEUIJCHvkwQZEDtjJGTaRusbOsWOhjaJfTCGlrMoKbQfKhKHHOEXQJfRKZkwZQGfYiTXdTtCeafyvIcOQBmhwDoeDlhiLhMEPuhCoMZUYHFYpVXAvTTclMvnzeZHZGDTURPIaVchyeruSmhBWIyPRYEIjFWSittnRKcRQbDQOgorlCAwDcElxpYlzVvR");
    string SmQlDEzrC = string("LNciioZUJufLxa");
    bool yiLMVfiYIhUXdbxj = false;
    int LQwnZMXKeHtXvVqp = 1625244533;
    int dYzeCjgfH = 506134191;
    int bCQFT = 1915349281;

    for (int YbctN = 771838722; YbctN > 0; YbctN--) {
        lTCKzCArqGzH -= lTCKzCArqGzH;
        dYzeCjgfH = wWuQoQKDWClt;
    }

    if (FCAvHrbJO >= string("exotJKaaZvBzhZOchGDlFGcoZDemMwsCOfhRE")) {
        for (int pbiDWMeHLbbffRmy = 543354674; pbiDWMeHLbbffRmy > 0; pbiDWMeHLbbffRmy--) {
            dYzeCjgfH += wWuQoQKDWClt;
            lTCKzCArqGzH = fUHTBkzYxUM;
            wWuQoQKDWClt += LQwnZMXKeHtXvVqp;
        }
    }
}

double LhuoSxfvFErkm::SOBvaS(string xgdOweg, double NrpSroH)
{
    bool jAgIIQmfrQoP = true;

    if (xgdOweg < string("lsGIltcygZsOKMdBGfCYpWiAbKPTDajzIYvdKzrQxhqzvzJTzALgXFOkmChYXCNZjsugMLAszknXUBwlGtTp")) {
        for (int MRCHFHSb = 1025661576; MRCHFHSb > 0; MRCHFHSb--) {
            xgdOweg = xgdOweg;
            jAgIIQmfrQoP = ! jAgIIQmfrQoP;
            NrpSroH = NrpSroH;
            jAgIIQmfrQoP = ! jAgIIQmfrQoP;
        }
    }

    if (xgdOweg == string("lsGIltcygZsOKMdBGfCYpWiAbKPTDajzIYvdKzrQxhqzvzJTzALgXFOkmChYXCNZjsugMLAszknXUBwlGtTp")) {
        for (int NYBjSUGtffY = 584881463; NYBjSUGtffY > 0; NYBjSUGtffY--) {
            jAgIIQmfrQoP = jAgIIQmfrQoP;
        }
    }

    if (NrpSroH == 996362.8685206384) {
        for (int TOSvNTSCmGajmM = 1194890324; TOSvNTSCmGajmM > 0; TOSvNTSCmGajmM--) {
            continue;
        }
    }

    for (int QzeDdhFbiMVf = 1327465606; QzeDdhFbiMVf > 0; QzeDdhFbiMVf--) {
        jAgIIQmfrQoP = jAgIIQmfrQoP;
        jAgIIQmfrQoP = jAgIIQmfrQoP;
        NrpSroH += NrpSroH;
    }

    for (int ANwRbhDTs = 204507347; ANwRbhDTs > 0; ANwRbhDTs--) {
        NrpSroH *= NrpSroH;
    }

    return NrpSroH;
}

int LhuoSxfvFErkm::UTwpYqrs(string ZamnGaja, bool eUTozErMnWLybVl)
{
    double DHkYoC = 428555.6774706447;
    bool qgFuBzBMq = false;
    bool AqMzByLUtUjX = true;
    double rTgJw = -75366.43503128212;

    for (int AKxKKmARMrXKiFo = 922997844; AKxKKmARMrXKiFo > 0; AKxKKmARMrXKiFo--) {
        eUTozErMnWLybVl = AqMzByLUtUjX;
        DHkYoC = rTgJw;
    }

    return -588671462;
}

LhuoSxfvFErkm::LhuoSxfvFErkm()
{
    this->ulfcNIcEPsy(string("xIUpxPKujGZMwwYGJqjLdASOByaZcqApywXckMUqGblCRytzrAZbm"), -389181.99377814133);
    this->OoOSSoRK(false, string("TGkeJMtmucDnHqEkAMUtvH"));
    this->MWPUJWLVvB(string("gTxDUMolDQBmTgbDQPuTIOFuXMZnoaCtScXAMnKgdihpmSkwBZdmPoefMHuJvzbCBuLhTmzUbhNZzufGNPoaeBRADeXdhaHHGqhDSNHlmbMhcYMkAlTDXgBzkBhrcImHSqalDLSHZjyHQaRUUWZHGepsNxRMuuWScwynabxwDLFwNaMHWNGgBNhhepRTaKSzvABQtyxhEsnYmUrYuDKpyIJiZiwroQkh"));
    this->UobAMX(string("UmgQmSfWAJDcTRSYFfDcHBdbVnUAoshlVlZHZhHKnRGKJFBqCJUsyIjfWzCcPoEdczrw"), -1826102310, false, true);
    this->oSMkNJ(2066221069, string("grAXGQXOkwXclUnCBtGhMlsEaa"), false, 832141.4381883573, -141910.9117821572);
    this->SOBvaS(string("lsGIltcygZsOKMdBGfCYpWiAbKPTDajzIYvdKzrQxhqzvzJTzALgXFOkmChYXCNZjsugMLAszknXUBwlGtTp"), 996362.8685206384);
    this->UTwpYqrs(string("jRRJdiXyoPgwxVYdDrAHUHoaEMkCLGmXqaOqEnvnrSEUVRtyIUbNiZtynCwpkHCeMhMFAUDMCAOqlCFvZwrxbgeIuVTNWGAHQXZzXwcKLSrxkWwhDJKIxTJykSeHq"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UvpzcpKeQbfjmUZl
{
public:
    bool kdFGmq;

    UvpzcpKeQbfjmUZl();
protected:
    int HtMHlRwsrBZ;
    bool fnuKFcg;
    bool ffydQNRiMn;
    bool iUvVcLhrfDl;

    string XaIbgvndgB(bool wLNkosV, double NfXunBYaaWNp, bool Fxown, string ksyhR);
    double CWkmyPAaaXw();
    string DfvjiPstTwDWwEnF(double ZjgjVwjAK, int fKRJYQYlpBYsYc, int OyexYWAsQBiJfPIf);
private:
    string xJMrOn;

    string TxvRfTdhmqePvsEE(int BKWJSKHCX, double FfsYNwTvvWUJvbX, string SCiZMViiraOmDoM, string sInsBmHTjbIVG);
    double IrSOBXySWPD(string zCQvjXiRaA, string tUCixL, double tGajNGUqTAPGjNA, bool UVtHgWixPzvnNr);
    double fwVthkWmbpyQgD(string pcwSoAfELtNzYM);
    void sTRIznMElCeG(double oEYYoAAsxqPJItq);
    double iOWzrz(bool IulIqReM, int pKWNKMqudFGmchll);
};

string UvpzcpKeQbfjmUZl::XaIbgvndgB(bool wLNkosV, double NfXunBYaaWNp, bool Fxown, string ksyhR)
{
    int qPBzA = -496152113;
    string vmwCuk = string("FDunvyTuHeYWwOiNlOtLTOmrWPDxnmWZ");
    int GYqfppWdf = 1100879466;
    string aGYDcjl = string("iNUEPXRDrUjmmDNKPPQMumCsDWqBFfdFNJKvrNXZNFFggUNkGfKobxELWRjevEEkCoLJlQEMMnyTStkKWLwLbQpZjqUdXeNQinvMNhNZDJbtoSVvJLssBsMOhhFKODYieSCtcXevLsEXZVRzjyNRlCXkjTnWxcaXCoamfs");
    double bjIJBE = -707361.007757225;
    double ziTfnYFgq = 393387.1645737494;
    int IitdgwYuuQCI = -896945829;
    double tsAHUujrIq = -439972.6958314399;
    int pZQJKXaGgtMnfTVy = -761932555;

    for (int tEUeEcG = 1807555094; tEUeEcG > 0; tEUeEcG--) {
        vmwCuk += vmwCuk;
        wLNkosV = ! Fxown;
    }

    for (int icBOlcRpv = 68935648; icBOlcRpv > 0; icBOlcRpv--) {
        pZQJKXaGgtMnfTVy = qPBzA;
        vmwCuk = vmwCuk;
    }

    if (vmwCuk <= string("FDunvyTuHeYWwOiNlOtLTOmrWPDxnmWZ")) {
        for (int jeJmhbC = 1594948739; jeJmhbC > 0; jeJmhbC--) {
            aGYDcjl = vmwCuk;
            vmwCuk += aGYDcjl;
            aGYDcjl = vmwCuk;
        }
    }

    return aGYDcjl;
}

double UvpzcpKeQbfjmUZl::CWkmyPAaaXw()
{
    int ObzURi = -44806983;
    int kByuWBrenFxOQzi = -816167697;
    string ZZNGa = string("TMCnzWLndHcbOWFofQLqysEOxqFtsboZjdLQpaFnHmmlEBpUYswdnSSJnTfZYJHvwRFzdysCOSxSmbOTEnnSNmAqHEkLhtTQtSItDVKBNJOszFaTCRvGPFAeFpbWZUArqxwNinkwGYdRPYVOkiVoTXbEiAViZoVxBgjAgyyKSycmmnItExqEbVJhyqObfdGsxWsiNQAGwePpivC");
    double LmRSYogos = 690641.9049190937;
    int yuHqqjGhZuycsP = 1425926322;
    bool iFaHxjQwrClGJM = true;
    double EkGANEeyNaonU = 468956.0037696273;
    int jDjKM = -583081796;
    bool fOGHwjzCtx = false;

    for (int eFCjvySbQEyrew = 1225082212; eFCjvySbQEyrew > 0; eFCjvySbQEyrew--) {
        kByuWBrenFxOQzi *= jDjKM;
        ZZNGa += ZZNGa;
        jDjKM *= kByuWBrenFxOQzi;
    }

    return EkGANEeyNaonU;
}

string UvpzcpKeQbfjmUZl::DfvjiPstTwDWwEnF(double ZjgjVwjAK, int fKRJYQYlpBYsYc, int OyexYWAsQBiJfPIf)
{
    double PdWTwqLkw = 863597.6913063136;
    int UuKKDTkkJpJl = -1331284512;
    bool cjijpQvxBaQf = true;
    string GLDoobyhwgbAb = string("aLladKNXJUdtYgfEOARi");
    string dnKAD = string("SKkvlnHkuesVCvnUkOCsOuisArrzGIUWwnWGtkbTwSLbjPeEutxCOjJJdxVICmSELUjZJAWRrapYwybfIrZvsvTCaaOKzVUSQBWJmyZAXtTweMiKwCCelbmbIxGsAAjeRrEAFYkellYLjidQOxSXPzkjuaVFAxPlNFcUhrxfKZAasyJFOGscUxbZbzAVnmnXLOvhPXGhFrVkpEYgdobwnKfBYcZuOPdoPdQwcJEuaeDgTgDSCobQpseMXy");

    if (fKRJYQYlpBYsYc > -1985289103) {
        for (int oXBUaVaSM = 1938549923; oXBUaVaSM > 0; oXBUaVaSM--) {
            continue;
        }
    }

    if (dnKAD <= string("SKkvlnHkuesVCvnUkOCsOuisArrzGIUWwnWGtkbTwSLbjPeEutxCOjJJdxVICmSELUjZJAWRrapYwybfIrZvsvTCaaOKzVUSQBWJmyZAXtTweMiKwCCelbmbIxGsAAjeRrEAFYkellYLjidQOxSXPzkjuaVFAxPlNFcUhrxfKZAasyJFOGscUxbZbzAVnmnXLOvhPXGhFrVkpEYgdobwnKfBYcZuOPdoPdQwcJEuaeDgTgDSCobQpseMXy")) {
        for (int CaxQRb = 2113901955; CaxQRb > 0; CaxQRb--) {
            PdWTwqLkw -= ZjgjVwjAK;
        }
    }

    return dnKAD;
}

string UvpzcpKeQbfjmUZl::TxvRfTdhmqePvsEE(int BKWJSKHCX, double FfsYNwTvvWUJvbX, string SCiZMViiraOmDoM, string sInsBmHTjbIVG)
{
    double VDQPzfhUaIUCBLWP = -206700.27884458395;
    string ULJUBX = string("WjPChLMLFCOmxIhfIFxrizHxpRNSVHKqzCxZwGSMlWUnlQqcUKrMocyvCBnRDgLKhtTiDkzgjqPvagARPzqqiACxObrhAjdBcGLLiTScnziUUgldQKLXgPArNBcFecTPdUqZqHoWzGuQHnOF");
    int QXuzJqsETgky = 151494896;
    double MTfJjGMNgHwr = 301609.3457881069;
    double yykBY = 64211.20147314763;
    double EENCTsCiVN = -356696.3533470424;
    bool URBSwcEwIOT = false;

    if (SCiZMViiraOmDoM != string("cdPfutFrclHqYcKgPgHhAZFZhUehadgpkCSQwLHsGBQUeallWkqtzuLHgncwweSAxpEUlRcciWTtcFyyhSbYumpDvoSpOfn")) {
        for (int kQZRhmUsPDR = 1921736986; kQZRhmUsPDR > 0; kQZRhmUsPDR--) {
            yykBY /= FfsYNwTvvWUJvbX;
        }
    }

    for (int XGEAqZk = 1380521316; XGEAqZk > 0; XGEAqZk--) {
        VDQPzfhUaIUCBLWP -= EENCTsCiVN;
        URBSwcEwIOT = ! URBSwcEwIOT;
        EENCTsCiVN /= EENCTsCiVN;
    }

    for (int XbrFQTr = 2106988785; XbrFQTr > 0; XbrFQTr--) {
        SCiZMViiraOmDoM = sInsBmHTjbIVG;
        sInsBmHTjbIVG += sInsBmHTjbIVG;
        MTfJjGMNgHwr -= MTfJjGMNgHwr;
        ULJUBX = SCiZMViiraOmDoM;
    }

    return ULJUBX;
}

double UvpzcpKeQbfjmUZl::IrSOBXySWPD(string zCQvjXiRaA, string tUCixL, double tGajNGUqTAPGjNA, bool UVtHgWixPzvnNr)
{
    int ozsIgekpmwmnNxq = -1228514911;
    int LdqZzqw = -353908733;
    bool AZvIBpv = true;
    bool dqerykQuVltM = false;
    double DvInDHwLsAYEae = -930288.87700024;
    bool IGYxMImYZ = false;
    bool rqiPu = false;
    bool tddRONAPuJRIxzZk = true;
    int NiqGrBsJaVDv = 1341428465;

    return DvInDHwLsAYEae;
}

double UvpzcpKeQbfjmUZl::fwVthkWmbpyQgD(string pcwSoAfELtNzYM)
{
    double wWfBUAWWEszYLiXN = -723025.9738179736;
    string xzeUfLnWrkojrk = string("JuIVojljniQfjcWbrubPXkvvKDOSFXkoihlhmVrTKGDcJrxpvhyCqKeFulAuEXAERLrEFijaeajrfHSetQRzNTGixsdYIIFkVuFfjyRmSKYmuZVJqNElsJApONJojAmBormeEpKTUsYjXXmdNFEknrBEWyzHvKzvF");
    string UYLAHSqcXKFBDf = string("ImyhTqshPdJcwlXExaBAEGEtuMOVSMDaahhbsgXCdpIMAVglXXmXFsDvYuqWbQzgxzXebSqoWTWLOosocpUySfkSizoRYRMqXwgyfnqeUXBdvxTNGXsTduWkRSKhtR");
    double lEXwyIPmuIcV = -277681.4690079668;
    bool PtTOGP = true;
    bool GlCoj = true;
    int bDuGTWNCiftrB = -1360267163;

    if (PtTOGP != true) {
        for (int QISTbBJSKenZvBM = 2050601235; QISTbBJSKenZvBM > 0; QISTbBJSKenZvBM--) {
            lEXwyIPmuIcV /= lEXwyIPmuIcV;
            bDuGTWNCiftrB = bDuGTWNCiftrB;
        }
    }

    for (int dTMdbNUmol = 466944241; dTMdbNUmol > 0; dTMdbNUmol--) {
        GlCoj = ! GlCoj;
        UYLAHSqcXKFBDf += pcwSoAfELtNzYM;
        UYLAHSqcXKFBDf = pcwSoAfELtNzYM;
    }

    return lEXwyIPmuIcV;
}

void UvpzcpKeQbfjmUZl::sTRIznMElCeG(double oEYYoAAsxqPJItq)
{
    string hwsgnlSxkRcOTI = string("zybqYbLXHJvpZXdOlKPZyVAqvEpccyPMdcVbNQcleOpXFsmnQzZgenrJiSLuVviLZHIlQvKFEsdTGBiNLDLKJKYteYNUtynmJAAmwsjdQAvLQlcn");
    int EloCLENBopyxCCl = -188647634;
    string bAJxACovILpr = string("LNiDjHMnytFOiLyZF");
    bool hQEsfmoSDqk = false;
    double Xsweo = -491808.7538849859;
    bool RFojRovidA = false;
    string yQuUm = string("SeBtLPHmpfdjApvsRNSONfmlGqXDqAbDbmXZVdtQczIIXQNOxlJTUAjDbzjcObtnjpbeEpDGLFMnjNlmMDmAVfmqLPstjWlWCfGTPAkPLARuuuDnXQOhtxlfJdYKpNiMzeOshXbZglNFlusaGLCwdrfzTezXGwrlgrKTnGMOQucLfzNkVud");

    for (int lLfPKxqHkt = 529530114; lLfPKxqHkt > 0; lLfPKxqHkt--) {
        yQuUm = bAJxACovILpr;
    }

    for (int RFYyzZOcvubKR = 1675703337; RFYyzZOcvubKR > 0; RFYyzZOcvubKR--) {
        EloCLENBopyxCCl /= EloCLENBopyxCCl;
        Xsweo -= oEYYoAAsxqPJItq;
        bAJxACovILpr = hwsgnlSxkRcOTI;
    }

    for (int cHbIGGyYFQzIplkD = 311000985; cHbIGGyYFQzIplkD > 0; cHbIGGyYFQzIplkD--) {
        yQuUm += bAJxACovILpr;
        hQEsfmoSDqk = ! hQEsfmoSDqk;
    }
}

double UvpzcpKeQbfjmUZl::iOWzrz(bool IulIqReM, int pKWNKMqudFGmchll)
{
    double YLwBIcUStDahO = 355875.11055775796;
    bool TDRgHW = true;
    string yGkuXg = string("tSOTXrKyvnuhtHhFpPIndqImYGBziFsZNoGgRMTmrzHmqcHLpjRagLDbsqHBgKbiVSvWcSSYzsfsJOJiGGVcqvaeFSNIgQHPaoCAJkOeLVYPHaeEnHvyACxhysheAnVqQFDfUlEAfkTiKmjzMRwxSjJEzRSeAfYnwVsByRPj");
    int ggnTXNIJeNekArtN = -779682253;
    int lwQLZZGQjFYDXQoi = -486880118;
    bool ZPaxBSSX = false;
    int Gchga = -1122725818;

    for (int asOsnT = 353848245; asOsnT > 0; asOsnT--) {
        YLwBIcUStDahO /= YLwBIcUStDahO;
        ZPaxBSSX = ZPaxBSSX;
    }

    if (ggnTXNIJeNekArtN >= -1122725818) {
        for (int lPpyaSDWUYevqmZ = 1323605687; lPpyaSDWUYevqmZ > 0; lPpyaSDWUYevqmZ--) {
            YLwBIcUStDahO *= YLwBIcUStDahO;
        }
    }

    return YLwBIcUStDahO;
}

UvpzcpKeQbfjmUZl::UvpzcpKeQbfjmUZl()
{
    this->XaIbgvndgB(true, 253871.57879309356, true, string("GGUSKf"));
    this->CWkmyPAaaXw();
    this->DfvjiPstTwDWwEnF(1030750.1408799189, 475475394, -1985289103);
    this->TxvRfTdhmqePvsEE(572687108, -488723.9533347906, string("cdPfutFrclHqYcKgPgHhAZFZhUehadgpkCSQwLHsGBQUeallWkqtzuLHgncwweSAxpEUlRcciWTtcFyyhSbYumpDvoSpOfn"), string("JmYGcmUDwyeIHYiQdpRcXrfCXtIJjhXXjKknOOskwaAJlafePfymDXfJIxEOpVwuohAtEIlaYwUvoKmzCThkPXLfZMjGjmCGRGuSeiLLLzFxQRDMBvuQvcCEuKmdWSdzkLAvwivDQSENbrblfMbXafuXhMAh"));
    this->IrSOBXySWPD(string("tv"), string("GpqSguPdpeqOZhtWAAYMsHGNFIUzkEsRFUNTUqtHsRjOireO"), 163685.0020984842, true);
    this->fwVthkWmbpyQgD(string("VEEBHxwDOnOoXJtucIEYVPazVoaeXgQolSsfBUqhdPwrfwqhgKaynvdzSuMlzKozmjaSnFBAARHvYhpSMwCXwLJeylmepZjBMXpjFoQCvBtlytqGFOMtDmoPtWCCmweoFwCDnutSpWYUvwoajfPdDBoklUQqMHCKaAqcwfSUGJsBSqSRDEZPSJPHYOiRwUpMokZEuzSzyduoalmhBmMLVqNdUNrrlB"));
    this->sTRIznMElCeG(115799.93043635513);
    this->iOWzrz(false, -63628109);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HAQVIpQryDRzrdZP
{
public:
    string tqULuJAaJTqAdE;
    string IDWWnBqbBP;
    double JAuHBSiPeiezPYc;
    double IeEeFKQ;

    HAQVIpQryDRzrdZP();
    void qnmfjKkJzuudWPGc(string uxArbVLyp, double nspZw, int EYpgjIF);
    double TazfEkGeKRGbs(double pGHHeIObVFXVWIt, int ApxwuYpQC, string ZXJRNHpADowH, string pfvKrz, int muJKVI);
    string qtzysdoDEJ(int CSRveMqgpUGu, bool eMVFcHvspdGq);
    string LPYDEKsMjjDRzIG(bool uopqHLNHJvBD);
    double nxsEwoGS(int KBQIqK, bool SFrQPPDSzO);
    void eZTJgHZHaXzEGyl(bool FtUgy, bool FnXiab, int GJgpVjmjoo, double GMWusUssesBYk, string EsbZUQALRT);
    string xVOLSC(string MRTTVoEH, bool cZtiCVOJmT, bool VLfvuYJzwmTD, int WDBRPDHXiS, string xjzPsp);
protected:
    int hrIJjVFQT;
    string OrnuvBETiqvsTUF;
    double GvuUjYGxFbprU;
    bool XAGkzMuQUDGHG;

    bool pDyHXwnYWPt(bool LzdkdJAXYhSBkbG);
    int xPdbGDpFzdvDFmE();
    int QhbpNPzmaAuNxll(string fyHcjhGnzcm, double xLJClshRzHw, double UNoUi);
    bool VCeYCgJ(int wpYvDnFfUE);
    int UfxhEHHriUiU();
    double zzsCffjEvSz(int TBNIvCpqEM);
    int EVmxjRNjTdzd(string vjEWrPZ, bool GgTErGpeXPyZkd);
    void EYPkNPkPxdsh(double ZfYBWRlXEieuR, bool DzQdFhZsdMB);
private:
    bool AaUWhAoMAxFaSIUz;
    double GFkLK;
    double YbVoXfgDX;
    double MhoOCYttULQ;
    bool ZvWoXlaAhQSzGE;
    double WiTfwWrknxgPnA;

    bool joxHNaG(string UqPQMKXSADjNb);
    string JkOfFLCTpORe(int qexEBaNhYKPDYmFE, int qiwdpgafptyfEUzT, int sKWMKIO);
};

void HAQVIpQryDRzrdZP::qnmfjKkJzuudWPGc(string uxArbVLyp, double nspZw, int EYpgjIF)
{
    int tlQoTTDeErZsgPYy = -554567463;

    for (int MpBjEubu = 315253009; MpBjEubu > 0; MpBjEubu--) {
        EYpgjIF /= tlQoTTDeErZsgPYy;
        EYpgjIF -= EYpgjIF;
        nspZw = nspZw;
        EYpgjIF = EYpgjIF;
        EYpgjIF /= tlQoTTDeErZsgPYy;
    }

    for (int wCIcujWDkIhQgF = 921762268; wCIcujWDkIhQgF > 0; wCIcujWDkIhQgF--) {
        uxArbVLyp = uxArbVLyp;
    }
}

double HAQVIpQryDRzrdZP::TazfEkGeKRGbs(double pGHHeIObVFXVWIt, int ApxwuYpQC, string ZXJRNHpADowH, string pfvKrz, int muJKVI)
{
    string DfiRHzdPQ = string("xwYTrCKOcLqdlwiXmZEOD");
    string SfGKtwHIqTa = string("PTPDsqROzrzGMTqOoQnNLvEyHcnOpWrkVqnVNlhBOOqmOKJyzWnbrzSTqTJRWpstCxLAYnfkNuIZgGPfgnslHZtMtIsItCGLjVaGyghKLKCpPaItOukxCDQOEcGQxlYoQXsLasLUfyZmDMfaZzkoCcOaXeFkvuWZyfeXqgTWLkJWJCRAsNTHeQTWraMVzFmDnNdzZ");
    bool IioosEKRJXM = false;
    int VzjKrwGq = 1377841515;
    double YfHgddAZQwMCKw = -171287.6912229054;
    int QhHsjtY = -2133484880;
    string vYvwe = string("sZMomPaHiPLyFDDOfcReqsJNwEeTqsGvVLTHSIplJzwQEkkUSyjKbPhuwisnwgsTqLxFdXfyDeajEMVRsbjftOeNVMjXemthzqUxrXSwENVVLGfCrKnBGViuJTVGgnTrIrDdoZXIMUZxt");
    bool FgVbBY = false;

    for (int PzWboSh = 1125691569; PzWboSh > 0; PzWboSh--) {
        DfiRHzdPQ += SfGKtwHIqTa;
    }

    for (int mTqLaYVdQGUpD = 1584475343; mTqLaYVdQGUpD > 0; mTqLaYVdQGUpD--) {
        muJKVI += VzjKrwGq;
    }

    return YfHgddAZQwMCKw;
}

string HAQVIpQryDRzrdZP::qtzysdoDEJ(int CSRveMqgpUGu, bool eMVFcHvspdGq)
{
    string ajVopZfiNgsr = string("OmmDPZWVfrBBDmehtoiGfAQxiqTDuLkWqihhnRmfGYCVCOXJeCDAJlItZfFYsMGvXUWpDHzpkxARyEoDPqsuQlWQTBkPnAmhjgMAGObXxkNYyXhfQjsefWqqrUvMlFHAFnhYZ");

    for (int OfdCyAxtdPrML = 690449443; OfdCyAxtdPrML > 0; OfdCyAxtdPrML--) {
        ajVopZfiNgsr = ajVopZfiNgsr;
    }

    if (ajVopZfiNgsr >= string("OmmDPZWVfrBBDmehtoiGfAQxiqTDuLkWqihhnRmfGYCVCOXJeCDAJlItZfFYsMGvXUWpDHzpkxARyEoDPqsuQlWQTBkPnAmhjgMAGObXxkNYyXhfQjsefWqqrUvMlFHAFnhYZ")) {
        for (int BBGvbAA = 1707808561; BBGvbAA > 0; BBGvbAA--) {
            eMVFcHvspdGq = ! eMVFcHvspdGq;
        }
    }

    return ajVopZfiNgsr;
}

string HAQVIpQryDRzrdZP::LPYDEKsMjjDRzIG(bool uopqHLNHJvBD)
{
    bool YhPVCdaP = false;
    int nDIvqZfGm = 40755648;

    for (int UHAHIX = 1683134666; UHAHIX > 0; UHAHIX--) {
        YhPVCdaP = YhPVCdaP;
        nDIvqZfGm = nDIvqZfGm;
        uopqHLNHJvBD = ! YhPVCdaP;
        uopqHLNHJvBD = YhPVCdaP;
        YhPVCdaP = ! YhPVCdaP;
    }

    return string("riWglDxrvpUngVRMHVkGcnQvFsPuxRbwkigEQYDWUUvhycKaMGFYZwKdQvvcUODDEvvfVqSjxioViFuKbFqSTECuoevUBpEBXiHmZVyIEaivcZcbSBFwhLFVcJdSeKHww");
}

double HAQVIpQryDRzrdZP::nxsEwoGS(int KBQIqK, bool SFrQPPDSzO)
{
    double hCaKFLitzYdT = -258629.67705413085;
    bool uVfaoX = false;
    int pKJzFIAoQpgZJN = 1176437337;
    double djSsoYsBBA = 562790.6057783226;
    string vRxDRpjagVWtjC = string("clrhqdEBnTOEzKtvZEoOU");
    bool NbarhJGA = false;
    bool TFPzpUZoPUz = false;
    int ztTqrQXNlALubkr = 288026796;
    int tGirJHTDofppjM = -572244109;
    string lUyqlSgTvVXgK = string("iHvHTCkSlWOpLUqPKfUPHOmQBUFWbcXXtSfvfivdUHSRFRVYbPgaEaLdbaUUTfDskNmqwYfDaVwzkgTVEnqROnMLWdEXGceMnXOCVAavfRssudzHEDZreXljOYvHGhUgq");

    if (uVfaoX == false) {
        for (int TBzYY = 458291607; TBzYY > 0; TBzYY--) {
            continue;
        }
    }

    for (int YQqBycrYqrM = 111055292; YQqBycrYqrM > 0; YQqBycrYqrM--) {
        ztTqrQXNlALubkr *= tGirJHTDofppjM;
        NbarhJGA = ! NbarhJGA;
    }

    return djSsoYsBBA;
}

void HAQVIpQryDRzrdZP::eZTJgHZHaXzEGyl(bool FtUgy, bool FnXiab, int GJgpVjmjoo, double GMWusUssesBYk, string EsbZUQALRT)
{
    int MxqJWkSHhAssmOxy = 459715314;
    int SREkIJNDcks = 84626013;
    int WDQDjlEhL = -897873740;
    string vfUIlvnB = string("LkkGdMtyMEInnNfzMnTNnZdBjOYWffomhsIqNUtGmblYonnFJELGYkcgiNwuUoaxuaMzuDlrPTmnuKKxeTWCMSmoSwiipXmrdMFGuehxWlKbWRWtEURdsWHYTYciCYElKmNcbgbQyyVPzEDbUrrUMPPazMQWKlOYEGWciqKhwndSxkIju");
    bool FAuXSwJXAewOkfC = true;

    for (int GiYrDUABAigx = 1846761360; GiYrDUABAigx > 0; GiYrDUABAigx--) {
        FAuXSwJXAewOkfC = FtUgy;
        EsbZUQALRT = EsbZUQALRT;
    }

    for (int DyHKgsrhEunHV = 794279187; DyHKgsrhEunHV > 0; DyHKgsrhEunHV--) {
        vfUIlvnB = EsbZUQALRT;
    }
}

string HAQVIpQryDRzrdZP::xVOLSC(string MRTTVoEH, bool cZtiCVOJmT, bool VLfvuYJzwmTD, int WDBRPDHXiS, string xjzPsp)
{
    int LTTJRXNpfAX = -141389367;
    int HxFIp = -800820952;

    if (MRTTVoEH == string("CMwuWLYltDDnVPpDidbhvcissDDuPYmFLYvgAUDwkKJZZkkomyACstuChuATRPSpKr")) {
        for (int wKzdVhzOodGnMD = 942908544; wKzdVhzOodGnMD > 0; wKzdVhzOodGnMD--) {
            xjzPsp += MRTTVoEH;
        }
    }

    if (VLfvuYJzwmTD != true) {
        for (int BCIKZX = 537443166; BCIKZX > 0; BCIKZX--) {
            cZtiCVOJmT = VLfvuYJzwmTD;
            LTTJRXNpfAX -= LTTJRXNpfAX;
            LTTJRXNpfAX *= WDBRPDHXiS;
            HxFIp -= HxFIp;
        }
    }

    return xjzPsp;
}

bool HAQVIpQryDRzrdZP::pDyHXwnYWPt(bool LzdkdJAXYhSBkbG)
{
    string BDlfSELg = string("pLVfpPEzChzMypjKxGvOZbpDKTBDxuVPdlXXfuQPTcuJSOWuecRUBRrQwWmoGqXMOCCvISTAtUY");
    string NEMiMaatmH = string("GWAFjxaoXpsflsiruWIwYjALicAhHpMItuo");
    double kvSQcuJqmvLGy = 924246.9094764643;
    string qEiomkSe = string("HOxRvgdtHHthBlPnovZvkhbhIJnfNFzvrHuyiloZSwkhfXAMzCIfJpHOScJROSyqhQXaZeWKCBULOJ");

    for (int Xpfrhww = 55350744; Xpfrhww > 0; Xpfrhww--) {
        qEiomkSe = qEiomkSe;
    }

    return LzdkdJAXYhSBkbG;
}

int HAQVIpQryDRzrdZP::xPdbGDpFzdvDFmE()
{
    double mwSCVorlIGepciYT = 662388.3722156653;
    bool LlBLu = true;
    int FtglJEcJElY = 1678275730;
    bool JBbBUfGpJZfjeOK = true;
    double FeTWKGd = -136493.08159274267;

    for (int BPRaapAvFinQhPE = 1281961457; BPRaapAvFinQhPE > 0; BPRaapAvFinQhPE--) {
        LlBLu = LlBLu;
    }

    if (JBbBUfGpJZfjeOK == true) {
        for (int yUJyKHUeEOv = 1359432115; yUJyKHUeEOv > 0; yUJyKHUeEOv--) {
            LlBLu = LlBLu;
            mwSCVorlIGepciYT -= mwSCVorlIGepciYT;
            FtglJEcJElY *= FtglJEcJElY;
            mwSCVorlIGepciYT += mwSCVorlIGepciYT;
            FeTWKGd /= mwSCVorlIGepciYT;
        }
    }

    if (LlBLu == true) {
        for (int FHyPoFJR = 310691681; FHyPoFJR > 0; FHyPoFJR--) {
            mwSCVorlIGepciYT /= mwSCVorlIGepciYT;
            mwSCVorlIGepciYT *= FeTWKGd;
            JBbBUfGpJZfjeOK = JBbBUfGpJZfjeOK;
            JBbBUfGpJZfjeOK = JBbBUfGpJZfjeOK;
            JBbBUfGpJZfjeOK = ! JBbBUfGpJZfjeOK;
        }
    }

    if (JBbBUfGpJZfjeOK == true) {
        for (int xpPcKxlp = 2066908422; xpPcKxlp > 0; xpPcKxlp--) {
            continue;
        }
    }

    for (int cTnlWhXkc = 840135134; cTnlWhXkc > 0; cTnlWhXkc--) {
        JBbBUfGpJZfjeOK = LlBLu;
        FtglJEcJElY *= FtglJEcJElY;
        LlBLu = LlBLu;
    }

    for (int JbfNaxaZuvL = 1576558063; JbfNaxaZuvL > 0; JbfNaxaZuvL--) {
        LlBLu = LlBLu;
        LlBLu = LlBLu;
        mwSCVorlIGepciYT = mwSCVorlIGepciYT;
    }

    return FtglJEcJElY;
}

int HAQVIpQryDRzrdZP::QhbpNPzmaAuNxll(string fyHcjhGnzcm, double xLJClshRzHw, double UNoUi)
{
    bool HrXbSjcEvOrdf = true;
    bool MJzeWW = true;
    string IbqKzmpBClfr = string("KOGXILmuPaGemoxNUBtordfNHWZSCtmoDCHXqFGwqjcTPEEFkGFJtMoUSuMHnKmlbuETwMobpqVOFyplWKcnaWbZFudfeUqeYoTVOUSTznbQVvyMdFkoimBKlNvQYrFMOlPJGwlnNENVrJvnBYiMVUcNqdJlSExNwKShHSPpxbQncDVLHfzAgpAKTxSiPLmfdeamiROCjRbNIzQLEvoh");
    double XGMcZuzpbkklZn = 551789.0588441737;
    bool xcyIoygqHK = false;
    double VRMedmLOwSPeOeyv = -64089.842145790295;
    double GZLfFGaWCQvNDQ = 696719.3997904968;
    bool bORHySIvaCeQE = true;
    bool qqCtwYC = true;
    int uQyaWLWplcxwawAT = 508534748;

    for (int hxYJPYGVULcpECc = 2075869622; hxYJPYGVULcpECc > 0; hxYJPYGVULcpECc--) {
        VRMedmLOwSPeOeyv -= VRMedmLOwSPeOeyv;
        GZLfFGaWCQvNDQ = xLJClshRzHw;
    }

    for (int kpkILtFDhlXDoiM = 512519481; kpkILtFDhlXDoiM > 0; kpkILtFDhlXDoiM--) {
        UNoUi = VRMedmLOwSPeOeyv;
        GZLfFGaWCQvNDQ /= xLJClshRzHw;
    }

    for (int QhAKRUWaQVPTnjre = 1360098003; QhAKRUWaQVPTnjre > 0; QhAKRUWaQVPTnjre--) {
        xcyIoygqHK = ! qqCtwYC;
    }

    if (HrXbSjcEvOrdf == false) {
        for (int hQJHdCUXhFj = 1018038152; hQJHdCUXhFj > 0; hQJHdCUXhFj--) {
            xLJClshRzHw *= VRMedmLOwSPeOeyv;
        }
    }

    return uQyaWLWplcxwawAT;
}

bool HAQVIpQryDRzrdZP::VCeYCgJ(int wpYvDnFfUE)
{
    bool zKKZtGmo = false;
    int DTQyzdiKtrPh = -2075144426;

    for (int iXFei = 620539488; iXFei > 0; iXFei--) {
        wpYvDnFfUE *= DTQyzdiKtrPh;
    }

    for (int LpCMmJaIib = 1382285144; LpCMmJaIib > 0; LpCMmJaIib--) {
        DTQyzdiKtrPh += DTQyzdiKtrPh;
        DTQyzdiKtrPh -= wpYvDnFfUE;
    }

    for (int wJzAyiMIGxEJiXI = 2046198899; wJzAyiMIGxEJiXI > 0; wJzAyiMIGxEJiXI--) {
        wpYvDnFfUE /= wpYvDnFfUE;
        DTQyzdiKtrPh += DTQyzdiKtrPh;
        DTQyzdiKtrPh = DTQyzdiKtrPh;
        DTQyzdiKtrPh += DTQyzdiKtrPh;
    }

    for (int oGHwJYcBOoqyM = 1374645068; oGHwJYcBOoqyM > 0; oGHwJYcBOoqyM--) {
        DTQyzdiKtrPh += wpYvDnFfUE;
        DTQyzdiKtrPh += DTQyzdiKtrPh;
        wpYvDnFfUE += wpYvDnFfUE;
        wpYvDnFfUE = DTQyzdiKtrPh;
        wpYvDnFfUE *= DTQyzdiKtrPh;
    }

    return zKKZtGmo;
}

int HAQVIpQryDRzrdZP::UfxhEHHriUiU()
{
    int bHubLLKX = -1240350260;
    bool YBUJnyqNg = true;
    string PITwXMYwe = string("epGFYpJasLQXhFtAtvfXmKapXzTOUcBfWskjsWttHjPgINyQJpJxaocZFCcNuyZkZPldQmfmcGm");
    string LBaoUdYTkFrRdq = string("YiUOFLlxFcdgdQtTDwqDfLOwiRgvLcerlRNign");
    double fAITFjY = -553989.2282045449;

    if (PITwXMYwe > string("YiUOFLlxFcdgdQtTDwqDfLOwiRgvLcerlRNign")) {
        for (int sbEOtFPiPG = 1951038257; sbEOtFPiPG > 0; sbEOtFPiPG--) {
            bHubLLKX = bHubLLKX;
            LBaoUdYTkFrRdq += LBaoUdYTkFrRdq;
        }
    }

    for (int FSvfv = 843748072; FSvfv > 0; FSvfv--) {
        LBaoUdYTkFrRdq = LBaoUdYTkFrRdq;
        YBUJnyqNg = ! YBUJnyqNg;
    }

    for (int onqTP = 692154885; onqTP > 0; onqTP--) {
        bHubLLKX = bHubLLKX;
        PITwXMYwe += PITwXMYwe;
        LBaoUdYTkFrRdq += LBaoUdYTkFrRdq;
        PITwXMYwe += PITwXMYwe;
    }

    for (int RZSRKitqimR = 524363453; RZSRKitqimR > 0; RZSRKitqimR--) {
        LBaoUdYTkFrRdq += LBaoUdYTkFrRdq;
        LBaoUdYTkFrRdq += LBaoUdYTkFrRdq;
        PITwXMYwe += PITwXMYwe;
    }

    return bHubLLKX;
}

double HAQVIpQryDRzrdZP::zzsCffjEvSz(int TBNIvCpqEM)
{
    double qIxFaXWi = 444997.24444356863;

    for (int oxOfEJH = 1091797726; oxOfEJH > 0; oxOfEJH--) {
        TBNIvCpqEM += TBNIvCpqEM;
    }

    for (int vzwsgTLSsdVnFBf = 271691054; vzwsgTLSsdVnFBf > 0; vzwsgTLSsdVnFBf--) {
        qIxFaXWi /= qIxFaXWi;
        TBNIvCpqEM *= TBNIvCpqEM;
        TBNIvCpqEM *= TBNIvCpqEM;
        TBNIvCpqEM *= TBNIvCpqEM;
        TBNIvCpqEM -= TBNIvCpqEM;
    }

    if (TBNIvCpqEM >= 1205479193) {
        for (int aVdulrGGV = 2037468518; aVdulrGGV > 0; aVdulrGGV--) {
            TBNIvCpqEM *= TBNIvCpqEM;
            TBNIvCpqEM /= TBNIvCpqEM;
        }
    }

    return qIxFaXWi;
}

int HAQVIpQryDRzrdZP::EVmxjRNjTdzd(string vjEWrPZ, bool GgTErGpeXPyZkd)
{
    bool DTfYvciUMgykJaxD = false;
    string TWXFEcNWAdYMQ = string("EbUTixwuBImKigeebdfmX");

    if (DTfYvciUMgykJaxD != false) {
        for (int GCUGxRY = 1213333723; GCUGxRY > 0; GCUGxRY--) {
            GgTErGpeXPyZkd = GgTErGpeXPyZkd;
        }
    }

    if (vjEWrPZ > string("EbUTixwuBImKigeebdfmX")) {
        for (int tVDRJGIYPYS = 1273911846; tVDRJGIYPYS > 0; tVDRJGIYPYS--) {
            vjEWrPZ += TWXFEcNWAdYMQ;
            TWXFEcNWAdYMQ = vjEWrPZ;
        }
    }

    for (int hVFPcmkr = 1010247801; hVFPcmkr > 0; hVFPcmkr--) {
        GgTErGpeXPyZkd = ! GgTErGpeXPyZkd;
        TWXFEcNWAdYMQ += TWXFEcNWAdYMQ;
        DTfYvciUMgykJaxD = DTfYvciUMgykJaxD;
        TWXFEcNWAdYMQ = TWXFEcNWAdYMQ;
        DTfYvciUMgykJaxD = GgTErGpeXPyZkd;
    }

    for (int MTxkksr = 1253473294; MTxkksr > 0; MTxkksr--) {
        TWXFEcNWAdYMQ += TWXFEcNWAdYMQ;
        DTfYvciUMgykJaxD = ! DTfYvciUMgykJaxD;
        vjEWrPZ += TWXFEcNWAdYMQ;
        TWXFEcNWAdYMQ += TWXFEcNWAdYMQ;
    }

    return -129791863;
}

void HAQVIpQryDRzrdZP::EYPkNPkPxdsh(double ZfYBWRlXEieuR, bool DzQdFhZsdMB)
{
    bool ycShZw = true;
    bool UnOJzZsoKxvsnJF = false;
    bool JZEuWlysE = false;
    bool OYhoWcGO = false;
    int RIixqTfnvUud = 1059397351;
    double uehqcdre = -561968.4337970347;
    string IySwEEzEdREsRtz = string("mboxTLGjF");
    int SsjcVpYsu = -2072864880;
    int erCCzyHiUReXcy = 471466823;

    for (int tIXcWuZXrl = 647958489; tIXcWuZXrl > 0; tIXcWuZXrl--) {
        erCCzyHiUReXcy /= erCCzyHiUReXcy;
        JZEuWlysE = UnOJzZsoKxvsnJF;
        DzQdFhZsdMB = DzQdFhZsdMB;
    }

    for (int CnuoFUItJOvTVY = 673939590; CnuoFUItJOvTVY > 0; CnuoFUItJOvTVY--) {
        continue;
    }

    for (int bMdDKtGJSclJgO = 1546599100; bMdDKtGJSclJgO > 0; bMdDKtGJSclJgO--) {
        UnOJzZsoKxvsnJF = JZEuWlysE;
        ycShZw = ! ycShZw;
        OYhoWcGO = ! ycShZw;
    }
}

bool HAQVIpQryDRzrdZP::joxHNaG(string UqPQMKXSADjNb)
{
    bool nBpEteMZmHydyPkV = false;
    bool LkaGSI = true;
    bool MTVNZRAyoFR = true;

    if (UqPQMKXSADjNb != string("pFizMdnHrTTsLEYHwEwkchZAKFNmPHgQuUwzHeZjSLoASqJbUgwaszQTWjEfF")) {
        for (int iPttI = 175166986; iPttI > 0; iPttI--) {
            UqPQMKXSADjNb += UqPQMKXSADjNb;
            MTVNZRAyoFR = LkaGSI;
            nBpEteMZmHydyPkV = LkaGSI;
            nBpEteMZmHydyPkV = LkaGSI;
            nBpEteMZmHydyPkV = MTVNZRAyoFR;
            MTVNZRAyoFR = ! nBpEteMZmHydyPkV;
            nBpEteMZmHydyPkV = LkaGSI;
            LkaGSI = nBpEteMZmHydyPkV;
        }
    }

    return MTVNZRAyoFR;
}

string HAQVIpQryDRzrdZP::JkOfFLCTpORe(int qexEBaNhYKPDYmFE, int qiwdpgafptyfEUzT, int sKWMKIO)
{
    string DAYSccNLM = string("ZuiCqlLiOtDxBlrpFDwZUGajqlSlQUpXOffURPkTJqygmFsKcoVlBtxSMazmradMHcWypAatTrNGPKWPTczcqRNDHoQfxuBGbYLjntbegJtbLwTqAnccqsHVHZ");

    for (int SoYXamXkM = 319568019; SoYXamXkM > 0; SoYXamXkM--) {
        continue;
    }

    return DAYSccNLM;
}

HAQVIpQryDRzrdZP::HAQVIpQryDRzrdZP()
{
    this->qnmfjKkJzuudWPGc(string("bBnAmEYhKBQughYAwRHKHZbonMGqkvzrolHghwbbqfFQyMoXKqGZQSKHaxBafvkVFvMaCjsCDiFbInIdtDlUTbkzTnZCcULYOVazCJZReWcQVnqLqDcSnbcCxSghJiKwMqcgUteFQRPn"), -67171.90673812038, 371158463);
    this->TazfEkGeKRGbs(593567.8900379547, -1498282573, string("F"), string("AKJAXBqwQBHITBrKCIQTWxGnYMnjiZXeOvRGODDTfpJzdboTcXVrarCqsQalYhfzUnSBsHaFlVDPtMJRvEQCdfhPzlZElxIVoCsJYGSFwJpUrLsSyyqprftNpuTQFqOOmUaFyokknMhXIPrikQnkPFfdacAARcXGusyxWFnWXZuwZzfVQyuGPVESDGwuMRUp"), -1237815874);
    this->qtzysdoDEJ(1737341110, true);
    this->LPYDEKsMjjDRzIG(true);
    this->nxsEwoGS(1781334340, true);
    this->eZTJgHZHaXzEGyl(false, false, -609360143, -177977.5437428922, string("pqjWeIxjntejitkPSeKUtqzToOoFkXNqveNoqsvXbNnNrOoIkGhRdxbAaWHSovUQEtVC"));
    this->xVOLSC(string("IZOnLyQAnlGgBsrsxwewvlsjFrCceoxvTVlP"), true, true, -1517937019, string("CMwuWLYltDDnVPpDidbhvcissDDuPYmFLYvgAUDwkKJZZkkomyACstuChuATRPSpKr"));
    this->pDyHXwnYWPt(false);
    this->xPdbGDpFzdvDFmE();
    this->QhbpNPzmaAuNxll(string("JSlZYSpMkiGdqTCvPHlDFQpZzvRxqUzZJ"), 480217.3247851801, -812019.2289174475);
    this->VCeYCgJ(-1858345987);
    this->UfxhEHHriUiU();
    this->zzsCffjEvSz(1205479193);
    this->EVmxjRNjTdzd(string("uJNshKmnPYDrRAycUhUflaLwmVYGNEQWPVgceqlMXLUCjcTnXCXqspJPsjRLj"), true);
    this->EYPkNPkPxdsh(-628010.4421629172, false);
    this->joxHNaG(string("pFizMdnHrTTsLEYHwEwkchZAKFNmPHgQuUwzHeZjSLoASqJbUgwaszQTWjEfF"));
    this->JkOfFLCTpORe(1757878482, -1366953310, -887398153);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TQTNasfqYVCX
{
public:
    int XOcPLTswLrNVPWTE;
    int LJLhlr;
    bool ClMAFQubfrUjdjm;

    TQTNasfqYVCX();
    double vJVRHuH(bool ZgupZOF, double ffhgghBwYGgKAe, string eOGtkyDVnyxPEM);
    double wzNANZR(bool NhnjIEZxcOlm, bool XBFqZqCCufgwdzI, int wIDBLrbPsbdBR, double upcUBnAqp);
    void AMrqX(bool StGiUDgpNI);
    double MunHzg(bool BdKDOznhTJv, bool JLkDPQuO, double YCRliyySgDbjd, string BsDXrmwMCDSyqM);
    bool gMviWKyMBrjE(int wqRWKTPG, int gLzOFumui, double fZjgHz);
protected:
    bool GrBNLYOYDAfqP;

    void jzpJqfzgbenz(bool bTYzFOaDRfQr, string jpGTBTVUJrinFvaa, string TwMzwda, double dUqjgitrftHWUVL, bool TWlSpGXHlZO);
    double MLIQJvwoQzfge(double QuaXzrKmoKKJviK, string bJqIqo, bool GGcqfpHAFSnyTH, string kTlueanFOrRUFPvz);
    double hAvvJV(double JHPyDJ, double axBNMBoHZ, string eNpbOWxsD);
private:
    bool pQWTDocDoIbyJbp;
    double pDQXVj;

};

double TQTNasfqYVCX::vJVRHuH(bool ZgupZOF, double ffhgghBwYGgKAe, string eOGtkyDVnyxPEM)
{
    double PPJNtSxmCAwtO = -747174.0173920945;
    int ZgAhOXUXXqJ = -957112102;
    int fofyun = -2086755597;
    double ZgyOrxV = 841909.4903157537;
    bool jChVYwG = true;
    string ePNXvYiclcOQRczl = string("YpdJeGuBHANKmnRygqabmplwKaplePMpHrsYlCjUaBoNyrXAgTjWkuidHQGDZrRbycslAmPQaWQhZqiRaOswwVdNGwRdYpkuzIermcIGsDGVoJQGrCVkRRfshgzSFcgpvbPqehVfMxYDJEQEHqlANXaZINKsPrBIkqZFmhlZKNgcGFRcguhzOFxDPuZYcJAfbqpKFAeAec");

    for (int LzDVbiMCbW = 1575945536; LzDVbiMCbW > 0; LzDVbiMCbW--) {
        ZgupZOF = ! jChVYwG;
        ZgupZOF = jChVYwG;
    }

    for (int dOeBiNMwYs = 1472939388; dOeBiNMwYs > 0; dOeBiNMwYs--) {
        fofyun += fofyun;
        ePNXvYiclcOQRczl = eOGtkyDVnyxPEM;
        PPJNtSxmCAwtO -= ffhgghBwYGgKAe;
    }

    return ZgyOrxV;
}

double TQTNasfqYVCX::wzNANZR(bool NhnjIEZxcOlm, bool XBFqZqCCufgwdzI, int wIDBLrbPsbdBR, double upcUBnAqp)
{
    string pLxYe = string("CAGpliKJIfIoKcLOshnEjcKOgZZJjabWEgLUzdyCXBxMKIHARhDWFltqXmvAhjQgZ");
    double rOhqDkgmknQMv = -18500.161988847467;
    double PflCJJTSUSbmQ = 453909.99248578516;
    double amlNUkfoj = -816845.0844240092;

    for (int hIDpSa = 563384939; hIDpSa > 0; hIDpSa--) {
        XBFqZqCCufgwdzI = ! NhnjIEZxcOlm;
        pLxYe = pLxYe;
        rOhqDkgmknQMv += amlNUkfoj;
    }

    if (rOhqDkgmknQMv > 453909.99248578516) {
        for (int FtzhThTpX = 867747074; FtzhThTpX > 0; FtzhThTpX--) {
            continue;
        }
    }

    return amlNUkfoj;
}

void TQTNasfqYVCX::AMrqX(bool StGiUDgpNI)
{
    bool wICudYRmAXZXM = true;

    if (StGiUDgpNI == true) {
        for (int hzfnOrVAtO = 779455110; hzfnOrVAtO > 0; hzfnOrVAtO--) {
            wICudYRmAXZXM = StGiUDgpNI;
            wICudYRmAXZXM = ! StGiUDgpNI;
            StGiUDgpNI = wICudYRmAXZXM;
            wICudYRmAXZXM = ! wICudYRmAXZXM;
            StGiUDgpNI = wICudYRmAXZXM;
            wICudYRmAXZXM = wICudYRmAXZXM;
        }
    }

    if (wICudYRmAXZXM != true) {
        for (int TlJHbPlQSym = 146216109; TlJHbPlQSym > 0; TlJHbPlQSym--) {
            wICudYRmAXZXM = ! wICudYRmAXZXM;
            StGiUDgpNI = wICudYRmAXZXM;
            wICudYRmAXZXM = ! StGiUDgpNI;
            wICudYRmAXZXM = ! wICudYRmAXZXM;
            StGiUDgpNI = StGiUDgpNI;
            StGiUDgpNI = wICudYRmAXZXM;
            wICudYRmAXZXM = StGiUDgpNI;
        }
    }

    if (StGiUDgpNI != true) {
        for (int wXdYlbyG = 1593404343; wXdYlbyG > 0; wXdYlbyG--) {
            wICudYRmAXZXM = StGiUDgpNI;
            wICudYRmAXZXM = ! wICudYRmAXZXM;
            wICudYRmAXZXM = ! wICudYRmAXZXM;
            StGiUDgpNI = wICudYRmAXZXM;
            StGiUDgpNI = StGiUDgpNI;
            StGiUDgpNI = StGiUDgpNI;
            wICudYRmAXZXM = ! StGiUDgpNI;
            wICudYRmAXZXM = StGiUDgpNI;
        }
    }

    if (wICudYRmAXZXM != true) {
        for (int GZhzsaoNXAZ = 1225418005; GZhzsaoNXAZ > 0; GZhzsaoNXAZ--) {
            StGiUDgpNI = wICudYRmAXZXM;
            StGiUDgpNI = wICudYRmAXZXM;
        }
    }
}

double TQTNasfqYVCX::MunHzg(bool BdKDOznhTJv, bool JLkDPQuO, double YCRliyySgDbjd, string BsDXrmwMCDSyqM)
{
    double TbUFMo = -1004146.2611501685;
    double rsxZGOpqvgcOJy = 135089.62251067805;

    if (JLkDPQuO == false) {
        for (int MieEjKupXOdrtDm = 731210251; MieEjKupXOdrtDm > 0; MieEjKupXOdrtDm--) {
            YCRliyySgDbjd += TbUFMo;
        }
    }

    for (int XMVSDkfEzygEiOa = 425898109; XMVSDkfEzygEiOa > 0; XMVSDkfEzygEiOa--) {
        YCRliyySgDbjd /= TbUFMo;
        rsxZGOpqvgcOJy = rsxZGOpqvgcOJy;
        JLkDPQuO = ! JLkDPQuO;
        YCRliyySgDbjd *= YCRliyySgDbjd;
        BsDXrmwMCDSyqM += BsDXrmwMCDSyqM;
    }

    if (JLkDPQuO == true) {
        for (int upQoPrdYKRo = 1863010058; upQoPrdYKRo > 0; upQoPrdYKRo--) {
            JLkDPQuO = ! BdKDOznhTJv;
            BdKDOznhTJv = BdKDOznhTJv;
        }
    }

    return rsxZGOpqvgcOJy;
}

bool TQTNasfqYVCX::gMviWKyMBrjE(int wqRWKTPG, int gLzOFumui, double fZjgHz)
{
    double RnLSgPksdomsGrtI = -526433.365182443;
    string PxLfbLLHMw = string("dLWSTnAIXUHiVklbFnokWdqBzujkeMUaLByDSKKqgXZvYwHwStiSYNXpIxxVZvqpTFMYEoEgAenHVZQgozCCTsgkGgFYIScAXfAAVBoDsEIGGsRcUNPUwxzSpAgMMxCHIFUfiRToHtUcq");
    bool VgOBwJnsekLx = false;
    int RRKTaK = 1697939286;
    double pWWvwfk = 981565.9278310639;
    int KZXSSjZTCfVvZJUq = -2134427055;
    string UwEHF = string("CmoPKXiDYPUeAtppwjwWuIkhBUvdlJpeKryNqTXHyQqJGwmYQzaBDgGSArDIuoWBxjwwQGPzNHQKbJBywTvseYWDaxhxIBrzNBrELpN");

    for (int YbUcwYKcSoTGBS = 1102264954; YbUcwYKcSoTGBS > 0; YbUcwYKcSoTGBS--) {
        KZXSSjZTCfVvZJUq *= RRKTaK;
        fZjgHz -= fZjgHz;
    }

    for (int wsVjfxXJLQGHExDa = 1732972523; wsVjfxXJLQGHExDa > 0; wsVjfxXJLQGHExDa--) {
        continue;
    }

    return VgOBwJnsekLx;
}

void TQTNasfqYVCX::jzpJqfzgbenz(bool bTYzFOaDRfQr, string jpGTBTVUJrinFvaa, string TwMzwda, double dUqjgitrftHWUVL, bool TWlSpGXHlZO)
{
    bool qwWQWmuJclMdju = true;
    double RhygqCUyKJQRiCX = 29520.243402082466;
    double WlSpUbr = -371604.6504211486;
    bool oFnCy = false;
    double FucreTnkcTMnRM = -104195.98493702021;

    for (int Zhsno = 686878780; Zhsno > 0; Zhsno--) {
        TWlSpGXHlZO = ! oFnCy;
    }

    for (int wRINBWQsYW = 1497172227; wRINBWQsYW > 0; wRINBWQsYW--) {
        FucreTnkcTMnRM -= FucreTnkcTMnRM;
        dUqjgitrftHWUVL -= WlSpUbr;
    }
}

double TQTNasfqYVCX::MLIQJvwoQzfge(double QuaXzrKmoKKJviK, string bJqIqo, bool GGcqfpHAFSnyTH, string kTlueanFOrRUFPvz)
{
    int fJrQnwMcqXDtvWC = -1855370508;

    for (int TCiJYgZoqUeDg = 970366658; TCiJYgZoqUeDg > 0; TCiJYgZoqUeDg--) {
        kTlueanFOrRUFPvz += kTlueanFOrRUFPvz;
    }

    return QuaXzrKmoKKJviK;
}

double TQTNasfqYVCX::hAvvJV(double JHPyDJ, double axBNMBoHZ, string eNpbOWxsD)
{
    bool CpcElneIdlyNTM = false;
    string fEWdoyDKq = string("sfrGZdQxPqjercUHkkqOMTUgkHqKEwRrrIDjtvLEJYsAxydavaNUqWZyFkFsNgGoTCLbhqUwQGHdZgojHNhJjwNICFmnVWVHQUrBcofHUVwNbgeKYLjWZmRrlYzoPBVtamztfYQDvxtggRldPxUPCAHOcIWQCLtWLrPkEYXfgjvxTwRBJgJdXbpDhYLMkwQtvvAjEzMbNx");
    string uSOXZpzfiWTlJK = string("NzudFTjqrQIgpwqgvBvTpWJriKTDLJcKRjOsvOPyPLoZAYLonFtku");
    int bhGCPxbwqibk = -1077550921;
    double uhFZrdXzKle = -99980.53818026374;

    for (int dJXTL = 383965177; dJXTL > 0; dJXTL--) {
        continue;
    }

    for (int WemENeFJRO = 1363271340; WemENeFJRO > 0; WemENeFJRO--) {
        uSOXZpzfiWTlJK = uSOXZpzfiWTlJK;
    }

    if (eNpbOWxsD == string("NzudFTjqrQIgpwqgvBvTpWJriKTDLJcKRjOsvOPyPLoZAYLonFtku")) {
        for (int FMDYGSWyysfjmR = 774590551; FMDYGSWyysfjmR > 0; FMDYGSWyysfjmR--) {
            fEWdoyDKq = eNpbOWxsD;
            fEWdoyDKq += uSOXZpzfiWTlJK;
            CpcElneIdlyNTM = ! CpcElneIdlyNTM;
            eNpbOWxsD = eNpbOWxsD;
        }
    }

    for (int CRfEWjijVLknWr = 1278824708; CRfEWjijVLknWr > 0; CRfEWjijVLknWr--) {
        continue;
    }

    return uhFZrdXzKle;
}

TQTNasfqYVCX::TQTNasfqYVCX()
{
    this->vJVRHuH(true, 368654.2338591462, string("PeQWIbNkPpvoPMwpWPXSsDlDpGYVytdnHDuaAladuAbfqmivBFIPYfuemBqpJZXexXQJPLlfacgebncyrKQYuXaZiLKvWGZNCHuLjiKNknznNRnPCNlPIGuhWSNnImMdQVGEVsLhgrOyyICOAAdzQnYnIWiWqHniUExpwPZxLjBocnSBsoCycotZnPXkznUEHQ"));
    this->wzNANZR(true, false, 815277957, -35774.14451372331);
    this->AMrqX(true);
    this->MunHzg(true, false, 851872.0549217287, string("TumuwqdOItvdMRcUxvuBNBnWFwXjJDPdufgIHGsLCpxICLpFzHEAmQuJWYWWKsTpNIDkJRVBBmkjFnEQEOMDJbnyZhpRJjFZdEWY"));
    this->gMviWKyMBrjE(2102829620, -102911845, 963143.431041136);
    this->jzpJqfzgbenz(true, string("mRfpPATSZeQcMpxRJOrNhpzJNyBKxtBpKWNVooUbxrPXjTaQWUBSuzhbaolUqdSFNgFOPkNJKhrOeweMaTlJzdgFyOlAxyzRoubtNDotoSackqZmgeKCgUzvfrIejyHyMDlLgYQOeaLTNTONwxiFhlbTGzUZavxtyhwOKoxvFVYzlrJeOAOnabzlWPUJkDSHxXuVEuDUQEs"), string("uNvEuxKxXpVdYsIdWUbRdeETqPBUePYBkjQmVhgPkvhuAzTrkembvDGVCSujkTWvBvxEDpbOWPvehmSVORjlYsXVliovyDlqjSOrJlMAYZZzOTFbaHQoCQhqmfFagljKaCgCAitfFFbo"), -119728.15495774132, false);
    this->MLIQJvwoQzfge(224787.0791975765, string("jloiNDQlZMvixWDktWKQxThfwtycxbACcjQakQDxPAUiOFZHUzJFAnZXWbvlNsRzssUw"), true, string("kSFvUNAwztsPxhMoAhSgtDmOXdkznyHWqqPkosKwRdBxtFQSnpVejZgpUTyPbAGSZSeuJFJaKbVMCJszgGYrCMMDWfQAyYevztdSrTcVqkrEuZvWqVFFfYtoKJpNFvydlvotzdTUfVqhRUMuEpZqNwksTTaQGXHFROceiB"));
    this->hAvvJV(1041434.3738121053, 947946.9135126736, string("OCqzHiexPFmhyDptIxNWbPvkKpfxLiMqxdfYUmGsSinlFXTjdvZBrQsKvssTbCSqwVhaJIjEJdehYQrSNcawoasmYSTDMIBymtrcbMXWZvlnppKhKfMlPCYNRleBwJmnBEDKgGpaiXuyqzWgPfYlREtmXnPPETWONQKLkisQUKLVeqimDKbXsvlmgDOvKwzLBMi"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tQFeF
{
public:
    double faAcWkSt;
    int RixIysIvDU;
    double ZjeEqAejay;
    double MbacXGNX;

    tQFeF();
    int jojxAUxFt(bool mRPPPp, int zvaBk, string JVmESzR, double iHdOMXQgbTNq, int jJzPnifD);
    void RilCz(int pLKcpbfNNYSl, string TvSagHusRew, bool qRDYoQ, string mzzio, double iFVgDkytWF);
    void fadiPBVx(string qiCUEhHzGyasL, string jBzLnJr, int wjWXNCwezw, int yFHnqGMazsb, double baUhFWfNbxW);
    void dEzdSECSzjkNWy(string ZpYUmzZWEidmyf, bool iBMmGnT, double XLHistQ);
protected:
    int RVNLThOMO;

    void NsFxwwgPHfndk(string tKYijXusTGrO);
    void nKmjYiGujRodae(int lmAAAg, int qtHsU, double HmUEoCIrV, bool gLOWs, bool NtqtFCQS);
    int pCBIjNIuyAi(bool fxodaUrvOALbQ, double RaYOECSn, string zRIoL, int aHsRpLvJFA, bool iJARBd);
    int hAwDDa();
    bool lCXRHJHnKBddqAP(double ZWhranal, bool QwIhplPwUThJGCZf);
    int bafUjPWjt(bool FDQHUQE, double PGUfxgjKkSqIux);
    void tfhvyUyGiGbZwu();
private:
    int DZVLlRnArZtxH;
    double bbPFG;
    int pIyfbsUTPalnp;
    double osMwRwloIH;
    int LgTZQuJjXpTUqT;
    int xuIUbrJkVDp;

    void rGKUCgWNlBdj(double PbGZAmJyiisq, double lXsxdYnlzjqb);
    void sXFABaGvOMVMlA();
};

int tQFeF::jojxAUxFt(bool mRPPPp, int zvaBk, string JVmESzR, double iHdOMXQgbTNq, int jJzPnifD)
{
    double sHJjoTERIIcB = 675741.7778911293;
    int kqtxhD = 1802457031;
    int FssKwDBkJ = -1749687749;
    int BFgqMeNSrkrQyzj = 426219835;

    if (mRPPPp != false) {
        for (int PBwPoxWGcXW = 523536751; PBwPoxWGcXW > 0; PBwPoxWGcXW--) {
            zvaBk = FssKwDBkJ;
        }
    }

    if (jJzPnifD != 1802457031) {
        for (int opcJUPjYpBSAuaT = 2120797282; opcJUPjYpBSAuaT > 0; opcJUPjYpBSAuaT--) {
            BFgqMeNSrkrQyzj /= jJzPnifD;
            iHdOMXQgbTNq = iHdOMXQgbTNq;
        }
    }

    for (int hCuEuEeHhhhAdX = 582173614; hCuEuEeHhhhAdX > 0; hCuEuEeHhhhAdX--) {
        kqtxhD += jJzPnifD;
    }

    if (mRPPPp == false) {
        for (int JvZcKq = 1704436372; JvZcKq > 0; JvZcKq--) {
            iHdOMXQgbTNq += sHJjoTERIIcB;
            FssKwDBkJ = FssKwDBkJ;
        }
    }

    return BFgqMeNSrkrQyzj;
}

void tQFeF::RilCz(int pLKcpbfNNYSl, string TvSagHusRew, bool qRDYoQ, string mzzio, double iFVgDkytWF)
{
    bool odfLMbUCeJbz = false;
    bool ghwecnnOAluq = false;

    if (TvSagHusRew <= string("PVFEEYalfyuSDbPOOTnBelmpfnEONsaStlsdQLiVLGRIPiMXEJjHRlDRNAbXQhhfVQPOsUHeRLiVxwOdsdZUliEcDhmjMoUdEPVXaYIhnZQqhTIuKlpIjaUxnMKASvvsafy")) {
        for (int UbRauhCaQgO = 643784428; UbRauhCaQgO > 0; UbRauhCaQgO--) {
            ghwecnnOAluq = odfLMbUCeJbz;
        }
    }

    if (ghwecnnOAluq == false) {
        for (int kVfbWykswUbhkNJq = 656731410; kVfbWykswUbhkNJq > 0; kVfbWykswUbhkNJq--) {
            continue;
        }
    }

    if (ghwecnnOAluq == false) {
        for (int DNOXWFu = 460008698; DNOXWFu > 0; DNOXWFu--) {
            ghwecnnOAluq = ! odfLMbUCeJbz;
        }
    }
}

void tQFeF::fadiPBVx(string qiCUEhHzGyasL, string jBzLnJr, int wjWXNCwezw, int yFHnqGMazsb, double baUhFWfNbxW)
{
    bool ayrbWIwQwjgd = true;
    string ulBEjiYfNgSRMcq = string("VwONQRQPPGjKvJRGKYOHGsOFkiKZgQUpwDGbwWYzmgneGyeAZplkeAIseGXqvHeEUacXxWgszElEXLgHTWEbayuVOfXdzlRHdeilPdutspEdHviJbTSIxLGvureOPMKsNLlJyhfEvfhlK");
    bool UuOrQHhkv = false;
    bool ydtjgqBcMcD = true;
    string dNFYoAfeUr = string("GRdmgMWDmaSKeoTkRuqGESsksWXMYzBwwfhFdOKvNTDiJMHaMDPXRkPbajJRHHuhPgHAhAowOrHQRl");
    double KRyMpMHDFLVupKrE = -407126.6021775727;
    double exJuaREkDzJCVB = 285344.45483861986;

    for (int djvtuoD = 675735956; djvtuoD > 0; djvtuoD--) {
        ulBEjiYfNgSRMcq = ulBEjiYfNgSRMcq;
    }

    for (int LPeyKvFZYYFV = 1328792709; LPeyKvFZYYFV > 0; LPeyKvFZYYFV--) {
        jBzLnJr += jBzLnJr;
    }

    for (int Mnxbv = 933236061; Mnxbv > 0; Mnxbv--) {
        qiCUEhHzGyasL = jBzLnJr;
        baUhFWfNbxW *= KRyMpMHDFLVupKrE;
        qiCUEhHzGyasL += ulBEjiYfNgSRMcq;
    }
}

void tQFeF::dEzdSECSzjkNWy(string ZpYUmzZWEidmyf, bool iBMmGnT, double XLHistQ)
{
    int HJEztuHovvpXhYBR = -996752784;

    if (XLHistQ != 266964.1289416177) {
        for (int ZKYNc = 1197796441; ZKYNc > 0; ZKYNc--) {
            ZpYUmzZWEidmyf += ZpYUmzZWEidmyf;
        }
    }

    for (int VwZXV = 2065349082; VwZXV > 0; VwZXV--) {
        XLHistQ *= XLHistQ;
        HJEztuHovvpXhYBR = HJEztuHovvpXhYBR;
        HJEztuHovvpXhYBR -= HJEztuHovvpXhYBR;
    }
}

void tQFeF::NsFxwwgPHfndk(string tKYijXusTGrO)
{
    bool AGhygqH = false;
    bool gYBDruYgYSiEZadl = false;
    bool dlUvdTtzPYczdY = true;
    bool lLFvjX = true;
    double SauxIjkFBTUzK = 392152.33809022175;
    bool DscOYToAaHgdj = true;

    for (int BBPKRfYQjVBf = 1334953534; BBPKRfYQjVBf > 0; BBPKRfYQjVBf--) {
        DscOYToAaHgdj = ! gYBDruYgYSiEZadl;
        DscOYToAaHgdj = AGhygqH;
        dlUvdTtzPYczdY = lLFvjX;
        gYBDruYgYSiEZadl = ! lLFvjX;
    }

    for (int PIAYOyNxyOAZMZe = 35189793; PIAYOyNxyOAZMZe > 0; PIAYOyNxyOAZMZe--) {
        continue;
    }
}

void tQFeF::nKmjYiGujRodae(int lmAAAg, int qtHsU, double HmUEoCIrV, bool gLOWs, bool NtqtFCQS)
{
    int zUQYLbnLUb = -55305182;
    string bmvhfmx = string("jeHfauxwtFnAnngxpngSaRgJHEURlXwzJuOYy");
    bool foVJlKREosic = false;

    for (int zbNZEtGSPMpe = 416004427; zbNZEtGSPMpe > 0; zbNZEtGSPMpe--) {
        foVJlKREosic = NtqtFCQS;
        zUQYLbnLUb *= zUQYLbnLUb;
        gLOWs = NtqtFCQS;
        zUQYLbnLUb = lmAAAg;
    }

    if (NtqtFCQS == true) {
        for (int WRNtXumAlrEq = 185467626; WRNtXumAlrEq > 0; WRNtXumAlrEq--) {
            continue;
        }
    }

    if (foVJlKREosic != true) {
        for (int nDnVshcBieEhi = 1044208917; nDnVshcBieEhi > 0; nDnVshcBieEhi--) {
            qtHsU = lmAAAg;
            qtHsU -= qtHsU;
        }
    }
}

int tQFeF::pCBIjNIuyAi(bool fxodaUrvOALbQ, double RaYOECSn, string zRIoL, int aHsRpLvJFA, bool iJARBd)
{
    string jNpNa = string("CfUFdBqpdDuiwqXSbKFTMiRsDimI");
    double arztNnqaKdPbZMyi = 904402.1937147591;
    int HzkaWj = -1765764636;
    double ZgkCDclDhzSWk = 928254.7362781405;
    double YsscE = 859560.7780280976;
    double xivRnIbSPTjP = 940630.5084389031;
    double XUQUW = -977576.6992280983;

    for (int nHWVlIKE = 432774536; nHWVlIKE > 0; nHWVlIKE--) {
        YsscE /= ZgkCDclDhzSWk;
        HzkaWj *= HzkaWj;
    }

    for (int oiHJk = 331937615; oiHJk > 0; oiHJk--) {
        RaYOECSn /= XUQUW;
    }

    for (int sHFtVNDGSO = 666277647; sHFtVNDGSO > 0; sHFtVNDGSO--) {
        HzkaWj += HzkaWj;
        ZgkCDclDhzSWk = XUQUW;
        ZgkCDclDhzSWk *= RaYOECSn;
    }

    for (int MhSWBdAVZgPeY = 157390843; MhSWBdAVZgPeY > 0; MhSWBdAVZgPeY--) {
        zRIoL = zRIoL;
    }

    return HzkaWj;
}

int tQFeF::hAwDDa()
{
    int blMFsL = -720702373;
    int IpkzYllej = -2075678951;
    bool lbWdFMBwEA = false;

    for (int xsVWqSSBEMuIDxwh = 1808276830; xsVWqSSBEMuIDxwh > 0; xsVWqSSBEMuIDxwh--) {
        IpkzYllej *= IpkzYllej;
        lbWdFMBwEA = lbWdFMBwEA;
        blMFsL *= IpkzYllej;
    }

    for (int UkkUuGsbOrM = 923826058; UkkUuGsbOrM > 0; UkkUuGsbOrM--) {
        IpkzYllej -= IpkzYllej;
    }

    for (int NNdfkVbufArv = 426064436; NNdfkVbufArv > 0; NNdfkVbufArv--) {
        blMFsL /= blMFsL;
        IpkzYllej -= blMFsL;
        blMFsL = IpkzYllej;
        blMFsL /= IpkzYllej;
    }

    if (IpkzYllej >= -2075678951) {
        for (int nVLnhbX = 1135555549; nVLnhbX > 0; nVLnhbX--) {
            blMFsL *= IpkzYllej;
            blMFsL += IpkzYllej;
            IpkzYllej *= blMFsL;
        }
    }

    if (lbWdFMBwEA == false) {
        for (int CPEDkiFCzh = 1224793903; CPEDkiFCzh > 0; CPEDkiFCzh--) {
            continue;
        }
    }

    for (int txcStzzwmuU = 684400212; txcStzzwmuU > 0; txcStzzwmuU--) {
        IpkzYllej /= blMFsL;
        IpkzYllej = blMFsL;
    }

    return IpkzYllej;
}

bool tQFeF::lCXRHJHnKBddqAP(double ZWhranal, bool QwIhplPwUThJGCZf)
{
    int YEvpjB = 473918941;
    int MVXSjUQPr = -210653477;
    int pXuXEWFUYYXZaWv = -1453876145;
    int RkJWB = 1935308137;
    double axIhld = 368435.6057567706;
    int jKGUvEJz = -314413626;

    for (int cRMBmyQ = 1878776013; cRMBmyQ > 0; cRMBmyQ--) {
        pXuXEWFUYYXZaWv -= YEvpjB;
        jKGUvEJz -= jKGUvEJz;
        RkJWB *= MVXSjUQPr;
    }

    for (int mUyzQDrkjHOZSe = 1709285665; mUyzQDrkjHOZSe > 0; mUyzQDrkjHOZSe--) {
        pXuXEWFUYYXZaWv += pXuXEWFUYYXZaWv;
        RkJWB += MVXSjUQPr;
        YEvpjB /= jKGUvEJz;
        pXuXEWFUYYXZaWv *= pXuXEWFUYYXZaWv;
        ZWhranal -= ZWhranal;
    }

    for (int UiLxUHIVYoQodiqW = 1274691341; UiLxUHIVYoQodiqW > 0; UiLxUHIVYoQodiqW--) {
        YEvpjB -= YEvpjB;
        RkJWB += jKGUvEJz;
        jKGUvEJz /= MVXSjUQPr;
    }

    if (pXuXEWFUYYXZaWv != 473918941) {
        for (int qHJOAoZeURnz = 1317906318; qHJOAoZeURnz > 0; qHJOAoZeURnz--) {
            RkJWB *= jKGUvEJz;
        }
    }

    for (int iKvDJOUyWSHXqZug = 1377289210; iKvDJOUyWSHXqZug > 0; iKvDJOUyWSHXqZug--) {
        RkJWB = pXuXEWFUYYXZaWv;
    }

    return QwIhplPwUThJGCZf;
}

int tQFeF::bafUjPWjt(bool FDQHUQE, double PGUfxgjKkSqIux)
{
    int usoxsjoUXhEA = -1140235651;
    double QBTsJW = -32370.683080465362;
    bool ylXdOutvmN = true;
    double gifCiP = 744213.4956043886;
    double RDxHipaRbJnsRN = -517608.7794388811;
    int NEoMZZZJEnG = -937233410;
    double AHECXGIRDd = 224349.42497171392;
    bool froaEsYLyB = false;

    return NEoMZZZJEnG;
}

void tQFeF::tfhvyUyGiGbZwu()
{
    int ZsnZdYJyCOdvNHcM = -522922645;
    string PxrTgD = string("QaNoRAHztORGniqFZIQKqatynMOkLXLTWzPqNkYIIiHgKwVLwcMPZoVCQNJcltakyh");
    double spAXfWcupGMKks = -267454.4584799513;
}

void tQFeF::rGKUCgWNlBdj(double PbGZAmJyiisq, double lXsxdYnlzjqb)
{
    string kBNTivs = string("FdEmAj");
    double wGvXStkUzZ = 808405.8311552802;

    for (int zwDopaxYGcvBitc = 1075678425; zwDopaxYGcvBitc > 0; zwDopaxYGcvBitc--) {
        wGvXStkUzZ -= PbGZAmJyiisq;
    }

    if (PbGZAmJyiisq != 353968.7588046802) {
        for (int RpkfBeYRWx = 1277364779; RpkfBeYRWx > 0; RpkfBeYRWx--) {
            lXsxdYnlzjqb /= wGvXStkUzZ;
            PbGZAmJyiisq = lXsxdYnlzjqb;
            PbGZAmJyiisq /= lXsxdYnlzjqb;
        }
    }

    for (int sQBOH = 1150361366; sQBOH > 0; sQBOH--) {
        lXsxdYnlzjqb *= lXsxdYnlzjqb;
        wGvXStkUzZ = lXsxdYnlzjqb;
        lXsxdYnlzjqb -= lXsxdYnlzjqb;
        PbGZAmJyiisq *= wGvXStkUzZ;
        wGvXStkUzZ = lXsxdYnlzjqb;
    }

    for (int acZdRlN = 175967538; acZdRlN > 0; acZdRlN--) {
        continue;
    }

    if (wGvXStkUzZ > 808405.8311552802) {
        for (int kKnCvLvmWlplVR = 1508902356; kKnCvLvmWlplVR > 0; kKnCvLvmWlplVR--) {
            wGvXStkUzZ = wGvXStkUzZ;
            wGvXStkUzZ -= lXsxdYnlzjqb;
            lXsxdYnlzjqb += wGvXStkUzZ;
            wGvXStkUzZ /= PbGZAmJyiisq;
            lXsxdYnlzjqb += lXsxdYnlzjqb;
            PbGZAmJyiisq += PbGZAmJyiisq;
            wGvXStkUzZ -= PbGZAmJyiisq;
            lXsxdYnlzjqb = wGvXStkUzZ;
        }
    }

    for (int rHPDNieJK = 1381268891; rHPDNieJK > 0; rHPDNieJK--) {
        lXsxdYnlzjqb += lXsxdYnlzjqb;
    }
}

void tQFeF::sXFABaGvOMVMlA()
{
    int GnABdCPhF = 1180982753;
    int zYYLPIEKwJicV = -607229547;
    double THzXODlmOqtF = -252629.4374273645;
    int SoehIrppuIsdLX = -894687260;
    int ZjvHh = 1114457338;

    if (ZjvHh >= 1114457338) {
        for (int qGaglObNHGeuUBNI = 1862749111; qGaglObNHGeuUBNI > 0; qGaglObNHGeuUBNI--) {
            ZjvHh -= ZjvHh;
            SoehIrppuIsdLX += zYYLPIEKwJicV;
            THzXODlmOqtF = THzXODlmOqtF;
            ZjvHh /= SoehIrppuIsdLX;
            zYYLPIEKwJicV /= ZjvHh;
        }
    }

    if (SoehIrppuIsdLX == -607229547) {
        for (int UZxYxS = 922694586; UZxYxS > 0; UZxYxS--) {
            zYYLPIEKwJicV = zYYLPIEKwJicV;
            ZjvHh *= zYYLPIEKwJicV;
            GnABdCPhF += SoehIrppuIsdLX;
            ZjvHh += SoehIrppuIsdLX;
        }
    }

    if (GnABdCPhF != 1114457338) {
        for (int nRWwYZx = 455162264; nRWwYZx > 0; nRWwYZx--) {
            continue;
        }
    }

    if (SoehIrppuIsdLX < 1180982753) {
        for (int hTWkrNevSQTIO = 1493960426; hTWkrNevSQTIO > 0; hTWkrNevSQTIO--) {
            zYYLPIEKwJicV = SoehIrppuIsdLX;
            ZjvHh = zYYLPIEKwJicV;
            GnABdCPhF += SoehIrppuIsdLX;
        }
    }

    for (int IOqOveQEGLtmvY = 138466175; IOqOveQEGLtmvY > 0; IOqOveQEGLtmvY--) {
        GnABdCPhF *= ZjvHh;
        ZjvHh = GnABdCPhF;
        SoehIrppuIsdLX = zYYLPIEKwJicV;
        ZjvHh -= SoehIrppuIsdLX;
    }
}

tQFeF::tQFeF()
{
    this->jojxAUxFt(false, 281751254, string("QLtiAINytKEtIZsHoUdoBxJLSxDyyMGDmMrjxjBqxsaQwFqEtadbGXrSrjImQcNPtqYEahFvWxBghnihApKxNkjvOCijlVAfPyuucDSbtMcoojnTPFtJrPBugWsBlSdnHXjTEMVIm"), -653158.2140411296, -1325784906);
    this->RilCz(1541822899, string("JDhfrlPsZYTxpsCpUkUPJMkXCoMAERYczKhYRyRYumWayhfDUdTBIsNVQLrpWDCbTwZCsXQso"), false, string("PVFEEYalfyuSDbPOOTnBelmpfnEONsaStlsdQLiVLGRIPiMXEJjHRlDRNAbXQhhfVQPOsUHeRLiVxwOdsdZUliEcDhmjMoUdEPVXaYIhnZQqhTIuKlpIjaUxnMKASvvsafy"), 564068.5587190076);
    this->fadiPBVx(string("JGfbFqdZlvsfbPdHngSFzLTkfHZUSRpFXekHOskhkCfhDDmsVjOHPMTfWLzRPKyWumuMXLhHVZ"), string("VrnJCLXnUceMOiakKRZkmfgGTRfhdlkzOlwmjsodNnqGdojwsDMlWOOAsbrXCASxPmCMB"), -304712886, 151431929, -964423.6527031575);
    this->dEzdSECSzjkNWy(string("ojrUOcAiPXhEEtWIVdPgjcdrITJHMLIZUoPwhpehcWUjjeLBPvSqfQYTaJGxuIJatAFJPHtHLhPjAFfpbDEyEfqYJtLvNBhdTMcLRsuzJseYBgRcEjWQyYyryYsjeOqhDicbUyolsARZyYierYtjoseyPATJvMZcptEXofTQpgF"), false, 266964.1289416177);
    this->NsFxwwgPHfndk(string("uTeimVaaQhfkkoqphHMCEryHhHnczkgINGDhAyPDveueHFDBMbPBmhxbrXNYkSeUyZkEEcwlLdxhgoEbvsXzVvfVXljfQCxeIzhYOSUgdaGxdYExXPqLlokGAgztyIBWBaafNDEpnvWVGXLCmNnxTTWmWWGjHpVfdnPYtlPKjvpzbcAGYgBAfFYPKMoQuSmZuk"));
    this->nKmjYiGujRodae(292852189, -1755089863, -980102.3011766045, true, false);
    this->pCBIjNIuyAi(false, 302158.89493429847, string("uqCHlcRFzZJkJrCccVMxOYfofQysmDJPjaVLaqNIkkzeYbzUpvKmjxlMLnqHPjWzbFooBvJfknaVQteNYoOoOsFNwUjMqiwwpLhEKyFZwLfjObLQOooyrzWwncrTcVudyOGAjnlbXeuSuUzrjLWEYwWykUewAtKgCrzOdsLJxbypmTsxiDMtVGXFCkNIYfoioybJcUhaFBVltytHnKvHBVKDjceBKaqvFMZHf"), -1586072817, false);
    this->hAwDDa();
    this->lCXRHJHnKBddqAP(-399684.01748384227, false);
    this->bafUjPWjt(true, 593349.7545651979);
    this->tfhvyUyGiGbZwu();
    this->rGKUCgWNlBdj(-261625.45447341303, 353968.7588046802);
    this->sXFABaGvOMVMlA();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KVWsorRoJv
{
public:
    string cYIRpEHwRAmtslK;
    int FalQtqERoHsskhw;
    bool IFeqwgsWz;
    string ZmrFWTyOajsy;

    KVWsorRoJv();
    double YJNflQAcsFmsEyQ(string Yhnrp);
    double OkNhB(int TutHtAzjkEDMdN);
    bool nYqnXWi(double fOjTPMytZQcqJv, bool CzYicvi, bool NjLGIIcFrgCr, bool mwkabZkiYa, bool hXwsO);
    double RNvlHifhCVkNghHn(bool ylVwzgIyYToiYnRV, string GgMCdvBF, string VBroVE);
    bool NycFmRpkTAcqW(string NdTQzVNouMzx, bool JwCcrjeOE, string BZshoxSdsC, string vfekPVNGAZSbUJO, int IbHnWrRHh);
    string VsbLRgpnx(int cGhcuLqq, int zmDcWGSGRQhM, double OjodtOyiilDzLRf, int hDqoxGVjUX, string agDbEEqokug);
protected:
    string CPnBzZGqAsFcl;
    int ENwwJQJ;
    double EdgaQqsRO;
    string aZvOhryseWIWS;
    string ldKjikJgT;

    bool zrwMBMlIAjQBKDo();
    int rxiOJ();
private:
    double CzoCeCa;
    int QkVuWaDkKRTvAxQ;
    int RcYPd;
    bool nHJCwLIqBSr;

    string TjXuua(int vfhWSv, double oHlZaXXoIqFxL, int IkGfaEqHrIIV, string wuykYGTtrnfPeFfk, double NgVpVHyIm);
    double SeZmO(double XPTjLmSIeZUfz, double VdOEayDDAjAFF, double zLvsvIEyzNBIC);
};

double KVWsorRoJv::YJNflQAcsFmsEyQ(string Yhnrp)
{
    double IxRqUQd = 849052.837919053;
    int TqGdUEjhak = -843827463;
    string osPBFfhis = string("lSCwQBVqKvVLJyynKFqmiXyogjiXzqKwzFxpwYqUoBgqqjkKXpwbIUXkrriSXfpFLIdHezTKfiWRQKcYNAN");
    int ngdjHwUCNvyVp = 1128136915;
    int aTlbhYUstHHxkQ = -1395131803;

    for (int vVLMtONv = 266521238; vVLMtONv > 0; vVLMtONv--) {
        osPBFfhis = osPBFfhis;
        TqGdUEjhak += TqGdUEjhak;
        osPBFfhis = Yhnrp;
    }

    if (ngdjHwUCNvyVp >= -843827463) {
        for (int QnNeLsd = 98711979; QnNeLsd > 0; QnNeLsd--) {
            TqGdUEjhak += ngdjHwUCNvyVp;
            aTlbhYUstHHxkQ -= aTlbhYUstHHxkQ;
        }
    }

    return IxRqUQd;
}

double KVWsorRoJv::OkNhB(int TutHtAzjkEDMdN)
{
    bool OfhRStEa = false;
    string gRpIQvrAw = string("lFlbOgTEgEEOKicRdrrXdToQkAPFuxKDoKsNGaPJBQpUnabBMnfEcGCwjZJgZmXkkNXyyWwkIGFwqHAtMUFSQhvgonBboVcMboDfGuoHrzytETBsJWmKcZXNZvoreG");
    bool zlhrNKsYL = true;
    bool BWYCjuqkbXN = true;
    string Fsjoqwt = string("mEjsHoymYEZtgGidDSQkOSJEQwCXAmDaLpRquRKkZmbVgtnzwvkTuUrfyJBKPHWNvcHxdosIECviaZdcVukUjhfgIbJeeHJWQIUSyGcZYASmwiSKbcdCNdaDurFGQStVn");
    string CaFHPyJmRJBqHQrn = string("oTBIwytvfpEPZcSqiPugxjxHydXUHvrFWknnTcEHfiSgqwIwiXSKPLfUaHwDHYbBYNjbsFspVGChBSirjPwzoaxdhh");
    double HQxjmj = -230009.41058932457;
    string HgUbCjlEObVlbQw = string("FlNZOGMBIjDgDxDwKXxalVLb");

    for (int RamiwQnbvJHeZ = 2109013338; RamiwQnbvJHeZ > 0; RamiwQnbvJHeZ--) {
        TutHtAzjkEDMdN *= TutHtAzjkEDMdN;
        HgUbCjlEObVlbQw = gRpIQvrAw;
    }

    for (int PqpzK = 1851380285; PqpzK > 0; PqpzK--) {
        continue;
    }

    for (int TpYCCGbdko = 1284695085; TpYCCGbdko > 0; TpYCCGbdko--) {
        Fsjoqwt += Fsjoqwt;
        CaFHPyJmRJBqHQrn += HgUbCjlEObVlbQw;
    }

    for (int SHuCthWMXsKsr = 1940776402; SHuCthWMXsKsr > 0; SHuCthWMXsKsr--) {
        CaFHPyJmRJBqHQrn += Fsjoqwt;
        zlhrNKsYL = ! zlhrNKsYL;
        zlhrNKsYL = OfhRStEa;
        gRpIQvrAw += HgUbCjlEObVlbQw;
        CaFHPyJmRJBqHQrn = HgUbCjlEObVlbQw;
    }

    if (HgUbCjlEObVlbQw != string("FlNZOGMBIjDgDxDwKXxalVLb")) {
        for (int BDdfQnqbIZsx = 1703585321; BDdfQnqbIZsx > 0; BDdfQnqbIZsx--) {
            HgUbCjlEObVlbQw += CaFHPyJmRJBqHQrn;
            OfhRStEa = zlhrNKsYL;
            zlhrNKsYL = ! zlhrNKsYL;
            gRpIQvrAw = Fsjoqwt;
        }
    }

    return HQxjmj;
}

bool KVWsorRoJv::nYqnXWi(double fOjTPMytZQcqJv, bool CzYicvi, bool NjLGIIcFrgCr, bool mwkabZkiYa, bool hXwsO)
{
    bool UwRckRljLMT = true;
    string iiytmRzHBTSHjiA = string("pxhUmMDbKwgRDYyQOfLLQPrIuuRIrlXmaKIYKYTiljinafuQqIXCoTYocXjwSjkZDlbHbTtHPJxzhGUtswZYfiTwuDZSnIdlZmJhkjsRbdeMhlIkwmDKmsErCsUyNtitwZGcjYFodFrckBYiKXXE");
    double tWCMiGPuce = 252818.09399082972;

    for (int ayfUtU = 1636623121; ayfUtU > 0; ayfUtU--) {
        mwkabZkiYa = mwkabZkiYa;
    }

    if (tWCMiGPuce >= 252818.09399082972) {
        for (int ojTPPM = 1761975643; ojTPPM > 0; ojTPPM--) {
            CzYicvi = UwRckRljLMT;
            NjLGIIcFrgCr = ! mwkabZkiYa;
            CzYicvi = mwkabZkiYa;
        }
    }

    if (UwRckRljLMT == false) {
        for (int DNrkU = 1478749588; DNrkU > 0; DNrkU--) {
            hXwsO = ! mwkabZkiYa;
            fOjTPMytZQcqJv *= tWCMiGPuce;
        }
    }

    if (fOjTPMytZQcqJv <= -637455.0544858949) {
        for (int EVjhUG = 1679037224; EVjhUG > 0; EVjhUG--) {
            NjLGIIcFrgCr = ! mwkabZkiYa;
        }
    }

    return UwRckRljLMT;
}

double KVWsorRoJv::RNvlHifhCVkNghHn(bool ylVwzgIyYToiYnRV, string GgMCdvBF, string VBroVE)
{
    double mUDyTHPsnRKK = -447219.9414450237;
    string KUPLOcfeFcPFA = string("hxPhvRrSyrbueRmltGdJWlSXFgFGDGKAllONZZaocZAZqupWuKpioqavpvV");

    for (int kxKNnkXxfXdh = 1224306636; kxKNnkXxfXdh > 0; kxKNnkXxfXdh--) {
        VBroVE = KUPLOcfeFcPFA;
        ylVwzgIyYToiYnRV = ylVwzgIyYToiYnRV;
        GgMCdvBF = GgMCdvBF;
        KUPLOcfeFcPFA += GgMCdvBF;
    }

    if (VBroVE != string("OxlCbJqghCzpFytGeoOqljXmErkHuQbRqTybnUMYQFzEMtUYyjNADUrKjAoMPnblEgAAYWJqmCSIwuLAouFNiGzScgaaCKqvQtMYGikOmzZGXTgZGsdwUUEKNzTTRbxcINAgLzfBlommrVVvmNvzHQdKOHqtOOJjXuijJMyNWsKtCuquNUSGpfctLGlRXh")) {
        for (int nkBkkEaGImxIxv = 1791224504; nkBkkEaGImxIxv > 0; nkBkkEaGImxIxv--) {
            VBroVE += VBroVE;
            GgMCdvBF = GgMCdvBF;
            KUPLOcfeFcPFA += VBroVE;
        }
    }

    for (int iRjNVPWfqVglrRN = 763602150; iRjNVPWfqVglrRN > 0; iRjNVPWfqVglrRN--) {
        VBroVE = KUPLOcfeFcPFA;
        ylVwzgIyYToiYnRV = ! ylVwzgIyYToiYnRV;
        GgMCdvBF = VBroVE;
        KUPLOcfeFcPFA += VBroVE;
        GgMCdvBF += KUPLOcfeFcPFA;
        GgMCdvBF += VBroVE;
        GgMCdvBF = GgMCdvBF;
        VBroVE += VBroVE;
    }

    for (int ACdZEX = 294443013; ACdZEX > 0; ACdZEX--) {
        mUDyTHPsnRKK *= mUDyTHPsnRKK;
        VBroVE += KUPLOcfeFcPFA;
        KUPLOcfeFcPFA = GgMCdvBF;
        ylVwzgIyYToiYnRV = ylVwzgIyYToiYnRV;
    }

    return mUDyTHPsnRKK;
}

bool KVWsorRoJv::NycFmRpkTAcqW(string NdTQzVNouMzx, bool JwCcrjeOE, string BZshoxSdsC, string vfekPVNGAZSbUJO, int IbHnWrRHh)
{
    bool xjLBazMun = true;

    for (int uWXInQ = 425692367; uWXInQ > 0; uWXInQ--) {
        BZshoxSdsC = NdTQzVNouMzx;
        vfekPVNGAZSbUJO += BZshoxSdsC;
        vfekPVNGAZSbUJO = NdTQzVNouMzx;
        xjLBazMun = xjLBazMun;
    }

    if (vfekPVNGAZSbUJO > string("rxwTTIcposeWHKJKtoycxPOgGUxCxUqSUNSCZoRLgMqdrGTCDoexlIefNvehvxTOqRDwTuUOaGalKjarkvOZbtkLtBcDtykDVnOLoOkIJtUTZKmjOaBtqrphxbNGuEWKCvkiyfVtnKRxEEWkEcLphZzXfILAMmehSYqcSZNRqQDCviqrPoeUydTZufpKSPEqDNRpcIpSWRdLAobRwFSYlPYsEMyupiCemBmpRQBHxTmcqeaHi")) {
        for (int OcCvQpNSUknnRtj = 32357612; OcCvQpNSUknnRtj > 0; OcCvQpNSUknnRtj--) {
            vfekPVNGAZSbUJO += NdTQzVNouMzx;
            JwCcrjeOE = ! JwCcrjeOE;
            xjLBazMun = JwCcrjeOE;
            BZshoxSdsC += vfekPVNGAZSbUJO;
            JwCcrjeOE = xjLBazMun;
        }
    }

    return xjLBazMun;
}

string KVWsorRoJv::VsbLRgpnx(int cGhcuLqq, int zmDcWGSGRQhM, double OjodtOyiilDzLRf, int hDqoxGVjUX, string agDbEEqokug)
{
    double kmFBzinGBvI = -370837.1557046438;

    if (kmFBzinGBvI < -370837.1557046438) {
        for (int BVXPSLKwjdXh = 1652626171; BVXPSLKwjdXh > 0; BVXPSLKwjdXh--) {
            kmFBzinGBvI *= OjodtOyiilDzLRf;
            kmFBzinGBvI = OjodtOyiilDzLRf;
            hDqoxGVjUX += cGhcuLqq;
        }
    }

    if (OjodtOyiilDzLRf == -595131.676858485) {
        for (int OfTJESwvoAFVsV = 960441495; OfTJESwvoAFVsV > 0; OfTJESwvoAFVsV--) {
            continue;
        }
    }

    for (int SrMbxU = 1619389186; SrMbxU > 0; SrMbxU--) {
        cGhcuLqq -= cGhcuLqq;
    }

    for (int LhBSFuaiq = 1877299683; LhBSFuaiq > 0; LhBSFuaiq--) {
        continue;
    }

    return agDbEEqokug;
}

bool KVWsorRoJv::zrwMBMlIAjQBKDo()
{
    double yPHBnaWIB = -208891.98119716143;
    double oJdZZURXE = -192131.76377640973;
    int zarzEiLaSAssv = 1070535308;

    for (int MIuLP = 684383304; MIuLP > 0; MIuLP--) {
        oJdZZURXE = yPHBnaWIB;
        yPHBnaWIB *= oJdZZURXE;
        zarzEiLaSAssv += zarzEiLaSAssv;
        yPHBnaWIB *= yPHBnaWIB;
    }

    if (zarzEiLaSAssv != 1070535308) {
        for (int JHraXVFYzNyN = 783440159; JHraXVFYzNyN > 0; JHraXVFYzNyN--) {
            oJdZZURXE += yPHBnaWIB;
            oJdZZURXE /= oJdZZURXE;
            yPHBnaWIB = oJdZZURXE;
            oJdZZURXE *= oJdZZURXE;
        }
    }

    if (zarzEiLaSAssv != 1070535308) {
        for (int UgFkLhqBIq = 1981578794; UgFkLhqBIq > 0; UgFkLhqBIq--) {
            oJdZZURXE /= yPHBnaWIB;
            zarzEiLaSAssv += zarzEiLaSAssv;
        }
    }

    return true;
}

int KVWsorRoJv::rxiOJ()
{
    double EjlcwbiKWABOAK = -822842.5530752273;
    bool uVMgNBOyTbQyz = true;

    for (int mlMJZNSbuaD = 49850602; mlMJZNSbuaD > 0; mlMJZNSbuaD--) {
        uVMgNBOyTbQyz = uVMgNBOyTbQyz;
        uVMgNBOyTbQyz = ! uVMgNBOyTbQyz;
    }

    return -1401415471;
}

string KVWsorRoJv::TjXuua(int vfhWSv, double oHlZaXXoIqFxL, int IkGfaEqHrIIV, string wuykYGTtrnfPeFfk, double NgVpVHyIm)
{
    double kLNhKpCliQkDihrE = 122420.0124652414;
    int XOFmXOzJYVEbXB = 1029630362;
    int SeDPqipGWgYWi = 972192156;
    string OeEOL = string("zHZpuKBSymgBtXQUYwxZlXGrCRCyLYvbUzugwxubIZuVulEXpAypKRdEdvDqHCIUkFZYqaxiDhSKTlORqihDpvdUQIAkdARpfyxOdYRoWAPvghyNgIgwtxWmoYgzwcxnoKzTTKVsrDNBGoCMMopYTLLbkpvGVOFCsiGBSIVnLDdDefktObKMCTqoqmNNWJSgiyaomBnZFwFyZjXXjpzkUEUcNIVIWDryfblANzQpBqBtfh");
    string pKFhzAGLzNk = string("CiLBPIGaNxfvdKSeHrneYslBxPILbTBYZVkMnbMOxrIVXVlwUPgNhPzwwVvwGooeoODgGiTySoiPWjIUqgIsmLXOQRvbagkaLUCOLmYbOnUcEOzlxChgVeygrosTTruqxmPpxjAiUUfYktstyisFRgaBuDEEqCnjfKLIdOEuvbgvkJXFElhFZbApfaZuFuDlhKUUwfTeZgAQVeeaLlumxJwHEaqeWDzgWwYHrII");
    bool EJkkoeHH = true;
    bool wfLhpsFlVQqfuL = true;
    double gEezgVoeJSXwd = 596469.0563293746;
    double wNTDxZnxS = -945182.6264809088;

    for (int LIuDWJAuki = 2051349; LIuDWJAuki > 0; LIuDWJAuki--) {
        continue;
    }

    return pKFhzAGLzNk;
}

double KVWsorRoJv::SeZmO(double XPTjLmSIeZUfz, double VdOEayDDAjAFF, double zLvsvIEyzNBIC)
{
    double ZjtGSkAihRC = -93400.41131702373;
    double IEfcnRKnsBZPqSn = 113722.18549193132;
    string dIaAwo = string("FxYBPdlXHwIVCWIslROSsBlifmDeLzJRwmwBvDvoSfPblVFtQKurXnuBDscvSsOkAtgflzCEFvXCGaiKqvHlMQEAOZeUyIjVYHRbNKirUxHdplUGpaxtXfmUZdmNaInoQAEvzQlgUoqvAyUDWOiKCjqvPeTJBmvqHJrprvGUwmoLQVXhOjQzjoXkntFeolYzcDQntIkMjawTQfVqZShuDFpGqQpqsAcOSUGUtwmWyegWXyaEiclQOMly");
    int LvngzjPJsfQpdbF = 692104582;
    double YPGyVJiOhxLjNVMn = -724733.3165026701;
    bool LkKPIOt = false;
    int UmXZg = 1313432939;
    bool WqEgyfJRMkPcN = true;
    int iLZMIZnam = 2111851859;
    double aEzKkHBCr = 432343.78678615374;

    for (int IdyVfCIbcejyQzM = 536160616; IdyVfCIbcejyQzM > 0; IdyVfCIbcejyQzM--) {
        IEfcnRKnsBZPqSn += IEfcnRKnsBZPqSn;
        XPTjLmSIeZUfz += aEzKkHBCr;
        UmXZg = UmXZg;
        IEfcnRKnsBZPqSn *= IEfcnRKnsBZPqSn;
        IEfcnRKnsBZPqSn -= IEfcnRKnsBZPqSn;
    }

    for (int bqygdbrn = 399603949; bqygdbrn > 0; bqygdbrn--) {
        ZjtGSkAihRC -= ZjtGSkAihRC;
        IEfcnRKnsBZPqSn *= ZjtGSkAihRC;
    }

    for (int VMFWgDjh = 1746380858; VMFWgDjh > 0; VMFWgDjh--) {
        UmXZg *= iLZMIZnam;
        VdOEayDDAjAFF -= XPTjLmSIeZUfz;
        XPTjLmSIeZUfz -= IEfcnRKnsBZPqSn;
    }

    if (LkKPIOt != true) {
        for (int NIOtandqglfqyR = 695309127; NIOtandqglfqyR > 0; NIOtandqglfqyR--) {
            IEfcnRKnsBZPqSn -= zLvsvIEyzNBIC;
        }
    }

    return aEzKkHBCr;
}

KVWsorRoJv::KVWsorRoJv()
{
    this->YJNflQAcsFmsEyQ(string("PawOBtFoxYuBDzQnsihOFFgWtEThUzMKVQErmEfXexvZmQWeXGRjAmJXdvYgVKQBgTaTjEOVBnQtRumsfeZZXrgmMYXlBZABRoayJwXNWlFBUSknNMYHoCgCYBJumHDPdzhHEbODDrsCgCzcpwNUDgQMrhYJkYCSxNoxGRkbdiqJUKehPmGfymVYA"));
    this->OkNhB(528215243);
    this->nYqnXWi(-637455.0544858949, false, false, false, false);
    this->RNvlHifhCVkNghHn(true, string("OxlCbJqghCzpFytGeoOqljXmErkHuQbRqTybnUMYQFzEMtUYyjNADUrKjAoMPnblEgAAYWJqmCSIwuLAouFNiGzScgaaCKqvQtMYGikOmzZGXTgZGsdwUUEKNzTTRbxcINAgLzfBlommrVVvmNvzHQdKOHqtOOJjXuijJMyNWsKtCuquNUSGpfctLGlRXh"), string("uhUMkwPbpOPqQnSOmzqrkmCpqDttMpdtmdCUCezADBroWEGMSNZWQXmdNP"));
    this->NycFmRpkTAcqW(string("rxwTTIcposeWHKJKtoycxPOgGUxCxUqSUNSCZoRLgMqdrGTCDoexlIefNvehvxTOqRDwTuUOaGalKjarkvOZbtkLtBcDtykDVnOLoOkIJtUTZKmjOaBtqrphxbNGuEWKCvkiyfVtnKRxEEWkEcLphZzXfILAMmehSYqcSZNRqQDCviqrPoeUydTZufpKSPEqDNRpcIpSWRdLAobRwFSYlPYsEMyupiCemBmpRQBHxTmcqeaHi"), true, string("PaesOpsTHboTYjSaqmCfSvZITXOjGQTmQWxYoDgEjvzXJfTwXsKrLaHVEvktbvqFPdZBQPMvyXFxGfVVUXZypFotJpxnQtrBwRJL"), string("sntxvIGfZWZFAUWSGynXVsCvyfXBlvnsitfVlaTcSQfMYpFuNFXdpkLtAQUlyAaxkdmihFNzCzgfHgxbNyBoEgnjZDHaKqkeKlmpedKnBXCICPCghIyhXNBxbpatjLqiApHdwvBvucOyiKWDHFLdQasCwdeWbaRiUCPRHpvbaHRwDURXWXMpBhCWywpLVUCEWcgfceygjSilypzjJocRsP"), -2075857929);
    this->VsbLRgpnx(-2051092342, 1847342276, -595131.676858485, 1930665347, string("GztZehJPIsYZRnnOnSKJlzdELzvwaNwCPNXYHdQXAmdmNKMijXmzwLUKJMvuvijo"));
    this->zrwMBMlIAjQBKDo();
    this->rxiOJ();
    this->TjXuua(1372509573, -350433.7170316961, 1572849103, string("uMoREXNnuZEyZCGdbQeCUugmoIIssaQMFjvNHgROtijLBJbiMbVXphEjzzfiHvgwsQCxbYQDaaWExRmDhbweRkyJPbvFughKaRZeteJtJMnVFikiKjQpennJrXKdJANsIDKRNATylZtQVKNzthJouoKExrwaHoDwGFdOWhsCWshHHrEMnfUZMNJRKsbYszKovxpayJwSCGRYmzRhKWoHxXf"), -612067.7615714669);
    this->SeZmO(379125.3650915348, -102059.32319974361, -24181.624123587564);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TPMqRMQklhzWpbu
{
public:
    bool uuPOwEZKc;
    bool YknbQUvlKtyToSZI;
    string ZoNdIXJFkI;

    TPMqRMQklhzWpbu();
    bool nsJbPdmhXgB(int RwBrxYMoTDrv, int SQHUleAqfpK, string ctohVKaQUUbAMEoC, double DHSGRDGdIEIV, int cGXysTxeMStwpTdZ);
    bool APsaBly(int dsLDFR, double zHhHYmfrtZpjbyp, double RbpDj);
    void HYWCzLcfSgYcyOo(string XUGcDpeRkKd, double FzLUsV, string ZgYLdycsJ, string KuLxGvzknTiXsiw, string BmeAmsbFmLZxGxO);
    string QIoehiaAjsAdM(bool eTuxHTGG, int GJCBmeWsP, bool OedoHGaKK, int ahTPMZEJZL, bool FvBGmixlIpyAEx);
protected:
    double Djvok;
    bool yEzEGhYrXqACCr;

    double WyUmgqBMYag(bool AgpzbSNy, double hNTnNZWJ, int iWWnDrLhuGSpOLa, string ZoMaVkLBvXbN);
    void KgJrABWXZn(int vONIyLaml, bool tFhZBPMuMf, int xCheytfVmviYUfz, string BbNcfzGPTg, string kltKETbUgNIGAmXC);
    double juNOhmPlg();
    string phkXIBk(double GrujpuPwtKLT);
    bool ZveJYGapJsRZj(string roEngdBWdplyrK, string uCpSsTwjtguuTzkL);
    bool DwyHBa(bool sTPIEiMSIcwU, double maHtXF);
    string opctF(double YGmvEAXKx, string mhhyZHUwzLR, bool uEkiTz, int XZMPthvTiE, int dzgmvmo);
    int uOFmBodDLAS(bool DiZcqKrNlKiytmt, string HNsjBBd, string Zytvx);
private:
    int NvjAGj;
    bool hHltb;

    bool JqSJjOyDiGCWkfVh(double lWqijzlOWM);
    void CYQGCzxTYG(int yzQZwUb, int VPidxK);
    string UsfsfShnkokbYg(bool qtPta, bool TAoVqwiXzmamo, int ICyynWNZKbu, int UkhlxPMJLQ, double GpFHCG);
};

bool TPMqRMQklhzWpbu::nsJbPdmhXgB(int RwBrxYMoTDrv, int SQHUleAqfpK, string ctohVKaQUUbAMEoC, double DHSGRDGdIEIV, int cGXysTxeMStwpTdZ)
{
    string swviyuDODrXVFjKS = string("LQBqRJrWPCRGKmuUNgvGzcvansYhnyDWSDJYQyKoclseIrKuwwPYmuOcUgBVSUQXgwSAKsMsWUuBKRLSdFSIZQobEclrVIqpKMuhfVKClDLNfUaBDLCZANUmkamquZINKvNBkeqwigulYiOEOzOsarWfa");

    return true;
}

bool TPMqRMQklhzWpbu::APsaBly(int dsLDFR, double zHhHYmfrtZpjbyp, double RbpDj)
{
    int nmySmgEXAhESitq = 506948073;
    double eUNEOfJaWOVyQd = 647435.4330900369;
    int ohOOpGzYDOWQQfnO = 2081794903;
    int lnsAvO = 890905954;
    double LlVEvZDJMm = -170080.59333995456;

    if (RbpDj != 239062.95054596517) {
        for (int TNzXTb = 935306612; TNzXTb > 0; TNzXTb--) {
            nmySmgEXAhESitq *= lnsAvO;
            RbpDj *= eUNEOfJaWOVyQd;
            eUNEOfJaWOVyQd += zHhHYmfrtZpjbyp;
            ohOOpGzYDOWQQfnO += nmySmgEXAhESitq;
        }
    }

    for (int LGCFDZr = 2121628991; LGCFDZr > 0; LGCFDZr--) {
        ohOOpGzYDOWQQfnO = nmySmgEXAhESitq;
    }

    for (int ApXhnDKq = 219085092; ApXhnDKq > 0; ApXhnDKq--) {
        zHhHYmfrtZpjbyp *= RbpDj;
        dsLDFR -= nmySmgEXAhESitq;
    }

    if (lnsAvO <= 458380163) {
        for (int rysOISPQdmB = 1629135792; rysOISPQdmB > 0; rysOISPQdmB--) {
            ohOOpGzYDOWQQfnO += lnsAvO;
            dsLDFR -= dsLDFR;
            nmySmgEXAhESitq -= ohOOpGzYDOWQQfnO;
        }
    }

    if (zHhHYmfrtZpjbyp > 239062.95054596517) {
        for (int AnNRJwcbgcVNjjMn = 2124673220; AnNRJwcbgcVNjjMn > 0; AnNRJwcbgcVNjjMn--) {
            eUNEOfJaWOVyQd /= RbpDj;
            eUNEOfJaWOVyQd = RbpDj;
            zHhHYmfrtZpjbyp = LlVEvZDJMm;
            nmySmgEXAhESitq /= lnsAvO;
        }
    }

    return true;
}

void TPMqRMQklhzWpbu::HYWCzLcfSgYcyOo(string XUGcDpeRkKd, double FzLUsV, string ZgYLdycsJ, string KuLxGvzknTiXsiw, string BmeAmsbFmLZxGxO)
{
    string TUrmVnatYP = string("NOdpJRBaNeAbtbqhMnolgrewPAWZPbeiHzzXIbOIdXgPPxFHfzMbePKIGiSqwJSMYGzPBYYSEWqkHHIUsrLqqbuelThHSvzNmuUktrmhqlSHgJqmDFgjQoQTiunvmIwrAOPlbVHCZkZqwnksxhIwoHdVPEDOOtycYPOhrhvpTWUCbmYXVuNdyedtrBiwlzZrIUltsFjWQMNikXKfcnfwWgpGxijhpumOtsXpxRFjPFkYZukOuiVpMvcr");
    bool GHPNlYcZRtvY = false;
    int DGmPMDwOXUeOdXBW = -1036157637;
    string wpAIXBHQcfIHzgC = string("MXiYDfm");
    int HqVcUdnrgGQ = -680013946;
    bool YFKudJBJBPLwQafx = false;
    bool SXZLwdspIdVi = false;

    for (int pVJisYVcAeNH = 1285559304; pVJisYVcAeNH > 0; pVJisYVcAeNH--) {
        SXZLwdspIdVi = GHPNlYcZRtvY;
    }
}

string TPMqRMQklhzWpbu::QIoehiaAjsAdM(bool eTuxHTGG, int GJCBmeWsP, bool OedoHGaKK, int ahTPMZEJZL, bool FvBGmixlIpyAEx)
{
    int AoECtEVWkfgkgIZ = -899315606;
    bool gFFfZYFPbSKBzKD = true;
    double uhwHRVhGzwZfW = 457070.6710697565;
    int KSJcCj = 1426699850;

    if (KSJcCj < 1426699850) {
        for (int ymxlQRUvFUrO = 2181987; ymxlQRUvFUrO > 0; ymxlQRUvFUrO--) {
            KSJcCj *= GJCBmeWsP;
            OedoHGaKK = gFFfZYFPbSKBzKD;
        }
    }

    for (int LBZoATZyJtUSzH = 756113790; LBZoATZyJtUSzH > 0; LBZoATZyJtUSzH--) {
        AoECtEVWkfgkgIZ += AoECtEVWkfgkgIZ;
        FvBGmixlIpyAEx = FvBGmixlIpyAEx;
    }

    for (int yvqGsXGukgUblQi = 395170378; yvqGsXGukgUblQi > 0; yvqGsXGukgUblQi--) {
        gFFfZYFPbSKBzKD = ! gFFfZYFPbSKBzKD;
        uhwHRVhGzwZfW += uhwHRVhGzwZfW;
    }

    return string("hueJHXnRNCAUkkOqkveJTvQqVsUnRAWBOYlCrsuaiOgOnngKpAVEVhDleBGVzAsMetMDY");
}

double TPMqRMQklhzWpbu::WyUmgqBMYag(bool AgpzbSNy, double hNTnNZWJ, int iWWnDrLhuGSpOLa, string ZoMaVkLBvXbN)
{
    double tFKmAycgskulUlT = -770609.7798004411;
    double YxDXshjoVisUBSm = -28483.935964900462;
    string DMCgtt = string("MwYGaWEgpKfsgcJoDYOjvlFhqHHTXelLNiaZwAfgWcPESiVlsLtnXxladRVQPxCgdQCtfGVqmkcZpGmzNknrpjhnukmUaoADpobEBcHvHCfLctjsXYeqCNcyzZJKMzpKoLFLcJDTNSZIkrToAMxSBxIUBMRlhBMNQxPFidUGHafFlbrrpxvQtOjZJOkSTiqRXxvYquLvUMaercKHkWOSvNUHjInaPbZLuIjTRuW");
    int JPWXq = 278593472;
    int DGqJxmKXXp = -587692886;
    string PNdgXcskzOLKkPf = string("xERVQxogpanWLOaxoGFcgBKmZAPHWNuetRNBFtfhbNqxtcGhxibkQiFIhGaybjiSCIHSLcZGqIuZMMdVIhRKxDpudFUuGNUGHMXkpmEJWzxPRVCzCLgYhJxDqhpWXUknyYqZFcTLGbjLt");
    double lNWySTPPBxNpf = -802128.367244537;
    bool MvQxMXCpiD = false;

    for (int BrcbfNJuUFXHb = 2121308932; BrcbfNJuUFXHb > 0; BrcbfNJuUFXHb--) {
        continue;
    }

    for (int qSYfpEZVrSC = 977360702; qSYfpEZVrSC > 0; qSYfpEZVrSC--) {
        YxDXshjoVisUBSm *= lNWySTPPBxNpf;
        tFKmAycgskulUlT += tFKmAycgskulUlT;
        iWWnDrLhuGSpOLa += JPWXq;
        hNTnNZWJ *= YxDXshjoVisUBSm;
    }

    for (int hHrJEoUuMXAC = 816289836; hHrJEoUuMXAC > 0; hHrJEoUuMXAC--) {
        continue;
    }

    if (MvQxMXCpiD == true) {
        for (int tryAPMtbW = 655014295; tryAPMtbW > 0; tryAPMtbW--) {
            YxDXshjoVisUBSm *= lNWySTPPBxNpf;
        }
    }

    for (int FSeXY = 1939835480; FSeXY > 0; FSeXY--) {
        continue;
    }

    return lNWySTPPBxNpf;
}

void TPMqRMQklhzWpbu::KgJrABWXZn(int vONIyLaml, bool tFhZBPMuMf, int xCheytfVmviYUfz, string BbNcfzGPTg, string kltKETbUgNIGAmXC)
{
    string kEykWiFtYwo = string("zPWeiPphATFXpRWHptCtNfbASAfVIhkjOXeEtbKXqFWMTFZxAhZGFDEblqQZJWgVMNsQKcjaCN");

    for (int GJkFHhvmA = 1265496353; GJkFHhvmA > 0; GJkFHhvmA--) {
        kEykWiFtYwo += BbNcfzGPTg;
    }
}

double TPMqRMQklhzWpbu::juNOhmPlg()
{
    string xOOAZrPsaIxoyMoo = string("AlpwRXuNTGFdRLPbDTSWkOMwEDDgsqycTMudfBhoCsUPEIAKcSEKWjcAplRmjOJoJmhMEykNWDyrlgxSnjVAUsMMUtgittbrXNzlsWWNFFvGFOQNMsrTwEMEuZdaOsPutWygmSoJlUmeVCwKaIlSJGenPHBPzwSyEwiomcqAlStTncBtE");
    bool qqQidQX = false;
    bool ZEWVRJSiDot = false;
    int NCRXhZtlZzwbWpp = -1918472629;
    double HcpNrMkO = 723056.9121505892;
    bool dtJYrPAoIPYcEmL = false;
    bool kiUnADgYTTX = true;
    int AbgJEHKovfdZSLY = -35430146;

    for (int ckvsmtBUsQMuJvt = 395378725; ckvsmtBUsQMuJvt > 0; ckvsmtBUsQMuJvt--) {
        kiUnADgYTTX = ! kiUnADgYTTX;
        dtJYrPAoIPYcEmL = dtJYrPAoIPYcEmL;
        NCRXhZtlZzwbWpp /= NCRXhZtlZzwbWpp;
    }

    for (int XJWXQRm = 1556342280; XJWXQRm > 0; XJWXQRm--) {
        continue;
    }

    for (int VZabrhCXXbdyV = 1248857464; VZabrhCXXbdyV > 0; VZabrhCXXbdyV--) {
        ZEWVRJSiDot = kiUnADgYTTX;
        ZEWVRJSiDot = ! ZEWVRJSiDot;
    }

    return HcpNrMkO;
}

string TPMqRMQklhzWpbu::phkXIBk(double GrujpuPwtKLT)
{
    double crGFQ = -615243.4160063085;
    int DHnniZJvkNVpsj = 1752208937;
    bool BkHdGl = true;
    bool CsccrKq = false;
    bool eOIxXlnx = true;
    double XsaVpRfY = -642898.7667132284;
    string jFxNrSFnvrp = string("EAVfqpMbxltuoTXlorYoExZtaNVPzdgVMZcuseHLAocJYGZxdmIIglVHeEvyzBjyZlHVvyHjknzXabgfZbmbbUCMPeztjYZBNdnhfdKvcHTzRYHyuoWycfpMsvsNFZasqDtbYHVJMsOxXpWpPZwXjbywYmfpkxlh");
    int MInqdRztWeCO = 2096596346;
    bool hDonbgDyZvGSqMjr = false;
    bool rKxQVJnQqIrEDjbT = true;

    for (int DlvaaYaX = 223917337; DlvaaYaX > 0; DlvaaYaX--) {
        rKxQVJnQqIrEDjbT = ! CsccrKq;
    }

    for (int TuHki = 1736597889; TuHki > 0; TuHki--) {
        DHnniZJvkNVpsj -= DHnniZJvkNVpsj;
    }

    if (BkHdGl != false) {
        for (int QwBJqQrFrfHXq = 2002996632; QwBJqQrFrfHXq > 0; QwBJqQrFrfHXq--) {
            BkHdGl = eOIxXlnx;
        }
    }

    if (CsccrKq != true) {
        for (int yKeAKyPkzdJ = 353956655; yKeAKyPkzdJ > 0; yKeAKyPkzdJ--) {
            crGFQ = crGFQ;
            XsaVpRfY -= GrujpuPwtKLT;
        }
    }

    for (int cIwEH = 449740470; cIwEH > 0; cIwEH--) {
        BkHdGl = BkHdGl;
        eOIxXlnx = eOIxXlnx;
        rKxQVJnQqIrEDjbT = ! CsccrKq;
    }

    return jFxNrSFnvrp;
}

bool TPMqRMQklhzWpbu::ZveJYGapJsRZj(string roEngdBWdplyrK, string uCpSsTwjtguuTzkL)
{
    double qojQlmBJaU = -400273.8570175677;
    int oOMrTyENmmS = 157378098;
    int VGBdrHRqNWovlikk = -2074366394;

    return true;
}

bool TPMqRMQklhzWpbu::DwyHBa(bool sTPIEiMSIcwU, double maHtXF)
{
    int IMcnN = 357651685;
    int ZJkVeieBT = 1048254370;
    string QwFSAw = string("rQvsYrWXMswZmghxBxvtUCBfYkIzzUJBlfpCIIwTFLYMIVcTfnHcQynFwMGAoBlZrQpxVZMgTxInFDEnNeuUAcNOYjtVzKDcSZlNvHeoWursPwvIgyRyaUmmVX");
    int QpAsrDWtR = -2006410150;
    double SAfkdZhb = -197131.13225229635;
    double mBbAisZaLxOkU = -272142.6705318906;
    bool BHPYlWIw = true;
    double oQXpyefzTQfi = -606451.7670877666;

    for (int RBMCThBUijB = 1579431572; RBMCThBUijB > 0; RBMCThBUijB--) {
        continue;
    }

    for (int mcEfOVpGCsojqL = 564864237; mcEfOVpGCsojqL > 0; mcEfOVpGCsojqL--) {
        continue;
    }

    if (SAfkdZhb != 118960.0559308483) {
        for (int qfeZLyZG = 718280171; qfeZLyZG > 0; qfeZLyZG--) {
            oQXpyefzTQfi -= oQXpyefzTQfi;
            oQXpyefzTQfi += mBbAisZaLxOkU;
            sTPIEiMSIcwU = sTPIEiMSIcwU;
        }
    }

    if (ZJkVeieBT == 357651685) {
        for (int VdFBwbvlVElEaBNq = 1991644749; VdFBwbvlVElEaBNq > 0; VdFBwbvlVElEaBNq--) {
            SAfkdZhb += maHtXF;
            IMcnN *= ZJkVeieBT;
        }
    }

    return BHPYlWIw;
}

string TPMqRMQklhzWpbu::opctF(double YGmvEAXKx, string mhhyZHUwzLR, bool uEkiTz, int XZMPthvTiE, int dzgmvmo)
{
    int zeIMUEFKuXG = 1929845189;
    int AuiLDtpiqJFU = -1721054336;

    for (int mRXkTulNHl = 716035434; mRXkTulNHl > 0; mRXkTulNHl--) {
        mhhyZHUwzLR = mhhyZHUwzLR;
    }

    if (YGmvEAXKx >= 484327.2575997786) {
        for (int HMcJEUpcwQT = 225169051; HMcJEUpcwQT > 0; HMcJEUpcwQT--) {
            zeIMUEFKuXG /= XZMPthvTiE;
            zeIMUEFKuXG = AuiLDtpiqJFU;
        }
    }

    return mhhyZHUwzLR;
}

int TPMqRMQklhzWpbu::uOFmBodDLAS(bool DiZcqKrNlKiytmt, string HNsjBBd, string Zytvx)
{
    bool tDTdfgRaZ = false;
    string CbRLfBXN = string("IzObIBVrhJSjyjStuEFBmRXkxBsitdDTPOAVoIekhFarMmqWOCAMaqoyFUCAtrPLXXZHJjmkiYvJpqCyetNSIqCTaogRfOKjOUNHFQILWwxPGJYEoBdtnSXfFFGHGebeeCQABquPczLlSwsnwBaTSFVCeowcVxmJvLAoEBUxfnqOrvREdpxHGFKkJsbbHqybAYnATXdAKZbwhBFtWFfEAnVfsyoTmBeNVYg");
    double bQaupUojG = 416533.26756681455;
    double BgLivbUg = -372411.77216690866;
    string pUlZyDRFQIADtmAA = string("embpFVpGxPmJGZAhGeZlisMhIqMWCXPJwhAjVPIWDTDazLyiWrYEMKeSCzQfMRvirxFnoKIroZEvdFACzfbcHOwrxMQAIHUELqeKmsHxKDXiKKmObGwoRNUwbcZVuirMgEgSOoRSzgaAjUbhGXYFOuWq");
    string zfXYNScNkfmLXUc = string("yrdBPpfeBMTvlSYOclJjVusWzZvFFUJFafNLMvlQsmnMrgnbZxIKUOnAEVZSkZiFVJDUrMwOuVboKzazEaIiKPyyskTnrqIaaoZvUytIDhRiULnkIjMAqLAqJprprSwgvXwYTglEdrMjyabToZIfyGkVZFwolDcsjinhQniPaUrhiZBZSOguCrcjtyAWRZhZjkmnFUremYXblWNBOolNbzoofBoYFQkIJmmfQRJhTQfyKMmDsIAAii");
    bool oYMllzZLXzju = false;
    string vjkCmzmDdF = string("lZiHgtpofRFGtHgjRPBpRGHdhzxMRoubQQOnjhRmWXPikFCCLkshFISQCtzMiLdBSHGO");
    string goxKDDDHuq = string("HuHDKfidwfygzeZuZmwRNOyJiuLjXmnQZYKaiBadVuQBSyMoFjgijqolHVNhszCKGWBmakLtpfHdZtiWhPVSACcrvHXmVoqxgsSQPnJPwOztyfdvoCuqbEHmMnbyrChpyHsYrEcNLL");
    bool HAaOgtQPtOUBKCi = true;

    if (HAaOgtQPtOUBKCi == true) {
        for (int PIGqyJo = 2009104758; PIGqyJo > 0; PIGqyJo--) {
            continue;
        }
    }

    for (int sGtMc = 1250793657; sGtMc > 0; sGtMc--) {
        oYMllzZLXzju = tDTdfgRaZ;
        HAaOgtQPtOUBKCi = HAaOgtQPtOUBKCi;
        goxKDDDHuq = zfXYNScNkfmLXUc;
        goxKDDDHuq += HNsjBBd;
    }

    if (vjkCmzmDdF < string("lZiHgtpofRFGtHgjRPBpRGHdhzxMRoubQQOnjhRmWXPikFCCLkshFISQCtzMiLdBSHGO")) {
        for (int rHSBiGNgWi = 679638401; rHSBiGNgWi > 0; rHSBiGNgWi--) {
            oYMllzZLXzju = ! HAaOgtQPtOUBKCi;
        }
    }

    for (int WFhOpn = 895228986; WFhOpn > 0; WFhOpn--) {
        continue;
    }

    return -1115083022;
}

bool TPMqRMQklhzWpbu::JqSJjOyDiGCWkfVh(double lWqijzlOWM)
{
    int xZNlUJViucla = -987908874;
    double olYxjFrZIKZucR = -302642.1802792007;
    bool ZNggwtGh = false;
    double gPPsxTuLjZ = -201776.7157509889;
    double kKROlMKG = -59763.29760522376;
    double SyVihqyvq = 30756.707500967146;
    int WZWQzCM = 816180509;
    string pzaLFW = string("XMSDoBjGUnlGOYfLBJtiPpgmDYurSFzXSzXHApukwdTUPTJxxJcvHUVhXHAJWMpoiTxUDHVEUlTIyHrHminqaNRQDkrv");
    string mwgVttcz = string("xrZtcCViLgOYzZoazdtLSRPPxMWFblnHnZyrMKzSXcOBwBGvRxTBQzMRpBPwFoWWQGxonMCcxgXIMeEFyyBUnuZoAwwwETQHnAzzaZxszkBbkfsLlJFgxwnhtBiLstlevVygYkWbPHAAioQrDOlmRRhTGvcycAMeyCyqKwyflnVcTENnKOGoxkynzdBbTbtVvkAsXYGjAwQTOFalzNgRhqjlAwTHfHuJtTSsLXmiAAOxhBXzAi");
    int pqcTvRRYzwy = 315109507;

    if (lWqijzlOWM < -302642.1802792007) {
        for (int DzNDy = 1972840947; DzNDy > 0; DzNDy--) {
            lWqijzlOWM -= lWqijzlOWM;
            xZNlUJViucla *= xZNlUJViucla;
            SyVihqyvq = kKROlMKG;
            olYxjFrZIKZucR /= gPPsxTuLjZ;
        }
    }

    return ZNggwtGh;
}

void TPMqRMQklhzWpbu::CYQGCzxTYG(int yzQZwUb, int VPidxK)
{
    bool qEcVabMCekU = true;
    double yfLowNmeq = 199066.37499737175;
    bool yyusAsMLeLrrRIOl = true;
    double miniVyriSV = 977851.0385194699;
    int GcQBTqFcY = 1592751309;
    int KtACjNnUTNkI = -2034455779;
    bool XVTUsPhPT = false;
    int nDtkEFS = 580099308;
    int CieAmPL = -118209475;
    double UZpHLfH = 95771.53408328872;

    for (int EdxPH = 772073841; EdxPH > 0; EdxPH--) {
        GcQBTqFcY -= nDtkEFS;
        miniVyriSV *= UZpHLfH;
        VPidxK = nDtkEFS;
        yyusAsMLeLrrRIOl = ! yyusAsMLeLrrRIOl;
    }

    for (int yveubs = 529306914; yveubs > 0; yveubs--) {
        CieAmPL *= VPidxK;
    }

    for (int ZehMbLpEGUX = 111775402; ZehMbLpEGUX > 0; ZehMbLpEGUX--) {
        qEcVabMCekU = ! XVTUsPhPT;
        yfLowNmeq = UZpHLfH;
        qEcVabMCekU = yyusAsMLeLrrRIOl;
        KtACjNnUTNkI += VPidxK;
        CieAmPL = CieAmPL;
    }

    for (int ApXRlxFdmvVF = 1521366265; ApXRlxFdmvVF > 0; ApXRlxFdmvVF--) {
        yzQZwUb += GcQBTqFcY;
    }
}

string TPMqRMQklhzWpbu::UsfsfShnkokbYg(bool qtPta, bool TAoVqwiXzmamo, int ICyynWNZKbu, int UkhlxPMJLQ, double GpFHCG)
{
    double fDDbIlbAjHNIgO = 425898.6099655244;
    double MPRmzhZSpt = -872723.2579764839;
    int KBulbbyJcPTZ = -35104810;
    double DaiQjc = 373322.01203413383;
    string bilOOCZRqrDYFh = string("EbMqmqoakDGEvshcyNkqvrIOaYbjsxmbtakaARLxEFszCJOyoSwFvcpTxaVabPwFuoFDPCTyFkJKSVICAKHdOfOKFbBGelflMIpcqHzxgjhzFOGEdBlmmBYoWfUUPaREjYAyvVZNReqDxWpMGXWgCuxrJRXiZAdUdpoiInKfQzLUHhSQQzTxdolpQqhgHhGMouDXyahdxBvdoCxFkGCwUaJQWLMyxqiGLvWKyFE");
    string yuVLGVpcyxkMS = string("mfKBnm");

    for (int MGlpWKfalvxEunE = 761302048; MGlpWKfalvxEunE > 0; MGlpWKfalvxEunE--) {
        MPRmzhZSpt *= GpFHCG;
        GpFHCG -= DaiQjc;
    }

    for (int zsXaPybH = 917951664; zsXaPybH > 0; zsXaPybH--) {
        DaiQjc *= GpFHCG;
        GpFHCG = MPRmzhZSpt;
        fDDbIlbAjHNIgO = DaiQjc;
    }

    for (int fyUlXbvVFhjvpf = 719539884; fyUlXbvVFhjvpf > 0; fyUlXbvVFhjvpf--) {
        ICyynWNZKbu = UkhlxPMJLQ;
    }

    return yuVLGVpcyxkMS;
}

TPMqRMQklhzWpbu::TPMqRMQklhzWpbu()
{
    this->nsJbPdmhXgB(319004134, 441258305, string("PiaFKotVGiJlzjloBudGtdtWbJpUfNDwAmyxownXFeFkafCpoDOcsEHbPtJxJvurLYwzDBEjEaAQCAxacqbPQhwBuUWNcmNPAWrSTJYbPxuEkJQPyvteOkZURShBByqBHmMkBJdHxygXUCQhypQQYNLQYqiDnFSHmsQJDPEb"), 512061.8682226738, -313012013);
    this->APsaBly(458380163, 239062.95054596517, 789404.9518616488);
    this->HYWCzLcfSgYcyOo(string("AkxuENFhFwOHZHvBJjbQBWZLUkJkJiTYRUbCgsrnxGzFieKObURQLFLkzCObTgHkqLsEkmBenzQwdOEgUnIUksfOoWIMWCBBXrvEIAZMciPkqc"), -512644.71192897984, string("VALZcaGKVscJlVilkwfDfoteiiURyYVJNvWqdpilevmzTXgjrjxkODCdAvihvNOFpMCdPGtYGLAqzeizkCroempmdOrZVZzkoNjssqMXWMHncqDIGkLxIBtFnzrqUUeccqEnaJKrPVLjzTjqCPJJDYLZtiFoGJjHteSWlFoCfSTgJtFvueaBTWYSuxqWKFVtbFFRWGqRcbdBTfddYYLCzYqNHXLqoBjeisLUSmKfhvNiYOwVIYfQJpd"), string("BcXFFnyPbLaQBZPbKLMUXoJTtHlHWCNUfuaYLwhYcyvJFcvHCMQRaDObnkcoorYNZdAfPFvJjdvryYtqaGxwVkfQuFOzlvezSizpaeHEwyKJcVWcnVMgMlzllXJwelKSelSDjWxZSdZnwEXGPuJblUSnxIAJDKAMfKiwPmNwRVFTISOeCBhhTFWMJmxkhLXcHCSByMIXWEBnvyOEKRhJtiJlwKllqMVraorh"), string("YfhKmlfcOpzaHjNYBMaTcskrqesMjQYENarFwNGlKXPmkdRcTcNQGDkXpXjJJUCmdmhUxdlVXzFizXGvzHJYssA"));
    this->QIoehiaAjsAdM(false, 716181627, true, 406222759, false);
    this->WyUmgqBMYag(true, -463891.2435449395, -1838298501, string("fyHZJEyeuPIkRnRnIyIdHeQeRNkNrXWQleGmDrxzFOrTHwkCNqKcOKjudoQminTmBErfsnigRWgdXCvbDeBJQMaYHkSIQcudWrGNjjyuqfEjOxesmhoSTqxsjwtsKEoBFfsTDMEJjIxybGzZIIlMZvDampKfsdiQhUoCCQXgOYVZtGxviCLkmllbXPwCEZeVkKMNKScBYJIvKoJsdbJSRxTxmpLKSEUKythqSpBmuVRNn"));
    this->KgJrABWXZn(1282165417, false, 480803232, string("dZLKzmQicnrIUiDrxnRlXgFhEdXomNHmiBTsuvHjsTeAjlJoqGTypxNZzJPQkJfpMhlpatVrvXJGFsToRAWMAmDnhdxgglqjhZAmfLlfJOpbwYFTCFObqFmJfOmQZiFfzXDpTUaFSgLnpGiKWpuriBG"), string("hwjLbAxobKMnEpivOYYiDjDuRvJJidoFpgeMnMiBqjuCCTXTjwFFrhnNwyJmzIljVFAagfOGpWQuKJNoKyjqhdJitUjruzjeylDOXXBaodvijgyKcGUGRhLKaukXAoChmelCiWpDUBwSRzSTuKNmqUaT"));
    this->juNOhmPlg();
    this->phkXIBk(-99948.24116471843);
    this->ZveJYGapJsRZj(string("uapewhbdCrtkDmmckoBntQMdnrYnKktVTTzVonrUyZqZHJgZGKkJmGKRTLCNnfKHCFyVcqNBKvWeHEpSJVcDDyTVFLEUJgCRqCkeNcqPrWTfrLeEDLTDVJYAXJnlmfgODGkrKtkfEQnLvLiTxMRWfOxkXQhcDrosYJErrxrxdaJqnkClMaoedQpCIfoNECVWVSydvWifqykWrVhZUUSnuA"), string("FNkoCeFvdbOIUaWGtixzyotulcsHfbzMCDiQZuBErAgtmYcvJHXdpyxOhnBmTtJaOACcoZiJjRcEYRDIXWBuevZvGnmdsZpwuoJPehzCGmTvRARnGlYdXIUutHuGfwwPxNLjpcXhZrGhwtunMbPjEqhSbUwFFwoLpCDYcDhknyxiOPteORKAhxEcCrAjeRjPpvMlcRtFyDVTTHUBSjNIXPxnViMZLUYnqTtxiceJ"));
    this->DwyHBa(true, 118960.0559308483);
    this->opctF(484327.2575997786, string("NVYhVOOvVmjbxybjgzcEAkGnYOGqWhriuLEhGTNQvOXMBXEjZUfQMsapFSrthybw"), true, -1043029618, 1896423891);
    this->uOFmBodDLAS(false, string("OQyXFpBHDdmloAfWpXEWMhKByVhxNVTUVCmaRFcERZiwBzfaRGCAuVxjAMvuPNmiDBahuHdaUdOLVBZqugptrSdMOsfLzcbIqpHMeQzuAmsEYteYmeTJWIDADbUOpSUxfFXWcFhNNLlbJJYLLVAjD"), string("vYlhUKhJXyCNnqNxkXWlmJkUrGLrwAwMCxEuSGezzftVOwhkhpJHPYgxoIdCtPxYcAxpyGDykakixHucIHMoDBqTZoitWsscBunhmMDOKBnlzCixOaYxYCSByNrkHwwGCujIEHEzdeLToSFGOEdKtAuHcPNWUgwzxjHgxsMwSSkJvaJdNTeypQClRubKKt"));
    this->JqSJjOyDiGCWkfVh(628562.0984886534);
    this->CYQGCzxTYG(756290740, 355675445);
    this->UsfsfShnkokbYg(false, false, 1925602747, 830854630, -329987.9529260374);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UPIbFTGjVuIzmYki
{
public:
    bool gyheqHRavuFMz;
    string YzHgHlkYCxUOqjoe;
    bool iefRqUe;
    string QKvBiQODszNigK;
    bool IoiZTLOktsnNWQCk;
    bool zPaApWJlhq;

    UPIbFTGjVuIzmYki();
protected:
    string bBzMwNrqpgtdU;
    int eNeMQtWT;
    bool KundUlwHyWGnRdiY;
    string ixyhN;
    bool IZinZXVZwpBeEUT;

    string YLJKVaPUdXyCJHw(string egVcRrRxd, string SZwFubQeOi, double RtPrlxwGw);
    string MtENGr(string nVExLrtORN);
    void sXlRPOAvCpEBrlt(int uURRhCbfpb, string grXRiwodaKxVeoOB);
private:
    bool jCbnDhALTEOFTAJS;
    string mjrVaXApq;
    int jiiFNdFqhCuQYFM;
    int IVQzLwzowTsbxD;

    double TDoDnhyaD(bool ZMYHclD, string AhUlTP, int MseBHIPOuLQQ, string PjyHwgWPFQH);
    void UKgUlfPVzbxr();
    bool utPlQ();
    void XtULz();
    double fWOde(int BhSCXabjGuOfkKRs, double vuxrOSj, int LSltGoC, bool QwVdfzKU);
    double JZYmOcRdbkGnthqr(bool vsKvHmkOombnF);
    int truqDpCKq(double DOevWC, int ytXRPOxpzTtzAE, bool inpkjPxDvPMwML, string FfxWph);
    void GUyZau(string QuAdJpDzC, int oAqTJaJoZEn, double SMJaXu);
};

string UPIbFTGjVuIzmYki::YLJKVaPUdXyCJHw(string egVcRrRxd, string SZwFubQeOi, double RtPrlxwGw)
{
    bool sApsqu = false;
    int VGKwnTQySk = 98638519;
    double eJSIaPPgFeEVVAKA = -974720.8187203443;
    string XnhEcJ = string("YMCPztOdempbYCBUQLGPAntEsqKieApghdTZpbpTrwIzZnsVNcBdseTE");

    for (int QNFsAYiIWq = 1600109117; QNFsAYiIWq > 0; QNFsAYiIWq--) {
        continue;
    }

    for (int JGmUCqENXf = 1216850311; JGmUCqENXf > 0; JGmUCqENXf--) {
        XnhEcJ += egVcRrRxd;
    }

    return XnhEcJ;
}

string UPIbFTGjVuIzmYki::MtENGr(string nVExLrtORN)
{
    int SaLapQVOY = 999771123;
    int ZsTvoiNcXbWwRr = -1816751020;
    string IMfMtvEfbTLOxDmN = string("EuhqYVOdxknGrjTIxVKxBIbOwpBAPSiCZKiuXWONRsIdrAwNAgPekxmcgofaIEXQbvgwWcMjLmBEiHtiTjOxjxVg");
    double KBoJstTnWvGZquOn = 470296.44494564604;

    return IMfMtvEfbTLOxDmN;
}

void UPIbFTGjVuIzmYki::sXlRPOAvCpEBrlt(int uURRhCbfpb, string grXRiwodaKxVeoOB)
{
    bool TfZqzSCu = false;
    int LrtZbvF = -176781526;
    bool aBnKJ = false;
    double LhWiCAZ = 205884.35213853643;
    string IyppipcSxpdbtPp = string("fZUHrjBLuHgvRgJAmFEEAfcaLaxfCcIJbfEpGrxFprYzdYHRRInjClJhahWVRJbSLBaZlPqLcUGmvPuFipEeeFRDsNFshWXHYtplxBNwHDZklsOoJEqVmvYalHSoxYfLiuwrozKuNYUpQZJCoxoBAZutglAqfmpffDTahptQkPPziHYNkHnQWADKzTaQoIxKpEEqvrRJowlWmjCDMUxreLimUXLLCymqaFxlrICpArZurNXIw");
    int KrXTIsemxzuZH = -2011501134;
    bool HeMtxrzZGkazx = true;
    int Tponc = 2146915552;
    double puoWsJRANGRpvU = 27897.025172811813;
    bool kdVPFaXtHqyIeOZ = false;

    for (int eclHkYRHvedcY = 1022927091; eclHkYRHvedcY > 0; eclHkYRHvedcY--) {
        kdVPFaXtHqyIeOZ = kdVPFaXtHqyIeOZ;
        LrtZbvF -= LrtZbvF;
        kdVPFaXtHqyIeOZ = HeMtxrzZGkazx;
        Tponc -= uURRhCbfpb;
    }

    if (TfZqzSCu != true) {
        for (int DaDEVqPbFQSM = 671157732; DaDEVqPbFQSM > 0; DaDEVqPbFQSM--) {
            LhWiCAZ -= puoWsJRANGRpvU;
        }
    }
}

double UPIbFTGjVuIzmYki::TDoDnhyaD(bool ZMYHclD, string AhUlTP, int MseBHIPOuLQQ, string PjyHwgWPFQH)
{
    string CdIxVczAnie = string("GbkxxBLfWyKeohMzfwCGwzlkJZHRjIKrWlEwZiugtScAgBxojaNwpiZxjHFvvCvcoAYytFtLFdMPIGjNajVXdgUxmtVPIlYoSKMhEQsXOtbWYbmqCPVcfgktLTn");
    int IHzgMtRsdgGL = 1530071063;

    for (int TfwNFbnvVVCMQ = 328728001; TfwNFbnvVVCMQ > 0; TfwNFbnvVVCMQ--) {
        CdIxVczAnie = CdIxVczAnie;
        IHzgMtRsdgGL -= IHzgMtRsdgGL;
        CdIxVczAnie += CdIxVczAnie;
    }

    return -861909.0275482247;
}

void UPIbFTGjVuIzmYki::UKgUlfPVzbxr()
{
    double hZqnqlfvEwsrxOO = 887301.976238777;
    double ZMgAI = 679424.0223798599;
    double qknonlUcD = -633515.7921472766;
    bool EwaBoBTsdkN = false;
    bool KpxHwtFVfYcfuSd = false;
    double XiFraEoRCCZgI = 622243.9664433001;
    double HLSxLTpmZeVfWIWO = 531367.9647551043;
    string LSzHHbnuRzMUVTF = string("xnfBvdjPDFqpnkDfNtuJkFJDYdwkAWHWFiixhhfyaTcwBzvlKmyyIrainKFoyezucFFBnNxwmfTwShgYHhZlkhQrocaGinDeEzKsdEWLkclUnRjHdxCjwDXtohmhrlEggKhWBmlDVfimwFOnGAkkFLBhoUXugeAeagOizXCpWOaEfGxiFERbNBUSeeBhHIrmwWMNKNmBR");
    int iOoUhmF = -250231774;
    int QRJdYHs = -1408987749;

    for (int matcExFejTOpiRsS = 1464770931; matcExFejTOpiRsS > 0; matcExFejTOpiRsS--) {
        continue;
    }

    for (int tnFeuIqKohjGg = 689598191; tnFeuIqKohjGg > 0; tnFeuIqKohjGg--) {
        HLSxLTpmZeVfWIWO *= HLSxLTpmZeVfWIWO;
    }

    for (int WkZOaKRF = 549492059; WkZOaKRF > 0; WkZOaKRF--) {
        XiFraEoRCCZgI /= ZMgAI;
        qknonlUcD /= hZqnqlfvEwsrxOO;
        hZqnqlfvEwsrxOO *= HLSxLTpmZeVfWIWO;
    }
}

bool UPIbFTGjVuIzmYki::utPlQ()
{
    string TCeciVtPFpI = string("KYAMtcmOEVEPbtCzVWZWrLugnfqHCRdepLBJUCbrJEPyUcCwrbKWpjdbjIeKGSAoxzyQkfyKZegafwnWwVeFDKFAKfLsLLPyprcssFxdkjwGBhHfgLisUPRIFEfNDGqnPtbglBuQavWfzDyfWg");
    bool lcVFQTeca = true;
    int hfmXtYdoSLZVt = 2016965962;
    bool DihqMIMgzq = false;
    string qTUZZPf = string("YWyJxgnnRg");
    double iynfxCvHekugAc = -804428.7536721886;
    string lkeaPKGnj = string("AKTWXohphxYiZmCijuZiuxOcRVtAitOxXgzRzwxygVMTUUyHYyaVovLeNuXKwzFSkbNFKtatRwGLIIdoTzGbdwjqxVMDyRnkAtFDYVoTdKEDDhoNYYFTkQJOnYbswxCYRzyrQaEsdtkPbDDgMTUFbbTijQKolBfkLPaDnwzwMZEvHMrk");
    double ZTSMFRyAurfkDxbB = 343789.2255878219;
    string eOfOXtlynXrVLb = string("HoVnsAcKILhsMdIwbDlPhvazwUBiMgmMIIttkiyrhOeHNIwdoAKqZQaghIDeLSUnQbmftNzEmxYftsOWQtmisVLmACKHJpLOKEIvJIkEHYNbYaBupEwhtJvAfPCJxhOxjedwYhhjWaMZkgQiDsojNzShBxNMBOKyKxNipLNBWynSeLnlduptntlxnhWsUbnvBuBTMKRwbJQUSeWJpeUZJzXvytmDt");
    int hWICXTBFIIXf = 1332052265;

    for (int OxigXKoxEsCQtbni = 2045814332; OxigXKoxEsCQtbni > 0; OxigXKoxEsCQtbni--) {
        lcVFQTeca = ! lcVFQTeca;
        DihqMIMgzq = lcVFQTeca;
        qTUZZPf = qTUZZPf;
        TCeciVtPFpI = qTUZZPf;
        ZTSMFRyAurfkDxbB -= ZTSMFRyAurfkDxbB;
        DihqMIMgzq = ! lcVFQTeca;
    }

    if (hfmXtYdoSLZVt > 1332052265) {
        for (int RSbJQ = 842621908; RSbJQ > 0; RSbJQ--) {
            lkeaPKGnj = lkeaPKGnj;
        }
    }

    return DihqMIMgzq;
}

void UPIbFTGjVuIzmYki::XtULz()
{
    double rWhwtQvqfmRYeEt = -507026.6877526464;
    bool DlHlJxVBChWhm = true;
    int mOUrdRwQ = 197267862;
    int SXYcvRr = 426107257;
    int xyUsr = -1427109124;
    bool gyOahgXHlREtczbV = true;
    int nFdgDNEiTg = -1640225664;
    bool YxxFciphHsZes = true;
    bool QalUWBopO = true;
    bool IHiJu = true;
}

double UPIbFTGjVuIzmYki::fWOde(int BhSCXabjGuOfkKRs, double vuxrOSj, int LSltGoC, bool QwVdfzKU)
{
    int hHuqIkW = -2138453242;
    int iLXQQ = -444802395;
    double WqMTP = -466122.87060193595;
    bool fEmXex = true;
    int ZhMYtDINbJzvcIj = 2068854125;
    bool JaJfxiaULn = true;
    int pEpIzLIjua = -1709434528;
    bool zaqcVlsCzt = true;
    string AfAfTlCQhCd = string("MhSoOkony");

    if (iLXQQ == 136036939) {
        for (int FPYqbYrjfkeJNA = 2091030514; FPYqbYrjfkeJNA > 0; FPYqbYrjfkeJNA--) {
            pEpIzLIjua += LSltGoC;
            iLXQQ = hHuqIkW;
            hHuqIkW = hHuqIkW;
        }
    }

    for (int XRqMQmszJyLycq = 1100257290; XRqMQmszJyLycq > 0; XRqMQmszJyLycq--) {
        BhSCXabjGuOfkKRs = LSltGoC;
        pEpIzLIjua = iLXQQ;
    }

    for (int JdUwFWLTRmMlpZSw = 2005046196; JdUwFWLTRmMlpZSw > 0; JdUwFWLTRmMlpZSw--) {
        hHuqIkW -= ZhMYtDINbJzvcIj;
    }

    for (int CSCChHVwHi = 93280142; CSCChHVwHi > 0; CSCChHVwHi--) {
        JaJfxiaULn = ! fEmXex;
        vuxrOSj += vuxrOSj;
    }

    if (QwVdfzKU != true) {
        for (int qljHq = 1114939842; qljHq > 0; qljHq--) {
            continue;
        }
    }

    return WqMTP;
}

double UPIbFTGjVuIzmYki::JZYmOcRdbkGnthqr(bool vsKvHmkOombnF)
{
    bool UqCXaRWkQHBRSEBO = false;
    int wXiSyuY = -468738621;
    int yMjKKopKlc = -1840007641;

    for (int UbQvjXrgVHesK = 831344675; UbQvjXrgVHesK > 0; UbQvjXrgVHesK--) {
        yMjKKopKlc += wXiSyuY;
        wXiSyuY *= wXiSyuY;
    }

    return -695613.1115959303;
}

int UPIbFTGjVuIzmYki::truqDpCKq(double DOevWC, int ytXRPOxpzTtzAE, bool inpkjPxDvPMwML, string FfxWph)
{
    double IDwwzwrGZADr = -1033222.7865035835;
    bool xWgPvCzXxoHikdjn = false;

    if (xWgPvCzXxoHikdjn != false) {
        for (int TYlWJIntxVln = 480004998; TYlWJIntxVln > 0; TYlWJIntxVln--) {
            IDwwzwrGZADr -= IDwwzwrGZADr;
            xWgPvCzXxoHikdjn = xWgPvCzXxoHikdjn;
        }
    }

    for (int FTjmqjL = 11758778; FTjmqjL > 0; FTjmqjL--) {
        DOevWC /= IDwwzwrGZADr;
        DOevWC -= IDwwzwrGZADr;
    }

    for (int yIoAGeC = 1895871877; yIoAGeC > 0; yIoAGeC--) {
        DOevWC /= DOevWC;
        inpkjPxDvPMwML = inpkjPxDvPMwML;
        ytXRPOxpzTtzAE /= ytXRPOxpzTtzAE;
    }

    return ytXRPOxpzTtzAE;
}

void UPIbFTGjVuIzmYki::GUyZau(string QuAdJpDzC, int oAqTJaJoZEn, double SMJaXu)
{
    double YVnamNqZwpiL = 1012627.6116785449;
    int gFIOOlAodb = -2121556984;
    bool QOKUQm = false;
    int AUZufr = -774637987;

    for (int goPQPzYUi = 566285890; goPQPzYUi > 0; goPQPzYUi--) {
        YVnamNqZwpiL = SMJaXu;
        oAqTJaJoZEn -= AUZufr;
        AUZufr = oAqTJaJoZEn;
        gFIOOlAodb -= AUZufr;
        oAqTJaJoZEn -= gFIOOlAodb;
    }

    for (int WgTFJSE = 860935576; WgTFJSE > 0; WgTFJSE--) {
        SMJaXu /= YVnamNqZwpiL;
        oAqTJaJoZEn /= oAqTJaJoZEn;
        QOKUQm = QOKUQm;
    }
}

UPIbFTGjVuIzmYki::UPIbFTGjVuIzmYki()
{
    this->YLJKVaPUdXyCJHw(string("OTRTKYXPvjhyvvaekYHVlGPSbEclqTbpyAPNjrBBznkZklidrptYcNeFtGojAjOAGxEUrACCLjPTuwBiyyRDTKGjIgFOuaVHqcxPYrJUuagZOgazFmoQMyrbbGlneCmKMQtqhlWCzldrGdjKrECJwrwzrMpiuRVWvMzKOicEMCcQvHxn"), string("exwXOeETpbimRVuQPLqAxWPcMWUrjKOQSomiYuXDqxVCAoxQGMMOCUtuIoxALQkwRdBgJUaqrSPTlFJOnHimIbcwYNiemKimeEbSAcwNisr"), 153523.0196636362);
    this->MtENGr(string("hblomLpakokvxqnxhCiYOLXNLoLKIpCxY"));
    this->sXlRPOAvCpEBrlt(-1604314882, string("dDImeuRprlaHnHLHljuJTosHu"));
    this->TDoDnhyaD(true, string("hCxDFxNyXpFyAertMwUpICSyEVgdewRsPAoXUlnLUCjJAWDZXvzNKlvufDavFrfSnGXDhpvanZNmuFVNdAffmCfPxzqQkqwXkqjsI"), 907152607, string("XEaLCZhqBPRPHWdysBUakmRlftxDRNALjLejTbSMGCQTuUzinXOdbLAuFYHawDfJjaugzVjhJIzJZmKGVJPusShVQwhVNTOBwLbMzHbxPHuUtuBRCJOw"));
    this->UKgUlfPVzbxr();
    this->utPlQ();
    this->XtULz();
    this->fWOde(-381210824, -483677.8037022752, 136036939, false);
    this->JZYmOcRdbkGnthqr(false);
    this->truqDpCKq(-460066.6281848956, -2133377663, false, string("XjXWCnDWtJOaPmvDrcsYBcBSVfmbTmxwTwCknwGS"));
    this->GUyZau(string("tZaGAaSvvHkXOjWbuATnDRWNTZItkCRwUlULdJbmAYjFSKxQdwfuasOGWqZDChERfPjQpoHjtuGCJpxkrRwezCgYGOxtYfHjDfcGzMUbyRnyOTAKzmqQcHrbuKUwEbQNvyAzKrMUlvAbGjnA"), -910537414, 255440.4449829453);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jxJqkVm
{
public:
    double NAoBsOLxah;
    int MmTSRjUvVQ;
    int dvlUUrUcHzbVfLr;
    string ZObIV;

    jxJqkVm();
    int OdgvfPZIuVbmqt();
    double cnewS(bool mMgemWPGQ, double TvfDjEPSLv, string fJYVrgg, bool XoXDGhKqWaz, int ZjIGMW);
    string XsWftGlG(int QghkTBig, double CUPyJl, int VmZRiydey);
    bool LVgkDhuCYWjdZy(string XTaqe, int SFZXqDO, int IiLYjq);
    void hfwydcOVzTuvuT(string sXgNWqU, double suFeTyQ, bool afEYLYmlpr, int Ocnagzik, double EaombneLOqohgpP);
protected:
    bool gkEmJctvG;

    bool YglNc(string BIfZEkNvPVKIfL, string LjJqL, string rnsFoFqxlm);
    void IwtgSN(double zWxUuCNfX, int olvDe, string fKScOeWYKz, bool TUEIwahq);
    string XmySCjCyMkZp(bool RAUPrlOAvU, int kTdyVUHptVWGqFG, int GNlMhGymDKPv);
    void vGtFupujykHaO(string PnyDuL, int nwlmZOzm);
    bool qrLjOHZw(double VkzSX);
private:
    string XeDHT;
    int YigrS;
    bool AeWRQyvEhuySVFF;

    double eejfvRiUt();
    int JAchrkkD();
    string jUkApx(int lnwMFnwkfRHi, string VCdNTvyLSyuFP, int kiUQDeWkFJTeA, double kwPWxxhSg, double LSXmHIJ);
    double TJoGjgDO(string NgEeQcJArUdPZer);
    double BVLEP(int SJNoileJWeJTiygB, bool LUWXNMXq, string lqXrzFgvtxAnecHp);
    int CBCYtI(double LnBTJuO, int RargxGZhDyFsQos, string bcDCTdByEFDfyUsB, int UHsfeLrrKm);
    double Alwaozk(bool MYoVkwc, double kgUaYeparNWOVe, string fgPtxxOBl, string wzCNvn);
    int EotbzyGLb(bool BQUSIbXZDQmJs, int oACdDeFcPKio, bool dZlCjCX, bool qOSydCheNDFWPjoA, double KTiGKeb);
};

int jxJqkVm::OdgvfPZIuVbmqt()
{
    bool pSnWQD = false;
    int OlKyduKrxCEbLZi = -305186513;
    double JEGEgvfOUdjnBUxm = 400830.7130079532;
    int XnOnQLZmxgL = 878468621;
    bool qTtqUvkhfMaRB = true;
    string qKPRRjjTnhwLo = string("IdlbLARbHMRahOdYtVTszHNrEGaeXQlveAWpaoGpJmkHNzkXObWhPrxffYCAQRnGzeSKMTOeRPUOqDpTNHcvtrGUSOwJykSmfquITajzBEzDVaVRDtat");
    bool CBpFAKmYlcwvup = false;
    bool iuNSaiGZIi = true;
    double eLnyGiuP = -640007.1233528043;
    bool rHdMwUpxlR = false;

    if (eLnyGiuP > -640007.1233528043) {
        for (int cWJpDqcS = 1271497138; cWJpDqcS > 0; cWJpDqcS--) {
            qTtqUvkhfMaRB = ! CBpFAKmYlcwvup;
            rHdMwUpxlR = ! iuNSaiGZIi;
            eLnyGiuP -= JEGEgvfOUdjnBUxm;
        }
    }

    for (int XFgYPCSdLvxCxxZ = 94626512; XFgYPCSdLvxCxxZ > 0; XFgYPCSdLvxCxxZ--) {
        rHdMwUpxlR = ! qTtqUvkhfMaRB;
    }

    if (XnOnQLZmxgL >= 878468621) {
        for (int wjpay = 1969098886; wjpay > 0; wjpay--) {
            CBpFAKmYlcwvup = ! iuNSaiGZIi;
        }
    }

    if (qTtqUvkhfMaRB != false) {
        for (int OPJAPywSyWXsF = 1454485169; OPJAPywSyWXsF > 0; OPJAPywSyWXsF--) {
            XnOnQLZmxgL -= XnOnQLZmxgL;
        }
    }

    for (int USdvmNPYxPjnVb = 238449994; USdvmNPYxPjnVb > 0; USdvmNPYxPjnVb--) {
        iuNSaiGZIi = CBpFAKmYlcwvup;
        CBpFAKmYlcwvup = pSnWQD;
    }

    return XnOnQLZmxgL;
}

double jxJqkVm::cnewS(bool mMgemWPGQ, double TvfDjEPSLv, string fJYVrgg, bool XoXDGhKqWaz, int ZjIGMW)
{
    double ddJyhTrDCOuJUQ = -794675.7214622701;
    int cjfHWyOMywXsQnkf = 1268716307;
    string ydzSDobCHpgPbZDx = string("IWygSmMZFTtCceFTajzyKlfuVEwwVoeRZNClNciEgdGePhkJXJGrrG");
    double VtTMQfKcORjd = -636302.9467007603;
    double xMCHAiK = 557971.796676223;
    double vLvMYsPGpaG = 954596.1626359134;
    double oToEBuZ = 254380.48778184925;

    if (oToEBuZ > 557971.796676223) {
        for (int XTpMpkVQHzAco = 1687813576; XTpMpkVQHzAco > 0; XTpMpkVQHzAco--) {
            vLvMYsPGpaG = vLvMYsPGpaG;
            TvfDjEPSLv += TvfDjEPSLv;
            ddJyhTrDCOuJUQ *= vLvMYsPGpaG;
        }
    }

    for (int AAmzASpP = 1498724904; AAmzASpP > 0; AAmzASpP--) {
        TvfDjEPSLv = ddJyhTrDCOuJUQ;
        xMCHAiK *= xMCHAiK;
        oToEBuZ *= ddJyhTrDCOuJUQ;
        xMCHAiK = ddJyhTrDCOuJUQ;
        TvfDjEPSLv = xMCHAiK;
    }

    for (int DMXehFZ = 75439961; DMXehFZ > 0; DMXehFZ--) {
        ZjIGMW -= cjfHWyOMywXsQnkf;
        ddJyhTrDCOuJUQ += oToEBuZ;
        oToEBuZ -= ddJyhTrDCOuJUQ;
    }

    for (int yGJMdZnv = 1362123353; yGJMdZnv > 0; yGJMdZnv--) {
        VtTMQfKcORjd -= TvfDjEPSLv;
        oToEBuZ /= VtTMQfKcORjd;
        ddJyhTrDCOuJUQ += xMCHAiK;
        ydzSDobCHpgPbZDx = ydzSDobCHpgPbZDx;
    }

    return oToEBuZ;
}

string jxJqkVm::XsWftGlG(int QghkTBig, double CUPyJl, int VmZRiydey)
{
    bool szlZsTKbmUkoN = true;
    bool OtXxtAIXepJ = true;
    string XclNWSzNfUa = string("BxSKwjUSsqJiNweWxOYkpBZSoNAeradbpDZtepCdCWZciGmjybIsgCABqdfgzGBpNPrKcQCMfzRTBEchTppPAfxnDsBXGAgMbcIYOuWwmSPufSCzUvTSjZRrJmgtinuKFztCoKWkOXbmxfyVNvqLLwmOsvKZuGSgmRuxNPeXqEDmSXfRPlDkdMhRtSHlNldJzgcsnwMKyZYvhLJsvsUVhYIVxDTutZMVSiGbHCINiEnBFVsCFbbkOq");
    bool zjGQeiX = true;
    bool zoRuLPePPTtyFl = false;
    double lngHIFdaHkVrO = 983178.6365227336;
    double WwFwc = -271676.07163976383;
    string jibTl = string("rBiJBGcnxvkBFXqjERpIINg");

    for (int KBslMPZLDriKfRCC = 795144728; KBslMPZLDriKfRCC > 0; KBslMPZLDriKfRCC--) {
        CUPyJl /= CUPyJl;
        szlZsTKbmUkoN = OtXxtAIXepJ;
    }

    for (int PYNBGOAkCtzJEHX = 1454210724; PYNBGOAkCtzJEHX > 0; PYNBGOAkCtzJEHX--) {
        WwFwc -= lngHIFdaHkVrO;
        lngHIFdaHkVrO *= lngHIFdaHkVrO;
        szlZsTKbmUkoN = ! zoRuLPePPTtyFl;
        XclNWSzNfUa += jibTl;
    }

    for (int YznRHYFRaU = 1487227526; YznRHYFRaU > 0; YznRHYFRaU--) {
        szlZsTKbmUkoN = ! szlZsTKbmUkoN;
    }

    for (int zDkePahNQcs = 48109882; zDkePahNQcs > 0; zDkePahNQcs--) {
        OtXxtAIXepJ = OtXxtAIXepJ;
        WwFwc /= CUPyJl;
        szlZsTKbmUkoN = ! zjGQeiX;
    }

    for (int WLkYQiWAUSoI = 997215468; WLkYQiWAUSoI > 0; WLkYQiWAUSoI--) {
        continue;
    }

    return jibTl;
}

bool jxJqkVm::LVgkDhuCYWjdZy(string XTaqe, int SFZXqDO, int IiLYjq)
{
    int xoGYqaBu = 1003343176;
    int ITIWhkmxRk = -599784457;
    string gxcdxxVnpFFZJC = string("sdviZrVVvnHKMDemTtpuZnxPLffKvEcypVUIOGiODEhhiACVneEkjHgVbzYUAXrsFwQOrvukELZhhfRXTOWnTOSGgEVhvHrRhMbFDdXymyVhAOjzWMXOwgJQjinAqdwcWQpvFkWgWCPJPgzbbEFIuhQSTeDPKDSCzpUQQmHycRtUdJJCtdzilWeTojpbiQAxgKmYuMjGqhVpJoCT");
    int VXloy = -1171782137;
    double LscyU = -419381.93010170374;
    bool WVtjRDeFsWr = false;
    string kHvmjqu = string("djYqFmTEWaRasoIohQFuoQbKVHquqxWnzslxrMWTuPkIKLhVbglPvkVlCTUpTwmEWfhjgkbmAhkbQAWjDrlWzwmZGXHZeBfhipufNzqDNsCVCRISdjEIteiomrSLsKOWCagjJSGHADsiXPJlhhDxXuQMHVxYIulpDjwSSaRldALyFcSyKQhKJkymFfKIUXhWsskopvjYkGMhIkjTdxvql");
    bool hpPZHPlXKmA = true;
    double aVjVipYPd = -363796.46710841527;

    for (int nrecUOJm = 2126386119; nrecUOJm > 0; nrecUOJm--) {
        IiLYjq /= IiLYjq;
        VXloy -= SFZXqDO;
        ITIWhkmxRk -= xoGYqaBu;
    }

    return hpPZHPlXKmA;
}

void jxJqkVm::hfwydcOVzTuvuT(string sXgNWqU, double suFeTyQ, bool afEYLYmlpr, int Ocnagzik, double EaombneLOqohgpP)
{
    bool KgaUonykrPdeRva = true;
    int IrNiQtatjus = 399138353;
    string pqHYrNtWFOMbw = string("ptP");
    double YjGBQSZHnHDU = -996958.1653963341;
    bool BRuBxZha = true;
    double pFHsmSYttq = 493158.88495693845;
    bool EmpVQdyP = true;
    string ocDzTcjcam = string("ajTAhxaiirBSrFTloXmxqLUaIbuTEBQcJrRfhyVaQWFrJiFjaLUGNlkoLoFDkdAaetfyRLiWUqsqSGdJEIuLVREYFbEMRaYMWaLKZSwNMwfTfxjOsgVPKnJPZqcteesyiYstllmJmbKyytPhhCpKCLMjWDMxyRutDnWENdKyDdWKoDrJqqMGFpGpEhJzwNJod");
    double GTHzfVdv = -584472.5005137182;
    string QULNjld = string("FBpzSSZQrSPjXVnhNjkhKAubRlODxeWxpmoGunb");

    if (Ocnagzik <= -2095009251) {
        for (int PeORaMJYgKelfoBn = 1943623281; PeORaMJYgKelfoBn > 0; PeORaMJYgKelfoBn--) {
            pFHsmSYttq = GTHzfVdv;
        }
    }
}

bool jxJqkVm::YglNc(string BIfZEkNvPVKIfL, string LjJqL, string rnsFoFqxlm)
{
    string JJkiGGh = string("NOsqksjPqwPDuAOfpoOdoTvsxcLLsQlkwCVbffOLFJSoVhqEgRMFgHrefScyxvMITZkaKyCX");
    string pwzyBNL = string("qwmFTwaGSVvdHVeqlXguAjnRdKrTTJQckgZRJroxJlDHBzJCYUOWeuleknGcOATNXsaJzHFaZtDPVdseeWpyMAWSWZNQkJoUVAtULAjVLFWVDtnHGutMaJXYNaVuVQduqRlSXveMGJUmxXELrllqHDWWnRxzNmLhCfinDYont");
    int uqoOTvRy = 639707603;
    double NlpXkvO = -686300.9864701289;
    string CZnMirdkjSuLyzq = string("RLNSFxJttkyAlKuOzrmswWZIjnzQTaqVNmEBtlwPWXbzgJTCWMjJCnhUUfyREyzIsqObmQupoGLvcVSsARellasgPtDeejphntaqPTSoANbFWPEydTohFpuyxsdcZlNXvtHxRKsbfR");
    bool fzSdYILDI = false;
    int SyEePk = -944529930;
    int aMIezSVnBWhV = -1838851551;
    bool mAMTsfiDV = true;
    string VEjVsrxYBxq = string("GYMUAdudMTcjQBqjfgHFvKUGWv");

    return mAMTsfiDV;
}

void jxJqkVm::IwtgSN(double zWxUuCNfX, int olvDe, string fKScOeWYKz, bool TUEIwahq)
{
    bool DGDlyuLo = true;
    bool uwHTBmSeASoxo = true;
    double HclIfUjIOeyCDg = -109694.62404843322;
    double oFDoZnrnEdLwSw = 774231.1401838185;
    int HZLSE = -421415792;
    string gChsOkDBQGoDKlQM = string("cKCPQJQjDyKVjtDlmmsadVfrpOUTtPIjUAQaBLPFUUeLsMCzUsQpmKtxVBLfrakDhoPhmruYJaoaObzvcQAnqSkCoWMFPjirXDycuTksBoDBVvlgnrPNGgDHRqdIwuKJbPozkkPdKNzMTgfLeUaEFgpXfgyREikfnjcBQDxTMxtxWWmsdsZuXlrCTsZizffhOPaEHNGZkKWyxMuOGKIbVqiByiVViwbJYqjamwLUt");
    bool ZdaCHDrsmmv = true;
}

string jxJqkVm::XmySCjCyMkZp(bool RAUPrlOAvU, int kTdyVUHptVWGqFG, int GNlMhGymDKPv)
{
    string HgMOS = string("XMdBOMCXRvesEDkzpTkNWpflPJrUypHilsvkrSimHBCzUpVNWyXzYHxTRQJFmSEBhKhqwCGvOwBaeQzRjyQFmfTvCMjOFiURYuManGxtxnFiksEfuJWTxrKLhZarOWprycIzvKWcZKjyLbSiXpfBRznIOmhYw");
    double DvAOqRTYwA = -705039.081333643;
    bool tcaLcIMtS = false;
    string JGubrVYF = string("Xuc");
    int RSDpHnA = 624433716;
    double tgSFhNQVnVGt = -290585.1421637255;
    bool XSeRDWqSw = true;
    string qeGLeT = string("PWsimSyCnlOfFOypCAxxyBcyGmBHdMCPGjLHL");
    int kHazDYFp = 2138013075;

    for (int NMJrIPZaiMTLU = 1877606117; NMJrIPZaiMTLU > 0; NMJrIPZaiMTLU--) {
        XSeRDWqSw = ! RAUPrlOAvU;
    }

    for (int UUOnRlHgCC = 13423379; UUOnRlHgCC > 0; UUOnRlHgCC--) {
        kHazDYFp -= RSDpHnA;
    }

    if (qeGLeT == string("Xuc")) {
        for (int uyqEkDvQsk = 1516524942; uyqEkDvQsk > 0; uyqEkDvQsk--) {
            HgMOS += HgMOS;
        }
    }

    for (int apbHLpbg = 1516424608; apbHLpbg > 0; apbHLpbg--) {
        tcaLcIMtS = tcaLcIMtS;
    }

    for (int kTsLQVTrrAkm = 635899860; kTsLQVTrrAkm > 0; kTsLQVTrrAkm--) {
        kTdyVUHptVWGqFG -= kHazDYFp;
    }

    for (int IGdtbicKw = 1962896874; IGdtbicKw > 0; IGdtbicKw--) {
        kTdyVUHptVWGqFG /= kHazDYFp;
        JGubrVYF += HgMOS;
        qeGLeT += JGubrVYF;
    }

    return qeGLeT;
}

void jxJqkVm::vGtFupujykHaO(string PnyDuL, int nwlmZOzm)
{
    double WZfCGB = -457963.81013244455;
    double qEBCZoXfIOOA = -293509.24167464057;
    int itJcInTUgDo = -1089718119;

    if (nwlmZOzm > -1087459319) {
        for (int GnjRNJljBytO = 887602442; GnjRNJljBytO > 0; GnjRNJljBytO--) {
            itJcInTUgDo -= itJcInTUgDo;
        }
    }

    for (int LIBKvnJnfGOjzG = 946337728; LIBKvnJnfGOjzG > 0; LIBKvnJnfGOjzG--) {
        PnyDuL += PnyDuL;
    }

    for (int rdneyFKTGFSD = 555640617; rdneyFKTGFSD > 0; rdneyFKTGFSD--) {
        continue;
    }

    for (int pZuegdOMJaPDYGS = 343624075; pZuegdOMJaPDYGS > 0; pZuegdOMJaPDYGS--) {
        nwlmZOzm *= itJcInTUgDo;
        nwlmZOzm *= nwlmZOzm;
        itJcInTUgDo *= itJcInTUgDo;
        itJcInTUgDo += nwlmZOzm;
        nwlmZOzm = itJcInTUgDo;
        PnyDuL += PnyDuL;
    }
}

bool jxJqkVm::qrLjOHZw(double VkzSX)
{
    string ESxgpCSRj = string("GxaeiImQtdhMjcloGQQRjoRjKyTGLRRqrOWJCOjSIeqzJDkphpVCqhsniFEjAClFXHJJvzpXTuDDWxDgHvKQFwKPgpowVIVjRWVyevaMRFycZCt");
    double zveoIbuOWzIMwZN = -299334.7315967696;
    int kmXLcSC = -1157493359;
    double AzxaEosmPV = -318497.05390716513;
    string clZhvCCChxdSmyMo = string("leCEbMnUWoJKSWBMEcSPEmwolqrMTDMjNQbwHkxBILQQZZSRSPSkBkGIkENEbDYCgFsHCJejJvKNQcmgJaGiNyQTxhyebWXWUlDEEUYLzpvFHywWFpAJWQEkVDKGWgQxAYPOViUYg");
    string yOAVNPr = string("BOETqZhPwHrUVQQaDBuzqWHZZWYtPUZzZdDZpHSxeMSXorKTUqZJLiApRfKVZpyWKoGLhqjNchzKOQvHPiPYExRoUoJtkPFLFDpdvGKUemPnGX");
    double ygAuvMWmisZ = -517600.1098630382;
    double ssISmylIEZa = -555264.8297663426;
    bool XfbBkY = false;
    bool CQZBDbNWLpNjTyIn = true;

    if (ESxgpCSRj < string("BOETqZhPwHrUVQQaDBuzqWHZZWYtPUZzZdDZpHSxeMSXorKTUqZJLiApRfKVZpyWKoGLhqjNchzKOQvHPiPYExRoUoJtkPFLFDpdvGKUemPnGX")) {
        for (int lFaXXo = 1264178703; lFaXXo > 0; lFaXXo--) {
            continue;
        }
    }

    return CQZBDbNWLpNjTyIn;
}

double jxJqkVm::eejfvRiUt()
{
    string PFVUWEJABFydvZG = string("KmtDPPwhqKJjMbYdVJDhylLJUuXEnWKFLpVVkAXCvmfjOCJTjANgTtpDLsVAMbsHNyHMBMIWHrVFhGAfxjELEQhdAVGlbXiPzSixcOXOtIbmXRRAZbwUwbSipCaM");
    bool GiQBFOpdGNhPi = true;
    double QFQjLUK = -161123.72141476316;
    int YomTxkOqg = 234464161;
    string IFlqznaEWvKUwn = string("ouWBMYkOWcpIdLDMhzkTmaZKagrpiSMIbNrzGug");

    if (QFQjLUK != -161123.72141476316) {
        for (int aWJhKvBbq = 272725219; aWJhKvBbq > 0; aWJhKvBbq--) {
            QFQjLUK -= QFQjLUK;
            GiQBFOpdGNhPi = ! GiQBFOpdGNhPi;
            IFlqznaEWvKUwn += PFVUWEJABFydvZG;
        }
    }

    return QFQjLUK;
}

int jxJqkVm::JAchrkkD()
{
    string fBKVKfdPcFUNgG = string("GpIntOEkeTouJpdfBqkdocpVOglkcBJycQPiRmKyoYysheUSiftsFfbMOCqnFpuaMdJkEYjaewCGeVzktFgiHTxKlCbBEhhhCWKpdEsMsJAgZLQeCsZMbKgHXwIoaJdm");
    bool okBbKxQvPiJUqc = false;
    bool buCsfQwFZ = true;
    int IxHIRZnzLyT = -357564470;
    int FbFjuXMBKDiD = -405553579;
    double URAra = -740218.3800094821;

    for (int LByLpZr = 1458518180; LByLpZr > 0; LByLpZr--) {
        FbFjuXMBKDiD = IxHIRZnzLyT;
        FbFjuXMBKDiD -= IxHIRZnzLyT;
    }

    return FbFjuXMBKDiD;
}

string jxJqkVm::jUkApx(int lnwMFnwkfRHi, string VCdNTvyLSyuFP, int kiUQDeWkFJTeA, double kwPWxxhSg, double LSXmHIJ)
{
    int PSRBSzJYD = 1356309270;
    double yqiUKkEhiDPJvO = -172044.89444979417;
    double vEgomNLAJrxSAQ = -304010.1953405826;
    int MONOylbJfvviYkv = -1292447230;

    for (int uXFmGSAOVreUI = 2091791424; uXFmGSAOVreUI > 0; uXFmGSAOVreUI--) {
        LSXmHIJ -= kwPWxxhSg;
        lnwMFnwkfRHi *= kiUQDeWkFJTeA;
        yqiUKkEhiDPJvO /= vEgomNLAJrxSAQ;
    }

    return VCdNTvyLSyuFP;
}

double jxJqkVm::TJoGjgDO(string NgEeQcJArUdPZer)
{
    bool KxeCAMlAKfREzxk = false;
    string zeaQyKzPnTmRtpGS = string("MKHNqwbdlbNCmHxmKkkmZLfgCltqcIBzMXqhowPsDFSMKaANzxdEpzjkfdODSRcWtQsnpBKNQAkMsnivZKeaRifdwucMIUNPZsKNRsBOOU");
    int HodPBjG = -304880647;
    int GHbhDRNXWd = 1400130551;
    bool AOlsRCivHVAWYRXa = true;
    string XrcVOYxxxOyV = string("nBajwfKjbGKHuIIwOwwpokcnuiVIczQwWbEzJnQSUtZJIevvPvtVUUqGMQvWmZvQPoisLjXpseeVxBtxCojBTcpavixovABKUaTNrfqqPNclCtUd");
    bool folUmfZI = true;

    if (zeaQyKzPnTmRtpGS > string("MKHNqwbdlbNCmHxmKkkmZLfgCltqcIBzMXqhowPsDFSMKaANzxdEpzjkfdODSRcWtQsnpBKNQAkMsnivZKeaRifdwucMIUNPZsKNRsBOOU")) {
        for (int zbTDBfQaddu = 1732108913; zbTDBfQaddu > 0; zbTDBfQaddu--) {
            GHbhDRNXWd /= HodPBjG;
        }
    }

    for (int gjijSWHxeipwySIK = 834107288; gjijSWHxeipwySIK > 0; gjijSWHxeipwySIK--) {
        continue;
    }

    return 334293.6490798138;
}

double jxJqkVm::BVLEP(int SJNoileJWeJTiygB, bool LUWXNMXq, string lqXrzFgvtxAnecHp)
{
    double erloR = 640308.5246705032;
    bool XNPTAqDlPdAj = true;

    if (SJNoileJWeJTiygB == -1508739966) {
        for (int JiysvJqtXpvmyQ = 1454794712; JiysvJqtXpvmyQ > 0; JiysvJqtXpvmyQ--) {
            LUWXNMXq = ! XNPTAqDlPdAj;
        }
    }

    return erloR;
}

int jxJqkVm::CBCYtI(double LnBTJuO, int RargxGZhDyFsQos, string bcDCTdByEFDfyUsB, int UHsfeLrrKm)
{
    string bbzhRFLua = string("lMbKwmQmTPjzqKMQpKifFntILrRtVNiUrvgPCiNIssNzpdaUfkOfenITCNLnsascdDediAhTBjdqRalNzkbExETBjAIGIVJSLmhVmGInRyEisaHrBKtAldfvaIPPnHIVImjClUajZXyReNSquULCnSGNAqhkrkXqylBHEvtCHZUiskTgqumQSUbmQIcfYhJu");
    int oQrrO = -1250482141;

    if (bbzhRFLua >= string("EywOWGnWkPJxjTDMXPKjIkQfRAFAYULWvEqmTmTmXnoiAwNFouTfsGmudNQzbMvkEffJynkLlDjTSHiNtpBSlBddhyFZGwbwpOvRHjZTsDSDeVqcjuXbxxeqFJhrRRPPaTrIkFqJoVtmxoSoxgLTYLCoNuEBhkygQYAVGxmXqwsyxsByUboddLnFvkOtfIfTLPNkoumnFShdrgOWtFOVHM")) {
        for (int tVdPsQiHVa = 125419933; tVdPsQiHVa > 0; tVdPsQiHVa--) {
            oQrrO /= RargxGZhDyFsQos;
            UHsfeLrrKm += oQrrO;
            bcDCTdByEFDfyUsB = bbzhRFLua;
        }
    }

    return oQrrO;
}

double jxJqkVm::Alwaozk(bool MYoVkwc, double kgUaYeparNWOVe, string fgPtxxOBl, string wzCNvn)
{
    double CdgclRdIDh = -737200.2385555239;
    string BFchb = string("JyeDEzWdmARisLwhEpCNGqzPOXKI");
    int WlUWCPcM = -1094771698;
    int nGYrvcA = 2137056489;

    for (int snQDbtWcPMqMbmTn = 379813689; snQDbtWcPMqMbmTn > 0; snQDbtWcPMqMbmTn--) {
        MYoVkwc = MYoVkwc;
        nGYrvcA += nGYrvcA;
        fgPtxxOBl = wzCNvn;
    }

    if (fgPtxxOBl <= string("JyeDEzWdmARisLwhEpCNGqzPOXKI")) {
        for (int cdqxQJMPEuDJinZ = 265832083; cdqxQJMPEuDJinZ > 0; cdqxQJMPEuDJinZ--) {
            CdgclRdIDh *= CdgclRdIDh;
            kgUaYeparNWOVe -= CdgclRdIDh;
        }
    }

    return CdgclRdIDh;
}

int jxJqkVm::EotbzyGLb(bool BQUSIbXZDQmJs, int oACdDeFcPKio, bool dZlCjCX, bool qOSydCheNDFWPjoA, double KTiGKeb)
{
    string djPilv = string("OkbRcmhHklqKzenmIynmAWGHcXTQUjAONqRRBhxlfNMuIwyTuamQiMpncBNFaGyCwbLeiRSfLvOxcOPlOSfGasTCnkzWpWvqfsKKKsSjaBotAykqQtXMKIXAzKJQVbRXOEbKPJueJTwiuZzeXvdHuEFSgyRMUuFRCmgbvnJzcMwmlifhnikkAoBVIeFwgNhUIIbgaXpzrlbmCazZcChcWUpIshQrNyeulKKDRnHG");
    double tqIyUeo = -983287.5980348977;
    int bESTB = 1022436842;
    bool EoMykhxzatCeMK = true;

    for (int olFQqNUhLiZuV = 1013138215; olFQqNUhLiZuV > 0; olFQqNUhLiZuV--) {
        bESTB = bESTB;
    }

    for (int cjSTQzCERzaL = 2059144316; cjSTQzCERzaL > 0; cjSTQzCERzaL--) {
        qOSydCheNDFWPjoA = qOSydCheNDFWPjoA;
    }

    for (int LrquupRfrzVkpT = 426542382; LrquupRfrzVkpT > 0; LrquupRfrzVkpT--) {
        qOSydCheNDFWPjoA = EoMykhxzatCeMK;
    }

    for (int jBWwzYo = 88856463; jBWwzYo > 0; jBWwzYo--) {
        BQUSIbXZDQmJs = qOSydCheNDFWPjoA;
        EoMykhxzatCeMK = BQUSIbXZDQmJs;
    }

    return bESTB;
}

jxJqkVm::jxJqkVm()
{
    this->OdgvfPZIuVbmqt();
    this->cnewS(false, 197096.16281636347, string("fKSpCNzjfsldQJzSHEKLADWVWJthnCdYuCtXlVSywZOrZxTGhBzwbPOBmVdhjolKGgb"), true, -1180244159);
    this->XsWftGlG(677307790, -168753.7011767011, -668884277);
    this->LVgkDhuCYWjdZy(string("owFbEYcbpxGiWFgFxGmNzrYYTiPvEyjVEZnOUAcWIKENXYCXLeYdlKhNIpmzQwPAOUNdkQeQUVgNtpLjLzqSyqstoltkaTGjFXCScEcVzwCDyNsSWPetQuXUWtVmqHbralzYrAsvsJJVKDVFkUFvpukHoteAkYVOQhdFSebfqvPwrXIEYNEvHEaEJSMfbmAbvgVztYnyyNYyUBvFqIvOzOzwqpNJHpHUnoJNcFkiywHaEMEebcHmhlcfWwrGV"), 1032394392, 87573249);
    this->hfwydcOVzTuvuT(string("kGUivtCOvEfCI"), -95681.86781675092, false, -2095009251, 515238.43063168676);
    this->YglNc(string("XWEZWpiFXAHhhQljEaXmEdGQ"), string("hmJkCDhmhNkcsYGwUwvpitxTwAoziyqVkNQeckyfODYVSIGiykbnrltRBcmPRyvRxhuOIMShEWjWUKHtGJKpeYZmuKFxnUcHyFyhuxDUFjtfOINACDhTkcAlPBrpMbeLlvpDGnRCJyxsFVXfjWLpfTLUYrpKsOSsbsAyNGTsrUzAzkSnqTeaPextFytzZFHPIJVWuFnHvLZoNAxn"), string("BxKRfxcfCyXPwDxJQhDPjRltzjmoeAejQwDeMeYZUkorRDQGbegOmvTIkICXODtliNxmKJYFriGnUSCCBjEDQNuhVwmYsZMxnRNLLlREnOKtBfVILjetPfITXSfoSaViowtetksrpCbCXbhidsvcEkcJYdazOzdtiWrUUUbsys"));
    this->IwtgSN(-110618.74900814502, -1512511949, string("yExWrsKMpvGCvIRchpsjNAZzOuyWPVJzrunlpjOCZNAOmqHYmPTLLaDvdy"), true);
    this->XmySCjCyMkZp(false, 432406998, 978831885);
    this->vGtFupujykHaO(string("zEBwRKuCDZsaiwTcZCThbXoMjpfRIPUqvSccFXxXFSxUBAcoYxKpOaBOirFfLv"), -1087459319);
    this->qrLjOHZw(-161206.19980036485);
    this->eejfvRiUt();
    this->JAchrkkD();
    this->jUkApx(1408436194, string("QlYngy"), -1936316137, 342569.861084693, 965654.6759820157);
    this->TJoGjgDO(string("zinYvVqdgcNrSAqlyOVIGqdepWvKYhXFEfPsElHtswUUTQHxFuVwAxANuVWKvDxOVatomjAITbeRnFiJnOBBsGOeLcQLLZWkvxoOUxpvOsJvekstzkRnSHgEjNdMFXIxHubaCewQIxpOvafjOyWqSWTTvfSSkYSKGEMHHcKtvmGtWMnlHJHOvpuSwbjjyvTchBTEUspOLLBj"));
    this->BVLEP(-1508739966, false, string("OLkLbcBGNchBvBrZLpXKZtiRpyKtEOuxePWVlrACexiDykduxNIXNapHqKfQJRpSyZuHkjLlPlhuiAwExEwkOZYYeksyXSvSqtlfEGwwpTLneHsMpwuvhuSVsXfHSeWJdDETyaONxIAhERQGaVVrrdMpxwkMDqhmmQrqrkqXmxxzjAPjBAavooNdHvNTxPLkvvfeaxzi"));
    this->CBCYtI(774368.3465608647, 793133245, string("EywOWGnWkPJxjTDMXPKjIkQfRAFAYULWvEqmTmTmXnoiAwNFouTfsGmudNQzbMvkEffJynkLlDjTSHiNtpBSlBddhyFZGwbwpOvRHjZTsDSDeVqcjuXbxxeqFJhrRRPPaTrIkFqJoVtmxoSoxgLTYLCoNuEBhkygQYAVGxmXqwsyxsByUboddLnFvkOtfIfTLPNkoumnFShdrgOWtFOVHM"), 765126798);
    this->Alwaozk(false, -543798.9225818943, string("tHYDhxHWvEDAZgbLlqbqYjPHLHZucPvyWjRyGwxgWSslYhQcWhRzHIXimH"), string("zdjJrMfqOmyuzEBZZHLDYFdZjGwbqQMHJOWbBejcjysSnYYgSiYZYLQMJLPoHhFESulIdz"));
    this->EotbzyGLb(true, -1646211919, true, false, 17281.134663811757);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BGMPVdXN
{
public:
    double sOqwoqsPBBMW;

    BGMPVdXN();
    bool fkkIZ(string zQzGs, int KeeDduKDzbWoEOJ, string lALYGZBVMVsGb, string NOIRCSDodRzpGM, double dYokEzyxiq);
    bool kIPtIXmezomlLQG(string KBNIlBwAsyKBDQ, double eodNyGENVLAUoEHA);
    int zCdLHhO(int ZjhvoIVVEpV);
    string PIMOBDcQRzGGD();
    double NSXsIHjghOIkEQ(string vPaIQuf);
    bool vMsjfH(double jzouYSjWyw, string amTfnepgduazDBxs, string hPWGSpeCXIuWdM);
    void KmoJH(bool QlfCoJAfwYQym, double umubtRuKlP, string eKWsMRtwnbqPxl, bool oMrbO, double TSCstoBudSs);
    string rKbAr(string mlBsPlCNbsyswsAw, int DFrAMRIXrGL, int MSqQwZT, string LQRtVubJriUeCxe);
protected:
    bool cCiIXwrzozYcMAh;
    string XwXJCTIIdOxzcQTJ;
    string DYCYdPxBM;

    bool FVeHwSQ(double pSjRLFDJF, bool cWMjctNbNWthWGrx, double tNafpoABFIPLN);
private:
    double KfgXDcyIvpEl;
    string RljoRK;

    bool MRQNqwuixKzsHO(string HEJtuSByL, int SsEIiZdK, string njtSjfvclNlGoOK);
    double BJUSJyzNU(double SjHZfKQqJBgcadUy, bool JGEoIrOQ);
};

bool BGMPVdXN::fkkIZ(string zQzGs, int KeeDduKDzbWoEOJ, string lALYGZBVMVsGb, string NOIRCSDodRzpGM, double dYokEzyxiq)
{
    string dnHOaONPwF = string("JDGtRQjGnfxZTBMnYpRfv");

    for (int GCmYLtaDWNi = 1298469886; GCmYLtaDWNi > 0; GCmYLtaDWNi--) {
        zQzGs = dnHOaONPwF;
        dnHOaONPwF = dnHOaONPwF;
        zQzGs += NOIRCSDodRzpGM;
        dnHOaONPwF += NOIRCSDodRzpGM;
    }

    if (dnHOaONPwF > string("cysoCjHFzTMahpglxNPnTHtJZfFUvOGKtadpvzlCNIbYeoJiHiwDGALoJZvzpibwfmwZqhOGPpyYSGVlSBxCGEsHqSCKcZMjzvrajAGeGgTGeuNMevJNAJSxhnZgBClfNVwqOaiwGENOlFpIHudoaujGxXFETCmCqOqPYPHvcBpyyEMHTIVmUoSljqcxCjDykFLHTwRJEwXPRiEOI")) {
        for (int THdTCxpKJSFtDO = 652757230; THdTCxpKJSFtDO > 0; THdTCxpKJSFtDO--) {
            zQzGs += NOIRCSDodRzpGM;
            zQzGs = dnHOaONPwF;
        }
    }

    return true;
}

bool BGMPVdXN::kIPtIXmezomlLQG(string KBNIlBwAsyKBDQ, double eodNyGENVLAUoEHA)
{
    int CpOaLvLHu = 1681761701;
    int LYRZZfqhuHwLXiHp = -1235786970;
    string kElYmXlRUVjPf = string("fjjJlKyAKRHEgOxIneeBaGtpcXmHDEHiLBUeefHQPuMMADWkBDoUKqqbawilCGHnxunPnEFOixVDLhMiWAXdQBqvimsgZgMzEAtaDmZtqJvfcfgyBYcOOArPVyPaKUpwVTjeALgBsvJHAJQRkyesOPTzRlEqvaqsDZrUMHDOhGESPlyYcJqDORDoCenvDcEWIpJkTsoX");
    bool WJZyyDyuDw = true;
    double xztrAzK = 320034.8670820017;
    double AwKqilnzIrq = 701588.3041238233;
    bool CHOOZuqmpQ = true;

    for (int jmrhwtWbKxaiTK = 372952654; jmrhwtWbKxaiTK > 0; jmrhwtWbKxaiTK--) {
        eodNyGENVLAUoEHA *= xztrAzK;
        kElYmXlRUVjPf = kElYmXlRUVjPf;
        WJZyyDyuDw = WJZyyDyuDw;
    }

    for (int BQFBYQV = 1238794861; BQFBYQV > 0; BQFBYQV--) {
        CHOOZuqmpQ = WJZyyDyuDw;
        kElYmXlRUVjPf = kElYmXlRUVjPf;
        eodNyGENVLAUoEHA *= xztrAzK;
        xztrAzK = AwKqilnzIrq;
    }

    for (int gJImNhsccmmYyyj = 1235766166; gJImNhsccmmYyyj > 0; gJImNhsccmmYyyj--) {
        eodNyGENVLAUoEHA /= xztrAzK;
    }

    for (int DjPEqMFg = 658759126; DjPEqMFg > 0; DjPEqMFg--) {
        WJZyyDyuDw = ! CHOOZuqmpQ;
        LYRZZfqhuHwLXiHp /= LYRZZfqhuHwLXiHp;
        xztrAzK -= xztrAzK;
        LYRZZfqhuHwLXiHp = CpOaLvLHu;
    }

    return CHOOZuqmpQ;
}

int BGMPVdXN::zCdLHhO(int ZjhvoIVVEpV)
{
    bool ImqyVWzJQhJ = false;
    string hmGLF = string("kcqzqqQJYYTEKAFLNeZfwWMNGumXPKWSPDCpQWizijWcxlHtiGxgiorUtzKpBAxJmLJHwXLBFGFShngYMTGUgNIWXmL");
    int CrkSrMnPO = -961627206;
    double oaujSuRyuqTP = 255165.7702245647;
    double YGoZiHYnKAlBux = 429737.9628750951;
    double ByEiQCDbCKfaTv = -439955.053368373;
    double pcmYRh = 121454.82337210298;
    bool lSBpkzqPrqEDM = false;
    int BAnBFUwNJpSc = -466232763;

    for (int oTkfbPbmCGUj = 309538745; oTkfbPbmCGUj > 0; oTkfbPbmCGUj--) {
        continue;
    }

    for (int clDwIAa = 91885099; clDwIAa > 0; clDwIAa--) {
        continue;
    }

    return BAnBFUwNJpSc;
}

string BGMPVdXN::PIMOBDcQRzGGD()
{
    bool lInlPsxThdraRPFy = false;
    double HeUKAtCf = 934534.4300939214;
    int AqPfEfY = -292594551;
    bool tLxyVYfmOBsI = true;
    int sctPPzCuKNawnUx = 116072571;
    double DefAkRudkE = 543675.355226014;
    double qbWaggb = 70061.43460133037;
    int RBUrAAWLVAy = -48196045;

    for (int omIzCmjYmLHpvY = 2045334645; omIzCmjYmLHpvY > 0; omIzCmjYmLHpvY--) {
        sctPPzCuKNawnUx /= RBUrAAWLVAy;
        DefAkRudkE += qbWaggb;
    }

    return string("xbGyEIRDEpnlcOJknWnCaMpwgEkLYvNLsIHjvvzZugPocXjqxCd");
}

double BGMPVdXN::NSXsIHjghOIkEQ(string vPaIQuf)
{
    double Muzfdz = 613336.6362723603;
    string PxxFhSZuCQuXMWXb = string("lfbCchSLsRatqBjxFJvqauCoDrHzyxeYbtXjRFpLuykUSbbAEooxgKCrwlgyvgkDHTssOCnWqeobxGXdtObPmkqexqnBeAHJeXhAZHnwtvtFfBYzeHlzuPLevzqmBrGDQykQcTtUJnWHzjgDBjXW");
    double SJhILhquNo = 308277.9896228859;
    int YugiURLSjf = -742138392;
    int pLvTWU = -218817383;
    double lBcIPUYNzSCLx = -71744.95634248768;
    bool DhjhTmfYA = true;
    int IjtLctwQHpUwkZw = -899096833;
    double SbWllRLH = -791739.5298895569;
    bool WrLjyBEcfys = true;

    for (int cSEZmowVXn = 721002357; cSEZmowVXn > 0; cSEZmowVXn--) {
        Muzfdz *= SbWllRLH;
    }

    for (int tVxdfgTkocTU = 554883250; tVxdfgTkocTU > 0; tVxdfgTkocTU--) {
        continue;
    }

    return SbWllRLH;
}

bool BGMPVdXN::vMsjfH(double jzouYSjWyw, string amTfnepgduazDBxs, string hPWGSpeCXIuWdM)
{
    double RPhByn = -732265.90039869;
    double BFtPtlBJ = -610501.5060617904;
    double sJKRSKGjTTkTtFFc = 309179.0661571555;

    for (int eJBOhYtrdyvE = 1396011487; eJBOhYtrdyvE > 0; eJBOhYtrdyvE--) {
        RPhByn += RPhByn;
        amTfnepgduazDBxs += hPWGSpeCXIuWdM;
        BFtPtlBJ /= RPhByn;
        jzouYSjWyw /= BFtPtlBJ;
        amTfnepgduazDBxs = hPWGSpeCXIuWdM;
    }

    for (int TaRWlUMrgS = 1037512745; TaRWlUMrgS > 0; TaRWlUMrgS--) {
        RPhByn += jzouYSjWyw;
        amTfnepgduazDBxs = amTfnepgduazDBxs;
    }

    if (sJKRSKGjTTkTtFFc >= -610501.5060617904) {
        for (int VBetGmrdepiuqkDw = 24002971; VBetGmrdepiuqkDw > 0; VBetGmrdepiuqkDw--) {
            BFtPtlBJ *= jzouYSjWyw;
            sJKRSKGjTTkTtFFc += sJKRSKGjTTkTtFFc;
        }
    }

    for (int nqAUxExpZzTcYiH = 1612517586; nqAUxExpZzTcYiH > 0; nqAUxExpZzTcYiH--) {
        sJKRSKGjTTkTtFFc /= RPhByn;
        sJKRSKGjTTkTtFFc += jzouYSjWyw;
        BFtPtlBJ -= jzouYSjWyw;
        hPWGSpeCXIuWdM = hPWGSpeCXIuWdM;
        BFtPtlBJ /= BFtPtlBJ;
        jzouYSjWyw -= BFtPtlBJ;
    }

    return true;
}

void BGMPVdXN::KmoJH(bool QlfCoJAfwYQym, double umubtRuKlP, string eKWsMRtwnbqPxl, bool oMrbO, double TSCstoBudSs)
{
    string zPFjmXovqG = string("NAAiPMUSoBQzLJpUMaNMsUZUhFnFUUMJdllEUFtyuYDiIRWLlBwHUIizOVHkOBCIYQOWiccOSpVURqSmlCaeoWxDOrpCkA");
    string LKBNjjGVeWL = string("tXfgfyVfzTGGcZMiTyrWwvQMwSQzXzycAxRdUmXBDfjeqttEbywxIEPAHlWVDIVWmSQipjFLMpwBnctmvBmcXzwdnKCghKdZCHxAErQUJDZxkmyfneVLZGtPxQdXFhZXrCGfHJssQkOFSiSVZYCKVonWFkMIOrBPnfdXceaobIfvwPocMZLPJiTPkoNmEvtFEutUBECMNmbnnAAfPrtlVgrUzrraLuvCqNdjFmdQBRA");
    int XxTVNBibVcHY = -1959340120;

    if (LKBNjjGVeWL > string("NAAiPMUSoBQzLJpUMaNMsUZUhFnFUUMJdllEUFtyuYDiIRWLlBwHUIizOVHkOBCIYQOWiccOSpVURqSmlCaeoWxDOrpCkA")) {
        for (int ARoqPD = 739115797; ARoqPD > 0; ARoqPD--) {
            eKWsMRtwnbqPxl = LKBNjjGVeWL;
            QlfCoJAfwYQym = ! oMrbO;
        }
    }
}

string BGMPVdXN::rKbAr(string mlBsPlCNbsyswsAw, int DFrAMRIXrGL, int MSqQwZT, string LQRtVubJriUeCxe)
{
    double GkExyd = -515418.2624227228;
    string QPAaSujYWD = string("EjIwSPMyhkNWtKnlzsGWAcsJAFzmoSkbU");
    string EfNEqkAZnrHObq = string("dEWLfQrjoNoYSFKWGrDNvwiIPuVRaXVjpX");
    string dSzvxai = string("jGeuVLatxEOWcEeoWnpBzAJJiSSyHFfVH");
    string JUWgHHQV = string("UCeJjAQpINlarjaskNKhRMRwVtpqetnJEvEgdwlYRUcRhkKlwlzvfOflxxkOESaoGBaRSZhkWYtsJEjtSsmwAOiFFcEMQdhPMWZzbFPbnwKdyqvLKcOiCWnCkmTsHxcSgBCuHtlQFZEgeNPaFgILEvATRwzQGyLirIPPJjcZQoTYOvrNYmKHtsDaNpfqNuZzfbGuprtGMyguBTKGqNebqkpSpXCKrYEGFqyyTGyyjTSGGffVsYkJP");

    for (int iAMut = 1822948664; iAMut > 0; iAMut--) {
        mlBsPlCNbsyswsAw = JUWgHHQV;
        EfNEqkAZnrHObq += mlBsPlCNbsyswsAw;
        DFrAMRIXrGL /= DFrAMRIXrGL;
    }

    if (JUWgHHQV == string("EjIwSPMyhkNWtKnlzsGWAcsJAFzmoSkbU")) {
        for (int jtAciUDMEAZxgFL = 264781662; jtAciUDMEAZxgFL > 0; jtAciUDMEAZxgFL--) {
            DFrAMRIXrGL /= DFrAMRIXrGL;
        }
    }

    for (int cMkreLlKqNHQPFYz = 924882553; cMkreLlKqNHQPFYz > 0; cMkreLlKqNHQPFYz--) {
        QPAaSujYWD += JUWgHHQV;
        QPAaSujYWD = LQRtVubJriUeCxe;
        DFrAMRIXrGL += DFrAMRIXrGL;
        dSzvxai = LQRtVubJriUeCxe;
        mlBsPlCNbsyswsAw = mlBsPlCNbsyswsAw;
        GkExyd = GkExyd;
        LQRtVubJriUeCxe = QPAaSujYWD;
    }

    for (int FXgHPJxMKkPHReMN = 1428400793; FXgHPJxMKkPHReMN > 0; FXgHPJxMKkPHReMN--) {
        QPAaSujYWD += QPAaSujYWD;
    }

    if (EfNEqkAZnrHObq < string("UCeJjAQpINlarjaskNKhRMRwVtpqetnJEvEgdwlYRUcRhkKlwlzvfOflxxkOESaoGBaRSZhkWYtsJEjtSsmwAOiFFcEMQdhPMWZzbFPbnwKdyqvLKcOiCWnCkmTsHxcSgBCuHtlQFZEgeNPaFgILEvATRwzQGyLirIPPJjcZQoTYOvrNYmKHtsDaNpfqNuZzfbGuprtGMyguBTKGqNebqkpSpXCKrYEGFqyyTGyyjTSGGffVsYkJP")) {
        for (int SmKLYK = 1013987596; SmKLYK > 0; SmKLYK--) {
            JUWgHHQV = EfNEqkAZnrHObq;
            dSzvxai = QPAaSujYWD;
            JUWgHHQV = JUWgHHQV;
        }
    }

    if (JUWgHHQV == string("liFUMoQmFLXtellrSWbwtBmsBpbTBGnWYoQEkupbneTrrYjCWENCHYrEVPaqHRLtpcApHQlbWUNaxeerOPwpKIKTqXRrssrDEMxVacScLGssLGcRmZCrFlfYGnbRhEqNPsrKmKKxqNjrinWwjcennJyzNJ")) {
        for (int RKWxwctNyJh = 2126489638; RKWxwctNyJh > 0; RKWxwctNyJh--) {
            LQRtVubJriUeCxe = EfNEqkAZnrHObq;
            DFrAMRIXrGL *= DFrAMRIXrGL;
            LQRtVubJriUeCxe += mlBsPlCNbsyswsAw;
            DFrAMRIXrGL -= DFrAMRIXrGL;
            dSzvxai = LQRtVubJriUeCxe;
        }
    }

    return JUWgHHQV;
}

bool BGMPVdXN::FVeHwSQ(double pSjRLFDJF, bool cWMjctNbNWthWGrx, double tNafpoABFIPLN)
{
    bool xsfkcxCnXzHRCe = true;
    int JgSOoDtHVT = -915631783;
    int MlgtLDmAxLnAmeq = 1429290163;
    bool dmkRtDPTgTZ = true;
    int xUunyWfC = -1995496599;
    bool FlAIlvPAWxJRK = false;
    string GyjaBq = string("xizcwhjQgpuKCVoGwlnDmYgCfkYkTznoicSCaCSyHuaIIkLSgJWqsZAnkgRWRkGKYzCWWYvmnnXkgeoTYPMLXKTyRwdGxUdsphpHKPCvellEubhwEbbHtyygTQfVBmRKrSKVIlnvHAuzahyRzpHsKTwjXweHtkTcPKaBRNOomPfNxrkidOxsZlPBCKhnIhbYLglJlYqDISvqPcTQLbgvh");

    if (xsfkcxCnXzHRCe != true) {
        for (int kdnchrjByQ = 996442265; kdnchrjByQ > 0; kdnchrjByQ--) {
            xsfkcxCnXzHRCe = dmkRtDPTgTZ;
            dmkRtDPTgTZ = cWMjctNbNWthWGrx;
        }
    }

    return FlAIlvPAWxJRK;
}

bool BGMPVdXN::MRQNqwuixKzsHO(string HEJtuSByL, int SsEIiZdK, string njtSjfvclNlGoOK)
{
    int BOFLOCd = -870738793;
    int OOjfrllMsl = 1251331586;
    bool wJnRtsDT = true;
    double wSJcyuXcRO = -290852.49666607263;
    bool KuQPFALBHdiwGr = false;
    int lIlOSkisXU = 246424623;
    bool CnLTAxOAovIx = false;
    bool nYIiwO = true;

    for (int jGCkRYptQx = 44837517; jGCkRYptQx > 0; jGCkRYptQx--) {
        lIlOSkisXU /= lIlOSkisXU;
    }

    for (int EkkOCFhCdhDai = 1332933918; EkkOCFhCdhDai > 0; EkkOCFhCdhDai--) {
        SsEIiZdK = SsEIiZdK;
        KuQPFALBHdiwGr = ! wJnRtsDT;
    }

    for (int ZPZrJrTa = 430533931; ZPZrJrTa > 0; ZPZrJrTa--) {
        continue;
    }

    for (int HEqmsPHYFwcTkgfy = 1244033703; HEqmsPHYFwcTkgfy > 0; HEqmsPHYFwcTkgfy--) {
        wSJcyuXcRO += wSJcyuXcRO;
        HEJtuSByL += njtSjfvclNlGoOK;
        HEJtuSByL += njtSjfvclNlGoOK;
        CnLTAxOAovIx = KuQPFALBHdiwGr;
    }

    return nYIiwO;
}

double BGMPVdXN::BJUSJyzNU(double SjHZfKQqJBgcadUy, bool JGEoIrOQ)
{
    bool JMVcHjjrCtCY = false;
    int yYkTX = 2122300763;
    bool UqDDrgGfRSnuMkOh = false;
    string wZGockIRAeh = string("NIxZHraUVqsNiuRpyitLtSBqSqtnVeDMzTNkpnLbjGaQnrfqvEKZNwWrQoPtbsibCqmImysPmWlVntPvVgkKvUthfPBeUwWmvMFecfXIjvPyyqetwOVgaaeJwUROIxhrlamLJbhuHhmqNhTPnFqmJmkFMhtFPLYOLmkZfSPBnvGcwryyOMlsdgxkoOjmorraKpdHiWuHpdJZDXPEyXMMoRTggBZVRRnZiJKyZUrPChcGMD");

    if (UqDDrgGfRSnuMkOh != false) {
        for (int gJQTWoyBhlE = 1958719028; gJQTWoyBhlE > 0; gJQTWoyBhlE--) {
            continue;
        }
    }

    for (int uxVzPkSh = 322578973; uxVzPkSh > 0; uxVzPkSh--) {
        UqDDrgGfRSnuMkOh = ! UqDDrgGfRSnuMkOh;
    }

    if (UqDDrgGfRSnuMkOh == false) {
        for (int BycuQXYvDKeOMupP = 1424149976; BycuQXYvDKeOMupP > 0; BycuQXYvDKeOMupP--) {
            continue;
        }
    }

    return SjHZfKQqJBgcadUy;
}

BGMPVdXN::BGMPVdXN()
{
    this->fkkIZ(string("EiLtGVdAXyZHXjXSBchPTfLMYbxhKUbPKUGcBqOsiKYdbzyuGKoiimdClCRDOkEicYQiqTqhjeoIuubGDXTvYvTGeqUsiMXLrtHePnhZpzacnfBQFezlVwqcWzkWJgJWNGpRxvxe"), 2009218874, string("cysoCjHFzTMahpglxNPnTHtJZfFUvOGKtadpvzlCNIbYeoJiHiwDGALoJZvzpibwfmwZqhOGPpyYSGVlSBxCGEsHqSCKcZMjzvrajAGeGgTGeuNMevJNAJSxhnZgBClfNVwqOaiwGENOlFpIHudoaujGxXFETCmCqOqPYPHvcBpyyEMHTIVmUoSljqcxCjDykFLHTwRJEwXPRiEOI"), string("WYMrUNevgWxeNYmdtCUWXhtkUWXUoSVkwxmyGAGcfjIPsEMxVRIxSmAIORXAqIzsqTxIDoSZckbYXzZsyQwMxjDiGxzJMDqUqsCLeRhYSHDAgZVBrDCRTMuKWNIuxJMUUCSIyJxFBlnyFCRcBYbHrpBtnOpDhwsQTJVtRrkjrWFfYpGlmPdkBQbYbcRBXuzzkLjHzFOHPtXABqazELRd"), 838527.2130490424);
    this->kIPtIXmezomlLQG(string("mXfEboJiqixwZVDAqyiWpStbvwrvKMdciZJMCDqAPyrZHkGLxHSMjrIHSeAZiajmbxOmJRypLLWwPqqKcItHyNMtIycXszUUrADGhiaOdfDwrGOfDNOUPXDzjaJbzHfOdlViEFIatcFLLywMdndUUIwjTaIFRRpcqFfmPGXmEZpupzSuzWsxyIgBfRJJdwSHofyFBswvb"), -591013.1457407358);
    this->zCdLHhO(1918676636);
    this->PIMOBDcQRzGGD();
    this->NSXsIHjghOIkEQ(string("SIbQahLtpAYcdGSvxvKVjjkGAQEvmHXMUnrNNnDSOKqHQhhLVYlwkAtioABlqLivixbgSwKGNtzBQcDyLxeYMomhAKlbrysEqIsXakLmlyXRwWwklcVvLgmKzwahNvWNpQtmatbhRVuosMuLTODuskXqD"));
    this->vMsjfH(-820423.6405788116, string("MjWaZUvlBESUObGqYcFbaqTULuEjbyEkevrOjqiw"), string("ExQFbKlyNkPoIiQQZgjWhBsLQkUhEyUXAVISRQlqpdfcflbeDzcDNLGvoWnoYWRNJerszLGdBZkwFZTSyBSDtgjEojStfWzPBssDCiYMSOjthyYmtijUyQcUxNlzGxHYDUnCCEmaLhkWxfNgUtVVPVvLiGZCXJBUeoInxmuaMnZbltttdzCUXvSldBKEujzjxYgXSqNLNhIiTlaGXUtOuFLjqGejATJlkzNooDggRrDhXpOGmuzqFIgh"));
    this->KmoJH(true, -374504.55197357456, string("ttoybnRXvJUmEkKjlkUXWmUClEFcaRyfxIgEmaZWdEFHfLEkbxUSKMAxsxFPPVucMIUvXvdGtIxbdbCOsUCdaozfTmxSmAETwJvxRKaeeEuQeREsPwhOwAJjXNGoXFEAqEOpUQbHvWeH"), false, -608914.5677868263);
    this->rKbAr(string("tkfUwqrCMOPuUznnDRwRDYobIKYUjPZJ"), -893420106, 557177014, string("liFUMoQmFLXtellrSWbwtBmsBpbTBGnWYoQEkupbneTrrYjCWENCHYrEVPaqHRLtpcApHQlbWUNaxeerOPwpKIKTqXRrssrDEMxVacScLGssLGcRmZCrFlfYGnbRhEqNPsrKmKKxqNjrinWwjcennJyzNJ"));
    this->FVeHwSQ(988336.1703834053, false, -1007154.1660090884);
    this->MRQNqwuixKzsHO(string("BtzBEEVwFADxo"), -460664385, string("dIobnbTlvKagBZviQdwQIbpIOTaMeKRLdLIaxbCuyamNMCkAsikjPMDPXTvqnYOepKltCTNwFWxcUccuxIDawmxoCmFnUnHKXJdbQcVqkzwtLeZqWhtrKqHcNoVeCJxiPRpAuvtGqPYJJLHElyWGROHNROSoEtkDmExOMPUTyhctdlBXucYkWAGmljaPGFLCnodmTviNIhihDBMXJvjlPgeOkoccSLEqRLcnIxhbvFaMXqZXXRAHBsIz"));
    this->BJUSJyzNU(177657.95211364605, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bDewxLb
{
public:
    string PDJpGPPXMWASIo;
    string yzseOxAAfDihqI;
    string cebufbXF;
    double ceTdhxm;
    int acsXNQn;

    bDewxLb();
    int XMKjkqothZl();
    string MQYSTOMeOwesg(string bqWSCoTHp, string azneiVWqetNEN, int REhyzF, int jOFyngLtpNxhDoAB);
    double rEhIjuSwQtpCzZ(string kDpZrQv);
    bool qQuak(bool kLhGpVlH, double axAoMBmwYxhVjDj, string TXBGTBNTFLkeeF);
    void abOQbx(double YHuRYQAIKlGT, int mXjGNysEkxiMSjz, double KUzsm, int WGRlz);
    void yKZIO(double gEAtpmYVYQGV, int bkuFKqrtb, int mpVOYmLgnGtaiULt, bool sklTlckWM, double tTgujDkeJNTcqXio);
    void TYoQtoxqZAZKWO(int RvwIcI);
    string Ztspl();
protected:
    double GecEQjWx;

    string BIyZPz();
    int XpUkgBtoQIp(string IpGPzOxwD, double dDckIj);
    void IrRBveEn(double UiPdEYi, string HFcUxfHge, double jfbDhsEIr);
    string TCiSoJH(int OnkcKNaiKrzjjf, double dDqbsDj, double upAyniJWlGmb);
    double NKNCUAGzTbY(string WNjPzZJmLwZ, string GFNLagpHo);
    double YaTBrWGSFL(string xClRWknIWqWYN, bool RoxxmkWqnQdEeqmP, string wdblD, double dkvQJ, string bmpCRSLniPzq);
    bool XeYAolYepMnGkrY(bool PjKDLg);
    double DWfIumhpZpQV(double ItRzNNkvdKXhvdn, bool kIcbzYxOuaR);
private:
    string RlgrpoNGlCj;
    bool AOzFzUtop;
    string xSIcbVtoddEhej;
    double ajZZpB;

    void aZWaBx(int uwkCiwQwuyFi, string fFkHAkDRFuHzTUIv, string ULQFrBQEsAXcxheH, string odOMeyL);
    int uVzSEfRBChm(bool AewxNwgpPvARrFk, bool mIoVTuMiVmawAdqA, int MYDEATgf);
    bool bUYRhCdVfQgIQVq(bool yOtRXc);
    bool DwBbPGkWp(double LGtRAyHgwtcuZO, double tiZlNjPBG, bool JMlUkOaSqn, string cqrnIlmtm);
};

int bDewxLb::XMKjkqothZl()
{
    int LMnyZYtgGnzPcl = 1111449038;
    string jMoXXTxIaEzoANI = string("KqyKysqzuTl");
    int PceKObVLbqJMSzK = -278203921;
    string GNGgNEGRZF = string("ddJMuvePxlSUkCBBpfKOZwFhILhxWviyq");

    for (int DPVhA = 650695671; DPVhA > 0; DPVhA--) {
        PceKObVLbqJMSzK += PceKObVLbqJMSzK;
    }

    for (int ONKMPOipcUr = 402931498; ONKMPOipcUr > 0; ONKMPOipcUr--) {
        PceKObVLbqJMSzK /= LMnyZYtgGnzPcl;
        GNGgNEGRZF = GNGgNEGRZF;
        GNGgNEGRZF = jMoXXTxIaEzoANI;
    }

    return PceKObVLbqJMSzK;
}

string bDewxLb::MQYSTOMeOwesg(string bqWSCoTHp, string azneiVWqetNEN, int REhyzF, int jOFyngLtpNxhDoAB)
{
    bool HzFEfr = false;
    string TLWcqLL = string("pTGoIeDG");

    for (int daPXEtEZBLBcdZH = 1637787123; daPXEtEZBLBcdZH > 0; daPXEtEZBLBcdZH--) {
        continue;
    }

    if (azneiVWqetNEN >= string("pTGoIeDG")) {
        for (int ciPPSARwE = 1778540860; ciPPSARwE > 0; ciPPSARwE--) {
            azneiVWqetNEN = TLWcqLL;
        }
    }

    return TLWcqLL;
}

double bDewxLb::rEhIjuSwQtpCzZ(string kDpZrQv)
{
    bool OypdAb = false;
    double eCgwKM = 130465.30452642824;

    if (OypdAb == false) {
        for (int VdPDxJZd = 398694527; VdPDxJZd > 0; VdPDxJZd--) {
            continue;
        }
    }

    return eCgwKM;
}

bool bDewxLb::qQuak(bool kLhGpVlH, double axAoMBmwYxhVjDj, string TXBGTBNTFLkeeF)
{
    bool OFUNWOcxdwRbue = false;
    int beuHWFGm = -2067317992;
    string wfLYUcIVopyaxIFa = string("MGgBPbbRaBMkqjUEyWzeJXVTfu");
    string xFAcEYafHnbjRvJ = string("uokVHhEfzRBytRpSlpIbwXmXDswrdyrGDuegVoPRZMBilJLHUOoThmzudcBvAXGRkQcPjOUvPCY");
    string caCjESAtsIIf = string("RehEhdXzMhdiXwwWbsVJIogTcqjAkdHUDQyRuxBIcBiFVNXXIEbcrygLqjxZyaMEWAWcAMQannpQWmuYLbyUYKtaGDHgwolThWvzBHlxgSFEqIjRJUYCwSvfLZfJprCyEmswxYthEZdnYicTEqjChXCtkuxxMVELFRPNItwwvgKpMuBOiMHkPFIMnwpebWtuHGdcAOXsSzBsyFgvcLgpWIaSloGahKeiTz");
    int eKoIRKGIi = -1502233303;
    bool WIXgln = false;
    int OSYtRhvZAVBfNE = 1482276071;

    for (int bLTMSxgg = 1105343633; bLTMSxgg > 0; bLTMSxgg--) {
        continue;
    }

    for (int TjOgywdAWmKfRu = 1456852537; TjOgywdAWmKfRu > 0; TjOgywdAWmKfRu--) {
        TXBGTBNTFLkeeF = TXBGTBNTFLkeeF;
        TXBGTBNTFLkeeF = TXBGTBNTFLkeeF;
        xFAcEYafHnbjRvJ += caCjESAtsIIf;
    }

    if (xFAcEYafHnbjRvJ != string("RehEhdXzMhdiXwwWbsVJIogTcqjAkdHUDQyRuxBIcBiFVNXXIEbcrygLqjxZyaMEWAWcAMQannpQWmuYLbyUYKtaGDHgwolThWvzBHlxgSFEqIjRJUYCwSvfLZfJprCyEmswxYthEZdnYicTEqjChXCtkuxxMVELFRPNItwwvgKpMuBOiMHkPFIMnwpebWtuHGdcAOXsSzBsyFgvcLgpWIaSloGahKeiTz")) {
        for (int XwCxRKi = 1333271074; XwCxRKi > 0; XwCxRKi--) {
            continue;
        }
    }

    return WIXgln;
}

void bDewxLb::abOQbx(double YHuRYQAIKlGT, int mXjGNysEkxiMSjz, double KUzsm, int WGRlz)
{
    int HfknIc = -1114313094;
    bool HaoVqDKoVHf = false;
    int hXZwMK = -1208936819;
    string eStNe = string("EijdrAjJhUXmbIPXJyVlHQgMDNEniLsSIaTNqFjUcRDYPaIpMNxHXtCQqLsaQcgQYOyfrlbwtwuHTaDFXKPEzKdliNYrYnOzPFDKPQGnFeiuCrIEzauQZlvysMmVKNzaSV");

    for (int kCpBcKORompA = 555158178; kCpBcKORompA > 0; kCpBcKORompA--) {
        HaoVqDKoVHf = ! HaoVqDKoVHf;
        YHuRYQAIKlGT /= YHuRYQAIKlGT;
        mXjGNysEkxiMSjz = mXjGNysEkxiMSjz;
    }

    for (int OEUDwRpyUEfRMtwK = 752304858; OEUDwRpyUEfRMtwK > 0; OEUDwRpyUEfRMtwK--) {
        WGRlz /= hXZwMK;
        HaoVqDKoVHf = ! HaoVqDKoVHf;
    }

    if (YHuRYQAIKlGT >= -153169.1076493124) {
        for (int iEXHimXCQU = 1134868425; iEXHimXCQU > 0; iEXHimXCQU--) {
            HfknIc -= HfknIc;
            HfknIc -= hXZwMK;
            HfknIc *= WGRlz;
        }
    }

    for (int iyRGmOox = 1335077026; iyRGmOox > 0; iyRGmOox--) {
        WGRlz = WGRlz;
    }
}

void bDewxLb::yKZIO(double gEAtpmYVYQGV, int bkuFKqrtb, int mpVOYmLgnGtaiULt, bool sklTlckWM, double tTgujDkeJNTcqXio)
{
    double fdKeIrypZP = 106035.28463225573;
    string sqAxgQFGJjZygb = string("hlSxAuFVBvuoMTOhZBshBzvCJWyyOpcoPXgdQzGhhTVahattDGkmfYthfullONkBbkblgwqkaaEileqnfw");
    int mmlhmLOei = -1307948484;
    string oMpWnfne = string("BVZBjdLwsRQtHOKmVjSRloXxMlqWcUOizWIsSTknEYutCTmsnLEWADAMECaqGeQklvIkcnTOogtXPoUUqIZzRJaULmgFHVIYDnlIVTZpDZUujIuGKEDaDMg");
    bool nfJxw = false;
    int TxDdRhzeuCAw = -1669788414;
    bool qzZYn = true;
    int BoxmTDsMTGmV = -1361733162;
    int DlfuiUipJJluecX = 1140253869;
    bool uTNUlN = true;

    if (sqAxgQFGJjZygb > string("hlSxAuFVBvuoMTOhZBshBzvCJWyyOpcoPXgdQzGhhTVahattDGkmfYthfullONkBbkblgwqkaaEileqnfw")) {
        for (int xIfUwVdSUxWsn = 26357533; xIfUwVdSUxWsn > 0; xIfUwVdSUxWsn--) {
            continue;
        }
    }

    for (int hHRPTJnvEv = 574815560; hHRPTJnvEv > 0; hHRPTJnvEv--) {
        continue;
    }

    for (int TDPkflKJmztav = 924228965; TDPkflKJmztav > 0; TDPkflKJmztav--) {
        continue;
    }
}

void bDewxLb::TYoQtoxqZAZKWO(int RvwIcI)
{
    string pKgomKv = string("yPmiiDuUTXssqPNkqbFVmWXwhUNuwHRpKLIugDJZWzfcCqzkgHDgYdJhDxBKgqoYOczltmzWPsmHlxPvvjwqnrbFtKysdxWFCCmky");
    double WTSgkCaHp = 159047.31440886998;
    bool bMDVGhfO = false;
    bool fIuLNEkS = true;

    for (int ZXkSqmcZtONCqkv = 1423687295; ZXkSqmcZtONCqkv > 0; ZXkSqmcZtONCqkv--) {
        fIuLNEkS = ! bMDVGhfO;
    }

    for (int LhLYdzEvfNyNuhl = 21736947; LhLYdzEvfNyNuhl > 0; LhLYdzEvfNyNuhl--) {
        bMDVGhfO = ! fIuLNEkS;
        pKgomKv = pKgomKv;
        fIuLNEkS = fIuLNEkS;
        bMDVGhfO = ! bMDVGhfO;
    }

    if (bMDVGhfO == false) {
        for (int QSVLctPSvC = 1246909662; QSVLctPSvC > 0; QSVLctPSvC--) {
            continue;
        }
    }
}

string bDewxLb::Ztspl()
{
    int bDPqRWDrODMyIUp = -1455005542;
    string CpDugNjPqV = string("yurQSjtNXgnCLCJEKsYJRqNJbDoteJGmGKycGGfXjlyivInpicFeILSwcOjrImGXxUeLocVYbxLceKITCXhpcAzltJIAnNFTYdKRHEnNLZtsngGWGNDAwtWEWapblTyvem");
    string FMfTswzmEVDPL = string("MuGSeXbRxPWamCzXubQbUcEHnHXslVgZORvticEoOcFuEWCIKsMYkfwDdegucCZADHhuMaLEEtwaHexHjBQdubhFlONFurJpdUCBzzKbKGkhuvmmjccktNcQeEoQlcerHgOneKIyiUotAabUGbfRVzTDJLkmBWQRRUmLjFceGilcKCTyIarDJCQbVdtRJzmCiRMwJjRnO");
    string kcbKoMHWm = string("ttQugcNGBYcdhhZohXUenojPkwzbBRTkmQdtXGLkdQJmhqqGSafmXDSDzvSTIqFrFaMW");
    bool LfqoI = false;
    string uPEVpICvhmBp = string("IIHNWdIDnLbbnjewnYxCojzcGTkauEPekjFTctBelKvUnkoxTNSRDgskPihzqnWAtrbChQZECPbOFmCStBXoQUrecFvWSLQHKZaVCwcnjWQVKVHpRDsnPkHPbqHcpHCVBCnwtoXYhXDfUniBFFWUNZXRfuXyOYDbLmDMTC");
    int xFFqRmmX = 1317806446;
    string jhdMQUW = string("sovHmVzsRffbQIPhxLeweStZRHXXXYCQctiVhrk");
    double NJMZNsCOlCfeU = -4920.55128359077;
    bool UcpBdxP = false;

    if (UcpBdxP != false) {
        for (int UdgILgjdmbwgP = 872384686; UdgILgjdmbwgP > 0; UdgILgjdmbwgP--) {
            UcpBdxP = ! LfqoI;
        }
    }

    for (int kHVcACTd = 1382887777; kHVcACTd > 0; kHVcACTd--) {
        xFFqRmmX -= bDPqRWDrODMyIUp;
    }

    return jhdMQUW;
}

string bDewxLb::BIyZPz()
{
    string heCyKDnluO = string("oRYPPiUzPaFNDyBJsMjYYbCGCqZtJbKlMUfbiWfJdVzEACuNTzRhlWMFpFGeDLqHvqiSoKsLqLeclKezwcKSYMcbAsQLcQEmKODpNUPCBkFnFsUKxawMEwLJEIeCwbFMKBQWvKLAHweqLDXpZAqSQaaiWNTJjKwyIjNcAGGDnLwjLcDms");
    double LMgjNk = -447567.7360026235;
    string HEvFQN = string("ylvbSaqVThmUhgZMSDGbdbvksJhGPocyLBKYJusrwMZBPeCpNPcifpI");
    int IByceVA = 1135152758;

    for (int enKUJlwirWXUyJ = 743816564; enKUJlwirWXUyJ > 0; enKUJlwirWXUyJ--) {
        continue;
    }

    for (int bDxWGdZaVXXDfQ = 1341085897; bDxWGdZaVXXDfQ > 0; bDxWGdZaVXXDfQ--) {
        HEvFQN += HEvFQN;
        heCyKDnluO = heCyKDnluO;
        heCyKDnluO = heCyKDnluO;
    }

    for (int dXGkkGkYWFI = 70391154; dXGkkGkYWFI > 0; dXGkkGkYWFI--) {
        heCyKDnluO += heCyKDnluO;
    }

    if (HEvFQN > string("ylvbSaqVThmUhgZMSDGbdbvksJhGPocyLBKYJusrwMZBPeCpNPcifpI")) {
        for (int tgXiMgyDvLrCWP = 1077926401; tgXiMgyDvLrCWP > 0; tgXiMgyDvLrCWP--) {
            HEvFQN = HEvFQN;
            heCyKDnluO = heCyKDnluO;
            HEvFQN = HEvFQN;
            LMgjNk *= LMgjNk;
        }
    }

    if (HEvFQN == string("oRYPPiUzPaFNDyBJsMjYYbCGCqZtJbKlMUfbiWfJdVzEACuNTzRhlWMFpFGeDLqHvqiSoKsLqLeclKezwcKSYMcbAsQLcQEmKODpNUPCBkFnFsUKxawMEwLJEIeCwbFMKBQWvKLAHweqLDXpZAqSQaaiWNTJjKwyIjNcAGGDnLwjLcDms")) {
        for (int xOBuHgay = 573377629; xOBuHgay > 0; xOBuHgay--) {
            HEvFQN += HEvFQN;
            HEvFQN += heCyKDnluO;
        }
    }

    return HEvFQN;
}

int bDewxLb::XpUkgBtoQIp(string IpGPzOxwD, double dDckIj)
{
    bool VlyNlHwQZqGvBvvm = false;
    int pJPUe = 45223884;
    int yaaxzrtScAo = 335496468;

    if (pJPUe < 335496468) {
        for (int yrVVaKy = 1792473003; yrVVaKy > 0; yrVVaKy--) {
            yaaxzrtScAo *= pJPUe;
            pJPUe *= yaaxzrtScAo;
            pJPUe *= yaaxzrtScAo;
            IpGPzOxwD = IpGPzOxwD;
        }
    }

    for (int YOUCrjUyRKtZFSwH = 1053409552; YOUCrjUyRKtZFSwH > 0; YOUCrjUyRKtZFSwH--) {
        continue;
    }

    if (IpGPzOxwD == string("JInPmwvewkBeuybyKnjFT")) {
        for (int oZndz = 1515810228; oZndz > 0; oZndz--) {
            IpGPzOxwD = IpGPzOxwD;
        }
    }

    for (int zqAgNKNHHmiDgt = 1145089561; zqAgNKNHHmiDgt > 0; zqAgNKNHHmiDgt--) {
        yaaxzrtScAo = pJPUe;
        yaaxzrtScAo *= pJPUe;
        pJPUe -= pJPUe;
        IpGPzOxwD = IpGPzOxwD;
    }

    if (yaaxzrtScAo >= 45223884) {
        for (int wESuCZPRmYVYq = 1380360215; wESuCZPRmYVYq > 0; wESuCZPRmYVYq--) {
            VlyNlHwQZqGvBvvm = VlyNlHwQZqGvBvvm;
            yaaxzrtScAo += yaaxzrtScAo;
        }
    }

    for (int wgvAossQHDoPgZ = 237475131; wgvAossQHDoPgZ > 0; wgvAossQHDoPgZ--) {
        pJPUe += yaaxzrtScAo;
    }

    return yaaxzrtScAo;
}

void bDewxLb::IrRBveEn(double UiPdEYi, string HFcUxfHge, double jfbDhsEIr)
{
    string psZghpyHbRDCl = string("GuvaefSclzkADCHeTupYRAoyYqTvixTXDOyWhkQQbmGJizZJluObXuemPNacuAQExMGRoaEXnKoYCZlvwfCHGiJbyyZSSxIAccwEJKPRLHZOPTXkFpQdarNEiDuXvCG");
    double aRvcWVBMWS = 706451.38426096;
    bool yXjhBUFIsdS = false;
    int ioBgQLNDYLpYdKr = 1518978619;
    string BZLYFmHSWL = string("AWpivPWBzfHuxdpYpvqoNpdtenqczqdtFxPlZQtorejIyypbflhZbAtucpTAYvGutJlHSANZOkCBAaenudRcscpCcNTOymbglItaspCDbWCtQVRPvkEeqSIXUBtIzlbNROMJkrpjhYJTxkinCSLmuWjwiMODCKDEjDVeAbfaGguIbCLWVJXrCVdrCFDUFBlturlTAUXuggUrJGWvMVjKPiYQQJirtPrzufywhGhENvFCT");
    double GUeyTtxzJWgGs = 970868.5850611642;
    string xoEIXsGZf = string("WKLRcMuGAyJLtGaRSBFiTugDQNqCBOQOgzVJVxIOeoTNiLWwIkiHmGKYkIONWAKutdwrHofzmJkvOaBYBQMEjYhzOMWaQuZgNMSgXRdJLldfVGkJNyvRAfmadEimRjTYoAPMYuiGuLlADXJJTLABcOOZrbhZuCHxCttXsLjLWdJDwfNCRcHgXFvamGuBDQbuNRXTtPoIbaIkFdUrkOyzoSHXfxsmaTZjyXcSMIalfDyWvTfQClcJYFstzkP");
    string LuPTUeKKRQeXDdF = string("OhMYKvMwoSRuJyVWhZUj");

    for (int aIqgezwKQZdGp = 1241424169; aIqgezwKQZdGp > 0; aIqgezwKQZdGp--) {
        continue;
    }

    for (int nSGiishd = 631052857; nSGiishd > 0; nSGiishd--) {
        continue;
    }

    for (int nhcSQhOm = 817349639; nhcSQhOm > 0; nhcSQhOm--) {
        psZghpyHbRDCl = HFcUxfHge;
    }
}

string bDewxLb::TCiSoJH(int OnkcKNaiKrzjjf, double dDqbsDj, double upAyniJWlGmb)
{
    double XCrTF = 931409.640924189;
    int WrwQlaB = -729154424;

    if (upAyniJWlGmb > 931409.640924189) {
        for (int nbHuvr = 294719868; nbHuvr > 0; nbHuvr--) {
            upAyniJWlGmb = XCrTF;
            OnkcKNaiKrzjjf += OnkcKNaiKrzjjf;
            dDqbsDj *= XCrTF;
            dDqbsDj *= upAyniJWlGmb;
            dDqbsDj = dDqbsDj;
        }
    }

    if (dDqbsDj < 663016.850696398) {
        for (int RPcREH = 1902213997; RPcREH > 0; RPcREH--) {
            WrwQlaB = OnkcKNaiKrzjjf;
        }
    }

    for (int xmZCMPzYkUAys = 185276344; xmZCMPzYkUAys > 0; xmZCMPzYkUAys--) {
        XCrTF -= dDqbsDj;
        upAyniJWlGmb -= XCrTF;
        dDqbsDj /= upAyniJWlGmb;
        dDqbsDj += dDqbsDj;
    }

    if (OnkcKNaiKrzjjf != -728278992) {
        for (int vGAVIjuBaEX = 854335108; vGAVIjuBaEX > 0; vGAVIjuBaEX--) {
            WrwQlaB /= OnkcKNaiKrzjjf;
            upAyniJWlGmb = dDqbsDj;
            OnkcKNaiKrzjjf /= WrwQlaB;
            OnkcKNaiKrzjjf += OnkcKNaiKrzjjf;
        }
    }

    for (int IRewDEJktJOylZ = 99292339; IRewDEJktJOylZ > 0; IRewDEJktJOylZ--) {
        upAyniJWlGmb /= dDqbsDj;
    }

    return string("ZNPPQbCo");
}

double bDewxLb::NKNCUAGzTbY(string WNjPzZJmLwZ, string GFNLagpHo)
{
    int xIIbLRsMRNtelX = -727591008;

    return 632893.9130201681;
}

double bDewxLb::YaTBrWGSFL(string xClRWknIWqWYN, bool RoxxmkWqnQdEeqmP, string wdblD, double dkvQJ, string bmpCRSLniPzq)
{
    double AMkOTUhoEeEpGB = 276208.30893020594;
    string KKfekJN = string("MjKiBajIcCehdtscRHzWlNQrnzbOlolzwTKsvkBvbrDWpwjqbTUEoprOCMpMdryBDSHsMAquchDFCRGhYlezlwmlIunQYUhnBXfPKbsAlQIUXTigLIrQoBmGdccSnEniDzjFvqSsuTbxjGpFiaddGpPMaIrEvoZyCQKLwrJRVAchlAPaWdsfyEMBCceKrpzqvgggjuuUElRmghSpGXIjDGCUKmlQJbrwxturzJWuxt");
    bool ZwvjFzOevMqRChV = true;
    double PoHCaYbcgcjuoE = 824254.4112534402;
    bool hvQrKtD = true;
    string hEMqGoC = string("kWBcSzWFOFddSQSAVWUWYyNfpfuPmSLDtAkrmfJiTWgmPwyeThUiMUPKOkSOvWLIYKgePdTkGCSAVGuBBbRXneedALIjvnlRNJdeeZCrZakjztfhRpsaEcBxXvuNPUEuAhgBlfHyqLGpNaPeGSvTuvhzaLMbnXEWCvkIdEvDeSzbelhEoNdATSLyKkPPPutwDzGExSoAFJuukNNkasmERFxHLgoUwyACjYqbMuscEgs");

    for (int nWTZZBghnjdtdfn = 172228562; nWTZZBghnjdtdfn > 0; nWTZZBghnjdtdfn--) {
        hEMqGoC = hEMqGoC;
        xClRWknIWqWYN += xClRWknIWqWYN;
        KKfekJN += wdblD;
    }

    for (int HKTctstFLZgnkP = 41443768; HKTctstFLZgnkP > 0; HKTctstFLZgnkP--) {
        RoxxmkWqnQdEeqmP = ZwvjFzOevMqRChV;
        AMkOTUhoEeEpGB -= PoHCaYbcgcjuoE;
        KKfekJN = hEMqGoC;
        dkvQJ = PoHCaYbcgcjuoE;
        ZwvjFzOevMqRChV = ! hvQrKtD;
    }

    if (ZwvjFzOevMqRChV == true) {
        for (int FrZTZUeDoiBPXvh = 1283168119; FrZTZUeDoiBPXvh > 0; FrZTZUeDoiBPXvh--) {
            xClRWknIWqWYN += bmpCRSLniPzq;
            RoxxmkWqnQdEeqmP = ! hvQrKtD;
        }
    }

    for (int VngOK = 1166406742; VngOK > 0; VngOK--) {
        PoHCaYbcgcjuoE += dkvQJ;
    }

    return PoHCaYbcgcjuoE;
}

bool bDewxLb::XeYAolYepMnGkrY(bool PjKDLg)
{
    int eLleTXBHyngURR = -1167128369;
    double rKHpupWlaWXMtr = -565049.3635380509;
    string KmDAwFAmbwY = string("pZujkggUafVndOOQWQfwEMHhishxQipErvvyLoxUSedFVVZQTLqZsZISCTjPTeGE");
    double TuVoWihUlKZETD = -665659.5707256857;
    int vziOAS = 344083244;
    int tHHePOEXvpLur = 694262533;

    if (tHHePOEXvpLur < -1167128369) {
        for (int WQojN = 1164323721; WQojN > 0; WQojN--) {
            tHHePOEXvpLur /= tHHePOEXvpLur;
            rKHpupWlaWXMtr = rKHpupWlaWXMtr;
            eLleTXBHyngURR *= vziOAS;
            rKHpupWlaWXMtr *= rKHpupWlaWXMtr;
        }
    }

    return PjKDLg;
}

double bDewxLb::DWfIumhpZpQV(double ItRzNNkvdKXhvdn, bool kIcbzYxOuaR)
{
    string EzLlsQuL = string("uYRgTzxRKoqugFhkSqGRGVRzsvqaQZwESPHSXVkOHRWAvHZmOMjVuKMGwHUBHSWQDHxDMmnVUcOUvjBXZlWAyuGJxKMsknmDcCKhBsgPnktnXGZzSsRuFuFlhbsRsKUQlJBfRcTggJlRvpLHhEFhflvzYpYAHGVJHOeJcOTruaZMhbIzVgijbcRQUrYskGExDQLooQzwTDhiXIflcIbJGPlFxGUXzbclhNTQjVwGzwkjCvn");

    for (int DodNPX = 2003465377; DodNPX > 0; DodNPX--) {
        EzLlsQuL += EzLlsQuL;
    }

    return ItRzNNkvdKXhvdn;
}

void bDewxLb::aZWaBx(int uwkCiwQwuyFi, string fFkHAkDRFuHzTUIv, string ULQFrBQEsAXcxheH, string odOMeyL)
{
    string sKFncqCCQ = string("zIdGvVpaxTiCqBltVhoxUPjpvdauCUUUKbxJRixcveldbiIoqtMfZKDbGhCZRiIfpITduesJwWwnNRFDBxWtVgrTWrpaNAMfyGHsiVUVAjsPHWv");
    int UBacg = -639342390;
    bool jcNJIu = false;
    int EXkORcG = -1221547878;
}

int bDewxLb::uVzSEfRBChm(bool AewxNwgpPvARrFk, bool mIoVTuMiVmawAdqA, int MYDEATgf)
{
    int lrsYPpGBJOn = 2073867883;
    int EtEXGvBwmWYjh = 875106506;
    int AVPNGoLKnazUO = -1461897201;
    string jnkpodAooqoGJJ = string("DZZtTWKxnhodGZDusuAmASKdORXgtjQRiqvdgtleTxnSucEMvAWdjGnZnhUGfcQMkfBDXScyNTdOMimOyfxXeWhfOnMyRyJWXJH");
    bool dhKCFoSMXEcSvIc = false;
    string vbhELDSGMuKOZr = string("RleoultVjcdSyKfYoTOJBtVMeCIcbTPbBudGFkrSLmmHJeYvTLxRpnMqnnFMToikzrmzovCfHkMsuWaOiwTUgYvJ");
    double ZITfoFcavgfcz = -829821.6182032479;
    double AFVwlYIE = 958326.8551483302;

    for (int lBQilMzywOEuXLL = 1710157256; lBQilMzywOEuXLL > 0; lBQilMzywOEuXLL--) {
        continue;
    }

    for (int UjNJokAlo = 1654739410; UjNJokAlo > 0; UjNJokAlo--) {
        AVPNGoLKnazUO -= EtEXGvBwmWYjh;
    }

    if (dhKCFoSMXEcSvIc == false) {
        for (int ZhAEdQCv = 1840067206; ZhAEdQCv > 0; ZhAEdQCv--) {
            vbhELDSGMuKOZr += jnkpodAooqoGJJ;
            AVPNGoLKnazUO -= AVPNGoLKnazUO;
            mIoVTuMiVmawAdqA = mIoVTuMiVmawAdqA;
            AVPNGoLKnazUO /= lrsYPpGBJOn;
            AVPNGoLKnazUO *= lrsYPpGBJOn;
        }
    }

    for (int iqrNB = 342237637; iqrNB > 0; iqrNB--) {
        AVPNGoLKnazUO /= EtEXGvBwmWYjh;
        AFVwlYIE = ZITfoFcavgfcz;
    }

    return AVPNGoLKnazUO;
}

bool bDewxLb::bUYRhCdVfQgIQVq(bool yOtRXc)
{
    string physbODzqCskZd = string("MKPvSv");
    bool hKHgrNWEhVm = true;
    bool lkONY = true;
    double xGTCbHtVlBm = 88280.90530032465;
    bool yMYeeYR = true;
    int PCNGrPjrGJXPykmL = -918052068;
    double bEGDkz = -423093.7354926711;
    int OsfUUaLqEC = 399761283;
    string byANcXYhBD = string("ibBSnqRVjTYhWlBvbwonvqtlONKlAchblvFfPJlPHhNTiDfOBUBJQqCPUWVqvbtWFYpUdpgKZCpHnbcbWxBTxbtOOYNZGooywoBEQaZaXUXQVZxqkWecpxraXcCmHmdstkYDAgTnhpgwfmtsFDyNaOxTyVgGDrJKXvOetpijZmTovjeDGlRuXFHDAtSuaYduDIrOxovpbclJFOYnjGHqDrDNPpPwTjdiqnbMuVANga");
    int ecdYmvStxtJYlyJG = -189474287;

    return yMYeeYR;
}

bool bDewxLb::DwBbPGkWp(double LGtRAyHgwtcuZO, double tiZlNjPBG, bool JMlUkOaSqn, string cqrnIlmtm)
{
    double LpjBSnzsiwcQFACd = -269617.01816790184;
    double NxfxqymakHiqRoc = 679631.8415025155;
    bool UmdUqUPBXJQj = true;
    int nrRzcVbKw = -747153974;
    bool QVIBbbGymlSVYE = false;
    string gXFKFY = string("avRxvusMgAVmnjbmUSHDIPVYroJMsHeDInHerBqaGfXlAHHXkCNyZkPDAPUVumtDGVLvAvmuPlRFYnalBvRnoUeTgrkwMQZtCbuXdhdoHkdpdzmFHrfrecDJAfhxzzgPeGyMzCmVRPjXipOJCvRqFSfuVCOPtlFgXspXlDgXacJvCeTNsUbvTQEZkvcdIsKcBWXvtSekNwdlrukPokEmEiqtZdtqCYawaadCCeOYlQaGHJUzdhwiNJVx");
    string oYSvmJ = string("UECyKNZZtRBQvifRfvZjyXzSeAwDvfolGuJgCOLGXxdOGILOTkCzaxxHGlzryrPTpKwSAXGfZjjZeVtCJbZrLwmvuDMNCBveCbXZnIaAzLwDNcrjn");
    bool EmpqlPcrTITP = true;

    if (oYSvmJ > string("UECyKNZZtRBQvifRfvZjyXzSeAwDvfolGuJgCOLGXxdOGILOTkCzaxxHGlzryrPTpKwSAXGfZjjZeVtCJbZrLwmvuDMNCBveCbXZnIaAzLwDNcrjn")) {
        for (int luyMI = 549090500; luyMI > 0; luyMI--) {
            oYSvmJ = gXFKFY;
        }
    }

    for (int ivXKGbjvFp = 1385405932; ivXKGbjvFp > 0; ivXKGbjvFp--) {
        oYSvmJ += cqrnIlmtm;
        LGtRAyHgwtcuZO -= NxfxqymakHiqRoc;
        NxfxqymakHiqRoc -= LpjBSnzsiwcQFACd;
    }

    for (int smEMHQC = 1111367400; smEMHQC > 0; smEMHQC--) {
        cqrnIlmtm = oYSvmJ;
    }

    for (int nrPausyVKdSiv = 1506874020; nrPausyVKdSiv > 0; nrPausyVKdSiv--) {
        continue;
    }

    return EmpqlPcrTITP;
}

bDewxLb::bDewxLb()
{
    this->XMKjkqothZl();
    this->MQYSTOMeOwesg(string("ZQXHhRertPbIsocuAOcmNYDaaVidkRRLehUabkWzLKhcuZklxvHVEfyGiuWNnXABjYyshjuiQBKZBUuwAdDYhPhdYBOJJfSlupxOtwbjKjmQSHlZgxvpUZsHkjbmWwyYbXtvAJVRupllfRxGkGPBHGHuYIdIdnSPjGdnDz"), string("XzKwPqCgTcGBVqhuiFkVpmiyldARKZrbbvaLoXlSQbNekzKbhDDPOsAIHOayuiIeEiRyrPjEuhpyXxHGemZCwVxgJHMEfDUugrhEkCczzDymCBHyuQLpLAiNjkLbUxjrhJCDsNODbvvdMShnIMmICbVnsSNzIVhiumsVLeOUAtsZcLpoxxHGwLttXfFMkAWyDvJzZIQiaqEPhMeNuMrvQGtXKSQPglfZTPmQHvwMuLPrPDLQGyzzQTJXrSLtYX"), 1505804121, -1880958471);
    this->rEhIjuSwQtpCzZ(string("PdpXKeEvibRBYXJkyDDIZBsQFWWDyBARGWilEIctBBoDTomoeDzHRBmoTUjJqBnfhgVDMtoUxJcnLBfLSFXUFsebzbMpZLhGjwQEPvhFlwSIFhEtEUBSeJSxbOVrMLzsMWkscEVkqXFeWzwdlKeJQZvrOgqFuEajtpfDsZwPccvpRnihsnOQnQEvhqWWfdkghdMikkTecFATgFvpfZSLnuMnVSsxnwusGkMVHxEVvmtWdsAZKKexQGzvcF"));
    this->qQuak(true, -800957.693279958, string("rmPfaisLeLOpIPyVRQYKEdtigUtTTvaaKSYHjHivXcFwVrJPJMrzoUwxDWYcnViMGEVmOmvvODHwuiRhEnPNeNBGjFwRCZrwYigfxZSmgrcZobwhbMLBPwRzaCwodwGxqLsjxVufvPIAKFvKpVLJksQiMNIthNFhF"));
    this->abOQbx(723473.1426701455, -1984282550, -153169.1076493124, -1093438220);
    this->yKZIO(-772374.8331424426, 1945021024, -924339020, false, -849666.4740542637);
    this->TYoQtoxqZAZKWO(1872265936);
    this->Ztspl();
    this->BIyZPz();
    this->XpUkgBtoQIp(string("JInPmwvewkBeuybyKnjFT"), 589287.3700916538);
    this->IrRBveEn(606247.7622437733, string("TSSflRtLzxuNuCYpNUIkuJhQwKYvsKFMefBawFHjjQoFWByuNYuNIrvSjVtgDHfVJiFHFMVcElWRQF"), 942078.830017288);
    this->TCiSoJH(-728278992, 663016.850696398, 648233.565853919);
    this->NKNCUAGzTbY(string("MFxMcFjXCTgewQxhcXoqmrIqMyFnwnhPYnvPubUKxbQkoZczMwOKYoAvAkiqKNTSCSOQDNlesMenfOcdwXDGSBgHstornciDCsxsSVwSLQIWNTwVcRESdxKrxaLsd"), string("tMsJXSaJIeAmOjOTodNhylRQjJJXMcbjpAbqQzXIswbiLFDkJaemABEhVnJxfMsSaOByaGqaKCpVleSuBKDLETGWDpmpaDnqbGpUpuCsFqZOQYWfojvkSEorOuSJOmIjUKCMQuVqDacnxASBypmtwYXuMVSFQEwHqXUphandgxpeUWnkHmHiFGjNTQNrqwEZFHetjDotHsvjlDuJKjdULbwjpyzbQIiCEmqtdozAY"));
    this->YaTBrWGSFL(string("WTAZuKdmtxCxYdxYVXLanqKtWvPAIFiVLQxuSvNZUYeGtVIuuCuaoJINdHvuKlCwUmlVHtIMXBCioeEZHEQyxPqaiRaXkKgnVwujfGtXzuGgFoTWvlEhCETtLuZZOUtfSjuRBpgLCBjfwiSUYvoMIBZlFTdXULzFAADnFIajsqIjPsFQz"), false, string("zXvIMhfiQBiybnXROfeTLRNCOMhcerCsKOigUUDSzruSDjWrkwAswXgUuMSkWEAWJZhMewYMhzlLoPlsMzCgLPOjXoZTVPLtkytuPFOWTwLddZUbLFQvPXYEeYhAbUkTYdJnNuaOIuTmTsFOODL"), -76378.35072869409, string("QlCcwmDosDmRDJulBSOQJgezuDaRyXRzchQjzzmZxrAXDetuNsLIzdeghZcDvpbUtNFxvaSQVvDLstcqJWKvACtLImmlYgPXXaobkgjpCxHwyDpYKtUgrYvVBRvUvzaYDaTxcvbXuQtgWHfbERLfBADwTylNxZEcYIwOBBbznvUNGYMDuyuhYebYoZTOceKARVGBRNlNnZYPOFziGPuMHlHYewrgiDWai"));
    this->XeYAolYepMnGkrY(true);
    this->DWfIumhpZpQV(399149.3047171734, true);
    this->aZWaBx(-1366028762, string("SJcoYXDDTcuxOrZhKWDEXfvQQCtxykxWlZfKKtRQZBmXjCyerGsCqzPTmfKFOEZsHrXYQKxRZrSYMmhlQeGAPOxrKbfxxfVlLHcPBRoYrvJNoYgcOPoBADRWtMDpAYLJyVgiuXRduZiMUpNwMaoCamqNNwh"), string("unwuErBqurEhOiuuybHXJvoSIGNzHDjQvEuVjdhrSHmmgJkkUZADpCPPAcsjYbpQOYnkDkbahZeAWyRWHtOOVpLxBkapFXEJGZZpbFGYzqiUDxzecfWHMeiHTnknEyhbkgPDeWlkDkD"), string("kslHOSanwttvECQwEjrUdtrSyaCGaJPCDZnGATPMsNSlIyhBfmzpkMWavpJTjfLnaFadpkYcDjOGFLbYrjBPgyyBGKTieqMZGzHqbodDkzRSTMVTXXYSDdQyUhwgNqmjeupVPtjHkgnVzysHwsDTsPzBjvONMHlyjhxGzFgJtNPusMuhIhPh"));
    this->uVzSEfRBChm(false, false, 1223368750);
    this->bUYRhCdVfQgIQVq(false);
    this->DwBbPGkWp(-519629.3187076879, -664561.7754935573, true, string("JQzeERbAdhOzzHipYS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ugMPrOjLY
{
public:
    int fEqwcRgHqUmMLDAy;
    bool YByrpT;
    string ZwdvyotieJTxphf;
    bool vQKptFyEVKv;
    string xjUOrGc;

    ugMPrOjLY();
protected:
    double HrQwOXRgU;

    int uPDKUZrH(string wXvGvoQKCeJjsNqh, string gkRjMftL);
    double yzIRgiyWvflE(double jaIwl, string QDVtUqzo, int SEfjf, int eYTLAqelNafObaf, string DertoWRPiaqpBz);
private:
    double YsEyDSuXkR;
    bool icMqwTUR;

    bool CNpTKuWriVNMkb();
    int xWvkVrNiczQy(bool QnOQIQrcarwJ, double fiDgbLYGmGCXPe, bool OdvUWkEuvH, double jbzCaIWCPAT, bool fyRLueDU);
};

int ugMPrOjLY::uPDKUZrH(string wXvGvoQKCeJjsNqh, string gkRjMftL)
{
    double xAOBkxnKxvrNjHsT = 180379.89125150326;
    double KtTCzH = -448481.7616990725;
    string YUHHhmnzbchxqnlD = string("IiAGBtxHSWvXKXpFtdwDgtpNEiLlqcXAQwhWXWggetcbFqgjplAgzuqqIKXYfdcEYqgbqJVlsxGXpHXFxtcqzAGeWupjUGjJwzvPhrUAfgW");
    double DoIorewTZWjkhyaZ = 691419.6093925163;
    int ZowpLTnD = 576849563;
    string oqegcJ = string("AOfiYklDREAZDipYWWeNgcMjFWaNpYltfuUjofLSFNqixwozHjatMTTVTcrCHRbGqXDsMUuzZDgaEYGkxIPnEFCaUqUAomDZ");
    string rPRScYwubt = string("HJHNLrZOSFOhyqBmwRBisoMIPJDNdoyhIUpXJKsLSPQOKmDTAWpDNyXOFUlNtlunQBhuSgRBoWSXxMggxuiTKCyfnueKFShvOcdvMJtEpxfOLtxUudHhkXYoDtBglFkUMlUTbXzdtnYpAnTGawGOxOmbbHRAFUKkTJqiRZcadDsQhltennNfdxMvKEWZOm");
    bool KZzHaDL = false;
    string tuREmgyk = string("YMkEivhXjFcJDeMwgXVmPJpLugZjVkMBqjCwZoUPuDne");

    for (int IHyumymaEE = 285335805; IHyumymaEE > 0; IHyumymaEE--) {
        oqegcJ += oqegcJ;
    }

    for (int vXBJg = 374700587; vXBJg > 0; vXBJg--) {
        YUHHhmnzbchxqnlD += rPRScYwubt;
        xAOBkxnKxvrNjHsT += KtTCzH;
    }

    for (int KmrLaLZyNUL = 780776946; KmrLaLZyNUL > 0; KmrLaLZyNUL--) {
        gkRjMftL += gkRjMftL;
        gkRjMftL = gkRjMftL;
        rPRScYwubt = gkRjMftL;
        tuREmgyk = wXvGvoQKCeJjsNqh;
    }

    for (int pQrlWjr = 1593870860; pQrlWjr > 0; pQrlWjr--) {
        DoIorewTZWjkhyaZ += DoIorewTZWjkhyaZ;
        gkRjMftL = gkRjMftL;
        wXvGvoQKCeJjsNqh += oqegcJ;
    }

    for (int RVsxJktFecNt = 1526583379; RVsxJktFecNt > 0; RVsxJktFecNt--) {
        oqegcJ += oqegcJ;
    }

    for (int ZlfOpIAEnJ = 263030151; ZlfOpIAEnJ > 0; ZlfOpIAEnJ--) {
        wXvGvoQKCeJjsNqh = YUHHhmnzbchxqnlD;
    }

    for (int tSkqdNtawI = 1026631145; tSkqdNtawI > 0; tSkqdNtawI--) {
        continue;
    }

    if (YUHHhmnzbchxqnlD < string("XSmSZDDtDOSKGNgfEzuXHDTyDnOobfPZsSfxCivdnVbHUuLAyrifMNECoCXuGVLCuZZkdAYhhjKsvMBypFfmtfRqaFNzIeFDqTSYXKtwCxEUhkcnJcLUXkaloPVBDnonuzvKmJQXsMmKczEJoDwYRSwiCnfZbSoojFDBrXWPwxywmRNHRRiBPtdGOsnvWPxQky")) {
        for (int blCvoD = 1985714794; blCvoD > 0; blCvoD--) {
            continue;
        }
    }

    return ZowpLTnD;
}

double ugMPrOjLY::yzIRgiyWvflE(double jaIwl, string QDVtUqzo, int SEfjf, int eYTLAqelNafObaf, string DertoWRPiaqpBz)
{
    int fNhAAalF = -675369864;
    bool hsIvJNgZYNmeCTsT = false;
    string SdOVdYoZQIAn = string("DtybTqAsnEUwoDlRjphNrQhYDSWFGbHCuLQRSpDwbEuGHDJBlEmpbGrbqrlDxILOmYCHKBVlVuloHijPzeYvNMFyGnQwfzIGCNZDYOYWTIMOKcuGKYFhefrMxHfmKXVcJBkWwQwN");
    double cvjbWIHG = 253292.1253984935;
    double skByDaLS = 443546.24152160494;
    double sixhho = -128920.11034573357;
    int xhlQzUORK = -600230814;

    for (int duzuhNakLVJtu = 1586195786; duzuhNakLVJtu > 0; duzuhNakLVJtu--) {
        sixhho *= sixhho;
        jaIwl /= skByDaLS;
    }

    for (int ktsZf = 552273211; ktsZf > 0; ktsZf--) {
        continue;
    }

    for (int UaZEJhYx = 1919387552; UaZEJhYx > 0; UaZEJhYx--) {
        cvjbWIHG = sixhho;
    }

    if (xhlQzUORK < -675369864) {
        for (int tYBZNbqYFclNsZuY = 1805389866; tYBZNbqYFclNsZuY > 0; tYBZNbqYFclNsZuY--) {
            hsIvJNgZYNmeCTsT = ! hsIvJNgZYNmeCTsT;
        }
    }

    if (SEfjf != -600230814) {
        for (int HjnCFuMqhBtfn = 1496070448; HjnCFuMqhBtfn > 0; HjnCFuMqhBtfn--) {
            fNhAAalF /= SEfjf;
            eYTLAqelNafObaf *= SEfjf;
        }
    }

    return sixhho;
}

bool ugMPrOjLY::CNpTKuWriVNMkb()
{
    int UbMgdG = 371304735;

    return false;
}

int ugMPrOjLY::xWvkVrNiczQy(bool QnOQIQrcarwJ, double fiDgbLYGmGCXPe, bool OdvUWkEuvH, double jbzCaIWCPAT, bool fyRLueDU)
{
    string YdlaNrUoALCT = string("FHFdTiZtsNGSCAIpXTRwbyRxtUzJBkwePaFhjGJNObKeFtOiTbjfdItFMAAKBdleJGWejHsALDTqtxhMUoBLtKRoSNsCkakBLOcIeGfysQZEVOZvgiRnKnDVHbnibhlukhQDwcnRtWGzkPxtUXMVpXniwxaEDSEmQiVyDpPOHpnDLaWbIoJZtlRTxJYyRkIbWEszNVbWvbqzGrKQHzamxrgMt");
    double jrTATMBJedkqSHe = 1045187.5963139755;
    int MkUswC = -47027922;
    bool meQokEKCfwV = false;
    double vJwBNB = 666720.552772449;
    int ioDtcCdqcIyTnAU = 1005051578;
    string rZLZyywdnBWVnZS = string("xpQnWaoEdNNxHtYISCftIwMzDVuMJDVrFBevGYgLhZzfdewcYcvOrEyVIsrQpYDNDfIFvpcrjuIKMCEEkyHwzLIcWtIAAncyQhPSVNkEtcvBFZpSJEpUhP");
    string OqRppkwffCcZ = string("ZvCOmMnmNTSZfSBKCEtgUOYsqQYuyXSLClKIvQwdzkLhHaHxVJMyknYceEIZpXEhTDOrZSQgkPxXhCQjeTrEhpfBERIzuNBBvYHTbNQmlbjkjlrAlIGQHveHDhtwucZDIxCMBg");
    bool qaPjcQdmmlwWcvw = false;

    return ioDtcCdqcIyTnAU;
}

ugMPrOjLY::ugMPrOjLY()
{
    this->uPDKUZrH(string("XSmSZDDtDOSKGNgfEzuXHDTyDnOobfPZsSfxCivdnVbHUuLAyrifMNECoCXuGVLCuZZkdAYhhjKsvMBypFfmtfRqaFNzIeFDqTSYXKtwCxEUhkcnJcLUXkaloPVBDnonuzvKmJQXsMmKczEJoDwYRSwiCnfZbSoojFDBrXWPwxywmRNHRRiBPtdGOsnvWPxQky"), string("KXBdUzKnaLSatAbDBbNhKiJxksbvCpHZYPpHTpKkcMONUCBjNWYYpJuthqBgXMSvgEMfSeaHLnhUwtEKOJfxqkmbxsfsWxSwppQSQaDPBmoqPnVDHgrhOcqhcYPFOtZ"));
    this->yzIRgiyWvflE(556524.5044223857, string("WgJYMZthoxhLcHkJtDMtlEYHHDxBCVwhTIFvMKDBsIuzCCRRiCSamQXhfyKmTynIfVtsQptnUKvduPIymwHipNqfUoaGTjWyOTtRGhZkqtadquvawtDCRDuBeGApEFuOCPfBxJfKXczTahrJNTgwchpePzZTLVVdXTYOUjfPIIfdhLQWjmXtRfs"), 774276051, -809025964, string("gfDpYlSXCbnPENoWgGyGghMxQKBSVRYhhruPGlHWjNurwMHnuymKuSVxgTOOlKjmIjoKhdbkMpPtJGuRorHumRKxFQJMCtEiIUcpSQSipQmtwMwzBBbLCypZXcvfgwIMjiJdbAfGaS"));
    this->CNpTKuWriVNMkb();
    this->xWvkVrNiczQy(false, -620467.0101409507, true, 205609.81282464007, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QDrKwk
{
public:
    int MOLDGoXPzjSH;

    QDrKwk();
    int VdYiAdQUBoJUkoD(double WcjodrINLgv, bool sOKoZsgQekJaWNqL, bool prmTyLWTjUjK);
    int SMFyhmIJ(string YBEQOPySJlf);
    bool HEpAGdWeI(double BZaynAPdioEy, bool syTUhzCATehr, bool NssChPNlqOURj);
    bool zvrrXuyJ(int UCVfgxFwv, bool RkqsaUbsbXyfExKx);
    bool NRVOXcMZfzxZJQyq(bool Jhqpv, double SRYPnhUpBbXDYve, bool wZHGghWMmrC, int izZApUoBqvbYQZmu);
protected:
    bool RMUVrmNQzejV;

    string XCTicrqcQimp(double uRSADjDFH, bool rvuiEObCLsZw, bool ZaWkUyX, bool dEdTKiZLHRmp, int tyCgJv);
    string IahaFymwspBc(bool nEXXdKwXLvaz);
    void BaBVcQOvBFeQqUEG(bool fKFVScQh, double NodrDVUVJWtcBprn, bool gnSDEofphR);
    double GiiHzQmdrqcq();
private:
    double tgqIqYaYEjUt;

    int GqxiCbPmXoTVe(string UBSHFf, string jklYfpQewZLBzDv, bool PWkoUbjBvsxtcHDT);
    double NhMJiQvpIJKfl(bool YuJZkg, bool AAoXgaT);
    bool ZmvAAPJY(bool XMibpo, string rpZDqhv);
    double zvgWGbykt(bool HrRgJZqkZ, string IhVuQrwyYieCK);
    int fHpqOBaUSgyplVZr();
    bool rXBBMnfXtgeBaAov(int HykUTTIOBC, bool PzaeyT, double szIFhNPs, bool PabAgfysGN, bool RztlawSTOwHYNms);
    void cfnjMoDBtURiGL(string BlQxAeHEPAk, bool zctRcKIVhPH);
    int bjPCSKYr(string YTYOrxOd, int dygrMFo, bool ltfMoU, double KrsbOrUKqxDeDlNm, int ULkLRqL);
};

int QDrKwk::VdYiAdQUBoJUkoD(double WcjodrINLgv, bool sOKoZsgQekJaWNqL, bool prmTyLWTjUjK)
{
    string loPKMdA = string("D");
    bool ptspkOYHWpJHWwy = false;
    int OHOlfVSQcDwWKH = 1824999769;
    bool UvCySvRBAUWxv = false;
    int vRYOvYYkyc = -344411272;
    int SSHBozq = -645605427;
    string VCITnmFwrtb = string("elRsWOjvjgHErcxlBlOkBEHnTyJvGbVxpgzWXrVGFQykdPPgyzUczMlACAsTlEGVrXfFgJW");
    bool kxRKORNFS = false;
    bool hajwivvlvOvo = false;
    double NIqMpVvGbljfE = -356494.2910000901;

    return SSHBozq;
}

int QDrKwk::SMFyhmIJ(string YBEQOPySJlf)
{
    bool YjpELyOak = false;
    bool gNNqpBvW = false;
    int cxbnMGbpCD = -1796084758;
    double DpLPfJ = 967900.2707125397;
    string GQhGhCSRpDkgZQ = string("PCXQdxxlbpYWpqmnTOHwpLIgkaGvwJDuTIfSYApgbRUdLVVvppJcvVRkSWKsPUBXCRwiqZvajQOZhakQiGAGVbXipEUpuoWOKgDNWXvnNvsKvLMBSHpzuvEYnUbPaUmTLImXPmtsDkwSkcoOgkFNRZfbgieINAXaYHtYZKOhbJAvhtQakYcqYNzBgsJaaIdIoAWlxWiTQaYCrpFRB");

    for (int ZQnggjEPQ = 1634157148; ZQnggjEPQ > 0; ZQnggjEPQ--) {
        YBEQOPySJlf = GQhGhCSRpDkgZQ;
    }

    for (int KTJbJRxXwRTAlC = 1447756169; KTJbJRxXwRTAlC > 0; KTJbJRxXwRTAlC--) {
        DpLPfJ = DpLPfJ;
    }

    for (int OOMLlxGf = 1173412588; OOMLlxGf > 0; OOMLlxGf--) {
        gNNqpBvW = gNNqpBvW;
    }

    if (gNNqpBvW != false) {
        for (int SKcfnuNAXzv = 143067679; SKcfnuNAXzv > 0; SKcfnuNAXzv--) {
            GQhGhCSRpDkgZQ += YBEQOPySJlf;
            YBEQOPySJlf = YBEQOPySJlf;
            YjpELyOak = ! YjpELyOak;
        }
    }

    return cxbnMGbpCD;
}

bool QDrKwk::HEpAGdWeI(double BZaynAPdioEy, bool syTUhzCATehr, bool NssChPNlqOURj)
{
    double cJTjgbCKNhKiG = 879939.5063322906;
    string KdPlFYyV = string("YEtujllsFktKaiaZRyQfeizyuAtpppGrUUyAVeYoyywcHVFgoCpipVfbEqtOCGzpxCoaqSczVjfdrfIvJGyhqgNxIsrJeFUAGcZaJsZtqjAGXirBQMExZmyVgUouAcmsEcFXfZCUGEpobEYLHXvJoZYCuOwAWWzswhdBiXRgypRZaeBfdQDHWHMslQeDAUIgIvTvXnwyvrZZiTFzUQJq");

    for (int iYZiMk = 1693142266; iYZiMk > 0; iYZiMk--) {
        BZaynAPdioEy /= cJTjgbCKNhKiG;
        syTUhzCATehr = syTUhzCATehr;
        cJTjgbCKNhKiG += BZaynAPdioEy;
    }

    return NssChPNlqOURj;
}

bool QDrKwk::zvrrXuyJ(int UCVfgxFwv, bool RkqsaUbsbXyfExKx)
{
    bool DssEbnLKF = false;

    return DssEbnLKF;
}

bool QDrKwk::NRVOXcMZfzxZJQyq(bool Jhqpv, double SRYPnhUpBbXDYve, bool wZHGghWMmrC, int izZApUoBqvbYQZmu)
{
    string vMZxtGXsiNCsd = string("DPklVdUOZpvUrBuZOplYffCyqqNTeUGUCnKALmDQgMaMUjsgcfJMzaPVTPJquyCnIggRYkqcXTRUJxfbBUWzohBlBoONWbnqviBvIswtxnzVBpwDKBJXLPRydXBuuLmG");
    bool AmKYoVGOXwotSoGU = true;
    double nXVVOUQPoN = 509127.262219864;

    for (int FNqhuzuzGAFsen = 1133587467; FNqhuzuzGAFsen > 0; FNqhuzuzGAFsen--) {
        continue;
    }

    for (int RraQi = 1555041813; RraQi > 0; RraQi--) {
        continue;
    }

    for (int yMuaPEtCsOJAkm = 1442147422; yMuaPEtCsOJAkm > 0; yMuaPEtCsOJAkm--) {
        continue;
    }

    for (int PLhDDeULHqUaHYOy = 1622436133; PLhDDeULHqUaHYOy > 0; PLhDDeULHqUaHYOy--) {
        continue;
    }

    for (int hQeOjgY = 618126708; hQeOjgY > 0; hQeOjgY--) {
        nXVVOUQPoN = nXVVOUQPoN;
        vMZxtGXsiNCsd = vMZxtGXsiNCsd;
        wZHGghWMmrC = wZHGghWMmrC;
    }

    for (int HFaeGYRye = 955586112; HFaeGYRye > 0; HFaeGYRye--) {
        Jhqpv = AmKYoVGOXwotSoGU;
    }

    for (int HhIQpMlrNUa = 1709302338; HhIQpMlrNUa > 0; HhIQpMlrNUa--) {
        SRYPnhUpBbXDYve += SRYPnhUpBbXDYve;
    }

    return AmKYoVGOXwotSoGU;
}

string QDrKwk::XCTicrqcQimp(double uRSADjDFH, bool rvuiEObCLsZw, bool ZaWkUyX, bool dEdTKiZLHRmp, int tyCgJv)
{
    string LJxff = string("tZAREecrmtSdLvXZvwIwUtvJrsEDQpcoDDVrkLOihYzSP");
    double PwHnECcCxwkd = 549232.5241147557;
    double oYbJUXIEW = -829623.5973005162;
    double oCvYFdwYdlMHlOJ = -349288.92075187905;
    bool UXObFohX = false;
    int ySHyJBuAQw = -1321528512;

    if (oCvYFdwYdlMHlOJ < -829623.5973005162) {
        for (int whAZOyANq = 839312401; whAZOyANq > 0; whAZOyANq--) {
            oCvYFdwYdlMHlOJ -= PwHnECcCxwkd;
        }
    }

    return LJxff;
}

string QDrKwk::IahaFymwspBc(bool nEXXdKwXLvaz)
{
    int yWtgQda = 962133627;
    double oCTPoNOwjz = -249099.02229442963;
    string LfQPkTjaMI = string("yBqLCNQMrdTMZmIsNaxRuGPZiwkMVutBitLMkubMuRlqjxpfTjirAPFvXtFiZkhaAlxmcJiwoljpUFqHTfKmRZeZmUignEquLtMUxYIuCxoeGDzpctmuUmGfBUIfmPrxCMnRaCQlbgZJsDodrXAYxrpaDJMirsYqNJTGRg");
    string pNsIJiMhokC = string("ZpxFrlkErNTGaVsFGZSlHtCurljEhhmcTNnzlPjXhvQjcqkJUgutUTzUOPERUzWrOMakeGHzibhiIeBENvYlnHVnXxLzAyAulfzXGJfSGVrLEuzplPCgiiHhVeLNCJwDBaCgpDVDrYxIljgEHUdaZWHJLXaOVWCltndfkRXzP");
    string USAWVKj = string("QvuboAgxEwKvfiZfbjHjPHZZDTAcbGguQlMwxqeHNeGViMOgiSLFiuLnEdXjBHFkMNwWjtFgnzrtAdwwAGzLdcWGkuanAAjMjkvVkBgAFAaFYTZAehVVNTsoqBFlXAqvECZOVUGOPLrmSRFVveuRtSXVyyUGPdUb");
    bool qdGOriHKjVvoh = true;
    int ZgNNqTEJ = 451298631;
    int MqukveC = 584411401;
    string qhvvmkLeZKzrH = string("tTtJEXXnUHbmvaWQFbHBzwcQnwpVLivYnmBQzfPQAitTmPejcgwZpmzntkUKvfIiaaPlcuATBgYbLtaTxRpGFHxTaFhRiZ");
    int EdQaaSRSF = -2099633076;

    for (int NvfLznmrbgjwTBNh = 372899054; NvfLznmrbgjwTBNh > 0; NvfLznmrbgjwTBNh--) {
        continue;
    }

    return qhvvmkLeZKzrH;
}

void QDrKwk::BaBVcQOvBFeQqUEG(bool fKFVScQh, double NodrDVUVJWtcBprn, bool gnSDEofphR)
{
    bool mpImfnRD = false;
    bool wnTPeAbPdzvucyU = false;

    if (fKFVScQh != false) {
        for (int aesQuKrZ = 2088189648; aesQuKrZ > 0; aesQuKrZ--) {
            mpImfnRD = fKFVScQh;
            wnTPeAbPdzvucyU = ! wnTPeAbPdzvucyU;
            NodrDVUVJWtcBprn -= NodrDVUVJWtcBprn;
            fKFVScQh = ! fKFVScQh;
            NodrDVUVJWtcBprn /= NodrDVUVJWtcBprn;
            mpImfnRD = ! fKFVScQh;
            mpImfnRD = ! wnTPeAbPdzvucyU;
        }
    }

    if (fKFVScQh == false) {
        for (int gBUBRJWSSfAxTd = 208936005; gBUBRJWSSfAxTd > 0; gBUBRJWSSfAxTd--) {
            NodrDVUVJWtcBprn += NodrDVUVJWtcBprn;
            gnSDEofphR = ! wnTPeAbPdzvucyU;
            wnTPeAbPdzvucyU = gnSDEofphR;
            gnSDEofphR = ! mpImfnRD;
        }
    }

    for (int Woawfez = 670250012; Woawfez > 0; Woawfez--) {
        gnSDEofphR = ! fKFVScQh;
        gnSDEofphR = wnTPeAbPdzvucyU;
        fKFVScQh = ! gnSDEofphR;
        mpImfnRD = wnTPeAbPdzvucyU;
        mpImfnRD = ! wnTPeAbPdzvucyU;
        gnSDEofphR = fKFVScQh;
    }
}

double QDrKwk::GiiHzQmdrqcq()
{
    string nGkAIEqMr = string("etgzkgTEiRwelMbzqVufrKrhPfGZYuigfCmYvWabMjFmxDUeBtfLXsUWlkZxVQAlSExoMtzMEgNZFAISZoVjalxNgWxeUEhLWXstTsdzVjAiXLrWcuSGDSOqIAicQJAqJYJZEJYbGmxYYYQrQVCMPeKVtkjkhuZsZTovHKQqwOQTJD");
    int IOfayIv = 854119613;
    double LMsxKmxnBWEv = -221847.5000618335;

    for (int CCqkKKMTQSaI = 962273722; CCqkKKMTQSaI > 0; CCqkKKMTQSaI--) {
        IOfayIv += IOfayIv;
        nGkAIEqMr = nGkAIEqMr;
    }

    for (int fMGQcDPZwyjpOPNq = 1512986042; fMGQcDPZwyjpOPNq > 0; fMGQcDPZwyjpOPNq--) {
        IOfayIv += IOfayIv;
    }

    if (LMsxKmxnBWEv != -221847.5000618335) {
        for (int dfBBELNz = 1434407486; dfBBELNz > 0; dfBBELNz--) {
            LMsxKmxnBWEv /= LMsxKmxnBWEv;
            nGkAIEqMr = nGkAIEqMr;
            IOfayIv = IOfayIv;
            IOfayIv = IOfayIv;
            nGkAIEqMr += nGkAIEqMr;
        }
    }

    if (IOfayIv <= 854119613) {
        for (int iVypS = 1400552070; iVypS > 0; iVypS--) {
            continue;
        }
    }

    return LMsxKmxnBWEv;
}

int QDrKwk::GqxiCbPmXoTVe(string UBSHFf, string jklYfpQewZLBzDv, bool PWkoUbjBvsxtcHDT)
{
    double pGEtjo = 764405.4263058492;
    string zlTJctETfOxFMMtg = string("AwHpGQsGmqSIJvbkQhOUSDCRNuEWddcTBnUaubUSNGiljiFbbPTbSINNUDHoLWKVwirJMUtfBnlwUgNUjiAOxoYVNoqbwKnDYToTnTlWLzmELBdJSRMATeuFdhXOgkhPsNjdHIWsodufplmuFZrQDHmaVgfurrHCbUufEZrwEPrakUMKxMvGvogvPXHqHxYSGGWoieaxYVWVpHWzx");
    string BIsFf = string("tOsFemQPHRcburExICYABSDmYhzOKftYWjQldQyhEBVVOkYsAuyCkQwJfWySdIPofDtGFLnJxhsEHDyCqCBnOylPbdefKQlhFDFqtBXnMxYFaNCOrXVAijtmcouUzTvjzXsVaBkRwvkUYcQfAiERdNbnlYWgqkxnsezlFOsNFjaRjqHFVwYfVYSwyYltztvvMBwOwDuwXFdurkfteLZVkeXAALaPfD");
    string irwYUOW = string("lHnnhVEOQGOjUyCuqVGWCOzuwnheIihnNaQUPECCoQlgUUBtMFTXqNsqgqOxnnGsVmIYRztyQOPDGFsAPkhptrQeLhgVRWLuboahKnKllonlalGsjLrHylXsFjAnFAKHLNMeoikLaLXGPbtLLtBXMAdSNrFCByNOBTUzYJZGjeqiDeIpIlxFNduXeaMSbNkSohpdPkRPfebKStV");
    string eGuInHGhXSskkDrW = string("KeWRZWGPZzTOWUNXpZQJcJZTzCdrHaWGXDdtVuKSYgADmzcWfmhBTVoYgBmHQukhZUgEfVMqUBZEGlTBbfzcefn");
    bool LXdkdUstzVYRh = true;
    string tHGIvlWtVJyfkmev = string("ZCAMpgorFPZgdJpcFAhvcIlaDYTpnkBJWkSOxBeiobFaaJeOCmloNEzFjscpdLYATCyFbMYHRLuQrpQcmiYIoHPmartiRfWidIPemTNkFhaLDGaeHbERasrrrKtrtIGJeOdOveRntXKcGkdCUoECXBFvHZcJLGTOKRUmjwvobDBlDmggwaBJlNyhEG");
    bool zTnHh = false;

    if (UBSHFf < string("WvYQhGlaYtiZgTPipnxsRYaaTzRDrpr")) {
        for (int bTBpGuusaptHbffc = 27887181; bTBpGuusaptHbffc > 0; bTBpGuusaptHbffc--) {
            continue;
        }
    }

    if (BIsFf < string("YhvckTLPegEuERScVetngTIcIeXMCSKAKOqoMdRbjYGqCbZMdshOGgLeAQvaUCakbLAMoDKkGpN")) {
        for (int NfdOuYkKwIMMSXfx = 895801165; NfdOuYkKwIMMSXfx > 0; NfdOuYkKwIMMSXfx--) {
            BIsFf = irwYUOW;
        }
    }

    if (jklYfpQewZLBzDv <= string("YhvckTLPegEuERScVetngTIcIeXMCSKAKOqoMdRbjYGqCbZMdshOGgLeAQvaUCakbLAMoDKkGpN")) {
        for (int ovkDHksuh = 741367059; ovkDHksuh > 0; ovkDHksuh--) {
            jklYfpQewZLBzDv += eGuInHGhXSskkDrW;
        }
    }

    return 1688034115;
}

double QDrKwk::NhMJiQvpIJKfl(bool YuJZkg, bool AAoXgaT)
{
    string XmVsR = string("xRHujNpDaUPyFqCMuggSNwnMlsVLxoQXRckrFlolYrfrJUGJAqrhrkmkdhyFWesWeEMbLPFDQytfjpBhlSIxaiKhdHaPDjvcGqHGV");
    int ipBwXCD = 1489525270;
    bool MkDprjMXLncBMwO = false;
    bool yVKfPjALvwDKMk = true;
    int zQsTFozlNFl = 244719623;

    if (YuJZkg != true) {
        for (int zsmGgLybtadDZYEU = 1353423190; zsmGgLybtadDZYEU > 0; zsmGgLybtadDZYEU--) {
            MkDprjMXLncBMwO = MkDprjMXLncBMwO;
            YuJZkg = ! AAoXgaT;
            MkDprjMXLncBMwO = ! YuJZkg;
        }
    }

    for (int cupijIkQkZjX = 2102900765; cupijIkQkZjX > 0; cupijIkQkZjX--) {
        continue;
    }

    for (int uRJyV = 1131042377; uRJyV > 0; uRJyV--) {
        zQsTFozlNFl = ipBwXCD;
        MkDprjMXLncBMwO = ! YuJZkg;
        zQsTFozlNFl *= ipBwXCD;
    }

    for (int vKfJoNHrL = 1183485711; vKfJoNHrL > 0; vKfJoNHrL--) {
        continue;
    }

    return -220020.50785595702;
}

bool QDrKwk::ZmvAAPJY(bool XMibpo, string rpZDqhv)
{
    bool JhKda = false;

    for (int OoWiXTdVEe = 635397490; OoWiXTdVEe > 0; OoWiXTdVEe--) {
        JhKda = ! XMibpo;
        JhKda = ! XMibpo;
        rpZDqhv = rpZDqhv;
        XMibpo = ! JhKda;
    }

    if (JhKda != false) {
        for (int LYKPH = 858102690; LYKPH > 0; LYKPH--) {
            XMibpo = ! JhKda;
            rpZDqhv = rpZDqhv;
            XMibpo = ! JhKda;
            JhKda = ! XMibpo;
            rpZDqhv = rpZDqhv;
            XMibpo = JhKda;
            JhKda = XMibpo;
            XMibpo = XMibpo;
            JhKda = XMibpo;
        }
    }

    if (rpZDqhv >= string("oEgoAmYkYDtfBKgfYuOWBMXxwfwwIk")) {
        for (int wtTBD = 133615656; wtTBD > 0; wtTBD--) {
            continue;
        }
    }

    return JhKda;
}

double QDrKwk::zvgWGbykt(bool HrRgJZqkZ, string IhVuQrwyYieCK)
{
    string IVBvALKdlXYpVkP = string("VcrAeqmnumRCHfNPMJEgIKNfdTCkjlwGrpQEXCtoZUnNFFnQGvFKiGiJmSUAgzIJfHBizsPuDJktlkDqRnVyFUbNBcyRdEFVtWPpCvtZwoXokKhwzwuTsJaIkyQWmhJFJtZTREicQWADyNvgRXRYkNhDbjJ");
    double aoMrBahZhprMV = -743669.8291930171;
    double JaaFaSusFdAhm = 550877.9555627524;
    int QEfoLfcUJcm = 1289611890;
    string HtNgmw = string("wxqwknBxTqphyaLfICWQrcyvGrCDTuQVTkGbDwwxhbeOKfWdSneXQxrekFZIZvyXsgvoIrijnkSJzrwkxdpEDJEWZWEgtPAmxMexPHyezfGsxOUeDyGJsuUVTqkPZqNrqORKgBZjKJivORRdodDXGLZnhVVMOdUyTKBpdhbhqmJAPUFAQOGubFvHYEpsiWgrvnwofgnTnIbhelTTSLadpFSGiZstHYJ");
    int gonAOx = -1112825574;
    int dMypZOxjcozsZ = -1284736137;
    bool cnLpcyzPhRlTY = true;
    bool mYtVt = true;
    bool SqLuoDtfTagj = false;

    if (SqLuoDtfTagj != true) {
        for (int HLHNrIO = 1965132168; HLHNrIO > 0; HLHNrIO--) {
            continue;
        }
    }

    for (int oAYDrlYpKsNbGUU = 1889106232; oAYDrlYpKsNbGUU > 0; oAYDrlYpKsNbGUU--) {
        cnLpcyzPhRlTY = HrRgJZqkZ;
    }

    for (int dudREus = 1941038482; dudREus > 0; dudREus--) {
        continue;
    }

    for (int tRxEb = 1718501491; tRxEb > 0; tRxEb--) {
        dMypZOxjcozsZ -= gonAOx;
        cnLpcyzPhRlTY = ! cnLpcyzPhRlTY;
    }

    for (int zVRODHSTv = 1264191636; zVRODHSTv > 0; zVRODHSTv--) {
        dMypZOxjcozsZ *= gonAOx;
    }

    return JaaFaSusFdAhm;
}

int QDrKwk::fHpqOBaUSgyplVZr()
{
    bool jAcgWY = false;
    int hYtOCNWiNPkHRrEf = 989928622;
    string suaoFZJCwZq = string("hsnOEaBVkzCvLkNujmZbUJdmuxqOYjhPTWKvREefIuouHNmorwTvugkFMGtFZwbfPsUypItDdVTsuQJijqGGZKzXUxrvcgpCa");
    string eukDSsUXhUThOqD = string("rCckMYZNgOwymZkIJXHFYStzhYkWaNDSaJYFcJNPPeSNofoEMhNdMQqdsFnnrfBhDMyuQwXxBwaOLNkaOz");
    bool ZYidvxcudglZu = true;
    string JCGVSnKiUTgZmw = string("TcAcFrPZbhHttlTWVAgxABDzaXjEudjHvgLqEjDyPoMQWWUChywGeENiWekiupmksMHQASMqrUNWjOUslgjUAaoeIQiNXiHOEk");
    int KSXfWGuzFzrds = -1109271131;
    bool xaeFy = true;

    for (int aIJytyUtQtjXfFt = 72199508; aIJytyUtQtjXfFt > 0; aIJytyUtQtjXfFt--) {
        KSXfWGuzFzrds += KSXfWGuzFzrds;
    }

    for (int pdIEjwFTkqDOphu = 690878761; pdIEjwFTkqDOphu > 0; pdIEjwFTkqDOphu--) {
        ZYidvxcudglZu = ! xaeFy;
        suaoFZJCwZq += suaoFZJCwZq;
        eukDSsUXhUThOqD += JCGVSnKiUTgZmw;
        eukDSsUXhUThOqD += eukDSsUXhUThOqD;
    }

    return KSXfWGuzFzrds;
}

bool QDrKwk::rXBBMnfXtgeBaAov(int HykUTTIOBC, bool PzaeyT, double szIFhNPs, bool PabAgfysGN, bool RztlawSTOwHYNms)
{
    int jtRxyGvyhNMKh = 1334090537;
    double XPgitzwVnNArjtDi = 1044109.1758721024;
    string iFwYrLmpE = string("HINcfAVKztLrdHtLjMCtPebTkDcveHHSNJRasfJrRNjxtSITfyZeyAVqOLMJAQjtTZdMXDjsFbPHEoAIZCBpwjYgMAgWbYnQiwBvwcWmYGcfGYeyozEljOXyWlCLOyDGmXJXIevTJJtvEknXFlHYsEQoTkCMfTMlRhOMzgCGBowKoaPKRLhmYHqGHGIWXyvIjJNWWersFoYkoMtRgUfBTsYRyfBvIAgR");
    int jSkafBVoGnAktMk = -517581247;
    int UaeANNgmucZwbT = 1602033315;
    double USbUNTJDS = 485883.5935582886;
    bool XWlbxEZuZt = true;
    double PWjvlexCIzuRb = -391938.91562727856;

    if (UaeANNgmucZwbT <= -517581247) {
        for (int sQKXuXALJYpgA = 1098196516; sQKXuXALJYpgA > 0; sQKXuXALJYpgA--) {
            continue;
        }
    }

    return XWlbxEZuZt;
}

void QDrKwk::cfnjMoDBtURiGL(string BlQxAeHEPAk, bool zctRcKIVhPH)
{
    double FTQpZ = 210344.33011359387;
    bool oSCGdqoupAZ = true;

    for (int IKTdilMNhZIcoz = 1927664094; IKTdilMNhZIcoz > 0; IKTdilMNhZIcoz--) {
        continue;
    }
}

int QDrKwk::bjPCSKYr(string YTYOrxOd, int dygrMFo, bool ltfMoU, double KrsbOrUKqxDeDlNm, int ULkLRqL)
{
    string Cdgsczx = string("kwkhJukxfOwPecIuOzzVYMaqCPqCOMnRtQchgUVXGrJrQUNqOMeRYVQCBIaNwzDXLaERAazQsyTxUzeFJjfLfgcKYOOQIkmQCrmMGPmwGXNERttBUMKpWSRuMJYkGLxXvcXdMtOTFJQNMLDWWrwERzwPCFUgnKDSsDnKWgqZDXeTBKyuZFjOLzAaLbcAUCPLSFOEPMNQMFIglKgOiYqFClFDkzyvwv");
    bool vCupVj = false;
    bool uWYZHjxT = true;
    double riaRDDmLw = -155199.19124893798;
    double hqDmDgd = -232322.7465256132;
    string VUyxYqXMSjEfuNz = string("DZowBRZaBhbFTlFhYHVpAeHhBMGWERbHqffj");
    bool otrwXfLgLMcW = true;
    bool oNHeegPxHzFlW = true;
    double fHawjSeRBcxCiRl = -992976.1783851752;
    string fyCEXvGa = string("jxLkjMVEBoxuDdXBIKWpaBGYvbuQpYJiXKBpdwxRShRXevlucBzeVrygRKDmcKznyOpSprqyJDKykmClJruzewgjvKHJuLgEOENwzknemz");

    for (int OaHWETVAyLSQJ = 1380526474; OaHWETVAyLSQJ > 0; OaHWETVAyLSQJ--) {
        riaRDDmLw -= riaRDDmLw;
    }

    if (vCupVj == true) {
        for (int mJQMYEtNQmVhkqlm = 38970683; mJQMYEtNQmVhkqlm > 0; mJQMYEtNQmVhkqlm--) {
            ULkLRqL /= dygrMFo;
            VUyxYqXMSjEfuNz = VUyxYqXMSjEfuNz;
            vCupVj = ltfMoU;
        }
    }

    if (oNHeegPxHzFlW != true) {
        for (int ENdfZSJ = 378322654; ENdfZSJ > 0; ENdfZSJ--) {
            oNHeegPxHzFlW = ltfMoU;
            oNHeegPxHzFlW = ! oNHeegPxHzFlW;
        }
    }

    for (int rTJusUfFKtk = 1338454982; rTJusUfFKtk > 0; rTJusUfFKtk--) {
        KrsbOrUKqxDeDlNm /= hqDmDgd;
    }

    for (int pFyweNN = 112734278; pFyweNN > 0; pFyweNN--) {
        ULkLRqL = ULkLRqL;
        otrwXfLgLMcW = vCupVj;
        otrwXfLgLMcW = oNHeegPxHzFlW;
    }

    if (dygrMFo == -692406390) {
        for (int nKGaAwrou = 1988687394; nKGaAwrou > 0; nKGaAwrou--) {
            Cdgsczx += YTYOrxOd;
            KrsbOrUKqxDeDlNm *= hqDmDgd;
            fHawjSeRBcxCiRl += KrsbOrUKqxDeDlNm;
        }
    }

    for (int XyfiJBo = 1309944534; XyfiJBo > 0; XyfiJBo--) {
        ULkLRqL -= dygrMFo;
    }

    return ULkLRqL;
}

QDrKwk::QDrKwk()
{
    this->VdYiAdQUBoJUkoD(27107.647925233323, false, true);
    this->SMFyhmIJ(string("YibfJbcQnrAACUGILaBHZESVOcMrNORnpIVBEJJxAknMqwyZhluycwaQjmIuLRwUNqNBhlFDiElphGnBUETgImNHZDUJvvFkfZnsWKWIVT"));
    this->HEpAGdWeI(977258.7138093587, false, false);
    this->zvrrXuyJ(1960215396, true);
    this->NRVOXcMZfzxZJQyq(false, 973796.587743535, false, -701220184);
    this->XCTicrqcQimp(-73520.5063714138, true, true, true, -867659521);
    this->IahaFymwspBc(true);
    this->BaBVcQOvBFeQqUEG(false, 937939.4286875931, false);
    this->GiiHzQmdrqcq();
    this->GqxiCbPmXoTVe(string("WvYQhGlaYtiZgTPipnxsRYaaTzRDrpr"), string("YhvckTLPegEuERScVetngTIcIeXMCSKAKOqoMdRbjYGqCbZMdshOGgLeAQvaUCakbLAMoDKkGpN"), false);
    this->NhMJiQvpIJKfl(true, true);
    this->ZmvAAPJY(false, string("oEgoAmYkYDtfBKgfYuOWBMXxwfwwIk"));
    this->zvgWGbykt(true, string("YzvZDOOTuDGWlbQUfoKtsoVShqybCnOxFpuJNZzYnwpyaqYkimZheDDEdKNwzpEJyRYCxBcvrOk"));
    this->fHpqOBaUSgyplVZr();
    this->rXBBMnfXtgeBaAov(-168725464, true, -1046330.5681130684, false, false);
    this->cfnjMoDBtURiGL(string("ACOvuKlOCfBCEYbssOplIgwgdlHJFjtSptHUaAvmotWnhoBiWsfmiVQhOfnOUbqEsMSXUjIVJtXwpamdbdfoAmyheMkJGywyTBzBsSEEJwrrmpKFSiuAfOhObAKkCEwvKkCnNgucsVINjjQJRdomgCUtAekWjghmBaFyDzAZcWetoBdkBNharxIYzkxCXUGNfAPkTgdaNATdGSZgrEbJDXvCgRcHEHKmMrEljrccUd"), false);
    this->bjPCSKYr(string("XaAbhAWReZvBCDttUeJLmLbiipYENnabYfBzrcOTGROMVzNgfahhQJHwzzfLHprLhtXLVF"), -1490016263, true, -554908.048566383, -692406390);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MSHjdAIxkJm
{
public:
    int OaDPfqyvaM;
    bool FGuQuzwCpo;
    string awnNnjqZQZpg;
    bool OnCeEEhdVT;

    MSHjdAIxkJm();
    double zfjDHikhdQtoC(string ZYUoH);
    int xbUxTndbwrKPFp();
    string csNXzwDeYhzW();
protected:
    int iTkSaePHNLqJd;
    bool MdqixnM;
    int hWxWdWyirq;
    string AQqVvph;
    bool jzHkdT;

    void BUsZjhSXV(bool eQnjeiEkRcGCpz, int rfoEArzgrErjpxD, int pUfbIABeLtPy, int TQmlIXZwBMjz, double wMdtwCJvKW);
    void zfWwKTvlZq(int ZVcLKRGlF, string tUhlgXtFmHu, double uhuEUNC, double ejMjZHJOhr, bool TZdGXkEki);
private:
    double smSdMvUyTk;

    int XtOxRzdvTqOqz(double HjRZYyJlrjtZns, int uaDhTx, string XXXVLLarrARPl, bool CvpmCLeSPVNe, bool TwGovRMWtXNcbSQ);
    bool LtfhQBbNg(bool sQwCyBVnMSfJGN, bool hLQweIPQWz, int dnbuIfkIcTgJDlmt);
    bool SGQVX();
    string nqbffb(bool PNTZkDNdYBeIvdWb);
    int aDmRL(int tmqayXtnTvqXpbm);
    void AQCcwh(double upyxtLH, int LMHSN, string lSXvfWBvwUnlqosL, int TfADKvQDTHQjMxbX, int eeavDCIWGjqqu);
    bool aMuwdjL(string lvchwHk);
    bool RvPgFbidqje(bool gaDIJwJGMXA, double EiXehd, double uDXJB, string KSzmjgxGyJ, int SNaJuJBXwwHTM);
};

double MSHjdAIxkJm::zfjDHikhdQtoC(string ZYUoH)
{
    bool dvrvQ = true;
    string hVLCwFhrnYJE = string("vQTuzxMBfaRmBlMtnSbTMEIxZeaVtfalGvjQBCiKZCVMVhLgLXuZLdumuvqcTVMptEedsRhosWtSgcIQnRoYWyfEfbIOLhJwIGdXRPWqPGQxddKTAXHanORQzINpSBrRKROPIymrUcbqnHfBBJlaeRMQwcHEJEGnaHUbRLGeieBvcOFplywMhQtlIYaMSMRMjjBjZoAPaOwqIqWnunvzgBqGYXpNuV");
    bool EoNWvh = false;
    double ekUojyFU = 591038.8115036521;
    bool qSThYrYmqpW = true;
    int BtwKJLZMqSBec = 456120268;

    if (dvrvQ == true) {
        for (int rorivhnsuYGjlmiA = 664418199; rorivhnsuYGjlmiA > 0; rorivhnsuYGjlmiA--) {
            continue;
        }
    }

    for (int IDewDoLf = 1140653998; IDewDoLf > 0; IDewDoLf--) {
        dvrvQ = ! qSThYrYmqpW;
        qSThYrYmqpW = ! qSThYrYmqpW;
    }

    return ekUojyFU;
}

int MSHjdAIxkJm::xbUxTndbwrKPFp()
{
    string VmVUbwdapKkCD = string("DZFbLsJIAufOzEBdHZAhjbvmLGuvseGqNJkGutYNaPNwubUJkHCguIYZMdycvcMReTGSvnsZMEXzxPIhbfHkfcGRzfVPwevMVqBczqdvAjYfAjrJDyDMoSMtAxQVwzwawofboGJJOOInPaYpLntlCGaHxWGsilDURKtCHtRTdZHYxZjeDzODXFmggkjgZUNkFLlHlpXWMaCmBkXTxdTWaBZjupRrCnPYnaFwAuEwAWgvVCKb");
    bool hraCyIKlIfnAW = false;

    for (int tSYJGedzlji = 809240796; tSYJGedzlji > 0; tSYJGedzlji--) {
        VmVUbwdapKkCD += VmVUbwdapKkCD;
        hraCyIKlIfnAW = ! hraCyIKlIfnAW;
        hraCyIKlIfnAW = hraCyIKlIfnAW;
        hraCyIKlIfnAW = ! hraCyIKlIfnAW;
    }

    if (hraCyIKlIfnAW != false) {
        for (int UupLdrGwxqhv = 1699186732; UupLdrGwxqhv > 0; UupLdrGwxqhv--) {
            hraCyIKlIfnAW = ! hraCyIKlIfnAW;
            hraCyIKlIfnAW = ! hraCyIKlIfnAW;
        }
    }

    for (int pBxcFBj = 64579459; pBxcFBj > 0; pBxcFBj--) {
        hraCyIKlIfnAW = hraCyIKlIfnAW;
    }

    return -1925225215;
}

string MSHjdAIxkJm::csNXzwDeYhzW()
{
    string lolEBJlrRzq = string("raCmbXFDDjtpOtNmpyFGmVaHgFITMPseaIKvrXqmUaDsRxxrvqasoZheTfamRTJkExtJjpCHiVInmZQCpdCNJRmHAGrMncyFkOLIqVtdtBqSBqeTxFMdBEWDVRUGnyigukAPdptPyONavTvyzVJziBQLpJoSjtxduVkErobcvsKldWHmgaYUtnxKzLqxBSUzgAlkSoBLqrbRAHMyDJI");
    bool NNuKOlZUTiyl = true;
    bool zIshwpiWobuUGqv = true;
    double FhRsEKUkfvTcYPt = 572701.3277777213;
    bool NBpcPxOahZvbxxZd = false;
    string qBHjWdNzPmdA = string("JbzwoJmthnDFJQFBniFwbsnEMHAEsQQtQgHsrAEckClZbGSEwVaGkaHQeiAESxsmvBmpoHahADrugOSHgRFKMrdlrMLxGbNgFT");
    double fNqii = -198185.8161741641;

    if (zIshwpiWobuUGqv != true) {
        for (int jRmucuOfZQLsdoe = 78654239; jRmucuOfZQLsdoe > 0; jRmucuOfZQLsdoe--) {
            continue;
        }
    }

    if (NNuKOlZUTiyl == true) {
        for (int TGKWXBDDQpHowCY = 1716251785; TGKWXBDDQpHowCY > 0; TGKWXBDDQpHowCY--) {
            continue;
        }
    }

    return qBHjWdNzPmdA;
}

void MSHjdAIxkJm::BUsZjhSXV(bool eQnjeiEkRcGCpz, int rfoEArzgrErjpxD, int pUfbIABeLtPy, int TQmlIXZwBMjz, double wMdtwCJvKW)
{
    int OabsfTTUkr = 1963848729;
}

void MSHjdAIxkJm::zfWwKTvlZq(int ZVcLKRGlF, string tUhlgXtFmHu, double uhuEUNC, double ejMjZHJOhr, bool TZdGXkEki)
{
    string HMMqTV = string("UrofGpMOFiXTkpMqLmaYPyLbkgWNCleTcEqdrKhEntBpJRMZEAKkjFQtqooPxGrBRgIknJsiviSKRdkLkrDSJMvMKRMOGgsYevZXjhnLCMQZwoTNlFhLauFHaaWqDglbbmNH");
    bool huDCXxeaUJ = false;

    for (int OzndJXLNodwLpV = 597699730; OzndJXLNodwLpV > 0; OzndJXLNodwLpV--) {
        ejMjZHJOhr += uhuEUNC;
        HMMqTV = HMMqTV;
    }

    if (tUhlgXtFmHu == string("pYzvWSOeLKHXVSSMpIWUeafwjYwWfCDRmyPLpuvMMGHzvyVjJcvjNvKnmKEzRPVDatagKSadfXtBpOXidJWtWvDDEykkBBoFCkMTRnpSZJczgTEwimSyDpBNGUhNoutNBnCdtZSvjIYQUyXdAeIFZzKlLPgBAaXGyvztgXQbUUVTQFZLIDFtddOclREJAAPRfQqQtScxwny")) {
        for (int qSPJMcsafBIbiYq = 1426012401; qSPJMcsafBIbiYq > 0; qSPJMcsafBIbiYq--) {
            HMMqTV = tUhlgXtFmHu;
            huDCXxeaUJ = huDCXxeaUJ;
            uhuEUNC /= uhuEUNC;
            TZdGXkEki = huDCXxeaUJ;
        }
    }

    for (int IoeVRCiVU = 285197378; IoeVRCiVU > 0; IoeVRCiVU--) {
        tUhlgXtFmHu += tUhlgXtFmHu;
    }

    for (int mTyHlqWeVtyore = 803788297; mTyHlqWeVtyore > 0; mTyHlqWeVtyore--) {
        continue;
    }
}

int MSHjdAIxkJm::XtOxRzdvTqOqz(double HjRZYyJlrjtZns, int uaDhTx, string XXXVLLarrARPl, bool CvpmCLeSPVNe, bool TwGovRMWtXNcbSQ)
{
    bool egjVoOZJStbyHWC = true;
    string vLJpEsElJQ = string("WWyPBvkiolircFvHsfzBfbpnPftDUnPZTIBqUgpsRmYIsCxrGvZzNsXgAsIMWPGNzuqNNvsZRycWhhBKcSafDSHuEoSBJVxdjiHveTYDJxFnGFPOHdSADuQmfFCVqQAisPaMVjhuDFqgLknUrHUfpjfnRkhrDogDWhfIJcDNnjdkcAldvtZvXfD");
    int JVgydCZ = -1704783303;

    for (int mdiyOnhTcwJtXv = 198777803; mdiyOnhTcwJtXv > 0; mdiyOnhTcwJtXv--) {
        egjVoOZJStbyHWC = ! egjVoOZJStbyHWC;
    }

    return JVgydCZ;
}

bool MSHjdAIxkJm::LtfhQBbNg(bool sQwCyBVnMSfJGN, bool hLQweIPQWz, int dnbuIfkIcTgJDlmt)
{
    int vOTVnSGER = 1949589099;
    int qkSpwN = 1481775540;
    bool NyaXoJknuJfsXpK = false;
    bool jwabYxfNdQYKpLin = true;
    int psYhehk = -980396491;
    string NyfOvIkDHMoAwj = string("FcAZTzCgrrgzaoWAR");
    int cXUcbem = 1477751764;

    if (cXUcbem == -542146315) {
        for (int uRWTRntlfos = 1953135540; uRWTRntlfos > 0; uRWTRntlfos--) {
            sQwCyBVnMSfJGN = jwabYxfNdQYKpLin;
            jwabYxfNdQYKpLin = NyaXoJknuJfsXpK;
            sQwCyBVnMSfJGN = ! sQwCyBVnMSfJGN;
        }
    }

    for (int vmQVeBCDTgp = 1252128942; vmQVeBCDTgp > 0; vmQVeBCDTgp--) {
        jwabYxfNdQYKpLin = NyaXoJknuJfsXpK;
    }

    for (int ovOOuLqm = 1056393996; ovOOuLqm > 0; ovOOuLqm--) {
        vOTVnSGER += qkSpwN;
        vOTVnSGER /= cXUcbem;
    }

    if (sQwCyBVnMSfJGN == true) {
        for (int hdGhFCQojUEfZg = 1956848570; hdGhFCQojUEfZg > 0; hdGhFCQojUEfZg--) {
            dnbuIfkIcTgJDlmt = psYhehk;
            sQwCyBVnMSfJGN = ! sQwCyBVnMSfJGN;
        }
    }

    return jwabYxfNdQYKpLin;
}

bool MSHjdAIxkJm::SGQVX()
{
    double ioCnTYjMNoca = 640669.4698824179;
    int bhNZuLVbhfbMBQ = -2139552100;
    double GnwKzFuGdhWgqTdE = -942465.9176845608;
    double ryZlxqFUd = -14696.67107082809;
    string RQLLTtTLwXUyZlfg = string("WbjQudOAHqlFBTQdiKGUSBydMSuJqKYRPwYrBueowIxuirEFNPbjuzkdvCJHeDNLfsrckvMOfyUxFOhq");
    int ejNRqfuvnLiFAa = 238003344;
    int cewJYWSjcuMwsMlN = 841701609;
    double aVWiloYKmUMqUny = -864496.6074749188;
    double FqLsj = 809299.9693051098;

    for (int lgfmPsSyFfHkehCN = 160522494; lgfmPsSyFfHkehCN > 0; lgfmPsSyFfHkehCN--) {
        cewJYWSjcuMwsMlN = bhNZuLVbhfbMBQ;
    }

    for (int AWSQpksEbVgvtj = 1138864106; AWSQpksEbVgvtj > 0; AWSQpksEbVgvtj--) {
        RQLLTtTLwXUyZlfg += RQLLTtTLwXUyZlfg;
        bhNZuLVbhfbMBQ *= ejNRqfuvnLiFAa;
        GnwKzFuGdhWgqTdE = ryZlxqFUd;
    }

    if (ioCnTYjMNoca <= -942465.9176845608) {
        for (int XtVDKjdUyw = 913223581; XtVDKjdUyw > 0; XtVDKjdUyw--) {
            GnwKzFuGdhWgqTdE = ioCnTYjMNoca;
            ryZlxqFUd = FqLsj;
            FqLsj = GnwKzFuGdhWgqTdE;
            aVWiloYKmUMqUny += ryZlxqFUd;
        }
    }

    if (GnwKzFuGdhWgqTdE != -864496.6074749188) {
        for (int AEHSRxqiO = 946432594; AEHSRxqiO > 0; AEHSRxqiO--) {
            ioCnTYjMNoca *= GnwKzFuGdhWgqTdE;
            aVWiloYKmUMqUny = FqLsj;
            ioCnTYjMNoca *= aVWiloYKmUMqUny;
        }
    }

    for (int AXpOERfuayLwLy = 146271223; AXpOERfuayLwLy > 0; AXpOERfuayLwLy--) {
        ryZlxqFUd = ioCnTYjMNoca;
    }

    return false;
}

string MSHjdAIxkJm::nqbffb(bool PNTZkDNdYBeIvdWb)
{
    string Mqxnfu = string("WOcKHEbsIzxFCbYRiJCRqJSJYbnxQtpJiVqQugCCLkFCpgEBnQfmNfNfORVLSarErZIzkjVhOulVaMpdYUrrZRRxTzLinzJYePNKwBhoecISJhWoYVzpXvvSarXCVUvsASLcpTFZvJffAiZMysIMvkjPikaeMlEmmSuojXajUlIkKqDwBuTKLkjJvEqjrlhccqODgChDgQXKcDjKGEpjQwUnwhrxOMTglsraOkuUmYNnNChBAfaaKBjaMqQ");
    bool wnrFVvDWqwINYiDD = false;
    double XZLDQF = -55458.7057535154;
    bool RMFCISvIPx = true;
    bool BvHmDyTp = false;
    int VpMDCsDKnv = 1140955233;
    string aJvhgKnp = string("hAqohynvdNMdwXWAvJURUkJSJbnlBmOygxyPDOwINGGBDZwhErzsUEwSDtxgsEyzIKylSUrfbIJrnhNuClWzbmsBfayYhNFKwcunBNff");
    bool scnRoXlZbrvFBVx = false;

    if (Mqxnfu > string("hAqohynvdNMdwXWAvJURUkJSJbnlBmOygxyPDOwINGGBDZwhErzsUEwSDtxgsEyzIKylSUrfbIJrnhNuClWzbmsBfayYhNFKwcunBNff")) {
        for (int rwfFdLv = 782340868; rwfFdLv > 0; rwfFdLv--) {
            PNTZkDNdYBeIvdWb = ! BvHmDyTp;
        }
    }

    for (int JTHUlqJOYiuiQIRC = 1495424998; JTHUlqJOYiuiQIRC > 0; JTHUlqJOYiuiQIRC--) {
        RMFCISvIPx = wnrFVvDWqwINYiDD;
        RMFCISvIPx = ! scnRoXlZbrvFBVx;
        scnRoXlZbrvFBVx = BvHmDyTp;
    }

    for (int ERAJPTpkLNv = 1745825155; ERAJPTpkLNv > 0; ERAJPTpkLNv--) {
        wnrFVvDWqwINYiDD = wnrFVvDWqwINYiDD;
    }

    for (int tGevTsxAmuAAiaL = 576089660; tGevTsxAmuAAiaL > 0; tGevTsxAmuAAiaL--) {
        XZLDQF += XZLDQF;
        BvHmDyTp = scnRoXlZbrvFBVx;
        BvHmDyTp = ! wnrFVvDWqwINYiDD;
    }

    if (PNTZkDNdYBeIvdWb == true) {
        for (int fckFisiGqK = 2078421861; fckFisiGqK > 0; fckFisiGqK--) {
            wnrFVvDWqwINYiDD = ! PNTZkDNdYBeIvdWb;
            BvHmDyTp = ! RMFCISvIPx;
        }
    }

    return aJvhgKnp;
}

int MSHjdAIxkJm::aDmRL(int tmqayXtnTvqXpbm)
{
    double nuXzSzBvaUi = 33447.76159872982;
    bool cEqWIzDEB = false;

    for (int MuzHUwXQy = 1309320584; MuzHUwXQy > 0; MuzHUwXQy--) {
        nuXzSzBvaUi /= nuXzSzBvaUi;
        cEqWIzDEB = cEqWIzDEB;
        nuXzSzBvaUi -= nuXzSzBvaUi;
        tmqayXtnTvqXpbm /= tmqayXtnTvqXpbm;
    }

    return tmqayXtnTvqXpbm;
}

void MSHjdAIxkJm::AQCcwh(double upyxtLH, int LMHSN, string lSXvfWBvwUnlqosL, int TfADKvQDTHQjMxbX, int eeavDCIWGjqqu)
{
    bool XIWCCSeTRXxDyccy = false;
    string FeNzmn = string("SZcKDwhPGjigOMlNMAvTdSGDMEcIXHUHACueVlboLbqlOlxHKiwwYvfLtyooBCyRXHsWriMYXxvzbGvVJUIaMAFtHJSkh");
    int KQGCjoWCkJrQEud = -1277740662;
    double aQuEzJJlH = -187477.16146012887;

    for (int UfTlzTkyXcGTAf = 676263334; UfTlzTkyXcGTAf > 0; UfTlzTkyXcGTAf--) {
        TfADKvQDTHQjMxbX = TfADKvQDTHQjMxbX;
    }

    for (int SNaeP = 2012626536; SNaeP > 0; SNaeP--) {
        TfADKvQDTHQjMxbX = KQGCjoWCkJrQEud;
        upyxtLH *= upyxtLH;
        lSXvfWBvwUnlqosL += lSXvfWBvwUnlqosL;
        aQuEzJJlH /= aQuEzJJlH;
        LMHSN += TfADKvQDTHQjMxbX;
    }
}

bool MSHjdAIxkJm::aMuwdjL(string lvchwHk)
{
    string pwelbjCUxMB = string("GrQiTsyTchhNtpEVsnSXkErSRDhyruQEXaoYsCZkSldcfyLWqNuiaQMpqharccblBcZAUnrfBUGeyGlQjNfeEprJNkKl");
    double jxKNyhXTNjBSKi = -805282.441331186;
    bool YJEZb = false;
    string zSHmhZyflaEmZGTV = string("avFOACgGownzxlGqqWePrBoVvJERzsHXSaXACFxjMDyhEbkivRjHXQpthVRESAppxtsHrIIVKCEFFAXuMvoJXWnDxEhyezVn");

    for (int UezjOdKwGtHcT = 959370676; UezjOdKwGtHcT > 0; UezjOdKwGtHcT--) {
        lvchwHk = lvchwHk;
    }

    for (int MxQlsZDsNgVA = 1980618547; MxQlsZDsNgVA > 0; MxQlsZDsNgVA--) {
        lvchwHk += lvchwHk;
    }

    return YJEZb;
}

bool MSHjdAIxkJm::RvPgFbidqje(bool gaDIJwJGMXA, double EiXehd, double uDXJB, string KSzmjgxGyJ, int SNaJuJBXwwHTM)
{
    string iiXbPcx = string("CQlZkXe");
    int bXvejoVDxFtpVpV = -360776380;
    string cOnCXjHoYgNaLwo = string("WAsGKxzIVjbaHQeljblAPABhpQacBNyeIyhKpWYJSHNJxUKkhAovcLYPYYPSaKLCLyDRCdCTEEveTiJYuFbsadRhqLoDzVXyEwvhLwwpTvIRAzdVirphVGBdHVjOKNAnyjDzPZnAfASMhYTPYVicLVooEMYXBjxEgWgxRlElCwsLxQKiFPM");
    bool QrCZbWhcp = false;
    bool WyBzMDa = false;

    for (int AJSPM = 1765718447; AJSPM > 0; AJSPM--) {
        iiXbPcx += KSzmjgxGyJ;
        QrCZbWhcp = ! WyBzMDa;
    }

    return WyBzMDa;
}

MSHjdAIxkJm::MSHjdAIxkJm()
{
    this->zfjDHikhdQtoC(string("DxMTjMJiKXypoJvUITkoBaOLUGTmdJOcTLtGjjc"));
    this->xbUxTndbwrKPFp();
    this->csNXzwDeYhzW();
    this->BUsZjhSXV(true, 46418042, 2110239292, 2058265622, 978265.3228617914);
    this->zfWwKTvlZq(-1874223299, string("pYzvWSOeLKHXVSSMpIWUeafwjYwWfCDRmyPLpuvMMGHzvyVjJcvjNvKnmKEzRPVDatagKSadfXtBpOXidJWtWvDDEykkBBoFCkMTRnpSZJczgTEwimSyDpBNGUhNoutNBnCdtZSvjIYQUyXdAeIFZzKlLPgBAaXGyvztgXQbUUVTQFZLIDFtddOclREJAAPRfQqQtScxwny"), -132309.66675556407, -42400.27454313423, false);
    this->XtOxRzdvTqOqz(-352224.31270101946, 1429669859, string("DpElStLYYPQQreOIXcuPIrQEImrgPJcUTsLHEgdBdgwagrEnMeEHATANhUJLzoCypywEzUVTjaOChvSALVrnACWoyUVOgPULHrjtjNkyGLfrDRJwIJnCSSoiWYvsDTZnNbsrSpKj"), true, true);
    this->LtfhQBbNg(true, false, -542146315);
    this->SGQVX();
    this->nqbffb(true);
    this->aDmRL(108536874);
    this->AQCcwh(-936998.4425469408, 462703510, string("dTqDoefXDaYwBeQbOlpWYZpjUlVvBqLRdtjlqMHbDyOITptOJQEdOjESkSvQmmvKICtVXTZabJSOjtBYZGTZNuBicYOtILzJIXxjhlEVIGtXCVlJpOHuPQKmxHvycTTszbFQikqjokNVDlNsG"), 905948997, 1173253777);
    this->aMuwdjL(string("mGYoQeGbKmuzbUXoHfqBdqeZtCPzWMlHIDQzDsuVmUUkCDmGsCMzLDoNRnBKPBIKAERVLWJtZnnpeBqpKOVDtETGJEoYhOiMroVcnC"));
    this->RvPgFbidqje(false, 810432.7505961997, 757303.3834212756, string("tHXbCtDUDhzrwBxMIkOhlNvpDRDGzVHaXvOdjubqEFTMXeeJVMGgaGRFBCtHuCBWArBQikIkdopAJsqWpNZuPNrJbUUlHLDoSlRCFCupJPPtzqXzMmFDDZeIfHATKnfbebUqVPHzjQaMacYsqaReCK"), 832476642);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RkspOqDmwhYDlYBT
{
public:
    string gkkQXfAFOZBZoe;
    bool dgpEXr;

    RkspOqDmwhYDlYBT();
    string RcCDGfqyWDsXgF(string kHbHANwO, double YxTPsFyMmzZrPM);
    double oWSVHFuCqQGjX(bool fQIjfsWRD, string QVVWYAtPJYSJS, double EYatdZ, double NaoygXcLbSvb, int VdAaoUvbhzo);
    string LWuCqRqmqsL(double zaKIAlRLItb, bool JJrIZyHGVqDJt);
    void jGjWSuLEenqfYbHI();
    bool DIAOWbUp();
    string izqCWUMKqNwFC(string GBeGfXaeojB, bool iLbsgOzyeKHFIUkN, int gawkI, double UTnPhVV, string xGbsqiE);
    bool kxzYKZrKeThMUatG(double mUodTMG, int cPKAJtyQXrmOy, bool vkFHzwX);
    int Byntj(double CQZalCAYXMzdxFUL);
protected:
    bool gWYgTpQRmRCfk;

    void PuWLzD();
    int wwxfhOplvxg(double KhuZCTiPSfPPoj, int QZBXHpEweYPMj, bool WxFCEJNDL);
    int hMgQWJsZR(double CuCJuuhAZm);
    string FQcxGsEH(string yhreSGfUitTuOfs, bool dufuwVGCwlZSuGm, int bVDKu, double oEjyLSHhLzhAO);
    int fnFYTGukqEN(int hjpyRANahGZgpjBD, bool OGzYMEyOs, int JhqXemOImCgq, int dfrEEJdHnhzDYg, string LWoTpK);
private:
    string wYJzfMR;
    bool UEDYbK;
    int MujzE;
    double lbGdqJS;

    double HbUrIGoSKKVXUPa(bool eaAQCKIyiBmTA, string PWsnpINaYWenkIUP, string UHBXFsOBKGRps, bool zozPbTpbKrHgR, int whmEpuRHauoip);
    string tKRNGhjsJlvi(string FFCKRCFfnd);
    void YqdWeuSr(bool yhYxszcJSbZ, bool gIUdBOMDTZsseN, double bfLbMbCtUtTSUp, bool nURhILLuA, double WCSuebNnVW);
    bool UvrhSX();
    void qPelwgUZEgS(double IxOjkrKGuhORKRP);
    bool WHNeZhNoNqam(bool FastvdGgj, int RWYzCIGtM, int QFUSwwbNSZFKUto, bool BFinfcD, int JMfPBpTT);
    string yggwxMSNrZ(bool KyLIifVWsSQQts, bool llzYGwaAt, string KbViaIIDhQa);
};

string RkspOqDmwhYDlYBT::RcCDGfqyWDsXgF(string kHbHANwO, double YxTPsFyMmzZrPM)
{
    string aOtWqarYxc = string("aNxaMFGjJFDQTnziEutnezRDynZxINcFgGwwzWgICbAhGKCUcpWUzZyortncRZJLHlPPzVLdOTZeSbwJXMRjKcdhFlmyylCrahwCQDLTshGQYwYmCreOZmPIWxAUmRPozTxSIOzdmWvYqYmEaVwnbOLtqwxrpCqhhzwbQTUmuQTsTrbbuLXZGypiebJBClgzosEunzqRcibOHPnXpGhXOczzxpBlRjPrQzzhaMHAexcpohAZOBlmYxUdMiH");
    double IzWqv = -298599.9434303877;
    bool LrlAouocdDfl = false;
    int zBiYN = 2110733528;
    bool fsQAt = false;

    for (int IjebzQQ = 428942201; IjebzQQ > 0; IjebzQQ--) {
        continue;
    }

    for (int UFnbvN = 181540499; UFnbvN > 0; UFnbvN--) {
        fsQAt = ! fsQAt;
        aOtWqarYxc += kHbHANwO;
    }

    for (int PzEqllqgXEh = 1961983927; PzEqllqgXEh > 0; PzEqllqgXEh--) {
        IzWqv /= YxTPsFyMmzZrPM;
        IzWqv /= IzWqv;
        fsQAt = ! fsQAt;
    }

    for (int psfCtIxdgfHvPltF = 2000486216; psfCtIxdgfHvPltF > 0; psfCtIxdgfHvPltF--) {
        aOtWqarYxc = aOtWqarYxc;
    }

    return aOtWqarYxc;
}

double RkspOqDmwhYDlYBT::oWSVHFuCqQGjX(bool fQIjfsWRD, string QVVWYAtPJYSJS, double EYatdZ, double NaoygXcLbSvb, int VdAaoUvbhzo)
{
    double HDCUkAbWPPuFvH = -951750.7377005385;
    bool HdlXKpbWTEsHlOS = false;
    bool HuyAC = false;
    double RovZGdsvQzcXt = 582844.2281556175;
    int HFCwYb = 1051372728;
    bool GOVKemrPI = true;
    bool HZuzJoFSBFl = true;
    string TNEMWkjKFFRSPI = string("qihWYzvzSobRQJtsryxcQqOrzWyRLmMChGxGNBBomMzXYSKrZzaDSqdnJxNPntVULPKZBLgjOAYOxRWQiiNgfqMNksNWxrsHipqNOUycGsbmcHCeKRdPOlBOWpOnUdKGKGAWssHdeQspnvyVhxxBkwVfsMoHIcbpkVhESXMhvldtiYFhWteKhbBruApOWGUoNnFGamCXkGgXcvURNBevM");
    string cGzATheVaFoXs = string("pSAZNyKDGncUZiHNcnqTvBVBmWDcingofsGKUzNwPtAphwwIyNqeRUzhIZOZSNkabtSGBzioNNKyLKAnEPFEQkdgrsaxEuazys");
    int mUtKLUCM = -269585427;

    for (int xPNNPTuutPrvntG = 403476021; xPNNPTuutPrvntG > 0; xPNNPTuutPrvntG--) {
        RovZGdsvQzcXt *= RovZGdsvQzcXt;
        mUtKLUCM /= mUtKLUCM;
    }

    return RovZGdsvQzcXt;
}

string RkspOqDmwhYDlYBT::LWuCqRqmqsL(double zaKIAlRLItb, bool JJrIZyHGVqDJt)
{
    string OKncN = string("tocYQEcdgpIQKmjXYtIRLVaXovkmQoQhVDxbibtVrlcqFCoqaSySUqBNsXTEfBtnOeRHVkRSnBDWYUTUscjAaaKUUkTBObbMaDTpYImAvqWLOqXwukqpENmZuxQllHTmQoraGZVMONVdTvEDKdQVjBBRCcDxnKCESfOaapjDElmxtiCeOAYzXuMzcqAzbPgyqgXdtgEunoxsyyoMkRIwPEaQgWVuSpAdgImnMJ");

    for (int hBXBzqrYMB = 1518414244; hBXBzqrYMB > 0; hBXBzqrYMB--) {
        OKncN += OKncN;
    }

    if (JJrIZyHGVqDJt != true) {
        for (int SbyArQzuSlO = 1935412242; SbyArQzuSlO > 0; SbyArQzuSlO--) {
            OKncN += OKncN;
            JJrIZyHGVqDJt = ! JJrIZyHGVqDJt;
        }
    }

    if (JJrIZyHGVqDJt == true) {
        for (int dLZGjUbUhWD = 265778505; dLZGjUbUhWD > 0; dLZGjUbUhWD--) {
            JJrIZyHGVqDJt = ! JJrIZyHGVqDJt;
            zaKIAlRLItb -= zaKIAlRLItb;
        }
    }

    return OKncN;
}

void RkspOqDmwhYDlYBT::jGjWSuLEenqfYbHI()
{
    double niVqBaVz = -240804.05012389767;
    double bkiOUFhsbYZ = 253293.46484751647;
    double LMNTncKK = 597615.9015821206;
    double uRTXLeic = 232521.73287281807;
    bool jUSLhtMhMtpoOCmQ = false;

    if (bkiOUFhsbYZ >= 232521.73287281807) {
        for (int rMFPtwVJtVuKAxGR = 1498097074; rMFPtwVJtVuKAxGR > 0; rMFPtwVJtVuKAxGR--) {
            LMNTncKK /= bkiOUFhsbYZ;
            niVqBaVz = uRTXLeic;
            bkiOUFhsbYZ = bkiOUFhsbYZ;
            LMNTncKK = niVqBaVz;
        }
    }

    for (int TYGwn = 1738784992; TYGwn > 0; TYGwn--) {
        uRTXLeic -= LMNTncKK;
        niVqBaVz = LMNTncKK;
        niVqBaVz -= LMNTncKK;
        niVqBaVz = LMNTncKK;
        uRTXLeic = niVqBaVz;
        bkiOUFhsbYZ *= niVqBaVz;
        jUSLhtMhMtpoOCmQ = jUSLhtMhMtpoOCmQ;
    }

    if (niVqBaVz <= 232521.73287281807) {
        for (int wMQGGtxNYWoWV = 1886575964; wMQGGtxNYWoWV > 0; wMQGGtxNYWoWV--) {
            LMNTncKK /= uRTXLeic;
            uRTXLeic *= bkiOUFhsbYZ;
            niVqBaVz *= LMNTncKK;
            LMNTncKK /= bkiOUFhsbYZ;
            LMNTncKK -= bkiOUFhsbYZ;
            niVqBaVz += uRTXLeic;
            uRTXLeic -= niVqBaVz;
        }
    }
}

bool RkspOqDmwhYDlYBT::DIAOWbUp()
{
    bool GwXYtQXwnLD = true;
    int pfMjrDYmOVJYAXjW = 291600062;
    string xsyKbgkFfUE = string("ekLJleAKDqLcrZYhzSmzzTxShVXYMftORijRugBZDmQsNOmBZRkXxpxPwsSaCFQdOHeldWIWqnvoKcVSFejamI");
    double gsLPGfQCiCwLRc = 1033850.9283636856;
    string ltdOQVaiKGG = string("HgvfWKploJrahCXHfaiOSFQucrGwiDzxhNmMxrXqHrLQ");

    for (int sAhoIVogKv = 346495135; sAhoIVogKv > 0; sAhoIVogKv--) {
        xsyKbgkFfUE += ltdOQVaiKGG;
    }

    for (int ugcFs = 233111235; ugcFs > 0; ugcFs--) {
        gsLPGfQCiCwLRc += gsLPGfQCiCwLRc;
    }

    if (ltdOQVaiKGG < string("HgvfWKploJrahCXHfaiOSFQucrGwiDzxhNmMxrXqHrLQ")) {
        for (int bWBeLUgU = 1102126229; bWBeLUgU > 0; bWBeLUgU--) {
            xsyKbgkFfUE += xsyKbgkFfUE;
        }
    }

    return GwXYtQXwnLD;
}

string RkspOqDmwhYDlYBT::izqCWUMKqNwFC(string GBeGfXaeojB, bool iLbsgOzyeKHFIUkN, int gawkI, double UTnPhVV, string xGbsqiE)
{
    bool JOnRqcWub = true;
    string dDFzYk = string("aUUhVCEiRLlWhaSmhzgSNpXaHxlNMutRclzbKfAAjCdrThAJckRyKAjnDhafjHySxiBmWmDuukqeSplXfqRfGvRAseWpONfuHISIpRQWeoWkACJhY");
    bool NLUSSCnW = true;
    bool uyKfzhaXSPaB = true;
    int tqqEDGxEyXBRx = 2032559698;

    if (uyKfzhaXSPaB == true) {
        for (int AbGdhTdcAg = 1172921685; AbGdhTdcAg > 0; AbGdhTdcAg--) {
            uyKfzhaXSPaB = JOnRqcWub;
            iLbsgOzyeKHFIUkN = ! iLbsgOzyeKHFIUkN;
            dDFzYk = GBeGfXaeojB;
        }
    }

    for (int Eqeur = 2059465785; Eqeur > 0; Eqeur--) {
        gawkI -= tqqEDGxEyXBRx;
        uyKfzhaXSPaB = ! uyKfzhaXSPaB;
        JOnRqcWub = uyKfzhaXSPaB;
    }

    for (int ssWWhw = 372603971; ssWWhw > 0; ssWWhw--) {
        GBeGfXaeojB += dDFzYk;
    }

    if (uyKfzhaXSPaB != true) {
        for (int RToACaHSpMGwZWA = 1126271359; RToACaHSpMGwZWA > 0; RToACaHSpMGwZWA--) {
            JOnRqcWub = iLbsgOzyeKHFIUkN;
            iLbsgOzyeKHFIUkN = ! iLbsgOzyeKHFIUkN;
            iLbsgOzyeKHFIUkN = iLbsgOzyeKHFIUkN;
            UTnPhVV += UTnPhVV;
            tqqEDGxEyXBRx *= gawkI;
        }
    }

    for (int YtEHRvBGg = 1876314221; YtEHRvBGg > 0; YtEHRvBGg--) {
        continue;
    }

    return dDFzYk;
}

bool RkspOqDmwhYDlYBT::kxzYKZrKeThMUatG(double mUodTMG, int cPKAJtyQXrmOy, bool vkFHzwX)
{
    double vGIOl = -232921.61283183564;
    int PrqKPDHWiYciOKn = -113121553;
    int LxEHapYtJrNuXjl = -91338469;
    string AimVFKUibiF = string("WNSxYIuorBuDmyIXmhiEkPNIMLDOZinOUEpsHjSjIoAeeGuXsOFOIXZFeUDNDvwzEYkYmEKLlLImoKfbbQKOtYDVePqRLsIMydMZqYSbhwSJegguRFJBqSKsSCtkDZGIrZwNNvfFvVbcJHDkeqXWfvcjmoJEQQXjFhnIAVVSUT");
    string EkNHopU = string("heGvjBEjByvFkpXjJUNTexigDWFWcYUWOaiGCEsRWXmFfYOfTkKTFZENfSgIxyKEatjTsvNkjuYpDoPEEdLzasAgmBJjNTkYmGNhJGROmgrzHOmugMuHgyKwJiKKHHTtjTEZHwbWpIyypagZOIfCifLIZGYAPPWJvVyrNFdCsyBrYLbQaGYRTcQpwlvxFE");
    double yBhIvDioetwmIM = -811296.3119997808;
    bool igYfxLhQPANmi = false;

    for (int wVhKGPrQSIpNcJ = 1649351209; wVhKGPrQSIpNcJ > 0; wVhKGPrQSIpNcJ--) {
        continue;
    }

    if (AimVFKUibiF == string("heGvjBEjByvFkpXjJUNTexigDWFWcYUWOaiGCEsRWXmFfYOfTkKTFZENfSgIxyKEatjTsvNkjuYpDoPEEdLzasAgmBJjNTkYmGNhJGROmgrzHOmugMuHgyKwJiKKHHTtjTEZHwbWpIyypagZOIfCifLIZGYAPPWJvVyrNFdCsyBrYLbQaGYRTcQpwlvxFE")) {
        for (int lXLrJZHHsH = 1303348687; lXLrJZHHsH > 0; lXLrJZHHsH--) {
            PrqKPDHWiYciOKn += PrqKPDHWiYciOKn;
        }
    }

    return igYfxLhQPANmi;
}

int RkspOqDmwhYDlYBT::Byntj(double CQZalCAYXMzdxFUL)
{
    int ElxCszm = -145134332;
    string mABkOc = string("vAMcEafGHnCVxZQiSrhQYXkxnGfIIvNMmlhnGnHSxuWeQdAzcRJoUvuwHKaAeeETSmNRGLiOBQpDardYkBYmXieLFoZngARXLICpxAZMbHbAxCChxECGziAKkJCxarKhNpzcFtAihObvZKzVPSQuvhONRmeLMLqcVetzFApnRwjAlRbJAMjgIzxjDOVuFdrCwbwByMSNuDdUomOdFTlDHZpkiWKLphUwEvcxfO");
    double wLFokjSNoAXCKb = 481474.8954006096;

    for (int cHMSHEvLIoYhkTNO = 262948350; cHMSHEvLIoYhkTNO > 0; cHMSHEvLIoYhkTNO--) {
        continue;
    }

    if (wLFokjSNoAXCKb >= -426501.52002327575) {
        for (int uFdPfLEOOufvKGNu = 1317281935; uFdPfLEOOufvKGNu > 0; uFdPfLEOOufvKGNu--) {
            wLFokjSNoAXCKb -= CQZalCAYXMzdxFUL;
        }
    }

    return ElxCszm;
}

void RkspOqDmwhYDlYBT::PuWLzD()
{
    string ATpgIfmEnnciCSq = string("mlmDmKlNtZXdbYWOvIEuFWMyZlkYUuDpJttgBwSdLLXECZ");
    double DsfLnowfal = -847832.4826410514;
    string xVYzY = string("dROtJGGSVXQyrcNJUzXnkoaFyyuYDWXsTBaTWCulWjBgBXZSFsOwqEgjhlzMhjHDSnKGQhXAPJdwZzuqYleHHUAfTbYusHhJHMhzbkglyiEcxmEfoQiaSaAPCwTMZjTlHScWakBTyGDwbUnidydJlxirQswkwMbPqXkeCVtNGFJRkchvzFgsmzUfzSIwcKjgJzBnLOpXzdfzvzcpDuDwpBOVQJuhbRRmseiBuzfLCJyvpUGT");
    int RobOlDc = 282571745;
    int AgvOrQGs = 1002927238;
    bool eDZSmRQTLv = true;
    double hZYWZFxLdkEqmiBY = 533352.6762440336;

    for (int KfzICbcOULb = 1608903822; KfzICbcOULb > 0; KfzICbcOULb--) {
        RobOlDc *= AgvOrQGs;
    }

    if (DsfLnowfal >= -847832.4826410514) {
        for (int SMfeCKDZWSb = 1893471033; SMfeCKDZWSb > 0; SMfeCKDZWSb--) {
            hZYWZFxLdkEqmiBY += DsfLnowfal;
        }
    }

    for (int sSlPXLjDujErD = 976061216; sSlPXLjDujErD > 0; sSlPXLjDujErD--) {
        xVYzY = ATpgIfmEnnciCSq;
        AgvOrQGs += AgvOrQGs;
    }

    for (int nyzabTILdxY = 719823183; nyzabTILdxY > 0; nyzabTILdxY--) {
        xVYzY += xVYzY;
        xVYzY = xVYzY;
        AgvOrQGs += AgvOrQGs;
    }
}

int RkspOqDmwhYDlYBT::wwxfhOplvxg(double KhuZCTiPSfPPoj, int QZBXHpEweYPMj, bool WxFCEJNDL)
{
    double tSlzpAiuvbzfoaB = -21876.00098151087;

    for (int KpQsjaqklFyEKV = 1169373717; KpQsjaqklFyEKV > 0; KpQsjaqklFyEKV--) {
        continue;
    }

    if (tSlzpAiuvbzfoaB <= -447930.38284692174) {
        for (int SpIuIHufXce = 172993165; SpIuIHufXce > 0; SpIuIHufXce--) {
            WxFCEJNDL = ! WxFCEJNDL;
            KhuZCTiPSfPPoj /= KhuZCTiPSfPPoj;
            tSlzpAiuvbzfoaB = tSlzpAiuvbzfoaB;
        }
    }

    for (int MWjeIdfzMndTfga = 268733394; MWjeIdfzMndTfga > 0; MWjeIdfzMndTfga--) {
        continue;
    }

    if (tSlzpAiuvbzfoaB >= -447930.38284692174) {
        for (int asxEaRvMmKSbQsO = 973601313; asxEaRvMmKSbQsO > 0; asxEaRvMmKSbQsO--) {
            tSlzpAiuvbzfoaB = KhuZCTiPSfPPoj;
            tSlzpAiuvbzfoaB -= tSlzpAiuvbzfoaB;
        }
    }

    for (int pwjpbUbyslqBsx = 1425257182; pwjpbUbyslqBsx > 0; pwjpbUbyslqBsx--) {
        tSlzpAiuvbzfoaB -= KhuZCTiPSfPPoj;
        QZBXHpEweYPMj *= QZBXHpEweYPMj;
        KhuZCTiPSfPPoj -= KhuZCTiPSfPPoj;
        tSlzpAiuvbzfoaB += tSlzpAiuvbzfoaB;
    }

    return QZBXHpEweYPMj;
}

int RkspOqDmwhYDlYBT::hMgQWJsZR(double CuCJuuhAZm)
{
    bool iyFwnPM = true;
    bool aRGqp = false;
    bool TmplIwmkjPlKTJ = true;
    double TfMOKhSI = -214345.86449258678;

    return -444555747;
}

string RkspOqDmwhYDlYBT::FQcxGsEH(string yhreSGfUitTuOfs, bool dufuwVGCwlZSuGm, int bVDKu, double oEjyLSHhLzhAO)
{
    string sdjBczKLXazAuZl = string("ifRFqUNHQfqAsnDBKY");
    double bnAAHjUs = -917734.86990195;
    bool LtpbkxuVtFkZdSXd = false;

    for (int nIrfIzQU = 1820444396; nIrfIzQU > 0; nIrfIzQU--) {
        LtpbkxuVtFkZdSXd = ! dufuwVGCwlZSuGm;
        yhreSGfUitTuOfs = yhreSGfUitTuOfs;
    }

    for (int aPGISmtsiZ = 1052837876; aPGISmtsiZ > 0; aPGISmtsiZ--) {
        bnAAHjUs = bnAAHjUs;
        bnAAHjUs += oEjyLSHhLzhAO;
        sdjBczKLXazAuZl = sdjBczKLXazAuZl;
        sdjBczKLXazAuZl += yhreSGfUitTuOfs;
        yhreSGfUitTuOfs = sdjBczKLXazAuZl;
    }

    for (int ljqdfMkUrLgJ = 2093221028; ljqdfMkUrLgJ > 0; ljqdfMkUrLgJ--) {
        LtpbkxuVtFkZdSXd = ! LtpbkxuVtFkZdSXd;
    }

    for (int eyuYbGwrGwRVWm = 1401059645; eyuYbGwrGwRVWm > 0; eyuYbGwrGwRVWm--) {
        continue;
    }

    if (yhreSGfUitTuOfs >= string("ifRFqUNHQfqAsnDBKY")) {
        for (int tFfRAHKJqUpQm = 39277724; tFfRAHKJqUpQm > 0; tFfRAHKJqUpQm--) {
            continue;
        }
    }

    return sdjBczKLXazAuZl;
}

int RkspOqDmwhYDlYBT::fnFYTGukqEN(int hjpyRANahGZgpjBD, bool OGzYMEyOs, int JhqXemOImCgq, int dfrEEJdHnhzDYg, string LWoTpK)
{
    string cyjsSbhfStPr = string("VPwMjjBOPHoheAsyxXLknbmbvzGrpJwDJMFBoHeoTgChpHh");
    double eIhkoKH = -307447.7136798846;
    int tQOTVPDrZIHU = 452503714;

    for (int PqqvISrs = 1896727191; PqqvISrs > 0; PqqvISrs--) {
        dfrEEJdHnhzDYg += hjpyRANahGZgpjBD;
        hjpyRANahGZgpjBD /= dfrEEJdHnhzDYg;
    }

    if (tQOTVPDrZIHU != 57489641) {
        for (int SnLulJVioWPjY = 1796906843; SnLulJVioWPjY > 0; SnLulJVioWPjY--) {
            hjpyRANahGZgpjBD *= JhqXemOImCgq;
        }
    }

    return tQOTVPDrZIHU;
}

double RkspOqDmwhYDlYBT::HbUrIGoSKKVXUPa(bool eaAQCKIyiBmTA, string PWsnpINaYWenkIUP, string UHBXFsOBKGRps, bool zozPbTpbKrHgR, int whmEpuRHauoip)
{
    bool CsSWjlX = false;
    string XrRaAyTZhz = string("WhZPTTDyMbgSIqCznUULdcguIT");
    double kSzvhkgw = 345145.27928754396;
    string sZAHHCpzayfbvIZ = string("BJRGUdcIpTYPTzdlUZccMUweQwLXkKbSDwOdvNHHCJonXkADsefnmXAlhRWtOSyDJIeaTEh");
    bool ThyuegOWOEyJCU = false;
    double QNINid = 207593.40566782595;
    bool ENONOZYYYQolr = true;
    bool XWOuwuQRuvQfHT = false;
    int tsmbJUubzbK = -2100509023;

    for (int RcPhU = 1438111387; RcPhU > 0; RcPhU--) {
        continue;
    }

    return QNINid;
}

string RkspOqDmwhYDlYBT::tKRNGhjsJlvi(string FFCKRCFfnd)
{
    string nmeElzHqFp = string("AbZUscgDZDZvlZuXxcUDAlPeDNPFprrApurCnTkIpwDBoKLSwGhcfTswUmiUMfMrWDWGqdmbXDQfvXohkJprsqvSCPSAcCkznTsLInetCEqvSrVCjonDvwMUmvFskwOvFtsWiMYZQTE");
    string NRbARM = string("qacFNkgSlRuLRKbDZsorGEAjSaedyifqfMZjZxBREbnZoQpXEbvlRlzOkMQqCEcwEfnuEnrrvrdeBxXCRCtuQbMULLPcKF");
    string ClRVu = string("GOdCYmMpEzmLAOonlCWzfQygnGctQjvwERtFgCZtnKnULZxbvEWlVibcYawZHhbFQkjIJrQGleFOsGqXSkbHEccdLvDcgQGDAvEPdfElNJgNYiYEBniPoDmzFXiDrlPlunJsXDyzlXHZLeTbzXoWIlYXAdFDFgGJwQAJTGxSwchmuvf");
    bool axgoDTeUJO = true;
    string MQliLgrcQ = string("WzAKWqYuylnHpjJvNSWfkLlQSHPsQMSUrTsiQlfneNopWROcnivqGvlaRmbsFeiSrooLROFZPAJcOmkGDviBSRUIKNDfdSefeFIPlQeQLKErVSHqhuKFqDIOnycwAr");
    int FyaaWhBGqJgd = -1125893409;
    int yFJWzcOj = -1201106664;
    string YmtxxTbudneezk = string("PWMAjqpYFhnTHNJqDmVYYezArVOQjXwEdbxSVOJjwWxOwfOMdVooamlNshIlPerItAaMIgHHWHjJwtPfrUmnNhjIXpjSQIkWKTyfXwfBOaBFdHGZwKwTBlZipbCrIEPsNafbIiZqPplQYZQYSWgVfWSGvjskspIyoiEDgtnvzFBsIAmLqDkCCDNwGywpVKgvYDfdHNxYpHhPQBUIjGwzQBpKCCBUNnTjVhPTqnKbZHcjPGoQIRkheHxevCj");
    string JsEEuhvonxIT = string("PFWtWvsGuaduoMxSMBHOnAAOmbmZwopEggzvLlmXtiBgVUqFxqwqLUjpgRnKOJhEUKJTZPejqkhBaXEbdOkxAuNuKHdyrLkdeKddNDmmSpNghWPNmfmwTZnBYXGLCOKDlMoYSVysmTdsfQXApMhMJSpkVmvecCqffmhQxhmUstwsqdMBTyGHHUgAlWVZcMDUhLaueaUWgMQQoAPgdpKELyGyYsRnmryhpk");
    bool xDPlOVsTp = true;

    return JsEEuhvonxIT;
}

void RkspOqDmwhYDlYBT::YqdWeuSr(bool yhYxszcJSbZ, bool gIUdBOMDTZsseN, double bfLbMbCtUtTSUp, bool nURhILLuA, double WCSuebNnVW)
{
    string hIjtiVPxrzz = string("AlNsnkfidkJtDyGQCvCDXruHOyDXnrkuIlysGOnaqDsMmqdXHLZqldFcLwVpVfaPWNxmOsEWDtxppqUKhDlYFfxpSYipdKQBLFfDadGNkYPlOaairbEAihgUDDOUVJNtBTaJrJPuerTtzhrCNhOuHWDtnSnYrGUGtgEbWQKdhoDvBonMNFmBDsEnGBHWlrCYfaGKaYMOqtEGcAjXEyR");
    string KXAbLgEWA = string("orsUHXNeDWXtjIAEvQxGoCTjFhwaJsUGzsbPdeAxlEkFNADDIDYTMBTLYNFhcFJuZdytiDWEEpTcCJHtwXDczGZkVxfxFTCxWIBpIaiDdajicNSxmZgsJGYXWZzBkUsszjjHkGtvcGWiKoqdwPBaAOLNFIGr");

    if (nURhILLuA != true) {
        for (int GKlKGpkBq = 532684296; GKlKGpkBq > 0; GKlKGpkBq--) {
            nURhILLuA = yhYxszcJSbZ;
            WCSuebNnVW += bfLbMbCtUtTSUp;
        }
    }

    for (int YLDbD = 637770907; YLDbD > 0; YLDbD--) {
        yhYxszcJSbZ = gIUdBOMDTZsseN;
    }

    if (gIUdBOMDTZsseN == true) {
        for (int CWBLPgpQXeyvbfL = 2081689661; CWBLPgpQXeyvbfL > 0; CWBLPgpQXeyvbfL--) {
            nURhILLuA = ! gIUdBOMDTZsseN;
        }
    }

    if (bfLbMbCtUtTSUp <= -1044539.6188937156) {
        for (int hwHZHZAAnACmtAme = 1153277423; hwHZHZAAnACmtAme > 0; hwHZHZAAnACmtAme--) {
            nURhILLuA = nURhILLuA;
        }
    }
}

bool RkspOqDmwhYDlYBT::UvrhSX()
{
    string XfAhdiOzihdAW = string("QCnmdApJDYdeAUtUIfZhWxoPxXnoDJCzQKeSMrnNWUXzXtOJpAzHOdXoxYIaHhZUPgeCOwWZSmhOXrYDLHsvPzyqvJsdnMnActgHArfuFIwycCDascbbwuMdTIDqVsiVIaVmKjIJxBljhHOCFmgjylbBTvaEkOKLryPFFGbQwNJnAJ");
    int AzmhDHffdzyA = -239991906;
    int iABNhfbHJPc = -700631762;
    int QyZGSY = 563555627;

    if (AzmhDHffdzyA >= -700631762) {
        for (int JHyvFSEvhAXwOC = 153363271; JHyvFSEvhAXwOC > 0; JHyvFSEvhAXwOC--) {
            iABNhfbHJPc = iABNhfbHJPc;
            QyZGSY = AzmhDHffdzyA;
            QyZGSY = AzmhDHffdzyA;
        }
    }

    if (AzmhDHffdzyA == 563555627) {
        for (int ZUXJb = 2118453249; ZUXJb > 0; ZUXJb--) {
            continue;
        }
    }

    return true;
}

void RkspOqDmwhYDlYBT::qPelwgUZEgS(double IxOjkrKGuhORKRP)
{
    bool hnZeDFu = false;
    string jBgPUfnIymDPfCL = string("FPIEzQvkVhAFtmNNTGgROs");
    bool gIhMxcCBurkMxL = true;
    double BUyIKKfGePWKT = -577875.8636885616;
    int ecIXCtBh = 785822090;
    string FZFwwk = string("WOjoyWrxYWjbiKUZdTUYIdSjboPbkkqVKexLNowNTGaTNYuqeOAaCgwYeZbLxOGNRqeaWOuNrmVLHOVMrZeUdmTgZepOyhjEMyzGzhsiPEgVqPw");
    int fBbotn = -1362196188;

    for (int vSChmIbg = 269250572; vSChmIbg > 0; vSChmIbg--) {
        gIhMxcCBurkMxL = ! gIhMxcCBurkMxL;
    }
}

bool RkspOqDmwhYDlYBT::WHNeZhNoNqam(bool FastvdGgj, int RWYzCIGtM, int QFUSwwbNSZFKUto, bool BFinfcD, int JMfPBpTT)
{
    double jeVBpt = -912526.2369867464;
    bool TqQPhzMpOWlfTE = false;
    int MvRYe = 644722010;

    for (int EEDLhan = 394833508; EEDLhan > 0; EEDLhan--) {
        BFinfcD = ! TqQPhzMpOWlfTE;
        BFinfcD = ! FastvdGgj;
        TqQPhzMpOWlfTE = BFinfcD;
        MvRYe = MvRYe;
    }

    if (RWYzCIGtM > 644722010) {
        for (int NcPeL = 979652985; NcPeL > 0; NcPeL--) {
            FastvdGgj = FastvdGgj;
            TqQPhzMpOWlfTE = ! FastvdGgj;
        }
    }

    return TqQPhzMpOWlfTE;
}

string RkspOqDmwhYDlYBT::yggwxMSNrZ(bool KyLIifVWsSQQts, bool llzYGwaAt, string KbViaIIDhQa)
{
    double enylUJO = 86293.090787401;
    bool XgcXifcufH = true;
    int IoMZhYVpTPVOVY = 968055073;
    int NjIilMokl = -1534575542;
    bool IdRKQ = false;

    for (int MtiGi = 238570352; MtiGi > 0; MtiGi--) {
        continue;
    }

    for (int sDcnOHTekLrBCTAv = 1836402530; sDcnOHTekLrBCTAv > 0; sDcnOHTekLrBCTAv--) {
        IdRKQ = ! IdRKQ;
        XgcXifcufH = ! IdRKQ;
    }

    for (int JIijNzUvaFpFluB = 2144512069; JIijNzUvaFpFluB > 0; JIijNzUvaFpFluB--) {
        IdRKQ = XgcXifcufH;
        IoMZhYVpTPVOVY += IoMZhYVpTPVOVY;
    }

    if (IoMZhYVpTPVOVY > 968055073) {
        for (int zNkVgBngXHbgEOI = 974392252; zNkVgBngXHbgEOI > 0; zNkVgBngXHbgEOI--) {
            NjIilMokl /= IoMZhYVpTPVOVY;
            NjIilMokl -= NjIilMokl;
        }
    }

    for (int QQOiLCWghg = 2090459726; QQOiLCWghg > 0; QQOiLCWghg--) {
        KbViaIIDhQa += KbViaIIDhQa;
    }

    return KbViaIIDhQa;
}

RkspOqDmwhYDlYBT::RkspOqDmwhYDlYBT()
{
    this->RcCDGfqyWDsXgF(string("faSTSZoVAZGroAltWxxXVVzLuTAYOeDdogwBKNOIftESLQUZcxrfKCCwdKJSeOjchSfDTsfSKOeGPvuDOrvqqyHZYvSiHovYIgZaeEuIfNSehlNtUZKqMYcpSSZVnuRx"), -260275.8882558402);
    this->oWSVHFuCqQGjX(false, string("kMGmbIzoWfMuclmkFobEQTtldtldthrnnFpNLXNqQGYDSTbNnmlyDflPttGlRBhFPGcRgHbcAlIPlRJjXCNTHijANNaCaTkrzqxlnMuqHQzrloDFbpUdsjCGujuDEWdjaUxLndsFRAZoSOqdeywFJLgXFBcQhWKEvcJXStXexrQVnraomntfQaJwvmQZxDpW"), -910562.711148839, -221165.35607256996, -955211741);
    this->LWuCqRqmqsL(662767.2686535869, true);
    this->jGjWSuLEenqfYbHI();
    this->DIAOWbUp();
    this->izqCWUMKqNwFC(string("IPMMkJCYuCcmPpOQfhUBtgKieVdTywlyVLozHxxrTRsJJigGLgOZIQNWvLuyOwObeKWSpGeFpqCbuEWQNtzkRIlagwOFEQArVmBnCUPJBabGIqkuhRNFdBjtWAyRJBTWTDUzmPwHbMRWmlxhFFWLKduSXBQcGgndiMSggyhykemewhupbYcyrbSZuuEqtgMobFpffQNWMZhPUPRBJmfguIVDSYBotpzrRdzCqXfeLuFRymRvEn"), true, 747121035, -892413.5253991237, string("kqwOKmcyJoUMdjlQTRyGBXDfMsJFwTqoFWILMdfjSlxFjBhkVlVONniojpOzZknJPnTOdywKlRI"));
    this->kxzYKZrKeThMUatG(790077.944712684, -1635502889, true);
    this->Byntj(-426501.52002327575);
    this->PuWLzD();
    this->wwxfhOplvxg(-447930.38284692174, 336987264, true);
    this->hMgQWJsZR(-798345.4466572191);
    this->FQcxGsEH(string("UPGYYEOXodZyYGFOYyTDCFcJQNmhPSSdcxVNDFjBXvnPDJLeAGIXLtJpBBboJbRfbTsDcieJkXTbxTZhLmOzsYYrlRnJxKZQoixJtNecLVeuajxZVUkITVEMVtbkWlaMfkEmzSSGfgqrsvUmCLLDRGpCeEFcurnANHERgUWxXonMSjEhdKAanuYpasvpsTZzUIgRGYXhulrdoHFLgKMnorsRcoyOSKsPaSQBD"), true, 1553032326, 454568.23054063425);
    this->fnFYTGukqEN(-1381207316, false, 1774717514, 57489641, string("IikboiokPPlRKbyCKJlvhcbxujGiQELLVvzhaxxxnGAUltHJbMhHdGdWvIHgDFTZmwEKSCvP"));
    this->HbUrIGoSKKVXUPa(true, string("rybVDzJcVOJEadjHwMDsGbgyIVlGZPzgvolSezMkDhEoXgGTaYAayDDRukgJNcmOPcyrtMfGPgjmOnJJCgoeOoJkrTJQttjBYpbXbxLwCKtTosrIiDbIPHxVIPhZxXHdnbKESEOkaZWSPuDGszICnfIoObXFoyyAPnyzhJoZPEpNUKwIbtbHZjmeNvBttFJaubViXtGaxtlFRMsJaLQXgEphSTuScDdWbvAqo"), string("qRnVDweJIRrYYPwsdHKfnPiKiTdhLTvsPxGVyLlsttgGQvrAHMteCZkxvJSUEDVhTRxbURaHplHAZLWSJYxkwyCHPASLsYapYCcZJtNTaYUNuJUvCAMrFnIrOnSJlFeExGhgHxhwwjBQmltjSqAGTPgoeGmOOxbrWYqeRmcGcpfopUUuRSmuLZyABdrrXkwsgQIlSGRGyL"), false, -402586315);
    this->tKRNGhjsJlvi(string("HQzZTLsnRroDmJsOcH"));
    this->YqdWeuSr(true, true, -1044539.6188937156, true, -207415.18101894474);
    this->UvrhSX();
    this->qPelwgUZEgS(983720.1139836954);
    this->WHNeZhNoNqam(false, 51238081, -873948144, true, -1974798058);
    this->yggwxMSNrZ(false, false, string("EnxtJhwIBdFBDIcBtYQBkiLPieDdxZAFAyplUPOrTHKlOiNfSLgJpvQrBbRzCIjdrHpfxLaboZoffmEncBtwAdfPJWlVTQGgegr"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ofzvKEs
{
public:
    string XpfRquFb;
    double eYfvuUCL;

    ofzvKEs();
    double UtirZU(bool TdlLhTDrYoMfiO, int IHoYeeBlz);
    bool wSiCSccBpwEpnEf(bool Okevx, double KXLgjtTcc, bool QCsQnePKSiuIKxI);
    void jfRUqs(string PDDLvJfFqePLqybZ, int dGJSfPaxFVbhn, bool xkHGoowLx, string iOGcaT, bool sCMjHCKEjyUeg);
    string KKtNUphw(string ZdTumBMvtlvcGawv, string LHDSGYDZnYx, bool LxnxoejC, bool mswzJaKEmsr, double IxNoQNXTxM);
    void qpNoOSWwMfTJNGl(string hWGMUav, string gJIqn, string tpVmVlIajTZHLQDW);
    void ieIhXKMbo(int FxstbQb, int BTBeRJumnJwmqGX, int PtdUt, bool lfZnRd, int iykKqiNGY);
protected:
    int JIDHDkft;
    string JjSuRWgzUsU;
    bool BxSlxchfBUXKXm;
    string wIaRADRQINZPjfec;
    bool rywqT;

private:
    bool mLltrgTL;
    double fhoazbgEhEjl;
    string TxhYpqPjZiAPcx;

    double EWafliMbDWFI(bool IiILDD, int qMBhJkEkFmCwvIy);
    string ocbfoygteuRnnt(double scbJTXoGzkvz, bool AtTnoFqXHUHulBEW, string bwzesg);
    string BqrdarwovVrt(string mEsryGbZOCwDXw, bool dJuoppsQiFC, bool yKEQPfOQbMBWrmda, int xHdaK);
    void EvMCZdQkrAyWO(int WPyCRXx, double fFgWDA, double SqgciVYZlpfdU, string wIcTQfWlnrXz);
    string gAUxCvOWfImzIzKQ(int BLAEwjfACAeC, bool BUKuraLlR, bool DqKuzWCWDPll, int HrSGSaHmNFs);
};

double ofzvKEs::UtirZU(bool TdlLhTDrYoMfiO, int IHoYeeBlz)
{
    int jFvgkQiJNm = 766792842;
    string CRuxnaK = string("aDOWadQEruyFMazDmrHHBeFWkbJFVcqRwTXkJwVUfdOWgDLMmiGQagrOLlmUCumdGhixFGXSQgCxrKmlmZfnFCUcNqlxhYQqsstnXpPrRmugzljkYEAQLRzNHFrQuBQLuLbbjJMSEZpSlxnHKJBmCJgjNjzplFBJmtOPTBFssAwqnFypWkEjkDZMVdHtbGPoqfyCylxMsxKGPmCQx");
    bool SwpCtzBzVFveKv = true;
    string bGrwvgrTgJbKeRtc = string("EYlBlLfjZmEGPTBxUZrmZyTmIXUXNXiHuifHfcvrLdxABftHIKgjdBxWxdcWuHBWqAVSOZptPQMPgWZKrketLobYupNRMefeKmtWUKccKUfVqhWkNjklAoLPQmWCyT");

    for (int WwPGDmx = 1497181519; WwPGDmx > 0; WwPGDmx--) {
        jFvgkQiJNm += jFvgkQiJNm;
        CRuxnaK += CRuxnaK;
        bGrwvgrTgJbKeRtc += bGrwvgrTgJbKeRtc;
    }

    for (int zVnUo = 599975402; zVnUo > 0; zVnUo--) {
        SwpCtzBzVFveKv = ! TdlLhTDrYoMfiO;
    }

    if (SwpCtzBzVFveKv == true) {
        for (int yFjsBvNVfGDbmGpG = 1704527896; yFjsBvNVfGDbmGpG > 0; yFjsBvNVfGDbmGpG--) {
            CRuxnaK = bGrwvgrTgJbKeRtc;
        }
    }

    for (int cEyuzehrovkTo = 829539349; cEyuzehrovkTo > 0; cEyuzehrovkTo--) {
        bGrwvgrTgJbKeRtc += CRuxnaK;
    }

    if (jFvgkQiJNm > 766792842) {
        for (int GOkyrHISyBBPKf = 1648476266; GOkyrHISyBBPKf > 0; GOkyrHISyBBPKf--) {
            bGrwvgrTgJbKeRtc += bGrwvgrTgJbKeRtc;
            IHoYeeBlz *= jFvgkQiJNm;
        }
    }

    return 350571.68461972545;
}

bool ofzvKEs::wSiCSccBpwEpnEf(bool Okevx, double KXLgjtTcc, bool QCsQnePKSiuIKxI)
{
    bool WdLtnnIBaloRnz = true;
    double ZaNav = -301845.0349290241;
    int WFZLzzMHLfHyZpQR = -1906386674;
    bool bQDVlhBDa = true;
    bool ibSRdBuDmlkDiqJF = true;
    double WIGypDreEI = -557635.5940358876;
    double sHVjAtyn = 457043.6767251921;
    int uYzHClNGaR = 876131262;

    return ibSRdBuDmlkDiqJF;
}

void ofzvKEs::jfRUqs(string PDDLvJfFqePLqybZ, int dGJSfPaxFVbhn, bool xkHGoowLx, string iOGcaT, bool sCMjHCKEjyUeg)
{
    double PgZYEPwLsXiUg = 202724.4948030246;
    int yxEIHUopDIFH = 71762260;

    for (int sqaiTrdJgtNrNubp = 1813551499; sqaiTrdJgtNrNubp > 0; sqaiTrdJgtNrNubp--) {
        continue;
    }

    for (int VCeZlA = 1614811841; VCeZlA > 0; VCeZlA--) {
        PDDLvJfFqePLqybZ += PDDLvJfFqePLqybZ;
        yxEIHUopDIFH *= dGJSfPaxFVbhn;
    }

    for (int xpFQdJI = 2101916579; xpFQdJI > 0; xpFQdJI--) {
        iOGcaT += iOGcaT;
        dGJSfPaxFVbhn = yxEIHUopDIFH;
    }

    if (xkHGoowLx != true) {
        for (int bBTysswLsDsS = 634784335; bBTysswLsDsS > 0; bBTysswLsDsS--) {
            dGJSfPaxFVbhn -= dGJSfPaxFVbhn;
        }
    }

    for (int hfzsinh = 2115745405; hfzsinh > 0; hfzsinh--) {
        yxEIHUopDIFH = yxEIHUopDIFH;
        xkHGoowLx = ! xkHGoowLx;
    }

    for (int FHoIVXO = 1834504087; FHoIVXO > 0; FHoIVXO--) {
        continue;
    }

    for (int xSoEaapPzL = 1450888272; xSoEaapPzL > 0; xSoEaapPzL--) {
        sCMjHCKEjyUeg = ! xkHGoowLx;
        xkHGoowLx = ! sCMjHCKEjyUeg;
    }
}

string ofzvKEs::KKtNUphw(string ZdTumBMvtlvcGawv, string LHDSGYDZnYx, bool LxnxoejC, bool mswzJaKEmsr, double IxNoQNXTxM)
{
    int cRlAMZXkJYCcK = 482210051;
    double hbACv = 893437.6327003427;
    string CAjFpohwLKyVtwAA = string("fxjfSLeOhOREnbYLTIPThsYSIufkdNHQt");
    bool CDgeAIFeXoayk = true;
    string PoTOmyyS = string("yecnFOzTInkgKIfGkAgYyZAKqIWCXpSuFhtBXFhKEnnNsLFgkzBUtGXdwmQOlILWSUyaJVfBLgbkmKDfCFtsCpGKXjuTqrjBFOPhpiZGFwopLJmBbncGpLZiUDRSNnuNRveEVNFpjiKOLFEFKNBNzfMOYPMxsLVGcUsfm");
    string bFYNbmqPmBCVMz = string("HHjnBjJfhsnpkbkyvsWKcXwCjlKYGMcdyQdIrLchRXshZIBgdeOVrNUfZNVCxWnFlFfrJrJbOQNGJGiKyEfWoFwlwiTYVSLqHjjDVDUWQwkAtptONDHrWfmprCYdyTIZfUqIQDnMZujiddXtBcWhakqDacQxVDIkZNwBFqycyySHFmFuxpOvRlFcSOOJDzZpDAjOGEsKjfdKvqdhaZJPOcefVyWvVxCoklnsbIstPZZvbmBXQODv");
    bool cnLsnJ = false;
    int vYeAx = 375741196;
    double oUMVtamuRihA = 813246.0186621569;

    for (int xDOSyolpZLQkp = 441596050; xDOSyolpZLQkp > 0; xDOSyolpZLQkp--) {
        mswzJaKEmsr = ! CDgeAIFeXoayk;
        PoTOmyyS += PoTOmyyS;
    }

    for (int JQcIiIWVTGFyff = 810191883; JQcIiIWVTGFyff > 0; JQcIiIWVTGFyff--) {
        CAjFpohwLKyVtwAA += PoTOmyyS;
    }

    for (int rJJMabPQMKrRF = 1710863282; rJJMabPQMKrRF > 0; rJJMabPQMKrRF--) {
        mswzJaKEmsr = cnLsnJ;
        LHDSGYDZnYx += LHDSGYDZnYx;
    }

    return bFYNbmqPmBCVMz;
}

void ofzvKEs::qpNoOSWwMfTJNGl(string hWGMUav, string gJIqn, string tpVmVlIajTZHLQDW)
{
    double bpkhrmoZ = -536838.517067109;

    if (gJIqn > string("crS")) {
        for (int ANKiJkCOXzWLeUn = 1645128298; ANKiJkCOXzWLeUn > 0; ANKiJkCOXzWLeUn--) {
            tpVmVlIajTZHLQDW += gJIqn;
            hWGMUav += hWGMUav;
            gJIqn += hWGMUav;
            gJIqn = hWGMUav;
            gJIqn = gJIqn;
        }
    }

    if (gJIqn <= string("crS")) {
        for (int vasDAHnuVWAnrq = 1528319732; vasDAHnuVWAnrq > 0; vasDAHnuVWAnrq--) {
            tpVmVlIajTZHLQDW = tpVmVlIajTZHLQDW;
            gJIqn = hWGMUav;
            tpVmVlIajTZHLQDW = hWGMUav;
            bpkhrmoZ /= bpkhrmoZ;
        }
    }

    if (bpkhrmoZ < -536838.517067109) {
        for (int ZrKxu = 461598014; ZrKxu > 0; ZrKxu--) {
            hWGMUav += tpVmVlIajTZHLQDW;
            hWGMUav += tpVmVlIajTZHLQDW;
            gJIqn += tpVmVlIajTZHLQDW;
            bpkhrmoZ = bpkhrmoZ;
        }
    }

    if (tpVmVlIajTZHLQDW <= string("xNRqcdmEELq")) {
        for (int EyPvcO = 1994301060; EyPvcO > 0; EyPvcO--) {
            hWGMUav += hWGMUav;
            hWGMUav = hWGMUav;
            bpkhrmoZ *= bpkhrmoZ;
            hWGMUav += hWGMUav;
        }
    }

    if (tpVmVlIajTZHLQDW >= string("xNRqcdmEELq")) {
        for (int mBiPlsJSZppvoYUu = 233738439; mBiPlsJSZppvoYUu > 0; mBiPlsJSZppvoYUu--) {
            hWGMUav = gJIqn;
            gJIqn = tpVmVlIajTZHLQDW;
            hWGMUav += tpVmVlIajTZHLQDW;
            gJIqn += hWGMUav;
        }
    }
}

void ofzvKEs::ieIhXKMbo(int FxstbQb, int BTBeRJumnJwmqGX, int PtdUt, bool lfZnRd, int iykKqiNGY)
{
    bool swCCoNlD = true;
    double dVhoPKeZ = -363923.0061263249;
    string uWDtwykv = string("WAInuyOXiUvKVGYPURSrqWnAkBGZfTdZBSwJAJdqAjXezfGMYBYvIRAfngNoJIoKcWyHdNrUbvhtIqQRWStnOCDxhCbXAvEfAInla");
    double fYtmUwFVcCuCRMR = -831617.9941853945;
    string QYFesqzDStso = string("YbXoHDkGIzImoKQRnvkRWJugpupOAWarRsxzojFqnhFTYSgYCLkDbmYjoOyC");
    int CIZAYMeNIWjoc = 393567958;
    string ZcWhlUNBQDx = string("NFkDkvYzwtuKwhUychDnoxzHoRGNCSOkpOCVhuyXHTjuZWMjoMHvZxWqIDDtkvStaHRXUqvGMnjOkroRUoGbovmGLSxyNBYuaXfymHOGoLSdLaQEELeSRIuQBnxarbCLxxnpzsnAVTbLUQRduoAagESDHcJbcfmuJpJQvRfvOPoKajijrpgDjVBbKoLtOVzGEIkXWXNxicrTwQxSyRxYcHJYdwQfoRmNPgCOlgrOadxWcuZqeB");
    int WRvhihCx = -367435699;

    for (int LvnILBLeorZes = 1543600145; LvnILBLeorZes > 0; LvnILBLeorZes--) {
        QYFesqzDStso += uWDtwykv;
        FxstbQb *= CIZAYMeNIWjoc;
    }

    if (dVhoPKeZ <= -363923.0061263249) {
        for (int fQxGG = 445105404; fQxGG > 0; fQxGG--) {
            continue;
        }
    }
}

double ofzvKEs::EWafliMbDWFI(bool IiILDD, int qMBhJkEkFmCwvIy)
{
    string ukgsSMQGItX = string("GawLEsBaKelvuTSIUCafgGYBlsjRNiURcthNXvRPUaSsMgmCpLbnpdKeRMdWmCTCRgyMErnCGvXsCvJvgGOFjiccfcojWRXoNggNmXg");
    double AEfLVGiP = -130268.32327470316;
    string lxKKfBYHqGXpm = string("XsgFELfnJKoagycObMVzQCJSrUSXsnzwibaJhWwXzeDrGaKhzlUzQAXLFLeRRJxNJRjtbUtYqJpxOSeyhYabrjVyoLGtxlFWySShSFTjfmYKsvYQUbF");
    double lIHsrD = -258653.7386223538;
    bool CFOVnJVp = true;

    for (int HlILptUzHSEQQda = 15144448; HlILptUzHSEQQda > 0; HlILptUzHSEQQda--) {
        continue;
    }

    return lIHsrD;
}

string ofzvKEs::ocbfoygteuRnnt(double scbJTXoGzkvz, bool AtTnoFqXHUHulBEW, string bwzesg)
{
    int LbMVXxzGGtNd = -840613476;
    int OzReCCqF = -2123793069;
    string OODkloYcHv = string("jCSvlRFOgGmSOrkFPikYcAmdDkINvbKmUTZnNanDWGBXYHYNWjDjUywrIjkAOivHOVdbiRoGYaOgGXsIBUIQOrhFSrYPpYqonXIwVtyHLLNOBnBFYevySZjIPIMMnuKBzVXcjVxiDGfpONmeGVanWWVmCLnHcTQcdBBnDfXwXfnieZOwyDPQHtxIhOaKdKBNPhYivhYLKqZoURWWTxMSSFpd");
    double KonNtMnnBEUPa = 747570.1882648509;

    for (int pNsRfEDjic = 1781399680; pNsRfEDjic > 0; pNsRfEDjic--) {
        continue;
    }

    if (bwzesg <= string("jCSvlRFOgGmSOrkFPikYcAmdDkINvbKmUTZnNanDWGBXYHYNWjDjUywrIjkAOivHOVdbiRoGYaOgGXsIBUIQOrhFSrYPpYqonXIwVtyHLLNOBnBFYevySZjIPIMMnuKBzVXcjVxiDGfpONmeGVanWWVmCLnHcTQcdBBnDfXwXfnieZOwyDPQHtxIhOaKdKBNPhYivhYLKqZoURWWTxMSSFpd")) {
        for (int vJlLzVVUox = 579489539; vJlLzVVUox > 0; vJlLzVVUox--) {
            LbMVXxzGGtNd -= LbMVXxzGGtNd;
        }
    }

    if (LbMVXxzGGtNd > -840613476) {
        for (int XeQhrCW = 1557014382; XeQhrCW > 0; XeQhrCW--) {
            continue;
        }
    }

    return OODkloYcHv;
}

string ofzvKEs::BqrdarwovVrt(string mEsryGbZOCwDXw, bool dJuoppsQiFC, bool yKEQPfOQbMBWrmda, int xHdaK)
{
    string yPRvgxqMLMTBMfMC = string("ZaJIyjfwynSRAmOTYHlTYSACPZHShcaaXtEiFasNbmpnfMrBbQwgkoKbZhUQqJVyIqCQtDGXeKfbRIfOtWPEE");
    double OLLpBqPlGLmbWCYO = -112352.1656567221;
    double xPTuSoiqnaEemg = 343622.1722653117;
    bool wbLhypRuXCq = true;
    int pImtiGculqSv = -1845275821;
    double XWOGo = -375757.6181306666;
    string SZmVwnF = string("NsHSBKSaeLjmOeTfQAEZxLuZIIoLpumbbeOyXzZVjQIzfRQtHttoLjjoOEVUnKFEDOKEcr");
    int qoqDuVYrxtb = 252335890;
    string oelKzjYgVUcx = string("IQOvsjDaELrisyfDYmWivPQvpQgZZXOMBngF");

    for (int AZokagrxWrEqlKW = 312400272; AZokagrxWrEqlKW > 0; AZokagrxWrEqlKW--) {
        wbLhypRuXCq = wbLhypRuXCq;
    }

    for (int xnpeJulOyi = 1333058530; xnpeJulOyi > 0; xnpeJulOyi--) {
        continue;
    }

    for (int dxuLqSFLiu = 2055947541; dxuLqSFLiu > 0; dxuLqSFLiu--) {
        yKEQPfOQbMBWrmda = ! wbLhypRuXCq;
    }

    for (int emBFYnfuhHxFR = 1454060316; emBFYnfuhHxFR > 0; emBFYnfuhHxFR--) {
        mEsryGbZOCwDXw += yPRvgxqMLMTBMfMC;
        wbLhypRuXCq = yKEQPfOQbMBWrmda;
    }

    if (OLLpBqPlGLmbWCYO == -375757.6181306666) {
        for (int URgHLJnqFYFll = 1419426623; URgHLJnqFYFll > 0; URgHLJnqFYFll--) {
            continue;
        }
    }

    for (int YhGaotkXwsfY = 28197083; YhGaotkXwsfY > 0; YhGaotkXwsfY--) {
        continue;
    }

    return oelKzjYgVUcx;
}

void ofzvKEs::EvMCZdQkrAyWO(int WPyCRXx, double fFgWDA, double SqgciVYZlpfdU, string wIcTQfWlnrXz)
{
    double qKwYvTTg = -245135.33201437822;
    double aicscpvMdGDI = 55613.98503838927;
    double EbcuCuurToUf = 802507.9105415174;
    string JgkGEFiEj = string("wNCdzqiFfEjgFycKSSYFyDKYBocfDvMcBTQSyDbOhNshCPpRSuuUpuhmjovnhbdyOolTlEEWqhCybqRhdxqueGZlXmkZeESgzniCtfuxNZbiityrJSiiizfjuqlbkJnXVcZOEyMxHNSbckplMswYWEDdlJpNxIGeGkYZCRSgHLybzXwxrRFxJzirzVcQlhtFhOcWKhXZDjnjVtRBIvTAKLUYKKvWTekTMdfXGpLgJqomJZnCvEwDQIUDJlC");
    string lFAsVtDVbMN = string("EGTOwBqpCVYTpmAvBprbYsLSEUawvTHcnNIhAWXbXrWJJRvWxeRhZMUMhVIMaBzjbxqbCQJKkPhMKVaHPgBHYtTBmhbnrqkXLNcguJhZRvxOePoHCVKBwjtlbguDXzsKBKahKfwkndvXYsJryTQxplQvXtdYqEnmtVfEfgXFfjMkQRpLmcBlxTtRKPG");

    if (lFAsVtDVbMN != string("EGTOwBqpCVYTpmAvBprbYsLSEUawvTHcnNIhAWXbXrWJJRvWxeRhZMUMhVIMaBzjbxqbCQJKkPhMKVaHPgBHYtTBmhbnrqkXLNcguJhZRvxOePoHCVKBwjtlbguDXzsKBKahKfwkndvXYsJryTQxplQvXtdYqEnmtVfEfgXFfjMkQRpLmcBlxTtRKPG")) {
        for (int RWoKmsITQlltNmQt = 599611629; RWoKmsITQlltNmQt > 0; RWoKmsITQlltNmQt--) {
            SqgciVYZlpfdU *= fFgWDA;
            qKwYvTTg += qKwYvTTg;
        }
    }

    if (qKwYvTTg != 525853.131755001) {
        for (int ZakWOOTehM = 679687649; ZakWOOTehM > 0; ZakWOOTehM--) {
            WPyCRXx /= WPyCRXx;
            qKwYvTTg /= qKwYvTTg;
        }
    }

    if (EbcuCuurToUf <= 525853.131755001) {
        for (int RENrGyg = 937160567; RENrGyg > 0; RENrGyg--) {
            continue;
        }
    }

    if (fFgWDA <= 55613.98503838927) {
        for (int XkmpNDE = 1759471412; XkmpNDE > 0; XkmpNDE--) {
            qKwYvTTg *= EbcuCuurToUf;
            EbcuCuurToUf *= EbcuCuurToUf;
            lFAsVtDVbMN = JgkGEFiEj;
        }
    }

    for (int cGGNzX = 1893558862; cGGNzX > 0; cGGNzX--) {
        EbcuCuurToUf += aicscpvMdGDI;
    }

    if (EbcuCuurToUf >= -245135.33201437822) {
        for (int GexypaFe = 1237484926; GexypaFe > 0; GexypaFe--) {
            SqgciVYZlpfdU += fFgWDA;
            qKwYvTTg += SqgciVYZlpfdU;
            SqgciVYZlpfdU = aicscpvMdGDI;
        }
    }
}

string ofzvKEs::gAUxCvOWfImzIzKQ(int BLAEwjfACAeC, bool BUKuraLlR, bool DqKuzWCWDPll, int HrSGSaHmNFs)
{
    string UoowUZSFvJf = string("pibGsahDDDGILVJeVnwTtqZFSJCyexgXHJTdUwYDvdEXkSzWHbgGkCyyVuwIEEbKkSkqkzQDSMglgChPrpDLhKDAohjQJYSncdgPlKeSwYcEaTElxnevfofQWTRiuBdSQyRGpmbexwWFFagQjEGOkAfIZkKhyJBeeqMJQplVIixUjfLsjUOlnOGkiFlQDwYPKLwnQhp");

    for (int pLwuYKnkoLN = 1483238584; pLwuYKnkoLN > 0; pLwuYKnkoLN--) {
        HrSGSaHmNFs += HrSGSaHmNFs;
        BLAEwjfACAeC /= BLAEwjfACAeC;
        BLAEwjfACAeC += HrSGSaHmNFs;
        DqKuzWCWDPll = ! BUKuraLlR;
        HrSGSaHmNFs /= HrSGSaHmNFs;
    }

    return UoowUZSFvJf;
}

ofzvKEs::ofzvKEs()
{
    this->UtirZU(true, 786096362);
    this->wSiCSccBpwEpnEf(false, 165932.68360354283, true);
    this->jfRUqs(string("GwlRBgEQthXwtln"), 1233181537, true, string("rPgrfqsxIurgDCmpVpWSZCGkGjwTrhQqHGzufHXtXlAoRhKaivJAusUDEhxZxnecnrYIALerXuvoUWOOWtluRELkSniFmIiKkbYnJalTTqlcuHnuPuKfDdAXNCMtvKFBzMznzctkNdeNWuHkDYBABuovyrPbhOhlzdzPXOoenIoVgsOKtL"), true);
    this->KKtNUphw(string("gkEKcdpdUZCddfcXGSuqXFdVuTreTIDCTxtthMhMKRlwitThkQJClEOpoyYyAzgYgrROlhhzqmwFoIJBMFfyVqOemUlVxIinabWyRHFpFhyZLiEgTuDsonXOrgehXJirSlGOgrtLINteMCjlyrhHgCiaShESCzrYnuAXLvFylgSbGPE"), string("iHUNWYsuQmLxpVtMMqJnYFAGwShvtgXTiGtHvdcsPbRQBZUlKTkIyEtOWxrdVZZuntKBspdOVWgzLrHbJtgJFZTyAAMBppaLIWQNEnCyKXLQKSoTOcsQcKUemGULPcIVLqPcHGyFzwPBbnddmlxPaxExVswzxcRqgyMOLnzlCRUFlkGByqGvzGIhkpSfukG"), true, true, -855572.8360260164);
    this->qpNoOSWwMfTJNGl(string("xNRqcdmEELq"), string("mqQgVeLkuVFnMlDiezFkOQYANKDHsCalGUXwKSLoCiiJdqowTLaVSJyHyvDvwRlZGzebXHRFYCDWtyXdyJmqsvNnjyKPVySoriAenkNILodtLpHnGnXHdhOIukrEUTSuhImZPDGySvLHUGesknJyiJcqECXyILOglzM"), string("crS"));
    this->ieIhXKMbo(212309567, 1754679427, 44571478, false, 117511981);
    this->EWafliMbDWFI(true, 467981423);
    this->ocbfoygteuRnnt(-734716.3559599146, false, string("WhRmpzklAAFZPBWIqGQVMGgjzMyLwDImiJeliMluZxEpmXoDenVtKrqtxLJHCuUDDjlyGiSBvSyQUYpKHfRxwGxpKrLEWziVlfPObNUxfSpEsCqTJIObnyVedXrNHCZfrhCVzzRHFbNewLjMXDpwOspeNMnNFAilqTJzGygirlabdeKmTwoIFIVLQunhfbVNn"));
    this->BqrdarwovVrt(string("GHg"), true, true, -1538802074);
    this->EvMCZdQkrAyWO(1666790799, 525853.131755001, 250174.2195663151, string("eolpfQjkTdmriZipmUbhVYXAotZZMTVlzJTakBMclwulyfzMYsOVhRjCamopcJfvDGrBrfbATbrfarrHTHaKlWTZzeXFaQGHmWLnCxACZIsXVWPVdjIoGFcjIMtgzgidghkjXqFPTDMaYmCgdXVChMOOCibNGlpvdtAWSHmqttdWdaosgzNxKPVahCehsSwvwERjHiTtZMtbpXcFbMELShFhzPPdrEeGnPtJCftwvOeHcpWhtR"));
    this->gAUxCvOWfImzIzKQ(-2086284214, false, true, 1961719062);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bDGMppohdm
{
public:
    string SDiGMgDzr;
    int kaETjIaG;
    string GiasEyZp;
    int lHItAkVEarqC;
    int yyPXZkZPrVdVAGV;
    double BWqbNWdfLYMHHnyo;

    bDGMppohdm();
    int HsDHMQLPvarrH(int PPwvXZDZtSMrdg, double rLXOhELPaVjGfpT, bool awjTKl);
    void srnfj(string ZKCpXwBKODqW, string CLmWyAiQcQN, bool DQYxmGjQ, bool LCkOUdrJzbQrG, bool RoWApalpXZJjjCS);
protected:
    string atgJXgpxpjjhXHDQ;
    int JdTjJTKLf;
    bool mVyGZEazE;
    int SnqVYLyzXs;

    double OWxVvmwlcCh(int bKPWKlvrdLRWo, string yiXUHjeRiJZn, double NFvPoiIvFRDljF);
    void MgBnrqfM(int DHMdl, int hOBPotejH, bool lOCQsTKtcSDYGfGr, double itKpm, double VrnHuLWIKhEmLXfU);
private:
    string ebIfRJaGFpZABz;
    double pqcwLJrcCDcWk;
    string EqCLAMmWbthWeApa;

    void VhwbtL(bool hwerBOzTjSgBNs, string jxAOctsmD);
    double mXbQnO(bool ugROtwvoRN, string MePIfXQaWWBwc, bool BzrRIb, string GpSGhXSFilAPrrCw, double xhjhsNguqdwyklDl);
    string CiwckzbKmsTD(bool etqfuqJ);
};

int bDGMppohdm::HsDHMQLPvarrH(int PPwvXZDZtSMrdg, double rLXOhELPaVjGfpT, bool awjTKl)
{
    bool OWAHoMh = false;

    return PPwvXZDZtSMrdg;
}

void bDGMppohdm::srnfj(string ZKCpXwBKODqW, string CLmWyAiQcQN, bool DQYxmGjQ, bool LCkOUdrJzbQrG, bool RoWApalpXZJjjCS)
{
    string TBbyOYqfu = string("sCBAteoGCxZhGEkKRFOCvSRcKbYnfyyfJXzEiWQpgy");
    int tOAQp = 1376381526;
    int cUgyHHlmmZZKu = -1502441461;
}

double bDGMppohdm::OWxVvmwlcCh(int bKPWKlvrdLRWo, string yiXUHjeRiJZn, double NFvPoiIvFRDljF)
{
    string bjVjkNCGTdAyvhc = string("hWTpcAaovccymqNpwbMGWwdcAmySuscfYhWNWpFPrjxlXDczIPqTsdIngoyZdggQeepwicXFZlloMPtvnlGSBmRNfpOBBG");
    string qvmbxLxn = string("ROrXkhXKDLruumyFprrqurhIVAHHwNElhpxQIESfEtXahbwPQzCDFWvHNFYdYIBuylWvekOFkJxQGsesMKeHBuDuOcrcYyWowJXsUzSDcFryDHPajMGphSzsbRePXHiRGaNDzaSmhuJzRlcyzRSDuJoCQOtzJotMrovLuKhEmIqnwQtadzMLAaROrvyvmBeCbwfKVvWqMJFokclQFlAwlVpHEZWsKFtdTJXTQw");
    int eEtoa = 310352468;
    string EzfKtBzUJ = string("PrufZZKmMTHiTwvVWzUcrXRrUXdgBqpsDWXIEgqCEmZuhxNQfasxynyFKYZiipudmSIBubqUFzRsOcvBzYvtMSHEixaqheHbV");
    bool SuawxeYHSB = false;
    double jRvVwuHtmf = -389322.7956499365;

    for (int qHhjHL = 1905353801; qHhjHL > 0; qHhjHL--) {
        EzfKtBzUJ += qvmbxLxn;
        EzfKtBzUJ += EzfKtBzUJ;
    }

    for (int mJdMjnddOsk = 725845487; mJdMjnddOsk > 0; mJdMjnddOsk--) {
        bjVjkNCGTdAyvhc += yiXUHjeRiJZn;
        NFvPoiIvFRDljF *= NFvPoiIvFRDljF;
        qvmbxLxn = EzfKtBzUJ;
    }

    return jRvVwuHtmf;
}

void bDGMppohdm::MgBnrqfM(int DHMdl, int hOBPotejH, bool lOCQsTKtcSDYGfGr, double itKpm, double VrnHuLWIKhEmLXfU)
{
    string uUbWyYlDnFXjUNCH = string("vPHBcoiQrwNamCuXoHCRRQIHkJXoroeSXZgyeexIcEuARLqpQGSyaNgPZlrWQsVtAwjygbkNxzsmUcwjidWKjzcoYKGFbumcihwZacQagnghNJJvYlJeeGTWTsb");
    double QZgpZddr = 626425.991148709;
    string esUsVJtCdPUH = string("ZwMHVogafUKVMDEoSXRbZnwAkpovVTogGfsDzPtpNopEmxpOzNPyCbsJIPJEMgealvRQsDTPrPUKYhvcuhroDUcvQwOmEnzVENmyiueGIyYdZDBTSPVfTgreWWrRTdZXHtZNxcicHtolPPUgZjZhmhiJthrCKtjXibqLMGlKKyjtKCOhXhKklrlDpNMvgdUvfGHGbGOkKBxADQCWxLjedIgMdroKEBqD");
    string LmkeCuYjz = string("McfzJMPPQSLNraVElDhOwBtQHynrOazOrChGeQiODAxAdXiXNzDZVrOOkJqpLoCkdFLSNSqTgOlKlqcgrAcuKWvwBzgVcAquNBfvIlKmIaYqDunzpMGi");
    string IHsxKRqxMkARyfbL = string("KkxIoupFTtbSVBvcTJwcILcOVtkfGdiYXVCKxuWMXqSQzzTKYWfXHkrmeaZsyNfcrwCTmrOxaKCpNErBICQoIIisuctixalPZQYqlaIiRMbuChSarlfxrtMhTDKwAimGcxPeXi");
    string rLqQCAnDsDsl = string("hgVzGuCKECkyzIZdOLllLwyRPTTQyWiDJqIorPmJhHldGJJusfurMqgrlqObqbozSYkrVwRyUJAYZUOqzNzpqLtkZKDySgOllqanhsjZnCnAjrShBPPSayzdbRprAzquStbXrALdLMlpTZZaiVQTFhNHPPvjpFFQOZDQjhYfBfzcfGoNiqJeSRdCnllPNmSjfaOSEDfrYUTISDIsTtEvhcOc");
    string hTIOLu = string("ItmotjCodTzPnPXnUxQVAgnXnEdGMQLKaajdMwdufVgCZlCyOqcGwGDZpVWAwWaZfKcXXxNcUEeFxzYqfikQQBPpJmOoTtYJUvNIxU");
    double wKlRXBLitpAdnPBL = 932312.1059865806;
    string qtYdYnPdFelto = string("RLUxZwyFUZmrnAwNtkwyTVuJrtpNMtQpDfkiNYbzhQELzoVDUHrbSQVywdUxUGJZwvvzmBKtSJMEFenTpJvjnumlwfjVQnhUZxPBJKdxMuFLvFNgOpXNJNnUULYGylEanCqrVpIgkGVQYhHDJmtpyBPfOhwsgUDDfbreeyYgmekmgUCfnGcMgvTXWzqVmcEljCkIvtOlbiVDNKI");
    int cbnZmnIL = -1054008189;

    for (int XKLGouMfPeK = 1893904540; XKLGouMfPeK > 0; XKLGouMfPeK--) {
        wKlRXBLitpAdnPBL *= wKlRXBLitpAdnPBL;
        IHsxKRqxMkARyfbL = rLqQCAnDsDsl;
    }

    for (int ZzXUjkZQKwgM = 209712304; ZzXUjkZQKwgM > 0; ZzXUjkZQKwgM--) {
        itKpm = itKpm;
        LmkeCuYjz = rLqQCAnDsDsl;
        LmkeCuYjz += qtYdYnPdFelto;
        esUsVJtCdPUH = LmkeCuYjz;
        hTIOLu = qtYdYnPdFelto;
    }
}

void bDGMppohdm::VhwbtL(bool hwerBOzTjSgBNs, string jxAOctsmD)
{
    int capOToOLz = 1539781649;
    bool krqshDY = false;
    bool brSZYsz = false;

    if (hwerBOzTjSgBNs != false) {
        for (int QbvILzC = 1359975893; QbvILzC > 0; QbvILzC--) {
            krqshDY = ! brSZYsz;
            brSZYsz = krqshDY;
        }
    }

    for (int EASHeyOq = 807555445; EASHeyOq > 0; EASHeyOq--) {
        continue;
    }

    for (int FPWAgyTHQMcdeUs = 1527745611; FPWAgyTHQMcdeUs > 0; FPWAgyTHQMcdeUs--) {
        krqshDY = ! krqshDY;
        jxAOctsmD += jxAOctsmD;
    }
}

double bDGMppohdm::mXbQnO(bool ugROtwvoRN, string MePIfXQaWWBwc, bool BzrRIb, string GpSGhXSFilAPrrCw, double xhjhsNguqdwyklDl)
{
    int HwslrN = 1492997747;
    bool UmTpdxfg = true;
    string eHHOKHVdOvEKZEr = string("hWcaABDTdhXaIJycewiHETzUBDwQXnnkhAfDWjHpPMegvmGWqFCgYxTkYblRLdXvSdFgCwbGmIkkqJNHJvQXuXxZpSxYQaNysmGdwtKpbhaTfb");
    double SWGrcvlC = -481051.86475081905;
    int dtpHsqLecVOLifT = -96758542;
    string dbZxcxsLNeTotsql = string("IlwgMGeDoUdolFszzToFJMkdOkblXbNPOmYPMPfJxhHoDabaVSUzdZBbtpJIPvOTXOFmrezjrXTWPUQflJOVxawqkQCMqZjRQwKUnaZCnBUiXbjkxJHTcDbztyvbMeuAbOxAypfZHdWqscUUgkwGBJHbGOwyfiFnmcGPWJRxdmnFjQOUaBBOVfWEbxGkPnwLmhNvElgzwxglCIOGOjbogXKiyvVTWrKXfpvqeepwLimVChSAGZplkzWbyEtLe");
    string LZoVrA = string("XvAmtOALeYmHktphMjMRmj");
    int djYTlHFkvwCemWej = 1946764464;
    string icrjJjXGZfHmHj = string("QCSZvKJNrQFRmtwYcAQMVQGySAdlOIUYsFMxMaB");

    for (int xXfQefzqT = 1951514490; xXfQefzqT > 0; xXfQefzqT--) {
        ugROtwvoRN = UmTpdxfg;
        MePIfXQaWWBwc += eHHOKHVdOvEKZEr;
        djYTlHFkvwCemWej += HwslrN;
        dbZxcxsLNeTotsql += icrjJjXGZfHmHj;
        HwslrN *= djYTlHFkvwCemWej;
    }

    for (int aDJSmLusIBDs = 971338255; aDJSmLusIBDs > 0; aDJSmLusIBDs--) {
        continue;
    }

    for (int zrAOxv = 2088151884; zrAOxv > 0; zrAOxv--) {
        eHHOKHVdOvEKZEr += GpSGhXSFilAPrrCw;
        UmTpdxfg = UmTpdxfg;
    }

    for (int vfOMZMeHFRne = 1507904603; vfOMZMeHFRne > 0; vfOMZMeHFRne--) {
        MePIfXQaWWBwc += LZoVrA;
    }

    for (int ImNfUVtWgqb = 271256375; ImNfUVtWgqb > 0; ImNfUVtWgqb--) {
        SWGrcvlC -= SWGrcvlC;
        xhjhsNguqdwyklDl -= xhjhsNguqdwyklDl;
    }

    return SWGrcvlC;
}

string bDGMppohdm::CiwckzbKmsTD(bool etqfuqJ)
{
    bool HUxUopoEqmU = false;
    int PlEjLycBEN = 1292275856;
    bool ZNyGxH = true;
    string EIVnjeSuvfYd = string("DDVYhfYgaXoxnOsGTLAwtBlBzzGwTEtUDvLDvjatoClywpBIkQIRxGZkOS");
    string vZuzS = string("FjwHlBvMmlIwficTMkKYsNMNNtLbUjhjzWcgGbgSFxuNBNgHDHrLEBgqVDJQuwgUvAwfcHEEWmQRNTnFtHTRzMYnReJCAHGsUfOgQ");
    bool vFqIMw = true;
    double shKXSrnwoUxAX = 327361.6179997102;

    for (int lBzckneBp = 915889710; lBzckneBp > 0; lBzckneBp--) {
        etqfuqJ = ! HUxUopoEqmU;
    }

    for (int uscDV = 537084475; uscDV > 0; uscDV--) {
        ZNyGxH = ! etqfuqJ;
        etqfuqJ = ! HUxUopoEqmU;
    }

    return vZuzS;
}

bDGMppohdm::bDGMppohdm()
{
    this->HsDHMQLPvarrH(770784942, 699185.6721351568, true);
    this->srnfj(string("TJvUeqpq"), string("bJnPtLVAimVEcUyWkvGxJpAXMKrjOcqYDvfJwBAzmygcmTExuLVwDJXbCsTGNzazyfRpjOHYBynbapsKyVCY"), false, true, false);
    this->OWxVvmwlcCh(1175992039, string("bMWJiUZPisqMSPYlQFgSUqtCrwVvuBRwbmMmInrSKZiCTmeNIQMZFHB"), -853005.3962499892);
    this->MgBnrqfM(-877634348, 1359694337, false, 8492.869146419933, -777515.9826828598);
    this->VhwbtL(true, string("jkxkQEmZfnKBQfuzTJTkByobwKdyjMVEffRLnTbDcjHTTMEWSKkAJdmULKAUyxwCdjdXtGsQPdhErJXwtDQkVgxgIYqDruDCHSvhlduTGqlmhKzpBkuDvHJkOPJCdrTuAyrRxqRrTcXPBiNKHzdeKyNsaJpHsprSsolhpAugAwYFTHoNRRkkyvJckJoHRwNGhRNDGQhdvNVvBqcWvGPWDNDAnnKfdeEswRYSTAsVAuxJirutrkTGgsXIZsQ"));
    this->mXbQnO(true, string("QNCnThjzmQlrtNhEvqMhJfasxbEjbvGmUxAJqHrAKeITlITTKLXUYmxaEnAUSBsicVrnrZSUVrKbACCHrHkKslOFrZMUxMxnnjHCiXiDkLIOPoxNMfxbwHPCMcUwREsFgWYCljxDJZqgcSMyEHZzBBqoaTnpaarOPWSVrVgmvWFFlSWOCpCHtAbmycTUgjDPyCCZRxbUycQNIsFxBOqYyNyaDvUYuDMLvUufhLLiDYMXVZwgeS"), true, string("nRayiPHsatzULtOnXBfmsHkVxqOhoiQIbDRoaUSbLhhnieAfLokunFsMwvTufNrOMDsxqkfhMkFcMMMwffKXEeuPmnvALUntYcerUXudBkDTFrfmqFwzqSwJzGXJBhDztAJGp"), 917989.8805383209);
    this->CiwckzbKmsTD(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jrbbl
{
public:
    double lqWlNaEqFT;
    double hMpTNCyBOPMfSV;

    jrbbl();
    string OWNYDzbsZOd(string NbWRFjU, int mauno, double sucUWJPkyHb, bool BiuybobpXtHCiv);
    bool BdhAHZPqcUjQ();
    double lqXcucnOABnu(bool nQGoHuVoqtNI, double ngStFUwJnkO, int sIuAirTQpV, int BrlloEPcLgfxwH, double sRzrOcBwD);
protected:
    bool sOzyRYqX;

    double pZXVJULZYHE(int lebDgFqVzRP);
private:
    double IMCZkCuUzs;
    bool VWeZFumBzfNQQ;
    string qcBrMHeasvGzx;

    void EEzePmjucchroEuZ();
    int NxnJrNPG(int SNrqhrJ, bool phJIjIjgslhno, int rZhbRn);
    string rJudyOQayjgIMI();
    int hfWpEE(int ceqYBJKGvyXf, bool mwdnrvABKAk, bool KOFQWOwunU, string TxFuhUK);
    string RzRHaaiJjpK();
    int rEiiQ(double gWChmfqFYRymONK);
    double FZifbAPfIfUIyVex(int JReFhDscqO, bool gjmYs, double uJDlZkFcQH);
    bool CNDXyseCBojtkElW(string vMvvPveOePXaK, double azWeOWzRxMlKEteL, int wzLATuWxUc, double kJepXMnPbuoWZPv);
};

string jrbbl::OWNYDzbsZOd(string NbWRFjU, int mauno, double sucUWJPkyHb, bool BiuybobpXtHCiv)
{
    double fUBVHd = -593662.2873610572;
    double ahzQmgKlZYECHwQY = 733776.325262232;
    int YucgJVh = -905451595;
    double GpKdhVVzy = -278991.62491130654;
    int AYKupPqeL = -1302396387;
    int KasNl = -1551802875;
    bool bdfmlapTl = false;
    int PxygHmKbxWsxFWBD = 129175259;
    double LxFPDVjfcXDOfB = 22164.252098197656;

    return NbWRFjU;
}

bool jrbbl::BdhAHZPqcUjQ()
{
    double DVqidOfwvP = 524098.8180133595;
    bool gISAccZTsj = true;
    bool kUFEgM = true;
    string oaEjrUwobyCg = string("NuidoqNMVWvGUIyEQFUDjpsqvNgzYaoryjqdbVKtZjEbKedWhRpqbgBBCyXDBvCsUNZpvtmxkoKc");
    string IiUtj = string("yNNHjXwcLRbiLpMxYdjdmPGhJvBYxYryUdYdedgDmmljNicIRbFygYDnhrgpEVPyozldBCHLpfftTAzKrmOvvFBLwEjduZGnzBwlCCjFczqDMAnYCZZklgfk");
    int oYVACIBJg = 805584775;
    double ERMJV = 655819.1932700989;
    bool WgQcESQyz = true;
    int iOIgdRp = -410372921;
    int KPTVTY = -1588083753;

    for (int vCrhaYDL = 1912325431; vCrhaYDL > 0; vCrhaYDL--) {
        continue;
    }

    for (int qKnJEZQ = 537487234; qKnJEZQ > 0; qKnJEZQ--) {
        continue;
    }

    for (int KOiBHyodvgraf = 1950207736; KOiBHyodvgraf > 0; KOiBHyodvgraf--) {
        WgQcESQyz = WgQcESQyz;
    }

    if (kUFEgM == true) {
        for (int MfkxUV = 498084216; MfkxUV > 0; MfkxUV--) {
            IiUtj = oaEjrUwobyCg;
            IiUtj += oaEjrUwobyCg;
        }
    }

    for (int mBrLTsJoeeDljrO = 1261155458; mBrLTsJoeeDljrO > 0; mBrLTsJoeeDljrO--) {
        oYVACIBJg /= oYVACIBJg;
        oaEjrUwobyCg += oaEjrUwobyCg;
    }

    return WgQcESQyz;
}

double jrbbl::lqXcucnOABnu(bool nQGoHuVoqtNI, double ngStFUwJnkO, int sIuAirTQpV, int BrlloEPcLgfxwH, double sRzrOcBwD)
{
    string rqisEh = string("pknFdkaxZrOCfYRhLtgFmlPWpuVGZffbteeCQVgHYMDNSoQHpGRAPCjwEplSZaHTMSRslZVjdPqBvvkDmhmUqSFBWbnFMpEWXbCcbWlVzeXfwpBMQSxVwDqutcbkDGNNGD");
    string lxWZHl = string("XYrrzRIaIgdkaFKZFEibfmkksoEPjOeYofWtjfsBVEqvEiKsYEUukgncfRUMwtaBkDyAwMIUmhQDuPkhiMPAKUqjQoKkMzgBQbECCfFmKOrFTRPoxgNvYogtwzxCLRSeVPYHZxPHAhKNENDIVGHRRglaInlRauNSPZQfCEyaxVdcTkRPTuLrTjQnoJbRcEl");

    return sRzrOcBwD;
}

double jrbbl::pZXVJULZYHE(int lebDgFqVzRP)
{
    int bxlOdowY = -2119921293;

    if (bxlOdowY < -2119921293) {
        for (int sgRoTnBImiHB = 1382477439; sgRoTnBImiHB > 0; sgRoTnBImiHB--) {
            bxlOdowY = bxlOdowY;
            bxlOdowY /= lebDgFqVzRP;
            bxlOdowY *= bxlOdowY;
            bxlOdowY /= lebDgFqVzRP;
            lebDgFqVzRP /= lebDgFqVzRP;
            lebDgFqVzRP = bxlOdowY;
            bxlOdowY += bxlOdowY;
        }
    }

    if (lebDgFqVzRP != -2119921293) {
        for (int BPneuadb = 1714319279; BPneuadb > 0; BPneuadb--) {
            lebDgFqVzRP = lebDgFqVzRP;
            lebDgFqVzRP -= lebDgFqVzRP;
            lebDgFqVzRP /= bxlOdowY;
            bxlOdowY -= lebDgFqVzRP;
            bxlOdowY *= lebDgFqVzRP;
            lebDgFqVzRP = bxlOdowY;
            lebDgFqVzRP = lebDgFqVzRP;
            lebDgFqVzRP *= bxlOdowY;
        }
    }

    if (bxlOdowY == -2119921293) {
        for (int kfdUNwjnN = 276495959; kfdUNwjnN > 0; kfdUNwjnN--) {
            lebDgFqVzRP = bxlOdowY;
            bxlOdowY *= lebDgFqVzRP;
            bxlOdowY *= lebDgFqVzRP;
            lebDgFqVzRP += bxlOdowY;
        }
    }

    if (lebDgFqVzRP == -2119921293) {
        for (int tBcxRcSFx = 1418621920; tBcxRcSFx > 0; tBcxRcSFx--) {
            lebDgFqVzRP /= bxlOdowY;
            lebDgFqVzRP += bxlOdowY;
        }
    }

    return 56512.19502528678;
}

void jrbbl::EEzePmjucchroEuZ()
{
    int rXSsh = 1262247551;
    string fryIrkMpgJzELzv = string("CJNLtB");
    bool hcmHoYeRddgDP = false;
    int RkhKUmDyPMpDH = -2014852527;
    double LQIRpVtEA = -952782.9340328742;
    double jvZGfp = -53663.893288152365;

    for (int frYzxmChfB = 552402515; frYzxmChfB > 0; frYzxmChfB--) {
        hcmHoYeRddgDP = ! hcmHoYeRddgDP;
        LQIRpVtEA -= LQIRpVtEA;
    }

    if (fryIrkMpgJzELzv < string("CJNLtB")) {
        for (int IuSxjCq = 979414968; IuSxjCq > 0; IuSxjCq--) {
            fryIrkMpgJzELzv = fryIrkMpgJzELzv;
        }
    }

    for (int YZSjjZTmkOSD = 394278599; YZSjjZTmkOSD > 0; YZSjjZTmkOSD--) {
        continue;
    }

    for (int TjXYbYsv = 226716118; TjXYbYsv > 0; TjXYbYsv--) {
        LQIRpVtEA += LQIRpVtEA;
        LQIRpVtEA /= LQIRpVtEA;
        RkhKUmDyPMpDH = rXSsh;
        fryIrkMpgJzELzv += fryIrkMpgJzELzv;
    }

    for (int RIolvrhBsDVnvNiF = 1569822747; RIolvrhBsDVnvNiF > 0; RIolvrhBsDVnvNiF--) {
        hcmHoYeRddgDP = hcmHoYeRddgDP;
    }
}

int jrbbl::NxnJrNPG(int SNrqhrJ, bool phJIjIjgslhno, int rZhbRn)
{
    bool gPKOpYgAiDSB = true;
    double qCVJcHMVaHC = 885355.6595457079;
    double shdIdVnrVzJ = -654047.2952598574;
    int WdKXNqUwKMmrvw = -1837704945;

    for (int WyIocLMhBS = 1872214144; WyIocLMhBS > 0; WyIocLMhBS--) {
        rZhbRn /= rZhbRn;
    }

    return WdKXNqUwKMmrvw;
}

string jrbbl::rJudyOQayjgIMI()
{
    string KQqkfnbect = string("IUDbtgbOfIRcMOXjIBXeZiyJSIcDjYejohylRgXgDrRgoNQNMeiCsPErJmaIcx");
    double iRPkRKQR = -794381.351714655;
    double JeAWAPN = 693997.9119289775;
    string qNAceRiOVQXu = string("OludgDWgXsbcEPoDpFEOmBabiiyvQRFnhDwXaqptlVhWkZKkflEqMBGXTxaBlGJxXRJinqORWYkOlxIpfHOwuprlvsWtptqEjFcYGqMRf");
    int cBTrVQDzJtlC = 1107557583;
    double rtfRyCuELspUHbjq = 68050.28418380285;
    string uoGUVLur = string("cyBfPsQOdsHPQYNGFWnVjVkOBXNUFxWXcbAabEoAfpjSDOmlAmyrcrjLbVDsvtkGVIrC");
    double JKliwlKvP = 710094.3459281983;
    double PhzFyFbfXRWuhmA = -598603.1492612285;

    for (int yTnkf = 179524197; yTnkf > 0; yTnkf--) {
        PhzFyFbfXRWuhmA -= PhzFyFbfXRWuhmA;
        iRPkRKQR -= JKliwlKvP;
        qNAceRiOVQXu += qNAceRiOVQXu;
        rtfRyCuELspUHbjq /= iRPkRKQR;
        uoGUVLur = KQqkfnbect;
    }

    if (JeAWAPN != 693997.9119289775) {
        for (int jyhwUCmtnN = 598470988; jyhwUCmtnN > 0; jyhwUCmtnN--) {
            iRPkRKQR -= rtfRyCuELspUHbjq;
        }
    }

    return uoGUVLur;
}

int jrbbl::hfWpEE(int ceqYBJKGvyXf, bool mwdnrvABKAk, bool KOFQWOwunU, string TxFuhUK)
{
    bool WUsWkAsHVmPUkGv = false;
    int fyWIwWfVRGRJWjJc = -2079689469;
    bool WuKws = false;
    int XAUjMoSQV = 432627063;
    bool LAbHqEjfnBrWq = false;

    for (int zpkejIn = 492453867; zpkejIn > 0; zpkejIn--) {
        WUsWkAsHVmPUkGv = WUsWkAsHVmPUkGv;
    }

    if (LAbHqEjfnBrWq != false) {
        for (int jUoRIPTEg = 1497143375; jUoRIPTEg > 0; jUoRIPTEg--) {
            KOFQWOwunU = WuKws;
        }
    }

    return XAUjMoSQV;
}

string jrbbl::RzRHaaiJjpK()
{
    string cQItOvajLu = string("teaUQTupjEDfLESUHosSqfeMORwlgDRMhMggzkJzFjxHkOutRvbQDKhgQRsrubMQlSipYcLmZykjkbbicVEnhxjTSKIhrGafJTTaN");
    bool mBzkSssnZNFk = false;
    bool zRhDCXgNocAWEH = false;
    int kckwfWXhTH = 1480171790;
    string rudyTLvkXFHuD = string("rRXxTfyyVKfolMusDcqdsZJERaaQCdFeEgZZAwOraWfqQITwqGOptyHMsVrIZwUfrFmMYKPqpXXCmbUhhRgjMFnMmHfFaohPlJsLKXEPHfrxwkZUJaphjyFlDLAOqOxXkmbkZFPwLSwLIxkkNjSiudIktvGUmZTdzAMAGTTTUPFPDYpPHQCScfdkPmeOqaiduBQbaeRSAzLhmybfkzyohqEtQeLJYOCEoAtmwaaEmjtPeSFgLFScTfibthk");
    string umssUMXWoHsrMAH = string("gLhFnyzHQLTkqxbJlJjmfMHgBKWyqVevYcgbMuLBbrBjkFqRpfsYLIGJsnHqcOqYRquztVKofIsRJMacBjCanOEVCDyxhKVVTYInNexstEWvuPppdPwIHEDBbHKjimaWYfgChyAFoOPTGSisVndivMBhEKXKdgEItWwoPLWWyMbPjWDhwulrjJOeCnXEmnceboXtgkvrzMaCPVQqvPBeJlzmGngHIibXNvoPyyMHdGpSxarqUv");

    for (int fAtvfsWiufl = 84411972; fAtvfsWiufl > 0; fAtvfsWiufl--) {
        cQItOvajLu = rudyTLvkXFHuD;
        rudyTLvkXFHuD = rudyTLvkXFHuD;
        zRhDCXgNocAWEH = ! mBzkSssnZNFk;
    }

    for (int qwdpdOiAJaXab = 277504159; qwdpdOiAJaXab > 0; qwdpdOiAJaXab--) {
        mBzkSssnZNFk = ! zRhDCXgNocAWEH;
        rudyTLvkXFHuD += cQItOvajLu;
    }

    for (int sMiDCezMYReyS = 1585295562; sMiDCezMYReyS > 0; sMiDCezMYReyS--) {
        rudyTLvkXFHuD = umssUMXWoHsrMAH;
        cQItOvajLu = cQItOvajLu;
    }

    if (mBzkSssnZNFk != false) {
        for (int NZhnC = 950643822; NZhnC > 0; NZhnC--) {
            cQItOvajLu = umssUMXWoHsrMAH;
            mBzkSssnZNFk = mBzkSssnZNFk;
            umssUMXWoHsrMAH = cQItOvajLu;
            zRhDCXgNocAWEH = ! mBzkSssnZNFk;
            zRhDCXgNocAWEH = mBzkSssnZNFk;
            rudyTLvkXFHuD = cQItOvajLu;
        }
    }

    return umssUMXWoHsrMAH;
}

int jrbbl::rEiiQ(double gWChmfqFYRymONK)
{
    bool ctmTiAV = false;
    double ubQjertXIjhv = -668922.2587604669;
    int LDqlsAJFxefIDb = 56831577;

    for (int MPBsyCifcCMG = 98264334; MPBsyCifcCMG > 0; MPBsyCifcCMG--) {
        ubQjertXIjhv -= ubQjertXIjhv;
        gWChmfqFYRymONK = gWChmfqFYRymONK;
        ubQjertXIjhv *= ubQjertXIjhv;
    }

    return LDqlsAJFxefIDb;
}

double jrbbl::FZifbAPfIfUIyVex(int JReFhDscqO, bool gjmYs, double uJDlZkFcQH)
{
    string HyBjxvcMoJEhB = string("iYdHcdQXDeChHmCaHIYxawFwoVtsxYZlnWxIErrcuTJSrhgPjDefQZUxOXPYKnXgGdllPetQWeVQoCWRupnnQTFxOjntOcRDVBhfiXwwuHJYuzAwyFDoSIRqxWKObgVGuuzJQKvyzYVqNMrhoTramKPxrcBzzJSJ");
    string yfVovusbAFydwG = string("tFGbXmQNrYxblpifUKOUhLSnqbRdtfEYDHBsxewikmJEHusVIBNlQFVTFPtqSDPLFzcZYZFMQltEbPKfJcxKpxTnHKgKcsOIbsPCqxCaZnktjxaTUGSYYkTIWJLziOiIyHyVzmkjHeokRccemzpIYdFhwoxKqYqhACzqPZaVJBzHamCjsvmOLsbRwWqFRLOVfYbj");
    string ZETqbXQEBIqt = string("KMiMyuMkfOqGUEUJtmdSsQMNSgaSnTeJYVJzleyxVabrPaoWdJzgJbaulCOdmctxBrPKobZZbpMUYOqiOvcFpTqmDkpdKdBXVticqPMSqEDxOUXrQhkjAnYgXDfbSFGDGnPKkjnJAFfuwSxpVVMfdVArdUllrwaScGvfToIErTPQVafIbjq");
    int lsLzDlEtSW = 730357496;
    string ZpxnoSGCjKX = string("VOfxgMcmUfEGoSNnKCmxrIHhahALBFJCaHvxcIDRufrzwYKHRMsaujYEhCgIbURkCExnEtFYafSTVozqNvyNaWMgQuyHjfOXCRWAxmRuaqZHocRNHaXzYxUIumnwyxSJGkTNTkJgBdIQWDqiHwtoXKPpYekCDFhzwkXzjbIcpRVmAZxplzzsyStjwfghwwMiCcnkrk");
    double VuyRGeqbdVNXoUDd = 191886.09654178398;
    double mStCmKTWithv = -806888.054260497;
    string DcRjHmOxgxVjZJ = string("mJWqcPOpIbIAursQHJmzcHJigxtdrWDBuOtWPQSVRwJqLKyhIcKKPdPocUjXPxkHArViQeHXbISeDfyVQcdVaGmaBMX");

    for (int JGJUivKta = 1642602374; JGJUivKta > 0; JGJUivKta--) {
        ZETqbXQEBIqt += HyBjxvcMoJEhB;
    }

    for (int PBZFPQlJuEAz = 198418135; PBZFPQlJuEAz > 0; PBZFPQlJuEAz--) {
        yfVovusbAFydwG += ZETqbXQEBIqt;
    }

    for (int oHVOzWWafuAWSB = 293661929; oHVOzWWafuAWSB > 0; oHVOzWWafuAWSB--) {
        lsLzDlEtSW /= lsLzDlEtSW;
    }

    return mStCmKTWithv;
}

bool jrbbl::CNDXyseCBojtkElW(string vMvvPveOePXaK, double azWeOWzRxMlKEteL, int wzLATuWxUc, double kJepXMnPbuoWZPv)
{
    string ZxzHJaJR = string("qbxZQMywiwDJOWbusDgPHoADWAYXJWIFChymqPfZAAUwMhStlwPEOvIBnKNDTjLPHNLlVJoryRkVhZfGGBIuBRszsdNSIxxRTimmbSghZlvbPkkuGeGTcZdYebPgyieFcXJhGJCXLmtWcdstDbebqDEvjkTdqshzVDzWclWpfTEElPYqFaABaPGOPwFkYJeHdrpZYCogHqkPkYdwkEqTBJtjpaxdiLB");

    for (int eDyWeLfWEOMC = 653632427; eDyWeLfWEOMC > 0; eDyWeLfWEOMC--) {
        azWeOWzRxMlKEteL = kJepXMnPbuoWZPv;
        wzLATuWxUc /= wzLATuWxUc;
    }

    for (int LIzkdHWyFmzRo = 1626769255; LIzkdHWyFmzRo > 0; LIzkdHWyFmzRo--) {
        azWeOWzRxMlKEteL -= kJepXMnPbuoWZPv;
        wzLATuWxUc -= wzLATuWxUc;
        vMvvPveOePXaK += vMvvPveOePXaK;
        kJepXMnPbuoWZPv *= kJepXMnPbuoWZPv;
    }

    if (ZxzHJaJR < string("qbxZQMywiwDJOWbusDgPHoADWAYXJWIFChymqPfZAAUwMhStlwPEOvIBnKNDTjLPHNLlVJoryRkVhZfGGBIuBRszsdNSIxxRTimmbSghZlvbPkkuGeGTcZdYebPgyieFcXJhGJCXLmtWcdstDbebqDEvjkTdqshzVDzWclWpfTEElPYqFaABaPGOPwFkYJeHdrpZYCogHqkPkYdwkEqTBJtjpaxdiLB")) {
        for (int wiJhkAdtOKhFU = 737930194; wiJhkAdtOKhFU > 0; wiJhkAdtOKhFU--) {
            kJepXMnPbuoWZPv += azWeOWzRxMlKEteL;
            azWeOWzRxMlKEteL = azWeOWzRxMlKEteL;
            azWeOWzRxMlKEteL /= azWeOWzRxMlKEteL;
        }
    }

    return false;
}

jrbbl::jrbbl()
{
    this->OWNYDzbsZOd(string("CodQgiiukwlwXNtkspEuWpcxdXLHrmhokfSkzIMSGDOlJAMRGrQHnWKtIFkALDHAsvnlCkgZBUgnrDtTOPUMiQvFCCNNVokVhCjLjpqFTnnQgkzi"), -240001936, -809893.4197280151, false);
    this->BdhAHZPqcUjQ();
    this->lqXcucnOABnu(false, 720917.558755209, -261061895, -411993312, -185266.75542938185);
    this->pZXVJULZYHE(-1117992005);
    this->EEzePmjucchroEuZ();
    this->NxnJrNPG(558009725, true, -878993590);
    this->rJudyOQayjgIMI();
    this->hfWpEE(-1376037706, true, false, string("QwhlJAfUswVVQWQRmKnFzeeTzqvaXMCfjOyLGETQiWgkN"));
    this->RzRHaaiJjpK();
    this->rEiiQ(326847.0982486989);
    this->FZifbAPfIfUIyVex(1200446969, false, 614481.1884335516);
    this->CNDXyseCBojtkElW(string("Y"), 102102.8158874441, 459710942, -11384.017553275113);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hGLoUbrBHz
{
public:
    double GisrY;
    bool FIjvAM;
    bool BtFCIrOCVBNSJf;
    bool DYUjFm;

    hGLoUbrBHz();
    int EdJArluSSdaOGQ(string JSMdNMsYdgg, bool onUaG, string pyDaaQusKxe, double hTszInEcoaRM, int vpVckajGNhNxkJ);
    bool EZFNhI(bool WlhcJuXpT, bool UaTEVO);
    string CNCZGwqn(int LXLlUe, double vvzPRUzDzsF);
    bool HgaOYrPoixwgHZE();
    void MvsqSRazBUowmh();
protected:
    bool ZdAABdA;

private:
    double pYUjmCvyWhfITZN;
    string jeLLYOkxtYeQCN;

    bool YLrEpFUTZRLuH();
    double ZaulNkajgT(int lbYIo, int mthvRTb);
    bool lRGXizGdahgKP(bool QjMDB, bool EcwJJSuW, bool KnekctTdx, bool laVzNnILlIxCc, bool syDrBUYWcTbcleAV);
    bool UpsRmrBW();
};

int hGLoUbrBHz::EdJArluSSdaOGQ(string JSMdNMsYdgg, bool onUaG, string pyDaaQusKxe, double hTszInEcoaRM, int vpVckajGNhNxkJ)
{
    bool WPBFnRaugkabc = false;
    int LLNUeMtJJJxX = 1022427298;
    int ztbGOBdUCMvdDJHA = -1120223727;
    int YBLxeuJWMZ = -1880904305;
    string cqQyeykDEOiJ = string("QnouCWOEtVRQGhOhpUaxQfPkwXmEdxyxVYohEYgXmAqQGTxLicerMM");
    int IboqdeKiiga = 548331397;
    double UCiYJGhzL = -823588.9973364985;
    bool WPycYQn = true;

    for (int vBEovoc = 1736248044; vBEovoc > 0; vBEovoc--) {
        LLNUeMtJJJxX *= YBLxeuJWMZ;
        ztbGOBdUCMvdDJHA += YBLxeuJWMZ;
    }

    if (WPBFnRaugkabc != true) {
        for (int ElZKPleTMMHBmjEX = 1035844471; ElZKPleTMMHBmjEX > 0; ElZKPleTMMHBmjEX--) {
            ztbGOBdUCMvdDJHA += IboqdeKiiga;
            vpVckajGNhNxkJ += LLNUeMtJJJxX;
            JSMdNMsYdgg += cqQyeykDEOiJ;
            ztbGOBdUCMvdDJHA += IboqdeKiiga;
        }
    }

    for (int pvynXdkeFSkAH = 1347603960; pvynXdkeFSkAH > 0; pvynXdkeFSkAH--) {
        ztbGOBdUCMvdDJHA /= YBLxeuJWMZ;
        YBLxeuJWMZ -= LLNUeMtJJJxX;
    }

    for (int tJWKLVDbPoBbzQ = 1065797765; tJWKLVDbPoBbzQ > 0; tJWKLVDbPoBbzQ--) {
        YBLxeuJWMZ /= ztbGOBdUCMvdDJHA;
    }

    return IboqdeKiiga;
}

bool hGLoUbrBHz::EZFNhI(bool WlhcJuXpT, bool UaTEVO)
{
    double EuxZiXJyOWx = -184152.045431116;
    double QfHBMKTnqhvE = -924059.4199497361;
    string LBkTspareSbV = string("tlIYCyySXgocJxmitsHQuWcdyaHRgCxeqXcWPYsOMcCDsdKQSeLZPfZUWLXliRPJOIYwUgCBCOthxtsDEWvgKyrzcLyTgVZljrpOJKwMTyCLKJBzXnMjPRKpMarsXKxaOGVOvkpCmnxlMordhNtoMuzsuHgyArtSOWrLnGmbrADkCapWcFIukJbySyDJEbVcWSVtxXCRjccpwOHXDRXdOQkgaPktBDYqlfBYDfVahWtfsAaAWpaAxjf");
    bool MJCemJXxEczFwV = false;
    double pQeLDCKtxQeA = 958090.4482444815;
    int DOItTlAD = -985284135;

    if (pQeLDCKtxQeA == 958090.4482444815) {
        for (int PeBUbNj = 1634109014; PeBUbNj > 0; PeBUbNj--) {
            UaTEVO = ! WlhcJuXpT;
        }
    }

    for (int IuteC = 1804031834; IuteC > 0; IuteC--) {
        EuxZiXJyOWx *= QfHBMKTnqhvE;
    }

    for (int XjzCJ = 300847187; XjzCJ > 0; XjzCJ--) {
        continue;
    }

    return MJCemJXxEczFwV;
}

string hGLoUbrBHz::CNCZGwqn(int LXLlUe, double vvzPRUzDzsF)
{
    double AGsQuqI = -686763.2405029766;
    double lVATl = -83184.21171381751;
    bool gOvCtYajnvsD = true;
    int fBGFcRMhdsr = 271528762;

    for (int YdsSkGPA = 1204291800; YdsSkGPA > 0; YdsSkGPA--) {
        vvzPRUzDzsF = AGsQuqI;
    }

    for (int ScwNDRrQlZjpSZUR = 1095251036; ScwNDRrQlZjpSZUR > 0; ScwNDRrQlZjpSZUR--) {
        vvzPRUzDzsF = vvzPRUzDzsF;
        fBGFcRMhdsr += LXLlUe;
    }

    if (lVATl > -83184.21171381751) {
        for (int DEfHaYEmYNEj = 1297599361; DEfHaYEmYNEj > 0; DEfHaYEmYNEj--) {
            continue;
        }
    }

    if (lVATl <= -859908.2882955003) {
        for (int MzksBqzgId = 1835420766; MzksBqzgId > 0; MzksBqzgId--) {
            vvzPRUzDzsF -= vvzPRUzDzsF;
        }
    }

    return string("oUiRlNuZgPHtVfCXEGQgbOZGWbmbtOiKHleVASSAWUDQvOfUYyFCDaYUxmjFmotuVYY");
}

bool hGLoUbrBHz::HgaOYrPoixwgHZE()
{
    double POBrRrNeToXbH = -48400.63290191548;
    double MXZKLFreFhgMDy = 277836.3242760373;

    if (MXZKLFreFhgMDy >= 277836.3242760373) {
        for (int wRlUaIcmEr = 1237255512; wRlUaIcmEr > 0; wRlUaIcmEr--) {
            POBrRrNeToXbH = POBrRrNeToXbH;
            MXZKLFreFhgMDy += POBrRrNeToXbH;
            POBrRrNeToXbH += MXZKLFreFhgMDy;
            POBrRrNeToXbH -= POBrRrNeToXbH;
            MXZKLFreFhgMDy *= MXZKLFreFhgMDy;
            POBrRrNeToXbH += MXZKLFreFhgMDy;
            POBrRrNeToXbH /= MXZKLFreFhgMDy;
        }
    }

    if (POBrRrNeToXbH != 277836.3242760373) {
        for (int meKAkMFrlPAt = 1089720449; meKAkMFrlPAt > 0; meKAkMFrlPAt--) {
            POBrRrNeToXbH /= MXZKLFreFhgMDy;
            POBrRrNeToXbH -= MXZKLFreFhgMDy;
            MXZKLFreFhgMDy += MXZKLFreFhgMDy;
            MXZKLFreFhgMDy -= POBrRrNeToXbH;
            POBrRrNeToXbH /= POBrRrNeToXbH;
            POBrRrNeToXbH *= POBrRrNeToXbH;
            POBrRrNeToXbH -= MXZKLFreFhgMDy;
            MXZKLFreFhgMDy -= POBrRrNeToXbH;
            MXZKLFreFhgMDy -= POBrRrNeToXbH;
            POBrRrNeToXbH -= POBrRrNeToXbH;
        }
    }

    return false;
}

void hGLoUbrBHz::MvsqSRazBUowmh()
{
    int TYebzWv = -1741959165;
    string vTYucpgcOlPo = string("AzzkjUMTCxHnmSVyhOoTVkRhGoqbdzIXKqUEOSlNrRRUvbFZDaQwZBhRCmUaRAhemzcEGqVCLVqfeUlg");
    string GMwhYoYNIXc = string("ngITNBzGtQJqfPZruDoHJVjxCvtKqniYwKOkfmYeHpyOtKTKlUHioTSAJxzkUgXbcCfFDHMlRfalhXBmJKFocDEgHNeqmgoJpcdHReebGyieXdkganXhVrvCezSIaAVxeCP");
    bool RmAhmNfoCU = true;
    bool cMoQqzYplREjqH = true;
    string zMdGvNdQthOr = string("PThTTbnok");
    bool ignMwsi = false;
    int AMOAJP = 1746911827;
    bool UEuBWRmwbOS = false;

    for (int PQbMCpIpoYHxhY = 982941763; PQbMCpIpoYHxhY > 0; PQbMCpIpoYHxhY--) {
        continue;
    }

    for (int vrmQsalnhyVGn = 1695266889; vrmQsalnhyVGn > 0; vrmQsalnhyVGn--) {
        ignMwsi = ignMwsi;
        UEuBWRmwbOS = ! UEuBWRmwbOS;
    }

    for (int jWzQje = 1137399109; jWzQje > 0; jWzQje--) {
        UEuBWRmwbOS = RmAhmNfoCU;
        ignMwsi = ! RmAhmNfoCU;
        AMOAJP *= TYebzWv;
        UEuBWRmwbOS = cMoQqzYplREjqH;
    }
}

bool hGLoUbrBHz::YLrEpFUTZRLuH()
{
    double NIdyQVguCfwpJKR = 502836.54233937175;
    double PgsyBIdoFwmxY = 75960.21328251984;
    int MgxUOYXgShm = 2119560612;

    if (PgsyBIdoFwmxY != 75960.21328251984) {
        for (int jEdAAEkWc = 1429926346; jEdAAEkWc > 0; jEdAAEkWc--) {
            MgxUOYXgShm /= MgxUOYXgShm;
            NIdyQVguCfwpJKR += PgsyBIdoFwmxY;
        }
    }

    for (int hHcim = 1421862040; hHcim > 0; hHcim--) {
        PgsyBIdoFwmxY += PgsyBIdoFwmxY;
    }

    for (int zAcwuiiDRUo = 1248975826; zAcwuiiDRUo > 0; zAcwuiiDRUo--) {
        PgsyBIdoFwmxY *= NIdyQVguCfwpJKR;
        NIdyQVguCfwpJKR += PgsyBIdoFwmxY;
        NIdyQVguCfwpJKR = PgsyBIdoFwmxY;
    }

    for (int blchR = 1059304447; blchR > 0; blchR--) {
        PgsyBIdoFwmxY += PgsyBIdoFwmxY;
    }

    for (int xHJMnRtjbe = 1510590846; xHJMnRtjbe > 0; xHJMnRtjbe--) {
        MgxUOYXgShm = MgxUOYXgShm;
        NIdyQVguCfwpJKR += NIdyQVguCfwpJKR;
        NIdyQVguCfwpJKR -= PgsyBIdoFwmxY;
        NIdyQVguCfwpJKR -= NIdyQVguCfwpJKR;
    }

    if (NIdyQVguCfwpJKR == 502836.54233937175) {
        for (int nruOcJAyca = 555722880; nruOcJAyca > 0; nruOcJAyca--) {
            PgsyBIdoFwmxY /= NIdyQVguCfwpJKR;
        }
    }

    return true;
}

double hGLoUbrBHz::ZaulNkajgT(int lbYIo, int mthvRTb)
{
    string YbVwbOfhTwIot = string("SYYAgJVyORhmTYFYSiDUvaKOaUADACwgfCeRlhbEQGGSMqZjmXwlKWyvyXodXaicUGRxpndSXBvbUscShXNjXyKgjGGPVcNFfqWmAHrFapugpQSRfxnSpLLpDkFxGDdSKdqUzwJDCYuQMigoIGYjGWFCtihVxJHJWMFBDsxXYUeIyKrZGjrjLaNkBcEHlZAFrcAdoQcvXXVRbCsBuSaJ");
    bool lQedyBIojZX = false;

    if (lQedyBIojZX != false) {
        for (int aDFnjeSyFtxGwr = 1681623803; aDFnjeSyFtxGwr > 0; aDFnjeSyFtxGwr--) {
            lQedyBIojZX = lQedyBIojZX;
            mthvRTb /= mthvRTb;
        }
    }

    if (lbYIo <= 1698536234) {
        for (int JiuUawFrkZ = 319897259; JiuUawFrkZ > 0; JiuUawFrkZ--) {
            mthvRTb /= mthvRTb;
            mthvRTb = mthvRTb;
        }
    }

    if (mthvRTb >= 1698536234) {
        for (int DaChw = 120519355; DaChw > 0; DaChw--) {
            lQedyBIojZX = ! lQedyBIojZX;
        }
    }

    for (int wmSekXglNx = 99008390; wmSekXglNx > 0; wmSekXglNx--) {
        lbYIo = lbYIo;
    }

    return 700266.4603839442;
}

bool hGLoUbrBHz::lRGXizGdahgKP(bool QjMDB, bool EcwJJSuW, bool KnekctTdx, bool laVzNnILlIxCc, bool syDrBUYWcTbcleAV)
{
    double lkagfqgqQZeb = -437396.42262341786;
    double XwFAvmvwrpeqy = 354631.99468549853;
    double LGdvITW = 390196.28585673764;
    int irTAh = -881361831;
    string zNjRAZMc = string("fiIWDTLHkMLbILdhOyHCPyzhcjCsJmTYcPvScAaMYnJPwaJxRpMJXQwWzyLQEJeBRbPJGxDLydZIVopIXvbeBdCJlTeBkkNilFZmzOWhumDegvPannBMnuMHxdjBuEC");
    double KcoNcYzcwYUg = 53230.684809844475;
    bool fULRcumpMIQBe = true;
    double LIYAGUN = 174825.66547154586;
    double ORixxSmIkp = 869032.2803675849;

    if (QjMDB != true) {
        for (int WjXSJZDbCLuFwDWN = 1196248317; WjXSJZDbCLuFwDWN > 0; WjXSJZDbCLuFwDWN--) {
            continue;
        }
    }

    if (irTAh < -881361831) {
        for (int hvNLpXcphD = 1506236535; hvNLpXcphD > 0; hvNLpXcphD--) {
            QjMDB = ! QjMDB;
            fULRcumpMIQBe = KnekctTdx;
        }
    }

    for (int fOuNMhZyAQGswcN = 635243025; fOuNMhZyAQGswcN > 0; fOuNMhZyAQGswcN--) {
        QjMDB = ! QjMDB;
    }

    for (int gmPxjodXRlTlKgsI = 2087631649; gmPxjodXRlTlKgsI > 0; gmPxjodXRlTlKgsI--) {
        fULRcumpMIQBe = ! laVzNnILlIxCc;
    }

    if (KnekctTdx != false) {
        for (int kRNiy = 801999468; kRNiy > 0; kRNiy--) {
            KcoNcYzcwYUg += LGdvITW;
            LGdvITW -= LGdvITW;
        }
    }

    return fULRcumpMIQBe;
}

bool hGLoUbrBHz::UpsRmrBW()
{
    int huZEzvvPcnjy = -1484345592;
    double lxBsOhqVu = 150646.8366684839;
    double WMcMjiCHyrzZwAga = -921884.5823518852;
    double dlCBxbGiXMg = 598282.3992017856;
    double xkkBACXR = -389806.5444839992;
    bool vOdyAAojhFgT = true;
    int NOUYetmigJEN = -2006757613;
    string FgDegsSBoLQ = string("PwlGNcBvafvovScpbYzUCfBWDAVHGAzRdFLPmYWOsUrhycOiPhSXSWfEIVnbBMpbklSgdtcAJHjKKAPlXtwNpYxwIiHqYrqWVDWkreQSjnTHhHLWCdAWcUfKClRmoVLtdhsZbMIJbAPtKLWATNjqbTfmydbMczrsiDBQNSHTBkOWn");
    string lmXKbGBjwPfyNl = string("kZrw");
    int JOtCnUl = 2084117029;

    for (int vVVnbZ = 2088417346; vVVnbZ > 0; vVVnbZ--) {
        continue;
    }

    if (FgDegsSBoLQ >= string("PwlGNcBvafvovScpbYzUCfBWDAVHGAzRdFLPmYWOsUrhycOiPhSXSWfEIVnbBMpbklSgdtcAJHjKKAPlXtwNpYxwIiHqYrqWVDWkreQSjnTHhHLWCdAWcUfKClRmoVLtdhsZbMIJbAPtKLWATNjqbTfmydbMczrsiDBQNSHTBkOWn")) {
        for (int vmuwBqjTFR = 624866419; vmuwBqjTFR > 0; vmuwBqjTFR--) {
            vOdyAAojhFgT = ! vOdyAAojhFgT;
            lxBsOhqVu = xkkBACXR;
        }
    }

    return vOdyAAojhFgT;
}

hGLoUbrBHz::hGLoUbrBHz()
{
    this->EdJArluSSdaOGQ(string("fDQKxIqKrNDedTmhhqUVXFAcfKjKFpBGucJIYGiyHwSPpauPJSFHuQlhCjrQAiZYjLuQb"), true, string("jTQROoWRVEoAPOQnVbYvTfWRJtzbPjcjEWWWdvZBitwMvkCCSdCvvvVUHmYdUhSjQoOgvHjqAFjTFpAJIzXIhECGmPOxvWuozelpbliLpyUtMtGytpzUdriVcEqaPokekjxexuppXVFwKUoCJHBPDSeSquKmhHfjXwvDOZoHcjb"), -731480.5084985452, -5375529);
    this->EZFNhI(false, false);
    this->CNCZGwqn(-1133656174, -859908.2882955003);
    this->HgaOYrPoixwgHZE();
    this->MvsqSRazBUowmh();
    this->YLrEpFUTZRLuH();
    this->ZaulNkajgT(1698536234, 1971065105);
    this->lRGXizGdahgKP(false, false, false, false, false);
    this->UpsRmrBW();
}
