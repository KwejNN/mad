#pragma once
namespace Fonts {
	#include "droid.hpp"
	#include "cousine.hpp"
}