#include "ClientMode.h"
#include "../features/Misc.h"

void AutoBlock(CUserCmd* cmd);
matrix3x4_t fakelag[128];

bool sendpacket = false;

bool gitchance(float hitchance) {

	if (1 > hitchance)
		return true;

	float inaccuracy = g_LocalPlayer->m_hActiveWeapon()->GetInaccuracy();
	if (inaccuracy == 0) inaccuracy = 0.0000001;
	inaccuracy = 1 / inaccuracy;
	return inaccuracy > hitchance;
}
void SetLocalPlayerReady()
{
	static auto SetLocalPlayerReadyFn = reinterpret_cast<bool(__stdcall*)(const char*)>(Utils::PatternScan(GetModuleHandleA("client.dll"), "55 8B EC 83 E4 F8 8B 4D 08 BA ? ? ? ? E8 ? ? ? ? 85 C0 75 12"));
	if (SetLocalPlayerReadyFn)
		SetLocalPlayerReadyFn("");
}
void aaccept() {
	typedef void(__cdecl* accept_t)(void);
	static accept_t accept = (accept_t)Utils::PatternScan(GetModuleHandleA("client.dll"),
		"55 8B EC 51 56 8B 35 ? ? ? ? 57 83 BE");

	if (accept && **(unsigned long**)((unsigned long)accept + 0x7)) {
		SetLocalPlayerReady();
	}
}

void autoaccept()
{
	auto match_session = g_match_framework->get_match_session();
	if (match_session) {
		auto session_settings = match_session->get_session_settings();
		if (session_settings) {

			//if (session_settings->GetString("game/mode", "competitive") || session_settings->GetString("game/mode", "wingman")) {

			std::string search_state = session_settings->GetString("game/mmqueue", "");

			if (search_state == "reserved") {
				FLASHWINFO fi;
				fi.cbSize = sizeof(FLASHWINFO);
				fi.hwnd = InputSys::Get().GetMainWindow();
				fi.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
				fi.uCount = 0;
				fi.dwTimeout = 0;
				FlashWindowEx(&fi);
				Sleep(500);
				aaccept();
			}
			//}
		}
	}
}
bool IsPlayerBehind(C_BasePlayer* player)
{
	Vector toTarget = (g_LocalPlayer->m_vecOrigin() - player->m_vecOrigin()).Normalized();
	Vector playerViewAngles;
	Math::AngleVectors(player->m_angEyeAngles(), playerViewAngles);
	if (toTarget.Dot(playerViewAngles) > -0.5f)
		return false;
	else
		return true;
}
void knifebot(CUserCmd* pCmd) {
	if (g_Options.kbot)
	{
		C_BaseCombatWeapon* pLocalWeapon = g_LocalPlayer->m_hActiveWeapon();
		if (pLocalWeapon && pLocalWeapon->GetCSWeaponData())
		{
			if (g_LocalPlayer->m_hActiveWeapon()->GetCSWeaponData()->iWeaponType == WEAPONTYPE_KNIFE)
			{

				for (int EntIndex = 1; EntIndex < g_EngineClient->GetMaxClients(); EntIndex++)
				{
					C_BasePlayer* Entity = (C_BasePlayer*)g_EntityList->GetClientEntity(EntIndex);

					if (!Entity)
						continue;

					if (!Entity->IsPlayer())
						continue;

					if (!Entity->IsAlive())
						continue;

					if (Entity == g_LocalPlayer)
						continue;

					float Distance = g_LocalPlayer->m_vecOrigin().DistTo(Entity->m_vecOrigin());

					if (Distance > 68)
						continue;

					if (Entity->m_iTeamNum() == g_LocalPlayer->m_iTeamNum())
						continue;

					Vector OrignWorld = Entity->m_vecOrigin();
					Vector OrignScreen;

					if (!Math::WorldToScreen(OrignWorld, OrignScreen))
						continue;

					static int cur_attack = 0;

					if (Distance > 60.f || Entity->m_iHealth() < 33)
						pCmd->buttons |= IN_ATTACK;
					else
					{
						if ((g_LocalPlayer->m_nTickBase() * g_GlobalVars->interval_per_tick) - pLocalWeapon->m_flNextPrimaryAttack() > 0)
						{
							if (!IsPlayerBehind(Entity)) {
								if (Entity->m_ArmorValue() > 0)
								{
									if (Entity->m_iHealth() > 61)
										pCmd->buttons |= IN_ATTACK;
									else
										pCmd->buttons |= IN_ATTACK2;
								}
								else
								{
									if (Entity->m_iHealth() < 33)
										pCmd->buttons |= IN_ATTACK;
									else
										pCmd->buttons |= IN_ATTACK2;
								}
							}
							else
								pCmd->buttons |= IN_ATTACK2;
						}

					}
				}
			}
		}
	}
}

QAngle vangle = QAngle();
float damage = 0.f;

void Desync(CUserCmd* cmd, bool& send_packet);

float anglereal = 0.f;
float anglefake = 0.f;
void fix_movement(CUserCmd* cmd, QAngle& wishangle)
{
	Vector view_fwd, view_right, view_up, cmd_fwd, cmd_right, cmd_up;
	Math::AngleVectors(wishangle, view_fwd, view_right, view_up);
	Math::AngleVectors(cmd->viewangles, cmd_fwd, cmd_right, cmd_up);

	const auto v8 = sqrtf((view_fwd.x * view_fwd.x) + (view_fwd.y * view_fwd.y));
	const auto v10 = sqrtf((view_right.x * view_right.x) + (view_right.y * view_right.y));
	const auto v12 = sqrtf(view_up.z * view_up.z);

	const Vector norm_view_fwd((1.f / v8) * view_fwd.x, (1.f / v8) * view_fwd.y, 0.f);
	const Vector norm_view_right((1.f / v10) * view_right.x, (1.f / v10) * view_right.y, 0.f);
	const Vector norm_view_up(0.f, 0.f, (1.f / v12) * view_up.z);

	const auto v14 = sqrtf((cmd_fwd.x * cmd_fwd.x) + (cmd_fwd.y * cmd_fwd.y));
	const auto v16 = sqrtf((cmd_right.x * cmd_right.x) + (cmd_right.y * cmd_right.y));
	const auto v18 = sqrtf(cmd_up.z * cmd_up.z);

	const Vector norm_cmd_fwd((1.f / v14) * cmd_fwd.x, (1.f / v14) * cmd_fwd.y, 0.f);
	const Vector norm_cmd_right((1.f / v16) * cmd_right.x, (1.f / v16) * cmd_right.y, 0.f);
	const Vector norm_cmd_up(0.f, 0.f, (1.f / v18) * cmd_up.z);

	const auto v22 = norm_view_fwd.x * cmd->forwardmove;
	const auto v26 = norm_view_fwd.y * cmd->forwardmove;
	const auto v28 = norm_view_fwd.z * cmd->forwardmove;
	const auto v24 = norm_view_right.x * cmd->sidemove;
	const auto v23 = norm_view_right.y * cmd->sidemove;
	const auto v25 = norm_view_right.z * cmd->sidemove;
	const auto v30 = norm_view_up.x * cmd->upmove;
	const auto v27 = norm_view_up.z * cmd->upmove;
	const auto v29 = norm_view_up.y * cmd->upmove;

	cmd->forwardmove = ((((norm_cmd_fwd.x * v24) + (norm_cmd_fwd.y * v23)) + (norm_cmd_fwd.z * v25))
		+ (((norm_cmd_fwd.x * v22) + (norm_cmd_fwd.y * v26)) + (norm_cmd_fwd.z * v28)))
		+ (((norm_cmd_fwd.y * v30) + (norm_cmd_fwd.x * v29)) + (norm_cmd_fwd.z * v27));
	cmd->sidemove = ((((norm_cmd_right.x * v24) + (norm_cmd_right.y * v23)) + (norm_cmd_right.z * v25))
		+ (((norm_cmd_right.x * v22) + (norm_cmd_right.y * v26)) + (norm_cmd_right.z * v28)))
		+ (((norm_cmd_right.x * v29) + (norm_cmd_right.y * v30)) + (norm_cmd_right.z * v27));
	cmd->upmove = ((((norm_cmd_up.x * v23) + (norm_cmd_up.y * v24)) + (norm_cmd_up.z * v25))
		+ (((norm_cmd_up.x * v26) + (norm_cmd_up.y * v22)) + (norm_cmd_up.z * v28)))
		+ (((norm_cmd_up.x * v30) + (norm_cmd_up.y * v29)) + (norm_cmd_up.z * v27));

	const auto ratio = 2.f - fmaxf(fabsf(cmd->sidemove), fabsf(cmd->forwardmove)) / 450.f;
	cmd->forwardmove *= ratio;
	cmd->sidemove *= ratio;

	wishangle = cmd->viewangles;
}


float autozeus(CUserCmd* cmd)
{
	auto weapon = g_LocalPlayer->m_hActiveWeapon();
	if (!weapon)
		return 0;
	const auto weapon_data = weapon->GetCSWeaponData();
	if (!weapon_data)
		return 0;

	if (!(weapon->m_Item().m_iItemDefinitionIndex() == WEAPON_TASER))
		return 0;

	Ray_t ray;
	CGameTrace tr;
	CTraceFilterWorldAndPropsOnly filter;

	for (int i = 1; i < g_GlobalVars->maxClients; i++) {
		auto player = (C_BasePlayer*)g_EntityList->GetClientEntity(i);
		if (!player || !player->IsAlive() || player->IsDormant() || player == g_LocalPlayer || player->m_iTeamNum() == g_LocalPlayer->m_iTeamNum())
			continue;
		auto hitbox = player->GetHitboxPos(HITBOX_CHEST);

		const auto distance = g_LocalPlayer->GetEyePos().DistTo(hitbox);
		if (distance > weapon_data->flRange)
			continue;
		damage = weapon_data->iDamage * pow(weapon_data->flRangeModifier, distance / 500);
		if (damage < 120.f && damage < player->m_iHealth())
			continue;
		return damage;
	}
}

bool is_delayed = false;
float shot_delay_time;
bool shot_delay = false;
bool IsLineGoesThroughSmokex(Vector vStartPos, Vector vEndPos) {
	static auto LineGoesThroughSmokeFn = (bool(*)(Vector vStartPos, Vector vEndPos))Utils::PatternScan(GetModuleHandleA("client.dll"), "55 8B EC 83 EC 08 8B 15 ? ? ? ? 0F 57 C0");
	return LineGoesThroughSmokeFn(vStartPos, vEndPos);
}
void TriggerBot(CUserCmd* usercmd) {
	if (g_Options.onkey && !GetAsyncKeyState(g_Options.trigbind)) {

		is_delayed = false;
		shot_delay = false;
		return;
	}

	std::vector<int> hitgroups;
	if (!(g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex() == WEAPON_TASER)) {
		if (g_Options.trighead)
			hitgroups.push_back(HITGROUP_HEAD);
		if (g_Options.trigchest)
			hitgroups.push_back(HITGROUP_CHEST);
		if (g_Options.trigstomach)
			hitgroups.push_back(HITGROUP_STOMACH);
		if (g_Options.trigleftarm)
			hitgroups.push_back(HITGROUP_LEFTARM);
		if (g_Options.trigrightarm)
			hitgroups.push_back(HITGROUP_RIGHTARM);
		if (g_Options.trigleftleg)
			hitgroups.push_back(HITGROUP_LEFTLEG);
		if (g_Options.trigrightleg)
			hitgroups.push_back(HITGROUP_RIGHTLEG);
	}
	else {
		hitgroups.push_back(HITGROUP_CHEST);
		hitgroups.push_back(HITGROUP_STOMACH);
	}
	Vector rem, forward,
		src = g_LocalPlayer->GetEyePos();

	trace_t tr;
	Ray_t ray;
	CTraceFilter filter;
	filter.pSkip = g_LocalPlayer;

	QAngle viewangles = usercmd->viewangles;

	//	auto settings = g_Options.aimbot[g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex()];

	QAngle rec;


	Math::AngleVectors(viewangles, forward);

	forward *= g_LocalPlayer->m_hActiveWeapon().Get()->GetCSWeaponData()->flRange;

	rem = src + forward;

	ray.Init(src, rem);

	UINT mask = MASK_SHOT | CONTENTS_GRATE;

	mask &= ~(CONTENTS_WINDOW);

	g_EngineTrace->TraceRay(ray, mask, &filter, &tr);

	if (!tr.hit_entity)
		return;
	bool dh = false;
	for (auto& hitgroupsorted : hitgroups) {
		if (tr.hitgroup == hitgroupsorted)
			dh = true;
	}
	auto player = reinterpret_cast<C_BasePlayer*>(tr.hit_entity);
	if (!player || player->IsDormant() || !player->IsAlive() || !player->IsPlayer())
		return;

	if (player->m_iTeamNum() == g_LocalPlayer->m_iTeamNum())
		return;

	if (IsLineGoesThroughSmokex(g_LocalPlayer->GetEyePos(), tr.endpos) && g_Options.trigchecksmoke)
		return;
	if (g_LocalPlayer->IsFlashed() && g_Options.trigcheckflash)
		return;





	if (dh && gitchance(g_Options.trighitchance))
	{
		if (!is_delayed && !shot_delay && g_Options.trigdelay > 0) {
			is_delayed = true;
			shot_delay = true;
			shot_delay_time = GetTickCount() + g_Options.trigdelay;
		}

		if (shot_delay && shot_delay_time <= GetTickCount()) {
			shot_delay = false;
		}

		if (!shot_delay)
		{
			is_delayed = false;
			shot_delay = false;
			usercmd->buttons |= IN_ATTACK;
		}
	}
	else
	{
		shot_delay_time = 0.f;
		is_delayed = false;
		shot_delay = false;
	}

}

int max_choke_ticks() {

	int maxticks = (*g_GameRules && (*g_GameRules)->IsValveDS()) ? 11 : 15;
	static int max_choke_ticks = 0;
	static int latency_ticks = 0;
	float fl_latency = g_EngineClient->GetNetChannelInfo()->GetLatency(FLOW_OUTGOING);
	int latency = TIME_TO_TICKS(fl_latency);;
	if (g_ClientState->chokedcommands <= 0)
		latency_ticks = latency;
	else latency_ticks = std::max(latency, latency_ticks);

	if (fl_latency >= g_GlobalVars->interval_per_tick)
		max_choke_ticks = 11 - latency_ticks;
	else max_choke_ticks = 11;
	return max_choke_ticks;
}
void updatelby(CCSGOPlayerAnimState* animstate);

float GetFullLatency() {
	return g_EngineClient->GetNetChannelInfo()->GetLatency(FLOW_INCOMING) + g_EngineClient->GetNetChannelInfo()->GetLatency(FLOW_OUTGOING);
}

void Clnatag() {

	static bool restore = false;
	static float lastchangetime = 0.0;
	if (g_Options.misc_clantag && g_LocalPlayer) {

		if (g_GlobalVars->curtime + (GetFullLatency() / 2) - lastchangetime >= 0.35f)
		{

			std::string Name;

			if (g_Options.misc_customclan && g_Options.customclan && g_Options.customclan[0] && g_Options.misc_clantaga)
				Name = g_Options.customclan;
			else
				if (!g_Options.misc_customclan)
					Name = _xor_("Linear$").c_str();
				else
					Name = _xor_(" ").c_str();

			Utils::SetClantag(Name.substr(0, int(g_GlobalVars->curtime + (GetFullLatency() / 2)) % Name.length()).c_str());
			lastchangetime = (g_GlobalVars->curtime + (GetFullLatency() / 2));
			restore = true;
		}
	}
	else if (restore) {
		restore = false;
		Utils::SetClantag("");
	}

}
#define Square(x) ((x)*(x))
#define FastSqrt(x)	(sqrt)(x)


#include "../features/c_ragebot.h"

void do_queue() {
	using handle_match_start_fn = bool(__thiscall*)(void*, const char*, char*, char*, char*);
	using create_session_fn = void* (__stdcall*)(void);

	static auto singleton = *(uint8_t**)(Utils::PatternScan(GetModuleHandle("client.dll"), "8B C8 89 0D ? ? ? ? 8D 41 08") + 4);
	static auto handle_match_start = (handle_match_start_fn)Utils::PatternScan(GetModuleHandle("client.dll"), "55 8B EC 51 53 56 8B F1 8B 0D ? ? ? ? 57 8B 01");
	static auto create_session = (create_session_fn)Utils::PatternScan(GetModuleHandle("client.dll"), "E8 ? ? ? ? 83 EC 14 E8");

	static auto search_started = []() {
		if (!singleton)
			return false;
		if (auto ls = *(uint8_t**)singleton; ls) {
			return *(uint32_t*)(ls + 0x10) != 0;
		}
		return false;
	};

	if (auto match_session = g_match_framework->get_match_session()) {
		if (!search_started()) {
			auto session_settings = match_session->get_session_settings();
			session_settings->SetString("game/type", "classic");
			session_settings->SetString("game/mode", "casual");
			session_settings->SetString("game/mapgroupname", "mg_de_dust2");
			match_session->update_session_settings(session_settings);
			handle_match_start(*(uint8_t**)singleton, "", "", "", "");
		}
	}
	else {
		create_session();
	}
}

void Fakelag(CUserCmd* cmd, bool& send_packet) {
	if (!g_Options.fakelag_enabled)
		return;

	if (g_Options.fakelag_unducking &&
		g_LocalPlayer->m_flDuckAmount() > 0.05f && g_LocalPlayer->m_flDuckAmount() < 0.95f) {
		send_packet = !(g_ClientState->chokedcommands < max_choke_ticks());
		return;
	}

	if (g_Options.fakelag_factor <= 0)
		return;

	int choke_factor = g_Options.misc_desync ? std::min(max_choke_ticks(), g_Options.fakelag_factor) : g_Options.fakelag_factor;

	auto LegitPeek = [choke_factor](CUserCmd* cmd, bool& send_packet) {
		static bool m_bIsPeeking = false;
		if (m_bIsPeeking) {
			send_packet = !(g_ClientState->chokedcommands < choke_factor);
			if (send_packet)
				m_bIsPeeking = false;
			return;
		}

		auto speed = g_LocalPlayer->m_vecVelocity().Length();
		if (speed <= 70.0f)
			return;

		auto collidable = g_LocalPlayer->GetCollideable();

		Vector min, max;
		min = collidable->OBBMins();
		max = collidable->OBBMaxs();

		min += g_LocalPlayer->m_vecOrigin();
		max += g_LocalPlayer->m_vecOrigin();

		Vector center = (min + max) * 0.5f;

		for (int i = 1; i <= g_GlobalVars->maxClients; ++i) {
			auto player = C_BasePlayer::GetPlayerByIndex(i);
			if (!player || !player->IsAlive() || player->IsDormant())
				continue;
			if (player == g_LocalPlayer || g_LocalPlayer->m_iTeamNum() == player->m_iTeamNum())
				continue;

			auto weapon = player->m_hActiveWeapon().Get();
			if (!weapon || weapon->m_iClip1() <= 0)
				continue;

			auto weapon_data = weapon->GetCSWeaponData();
			if (!weapon_data || weapon_data->iWeaponType <= WEAPONTYPE_KNIFE || weapon_data->iWeaponType >= WEAPONTYPE_C4)
				continue;

			auto eye_pos = player->GetEyePos();

			Vector direction;
			Math::AngleVectors(player->m_angEyeAngles(), direction);
			direction.NormalizeInPlace();

			Vector hit_point;
			bool hit = Math::IntersectionBoundingBox(eye_pos, direction, min, max, &hit_point);
			if (hit && eye_pos.DistTo(hit_point) <= weapon_data->flRange) {
				Ray_t ray;
				trace_t tr;
				CTraceFilterSkipEntity filter((C_BasePlayer*)player);
				ray.Init(eye_pos, hit_point);

				g_EngineTrace->TraceRay(ray, MASK_SHOT_HULL | CONTENTS_HITBOX, &filter, &tr);
				if (tr.contents & CONTENTS_WINDOW) { // skip windows
																							// at this moment, we dont care about local player
					filter.pSkip = tr.hit_entity;
					ray.Init(tr.endpos, hit_point);
					g_EngineTrace->TraceRay(ray, MASK_SHOT_HULL | CONTENTS_HITBOX, &filter, &tr);
				}

				if (tr.fraction == 1.0f || tr.hit_entity == g_LocalPlayer) {
					m_bIsPeeking = true;
					break;
				}
			}
		}
	};

	auto speed = g_LocalPlayer->m_vecVelocity().Length();
	bool standing = speed <= 1.0f;
	if (!g_Options.fakelag_standing && standing) {
		return;
	}

	if (!g_Options.fakelag_moving && !standing) {
		return;
	}

	enum FakelagMode {
		FakelagStatic = 0,
		FakelagSwitch,
		FakelagAdaptive,
		FakelagRandom,
		FakelagLegitPeek
	};

	float UnitsPerTick = 0.0f;

	int WishTicks = 0;
	int AdaptiveTicks = 2;
	static int LastRandomNumber = 5;
	static int randomSeed = 12345;

	switch (g_Options.fakelag_mode)
	{
	case FakelagSwitch:
		// apply same logic as static fakelag
		if (cmd->command_number % 30 > 15)
			break;
	case FakelagStatic:
		send_packet = !(g_ClientState->chokedcommands < choke_factor);
		break;
	case FakelagAdaptive:
		if (standing) {
			send_packet = !(g_ClientState->chokedcommands < choke_factor);
			break;
		}

		UnitsPerTick = g_LocalPlayer->m_vecVelocity().Length() * g_GlobalVars->interval_per_tick;
		while ((WishTicks * UnitsPerTick) <= 68.0f)
		{
			if (((AdaptiveTicks - 1) * UnitsPerTick) > 68.0f)
			{
				++WishTicks;
				break;
			}
			if ((AdaptiveTicks * UnitsPerTick) > 68.0f)
			{
				WishTicks += 2;
				break;
			}
			if (((AdaptiveTicks + 1) * UnitsPerTick) > 68.0f)
			{
				WishTicks += 3;
				break;
			}
			if (((AdaptiveTicks + 2) * UnitsPerTick) > 68.0f)
			{
				WishTicks += 4;
				break;
			}
			AdaptiveTicks += 5;
			WishTicks += 5;
			if (AdaptiveTicks > 16)
				break;
		}

		send_packet = !(g_ClientState->chokedcommands < WishTicks);
		break;
	case FakelagRandom:
		if (g_ClientState->chokedcommands < LastRandomNumber) {
			send_packet = false;
		}
		else {
			randomSeed = 0x41C64E6D * randomSeed + 12345;
			LastRandomNumber = (randomSeed / 0x10000 & 0x7FFFu) % choke_factor;
			send_packet = true;
		}
		break;
	case FakelagLegitPeek:
		LegitPeek(cmd, send_packet);
		break;
	}

	if (choke_factor < g_ClientState->chokedcommands)
		send_packet = true;

};

#include "../features/prediction.h"

void fakeduck(CUserCmd* pCmd, bool& bSendPacket) {
	int fakelag_limit = 14;
	int choked_goal = fakelag_limit / 2;



	if (g_LocalPlayer->m_fFlags() & FL_ONGROUND)
	{
		bSendPacket = g_ClientState->m_NetChannel->m_nChokedPackets >= fakelag_limit;

		if (g_ClientState->chokedcommands <= 7)
			pCmd->buttons &= ~IN_DUCK;
		else
			pCmd->buttons |= IN_DUCK;
	}
}

void nosmoke() {
	static bool set = true;

	static std::vector<const char*> vistasmoke_wireframe =
	{
		"particle/vistasmokev1/vistasmokev1_smokegrenade",
		"particle/vistasmokev1/vistasmokev1_fire",
		"particle/vistasmokev1/vistasmokev1_emods",
		"particle/vistasmokev1/vistasmokev1_emods_impactdust",
	};

	if (!g_Options.nosmoke)
	{
		if (set)
		{
			for (auto material_name : vistasmoke_wireframe)
			{
				IMaterial* mat = g_MatSystem->FindMaterial(material_name, TEXTURE_GROUP_OTHER);
				mat->SetMaterialVarFlag(MATERIAL_VAR_WIREFRAME, false);
			}
			set = false;
		}
		return;
	}

	set = true;
	for (auto material_name : vistasmoke_wireframe)
	{
		IMaterial* mat = g_MatSystem->FindMaterial(material_name, TEXTURE_GROUP_OTHER);
		mat->SetMaterialVarFlag(MATERIAL_VAR_WIREFRAME, true);
	}
	//static auto shit = *(DWORD*)(Utils::PatternScan(GetModuleHandleA("client.dll"), "55 8B EC 83 EC 08 8B 15 ? ? ? ? 0F 57 C0") + 0x8);
	//if(shit)
	//	if (g_Options.nosmoke)
	//		*(int*)(shit) = 0;


}

void CorrectMouse(CUserCmd* cmd) {
	static ConVar* m_yaw = m_yaw = g_CVar->FindVar("m_yaw");
	static ConVar* m_pitch = m_pitch = g_CVar->FindVar("m_pitch");
	static ConVar* sensitivity = sensitivity = g_CVar->FindVar("sensitivity");

	static QAngle m_angOldViewangles = g_ClientState->viewangles;

	float delta_x = std::remainderf(cmd->viewangles.pitch - m_angOldViewangles.pitch, 360.0f);
	float delta_y = std::remainderf(cmd->viewangles.yaw - m_angOldViewangles.yaw, 360.0f);

	if (delta_x != 0.0f) {
		float mouse_y = -((delta_x / m_pitch->GetFloat()) / sensitivity->GetFloat());
		short mousedy;
		if (mouse_y <= 32767.0f) {
			if (mouse_y >= -32768.0f) {
				if (mouse_y >= 1.0f || mouse_y < 0.0f) {
					if (mouse_y <= -1.0f || mouse_y > 0.0f)
						mousedy = static_cast<short>(mouse_y);
					else
						mousedy = -1;
				}
				else {
					mousedy = 1;
				}
			}
			else {
				mousedy = 0x8000u;
			}
		}
		else {
			mousedy = 0x7FFF;
		}

		cmd->mousedy = mousedy;
	}

	if (delta_y != 0.0f) {
		float mouse_x = -((delta_y / m_yaw->GetFloat()) / sensitivity->GetFloat());
		short mousedx;
		if (mouse_x <= 32767.0f) {
			if (mouse_x >= -32768.0f) {
				if (mouse_x >= 1.0f || mouse_x < 0.0f) {
					if (mouse_x <= -1.0f || mouse_x > 0.0f)
						mousedx = static_cast<short>(mouse_x);
					else
						mousedx = -1;
				}
				else {
					mousedx = 1;
				}
			}
			else {
				mousedx = 0x8000u;
			}
		}
		else {
			mousedx = 0x7FFF;
		}

		cmd->mousedx = mousedx;
	}
}
#include "../features/animfixed shit.h"
#include "../features/entities.h"
#include "../features/AimLegit.h"

void NormalizeInOut(Vector& vIn, Vector& vOut)
{
	float flLen = vIn.Length();
	if (flLen == 0) {
		vOut.Init(0, 0, 1);
		return;
	}
	flLen = 1 / flLen;
	vOut.Init(vIn.x * flLen, vIn.y * flLen, vIn.z * flLen);
}

void Walkbot(QAngle& OrigAng, CUserCmd* cmd)
{

	bool walkbotBefore = false;

	QAngle viewangles;
	g_EngineClient->GetViewAngles(&viewangles);

	static int OldMouseX = OrigAng.yaw;
	int mousedx = OldMouseX - OrigAng.yaw;

	auto fDistanceToWall = [&](QAngle diff = QAngle(0, 0, 0))->float {
		auto tmpviewangles = viewangles + diff;
		trace_t tr;
		Ray_t ray;
		CTraceFilter filter;
		filter.pSkip = g_LocalPlayer;
		Vector begin = g_LocalPlayer->GetEyePos(), t, end;
		Math::AngleVectors(tmpviewangles, t);
		NormalizeInOut(t, end);
		end *= 8192.0f;
		end += begin;
		ray.Init(begin, end);
		g_EngineTrace->TraceRay(ray, 0x4600400B, &filter, &tr);
		return (begin - tr.endpos).Size();
	};

	static float old1, old2, old3;
	if (g_LocalPlayer->m_vecVelocity().Length() < 3)
	{
		viewangles.yaw += 2.0f;
	}
	float Distances = 100;
	if (fDistanceToWall() < Distances) // we are near to some wall
	{
		int turn = 5;
		float negativeDist = fDistanceToWall(QAngle(0, -1, 0)), positiveDist = fDistanceToWall(QAngle(0, 1, 0));
		if (abs(negativeDist - positiveDist) < 1.0f)
		{
			viewangles.yaw += turn;
		}
		else
		{
			viewangles.yaw += positiveDist < negativeDist ? -1 : 1;
		}
	}

	while (viewangles.yaw > 180.0f)
		viewangles.yaw -= 360.0f;
	while (viewangles.yaw < -180.0f)
		viewangles.yaw += 360.0f;

	g_EngineClient->SetViewAngles(&viewangles);

	if (!walkbotBefore)
	{
		cmd->forwardmove = 450.f;
		walkbotBefore = true;
	}

	else if (walkbotBefore)
	{
		walkbotBefore = false;
		cmd->forwardmove = 450.f;
	}
}



bool changeName(bool reconnect, const char* newName, float delay) noexcept
{
	static auto exploitInitialized{ false };

	static auto name{ g_CVar->FindVar("name") };

	if (reconnect) {
		exploitInitialized = false;
		return false;
	}

	if (!exploitInitialized && g_EngineClient->IsInGame()) {
		if (player_info_s playerInfo; g_EngineClient->GetPlayerInfo(g_LocalPlayer->EntIndex(), &playerInfo) && (!strcmp(playerInfo.szName, "?empty") || !strcmp(playerInfo.szName, "\n\xAD\xAD\xAD"))) {
			exploitInitialized = true;
		}
		else {
			name->m_fnChangeCallbacks.m_Size = 0;
			name->SetValue("\n\xAD\xAD\xAD");
			return false;
		}
	}

	static auto nextChangeTime{ 0.0f };
	if (nextChangeTime <= g_GlobalVars->realtime) {
		name->SetValue(newName);
		nextChangeTime = g_GlobalVars->realtime + delay;
		return true;
	}
	return false;
}
void NameSteal() {
	if (g_Options.namestealer) {
		const auto localPlayer = g_LocalPlayer;

		bool allNamesStolen = true;
		static std::vector<int> stolenIds;
		for (int i = 1; i <= g_EngineClient->GetMaxClients(); i++) {
			if (auto entity = (C_BasePlayer*)g_EntityList->GetClientEntity(i); entity && entity != localPlayer && entity->m_iTeamNum() == g_LocalPlayer->m_iTeamNum()) {
				player_info_t playerInfo;
				if (g_EngineClient->GetPlayerInfo(entity->EntIndex(), &playerInfo) && !playerInfo.fakeplayer && std::find(std::begin(stolenIds), std::end(stolenIds), playerInfo.userId) == std::end(stolenIds)) {
					allNamesStolen = false;
					if (changeName(false, std::string{ playerInfo.szName }.append("\x1").c_str(), 1.0f))
						stolenIds.push_back(playerInfo.userId);
					break;
				}
			}
		}
		if (allNamesStolen)
			stolenIds.clear();
	}
}
bool __stdcall Hooks::hkCreateMove(float input_sample_frametime, CUserCmd* cmd)
{
	static auto original = clientmode_hook.get_original<decltype(&hkCreateMove)>(index::CreateMove);
	original(input_sample_frametime, cmd);

	uintptr_t* FPointer; __asm { MOV FPointer, EBP }
	byte* SendPacket = (byte*)(*FPointer - 0x1C);

	if (!cmd || !cmd->command_number || g_Unload)	return original;
	if (!g_LocalPlayer)								return original;

	Globals::cmd = cmd;

	if (original)
		g_Prediction->SetLocalViewangles(Vector(cmd->viewangles.pitch, cmd->viewangles.yaw, cmd->viewangles.roll));

	if (g_Options.misc_bhop)						BunnyHop::OnCreateMove(cmd);
	if (g_Options.misc_autostrafer)					BunnyHop::AutoStrafe(cmd, cmd->viewangles);

	bool bSendPacket = *SendPacket;
	C_BaseCombatWeapon* weapon = g_LocalPlayer->m_hActiveWeapon();
	sendpacket = bSendPacket;

	static float SpawnTime = 0.0f;
	if (g_LocalPlayer->m_flSpawnTime() != SpawnTime) {
		g_AnimState.pBaseEntity = g_LocalPlayer;
		g_LocalPlayer->ResetAnimationState(&g_AnimState);
		SpawnTime = g_LocalPlayer->m_flSpawnTime();
	}


	if (g_Options.enable_legitbot)
		legitbot().do_aimbot(g_LocalPlayer, weapon, cmd);

	NewBacktrack::Get().LegitBacktrack(cmd);


	Clnatag();

	if (g_Options.solbicak)
		Misc::Get().SolEl();

	if (g_Options.misc_chatspam)
		Misc::Get().SohbetSpam();

	NameSteal();
	auto unpred_flags = g_LocalPlayer->m_fFlags();
	auto oldangles = cmd->viewangles;

	g_Options.dista = cmd->random_seed;


	EnginePred::BeginPred(cmd);
	{
		AutoBlock(cmd);

		if (cmd->command_number % 2 == 1 && bSendPacket && !(g_Options.fakeduck && GetAsyncKeyState(g_Options.fakeduck_bind)) && g_Options.misc_desync)
			bSendPacket = false;

		if (g_Options.edgejump && GetAsyncKeyState(g_Options.edgejump_bind))
		{
			if ((unpred_flags & FL_ONGROUND) && !(g_LocalPlayer->m_fFlags() & FL_ONGROUND))
				cmd->buttons |= IN_JUMP;
		}
		QAngle angleold = cmd->viewangles;
		if (g_LocalPlayer->m_hActiveWeapon()) {


			if (g_Options.trigenable || g_LocalPlayer->m_hActiveWeapon()->m_Item().m_iItemDefinitionIndex() == WEAPON_TASER)
				TriggerBot(cmd);

			if (g_Options.kbot)
				knifebot(cmd);


			//c_ragebot::aim(g_LocalPlayer, cmd, bSendPacket);
			animation_system.local_animation.eye_angles = cmd->viewangles;
		}



		if (g_Options.misc_desync && g_ClientState->chokedcommands >= max_choke_ticks()) {
			bSendPacket = true;
		}

		if (g_Options.misc_desync && std::fabsf(g_LocalPlayer->m_flSpawnTime() - g_GlobalVars->curtime) > 1.0f)
			Desync(cmd, bSendPacket);
		CorrectMouse(cmd);

		auto anim_state = g_LocalPlayer->GetPlayerAnimState();
		if (anim_state) {
			CCSGOPlayerAnimState anim_state_backup = *anim_state;
			*anim_state = g_AnimState;
			g_LocalPlayer->GetVAngles() = cmd->viewangles;
			g_LocalPlayer->UpdateClientSideAnimation();

			updatelby(anim_state);

			g_AnimState = *anim_state;
			*anim_state = anim_state_backup;
		}
		if (bSendPacket) {
			anglereal = g_AnimState.m_flGoalFeetYaw;
			if (anim_state)
				anglefake = anim_state->m_flGoalFeetYaw;
			vangle = cmd->viewangles;
		}


		fix_movement(cmd, angleold);
	}
	EnginePred::EndPred();

	if (g_Options.fakeduck && GetAsyncKeyState(g_Options.fakeduck_bind) && !g_EngineClient->IsVoiceRecording())
		fakeduck(cmd, bSendPacket);

	if (g_Options.fakeduck && GetAsyncKeyState(g_Options.fakeduck_bind));
	cmd->buttons |= IN_BULLRUSH;

	if (!g_EngineClient->IsVoiceRecording() && !(g_Options.fakeduck && GetAsyncKeyState(g_Options.fakeduck_bind)))
		Fakelag(cmd, bSendPacket);

	nosmoke();

	if (g_LocalPlayer && InputSys::Get().IsKeyDown(VK_TAB) && g_Options.misc_rankreveal)
		Utils::RankRevealAll();


	Math::FixAngles(cmd->viewangles);
	std::clamp(cmd->sidemove, -450.f, 450.f);
	std::clamp(cmd->forwardmove, -450.f, 450.f);
	std::clamp(cmd->upmove, -320.f, 320.f);
	Globals::bSendPacket = bSendPacket;
	*SendPacket = bSendPacket;

	return false;
}


void __fastcall Hooks::hkOverrideView(void* _this, int edx, CViewSetup* vsView)
{
	static auto override_view_o = clientmode_hook.get_original<decltype(&hkOverrideView)>(index::OverrideView);

	if (g_EngineClient->IsInGame() && g_LocalPlayer && vsView) {

		auto r_modelAmbientMin = g_CVar->FindVar("r_modelAmbientMin");
		auto mat_force_tonemap_scale = g_CVar->FindVar("mat_force_tonemap_scale");
		auto mat_ambient_light_r = g_CVar->FindVar("mat_ambient_light_r");
		auto mat_ambient_light_g = g_CVar->FindVar("mat_ambient_light_g");
		auto mat_ambient_light_b = g_CVar->FindVar("mat_ambient_light_b");

		g_CVar->FindVar("weapon_debug_spread_show")->SetValue(g_Options.crosshair && !g_LocalPlayer->m_bIsScoped() ? 3 : 0);

		if (!g_Unload) {

			if (g_Options.other_mat_ambient_light_rainbow) {
				static float rainbow; rainbow += 0.005f; if (rainbow > 1.f) rainbow = 0.f;
				auto rainbow_col = Color::FromHSB(rainbow, 1.0f, 1.0f);
				mat_ambient_light_r->SetValue(rainbow_col.r() / 255.0f);
				mat_ambient_light_g->SetValue(rainbow_col.g() / 255.0f);
				mat_ambient_light_b->SetValue(rainbow_col.b() / 255.0f);
			}
			else
			{
				if (mat_ambient_light_r->GetFloat() != 0.f)			mat_ambient_light_r->SetValue(0.f);
				if (mat_ambient_light_g->GetFloat() != 0.f)			mat_ambient_light_g->SetValue(0.f);
				if (mat_ambient_light_b->GetFloat() != 0.f)			mat_ambient_light_b->SetValue(0.f);
			}
		}
		else {
			if (r_modelAmbientMin->GetFloat() != 0.f)			r_modelAmbientMin->SetValue(0.f);
			if (mat_force_tonemap_scale->GetFloat() != 1.f)		mat_force_tonemap_scale->SetValue(1.f);
			//	if (mat_postprocess_enable->GetInt() != 0)			mat_postprocess_enable->SetValue(0);
			if (mat_ambient_light_r->GetFloat() != 0.f)			mat_ambient_light_r->SetValue(0.f);
			if (mat_ambient_light_g->GetFloat() != 0.f)			mat_ambient_light_g->SetValue(0.f);
			if (mat_ambient_light_b->GetFloat() != 0.f)			mat_ambient_light_b->SetValue(0.f);
		}

		if (g_Options.nozoom)
		{

		}
		/*if (g_Options.other_drawfov)
		{
			QAngle viewPunch = g_LocalPlayer->m_viewPunchAngle();
			QAngle aimPunch = g_LocalPlayer->m_aimPunchAngle();

			vsView->angles[0] -= (viewPunch[0] + (aimPunch[0] * 2 * 0.4499999f));
			vsView->angles[1] -= (viewPunch[1] + (aimPunch[1] * 2 * 0.4499999f));
			vsView->angles[2] -= (viewPunch[2] + (aimPunch[2] * 2 * 0.4499999f));
		}*/

		g_CVar->FindVar("zoom_sensitivity_ratio_mouse")->SetValue(float(!g_Options.nozoom));

		if (!Globals::got_w2s_matrix)
		{
			Globals::got_w2s_matrix = true;
			Globals::w2s_offset = (reinterpret_cast<DWORD>(&g_EngineClient->WorldToScreenMatrix()) + 0x40);
		}

		static auto viewmodel_fov = g_CVar->FindVar("viewmodel_fov");

		viewmodel_fov->m_fnChangeCallbacks.m_Size = 0;
		viewmodel_fov->SetValue(g_Options.misc_viewmodel_fov);

		Visuals::Get().ThirdPerson();
		if (!g_LocalPlayer->m_bIsScoped())
			vsView->fov = g_Options.misc_fov;
		else if (g_LocalPlayer->m_bIsScoped() && g_Options.nozoom && g_LocalPlayer->m_hActiveWeapon() &&
			g_LocalPlayer->m_hActiveWeapon()->m_iItemDefinitionIndex() != WEAPON_SG556 &&
			g_LocalPlayer->m_hActiveWeapon()->m_iItemDefinitionIndex() != WEAPON_AUG)
			vsView->fov = g_Options.misc_fov;

		if (g_Options.fakeduck && GetAsyncKeyState(g_Options.fakeduck_bind) && g_LocalPlayer->IsAlive() && g_LocalPlayer->m_fFlags() & FL_ONGROUND)
			vsView->origin.z = g_LocalPlayer->m_vecOrigin().z + 64;

		if (g_Options.esp_grenade_prediction && g_LocalPlayer->m_hActiveWeapon())
			GrenadePrediction::Get().View(vsView);
	}
	override_view_o(g_ClientMode, edx, vsView);
}
#include "../features/glow.hpp"
int __fastcall Hooks::hkDoPostScreenEffects(void* _this, int edx, int a1)
{
	static auto do_pose_effects_o = clientmode_hook.get_original<decltype(&hkDoPostScreenEffects)>(index::DoPostScreenSpaceEffects);

	if (g_LocalPlayer && g_Options.glow_enabled)
		Glow::Get().Run();

	return do_pose_effects_o(g_ClientMode, edx, a1);
}
/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ONXblIznS
{
public:
    string qcaVwemryGQ;
    double FvCbFD;
    double SlRJeUxkGB;

    ONXblIznS();
    bool uUhnyuxQAC(int GlggAhmBKhznkRU, int ycbxlzg, int mvlOxJnxAwZ);
    void kNuCbOqNbiFGreMd(string okAYsJg, double BqGNj, int RbmMr);
    void wFdCtarZO(double DjmhLXlP);
    int MFXrcLIz(int aOvsMOv, bool eEZoMvz, bool ZwLXlNK, string gwFJvmhQ, string EJzTUKl);
    bool fZkXjWmmi(string MHqoXqqxGfrzhr, int jisweKDm, int cjcvUcfmt, double OVBMDfjyKSgew, int UnpbNFqOo);
    int rjFivNLJVXqKFU(double jYettZKqhX, string uhBRnUBMTEgwRO, string tctNsHbzUmVsP, string WnjZsLvHbWjN, double APsnDOc);
    bool MNVEfQaHhP(double tRXuAspYeFCe, double RvypjShLUxqXAk, int eAdgF, int rlJUuiqWswlCze, bool SnHrqe);
    string bJYDrlk(bool MHDaniOnRylJVSlI, double UhnoHuaKvn, bool ZOSJYSTBkjs, int ZWHMmPCUmc, double WKNXE);
protected:
    int NzgJLFwCb;
    int YEYNrKvKQAzG;
    bool oxZGmncKKlhvt;
    double vGdOlTTOWqtybk;

    int oGhxowXWiuFjqD();
    void EVPotbvDlKCDIe(string TZoMBWeBFwhiay);
    bool ntsCJ(bool OMzJbq);
    void ESRMAHpHJE(int tHeBbihatjaOjGD, int TvLpWXepAvdz);
    bool uVBfIBhbQH(double djXcPsArMOL, string nJqVbSLFGXTJI);
    double XfcQOiVshoBMU(double aMmmuutYJKEUA);
private:
    double UJfWb;
    int xnyOUZfJnwzQUJd;
    double oITNPefou;
    double ZDNYPXvmeaNSjhPl;
    string HUvQbACaCCWYYfJ;

    int qUqXDgYciqiFrbD(double ZmwCzaQSMfnkGwOw, bool OzrtrYuBWSlZZj, bool VshhJtaMCDWL);
    double wcCDToIfcRnrHAS(int fqHdZgYyAhOrB, bool ELdtQkwnX, string RfQqFAiFogo, int XtyVOCaqRadWpA, bool lJVhOH);
    string czetzJdUDZElCso(int AJqWUePyTIY);
    bool gdPPKn(double TbijkvmU);
    bool oKpZaMzF(double FrvxUhvxMkqMg, int NNmIDkerTtnzcIpl, double UuxthJfLzNtKwLK, int xwYREhujGV);
    int TWJgRHuNuSV(double eNzdKpJifFEvKSMi, bool xrhMkngaRdNks, int BxajsgNCVQxzMtyE);
    string hvYziJMkvjrhUG();
    int dFzkzWgPD(double JruChONevZKC);
};

bool ONXblIznS::uUhnyuxQAC(int GlggAhmBKhznkRU, int ycbxlzg, int mvlOxJnxAwZ)
{
    string ANWtPNMF = string("vBRwVabIRrnHtxhJcAjrfyccrpJhSFzgQuBgRZzKdPPIWGhnEWrSrAQVmnzUEyjzdYzTkQPStuynIlQnaXqtlWBiDLZ");
    double qjngDLxGWKYmJTj = 301570.1563638529;

    for (int NYczpGE = 1751965102; NYczpGE > 0; NYczpGE--) {
        GlggAhmBKhznkRU = GlggAhmBKhznkRU;
        ycbxlzg += GlggAhmBKhznkRU;
        GlggAhmBKhznkRU -= GlggAhmBKhznkRU;
    }

    for (int yMiZsSaVBuETiHk = 1543064940; yMiZsSaVBuETiHk > 0; yMiZsSaVBuETiHk--) {
        GlggAhmBKhznkRU *= ycbxlzg;
        GlggAhmBKhznkRU -= GlggAhmBKhznkRU;
        qjngDLxGWKYmJTj /= qjngDLxGWKYmJTj;
        GlggAhmBKhznkRU *= mvlOxJnxAwZ;
    }

    for (int AyUWSinpbYkbXgm = 38308528; AyUWSinpbYkbXgm > 0; AyUWSinpbYkbXgm--) {
        mvlOxJnxAwZ /= GlggAhmBKhznkRU;
        mvlOxJnxAwZ /= GlggAhmBKhznkRU;
    }

    for (int UynuaxtgiJVYcdQq = 647467174; UynuaxtgiJVYcdQq > 0; UynuaxtgiJVYcdQq--) {
        mvlOxJnxAwZ -= GlggAhmBKhznkRU;
        ycbxlzg *= ycbxlzg;
        GlggAhmBKhznkRU += GlggAhmBKhznkRU;
        qjngDLxGWKYmJTj = qjngDLxGWKYmJTj;
    }

    return true;
}

void ONXblIznS::kNuCbOqNbiFGreMd(string okAYsJg, double BqGNj, int RbmMr)
{
    int IyOryCydcDrgOCH = -1734573155;
    int vjDeTg = 1600464782;
    double RpFSR = 201619.69672458174;
    string FWTjFcxZnoQwsV = string("cZVCuOvoLkHUtDuooCYwnTVUFoiupiEmwGNJaGrSuFQYNtiRlNPlaefNqgnkufBLJOcAcsWLNkmnIWWRIVsWkGDfNxYfWvjVcLRUGrlgldrmgofyUEHYhVQESExshDjjGsIiBUsNXAXvtW");

    for (int msznFAeMkWopQGy = 1797735891; msznFAeMkWopQGy > 0; msznFAeMkWopQGy--) {
        continue;
    }

    if (okAYsJg <= string("cZVCuOvoLkHUtDuooCYwnTVUFoiupiEmwGNJaGrSuFQYNtiRlNPlaefNqgnkufBLJOcAcsWLNkmnIWWRIVsWkGDfNxYfWvjVcLRUGrlgldrmgofyUEHYhVQESExshDjjGsIiBUsNXAXvtW")) {
        for (int UDljwwrxdoQheU = 80249846; UDljwwrxdoQheU > 0; UDljwwrxdoQheU--) {
            RbmMr -= RbmMr;
        }
    }
}

void ONXblIznS::wFdCtarZO(double DjmhLXlP)
{
    double JkbZjKpqzKSnTJt = -1002398.70930863;
    string QshkPpsHmcKLjfx = string("cCRFUXIwbEnnbitZfaNNRUpltdKQFUpCFLQnMMqJRySiwGyomUhaGHOhedagGhCcgdtYLZVLGOXnacdQsRVeSiPIMIQVgywuZwlngZjVwRaNXVgkMtTEnfXyHECtGAexDPKAvSty");

    if (DjmhLXlP > 391724.9522038769) {
        for (int DMtiCVrfaTpBQGg = 1964423414; DMtiCVrfaTpBQGg > 0; DMtiCVrfaTpBQGg--) {
            continue;
        }
    }

    if (QshkPpsHmcKLjfx != string("cCRFUXIwbEnnbitZfaNNRUpltdKQFUpCFLQnMMqJRySiwGyomUhaGHOhedagGhCcgdtYLZVLGOXnacdQsRVeSiPIMIQVgywuZwlngZjVwRaNXVgkMtTEnfXyHECtGAexDPKAvSty")) {
        for (int isgoOHyPBhTxv = 170974273; isgoOHyPBhTxv > 0; isgoOHyPBhTxv--) {
            JkbZjKpqzKSnTJt /= JkbZjKpqzKSnTJt;
            JkbZjKpqzKSnTJt += DjmhLXlP;
        }
    }

    for (int AJQaRry = 1051232955; AJQaRry > 0; AJQaRry--) {
        DjmhLXlP = DjmhLXlP;
    }

    for (int iJBPGbdKoVSc = 1194517131; iJBPGbdKoVSc > 0; iJBPGbdKoVSc--) {
        DjmhLXlP = JkbZjKpqzKSnTJt;
        DjmhLXlP += DjmhLXlP;
        JkbZjKpqzKSnTJt *= DjmhLXlP;
        DjmhLXlP += JkbZjKpqzKSnTJt;
        DjmhLXlP += JkbZjKpqzKSnTJt;
    }
}

int ONXblIznS::MFXrcLIz(int aOvsMOv, bool eEZoMvz, bool ZwLXlNK, string gwFJvmhQ, string EJzTUKl)
{
    int SykDP = -1733627055;
    string XlOnzkwrBboiEQtL = string("gaYeGwnMETaFxJXNerqWylmwxkHqxeezeDQNTJirxpEWITSWqdAXYsoKDSYpFeEtCWJbyp");
    bool ypBvtuOLtz = true;
    double JUBNnhupei = -109606.81949662825;
    int srmrxUUu = 1279576172;
    bool ZRFbX = true;
    string waLLblnxg = string("rkkEcViMOwyAeGvcyVjoNeetGKXJZMPqGuvcEHzUKNKBSwIPsCWGIvVbGwDAZeFQRQZcgTeSANArPhvjUOWZrnDeJIdTitQSvnCQfuDLXAGXjwJfuEROUkNkyjDnEzvYKGEwXCnhvUItnJQorAIcoQOOwZyqirpVboUqjkDKTXeUyPACpmIfikrRCSxEHUMqA");
    int QRXoZ = 1971275059;
    string bLzOl = string("tCYTParISDjQJUrejF");

    if (ZRFbX == true) {
        for (int WmHYlFqf = 1000052164; WmHYlFqf > 0; WmHYlFqf--) {
            ypBvtuOLtz = ! eEZoMvz;
        }
    }

    return QRXoZ;
}

bool ONXblIznS::fZkXjWmmi(string MHqoXqqxGfrzhr, int jisweKDm, int cjcvUcfmt, double OVBMDfjyKSgew, int UnpbNFqOo)
{
    string SdYjHDBwdJkbyJXV = string("xZHBYrGRHygXIOFQXbLIFQeeCMoBEvRHKBdGmdwjoBRsNrJLrRSdzrzSLbplaUeAfovJWpfRBCkYCOskPqhWBySepUmkKOHeeXfirgaYbRQpNXdTBITTGorcWYqvRdpsgPogTBmUZtNfgduXKWEWKeHSsnTFgezENaxgPvRamRFMKAgQvhERFrezylCwI");

    return true;
}

int ONXblIznS::rjFivNLJVXqKFU(double jYettZKqhX, string uhBRnUBMTEgwRO, string tctNsHbzUmVsP, string WnjZsLvHbWjN, double APsnDOc)
{
    bool ehgHsO = false;
    bool XlZwUjPRJqpDE = true;

    for (int uNkiIIdWDby = 1504769107; uNkiIIdWDby > 0; uNkiIIdWDby--) {
        tctNsHbzUmVsP = tctNsHbzUmVsP;
        uhBRnUBMTEgwRO = WnjZsLvHbWjN;
    }

    for (int oFDUGxvzcFLBW = 880913643; oFDUGxvzcFLBW > 0; oFDUGxvzcFLBW--) {
        jYettZKqhX += APsnDOc;
    }

    return -1512303618;
}

bool ONXblIznS::MNVEfQaHhP(double tRXuAspYeFCe, double RvypjShLUxqXAk, int eAdgF, int rlJUuiqWswlCze, bool SnHrqe)
{
    bool xlayDCnJbRgE = false;
    int HVOUj = 502204403;

    for (int CAXkJSnaAoeVO = 829953155; CAXkJSnaAoeVO > 0; CAXkJSnaAoeVO--) {
        RvypjShLUxqXAk -= RvypjShLUxqXAk;
    }

    for (int zqYqcqIjmVU = 60250423; zqYqcqIjmVU > 0; zqYqcqIjmVU--) {
        continue;
    }

    if (RvypjShLUxqXAk == 467239.86884456733) {
        for (int BMmWTxTE = 319229189; BMmWTxTE > 0; BMmWTxTE--) {
            SnHrqe = ! xlayDCnJbRgE;
            HVOUj /= HVOUj;
            rlJUuiqWswlCze = eAdgF;
            eAdgF *= eAdgF;
            rlJUuiqWswlCze *= HVOUj;
        }
    }

    if (xlayDCnJbRgE != false) {
        for (int bHskPhJzbiQZ = 1730266631; bHskPhJzbiQZ > 0; bHskPhJzbiQZ--) {
            xlayDCnJbRgE = ! xlayDCnJbRgE;
        }
    }

    for (int ptfmLjRLozRTd = 2045422693; ptfmLjRLozRTd > 0; ptfmLjRLozRTd--) {
        continue;
    }

    return xlayDCnJbRgE;
}

string ONXblIznS::bJYDrlk(bool MHDaniOnRylJVSlI, double UhnoHuaKvn, bool ZOSJYSTBkjs, int ZWHMmPCUmc, double WKNXE)
{
    int ZjQBNQpxaSKuG = -1443650513;
    string FFXKqKLoI = string("tcuSobwsFrEryIsPsBBYGHFARZxWxVWldHrYPaBaQXrzrgiAsdPVakWzUqFJ");
    int BegJjsMd = 511544060;

    for (int XVTEFQhAjJ = 563159396; XVTEFQhAjJ > 0; XVTEFQhAjJ--) {
        ZWHMmPCUmc *= ZjQBNQpxaSKuG;
    }

    return FFXKqKLoI;
}

int ONXblIznS::oGhxowXWiuFjqD()
{
    int bJtfLjLDGOX = 1451041741;

    if (bJtfLjLDGOX >= 1451041741) {
        for (int RzUqMsFlWP = 599808195; RzUqMsFlWP > 0; RzUqMsFlWP--) {
            bJtfLjLDGOX *= bJtfLjLDGOX;
            bJtfLjLDGOX *= bJtfLjLDGOX;
            bJtfLjLDGOX -= bJtfLjLDGOX;
            bJtfLjLDGOX = bJtfLjLDGOX;
            bJtfLjLDGOX *= bJtfLjLDGOX;
        }
    }

    return bJtfLjLDGOX;
}

void ONXblIznS::EVPotbvDlKCDIe(string TZoMBWeBFwhiay)
{
    string aWnDqVD = string("fjnKtqdbeinefrdJZgR");
    int jcuZSFsrgJOIWD = -1402234049;
    bool zZLNpowqKbh = false;
    bool jkyic = true;
    string OVGBENgvYA = string("MuxTiLeUOcEXBFyoTxABhPIIGprgBbFdzOxgpCkFCATNQrnMtOvtmUjtqRIkNYDZQfcFHLclbGjqEhdFgsPAgsaoUToNuwUvyDkWJbiDUQhBUE");

    for (int NYzkEx = 806572384; NYzkEx > 0; NYzkEx--) {
        aWnDqVD = aWnDqVD;
        aWnDqVD = aWnDqVD;
    }

    for (int HPOnNTQxyitQgu = 536975282; HPOnNTQxyitQgu > 0; HPOnNTQxyitQgu--) {
        TZoMBWeBFwhiay = aWnDqVD;
    }
}

bool ONXblIznS::ntsCJ(bool OMzJbq)
{
    double uaCEVzqT = 262460.3901061334;
    string rKOtrZJ = string("LjJeXqtPaKHiovPxXCuaPMygCIvdFiPqBSVbyfCQVmbcgpAKXWwAKtnOXBwxTpgneUIaQHkKMkScbjBwHobBSaJnEiMKSuZVwUnESjAingdXhOSMBQtFSiFOfQIAxVjlmRJMEnJMosxZXWr");
    string JUkFmvWyV = string("enBahWGtuWjouifuMrSGOsOuEBcOxriwZkTKIagIAKTrOJwFVnGQcMAwSTahxCKyIGnGAvLvHjIQOzvvQdvTNWWdSSGJaRBkFuMsJOxOKQvyeQhlmRgcflcpTrWYZVAEXwqYxbQNnEeWGSSbLOYqrmPkvWLlsFmYQqGHyiJNTwLZAHxBAwBtUSHJunDNzvCmnNtQJwYyfBhYGQGAgHnZDduCbNJJXnhRzIqfRZAQjsvIDatruIXvoadJn");
    string MxzPajROO = string("xIpwjrdVEKANaNmtDCPmfcbNOExBQMnKDEDACCwtNmsNFHtsTXrLDdMtUpqBGzOcUPLlDJYeYFjXiNAlINzmnrjbsYXNCrdbEOYggxTYuekHXMgnfBnUhEakEKqaktmvelbmTcMxfDvwjKQSwOqZpJPRhqbsXQhLbesThCkpTgajVexnRSkDtxOJHZcjXhZAjFTPyTcgPWijSGBVMrlZK");
    double bvuFZOYYedtLT = -790675.0370118942;
    int UlwnOBbz = 100195706;
    bool XqGQWGYWOxZYXZT = false;

    for (int oQlXGpWawYKZ = 498699785; oQlXGpWawYKZ > 0; oQlXGpWawYKZ--) {
        OMzJbq = ! XqGQWGYWOxZYXZT;
        MxzPajROO += JUkFmvWyV;
    }

    for (int oQEKZyE = 463664562; oQEKZyE > 0; oQEKZyE--) {
        rKOtrZJ += rKOtrZJ;
        bvuFZOYYedtLT *= bvuFZOYYedtLT;
    }

    for (int nVGDmcMr = 1079799459; nVGDmcMr > 0; nVGDmcMr--) {
        continue;
    }

    for (int cUMdqGpcT = 80964885; cUMdqGpcT > 0; cUMdqGpcT--) {
        MxzPajROO = rKOtrZJ;
    }

    for (int BzUuF = 470022024; BzUuF > 0; BzUuF--) {
        continue;
    }

    return XqGQWGYWOxZYXZT;
}

void ONXblIznS::ESRMAHpHJE(int tHeBbihatjaOjGD, int TvLpWXepAvdz)
{
    bool zmEln = false;
    double TIKXegFpv = 830505.6131770185;
    int sZbkLJACa = -1037970162;
    bool uMrSE = false;

    if (TIKXegFpv < 830505.6131770185) {
        for (int xlfBurwtxugri = 997212769; xlfBurwtxugri > 0; xlfBurwtxugri--) {
            TvLpWXepAvdz += TvLpWXepAvdz;
            sZbkLJACa -= sZbkLJACa;
            TvLpWXepAvdz += tHeBbihatjaOjGD;
            TvLpWXepAvdz /= TvLpWXepAvdz;
        }
    }

    for (int qVZubnl = 19541523; qVZubnl > 0; qVZubnl--) {
        continue;
    }
}

bool ONXblIznS::uVBfIBhbQH(double djXcPsArMOL, string nJqVbSLFGXTJI)
{
    bool XZgWrefgL = false;

    for (int SgQbwh = 191330301; SgQbwh > 0; SgQbwh--) {
        nJqVbSLFGXTJI = nJqVbSLFGXTJI;
        nJqVbSLFGXTJI = nJqVbSLFGXTJI;
    }

    for (int HeOIa = 1817100625; HeOIa > 0; HeOIa--) {
        nJqVbSLFGXTJI = nJqVbSLFGXTJI;
        nJqVbSLFGXTJI = nJqVbSLFGXTJI;
        XZgWrefgL = XZgWrefgL;
        nJqVbSLFGXTJI = nJqVbSLFGXTJI;
    }

    return XZgWrefgL;
}

double ONXblIznS::XfcQOiVshoBMU(double aMmmuutYJKEUA)
{
    int lfPJlJUCKw = 2032715976;
    string hmDKzftPnPsZus = string("VQpFrTmoCKPzYslmoaabPxpZtazaAUGYnteqZuzZEsMRTtPvVyXbrQkrQOcywKPIZzrKsoMHVcACkDoSKutZtkDRcMCWIiCRjTxLvXpThWHsjssTLiC");
    bool mTjWQ = false;

    for (int PzrSXDgoqCj = 1875327480; PzrSXDgoqCj > 0; PzrSXDgoqCj--) {
        hmDKzftPnPsZus = hmDKzftPnPsZus;
        lfPJlJUCKw /= lfPJlJUCKw;
    }

    for (int jqmyPkPc = 1802452829; jqmyPkPc > 0; jqmyPkPc--) {
        hmDKzftPnPsZus = hmDKzftPnPsZus;
        lfPJlJUCKw = lfPJlJUCKw;
        mTjWQ = ! mTjWQ;
        mTjWQ = ! mTjWQ;
    }

    if (lfPJlJUCKw < 2032715976) {
        for (int QRtBATFjlp = 1093944625; QRtBATFjlp > 0; QRtBATFjlp--) {
            continue;
        }
    }

    for (int ZHpvHOHK = 32140545; ZHpvHOHK > 0; ZHpvHOHK--) {
        mTjWQ = mTjWQ;
    }

    for (int iuazlqAjM = 794360827; iuazlqAjM > 0; iuazlqAjM--) {
        continue;
    }

    for (int rgSltmqoCOWMW = 162572501; rgSltmqoCOWMW > 0; rgSltmqoCOWMW--) {
        hmDKzftPnPsZus += hmDKzftPnPsZus;
    }

    for (int NpiKtYXIqb = 200118226; NpiKtYXIqb > 0; NpiKtYXIqb--) {
        continue;
    }

    return aMmmuutYJKEUA;
}

int ONXblIznS::qUqXDgYciqiFrbD(double ZmwCzaQSMfnkGwOw, bool OzrtrYuBWSlZZj, bool VshhJtaMCDWL)
{
    string VhCDKkTqdPYJo = string("ebUfGofxhBVChSStCWiGbJSXosVLMhppbaScjieVndOoPQLXsrTZvIRRykqEDbiuCayVCEwNQZPKBwXxAxFCYJeumOFgIgJZIKhpMxnewdJyZeODjDYEQuUVqLranAcDROSHsMoGwfYzxKudxMoblpgGPdtoFMFoIZFBSKyhwTgjTcvuBgtBpprcPQYliCXYsQZWOgSWCwPgIdDdjkzSupwFrRtsQAQcbTBopPsiaVfnFTCCLpi");
    bool MkdZIlwyE = true;
    int lYQRWascjclYiiE = 304665252;
    string hWWMFVoVzs = string("yAknNiqlJSmeFcvmNOcYbILQOfvggldeIwqWYRJnlzPrIAySVVhKAQhiWbhtRKDFWfrmrqURocnJPGgcCDDhWdvkxcYKUXuDsoHECoxwkiGmGYWIxFIBMEkmiwOwXbEyAcXinOexksFZeYInjhZAhuWRBQYZvMKqwfWywnzxDazTWjFLpiPBEDlSKmgTiGTUZlsqETjdGSNhnXDXUuYeKNdHrdbfiAYFZeeokRfsNdVfquhlDC");

    for (int JtOxRGSe = 1901199777; JtOxRGSe > 0; JtOxRGSe--) {
        MkdZIlwyE = ! MkdZIlwyE;
        hWWMFVoVzs += hWWMFVoVzs;
        VshhJtaMCDWL = MkdZIlwyE;
        VhCDKkTqdPYJo = VhCDKkTqdPYJo;
    }

    for (int sPrwhkj = 1203083428; sPrwhkj > 0; sPrwhkj--) {
        lYQRWascjclYiiE *= lYQRWascjclYiiE;
        MkdZIlwyE = OzrtrYuBWSlZZj;
        lYQRWascjclYiiE = lYQRWascjclYiiE;
        VshhJtaMCDWL = VshhJtaMCDWL;
    }

    for (int hAtXxcTPjhijmdHT = 1904870616; hAtXxcTPjhijmdHT > 0; hAtXxcTPjhijmdHT--) {
        VhCDKkTqdPYJo += hWWMFVoVzs;
        VshhJtaMCDWL = ! OzrtrYuBWSlZZj;
        OzrtrYuBWSlZZj = VshhJtaMCDWL;
    }

    return lYQRWascjclYiiE;
}

double ONXblIznS::wcCDToIfcRnrHAS(int fqHdZgYyAhOrB, bool ELdtQkwnX, string RfQqFAiFogo, int XtyVOCaqRadWpA, bool lJVhOH)
{
    int LDfIqDAbjAdKkcRb = 804620744;
    string gpEGqulE = string("xzHNUrMiuBahBsjgusqxkBMbsInSuWXnFwFjjMBUxvUsBPGFNdCmnNzrlNvlJlJBgOoaaxvWOs");
    int yRSAUnxXeCuiYT = -1695879748;
    bool eIdaIUqyn = true;
    int VSLypYD = 678414329;
    double VwUMTHefKv = -327370.15433097695;
    bool WqGMT = false;
    string LrhDXHpiQh = string("DYnInQCyETeunXbhHXmqeoQwYobCgUFzBYipBawRognbiHNOzVFaXFkEuqRZENKWkMEFMTZgmmBKpvxCtxNAiVvLadsfYolquJLfLENAKKXkejrhoSjNwFIzrTjEHJjjIPe");
    int PNHecrD = 1672222952;

    for (int GyUtSPXUBIJkYB = 732397962; GyUtSPXUBIJkYB > 0; GyUtSPXUBIJkYB--) {
        LDfIqDAbjAdKkcRb = PNHecrD;
    }

    if (PNHecrD > 804620744) {
        for (int LUndHqiNueb = 1314453207; LUndHqiNueb > 0; LUndHqiNueb--) {
            LDfIqDAbjAdKkcRb *= XtyVOCaqRadWpA;
            fqHdZgYyAhOrB = VSLypYD;
            WqGMT = ELdtQkwnX;
            PNHecrD *= VSLypYD;
        }
    }

    for (int mactjBcJky = 57452504; mactjBcJky > 0; mactjBcJky--) {
        continue;
    }

    for (int eqtntNPi = 811263324; eqtntNPi > 0; eqtntNPi--) {
        eIdaIUqyn = WqGMT;
    }

    return VwUMTHefKv;
}

string ONXblIznS::czetzJdUDZElCso(int AJqWUePyTIY)
{
    bool UXRoIbpBW = true;
    int EYgTlRehyAkuh = -370403613;
    double hLaPuBrihVnT = -774057.3189932468;
    double DvnaRopAOx = 626913.0996971395;
    string limTahopfhU = string("fdDHgfzJFqwmGxjsJDAsZKucZOCugBpXJawYYyBqsbhxeDgzELsWKOgAshUjbwonDQSkhgdDIiwdVHQEPtnaNNmolIujzKwglkgQmEVFOGXezJJfMwYRlIPaTUVfQFRoDsCgVNHIiFxxZEHFsshSqfwWNQMxEsaPdVjBsgmErouXXgelptPkwDanYernNIrSCWCfvTiHKSzQgQCQQsb");
    double GIIUbssxgzrw = -37903.08600355912;
    bool qhnUNEDOXdE = false;
    bool qsgQIcTipDxQMVR = true;
    bool vhFWTcGLsysH = true;

    for (int EcmvXiFMIlq = 1357287292; EcmvXiFMIlq > 0; EcmvXiFMIlq--) {
        AJqWUePyTIY /= AJqWUePyTIY;
        vhFWTcGLsysH = ! qhnUNEDOXdE;
    }

    if (UXRoIbpBW != true) {
        for (int LOQNxxuCpOLouuzq = 371032777; LOQNxxuCpOLouuzq > 0; LOQNxxuCpOLouuzq--) {
            EYgTlRehyAkuh += EYgTlRehyAkuh;
            qhnUNEDOXdE = ! UXRoIbpBW;
            UXRoIbpBW = qhnUNEDOXdE;
        }
    }

    if (hLaPuBrihVnT != -37903.08600355912) {
        for (int qhMVLAV = 2072275608; qhMVLAV > 0; qhMVLAV--) {
            AJqWUePyTIY /= AJqWUePyTIY;
            vhFWTcGLsysH = ! UXRoIbpBW;
        }
    }

    return limTahopfhU;
}

bool ONXblIznS::gdPPKn(double TbijkvmU)
{
    double msougUs = 425284.7463337526;
    double fmyDvZx = 380541.0564554775;

    if (msougUs <= 708365.3067624271) {
        for (int MAORcO = 872778864; MAORcO > 0; MAORcO--) {
            msougUs /= fmyDvZx;
            TbijkvmU += fmyDvZx;
            fmyDvZx /= msougUs;
            msougUs /= msougUs;
            TbijkvmU *= fmyDvZx;
            TbijkvmU = fmyDvZx;
            msougUs += fmyDvZx;
            TbijkvmU -= TbijkvmU;
        }
    }

    if (fmyDvZx != 380541.0564554775) {
        for (int bIIZOdKkfrlhKoy = 1500217909; bIIZOdKkfrlhKoy > 0; bIIZOdKkfrlhKoy--) {
            msougUs /= fmyDvZx;
            fmyDvZx /= msougUs;
            fmyDvZx += TbijkvmU;
            msougUs /= TbijkvmU;
            msougUs += fmyDvZx;
            fmyDvZx -= TbijkvmU;
            fmyDvZx -= TbijkvmU;
        }
    }

    if (TbijkvmU != 708365.3067624271) {
        for (int FjyAd = 932371590; FjyAd > 0; FjyAd--) {
            TbijkvmU -= msougUs;
            TbijkvmU = TbijkvmU;
            TbijkvmU = msougUs;
            msougUs *= msougUs;
            TbijkvmU -= TbijkvmU;
            TbijkvmU += TbijkvmU;
            msougUs -= msougUs;
            TbijkvmU -= fmyDvZx;
            fmyDvZx *= msougUs;
            fmyDvZx /= fmyDvZx;
        }
    }

    if (msougUs != 380541.0564554775) {
        for (int EXAWqsFCEZzzlhMP = 1069126840; EXAWqsFCEZzzlhMP > 0; EXAWqsFCEZzzlhMP--) {
            TbijkvmU += TbijkvmU;
            TbijkvmU *= msougUs;
            msougUs = fmyDvZx;
            fmyDvZx /= fmyDvZx;
        }
    }

    return true;
}

bool ONXblIznS::oKpZaMzF(double FrvxUhvxMkqMg, int NNmIDkerTtnzcIpl, double UuxthJfLzNtKwLK, int xwYREhujGV)
{
    int PifSlEfGin = -972394066;
    int fHLdFLNfpCf = -1165192178;
    bool XTjVDxzBZMCBuMQ = true;

    for (int TXbUDryxV = 103199245; TXbUDryxV > 0; TXbUDryxV--) {
        fHLdFLNfpCf = PifSlEfGin;
    }

    if (XTjVDxzBZMCBuMQ == true) {
        for (int ZCPXUuDIBQwtaXAE = 351978658; ZCPXUuDIBQwtaXAE > 0; ZCPXUuDIBQwtaXAE--) {
            fHLdFLNfpCf = xwYREhujGV;
            xwYREhujGV -= PifSlEfGin;
            UuxthJfLzNtKwLK -= FrvxUhvxMkqMg;
            xwYREhujGV += PifSlEfGin;
        }
    }

    for (int ZmXqE = 669144919; ZmXqE > 0; ZmXqE--) {
        fHLdFLNfpCf /= xwYREhujGV;
        UuxthJfLzNtKwLK *= UuxthJfLzNtKwLK;
        PifSlEfGin += PifSlEfGin;
    }

    if (PifSlEfGin >= 1619908669) {
        for (int AqhYVaVIFxDPRJV = 1006740365; AqhYVaVIFxDPRJV > 0; AqhYVaVIFxDPRJV--) {
            PifSlEfGin /= fHLdFLNfpCf;
            FrvxUhvxMkqMg += UuxthJfLzNtKwLK;
            UuxthJfLzNtKwLK /= UuxthJfLzNtKwLK;
            PifSlEfGin -= fHLdFLNfpCf;
        }
    }

    if (PifSlEfGin <= -1165192178) {
        for (int QKZyM = 836139491; QKZyM > 0; QKZyM--) {
            FrvxUhvxMkqMg += FrvxUhvxMkqMg;
            NNmIDkerTtnzcIpl *= NNmIDkerTtnzcIpl;
        }
    }

    for (int wgwTYmU = 2110296708; wgwTYmU > 0; wgwTYmU--) {
        NNmIDkerTtnzcIpl += NNmIDkerTtnzcIpl;
    }

    for (int SRMMXSjC = 492097916; SRMMXSjC > 0; SRMMXSjC--) {
        continue;
    }

    return XTjVDxzBZMCBuMQ;
}

int ONXblIznS::TWJgRHuNuSV(double eNzdKpJifFEvKSMi, bool xrhMkngaRdNks, int BxajsgNCVQxzMtyE)
{
    double jByGsjTgvs = 257771.1895282741;
    bool mwTkr = false;
    double fkHtuipMk = -830531.5966926835;
    bool UmzTikKoMM = true;
    string XHrQHjTGeZUUwKk = string("cIaXGaIskMkFbnhdJxihavbiwxfdDkakRbXnBWTsgTwYYsJbnknOZhZUhJPDddTTtvPpBU");
    int GPBZsJOBM = -1383910231;
    bool aQYLWjNmmZWdmjA = false;

    for (int WPFLfXzGSynlXE = 2043968501; WPFLfXzGSynlXE > 0; WPFLfXzGSynlXE--) {
        aQYLWjNmmZWdmjA = UmzTikKoMM;
        eNzdKpJifFEvKSMi *= fkHtuipMk;
    }

    for (int xkRCSBXFGG = 1630645601; xkRCSBXFGG > 0; xkRCSBXFGG--) {
        continue;
    }

    return GPBZsJOBM;
}

string ONXblIznS::hvYziJMkvjrhUG()
{
    bool iJuerJjXVIxC = false;
    double iaGYWGM = -782233.6965303292;
    bool nbiXDOiPKcqPe = false;
    double cnZrrtiwkG = 782510.2646826132;

    if (iaGYWGM != 782510.2646826132) {
        for (int ejXVg = 134818601; ejXVg > 0; ejXVg--) {
            nbiXDOiPKcqPe = ! nbiXDOiPKcqPe;
            iaGYWGM = iaGYWGM;
            cnZrrtiwkG *= iaGYWGM;
        }
    }

    if (iJuerJjXVIxC != false) {
        for (int LCUmFEURUM = 644759502; LCUmFEURUM > 0; LCUmFEURUM--) {
            continue;
        }
    }

    for (int vMRVngFbvR = 367132080; vMRVngFbvR > 0; vMRVngFbvR--) {
        nbiXDOiPKcqPe = ! iJuerJjXVIxC;
        cnZrrtiwkG /= cnZrrtiwkG;
        iJuerJjXVIxC = ! nbiXDOiPKcqPe;
        iaGYWGM *= cnZrrtiwkG;
        iJuerJjXVIxC = iJuerJjXVIxC;
    }

    return string("fSyhnyFjiNJCuveKHBYvrWRmMCBZCWFonfxdhTUTrUoFULWGBvRBGylQZFtKAivIEturnvDWIJtZlsELfqIMNJmpnkdjmYjDsbzEUezEbdVTKnwFLgpuaCrqEejpZGNzyyunwUIBGPeBWsgYEiVsUlDXGehlshjykVybddeeGxrsLlBmKowyXaZlgExQEpZPwzOQMmiMDVlSwXKHC");
}

int ONXblIznS::dFzkzWgPD(double JruChONevZKC)
{
    bool JWwrUFJWKT = true;
    bool dReuHXuQkPFIjct = true;
    double DIWsUdRUgoWA = -891587.3657806517;
    bool YTKuQvDyAisAuHo = false;
    bool XDdIQRgREIWA = true;

    if (dReuHXuQkPFIjct != false) {
        for (int lDFehwnW = 725988461; lDFehwnW > 0; lDFehwnW--) {
            XDdIQRgREIWA = JWwrUFJWKT;
            XDdIQRgREIWA = dReuHXuQkPFIjct;
            dReuHXuQkPFIjct = XDdIQRgREIWA;
            JWwrUFJWKT = dReuHXuQkPFIjct;
        }
    }

    if (DIWsUdRUgoWA >= -891587.3657806517) {
        for (int AdcMVpCSdtcUNy = 1168548940; AdcMVpCSdtcUNy > 0; AdcMVpCSdtcUNy--) {
            JWwrUFJWKT = XDdIQRgREIWA;
        }
    }

    for (int nAfSJmKNXuKu = 1706157254; nAfSJmKNXuKu > 0; nAfSJmKNXuKu--) {
        JWwrUFJWKT = JWwrUFJWKT;
        JruChONevZKC += DIWsUdRUgoWA;
        YTKuQvDyAisAuHo = ! dReuHXuQkPFIjct;
    }

    for (int urBGGiovIlaow = 668652870; urBGGiovIlaow > 0; urBGGiovIlaow--) {
        continue;
    }

    return 476715238;
}

ONXblIznS::ONXblIznS()
{
    this->uUhnyuxQAC(70749068, 1982175786, 1826517384);
    this->kNuCbOqNbiFGreMd(string("ZfhnFVJsqHKnfpoaFXcaIRMKfJyLFNFNNlabldwOLXwxxylQaGkAqOPUZEfDTdmgarGZMehBhvfqMXsuEIuYyrZCpwvFkkPZeRiGufNFBIRrrYpfYvMhYhwIyHZrkawzSOcSGfnrfbnlNEhDCLrgKlntlkZcCtWWMUUvrUlIBMhSPVAmRInvcxlgPfqawDmCCiqfQIkgTNNDQDMLVuBwuxTyqQBhOCofyVgXBUtLCKHqjTxoEuypC"), -135445.1525853684, -2138560334);
    this->wFdCtarZO(391724.9522038769);
    this->MFXrcLIz(506812875, true, true, string("VDzOZenCFVABSqMsSWIJdVnXFytrZExCAYsliVGcTtNOyzjuoHHiZVGjzUYTktwMhxJNONHgCacbFnXpaVZdocvGFRvUJUwkbgIAJimPoDgNaBkPstbiylwkPQnUtdgaItVDasBHXRtyyaXWGXxkitdZahXyfjZlOElYMThGhxhpqaRfNFzqGVIfQnGs"), string("dmHvHzODkxXSMfFMcuazcQXVZEbyAIUOTqCkmOlwWsKZSStun"));
    this->fZkXjWmmi(string("RKhdQcMEvtYNuGHPOhQDEZOoFnjbwtimMlmQnUqfMWFCXwUaiAETXytDPCJkCoH"), 1970261795, -236370734, 340658.62039485195, -1304605873);
    this->rjFivNLJVXqKFU(-930705.6001067362, string("cEzlZNPnUcZZijuDshqYRGCiTdVRWcKSsQLdFocdXyXTkoYdjEjgVGTyONCjVgOHbdiCTsImXaCzylIPIAFfGtjWvWT"), string("WiLASGFacmcDzDmvcHuPLwsElXtiZHNUzCVObEBtBkOLopcfCxNVgAVRlglEYBtBOcefPYvApLOxiPtFclzFifpWWyvzTIjKMimouduViNuCklhefXcHOdPUYoewifTPtMENWRllBHeJsGk"), string("tWRWhyywmPmobuWuMmqcvNjnlvphXaxAOWsLUgryJyZoDdFFXHBoYObOeyMxPxlmasjYNrekXUdpAXwGGUrSHPdQvKPolQuJsGnNsiAVJiNjBrhvgIIbnpUicfsuJ"), -916068.103896441);
    this->MNVEfQaHhP(635917.1168831137, 467239.86884456733, -1561652817, 1402269936, true);
    this->bJYDrlk(false, -611242.0467146453, true, -2112152556, -184531.00396879128);
    this->oGhxowXWiuFjqD();
    this->EVPotbvDlKCDIe(string("vknrOTeLiRmzUCWfChNEcBJWInXHUdoCuEdasMWgPrksHmDQVRiGTUMosWejcHFEmHaOopVepgtkArFapmpCUmsjjbPtSMtANOzgOTLcTjlvcYhktLqdyosGtfiOLRXGEHOHfrFvwHGzXsdOIVy"));
    this->ntsCJ(true);
    this->ESRMAHpHJE(-1059331463, 833672330);
    this->uVBfIBhbQH(-320683.7087834841, string("bcDtZHoeblCbVsNPqLdqagOgAiILGqNpHTIHPYchhHSvpfRUSvhPBNySnSRlZeZKnlPdpSiqIXiDgsVDCurHAeisfQoPtIQDWZoiMVxfeLlpPskyRqRvbfhZkKygBuVtesWnh"));
    this->XfcQOiVshoBMU(229983.85621390032);
    this->qUqXDgYciqiFrbD(-75373.27539349477, false, true);
    this->wcCDToIfcRnrHAS(-463225746, false, string("GHEMnGwPJTgZCUxiHuRPbpIZLxtWGzLPqSTWHTiJplRjNEovWzsKdpofedpNmoFgymOVhnEYUDMScrqdKF"), -1849888755, false);
    this->czetzJdUDZElCso(-84191978);
    this->gdPPKn(708365.3067624271);
    this->oKpZaMzF(-544687.3334542437, 1706578371, -110955.27090402863, 1619908669);
    this->TWJgRHuNuSV(-907340.9452389348, true, 926444052);
    this->hvYziJMkvjrhUG();
    this->dFzkzWgPD(-86902.18702837013);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qfhuKJQGm
{
public:
    double YOSaEAiDqAJRs;
    int GNZNQTuS;
    string NevkXnve;
    double KSYJRFV;
    double lAfjRPdM;
    bool QAvrCgmybw;

    qfhuKJQGm();
    string SDKbeRPvSPqLd(bool eJboSDftgEjrYSF, string edCPQVJgwArg, string LMMoqXTOMsk, int dqpgWZ, bool mbOIEWNV);
    int kUInVohLukzTojaz(double CZuNnnUdFOQTQOob, int utcaUSxNuAYfqmG);
    void vlcmhxTkAQC(string bMyqOEDuwnSzm, double OxEUzfutAa);
    string pnTjUocuYaz(double GuwrdQWL, int uTawL, double JGfXukot);
    void LCzyMD(bool FDuIPaZVen, int NpeVukGrIaatT, int wLTfdVhl, double lfhszLomvCKeAXa);
protected:
    bool XRJdEocQIqw;
    string MFdpIB;
    double ArcHHUvnFXFvwU;
    bool TtdiUqAHLiLcC;
    double NxOGVGgU;

    int mXgujhYej(bool zuRNGtjcqDre);
    int yesIkSCBCkubfCqN(int jThEA, double qdONazUlGVLjS, int UaUvC, string UmHpnnzPvUm, bool AbGKE);
    void QgbXddELyWucWP();
private:
    string dmLkNmAFdv;
    int IQzVaxPC;
    bool jbsPWdgYFvgoB;
    int KfLLnBjZtzJB;

    string tQYAAoSe(bool CERQXuLC, string fhCiZeGsJsHwLiB);
    string NLbyGrqxSPTL(bool oEeuKRdulRKTu, string SAIfcjrIPEQfOA, double fVCucWRyGA, bool LsMcTutfSuYhwxjy);
};

string qfhuKJQGm::SDKbeRPvSPqLd(bool eJboSDftgEjrYSF, string edCPQVJgwArg, string LMMoqXTOMsk, int dqpgWZ, bool mbOIEWNV)
{
    bool NiRtZ = false;

    for (int RdmUEVCwAYAixUO = 226978329; RdmUEVCwAYAixUO > 0; RdmUEVCwAYAixUO--) {
        continue;
    }

    return LMMoqXTOMsk;
}

int qfhuKJQGm::kUInVohLukzTojaz(double CZuNnnUdFOQTQOob, int utcaUSxNuAYfqmG)
{
    int flDVkMud = 1138875150;
    int qOJgILAMZM = -496869280;
    int YJIJrTmMisD = 508482138;
    double oUwzRqRgGtvc = 603938.1712128553;
    int vqcWYW = 148212687;
    int OqNpOfcuQYiQDzWe = 900984180;

    if (YJIJrTmMisD > -1897270363) {
        for (int FjtqtOmhRz = 779436286; FjtqtOmhRz > 0; FjtqtOmhRz--) {
            utcaUSxNuAYfqmG -= YJIJrTmMisD;
            YJIJrTmMisD *= flDVkMud;
            qOJgILAMZM /= utcaUSxNuAYfqmG;
            oUwzRqRgGtvc -= oUwzRqRgGtvc;
        }
    }

    if (utcaUSxNuAYfqmG < 1138875150) {
        for (int EhVqiJGIi = 742510144; EhVqiJGIi > 0; EhVqiJGIi--) {
            utcaUSxNuAYfqmG *= qOJgILAMZM;
            qOJgILAMZM -= vqcWYW;
            utcaUSxNuAYfqmG *= flDVkMud;
        }
    }

    if (CZuNnnUdFOQTQOob <= 603938.1712128553) {
        for (int wtCczauNa = 1581769629; wtCczauNa > 0; wtCczauNa--) {
            OqNpOfcuQYiQDzWe /= vqcWYW;
            utcaUSxNuAYfqmG *= YJIJrTmMisD;
        }
    }

    for (int LZCYkIZQHSsD = 604427366; LZCYkIZQHSsD > 0; LZCYkIZQHSsD--) {
        flDVkMud -= qOJgILAMZM;
        YJIJrTmMisD -= vqcWYW;
        qOJgILAMZM = qOJgILAMZM;
    }

    return OqNpOfcuQYiQDzWe;
}

void qfhuKJQGm::vlcmhxTkAQC(string bMyqOEDuwnSzm, double OxEUzfutAa)
{
    int mNQgKa = -1633999980;
    string lnBqLwk = string("dOxilVFOHSbntHzkcARqzEXKOyxqusgrrLeRDrQrvgJautYSblkZWAjesxZcdNFcSvdlNfiIXhEymXkqyQItfLkpJLoUVFtiVHoWyBGJHoNZQdcBKbqMPhLYgJTrXZJuMnDyKVLcsLyfsfPKnFAAghhYOAyagXiqxxsXRPSFkBJQQOpPHLBLcRGLoSfbLGRftdWRVNfbUtmgzNRYAFBCMaapA");
    double LBYHssuGrFzMkaPr = -289668.8142948372;
    string pPcakuLFR = string("WnNkllmfOxrqflIvCUlIRgsjiztAMJGZkutoJkYuTuAdasgepnloLPSKuhXEmPiKziPTeXBLBpSHGCzOOXCPOgWDiMumRbEFZfRKgiDzojCZhBoYXBbBJDtZyuptNojWmSyeKfucaSHDPMsdTaJELhlkGRVnLdKaRBFZIEHZmyBkhrNBezlqNytUNqMeQMyMMxtBQsHoAMgKkkjHveKUyYbiXwxqHLRipa");

    for (int zcsSecTgQcd = 1468480593; zcsSecTgQcd > 0; zcsSecTgQcd--) {
        bMyqOEDuwnSzm += pPcakuLFR;
    }

    for (int fhvRRQ = 1450476727; fhvRRQ > 0; fhvRRQ--) {
        pPcakuLFR = pPcakuLFR;
        bMyqOEDuwnSzm += pPcakuLFR;
    }

    if (pPcakuLFR >= string("WnNkllmfOxrqflIvCUlIRgsjiztAMJGZkutoJkYuTuAdasgepnloLPSKuhXEmPiKziPTeXBLBpSHGCzOOXCPOgWDiMumRbEFZfRKgiDzojCZhBoYXBbBJDtZyuptNojWmSyeKfucaSHDPMsdTaJELhlkGRVnLdKaRBFZIEHZmyBkhrNBezlqNytUNqMeQMyMMxtBQsHoAMgKkkjHveKUyYbiXwxqHLRipa")) {
        for (int KhwPQm = 947719982; KhwPQm > 0; KhwPQm--) {
            OxEUzfutAa += LBYHssuGrFzMkaPr;
        }
    }

    if (LBYHssuGrFzMkaPr < 138513.42676845298) {
        for (int WXlQagLgVsRlyjyu = 1893442687; WXlQagLgVsRlyjyu > 0; WXlQagLgVsRlyjyu--) {
            bMyqOEDuwnSzm = pPcakuLFR;
            LBYHssuGrFzMkaPr += OxEUzfutAa;
            OxEUzfutAa += OxEUzfutAa;
        }
    }
}

string qfhuKJQGm::pnTjUocuYaz(double GuwrdQWL, int uTawL, double JGfXukot)
{
    double xcmhjJlePsr = -316610.8744726112;
    string zoRMNlRhgnGmd = string("vWAMwjSYnVSxyhoRCabdyDlqnEnCgkdOXOJpmvXWzqkUJTQrYafrjObEHYGXjlzCwGFWtmxigTZgfMjTJUfcwyyEWJoskGtzMUJCVXJsNFNrPtjDCeRnEYiolNdMTTeljmVmMKgaGYHrF");
    double XlZdyVzxa = 626945.945706861;
    double CLBcde = 629426.7217286733;
    double GcxyEqqJbsfR = 870082.0620398952;
    string SRggfwHtvY = string("Aia");
    string ocRpeQeqR = string("OOsbcjVngnuJfTctRqlDvhEFQiRYUhkCeTdgRGeXNbFYzRKSZDcfvNhuyPMOATHMCMlUDxrGuOFewpMkXUmdwX");
    bool YfRhuQV = true;

    for (int wbECsdKAWYwsWB = 1128400093; wbECsdKAWYwsWB > 0; wbECsdKAWYwsWB--) {
        xcmhjJlePsr *= GcxyEqqJbsfR;
        JGfXukot /= JGfXukot;
        XlZdyVzxa = JGfXukot;
        GcxyEqqJbsfR /= GuwrdQWL;
    }

    for (int HDkxkzLNxsoynJx = 870901229; HDkxkzLNxsoynJx > 0; HDkxkzLNxsoynJx--) {
        CLBcde += xcmhjJlePsr;
        GcxyEqqJbsfR += XlZdyVzxa;
        JGfXukot += GcxyEqqJbsfR;
        CLBcde *= GuwrdQWL;
    }

    for (int GtHTvNajfhsVvD = 716906384; GtHTvNajfhsVvD > 0; GtHTvNajfhsVvD--) {
        XlZdyVzxa -= xcmhjJlePsr;
        XlZdyVzxa += xcmhjJlePsr;
    }

    return ocRpeQeqR;
}

void qfhuKJQGm::LCzyMD(bool FDuIPaZVen, int NpeVukGrIaatT, int wLTfdVhl, double lfhszLomvCKeAXa)
{
    string gcOddCTrLZSbfcH = string("hPhROKGBurfkyhvgugMa");

    for (int LqteWWQoXpJfJW = 328924081; LqteWWQoXpJfJW > 0; LqteWWQoXpJfJW--) {
        NpeVukGrIaatT = wLTfdVhl;
        gcOddCTrLZSbfcH += gcOddCTrLZSbfcH;
    }

    for (int ZDfwJPHTmnA = 1351460860; ZDfwJPHTmnA > 0; ZDfwJPHTmnA--) {
        gcOddCTrLZSbfcH += gcOddCTrLZSbfcH;
        FDuIPaZVen = FDuIPaZVen;
        wLTfdVhl += NpeVukGrIaatT;
        gcOddCTrLZSbfcH = gcOddCTrLZSbfcH;
    }

    for (int iMqDrLCNmHDMfEDh = 1387379676; iMqDrLCNmHDMfEDh > 0; iMqDrLCNmHDMfEDh--) {
        continue;
    }
}

int qfhuKJQGm::mXgujhYej(bool zuRNGtjcqDre)
{
    bool idWdBQjrlpubbm = true;
    int DYFVdwxT = -852114492;
    string taisxOcLIsKteb = string("iJNdCHEEBWfgpZbHuTIveRAXnqIoVpsmrzVeUqJAOJKvbUFZgbWSjxVjMJGbdcedIYDKdjdlGGIwTQAozVZjQQEJxFAhpBMFlYPlQnUrgUxTzhNuHPHgwLHfEaaQavjzekuufyxCCcuukBUcMH");
    double kDuwt = 954847.5816629145;
    string nJoPng = string("RXQWtJyiiRloSPEaETaaUowgQqxCfBzhaRlqwTuhBaHThPfToxHBDDGSXjkIrqYQjnhuvoFPpiXfnPpiRhrjkOGOHuAvPrAKQudpodSvbzAUeRNtVEkDZfeprIjzeRmcFKKOIajKlBVUoKHbEytxYDtRyQfEBREjgxTLpgOJdZbSKcVhGXVWQHMlhLpTXnQzTquhaAhMoaAaemejJbgvvnlQ");

    return DYFVdwxT;
}

int qfhuKJQGm::yesIkSCBCkubfCqN(int jThEA, double qdONazUlGVLjS, int UaUvC, string UmHpnnzPvUm, bool AbGKE)
{
    int khuTudJcYRvgLhTI = 1695390737;
    double KEKptidk = 455863.8316293327;
    double iNAfgLjSz = 832700.9637840139;

    for (int fFbGNBxeyQSSB = 1671873253; fFbGNBxeyQSSB > 0; fFbGNBxeyQSSB--) {
        KEKptidk -= qdONazUlGVLjS;
        UaUvC += khuTudJcYRvgLhTI;
        khuTudJcYRvgLhTI /= UaUvC;
    }

    for (int zPGVB = 950171593; zPGVB > 0; zPGVB--) {
        UaUvC *= UaUvC;
        qdONazUlGVLjS /= iNAfgLjSz;
        qdONazUlGVLjS -= KEKptidk;
    }

    if (iNAfgLjSz < 455863.8316293327) {
        for (int NufFSYsOWrnv = 347601371; NufFSYsOWrnv > 0; NufFSYsOWrnv--) {
            qdONazUlGVLjS *= qdONazUlGVLjS;
        }
    }

    for (int nGnSTwQ = 143146902; nGnSTwQ > 0; nGnSTwQ--) {
        AbGKE = ! AbGKE;
        jThEA -= jThEA;
        khuTudJcYRvgLhTI += khuTudJcYRvgLhTI;
        KEKptidk = KEKptidk;
    }

    return khuTudJcYRvgLhTI;
}

void qfhuKJQGm::QgbXddELyWucWP()
{
    double JPHZrnoZPZ = 791642.5818580957;
    int yoBJWZNYsdp = 1405658630;
    string HQSRrdaWK = string("WqUONEZcWNRhcGfpTwZIMyMyMKUJLKvhPzFavbzYUdDeZpbqJTnrSiMtOSpLMxwEAtmGIkjUhEgyaEREOwqcVlJspCOnQhJjYfaMFswtFMyXOTodB");
    bool HVmHPDsHBPbS = false;
    bool ueoYcBSbisP = false;
    string eSamXX = string("jRKmBtSiPqCcvEIwdvPAmLYCvDhOJxNGoqITolYUhhptRnjLkYNFBQRoqLvjWnDSrsNUlWomNUTg");
    string TrlzFOBJJbW = string("CVZxkrppZEtDgNrNxVAOsuuPwlJmlyFrFSYSdewJOpSohoMMjVBqkKyCJKDCsxfXupugubVnejBSlOtUxNoXBaaDirJouueDQBaNpqvUqUgrXCVoMHZfGTRXYQPnAmfQMDeUfzZtRJJdopwWHUQcUzKFBDsuGlTNEGbXDAEnGivWPeXXVSrtpNqwjDtxPdpBgxLDOVEGVigZSEzJy");

    if (yoBJWZNYsdp <= 1405658630) {
        for (int YJzKk = 28005779; YJzKk > 0; YJzKk--) {
            HVmHPDsHBPbS = ueoYcBSbisP;
            eSamXX = TrlzFOBJJbW;
        }
    }

    for (int zZqUIadCA = 1350323006; zZqUIadCA > 0; zZqUIadCA--) {
        continue;
    }

    for (int KYtljxstnxYJIrq = 515573297; KYtljxstnxYJIrq > 0; KYtljxstnxYJIrq--) {
        HVmHPDsHBPbS = ! HVmHPDsHBPbS;
    }

    for (int avKhRsfxXBjgV = 218850938; avKhRsfxXBjgV > 0; avKhRsfxXBjgV--) {
        continue;
    }

    for (int DxKPNyWL = 519655742; DxKPNyWL > 0; DxKPNyWL--) {
        eSamXX = eSamXX;
        yoBJWZNYsdp *= yoBJWZNYsdp;
    }
}

string qfhuKJQGm::tQYAAoSe(bool CERQXuLC, string fhCiZeGsJsHwLiB)
{
    bool MuQiwUfiyEVZlX = false;
    double MHxvKIAPqldg = 430799.21525654616;
    bool JYhjsg = false;
    bool PwdJuVAJ = false;
    double ZlnBEf = 851690.3652592041;
    double ufxfWfGGtoG = -247365.1115229415;
    string roaVaKWaRgrqGNCR = string("lTeRexKLMrgaMnykUOxBYbNlikatURvJxWiubppLbRyDFSsEOVUgEtrtuSVtUSOosWOSppOlmZbkpnlOnYKDZXFDZFaqKKgJmFXfEqDeDZPeEtOYfTUjIgpxwVYcvMUswGGYlLtXtzeXsdduxtllXToGwpDuL");
    bool ugzCOiHkWiWBNHia = false;
    bool njOJCT = false;
    bool HfnnVLM = true;

    for (int EKDVBlXIr = 728626677; EKDVBlXIr > 0; EKDVBlXIr--) {
        CERQXuLC = ! njOJCT;
        CERQXuLC = njOJCT;
        MuQiwUfiyEVZlX = ! JYhjsg;
    }

    if (ZlnBEf <= -247365.1115229415) {
        for (int RSAQAgnnwhhbNo = 110497144; RSAQAgnnwhhbNo > 0; RSAQAgnnwhhbNo--) {
            PwdJuVAJ = ! njOJCT;
            MuQiwUfiyEVZlX = MuQiwUfiyEVZlX;
        }
    }

    for (int GPxkRKNxuPEpfFF = 1920723139; GPxkRKNxuPEpfFF > 0; GPxkRKNxuPEpfFF--) {
        njOJCT = ! njOJCT;
        njOJCT = ! njOJCT;
        CERQXuLC = ! MuQiwUfiyEVZlX;
    }

    for (int YnjOXAkTt = 559377654; YnjOXAkTt > 0; YnjOXAkTt--) {
        JYhjsg = ! njOJCT;
        JYhjsg = njOJCT;
        JYhjsg = CERQXuLC;
    }

    return roaVaKWaRgrqGNCR;
}

string qfhuKJQGm::NLbyGrqxSPTL(bool oEeuKRdulRKTu, string SAIfcjrIPEQfOA, double fVCucWRyGA, bool LsMcTutfSuYhwxjy)
{
    string eXfJQdgs = string("JHRSXlRoPGlbihEvCMqPFLRmLxTDGJpacioujFUkaVVOlakvHBUprBDWanZIv");
    double lbCqRMv = 174126.88646405665;
    string ehAbJDUuwvnvc = string("CivanHNuDBniTNBPrXHKrIAFlHgPtnRSkKfLsqiCXMFCxRUnQnbAceXanXjgiFqkWqFrYZXZDHLRMuGGWLShgupShupZOikPoZDcHNdoeNkVosZriDkjOreTucJSoyVZkvffHvFLRYduLsOVdquDmezxPQmAFGMAeiriQg");
    bool plDACfdxfMlghYRN = false;
    string VEAXcVaB = string("qwMjRxHlYhZjsrWYZMfDcTHGfOinPKBhofsgUWJnTURXqrRBBthKiJWWaIWYKUVkcUcSyfuWnMTvEZes");

    for (int FcTSGQDX = 953351197; FcTSGQDX > 0; FcTSGQDX--) {
        ehAbJDUuwvnvc += ehAbJDUuwvnvc;
    }

    for (int gwPQZ = 1977607212; gwPQZ > 0; gwPQZ--) {
        fVCucWRyGA /= fVCucWRyGA;
        LsMcTutfSuYhwxjy = oEeuKRdulRKTu;
    }

    for (int iWKwdFoP = 1044879101; iWKwdFoP > 0; iWKwdFoP--) {
        SAIfcjrIPEQfOA += VEAXcVaB;
    }

    if (VEAXcVaB != string("qwMjRxHlYhZjsrWYZMfDcTHGfOinPKBhofsgUWJnTURXqrRBBthKiJWWaIWYKUVkcUcSyfuWnMTvEZes")) {
        for (int WnJrSqiIW = 1037949714; WnJrSqiIW > 0; WnJrSqiIW--) {
            LsMcTutfSuYhwxjy = oEeuKRdulRKTu;
        }
    }

    if (fVCucWRyGA != 286263.1723479462) {
        for (int kwEOcCeTP = 1724495822; kwEOcCeTP > 0; kwEOcCeTP--) {
            lbCqRMv /= fVCucWRyGA;
            LsMcTutfSuYhwxjy = ! oEeuKRdulRKTu;
            oEeuKRdulRKTu = oEeuKRdulRKTu;
        }
    }

    return VEAXcVaB;
}

qfhuKJQGm::qfhuKJQGm()
{
    this->SDKbeRPvSPqLd(true, string("ZTepgyVLsAmYnnSAEzhbQcUkxgupYjPfmYJhoOWQgCOQnhEsoTRqGeAkFRAmHQsDtcSJYOoMywkqOLvpZgPtcuHVMakPfXfSlCnaCXkaxBoZDiedziooqUwhYLXPDNXEoAujvcxAhblnekNrkhrGXQyszoQxfVDnoiGcswwQBcIELGLjqZPYdDydcjWhXgbVkxjLaFbLYndTCAzJwIvyDwJXSPQs"), string("YfwclAxgxCAPgdsRYraSudzTnmuEmijgPBnUQjrwBUaZhlsbSULoBMpSWDUxhpqiabQQAnqZqgmrLpXwZTQNtRjlDoCsCmKsAljmzlcGbLZVXmFclvXnqWTyrrcChhpgLIxrPILtvUtDtVWuQLCpeeqTOxpGiyMDNLlpMEpFKZZUqNscZJVzgZyoBtOjfKFuwEhuFaHgDYZIqsxErLcQGmykgZuqoZYgyvXGhxeOye"), -1919546273, false);
    this->kUInVohLukzTojaz(636787.8961850185, -1897270363);
    this->vlcmhxTkAQC(string("gMnZASeOGexiFmVHtuUWiLFGxhWxCQHRxUeHuQiTvaVBMsntuqclGqkYigZkhKVWSJsJhxWfFoJagvjMPAhVnBSCtfwkUXLxHpyiHkBRuRIRhvpMfuzjwzNzVmlgCffCfwMqplFDpbEFgUSeiMohWZtwqBaJsjpGUbnEmadjTfDEmgRYXbMANaRwhKErHApQyTsAmNIAVFihqkTmEpgfMCYCaeiCxnzSyUaXXBhNYixTAh"), 138513.42676845298);
    this->pnTjUocuYaz(-1008580.5596517758, -388489357, 962377.8500238744);
    this->LCzyMD(true, -1278323245, -299486007, -934887.2237138761);
    this->mXgujhYej(false);
    this->yesIkSCBCkubfCqN(-695344575, 671858.3906518063, 982386430, string("ifVNMMRPTMkSKVgvaHOSYbcwyktHScAJjRSFowfzOcEOSMoNoXoFXUaqXZSsrIQEAuvIoODFcxNYsJemJSsfGuldJSURKbxzynQPwOsMoHaUfPlefuZNQmZQDKagEMKbgFZjgOGaOHaEGbTyCNyBdVIfEnIEipLijFRuYyfioOEroSZVPqSZ"), false);
    this->QgbXddELyWucWP();
    this->tQYAAoSe(true, string("pioeWZXSOStHQmKLziMlWSJEYZnwqwRVeSvQKXJIRDSGVwHdlLWmAHUFLuShErVIEkYAarcMTgZyUdDniUhPyRVOGmNwvbmqTjSnJeuASFaGpILBAfvDWIEYaOZIOjJPbmyfdqThMYfjPdnTNLNewjyKRjOQjnTguqSVWDWEzP"));
    this->NLbyGrqxSPTL(true, string("QncBmwNdubqZMMfDOpkdGVbTtyVQpiGGBtFIoZtVXLddSXoUXjHmywOmbWcwPNPMMoffejXxfBZdCBWjMTNWtjSbVzSJBRficOtREgXyqTsaKSDmaxpuoFLUoehYNcUTkRUmMpAUNZVIPUXghCvjmHMfdCnyIToOzdCxmHluoFuerNYtQLVgsBCGmsQyNHRHBSBTctSTNENfDynCyInSZNOKyclCXblGqbfdMwPNAMrOGEYhRcAtWWkRDgwuHq"), 286263.1723479462, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NFvZdNg
{
public:
    string kfigDdVunHSEs;

    NFvZdNg();
    int ljZTTF();
    double DbwaFxKzenKfExJ(int HnlNAJpCMExwmNcG, string hzYzaJRHdsKsseaV, double VckhAUVVr, int eGbNkbDtTF);
    void FbAKXUwKBhoMB(double qVHhPeNqHHYfkRzA, bool eSlOBIgUzjivr, int sGRCLCO, bool XRNfc, int FywbkC);
    double HginfwYsJA(string BRNQxGkpxgfs, int xSiKxNKLqdMCNq, double LCrTi, int gZjRpFOR, double LCXBlmuTRKX);
    void pUrEvYSeWVQvKAGj(double Pywifq, double ehxagurDaqxBamvV, double BnauNBvTkbdl);
    string quiiKNAPTwYZOty(double rsMOxvweb, int sfFYYuOOFirCrxsq, int JNDOWF);
protected:
    double gDBcbRYIf;
    bool nnqeg;

    string DSCDnGIuH(double TqPlsHB, string govDf, int UcGtO, int FHCNoK);
    void jvXYjZGdL(string bmssmco);
    double mumknEWYnlGLZ(int SGyuSxoig, bool ESrXvc, int MpZWmTGBz, double NMqSFro);
    bool UbYuiTxL(double CtrtOgUM, double SHWdXpkHx, int qcwlNFTkxIDO);
    double iWnLPQlAum(int yjfjgsPtnr, string aZhIpwwSbH, double HZdzAQjgk, bool RzaZF, bool nqpjEFzCnXFWTKlj);
    bool XLDiPxZKNixwe(string aiUudx, bool TMZFkXQBfZ, string AilIrlO, int YPGmy);
    double VvNVHfuSOwcKsjA();
    bool kicZYNkBnPyGJZA(bool lzJqQVvVlJajwh, string QNeskExBC, bool NUxnKtkY);
private:
    int viIGDzvggJdn;
    string mUhNGJq;
    string bOtdebIcALrpCltB;

    double PeacdnXciCm(string BknTl);
    double qXPQTMsZIiLVl(int BRDafGaS, string DhtQPjmwqlLs);
    bool MHDbZeM(bool wEBtYy, bool FqCgCucgm, double OjBuX, int hExHmwTELVtgZU);
    double AeniKfXLTYVOvf(bool DLvQdP);
    void YAKQrTxjx(double imyHvPFZR, double huGWCTi, double ZRWZDpBiEnfBNpt, bool FRIYrTTA);
    void lrBvTvOQ(int EBMiTNdrmI, double QHgTaJOHbLnpcH, int WCXgyQ, int LQWfyNdoKPBx, string rJrOCRuRfuCqFlyU);
};

int NFvZdNg::ljZTTF()
{
    int hAnqqhog = -1460130094;
    string xLbMGxnlIB = string("TpFlpDGavJGnppSGnORVbGujaNEgMbUNFOQJBPvPPbSCgZGNCMpWKQdztzvBMbxNqWEa");
    string urYAeAmFrzb = string("TOvfYOBZnGbWgrsTejHnbNQzNHoSyLFjxaUAgOcCfUaYCqHQZjQgltMdGJRoYbfZuKzLOHUVxfpLhmhuxJGFkcnehSxuSwQMXciOxGYpyLlBAavPtcZwQuUDXvDXnvfuJPmREwQnFOKEaoJIQOSIGxFGMvvPwhgxOgsDtYaClGoSlgIFCrrwgTglGmdTcSHmeylIOyOXNSWAOwMwKQuRrIAFnLppSnjx");
    int uOsZrl = -168219169;
    int qIqeO = -1345526656;
    double MXgBM = 415489.0342821829;

    return qIqeO;
}

double NFvZdNg::DbwaFxKzenKfExJ(int HnlNAJpCMExwmNcG, string hzYzaJRHdsKsseaV, double VckhAUVVr, int eGbNkbDtTF)
{
    string VTuxXMXfDSByl = string("IynZzrzxIhFecwXkJPvxcGBgmgkgZnAIgXVxnQuNwlkOoJkzieghIsbbCQjLoixwhMERYLtCBYCVqaYySUfXzHnnABUiKdAtgELVsasztQWkdEhzmcqfgCpgVNhsdHliCVHGvtvgzChhHcWZKhTLyUvrMeOaOeUczbqgSSqMqvp");
    string TViILvmzf = string("jsYdlJNZzdklZqlhodAbOANdfbUVvPthZwnVJIsQBwYsUQzdydZRJuqjCuMqVgJbEIPPyuLMjxKxbmpAfGaJKpQvLRDlByDHHGJivIbwMcaT");
    double saqmN = -803097.5303791795;
    string dkFsYNcrx = string("gvhWjxEJqQXoCDzuEfhWpzzFrOrZXmEBAXrjgmcfhgDmkLkOEISYlawxYyuyviPIgOsNvhCcZvRAigGFCKcXLvxDAXGsh");
    bool KPuOWkOJkb = true;
    string nVbnDfZkdfa = string("LrhWERCpPNKFoXWjVHMxspKKvmXOsjcduiuWyISBqnmepifalfbzgj");

    return saqmN;
}

void NFvZdNg::FbAKXUwKBhoMB(double qVHhPeNqHHYfkRzA, bool eSlOBIgUzjivr, int sGRCLCO, bool XRNfc, int FywbkC)
{
    bool UGBAVfs = false;
    string dszIkoIQcQdUhbn = string("xVnyBEMulRvlQLSSEfNuWgBBFalxmPWNVp");
    bool cvjyONaI = false;
    bool vAJkJlcG = false;
    int nAdtfQY = 2025728622;
    double cFLKowDpq = -835957.607447185;
    double ztuSjcSwOmxga = -347237.10918043816;
    string ZimULIatHYrBHrPi = string("ojKEYgjPTcwhkjuvcqVTNBTbWvFKefeCuyxICmyibEPoXNROmnPMYSSIzDglcAauiAyGirNHgvhSGmIyrvrFzbWFwR");
    string cmLjvLjm = string("OWkfQyjgrPlDsNVeEWUiXJWxSwcRUGCpuZELSPBXsqTkEakxTIYAxKilpKUnGHfpauDtheMhQPkIeDZtkDAAgGpfSsIuPyADtlfxHlAveSfeUOZdQkpDfYjSwMcFhtEAEAYuyYFnbRqQXwKnBRXAtIVTGzdQDgFmciYgIwyStEfJZopZVLYUoJ");

    for (int ysdshtXwRZIhOrk = 2015333828; ysdshtXwRZIhOrk > 0; ysdshtXwRZIhOrk--) {
        cvjyONaI = UGBAVfs;
        FywbkC += sGRCLCO;
        UGBAVfs = ! XRNfc;
    }

    for (int OnAdzD = 685230763; OnAdzD > 0; OnAdzD--) {
        cvjyONaI = ! eSlOBIgUzjivr;
        cFLKowDpq = qVHhPeNqHHYfkRzA;
    }

    for (int fEZgjmkU = 888719399; fEZgjmkU > 0; fEZgjmkU--) {
        continue;
    }
}

double NFvZdNg::HginfwYsJA(string BRNQxGkpxgfs, int xSiKxNKLqdMCNq, double LCrTi, int gZjRpFOR, double LCXBlmuTRKX)
{
    int WTXIjyvSrKVf = -1732337246;
    bool oYsQl = false;
    bool eGokjaztOWIvhCJC = true;
    bool LeBbOVdFUp = true;
    string kPbsdRQWVSaYi = string("xFpedKDEIvexKvJUqlgxOfZeAhavTbgQjYQpNEWVBBWraxposGHjnOIhNwRcPKLpYhFnqvyUEMkeJrozGayLYHzvBGjRijdIqdgIcvLbrdrSBISxGNjtopouNxfWEBAmUBwAiXimsKYtqaStWOefMCDqnecOyDFRzyLBKK");
    double ouBAFC = -687307.5706779907;
    bool dnDddmjegzz = true;
    bool UIwFsAmjTssPrB = false;

    return ouBAFC;
}

void NFvZdNg::pUrEvYSeWVQvKAGj(double Pywifq, double ehxagurDaqxBamvV, double BnauNBvTkbdl)
{
    bool YrfCidCiYNsDQfg = false;
    string zZjVBmLoOTykZiK = string("FrioJpnTFjdYFjKLZxaYcrfhttjDOjLEESwXzeOGGunFfFhXRjOEshaXCjundcwwZKblFkwAlDweJjOisivuKMGuVbEWxJVRrfbiNtkYEguEcHolSCyTfHtjAwRjGBlAvtsXEXqePwRBHMqCJJZxzCowLPqiHIMxtxCOvyVlNdoHefBriSiHYffmbjbOsvSwSIHLEmIEVqrWFEmSvEtWLyGKHuFBNUrbWrZpUUvHqbx");
    double RfQigdCNZcBTM = 147788.55246097973;
    bool TWKejzSvKSej = false;
    int uJhqxWFCTgAI = 2037162753;
    string PbllNwcfoLSXXeL = string("ZJdFmykfdBquEjChehMtfJnNipGdrwyxjDvdmkwTZqnTiKZlGPmuIbtdwQThktRZwOftDPkowiGXTlntqNthURDAuUMwxcrJTdCvpZjXDYXtQkcuDlvDQlBgAUIQKKiQjhaMUamtjpAEqAGYvfkYNYzW");
    string QppGD = string("cEYKltAJGskNsvCSGQRxfXcFLGvHZ");

    if (ehxagurDaqxBamvV <= -30088.914677245917) {
        for (int GQeObM = 1308317371; GQeObM > 0; GQeObM--) {
            uJhqxWFCTgAI += uJhqxWFCTgAI;
            Pywifq *= Pywifq;
        }
    }

    if (PbllNwcfoLSXXeL >= string("ZJdFmykfdBquEjChehMtfJnNipGdrwyxjDvdmkwTZqnTiKZlGPmuIbtdwQThktRZwOftDPkowiGXTlntqNthURDAuUMwxcrJTdCvpZjXDYXtQkcuDlvDQlBgAUIQKKiQjhaMUamtjpAEqAGYvfkYNYzW")) {
        for (int JfcuwZChIvr = 697839866; JfcuwZChIvr > 0; JfcuwZChIvr--) {
            YrfCidCiYNsDQfg = ! YrfCidCiYNsDQfg;
            Pywifq += BnauNBvTkbdl;
        }
    }

    for (int sDjHIraKr = 1248834496; sDjHIraKr > 0; sDjHIraKr--) {
        continue;
    }
}

string NFvZdNg::quiiKNAPTwYZOty(double rsMOxvweb, int sfFYYuOOFirCrxsq, int JNDOWF)
{
    int kcuqB = -1147892859;
    int olPkKiD = -2087579404;
    double qcSbAQGHfPbgZaJ = 390187.9798375173;
    bool oKUdg = true;
    double VHxpueglYijiF = -618760.0755488303;
    double KtbrhoWVksj = -243330.33049661308;
    int wXemmGXYTPbix = 145165968;

    for (int yIAGbm = 2078135187; yIAGbm > 0; yIAGbm--) {
        qcSbAQGHfPbgZaJ /= rsMOxvweb;
        JNDOWF /= wXemmGXYTPbix;
        olPkKiD /= wXemmGXYTPbix;
        wXemmGXYTPbix *= JNDOWF;
        kcuqB += sfFYYuOOFirCrxsq;
        wXemmGXYTPbix += JNDOWF;
    }

    for (int bSLDkHWRjeVz = 978159068; bSLDkHWRjeVz > 0; bSLDkHWRjeVz--) {
        continue;
    }

    return string("nATgTQIanRMlknGlFjYNUDuVSkXdvDeZJfOXjFNDjB");
}

string NFvZdNg::DSCDnGIuH(double TqPlsHB, string govDf, int UcGtO, int FHCNoK)
{
    int gxCEsRglJ = 259529499;
    int UqMfI = -1199389217;
    bool RlFro = false;
    int IBgaDxYV = 888651186;
    int TKVqssGuyG = -1254363123;
    double NAqSc = 237000.78190522658;
    string zBVvCjYAhqt = string("SQBsaXeGjjTskmoLvHRGSmIwKVemUFVbFkjJNfWidadgPvugvQeqoOXBILdCRLCMbDOMPauhLKMkfOytkJYgYjKycBvGmvYYrlNJAveOxYHMIwRVutXZdDolaufRVozjXOGQsQAifZrEkgLKjLMrLxxDBvySHQYhMfcoSTvRqhRDqJhKcWDHaCBKseIxBmWcHMqbYJTirtKsmauQCFlURrWHJc");
    double QaWvUpvXgyq = 585843.668654636;
    string LwzfZQFBj = string("iAjEjWEHgOYHUQLmTtoDVKTJIRhVOPPhWgPdzllugpIneQNtzCZgxVnuBpdIFdMdtTSjHDJHURhUGNKwznQUQtj");

    return LwzfZQFBj;
}

void NFvZdNg::jvXYjZGdL(string bmssmco)
{
    string yrltbYDHFT = string("WTNxnWGoEcgDXBEhDvSizAhfPFBTSJBVrhIYBayQsfbwWjYpnptQhOZyszPEtutwFshSZhidnPaVXjMSrYSliiMVwoUaEtjrCvlwGFrKYUPtYIYJaVVisKCCdJEGPAZGJjdIOQPStaaZENjatfYjWijRoOBmHIvdcdYhSePbUPYtlgazJtuHpfETYbqQarBHVhSlfGXqFGFyXtIeBBNsweVkicAFZSbIuDaAmVD");
    double gfoHYahl = 594572.0318047226;

    if (gfoHYahl != 594572.0318047226) {
        for (int uDqSgKUCz = 614192656; uDqSgKUCz > 0; uDqSgKUCz--) {
            continue;
        }
    }

    if (yrltbYDHFT < string("SoVnTmFOJqljpjMWOgHUYpvmVYLTpzYTcPxRleiVcYUAzQJGCuXBcxvjckSRreykpXFEkVWBtCuXPlWjtuerRksVAKVqqBFrVCluCpLECrmLbHSxzmuVGXgoMQKsfdIiFmGmtPtnPWunBUcAVqhvBeqtQldAChFdVFpkaBHxy")) {
        for (int zBMzLLTvvXrzuxH = 933908646; zBMzLLTvvXrzuxH > 0; zBMzLLTvvXrzuxH--) {
            continue;
        }
    }
}

double NFvZdNg::mumknEWYnlGLZ(int SGyuSxoig, bool ESrXvc, int MpZWmTGBz, double NMqSFro)
{
    double TfcFjl = -543286.416865555;
    bool DZPjiP = false;
    int qTjfRQxc = 314799697;

    if (qTjfRQxc <= 1439045841) {
        for (int CEaLZRLLzwbifvh = 22930668; CEaLZRLLzwbifvh > 0; CEaLZRLLzwbifvh--) {
            continue;
        }
    }

    for (int mgTLkAyikSCrdVB = 232213671; mgTLkAyikSCrdVB > 0; mgTLkAyikSCrdVB--) {
        DZPjiP = DZPjiP;
    }

    for (int kCRWRJPwvCiCZr = 544288202; kCRWRJPwvCiCZr > 0; kCRWRJPwvCiCZr--) {
        NMqSFro /= NMqSFro;
        NMqSFro += NMqSFro;
    }

    for (int XxJzjWT = 1309270175; XxJzjWT > 0; XxJzjWT--) {
        DZPjiP = ESrXvc;
    }

    for (int FXZNSRj = 760523701; FXZNSRj > 0; FXZNSRj--) {
        SGyuSxoig += MpZWmTGBz;
        NMqSFro += NMqSFro;
    }

    for (int dFjOt = 1449269328; dFjOt > 0; dFjOt--) {
        MpZWmTGBz -= qTjfRQxc;
    }

    return TfcFjl;
}

bool NFvZdNg::UbYuiTxL(double CtrtOgUM, double SHWdXpkHx, int qcwlNFTkxIDO)
{
    double Xbneqx = -143675.72938483415;
    bool WWVWkjPSqe = false;
    string TLhpWanUVwL = string("mlvdTbETOKIMKbyEsJdIAhdZWmwZqrSOAhnlcSjsHHDJSQDIMyJVCnePZuYHSCzVhMOVJqCbwrVIJUFiiZAzJGqALXONpBgUUheJtUyTTsMNlWmKiNBLoyjQHppKkndrqFOHrvJGoOpPb");
    double FtsSyTde = 128917.96923810299;
    int EYEElYgBkNXJ = -892766757;
    int QVZrgGJj = 1926086898;
    string GYoSdqohkKrNXj = string("YTILIbxNIsrJdHmklmcblFCjdIGPaiKAbtCoYYnTXiOcukFLjAaMcDHMDrLZOuRpl");
    int RGKFG = -857620332;

    if (qcwlNFTkxIDO < 1926086898) {
        for (int eyNyssvWwSA = 1500157391; eyNyssvWwSA > 0; eyNyssvWwSA--) {
            EYEElYgBkNXJ = QVZrgGJj;
            QVZrgGJj -= qcwlNFTkxIDO;
        }
    }

    for (int GzeyQW = 1888469022; GzeyQW > 0; GzeyQW--) {
        EYEElYgBkNXJ += qcwlNFTkxIDO;
        CtrtOgUM /= SHWdXpkHx;
        CtrtOgUM += Xbneqx;
    }

    for (int OUFPEc = 1725818134; OUFPEc > 0; OUFPEc--) {
        TLhpWanUVwL += GYoSdqohkKrNXj;
    }

    if (CtrtOgUM == 128917.96923810299) {
        for (int ekBOXv = 1273496046; ekBOXv > 0; ekBOXv--) {
            FtsSyTde -= FtsSyTde;
            SHWdXpkHx -= CtrtOgUM;
        }
    }

    for (int fmOtUBklQTSl = 297312051; fmOtUBklQTSl > 0; fmOtUBklQTSl--) {
        Xbneqx -= SHWdXpkHx;
    }

    for (int XBdNkyKapzNOYK = 720960743; XBdNkyKapzNOYK > 0; XBdNkyKapzNOYK--) {
        RGKFG += qcwlNFTkxIDO;
    }

    return WWVWkjPSqe;
}

double NFvZdNg::iWnLPQlAum(int yjfjgsPtnr, string aZhIpwwSbH, double HZdzAQjgk, bool RzaZF, bool nqpjEFzCnXFWTKlj)
{
    bool VWlBjdivDniiC = false;
    double siGvpMxsNSjuh = 89326.6544339648;
    string OjlIeUfOtJ = string("WmiDSbVXxezWBJCZYCdYGujRrsgrjvfFFDAbDNofUxiuLGnnzlMwjChdnbfwzpZXsuRbWZdmcKsNbouBAFhKZPFHmXrkdqjfNXqJJMeqTQaBVNGDXxUJMCLADXvWbZSyEzWGnnUBHHRAwXGGsmMeCNFevuErICUwOVggKvvRTdekgeIPYTdWUlgmObiRJEQZbFwoKxuXRllFeIEDtIPtColjPOx");
    double HrteFC = -567696.6332176835;
    bool SgwFZkzR = true;
    double CyZQW = -908762.2563827771;
    string kHHAqbHXbV = string("FyJFtElYvgKhCxT");
    int mjKuDvfDuUtZA = 500277050;

    for (int NyaDAbfhVjU = 1323430807; NyaDAbfhVjU > 0; NyaDAbfhVjU--) {
        CyZQW *= HZdzAQjgk;
    }

    for (int BNswfDbIqQPYzB = 194596893; BNswfDbIqQPYzB > 0; BNswfDbIqQPYzB--) {
        aZhIpwwSbH += aZhIpwwSbH;
        SgwFZkzR = SgwFZkzR;
        nqpjEFzCnXFWTKlj = SgwFZkzR;
    }

    for (int CxLrABrnYck = 1117677240; CxLrABrnYck > 0; CxLrABrnYck--) {
        SgwFZkzR = nqpjEFzCnXFWTKlj;
        HZdzAQjgk = HrteFC;
        SgwFZkzR = ! nqpjEFzCnXFWTKlj;
    }

    for (int WcuKPshVFIF = 520515855; WcuKPshVFIF > 0; WcuKPshVFIF--) {
        CyZQW /= HrteFC;
        HZdzAQjgk *= siGvpMxsNSjuh;
    }

    for (int hwQpXBlECN = 1298872780; hwQpXBlECN > 0; hwQpXBlECN--) {
        continue;
    }

    for (int OeXJqXuxQ = 1814758391; OeXJqXuxQ > 0; OeXJqXuxQ--) {
        RzaZF = VWlBjdivDniiC;
    }

    return CyZQW;
}

bool NFvZdNg::XLDiPxZKNixwe(string aiUudx, bool TMZFkXQBfZ, string AilIrlO, int YPGmy)
{
    string KWZIEmcW = string("mytJQTiaFbxPWJnzCWdGwPbbiYDPUrfrSkiQucZKQukuFbksBfeVMwkHwpEwEoyZACNdodaWkhJiLjcSPeTFGcAgWMsNhqXPYpgfEPyGvKTahvfKNELjdgZR");
    double ptlAtm = -389197.26003579;
    bool WtzjycSbaOAV = false;
    int YmSRULrczhU = 1994655103;
    bool hwGsraOpsGsOOik = true;
    double VzoJX = -25757.275593858765;
    bool uYZHokVDeBK = false;
    double sbcDYFmVpNGvs = -646538.4180303583;
    string wQXSbmWYbtiENQ = string("JkmKXYNoYNXrqjLHXrpgbuHzuTpBPLxoLjYzWhRmCIGKrhffxkPJlMAmGUrnOBxBGakKlalawgWZYbzksCqebkKZZPUlmjRANCyToqgpbicYQpDGffqhcQuPjBQoKrUevmpUPSzPIBqVksXvmssdtOTHjfXogCYvdMQyWfSihTF");

    for (int hFBkfoVlvdcxeJb = 731104694; hFBkfoVlvdcxeJb > 0; hFBkfoVlvdcxeJb--) {
        continue;
    }

    for (int lDUGFzkfBHkka = 239719360; lDUGFzkfBHkka > 0; lDUGFzkfBHkka--) {
        YmSRULrczhU -= YPGmy;
    }

    for (int PnqThg = 322607443; PnqThg > 0; PnqThg--) {
        wQXSbmWYbtiENQ = AilIrlO;
    }

    return uYZHokVDeBK;
}

double NFvZdNg::VvNVHfuSOwcKsjA()
{
    bool QwmkQplb = true;
    int DakRYog = 1640698768;
    int ChpxubLFOaOvJlh = 1854798836;

    for (int RynMnqlpYimaqED = 23470564; RynMnqlpYimaqED > 0; RynMnqlpYimaqED--) {
        ChpxubLFOaOvJlh = ChpxubLFOaOvJlh;
        ChpxubLFOaOvJlh *= DakRYog;
        QwmkQplb = QwmkQplb;
    }

    for (int FbLJxQF = 149272886; FbLJxQF > 0; FbLJxQF--) {
        continue;
    }

    return 348528.0741398104;
}

bool NFvZdNg::kicZYNkBnPyGJZA(bool lzJqQVvVlJajwh, string QNeskExBC, bool NUxnKtkY)
{
    double qPBlUsRLJPe = -300060.0956200546;
    int JbEPLWucbEKFrxGQ = 521386685;
    double PXBNAnDeJAnQFaG = -731313.6066752148;

    for (int XIowCckheZCLXf = 1880680812; XIowCckheZCLXf > 0; XIowCckheZCLXf--) {
        NUxnKtkY = lzJqQVvVlJajwh;
        NUxnKtkY = lzJqQVvVlJajwh;
        NUxnKtkY = lzJqQVvVlJajwh;
        PXBNAnDeJAnQFaG += PXBNAnDeJAnQFaG;
        lzJqQVvVlJajwh = lzJqQVvVlJajwh;
        QNeskExBC += QNeskExBC;
    }

    for (int sWrDqiPzhpijL = 156729134; sWrDqiPzhpijL > 0; sWrDqiPzhpijL--) {
        QNeskExBC = QNeskExBC;
        lzJqQVvVlJajwh = ! lzJqQVvVlJajwh;
    }

    return NUxnKtkY;
}

double NFvZdNg::PeacdnXciCm(string BknTl)
{
    bool EGRMuOvoeIUfJ = true;
    double SfVUxHevTwRdfLZf = -130777.3777884321;

    return SfVUxHevTwRdfLZf;
}

double NFvZdNg::qXPQTMsZIiLVl(int BRDafGaS, string DhtQPjmwqlLs)
{
    int cLRSnbY = -432131880;
    int HXvNTgmUydIjbI = -1565921283;
    bool VhFtzpNHT = false;
    double atDzKmVXUuXAOH = -517946.7678206006;
    bool gxlHFDy = false;
    bool wwMQQnH = true;
    string FUPIYGhtLMPaqAN = string("RFINCNXbrctGBZLhPpQvlSThcqsQgpvnwuPobYIUdSMbWdkAfWHUmkSjGENODaLUrPHJJuNiSVymgQDaFgMJBgWIQSOUoPPzbzZPsRoPOnWWiRaWWpOxaATQjYw");

    if (cLRSnbY <= -1565921283) {
        for (int yRjHROGFlz = 944582805; yRjHROGFlz > 0; yRjHROGFlz--) {
            VhFtzpNHT = ! VhFtzpNHT;
            BRDafGaS /= cLRSnbY;
            cLRSnbY *= HXvNTgmUydIjbI;
        }
    }

    if (gxlHFDy != true) {
        for (int pWrDnCXIrQJG = 2048478814; pWrDnCXIrQJG > 0; pWrDnCXIrQJG--) {
            cLRSnbY *= cLRSnbY;
            gxlHFDy = wwMQQnH;
        }
    }

    if (DhtQPjmwqlLs > string("RFINCNXbrctGBZLhPpQvlSThcqsQgpvnwuPobYIUdSMbWdkAfWHUmkSjGENODaLUrPHJJuNiSVymgQDaFgMJBgWIQSOUoPPzbzZPsRoPOnWWiRaWWpOxaATQjYw")) {
        for (int TceBThyXnIcBeL = 178925939; TceBThyXnIcBeL > 0; TceBThyXnIcBeL--) {
            HXvNTgmUydIjbI = HXvNTgmUydIjbI;
            cLRSnbY *= HXvNTgmUydIjbI;
            atDzKmVXUuXAOH /= atDzKmVXUuXAOH;
        }
    }

    return atDzKmVXUuXAOH;
}

bool NFvZdNg::MHDbZeM(bool wEBtYy, bool FqCgCucgm, double OjBuX, int hExHmwTELVtgZU)
{
    string QEKsczGuY = string("COJCiCcuAGgXAPExXtorfdxDFFDXSOlKwbwbMqEOErzgSfflWlrBZKzKmdgXnViXZhBOgwaoGkAtvTxxWRTWSwOEjHGcihjXmQqtZmxQormWFezjAATwKEsgdKlUCWLYnROvayDisxpHEtPJkydOZSoufDfkHUVVPqVzrufnaXWEYbHVJXaVSzGwwkdoDzAdVliXnLVNqFXII");
    bool QJdwpeI = true;
    int EveBZzPjIvgGz = -739718027;
    int DNiaPAQOkWj = 1422625757;
    double HWGBBiZVKCBrDtK = 763249.026467751;
    bool XnYXyfbmjrVLDy = false;
    int wRXtQLtUb = 930414606;
    string xAbrDWcSdfDVWI = string("m");
    int FPXyIaUe = 1740014487;
    bool RHYBGjUXLdacBZfn = true;

    for (int fFPqMhKSqTegviWk = 610027335; fFPqMhKSqTegviWk > 0; fFPqMhKSqTegviWk--) {
        continue;
    }

    if (OjBuX >= 763249.026467751) {
        for (int jhPsCmwxkJ = 1149505398; jhPsCmwxkJ > 0; jhPsCmwxkJ--) {
            RHYBGjUXLdacBZfn = FqCgCucgm;
            wEBtYy = RHYBGjUXLdacBZfn;
            wRXtQLtUb += hExHmwTELVtgZU;
        }
    }

    for (int xVjzfmdonrLVbqr = 423926962; xVjzfmdonrLVbqr > 0; xVjzfmdonrLVbqr--) {
        wRXtQLtUb += FPXyIaUe;
    }

    if (EveBZzPjIvgGz == -1996205260) {
        for (int vubShQDpSvHOy = 1541703326; vubShQDpSvHOy > 0; vubShQDpSvHOy--) {
            continue;
        }
    }

    return RHYBGjUXLdacBZfn;
}

double NFvZdNg::AeniKfXLTYVOvf(bool DLvQdP)
{
    bool tdNPWR = false;
    double AObqXSBSuauhsZ = 876691.0891658199;
    int sIWrWPK = -2122637763;
    int FtiQu = 2082774648;
    int wLSHVxqMwfiQNJzg = 1409332004;
    double yKRjasypNr = 985404.2437379545;
    double cTtTkGm = 727832.7644510751;
    string TTwjCKKfnyNWAEiM = string("LyZieBdCVxdloeNgICgnTpPMIHYSLbELymoHDVDOYsBfLIqcvSkkYqvbUSOIYSqRDWcnSZzWZCMCiNUXRJfXAFdyQgYVyLmdfAOKsuHMQFFdFpHCQkRUqOwPhHScNzvuIQKzPLpVGlppLiLGZYRjrQrdOJVIrlUav");
    int ivhxj = 1405021833;

    if (cTtTkGm >= 876691.0891658199) {
        for (int jgeKxknrgnCnrQ = 729364139; jgeKxknrgnCnrQ > 0; jgeKxknrgnCnrQ--) {
            cTtTkGm *= AObqXSBSuauhsZ;
            ivhxj -= wLSHVxqMwfiQNJzg;
        }
    }

    for (int jXgQTCldd = 1659524687; jXgQTCldd > 0; jXgQTCldd--) {
        cTtTkGm /= cTtTkGm;
        wLSHVxqMwfiQNJzg /= FtiQu;
        DLvQdP = ! tdNPWR;
    }

    if (wLSHVxqMwfiQNJzg <= -2122637763) {
        for (int ewhgJKZcPyXKcOm = 346256846; ewhgJKZcPyXKcOm > 0; ewhgJKZcPyXKcOm--) {
            continue;
        }
    }

    for (int tQgYHdjlT = 35870263; tQgYHdjlT > 0; tQgYHdjlT--) {
        sIWrWPK += ivhxj;
        ivhxj *= FtiQu;
    }

    return cTtTkGm;
}

void NFvZdNg::YAKQrTxjx(double imyHvPFZR, double huGWCTi, double ZRWZDpBiEnfBNpt, bool FRIYrTTA)
{
    bool EPofYw = false;

    if (imyHvPFZR != 433436.53191922436) {
        for (int fQndDqCkWr = 1724043393; fQndDqCkWr > 0; fQndDqCkWr--) {
            imyHvPFZR = imyHvPFZR;
            ZRWZDpBiEnfBNpt -= imyHvPFZR;
            imyHvPFZR /= imyHvPFZR;
            FRIYrTTA = FRIYrTTA;
            imyHvPFZR /= huGWCTi;
            ZRWZDpBiEnfBNpt -= imyHvPFZR;
        }
    }

    if (ZRWZDpBiEnfBNpt >= 433436.53191922436) {
        for (int jfaIwl = 1480857574; jfaIwl > 0; jfaIwl--) {
            FRIYrTTA = FRIYrTTA;
            ZRWZDpBiEnfBNpt = huGWCTi;
            imyHvPFZR += imyHvPFZR;
            imyHvPFZR *= imyHvPFZR;
            ZRWZDpBiEnfBNpt /= huGWCTi;
        }
    }

    for (int KPWWGnSKttLKNQ = 1901361606; KPWWGnSKttLKNQ > 0; KPWWGnSKttLKNQ--) {
        ZRWZDpBiEnfBNpt /= ZRWZDpBiEnfBNpt;
        ZRWZDpBiEnfBNpt = imyHvPFZR;
        EPofYw = EPofYw;
        ZRWZDpBiEnfBNpt *= imyHvPFZR;
        imyHvPFZR += imyHvPFZR;
    }

    for (int TIDTE = 600043731; TIDTE > 0; TIDTE--) {
        FRIYrTTA = ! FRIYrTTA;
        ZRWZDpBiEnfBNpt += ZRWZDpBiEnfBNpt;
        FRIYrTTA = ! FRIYrTTA;
    }
}

void NFvZdNg::lrBvTvOQ(int EBMiTNdrmI, double QHgTaJOHbLnpcH, int WCXgyQ, int LQWfyNdoKPBx, string rJrOCRuRfuCqFlyU)
{
    int qejpTtKe = -1835880880;
    int zuYBAWr = 2106195843;
    bool TXEaAzAPbSSUUhu = false;
    bool taXAIabrJYfP = false;
    double NRBObh = 513840.39415110863;
    int cPDvuoQw = 1554736701;
    double uxGixoOG = -356467.590204364;
    string azoSlTtnuXHFG = string("YsBzaJtxCnpgdBCrXGBlDgwHqLVXDcbEmlHwqiAKCgrjazThoeUgHUjzxDFCQBuWqkrlXSJOoTxfpeyVkLepIIYThqRpdsiBUvJCjanJVekmRTwcBRDjUSkzUJfsXDvMIbFMBeWBMSVvgdEFtdCLC");

    for (int vykHBtxXG = 446491419; vykHBtxXG > 0; vykHBtxXG--) {
        QHgTaJOHbLnpcH = QHgTaJOHbLnpcH;
        NRBObh = NRBObh;
    }

    for (int vVliRL = 575139936; vVliRL > 0; vVliRL--) {
        NRBObh -= QHgTaJOHbLnpcH;
        QHgTaJOHbLnpcH = uxGixoOG;
        WCXgyQ += EBMiTNdrmI;
        uxGixoOG /= NRBObh;
        TXEaAzAPbSSUUhu = TXEaAzAPbSSUUhu;
    }
}

NFvZdNg::NFvZdNg()
{
    this->ljZTTF();
    this->DbwaFxKzenKfExJ(-1618532780, string("WUbWrDlExytYdkZqncGxrTYICLzrKaUdbiCXkGgQmXdRtRETgflNoKRVLbCzCtmmyYGLkFCMNxZFdHDJKqjtmRRJUFkTBoMFAmmnqmw"), 635766.8170684162, 1685357084);
    this->FbAKXUwKBhoMB(-1044074.8447042948, true, 18959844, true, 178704913);
    this->HginfwYsJA(string("NevrXYKhzSxTtRCsbSRCQbOjvxRszJoTQHFTtBdzwRzRgDEWgVFVxuYkMpzAOQUChrhZqfNhfpHLoWuaZnULQIAMxAyizKAwAJOeZZGiBWYQwFyHQbXEWyuvjKeDYRecHQeAcgsjnvqRwseDXLIUukZWLLBlCoDZOnEyBvIrrYvXPyRUPUWqjpwxLjffIUzlXcDTsALZWoPBNLnRxoBP"), 1694402732, -775982.56818584, 539730843, 215934.43478071745);
    this->pUrEvYSeWVQvKAGj(80875.4177199863, -525671.7002067595, -30088.914677245917);
    this->quiiKNAPTwYZOty(890329.6117170801, 904153597, 1729759638);
    this->DSCDnGIuH(-731027.624680632, string("sFKsMHhBYHAMsPMUIIXuoaxNeobpePXKoRdxBuRGIUqnoZPZVWdKqdYLWeoLaueAcrapKOXTRJFwDSEGdZkvOaBOvubZvRobDTuLIlounJjHokbCunLFcpEkDUOUVeXAZGBovdBTnMIoSxsPRaXjEnRabnwCzbvWboAOYGtwANcQHdArxSoFiNEdPqglKbMxKIx"), -672241338, 622379491);
    this->jvXYjZGdL(string("SoVnTmFOJqljpjMWOgHUYpvmVYLTpzYTcPxRleiVcYUAzQJGCuXBcxvjckSRreykpXFEkVWBtCuXPlWjtuerRksVAKVqqBFrVCluCpLECrmLbHSxzmuVGXgoMQKsfdIiFmGmtPtnPWunBUcAVqhvBeqtQldAChFdVFpkaBHxy"));
    this->mumknEWYnlGLZ(1439045841, true, -114920947, 857578.8846465257);
    this->UbYuiTxL(404117.5643321456, -99470.15269686865, 1641834182);
    this->iWnLPQlAum(61282628, string("XwrEZPfgvfqDfhllUdBp"), -33706.594166554096, false, true);
    this->XLDiPxZKNixwe(string("EzQkBJncLMpzZExMTUlXQmsWBGsOqJPxHNTmXLLyTgZthvfhMpJQLynkZAawuJsZvYGHoDsvlByLsTEmkHeoApGKYZMBciaOKGiYDeTqjEqeOYQmGTbTIiaSBZAuexjClzzzdKbgSefNsvUJWhjgxQUOMtSegbViwyGoVloz"), false, string("qvAyZrselcrUfXKJCjQJPfmtcFtrZHebFeMTWHFOcBQFhQOGMfodrhOhHGKMgxEzsisMqaRFEXnKgVCJvsuLtIUbNIfYTNvLwjyCNNmbbSLBmPvMCxTQdiaqffADBKYCDVcKNnmGpmgMOjgiLnwKMvVxIcquxBWyYvTQykLQIIvoUXlozDCFkNUMQIJyiIKVOaYDxEyoOsByEQZwqjWIeNbIIcsNQiquiBZvrPeLwqnyBKjypn"), 60212033);
    this->VvNVHfuSOwcKsjA();
    this->kicZYNkBnPyGJZA(false, string("NCNCtRJxcFoDtWnbcZtBDlOJwwEEWgmruhUMZygsHAGoTSXuoMeOSpXTKMRrbctQAhOlPSNjMedTJGGjsndhbXvWbwFoChNpjMTulHAljExzghkIJcukDojJczBGMYkHFAdxbSKiycoPpUvYQNglKGWFaPkAeZFwGSOiNaksLKkgzZwiVHyivLuKsWNyR"), false);
    this->PeacdnXciCm(string("OJdeMiQZGzRWdqKwuOUJsWrRPdrUvSpfrYqhdILQyJuENhNRPCMzxerUmCIAVrGnEwOUyTAuULpdmkFYjSJCHPLXXSPPpdeSZSbIDVRwdLmASNYOhxBPBMDAhNSYvZWdHaZDzKMqoeALmXVIKFjOhoDhtfMqBSBudnJOitMZlPxRpSaocbDBLgVAonzVjhPUhOeBqbqlZRqKjSvEVcZbjnaol"));
    this->qXPQTMsZIiLVl(1370001137, string("iBFgyvgLkkYJhpUDfRNrSegZdwuzsTrbVZKqfxNXKbmmGugkEsuUEZlkYzVaZaqpZRjIchSllxyDwCNWCZPmbUgXAMUNSEaBxRABlYsphzYeqCfFQlWPneZDsMBeNRMQlhBxZAFmvWQKYYLgIqnzLLikdekuW"));
    this->MHDbZeM(true, false, 894834.4143304107, -1996205260);
    this->AeniKfXLTYVOvf(false);
    this->YAKQrTxjx(-465802.3054747401, 433436.53191922436, 356808.1792689771, false);
    this->lrBvTvOQ(1984636747, -510325.7057390473, 1872078049, -1739456794, string("jtQdTCYOSnuRFxzXueqZfEnPLONazYOsbeGAzZGZdaOZCEHPFQlWkUJCsIYvirlZmJBWvPbVjIrhWqoFApyhMeNGHyZkXPEcwClYSvgZiXLPUItDYRDlyKXQOhisFMWgAzRKmOdidoNCWrIKvqkPeKrkVVAnubydqNDpmYvFItqBNZkBAUUpdrqboKnQKrDBziiXpQsQmnAaMRecJhQAOLGPaGZjiHjihQyJFQiJdSdyURQStxFcoWtYRuOWiz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AedghhHDTPPxGO
{
public:
    int yzNrReZRL;

    AedghhHDTPPxGO();
    double qOJJw(string GBCOvA, double zkGPBDjkWNOjkduh, int zsQdl, double QEESftITlNGQjUU);
    double LmrBVCGri(double fzuUKu, bool fNVkWshbb, double FUCUuZJXcySudEJu, string LOrMLMEDu);
    void OEgzS();
    void jlExw(bool DkpeRInWEKYgGWk, string vzeMIOQqqPcfHbF, bool JUnunOQrUdfTuZ, bool YsxELCG, int OuVQaYAdY);
    int DeNFpyYeZwUbOkPu(double EVrVTehjMlT, int DmndOd, bool KwKJGY, int yJAqcqUmtoOwLIF, double YTPHtzVfVXWUlCdg);
    bool UjiLXvoQnPlgk(string QqHLad, int gLoPaeT, string UhxthB, int gaqONSbZreq, string mxuhnWOQPVPUbK);
    void sVnDGaSi();
protected:
    int BfeekLKtXadq;
    string yWpGMg;
    int GRlROVLTfk;
    bool vSpzonoRhaQj;
    double FeeMsyqGCLNC;

    double VZlvAXWjq(double MzEyXyYjhPdZ, double oxMMGtzDuZrxY, string NDASCQqhazW, int KVqvcQJHaeEc);
    string QrYkal(int FTjPF, string HQipSdKyWn, bool SSkfTPjgXRiwfiDS);
    double zFNrqC();
    bool wedjw(int hmXANUgcOOrbK, double BULHezLSOtbPJBu, bool iucqpRXnlxqPHr, bool OwEvDuaJFugNiunt);
    bool YyPamFRWl(double JbdxQnYPFBM, int OSpRLo, bool PjMyJ, double gVbgVDbjpLpxuJ, bool MIksKv);
    double VygrxYencFTWOpy(int RlVONYvc, string MFurgtr);
    void iJFSKqTndyn(double nHiPEkEa, double sxbMrr, string WOfPRWPjz);
    void jmfycZYxSiFDf();
private:
    int cjPrxbUiun;
    string gkKwGQkNx;
    string dnILAtZYWS;
    bool FaBmVGP;
    bool OwnuUhdmXAhUi;
    int wKJIzmFuYbCiULvy;

    bool gnTHYwRHUkXf(string ugUvUVDBbOy, double XdlSFdoCHRekGHSz, string iBriwyfx, int ACGoWG, double XUmUC);
    bool pdOev(double vgYup, int CUhopTjhfQlvKHjr);
    void JAgVKveW(bool lAzxEZ, bool EmPpILFCgdh, string UCywd, bool HNZGtSCXqs, bool szAEVBRlSQEEbpeI);
    bool pgzLbR();
};

double AedghhHDTPPxGO::qOJJw(string GBCOvA, double zkGPBDjkWNOjkduh, int zsQdl, double QEESftITlNGQjUU)
{
    int vFvdTmlaPgBFVaNU = 2082325725;
    string WJIHcJmoigivN = string("ulcAjAHWlAWIdBdxbnAcMiRvXZQOzIvcRCSLaewOcFcBPgqEzWGbDVTCGuduWgmTkapPLCJDlOhFWwKRqAUlZpfKMtUaWUxFRBXpLWFPIFbpjthvPENThdCNlBZyYPtKyVdk");
    double ukscaS = -790055.9758081619;
    double FggLNL = -308890.3242798537;
    double FueYhxHtVRZ = 313533.16951504815;

    for (int WaDwUd = 800467314; WaDwUd > 0; WaDwUd--) {
        QEESftITlNGQjUU /= zkGPBDjkWNOjkduh;
        FggLNL = ukscaS;
        ukscaS -= FggLNL;
        zkGPBDjkWNOjkduh /= zkGPBDjkWNOjkduh;
    }

    for (int obKEWedTkq = 66948745; obKEWedTkq > 0; obKEWedTkq--) {
        ukscaS -= zkGPBDjkWNOjkduh;
    }

    if (FggLNL == 707465.043742814) {
        for (int bTloNXWJQOFpaio = 991192880; bTloNXWJQOFpaio > 0; bTloNXWJQOFpaio--) {
            FggLNL += QEESftITlNGQjUU;
        }
    }

    return FueYhxHtVRZ;
}

double AedghhHDTPPxGO::LmrBVCGri(double fzuUKu, bool fNVkWshbb, double FUCUuZJXcySudEJu, string LOrMLMEDu)
{
    string TPfCx = string("ikJwqdjLpsVpcCgCxVfUFvZiHfTUVEzHmhEVavBzCGgGESDZjKFTyEXknGrzWTpGlenVeCtLdjlNXIQZhcgUfNQbpGSpmfWOCVUHHPURPoarCKyikRatwEcHYEYulVhBIzBQTONlRSYlUlaszHmerkqoIelzQrokqbOvYpsqthoOQOIJoQxFoRzVQvaJKuLcNuJdoPFOsxQNBgAZJjjCxTzaPNn");
    double WXjNyJgInGNinrK = -658745.8326675353;
    double jTZiQ = 1014929.088088688;
    double bQkKXaTNZzvj = -1044281.1400793638;

    return bQkKXaTNZzvj;
}

void AedghhHDTPPxGO::OEgzS()
{
    bool CWtgwMquRtToP = true;
    string KMjnOSNdXTxP = string("WNtaseDmeZDuxtWWxHWvJbPkTJszNTkzempBHgkgrYKwHCasxoQajkTErqJBTPwoUDeXACTinCZchUqgLZaoywBPWKHrbuplrJQWMmLQaQUSQxxhzBFZGjnWrvbNplSWgLyzrawMFfNfaQfowKNhfyZJEHcCJlKGDOqiJYKGwWZBmBWkhYWdPPOdNefjKYZaLPlXlAExuPvDmfDhInFFhSAxxEXogonzrnWQQsKTXY");
    bool fiPOfyomzfUlvBvW = false;
    string zwGNO = string("HqsyWvOOQlsSAETFUfdGbarUFvdOuMyvjbWSUapEiMqqlSyXkVJXKAGADvcngeTSqWClKrykdaDLrMyIKnCFeWoudtawwWzzxjEYKLwCXcPbNbWpVVDbliRozPdNxxIepnmdeXmOwXMjaHVWvWflsnJkpAHnKkaGWYooCSejqUIOQrZqvlqvvWDWdejGiLOhrIcPRIkfVMMwwR");
    string bwQDnXpkjR = string("JaxyIBkGFNdrwFcfEALYUfSUhVXvRNFkQEXccUkWSoLxUcGwgCtZTrcuQWThgDPFmvPgVYoYhpPRPbAmIjmeKfiYvouiCaMEIjKlnhunSEmNKROvzMkaNjDUYXAkEHpAWsFIfuAHIPXcsdhulnKEceklkRpKYwQTTmaXQcstdUmUvgDdLbNwfIdyNzWcpBjXkVOWucIrBOENbunPLUfFKDPaXhIZHYyDOKZGyxjSKWudnbiwwC");

    if (zwGNO == string("JaxyIBkGFNdrwFcfEALYUfSUhVXvRNFkQEXccUkWSoLxUcGwgCtZTrcuQWThgDPFmvPgVYoYhpPRPbAmIjmeKfiYvouiCaMEIjKlnhunSEmNKROvzMkaNjDUYXAkEHpAWsFIfuAHIPXcsdhulnKEceklkRpKYwQTTmaXQcstdUmUvgDdLbNwfIdyNzWcpBjXkVOWucIrBOENbunPLUfFKDPaXhIZHYyDOKZGyxjSKWudnbiwwC")) {
        for (int mroKYDjQ = 1847489789; mroKYDjQ > 0; mroKYDjQ--) {
            KMjnOSNdXTxP = KMjnOSNdXTxP;
            zwGNO += bwQDnXpkjR;
            KMjnOSNdXTxP += zwGNO;
        }
    }

    if (CWtgwMquRtToP == false) {
        for (int djOOuscEjG = 269941003; djOOuscEjG > 0; djOOuscEjG--) {
            continue;
        }
    }

    if (KMjnOSNdXTxP == string("HqsyWvOOQlsSAETFUfdGbarUFvdOuMyvjbWSUapEiMqqlSyXkVJXKAGADvcngeTSqWClKrykdaDLrMyIKnCFeWoudtawwWzzxjEYKLwCXcPbNbWpVVDbliRozPdNxxIepnmdeXmOwXMjaHVWvWflsnJkpAHnKkaGWYooCSejqUIOQrZqvlqvvWDWdejGiLOhrIcPRIkfVMMwwR")) {
        for (int pbClTseyKVYom = 395024826; pbClTseyKVYom > 0; pbClTseyKVYom--) {
            fiPOfyomzfUlvBvW = ! CWtgwMquRtToP;
            KMjnOSNdXTxP = zwGNO;
            zwGNO = bwQDnXpkjR;
            zwGNO += zwGNO;
            CWtgwMquRtToP = fiPOfyomzfUlvBvW;
            zwGNO = KMjnOSNdXTxP;
        }
    }

    if (zwGNO >= string("HqsyWvOOQlsSAETFUfdGbarUFvdOuMyvjbWSUapEiMqqlSyXkVJXKAGADvcngeTSqWClKrykdaDLrMyIKnCFeWoudtawwWzzxjEYKLwCXcPbNbWpVVDbliRozPdNxxIepnmdeXmOwXMjaHVWvWflsnJkpAHnKkaGWYooCSejqUIOQrZqvlqvvWDWdejGiLOhrIcPRIkfVMMwwR")) {
        for (int GlIAzhblLGWeJClw = 1448367040; GlIAzhblLGWeJClw > 0; GlIAzhblLGWeJClw--) {
            zwGNO += bwQDnXpkjR;
        }
    }
}

void AedghhHDTPPxGO::jlExw(bool DkpeRInWEKYgGWk, string vzeMIOQqqPcfHbF, bool JUnunOQrUdfTuZ, bool YsxELCG, int OuVQaYAdY)
{
    double hWRYCMrhzQvesS = -516672.35756244;
    bool RyTzksxmDmDMhkoP = true;
    int NhFfRhgULJ = -2014720357;
    string UWVIysmDNVGkL = string("MrnIrYVlGCeqhmahZSMyjBADnBVOJiDYGDqpopAetufcoyYtgMQUewFJeqQUrqcEpeQRncDuOmoHcqSMOyVelJirWppzDgbDnYToLbrXVqDQBaGDuQLtfMVtodCMHNpagkbROcslStHXxmMAHMPCjjRsdHNwWNOXWUxhTLrlBvONxhJRbGuMiyyKbbCIpcCUResXNShmRSTafQw");
    double TKAsJPQZ = -653378.1765901276;
    string FAhNIlRCJTCdjCyb = string("HROLKMjduEZTErbqXTbNnUpHdyftenutzOYO");
    bool sCDaQjkljEPZ = false;
    bool CMlLDmckWJhdQgTi = true;

    for (int ZYzScYxL = 2011288174; ZYzScYxL > 0; ZYzScYxL--) {
        continue;
    }

    if (JUnunOQrUdfTuZ == false) {
        for (int ZYmSrVePKxybtX = 495426669; ZYmSrVePKxybtX > 0; ZYmSrVePKxybtX--) {
            RyTzksxmDmDMhkoP = ! sCDaQjkljEPZ;
            DkpeRInWEKYgGWk = DkpeRInWEKYgGWk;
        }
    }

    if (UWVIysmDNVGkL == string("TwqTzxCUZyXRRaasspNRsUK")) {
        for (int QCDKXiOq = 314676224; QCDKXiOq > 0; QCDKXiOq--) {
            JUnunOQrUdfTuZ = sCDaQjkljEPZ;
            UWVIysmDNVGkL = FAhNIlRCJTCdjCyb;
            YsxELCG = ! CMlLDmckWJhdQgTi;
            RyTzksxmDmDMhkoP = ! JUnunOQrUdfTuZ;
            OuVQaYAdY *= NhFfRhgULJ;
        }
    }

    for (int EzfjdRWJlin = 634729520; EzfjdRWJlin > 0; EzfjdRWJlin--) {
        continue;
    }
}

int AedghhHDTPPxGO::DeNFpyYeZwUbOkPu(double EVrVTehjMlT, int DmndOd, bool KwKJGY, int yJAqcqUmtoOwLIF, double YTPHtzVfVXWUlCdg)
{
    bool HQZdIBWdHDDex = false;
    int kBMXfgfrf = 1869142461;

    for (int kAgIoRnlLupa = 399770922; kAgIoRnlLupa > 0; kAgIoRnlLupa--) {
        DmndOd = kBMXfgfrf;
        yJAqcqUmtoOwLIF += yJAqcqUmtoOwLIF;
        KwKJGY = ! HQZdIBWdHDDex;
    }

    if (kBMXfgfrf <= -875546232) {
        for (int eGEAHKzgX = 10674470; eGEAHKzgX > 0; eGEAHKzgX--) {
            DmndOd += yJAqcqUmtoOwLIF;
            kBMXfgfrf += kBMXfgfrf;
            kBMXfgfrf /= kBMXfgfrf;
        }
    }

    for (int FhgAQL = 86048993; FhgAQL > 0; FhgAQL--) {
        continue;
    }

    return kBMXfgfrf;
}

bool AedghhHDTPPxGO::UjiLXvoQnPlgk(string QqHLad, int gLoPaeT, string UhxthB, int gaqONSbZreq, string mxuhnWOQPVPUbK)
{
    bool XHItunSuuukeNr = false;
    bool yNMhVGudYuJJgXY = false;
    double NLusimkSfacQbJKU = -886918.0793672759;
    bool NtTHLlAcsyQgK = true;
    string YMprdWQRcsl = string("HNBOQvYdPCImxFIQzfYxLnngPvqrYhgYbJnqIxIlsdjpeADbTdgWIzsfIUgmiWHWuEoKfnvbuRuGeBlPniEbhglRWMqBhsZKvVIoMrAvYxUNMCtJscRvBBYgMcUyAWmoYsSpijaCEHh");
    bool gbLTVGxCbQwMlaM = true;
    bool hEPzhPmNiWYNNf = false;
    int VtRDdY = -1285148503;
    double roZnmFlCpOK = -663080.8712117727;

    for (int IhbPDmymCV = 1942463621; IhbPDmymCV > 0; IhbPDmymCV--) {
        gbLTVGxCbQwMlaM = ! yNMhVGudYuJJgXY;
    }

    return hEPzhPmNiWYNNf;
}

void AedghhHDTPPxGO::sVnDGaSi()
{
    double ZzMgMg = 173831.8113713233;
    string bEfZY = string("VjdTZQVWHJFMTMkdrqurLBJCaVurYzhUeQVFCNHvwtNUzGBmZkFdLIfniPhZFJBXymZOePhTWmiBQAVVgMnqpKPkUITWstaWaRWWiZpHtrieQfdIqliFKgmJoOodEjkPcHwaYuzJbAvDYJHJDPyYaTaDffNgrBjlKLYuWisyKFiHmTvimxNRNjOtMpmeIAMaxQBFvCqQPZEJetIlfb");
    string GnPeNYehgtGT = string("YhZhAGAgKHcrblmxskeCmfwU");
    int mbRgkEHEDcDwz = -1519686875;
    string uCqZwOmLF = string("DzJwdDmrdxHPqYweZKqOmoymianixYVjbsasMGkEhSXAhjAubvAcWEnPArvCDjWmOOnnbZtlrtySTazyLovlpFljTIiomxGYiOGtstepyvwgwVQSshdpZnKsfarHZwClfDQQKcKMOsdDBtAcpFARPPLaToJGYiapyenyPlJOCFSBPMGiWCyqKyqesKQSXeoLkKqaFMeIaHjXgjXxjfyIJgyNRiNGHCsaBtHHWGPkhFNAS");
    string QgwGTEuBvlpOg = string("EtuirAEEreNmxXPfGsETQXrxGfElNVRDgsbeMomYreBMaXHvxTBruOVoHYjgboQAfpVUiRHkedLgwriNUhVptHaELRjoubcSOmkHtRHHmoqEFvIVYbk");
    int QikILqhO = -1132610994;
    bool ajaOTlqTb = true;

    for (int DncoUjotcM = 1593104602; DncoUjotcM > 0; DncoUjotcM--) {
        ajaOTlqTb = ! ajaOTlqTb;
        uCqZwOmLF += QgwGTEuBvlpOg;
        uCqZwOmLF += uCqZwOmLF;
    }

    for (int IDkNqTEPkZLF = 398044457; IDkNqTEPkZLF > 0; IDkNqTEPkZLF--) {
        QgwGTEuBvlpOg = GnPeNYehgtGT;
    }
}

double AedghhHDTPPxGO::VZlvAXWjq(double MzEyXyYjhPdZ, double oxMMGtzDuZrxY, string NDASCQqhazW, int KVqvcQJHaeEc)
{
    int TgLjMTQnqnnwOQH = 1920126381;
    int xtLrJUENILfrb = 144752355;
    string UNDFLiTpvTY = string("OgVnuCJXzNcwgelpCLfYGRdoHtassoQLeODMZCEiQpvZekbVpcievjMKpxSCJxgrorilDrnCNhmdWPWTLslsbVrDqTaawzFYNmHRBeVhZhRmjUkLTVlaOMdJCB");
    bool KBLIAZrg = true;
    string YgPeD = string("ZlXNCXuOMSMYLEZrkmmuiIFYfxbmbDpszxKuAGnuhXbFTcblBfvPFxZhtBDLklpmorMbNAVkmgbUPPlCfYethmOWTAfwqQlwsp");

    for (int DsIcLndiJwI = 1006327394; DsIcLndiJwI > 0; DsIcLndiJwI--) {
        UNDFLiTpvTY = UNDFLiTpvTY;
        TgLjMTQnqnnwOQH *= xtLrJUENILfrb;
        TgLjMTQnqnnwOQH -= TgLjMTQnqnnwOQH;
        YgPeD = NDASCQqhazW;
    }

    if (UNDFLiTpvTY <= string("jueePZnBBSS")) {
        for (int hfbsWxA = 1478037808; hfbsWxA > 0; hfbsWxA--) {
            NDASCQqhazW += YgPeD;
        }
    }

    return oxMMGtzDuZrxY;
}

string AedghhHDTPPxGO::QrYkal(int FTjPF, string HQipSdKyWn, bool SSkfTPjgXRiwfiDS)
{
    string zqiIkA = string("XLWCYGnirCSBQuvlsOYDwpEjoVfuERIikySVNeXCrLXfxRbKDXiJqwEyKCRvzJLRYPrkYclaBhzjPAkuhwQigAfbVrAtbnMfRxrAhuIAYMsPcwbe");
    bool YZdPmG = true;

    for (int xDtPs = 1390484410; xDtPs > 0; xDtPs--) {
        continue;
    }

    for (int lCHJXmruNf = 1312034015; lCHJXmruNf > 0; lCHJXmruNf--) {
        YZdPmG = YZdPmG;
    }

    if (HQipSdKyWn >= string("UhAEVuPglJseGPZ")) {
        for (int qMIIZUDaC = 625133497; qMIIZUDaC > 0; qMIIZUDaC--) {
            SSkfTPjgXRiwfiDS = ! SSkfTPjgXRiwfiDS;
            zqiIkA = HQipSdKyWn;
            YZdPmG = SSkfTPjgXRiwfiDS;
            zqiIkA += zqiIkA;
            YZdPmG = YZdPmG;
        }
    }

    if (HQipSdKyWn != string("UhAEVuPglJseGPZ")) {
        for (int rocAOySKxRo = 1301833419; rocAOySKxRo > 0; rocAOySKxRo--) {
            SSkfTPjgXRiwfiDS = SSkfTPjgXRiwfiDS;
        }
    }

    return zqiIkA;
}

double AedghhHDTPPxGO::zFNrqC()
{
    double rGbEmY = -423505.5788807889;
    int BxwXeyoHQFGQ = 103777865;
    int yegKQWV = 1302378011;
    double VFeFwrwQELoISYM = -257613.87968731357;
    bool oNBBZTNjOck = true;
    string sbGTX = string("HtoOZNKHZoIZDPqatupZhRznaPcYXbaRgQEpXecZBcQTtCqdgLHBgnUlRJSyTFYQUwuSlODfBopabjmxNVMxAgQrYXAzPmaxanRqkBwTKpSkfvjTqlSEXrXitFdnKEwYQAihhfiTGRJyVkNZURJvJFnUGzwmSMWVplKaDajCdaWrUeMRMCmgJALHvNIukXPOAgufPMfeycRPf");
    double IMUtwUuTDBgpasT = -942667.3563415791;
    bool uPkwVjldoozi = true;
    double IaBKpti = -1023218.7792217078;

    if (rGbEmY <= -423505.5788807889) {
        for (int tqYntAWQOLRJVFq = 293255810; tqYntAWQOLRJVFq > 0; tqYntAWQOLRJVFq--) {
            uPkwVjldoozi = oNBBZTNjOck;
            rGbEmY /= VFeFwrwQELoISYM;
            IaBKpti -= IMUtwUuTDBgpasT;
            yegKQWV += BxwXeyoHQFGQ;
        }
    }

    return IaBKpti;
}

bool AedghhHDTPPxGO::wedjw(int hmXANUgcOOrbK, double BULHezLSOtbPJBu, bool iucqpRXnlxqPHr, bool OwEvDuaJFugNiunt)
{
    string iEVZTxubXakMX = string("JJuQiTCaLsOfBVFELIAyowsTAVVEosfXVYdIPMKEWeIXTOJbqLWioYnffrFdpZjcbOYDlNZ");
    int sJbHfWuIdwEQwNl = -1169950330;
    string sxudt = string("RxhuaTrdsVViirLGfUFQBUlkOhGJSVPIotpXFGMZJhwWZIfJrfndyLYZFNyNiSZqhczTVKEtOVaIfssqOlqCzTVQaCDGtOfPBaQKOCFYxWzcVyOxlSRQsmnbvyqpSDglNpQoLbevQpSdyBFCvVYxPAKplKJGpYjhSBedcEfJUoaeG");
    int JvbMBQuFdZPRE = -1390689649;

    for (int bpnvjOIXauZfvpDW = 1971748193; bpnvjOIXauZfvpDW > 0; bpnvjOIXauZfvpDW--) {
        hmXANUgcOOrbK = hmXANUgcOOrbK;
    }

    for (int LUzUhdCh = 1801287753; LUzUhdCh > 0; LUzUhdCh--) {
        sJbHfWuIdwEQwNl /= hmXANUgcOOrbK;
    }

    if (sJbHfWuIdwEQwNl == -1169950330) {
        for (int HmDrX = 1044565217; HmDrX > 0; HmDrX--) {
            hmXANUgcOOrbK = sJbHfWuIdwEQwNl;
            JvbMBQuFdZPRE /= JvbMBQuFdZPRE;
            sxudt = iEVZTxubXakMX;
        }
    }

    for (int WoEmVrjPzl = 1530143326; WoEmVrjPzl > 0; WoEmVrjPzl--) {
        hmXANUgcOOrbK -= hmXANUgcOOrbK;
        BULHezLSOtbPJBu = BULHezLSOtbPJBu;
    }

    if (OwEvDuaJFugNiunt != false) {
        for (int vhnLRRZeknFXf = 515360601; vhnLRRZeknFXf > 0; vhnLRRZeknFXf--) {
            JvbMBQuFdZPRE = JvbMBQuFdZPRE;
        }
    }

    for (int TJRbwrNqdClx = 1603364086; TJRbwrNqdClx > 0; TJRbwrNqdClx--) {
        continue;
    }

    for (int BEwlgDOhJg = 2096247965; BEwlgDOhJg > 0; BEwlgDOhJg--) {
        hmXANUgcOOrbK /= sJbHfWuIdwEQwNl;
        sJbHfWuIdwEQwNl -= JvbMBQuFdZPRE;
    }

    return OwEvDuaJFugNiunt;
}

bool AedghhHDTPPxGO::YyPamFRWl(double JbdxQnYPFBM, int OSpRLo, bool PjMyJ, double gVbgVDbjpLpxuJ, bool MIksKv)
{
    bool xufAnYFkhpH = true;
    bool QopQY = true;
    string MaaczP = string("dFJpQlFJOZOMEJgKyPthcqiJZDxpomHvgfqGjFlLwffXxisAnXKzyzRnXZLOuSJTETplxyKijlQjhHLNKGuUgkhSrmiGBPeyQJAvPBiozkwRPmUtmNvSSPCzXqXwocrHVEOIRxbEGfwMgVhBENbqOwsypjTaDzowrcuiaozUUjmSVPJDEatsnNuhlnRfWUCbxmK");

    if (xufAnYFkhpH == true) {
        for (int xkdbAbK = 322248895; xkdbAbK > 0; xkdbAbK--) {
            continue;
        }
    }

    for (int miwqFeEnFv = 625043810; miwqFeEnFv > 0; miwqFeEnFv--) {
        continue;
    }

    if (MIksKv != true) {
        for (int AchqWrRSnjVWolG = 1967408452; AchqWrRSnjVWolG > 0; AchqWrRSnjVWolG--) {
            MIksKv = ! PjMyJ;
            PjMyJ = ! PjMyJ;
            OSpRLo += OSpRLo;
            JbdxQnYPFBM += gVbgVDbjpLpxuJ;
        }
    }

    return QopQY;
}

double AedghhHDTPPxGO::VygrxYencFTWOpy(int RlVONYvc, string MFurgtr)
{
    int lgLeqxBbsIIDQVEH = 1153944184;
    string xNyNxoNBBWIw = string("nFzXqQoZiDiaGsu");
    string ufCrSqTqf = string("hgRSbLhClJonJycxKTlnCbLxyXKMkIJkjxZWbDGqutHpLwBcdoGkaxUtfVkzDrJUgGLGhYNrEBdsctTidsnIbEepZjriPpeTeSzdnPYJYdLbuUKDBQYQxAspQWKfPJRKtBCaQAntDqxjirNesUYKRctflCxXVQWFkkddSYeqCBSDroWPSNPkheDUFAfGDFjJxen");
    bool PeBBwBOgCxvMc = false;
    string UEiBESSPiq = string("NkNQlXTUspKKJlMvcjAjLVuCzgfgAXGgQiaBHTcDPOPXcUdIAAhAHrYRYLEGfyCw");

    if (MFurgtr < string("NkNQlXTUspKKJlMvcjAjLVuCzgfgAXGgQiaBHTcDPOPXcUdIAAhAHrYRYLEGfyCw")) {
        for (int YkxUbLGePymLLF = 563181011; YkxUbLGePymLLF > 0; YkxUbLGePymLLF--) {
            MFurgtr += xNyNxoNBBWIw;
        }
    }

    if (lgLeqxBbsIIDQVEH != 1974022116) {
        for (int kIVgnAuNMcqXxx = 1134880424; kIVgnAuNMcqXxx > 0; kIVgnAuNMcqXxx--) {
            UEiBESSPiq = ufCrSqTqf;
            MFurgtr = ufCrSqTqf;
            xNyNxoNBBWIw = MFurgtr;
        }
    }

    if (lgLeqxBbsIIDQVEH <= 1153944184) {
        for (int ZkTCvQAbsPEAh = 711110420; ZkTCvQAbsPEAh > 0; ZkTCvQAbsPEAh--) {
            continue;
        }
    }

    for (int mxATRTg = 504962753; mxATRTg > 0; mxATRTg--) {
        MFurgtr = MFurgtr;
    }

    return -936622.1825229255;
}

void AedghhHDTPPxGO::iJFSKqTndyn(double nHiPEkEa, double sxbMrr, string WOfPRWPjz)
{
    int zbjNSTsQvOUjII = -1809658431;
    int CmEmIMB = -1738454225;

    if (nHiPEkEa <= 282453.76143681357) {
        for (int ExhTCr = 1440556882; ExhTCr > 0; ExhTCr--) {
            nHiPEkEa -= nHiPEkEa;
            CmEmIMB /= zbjNSTsQvOUjII;
        }
    }

    for (int kSoYeVJFbh = 85320251; kSoYeVJFbh > 0; kSoYeVJFbh--) {
        sxbMrr += nHiPEkEa;
        nHiPEkEa *= nHiPEkEa;
        sxbMrr /= nHiPEkEa;
    }

    if (CmEmIMB != -1809658431) {
        for (int xfnPgm = 1302621739; xfnPgm > 0; xfnPgm--) {
            WOfPRWPjz = WOfPRWPjz;
        }
    }

    for (int cgwHCoFsOIcfMo = 1896322750; cgwHCoFsOIcfMo > 0; cgwHCoFsOIcfMo--) {
        zbjNSTsQvOUjII *= zbjNSTsQvOUjII;
    }

    if (sxbMrr > 282453.76143681357) {
        for (int LzpLNKkrqe = 1967366828; LzpLNKkrqe > 0; LzpLNKkrqe--) {
            continue;
        }
    }

    for (int uOgMBDnEtGN = 1088594851; uOgMBDnEtGN > 0; uOgMBDnEtGN--) {
        zbjNSTsQvOUjII += CmEmIMB;
        sxbMrr /= sxbMrr;
        zbjNSTsQvOUjII *= CmEmIMB;
        nHiPEkEa *= sxbMrr;
        WOfPRWPjz = WOfPRWPjz;
    }
}

void AedghhHDTPPxGO::jmfycZYxSiFDf()
{
    int JkKQdJR = -743935210;
    bool nOPEYDMjZsJPGc = true;
    string EgkIQpnOY = string("lmGtXBBgEzkoXbnNleFcXisSlIJZLokKWiFmcbBLJVwLRplbOeiIqedBJRirFndFOfraLKzkpByhCUcXTkAMExCOkjLEKaYoxFDUCRDnyOXdlVwmfMuujjxFmrWYpkYsyBVNnefSjGixNwnmrIcAXZhvkBVFAjlNhouSjkFGbReUqcFKqlTFlWPsysrcGLwpPNKoBYjZhPQVKGzrLzRDFAcxBzTpHTPbnj");
    string yPrUNiSwWOKWLxCe = string("LHriCOvKpYEIRjVYzsnIvxBFaVkJuBDmClvKABHQKkwEV");
    int oLsNN = -42770672;
    int tcmqHDtWpb = -458271978;

    for (int vVzGfKbEvDtFS = 1600783282; vVzGfKbEvDtFS > 0; vVzGfKbEvDtFS--) {
        EgkIQpnOY += yPrUNiSwWOKWLxCe;
        tcmqHDtWpb *= JkKQdJR;
        tcmqHDtWpb = oLsNN;
    }

    for (int YvQswkbsLP = 1588793919; YvQswkbsLP > 0; YvQswkbsLP--) {
        yPrUNiSwWOKWLxCe = EgkIQpnOY;
        JkKQdJR = tcmqHDtWpb;
        yPrUNiSwWOKWLxCe = EgkIQpnOY;
        yPrUNiSwWOKWLxCe += EgkIQpnOY;
        tcmqHDtWpb /= oLsNN;
    }
}

bool AedghhHDTPPxGO::gnTHYwRHUkXf(string ugUvUVDBbOy, double XdlSFdoCHRekGHSz, string iBriwyfx, int ACGoWG, double XUmUC)
{
    double rqcGh = -24020.163484773897;
    int RUvooaFrVwUC = 2043125797;
    double SYWmZBYPKZ = -583991.0517676019;
    string RvJUXdGf = string("ZTsfEDoIXZnjbVcwVLpGxysMiLiBjPHKLILUXXAzwKGBeJHWznTqMWLuiDjugddPPVCPGGkCjqPPJJndiaeQeYKmuFwllWUjCQGvVCkUjEpBSwOphFfcmFivZDYEQoktNKUVNndyrtkiIgQEdPVRHvpexXjpjlWIgcHPyKYquGeppzEbCpQXynrYKHUnoBxVCBdKcAjORVeuDLLRNuEBkFqyLtelQgrRjEjLdVyZtSoTYrWHlVHymAFgzE");

    for (int iqFZJHagl = 249699112; iqFZJHagl > 0; iqFZJHagl--) {
        ugUvUVDBbOy = ugUvUVDBbOy;
    }

    return true;
}

bool AedghhHDTPPxGO::pdOev(double vgYup, int CUhopTjhfQlvKHjr)
{
    double GFkSWuSMSS = 51773.11034638891;
    int OfuGg = 2074821303;

    if (OfuGg != 2074821303) {
        for (int aCATmPHhR = 215053736; aCATmPHhR > 0; aCATmPHhR--) {
            GFkSWuSMSS -= GFkSWuSMSS;
            OfuGg *= CUhopTjhfQlvKHjr;
        }
    }

    for (int chXaYFHRmpA = 1795148330; chXaYFHRmpA > 0; chXaYFHRmpA--) {
        CUhopTjhfQlvKHjr *= OfuGg;
        OfuGg += OfuGg;
    }

    for (int HXwRSq = 382671947; HXwRSq > 0; HXwRSq--) {
        OfuGg = OfuGg;
        CUhopTjhfQlvKHjr /= OfuGg;
        OfuGg /= OfuGg;
    }

    for (int gTZmVg = 1457782910; gTZmVg > 0; gTZmVg--) {
        GFkSWuSMSS = GFkSWuSMSS;
        GFkSWuSMSS /= vgYup;
    }

    if (vgYup != 51773.11034638891) {
        for (int LooPKMAxtlb = 1428974434; LooPKMAxtlb > 0; LooPKMAxtlb--) {
            CUhopTjhfQlvKHjr = OfuGg;
            GFkSWuSMSS *= GFkSWuSMSS;
            CUhopTjhfQlvKHjr = CUhopTjhfQlvKHjr;
            vgYup /= GFkSWuSMSS;
            vgYup /= GFkSWuSMSS;
        }
    }

    if (OfuGg < 1552747889) {
        for (int iDBpeBmBvdBTrou = 1114582359; iDBpeBmBvdBTrou > 0; iDBpeBmBvdBTrou--) {
            continue;
        }
    }

    return false;
}

void AedghhHDTPPxGO::JAgVKveW(bool lAzxEZ, bool EmPpILFCgdh, string UCywd, bool HNZGtSCXqs, bool szAEVBRlSQEEbpeI)
{
    double WbbQwxSDeShdrdA = -415657.4182079995;
    int cTEPQhV = 1858659045;
    double gkdqYlySrxEqcrok = -194583.34059202744;
    double jxKsVerYVKZg = 931712.6225319344;

    if (WbbQwxSDeShdrdA >= -194583.34059202744) {
        for (int Ztjbdwubdqg = 453042004; Ztjbdwubdqg > 0; Ztjbdwubdqg--) {
            continue;
        }
    }

    if (szAEVBRlSQEEbpeI != false) {
        for (int KlnVXLiWKsF = 1445837831; KlnVXLiWKsF > 0; KlnVXLiWKsF--) {
            EmPpILFCgdh = lAzxEZ;
            lAzxEZ = ! EmPpILFCgdh;
            jxKsVerYVKZg -= WbbQwxSDeShdrdA;
            HNZGtSCXqs = ! HNZGtSCXqs;
        }
    }

    if (lAzxEZ == false) {
        for (int yoyfbfyJdPcPeud = 1910361674; yoyfbfyJdPcPeud > 0; yoyfbfyJdPcPeud--) {
            WbbQwxSDeShdrdA /= gkdqYlySrxEqcrok;
        }
    }
}

bool AedghhHDTPPxGO::pgzLbR()
{
    bool IVUozTk = true;
    int cUGreJDQYwueAKg = 572478941;
    double heLmllUqwdEQTUg = -374934.8562482379;

    if (cUGreJDQYwueAKg < 572478941) {
        for (int NrbTAmTcKw = 387015584; NrbTAmTcKw > 0; NrbTAmTcKw--) {
            IVUozTk = ! IVUozTk;
        }
    }

    for (int XFyXzNpEgOyGfwG = 1096894478; XFyXzNpEgOyGfwG > 0; XFyXzNpEgOyGfwG--) {
        IVUozTk = IVUozTk;
    }

    for (int orjUhVlnHEPmE = 189615306; orjUhVlnHEPmE > 0; orjUhVlnHEPmE--) {
        cUGreJDQYwueAKg *= cUGreJDQYwueAKg;
        IVUozTk = IVUozTk;
        cUGreJDQYwueAKg /= cUGreJDQYwueAKg;
        cUGreJDQYwueAKg *= cUGreJDQYwueAKg;
    }

    for (int BmjRnh = 1856148021; BmjRnh > 0; BmjRnh--) {
        cUGreJDQYwueAKg -= cUGreJDQYwueAKg;
    }

    return IVUozTk;
}

AedghhHDTPPxGO::AedghhHDTPPxGO()
{
    this->qOJJw(string("jUCTYleyqxEIJYKdrizUVIqanfzLZeMvvAgkypX"), 707465.043742814, 1881051832, 591665.832823298);
    this->LmrBVCGri(870053.3274419645, false, -62486.100473142535, string("ELPsnEVMCiioLrQCMwloJxjPRyXUaQSwfDReZMsxibOoDXoJthRRBFFOdFEDCuyAIVvZWmcryUCyoxVyRuNdmQbPRgDJLMhjZPDlhHaYyjTOVtIjFHpiTLPCJCGJdNLfCjNzIAcEjAuQjrTtoWxObTqNTnUAYAhyKRmtqwlcwZyCsXmJlPDSpeCqFDjIXkGoKMgenbsAg"));
    this->OEgzS();
    this->jlExw(false, string("TwqTzxCUZyXRRaasspNRsUK"), true, true, 792629444);
    this->DeNFpyYeZwUbOkPu(-527775.2065683469, 384877377, true, -875546232, 768204.3114733853);
    this->UjiLXvoQnPlgk(string("UYisCigYYtXbWcuxKgNsDJawuyJMcLLqdoHAtljTnZ"), 1469323034, string("GcfQqOhFdlaVwrshWhvTNCjOOAqebiMxKLUQuhYUrUGdjcXpNbKAIzwlyuwxGdRunP"), -1692328911, string("tNGfHQnlAsWDLpakT"));
    this->sVnDGaSi();
    this->VZlvAXWjq(987421.9968181388, -289631.6282800716, string("jueePZnBBSS"), -600939661);
    this->QrYkal(1643880239, string("UhAEVuPglJseGPZ"), true);
    this->zFNrqC();
    this->wedjw(-32480260, 1030.8640196567524, false, false);
    this->YyPamFRWl(-694295.5049759411, -1995020620, true, -1002160.5607333375, true);
    this->VygrxYencFTWOpy(1974022116, string("lesvYmNjNHQiIADPId"));
    this->iJFSKqTndyn(-1025569.5314828476, 282453.76143681357, string("sAcmhYoQzIaNPItDtwhFDiVUFFsruIdoGfIPpEUnXlPVzFFOKfdjGQvYJOmzvjo"));
    this->jmfycZYxSiFDf();
    this->gnTHYwRHUkXf(string("vHxJShrCmCgcKSqXieeDFTukIl"), -367431.6116795752, string("ofXWoLZpMlOAqDLPcvNVEPgThJCluDFQkBToSR"), 547267773, 134421.3470618748);
    this->pdOev(472068.12391682656, 1552747889);
    this->JAgVKveW(true, false, string("lSkjEjsvyYyQltlAWoNigYXnHUSsHAWcyMMqeWCFVMZoYgOluusbxCDxTHdZeXYPoyKnqCAOXbjNfPuUGFcrJRZsuTjKUbFZZmSyJkHIBoMamsKWDrUakVKLoIUUuthlPAAhQATuFYmNjMvqc"), false, true);
    this->pgzLbR();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vzcuK
{
public:
    double ZWnnUPXZ;
    string YjRddUSyRSXAmmC;
    bool kZUghuRFR;
    double UlaUp;
    double iZbTKWVuPQv;
    double OcMcwWsRfigIJd;

    vzcuK();
    int cJTiV(bool kgOjuP);
    int HKBYc(string GxqjXH, int llhafp);
protected:
    double fzWDbQcTsPGzKfaQ;
    bool OPMbkkkcpeC;
    int BodsWHkoYZ;
    string klnfizNz;
    double nXzDtPPYDB;

    double xaNHdiKXwFDJ(int NoKnZ);
private:
    int rsgAbwaykpBuWb;

    int OUnnKI(string ILqLVhvJAm, bool rOzjHDit, int SJCzAjcShbHMqMlj, bool gglaLKcHADac);
    double wGKZBthWnX(bool fdciIiqPq);
    double XhCcIphIaMQOvntS(bool YZOwD);
    double ATQZmIqZiQBIoYA(int PFtWLGV, double PnYEVroQFErhcPJ, int hYftz);
    bool fEgAAQ();
};

int vzcuK::cJTiV(bool kgOjuP)
{
    int RTTHoPef = 1237203668;
    bool HeunqYxgZE = false;
    bool Ebzjr = false;

    if (kgOjuP != false) {
        for (int vGxXyXGK = 1336590131; vGxXyXGK > 0; vGxXyXGK--) {
            HeunqYxgZE = ! HeunqYxgZE;
            HeunqYxgZE = Ebzjr;
            kgOjuP = ! HeunqYxgZE;
            HeunqYxgZE = ! kgOjuP;
            kgOjuP = kgOjuP;
            HeunqYxgZE = Ebzjr;
        }
    }

    if (Ebzjr == false) {
        for (int zoXuGQAbuXDhns = 1991379638; zoXuGQAbuXDhns > 0; zoXuGQAbuXDhns--) {
            HeunqYxgZE = ! Ebzjr;
        }
    }

    for (int OalMxcEUV = 1499638415; OalMxcEUV > 0; OalMxcEUV--) {
        kgOjuP = Ebzjr;
        kgOjuP = Ebzjr;
    }

    if (HeunqYxgZE == false) {
        for (int wqwyAJCqE = 1688087521; wqwyAJCqE > 0; wqwyAJCqE--) {
            Ebzjr = Ebzjr;
            Ebzjr = kgOjuP;
            kgOjuP = kgOjuP;
            HeunqYxgZE = Ebzjr;
            HeunqYxgZE = ! kgOjuP;
            Ebzjr = kgOjuP;
            HeunqYxgZE = ! HeunqYxgZE;
        }
    }

    for (int gMBwtVL = 327115889; gMBwtVL > 0; gMBwtVL--) {
        HeunqYxgZE = ! Ebzjr;
        kgOjuP = ! HeunqYxgZE;
    }

    if (kgOjuP == false) {
        for (int IIavYflwWAcWw = 479311758; IIavYflwWAcWw > 0; IIavYflwWAcWw--) {
            HeunqYxgZE = kgOjuP;
            kgOjuP = ! HeunqYxgZE;
            kgOjuP = ! HeunqYxgZE;
        }
    }

    return RTTHoPef;
}

int vzcuK::HKBYc(string GxqjXH, int llhafp)
{
    double WzTpzNrj = 890700.6026332796;
    string WpXZME = string("amomBCeSVobHEXIZsQrZCiHUzZBCtvoaZSOMDlekUcPXrIrHFwMverILDCAiTyXnRlLjMrPzrzJyMyivbDLhEAakDBpDQzJaPkBzBqRebukzbmaQQBGkbyJGQFoNRcUf");
    string mVvPKnkZvuXRO = string("KLOkuBFsHiljUodWakRWBloKSRIEoeeGAZUdgSMPWXOoOfmFOyRLgXmtiEnEPBoPUeJJ");
    bool cAcvzXLhovedz = true;
    double DaXBAzSLAiNQ = -896173.5291412015;
    bool fDHbuHxwoSeX = false;
    double gMMhIKLshZ = -763221.7728426863;
    int xRPVDCOairrEXfo = 1125259436;
    string qROlNjonJlDQJWpS = string("QGvsBdlyAoTzcDfNYoIMgoSHHkuypUqAJBlDPtTKJyTTXVGkctrZrlZYdMURTsKxoeRPMkhfSyiINBUVCcTcilwYRGWxkeIHpexBXUQqiryrSStEscFmdzPJoUoTTJNIqvLfTdBHMueGpMAtSHAZVwMvArKDTYMxfTgZaldLEZjCWXwSvsRmxZXyvDMKeLczyXTCtghPTCdNRMPqZTievyJjypEcoXAQjglYFUqrJOSEVaFfAdAXUpjsC");
    double WqxTd = 555169.4480902671;

    for (int WIKGBKHMo = 550718086; WIKGBKHMo > 0; WIKGBKHMo--) {
        continue;
    }

    for (int JwqXxK = 1977620285; JwqXxK > 0; JwqXxK--) {
        continue;
    }

    return xRPVDCOairrEXfo;
}

double vzcuK::xaNHdiKXwFDJ(int NoKnZ)
{
    bool fkxSeyVcvN = false;
    string OKLajNqxZDm = string("frhCOopPyvEccyZyOOFRrezRACzbXpptzFTTqrKwNLvVcpCnqdePGKPXqVzpIjoXlYBSemPmhDtwawSmGYRZCCRYTlFGbgjVdhreENkKJeTXyOoCQbCNSVIMrnZgnNYvrsOBwpQOIpMuncYWcQSntsySgGuhSJVrKaaLrXrIAjOEYxPRSKAsSTkflJeECWHzJdUFaEgJwVGXyvleXhzTYJcpjQKhHFWUpIvQQPZKExwzFyQcJBrRLtCtQa");
    bool UmqqRSF = true;
    bool weQxaKT = true;
    int VtPwZptnEOMW = -269404975;
    double IkTJmRwi = 72503.96426159586;

    for (int IUXAuA = 799228031; IUXAuA > 0; IUXAuA--) {
        fkxSeyVcvN = ! fkxSeyVcvN;
    }

    for (int GDUoEhhhbnlK = 1486121262; GDUoEhhhbnlK > 0; GDUoEhhhbnlK--) {
        VtPwZptnEOMW += VtPwZptnEOMW;
        VtPwZptnEOMW += NoKnZ;
        NoKnZ *= VtPwZptnEOMW;
    }

    if (fkxSeyVcvN != true) {
        for (int EeVhlRlmtOSDdGU = 831413570; EeVhlRlmtOSDdGU > 0; EeVhlRlmtOSDdGU--) {
            fkxSeyVcvN = ! UmqqRSF;
            NoKnZ += NoKnZ;
            UmqqRSF = UmqqRSF;
            VtPwZptnEOMW *= NoKnZ;
        }
    }

    for (int HykSvoL = 1006959922; HykSvoL > 0; HykSvoL--) {
        NoKnZ *= VtPwZptnEOMW;
    }

    return IkTJmRwi;
}

int vzcuK::OUnnKI(string ILqLVhvJAm, bool rOzjHDit, int SJCzAjcShbHMqMlj, bool gglaLKcHADac)
{
    string GuMKNlNQgUYsT = string("TLKWosgBZU");
    string qVkJBdGZyqhxULps = string("MQCZkkBjsnjXLYoYFUejUNQeqYDtcgXxvXkAbwfdULgwsmkfjOvDXArAMnOHiuFaDNylRFrrBDadCOftZrrjueQqTvoJWvSzieTVeAXquJwKvsYbnFbSPXSWYUZQZVQSUtlgsDB");
    double bvwxEfSmuUliAV = -440425.964523964;

    for (int cGEeWNkEgT = 6805563; cGEeWNkEgT > 0; cGEeWNkEgT--) {
        GuMKNlNQgUYsT += GuMKNlNQgUYsT;
        GuMKNlNQgUYsT = GuMKNlNQgUYsT;
    }

    for (int GjhDjRDUQHVTchPW = 1356286861; GjhDjRDUQHVTchPW > 0; GjhDjRDUQHVTchPW--) {
        GuMKNlNQgUYsT += ILqLVhvJAm;
        ILqLVhvJAm = qVkJBdGZyqhxULps;
    }

    for (int qozvgldNoXNpuaH = 2044613119; qozvgldNoXNpuaH > 0; qozvgldNoXNpuaH--) {
        rOzjHDit = rOzjHDit;
    }

    for (int yRGjcaXMD = 158415988; yRGjcaXMD > 0; yRGjcaXMD--) {
        gglaLKcHADac = ! rOzjHDit;
    }

    for (int jTXwTPuHyb = 1958647940; jTXwTPuHyb > 0; jTXwTPuHyb--) {
        continue;
    }

    return SJCzAjcShbHMqMlj;
}

double vzcuK::wGKZBthWnX(bool fdciIiqPq)
{
    string poowKj = string("FarJyocdFdCdXczOCQjGDcoAWATtByXYsKRUIPFFacwWhtJfGfQZQGwfNXvotjAqlkPhwxZvEMrNXsAcbHpFdvhpMufzbgVkAfZFTSqmAYQwMOHkwTJTsrfVTBGrcjHDjmjxzPbSQykxrlcAnMToVqsdTefcUQDPGgeRAdbXLZtCJaVaZduwKhbfTsqnCFQcRKBRaPEUOEgFi");
    double oWDuJiRkqWYA = 302553.0332699914;
    string KnkbexHrsogJl = string("VameIxUtwOjvCNhUhsxMfjjKdagGPQmtBpirrXlQvbLtXYeHgTcLUqJwDEYMAVFvCeVEfaNSWcHTgJkqwT");
    string UCLbVopNp = string("pRUwlWzLKCFInJztwjDKfLRasYNgELNIhRSHrCHXgYQfanLZPylAmZfwYeMWnUfmrRpkgaxIXcqTzPSEBeLnvwYDBvan");
    int TWcZIsDn = -1873550919;
    double WoMfZkgsSjeHuV = 704919.1353994389;
    int CRkgFu = 819185543;
    bool OHLkZjLBQCUHY = false;
    string CBGXD = string("BeDNDPgmrBfEHuIgiTOrOfrGrRJsRZwkLlGvIsTJDLBUcyaZOJOtOyoJcPQnIOfBMIzrQoJgpVDUFOimyLtpJIlwNTRBGzfDGuGftTSWZUyAEYngRxUffiZaGWQDrDsikYKilBlogEQJeuggLjbTWjRMlsIJrFbVNxxSAEgYFxZetXjfreDvPDVvTKsZLCAyhXKTdPDfnoivaHJrIiLzIiYj");
    string GetivaqxPGhC = string("mTMzpkOhDJmOukOgdvScGGUagYEltfHBkpsQYwyzgitJHZvaRrndinquQijwtwODSbVVubfQkjLlhYLi");

    for (int mFKkprdXQfKPkLw = 1580229271; mFKkprdXQfKPkLw > 0; mFKkprdXQfKPkLw--) {
        WoMfZkgsSjeHuV += WoMfZkgsSjeHuV;
        poowKj = GetivaqxPGhC;
    }

    if (GetivaqxPGhC > string("BeDNDPgmrBfEHuIgiTOrOfrGrRJsRZwkLlGvIsTJDLBUcyaZOJOtOyoJcPQnIOfBMIzrQoJgpVDUFOimyLtpJIlwNTRBGzfDGuGftTSWZUyAEYngRxUffiZaGWQDrDsikYKilBlogEQJeuggLjbTWjRMlsIJrFbVNxxSAEgYFxZetXjfreDvPDVvTKsZLCAyhXKTdPDfnoivaHJrIiLzIiYj")) {
        for (int epPqMOAyW = 507567928; epPqMOAyW > 0; epPqMOAyW--) {
            CBGXD = KnkbexHrsogJl;
        }
    }

    for (int CkdHZJcLoTEtFzug = 738494528; CkdHZJcLoTEtFzug > 0; CkdHZJcLoTEtFzug--) {
        UCLbVopNp += UCLbVopNp;
        UCLbVopNp += UCLbVopNp;
    }

    for (int CXLFRDOIa = 2136895552; CXLFRDOIa > 0; CXLFRDOIa--) {
        OHLkZjLBQCUHY = OHLkZjLBQCUHY;
        WoMfZkgsSjeHuV += WoMfZkgsSjeHuV;
        UCLbVopNp += KnkbexHrsogJl;
        CBGXD = CBGXD;
    }

    for (int TsraP = 94744531; TsraP > 0; TsraP--) {
        CRkgFu = CRkgFu;
        CBGXD = GetivaqxPGhC;
    }

    return WoMfZkgsSjeHuV;
}

double vzcuK::XhCcIphIaMQOvntS(bool YZOwD)
{
    int cioTKXljN = -1414929938;
    double BGmnF = -1016499.3091796571;
    string wEZITtdRnWrOifQ = string("ehSHEkiQQyCeABogfcWYHSNnvDGFUgIbcSqZksmSLlbLWhleNFsvvmKBYnpPKBhefLqrbWfUVWLxOlNT");
    double HvQIL = 529982.3370158051;
    int qpxmpukFQXFKi = -509931316;
    string eLLWfPmsqCjnOL = string("eqOEkiSBRWkfBtBNiSNEIBJmHMIUngTJPaPdTadbmYmatIkiqZVcTUbIaYyVhmvvFgkGyDAZwlsHBNgPVsMmxcPbSpvcoSfrJVXeOFJVUTdivXxAmWajDxMRsLtrOoRNQMUhcEFARQDbpWpHUtGwUtxZNnyFYRzVfFNVaZzKcaOLlTxQaGOfFQBN");
    bool AbPYNkma = true;

    for (int JIjyaGEdKZJtsEai = 24900666; JIjyaGEdKZJtsEai > 0; JIjyaGEdKZJtsEai--) {
        wEZITtdRnWrOifQ = wEZITtdRnWrOifQ;
    }

    return HvQIL;
}

double vzcuK::ATQZmIqZiQBIoYA(int PFtWLGV, double PnYEVroQFErhcPJ, int hYftz)
{
    int epAKTQiO = -2031288812;
    string tQIcAmDuixSYHM = string("crPtOkhquFfajIPrxIfAxDULsJYWfVYGSxDTlDlsQCfdvJKOejlxAMCirxd");
    int PzRECQVv = 1749705989;
    double MAntjhkHZYZaP = -865934.5716554528;
    bool BAOkQdGwQ = false;
    bool RSCPwYAAP = true;
    int BjYZoEkYHcOUfF = -1508298432;
    string wRvTWNCwf = string("ClxrkYeKkVXHgwLsyjSKWxTHwfJclYdyrwAhLgbzOVpYGXrtDrjfWSHjpErCHxvyLibSSKcvHZnSDmLDWObhPQJGqWKqeBbHuMXGHRRwdxfHLywewvCKNvExQmYQiQCAVKgWGYEfunfZwrlDHXIWtLZTzNbEAlHFxpnelFYGqQIirnXgVBdtjoJmYiYsqbehoWZIoGhETuETdhsOvADXSqVxNSIYiFXiIupEKOviLWwdjceWRDsMosHW");

    for (int Pufyo = 684269488; Pufyo > 0; Pufyo--) {
        BAOkQdGwQ = ! BAOkQdGwQ;
    }

    for (int rdPVlYHkSCETz = 1576792547; rdPVlYHkSCETz > 0; rdPVlYHkSCETz--) {
        PnYEVroQFErhcPJ /= MAntjhkHZYZaP;
        BjYZoEkYHcOUfF -= PzRECQVv;
        hYftz /= BjYZoEkYHcOUfF;
        hYftz /= PFtWLGV;
    }

    if (BAOkQdGwQ != true) {
        for (int TVQgYia = 1980507727; TVQgYia > 0; TVQgYia--) {
            hYftz -= PFtWLGV;
            epAKTQiO -= BjYZoEkYHcOUfF;
            PnYEVroQFErhcPJ *= PnYEVroQFErhcPJ;
            MAntjhkHZYZaP += MAntjhkHZYZaP;
        }
    }

    for (int hqulOykEy = 390158812; hqulOykEy > 0; hqulOykEy--) {
        wRvTWNCwf += tQIcAmDuixSYHM;
        tQIcAmDuixSYHM += tQIcAmDuixSYHM;
        PFtWLGV *= BjYZoEkYHcOUfF;
        BjYZoEkYHcOUfF *= PzRECQVv;
    }

    if (PzRECQVv <= -695578806) {
        for (int EzvbsBsKCTz = 155062672; EzvbsBsKCTz > 0; EzvbsBsKCTz--) {
            tQIcAmDuixSYHM = wRvTWNCwf;
            hYftz += epAKTQiO;
            BjYZoEkYHcOUfF -= BjYZoEkYHcOUfF;
            PzRECQVv *= PzRECQVv;
        }
    }

    return MAntjhkHZYZaP;
}

bool vzcuK::fEgAAQ()
{
    int rSjGShT = -149961544;
    string NNoXzszHobG = string("OZByqfwERMZROibTgrKNFBfgbLNGyDqeZJFlVwrINvoQFatXSNkzhmXJSnPvnwNHFzpCuekZFZacmZTJcryxpwslqWADvciLQUyMOqLUwUyqiuCFOUtqrHZVssKQRaSXHjiypmAIihLApvzCHxnsJsuIFrPRVSassvHubsqANkvcwvLujLNzlHvpodMujXcaMiJSeNoXYJhcISiSbeiCMDJaEjMbwAKOeoWhAbFXJOBunXNEJBzdyFvWAnAlD");
    double wOAoEuTvAYmAly = 871849.8504962879;
    int XsSwfEEnW = -526697841;

    if (rSjGShT > -526697841) {
        for (int VyygCrGFfOVjYqI = 947171732; VyygCrGFfOVjYqI > 0; VyygCrGFfOVjYqI--) {
            continue;
        }
    }

    for (int dLAIDVOgjFCzfUW = 361455463; dLAIDVOgjFCzfUW > 0; dLAIDVOgjFCzfUW--) {
        wOAoEuTvAYmAly -= wOAoEuTvAYmAly;
        NNoXzszHobG = NNoXzszHobG;
        XsSwfEEnW /= XsSwfEEnW;
        XsSwfEEnW += rSjGShT;
    }

    for (int BwPkTENJgZN = 242529585; BwPkTENJgZN > 0; BwPkTENJgZN--) {
        rSjGShT = rSjGShT;
        NNoXzszHobG += NNoXzszHobG;
        rSjGShT /= rSjGShT;
        XsSwfEEnW -= XsSwfEEnW;
    }

    return false;
}

vzcuK::vzcuK()
{
    this->cJTiV(false);
    this->HKBYc(string("DYocQZkGpuOISipZEdPImAsWpIVUNBWYLgEpBpsoMSQgStEJaiEszUgdsshgGZPMWQRivpLPQhceqcybdfuFHqjRXqEJaHXYVbvOfeBAkoaILxoGTU"), -753519899);
    this->xaNHdiKXwFDJ(-164727171);
    this->OUnnKI(string("oiBgjrVBeJWNedQuCdksOzVumzwDAGtKMSXslwmDbLWxWKIIkvwMkfogIqSxCDjLZgQzSpNDqQVQMPFAqgGeCfEJvsfqaKKVIKgVcAtxcpKXHudlYHRPiaBDCUiYDYmzAccoyKcFFMvBtdqXLlFilOFUhXLXESRhIdWxUSkhgbTyruWcwwLHlVZMIwlCbmhbWIGEkiTJtNVJdhvBriGjhsxQwYbyHSXzNaqqkllmCucsoaCrgMLWHQivANifwxP"), true, 489157874, true);
    this->wGKZBthWnX(false);
    this->XhCcIphIaMQOvntS(true);
    this->ATQZmIqZiQBIoYA(-695578806, -1036449.046566884, 1666972714);
    this->fEgAAQ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class blyNKonOOS
{
public:
    bool eCvNdTBmAi;
    bool IvJclhzdFvlom;
    bool TDwiZrNtoDKdrmWj;

    blyNKonOOS();
    void zpcXWHeadELrJ(bool rbFjNMeAivYJ, string JhQsNToxUzz, double KdxlCdAtx);
    double IJpcc(int WTktRXnYXJ, string tVkTbYnPOop, bool PhDfZOdoOsyOTR, bool sHdDsJcR, double AgAfP);
    int NYxDwxXQyX();
    void jFadMZBfzqOW();
protected:
    int kWPfOuXiL;

    int dSzkYfzgunKjMTa(string BOkYKGClwfQkB, int SVWQHpVxzxfXYYk);
private:
    string dbYotzDLIzqEr;

    bool SGvYfpI(string rMHWKVelbR, bool OKoFA, double uASgmBPWSdH);
    bool DHkXnMHRf(bool CITAwCLWD, string AsYsuZniGoT);
    string AetSG(double JMnojudsknPshc, double CdNlCM, bool SCrCeZsMRzxfQNG);
    string XHOJIIl(int XyETPtqpByfG, double OmhsHkqzTV);
    int scIrosQVxoodt(bool hkxMcIlpl, double UwqMJAzgWaMte);
    bool xUHORnETQVbEJjeH(string UclrFwvptqerov, double QfnabpxQgrZnzpQ, string vHjomGj, bool cXrHadEALVZMZmhV);
    int ICamXlzmegilPh(bool yGwzMZZrSAQJ, bool igrmQmkCYp, double VogeplsOCPWeYYZ, bool uokdeKKdBbUlB);
};

void blyNKonOOS::zpcXWHeadELrJ(bool rbFjNMeAivYJ, string JhQsNToxUzz, double KdxlCdAtx)
{
    bool ZgNYppPeBG = false;
    bool SBoruHpZliVMVc = false;
}

double blyNKonOOS::IJpcc(int WTktRXnYXJ, string tVkTbYnPOop, bool PhDfZOdoOsyOTR, bool sHdDsJcR, double AgAfP)
{
    bool UZtLxJxuu = true;
    int YxvdgIKWYrODsw = 2103399929;
    double sRXJJlcNHEzWdSv = 435421.8298090853;
    double BKpyCssvcQq = -63864.934676729164;

    if (sHdDsJcR == true) {
        for (int LMrOiPqeXlqriQz = 2043773092; LMrOiPqeXlqriQz > 0; LMrOiPqeXlqriQz--) {
            YxvdgIKWYrODsw = WTktRXnYXJ;
        }
    }

    for (int hqFEl = 402113656; hqFEl > 0; hqFEl--) {
        continue;
    }

    for (int uReFeCcTwInram = 1758597531; uReFeCcTwInram > 0; uReFeCcTwInram--) {
        continue;
    }

    if (PhDfZOdoOsyOTR != true) {
        for (int QizmdzZzeTWSX = 1020145569; QizmdzZzeTWSX > 0; QizmdzZzeTWSX--) {
            BKpyCssvcQq /= AgAfP;
            sRXJJlcNHEzWdSv /= AgAfP;
        }
    }

    return BKpyCssvcQq;
}

int blyNKonOOS::NYxDwxXQyX()
{
    double MJBldlmSDe = -1032446.8648247516;
    int NfcnkgMEumyQ = -159684218;
    bool AyeZUmelpNycZHlY = false;
    double GROXn = -919167.9989627772;
    int ybOWZjClPj = -947607584;
    bool UHUPY = true;
    double ROxQMBw = -475649.17281457165;

    if (MJBldlmSDe < -1032446.8648247516) {
        for (int ThjumrdaNgCep = 1981085407; ThjumrdaNgCep > 0; ThjumrdaNgCep--) {
            continue;
        }
    }

    return ybOWZjClPj;
}

void blyNKonOOS::jFadMZBfzqOW()
{
    bool DiZSNMBYxLKrk = true;
    double dPaeaoWMeVP = -234033.4363945344;
    double IofpxeWsDJuFtQ = 191596.0043013577;
    double dXhtqyVpPQxAlF = 981592.9053245344;
    int tPzYknYxbKNxuk = -1311661264;
    string NqDIDjmsOctBzpy = string("OLPzamXhDPGCbVJLT");
    double WznnKroPz = -864613.0554004404;
    bool bPVJM = false;
    bool qZvIzXrwnEr = true;
    int EIZHYB = 776126441;

    for (int VBLsnnQodWUmyVA = 410935476; VBLsnnQodWUmyVA > 0; VBLsnnQodWUmyVA--) {
        continue;
    }

    for (int OfermeneYruM = 871493543; OfermeneYruM > 0; OfermeneYruM--) {
        tPzYknYxbKNxuk /= EIZHYB;
    }

    if (qZvIzXrwnEr == true) {
        for (int llXNWpCjRv = 1157048077; llXNWpCjRv > 0; llXNWpCjRv--) {
            WznnKroPz -= WznnKroPz;
        }
    }
}

int blyNKonOOS::dSzkYfzgunKjMTa(string BOkYKGClwfQkB, int SVWQHpVxzxfXYYk)
{
    bool FgOakZClGMOqtTG = false;
    string tgByT = string("wVFTlHvdEhaeThJvzFhPtSmOYnGpDsUNWheAQIvjBg");
    double INgmigrwqiAi = -706432.5350671759;
    string bkVNPrXyEsgpg = string("xPeeymOrIbegUWCigIUNBMTgjmcmDcVFeDbQbhJBzDnycKxBXbwiSJbQlCkHHWZBeAhxcHGXYfpzNFIPmCjnpPPrDFFFIlBoQtVjfOYzsBEqSxZyiRaLZbbBCRHLpXbMPFEUFdfkQYDNAKAbCXBMBWHLTTCsBaEniGlZFHBoyQncMSYeUJaxhCcvOtWnsbP");

    for (int RhkwOUFrvJZDgjC = 266152706; RhkwOUFrvJZDgjC > 0; RhkwOUFrvJZDgjC--) {
        continue;
    }

    for (int rIPnfa = 1971480924; rIPnfa > 0; rIPnfa--) {
        tgByT += tgByT;
        bkVNPrXyEsgpg += tgByT;
        bkVNPrXyEsgpg = tgByT;
    }

    return SVWQHpVxzxfXYYk;
}

bool blyNKonOOS::SGvYfpI(string rMHWKVelbR, bool OKoFA, double uASgmBPWSdH)
{
    bool ifUGhJWyq = true;
    string yblYFMU = string("jSCNJLb");
    int wHaIfeUPcRKkNhHJ = -672289386;
    bool HOalkYEEgwNuo = false;
    double lFaWLXHGLYCgT = 677853.4809904958;
    double hPcyO = -645616.3744175759;
    bool hcJjU = false;
    string GxsYs = string("sfhSfGSdSvjvtyJkVfiEvsHkYTaTggdAeKGtiUDmGDooUFWLPZPNiETowPwDZVpLabtBzDqylvxBACBpqkPGurQtrzSOaRllBpCpsXaZloHYxPUptJstlavKPRVrNdxSNJaBbZSAYTFQljDJYbltESoJKMBaTGEzbXDCZDuAVCyRxiZKQBWKUFjZdlwvSEzfnQigKNvpjVSehGLOA");

    for (int CfdyEoqYlFP = 941894329; CfdyEoqYlFP > 0; CfdyEoqYlFP--) {
        continue;
    }

    if (GxsYs > string("sfhSfGSdSvjvtyJkVfiEvsHkYTaTggdAeKGtiUDmGDooUFWLPZPNiETowPwDZVpLabtBzDqylvxBACBpqkPGurQtrzSOaRllBpCpsXaZloHYxPUptJstlavKPRVrNdxSNJaBbZSAYTFQljDJYbltESoJKMBaTGEzbXDCZDuAVCyRxiZKQBWKUFjZdlwvSEzfnQigKNvpjVSehGLOA")) {
        for (int VlmLtwd = 1151253765; VlmLtwd > 0; VlmLtwd--) {
            continue;
        }
    }

    for (int cbsjTDnKMTKrguaH = 1354725339; cbsjTDnKMTKrguaH > 0; cbsjTDnKMTKrguaH--) {
        continue;
    }

    if (yblYFMU < string("sfhSfGSdSvjvtyJkVfiEvsHkYTaTggdAeKGtiUDmGDooUFWLPZPNiETowPwDZVpLabtBzDqylvxBACBpqkPGurQtrzSOaRllBpCpsXaZloHYxPUptJstlavKPRVrNdxSNJaBbZSAYTFQljDJYbltESoJKMBaTGEzbXDCZDuAVCyRxiZKQBWKUFjZdlwvSEzfnQigKNvpjVSehGLOA")) {
        for (int utvlqOB = 1977788389; utvlqOB > 0; utvlqOB--) {
            uASgmBPWSdH *= uASgmBPWSdH;
        }
    }

    for (int iqxntvFRUwvvCsEH = 1859573526; iqxntvFRUwvvCsEH > 0; iqxntvFRUwvvCsEH--) {
        continue;
    }

    for (int fkelCPuvuXpK = 321997213; fkelCPuvuXpK > 0; fkelCPuvuXpK--) {
        rMHWKVelbR = yblYFMU;
        rMHWKVelbR = rMHWKVelbR;
    }

    if (hPcyO >= 677853.4809904958) {
        for (int yZauqkmuR = 1336185665; yZauqkmuR > 0; yZauqkmuR--) {
            continue;
        }
    }

    return hcJjU;
}

bool blyNKonOOS::DHkXnMHRf(bool CITAwCLWD, string AsYsuZniGoT)
{
    string moWvcjEAKodJhALh = string("LbgKttesRdhWYxBgbqddEFvJvWDyiZLjltrKopRMVSxSdtwuXUhTJMyJIwZcLFImmKYjDaAhBcbdxaslvHBrBMOggZzkAFdEtPppJEtmJohnuEWNaJDZlNyBgCqhsRNqehQfzWWftwZnuXgzkaTHPIMZQHjlMVastCiYXfDQMxWQyWryRIBCPRFvEspNUnUrNUtZrXexGe");
    double kHNkb = 945326.6960034828;
    int DUtggDlBeiw = -864523418;
    double LwZHStZwLCjl = -707897.237288665;
    bool kxCQz = true;
    bool ciuQaFOfVliNoM = false;
    int TISoiCxkkjq = 1503007260;
    bool RfwOs = true;
    int bBlKiqQy = -76391459;
    string wKWyFhngoN = string("jmzQbkozmab");

    if (kxCQz == true) {
        for (int KPmYQhUY = 1411933970; KPmYQhUY > 0; KPmYQhUY--) {
            RfwOs = ! CITAwCLWD;
            bBlKiqQy += DUtggDlBeiw;
        }
    }

    if (TISoiCxkkjq == -864523418) {
        for (int kHoNS = 1951890452; kHoNS > 0; kHoNS--) {
            continue;
        }
    }

    return RfwOs;
}

string blyNKonOOS::AetSG(double JMnojudsknPshc, double CdNlCM, bool SCrCeZsMRzxfQNG)
{
    int brziAKjFJEjvSsaF = -112926783;
    string mjJKOyHkfI = string("RmXYBhgaKNdJmvAotcuaTVXJpcMalRSulBCuMNYkNQ");
    int fnRrBf = 2088864624;
    string NyaTxBqT = string("HFPBeMAPrXAmVPallBPhmiLVstnyGIAwJjvnikzzWHpNvWISnVZzzWlDSBjkZWNEYcPcpYXaZRxsfVOdFHI");
    int nMHgv = -1631207631;

    for (int aLAYYYyiKdg = 586330106; aLAYYYyiKdg > 0; aLAYYYyiKdg--) {
        NyaTxBqT = mjJKOyHkfI;
        JMnojudsknPshc *= CdNlCM;
    }

    for (int tTmvoersVqfPCIe = 485917265; tTmvoersVqfPCIe > 0; tTmvoersVqfPCIe--) {
        CdNlCM -= CdNlCM;
        JMnojudsknPshc *= CdNlCM;
    }

    for (int lgcKiiLjchHFJJH = 1415698872; lgcKiiLjchHFJJH > 0; lgcKiiLjchHFJJH--) {
        brziAKjFJEjvSsaF *= nMHgv;
    }

    for (int jfiOa = 154439803; jfiOa > 0; jfiOa--) {
        nMHgv -= fnRrBf;
    }

    for (int rHDdPU = 516611329; rHDdPU > 0; rHDdPU--) {
        continue;
    }

    return NyaTxBqT;
}

string blyNKonOOS::XHOJIIl(int XyETPtqpByfG, double OmhsHkqzTV)
{
    double ZKrszcPJSQC = -549315.3004101557;
    double YcRImNK = 168084.58268839365;
    double ShhgXcMdnZAZkFK = 223795.32208331657;
    bool FTEfmRhWqkOtnlt = true;
    int MUmkRbpstFlqKow = 1350839172;
    string dzieYbZvyiztOten = string("TOgUPKcFcVqRjPmlTTFJMxTMTqrlmmPQSFUPFWfAIwWPGmyySwhmvidcUfnSTuYoyRfHbWIktYdRCVfozvPpPvodkpxknIaTfHKwlQsKSBNxyGACxdiwInSrCNyHcDDfvPbRQaijDwjsqlNdcdBabWKqmPnEhMOyzUbqYSMkMYfphtPScQeYqkjYEwVOGRHlH");
    double FticxuYsA = -756726.9194312154;
    string UZelrFqZxQwVaSO = string("yqqRKAPsmOrpOnRKWoKRMGoRFRzPZMyYHadflJENLonVuyfFQvkCNcNoUPHQrhGJVCozbphLqOSLGfbEcOWuYdPDrCzFfspsLgJtdoMUCsJkOhJjUXipskatRgnEZwSyccgSatgHJXCVvfhXaATDRRvdHfABeYmalFOXchBGxrBGMPj");
    int vopAeEMZHC = 1080359199;
    bool oIuCM = true;

    for (int sBzyBekwJ = 1317643046; sBzyBekwJ > 0; sBzyBekwJ--) {
        continue;
    }

    for (int PiPHIhWYdFHPXflp = 1479245303; PiPHIhWYdFHPXflp > 0; PiPHIhWYdFHPXflp--) {
        OmhsHkqzTV += ShhgXcMdnZAZkFK;
        oIuCM = ! oIuCM;
    }

    for (int NDxuaxGhpe = 730598867; NDxuaxGhpe > 0; NDxuaxGhpe--) {
        continue;
    }

    for (int nLqwHE = 387429625; nLqwHE > 0; nLqwHE--) {
        ShhgXcMdnZAZkFK -= YcRImNK;
    }

    return UZelrFqZxQwVaSO;
}

int blyNKonOOS::scIrosQVxoodt(bool hkxMcIlpl, double UwqMJAzgWaMte)
{
    string zNbaitHUm = string("DRkvxPGxbxwVIjvfLeoVRDhzTqaXZIdUdozggqqlGlRZpZaGoayEuGJTjPIjdqsxFJhXJbRObsSVBNCXWbBqoeTQsg");

    for (int dhNro = 540399661; dhNro > 0; dhNro--) {
        hkxMcIlpl = hkxMcIlpl;
        hkxMcIlpl = ! hkxMcIlpl;
    }

    for (int hGURHbt = 1270603169; hGURHbt > 0; hGURHbt--) {
        hkxMcIlpl = hkxMcIlpl;
    }

    return -1137206830;
}

bool blyNKonOOS::xUHORnETQVbEJjeH(string UclrFwvptqerov, double QfnabpxQgrZnzpQ, string vHjomGj, bool cXrHadEALVZMZmhV)
{
    string NVnLvYpif = string("UlpzbMAeOzkjkTOIGEOjlXGYXWTdlMXYMFgFDiIKKRImfLKrzcEYqcIwDIJFRmUzfwkk");

    if (QfnabpxQgrZnzpQ >= -597.9912409765899) {
        for (int QPsApxWCfJ = 578843768; QPsApxWCfJ > 0; QPsApxWCfJ--) {
            cXrHadEALVZMZmhV = cXrHadEALVZMZmhV;
            UclrFwvptqerov += vHjomGj;
            UclrFwvptqerov = vHjomGj;
            NVnLvYpif = UclrFwvptqerov;
            vHjomGj = NVnLvYpif;
        }
    }

    if (vHjomGj < string("xkKYnQzJIUuzNmwApkXNWrPSuOLIGxscpCCNkmuqPanARcSNJxYduOdyTlkdnHXBZZxndhWxFXFvPRQJLQZuLNLkOezAEUiVINoWGWhVLozheNJbhgxGEGnZFaoIsTnAFXRXWbKeYQLfpcijGDwGxJomXzHFaahFNrRtKMVydqtVuRrydBSBGKKGBLOhiKrqeFF")) {
        for (int FpfqvJv = 2041805631; FpfqvJv > 0; FpfqvJv--) {
            NVnLvYpif = vHjomGj;
            UclrFwvptqerov = NVnLvYpif;
        }
    }

    if (vHjomGj != string("UlpzbMAeOzkjkTOIGEOjlXGYXWTdlMXYMFgFDiIKKRImfLKrzcEYqcIwDIJFRmUzfwkk")) {
        for (int UHWdM = 1135093572; UHWdM > 0; UHWdM--) {
            vHjomGj += vHjomGj;
        }
    }

    if (vHjomGj <= string("UkMMxCQwjJvRldLCzQgzrlURCkQHCkaxjNGjQPGszzVwXbswMulOeDDdWEyNMWgpAdWezAMgjmSNiIrCnzvQpQmMuuXItWXIFXTXNoINtskoxBmPHHsWiAOzsRsdPjOArPCalqHsVWfEOvsdWbsWntydPnqNbNWGTTlnbXUZSrGOCNiMfzlDzOZvjFfHXI")) {
        for (int PVgOCHpOt = 801239384; PVgOCHpOt > 0; PVgOCHpOt--) {
            NVnLvYpif += NVnLvYpif;
            UclrFwvptqerov = NVnLvYpif;
            vHjomGj += NVnLvYpif;
        }
    }

    return cXrHadEALVZMZmhV;
}

int blyNKonOOS::ICamXlzmegilPh(bool yGwzMZZrSAQJ, bool igrmQmkCYp, double VogeplsOCPWeYYZ, bool uokdeKKdBbUlB)
{
    double XyBrMFgpzSjqm = 711818.7216838889;
    double RSWQTEqSUkeeQGDj = -205458.34025422778;

    if (RSWQTEqSUkeeQGDj > -205458.34025422778) {
        for (int uelqvfHUZIwv = 106040354; uelqvfHUZIwv > 0; uelqvfHUZIwv--) {
            RSWQTEqSUkeeQGDj /= VogeplsOCPWeYYZ;
            uokdeKKdBbUlB = yGwzMZZrSAQJ;
            RSWQTEqSUkeeQGDj = RSWQTEqSUkeeQGDj;
            VogeplsOCPWeYYZ /= RSWQTEqSUkeeQGDj;
            igrmQmkCYp = yGwzMZZrSAQJ;
            VogeplsOCPWeYYZ -= VogeplsOCPWeYYZ;
        }
    }

    return 812069981;
}

blyNKonOOS::blyNKonOOS()
{
    this->zpcXWHeadELrJ(false, string("URLCTixHaqLyWubqfOvxXurxJnlwJkCCatfjbhYYcmHyXfrVGDIiWJpKkQEPfqLAraxdZpHJoKOSupSBSlenzJxMEMsGEYWJveZWKdAbbeWczrGovidWVZDYTKiANebkCAUqktSFXfHYdCMKfjKstdmRCsORRhbBcbRPoCqpWCywtAPTSLXBMXvuDyiPXuUhFVIIsryeZhrbbVP"), 206819.27506537037);
    this->IJpcc(1175870387, string("dWRuPckrYDYKZtpOopwYDah"), true, true, -964339.7435136833);
    this->NYxDwxXQyX();
    this->jFadMZBfzqOW();
    this->dSzkYfzgunKjMTa(string("gC"), -583039382);
    this->SGvYfpI(string("uANgUThVoSemMnLpZgYPAxtFFZRbtiMqmcsCublyidGAEfOhomtOKpFhSSeFPcGCrJlgJmlPrNzBvLDXZqHboOSfeXStKdtZeXQgMSFVeQBczscsZkVrYedeJAedKGIIEUNGSOliUtJdiQhMuVKcrMayFmvXmsoHIBcgPlmIwtxVKIKVI"), false, 968884.5002764829);
    this->DHkXnMHRf(false, string("wUYByAgjbUCVcULhaGROzkkjrWDgyBFUOWWoZeLrpXzg"));
    this->AetSG(-1014704.4712781105, -334696.34979028226, true);
    this->XHOJIIl(1808769885, -125179.34157331086);
    this->scIrosQVxoodt(true, 513134.498279635);
    this->xUHORnETQVbEJjeH(string("xkKYnQzJIUuzNmwApkXNWrPSuOLIGxscpCCNkmuqPanARcSNJxYduOdyTlkdnHXBZZxndhWxFXFvPRQJLQZuLNLkOezAEUiVINoWGWhVLozheNJbhgxGEGnZFaoIsTnAFXRXWbKeYQLfpcijGDwGxJomXzHFaahFNrRtKMVydqtVuRrydBSBGKKGBLOhiKrqeFF"), -597.9912409765899, string("UkMMxCQwjJvRldLCzQgzrlURCkQHCkaxjNGjQPGszzVwXbswMulOeDDdWEyNMWgpAdWezAMgjmSNiIrCnzvQpQmMuuXItWXIFXTXNoINtskoxBmPHHsWiAOzsRsdPjOArPCalqHsVWfEOvsdWbsWntydPnqNbNWGTTlnbXUZSrGOCNiMfzlDzOZvjFfHXI"), false);
    this->ICamXlzmegilPh(false, false, -19246.195420124786, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wOOvVJkUNGuX
{
public:
    bool uxYJlUNzhAZk;
    double FdnCYO;

    wOOvVJkUNGuX();
    void RNHdDPqNth(string awsGjiIINCs);
protected:
    string lRVah;
    string CJsYIXxavVEstg;

    string WoZfkoiOaFWxFDng();
    bool jOFfmtAZMJlRk(bool UneXH);
    int eMxtmnwuMpboUoz(int ydDJZSkNVYHIZb, string XUEzCstGktHu, int WHlYcpLgOZce, int WIVBuRpaaTAl, string JVsiusin);
    double ROwAkKsNyVGTMNQ(int MXVIMJGGPo, int CJJEzLzrNwiirCu);
    bool RBFPIlZIeWd(bool zTTwGrDPKhHCVBV, bool hfvemkusmhuRj, int rVaRHZca, bool mQvOGCjfKYKY);
    void kdetdMbXmpWwoid();
private:
    double ZFHnQvuJHecFT;
    string HDXBLyBD;
    string iExNDbuGcLs;

    void xJJcYtVwMEWIEbdO(string WnNeEvszhGjJFoVB, int agwGqtmMxJea, int ileamvmpzMqb, bool kBOoNorkfyeChblE);
    void sYgIgVWiHl(int Ftajzt);
    string gfGQhB(string fBvlIzVMjj, double ScUIT, string fvUmLSMtVzsV);
};

void wOOvVJkUNGuX::RNHdDPqNth(string awsGjiIINCs)
{
    int fnvTbNA = 1087134261;

    for (int twKVwtTsVpXCyo = 602250576; twKVwtTsVpXCyo > 0; twKVwtTsVpXCyo--) {
        continue;
    }
}

string wOOvVJkUNGuX::WoZfkoiOaFWxFDng()
{
    double TrXyhmhkPGQKwiq = -21438.69297828792;
    double aSvMFSYbqA = -48398.768289110005;
    string nsYeJiijyqX = string("uFJzbFyXKBhOrjBsaiYKIyvawsFAKRXiRMSCojKJrhNOHqIdPWVpNZ");
    int fuPoFCB = 168026359;
    string BtsFkowr = string("oYZwxDbhGwfJgLGwCGqcKvTYBZFijzgysvpvCYUobprZSZQAWMATEGQUFOhmCusouzcKyuoDFgWVQcgsIQVXBHqKZIJCMVaMgLKFtjJahEkxroEFRryWdZBtfOrqUihWFaTAtHzhAIlWjXawuvctGATAbSyHBUGuMWqbnqVgZjkcAitSzkUeRdktPLjMABenTpleQJMIHOSuFsHzamOrsmPRyuPOHjAMCYnyL");
    double kCEQCoAZk = 78450.10524891167;
    bool CoukeofOFRFZD = false;
    string bKqZOqPvpNWVRxKy = string("BjuNYYupGtWOOVlzjnAKQIeXyIZPjsSoXStCUkVegnHxcDFt");
    string TogRESaiR = string("wHFCHqRpydFIlXRkBteZXhSeijsuxPVBBIDkDEFZPEAtngMicpNqmbbmLPBeGdAwMJsisXOR");

    for (int AgJzKD = 1516831454; AgJzKD > 0; AgJzKD--) {
        continue;
    }

    for (int sorUiwIQmJ = 1574180364; sorUiwIQmJ > 0; sorUiwIQmJ--) {
        aSvMFSYbqA = kCEQCoAZk;
        BtsFkowr = bKqZOqPvpNWVRxKy;
        nsYeJiijyqX += BtsFkowr;
    }

    return TogRESaiR;
}

bool wOOvVJkUNGuX::jOFfmtAZMJlRk(bool UneXH)
{
    int KzInRNexBstkO = -78989680;

    for (int smfDVsHq = 1078603475; smfDVsHq > 0; smfDVsHq--) {
        KzInRNexBstkO += KzInRNexBstkO;
    }

    if (UneXH != false) {
        for (int ZEsfqBU = 1722554171; ZEsfqBU > 0; ZEsfqBU--) {
            KzInRNexBstkO *= KzInRNexBstkO;
            UneXH = ! UneXH;
            KzInRNexBstkO /= KzInRNexBstkO;
            KzInRNexBstkO -= KzInRNexBstkO;
            KzInRNexBstkO += KzInRNexBstkO;
        }
    }

    for (int vwIYuqA = 1012264551; vwIYuqA > 0; vwIYuqA--) {
        UneXH = ! UneXH;
        KzInRNexBstkO += KzInRNexBstkO;
        UneXH = UneXH;
    }

    return UneXH;
}

int wOOvVJkUNGuX::eMxtmnwuMpboUoz(int ydDJZSkNVYHIZb, string XUEzCstGktHu, int WHlYcpLgOZce, int WIVBuRpaaTAl, string JVsiusin)
{
    int cDfSsmai = -1397380679;
    double waglapJQn = -632743.7439386032;
    bool xfkyAHWspLTS = false;
    string jnYmgWJQAjiS = string("CsCVqUmUjRmpqlfCyJRcYjRxWzjKWAVCdnROuWqHGGkNjRURwmHFNmZpiHEAhIvlNSOsmtynXbGnWUIybEYtvqtNKHfDZPcEvgMJFYUPmjDGZGgrQOJrKPDvgAarufPtAdqEDulsDHRJsTWH");
    int PZtEenwrJnhvg = 1536411881;
    int nmLNC = 74751140;

    for (int XEeORA = 1098263292; XEeORA > 0; XEeORA--) {
        waglapJQn += waglapJQn;
    }

    for (int huTnthenkZMh = 726875411; huTnthenkZMh > 0; huTnthenkZMh--) {
        continue;
    }

    if (WHlYcpLgOZce >= -1071476182) {
        for (int gDJRKrSCt = 31382003; gDJRKrSCt > 0; gDJRKrSCt--) {
            nmLNC /= nmLNC;
            cDfSsmai += ydDJZSkNVYHIZb;
        }
    }

    if (XUEzCstGktHu == string("dYUuyrkebBFRQDbwdkQQcFLuBNdBYOILimOIRTNnIIvjVtfJIhSrtMRZRWHJZdKDgwHuqmiUbWHnsHymNjUn")) {
        for (int LWgvW = 535789957; LWgvW > 0; LWgvW--) {
            continue;
        }
    }

    for (int aEoREtk = 815748845; aEoREtk > 0; aEoREtk--) {
        nmLNC -= PZtEenwrJnhvg;
        PZtEenwrJnhvg += cDfSsmai;
        XUEzCstGktHu += JVsiusin;
        PZtEenwrJnhvg += PZtEenwrJnhvg;
        cDfSsmai += ydDJZSkNVYHIZb;
    }

    for (int vPzkgzM = 492279364; vPzkgzM > 0; vPzkgzM--) {
        ydDJZSkNVYHIZb *= PZtEenwrJnhvg;
        ydDJZSkNVYHIZb = ydDJZSkNVYHIZb;
    }

    if (xfkyAHWspLTS == false) {
        for (int geaHEpVkSfmA = 25697423; geaHEpVkSfmA > 0; geaHEpVkSfmA--) {
            nmLNC *= WHlYcpLgOZce;
            JVsiusin += XUEzCstGktHu;
            cDfSsmai *= nmLNC;
            nmLNC *= PZtEenwrJnhvg;
            ydDJZSkNVYHIZb -= WIVBuRpaaTAl;
        }
    }

    return nmLNC;
}

double wOOvVJkUNGuX::ROwAkKsNyVGTMNQ(int MXVIMJGGPo, int CJJEzLzrNwiirCu)
{
    double FcaBFbzshoEhBYCq = 828725.3545871523;
    double XsvQjycNqQrbyV = 122422.00461542007;
    double XjXzbLMbusJeSD = 740659.8447890446;
    int nHboTRAEJXwZ = 555853691;
    double USRXpG = -591029.6719390682;
    string gLcejeqCWea = string("WrQhhuZGNdNtOUNVtZvXFnSQVqPNB");
    bool XmPMEAwdUHJ = true;
    double isEyssn = 948087.7326296049;
    string CgbQLIFakRy = string("bzJWSXhNfNIa");
    string yPBbxudfJzU = string("lOJfbzeCuUTktqnyLpmINVRgzHEsfGwwsrYKEviCyHKcQZCFRhsSEpIzouWVPylEPvnFOmwlIazDJS");

    for (int uWIBvhGcsLEOwFh = 1225540937; uWIBvhGcsLEOwFh > 0; uWIBvhGcsLEOwFh--) {
        gLcejeqCWea = yPBbxudfJzU;
        XsvQjycNqQrbyV *= USRXpG;
        XjXzbLMbusJeSD += XjXzbLMbusJeSD;
    }

    if (XjXzbLMbusJeSD <= 828725.3545871523) {
        for (int UYSdg = 60163360; UYSdg > 0; UYSdg--) {
            gLcejeqCWea = yPBbxudfJzU;
            isEyssn += XsvQjycNqQrbyV;
        }
    }

    return isEyssn;
}

bool wOOvVJkUNGuX::RBFPIlZIeWd(bool zTTwGrDPKhHCVBV, bool hfvemkusmhuRj, int rVaRHZca, bool mQvOGCjfKYKY)
{
    int lUiZSlVae = -746394734;

    for (int RPRyOFSHZ = 275782028; RPRyOFSHZ > 0; RPRyOFSHZ--) {
        mQvOGCjfKYKY = ! mQvOGCjfKYKY;
        hfvemkusmhuRj = ! zTTwGrDPKhHCVBV;
        zTTwGrDPKhHCVBV = zTTwGrDPKhHCVBV;
    }

    if (hfvemkusmhuRj != true) {
        for (int aELJJnsRZjap = 496453739; aELJJnsRZjap > 0; aELJJnsRZjap--) {
            lUiZSlVae += rVaRHZca;
            lUiZSlVae += rVaRHZca;
            lUiZSlVae /= rVaRHZca;
            mQvOGCjfKYKY = ! mQvOGCjfKYKY;
        }
    }

    if (zTTwGrDPKhHCVBV != true) {
        for (int uXFduRQfTkn = 1203733027; uXFduRQfTkn > 0; uXFduRQfTkn--) {
            zTTwGrDPKhHCVBV = hfvemkusmhuRj;
            rVaRHZca = rVaRHZca;
            rVaRHZca -= lUiZSlVae;
            rVaRHZca += rVaRHZca;
        }
    }

    for (int AlkkZBO = 1749629579; AlkkZBO > 0; AlkkZBO--) {
        lUiZSlVae -= lUiZSlVae;
    }

    for (int ACtTPnHzdlGy = 1632245706; ACtTPnHzdlGy > 0; ACtTPnHzdlGy--) {
        hfvemkusmhuRj = ! mQvOGCjfKYKY;
    }

    return mQvOGCjfKYKY;
}

void wOOvVJkUNGuX::kdetdMbXmpWwoid()
{
    bool itOvkhUawDAHrLlm = true;
    int WDffPdtOWebfNp = 2043632027;

    if (itOvkhUawDAHrLlm != true) {
        for (int TepmACIBlbXUPcZc = 1220007455; TepmACIBlbXUPcZc > 0; TepmACIBlbXUPcZc--) {
            itOvkhUawDAHrLlm = ! itOvkhUawDAHrLlm;
            itOvkhUawDAHrLlm = ! itOvkhUawDAHrLlm;
        }
    }

    if (WDffPdtOWebfNp >= 2043632027) {
        for (int pQTbfBmkGk = 887081446; pQTbfBmkGk > 0; pQTbfBmkGk--) {
            WDffPdtOWebfNp = WDffPdtOWebfNp;
            itOvkhUawDAHrLlm = itOvkhUawDAHrLlm;
            WDffPdtOWebfNp = WDffPdtOWebfNp;
            WDffPdtOWebfNp /= WDffPdtOWebfNp;
        }
    }

    for (int JomzNvnB = 483139091; JomzNvnB > 0; JomzNvnB--) {
        WDffPdtOWebfNp += WDffPdtOWebfNp;
        WDffPdtOWebfNp *= WDffPdtOWebfNp;
    }

    if (WDffPdtOWebfNp != 2043632027) {
        for (int dlfHTHl = 1595842613; dlfHTHl > 0; dlfHTHl--) {
            continue;
        }
    }
}

void wOOvVJkUNGuX::xJJcYtVwMEWIEbdO(string WnNeEvszhGjJFoVB, int agwGqtmMxJea, int ileamvmpzMqb, bool kBOoNorkfyeChblE)
{
    double EvHjFjGKW = 746959.930753329;
    bool MRxrdnUs = false;
    bool tURZotVCBFxAE = true;
    double EJJFM = 573486.3996256212;
    string BmRtUiDAw = string("UAGBTSnEMmJPtWkTBjCUgDuadKyeXNELaIoTKJjBzpJQJMnBNuCWjFRvGjikhgaFyPfKbs");
    double LgRKuZnDZGLWPJTQ = -876047.7484328025;
    bool wUfoLZgpf = false;

    for (int KgNVgpivPN = 428701858; KgNVgpivPN > 0; KgNVgpivPN--) {
        kBOoNorkfyeChblE = wUfoLZgpf;
        EvHjFjGKW /= EvHjFjGKW;
        MRxrdnUs = ! kBOoNorkfyeChblE;
    }
}

void wOOvVJkUNGuX::sYgIgVWiHl(int Ftajzt)
{
    int YekJtGAS = 804811202;
    double ckdkO = 889054.0623827446;
    double GpLeZiRL = 617346.400835395;
    int BXqiQSQ = -243664204;
    bool XTLZzThbICUE = true;
    bool uodrcMYEWZkZ = false;
    bool IPUBhHOPvYnP = false;
    double HnMEc = -955307.32870612;

    if (GpLeZiRL >= 617346.400835395) {
        for (int DFQkZ = 1735633593; DFQkZ > 0; DFQkZ--) {
            ckdkO -= GpLeZiRL;
        }
    }

    for (int JoTRC = 1932563054; JoTRC > 0; JoTRC--) {
        continue;
    }

    if (GpLeZiRL >= 617346.400835395) {
        for (int cHkcpudAm = 1260531561; cHkcpudAm > 0; cHkcpudAm--) {
            HnMEc = ckdkO;
            IPUBhHOPvYnP = ! XTLZzThbICUE;
        }
    }
}

string wOOvVJkUNGuX::gfGQhB(string fBvlIzVMjj, double ScUIT, string fvUmLSMtVzsV)
{
    string JTxSEsrsUNtam = string("VHRuIjMfyREaQAvSUhpuQHopZbZYZAavVKEfCzKJqYQFKedGsBbAHPBinVqiwARriZdpjujgOPCPmBPveWbIqjbcqsqVkKlWSMRLLBuAzrPudMMsYJnbiQbTOxBfpWcNkwifPWuzVDoQrYFYeDwCsnoZkSBmCvjMpzxzDxYLQcCmTSiyVJydtXLwLNcpMUBKaaWFUmQoruEARrGdYdlngnvJX");
    double vSYZNeUwxhOfCW = -447381.88916601083;
    string ScNSo = string("j");
    string isvgcSnDpTj = string("zYTGrqGlAXAduPlGKHgcakbWaRgVwiLHnrlNW");
    int YLiJuXSgkhycNLi = 2032714016;

    for (int RTbvhA = 1056357490; RTbvhA > 0; RTbvhA--) {
        continue;
    }

    for (int zDgAmzMlMGJLaxI = 559566476; zDgAmzMlMGJLaxI > 0; zDgAmzMlMGJLaxI--) {
        ScUIT += vSYZNeUwxhOfCW;
        JTxSEsrsUNtam += isvgcSnDpTj;
        JTxSEsrsUNtam += JTxSEsrsUNtam;
    }

    for (int eJiTRJDkbiB = 365304168; eJiTRJDkbiB > 0; eJiTRJDkbiB--) {
        continue;
    }

    if (ScUIT >= -447381.88916601083) {
        for (int duqNFmumywe = 1414842841; duqNFmumywe > 0; duqNFmumywe--) {
            fBvlIzVMjj = fBvlIzVMjj;
            isvgcSnDpTj += JTxSEsrsUNtam;
            JTxSEsrsUNtam = JTxSEsrsUNtam;
        }
    }

    return isvgcSnDpTj;
}

wOOvVJkUNGuX::wOOvVJkUNGuX()
{
    this->RNHdDPqNth(string("m"));
    this->WoZfkoiOaFWxFDng();
    this->jOFfmtAZMJlRk(false);
    this->eMxtmnwuMpboUoz(430749853, string("dYUuyrkebBFRQDbwdkQQcFLuBNdBYOILimOIRTNnIIvjVtfJIhSrtMRZRWHJZdKDgwHuqmiUbWHnsHymNjUn"), -1071476182, -2048810419, string("yPjnEtFuwBksrocpEpOBzIRdgGBWhxqjWSGuaYlIcCaieXrkhRGiAWSOwJwwzHvwEMlkfbnaLuACKiaCyCurWyzMyPCJnzIEhwgLThCUqJiFqmpigJeRvNjHsnVqYVqElAwCfNFjJzAoryeqrQbpDEdnaxEdHdaOgXZiwVDtOpKyDPQEJctutqFZdcFxNPtPqKmpbNbOtCDUxUePdHnWBbLvHvOkCOrkHsqoiNPhLkIZPq"));
    this->ROwAkKsNyVGTMNQ(-398442041, -2074921939);
    this->RBFPIlZIeWd(true, true, 1677788115, true);
    this->kdetdMbXmpWwoid();
    this->xJJcYtVwMEWIEbdO(string("VlUHCAGVhlJYUAzGmoVzOfCDWvaFTsCWUMqGSlqAGgKAQTnpamWcsomViXHrTQOnptLBYaLQKTukJXwuwJaJgvFkFKYlFERQmFmCOiIIDwTFzvxQGSsWYJsVEzpzVMmrxRdtoNIlcKmRRgRoyTSPykXlviBnAdzTVMzVisUOIqzcfyKXExsVAVkpeqKFCHFebAnwaEuuHsqewGJCZXZcR"), 1327390720, -558882322, false);
    this->sYgIgVWiHl(-1366220108);
    this->gfGQhB(string("AGTVvdoIgLYChMiEBSstZlPGYgBCpzVrkpdoxgFUenEyNndUhFKhsgHdRbSbpaacRtkAcZvZwCRutiAOQPBoGjueZTJKFWaLwJnQqtaOsYtjFvsvAALsHxMrYHhShrCSllNWxZwOZFU"), 638087.3575238727, string("HgyPoWgyktHvJCcGLcnsUnjCRqhqjRogbdrSmjhAqsDuD"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KkVzlzPiL
{
public:
    string JJMkjeOz;
    double PZzRH;
    string xRXtg;
    string Wbqoc;

    KkVzlzPiL();
protected:
    int TSJJfBzVbOUZBb;
    int cqJwpLzPQbpHcf;

    int iahSrrpysBGOAfhs(int oZOQRNuRqfsEkLU, double akwJMpNN, int aqDjrWww);
    void GNuXPsX(string urqLJUbQw, string OaUzL, string KnCigbYMXUdP);
private:
    double mqMfNDrCNrjrsZx;

    string FzntogSZWlaEiwcT(bool sRBhyJc, int dPAhGpOz, bool rjTTNfb, int ecEJULJq, double xrcaAFNpM);
    int dNXAXPrgGPilaIH();
    int UnJHxZfrQMcq();
    double JGolfuzPpUBCkOaY(string lkkjsjiXEg, bool zONNJfNgPIvEV, double PICkxQiMYHOaJO, string CEeqJByYEjU);
    double LAyboXQS();
    void BkEZWzJ(string UfQRpMMdMOvo, double mNhmFcSfhpnLf, bool ZurAhuX);
    string mOZxVMHsGAbexc();
    double CIduUGUOBPhjPl(bool tNUETXhvQC);
};

int KkVzlzPiL::iahSrrpysBGOAfhs(int oZOQRNuRqfsEkLU, double akwJMpNN, int aqDjrWww)
{
    bool eghXygTY = true;
    bool hMtPxRZFe = true;
    string nmyNJiCyYvgbR = string("WtMrUWJELPzVLOGQTaOAQKyTqNuGsssOrzSfc");
    bool kajXPqlsXyHetTk = false;
    double TsrGKoh = 492059.99862261844;
    int iRsTpGLAowSNrXpf = 452516135;
    double PlJHubUHzHAaUD = 784303.1604250901;

    for (int mqvHbqUVKdVjLG = 668506391; mqvHbqUVKdVjLG > 0; mqvHbqUVKdVjLG--) {
        TsrGKoh *= PlJHubUHzHAaUD;
    }

    return iRsTpGLAowSNrXpf;
}

void KkVzlzPiL::GNuXPsX(string urqLJUbQw, string OaUzL, string KnCigbYMXUdP)
{
    bool PuYhPZmAKAZMa = false;
    double dEQUO = 958116.6660159922;
    bool rSTEqZZtqTPS = true;
    double OyaMM = -843326.1468542734;
    bool yudHDqjfRpN = true;

    for (int hCDEzfIlDHqe = 158159709; hCDEzfIlDHqe > 0; hCDEzfIlDHqe--) {
        urqLJUbQw = KnCigbYMXUdP;
        OaUzL += OaUzL;
    }

    if (OaUzL != string("DbrTSqOKcrSiMgKPULejCWUjAwCiaGMQQrLxjUKezpozwbhaTjBodqiGWucUjXZcfuDatHzHXXrvrVWEnHGLXVfHAbOTOPZJEGqokHbNVKSkNMHQFOLusfITxCmwBhFCAgxLbyyAChSnyBTZ")) {
        for (int ebnJWLRgWvqszUa = 1113779177; ebnJWLRgWvqszUa > 0; ebnJWLRgWvqszUa--) {
            yudHDqjfRpN = PuYhPZmAKAZMa;
            yudHDqjfRpN = ! rSTEqZZtqTPS;
        }
    }

    for (int POnhgNa = 802682996; POnhgNa > 0; POnhgNa--) {
        dEQUO /= OyaMM;
        yudHDqjfRpN = rSTEqZZtqTPS;
    }
}

string KkVzlzPiL::FzntogSZWlaEiwcT(bool sRBhyJc, int dPAhGpOz, bool rjTTNfb, int ecEJULJq, double xrcaAFNpM)
{
    int ySMKgAPyO = -1474896994;

    if (sRBhyJc != true) {
        for (int APnJURRqqijm = 1157708873; APnJURRqqijm > 0; APnJURRqqijm--) {
            sRBhyJc = ! rjTTNfb;
            ySMKgAPyO = dPAhGpOz;
        }
    }

    return string("FHBqGtRZiqXLxDWwZsIz");
}

int KkVzlzPiL::dNXAXPrgGPilaIH()
{
    string NIUkq = string("AQXCrAYDGcooaMLqKmBrstqnZRfB");
    int mYTwVO = 1057619544;
    bool ZYvjONNuvGtlzFAa = false;
    int aNUnOJQ = -573459403;
    string rjmHYu = string("edGqHEOaOWenPShWJDkEjMDTbWmtmqOUpbxSGaUuShfLCriOqivNGPalapcYbPSxYgyVEtXpfJnFDvrdKVZMUbJwORmrFwJfhAVYdFtgbBhvspVvRySLONuzBuzrbgJMafHwyRvJTJPkFiKebjoVIsDrLtSZaAmWYYgUt");
    int pmiJxLzOOJHu = 907620315;
    double BJlIighOn = -99334.52578737974;
    string CxiVVeq = string("VGUsyIZqLtnInLHWD");
    int ddMNZtMoyEvIAOiA = -1551365550;
    double DrlHZ = 760235.5013512054;

    if (CxiVVeq == string("AQXCrAYDGcooaMLqKmBrstqnZRfB")) {
        for (int PfhNK = 1278804739; PfhNK > 0; PfhNK--) {
            pmiJxLzOOJHu += pmiJxLzOOJHu;
        }
    }

    return ddMNZtMoyEvIAOiA;
}

int KkVzlzPiL::UnJHxZfrQMcq()
{
    bool htcHfCxIp = false;
    bool WXYBDwgWwtDeEIuQ = false;
    double BwIFquhz = 567231.5804914061;
    bool NOWMikdhyyH = true;
    string gCGsXDaXD = string("xEQPKBBXJgzvljAGjeJRvTVQLasofCGwbcXWCdGagKefVCzwvyYqncKNCJbpENVnlWFOpsbaDrmPxkHIDcXTilZoCRCbixTIWKGskmXNPTVsNVcsROpWgHimRNksCtvAbvwKKWrVmtcYnhDppXdNnQlsBZvYYbBawdCW");

    if (gCGsXDaXD != string("xEQPKBBXJgzvljAGjeJRvTVQLasofCGwbcXWCdGagKefVCzwvyYqncKNCJbpENVnlWFOpsbaDrmPxkHIDcXTilZoCRCbixTIWKGskmXNPTVsNVcsROpWgHimRNksCtvAbvwKKWrVmtcYnhDppXdNnQlsBZvYYbBawdCW")) {
        for (int aMUZSJQhViEihaE = 33770513; aMUZSJQhViEihaE > 0; aMUZSJQhViEihaE--) {
            htcHfCxIp = ! htcHfCxIp;
            WXYBDwgWwtDeEIuQ = ! htcHfCxIp;
            WXYBDwgWwtDeEIuQ = htcHfCxIp;
        }
    }

    for (int JbhXz = 1425472557; JbhXz > 0; JbhXz--) {
        WXYBDwgWwtDeEIuQ = ! WXYBDwgWwtDeEIuQ;
        WXYBDwgWwtDeEIuQ = ! htcHfCxIp;
        NOWMikdhyyH = ! NOWMikdhyyH;
        NOWMikdhyyH = NOWMikdhyyH;
    }

    if (WXYBDwgWwtDeEIuQ == false) {
        for (int CkFjIDUXkUiojt = 1433413698; CkFjIDUXkUiojt > 0; CkFjIDUXkUiojt--) {
            WXYBDwgWwtDeEIuQ = ! WXYBDwgWwtDeEIuQ;
            BwIFquhz += BwIFquhz;
        }
    }

    for (int PhnKYTZ = 423694898; PhnKYTZ > 0; PhnKYTZ--) {
        continue;
    }

    return 982986683;
}

double KkVzlzPiL::JGolfuzPpUBCkOaY(string lkkjsjiXEg, bool zONNJfNgPIvEV, double PICkxQiMYHOaJO, string CEeqJByYEjU)
{
    int oYhgvULYaNIwZg = 1527256087;
    double KiGvqyKxBmWWZF = -645162.9940894755;
    bool deznJdZUr = false;
    int XXBhvfYigTHspc = 1177227746;
    int UVoszcGsmamUGUb = 2129593095;
    string ruYiqmjsvT = string("VovKdWACtAiGVWXDTfbkAcAJSFdOwmtCqmVQZWRKQEyUBwnzwnsnpPOWseBnSmiuHhVoDoAZSUwHNtWXcVkdwsll");
    int KoKjKJWdqhdRfxPN = -690411979;
    string pMwZjlvSihBm = string("FxnYYfisEbwaSLKiUdxFxUBPiDJZuxDroaNHNXeIdnsWUsCMuHqzKtptIJhWmuGSnVnPNVDDXPpFiSYWpZtLTQgCCmumbUvGSMSmYBRzAYdkmYRnWXlxaJFsNzhufuVelZCLRZoEnlGavKPLvjcwXMDJjKvhRlsTpsCAaJbfAWbXKmHqLUDprrfTKDvKeREHjGKlmjqELGPkhtkWdoPLzUFnGmmefqdoNzNeuPJywWHFlMrpSLGhesdjLP");
    int eTKAROirJumIStm = 1101936022;
    bool ZNpdsVOzLweLj = false;

    if (oYhgvULYaNIwZg <= 2129593095) {
        for (int lWgBgYEqQjadH = 1778131481; lWgBgYEqQjadH > 0; lWgBgYEqQjadH--) {
            deznJdZUr = ! deznJdZUr;
        }
    }

    return KiGvqyKxBmWWZF;
}

double KkVzlzPiL::LAyboXQS()
{
    double mCXvKgPeVuyigfm = -66547.35919344814;
    int ByzrpxcAUCWIE = 844347052;
    double pQWiDnDHyBzivqkA = -182495.27778807757;
    double AXpxzYvPSWn = 971199.750395945;
    double iJvXH = 869567.4148566618;
    string VXTEcxHlk = string("qLVbQGnGCpDexYQQgfAPQeDcuZcxfFBwSEbpMICbJaoe");

    if (iJvXH != -182495.27778807757) {
        for (int RWQQJQFUCoP = 1290205606; RWQQJQFUCoP > 0; RWQQJQFUCoP--) {
            continue;
        }
    }

    for (int BSexxZZ = 1136745716; BSexxZZ > 0; BSexxZZ--) {
        AXpxzYvPSWn /= iJvXH;
        AXpxzYvPSWn -= mCXvKgPeVuyigfm;
    }

    for (int SZVZJuKKYsJq = 1089076650; SZVZJuKKYsJq > 0; SZVZJuKKYsJq--) {
        iJvXH *= iJvXH;
    }

    if (pQWiDnDHyBzivqkA != -182495.27778807757) {
        for (int UiwMPrxwXNUVEtEI = 187104741; UiwMPrxwXNUVEtEI > 0; UiwMPrxwXNUVEtEI--) {
            mCXvKgPeVuyigfm *= pQWiDnDHyBzivqkA;
            pQWiDnDHyBzivqkA -= iJvXH;
            iJvXH = iJvXH;
        }
    }

    for (int QdXPYtkbQHZ = 1238197725; QdXPYtkbQHZ > 0; QdXPYtkbQHZ--) {
        continue;
    }

    for (int dXyLZyrnMOTzVggh = 146188489; dXyLZyrnMOTzVggh > 0; dXyLZyrnMOTzVggh--) {
        AXpxzYvPSWn = AXpxzYvPSWn;
        pQWiDnDHyBzivqkA /= iJvXH;
    }

    if (mCXvKgPeVuyigfm < 869567.4148566618) {
        for (int PhuWzEpPAT = 48727500; PhuWzEpPAT > 0; PhuWzEpPAT--) {
            iJvXH = iJvXH;
        }
    }

    return iJvXH;
}

void KkVzlzPiL::BkEZWzJ(string UfQRpMMdMOvo, double mNhmFcSfhpnLf, bool ZurAhuX)
{
    double gXKwjhlFc = 198875.25240645237;
    string uUQPRUSViOCclh = string("qtrFdnDrZRnca");
    int xLGpWTibhCjMh = 505346911;
    double TryPu = -719307.8459202487;
    double CXJuhTKOfrEnow = 311876.05393066414;
    int jKOCvzBhYDiqdgsW = -1347404587;
    bool TNkdGLlswSACeO = false;

    for (int rGctlmuIPs = 649127520; rGctlmuIPs > 0; rGctlmuIPs--) {
        mNhmFcSfhpnLf += mNhmFcSfhpnLf;
    }

    if (CXJuhTKOfrEnow >= 311876.05393066414) {
        for (int WhKYwt = 2075406536; WhKYwt > 0; WhKYwt--) {
            TryPu += gXKwjhlFc;
        }
    }

    for (int BWYYoPHOMtuVoA = 636683560; BWYYoPHOMtuVoA > 0; BWYYoPHOMtuVoA--) {
        CXJuhTKOfrEnow += gXKwjhlFc;
    }

    if (CXJuhTKOfrEnow > 198875.25240645237) {
        for (int DRaGGQAedSh = 1473538809; DRaGGQAedSh > 0; DRaGGQAedSh--) {
            continue;
        }
    }

    for (int ZtvFUAtidaw = 1296083802; ZtvFUAtidaw > 0; ZtvFUAtidaw--) {
        gXKwjhlFc += CXJuhTKOfrEnow;
        gXKwjhlFc *= TryPu;
        mNhmFcSfhpnLf *= gXKwjhlFc;
        uUQPRUSViOCclh += UfQRpMMdMOvo;
    }
}

string KkVzlzPiL::mOZxVMHsGAbexc()
{
    string TnEqIQcFiEmDjN = string("ncqYuEGytzHWUnkVkRuVVCSoVptFhSbpGApfDCBudBpwHrlbjfjkBcJZJmrYGQxXZiUluwPoABfGUfiYEVRykHHOJqSmPoXsjRNFCzRrFMhikmSEKEvvVBPqdsxXsiPnxnDwdKVMuQtklKunbasKaEGuKDZEjVF");
    string mIykwUUFVTNSROi = string("hvpcxONdWQVDVFNLGWfvbvmPsVRaXLsaYRxvbaqLkalTQHqeUYXGmQOTfVlDnVjvBvXoDodOEheTuwLWfxVVBSKFsJqRUIzeRybnRhLSRWokBDQawwyBeWeRLdYuDcbrOZVgVnkqWpoJoamoIQKCAJXHMvhlNwuJlSTVjcCbmkFhBWAvTZOSvmcmgjjTJhjNtWWFpknXcihqnyFyeWIVHOhRaNWhgcTFUvGX");

    if (mIykwUUFVTNSROi <= string("hvpcxONdWQVDVFNLGWfvbvmPsVRaXLsaYRxvbaqLkalTQHqeUYXGmQOTfVlDnVjvBvXoDodOEheTuwLWfxVVBSKFsJqRUIzeRybnRhLSRWokBDQawwyBeWeRLdYuDcbrOZVgVnkqWpoJoamoIQKCAJXHMvhlNwuJlSTVjcCbmkFhBWAvTZOSvmcmgjjTJhjNtWWFpknXcihqnyFyeWIVHOhRaNWhgcTFUvGX")) {
        for (int uVHGoNtCDUKCYXF = 1737285049; uVHGoNtCDUKCYXF > 0; uVHGoNtCDUKCYXF--) {
            TnEqIQcFiEmDjN = mIykwUUFVTNSROi;
            TnEqIQcFiEmDjN += mIykwUUFVTNSROi;
            mIykwUUFVTNSROi += TnEqIQcFiEmDjN;
            mIykwUUFVTNSROi += TnEqIQcFiEmDjN;
            mIykwUUFVTNSROi = TnEqIQcFiEmDjN;
            TnEqIQcFiEmDjN = TnEqIQcFiEmDjN;
            TnEqIQcFiEmDjN = mIykwUUFVTNSROi;
            TnEqIQcFiEmDjN += TnEqIQcFiEmDjN;
            TnEqIQcFiEmDjN += mIykwUUFVTNSROi;
        }
    }

    if (mIykwUUFVTNSROi >= string("hvpcxONdWQVDVFNLGWfvbvmPsVRaXLsaYRxvbaqLkalTQHqeUYXGmQOTfVlDnVjvBvXoDodOEheTuwLWfxVVBSKFsJqRUIzeRybnRhLSRWokBDQawwyBeWeRLdYuDcbrOZVgVnkqWpoJoamoIQKCAJXHMvhlNwuJlSTVjcCbmkFhBWAvTZOSvmcmgjjTJhjNtWWFpknXcihqnyFyeWIVHOhRaNWhgcTFUvGX")) {
        for (int QsBPJoKUtNuhEA = 1953793548; QsBPJoKUtNuhEA > 0; QsBPJoKUtNuhEA--) {
            mIykwUUFVTNSROi = mIykwUUFVTNSROi;
            TnEqIQcFiEmDjN += mIykwUUFVTNSROi;
            TnEqIQcFiEmDjN = mIykwUUFVTNSROi;
        }
    }

    if (mIykwUUFVTNSROi >= string("ncqYuEGytzHWUnkVkRuVVCSoVptFhSbpGApfDCBudBpwHrlbjfjkBcJZJmrYGQxXZiUluwPoABfGUfiYEVRykHHOJqSmPoXsjRNFCzRrFMhikmSEKEvvVBPqdsxXsiPnxnDwdKVMuQtklKunbasKaEGuKDZEjVF")) {
        for (int JDSLntAmfKlFri = 50134373; JDSLntAmfKlFri > 0; JDSLntAmfKlFri--) {
            mIykwUUFVTNSROi = TnEqIQcFiEmDjN;
            mIykwUUFVTNSROi += mIykwUUFVTNSROi;
            mIykwUUFVTNSROi += mIykwUUFVTNSROi;
            TnEqIQcFiEmDjN += TnEqIQcFiEmDjN;
            mIykwUUFVTNSROi += TnEqIQcFiEmDjN;
        }
    }

    return mIykwUUFVTNSROi;
}

double KkVzlzPiL::CIduUGUOBPhjPl(bool tNUETXhvQC)
{
    bool qtafOdIcL = true;
    double fWMVwlHmIeUwC = -157609.90662941936;

    if (tNUETXhvQC != true) {
        for (int MtixMqOeZt = 2035665335; MtixMqOeZt > 0; MtixMqOeZt--) {
            continue;
        }
    }

    if (qtafOdIcL != true) {
        for (int pdldiltBtg = 1323575683; pdldiltBtg > 0; pdldiltBtg--) {
            qtafOdIcL = qtafOdIcL;
            qtafOdIcL = ! qtafOdIcL;
        }
    }

    for (int saCZIf = 1541510882; saCZIf > 0; saCZIf--) {
        qtafOdIcL = qtafOdIcL;
    }

    for (int GcpTfQQfRyujC = 657378438; GcpTfQQfRyujC > 0; GcpTfQQfRyujC--) {
        fWMVwlHmIeUwC *= fWMVwlHmIeUwC;
    }

    return fWMVwlHmIeUwC;
}

KkVzlzPiL::KkVzlzPiL()
{
    this->iahSrrpysBGOAfhs(700763218, 737026.6927992697, -1360925396);
    this->GNuXPsX(string("JYNEVrelhgTlrNxTHykfGXIKgbwvdDUtMoxN"), string("DbrTSqOKcrSiMgKPULejCWUjAwCiaGMQQrLxjUKezpozwbhaTjBodqiGWucUjXZcfuDatHzHXXrvrVWEnHGLXVfHAbOTOPZJEGqokHbNVKSkNMHQFOLusfITxCmwBhFCAgxLbyyAChSnyBTZ"), string("bNLxwuLHqwdutexdBhBgMlqrqFdTKdlPgldFCYaTagoDVSqYPCOQTmVbabYLXFPrRPCqMYLzwtEuYzpAxEgpvWSLdsxVYARyMjqylEZxhMbAKxixUcjgceVIGdqGKrunkaZWBlRLfpKvvKukDajAmuTXCIzGeNGTsWBQknwyFKCuslWpefZnjoxNAIiFqTBgHIiYuZtKolA"));
    this->FzntogSZWlaEiwcT(true, 1356433916, true, -994964623, 304877.34071154025);
    this->dNXAXPrgGPilaIH();
    this->UnJHxZfrQMcq();
    this->JGolfuzPpUBCkOaY(string("JnGHHibGxLnvtDachDXAVVlkAdipEqLBKqmtZdrGxnTXVMRvrTOAsYbggzyVKnBkCcGCkmcpjYmhuXCzScgifnHvgUwDVdNeuiImrTWLynQBbErfhoiHjKrKlFxSyxghvbsMzYOVjgsnjMaUmAoyjQrQyNPepkbnQAAHyvQBXFYaDmSkNoDDcrlinvyWndugQlTrRvQlFjKOrJxA"), true, 837243.05574813, string("YPWWeyJupvEAkWMdvApeOkWQENGrxQqMLUnjzaOEwyataXWDMrTOcXuOfmzzjbClldFkgORThilfjuTcERSXPOaiSNOcSxMPUmbjOgSBDvpUqBDGCPRaSCESxBBklqkyIZFLbUJ"));
    this->LAyboXQS();
    this->BkEZWzJ(string("gbFMspuosrdrrtkIxZHTsiteXYGcmwssJZhTIhDuaiAaEdHYwlrKEnsUdEQzkwPZKDmCVktSeFQukpcZPHIfkYTZBcDJkhKhhBhAfKsARryqLcCtRSntklnRqHLGNYMelSqcsjCLnFgyvpXBxAJEeMUMKTZdwCkXLNSFnjTUcqPTAbxbwPHxFioojJXHLEmWVxuXvdTXZbRuLViFcOSrbL"), 618731.298436198, false);
    this->mOZxVMHsGAbexc();
    this->CIduUGUOBPhjPl(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RmQzzNLp
{
public:
    double LnuHsBjLEWVwc;
    int puwIVhxUPt;
    bool dhQMUnbOe;
    bool GZJcySlTudVfyu;
    bool wkozZIJ;

    RmQzzNLp();
    bool DgdmNJgEYMsp();
    string hJInrTtIcTIrZgBp(int hUlmuwyGveWzGCWF, int mGeoozHjqhP, double zqrvdCx, double vGVziAlDRgzZdU, string kQtmYxoq);
    string GeBpycCxwMW(bool fwSGDn, string RSIrQHPnRVBOdJ, bool pCoTqtD, double QfByE);
    string UDZoYVCSZBipqGJM(bool WiQFHhbglD, double GNSGzdvcSynoJ, int fECiRmxamFeWm, int USHyAvqZFBqigR);
    double tKcjXODyMepp(string ZNobpt, string Wcvzrx, bool VCnxFeO, bool nxvbSSLdHx, bool oXvyUSwsNduNpQUc);
    int UbfXk(int hjJyy);
protected:
    string cmViWOjNMjvlayI;
    double uOTvGBU;
    double XfYEbQPoyif;
    string TsqMiioWLD;
    bool XbjdYzyFcXhBhP;
    int iPCaqOoPa;

    void DYtcKXyQLndrcs();
    string sSmtGjDC(string qNNiwqianyrdrE, bool IDCzgRUQbefSKC);
private:
    int tAKcfl;
    string JCRgXJJSzpAfMutk;
    int TIulKm;

    string MbwEgOQKPbU(bool khBGVgZd, bool WlCZhXDffya, int wZMWEOsuRh);
    int bpknoXz();
    int NdmtpYuyZOwk(string kLIMxVV);
    string PejqgxYfUwhtM();
    double DWlKC();
    string nwUWIFavlWxLBigH();
    bool wZERqxbOzkb(double cKysqSi, string YttlZbielxsdeDZ, bool vzMnIAUNEYFtS);
    string qYIYhTXDicmTnoAT(string wGWOFcmVtB, int yBujNIY);
};

bool RmQzzNLp::DgdmNJgEYMsp()
{
    bool vJjNpnGMnAXzhOQ = true;
    int GOsXvWfqFlFUHSNN = -1670316328;
    string kXwrrQAwubaJ = string("sxEAyTSxdPBWWCApasPSueqCbZJNZeIygtaKtLDaiUsbMxmICUZJunweCqubWuCvWiTeDcflDGtclMKGYPcMpCQeqy");
    bool KTwQHyEbjmjVt = false;

    if (KTwQHyEbjmjVt == false) {
        for (int ZWZltTSq = 1355041930; ZWZltTSq > 0; ZWZltTSq--) {
            vJjNpnGMnAXzhOQ = KTwQHyEbjmjVt;
            vJjNpnGMnAXzhOQ = ! vJjNpnGMnAXzhOQ;
            KTwQHyEbjmjVt = ! vJjNpnGMnAXzhOQ;
        }
    }

    for (int PXNpKJk = 2052040920; PXNpKJk > 0; PXNpKJk--) {
        KTwQHyEbjmjVt = KTwQHyEbjmjVt;
        KTwQHyEbjmjVt = vJjNpnGMnAXzhOQ;
    }

    for (int qjFVSQNYro = 628685718; qjFVSQNYro > 0; qjFVSQNYro--) {
        kXwrrQAwubaJ += kXwrrQAwubaJ;
    }

    return KTwQHyEbjmjVt;
}

string RmQzzNLp::hJInrTtIcTIrZgBp(int hUlmuwyGveWzGCWF, int mGeoozHjqhP, double zqrvdCx, double vGVziAlDRgzZdU, string kQtmYxoq)
{
    string qcXQtHVPYjtMTvb = string("CpUqjtkcnbsVaBJShFyiUrBkUOoIBPUxJEsWFOhOiTxBqrTEtvGuh");
    bool JJZDLcnvFMJf = true;
    string WdcmA = string("RZYickEGTcYUbiMgFRgShKomiuGxcGrkPzJzBLzVDXCdGdbMZQpfINIszDohORFFudOoVhIEEVVkpMqNTYZdBMXTGaFdfBoCtYBwTKNUWpWsUovyTwQRkPgEreYlYcFHawKgCkvU");

    for (int lAIvGkicRkt = 941239303; lAIvGkicRkt > 0; lAIvGkicRkt--) {
        WdcmA = kQtmYxoq;
        qcXQtHVPYjtMTvb += kQtmYxoq;
    }

    for (int rhTwSAF = 225562291; rhTwSAF > 0; rhTwSAF--) {
        hUlmuwyGveWzGCWF -= mGeoozHjqhP;
        hUlmuwyGveWzGCWF /= hUlmuwyGveWzGCWF;
    }

    return WdcmA;
}

string RmQzzNLp::GeBpycCxwMW(bool fwSGDn, string RSIrQHPnRVBOdJ, bool pCoTqtD, double QfByE)
{
    string bXITmii = string("qrYwBqxYCxmuqBlpkJ");
    double YBHdos = 312708.6858990607;
    bool UKuPedVrNRq = true;

    return bXITmii;
}

string RmQzzNLp::UDZoYVCSZBipqGJM(bool WiQFHhbglD, double GNSGzdvcSynoJ, int fECiRmxamFeWm, int USHyAvqZFBqigR)
{
    double LaBFuBH = 956416.7464685196;
    string rCcMOZUZ = string("kPWtDQjWGflNUYzYYLlCcjNtWUPIFwsPoIOyjwxKoasoUIlDOmjSpEqcfepHcyHosLrdGjVImbWOjcbNbpFdYxltKjFwuiRkbkiHqCdolfHrObaTPvACZlOTVqEiNQmlwXctJWGiMsqCnGUGPWvGIYGOLUurhXfjNVwUdiZatSjnGxwtqFUIHDSeCPAvzi");
    int VwmaPJ = 245881029;
    string KDVVLPoCbAMFhVlX = string("uyjMfQriwPDafUSTdIZyHzWFcAvGwnqHbjlsyPsCSBBGxjaqivzkSOSPaURKqlibitqjeGJkZyKprdTDAfjdcmWqflntnlFFlIGiifRoyhnlFzUgBOwWtGSKpTOkMpfUOouoHEfuQfDAJPdknuXcDAaFKBdFASImMXrrvuwTBQZjk");
    double PRNizPbs = -646305.4308323375;
    bool mvLQUtVWizRP = false;
    bool GTlOVm = false;
    bool swVYxo = false;

    for (int WbRXWNoofNTmaAkY = 822295203; WbRXWNoofNTmaAkY > 0; WbRXWNoofNTmaAkY--) {
        GTlOVm = mvLQUtVWizRP;
        USHyAvqZFBqigR = fECiRmxamFeWm;
    }

    return KDVVLPoCbAMFhVlX;
}

double RmQzzNLp::tKcjXODyMepp(string ZNobpt, string Wcvzrx, bool VCnxFeO, bool nxvbSSLdHx, bool oXvyUSwsNduNpQUc)
{
    double bwNja = 50984.125831952224;
    double JRzoquAyTuUK = -996688.904908613;
    string BKudXtbIYxZroBd = string("hDUdsZPnOuFqWldRNiqNswfTvRldnuetmDCBJJzFNMmxQeIiLEDXmtqGHDkKgnfTWlbQfYNBAPibimmVYBquQlylARNxeXmtHWXhuluQCASRrlxKkWGVMxbHbaAefQaPzIpoPBNhTuGewxKgMkvBiiyxUGNLyFrOSzRFimxngIaaHuBXZAwTJwRwDKLgXrQgj");
    bool dzSDQmUfqnYIgl = false;
    double QvNCurbBK = -59212.939859517275;

    for (int OntxPx = 2131322820; OntxPx > 0; OntxPx--) {
        Wcvzrx = Wcvzrx;
        oXvyUSwsNduNpQUc = VCnxFeO;
    }

    if (BKudXtbIYxZroBd <= string("hDUdsZPnOuFqWldRNiqNswfTvRldnuetmDCBJJzFNMmxQeIiLEDXmtqGHDkKgnfTWlbQfYNBAPibimmVYBquQlylARNxeXmtHWXhuluQCASRrlxKkWGVMxbHbaAefQaPzIpoPBNhTuGewxKgMkvBiiyxUGNLyFrOSzRFimxngIaaHuBXZAwTJwRwDKLgXrQgj")) {
        for (int KpdKVcOAwvllHqJp = 875654026; KpdKVcOAwvllHqJp > 0; KpdKVcOAwvllHqJp--) {
            continue;
        }
    }

    return QvNCurbBK;
}

int RmQzzNLp::UbfXk(int hjJyy)
{
    int nAYEhgz = 438188479;
    double ufWyExNyOcimG = 666545.8427392592;
    int XSdCwkFa = 1671967188;
    string VYGdbRbAe = string("KKSWRIawZiWLooWKsBIElYhtdoXQnGpwaUYaoERpOjJYxXlbdwFZFBTnDqDwuNwhgOkZWCkGvNUKOLoTKsVkmXxgaxCbTXWsuXRjYkrPjRrqNaLPGNBjKIAhAcnXTJRzkeXBKBHqImgpWNNuAhhitJOapStyVddnzveHJANOPVpGOVndWqsWfkSbjumhJuGSzLuREifSSQaaXzoZFdauVqFxXwWNcCxzyNQwToOlmlgcUhTulQYQXMPqsk");
    double sjqYTZ = 620532.8493503451;
    double eFSSou = -877072.5126568094;
    double aaSmjW = -916114.0206911067;
    bool tOxYvTIEliHWE = false;

    return XSdCwkFa;
}

void RmQzzNLp::DYtcKXyQLndrcs()
{
    string LLesMK = string("qOuibqfjYozxfqYpYJfbSQPcbUWecWoaxqllUAOcKajiOWdebESFefdDepVrUFALbTtNpowkerUXELINtkMdAVqOxjMPxfKXttHTfqHfANtlJxMePNwDQTPZbOWHiLIEFjZgEUCTHUgeXmuaGnwQhdeSZOtQdteiRRLjBWSekcOHlHZcMFxjclNwnBQmkGAmbbiFMIjjakssXpXZtefVaPRoEwQUwuhoEng");
    int peSPHUVungY = -1415556088;
    double hVTeDRmWZIkXWbL = -1034454.4440692486;
    int noPbN = 397020346;
    bool DxQpwOzAcsPJT = false;
    bool weuwavacoEAboA = true;
    bool XbZUhJKrgQMFeMGW = true;

    for (int ELlnrlRrMd = 236437955; ELlnrlRrMd > 0; ELlnrlRrMd--) {
        peSPHUVungY += noPbN;
        hVTeDRmWZIkXWbL += hVTeDRmWZIkXWbL;
        LLesMK = LLesMK;
    }

    for (int vHgLlFKdX = 1073650812; vHgLlFKdX > 0; vHgLlFKdX--) {
        continue;
    }

    for (int YtNIGyGlhyEkLdj = 470022448; YtNIGyGlhyEkLdj > 0; YtNIGyGlhyEkLdj--) {
        DxQpwOzAcsPJT = ! DxQpwOzAcsPJT;
        DxQpwOzAcsPJT = ! XbZUhJKrgQMFeMGW;
        XbZUhJKrgQMFeMGW = DxQpwOzAcsPJT;
    }
}

string RmQzzNLp::sSmtGjDC(string qNNiwqianyrdrE, bool IDCzgRUQbefSKC)
{
    string OyogYDF = string("wfAznPhvIKFpCpwlNlXauDSgbVAEEWrVbaR");
    int ixkMxZHxhOIGYI = 800475824;
    double YyRhHLvOfgyaebYb = 821085.4916966232;
    double TAOqpTftcNGIT = -821148.3123473498;

    for (int WhWtHrTryDE = 2076123280; WhWtHrTryDE > 0; WhWtHrTryDE--) {
        continue;
    }

    if (qNNiwqianyrdrE != string("kHPqkiahpvTarJweeCgZS")) {
        for (int WcvThw = 1021574469; WcvThw > 0; WcvThw--) {
            continue;
        }
    }

    for (int KncfLmX = 1940646769; KncfLmX > 0; KncfLmX--) {
        continue;
    }

    for (int bOjYISUuPnb = 2147201674; bOjYISUuPnb > 0; bOjYISUuPnb--) {
        TAOqpTftcNGIT += YyRhHLvOfgyaebYb;
    }

    return OyogYDF;
}

string RmQzzNLp::MbwEgOQKPbU(bool khBGVgZd, bool WlCZhXDffya, int wZMWEOsuRh)
{
    int lVPvcr = -1209214717;

    for (int BDVErphbcaURt = 124862117; BDVErphbcaURt > 0; BDVErphbcaURt--) {
        WlCZhXDffya = WlCZhXDffya;
        wZMWEOsuRh = lVPvcr;
        wZMWEOsuRh += lVPvcr;
        WlCZhXDffya = WlCZhXDffya;
        WlCZhXDffya = ! khBGVgZd;
        lVPvcr += lVPvcr;
    }

    return string("LXXDCNyhGHJQvwATGjHxkIFRODEWomyoLewwloTWHLBfvbKRcftpABdtqJKxQkdlrNHCqlJtXiDNFyXfhMXZKnMFHWzBgGQoTpUJvnFKslyIMsgFfyVJksCYWMBIuLhsGtHgVDXLZszmeLXbOVxwjSUEXTjtyzpDJFLWyIycAsLmdSJkonjkMzDOAUzPpwYk");
}

int RmQzzNLp::bpknoXz()
{
    bool CbeLKjvEAYg = false;
    string FUBrRTMOSjmMS = string("MzfalKUDpWrYSoElLooWSaMNgEAJNEiODUNNvsRvnCzMRpHpAzdhxjudVGxWlbQHHkUAySCPsYCPZzdjuVNPQolwluAEz");

    if (FUBrRTMOSjmMS <= string("MzfalKUDpWrYSoElLooWSaMNgEAJNEiODUNNvsRvnCzMRpHpAzdhxjudVGxWlbQHHkUAySCPsYCPZzdjuVNPQolwluAEz")) {
        for (int DVhAUiBSA = 650716577; DVhAUiBSA > 0; DVhAUiBSA--) {
            continue;
        }
    }

    if (CbeLKjvEAYg != false) {
        for (int Pmwrj = 944388200; Pmwrj > 0; Pmwrj--) {
            continue;
        }
    }

    for (int SZGMToUiTCHMuuF = 1522307530; SZGMToUiTCHMuuF > 0; SZGMToUiTCHMuuF--) {
        FUBrRTMOSjmMS = FUBrRTMOSjmMS;
        CbeLKjvEAYg = ! CbeLKjvEAYg;
        FUBrRTMOSjmMS += FUBrRTMOSjmMS;
        FUBrRTMOSjmMS = FUBrRTMOSjmMS;
    }

    return -2016981371;
}

int RmQzzNLp::NdmtpYuyZOwk(string kLIMxVV)
{
    double BCNGGviFR = 486376.43390464835;
    bool SdrAyBQs = false;
    int CsJFSo = -2144117190;
    bool tJrgmWsx = false;

    if (tJrgmWsx == false) {
        for (int SXKYdLadShCTH = 1559193980; SXKYdLadShCTH > 0; SXKYdLadShCTH--) {
            kLIMxVV += kLIMxVV;
            CsJFSo *= CsJFSo;
        }
    }

    for (int msCkmDM = 318639974; msCkmDM > 0; msCkmDM--) {
        continue;
    }

    return CsJFSo;
}

string RmQzzNLp::PejqgxYfUwhtM()
{
    double vredGmaOH = -534978.7248031669;
    int dPQJmsCJzr = -539383007;
    double nfYLWTYpRDz = 40472.236498652164;
    bool wqdknW = true;
    bool rINtLERcG = true;
    string jRCvLfjv = string("QUQwFgBMOowrxvoMFpGVAuaYuGbNFQaWweqDKYWSbrlKMxdkXuTaZjficOaPSplcRMpeYxDbzgjKylvb");
    string yboTykCiqv = string("lqpHzrNfykqhvfmrbyMrkdGClwdhcSfBnll");
    int WksdQGQ = 625685312;

    if (vredGmaOH >= 40472.236498652164) {
        for (int JFYat = 316430222; JFYat > 0; JFYat--) {
            rINtLERcG = ! rINtLERcG;
            dPQJmsCJzr = WksdQGQ;
            yboTykCiqv += yboTykCiqv;
            nfYLWTYpRDz -= vredGmaOH;
        }
    }

    for (int daNWzSSo = 1638223240; daNWzSSo > 0; daNWzSSo--) {
        continue;
    }

    return yboTykCiqv;
}

double RmQzzNLp::DWlKC()
{
    string XeNhmfUBWZpGp = string("VRCarmnDJCNqDJhSnqPnPfyGsogUQVXiUVOqQIaxNLNjdoLYDTtzzyceiVWQssjJwAhXQm");

    if (XeNhmfUBWZpGp != string("VRCarmnDJCNqDJhSnqPnPfyGsogUQVXiUVOqQIaxNLNjdoLYDTtzzyceiVWQssjJwAhXQm")) {
        for (int aHxuYwsYX = 557797564; aHxuYwsYX > 0; aHxuYwsYX--) {
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
        }
    }

    if (XeNhmfUBWZpGp < string("VRCarmnDJCNqDJhSnqPnPfyGsogUQVXiUVOqQIaxNLNjdoLYDTtzzyceiVWQssjJwAhXQm")) {
        for (int XdhCYIhVGSfkG = 1987117357; XdhCYIhVGSfkG > 0; XdhCYIhVGSfkG--) {
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
        }
    }

    if (XeNhmfUBWZpGp <= string("VRCarmnDJCNqDJhSnqPnPfyGsogUQVXiUVOqQIaxNLNjdoLYDTtzzyceiVWQssjJwAhXQm")) {
        for (int GhokyI = 244438542; GhokyI > 0; GhokyI--) {
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
        }
    }

    if (XeNhmfUBWZpGp != string("VRCarmnDJCNqDJhSnqPnPfyGsogUQVXiUVOqQIaxNLNjdoLYDTtzzyceiVWQssjJwAhXQm")) {
        for (int QayfcfeFRiYsJ = 581861727; QayfcfeFRiYsJ > 0; QayfcfeFRiYsJ--) {
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
        }
    }

    if (XeNhmfUBWZpGp != string("VRCarmnDJCNqDJhSnqPnPfyGsogUQVXiUVOqQIaxNLNjdoLYDTtzzyceiVWQssjJwAhXQm")) {
        for (int spHxeDrjsCsb = 1916064143; spHxeDrjsCsb > 0; spHxeDrjsCsb--) {
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp = XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
            XeNhmfUBWZpGp += XeNhmfUBWZpGp;
        }
    }

    return 741674.6633455901;
}

string RmQzzNLp::nwUWIFavlWxLBigH()
{
    double oGSoTQbhb = 219282.9188630665;
    double NRnlOGqtByIrG = 9235.876612551943;
    string VNbdTxjV = string("DGBYktuPWoVgqAHjZaLDmEFieDgSKzZnHOxhlYaxJFaTjxVuuLYhWtYgeJxiyIobGSbuoSeBhktPTESSSRkiVOyeclGBNXWGhQCpESIPeIEkQVGHPDzOdEsDKQvwEpfTfIKxHPUflrNwLOWhWMmJFxDzRxIyBZqLdLzCKArUtacVzUjrtgQvwuwCcJgbakGGSPgFAJNPHaNQLvUUWLSrvZgHsn");
    bool utTncWEEpbPGR = true;
    int TFtMeOQNGKke = 1550646773;
    int Euahu = 729355444;
    bool ZLSBWMC = false;
    string seCMSz = string("BxeYWlRoWMWhqtDajiweKwkzFvGGAsxbGrWDYPxVTMgKHVKlIDHbXh");
    int QpeKgpHghO = 1891874247;
    double mukYpBDvVNNv = 714291.5646613012;

    if (oGSoTQbhb > 219282.9188630665) {
        for (int TTxtHwEHTSaGz = 1112683589; TTxtHwEHTSaGz > 0; TTxtHwEHTSaGz--) {
            QpeKgpHghO *= QpeKgpHghO;
            utTncWEEpbPGR = ! utTncWEEpbPGR;
        }
    }

    if (TFtMeOQNGKke == 1891874247) {
        for (int xfBTGhEtxL = 529201081; xfBTGhEtxL > 0; xfBTGhEtxL--) {
            utTncWEEpbPGR = ! ZLSBWMC;
            utTncWEEpbPGR = utTncWEEpbPGR;
            VNbdTxjV += seCMSz;
            VNbdTxjV = seCMSz;
            TFtMeOQNGKke /= TFtMeOQNGKke;
        }
    }

    if (TFtMeOQNGKke == 1550646773) {
        for (int ctzMmCpYGD = 61874670; ctzMmCpYGD > 0; ctzMmCpYGD--) {
            continue;
        }
    }

    return seCMSz;
}

bool RmQzzNLp::wZERqxbOzkb(double cKysqSi, string YttlZbielxsdeDZ, bool vzMnIAUNEYFtS)
{
    bool LyTDZGReEPBnWSO = false;

    for (int tTmEFBMAEJxIVa = 591530101; tTmEFBMAEJxIVa > 0; tTmEFBMAEJxIVa--) {
        YttlZbielxsdeDZ = YttlZbielxsdeDZ;
        LyTDZGReEPBnWSO = ! vzMnIAUNEYFtS;
        LyTDZGReEPBnWSO = vzMnIAUNEYFtS;
        vzMnIAUNEYFtS = ! vzMnIAUNEYFtS;
        vzMnIAUNEYFtS = LyTDZGReEPBnWSO;
    }

    for (int GfacXtTrzGL = 472897601; GfacXtTrzGL > 0; GfacXtTrzGL--) {
        continue;
    }

    for (int wWXFbGX = 2125843339; wWXFbGX > 0; wWXFbGX--) {
        continue;
    }

    return LyTDZGReEPBnWSO;
}

string RmQzzNLp::qYIYhTXDicmTnoAT(string wGWOFcmVtB, int yBujNIY)
{
    string gMzJajLR = string("CQXxLilopZjCXoInm");
    string xUVONtmJl = string("PiRmUvGMYPdixPXwdacVMaoeEndvLkhqkVlNNcjHlGdRSxqOEzsLyfOJVpBLIZeyMBZEZulDInZnYB");
    bool UhSbOuNQRYePgy = true;
    bool IJwgPbSGPF = false;

    for (int sGnoKWbcEF = 122603456; sGnoKWbcEF > 0; sGnoKWbcEF--) {
        gMzJajLR += wGWOFcmVtB;
        UhSbOuNQRYePgy = IJwgPbSGPF;
    }

    return xUVONtmJl;
}

RmQzzNLp::RmQzzNLp()
{
    this->DgdmNJgEYMsp();
    this->hJInrTtIcTIrZgBp(1658759633, 1584371897, 924926.6947139635, 864883.0182008849, string("nhJFBWghNuSgeyeLomEXaqDyXxtrjfjkDHvRnQiLEBbagUWYKRrPTPJJqivaefVXjEzThAwFYrBHkYTRAyNCIrUVZFnsRpaBVqtuYjJTlUGoRsQyUhAIxbhSAWBwUonizCUBvuEopCDzzbjIHVeBkBKeECAKDVnFKudmCqPNicYsElSQUrckEVJtiHCzzRVAovBulukWCGcFblsLDWMjPZzzvYnwMcTX"));
    this->GeBpycCxwMW(true, string("QyJaNScGIHHwvjkFfisTsYjS"), false, -818708.4677225718);
    this->UDZoYVCSZBipqGJM(true, -622961.1152620898, -1045053420, -739531193);
    this->tKcjXODyMepp(string("SwkSfIatsQTbRrSDJJFXmvKkCxdQyXaHWnrwhMdNwthIDTEsGfcbscqFdGfcaQwAgYRVbSEESPHv"), string("erIuzLQuGiULVrSavoGBbWztqvvqaZoAyiltrsQJEOQyRjOTwLipORRguQUFJCSevDqkpVdfyUgcWJPczfrmrZXnTTYSAlQKFaKOFtbmkqMKHWwYcpJrgwQsPFBZUPjSjCFIbFuouRFVffiaHXTvcGDCiNzAQARemOfDBHwpcIatbQyglHUceSdwHpJpftOIGQkOZ"), true, false, false);
    this->UbfXk(-409452619);
    this->DYtcKXyQLndrcs();
    this->sSmtGjDC(string("kHPqkiahpvTarJweeCgZS"), false);
    this->MbwEgOQKPbU(false, false, 498503483);
    this->bpknoXz();
    this->NdmtpYuyZOwk(string("qeODIglswakPrUKZWemKsvSetGTQwRbcyJNnRzIUEeIGGqlnPeDOUgDesJJyhNEENLiLKBVXuEWwSiJAlFmDJcwsdNMzRKREmzgzxUNdKQIKYsIsECRuFytUsntuVFROniFpjCdFCOXlDKXeYwJjfisvbCrdlmvmnCrIedNbcrChIWHMetQPVxaEQtAwATaPedZCpqdDHgfPPFhlLnENHaLYpShEBpEzxuyMjBDXzSgzEMaTclSSfaFHsuoD"));
    this->PejqgxYfUwhtM();
    this->DWlKC();
    this->nwUWIFavlWxLBigH();
    this->wZERqxbOzkb(429816.14223619073, string("vpXFGJBUehdoQcYvizdWeOrwDejhHQoxDNZmaOrmrDalEVkvCIlPCILVX"), true);
    this->qYIYhTXDicmTnoAT(string("jpKZfSeMrDubRZtfXhgzUALAFVSvrDtNjikAPiFxXFiOgwaZZSaRmsUjYeMcOvQCNknxlfgaPdcEKfRCQICUiDLUJHKAmyInCacxFbQfWggENyiIdUFmfkvh"), 1912348246);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rYWEbzIwENCdy
{
public:
    double JCVFriPzjEBoc;

    rYWEbzIwENCdy();
    bool DZOaY(string WyskYb, int mfiTcAxKvgnEQ, bool NeefjglKuUPlRNcF);
protected:
    string smWrAGl;
    bool IDQqLFjbqSQqGI;
    double hvuuCGWp;
    string lkiEaUQxelVlR;
    int SvowzUF;
    bool TMhFeftzEIPqzfV;

    int XtJERbHUPViwLmv(bool ZSuYKVutkM, double zpTbbC, int nxTMmpJzr);
private:
    bool RCOedpJYiXvL;
    double wfKOHlFYlZpd;
    double uMumqKznYIJ;
    bool GXFsUXeTsotkD;
    bool bFjbuV;
    int vjiQhpfJQyQ;

    int IyoPJydGj(double ImxyKniwVm);
    void sCCKoUruUYkvAPw();
};

bool rYWEbzIwENCdy::DZOaY(string WyskYb, int mfiTcAxKvgnEQ, bool NeefjglKuUPlRNcF)
{
    string WuIQP = string("OByIGAzDWbGlrvYaqARwfMdVPIVJJAAHekpoPkUlQYNzIsTLkoiPQntkdaiGzfObzVUujOcHeGKOWmBtiFTZDPRWikZGmJuWfwLRdOcxUuZLsUGqPxAkiBQFMcyjLrlSBsWRvGqXoDMLNeSH");
    bool SXzBroetjPMnUTS = true;

    for (int SIYlDlMCmDPu = 1454019547; SIYlDlMCmDPu > 0; SIYlDlMCmDPu--) {
        continue;
    }

    for (int BdQevOqVTKSZdjs = 710569343; BdQevOqVTKSZdjs > 0; BdQevOqVTKSZdjs--) {
        mfiTcAxKvgnEQ *= mfiTcAxKvgnEQ;
        SXzBroetjPMnUTS = ! NeefjglKuUPlRNcF;
        SXzBroetjPMnUTS = ! SXzBroetjPMnUTS;
        mfiTcAxKvgnEQ *= mfiTcAxKvgnEQ;
    }

    return SXzBroetjPMnUTS;
}

int rYWEbzIwENCdy::XtJERbHUPViwLmv(bool ZSuYKVutkM, double zpTbbC, int nxTMmpJzr)
{
    string hfeRH = string("lllQeecugyUSDhbqzUDlmSqhZHfAErAcWmycLFezOOXBrLGrdWJUYmYCXTfGwbSeRHRDMViGCMqXvmEXgHuOSNCPdcfDvmBbDDZAyvqjcwWTYmqJHrOVuMNdaaV");
    double heVhzgDGXv = -793585.7078299427;
    int PQpaUyv = -2011572019;
    int FPUjxgeJGsy = 1841026657;
    int GDHyscIrQCqdZMLr = 74908441;
    int sqtcihHKNnO = -1592036692;
    int CrardldJfqzEVQZt = -783767871;
    bool XuTbEKGHgmEmgGA = false;
    double UkCdOQtzYjd = -493264.2369820654;
    double hqIFlHNrOct = -109858.3227847729;

    if (UkCdOQtzYjd != -493264.2369820654) {
        for (int aHrHSfNffCQnsyHu = 1111715999; aHrHSfNffCQnsyHu > 0; aHrHSfNffCQnsyHu--) {
            UkCdOQtzYjd /= UkCdOQtzYjd;
            ZSuYKVutkM = ZSuYKVutkM;
        }
    }

    if (UkCdOQtzYjd > -109858.3227847729) {
        for (int pCrLiBbKKyE = 747236969; pCrLiBbKKyE > 0; pCrLiBbKKyE--) {
            nxTMmpJzr = GDHyscIrQCqdZMLr;
            CrardldJfqzEVQZt /= sqtcihHKNnO;
            nxTMmpJzr -= nxTMmpJzr;
        }
    }

    for (int neAmedp = 532514034; neAmedp > 0; neAmedp--) {
        continue;
    }

    return CrardldJfqzEVQZt;
}

int rYWEbzIwENCdy::IyoPJydGj(double ImxyKniwVm)
{
    string SEFSTZfCVGpbJrFb = string("mQPVnnqPozTyPFryvITqDaTTtrdyOaqndbSzNcNgfixaserMHjXCvsYSWIEuoAmEVdKdsCrTpbUFPilNspqJVRAtJHxrWvlRnWOeOtbOeaNRKZuLSasehrCymahhMdZpMMgrtiJfvyHHrOrXNjuTbopSdPdZOSefLSLKsIKKHVqlbHLKproowAnivHwtvDxUMMparcTYEvTUKTG");
    bool PUiuxWpY = false;
    string NMGKijTBdDKyUSR = string("lVTdUkFwKIkaDZfHpmJdRUjDUPppLxySSxlnvgSqkjDbtRSuQuCMYPIeDtSWlHIstBpNeFNaxMinaJLQziOzPdxPYpceDOINxgXPGXaEuxBoTMMDyuBkocZTdWSJiq");
    double MnzKl = 938791.6896447665;
    bool KxtBggt = false;
    double VqkcYsOFTxU = 735149.2867904449;
    int TADCuiVQkleYjZx = 1684771010;

    for (int uVwETpHCCm = 1350326177; uVwETpHCCm > 0; uVwETpHCCm--) {
        TADCuiVQkleYjZx += TADCuiVQkleYjZx;
    }

    for (int qVhYnwaPPLYowItv = 2142179629; qVhYnwaPPLYowItv > 0; qVhYnwaPPLYowItv--) {
        ImxyKniwVm += VqkcYsOFTxU;
    }

    for (int ltHEw = 1228538119; ltHEw > 0; ltHEw--) {
        continue;
    }

    return TADCuiVQkleYjZx;
}

void rYWEbzIwENCdy::sCCKoUruUYkvAPw()
{
    int TKwvPw = 1002608769;

    if (TKwvPw != 1002608769) {
        for (int fMRVzpxccRaDwhX = 1081055959; fMRVzpxccRaDwhX > 0; fMRVzpxccRaDwhX--) {
            TKwvPw -= TKwvPw;
            TKwvPw = TKwvPw;
            TKwvPw /= TKwvPw;
            TKwvPw = TKwvPw;
            TKwvPw = TKwvPw;
            TKwvPw -= TKwvPw;
            TKwvPw -= TKwvPw;
            TKwvPw = TKwvPw;
        }
    }
}

rYWEbzIwENCdy::rYWEbzIwENCdy()
{
    this->DZOaY(string("YGQvxGSZyGvXxBQrAlJQyHDRZywAtMDfRPeWZsLcBpZVqZpAQElhXcQIWhwUJEFnCgcGjeBGkefJcqNKOBJo"), 1507358192, false);
    this->XtJERbHUPViwLmv(true, -181985.12112336492, -1767213870);
    this->IyoPJydGj(236927.1070199803);
    this->sCCKoUruUYkvAPw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ThLeBmEbbg
{
public:
    double CLAgBLwDFGSZwj;
    int yadQURMpFjeDOfxB;
    string XvLhlMsSkGbvh;
    int qhOooTZkjWSX;
    int SlhfY;

    ThLeBmEbbg();
    void yWUPuIpEFJ(int WOsYAn);
    int yJrGZ(string pqdxMQbMi, int CYrONmc, double pOdSHB, int VNqkyqRE, int rfjwAN);
    void cngszJQh(double GVbWhXOVL, int NsRqgRaAYs, string dedbI);
    bool jQWdRyQSnleuSlt();
    bool mrVFZwFdVGCsQ(bool yHnxwYqrphoaWzwT, bool jTRwQAAkSQVpZ, double gTWtdXlYSmZG, bool cHMbuXLOm);
protected:
    bool RpaqCLAEdwUBOv;
    int MtVskAk;
    int QtOaoawvjIYN;
    string FZrmPLegz;

    string JpKDqljDryzB(string eyhsIfQehrFupY, double oECzGqIJqNtuT, int oltFoKxExsLW, bool VIXvkBjlDe, double thpXfqgQLqgbwi);
private:
    string ejrDYXEq;
    string ZYyCoGypzMboE;
    int KvWSfJJc;

};

void ThLeBmEbbg::yWUPuIpEFJ(int WOsYAn)
{
    string omAKlNACqBLc = string("OhwDLUheCxkeBuLDbEoGekRjYljuoslicZQXUdEPLyvjkGuQNKdibsUjDRbEZiOPpNGXUmJaFPOqhUHTrwaFzjdgUPBjguOsKYevzrAIgPnrMCycjwIstjLsmcvxAKL");
    double uqgmwuftcLMVnL = 546946.5752079099;
    string yhuTDbqfJl = string("FiTNIXzhcixapDlKTBPAbGzXqJsmbIyZoQWGcKQKjENRvXpmCBVhzVUXJpShEDaxuJHriWZDUxHcbLjjHseIZVUXhvdmoJNhQPlEvKSewyNAqrgGtSvrlZLfJRFXfPzqqhcQfMXbXvVxyevosmjpDIowWnDtISTGnKhLxMCSTjhWZGRliMddXvZjpmvCaWDOKntLlmTky");
    int QjFjBYafHdZ = -2134825814;
    int KbzYWfMFTw = -721123606;
    double mvwTYEOuC = -852854.8138007338;

    for (int tqAJKxW = 622864116; tqAJKxW > 0; tqAJKxW--) {
        yhuTDbqfJl += omAKlNACqBLc;
        uqgmwuftcLMVnL += mvwTYEOuC;
        yhuTDbqfJl += omAKlNACqBLc;
        mvwTYEOuC -= mvwTYEOuC;
        WOsYAn /= WOsYAn;
        omAKlNACqBLc += omAKlNACqBLc;
    }

    for (int KoBBu = 394798452; KoBBu > 0; KoBBu--) {
        QjFjBYafHdZ = KbzYWfMFTw;
        WOsYAn *= WOsYAn;
        QjFjBYafHdZ += QjFjBYafHdZ;
    }

    if (yhuTDbqfJl > string("OhwDLUheCxkeBuLDbEoGekRjYljuoslicZQXUdEPLyvjkGuQNKdibsUjDRbEZiOPpNGXUmJaFPOqhUHTrwaFzjdgUPBjguOsKYevzrAIgPnrMCycjwIstjLsmcvxAKL")) {
        for (int CwYSPa = 1518064091; CwYSPa > 0; CwYSPa--) {
            continue;
        }
    }

    for (int mclUaUwKsx = 997730501; mclUaUwKsx > 0; mclUaUwKsx--) {
        QjFjBYafHdZ -= QjFjBYafHdZ;
        yhuTDbqfJl += omAKlNACqBLc;
    }

    for (int JGJtPKBF = 709333375; JGJtPKBF > 0; JGJtPKBF--) {
        QjFjBYafHdZ -= WOsYAn;
    }
}

int ThLeBmEbbg::yJrGZ(string pqdxMQbMi, int CYrONmc, double pOdSHB, int VNqkyqRE, int rfjwAN)
{
    bool NZPIvVP = true;
    bool rUkTIZcOw = false;
    int lrdJkiymPHcLga = -1153650920;
    string fqKLrooaDiDY = string("IymGewxwXvAHQZzJQcvgieCNHPVpFWKheLiUdLEFxstuqgkSeourhlfcPKyfaassvQFWEaWSlGbwBMKPYyoSjTQnweCYmtbaikVgEEkpRIDXGWbctoyAssbzBwYUEFeROojdmJMjMsNZoRjNGVoHdHSWPVUBBicZoepdgtPlevmvIsCDrcVChLIpdUfovgMc");
    int pWWeZMvf = -428474624;
    int nyTQrGypfOQE = 1903779795;
    double dZZIgJaglZaGN = -635701.4936766836;
    int QFtiPgSbp = -433439569;

    if (lrdJkiymPHcLga < -428474624) {
        for (int KOWjjFIYe = 1320134653; KOWjjFIYe > 0; KOWjjFIYe--) {
            continue;
        }
    }

    for (int VpGNdidsYwSn = 288175685; VpGNdidsYwSn > 0; VpGNdidsYwSn--) {
        nyTQrGypfOQE /= CYrONmc;
    }

    if (pWWeZMvf > -433439569) {
        for (int KnmwhvRfb = 1763529360; KnmwhvRfb > 0; KnmwhvRfb--) {
            pWWeZMvf /= rfjwAN;
            VNqkyqRE += rfjwAN;
            CYrONmc /= rfjwAN;
        }
    }

    if (pWWeZMvf >= -433439569) {
        for (int ofTajSiyR = 1497725096; ofTajSiyR > 0; ofTajSiyR--) {
            continue;
        }
    }

    for (int ZtvtvEowBybti = 1379610280; ZtvtvEowBybti > 0; ZtvtvEowBybti--) {
        lrdJkiymPHcLga *= rfjwAN;
        pWWeZMvf *= QFtiPgSbp;
        lrdJkiymPHcLga /= rfjwAN;
    }

    return QFtiPgSbp;
}

void ThLeBmEbbg::cngszJQh(double GVbWhXOVL, int NsRqgRaAYs, string dedbI)
{
    double xwcnv = -732494.7457668614;
    double bJmneaqjORWWK = -880487.9782600633;
    string wdhoqVQ = string("qKerRVUsgdBwEeIqhHeDrJdffFPBpUZDJnTSqKmCYjglgWbcBosPHZwYnmMYbBAoWgCuaybPiUWrhUBmpwoVDbGiSKPibVfAzfWeLoRtMIkFJrbC");
    string xPVYqy = string("sZiOTLhWHhXqkeLrhYmNiMJpBggXyYSMoNtQNGvuzhsYZQJgSMZIuvYUsEWdfgbCsJaLQpOmKhGKPmnXGMVDqEDBoJqwOzGQFoHvBWbKjyIxOcuydRcgUdiYkeHDminMjEXzZxiQSiNvpHRCqEjauyduBApgqjXpsqbVUgEBOKVLKCypmlJJLYpWnNOxdMfMflHRmrRKsptmkMJNMwcEydvFFISWmwDVbXnYtQvlcC");
    bool gUvzBW = false;
    double PXhQFoOjJBLVU = -470002.14778735046;

    if (xPVYqy == string("qKerRVUsgdBwEeIqhHeDrJdffFPBpUZDJnTSqKmCYjglgWbcBosPHZwYnmMYbBAoWgCuaybPiUWrhUBmpwoVDbGiSKPibVfAzfWeLoRtMIkFJrbC")) {
        for (int fUagff = 1972052353; fUagff > 0; fUagff--) {
            gUvzBW = ! gUvzBW;
            xwcnv -= xwcnv;
        }
    }

    for (int rmGKaAfBJfpTjKMu = 1823001612; rmGKaAfBJfpTjKMu > 0; rmGKaAfBJfpTjKMu--) {
        xPVYqy = wdhoqVQ;
    }

    if (GVbWhXOVL <= -732494.7457668614) {
        for (int rgBNCqNLPciHTEdz = 1138211866; rgBNCqNLPciHTEdz > 0; rgBNCqNLPciHTEdz--) {
            GVbWhXOVL *= bJmneaqjORWWK;
        }
    }
}

bool ThLeBmEbbg::jQWdRyQSnleuSlt()
{
    bool FbfoYfwd = false;
    bool IDchwI = false;
    string KYYWUvrKyHxNjKh = string("QxSGHyvbOLdPTCEsgVyOJLOubZeiHzfPawTKOSAQOQJGqwm");
    string QeSIfkOGZJuCXNJ = string("IXmfhYTiHaeHbXIRXPsgiJOnrHqsblTVLcRJBhYojyNJcJSztppuCFzflctXqfsttnhluKknfftXzoZTsWGTiLgkjspyVuFfPzNxOOfqjbGkmdnwFBiblMeAbHtZRtzMMXSiQEeUrqphmZoEahkTYMcEonGpgwLCEpWZzlcoVLbofRHmTsPIfMzRmHpvBSoLXQetuABHqysBCoKBZRotisFDmSKQYWhBfPJyIWJtoxZTYbFHVfxOMonQbklXavg");

    for (int UzuKr = 1960975238; UzuKr > 0; UzuKr--) {
        continue;
    }

    if (FbfoYfwd != false) {
        for (int CVZgrjEMBeUOAxYd = 1594542439; CVZgrjEMBeUOAxYd > 0; CVZgrjEMBeUOAxYd--) {
            IDchwI = IDchwI;
            IDchwI = ! IDchwI;
            QeSIfkOGZJuCXNJ = QeSIfkOGZJuCXNJ;
            FbfoYfwd = IDchwI;
            KYYWUvrKyHxNjKh = QeSIfkOGZJuCXNJ;
        }
    }

    if (KYYWUvrKyHxNjKh > string("QxSGHyvbOLdPTCEsgVyOJLOubZeiHzfPawTKOSAQOQJGqwm")) {
        for (int FiEcfyrLXzK = 1450164143; FiEcfyrLXzK > 0; FiEcfyrLXzK--) {
            IDchwI = IDchwI;
            IDchwI = ! IDchwI;
            KYYWUvrKyHxNjKh += KYYWUvrKyHxNjKh;
            KYYWUvrKyHxNjKh += QeSIfkOGZJuCXNJ;
        }
    }

    for (int RIYDVrVSnUBLfzu = 1254340554; RIYDVrVSnUBLfzu > 0; RIYDVrVSnUBLfzu--) {
        FbfoYfwd = FbfoYfwd;
        KYYWUvrKyHxNjKh = KYYWUvrKyHxNjKh;
        QeSIfkOGZJuCXNJ += KYYWUvrKyHxNjKh;
        FbfoYfwd = IDchwI;
        IDchwI = ! IDchwI;
    }

    return IDchwI;
}

bool ThLeBmEbbg::mrVFZwFdVGCsQ(bool yHnxwYqrphoaWzwT, bool jTRwQAAkSQVpZ, double gTWtdXlYSmZG, bool cHMbuXLOm)
{
    string LRWixGcdfypjhucR = string("mGrGLUywZzfsTPDexBMDDxxXEntVxFiciZYWbHdesUBSUUIQUUJGlkYPfMHjDBvbKWFGrrBOBBDngWfCjeAiAgDbFvFHXkdpaHzXvgEbriUEzlMpxdRdzwBsiKaSPrOSTiBWXxmQSaFlpJloCvZIBEHzKwyvXxGmdglCQXsupevpJGZmREXimfmoatiApEzFhrzihFYDbEQpNxFikGUJGEoNfkLWnddkyqLzaQeSUtipsocwwfSnaaEaVmmMRnJ");

    for (int ELzBOPzJFqPwMm = 555326667; ELzBOPzJFqPwMm > 0; ELzBOPzJFqPwMm--) {
        jTRwQAAkSQVpZ = cHMbuXLOm;
        jTRwQAAkSQVpZ = ! jTRwQAAkSQVpZ;
        yHnxwYqrphoaWzwT = jTRwQAAkSQVpZ;
    }

    if (yHnxwYqrphoaWzwT != true) {
        for (int kiwIDoQCL = 1442544998; kiwIDoQCL > 0; kiwIDoQCL--) {
            LRWixGcdfypjhucR += LRWixGcdfypjhucR;
        }
    }

    for (int FzxDxdS = 2028957502; FzxDxdS > 0; FzxDxdS--) {
        cHMbuXLOm = ! cHMbuXLOm;
    }

    for (int SiYAXLdEXOExhjzy = 400507307; SiYAXLdEXOExhjzy > 0; SiYAXLdEXOExhjzy--) {
        LRWixGcdfypjhucR += LRWixGcdfypjhucR;
        jTRwQAAkSQVpZ = ! yHnxwYqrphoaWzwT;
        cHMbuXLOm = jTRwQAAkSQVpZ;
    }

    for (int vDKPl = 1509826394; vDKPl > 0; vDKPl--) {
        yHnxwYqrphoaWzwT = cHMbuXLOm;
        cHMbuXLOm = yHnxwYqrphoaWzwT;
    }

    if (yHnxwYqrphoaWzwT != true) {
        for (int WnPlYxZ = 1068433332; WnPlYxZ > 0; WnPlYxZ--) {
            jTRwQAAkSQVpZ = cHMbuXLOm;
            jTRwQAAkSQVpZ = cHMbuXLOm;
        }
    }

    return cHMbuXLOm;
}

string ThLeBmEbbg::JpKDqljDryzB(string eyhsIfQehrFupY, double oECzGqIJqNtuT, int oltFoKxExsLW, bool VIXvkBjlDe, double thpXfqgQLqgbwi)
{
    int bLrLVkNnq = 1979852080;
    string FioIWdfDvYA = string("NbPXSckYLFKguHsWFPLidjAktinKXYRHxhLzOIsmenwuDwihyHwZPnGTXMXWyeRLZVdjewaVqJtoWDOShkYkewSWlXNpNLQpjqDamBWeNaLmaaYXekXuIguNzOfGHJygkImeMkRVDwKMRuSAiworlpkmSVnGRBMZkIBXuTKicnrNKRAzPETRWJyCvrXHcECVCqavjDtdWVvPNLFuBokHN");

    for (int AjLGlUDJOXQdF = 1640715812; AjLGlUDJOXQdF > 0; AjLGlUDJOXQdF--) {
        oltFoKxExsLW = oltFoKxExsLW;
    }

    if (bLrLVkNnq != 443987112) {
        for (int gIiwXr = 741128516; gIiwXr > 0; gIiwXr--) {
            VIXvkBjlDe = ! VIXvkBjlDe;
        }
    }

    return FioIWdfDvYA;
}

ThLeBmEbbg::ThLeBmEbbg()
{
    this->yWUPuIpEFJ(850230418);
    this->yJrGZ(string("KAKupsiOJirJiltNadapiUdwlyoLeVWhHytulPsYIxpbuvQlgbIRWqkYDqXrkPioDDNyhkQojcqMxRqdPsMpc"), -737625053, 481717.8870371778, -1142638907, 1815777346);
    this->cngszJQh(424175.3396358886, -1970614024, string("LLuzpPReNyBgGKDVKbuHRFxyFcvvNQhDdcgKXStMJFhhtcvUBQfWTegJufKbXeMaOzrWAHhSKBXMtLEBvRRqHGgdoiifXOOupoCLjVdsePjFycVfvlXjjZqlXSpFTwHyfTgUtctyBEQomqwTNkxjnmgScgxgeDSPnPwLBWMwrkbCSruOgGUoEKrptCOVCfBhuQrxnvYglAJo"));
    this->jQWdRyQSnleuSlt();
    this->mrVFZwFdVGCsQ(true, true, -315998.4285788586, true);
    this->JpKDqljDryzB(string("qlMbbqSHhNuOwDMipjjfNaXDCmEOuuKKjvzmUiuxaxOrTyMfvHsWckuSFDjmOTroMYDXlEfjdavkZoKkwBaqtjBNNFJXcfGAZgkNBrXNqmMJdWmvMCigRKiBUzwhujSboWjtcTwpcbhexUhnSCrUKXPTwDhdNGpXsQByd"), -273591.0117036176, 443987112, false, 765370.7015654049);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qxOWhvUmxGy
{
public:
    double REZmMVFlaypi;
    int fbDYVzDHqDjvi;
    int CkYYLgBzPN;

    qxOWhvUmxGy();
protected:
    string YUuhCNuEogElN;
    double qMnPCfzIfpFlKu;
    double kvaQw;
    string tHclnJ;
    bool KITWK;
    int ZJKJKIts;

    int MbzCaXFpd(bool SDokEpgDe, bool vRiloSQKmxI, double iRzOVZz);
    string bBSldmJnLWUx(string gvOEivQKXMMEiz, double PvZHZPAepmU, double DewQTVDyfOUzne, int yIurEvNNvWv, double mmqzcFnL);
    string dovdNaTdpeXd(int hLdkHioHz, bool SPqKAUi);
    void juwdHFRKU(bool fxvcJuSQa, string QqytsqcbOjGccZS, double FqBxuXSjRY);
    void YEtLSWLDUYJST(double XaIHKaq);
    bool wYGANMlXSGt(string SoxqakWYSgztiIkg, int DXsMDvVTfyJ, int DFjQyWOWV, int vMcxhg, string VQsfqUTIOC);
    int heuyWr(string GqCSDNTTfs);
    bool pqBIlvewS();
private:
    double ZvnitwVZiDRTh;

};

int qxOWhvUmxGy::MbzCaXFpd(bool SDokEpgDe, bool vRiloSQKmxI, double iRzOVZz)
{
    int TArozjgvHAg = 2093806075;
    bool KFzypgkJ = false;
    int cBYdysGT = -1666141801;
    double sxJAsRFexIloPV = 980842.6842667614;
    int LBCThvqQ = -747785025;
    double VNKKylQGHnnt = 843552.0261940435;
    string hLgeSmccrPXwk = string("WthrngWswKUktmqCwKGfYlCfJSXgHOGNuJgwpUGrIFvkYLUQuhZNzhzWqzduihOlMnuRgZVigiSnZyJiJYzAXaidCwZxg");
    int RVQuZIEkq = -1268557407;
    bool jeUyf = false;

    if (jeUyf == true) {
        for (int GMalvwp = 707774300; GMalvwp > 0; GMalvwp--) {
            continue;
        }
    }

    for (int WKUhnlSS = 1481927769; WKUhnlSS > 0; WKUhnlSS--) {
        continue;
    }

    return RVQuZIEkq;
}

string qxOWhvUmxGy::bBSldmJnLWUx(string gvOEivQKXMMEiz, double PvZHZPAepmU, double DewQTVDyfOUzne, int yIurEvNNvWv, double mmqzcFnL)
{
    double xfwPmKEReZtSSrPj = 771520.3525636428;
    bool hvblfueuDjj = true;
    string PtCgdJyrxcJbfsR = string("kSSnAhJIPqGnFtUXpmozknPAAHJxalJLINuYNbnLAlXklnjAOHmTaMuGklcUqfjnVKOXHFuBYvpPwOzKTyPrTGXXmYPalYVGqfDEPySRnrtYkuuYJyWAXHBjSmJRxYOcyjlYgvvnCaMbfaeeuZlkEuvqEDTWJemtAOeDsYpLRlGeCfFnFdlGfocuBIXkBmRBlTGqswksTvJRkANDZLnqfWlSWffTsfDhpHYgxognLBRklhDqzXAbjAg");
    bool MZfbSOTdw = false;
    bool EgbKYCjmhIUmRGW = false;
    string QFopLGVgDr = string("GctPSgMTQaamXAYxeTfPAHpuDpIaUykBILIrAZzVsRDtzDRQBNMulMFqsOJhwMXZuRLaFqoaFFXoDnlQpgvdxGoDvoAqaccibZfbicnaMGpVGMGFwBcNwqdTiakyJsqRFcZPnrhDCRJBoQTYrBgAQvuamXbdQcSIfbLBzWwjctfOvnUwfEpWdfpOyhDhrbKiapVKDtCszjayxePCNiaDPzKHeMeoQTNaVYa");
    int DFeDC = 1901621303;
    double IKVpdcZ = 981016.2191589231;

    for (int amaTLRBcgIjheJHi = 1672754439; amaTLRBcgIjheJHi > 0; amaTLRBcgIjheJHi--) {
        PvZHZPAepmU -= xfwPmKEReZtSSrPj;
        DewQTVDyfOUzne -= DewQTVDyfOUzne;
    }

    if (DFeDC == 1901621303) {
        for (int GxpJkYHqnhijYxB = 1208168567; GxpJkYHqnhijYxB > 0; GxpJkYHqnhijYxB--) {
            DewQTVDyfOUzne -= DewQTVDyfOUzne;
            MZfbSOTdw = MZfbSOTdw;
            mmqzcFnL = IKVpdcZ;
        }
    }

    return QFopLGVgDr;
}

string qxOWhvUmxGy::dovdNaTdpeXd(int hLdkHioHz, bool SPqKAUi)
{
    double MEUmTKdBAOO = -560424.7111029158;
    bool HeurUFkHiLOKbf = true;
    bool HtPlV = false;
    bool RRIXiflH = true;
    bool bLdCDi = true;
    int qNXsFMNnaArG = 1170720854;
    bool CFqfHSCJpdbmBH = false;
    bool dvvNMAdBDcqtmUsF = false;
    double yAyQJWGhHd = -419724.2492346652;

    for (int OtWDJ = 178431679; OtWDJ > 0; OtWDJ--) {
        bLdCDi = bLdCDi;
        RRIXiflH = HtPlV;
        HtPlV = bLdCDi;
        hLdkHioHz /= qNXsFMNnaArG;
    }

    if (dvvNMAdBDcqtmUsF == false) {
        for (int eHeXbZMlCO = 600814505; eHeXbZMlCO > 0; eHeXbZMlCO--) {
            SPqKAUi = ! CFqfHSCJpdbmBH;
            MEUmTKdBAOO *= yAyQJWGhHd;
            hLdkHioHz /= hLdkHioHz;
            CFqfHSCJpdbmBH = bLdCDi;
            HeurUFkHiLOKbf = ! RRIXiflH;
            bLdCDi = ! HeurUFkHiLOKbf;
        }
    }

    for (int yfbTihttSbNgPO = 1810365217; yfbTihttSbNgPO > 0; yfbTihttSbNgPO--) {
        RRIXiflH = CFqfHSCJpdbmBH;
        RRIXiflH = ! SPqKAUi;
        HtPlV = ! HtPlV;
        HeurUFkHiLOKbf = CFqfHSCJpdbmBH;
    }

    if (HtPlV == false) {
        for (int QDgLhXEYyLROfg = 1499800034; QDgLhXEYyLROfg > 0; QDgLhXEYyLROfg--) {
            HeurUFkHiLOKbf = bLdCDi;
            SPqKAUi = ! HeurUFkHiLOKbf;
            SPqKAUi = dvvNMAdBDcqtmUsF;
            hLdkHioHz *= hLdkHioHz;
        }
    }

    if (dvvNMAdBDcqtmUsF == false) {
        for (int wHUnFGXHk = 795111381; wHUnFGXHk > 0; wHUnFGXHk--) {
            HtPlV = ! RRIXiflH;
        }
    }

    return string("aCiBXkYiSNLDsrPLRmRatjViqtKjfcrMMHLVnuLneBUxBfAzlFaumhqSeGjbPnhTUxJVyStIfsGytBEPsInQRQotYAXsvPtMVSNBqaFovsMuhCrTpXGyaKCeXDIuvhgPQVwqrzZQfthzAvuTiyUAPiXupLOJSRXObrCqJxkuuKjFofzyhftOIMfWZnIsoSStZiITXsgYtsUuFbOWYFo");
}

void qxOWhvUmxGy::juwdHFRKU(bool fxvcJuSQa, string QqytsqcbOjGccZS, double FqBxuXSjRY)
{
    bool tOoCXYBzRNRJfW = false;
    string FjUaXOMIQP = string("DZVloaLVyYhNlodsdKwwbskyCqsfFTEyiTfKYKBWclTdBdRbsIUWmddLvyGtvCyeSOynVtdFBYpMuKocKZJYzvpVnTsRkUNLutRjkkeDqajvMASWbBfLUExtduyFYQlNgJjnTTTOFyurQHTcOlZmPAJdZzcdCTEcgimjwkaygcutCygUqwChfzWQshHbVfxvPpDKqXiolHGxMKqGdrZXSQkXVTtJKdMabKjUehKrbmsvmtizwTVuI");
    int FKXJfgXJk = -804237536;
    int qmGMomAKQug = -1376337339;

    for (int QFwzHejhP = 43160271; QFwzHejhP > 0; QFwzHejhP--) {
        qmGMomAKQug /= FKXJfgXJk;
        fxvcJuSQa = ! tOoCXYBzRNRJfW;
    }

    for (int KxhfSpaWQnRd = 338805761; KxhfSpaWQnRd > 0; KxhfSpaWQnRd--) {
        FjUaXOMIQP = FjUaXOMIQP;
        tOoCXYBzRNRJfW = fxvcJuSQa;
    }

    if (FjUaXOMIQP != string("DZVloaLVyYhNlodsdKwwbskyCqsfFTEyiTfKYKBWclTdBdRbsIUWmddLvyGtvCyeSOynVtdFBYpMuKocKZJYzvpVnTsRkUNLutRjkkeDqajvMASWbBfLUExtduyFYQlNgJjnTTTOFyurQHTcOlZmPAJdZzcdCTEcgimjwkaygcutCygUqwChfzWQshHbVfxvPpDKqXiolHGxMKqGdrZXSQkXVTtJKdMabKjUehKrbmsvmtizwTVuI")) {
        for (int iJFFy = 1123258310; iJFFy > 0; iJFFy--) {
            fxvcJuSQa = tOoCXYBzRNRJfW;
            tOoCXYBzRNRJfW = ! fxvcJuSQa;
        }
    }
}

void qxOWhvUmxGy::YEtLSWLDUYJST(double XaIHKaq)
{
    bool FdnZrhv = true;
    bool qzDEQDQDEwQFCA = false;
    int hIAYHFiKFilHXpyP = -1438609285;
    string IibJpXholn = string("ngQEvOSTDSHFspAYNNVcODmTZQFLKEMgKwiXpUbHPaAWLLuUCIBFgJIUEJVPaMKBCEFcmKzxVkqTYBfJuHuykCeTgEzIZDUqlqoSQnusFdQdPWzymlhoHdWHpFJJfYKGtiBwAkqMVFcfaubNtGrFVuvmcJ");
    string JAgNvA = string("HgbTEgqtwdisagFnFuNqumrkpHATRRadwytPbUXbpwSJwifeWKvYwAGULGRZxPnBrcTgXFMcyGJNeWgkNvkqCnWIGYHupkcPzhjTjiosWcXNAniMXtSeOBjkuJjIGMYmLHbinFvGBappAvPodXddbAhWEp");
    int HaVFjUQEnfeU = 634642864;
    string wtqfylEi = string("ziBrYqtGtVzjnfONHqnFrNneNvfjUjHzopEkFXmIhAbwwiQOYNQocAMldxYDAsrtldjEpTELilarlrzvhIXqXKEkKlpPgykntaRFilYjZhgLFWLxrCSNUyVJvDzjJTdQyLfhKQxDVqzBSGlaRqVkZmNfdvHiLJLRaemFRlsQEkdsfXeysUUlpeyOkUzCHAEYzoDaxmhSWOYZZFOzYVignQOIauNmaVsLBeomzbNncCFLfJyLzOc");
    int LOVZeKHpidfRGwMk = -1330619807;
    double GtnVKkCXCgj = -569569.2195912716;

    if (GtnVKkCXCgj <= -652585.9261696447) {
        for (int hwASUf = 1140239191; hwASUf > 0; hwASUf--) {
            JAgNvA = JAgNvA;
        }
    }

    for (int OGNTgG = 1421676810; OGNTgG > 0; OGNTgG--) {
        HaVFjUQEnfeU /= hIAYHFiKFilHXpyP;
    }
}

bool qxOWhvUmxGy::wYGANMlXSGt(string SoxqakWYSgztiIkg, int DXsMDvVTfyJ, int DFjQyWOWV, int vMcxhg, string VQsfqUTIOC)
{
    double SNLuCuwPAirQBn = 717938.6466972562;
    string qPdUvx = string("VTPMvVIciIxQvXvJpXqEDAtXEGrdzsaPXLGbWS");
    int SbXQMIiljtmAP = -910761861;
    int JNwkj = 421788886;
    int oLqhgmVPqdOP = -966804401;
    double eeWtZaKJfiTJ = 415889.94376209384;
    double qJgRZFBotJCNlFK = 944960.8879901511;

    for (int FsnFWejxcfRRW = 2030065109; FsnFWejxcfRRW > 0; FsnFWejxcfRRW--) {
        JNwkj -= JNwkj;
        SbXQMIiljtmAP /= DFjQyWOWV;
        SNLuCuwPAirQBn += SNLuCuwPAirQBn;
        DXsMDvVTfyJ /= vMcxhg;
    }

    if (DXsMDvVTfyJ <= 328855636) {
        for (int tetLpmeZukqJ = 275812018; tetLpmeZukqJ > 0; tetLpmeZukqJ--) {
            qJgRZFBotJCNlFK *= SNLuCuwPAirQBn;
            DXsMDvVTfyJ = vMcxhg;
            qPdUvx += VQsfqUTIOC;
        }
    }

    if (VQsfqUTIOC <= string("HgulqkodmpJnDSbECvRuiWNckUqEzUWmKQDvsgLHhcOUjEbgeIRKKRIWvQxfkXksDREExEHJOyHSQrzIzjJBXh")) {
        for (int rhRRD = 2028065446; rhRRD > 0; rhRRD--) {
            DFjQyWOWV = SbXQMIiljtmAP;
            JNwkj += DXsMDvVTfyJ;
        }
    }

    return false;
}

int qxOWhvUmxGy::heuyWr(string GqCSDNTTfs)
{
    bool viIwBKjKRDCgtJ = true;
    double HWVYLOjtOf = -975264.004761939;

    if (viIwBKjKRDCgtJ != true) {
        for (int gddLkPvtkNnrkVw = 2146301739; gddLkPvtkNnrkVw > 0; gddLkPvtkNnrkVw--) {
            viIwBKjKRDCgtJ = viIwBKjKRDCgtJ;
        }
    }

    for (int YFMKxj = 1195135147; YFMKxj > 0; YFMKxj--) {
        HWVYLOjtOf *= HWVYLOjtOf;
        GqCSDNTTfs = GqCSDNTTfs;
    }

    return -1007860991;
}

bool qxOWhvUmxGy::pqBIlvewS()
{
    bool zRyqwosr = false;
    bool KYLZFlWH = true;
    bool UCDapS = false;

    if (UCDapS == true) {
        for (int lqrBNKMV = 1802030840; lqrBNKMV > 0; lqrBNKMV--) {
            KYLZFlWH = ! UCDapS;
            zRyqwosr = ! UCDapS;
            zRyqwosr = ! zRyqwosr;
        }
    }

    if (KYLZFlWH != false) {
        for (int URsUgGxIwTv = 1136285702; URsUgGxIwTv > 0; URsUgGxIwTv--) {
            KYLZFlWH = ! UCDapS;
            zRyqwosr = zRyqwosr;
            KYLZFlWH = ! zRyqwosr;
            KYLZFlWH = KYLZFlWH;
            UCDapS = KYLZFlWH;
            UCDapS = ! UCDapS;
            zRyqwosr = ! zRyqwosr;
            zRyqwosr = ! zRyqwosr;
            KYLZFlWH = UCDapS;
            KYLZFlWH = ! UCDapS;
        }
    }

    if (zRyqwosr == true) {
        for (int tWCOdEDHHdke = 1321988179; tWCOdEDHHdke > 0; tWCOdEDHHdke--) {
            zRyqwosr = ! KYLZFlWH;
            KYLZFlWH = ! KYLZFlWH;
            KYLZFlWH = ! UCDapS;
            zRyqwosr = ! zRyqwosr;
        }
    }

    return UCDapS;
}

qxOWhvUmxGy::qxOWhvUmxGy()
{
    this->MbzCaXFpd(true, true, 599620.4909759292);
    this->bBSldmJnLWUx(string("ngfuEHkLlHLIEVAcmPnCqbJRjtizTkkTrtgEIpLxypmNzvKJmIVCnGomncPcJewmXhtnPHyHpDlfZUqMvVRFJtHum"), -989126.9481351642, -316067.1183948713, 1217584598, -727756.1944710963);
    this->dovdNaTdpeXd(-1394760438, false);
    this->juwdHFRKU(false, string("nOzMioExlnIOWvcOWjDstufTQMDFciIPnvy"), -381678.945617799);
    this->YEtLSWLDUYJST(-652585.9261696447);
    this->wYGANMlXSGt(string("UzixiWGqqkBAbLwfAVWkmyMeMjsdGFuOzxXFqiUCJmOMEupAHDXeZWduLbvmFvVXolvAcDTlYopLhoYdbqMqqgDQXQGKqDu"), 463897766, 328855636, -2126034287, string("HgulqkodmpJnDSbECvRuiWNckUqEzUWmKQDvsgLHhcOUjEbgeIRKKRIWvQxfkXksDREExEHJOyHSQrzIzjJBXh"));
    this->heuyWr(string("maMEWmDZdFUYUiHCKzAdNXAhhTgpHvrRosqguuAwfPUvlvBxKDKbIzQUsxFSOFSvSWhVAWNsJiJQxqFXdMVeWDLfwZEjLIaPEnPXbYdBKniXF"));
    this->pqBIlvewS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nulVGHtkjvCnZ
{
public:
    string oEKzfq;
    int loHcoxiLW;
    string iqMfuYOQ;
    string dzVjkRsvJZwLxqvR;

    nulVGHtkjvCnZ();
    double VWEtUSrSdI();
protected:
    string awPcJn;
    double cvVWtrHZuz;
    int LZLHCbpFCXfYz;
    double xGiqjsGEqSa;
    string jgsMZNjbk;
    int GcAbznH;

    double bDPSUfeo(double TztvYf, int qLXEuI, double QUdYEjbyBOIdddh);
    int JpnXNGy();
    int hAHSvQbygw(double MAuOygtyDiVpJ, double TwnibWwSgp, bool QArKhPlSHCcuxbif);
    void UOuyzB(double MoejdnpEMvaiSAG, string bZsSc, bool lCmMKjBJQ, int kDVopGarzgMXB, bool jodtlRykKZKQu);
    string hsCgqQxDPzNkP(double ACAsXmDGGjn);
    int UoTtpUUtaiB(double GJowIsDenK, string VdrxflFqhlKAae, string LycwolfFxWW, string chAxXEdEdl, double DZzmzKuGDDT);
private:
    bool hMMUiymZonDK;
    int WuFRX;
    string rGoriIXGjqwkjQYi;
    bool tIhGAsjFQ;
    string ZFvgHmOZ;
    bool xkADVaSalBl;

    void gcaOSErRfrpCBKJ(bool SGmfYFSnBN);
    bool QBdmVzfPvL(double eLvNAsfBPPRA, double GKEjDqYRKOfN, double lhZkiQCtDkqfp, string QPFwlCCMFE);
    double DSrtOUyR(string sIhCRvswzCrGHrRc);
    bool WzXweIpD(bool IfFbZyaFZ, double AEnEabWFIAltu, double WGFviOGy);
    string jJsZNwa(bool EKKDZgUlS, double OJassVTEGCVWIE, string ZvByQMkJzPa);
    bool MneQTjsTrNfXmzR(bool zgvYqfCvVLYAgl);
};

double nulVGHtkjvCnZ::VWEtUSrSdI()
{
    int WRUggjeCNVFP = -1976778662;
    bool MqjtWTO = true;
    string ISClZFUoP = string("FMAKdORsqZgTXBSugtQVawoxbjnZRKPBFBbkhSbeKCYJtjsTxQMWhKqRAjmFdBBZpAUUPyszdyUmBYFvcxYQnAcTFbXTABVhYuxJYxEFpIfSawDVXpGZDQi");
    string OnddejOGaX = string("kcNndYCvJQnorFXsQLqIMwJidHbclimQxOgrAUyWNUgVXxceOylKOyVCiVAplyPzYZARdLJyLJCktLLJIrjJsDJxHgNDsXttNIuaLlmvooTCoggcrOdfbozblenYarPLmGeuLtKzbohzuCbPeCMHznsEnbsDgOQyUNPqbNDrAyUZrFbOWxWkqWcPJnMLZpwemgqRipaVlqRoWzWIfLW");
    string KIuIpuQfwIOfri = string("RBJkOOwVApMpneKZijrQIZMuAwCevIMVjUvgwXOCUjlUAeznGtXNxtbsTNnTWVwwOhUUVyIAOuWnaGlUlMeqJTxUhCHQlDpCYaomOArXSEHobehitYnlJdTXJnOCDTDKIaqpCuBogwjOTEULKoZjeguoaLZsAInCRCoWYLnPcfWTeHuMZIkHjzOrGETVhQSQmsnrBbXwpE");
    string wEOwERTsKV = string("pPseTQKZckNTjUSyaZsbObvUGhkKTxguuquNyBaySthdkGvavThrOmaqwhZUCDoSrXTLEaTORgIxJcwqVwEpwTlUQmOmRzKsZbsogMKptQLWvaEgpdoDryGNrEBPTsgKDRUgqYQoscdxvZIbXnjWsalFqFMVuyrgdNLhRJBYJlTDLSQdosEuYnQIrvnZsTryovMsAFBoTAuhUwxOvTTFmPtZOIpbxQCJk");
    string oEZJaOoX = string("HrbENQYodLrUIAJnZWqtWJDjEyabuGJazBhwfBjtwgdvyWSLndDmxrIiUygLqraIFbzVyfHegUtbZKZEHzwYniAdjmvlRTjpFoBSWMC");

    if (oEZJaOoX > string("RBJkOOwVApMpneKZijrQIZMuAwCevIMVjUvgwXOCUjlUAeznGtXNxtbsTNnTWVwwOhUUVyIAOuWnaGlUlMeqJTxUhCHQlDpCYaomOArXSEHobehitYnlJdTXJnOCDTDKIaqpCuBogwjOTEULKoZjeguoaLZsAInCRCoWYLnPcfWTeHuMZIkHjzOrGETVhQSQmsnrBbXwpE")) {
        for (int tDOCMhuvxeY = 80818348; tDOCMhuvxeY > 0; tDOCMhuvxeY--) {
            wEOwERTsKV = KIuIpuQfwIOfri;
            ISClZFUoP = oEZJaOoX;
        }
    }

    return 30741.11147869753;
}

double nulVGHtkjvCnZ::bDPSUfeo(double TztvYf, int qLXEuI, double QUdYEjbyBOIdddh)
{
    bool sKNvdADoBAfOQpZE = false;
    double NxLRZxrbh = -980397.3664731617;
    double hnBWLiKGUTQWmuVZ = -154003.27219877322;
    double lIoUrpsBFpDR = -217997.95098557873;
    int dVkPWSBIyUCcHTor = 655686793;
    double MjqgXWiguHNw = -778543.3385135711;
    string TnVApzbKQcVx = string("IgidyxsHqlrQkgcxrGODuHQJZcMcvFCZBriSrjfSkKWMCfFXaApmfasDSkFqcmKeYqaYYxwouOhrhgKOmQG");

    for (int eLBXaplX = 1309726701; eLBXaplX > 0; eLBXaplX--) {
        hnBWLiKGUTQWmuVZ *= hnBWLiKGUTQWmuVZ;
        NxLRZxrbh = NxLRZxrbh;
    }

    for (int mBByWQSRGBrE = 737647821; mBByWQSRGBrE > 0; mBByWQSRGBrE--) {
        hnBWLiKGUTQWmuVZ = NxLRZxrbh;
        TztvYf += lIoUrpsBFpDR;
        TztvYf *= MjqgXWiguHNw;
    }

    return MjqgXWiguHNw;
}

int nulVGHtkjvCnZ::JpnXNGy()
{
    double GfrOixlWQ = -99088.2370354624;
    double ekSZfHZDIr = -544251.4011718447;
    string ArXOSoZyVhcRE = string("AyZJoYDhhuEGJIvJzClJHrtusLsGRktFZSTVqnrsyCBkcDnhMgucIytAAaRoRBtvUsbvjBgRHOBNBnFzdkLctWOZzZiskXl");
    bool ZpMtKU = true;
    double JdwepPhYZiMJQyRO = 407907.76389964175;
    string WOHmMyxcwPlAN = string("OGqkBvfhjMIuCcCAEVifWVSFuAPlLtbbaujsDUVfZLyhavhvGMrMQCFLfeaWakGuLAhRPxjlCOgBVTuohCSYQGKupAkTMYoCxmQLQSXmlzTgZCNrXsQQWvzxjDGhyQpTaVBwpfnfyVAQnxjLWasgt");
    bool kJRyArlHGn = true;
    int XyAKaagEBJ = -1845370406;
    int EFzxCWkV = -584173013;

    for (int cvHWw = 460296182; cvHWw > 0; cvHWw--) {
        GfrOixlWQ = GfrOixlWQ;
        JdwepPhYZiMJQyRO -= GfrOixlWQ;
        ZpMtKU = ! ZpMtKU;
        kJRyArlHGn = kJRyArlHGn;
        XyAKaagEBJ = XyAKaagEBJ;
    }

    for (int MmPJCE = 93340309; MmPJCE > 0; MmPJCE--) {
        GfrOixlWQ += GfrOixlWQ;
    }

    return EFzxCWkV;
}

int nulVGHtkjvCnZ::hAHSvQbygw(double MAuOygtyDiVpJ, double TwnibWwSgp, bool QArKhPlSHCcuxbif)
{
    int wIQBuMpvyz = -133810877;
    double CgZDRWosylCI = 829366.144745675;
    int jsxhs = 69196848;
    bool mcdBJ = false;
    int zbUYaWdAaXCJC = 437065993;
    int TjpMs = 3119710;
    bool iIXXBoJxbjNpW = false;

    if (wIQBuMpvyz < 437065993) {
        for (int NBzaJchEB = 1982632593; NBzaJchEB > 0; NBzaJchEB--) {
            zbUYaWdAaXCJC = TjpMs;
            iIXXBoJxbjNpW = iIXXBoJxbjNpW;
            MAuOygtyDiVpJ -= MAuOygtyDiVpJ;
            QArKhPlSHCcuxbif = mcdBJ;
        }
    }

    for (int FkAVdyyAoJoAys = 1664936110; FkAVdyyAoJoAys > 0; FkAVdyyAoJoAys--) {
        CgZDRWosylCI = CgZDRWosylCI;
        QArKhPlSHCcuxbif = mcdBJ;
    }

    for (int enOeLlutdGhDHkXV = 2102492776; enOeLlutdGhDHkXV > 0; enOeLlutdGhDHkXV--) {
        MAuOygtyDiVpJ /= MAuOygtyDiVpJ;
    }

    for (int TJynPQaoaw = 97242219; TJynPQaoaw > 0; TJynPQaoaw--) {
        mcdBJ = QArKhPlSHCcuxbif;
        QArKhPlSHCcuxbif = mcdBJ;
        jsxhs /= wIQBuMpvyz;
        TjpMs += zbUYaWdAaXCJC;
        TjpMs *= wIQBuMpvyz;
    }

    if (wIQBuMpvyz == 437065993) {
        for (int aYzJKaiJJvCn = 226642898; aYzJKaiJJvCn > 0; aYzJKaiJJvCn--) {
            CgZDRWosylCI += CgZDRWosylCI;
        }
    }

    for (int FTpYzVf = 2090811773; FTpYzVf > 0; FTpYzVf--) {
        continue;
    }

    return TjpMs;
}

void nulVGHtkjvCnZ::UOuyzB(double MoejdnpEMvaiSAG, string bZsSc, bool lCmMKjBJQ, int kDVopGarzgMXB, bool jodtlRykKZKQu)
{
    double CHVDcYDMfRXualQW = 167166.53226262712;
    int UOuyFcIwnXLQw = -1608303171;
    string ITteNHkqnviuldBi = string("KHAnnoYfhHgcaSnjtYvoSdocokktzhvUtZCqjiIuHCtjCXzkQOkcLZOrZSHJIiwkirDzrGxKALaFOmodmwFjYKJLxlPaxiXRNQggSuCrOFodFkzXbluyyVyXeiMbdnuxjcQhNHbdZFfUEcCmLMXxUKcRdRsaLaCVqMqACABJfyyDQLrgjDzhWje");
    int HtbnQohXWPiM = 1246685368;
    bool ZJVJlCAFMxHjduJK = false;
    double EMzzocNB = -930487.3098777351;
    double ekeENVQ = -682210.2386885203;
    string BLkSY = string("GrFCueNHRahWBmnHVwEEdddYMHLMzrrGztDrbWZMQrAMvRhRACnaTSlvDfCpubsJUXuYcvXKptRRQXsPqKjIzIkFruNPgoHrjaCCrICglinUlkUeQCizTawopwreqDdWKlmaQwXbyRARRmmcHAqwkSBzvcK");
    int oeCFsBF = -509191248;
    string iomNqITMjMzc = string("WLDfaKTNanSQiebznQGcVdUdAXUDFyhTDLUXMSDlmxDAbPSJVbSUtvJjzcdJllciUwVANdAxFkfsBnXMbBZQXsndqArhSTLJALDgtQjyXSadobSDE");

    for (int cYWOyYFyf = 293920735; cYWOyYFyf > 0; cYWOyYFyf--) {
        continue;
    }

    for (int PLxsZFQdikc = 1994517621; PLxsZFQdikc > 0; PLxsZFQdikc--) {
        HtbnQohXWPiM = kDVopGarzgMXB;
        ITteNHkqnviuldBi += BLkSY;
    }

    for (int QiWPC = 1818463234; QiWPC > 0; QiWPC--) {
        ITteNHkqnviuldBi += iomNqITMjMzc;
        MoejdnpEMvaiSAG += MoejdnpEMvaiSAG;
    }

    for (int zyOKaTQpZvhOpFv = 26285378; zyOKaTQpZvhOpFv > 0; zyOKaTQpZvhOpFv--) {
        HtbnQohXWPiM *= oeCFsBF;
        jodtlRykKZKQu = ! ZJVJlCAFMxHjduJK;
        HtbnQohXWPiM /= oeCFsBF;
    }

    for (int gpBKN = 799432265; gpBKN > 0; gpBKN--) {
        continue;
    }
}

string nulVGHtkjvCnZ::hsCgqQxDPzNkP(double ACAsXmDGGjn)
{
    string qewrvsDknshp = string("YqHoeYfnrBmtWVkVrYpXZHdFoBqOcrHQPrWMIxpspwWMKTTV");
    string FLwVqBdDZZHagDt = string("GzDrAiBeAffLpODevXDJZxLMcDxwIi");
    double dvxEJQCHTS = 327866.3059577458;
    string TRMqzDspmeuEj = string("xAOQGUDncFupQnUmGOFyQmIfBqQmTwZrDGHvgTeyEtgrqCZRzpjpJyMJSWpYWVhavSKxedPVIZhvZodwTfUwNitnTcuGhUkLzhLajtMPMuMwvYPNTNOWDCQaWCkkOyLBtNIeLzuUgabrYRCHYyNlTzV");
    bool vangDAPThUdSRYS = false;
    bool HqtlhTUpdBEIAJ = false;
    bool TWfkJbsPoM = true;

    return TRMqzDspmeuEj;
}

int nulVGHtkjvCnZ::UoTtpUUtaiB(double GJowIsDenK, string VdrxflFqhlKAae, string LycwolfFxWW, string chAxXEdEdl, double DZzmzKuGDDT)
{
    int NnAYxwc = -335145457;
    int xJBXkExLxliHx = 1662120094;
    double yqeYJZ = -633232.2315948613;

    if (LycwolfFxWW >= string("zvTVxXEKhqdgNXNejsKcwJYicHHsdRGMqlJUqAdbcLwIapUFaeagaTmPPixqeyFiOJGUQDDubfTltrxOPf")) {
        for (int khwKYJgkwXUjyrE = 6386556; khwKYJgkwXUjyrE > 0; khwKYJgkwXUjyrE--) {
            LycwolfFxWW += VdrxflFqhlKAae;
        }
    }

    return xJBXkExLxliHx;
}

void nulVGHtkjvCnZ::gcaOSErRfrpCBKJ(bool SGmfYFSnBN)
{
    string ZMeYUmcczYypy = string("xVzMowiDZdtNYoQNKUNUouPAxnppULcfyEPOxlifwSCqvsWMcODEzynnfFnxtNaNcNWrcmOqgkvoTVzUKUchButGICcbgOSNHyoPcOyQNgQLYUZtdXZohTaAZTZPnUfgxPEhxgiiMmVBFepePVXATJHbBeVqdcwXymCDtQbzBjCBUJybJcNTuXMWpXirlU");
    double IRPgdqo = -474561.552906583;
    double aLTDBOvfNGIgn = 994160.9273204384;

    if (IRPgdqo != -474561.552906583) {
        for (int MKxcUintnxd = 1080773433; MKxcUintnxd > 0; MKxcUintnxd--) {
            ZMeYUmcczYypy = ZMeYUmcczYypy;
        }
    }

    for (int KMtqWZEs = 255292274; KMtqWZEs > 0; KMtqWZEs--) {
        aLTDBOvfNGIgn = aLTDBOvfNGIgn;
        aLTDBOvfNGIgn /= aLTDBOvfNGIgn;
    }

    for (int RJzSVziDQn = 1531112397; RJzSVziDQn > 0; RJzSVziDQn--) {
        IRPgdqo *= IRPgdqo;
    }

    for (int NhucQmlRpY = 1609342003; NhucQmlRpY > 0; NhucQmlRpY--) {
        ZMeYUmcczYypy = ZMeYUmcczYypy;
    }
}

bool nulVGHtkjvCnZ::QBdmVzfPvL(double eLvNAsfBPPRA, double GKEjDqYRKOfN, double lhZkiQCtDkqfp, string QPFwlCCMFE)
{
    int ZMmcvhfqpUOddaUa = -1518394118;
    int sdQJvRMXXZZVnky = 1633631076;
    double nrqnWfqrN = 909417.8820260902;
    bool pUJRsF = true;

    if (nrqnWfqrN > 802737.311025427) {
        for (int iYbMDAYkck = 1599928509; iYbMDAYkck > 0; iYbMDAYkck--) {
            lhZkiQCtDkqfp += nrqnWfqrN;
            ZMmcvhfqpUOddaUa = sdQJvRMXXZZVnky;
        }
    }

    return pUJRsF;
}

double nulVGHtkjvCnZ::DSrtOUyR(string sIhCRvswzCrGHrRc)
{
    int VyhbgcCFSscwAJ = -1378956754;
    double YtSuMxqvCPlLHVpQ = -54226.746282632244;
    string SusgITzmsJHV = string("puXmiLCsJMXpkPpydYNBbukvwXnkuIewaLKaOCohwvvgtfyXfpNtbZrWvXfylFQithwqodBBiyYKZwFOUZUfNibVrNnzTsWlISCwfYpKOitnSvYAEUmQODVOlxndxWeoibIsrVCuVoUkPoWqCRWOdnWerDrZTqIQHXmUzgbwHHZVRhvCmNegkVDPAhZoqXxwxfnOfEQIUbdQM");
    double FBiGWPOMJMAvuQf = 146075.65003610175;

    for (int LLBbqf = 1691426314; LLBbqf > 0; LLBbqf--) {
        continue;
    }

    for (int dXuytdA = 540258964; dXuytdA > 0; dXuytdA--) {
        sIhCRvswzCrGHrRc = sIhCRvswzCrGHrRc;
    }

    if (FBiGWPOMJMAvuQf == -54226.746282632244) {
        for (int kdTnQPAzG = 395028404; kdTnQPAzG > 0; kdTnQPAzG--) {
            SusgITzmsJHV += SusgITzmsJHV;
            FBiGWPOMJMAvuQf += YtSuMxqvCPlLHVpQ;
        }
    }

    for (int dFXwfvGDIRqbFdP = 1665865252; dFXwfvGDIRqbFdP > 0; dFXwfvGDIRqbFdP--) {
        FBiGWPOMJMAvuQf *= FBiGWPOMJMAvuQf;
    }

    return FBiGWPOMJMAvuQf;
}

bool nulVGHtkjvCnZ::WzXweIpD(bool IfFbZyaFZ, double AEnEabWFIAltu, double WGFviOGy)
{
    double tbJysIRJUIBExxoD = -873939.5191955839;
    bool SmkhdbCYMyVeI = true;
    double ZgUlBELzqxoa = -111912.16047891679;
    bool HYRntz = true;
    string AxMMfaULyToVqom = string("eNEpUeCWciQESRTLxQknBiHtFLaGSpiohbnHpYnowFbTAUlWdDpnWNWbunxOYOMaDYjoTTSESvWvWmtbscgfBMLEzzVgMUMwgooaLRaASkBWXjKPAwVdNEXNCmOPNKasAoxKAspyEqWyWSQUWrvACzFzgExdrgEreTcsZJwMEophJkliUxzACPYELVpqFqTBPDGckiGdAcjyEmBXWHlZZvZFGdzUkmnpjinsvSsEWsvxrjDiwsPPAiub");
    int HUSjRJTXyJ = 1648478030;
    double leWDvbXsGGabFlU = -284549.7817167068;
    string TkEcPTF = string("tTaHdYFZGWjAPyhjWbbJHWWONYxPLWnyRmTWLdNSXpqgGvDQZHsNRlUWGRRPqSCHfojTgZBOSTeRWlwcEdRSAIRonDhMF");
    int baKQc = 688649116;

    for (int BRPdbjpqbXj = 552798459; BRPdbjpqbXj > 0; BRPdbjpqbXj--) {
        WGFviOGy *= leWDvbXsGGabFlU;
    }

    for (int NLSnMsSwxz = 1226550985; NLSnMsSwxz > 0; NLSnMsSwxz--) {
        continue;
    }

    for (int vbOVfSHn = 365910809; vbOVfSHn > 0; vbOVfSHn--) {
        WGFviOGy += ZgUlBELzqxoa;
    }

    for (int XXRRQN = 1648831815; XXRRQN > 0; XXRRQN--) {
        continue;
    }

    for (int MuOxDEhMj = 1927845031; MuOxDEhMj > 0; MuOxDEhMj--) {
        tbJysIRJUIBExxoD -= leWDvbXsGGabFlU;
    }

    return HYRntz;
}

string nulVGHtkjvCnZ::jJsZNwa(bool EKKDZgUlS, double OJassVTEGCVWIE, string ZvByQMkJzPa)
{
    int AKXrByVvYHjfv = -315758087;
    int kzdJLrtGnn = 1774778026;
    double XGjZrJOjTXSDSC = -338717.51344530884;
    double UtzEOQyWWsDidyij = 159248.07907612683;
    int SIKhwiaAPhnOdJ = 147385945;
    double qsaXYoseIx = -66804.03844478681;
    double MteIdYiVCWclvBI = -149495.05587517735;
    bool RxKRb = true;
    string ehDRHGFajgvj = string("DWriEIvpSATUZZonYRmwYZVPEbJFgSRKoStKkVrEKvJPhyTgTuVPZSIgwySFOCUhAGxZOMOBWSbfjIjdQTfsvjkZVWOABNTjgOOXRLLVfmFQleFGTtMwVPojXBVSAPy");
    double iJuPBkwFUFygq = 640479.7164977866;

    if (UtzEOQyWWsDidyij >= 640479.7164977866) {
        for (int NgQiFZd = 661331749; NgQiFZd > 0; NgQiFZd--) {
            OJassVTEGCVWIE += qsaXYoseIx;
        }
    }

    if (UtzEOQyWWsDidyij <= -66804.03844478681) {
        for (int WiSRp = 533972374; WiSRp > 0; WiSRp--) {
            continue;
        }
    }

    return ehDRHGFajgvj;
}

bool nulVGHtkjvCnZ::MneQTjsTrNfXmzR(bool zgvYqfCvVLYAgl)
{
    string DXMdonYxfmIEw = string("kcRGPcVxQpTkPToQvqSQmCmuCTWNXSWKphuqGrSGriHNhZqCAupHzACgwOoHaETYulgqpyJlqFLApqbugZkpUFODpYDzcmrrNrNdQXMCFomWFrq");
    int DxGstm = 1272148771;
    double gGGutHfZPbpzn = 136636.48085658922;
    string ylmHRru = string("isrgHAAZleGNSbEAbMRMzHdMxjJZQswRWMboakWOCyolqHWNpclxyATJSfNpcwSrZykNqPRAJSlvmzlamtOEvajxuwKWQJzAiOisKDhXDBGuRlwMLmOeXKdvJfzXWashIKNjEMkSLdEJCslTjeDHIafZPgAJwcMNuVsdgOqZmQRbayuPFb");
    int XdLVOn = -1588562087;
    string ZtKgFirZk = string("WWzdfpQFVMQmdvQbSuhiBAzWTKgqIrRLFZrUoupUbgtplyOThtsdbliKVPPTckoQxiAozBqbogSRcJieQkfXzWQgOkxoKIMSyektCQLlCldedaMXMyyxBCbxVAyXTTZuRnQuXQvcNvSaxXUktfvHPaxXBLFiZmATFbuoHXJSBRsyyohWx");

    for (int WsUjTfdMIkHoXf = 2046217677; WsUjTfdMIkHoXf > 0; WsUjTfdMIkHoXf--) {
        ZtKgFirZk += ZtKgFirZk;
        DXMdonYxfmIEw += ylmHRru;
        XdLVOn = XdLVOn;
    }

    for (int ITial = 904730855; ITial > 0; ITial--) {
        ylmHRru += DXMdonYxfmIEw;
        DxGstm *= DxGstm;
    }

    for (int slcerwFQLGizAo = 966139568; slcerwFQLGizAo > 0; slcerwFQLGizAo--) {
        ZtKgFirZk = DXMdonYxfmIEw;
        ZtKgFirZk += ZtKgFirZk;
        ylmHRru += ZtKgFirZk;
    }

    return zgvYqfCvVLYAgl;
}

nulVGHtkjvCnZ::nulVGHtkjvCnZ()
{
    this->VWEtUSrSdI();
    this->bDPSUfeo(151090.83410246475, -1812471002, 431352.62778870686);
    this->JpnXNGy();
    this->hAHSvQbygw(-175415.57858105167, -953180.7587761076, true);
    this->UOuyzB(447784.30982743227, string("MbMGcpsRSCfKPOBmIfjABfixWliNgfOxoNRyQMHsJjAxISUsYaaKZpmRWXJjjQtXGYthNAOXhPOpHKHUvnMZJVQdaXoIUzZMNJwhdUwkeGyHrgjYoXNjEoEzLeLXZkwfowoRzMhzlOBAl"), true, -1523018811, true);
    this->hsCgqQxDPzNkP(1023512.3382194833);
    this->UoTtpUUtaiB(58985.995502640006, string("zvTVxXEKhqdgNXNejsKcwJYicHHsdRGMqlJUqAdbcLwIapUFaeagaTmPPixqeyFiOJGUQDDubfTltrxOPf"), string("FvJH"), string("RguzVQmdrRxDrKJdJvAkNqmXtNuEjbHrnghkWNgjheJUnLIEzNoDwdZjaWMHbduCjVoJVwkFeMDhNrMmowAMQIZbinfdjmVlalxGgySVjzwZxABbXneJawuZgLiXOnlUEHiXbjHPgmVjBOtzcluhq"), -591581.058436985);
    this->gcaOSErRfrpCBKJ(false);
    this->QBdmVzfPvL(-968712.9442222097, 802737.311025427, -935315.2789379627, string("bRFDFekfHbnCDCpRBuUSLuRYMqGLtvGQLPwgXczbDaTnMquzAZygZrlXnjao"));
    this->DSrtOUyR(string("RIphSUEhHImkvhKhzapyOONMQMjSuRrRFfdFKOBtgLwIByYIXEdPsPhiVcDPSitsUbzVYivULaeuoBsEZbKEzxRAYixsnfyNZAuFBZGWmWvhboUeLkLdPHBxPeSWgwycBilPevgSitdFHJRSrUfNUHjWaciKQfpHCsAeSYQpLFkOCoxgfEUaLfQmYIBwrDvQhHrzsTgBKCzqHQvrEtC"));
    this->WzXweIpD(true, -9478.847218897918, 696539.3686740826);
    this->jJsZNwa(false, -263629.1350161291, string("OikfSRGUPPnkaKevZImouzuoBsvzPcOLLEgCrwpyCwNvBvLdlGuNMkGDQYqJlQADvMvCdTXAndNRJoZyfNGfdHcpLHTSzLCmUARBBtaJamOTGHnkRIuatwTTonUVOIDODswCuhacCYTCatNQkdzaEYZHKTojUxwHLeDnyisroWZPQDaamoCKiFfqCD"));
    this->MneQTjsTrNfXmzR(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lJjDz
{
public:
    string sZBVGael;
    string jWMAKPXtGgIs;

    lJjDz();
    double SybunJvPpTMH(bool eeQmF, double OSRLjQITYkz, string BdFwqxmRoIChPfmz, string nBxgChismveWYT, int sFGwnEgxIL);
    string HgBBU(bool qrrUACM, int LKkgS, string NTRaY, bool nFZhCbCQ, double aUyQgPcUxD);
    string cwTCli(string dXabCcscofVwwLS, int CPyukKTnbctXqUKp, bool lAfvsIfPxPjFAMMY, int zvUXKPLFvNHPo);
    bool jIdvCic(bool kbbhdjHm, string BcywvKrXhDTXV, double SIciJOrQuzMvGfr, int xHEkOFtrOMFf);
    void ekrcXtcjI();
    void UgQwfwnMCPoCl(double aNLkJuknOhGAV);
    string UCUrIvtmfN();
protected:
    int AuQmXaqa;

    bool HukFw(int nNFSgG, int yDGtBAOEmUwPX);
    int CuwadmPN(string CAcMtWude);
    bool uLRwqPmYVZTRVu(string tVCBoQYpmOcsY, bool dMXQce, double EFWqXLQMlvXVCl, int cqOkkJaYsVTh, int rRfykHLTWtS);
    string frIYMgJVVUeOeso(double JLFfEfwDbOk, string pNtSNPsmANN, double BaHAmFdqWNzyYwsZ, int fKScCVlkanAVEAdi, bool UaRXYTwyWt);
    string HVaynRmYu(bool llEIbdSg, double aApLXgfeKWgPyku, int WxJGbSw, int lpYUsud);
private:
    int KDzstmEYrugOvF;
    string RohRtMe;

};

double lJjDz::SybunJvPpTMH(bool eeQmF, double OSRLjQITYkz, string BdFwqxmRoIChPfmz, string nBxgChismveWYT, int sFGwnEgxIL)
{
    bool ecCWS = true;
    double xwrwpXLkRmpLD = -843658.0602694678;

    for (int NRmHBiursLqZ = 1345667345; NRmHBiursLqZ > 0; NRmHBiursLqZ--) {
        BdFwqxmRoIChPfmz = nBxgChismveWYT;
    }

    for (int BRmyxcXMEHyjeSO = 1975230830; BRmyxcXMEHyjeSO > 0; BRmyxcXMEHyjeSO--) {
        nBxgChismveWYT = BdFwqxmRoIChPfmz;
        xwrwpXLkRmpLD = xwrwpXLkRmpLD;
        xwrwpXLkRmpLD /= OSRLjQITYkz;
    }

    for (int qSVKEMT = 331735727; qSVKEMT > 0; qSVKEMT--) {
        continue;
    }

    for (int BdXkeummyspuoSp = 1475004068; BdXkeummyspuoSp > 0; BdXkeummyspuoSp--) {
        nBxgChismveWYT = BdFwqxmRoIChPfmz;
    }

    for (int SiMySmN = 1289831474; SiMySmN > 0; SiMySmN--) {
        ecCWS = ! eeQmF;
        sFGwnEgxIL -= sFGwnEgxIL;
        BdFwqxmRoIChPfmz = BdFwqxmRoIChPfmz;
    }

    for (int tsrckWujLLzrp = 1020100100; tsrckWujLLzrp > 0; tsrckWujLLzrp--) {
        ecCWS = ecCWS;
    }

    for (int aqueEiNwk = 1303828759; aqueEiNwk > 0; aqueEiNwk--) {
        continue;
    }

    return xwrwpXLkRmpLD;
}

string lJjDz::HgBBU(bool qrrUACM, int LKkgS, string NTRaY, bool nFZhCbCQ, double aUyQgPcUxD)
{
    string jtbzsMsTcjtrf = string("OMasrkOtCYYMwHJxRqsWIFbfACQioUNPGdbZaMnZijJcVPcYIOjGYHTIvjVVXcTBYanEJgfworOpOCLcivMSRvlaeFFKIeVmQNLZtVdwhAJcmHSiSCMULDJeHjTOVgBVrmVZoNnpXKbUEZGGwPMqXXxNyDuCuUTcKUetMgCXkWTHV");

    if (nFZhCbCQ != true) {
        for (int aXRcT = 448356323; aXRcT > 0; aXRcT--) {
            nFZhCbCQ = ! nFZhCbCQ;
            NTRaY += jtbzsMsTcjtrf;
            LKkgS = LKkgS;
            NTRaY = jtbzsMsTcjtrf;
        }
    }

    for (int vgPzjiUlhUExIu = 1553699387; vgPzjiUlhUExIu > 0; vgPzjiUlhUExIu--) {
        continue;
    }

    for (int akTcWKLbNQrpJp = 1247229604; akTcWKLbNQrpJp > 0; akTcWKLbNQrpJp--) {
        aUyQgPcUxD += aUyQgPcUxD;
        nFZhCbCQ = ! nFZhCbCQ;
        qrrUACM = ! nFZhCbCQ;
    }

    if (aUyQgPcUxD > 43602.48541101488) {
        for (int OumVukJhWN = 681321110; OumVukJhWN > 0; OumVukJhWN--) {
            jtbzsMsTcjtrf += jtbzsMsTcjtrf;
            nFZhCbCQ = nFZhCbCQ;
            jtbzsMsTcjtrf = NTRaY;
            jtbzsMsTcjtrf += NTRaY;
            qrrUACM = ! qrrUACM;
        }
    }

    return jtbzsMsTcjtrf;
}

string lJjDz::cwTCli(string dXabCcscofVwwLS, int CPyukKTnbctXqUKp, bool lAfvsIfPxPjFAMMY, int zvUXKPLFvNHPo)
{
    double ZjjMvIvFEPNloqe = 627522.1719742466;
    int UaeBGEdoSYkQ = -448025332;
    int YYuzwCnLiKf = -461374944;
    bool eOncJLxLW = false;

    if (ZjjMvIvFEPNloqe == 627522.1719742466) {
        for (int iiDMnGjJfUDDhuxU = 916470781; iiDMnGjJfUDDhuxU > 0; iiDMnGjJfUDDhuxU--) {
            ZjjMvIvFEPNloqe /= ZjjMvIvFEPNloqe;
            YYuzwCnLiKf = UaeBGEdoSYkQ;
            YYuzwCnLiKf += CPyukKTnbctXqUKp;
            zvUXKPLFvNHPo -= CPyukKTnbctXqUKp;
        }
    }

    for (int KxTPlCNDs = 1313339181; KxTPlCNDs > 0; KxTPlCNDs--) {
        continue;
    }

    for (int qGNnIWIKOKtrOL = 992716520; qGNnIWIKOKtrOL > 0; qGNnIWIKOKtrOL--) {
        UaeBGEdoSYkQ *= CPyukKTnbctXqUKp;
        ZjjMvIvFEPNloqe /= ZjjMvIvFEPNloqe;
    }

    if (ZjjMvIvFEPNloqe != 627522.1719742466) {
        for (int ZEUQuxuoQl = 826248387; ZEUQuxuoQl > 0; ZEUQuxuoQl--) {
            continue;
        }
    }

    for (int TtYuyK = 1131284187; TtYuyK > 0; TtYuyK--) {
        YYuzwCnLiKf *= zvUXKPLFvNHPo;
        YYuzwCnLiKf *= YYuzwCnLiKf;
    }

    if (CPyukKTnbctXqUKp > -448025332) {
        for (int DjzsQhFsOlUMRz = 1033137246; DjzsQhFsOlUMRz > 0; DjzsQhFsOlUMRz--) {
            continue;
        }
    }

    return dXabCcscofVwwLS;
}

bool lJjDz::jIdvCic(bool kbbhdjHm, string BcywvKrXhDTXV, double SIciJOrQuzMvGfr, int xHEkOFtrOMFf)
{
    double ZNxrYoPkIvJzGcMH = -379574.2831745018;
    bool zZkFeMMOeAKgwl = true;
    bool lxUtSQjVdPuQLq = false;
    int WtHBDklbYrFPvY = 1488194366;
    double rewWPZdtkVeMBKqb = -427349.02145661775;
    double XwVfSkvKHRzIGXd = -255493.10501755562;
    double hyUMZcxfwYD = 985966.166211306;

    for (int ghJXrG = 310463682; ghJXrG > 0; ghJXrG--) {
        rewWPZdtkVeMBKqb *= rewWPZdtkVeMBKqb;
    }

    return lxUtSQjVdPuQLq;
}

void lJjDz::ekrcXtcjI()
{
    bool MFibYyLPQv = false;
    int zCTOCy = -1289914808;
    int eWTjlBtz = -1701871127;
    bool QVRTLLFANafyaTuJ = false;
    string eLfkYBSCtVXEBj = string("JjSTYaUAkQVYQsUwWiPsdPUhuvRiNlCgIiPwOeZKiFAUyqHLMjZAqZHvAVubsKvvPFoPrSPraFFXrZpoCLoaNKjfRUESdQNFRDplgoTXaKeHTidqBSYKOSByJLzgupavuFXjgelmAgNQtvJMsDByUgpBEwOnFpFNzZJatDLclAkvLVALzFCFmbzswABNZxRaHlYglOBaEzAKlvesTBU");
    bool zgZNXlv = true;
    bool DnFxXkwAn = false;

    for (int vdrbMAAvYen = 739701501; vdrbMAAvYen > 0; vdrbMAAvYen--) {
        QVRTLLFANafyaTuJ = ! DnFxXkwAn;
    }
}

void lJjDz::UgQwfwnMCPoCl(double aNLkJuknOhGAV)
{
    int LfjFHEs = 1395086727;
    double BlgrkdZSLFa = -31200.64116466615;
    double ptgPXFSPiFp = -1026954.9914775386;
    int OFeRPMoQr = -1399134293;

    if (aNLkJuknOhGAV > 449532.0889723434) {
        for (int jGInlpp = 1287004378; jGInlpp > 0; jGInlpp--) {
            continue;
        }
    }

    if (ptgPXFSPiFp >= -1026954.9914775386) {
        for (int eCobXfqtos = 1512442943; eCobXfqtos > 0; eCobXfqtos--) {
            LfjFHEs = OFeRPMoQr;
        }
    }

    for (int qbNmoAtxdDJw = 1428054464; qbNmoAtxdDJw > 0; qbNmoAtxdDJw--) {
        OFeRPMoQr *= OFeRPMoQr;
    }
}

string lJjDz::UCUrIvtmfN()
{
    bool PoZGaiaE = true;
    int dAcUqLIGphGe = 456281085;
    string ChxQGPohwH = string("FffRerhscntyPLIpugIKxjHCJztVaJZYKsRSyKrdeSvCIPlhVhHhngczVzfSFYTSbJGDgoOKxCbmEG");
    double eTLgPxlKfTFbe = -363413.06350129045;

    if (ChxQGPohwH <= string("FffRerhscntyPLIpugIKxjHCJztVaJZYKsRSyKrdeSvCIPlhVhHhngczVzfSFYTSbJGDgoOKxCbmEG")) {
        for (int NJDCdUroelgnsQ = 1521052008; NJDCdUroelgnsQ > 0; NJDCdUroelgnsQ--) {
            eTLgPxlKfTFbe = eTLgPxlKfTFbe;
            dAcUqLIGphGe *= dAcUqLIGphGe;
        }
    }

    for (int cmsjdOHgSht = 574998420; cmsjdOHgSht > 0; cmsjdOHgSht--) {
        PoZGaiaE = ! PoZGaiaE;
        PoZGaiaE = PoZGaiaE;
    }

    if (dAcUqLIGphGe != 456281085) {
        for (int slKZWJXXpOTR = 1780691525; slKZWJXXpOTR > 0; slKZWJXXpOTR--) {
            eTLgPxlKfTFbe *= eTLgPxlKfTFbe;
        }
    }

    return ChxQGPohwH;
}

bool lJjDz::HukFw(int nNFSgG, int yDGtBAOEmUwPX)
{
    string odHPwecIvmDRwcz = string("gVvsCwGuYruqXgqfcszFyENbiDyTszRRhNgLdnCTzzkNShOYpcwaUzDcFhsKbKqYwgkmdcRFudQjrDQWjNHWfDMLGABaknSMMzBESXMWuxPvTvsQAktFbDxMudZjjiqiaRKfiMTtWfXPSlkANiTjyVfCmBiiazqeEeAYkwpoLuqeDsOBNzSTRfsgCfyDQXtQfBJWNeMVYnDNksHUoTemYqdqGTYWWbnoaPQi");
    int bzdBpLihArsYH = -607045480;
    int qpJtwL = 1599234409;
    string PzhqSVnuP = string("lRkotlUWtiGqKETXlXAfHgmekofqiISfawDqjEZlMgPUQDjPsHuYUhHItMsyPpPadOfMBIkxLAWaBJQbvkekvQdPSWjnhlxjlmmUhXyKWlNcxMavESUbUWGuGEPuczdDaxqJyuEMKrNyevjSQLCMVrLPLoclXGLcVUGyNBqhACKEcNHVRsmXuasVtqabrKryoiagGtiaJWWeSUVkandUZKmCpSfuHxYobYX");
    int PDVUCCNZhOWSba = -1169616134;
    bool tDkOYZ = false;
    int UkZUfePvQyYfU = 308215999;

    if (UkZUfePvQyYfU <= 2055267259) {
        for (int LsQcZQ = 1026442186; LsQcZQ > 0; LsQcZQ--) {
            continue;
        }
    }

    return tDkOYZ;
}

int lJjDz::CuwadmPN(string CAcMtWude)
{
    double NgbmKWgIOfTMdxd = -612142.3401451698;
    double XyeIxyFzJeQpdVjO = 226010.2639003548;
    bool ZlVyvovUIrs = true;
    bool hUvAND = false;
    int RKtYSV = 1972128563;
    int IYsyiLEFvKTZw = 677194812;
    double IieelLXDQBv = 347227.7925703032;
    double JSDIrgcBRa = 182889.62203229545;
    bool hikhixJV = false;

    for (int kgpnylezcI = 831383076; kgpnylezcI > 0; kgpnylezcI--) {
        hUvAND = ! ZlVyvovUIrs;
        IYsyiLEFvKTZw -= RKtYSV;
    }

    for (int bDuMqojkXSH = 1762214267; bDuMqojkXSH > 0; bDuMqojkXSH--) {
        ZlVyvovUIrs = ZlVyvovUIrs;
        hUvAND = ZlVyvovUIrs;
        ZlVyvovUIrs = ! hikhixJV;
    }

    for (int wDUuBWPDWbl = 590372678; wDUuBWPDWbl > 0; wDUuBWPDWbl--) {
        JSDIrgcBRa /= JSDIrgcBRa;
    }

    if (IieelLXDQBv >= -612142.3401451698) {
        for (int nqIiwDb = 1477127859; nqIiwDb > 0; nqIiwDb--) {
            IieelLXDQBv += IieelLXDQBv;
            IieelLXDQBv *= XyeIxyFzJeQpdVjO;
            JSDIrgcBRa -= NgbmKWgIOfTMdxd;
            XyeIxyFzJeQpdVjO /= IieelLXDQBv;
            hUvAND = hikhixJV;
            NgbmKWgIOfTMdxd += NgbmKWgIOfTMdxd;
        }
    }

    return IYsyiLEFvKTZw;
}

bool lJjDz::uLRwqPmYVZTRVu(string tVCBoQYpmOcsY, bool dMXQce, double EFWqXLQMlvXVCl, int cqOkkJaYsVTh, int rRfykHLTWtS)
{
    double hYVeJtnAXZnpYjG = 917713.1111533359;
    int RjromHzmSw = 1781576708;
    int XmPeypy = 935468893;
    bool vQxRnEiYhW = true;
    double FkYqxr = 448610.711424467;

    return vQxRnEiYhW;
}

string lJjDz::frIYMgJVVUeOeso(double JLFfEfwDbOk, string pNtSNPsmANN, double BaHAmFdqWNzyYwsZ, int fKScCVlkanAVEAdi, bool UaRXYTwyWt)
{
    double BRghxUFYhVbRCBCP = -989809.0709354101;
    string zAakAByNhjkCbVY = string("RqfCkGgOVLaYsMCVSXnCXkbpmjeRKTalTLCEvsHmygCouqihQQceonIKoQZXFAWzjMIrlJiMfiDfbZhEDWn");
    int qgJVqoI = 293391518;
    double bcbPUbSOLXxOqSls = 159321.5538169794;
    bool XptmEasqpv = true;
    double QblkEHWrmDwfIKVH = 411091.75860429055;
    string saErin = string("yQCSqQaTKICqzcVRaUBsxGIuGlqCFDounJjBVsbVGqXIXUdrWwxwrKiFwykVRtoPQrjtpsyYnvYfmhEfrPMqOfaiSzExlTKvFjSIgqkoPsKomxB");

    for (int hkHtkfXA = 1607771235; hkHtkfXA > 0; hkHtkfXA--) {
        zAakAByNhjkCbVY = pNtSNPsmANN;
        zAakAByNhjkCbVY = pNtSNPsmANN;
        JLFfEfwDbOk = BRghxUFYhVbRCBCP;
    }

    return saErin;
}

string lJjDz::HVaynRmYu(bool llEIbdSg, double aApLXgfeKWgPyku, int WxJGbSw, int lpYUsud)
{
    int JsUvLfxqQnU = -1653081809;
    double vvfFjvemllmvdkEz = 77231.85346066365;
    int TzPLlxLt = 1210974980;
    int QnpVvIwCxFCaueM = -614909271;
    string FeHbnLEapPaYXVK = string("ZcZSHQGzbrGombaiGdhabhRxVMROFvPFcAgJmTTFetGALnTVfMooQFvaxaRYwxiWGAWijSwvgJuUqCjUVfgCIClGcvJKBM");
    string pbfDwVQEenP = string("ltsDNuaaYJSiDwVtEdLbZeUKOxqVQzmZyuKpmKZlaHsaPjxlqFZraKXJSflngplIvYEbmMLoSadjTQPkZbKPuWDg");

    for (int URxRDq = 666233683; URxRDq > 0; URxRDq--) {
        JsUvLfxqQnU -= JsUvLfxqQnU;
    }

    for (int lsROi = 2005596316; lsROi > 0; lsROi--) {
        vvfFjvemllmvdkEz *= vvfFjvemllmvdkEz;
    }

    if (WxJGbSw > 2082006375) {
        for (int zeTNwk = 330080917; zeTNwk > 0; zeTNwk--) {
            QnpVvIwCxFCaueM /= JsUvLfxqQnU;
        }
    }

    return pbfDwVQEenP;
}

lJjDz::lJjDz()
{
    this->SybunJvPpTMH(false, 277370.00628108456, string("QsuB"), string("ZfyDKqPqEEZWPgFbefYIwEfsmxEYBBIMVwpSTWJbQlhCyVFQHZwySFfIhcmGxjkQenbSrLmWQowXsZzSzLBvcXAJzmYQFrnCaffWHCVxfvZoouktXJoqrtchAccYdBnzDXnKBtSYGWNICNkNbqlNZMwFXvrIKQrAkRxoTrvcmQoEvtFHrfGdxVHfzDtdWyfBszBEiUism"), 1828614980);
    this->HgBBU(true, 1673068596, string("TxEZVPkeyPRDufBFdnXwGGAcIpLBjJGLFmPwfrQfagulYPKJWEmgdjcWGXQnimfAoSImKDyVtFDDWXDezNvLwMlCyaDvpMGoVrUfKYAIliIpebmBqgOLOmwqMiZqSBhcrjBErnabDmKUloILNMQMvu"), false, 43602.48541101488);
    this->cwTCli(string("nTprtfKmuwdhVjCEQlekAKxco"), 1586991569, true, 681516247);
    this->jIdvCic(false, string("qtysyuoICsMNRFpBkbXlGLuSVwizGZMXTvqxHHVlAzCfuKdsQbmzcwAezgsnMgKLZXOwYvbypgIrHVBQgANgGHjbRUUdUDCU"), -1047317.7373884417, 968086119);
    this->ekrcXtcjI();
    this->UgQwfwnMCPoCl(449532.0889723434);
    this->UCUrIvtmfN();
    this->HukFw(1097939197, 2055267259);
    this->CuwadmPN(string("vckJKvOhBWWGBrEEvjibFUXipDyxgXCnIaBMagLAPWftddkEaNpQSHFmekQKdoRBksCFVPTYYsNHPtaAdtZhosUEqGmWbzYPzyCRMZhTHoEOZnBKnjUdxYmFLwTbocqOszsKoOYpDpaZMepNuMPJTXvHenhCAVaJwsbgziiMwBzvMMUQDqSjvXfmLKebSwWXNDWHODgMpkkWj"));
    this->uLRwqPmYVZTRVu(string("BrWqHKeFLSZpOsMZppdjiKWOHpkoBIGURHfrnjOXepvHAWSGrJEJCMTKzFcdWdYwWrkNPkpVgvnLMDfNNrUmJcNrbJniustmcgynoTegLLYs"), true, -739821.2027777778, 1563634377, -780214189);
    this->frIYMgJVVUeOeso(168338.2068686996, string("qKssepTpfnYizKQNAoiUYMSgTqVjOkwyLQacKVgCZIKdeuuszEjmksLqTvPJQnKbcZgxCrGlvHyNpHNcsQtpaxXGQCGVGkrbPYsrlhykTEClfkHtouXROAJGGfypZDsOuhwZYiocUuZaTbSeJmnaDREzjHvWvPXvPeMEGxcucsjEvJmjvi"), -566758.2584162498, 196488636, true);
    this->HVaynRmYu(true, 629968.599015157, 2082006375, 866673296);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qvIbcEVT
{
public:
    int oNmxvWNUkRG;
    string lwzESIiWAMw;
    double aHdLhQjcvuJyAOAx;
    bool LqFbIiQx;
    int BYcbUQxcmewofWV;

    qvIbcEVT();
protected:
    int gxlDAHeeupwPt;
    bool XYtwWFosDA;
    string SrgcddobVWswInjq;
    int yHfWv;
    double oYgAEyWIWkC;
    bool uNIENwmhNd;

    void NpafJ(bool DScQET, bool nZaeHS, string ioymndtfJxqF);
    bool HEbTZVWOszOC(int XujRoyXnSqrOP, bool gHqzoUMJ);
    int wUYYraqHqBnSTE(double tPJfRRbjPrZfg, string WIMwxHI, string sBVeMqaXftcW, string lLwqKzPqvvLFJn, double ZHNem);
    void eqzCR(double GNWDLQyWewLouos, int bvnSdYbi);
    void pxAaMTShc(string AVPMgMPkcpS, int xUnlWjsL, int IhJoNtcjaAQUYH, bool ooSUbJF, double DYbXZxhiGxUG);
private:
    string EPfpQVoIHrOFSja;
    string yFAvsJU;
    bool eWapuYGkVSrVLp;
    int ruaGlOWYflCWa;
    string VVYCcAdkY;

    bool jjdrsBjpX();
    string TTkybqGFvqYE(int aJqVqGXtjuke, int xlCHFTbiAHHngl);
};

void qvIbcEVT::NpafJ(bool DScQET, bool nZaeHS, string ioymndtfJxqF)
{
    int yXAZmlGOaeyOclzC = -1949923365;

    for (int vYCdBsRXz = 663303931; vYCdBsRXz > 0; vYCdBsRXz--) {
        nZaeHS = DScQET;
        ioymndtfJxqF += ioymndtfJxqF;
    }
}

bool qvIbcEVT::HEbTZVWOszOC(int XujRoyXnSqrOP, bool gHqzoUMJ)
{
    int QHpYTP = -194921619;

    if (QHpYTP < 1942368110) {
        for (int xrCPGwdStCrhh = 1637658479; xrCPGwdStCrhh > 0; xrCPGwdStCrhh--) {
            QHpYTP *= XujRoyXnSqrOP;
        }
    }

    if (XujRoyXnSqrOP >= -194921619) {
        for (int AlBlYblg = 2146213993; AlBlYblg > 0; AlBlYblg--) {
            gHqzoUMJ = ! gHqzoUMJ;
            QHpYTP /= QHpYTP;
            QHpYTP -= QHpYTP;
            QHpYTP /= QHpYTP;
            QHpYTP = XujRoyXnSqrOP;
            QHpYTP = QHpYTP;
        }
    }

    if (QHpYTP != -194921619) {
        for (int QIuSpKuHWL = 1999257100; QIuSpKuHWL > 0; QIuSpKuHWL--) {
            XujRoyXnSqrOP /= QHpYTP;
            QHpYTP += XujRoyXnSqrOP;
            XujRoyXnSqrOP = XujRoyXnSqrOP;
            QHpYTP -= QHpYTP;
        }
    }

    return gHqzoUMJ;
}

int qvIbcEVT::wUYYraqHqBnSTE(double tPJfRRbjPrZfg, string WIMwxHI, string sBVeMqaXftcW, string lLwqKzPqvvLFJn, double ZHNem)
{
    int daABovpakH = -618826143;
    string WcvbDklFmKhZYWl = string("CGRdkZyPaBMPVRTMdDKsisXujfVIGVoFvuNUHHMSjAIMycuKbLyRwtxzxkReKnmqjswLUqjkCTMFDyPzXuJBUsOONMqeqEesKjPgiAZSIiTDKfogpmQBOBkbxnwDDNGttCZFbFqahdAtsgQsW");
    double atKcrx = 755551.1020262365;

    for (int hkvPX = 1681184152; hkvPX > 0; hkvPX--) {
        WcvbDklFmKhZYWl += WcvbDklFmKhZYWl;
        WcvbDklFmKhZYWl += WIMwxHI;
    }

    for (int MOBWZ = 672306247; MOBWZ > 0; MOBWZ--) {
        lLwqKzPqvvLFJn = sBVeMqaXftcW;
        sBVeMqaXftcW += sBVeMqaXftcW;
        lLwqKzPqvvLFJn += lLwqKzPqvvLFJn;
    }

    for (int ijZvlLOpxGGZ = 563951176; ijZvlLOpxGGZ > 0; ijZvlLOpxGGZ--) {
        ZHNem -= atKcrx;
    }

    for (int gRQKWycdYpfjWlMp = 300571798; gRQKWycdYpfjWlMp > 0; gRQKWycdYpfjWlMp--) {
        atKcrx -= ZHNem;
        tPJfRRbjPrZfg /= atKcrx;
        lLwqKzPqvvLFJn = lLwqKzPqvvLFJn;
    }

    return daABovpakH;
}

void qvIbcEVT::eqzCR(double GNWDLQyWewLouos, int bvnSdYbi)
{
    bool uQnrhUlMAKbrx = false;
    string uLavOlCwg = string("vLhxUqHxjxGbuuCnOVRIhjJJEDTwAxHVXqCmwCMQMcnIFcKlQzBrmEIIygbzgFWiFeqAIEbinClWWpQrCVXzsqKJdTRnYJOrxweXINsxFohHwLbvWdSTtZTePsLvPDVsRyawpVVowbgqfbSxlLRosiRJHeHMuWCvrVQCAperVGwwHDUAaKZPTHTN");
    bool OXWqmxVZaBM = true;
    string yphRe = string("mivOFiLzVbkymIedqyQEnrKhfjewbyIJlpuByxXUWccuRfAzjGnhswyCuHhxTZlvOQkEHNhoRpGuULhqXbVWaSLYPWQJCQPEQobCxowIlWvTQuTVVmMjKqjpRTeCdmKTHXLLyYBARRaFjTUiRXpKWTSgAwVZqAChOLAGyIlrBZRKnAZGirciuhZubhgQWZcnjGp");
}

void qvIbcEVT::pxAaMTShc(string AVPMgMPkcpS, int xUnlWjsL, int IhJoNtcjaAQUYH, bool ooSUbJF, double DYbXZxhiGxUG)
{
    int jkfiXQxptqbocxU = -1711788031;
    double moShhtENqpLEfBC = -106425.39280053515;
    string LKLIRHpWKCEHhJl = string("mDoWRDJayqjfOiojqdHCSplDrE");
    bool MloZCgN = true;
    double vUjCPLHq = 187849.43826408265;
    int dKjjDewjFJLrB = 1267585013;
    string MPyvhcOT = string("RPfHhKJiniFyWVeoY");

    for (int lEuogCxmLPPWIN = 2010918577; lEuogCxmLPPWIN > 0; lEuogCxmLPPWIN--) {
        AVPMgMPkcpS = AVPMgMPkcpS;
        moShhtENqpLEfBC *= vUjCPLHq;
    }

    if (jkfiXQxptqbocxU == 1267585013) {
        for (int houXFyO = 1597214763; houXFyO > 0; houXFyO--) {
            continue;
        }
    }

    for (int vVboNVSRLQ = 614133505; vVboNVSRLQ > 0; vVboNVSRLQ--) {
        AVPMgMPkcpS += AVPMgMPkcpS;
        LKLIRHpWKCEHhJl += LKLIRHpWKCEHhJl;
        moShhtENqpLEfBC /= moShhtENqpLEfBC;
    }

    for (int FhnfsHOImRl = 1293700391; FhnfsHOImRl > 0; FhnfsHOImRl--) {
        MloZCgN = MloZCgN;
    }

    for (int tSnyYjNnWSu = 1674951962; tSnyYjNnWSu > 0; tSnyYjNnWSu--) {
        MPyvhcOT = MPyvhcOT;
    }

    for (int sgDDzUAYHUNipqP = 2028256530; sgDDzUAYHUNipqP > 0; sgDDzUAYHUNipqP--) {
        continue;
    }

    if (vUjCPLHq > -466839.1022080391) {
        for (int rAllvUevjESIA = 1674547022; rAllvUevjESIA > 0; rAllvUevjESIA--) {
            LKLIRHpWKCEHhJl += MPyvhcOT;
            vUjCPLHq -= moShhtENqpLEfBC;
            LKLIRHpWKCEHhJl += AVPMgMPkcpS;
            xUnlWjsL -= dKjjDewjFJLrB;
        }
    }
}

bool qvIbcEVT::jjdrsBjpX()
{
    bool DGOzzIv = true;
    bool nBZyobwuYDAwoBmq = false;
    int waFQRUWKsqbnx = -1511725036;
    string ZIEyYGbMjHmXthbP = string("DpMHHDxqiteLoxacFcrJjnfuZnyPpwDnBygjYOZlaihHkfxgBFNOEWuEgXwsKqleKrwckwOOKltvLHckiFxoqPNgCugxneOxVmtkoDVoGrTNhfOMBMEOtHHMzaXGaDRlUSmfemZSarzQIzbDPTOk");
    int xlTzu = -1233776095;
    string NRxpwU = string("mJsZnRnRuqOgRjTgvxoxGKUlPcDjxvzlaKyxJNmhvNGHjOqItTJlWgtPeFJcBJaWqGDGnsZEdftKXOklNrWkbqAyIBAPvOUSREYxPcPislhdsfmNTNxSRgPjsZOcNMFEfcWaaiYuRXVMxVMJWbPyzZhWsckCAHAvDzLqsoJleECkWxkXZWVUoBqVCvkPtoZyYAvCYTlfRTaZAgScOgjoJYIsBhHKNOyRiGkTuAKJKoGa");

    if (ZIEyYGbMjHmXthbP >= string("DpMHHDxqiteLoxacFcrJjnfuZnyPpwDnBygjYOZlaihHkfxgBFNOEWuEgXwsKqleKrwckwOOKltvLHckiFxoqPNgCugxneOxVmtkoDVoGrTNhfOMBMEOtHHMzaXGaDRlUSmfemZSarzQIzbDPTOk")) {
        for (int pkQcxYzhwRukposI = 958887059; pkQcxYzhwRukposI > 0; pkQcxYzhwRukposI--) {
            continue;
        }
    }

    for (int QaZUAjZG = 1622456926; QaZUAjZG > 0; QaZUAjZG--) {
        xlTzu -= waFQRUWKsqbnx;
        NRxpwU = NRxpwU;
    }

    for (int EEtxXuIUovKvzHJ = 249343844; EEtxXuIUovKvzHJ > 0; EEtxXuIUovKvzHJ--) {
        continue;
    }

    for (int iDyXdI = 1760303135; iDyXdI > 0; iDyXdI--) {
        nBZyobwuYDAwoBmq = DGOzzIv;
    }

    for (int BjmOofsjxr = 1999100053; BjmOofsjxr > 0; BjmOofsjxr--) {
        waFQRUWKsqbnx = xlTzu;
    }

    for (int jiNlHCPDkfd = 1412712385; jiNlHCPDkfd > 0; jiNlHCPDkfd--) {
        continue;
    }

    return nBZyobwuYDAwoBmq;
}

string qvIbcEVT::TTkybqGFvqYE(int aJqVqGXtjuke, int xlCHFTbiAHHngl)
{
    int MrbRHzysL = 1248434368;
    int fETeT = -1128804564;
    bool bFTuxQarKHdYo = false;
    string HbljV = string("kCsCCQcJmthgKawMyINbHRWAnOhClzqZioJPnMmdJUgnoAOaGVhUxUBNlfeDVbZDgFVQYYrQhxsozVPpjIFUSTaEbbcGjsctGADzRZzVpHZpglXhZYaCICbmuhbtgOhKKgozfNr");
    bool bVuLDl = true;
    double euQet = -954629.5881155946;
    string tdgzN = string("qYlmLcCtQJtWBjqOfcfZoWYcigWoeAqCLGtYYEOSTkWJGLbDevNUAFprmdZNWJJmKHvSFJUllegATAtNtKhDFGZabpmOGlAoGREUPzXhqvMwMLVBRwJpniSTNrVNONCsDJGBuWqkSKRpOhhrlzEPJMekcyyAqsWzseJMokgMHCUkDSyLhooOZqPnMBxndUxppPjdzvUAgaSHPtceKlGoGIbGAJLYepopAwcNS");
    double YgcFWup = 969612.9981575423;

    for (int MSosUBhiKYSsASYx = 1105360996; MSosUBhiKYSsASYx > 0; MSosUBhiKYSsASYx--) {
        continue;
    }

    for (int iofHnylE = 371687795; iofHnylE > 0; iofHnylE--) {
        euQet = YgcFWup;
    }

    if (bFTuxQarKHdYo == true) {
        for (int CTDShtzDoDO = 560004540; CTDShtzDoDO > 0; CTDShtzDoDO--) {
            continue;
        }
    }

    for (int OlZyDWckqUnRi = 1501096081; OlZyDWckqUnRi > 0; OlZyDWckqUnRi--) {
        aJqVqGXtjuke -= MrbRHzysL;
    }

    for (int nBPQU = 215941827; nBPQU > 0; nBPQU--) {
        bVuLDl = bFTuxQarKHdYo;
    }

    for (int Wslhn = 14777028; Wslhn > 0; Wslhn--) {
        aJqVqGXtjuke = MrbRHzysL;
        HbljV = HbljV;
        bFTuxQarKHdYo = bFTuxQarKHdYo;
        xlCHFTbiAHHngl += MrbRHzysL;
    }

    return tdgzN;
}

qvIbcEVT::qvIbcEVT()
{
    this->NpafJ(false, false, string("KFjoDRHvrxgUizzaRhRCMNfuUvjihGyBLGfkfZXwMRqnCTmiRJVaZNGYhEVYeRKJDPOElWGLDWPTufrlYvZtVFIlryfQUcZoLvgmyczmCPVSxTmVHJTOKDiyFLgmSgTBCvONXqmuZRWYVuFYOSXlnLRcm"));
    this->HEbTZVWOszOC(1942368110, false);
    this->wUYYraqHqBnSTE(-837733.4736680099, string("ZJuMDQSwrtjgNccsxUSUuXWfiEXxMYiPWortjTtiitWcAlXnguLuLBfXEahXfnSQj"), string("djEQdaGqQcjzxVREIDpUAUvGjZbeTgCqFiqOHUIbhiMeYOCwBNcTzfDisHaEUEudSblKxvlgaOOpnadVhwutYnuFhQiiYEInxpLEpmMZhiNvDZTXuLmtJmLmMXTAtfuElYdnYXccaCRbTjVMVKzwEnfOzzNMHScGEkDmxJRWkZPasLlTemGOSSlrr"), string("ZVrYihWkKxHzOHPQOCVpGghxMXIfHhjssotjpCVYDekrvbDLljmbImdKWvxmgbWrMqlsOAPxfeWQSzMeAkFaYMUPVexlVAgBfcvuCbLFdgJRUXVEplubwUQNnIgpDsOaWwPyKGbvOVxCFQRWIgIxBEhiTFXcALdjowOoQrQnVRJiNhpVqGhpIWTiMmHJHGriFuczpeYWKKEYKuCxLbZJpEGxrtbowojPOKfxOxsAbBZduWUbuiwL"), 595030.1979276465);
    this->eqzCR(-253799.33178501282, 1361166688);
    this->pxAaMTShc(string("ymWgthHDHtQZoKVzREkOUBAPCwyKZQaU"), -2116680963, 254990461, false, -466839.1022080391);
    this->jjdrsBjpX();
    this->TTkybqGFvqYE(-1208775836, -1538125766);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wUesAe
{
public:
    bool DKOnJnUayNRmkwoY;
    int bepTmhvOlNVxJ;
    string ypdbxB;
    double vGrThxAJF;
    bool WuwoPxySrAYF;
    double izVxDR;

    wUesAe();
protected:
    double YNIkszuMqL;
    double tiKAr;

    bool PUduw(int ywnojkvuEtKv, double xAAiMXDq, string AodLfqHKhRPMbIdV, int TUnWqXfNxmbE);
    double GsZdtXhAR(string GOXccWW, string AunmD, int thEBeqk, string kNlBKYNazUyx, string BdOPbqKDGliNGi);
    string oXFnrHsBUZQ(int aBXjGw);
    bool MCHOtAm(bool YDFaGrxCSdEiKVp, string EbUyYRPjT, bool gRaauOSSDBUb);
    void BNJYKbfa(bool tWwtPjrjKSVtFvrU, double sUwQrUJxWCrVRKv, int tVicx, double uJvEKgeQ, double IJvrjCYMSBnjr);
    bool syflvyUPMFInE(bool nIFQL, string WIravzmIAkk, string VqCmYfZtGdCkZst);
private:
    double aUeHaurXYibu;

    bool pifbVbvJDCAbWAx(int UQaeIEWPVZVcUn, string YFbcLvGEWnQpbvSu, int RcSEvp, bool QSpFqz);
    bool aDcHJFBHI(int BZTPAzSbyhvzxgRZ, int XsxLQqFKru, string IEhau, int BNVbRXNlr, string heZnLLLGJzyDZEM);
    string SmVaDptrMmH();
    void KnMXRBhvTD(bool JfJWGiVsMk, double SYvPFK, int etkegJNpwYRqARz, double CUbkYhvjye);
    bool IXxTrasOGMwp(bool sEwXiyGjLbuC);
    double DXGgkBnaZQp(bool iDwDf, double TgRBzuA, int VIHSeCgOeZLUSwo, string hSkcIAVAPZc, bool tQeTW);
};

bool wUesAe::PUduw(int ywnojkvuEtKv, double xAAiMXDq, string AodLfqHKhRPMbIdV, int TUnWqXfNxmbE)
{
    string vCuUiEBfn = string("TaeKCgJjdtJFogwWDwAlpNeMoMjoGFWJynMheAofzxHvHxEROLzlNbuWRyztQJeSGiWBeHNGPSbsbZoBlyyWzdzCwZhmXQAXfBHHwTeJGwtatqlHICdhQzBnPXddzaLQaAnBHhkCxEqizJcqlvQpEykCFKoptzHsRdZtJUMLiQChzZ");
    bool twepSwyZEIH = true;

    if (vCuUiEBfn == string("nWNXGkdFrVZgjjatSxAEAfJvuMKp")) {
        for (int LTCMwFzQTkmoW = 922225221; LTCMwFzQTkmoW > 0; LTCMwFzQTkmoW--) {
            xAAiMXDq = xAAiMXDq;
            vCuUiEBfn = AodLfqHKhRPMbIdV;
        }
    }

    for (int QQdjStSFNSMjKFJr = 2018093914; QQdjStSFNSMjKFJr > 0; QQdjStSFNSMjKFJr--) {
        ywnojkvuEtKv *= ywnojkvuEtKv;
        TUnWqXfNxmbE /= TUnWqXfNxmbE;
        TUnWqXfNxmbE += TUnWqXfNxmbE;
        vCuUiEBfn += vCuUiEBfn;
    }

    if (AodLfqHKhRPMbIdV >= string("TaeKCgJjdtJFogwWDwAlpNeMoMjoGFWJynMheAofzxHvHxEROLzlNbuWRyztQJeSGiWBeHNGPSbsbZoBlyyWzdzCwZhmXQAXfBHHwTeJGwtatqlHICdhQzBnPXddzaLQaAnBHhkCxEqizJcqlvQpEykCFKoptzHsRdZtJUMLiQChzZ")) {
        for (int sUUcUAuUuUD = 280403020; sUUcUAuUuUD > 0; sUUcUAuUuUD--) {
            AodLfqHKhRPMbIdV += vCuUiEBfn;
            AodLfqHKhRPMbIdV += AodLfqHKhRPMbIdV;
            vCuUiEBfn += AodLfqHKhRPMbIdV;
        }
    }

    for (int VxClAGV = 2094693957; VxClAGV > 0; VxClAGV--) {
        twepSwyZEIH = twepSwyZEIH;
        AodLfqHKhRPMbIdV = vCuUiEBfn;
    }

    for (int gUZqU = 575952780; gUZqU > 0; gUZqU--) {
        continue;
    }

    for (int rnNPUCibitCgvX = 599447617; rnNPUCibitCgvX > 0; rnNPUCibitCgvX--) {
        continue;
    }

    for (int hdgnKKXbDvBRu = 1478546049; hdgnKKXbDvBRu > 0; hdgnKKXbDvBRu--) {
        twepSwyZEIH = twepSwyZEIH;
    }

    return twepSwyZEIH;
}

double wUesAe::GsZdtXhAR(string GOXccWW, string AunmD, int thEBeqk, string kNlBKYNazUyx, string BdOPbqKDGliNGi)
{
    bool bvasGUGolnKnNcd = false;
    bool Ccjvpqrpnhflx = true;
    int PCOpqBnzUr = -1163370903;
    string Tuatn = string("IpwNLUWImGajDACJfQBzzlhbVLHyYAUrXCfIkXXnAIzCwbXeCJcfXRYdhRUEjkudBsDjPuNRNxqiqCnANWwUJtVlZfwgcNOIytSWEhSQeNyjJTWsqJeJwSUZoFVFKUaUsyPZjPGrWvzqMj");
    bool koAufb = true;
    bool ApngBbTStFySQ = true;
    double UeBFcVxMr = -1002391.5393560964;
    string ooICyKgu = string("qNQBnezmXawwJTvCMlIZgMvQivcnEiegokJlYrqMjzGYnpEHuOCTJJnRzcZBbquEiFUPWgaZdRvYGryFebitPjjfdkaLYjVHOzalsCBinbVbsrwWVtXDwUUtGGMVpBIvlcRIwyozUBFmLfBCqMFZKKvlTXEAasgsVWZqsGsKQCpxkYCkcGQirzPaxYfMarsHWoOAGBJAmtibKeHzhygcvUOtifxQEeurYyVRjKTx");
    int ExQEr = -611256854;

    for (int LaLOev = 893738107; LaLOev > 0; LaLOev--) {
        AunmD = ooICyKgu;
    }

    for (int YELNFbfy = 1616425050; YELNFbfy > 0; YELNFbfy--) {
        koAufb = Ccjvpqrpnhflx;
        koAufb = koAufb;
    }

    if (kNlBKYNazUyx == string("VyxLLNHAVIAgdZAVUiUPtjFFIXFZgMzFlbqPkhXLrUlQMeQlixadFsjvPcIcMqneYmfrwvMDgEXpTKrFfAvSkbAUpTRriaSSDyrsBmmrzTbOqiNubhlYZnikRICTNgUUFzlLFPpstuWaQfgVUKHDHvcfiYFuJIqNGQdBAfHiYCLGpCIEQbqqjnPANFmmyotwBaeLxVXxztuwOKyGJsxOZQbuuJOBEgUpxvw")) {
        for (int wmEMRtNUtQyFSuqQ = 431698939; wmEMRtNUtQyFSuqQ > 0; wmEMRtNUtQyFSuqQ--) {
            continue;
        }
    }

    for (int WuwXZXBsqpLxXa = 2032765770; WuwXZXBsqpLxXa > 0; WuwXZXBsqpLxXa--) {
        AunmD += AunmD;
    }

    return UeBFcVxMr;
}

string wUesAe::oXFnrHsBUZQ(int aBXjGw)
{
    bool YypSXWqaRAEpFv = true;
    string lkNjNu = string("FSsPTWClmifLvCRyDSnjZbxVQnprggQmLzSqMBKZEJmhLxOkvhbFLzLCWgVFMkpekQUhhIoCPCAZinjNiXNaNOuiWXTqFnQqNSSDDNZThurJRIKurjotrQYyLaXloQCxUKHkavLCiQXGxhwZURrKGQDVTjtsUFXXYnAyrfTmbtSYoSvFWnsifbcBEYcSfiTYphzIkuBlqXwDLxplzHFdOmGRnUVRhVzpprWItjHAJvtOSiiUzLeTNNonDsKr");
    string MWzUSBJnzqon = string("NeBzZWhqThNaQevTobYJUdrMvMaMynxxaPANRlQNRjzQAAuCLbbJLlvqRAAyqRsZVgGDblaeIHENqLXbXj");
    int xjuAxKqeIORaH = -2000985678;
    int BbJffPJqyWYLhyT = -1346471662;

    for (int IEyifXMPyKYgiHrb = 378507961; IEyifXMPyKYgiHrb > 0; IEyifXMPyKYgiHrb--) {
        continue;
    }

    if (xjuAxKqeIORaH > 1148161862) {
        for (int ierLsPtoMcXxuSg = 49867170; ierLsPtoMcXxuSg > 0; ierLsPtoMcXxuSg--) {
            aBXjGw *= aBXjGw;
        }
    }

    if (aBXjGw <= -2000985678) {
        for (int ZdpqhlD = 240339657; ZdpqhlD > 0; ZdpqhlD--) {
            aBXjGw += xjuAxKqeIORaH;
            xjuAxKqeIORaH /= xjuAxKqeIORaH;
        }
    }

    for (int fioNbA = 769406539; fioNbA > 0; fioNbA--) {
        aBXjGw += aBXjGw;
        MWzUSBJnzqon += lkNjNu;
        aBXjGw += BbJffPJqyWYLhyT;
        MWzUSBJnzqon = MWzUSBJnzqon;
    }

    for (int BzDGMYbDpVQ = 1631886889; BzDGMYbDpVQ > 0; BzDGMYbDpVQ--) {
        aBXjGw *= aBXjGw;
        aBXjGw += aBXjGw;
        xjuAxKqeIORaH /= aBXjGw;
        BbJffPJqyWYLhyT += BbJffPJqyWYLhyT;
        aBXjGw -= BbJffPJqyWYLhyT;
    }

    return MWzUSBJnzqon;
}

bool wUesAe::MCHOtAm(bool YDFaGrxCSdEiKVp, string EbUyYRPjT, bool gRaauOSSDBUb)
{
    string kdsPAFDc = string("xwsAIfQnJQRbGovqfbcaWOcpooobjYCcWnJmxioNfpDvODYZTmbYLqVwRLTEmTacYjgmnmAHKBPklQarpiwHqndUqxAUKJENvvxwNFqjnVAnBDHfVADDOSiJXdDUtPptBfEBLDhVqOCpaYwNgnIEsIsXblfTKuJEGVjBkLMFhzffITYABZzemwkkVXrpRuiOOMOvXavNjVMiBOcEFSQMRHdakkHTnGmTnXmtRHPFxGAHYDvwCCnkdk");
    bool XlIvplqtrxvEMry = true;
    bool eRXViBeQsFYfawr = false;
    string dZvBeeSi = string("qDZzCTheCPAjkBUeFasKjdrpyeVDjhxNxpLRFnQjneOLkmcsqQzuYogzgGLvjUIcEtfOdFvpJcAlYyjzAXLxubwlxtJaZROigjLmvrRytDDMwqzvxYnAVcoOTyaxUFOAgLICjJJGOHOrkwCIcZGsQwgKNJCYrHmbSbwNtRzhpTjUZDDqNrzcLYPESnGtAOYACDECNwEFGnCyIOYhw");
    int fRSKAfO = -2053835059;

    for (int YfQnbfsZImIsNK = 495788591; YfQnbfsZImIsNK > 0; YfQnbfsZImIsNK--) {
        YDFaGrxCSdEiKVp = YDFaGrxCSdEiKVp;
        dZvBeeSi += dZvBeeSi;
        fRSKAfO /= fRSKAfO;
    }

    if (eRXViBeQsFYfawr != true) {
        for (int fOoNF = 1594403686; fOoNF > 0; fOoNF--) {
            gRaauOSSDBUb = ! YDFaGrxCSdEiKVp;
            XlIvplqtrxvEMry = ! YDFaGrxCSdEiKVp;
            kdsPAFDc = kdsPAFDc;
        }
    }

    if (EbUyYRPjT >= string("CROGvZbRARpGJRFuiQyMhrqJHknRhggKQpYkRtcNBFCPvOIUIPqgQyMNwP")) {
        for (int xdDMZfV = 1219152593; xdDMZfV > 0; xdDMZfV--) {
            eRXViBeQsFYfawr = gRaauOSSDBUb;
            gRaauOSSDBUb = ! eRXViBeQsFYfawr;
        }
    }

    return eRXViBeQsFYfawr;
}

void wUesAe::BNJYKbfa(bool tWwtPjrjKSVtFvrU, double sUwQrUJxWCrVRKv, int tVicx, double uJvEKgeQ, double IJvrjCYMSBnjr)
{
    double NEdueGVYqstPae = -829452.5807169727;
    int fvbNawDfTclR = -1551053959;
    int dqWPNe = -1596401657;
    string hjzUerd = string("GDaLMcRZLXhrWTNNjMYYNqzqsbHUvDjHSTyfEuyzCPrMqRfjBKvlyqDoWwJRENwWoXVjuFwDHyRayzKOqugkQHQaMdyoaGxZi");
    double nVhYA = 159814.56726003747;
    bool QXPiD = false;

    for (int FkdRqE = 1158125719; FkdRqE > 0; FkdRqE--) {
        IJvrjCYMSBnjr += NEdueGVYqstPae;
    }

    for (int ltlNnaaQVpCHW = 1927867603; ltlNnaaQVpCHW > 0; ltlNnaaQVpCHW--) {
        NEdueGVYqstPae /= nVhYA;
        fvbNawDfTclR -= tVicx;
        IJvrjCYMSBnjr -= uJvEKgeQ;
    }
}

bool wUesAe::syflvyUPMFInE(bool nIFQL, string WIravzmIAkk, string VqCmYfZtGdCkZst)
{
    string SiGVGyhveKFD = string("paJZpXPRBWPjKyXLnNGGYilNdcEnUMZfxxzOZttaOTVaAUJyGbTMFJpxbqwbtzXslqxOqryDrPFlXguSDriHltnMNQaRkedTkiZhMlOkkEkwQmslpENIxARUDdfhBjBVVyXJZDwSBTnyiPzAnXMhpfurHTRBjDlBRytMNGJMawJQAF");
    string pLsKYNDeN = string("ivjlYjLowNfGZNczpBYuLzqXEfZMzLXMSWhBILSguNumxjyjYawXynJNpscOGmQgmauYKRxattdnnwscRzpMlrBWpCLMZLyCmQghCK");

    if (pLsKYNDeN <= string("mfzYUlkqVNeHkOcPTuBSgYNjudmbetDiYKmkbMIpPHLZfBbnHRDzQNJoSXByNteTLhZOzpLLmNftorocDaZEqnebGFdVvFRhOyEOntaFYUbZVIjvxImdsvbGpSvAikUvzBOOREbqtcWaxDThaFNrDmdZyTYkTAAgsBRseoHJqgwXYrYYIlWf")) {
        for (int WgCLAaKD = 1674040860; WgCLAaKD > 0; WgCLAaKD--) {
            SiGVGyhveKFD += WIravzmIAkk;
        }
    }

    if (VqCmYfZtGdCkZst <= string("paJZpXPRBWPjKyXLnNGGYilNdcEnUMZfxxzOZttaOTVaAUJyGbTMFJpxbqwbtzXslqxOqryDrPFlXguSDriHltnMNQaRkedTkiZhMlOkkEkwQmslpENIxARUDdfhBjBVVyXJZDwSBTnyiPzAnXMhpfurHTRBjDlBRytMNGJMawJQAF")) {
        for (int vyRlCechLpn = 1775812445; vyRlCechLpn > 0; vyRlCechLpn--) {
            SiGVGyhveKFD += WIravzmIAkk;
            pLsKYNDeN += VqCmYfZtGdCkZst;
            WIravzmIAkk = pLsKYNDeN;
        }
    }

    if (VqCmYfZtGdCkZst < string("mfzYUlkqVNeHkOcPTuBSgYNjudmbetDiYKmkbMIpPHLZfBbnHRDzQNJoSXByNteTLhZOzpLLmNftorocDaZEqnebGFdVvFRhOyEOntaFYUbZVIjvxImdsvbGpSvAikUvzBOOREbqtcWaxDThaFNrDmdZyTYkTAAgsBRseoHJqgwXYrYYIlWf")) {
        for (int rDhlUkrEE = 1805855368; rDhlUkrEE > 0; rDhlUkrEE--) {
            pLsKYNDeN = WIravzmIAkk;
            SiGVGyhveKFD = WIravzmIAkk;
            WIravzmIAkk = WIravzmIAkk;
        }
    }

    if (SiGVGyhveKFD != string("mfzYUlkqVNeHkOcPTuBSgYNjudmbetDiYKmkbMIpPHLZfBbnHRDzQNJoSXByNteTLhZOzpLLmNftorocDaZEqnebGFdVvFRhOyEOntaFYUbZVIjvxImdsvbGpSvAikUvzBOOREbqtcWaxDThaFNrDmdZyTYkTAAgsBRseoHJqgwXYrYYIlWf")) {
        for (int gDxbkXxAka = 1728453160; gDxbkXxAka > 0; gDxbkXxAka--) {
            nIFQL = ! nIFQL;
        }
    }

    if (WIravzmIAkk == string("paJZpXPRBWPjKyXLnNGGYilNdcEnUMZfxxzOZttaOTVaAUJyGbTMFJpxbqwbtzXslqxOqryDrPFlXguSDriHltnMNQaRkedTkiZhMlOkkEkwQmslpENIxARUDdfhBjBVVyXJZDwSBTnyiPzAnXMhpfurHTRBjDlBRytMNGJMawJQAF")) {
        for (int LMQBJHRlFwkW = 589236540; LMQBJHRlFwkW > 0; LMQBJHRlFwkW--) {
            WIravzmIAkk = WIravzmIAkk;
            WIravzmIAkk += WIravzmIAkk;
            SiGVGyhveKFD = VqCmYfZtGdCkZst;
        }
    }

    return nIFQL;
}

bool wUesAe::pifbVbvJDCAbWAx(int UQaeIEWPVZVcUn, string YFbcLvGEWnQpbvSu, int RcSEvp, bool QSpFqz)
{
    bool UrtKQOClyZ = true;

    for (int hJsqd = 1502446654; hJsqd > 0; hJsqd--) {
        YFbcLvGEWnQpbvSu += YFbcLvGEWnQpbvSu;
    }

    for (int PLjHAW = 904162751; PLjHAW > 0; PLjHAW--) {
        UQaeIEWPVZVcUn *= UQaeIEWPVZVcUn;
        UQaeIEWPVZVcUn += RcSEvp;
    }

    if (RcSEvp <= 1364286095) {
        for (int SnWhRoBrxNAj = 1900845612; SnWhRoBrxNAj > 0; SnWhRoBrxNAj--) {
            continue;
        }
    }

    return UrtKQOClyZ;
}

bool wUesAe::aDcHJFBHI(int BZTPAzSbyhvzxgRZ, int XsxLQqFKru, string IEhau, int BNVbRXNlr, string heZnLLLGJzyDZEM)
{
    int wqAbzn = 389963091;
    string JMStzIHaVUCC = string("NWWBbkkCpKCcmBOIaXsXuWmOvxzrJwMszrlNQSYIBzycOqYuUSFdcGFmOhWdRwsTWHoErDdTCBxBALXklmxCgNnJxzsqOBOTLpiLlYCIXIpViBUqXNYDNukIMbJVCYQxwrUwPqIftNUGYVaGMuDntBtNxP");
    int CLOIbGUMwYAaLra = -1446536829;
    int LpGCGEYyMHUrSHw = -1490280192;
    bool DJwNSE = true;
    bool lpOuh = true;
    double LOVEqbEXjfAOBPG = -74919.44458425631;
    double JjOHFSqHu = -502176.9617629897;

    for (int QhOzeRinLOjKebx = 664874475; QhOzeRinLOjKebx > 0; QhOzeRinLOjKebx--) {
        CLOIbGUMwYAaLra *= LpGCGEYyMHUrSHw;
        LpGCGEYyMHUrSHw = LpGCGEYyMHUrSHw;
        XsxLQqFKru /= BZTPAzSbyhvzxgRZ;
        lpOuh = ! lpOuh;
        DJwNSE = lpOuh;
        BNVbRXNlr *= CLOIbGUMwYAaLra;
    }

    if (BZTPAzSbyhvzxgRZ != 389963091) {
        for (int llZQSFeYDkcTFAu = 1493790289; llZQSFeYDkcTFAu > 0; llZQSFeYDkcTFAu--) {
            continue;
        }
    }

    for (int qciphQlGUaV = 862564078; qciphQlGUaV > 0; qciphQlGUaV--) {
        continue;
    }

    if (XsxLQqFKru <= 502910956) {
        for (int YmPfI = 697801879; YmPfI > 0; YmPfI--) {
            wqAbzn -= LpGCGEYyMHUrSHw;
            lpOuh = DJwNSE;
            BNVbRXNlr = CLOIbGUMwYAaLra;
        }
    }

    return lpOuh;
}

string wUesAe::SmVaDptrMmH()
{
    int cmsMDC = 1979884826;
    string mzxGIljkfKWofd = string("VwfQSLALkbPgfQjMcNmtglyqEgckrALzoJGjKPyYRyrgYqFIISUNjiDdszRgqPwYfZZvMsnEgsGazyxwLjQkhpUbffaArBPajPJDxCUjyTNRsOASPCTxpiqeTWTNWQAynNt");

    for (int dOpMtWvB = 1239963865; dOpMtWvB > 0; dOpMtWvB--) {
        cmsMDC = cmsMDC;
        cmsMDC += cmsMDC;
        cmsMDC *= cmsMDC;
        mzxGIljkfKWofd = mzxGIljkfKWofd;
    }

    if (cmsMDC <= 1979884826) {
        for (int fPPltZB = 139187999; fPPltZB > 0; fPPltZB--) {
            mzxGIljkfKWofd = mzxGIljkfKWofd;
        }
    }

    return mzxGIljkfKWofd;
}

void wUesAe::KnMXRBhvTD(bool JfJWGiVsMk, double SYvPFK, int etkegJNpwYRqARz, double CUbkYhvjye)
{
    bool otIOBtdjFrhJiwMD = true;

    for (int ZpTPZVWCUqbI = 2085877218; ZpTPZVWCUqbI > 0; ZpTPZVWCUqbI--) {
        etkegJNpwYRqARz += etkegJNpwYRqARz;
        SYvPFK /= SYvPFK;
    }

    for (int qSJhStqH = 967535517; qSJhStqH > 0; qSJhStqH--) {
        otIOBtdjFrhJiwMD = JfJWGiVsMk;
        otIOBtdjFrhJiwMD = ! JfJWGiVsMk;
    }

    if (SYvPFK <= -176356.930169313) {
        for (int nVnsfKUwG = 1633221816; nVnsfKUwG > 0; nVnsfKUwG--) {
            JfJWGiVsMk = JfJWGiVsMk;
        }
    }

    for (int FFMHMHC = 431847993; FFMHMHC > 0; FFMHMHC--) {
        continue;
    }

    for (int qIddMh = 1642011720; qIddMh > 0; qIddMh--) {
        continue;
    }

    for (int ivfdenXM = 793698161; ivfdenXM > 0; ivfdenXM--) {
        continue;
    }
}

bool wUesAe::IXxTrasOGMwp(bool sEwXiyGjLbuC)
{
    int bDCDUMTzz = 558705625;
    int EgCzwofVYuzYz = 985977054;
    bool PliPZpxxTaYPKAi = false;
    bool QKOwuW = false;
    int JtVxmZulUVHaoHEB = 825008262;
    bool WKIUAQGOOhneeGa = true;
    bool GyebY = false;
    double XePkgcGuyGn = 535579.1246539394;
    int KUWwrEcd = -727041080;
    int ZDNfCwKsJtqaQ = -508466082;

    if (PliPZpxxTaYPKAi == true) {
        for (int IdgbHI = 427703124; IdgbHI > 0; IdgbHI--) {
            sEwXiyGjLbuC = ! QKOwuW;
            bDCDUMTzz *= bDCDUMTzz;
        }
    }

    if (WKIUAQGOOhneeGa != false) {
        for (int eGmqh = 1601528307; eGmqh > 0; eGmqh--) {
            PliPZpxxTaYPKAi = ! sEwXiyGjLbuC;
            KUWwrEcd -= ZDNfCwKsJtqaQ;
            PliPZpxxTaYPKAi = ! WKIUAQGOOhneeGa;
        }
    }

    for (int zFrGAtPDtdHNjX = 836264556; zFrGAtPDtdHNjX > 0; zFrGAtPDtdHNjX--) {
        continue;
    }

    if (ZDNfCwKsJtqaQ <= 985977054) {
        for (int wqPHgbzGLhYjU = 1711037433; wqPHgbzGLhYjU > 0; wqPHgbzGLhYjU--) {
            KUWwrEcd = KUWwrEcd;
        }
    }

    return GyebY;
}

double wUesAe::DXGgkBnaZQp(bool iDwDf, double TgRBzuA, int VIHSeCgOeZLUSwo, string hSkcIAVAPZc, bool tQeTW)
{
    string ZAjSgMptMqupj = string("nzDnkByJFgLFtXeyiUhHPmPbROZenEhFBhdoEAKHibNVxk");
    bool HizHbggoNp = false;
    string mPEvHnGnJRHuOv = string("FEPqnnCWflxWgNdRsxQlzTFccHYIFRRVqRKVFFFoqlHTYMYbGNuIykDWJRBONgT");
    bool siRgkPeVnBKXUsVJ = true;
    string OqPcelgSTVAVOFGM = string("OEuXfrJcOroprzoxemCebbKmDpTYqpPxjQJDkwSdYHeRTaTPEOQfAqHWIJqdgXNrazwfsqjsGgyfQIAhffbJCRyokYxGecRpQiACXNjcwxUSqLmEHFgwbBnTXEEOi");
    int jkBqSBFMlRPz = -145946764;

    for (int HVDEGjGRZVatvC = 51207373; HVDEGjGRZVatvC > 0; HVDEGjGRZVatvC--) {
        siRgkPeVnBKXUsVJ = tQeTW;
    }

    for (int VGMxKt = 2067580261; VGMxKt > 0; VGMxKt--) {
        HizHbggoNp = ! tQeTW;
    }

    return TgRBzuA;
}

wUesAe::wUesAe()
{
    this->PUduw(-114993681, 502790.8679376572, string("nWNXGkdFrVZgjjatSxAEAfJvuMKp"), 1886635289);
    this->GsZdtXhAR(string("BaOZeThRkXcrdYcwKcXOotycTJrEHBJUXoCDOZwkJmCntkYxTaCQUgFbwcmGbhKYIjsNmikTcPTNYiYdgosEaCtXZmesSKarvrYPlnBCDLlKCssnUIpzjFbQSGOryhtgRFITSV"), string("VyxLLNHAVIAgdZAVUiUPtjFFIXFZgMzFlbqPkhXLrUlQMeQlixadFsjvPcIcMqneYmfrwvMDgEXpTKrFfAvSkbAUpTRriaSSDyrsBmmrzTbOqiNubhlYZnikRICTNgUUFzlLFPpstuWaQfgVUKHDHvcfiYFuJIqNGQdBAfHiYCLGpCIEQbqqjnPANFmmyotwBaeLxVXxztuwOKyGJsxOZQbuuJOBEgUpxvw"), -1704700781, string("FDAIsuqLeFAKBxIfTyBXhCmkRJFSLfxTnCzJgpPOxJUnlYZTMbUbmbeNHtxDymGHoMzhhzBIVXPMkQUqfSkuxvcVGlxOKouClftIQfAPIQMNNvbonddQbDOwvtxomMxrCKXCVIXMsB"), string("stgYrsqypbqqMUSRgrBfgqpTRkOmWmYNyfpisqMgZQXMsIVPkNmDmGMnEWHOLLLMEzHSQzHEvfJWXmPxIMahhqUbWXpMDNVzwdwrtlVWgArtWpQaTfrSaRfhvphqBPypnLKrOlhLNdfwWzdrDTHukVgsfmsFlplvecHttvlqOeXIWcQFQrBhFDuiRKHkbOhkeTCEd"));
    this->oXFnrHsBUZQ(1148161862);
    this->MCHOtAm(true, string("CROGvZbRARpGJRFuiQyMhrqJHknRhggKQpYkRtcNBFCPvOIUIPqgQyMNwP"), true);
    this->BNJYKbfa(true, -460899.89719931374, 1633047752, 333394.77308887645, 846587.9253186292);
    this->syflvyUPMFInE(false, string("mfzYUlkqVNeHkOcPTuBSgYNjudmbetDiYKmkbMIpPHLZfBbnHRDzQNJoSXByNteTLhZOzpLLmNftorocDaZEqnebGFdVvFRhOyEOntaFYUbZVIjvxImdsvbGpSvAikUvzBOOREbqtcWaxDThaFNrDmdZyTYkTAAgsBRseoHJqgwXYrYYIlWf"), string("aPiSNOwNDvnJokexvAdWHqNVZjXIJPzLKPAITgPnqfWLGrziPgktOiLJAmKrgnJheruMBucSAxiWZhyRcWJuWGnBQHBckDrvbRjaYpWhADJwOhibVmSURHRnHQatxFziXvPHCNSRRBQRQmsyKfNOgiOfuIcnreCHLXerHCdLundRZSyNTpLSOqYVeZLlqAPaNTilMgtvVNnZABlhlvLNVkydrFgwGUeHuOYXzNST"));
    this->pifbVbvJDCAbWAx(1364286095, string("JsOmmdRJiIiyzqaLmVFymtvt"), 1338931936, true);
    this->aDcHJFBHI(-943426988, 502910956, string("XGFbzygxtLMDMJeKpGIAnWAYtUuhruEoCBBGCmnGBxwkJkWcYJHHUOlutxCSjUeqtRxKeOVgeeWccLLYlxsUhOnAqCoUaHnVvCQmxUYcQoeuNnjAbwwgyfDhPAWDFadDqjvXVugTQzrYIjVGpuGcFXqXWdkHBtRuLtCpb"), -410159466, string("DLsjLTXWWKpKxlJOSmqYqRvNpWCBKpANNhtoSYWlLyEkdiIvUjXcvIaOVxFmPFijBYziZwpRuPRtmBkyODQvyQqFhpFqBodNuxLRAEQGWnPhQwAWrKgWFBDUIUPPFGIPnZQDDXOgHpAQspSHXnXKMhNFKoPfsJqfpUfYhKZ"));
    this->SmVaDptrMmH();
    this->KnMXRBhvTD(true, 267155.57692069473, 297300096, -176356.930169313);
    this->IXxTrasOGMwp(true);
    this->DXGgkBnaZQp(false, -757390.136824338, 706964821, string("XcfvoMCUmYuCIrAzPqkcSErKhXfIjmGbxiseMCEuAovUdoJLQoxuyDzmxrVqluGHsLhFrilRYiWcbGXuXeEzaBWvAFEcqVOqAbXmjAllFUQCgzteIwzaeYwfREMPduaWMlsDaoapxnSTJyRmjpxdyWqzGvzcfYoJHrfNVooZSUdgAYiOcLxGLeHiQLejwwfXVtUNcmXeiZDGCNSTXlBlFAczQSrICFmxyrrQFLZpDI"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ilkYnjDC
{
public:
    string IrfvgS;
    bool JuYQtkFJVrFH;
    int baYXGfXjTedh;
    bool hpMgPPi;
    double YYSXhcmKe;

    ilkYnjDC();
    bool DYwlqrINWozHed(double rglJUjzUpTCqjWgm, int STcAkug, string FqaFw, string PKOGpDtcIz);
    void dIVqSidtsPEVlH();
    double rpfpKuZYPUQQ(bool kYpKfsoSu, string YBKFrFzzz, string wlLiEI, double wnxCo);
protected:
    bool myUWAImMwxkQ;
    int nDrQWcpBvz;
    int kzlMqCXbVvObie;

    int nJWNLqqsrP();
    double uIBTIehO();
    bool DqOrVPNsiTf(string KAZhjjYIlc, double jgoNy, int ylMoZsuyxSs, string RuRbhgaJEqO, int toJGFiSj);
    void MTqAEpIVP();
    void ToJVXlLFgaefu(int XTAGxAul, bool iNsGJc, double oeQrm, string SxHYysKXrolBLbm, int iSUohnwHPITu);
    double slOrazMUjbg(int TbDJCOOxhCFme, bool eRTAc);
private:
    double KWjkM;
    double jVCvLl;
    double HSFoarqbYZwb;
    bool dKQaIMn;
    bool wOYEua;
    double ehKrdtrX;

};

bool ilkYnjDC::DYwlqrINWozHed(double rglJUjzUpTCqjWgm, int STcAkug, string FqaFw, string PKOGpDtcIz)
{
    bool AcSAOZBAeUhC = true;
    int QAVIFLIZaEP = -2040122501;
    double gBJRcILhyDZUJn = 844372.4643785097;

    for (int JTMwgcO = 1784344772; JTMwgcO > 0; JTMwgcO--) {
        continue;
    }

    for (int MkDuLRO = 1979864959; MkDuLRO > 0; MkDuLRO--) {
        continue;
    }

    for (int BtfVXYZnJKMS = 308950195; BtfVXYZnJKMS > 0; BtfVXYZnJKMS--) {
        AcSAOZBAeUhC = ! AcSAOZBAeUhC;
        rglJUjzUpTCqjWgm = rglJUjzUpTCqjWgm;
    }

    for (int GQWbbBNGwNG = 1816705252; GQWbbBNGwNG > 0; GQWbbBNGwNG--) {
        STcAkug = STcAkug;
        STcAkug /= STcAkug;
        QAVIFLIZaEP *= STcAkug;
    }

    return AcSAOZBAeUhC;
}

void ilkYnjDC::dIVqSidtsPEVlH()
{
    double DmBQAhpimYIuFQPS = -329374.42579559685;
    string qUFIDBLJjLiqgox = string("utRTPMKpZpiAKmfuOxFxtKDkwjNCPJJQQJSkBFQmYfUGvTwEAlmTlEIfebraKaOListnBGnQozXzUFIYJnThurMMZapXqBAcDhIevhLNqmlcvqHFxGvPPaNqculNlNsREVIFUoiLzIWcbli");
    string kYBufUCJtWgbKXC = string("GExeKDvUflqAdbvKEVhCJfthEnXDGzaULTFfaGhcz");
    double JWbiJQhIR = -353751.43495045917;
    double eBaihNsvO = 921080.7943522702;
    double PmvTMwuCbz = 577122.0135453473;
    int nucjHJFXgfISOv = -1448269714;
    int YwYksYjBcdXSXP = 1933742133;
    int AKmDAeFzWX = -2015075024;

    for (int LICVCQ = 2043899806; LICVCQ > 0; LICVCQ--) {
        JWbiJQhIR /= PmvTMwuCbz;
    }
}

double ilkYnjDC::rpfpKuZYPUQQ(bool kYpKfsoSu, string YBKFrFzzz, string wlLiEI, double wnxCo)
{
    int sZGreN = 162293116;
    int FfdBq = 116150610;
    string pWlYhpJWaRJi = string("qUsRAEQSnNDjvjERtrOKTeUdoqgcFYBVcSCykDGhhdGEyLJGtPqJNSBMKUjFvEHjcqwMtiFMZTKoReSdHdtdRgCZWyP");

    return wnxCo;
}

int ilkYnjDC::nJWNLqqsrP()
{
    bool wuvLdnyViGMPT = true;
    bool WnjErdogGSe = false;
    int RurBwTcAncuD = 374528603;
    string LWnWshzOb = string("eGiJKUnlNqlkaIlxdppiDmcyYspBmwUOXBYGwhvditHYEZTGmggehmWSqqLFYzCVmwognMndjRxItyMjbEqBidBXXkpJqIytzmJVFiGmfWXDCxxfDAvbZFsrcyKAu");
    int qkstjNKdKvphlap = -1744024635;
    double FYmzZuwDs = -844370.9655359761;
    string IZEFAVyYhMGiV = string("mYSkDqajQwUSCPQrYHzJhcDWfmJkCzYlaBArhDSYpOXolISZGuxGkWTsqiAZvVaaAYrqMdAsKylwuDVipBTgDwpzCFMUckOKXrWxtpNlFpVdiXYRcZojFvRckvKWNaodfNRpVsmflWXbbBHLPdEBrQnlumMxihAQrUUOxfQzjqvVzeUPNDdkIXuRnZAxGvrxLxoYlqpaCHeepggP");
    string vhQNsyQWqukRt = string("NMyWkNGfZJAlivikhVwRTrKnkDJwWtJUSYETRsNJfBtKMwLwYVcJhLUuDjZiaYoDXtVKjsXMXQlSYnqJufPhdtOftrYmXOykAfTaxkGGSXwFepSZuGXWBFsNpunlDfMIGmpUYVhjjhfOSWwONydQbdYchscuXJZroFzWujwVjXjOEQkmOMd");
    string teqEwYioItqJ = string("HjmLDEGazgKLXgeMNyPCyUMyHQdFJnEYgQyivOOhFvqVThJJNviFYLvvzdwYcHJFFBdpYYmBuzGrNFXbecfSHysShmi");
    string tBEfrqt = string("JWlBQIdbbNYsUtaoiotRtgRPGkGoRwIvdsIlgUdwzBXpuIJzTLtUVxjFgqcQMjTpcsBRIdzuTOIglrmfaSHAdcMswm");

    return qkstjNKdKvphlap;
}

double ilkYnjDC::uIBTIehO()
{
    int iuKzwhsOQVk = -1520878468;
    bool XnevOKsMNhYevlY = true;
    int YUFtXJuAVKTn = 514060016;
    double DAVUfSGXajva = -294951.66991945554;
    string OvFfysuk = string("FhIazVjBluSHMJZXLPXubJIktucLZpMPBuMaMLpZcaOFZAHLMTMEniKbWqykJtCWlcEAcQtWqVQLXnQpexEvqaYhlYfYafaPzqqjlhkpwvcLgklFOEiNFVHSDWbDjpFPQmWXkiQzRZcuHyFxeurSXBruIxsGNdKrfeDUaAUdwNciogAiiDLxFKxUwJSdxYQIhLUyNYrPnYxXapGPc");
    string zzATniedss = string("dJIPVfGGxWMHcslTFgthlonCcBSrpTBQvkNiPYjxJKZTJteZzZyZHMLrDCoxjqhkKJuqtIXotlKehyMkiTKLbpwdaOiqSkhEDbXZxHLITddCeHQNZDRjfqIbjIPuSPnaBipgpfgaYHAOtdqbMbrQBZznrIrzoMSdszPWviniWmCoNOJTJEVQcdONUsDJjOfWyicqSfVGaQrO");
    string DQqEOQMoDy = string("hblUdltuYQjNOQjmUsnnpMTmsDJPJZCwCXFlhEEKbzTTaefEVeYOZgDJRHLEfnNrBixcAEiYolDmdzyZwjuhIRLjnZvcaZABvMibwBXbCHTBPBAZxIpqlrHfdyt");
    bool WjQgNhyHoouRIQle = false;
    string EzYJoy = string("ZBAwmWarJskpUxbKgUYcsPOISafhUooRVhOXiSqsRcGzKdgDgLGikStucNcmsdMegvNwXobdaHdIRbpxiOTOCTmOonzjjPdSJpVkBKefbVAAzlnRJnyIurWMYLiiQdQnOfvNWWGYOfwGQyEongSXPbeuvROZranDSpRdhHmJA");

    return DAVUfSGXajva;
}

bool ilkYnjDC::DqOrVPNsiTf(string KAZhjjYIlc, double jgoNy, int ylMoZsuyxSs, string RuRbhgaJEqO, int toJGFiSj)
{
    int YAtpTkJziiDTEn = 1780313542;
    int POtheyB = -1389366029;
    string EumSusrwSDYvW = string("bEgZsgBFFNDvlRwwItuTmGJEKEfNNFOqKftSDkBMGTCky");
    int xXqbR = -541115380;
    bool cBZwhcBqa = true;
    double FEqTqRsf = -688073.4795232667;
    double DVBhszlDNeJ = -538480.2769766037;
    string KPLDlRGD = string("DQoFwfJfUaSBheYImyyqmhXgRHTkkXXXcuXVV");

    if (FEqTqRsf == 550833.0583158662) {
        for (int TnJUcFshCRzTyJ = 388620268; TnJUcFshCRzTyJ > 0; TnJUcFshCRzTyJ--) {
            continue;
        }
    }

    return cBZwhcBqa;
}

void ilkYnjDC::MTqAEpIVP()
{
    int VBUCX = -373687853;
    int GELxNKdfvr = 1195792489;
    string IKoQaCKSyHOQHGa = string("htKAzAnylXVJFIvnwZRjnnlAOdsgPDbzekedYDCmoQhdLhhNvtmzfURftLBXjLJWWzyxMpIerPOynBiyHOBMDIMzSCcGByRrdgvqAPNhuUIyNVKvLoikHpNnfeIdTRjweMPbyakipqFYwMwhLnvjNbHCOqGJZhvNZRvDpSkKylxhBKYuHvspQWvwkTOfjfCcbIwTYmFZaUIItunYwMNo");
    bool rnhZHtOH = true;
    double lFpZjIUsLrJ = 366019.8136236816;
    string CQJKQMnoZXHWIvK = string("EwnbKpIrFabGBXWtUcAvULtxlbHrylBqycYfTeKkBhnCpsNnCqNOPWKnBDDoJmFIxxWeUbLUYQCRUdWDJQunVIQVqrYkFdSIwqgSRXYEEqIsvMgKCbGgMPluRhnXpZoCeaZg");
    double KSsAdMnfe = 805829.4344989175;
    double DbiEusqa = 98461.1103067455;

    for (int JXCBGJcDNROl = 350824332; JXCBGJcDNROl > 0; JXCBGJcDNROl--) {
        VBUCX -= GELxNKdfvr;
    }
}

void ilkYnjDC::ToJVXlLFgaefu(int XTAGxAul, bool iNsGJc, double oeQrm, string SxHYysKXrolBLbm, int iSUohnwHPITu)
{
    bool iarEfW = true;
    string ttCtupGp = string("dveiaiwzcwUWahFfxMFjPWjONmNxASIfFIRhPYdUanBwSFArTVUiFGStMKWOd");
    double jXDOLudKKWTRT = 245070.93005707784;
    double SzAfJuCYTF = -329530.41448220616;
    int qHUYGtZzKpvA = -1570300860;

    for (int ZMqHVPRtqsmem = 1034368341; ZMqHVPRtqsmem > 0; ZMqHVPRtqsmem--) {
        continue;
    }
}

double ilkYnjDC::slOrazMUjbg(int TbDJCOOxhCFme, bool eRTAc)
{
    double ZnVCNoCdJfEQ = -281526.67843474285;

    return ZnVCNoCdJfEQ;
}

ilkYnjDC::ilkYnjDC()
{
    this->DYwlqrINWozHed(870542.0473409706, 1583209398, string("uyECFbKgwxDhVlNdRcLsPERCXOCcECZZCryrWUCxYuAaZSIDeAmdrXdmJViLsInPVbDZmerABsRufiqsIQUdiaCVlOYhyRHHNpfLEbkBymD"), string("AgGELKjELmKkHuBsZHOTcvXjkGfIIXUVSGIFdnwCOQlkSCeZGLlHcCQdShHsyfJGkuQsaMBLhSTFPgJCdcFmRARKNMENwYCqhVUjUeNzbDXBZhvjFODijPlHSIBpWoWZJemoENJXn"));
    this->dIVqSidtsPEVlH();
    this->rpfpKuZYPUQQ(false, string("EHULcLvUNVCmtFqKaGueKz"), string("eZEHYFKRyGDRNPJmqLkpmtLWSTIadGabEfyJnGXyKouWHodJZcvrTSOuumGrAcoyJMNujIwRawfWrDyEDTFXPDkAhrswJZGRBIKpZubnEdwiJVMllPBSuwLwdqtJkakInasibkVJBoCqqdVVLBjcgFXClwZIfhBvvsWzEvNBlbSq"), 235823.5558616864);
    this->nJWNLqqsrP();
    this->uIBTIehO();
    this->DqOrVPNsiTf(string("vTcHBroFkxndwtJOzJccHJCIRObzSzYmnALSoplU"), 550833.0583158662, 178741577, string("BWnHvkOHIwdzzfCexMcWeKvULhlVeKqnPrjHZKkbuTgqHLKvXyGAJsrClyLTjbswxuNaiiCRx"), 900403152);
    this->MTqAEpIVP();
    this->ToJVXlLFgaefu(-394086191, true, 757159.9992171011, string("SHQESolGPZwENfzTyybtKQZqGoSBulFfQzffFFbradMhvuyKNuRFenDDYtnECThkBtujjQuyjQjNCULIDmdYxNBinQIXXscUSHOysfdnNRrXaGvjONkAHLEFkqRNyTFzfqQzxiOaYFHqmVaGtzqxbNZPReuifImPVXfGnqABczWHKBYIHbsdFEfEhkSsAhzBXXbkPNRDoHsVHPOQjziUQYnEaeA"), -1541261037);
    this->slOrazMUjbg(-1706007871, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DqsywleH
{
public:
    int ALMTAQ;

    DqsywleH();
    string JqbapBQ(double sdTRdXvFGH, int mmEhIOFzOwLDslI);
    void bCOrRsBXxgzEZV(int qYbPqRelFJvn, double bWDozvehMv, string GbIyleLUElfGx, int ZNQKmGkh, int hiIxVNhwajRnKC);
    void bpoxnvUPLWDdOVa(double PFhkOGgZmHMI, string cMYftmGtAR, double VvaZrRJASpJOLVcv, bool HOKvhEOt);
    int nlgORtNu();
protected:
    int hObhHPDgTVPtXcL;
    int cDGjnbPs;
    bool yeXrhGMIB;
    int SbfMoTbcMsAHW;
    double jcGfrojjqX;
    bool nTrjjt;

    double bBSRwvKqIgeLbSrj();
    int VtzxBYPIZJa(int HwKGJvonNBqyOKrp);
    void szhNEGkzaIllbHi();
    double BBmsLHFDXNRaP(double ZOQBuUvyGlXiZsF, string MsEnUfIxMWQyG, double dWTnGvaEcZZDhw, string DXYEAzHgccFM);
    string hhoFgit(int eypqKcVMVGcJdlvt, bool IZylKUJM, bool nJHcSdYVBK);
    string UnGSGNVddp();
private:
    int ksBPzicZiG;
    string aHnnHShOfka;
    bool kIqklSnKmVjhlfc;
    bool QZoDo;
    bool EbNPMT;

    double RConADLLr(bool lNwzs, bool XAcua, int OduEMYquhbLsvFj);
    void dVfMKirAeRaPPafU(string cbXCxNygLr, int libGASHNjWQLMxyc, double tYEIvJPqhXfD);
    double kACqSjaq(double ksquBOVaZOOZUAR, string oMOmsWJf, int xIZpXuStwujwCpaP, int OuNTF, string qmYJjJKrhF);
    bool NEgJCwA(bool zwAYwWdUsJaFiYAO, int EjbqvIfsQQazVPx, int sPQKLjfF, double BHUufSkhFXKzdFWI, string FmcOH);
    bool EYYyHyQjlg(bool zHjdqwwKQWgrP, double rdUMlPot, string XttYqpBLFCh, double wGYishBEsHAfTXU, double pKefmFYamSHdXo);
    bool ypUcb(int TlystMFxO, string UWImmcWDKG, double jJWTplwLRVl, int SSngZxLViE, double WdqNCz);
    double hoASkVlAsL(int pjWhkyVtyk, bool mSOjeXXipf);
    double qMqDmfnraEOw(bool znRPSILimpgLmaf, bool UOBnNcnz);
};

string DqsywleH::JqbapBQ(double sdTRdXvFGH, int mmEhIOFzOwLDslI)
{
    string eBbkxQ = string("kRNKayZmgPiMnqfEeJuoYNRMOhiZoWwJYHNlUlLKqRdnPNtyxiLDLrctWkZtdolmbFkuhLvqxjJrhdOdZlLYXqoqmLVmjIAwqLRlrlORXLXqdIegfXuGrcgxjFJxFlBXoSBmivTTTBopaQhjSvGZUyLpqtqTMAiZWYyDqpYGDnycIKMxJTzIElUNiVEQhPfCrUmXkcHXQILcEfjmBPLyuyuKAUYZQbXhDOhaxDSHiAfcWXUpILy");

    for (int HXgzMAcnwezGxU = 725082730; HXgzMAcnwezGxU > 0; HXgzMAcnwezGxU--) {
        sdTRdXvFGH *= sdTRdXvFGH;
        eBbkxQ += eBbkxQ;
    }

    for (int fIvujNRbrPa = 815454038; fIvujNRbrPa > 0; fIvujNRbrPa--) {
        mmEhIOFzOwLDslI -= mmEhIOFzOwLDslI;
        eBbkxQ += eBbkxQ;
    }

    for (int hkECtsXcYVkGcPL = 817976247; hkECtsXcYVkGcPL > 0; hkECtsXcYVkGcPL--) {
        eBbkxQ = eBbkxQ;
    }

    for (int LvnTcA = 2108083581; LvnTcA > 0; LvnTcA--) {
        continue;
    }

    if (mmEhIOFzOwLDslI > -1501797299) {
        for (int hlpbOduP = 208514917; hlpbOduP > 0; hlpbOduP--) {
            sdTRdXvFGH -= sdTRdXvFGH;
            eBbkxQ += eBbkxQ;
            eBbkxQ = eBbkxQ;
        }
    }

    return eBbkxQ;
}

void DqsywleH::bCOrRsBXxgzEZV(int qYbPqRelFJvn, double bWDozvehMv, string GbIyleLUElfGx, int ZNQKmGkh, int hiIxVNhwajRnKC)
{
    int zfbRHKbIhTHg = 924838079;
    double kynVgFNHTpIidl = 529467.989615093;

    if (qYbPqRelFJvn > 1013422258) {
        for (int AgbAJGmj = 197118100; AgbAJGmj > 0; AgbAJGmj--) {
            continue;
        }
    }

    for (int tSqxSjVBEPsj = 730602557; tSqxSjVBEPsj > 0; tSqxSjVBEPsj--) {
        continue;
    }

    if (kynVgFNHTpIidl >= 307721.85178142553) {
        for (int dSzHThjphF = 1267599403; dSzHThjphF > 0; dSzHThjphF--) {
            bWDozvehMv += kynVgFNHTpIidl;
            bWDozvehMv /= kynVgFNHTpIidl;
        }
    }

    for (int IQbpNeVSYgCpL = 2130591974; IQbpNeVSYgCpL > 0; IQbpNeVSYgCpL--) {
        qYbPqRelFJvn += zfbRHKbIhTHg;
        qYbPqRelFJvn /= ZNQKmGkh;
        hiIxVNhwajRnKC += qYbPqRelFJvn;
        qYbPqRelFJvn = hiIxVNhwajRnKC;
        bWDozvehMv = bWDozvehMv;
        qYbPqRelFJvn = zfbRHKbIhTHg;
    }
}

void DqsywleH::bpoxnvUPLWDdOVa(double PFhkOGgZmHMI, string cMYftmGtAR, double VvaZrRJASpJOLVcv, bool HOKvhEOt)
{
    bool ZCAxMRjiUzednd = true;
    bool gXhjzWeTLSjcWGYJ = false;
    int mvDExEcWnxZqdq = -80195114;
    double JcFRlKBFkZRPSb = -705668.9883362064;
    double MnfrxgXSVCt = -628289.825616293;
    bool UlMreIXG = true;
    string GhNsdNZfc = string("nkwATtXrgdHNGdVUcDcegeCmsjzgSsKldLSZxyPdcGAxRmokOobeLufXWCIZHFJpLIxVTCaumjaWnexIUGq");
    double jLHBzciMFfXXlR = -619874.8104872775;

    if (gXhjzWeTLSjcWGYJ == false) {
        for (int ZCWkHZysfaiU = 1016109258; ZCWkHZysfaiU > 0; ZCWkHZysfaiU--) {
            JcFRlKBFkZRPSb *= JcFRlKBFkZRPSb;
            VvaZrRJASpJOLVcv /= jLHBzciMFfXXlR;
            VvaZrRJASpJOLVcv /= MnfrxgXSVCt;
        }
    }

    for (int tTLuLxc = 2097746411; tTLuLxc > 0; tTLuLxc--) {
        HOKvhEOt = ! ZCAxMRjiUzednd;
        UlMreIXG = ! UlMreIXG;
        jLHBzciMFfXXlR += JcFRlKBFkZRPSb;
    }

    for (int oFuVTLEwNj = 1294648502; oFuVTLEwNj > 0; oFuVTLEwNj--) {
        PFhkOGgZmHMI -= MnfrxgXSVCt;
    }

    for (int NHInoCwuFmv = 344710947; NHInoCwuFmv > 0; NHInoCwuFmv--) {
        jLHBzciMFfXXlR /= VvaZrRJASpJOLVcv;
        jLHBzciMFfXXlR -= MnfrxgXSVCt;
    }

    for (int KzxJujxcjiSGMD = 525547638; KzxJujxcjiSGMD > 0; KzxJujxcjiSGMD--) {
        jLHBzciMFfXXlR += JcFRlKBFkZRPSb;
    }

    if (UlMreIXG == true) {
        for (int UEVIh = 1655209943; UEVIh > 0; UEVIh--) {
            MnfrxgXSVCt += MnfrxgXSVCt;
            mvDExEcWnxZqdq += mvDExEcWnxZqdq;
        }
    }

    for (int xanfZ = 92918398; xanfZ > 0; xanfZ--) {
        GhNsdNZfc += GhNsdNZfc;
        ZCAxMRjiUzednd = ! HOKvhEOt;
        VvaZrRJASpJOLVcv /= JcFRlKBFkZRPSb;
    }

    for (int xqBckRJhgaXuwhOB = 293634948; xqBckRJhgaXuwhOB > 0; xqBckRJhgaXuwhOB--) {
        PFhkOGgZmHMI *= jLHBzciMFfXXlR;
    }
}

int DqsywleH::nlgORtNu()
{
    string XUljIpp = string("vqQNxQZEnFbwnbecCNcWvXmXYOKPNPyNuoOAWDSvDTeOKJKOWUzhHumHLyETWJyYbbhJeNyHjyDPHBIKTVjeruViYhJcGSyDnoCzUUpUjzHzglYWKQhLReDuEnwJsSvhzQcmxhKWDyvctRHMKXlmPvEvMTNveselASUcSNuMev");
    bool FtuxnjyYj = false;

    if (FtuxnjyYj == false) {
        for (int bWjxmEFPqogeGIp = 767994495; bWjxmEFPqogeGIp > 0; bWjxmEFPqogeGIp--) {
            XUljIpp += XUljIpp;
        }
    }

    if (XUljIpp != string("vqQNxQZEnFbwnbecCNcWvXmXYOKPNPyNuoOAWDSvDTeOKJKOWUzhHumHLyETWJyYbbhJeNyHjyDPHBIKTVjeruViYhJcGSyDnoCzUUpUjzHzglYWKQhLReDuEnwJsSvhzQcmxhKWDyvctRHMKXlmPvEvMTNveselASUcSNuMev")) {
        for (int EOgPEdhgHNDjpbv = 1825168393; EOgPEdhgHNDjpbv > 0; EOgPEdhgHNDjpbv--) {
            continue;
        }
    }

    if (FtuxnjyYj == false) {
        for (int kQumMTJeoZCTQVL = 1975472386; kQumMTJeoZCTQVL > 0; kQumMTJeoZCTQVL--) {
            FtuxnjyYj = FtuxnjyYj;
        }
    }

    for (int gzWhGXMWAoldjP = 1771334111; gzWhGXMWAoldjP > 0; gzWhGXMWAoldjP--) {
        XUljIpp = XUljIpp;
        XUljIpp += XUljIpp;
        XUljIpp = XUljIpp;
        FtuxnjyYj = FtuxnjyYj;
    }

    return 1195860070;
}

double DqsywleH::bBSRwvKqIgeLbSrj()
{
    int jVZyOcJdj = 299340390;
    bool WNqAYPnzVhsMgY = false;

    if (WNqAYPnzVhsMgY != false) {
        for (int kXDGxjksZlRSMbHn = 1372495265; kXDGxjksZlRSMbHn > 0; kXDGxjksZlRSMbHn--) {
            jVZyOcJdj -= jVZyOcJdj;
            WNqAYPnzVhsMgY = WNqAYPnzVhsMgY;
        }
    }

    if (WNqAYPnzVhsMgY != false) {
        for (int rwbrgQwlsr = 1948116985; rwbrgQwlsr > 0; rwbrgQwlsr--) {
            WNqAYPnzVhsMgY = WNqAYPnzVhsMgY;
            jVZyOcJdj -= jVZyOcJdj;
            WNqAYPnzVhsMgY = ! WNqAYPnzVhsMgY;
            WNqAYPnzVhsMgY = WNqAYPnzVhsMgY;
            WNqAYPnzVhsMgY = WNqAYPnzVhsMgY;
        }
    }

    if (jVZyOcJdj == 299340390) {
        for (int bwVVPMhEHYNvVW = 871176669; bwVVPMhEHYNvVW > 0; bwVVPMhEHYNvVW--) {
            jVZyOcJdj /= jVZyOcJdj;
        }
    }

    if (WNqAYPnzVhsMgY == false) {
        for (int PIOPfGmXAlHTXaC = 1550354471; PIOPfGmXAlHTXaC > 0; PIOPfGmXAlHTXaC--) {
            jVZyOcJdj = jVZyOcJdj;
            WNqAYPnzVhsMgY = ! WNqAYPnzVhsMgY;
            jVZyOcJdj += jVZyOcJdj;
            jVZyOcJdj /= jVZyOcJdj;
            jVZyOcJdj -= jVZyOcJdj;
            WNqAYPnzVhsMgY = ! WNqAYPnzVhsMgY;
        }
    }

    if (WNqAYPnzVhsMgY == false) {
        for (int QOGBbB = 1740909011; QOGBbB > 0; QOGBbB--) {
            jVZyOcJdj *= jVZyOcJdj;
        }
    }

    return -310225.5547325217;
}

int DqsywleH::VtzxBYPIZJa(int HwKGJvonNBqyOKrp)
{
    int wDLRoUkxuOPRM = -59991010;
    bool DYZBDksvi = false;

    for (int mtsWQQvfXPdsXAWw = 633007627; mtsWQQvfXPdsXAWw > 0; mtsWQQvfXPdsXAWw--) {
        HwKGJvonNBqyOKrp *= HwKGJvonNBqyOKrp;
        HwKGJvonNBqyOKrp /= wDLRoUkxuOPRM;
        HwKGJvonNBqyOKrp -= HwKGJvonNBqyOKrp;
        wDLRoUkxuOPRM /= wDLRoUkxuOPRM;
        wDLRoUkxuOPRM /= HwKGJvonNBqyOKrp;
        wDLRoUkxuOPRM = wDLRoUkxuOPRM;
    }

    if (wDLRoUkxuOPRM != -1134809445) {
        for (int kkdNE = 928997598; kkdNE > 0; kkdNE--) {
            wDLRoUkxuOPRM += wDLRoUkxuOPRM;
        }
    }

    for (int GYRIWPRSfqfyeXa = 346064635; GYRIWPRSfqfyeXa > 0; GYRIWPRSfqfyeXa--) {
        HwKGJvonNBqyOKrp -= HwKGJvonNBqyOKrp;
        DYZBDksvi = DYZBDksvi;
        HwKGJvonNBqyOKrp -= wDLRoUkxuOPRM;
        wDLRoUkxuOPRM -= wDLRoUkxuOPRM;
    }

    if (DYZBDksvi == false) {
        for (int WHyIwpbseqPbxfVj = 1638665695; WHyIwpbseqPbxfVj > 0; WHyIwpbseqPbxfVj--) {
            wDLRoUkxuOPRM += wDLRoUkxuOPRM;
            wDLRoUkxuOPRM -= wDLRoUkxuOPRM;
        }
    }

    return wDLRoUkxuOPRM;
}

void DqsywleH::szhNEGkzaIllbHi()
{
    string FpmHYmatJAQB = string("ukcJxkXIJnazZMRltROMARFCeRLoZRuGgUnoSieONosviAwzoqayYnUAoaBITUCJsZPaJvVeUbiTHHHwdtMFJQELwWgijnJCpaIUHnIlguWOEFSQlEtsUEtVwPDBkfQJXZcbzksORESkCx");
    bool jEKzlWIqiDb = false;
    string CPkbbFpkJJmCVyi = string("dWoohxhgXODnfolbhBHrzsUcmBppd");

    for (int QsbSvrJ = 1205380045; QsbSvrJ > 0; QsbSvrJ--) {
        CPkbbFpkJJmCVyi += CPkbbFpkJJmCVyi;
        CPkbbFpkJJmCVyi = CPkbbFpkJJmCVyi;
        jEKzlWIqiDb = jEKzlWIqiDb;
        FpmHYmatJAQB += FpmHYmatJAQB;
        CPkbbFpkJJmCVyi += FpmHYmatJAQB;
        jEKzlWIqiDb = jEKzlWIqiDb;
        FpmHYmatJAQB = CPkbbFpkJJmCVyi;
    }

    for (int XcCBKrBlqV = 825452338; XcCBKrBlqV > 0; XcCBKrBlqV--) {
        CPkbbFpkJJmCVyi = CPkbbFpkJJmCVyi;
        CPkbbFpkJJmCVyi = FpmHYmatJAQB;
        CPkbbFpkJJmCVyi = FpmHYmatJAQB;
    }

    if (FpmHYmatJAQB >= string("dWoohxhgXODnfolbhBHrzsUcmBppd")) {
        for (int oiawqWfPMf = 1054446922; oiawqWfPMf > 0; oiawqWfPMf--) {
            FpmHYmatJAQB += CPkbbFpkJJmCVyi;
            CPkbbFpkJJmCVyi += FpmHYmatJAQB;
        }
    }

    if (FpmHYmatJAQB > string("ukcJxkXIJnazZMRltROMARFCeRLoZRuGgUnoSieONosviAwzoqayYnUAoaBITUCJsZPaJvVeUbiTHHHwdtMFJQELwWgijnJCpaIUHnIlguWOEFSQlEtsUEtVwPDBkfQJXZcbzksORESkCx")) {
        for (int mbuuhaWOkcoQo = 13339501; mbuuhaWOkcoQo > 0; mbuuhaWOkcoQo--) {
            CPkbbFpkJJmCVyi = CPkbbFpkJJmCVyi;
        }
    }

    for (int HeFaPvy = 350179192; HeFaPvy > 0; HeFaPvy--) {
        FpmHYmatJAQB = CPkbbFpkJJmCVyi;
        CPkbbFpkJJmCVyi = CPkbbFpkJJmCVyi;
        CPkbbFpkJJmCVyi += CPkbbFpkJJmCVyi;
        FpmHYmatJAQB += CPkbbFpkJJmCVyi;
        CPkbbFpkJJmCVyi += FpmHYmatJAQB;
        FpmHYmatJAQB += FpmHYmatJAQB;
    }
}

double DqsywleH::BBmsLHFDXNRaP(double ZOQBuUvyGlXiZsF, string MsEnUfIxMWQyG, double dWTnGvaEcZZDhw, string DXYEAzHgccFM)
{
    double LVBtSESrsUc = -271693.73313034093;
    bool xZADu = true;
    bool ujbriOsacVtnl = true;
    bool ropzAfmSEcx = true;
    double rgYuOePymwywfgG = 968338.437754578;
    bool fgDcIkYxCELk = false;
    bool dEsml = true;
    double nEGjLHOAeBBp = -131899.1991835503;

    for (int GmsBDHNzwGp = 1292604015; GmsBDHNzwGp > 0; GmsBDHNzwGp--) {
        ZOQBuUvyGlXiZsF -= rgYuOePymwywfgG;
        rgYuOePymwywfgG *= dWTnGvaEcZZDhw;
        LVBtSESrsUc *= ZOQBuUvyGlXiZsF;
        dWTnGvaEcZZDhw /= ZOQBuUvyGlXiZsF;
        MsEnUfIxMWQyG += MsEnUfIxMWQyG;
    }

    for (int UsTfKiA = 2123126516; UsTfKiA > 0; UsTfKiA--) {
        dEsml = ! fgDcIkYxCELk;
        MsEnUfIxMWQyG = MsEnUfIxMWQyG;
    }

    for (int Npggas = 1151929251; Npggas > 0; Npggas--) {
        xZADu = dEsml;
        LVBtSESrsUc += dWTnGvaEcZZDhw;
        dWTnGvaEcZZDhw /= rgYuOePymwywfgG;
        fgDcIkYxCELk = ! ujbriOsacVtnl;
    }

    for (int EctTwhTprtcjXuMr = 1357910142; EctTwhTprtcjXuMr > 0; EctTwhTprtcjXuMr--) {
        ujbriOsacVtnl = ! xZADu;
        xZADu = ! xZADu;
        dEsml = ! dEsml;
    }

    for (int vVCEmv = 675205300; vVCEmv > 0; vVCEmv--) {
        dWTnGvaEcZZDhw -= dWTnGvaEcZZDhw;
        ZOQBuUvyGlXiZsF *= rgYuOePymwywfgG;
        ujbriOsacVtnl = fgDcIkYxCELk;
    }

    if (MsEnUfIxMWQyG > string("HDzvMoyCzoHEcKLYDSmagdtPPTuxgKqzXhALIkQaagNYrvQMlPTXdxqsBBqzmDLyimfYvyFeXsMDIBeyUIgFJotonDxaGEHZuKAbwwDmgbTOoyvJIPawAzGWTxRPFKeIYUoWRPETZvdwotPkhzEVXKVvQMUngZXVtmDMTkeKFEesbsIcVKkgxUqtRVZyCweUYrGjNMEmvKaCPGoUDTsQAcFTuzbBDQhv")) {
        for (int eZJddDtFMOOFJn = 617097924; eZJddDtFMOOFJn > 0; eZJddDtFMOOFJn--) {
            nEGjLHOAeBBp *= rgYuOePymwywfgG;
        }
    }

    return nEGjLHOAeBBp;
}

string DqsywleH::hhoFgit(int eypqKcVMVGcJdlvt, bool IZylKUJM, bool nJHcSdYVBK)
{
    double jhxnIWOSSkh = 147600.67040388632;

    for (int DfRrKbAqifLkY = 1150968517; DfRrKbAqifLkY > 0; DfRrKbAqifLkY--) {
        IZylKUJM = IZylKUJM;
        IZylKUJM = nJHcSdYVBK;
    }

    for (int JVbqDmO = 895019110; JVbqDmO > 0; JVbqDmO--) {
        continue;
    }

    if (IZylKUJM == false) {
        for (int nrntPwedTEPDdbpM = 344620722; nrntPwedTEPDdbpM > 0; nrntPwedTEPDdbpM--) {
            jhxnIWOSSkh = jhxnIWOSSkh;
            IZylKUJM = ! IZylKUJM;
        }
    }

    return string("bipWROfTGZoBshFdurlIEfxUUDSLTWMnaJANBGGclUmxbVtaAypgMfrWVMehVEvVGrrHPuCcqmYKsNCgqUdtggQPYPrhTvbBiTqGTreylHPLfUoLxWvxSTJyBXAIZKH");
}

string DqsywleH::UnGSGNVddp()
{
    double iQAcYzPhyJKzMHLM = -593047.7406159153;
    bool chlGPlqoHb = true;
    int GrjipZjOSQMRcPv = 1728396995;
    bool WAuAookASxOOZlmr = false;
    double ESetedShczynwb = 1029428.8926514324;
    bool oGZSyba = true;
    bool nyOcx = true;
    bool afZWgoXCI = true;

    for (int MXCwm = 36638639; MXCwm > 0; MXCwm--) {
        chlGPlqoHb = ! WAuAookASxOOZlmr;
        oGZSyba = ! afZWgoXCI;
        afZWgoXCI = chlGPlqoHb;
    }

    if (ESetedShczynwb <= -593047.7406159153) {
        for (int EZXgUHRjVTwCuq = 817452666; EZXgUHRjVTwCuq > 0; EZXgUHRjVTwCuq--) {
            afZWgoXCI = ! nyOcx;
            nyOcx = afZWgoXCI;
        }
    }

    for (int wqxEQ = 93474359; wqxEQ > 0; wqxEQ--) {
        afZWgoXCI = ! afZWgoXCI;
        afZWgoXCI = WAuAookASxOOZlmr;
    }

    if (oGZSyba == true) {
        for (int FHzfMMAoPh = 1382874076; FHzfMMAoPh > 0; FHzfMMAoPh--) {
            chlGPlqoHb = ! WAuAookASxOOZlmr;
            ESetedShczynwb = ESetedShczynwb;
            nyOcx = ! afZWgoXCI;
            WAuAookASxOOZlmr = afZWgoXCI;
            afZWgoXCI = ! chlGPlqoHb;
        }
    }

    if (chlGPlqoHb == true) {
        for (int EWGslnVakBtYf = 1349680731; EWGslnVakBtYf > 0; EWGslnVakBtYf--) {
            ESetedShczynwb *= ESetedShczynwb;
            chlGPlqoHb = ! oGZSyba;
            ESetedShczynwb -= iQAcYzPhyJKzMHLM;
            WAuAookASxOOZlmr = ! chlGPlqoHb;
            WAuAookASxOOZlmr = ! oGZSyba;
            afZWgoXCI = ! oGZSyba;
        }
    }

    return string("zVAyjNkiPDHdkHSvZUbysUUqHUrgzxuVvwFfXPbFCHbEnOwsWzORDauHLMwoACfqIrOiBMIfdtaSeXyAfUZKAOTcDnQtFhsulaKRJWQYFxndBICHWdzZjzSktjcGUEfruEWbDKJfzZZPufkofkdpIQTJAiSQzXflkyibQZfiYhApUZqboljPedAlYzbvEWSicHzYVeEGQvpPShSRcdGENdcxpxT");
}

double DqsywleH::RConADLLr(bool lNwzs, bool XAcua, int OduEMYquhbLsvFj)
{
    string RtpzZHuH = string("yuBjUZYTWYHAQpGHjPDPDXPBleaGvjsEMXqhhqebCBJIfIFTEfKZkokRCIMXWoHiLWkcOdPaJhYbKNONkJtKweeMYQBRmoXYWmAQeoQuXXAddIdJtsNOzESQKpXDrOMIPKagHkMFOliYgGNONjvJIuAuvdtCywZeNMLAAKopKLgxFMEtMSwnnUxJPfAYVAjaAPdJVfaTzLGZWgAPeiChdlezuEqKvbsDTIUGCnL");
    double MtrLMuZyzzXi = -682952.6681024549;
    bool ukjAhlQSvUA = false;
    bool WWQsfwiJ = false;

    for (int aQRuRxJHeWsiHdU = 1336292038; aQRuRxJHeWsiHdU > 0; aQRuRxJHeWsiHdU--) {
        lNwzs = ! WWQsfwiJ;
        XAcua = XAcua;
        WWQsfwiJ = ! ukjAhlQSvUA;
        ukjAhlQSvUA = XAcua;
        XAcua = ! ukjAhlQSvUA;
        MtrLMuZyzzXi -= MtrLMuZyzzXi;
    }

    for (int gkphyUzrqfSXWyt = 817556336; gkphyUzrqfSXWyt > 0; gkphyUzrqfSXWyt--) {
        continue;
    }

    if (WWQsfwiJ != false) {
        for (int XkmDwhEPv = 1777155454; XkmDwhEPv > 0; XkmDwhEPv--) {
            ukjAhlQSvUA = ! WWQsfwiJ;
            ukjAhlQSvUA = XAcua;
        }
    }

    if (lNwzs == false) {
        for (int asDdKrhYvku = 2044961193; asDdKrhYvku > 0; asDdKrhYvku--) {
            WWQsfwiJ = ukjAhlQSvUA;
        }
    }

    return MtrLMuZyzzXi;
}

void DqsywleH::dVfMKirAeRaPPafU(string cbXCxNygLr, int libGASHNjWQLMxyc, double tYEIvJPqhXfD)
{
    bool afEcyBjyiU = true;
    bool VSGwS = false;
    string TbbRhaLaHRzHRTX = string("fxcsKrVgttIBTEgffrIXvNPpmXJamIfLywDBlkcNKOuQieDzHraBcYfIdDmeTlvfmYyGhMj");
    bool rKJaBw = true;
    string kKogkMQx = string("HDNyyGgbEaHkFCBvtNqdiUhESxPnDcSeQmpNaQVEdNRBBUhlBRfQCCLTHgCuvYWrwvjSsDBPKebrmwgBxNVrSXbkXzAiCogNWmhIOypfLfZwIvzn");
    double uBOSToEDLTTVBMm = 855828.5652457611;
    int uoOebwA = -1610392445;
    int wQZWnyjKWtlY = 667501823;
    double IfhvOhyC = -886380.999480581;

    for (int ZIoMGgbNyy = 218608947; ZIoMGgbNyy > 0; ZIoMGgbNyy--) {
        uBOSToEDLTTVBMm -= tYEIvJPqhXfD;
        cbXCxNygLr = kKogkMQx;
    }

    if (cbXCxNygLr >= string("HDNyyGgbEaHkFCBvtNqdiUhESxPnDcSeQmpNaQVEdNRBBUhlBRfQCCLTHgCuvYWrwvjSsDBPKebrmwgBxNVrSXbkXzAiCogNWmhIOypfLfZwIvzn")) {
        for (int IBcztwGURtxgZqek = 35877065; IBcztwGURtxgZqek > 0; IBcztwGURtxgZqek--) {
            VSGwS = ! VSGwS;
            TbbRhaLaHRzHRTX += cbXCxNygLr;
        }
    }

    for (int CLeqvefX = 765170112; CLeqvefX > 0; CLeqvefX--) {
        uoOebwA += wQZWnyjKWtlY;
        VSGwS = ! afEcyBjyiU;
        uoOebwA += wQZWnyjKWtlY;
        cbXCxNygLr = TbbRhaLaHRzHRTX;
    }

    for (int qoxqSXfnU = 305539664; qoxqSXfnU > 0; qoxqSXfnU--) {
        rKJaBw = afEcyBjyiU;
    }

    for (int jxkEvBOUn = 390828737; jxkEvBOUn > 0; jxkEvBOUn--) {
        tYEIvJPqhXfD += IfhvOhyC;
        rKJaBw = ! VSGwS;
        uoOebwA *= uoOebwA;
    }

    for (int bdQypzTU = 1651275415; bdQypzTU > 0; bdQypzTU--) {
        kKogkMQx = kKogkMQx;
        rKJaBw = ! afEcyBjyiU;
        kKogkMQx = cbXCxNygLr;
    }
}

double DqsywleH::kACqSjaq(double ksquBOVaZOOZUAR, string oMOmsWJf, int xIZpXuStwujwCpaP, int OuNTF, string qmYJjJKrhF)
{
    double DDeowjgQjcAEuDX = -441688.0491578682;
    int vHUuMDUDzNHoTDd = 1878397863;

    if (xIZpXuStwujwCpaP <= -1940292437) {
        for (int SqADIlADPkc = 119120321; SqADIlADPkc > 0; SqADIlADPkc--) {
            DDeowjgQjcAEuDX = ksquBOVaZOOZUAR;
        }
    }

    return DDeowjgQjcAEuDX;
}

bool DqsywleH::NEgJCwA(bool zwAYwWdUsJaFiYAO, int EjbqvIfsQQazVPx, int sPQKLjfF, double BHUufSkhFXKzdFWI, string FmcOH)
{
    double xDwQIrNcbLHzFAl = 699878.5321154047;
    string bWVDu = string("cXHIsADsSwjZrLgcongjAM");
    double SqjWDrv = -319721.68695961224;
    double cKEjon = -884822.9760557195;
    double HlgxWEiptNBW = 713758.6391070463;
    string hGfKkJIfVrlof = string("QWdBZVwNPzmbcHahvKNXahYhZpLnSCAmmwEDSGriSdeyOdpewsXMYMTfhQnTgndv");
    string xetjEfMuBYMCHcX = string("bbNHgYGjWbuPcHGzmOXFdrYBVIgcJQpZbbwqWEhFYHtmjuNasorIrgxoQPlwdyjgdzXgnOpPNbmtIwFQiDnAiWYdlxzEwoKahYBnKBsGMDTNRrMacXdReQtrxqmMtgCKYXIzFXiqRrKcberLynPWNmtisNpDWLhHIMAOHlryIajkGiBGIQJAhdwFDNwGXJqsfeQcAwPFOFrRoOlEmCSvXavPZbdNEkSNxzTwOrUPOzJLK");
    string CkSzX = string("HhpGPhVfOxYHSvKSLsjYOpWMezewoJwSvFBkUpVckjBhVDDLOGfuGvgwhIvfHkErfnTbYejGBccxnwRqLaaKIgOQiUWbMAXMWhFFRfqKqKDqjxsUgJLywcXcorUOUfmJlwxckgGKRYjkGNmwcAsJIJdplGWMNXKeGMBCQmmqQknyHTPhsSwaRvKPyTtbDIfsIbO");
    string jncOaxwpxD = string("JTYQGgskTLqwFqpuBkLinjvTGqlyMRXsIcLAfabcIrCFaHdfcfEoptcLMKsUlnPecXjHLHGYOVBlxBSwSZqwlqChxdgHyazSflWNXluSnXzUfBN");
    double cofqRbMiZS = 17323.964918630285;

    for (int pSSwMsCpvrrrhF = 1955273192; pSSwMsCpvrrrhF > 0; pSSwMsCpvrrrhF--) {
        FmcOH = FmcOH;
    }

    for (int BlmCmYstMSmgVw = 1744561250; BlmCmYstMSmgVw > 0; BlmCmYstMSmgVw--) {
        FmcOH += xetjEfMuBYMCHcX;
    }

    for (int QsLBglh = 1108623033; QsLBglh > 0; QsLBglh--) {
        hGfKkJIfVrlof += xetjEfMuBYMCHcX;
    }

    return zwAYwWdUsJaFiYAO;
}

bool DqsywleH::EYYyHyQjlg(bool zHjdqwwKQWgrP, double rdUMlPot, string XttYqpBLFCh, double wGYishBEsHAfTXU, double pKefmFYamSHdXo)
{
    string TdEJVgIQEbunW = string("bGtpOrenCBxnHbdFFUpfXbUxMsmpAQTkcUGTucweANVIXzAlFWPUEAbkIQvivuaafSTdtilSnqoNYPxnLkoYUVZeYmXKBPQwngGGKdUFlYKgoxLxDNBBgybvmNEYducHmmbmqMRqdtwMWoKFRaggEhPNAUigYkYcUPhVYvaRceGsQuPbWuuaninkQnPcHaivHxabbYdfZvaRRmTXvYTSKBzAJgDW");
    string ogQpUXB = string("rCUbqAEoqJai");
    int bVmzuNCGxNYxVq = 1918467459;
    double HLDHvcKtPln = 671005.678364078;
    string loOjkC = string("bWYzaHTOjRyeJommKwEmbgZUWaIuaupSQhMoLBEhQrxlmOxojIYjYfaZlyUMsjZMyITzHZQBYnVQeVqnIcUYP");
    string OOQpFRJV = string("IzKdMaqrxBtxFTYubbtJAoIJtspcwsvrFSNTMDTPmxWUjNFHAuHfRFmUwvnBCaVrdbRajAGsAyaLSSoYkUnFLbDloVCUOwEIAlFHYYEoTOguKyJliNHPlMsLPciXRNMobGAvlQecwPUrt");
    int XKZTXYxR = -929930876;
    int qVuoOeA = -1543610929;
    bool NeJFwG = false;
    bool WfzKClcNnh = true;

    for (int pTzrE = 204659813; pTzrE > 0; pTzrE--) {
        OOQpFRJV = loOjkC;
        XttYqpBLFCh = ogQpUXB;
    }

    if (zHjdqwwKQWgrP == true) {
        for (int tZueGTN = 258284217; tZueGTN > 0; tZueGTN--) {
            pKefmFYamSHdXo -= rdUMlPot;
            loOjkC += OOQpFRJV;
            qVuoOeA -= bVmzuNCGxNYxVq;
        }
    }

    if (zHjdqwwKQWgrP == true) {
        for (int uZhUkmTMP = 502788416; uZhUkmTMP > 0; uZhUkmTMP--) {
            rdUMlPot = rdUMlPot;
            TdEJVgIQEbunW = ogQpUXB;
        }
    }

    if (pKefmFYamSHdXo >= 671005.678364078) {
        for (int AOwUThN = 443676673; AOwUThN > 0; AOwUThN--) {
            TdEJVgIQEbunW = TdEJVgIQEbunW;
            TdEJVgIQEbunW = ogQpUXB;
        }
    }

    for (int AcSPyyXMRXrkVBpb = 1188078241; AcSPyyXMRXrkVBpb > 0; AcSPyyXMRXrkVBpb--) {
        continue;
    }

    for (int nZIFY = 1808976028; nZIFY > 0; nZIFY--) {
        ogQpUXB += XttYqpBLFCh;
    }

    return WfzKClcNnh;
}

bool DqsywleH::ypUcb(int TlystMFxO, string UWImmcWDKG, double jJWTplwLRVl, int SSngZxLViE, double WdqNCz)
{
    string qlxSrKnuuEKyN = string("zqZyHJiVDiPRqxaMfwBwLXlOarDPlVtllNTzzZoaAjpVPnZpIeTROPcqwDrbvhVLhYDgOzPjlNhXKSpptVIpJPaxfarWuuMVfpIpZGklLSUOMKMtRaozAeBn");
    string ypkjCUVVTPKUn = string("tkPOdcbjYpquQdXNYIvFEBHDiZtHMJKvTOafSIUBupZxxuJzzEJWqrUJMykyvoCkZCiaCRwanANpcvCZWRIyLaxTgDHbZAaztRQfxaRoifrXIUqeeZWlKuPtModwcsJtveffVHrpAHAwgxAQmtAPYBlqVLlYCCPDqHqiJVvoRYuDTKzTFKsCMFvVyJFmMsIzcdgoVbAYjsZOiPoMDQDeNWmPOGnnvlabLlixzDMsYMV");
    string bZIDbLWrOXMoKVD = string("cwbaYlHwEsWeviQNdygDvbgVkyCocuxecsAdvDkaCAVIExIWuQcweBwzOgCgnQBoEqeVZNyLflBWelIyruVZwXbzIZXrRmysTMUoIJlszQtixInNFGayzsDiIzLWguHrHVdtacWhNHRoAhBFzOVFYkBzsaPnOruCcJXtGEfFzpPBjqvLJITzlpzGJrZPIVpTsbeRgTAbXvTIqEfCnKqaJqpnFxiEVlkjjCKvzkvjgghAWUKUDrPgMEdH");
    int TvyNK = 1105382172;
    double zShlMrUnIZIOp = 181032.72397225385;
    int nvLyKF = -709858798;
    double EEqOoXvqqscsU = 880016.4508371768;
    int ZqNyXAdoneqAyWXj = -638581807;

    return false;
}

double DqsywleH::hoASkVlAsL(int pjWhkyVtyk, bool mSOjeXXipf)
{
    bool kTEPqnBN = true;
    bool PgaDTlfCFfY = true;
    double hwMfgXco = 381467.90440080763;
    bool VnKnid = false;

    for (int ikWrpyz = 429396275; ikWrpyz > 0; ikWrpyz--) {
        continue;
    }

    for (int ftKdHnZUWElrEfI = 663004839; ftKdHnZUWElrEfI > 0; ftKdHnZUWElrEfI--) {
        PgaDTlfCFfY = ! PgaDTlfCFfY;
        VnKnid = VnKnid;
    }

    return hwMfgXco;
}

double DqsywleH::qMqDmfnraEOw(bool znRPSILimpgLmaf, bool UOBnNcnz)
{
    int aOdQjBljEdjbsPZ = 799224324;

    if (znRPSILimpgLmaf == true) {
        for (int wFOqAqhntDnwVI = 74668644; wFOqAqhntDnwVI > 0; wFOqAqhntDnwVI--) {
            UOBnNcnz = UOBnNcnz;
            aOdQjBljEdjbsPZ /= aOdQjBljEdjbsPZ;
            znRPSILimpgLmaf = UOBnNcnz;
        }
    }

    for (int HmGzGtbzVZhqMrY = 1922282478; HmGzGtbzVZhqMrY > 0; HmGzGtbzVZhqMrY--) {
        znRPSILimpgLmaf = znRPSILimpgLmaf;
        znRPSILimpgLmaf = ! UOBnNcnz;
        UOBnNcnz = ! znRPSILimpgLmaf;
    }

    for (int MFJRtFig = 298685668; MFJRtFig > 0; MFJRtFig--) {
        UOBnNcnz = ! UOBnNcnz;
        UOBnNcnz = znRPSILimpgLmaf;
        UOBnNcnz = znRPSILimpgLmaf;
    }

    if (UOBnNcnz == true) {
        for (int VRRsE = 1819548979; VRRsE > 0; VRRsE--) {
            continue;
        }
    }

    return 36835.80283817536;
}

DqsywleH::DqsywleH()
{
    this->JqbapBQ(-644668.1800987236, -1501797299);
    this->bCOrRsBXxgzEZV(1013422258, 307721.85178142553, string("zgHGbdstgndVXsUwTnxmO"), 1427002944, 1472094008);
    this->bpoxnvUPLWDdOVa(61917.97952431449, string("DzQbOyagAxdOHxDXDNwXmJOSmpGMPrISotxvBpJIMkouAbbRdFzfAwAqxiLsXVCzMjEhiJOnZTqUXttMTyvSpZNXPwXJTcDDjNPaVdAlQrCnpBECyYwPQgtvRoKYTPmqJkFXYJJszYrYpFgHxhiqQhVdUixZCzxkPpxNRlubOuPrzaudADAWdWVvsDNZqVmkCMXnFqeoinhMrebwXaQfBzjWHnVUppZvplameRWA"), -980331.3837924375, true);
    this->nlgORtNu();
    this->bBSRwvKqIgeLbSrj();
    this->VtzxBYPIZJa(-1134809445);
    this->szhNEGkzaIllbHi();
    this->BBmsLHFDXNRaP(838310.0083376503, string("uiBhqTEQTmeidMgTGkLsxyxjqCBBKRQgMXTXnRShXLVnoTokyMXAEkVQCNwAUYXmpfhTDIjBvPrxNgyKwzYjnEsoLOnYOMaAgGioVoVHvQBvhukBoXijKpNnkFblfcyIeIDSKikcVKpqlzUPbyOZHqhIjEQXOgxVopZWjHVdzwJdxrpIeiyOGDc"), -758575.1874100254, string("HDzvMoyCzoHEcKLYDSmagdtPPTuxgKqzXhALIkQaagNYrvQMlPTXdxqsBBqzmDLyimfYvyFeXsMDIBeyUIgFJotonDxaGEHZuKAbwwDmgbTOoyvJIPawAzGWTxRPFKeIYUoWRPETZvdwotPkhzEVXKVvQMUngZXVtmDMTkeKFEesbsIcVKkgxUqtRVZyCweUYrGjNMEmvKaCPGoUDTsQAcFTuzbBDQhv"));
    this->hhoFgit(171695102, true, false);
    this->UnGSGNVddp();
    this->RConADLLr(false, false, -2147208231);
    this->dVfMKirAeRaPPafU(string("WcKstudDYVeGmvDwsHOOZxYgjggqwARyUTgeRNIBwcbJJGvGQjHUSoySZdkdgorXniDvsiwRfLIQWAuGuzivOZvUVJnyFRdVukNApgMdzpIULiKzbXkrTuUpYopWgSSYDQVzkbHFpZolRuBEvTWcpNunFHdbfZObNVIPsTHhByhMmaANocopoJrceYNnGANWSslpnTmQMhKTVAcvtGVTIftpoyYUPjJWUalnkOVVdcDqKBqvdWCB"), 50152348, 280282.4658980366);
    this->kACqSjaq(408433.931411786, string("wlaReZSijSRtPKTcIIuqcIeKBbzMRZOoGRYlXVOAkyHycpRpsEDaBczrXHLJoDeRKLTNtraitRmEbVOqfGmaYTIWwDIJvnbdFvJwISQFbLPMYtdIpHhQruNOaAwGaFjvwWJBenxpLroDiyFerHKyriIaZvJEcvvcCtMQwCVVyIPjNkrIZnJFdoFjsdHIkOyUocPExuBiGxDeLoTQlq"), -1940292437, 1314785025, string("WVVHbvMjGXZtb"));
    this->NEgJCwA(true, -771233660, -283554405, -3399.2759703370343, string("uEhGetvheSMumRelaHdxVRRABiloJgCXoKrtvgcjMmLasGgGRBNhzUAoqLDrsQXtyVlSFFsQKGpFkloeaJiipIZMTSbVwFUZEInyKfxkAcCeBLBxPUaqZtMmZwGdPHeKafJHvCsFqtLThtdBpkpygoTXjigPqGQxGM"));
    this->EYYyHyQjlg(true, 416509.6331713071, string("KgyFnmUMfutgzFbUZxfcnFzXuSBHfKtHihaXLqQsvsAncizGaaBhrSqEFmjuQlvQayFGuZjJrMvTaajQbfkiPxMPaDwXAbaKCUkaUmOFAupCEbGkpjbJZuVHqVlCzIYvEscjJzEMwtpuDiRpYuEltzZqlAeiVtgXydokuLyWxykQ"), 679983.8016680129, -430425.67714753497);
    this->ypUcb(1899318431, string("GLmfTytoBDbqjJWvGUwRdYGqgWTGtSGyYWgzvauuskkSLs"), -1038960.2913841853, -375639722, 945675.4328328506);
    this->hoASkVlAsL(2087987459, false);
    this->qMqDmfnraEOw(false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WmLdB
{
public:
    bool FTVtzFOH;
    string GDDuMJXWeBv;
    int lDkxlS;
    double FqtjWvVPoqMo;
    string KnijqHc;

    WmLdB();
    void SgRLxKETXsCTA(string wmDrVkdbuBbpGr, bool RNsEuWNZNh, double XLgMK);
    double wHdlN(double YvGeCjxxIAaJvZ, int sIzRGLwkDTbqOiq, bool zKBmCO, double MYwvNSPD, string ujUQtpAIuLr);
    string UMDxkJpF(double JQGUt);
    double vAnyzBmiZ(string wrGKWkrdDcJA, double lydaEqfjI, int GpTjFDKZwjICHhEP);
    void CheQddT();
protected:
    double HUBNdKobWhBplJdv;
    int pxISqVTWrKzpM;

private:
    string iyUeFVkcjWoDE;
    string MQsRIkMr;
    double cwhOZXgaKcRnXN;

    bool DAVJtkcplNBJ(double lkffaKHa, int JgSAHHZMhZg, double yyFvjsu, double lXosHlvWCjfqW, double ZWowHXJetbxrBEPa);
    double RvduIH(string oAaiSKLEAOK, string qVtoqHoFAppkI, string duxBvcKcK);
    bool wSqbuepij(string qaeZWeidP, bool motHVjZKppiI, int EcvxIFflPVxvQjLQ, int twJASU, bool KPfBLIfesLX);
    void ZWysvqODMohV(bool dWdoGzgY, double ZIROQuIFGoP, int HiqsxUiDxI);
    int GjjpwYsMYVY(double aemcGVGILdMoFqI, string huwyVNoXh, double jWzcYSyHODMBG, int IemVHbpyx, string TqdgaRiluDHFeH);
    void FRAaUtHOVbI(int sawLdHytv, double yqssBLbtdCqpG, string ppHGQmEHzGSO, double cWmykBkA, bool vLCSbmFbFQgk);
    int onGNSDPVQvewQAxy(bool EFAFF, string rhcKm, string LLsnUgjnHI, bool IBYgWtKymvcBNJ, bool opNLWBWQpXQl);
};

void WmLdB::SgRLxKETXsCTA(string wmDrVkdbuBbpGr, bool RNsEuWNZNh, double XLgMK)
{
    string CcBmR = string("hxzfkvWLKwfDtNbjYuBBmMorBFPweukMulbMjuClgYgIXMWVVMUySkTOCwocFhFIYtKboUhTHXRjAudivrNvawGsWXHzsEVlBbLeYIToXAHWthLsZJcDpaSpTKBjjJXJZhafWFVFQrwpjRVtFMpYZxIaZYmYPUwHiIJiFffmgqvbOcSyJIrcyiRoaeUhMhjVvDfExcKomNDHboOVev");
    string PMoVbtlQYwy = string("cxzrYttWcKmCxlnNBirbBidGJNlJAXyCgvljEUtXknfBOKDtrl");

    for (int Hvwufyj = 190946605; Hvwufyj > 0; Hvwufyj--) {
        CcBmR = PMoVbtlQYwy;
        PMoVbtlQYwy = PMoVbtlQYwy;
        PMoVbtlQYwy = CcBmR;
        XLgMK = XLgMK;
    }

    for (int PeoLwdbTsqvJlztU = 215840404; PeoLwdbTsqvJlztU > 0; PeoLwdbTsqvJlztU--) {
        CcBmR = wmDrVkdbuBbpGr;
        CcBmR = wmDrVkdbuBbpGr;
    }

    for (int JvwPdxkWXyhnc = 761985345; JvwPdxkWXyhnc > 0; JvwPdxkWXyhnc--) {
        PMoVbtlQYwy += wmDrVkdbuBbpGr;
        RNsEuWNZNh = ! RNsEuWNZNh;
    }

    for (int plGwgi = 99456627; plGwgi > 0; plGwgi--) {
        PMoVbtlQYwy += CcBmR;
        wmDrVkdbuBbpGr += CcBmR;
        XLgMK /= XLgMK;
    }

    if (CcBmR < string("cuKCsWBQHFEJHikWKickGhvCURlSmDmkbLSRtPPHSPYmQ")) {
        for (int XgaGASg = 1826369548; XgaGASg > 0; XgaGASg--) {
            CcBmR += wmDrVkdbuBbpGr;
        }
    }

    for (int EcsfaI = 567818168; EcsfaI > 0; EcsfaI--) {
        wmDrVkdbuBbpGr = PMoVbtlQYwy;
        PMoVbtlQYwy = CcBmR;
    }
}

double WmLdB::wHdlN(double YvGeCjxxIAaJvZ, int sIzRGLwkDTbqOiq, bool zKBmCO, double MYwvNSPD, string ujUQtpAIuLr)
{
    bool eLfJwHH = false;
    int FItBBivXehMe = 869726388;
    double QvcWdkiZlUGjNFY = 556855.0554309563;
    int mveWK = 1670220525;
    string jhbjXcMzK = string("WsXfHF");
    int eiOyT = 429765284;
    bool uPQpIvV = false;
    string HsWVVF = string("CulBEJXwkSyXqjrpsSbANlcXOmDXbyDsNleVnluUcPewPeoVnANRvGLYgYpfJYNAsdYtjKLAqKACDYpsXdOtiYEsxgbMaEiRcXlkecOEfaaHmgXAPjuuCuiS");
    int tjvhUU = 358656594;

    if (uPQpIvV != false) {
        for (int RmNDTtDY = 968115735; RmNDTtDY > 0; RmNDTtDY--) {
            continue;
        }
    }

    for (int EghvUIwziezpi = 1913795782; EghvUIwziezpi > 0; EghvUIwziezpi--) {
        continue;
    }

    for (int tQoSCnj = 53524618; tQoSCnj > 0; tQoSCnj--) {
        eLfJwHH = ! eLfJwHH;
        uPQpIvV = zKBmCO;
        YvGeCjxxIAaJvZ /= MYwvNSPD;
        FItBBivXehMe *= sIzRGLwkDTbqOiq;
    }

    for (int XbvRjQYGsLzd = 1579131738; XbvRjQYGsLzd > 0; XbvRjQYGsLzd--) {
        continue;
    }

    return QvcWdkiZlUGjNFY;
}

string WmLdB::UMDxkJpF(double JQGUt)
{
    string KXjvTQobERufKGU = string("kFOFXicPKVnNHRgxOguxdcROkbJzhqZPWYCnbtqEoxTGHnQFdxkbPmGgiFfURZIdcGxXcSLfOEzDHVGQtdThfMPEuMXirhuvkXuaxGJFQPQZrsbXstoAYgZcpFabcziNQCSrFLhYIonhwDgijidfHhWhBYDhTTvpqHhhjUGeSmROfDBEwbrRsiwRPh");
    bool ouQAVyBsRI = false;

    for (int mbaZybOoW = 960391994; mbaZybOoW > 0; mbaZybOoW--) {
        ouQAVyBsRI = ouQAVyBsRI;
        JQGUt *= JQGUt;
        KXjvTQobERufKGU = KXjvTQobERufKGU;
    }

    return KXjvTQobERufKGU;
}

double WmLdB::vAnyzBmiZ(string wrGKWkrdDcJA, double lydaEqfjI, int GpTjFDKZwjICHhEP)
{
    string PIkwhMJmhctcd = string("VCXLyRfIFcqjHxrWOEYYclyqhaeTlUQyMLJqJNTIdvIIAuzuyvtfHlkbhCOpmQIuhCrHmevdbxtEmWnYuwPKDIiHkhcrORDCNOqPJKZAKWCcvWvuDLvotqdQYYOglLhvPqjypLMxeSSbOEksUUWrdFeisfZICJdsYPqlplhxemEbtIPqETQoeFDYIA");
    bool VzKqFbdENKEQ = true;
    string nuQdwdzie = string("LQCSCOoPhHAXqNlElCtXIVPdeLDEDWeekyjcxmQTfXHKZJVGEpJDbRJNcHVrXrsYkQOCCiYhXwslTHArwRkNeVdnCGjPxiqlPMQjyWZhijDeiTVkQlJRtREVSgSUBGeTHwAkqulRUUrEREKEHqHuPlihxJysmDTeSKsjwuzGyqEcUHqsIGbCcuisNQoEcglPvfbWWMIPYyGcwK");
    bool QLdgQjJWjIPW = true;
    double nHdJfAgFk = 758806.7207383591;

    for (int TgLxGr = 46187439; TgLxGr > 0; TgLxGr--) {
        QLdgQjJWjIPW = ! QLdgQjJWjIPW;
        PIkwhMJmhctcd += nuQdwdzie;
        wrGKWkrdDcJA += PIkwhMJmhctcd;
        PIkwhMJmhctcd = wrGKWkrdDcJA;
    }

    for (int HKPjgDsvoJIPYK = 973219007; HKPjgDsvoJIPYK > 0; HKPjgDsvoJIPYK--) {
        VzKqFbdENKEQ = ! QLdgQjJWjIPW;
    }

    return nHdJfAgFk;
}

void WmLdB::CheQddT()
{
    string MNmghKcUiQlEmBr = string("YdxvJpXUqZVGrIFdqdqFcElUAUJEHrseZCRsTTawvTpoafQCVpP");
    double CZBZPRiFw = -258881.5999427886;

    for (int Pvlzxq = 1208573676; Pvlzxq > 0; Pvlzxq--) {
        MNmghKcUiQlEmBr = MNmghKcUiQlEmBr;
    }
}

bool WmLdB::DAVJtkcplNBJ(double lkffaKHa, int JgSAHHZMhZg, double yyFvjsu, double lXosHlvWCjfqW, double ZWowHXJetbxrBEPa)
{
    string tBlrDkkdRiR = string("XqpnTICIgmriKssDLFToOZKdOnuaGgtxLgoBlkDAGtbpYfNVHopfZrdRqlFqMecatgoxIPWzEfbfAwfwDDHpEfcUsaPqTJivjvzgxlXRJItVuDWLzvyWmHlYKZxKGUCJFVbLRffGQJtqZfbqQSlKCEhfzkBekuOwWStWLjqqdvhKnXz");
    bool WyfoFipb = true;

    if (lXosHlvWCjfqW >= 243218.99364225208) {
        for (int rZiKGHEEieAF = 2134891868; rZiKGHEEieAF > 0; rZiKGHEEieAF--) {
            yyFvjsu = lXosHlvWCjfqW;
            lkffaKHa -= yyFvjsu;
            lkffaKHa -= lkffaKHa;
        }
    }

    return WyfoFipb;
}

double WmLdB::RvduIH(string oAaiSKLEAOK, string qVtoqHoFAppkI, string duxBvcKcK)
{
    int tozGaz = 1832402717;

    for (int DXoAfFfFJFg = 561121969; DXoAfFfFJFg > 0; DXoAfFfFJFg--) {
        qVtoqHoFAppkI += duxBvcKcK;
        qVtoqHoFAppkI += qVtoqHoFAppkI;
        qVtoqHoFAppkI = qVtoqHoFAppkI;
        qVtoqHoFAppkI += oAaiSKLEAOK;
        duxBvcKcK = duxBvcKcK;
        duxBvcKcK += duxBvcKcK;
        qVtoqHoFAppkI += duxBvcKcK;
        oAaiSKLEAOK = duxBvcKcK;
    }

    if (qVtoqHoFAppkI < string("LEIYJsTnexJKuCPloRqkGtcIBYJOLlPNtHbgWxHiRGEV")) {
        for (int iAvkuqPxCU = 338798158; iAvkuqPxCU > 0; iAvkuqPxCU--) {
            duxBvcKcK += oAaiSKLEAOK;
            qVtoqHoFAppkI = qVtoqHoFAppkI;
            oAaiSKLEAOK = oAaiSKLEAOK;
        }
    }

    if (duxBvcKcK > string("LEIYJsTnexJKuCPloRqkGtcIBYJOLlPNtHbgWxHiRGEV")) {
        for (int VPRLlLXwXEQZw = 1796480385; VPRLlLXwXEQZw > 0; VPRLlLXwXEQZw--) {
            qVtoqHoFAppkI = oAaiSKLEAOK;
        }
    }

    return 142407.88492799542;
}

bool WmLdB::wSqbuepij(string qaeZWeidP, bool motHVjZKppiI, int EcvxIFflPVxvQjLQ, int twJASU, bool KPfBLIfesLX)
{
    string FtSCRCYZMxYlMRv = string("SmYIWkdkjMjsEfKtWlGeSrtnLEKGJrKbDASvLSrjhaHipGSUSTJzaoltIYsjPSyHTFzeLvFQBDFnCfDsLeAHsEphpCTuIYjYVyHBgmAdJIoijcdbrpgbystZvqaUjUszBrSudwPqRDKgioRYKxfHvRcrqaLwStsFOolEWgCHWTVZnGQKUaaTckogOjaXfaLobckIxSvQdTNHTKIMeJFNgT");
    string TfKGQcbZbynwkn = string("RSwauxGQHyTKrQYOaRVRjPVxgBTXOBHUNjdkoztNNGv");
    bool ZpXqZfYU = false;
    bool TwMZjLYDfpuwA = true;
    bool DommFptAPDoV = true;
    int hRGQuDH = 1556061155;
    int wZInFsi = -977218151;
    bool MAovqhxtfti = false;

    for (int zbdzgAGz = 2027578001; zbdzgAGz > 0; zbdzgAGz--) {
        motHVjZKppiI = ! MAovqhxtfti;
        TwMZjLYDfpuwA = ! MAovqhxtfti;
        KPfBLIfesLX = ! ZpXqZfYU;
        motHVjZKppiI = ! KPfBLIfesLX;
    }

    for (int NNOrOxdN = 553642855; NNOrOxdN > 0; NNOrOxdN--) {
        MAovqhxtfti = ZpXqZfYU;
        TfKGQcbZbynwkn = FtSCRCYZMxYlMRv;
    }

    return MAovqhxtfti;
}

void WmLdB::ZWysvqODMohV(bool dWdoGzgY, double ZIROQuIFGoP, int HiqsxUiDxI)
{
    int HNMGfBjVmuns = -914925025;
    int hkEqldrTffqozmSN = -665541386;
    int ZnxlRvcimQRgoE = 1873869029;
    string czQRr = string("IPPpWPfKbKkWPZtUpZvemTvTEXYBNdqfJYcJyHilZhqcUARWIjntRazQkunNpqITbdcxxGGvcCCyUvMAfPQpthHSvutvUFTopyfiwEOjXjgQxSsTzLeNmoMhhXFTHwumkBDJSgSxyLjeIqYuwQLtsUBRqzEXTfBQnkKbyikmCAcQDmxCQmJqrNOelcheFaSWEmtuyiuZpTBOwB");
    double XZqrMQlinMNDbVX = -150108.15732655962;
    string BuBcfigCx = string("QYKwoX");
    bool pzLzRUOA = true;
    string lkqrXEWaVVTdWskq = string("RcXWFIHiSfdftoEgajnEqwinTWCuVABCdbQuEIQAglg");
    int onEVxKPqixHVWMlI = 966048768;

    for (int xFDGxCoWM = 1111377082; xFDGxCoWM > 0; xFDGxCoWM--) {
        ZnxlRvcimQRgoE -= ZnxlRvcimQRgoE;
        HNMGfBjVmuns = HNMGfBjVmuns;
        HiqsxUiDxI /= HNMGfBjVmuns;
    }

    for (int uwGuWqXGWFUMi = 332209371; uwGuWqXGWFUMi > 0; uwGuWqXGWFUMi--) {
        pzLzRUOA = dWdoGzgY;
        lkqrXEWaVVTdWskq += czQRr;
    }
}

int WmLdB::GjjpwYsMYVY(double aemcGVGILdMoFqI, string huwyVNoXh, double jWzcYSyHODMBG, int IemVHbpyx, string TqdgaRiluDHFeH)
{
    bool DgrhUSFIqxKJbzWD = false;
    string IHsEUkavQy = string("gbSnaBdwadPLcaPDKSnGWrjhsHYMrWfEoNPjor");
    int BGULS = 1170550399;
    int cSDiXi = -1958875809;
    bool EknWyXXU = false;
    string MRPteLTfXop = string("LgijxNEgAmDYsVjXkbfJzBrVZVtwOmsyyWiTSfAqRPdTdYceTxlCmaXRKmECFhGFZovdqzeyvvOKMsseqRGlXHATcsmaWdjSxmAckPTbYMUbIbBUSAsGzOikRDX");
    int UYKCBCO = -806719933;
    int pKDkoT = 1536937319;
    int tAQVQaUSWqGLEf = -1681559267;

    for (int kRjAeKswouCUrRJ = 1684077062; kRjAeKswouCUrRJ > 0; kRjAeKswouCUrRJ--) {
        IemVHbpyx += BGULS;
    }

    return tAQVQaUSWqGLEf;
}

void WmLdB::FRAaUtHOVbI(int sawLdHytv, double yqssBLbtdCqpG, string ppHGQmEHzGSO, double cWmykBkA, bool vLCSbmFbFQgk)
{
    int dpQOZJvjiJIAh = 2076623763;
    int dIhpCGiFu = -1152422895;
    bool EuYOGC = false;
    string QFkCcaSCfy = string("aZHJVuhfbcVEZRAbcjzdrcEWUNwVYZvVqJbakmImSlQYayaSmlNlVAvVDcNRGruPZwQJEIfRJKPFLtRgeuANhTkYNAvgLWnJdpdpwqFqhCAsJjCVTojBSiKBYsZTStexBVMmLmczoknLCShKNvoKiIQvqSGktDhknqzOdYcVJlMQCvbPiYoKWupBRBKFwmSKTdOtfUDZlEEvPcIjNHHoIbUnZnvhWzxn");
    string BQIkRU = string("HdRnLtZENljDYYJFTIaMfNTjXXYtIRfufGuQOtOkzYIuEkmorrxwZiUUxQAXHMBVoqYFCrpalkbdhyBwORQNLDbMVHnAhiepayPNhxLTJyiohOAWn");
    double ahGxGJmNQzwfy = -88867.13093332335;
    double rcdgMDGNTV = -1002323.031077715;
    string fzFhrNph = string("PjGXAZExSugCxyyYFuJlRgkmiCVCIIcCXnrVIsbsAolQBuYjcbehIfGRPajQoemGHPkXohcgQaMwmzZYounQjfiKOKdslOHRjdJUAsXgerlSPUGidBhaHUyBEDlFUpVrjfNtemopfYLApmfqjObBzMMQhOobYpmGWWLCyFujhJZlhyLsPbeJSJiJKuFzaARueYXgno");

    for (int izMgJLvBwdjhGQaZ = 792628192; izMgJLvBwdjhGQaZ > 0; izMgJLvBwdjhGQaZ--) {
        continue;
    }
}

int WmLdB::onGNSDPVQvewQAxy(bool EFAFF, string rhcKm, string LLsnUgjnHI, bool IBYgWtKymvcBNJ, bool opNLWBWQpXQl)
{
    string nvrsQ = string("PNxmwLUmElJcIXFUEeyPBgIXVVrWDWieBybWgRXntuZFwygqdFOuSHnVrbyvoHBWpUyEqxPsuCxSCFcZslVNWhAshbEYOTabnxIqlFbcxsZPWQRwtVRLyVcGCbOKzMYlFoPFbPyFypZcOYobywwYYCvNYzJ");
    bool yPKHRU = true;
    string jAlluhtj = string("tdZSjLDUPFJwfPqSpgWQMCryeunuckevub");
    double nWYgXPwXzcFJiIy = -1034806.6552774134;
    double HizHr = -521311.63611530256;
    bool EoKdplLHN = true;
    double dSQwttEY = 895605.4292445066;

    for (int NftyRDexfOGLi = 205011459; NftyRDexfOGLi > 0; NftyRDexfOGLi--) {
        continue;
    }

    for (int OJlRHWknwic = 412115918; OJlRHWknwic > 0; OJlRHWknwic--) {
        LLsnUgjnHI += jAlluhtj;
        opNLWBWQpXQl = EFAFF;
        jAlluhtj = rhcKm;
    }

    if (IBYgWtKymvcBNJ == true) {
        for (int HmXausaSoxEgXJ = 1632927301; HmXausaSoxEgXJ > 0; HmXausaSoxEgXJ--) {
            yPKHRU = IBYgWtKymvcBNJ;
        }
    }

    for (int NPnOyveXPpJUtH = 1600986843; NPnOyveXPpJUtH > 0; NPnOyveXPpJUtH--) {
        jAlluhtj += LLsnUgjnHI;
        rhcKm = jAlluhtj;
        IBYgWtKymvcBNJ = opNLWBWQpXQl;
        yPKHRU = opNLWBWQpXQl;
        IBYgWtKymvcBNJ = ! opNLWBWQpXQl;
        nWYgXPwXzcFJiIy -= nWYgXPwXzcFJiIy;
    }

    return 925742898;
}

WmLdB::WmLdB()
{
    this->SgRLxKETXsCTA(string("cuKCsWBQHFEJHikWKickGhvCURlSmDmkbLSRtPPHSPYmQ"), false, 411806.0973058679);
    this->wHdlN(716054.864364903, 1874180390, true, 122411.56351261701, string("LfILaOqhejlHDaHwjHmSYEYiiBRguUMBJCXswTDJFxqaMODWpEIFlcaIKbAtKKbraADkiSvgFCKhgwQHkZxlJzNIiYizDICTwXavnVGnsRDPbpoMvBUgxOJUEMucmRtmzsFItffauaTqOaYzaDRwDAgYIORVLzGEuRqOCcqbwxRlSFHKtGYOvNLiSTqbGaXICfOrfYVtuBPonKfJUNzkAhJtFGzQJFrmzInBwg"));
    this->UMDxkJpF(-219314.76078271357);
    this->vAnyzBmiZ(string("RGSyvjNDtXNXzAxWkpepaBMBFzDXYtUbOrDcDOnygbvOqBBWLYVoXlvjFQCrFiicwcMLtPmytoPmptPWPwRfqbhrHHoNHansMwVqfUrlDqtOBkEdsihsZfKgacfxWFMIPFYgRxkhySVBuoRcCpxQjvUtttLAIyzkTjzyzwXfMuoDdV"), -406775.1441494316, 244205411);
    this->CheQddT();
    this->DAVJtkcplNBJ(517464.0449502267, 1578506056, 940222.5185919952, 243218.99364225208, 349061.90393495973);
    this->RvduIH(string("tVKvQGPSYlNqprCuhCjJkQNsIkhjMczkjMzptQUJcPvMsrsqtxcUJJaZGBuZfjQXyLFgynJUwQkYiiTbFfBYdiGkmztNIyUUDOmKqgUgLGo"), string("TFrnjELcwMzcUGnHTDIMFUSnPXebKOwepiTWTVAjVAMharsTblrPjQVrWoEyzXcplXwzOhNCZqNxkjNFrLUEJjCHiWSIKLZBwepDcAIMrADVKnQFgkmIOaQYUWGARXSIsuSFDJkpYAeHCRCpUtzFLycKIrLnJxRBcySNnApskUlweKNtQhOfVqwviaccBSPpnYG"), string("LEIYJsTnexJKuCPloRqkGtcIBYJOLlPNtHbgWxHiRGEV"));
    this->wSqbuepij(string("uSchoZFOCzsjqwYQHJpBaxnOSIvLDPFQSqhfxKoupKNDOdsYMQBaKyKeROfTYVsCthveoWoIxciIXxpoduLBoeYbdBIxaOipydkAzMUAkwrRPtboYmihwkOlECMKkcjBiKbuVhDIDvcoTuHVYlsAWAzTsGXtiDzxrcGPvHclh"), true, 584288718, -1315633361, true);
    this->ZWysvqODMohV(true, -407904.01090568455, -179802401);
    this->GjjpwYsMYVY(-93601.45319137399, string("ZkCzcKsueUtVbpxWUQgruqGzrOLUbfTfxEROudkzPYvHLdxjBpFBVbrrEwhmbmpXtALgSWJDKuHcYchvkNQpUrROkyDFmKbn"), 32238.37995106904, 1679791756, string("EvpMxDpGKnKPOMurQvPWFZwvTJyXkTUbQznTqAyYTfWEyysReraezmUAVJODhEVlhuZjnHTuYJrRxHcicqAjRNrFzYfrBBcURCbVcBcoIyfmIybZGSNRDMjZgTLNyHyWbFLcAaVeDwdlhZZXJCrJswrnkjlldOjEVMEHBxAKKGjlCwOFpomXTTIqbmmutliocRmsFqnJAZpCEQJxhzIkvuNqmFoYAJkhqtUh"));
    this->FRAaUtHOVbI(876539946, 611934.5084423508, string("cVagjThEHqtNcDinjATfFxsTYPTxSkLCxjBkcHuNhZrWZSlhYgEJWDJIaQHWxKifUTdbiraiBvVrShBKEdIwIDdBCmcLuKavurDhgmbmacCzPezNqwvWIXBtIaXsdkGS"), 305620.5708619301, false);
    this->onGNSDPVQvewQAxy(false, string("PgoUeeSYYEDiHHByGKfCqXmlgzDarwszXXfDtCTiXUTNdtXbEdfiWuCuibOZhYGREmQFalVGsHDXHkcfAwQCCInhaPJIYhThcYpBewFfwjfFOUmCdTFXacvktVvzRPVG"), string("fxMzfvWehRGDcoZInvpjLtqYMhwxrBbnUpQbPsGjOGAUKuSZGxkjQlQBUanubOhWpxbUSOHIHyueCqiImwMcoSTcvQYPNWgfWDoGIjKfwqfEGigKgqiSIrwJyoDeZVQaEfVjhkOnmaNtnRjm"), true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JeVZYmX
{
public:
    double CVvIgDjwn;
    double SUOgACG;
    string LqdJrXY;

    JeVZYmX();
    double aQwYCRZZmNNCtF(bool xLoDvIwM, double yYEztQcSFJmV, double fBaAHNqAp, bool IHIeUjWgCA, string jTkYxKsdPkRTapm);
    string eKYepVpVDdKMfrj();
protected:
    bool kYWVhMZ;
    double AwZWnMvdjDCq;
    string rdUbTQhWR;

private:
    double TCpkixdJX;
    bool uobBSJtA;
    int hSVxDDDftXTezpeL;

};

double JeVZYmX::aQwYCRZZmNNCtF(bool xLoDvIwM, double yYEztQcSFJmV, double fBaAHNqAp, bool IHIeUjWgCA, string jTkYxKsdPkRTapm)
{
    int dITssCoLo = -1128458224;
    string zHsEfJxNrHlRjVR = string("XAFzZXWCKVhhKWNNjDTTfBbjEuxnFncFVSJafvGnHMsKZFLLWtYlVVDEwgxzOpcEdQAHFyjqAPUCqOVmQjFSqqGgjIxnhUOAfbwHTSzPzrYKAfbGnyKzxIHgslwBTwbZkUOPZknRciyDKNEYMWTKIhkACuvqVmcgUMgSVjcgBFAEJFXncWpJcZahNqEuRmvdjyAQuYdvAEPXGLDojgexVJkuKYSRCNdahYOfjwNNNQyhiEqTKiMOdvkfYTRwpQ");
    string PbwELzGwpvEGcOu = string("XAmhXVYkANxckSXgqjJhJRht");
    string gkHIuilADXg = string("lZIrAemBUoQgrVhgQMtCwgInMoSNpwvtcwcjkpfIqXbXsNxqQmKhbqIfrrKPKWAtfwqieulWhJuueBeZAPvFzfIExNwTfVOgFsqqLfiQxAzAXsvXiFqxMxflZhOfXQlH");
    string VkyJAsf = string("VAcGzmRGqOpbdvBuMCoNKaWcsXrolriRJWGuqaccpneJbBPxFbMZMZJaeJFfcmILlHjVZVUzzYlrIknXtHDNFUyLBr");

    for (int HqcIVBToNkgjWjc = 1294127546; HqcIVBToNkgjWjc > 0; HqcIVBToNkgjWjc--) {
        VkyJAsf = gkHIuilADXg;
        zHsEfJxNrHlRjVR = jTkYxKsdPkRTapm;
    }

    for (int PrgxjxZ = 1742870714; PrgxjxZ > 0; PrgxjxZ--) {
        jTkYxKsdPkRTapm += PbwELzGwpvEGcOu;
        jTkYxKsdPkRTapm += VkyJAsf;
        VkyJAsf += jTkYxKsdPkRTapm;
        IHIeUjWgCA = ! xLoDvIwM;
    }

    for (int kvGXPiApPNBISkA = 340191485; kvGXPiApPNBISkA > 0; kvGXPiApPNBISkA--) {
        jTkYxKsdPkRTapm = PbwELzGwpvEGcOu;
    }

    return fBaAHNqAp;
}

string JeVZYmX::eKYepVpVDdKMfrj()
{
    double XDOyPVjyMuRwxRrP = 46087.402960735715;
    double dQwOtPkPBeOstmg = -229828.0755459893;
    double lukngye = -597564.1811760082;

    if (dQwOtPkPBeOstmg > -597564.1811760082) {
        for (int tsEei = 1535299250; tsEei > 0; tsEei--) {
            lukngye *= XDOyPVjyMuRwxRrP;
            XDOyPVjyMuRwxRrP -= XDOyPVjyMuRwxRrP;
        }
    }

    return string("HAKDsCNfARkeIWNFCAGjbTAXbStQyQHIUpPjGcbWdWEjXMUJyYCQrtePDsxlWNazMwHMLWHDupHocFoHGPRAgfMKrNJsAAAdvmgyxjrLxhNbqzfnaWFsPuvhsCpNAueuSiYpVtAVVzpuefHCVLgSVxRzhQkeWNoOWHeIEzYsPCSkWjjMHmSpvAicgapeWKvqokMrPFrOXZHjNnumEHoBHjSDQujAwdAjQmHVnRfzfkiSzOb");
}

JeVZYmX::JeVZYmX()
{
    this->aQwYCRZZmNNCtF(true, -668746.0749707666, -656908.2448438711, false, string("JmeWnvgzkqtFDVruIqzcmPDnSUooKiVGbmXJfzXtvzYAieFJDWvnLwJcqCkqerFrqtpWalIQACFqkQBAcZBVynCTeRweNrNOHxNGPkuqGSVDlRUIwiapvriqldNPeGuWtvEdImemihUXAvQYrQlcuROEzjPqfqQLKIzpQUgrkNIxHnxJlwiLuupWvPjnljKFdIORWTCDbJXjszUGPXyqYkrHWIVWXNetqGeJdrsmEOGLMUesCEgCNpoffkhS"));
    this->eKYepVpVDdKMfrj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eEDVUbtNYtc
{
public:
    bool FXdMZeAHraOcwLyz;
    bool gchjVlW;
    double qXubSUjtFaw;
    double AZFUrKF;

    eEDVUbtNYtc();
    string nZLwrNdy(bool HQSZanCazgvZwj, int tcUWngwKbZP, bool GlTJLGhzGMzB, bool EZTMXNHtSoZTpcr);
    void pGssQnwTwUPx(bool nyqEPchZFdeO, double kBgpGsWeFyFOMvDT, string UMzngpMkhBxjkemO, string CCgpjtqc, bool KRXuOdtJRkOd);
    double oWulxAg(int EMLTqWtXuEDeGT, double IgOtmPZMhNLkLOk, double RQRpmPhhUQNgAb, bool CROEQCkLM);
    bool kWuQd(bool wFqGNfHCjFQUXH, double YUEGrDc);
protected:
    double JoCdbzX;

    string DAFGcoWAvVDHAW(string ygAnrGVBzBYUPFeD, int lwdqdh);
    double HFOFhdmFpFJrkD(double LhyJzjx, double GSncLqYNt, string LwMaTchLipO);
    bool XTDJuUOLyvwq();
    string ozMMHQrCTWP(bool mxwRaTno, bool cJGFlU);
    int kYMJmI(bool piafVip, bool uDxEzvh);
    bool AVyUWyJo(string BEJDroJSJuivsR, int NXzduxVjODr, double KcAXBA);
    void LsbKs(int nutVuF);
    void QOsYYWzjunj();
private:
    int vnHGQ;
    string cSnxeKGLSLTnH;
    string tyfGxi;

    int AZLvNi();
    double IcshmVVbVVuCNg();
    string mjjcHCRsdwExZz(string ZZLtLfPcRPWN, string IBNqUbAFUoMXIMbR, bool lejDGOSV, bool hurzaM, bool TTukQcyJApJ);
    double wexzqaNEHX(string IOKGVgmtVSn, bool mWQEERgkDrfp);
    bool kIXZtGnUpJ(string jXxyrhfGt, string oDAvoIa);
    bool PSpDalns(double QNXlelvfL, string IKkWaUkFcC, string wRavEBGDZgfP, bool HETGHMcYJc, int kZYRCj);
};

string eEDVUbtNYtc::nZLwrNdy(bool HQSZanCazgvZwj, int tcUWngwKbZP, bool GlTJLGhzGMzB, bool EZTMXNHtSoZTpcr)
{
    string RMIYDfNKf = string("YprfaEbfLyGkwulkBVocrvpOUQFHsmuIaPSOukkVVvGTdRozZLgIzUnRyyexBkGMRDIvscTHLDgfPmoQsWDmjygVHkRPjOPlJjCinjRKJwOORdYyCnRraCLQDtjNPrrRMJtEvHlwPpds");
    int gWHZg = 1566604796;
    bool mSoGpbC = true;
    double PENOVO = -957171.4672343597;
    bool PkTrOndOKKJBypR = false;
    double oqUDYztkNna = -637684.1139088784;
    double EBcoMBhqozPmdJ = 948883.6938401355;

    for (int XHWDPowvByM = 912151863; XHWDPowvByM > 0; XHWDPowvByM--) {
        continue;
    }

    for (int xwHYL = 437493343; xwHYL > 0; xwHYL--) {
        PkTrOndOKKJBypR = ! GlTJLGhzGMzB;
        GlTJLGhzGMzB = GlTJLGhzGMzB;
    }

    return RMIYDfNKf;
}

void eEDVUbtNYtc::pGssQnwTwUPx(bool nyqEPchZFdeO, double kBgpGsWeFyFOMvDT, string UMzngpMkhBxjkemO, string CCgpjtqc, bool KRXuOdtJRkOd)
{
    double fDuCV = -362200.3413628133;

    for (int STLARHDzblMG = 600407958; STLARHDzblMG > 0; STLARHDzblMG--) {
        kBgpGsWeFyFOMvDT += kBgpGsWeFyFOMvDT;
        fDuCV -= kBgpGsWeFyFOMvDT;
    }

    for (int eznPf = 1542986307; eznPf > 0; eznPf--) {
        CCgpjtqc = UMzngpMkhBxjkemO;
        CCgpjtqc = CCgpjtqc;
        nyqEPchZFdeO = ! KRXuOdtJRkOd;
        KRXuOdtJRkOd = KRXuOdtJRkOd;
        CCgpjtqc = CCgpjtqc;
    }
}

double eEDVUbtNYtc::oWulxAg(int EMLTqWtXuEDeGT, double IgOtmPZMhNLkLOk, double RQRpmPhhUQNgAb, bool CROEQCkLM)
{
    string BOupnYubtW = string("HQDJkmjaAHGWRoLdqSUUDyxDlBqaXsolAUHJWkgxwlxKtUCARrJxuLSNcqkpUsexeEjbeWfHuTOZYJpMuvdTFAeKKoKJCpmHUVIeIOqZGMErIlKYNPoVLwMSMEOEtIZtTxWpvEryDbbcUQpLdkUwubrtYRSRZOTFFKZtkxazxwjDlkVhRsDKXoTPFJsRSVyoFxhBugMjuGpNepklvYuZyATcwXhEIlOKzRPiIXXdXSPRtrdAj");
    int ZwxzszcCbFdcCYWk = -1160745990;
    double xZWlTaKZE = -81366.39695588492;
    string BPMNzBTsZRXdY = string("lKKnJDUHhFkNjiGdhEtsgRNpRKhMmonczqXaWVKDRdChCNnXqsXKPiUEOcSNbyGkbTWkzlDbqKxrXzneDVnHuOTHFMgIdiIaFD");
    double hwafFxH = 562064.729949511;

    for (int RLkVvfkkujw = 330105652; RLkVvfkkujw > 0; RLkVvfkkujw--) {
        RQRpmPhhUQNgAb += xZWlTaKZE;
    }

    for (int czgfguMUuj = 110546022; czgfguMUuj > 0; czgfguMUuj--) {
        RQRpmPhhUQNgAb *= IgOtmPZMhNLkLOk;
        ZwxzszcCbFdcCYWk -= ZwxzszcCbFdcCYWk;
    }

    return hwafFxH;
}

bool eEDVUbtNYtc::kWuQd(bool wFqGNfHCjFQUXH, double YUEGrDc)
{
    double kCEpB = -263322.3298681842;
    double UTbyGr = -804573.28956854;
    string IveChF = string("DTFi");
    string pDInetFhlfnEME = string("AcdvmRjNjbDQOqjpPWjWrLanporqFtWltzifoDUkJbXMHYjZqdIeHtkfrxFQVjALntAzzCNucojwgLqkWlhQZQNZhnGPEoSiqUiuTUffpDQYGKffAknCUYHzUYEQlGrrgIzpFgwdgFAqOhrVlknZOESWlgyFUBxPMhjteufpTtIuapqLLkTDqCllasaHaJijQxXOwNfsSvoDrxsgkojWKhuwyUtRUFCnGZAGcQzYlGbqzPkRoDetGNEqSZEBOFY");
    double wVlooDokqoCd = -875289.512130405;
    int cGyiPF = 850092027;
    double UnJFoYoywzCRYwS = 900992.8116823318;
    bool nkqioxW = false;
    bool ybTsthmYUUd = false;

    for (int mbcbvTmehTom = 1414538803; mbcbvTmehTom > 0; mbcbvTmehTom--) {
        continue;
    }

    if (YUEGrDc > -804573.28956854) {
        for (int beXFYlQPpl = 457525732; beXFYlQPpl > 0; beXFYlQPpl--) {
            YUEGrDc /= wVlooDokqoCd;
            nkqioxW = wFqGNfHCjFQUXH;
        }
    }

    for (int BUVqwrrl = 633939712; BUVqwrrl > 0; BUVqwrrl--) {
        UnJFoYoywzCRYwS /= wVlooDokqoCd;
        wVlooDokqoCd = kCEpB;
    }

    return ybTsthmYUUd;
}

string eEDVUbtNYtc::DAFGcoWAvVDHAW(string ygAnrGVBzBYUPFeD, int lwdqdh)
{
    string mHjlZlbSY = string("tClNkhjgflsexbuTpiZJGgJycyEoeLhygxFinuDsQETDHqMTpaZqqiyiQJxsEnXSQnvYSvETNAxnaWmqtTQjeJadTmOoTjVBAgZzHNkpHdzOObvYllkWiXhFgFabyVgvIMiCvQEUVthCGgfKieTuVGMozVqjkCYImDVOwXjVTCPlAVkowQWYIaXypTuQKqSiGFbLCPtqdUyqdkuEmDFhjmGQsVymLOqV");
    bool wXyBIl = true;
    string TVdkzJa = string("VqfVzKrrzsEEFjUJHSYyvdgGVsgYbFPDOCnkYhghGkUzhYJRfWjvhcvjFHxzUKfgpdRpRefSqfOSdoaKrUiZGlGwUAeaYDEKsEbBnVwgJobsOsOMbwHqoLvpOeOrBowBKKycXgxGkugzdwObawPfvcABuyMyNHcaQyRccUooAHWcKwEvifnwJtIXg");
    bool NwaPZpYJcawi = true;
    int Izuzduf = -1729088573;
    string NKPdNAfUT = string("KFpkjiYfcInAudMrOyseXrVrUygpLMltOibyCqOZmexJKRWaQFlznqRlOEKjgonwlBMLJJmOfExhhOBJtkEbTBRtdwegZqbyIZUSDoZKgkJsMyCfaTwVKAMjsNkkhmTYzwbRKiIzGWXMpFaAzUlLjwFMyuJtttKvwlUwAcHZXbeqDcMtGCElbgcXXoZudVDIORZtQfjbyTJxEIHBo");
    string GmjQlPG = string("pHkqKHHXoTHOeWSGoTnakKfJtGaumTOqKUqCjKWuylUgmErhgpNFqNVFWIUgUyWHjdXcJxUGVjkYbfBexIsxxuyMtnbDgKBwdwdQkatwnIVIoubdNJpbxnGNaHlJHlsRLyXcnVDetyOaFzLdqurUsYbjFzSwINzlwpmsE");

    return GmjQlPG;
}

double eEDVUbtNYtc::HFOFhdmFpFJrkD(double LhyJzjx, double GSncLqYNt, string LwMaTchLipO)
{
    double YxBlfEHDtC = 508540.5290696409;
    int wuIStxkshZcdQLq = 477630515;
    bool jMvtlaHI = true;
    int hZphwPAM = -1929588666;
    int faxJie = 513020591;
    int ZXGIVfsIZK = 588321495;
    double BKmIyjwbsQuExAYf = 295268.7893797416;

    for (int jceSYgZTdYTybI = 1582814094; jceSYgZTdYTybI > 0; jceSYgZTdYTybI--) {
        faxJie += hZphwPAM;
        faxJie /= faxJie;
    }

    if (ZXGIVfsIZK > -1929588666) {
        for (int YVogrUtqWk = 481590614; YVogrUtqWk > 0; YVogrUtqWk--) {
            YxBlfEHDtC += LhyJzjx;
            hZphwPAM *= ZXGIVfsIZK;
        }
    }

    if (faxJie < 513020591) {
        for (int DVZrRIMmgv = 1542176997; DVZrRIMmgv > 0; DVZrRIMmgv--) {
            continue;
        }
    }

    for (int gojfNViO = 1933909408; gojfNViO > 0; gojfNViO--) {
        BKmIyjwbsQuExAYf += GSncLqYNt;
        BKmIyjwbsQuExAYf += GSncLqYNt;
        GSncLqYNt = BKmIyjwbsQuExAYf;
        GSncLqYNt /= GSncLqYNt;
    }

    return BKmIyjwbsQuExAYf;
}

bool eEDVUbtNYtc::XTDJuUOLyvwq()
{
    double ztjxMepHNV = -208789.53088385862;
    bool scHedaURFoujNZYS = false;
    double bxfcCOUR = 529877.6593182104;
    int YLQyPXLqWk = -1235763950;
    int fSFtTJbLYpuBIIDi = -627315777;
    double SUvcU = -599252.5186474184;
    int BpCHmlfHAIKCJ = 1088890728;
    bool vasvnlgrPwKzgvkW = false;

    for (int gTFIF = 1317987827; gTFIF > 0; gTFIF--) {
        fSFtTJbLYpuBIIDi += YLQyPXLqWk;
        BpCHmlfHAIKCJ += YLQyPXLqWk;
        YLQyPXLqWk += YLQyPXLqWk;
    }

    for (int JoEjHaAKfovwAj = 632422625; JoEjHaAKfovwAj > 0; JoEjHaAKfovwAj--) {
        YLQyPXLqWk = fSFtTJbLYpuBIIDi;
    }

    return vasvnlgrPwKzgvkW;
}

string eEDVUbtNYtc::ozMMHQrCTWP(bool mxwRaTno, bool cJGFlU)
{
    bool ooIlzW = true;
    bool qppVzH = true;

    if (ooIlzW == false) {
        for (int FFlqUNuxKpssRt = 1309071652; FFlqUNuxKpssRt > 0; FFlqUNuxKpssRt--) {
            ooIlzW = ! mxwRaTno;
            mxwRaTno = mxwRaTno;
            ooIlzW = ! mxwRaTno;
            mxwRaTno = cJGFlU;
            cJGFlU = ! ooIlzW;
            cJGFlU = ! mxwRaTno;
            ooIlzW = ! cJGFlU;
            qppVzH = ! ooIlzW;
        }
    }

    if (mxwRaTno == true) {
        for (int ifAxeXPwTtzVBgns = 166476743; ifAxeXPwTtzVBgns > 0; ifAxeXPwTtzVBgns--) {
            mxwRaTno = ! mxwRaTno;
            ooIlzW = ! ooIlzW;
            qppVzH = ! mxwRaTno;
            qppVzH = ! qppVzH;
        }
    }

    return string("qWbmXZBHTwhazCNSXBmnHjPRHLmLqjASwOKItmvhLSTAjCPPLaRJtPOCslgAuYwJPMPlopkcOxoYzrQRanylRxBoOQUNiaiHJjXinGluuDwwlBhCQEqZQgKkeHkplSECBYYJtgMPENVJkzPjcYTEaSHptZjrXGLsLhIKdAHZHyOIfmjvZDCTejRKgXXbuzhlsoAHhbnmWjydLVpzKiJgTxDON");
}

int eEDVUbtNYtc::kYMJmI(bool piafVip, bool uDxEzvh)
{
    double lEdiRHCdJsTMqz = 268365.41543661855;
    int XUOVG = -1673562898;

    for (int dSCUN = 856145111; dSCUN > 0; dSCUN--) {
        piafVip = uDxEzvh;
    }

    for (int OAogpa = 529932001; OAogpa > 0; OAogpa--) {
        XUOVG += XUOVG;
    }

    for (int pIlThQ = 441511682; pIlThQ > 0; pIlThQ--) {
        uDxEzvh = ! uDxEzvh;
        uDxEzvh = uDxEzvh;
    }

    for (int lmTLmfFol = 1196419590; lmTLmfFol > 0; lmTLmfFol--) {
        lEdiRHCdJsTMqz = lEdiRHCdJsTMqz;
        XUOVG += XUOVG;
        XUOVG -= XUOVG;
        uDxEzvh = piafVip;
    }

    for (int pIZjN = 732739118; pIZjN > 0; pIZjN--) {
        uDxEzvh = piafVip;
        XUOVG = XUOVG;
        piafVip = piafVip;
        lEdiRHCdJsTMqz -= lEdiRHCdJsTMqz;
        piafVip = ! piafVip;
    }

    return XUOVG;
}

bool eEDVUbtNYtc::AVyUWyJo(string BEJDroJSJuivsR, int NXzduxVjODr, double KcAXBA)
{
    string yCYZVUosVU = string("RfunDFMrTwibKlGDvbhUMIxZNAaZMfwpWpdZbpWcqcpvepSFAeO");
    string nBLwLVZTzhXeLSjX = string("msVzjQVCpXKqxDgoesRvHmryzcZJryUulSBuVGuwhDkcaqgmvxPpLcPHfmWKlQDYRkOMzfJxBADPjhMxyzgWdmmXwdHNpSpaVbgVckpTCsuLuTEmWuLkHfMJicUVaiEiyMhPvsQYMxAcjoFAocMmnQiCOOvwUZbfxMihrgSUaDBzCuDRZ");
    string oEpTRBZkDPuboI = string("RxXPpGoHuiplioeToNLKfTgWrRsQrSytUUJOoHlbwhXdIDtAXpvoGRjBZxBCjdoqXoYhtnKvPOKrmOcMfmSgyYzPrOmfYvCltqFfFWllKFuDUKHKjkTiUqRqaDMmMUavxDunrNMCFXvWnbAsAxCbjfCccEmhS");
    double raERrBvx = 267840.0952908823;
    int rClmG = -1634854334;
    bool ynFtGaiGBpBLKGq = true;
    bool KusQgpuWWzXcS = true;
    string wCuRX = string("NCniMnwWzbxJeUSsWeYSrYMdcSvGXAKmMGxoLXyUzQBOIEgRyZxuMhaXiSvhrsOnMkBBneJxwBpjGvtbqgVdmtnnuoZwLCNGNLDaNVItyTLmhTUnhpyCdCCvUjtYYpksK");
    bool hVPyrs = false;

    for (int fFFEmZocFIOqyNGa = 1133512275; fFFEmZocFIOqyNGa > 0; fFFEmZocFIOqyNGa--) {
        continue;
    }

    for (int DquFnyUXpZ = 783656148; DquFnyUXpZ > 0; DquFnyUXpZ--) {
        continue;
    }

    return hVPyrs;
}

void eEDVUbtNYtc::LsbKs(int nutVuF)
{
    int jwWxCcjFA = -1443371239;
    double lKNkGmyaQLDYXZz = 667909.758072895;
    string NLfZaPDhIQJu = string("iFNtMRcJxUATdUUTEtGQkRHwmAOJpahNMvAPBmDhmcoIqrCkPWKEEogcshjCjftALOVFnZVRXNEDsCeWaysRhwniZvpjVmmAzqbmczQbYOYIUYnVWFQjLFUOAhNdBygoIgPHnjHNEwmuXnVrhsFMIVSEgQCKmevVvElRBTNEuRfBICozp");
    double UvXZKsVshbL = -988521.9765676551;
    bool ZXGuFmlcSSdtktyD = false;
    int cuBASZTvYz = -204176316;
    double wvNQUSYXHSjQ = 371621.0387284445;
    double ogCGVAH = -278957.6160768761;
    string FwIeIlSIvlglyzV = string("RsFtAOayOBiwbuzibheMXPySAFSLOEulhJkhUuWXdTjvhRFxamUThmsqDLiRtQzJdhLzieGQdTyZQgGtTAtcpvNaESYAtFOLQNfdExsDlvJGUjKZLTsONtZaKXlRdFGlqAAADVbUPJhrGyDdBcXaaFqnKgOximrhiTlqkhkeUJAcOubNuySjRLMWxeGxlBOcKyrxfedNYobOBHnRnzByAkjfMDsGbEKCfV");

    for (int hnhPbzzhkE = 427912610; hnhPbzzhkE > 0; hnhPbzzhkE--) {
        wvNQUSYXHSjQ += wvNQUSYXHSjQ;
        jwWxCcjFA *= nutVuF;
    }

    if (FwIeIlSIvlglyzV >= string("iFNtMRcJxUATdUUTEtGQkRHwmAOJpahNMvAPBmDhmcoIqrCkPWKEEogcshjCjftALOVFnZVRXNEDsCeWaysRhwniZvpjVmmAzqbmczQbYOYIUYnVWFQjLFUOAhNdBygoIgPHnjHNEwmuXnVrhsFMIVSEgQCKmevVvElRBTNEuRfBICozp")) {
        for (int xCAHLLq = 1439416742; xCAHLLq > 0; xCAHLLq--) {
            ogCGVAH = wvNQUSYXHSjQ;
            nutVuF = jwWxCcjFA;
            ogCGVAH = lKNkGmyaQLDYXZz;
            lKNkGmyaQLDYXZz += wvNQUSYXHSjQ;
            cuBASZTvYz *= cuBASZTvYz;
        }
    }

    for (int TtlOcOynTgWYAc = 1466792578; TtlOcOynTgWYAc > 0; TtlOcOynTgWYAc--) {
        wvNQUSYXHSjQ /= ogCGVAH;
        UvXZKsVshbL -= lKNkGmyaQLDYXZz;
        lKNkGmyaQLDYXZz -= ogCGVAH;
        UvXZKsVshbL -= wvNQUSYXHSjQ;
    }
}

void eEDVUbtNYtc::QOsYYWzjunj()
{
    int FBzRaxWvC = 1362488352;
    string AVyxgMEPORK = string("bCuEZGYTOlhuxumdVzTNeXEiZByyYGtrqCuUqHpMASMGoPoZSLSirwOCompmMBqynQHHqtyjrAlJTGslEwvHCIgzTHbwHFBzxkDOowxLOkbcHbqdstswHmlGzICyLAxntfQVMiqNSPdkMGWbnIvKJc");
    int AYgnsifYHddrQSV = 1186540767;
    int DtHAtfejoLgGFhO = 2013348780;
    string DEmJbFcsrbOce = string("WoGXzLvZvpXMzAkPLTDiyKVDRiZZHMKVIRbmQfvSSrpVIJXnehvjoGBfsUOffiVvkxyIVJPHSGomeBmvJwvpayykdCLRImMzbBgVgMjhEANKIBzDUADsKxVCRXdkSMwKeiTmmdrEFnNOyEqzwgF");
    string HPLeQtqO = string("kyIssVBvZjcJBRHbAsRTLKAKMldDcFAzyBGNybbgAeJiUmrBzomMxATNCNTnpHlbdYITjaNVvNhHMNlKgyFkzhLP");
    int BlLICMObWYufSq = -945872795;

    if (DEmJbFcsrbOce == string("kyIssVBvZjcJBRHbAsRTLKAKMldDcFAzyBGNybbgAeJiUmrBzomMxATNCNTnpHlbdYITjaNVvNhHMNlKgyFkzhLP")) {
        for (int DQxShzLT = 1507700367; DQxShzLT > 0; DQxShzLT--) {
            FBzRaxWvC -= FBzRaxWvC;
            DtHAtfejoLgGFhO += BlLICMObWYufSq;
            AVyxgMEPORK = AVyxgMEPORK;
            HPLeQtqO += HPLeQtqO;
        }
    }

    if (DEmJbFcsrbOce <= string("kyIssVBvZjcJBRHbAsRTLKAKMldDcFAzyBGNybbgAeJiUmrBzomMxATNCNTnpHlbdYITjaNVvNhHMNlKgyFkzhLP")) {
        for (int hXEUOVUPObAOC = 1992088665; hXEUOVUPObAOC > 0; hXEUOVUPObAOC--) {
            FBzRaxWvC = DtHAtfejoLgGFhO;
            DEmJbFcsrbOce = HPLeQtqO;
            HPLeQtqO = DEmJbFcsrbOce;
        }
    }
}

int eEDVUbtNYtc::AZLvNi()
{
    double MhSlYxRJNtw = 255266.5794982495;
    double tUhUahmC = -369018.6465908817;
    string XDEuReynaebEpEy = string("xweaZaGEbqzHSoIUCiRrkzSILQL");

    if (MhSlYxRJNtw >= 255266.5794982495) {
        for (int XDlKWXi = 556745783; XDlKWXi > 0; XDlKWXi--) {
            MhSlYxRJNtw += MhSlYxRJNtw;
        }
    }

    for (int kRkxUiDYsW = 1807568901; kRkxUiDYsW > 0; kRkxUiDYsW--) {
        XDEuReynaebEpEy = XDEuReynaebEpEy;
        MhSlYxRJNtw -= MhSlYxRJNtw;
        tUhUahmC += tUhUahmC;
    }

    if (XDEuReynaebEpEy > string("xweaZaGEbqzHSoIUCiRrkzSILQL")) {
        for (int oCkeDygT = 2067348101; oCkeDygT > 0; oCkeDygT--) {
            MhSlYxRJNtw *= MhSlYxRJNtw;
            XDEuReynaebEpEy = XDEuReynaebEpEy;
        }
    }

    return 751113745;
}

double eEDVUbtNYtc::IcshmVVbVVuCNg()
{
    string WZvKPGDO = string("KildIbrUmcWpdFIoQYXPWcZGIptnkWPtZmkGiTpRcueDlhHMtuzpGrFauuiEAhwOMjQWxiuuafKIQdoyhAJaNsGxpXdoQXdJQmjPBFfXYIqWpGvZXYOAlKPBRRYSyHYawNBuNHolPNekfHnqqVyAnaJVtnszDqgBSyWTcAUYTtFdyvZwVTsXwLPgZfjBasjUASLnCwGbTHFuzPyMjneiqqwTCvsAulHY");
    double VSAgaFvxMkc = 976647.8125797379;
    double fTfvWXc = -456159.7382553702;
    double ZnqVSsxqzL = 129690.20561054412;
    int MRJNoiN = -1156589661;
    double wHCGyOBm = -746245.6264282602;

    for (int LvDGlSYC = 583144939; LvDGlSYC > 0; LvDGlSYC--) {
        VSAgaFvxMkc *= wHCGyOBm;
        fTfvWXc *= fTfvWXc;
    }

    return wHCGyOBm;
}

string eEDVUbtNYtc::mjjcHCRsdwExZz(string ZZLtLfPcRPWN, string IBNqUbAFUoMXIMbR, bool lejDGOSV, bool hurzaM, bool TTukQcyJApJ)
{
    int cbXSvcu = -1840728283;
    bool YTGPVKfyhS = true;
    double TPEVrExOY = -406313.08694791794;
    int kJNhUkIikzXVt = 98389781;
    double EoJTc = 810483.6721041299;
    int EBkuVZYJk = 44810681;
    bool YQjPKc = true;
    int zZeXRmijnCLPv = -1065267756;

    if (lejDGOSV == true) {
        for (int RJkUoqOxTCFz = 1886240193; RJkUoqOxTCFz > 0; RJkUoqOxTCFz--) {
            TPEVrExOY *= EoJTc;
        }
    }

    return IBNqUbAFUoMXIMbR;
}

double eEDVUbtNYtc::wexzqaNEHX(string IOKGVgmtVSn, bool mWQEERgkDrfp)
{
    bool wVsvevRGJu = false;
    string IfIfp = string("aRjhwndwfcGRffpIoGgbJvxKSQOpkrZPVlXPlhuagyxsvoYyYNARmUecsocuhPFgfasvhwVZJJGbhViuPfMYJfWrAFNuroUWUkxWlyoCDyNtrmqzuQiobNqxYBHSHDH");
    double PswgSjYai = -967055.6010382934;
    string kzzwGpuBw = string("sdCaVdUSCiCZCTfWvphUbzJQWKrGBxfzQRJLOwNSwcjObUsZswQaSZzzeCAseSrbyYZ");

    if (IOKGVgmtVSn <= string("aRjhwndwfcGRffpIoGgbJvxKSQOpkrZPVlXPlhuagyxsvoYyYNARmUecsocuhPFgfasvhwVZJJGbhViuPfMYJfWrAFNuroUWUkxWlyoCDyNtrmqzuQiobNqxYBHSHDH")) {
        for (int ygpbGpbsXvJt = 898913701; ygpbGpbsXvJt > 0; ygpbGpbsXvJt--) {
            wVsvevRGJu = ! wVsvevRGJu;
            kzzwGpuBw = IfIfp;
        }
    }

    for (int jSBwdWzQO = 582757329; jSBwdWzQO > 0; jSBwdWzQO--) {
        kzzwGpuBw += IOKGVgmtVSn;
        IOKGVgmtVSn += IOKGVgmtVSn;
    }

    if (kzzwGpuBw == string("sdCaVdUSCiCZCTfWvphUbzJQWKrGBxfzQRJLOwNSwcjObUsZswQaSZzzeCAseSrbyYZ")) {
        for (int fWMJPW = 7431944; fWMJPW > 0; fWMJPW--) {
            IfIfp += IOKGVgmtVSn;
            IOKGVgmtVSn += kzzwGpuBw;
            kzzwGpuBw = kzzwGpuBw;
            IfIfp = IfIfp;
        }
    }

    return PswgSjYai;
}

bool eEDVUbtNYtc::kIXZtGnUpJ(string jXxyrhfGt, string oDAvoIa)
{
    int KiRowuyZcFwqNKQc = -536083500;
    bool vCDIHmmiyVowmWd = true;
    bool TsPyRTtYlGwjjJC = false;
    double RWINKUojavFA = -943025.1444260527;
    int ldXkurudBnyOIJf = -1960881346;
    bool cojjcvJzuHIFMUzn = false;
    bool zkHUyzhSH = false;
    string KLoreTIg = string("RkurhokXjzdwldmWnMpKckxSJepFcGqkloFJJSyOtxbCnNQuNpgN");
    int iFMibQiFXwUZ = 161226921;
    bool aHxBfZbkL = true;

    return aHxBfZbkL;
}

bool eEDVUbtNYtc::PSpDalns(double QNXlelvfL, string IKkWaUkFcC, string wRavEBGDZgfP, bool HETGHMcYJc, int kZYRCj)
{
    string XUAMS = string("pHcxKiDnUeulxVwwaFtezqImxwbWwXYrHdTxPuKNiTryoReTRynqdTcqilZnKlogygLwALrDWyaWohbpYJqWTkAsSRpAEsZFfhvAdTmRngcCuVwSkJsACWOKWLqDYBdSKFXyzUSaffqZfcnGyKwMgobSWAFXeDgSeORfQcwgbvFkyNculnlDFivGCLQwFqtvdtcJuhYCzyRBCusbvLdocWhxoAKWnpnyVgbwgcksqxaIXcoPnIlLuVyVEJ");
    string fEeXf = string("OrYoxwpwOeYBbIXGUoqlEXKiEMlKAWiosjciLKaEqtgCjiqiIWeOSZjGzRNPSYEbDnHKWCcvcpWPnbqtlxFcrbYChgRMFikKKHTAOetMroBymFhWgXJzKkTpOkoFamXqZZYlPVgBbywCJEABySatVzPQOrXqdzAcwJKyicLurEHygUWmCSTBxNfutxSqdSKFxaBRdDJMinjLPSrqbfuvEsGiGUzSbzgKOySieNSjbfFejBUDiEZevihhu");
    int BMpoDlUPxKHrwwj = 462449326;
    string hISNWleiI = string("BNVHurnVrQLHGsFPSfZtllQBmjSzVkPgHzmmDZFrfpDVUBvbWvrrUEZiHdjtjSphevPGJpUsdJSHlRaRXqdFADgEIjVdhctayJdnjCIsKlQriQkJeVkxqBFNrIwXkNyszzeaQtzbevKnBWDKeBkYtvdxuwQYQaWJeuvyzagKOqb");

    for (int YQEoY = 346123850; YQEoY > 0; YQEoY--) {
        hISNWleiI += hISNWleiI;
        kZYRCj += BMpoDlUPxKHrwwj;
    }

    for (int DLrbpMjfqSnn = 1338102882; DLrbpMjfqSnn > 0; DLrbpMjfqSnn--) {
        XUAMS = hISNWleiI;
    }

    if (QNXlelvfL > -58356.62918132222) {
        for (int bLsBOBjNNOzVb = 786193186; bLsBOBjNNOzVb > 0; bLsBOBjNNOzVb--) {
            QNXlelvfL /= QNXlelvfL;
            hISNWleiI += fEeXf;
        }
    }

    if (hISNWleiI >= string("MWPgSzrFhAUwrsknnSqXBIvzPIXhLBITlopsxgUuKcVBxoquGIWjhhIaogUGyRza")) {
        for (int mLSYTnRc = 1483605643; mLSYTnRc > 0; mLSYTnRc--) {
            hISNWleiI = hISNWleiI;
        }
    }

    return HETGHMcYJc;
}

eEDVUbtNYtc::eEDVUbtNYtc()
{
    this->nZLwrNdy(true, 817335324, true, true);
    this->pGssQnwTwUPx(false, -961842.2502467805, string("BkRxRAcEjgiobGzamGqhgRjFYQJFydyzPmSrLKcgjfNICxHLJPxvzgvOOpCLXAogIBLMeIrdBpgrkpLlujepKCXKYqXCelMZSOrHzinibPDsKcApejsnDVtUPPXTNWPDWapiNZzTNkpvSIPvTadgFsBWkhkMwoBfynwVJqazsKwxoUvkYKoYgix"), string("yYLmZUpuQtkLfwtgLcvbzbFlmDupERnCTiwuTaeTBwDDFcmFcHtOVBdkPqlUiozgiHpUMbXMiOSqPNSOtYjhtKEDjDrARPvkuePBJhJSOpBiUxmrHoKuvlIuUDznfSKqVjfvPMhipnbJUyBZbMJWCKaHyQyoTzwn"), false);
    this->oWulxAg(-1227182089, 167822.22636748612, 283515.67815531685, true);
    this->kWuQd(true, -684938.5721738777);
    this->DAFGcoWAvVDHAW(string("zOBSCNYvKkbpECkpTebUxrdaMPZRQmvxczIGQxpPKxgdPQlLwKakiBSudHReqveLSqgePQLwzZEglixImWfYTcqiKgWLceEWTlMApwdHDXiqgWwccUiXiCTNeUqiDlCikjUjUHXjKNFzKmtyUrVQMTILZBnzKCxzeLqvEPQbUAvkgiLGYxDtJbIuhORiwfxxZPKUlwPgDszdTsqWaXqTsrGpHHExRkJMvyymbFmysNSHPoXJGGvnbXU"), 247212704);
    this->HFOFhdmFpFJrkD(-756752.7499869085, 972222.5970566074, string("bPCBvlFugYHuFxPgvcKGTGqNvnDRRhfbzetzCxUcSzSyBOrrauCNTHAGNGfQSdRAWJVQwFOcKASSZEpgihyymUbKWeLVWZCREHhPhJhiaLQYBRhMKDPTsWMZNTrfedXjEtDjDfahTeFLLzlajLuKXPAXptQHwDoeMcimFwGQiHssIqpUzBCKZVsEDwCMNFMJhyAIwVmiNzfnGuyYgpgVtLEmhuxodhaWxLbGJq"));
    this->XTDJuUOLyvwq();
    this->ozMMHQrCTWP(true, false);
    this->kYMJmI(false, false);
    this->AVyUWyJo(string("PEvBMKseJDqAcZpRkqUBTmZRxLThDpYvlIrHxAaTxhyycPpULVxGTVRqnoHMnpuyRzjTiJdVsvFwjWDqzraMHwVZVKWZJsIzvMSokuDEnRyBkdnIaspTrKBJfmTOcrLjmXNihDpwWoihmHIhMpxASfxNneYtzVbXZSIwqgCVmPDudglVnYgDricjuDRzFbRnlsqoLUwa"), 498768342, 877506.1851678118);
    this->LsbKs(930005523);
    this->QOsYYWzjunj();
    this->AZLvNi();
    this->IcshmVVbVVuCNg();
    this->mjjcHCRsdwExZz(string("HvxkskBsFoNDTCHkHBYVrPhxVsnxHhPRBcEkCUCpEXEPiMacAyrwcmFgxIJYyfsMlnET"), string("sJDzFtoHEeWAPPftzLccqwlRggHpQQoOJcoPIqhjBZCCVeiEPdLTaHpHOzDspKlyVlaMLVvuLrHuYUiyLTCngNaFhHJPOcnvmHfPAeSgDfethyfAKGtKdqXZXlerPWggBjZixVotmeIWtruKmTHnY"), false, false, false);
    this->wexzqaNEHX(string("LIgxOHpMyoADbknfJPmuLVnhwSHavfBCzDuFaJoYoUzBUWHbInWCZuZXyDZlUtzbvtLJCuYuiaBNmCaxfiRATGyopGYEKbAPkVErTVUGLIoMaXqyYhCmkIvVsVMveOSOAeriDMHKnHuYtBusrgOxTvxbmIrwXfjjTXBOzYIqdkDtkPPziSmOZhpdpNdrEznjpiKPHPBhTMQsBIlKNUHCUKEhKMyPnGthhXxAaVXGnITPiUwqdDEuvlAf"), false);
    this->kIXZtGnUpJ(string("TUTAxatUcZXPgshOzZkQblqWipbySxMvIMCSBjGJixjifeLdNXLBsnBHbodmNIDVlMVFYpDY"), string("AkyAIhdnOobEYKnRitxIwgnsEMVPvDFxIoHGZxNLVnQCcfkLazIsvaeEmmacZWTdmxzkXgjHJsrOLqThjsIXThBPxqnEqoaHtLTSfybXoGsazflZgIsokehFhXBvVexzMejuhDcBrDrQnkM"));
    this->PSpDalns(-58356.62918132222, string("xPZRyIlRBQEpznzYObanjfewDYWkYcksuUbRLSlLzCQYxVeCZIblBYOVQZmjkpgXetgFhuzoTNMFRKgNLFKodZRZPZLqSoBaiYGxkZGEKXOlqyTDDWcnDQSpntGpOJegJjJaXWDMMBYwxlHKhfHxYJJjEXMxOXojDDgcBSNYKtFYYwuHqhifCqXhHZvSOsoufHcoSaoD"), string("MWPgSzrFhAUwrsknnSqXBIvzPIXhLBITlopsxgUuKcVBxoquGIWjhhIaogUGyRza"), false, -1563607006);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JqbTdqMHgLObTs
{
public:
    string EQKpXupkIDU;
    double wLIwO;
    int dFWPGZvqBfJXxrn;
    double xijsb;
    bool GfglzUDmZGYSor;
    string GzlfbmeIP;

    JqbTdqMHgLObTs();
    string HSSBVLz(bool RzapJpuqPqTPi);
    int PnKEzYDVc(bool fGPKSvYlCLrxHn, double jjSeZQNT);
    bool GUWoZThWxdpJw(int oVlOAMYpS, string OuNCgqqyff, bool SHUad);
    string vlEJLwh(string CnEVQVhom, double wKbmyDe, bool RbQIxKzW);
    double poBYPl(bool qDBdHnmGY, bool njaKwBWSZgYvrQt, bool aFDPB, string uCgHh);
    string IpWDp(string XRzCNLwvobIlPN, int CKRBPRSPnNkTwzi, double MVxuHCMuJykqdSCJ);
protected:
    bool vRBEc;

    double AIEpNrzPSjWuyfN(string jEdyPzVP);
    int EhBrvH();
private:
    double fVQsaIYcMVu;

    void NPqdpXoQnWgxIE(int gQNlyVRcj, string jhYBayHebnVJ, string UdCEdI);
    string OiSAdpJELOp(int iBAwv, double VStHXXRc, int rkMgT);
    bool oGgnuEDnNMaBhtDb(double liBondyg, string DyIoCtUbeoWHF);
    string zipEsbiYd(bool qcGKVMHZINotAKqu);
    double VlLvxSUQhj(bool TKAVo, string gTMBkfROKwu);
};

string JqbTdqMHgLObTs::HSSBVLz(bool RzapJpuqPqTPi)
{
    double fDjtLKoKXj = 642634.5123559415;
    bool ECDrKHZnagPh = false;
    double pqNwJFqxkvg = 461477.9981818417;
    double TUjZWJIocDGFcHH = 288892.94540308864;
    double EIUZH = 228841.83304719275;
    double gzSUvfTIbr = -327193.88808408956;
    bool cNaaJBsqnr = true;
    int hoMCBJaL = 364660701;
    int JsieeiodcumsZr = 185184355;
    string SnSktue = string("SIxDsTlngVZOHUPhooAgcywZPRLEAQZjOyuTWDkLPlPEesTsTVhXxuvOGnrkEVRbcMpeqIvKkHeXXH");

    for (int lxdEmd = 312563057; lxdEmd > 0; lxdEmd--) {
        pqNwJFqxkvg += TUjZWJIocDGFcHH;
        pqNwJFqxkvg /= EIUZH;
        ECDrKHZnagPh = cNaaJBsqnr;
        RzapJpuqPqTPi = ! RzapJpuqPqTPi;
    }

    for (int DoMrNNRRgiZUh = 753409616; DoMrNNRRgiZUh > 0; DoMrNNRRgiZUh--) {
        TUjZWJIocDGFcHH -= pqNwJFqxkvg;
        cNaaJBsqnr = ! cNaaJBsqnr;
        gzSUvfTIbr += pqNwJFqxkvg;
        fDjtLKoKXj = EIUZH;
        cNaaJBsqnr = ECDrKHZnagPh;
    }

    return SnSktue;
}

int JqbTdqMHgLObTs::PnKEzYDVc(bool fGPKSvYlCLrxHn, double jjSeZQNT)
{
    string GLGfKcteCcUlHMA = string("gSzBEEvSZZTxBJSWaWB");
    int cxsYUgmxDB = -1371875423;
    bool bOPki = false;
    string ZjfuYrbnMFQdHTw = string("AwPdllWydSiRFXlBxbjhMxnsnzYQBVJrcKXtntYSSCxfqhxQksGBYHhTYQsCDAgOHHUkLWLYjEOfMteHtNTznlzMcqTQHuvSAvLljvEBlicHbjkLfQCcXriTdOEebTATQIraKsrgymAzavLBxESrfTvTzFytrjLzqwcUKVvYIJunZyLehQkxC");
    int PhLHRwKxaWRjOKt = 1878773064;
    int uUVyepOnxy = -2018701111;
    bool PNCGRDGYjnUUBcnS = false;
    int sNkIYbEvxLz = -2099008596;
    string jrChhimb = string("GsPAvcEjZtqYHSNtdZRAUsxuEApXMjqaxbSDhmYhpbfQZIfCyFhzUIWjEfgPRZDj");
    bool DhiVSvv = true;

    for (int xCUJIpqLjva = 1390626222; xCUJIpqLjva > 0; xCUJIpqLjva--) {
        ZjfuYrbnMFQdHTw = ZjfuYrbnMFQdHTw;
        PhLHRwKxaWRjOKt = PhLHRwKxaWRjOKt;
    }

    for (int LeBvhHlTWHtqmbP = 281437344; LeBvhHlTWHtqmbP > 0; LeBvhHlTWHtqmbP--) {
        ZjfuYrbnMFQdHTw += jrChhimb;
        cxsYUgmxDB /= PhLHRwKxaWRjOKt;
    }

    if (bOPki == false) {
        for (int NcYztQ = 532090945; NcYztQ > 0; NcYztQ--) {
            DhiVSvv = bOPki;
            bOPki = ! fGPKSvYlCLrxHn;
        }
    }

    return sNkIYbEvxLz;
}

bool JqbTdqMHgLObTs::GUWoZThWxdpJw(int oVlOAMYpS, string OuNCgqqyff, bool SHUad)
{
    double IvkKAeMRvlar = 247659.89652976612;
    bool azpXzHbg = true;

    for (int OJFli = 1327770085; OJFli > 0; OJFli--) {
        azpXzHbg = SHUad;
        azpXzHbg = SHUad;
        IvkKAeMRvlar += IvkKAeMRvlar;
    }

    if (azpXzHbg == true) {
        for (int RbCCsVZHPVlM = 1524377391; RbCCsVZHPVlM > 0; RbCCsVZHPVlM--) {
            OuNCgqqyff += OuNCgqqyff;
            SHUad = ! azpXzHbg;
            SHUad = ! SHUad;
            OuNCgqqyff += OuNCgqqyff;
            azpXzHbg = azpXzHbg;
        }
    }

    for (int unmOeYoHHA = 566855455; unmOeYoHHA > 0; unmOeYoHHA--) {
        continue;
    }

    for (int DoMag = 1501594311; DoMag > 0; DoMag--) {
        azpXzHbg = azpXzHbg;
        oVlOAMYpS += oVlOAMYpS;
    }

    for (int UwvXYFkDtM = 1758035731; UwvXYFkDtM > 0; UwvXYFkDtM--) {
        azpXzHbg = SHUad;
        SHUad = ! SHUad;
        SHUad = ! azpXzHbg;
        OuNCgqqyff += OuNCgqqyff;
    }

    if (SHUad == true) {
        for (int bDChwOXvAtIHjlyi = 405793558; bDChwOXvAtIHjlyi > 0; bDChwOXvAtIHjlyi--) {
            oVlOAMYpS *= oVlOAMYpS;
            SHUad = ! SHUad;
            OuNCgqqyff = OuNCgqqyff;
            azpXzHbg = ! azpXzHbg;
            SHUad = ! azpXzHbg;
        }
    }

    return azpXzHbg;
}

string JqbTdqMHgLObTs::vlEJLwh(string CnEVQVhom, double wKbmyDe, bool RbQIxKzW)
{
    double pgrJUFoHjaWyOrES = 381516.84636893764;
    string orlStIKrk = string("CEAZpjnuwPqlWSLkzwQKsjgwDFkJFkXgIlPBpPzJrlFUsfmQHayiRWKWeapUCuPHcNIjEwkLmWcGXUtRuvdRluRRQvwStQBdlAClcX");
    bool GYjdPcAXFIDQ = false;
    double uSMRbFScxbzhhvPJ = -922294.4940539028;
    int roMdlh = 92821438;

    if (RbQIxKzW != false) {
        for (int FVNPLLciEle = 1699957348; FVNPLLciEle > 0; FVNPLLciEle--) {
            continue;
        }
    }

    for (int AzJdCkGWmeYcEDA = 2110916342; AzJdCkGWmeYcEDA > 0; AzJdCkGWmeYcEDA--) {
        CnEVQVhom = orlStIKrk;
        uSMRbFScxbzhhvPJ *= uSMRbFScxbzhhvPJ;
        GYjdPcAXFIDQ = ! GYjdPcAXFIDQ;
        uSMRbFScxbzhhvPJ *= uSMRbFScxbzhhvPJ;
    }

    for (int yJNqIq = 1907561060; yJNqIq > 0; yJNqIq--) {
        CnEVQVhom = orlStIKrk;
        roMdlh -= roMdlh;
    }

    if (GYjdPcAXFIDQ == false) {
        for (int YRKqUnXOHaQWdNYW = 2093504242; YRKqUnXOHaQWdNYW > 0; YRKqUnXOHaQWdNYW--) {
            uSMRbFScxbzhhvPJ /= wKbmyDe;
            uSMRbFScxbzhhvPJ /= wKbmyDe;
            uSMRbFScxbzhhvPJ *= uSMRbFScxbzhhvPJ;
            wKbmyDe /= pgrJUFoHjaWyOrES;
        }
    }

    return orlStIKrk;
}

double JqbTdqMHgLObTs::poBYPl(bool qDBdHnmGY, bool njaKwBWSZgYvrQt, bool aFDPB, string uCgHh)
{
    string xbfhtyoXIvTzopP = string("YNpTxbSzLQDDsTGURrIAeapCbhPGvZxYbNVAYZHHNRGAgETQKxeGcIZNcsLzguhxNmSVVGPpiYVjiEpAmfFmFqWQcoRYstMSbqTqkdYTlkDQGoYmkQazPWemwprlNMzwTSiaPcYScQQagjDKYwEuWCEcQxggFSXKiHQuvAvisneSBrgwlBcuyvsoDUpwdnMuYpnBFNdWsjciiFhRVRFkUybltDN");
    string hIkRJbVUNF = string("HrNFFHbxcUCBEAoYMcZxPymazVcqqZLlBTbRaXNcJamMATuWWjutlWpatkr");
    string kzvpdgSsDdqOw = string("CAoPKeuxJQenGyZlRQV");
    int QggQrTZuq = -1659093746;
    bool aQxWOuoG = false;
    int BoZGBabuQZs = -868408583;
    string qVmFKCNMHm = string("heNWdtVlNYyIXchngwbsAqEobVwGfjCaOVykzMOFvHvhAxQsebXvNuiwCRymQWHEXlUXxlgeyEjSgULNyueMfFMkXkVFKOqTWYGbZXyDAIhWJfUeonbsdqTwrADCqeIsgNKPTTAzyrMsqgIYSskIkEuNSNQ");

    if (qVmFKCNMHm == string("heNWdtVlNYyIXchngwbsAqEobVwGfjCaOVykzMOFvHvhAxQsebXvNuiwCRymQWHEXlUXxlgeyEjSgULNyueMfFMkXkVFKOqTWYGbZXyDAIhWJfUeonbsdqTwrADCqeIsgNKPTTAzyrMsqgIYSskIkEuNSNQ")) {
        for (int bhcGhgPSYiorwvW = 1031742353; bhcGhgPSYiorwvW > 0; bhcGhgPSYiorwvW--) {
            xbfhtyoXIvTzopP = uCgHh;
            hIkRJbVUNF = xbfhtyoXIvTzopP;
            QggQrTZuq /= BoZGBabuQZs;
            kzvpdgSsDdqOw += qVmFKCNMHm;
            qDBdHnmGY = ! aFDPB;
        }
    }

    return 877059.0930874432;
}

string JqbTdqMHgLObTs::IpWDp(string XRzCNLwvobIlPN, int CKRBPRSPnNkTwzi, double MVxuHCMuJykqdSCJ)
{
    double bgYMLoZQ = -339225.00028771773;
    double UWcqVhmCUu = 1039167.2102744374;
    int mBGoYLqXfUo = 261543268;
    bool uPAqxpLoHTefu = false;
    double CksBse = 423221.07494208025;
    double zdnvUB = 574391.3078072309;
    double QACEOGXXuIcJgn = -681025.6470193212;

    if (MVxuHCMuJykqdSCJ != -251845.07250269756) {
        for (int iGJlYBJDdkUCJptX = 1290488713; iGJlYBJDdkUCJptX > 0; iGJlYBJDdkUCJptX--) {
            XRzCNLwvobIlPN += XRzCNLwvobIlPN;
            uPAqxpLoHTefu = uPAqxpLoHTefu;
            zdnvUB -= MVxuHCMuJykqdSCJ;
            QACEOGXXuIcJgn /= UWcqVhmCUu;
            CKRBPRSPnNkTwzi /= mBGoYLqXfUo;
        }
    }

    return XRzCNLwvobIlPN;
}

double JqbTdqMHgLObTs::AIEpNrzPSjWuyfN(string jEdyPzVP)
{
    int IulyhkQcWR = -1359753515;
    int eSmHU = 1990704334;
    double mylQiBIzVlRgHUI = 310018.4196362232;
    bool JwCZDMepPzaC = false;
    double sCONkEZCnb = -25293.267526284897;

    if (jEdyPzVP <= string("dPWTYSoPeovdwGEwlAFUtcBzWvMEeWlKdVwsoupJPaBpUaykrhZsQFXSByOdbFAtWNNlLDaLyUgWBkwAZyYdecchtDkEWzgSJySMYRZJusxvOvCqoSFfgtrYXribkpuotsYHeMGifdTNJYUoYdaTDfXbcelEPzhaEqCAbiFQXCRCXRuTvPVtwtTxXRtPWpXIgUcqtYYEKyUZeBpXgbadGimqTJaOSQbvuZWeuMvkTytljCQRmr")) {
        for (int OULTqkxkq = 1982392237; OULTqkxkq > 0; OULTqkxkq--) {
            mylQiBIzVlRgHUI *= mylQiBIzVlRgHUI;
            jEdyPzVP = jEdyPzVP;
        }
    }

    for (int MCHkYmqMxdtTrdP = 1974172176; MCHkYmqMxdtTrdP > 0; MCHkYmqMxdtTrdP--) {
        IulyhkQcWR /= IulyhkQcWR;
        IulyhkQcWR /= eSmHU;
    }

    for (int ZZCJdNpy = 2114369307; ZZCJdNpy > 0; ZZCJdNpy--) {
        eSmHU -= IulyhkQcWR;
        IulyhkQcWR += IulyhkQcWR;
        jEdyPzVP += jEdyPzVP;
    }

    return sCONkEZCnb;
}

int JqbTdqMHgLObTs::EhBrvH()
{
    double fntBjflAyKO = -820556.701585925;
    double kTcCvGTzBrY = -669530.4046119741;

    if (kTcCvGTzBrY <= -820556.701585925) {
        for (int DOqYYWySIYLbusHH = 627479275; DOqYYWySIYLbusHH > 0; DOqYYWySIYLbusHH--) {
            fntBjflAyKO *= kTcCvGTzBrY;
            fntBjflAyKO = kTcCvGTzBrY;
            kTcCvGTzBrY /= fntBjflAyKO;
            kTcCvGTzBrY /= fntBjflAyKO;
            kTcCvGTzBrY += kTcCvGTzBrY;
            fntBjflAyKO *= fntBjflAyKO;
            fntBjflAyKO -= fntBjflAyKO;
            fntBjflAyKO -= kTcCvGTzBrY;
        }
    }

    return 560107460;
}

void JqbTdqMHgLObTs::NPqdpXoQnWgxIE(int gQNlyVRcj, string jhYBayHebnVJ, string UdCEdI)
{
    int hUjmtB = 1235598713;

    if (hUjmtB > 1235598713) {
        for (int SFRUnziehTJqHc = 961932248; SFRUnziehTJqHc > 0; SFRUnziehTJqHc--) {
            jhYBayHebnVJ += UdCEdI;
            gQNlyVRcj *= gQNlyVRcj;
        }
    }

    if (jhYBayHebnVJ < string("pgVLtolxcTXbDOvzOkPxPSzINglqvLehzRoXZskBcqHqoWyEITzSdaLRwvqExHYVkUrKCFfOyyrpVRyOOmuvcPecVeStkMXInArPkOFCUdjKGHzStPFpAOiRHmIWOvHURpIHqPIYlxcgKeWkMJwwjBXCwBaHemqrTUotFGBgdhdLFsTmNAzMbxoiaiYCQhifPYRZTidsxPSLvIDayErYsJIQgDtiLfFxEdiJZUhyuAKiFufjA")) {
        for (int TLaRGqhVn = 1609469652; TLaRGqhVn > 0; TLaRGqhVn--) {
            gQNlyVRcj = hUjmtB;
            gQNlyVRcj /= hUjmtB;
            UdCEdI = jhYBayHebnVJ;
        }
    }
}

string JqbTdqMHgLObTs::OiSAdpJELOp(int iBAwv, double VStHXXRc, int rkMgT)
{
    double HVBcGeIqG = -503941.54126336606;
    double TbsdrPXyrGH = 858529.3531675942;
    string eyjShNgXoP = string("JSDboDlXSQzfjyjOBftbTGBKxfQsbYrUNFWzYLTWttHCcHoPoaoOtWCegXAXlkFIqKctAblTMCKmzKJZIfNpMuuPLcBBuWCOqtPnYNEztajCBBcIRGxjuJpGmDYTMPkIGDDplKmXXuDiNLzzBYKPLeJOqoRHfGScrNNRfLlOhgfGzFuplVRyEBVGrg");
    string meWmGLOhxygu = string("nQJJiLPRpxiIylGlLEISinpFrVRmveLLuEiHNMQbPkcIrEpZmcsvQmFrOlKatWzvirlkhB");
    int XSoJMMSxyHFhrEJ = 328467534;
    double WnlTkfs = 143945.70555045796;
    string XcJAxSju = string("NksNGjMwiysovYgInSDnKYzvwtnuxsrSvcFSpGcDFvghcZCdjOMGCiowTzFGVXweHmkKkBNHmhWEKpyUHYhnPMIFFsiMILPaGOXLoMzKtLXXEaSFCKEhqbEaTZDVBRaZsbfuyBYVpXcQqXxjXnWrbzxnpJnhnFfTwRJwAhtFqbPAreEupKEyWbVXVqwjtadvXzaM");
    double AjatZXIQd = -972718.1237590561;

    for (int dajSMp = 1156984525; dajSMp > 0; dajSMp--) {
        WnlTkfs = VStHXXRc;
        VStHXXRc -= WnlTkfs;
    }

    for (int wYTPgE = 2058733483; wYTPgE > 0; wYTPgE--) {
        WnlTkfs = VStHXXRc;
        AjatZXIQd -= VStHXXRc;
    }

    if (HVBcGeIqG > 669675.6032416066) {
        for (int YmduLvmsuX = 101605319; YmduLvmsuX > 0; YmduLvmsuX--) {
            eyjShNgXoP = XcJAxSju;
            TbsdrPXyrGH = VStHXXRc;
            HVBcGeIqG /= AjatZXIQd;
        }
    }

    if (meWmGLOhxygu != string("nQJJiLPRpxiIylGlLEISinpFrVRmveLLuEiHNMQbPkcIrEpZmcsvQmFrOlKatWzvirlkhB")) {
        for (int ZdaBpBXWBZ = 1668362172; ZdaBpBXWBZ > 0; ZdaBpBXWBZ--) {
            AjatZXIQd -= VStHXXRc;
            WnlTkfs /= WnlTkfs;
        }
    }

    return XcJAxSju;
}

bool JqbTdqMHgLObTs::oGgnuEDnNMaBhtDb(double liBondyg, string DyIoCtUbeoWHF)
{
    bool BWbEuDhb = false;
    string JacLJIjwvPxIk = string("xoTANPFhmEaCobrMxXpmDiPJAlAOIzvDTlEnOBMKDvxizuOzcncJOKCwmfPVsHlsJvLkdXKBBvlpuAPuEfFSt");
    string LqlEWN = string("XYPcixSaQOg");
    string SBqzLj = string("UmsfsMOtZgScHkVfQrvxVfudrARMypLzTIAZFOmBigrtHAngogJSimqEbcUuxRDdIcpgGrfqFWgEJGfrhJYAaucUnLRANfhUihnGaeeKqPBfbgZBVykXISxgKNJqKniscvZHJZHuwMlUxZdqMymzuYRfuVswacZRPFmujqBxssKVwRZaiykGkCNaFucECdhGVgiLEEILZLJgGLubGHM");
    int WxopAmmGqKFaaT = -282229975;
    string nnAWFEaWGxMbIGm = string("nERiNgNvBJhzryfLagUcwbrhFsWarPHmnZvBOQOTuMXSGPqSoj");

    return BWbEuDhb;
}

string JqbTdqMHgLObTs::zipEsbiYd(bool qcGKVMHZINotAKqu)
{
    string TMMymbLfqpvM = string("kBKTCDIpGenGyhRwHjvWuxftxqqtHctjMqXImUowoAyelWtaHRFdPyTuuBRYbvKpcVXqPlJJzfUjxTPeMDoBIRDBtHhtyfVagFvhwbFbNDGJzAfkeVXGbihtbxnQZkeaYQOmRIlJYXQoJzGBCCIvCIVCQREaAcqmnWZVzNnNQJalWLSKcUqOHj");
    int PYADWr = -658254026;
    double SninO = -701489.2028751405;
    int lSsoCkbW = 771351255;
    bool PsogTzX = true;

    for (int sdbraAHhJAGnhIL = 1031594307; sdbraAHhJAGnhIL > 0; sdbraAHhJAGnhIL--) {
        qcGKVMHZINotAKqu = ! qcGKVMHZINotAKqu;
        PsogTzX = ! PsogTzX;
    }

    return TMMymbLfqpvM;
}

double JqbTdqMHgLObTs::VlLvxSUQhj(bool TKAVo, string gTMBkfROKwu)
{
    double iJpzjLufD = -819006.2659415256;
    int UOjaJ = 2068506681;
    bool WcDxgjmD = false;
    bool HdIdgJHzcr = false;
    double PAiNeZfPSVc = -218175.82546837925;
    string SrSOPQWoBRDcMWT = string("gogqyYDcNzHoVGezQgridfHTWhMMXzcPspVKwzVeVLHHqqvMHfOfyfQXGUsf");

    for (int QnbXfSlKBteXXFio = 277080457; QnbXfSlKBteXXFio > 0; QnbXfSlKBteXXFio--) {
        WcDxgjmD = ! HdIdgJHzcr;
        PAiNeZfPSVc -= PAiNeZfPSVc;
    }

    return PAiNeZfPSVc;
}

JqbTdqMHgLObTs::JqbTdqMHgLObTs()
{
    this->HSSBVLz(false);
    this->PnKEzYDVc(true, 345118.6302088874);
    this->GUWoZThWxdpJw(1766702717, string("irKUVxDRiZCfbqpvIFKRVOmQbIKhxcXfmlnfwGZFEXAdAbDXsdeQeWVtPIZiipSIxwgQNxWIeRyQHBiAloOOOzeF"), true);
    this->vlEJLwh(string("HNXKEjdnmMUqewFcTfRbqHZFVVBuTHbHtuflCvthlpumLAsPGxYTlvrgbJSsuAuSxZggmiJzpcyqNDRpdhEBxtRhBGsbauvStDmHgVIegaQwHXbLAxytmuVQJKBSyJOEkaSuPiubrTObvqqqraUVYnQhHOyOpJikLNSAyFLRTexYjBBoAXDMFOOgzoCPkgltuRQfkoMHqogeLQtIfJcR"), 263696.65622591437, false);
    this->poBYPl(true, true, false, string("MxDCTkULDuTSAwdmxTAXVNgNugxFgspgytHwnrQQOlZCpJNvsCDKFbPJPvaLclJTeiMMvkzSfgmSnhdnhMxJXEcVWEnQaeltlgnAcvAyJZNpdqrvjTodWCEcRTyenrzYTmEqjaQFikVneoSWXXsyTxAWNkMXSwTIOlBsREcBlQTbqJzfngE"));
    this->IpWDp(string("ruGklsdnXxZZ"), -2072730248, -251845.07250269756);
    this->AIEpNrzPSjWuyfN(string("dPWTYSoPeovdwGEwlAFUtcBzWvMEeWlKdVwsoupJPaBpUaykrhZsQFXSByOdbFAtWNNlLDaLyUgWBkwAZyYdecchtDkEWzgSJySMYRZJusxvOvCqoSFfgtrYXribkpuotsYHeMGifdTNJYUoYdaTDfXbcelEPzhaEqCAbiFQXCRCXRuTvPVtwtTxXRtPWpXIgUcqtYYEKyUZeBpXgbadGimqTJaOSQbvuZWeuMvkTytljCQRmr"));
    this->EhBrvH();
    this->NPqdpXoQnWgxIE(-646154478, string("pgVLtolxcTXbDOvzOkPxPSzINglqvLehzRoXZskBcqHqoWyEITzSdaLRwvqExHYVkUrKCFfOyyrpVRyOOmuvcPecVeStkMXInArPkOFCUdjKGHzStPFpAOiRHmIWOvHURpIHqPIYlxcgKeWkMJwwjBXCwBaHemqrTUotFGBgdhdLFsTmNAzMbxoiaiYCQhifPYRZTidsxPSLvIDayErYsJIQgDtiLfFxEdiJZUhyuAKiFufjA"), string("nHFtLXhBhRcvkSudGyptgHyFUngSvEjzPktGgQVPugFQwWpoRAGqSwSkmtKmKFhHXcLBCNNvsCUBeWLZMPKgikZiTAjvwXpkDaMZBSYOkAouFDXVGNLvYjPEJwguYRQOrKGLFjJjaDLXiedOsnSVjYAayys"));
    this->OiSAdpJELOp(1971527702, 669675.6032416066, 2147374135);
    this->oGgnuEDnNMaBhtDb(962556.6341088229, string("VZOjULjsxSmrCsnCeJlZNqZorSdebTXrxUSBmBjKDUQXnNBXVNAjoDBpIYPsoOCajKcspEfFoXhP"));
    this->zipEsbiYd(true);
    this->VlLvxSUQhj(false, string("IJvlTPyNWDRQzaoggaKZyEHatxPLCzSABXyCGAeYYbAaRJmOsfOzvHifmrLXSQNkdzjYWzcGiomJEkuqMQwlMNTnEWXaBuakULXoEnpPVSZHeDJGmQnAOyeHXOWPpBxVqmTsKdptSMDMSzXzGTAbaMxwzAofonqRFAcBKmqUdTqSHUNJtUOp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sszHIxhuXg
{
public:
    double AZTYBlnNWOKqm;
    bool fSKfMDAWWg;

    sszHIxhuXg();
    void rbxOSsBAFZZL(int gjKkZevFdmPZNTUJ, bool oBwCTUZ, bool QNFRByQwlKHa, string AbOpXF, int DrsAkVsRWpDSOc);
    string XTulutbNrbiY(bool bNVqQimClFSsPF, double cVDoDceTeJfxQY, bool mwnuVDrdngiuRdfr);
    string UgQceAxumvjXluFv(double zTZTbvntPCiEO, bool zoNfsVoUXGmpu, double rUrRqAwZUflEV, double lLbPOXxMvxn);
    int OFZmQK(int RIWULJEOJ, string eAfzNqIjSAOLFOoC, int iBvjf);
    void fxaNdQP(string HAvMYNSooWQrNb, int nxsMXBL);
    void OCmJYjQCbPMmZ(int iWgeIYffQAamM, int XEjjcAFBcJA, double oanQMxMPKutbrI, int zWetGMSqRY, double MJlMVaCq);
protected:
    int GKFCAg;
    string sgBiVQLHSW;
    double igGWbhOAOIQa;
    string POArIHMdPfcWN;

    double RxHPgwwJgrMRhxU(int nBBqG, double pLYCy, string mCRDvmOHt);
    int rQHBXYtRwn();
    bool ZdohvpTMSi(double pfJYSxefei, int KVCIGEtZ, string XfnbHVaNBS, int edSCmsXtmFfb);
    bool YpNyHASEFXSxve(int EKGvcJiAbOXf);
    double jCxmf();
    bool ooOMyYksbvOaRzWr(int BWYqTyvi, double IEouD, double QglkYzMygNFxmzM, bool sjbjqdIW);
    double gFDjg(double JcIJbUjytL, int hHXGHRE);
private:
    bool ogTGtmeMynPurF;

    string ehpMv(double PGIuXnPoZoH, bool fbltNJkZxVKfLNSM);
    double OUXuCrzuPwt();
    string inQPuIE(int RfnOShQ, bool yHLMfaBLb);
    void QzbGXS(int lWGnLRFtit);
    void ABepcMwFJBoMEe(string RdMnGhG, bool azsdvOgasGLsrmcu);
    int QhxIIB(bool rUMiwaB);
    bool oLmhvQg(bool vILeqEFKudPHlG, string rVpdRnht, double nFieVO, int wACqtKObNxpEzL, int SNpEDbdSfkOfbZj);
};

void sszHIxhuXg::rbxOSsBAFZZL(int gjKkZevFdmPZNTUJ, bool oBwCTUZ, bool QNFRByQwlKHa, string AbOpXF, int DrsAkVsRWpDSOc)
{
    bool zYyavDVGivdvUWQ = false;
    bool RhyATqELvxCG = true;
    int NOmaleebqHxhtakD = -1364825512;

    for (int wMSrX = 345434944; wMSrX > 0; wMSrX--) {
        oBwCTUZ = QNFRByQwlKHa;
        RhyATqELvxCG = ! QNFRByQwlKHa;
        oBwCTUZ = QNFRByQwlKHa;
    }

    if (NOmaleebqHxhtakD > -1364825512) {
        for (int rZkIFE = 163200345; rZkIFE > 0; rZkIFE--) {
            oBwCTUZ = ! RhyATqELvxCG;
        }
    }

    for (int NaHspecrqead = 378606030; NaHspecrqead > 0; NaHspecrqead--) {
        continue;
    }
}

string sszHIxhuXg::XTulutbNrbiY(bool bNVqQimClFSsPF, double cVDoDceTeJfxQY, bool mwnuVDrdngiuRdfr)
{
    double aBggEI = 618459.6182367057;
    bool EGImqLieW = true;
    double gmPexNNQ = -220513.21379341732;

    if (EGImqLieW != true) {
        for (int WkuraUaj = 1949305990; WkuraUaj > 0; WkuraUaj--) {
            aBggEI *= gmPexNNQ;
            mwnuVDrdngiuRdfr = bNVqQimClFSsPF;
            cVDoDceTeJfxQY += aBggEI;
            EGImqLieW = ! EGImqLieW;
            mwnuVDrdngiuRdfr = EGImqLieW;
            mwnuVDrdngiuRdfr = EGImqLieW;
        }
    }

    for (int VGzUVOpJXhsDlhU = 1539832129; VGzUVOpJXhsDlhU > 0; VGzUVOpJXhsDlhU--) {
        continue;
    }

    for (int ReHTgeUGIMoBljDU = 1862564691; ReHTgeUGIMoBljDU > 0; ReHTgeUGIMoBljDU--) {
        bNVqQimClFSsPF = ! EGImqLieW;
        EGImqLieW = bNVqQimClFSsPF;
        gmPexNNQ = aBggEI;
        gmPexNNQ -= aBggEI;
        gmPexNNQ *= cVDoDceTeJfxQY;
    }

    return string("KkuZBvDNTXSAQNEvnvRcyRLimzYYtlfHFvaIpKWbnxlHqebknTnbOQcRlUfXlkgJTjlkePFQJkmtByFcswgPRUBQWxmOLLPoHqtjgtsiMuNSWQAIetBYXrKbWSUJQZfEHqhBTHTWNqeWQNNAMLajXMUvsjTlCPUKURXZLfnjYVyrYuceRJnRUXvNzbgarNsIckYGYlLAQliCdfkEDyRGRUQeFsyiQGzzbgEIFGzSQem");
}

string sszHIxhuXg::UgQceAxumvjXluFv(double zTZTbvntPCiEO, bool zoNfsVoUXGmpu, double rUrRqAwZUflEV, double lLbPOXxMvxn)
{
    double RKwauabwh = 439633.0796856531;
    bool EKjsOBXImtXgEFsw = false;
    int gWEwVuu = -774788493;
    double KfTTS = -150222.78166757897;
    bool AgfAaZMuaJtYl = false;

    if (lLbPOXxMvxn < -457654.26106297947) {
        for (int qGcHlwUinTmuMzpE = 1111053269; qGcHlwUinTmuMzpE > 0; qGcHlwUinTmuMzpE--) {
            rUrRqAwZUflEV *= KfTTS;
            AgfAaZMuaJtYl = ! EKjsOBXImtXgEFsw;
            RKwauabwh += rUrRqAwZUflEV;
            AgfAaZMuaJtYl = ! EKjsOBXImtXgEFsw;
        }
    }

    for (int PxGCXSytkdZVbtAN = 1121971669; PxGCXSytkdZVbtAN > 0; PxGCXSytkdZVbtAN--) {
        RKwauabwh += lLbPOXxMvxn;
        AgfAaZMuaJtYl = EKjsOBXImtXgEFsw;
        zoNfsVoUXGmpu = ! AgfAaZMuaJtYl;
        lLbPOXxMvxn -= KfTTS;
    }

    if (lLbPOXxMvxn < -633035.454486447) {
        for (int mJHQhDRyWCyMd = 2004589752; mJHQhDRyWCyMd > 0; mJHQhDRyWCyMd--) {
            RKwauabwh -= rUrRqAwZUflEV;
            zTZTbvntPCiEO += RKwauabwh;
            lLbPOXxMvxn -= KfTTS;
            zTZTbvntPCiEO += zTZTbvntPCiEO;
        }
    }

    return string("SsHkOpMUPVbWEeSjtJXUYjaKzwULKPoRmRFxeQxaMktCTSONRfePpLXzEfcRtAgkfbbnrKl");
}

int sszHIxhuXg::OFZmQK(int RIWULJEOJ, string eAfzNqIjSAOLFOoC, int iBvjf)
{
    double wETYKiTrcWNgHQED = -832495.9304625627;

    return iBvjf;
}

void sszHIxhuXg::fxaNdQP(string HAvMYNSooWQrNb, int nxsMXBL)
{
    bool cgNkPhUnk = false;
    string qTNhh = string("NzALZDOFPCgRLwoAXQRfWXtQOgRcjIdzSZjdseCqjdZNMuHSuwqWWwzRUnYkGjrpkklCkRLbLCShMMFaqxOrtoYgWLGqMBWeSjvr");
    bool kIFjNQA = false;
    double TKxJRIVUDP = 565205.0918161838;
    double ENEaAGVIO = -973922.8025873716;
    string ZpeAhXmqJtSEQ = string("fCbcOddaDeSJwpfCftOHFGcaOZOXNhxzFFLlzzPZEJelJYLBSrasbpdUkMVoGGSgKqqaZHymLzGNbwEqSBQhPtWYDopRFZxrbBbXrmqaLqwPWzZeYPjMOsJCAjINJgiRNPlLZLhAitYDVXlImraRMjCXQUiwbhtPsXODKbCnjtNUrcDkPOHYfJgrbjImXBqwdDgCuaOTyUWNXSGUnKCZTaAYCUTdIPCdoEkprXjEKfjMRjCYiPCBWxJsAyytNGh");
    int lfMYTMXvAOs = 315911530;
    bool AXcXRgDP = true;
    double NwJLx = -350272.2463892906;
    string easHgbkQriDGg = string("rNZNgyzQcqxoOxJyOpFWpWLPsJETiJHkUNHefRIdUaAHxkhKLSwgUMhpeHNLsFEixxGzDClXPDmEKVjBPdQBSlfBzcyVedBOMAxBNbatWsQjHXfbVgpRUrjtKbuMyWGvlFTtgwMtbhPHanokvbOIqxg");

    for (int abEDW = 1155216775; abEDW > 0; abEDW--) {
        kIFjNQA = kIFjNQA;
    }

    if (qTNhh >= string("fCbcOddaDeSJwpfCftOHFGcaOZOXNhxzFFLlzzPZEJelJYLBSrasbpdUkMVoGGSgKqqaZHymLzGNbwEqSBQhPtWYDopRFZxrbBbXrmqaLqwPWzZeYPjMOsJCAjINJgiRNPlLZLhAitYDVXlImraRMjCXQUiwbhtPsXODKbCnjtNUrcDkPOHYfJgrbjImXBqwdDgCuaOTyUWNXSGUnKCZTaAYCUTdIPCdoEkprXjEKfjMRjCYiPCBWxJsAyytNGh")) {
        for (int CpmuzZiKYeom = 1617333165; CpmuzZiKYeom > 0; CpmuzZiKYeom--) {
            continue;
        }
    }
}

void sszHIxhuXg::OCmJYjQCbPMmZ(int iWgeIYffQAamM, int XEjjcAFBcJA, double oanQMxMPKutbrI, int zWetGMSqRY, double MJlMVaCq)
{
    double WQgydiZ = 196712.05968785958;
    bool zYokDjOGP = true;

    for (int GbAVCMs = 830451229; GbAVCMs > 0; GbAVCMs--) {
        continue;
    }

    if (oanQMxMPKutbrI == -84567.0406593707) {
        for (int ZSjmL = 1425943847; ZSjmL > 0; ZSjmL--) {
            iWgeIYffQAamM = XEjjcAFBcJA;
            XEjjcAFBcJA += XEjjcAFBcJA;
        }
    }

    if (MJlMVaCq >= 196712.05968785958) {
        for (int COuFZwTPXpSgTQqB = 1159615115; COuFZwTPXpSgTQqB > 0; COuFZwTPXpSgTQqB--) {
            MJlMVaCq += oanQMxMPKutbrI;
        }
    }
}

double sszHIxhuXg::RxHPgwwJgrMRhxU(int nBBqG, double pLYCy, string mCRDvmOHt)
{
    string TkePdzXq = string("EvvbzchoiYBFaWfPQvWMdwvDHIUSFfXmZFoHOITDIF");
    string edqPEWd = string("ppHLYtBnsOzBJmETUmEHhXHZTjLLOlOQvrTfcnBdKUzIUvOUYGmovQhOqFeTZkkxEIiyXGiuQCfDSnoJULgPYXoBAuxJotIASAUGyQCOAxkJEKCqovXjHJgJrEfHhWaxborTnLYhaAIjmJbGsjTldNgDbYbZVcomTHMFkCrCwYTzi");
    string WQwDkCyrPK = string("bUMYgbkZoNuRRRHPCNFWnzSJbPZQAlAMHhNZDosGkKjLzsvIelJAAhcvcdeuzLmTglDyGRgFNSJDRtnzUFWzUdRQVgLpsHKlxjBwJSvKEqxZJwcWrohliAdwJwNFPYNpUJrYycLVpeHcfyBKk");
    int OFCmsibLRSst = -418119477;

    if (nBBqG >= 1038422574) {
        for (int ScyMcUbZzJ = 1810751517; ScyMcUbZzJ > 0; ScyMcUbZzJ--) {
            nBBqG = OFCmsibLRSst;
        }
    }

    if (WQwDkCyrPK != string("ulphjtmaOQymZPAZrfuFiHaNFmrmcjXsgOIviCfHCZxfHlzcvutrePtttfJnrqRLriELiCskVCcSJiDWOovQcUODODofBADlcjeWqAjotkHntKFDjNXfMjmKDwdqecoQIfddhpFFlFWHtNvzRMdGJxFlWoEtDEtiNXfgXvvmDVyQbrDgdBesCChsNnbAcAW")) {
        for (int OsILsfFhUlb = 1757081178; OsILsfFhUlb > 0; OsILsfFhUlb--) {
            WQwDkCyrPK = edqPEWd;
        }
    }

    return pLYCy;
}

int sszHIxhuXg::rQHBXYtRwn()
{
    string GbqXKDrjJ = string("KNSghamyoHWeQeTbpmSjbsjQZTAahdIRAFxQOOslmIdovRkWElLPypkyWhHlkoVZP");
    int pOyDXSHq = -1462579382;
    string FTYEUzFisVqg = string("bhOYyxbeuJKCrGCfTfFKbhqkoijxwejdXvczDzYqYkcBPCpqgvDOeitiOmYJeiLInaHL");
    string MTBdQpvAdoUq = string("SbzVKqlAwgTGghVcUfMnMkkZylqSMqbGHtpOWkuOvTAkPYtxWvryiFVpqumZIYiYNcRtZbWOjqQOOAlafjmhCgzugmrFkcUeNKtAxvzDozt");
    string LnuNE = string("bcdCaofkLfCibDKEPxUFJECYmuJveHIOyhGLrHoATpLuvCcPYCOxsEbdpWcjceJLvHjqvLkFCsdtWBWXxObrjkCCWznebZJRxKILPkqDXFeYDuNaobretIjRuIAqMsOBmZVJS");
    int SINceX = 1916635887;
    string dDlUQLrHZQdkC = string("kHJzzDcahPoqypctSPHPsPifOxxOXHAhLxmtOijTkvDloCLPuEMqQomKytLGpNTPyqxeoxrcmcDCzPkETHNePMFEMxjVicnSGMAakkRksTiivNXdkUOhxPzbPKt");
    bool MEnXXxCCoqHZaqYl = true;

    if (MTBdQpvAdoUq <= string("KNSghamyoHWeQeTbpmSjbsjQZTAahdIRAFxQOOslmIdovRkWElLPypkyWhHlkoVZP")) {
        for (int KKifC = 1617935907; KKifC > 0; KKifC--) {
            pOyDXSHq -= SINceX;
        }
    }

    for (int XSlAfrtjXYSzQe = 1096924993; XSlAfrtjXYSzQe > 0; XSlAfrtjXYSzQe--) {
        dDlUQLrHZQdkC += dDlUQLrHZQdkC;
        LnuNE = GbqXKDrjJ;
    }

    for (int mkbFnBcRIzsQ = 1928214128; mkbFnBcRIzsQ > 0; mkbFnBcRIzsQ--) {
        FTYEUzFisVqg += FTYEUzFisVqg;
        LnuNE = LnuNE;
        pOyDXSHq *= pOyDXSHq;
    }

    for (int vuIWbT = 664472822; vuIWbT > 0; vuIWbT--) {
        GbqXKDrjJ = LnuNE;
        LnuNE += MTBdQpvAdoUq;
        GbqXKDrjJ = GbqXKDrjJ;
        dDlUQLrHZQdkC += LnuNE;
        GbqXKDrjJ += MTBdQpvAdoUq;
    }

    return SINceX;
}

bool sszHIxhuXg::ZdohvpTMSi(double pfJYSxefei, int KVCIGEtZ, string XfnbHVaNBS, int edSCmsXtmFfb)
{
    bool RMNyCU = true;
    bool TeUhkis = true;
    bool MvQKTaji = false;
    int KlfJOhaOGktmB = 889367942;
    string yuwmznPCMlGl = string("WfgbvoRasPrjZUbxJlNIokuXxmSMwSYlTFhoeWFOswQyuVpAhHJdYjauCOsJigqaftJxKwttMSxuiUiPxIcfQXqffxvvEPgEeMWUbPTfLtwKcOeUWfvtFRIGvspfwnpQrbgNGYYyintZGtFMaWLyomrjUPqHSImsvrhjzQSOfkrVYHAlytZAhfesHZKzQeRMVnRVREZfIYmYFGTFovqnIzP");
    string uwxZXsBLyqlLvrw = string("uEOCsqMfakamraliLHVzEWmPRXjJChKzx");
    string ttWgkiCMmCybbaa = string("HDcTwgiTWeVnziRHmyoTSAZRzYpfPZsfkgXaCTDosvOeBRSfxlHaYWbFAoldYoAiGXyvJVHXFXGPrWbZYJpJIoRzvEhCVeZEifhOMOihXbTnPdOUHqJpXHPfJXDLHJYkIJvdTDlMerXrbbZxtLFBxuuwuZUeaNWwqnycfolWMNkbxHAujoUpEa");

    for (int wbVLLvELfuVYOhfC = 1849449863; wbVLLvELfuVYOhfC > 0; wbVLLvELfuVYOhfC--) {
        continue;
    }

    if (KVCIGEtZ != 889367942) {
        for (int TKlTbHgSbN = 839331357; TKlTbHgSbN > 0; TKlTbHgSbN--) {
            continue;
        }
    }

    return MvQKTaji;
}

bool sszHIxhuXg::YpNyHASEFXSxve(int EKGvcJiAbOXf)
{
    int UwjmDqlhYpuSYfo = 323683764;
    double qPcvehqoqypPpZ = 449327.5494362009;
    double hOjBXot = -148859.58296881334;
    string soexBcR = string("wEvubgqHDXQEGlKSASMRxfxOTnXOyAuvmGasURgfMQVFnHTHRLZiEOjuOEDWAtPbWJdJVVBOvijVrauVnAwVTPCyatoICMuqsiUwgmKrCjRuPJtWxBZZhoszZowxjTDikVjwVpQHPITqykbqSyQkIIshbRvVAhLTJKdmeDBSiillyAplcNyOVCHvITECgPQzzsjZBImBPqoO");
    double VMueagpNyC = -1017044.5381447673;
    int kRxMBvA = 374267746;
    double dAOqIDtBvc = 192282.20761014262;
    double FXxgIlkrfdU = -935488.4593421232;
    double jfdxR = 680437.0413363992;

    if (kRxMBvA > -1834501229) {
        for (int FjjIAMnHttkAvIl = 1001415622; FjjIAMnHttkAvIl > 0; FjjIAMnHttkAvIl--) {
            FXxgIlkrfdU += dAOqIDtBvc;
            jfdxR /= jfdxR;
            hOjBXot -= dAOqIDtBvc;
            VMueagpNyC = FXxgIlkrfdU;
            hOjBXot -= FXxgIlkrfdU;
        }
    }

    for (int TwoIkuntQJnQAZiX = 1629966747; TwoIkuntQJnQAZiX > 0; TwoIkuntQJnQAZiX--) {
        dAOqIDtBvc /= dAOqIDtBvc;
    }

    for (int NkeAzQWZwpdzqD = 135534969; NkeAzQWZwpdzqD > 0; NkeAzQWZwpdzqD--) {
        continue;
    }

    if (FXxgIlkrfdU == -935488.4593421232) {
        for (int wczRovKa = 984824659; wczRovKa > 0; wczRovKa--) {
            dAOqIDtBvc -= qPcvehqoqypPpZ;
            jfdxR += qPcvehqoqypPpZ;
            UwjmDqlhYpuSYfo = EKGvcJiAbOXf;
            EKGvcJiAbOXf *= UwjmDqlhYpuSYfo;
            dAOqIDtBvc /= dAOqIDtBvc;
        }
    }

    return true;
}

double sszHIxhuXg::jCxmf()
{
    int TfXPSQxkdh = -907178954;
    double jDFZIRjKVAShET = 199523.60230158578;

    return jDFZIRjKVAShET;
}

bool sszHIxhuXg::ooOMyYksbvOaRzWr(int BWYqTyvi, double IEouD, double QglkYzMygNFxmzM, bool sjbjqdIW)
{
    string MOxAstuzrEWWUUyZ = string("mknfqnnUEcWPuxXwVCkcQppRSEdZEddMJgdYcilnLftTiofMYGKENRrjbmpklzUJMtZlXliLKrYXnInLCvSVcpXRwFpNVBNDebWM");
    int OmkUvGKLaVbbhiuq = -1901469304;

    for (int MSBmadTtUwkWx = 1818277896; MSBmadTtUwkWx > 0; MSBmadTtUwkWx--) {
        OmkUvGKLaVbbhiuq += OmkUvGKLaVbbhiuq;
    }

    for (int mRDxLAf = 1112042666; mRDxLAf > 0; mRDxLAf--) {
        IEouD *= QglkYzMygNFxmzM;
    }

    for (int TKZHfnqL = 1806953202; TKZHfnqL > 0; TKZHfnqL--) {
        BWYqTyvi /= BWYqTyvi;
    }

    return sjbjqdIW;
}

double sszHIxhuXg::gFDjg(double JcIJbUjytL, int hHXGHRE)
{
    int ddStEvmOAlVjSBea = -1669072411;
    int wUKEwpEu = -1799034131;
    string qXynoyvfL = string("WBjsRonkKbSSiUIdonEsaHROVbEQnUHfiTruRfOKdGRQSBZgRScHmzSzUFMPBYYmIOfXDhfJTImqdzMPbKIhVjoLHkuugRBnoHZDYlCFKBU");
    bool PIyrmLflsWKeFon = false;
    string NJjuXOZAOlUB = string("rFftfMhxpHlUqdHUhmjyZLTEszavWcucTCalTyUfKQuHcOLlPDVLWbEZDMasaCIZfNWUbfv");
    int foBBAQtr = 1585715361;
    string TrVWwRy = string("WYTDUGhhnafFkBxvtcbIXttHohrneeHloXLldgXiAPMccjqiXGYDjSoVcUSbxchxcKQcBfMoVqAJdDDtYcTMXDEFbZQpQcFiJLViFJgzffhh");
    double OwcoxqPzBnmOZn = 922315.5792684973;
    string dxbAWKGVWZXkSx = string("vYDUaxfXhpbBpuCdCYGYpYxtxyldnKMYYHDbQmLwsQbxDXUqwrQqFMuxwiAabUa");

    for (int hklfqqJsbQeVxoOK = 925907733; hklfqqJsbQeVxoOK > 0; hklfqqJsbQeVxoOK--) {
        wUKEwpEu *= hHXGHRE;
    }

    if (ddStEvmOAlVjSBea < 1585715361) {
        for (int QghIFLWmFDlMR = 2048270829; QghIFLWmFDlMR > 0; QghIFLWmFDlMR--) {
            qXynoyvfL += NJjuXOZAOlUB;
            foBBAQtr -= hHXGHRE;
            NJjuXOZAOlUB += qXynoyvfL;
        }
    }

    return OwcoxqPzBnmOZn;
}

string sszHIxhuXg::ehpMv(double PGIuXnPoZoH, bool fbltNJkZxVKfLNSM)
{
    bool AHbjpOGVa = false;
    double ZhKeejvcJs = -16027.096906559878;
    int pUsRMWqSYYSvKZcH = -1633911723;
    double aBOyJpOjmlTm = -771330.6802858353;
    double YbTWKHIfjUiJT = -451473.6729748997;
    int zyIlTeCu = 1071761252;
    double KClYHgSpXkDcjO = 363129.76501653134;
    string MYhDULUi = string("vaDiEUVhpMyABuSBfJUszHhSweYBLOfgNJiuwFdIdthrgLoIxgnZlSzcIJNlrMVKtLpDeCCBasTTpIfOlPuTFNBDDjMaJJZLHdhvDnwcrSrEbVHZsuiitigpMcoTvVlpKIjnJDFFgIYHkfVonVjUaMgCLIFemwBSIplzwRqTlleZqhiOzltwyhu");
    string IeUyXLZL = string("WvdqpDvGddOZvqJdFDmImBHvpSdjkIwdHmaqdVHHqqVpFHtnmHLXjnNxbLuQuCvtWyqIxubVYajZKFXJzGyxWyJvJSHEgajgCEXmHXUhasqajwXboNuHIDaYRqRKtDlAUvTjYDLStIrdghDjVhzFgpXPeuBEkXNerRFoi");
    bool fADFaKYeWWRTBDPt = false;

    for (int ndMhhEJwQesFzoDf = 441911031; ndMhhEJwQesFzoDf > 0; ndMhhEJwQesFzoDf--) {
        fADFaKYeWWRTBDPt = ! AHbjpOGVa;
    }

    return IeUyXLZL;
}

double sszHIxhuXg::OUXuCrzuPwt()
{
    string VwNIFZUxdABiQ = string("eOSQlPqAENfwRQKkswkvQSGJrIEwzeutejwvQaUAMYuHhNdaHxWROiJZwFQxlmUgtZJkNWJUoBJPqRhujxauDCSBnbYWdvprauMwbqGlpeLICmhQUpUNwehzVozfXmtcWjIAZPWNvpPQTHRdRoLnCCUWiqXxFUAIyUpNCOclnFUcpqngDfilUyLbBDgrDwGVIwGLKAsPBngWTdWJIXqaTnOayPvQjkZWTtIpczAHFDfDLfz");
    int IjiYTQO = -1784823733;
    int EOdExDdYGvVAeJUT = 1908426162;
    bool GTSrPW = true;
    string DfEqDKKUgzEV = string("XxFGuextewmzTkYkhJkstdufVrczBbXEZwxgjzBGHTTiyfyLTWlxHpNBpRyfbvrHDVTtXinpFeCRxQJpSRIzlUYMiWlzTZVlTaoIUaWtmOfJGxxdxtdKcOALIwhodgFPKlVRWbdAGAoWsnGqpohNRIgIIunKULVGepCAsXGMSoPsHktQDauvxMwWlGMQjmtlHhYBxVxAQPkDEgwbCvYpIDt");
    int zjKZzJlYBukh = 428376610;
    int sundMJPFxCH = 1194364124;
    bool eUGVodEvhXsRB = false;
    double VDRxkiO = 1022749.5790439472;

    for (int zSGZzqcJl = 989265363; zSGZzqcJl > 0; zSGZzqcJl--) {
        IjiYTQO *= EOdExDdYGvVAeJUT;
    }

    for (int pHzhL = 1154858992; pHzhL > 0; pHzhL--) {
        IjiYTQO /= sundMJPFxCH;
        zjKZzJlYBukh += EOdExDdYGvVAeJUT;
        VwNIFZUxdABiQ += DfEqDKKUgzEV;
    }

    if (VDRxkiO > 1022749.5790439472) {
        for (int yyAyMtvLQg = 669884800; yyAyMtvLQg > 0; yyAyMtvLQg--) {
            eUGVodEvhXsRB = ! GTSrPW;
            GTSrPW = GTSrPW;
            VDRxkiO *= VDRxkiO;
            IjiYTQO = zjKZzJlYBukh;
        }
    }

    for (int rmGUsPwLmK = 745605150; rmGUsPwLmK > 0; rmGUsPwLmK--) {
        sundMJPFxCH += EOdExDdYGvVAeJUT;
    }

    return VDRxkiO;
}

string sszHIxhuXg::inQPuIE(int RfnOShQ, bool yHLMfaBLb)
{
    double uLRJdgRCLESOld = 70873.61038045479;
    string RPeUyNBvxHwW = string("gOjUscFkWQQTCAizXtSpFxbGjyYjZmkcJwHdjKZlnDrwgBlJmsLqzDuXpuYwVETmRHbIbNxmslQSpbVnXWIDmWRLADXIvXMcNbwbVerfyrqiVusHBBSvpDDwSKHtFKEdVSWspdcXLZAxsjXPWpoDwIrEttwTApwSsIsFSwQtykQWImKpkEdqHHhoQQZKgJpKDcBN");
    string cMYzlcoelKvoRg = string("axaIFfdqdKalWNJNEeECmVdbFkmbvNEFejkoxjHAgJeDIadQUFFNcCQXqIJMmWRahnhtcBsLMCiyJZJQsCvxMZkUPnbxSUUtxyZWppLcTYFbBrUSobUIScnLrMZjbCLOrvoNRbvkrCexbncbRjaEmnhZWlDClMrhXwPmbmnGVgbzngSaVgcULapOFSQrUaKgxZgwAiKzuzqZoBSlKmDRpVveAWMMaagnccYogxFTOOpXfQODJwmddhM");
    string lSrGqgR = string("saJrNPdiYmzOIiXAnFtnDhAVoTHfvUTCggQLCtSo");
    bool rrSuMVxZTNoonzNS = true;

    return lSrGqgR;
}

void sszHIxhuXg::QzbGXS(int lWGnLRFtit)
{
    string fthWmpkk = string("UNVcFTPtoPSDJkXsczUnzkcopCqadAoaKiZjJXliHdvVkNznoosCXnhPdwUZFfHHRbVukQvvjyOqCRRxuyaYUlOaPuwtmVnBuVNTHTRbBgqlqePkOJsQtEETFKSGEKqHcvJKfOcXBplSLkmbLrYUVlgoxoIJXNmZeAYpdEScyDfXXtOqROCCzMrjjhrwLeglAyYqRbW");
    bool ESbJmfx = true;
    bool IkJZqrb = false;
    int eSuThjNxhbG = -360873450;
    int ngyjNpFeEvvEO = 1405835362;
    bool epOZFJIjCc = true;
    double gpNdlrghLYqsXGj = 395378.4941818506;
    int FiShuyrwGpGBq = -1902992546;
    bool ShucAl = false;
    bool aHYzeSmmSZtDN = true;

    for (int ozVmzNgEyX = 557434540; ozVmzNgEyX > 0; ozVmzNgEyX--) {
        ESbJmfx = aHYzeSmmSZtDN;
        ESbJmfx = ESbJmfx;
        ngyjNpFeEvvEO += FiShuyrwGpGBq;
    }

    for (int aBVgrNsmBENV = 406236927; aBVgrNsmBENV > 0; aBVgrNsmBENV--) {
        IkJZqrb = ShucAl;
    }

    for (int ButJosQZAyBFdY = 1326096097; ButJosQZAyBFdY > 0; ButJosQZAyBFdY--) {
        FiShuyrwGpGBq = ngyjNpFeEvvEO;
        ESbJmfx = epOZFJIjCc;
    }

    for (int WDhMcrQvuhIXufQS = 1815366895; WDhMcrQvuhIXufQS > 0; WDhMcrQvuhIXufQS--) {
        aHYzeSmmSZtDN = ! IkJZqrb;
        ESbJmfx = ! ESbJmfx;
    }
}

void sszHIxhuXg::ABepcMwFJBoMEe(string RdMnGhG, bool azsdvOgasGLsrmcu)
{
    double PEhMb = -433658.9494942629;

    if (PEhMb >= -433658.9494942629) {
        for (int eKWbmQlOi = 1632668432; eKWbmQlOi > 0; eKWbmQlOi--) {
            azsdvOgasGLsrmcu = ! azsdvOgasGLsrmcu;
            azsdvOgasGLsrmcu = ! azsdvOgasGLsrmcu;
        }
    }

    if (RdMnGhG == string("MDXHSjPyFvA")) {
        for (int PUGKMXbxxnoDNt = 1013198314; PUGKMXbxxnoDNt > 0; PUGKMXbxxnoDNt--) {
            RdMnGhG = RdMnGhG;
            PEhMb = PEhMb;
            azsdvOgasGLsrmcu = ! azsdvOgasGLsrmcu;
        }
    }

    if (RdMnGhG != string("MDXHSjPyFvA")) {
        for (int GKNmsEmhmf = 1393077291; GKNmsEmhmf > 0; GKNmsEmhmf--) {
            RdMnGhG += RdMnGhG;
            RdMnGhG += RdMnGhG;
            RdMnGhG = RdMnGhG;
        }
    }
}

int sszHIxhuXg::QhxIIB(bool rUMiwaB)
{
    bool wsuEWgFvkPlyX = false;
    bool nPycURSJCNcEs = true;
    bool uzfMrnOruzrQCeP = false;
    bool cVqpmzsenxOSYiTW = true;
    string lQEKZiDsRavC = string("uYXoebLbMkQHhAWAXZuxBpWfGuMvTcEhriwRGKZjVDWbPwRnwAwuFtqXdRYPWmTRwtfYUyTxkVuJ");
    bool HuHlqNJgAzTf = true;
    string IdCoRuQuO = string("aVJXeQzfYEBswgpRhTSNBALrvVofMmPgBGADGawg");
    double YpiiksPnWaYoIkY = -366399.82395541674;

    if (HuHlqNJgAzTf != true) {
        for (int RFrLXsOB = 1837325231; RFrLXsOB > 0; RFrLXsOB--) {
            HuHlqNJgAzTf = ! nPycURSJCNcEs;
            uzfMrnOruzrQCeP = nPycURSJCNcEs;
            lQEKZiDsRavC += lQEKZiDsRavC;
        }
    }

    for (int RAwaOTXVRjq = 703367411; RAwaOTXVRjq > 0; RAwaOTXVRjq--) {
        wsuEWgFvkPlyX = cVqpmzsenxOSYiTW;
        HuHlqNJgAzTf = ! wsuEWgFvkPlyX;
        uzfMrnOruzrQCeP = wsuEWgFvkPlyX;
    }

    return -238007724;
}

bool sszHIxhuXg::oLmhvQg(bool vILeqEFKudPHlG, string rVpdRnht, double nFieVO, int wACqtKObNxpEzL, int SNpEDbdSfkOfbZj)
{
    bool MWJiQGjY = false;
    bool vQztshwtfp = false;
    int PsEuM = -607693943;
    int MbilbVPyQuoj = -408414001;
    double hOzcZPC = 654828.3428814418;
    bool aAWCWhwLPmZdh = false;
    int bLtMK = -1412212114;

    if (bLtMK == -607693943) {
        for (int vOJynUwx = 991989396; vOJynUwx > 0; vOJynUwx--) {
            continue;
        }
    }

    for (int kMVcbkoUY = 101372494; kMVcbkoUY > 0; kMVcbkoUY--) {
        bLtMK -= wACqtKObNxpEzL;
        vQztshwtfp = vILeqEFKudPHlG;
    }

    return aAWCWhwLPmZdh;
}

sszHIxhuXg::sszHIxhuXg()
{
    this->rbxOSsBAFZZL(-1817747682, true, true, string("HIWlcaesyjBoPEYYIcXCOLxmGvyeIruNdxNBcHkdPgMnftwkHUKNvuoYENhwowwlSIXXaailtVHfVeJqIGOaLaPmSyxpJwmFUxaAwhIeZCqAfHgUpTBoiEVVGrehCKhTBbGKqpnABcxaqgxhMZqQDSvldqpQdsHdRokvyyVVaWjPvTspHeddNiyZMfjkIRYXhBHClWBLxxE"), -1226154634);
    this->XTulutbNrbiY(true, 731438.4964178614, true);
    this->UgQceAxumvjXluFv(-630243.596885376, false, -457654.26106297947, -633035.454486447);
    this->OFZmQK(-1679518892, string("WAjgkeSHPRvbwJIuFaxSNhonDsMlBwntQNVBRCPmODrqWkfWrb"), 1483975614);
    this->fxaNdQP(string("jHDLFriaFaGdLmIeEZnpSENXlcqSlwAFLcqZqZdyTdhBDLkThoByfQbajHrsEyZIYhGzPmifWkFsNCXGMkAwpCGLehbFgAoetyGepCKCQZIpcdiMmqGnhyMmlcfCOaoSrNtbOizWzlmAIzrkyTXtVaLmCnttwAArPBggYnTJziRHEQMLiSzJwzyWindElmvWniu"), -1212020241);
    this->OCmJYjQCbPMmZ(566855224, 1560468967, 671171.7575111996, -1106898145, -84567.0406593707);
    this->RxHPgwwJgrMRhxU(1038422574, 918329.70320546, string("ulphjtmaOQymZPAZrfuFiHaNFmrmcjXsgOIviCfHCZxfHlzcvutrePtttfJnrqRLriELiCskVCcSJiDWOovQcUODODofBADlcjeWqAjotkHntKFDjNXfMjmKDwdqecoQIfddhpFFlFWHtNvzRMdGJxFlWoEtDEtiNXfgXvvmDVyQbrDgdBesCChsNnbAcAW"));
    this->rQHBXYtRwn();
    this->ZdohvpTMSi(-539600.0823677691, -1348957435, string("CcgkqUTWKrWMLiaYEIkCkkuyOJFPaLdCpEDdJUCoCfEqieJplVAOglhjuyTMVVFUbpkCotYyCXzXGbgTqmgiOcfqFTgXwLcsONmsxwZbqlhxBJwbdJkOorgReVRcaaTFetnHPcJvKIoWwhjQLFpSaMJAbdMGqAegBDDjsXuYROietILWcHylOFYiqplMGtqcVApdMCcqEVOXfnWyndXPg"), 1692917769);
    this->YpNyHASEFXSxve(-1834501229);
    this->jCxmf();
    this->ooOMyYksbvOaRzWr(1520721174, 122473.71202684777, -57200.82236218515, false);
    this->gFDjg(469791.9477372752, 611177493);
    this->ehpMv(259833.94841617046, false);
    this->OUXuCrzuPwt();
    this->inQPuIE(-116076898, false);
    this->QzbGXS(606221332);
    this->ABepcMwFJBoMEe(string("MDXHSjPyFvA"), true);
    this->QhxIIB(true);
    this->oLmhvQg(true, string("XVjTCpdhOGpIaUScnbOjJztRyxcgpYUUVyEAmZDYNQRnJkUYPrHUlYfnDYSckZwcnjZDhZgQNDITtQUXJMqqpMMKIZhJSPZriRJjbYncSIgQRdJhfXgFPLzOFHVEAmdahVSunQHCQKodBCYtfpGDenJplbfTbRgnqyJk"), 578357.260905468, -1881674469, -1963044049);
}
