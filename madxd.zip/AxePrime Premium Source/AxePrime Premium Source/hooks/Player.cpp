
/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gcFtipcrJ
{
public:
    double GWIcBxtneik;
    bool scGaCvCkJ;
    int iwFjbIFefmelnvHn;
    double FnvZsnF;

    gcFtipcrJ();
    void tbNoquhQcAMSMbc();
    bool pKyheUXfzCgHgd(double EtXhECxBmNMNl, string grcOKUT);
    bool fYwKPyICxDiO(double kpCeLWLSZxOnAEiM, bool YIQcKaiHzPqH, bool iTaDxLkokX);
protected:
    int HtRBIEM;

    double UyZyUFNZ(int nCCxif);
    void dPkZQKGCQn(bool zQiOnLPetdML, bool DuqYPKJJ, int hAxkEgctnzv);
    void EDeYErRkneKPy(string cyLVoEjDay, int onTkYtujaGYCuLf, bool qNCYGVouWZRjE);
    double iPmxOKE();
private:
    int IErDxYOxTpVsBugj;
    string rEcYbLqKHsy;
    string NkYjZRowONPg;

    int RRrlGeIdkQ(bool ARTjfO, double JJUGjbHroyuRcNo);
    bool zLRNKYbZnBS(string VilLRHvqppPbHX, double VQGcCI, int cLPliK, double ILtbRSpHYUv);
    bool FrDhK(bool OrHWAw, int RYypekTg, int CCDqjk);
    double NneWm(string ddeWNkavoPLV, double GDbZz, string HBChr, string cPRgFZRqomGS);
    double WWRgOfHkVnay(bool nmAwBXmHjEFY);
};

void gcFtipcrJ::tbNoquhQcAMSMbc()
{
    string kNgjkK = string("fGklVqzJJMwQxcoyHlVSHeVcfoLSvEDsnzcoAhLaaxVBjBNzHlxqGLqmTBWzvmVBvNOcDQIHBSTdKZzMOjsWpbu");
    double FpOSxIgvVcV = -578274.2604820005;

    for (int XMbtFvcYSKbER = 1541038580; XMbtFvcYSKbER > 0; XMbtFvcYSKbER--) {
        FpOSxIgvVcV *= FpOSxIgvVcV;
        FpOSxIgvVcV /= FpOSxIgvVcV;
        kNgjkK += kNgjkK;
    }
}

bool gcFtipcrJ::pKyheUXfzCgHgd(double EtXhECxBmNMNl, string grcOKUT)
{
    bool prMHqqfm = false;
    bool rVYNHGFcGradnvR = true;
    string vNcQujYDWjIUc = string("Fyjt");
    double yohVQhirwT = -42515.276140434085;
    double zgJKYHv = 420124.6653882335;
    bool URkqjYBjB = false;

    if (EtXhECxBmNMNl > 533503.228489196) {
        for (int kuFyIrpt = 356274930; kuFyIrpt > 0; kuFyIrpt--) {
            EtXhECxBmNMNl += EtXhECxBmNMNl;
            prMHqqfm = URkqjYBjB;
        }
    }

    for (int xTuXhKU = 918413811; xTuXhKU > 0; xTuXhKU--) {
        prMHqqfm = ! URkqjYBjB;
        EtXhECxBmNMNl += yohVQhirwT;
        zgJKYHv -= yohVQhirwT;
        rVYNHGFcGradnvR = ! prMHqqfm;
    }

    for (int ybAHxJGrPM = 832110746; ybAHxJGrPM > 0; ybAHxJGrPM--) {
        continue;
    }

    for (int XVJsOhfBgM = 1546848754; XVJsOhfBgM > 0; XVJsOhfBgM--) {
        rVYNHGFcGradnvR = rVYNHGFcGradnvR;
    }

    for (int sdrFVKWIfPSOyXz = 1346431003; sdrFVKWIfPSOyXz > 0; sdrFVKWIfPSOyXz--) {
        zgJKYHv -= yohVQhirwT;
        rVYNHGFcGradnvR = ! rVYNHGFcGradnvR;
        EtXhECxBmNMNl = EtXhECxBmNMNl;
        rVYNHGFcGradnvR = URkqjYBjB;
    }

    for (int trbWpULgfDrmco = 1246934690; trbWpULgfDrmco > 0; trbWpULgfDrmco--) {
        vNcQujYDWjIUc = vNcQujYDWjIUc;
        rVYNHGFcGradnvR = prMHqqfm;
    }

    for (int fhKblgRYhaIpev = 303336256; fhKblgRYhaIpev > 0; fhKblgRYhaIpev--) {
        EtXhECxBmNMNl -= EtXhECxBmNMNl;
        yohVQhirwT /= EtXhECxBmNMNl;
        yohVQhirwT -= zgJKYHv;
        yohVQhirwT = zgJKYHv;
    }

    return URkqjYBjB;
}

bool gcFtipcrJ::fYwKPyICxDiO(double kpCeLWLSZxOnAEiM, bool YIQcKaiHzPqH, bool iTaDxLkokX)
{
    int XHAftoSfZNhD = 1529401255;
    int YCnialtCcFZLarxq = 1970938274;
    string aQFkkJDHQNkhgC = string("tZSfOEEsSxNAWlTErWfomMqDTCHkEzOqrCTpXSFWLBBZGgKFdWqruYaaIZYq");
    double SvBzkYU = -302450.4022706766;
    string fUiRaQsSZh = string("FvLpNVyxpWBrxXObDowfZTLbSwVIKfAN");
    double qqPCaHLpeWYgcsLM = -383763.7082252775;
    string zpEFJVGwWrPAjR = string("qDtPvPCaMvZNaytcDsNWOLTwLBve");
    int RBNkTmGQepLCH = 86392580;

    for (int umEOPyDTk = 1601141951; umEOPyDTk > 0; umEOPyDTk--) {
        RBNkTmGQepLCH /= XHAftoSfZNhD;
        zpEFJVGwWrPAjR += fUiRaQsSZh;
    }

    if (XHAftoSfZNhD != 86392580) {
        for (int GnjNjI = 1243874398; GnjNjI > 0; GnjNjI--) {
            zpEFJVGwWrPAjR += fUiRaQsSZh;
        }
    }

    for (int kPCXdLwCDA = 918041854; kPCXdLwCDA > 0; kPCXdLwCDA--) {
        zpEFJVGwWrPAjR = aQFkkJDHQNkhgC;
        YCnialtCcFZLarxq = XHAftoSfZNhD;
        XHAftoSfZNhD = RBNkTmGQepLCH;
    }

    return iTaDxLkokX;
}

double gcFtipcrJ::UyZyUFNZ(int nCCxif)
{
    string euVgDQuepi = string("xmyOAMoLhqiWrkkuStLqdVapgfXexffTHyWxCxHZWcZhtlJmCl");
    int EttpNUqbpWTFPo = -440729832;
    int PpvYraMxksbY = -498753890;
    int cvtfdU = -1913803849;
    double LXVfxPrLC = 571062.2181665296;

    for (int NRCnaPs = 1029325956; NRCnaPs > 0; NRCnaPs--) {
        nCCxif += PpvYraMxksbY;
        cvtfdU *= nCCxif;
        PpvYraMxksbY /= PpvYraMxksbY;
        EttpNUqbpWTFPo = nCCxif;
        nCCxif = EttpNUqbpWTFPo;
        LXVfxPrLC -= LXVfxPrLC;
        EttpNUqbpWTFPo += PpvYraMxksbY;
        PpvYraMxksbY = PpvYraMxksbY;
    }

    if (nCCxif < 1582969080) {
        for (int PeNNslHKWSaZlUVE = 780204361; PeNNslHKWSaZlUVE > 0; PeNNslHKWSaZlUVE--) {
            euVgDQuepi = euVgDQuepi;
            cvtfdU *= EttpNUqbpWTFPo;
        }
    }

    for (int PThFGFHjfnFw = 1887037717; PThFGFHjfnFw > 0; PThFGFHjfnFw--) {
        nCCxif += PpvYraMxksbY;
        EttpNUqbpWTFPo *= EttpNUqbpWTFPo;
        EttpNUqbpWTFPo -= PpvYraMxksbY;
        nCCxif = cvtfdU;
        euVgDQuepi = euVgDQuepi;
    }

    return LXVfxPrLC;
}

void gcFtipcrJ::dPkZQKGCQn(bool zQiOnLPetdML, bool DuqYPKJJ, int hAxkEgctnzv)
{
    bool XvZmGCQjyIH = true;
    bool gJBPB = false;
    string WsWhkGZySm = string("DGVKcPctllAHWLtMtNrskkwssgCsmHarPtOSTrQwBmJTarZVPZLyqXtJfhwvPgERmqtjMRAoTGDI");
    string VJlLH = string("uOpvAUoQmPxqOrnRiwYeySIGSerBfIzYShgGtfqzuDxWa");
    double oJnNmA = -930369.6055304774;
    int hLflbxnUaToe = 1982500609;
    int DCekjfLeE = 1318213925;
    string vppWogAd = string("DQVhuRmxJPQaEwblRpbdpgrCfazddFBmurIWrEcJjWlzfpjpnTpZHVseibYdfEVGFXfhMQozktGGgUxvItJLUqYEHTNDAeqqAwMTnKkRzGkseqSrblcjVfroRczPt");
    double yPOcElnbH = 76646.07247547561;

    for (int VafDFwztlCMusVUh = 329121464; VafDFwztlCMusVUh > 0; VafDFwztlCMusVUh--) {
        XvZmGCQjyIH = ! gJBPB;
        DuqYPKJJ = ! gJBPB;
    }
}

void gcFtipcrJ::EDeYErRkneKPy(string cyLVoEjDay, int onTkYtujaGYCuLf, bool qNCYGVouWZRjE)
{
    double ZUiMCclor = -402963.60498825775;
    int etkRgVKaBW = -616264963;

    if (cyLVoEjDay != string("EnhPnnKtbnnGdztwLttPWWHuXotClRkbVnqBpgPcztaHjGqWAzouWLUeghkYtDuscaNqwULgGNaQWqVNFuOMgUncDqXkEcybqxBDPqfaXBmziasJzmpUWThINhQhOqrnrfXHuBpwZjByLaZPRQmnJkp")) {
        for (int xeODioFC = 205120102; xeODioFC > 0; xeODioFC--) {
            etkRgVKaBW -= onTkYtujaGYCuLf;
        }
    }

    for (int YLYYSkplLy = 873240504; YLYYSkplLy > 0; YLYYSkplLy--) {
        continue;
    }

    for (int aVusQBnBMLQ = 1526595756; aVusQBnBMLQ > 0; aVusQBnBMLQ--) {
        etkRgVKaBW -= onTkYtujaGYCuLf;
        etkRgVKaBW *= etkRgVKaBW;
    }

    for (int LODItzAJCjdD = 1903318921; LODItzAJCjdD > 0; LODItzAJCjdD--) {
        etkRgVKaBW /= etkRgVKaBW;
    }

    for (int dhWwIqs = 2111835377; dhWwIqs > 0; dhWwIqs--) {
        etkRgVKaBW += onTkYtujaGYCuLf;
    }
}

double gcFtipcrJ::iPmxOKE()
{
    double zaJGpXqjosnMlD = -36892.03977952913;
    bool kEDUUuvlYTZGbNBE = false;
    bool CGoLjgvb = true;
    int jnQlYWUgChDm = -962431113;
    double SoluTYiW = 103077.97969470127;
    double AYIFCKum = -756280.8980269984;
    double LLNMCbKIups = 626587.913294892;
    double ojKFAk = -933499.7544031078;
    double IpttLQYaQc = 254557.92097204097;
    double OmobpZTpLaW = -1042929.6093269237;

    return OmobpZTpLaW;
}

int gcFtipcrJ::RRrlGeIdkQ(bool ARTjfO, double JJUGjbHroyuRcNo)
{
    bool nmMuAmhQK = false;
    bool vsgHBUISmz = true;
    bool nCSUqzKXRsSbxCRU = true;
    int qRDggEwOXcoHK = 182912170;
    string gnQFUEUsaJ = string("LC");
    int inQGo = 1039041038;
    double AYltCCGltdXWcYVM = 864594.6070905947;
    double VAZDIjinIhHEjYyP = -326764.59328082466;

    for (int qBUCOeykx = 1754213196; qBUCOeykx > 0; qBUCOeykx--) {
        continue;
    }

    for (int IeVWNbPSCMXA = 381217231; IeVWNbPSCMXA > 0; IeVWNbPSCMXA--) {
        nCSUqzKXRsSbxCRU = vsgHBUISmz;
        nCSUqzKXRsSbxCRU = nCSUqzKXRsSbxCRU;
    }

    for (int XlkOxatOCkOsQmKl = 1041706036; XlkOxatOCkOsQmKl > 0; XlkOxatOCkOsQmKl--) {
        AYltCCGltdXWcYVM /= VAZDIjinIhHEjYyP;
        vsgHBUISmz = ! nCSUqzKXRsSbxCRU;
    }

    for (int nbYzQ = 1082760864; nbYzQ > 0; nbYzQ--) {
        nmMuAmhQK = nmMuAmhQK;
        inQGo = inQGo;
    }

    if (nCSUqzKXRsSbxCRU != true) {
        for (int JMtvAeLzR = 182557155; JMtvAeLzR > 0; JMtvAeLzR--) {
            continue;
        }
    }

    return inQGo;
}

bool gcFtipcrJ::zLRNKYbZnBS(string VilLRHvqppPbHX, double VQGcCI, int cLPliK, double ILtbRSpHYUv)
{
    int kwhyNkcDmtjnHtY = 83361069;
    int tdDPdxEFlImLOV = 1878772193;
    int hTvtPeefNZPUojBn = -399683705;

    if (tdDPdxEFlImLOV != 1878772193) {
        for (int kZZrmG = 47073448; kZZrmG > 0; kZZrmG--) {
            kwhyNkcDmtjnHtY = hTvtPeefNZPUojBn;
            tdDPdxEFlImLOV *= hTvtPeefNZPUojBn;
            ILtbRSpHYUv *= VQGcCI;
            tdDPdxEFlImLOV = kwhyNkcDmtjnHtY;
            hTvtPeefNZPUojBn -= hTvtPeefNZPUojBn;
        }
    }

    for (int BloWSVlFIE = 497853874; BloWSVlFIE > 0; BloWSVlFIE--) {
        ILtbRSpHYUv = VQGcCI;
        VQGcCI -= ILtbRSpHYUv;
        hTvtPeefNZPUojBn /= cLPliK;
    }

    for (int WnBVSk = 168084641; WnBVSk > 0; WnBVSk--) {
        cLPliK += kwhyNkcDmtjnHtY;
    }

    if (cLPliK <= -399683705) {
        for (int ukLZKdqndn = 1285810459; ukLZKdqndn > 0; ukLZKdqndn--) {
            continue;
        }
    }

    for (int TJdIKX = 1685337574; TJdIKX > 0; TJdIKX--) {
        continue;
    }

    return true;
}

bool gcFtipcrJ::FrDhK(bool OrHWAw, int RYypekTg, int CCDqjk)
{
    int hhfAIJJvVoNSXfXg = -100828341;
    string oGObh = string("dJwXWWaFprnIYgRGYdeTCqjZBKiPrEFVBYuvNOOlYxYZqWLMOBkJXKxbKqhltMjzxQUXMDGACCOQYqJCgsoHnuTdyNJCzCLECFObTxlhnKoOTCzqgtjzZFeZOMIjthtBmIgZksfJdHdTZJKrQDSRbntuzyhGXWthtUkvSHiGqPo");
    bool kIcDWvuCoeKylXzN = false;
    double PIjsVUJ = -409079.2107637786;
    double NipwDVFZOHsJ = -514306.21352917503;
    string QrtXoPzUcrYAIr = string("XrqqOLgHJjMFBOXQaTtahPUnEZyQoxLuzDDaXUqOaWVYFCRGRgtFIwoyQpxtFKhubzSfVnpnwdLoKtQWoHnPePsxfEYycoBKodzOmpFUSvzrEnIZBZkerOgCgJseQLJKgCXzHDEJOuhqCFVwFciOXkQuqwMYSvhTRkOmXBrOsnFxtFNUqqJMyYOqKYwjabuPIaEHCkTBqGeSyjwmkdbJjAXIHaTwgqPrkOGDcWMIqiuDND");
    int mNlJgpVTGM = -1838313489;
    bool ncWrzfdtviLCZcs = false;

    for (int nFudMOgy = 241875241; nFudMOgy > 0; nFudMOgy--) {
        NipwDVFZOHsJ *= NipwDVFZOHsJ;
        hhfAIJJvVoNSXfXg -= RYypekTg;
    }

    for (int mzOpMmHsOPCU = 696307131; mzOpMmHsOPCU > 0; mzOpMmHsOPCU--) {
        mNlJgpVTGM = mNlJgpVTGM;
    }

    if (oGObh <= string("XrqqOLgHJjMFBOXQaTtahPUnEZyQoxLuzDDaXUqOaWVYFCRGRgtFIwoyQpxtFKhubzSfVnpnwdLoKtQWoHnPePsxfEYycoBKodzOmpFUSvzrEnIZBZkerOgCgJseQLJKgCXzHDEJOuhqCFVwFciOXkQuqwMYSvhTRkOmXBrOsnFxtFNUqqJMyYOqKYwjabuPIaEHCkTBqGeSyjwmkdbJjAXIHaTwgqPrkOGDcWMIqiuDND")) {
        for (int BosCahFrb = 1573676065; BosCahFrb > 0; BosCahFrb--) {
            PIjsVUJ /= NipwDVFZOHsJ;
            QrtXoPzUcrYAIr += oGObh;
        }
    }

    for (int FeeYqmXSfaNiGQcg = 18653755; FeeYqmXSfaNiGQcg > 0; FeeYqmXSfaNiGQcg--) {
        kIcDWvuCoeKylXzN = ! kIcDWvuCoeKylXzN;
        RYypekTg += hhfAIJJvVoNSXfXg;
    }

    if (PIjsVUJ <= -409079.2107637786) {
        for (int vpIAkVE = 987567851; vpIAkVE > 0; vpIAkVE--) {
            RYypekTg += hhfAIJJvVoNSXfXg;
            OrHWAw = kIcDWvuCoeKylXzN;
        }
    }

    return ncWrzfdtviLCZcs;
}

double gcFtipcrJ::NneWm(string ddeWNkavoPLV, double GDbZz, string HBChr, string cPRgFZRqomGS)
{
    string GNfxmqPfFIyatNcJ = string("HOquEyFMzKGgejselWyDMJBHIbOwmFNLKAsVbjoWVihThcYDIu");
    double WihXUPwANGe = -905774.6612820232;
    string yJIhQGsbbbBnLdqh = string("lyGVCdqyfDzKfnXzYDyNgPLCExkKaCvvYbqMtZCiaBxDubbsIlvhYDZZyJKLoIuGiyBXzGUfaNcreWXeZfrYVYSP");
    string DccOC = string("kBrLjcLYHixSscYUOgIkgDLTmRPOzHszu");
    double BaBQs = -393135.2741221314;
    int YXvJRToe = -703727318;
    double SgSzZAqWfi = -386573.94523097505;

    for (int PtzRmtzAEmTtc = 1839354975; PtzRmtzAEmTtc > 0; PtzRmtzAEmTtc--) {
        ddeWNkavoPLV = DccOC;
        cPRgFZRqomGS += ddeWNkavoPLV;
        yJIhQGsbbbBnLdqh += DccOC;
        yJIhQGsbbbBnLdqh += HBChr;
    }

    for (int lOklbKR = 15139502; lOklbKR > 0; lOklbKR--) {
        DccOC = DccOC;
    }

    if (SgSzZAqWfi < -905774.6612820232) {
        for (int lKVaczMaqfLXWs = 1787534513; lKVaczMaqfLXWs > 0; lKVaczMaqfLXWs--) {
            BaBQs += BaBQs;
        }
    }

    for (int Wmsubop = 751904401; Wmsubop > 0; Wmsubop--) {
        cPRgFZRqomGS = HBChr;
        SgSzZAqWfi *= SgSzZAqWfi;
        ddeWNkavoPLV += ddeWNkavoPLV;
        DccOC += GNfxmqPfFIyatNcJ;
        DccOC = ddeWNkavoPLV;
    }

    if (WihXUPwANGe >= -386573.94523097505) {
        for (int oIHbdrr = 551512695; oIHbdrr > 0; oIHbdrr--) {
            BaBQs -= SgSzZAqWfi;
        }
    }

    return SgSzZAqWfi;
}

double gcFtipcrJ::WWRgOfHkVnay(bool nmAwBXmHjEFY)
{
    double gxLLB = 669318.3785482765;
    int EVfHQOZw = -1113163379;
    int IkiKnfHt = -1852460699;
    bool rSRnKwUt = false;
    int tFWeyTVS = 2011904152;
    string UyJuPGsIvH = string("qjRCp");
    int gRAnhlqGMysjhSnz = 1714125906;
    int xsIQkAfVQj = -2086321694;
    double YvmWdcKMSRuVxK = -1029264.7915262626;

    for (int mVJeVehPTwYI = 995354714; mVJeVehPTwYI > 0; mVJeVehPTwYI--) {
        gRAnhlqGMysjhSnz -= gRAnhlqGMysjhSnz;
        IkiKnfHt = xsIQkAfVQj;
        tFWeyTVS *= EVfHQOZw;
        gRAnhlqGMysjhSnz = xsIQkAfVQj;
        IkiKnfHt += xsIQkAfVQj;
    }

    if (xsIQkAfVQj == -1852460699) {
        for (int SYEQqotQUSbupbY = 1031563779; SYEQqotQUSbupbY > 0; SYEQqotQUSbupbY--) {
            continue;
        }
    }

    return YvmWdcKMSRuVxK;
}

gcFtipcrJ::gcFtipcrJ()
{
    this->tbNoquhQcAMSMbc();
    this->pKyheUXfzCgHgd(533503.228489196, string("qXeuMAPIehNzoyUkVzgzxwVuDZSBeAIncjkhwJqrGEvLPajMZnFDnyLJSKhhgxGXRyClF"));
    this->fYwKPyICxDiO(-764591.5609967682, false, false);
    this->UyZyUFNZ(1582969080);
    this->dPkZQKGCQn(true, false, 1618550543);
    this->EDeYErRkneKPy(string("EnhPnnKtbnnGdztwLttPWWHuXotClRkbVnqBpgPcztaHjGqWAzouWLUeghkYtDuscaNqwULgGNaQWqVNFuOMgUncDqXkEcybqxBDPqfaXBmziasJzmpUWThINhQhOqrnrfXHuBpwZjByLaZPRQmnJkp"), -1661569029, false);
    this->iPmxOKE();
    this->RRrlGeIdkQ(true, -840837.4454204541);
    this->zLRNKYbZnBS(string("YAdwnQRDrzMOfwoUtidSkvpIZYWUswUDSTXORMplyEHUYaviFyhcLudUxkDtxqSwteJZZjVRuFFldiQZsxkkgYsstjuxfszzGLyngLxIDRBXxszSDBSXBihFKxdYqTVLpHhhcwDmhfRVqPFYTGBzdVsfyANgwZRSflUVudvcfXIsPTCyiRyHWXXPudiNGPZuFfi"), -685386.1155991049, 1192529915, 388503.1440828066);
    this->FrDhK(true, -231821466, -565218947);
    this->NneWm(string("IvugbzOCUeQWOhCWytXuqpFEDDmAxhpxuczqeOODCEmNSIjclubTvBkvTyDKZYkRqhwmBdQmbSUqzDqktkKdTJdYAVjRhIgTKAKKyNVAj"), -227593.6462507862, string("OBCnGlYiXmxzXsjQkiSaOXMOhIoepsNzuiXILFjmzlWVPWMbWGHHOAUWMHUhgGzXfbWFkKGiRDg"), string("nQXofgbABBwHzlDRksuEkigYsJjHYBXRGHmfNzmePHaGRHbLNqtFNnilgcOUrTGOsAVysIncSlYrhMidCDzqAXEkcoaprgfkqtVOBjxwFycsswtGiOJiJkKfSObWpluXbAqrTZZnfFrmSRdmlKiXFkBaYiuECmxcvFhrpXdIWGSeWXtlPuTVVIdbnLJLoiPccCql"));
    this->WWRgOfHkVnay(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MWCORaxQe
{
public:
    bool yJxVscMx;
    int kTuJEFHPvuKpRq;
    int ECEsSHUHLyLWDU;
    bool luMoREn;

    MWCORaxQe();
    double DCIpfCoDbMeNX(bool tisOng, string PlxJzWoGLkNeFI);
    double ywuLPiriRDG(int zThxGyWksawzgur);
    double RshpYhtue(double BHafiN, bool bfIiojCzvWHWn, string DWmgEMokUsMLUkMJ, double oxyIyAXw, double RTCWAATkCZXDeR);
    bool mNlXUDFFVcRDp();
    double spQMpJ(double rItGNT);
    bool PRFsNg(double dftTcHrI, int MyELvqJi, int ahYRxETXqiHdQn);
    bool JfvKV();
protected:
    bool CItaWeNk;
    string vUEFH;
    string diyLJJoBfh;
    int wvGBUnkfmkHoQDq;
    string MpjTBWcChJZhpMdp;

    string jpatMoVEsTDSL(int XURYvHr, double oamqcawMoIXQqn, string yspamOlECUe, bool daNdAhrM, string qLhowDUu);
    void qSGxD(string HznGfAQVFPv, bool sRuFEGLeFfmH, int RvjlfWjZCZff, double GbBuQWJZnK, double YjlGldKDsxVduPM);
private:
    bool ctDfWepFQyo;

    int IBSliGOYXmDVVw();
};

double MWCORaxQe::DCIpfCoDbMeNX(bool tisOng, string PlxJzWoGLkNeFI)
{
    double cdWgVJsubpUDxd = 191762.62392890602;
    string HsLMi = string("RcCfveTNnLNcxgtGytFIELmdwSGDZZucKwkiBKQuejTBwGjeZkrQvqXXjEPDTiDKtxtpzDnfWVFnbkJCZuEuZYWfcnvMmAPWmsoHIrCgpAQJHZNtcmKABSFcfwqldwImZCKdFxixcceLtfCQikypgJsHFCslKRXtGqzCFoMnRGbxEtuCuNdAAZIsAMcTxbSeOtKzcmiOUXfFGtvsSJoxlOIOlmtRKaIjdBPeBqaSgjyqAWahR");
    double jApAMdI = -63382.99880821439;
    int fzeLEkYm = 305055130;
    string JxMcAlCAaJ = string("ySpFDhQqwWatUuJLSzlgbOiCJlReaKFkobBWnjOryDfHBSagYvrQXMqsHifSBsKdjCkKPWEpPIIEJyLcTKJGJABEMKOdAmwWjfbajWFsinwiEwrIIztZhHVhCgKJjnQXeCHkSzEfGBmuIzZsSCiUjPZPpdIcJCAUTpczLdhmCMLjGekVZUANnuOCzDLOxbtPstLKzAbM");
    bool ykCScHAZSUhZvl = false;
    string ryczUHQNyyO = string("QdElzIDSDlyvbuanQYCOwEPjMJbDFocJPsMCxbFAfILImxjzrVMBFDuwTOHbhnGtjChHlgTuJlZrdYaNbXSaqBoYAtEiPRQYhjoseQeIHOhAdPkVhTBamVfeKHyiSYiWfViysfgSHwKgrNPhXzaE");
    int czkDRWIS = 1792586312;

    for (int UPgiuGvfFB = 706520691; UPgiuGvfFB > 0; UPgiuGvfFB--) {
        continue;
    }

    for (int cDAYrwxjO = 160220437; cDAYrwxjO > 0; cDAYrwxjO--) {
        continue;
    }

    return jApAMdI;
}

double MWCORaxQe::ywuLPiriRDG(int zThxGyWksawzgur)
{
    string wHJFPAPwvQfKsr = string("lwQZkmLyNmYodHjIcZUPebyvldgRawfvITrOEeGVDYBMOgsJCdULaJJrpbchLKuGojuPzBgJJjsuwfEcOsvDYpdhlgnsbCPEsXMPobaBDVeUXOvQksImaycRgTLvfecbbPTBvBenaoWfdqAOZSRmoLneEpshtnqVBrGOFHwVlaBfGKCmPFDjPPUaBGmlNzFGEgYjfLQGJzknGdSceUCuSPBxIfluGAmdRFrFrlzCpcZBSQFiTqDwYufMs");

    for (int eSmuNZatRgfGVHGX = 667282632; eSmuNZatRgfGVHGX > 0; eSmuNZatRgfGVHGX--) {
        wHJFPAPwvQfKsr += wHJFPAPwvQfKsr;
        zThxGyWksawzgur /= zThxGyWksawzgur;
        zThxGyWksawzgur -= zThxGyWksawzgur;
    }

    if (zThxGyWksawzgur == -332473742) {
        for (int GeGmsUeGQy = 115646656; GeGmsUeGQy > 0; GeGmsUeGQy--) {
            wHJFPAPwvQfKsr = wHJFPAPwvQfKsr;
            wHJFPAPwvQfKsr += wHJFPAPwvQfKsr;
            wHJFPAPwvQfKsr += wHJFPAPwvQfKsr;
            wHJFPAPwvQfKsr = wHJFPAPwvQfKsr;
        }
    }

    for (int MiCRGM = 788892730; MiCRGM > 0; MiCRGM--) {
        wHJFPAPwvQfKsr = wHJFPAPwvQfKsr;
        wHJFPAPwvQfKsr = wHJFPAPwvQfKsr;
        wHJFPAPwvQfKsr = wHJFPAPwvQfKsr;
        zThxGyWksawzgur -= zThxGyWksawzgur;
        zThxGyWksawzgur *= zThxGyWksawzgur;
    }

    return 830687.2402379563;
}

double MWCORaxQe::RshpYhtue(double BHafiN, bool bfIiojCzvWHWn, string DWmgEMokUsMLUkMJ, double oxyIyAXw, double RTCWAATkCZXDeR)
{
    double GrXiZEd = -382027.17704975646;
    string BXxmaelfVvT = string("EpFpkRhKiHQxpPtwnoSvWctvlxmvjXBtEUVnulfCCVLJCdwYSMCdKjwzeThArLkIXQkAwhXHLUwfvGcwycBDBdsQvHNgtuyKZgEmrvTLTFVVxLEYQdbvsAjXDchZgbTLwQgIfZTtscxPiueolpXJtYnKDEODLRXkJOdWgqzlZOpeCGneczVKmxtNScijjLmdTHngqhQmqdBBGYOXtIViYtcqdGGguXPSkYikipkXjGwulhRA");

    if (BHafiN != -382027.17704975646) {
        for (int zdKndtOqlB = 2036176951; zdKndtOqlB > 0; zdKndtOqlB--) {
            oxyIyAXw += GrXiZEd;
        }
    }

    for (int krlevWQZYOozgxz = 239887857; krlevWQZYOozgxz > 0; krlevWQZYOozgxz--) {
        oxyIyAXw *= GrXiZEd;
        BXxmaelfVvT = DWmgEMokUsMLUkMJ;
        BHafiN *= RTCWAATkCZXDeR;
        DWmgEMokUsMLUkMJ = DWmgEMokUsMLUkMJ;
        RTCWAATkCZXDeR *= oxyIyAXw;
    }

    return GrXiZEd;
}

bool MWCORaxQe::mNlXUDFFVcRDp()
{
    string bcNFnVog = string("zBfFdgwyUbFhrvBJgWHpJdWKEZlbvSDCEVVQXfpQsOBqVbtUDTetmGVrZZVXBcRBwIaTQPapMjByYpithPwvLLyhUZSIxBLLZXDbDfcFFHIXbtVzDlVtEOcUsliOzsqDClZRZubFWEiKgCBgJecEEkgYaqEHxseieMAgymwSRoxpRCTaxiaAEHowPjXxubFUvQyDJkWUzflfTyYpRAzPFKhBfduvFbkfkUfXaIOZBMyalFK");

    if (bcNFnVog == string("zBfFdgwyUbFhrvBJgWHpJdWKEZlbvSDCEVVQXfpQsOBqVbtUDTetmGVrZZVXBcRBwIaTQPapMjByYpithPwvLLyhUZSIxBLLZXDbDfcFFHIXbtVzDlVtEOcUsliOzsqDClZRZubFWEiKgCBgJecEEkgYaqEHxseieMAgymwSRoxpRCTaxiaAEHowPjXxubFUvQyDJkWUzflfTyYpRAzPFKhBfduvFbkfkUfXaIOZBMyalFK")) {
        for (int uCRZWRuUsnxaQoMl = 2042069774; uCRZWRuUsnxaQoMl > 0; uCRZWRuUsnxaQoMl--) {
            bcNFnVog = bcNFnVog;
            bcNFnVog += bcNFnVog;
        }
    }

    if (bcNFnVog == string("zBfFdgwyUbFhrvBJgWHpJdWKEZlbvSDCEVVQXfpQsOBqVbtUDTetmGVrZZVXBcRBwIaTQPapMjByYpithPwvLLyhUZSIxBLLZXDbDfcFFHIXbtVzDlVtEOcUsliOzsqDClZRZubFWEiKgCBgJecEEkgYaqEHxseieMAgymwSRoxpRCTaxiaAEHowPjXxubFUvQyDJkWUzflfTyYpRAzPFKhBfduvFbkfkUfXaIOZBMyalFK")) {
        for (int uMFxvOp = 1704205584; uMFxvOp > 0; uMFxvOp--) {
            bcNFnVog += bcNFnVog;
            bcNFnVog = bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog = bcNFnVog;
            bcNFnVog = bcNFnVog;
            bcNFnVog = bcNFnVog;
        }
    }

    if (bcNFnVog > string("zBfFdgwyUbFhrvBJgWHpJdWKEZlbvSDCEVVQXfpQsOBqVbtUDTetmGVrZZVXBcRBwIaTQPapMjByYpithPwvLLyhUZSIxBLLZXDbDfcFFHIXbtVzDlVtEOcUsliOzsqDClZRZubFWEiKgCBgJecEEkgYaqEHxseieMAgymwSRoxpRCTaxiaAEHowPjXxubFUvQyDJkWUzflfTyYpRAzPFKhBfduvFbkfkUfXaIOZBMyalFK")) {
        for (int DNPFDqJlnORg = 853852310; DNPFDqJlnORg > 0; DNPFDqJlnORg--) {
            bcNFnVog = bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog = bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog += bcNFnVog;
            bcNFnVog = bcNFnVog;
            bcNFnVog = bcNFnVog;
        }
    }

    if (bcNFnVog <= string("zBfFdgwyUbFhrvBJgWHpJdWKEZlbvSDCEVVQXfpQsOBqVbtUDTetmGVrZZVXBcRBwIaTQPapMjByYpithPwvLLyhUZSIxBLLZXDbDfcFFHIXbtVzDlVtEOcUsliOzsqDClZRZubFWEiKgCBgJecEEkgYaqEHxseieMAgymwSRoxpRCTaxiaAEHowPjXxubFUvQyDJkWUzflfTyYpRAzPFKhBfduvFbkfkUfXaIOZBMyalFK")) {
        for (int VpnwDULMSlQIuNy = 79480081; VpnwDULMSlQIuNy > 0; VpnwDULMSlQIuNy--) {
            bcNFnVog = bcNFnVog;
            bcNFnVog = bcNFnVog;
        }
    }

    return true;
}

double MWCORaxQe::spQMpJ(double rItGNT)
{
    int JHExOAIi = 462770076;

    for (int INogebM = 1996742530; INogebM > 0; INogebM--) {
        JHExOAIi = JHExOAIi;
        rItGNT *= rItGNT;
        JHExOAIi -= JHExOAIi;
        rItGNT = rItGNT;
    }

    for (int lyqveDjSKgjQ = 1421286572; lyqveDjSKgjQ > 0; lyqveDjSKgjQ--) {
        continue;
    }

    return rItGNT;
}

bool MWCORaxQe::PRFsNg(double dftTcHrI, int MyELvqJi, int ahYRxETXqiHdQn)
{
    double HaTlyuYIJoYFgKdR = -754398.5224566406;
    string UlCblwGmMlIf = string("dWmclbeQwPRCdELbGfnrsVsVxsGNMgQLzluWoDEybZMofZAxVspIBmHpmLPNeCqxOahqXgNUWRvNWXehIzDKymmxJMqDOtmENHggDNVTuAUSFVRJZnunRKEREoQzSdfzAbBFMISM");
    string NiQqQbxRL = string("axperhPIqLmSBefUAsrhRyBgxpKWviIhmmUnDhkFLFuD");
    int cxtskhzVBQtAE = 870929346;
    bool jRStZfMR = false;
    string FpKkxL = string("KdwimTFyAuWcXnWpRsgJRyF");

    return jRStZfMR;
}

bool MWCORaxQe::JfvKV()
{
    string ufzQocDWhxZWfus = string("AmdcUKPSPZIkCrLqNhqKqYFpfKqbEIFtFIkBxWWsmMDgVxoyqaPxNUMXpJwSPNmcoEUuNLnjgryLKTeBnMpARtjBrySjYZiiupOnomGSUZVsZfNbBlpRWjQqJOYdgMuQcYQLnxgWhqQrnJnqUQlqFbOGLLIhoQmGOpontzFLrqBdE");
    string qcutoVSCuNLhgF = string("GAVJhgVDfOjFRrDaJLJdRfsJSfnjdJlVtPnXzhDQdMnjsmmyWqnpsYjvHxMDBZvoZUtAJEdffCoxemlAXLqlKtPHoJXSjVQp");
    string MBZuwmOtXTyMnEs = string("GyaSqgRfXigcqzaAttKhfxuxFuABvtAWefRhzYRKPgkjjbuPOqqfSKfYvZrBbSkoGWwfkgBiOMZEjTlTdfehDZrXRfhHRHWEmIqcalBLuLoWQQpoSMzGUBUPUpfKvXphtdqxHfGLjzcXPlOnIktMjLfwkkDbwMPzdHeNpzCTVKNdUymQzQxRdFZeDImOqVabATtNspOUvthsGUCUtDUJYXvuyvcRQDAhQWjnZYufKiRbzCxJtZsj");
    string MXjgiMM = string("pWywGSLsfnZuHntkwhIOxxbJQVdVMiRNSRMVigmEmRbypwLWLNpTFfeqvlXBUHFsRqiqdtqtPleYJOeTlrBoqXgBOamVNsiLfNKCexiblWBXsDwuqmMQBKbqdRhwARfsWfwVosHtWtXfTDjHIhVQmYJkFsCGNMmWzIUXuSamThmvxfQgDJWiJOqCiZXaxVrAFo");
    string VJzRTNNuM = string("ycaYpNhjfUQfzfchfdmJZGewrEwwUZfFEGMcyrTkrIDToDsrxnSKAfUUAoQpTJBMBmBmJdRPfIgYUihsuDsfBKZjaEHcpIawkzPIoPwffUUshvMLsIkBhNomFYcQWvpuraubD");
    bool FxdteohqOJuqqG = false;

    if (MBZuwmOtXTyMnEs > string("pWywGSLsfnZuHntkwhIOxxbJQVdVMiRNSRMVigmEmRbypwLWLNpTFfeqvlXBUHFsRqiqdtqtPleYJOeTlrBoqXgBOamVNsiLfNKCexiblWBXsDwuqmMQBKbqdRhwARfsWfwVosHtWtXfTDjHIhVQmYJkFsCGNMmWzIUXuSamThmvxfQgDJWiJOqCiZXaxVrAFo")) {
        for (int GBBFNjrYp = 1975122891; GBBFNjrYp > 0; GBBFNjrYp--) {
            MXjgiMM += MBZuwmOtXTyMnEs;
            MXjgiMM = qcutoVSCuNLhgF;
            ufzQocDWhxZWfus = qcutoVSCuNLhgF;
            MBZuwmOtXTyMnEs = qcutoVSCuNLhgF;
            VJzRTNNuM = ufzQocDWhxZWfus;
            qcutoVSCuNLhgF += MBZuwmOtXTyMnEs;
            VJzRTNNuM = MXjgiMM;
        }
    }

    return FxdteohqOJuqqG;
}

string MWCORaxQe::jpatMoVEsTDSL(int XURYvHr, double oamqcawMoIXQqn, string yspamOlECUe, bool daNdAhrM, string qLhowDUu)
{
    string hWWiASwx = string("wumbsD");
    string ZUjbCPtKHrWK = string("EDCztlFQVrgySeSesuMJfQDgGDKWpZFIlMSlJYPzbjnGHxKSYVLeFNXSXCwleQkdSusjhNmcGzztpbDQQ");
    double rYvKTglpBfTqaEs = 135292.74882170817;
    string ekblSDOnVZKY = string("kZZINHhrZhmrOxFkopkXWiSQtUnfWfedFgCFlDtMHkNIlbLHPfoCuHXlTeLOKtiletHbGOGniPTFYSMvVrEFDpbnXVgxhmCIB");
    string CVCzCHofT = string("aFJZwRbXgygYxqhQeGMhImrnmGJOPZpEXAFyUWSXcOVcrCZJCitxYnqaSwVQGahjbeDhfvzOOHNzRufRaCWmOziSxMqCSyyvBPQvyKUsFmHepllfnMgwTiJLYXNLzBMrbQgVsGUDDClHLEVSGqac");
    int TvzXgmGP = 446346449;
    double dhKQLUB = -797938.272166633;
    double DsbTgUSwp = 884449.6121005976;
    double KsHtxipNctElj = 785572.7954387876;
    int OlCmxgegOjRHYe = -234588594;

    if (ekblSDOnVZKY <= string("aFJZwRbXgygYxqhQeGMhImrnmGJOPZpEXAFyUWSXcOVcrCZJCitxYnqaSwVQGahjbeDhfvzOOHNzRufRaCWmOziSxMqCSyyvBPQvyKUsFmHepllfnMgwTiJLYXNLzBMrbQgVsGUDDClHLEVSGqac")) {
        for (int sKdgYPOlIEOFNX = 706738690; sKdgYPOlIEOFNX > 0; sKdgYPOlIEOFNX--) {
            oamqcawMoIXQqn /= oamqcawMoIXQqn;
            hWWiASwx = CVCzCHofT;
        }
    }

    return CVCzCHofT;
}

void MWCORaxQe::qSGxD(string HznGfAQVFPv, bool sRuFEGLeFfmH, int RvjlfWjZCZff, double GbBuQWJZnK, double YjlGldKDsxVduPM)
{
    string VaqIslUFUAoMLV = string("IzLQtnAbsXakxJGNHVFOlRsymLDWhtYdmrYdTbqwDeiDHCTHTrWlQdlgivZSLTiTHiCQYbPYYzTUiQwlVMWhKQzNdERfiTAEkJPVJzuhBIuyKQLBiWlvgkjMeUUENmQqYNoMipRfBKQzyVcmNKtFQCAkQniKfhMJoKstTqmTcymgOFoNzTcIfDRlzaskswkWfAwfFVRrgNpuzvmGnRpWTcQL");
    double EQfnUROjeR = -779160.8960796681;
    int fZlZUPieUXlUdFvk = 12794289;
    double lszTptlbXYoBU = 709249.7844824037;
    string IEFPoHZ = string("uadOWUiswZhzjaqZmeDfqDMIhexaVerfAgYUfzHWrFjhRGGGBBbCBHFPkPBPQEgDZHTEloXqqxNmmVDgLdUtGYegTWghhdidaaLkvkOmiXMFEzlqKbIKNVTRsPUtVXhSypfvktfLZoUYmxQwrfzmmFipTlplfvvpEEmcPfsLCUlDqPAV");
    bool rWpisZVHdOyOtYbU = false;

    if (lszTptlbXYoBU <= 698696.2582540332) {
        for (int AozvoqwaPwe = 1442832601; AozvoqwaPwe > 0; AozvoqwaPwe--) {
            VaqIslUFUAoMLV = VaqIslUFUAoMLV;
            sRuFEGLeFfmH = sRuFEGLeFfmH;
        }
    }
}

int MWCORaxQe::IBSliGOYXmDVVw()
{
    double QAtzkijEs = 346635.7472465015;

    if (QAtzkijEs < 346635.7472465015) {
        for (int JUqOy = 1567925798; JUqOy > 0; JUqOy--) {
            QAtzkijEs -= QAtzkijEs;
            QAtzkijEs = QAtzkijEs;
        }
    }

    if (QAtzkijEs != 346635.7472465015) {
        for (int HwbOXrwQpZeS = 463045533; HwbOXrwQpZeS > 0; HwbOXrwQpZeS--) {
            QAtzkijEs *= QAtzkijEs;
            QAtzkijEs /= QAtzkijEs;
            QAtzkijEs += QAtzkijEs;
        }
    }

    if (QAtzkijEs >= 346635.7472465015) {
        for (int NTXtOEsSnNE = 60189738; NTXtOEsSnNE > 0; NTXtOEsSnNE--) {
            QAtzkijEs = QAtzkijEs;
        }
    }

    if (QAtzkijEs >= 346635.7472465015) {
        for (int MJjwKQhKN = 578501387; MJjwKQhKN > 0; MJjwKQhKN--) {
            QAtzkijEs -= QAtzkijEs;
            QAtzkijEs += QAtzkijEs;
            QAtzkijEs = QAtzkijEs;
            QAtzkijEs += QAtzkijEs;
            QAtzkijEs -= QAtzkijEs;
            QAtzkijEs += QAtzkijEs;
        }
    }

    return 1279006652;
}

MWCORaxQe::MWCORaxQe()
{
    this->DCIpfCoDbMeNX(true, string("BOtrlUJFxoNXreYWInDyOafNWjuEtceQ"));
    this->ywuLPiriRDG(-332473742);
    this->RshpYhtue(104746.37256702987, false, string("XJGcClLCfgnnCZGbacRgzYgSqFPSnAgPeTymKYovBGVWeUqKtTBmAUcEHfZQToLiNmxpRjDcoPkikjmcDBaHQMdFxLTFqDFpeWLzMizbgfcMIdiiAZQajiSFzgtJcgWcDwTpvpjOVIUfFehlQPHkQNAiVjjyACwGSquherhAwSOlLAtSUUuZIzVyGqLdDVaJLsrZqperjlKcHpVITvSQuaGTGighMAyscUfntcRXSZljrMiAZMwOsnUrDxwhR"), 116222.08528634533, -468626.6867889355);
    this->mNlXUDFFVcRDp();
    this->spQMpJ(626404.6623578289);
    this->PRFsNg(584219.1626952313, 1233145070, -755944324);
    this->JfvKV();
    this->jpatMoVEsTDSL(1606411842, 554977.2616151957, string("eOSlFzcTdczrLLFOOHJnNduGrRRQpXqQFBcuXJ"), true, string("VvglIbxPfiNXjjMeUrDafdEFozLGiQCjuJgCQcbSz"));
    this->qSGxD(string("jrilySIAhXdOZTSYllxvlzhyerAlpIqrQOREqXscYTtMHSnIVsiNjDiCoPPoTypzYCsLXRJBmmiVDJTpxtheuUVnOyWzjirvOSaYyVEUWqLwRfphjlyywVMOdyeUaPSuelfLeqMgYk"), true, 229588402, 698696.2582540332, -237067.23319340884);
    this->IBSliGOYXmDVVw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QEIyXyDLaXBxnr
{
public:
    bool xHFaamwhfTHoK;
    bool gBbHPwMx;
    int mjlapRZyFpXkdBIC;
    int QwqBQq;
    string htjtRvsCnoTz;

    QEIyXyDLaXBxnr();
    string pBBZhVKdEziepzO(int OnKXxeVWKOAh, bool yBChqqHlmZhmir, double QUhgzWNKIV, string urNGkG);
    bool HJnCHLSDFSX(double DVvcqsXsmbYpCB, int jwmeMpvzGmqv, int WvlEw);
    bool zDxMpgnGMNzZJD(bool RFzNoxnkGIZh, string URbAfmsFYwBQck);
    bool JGtmiAJbjzTkgNB(int iAxIlvrEzaBvSzs, string BIQnZCIL, string eWqLExKLosXMz, bool lVBAHRaXzCqbtkxc, bool NYiZnnaSsqTM);
    int lXJJlTQhaocWFe(string aEjiswavoogdJ, string SjtSihggKdrYrSe, double ojvXwsxod);
protected:
    int WQRpVb;

    void hAioGruZlgTeBUfs(double nWfgFWhvJCGk, double JpEeInuGWn);
    void BXqiU();
    void ywgXQr();
    void zsXVifIt();
    string oJgPSGmEGtBxvAy(double UmFoTRUfOaKdWYL, double ADblYJmORO, int ixjMSULzn, int iBFHQzncBrkdy);
    bool TiZoxiMXXpXNbv(int eVSgksxEUpMhI, string fSTAxl);
private:
    string KkOnremLD;
    int ofsqdsw;
    int LlDjdkxlbsZVVSFY;
    string LfcJE;

    void AYDTgQIAZlskcWK(string Zvueh, int emyQr, double dSCjKL, string xCubbSltCSsx);
    int sozvWWFuNlDclGN(double gLcTr, double BaCRdYcNuEaqTnr, double DxSgmk, double npOwochHEYeglJz);
    int rkPzgoacKXH(double KrWvZgLBfHcQFf, double NjJDWDyAIT, bool vcGlmU, bool qrVZWeDU, string umpmdb);
    string iGDKRTtNrYVMGq(bool IivUG);
    void pgjxqXTvZCK(int kUujQUw, int yAZNpuApwXFtYZy);
    bool dmBHULhdPemsYjey(double IpGMNwy, string fzdlzmLIzaiAx, bool qJfciYhKo, string ulIDgagWyz, bool ZjoLcSkeMjpyuw);
};

string QEIyXyDLaXBxnr::pBBZhVKdEziepzO(int OnKXxeVWKOAh, bool yBChqqHlmZhmir, double QUhgzWNKIV, string urNGkG)
{
    int onxMeUikmJFr = 1696433307;
    int jvhBUO = -503347620;
    double SwnxLj = -395414.65338819777;
    bool qmVpwYMsx = false;
    double ugASaqpVLuJrtiDO = 109324.53099718642;
    int iHYWBhuCWC = 1544453247;

    return urNGkG;
}

bool QEIyXyDLaXBxnr::HJnCHLSDFSX(double DVvcqsXsmbYpCB, int jwmeMpvzGmqv, int WvlEw)
{
    double pXWDqjyzifhpYaac = 563728.9495753336;
    bool FUcqPuLvmTZIzpO = true;
    bool oCWqSfuvhlDgwLjh = true;
    string tkkAaGPtaiJR = string("VusHzpMCwhVnVEaqPeNnfgjmMyiizpADrbJICIGCVqAOdIWHHfyGzlpbRXnzvubYBZpXjDIhrtHlBqoWCDGcLBNBQFGKHuHRWbUhjIzmZhPVfpQGCJKCmVJBIhJZSUllQziYiHKNUmCxHRfHhNUdvDmXDtZYnyzqjVLuknuPwDUXVhkUMIbGALWePxMKGl");
    int LvMzoNHgBnx = 163393763;
    double BnkPWzmcvkXG = -603933.2041456756;
    int uaXXkeowLyr = 1440564350;

    for (int BhTkBSKOqQDPsv = 436082680; BhTkBSKOqQDPsv > 0; BhTkBSKOqQDPsv--) {
        WvlEw *= WvlEw;
    }

    for (int YfGxvjWMy = 684984804; YfGxvjWMy > 0; YfGxvjWMy--) {
        tkkAaGPtaiJR += tkkAaGPtaiJR;
        uaXXkeowLyr /= WvlEw;
        LvMzoNHgBnx *= jwmeMpvzGmqv;
        BnkPWzmcvkXG /= BnkPWzmcvkXG;
        BnkPWzmcvkXG -= pXWDqjyzifhpYaac;
    }

    return oCWqSfuvhlDgwLjh;
}

bool QEIyXyDLaXBxnr::zDxMpgnGMNzZJD(bool RFzNoxnkGIZh, string URbAfmsFYwBQck)
{
    int SKyVf = 814388733;
    double hFHcSzpKISLkMGWb = 180424.8377383337;
    string uHblbNjb = string("bJEMEDpVAYwswIsHtxdYkDttfDVWNoJLLFqTOtKIhyDEPPwrpMvcvNCHjxELaXLSOGSQwuKyuSGQDIMwKowpfXehBPqWwtIPmZTpHUkrEStAlbwTBGwglPtDRxaftbCkEqpSJdaxZixUuvQGvXHHCYhKnr");
    double KxYntFbwprZYaJDE = 298079.51274817553;
    string XPtzHONMQNM = string("vcbehxlvKURWQTfojViCXjmEAoQQxGqpKrTuAyfSWikkAkWtHCbOVwCYAYxUaZGGRjuksrnxMHpXmWlEqIMHsxyryDqceRMdHRfjwBBnbLBLDeMXRjEOaQpVkXgsInWoTWXtuKnEynmERQylRzEtDJoYCbdWfQsOiqBMmFjdqNXoZNOXfkiGrrOYXPwHvLfZJUbLKocRJljJUhKargEnkYAGiaTznllf");

    for (int IBAjvFZGpNTUyq = 1216469749; IBAjvFZGpNTUyq > 0; IBAjvFZGpNTUyq--) {
        hFHcSzpKISLkMGWb += KxYntFbwprZYaJDE;
        RFzNoxnkGIZh = RFzNoxnkGIZh;
    }

    for (int NxesgphZZGDp = 1813757490; NxesgphZZGDp > 0; NxesgphZZGDp--) {
        hFHcSzpKISLkMGWb -= KxYntFbwprZYaJDE;
        KxYntFbwprZYaJDE += hFHcSzpKISLkMGWb;
    }

    if (uHblbNjb != string("vcbehxlvKURWQTfojViCXjmEAoQQxGqpKrTuAyfSWikkAkWtHCbOVwCYAYxUaZGGRjuksrnxMHpXmWlEqIMHsxyryDqceRMdHRfjwBBnbLBLDeMXRjEOaQpVkXgsInWoTWXtuKnEynmERQylRzEtDJoYCbdWfQsOiqBMmFjdqNXoZNOXfkiGrrOYXPwHvLfZJUbLKocRJljJUhKargEnkYAGiaTznllf")) {
        for (int PlSDpLcfNkyuV = 406218316; PlSDpLcfNkyuV > 0; PlSDpLcfNkyuV--) {
            URbAfmsFYwBQck += XPtzHONMQNM;
            XPtzHONMQNM += uHblbNjb;
        }
    }

    for (int sxLPjZreFKpPeIn = 722408055; sxLPjZreFKpPeIn > 0; sxLPjZreFKpPeIn--) {
        hFHcSzpKISLkMGWb += KxYntFbwprZYaJDE;
    }

    return RFzNoxnkGIZh;
}

bool QEIyXyDLaXBxnr::JGtmiAJbjzTkgNB(int iAxIlvrEzaBvSzs, string BIQnZCIL, string eWqLExKLosXMz, bool lVBAHRaXzCqbtkxc, bool NYiZnnaSsqTM)
{
    bool fLyefHg = true;

    for (int gFWdIDNUSQ = 306303780; gFWdIDNUSQ > 0; gFWdIDNUSQ--) {
        NYiZnnaSsqTM = fLyefHg;
        NYiZnnaSsqTM = NYiZnnaSsqTM;
        BIQnZCIL = eWqLExKLosXMz;
    }

    for (int OfTGThgPJ = 126680330; OfTGThgPJ > 0; OfTGThgPJ--) {
        BIQnZCIL += BIQnZCIL;
        fLyefHg = ! fLyefHg;
        lVBAHRaXzCqbtkxc = fLyefHg;
    }

    for (int EDtRxVzXTn = 1298971414; EDtRxVzXTn > 0; EDtRxVzXTn--) {
        lVBAHRaXzCqbtkxc = NYiZnnaSsqTM;
        BIQnZCIL += eWqLExKLosXMz;
        BIQnZCIL += eWqLExKLosXMz;
        BIQnZCIL = BIQnZCIL;
    }

    for (int fHABmmygwCb = 1874856346; fHABmmygwCb > 0; fHABmmygwCb--) {
        fLyefHg = NYiZnnaSsqTM;
        lVBAHRaXzCqbtkxc = ! lVBAHRaXzCqbtkxc;
        iAxIlvrEzaBvSzs *= iAxIlvrEzaBvSzs;
        NYiZnnaSsqTM = ! NYiZnnaSsqTM;
    }

    return fLyefHg;
}

int QEIyXyDLaXBxnr::lXJJlTQhaocWFe(string aEjiswavoogdJ, string SjtSihggKdrYrSe, double ojvXwsxod)
{
    bool veueZKXaglq = true;
    bool IlhOFIIo = true;
    bool sWqLmXOLJTzRX = true;

    for (int jUQBiRvq = 1405109792; jUQBiRvq > 0; jUQBiRvq--) {
        IlhOFIIo = ! veueZKXaglq;
        aEjiswavoogdJ += SjtSihggKdrYrSe;
    }

    if (sWqLmXOLJTzRX == true) {
        for (int wUNXDSRvTSEOkLP = 1101069835; wUNXDSRvTSEOkLP > 0; wUNXDSRvTSEOkLP--) {
            ojvXwsxod *= ojvXwsxod;
            IlhOFIIo = IlhOFIIo;
        }
    }

    return 578044095;
}

void QEIyXyDLaXBxnr::hAioGruZlgTeBUfs(double nWfgFWhvJCGk, double JpEeInuGWn)
{
    bool wmtBbBrf = true;
    bool Skimvw = false;
    int KIPKfqAqxod = -1701662161;
    string BDCfc = string("BeTYjMXtixlWVvzJFALT");
    bool VgJKCbXGV = true;
    string iUKyO = string("WTRJGsVuexDpShGpABDPnkZSCtVhLPS");
    string yGkxvkCKvvKUzQEX = string("kmusOTujLboTzFbmDpKRrUfzqzDsMYhhzSRyWiElbLlzigNOQDimvJbJCgVRBxjXmQGSyMNbKQXuVQbwtzosxTkLlabeDbrYedXDNUeKusIx");
    string PNmyfIckwCCeICHj = string("wFlpAzIlBXDrOQRdDKvSTfresWtYJhJgPKrHWQEeLRvfvVjuXYCGhPxXsdPFIUpprwSXTpVoQcTJPmibMxZREvzRmoiACzvrYjQKLXwIGcdkXcGsaDrBGVDqmDxhiURVvkITuONmeSeduNDUXKgvJUOrAxyVaIZhEhIvMSYTDoMzacBWUTOcDnwzMiXQShCoLormnPCoiIZXCqUKfmNSpgUNYolwquyyXzu");

    for (int RWozBQHUOJSjvu = 735435673; RWozBQHUOJSjvu > 0; RWozBQHUOJSjvu--) {
        JpEeInuGWn += nWfgFWhvJCGk;
    }

    for (int vjmIxOaCPiVXO = 1107539781; vjmIxOaCPiVXO > 0; vjmIxOaCPiVXO--) {
        wmtBbBrf = ! VgJKCbXGV;
        BDCfc = BDCfc;
    }
}

void QEIyXyDLaXBxnr::BXqiU()
{
    string oOzAINCGRBNJz = string("umuRueNtnMJISLuOLMoocySEfJZAOvSWywtxROFwDKyTUUIcvhFBoDmRcjdoNSfqUIARmrdCCiefgpuUmSHkSwvMnrylfYuYzPlUzblUnqcSEsuWzEwSuGaAMxjno");
    int OUSpspypdU = -863145424;
    double tFxSptqNB = 114698.93146200839;
    string BcafavoBvT = string("qgdeKiPQKUoDZcDzKFIvYVNOhZZBMnuOHHxBCiBnkMDrmUjXRBqNPvFENeOjqKhSRQbrHyZvavsmtckHxiXLQLhn");

    if (tFxSptqNB > 114698.93146200839) {
        for (int jvusATjcQVauBV = 1658666480; jvusATjcQVauBV > 0; jvusATjcQVauBV--) {
            continue;
        }
    }

    if (BcafavoBvT == string("qgdeKiPQKUoDZcDzKFIvYVNOhZZBMnuOHHxBCiBnkMDrmUjXRBqNPvFENeOjqKhSRQbrHyZvavsmtckHxiXLQLhn")) {
        for (int UdizstiwflOesXJK = 1914911733; UdizstiwflOesXJK > 0; UdizstiwflOesXJK--) {
            continue;
        }
    }

    for (int biBuBwua = 95473299; biBuBwua > 0; biBuBwua--) {
        oOzAINCGRBNJz = BcafavoBvT;
        tFxSptqNB -= tFxSptqNB;
    }

    for (int aBDLn = 1780487325; aBDLn > 0; aBDLn--) {
        oOzAINCGRBNJz = oOzAINCGRBNJz;
    }

    for (int jHBvaKCBbbLN = 893972972; jHBvaKCBbbLN > 0; jHBvaKCBbbLN--) {
        BcafavoBvT += oOzAINCGRBNJz;
        OUSpspypdU -= OUSpspypdU;
    }
}

void QEIyXyDLaXBxnr::ywgXQr()
{
    bool RGLjbTPSzbV = true;
    double YvErJNWFRpuCj = -534637.0728751866;
    int spQfoprokiL = -2077352559;
    string wEyTIRgdWfDqvcl = string("OTUhFLlhyACpozSsyDiDyWaDgcwuUMHrNpxPPoQXYdtaYUtwZyKWHNNKnuSTODzMBtDlxxUlPEvXXjaraTwTaanPCOvxrDEwAaRkVENmSzOzjieDgooJhEKcgnKWTeYaCFmZnJenQjUgNCXWWrjEFNnxVVMjLCQVynP");
    string CFMLTUQaT = string("KxHYDqYySgVrxiwMPbSPvFTRlHfVDboTkjytbRZylVwCSTXXtJYyYgNqtHDmKKXJHBpbLwSnpgWvwkXJCRvCoxePQvJZiSEwEQYYeIrPXusocXHVCKnTxVabYdhRMjASosCBeq");
    string QuZcCjFQ = string("AyAtKKYxoEzSzBJbvgSOfMnBlgpXHRIaTxyyDTIsPrcbDRIENCWIkLSvhQIKMAwhvKlFYbNEzwtMvFTCtLarpAOPUnroaSrpdvrrKqhETLRVSeamurNWzJalFSPNDqMLJiQEfIxZjgybjDPhtTZarmyzcrEyCcdgWOORoqTjydUwRzdxiF");
    double IDPsUBvMlozQStg = 653393.325979468;
    double uTYPJBBiiAUAfHNP = -871076.8350115096;

    if (IDPsUBvMlozQStg != -871076.8350115096) {
        for (int SJxoBtGDhG = 1654839961; SJxoBtGDhG > 0; SJxoBtGDhG--) {
            QuZcCjFQ += CFMLTUQaT;
            wEyTIRgdWfDqvcl += wEyTIRgdWfDqvcl;
        }
    }

    for (int TTHrbfmKd = 10889206; TTHrbfmKd > 0; TTHrbfmKd--) {
        CFMLTUQaT = CFMLTUQaT;
    }

    for (int vaODODJGEXoJM = 341653148; vaODODJGEXoJM > 0; vaODODJGEXoJM--) {
        uTYPJBBiiAUAfHNP += uTYPJBBiiAUAfHNP;
        wEyTIRgdWfDqvcl += wEyTIRgdWfDqvcl;
        CFMLTUQaT = CFMLTUQaT;
        QuZcCjFQ += QuZcCjFQ;
    }
}

void QEIyXyDLaXBxnr::zsXVifIt()
{
    int suQTXm = 873499411;
    bool DBKoTJuI = false;
    bool IKYrKtyNlifmCKK = false;
    int HzjTqtrERzfO = -537124378;
    string FJCsEHeQGgjk = string("ghyGdsKOJmLVqkCxvneUDAlPXXCVdzmxlRNFhwtNlwktJJbsqJETTocSyYJcIVLtPNYFLcSNLOYVNuumfGNCHnFQCzihRvrbhBfhVFXgfUmDviYzEzLxmPHyWStSMziyGSiqzNpexhEVzASZluLuWfLmGKhJMxuiEQl");
    double eRXHZFkpaHtrSm = -193405.575714514;
    string OhsgJWq = string("hhoEnTNmVacUVnTtYsABvMMBPrSJeIxjzJjXPKxDSENowxvalbPlcrHOXLZdbOKPInRZfrGDaoVTgp");
    bool Psvjj = false;
    int QukxNIut = -1971709707;
    int wogELvwzlHXeu = -1871361246;

    if (IKYrKtyNlifmCKK != false) {
        for (int gQyKRsBdOo = 1550912548; gQyKRsBdOo > 0; gQyKRsBdOo--) {
            continue;
        }
    }

    for (int BwNHzeSBnCk = 1205881421; BwNHzeSBnCk > 0; BwNHzeSBnCk--) {
        continue;
    }

    for (int VXvgKlA = 1665835927; VXvgKlA > 0; VXvgKlA--) {
        continue;
    }
}

string QEIyXyDLaXBxnr::oJgPSGmEGtBxvAy(double UmFoTRUfOaKdWYL, double ADblYJmORO, int ixjMSULzn, int iBFHQzncBrkdy)
{
    int CslcztoTZGlSrm = -664795745;
    string gNPzUkLOvDzm = string("ughiANGoCHyRaKqfITTvRaybJztdVuYjVWMKtSJwiFJHtCZqhAGxkBtIpHoUP");
    bool jsMyXDmTHvyfOs = true;
    double rxhaGa = 856518.5208006538;
    int zMDupw = -1438880262;

    for (int rxtJgFcGH = 1612939738; rxtJgFcGH > 0; rxtJgFcGH--) {
        jsMyXDmTHvyfOs = ! jsMyXDmTHvyfOs;
        ADblYJmORO += UmFoTRUfOaKdWYL;
        zMDupw -= ixjMSULzn;
        ixjMSULzn = iBFHQzncBrkdy;
        zMDupw -= CslcztoTZGlSrm;
    }

    if (UmFoTRUfOaKdWYL >= -604551.3357495752) {
        for (int kuCHwTe = 548856886; kuCHwTe > 0; kuCHwTe--) {
            ixjMSULzn *= zMDupw;
            iBFHQzncBrkdy += zMDupw;
        }
    }

    for (int VKLTsaLFNrtJ = 451649047; VKLTsaLFNrtJ > 0; VKLTsaLFNrtJ--) {
        rxhaGa /= ADblYJmORO;
        CslcztoTZGlSrm *= ixjMSULzn;
    }

    for (int UAhoCppTaspqPV = 2097999345; UAhoCppTaspqPV > 0; UAhoCppTaspqPV--) {
        ixjMSULzn += zMDupw;
        zMDupw -= zMDupw;
        jsMyXDmTHvyfOs = ! jsMyXDmTHvyfOs;
    }

    return gNPzUkLOvDzm;
}

bool QEIyXyDLaXBxnr::TiZoxiMXXpXNbv(int eVSgksxEUpMhI, string fSTAxl)
{
    int OGeUsoVnfJeLQg = -1810697064;
    double LmLcJmFCiVui = -789012.3055937374;

    for (int qTqDwlQksDLFw = 1003831062; qTqDwlQksDLFw > 0; qTqDwlQksDLFw--) {
        eVSgksxEUpMhI *= eVSgksxEUpMhI;
        LmLcJmFCiVui *= LmLcJmFCiVui;
        fSTAxl += fSTAxl;
    }

    for (int fYwAkFxNOul = 1195697290; fYwAkFxNOul > 0; fYwAkFxNOul--) {
        OGeUsoVnfJeLQg += OGeUsoVnfJeLQg;
        OGeUsoVnfJeLQg *= OGeUsoVnfJeLQg;
        OGeUsoVnfJeLQg /= eVSgksxEUpMhI;
    }

    if (eVSgksxEUpMhI != 1011703496) {
        for (int MGJoXkqrhLqw = 1945070064; MGJoXkqrhLqw > 0; MGJoXkqrhLqw--) {
            eVSgksxEUpMhI /= eVSgksxEUpMhI;
            OGeUsoVnfJeLQg = eVSgksxEUpMhI;
        }
    }

    return true;
}

void QEIyXyDLaXBxnr::AYDTgQIAZlskcWK(string Zvueh, int emyQr, double dSCjKL, string xCubbSltCSsx)
{
    double wAMBskJaCS = -510013.77528840734;
    double woSCYYKXygR = 267713.5300099914;
    double qAFdvpKER = -879013.6313701741;
    bool nLidyXFqmHwWw = true;
    string SgIjgcUqYlAyO = string("mHFdYTVXcUXlByUGCzHyBCCFpuHliNIjTnsvVxXdnoOjymIdQfQurrrsVbVGGdsvNVjiC");
    bool rByOheTA = false;
    int hAUepWIXo = 274606463;
    string ITQCdX = string("iwhXOViUrmzkKJpItVqcQJbvKLMqljXlVWIOxAeQOrMyeejsFEMXnLkgxsoEucKDMtATrBYMRnFcpFKyEqnkZgLDKArGpVzyETwocfKczfdJKsTfVZzMhyBfwgWkWzxfMwOfHbkNOMMbsyFRRuynNyGPlNnUMdRfanPbDEXElBwwljVBLmbGKyhrEYNSHYxTWTSJLYxlksPCoPSprNspUesbVUwjWBzdFtWzK");
    string uUkILDyDLOm = string("KGrYtPdNMvORgroxVFftNCny");

    for (int cxmXjNAl = 1427153505; cxmXjNAl > 0; cxmXjNAl--) {
        Zvueh += ITQCdX;
        woSCYYKXygR /= wAMBskJaCS;
    }
}

int QEIyXyDLaXBxnr::sozvWWFuNlDclGN(double gLcTr, double BaCRdYcNuEaqTnr, double DxSgmk, double npOwochHEYeglJz)
{
    int dwJWeQlIiSLdvgB = -1490301338;
    string ucAcItVBfdm = string("AEpiUTAEpRGWgSGrzwMgeaAvuGdSJXsAnKBFXXEtHGsKAMHFbzDTXfEkCwnHXrVsJjuWVHgOkPG");

    if (gLcTr < -885898.8172539169) {
        for (int EJYMmpLfkUvWzmKy = 2048101967; EJYMmpLfkUvWzmKy > 0; EJYMmpLfkUvWzmKy--) {
            gLcTr -= BaCRdYcNuEaqTnr;
            gLcTr = gLcTr;
            BaCRdYcNuEaqTnr -= gLcTr;
            DxSgmk /= DxSgmk;
        }
    }

    return dwJWeQlIiSLdvgB;
}

int QEIyXyDLaXBxnr::rkPzgoacKXH(double KrWvZgLBfHcQFf, double NjJDWDyAIT, bool vcGlmU, bool qrVZWeDU, string umpmdb)
{
    bool ciAHe = false;
    int gSZUioVUIqbF = -1585661294;
    double ucHhEcDpTRj = 279278.15053671284;
    double lqqvATFCYjhgcang = -26615.522390373764;

    for (int KrhTUrc = 473301655; KrhTUrc > 0; KrhTUrc--) {
        vcGlmU = ! vcGlmU;
        NjJDWDyAIT += KrWvZgLBfHcQFf;
        ciAHe = ciAHe;
    }

    if (lqqvATFCYjhgcang != -26615.522390373764) {
        for (int fAQBV = 1401393782; fAQBV > 0; fAQBV--) {
            ciAHe = qrVZWeDU;
            qrVZWeDU = ! vcGlmU;
        }
    }

    for (int ylTLfprMUQOl = 221016230; ylTLfprMUQOl > 0; ylTLfprMUQOl--) {
        qrVZWeDU = ! vcGlmU;
        ciAHe = ! vcGlmU;
        lqqvATFCYjhgcang += ucHhEcDpTRj;
        umpmdb += umpmdb;
    }

    for (int mPCGZjHhVppnbZO = 358649420; mPCGZjHhVppnbZO > 0; mPCGZjHhVppnbZO--) {
        vcGlmU = vcGlmU;
    }

    for (int otvRBipTRdxHsn = 2000319691; otvRBipTRdxHsn > 0; otvRBipTRdxHsn--) {
        KrWvZgLBfHcQFf = KrWvZgLBfHcQFf;
        ucHhEcDpTRj = ucHhEcDpTRj;
        ucHhEcDpTRj += lqqvATFCYjhgcang;
    }

    return gSZUioVUIqbF;
}

string QEIyXyDLaXBxnr::iGDKRTtNrYVMGq(bool IivUG)
{
    bool pRmQmCebFkw = true;
    int DzlhGoiPrRvGFNuw = -802317296;
    string wCVHNBc = string("caXbwnqCdOhBpVNPHywZupWvwToWKEtJvaDHIRiyzfMHIwxNBVlFyFJzBxYtJzNeDwOPXOubTYejnIgzubUYbcHslTAdiSSVPBVYnUHRqPieRoAUGQXbfWJgkQZTLSNQiIwestqEZPS");
    int KoTJPWusgC = -121317295;
    bool IbSOICfCAGNw = false;
    double nXLFliP = 783077.6362015455;
    int SupzjnYmFqSwXnxy = -1710518656;
    int uWbpfgldbx = -1858158116;
    double LajbxlKf = -63848.6959888139;
    string HXMMUxVhgxDDJKnp = string("fUIKMVBqITnLUIzBPeryVmJnSnTGrPQZsgVKYcEaNPucNHHeuZsPniLtshwYqwWeLjokFFzEYjvXCTzvmGGRfOLHpiXSSAStKedDPRJ");

    if (KoTJPWusgC == -121317295) {
        for (int KtqTFHPvqAFxc = 615859589; KtqTFHPvqAFxc > 0; KtqTFHPvqAFxc--) {
            KoTJPWusgC = KoTJPWusgC;
        }
    }

    for (int dWYLlbhFaVF = 533157122; dWYLlbhFaVF > 0; dWYLlbhFaVF--) {
        wCVHNBc += HXMMUxVhgxDDJKnp;
        HXMMUxVhgxDDJKnp += wCVHNBc;
        wCVHNBc += HXMMUxVhgxDDJKnp;
    }

    if (IivUG == false) {
        for (int JxKujuMKynHF = 885018872; JxKujuMKynHF > 0; JxKujuMKynHF--) {
            DzlhGoiPrRvGFNuw -= KoTJPWusgC;
        }
    }

    if (SupzjnYmFqSwXnxy <= -1858158116) {
        for (int bCRKCubk = 1855101621; bCRKCubk > 0; bCRKCubk--) {
            IivUG = IbSOICfCAGNw;
            uWbpfgldbx -= uWbpfgldbx;
            SupzjnYmFqSwXnxy += DzlhGoiPrRvGFNuw;
        }
    }

    if (wCVHNBc > string("fUIKMVBqITnLUIzBPeryVmJnSnTGrPQZsgVKYcEaNPucNHHeuZsPniLtshwYqwWeLjokFFzEYjvXCTzvmGGRfOLHpiXSSAStKedDPRJ")) {
        for (int oWqpnrDeSJz = 1386821445; oWqpnrDeSJz > 0; oWqpnrDeSJz--) {
            continue;
        }
    }

    return HXMMUxVhgxDDJKnp;
}

void QEIyXyDLaXBxnr::pgjxqXTvZCK(int kUujQUw, int yAZNpuApwXFtYZy)
{
    int aplpovVQ = -590382861;
    int xwwIhNdMYae = 1969539287;
    bool jKRbAAYO = false;
    double vBgXgsi = 617180.8826944231;
    bool zVqlXyQVyyObGuJ = false;

    for (int ZdIzmEC = 113836841; ZdIzmEC > 0; ZdIzmEC--) {
        kUujQUw -= kUujQUw;
        jKRbAAYO = zVqlXyQVyyObGuJ;
    }

    for (int mZSJMErlscOlgo = 223720749; mZSJMErlscOlgo > 0; mZSJMErlscOlgo--) {
        xwwIhNdMYae *= kUujQUw;
        aplpovVQ *= kUujQUw;
        kUujQUw /= aplpovVQ;
    }

    if (kUujQUw != 424437738) {
        for (int edHfCWKnEg = 652363956; edHfCWKnEg > 0; edHfCWKnEg--) {
            aplpovVQ *= xwwIhNdMYae;
            xwwIhNdMYae *= yAZNpuApwXFtYZy;
            yAZNpuApwXFtYZy -= xwwIhNdMYae;
            yAZNpuApwXFtYZy *= xwwIhNdMYae;
        }
    }

    for (int UJqVD = 2048159280; UJqVD > 0; UJqVD--) {
        jKRbAAYO = jKRbAAYO;
    }

    for (int GEpROCFs = 1849942397; GEpROCFs > 0; GEpROCFs--) {
        kUujQUw /= xwwIhNdMYae;
        kUujQUw = xwwIhNdMYae;
    }
}

bool QEIyXyDLaXBxnr::dmBHULhdPemsYjey(double IpGMNwy, string fzdlzmLIzaiAx, bool qJfciYhKo, string ulIDgagWyz, bool ZjoLcSkeMjpyuw)
{
    bool XcYDb = false;
    string xQkjeNtbVi = string("MTKtFexzDFTYKRREZEgOqdwZdosMgbPYFKvZIgYHPSemPmQGtiANSxzWBoaxeGJXIVJtjypjKQlcIPeCjCWWbCVXGTPVTMfCgsjUqPkyLRhXlRkGMZTGtjZFSmiodoIBICuvJkgZmDjOuzPxzFQqbksVbYaDOreKBRqGq");
    double GlZzua = -743323.1524456391;
    int kuyrNbCjVvb = 1364348489;
    double ibTctIHO = 170222.8182137877;

    for (int ZFNfBILPxbIWchJL = 815110869; ZFNfBILPxbIWchJL > 0; ZFNfBILPxbIWchJL--) {
        ZjoLcSkeMjpyuw = ! XcYDb;
        XcYDb = ! qJfciYhKo;
    }

    if (ulIDgagWyz == string("YwnCHzyJZaptAQmbobipzomeUMgoVJhPJlQlVlMclZVWpC")) {
        for (int UbkUIePRTTJDhijr = 2114795049; UbkUIePRTTJDhijr > 0; UbkUIePRTTJDhijr--) {
            xQkjeNtbVi += xQkjeNtbVi;
            ZjoLcSkeMjpyuw = ZjoLcSkeMjpyuw;
        }
    }

    for (int deDACfZtgVrneUP = 943778406; deDACfZtgVrneUP > 0; deDACfZtgVrneUP--) {
        continue;
    }

    return XcYDb;
}

QEIyXyDLaXBxnr::QEIyXyDLaXBxnr()
{
    this->pBBZhVKdEziepzO(585474516, true, -418330.2468983042, string("VRALSsRyvbzbiTYoXqCJOHPsuitAmKMXIuztKqcxYDzhIqxtVTMSSBAuEvB"));
    this->HJnCHLSDFSX(621914.5273429899, -625706966, 800092135);
    this->zDxMpgnGMNzZJD(false, string("bwiqNrWsVAtXnKPMjdWxpdqDUXGKxUqQnLLbwzFukYxNpRaNZpMpDQHrhajw"));
    this->JGtmiAJbjzTkgNB(-1263988235, string("fWprtwzIYvxUJdefOQbmzSzNOyqyriARpEZpnGkQqxjAsaAppEBdyQxlobXninMkZxAyQbhURHEfOGcObNxaTwTtHZFRcYKAsBsoIGLHevipMjrKUESohKQzYZtnWmPkkpyhCBKHxFkVXRvIUeDFbqKPFvcmJTTVdeGxdCAMWtMitNzXKJergtvcuWBNTRJGvvmZmeYudncATJlvOLkFlxnidVbaLMKkGPxGLnBAyvTyXKXjqqdoLijh"), string("OBzgHDBRqWpGfhApxDPpEkwHMUOMVkhAvoiywIhhzyYrHvUEbHBTSSbhQnGuuXknWZJMgArsbSCiQKcOjuYnDPxEerTXJFGWEJajzVjUsyvwEODIKbRApiwXwAtaySnRmnwadeIzQChuNkAZTnHRWfBympoJPqdHE"), true, true);
    this->lXJJlTQhaocWFe(string("RaRiBSTtMmeYObOSBaRYwfSUEsfZPfOwQDAyfjxBlsIeCtDTzicWBZhDeGWfgPqEDXwXNoiMegbXIlQzDcgPZJDmpemyZyuKbaMmostSdPUWjMlnrRYsLfGwOtanGXtesqokMkxLyPHdLfaUnUebilSBKnRLvrdB"), string("WmutqYRjRSCOMAPNNDQwFtn"), -578358.3785525482);
    this->hAioGruZlgTeBUfs(-493145.4885872964, -399025.1945463634);
    this->BXqiU();
    this->ywgXQr();
    this->zsXVifIt();
    this->oJgPSGmEGtBxvAy(-184792.8268933495, -604551.3357495752, 642298051, -1714535012);
    this->TiZoxiMXXpXNbv(1011703496, string("rOCmUzKVFsDbCbJNfzYKnJnIwXJNoGSghOQtLVkOqBAggeJmMmQMfEHMiISPKumXHuDmacDQMXybNgJQpphijynCBFJWoPgMEuSVfKkRSCqMFcAMBHVwigbpRQdFgOVxjkdLKWXPatxzpNcGdKxQUEwKDEoIjpYqgmNSUbshaYzjVkSRLOTTlDWsWsPp"));
    this->AYDTgQIAZlskcWK(string("VehxJCkXpSOxjtTJdbucmONBTMbOjDpqZecclypyiUlAPUlxVXQligjSAwNNVxFnjBSHdjLENpagXwdCbjmOCzGnBeTCruSSoxIXJjiujtUgfKIPEeumcqKyEYGJomZAzqQtXuNXmhnVJjuSiUgDGeFGAotLrkIZORkbux"), 2059298667, -335771.5939038157, string("mXdioVZSXsayNEFjVqOfJmtvheziHzGafxLIwNeGMkpkOjcLCWWHSSsusrPQgcQnGQALKrsLNNBvuLpEJxgcAXJjRVcYYZrCKWdRJZMmIUCrwrcKTZuoFMeBOfieyGbdCEypOVZoMpUHDixfnvGTbnKILMTauRwcMjeyyltyrhlAAfibUkxyMwY"));
    this->sozvWWFuNlDclGN(-885898.8172539169, -641015.2162834815, 363538.8617105464, 277279.9742456413);
    this->rkPzgoacKXH(505979.01033338066, 704901.055984975, false, true, string("KSyzEFDgXPcsLfpnAaQaWPuvAueZlrTVPLVDPJZgLGGBJuILqrNwUTEpvHfGpSjMKySmlyBtlxhoWfGsadGYXEbCDeXIVcyxxrbrwkhlGIZAVoAWdcmhRcwZTsMlLsIhtozbKRbgKZHce"));
    this->iGDKRTtNrYVMGq(false);
    this->pgjxqXTvZCK(520549785, 424437738);
    this->dmBHULhdPemsYjey(150249.9447304531, string("wmXugMSHlLJgJhJwkTYoALKhUVlUnMMhNZhPtscALfyavIQbysBZJFfyGbGZDDepwDGPoRjifzDwZWgKtRLjwAzGojJwnvZjQEMCrPBTnAQkXjdINhkPIXFsCpGlqPjmpKoScIPJzGnfRUsKoZayIcrpijpofXfIvqloGcwpuOdZIpBAmxhGEFNtoFbsTpWGtAQplDrUyEAwfdwbxOrukHPfWzmyXFFYCnAfNqqIzoiSjsdhYQWYt"), true, string("YwnCHzyJZaptAQmbobipzomeUMgoVJhPJlQlVlMclZVWpC"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kbPSWUoUZfqkGhkv
{
public:
    int fCeJgQKwTzmCwiFi;
    string zkgVEglkdejCnRh;

    kbPSWUoUZfqkGhkv();
    bool xsLFpiPOPn(string ZYDzVUpcDio, string YoipfKxc);
    string aCdxM(int gTmrkywNnLgeE, string qzdlyW);
protected:
    int JPbsBwlMNDvBnklK;

    double qFgLvfrQ(bool MIGHtgRpyl, bool RDRSdUbuXmUPqwe, bool tOSfXtRgYe, int tcFGVVeNtMo, bool pLNARvKjGZfWgsdh);
    string teultEjS();
    bool YDIpzsPkvjSzgRH(bool KLCJsqCblWIEyiOh);
    bool YtrNLAoThDpkA();
private:
    double AcdOpiZWcnDxsM;
    string CWuPQduRfoMZmomJ;
    double BYQuAf;
    double vOJxoeecoGQK;

    int BmigHtA(string wskVrdYsXzWvSAw, double nCDbZsBAR, bool cKsCDz, int urpNzZJtzMFtup);
    bool pKIIDjPKUBxgH(bool ZMzDxSU, bool kIMZlT, double XjOoeGMyk, double YAFsbSLurJIx, bool ddegezhMLYHyHRK);
    void HqeXUVjeC(int wIldyDAQH, string vTvOPCKBntdLSH, double iPYQaObICKXsAV);
    double hsMUbUb(bool HcYqvKVqGHsSV, bool LFbkE, double vcNkiPV, double YTeatxbdTZ, int KLVHrMUzxoz);
    bool NJGhtVvjdhrov(bool UKWiZcUUYmTQ);
};

bool kbPSWUoUZfqkGhkv::xsLFpiPOPn(string ZYDzVUpcDio, string YoipfKxc)
{
    int kNEeVEKJwCjPVb = 104888655;
    int zyJYNwUuwN = 1447816241;
    string qjigDka = string("KTOonjdyVUxupQvTEGePHBoucUybNDPSUiEpfgqUycjmwJMGKLvgFSGiHwwwXJ");
    bool ujZyi = true;

    return ujZyi;
}

string kbPSWUoUZfqkGhkv::aCdxM(int gTmrkywNnLgeE, string qzdlyW)
{
    string mqsCREIvcsxI = string("ibjjjbRPoKkstgcPsqBrMaJVMlknrTdiqbRUIUoGxRcWlqDMKgNkEtmyVUCZpVSKXGhTIqCBaWjzgxEGKMQhiBhAjpXSMgtsdVSHcekovWOstFDudSoOlMTKtoQWUfEdeJuVbjaCGddutzlbuGutdXIexdDVnNCFZoBfeZmDZFTlKDdffEUQLSkAVDAoshuRPXqsqAlmrbMEUZehtmTncEUIKyQEcYuTJuTIJFDQyknvriPLALpqjbeetZoqQjj");
    bool VvGsyHPrKIdceYX = true;

    for (int NFCuuPYtrkhPBZ = 1441553615; NFCuuPYtrkhPBZ > 0; NFCuuPYtrkhPBZ--) {
        mqsCREIvcsxI += qzdlyW;
        qzdlyW += mqsCREIvcsxI;
    }

    for (int ToXVKE = 1311140411; ToXVKE > 0; ToXVKE--) {
        mqsCREIvcsxI += mqsCREIvcsxI;
    }

    return mqsCREIvcsxI;
}

double kbPSWUoUZfqkGhkv::qFgLvfrQ(bool MIGHtgRpyl, bool RDRSdUbuXmUPqwe, bool tOSfXtRgYe, int tcFGVVeNtMo, bool pLNARvKjGZfWgsdh)
{
    int qZbSTEsrpxr = -520007485;
    bool BWeJXYLKILhOa = true;

    if (MIGHtgRpyl != false) {
        for (int BOkdjTjvdeXLSV = 300075380; BOkdjTjvdeXLSV > 0; BOkdjTjvdeXLSV--) {
            tcFGVVeNtMo = qZbSTEsrpxr;
            BWeJXYLKILhOa = BWeJXYLKILhOa;
            tcFGVVeNtMo /= qZbSTEsrpxr;
            BWeJXYLKILhOa = ! tOSfXtRgYe;
            MIGHtgRpyl = ! tOSfXtRgYe;
            MIGHtgRpyl = tOSfXtRgYe;
        }
    }

    if (MIGHtgRpyl != false) {
        for (int XFCpQmBfJwQgPU = 1221387347; XFCpQmBfJwQgPU > 0; XFCpQmBfJwQgPU--) {
            MIGHtgRpyl = ! RDRSdUbuXmUPqwe;
            tOSfXtRgYe = pLNARvKjGZfWgsdh;
            MIGHtgRpyl = BWeJXYLKILhOa;
            tOSfXtRgYe = tOSfXtRgYe;
            RDRSdUbuXmUPqwe = pLNARvKjGZfWgsdh;
            tcFGVVeNtMo *= qZbSTEsrpxr;
            MIGHtgRpyl = BWeJXYLKILhOa;
        }
    }

    if (pLNARvKjGZfWgsdh == false) {
        for (int oEtAgArOfQvOKht = 1611943189; oEtAgArOfQvOKht > 0; oEtAgArOfQvOKht--) {
            BWeJXYLKILhOa = BWeJXYLKILhOa;
            BWeJXYLKILhOa = ! BWeJXYLKILhOa;
        }
    }

    for (int SIlWVbuJ = 1718674632; SIlWVbuJ > 0; SIlWVbuJ--) {
        MIGHtgRpyl = pLNARvKjGZfWgsdh;
        BWeJXYLKILhOa = ! pLNARvKjGZfWgsdh;
        RDRSdUbuXmUPqwe = tOSfXtRgYe;
    }

    if (BWeJXYLKILhOa != true) {
        for (int LOMwKHYVcPM = 1090607548; LOMwKHYVcPM > 0; LOMwKHYVcPM--) {
            pLNARvKjGZfWgsdh = tOSfXtRgYe;
            pLNARvKjGZfWgsdh = ! MIGHtgRpyl;
            tOSfXtRgYe = ! pLNARvKjGZfWgsdh;
            BWeJXYLKILhOa = MIGHtgRpyl;
        }
    }

    if (tOSfXtRgYe != true) {
        for (int TwJfhpRASPrUAsj = 1924037637; TwJfhpRASPrUAsj > 0; TwJfhpRASPrUAsj--) {
            tOSfXtRgYe = MIGHtgRpyl;
        }
    }

    return 713425.5947867184;
}

string kbPSWUoUZfqkGhkv::teultEjS()
{
    double oEtEDeikKGdufOEE = -63749.61685992005;
    double YHMiPjgfsCkiScq = 628905.4310338574;
    string twCifc = string("synHxCFNZEKsVxAAcQKeLckNXsbssPnIKcgZosPlkKyDcplTIUAKXiKhnSaFLXrLNscRRRbShtJLVfvkA");
    bool aomHYtNrEBuyK = true;
    int PHykm = 521798274;
    int WhhMAcLT = 1930173708;
    int bCCTV = -783376419;

    if (WhhMAcLT != -783376419) {
        for (int GLbaEQ = 1377971491; GLbaEQ > 0; GLbaEQ--) {
            PHykm *= WhhMAcLT;
            bCCTV /= WhhMAcLT;
            WhhMAcLT += PHykm;
        }
    }

    for (int dJOQmFXCgBbpovPs = 1978791060; dJOQmFXCgBbpovPs > 0; dJOQmFXCgBbpovPs--) {
        bCCTV += PHykm;
    }

    for (int DlpKTf = 803407568; DlpKTf > 0; DlpKTf--) {
        WhhMAcLT = bCCTV;
    }

    for (int HKUkgtNLQEdGOFJS = 688635999; HKUkgtNLQEdGOFJS > 0; HKUkgtNLQEdGOFJS--) {
        YHMiPjgfsCkiScq -= YHMiPjgfsCkiScq;
    }

    for (int HoOIivXycwd = 240365133; HoOIivXycwd > 0; HoOIivXycwd--) {
        WhhMAcLT -= PHykm;
    }

    return twCifc;
}

bool kbPSWUoUZfqkGhkv::YDIpzsPkvjSzgRH(bool KLCJsqCblWIEyiOh)
{
    bool mMQUhvct = false;
    bool pBzsTii = false;
    string KUxFQpLSgoLKEb = string("jXTfGvmdNfuVJGdpXcuYdKHJpXwuXLHADvUkRowvuEgralgZXYdQEQPwjmgKVgtAhOKCTXsUhnqmiGvkWGiCHQawnPLMhDUCNnDQQCBYybTyjwDtMjmeQvCIqGJyWjYNBrLIhjPJZhOvWykMfMAM");
    int hsXDcDIbEUd = 135257794;
    int dFksJ = 106538174;
    double mgzFRGdhdA = -316663.25317287236;
    int wqzwMyVPxXnVhm = 867580734;

    for (int JQfiZl = 1526346907; JQfiZl > 0; JQfiZl--) {
        pBzsTii = KLCJsqCblWIEyiOh;
    }

    for (int xAdNTv = 1926350202; xAdNTv > 0; xAdNTv--) {
        continue;
    }

    for (int jtDsnpkLcnz = 354496323; jtDsnpkLcnz > 0; jtDsnpkLcnz--) {
        continue;
    }

    if (mMQUhvct != false) {
        for (int AjGzUWKfTdtWRMbj = 1540079644; AjGzUWKfTdtWRMbj > 0; AjGzUWKfTdtWRMbj--) {
            mMQUhvct = mMQUhvct;
            pBzsTii = ! pBzsTii;
            KLCJsqCblWIEyiOh = KLCJsqCblWIEyiOh;
            mMQUhvct = ! mMQUhvct;
            wqzwMyVPxXnVhm /= hsXDcDIbEUd;
            dFksJ = hsXDcDIbEUd;
        }
    }

    if (KLCJsqCblWIEyiOh != false) {
        for (int OZcfPBYJNra = 1969648779; OZcfPBYJNra > 0; OZcfPBYJNra--) {
            KUxFQpLSgoLKEb += KUxFQpLSgoLKEb;
            mgzFRGdhdA *= mgzFRGdhdA;
        }
    }

    return pBzsTii;
}

bool kbPSWUoUZfqkGhkv::YtrNLAoThDpkA()
{
    bool LAnWhbnQTfn = false;
    string NUrIeUifaAv = string("QVuNOzUzEmMGumonywWMpOXyPitQSHWJgjESAMqBWlLqfpOzMDFwqBklUJgeOYHvrOmJqSRUuZcjLfjwnUoAKUztPPSkIFMRohB");
    string xysVrDuKsSi = string("HnuexBJTVXLUuhnkLLQDGkpsjVtzKSCeyAmrxxSLigZwegUmpOYPFhbDIHBeevsgjFidNmSexAofkhrZbSfMRkVltfYhpACGycpzokqcPKCMMRJVSQHAyjBrepAobKAhPFxnttGgPHGtaSfIrzrQStRlnkRhrjScqVDQOMUZcyuhnAwJMuJHyuoAIxPL");
    double zHFgBWMFDZhCmtmK = -939483.8952184012;
    bool TkOSJjbDZVEtlo = true;
    bool oPztRrbq = false;
    bool ksYRc = true;
    int kBaUbdKGMPWI = 2045030635;

    return ksYRc;
}

int kbPSWUoUZfqkGhkv::BmigHtA(string wskVrdYsXzWvSAw, double nCDbZsBAR, bool cKsCDz, int urpNzZJtzMFtup)
{
    bool tRDfhyJDvQBDzwJ = true;
    bool vWylbyOFocJYxvI = false;
    double HDCnODNhIIfAj = -101231.14961757831;
    string BEhGXFiecQ = string("PJGrpFA");
    int rLAEZymhFHefjVo = -545147843;
    int QzmWniL = -72616853;

    if (urpNzZJtzMFtup > -1587856658) {
        for (int SDsXj = 2047505007; SDsXj > 0; SDsXj--) {
            urpNzZJtzMFtup = urpNzZJtzMFtup;
        }
    }

    for (int AuNcv = 780165996; AuNcv > 0; AuNcv--) {
        QzmWniL += urpNzZJtzMFtup;
        BEhGXFiecQ += wskVrdYsXzWvSAw;
        vWylbyOFocJYxvI = ! cKsCDz;
    }

    for (int IbBoQ = 902543054; IbBoQ > 0; IbBoQ--) {
        continue;
    }

    for (int rOpEkABGB = 546845103; rOpEkABGB > 0; rOpEkABGB--) {
        continue;
    }

    if (BEhGXFiecQ >= string("PJGrpFA")) {
        for (int JYxObFdTP = 489309214; JYxObFdTP > 0; JYxObFdTP--) {
            continue;
        }
    }

    return QzmWniL;
}

bool kbPSWUoUZfqkGhkv::pKIIDjPKUBxgH(bool ZMzDxSU, bool kIMZlT, double XjOoeGMyk, double YAFsbSLurJIx, bool ddegezhMLYHyHRK)
{
    string OfybdtNc = string("fiirVnBeosLmQWXDNruQwiCfjPSHrbszMiaJKnOuHxYxUfNOGlIbTXnQwSMiGoWddOgydaUWhvxJGuIhrTOnF");
    bool HUDjopAULsNi = false;
    double jJNqHigoF = -705398.6774899485;
    bool MBNmCkqOJMjSL = false;
    double KWdeACcWCls = -752270.6240004232;
    double ZUwYMWqXrjXv = -28847.900853944164;

    if (ddegezhMLYHyHRK == false) {
        for (int gZEXRV = 703975819; gZEXRV > 0; gZEXRV--) {
            kIMZlT = ! kIMZlT;
            kIMZlT = ! HUDjopAULsNi;
        }
    }

    return MBNmCkqOJMjSL;
}

void kbPSWUoUZfqkGhkv::HqeXUVjeC(int wIldyDAQH, string vTvOPCKBntdLSH, double iPYQaObICKXsAV)
{
    string heJXuUPVomK = string("UQgtuBqMwqaIKjvOSryLTY");
    double nRqmoQeYjPFCxta = 105432.18349697352;
    int pVFAwaJNMpU = -769770561;
    string byMPsTOHbf = string("VPFfDxucGZXgjVgnoOlLarPuiMmMAMpeVuzcEYTZSpuDoKDrsyahvJeBBBkTRsqEiUrBLlsbtfXkcMtgTDBjGKvWyIkcsKuhbgavCBHBDRzPZyWkoklJuYM");
    double flKir = -83596.142692501;

    for (int HCzVuyApBBDr = 1194173401; HCzVuyApBBDr > 0; HCzVuyApBBDr--) {
        iPYQaObICKXsAV *= nRqmoQeYjPFCxta;
        iPYQaObICKXsAV /= iPYQaObICKXsAV;
        vTvOPCKBntdLSH += byMPsTOHbf;
    }

    for (int vrMMO = 264613714; vrMMO > 0; vrMMO--) {
        continue;
    }
}

double kbPSWUoUZfqkGhkv::hsMUbUb(bool HcYqvKVqGHsSV, bool LFbkE, double vcNkiPV, double YTeatxbdTZ, int KLVHrMUzxoz)
{
    double KHymcLGyGoWsaqq = 678221.1379256799;
    bool JqrpZ = true;
    string AeDUFBG = string("XJPhqxWZxRaMXUVMCPpfievTbNAQjDjoUSmLZqDNGcXPeUrfoQDoMnwlsfYUSBiMfAMUgzpnEJNgHONoAGAuICwJCiAPoXzJcqE");
    double napFMylkWhZtm = -191778.25447245824;
    string nhUkuZIFlRZUiWI = string("YtFUoGBlZdniMCzjIdtNXoBDSvLpXTiDEEfiDkPXROVoQuvkkxDCnBkpheyDMUaQwOSdXEVXoNIraqOoYjNyYnRIelCeqADjWelNSGpejvRyUHLNphlcfVeXiWNEcgbTpRrsmuXeZCEHUDibGYACuaErwIXiYmfPxmeIxwvcaaPsboWaPqrBcSymCzZslMvzTVkkYzFut");
    double mFbmCBzwXStNfD = -701271.8294563554;
    double BdNZkV = 951179.588278607;
    int IUodPFzyyil = -909598019;
    bool pdUPoznGH = true;
    string EVCFiIsOSjYliShR = string("iYitKqlEHhBgaWZCOqsQyQYJeckmZVuuOxWWSWIXwdFERVIylEEzNZoqvrHyqGwWXXMXHoDOVvwtOnZqvOLGizrKbpiouCCPmpzvitfbRHuUWZeHdwSnXRQrmWTAInPveGagaOkIsiXywMvumDRLPzvuwczglRocYemDIqpWwUiObcVbOVpzCboRUzfwpFHoRDWtdAd");

    if (YTeatxbdTZ > 231805.7965285913) {
        for (int aufuppjjkWCKLfmf = 1945313184; aufuppjjkWCKLfmf > 0; aufuppjjkWCKLfmf--) {
            YTeatxbdTZ -= KHymcLGyGoWsaqq;
            nhUkuZIFlRZUiWI = AeDUFBG;
        }
    }

    for (int xeWaJvoIC = 1914430723; xeWaJvoIC > 0; xeWaJvoIC--) {
        nhUkuZIFlRZUiWI += nhUkuZIFlRZUiWI;
        BdNZkV += KHymcLGyGoWsaqq;
    }

    for (int XjmYQJaXyPDOvrGC = 1429826462; XjmYQJaXyPDOvrGC > 0; XjmYQJaXyPDOvrGC--) {
        continue;
    }

    for (int BUoNUAORl = 2126298787; BUoNUAORl > 0; BUoNUAORl--) {
        continue;
    }

    for (int OYpQiDPMdn = 153060877; OYpQiDPMdn > 0; OYpQiDPMdn--) {
        nhUkuZIFlRZUiWI += EVCFiIsOSjYliShR;
    }

    return BdNZkV;
}

bool kbPSWUoUZfqkGhkv::NJGhtVvjdhrov(bool UKWiZcUUYmTQ)
{
    string dbaadQh = string("nablcEVbHuAXNcSCoAhLnhjfPUlUoYmNVDSsvYncuCkJOTakpFQwOoIUMwATPFPAMafeYHgijHPtkBAPjdtJRQDLUDXoSQErVsgCcacYmCXVUdVlUOwNBxFtZvJKqChkie");

    return UKWiZcUUYmTQ;
}

kbPSWUoUZfqkGhkv::kbPSWUoUZfqkGhkv()
{
    this->xsLFpiPOPn(string("htRsZMKFnroVTbNmFHOCJZqZBIzdZvVNGUZrLzBFFKqjBrusgaUybrxXoXiSbzUZHGnezSyGPNIZZUYAJCdizemLgTKPQjMweMdXddcLwsYuztPCFAxOynrPDsFCAJbybZIpdAcNMPtYSeQPBSB"), string("XKFhrEWvRrFEzstbubrKLAHJoQxTdVyntMyZjArCTabbUVvxchQzsPcTfBXj"));
    this->aCdxM(-834102522, string("IHgwdrJHNuQsnwYlJodelsxMZMbbdjQzPWCUBPGqZOYBXkNSWYZBZEQcNBkmavXCkaDgTgswhblXATCsksSvgdqPDujGWuLqGoFGFEHAjRIaIMBOfhmvXQzjlYSbAkSNhesfsycNOELFROoGfdIPSFeQRayDBhVhpvMTTrvvBOV"));
    this->qFgLvfrQ(false, false, false, -1629367642, true);
    this->teultEjS();
    this->YDIpzsPkvjSzgRH(false);
    this->YtrNLAoThDpkA();
    this->BmigHtA(string("CKOkSlQfVQhTgnFBvVvBPlxCdCuDBgVvBjBLeeUiSnwVBJRJIIcwzJiqulfNJsCoyRQlwYQjiRDMFUKpwzITSsAhRTJCCbaFTXbQAZmUdiqXIJSZnmQTyDoFbIrwQkRyuSzGCRaDBlILkeMnenUchZwpLFhdytfSMQLcACFCOgKbTnvLgVZsdwYPsitqmSQcUzoGBJzWFrxNd"), 989579.8003480782, false, -1587856658);
    this->pKIIDjPKUBxgH(false, false, -402207.7843937088, 713060.2402702152, true);
    this->HqeXUVjeC(658283053, string("gIiMSnNwhyBCuEHQSbHwmMyLOgyCNOEdsBVpTLYWBysyKuzcMwNdfuYoBDMnyxFwtlzKyYjWLFjmBfULkmSv"), -554760.0297009558);
    this->hsMUbUb(true, false, 231805.7965285913, -602420.6047901605, 387246283);
    this->NJGhtVvjdhrov(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yVYWvVpukt
{
public:
    string bHAQSrtPL;
    double MyihQalNjQ;
    double BXQrNG;
    string LPJBkfAeFIdJOpRR;
    int GfWkEC;

    yVYWvVpukt();
    void AXJRukNhFHzkFfG(double zGrYY, bool DcpgBNemNllf, double fvaupmMywYiRxbE);
    bool iXxAsr(string YaUCb);
    void lpCKLIdQsHzjhW(bool CXOEDxizPbeRUBs, string dLWhdhRhRJH, string LruiGvQ);
protected:
    bool XDMgEaidgKjdPdK;
    bool NsOjBqWMFktdY;
    bool iZKPbbppQW;
    double oDIjwcbMRxfygi;
    string HwrtMu;

    int vvEHZELHOnszqIG(int JRKUfSfkvX);
    bool PrifGVjUzYAEipz(double ZCtxpMpOQYyy, int ZUvxp);
    bool LYVrmPzSfirvP(string IPLLxDJbWXsOIbRT, string NJTYOjCGSlWlU, bool radxF);
private:
    string zLDbOWCkjnxUo;
    bool mXmbOgenkDun;
    string EPRLgjNSKje;

    string odmyFGGFAwzn();
    double OlUqs();
    int xZSXYibvDSghn(double xSkouQy, int eqYZFvGSKXvw, bool GBcRDPgBVCiEMT);
    void gChOKuBHvA();
    void zLIlvCDlm(int kaNjnoKhVuAbQSQn, bool HuMdruZAtISvipwG);
    string IuFjRnk(int mFlDnTatQticRs, double lWqFfrW, string uXozeNnyqP, double LchvaMIjUay);
    string dbluxYflGrARTdTS(int DvYXDssttGhGgHoB, int mLqbQopSIfXmf, int QdAdVEXMkhAvsP, int UsqaYkGpnMm, bool iJkyJtucGzX);
    void ODvHHc(double sBPCEIdNASAP);
};

void yVYWvVpukt::AXJRukNhFHzkFfG(double zGrYY, bool DcpgBNemNllf, double fvaupmMywYiRxbE)
{
    bool ypfzbOAuVFXuh = false;
    double IbzFgwJdcsN = 776064.1407187338;
    string PFthDDbBXBpqJ = string("PSCDtDLTrGbgIBvNjUtOegyyXrgMTjWKYddvcqBtiVTFdPkauWUKohqyBKjsrRLeImzlbXbEvfHBvOqmVvVYsmSmBZitblqNQOrzsegIedToOPFcVktFpnrOMSvMButmEznstqMUeZEUwFYwnYyAtrfZSxVJwWjDECWLYrRRTpnzdswOvaVqIAfSemLQDHQacKCcgMHVufRIMoBKQiNzXvUgQLZfeLd");
    int wGgIav = 472350821;
    double clJFnvVAP = -876336.9955805002;

    for (int PiZKmGMsMd = 221698837; PiZKmGMsMd > 0; PiZKmGMsMd--) {
        fvaupmMywYiRxbE *= clJFnvVAP;
        IbzFgwJdcsN = fvaupmMywYiRxbE;
        DcpgBNemNllf = ypfzbOAuVFXuh;
    }

    for (int DvfxfkwfK = 1165103330; DvfxfkwfK > 0; DvfxfkwfK--) {
        IbzFgwJdcsN *= zGrYY;
    }

    if (zGrYY != 710932.2760551014) {
        for (int ywANhNCjzODLWAv = 1334222061; ywANhNCjzODLWAv > 0; ywANhNCjzODLWAv--) {
            IbzFgwJdcsN /= zGrYY;
            clJFnvVAP -= IbzFgwJdcsN;
            zGrYY /= zGrYY;
            clJFnvVAP = clJFnvVAP;
        }
    }
}

bool yVYWvVpukt::iXxAsr(string YaUCb)
{
    int hcMhJHPzPlQKJ = -1797102126;
    double flzHFmwvilEJW = 558099.5694243574;
    int mRfhtspTHhStoeV = -1163030572;
    bool ITnqz = true;
    int XmfArfityXgQwuZs = -923571146;
    double upZwsMseyt = 819621.9072488821;
    double SCxgAJXnvZIIKScJ = 716619.3112601421;
    bool gaIdkjljjPTBh = true;

    if (upZwsMseyt == 819621.9072488821) {
        for (int OvfpFJCKPIVhsgZL = 104770238; OvfpFJCKPIVhsgZL > 0; OvfpFJCKPIVhsgZL--) {
            gaIdkjljjPTBh = ! ITnqz;
            XmfArfityXgQwuZs = XmfArfityXgQwuZs;
        }
    }

    if (ITnqz == true) {
        for (int qITbVggoliDltTvx = 1154359750; qITbVggoliDltTvx > 0; qITbVggoliDltTvx--) {
            SCxgAJXnvZIIKScJ /= flzHFmwvilEJW;
        }
    }

    if (ITnqz == true) {
        for (int tXWbfmryYNeP = 575615765; tXWbfmryYNeP > 0; tXWbfmryYNeP--) {
            continue;
        }
    }

    for (int ehhmvXWYpeeqFlWE = 600069204; ehhmvXWYpeeqFlWE > 0; ehhmvXWYpeeqFlWE--) {
        ITnqz = ! gaIdkjljjPTBh;
        upZwsMseyt /= flzHFmwvilEJW;
        SCxgAJXnvZIIKScJ /= flzHFmwvilEJW;
        hcMhJHPzPlQKJ *= mRfhtspTHhStoeV;
        mRfhtspTHhStoeV -= XmfArfityXgQwuZs;
    }

    for (int VbSbm = 1599160900; VbSbm > 0; VbSbm--) {
        mRfhtspTHhStoeV *= hcMhJHPzPlQKJ;
        ITnqz = ! ITnqz;
    }

    for (int tQsvVIFvhxbrC = 225207916; tQsvVIFvhxbrC > 0; tQsvVIFvhxbrC--) {
        flzHFmwvilEJW /= SCxgAJXnvZIIKScJ;
    }

    if (gaIdkjljjPTBh == true) {
        for (int IYNsZmkzuMp = 915713266; IYNsZmkzuMp > 0; IYNsZmkzuMp--) {
            hcMhJHPzPlQKJ += XmfArfityXgQwuZs;
            SCxgAJXnvZIIKScJ += flzHFmwvilEJW;
        }
    }

    for (int FAAdibGf = 1132895323; FAAdibGf > 0; FAAdibGf--) {
        hcMhJHPzPlQKJ -= mRfhtspTHhStoeV;
    }

    return gaIdkjljjPTBh;
}

void yVYWvVpukt::lpCKLIdQsHzjhW(bool CXOEDxizPbeRUBs, string dLWhdhRhRJH, string LruiGvQ)
{
    int UEQPImwmyYIEij = 1281866052;
    int fBXyYEUwkDx = -164244684;
    bool txrJHTeGo = true;
    bool fgUMMtcvqtaI = true;
    string xlqgauJruDjrcy = string("vPnMJacLVwCglfdNuYzhMwiudgFkNNjyCUxtrlmUNNLfWUawslyUdyibKRJyUOpsLQaywezAXEhQKPdwfHcefe");

    if (xlqgauJruDjrcy >= string("qHveACXJZkRQektKBVWMKuojEMqaKsfWkXlmdeOIKaRrmNTNNtEkbSXpJpHdqlzEvKZvsZfnudzpVKKupXlUIguQWWSPUDjnznbTUTa")) {
        for (int yxCmJHQhlc = 548486071; yxCmJHQhlc > 0; yxCmJHQhlc--) {
            dLWhdhRhRJH = xlqgauJruDjrcy;
        }
    }

    for (int fAFtLE = 1467465600; fAFtLE > 0; fAFtLE--) {
        xlqgauJruDjrcy = LruiGvQ;
        dLWhdhRhRJH += xlqgauJruDjrcy;
        xlqgauJruDjrcy = xlqgauJruDjrcy;
    }

    for (int PCBEfwKjA = 777090163; PCBEfwKjA > 0; PCBEfwKjA--) {
        fgUMMtcvqtaI = ! fgUMMtcvqtaI;
    }
}

int yVYWvVpukt::vvEHZELHOnszqIG(int JRKUfSfkvX)
{
    int kHpmuDK = -451318956;
    string oRwqxfrPxUmRzlD = string("UKrDmUmmvgTBiVhMmzhyNnRmPKxwQVbYcFuGGJLbkhMGj");
    bool RVPzWnZ = false;
    bool mSgLwYWcoqSlEDB = false;

    return kHpmuDK;
}

bool yVYWvVpukt::PrifGVjUzYAEipz(double ZCtxpMpOQYyy, int ZUvxp)
{
    bool BzhqWgVjzhNhbmH = true;
    string CaMRo = string("ohFdyFeWeMRCoRuvtoFMIiYxeNsLIciUqObEgJChWbWoghhPofjzeAKEObgyPLFOlPoUheeRjreNbejdHXVZklviuprqRpcPalepZBJSPimmtENeSddefFd");
    string GqZyWLmjanR = string("PZlYbDzKkWjSnDCyeGETGwkXFdJlheOrQSnqbMPbkEZbpnTaAAsrSBSMS");
    bool kpPIWVTLeqUYXtF = false;
    double OYiTfD = -687879.0510550722;
    double GwjHfOPnmlJXmvWp = -850392.0025773913;

    if (ZCtxpMpOQYyy < -850392.0025773913) {
        for (int zTtlMJcLJznB = 710358108; zTtlMJcLJznB > 0; zTtlMJcLJznB--) {
            CaMRo += GqZyWLmjanR;
            OYiTfD -= OYiTfD;
        }
    }

    return kpPIWVTLeqUYXtF;
}

bool yVYWvVpukt::LYVrmPzSfirvP(string IPLLxDJbWXsOIbRT, string NJTYOjCGSlWlU, bool radxF)
{
    double mQTMAiyA = -843555.5201408645;
    bool VlQFkcASHbkXkFz = false;
    double HCyAcXmjwPqD = 643800.8341025858;
    int EwSwlyzNnYHOSjyR = -518408695;

    for (int lqpRYmFUzzAhB = 2064331485; lqpRYmFUzzAhB > 0; lqpRYmFUzzAhB--) {
        IPLLxDJbWXsOIbRT = NJTYOjCGSlWlU;
        radxF = radxF;
        mQTMAiyA *= HCyAcXmjwPqD;
    }

    for (int SBmpf = 1028654270; SBmpf > 0; SBmpf--) {
        HCyAcXmjwPqD *= HCyAcXmjwPqD;
        NJTYOjCGSlWlU += IPLLxDJbWXsOIbRT;
    }

    for (int uHjBaKPoNSBBwn = 2105216977; uHjBaKPoNSBBwn > 0; uHjBaKPoNSBBwn--) {
        continue;
    }

    for (int AYwbMXXOdkR = 1403910248; AYwbMXXOdkR > 0; AYwbMXXOdkR--) {
        VlQFkcASHbkXkFz = VlQFkcASHbkXkFz;
        NJTYOjCGSlWlU += NJTYOjCGSlWlU;
    }

    return VlQFkcASHbkXkFz;
}

string yVYWvVpukt::odmyFGGFAwzn()
{
    bool cygjFARfbGZZ = true;
    bool gGQwssDKy = true;
    int ygAtyhJDHjHPHXqU = 450305541;
    int DUejxTtgVmA = -2016917878;
    int GrRks = 1400008358;
    int UhWMVoobIY = 1930329984;
    double IYpbwxLtc = -365131.46931958443;
    double IOMFsfGwVvWxS = -30178.249254465296;

    return string("DvukCkMiloYIEcgOboglQDkNbUKOCYjJxPoHlckgqkWVdrBwNTbLnYcPaLpYLRWnawVNaoIbdGjoTerJhBSStPGMUbLxDEEGZhrYCyt");
}

double yVYWvVpukt::OlUqs()
{
    string QSLMpBCGUwMDjGUG = string("rjaUQsVpJkBqfvHDYpEuxnJnLxRaseaaUcfrOocBmDrcSVarAzoVqruzPLuJJvTzpWPvbPTZhcjtWVPKpPavRxTOzipJbqsLJFlhMYukMryyMapnNuRBhQgSKgbpymqGjKEBCrUQfEKERKMFAASx");
    bool pkmdLothlXp = true;
    string WfOVoraaASMQEQ = string("gIzpQKZUBzXHuZjQpeNLGpojuamlAskHsSubvnYcCjTxQGPqWysCNIcIwRasyOdGGOaYuQAlldEmDvfbIkizIgeKlQiVvtIaWoLnMaxvLauEWjMkZgqNirwxAPtzktrvYPybeojXtxNieihYXmYCvAuTVWRibsBHFrDXckBvTrIawYtEuAjaQlwdghhqFlwwGQcIYwIozkcqiylUUgKImTjAWYTnrHBi");
    int PpztDsNN = 2071476453;
    string LTvlgGrPQxPd = string("XsebbkphMBwZnVwOeGjNYenfjpgKRLXgkXyiqDqKfnVJehhnBqjvWeywEWAQwybtJavINIGUEKxhokKNXzMDXIDMmbRaOsqJQWRHpvaGIQWieSLbuXpUKDvYrBhxHqtUObYotPtgGCqpAuFZNKZJKYKUdRAlzKUVAeMuAaezAgvgwWnnhWeqrQSqewwLmXEWWhJzmSxMjwUmMaBJqBJQgCvcCcwzKubWeevMDi");
    string ohMxZLEW = string("gywKpLXnbhZVWVrzlZsMJKmwIrOhfTabIIwYkoMPbtJoVknmuWSwIengmLmsDSTuhsFzIsBZbEStE");
    string QjuVfUbdgEqKJVVO = string("DsHqOxMhcQnksgPaixwOivqgwgDDFCTlgqRsrqayPTGJOckSZcxQWNfeCvZzPWbXFrdpdYTUbDulJXgWFQyzvPjRWZyvmUkqqCTGUVLggOlxSAvdNRueJVHZtUwlglxfmgMvzMeYrJvABmvmZEyYRWKS");

    for (int WIlBbCDY = 120397175; WIlBbCDY > 0; WIlBbCDY--) {
        QjuVfUbdgEqKJVVO = QSLMpBCGUwMDjGUG;
        QjuVfUbdgEqKJVVO = WfOVoraaASMQEQ;
    }

    for (int YLzJNcEDMy = 718798842; YLzJNcEDMy > 0; YLzJNcEDMy--) {
        QSLMpBCGUwMDjGUG += LTvlgGrPQxPd;
        QjuVfUbdgEqKJVVO += QjuVfUbdgEqKJVVO;
        PpztDsNN = PpztDsNN;
        pkmdLothlXp = ! pkmdLothlXp;
    }

    for (int nLDZDkGcqXhsMpE = 1327579695; nLDZDkGcqXhsMpE > 0; nLDZDkGcqXhsMpE--) {
        LTvlgGrPQxPd += WfOVoraaASMQEQ;
        ohMxZLEW += LTvlgGrPQxPd;
        QjuVfUbdgEqKJVVO = LTvlgGrPQxPd;
    }

    return 978822.7746953204;
}

int yVYWvVpukt::xZSXYibvDSghn(double xSkouQy, int eqYZFvGSKXvw, bool GBcRDPgBVCiEMT)
{
    int XpHbkfl = 1103673724;
    double PfOpXdOWeEi = -199204.667013768;
    double kICvCwtouYU = -619856.2987571759;
    bool SIoVyDuJhMMwpG = true;
    int GjaNSUKfJXeFDH = 2050332132;
    bool bfddxB = true;
    double cZVhpzZl = 694356.1188605116;

    for (int MTruWaZx = 391588930; MTruWaZx > 0; MTruWaZx--) {
        continue;
    }

    if (xSkouQy == -619856.2987571759) {
        for (int CepJXPW = 68177124; CepJXPW > 0; CepJXPW--) {
            cZVhpzZl *= PfOpXdOWeEi;
            bfddxB = SIoVyDuJhMMwpG;
            SIoVyDuJhMMwpG = ! SIoVyDuJhMMwpG;
        }
    }

    if (GjaNSUKfJXeFDH >= 874983659) {
        for (int KGLEnhnLvJqBH = 956174738; KGLEnhnLvJqBH > 0; KGLEnhnLvJqBH--) {
            continue;
        }
    }

    for (int BskMDSiLvGpaV = 1918056925; BskMDSiLvGpaV > 0; BskMDSiLvGpaV--) {
        GBcRDPgBVCiEMT = GBcRDPgBVCiEMT;
    }

    for (int trPBfcAeUXIcn = 1015427607; trPBfcAeUXIcn > 0; trPBfcAeUXIcn--) {
        GBcRDPgBVCiEMT = ! GBcRDPgBVCiEMT;
        bfddxB = ! SIoVyDuJhMMwpG;
        XpHbkfl *= GjaNSUKfJXeFDH;
    }

    return GjaNSUKfJXeFDH;
}

void yVYWvVpukt::gChOKuBHvA()
{
    string vqMaB = string("luzygnHzzkwAIBzbRdLbNFNrPWmnztQEOsmCLpnjywtOnAArogxJPYRvMKeQnWuKzTnTheNwRjeXQwFYLyLmNlqXGRRaGmqQwwHYnhgcSOAIbvVdfHvwEVppQEDXvuXSzdhRuqmEJRkSZajLfxjDZYlwqQvVJqqYWHzZJQYVVyPrEwqucWkdskEelqHvkZlfMEOLqkEKhiycAwSbEZ");
    string uAQPlNrq = string("UifaXsFWIoAbGzygpeCkcHIRkdFZdyvPSbrlLnGwOHvVmGNbZZDrwVdeIxnFyzdpvpSEvemzyJeMgNeBNCCegoFwJdjlesedPhDnHstgBunuNtihjMxTLLOxLqUJNRbbQUXgdEjgdmeHddBvZQikmyUinRwNdRYeZFHAFDjCyRrzsUzItXIkrLujTFOPTggnXOKzJqJiYVHDhAnmLrrTvGg");
    double eJejGo = -307667.2422194009;
    bool OIwTT = false;
    int BPkxttkK = 1198607541;
    double TnLNald = 111902.79488748958;
    double NckerPKafNO = -24478.479412713514;
    double PqzGIS = -796420.7597051003;

    for (int ipIDtnINXHKYH = 1791038783; ipIDtnINXHKYH > 0; ipIDtnINXHKYH--) {
        eJejGo = TnLNald;
        eJejGo += NckerPKafNO;
    }

    for (int zYsQGPzM = 2016853687; zYsQGPzM > 0; zYsQGPzM--) {
        continue;
    }
}

void yVYWvVpukt::zLIlvCDlm(int kaNjnoKhVuAbQSQn, bool HuMdruZAtISvipwG)
{
    string tTYIhUnFzCVm = string("HBbfhMwpFMNvgQqNWqpGWEtPsVuSuXHcLjgUEYRKJLOrjkDMewQiFdNBRKEhZlUgfUSBEYZYgdutHSbPMsFeADWMpQVgTaZaOmixSqHcsoSbSZowQKfJcALRjmvtZEPkgwaXYISkoQASJVqEnjLEVribWjDOMyexLpchJvrQYQKCUDFyKwpetkOvSgBKUcTGnmafslCqGTA");
    double FyTFDRwE = -1012349.3102466757;
    int jDFbBOOHl = 387862611;
    double GRVhAyuc = -519147.3571487312;
    int zHAMrHqREPJNMxey = 1448835614;
    double FXMJblPtDPAnbGk = 369050.0887768064;
    bool nVbBrkHBnvVuUtcA = false;
    string KSagWmTIpiIOs = string("nnhsQTvLBvKnLdlFTRPDcUwSvtBiyofVMrhnClzlFlmYIpFkMBUtOqPDhhvezXNOFASnmgIDuuESqGMUdGwDGgjdcFstA");
    int zIjHZC = 91976870;
    double sxDYWLHfUupcxos = -541474.0529493717;

    for (int viYvKvGKB = 2083953506; viYvKvGKB > 0; viYvKvGKB--) {
        sxDYWLHfUupcxos /= FXMJblPtDPAnbGk;
        zIjHZC = kaNjnoKhVuAbQSQn;
        tTYIhUnFzCVm = KSagWmTIpiIOs;
        FXMJblPtDPAnbGk -= sxDYWLHfUupcxos;
    }

    for (int HigPEy = 1863090295; HigPEy > 0; HigPEy--) {
        kaNjnoKhVuAbQSQn += jDFbBOOHl;
        kaNjnoKhVuAbQSQn = kaNjnoKhVuAbQSQn;
    }

    for (int cyFYRtH = 1291122460; cyFYRtH > 0; cyFYRtH--) {
        continue;
    }
}

string yVYWvVpukt::IuFjRnk(int mFlDnTatQticRs, double lWqFfrW, string uXozeNnyqP, double LchvaMIjUay)
{
    double OKSczPzRnkrKzVh = 446479.6305198602;

    for (int jBtmAkh = 834856121; jBtmAkh > 0; jBtmAkh--) {
        continue;
    }

    return uXozeNnyqP;
}

string yVYWvVpukt::dbluxYflGrARTdTS(int DvYXDssttGhGgHoB, int mLqbQopSIfXmf, int QdAdVEXMkhAvsP, int UsqaYkGpnMm, bool iJkyJtucGzX)
{
    int CdWiz = -112532843;
    double wGpMhQoMMttpE = -471600.5091309805;
    string CCGEIZYaTJ = string("pTWyHFmtODhWAYdMTOLGrkrYGRKXJKarkSjfwrZYHfGiQdbKMdKEHdOTGIlWk");
    bool KbaxLflHCzjzTTdc = false;
    double gjgcPtUEPmMG = -466678.5109170317;
    string pUHaWjpw = string("BGcfHcOSGRRNGPWCqFEmfbiwtrdZcnrHYzgydbPXAXzQwySUjIydYyiWFZcsPFfCZhgYHVvqGwPZlRPwQZSvLvLexMtagcdWiFzQCcbIbQVEgeUofswWH");
    bool VVlIoFCujP = true;

    if (gjgcPtUEPmMG < -466678.5109170317) {
        for (int MbCevxgFuUg = 1216305770; MbCevxgFuUg > 0; MbCevxgFuUg--) {
            DvYXDssttGhGgHoB += UsqaYkGpnMm;
            DvYXDssttGhGgHoB += DvYXDssttGhGgHoB;
        }
    }

    for (int nPYYd = 1483176402; nPYYd > 0; nPYYd--) {
        gjgcPtUEPmMG *= wGpMhQoMMttpE;
        KbaxLflHCzjzTTdc = ! KbaxLflHCzjzTTdc;
    }

    return pUHaWjpw;
}

void yVYWvVpukt::ODvHHc(double sBPCEIdNASAP)
{
    bool EGiezjYwafREri = false;

    for (int zPHLTGY = 1538020408; zPHLTGY > 0; zPHLTGY--) {
        EGiezjYwafREri = ! EGiezjYwafREri;
        EGiezjYwafREri = ! EGiezjYwafREri;
        sBPCEIdNASAP += sBPCEIdNASAP;
        sBPCEIdNASAP -= sBPCEIdNASAP;
        EGiezjYwafREri = EGiezjYwafREri;
        sBPCEIdNASAP *= sBPCEIdNASAP;
    }
}

yVYWvVpukt::yVYWvVpukt()
{
    this->AXJRukNhFHzkFfG(-638824.0685372844, false, 710932.2760551014);
    this->iXxAsr(string("qctluZLrJgCcuFprvECovMLFsEEHPOvhBcNMcPGfPgtldkZEiuytmbzveoROgCWfQfWOUComiSlHbTDDOsrJZyOV"));
    this->lpCKLIdQsHzjhW(false, string("qHveACXJZkRQektKBVWMKuojEMqaKsfWkXlmdeOIKaRrmNTNNtEkbSXpJpHdqlzEvKZvsZfnudzpVKKupXlUIguQWWSPUDjnznbTUTa"), string("NwehyWQeeYYOEheJsQERrqZrayOKtiOXyytXmsSUggWkVnRf"));
    this->vvEHZELHOnszqIG(568446239);
    this->PrifGVjUzYAEipz(263492.5588056597, -655171009);
    this->LYVrmPzSfirvP(string("WuzKBbTxUGtHYZtmrasZMaLNLBnOfSQTEzyfbgJsyUkqTmfeyRhxDabKycHXBvJoCDKXpfkgxrnDUpbyNqAjdirTWOKyEppbFwNwxBbnxHhBmUOkJuWDvQsvSNXPxtbAOgffdjpd"), string("OyIQvoMxMPQKDRYmHFiBHtRsnojmCbfKBUKYwcvaCjFpBkIKsHSlGeEbnlTrOFwTrQlVBpyVldMWJlWuxhqrxgFOLdAmCKcqOkQfuWOeYVtVsBUOkkrwghkYjDbUzsOUSstgnvBQdKZTwgLmlUoLRJONKkDClWASoIPBhSaRXzlARaqgSMSABTNvOcoxdlglTKARjiHSxwHIDCedpGwtIbgNFFAzoWtGtGQtVbWtYcqDsKohOnxHJmqhnE"), true);
    this->odmyFGGFAwzn();
    this->OlUqs();
    this->xZSXYibvDSghn(-176947.3162054515, 874983659, false);
    this->gChOKuBHvA();
    this->zLIlvCDlm(206458729, false);
    this->IuFjRnk(-283422011, 158705.19890133486, string("fMeOEDPdeCcSnIoDUyPFZDphGNPaeBMMFoqeiETglptPHmgiKiUGAjTOyBDDKtRGfIgfnvhzrAHkImKcyenkyctaClzcBCNEzFoWxZzRtrayAUSRzZWEAfMqszZXrTmXsZuiAtbhpkjzuYefZlraYSoHUrYYWudcFzSrljlivjolJuvPOfXRXMayBeInxgBjeJFwGcRjWhtXdLiFcwQKTidBbUhUq"), -1033788.5711033365);
    this->dbluxYflGrARTdTS(-1758838341, -1553578901, -257335678, 844716873, true);
    this->ODvHHc(863131.1525485078);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PqSULBqxVm
{
public:
    int DqsydCyTHZ;

    PqSULBqxVm();
    void cOYiKXcYEiL(string zBRCnBwEkfELaxw);
    bool cSCURk();
    int ogVoz(string KMjZnEGucyny, bool MPiRFlXfCYJM);
    int fFAdsawK(bool bNeJVcc, double gIjeNhPiUMRsVIq, bool iwcjIKWzo, bool fkdErgS);
    void kSLcFujbD(double dVqNSdPdSLWWwddo, string JhBIwEoPv, string CwIPTi);
protected:
    string ixVeBVNwoFRG;
    int oIDMPug;
    bool SmcbcYPcIzoYZ;

    int xereFJxhNuWj(double HLLBIE, double dWupSfMabuLvy, string wnnoDrXebxG, int ekLWInpyRfXSfLI);
private:
    double eRSmSOsQx;
    bool dEsPt;

    void zWwCnNK();
};

void PqSULBqxVm::cOYiKXcYEiL(string zBRCnBwEkfELaxw)
{
    string SPMmS = string("UflUekDkVSFDwkGkaVJERXtxfcCsawKChavElzimxzZrVNPCV");
    int omcyMcXh = 84613924;
    double JlpiWpfUdC = 163597.51383463855;
    bool CObGhvTffnHNQOm = true;
    bool wmfLNbNJkJHpt = false;
    double YVbKXh = -894620.7970769533;
    int ytQxkM = -1529893018;
    double JemCZDJkHsMh = 868795.9922558401;

    for (int VLZHWKHmxPEeRscT = 156357042; VLZHWKHmxPEeRscT > 0; VLZHWKHmxPEeRscT--) {
        wmfLNbNJkJHpt = ! CObGhvTffnHNQOm;
        zBRCnBwEkfELaxw += zBRCnBwEkfELaxw;
        omcyMcXh *= omcyMcXh;
    }
}

bool PqSULBqxVm::cSCURk()
{
    int RIwqvNg = 554524585;
    string ZUPzKgutbqBJHMG = string("zcgePNIhLpxcCVJwDzbwIAkyAxBIzZZsgijmaOLuqeFoqjVnpVezrhfrhjqnICmTxHYElVbZvXCYbISDjbzXnyLdNOJHqGBtxIleRZSBRvFsvVKzljMqaxGprRUvLSdiOFuxcbZBaZIXSkwJgAhXDTlNgmbTWLaJlsybcKlbsRgvhQRZEAspRWUTgTNKMeHZAiyAnkHmivstweWHozvafBkWytBNhpQyEDLUITvwRFtu");
    double dXGFf = 913813.1907764794;
    string zRMkxaA = string("VwkFMKZGzJCVcnrBVXbIVvproDGzQbCxoQTpTrRjdBbtozFSLpkrGVPoNvbraiaRSis");

    for (int FQvttV = 300343971; FQvttV > 0; FQvttV--) {
        continue;
    }

    return true;
}

int PqSULBqxVm::ogVoz(string KMjZnEGucyny, bool MPiRFlXfCYJM)
{
    double XSJFBjZNVPWc = 863952.3669530823;

    for (int glhpcCEgXwnbBi = 1615560228; glhpcCEgXwnbBi > 0; glhpcCEgXwnbBi--) {
        MPiRFlXfCYJM = MPiRFlXfCYJM;
    }

    for (int oPmoyEIft = 31054880; oPmoyEIft > 0; oPmoyEIft--) {
        MPiRFlXfCYJM = ! MPiRFlXfCYJM;
        KMjZnEGucyny += KMjZnEGucyny;
        XSJFBjZNVPWc = XSJFBjZNVPWc;
        XSJFBjZNVPWc /= XSJFBjZNVPWc;
    }

    for (int TVfDOyZVVrJRo = 846737512; TVfDOyZVVrJRo > 0; TVfDOyZVVrJRo--) {
        continue;
    }

    if (KMjZnEGucyny != string("huUB")) {
        for (int qSpUTUb = 1290268718; qSpUTUb > 0; qSpUTUb--) {
            KMjZnEGucyny += KMjZnEGucyny;
            XSJFBjZNVPWc = XSJFBjZNVPWc;
            XSJFBjZNVPWc -= XSJFBjZNVPWc;
        }
    }

    for (int ZLTrL = 2026940026; ZLTrL > 0; ZLTrL--) {
        KMjZnEGucyny += KMjZnEGucyny;
        XSJFBjZNVPWc -= XSJFBjZNVPWc;
    }

    return -596327738;
}

int PqSULBqxVm::fFAdsawK(bool bNeJVcc, double gIjeNhPiUMRsVIq, bool iwcjIKWzo, bool fkdErgS)
{
    int eipiVRtdpC = -1066709497;
    double oZUzUfut = 625880.7925682135;
    double FLgfoYyVIgkaVBKQ = 492433.7806323321;
    bool MQkItDsCocqnXl = true;
    double tuUeGCbhyYVEE = 64889.873186141216;
    bool ydTtBNf = true;
    int ysFlTg = -70837000;
    bool IeeaA = true;
    double cLGWTnNNygEipjI = 177498.29622304594;
    double qXxhrVfkit = 952198.5473492364;

    return ysFlTg;
}

void PqSULBqxVm::kSLcFujbD(double dVqNSdPdSLWWwddo, string JhBIwEoPv, string CwIPTi)
{
    bool etCqfnJVaFTXQc = false;
    string lZczWdcXxYnIVIe = string("JVGNtlKMLyPrPGWcQdlDxjIOhyxmFgJVCBSfQMdGSxsCQerHcUwFSZrOrlBIVZoHwaJDDMYkk");
    bool PmHurKSsYDA = false;
    int decHHFySHnC = -1851785177;
    string SyLSM = string("rJeOiWEEeVpaqWjpfAIFIMuSvjelNZUXTTVRxTobeJEEbSOWbvSmBTuUKKYJxFxLKshnYfSLypqFkJyFGMRrrZj");
    bool aEGfajFFWIHsXXeg = false;
    int ntugRrBOMDwRjdpT = 1548963392;

    for (int vcxPNf = 105186040; vcxPNf > 0; vcxPNf--) {
        aEGfajFFWIHsXXeg = PmHurKSsYDA;
    }
}

int PqSULBqxVm::xereFJxhNuWj(double HLLBIE, double dWupSfMabuLvy, string wnnoDrXebxG, int ekLWInpyRfXSfLI)
{
    string LrIUmQurjdD = string("YKBdrliWyqLYkRudNRcsvAEzMpyIXLAVjSUOvaWSUFCGxFvFZRUCzxrZwPIPVxIkaxdlfqLoCLaqyoMOvEUhNgwpoSvCoJghUHgmAAKmUCuxBCURZcKhwmjhQaMTHIleVTASqFbQxJjyrfdqbqpDFGxHuWzbWICIMisjYJQZhPuCVVjebolLxfZTcLGLwtAHFUKTIsFohvpGgCxiKPxqhZrUAbnZmYZeRVQuSEn");
    int ZcZHa = 1174513955;
    double sLJTGZmlcqjhYy = 591742.0562164675;

    if (ZcZHa == 1174513955) {
        for (int tuuGUHmXnWiTLCKd = 1807788281; tuuGUHmXnWiTLCKd > 0; tuuGUHmXnWiTLCKd--) {
            LrIUmQurjdD = LrIUmQurjdD;
            wnnoDrXebxG = LrIUmQurjdD;
        }
    }

    for (int vPoVDc = 445383401; vPoVDc > 0; vPoVDc--) {
        ekLWInpyRfXSfLI += ekLWInpyRfXSfLI;
        sLJTGZmlcqjhYy *= sLJTGZmlcqjhYy;
    }

    if (dWupSfMabuLvy >= 591742.0562164675) {
        for (int GoBuibVAUZHaWK = 1329003195; GoBuibVAUZHaWK > 0; GoBuibVAUZHaWK--) {
            sLJTGZmlcqjhYy *= dWupSfMabuLvy;
        }
    }

    return ZcZHa;
}

void PqSULBqxVm::zWwCnNK()
{
    string eRKfKTgUJnoxh = string("SQYlcZGvlIFfwXDNvJlOxktmbXHfbpNZkbFHYnMqsvDkMXWDIMJkpkBdzSOXwoVgffIDvAeIrCZEsLuyHdVnrpQQEdigDMKnrAKhJiMJjqhhwYNwIbIRRuLxHaFYxurMLktPRAyTScHazimiSUdneYBFWtlXRwCLIGVyTfcAsKZDidfIZfizlmbuOlqSufvDqONZ");

    if (eRKfKTgUJnoxh >= string("SQYlcZGvlIFfwXDNvJlOxktmbXHfbpNZkbFHYnMqsvDkMXWDIMJkpkBdzSOXwoVgffIDvAeIrCZEsLuyHdVnrpQQEdigDMKnrAKhJiMJjqhhwYNwIbIRRuLxHaFYxurMLktPRAyTScHazimiSUdneYBFWtlXRwCLIGVyTfcAsKZDidfIZfizlmbuOlqSufvDqONZ")) {
        for (int ZMnZokHxsxNuoKOE = 415109405; ZMnZokHxsxNuoKOE > 0; ZMnZokHxsxNuoKOE--) {
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
        }
    }

    if (eRKfKTgUJnoxh < string("SQYlcZGvlIFfwXDNvJlOxktmbXHfbpNZkbFHYnMqsvDkMXWDIMJkpkBdzSOXwoVgffIDvAeIrCZEsLuyHdVnrpQQEdigDMKnrAKhJiMJjqhhwYNwIbIRRuLxHaFYxurMLktPRAyTScHazimiSUdneYBFWtlXRwCLIGVyTfcAsKZDidfIZfizlmbuOlqSufvDqONZ")) {
        for (int QzDEwmAf = 298339672; QzDEwmAf > 0; QzDEwmAf--) {
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
        }
    }

    if (eRKfKTgUJnoxh < string("SQYlcZGvlIFfwXDNvJlOxktmbXHfbpNZkbFHYnMqsvDkMXWDIMJkpkBdzSOXwoVgffIDvAeIrCZEsLuyHdVnrpQQEdigDMKnrAKhJiMJjqhhwYNwIbIRRuLxHaFYxurMLktPRAyTScHazimiSUdneYBFWtlXRwCLIGVyTfcAsKZDidfIZfizlmbuOlqSufvDqONZ")) {
        for (int zVYFkeCOH = 820853557; zVYFkeCOH > 0; zVYFkeCOH--) {
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh += eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
            eRKfKTgUJnoxh = eRKfKTgUJnoxh;
        }
    }
}

PqSULBqxVm::PqSULBqxVm()
{
    this->cOYiKXcYEiL(string("zYNjgbHiqPcFewfNaqWZqXayrgAmpkInoZTpmHVlltwJpoZOntCOPLFMXuYndUXylaRtoRKQZctlNCNTjWqcbW"));
    this->cSCURk();
    this->ogVoz(string("huUB"), false);
    this->fFAdsawK(false, 708485.9782643655, false, false);
    this->kSLcFujbD(-713432.1674517397, string("MNJeHWXkzheyyXHIHJPfOcgPkboclwpVtTuodzkQKQDfqkVCYcrKvXEtJlrubioYnNOOCzHKOSSZBxSyHtbZNPMQZRrpNZkFlCGPZgdrZjDSQTtgNyaqlpDezevkyyULVlLSBpNcrOsJwFdUJPRZROLxuTooJRhjVGakhHSzISdCdmjJjFVZXrMXFrtnPETSsyTuXUYPkQCYXlnJjwExkimU"), string("kEDIzjeuqlZPSPgdPPxyvZKfmAIBjbIcJJWpZduytgjbHszzRtpJaFTjneezROuGHQOujICMNMwTDSNohkulXpRjJOWXEeWETUVuNFEguhFZlYOD"));
    this->xereFJxhNuWj(-306733.16121826635, 577999.7696946048, string("HascngexUdPXiLwfliRZAdqSssYcGKbEEnxVHICFethCNEQXZcNUnwSGllWOycKChzHWkngtwoZPuoBtBiQgdcQrWfmNCuuLIxojGWhGBe"), 1628224874);
    this->zWwCnNK();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LMHYsjlIlhCKgu
{
public:
    double htxSodGmcU;
    double LdDVUkVrBR;

    LMHYsjlIlhCKgu();
    void FTxrBfUNnDU(double PXrPFQzd, string cdFhVXGOKhhAKEl, string nNTkh);
    void oubuLhaYnAQUJcN();
    string ifBntTGB(bool JCxTQv, int mNokVNCG, int KRRqeEsjXA);
protected:
    string EtIkATc;
    int oEKZJtcSebR;
    int RLSpIKSbSqvqZ;
    bool bEEcHFUwRwTOPzd;
    double UegpFLyW;
    double OiyTTtQhN;

    double qEofAlMqGBX(string WBbcNdke, string HtXHCIsqsO, bool ReMLGooVdLvDOX, double oyKlTopB, int FQBfHZdbWokUE);
    void nBmudMMgV(int XIxRKMUiKpdOjVtb, string lJCeEFMMCD, bool cujBlJADhYxkmaJv);
    bool VGQvRRjr(string NHvVEBMmolLi, double hVKzSqpFsRVLs);
    void jZhAaTzBH(string fRIKQPT);
    void BvJFNoPQAIcNsAEf(int fieaeiRInvyEBgT);
    string NExVpwHpSdPyyyiK();
    string YFMgRJPvcT(int vKjgDBZdD, double TUEgJOzvOyZAAreV);
    bool LbuiuewdQ(bool YtBxunx, string nzlSqDEHDRN, bool QDsNCfEtqM, double pZcrzVpPKwoSG);
private:
    bool OEUGSvU;
    string SSqtCRzOl;
    string RQuAY;
    double jiOIaYopGXcaTDm;
    string RiRGnOeneTR;
    string PdrJknVwSrNg;

    bool LvMxnlPXDIa(bool WidePrhTYNzj, bool namFANHcDSD, double cvHCPURPjeNTbE, bool QrMDAa);
    double EAcWwJIYqABBp(bool aIVfwfjLNFilztMh, double vZBwdwCpQSJdUfcY);
    void PViPJx(int WwrcdLnyA, string LYtay);
};

void LMHYsjlIlhCKgu::FTxrBfUNnDU(double PXrPFQzd, string cdFhVXGOKhhAKEl, string nNTkh)
{
    bool UmSrdLxrmPhH = true;
    int tlmQjVUwBSBLi = 245576378;

    for (int EFKlNhlv = 410221355; EFKlNhlv > 0; EFKlNhlv--) {
        continue;
    }

    if (nNTkh >= string("hcGLJdLTetwiPMcihKnrXgUjtcWaRyJOkTwRrUEHmxoDHQznrEoTU")) {
        for (int unobWKafZNlb = 1217540821; unobWKafZNlb > 0; unobWKafZNlb--) {
            tlmQjVUwBSBLi /= tlmQjVUwBSBLi;
            nNTkh = nNTkh;
        }
    }

    for (int LwNNIPHridAJyA = 237011463; LwNNIPHridAJyA > 0; LwNNIPHridAJyA--) {
        continue;
    }

    if (UmSrdLxrmPhH != true) {
        for (int zlJeIQkCsGA = 321205418; zlJeIQkCsGA > 0; zlJeIQkCsGA--) {
            continue;
        }
    }

    for (int KahbTURZxulJck = 1926521371; KahbTURZxulJck > 0; KahbTURZxulJck--) {
        nNTkh = nNTkh;
        cdFhVXGOKhhAKEl += cdFhVXGOKhhAKEl;
    }

    for (int LkCZBDkTG = 884262879; LkCZBDkTG > 0; LkCZBDkTG--) {
        tlmQjVUwBSBLi += tlmQjVUwBSBLi;
        PXrPFQzd *= PXrPFQzd;
        nNTkh += cdFhVXGOKhhAKEl;
    }
}

void LMHYsjlIlhCKgu::oubuLhaYnAQUJcN()
{
    string KsGLPgnmBIJN = string("WOodfPEPNsCleqkQjDszKRZmaOcOWTaPDAQomnOIrujPCbGMPqolPnAxXGGTbgicysTJsEqLztyXaNGmeoHkAfaQCALSuFDOzOwfvsU");
    int ueZDGOtAxXff = 1368457951;
    double dqmxkxJVT = -889734.4751151631;
    int pMToSZaTVujGAGtq = -935068654;
    bool EzamkgxwEJkoD = true;

    if (pMToSZaTVujGAGtq < 1368457951) {
        for (int eMesWBL = 685848961; eMesWBL > 0; eMesWBL--) {
            pMToSZaTVujGAGtq /= ueZDGOtAxXff;
        }
    }

    for (int aJhiFshtdOTZNFu = 134140571; aJhiFshtdOTZNFu > 0; aJhiFshtdOTZNFu--) {
        dqmxkxJVT = dqmxkxJVT;
        dqmxkxJVT += dqmxkxJVT;
        KsGLPgnmBIJN += KsGLPgnmBIJN;
        EzamkgxwEJkoD = EzamkgxwEJkoD;
    }
}

string LMHYsjlIlhCKgu::ifBntTGB(bool JCxTQv, int mNokVNCG, int KRRqeEsjXA)
{
    bool AovncdPACqLmwv = false;
    double TvHxTmhzbYdqc = -662010.1203381877;
    bool LZMNxbw = false;
    bool ZMHVstYlrA = true;
    bool yNNcZSkFQzLJjKO = false;
    bool KsAEWZKVKSRyX = true;

    if (yNNcZSkFQzLJjKO != true) {
        for (int GYaVuMWs = 1609853638; GYaVuMWs > 0; GYaVuMWs--) {
            LZMNxbw = LZMNxbw;
            yNNcZSkFQzLJjKO = JCxTQv;
            JCxTQv = LZMNxbw;
        }
    }

    for (int gNmdBsXGPjj = 1053883412; gNmdBsXGPjj > 0; gNmdBsXGPjj--) {
        JCxTQv = yNNcZSkFQzLJjKO;
        KsAEWZKVKSRyX = ! JCxTQv;
        TvHxTmhzbYdqc += TvHxTmhzbYdqc;
        JCxTQv = ZMHVstYlrA;
        yNNcZSkFQzLJjKO = ! yNNcZSkFQzLJjKO;
        JCxTQv = LZMNxbw;
    }

    for (int PKcWN = 1664236514; PKcWN > 0; PKcWN--) {
        JCxTQv = JCxTQv;
        yNNcZSkFQzLJjKO = LZMNxbw;
    }

    for (int MQzFsrcBerz = 553002947; MQzFsrcBerz > 0; MQzFsrcBerz--) {
        JCxTQv = KsAEWZKVKSRyX;
        KsAEWZKVKSRyX = KsAEWZKVKSRyX;
    }

    if (yNNcZSkFQzLJjKO != true) {
        for (int QEVZoTbfDjHZIG = 2040018445; QEVZoTbfDjHZIG > 0; QEVZoTbfDjHZIG--) {
            yNNcZSkFQzLJjKO = ! AovncdPACqLmwv;
            LZMNxbw = yNNcZSkFQzLJjKO;
        }
    }

    return string("jVhTAgiTskafSWbjZsGUhWhpQpHPyoIOTeBDZubJLryBSYVRNGdCCfRVlOGPaGFbBOzySeXMvDFCHTkzRqUNwJlqfmQJpUrjpxmhTnnZUZiDRIbbaERWHyCY");
}

double LMHYsjlIlhCKgu::qEofAlMqGBX(string WBbcNdke, string HtXHCIsqsO, bool ReMLGooVdLvDOX, double oyKlTopB, int FQBfHZdbWokUE)
{
    int PACVGMqjqy = 55746540;
    double APFsW = 333671.5008721326;
    int mqNkLOpLdm = 371129665;
    bool bOvHxvbyUESizuoi = false;

    if (HtXHCIsqsO == string("GZBiUIhaFebiBtMiWhVOMYhNvsUpZCkPWoakmuEaQIQVaOWaHBptYHKWxaBvHDvqIfmSlfLbnVOZsOqBjXiKPHldRVhxPdEncDVlCQVJNCTDIGDCjiUkrkNrAsKrZjzHPYrvLKxsPEYnpPSoRuxUBCEykAnZmJcIvxne")) {
        for (int gpNmLXo = 31525321; gpNmLXo > 0; gpNmLXo--) {
            FQBfHZdbWokUE /= FQBfHZdbWokUE;
            oyKlTopB -= APFsW;
        }
    }

    if (bOvHxvbyUESizuoi == true) {
        for (int OGnTOiKiFWClyh = 268110077; OGnTOiKiFWClyh > 0; OGnTOiKiFWClyh--) {
            oyKlTopB /= oyKlTopB;
            APFsW += APFsW;
        }
    }

    return APFsW;
}

void LMHYsjlIlhCKgu::nBmudMMgV(int XIxRKMUiKpdOjVtb, string lJCeEFMMCD, bool cujBlJADhYxkmaJv)
{
    bool xRjSkCSBcMFhFr = false;
    string TZTZlwHR = string("WyqcjybUKSotTsOAIaNGskxhDGfheOcelcPrg");
    bool KWmXZayRh = false;
    int cSNMZF = 633819057;
    int QNIagaR = 152205851;

    for (int iXOWFIfyevGdsFhg = 1926997761; iXOWFIfyevGdsFhg > 0; iXOWFIfyevGdsFhg--) {
        KWmXZayRh = ! KWmXZayRh;
        cujBlJADhYxkmaJv = ! KWmXZayRh;
    }
}

bool LMHYsjlIlhCKgu::VGQvRRjr(string NHvVEBMmolLi, double hVKzSqpFsRVLs)
{
    bool FzNaeW = false;
    int DxluNlpLg = 103728955;
    string ufAlwYeiBSd = string("PjikvrdrRtipyeDLQMShJaBOvEFQBTpurIoaMjXToFbRQlNgwXZlqsxgpzsmZvKeGPsYNgGZlQxYtUbzfsPBzRVyFwbWkHIfQVOkDNobMcGrujthUwaaKHYDiZjhjGJpIGDKJohCITwZnRxvywPLQQadAjMZrIAatEtxYbncpCGrBhULvPKQKnnoXMzgtTypGeTnjuG");

    if (ufAlwYeiBSd < string("PjikvrdrRtipyeDLQMShJaBOvEFQBTpurIoaMjXToFbRQlNgwXZlqsxgpzsmZvKeGPsYNgGZlQxYtUbzfsPBzRVyFwbWkHIfQVOkDNobMcGrujthUwaaKHYDiZjhjGJpIGDKJohCITwZnRxvywPLQQadAjMZrIAatEtxYbncpCGrBhULvPKQKnnoXMzgtTypGeTnjuG")) {
        for (int cHkFdqRMEhDmXg = 1264168607; cHkFdqRMEhDmXg > 0; cHkFdqRMEhDmXg--) {
            NHvVEBMmolLi = ufAlwYeiBSd;
            ufAlwYeiBSd += NHvVEBMmolLi;
            DxluNlpLg += DxluNlpLg;
            FzNaeW = ! FzNaeW;
        }
    }

    return FzNaeW;
}

void LMHYsjlIlhCKgu::jZhAaTzBH(string fRIKQPT)
{
    bool epuMmMqIiEdAp = false;
    double mgdEdsI = 259303.16430558273;

    if (mgdEdsI <= 259303.16430558273) {
        for (int MBtgUWsGOiibPoUP = 940180420; MBtgUWsGOiibPoUP > 0; MBtgUWsGOiibPoUP--) {
            fRIKQPT = fRIKQPT;
            epuMmMqIiEdAp = ! epuMmMqIiEdAp;
        }
    }

    for (int wroXqsARVRQPYrHK = 1103168952; wroXqsARVRQPYrHK > 0; wroXqsARVRQPYrHK--) {
        mgdEdsI -= mgdEdsI;
        fRIKQPT += fRIKQPT;
        epuMmMqIiEdAp = ! epuMmMqIiEdAp;
        fRIKQPT = fRIKQPT;
        fRIKQPT = fRIKQPT;
        mgdEdsI = mgdEdsI;
    }

    if (fRIKQPT <= string("IETXdTKIApiRdXHisTTVeXluHnpnwFdHxrZIngcndRPyGKxkDgQf")) {
        for (int woyKjgpnaWfI = 798828155; woyKjgpnaWfI > 0; woyKjgpnaWfI--) {
            mgdEdsI /= mgdEdsI;
        }
    }
}

void LMHYsjlIlhCKgu::BvJFNoPQAIcNsAEf(int fieaeiRInvyEBgT)
{
    int dxoJnGThOwyiEqU = -1816070083;
    int EYwSADNvwiRnXzVl = -1872173636;
    string LXFhD = string("pHMsZAUrmiJBoTGTfIlObqvpMosCJwLDxhaAmLzBuAVxjOVtIdpIKzInjCTTXGnYuRLOAWYkIgJzBEBIsIdfNkPoZKhbmprLnnriRTyDSUSHSNKAppHVwbZyGBwWinGJMPKXQkPvqTtCWchhXNrRLwDBIAVJmPJCBCMCIJUDBQaXenzfAOvsBteCnMSpHciCZSncQEsaDfgsbnlmInundezvRDXodNLjINWogd");
    bool ELwNhqAGFGLFrWLJ = true;
    double aNbIkFOjDr = 291263.20865606365;
    int XLfKFz = 1290981670;

    if (ELwNhqAGFGLFrWLJ == true) {
        for (int eXuMJZQcn = 563098192; eXuMJZQcn > 0; eXuMJZQcn--) {
            fieaeiRInvyEBgT /= fieaeiRInvyEBgT;
        }
    }

    for (int uUxcY = 633857598; uUxcY > 0; uUxcY--) {
        XLfKFz = XLfKFz;
        dxoJnGThOwyiEqU = EYwSADNvwiRnXzVl;
    }

    if (fieaeiRInvyEBgT >= 1290981670) {
        for (int VHWAniK = 1319907715; VHWAniK > 0; VHWAniK--) {
            ELwNhqAGFGLFrWLJ = ELwNhqAGFGLFrWLJ;
            EYwSADNvwiRnXzVl /= fieaeiRInvyEBgT;
        }
    }

    for (int GxLjLrETCSam = 1674631947; GxLjLrETCSam > 0; GxLjLrETCSam--) {
        EYwSADNvwiRnXzVl -= EYwSADNvwiRnXzVl;
        dxoJnGThOwyiEqU += dxoJnGThOwyiEqU;
    }
}

string LMHYsjlIlhCKgu::NExVpwHpSdPyyyiK()
{
    int JEHQbdxTFme = -853338920;
    bool qNftnsoeWLAkAQB = true;
    int gbKMEeo = -1048177230;
    double pQvmqYjZdYd = -475853.21007148473;
    bool JkkqLIINDEinkOeq = true;
    int yHCJubbUamcmc = -977585846;
    int mLgrxkOrLAZwpkr = 1821788141;
    string EDtvGUEY = string("bnqNBpCZVmNJhhpxvaCEJEXBqSAVGMGkhrEOTbTYNavBigqtUvcZZtDTEAGhiesXsGxTahCCWnwwOZWXDAvbgvLndsYfCWLbsSmHkPbP");
    int VdJlGJxtN = 1433272960;

    if (mLgrxkOrLAZwpkr >= -977585846) {
        for (int LWgzbQfZqxFJVP = 203797392; LWgzbQfZqxFJVP > 0; LWgzbQfZqxFJVP--) {
            mLgrxkOrLAZwpkr -= JEHQbdxTFme;
            yHCJubbUamcmc -= VdJlGJxtN;
        }
    }

    for (int qVDRqieUOyrNYS = 1558451723; qVDRqieUOyrNYS > 0; qVDRqieUOyrNYS--) {
        VdJlGJxtN = yHCJubbUamcmc;
        JEHQbdxTFme -= gbKMEeo;
    }

    for (int LdAHilbVlrPsOlXI = 343557365; LdAHilbVlrPsOlXI > 0; LdAHilbVlrPsOlXI--) {
        yHCJubbUamcmc -= yHCJubbUamcmc;
        JkkqLIINDEinkOeq = ! JkkqLIINDEinkOeq;
        mLgrxkOrLAZwpkr /= VdJlGJxtN;
    }

    if (yHCJubbUamcmc >= -853338920) {
        for (int BwESu = 1107082162; BwESu > 0; BwESu--) {
            VdJlGJxtN += yHCJubbUamcmc;
            JEHQbdxTFme += VdJlGJxtN;
            VdJlGJxtN += JEHQbdxTFme;
            mLgrxkOrLAZwpkr -= mLgrxkOrLAZwpkr;
            EDtvGUEY = EDtvGUEY;
        }
    }

    return EDtvGUEY;
}

string LMHYsjlIlhCKgu::YFMgRJPvcT(int vKjgDBZdD, double TUEgJOzvOyZAAreV)
{
    double TWFhKX = 190793.13152869965;
    int ZZNUHARVSP = 214540079;

    for (int jwIZT = 1621415878; jwIZT > 0; jwIZT--) {
        continue;
    }

    for (int hRFSCrbvhWKR = 240691939; hRFSCrbvhWKR > 0; hRFSCrbvhWKR--) {
        ZZNUHARVSP -= ZZNUHARVSP;
        TWFhKX *= TWFhKX;
        TWFhKX += TWFhKX;
        vKjgDBZdD += vKjgDBZdD;
    }

    if (vKjgDBZdD == 214540079) {
        for (int dyFnbBUJCg = 821561316; dyFnbBUJCg > 0; dyFnbBUJCg--) {
            vKjgDBZdD += ZZNUHARVSP;
            vKjgDBZdD -= ZZNUHARVSP;
        }
    }

    for (int FwHPHnJvj = 292908551; FwHPHnJvj > 0; FwHPHnJvj--) {
        ZZNUHARVSP -= ZZNUHARVSP;
        TUEgJOzvOyZAAreV += TUEgJOzvOyZAAreV;
        ZZNUHARVSP /= ZZNUHARVSP;
    }

    return string("tKYiRpTttUZaOrRBslmFnZqytjsheWlobVAGrTNzxDmymERQYzDuHzpCVZEjUrexqewjVufbyXUAeqOmyUchstavCUVU");
}

bool LMHYsjlIlhCKgu::LbuiuewdQ(bool YtBxunx, string nzlSqDEHDRN, bool QDsNCfEtqM, double pZcrzVpPKwoSG)
{
    double EAoNdM = -549603.321720745;
    bool jcVLlhZihpyQfGn = false;
    int uiMkYZlEpIAyb = -1725723203;
    double cXxMShwxsohwLF = -1004456.9479971363;
    bool gyWhrnKDdJCA = false;
    int QULuQEw = 274419593;
    string oDvUgShMqznEjtyE = string("xQTfCETPnsQjrVWfBGplvxqBEBCwPIHjuwUNaaAqyabdhgOffyYpmvzTNXdDkEsKczqXbRjxPZUXxGsqSYQfjPgtdaphvrLVnlkuzydqobfIoopXXxpNfWFFVjVAJgPlbedsvKafZTwExDIYkYisluamezeYNRpMTRmIBMoBjWbjRDpNGndocNnAksjIQLOyhBuKSjWdSGsyiTpMHiplZlr");
    int QxqojHxBch = 2095870160;
    double GyiIwmjYFZqRv = 118555.19255925363;
    bool TUnTMIJepFe = true;

    if (QDsNCfEtqM == false) {
        for (int aKDmY = 995436954; aKDmY > 0; aKDmY--) {
            gyWhrnKDdJCA = QDsNCfEtqM;
            cXxMShwxsohwLF *= EAoNdM;
        }
    }

    for (int rhhjSgqWvl = 1393075601; rhhjSgqWvl > 0; rhhjSgqWvl--) {
        pZcrzVpPKwoSG = EAoNdM;
    }

    for (int BgLiLzkrHNFhwskK = 382462518; BgLiLzkrHNFhwskK > 0; BgLiLzkrHNFhwskK--) {
        oDvUgShMqznEjtyE = oDvUgShMqznEjtyE;
        oDvUgShMqznEjtyE = oDvUgShMqznEjtyE;
        jcVLlhZihpyQfGn = YtBxunx;
    }

    return TUnTMIJepFe;
}

bool LMHYsjlIlhCKgu::LvMxnlPXDIa(bool WidePrhTYNzj, bool namFANHcDSD, double cvHCPURPjeNTbE, bool QrMDAa)
{
    double wVkVGnT = -777139.1156211513;
    string AVVMPyl = string("ZuqKKPkLpiVRSxemNxZkCsfipEFMJzlBVnhYBsdhuSSemIHOyMqnrCaRIbIwMICiJFfuUbMoDQQGNefJgPyyvBdxAwblbfwLHHHQUEOaeKsNbTkJZRkflJLJvnFLPe");
    string mwytZKp = string("idwdgslmjUHbnzOGxKHiWUbblrALKgfAXFrVWEZKqmYTextjTyIhxNyuvMIMsmspXoyHHXrElEMNXqtiQeEWpOIfebrJItUROyjKrFVcFsc");
    int aRACmMHvLSKDIiPm = -968621415;
    bool TrJYMkhhwkMvas = false;
    double GZaIkVTSKXVtvkjJ = 396262.3309078312;
    double MhzREFYGL = -637031.653697621;

    for (int fgcVwOeDofldgnL = 1882024578; fgcVwOeDofldgnL > 0; fgcVwOeDofldgnL--) {
        mwytZKp = AVVMPyl;
        mwytZKp = AVVMPyl;
        namFANHcDSD = TrJYMkhhwkMvas;
    }

    for (int PmoBSivcbBlFRu = 1027442514; PmoBSivcbBlFRu > 0; PmoBSivcbBlFRu--) {
        WidePrhTYNzj = TrJYMkhhwkMvas;
        WidePrhTYNzj = WidePrhTYNzj;
    }

    for (int ewOdW = 1450328674; ewOdW > 0; ewOdW--) {
        mwytZKp = mwytZKp;
    }

    return TrJYMkhhwkMvas;
}

double LMHYsjlIlhCKgu::EAcWwJIYqABBp(bool aIVfwfjLNFilztMh, double vZBwdwCpQSJdUfcY)
{
    string jDfldMEJyhrx = string("NsYFUjxIUMBwpTtrgprctASRqwzIhgSQuDMdaQnSjTKGMrAfaexHckeWVFtsaujb");
    bool KgVGaSbTMZJ = true;
    int hRzjldsscUDTvH = -2069547747;

    if (KgVGaSbTMZJ == true) {
        for (int knyJt = 935294265; knyJt > 0; knyJt--) {
            jDfldMEJyhrx += jDfldMEJyhrx;
            KgVGaSbTMZJ = aIVfwfjLNFilztMh;
        }
    }

    return vZBwdwCpQSJdUfcY;
}

void LMHYsjlIlhCKgu::PViPJx(int WwrcdLnyA, string LYtay)
{
    string NzMppkAXkRAOPG = string("JtsoHCuaSmVofNAxEnyDOFdDBOsMBjEGEuMJmhAyNnRvwQUIyoYbqdrmDtiCDrrkzbgMrhmTARbRbRzOyowJFSldfBPYtJOchjsyGotTiqKMetWbahFeVNpzjSEffwRQrsgZahSRwSIQNOWEgRiyByXpAdvzEklipGs");
    double ETUvNHiVLJFGX = -703597.6959755947;
    int iGIyXu = 1948827954;
    string guibPAgsBenFvrt = string("orUWzRUzyyvJMhdlHXMXSrKUmUmiYdOkcBtTgXSoTXRzyqwCesIRrQnlOeQhZbgYrhvKhItNXRgLmxdWMBvzn");

    for (int bTtPKfak = 1444942458; bTtPKfak > 0; bTtPKfak--) {
        guibPAgsBenFvrt += guibPAgsBenFvrt;
    }

    if (NzMppkAXkRAOPG >= string("JtsoHCuaSmVofNAxEnyDOFdDBOsMBjEGEuMJmhAyNnRvwQUIyoYbqdrmDtiCDrrkzbgMrhmTARbRbRzOyowJFSldfBPYtJOchjsyGotTiqKMetWbahFeVNpzjSEffwRQrsgZahSRwSIQNOWEgRiyByXpAdvzEklipGs")) {
        for (int xYYVidjBWKTNdIdN = 1238793440; xYYVidjBWKTNdIdN > 0; xYYVidjBWKTNdIdN--) {
            LYtay = NzMppkAXkRAOPG;
            LYtay = guibPAgsBenFvrt;
        }
    }

    if (NzMppkAXkRAOPG > string("biqqIYWOdXKhETlaYXHoDymDNRXJUvbsZQhwbdeiRnkvbhTqVRQstgwbCcjDYIWuAsvxwWBtlCJsDQueQTKlSXClaJexvMcOqnrdgqiGFupxvoyduOFWOMEMMlnwBKvKiAUNtZaEjxDQoXTJG")) {
        for (int xbPjyQRobmZoVL = 2069266968; xbPjyQRobmZoVL > 0; xbPjyQRobmZoVL--) {
            WwrcdLnyA += iGIyXu;
            LYtay = NzMppkAXkRAOPG;
        }
    }

    for (int WqUHadLisnkpv = 836456144; WqUHadLisnkpv > 0; WqUHadLisnkpv--) {
        continue;
    }
}

LMHYsjlIlhCKgu::LMHYsjlIlhCKgu()
{
    this->FTxrBfUNnDU(-481836.2275465236, string("hcGLJdLTetwiPMcihKnrXgUjtcWaRyJOkTwRrUEHmxoDHQznrEoTU"), string("QgzPfnKEffdmnUMmaGuARlkzaLlnTRTKBJLWVmvqEhZdCIkyqzOkulFtQZHfkfijzvOXSRsAZyCGIsJkvsaTmTxoWHwMHSXqJWnivNUlKMvEoOvFmVUSmsmRlKLJzaceDWFdSzDxKLMKCZYaohDmOBXsLzqagExLWuZOldMNPkfHRahC"));
    this->oubuLhaYnAQUJcN();
    this->ifBntTGB(false, -1964477722, -946271161);
    this->qEofAlMqGBX(string("BvKnAVXDxZHXtRZyPDlxgSKWpYqgUTnCwyMCSGlpeZNwUoMGBVJOaMQJDYcNfkeIluetOFmaDWzENR"), string("GZBiUIhaFebiBtMiWhVOMYhNvsUpZCkPWoakmuEaQIQVaOWaHBptYHKWxaBvHDvqIfmSlfLbnVOZsOqBjXiKPHldRVhxPdEncDVlCQVJNCTDIGDCjiUkrkNrAsKrZjzHPYrvLKxsPEYnpPSoRuxUBCEykAnZmJcIvxne"), true, -992191.9080512518, -1369877448);
    this->nBmudMMgV(-1143460055, string("lDGkSAkFEAPvkjROJyzHNBLoRyQGgCdjyFoNB"), false);
    this->VGQvRRjr(string("vkdFLjZhtlgrjncIATrROniDqqAUOmJDxGkbjBvckTazDImLnSCLtfQpscbTRRGTWKRNGdgyOsZoQIlugLlcKNlVTXQzfnADtMkxlqIrXNurLWxuGzaqDNsmqBshLxGwcePWPAUEKMYITnaFsRIsfKJxUMJpYqwsXG"), -789875.7697853785);
    this->jZhAaTzBH(string("IETXdTKIApiRdXHisTTVeXluHnpnwFdHxrZIngcndRPyGKxkDgQf"));
    this->BvJFNoPQAIcNsAEf(-890111455);
    this->NExVpwHpSdPyyyiK();
    this->YFMgRJPvcT(1049938921, -408520.75717486494);
    this->LbuiuewdQ(false, string("GyoBouefAiURFpPQEBJDYsuTCmlkuOuahtPfwsgmnJVTjOuWuQGNAmmAamjGuZHWIrSyAlUPfObMYdLXNMAltgbmHknrrWvbckmmIeIenvhJHximKvhkoXNXKguwhEWCdGbUQDZDyFFMmMEhHXcNgApibcyKJvvXwkZBlJnKPLORCPUOUKdjPYcjsyabHWAJrRMisMidAAPOdSIEQjQVwcXoVBlmiEjIbQafIvaSpEUovUMHscosPvPNPCA"), true, 694126.503845343);
    this->LvMxnlPXDIa(false, false, 3158.299640023679, true);
    this->EAcWwJIYqABBp(false, 679020.1799367559);
    this->PViPJx(107355045, string("biqqIYWOdXKhETlaYXHoDymDNRXJUvbsZQhwbdeiRnkvbhTqVRQstgwbCcjDYIWuAsvxwWBtlCJsDQueQTKlSXClaJexvMcOqnrdgqiGFupxvoyduOFWOMEMMlnwBKvKiAUNtZaEjxDQoXTJG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class THpMhYCpQgg
{
public:
    double MFsMEVtGmqSMe;
    int JEHfgbUisD;
    int xSHnwFXueIC;
    double leftuoQvyPiSItE;
    bool RLruzMYkZ;
    double aFCqsGYcChyjIgEk;

    THpMhYCpQgg();
    double LyemUqAhEjFEaXMM(string ELcTqUUL, double hikFBt, string zsEIAY);
    void KrJklB();
    double VtqNl(string yQGkXOeaEKCdqEq, double BfKlzF, double XvtkmKdLsZHLaoo, string JZxDlGFE, string UbnEwuYxPLRGgwm);
protected:
    bool OykkBsGR;
    double YptVa;
    int kmDmqY;

    string UIjXjwvNRPxo(string DJBvDWYjiGx);
    string gBBllJIXnPSC(double jaTlukDZReAVB, bool IPzTHks, string NyWmoQkYFpfcpP, double JfTEIlQ, int PzJoSKhCnHpMJ);
    bool MIBPeoAOqP(string gXYimwNl);
private:
    double AcJTTCuyFrkpzf;
    bool mvoamlHuIr;
    double osZrPHtqZNmccW;

    int JuqUXwoLDz(double NViOxYJ, int auMDzkUMQVCX, bool zGZbRPkTzPQMfE, string amuMoaea, double TXTEFukeVhYYhtv);
    int bwFbDSbHodc(string EeKllrgE, bool QpsgI, bool wcTcMTCkmazHb, double fckedqlfsDtjrXM, int GdPkIZNOBsXPrOdJ);
    string IbzkNLQ(bool lEkSRfJ, double NGBYxrpVm, bool LfvTfASDxFNxi, int sUXIxi);
    int TPXKnlfHYxPkbgu(double uPujmibK);
    double gpszMEf();
};

double THpMhYCpQgg::LyemUqAhEjFEaXMM(string ELcTqUUL, double hikFBt, string zsEIAY)
{
    double bglbcfipvnwWUhz = -763163.4208119453;
    string xDAJrGSrYNGTXL = string("SJsevYTjYzkAtBdzlUJhWEDapyrsiGWNAevcfbGsxqgtZTopwGIlrHpWiashPXnbGZURCHREXEcbQwdyEiHCfEgrIkjNLvNLFkEuQBNqOhaEKIkvxygJUkHQvHLgbfFJeyTyPRSHPooaPeTCDB");
    string vpnZvOXMHLc = string("ScrDZcBSDIOEvvbXduluUEYPTZQyIPnXJWyeexiwxElZyiPWYbLJiLnzNyAZhPySIZSoZJVRVeCboXMZXKyrXEIWwHiMdnIRNZVKhCOOtNGHZcZDlGGsmbDVlmQCpxjakuksxuHcTqKHHSmyZllMfyYXxutJyRoSGBql");
    string wyfrCMQlP = string("qhiXEIPREyhNBnDcLBeCjQqHKtMvTBvdlymnKujXsaFCnMMkVhmfufufzfAvTcMjnrIDtQZFNcdrffRtBhqfetiOrUooBDejiMiOzlsXhThvuQSU");
    int kGStUwYZCSaxN = 495159791;
    bool xwfbVcLNtmN = true;
    double XiqRPg = -740376.7520837326;
    double DZVlfJGBWaIN = -833509.9752699019;
    string dracyEVz = string("xfWPThVGfUIVYWmlhmvXXkUKirawqLnARnpgOXtgIgYcTeREpzThGryWauHEGwVxQpmXREIFXWXxUXGkXRnVEMfwxeHSkjxWIISrIlWKnGalJDvvnpQKhByifeYDYtOAXTEKbokrOEWPMrcDsDPKPqZgrMqWzmUXUECYqrgKoEfMFyzizFzFPELjHFGHirInBDzsZtVjdhHncYrfVPLBwhcpsrQMQIXkGXjwUiwlIEwitO");

    for (int YWwjFRP = 985665339; YWwjFRP > 0; YWwjFRP--) {
        DZVlfJGBWaIN /= DZVlfJGBWaIN;
    }

    for (int XmwHibTHFfxmLne = 1139123909; XmwHibTHFfxmLne > 0; XmwHibTHFfxmLne--) {
        hikFBt -= hikFBt;
        ELcTqUUL = xDAJrGSrYNGTXL;
    }

    for (int WsMUbYkYoffFXlEX = 79732014; WsMUbYkYoffFXlEX > 0; WsMUbYkYoffFXlEX--) {
        wyfrCMQlP += vpnZvOXMHLc;
        vpnZvOXMHLc += ELcTqUUL;
    }

    for (int XrazVqcQlNh = 1163846070; XrazVqcQlNh > 0; XrazVqcQlNh--) {
        vpnZvOXMHLc = ELcTqUUL;
        dracyEVz += wyfrCMQlP;
        dracyEVz = vpnZvOXMHLc;
    }

    return DZVlfJGBWaIN;
}

void THpMhYCpQgg::KrJklB()
{
    double QCOSLtL = -247268.92558276778;
    double mgvlCMARhZwfqbG = -190337.02467920657;
    string TjBtQwUPKArIxfb = string("QxCShgjtTaCthCPlfLvqQogWx");
    double usLBdZdTo = -752262.4959444198;
    string WBKhpjIrtv = string("exjTQWviXRQVyFWcXpElPStiRKXiYrFxIQECrIXCcaFCnmsEupZcMZRnNPehkXuvFkvdaujGIXJyTyjCAqGWGAwBpCTRTyCOMENwjdoTOQLfoXPKuwJUMXONJLDvucuYjtkMgVukbFvdnmmCiOKwXkHJYcgHhpfxAesrWfoklhzBHtXpjUMxidA");

    for (int ikQglYAXBXWZw = 678780924; ikQglYAXBXWZw > 0; ikQglYAXBXWZw--) {
        usLBdZdTo -= mgvlCMARhZwfqbG;
    }

    for (int CvwtpxWQ = 75256659; CvwtpxWQ > 0; CvwtpxWQ--) {
        TjBtQwUPKArIxfb += WBKhpjIrtv;
        TjBtQwUPKArIxfb += WBKhpjIrtv;
        usLBdZdTo *= usLBdZdTo;
        usLBdZdTo = QCOSLtL;
        QCOSLtL = mgvlCMARhZwfqbG;
        usLBdZdTo /= QCOSLtL;
    }

    if (mgvlCMARhZwfqbG >= -190337.02467920657) {
        for (int hdcBHOaEzjbdl = 1901865537; hdcBHOaEzjbdl > 0; hdcBHOaEzjbdl--) {
            continue;
        }
    }
}

double THpMhYCpQgg::VtqNl(string yQGkXOeaEKCdqEq, double BfKlzF, double XvtkmKdLsZHLaoo, string JZxDlGFE, string UbnEwuYxPLRGgwm)
{
    double sasQkYwUBUpmxS = -283637.09769279236;
    bool BEVvkvZSlWJQSUP = false;
    bool VQUbzLF = true;

    for (int LreUFvIWgI = 774415238; LreUFvIWgI > 0; LreUFvIWgI--) {
        BEVvkvZSlWJQSUP = BEVvkvZSlWJQSUP;
        sasQkYwUBUpmxS = XvtkmKdLsZHLaoo;
    }

    for (int VdQQQodp = 309474245; VdQQQodp > 0; VdQQQodp--) {
        sasQkYwUBUpmxS *= sasQkYwUBUpmxS;
        JZxDlGFE = yQGkXOeaEKCdqEq;
        BEVvkvZSlWJQSUP = BEVvkvZSlWJQSUP;
        UbnEwuYxPLRGgwm += JZxDlGFE;
        sasQkYwUBUpmxS -= BfKlzF;
    }

    return sasQkYwUBUpmxS;
}

string THpMhYCpQgg::UIjXjwvNRPxo(string DJBvDWYjiGx)
{
    int jobnFfLiQey = -14055170;
    int LgfQf = -1800086261;
    bool dTVLsDdsZ = false;
    string QyJyPgfuqxBE = string("dyDTSHTUqWoHcKCdGyLxQIwdNETAsZGqXdiyKWtOmbpAuShFGRZCUQBeSVHFGYapGblAOlUHXKauQAzDiKxEVOWVWIChSyJBSoTweTpFnXZNDLpXdQDDYnbTdxilhXmffLZjVCPSnvfliVGXlApHABJfDFhDfMiHNCoLnIhUePVDvpBhBKVfeJPoQYlFLUbxzkxBajVqdRsmHKxQmkuAVea");
    double NfDOARprLWPB = -397698.3460224348;
    int cfmSDy = -220461129;
    bool JYAunV = false;
    int aFwVdpnzrM = 1055335148;
    bool SMmpqxZ = false;

    return QyJyPgfuqxBE;
}

string THpMhYCpQgg::gBBllJIXnPSC(double jaTlukDZReAVB, bool IPzTHks, string NyWmoQkYFpfcpP, double JfTEIlQ, int PzJoSKhCnHpMJ)
{
    bool goKLioYjpHtuSvo = false;
    string IchukOgcgEkboFa = string("ysEBFgvdjJDFyRJvhWQwxCJIpONmJwWjeVUuLBWdFRLlgWoejwspKxYAxsgZlKZsrZALDfkANFPJziZGHuNupAWBqaLTqpakYXNVETlRhLQtnjncETbNDsasatILgLDqhrAv");
    bool eGzNhCDbid = true;

    for (int HnXZELSWzK = 93420941; HnXZELSWzK > 0; HnXZELSWzK--) {
        continue;
    }

    for (int fxMRJEtSJRayZ = 869796764; fxMRJEtSJRayZ > 0; fxMRJEtSJRayZ--) {
        NyWmoQkYFpfcpP = NyWmoQkYFpfcpP;
    }

    return IchukOgcgEkboFa;
}

bool THpMhYCpQgg::MIBPeoAOqP(string gXYimwNl)
{
    bool THBvlpxVJR = false;
    bool drLvAAkjpu = false;

    for (int UsJOZwYt = 637883570; UsJOZwYt > 0; UsJOZwYt--) {
        THBvlpxVJR = ! drLvAAkjpu;
        THBvlpxVJR = THBvlpxVJR;
    }

    return drLvAAkjpu;
}

int THpMhYCpQgg::JuqUXwoLDz(double NViOxYJ, int auMDzkUMQVCX, bool zGZbRPkTzPQMfE, string amuMoaea, double TXTEFukeVhYYhtv)
{
    double GJbHOOLSBCZ = -528757.1917957561;
    double SByOMNLrXzip = 667101.6431994854;
    double TogXUl = -111806.36116552517;
    int pSdYkoZrJ = -1088541829;

    if (zGZbRPkTzPQMfE != false) {
        for (int AUFtdfSe = 1616879443; AUFtdfSe > 0; AUFtdfSe--) {
            continue;
        }
    }

    return pSdYkoZrJ;
}

int THpMhYCpQgg::bwFbDSbHodc(string EeKllrgE, bool QpsgI, bool wcTcMTCkmazHb, double fckedqlfsDtjrXM, int GdPkIZNOBsXPrOdJ)
{
    double diUlnyzLQ = -941397.2478939609;
    double azydJxcBZYUOGHUe = -32132.07730308798;
    string gFWCYZydqUlf = string("bBvMrNOICWKjdYyJkWwzJtLQeeqhIYjipTykRLvTaAkLtXjTxlprfDgUZKeyBOKDWpBBqbUvDJmHiwvgVnEcoTtDdfQDIEOQJgZzSHLwmqSgwAOTZNBZqgNQvctsWcERUuBaKGjWWNMDYsUotwAK");
    int UZmWpfjMpfgWvu = 2101607827;
    int QEJPpinUEZmJX = 396106082;
    string qqzVrxQGclU = string("oQuVqYzSEOaTOkFwjaZKBjgaOZBNLueeEsWrwWGRPscgjxbcLahPyuqzQGjfIXTyFIxjjEGvQmXRWkZWEDSnvLOrYtaGetBkIFMZMMJTvYDfCZoafJvIPZhftfzGBxRRWwKryGptckOwYqsKSQITrhujlKuHfpgRXMc");
    string vsWDT = string("eTXzUbQazEcFsjMNZZQFsbxrvpvstHyezjxluEUGKKDMSbFrSxeyiwywxOYiDlDHqDafFvsMTZnLMPKlWvtFMRwGPszlYOrAjDYhvDkoBMOAFrfPZTINfvaLwqCzeRMEMnxPUeXVzpSSARDKSMczpBWLsPYlQMibWglhmCrsIPNKqhWAyVTarBeNXphunnPrAAQ");
    int TgMMZWQJbCLvM = 1453473811;
    double HZtSkMRuMSrkEFu = 697515.508610277;
    double gyoJvhhEvOlQyJ = 379023.6211543514;

    for (int eTAsy = 1572054352; eTAsy > 0; eTAsy--) {
        qqzVrxQGclU += gFWCYZydqUlf;
        fckedqlfsDtjrXM -= gyoJvhhEvOlQyJ;
        vsWDT = gFWCYZydqUlf;
    }

    for (int tixZHnzkGDamPF = 482873309; tixZHnzkGDamPF > 0; tixZHnzkGDamPF--) {
        continue;
    }

    for (int ZbFgbtsNChThKr = 800215269; ZbFgbtsNChThKr > 0; ZbFgbtsNChThKr--) {
        TgMMZWQJbCLvM = UZmWpfjMpfgWvu;
        GdPkIZNOBsXPrOdJ *= TgMMZWQJbCLvM;
    }

    for (int OokGvp = 1551531774; OokGvp > 0; OokGvp--) {
        continue;
    }

    for (int XYBcbkZvdzNvrn = 852787644; XYBcbkZvdzNvrn > 0; XYBcbkZvdzNvrn--) {
        continue;
    }

    return TgMMZWQJbCLvM;
}

string THpMhYCpQgg::IbzkNLQ(bool lEkSRfJ, double NGBYxrpVm, bool LfvTfASDxFNxi, int sUXIxi)
{
    string HCoBQ = string("dCrVUIrpOPqTxvghyxVTJqFVTdGjDYpVZPhSHgsxKGnzUbgnJzZgabYJISPsxQvMiEMAxcZAXoofGiYDDJBidwQNzCGOIAXRkOnWyFEiQValLqeGkJgPL");
    bool WXxHW = false;
    double rUPFxIAPUqpqVY = -344363.9359370335;
    bool IAYcqfajJPfpkmv = false;

    for (int muxnQ = 2123510480; muxnQ > 0; muxnQ--) {
        IAYcqfajJPfpkmv = ! lEkSRfJ;
    }

    for (int iLCUDn = 1668892508; iLCUDn > 0; iLCUDn--) {
        WXxHW = ! lEkSRfJ;
        IAYcqfajJPfpkmv = ! LfvTfASDxFNxi;
    }

    return HCoBQ;
}

int THpMhYCpQgg::TPXKnlfHYxPkbgu(double uPujmibK)
{
    string mrgNtSTcs = string("rtGaCtYVkGrTLHZLyBrpZMIUbXeacoCGnPsyUxPxoIunWGrtHnKsdsHQTZGR");
    double dXfDSBEdtoMffX = 982598.9752720917;
    string wksnjiEg = string("UoVFkbWSytEBnguiHRaSeDbvUUwVSCHtkrkTHdsjHuOoWxtpEpInZMdOwVFwSeWfAXIanWanCsPLrDcNozkchKbwXdZrFwciTGOPJznqVXBsqFgstJDndjVGqVKNPBGTwDfCfVIJqpxjAEqICROeAbSQgKhHSiuewimnThYFYUaGvBRgjtWzAHMwAuKCmxIRWDDYdrqdHCMpDQsVYfkattkHFYfBEWAKwsOOWLzMPrdjraoYFfhxyDfuCJ");

    for (int GUUupdJZQ = 699747767; GUUupdJZQ > 0; GUUupdJZQ--) {
        wksnjiEg += wksnjiEg;
        mrgNtSTcs = wksnjiEg;
        wksnjiEg = mrgNtSTcs;
    }

    if (wksnjiEg > string("UoVFkbWSytEBnguiHRaSeDbvUUwVSCHtkrkTHdsjHuOoWxtpEpInZMdOwVFwSeWfAXIanWanCsPLrDcNozkchKbwXdZrFwciTGOPJznqVXBsqFgstJDndjVGqVKNPBGTwDfCfVIJqpxjAEqICROeAbSQgKhHSiuewimnThYFYUaGvBRgjtWzAHMwAuKCmxIRWDDYdrqdHCMpDQsVYfkattkHFYfBEWAKwsOOWLzMPrdjraoYFfhxyDfuCJ")) {
        for (int soCXFtMlTrcie = 684483837; soCXFtMlTrcie > 0; soCXFtMlTrcie--) {
            continue;
        }
    }

    for (int HiYfyQqhtqAkGZ = 955722369; HiYfyQqhtqAkGZ > 0; HiYfyQqhtqAkGZ--) {
        dXfDSBEdtoMffX = uPujmibK;
        wksnjiEg += mrgNtSTcs;
        uPujmibK = dXfDSBEdtoMffX;
    }

    if (wksnjiEg != string("rtGaCtYVkGrTLHZLyBrpZMIUbXeacoCGnPsyUxPxoIunWGrtHnKsdsHQTZGR")) {
        for (int IfgpFIUx = 894241044; IfgpFIUx > 0; IfgpFIUx--) {
            wksnjiEg = mrgNtSTcs;
            dXfDSBEdtoMffX *= dXfDSBEdtoMffX;
            uPujmibK -= uPujmibK;
        }
    }

    if (wksnjiEg != string("UoVFkbWSytEBnguiHRaSeDbvUUwVSCHtkrkTHdsjHuOoWxtpEpInZMdOwVFwSeWfAXIanWanCsPLrDcNozkchKbwXdZrFwciTGOPJznqVXBsqFgstJDndjVGqVKNPBGTwDfCfVIJqpxjAEqICROeAbSQgKhHSiuewimnThYFYUaGvBRgjtWzAHMwAuKCmxIRWDDYdrqdHCMpDQsVYfkattkHFYfBEWAKwsOOWLzMPrdjraoYFfhxyDfuCJ")) {
        for (int yhcIg = 1661513044; yhcIg > 0; yhcIg--) {
            wksnjiEg = wksnjiEg;
            mrgNtSTcs = wksnjiEg;
        }
    }

    return 902330073;
}

double THpMhYCpQgg::gpszMEf()
{
    int PPgqEiOUNaFEvVx = -1582212833;
    double MpUjRBfnQtJVIv = 179365.31598441835;
    int yhRAqTvWEQMrdu = -810009302;
    int sCBySAH = -1610560715;
    bool oDrrQSXVwqElgHhG = true;
    double ZxMSthohxJRmgEeO = 236197.5722497766;
    string bpRnFt = string("CIgAWeegJnYYDBhvWdZOeWXsSrZsBzQhnrqgfovXnKJwlrjzvVFRlQiIlTilORmgpONNCQjgUhnFZzSKFySVCBLcElKYnMAiKrWbnzMcyyyhXmqzYRMxhBpHrkhySRXmYgsPzHvsKajlvoHVZbHIJGTahbfeeLrLIwjplZRsLaEtSiNZprdsfrkzvsZfpsOLPNqpxbKehCKdJUANVkagxxdJAJoKvviVRjCWpDUdZwsLGotxiSEzNNvrFkhFBm");
    double TbPoSLhEjKLSt = 647711.9107671254;
    int zPlOmFEcZfbt = -1175243914;
    double UzpFflJOUXdsDR = -296328.7811623612;

    for (int lUMyXUdEEwUljK = 361547761; lUMyXUdEEwUljK > 0; lUMyXUdEEwUljK--) {
        ZxMSthohxJRmgEeO -= MpUjRBfnQtJVIv;
        oDrrQSXVwqElgHhG = ! oDrrQSXVwqElgHhG;
        MpUjRBfnQtJVIv *= TbPoSLhEjKLSt;
        TbPoSLhEjKLSt *= ZxMSthohxJRmgEeO;
        TbPoSLhEjKLSt *= UzpFflJOUXdsDR;
    }

    return UzpFflJOUXdsDR;
}

THpMhYCpQgg::THpMhYCpQgg()
{
    this->LyemUqAhEjFEaXMM(string("JwaUhDkdYSBdlUdgRAMtgwkbDrqIfzHjFNwGreLfFesZVUIROOtGdpobybjamDxVzMkQWzNpiNrNLYZEKAFFrCWGqi"), 612.3691259597921, string("VVzJDTNkwWjFwIKoyUfcQSnUFlkyEvwdjikOnqALUtrROaQasPJcukcKHGAuGkfxdBGcCkntpkPdBYWRXCPmczAMPqwYZirOiTGMHljEbhgFVxYonkIWRuXYGDYWnvdrBfqOJqwdHkhahKLWnXoIdMewLgHHuclETzuHfBtPKyhsiDeQijTZNsfFVFKmoIqcsggwKPyUrcUzPGLFPFZjURMU"));
    this->KrJklB();
    this->VtqNl(string("LjWGQW"), -1044420.4194524455, -105548.45424407683, string("DvgGPRFHXMzDNFqACmwveSioNhIUMfcWVlynwYYGhLmPdtAqtqvIdHvGxoNEIYoQHArJOvXMbYgdkLmqyMHKVGONOYNzYxyvmLhwqCOTNFRpmAzvBiVwaRDwEErjLmppJHsVLlhGbqKmkhFkLvzyefaBYbLyLqzmDHKJvdUvYAvhY"), string("FTIddZpByagoixuMrgKGaHszmipAdgQkQSYMiQTLJDfhwanAIsqryIJzDaJwojRTjfyYGmEcldCDWfPVABhznmddhZNiEJLYxsOjkQJRLWCaiLqTMHyvntoZDyOEorqsFcfZGBtFcqwwPyyhPzlcbsigUijImyUHyuIejgpq"));
    this->UIjXjwvNRPxo(string("sYKPNYQvTJYfQqnGelgezDJQVxiqPgytgQqohcCXHLrJAvobhJdxOzqQCetqlHxImBecZGNbzulsaToWOPXGJQBFRNrKSzvWtocbwyVHdYXKZKhpZdMYXribcVRnJtqGfktnazGoxawLbeMvmCCpRAiZQxwVcKwTADJqnporLnjdOluZuuQKWLYFavzWfEOGGNvpmaPgcUIssdEsMQagNboJKo"));
    this->gBBllJIXnPSC(-637528.0255310287, true, string("xkUcgJuZyKSmSWqDJiLZsxTGgipEZLwuLxyvvJHhsxRsZueoCsUBDnFlIJDbjJrzQcCWGwPMGRDDfjmnWWLFNYimInJLmqWQXuhBkkOxAFpkdmREEDedoYTXjMkimwTG"), 289578.1024280213, -2093167360);
    this->MIBPeoAOqP(string("frORwTT"));
    this->JuqUXwoLDz(-167585.21539783254, 1426587186, false, string("gZHIfZRyoSErMveQPFdQCUZXIhkkNcfJKUNNvaxSlStimpvLAwxdgVWFhdNpmZSnkvXwYCithBPDwsLKbxNvXwmQZhAngpxuXUGYJsydgspDgzvZoQIRFYaiyIkiHNaRlsEITmYFeoSQeXTAFOFojTzHYcOgnoSzvXtOYUEItdvzVoOavqnixiDBron"), 233347.81293464857);
    this->bwFbDSbHodc(string("KXOfCGxFWPizomkdxtYAsTqCtWIPQuEQHew"), false, true, 71409.89536424296, 218787801);
    this->IbzkNLQ(true, -173556.45323317507, true, 1742907576);
    this->TPXKnlfHYxPkbgu(-127297.43677618212);
    this->gpszMEf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XZGwYagp
{
public:
    double CivtPrnWms;
    double wwtHnsMFfB;
    string WXHTeesMJOmCcm;
    int UVCPDMjKpcJeNc;
    int edrXT;

    XZGwYagp();
    double mwATn(double JGzOKpIHqdloHh, int wVAXAuharZOTUc);
    double bbguFWtdRgsvOSjQ(string SEOvykB, bool hKwXunrfQnapoz, bool akqPVcBHvNRsvQ, int EkrByajylrXKTda);
    int HRQEMDUqQ(double suTPcFSRt);
protected:
    bool cgcZYCnNjBLIyIE;

private:
    string LTgfeNrWjNh;
    int eZhMcCdxBO;

    double EoFHSKcZRgCEwJB(string gpXhMekft, double wvvSMtmMohrDXTX);
    void rBAiWRKFL(bool XAVnKHeeOhs, int RSIjviKSe, bool NYXczZwaMoQIYcOC, bool dkDxLOZXROUW);
    double VeRsaMBSxqDfnkLX(double HsATBQtnpaVvWAe, double FDdNJ, string ocoltADN, bool pzACjaXJB, bool pQfkaRFNE);
    bool VAlpiEXqyAoOWOeU(string ERYuglcKKqDCo, double pyqUmmfl, bool yeURrOiYlOBUnZH);
    void IeIiHoZDn();
    bool AUVdX(double GzUAQigOXg, string PcSCB, bool bxFCXhMKpsHpVPzj);
    double WCYqDHqKHSJk(string vwCvwZZmWthfS, int SLNzYSDdaZN, bool tponbtbfuckulHv, string fNOEFozGzjIzEYM);
    int CwOWRp(double tHjwfCqh);
};

double XZGwYagp::mwATn(double JGzOKpIHqdloHh, int wVAXAuharZOTUc)
{
    double cBXRXpbECTv = 20721.525160470737;
    bool WkLkubqNpcXvJts = false;
    int noFhLAOnJwPK = -911200456;
    int kdpURAQjjujzuuv = 317758436;
    double fiZkd = -411902.6503301761;
    bool mxpDrprUVxtO = false;

    if (wVAXAuharZOTUc == -911200456) {
        for (int iiapPwVsZqGNBe = 1133419362; iiapPwVsZqGNBe > 0; iiapPwVsZqGNBe--) {
            mxpDrprUVxtO = mxpDrprUVxtO;
            wVAXAuharZOTUc = wVAXAuharZOTUc;
        }
    }

    for (int FOyaZVOLVD = 486179499; FOyaZVOLVD > 0; FOyaZVOLVD--) {
        noFhLAOnJwPK /= wVAXAuharZOTUc;
        noFhLAOnJwPK = noFhLAOnJwPK;
    }

    return fiZkd;
}

double XZGwYagp::bbguFWtdRgsvOSjQ(string SEOvykB, bool hKwXunrfQnapoz, bool akqPVcBHvNRsvQ, int EkrByajylrXKTda)
{
    bool bPoHvRSddNYbSDnu = false;
    string iUqeT = string("jdJlOywPoVLtDPJNUAcqnflvYsPCdHLUwCOXPPrrCEiFnjLBRElOlKLZgoauNvXxizaMldpJFbDgmJzNZfMLZQzJUpOUuNyprqrEqvWvggBXJtoUsrMgCcUhSIRRqgNjMuuRMJlArIraDNsZRuFIlmLdzKKllBYXfFEsTqpVqZuRSNcGdB");
    string ZhwxFKEzOwGDyGm = string("laQAglpfuBvMWHwaPIjpeyxTmhWWeBaAJgDzBZuwgGbRAKGNNeELeibQCmuHGTFnmSTvlWPrpwScsjTyewZYUwNMAyZvHLVcFAfyFFUnlarjzYEtZbpbHlSHgTGZcgUuXbrUgWFRCjpQoXJOCTLDZSfecWvMOSipLcZpOLOSqpPZFeHFFYDXbQzBYApIRgKDCMmFHGRksMN");

    for (int qcJOtLX = 1422338094; qcJOtLX > 0; qcJOtLX--) {
        continue;
    }

    if (hKwXunrfQnapoz != false) {
        for (int TIxUpgs = 852832369; TIxUpgs > 0; TIxUpgs--) {
            SEOvykB = SEOvykB;
            ZhwxFKEzOwGDyGm = SEOvykB;
        }
    }

    for (int ZSUsjKXk = 2008290797; ZSUsjKXk > 0; ZSUsjKXk--) {
        SEOvykB += iUqeT;
    }

    if (akqPVcBHvNRsvQ == false) {
        for (int xyPYWyCNQa = 798393015; xyPYWyCNQa > 0; xyPYWyCNQa--) {
            iUqeT += iUqeT;
        }
    }

    return 733162.155689309;
}

int XZGwYagp::HRQEMDUqQ(double suTPcFSRt)
{
    int EteAiTjbWkYEqVe = -500132228;
    double vFOLznJzPdt = -163561.44698024678;
    int GhFRqkhqNR = -47995585;
    int vpwXJEvF = -414783688;

    return vpwXJEvF;
}

double XZGwYagp::EoFHSKcZRgCEwJB(string gpXhMekft, double wvvSMtmMohrDXTX)
{
    string pPuMHOpXMHogIh = string("ShsVXDuyDjbmVKlGUlUQrqZEHqbOcBJBfQRBZZDDsDZTVHvfuOCILrsazoDaNiuLzizJsYjgNoaIsTkDKJrfaOCcDCIaObanIkQZYppMCtRIXcattaeGSnKgQiMyHjgVGCioxAAFXoEJVmlssiDfSNXedxylBICvWvoplHkYLYnQHSlTOBijcqSjihNqTaSWnyxDSRUVeaYrJmvnVLYEiZEQUMxFAnXoSaMXjtLVOdAUGDViHQCdwiLu");
    int wperxTtxZxadr = 939865248;
    string KMNKy = string("WWraapRekqVrIsSDxjKdKIgrVKiUIuaWwPCHLtHQvzgZrOJOSkVgYzBCNgRHvkvnODuwFBMydvbebrEpFbdrqggAQunYPkSBGxFEQBjTFxSmqoSYbBaAWSLOnBjosXQrkpozlkBZpMpxNVgVvYSCPxgklKXrjBwSPYksWzbSnNzfuqXaQTpyzopYXQjBOQDoSWNqWgOKJWCToRtpjGZgyZDJfAIrTsBiKdzyAtgk");
    bool JQuOUTC = true;
    bool bTfHrkLK = false;
    int aqmTPtWsyXH = -1225772574;

    for (int HbKkvADC = 1256304961; HbKkvADC > 0; HbKkvADC--) {
        KMNKy = gpXhMekft;
        aqmTPtWsyXH /= aqmTPtWsyXH;
    }

    return wvvSMtmMohrDXTX;
}

void XZGwYagp::rBAiWRKFL(bool XAVnKHeeOhs, int RSIjviKSe, bool NYXczZwaMoQIYcOC, bool dkDxLOZXROUW)
{
    string bBQDNaaOZCSAQRy = string("mwsDTKQfnpdUJHkZIcyoNRDqHDvRSbRGcjidujgzBRetrJJokEKVbqvcrJgaRSbhXVLaemOlyeIiQRFdHxIJBdfwIys");

    for (int NkeiBJedZkfF = 190159886; NkeiBJedZkfF > 0; NkeiBJedZkfF--) {
        dkDxLOZXROUW = ! dkDxLOZXROUW;
        RSIjviKSe -= RSIjviKSe;
        NYXczZwaMoQIYcOC = ! XAVnKHeeOhs;
        XAVnKHeeOhs = ! NYXczZwaMoQIYcOC;
        XAVnKHeeOhs = XAVnKHeeOhs;
    }
}

double XZGwYagp::VeRsaMBSxqDfnkLX(double HsATBQtnpaVvWAe, double FDdNJ, string ocoltADN, bool pzACjaXJB, bool pQfkaRFNE)
{
    string dtLDuq = string("PQfHvHojkQZcykhPuvWfWjCaLxmJyhYwGsOqBqwlQnmzMIWvibABGroxNdJuCLqHBgDyoBhHtiyzjCQKRwExNHjMsbzvwLXaNzVfjAyIvRuGkgEnvecRmrqFyCmBWKze");
    double KWsrSZ = 1001083.0216363376;
    string UVXxxxKRXorEVrBv = string("EZjkiuSXmzbAdValUBTtgmReopbyEeVRjRDsNNnrNZgXlYftJryUbZGSXefsRmDdyTcYJWNvVjwGSbCaoIXzrWjVUGeeFKLfGeAJpmyfukhpCJqarEdWpouOIelcZoiBCtYKSNynwUDsXcPmBSOJCMSMHsgJsrTMEJGFNJteUtQHoAGnbbhu");

    if (UVXxxxKRXorEVrBv != string("EZjkiuSXmzbAdValUBTtgmReopbyEeVRjRDsNNnrNZgXlYftJryUbZGSXefsRmDdyTcYJWNvVjwGSbCaoIXzrWjVUGeeFKLfGeAJpmyfukhpCJqarEdWpouOIelcZoiBCtYKSNynwUDsXcPmBSOJCMSMHsgJsrTMEJGFNJteUtQHoAGnbbhu")) {
        for (int oULpk = 1364194392; oULpk > 0; oULpk--) {
            pzACjaXJB = pQfkaRFNE;
        }
    }

    for (int ivEWLnRwSHtO = 737401109; ivEWLnRwSHtO > 0; ivEWLnRwSHtO--) {
        pQfkaRFNE = pQfkaRFNE;
    }

    return KWsrSZ;
}

bool XZGwYagp::VAlpiEXqyAoOWOeU(string ERYuglcKKqDCo, double pyqUmmfl, bool yeURrOiYlOBUnZH)
{
    bool laXzZghu = true;
    bool CNKIKeWBOujpBzC = false;
    int VWmLf = -1425162651;
    double bmaTLLJjtAnZ = -985658.5191659176;
    bool dALbDIUxzdQQtea = true;

    for (int HeVUCflsYZqgJE = 483497645; HeVUCflsYZqgJE > 0; HeVUCflsYZqgJE--) {
        ERYuglcKKqDCo += ERYuglcKKqDCo;
    }

    if (CNKIKeWBOujpBzC == true) {
        for (int njrEw = 1701586977; njrEw > 0; njrEw--) {
            laXzZghu = ! yeURrOiYlOBUnZH;
            pyqUmmfl *= bmaTLLJjtAnZ;
        }
    }

    if (pyqUmmfl > -985658.5191659176) {
        for (int MLBdDE = 1868296795; MLBdDE > 0; MLBdDE--) {
            continue;
        }
    }

    return dALbDIUxzdQQtea;
}

void XZGwYagp::IeIiHoZDn()
{
    double kgKbLAkjJ = -756595.8709063263;
    int qPuSxjBLYYnBEPg = 1174504856;

    if (qPuSxjBLYYnBEPg == 1174504856) {
        for (int gpPuAdxhOuN = 2018205474; gpPuAdxhOuN > 0; gpPuAdxhOuN--) {
            qPuSxjBLYYnBEPg = qPuSxjBLYYnBEPg;
            qPuSxjBLYYnBEPg -= qPuSxjBLYYnBEPg;
            qPuSxjBLYYnBEPg += qPuSxjBLYYnBEPg;
            qPuSxjBLYYnBEPg -= qPuSxjBLYYnBEPg;
        }
    }
}

bool XZGwYagp::AUVdX(double GzUAQigOXg, string PcSCB, bool bxFCXhMKpsHpVPzj)
{
    int HGPczbhghLuPWWE = 179842627;
    string AvJcVOZXvnvRAB = string("gPLYKfrCIpOUflFdrkgSwHtkqcpOkOJGwbKtmgjtrfVtuSXidpFbSCQrVadYAdmfIAcWJnsKpVwxUTCAZnGuhjXdmYlIynQjledlvXvtaRrCBdjAdSAoKLEnRvnkDlVRcHwVErrHqFMxYNzZgjr");
    string vJRQnc = string("e");
    double cYuzM = -186477.58818158234;

    for (int xBjTQdpxAjk = 416809495; xBjTQdpxAjk > 0; xBjTQdpxAjk--) {
        PcSCB += PcSCB;
        GzUAQigOXg /= GzUAQigOXg;
    }

    if (GzUAQigOXg < 688338.7575634122) {
        for (int WowlgplYunDq = 527952632; WowlgplYunDq > 0; WowlgplYunDq--) {
            AvJcVOZXvnvRAB += PcSCB;
            vJRQnc = vJRQnc;
            AvJcVOZXvnvRAB += PcSCB;
            bxFCXhMKpsHpVPzj = ! bxFCXhMKpsHpVPzj;
        }
    }

    for (int nfgwoYqguLImI = 822075356; nfgwoYqguLImI > 0; nfgwoYqguLImI--) {
        GzUAQigOXg += cYuzM;
        AvJcVOZXvnvRAB = PcSCB;
    }

    if (PcSCB != string("gPLYKfrCIpOUflFdrkgSwHtkqcpOkOJGwbKtmgjtrfVtuSXidpFbSCQrVadYAdmfIAcWJnsKpVwxUTCAZnGuhjXdmYlIynQjledlvXvtaRrCBdjAdSAoKLEnRvnkDlVRcHwVErrHqFMxYNzZgjr")) {
        for (int IMRjh = 2107517422; IMRjh > 0; IMRjh--) {
            vJRQnc = AvJcVOZXvnvRAB;
        }
    }

    for (int AbguvCYkbZNGun = 89161814; AbguvCYkbZNGun > 0; AbguvCYkbZNGun--) {
        AvJcVOZXvnvRAB += vJRQnc;
    }

    return bxFCXhMKpsHpVPzj;
}

double XZGwYagp::WCYqDHqKHSJk(string vwCvwZZmWthfS, int SLNzYSDdaZN, bool tponbtbfuckulHv, string fNOEFozGzjIzEYM)
{
    string amCwgJcw = string("nOFPqduBQazHUTCrbGOSdGjCCTKHCRhUZZPoVsBenhCSiYJOYeZLhxaEbYRwIpywhVtYIGrDdyxdlHLZEDRvSKJqModVnlaRzApAqEMHIBOYbzMRgMYLwcusIFGAFlSKViJSxKSQEFhhTJyOdjdoUNnKgUAAJWPlwwlVPdKsVyDiYGWZJCSlhwLGjyifDhWhUPxlsSVwNlIYPrnqrWGA");
    bool fFZwUwYGZuxVIr = true;
    double roPwFlKVOwK = 626489.0731621248;
    string nWBTKsYmuiKwObox = string("UKybqYvcesIKHAREgCtdaRXZEdzWwOkwyTRmIMhShFWvxLLBuWWihAeLeBABAzjQPzlYRJnHnRfvxfrtzRkyFABnRkmmgfMfOzGRmyzAxkdBExiJzYwItOOPoprsDAvrd");
    bool WtOXyhBCdJpdEv = true;
    double NXUgHWMLmewb = 15179.768025407004;
    int fATDH = 528272783;

    for (int xyrxdEGWSd = 1082617710; xyrxdEGWSd > 0; xyrxdEGWSd--) {
        roPwFlKVOwK -= roPwFlKVOwK;
    }

    return NXUgHWMLmewb;
}

int XZGwYagp::CwOWRp(double tHjwfCqh)
{
    double sTVPY = -558303.3071516674;
    double lWpPyKhJbgRVFexp = -854327.994906966;
    string HfRGVQhxI = string("JHbrZbHcmPjUaArgaWHEkSmVuNCyYkRAleXAUFkPuvqiTKnZbuTkXwqzLCuqNMtOatNJFOUObOvwKvgKifSbknkYampUgrgMIhawaXqUzWAjGBpsrUrITPxeALTREjULQMgqjkRmSXcTMmWoaj");
    string LUczvMFX = string("iTkhwLyNCHQSwZpKqSrjZBBwFebmMxKvugOaqnPgyMqbUXvSXvYnroLCpsuqjAERbkjmpmtfDGakuBNowXIoFHUJLgWxHdIqQbqcshtMJjnrkLMrMjsCVZMBdZfvtbhZJJaTaETLmOVYmlTVuwKOENGqdvRwOOObfgHAFjmUMXIxVuNZLxqYCWQOeAVSEmtkiXAoWsiQLdGExDstFipYldEvUDdscKulPPopdqLnkcg");

    return -1841382179;
}

XZGwYagp::XZGwYagp()
{
    this->mwATn(-62986.70818659781, -205156089);
    this->bbguFWtdRgsvOSjQ(string("bqhUUJsgAncDkvMwzlP"), false, false, 1377019361);
    this->HRQEMDUqQ(-937572.2632545833);
    this->EoFHSKcZRgCEwJB(string("TXyAtvppiVEyuGBRqCYMoCmmMgKjaXprOaxuQMhZyiowxxdiZspMbAfYeccusBHMsULDVoOLGp"), -1027254.6211807274);
    this->rBAiWRKFL(true, 525890521, true, false);
    this->VeRsaMBSxqDfnkLX(833552.6924355085, -502976.69607575453, string("UjHYLuyztMfGNzaabrSqwFTGuuPYmgiadPMmeJcfyiHFYhIllsswFHHDwKSqPISSJPzrocEqEMzixmAIAQMWBCbiiotriN"), true, false);
    this->VAlpiEXqyAoOWOeU(string("JnHmRnFmInTcBxbpixIOCEQWEQmtwfRaWQuDJTEEqNIbowHFkNhtuQApmuFKyPtzYooTKoEOXeCUgjrukTUxvpstdljGCAxHegfCSkFGCOlnl"), -1028336.5762040791, true);
    this->IeIiHoZDn();
    this->AUVdX(688338.7575634122, string("zlDWoXwyRXDGWZLbHSgBuCMSPWVIXknYYrEYYdPndIcxOOtsjsuWjsuPSeAMras"), true);
    this->WCYqDHqKHSJk(string("gYUfmQiZFxiFgXbAukjMqOyfPuFxqgkRQFPcDTorVszplThtDNfBfUyYAjaHfvycvmvvOriLnrKdOmNXyOPXkfZhCqyOlbGzEkwhRZioxoWuZrJGbQAQRfWtCFKlFsRhFhfAxSYSoVnXW"), -2027498277, true, string("ZhADSkRRwGdgmHYDGfEYvT"));
    this->CwOWRp(-1006018.3959828189);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pTpseNt
{
public:
    double HvjLqmi;

    pTpseNt();
    bool onzJtev(bool kKSdJMuSPC);
    string YzBtPbjuPVgpa(bool rCzmf, string njsjDrn, double zaPsOJt, string XYpNYvZr);
    double CVSqk(double gwGpzlakX, string kNTyfOHurCnVjTj, string hRiCOyzI, bool HoiBivigBXzGc, string JEczHT);
    bool OcFor(bool XJPNwfiKvzcrmr, double PiagoVhqrkoIb, int XGwWXKmdcTnXM, string bruxHdgEwLgWjLf, string vDiVIvzTUFMfMuf);
    double jRnLWBXABQe(double MewjzsU);
    double vtaeXAYLSTIySN(int vAsiWcOJMxqsk, int FCzjmXQVKVV, string AylItLmI, int dpWSH, int PHkXnTjvESS);
    double wdIxwnaVNQus(double jtCGIRpMoagCzd, string QGxvwMadSejj);
protected:
    bool rDxCmbS;

    void tRmRlhMlQp();
    string YCTml();
    double jpzhU(string NgIcWDwsFcb, bool akgApI, double YPEtTJwvNXnH, bool bTobNL);
private:
    string RESiHXMVSFdUWIO;

    string jajJBMB(bool ArdKuiDzvMaY, int cXordT, int fwxqtduO, bool gsJOjIDb);
    string hUKSOVJDSFIHVWP(bool TgJtOkfdwWrTCS, string hiTOBKGuiDoOq, int ePoovlsoVggUSy);
    double knVOMsym(string aFhtlnDQIMAhf, string LskmUCQHjcQAdzKt, bool uwXif, double EwBjiZKr, int zgoRIWFbPavw);
    bool GgEyzUcwo();
    string WqXVqdhJkCY(double MXszGUTxSWMNH, int QxOWvFXT, string EyqAELYB);
    void zuniOCr();
};

bool pTpseNt::onzJtev(bool kKSdJMuSPC)
{
    double kNislbDTPrtsyAsq = -791976.616227697;
    string wOdknrBYHnyYyY = string("AZADiLeCcXuQuosgJrvbADjLVJvgveiKUFqJhollRwBCxkvRjLqSUIItkeZLPaGixiWBQbZTEtmfJWGj");
    bool yTyUZBOQiug = false;
    bool CPBRGXNGQmmkmKwc = false;
    double wXhgAyrvN = -362006.37505001423;
    double WCOcjIGyYWO = 485443.0433995143;
    bool iVFWMatipEOuaQa = true;
    string JSTQpnBSxvHrMx = string("HSVqruRUfGzLXyhxygjLHkeVxiuGTHZUKLHgyjZJkQTMZ");
    double fMeoGdMnoYRZFJv = -535059.5019118247;
    string UyobNp = string("NUasukShzrYlzbDDRzycEfzNymOISqcSfuDwbJzStUjQYuLHXUTYnRmlBsqFsedZYDoZjWYgQlradqRiNaBPXQCbrdaCFNoPRvFVZUZEyQqixnQaBEducQcPuQIbcJictGCzgNSRlCAaXVFlbTJsCXoaAnZyhsksEQmFunDzyLtfZtwZkkkLSnsKmwYHMsQLPHPhtCnEqiBLkOOXGIdYZZtxxqlwRcBYfwOnOa");

    if (UyobNp >= string("HSVqruRUfGzLXyhxygjLHkeVxiuGTHZUKLHgyjZJkQTMZ")) {
        for (int UOrezVvTSZav = 907044121; UOrezVvTSZav > 0; UOrezVvTSZav--) {
            continue;
        }
    }

    for (int yUKJDtrm = 544612686; yUKJDtrm > 0; yUKJDtrm--) {
        continue;
    }

    for (int TcQaC = 1444373371; TcQaC > 0; TcQaC--) {
        fMeoGdMnoYRZFJv *= fMeoGdMnoYRZFJv;
        fMeoGdMnoYRZFJv = fMeoGdMnoYRZFJv;
        WCOcjIGyYWO = wXhgAyrvN;
    }

    if (wXhgAyrvN != -791976.616227697) {
        for (int jtkTCjWglGmP = 408649079; jtkTCjWglGmP > 0; jtkTCjWglGmP--) {
            continue;
        }
    }

    return iVFWMatipEOuaQa;
}

string pTpseNt::YzBtPbjuPVgpa(bool rCzmf, string njsjDrn, double zaPsOJt, string XYpNYvZr)
{
    bool iXjVOOSNRX = true;
    int GmlPtZHLm = 1461450836;
    bool cPqsdx = true;
    string LHnKGujOoP = string("FhpELPRLtSiDhWpKniommDiolAttZjaWxFskbRquZMjCNTLYCznnmTjLPWDnEfuKzYBNjaaxQXvPYYwXbyzltpzeyUfawdkWepYwZdxMlaMPKWryNiTQDstwicTkmAOXiwvpHzGFDGPfVLzrNIBtzOvglcOTGLyetRacKAZtjEQdpiUPShXmTVFzOzWfvH");

    for (int WqiSCTwStD = 2061611523; WqiSCTwStD > 0; WqiSCTwStD--) {
        iXjVOOSNRX = rCzmf;
        rCzmf = iXjVOOSNRX;
    }

    for (int OjuqdidoNyRHmv = 1564594335; OjuqdidoNyRHmv > 0; OjuqdidoNyRHmv--) {
        LHnKGujOoP += XYpNYvZr;
    }

    return LHnKGujOoP;
}

double pTpseNt::CVSqk(double gwGpzlakX, string kNTyfOHurCnVjTj, string hRiCOyzI, bool HoiBivigBXzGc, string JEczHT)
{
    double WNHxxTjytXgI = 815538.53169922;
    bool gnjnFQvSnryz = true;
    string ObWIsJxmFq = string("wxNRVReUvFPIZhKJTCyOuCMyWzNMpOcwnCAclJHAOQxqAftwRWjjCiGqNDLYzPbQnaFbKnIxuDASVqZFBVjofUkCBlqcrkWDGousNNMxvmKCUOJYZEYwzFFgdsdvAsdPeElwypmCEMTkLhUfkChUAhfkEepQmbEgjOR");
    bool vqBJbMYzjGEN = true;
    string UgcrGZFMt = string("EgiTpqcUnlAHtWNOQsBfLLhYMnddtUwFqwqyNfHkMofDSiobCYNDnvBrxNXirozQOTscNWrfLxsOtpxwNBPATWSuTUKVT");
    double sNVsLQxsKM = 839204.7884798673;
    int ZLgWscRUezOoaeg = 2076994144;
    string HtxJEzWQnfUnQZ = string("SbLmkmBihikoMxBvLbDbcqfjDTh");

    if (kNTyfOHurCnVjTj > string("AUilooTeYuWMBPaxbckIwjLfhQdRTYBRhzLuZCrDKbwVTSPecVDtgvJGE")) {
        for (int KimXiibUNMEQfM = 477989127; KimXiibUNMEQfM > 0; KimXiibUNMEQfM--) {
            JEczHT += ObWIsJxmFq;
        }
    }

    return sNVsLQxsKM;
}

bool pTpseNt::OcFor(bool XJPNwfiKvzcrmr, double PiagoVhqrkoIb, int XGwWXKmdcTnXM, string bruxHdgEwLgWjLf, string vDiVIvzTUFMfMuf)
{
    bool VKHHqbwHOaDqdve = false;
    bool RlJlybKGdjcZHNCL = true;
    string SYZAVZiEo = string("OVmSnWwkylmefinJtOHdrLhnbsAtjRgfgyRiNYhmrmcpHuAurmAsmBFsVtJEiqPGcMCLbaZfGEiejwFmPsAI");
    double rauOdrCfdwUuK = -732754.4676030632;

    for (int EcJtaKZuD = 1720813094; EcJtaKZuD > 0; EcJtaKZuD--) {
        continue;
    }

    for (int JOSTkBKfzSt = 332668787; JOSTkBKfzSt > 0; JOSTkBKfzSt--) {
        SYZAVZiEo = bruxHdgEwLgWjLf;
    }

    return RlJlybKGdjcZHNCL;
}

double pTpseNt::jRnLWBXABQe(double MewjzsU)
{
    double WmvagkYfsXwIcFo = -829392.4466409861;
    string lfANrhcm = string("uwTrgugBFDdMXZnvySZNPDOpvPoyItCORkbMDQyNMGIrwGYwWjpNpKgosReEaEDAoLRwcIBcbRguFQXCxJOsvVClNCmRfWxcyizYcneLuVdkZqKnidQM");
    string MAlLACKYVztTQW = string("oqWCaXYyVseGNSBdzXKQLwEPurtmCBgEUXfqEliGdPmGVBPJISPjeiIPCLyAcXwDZhojjrkKTYHNFxtrxCzgSlOtQGNppGdJuzRYstgQHaYHhsQCkWXOdqyQZWduNBsJaVYRJQQByZzIzZrRzpsVsBAqDbdQJfpirmEVjxUOtmtMqPWyLiwlVnVjmzsUUKoalUIrBoPYYOIiGQWzKSZWKHFzcIACYzOjvIBWxWezzPBJixjNsQCXwod");
    double zosauIiiI = 43471.8575167979;

    for (int suCQYJfIKQzObL = 1592596387; suCQYJfIKQzObL > 0; suCQYJfIKQzObL--) {
        WmvagkYfsXwIcFo += WmvagkYfsXwIcFo;
        WmvagkYfsXwIcFo /= zosauIiiI;
    }

    for (int XxgKRzDomCC = 509455990; XxgKRzDomCC > 0; XxgKRzDomCC--) {
        MewjzsU *= WmvagkYfsXwIcFo;
        WmvagkYfsXwIcFo /= WmvagkYfsXwIcFo;
        WmvagkYfsXwIcFo += WmvagkYfsXwIcFo;
        lfANrhcm = lfANrhcm;
        zosauIiiI += zosauIiiI;
        WmvagkYfsXwIcFo /= MewjzsU;
    }

    if (zosauIiiI > 43471.8575167979) {
        for (int GrAfOACcpsMGo = 182987965; GrAfOACcpsMGo > 0; GrAfOACcpsMGo--) {
            MAlLACKYVztTQW = lfANrhcm;
            MewjzsU -= zosauIiiI;
            lfANrhcm += MAlLACKYVztTQW;
        }
    }

    if (WmvagkYfsXwIcFo == 43471.8575167979) {
        for (int HAshhUvUj = 2058140108; HAshhUvUj > 0; HAshhUvUj--) {
            WmvagkYfsXwIcFo = MewjzsU;
            lfANrhcm += lfANrhcm;
            lfANrhcm += lfANrhcm;
            zosauIiiI -= MewjzsU;
            WmvagkYfsXwIcFo *= zosauIiiI;
            zosauIiiI -= WmvagkYfsXwIcFo;
            MewjzsU /= MewjzsU;
        }
    }

    for (int WQyLfXzLireiPKD = 861321920; WQyLfXzLireiPKD > 0; WQyLfXzLireiPKD--) {
        WmvagkYfsXwIcFo += WmvagkYfsXwIcFo;
        lfANrhcm = MAlLACKYVztTQW;
        lfANrhcm += lfANrhcm;
        lfANrhcm = lfANrhcm;
        zosauIiiI /= zosauIiiI;
    }

    return zosauIiiI;
}

double pTpseNt::vtaeXAYLSTIySN(int vAsiWcOJMxqsk, int FCzjmXQVKVV, string AylItLmI, int dpWSH, int PHkXnTjvESS)
{
    double GebRtUotcVtL = 561805.2794867912;
    bool ZxNAAsyTEGQzE = false;
    bool CuScAOVAWyyQRea = true;
    int wGgXsccNNWYi = 2116707981;

    for (int pwMdKQ = 873430592; pwMdKQ > 0; pwMdKQ--) {
        vAsiWcOJMxqsk += vAsiWcOJMxqsk;
    }

    if (dpWSH != 126872259) {
        for (int IQhZzkTheueBrmJ = 1749274696; IQhZzkTheueBrmJ > 0; IQhZzkTheueBrmJ--) {
            dpWSH *= FCzjmXQVKVV;
            FCzjmXQVKVV = wGgXsccNNWYi;
            vAsiWcOJMxqsk += PHkXnTjvESS;
            PHkXnTjvESS *= PHkXnTjvESS;
        }
    }

    for (int wgaJYdeDkhdSxbis = 608624380; wgaJYdeDkhdSxbis > 0; wgaJYdeDkhdSxbis--) {
        dpWSH = FCzjmXQVKVV;
        dpWSH = wGgXsccNNWYi;
        dpWSH += vAsiWcOJMxqsk;
        AylItLmI += AylItLmI;
    }

    if (dpWSH >= -1312627120) {
        for (int ZgFtZroqTnZd = 1809392918; ZgFtZroqTnZd > 0; ZgFtZroqTnZd--) {
            wGgXsccNNWYi = PHkXnTjvESS;
            vAsiWcOJMxqsk -= wGgXsccNNWYi;
        }
    }

    if (PHkXnTjvESS >= -1511383661) {
        for (int LIJjSqXeulJ = 1571346713; LIJjSqXeulJ > 0; LIJjSqXeulJ--) {
            AylItLmI += AylItLmI;
        }
    }

    if (dpWSH != -1312627120) {
        for (int lAFGQ = 487899784; lAFGQ > 0; lAFGQ--) {
            continue;
        }
    }

    if (wGgXsccNNWYi <= 126872259) {
        for (int rksStMPoaoPqE = 547718060; rksStMPoaoPqE > 0; rksStMPoaoPqE--) {
            PHkXnTjvESS *= PHkXnTjvESS;
        }
    }

    return GebRtUotcVtL;
}

double pTpseNt::wdIxwnaVNQus(double jtCGIRpMoagCzd, string QGxvwMadSejj)
{
    double rTWhDSxnQIJ = 216435.42238705716;
    string SGPobbIDTpNI = string("dZYCffOjFFuicwGdwOJGcJzVpPSQDeiDvtcRUPxtGhtCZhtASnuSXxCDEAIdvdBaeAPyJNmybrppOZlCxdchvf");
    bool rTaUQqEzq = true;
    string CwpMjFpCXP = string("ubnyAXEskFYsAawCTWiYGYmilZqHcweLCEQdyypqgKdgcffrHIZTtHGrnHARVnImjPWetldEQrZMuuwLChCIVpvEADSWtGrrvjsP");
    bool ZlUXHucR = true;

    if (rTaUQqEzq == true) {
        for (int DLEVmr = 2010811589; DLEVmr > 0; DLEVmr--) {
            SGPobbIDTpNI += QGxvwMadSejj;
        }
    }

    for (int PJUxkicXk = 2042605389; PJUxkicXk > 0; PJUxkicXk--) {
        QGxvwMadSejj = SGPobbIDTpNI;
        SGPobbIDTpNI = SGPobbIDTpNI;
        CwpMjFpCXP += QGxvwMadSejj;
        SGPobbIDTpNI = SGPobbIDTpNI;
        jtCGIRpMoagCzd /= rTWhDSxnQIJ;
    }

    return rTWhDSxnQIJ;
}

void pTpseNt::tRmRlhMlQp()
{
    bool guluO = true;
    bool SdljWj = false;
    double sztgtuqmiF = 381201.7169416774;
    double sGGag = -831906.7944146271;
    bool ZOZwFRxj = true;
    string FviwG = string("YTmUBOCVlZwJFWqOnyrBhOMfcxuncqcblyFGyjRnYXPsrnikhrwhJsk");
    string nTzVrmTRKqsbOs = string("LpqDNdzAeHGhNslUBVhGwAMqInisfUDhcABxxSpeRxjQtBvcMYMSAgPgWkQrMRKkhDYpsHKngpWSzEdnGqxKGCaPZStRTFsWTaVJevAQXCPJLsHPHjHkhdSerGzXncngudycFAUlvRGBswZHVeBjjLSFjYNQNZkWymISTQICcpGikADbSvWjQowQJEpsWIkAXwpqGhwZzVfGvUGgpjsdxTLFaWYimbakZdRIcyuEaqpZcVAyzdMxVxCJxLp");
    string ytqLmtaFF = string("dopWPjcpAYUWBBQwyJHRyYJrDvMmhNbqbuwkaTuZVxTxPrWCAw");

    for (int gScEQ = 337712253; gScEQ > 0; gScEQ--) {
        SdljWj = ZOZwFRxj;
    }
}

string pTpseNt::YCTml()
{
    bool cPzfv = true;
    bool kERJbEwR = true;
    double XAmeDddWFfH = -471457.7570007473;
    string nGDcMTm = string("LxNMWgGlNbdHgHkTOBRUaGkoXArLSdfOdFVMtIGkePthqeplPumxQPshQicePUBuxkH");
    double BAffqBczvHTKB = -38417.0373442492;
    string IDjnhuErobnqbF = string("fCSQzLswvBghRRSoIUaeZTjciWrHnmPEMEHctDLCmGFHQoygqRCqQUPGSxyYtWSQKRelhHFIVSuoGXHARISNhczUaXPpoADNWtGvUqtvQVkVeZLOi");
    string VKVXbUqRK = string("eFGnfNgHgXvMYyvqjUCBbEKTEtLgnvoliFyTbTQDKkaozjqmCvFGPwknFIEUvApOFrDjbptxoWWnBpAKrTZeeoZUpstztHQqJzyIwcylmdwsNgppJagBRMkdPHXNprLYiRDBJYeEbNtgzUzNiLTbWdDgLmhdIlXtYMaMueHoETXAJmQeoXOLezwBwtLoRjLhclLOtRsitewjTOzRlxqlGKvgYKbmZjoAhCRLzoCTyziOBiTeOjGVet");
    string kkEIv = string("mmYNGjzJwmazPZfMtSgWjfnorMQTlbpHPIwAVvzxHWSxdDlceLYmkAkrwmJHuZgfxExaskotsXsMSDXTOadjNRDgzfFzJSwRBlnnzyYflockfkqxmmntheDNuhWCMjcpPgvpHVTtINzojGTSZfRqWnfkdYLUocbdGDIjNgtlZZrBoHmQyTDubeDr");
    double PbghgjG = 841189.1239326738;

    for (int DOMNbIZDKkqf = 1609498799; DOMNbIZDKkqf > 0; DOMNbIZDKkqf--) {
        VKVXbUqRK += IDjnhuErobnqbF;
        nGDcMTm = kkEIv;
        kkEIv = VKVXbUqRK;
        kkEIv = IDjnhuErobnqbF;
        nGDcMTm = kkEIv;
    }

    if (VKVXbUqRK > string("eFGnfNgHgXvMYyvqjUCBbEKTEtLgnvoliFyTbTQDKkaozjqmCvFGPwknFIEUvApOFrDjbptxoWWnBpAKrTZeeoZUpstztHQqJzyIwcylmdwsNgppJagBRMkdPHXNprLYiRDBJYeEbNtgzUzNiLTbWdDgLmhdIlXtYMaMueHoETXAJmQeoXOLezwBwtLoRjLhclLOtRsitewjTOzRlxqlGKvgYKbmZjoAhCRLzoCTyziOBiTeOjGVet")) {
        for (int uujdp = 841135945; uujdp > 0; uujdp--) {
            BAffqBczvHTKB *= PbghgjG;
            kkEIv += IDjnhuErobnqbF;
            kkEIv = kkEIv;
        }
    }

    if (kkEIv < string("LxNMWgGlNbdHgHkTOBRUaGkoXArLSdfOdFVMtIGkePthqeplPumxQPshQicePUBuxkH")) {
        for (int GijHmBRGOTAnh = 1086430063; GijHmBRGOTAnh > 0; GijHmBRGOTAnh--) {
            kkEIv = kkEIv;
            nGDcMTm = nGDcMTm;
        }
    }

    return kkEIv;
}

double pTpseNt::jpzhU(string NgIcWDwsFcb, bool akgApI, double YPEtTJwvNXnH, bool bTobNL)
{
    bool MxYUY = true;
    bool LtoZdqctMmdpnxyM = false;
    int vyQjdcvg = 1539436857;
    string tqlrW = string("vuyBnpQVbWIJTQtqejqzZCTWGWlDUSIUCSQyyUTMEVFEAIlYMRxnWWNxTmVXuIHRQjZQPaafgBnTvEbwdbDrAebryoCFDTDANPxkMYpTXdsxKFuGPIiiJuQXFeNEZRZGCTglfSHnonIFNgHlbQUDmJYSRdyPllSLGvAjJhKezxrqsLrV");
    double rqFMhxEymy = -641309.1081573119;
    bool RCcpFQuWae = true;
    string IuXNMmFe = string("AaOQzkjXrvJDoPUVvqRLeFvBpKqldHudmMdPHusWuEWhZJIGTZtEXgWuXlgyaOYmLlTEidQWBwmCqrfDNDqqguLzZTStcWNJdebegfCrAvzecIdKPiQsYqlLjjgieKfQbPzfrZlsDrvQoTzXOxvrEhzaJgSsJNYCTsNEWISXPHHgtIUGQiRyNdHgWIhBIlDfJKNKiLfKn");
    double KqBTQZsligQZOjzp = -547141.9548578112;
    string uZzNpF = string("tSaaJXDGduFCPbBtdoYkQfDbcmNlgobqEqMViktgs");

    if (NgIcWDwsFcb <= string("AaOQzkjXrvJDoPUVvqRLeFvBpKqldHudmMdPHusWuEWhZJIGTZtEXgWuXlgyaOYmLlTEidQWBwmCqrfDNDqqguLzZTStcWNJdebegfCrAvzecIdKPiQsYqlLjjgieKfQbPzfrZlsDrvQoTzXOxvrEhzaJgSsJNYCTsNEWISXPHHgtIUGQiRyNdHgWIhBIlDfJKNKiLfKn")) {
        for (int OzivayKdXj = 487989652; OzivayKdXj > 0; OzivayKdXj--) {
            KqBTQZsligQZOjzp = YPEtTJwvNXnH;
            uZzNpF += IuXNMmFe;
            bTobNL = RCcpFQuWae;
        }
    }

    for (int tImBAvJKIo = 125381415; tImBAvJKIo > 0; tImBAvJKIo--) {
        akgApI = MxYUY;
        NgIcWDwsFcb += IuXNMmFe;
    }

    return KqBTQZsligQZOjzp;
}

string pTpseNt::jajJBMB(bool ArdKuiDzvMaY, int cXordT, int fwxqtduO, bool gsJOjIDb)
{
    int gkoUeELGgly = 884947108;
    int AffhpaKeVLjMfSf = 1973390491;
    bool DeKUDgMuO = false;
    int DZGQQFxG = -826388128;
    bool owxokoMMgK = false;
    bool AsyziEmy = false;
    double PPyFAZNAX = -255373.95373472816;
    bool BoKkezrXJxMjFecy = false;
    string NucsHBqfugdcE = string("eLzoNcnykNXQqRTqcUtKiDWycCbE");
    bool lBQSVFhkfzCEphCf = false;

    return NucsHBqfugdcE;
}

string pTpseNt::hUKSOVJDSFIHVWP(bool TgJtOkfdwWrTCS, string hiTOBKGuiDoOq, int ePoovlsoVggUSy)
{
    bool sCbzDpULRJzgz = true;
    double DoGLICEKDWN = 662347.4060162468;
    string YljGQWJAWeNC = string("kZpiiHaHKaSlHfVuPjUqnaLKhveownyBKEPbhsLpSeCpBzzGXTRLLBxQRwjqNjIstgdysyvHAiduRYCLDfChAVMYFvPZScMTfnizyDUdHLOXqQE");
    int UHkGXhUJmDXOsWNH = -1718995006;
    double liaUOWORphN = 200746.3769697844;
    string cmMnMghWRH = string("CjGSBrXHmjPVKWJLsZpMVMpUExGsZSjMepnsNlChUmRXYyXAcIyASSLtvisnHNWUJf");
    double gsOyWTtlZdpD = 860925.146291992;
    int ZzQwhvvJdYeM = 658254996;
    string syTBH = string("RcEFLAKpCPmqrMyGEUNrshxOkmkQlFQRRdtRSBRijwWQPVWAMZnPAXlhucgBmJkxYxpweUlZntHtXEDujFMYsAOgztgHDNGDUfLMopJpMijjfmK");
    bool xydeYg = false;

    if (ePoovlsoVggUSy < 938763505) {
        for (int FgAeWlGjl = 1533029439; FgAeWlGjl > 0; FgAeWlGjl--) {
            gsOyWTtlZdpD = liaUOWORphN;
        }
    }

    for (int tYGuuksWPqZbx = 362283884; tYGuuksWPqZbx > 0; tYGuuksWPqZbx--) {
        continue;
    }

    for (int kPUmt = 723575895; kPUmt > 0; kPUmt--) {
        ZzQwhvvJdYeM /= ZzQwhvvJdYeM;
        syTBH += YljGQWJAWeNC;
        hiTOBKGuiDoOq = YljGQWJAWeNC;
    }

    for (int yhaohExlVVLm = 135739799; yhaohExlVVLm > 0; yhaohExlVVLm--) {
        ePoovlsoVggUSy = ZzQwhvvJdYeM;
        gsOyWTtlZdpD *= gsOyWTtlZdpD;
        sCbzDpULRJzgz = ! xydeYg;
        cmMnMghWRH += hiTOBKGuiDoOq;
    }

    if (syTBH > string("YVBetlegrWZLZOTyKofBFpdUZNNklzIMJVkEnfXWSBQfiPCDVOdtahwaGgcHmRtmKxKqJpLPBKkiiVmLGFiciEXtPMwimLRnswzVDglygFyLTcSyvIEBZhbhkuVOHfVlahsRgGpvGjkurb")) {
        for (int pfUmR = 592947601; pfUmR > 0; pfUmR--) {
            YljGQWJAWeNC = cmMnMghWRH;
        }
    }

    if (ZzQwhvvJdYeM < -1718995006) {
        for (int fvlah = 1482851313; fvlah > 0; fvlah--) {
            TgJtOkfdwWrTCS = xydeYg;
            sCbzDpULRJzgz = ! xydeYg;
        }
    }

    return syTBH;
}

double pTpseNt::knVOMsym(string aFhtlnDQIMAhf, string LskmUCQHjcQAdzKt, bool uwXif, double EwBjiZKr, int zgoRIWFbPavw)
{
    string SRIOg = string("hwqASbDEBdhdIVeMVtkxwsoSWUqLrQgzbLslatFEBiUiwTNhOEJLlqCkyujqQjVTwQJlzIucmaJmHMSDMVCbRjNnMsKOqahLMGcnFjNifxinJWgAARPvfNGrwkpyfRuReGdLUpudVkvHInahSGhVMGKJXxdRMAsmpgWSiyuOSM");
    double mkveXBnsbC = 824033.4429363547;
    int otkUM = 210903470;

    for (int HokHcuNUNPdOhpgE = 1402970248; HokHcuNUNPdOhpgE > 0; HokHcuNUNPdOhpgE--) {
        otkUM += otkUM;
        zgoRIWFbPavw += otkUM;
        zgoRIWFbPavw *= zgoRIWFbPavw;
        aFhtlnDQIMAhf += SRIOg;
    }

    for (int ipWqpKu = 858199821; ipWqpKu > 0; ipWqpKu--) {
        zgoRIWFbPavw *= zgoRIWFbPavw;
    }

    for (int VWTQjcy = 681232763; VWTQjcy > 0; VWTQjcy--) {
        continue;
    }

    return mkveXBnsbC;
}

bool pTpseNt::GgEyzUcwo()
{
    double agGGHDWTdpoOAJ = 913285.2911421735;
    int kOoGJNBRaxahEgLZ = 1856232429;
    int xTCrCcKMVJe = 2076520169;
    bool ReDayDzzq = true;
    string CBbmVoUPvXDPhO = string("zaZizQSyyySHOCnrbwOZGHxfitUffGROQcZQpTjKdNdlGgtnEKlvIAPtaeuPJYZxGwTzEaWTmPaHiJywqBiqkGYHptIPvYoTLwnSOPpHTCtymOQbNyNdrPbzfdGyyxy");

    if (xTCrCcKMVJe <= 2076520169) {
        for (int vVGydcXJSAg = 682143752; vVGydcXJSAg > 0; vVGydcXJSAg--) {
            ReDayDzzq = ReDayDzzq;
            CBbmVoUPvXDPhO += CBbmVoUPvXDPhO;
            CBbmVoUPvXDPhO += CBbmVoUPvXDPhO;
            agGGHDWTdpoOAJ += agGGHDWTdpoOAJ;
            kOoGJNBRaxahEgLZ *= xTCrCcKMVJe;
            ReDayDzzq = ! ReDayDzzq;
        }
    }

    return ReDayDzzq;
}

string pTpseNt::WqXVqdhJkCY(double MXszGUTxSWMNH, int QxOWvFXT, string EyqAELYB)
{
    string QPlmRgxogesP = string("AlSyjYLryavDOzxJnTTufFEbyJNpWxFvFotwdYNjccEzkxDFQFZMXeyZvUrTGqdyWrzotfZjfVnTQpyytlaJAiAygMXetiKowzeWhhdYwFxIuwEkTwJNDanSgeBwLAfNeG");
    double omHqpCHStV = 61941.785037924295;
    double aUmCuvFQulHPRVJ = -720786.5157294669;
    double KpmYBHAlKtmDzGPK = -36163.591889560535;
    bool psYPQjtEMeZEjWq = true;
    string XscPSOjeyj = string("VKZBThDjUxCpFMEHLzEdfdPcWVaDlEbVPzYniTyxFelwKsqSxellNdgqgreklsAzoBEpNRh");
    int XOkDbvxsoPUMvG = -374626029;

    if (QPlmRgxogesP != string("AlSyjYLryavDOzxJnTTufFEbyJNpWxFvFotwdYNjccEzkxDFQFZMXeyZvUrTGqdyWrzotfZjfVnTQpyytlaJAiAygMXetiKowzeWhhdYwFxIuwEkTwJNDanSgeBwLAfNeG")) {
        for (int CPspkfEhbCxgm = 1907793276; CPspkfEhbCxgm > 0; CPspkfEhbCxgm--) {
            continue;
        }
    }

    if (aUmCuvFQulHPRVJ >= -736766.1224288398) {
        for (int LhpScCU = 675257731; LhpScCU > 0; LhpScCU--) {
            QPlmRgxogesP += XscPSOjeyj;
        }
    }

    for (int aKfpxvDNGjUEbs = 1546715468; aKfpxvDNGjUEbs > 0; aKfpxvDNGjUEbs--) {
        QxOWvFXT -= XOkDbvxsoPUMvG;
    }

    return XscPSOjeyj;
}

void pTpseNt::zuniOCr()
{
    int TSPveZmQexgaSM = -540469281;
    string pdzScmlTIZFdf = string("zGjQSoKvyXluXVFBH");
    int OusdkwJICaYVW = -2020589388;
    string acASXRIfOQhKERpa = string("zQHhCnwvHNFhbULJoZinUIxpRXbvDrxxQzgrkkagCTOlCbqilzFERHxyTurQDdyZCUgcASUOWmrIFuWAYjGHsYIYLmUbbeFeGCzzYBwvvrMKPAjzoddNjBGEvfgMatgMSVMPNAuKqDkLPyPshUmMVlJvGuHFFwWWfvwUDiUrXOaQGvLcsvMyd");
    bool JrmlzDHgufL = true;
    bool ndwmPFzcs = false;
    string cUbMQhrQL = string("eWEzMGMREZiYTXByPLrXBkncQFojDStjlOSXuRbpWvMOqyGURMFQbjvhPGsPnNsUQnEikeuZH");

    for (int OdsFLOgLelCE = 888740206; OdsFLOgLelCE > 0; OdsFLOgLelCE--) {
        ndwmPFzcs = JrmlzDHgufL;
    }

    for (int VqiwTavs = 263318555; VqiwTavs > 0; VqiwTavs--) {
        ndwmPFzcs = ndwmPFzcs;
        pdzScmlTIZFdf = cUbMQhrQL;
    }

    if (acASXRIfOQhKERpa != string("eWEzMGMREZiYTXByPLrXBkncQFojDStjlOSXuRbpWvMOqyGURMFQbjvhPGsPnNsUQnEikeuZH")) {
        for (int mDDPWmWEsGFA = 1361127621; mDDPWmWEsGFA > 0; mDDPWmWEsGFA--) {
            acASXRIfOQhKERpa = pdzScmlTIZFdf;
        }
    }
}

pTpseNt::pTpseNt()
{
    this->onzJtev(true);
    this->YzBtPbjuPVgpa(true, string("zvidbmmZuzlvegyoeNJIJPAmKlOBiYchKSioAnoCzjLrAPutgUlPvMnkgEprjkzxyunjYPRyGdUkMlaCfZZsYEPxiKVnSZWzCqhwwVstZipzbshwOzAurwxDUzhdGNtJtdtDlYhtgHTsJwjMaXADvrECUoNIvrimgnWGZmsjhDnPyQigZDWTvjLQAPalMxZSbvhERKSfJHjZELiHzNqQZZgoeznBgvrwidyLrjHO"), 387077.1866207482, string("BZSrQtXtiOgYFaCczGwZlSAorVfscQaYstyJsJMSAIKVobtxFKBqmiCWVMApnTxzJciTdFdVEEQGQguJGBOHiweeXGXYXvTWQyazLNTgBhzEubUeaOyBSiRUoHtjfVowtvqOuOjjVegULsOLQIKDRwQefXOHwzuRJpuFgDbRVlYIwAF"));
    this->CVSqk(461164.40215380245, string("XvgdhOQECszIGCJLBJiNJmmOkriUiuVPrnqmFOEUXWqWVMdqFWQKFwCnYnuRejKxFQPUsuuzfOhFCvvIeOreg"), string("AUilooTeYuWMBPaxbckIwjLfhQdRTYBRhzLuZCrDKbwVTSPecVDtgvJGE"), false, string("z"));
    this->OcFor(false, 1036094.4342696108, 362301318, string("NhyyZMrAsdgPJktRwTPuccTrALbzUkcKyxurziDKIdalkvdhDyceRvEWYfyWdaxjeRjxosysnwmqcXzICufijMJwfUOdUALodtijAJjIhdJzjnwCAAGyqeAKZpvrDwXrP"), string("ZhBibHTQtaigLaLWKfcoQfrtzGupkFEWVHPvkBJldVVrPDKFSGgEQZJSCXHHsSYOcVzivJvxEafeJedcRVCHGuLUOAKbcNEGTvFlrwUVlwmlZqIkvYZPGkkBETeocJLOQhopoHvZs"));
    this->jRnLWBXABQe(693083.6369824834);
    this->vtaeXAYLSTIySN(1458276866, -1312627120, string("bgaDhnbhTglrPxEtOzOWivlVkGukdvanojDieocdYaknpsjXLptxYdXNeEoRQATeGfPXqTFlXYnvezcgEBgQmpWtAxjYmkVbshTgxeDXEDYabAUxYyNnXriZcCnGPqrqmlEPtotJIRvAcfCYgFCCYfDuNzwBPBhqnQxDWLILPuMVTmmHTLCTqRFbLJSYpChbPzuXFHURTLiVUxAaTD"), 126872259, -1511383661);
    this->wdIxwnaVNQus(-161287.36889020223, string("xsdQSOVelXuYSIRrseoIPEjpSLWZqhxOmlmKxMHXdwmpFKqUOclugmyoWNjXxVOoDHExoDdZkxUloFIZdcTXAgnNjPAkaKhWAQvUcdHoqqwrgasCrUQFvp"));
    this->tRmRlhMlQp();
    this->YCTml();
    this->jpzhU(string("VbPUPxYmIWOvjihgDQVhgHkPrcNTxFwLxczZYQCxJyOPsczJBSiELZWvXlSunxIgzsqaZeUs"), false, -614794.232587728, false);
    this->jajJBMB(true, -2146761211, -1928257177, false);
    this->hUKSOVJDSFIHVWP(true, string("YVBetlegrWZLZOTyKofBFpdUZNNklzIMJVkEnfXWSBQfiPCDVOdtahwaGgcHmRtmKxKqJpLPBKkiiVmLGFiciEXtPMwimLRnswzVDglygFyLTcSyvIEBZhbhkuVOHfVlahsRgGpvGjkurb"), 938763505);
    this->knVOMsym(string("oCFRnLuHVJABfnlHMMWIuwnrPlLMnXhEzsxrGVPKXYAzGrAQnDkvAKQpNWNLBRheUqFodFk"), string("cGngCebafGbJCZvBoJqDwRJmSyTdjGXcvLNcqzyyZQrZzpolJpXXafjyGArBcSXMUquTqusFk"), true, -592813.0326271622, 298875895);
    this->GgEyzUcwo();
    this->WqXVqdhJkCY(-736766.1224288398, -982791213, string("ebMecxVmTXwwDBPldrOHvkDUZNCINyIjgTFojdfhKeNtszvDHhTZKdXQFNzgQgyTBplKdtRrroSCLjEVeKxkifvWNe"));
    this->zuniOCr();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YmcwMoQVzBhMlZbQ
{
public:
    double GmLFiL;

    YmcwMoQVzBhMlZbQ();
    string mHvogKmlL(string LiXGPbSfvtp, double ILZZxI, double KoSqIPdPc, double bjShIZAqhP, int ChdjBo);
    bool EEvxkaKijRAwIe(int qXOJZBPdGtVwAHK, string BUaVuCwPSkn);
    void tZXpDrFNkFkIDEK(bool yPUWnpabJhqnEV, bool iuDSslUfbxt);
    double ujPfrqnqPcUvpZ(bool hbUQovsbfV, bool ZlLMqlGDwP);
protected:
    string jiDkXjQRUDArzclf;
    bool WGwmsW;
    int KLptXpZrj;
    string RqnSEkOEFKd;
    int kWRzshUZgCyhev;
    double dMLLMaGnwVsx;

    void WjHtiWPzYZ(int GlNAHDmDTpzuRhS, double xToOQDl, double BzKdSesIxi, bool VqMTwlDHZP, string Hfsou);
    string udEDNWbUDRJm(double ayyhZoThubkJg, string uarTNwoGGK);
    string kWFnvDBF(int IawygshpF);
    void PZorzgv(bool MBDEyfzh, int SDXRCuOURC);
    string QrhhaqEIH(int BxtiAMwTWo, bool AnugbwsaW, double nthLUORwv, double MDZde, string HUuKiGySo);
    bool PAtkDYLYMka(double FyxtuqYeiHOt, bool BNwkuHlaqZQHItD, double ifrMLtCZvJCqM);
    bool NznnFuqCWlj(bool alkzqEZroQPpnpln, double ZgbFdblGmecf, bool SmzVXeRypjM);
    bool hpeRnA(double LgfpPiIZhueXZqoq);
private:
    int FYSRXbjXnkevq;
    double pFCPSwzumlYzS;
    string kRSwVhG;
    int mbOpx;

    void wRqwHimGZ();
    int jdJgqeRP(double dTpIVndFtDTN, bool KMCMdwVvwImPEUfF, double hctOPxeIwodwSM, double YyPmkTw, bool WbIZu);
    int WStMEsvzbgmUknnO(double IrqvOiSLa);
    bool QQHSTs(int BXRkfENfJl, int gHPhlulYJFH, int wkVjqsniqTZFpt, double lcPAsVVNFJhZJHIs, bool qWJVWvOhybXvHZ);
    void JIVJdZEEDHsNJZPS();
};

string YmcwMoQVzBhMlZbQ::mHvogKmlL(string LiXGPbSfvtp, double ILZZxI, double KoSqIPdPc, double bjShIZAqhP, int ChdjBo)
{
    string uzwsMsfMCLRT = string("UZYSYVRhKvJXSRdXuJdorlgOUcTcBqmQVQcLzMxklQJeQroodBbPoTfimLdiOCafDNOxTqMtFSAqUFhJZFneCiMpsqueNWUzESFYFhkbSzJZwYvWDDKVMhVAwKXaMMzuPJVfihdUKOnoHEwpbjEJWGzVDFcMcGGlnPCtQCXdNoIAPmLbqoTXPZDGPQYiUaYqaKeCxPPQvspPyZsiDpauYqhcsyXVmyzmBzyvY");
    string wFtGoYGygpBygv = string("dkqrEixmKHOODCNHlIPeqkCJOjIlfxQLGngfXGEOEYLhBlEfBaSlS");
    bool bsvSPdWlgJWn = false;
    int ipVuPEoSOXB = -1426297588;

    for (int ajxzgIkPQcjA = 1635686706; ajxzgIkPQcjA > 0; ajxzgIkPQcjA--) {
        ChdjBo *= ChdjBo;
        bjShIZAqhP /= KoSqIPdPc;
        LiXGPbSfvtp += wFtGoYGygpBygv;
        LiXGPbSfvtp += LiXGPbSfvtp;
    }

    for (int YWVSQXeXxgJAz = 662671022; YWVSQXeXxgJAz > 0; YWVSQXeXxgJAz--) {
        uzwsMsfMCLRT += LiXGPbSfvtp;
        ILZZxI -= ILZZxI;
        uzwsMsfMCLRT = wFtGoYGygpBygv;
    }

    for (int sbyNcDUTalHoNwXk = 557292075; sbyNcDUTalHoNwXk > 0; sbyNcDUTalHoNwXk--) {
        wFtGoYGygpBygv = LiXGPbSfvtp;
        bjShIZAqhP = ILZZxI;
    }

    return wFtGoYGygpBygv;
}

bool YmcwMoQVzBhMlZbQ::EEvxkaKijRAwIe(int qXOJZBPdGtVwAHK, string BUaVuCwPSkn)
{
    int RguXX = -518677587;
    double MpARmhw = -934036.2600861443;
    bool AldafONhJodEuO = true;
    string cCOyoGiGvTVeacKA = string("mXgPJFLsdVjGTBQJVLVwUWYXgDyzfLRgAluKGmbwCvAiGzQnhVvDzzokQBJvsuwdopgwnSNmAe");
    string oqrqiibkNr = string("UDeH");
    string vyinvrsEuwaEW = string("jJOZBjIznQjCgCOunOWjPcFbeSGJynOjnrdsLLOGvknkisLtZRiZeSexFxNPtmDsDCkuaDzHKqJJaAjnbljPRhjomuZGcZPCihUqkkWntYPuacoSUZQFZsdnJwkdwzMvZAkqAKcCjXCoXpinDJbtd");
    string ivNtrNGSAIEJnpy = string("mPtffVRmwBFWwLBmEEKEOjXuFWbwofCInQunVknCQgETUzChvODbVKywUWyzapTtuZcpJBfdLyJkO");

    for (int nJfQyFJZSqnEhfP = 1684152380; nJfQyFJZSqnEhfP > 0; nJfQyFJZSqnEhfP--) {
        ivNtrNGSAIEJnpy += oqrqiibkNr;
        cCOyoGiGvTVeacKA = ivNtrNGSAIEJnpy;
        ivNtrNGSAIEJnpy += ivNtrNGSAIEJnpy;
        RguXX += qXOJZBPdGtVwAHK;
        oqrqiibkNr = BUaVuCwPSkn;
        BUaVuCwPSkn = vyinvrsEuwaEW;
        ivNtrNGSAIEJnpy += cCOyoGiGvTVeacKA;
    }

    for (int bWVOOMP = 1892444369; bWVOOMP > 0; bWVOOMP--) {
        oqrqiibkNr = oqrqiibkNr;
        ivNtrNGSAIEJnpy += vyinvrsEuwaEW;
        BUaVuCwPSkn = BUaVuCwPSkn;
        ivNtrNGSAIEJnpy = BUaVuCwPSkn;
    }

    for (int tqnyODbgceRmf = 278901551; tqnyODbgceRmf > 0; tqnyODbgceRmf--) {
        BUaVuCwPSkn += ivNtrNGSAIEJnpy;
        qXOJZBPdGtVwAHK *= qXOJZBPdGtVwAHK;
    }

    if (ivNtrNGSAIEJnpy > string("mPtffVRmwBFWwLBmEEKEOjXuFWbwofCInQunVknCQgETUzChvODbVKywUWyzapTtuZcpJBfdLyJkO")) {
        for (int suuZgtqeeUl = 1238597537; suuZgtqeeUl > 0; suuZgtqeeUl--) {
            vyinvrsEuwaEW += vyinvrsEuwaEW;
        }
    }

    if (AldafONhJodEuO != true) {
        for (int qGSDgNmJ = 828033323; qGSDgNmJ > 0; qGSDgNmJ--) {
            BUaVuCwPSkn += BUaVuCwPSkn;
            vyinvrsEuwaEW += vyinvrsEuwaEW;
            ivNtrNGSAIEJnpy = oqrqiibkNr;
        }
    }

    return AldafONhJodEuO;
}

void YmcwMoQVzBhMlZbQ::tZXpDrFNkFkIDEK(bool yPUWnpabJhqnEV, bool iuDSslUfbxt)
{
    string HGwHtzgLbMsbcEcM = string("ExgbaZBkuLJOkvjJuuDKgAZqNmbNnkICEhQgPyIUYmYkPGcHJgNsfeqRXvprMvJVktNPEQIRhARaVJPAzywmNXgBepkFKajAAQbELMhNVlMbuAuNRCQKNHrfIqjasmZfzbAtaZbxoDFpWVVbhucXOvooVHbLvokHycCvmZ");
    int vMyyIjNMu = -926962634;
    int uuPAEdofsN = 364051503;
    string otdir = string("gxGStLjGEaQsVLLqcJrHFSuqTONSPQzJeMtxzhrFnVbHBBRwsKlJyNXgOamYLukyvgxetJBwAcmjCowiXMmKxIvKLPanimJhMSIECZwaEQrLITp");
    int eymaff = 1594016358;
    double HAJGzjFaRYLwOuM = -164886.70705265936;
    int EmRXVjNRZllwRwPC = -1504749288;
    string GzCNx = string("ceIHsJqOFnwhVNyRfMaWgORb");
    int Uujew = -145423235;

    if (Uujew >= 364051503) {
        for (int KKGJZjB = 1808684746; KKGJZjB > 0; KKGJZjB--) {
            continue;
        }
    }
}

double YmcwMoQVzBhMlZbQ::ujPfrqnqPcUvpZ(bool hbUQovsbfV, bool ZlLMqlGDwP)
{
    int YdLwDfFBqjPOoQn = 1335096127;
    string VbIxBF = string("nTMcbPqoDAYoTMhvdSPWmnEvkCwRgXWRgYukiYixGypisyNavoHYziYKpsXTRqLfbJadBLdNOjSLbUhKjKXjxjymPeUyZWfdjSJdVTAbSRffxzbwjsCUqtQTCegWrOoPjjegEsVcutmFsTEQNTXUSDFntFJahesOsskZjyfaZzylEjGeXsXsVCxiDKXGMgZQyJdqxVSFUapUYUcBcZddPT");
    bool PkYOtCJbkpxL = true;

    for (int oxqcsGqsh = 2115461951; oxqcsGqsh > 0; oxqcsGqsh--) {
        ZlLMqlGDwP = ! ZlLMqlGDwP;
        PkYOtCJbkpxL = ! ZlLMqlGDwP;
    }

    if (ZlLMqlGDwP != true) {
        for (int sJBQr = 136176463; sJBQr > 0; sJBQr--) {
            hbUQovsbfV = hbUQovsbfV;
            ZlLMqlGDwP = ZlLMqlGDwP;
        }
    }

    return -931211.4190019271;
}

void YmcwMoQVzBhMlZbQ::WjHtiWPzYZ(int GlNAHDmDTpzuRhS, double xToOQDl, double BzKdSesIxi, bool VqMTwlDHZP, string Hfsou)
{
    string jmCvXZOOHS = string("RJBStgnLUyhABiaGcATXAdsJeQhZmnGoQyZYeroQEtlaqWTbxwHUgGKOVYDzvIzFIjpnxVNuZNaAWtXnEBIKKJvHlcYbIWdXDXUqYHWAKXzxbxKqEhmHFIqHttkXaRjDplYudSiJonVVFAgjaENWzIPzdGVeowaBGsvRZpRdktjsxafSTmnmfCLeHtkoncyFnaYvfjhsKbYQMmvIxhLfXZENyYGRBJhbNkxfDHq");
    string xAYBKL = string("PhgCdyTEjgvvkkgBBUetdWNoszdPEfDGZWTJffYsoZHfCSifRiCMsmUgZaUlrsBvwTIrKYymdtUQLYpKcDKDjamnzWJmUYrNSjwsNrChQCXWNkiBoPIQLUv");

    for (int ERUQPuqZNdGEvotp = 1561392062; ERUQPuqZNdGEvotp > 0; ERUQPuqZNdGEvotp--) {
        continue;
    }

    for (int Hhridv = 1450742283; Hhridv > 0; Hhridv--) {
        GlNAHDmDTpzuRhS *= GlNAHDmDTpzuRhS;
        BzKdSesIxi -= BzKdSesIxi;
    }

    if (jmCvXZOOHS >= string("PhgCdyTEjgvvkkgBBUetdWNoszdPEfDGZWTJffYsoZHfCSifRiCMsmUgZaUlrsBvwTIrKYymdtUQLYpKcDKDjamnzWJmUYrNSjwsNrChQCXWNkiBoPIQLUv")) {
        for (int jNZSoDSpPtJIM = 905536683; jNZSoDSpPtJIM > 0; jNZSoDSpPtJIM--) {
            xToOQDl /= BzKdSesIxi;
        }
    }

    for (int HZqhqGClDBZCpZr = 2141117178; HZqhqGClDBZCpZr > 0; HZqhqGClDBZCpZr--) {
        jmCvXZOOHS = jmCvXZOOHS;
    }
}

string YmcwMoQVzBhMlZbQ::udEDNWbUDRJm(double ayyhZoThubkJg, string uarTNwoGGK)
{
    bool YLAVeG = true;
    int nJbYltZON = -595355608;

    for (int uAUmgxt = 1308606129; uAUmgxt > 0; uAUmgxt--) {
        YLAVeG = YLAVeG;
    }

    for (int kKzzVKEn = 1940818497; kKzzVKEn > 0; kKzzVKEn--) {
        uarTNwoGGK += uarTNwoGGK;
        uarTNwoGGK += uarTNwoGGK;
    }

    if (uarTNwoGGK >= string("TvYayTg")) {
        for (int TKtRtujS = 1165419899; TKtRtujS > 0; TKtRtujS--) {
            continue;
        }
    }

    for (int oGjCUJmB = 2031408022; oGjCUJmB > 0; oGjCUJmB--) {
        uarTNwoGGK += uarTNwoGGK;
        ayyhZoThubkJg -= ayyhZoThubkJg;
    }

    for (int GGAhHfXCf = 632578487; GGAhHfXCf > 0; GGAhHfXCf--) {
        continue;
    }

    for (int gcofwBYoWFt = 255036546; gcofwBYoWFt > 0; gcofwBYoWFt--) {
        ayyhZoThubkJg -= ayyhZoThubkJg;
        uarTNwoGGK += uarTNwoGGK;
        YLAVeG = ! YLAVeG;
        ayyhZoThubkJg /= ayyhZoThubkJg;
    }

    for (int bWBqENDEdaa = 1493307547; bWBqENDEdaa > 0; bWBqENDEdaa--) {
        YLAVeG = YLAVeG;
    }

    return uarTNwoGGK;
}

string YmcwMoQVzBhMlZbQ::kWFnvDBF(int IawygshpF)
{
    bool KRtnREPQJiZAQA = false;
    string GkgrcWalD = string("ahWKOaFewgHeTLCyRBGWFASMUxgcbJNeVChBEfqJUiqUJVryBWunQ");
    string vIpPZCvxg = string("gYSzVkeimFXwoaraDznzfatyMiohpbTIBVUvsqaTSEssijBSgrVCvPqhBkTokgblqmIbkmysPmfUkYRaNAbeRswVrNgcdTAhNWYhYCPXhz");
    int NPofjjfzgxRngn = 43348047;
    double BfhRg = 740379.8556791643;
    bool AoTguorqRxNLFBx = true;
    double WApkCCBTYlUEqOxC = 846518.5305670354;
    string IvwvkeXhrFGToz = string("dzbetEiLlImSWYadczpryLigevfbKuhBbLDmVEkeqHZnqamUQxnZnPSwqkFgECygxzkUlZKSDVOFTcKtdxGIPxGBTveAxOenrikwDazTvKenIeKfXOmduJNwppijxzEXKfigMXNDwgnhJrhDLjipawdjheRZXJLVZPcwBLQduyFZRIYp");

    for (int htufgeXTmhd = 851714019; htufgeXTmhd > 0; htufgeXTmhd--) {
        BfhRg -= WApkCCBTYlUEqOxC;
        AoTguorqRxNLFBx = ! AoTguorqRxNLFBx;
    }

    return IvwvkeXhrFGToz;
}

void YmcwMoQVzBhMlZbQ::PZorzgv(bool MBDEyfzh, int SDXRCuOURC)
{
    double IjCXmhrvv = -76063.1725015325;
    string DcyKJj = string("KhAckljA");
    string YQSJKpIItjJf = string("wywjbTqxxzgsmjiQVrYEtyYZwjvsEnnuYr");
    bool UtRPpmgpbnGrJCnk = false;

    for (int qagJQ = 329611984; qagJQ > 0; qagJQ--) {
        UtRPpmgpbnGrJCnk = MBDEyfzh;
        YQSJKpIItjJf = DcyKJj;
    }
}

string YmcwMoQVzBhMlZbQ::QrhhaqEIH(int BxtiAMwTWo, bool AnugbwsaW, double nthLUORwv, double MDZde, string HUuKiGySo)
{
    int KHxFIUZIsPMXF = -579376416;
    string GFgukXCIAYAMHFON = string("SdgrWIcSTcNDOcHtVBnzvflwOrxlAMtrRAMuFSJUxomzmISBJtwrKIUmNHIPcDPCpFxZnkvzBizgrRORxwfgIWGHirmOjbmATlPgDnasZCVdDjtQYwEkLjjl");
    bool dmvyvNJPUKB = false;
    int FevTc = 1269622883;
    double zFHLS = -174528.61604965728;
    double TITcDYSrxw = -129829.69235495475;
    string bTyHJQMCHbYxZRk = string("CFXFgTahZsJ");
    bool kzfTBfJAg = true;
    double WEIPKkrewWfGS = 475687.0345950721;

    for (int LCNfrNdUtpyCk = 1484053455; LCNfrNdUtpyCk > 0; LCNfrNdUtpyCk--) {
        continue;
    }

    for (int ROWYHtHGnoKgYY = 359343823; ROWYHtHGnoKgYY > 0; ROWYHtHGnoKgYY--) {
        kzfTBfJAg = ! AnugbwsaW;
    }

    for (int kxWrCuxdn = 1837829839; kxWrCuxdn > 0; kxWrCuxdn--) {
        FevTc = FevTc;
        BxtiAMwTWo += BxtiAMwTWo;
    }

    return bTyHJQMCHbYxZRk;
}

bool YmcwMoQVzBhMlZbQ::PAtkDYLYMka(double FyxtuqYeiHOt, bool BNwkuHlaqZQHItD, double ifrMLtCZvJCqM)
{
    bool IdSVNBKxAkapqs = true;
    string pkNnnMDnrXKrH = string("hgUzbrPBkezFFSxxfcaCFEcGbPCLmjM");
    bool ZSbTEnSkjcfTbRfq = true;

    if (ifrMLtCZvJCqM == -962757.5881463535) {
        for (int uzWPOlU = 1121879242; uzWPOlU > 0; uzWPOlU--) {
            IdSVNBKxAkapqs = ! BNwkuHlaqZQHItD;
        }
    }

    if (ifrMLtCZvJCqM <= -962757.5881463535) {
        for (int TBJLB = 710367816; TBJLB > 0; TBJLB--) {
            IdSVNBKxAkapqs = BNwkuHlaqZQHItD;
            ZSbTEnSkjcfTbRfq = BNwkuHlaqZQHItD;
        }
    }

    if (pkNnnMDnrXKrH <= string("hgUzbrPBkezFFSxxfcaCFEcGbPCLmjM")) {
        for (int EiCasyYUCRC = 1951300582; EiCasyYUCRC > 0; EiCasyYUCRC--) {
            ZSbTEnSkjcfTbRfq = BNwkuHlaqZQHItD;
        }
    }

    for (int rkGlA = 1441892387; rkGlA > 0; rkGlA--) {
        FyxtuqYeiHOt -= FyxtuqYeiHOt;
    }

    for (int FiRsnVZWIqJMPTU = 1285113390; FiRsnVZWIqJMPTU > 0; FiRsnVZWIqJMPTU--) {
        FyxtuqYeiHOt += ifrMLtCZvJCqM;
        pkNnnMDnrXKrH = pkNnnMDnrXKrH;
        pkNnnMDnrXKrH = pkNnnMDnrXKrH;
        IdSVNBKxAkapqs = ZSbTEnSkjcfTbRfq;
        ZSbTEnSkjcfTbRfq = ZSbTEnSkjcfTbRfq;
    }

    return ZSbTEnSkjcfTbRfq;
}

bool YmcwMoQVzBhMlZbQ::NznnFuqCWlj(bool alkzqEZroQPpnpln, double ZgbFdblGmecf, bool SmzVXeRypjM)
{
    string TQUoobjphbW = string("AcicInoWcGDuCpgfPROvIOPLDqtuJhboJMRygXcCOBWjRtZLeuNsrCMkMNyxAYqOcipVUgTPMkwTgYumxhQpFpvPKFbONjypaXOkIRTThLwiFeKJOoasoBtGwXGWWDRWonzWRszfEGMYnPWbVjiNTvfmjsVlkFfBLBevsfUJufwmpTmjEeClNfglLgXyCSCKJEsuwHmaRzDQoIsLzsxeqWhKneppGEAbRWaTznMwmPUluWhVSPZoNdFJiBd");
    bool mCvHXLYyXUQ = true;
    int DYFeZrDJQ = -1932601342;
    int OfMgHp = 1774237634;
    string JFYgJatAFLXEJN = string("rKcrhDyjqpPmqICSIwLpXpthJxWgbFkdgSkbYg");

    if (alkzqEZroQPpnpln != true) {
        for (int GJsetU = 739853393; GJsetU > 0; GJsetU--) {
            ZgbFdblGmecf /= ZgbFdblGmecf;
            OfMgHp /= OfMgHp;
            alkzqEZroQPpnpln = mCvHXLYyXUQ;
            DYFeZrDJQ *= DYFeZrDJQ;
        }
    }

    for (int WvIxaDQdrO = 1699317893; WvIxaDQdrO > 0; WvIxaDQdrO--) {
        continue;
    }

    for (int jSZgdnJrx = 59931248; jSZgdnJrx > 0; jSZgdnJrx--) {
        JFYgJatAFLXEJN = TQUoobjphbW;
    }

    for (int WABcCiHh = 938406707; WABcCiHh > 0; WABcCiHh--) {
        ZgbFdblGmecf *= ZgbFdblGmecf;
    }

    return mCvHXLYyXUQ;
}

bool YmcwMoQVzBhMlZbQ::hpeRnA(double LgfpPiIZhueXZqoq)
{
    bool BBKKVsSWnsRitoJ = true;

    for (int TmdJBG = 26443532; TmdJBG > 0; TmdJBG--) {
        BBKKVsSWnsRitoJ = ! BBKKVsSWnsRitoJ;
    }

    return BBKKVsSWnsRitoJ;
}

void YmcwMoQVzBhMlZbQ::wRqwHimGZ()
{
    string cFvSlSuIk = string("STEJDR");
    double JLhDJiJbEXK = 376121.41960974707;
    double SydawAOfXtvSV = -99603.27460426638;
    int bhLboqsj = -1846097434;

    for (int GpFoG = 1687177295; GpFoG > 0; GpFoG--) {
        JLhDJiJbEXK -= SydawAOfXtvSV;
        SydawAOfXtvSV += SydawAOfXtvSV;
        JLhDJiJbEXK *= SydawAOfXtvSV;
        SydawAOfXtvSV += JLhDJiJbEXK;
    }

    for (int TKzOBSbtm = 138720750; TKzOBSbtm > 0; TKzOBSbtm--) {
        JLhDJiJbEXK += JLhDJiJbEXK;
        cFvSlSuIk = cFvSlSuIk;
        cFvSlSuIk = cFvSlSuIk;
        JLhDJiJbEXK /= JLhDJiJbEXK;
        cFvSlSuIk += cFvSlSuIk;
        cFvSlSuIk = cFvSlSuIk;
    }
}

int YmcwMoQVzBhMlZbQ::jdJgqeRP(double dTpIVndFtDTN, bool KMCMdwVvwImPEUfF, double hctOPxeIwodwSM, double YyPmkTw, bool WbIZu)
{
    int kbFlGQCcSzQt = 2101325813;
    bool ioqPBI = true;
    int pGwREWydmVbNyX = -460990300;
    double ShdNetjVcBMGsYJk = -827494.3090433216;

    for (int YJlVHcoddQiPeoVq = 861181480; YJlVHcoddQiPeoVq > 0; YJlVHcoddQiPeoVq--) {
        KMCMdwVvwImPEUfF = WbIZu;
        dTpIVndFtDTN *= ShdNetjVcBMGsYJk;
        KMCMdwVvwImPEUfF = WbIZu;
        dTpIVndFtDTN = hctOPxeIwodwSM;
    }

    if (pGwREWydmVbNyX <= 2101325813) {
        for (int LMOwDoNfHolZIqOU = 1361554002; LMOwDoNfHolZIqOU > 0; LMOwDoNfHolZIqOU--) {
            hctOPxeIwodwSM /= ShdNetjVcBMGsYJk;
            dTpIVndFtDTN -= hctOPxeIwodwSM;
        }
    }

    for (int JQuZOWihttfArWb = 2122965496; JQuZOWihttfArWb > 0; JQuZOWihttfArWb--) {
        YyPmkTw *= ShdNetjVcBMGsYJk;
        ioqPBI = KMCMdwVvwImPEUfF;
    }

    return pGwREWydmVbNyX;
}

int YmcwMoQVzBhMlZbQ::WStMEsvzbgmUknnO(double IrqvOiSLa)
{
    bool LpSSgpvlcelkgblV = true;
    string qNepYIzIN = string("EACMUYdaOvuKeXEQPhlOtIbXSICwGSRslTAKOzpFtSuYzugDzIBRlNxpvgCRVMqoFihyyFtVjhsAcLOQdwToZpVDvFHtVNCJVabrugKLtMxywYrXgWLLDoTcaTsZolFIvFpieZXhXduzCwJ");
    double vTFjfSVZQh = 648857.902963542;
    bool AUXNIxny = false;

    for (int dAzUYwPypCYrVRne = 1154245738; dAzUYwPypCYrVRne > 0; dAzUYwPypCYrVRne--) {
        AUXNIxny = ! AUXNIxny;
        vTFjfSVZQh += IrqvOiSLa;
    }

    for (int cjuxtxjZHy = 242737798; cjuxtxjZHy > 0; cjuxtxjZHy--) {
        continue;
    }

    for (int bVALgkoCvgFP = 336238280; bVALgkoCvgFP > 0; bVALgkoCvgFP--) {
        qNepYIzIN += qNepYIzIN;
    }

    return -401423966;
}

bool YmcwMoQVzBhMlZbQ::QQHSTs(int BXRkfENfJl, int gHPhlulYJFH, int wkVjqsniqTZFpt, double lcPAsVVNFJhZJHIs, bool qWJVWvOhybXvHZ)
{
    string ZDWtfFGuaUMhblMN = string("RihbmvbwRRWaqVroUGJNrXYESgyoloINbroXnPyTTEbpxXrrFwYjejCAuESFgv");
    double jpnOpFGNKt = 588229.238554521;
    string sZbDAKdC = string("kaMDcmePRIPOhhwJRensClfBBHkeWYfRVYxggPhihzOjYxWSNRMzClWBahSHmvZGDyYdKzxRJvRCFSLCsIQyzmPDINJeJMtZhdsmjCjmucxPmwbC");
    int tmwZYys = -1028442450;

    for (int sgrCtjegWXKJve = 1519984575; sgrCtjegWXKJve > 0; sgrCtjegWXKJve--) {
        lcPAsVVNFJhZJHIs += jpnOpFGNKt;
    }

    for (int GMopxXQW = 2005368834; GMopxXQW > 0; GMopxXQW--) {
        ZDWtfFGuaUMhblMN += sZbDAKdC;
        wkVjqsniqTZFpt -= wkVjqsniqTZFpt;
    }

    if (wkVjqsniqTZFpt > -1324901343) {
        for (int zYvtSDDlFmgjVjBj = 1020321953; zYvtSDDlFmgjVjBj > 0; zYvtSDDlFmgjVjBj--) {
            wkVjqsniqTZFpt += BXRkfENfJl;
        }
    }

    for (int QXmyEoGyMVkh = 388017600; QXmyEoGyMVkh > 0; QXmyEoGyMVkh--) {
        gHPhlulYJFH /= BXRkfENfJl;
        BXRkfENfJl = BXRkfENfJl;
        wkVjqsniqTZFpt -= tmwZYys;
    }

    for (int sbwAMDGmCK = 829224163; sbwAMDGmCK > 0; sbwAMDGmCK--) {
        tmwZYys = gHPhlulYJFH;
    }

    for (int mMcdvBYORlhPowh = 1449613158; mMcdvBYORlhPowh > 0; mMcdvBYORlhPowh--) {
        tmwZYys /= tmwZYys;
    }

    return qWJVWvOhybXvHZ;
}

void YmcwMoQVzBhMlZbQ::JIVJdZEEDHsNJZPS()
{
    string MFMhYARq = string("MJGTHOvYTOXtloXhWOLHnBcGoJzDFKXXfFpUiZZuMEOuQpJELNpeJHqqpennHGvLdMsJdpXQZxiriWqgi");
    int sqcJGpGPkVeDQOSQ = 1032041050;

    if (MFMhYARq != string("MJGTHOvYTOXtloXhWOLHnBcGoJzDFKXXfFpUiZZuMEOuQpJELNpeJHqqpennHGvLdMsJdpXQZxiriWqgi")) {
        for (int UVZasf = 1624022346; UVZasf > 0; UVZasf--) {
            MFMhYARq += MFMhYARq;
            MFMhYARq = MFMhYARq;
            MFMhYARq += MFMhYARq;
            sqcJGpGPkVeDQOSQ -= sqcJGpGPkVeDQOSQ;
        }
    }

    for (int LAMEMPPsoNtFLsgL = 1719938422; LAMEMPPsoNtFLsgL > 0; LAMEMPPsoNtFLsgL--) {
        sqcJGpGPkVeDQOSQ /= sqcJGpGPkVeDQOSQ;
        MFMhYARq += MFMhYARq;
        sqcJGpGPkVeDQOSQ += sqcJGpGPkVeDQOSQ;
    }

    if (MFMhYARq == string("MJGTHOvYTOXtloXhWOLHnBcGoJzDFKXXfFpUiZZuMEOuQpJELNpeJHqqpennHGvLdMsJdpXQZxiriWqgi")) {
        for (int ldyNvvL = 1906193137; ldyNvvL > 0; ldyNvvL--) {
            sqcJGpGPkVeDQOSQ -= sqcJGpGPkVeDQOSQ;
        }
    }

    if (sqcJGpGPkVeDQOSQ < 1032041050) {
        for (int zKFoa = 1146438525; zKFoa > 0; zKFoa--) {
            MFMhYARq += MFMhYARq;
        }
    }

    if (MFMhYARq >= string("MJGTHOvYTOXtloXhWOLHnBcGoJzDFKXXfFpUiZZuMEOuQpJELNpeJHqqpennHGvLdMsJdpXQZxiriWqgi")) {
        for (int IbvtxuUHJyQ = 599802442; IbvtxuUHJyQ > 0; IbvtxuUHJyQ--) {
            MFMhYARq = MFMhYARq;
            MFMhYARq += MFMhYARq;
            MFMhYARq += MFMhYARq;
        }
    }

    for (int PVqfdEQA = 1955084996; PVqfdEQA > 0; PVqfdEQA--) {
        continue;
    }
}

YmcwMoQVzBhMlZbQ::YmcwMoQVzBhMlZbQ()
{
    this->mHvogKmlL(string("sKlcOgvSfYifMXYLaOxYyWPjsoQmqVicZrSoAMvsybmUCHREIZRcyUhPmEyJxdTTTzZQizETCXScIzqCIeUxvUcXvNgwMobKmBftgVJzvhJRrWHYvCaaXvncPmtGlyOioFfOYXxfDXdNIOYgjgOsiYCHGhEldepbxGBonZqLnniJIgUFUFVoeoLRXDbwzvmGwDAvxaZvtTXDXtghPSHLP"), -617068.9097754081, 589425.0610736203, -164757.08954388718, 740906010);
    this->EEvxkaKijRAwIe(1464942848, string("LdPoZjPKwEuRWsDwKhfaLWtFHsDTnJAdOCgRQGqSrvTwjxSrMHCVzxX"));
    this->tZXpDrFNkFkIDEK(true, true);
    this->ujPfrqnqPcUvpZ(true, false);
    this->WjHtiWPzYZ(776895193, -566158.6174410646, 604710.7286873008, false, string("DWcIbblyWqwfePeyKlyHJCJXVlgjZgDqaYUhzXwyEranjEcgZACGwENrhJGpslDNwDXcZjioOruKXLrXyXjfJcJpLBPVftZxPkryvGSXjrJGeMmfLHuFWkpyDqu"));
    this->udEDNWbUDRJm(921358.2739044456, string("TvYayTg"));
    this->kWFnvDBF(-614116503);
    this->PZorzgv(true, 171204915);
    this->QrhhaqEIH(-1978545885, true, -453305.26370872534, 318226.1738161172, string("EFgItGkGxxjSuatprMqSASmJTsIewhiGwHAUezyEDhnlRqBDGQJaF"));
    this->PAtkDYLYMka(-25163.953025054037, true, -962757.5881463535);
    this->NznnFuqCWlj(false, 44669.71790989967, false);
    this->hpeRnA(661991.8101227568);
    this->wRqwHimGZ();
    this->jdJgqeRP(-620686.6801193637, true, -851041.6843120346, 952622.0134579384, false);
    this->WStMEsvzbgmUknnO(-718027.3267505884);
    this->QQHSTs(815200632, -1324901343, -1175441606, -977495.5829902979, false);
    this->JIVJdZEEDHsNJZPS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dylqOqbzdVrO
{
public:
    string YegUqiGuVoxWrp;
    double DlvRhfCod;
    double DZASBFpF;

    dylqOqbzdVrO();
    bool guxrLcQgjJtE(string lMwIauyGmKKpW, int eVimAEyHAwJrnH, double RBgQU, int VyPCCtH, double RbPUpaUKqZ);
    double DVFfXCZooEH();
    void EDgzOMfwoWplApsr(bool ttjdHxkpQEiyTKqi, int MdKSUCv, int ZDremGkbm, bool yasgfZKbVOKaU);
protected:
    int QezsZKUjkryG;
    bool USqpfCedoR;
    double NHPSjpVXkvQ;

    void bFwdOd(double SrROzLIKN, double HVFjpNeltGIr, bool WNESxmHLa);
    string vSLfkIjOw(string DIJstkRtMtl, string YCtBChnMuuD, string YksaryN, double pisAqoF);
    bool ZKSVqQYh(int HCxXTgbGW, string aAPVivhqVQ, bool iAzRS);
    double WDRQOd(string hbwGpCIQI, double UiHuaAsHvg, int DWsbCUWP, bool DyayPzKIxDg, int PzSttrMzB);
    int FVuvJbURizcA(double gzLkQONtB, string dVsEjPQs, bool IKdRxdPzlXOlsb, double lBpjPah, bool AdcflQp);
    bool PTGfiVkKbRlcmDC(int FBntHW, int IPslpHYli);
    void TwJtZnvqZxiwgHI(string rPTlTPwbxBIEIG, int mtiET, string zdYlEqrMQ, double hbwCub, bool hkclnDcYoSEY);
private:
    string gCeeFTPQIT;

    void sSYkhdPZhe(int pKVjueTlnCcaQBPF, int scAitxfun, string eIIpKHOZt, double jTECMDycTglgo);
    double VdHvqccYSMJwJK(int SiPqpnJhDB, bool FobGlPtZQmngwSg, bool NMuZAjeUjN);
    bool aPXhLyph(bool XiVdtZotflRNL);
};

bool dylqOqbzdVrO::guxrLcQgjJtE(string lMwIauyGmKKpW, int eVimAEyHAwJrnH, double RBgQU, int VyPCCtH, double RbPUpaUKqZ)
{
    int CTvRYWIUOfApDBz = -1889607340;
    int cDhdcLXSwE = -1350934359;
    string HxpPLZTLaV = string("dRDlAGOPhAIdSYVkBYhGwZimzuDcsigjtKGRQpauJiezShrYfrlQIAtelEMRLQKUUxketBjlEZgc");
    bool ZLKMNuQOHrlVfWew = true;
    double nhiVsQSMAcZiWx = -1006903.7044009884;
    string GvRYRzLuKrw = string("oGTtuDdPOkaPrUXJuGtZPwLFwcjlzoxZHLKNPBCqbbodpMEQxhMyPSRxBkBNoJOrWfCjRofefUenVrNCMDTOEntrLelGVRjeqcIiFbTsssuWeOlRLsRFuNUHLCbiGGwoUdaOKyhdzULMlZocqDHeHEjfnlmEzPkFKiijqaYNTPaKUZY");
    double MQxrRRVlGY = -641663.8017204631;
    bool bIXUENuefF = true;

    if (HxpPLZTLaV != string("lQjowTxHIjGfPGjnSBWPMOlctUcYlRAKrfzxMNQxBdRfkldNWRGMKdwhwqZctJDBxLaDjUELgNPjRQVsFqzxLkVoZajmRAcZgiNgeOoXjiLkQgQNMWveYjCFNjPzlxRUaqkZWxp")) {
        for (int lSXGzH = 1847916859; lSXGzH > 0; lSXGzH--) {
            CTvRYWIUOfApDBz = CTvRYWIUOfApDBz;
            cDhdcLXSwE *= VyPCCtH;
            CTvRYWIUOfApDBz += CTvRYWIUOfApDBz;
        }
    }

    return bIXUENuefF;
}

double dylqOqbzdVrO::DVFfXCZooEH()
{
    string oAtGEmHoGwFjtWOj = string("RnRArccbNqlxdXCBkuHCiqIDYZgojbtkyQfWhKJCrVIlUQnMQJLRlEHPHpYIykiuulRzNceDUoPFfoprXSrCsmyxnnwMrjtBTkSGrudpeMlMUQxIZcbGMMfzYdAJyEgOLIGMaZQkXlHpaBsUoPIXDKGzxlRaWnpXRSKQaSercbOfxAAgBevxxyVoSOTrTYPRrdsJJcSowEKEWoKKyIviNfrQTGzwhPMvP");
    double nTGELd = -243436.72332634215;
    string DPUoYt = string("mQjQhHmFicwLCwUVMjcFYGcMXGZTcKOfFfQQGodzHbjsJVXiriNIXXWBSFTgWqeoFN");
    int ZKHTWtjI = -816792017;
    int KksAL = 1821970159;
    string DWEkLOYgWhmUg = string("QtWqLmijAiriHuLrslLPnkAaiaeacNDuWbZIiLjvpNEXVQHsqPBSPVsbwmDqNAWBCGHqHPYyiHXmKmsEvPVyhhvNKEOQDgDakoNAtzLAyOczjjdwfidDIiHHxIQJQdDMbKOSTSWTRaXg");

    for (int ndbWZCfavm = 75206976; ndbWZCfavm > 0; ndbWZCfavm--) {
        continue;
    }

    for (int YGDAvRfXyJIK = 1369731664; YGDAvRfXyJIK > 0; YGDAvRfXyJIK--) {
        DPUoYt = oAtGEmHoGwFjtWOj;
        DPUoYt += oAtGEmHoGwFjtWOj;
        ZKHTWtjI *= ZKHTWtjI;
        DPUoYt += oAtGEmHoGwFjtWOj;
    }

    for (int oKbunAvQlApzEBir = 1056680696; oKbunAvQlApzEBir > 0; oKbunAvQlApzEBir--) {
        DPUoYt += oAtGEmHoGwFjtWOj;
        oAtGEmHoGwFjtWOj = DPUoYt;
    }

    if (DWEkLOYgWhmUg != string("RnRArccbNqlxdXCBkuHCiqIDYZgojbtkyQfWhKJCrVIlUQnMQJLRlEHPHpYIykiuulRzNceDUoPFfoprXSrCsmyxnnwMrjtBTkSGrudpeMlMUQxIZcbGMMfzYdAJyEgOLIGMaZQkXlHpaBsUoPIXDKGzxlRaWnpXRSKQaSercbOfxAAgBevxxyVoSOTrTYPRrdsJJcSowEKEWoKKyIviNfrQTGzwhPMvP")) {
        for (int dsYLQmcaP = 1260444073; dsYLQmcaP > 0; dsYLQmcaP--) {
            oAtGEmHoGwFjtWOj += oAtGEmHoGwFjtWOj;
            KksAL = ZKHTWtjI;
            DPUoYt += DWEkLOYgWhmUg;
            DWEkLOYgWhmUg += DPUoYt;
            oAtGEmHoGwFjtWOj += oAtGEmHoGwFjtWOj;
            DWEkLOYgWhmUg += DWEkLOYgWhmUg;
        }
    }

    for (int YijpTzuSkvd = 1911887708; YijpTzuSkvd > 0; YijpTzuSkvd--) {
        DPUoYt = oAtGEmHoGwFjtWOj;
    }

    return nTGELd;
}

void dylqOqbzdVrO::EDgzOMfwoWplApsr(bool ttjdHxkpQEiyTKqi, int MdKSUCv, int ZDremGkbm, bool yasgfZKbVOKaU)
{
    int zHklE = -897899513;
    bool ACvpRHIk = false;
    double KVaCrelUrBoWG = 704600.0118324843;
    string SRTPRitvjzEisnrD = string("CfKSCHDAfqAEHopEMjglJEuCFhBQQKYWOJxOhyvPElJWcQSNYgQuNDHikwUOkbDxeOyJsellZIUuFvPwvkJFjMMAtWrXaNQlHOvbuifsFUfghoMKxqcKOQAunW");
    double HyGFyvRUYbby = 805590.38565341;

    for (int HVcMFLQvR = 246902459; HVcMFLQvR > 0; HVcMFLQvR--) {
        HyGFyvRUYbby *= HyGFyvRUYbby;
    }

    for (int eqBprmAklsjzjRe = 2123920368; eqBprmAklsjzjRe > 0; eqBprmAklsjzjRe--) {
        HyGFyvRUYbby += KVaCrelUrBoWG;
        zHklE *= MdKSUCv;
    }

    for (int gaZZgUPrvotJnR = 210680293; gaZZgUPrvotJnR > 0; gaZZgUPrvotJnR--) {
        continue;
    }

    for (int PcpfeA = 1857034939; PcpfeA > 0; PcpfeA--) {
        continue;
    }
}

void dylqOqbzdVrO::bFwdOd(double SrROzLIKN, double HVFjpNeltGIr, bool WNESxmHLa)
{
    int zhGEXhIyf = 1200360073;
}

string dylqOqbzdVrO::vSLfkIjOw(string DIJstkRtMtl, string YCtBChnMuuD, string YksaryN, double pisAqoF)
{
    bool bwMIWSSWriWaU = false;
    string wFYbPPkqtkZPh = string("ZEdfrkPjJktZWBKOGiHewetZsffbFcezoWQrOJrJoQtQJMbYUqIBKoktGAQnvTfZrNZEt");
    int cwFrZRmHfxhWo = -323466871;
    string NqmUXuwZCMWlqg = string("FoUCTrbIPYwzWCagmULVChFBShsYeJbXjtDqJVfztxgaAXLcdeiYXkBBImRhszzfSrVORtouredVLsljLETbYzGxrubZRaWALgNWJIEUIVzptCusmvYbNvUMadbvEtuvEnMfQwwnXGNwywdFmYXjxHxKYajoszUqbnAgAKMaxgvUbHiLrTsZZEUTqcjPoHFXeTbXgOZgHTIYLvfZfglEywIfWwPMUzFZPKvjRLXIyXLwUE");
    string ONTRAEZHYO = string("lHKbORQhmqmyBdAaaMpVGMwhIeBmkeAyWZZdMmfGOiZmPzrNePMxILIKVqarEFkvdzHVQHOUFRMiFSUBPPINVuqsJcwkRhGUkurUBAlGKhzfBAvHJTqImzzAqkiJsybPuZPtJkAhxyPBKtRYFrHsxXPIVByTScpmgVFeeprqJcmHTXoGrLCHKFSZrBzKmfCslWmuODFHluBvaoBLonFghiItFfAyMoJyQNKB");
    double VvrCz = 396191.5359784865;
    string YAiUVDK = string("WJBTHhltDAYSwSYoEUHyVwYgOCNPBnWjmvuzxLwYxjmRkYWyVGRFffRHyQiGfwVbhxiCbupGUffUOsRDAyldvUxVNMpQENrIIuBQYzHretNUQSiUgXTXSJWFnvJVRKFWjSloJWscHvKZlzJXEAxCQllnpmvseBvfBiseNOHpnKTzMAsj");

    for (int hatXwXippFFVgv = 399363909; hatXwXippFFVgv > 0; hatXwXippFFVgv--) {
        YCtBChnMuuD = ONTRAEZHYO;
        cwFrZRmHfxhWo += cwFrZRmHfxhWo;
    }

    for (int kHwfcwkgCSMOUl = 1553989721; kHwfcwkgCSMOUl > 0; kHwfcwkgCSMOUl--) {
        NqmUXuwZCMWlqg += YksaryN;
        YAiUVDK += DIJstkRtMtl;
        NqmUXuwZCMWlqg += YCtBChnMuuD;
    }

    for (int tEjeSGdg = 1585381551; tEjeSGdg > 0; tEjeSGdg--) {
        YCtBChnMuuD += YksaryN;
        NqmUXuwZCMWlqg += wFYbPPkqtkZPh;
        YksaryN = ONTRAEZHYO;
    }

    for (int vuNQFd = 1279639422; vuNQFd > 0; vuNQFd--) {
        cwFrZRmHfxhWo += cwFrZRmHfxhWo;
        pisAqoF *= VvrCz;
        YCtBChnMuuD = YAiUVDK;
        YAiUVDK += YksaryN;
    }

    return YAiUVDK;
}

bool dylqOqbzdVrO::ZKSVqQYh(int HCxXTgbGW, string aAPVivhqVQ, bool iAzRS)
{
    double VbIAwRd = 57949.13517381524;
    bool pKclUkbxu = false;
    string qkDVwJlBGderIxHx = string("BUTpqosHZzIEwcqQyyIUZtPtQtpsNVnIznNVndnzyzGGEQwtItQ");
    int aDVJHoVTOm = 1391334511;

    for (int VVhPlaBXrZDMI = 54536182; VVhPlaBXrZDMI > 0; VVhPlaBXrZDMI--) {
        HCxXTgbGW /= HCxXTgbGW;
        pKclUkbxu = ! pKclUkbxu;
    }

    for (int CglyXzH = 928867789; CglyXzH > 0; CglyXzH--) {
        aAPVivhqVQ += aAPVivhqVQ;
        aAPVivhqVQ = aAPVivhqVQ;
        iAzRS = iAzRS;
        qkDVwJlBGderIxHx = qkDVwJlBGderIxHx;
        VbIAwRd = VbIAwRd;
    }

    for (int eTBHwFPvH = 2059427307; eTBHwFPvH > 0; eTBHwFPvH--) {
        aAPVivhqVQ = qkDVwJlBGderIxHx;
        VbIAwRd += VbIAwRd;
    }

    for (int jIEEEkbakXLZIuUb = 832651654; jIEEEkbakXLZIuUb > 0; jIEEEkbakXLZIuUb--) {
        aDVJHoVTOm = HCxXTgbGW;
        pKclUkbxu = iAzRS;
        pKclUkbxu = pKclUkbxu;
        HCxXTgbGW /= HCxXTgbGW;
    }

    return pKclUkbxu;
}

double dylqOqbzdVrO::WDRQOd(string hbwGpCIQI, double UiHuaAsHvg, int DWsbCUWP, bool DyayPzKIxDg, int PzSttrMzB)
{
    int teiOkezuhGcUDHCZ = 1794632414;
    bool miQtXo = false;
    bool atEPr = true;
    bool cdQRmtrQilrDylX = true;
    double jMgqYTejpkKgN = 145370.4548161464;
    bool RlVTKuEWR = false;

    for (int pAyJgJouwvPGjJXm = 250330585; pAyJgJouwvPGjJXm > 0; pAyJgJouwvPGjJXm--) {
        atEPr = ! DyayPzKIxDg;
        cdQRmtrQilrDylX = cdQRmtrQilrDylX;
        DyayPzKIxDg = RlVTKuEWR;
        DyayPzKIxDg = atEPr;
    }

    if (DWsbCUWP > 864248501) {
        for (int WHvjSbYzEwoT = 1389605935; WHvjSbYzEwoT > 0; WHvjSbYzEwoT--) {
            continue;
        }
    }

    return jMgqYTejpkKgN;
}

int dylqOqbzdVrO::FVuvJbURizcA(double gzLkQONtB, string dVsEjPQs, bool IKdRxdPzlXOlsb, double lBpjPah, bool AdcflQp)
{
    double raxCdzdKNKaa = -806921.5527821106;
    bool iRDEJnyxlgI = true;
    string VxorXV = string("FgyaGhVmlfEKKDeDRCrrmIshUVxvsAIPitrcbJGWtTnriFpfOqJUROkcQqBNrokqhQTjvRcWgCWoMKgQBTxrLgroKtmJeFpijUMmvTNjYrTfTDJRJQmXQGMulbDHpkM");
    string gbYUmf = string("sJTnYXWgWztEdsidZrADEKMydovhYbYlBeixKAHb");
    bool pOMVcLGYUFhf = false;

    for (int wDhKYlEAbbWfsln = 1811228914; wDhKYlEAbbWfsln > 0; wDhKYlEAbbWfsln--) {
        continue;
    }

    for (int PfbWxVyZI = 1812149548; PfbWxVyZI > 0; PfbWxVyZI--) {
        iRDEJnyxlgI = ! pOMVcLGYUFhf;
        iRDEJnyxlgI = ! AdcflQp;
        gbYUmf = dVsEjPQs;
    }

    for (int BFpxatepE = 83883534; BFpxatepE > 0; BFpxatepE--) {
        iRDEJnyxlgI = ! pOMVcLGYUFhf;
    }

    for (int wPvWgCsMIwXguMd = 630860250; wPvWgCsMIwXguMd > 0; wPvWgCsMIwXguMd--) {
        lBpjPah *= lBpjPah;
        AdcflQp = iRDEJnyxlgI;
        gbYUmf += VxorXV;
    }

    for (int viWwWmMElCUpSQz = 13419354; viWwWmMElCUpSQz > 0; viWwWmMElCUpSQz--) {
        gbYUmf += gbYUmf;
        IKdRxdPzlXOlsb = IKdRxdPzlXOlsb;
        dVsEjPQs = dVsEjPQs;
        raxCdzdKNKaa = gzLkQONtB;
    }

    if (pOMVcLGYUFhf == false) {
        for (int qQjnKaVZNWJ = 2035519797; qQjnKaVZNWJ > 0; qQjnKaVZNWJ--) {
            gbYUmf = gbYUmf;
            gbYUmf += gbYUmf;
            iRDEJnyxlgI = ! AdcflQp;
            raxCdzdKNKaa = gzLkQONtB;
            lBpjPah *= raxCdzdKNKaa;
        }
    }

    if (VxorXV < string("hAYCgQikmmejvwHxMsibWWirenvCGGcsTiVUDWCMlkVrhHyjWYzPpztRdMuhKbrYsmCjJPTMRImpymWVJEoeKTdFxXFPJPDqydaebyjCIsXkyqJIkhYZBdEwvqBmoTuAPjGXLaPagbCzYphSaCJkGMBsuybDizqruPPTWuuLxqanqLyOUmHX")) {
        for (int ChRiXtGHPCZySxu = 1614009064; ChRiXtGHPCZySxu > 0; ChRiXtGHPCZySxu--) {
            VxorXV = gbYUmf;
            dVsEjPQs += gbYUmf;
            pOMVcLGYUFhf = ! iRDEJnyxlgI;
        }
    }

    for (int ftsADr = 1058555657; ftsADr > 0; ftsADr--) {
        continue;
    }

    return -840167476;
}

bool dylqOqbzdVrO::PTGfiVkKbRlcmDC(int FBntHW, int IPslpHYli)
{
    string mHzeWdjVWrsea = string("GcXdffwsIoalisGf");
    int AuhmD = -1838104319;

    if (mHzeWdjVWrsea > string("GcXdffwsIoalisGf")) {
        for (int PanMWBjayBS = 691241705; PanMWBjayBS > 0; PanMWBjayBS--) {
            FBntHW = FBntHW;
            AuhmD = IPslpHYli;
            FBntHW /= FBntHW;
            FBntHW *= FBntHW;
            mHzeWdjVWrsea = mHzeWdjVWrsea;
            AuhmD /= FBntHW;
        }
    }

    if (IPslpHYli >= -2053849223) {
        for (int esqMPkZUvPOMD = 1663773733; esqMPkZUvPOMD > 0; esqMPkZUvPOMD--) {
            IPslpHYli += IPslpHYli;
            IPslpHYli = AuhmD;
            AuhmD /= FBntHW;
        }
    }

    for (int TmkEBrCztqGyXxu = 354770918; TmkEBrCztqGyXxu > 0; TmkEBrCztqGyXxu--) {
        FBntHW *= FBntHW;
        mHzeWdjVWrsea += mHzeWdjVWrsea;
        FBntHW += AuhmD;
        mHzeWdjVWrsea += mHzeWdjVWrsea;
    }

    for (int vWotAZ = 1816402846; vWotAZ > 0; vWotAZ--) {
        AuhmD += IPslpHYli;
        AuhmD *= AuhmD;
        AuhmD = AuhmD;
        IPslpHYli = IPslpHYli;
        AuhmD /= FBntHW;
        AuhmD *= FBntHW;
        IPslpHYli = FBntHW;
    }

    return false;
}

void dylqOqbzdVrO::TwJtZnvqZxiwgHI(string rPTlTPwbxBIEIG, int mtiET, string zdYlEqrMQ, double hbwCub, bool hkclnDcYoSEY)
{
    string otSCJgjK = string("cLcGrdkzmCbuvLTLthVhezonRKBejenBIKxf");
    int LlUPzWraHvay = -2065151576;
    string EITXfS = string("ynzfGIefxuTeJWhqlrycmvEgIPOAUNVTJhXHJLUFXSXKNzVXPTbbhGbgOEzknIpMTBHBZltBQYPcSgRCHwMYkJErHwxXkwfQKMaXDGDIVxnEHInhuJSnOHrVKURYcqNtUIPjQiUUxhdxShqaoNBFCIagUMNmkBHzthlPrlPtPOmNCrUMMYFnuQRZmWXgeJJPBJLGtdqrcPawiFXJNKorLXgAFXfxoemzuIWUEmjZtGQQNpUFdoAJfzx");
    int dmPRwEYcqpKD = -352043291;

    for (int ArHfJ = 1660266495; ArHfJ > 0; ArHfJ--) {
        EITXfS = EITXfS;
        EITXfS += otSCJgjK;
    }

    if (zdYlEqrMQ == string("woJoJNWQwsqQlZovSqFTMrlfmpbvazVCcfofJApiqEGobPlBHrdEsTa")) {
        for (int cfMwt = 1858629532; cfMwt > 0; cfMwt--) {
            zdYlEqrMQ += rPTlTPwbxBIEIG;
            mtiET *= LlUPzWraHvay;
            mtiET += dmPRwEYcqpKD;
            hbwCub *= hbwCub;
        }
    }

    for (int SSYoueXyfxjllofQ = 587887960; SSYoueXyfxjllofQ > 0; SSYoueXyfxjllofQ--) {
        otSCJgjK = zdYlEqrMQ;
    }

    for (int SmzHdKPQImOxu = 1063875267; SmzHdKPQImOxu > 0; SmzHdKPQImOxu--) {
        zdYlEqrMQ += zdYlEqrMQ;
    }

    for (int ToRgBFBjQbruqB = 46407390; ToRgBFBjQbruqB > 0; ToRgBFBjQbruqB--) {
        LlUPzWraHvay = LlUPzWraHvay;
        dmPRwEYcqpKD -= mtiET;
        rPTlTPwbxBIEIG = zdYlEqrMQ;
    }
}

void dylqOqbzdVrO::sSYkhdPZhe(int pKVjueTlnCcaQBPF, int scAitxfun, string eIIpKHOZt, double jTECMDycTglgo)
{
    int uMVioFjAu = 1699400460;
    double GRTKnMHbf = -457187.0165215419;
    double EnGhq = 648614.7831515617;
    double neVtn = -395406.59187864163;
    int BKaVppkVJ = -305203001;
    double XIEuEi = -1027141.4796803812;
    bool dZIQMXbc = true;
    int bSxcKYKzqnelP = -184031020;

    if (bSxcKYKzqnelP < -1120245092) {
        for (int sHANNJMukApuAlZ = 691009151; sHANNJMukApuAlZ > 0; sHANNJMukApuAlZ--) {
            pKVjueTlnCcaQBPF /= scAitxfun;
            XIEuEi /= GRTKnMHbf;
        }
    }

    if (GRTKnMHbf == -1027141.4796803812) {
        for (int fiMFGdoI = 23939101; fiMFGdoI > 0; fiMFGdoI--) {
            neVtn *= jTECMDycTglgo;
            EnGhq -= jTECMDycTglgo;
            XIEuEi = neVtn;
        }
    }
}

double dylqOqbzdVrO::VdHvqccYSMJwJK(int SiPqpnJhDB, bool FobGlPtZQmngwSg, bool NMuZAjeUjN)
{
    double ExAjuczyKJRMu = -39280.72233242618;

    for (int uwGBAXczJeNSiOYJ = 1606033133; uwGBAXczJeNSiOYJ > 0; uwGBAXczJeNSiOYJ--) {
        FobGlPtZQmngwSg = NMuZAjeUjN;
        NMuZAjeUjN = ! FobGlPtZQmngwSg;
    }

    if (SiPqpnJhDB >= -264468973) {
        for (int KMbVoXyJBb = 978956894; KMbVoXyJBb > 0; KMbVoXyJBb--) {
            continue;
        }
    }

    for (int nuhEGyF = 288920018; nuhEGyF > 0; nuhEGyF--) {
        NMuZAjeUjN = ! FobGlPtZQmngwSg;
        FobGlPtZQmngwSg = FobGlPtZQmngwSg;
        NMuZAjeUjN = NMuZAjeUjN;
        NMuZAjeUjN = ! NMuZAjeUjN;
    }

    if (NMuZAjeUjN == false) {
        for (int tHHTyWdaditA = 249101824; tHHTyWdaditA > 0; tHHTyWdaditA--) {
            ExAjuczyKJRMu = ExAjuczyKJRMu;
            ExAjuczyKJRMu /= ExAjuczyKJRMu;
            NMuZAjeUjN = FobGlPtZQmngwSg;
            FobGlPtZQmngwSg = ! NMuZAjeUjN;
        }
    }

    return ExAjuczyKJRMu;
}

bool dylqOqbzdVrO::aPXhLyph(bool XiVdtZotflRNL)
{
    double PDXySFdBYLpCUQ = -230608.0692487005;
    int nHcUiIwWHDvWOi = -947215068;

    for (int PLcTIRew = 1949109925; PLcTIRew > 0; PLcTIRew--) {
        continue;
    }

    return XiVdtZotflRNL;
}

dylqOqbzdVrO::dylqOqbzdVrO()
{
    this->guxrLcQgjJtE(string("lQjowTxHIjGfPGjnSBWPMOlctUcYlRAKrfzxMNQxBdRfkldNWRGMKdwhwqZctJDBxLaDjUELgNPjRQVsFqzxLkVoZajmRAcZgiNgeOoXjiLkQgQNMWveYjCFNjPzlxRUaqkZWxp"), 210143500, 212694.2429035328, 1270392421, 988727.0986043673);
    this->DVFfXCZooEH();
    this->EDgzOMfwoWplApsr(true, 1712024949, -31438720, false);
    this->bFwdOd(344908.0558517964, -368153.02658254065, false);
    this->vSLfkIjOw(string("VaTPNGxEEPXmRpQuvXvPzrLioEhEkMIqhCLFoT"), string("qGtTZGojWHGaYKvrbCOsgu"), string("ldsBrqpCfYXtJRhnJngAcRxqIzTRKUeedMKrdypxVcVxclIxNUaTeHutBEDWTomtzJzfQyyPiYMdxgcHZRKYidWaSVvJVMyyFVIQTrsIQXLslmnUaKHNoNMrAXIUoeajwPauntFcKnHSNoxltOrheYYWdFDYOFYnBEVignOdXpwSMBogMTxoPOIqYS"), -1012493.7124395455);
    this->ZKSVqQYh(585259680, string("HKLTNyiFRpfIKaoPXBmEqeR"), true);
    this->WDRQOd(string("SYgfdJfzEEyyPGNvtDszFpjbpClaQXvpoPunmhndDqAyczWPnMbZlRbmgWEgNEhhCxSbVp"), -977030.6496152877, 1160174559, false, 864248501);
    this->FVuvJbURizcA(180414.286088008, string("hAYCgQikmmejvwHxMsibWWirenvCGGcsTiVUDWCMlkVrhHyjWYzPpztRdMuhKbrYsmCjJPTMRImpymWVJEoeKTdFxXFPJPDqydaebyjCIsXkyqJIkhYZBdEwvqBmoTuAPjGXLaPagbCzYphSaCJkGMBsuybDizqruPPTWuuLxqanqLyOUmHX"), false, 147867.10341837525, false);
    this->PTGfiVkKbRlcmDC(-497011922, -2053849223);
    this->TwJtZnvqZxiwgHI(string("woJoJNWQwsqQlZovSqFTMrlfmpbvazVCcfofJApiqEGobPlBHrdEsTa"), 1646206310, string("JYzkuqGUxYZkvBDqn"), 804525.1357555772, true);
    this->sSYkhdPZhe(728156962, -1120245092, string("ufsgpWVahbMAcGZpvWKdUTQugyMcGfPlFVjNrhdqTFCJQBvUVaugvyvPxTXwipOKGNKEWEBASUrviFcOkjdhTkQyGhcOsJJiPHDPV"), -193906.53465418806);
    this->VdHvqccYSMJwJK(-264468973, false, false);
    this->aPXhLyph(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kkynPXYsjihtB
{
public:
    double tXAoWb;
    string QvoOgJgAPSJfqcg;
    double sAIyiAhVn;

    kkynPXYsjihtB();
    int PLGFPjI(int gPQdQskjOI, bool hNVukmmbnCQM);
    void eoyxcYJVNi(bool bRzWUpv, string cTQbhwAx, bool aLSYCdKJlnjMBFD);
    double InEci(bool bSfQr);
    string bbvrXytBy(int OEoHEC, double iWOtFtfCpHJBHZ, double iledAjaClTrkdfO);
protected:
    bool tBgVUeayYkij;
    string dCyAWkY;
    double hTFXs;

    void QccJlqnMSKDTAMzZ(bool AlKMYA, bool APMpdXgjnLtIwzOQ, bool EYbZc, bool ZbxjqQOnMImiy);
    void gKbGPwcNnbYNOai(string mBAOhCAyT, double JOMOSZ);
    int tjqWXQrgCWlrcL(double fnLYYzPDUhWSq, int GWydTFm, string ffKUGITHtvc, bool nYlqxtfkrynUShu, int LINwIHyLtR);
    void PQJAf(string NmJGqrVR, double CRPaGDJZLFHI, double wwDUVNDulqF, bool ombSrChxKvtFc);
    bool JzeyqRMc();
private:
    string LvGpGFZqfWfqicoy;
    bool wlqXxQDvg;
    bool YsstFnfOLwzOzTzV;
    int zHYHIyhtNR;
    string XknRFLGwRlWlG;

};

int kkynPXYsjihtB::PLGFPjI(int gPQdQskjOI, bool hNVukmmbnCQM)
{
    string IIsdxxeL = string("AvfEnHhvJtaYrpBDhYZBBQAkxOyDeXijbcONqumJbBFMvWtHMrFlrytDockveEIAhFNKWnHPAJnXTgvlGfJsCjtgzoyXFgydrpiANcltcKKeIoyQPPmIPLuFEtMswMPVWObRYYmhWMHTsgiyZyTqidKzqQyPpcIfhCylJDkGLaIOvGPJJpYtotGWhiqFuULYTsdJWoUslbBpwgLzNiDFTBpASLIjMoMSjgsQquaAzTtYxtfo");
    double EIApAlZYfvm = 83097.57559149597;
    bool GKboHqVjkpEsPJ = true;
    string rGcmtgsZVuBW = string("CafYzNvOOhzFOBWTAYHMLxZJlsqfpJTFuxiBsbHIYCdvqQlrgrIxOqSowdspCOlsKXLigOSaEdMLxAwwzLCvSuoWYgmels");
    double FkIXhT = 796812.5342345345;
    double yHZfpzrIdXKWNd = 374673.1613982945;
    int POvhxIUbFm = 1499538129;

    for (int pdzkZdpi = 1614473531; pdzkZdpi > 0; pdzkZdpi--) {
        continue;
    }

    for (int VBcmAnV = 336108738; VBcmAnV > 0; VBcmAnV--) {
        continue;
    }

    if (GKboHqVjkpEsPJ != true) {
        for (int HgvNw = 2056808721; HgvNw > 0; HgvNw--) {
            continue;
        }
    }

    if (GKboHqVjkpEsPJ != true) {
        for (int TcXbEpRaFoxkS = 2073793978; TcXbEpRaFoxkS > 0; TcXbEpRaFoxkS--) {
            gPQdQskjOI += gPQdQskjOI;
            EIApAlZYfvm += FkIXhT;
            POvhxIUbFm = gPQdQskjOI;
        }
    }

    for (int axwHxm = 694555608; axwHxm > 0; axwHxm--) {
        POvhxIUbFm /= POvhxIUbFm;
        FkIXhT += yHZfpzrIdXKWNd;
    }

    return POvhxIUbFm;
}

void kkynPXYsjihtB::eoyxcYJVNi(bool bRzWUpv, string cTQbhwAx, bool aLSYCdKJlnjMBFD)
{
    string uYQDgByNcI = string("JpYVyTMnMTKtHgtjEIAPHvuyzNzlQmbcbiBxbybKyckYPzzfsXWWbpQVWyxmAtLZbSYltWHKQFznbm");

    for (int ICyrckVHq = 1545577798; ICyrckVHq > 0; ICyrckVHq--) {
        aLSYCdKJlnjMBFD = ! aLSYCdKJlnjMBFD;
        cTQbhwAx = cTQbhwAx;
        cTQbhwAx += cTQbhwAx;
    }

    if (aLSYCdKJlnjMBFD != true) {
        for (int czQPqZyftM = 445158380; czQPqZyftM > 0; czQPqZyftM--) {
            cTQbhwAx = uYQDgByNcI;
            cTQbhwAx = uYQDgByNcI;
            aLSYCdKJlnjMBFD = ! aLSYCdKJlnjMBFD;
            aLSYCdKJlnjMBFD = ! bRzWUpv;
            uYQDgByNcI = cTQbhwAx;
        }
    }
}

double kkynPXYsjihtB::InEci(bool bSfQr)
{
    int ipwXeOcaXV = 1010873625;
    bool oAQgQwdn = true;
    string CeXZQIMNTY = string("lvpHvfhfunNiImzaVTgUnWjxVTXOsxccSUwpfNeCWBPDmrHsbYyUXSmovqmXerwTaSBrvuublktZiQvQPioHrWxPnJDqBduWRvVfFsOatCBblDdEoKWhXalFeqxdgPqqzoTgvs");
    bool bRFVoaYvXF = false;
    bool MatFmmRmN = false;
    int etnZyBGFrQfHzQ = 47114999;
    int gvuJgQojotgSpyXV = -1729647973;

    if (bSfQr != false) {
        for (int dnzYVsQTxCvu = 1986677819; dnzYVsQTxCvu > 0; dnzYVsQTxCvu--) {
            etnZyBGFrQfHzQ += gvuJgQojotgSpyXV;
            bSfQr = ! MatFmmRmN;
            oAQgQwdn = ! oAQgQwdn;
            CeXZQIMNTY += CeXZQIMNTY;
            oAQgQwdn = bSfQr;
        }
    }

    return 1040325.3131154793;
}

string kkynPXYsjihtB::bbvrXytBy(int OEoHEC, double iWOtFtfCpHJBHZ, double iledAjaClTrkdfO)
{
    bool vZTlDIQLmQ = true;

    for (int Teikykbo = 1340746091; Teikykbo > 0; Teikykbo--) {
        continue;
    }

    for (int YIqePXcJBveK = 882947405; YIqePXcJBveK > 0; YIqePXcJBveK--) {
        OEoHEC /= OEoHEC;
        vZTlDIQLmQ = ! vZTlDIQLmQ;
    }

    if (iWOtFtfCpHJBHZ > 731648.3381617118) {
        for (int EkDcqx = 1513437088; EkDcqx > 0; EkDcqx--) {
            vZTlDIQLmQ = vZTlDIQLmQ;
        }
    }

    for (int oFNooyWWnA = 584786571; oFNooyWWnA > 0; oFNooyWWnA--) {
        continue;
    }

    for (int ZOtJq = 647449316; ZOtJq > 0; ZOtJq--) {
        OEoHEC /= OEoHEC;
        iWOtFtfCpHJBHZ = iledAjaClTrkdfO;
        iWOtFtfCpHJBHZ = iWOtFtfCpHJBHZ;
        OEoHEC += OEoHEC;
    }

    return string("JKiEbojgKqogJPlaXFcVSGVAddFKNFqeHKDwcwULQLhmLQyMtvSGeTTBEllesrpLyYlTGxWp");
}

void kkynPXYsjihtB::QccJlqnMSKDTAMzZ(bool AlKMYA, bool APMpdXgjnLtIwzOQ, bool EYbZc, bool ZbxjqQOnMImiy)
{
    bool nzNrflICeFn = false;
    bool hxiGOZli = false;
    int zVVsXI = 2079343285;
    double nGuyaivd = 971906.1991751496;
    string wxjiN = string("UMQMuLfsQWVlh");
    int yTyTkpTdjej = -1136439922;
    string iTHcq = string("IKdXCEEjBbCTJxVtRRjKBLvuqjWjANIBOyFjnIVtLWMmhOeUHmPaElwEbwLgiTwHmxMPCwJLezphwmJXgVvppSzLZsnVRisvVXmIkMtNorKZEipoQPLGKsuqDXLRnTwVUPsNFetDcBzRFeSAzzIEidldskcXhZKcjUKparQVOTGsGVqoJBG");
    int hjbfyEytO = 358084436;

    if (AlKMYA != true) {
        for (int vqWgXBruyi = 795603367; vqWgXBruyi > 0; vqWgXBruyi--) {
            ZbxjqQOnMImiy = ! nzNrflICeFn;
        }
    }

    for (int IoRayXFWVMbI = 1512455391; IoRayXFWVMbI > 0; IoRayXFWVMbI--) {
        APMpdXgjnLtIwzOQ = ZbxjqQOnMImiy;
        nzNrflICeFn = ! AlKMYA;
        APMpdXgjnLtIwzOQ = ! ZbxjqQOnMImiy;
    }

    for (int noEZwPG = 296497025; noEZwPG > 0; noEZwPG--) {
        ZbxjqQOnMImiy = ! hxiGOZli;
        hxiGOZli = ! nzNrflICeFn;
    }

    for (int IGymgKh = 1775650307; IGymgKh > 0; IGymgKh--) {
        continue;
    }

    for (int JWnYiFfcSi = 1153304712; JWnYiFfcSi > 0; JWnYiFfcSi--) {
        wxjiN += wxjiN;
        APMpdXgjnLtIwzOQ = ! hxiGOZli;
    }
}

void kkynPXYsjihtB::gKbGPwcNnbYNOai(string mBAOhCAyT, double JOMOSZ)
{
    int KlpONexiYPdurLbD = -1258015914;
    int GVWtylNKCB = 2034914149;
    string srJog = string("dZfDgEpzHpnpyNaFwEVmEZTmqDWOzDCjVbVWgWIQvErjPRYOxqIzauUXEsYgdKczgbgNXKcTKBtJVAAuhYxuRZvMesUbRijrSvRtjYZUcmUlYTWVDKhAqFqKdgCGBjHcpZxYUTeXlVIjirztKpzWSPdSTJGrpRqzxZHyMTiJSBHOVsfXQrZVfWoSkifUzbhAIGUArcbGwjKdoMVSGzmeVMKbMpQxpmnwlczyVvFljeTzmjlKNiBOwnOIaNwjPm");
    double amJEXzxwmPA = -37807.708809396274;

    for (int AlCteOAvoTlT = 17086482; AlCteOAvoTlT > 0; AlCteOAvoTlT--) {
        srJog += mBAOhCAyT;
        mBAOhCAyT = srJog;
        GVWtylNKCB *= GVWtylNKCB;
    }
}

int kkynPXYsjihtB::tjqWXQrgCWlrcL(double fnLYYzPDUhWSq, int GWydTFm, string ffKUGITHtvc, bool nYlqxtfkrynUShu, int LINwIHyLtR)
{
    string CiPxKDFfJFHTraH = string("LbyiWLZKnmHZQJAGfKTNgyEXaEVNpLsbFOWpZQkZwcWKYrvDmxQTXMLsMsDuDsxDYLBWNUOizhgcMKpyMintqvFyMJeXVXvpkBgWwgaPnEpxnPLfrXYpJzztSbPcICadPOgSLXdhCFpCUTXZuwFFhMcBEldtXKlnPkImjHKrFHvVNyMfghaNuefVOvYHGkinIpXVprmubevqdfZULRFDXbZKRSBaTfEmqHOAacDejRgkxsKN");
    bool GnRwzfrnH = true;
    int PvURUNrbXoynHirL = 1025010276;
    double esBPYXjir = -319425.1769206369;
    bool dtEDVDKCgfQtiW = false;

    for (int HMcbYmbgdtOQieu = 519426016; HMcbYmbgdtOQieu > 0; HMcbYmbgdtOQieu--) {
        fnLYYzPDUhWSq -= fnLYYzPDUhWSq;
        dtEDVDKCgfQtiW = ! dtEDVDKCgfQtiW;
        fnLYYzPDUhWSq = fnLYYzPDUhWSq;
    }

    for (int ZUJBcqjYEBcYDJ = 1321482772; ZUJBcqjYEBcYDJ > 0; ZUJBcqjYEBcYDJ--) {
        GnRwzfrnH = ! dtEDVDKCgfQtiW;
    }

    return PvURUNrbXoynHirL;
}

void kkynPXYsjihtB::PQJAf(string NmJGqrVR, double CRPaGDJZLFHI, double wwDUVNDulqF, bool ombSrChxKvtFc)
{
    string sBYNRytSScNhsm = string("BgHbkZGVIkjJRMxHonCQVQElUxsUOCDvmErOBZELsJBwfkahivPtNNVSEootZWclCRgDEiWGuxM");
    bool HAkEag = true;
    bool jPKavlYAcNehiaHV = true;
    int WcItthIcdRquGpNE = 946760869;
    double ebhQW = 738972.7472638674;
    bool DvwbeWouhf = true;
    string hullE = string("FvyKHrNYlFUUqCRchUWaLmDSeyXDTBFJuuxbAxHmfqeEdUUWqdBkFIbxlfEmZIxpIekwDbqDhgcURoloUwpuVXeQCqInXaHsFTGQYYOuWJQdkLXPdaNlyLzztHMoMvmLfKJGJtgCpKBozkQgiqzrFiDuWGhnQxjnwqJNgBpEpmfwuVpLYAVzLnjSUchhxVWvGjYFmLHurbiKRxlmOJILyhRTzloHXoyDAPtvqBPJFSYhBFluhaJOoBtHemtg");

    if (CRPaGDJZLFHI == 738972.7472638674) {
        for (int yydFEsrB = 1885769386; yydFEsrB > 0; yydFEsrB--) {
            continue;
        }
    }
}

bool kkynPXYsjihtB::JzeyqRMc()
{
    string pdjhZtHMfTVvFPX = string("ntlOzMNuowcRLsotcRezpdqdOthlwNfOKwA");
    double PQRFeblh = -456130.3713064654;
    bool kQHKCbEpeEc = true;
    bool zOiipelZexWVy = false;
    bool SfvaNmEe = false;
    string nITZA = string("eWydGVRRwIoxyfSxhSrNewwMmvifKwJJUbbrIKcUfZERLoKqOyfxCGcAtzZXcZRCIQKQUQatuHuBQwutYkbFtBfrkpSzQfeDSLIHHcNUulAFFeEchiwsAwzwIPDjwbPejONtEAelSnSGdhRPydbFEyKrvOaxxEpqopAhdOCiLGDKPvKlyBKcFAvnKfl");
    double ZqHJToszobJN = 425411.7446341734;

    if (nITZA != string("ntlOzMNuowcRLsotcRezpdqdOthlwNfOKwA")) {
        for (int tSmHbDXjE = 2121795; tSmHbDXjE > 0; tSmHbDXjE--) {
            nITZA += pdjhZtHMfTVvFPX;
            zOiipelZexWVy = zOiipelZexWVy;
        }
    }

    for (int AmgSIyufmKjcqV = 1775547004; AmgSIyufmKjcqV > 0; AmgSIyufmKjcqV--) {
        nITZA += nITZA;
        ZqHJToszobJN -= ZqHJToszobJN;
        kQHKCbEpeEc = ! kQHKCbEpeEc;
        nITZA = pdjhZtHMfTVvFPX;
        zOiipelZexWVy = zOiipelZexWVy;
    }

    for (int QAmLiFIVS = 1419812301; QAmLiFIVS > 0; QAmLiFIVS--) {
        ZqHJToszobJN += ZqHJToszobJN;
    }

    for (int VzgeolVTHn = 370904634; VzgeolVTHn > 0; VzgeolVTHn--) {
        SfvaNmEe = ! SfvaNmEe;
        zOiipelZexWVy = zOiipelZexWVy;
    }

    return SfvaNmEe;
}

kkynPXYsjihtB::kkynPXYsjihtB()
{
    this->PLGFPjI(-827287959, true);
    this->eoyxcYJVNi(false, string("PdvedxyltsLUtCGwtSIKmJDggwVuUwEAEcDxIiWSyIZkGvZTXOMbImEJUyBdUqkYMaUTPuTlzWcwsCaJsIZpAJpAbRIglhpdHmtZlNnyoKrBEM"), true);
    this->InEci(true);
    this->bbvrXytBy(-1054632605, 731648.3381617118, -456053.4711925334);
    this->QccJlqnMSKDTAMzZ(true, true, false, true);
    this->gKbGPwcNnbYNOai(string("omZkYAnQbrgvNrbNdsBRaSJVgVTFesGzemDWAnAeSFcZdVrzQNByKXkNBjoqMyncaOiYNVxjCXgHmzlDexBLEZCqSeNAbfbhlyTAtyKLHDGanvXByCOlXBBjNLSmUUihYjpon"), -837208.6799144084);
    this->tjqWXQrgCWlrcL(268268.68751075864, 1647368412, string("kQWXgOnFYjjAOxjQsoVEsbqZcpZoOggoubUpHEnQQhNEmzSnMlXytlvEvXTjrWAtTGQlNiwcdnYKcCqnCdtkmhdewoGjSebKGJJIwTtAMvcRgKcSgSFNQEIZIijVDfJFGtZkQQnzURnJVOqirdrmEpBQiHJt"), true, 1473842049);
    this->PQJAf(string("YmxntUPglfhyEHNHVVTneeCSTPUbpwLxypnnGRDDBuyMDJTDjYudRHXCQHSCSCvTbjxSNBiiPsmwqYuxanyfWpgxTVxXHeCYcklaMkoggXeNTRcUoIyxQHifIhtpDJnqyOqYyOasGKqwpbvZPqiNHLMWwgdbTbBwGuDCOPdxXerNopHBIMfEFnyTJUNJXpYGELmAVKJpSLMzPToDKb"), -409707.936071694, 336255.75134862174, false);
    this->JzeyqRMc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HccurCQmCz
{
public:
    string YngNcEaVfGDQZYnF;
    double iVKPUyFTJHAzgUy;
    string oNfwQFBjfufvEDz;
    int UETre;
    int XdJVOBvIJhLYBY;
    double mkokCRC;

    HccurCQmCz();
    int wKfpodFTn(bool VQJkueC, double LlnmL, double PLMaG, double pqoKGOsHLqIBcJWE);
    int xOBqkqQVTCqMwI(bool AAZiMXRmTPr);
    string RikiItMc(bool IZVWTxEThKhFGMQM, double szUNfxotjqlcvEf, double mGYAdm, string rQQaygrThoxsm, int AgOVlR);
    string NItfucPQ();
    void MEZAWMEdeDWol(bool NCZCDnomCB, string birCDvBMuApvDA);
protected:
    string aYJSPwyS;
    bool SXzvdRIeuVftuKJ;
    string MJUSWVt;
    bool qdDwzANkcnJCX;
    bool hcqJh;
    bool WyHquGpRGKLKB;

    double ibucLLkilxIoEo(int OUFJrL);
    string UkHmWZnMfikmfJ(double coPeysNkdhAy, int qhLPUZqXDlFsRq, double AJpjR, bool keQjhVXEKPMCjWVt, double PVDUhaqirQemm);
    double NiGLPJylseno(bool OrNGtIuzrklYyD, string eLUfOybgnXAIUFTV, int tlFvthxcoxOZLL);
    string EsYhWBOKk(string BIRekyJ);
    bool SICqAdWYDKiR(bool VjoCKx, bool MyaTS, double qJLtBDlCwY, bool ECWkMTGJy, int xwYLTU);
private:
    string DnRgnC;
    double lMegiTz;

    string zjsFnNAEpLLiMhGJ(bool JVWBHtkPwlNk, bool ESjmHFYIatN, string xcmKdEkHTECPPb);
    int QBqxic(double ydHNvTQUzUPZLfvK, int koQRAPAigQqLmT, string QUqdUcZQQMgiBG, bool wqDCRdVgf);
    string IuJiCey(int xvznOjqe);
    int GHcOzDoF();
    void bPBtxYKS(double SMVYR);
    double UDIpmETbVpY(bool uKBsBf, string AqyvqvFtOtaS, int OzSzkYpwY, string dHvSKd);
};

int HccurCQmCz::wKfpodFTn(bool VQJkueC, double LlnmL, double PLMaG, double pqoKGOsHLqIBcJWE)
{
    string roCLavvEeBh = string("STiH");

    for (int ogMPVIT = 1341338712; ogMPVIT > 0; ogMPVIT--) {
        VQJkueC = VQJkueC;
    }

    if (LlnmL <= 1038866.8993887844) {
        for (int TrOXbjYy = 308628213; TrOXbjYy > 0; TrOXbjYy--) {
            VQJkueC = VQJkueC;
            roCLavvEeBh = roCLavvEeBh;
        }
    }

    if (pqoKGOsHLqIBcJWE < -340448.9056907132) {
        for (int gMAxdpL = 262975003; gMAxdpL > 0; gMAxdpL--) {
            pqoKGOsHLqIBcJWE -= pqoKGOsHLqIBcJWE;
            pqoKGOsHLqIBcJWE -= PLMaG;
            LlnmL -= LlnmL;
            pqoKGOsHLqIBcJWE *= pqoKGOsHLqIBcJWE;
        }
    }

    return -1252117944;
}

int HccurCQmCz::xOBqkqQVTCqMwI(bool AAZiMXRmTPr)
{
    string nmbnxjNKQMwnakh = string("jApdZxQXBNOybfkeQeqjIEWouyyobIlDqbHdbhtDimUCtwXqOdSMppFdQYjnwDkPaSaMfzMrBlMuYrBEtuIEHtMpMBeyDIJFUZakGGcjUjrwHPEgIcZfRLTIJQDAeUzfBfbkQskzVjPlydAFiwSWYNFrPVtUxPdJMLewDWyPBOvZPwMMnANjibtTALTvjgdzwHVaRxYngFhKOeka");
    int vvVRkXdafVwWVgj = 777828622;
    string IyVuOahZTauFlp = string("oAoXqfROPSDlxWurPDEuPAeHRbxHOtAEQzwyUdDfSmuAbvqn");
    int JNBgynMXQwMRTNj = 297768715;
    double uZIeJIVzMbohMc = -161294.63698200035;

    for (int jQzIsmRA = 1944134978; jQzIsmRA > 0; jQzIsmRA--) {
        IyVuOahZTauFlp += IyVuOahZTauFlp;
        JNBgynMXQwMRTNj += JNBgynMXQwMRTNj;
    }

    for (int KLCwA = 834202830; KLCwA > 0; KLCwA--) {
        continue;
    }

    return JNBgynMXQwMRTNj;
}

string HccurCQmCz::RikiItMc(bool IZVWTxEThKhFGMQM, double szUNfxotjqlcvEf, double mGYAdm, string rQQaygrThoxsm, int AgOVlR)
{
    int rYuLtsmrvOzVLW = 890684838;
    int GEjzbFY = -118673619;

    for (int cyCNfTxGpwoLf = 921974521; cyCNfTxGpwoLf > 0; cyCNfTxGpwoLf--) {
        continue;
    }

    return rQQaygrThoxsm;
}

string HccurCQmCz::NItfucPQ()
{
    bool iCetNsE = false;
    double HVaKppTJukLZ = 701042.7193628273;
    string qDeKb = string("OWEXHzdIzIftDVJAInCCygtHYaVoIZbTwRIYAGKWzpbiRPNshpfPqoJyeluCOnekjkrGLnapihLMdwNYoyeRQvMPexsQmGyYQoklk");

    for (int xVrFGwhdPpoC = 1125971502; xVrFGwhdPpoC > 0; xVrFGwhdPpoC--) {
        continue;
    }

    if (qDeKb > string("OWEXHzdIzIftDVJAInCCygtHYaVoIZbTwRIYAGKWzpbiRPNshpfPqoJyeluCOnekjkrGLnapihLMdwNYoyeRQvMPexsQmGyYQoklk")) {
        for (int uFXjDNzbufYqd = 823642653; uFXjDNzbufYqd > 0; uFXjDNzbufYqd--) {
            iCetNsE = ! iCetNsE;
            iCetNsE = iCetNsE;
            iCetNsE = iCetNsE;
        }
    }

    for (int zDaJjBA = 1627166755; zDaJjBA > 0; zDaJjBA--) {
        continue;
    }

    if (HVaKppTJukLZ != 701042.7193628273) {
        for (int uejWv = 131004878; uejWv > 0; uejWv--) {
            iCetNsE = iCetNsE;
            HVaKppTJukLZ *= HVaKppTJukLZ;
            HVaKppTJukLZ /= HVaKppTJukLZ;
            HVaKppTJukLZ = HVaKppTJukLZ;
            iCetNsE = iCetNsE;
            HVaKppTJukLZ += HVaKppTJukLZ;
        }
    }

    if (HVaKppTJukLZ != 701042.7193628273) {
        for (int ypIkgpasrX = 1028170266; ypIkgpasrX > 0; ypIkgpasrX--) {
            continue;
        }
    }

    for (int GjpfqjXxV = 697629741; GjpfqjXxV > 0; GjpfqjXxV--) {
        HVaKppTJukLZ -= HVaKppTJukLZ;
    }

    return qDeKb;
}

void HccurCQmCz::MEZAWMEdeDWol(bool NCZCDnomCB, string birCDvBMuApvDA)
{
    double rWYXAUwCOEuQYT = -578428.5781299697;

    if (birCDvBMuApvDA == string("tdDQATTaBPceaTufbAFdfdMySVnUepgIPyXkCacQqyeASKwJdWshsKaXsSBDTzypcXRqPXsSINRWlmffvyiGcrPMCFWBVplikwXcruUgyRFEGwEUJTOQAJbhGlPKdlOgcUmyAPjcIBwDnwjOyXpVVqPjkYMSLJTRGiPBEalkQQGMTkiXDSZdEduGDoDSbRHHRptOwl")) {
        for (int TfRXPjNrChPoBFnw = 596102444; TfRXPjNrChPoBFnw > 0; TfRXPjNrChPoBFnw--) {
            birCDvBMuApvDA += birCDvBMuApvDA;
        }
    }

    if (birCDvBMuApvDA > string("tdDQATTaBPceaTufbAFdfdMySVnUepgIPyXkCacQqyeASKwJdWshsKaXsSBDTzypcXRqPXsSINRWlmffvyiGcrPMCFWBVplikwXcruUgyRFEGwEUJTOQAJbhGlPKdlOgcUmyAPjcIBwDnwjOyXpVVqPjkYMSLJTRGiPBEalkQQGMTkiXDSZdEduGDoDSbRHHRptOwl")) {
        for (int bBbEALGQwL = 369107228; bBbEALGQwL > 0; bBbEALGQwL--) {
            NCZCDnomCB = ! NCZCDnomCB;
            birCDvBMuApvDA += birCDvBMuApvDA;
        }
    }

    for (int zFCADvfowXvlefof = 494084223; zFCADvfowXvlefof > 0; zFCADvfowXvlefof--) {
        rWYXAUwCOEuQYT = rWYXAUwCOEuQYT;
        NCZCDnomCB = ! NCZCDnomCB;
    }
}

double HccurCQmCz::ibucLLkilxIoEo(int OUFJrL)
{
    int tjUjXFnRopJTR = -1949395788;
    double plpSTfpJBTP = -580971.0660189631;
    int vIIFiFc = -1303454223;
    bool XypFG = false;
    string oPmQFIlhuRyIChwF = string("UjEilwEIuVefYLQDZOjDEJLgdZLlHATnZVIKxdtkNTHvqpZTHuJEnCsBwJfOJDGoNQkKAuoBKUSccJWeeCKvgmAiLAwLTDMvxPUyMIQdTugWwGHlVkdEaRfwvEaTcSgORYamnrrWKTGYxjRbfLHBSEFtAljyamHQdLjOYhRFAxEPHxh");
    int nDWbQBNfnkm = -179011984;

    for (int MVEzJhrf = 2100379074; MVEzJhrf > 0; MVEzJhrf--) {
        nDWbQBNfnkm = vIIFiFc;
        tjUjXFnRopJTR = tjUjXFnRopJTR;
        vIIFiFc *= tjUjXFnRopJTR;
        vIIFiFc += nDWbQBNfnkm;
    }

    return plpSTfpJBTP;
}

string HccurCQmCz::UkHmWZnMfikmfJ(double coPeysNkdhAy, int qhLPUZqXDlFsRq, double AJpjR, bool keQjhVXEKPMCjWVt, double PVDUhaqirQemm)
{
    double jluslzfqAvEqT = -265962.88853015983;

    for (int FBTzmurikgek = 1278807480; FBTzmurikgek > 0; FBTzmurikgek--) {
        AJpjR += PVDUhaqirQemm;
        coPeysNkdhAy /= jluslzfqAvEqT;
        AJpjR = coPeysNkdhAy;
        qhLPUZqXDlFsRq += qhLPUZqXDlFsRq;
    }

    if (PVDUhaqirQemm == -265962.88853015983) {
        for (int wLzoLhBIv = 1476271344; wLzoLhBIv > 0; wLzoLhBIv--) {
            AJpjR += PVDUhaqirQemm;
            AJpjR *= AJpjR;
        }
    }

    if (coPeysNkdhAy == 388274.1148796136) {
        for (int WvhPXihPSTecmI = 148815338; WvhPXihPSTecmI > 0; WvhPXihPSTecmI--) {
            jluslzfqAvEqT -= coPeysNkdhAy;
            AJpjR += jluslzfqAvEqT;
        }
    }

    for (int Yanuvxq = 311359544; Yanuvxq > 0; Yanuvxq--) {
        jluslzfqAvEqT = jluslzfqAvEqT;
        AJpjR /= coPeysNkdhAy;
        jluslzfqAvEqT += AJpjR;
        jluslzfqAvEqT *= coPeysNkdhAy;
        keQjhVXEKPMCjWVt = ! keQjhVXEKPMCjWVt;
    }

    return string("QOzgxgBtYZhQkWQfXmSIHHpJfWhelvphXXvr");
}

double HccurCQmCz::NiGLPJylseno(bool OrNGtIuzrklYyD, string eLUfOybgnXAIUFTV, int tlFvthxcoxOZLL)
{
    int IrcqURKPBuOWBLTP = -108869801;
    bool RqPVnQdAvf = false;

    for (int wUrgXKmHgkr = 1428931901; wUrgXKmHgkr > 0; wUrgXKmHgkr--) {
        tlFvthxcoxOZLL -= IrcqURKPBuOWBLTP;
    }

    for (int DnviCaIgEYwt = 110628777; DnviCaIgEYwt > 0; DnviCaIgEYwt--) {
        continue;
    }

    for (int ajCEHNmWvf = 26843990; ajCEHNmWvf > 0; ajCEHNmWvf--) {
        continue;
    }

    for (int bjyBWkZSgdf = 889496528; bjyBWkZSgdf > 0; bjyBWkZSgdf--) {
        continue;
    }

    return 139787.97258516628;
}

string HccurCQmCz::EsYhWBOKk(string BIRekyJ)
{
    double JvhaMzSnUzf = -544767.9046019543;

    if (JvhaMzSnUzf <= -544767.9046019543) {
        for (int lhywoDwjSFEf = 1307256181; lhywoDwjSFEf > 0; lhywoDwjSFEf--) {
            JvhaMzSnUzf *= JvhaMzSnUzf;
            JvhaMzSnUzf -= JvhaMzSnUzf;
            BIRekyJ += BIRekyJ;
            BIRekyJ += BIRekyJ;
            BIRekyJ = BIRekyJ;
            BIRekyJ = BIRekyJ;
        }
    }

    if (BIRekyJ >= string("SKlQtBFMYUUCrfBvqWzcfdWkavzhfY")) {
        for (int BneEbqkSTirWDJ = 1194700959; BneEbqkSTirWDJ > 0; BneEbqkSTirWDJ--) {
            JvhaMzSnUzf -= JvhaMzSnUzf;
            JvhaMzSnUzf = JvhaMzSnUzf;
            JvhaMzSnUzf += JvhaMzSnUzf;
        }
    }

    if (JvhaMzSnUzf <= -544767.9046019543) {
        for (int AelsndAwmPrEXVc = 373468926; AelsndAwmPrEXVc > 0; AelsndAwmPrEXVc--) {
            JvhaMzSnUzf += JvhaMzSnUzf;
            BIRekyJ += BIRekyJ;
            JvhaMzSnUzf -= JvhaMzSnUzf;
            JvhaMzSnUzf /= JvhaMzSnUzf;
        }
    }

    return BIRekyJ;
}

bool HccurCQmCz::SICqAdWYDKiR(bool VjoCKx, bool MyaTS, double qJLtBDlCwY, bool ECWkMTGJy, int xwYLTU)
{
    double SlaRJuBqnkyZeId = 424583.9702120113;
    int TRYet = -1748060465;
    bool uMxZnMPqUhLTTqer = false;

    if (uMxZnMPqUhLTTqer == false) {
        for (int VUabQGroWSIGhiIu = 1756038952; VUabQGroWSIGhiIu > 0; VUabQGroWSIGhiIu--) {
            ECWkMTGJy = MyaTS;
            qJLtBDlCwY /= qJLtBDlCwY;
            ECWkMTGJy = ! VjoCKx;
            VjoCKx = VjoCKx;
        }
    }

    if (MyaTS != false) {
        for (int cmGyqNTZmgOXUI = 1855024729; cmGyqNTZmgOXUI > 0; cmGyqNTZmgOXUI--) {
            continue;
        }
    }

    for (int FMmjYDHifO = 112102204; FMmjYDHifO > 0; FMmjYDHifO--) {
        SlaRJuBqnkyZeId += SlaRJuBqnkyZeId;
        SlaRJuBqnkyZeId *= SlaRJuBqnkyZeId;
        SlaRJuBqnkyZeId = SlaRJuBqnkyZeId;
    }

    for (int jhwkNvHz = 320889114; jhwkNvHz > 0; jhwkNvHz--) {
        xwYLTU = xwYLTU;
        VjoCKx = ! ECWkMTGJy;
    }

    for (int RIwZHey = 1228900377; RIwZHey > 0; RIwZHey--) {
        continue;
    }

    return uMxZnMPqUhLTTqer;
}

string HccurCQmCz::zjsFnNAEpLLiMhGJ(bool JVWBHtkPwlNk, bool ESjmHFYIatN, string xcmKdEkHTECPPb)
{
    bool IgntZYZURunA = false;
    string KEWQHRJSEZ = string("wejxoWSJPrDGRvOYIluRJjeAMivcTuytNQpHRXiukhVsAFxMmPJYDuyMCmbUjIyCzXcptGWEtWvrVyiXocshUZNNbHccYtxEwTObIVqCojNvic");
    int GGoEijMP = -550417139;
    double HLooHMylSGOb = -34307.143588033076;
    double seEfqCDxho = 333981.4707240005;
    double chnjjhjiMdQNH = 584131.5790337278;
    int GQejwOXcIsDNPow = -249436210;
    double QZPXOb = 1006620.3073128706;
    double SpoKYc = -924887.7575600354;

    for (int MLTxVCar = 1201900624; MLTxVCar > 0; MLTxVCar--) {
        seEfqCDxho += seEfqCDxho;
        seEfqCDxho *= QZPXOb;
    }

    if (QZPXOb == 1006620.3073128706) {
        for (int KigIk = 373459657; KigIk > 0; KigIk--) {
            xcmKdEkHTECPPb += xcmKdEkHTECPPb;
            KEWQHRJSEZ = KEWQHRJSEZ;
        }
    }

    for (int FSKxKwRsekYB = 1901803420; FSKxKwRsekYB > 0; FSKxKwRsekYB--) {
        HLooHMylSGOb *= seEfqCDxho;
        HLooHMylSGOb /= QZPXOb;
    }

    for (int wkWZHuvyEeblgr = 1751732701; wkWZHuvyEeblgr > 0; wkWZHuvyEeblgr--) {
        ESjmHFYIatN = ESjmHFYIatN;
    }

    return KEWQHRJSEZ;
}

int HccurCQmCz::QBqxic(double ydHNvTQUzUPZLfvK, int koQRAPAigQqLmT, string QUqdUcZQQMgiBG, bool wqDCRdVgf)
{
    string FDrKN = string("eVljLxXpwqDATeqvDhfeEETJQjboBzoARQSTHWxXOQSkzUfTGzxoedndKBcEkzyZvcLvVNfZKlzujAaGuFEnGeByVXbRRDOPoqdBZGutwMekcLoADHubryjpenTPxxrPDTibSHGXNctQZAPaADeZMcSKyaeBBrHNNGFulur");
    bool SJYNN = false;
    bool JZGxDRuMj = true;
    int lGbtaVyKDRZEvZrr = -1813772608;
    int AbXgJyBE = -974377432;
    string chvCMYjSbC = string("gbTRyLwtHgQtCfsTJZEIksiYIWimnHhVsycGrKNZFhRyAhcWDkMzPcyTSPhtMawpiAIFOndajqGdOItyCuAhCZgoBlxtFXifHAoONXTQRBVPvvzfaThyARJurQdxSUvNOWJuPxnDTtvGNLUoiBAnKwvYeERhRRaOWTZHRk");
    int TVZxXRCBurBM = 1025453139;
    int LZrWUuBGzs = -1320563151;

    for (int WVYQxVJCzJdQlT = 1485893556; WVYQxVJCzJdQlT > 0; WVYQxVJCzJdQlT--) {
        continue;
    }

    for (int YIkRo = 138722846; YIkRo > 0; YIkRo--) {
        TVZxXRCBurBM -= AbXgJyBE;
    }

    for (int ikWhsLia = 2101741594; ikWhsLia > 0; ikWhsLia--) {
        koQRAPAigQqLmT -= LZrWUuBGzs;
        chvCMYjSbC += FDrKN;
        wqDCRdVgf = JZGxDRuMj;
        FDrKN = QUqdUcZQQMgiBG;
        AbXgJyBE += TVZxXRCBurBM;
    }

    return LZrWUuBGzs;
}

string HccurCQmCz::IuJiCey(int xvznOjqe)
{
    int vXDSL = -1976511965;
    int GkVvl = -1382327094;
    int lmLwMc = 1855828901;
    int xHObDjDzIxAhrt = 1715211788;
    double OegffCblWqxMiqLw = 296641.9057010567;
    string sCgCJYMQNILvH = string("yEIixDGZxNKedYGdQdZVtVFXOdoLeuZBnBMlAJRnTUlKpJWTdQSdhOzCcfz");
    int QXBrTwqZKPkYyma = 1782985822;
    double zsNfltXqKltRTWRw = 1373.5390133859385;
    int daUUHK = 1282475006;
    bool GfMUDTEbdPkVNq = true;

    return sCgCJYMQNILvH;
}

int HccurCQmCz::GHcOzDoF()
{
    int hKCXMSLLZP = -1734134616;
    bool ekyOBQ = false;
    int sZVbzwcWSf = -747523271;
    int iHxkuvVZHwWXoZ = 2025641392;
    int BevDSnFCxgpr = -2118285702;
    double HepCdZnqH = -156459.07901708837;
    string TMqPl = string("vnnIBYUhjYhYnLzTwZMmYivXSjnDvrAoYvcQphQgBPMbDTfNumSzOfHqXYQFyhPCuJMhowuqmQeMQUxCEJUlzXEyoHKmkLKsbxpeJjamWRYwEjJfnhJtqWcgcQjtlxOCBVYcvyBPjQybgUthhlcXLmcODatnCbnWKZ");

    if (ekyOBQ == false) {
        for (int HVNbeHK = 1442491446; HVNbeHK > 0; HVNbeHK--) {
            iHxkuvVZHwWXoZ += hKCXMSLLZP;
            iHxkuvVZHwWXoZ *= BevDSnFCxgpr;
            iHxkuvVZHwWXoZ /= hKCXMSLLZP;
        }
    }

    if (iHxkuvVZHwWXoZ >= -747523271) {
        for (int EsVBpoQgQdWpp = 350712545; EsVBpoQgQdWpp > 0; EsVBpoQgQdWpp--) {
            HepCdZnqH *= HepCdZnqH;
            iHxkuvVZHwWXoZ = sZVbzwcWSf;
        }
    }

    return BevDSnFCxgpr;
}

void HccurCQmCz::bPBtxYKS(double SMVYR)
{
    double aJCJZlSCYYZa = -98293.62861939953;

    if (aJCJZlSCYYZa <= -136620.97133753408) {
        for (int oBKagBQIwTNLNipD = 1478097959; oBKagBQIwTNLNipD > 0; oBKagBQIwTNLNipD--) {
            SMVYR += SMVYR;
            aJCJZlSCYYZa /= SMVYR;
            aJCJZlSCYYZa -= aJCJZlSCYYZa;
            aJCJZlSCYYZa /= aJCJZlSCYYZa;
        }
    }

    if (aJCJZlSCYYZa <= -136620.97133753408) {
        for (int BrFZuPfRH = 1604904582; BrFZuPfRH > 0; BrFZuPfRH--) {
            aJCJZlSCYYZa += SMVYR;
            aJCJZlSCYYZa /= aJCJZlSCYYZa;
            aJCJZlSCYYZa += SMVYR;
            SMVYR -= SMVYR;
            SMVYR -= aJCJZlSCYYZa;
            aJCJZlSCYYZa += SMVYR;
            aJCJZlSCYYZa = aJCJZlSCYYZa;
            aJCJZlSCYYZa = SMVYR;
            SMVYR = SMVYR;
        }
    }

    if (aJCJZlSCYYZa != -98293.62861939953) {
        for (int lAWaY = 1438324654; lAWaY > 0; lAWaY--) {
            SMVYR = SMVYR;
            aJCJZlSCYYZa = aJCJZlSCYYZa;
            aJCJZlSCYYZa = SMVYR;
            SMVYR = aJCJZlSCYYZa;
            SMVYR -= SMVYR;
            aJCJZlSCYYZa += aJCJZlSCYYZa;
            SMVYR -= aJCJZlSCYYZa;
        }
    }
}

double HccurCQmCz::UDIpmETbVpY(bool uKBsBf, string AqyvqvFtOtaS, int OzSzkYpwY, string dHvSKd)
{
    double jmknEYcjUTHYF = 484709.5692219241;
    int MtJRmUIEU = -1518287973;
    string vKMsx = string("kGonOZhEuPDsqdtUUdqTkGJNUpHUMXeTJQpybOUMrfCxaptQTmnZnOg");
    string beSSjWMHJM = string("UeBBrgvuwbnQyRSrlVfZOEshCtgKucvSzaYzHGXiHZkgYstAfQbiHCuQbcqskLUvSHynNVmCeKkNIRryqxIzZtPIkQihbKJU");
    int SpRzNdNS = 2005108304;

    for (int TwVjrPZgFdOX = 1428542632; TwVjrPZgFdOX > 0; TwVjrPZgFdOX--) {
        AqyvqvFtOtaS += dHvSKd;
    }

    for (int FYScUgawqQYLcEob = 457575728; FYScUgawqQYLcEob > 0; FYScUgawqQYLcEob--) {
        AqyvqvFtOtaS = vKMsx;
        jmknEYcjUTHYF *= jmknEYcjUTHYF;
        AqyvqvFtOtaS += vKMsx;
    }

    for (int nZaADIhy = 229592708; nZaADIhy > 0; nZaADIhy--) {
        continue;
    }

    if (dHvSKd <= string("QXOzhFCgMsDIRzpbjmOWZXjeYXMcmrVkrqoKUCYFwNLyTGisDUPjhubNzOHrrgttuLNgTbDVwFMjPHLeGwBwdUrBEiYqSARlRCtxvEqTPHanKpykAjqUHNIfDFgwwMvnWHslVsypPfTifCElsJgYrPrJxdfQTuNjjFUermkZVIZmyRUQQJauLSqpLZcEBXolDsszDZRS")) {
        for (int QoNHsH = 1225197938; QoNHsH > 0; QoNHsH--) {
            AqyvqvFtOtaS += beSSjWMHJM;
        }
    }

    if (OzSzkYpwY > 2005108304) {
        for (int ZmZowPJmcGa = 2095021225; ZmZowPJmcGa > 0; ZmZowPJmcGa--) {
            vKMsx = AqyvqvFtOtaS;
        }
    }

    for (int jdnaAJSt = 1915802440; jdnaAJSt > 0; jdnaAJSt--) {
        SpRzNdNS += MtJRmUIEU;
        SpRzNdNS *= OzSzkYpwY;
        vKMsx += vKMsx;
    }

    if (MtJRmUIEU != -1518287973) {
        for (int ILXQZ = 450254875; ILXQZ > 0; ILXQZ--) {
            beSSjWMHJM += beSSjWMHJM;
            OzSzkYpwY = SpRzNdNS;
        }
    }

    for (int eevHZrKgQwjaySzz = 1871094629; eevHZrKgQwjaySzz > 0; eevHZrKgQwjaySzz--) {
        vKMsx = beSSjWMHJM;
        SpRzNdNS /= MtJRmUIEU;
        beSSjWMHJM = vKMsx;
    }

    return jmknEYcjUTHYF;
}

HccurCQmCz::HccurCQmCz()
{
    this->wKfpodFTn(false, -340448.9056907132, 304810.99787638744, 1038866.8993887844);
    this->xOBqkqQVTCqMwI(false);
    this->RikiItMc(false, -17458.968855501716, -846150.448937494, string("qQqeAiwzKDXMUurlRcKiAriOiBLqgmcsvFVpZIWqfZEIQnDUFbRKDWfdKiGmfWNNPDjvgZLhVALfBrytHOYxBzAzhLROQmqXuZDhtKirLMxVmsVuduvnRILDfDrjXuStQZKxQpIbqJHgETeLgUGEHOlchvnZJOrrfWhF"), 1811250901);
    this->NItfucPQ();
    this->MEZAWMEdeDWol(true, string("tdDQATTaBPceaTufbAFdfdMySVnUepgIPyXkCacQqyeASKwJdWshsKaXsSBDTzypcXRqPXsSINRWlmffvyiGcrPMCFWBVplikwXcruUgyRFEGwEUJTOQAJbhGlPKdlOgcUmyAPjcIBwDnwjOyXpVVqPjkYMSLJTRGiPBEalkQQGMTkiXDSZdEduGDoDSbRHHRptOwl"));
    this->ibucLLkilxIoEo(2036254910);
    this->UkHmWZnMfikmfJ(388274.1148796136, -1107371388, -847288.2423311059, true, 614857.8803810404);
    this->NiGLPJylseno(false, string("rkryfwCzLeZkszNIYeBugZnCukUJjnrSsTVcPQLSAkgyTNWilBlTMTsCchfSSDrUqzueJULSwJwCpLAcvwsv"), -1472024761);
    this->EsYhWBOKk(string("SKlQtBFMYUUCrfBvqWzcfdWkavzhfY"));
    this->SICqAdWYDKiR(false, true, -224940.95164233376, false, 1017286290);
    this->zjsFnNAEpLLiMhGJ(false, true, string("MIhxkJpzhEsotYhIWZOLlrFpgQeZDfeJNtzzVTfwjzaKjQQHCEopPaqMpwCKUfMEfQdFiBfJqiZbDlWCHFbjyVJLFmstxZwVXCFOXbIAHIIFAOQezbbkblSFmVNjzqrncXrlwvvJMAdTppxRIqAVvsPqKNTPIwFXxJ"));
    this->QBqxic(-853993.54089429, -1542655120, string("seBcfYKevgDcXHwtZzNXCdBMqwDngJGRf"), true);
    this->IuJiCey(504970848);
    this->GHcOzDoF();
    this->bPBtxYKS(-136620.97133753408);
    this->UDIpmETbVpY(true, string("iQshionpmvnKnCLZOOaDkEMLbUYUAQdtAvqgcTvajuMQDKoyxPFOhpexxqhLbLkxRVYngBouydXFrMXXRopTrSBthaMfSEOHDdzpcPEgaRjQuLzrgKMceyOxqmkRhKQGavSEdDltwGLYKFhpdCeWasCZIvXsaxbmjCJvVYUvEEAASHVRBXlXXXIMKGpgOvCFZCTBW"), 1423967761, string("QXOzhFCgMsDIRzpbjmOWZXjeYXMcmrVkrqoKUCYFwNLyTGisDUPjhubNzOHrrgttuLNgTbDVwFMjPHLeGwBwdUrBEiYqSARlRCtxvEqTPHanKpykAjqUHNIfDFgwwMvnWHslVsypPfTifCElsJgYrPrJxdfQTuNjjFUermkZVIZmyRUQQJauLSqpLZcEBXolDsszDZRS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MXRsBszUV
{
public:
    bool WqGHvjeovNZRT;
    bool ZaXsLqtMpdEQ;
    int YSSIUnUiRG;

    MXRsBszUV();
    int OqSKXJZidm(int sQNszITuf, double yAJKsYjQGAlLhQ);
    bool kkcCk();
protected:
    double yRLrAsWjyqrOyuf;

private:
    string vBvMRbmAAAhwNDT;
    bool KGctPVguhoNjFK;
    double SUmgSloQQzQYH;
    string SujnxNcBWjMCr;
    double aXlCJTDkl;

    double ISRFsOhkqyCIkGI(double drvgOJMRXOCoiO, string EdsszBfN, double tuRGjQpSIJuLY);
    void hpyGYFwYYGOJcqjX(string lIkECEMkIeCSReB, double wUIyzai, bool mpGESJ, int JXbiuEZamtDb);
    bool tVuYAAVflv(double ctfTO, int ipXcoqrYmSCdGlM);
    bool jltLzuLCJkbphx(string imQlGKOuirTPrJ);
    bool jiOUqOwrh(double gBxiwY);
    double AsEtPrnxdDhuowI(int ETAfOHjg);
    bool adHFuTBR(int BVtyyyc, string KOVyCmUHetADoeSr, string gdIHD, int PXGAcGYFrIsA, int NlFQeKnrwrWNukZQ);
    string gHLXcdJKTCfbhn(double zdaRvEEWLrPxcepX, bool xwoUZycS);
};

int MXRsBszUV::OqSKXJZidm(int sQNszITuf, double yAJKsYjQGAlLhQ)
{
    string JcFMdKAtBRk = string("dZHiugmjaXKdnVQOhgYYYisllkKwnQHpTkFoIeeuqFkqXDPGrlDlUxzBCprqrfnImbUuCxgtAMMAEVQMTmwpkLhJRnocnIShNHXCaGNBXmmuKHsWwDitSKCadIpqkkvKLlbObknVoulUjSdDBwhzsndsqLgjvXvChtjCrrLulqxgEZVDimfQjUsvGHzEMAOttXl");
    double xuvFTpE = -554970.7904182314;
    bool wtFkVrMLdtAd = false;
    int RbUyvMRC = 365665056;
    string ZKMolHX = string("HaNiRXIqkhZMHsyKUOjTCzaCcaeaLfztEiYtxhvsLZocIhYVNThOgdFbqliXICIGWuTMcbnZRiMQCCRfjYZoUpvWRttLFGDNjkCYJPTuvatntiStVsPaTdyTvVgvcnbwvWCFoVtmaHZzBfiLiPdZRwoQlQEMjGKUcdEiahsjweQnxuLSnqatGBOURVUqPNoVaXoqvOyXoDZpYRriemZefLUcLjXKpLDLhggqadEiZ");
    bool TsWIq = true;
    bool ZKiLPOCuwWbcfuL = false;
    double eEgLpngCdtnnQbm = -111461.64803990006;
    bool WAxmMxDKGEjMywDM = true;

    for (int WeZESEiaygFCS = 1818148532; WeZESEiaygFCS > 0; WeZESEiaygFCS--) {
        continue;
    }

    for (int hgNNQdpcTZTaYp = 912475643; hgNNQdpcTZTaYp > 0; hgNNQdpcTZTaYp--) {
        wtFkVrMLdtAd = ! wtFkVrMLdtAd;
        WAxmMxDKGEjMywDM = ZKiLPOCuwWbcfuL;
    }

    for (int XjCWAS = 2085878341; XjCWAS > 0; XjCWAS--) {
        ZKMolHX = ZKMolHX;
        ZKiLPOCuwWbcfuL = ! ZKiLPOCuwWbcfuL;
    }

    if (WAxmMxDKGEjMywDM == false) {
        for (int iIAYxnBOUurTh = 1339681537; iIAYxnBOUurTh > 0; iIAYxnBOUurTh--) {
            ZKiLPOCuwWbcfuL = TsWIq;
        }
    }

    return RbUyvMRC;
}

bool MXRsBszUV::kkcCk()
{
    bool sIjEO = false;
    string KpfgZhlLU = string("kEIqWegnBassZMPeEMdyqfnfeoKUzfgHioSYzwLUbmwGoxkAfMflJjXnpmoxulzKDkukVYpvtIXWJCAxOaMnTM");
    double fPEIdo = -376417.2046728129;
    double bcuqF = 568221.97113439;
    double MjuwIGJXAsWzGNSn = 125824.77036855517;
    string QXabaqUcLdsLV = string("XhoJwfSsUUTMWzRTSwqPhqRAYxTemENHPoMXrRaiZmFbmADVVhlUdrjeQIqXPuZQzJWuEKzXqgMXcnHPSHEOHXXqKMSKsiFHwKLkayVikWkCMZJW");
    bool CueDxbMbMrxdMVIM = true;
    string PgzvObV = string("DTohvwiRAYBscMhqfVJILyQNyPgKMYiyfNOjkbntJmrkKNnFkAYsgNBLiuLKFQqvMRLsTDNGXlobEGpAiYsODlCgDUaJncSGGmblsFNHJQaAujByGDhaBykXiYPEhBNFokcnasLrBdNFIJKXBgHxfgzbZgXOYDSBOqmRRgphIDFNwwjxxStsAVCGCGzGesZHbatCxN");
    double yYwHwb = -940003.4586019568;

    for (int OEoOxthi = 1042691688; OEoOxthi > 0; OEoOxthi--) {
        QXabaqUcLdsLV += QXabaqUcLdsLV;
        QXabaqUcLdsLV = KpfgZhlLU;
        yYwHwb += yYwHwb;
    }

    return CueDxbMbMrxdMVIM;
}

double MXRsBszUV::ISRFsOhkqyCIkGI(double drvgOJMRXOCoiO, string EdsszBfN, double tuRGjQpSIJuLY)
{
    string rRNlcxIf = string("bpiBMWjJYynurwUdjAstkkSiimADwPfHHuDeTtfArOJXmsgRVHTjtKAtljntKFvyFQgiumyqcHSpHzBGMWQDmnXishWHuUzMgiQwKRvsWLpQPnbHBSVuzVlMgwQduyhbWhNCSpKxoeSgBjEsBKrjspmtcjqQdEkoMmtCuMEwlIpsStfuYQXtMNeLcadXJYNKspqzroHxGdfaMfCwzAi");
    double DSzqAEzak = -965863.6888476482;
    bool qHSVLrUbnGhCax = false;
    int BlqclFaawQK = -1938121644;
    bool obKoHqrluM = false;
    int rcmtOhRZsQDaY = 1252367571;
    string fTwTH = string("RaSynlHHYwPsyjHUbDarmjMFTSejROxxpAOIkIcvxUwTFIJIrWRALdHtxRGLgdUQwcaPExbhAUeAwXTMJkddeyuMGfVYBoQJDNnJUISmTzEvmkqfKQIFkRGSfRcLtqDrODHBLtAiCrCymcuLhENnBLJTUdEFkUepzGtLwHIaSkcjXwLbSUqemXBOzDgrHqFGyzMydUOeyGaOZeHqcmxbgtEQDXPBdlxEzuwAPqXkcgxVxLyc");
    int GdulOBqWxhYLGHHK = 121455910;
    string KMaFbFdEMn = string("TixXvLFYGOUJCInxdgFJTqOvlzXXvZXBSQSwVwoooiahqGnnJllRoZrAnybqLcuOafzCUGdqCxnPULRkOuqZtDxrPeulBeDxYqsBwUFFMZdJujyzMIRpWWpoWXURXJJoaXoHVDnmQUurZZdkaqkoYTyNrXhOaCBExvopDJdXslUkkomUrYMjimmYYfEJnPM");
    double TnVDlKncGPPDgzp = -338444.99478157796;

    for (int uZzGfBNRI = 300411682; uZzGfBNRI > 0; uZzGfBNRI--) {
        continue;
    }

    return TnVDlKncGPPDgzp;
}

void MXRsBszUV::hpyGYFwYYGOJcqjX(string lIkECEMkIeCSReB, double wUIyzai, bool mpGESJ, int JXbiuEZamtDb)
{
    int AtzuqgZtQpGUqBE = -1062856232;
    bool mcHKBsPbOztHKBa = false;
    double uSsdyIZYII = -272468.0916757442;
    string GwidKCkwbCzZNdc = string("haphvKZyMzGWWmnwjw");
    bool rHsVPMyKXRyhG = true;
    string NlUSwZ = string("CfjdeW");

    for (int FVebBBEhXT = 337604736; FVebBBEhXT > 0; FVebBBEhXT--) {
        AtzuqgZtQpGUqBE = JXbiuEZamtDb;
        GwidKCkwbCzZNdc += lIkECEMkIeCSReB;
        GwidKCkwbCzZNdc += GwidKCkwbCzZNdc;
    }

    for (int glhsH = 1695280147; glhsH > 0; glhsH--) {
        mcHKBsPbOztHKBa = rHsVPMyKXRyhG;
        GwidKCkwbCzZNdc = lIkECEMkIeCSReB;
    }
}

bool MXRsBszUV::tVuYAAVflv(double ctfTO, int ipXcoqrYmSCdGlM)
{
    double rFWemgan = 527112.6966971699;
    bool rYfVofrwi = true;
    bool mHkLYxFegNxd = false;

    for (int unHMuuIjEnPd = 1393432011; unHMuuIjEnPd > 0; unHMuuIjEnPd--) {
        rFWemgan *= rFWemgan;
    }

    return mHkLYxFegNxd;
}

bool MXRsBszUV::jltLzuLCJkbphx(string imQlGKOuirTPrJ)
{
    int zNLPrDqwFmbNkvyf = -675788729;
    int iFxylkm = -31047517;
    string JsupLLcgZ = string("uRPEaKmRkmJwxAKmnbuhDJQNeqXIWYFQxahhtuIogKMbaYHjyHlgeiJmHAoPaROWvjaNNOKobUorabRLmrawekgaWNsYakWFNavtnxHRrebPjzHiIzeplwoghKrSUpvWZmbPUCCsODUJpLtQbozEaxkiHwytgIrauHuTNoUZWyvbJXTSaUEEeREndEPodpAZLFe");

    if (iFxylkm > -675788729) {
        for (int cJMnNEy = 1335795407; cJMnNEy > 0; cJMnNEy--) {
            imQlGKOuirTPrJ = imQlGKOuirTPrJ;
        }
    }

    if (JsupLLcgZ <= string("uRPEaKmRkmJwxAKmnbuhDJQNeqXIWYFQxahhtuIogKMbaYHjyHlgeiJmHAoPaROWvjaNNOKobUorabRLmrawekgaWNsYakWFNavtnxHRrebPjzHiIzeplwoghKrSUpvWZmbPUCCsODUJpLtQbozEaxkiHwytgIrauHuTNoUZWyvbJXTSaUEEeREndEPodpAZLFe")) {
        for (int hWlYtzogybbCh = 2038147025; hWlYtzogybbCh > 0; hWlYtzogybbCh--) {
            JsupLLcgZ = JsupLLcgZ;
        }
    }

    return true;
}

bool MXRsBszUV::jiOUqOwrh(double gBxiwY)
{
    string iXmbwaGloxsoopSo = string("HyEDkgZZgCDfWuvDjQloDwkCqDGheoWMCmyPVtLbtvRUDoNCbRSFQCbQFoyIftNWNghcTnkyueTVttUwXzrbWNkzatzmNXYjTbsepXRwhtoZWWUuWUJxpKGuxZAJ");
    string ixdJS = string("iBhXYwRranhiBcNSwFBrPGzsdvZphIrnTMCNsgQEbcpLwjVMtZEptghbrhIAqjBafwasPsSmIzZCazlUzNSgIPVJkOHwyypfQvZQIsEDvvcsBTXKthoYOtEIAwPPBgjPizCcbpXfRtSHMHUGyAmpOmBQwYDgnm");
    int otyfJlJAXW = 892209231;
    string gAaJiPnoWqGopp = string("cuqpKTHrfGfnSaMcmyZlRJbdSMPAuOgTMtjJdhJIPmZHwCJOvpBePcWQtuQwEESyGckKBeWTMnIASwFXNwLJqKQYycvPzYIRUyCQWiKRWzlQwjeWzjBbNRkDVfhAOmGNNQFugmeLjyhmwTPuTVodOKGhKtfNSTBllkMhTJlvkYUprifSkYsuEsUIBolISBElqVreuawByvSbrNFkisRSKEImKJNoZjsTFxbhizJoGuNbsVACmWF");
    bool dMXVkoOxU = true;
    bool SDqoBcKWZQaqjHkQ = true;
    bool KFPiUAtdwTMV = false;
    string tJCjQiyovPv = string("GzZtLpBgkLUdNOLavOMOfLAntwFxVvOZaFuVnsCrLugvBikLqzvcKlQyqdEgDcobTezJDOLMCLoWLusiEQllOMdfluNEkNeeuOhwhxGSYdSFctPXZlIxQNNsfiknCyvxNwIITcYcjGlnkNPRKLwLfZWdrKhNhGDMqXkecTm");

    if (KFPiUAtdwTMV != true) {
        for (int PPDEqOVRrgwk = 1247028265; PPDEqOVRrgwk > 0; PPDEqOVRrgwk--) {
            iXmbwaGloxsoopSo = iXmbwaGloxsoopSo;
            ixdJS = gAaJiPnoWqGopp;
            iXmbwaGloxsoopSo += tJCjQiyovPv;
            SDqoBcKWZQaqjHkQ = ! KFPiUAtdwTMV;
        }
    }

    if (dMXVkoOxU != true) {
        for (int UvVTkOFUcRTFRI = 895598698; UvVTkOFUcRTFRI > 0; UvVTkOFUcRTFRI--) {
            SDqoBcKWZQaqjHkQ = KFPiUAtdwTMV;
            KFPiUAtdwTMV = ! dMXVkoOxU;
        }
    }

    if (gAaJiPnoWqGopp == string("HyEDkgZZgCDfWuvDjQloDwkCqDGheoWMCmyPVtLbtvRUDoNCbRSFQCbQFoyIftNWNghcTnkyueTVttUwXzrbWNkzatzmNXYjTbsepXRwhtoZWWUuWUJxpKGuxZAJ")) {
        for (int bmqqNKLm = 1907128781; bmqqNKLm > 0; bmqqNKLm--) {
            gAaJiPnoWqGopp += gAaJiPnoWqGopp;
        }
    }

    return KFPiUAtdwTMV;
}

double MXRsBszUV::AsEtPrnxdDhuowI(int ETAfOHjg)
{
    double FjDWZsaqmjGNoJIg = -576217.8767691333;

    for (int qntLVTYtaNr = 103521206; qntLVTYtaNr > 0; qntLVTYtaNr--) {
        FjDWZsaqmjGNoJIg /= FjDWZsaqmjGNoJIg;
        ETAfOHjg *= ETAfOHjg;
        FjDWZsaqmjGNoJIg += FjDWZsaqmjGNoJIg;
        ETAfOHjg *= ETAfOHjg;
        FjDWZsaqmjGNoJIg *= FjDWZsaqmjGNoJIg;
    }

    for (int JMZjkyCYJDw = 1076511249; JMZjkyCYJDw > 0; JMZjkyCYJDw--) {
        FjDWZsaqmjGNoJIg -= FjDWZsaqmjGNoJIg;
        ETAfOHjg += ETAfOHjg;
        ETAfOHjg -= ETAfOHjg;
        FjDWZsaqmjGNoJIg *= FjDWZsaqmjGNoJIg;
        FjDWZsaqmjGNoJIg -= FjDWZsaqmjGNoJIg;
        FjDWZsaqmjGNoJIg = FjDWZsaqmjGNoJIg;
    }

    return FjDWZsaqmjGNoJIg;
}

bool MXRsBszUV::adHFuTBR(int BVtyyyc, string KOVyCmUHetADoeSr, string gdIHD, int PXGAcGYFrIsA, int NlFQeKnrwrWNukZQ)
{
    double UqIpBlQC = 191452.280947589;
    int arsQzzvwZa = 2130445184;
    bool RkxlFNPgUEJu = true;
    double dmjdEv = -58783.64113909327;
    bool mdvhmZXEPVLy = true;
    double GILjbvCc = -804921.9167207635;
    bool TdJzrZJwv = false;
    double BbqryoLiFe = -852208.1315675727;

    if (RkxlFNPgUEJu == true) {
        for (int MiBLvafVChdC = 1690137481; MiBLvafVChdC > 0; MiBLvafVChdC--) {
            dmjdEv += dmjdEv;
            NlFQeKnrwrWNukZQ += arsQzzvwZa;
            arsQzzvwZa += BVtyyyc;
            RkxlFNPgUEJu = RkxlFNPgUEJu;
        }
    }

    return TdJzrZJwv;
}

string MXRsBszUV::gHLXcdJKTCfbhn(double zdaRvEEWLrPxcepX, bool xwoUZycS)
{
    string hgTaoIfgREeA = string("mJIpFVHazUrkWCFyWMrJlQeaGBgpXffWlzJtFqqBjWdaOCrStBKetTlBxqCTbiqnvbMOlfyyefpjCvOjhqOFYUFRJUmXBCDlPmqNLBEIGReyUBhaNqIaCQpVVeOXFlAcVYVxtYpAXHuIfIzoJRlZwnxSaoUkyYByPzhGdVkWGMMuCJrMdXagMgilyuMvRPelaEfCnbSB");
    bool LoexZcxWPADUVqiB = true;
    int vEAcjZaUdmBQaPSn = -1442291251;
    double TFEtgXOVxDq = -245919.31268445673;
    bool xMlusBLBMT = false;
    int RExpeQpjWmK = 80958758;
    double nhDCdnqnOAluv = -777468.3035760813;

    for (int jcmrHtiEq = 1697605781; jcmrHtiEq > 0; jcmrHtiEq--) {
        continue;
    }

    for (int FURXAhn = 816990691; FURXAhn > 0; FURXAhn--) {
        nhDCdnqnOAluv *= TFEtgXOVxDq;
        xMlusBLBMT = xMlusBLBMT;
    }

    if (TFEtgXOVxDq >= -777468.3035760813) {
        for (int aKTsXpmLfp = 923657009; aKTsXpmLfp > 0; aKTsXpmLfp--) {
            continue;
        }
    }

    for (int LeUXLYs = 1678362736; LeUXLYs > 0; LeUXLYs--) {
        xMlusBLBMT = LoexZcxWPADUVqiB;
        nhDCdnqnOAluv *= nhDCdnqnOAluv;
    }

    for (int wFjHsUSy = 1827516513; wFjHsUSy > 0; wFjHsUSy--) {
        nhDCdnqnOAluv = TFEtgXOVxDq;
    }

    return hgTaoIfgREeA;
}

MXRsBszUV::MXRsBszUV()
{
    this->OqSKXJZidm(-1943762927, 714364.5930265485);
    this->kkcCk();
    this->ISRFsOhkqyCIkGI(-686280.9069188706, string("fWorACfeGoKBHXgCXHaoGJgzYLXhPgFfhjGHtPCBppJPktNfigJKqNrhhMkHlzkxsdkMfexTYKwUjxrPpgQLcTMxKFbwwxiedearsQNKXzNVOvdQeZJHemyDIQtZIvlNZwIuqZFJIAHByBJgEMfkejCDSNRjrcOBoFUDnhuibbhRLUqdXebAbELaAGUmYOJYJrjTYUzyRqRCYvpSEdZKlFVaFxhXnVfORODXYtGqDraHtDppVARPhabLyb"), -514073.36585494434);
    this->hpyGYFwYYGOJcqjX(string("UPgIlGqUTcrcwDIzZZFtobGrXchMeiNlbXHeslnjwyQCxRUMzpXpfJNpXJbHTvrSNCNVkdfazAXBqcrMlcyOldaHpJHisUjUezAC"), -908605.9829115503, false, -360850544);
    this->tVuYAAVflv(-600125.8011802156, 1393281338);
    this->jltLzuLCJkbphx(string("CoajScQmcnVpPMAkQRbXjYhYJRqGezTFqdqzmhWQROJmvkOcFMyBHjzErNvmkTKFfHqKkPVOXdAtbMehPhKBjgqCZAygRpuPSWNBnAyqmbfrnJbNCcgReXYAnOIDGDDnhbpMxZWgxS"));
    this->jiOUqOwrh(-74178.71395306801);
    this->AsEtPrnxdDhuowI(441001452);
    this->adHFuTBR(808628613, string("zkUFycHibpRsxylbMisnJltkKNhOigdgKrbVyludCPCiJ"), string("tJUtCOguIUistaaxBASFZAj"), 1461644755, 1779719653);
    this->gHLXcdJKTCfbhn(-13734.073615144982, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aGOOnYdcarl
{
public:
    string PgAYrSJIqKi;
    double LFDALY;
    bool qqWvR;
    int rJXHQMvAE;
    int UMVbhFtZ;
    double crooowxv;

    aGOOnYdcarl();
    double gTkTjvIZxivqomo(bool LNbPMa);
    int ZpozaeELXtDcxI(double QJjHFGsohw);
    double rQaAceJzIKla(bool aRmWsBEv, double CqRzvkxD, string PgOiTJHwWLiqODtZ, string rwJxJYfMstTt, string FXvFZ);
    string biHjAHbCGtAXt(string FKuirKXiFtswFond, double jEjVwLeGievPtH);
    int LeJDJYOj(bool XgBCyLOr, int dDOjLBYupmDZGlml, bool wkDPH);
    int HDpWe(int NObdLFTngom, double BpACiRYDPJFH);
protected:
    bool ezZCHiPElKRAxD;
    bool VsXIoDKhYks;
    double bqEVyONGWvoLX;
    double rreljTZAFgiBzV;

    double cbADNGk(string aolaGhKoRBDLNY, bool oXmKua, bool MmkocCRxERp);
    void eaxUqcf(int mURCFmv, string POEOfoEmhhcEwsc, string pLzwnY, double ONQpEufyg, bool HrTbDQYcJwjy);
    void bsYipCFuIQ(double eUlEYr);
    double IQtrVvIuvWSXpM();
    string PHxIHULLbrkWPx(int wYwvSkC, double PqTmK, int WithFenwUb);
private:
    bool qaxTUMOJNXPSEr;
    double weuSqTkwzxFsy;
    bool frsEFQQVNb;

    double EkNSMkyruzb(int oekNQMcMP, double otJhZVu, string MrvlvNwKeAVnSWXQ, double QIXzkOQiESqCBhiU);
    void JlQeThBQODnKiYqh(bool mvSQuzDuzKoIVx, double lSbBIienwsqCWg, int THmgkOGAWYtGqjM, int OLXZeWts, bool EcxwKJaKPO);
    void ueZLUGQx(int CDQap, double RHGXWmgKFziYS, bool zdlZtYHR);
    string dJFBlAVUhn(string XNdPipsVxXUtPGW);
    bool ftaVOGG(bool bhmigReMeKtCMMPs, string XJCNps, double qIrggeFDEhuqxFmP);
};

double aGOOnYdcarl::gTkTjvIZxivqomo(bool LNbPMa)
{
    string DhlLaBfyD = string("BJfVlVZtfGhudijRmJTCMAyeZKoyVSzVrcQKTFDLcehdNbQTJaQQMyrRyTdBULppiKkJxNfRvqLxNVhDhVsRXxjycqWiXEpulmgpLMGhBBmhJmfZPRRCPtJcADvwWqBN");
    string mrFkiBIq = string("ifzHxhHqgtUXFEfKVtviDnEZUJdSlyCLhhpgSMIxJrndSVIV");
    bool yVDxukdSATt = false;
    int gRgTaaeDRCIn = -1376942936;

    for (int SQspCtbG = 2097256331; SQspCtbG > 0; SQspCtbG--) {
        DhlLaBfyD = mrFkiBIq;
        yVDxukdSATt = ! LNbPMa;
        LNbPMa = ! LNbPMa;
    }

    for (int gZtmpzzFOJFlAPo = 2056913577; gZtmpzzFOJFlAPo > 0; gZtmpzzFOJFlAPo--) {
        gRgTaaeDRCIn /= gRgTaaeDRCIn;
        DhlLaBfyD += mrFkiBIq;
    }

    if (mrFkiBIq > string("ifzHxhHqgtUXFEfKVtviDnEZUJdSlyCLhhpgSMIxJrndSVIV")) {
        for (int ndUFUJtmKu = 521929595; ndUFUJtmKu > 0; ndUFUJtmKu--) {
            LNbPMa = yVDxukdSATt;
            LNbPMa = ! LNbPMa;
        }
    }

    for (int XUBlRRaOHsDsrRJ = 1498489255; XUBlRRaOHsDsrRJ > 0; XUBlRRaOHsDsrRJ--) {
        continue;
    }

    if (LNbPMa == false) {
        for (int nFQsaqabjp = 1693013709; nFQsaqabjp > 0; nFQsaqabjp--) {
            LNbPMa = ! LNbPMa;
            gRgTaaeDRCIn = gRgTaaeDRCIn;
        }
    }

    if (gRgTaaeDRCIn > -1376942936) {
        for (int fuuJTjzhTFb = 592440883; fuuJTjzhTFb > 0; fuuJTjzhTFb--) {
            LNbPMa = yVDxukdSATt;
            DhlLaBfyD += mrFkiBIq;
            yVDxukdSATt = ! LNbPMa;
        }
    }

    return -729502.2891013853;
}

int aGOOnYdcarl::ZpozaeELXtDcxI(double QJjHFGsohw)
{
    int ocJJsNWqifCSs = 1506037636;

    for (int ecRjNuMWAYYvu = 134606842; ecRjNuMWAYYvu > 0; ecRjNuMWAYYvu--) {
        QJjHFGsohw -= QJjHFGsohw;
    }

    for (int FuDVcjflUj = 2117747471; FuDVcjflUj > 0; FuDVcjflUj--) {
        ocJJsNWqifCSs += ocJJsNWqifCSs;
    }

    for (int HaWADXdjdZVHqkJp = 1588975126; HaWADXdjdZVHqkJp > 0; HaWADXdjdZVHqkJp--) {
        QJjHFGsohw *= QJjHFGsohw;
        ocJJsNWqifCSs -= ocJJsNWqifCSs;
    }

    return ocJJsNWqifCSs;
}

double aGOOnYdcarl::rQaAceJzIKla(bool aRmWsBEv, double CqRzvkxD, string PgOiTJHwWLiqODtZ, string rwJxJYfMstTt, string FXvFZ)
{
    int aThtFFlZyBW = -387082455;
    string ASdZRXLqEIVuPVoP = string("nVZSssGJQWZkGwxUmGLpGfvZmLgeTvliwATccrOuWRzigNqmyXJJQSDSeqgqDKYeSkZjgeWuNLdgzZjEcsBldT");
    int jakpEu = -168696833;
    string zMAvCK = string("PFEgtpSIuUggK");
    bool WcLXUjwTLq = true;
    double ndGCQ = 649390.4987086473;
    int klnRitVUxWO = 1614427837;
    string hWpizprKaMvz = string("IOYJtQEDeVaAZoEzXUsObHmhTKdzBpendHxGJYIesHevqavWdtGCaBQjnruCIpBINOHUZtKBbxVOHcyVpNKMtopkhRndrAhcfNLTNGTWHQIRjcLMzzzBAoOfnTNqqTbZvMr");
    int QfhtDeZdoEZjaqR = 1795579251;

    for (int rlFYDc = 1066102311; rlFYDc > 0; rlFYDc--) {
        PgOiTJHwWLiqODtZ = hWpizprKaMvz;
        WcLXUjwTLq = ! WcLXUjwTLq;
        ASdZRXLqEIVuPVoP += rwJxJYfMstTt;
        hWpizprKaMvz += hWpizprKaMvz;
    }

    if (ndGCQ <= -641728.9873369511) {
        for (int ADzcq = 820489671; ADzcq > 0; ADzcq--) {
            continue;
        }
    }

    for (int QNqSA = 1286704410; QNqSA > 0; QNqSA--) {
        jakpEu += aThtFFlZyBW;
        zMAvCK = FXvFZ;
    }

    for (int FiJYi = 841938244; FiJYi > 0; FiJYi--) {
        FXvFZ += ASdZRXLqEIVuPVoP;
    }

    if (ASdZRXLqEIVuPVoP <= string("PFEgtpSIuUggK")) {
        for (int UaMcHliYHzLaXEIE = 1591299844; UaMcHliYHzLaXEIE > 0; UaMcHliYHzLaXEIE--) {
            CqRzvkxD *= CqRzvkxD;
            zMAvCK += FXvFZ;
        }
    }

    return ndGCQ;
}

string aGOOnYdcarl::biHjAHbCGtAXt(string FKuirKXiFtswFond, double jEjVwLeGievPtH)
{
    bool HgZThv = true;
    string UXxAEGwLGr = string("iqSoStJaqSWFsGTRfMwHfGsWzZgCCdnEHrevQazsMdEXMtpClHJeSpQmKWNnBzERQNaywlcGtPcbupwUnAtOrHEpvaVqkdYQGaaPlkPmJDPSmmrEzwlkPKjEzhhAjSEDIUIFOXRofvxqgcBgOMSodqXLXPaHuMmBShlNMzEYSjUSacGujkEDSjp");

    for (int sMNbzTqLfDPnBuCI = 521360452; sMNbzTqLfDPnBuCI > 0; sMNbzTqLfDPnBuCI--) {
        continue;
    }

    if (jEjVwLeGievPtH > -171422.15759872668) {
        for (int gBMszGElheAHIEs = 1392097733; gBMszGElheAHIEs > 0; gBMszGElheAHIEs--) {
            continue;
        }
    }

    for (int EAasHtLiY = 1792390837; EAasHtLiY > 0; EAasHtLiY--) {
        jEjVwLeGievPtH /= jEjVwLeGievPtH;
        UXxAEGwLGr += FKuirKXiFtswFond;
    }

    if (FKuirKXiFtswFond != string("WUffFEGdLrbDBzRMSjhONvkzSTTcdFjNDjhZBKrSoZ")) {
        for (int Imuty = 530875013; Imuty > 0; Imuty--) {
            jEjVwLeGievPtH += jEjVwLeGievPtH;
        }
    }

    for (int IUQEHkuJffaWpM = 1329291830; IUQEHkuJffaWpM > 0; IUQEHkuJffaWpM--) {
        jEjVwLeGievPtH += jEjVwLeGievPtH;
    }

    return UXxAEGwLGr;
}

int aGOOnYdcarl::LeJDJYOj(bool XgBCyLOr, int dDOjLBYupmDZGlml, bool wkDPH)
{
    double eQSDQDquWDnA = -817880.9356686786;
    string JjsJlY = string("avCZtzpYYCFtiPHZlidVstmdSFgsjioEgEfYSvotVCkhVRrVfpGxgRfRUoHKxfPyrnGHybhuKsSzNjNoyOlJIpHhvrVezMPMmXWagGlathplTcqJzDDDeFicMobItpkeUiKnBsWnrOlYsWEBab");
    double HbyffCRiBLUx = -975737.8908713358;
    double aJXPp = 497877.9954234205;
    int jxzpiMdRg = -1765529431;
    string UPQbR = string("DzRkOSxoZCycKWsEPttZqygNOrgHvIzPGjOUgZvCePLDSk");
    double aIKyqVEsAi = -215752.1652688702;
    string NXFuuLdWpmtUK = string("vCOgDgbtkVsCjWQrYnjCdsiVyjWKYMiPgNhiTWNqOmUEjogCJrTjmzQUgiPUBTKQQQvnSDtVoSHLVySbsdWwGYexnNrcEKDaVbAiSprYSilIEesrrtyBTgVEmLZNimCOZygtGCoPaGMFHWKkWiXrghGJepuSIfMnwSwqZnuvmwkMDFcfRkcDSHYoPBSBAMuhlYvdUgnUJmFsAlqvICBPCkZyZlbgmHm");

    for (int DMayE = 134614834; DMayE > 0; DMayE--) {
        NXFuuLdWpmtUK += NXFuuLdWpmtUK;
    }

    return jxzpiMdRg;
}

int aGOOnYdcarl::HDpWe(int NObdLFTngom, double BpACiRYDPJFH)
{
    string VOahSssekRfCIgfe = string("iNalhVXZPxmJRlQoSjYSMsDWXwDCCtlbKtzSSJRDwHVgmFxymfvaDvcxoelgjTqeVqbDtbUVbcuknFvjd");
    double wLBuICANSiGV = 722418.1143449848;
    double dRAXsQOhvj = -43563.55373251876;
    double wjPHsnGcGvLXiJR = -3912.19686028923;
    string QwHPgbLgVACK = string("OApVSoVgOZxfTfoYHBeTpbOoVNZrBOLsbVXyoPXFYfeIxFSWzxKslBDuAQysWGyVSJEHrZqxRfBTPcSYaLHhqSiYKqVtsSdGSVarpjVOntRiduDNOXzbXAYdVXOFpKVNErDKLEALGJct");
    double TExWIFRMSAl = -339743.07636644755;
    string BUqBkUeUmUCdE = string("hXuHnwXsbbljIwxQhnpcAhSTRCXQJNbEiqwalQtLQLchjjbFIRpVWTMwRikcKBlztsrjfjqgzYqeSoniOAVoAjZyXrCPEQAKnYpoZpQWfSHAQHwlmuccdteCYmcqvJtSdtKZVNxHETOSeGgnmgAZcqFceYsOHyZWJMUsiJDoLCzvxertnsPlJIRnCctAFYUFgxvbWHRGtZIpUPolwwSRmxDGvIoCTylyKMEM");
    string ygwUFAMxWPlVt = string("MJOvWZsQHYoXcKtMURlmUbLUdDjjfnIDUvhYIFvOXqpWPgNywHZUoBoJUwRdcLeSayGSBNQauLTjZaHatjYFlPGxxRDbxvTFxUtKcQnquacSQVfWa");
    double enqrzXCFLOPaUxV = 676035.5481712001;
    bool UJGkDXcj = false;

    if (enqrzXCFLOPaUxV <= -3912.19686028923) {
        for (int YfcUcpKzR = 2049209577; YfcUcpKzR > 0; YfcUcpKzR--) {
            dRAXsQOhvj *= BpACiRYDPJFH;
        }
    }

    for (int mIusZOEWkx = 2061266869; mIusZOEWkx > 0; mIusZOEWkx--) {
        BpACiRYDPJFH += wLBuICANSiGV;
    }

    if (wjPHsnGcGvLXiJR < -339743.07636644755) {
        for (int OaeDLmrHGXfB = 1943688621; OaeDLmrHGXfB > 0; OaeDLmrHGXfB--) {
            TExWIFRMSAl /= wLBuICANSiGV;
            BUqBkUeUmUCdE = VOahSssekRfCIgfe;
        }
    }

    return NObdLFTngom;
}

double aGOOnYdcarl::cbADNGk(string aolaGhKoRBDLNY, bool oXmKua, bool MmkocCRxERp)
{
    string GSAobQ = string("KyVINZHljKGtMWDfvfymDaMWSSjelOkgNepnmkklqaYOoqfWXqkmDmTaArIGdPWNLUkHDjKuzwVqtckaPcwGPOrsvhiavycqGTPTpLwswlFIjerPhgeAFfdbYkzPQLZIMyQSRbYECfkWJxCCGMvQPumTYDAASwwNBiRFSNTjjtWuhSyrZVXoijMQVNmQQwCSXimAJJhOiBn");
    string UdIUkPJJsmuLD = string("krscWbKvPsZtaoHCgqxJRwmXMluQIrxpGAJGvEDfCUEOtvkuwUAVOkCmCGMgXDEUUdYZxfxgJESccgBcBWkNnGuEQHyyRfjEFuGhDIicahbasoWggGfwxHqlByVsZqsMtqHFAqYQyWDeExYdGQWdhfynIcyBORTetJaDNMZYVeZcYDdevtQwbuxfFVwSUnCn");
    int rpyxsyQs = 1938277009;
    double JaVUdowsXT = -59578.44387126059;
    int CfSFSA = 1168205661;
    int NsgYTit = 1672843459;
    int AhySoXstuQ = 270980266;
    string XWrEgxKfNxfAxhyQ = string("eVfoLusYwIDdruIMBbCWyVRCydOpPUVrMGJCBA");

    for (int hPvrVUBFZ = 1915768966; hPvrVUBFZ > 0; hPvrVUBFZ--) {
        CfSFSA -= CfSFSA;
        aolaGhKoRBDLNY += UdIUkPJJsmuLD;
        CfSFSA = NsgYTit;
    }

    for (int GsKQwW = 1034338031; GsKQwW > 0; GsKQwW--) {
        continue;
    }

    return JaVUdowsXT;
}

void aGOOnYdcarl::eaxUqcf(int mURCFmv, string POEOfoEmhhcEwsc, string pLzwnY, double ONQpEufyg, bool HrTbDQYcJwjy)
{
    bool UHAWcK = false;
    int xdJVXLnhpQwKBOq = 319214794;
    string gOQswak = string("ecFDWMtzWpiBPuetYULjKrFVLNodUfQPWvcQqCmQ");
    double QrDTNFLPBbSbcQ = 734759.6876872819;
    int KhnRgmhSbsM = -1030725069;

    if (pLzwnY > string("oIflNpFKWbkdWnUXnMNBXBzmPtZZJDIrqkOfNBqLxIYDvIBakFTrpvUuufHQTqBMzlWszHNRHoTSznDjGQYZUVtvVtpMVSoytVwcBahjdGytjDcAaVnJcbyjEWGHdrhkLfHjpJyPmxJRLrVuGISezHmdRmAPHPGQDVJFUsaJKmMsUmzwLSQnGlvByHRlnplbMsYOoOw")) {
        for (int dqhkOe = 112371853; dqhkOe > 0; dqhkOe--) {
            HrTbDQYcJwjy = ! HrTbDQYcJwjy;
            gOQswak = pLzwnY;
            HrTbDQYcJwjy = ! UHAWcK;
        }
    }

    for (int IWvzIuWTleRJxwz = 543372889; IWvzIuWTleRJxwz > 0; IWvzIuWTleRJxwz--) {
        QrDTNFLPBbSbcQ += ONQpEufyg;
        mURCFmv += xdJVXLnhpQwKBOq;
    }

    for (int FVMrTWxmDflwPM = 933788776; FVMrTWxmDflwPM > 0; FVMrTWxmDflwPM--) {
        HrTbDQYcJwjy = ! HrTbDQYcJwjy;
        pLzwnY += pLzwnY;
        UHAWcK = ! UHAWcK;
    }

    for (int MthmxWLuIyDEBx = 1678137718; MthmxWLuIyDEBx > 0; MthmxWLuIyDEBx--) {
        continue;
    }
}

void aGOOnYdcarl::bsYipCFuIQ(double eUlEYr)
{
    bool eaafhRHFcvv = false;
    bool LhNwlgqU = true;

    for (int FJskOozzC = 411178110; FJskOozzC > 0; FJskOozzC--) {
        LhNwlgqU = ! eaafhRHFcvv;
    }
}

double aGOOnYdcarl::IQtrVvIuvWSXpM()
{
    double kszjiIexbEWHBhhI = 632130.7938062348;
    double LrQbvelpqWk = 876853.1695282905;
    double IychXnPCiDtQWSyB = 213802.1339351564;
    double wKKTFGouSHySIeU = 855060.113071919;
    double CzKztMXYP = -633325.8646817462;
    string WSdbmB = string("eAigTnFGYOaZNdfNhhDodfjFqoApnVpaMSfogrCZwWkDwIaQOnSPCzzygeEPCpxtGVdQ");
    string VhzMxfXUwzUfyk = string("msyWOXepDNrBNzlokIYZjbkvVEkAmGqXFBtZwQDcxlbUARiOsRyQOfhDovAYbHzkbQWLIchTdiJGvwzIHZMBjaTWBIOsUcZcqRRgUtDHQuiEKMBVqhHlZYOqqPdieWVvMKhdVYGkaePUcAFUUiNKHnBSKYbXWoqVAtrJEPhY");
    double DLnlrmxtvBwF = 1006131.9367999329;
    double aHnMqghKufyND = -117608.6040847755;
    int QgwoosgxN = -1834198420;

    return aHnMqghKufyND;
}

string aGOOnYdcarl::PHxIHULLbrkWPx(int wYwvSkC, double PqTmK, int WithFenwUb)
{
    bool BDOVsSymZ = true;
    string cnUyy = string("GQPsjhHWETzVshkdiTqNacbFBzxmbRLTSwxGftHSCZfjhsJSsUwJOnkjhQwqbrBBUiYqpzBfjeoKAoADhScRxYVNvsFzfxIFeAgLeuRzAOPiEvIIvufcfjmPJdQUpdQDjecrxmyxQMutvUq");
    bool vOOSCrEejfjMP = false;
    string fCuSkOTkmzIabz = string("MLmLEDrqoFTJYUnDlsLIfEgSb");
    bool NJpkALauT = false;
    string NTpHSpCWatb = string("iSGDAjuwTayDJzOmRxEHzxNVsVfnGHxlLNUkggWIRmFqqraQAURpeLQqqHCQisLoVllMebwvfVdozteKpzMNjLMmLDziPDQaywfzzGjq");
    int eMUZOwLYHAOs = 921445995;

    return NTpHSpCWatb;
}

double aGOOnYdcarl::EkNSMkyruzb(int oekNQMcMP, double otJhZVu, string MrvlvNwKeAVnSWXQ, double QIXzkOQiESqCBhiU)
{
    bool iwIUNIJJnPKcy = false;
    bool TaMwQpSlkCEAkIQH = true;
    string nqZOjgkWpA = string("LGbZcfAAatSvABpdLWVCUGinDpuxVfQNHYbcqtUGCmhGtkpPoStoVAiQbkJSZNaoqpQizGkutoWKthZCFCcHTJpWluNipgNZFHNlFCNyiwtLwVFZpOTBFxVemCgKOmFvkZNwLogQqyfqrCIDmZudvAHNDmnCmEiVEQSjJRsDW");

    for (int sJiZHfcvRbJ = 1844669876; sJiZHfcvRbJ > 0; sJiZHfcvRbJ--) {
        continue;
    }

    for (int xkfafpZCHOr = 882001127; xkfafpZCHOr > 0; xkfafpZCHOr--) {
        continue;
    }

    return QIXzkOQiESqCBhiU;
}

void aGOOnYdcarl::JlQeThBQODnKiYqh(bool mvSQuzDuzKoIVx, double lSbBIienwsqCWg, int THmgkOGAWYtGqjM, int OLXZeWts, bool EcxwKJaKPO)
{
    double WETbE = -790607.3233445775;
    string LUyELzlskYsqtdA = string("oppBQLWIHLrsONkJmBgwwaunWKaFOcKjkpSCtazrLNtuLCuDOFmFKtqLHxyoOS");
    string xhYCHurTKSlFQp = string("CRiMaQAzyGQPlZlbolXKOmozDaLuSXjaKCYhaJErHhGWXDTGQieAXtYsErAxjSskopSxtOtwgOrESbDmtNuIaSZg");
    bool UKVDukEXJn = true;
    string huzoIvkWviDMKVqe = string("eIBvwYQBOOxAldy");
    string AVvKvZujJIWw = string("QKUrYOygiUbOTetoemAKiXWIpFkkJXdvclbUnyKlvAMUlLkjlXtborEzeNXEQZZQZfhtryFSgJoMefXVuKJSkneuImSOdWkNtwaSFOdLQjYtlimwxxhGOkBlYlozpGFYdKNcSwnaOtKetWTZUDruPsfPJjCC");
    bool rOrMkOk = false;
    string avzFGlNJilHDN = string("LFouATNQPgiAriXrKVPzASxkDhhGPIZXJjMYwOybelTxesNcxBoonflkzcDNObhRpNaGJVHXPYLBoluNJTkFOdHumuICfBVOsxCRujxptdeYMnVpdandpJBQsgsmPOmzLTGGefINvRPEtMWroVOi");
    bool TMmFAKgyus = false;
    bool eHeQPtUcGHGvpWHd = true;

    for (int SoigYGvlRWrP = 545894297; SoigYGvlRWrP > 0; SoigYGvlRWrP--) {
        xhYCHurTKSlFQp = huzoIvkWviDMKVqe;
        LUyELzlskYsqtdA = huzoIvkWviDMKVqe;
        EcxwKJaKPO = TMmFAKgyus;
        mvSQuzDuzKoIVx = TMmFAKgyus;
    }

    if (eHeQPtUcGHGvpWHd != false) {
        for (int uURatTk = 261944071; uURatTk > 0; uURatTk--) {
            mvSQuzDuzKoIVx = TMmFAKgyus;
        }
    }

    if (rOrMkOk != false) {
        for (int kLabMEfvsfGF = 1710861070; kLabMEfvsfGF > 0; kLabMEfvsfGF--) {
            continue;
        }
    }

    for (int JEKHSYjUrekyEcrS = 85472414; JEKHSYjUrekyEcrS > 0; JEKHSYjUrekyEcrS--) {
        continue;
    }

    for (int mIsGU = 260339452; mIsGU > 0; mIsGU--) {
        avzFGlNJilHDN += avzFGlNJilHDN;
        AVvKvZujJIWw = xhYCHurTKSlFQp;
        mvSQuzDuzKoIVx = EcxwKJaKPO;
        rOrMkOk = TMmFAKgyus;
    }
}

void aGOOnYdcarl::ueZLUGQx(int CDQap, double RHGXWmgKFziYS, bool zdlZtYHR)
{
    int NiyfBkJ = -1755323490;
    string ZmliLFO = string("ATBSshvuupGKDHZmjamViFNihRZOMcUlbPONcfKJMWYufFbQDXkrhZIfToLYEQQTXKFcgFgshRAnEgipgUPWXnRcAyJ");
    bool ldfuqWPqFsUQXdx = true;
    string OSVDzMmyUvmkjS = string("EBPoyKOtHugUUiAbFfhDPQPKmchiymnGyZWCmQOcVjKDNvszSTkfsraRwJygzugrcYgKrIlYUHCcBAxgSCqiNJun");
    string AldXVMPqfwxIA = string("yvxLqurfOLbKKgFVRIRFCxQTiAUBELyyaCPiUJXcyFw");
    double HsPpaTAH = -500182.5944818881;
    string JWKrBMDL = string("VcCVLMlLawOyJAOVxBEzgPJlVyFKthySJIwfOtrchZrJppaODhufDcfWVAgkrktmYVQbesdGHUoYPLvBOYebBGcYiNzciOxTYhrTACOuWkcGCBnUpeUpURLfCcWFraMxVkintzmYLaSShUOKowtCyVclhfUWITeQ");
    double yJptFIjrUlBKB = -389762.7472652793;

    if (ZmliLFO < string("yvxLqurfOLbKKgFVRIRFCxQTiAUBELyyaCPiUJXcyFw")) {
        for (int hzmEaYGqMz = 799359082; hzmEaYGqMz > 0; hzmEaYGqMz--) {
            OSVDzMmyUvmkjS += AldXVMPqfwxIA;
            RHGXWmgKFziYS = yJptFIjrUlBKB;
            RHGXWmgKFziYS -= RHGXWmgKFziYS;
        }
    }

    for (int xRLEJpvT = 1456222765; xRLEJpvT > 0; xRLEJpvT--) {
        yJptFIjrUlBKB /= RHGXWmgKFziYS;
        yJptFIjrUlBKB += HsPpaTAH;
        ZmliLFO = OSVDzMmyUvmkjS;
    }

    if (OSVDzMmyUvmkjS > string("VcCVLMlLawOyJAOVxBEzgPJlVyFKthySJIwfOtrchZrJppaODhufDcfWVAgkrktmYVQbesdGHUoYPLvBOYebBGcYiNzciOxTYhrTACOuWkcGCBnUpeUpURLfCcWFraMxVkintzmYLaSShUOKowtCyVclhfUWITeQ")) {
        for (int fUGqQb = 1739841835; fUGqQb > 0; fUGqQb--) {
            ldfuqWPqFsUQXdx = zdlZtYHR;
        }
    }

    for (int nTgRu = 574603878; nTgRu > 0; nTgRu--) {
        continue;
    }

    for (int ocXXGcYs = 1024529736; ocXXGcYs > 0; ocXXGcYs--) {
        ldfuqWPqFsUQXdx = ! zdlZtYHR;
    }
}

string aGOOnYdcarl::dJFBlAVUhn(string XNdPipsVxXUtPGW)
{
    double fSBwNTXOybGFiRms = -616654.1583262053;
    bool PGkukdQ = true;
    string JcpamQMrv = string("FrHlDRzXftfiDBerulHBJZoPvnnBGshWfcFTfOXZEmwSqvOdDFiLrJyzMzsbPjQzcPNcwCcrTeaNATZeOeyoiGTzIdNrmgZVAWvISkVehUuSPjKCsQuZcydbUKefbJGLQOabDGOnQodkuljzOvgaLnAYOxGFaZssqVRPYtVBRUJUvWWjCFVtvlKTHbmCRGf");
    double XVsVhNEII = 886387.7922411582;
    bool IHoszpQfNkwEIG = true;
    double jFOCSZH = 767159.5844952236;
    bool rQlGE = false;
    string dqAPbsR = string("RWMUKXnAyExxcGKuFnqGNDqAjdvuPgqWHGKjDFTVShpZyMQuIHfqDzlOPweZuqrlCraMOcVFFfpdrNuAgahVnrjTOPrLkmnTnvWPqvNSQXvatskmXZtLObvGmqAEkTadrgoyRQUPoiMwwRdLvYIxRltvaDsohTiLhBZJrjKBbKdGQlrlCACCulDPVzXzaHmRTRStJufvWIynMkDn");
    int rxvSJVWChAUES = 301774148;
    string XVoUNUvEzkLWJbX = string("EFRjcQhvGadCntTKGVLxQMuvHmXyenYaSaQInJTIpyyFgSKSKMHivsbEcOwVZxZbFuUpTPzqEcQczonSpaZuRHLoURLunkTCBzrNbVDvpJIuorICyheMJolGCTUpnvDlcdMRHgxPRPdsoWBCcxwKVsiPRSAJUMgLYVDAolgbaJyuxYczidASufg");

    if (IHoszpQfNkwEIG == false) {
        for (int UPgRBjVKz = 458743574; UPgRBjVKz > 0; UPgRBjVKz--) {
            dqAPbsR = JcpamQMrv;
        }
    }

    if (rQlGE == false) {
        for (int rSkOrSZp = 392644305; rSkOrSZp > 0; rSkOrSZp--) {
            jFOCSZH = XVsVhNEII;
            PGkukdQ = ! IHoszpQfNkwEIG;
            XNdPipsVxXUtPGW = XVoUNUvEzkLWJbX;
        }
    }

    return XVoUNUvEzkLWJbX;
}

bool aGOOnYdcarl::ftaVOGG(bool bhmigReMeKtCMMPs, string XJCNps, double qIrggeFDEhuqxFmP)
{
    bool HLKHbJ = true;
    string yERMwTR = string("JictAxzmeiRpYGQqWtjRGnCFKyhlPDdwUvbIZPzSwCzinXcJNybUuSMsYAumWazdakxoqXgpcwFumkIKgcqYxTUsJtsMIujSUBalrtjiPmjfSesbMHoFWlXqOWcrtmtqijnOWSJkRsXNSexRcVN");
    bool wqUklJAmA = false;
    string wEdxLwvNREEX = string("jctbBPoGbqHXeLGfENRzSrqRuntyoELeLtzsOQNJmFDoilKHXegjmKAoSJndzwcqGDGwaPEWWffgkenaQoHUYgWHjsjezXsTlRCrXBra");
    bool koTfwmyupUhXs = false;
    bool CJKraGfEhwq = true;

    for (int yNDWcdUYiMyftYGq = 439702230; yNDWcdUYiMyftYGq > 0; yNDWcdUYiMyftYGq--) {
        koTfwmyupUhXs = bhmigReMeKtCMMPs;
        koTfwmyupUhXs = HLKHbJ;
        koTfwmyupUhXs = HLKHbJ;
    }

    for (int eRwcacxDuUJ = 823941360; eRwcacxDuUJ > 0; eRwcacxDuUJ--) {
        bhmigReMeKtCMMPs = ! HLKHbJ;
        bhmigReMeKtCMMPs = ! wqUklJAmA;
        CJKraGfEhwq = ! HLKHbJ;
    }

    return CJKraGfEhwq;
}

aGOOnYdcarl::aGOOnYdcarl()
{
    this->gTkTjvIZxivqomo(false);
    this->ZpozaeELXtDcxI(806774.3930795296);
    this->rQaAceJzIKla(true, -641728.9873369511, string("dRMxLsqJtJQPMHroJpotVkSpluRmkbvqBJaDcDeSahaPrvmUBlUVDHvcepuNlRNPeoCBwfxvtjYnOxBxibHSFEqMvJSEUrMoqXDyNCfucggpJiaxGSkVziDfcsIPZdwvVmYdlApeGYaqThshbrclqrqroCtMDqsaUQciVs"), string("OjhFdafeYmDOUQAQqfCHjcdhcZCmwivFEZTtSmhfQxkPYEAeBBpdFdeUeOKceFVFjHmDAfTttbcPXzdkMrtbbweaBChMiFKScskeEuAuQkSFRpxUpgDSifJEYfUDQsuUAcKoIWKCUCllJtkPPIpccgOFzlnmoGtkTBpmPCmFDeXsubhGkSuubqtdGRHMuEeYhJwD"), string("mShJbYPfHtHFGmhqKdWsTYpVqPuOWMVsMPSpsbKnWdqJthARgaYWolAjsrcwGhkRrqyQJGSgpngQBWgMINajGlGLRbYLVdQzScwsekAEGVsKWwQxVKJCScUdgMZIVqUXuBrJjrsldlGPofQBvnQSobaIblDkWAMduCpdgWLUxsZKAvuHrhOGdGTiPQOvPkYivniZXVLv"));
    this->biHjAHbCGtAXt(string("WUffFEGdLrbDBzRMSjhONvkzSTTcdFjNDjhZBKrSoZ"), -171422.15759872668);
    this->LeJDJYOj(false, 1646065411, true);
    this->HDpWe(-1945068089, -871136.4320768837);
    this->cbADNGk(string("iJvSuwIkqMYNMrhexiQghJDGRIogCBmNnBwGrklfmcRcmlxfcXgsmAoefYssCxCshTXHJTXZEqGgNyMANlcERtalZvBmpXRjDoYxHQfhPNdC"), true, false);
    this->eaxUqcf(-2130089086, string("CtTYbaUPYjJqgwnALUifPDuaLwEsBkKaFdQMBtfzbkvkdVCrrQEKbmTDkiGBASLuYdHGLiWsPleZouXYyuUOhsDKKZCsj"), string("oIflNpFKWbkdWnUXnMNBXBzmPtZZJDIrqkOfNBqLxIYDvIBakFTrpvUuufHQTqBMzlWszHNRHoTSznDjGQYZUVtvVtpMVSoytVwcBahjdGytjDcAaVnJcbyjEWGHdrhkLfHjpJyPmxJRLrVuGISezHmdRmAPHPGQDVJFUsaJKmMsUmzwLSQnGlvByHRlnplbMsYOoOw"), -944010.2450545968, false);
    this->bsYipCFuIQ(750824.9466992641);
    this->IQtrVvIuvWSXpM();
    this->PHxIHULLbrkWPx(1695971456, 107017.03495798912, -1283604583);
    this->EkNSMkyruzb(-1333628061, -693210.3779177647, string("CnDqjOjILVflRlFNTtlBjtKvvPwYJuHksiAkIRqNciQItQuK"), 516647.8005110527);
    this->JlQeThBQODnKiYqh(true, 749145.4144466995, 1782263095, 2066650294, false);
    this->ueZLUGQx(-1730938781, 380536.70763429784, false);
    this->dJFBlAVUhn(string("qjeKjIKwDTxlGOxAdxZgbFzxtcjudwbHDbwmMRVINCIYzKokYOEMfWCkguhMFRBQBZoSxatilvbyOkwpotjfkGVPqWRXJOFIEBVDznhrwYAgTXjLJBTSlRpMXhTAlastPYtbhCcjTLTnNvdakZdvqNvDGf"));
    this->ftaVOGG(true, string("JGlJnMJojKnrvfxuDuOMSKAxNEAomFQYTEUurhiYoBRgLMSvLNreJVtXFFyuyUeXrJykGotmlaElCnlhLCwlarolPTncLEwnMIsVFRoJEjqWYyzCRINsnlCouWHmFArIbCjhSvRxRdhWJVfdaWwiIDpkRhMJxSlFtFHmnSezAgoYSeyMafNgshqmCljWQCVUzKVkGFuXsjeOvUVLDjBDZeyFKDOaRviscsqEBkRb"), -299250.0431686417);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cxDAXCHjlSA
{
public:
    double djLrlNqKockrgkNd;
    string XXDPujOM;

    cxDAXCHjlSA();
    int YNIieCkUhXPiuMg(string TjRBCZjgEKVL, double kRAChlk);
    string VBWxEHueaWUZEG(bool fsNexEWwXGbkQuwf, double VdSttWieGicDHbu, bool QXxMt, int WRCxcyCGo);
    int HZVdVtszUADPqk(string cmrOQbMZYIPv, double lfiPwqzjSTR, double QiXHxDUFhEcS, bool yTYHwVLfpm);
protected:
    string lkYvPP;
    bool SELYXyTMIhaxtwz;
    int bMfMadQKbZbFMkI;
    string cBlBLbjK;
    double NASRxpIaBxyGBs;

private:
    int cnuaqWKjl;
    int QxAqMYK;
    string vUbTY;

    bool fMIKmTZvlOux(string cytSCadNVqKz, string dybtrjQOn, string kJrui, string PWxHXJnklLgl, double VNRUUYMITYQm);
};

int cxDAXCHjlSA::YNIieCkUhXPiuMg(string TjRBCZjgEKVL, double kRAChlk)
{
    string FCBgTAR = string("GRnmspKqMlBFwadIcGmBtJfHeSwGHnbSJAQUCMbnpUtBoChmcapLOFKNebChXQLYqpstOOJWqJWKidAtbogXpglWElhCcFfEZTpfZkmnKPxiouHWEiQqYXyKRlbNIijCAqolwkydKbyMpCqHqAvfrWxMyGaeqvpCzqTdzKffvcTXRQxvZMJRewQspIejhVgHPvzGImYSqcmQvhK");
    double cWqLdPvBlaLVXvsT = -55988.61818864834;
    int tnLOXKDd = 1131587396;
    double loutOsogLSka = 751282.8638603926;
    string pvwli = string("velOPaRbHuzhcpicQJlqIOnwYLoNhkxXDFdShdkZGNMgCpLCiNXDACumtcyQQCrXAtIThbVZASxroUFSaTxAAWjYzZdzkIOeVbYmEFEXbevANkUpRgFThcXvWoQdLiSdyvPLytWVeWnFhbyZTumtcBYSFFmXfLoVTEjnqcRYrmiXnVeDOWEhSSisdJyPsomgpKJVjalwQHpcPhwJ");
    int PRGfSSnfYtNYULK = 314733303;
    double QbexJjACkby = 674814.694084408;
    string fxEFs = string("kSZPQUCoTvokGRGoiXakJGpTLfHDEAdEjgDHKxacPzwMeFpijGpHfSfAwDddRgpbkqBVPdPngYXLLKzYwwlgDRnMpPFjyDzggoEqNdtQeFhrRFdRvMauEGzNfSGSVXGNgKXycVHEIXkDObIqnXoFrygyVjnBMlzsELhbWLpjZgTPJQQMqcwUg");
    string kMXtRkynKj = string("jVRvXQzTPxTRgkXuxcFziNikSPCFoKCXYTEIWcTTcxpUUKoDVztBsUqMvQPPCaJzRYVNXoGzWKGJniuXXJKPDzMWLeUARmTErgmrISjHnfZozXZoFMdLbxezRwUTUggYDNIsFtNKNdPsodHYPiiNsZZeoMCiaPnKkWGFRYOeGtXCMqVJwPnKGQPoqlqTgYOVHkzxWDRnbwgNCHpMCrhutZuvtbkitGwKLEbwMkeeP");
    double TQNJMp = -1046443.5843688014;

    for (int HNfeVYYTlsVgYeK = 1165838256; HNfeVYYTlsVgYeK > 0; HNfeVYYTlsVgYeK--) {
        FCBgTAR = kMXtRkynKj;
        pvwli += TjRBCZjgEKVL;
        cWqLdPvBlaLVXvsT -= TQNJMp;
        fxEFs += FCBgTAR;
    }

    if (FCBgTAR >= string("jVRvXQzTPxTRgkXuxcFziNikSPCFoKCXYTEIWcTTcxpUUKoDVztBsUqMvQPPCaJzRYVNXoGzWKGJniuXXJKPDzMWLeUARmTErgmrISjHnfZozXZoFMdLbxezRwUTUggYDNIsFtNKNdPsodHYPiiNsZZeoMCiaPnKkWGFRYOeGtXCMqVJwPnKGQPoqlqTgYOVHkzxWDRnbwgNCHpMCrhutZuvtbkitGwKLEbwMkeeP")) {
        for (int DEEVIoUNT = 1509742726; DEEVIoUNT > 0; DEEVIoUNT--) {
            continue;
        }
    }

    for (int DEcviSWNYgQYaVjv = 463554487; DEcviSWNYgQYaVjv > 0; DEcviSWNYgQYaVjv--) {
        cWqLdPvBlaLVXvsT /= cWqLdPvBlaLVXvsT;
    }

    if (TQNJMp >= 674814.694084408) {
        for (int JURutGydgEBr = 1398972866; JURutGydgEBr > 0; JURutGydgEBr--) {
            kRAChlk *= QbexJjACkby;
            fxEFs = FCBgTAR;
            loutOsogLSka /= loutOsogLSka;
            FCBgTAR += pvwli;
            kRAChlk -= cWqLdPvBlaLVXvsT;
        }
    }

    return PRGfSSnfYtNYULK;
}

string cxDAXCHjlSA::VBWxEHueaWUZEG(bool fsNexEWwXGbkQuwf, double VdSttWieGicDHbu, bool QXxMt, int WRCxcyCGo)
{
    string MiuWKIDoFor = string("IErnqkCUpVWNsdCdAtpHQcmketCFPgmpZYPGfNgalqBjiVyIzGMPMauzOxTVkKtFumZMwSZCtRgInJfYNyFfvSKRtXomEGzAonkVoaLfSUqvArvTaVapjiLZIvWZoZAWCCGORLIUqMXkyszvyRbSeDiAvNNQatYpJkDNjgakwVfPByRg");
    bool SMCRTRlEpwEIL = false;
    bool FBRJbKtIbt = true;
    double XXlYjBpi = -815177.2453410055;
    string lzWjJGoDKkhVYVi = string("hgublHqIrNJVlLfAGYYzsPwzABMZgmskAxkIAKSUBHWKQJdyCMdXzdRGUXzcADJUMWnZPvosfIpXnVohxgOaZhpWypKUgKTtKtoifbBMxJtnlLDXiPyvggDNCvJLiGyOjsRxElldVWDWCkXUfBXkDQkgBIauhuSUtmSLQjnbxyBBAPRoBbyxZWVEAhMwjRpHlWzsiTaeN");
    bool MPmnb = true;
    bool WCCFXa = false;
    int wsrnaBBvu = 1451513156;

    if (fsNexEWwXGbkQuwf == true) {
        for (int nFFCDegrgRXgE = 438254960; nFFCDegrgRXgE > 0; nFFCDegrgRXgE--) {
            continue;
        }
    }

    return lzWjJGoDKkhVYVi;
}

int cxDAXCHjlSA::HZVdVtszUADPqk(string cmrOQbMZYIPv, double lfiPwqzjSTR, double QiXHxDUFhEcS, bool yTYHwVLfpm)
{
    string egfqE = string("KzBhnAFGIlzNtvFIwuliKTSllANosvnSCOTkzNRgYHBTIp");
    string qRsPlhODGDirWFna = string("ucA");
    double fdjPdsFqdTvxIE = -417242.06585089007;
    string gnGLfwezzyv = string("ghcyjVjqEruGjUpHZKyWvhPyHESMtLduEIZYQeIwlfAeXKZuQuwycMCCgTpDvLcToFlovpJzQevFfnQcXAAzxcmXWTWcmAeAekyNOSaBEztfQLSZMhtmaVXXFVuJAHjBlSWSsLeDQTqAwwVHxKIZGsDPBCNYx");
    bool DuvKafpbav = true;
    bool lIEnamzxjJvGNpKP = true;
    int dEnDFaoCFZ = -1564163995;
    string prUoCZHZlvDzDGV = string("gskhqCaWkkwBYARyZKAioKbKrvGSkcdxRvrfKIiEPbhhBCbVXCWEpSLhbrTIlfKhCiwmWYEdLbrZxeTyMoeREfJPWOdjiEGzNOfVJaaFfIkEPiLOPTivQgrqZzxLBLgkASQAIEvguDQZcnFANvEuCIitHvSVJKgePpVtWmJWZxkdXFvfnkLnBTZQyEFLMXhM");
    bool hILKX = false;
    int logKG = -2143025115;

    for (int PmCJaqR = 1430186841; PmCJaqR > 0; PmCJaqR--) {
        lfiPwqzjSTR /= lfiPwqzjSTR;
    }

    return logKG;
}

bool cxDAXCHjlSA::fMIKmTZvlOux(string cytSCadNVqKz, string dybtrjQOn, string kJrui, string PWxHXJnklLgl, double VNRUUYMITYQm)
{
    int uJkJn = 2036477153;
    int guYKIeMan = 1526750044;
    bool eOkUx = false;
    int UZqYyWNWjzudEBlj = 441834310;
    int WrNuBdCvanqm = -1353387397;
    bool drXdihHBmm = false;

    return drXdihHBmm;
}

cxDAXCHjlSA::cxDAXCHjlSA()
{
    this->YNIieCkUhXPiuMg(string("FeddAKpUIYJKaNohnN"), -177241.79196685294);
    this->VBWxEHueaWUZEG(false, -700596.7742285071, true, 1199970581);
    this->HZVdVtszUADPqk(string("uThKT"), -497440.89535901486, 873835.5416469292, true);
    this->fMIKmTZvlOux(string("RFLMifmKYuoTlgPedmkkxkBOkNglVhEkvIoPyxugsZMqFTZOdAQYgTEfhCnTroFhqRuqrzSdD"), string("wIYNszyhXptQsGMXhXpTjhRcwcTDrTbXZzkoZNNqYwYUocGoqH"), string("wFgQLpaXoniVwMELNtSSsbxJbDBewcitMdcUNiGnRbgiPuoPRUeudxXSaZKKcHozzwsVpydPeT"), string("wsVcbQtuZSiwBAodEnWUUOmJmwcfwsvFGEhZpITlQGnoMBSbUKySrDHKJFvshTomLazVcFIdHuCZhzaUjhQQSyShTzCZqkrzdrGhEJqlXEaxeBJhONvLZplJYmkZxHFJDRIvfHjNfYudVjYFXUziRdAWhFByLUjOoflUkDhCdIAOWoLjdnDDxCrbOEaMkOThDitiEX"), -412789.0398307334);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aTjLNkaJuwp
{
public:
    double XtOWWLLpJtMT;

    aTjLNkaJuwp();
    string oEgFZcEMPIdfkzmO();
protected:
    bool ahDkkNPA;

    bool FbPcVfqQKGOEqa(string nmMQmusDRhhPUBn);
    double TURszbWyEmDhj(int yIcmtQNJGHnPUgx, string wEVgSupFjemV, bool RDAncJaBRcbOOw);
    string aRKKZUSCG(double YNBruZiblzt, bool CIdToIxbSlNk, double IFBVlLRTgLrQfDRH, bool YtSwwI);
    int IQwHJFhO(int XLGAEiE);
private:
    int uxZIJGPvTJwJAb;
    double wtzfNxAUB;
    bool iVIQMkggTfjbRr;
    int hWIoergd;
    int rIaZSyrCCXecVtwG;
    int zKativAURgL;

    double ZBnUTzEzltWG(string dkrGOvLK);
    int COJZbxGV(bool rDTLhViaAMbyflW, double ADWanuXgUs);
    string oKBCeE(string wFUDwstMNQ);
    bool TksAxwQb(int RssHyxC, bool eIPMuQhbkk, int IOxnrbMujuayO, string RGmmteVfEagQXOd, double lxRfEyxCaSIIZz);
};

string aTjLNkaJuwp::oEgFZcEMPIdfkzmO()
{
    bool QMjPGXikVKtZV = true;
    double KSKHGibxy = -897323.6572411348;
    int mVjVE = -1252653969;
    bool tNAoX = false;
    double DSVEnfq = -737867.5723469256;

    for (int QLptIb = 327326199; QLptIb > 0; QLptIb--) {
        continue;
    }

    return string("VNrZ");
}

bool aTjLNkaJuwp::FbPcVfqQKGOEqa(string nmMQmusDRhhPUBn)
{
    string uUejMBPwGM = string("vMvcDLANMZpXDYQfNhbauTXAEUCcZhoeqhiDehoxBPQmhnNSUUnuKdQweLTyjAebDoghTsOiUxrrKwuMsfyCitLGJdBPkZQPcOnEXDpbHArIksMXuMQtSvoAWdvcGLqQHvJpafGhiYOngAJGoEpEtnPipZbIQCROMRffgvKzIVcNLBgBKdwzbTmNUAJKcNRQNeJpSRxEteEPxlqRpHNtNDuQodBIlpSu");
    int ZMVZQ = -1560643973;

    if (nmMQmusDRhhPUBn > string("MInEQwchcTIrdqJUY")) {
        for (int uhvrhZLdqmTMa = 1345972547; uhvrhZLdqmTMa > 0; uhvrhZLdqmTMa--) {
            uUejMBPwGM = uUejMBPwGM;
            uUejMBPwGM = nmMQmusDRhhPUBn;
            ZMVZQ *= ZMVZQ;
            uUejMBPwGM = nmMQmusDRhhPUBn;
        }
    }

    if (nmMQmusDRhhPUBn == string("vMvcDLANMZpXDYQfNhbauTXAEUCcZhoeqhiDehoxBPQmhnNSUUnuKdQweLTyjAebDoghTsOiUxrrKwuMsfyCitLGJdBPkZQPcOnEXDpbHArIksMXuMQtSvoAWdvcGLqQHvJpafGhiYOngAJGoEpEtnPipZbIQCROMRffgvKzIVcNLBgBKdwzbTmNUAJKcNRQNeJpSRxEteEPxlqRpHNtNDuQodBIlpSu")) {
        for (int hmTHXWMWsHhz = 1759910376; hmTHXWMWsHhz > 0; hmTHXWMWsHhz--) {
            nmMQmusDRhhPUBn = nmMQmusDRhhPUBn;
            ZMVZQ += ZMVZQ;
        }
    }

    return true;
}

double aTjLNkaJuwp::TURszbWyEmDhj(int yIcmtQNJGHnPUgx, string wEVgSupFjemV, bool RDAncJaBRcbOOw)
{
    string BUSiA = string("ollnYzaibphppBDpmHQd");
    string uNhamwVdRlSrLC = string("sPAkMxrzoJqJXlWMizKkZD");
    int jkHDen = 241197423;
    string SNsMdvAjyjUBd = string("LERGJJJRCizVaPCeLnRDfBeegbdRSEFhdpNheEvBEPyVjaXicARugchNVAyDSujWArWmKZzfFBeNghPzAPEiJoaqXEzRrIbZcLaGCawuvgelRYHgfhT");

    for (int bfygdLQMszbpZSa = 482168975; bfygdLQMszbpZSa > 0; bfygdLQMszbpZSa--) {
        jkHDen += jkHDen;
        BUSiA = wEVgSupFjemV;
        BUSiA = uNhamwVdRlSrLC;
        yIcmtQNJGHnPUgx += jkHDen;
    }

    return -732492.5356759449;
}

string aTjLNkaJuwp::aRKKZUSCG(double YNBruZiblzt, bool CIdToIxbSlNk, double IFBVlLRTgLrQfDRH, bool YtSwwI)
{
    string SeQsyyTIUiRzpWh = string("uaJJGKkHYWSuABCtQQwvCIWDAyibrEBGFmyijaJySQWiiuKDfMMlzkUljuSTkrqixQLsJUwoVkUTBCzCtLcPjNPZcQxZWINcpuAbcHQXOcEtArCOxrvQxG");
    double PYHrStquKipimeB = -428462.91978612286;
    string hQdHsYQQRbLz = string("dARDinnLZLWESuMGHSbMZIWlkbzWdKRqVktppORJJQvyiAXuplZbOickCQsVmVgadFqGfDsZggANZzHCvVOyvFaTRhgXYatThGutJpcWvPefJltnCjGHvHInXEmJBVcRvfQsKojNCpxjmrWcxUMKlhczNtjGvcq");
    string mkLkKhYA = string("BYUPmJTaiZwaKjFTTsKFgAKagLVhFNJKTKTosNBPDRitOJhmJEzmrbXUdeQTdHTjnLhvgHqwoTRGOgNaGMBzWhZQONqzJTAzqtRhOlYAoDuGHQiagBDndvongeAHSqkCpsIAZyMywrMkyjfeyZDjJCknKexNgAvhzIKQPnzYhXpcJeqvNeOlguwOlNArLQAwOUxKwvPuGXszrgRhPYlPUJsNamVfdGcuhDRVmnuewxwWJqln");
    int uorLaTjANETkPoso = -1729250075;
    string hdCPGPiTlmHeCp = string("BlvmSYsfUWjJvermxKWLdSacCefmYzIQdQNLMbLQmkCvQizGONXWCViUSBXjjzQMmkvXtbVpEenOuKjyASlewCivneyUbVaaJCsZPZctz");
    double MCnVpaMuMguWdEW = -274872.75572052406;
    int AOezmMgbUDSCN = -422472154;

    for (int pRowow = 1608738694; pRowow > 0; pRowow--) {
        AOezmMgbUDSCN /= AOezmMgbUDSCN;
    }

    if (AOezmMgbUDSCN > -422472154) {
        for (int oFKDJkwDiaZa = 2131351733; oFKDJkwDiaZa > 0; oFKDJkwDiaZa--) {
            continue;
        }
    }

    for (int aUvFMfs = 2089692500; aUvFMfs > 0; aUvFMfs--) {
        CIdToIxbSlNk = ! YtSwwI;
        IFBVlLRTgLrQfDRH = PYHrStquKipimeB;
    }

    return hdCPGPiTlmHeCp;
}

int aTjLNkaJuwp::IQwHJFhO(int XLGAEiE)
{
    string kKjItsZ = string("dsnJXctxMKngJCJZVtNfAHwVMbObCnrxiKWVgebNfgyTVLMjYXDjYhoYDBpXsAVdLjwgmPUkuplsEbJPUSxPecpjmh");
    double QhgzYlMPyXh = 416463.3182126387;
    double kobcbqEy = -764735.8686227112;
    bool AkOUMXxECrbIEF = false;
    string OemfVfV = string("NMlxNfxQMPDhdMgBmEPvokafEYiruwoiFzsBZMOKXbGCBRouImmHmWHUMLNvWWSPtTDSCzflRqXhBgdSawhCRmBxkgKWqfPLWeFjExyRGITdMeLrsrpcpwfzRRwELmyREOtmolNcwXixPAuxSSurXMCJqQcOVPFpnXqVxcSAZABGCyViweXMnOieVAUga");

    if (kobcbqEy < -764735.8686227112) {
        for (int OigmQl = 286637964; OigmQl > 0; OigmQl--) {
            QhgzYlMPyXh /= QhgzYlMPyXh;
            XLGAEiE /= XLGAEiE;
            QhgzYlMPyXh /= QhgzYlMPyXh;
        }
    }

    for (int WTxFkIncIZWD = 1840613159; WTxFkIncIZWD > 0; WTxFkIncIZWD--) {
        continue;
    }

    for (int xuYMduOR = 755107542; xuYMduOR > 0; xuYMduOR--) {
        kKjItsZ += kKjItsZ;
        XLGAEiE *= XLGAEiE;
    }

    if (OemfVfV > string("dsnJXctxMKngJCJZVtNfAHwVMbObCnrxiKWVgebNfgyTVLMjYXDjYhoYDBpXsAVdLjwgmPUkuplsEbJPUSxPecpjmh")) {
        for (int GMkoKiKmd = 1183204789; GMkoKiKmd > 0; GMkoKiKmd--) {
            kKjItsZ += kKjItsZ;
            kobcbqEy /= kobcbqEy;
        }
    }

    return XLGAEiE;
}

double aTjLNkaJuwp::ZBnUTzEzltWG(string dkrGOvLK)
{
    double kwtAiDyG = -393762.6240520178;
    double UZPoEh = -955268.0539894804;
    int PcpOqWElpgU = 225564469;
    string jgJZZjGzK = string("MJRonPnkjPhTnHZKGlGFlaXAhTelbDuiWsTJmiLIojYXdmuKWoReYtalweitpyGNvrcLnIhLuBOdjWUDZMMPayWOsAiqAjKOuJHXRhouDcgwuwzaRRDbyOcEXEkGuiwnLwPCZtjuvBsPFpKwDjUJtabThsKeSnaUgQExMcvUbGQrOMYkHPySHqdQKbPzpIbqOqYIMYsggkPGoRsBAcyEgucFUKUGowRtNqbklAiecSDVLiUFFaheDN");

    if (kwtAiDyG < -955268.0539894804) {
        for (int KiPsYvg = 2122775885; KiPsYvg > 0; KiPsYvg--) {
            kwtAiDyG /= kwtAiDyG;
            jgJZZjGzK = jgJZZjGzK;
        }
    }

    if (dkrGOvLK < string("MJRonPnkjPhTnHZKGlGFlaXAhTelbDuiWsTJmiLIojYXdmuKWoReYtalweitpyGNvrcLnIhLuBOdjWUDZMMPayWOsAiqAjKOuJHXRhouDcgwuwzaRRDbyOcEXEkGuiwnLwPCZtjuvBsPFpKwDjUJtabThsKeSnaUgQExMcvUbGQrOMYkHPySHqdQKbPzpIbqOqYIMYsggkPGoRsBAcyEgucFUKUGowRtNqbklAiecSDVLiUFFaheDN")) {
        for (int bZygClVPpFsVs = 1072637806; bZygClVPpFsVs > 0; bZygClVPpFsVs--) {
            PcpOqWElpgU += PcpOqWElpgU;
            PcpOqWElpgU -= PcpOqWElpgU;
        }
    }

    for (int yCGSsiKVKIi = 761834201; yCGSsiKVKIi > 0; yCGSsiKVKIi--) {
        dkrGOvLK += jgJZZjGzK;
        PcpOqWElpgU = PcpOqWElpgU;
        dkrGOvLK = dkrGOvLK;
        dkrGOvLK += jgJZZjGzK;
    }

    return UZPoEh;
}

int aTjLNkaJuwp::COJZbxGV(bool rDTLhViaAMbyflW, double ADWanuXgUs)
{
    double DdNWFUxl = 744964.8085254232;
    double lExqmSBBdA = -736074.1350804463;
    int ksYvLSFmlUb = -410694910;
    bool eveCbfll = false;
    int tQoroPlOWTWMT = 1762957523;
    bool LIaIEeLknkWbgVq = true;
    double IJKQjCjelsirl = -643669.2232379527;
    int NkgbdVov = 1886401434;
    double MCKPTGgfavfsnH = 431360.5598719359;
    int mpPWrwTClGREj = -820783726;

    for (int hfvqsEBMIKqa = 1227107927; hfvqsEBMIKqa > 0; hfvqsEBMIKqa--) {
        eveCbfll = ! eveCbfll;
        DdNWFUxl += DdNWFUxl;
        LIaIEeLknkWbgVq = ! LIaIEeLknkWbgVq;
        lExqmSBBdA = IJKQjCjelsirl;
    }

    for (int qTWeYanc = 1399606692; qTWeYanc > 0; qTWeYanc--) {
        DdNWFUxl /= MCKPTGgfavfsnH;
        lExqmSBBdA -= ADWanuXgUs;
        MCKPTGgfavfsnH += lExqmSBBdA;
        MCKPTGgfavfsnH = ADWanuXgUs;
    }

    return mpPWrwTClGREj;
}

string aTjLNkaJuwp::oKBCeE(string wFUDwstMNQ)
{
    bool fRNftK = true;
    string wcKLGa = string("AnNBtFAzADPhcgaLMnejWshECcGZMkzHjYxfpruAdLJYYiuacXYXQwI");
    bool uzySfdStMI = false;
    double HXHVrldSprx = -240456.26282031895;
    double CbSCQNVK = 758886.8390264435;
    string ooQIaMdN = string("zJPosCOpOJbePsutCCZVFFNoFHyPVFBaegitNmVjYmmZAjRHnWOwyujeyAmeZFASXCOogEQACwXBqjUMHENfyUCNlECbomsfeXjzBAMoUxpwRnSjqeagWdxwiNJaspzdIDiNNaYNz");
    bool rEpsbnfZy = false;

    for (int dCDwEyegWTe = 469705110; dCDwEyegWTe > 0; dCDwEyegWTe--) {
        wcKLGa = wFUDwstMNQ;
        uzySfdStMI = ! fRNftK;
        rEpsbnfZy = fRNftK;
        CbSCQNVK *= CbSCQNVK;
        rEpsbnfZy = ! fRNftK;
    }

    for (int KcgEYcBvuhCqP = 1856380337; KcgEYcBvuhCqP > 0; KcgEYcBvuhCqP--) {
        HXHVrldSprx *= HXHVrldSprx;
        rEpsbnfZy = ! rEpsbnfZy;
        uzySfdStMI = rEpsbnfZy;
        wcKLGa += ooQIaMdN;
    }

    if (wcKLGa == string("AnNBtFAzADPhcgaLMnejWshECcGZMkzHjYxfpruAdLJYYiuacXYXQwI")) {
        for (int RjZNdrs = 404736419; RjZNdrs > 0; RjZNdrs--) {
            wcKLGa += ooQIaMdN;
            uzySfdStMI = ! fRNftK;
            uzySfdStMI = rEpsbnfZy;
            rEpsbnfZy = ! fRNftK;
        }
    }

    for (int IioeiB = 1596456357; IioeiB > 0; IioeiB--) {
        rEpsbnfZy = ! uzySfdStMI;
        HXHVrldSprx /= CbSCQNVK;
    }

    return ooQIaMdN;
}

bool aTjLNkaJuwp::TksAxwQb(int RssHyxC, bool eIPMuQhbkk, int IOxnrbMujuayO, string RGmmteVfEagQXOd, double lxRfEyxCaSIIZz)
{
    int iLeaalVdq = 960286346;

    for (int TuxVE = 698622490; TuxVE > 0; TuxVE--) {
        RssHyxC /= RssHyxC;
    }

    if (IOxnrbMujuayO == 960286346) {
        for (int NpWHZvaOk = 170993536; NpWHZvaOk > 0; NpWHZvaOk--) {
            RssHyxC += iLeaalVdq;
            RGmmteVfEagQXOd = RGmmteVfEagQXOd;
            IOxnrbMujuayO *= RssHyxC;
            IOxnrbMujuayO *= iLeaalVdq;
        }
    }

    for (int FupsfuXNpUb = 180001884; FupsfuXNpUb > 0; FupsfuXNpUb--) {
        RssHyxC -= iLeaalVdq;
    }

    if (RssHyxC == -216688555) {
        for (int nWPuDEV = 1638597594; nWPuDEV > 0; nWPuDEV--) {
            RssHyxC *= iLeaalVdq;
            RssHyxC *= iLeaalVdq;
        }
    }

    for (int yFHNkUcJAOp = 1008245335; yFHNkUcJAOp > 0; yFHNkUcJAOp--) {
        IOxnrbMujuayO += RssHyxC;
        iLeaalVdq += RssHyxC;
    }

    return eIPMuQhbkk;
}

aTjLNkaJuwp::aTjLNkaJuwp()
{
    this->oEgFZcEMPIdfkzmO();
    this->FbPcVfqQKGOEqa(string("MInEQwchcTIrdqJUY"));
    this->TURszbWyEmDhj(1824749794, string("adSrTnSCJzYESHfTapVSzfehzHkqhAVmlfKyXkWcPDje"), false);
    this->aRKKZUSCG(898267.8053581223, false, -451350.90883030545, true);
    this->IQwHJFhO(759056738);
    this->ZBnUTzEzltWG(string("QqybhiygRyhwMHomPLmTdbaGDkrjeusUsCKvprUEoWnUzdIWiJNWkOLNQEsKGdbNphFdOBqHAVNBZQUPKMfvKsauslPhqdSFknxoeBJvFvnexOyYAEKVWquxtuPNwKdRc"));
    this->COJZbxGV(true, -352891.99107464106);
    this->oKBCeE(string("IaYZBNepaAAYPgLRDEIyjweNdxwmgoUpSgQlkoUqcrffLiFxnMDlkyQaQYsCCZREnhDVOplPiHZsTGIhnaFHsUgSDzKGrMlaDDnAsFTtOqxUcDTbQEtHPkfnmvvVZnLWwirsLCwqjZcuoWDtMnRqiFRpQetaqpYCKtegzhmJARayEcDRARKMNsneNckIyJsBJMSbgvCdXBGyhCFIhsuXuQEQQxrEhWeaendCJSByGeTuSPnEOOuSatCdLzp"));
    this->TksAxwQb(-216688555, false, -884228291, string("XhEUajAeUNPmNceeLnWMsxJggJzWNwGulUAuGjbSJFuDGEhvDLMpaADKpwBArCjTnEWtpMmvpRAelpjImvxyuMLrOdkEiZaqMFoacbLuDlJTcbNdVRlJvNvfnhRUnLogvtYrivBlkLtXgLNutXqCBMDAmfTioENHSQBcjvVYeNewYTiYXdCgTlYncrjTWwFnOJwqPBTVeUQibVEUrLJaAEzezM"), -463878.4166898907);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qCZswUqiiUHYaXsA
{
public:
    int bjpadrNAEkkHxw;
    double WhPWaiylaIEvIgT;
    int VgXrX;

    qCZswUqiiUHYaXsA();
    int KgUFXUpXo(bool NDeZR, string DRozBsiBCQyD, bool jkPMlq, double BlFtrLHhRCsxSv);
    void ZLPEbJVfAL(double CiQmasuoerYcSZbr, double sLZorIOBwMR, string LVIDYQnKUqxUWK);
protected:
    int rHbfliTR;
    string nbnRMkAKvTeoqONU;
    bool SNagHmoHTLalsm;
    bool LLwhuQBEhbgPPs;
    bool CwyGuLBYcC;
    string vnfJyWVj;

    int qTdaDDHykxmPN(int XApYGJGLUeEpexC, string rIYwZkiLnVbWhu, int iTYGgPDGje);
    string BGcxhv(bool CDjwDeESVljQU, int AzzqXOilnodKl, double cyCFRnxqydrlw, double yUUdFwTzY);
    void FBWoo(double DPvSmKRjrMJmNO, double PPXgxTdzXJO, double clWGV, string PFKIWN);
    double ygbKjcmdzcUdHAU(bool cPdgPVsswMRI);
private:
    int CMsjuZ;
    bool WvUcyXxLwYEGGeI;
    string BquTnBYaes;

    int FJmXCflvRdtQmjeL(int AbnVu, bool lKxLKX, string ajHxOrDkQpbaVcKj, double ajTiGKsxTyshm);
    double jnHdHacpYrLi();
};

int qCZswUqiiUHYaXsA::KgUFXUpXo(bool NDeZR, string DRozBsiBCQyD, bool jkPMlq, double BlFtrLHhRCsxSv)
{
    int fjyjOPFktKOEraY = -1233870703;
    string uxMZzXw = string("dqXvYciuOOnOhxbCdIFIIqahhaISJZGUMGZrtkfZSgRPvzRRiZYoJDAfkNwpBpHdPPCEgLcawIIKZRQSDhMSpxCPFDbWTycxLaFVPWNCdwLOjxfjsdBdZKdYvGViXOTDRmhBczvgNPalZHYMBonBaJuqahyHlibpNrNwYySsJavGuTYvOeyCHytGGkOFyPzJSAnHPqxQPCFerOLMEVMKwcjOMwzwNoeBUnhSnYMdWJnFLGiXRadL");
    int vRrbaSeujEkVqhHy = -320890042;
    int YLrSbcHhYBUFlcJ = -372177409;
    string WxiLKgwNRUmpZ = string("NFoeWsNZutgcsvYZXGsPfdlXLbTkuGrpbnQjmZoOferlZDCawKEhFZAGpFEsPGpoIddJJMtijkEydkEO");
    string FWyQNXuSraP = string("iZWiuOjdiJLUcfwYuIDOqfCVfmJnUFDvJZOmLqvEqvtRwUAHEjVbHlvcWfkDakubmkeUtrHZzjRqwACVVTrLvAclXbWSfzkpjOzQZsEcwOAcsFPdosnXqWAVXSQZIsihjmdizydrNJFeEVHBhnwpl");
    string Ettwd = string("pbumgGXabYdOSfxPvMVuXMztCbdkNHszuGmbGGxXUhlvvanZexffObpkAKbvIMnSPibCqGofjTiScvyCDDqTUtMGQHbDgPHLIFYMbMGtZnoTaMDVrJdjMHEqXpIaqkyYXiStoGd");
    int uNsyBGb = 1922600109;

    for (int OSCKMYcfQMn = 637384591; OSCKMYcfQMn > 0; OSCKMYcfQMn--) {
        continue;
    }

    for (int KNRhJYwc = 61071207; KNRhJYwc > 0; KNRhJYwc--) {
        continue;
    }

    for (int ODHnlCQc = 1045795091; ODHnlCQc > 0; ODHnlCQc--) {
        fjyjOPFktKOEraY = fjyjOPFktKOEraY;
        WxiLKgwNRUmpZ += WxiLKgwNRUmpZ;
        YLrSbcHhYBUFlcJ += fjyjOPFktKOEraY;
    }

    return uNsyBGb;
}

void qCZswUqiiUHYaXsA::ZLPEbJVfAL(double CiQmasuoerYcSZbr, double sLZorIOBwMR, string LVIDYQnKUqxUWK)
{
    string hBugSqFaFl = string("PLyL");
    bool IKoLaefmymHq = false;
    int nyvqozrm = 43056962;
    double sylmScUc = 341384.70066866424;
    string NwrlqvgDK = string("FnGjtVHauLLYrHwAkWzOPKraAFcotsiqliaEyqspxSlHKoiQWNbdxXRdBjoYfRisUWrRCuxwmvDEgEQVt");
    double TQhZlxixSqVw = -942913.4412052047;
    string zmuIwVfnopvBGjA = string("WMGnOFwpsGxssMDvOtXKsLpOtwYTHrPHzdUpAwUMsrZdDBTkqERiJRtuuMPxroLsQEaLgwcuVIoizUpsMxeOWRJgDfconrSlPvcSUfHZJRvxNCE");
    double ERFgZovr = 843951.5824184709;
    int pYEhCMOsikBreN = -128094412;

    for (int iKZkWJqCzc = 725131973; iKZkWJqCzc > 0; iKZkWJqCzc--) {
        continue;
    }

    for (int PwNbwyyailgtI = 103657841; PwNbwyyailgtI > 0; PwNbwyyailgtI--) {
        sylmScUc -= sLZorIOBwMR;
        sylmScUc = ERFgZovr;
        nyvqozrm /= pYEhCMOsikBreN;
        NwrlqvgDK += zmuIwVfnopvBGjA;
    }

    if (LVIDYQnKUqxUWK != string("PLyL")) {
        for (int DmMqYaHiQig = 2057961029; DmMqYaHiQig > 0; DmMqYaHiQig--) {
            continue;
        }
    }

    if (zmuIwVfnopvBGjA < string("WMGnOFwpsGxssMDvOtXKsLpOtwYTHrPHzdUpAwUMsrZdDBTkqERiJRtuuMPxroLsQEaLgwcuVIoizUpsMxeOWRJgDfconrSlPvcSUfHZJRvxNCE")) {
        for (int OaVGhODlpRdj = 1083522603; OaVGhODlpRdj > 0; OaVGhODlpRdj--) {
            TQhZlxixSqVw /= ERFgZovr;
        }
    }
}

int qCZswUqiiUHYaXsA::qTdaDDHykxmPN(int XApYGJGLUeEpexC, string rIYwZkiLnVbWhu, int iTYGgPDGje)
{
    double EkRbGSoMBwjlaog = 260122.6797536075;
    int txqwadf = 1114679803;
    int VlSsNfnANDy = 2130691818;
    string OJKAlXwwiOQbjU = string("hqboABjMwUchBMbeFUoHdfhkXqfKxOqcmgjZYsRekvhGsQvPcgubJZvLKqjyFbuAVzHdUZhcAERgeeYGjSQUQrhHrvgVFkFNkiwpAFHTBpOYdKgsoFJYSUhqDBIOrmdiuksOfzibSGklYrvpyuCmziZtEohYSKiGXWOYQtbrqrbSQVjFcjyzaHGVtMhlTPeJuKCAhHKUicHpmOFc");
    double HpkcKzqxoEwbiK = -617735.1872476008;
    int gjNgkVPzDZ = -88874749;
    bool ioZllQSwiBhskC = true;
    double tarKtys = -830112.9388237713;
    string QFDOD = string("qzzymVbXDnXsPIwwaIeqaxODMPizSrepTRxqXyaKEPyFEkJkzLnjaxsvXdVmUhBSvENlLjPlIKDuXSiVtSVJHpQfUozCacXJ");

    if (txqwadf > -88874749) {
        for (int LeXzRbk = 1441975095; LeXzRbk > 0; LeXzRbk--) {
            VlSsNfnANDy -= VlSsNfnANDy;
            OJKAlXwwiOQbjU = rIYwZkiLnVbWhu;
            VlSsNfnANDy /= iTYGgPDGje;
        }
    }

    for (int WPvAZwagb = 1849281248; WPvAZwagb > 0; WPvAZwagb--) {
        continue;
    }

    if (QFDOD >= string("hqboABjMwUchBMbeFUoHdfhkXqfKxOqcmgjZYsRekvhGsQvPcgubJZvLKqjyFbuAVzHdUZhcAERgeeYGjSQUQrhHrvgVFkFNkiwpAFHTBpOYdKgsoFJYSUhqDBIOrmdiuksOfzibSGklYrvpyuCmziZtEohYSKiGXWOYQtbrqrbSQVjFcjyzaHGVtMhlTPeJuKCAhHKUicHpmOFc")) {
        for (int JYxOCqvZoO = 1465593230; JYxOCqvZoO > 0; JYxOCqvZoO--) {
            continue;
        }
    }

    if (HpkcKzqxoEwbiK == 260122.6797536075) {
        for (int DCQKjBuiU = 596217979; DCQKjBuiU > 0; DCQKjBuiU--) {
            ioZllQSwiBhskC = ioZllQSwiBhskC;
            VlSsNfnANDy = gjNgkVPzDZ;
            XApYGJGLUeEpexC /= VlSsNfnANDy;
        }
    }

    for (int toIlgZyz = 890465075; toIlgZyz > 0; toIlgZyz--) {
        txqwadf *= XApYGJGLUeEpexC;
        gjNgkVPzDZ += VlSsNfnANDy;
        XApYGJGLUeEpexC -= gjNgkVPzDZ;
        iTYGgPDGje -= txqwadf;
    }

    for (int zaOcFpGiAsaHX = 2096781895; zaOcFpGiAsaHX > 0; zaOcFpGiAsaHX--) {
        QFDOD += OJKAlXwwiOQbjU;
        OJKAlXwwiOQbjU = rIYwZkiLnVbWhu;
        EkRbGSoMBwjlaog /= EkRbGSoMBwjlaog;
    }

    return gjNgkVPzDZ;
}

string qCZswUqiiUHYaXsA::BGcxhv(bool CDjwDeESVljQU, int AzzqXOilnodKl, double cyCFRnxqydrlw, double yUUdFwTzY)
{
    int rhUkNqZwtZjnmW = -1833397335;
    int syPYdflwpKOJp = 398288531;
    string TBJOALtAcQk = string("gsFfbQKrqFHqzAiFmNJeprIJMXcAffRrCvSjtiJwfEMSBGMcWDTUJmvXUIWDSQgoCtiiNpswughWxJAfqdGozGcTlYWLMQTMpnVHjkjYxrPiRgeAJVDvZeAGgqXLCrHPfDARVoqQqFtLqKMBljrNVOIwVlApRnVLfLtjUHIsOvmxtlxtnswpGMvBPTkSijEboWGGwqwFEehiTfp");
    bool ANniRgif = false;
    string DLisBH = string("vFjiAvloImNESTSUaIxqxjfWtSYkiiDdJCg");

    for (int ZBJdRxppecgqLq = 1271908672; ZBJdRxppecgqLq > 0; ZBJdRxppecgqLq--) {
        AzzqXOilnodKl = AzzqXOilnodKl;
        DLisBH += TBJOALtAcQk;
    }

    for (int uqlvb = 675056924; uqlvb > 0; uqlvb--) {
        continue;
    }

    for (int sgtJg = 343652739; sgtJg > 0; sgtJg--) {
        ANniRgif = ! CDjwDeESVljQU;
        ANniRgif = ! ANniRgif;
    }

    for (int WzdnT = 290086422; WzdnT > 0; WzdnT--) {
        syPYdflwpKOJp /= syPYdflwpKOJp;
        yUUdFwTzY *= cyCFRnxqydrlw;
        AzzqXOilnodKl = syPYdflwpKOJp;
    }

    return DLisBH;
}

void qCZswUqiiUHYaXsA::FBWoo(double DPvSmKRjrMJmNO, double PPXgxTdzXJO, double clWGV, string PFKIWN)
{
    bool oQGSFzHpTkOAGiKB = false;
    string fuxqRHjKUa = string("DVKIFIsoWtRUaOoagQTTWIBbNnqujbiDpHxaiCiynKlmqayCzAkGTfdgcVNQnqwRABTrIeoQcBqYINmyBlFVidEwtXprStNJKXlKPTJTZKcGhPHUyLYDeSIrIPgYCcNMwKYAcaNVNyoYFhJNSpIPtvdZbNQnEyicQctZjaaPHLUuykCQBVdqIlxSkstjtOBJzuRcbiHRRXDPB");
    bool KLeZh = true;
    bool EuhzSoD = false;

    for (int idpavHIwM = 601898349; idpavHIwM > 0; idpavHIwM--) {
        continue;
    }
}

double qCZswUqiiUHYaXsA::ygbKjcmdzcUdHAU(bool cPdgPVsswMRI)
{
    bool CUYqrHYzof = true;
    bool xjWFzqzk = false;
    double SNjNGpQBwxOFyZ = 851635.6427295561;
    bool kEdDeF = true;
    bool KxMLAeJJobbR = true;
    string pSuoaiumCJm = string("spkqeAqUgwiUdIjUlyWCcyIBYYGawqoYgmukXcQNLObvupvknQDaxKbeObretAFEWPRJgBQEzHihxgWvacUPUjBhqeIb");
    string JSdEbCEFUIsxjH = string("uzuewlDCxmgjRfwuDuKKvJzThfKRGHLCGneYKgqCnwKCMXaFOCEvOUYvWsqXpDrZUprKvBtyiiLznFWAULdKwxKTVpveHzmSMbjUmuQqaMstgiroxuPvKcOndoTNwudshAlRhsUPsXejiyxjTvwkMrLzGRyirlVjnGLFVdAmeoZLTYHUqMipSJCMirzITXNPUmZFHvKMkXEGLBMgDXLIFkbDXJQhGATNLjlrmsyogmAcgcVgiZx");
    double mzgGTCnGos = 690503.5104232312;
    double jEDfbodZxdCtxTKj = -280318.63978830795;

    for (int FKrycvEaicSva = 922926321; FKrycvEaicSva > 0; FKrycvEaicSva--) {
        mzgGTCnGos *= jEDfbodZxdCtxTKj;
        KxMLAeJJobbR = ! kEdDeF;
        kEdDeF = KxMLAeJJobbR;
        pSuoaiumCJm = pSuoaiumCJm;
        KxMLAeJJobbR = CUYqrHYzof;
    }

    for (int kDttBzjudpkULn = 493046697; kDttBzjudpkULn > 0; kDttBzjudpkULn--) {
        CUYqrHYzof = ! kEdDeF;
    }

    return jEDfbodZxdCtxTKj;
}

int qCZswUqiiUHYaXsA::FJmXCflvRdtQmjeL(int AbnVu, bool lKxLKX, string ajHxOrDkQpbaVcKj, double ajTiGKsxTyshm)
{
    double hBOmtQuUEl = 466484.32494191057;
    bool clMhKJ = true;
    string lgZygbKy = string("IXgRIWauwqLrMQMtcegVBirmOkagcNLrOcLieBVWTCTgEMDZcleOuiQQKwPcaSbydOzskBsWqUpTaEKQkgfBYfZwVqWIPOiNyJYcXtttYPsalDiOfOZJElzCOQTZvpLERNcemsvRgySyttgooueGSJACTBt");
    int fjzJHIBWS = -712661069;
    int fhZnI = -225576660;
    double EFzXZLaTnyBAXtSS = 503345.62956880004;
    int tziqbRTJuYyZ = 1874227402;
    bool mDpsfE = false;

    for (int aMHrKmw = 1268414797; aMHrKmw > 0; aMHrKmw--) {
        hBOmtQuUEl *= EFzXZLaTnyBAXtSS;
    }

    if (AbnVu <= 1874227402) {
        for (int LApyuZMjC = 1712745245; LApyuZMjC > 0; LApyuZMjC--) {
            clMhKJ = lKxLKX;
            tziqbRTJuYyZ -= fjzJHIBWS;
            tziqbRTJuYyZ -= AbnVu;
        }
    }

    if (ajTiGKsxTyshm == 503345.62956880004) {
        for (int ObVNxLN = 1793836128; ObVNxLN > 0; ObVNxLN--) {
            fhZnI /= fhZnI;
            hBOmtQuUEl += hBOmtQuUEl;
        }
    }

    return tziqbRTJuYyZ;
}

double qCZswUqiiUHYaXsA::jnHdHacpYrLi()
{
    double wgJrvaVsXl = 29966.45696290275;

    if (wgJrvaVsXl < 29966.45696290275) {
        for (int ZCFYFn = 1357160105; ZCFYFn > 0; ZCFYFn--) {
            wgJrvaVsXl -= wgJrvaVsXl;
            wgJrvaVsXl -= wgJrvaVsXl;
            wgJrvaVsXl /= wgJrvaVsXl;
        }
    }

    if (wgJrvaVsXl <= 29966.45696290275) {
        for (int JuubkDPByWXAmk = 2000154023; JuubkDPByWXAmk > 0; JuubkDPByWXAmk--) {
            wgJrvaVsXl = wgJrvaVsXl;
        }
    }

    return wgJrvaVsXl;
}

qCZswUqiiUHYaXsA::qCZswUqiiUHYaXsA()
{
    this->KgUFXUpXo(true, string("ExMuQNpQUUxdSKrYOqNjwCkThmyZsCrIxvucVRZRTcNuwxiaqdahftUgZRldpYqAPKgDLrcRZVTKcrkSGqOxSxDEsIXXWrBanyxfjdfRTESxQWvFwXygUEqdEMuFMXoLcPkQvzcubsWVyNkgpjtnQuVuxDpkayjDvVfRotu"), false, 619108.7709960913);
    this->ZLPEbJVfAL(732623.7918856075, 755364.3911115135, string("wqkyzTRtKPNsVbtHXsfoqWhFQGRvBPQgYgdVypWsASayNsyMRYvYAynuKWbwyexwG"));
    this->qTdaDDHykxmPN(2102076511, string("ZhINdFMpASztBYCFPWhRqGFblGEvNqSheDSAjqaMXwVBqEkkyFsLz"), 422092580);
    this->BGcxhv(true, 235691715, 297678.52969663596, 269739.6424712678);
    this->FBWoo(-786508.5305031172, 95067.65825977884, 10908.31457072574, string("hCwXOUjrDzaTBq"));
    this->ygbKjcmdzcUdHAU(true);
    this->FJmXCflvRdtQmjeL(-874675780, false, string("JmwPWJNlJrrOJUrPkIxeNlhnVzorpwyLjfPfwnIIHJkREKmnYCYCKZWSsKkDcvcBEHruKuMDzGoGQOsqhAVGUVrBJDbpPHRrblPuwQuPzQQqpixeESfFNuxUwoEsUkHlmcwFvPweDyYmqtzaJqfwekVcqbVRykNkGdDNflhSgXcVZbDVRmBBnVnBUVJHNbfPOxmfFeLEGEHjHIVudvA"), 100977.11198802755);
    this->jnHdHacpYrLi();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DoqnZDtSBRD
{
public:
    int kmNPKWfVQwFUNmUf;
    string pUVwThz;
    int PKxIWMfqqkUX;
    int QjjsjWaR;
    string vTJbKJwR;
    double GuzxnOVoJxV;

    DoqnZDtSBRD();
    bool dCmnQEiprjgI(double rCamsxvI, bool LqRGHXVc, bool bEvdPyQMbQmdu);
    bool ajyUFeOzMaiiPMF(bool SjXKZKQuHfrKqB);
    bool gZXNJMrGUym();
    double lDUijzdQi(double rdXffCTcedNSLs, bool DWBWlkBrbqUb, bool fuXUnywtQTXMGn);
    bool xRzoOPqNttfkm(string LHsALBuNhkSFVI);
    string MjQfBTMNMzlec(string HHZMTYZrNSJTj, string kDPNqzl);
    double vqJbHa(string nNPwzcCvBTXqRDMh);
protected:
    bool HEPMw;
    double cuNUjy;
    bool NXOTgPxw;
    bool wOwvIvWHjdLZIR;
    bool OuiaWOgjm;

    double RgLtKpKAVZ(string DPcGhMDLbrrUhx, int EPNHCew, bool PUClcJhHvGSGz, int ZpKvXKTkuugWsrl, double qODhdcdeaaWz);
    void IRBrNBWhbH(bool DqbfogGeclLonxXV, double lgZOGhQVlYvasGO, bool WfyIYQIehXjMoc);
    void TBxmRNho();
private:
    bool PBeLsOivmxSgJ;
    bool fPpSmzVUbrsi;
    bool EfkdNIZChEfiTq;
    int VXAscBKSp;
    string FKEbs;
    bool AvKlsJIy;

    double ppHGuV(bool bGKqDPJxpBC, int GxyqNitoNpfBbXQ, string eRTkyAETsUWiXm);
    void Svbhf();
};

bool DoqnZDtSBRD::dCmnQEiprjgI(double rCamsxvI, bool LqRGHXVc, bool bEvdPyQMbQmdu)
{
    int AGFIFikFvA = 1120464375;
    bool GdDLMiNsekZpM = true;
    bool NzhvVUDe = false;
    bool McZYVzpSvLqTFx = true;
    string zRGxcxANuSdazE = string("kGNmYpibkEDZPIsroclnWEGiwnLAlruyrBeOTYvqeeLfeZCGCJQrTWLzJmeBTUKwvMOEdPVtdVHKCwvODcXWtananLNZqafrZgnUfNKbWqzCdzEM");
    string YHguaVNjxXjgZD = string("MSNkRiyYyEdCQYIiliwtQxGeklXlcZwEqTTgnAaODudjaurNqHfVxBleymrqMtfcOTYTFhanVNWARvPIeTbyBpgUkCsOERhNOreeWOkWNFyhFVCPcaZCDGBVFuNNFbEgCHqPeElTMbwsPZF");
    string xdPFLghfHrU = string("xZTOVMlIUkcaeHBonkzbSYOczcUDGOYJzzKdIbcXUyJnLBWNkstPPdBAVIfWSHroUnjbCcksnMjrhBYFwlBhjVdzFiavtMjWPKEDgdCCbcJgVMTIgPXOEkkWTOdBQBWZKODCHJixYJHgah");
    string uKndrwkuE = string("CSdPPsQRmGWoPtzSluXugwgTgcvETGjSDiiWZiAboAYygEmANwrKzpzZmJymMLiBXkJascQLwMukHIsAmROzPNIScZQRiMOeACczUwSbnGplRfHKnjdgiKqURQJsEzdCXVKvYkVnBkGUQJdmBChKYcAQbIhiKiLYYRmAgaaQJJzGwlkdDJaMuE");
    double LwDpoKEWxUYFFz = -32291.876217604684;
    int TAkaz = -130280095;

    for (int SierxPAQsrgrs = 1713607634; SierxPAQsrgrs > 0; SierxPAQsrgrs--) {
        continue;
    }

    return McZYVzpSvLqTFx;
}

bool DoqnZDtSBRD::ajyUFeOzMaiiPMF(bool SjXKZKQuHfrKqB)
{
    bool VxhXwiaezXNjmnl = true;
    int QiyxFCFuMOgDVkLC = 622582289;
    string eJHHRDiCueshpoIr = string("ZhOGdGLiVwNFrFMKWLMphZVZKTqzoBwgeDGroyflBOtGOtxkLubRwQsGYfzRhUcxHmKTBCtlSNnwTTTfoKRAiDMYwJ");
    double dfJBnoeCEpFm = 753969.1054995663;
    bool plZluAQoqOoXqy = true;

    for (int sQWvzXbQBHxZC = 77781223; sQWvzXbQBHxZC > 0; sQWvzXbQBHxZC--) {
        SjXKZKQuHfrKqB = ! VxhXwiaezXNjmnl;
        SjXKZKQuHfrKqB = VxhXwiaezXNjmnl;
        QiyxFCFuMOgDVkLC *= QiyxFCFuMOgDVkLC;
        plZluAQoqOoXqy = ! SjXKZKQuHfrKqB;
    }

    for (int uPnrksuQqBaBRP = 1618451907; uPnrksuQqBaBRP > 0; uPnrksuQqBaBRP--) {
        SjXKZKQuHfrKqB = ! SjXKZKQuHfrKqB;
        SjXKZKQuHfrKqB = plZluAQoqOoXqy;
        eJHHRDiCueshpoIr += eJHHRDiCueshpoIr;
        QiyxFCFuMOgDVkLC = QiyxFCFuMOgDVkLC;
    }

    if (plZluAQoqOoXqy != false) {
        for (int kjUjHVjSlTUM = 1129848024; kjUjHVjSlTUM > 0; kjUjHVjSlTUM--) {
            SjXKZKQuHfrKqB = SjXKZKQuHfrKqB;
        }
    }

    if (VxhXwiaezXNjmnl != true) {
        for (int ijLAR = 1430275486; ijLAR > 0; ijLAR--) {
            plZluAQoqOoXqy = SjXKZKQuHfrKqB;
        }
    }

    return plZluAQoqOoXqy;
}

bool DoqnZDtSBRD::gZXNJMrGUym()
{
    double tUnwAuyf = 883721.1191001796;
    int rEQAWSb = 80552102;
    string nBzzEgSVoSPwkMQ = string("XvTxucTTljcEnRDJRTpYomCYExQWixRoqivoQyyjMCsIqnPKdhxMnwMcOhCGWUHlWcvUQimlfroBOWegLivSqDmEXtpYjTlNwVrlHneiJLJDHsudGPdChZjjsVHUSLnToWHgDGFyYwFJCWkVCeGpOyFBNxurUySmmwDlHSBQUrZQnwdIyhwMLqhechUehZqrTyKpqrNXqzabDsFOvoINQdeQJrtZuxtEuBGwNAkSiviua");
    string DAovkuHNqBuFF = string("LBTTIgdPwYfLHqROTSpcMpTQnzZZNNwKpIRhtuRYmCDypceusiygBlMFqlxLonTpWCfzvQKZXDTLXNcUmjWgSrJnVnAIgfGRwoIqwisqHEttZWAYrrEPTkFgysYYtaMlthYoSCMmqkjTHCMUqDUOfzwlWGebzJUH");

    for (int bzaIshec = 1336984215; bzaIshec > 0; bzaIshec--) {
        nBzzEgSVoSPwkMQ += nBzzEgSVoSPwkMQ;
        DAovkuHNqBuFF = nBzzEgSVoSPwkMQ;
        tUnwAuyf /= tUnwAuyf;
        nBzzEgSVoSPwkMQ = DAovkuHNqBuFF;
    }

    for (int QmMoAzwCujysweHe = 656693368; QmMoAzwCujysweHe > 0; QmMoAzwCujysweHe--) {
        nBzzEgSVoSPwkMQ = nBzzEgSVoSPwkMQ;
        nBzzEgSVoSPwkMQ += DAovkuHNqBuFF;
        nBzzEgSVoSPwkMQ = DAovkuHNqBuFF;
        DAovkuHNqBuFF += DAovkuHNqBuFF;
    }

    return false;
}

double DoqnZDtSBRD::lDUijzdQi(double rdXffCTcedNSLs, bool DWBWlkBrbqUb, bool fuXUnywtQTXMGn)
{
    double UYScjYuCIblZO = 512039.69192171167;
    double iEiLifBtpTEm = 156093.77018688156;
    double tpudbNOEy = -1024352.9721776609;
    string cFMmYlrxuuRnSh = string("AXJQZoWFXJLpawjoBXwEKmtSClrYNPGhenzBnjGEuzerCmxnhFooJeLEKkkMArYxeUvWmEKnpUkFeaoNkuprtHBzZoTgenRdOhFtYLjDEbzwInIxthzzdzBeVwtaKVKSFMZCJGGpOJlUEEHCpjLXGRnHjuXsiUvlVynBCmOnvYegBCBsmkHTWKUXsXQNSZpT");
    double QaCVouLCYSYZ = 566500.1192094191;
    int odmqcdPgRS = 1864024559;
    string DqQDSvROesh = string("jRljGvtf");
    double NBKAgWnrCyYQRBid = -1017085.3886515311;
    string mTLak = string("zKnXAKcamzOJYGuIhoKFknWzEYKBHTqaeafYarGespOJbZcYWcYPgJsYjfRFeDwJBkRmiSrCqwFUDDYeRaYRlrttgUnkLkOiavddTzvHUHAMIFobmqZxcYjLUtVie");
    string JIcXzPqSE = string("vEVVwAkXMblLcMKOWXMyieUl");

    for (int iEKQpHFERqX = 789371513; iEKQpHFERqX > 0; iEKQpHFERqX--) {
        continue;
    }

    return NBKAgWnrCyYQRBid;
}

bool DoqnZDtSBRD::xRzoOPqNttfkm(string LHsALBuNhkSFVI)
{
    bool OGBgr = false;
    int XpJcqfFvtmBJkGJq = -244943944;
    int duYJrMMOCLDAlxYD = -701546361;
    double DMzVvDfwVGM = -239452.7603537903;
    bool PsNQVwNRhDB = false;

    for (int UUxRTOAAQl = 1205191379; UUxRTOAAQl > 0; UUxRTOAAQl--) {
        continue;
    }

    return PsNQVwNRhDB;
}

string DoqnZDtSBRD::MjQfBTMNMzlec(string HHZMTYZrNSJTj, string kDPNqzl)
{
    bool WRTlFxK = true;
    int PPEPHhNDJNnNft = -399491658;
    int cqqhFIVQCH = -330958738;
    double TmiTedOKHEoGJ = 528057.0324493882;
    string wllbdzkRgXOrvCJ = string("fCC");
    double PAMkph = -565949.7769047403;
    int nkcRGXeoLHr = -2122047331;

    for (int vhDDcGxN = 1128269459; vhDDcGxN > 0; vhDDcGxN--) {
        wllbdzkRgXOrvCJ = kDPNqzl;
    }

    if (HHZMTYZrNSJTj == string("YfkuLlVZtmvjjIeIjjCUektGusaGrSIcEnDDWpqObzeetCllWaoSXmsQuifJMBZryHroyTHtGlWOLdnoMmWYFTNLhHSztclHsmDvSPSoDUJezyJlNTijWFaGnekWVsWNjuWiBaXePMVhSbiFxlPcEzUPNiHDtDWOELnqBIBvNzjLzIdiSAvhwLt")) {
        for (int KCfBGk = 332264438; KCfBGk > 0; KCfBGk--) {
            HHZMTYZrNSJTj = kDPNqzl;
        }
    }

    for (int uhyuxxtw = 273953164; uhyuxxtw > 0; uhyuxxtw--) {
        kDPNqzl = wllbdzkRgXOrvCJ;
    }

    for (int OuohjBxM = 659728269; OuohjBxM > 0; OuohjBxM--) {
        wllbdzkRgXOrvCJ = wllbdzkRgXOrvCJ;
    }

    if (cqqhFIVQCH != -330958738) {
        for (int MvbNxRShgl = 330458339; MvbNxRShgl > 0; MvbNxRShgl--) {
            continue;
        }
    }

    for (int oZpxGbIDVJkINZNQ = 1997228644; oZpxGbIDVJkINZNQ > 0; oZpxGbIDVJkINZNQ--) {
        nkcRGXeoLHr -= cqqhFIVQCH;
    }

    return wllbdzkRgXOrvCJ;
}

double DoqnZDtSBRD::vqJbHa(string nNPwzcCvBTXqRDMh)
{
    double BUGDNmxLu = -520105.6341241023;
    bool UzVzsw = false;

    for (int gWmbXabSU = 1556881271; gWmbXabSU > 0; gWmbXabSU--) {
        UzVzsw = UzVzsw;
    }

    if (UzVzsw != false) {
        for (int OAosHnwCWWDNKV = 1962147148; OAosHnwCWWDNKV > 0; OAosHnwCWWDNKV--) {
            BUGDNmxLu += BUGDNmxLu;
            nNPwzcCvBTXqRDMh += nNPwzcCvBTXqRDMh;
            nNPwzcCvBTXqRDMh += nNPwzcCvBTXqRDMh;
            nNPwzcCvBTXqRDMh += nNPwzcCvBTXqRDMh;
            BUGDNmxLu -= BUGDNmxLu;
            UzVzsw = ! UzVzsw;
        }
    }

    if (nNPwzcCvBTXqRDMh <= string("pVlXGHWzzobQVEjJHWDOmfZDctReFjyaFteeJeETAhaSaAlWSAEoLYhItHBVG")) {
        for (int jPxSHRopPFt = 1714392033; jPxSHRopPFt > 0; jPxSHRopPFt--) {
            nNPwzcCvBTXqRDMh += nNPwzcCvBTXqRDMh;
            UzVzsw = ! UzVzsw;
        }
    }

    for (int SqWJXLRSrSfVd = 854565961; SqWJXLRSrSfVd > 0; SqWJXLRSrSfVd--) {
        BUGDNmxLu -= BUGDNmxLu;
        UzVzsw = ! UzVzsw;
        UzVzsw = UzVzsw;
        UzVzsw = UzVzsw;
    }

    return BUGDNmxLu;
}

double DoqnZDtSBRD::RgLtKpKAVZ(string DPcGhMDLbrrUhx, int EPNHCew, bool PUClcJhHvGSGz, int ZpKvXKTkuugWsrl, double qODhdcdeaaWz)
{
    bool ieKcYiVfwoOXb = true;
    double QhbfmoKIPWPxaM = 713079.2043197913;
    bool hHyPBKjrEVYkqX = true;
    int hdwWut = 558316023;
    double HabVAQwnLyr = -261220.799026061;
    double EhIsXUEganFmS = 97514.05442014824;
    string LZCXfesWfJPgzhm = string("QKPKBDIxUffXnifpjkyxvbXYLisCCCyeLmjkoJkznnh");

    return EhIsXUEganFmS;
}

void DoqnZDtSBRD::IRBrNBWhbH(bool DqbfogGeclLonxXV, double lgZOGhQVlYvasGO, bool WfyIYQIehXjMoc)
{
    string kwwyrIDhgzJv = string("jJBidsRpfLAsuCGtjTsTWAdxjBUTYhjEFLcSkRyQcZLqP");
    double dKZoiWNc = -341326.46704394737;
    string etgiRczDeJHiMmY = string("LeUzolJNkaeqyAAxDJeIGxNHQpWujXgnoLUvgXFvBIxZjGPtKDYHFUGUBnfmvuDAltXGunaBvEAtaIBrnSMEKkYRqniEDggozGULEspFEUKLRCTHTVAaqPjhDNzyyafvbQrPbawPMxRJafPWzaeOcBHdYozVJRZQhxPjpZKJoNQIsMGSTMcjUSLmWpAzaH");
    bool tXURwmBSwAUJAHQ = false;

    if (WfyIYQIehXjMoc == true) {
        for (int HOIiRqwNPUrGVEEI = 2113623318; HOIiRqwNPUrGVEEI > 0; HOIiRqwNPUrGVEEI--) {
            continue;
        }
    }
}

void DoqnZDtSBRD::TBxmRNho()
{
    double lqmwvkuB = 220814.7035069142;
    int pPeetAVat = -2036765265;

    for (int UVQJNR = 1089227556; UVQJNR > 0; UVQJNR--) {
        lqmwvkuB -= lqmwvkuB;
    }
}

double DoqnZDtSBRD::ppHGuV(bool bGKqDPJxpBC, int GxyqNitoNpfBbXQ, string eRTkyAETsUWiXm)
{
    int OrImoaVojegjng = 89193923;
    double GRHbhctt = 9114.064211223917;
    int QTPLllBaE = -1398209613;
    bool kAHLeISWhioxq = true;
    int SCWUHFbP = 204759701;
    bool QrTSnGTEWWy = false;
    double nwegPPi = -846979.7074848305;
    string DldQgSZvQB = string("AqfojGouumcifqNfHprKtSPPDmOLQtfDmBjRaKOTIwBxosXJuOZVwmIIUfKYSrMxKRwDaYBhwijdS");
    int VwnBYXfWCeaiLh = 1473847826;
    bool RspDmgLF = false;

    for (int UGRxTrjHusJVqlpS = 860449126; UGRxTrjHusJVqlpS > 0; UGRxTrjHusJVqlpS--) {
        GxyqNitoNpfBbXQ /= GxyqNitoNpfBbXQ;
        QTPLllBaE /= GxyqNitoNpfBbXQ;
    }

    for (int MuBFUZnuZdwJ = 644472071; MuBFUZnuZdwJ > 0; MuBFUZnuZdwJ--) {
        continue;
    }

    if (QTPLllBaE == 1473847826) {
        for (int ANphDxkJsIbrmPR = 1817612641; ANphDxkJsIbrmPR > 0; ANphDxkJsIbrmPR--) {
            GxyqNitoNpfBbXQ -= QTPLllBaE;
            GxyqNitoNpfBbXQ -= OrImoaVojegjng;
            SCWUHFbP += QTPLllBaE;
        }
    }

    for (int tTjQik = 671268183; tTjQik > 0; tTjQik--) {
        continue;
    }

    if (GxyqNitoNpfBbXQ != 1473847826) {
        for (int mmQmQ = 499669919; mmQmQ > 0; mmQmQ--) {
            continue;
        }
    }

    for (int rVlapVcyrK = 189575569; rVlapVcyrK > 0; rVlapVcyrK--) {
        continue;
    }

    for (int GZGfsWcVUYTFv = 441031269; GZGfsWcVUYTFv > 0; GZGfsWcVUYTFv--) {
        continue;
    }

    return nwegPPi;
}

void DoqnZDtSBRD::Svbhf()
{
    string uwrkQocojBHv = string("MAVPloQgG");
    bool RudUt = true;
    double SrLzFwj = -729435.5017591825;
    bool FbAGjE = true;
    string fwhxymiOLiA = string("harHCJoUutYTNBhQXGMUbFIivSWdYwdkExQrrwUAuQFtuxYNcNyNONCKnhKoKuNLCMTPdsFKAxDRJWGvjBRpNfmayVWnevRQbzTsuRhbSpXrBSvAFktKcmbimKhApCpWCWNEcxArenfcuCakKOWHUtwxw");
    int sXUYog = -1847929878;

    for (int uypGIjxrILrODL = 905048665; uypGIjxrILrODL > 0; uypGIjxrILrODL--) {
        FbAGjE = FbAGjE;
        SrLzFwj *= SrLzFwj;
    }

    for (int pLqECXZGY = 409155839; pLqECXZGY > 0; pLqECXZGY--) {
        uwrkQocojBHv += uwrkQocojBHv;
        uwrkQocojBHv = fwhxymiOLiA;
    }

    for (int qtdMSP = 2039149902; qtdMSP > 0; qtdMSP--) {
        RudUt = ! FbAGjE;
        sXUYog = sXUYog;
        fwhxymiOLiA += uwrkQocojBHv;
    }
}

DoqnZDtSBRD::DoqnZDtSBRD()
{
    this->dCmnQEiprjgI(-28241.43785289048, true, false);
    this->ajyUFeOzMaiiPMF(false);
    this->gZXNJMrGUym();
    this->lDUijzdQi(612692.138920565, false, true);
    this->xRzoOPqNttfkm(string("wHpEnWsQrlqbraghHJiJLWGZHZrbSiRnSPBzwssVpZgwONpaAyRHbwuGeicAWn"));
    this->MjQfBTMNMzlec(string("djNSJiJEthDxuplwifIwLyfQckgQInlKRkAlzMDdlYOgDPSAgSJAiRWMpYpQMAKBbMVsZtOhTifAdDgvTCQHvqawEulwxvpHOUWWxYGGqOfFbVw"), string("YfkuLlVZtmvjjIeIjjCUektGusaGrSIcEnDDWpqObzeetCllWaoSXmsQuifJMBZryHroyTHtGlWOLdnoMmWYFTNLhHSztclHsmDvSPSoDUJezyJlNTijWFaGnekWVsWNjuWiBaXePMVhSbiFxlPcEzUPNiHDtDWOELnqBIBvNzjLzIdiSAvhwLt"));
    this->vqJbHa(string("pVlXGHWzzobQVEjJHWDOmfZDctReFjyaFteeJeETAhaSaAlWSAEoLYhItHBVG"));
    this->RgLtKpKAVZ(string("ybvKyEPawNJQKoCNHIhXbIHUDYxCYvqfNzfCKjbcKDoHvhmuwsncqJzTWWTgfzqTmmiIrKmPqlFTJSCIXFZWcgdOVjCgmycVDTwablLOoHTXJFdNR"), -10909989, false, 1793693830, 484863.15132226533);
    this->IRBrNBWhbH(true, -132750.62061565008, false);
    this->TBxmRNho();
    this->ppHGuV(false, -199948917, string("DkvzTXmUVUVInnNNvcfJndNAllcJsrBAfTEjsWpuurqNIPjoXQrJROYuwgKSXfRCLvvXOkKnCkrfEoTdFnGeoePzikMFdLXuEoJqgKfDdXZBcXTnMwhlvNWJOmLiHWsflLxETTJKGAFpwXlepbqSKpCQvuOdVAxnasLvifSumzWfgxUfCLMkAikcxoJTgExufOhELqb"));
    this->Svbhf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MimkPAulIso
{
public:
    bool rXEcayTRytojqaMM;
    bool MSpLjUW;
    int OTsFbM;
    string lAiOa;
    double hgbaSJMZxqjc;
    double hwfmz;

    MimkPAulIso();
    double KtdQbNCe();
    int riIGWumDGtrr(double JEtqqDJtfqDLMhq);
protected:
    string XXNlSWsuyKAVYirF;
    int GBfGWMTJuCxC;

    void GmiJKHIJi(int hUiKOiCjUQjOIb, double AKbRB, int uzADnMhlBfDf);
    bool rTtKMpl();
    int JaWhy(double LcwGxp);
    string IcxThIvNd(bool kIVYPkme, double TpHiMQAjshNgH, double goGskAwjBinvhDmf);
    int dqEULwdJdbSFBD(int yQOCrCJ, string vgHnVJy, int LTlBpL, double trbat);
    void NYbUhX(int HzfVxImOD, bool fwxabsNv, string xwYaAoCryU, int yBlKNGTxTmxHoiQ);
    int ZyUBSZeTlA(int WSPvo, double rvdqABln, string pwHPKo, int kYWRJVOI);
    bool PIIelThfqPKM(double GvrGOphczwHsYUG, bool gjpVJrM);
private:
    string xPTgqenxfo;
    int iKtesFrUcr;
    bool zICYSOkaYT;
    int dgNnDnToPV;

    string zTNflQfGwWqUqkCC(int OswkkzsAocJdnD, string eiYovYT);
    bool nxLtmltdCWlP(bool xKibrFChs);
};

double MimkPAulIso::KtdQbNCe()
{
    string pUcqbi = string("hxZKmBIELnAtPngkwpXJJqxxLVAYGfwQwLozXPINuKpNaBQmDDaUYWeOCcXHCNexqxqScjxpGrlRVXyLNzPSeNWBkSRycOdnazpLLFfRrFEXkcBNaBZItxgzFpaocqgQqrOJvUlRhwhFvvdYRxZhE");
    string DawZnvVlRpCcK = string("hZCgBpurjZhIRjnqOgaBWpeHHjHiAYhqiNwqgtOdLykyPZFTiYBrSXnGdECimZsjmuYaWuPURNoNfdmrPswLMsnhCmZonQAfo");
    bool trWeMECAAIeFPCCm = false;
    double HxlWIbg = -544373.1762816571;
    double kOEAa = 532366.9075836245;
    string IQwXBLkprqVcz = string("UBCmUkLftiWvjeDzSTGtmpwQLeyoDNlpjHTrcjpdUqATgcPCYAATuQvBHHWrxxILdUzzQXlOWwtDVTbynLMYTuOhEhAYnzwsUyZNpFtMxNdTXfmXvgHLCSuwBRNwCtEztyFFiSPydMgXsWSvQTIboJUMIdWMKhsonwdJbUphjURQwcNgnBnIkUMYLgEWwiPbTKJpYLGsMoatTJcRqQOGaNJIKABGWbWHLttmGJpCJBKks");
    bool hMMDPMQpPbolEv = true;
    string UAMqydRna = string("LhSJfDrEzhgkilMQjCloEMRDqVOgIPlsJrXGMOjOrVlCtKQtFsIVAMSipmLxbnvnlVyDbjEeyOYzoIVgrDyMhVF");
    string kjgCNWNcqxeWgP = string("olImRnIJVvUlOcAmoaaFcMDSAgQAhsgNNTNYihcLVPNaWrySbMcNZbAsqjEyVhrwyScXLYizqdJswcrLttfxJOPwgaxSnCWcbNgVmaixawftBtOOROAhIkrCWXBkOgRiBwJXjekgIJGCGKhPivKjkGLzfWSbskQxACmYxflyGArvQsabxMvwhvxARnuuSlxbUStXEivwN");
    int OjpcaW = -1732936289;

    for (int PEjuqNkItOdLK = 1195945259; PEjuqNkItOdLK > 0; PEjuqNkItOdLK--) {
        kjgCNWNcqxeWgP = pUcqbi;
    }

    if (IQwXBLkprqVcz > string("hxZKmBIELnAtPngkwpXJJqxxLVAYGfwQwLozXPINuKpNaBQmDDaUYWeOCcXHCNexqxqScjxpGrlRVXyLNzPSeNWBkSRycOdnazpLLFfRrFEXkcBNaBZItxgzFpaocqgQqrOJvUlRhwhFvvdYRxZhE")) {
        for (int lzoLhYSC = 831525976; lzoLhYSC > 0; lzoLhYSC--) {
            kjgCNWNcqxeWgP = pUcqbi;
        }
    }

    if (UAMqydRna < string("hZCgBpurjZhIRjnqOgaBWpeHHjHiAYhqiNwqgtOdLykyPZFTiYBrSXnGdECimZsjmuYaWuPURNoNfdmrPswLMsnhCmZonQAfo")) {
        for (int JvltUSHBqHiik = 1212928689; JvltUSHBqHiik > 0; JvltUSHBqHiik--) {
            DawZnvVlRpCcK = DawZnvVlRpCcK;
            hMMDPMQpPbolEv = hMMDPMQpPbolEv;
        }
    }

    for (int rkYLTUPpQp = 634856034; rkYLTUPpQp > 0; rkYLTUPpQp--) {
        trWeMECAAIeFPCCm = hMMDPMQpPbolEv;
        UAMqydRna = IQwXBLkprqVcz;
    }

    for (int HgxOIZFdl = 1415524276; HgxOIZFdl > 0; HgxOIZFdl--) {
        continue;
    }

    return kOEAa;
}

int MimkPAulIso::riIGWumDGtrr(double JEtqqDJtfqDLMhq)
{
    int YSwNwMcKddkt = 693095136;
    bool ewyfShQSXMfD = false;

    if (JEtqqDJtfqDLMhq == 912975.8077491185) {
        for (int tiZvzmntOtN = 1753672579; tiZvzmntOtN > 0; tiZvzmntOtN--) {
            ewyfShQSXMfD = ! ewyfShQSXMfD;
        }
    }

    if (JEtqqDJtfqDLMhq <= 912975.8077491185) {
        for (int AKtjiDQyV = 1943308989; AKtjiDQyV > 0; AKtjiDQyV--) {
            YSwNwMcKddkt -= YSwNwMcKddkt;
            YSwNwMcKddkt = YSwNwMcKddkt;
            ewyfShQSXMfD = ! ewyfShQSXMfD;
            ewyfShQSXMfD = ewyfShQSXMfD;
        }
    }

    for (int thOnVLfFVqX = 2100489546; thOnVLfFVqX > 0; thOnVLfFVqX--) {
        YSwNwMcKddkt *= YSwNwMcKddkt;
    }

    for (int xFIaBRWk = 329858201; xFIaBRWk > 0; xFIaBRWk--) {
        continue;
    }

    return YSwNwMcKddkt;
}

void MimkPAulIso::GmiJKHIJi(int hUiKOiCjUQjOIb, double AKbRB, int uzADnMhlBfDf)
{
    int gMAsFAZBTi = -381536192;
    int UnYEAIijAxmuD = 1513311858;
    bool JvQLvlPsRGohY = true;
}

bool MimkPAulIso::rTtKMpl()
{
    string EWGEzeg = string("sMlFQNUZzBuxOXCvHwGWfdOkviLgOZCwrtvdPbXnUsgellyskzcqBBzmAlhYmcZNWzOmmsGXMDsZAXKWLmKaNrjnJswgjOqBntrzCaYDemszIxZrqqYcnBjUwOJPpEkXHWHL");
    int grjFg = -1442823987;
    bool lXwEGZphjLUElnC = false;
    string BnGumTQpHj = string("AmPyRYqjyjFUbCNwoAqHAyDJNcQTmTaMiWhrCKjIrGnsrbxwecdxHHAgbdswCLPXisVZwXEgyJlJCEWsoWZlNnuABks");
    string jWOZvhMTLJFKjSFk = string("jQLxXuKJKeUitCLMsIrLaLUTxTMCwuNPsEcLHCSHvchMvhFVjzViRgZKINOoODNUeQOurIjXGmAMXteeBSkyyCuxRaUrtWeHbAz");
    int SKPprTEJoHQiq = -1970394472;
    int hzyifGwvYMldGV = -1527505070;
    double JWecxjtExruLbDiR = 177476.72893509266;
    bool jtGnt = true;

    if (jWOZvhMTLJFKjSFk == string("AmPyRYqjyjFUbCNwoAqHAyDJNcQTmTaMiWhrCKjIrGnsrbxwecdxHHAgbdswCLPXisVZwXEgyJlJCEWsoWZlNnuABks")) {
        for (int FgaxyvbpWaDS = 540684743; FgaxyvbpWaDS > 0; FgaxyvbpWaDS--) {
            EWGEzeg += jWOZvhMTLJFKjSFk;
            BnGumTQpHj = BnGumTQpHj;
        }
    }

    return jtGnt;
}

int MimkPAulIso::JaWhy(double LcwGxp)
{
    int uEpchCDjxnb = 986603995;
    int NsufVUtakfPeBmQ = 793958021;
    bool ktvvLlKJSjWuK = true;
    int LdmrrMq = 885148863;
    int ZRHVScuanvvDNbl = 452716545;
    bool sZcjGo = true;
    string SSVcnDhFjaPak = string("mnbeWuHoChXMCbndyGXoREOyROKBGmpWNrKIiKwAUrlkLEckYDjsMndgRdaxtrBOzjJYvDYTWQrtzvqlTZaSBofikUNvDFGNxfrhuKYXcjdmgEOVoFnsXIqmFoBFOTeWLgFhaLmsOPwFlaBzdMDHflCyHcEnbdtOTfzjxJRSGQPxoHCqxDRYoHbJidzOtvJrmm");
    double NQejFLNwPgCJz = 255015.6497109175;
    double YqrUFrgAdvM = 112507.95035431266;

    for (int JKIdsIyIKXphkm = 212143795; JKIdsIyIKXphkm > 0; JKIdsIyIKXphkm--) {
        ktvvLlKJSjWuK = ktvvLlKJSjWuK;
        NQejFLNwPgCJz += NQejFLNwPgCJz;
        NQejFLNwPgCJz /= NQejFLNwPgCJz;
    }

    for (int wEJZAuDVo = 1997096243; wEJZAuDVo > 0; wEJZAuDVo--) {
        uEpchCDjxnb = LdmrrMq;
        ZRHVScuanvvDNbl /= NsufVUtakfPeBmQ;
        uEpchCDjxnb = ZRHVScuanvvDNbl;
        LcwGxp = LcwGxp;
    }

    for (int XaBgRUuOm = 1116070735; XaBgRUuOm > 0; XaBgRUuOm--) {
        LdmrrMq *= ZRHVScuanvvDNbl;
        uEpchCDjxnb += LdmrrMq;
        uEpchCDjxnb *= NsufVUtakfPeBmQ;
    }

    return ZRHVScuanvvDNbl;
}

string MimkPAulIso::IcxThIvNd(bool kIVYPkme, double TpHiMQAjshNgH, double goGskAwjBinvhDmf)
{
    bool LwdXh = false;
    int YAhzNwYQH = 1547942180;
    int jFyPkWAvBVFx = 1329234419;
    bool nyusFxsftJ = true;
    string YtVLiezqFsFX = string("ZuKwkpBcVPQKNzNgJyCZvwqbVjRBwqiQvAZlipBtLMLOzuYVVlJkWtEkcJzVHDtIcSPgbPGoDsLoxfwyrqfvlXjPqbTcFIhmVmBavpxNKVPknjCaUTvPnKkxwIuIGAByvFfSmCxZOnbOpplYBWMDeHYGDkGMrqRZOrCic");

    for (int YHwEjLn = 1144348538; YHwEjLn > 0; YHwEjLn--) {
        LwdXh = nyusFxsftJ;
    }

    for (int LjbfN = 1661561544; LjbfN > 0; LjbfN--) {
        kIVYPkme = ! kIVYPkme;
        goGskAwjBinvhDmf -= TpHiMQAjshNgH;
        nyusFxsftJ = ! nyusFxsftJ;
        YtVLiezqFsFX = YtVLiezqFsFX;
    }

    return YtVLiezqFsFX;
}

int MimkPAulIso::dqEULwdJdbSFBD(int yQOCrCJ, string vgHnVJy, int LTlBpL, double trbat)
{
    int xejtL = -1032925194;
    int zdMaFsuDHKe = 1178090014;
    double dDHGnn = -878104.2338267843;
    int RpRRyWhLYX = 134664504;
    bool eTihSEPqzD = true;
    string STYkV = string("TABhDXuGEysYtAoDMEklmvemiqrTGKtwicwqJvtrDHudsCfawARmSAHjKKWxtUTuHagaoCFVJHgyzAshbRUdazBndImFmzl");
    int GnVQqgy = -549418619;

    if (yQOCrCJ > 569449668) {
        for (int rIuKAcdO = 1140980491; rIuKAcdO > 0; rIuKAcdO--) {
            vgHnVJy += vgHnVJy;
            zdMaFsuDHKe -= RpRRyWhLYX;
        }
    }

    return GnVQqgy;
}

void MimkPAulIso::NYbUhX(int HzfVxImOD, bool fwxabsNv, string xwYaAoCryU, int yBlKNGTxTmxHoiQ)
{
    string rMDhHPrkuwBIwhO = string("zqkydJkcIbTUYBBMNmwqYRXIsPeWbrpUyMQuwoguaKFgbjkdtqmXvAlsLzWBGBrzRZvgBuiDCnFTnG");
    int mENTPRil = -2023409138;
    string ixZuRPqQiyFpqiaM = string("HKYdAgnFxLFnhjNseMvZaltWfMYETEfxrBgWzamBzyivJhvSGTenMzTAVhQJMGurzZuQvpsZdCmKWQfpdcxmpUkxfjxNeXWfuBnGyQXnqcdnJyoNwsdjYzYx");
    bool KgQmv = false;
    int awOlyquFotKZL = 1192845290;
    int gQFSB = -1548205648;
    bool niGtRzRFIlGjrsoE = false;
    double iITQWpatxi = 587359.6799937523;

    if (gQFSB < -1548205648) {
        for (int DJULbZaMEf = 5334073; DJULbZaMEf > 0; DJULbZaMEf--) {
            rMDhHPrkuwBIwhO = xwYaAoCryU;
        }
    }
}

int MimkPAulIso::ZyUBSZeTlA(int WSPvo, double rvdqABln, string pwHPKo, int kYWRJVOI)
{
    bool sgvbvqncLeiWS = false;
    double YOrIDcJblXgmZ = 216740.13600498642;
    string BaIXFMq = string("uACJBMWgTFIEVMyqnuEkwulBLPVFLeTzarFxKbKJaOgAimfkAJgcHjoDKyoVSpBKnGuqRWamyybYTBDLUIagQHtFtIDxyEKotZlXEzfMnJXHbbeBNqXcvFqKowbBhhbMEycOsOHhMcaYIVejhOITHZflMu");

    if (WSPvo != 501653328) {
        for (int wqriU = 1724806536; wqriU > 0; wqriU--) {
            continue;
        }
    }

    return kYWRJVOI;
}

bool MimkPAulIso::PIIelThfqPKM(double GvrGOphczwHsYUG, bool gjpVJrM)
{
    int BIbJQVnitDSgvGx = -1276633998;
    bool lnYxIUEIJuX = false;
    double BRQaX = 844321.445815979;
    double frXlsGHZAsCuAN = -670032.2034699763;
    string lPmHphMUWUmfwgW = string("TSLlSHgXJcScFrbh");
    int RkbJcygfaGfcsQU = 1045922865;

    if (lPmHphMUWUmfwgW <= string("TSLlSHgXJcScFrbh")) {
        for (int oCJKbYCxqKqiOBa = 403269876; oCJKbYCxqKqiOBa > 0; oCJKbYCxqKqiOBa--) {
            BIbJQVnitDSgvGx /= RkbJcygfaGfcsQU;
        }
    }

    if (frXlsGHZAsCuAN >= 844321.445815979) {
        for (int EpMMFxwOolYg = 66387496; EpMMFxwOolYg > 0; EpMMFxwOolYg--) {
            lnYxIUEIJuX = ! lnYxIUEIJuX;
            GvrGOphczwHsYUG = GvrGOphczwHsYUG;
        }
    }

    return lnYxIUEIJuX;
}

string MimkPAulIso::zTNflQfGwWqUqkCC(int OswkkzsAocJdnD, string eiYovYT)
{
    double iaJDpbd = 537965.2983801147;
    string tAGYIMMwn = string("dnFwELxrwRXoyASkTUUSHUTqUghsOcUGvuwxEJjdCkQgRyVGtyhijgClJpIDKdfGiPlMqKMtfIwSoKbbRnCBFQjcGQiAGJwXQQvPPPEnHuOGzEBDGoHhFZpuiVleQlfCsfZqAtRlMakmQUBqvwGOpPlknHZJAYRXviIcZwSdAaZpzfSDgGGtwHCpsUuZflRamMgBGzdtgQJKDhSQYvmqxmmaqbRulWGAhSAElSAaRqaOpLPScR");
    string jyzGdGIBSvKu = string("JVwbhdJMxYVKFuRkrvZVkDwxlUhxriYWjuEjfMYXwLwslmnUfAufeCmprQLAjdoSSaJYDPmvtBpYmyhUhKxbCrGNlnrTUmPYyhuhPXrnkAdnkORUKfZkzHPrgdClOZmuwGnC");
    int mSyxDVADyedgSb = 626130239;
    int izbkFKAZQ = -1266294819;
    double oacTCJHmVNpR = -1000613.5397963632;
    double xHRsVkSlnptSTBgj = 837819.3316450145;
    int CqzOVcMkrOGrmnke = -1011104059;
    string hGNmFTYvYi = string("qxOXgUBbbFUmetVIILeNaWGrZvbPIkfjNnPDOHvYvftwlUNUnDQXSeypJtgJSsVgXQyivAULcjfJvvFHgGNojNessARFaTpcnMykdfgFkHFOZzomJYhD");

    if (OswkkzsAocJdnD == 626130239) {
        for (int mcprdTSgBW = 1786425178; mcprdTSgBW > 0; mcprdTSgBW--) {
            jyzGdGIBSvKu += tAGYIMMwn;
            jyzGdGIBSvKu = hGNmFTYvYi;
            iaJDpbd /= oacTCJHmVNpR;
            hGNmFTYvYi += tAGYIMMwn;
            oacTCJHmVNpR -= oacTCJHmVNpR;
        }
    }

    for (int kdHLZ = 979069977; kdHLZ > 0; kdHLZ--) {
        izbkFKAZQ /= OswkkzsAocJdnD;
    }

    if (tAGYIMMwn >= string("qxOXgUBbbFUmetVIILeNaWGrZvbPIkfjNnPDOHvYvftwlUNUnDQXSeypJtgJSsVgXQyivAULcjfJvvFHgGNojNessARFaTpcnMykdfgFkHFOZzomJYhD")) {
        for (int dLkfOLBZYucm = 1916323659; dLkfOLBZYucm > 0; dLkfOLBZYucm--) {
            eiYovYT = tAGYIMMwn;
        }
    }

    return hGNmFTYvYi;
}

bool MimkPAulIso::nxLtmltdCWlP(bool xKibrFChs)
{
    string FCoEJyI = string("qnmwCsCVzYToSAIbCraCkZoKXNTCGtjsidWrEjnLrvjzaMQtLStXHkcZyjcwWULtQBAHJYNcEDLMHxFJXWfyLbjelWwgxJrmSscvkZAmPMGQkzIXrDuRmgWWtvVKRNIAnTxzVSbqntuTImShmMBwZLVFrhICSpPOSOnqtEsoDybNKohttRCuajkfPJdOFcurUrWoxZqqTefpdTtUjgJDIvHDtlSnWIEO");
    double VjOlaIQveVlTYp = -897928.9929217898;
    int itzLXhIHqP = 981068190;

    if (xKibrFChs != false) {
        for (int kmHuutz = 127619271; kmHuutz > 0; kmHuutz--) {
            xKibrFChs = ! xKibrFChs;
        }
    }

    for (int KJQnYStflu = 456744530; KJQnYStflu > 0; KJQnYStflu--) {
        VjOlaIQveVlTYp += VjOlaIQveVlTYp;
    }

    for (int vBIxMMMrLWrvjAVq = 1440695667; vBIxMMMrLWrvjAVq > 0; vBIxMMMrLWrvjAVq--) {
        itzLXhIHqP += itzLXhIHqP;
    }

    for (int NuoUb = 514790921; NuoUb > 0; NuoUb--) {
        itzLXhIHqP += itzLXhIHqP;
        xKibrFChs = xKibrFChs;
    }

    for (int OhYvw = 1546138272; OhYvw > 0; OhYvw--) {
        continue;
    }

    return xKibrFChs;
}

MimkPAulIso::MimkPAulIso()
{
    this->KtdQbNCe();
    this->riIGWumDGtrr(912975.8077491185);
    this->GmiJKHIJi(-949957216, -921436.2429454091, -1730952593);
    this->rTtKMpl();
    this->JaWhy(-535523.5504681038);
    this->IcxThIvNd(false, 262926.6686258144, 617622.5462071098);
    this->dqEULwdJdbSFBD(905119095, string("vSaLuZhyriPTomUcBWZJOTBabTCqjTiWzWTIDQOWdFFlysRRKgpHrtLuMsumdekQcwOQgqAjCPMmvJuqyjYueahoXfYPNimAEiuOjRlfKPWUWPoKwqTKbCTXWKesBmJAGZxmoOJYyYxMbY"), 569449668, 735167.111199501);
    this->NYbUhX(-31278732, false, string("yMPOyFmFRiluosDuYbKnRWwJcnIdEfDacxZBeQLZbxkiAPlkpKqHHcqucLJVCZSxAEHzexYLizwNsTRNFHEaYtJanaHZhvphhINftVhhpuYuncbOIgGuXmpkYyZZJpbacGcrPBRGYEusofCDcWgINeqDSrqtYlUYWLxyExEaStOmZCpbvHdPafMAcGApJOLJEzZxp"), 2060514480);
    this->ZyUBSZeTlA(501653328, -826458.7604538067, string("iPevPlFIuQPVrSjoROBvWEzchPBhvrLreUXbhNLHeufAVFeMHzfMvyMMOgnRuCaStTFCLsOKdWAeiVXGqouuBqwjEnNloyoOttsUFRubSUHdRzPylMCSFGeoCJDBjsbqJTCuWYSzHEldAxdmPzTEhajfhQFjxDlrzdHfZrLzAFLtilxRYYZtEkuGcYTSBAJmoAZRTIQWWbaZlhnGpqBPKFrcUnUitSFulqbMN"), -312241065);
    this->PIIelThfqPKM(-151294.4916035624, true);
    this->zTNflQfGwWqUqkCC(-1612094045, string("PiiOoFkXeUtjiCDKjJAYvQcAmhycVwrJChHQtVbgYVFBNYZtlbEptQVsIiPkKcrsogyglXTCZsLRtesdCkNrdikvuSxPudnGgvKihZOBnTkoUCOasBErbOhmxcFyTcQNVAltsNuxdMqcdfitAoIXcZMZJeycHqejpt"));
    this->nxLtmltdCWlP(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aqbBTDuoYGIu
{
public:
    string gXNpr;
    string KDDSEuvikSFoD;
    int ykDTfCzHKjiafg;
    double lkpKmZhq;
    double BAOCVMpDOIkUyAPD;

    aqbBTDuoYGIu();
    void yZEAAWdIdCdl(double VkfRUkBaXmjGu, string FtvdOPAkhQp);
    int vNvwLrBroaBMo(int yqvsiLjs, bool ToZVcVLeAno, string qxOmynui, int TFrYGCbCurD);
    void chVTtdKNgpcxm(bool wMWaaGW, string ABrBqgxfUZTm);
    bool HeZPEfdVLQgYwe(int qfGrYhBkAANMBcCI, bool WJKwVuKEHLnHkR, int AurhD);
protected:
    string RixRFJvgCxIjp;
    double tLtRelUyQTec;
    bool RqOdzwYsnu;
    int Yxlcq;
    double oakCTZVuKzNOETA;
    bool UaLwYwvmK;

    int aXrWe(string kQcgEw, double aPGXISnaDXOL, double tyVvpuyGeGoKJlgk, int tZOlKchEmAXKZXT, bool pJWWhXPnads);
    string UnSfvadzXOUTYEOU(double cCJsiylCBlN, int ikyYgutxplo);
    bool XuxousaJeitqaqf();
    bool kvnDARsvCfnM(bool lQmZKSrrRluzx, bool oJaDBXgQPiRG);
    void EUHNUKJncScsigDx(double buiwLXDNM, string AdKKnfjMnJZ, double tffAHk, int QFyInnh, string tmWbiXH);
    bool UGHvol(string AaHFWmpUe, int ksMBLZjDcrLQOfET, int sDkKNEpexXnxOY);
    int WgaRM(bool DmemYheeMxOTupcD, string pkyLuPYfoCMS, string sIdnNNbABplVYd, int DkmnsbctpHHxZ, int zZyWzg);
    string WiYoujUTVokZnd(int ohlle, bool Gqzybrila, string oCrVZiSZkIgcpFhR, bool aRunNVf);
private:
    int uSOjcZuI;
    double YSnDADYYGOnDBVN;

    void HhwXRMYytrkBqBK(double uqPln, double brEQV, double NlKfFjouye, bool oDkCnor);
    string rAZUiNOxZNKrjf(double KjNZBhvep);
    string PnJvXvdDLKOBFTSd(int mQWvthNo);
    bool MNOWvYAyxcZSvi(bool LGVDZsxkMY);
    string ixCRhuhirYjThS(int nVaGcHCwlDdxR, int vtFpFmpGBL, int ReZJAWuntzTAXxI, bool mpzNYWynaUCGRmqg);
};

void aqbBTDuoYGIu::yZEAAWdIdCdl(double VkfRUkBaXmjGu, string FtvdOPAkhQp)
{
    string zfseReanWAVelcK = string("lcoqccTsQuZsufcvQBjxDSZzFqnpW");
    string LESHGbrxbGXusC = string("HvIjbCcAXQGzPWGvvUhwjPBASbACJYnwtnyAMYymormbuVqgmbMmuCnQrKHDDjDenCNMRXqyAOaICTcFCZsTPKoGGhEjETRXrzqFuDkMFAfBjQgqCkUfAgSpikLijYZRgxuBPRQIGAIfdFRolBbq");

    if (zfseReanWAVelcK != string("HvIjbCcAXQGzPWGvvUhwjPBASbACJYnwtnyAMYymormbuVqgmbMmuCnQrKHDDjDenCNMRXqyAOaICTcFCZsTPKoGGhEjETRXrzqFuDkMFAfBjQgqCkUfAgSpikLijYZRgxuBPRQIGAIfdFRolBbq")) {
        for (int IUtXyUYOpa = 410100559; IUtXyUYOpa > 0; IUtXyUYOpa--) {
            LESHGbrxbGXusC += zfseReanWAVelcK;
            zfseReanWAVelcK = FtvdOPAkhQp;
            VkfRUkBaXmjGu += VkfRUkBaXmjGu;
            FtvdOPAkhQp = zfseReanWAVelcK;
            VkfRUkBaXmjGu /= VkfRUkBaXmjGu;
        }
    }

    if (FtvdOPAkhQp < string("lcoqccTsQuZsufcvQBjxDSZzFqnpW")) {
        for (int VewCAdHZkOxz = 755118470; VewCAdHZkOxz > 0; VewCAdHZkOxz--) {
            LESHGbrxbGXusC = zfseReanWAVelcK;
            FtvdOPAkhQp = FtvdOPAkhQp;
        }
    }

    if (FtvdOPAkhQp > string("HvIjbCcAXQGzPWGvvUhwjPBASbACJYnwtnyAMYymormbuVqgmbMmuCnQrKHDDjDenCNMRXqyAOaICTcFCZsTPKoGGhEjETRXrzqFuDkMFAfBjQgqCkUfAgSpikLijYZRgxuBPRQIGAIfdFRolBbq")) {
        for (int ogcQzxDmfDyT = 568483149; ogcQzxDmfDyT > 0; ogcQzxDmfDyT--) {
            FtvdOPAkhQp = zfseReanWAVelcK;
            FtvdOPAkhQp += FtvdOPAkhQp;
            FtvdOPAkhQp = FtvdOPAkhQp;
            zfseReanWAVelcK += zfseReanWAVelcK;
            FtvdOPAkhQp = zfseReanWAVelcK;
        }
    }

    for (int JKhzDeD = 927440595; JKhzDeD > 0; JKhzDeD--) {
        continue;
    }
}

int aqbBTDuoYGIu::vNvwLrBroaBMo(int yqvsiLjs, bool ToZVcVLeAno, string qxOmynui, int TFrYGCbCurD)
{
    bool IqqFI = true;
    bool VPSADdGgAAqKwK = true;
    double iadOUfmE = -829848.7881974708;
    int RnBVd = -501735031;
    string FoRgfuBYnw = string("hAGVFUoXFJenVMpQoTSoEJlBbalZxpnbDnTyDVfAqNkjWwzFljAgGHJlaepiKaKiOFPOFqUzxhkzNmEPapeEwgwIEYHLxAVHXcCkUOYmyYSFEGkRznSDURNxaVzRHXNZTABKMagMPCKIWXWSdTIKcFahSvsGkFyHfDYrSrjEYCgBRfXniZHiwqSMgekEZFeqgHKWp");
    int pgTfSEbd = 1428298605;

    if (TFrYGCbCurD <= 260633925) {
        for (int fPVwvbX = 356658977; fPVwvbX > 0; fPVwvbX--) {
            RnBVd = yqvsiLjs;
            pgTfSEbd = TFrYGCbCurD;
        }
    }

    if (IqqFI != true) {
        for (int VkOfWldDpifxC = 2120733554; VkOfWldDpifxC > 0; VkOfWldDpifxC--) {
            yqvsiLjs *= TFrYGCbCurD;
            ToZVcVLeAno = IqqFI;
            pgTfSEbd += TFrYGCbCurD;
        }
    }

    for (int zJenCRbbEXscfgAE = 1306605744; zJenCRbbEXscfgAE > 0; zJenCRbbEXscfgAE--) {
        continue;
    }

    for (int KrgbDqj = 43054102; KrgbDqj > 0; KrgbDqj--) {
        continue;
    }

    for (int oonjyjn = 857536334; oonjyjn > 0; oonjyjn--) {
        pgTfSEbd /= pgTfSEbd;
    }

    return pgTfSEbd;
}

void aqbBTDuoYGIu::chVTtdKNgpcxm(bool wMWaaGW, string ABrBqgxfUZTm)
{
    string UIXrj = string("QRQgnkVPcPXVaEbtfURyITfpWtrdqFqOcCLEDPiaLzJbQtJAAuoYjrvghQmLkMfSLMjzYXd");
    double jGqOKcCuIskyQ = 769320.3421096726;
    double ZhHUPs = 558367.7739336347;
    bool OcjIAhmjvrKiKio = true;

    for (int xIFnCOKmzQOdhn = 1822729680; xIFnCOKmzQOdhn > 0; xIFnCOKmzQOdhn--) {
        wMWaaGW = ! OcjIAhmjvrKiKio;
        wMWaaGW = OcjIAhmjvrKiKio;
        wMWaaGW = ! OcjIAhmjvrKiKio;
    }

    if (jGqOKcCuIskyQ >= 558367.7739336347) {
        for (int wpnto = 1505050501; wpnto > 0; wpnto--) {
            wMWaaGW = wMWaaGW;
        }
    }

    for (int CGjfkXmnLHdT = 1049301082; CGjfkXmnLHdT > 0; CGjfkXmnLHdT--) {
        OcjIAhmjvrKiKio = ! wMWaaGW;
        jGqOKcCuIskyQ -= jGqOKcCuIskyQ;
        jGqOKcCuIskyQ += ZhHUPs;
    }
}

bool aqbBTDuoYGIu::HeZPEfdVLQgYwe(int qfGrYhBkAANMBcCI, bool WJKwVuKEHLnHkR, int AurhD)
{
    double DToMNQ = -176661.2739573458;

    if (qfGrYhBkAANMBcCI >= -1570048824) {
        for (int fqVHZuTtiKz = 1660451082; fqVHZuTtiKz > 0; fqVHZuTtiKz--) {
            continue;
        }
    }

    if (qfGrYhBkAANMBcCI < -1570048824) {
        for (int NTzjPMS = 689676806; NTzjPMS > 0; NTzjPMS--) {
            continue;
        }
    }

    if (AurhD != 757950848) {
        for (int dxIzyYjM = 1936738160; dxIzyYjM > 0; dxIzyYjM--) {
            qfGrYhBkAANMBcCI -= AurhD;
        }
    }

    if (AurhD >= -1570048824) {
        for (int TbNFwP = 137867344; TbNFwP > 0; TbNFwP--) {
            WJKwVuKEHLnHkR = ! WJKwVuKEHLnHkR;
            DToMNQ /= DToMNQ;
            AurhD /= qfGrYhBkAANMBcCI;
        }
    }

    for (int cujub = 1858750591; cujub > 0; cujub--) {
        AurhD += AurhD;
    }

    for (int CgCGlVTwDDslM = 1814401219; CgCGlVTwDDslM > 0; CgCGlVTwDDslM--) {
        qfGrYhBkAANMBcCI = qfGrYhBkAANMBcCI;
    }

    if (AurhD > -1570048824) {
        for (int nUpASnZXEKXabv = 1762823154; nUpASnZXEKXabv > 0; nUpASnZXEKXabv--) {
            qfGrYhBkAANMBcCI += qfGrYhBkAANMBcCI;
            AurhD *= qfGrYhBkAANMBcCI;
            WJKwVuKEHLnHkR = ! WJKwVuKEHLnHkR;
            WJKwVuKEHLnHkR = ! WJKwVuKEHLnHkR;
            DToMNQ = DToMNQ;
        }
    }

    for (int XofdsaWhfRoCUJ = 467717357; XofdsaWhfRoCUJ > 0; XofdsaWhfRoCUJ--) {
        continue;
    }

    for (int SrIEGxk = 362213873; SrIEGxk > 0; SrIEGxk--) {
        WJKwVuKEHLnHkR = WJKwVuKEHLnHkR;
    }

    return WJKwVuKEHLnHkR;
}

int aqbBTDuoYGIu::aXrWe(string kQcgEw, double aPGXISnaDXOL, double tyVvpuyGeGoKJlgk, int tZOlKchEmAXKZXT, bool pJWWhXPnads)
{
    bool nPuzf = true;
    string IvjwiHd = string("xYtzkKwEbYDXiKVlARxLSMLBawrXwakOjhUZKuoJWSkmkbgJqnFtrTqdZMShHxgHyQoduUgjZHKYkyQVJtDMWHkWRAywFbvNhzvftKngAhpBlVjwwXfYwNPdsPEcdIJSClvUcDEuLcSCtqOFlRjQZgENwIhKHfIzSeSXYzoyjuGBnuCEakzJNHFsTFpOBSEXSrOAHRWDsUksounRWIPpPwIjPBAdURNHsXJHhIsFQyctigGPHdURzSFkdruFu");
    double IIlibVdHv = 858388.3626264719;
    bool AInaoofX = false;
    double DOefVx = -803840.0278494473;
    string QmkchsVZQpfKwfUc = string("EytJPdnNqBHqXHhsJdwMYYeXbDepczdoBsTcTHqHEOoHsyEKUNvDBDiAlMgnRAdrPBfxbfHWVMGNKWp");
    bool eUYSiC = true;
    double hXxiHY = -339322.1067758338;

    if (IvjwiHd < string("EytJPdnNqBHqXHhsJdwMYYeXbDepczdoBsTcTHqHEOoHsyEKUNvDBDiAlMgnRAdrPBfxbfHWVMGNKWp")) {
        for (int dapMBWD = 1881043793; dapMBWD > 0; dapMBWD--) {
            continue;
        }
    }

    for (int sufWmIDSJnajYh = 1199075042; sufWmIDSJnajYh > 0; sufWmIDSJnajYh--) {
        nPuzf = AInaoofX;
    }

    for (int dxdDQggUgpDiciJ = 982932446; dxdDQggUgpDiciJ > 0; dxdDQggUgpDiciJ--) {
        hXxiHY /= aPGXISnaDXOL;
    }

    if (hXxiHY <= 858388.3626264719) {
        for (int pEQDhSoiB = 739836181; pEQDhSoiB > 0; pEQDhSoiB--) {
            AInaoofX = pJWWhXPnads;
            aPGXISnaDXOL = aPGXISnaDXOL;
            nPuzf = nPuzf;
        }
    }

    return tZOlKchEmAXKZXT;
}

string aqbBTDuoYGIu::UnSfvadzXOUTYEOU(double cCJsiylCBlN, int ikyYgutxplo)
{
    string WvxGN = string("BUz");
    bool eVIicEwJQUmBwu = false;
    string CQJOgelfUMN = string("vZJVaMlidsYIkABXKkzVpmXLRlBYbzyWfaqwhcrOZjPCMPWxkALNHlTVymsyJLkgZLOBEnNLUwVJvZGfFTFNuWtRhvdG");

    for (int CxrDFgLWVLDI = 2079552037; CxrDFgLWVLDI > 0; CxrDFgLWVLDI--) {
        ikyYgutxplo *= ikyYgutxplo;
    }

    for (int BlNtxDtmtxGl = 806199327; BlNtxDtmtxGl > 0; BlNtxDtmtxGl--) {
        WvxGN = WvxGN;
    }

    if (CQJOgelfUMN == string("BUz")) {
        for (int VmWftvQY = 911316403; VmWftvQY > 0; VmWftvQY--) {
            WvxGN += CQJOgelfUMN;
            cCJsiylCBlN = cCJsiylCBlN;
        }
    }

    for (int uWopZz = 265063404; uWopZz > 0; uWopZz--) {
        continue;
    }

    for (int PdHQYrT = 231627060; PdHQYrT > 0; PdHQYrT--) {
        eVIicEwJQUmBwu = eVIicEwJQUmBwu;
    }

    for (int JIhjkUaic = 1092926742; JIhjkUaic > 0; JIhjkUaic--) {
        continue;
    }

    return CQJOgelfUMN;
}

bool aqbBTDuoYGIu::XuxousaJeitqaqf()
{
    int tSSZnPcBHnS = 577941645;
    bool MVBWh = false;
    int pbvfoeNYIH = 895983649;
    bool GLXrOCMFaxsgyER = true;
    int KpsqX = -30058104;
    string AfRHvEGDkpPW = string("eWNbVoSxgVFmJBbJPuIqeGjv");
    bool EObOreAu = false;

    if (MVBWh == false) {
        for (int QupYjpOzKIlVTVPH = 1149664065; QupYjpOzKIlVTVPH > 0; QupYjpOzKIlVTVPH--) {
            pbvfoeNYIH += pbvfoeNYIH;
            EObOreAu = ! MVBWh;
            KpsqX /= pbvfoeNYIH;
        }
    }

    if (EObOreAu != false) {
        for (int AlFPPyHcMJsB = 401400534; AlFPPyHcMJsB > 0; AlFPPyHcMJsB--) {
            KpsqX /= tSSZnPcBHnS;
        }
    }

    for (int aBJrGjdPDk = 1450701932; aBJrGjdPDk > 0; aBJrGjdPDk--) {
        KpsqX -= KpsqX;
        GLXrOCMFaxsgyER = ! GLXrOCMFaxsgyER;
    }

    return EObOreAu;
}

bool aqbBTDuoYGIu::kvnDARsvCfnM(bool lQmZKSrrRluzx, bool oJaDBXgQPiRG)
{
    int DpAcIckQTeWEgIkJ = 1821314359;
    string wrlLfCv = string("rLurtZJKTqltmGuLpDQnznvKiukdjWJhFUExghLboVvpRneanVagtMiShwOGPDFqxoeVLtCWXCkHwspnpTyMJwEDyJPvblAScLPAEfkwbZavulXVTyKWGEIKxgHcEYgMGgZVMaFTyTavuwFAurnDCKQGjOFbNkksuxEpTdgocpnhDySJkUEyvtlEnXtUjRQaQxUufcTyCNoiQLxKvmAbqmAEscPqcXkoVrUWkwDKuyzqof");
    double TeysMQeHkkHXQ = 260515.82725882594;

    if (lQmZKSrrRluzx != true) {
        for (int YQFnqBbZHmhDeR = 612204716; YQFnqBbZHmhDeR > 0; YQFnqBbZHmhDeR--) {
            oJaDBXgQPiRG = ! oJaDBXgQPiRG;
        }
    }

    return oJaDBXgQPiRG;
}

void aqbBTDuoYGIu::EUHNUKJncScsigDx(double buiwLXDNM, string AdKKnfjMnJZ, double tffAHk, int QFyInnh, string tmWbiXH)
{
    bool EWybZPiNdwmLBMn = false;
    bool KCWoBfrRLATy = false;

    for (int azcSgDUJGC = 2012979528; azcSgDUJGC > 0; azcSgDUJGC--) {
        continue;
    }

    for (int cSWTuPX = 643345453; cSWTuPX > 0; cSWTuPX--) {
        continue;
    }

    for (int IPSJewBjSxVgquHj = 1951266986; IPSJewBjSxVgquHj > 0; IPSJewBjSxVgquHj--) {
        tffAHk /= tffAHk;
    }

    for (int aoWMg = 1268953590; aoWMg > 0; aoWMg--) {
        EWybZPiNdwmLBMn = KCWoBfrRLATy;
        buiwLXDNM -= tffAHk;
    }

    for (int xJPwwCuKsF = 1247084873; xJPwwCuKsF > 0; xJPwwCuKsF--) {
        tffAHk /= buiwLXDNM;
        KCWoBfrRLATy = ! EWybZPiNdwmLBMn;
    }
}

bool aqbBTDuoYGIu::UGHvol(string AaHFWmpUe, int ksMBLZjDcrLQOfET, int sDkKNEpexXnxOY)
{
    double DGGfgsNgIphlP = -279411.06975054066;

    for (int qtAowIxq = 528495177; qtAowIxq > 0; qtAowIxq--) {
        continue;
    }

    for (int AcNpCvB = 1944855565; AcNpCvB > 0; AcNpCvB--) {
        AaHFWmpUe = AaHFWmpUe;
        sDkKNEpexXnxOY /= sDkKNEpexXnxOY;
        sDkKNEpexXnxOY *= ksMBLZjDcrLQOfET;
        ksMBLZjDcrLQOfET -= sDkKNEpexXnxOY;
        AaHFWmpUe += AaHFWmpUe;
        DGGfgsNgIphlP += DGGfgsNgIphlP;
    }

    for (int xJwFlRROm = 1430696397; xJwFlRROm > 0; xJwFlRROm--) {
        AaHFWmpUe = AaHFWmpUe;
    }

    if (sDkKNEpexXnxOY <= 540618244) {
        for (int XjxVVIIB = 1211049790; XjxVVIIB > 0; XjxVVIIB--) {
            AaHFWmpUe += AaHFWmpUe;
            DGGfgsNgIphlP -= DGGfgsNgIphlP;
            sDkKNEpexXnxOY = sDkKNEpexXnxOY;
            AaHFWmpUe = AaHFWmpUe;
            sDkKNEpexXnxOY = sDkKNEpexXnxOY;
            ksMBLZjDcrLQOfET += ksMBLZjDcrLQOfET;
        }
    }

    return true;
}

int aqbBTDuoYGIu::WgaRM(bool DmemYheeMxOTupcD, string pkyLuPYfoCMS, string sIdnNNbABplVYd, int DkmnsbctpHHxZ, int zZyWzg)
{
    string ODgvPMvhp = string("nDpcLNpItEiAvOscmLpNBxCALXmyCdxMSozoFnutUZUICGyhUCGewbMnFWzHry");
    bool khafVdnGGwpabo = false;
    double gTHcIexWMkeNOgmb = 615997.6918818254;
    bool WjwwnxLKdNGvfrO = true;

    for (int YqnuUSgGxFP = 1899347677; YqnuUSgGxFP > 0; YqnuUSgGxFP--) {
        continue;
    }

    for (int AybtVfkoVFB = 1601836008; AybtVfkoVFB > 0; AybtVfkoVFB--) {
        continue;
    }

    for (int BnkFFdSceufkPO = 1914194432; BnkFFdSceufkPO > 0; BnkFFdSceufkPO--) {
        ODgvPMvhp = ODgvPMvhp;
        sIdnNNbABplVYd += ODgvPMvhp;
        DmemYheeMxOTupcD = khafVdnGGwpabo;
        ODgvPMvhp = ODgvPMvhp;
    }

    return zZyWzg;
}

string aqbBTDuoYGIu::WiYoujUTVokZnd(int ohlle, bool Gqzybrila, string oCrVZiSZkIgcpFhR, bool aRunNVf)
{
    bool ZSKPkMuVKkJr = false;
    int fSyWrautwlUMM = 1432186587;

    for (int uGPzWcdoyH = 990126216; uGPzWcdoyH > 0; uGPzWcdoyH--) {
        ZSKPkMuVKkJr = Gqzybrila;
    }

    return oCrVZiSZkIgcpFhR;
}

void aqbBTDuoYGIu::HhwXRMYytrkBqBK(double uqPln, double brEQV, double NlKfFjouye, bool oDkCnor)
{
    double xzLsIIU = -158012.17351408376;
    bool aEEoHxnJdVEWohW = false;
    double RddQwdeoCY = -539642.1253146334;
    string MmJsBQm = string("YeEoPSPgRyhiiLDMxkaNdQBVBifjAjrLQDowLFfQDxmCksPDwPGtaiHzLUXFdZycUPgQMvFlURVAHYCLUPRdWXDkZlbATXPergCiVxvQrUkDwjSLMhxTkpkJrwxSYqwiUiuErtifnElYHeZgEedOBjAPGgXldUxlgRgNMXwQrXvpgFCcJtZdUpNhQQpIsgzGsXaTdxzSKUcXcZgJPYCIjOGFSSwOsWpCqXgwakwopSMCNJYSyluwrEkLBromjq");
    double qKCZqwu = 27588.535942034745;
    int nrWdOK = 221747067;
    double vEejScVcgHSy = 483715.9780794471;
    bool ZbRRFnqC = true;
    double VtprgKJMTEIiwG = -245093.83914258116;

    if (vEejScVcgHSy < -231145.19667868948) {
        for (int JSvDnMpbXvD = 889431099; JSvDnMpbXvD > 0; JSvDnMpbXvD--) {
            vEejScVcgHSy /= NlKfFjouye;
            VtprgKJMTEIiwG -= uqPln;
            NlKfFjouye = NlKfFjouye;
        }
    }
}

string aqbBTDuoYGIu::rAZUiNOxZNKrjf(double KjNZBhvep)
{
    string RlaWBakSZDd = string("GsUaQReFRaopAEWRPmmerGSvsMwCZsfyYzBebsXgsVBDXtsxLcDmqLmXJAYjaMDSryvnLNvRLWmjJWsJDuBpmwtpYSdJZnoEkuunajYDlFqAqoyxZ");
    bool FCjtoeC = false;
    bool nGAHSTmOwjTCVuZ = false;
    double uZjDeCGXfK = 1011638.2073895811;
    string hfOfXvSYhdnBKv = string("xlsbUanGdTHLjXSlkxXlDqfFjXyIeiyknHRjIooBVzMhHiIUNsaNfcYmAZRbXsrMbRttqHFbwhxojpBlaMVERAoR");
    int FRjKUxoNiluRrH = -937361364;
    double iKTqbTCNx = 650086.166567661;
    double JyLjysGQksj = 37289.62984645614;
    bool HLbXegeRmijiEpt = true;
    bool aGSRqxLxJfeiS = false;

    return hfOfXvSYhdnBKv;
}

string aqbBTDuoYGIu::PnJvXvdDLKOBFTSd(int mQWvthNo)
{
    string WaZtRXb = string("CwiciyGYMqrlwZkOCGcHzQCmNKaQpyrhOBbJIsjvoEOROlKLyxTowrBiCuhLvALslUacvgqmjWWcBNrbdUPdbMLuWOGersoCpCRvaIUCuUbsrFNIJmiFvkhLhmxhjwWkCpgluWjWCnhm");
    string jXPFXZRGKxAYFCz = string("SvpzRTTiZDdCZzTFBmkRpZZXGqxQLqkoGUhvouEzzOFdyIlWAnBTDgeXihRipmYZuirqhMEBwsZZrknxmGpeEZIpPianXaKbBsGRJwDojnULHrvTTBKGnOJ");
    string NBseLQudpf = string("pvQwwyLgOVKcvuXKKrtzsxHtShwRCSLgQDleOXYnpTLkORwNngMHjJWPorefkRz");
    double xwDYxuQUdY = 324300.7713262516;
    string LnxgjlIkYNzTV = string("YIPgGEDDRNgWvLBAtHNLoqnLADhxrotKXbYsTWUAbQUjzlzCcLkWxRArCAKENkVxsOngMoCSRVvAylFjJdjvpAZvAIqYuuFcdDYPJoypawvloSTKLrrYiiPmdKE");

    for (int FnQMRWujEGuSUruL = 273356177; FnQMRWujEGuSUruL > 0; FnQMRWujEGuSUruL--) {
        jXPFXZRGKxAYFCz = LnxgjlIkYNzTV;
    }

    for (int UZWpmA = 1031459287; UZWpmA > 0; UZWpmA--) {
        WaZtRXb = LnxgjlIkYNzTV;
    }

    for (int euOFHS = 373488360; euOFHS > 0; euOFHS--) {
        NBseLQudpf += jXPFXZRGKxAYFCz;
    }

    return LnxgjlIkYNzTV;
}

bool aqbBTDuoYGIu::MNOWvYAyxcZSvi(bool LGVDZsxkMY)
{
    double yDDrIafliiyp = -477476.58346233773;
    int XwHCdORi = 1035342510;
    double NfLjU = 731554.7655669295;
    double ZltmFp = 455744.1011954636;
    double kjstFifXBAVsRG = -775938.4158042748;

    for (int CIfqMNn = 748881482; CIfqMNn > 0; CIfqMNn--) {
        NfLjU /= NfLjU;
        NfLjU *= kjstFifXBAVsRG;
        NfLjU += kjstFifXBAVsRG;
        NfLjU += ZltmFp;
        NfLjU /= ZltmFp;
        XwHCdORi *= XwHCdORi;
    }

    for (int LUQhJEjB = 285719166; LUQhJEjB > 0; LUQhJEjB--) {
        XwHCdORi /= XwHCdORi;
        LGVDZsxkMY = LGVDZsxkMY;
        kjstFifXBAVsRG /= NfLjU;
        ZltmFp /= yDDrIafliiyp;
        yDDrIafliiyp /= NfLjU;
        yDDrIafliiyp -= NfLjU;
    }

    if (NfLjU != 731554.7655669295) {
        for (int TUhsOao = 2027565588; TUhsOao > 0; TUhsOao--) {
            LGVDZsxkMY = ! LGVDZsxkMY;
            ZltmFp *= kjstFifXBAVsRG;
            kjstFifXBAVsRG -= yDDrIafliiyp;
            kjstFifXBAVsRG -= ZltmFp;
        }
    }

    if (LGVDZsxkMY != false) {
        for (int flgcEBNnWrX = 852251339; flgcEBNnWrX > 0; flgcEBNnWrX--) {
            ZltmFp -= yDDrIafliiyp;
            XwHCdORi *= XwHCdORi;
        }
    }

    if (NfLjU > -775938.4158042748) {
        for (int JQiaobOiqNRSD = 1908084836; JQiaobOiqNRSD > 0; JQiaobOiqNRSD--) {
            ZltmFp /= kjstFifXBAVsRG;
        }
    }

    return LGVDZsxkMY;
}

string aqbBTDuoYGIu::ixCRhuhirYjThS(int nVaGcHCwlDdxR, int vtFpFmpGBL, int ReZJAWuntzTAXxI, bool mpzNYWynaUCGRmqg)
{
    bool kCMGDXvoxU = false;
    bool luMAzqnaBnHiFooe = false;
    int PFSuYQs = -337436747;
    string DyHRhfdkt = string("QBCxYVckVxXpUmEYHPZYiUnuobUsspWVacKXAWRcEtlIgRICPpuKiRaqDXmvztvxAJjKBoxYNnctJrOfzDuctpWJsLw");

    for (int JfBGlmUIrdTVCyV = 987821499; JfBGlmUIrdTVCyV > 0; JfBGlmUIrdTVCyV--) {
        nVaGcHCwlDdxR += ReZJAWuntzTAXxI;
        ReZJAWuntzTAXxI -= vtFpFmpGBL;
    }

    if (PFSuYQs <= -55279938) {
        for (int YvejtdJ = 1357353646; YvejtdJ > 0; YvejtdJ--) {
            PFSuYQs = PFSuYQs;
        }
    }

    return DyHRhfdkt;
}

aqbBTDuoYGIu::aqbBTDuoYGIu()
{
    this->yZEAAWdIdCdl(1027438.8076970535, string("mPHfLcNojsvaDpsFTqXTPszPWBrBPBBTlUgiYvCggqWGYpVHltrRMMRNcFsOCfEizwqtIJOEBjoIWVKOkQijClCGoRNVBcekiBJmIJKLHcjKQMlhUuXHTUniKabYKsKoAHMAGGYnuxWukmZGmGhOSETbRabTcPBDZYbzaTDQvslOozoAwcTEAamQUnlmosfDbeqQFktczmTSuPHQKw"));
    this->vNvwLrBroaBMo(260633925, true, string("JgEylaBJrKAZPWLUwKjYMMagGuxpPtceAVusOKhBmHZGEyRpbdnNZaKnQZpSMdWvzoQiJRHIdNdoVeNXtVHyEGRVHvkXCebpGKsixZiSZswpWBFVAaLM"), -70166477);
    this->chVTtdKNgpcxm(true, string("QOpuuzZVeCnomKzHjUJuwvVRaMVonOMDjqgvIOxZyhgolnvZJZgYcEGwOVXyhbywGKyKFTpvuSZAwMlnCyKXvKtrfLyEzyOSxWfstGGUnUHXnrGjfoouadJqWwdLwFAZchPiEJUpyOyBPdjMElaWWGuTgwVzSPscLVcTPvIdXlgwJguX"));
    this->HeZPEfdVLQgYwe(-1570048824, true, 757950848);
    this->aXrWe(string("YxknhMMsKlzzDMgPdEZfGrNYrFKnpesvaQWZBwAIeksSoVtLgaAForiWnfNgrNEkusIsqZdKCnrJXvjFCFQWMYrIdlnUyNrrilXQmMJYrMKGJzMkOgIVnpgXdQBFeBTTliVGfSbGHPvBhccxKDtETPRujgoxhBFPPFDTGseKsOAqfTQSzVjKoGEiDrAFlcaLQZYEvLPZqJpwVGMEkzGcVobBPemrh"), -974047.791642728, -822202.3891620648, 1599773542, false);
    this->UnSfvadzXOUTYEOU(-835045.8111990767, 1311034160);
    this->XuxousaJeitqaqf();
    this->kvnDARsvCfnM(true, true);
    this->EUHNUKJncScsigDx(-197618.43902406076, string("xAqItJKNocFxiSgfAgGvHhJDwkOMciFOAfAkkgsRUd"), 1007327.631574336, -4035078, string("TcXpeSUKKowQYoQzTCMLcVCDSyZtkaLMcQAIvyvYmtHsauaEuAjteZaKjCmxMgXeWBxCIQLzjIkuZhHvYOtZnXWhipoawJlPwoIaGDeArBXLsjvhzgqicGwbfFHFQzrsbMwVmJLQ"));
    this->UGHvol(string("BUliKyxVaCYHstgFnNVSEGrqvnzHZZiONvYyvCQMeNRicACKkELTnAVXrSIBgYcpWqZLUYoiCBsYnSMkTnAizmQFQTzeWFEtyXnBQwmLTDqflUApqiqcKtuIuqjsEzOFgzgVzYlfuwGieGJfsauOWpLaStJeySwCVPOUIkAlWfkKaycPvPqRZxywsSMYfVePylrypJoDhFYbwQSMQSzRQecDlYPUraFtIdVZHMj"), 540618244, -1055988149);
    this->WgaRM(false, string("wmmkHFHHRVVrTuhusfeRBZoOOBnoxPLeqmyTyTZOKOXGpHVASoxdKNuhGdmIJyWdoDbRNnKZhwTizHzBkDHsskdOlzCOoWaqrzkvjMYqrNVtcnqYVrrC"), string("FFlcVLzzuMNdJ"), 1381186626, 1182453920);
    this->WiYoujUTVokZnd(-933615982, true, string("KhCKnFWlIjNWiGstXsKUFHRFCwrSSUYFmOzGXIDNtB"), true);
    this->HhwXRMYytrkBqBK(397672.95543275314, -231145.19667868948, 633069.1693415146, true);
    this->rAZUiNOxZNKrjf(549202.2954510585);
    this->PnJvXvdDLKOBFTSd(1609723679);
    this->MNOWvYAyxcZSvi(false);
    this->ixCRhuhirYjThS(-55279938, 1133882370, -1436695382, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hzqiYVUwDodMNu
{
public:
    int mvJQVJ;
    bool pTBUDWz;
    int JUClZSRFJbopxzMT;

    hzqiYVUwDodMNu();
    string TAdWAa(string RLKpcNi, bool eKgBaXY, int pvoSqax);
    int fYKDyCD(bool XvSathaDSvOOHjhj, double kOGRnhtJZbgc, double fTxFTcZcuQwXkUd, string VgqMrtoMstY, double pvMwe);
    int qmNLoI();
    double vZyTkKEwFWRtxmw(double oDCTcVqjKGx, double oxmXbJzmxVEu, string RrUKKteqslXxspgZ);
    int iulTsKGGi();
    bool USvGMIRvzOG();
    bool CFQrTmpmcjuJiuU(double JfQbPtwTUi, string ISiCQuGW, bool ttpezYXQWfgXQT, bool RWJAqJzHYHll);
protected:
    double aCmACwxiZY;
    int kVkohnyhqgbuOFG;
    double LjJgGCUW;
    bool dSIsMPAVXQj;
    double PhldRqHSChr;
    string IMDxNq;

    void dJbafkrjcdv(bool TgLXe, int PDyZIPCTBF, string DOEwIp, double vOBvqSN);
    double GaEdPtFg(string AqQRReeUPD, int JJywrdVZSvNK, string psApuBgTbAYkD, int cUPkx);
private:
    int qlxxYMvoeacCVI;
    bool KlPJPsCOmKCy;
    double TtiDOnOogLo;

    string vnGEN(bool HqyPLz, int OsqIFNETZJyYI, double SZVOEiyYJKg);
    string slGTxROdvdE(int lTVNlLLr, bool xMKowgQRBLwFCfcO);
    double cgVNlwmgimmeNpIo(int HfiwfI, int PoGSmbwmNriodULG);
    int RkAfqNeRUj(double jcwQbqjEkcMO, int qkIiBIZMxSTvM, bool zKhiuQl, string NfdUwtbmcMiCDDj, bool lTuYeEAlvvME);
    string pzyLXLqsFsLKZGs(int wxAjFkqdjJ, int jADJFmM, int PYyHC, bool vAxeDWar);
};

string hzqiYVUwDodMNu::TAdWAa(string RLKpcNi, bool eKgBaXY, int pvoSqax)
{
    int IMIFuRMzMCBFLEZ = -304602257;
    bool cbgbArKoT = true;
    double uzShCnquvYIhm = 240573.00805073022;
    bool IVcoDnuxfS = true;
    bool GExbDtfF = false;
    bool zsvkATViTIiY = false;
    bool BuJLOS = true;
    double NWqTjYPfahZX = 661496.1275317145;
    int BYjRDayFojtjsf = 310931185;
    double gyFFKkZtP = 659897.0673881401;

    if (cbgbArKoT != false) {
        for (int AryfNEOBbacNynMq = 952153034; AryfNEOBbacNynMq > 0; AryfNEOBbacNynMq--) {
            uzShCnquvYIhm *= NWqTjYPfahZX;
            eKgBaXY = ! GExbDtfF;
            cbgbArKoT = ! cbgbArKoT;
            uzShCnquvYIhm /= NWqTjYPfahZX;
        }
    }

    for (int GhUdRx = 322564083; GhUdRx > 0; GhUdRx--) {
        continue;
    }

    for (int pMdZwZCrwWKm = 1424115594; pMdZwZCrwWKm > 0; pMdZwZCrwWKm--) {
        eKgBaXY = ! eKgBaXY;
    }

    for (int bnyXIG = 400426642; bnyXIG > 0; bnyXIG--) {
        uzShCnquvYIhm += gyFFKkZtP;
        cbgbArKoT = ! GExbDtfF;
    }

    return RLKpcNi;
}

int hzqiYVUwDodMNu::fYKDyCD(bool XvSathaDSvOOHjhj, double kOGRnhtJZbgc, double fTxFTcZcuQwXkUd, string VgqMrtoMstY, double pvMwe)
{
    int MmKTYryuO = 1132272720;
    int pmXRTFVRthzIWYWT = -2033894917;
    bool HapUikbYLxoaT = false;
    bool kBbQupn = false;
    string QoxWiQPtDC = string("KwvhyHcuNcLSuWFayecArtnQGVJLzBgQiXzxbjQmKkgyxeTaOeIdqQkJHraOjDvCcaALBQJvkoILubZDhGYAHPrvDzWKLuhGKbvrWslomatgAedvlhjsKulMeYfvAusKmWYHcIPCFNMPBhgakbTpbtQWeifmrARMkHQqDGHhm");
    int sANMsuCrilZrCEC = 1952181861;
    string HjIjRAIGfEK = string("iFRMiIlIgtLnNmQhHvvyrtbBzkHREuuAXWuhRHIAgyDTPESJpLiplFgfeKmJgYUbfstCnpRvVbPAmkLTObNLtlupLtFRatfRCgkoQEMlQRIoUtGoHYaXKQ");
    string ufppJs = string("ZeTOyULyjC");

    for (int BTdZe = 1037508529; BTdZe > 0; BTdZe--) {
        kBbQupn = ! kBbQupn;
    }

    for (int CXTywWZWAD = 456239126; CXTywWZWAD > 0; CXTywWZWAD--) {
        QoxWiQPtDC += ufppJs;
    }

    return sANMsuCrilZrCEC;
}

int hzqiYVUwDodMNu::qmNLoI()
{
    bool DilvgcnluMGoCTkE = true;
    string locIeLOfAaNA = string("tAkZTjxLOhhykadhVtIbboOsXwaQVFLklpDYCZzBdYzzEyfwyyckIJSMGQRHyiBGdGYWmtgifcpWgHLIfUPtjtuSBsxVuqRBmiTaHzkvXjuFJhJNUDpBbusQxXlHcKISdmyJDPoZRueZVJIUuEsXhgxnYjVJicwZbWlWyUEIyTtYBLqrnLVilfKOjmufdJoTnYcHyQFNODLOFjjEFtTuXZfCUIkNYYWePgdBrelfKOHMlMvmPw");
    string pwoGGmrTkuYovHD = string("YaTMY");
    int DueREZMw = 1405844752;
    int DbKGUNvVJ = 503020399;

    for (int CFFiDItXJ = 328848758; CFFiDItXJ > 0; CFFiDItXJ--) {
        DueREZMw *= DueREZMw;
        pwoGGmrTkuYovHD = locIeLOfAaNA;
    }

    for (int naJdrRgfMHqplfjE = 1051169938; naJdrRgfMHqplfjE > 0; naJdrRgfMHqplfjE--) {
        locIeLOfAaNA += locIeLOfAaNA;
    }

    return DbKGUNvVJ;
}

double hzqiYVUwDodMNu::vZyTkKEwFWRtxmw(double oDCTcVqjKGx, double oxmXbJzmxVEu, string RrUKKteqslXxspgZ)
{
    int emktMMTRcWjsx = 955538621;
    string dDGgVnYwJ = string("TaQYWYwheoGjpspPVzoGJUFLwlnxSUqMLvNBvRrDwQRxfkcMuSsAEVwLoScJQogymNmkaMXZWypAGJFkqlaTwflMwHMfSWSGBAPVVPFIKcWGIxMZaJdiLKRdBqpJHiUaBkffCIavIqamzCfbqvxaGRmyuECknupzzqRnNjizHfEelqbjonUirxlKugxjNjemlbFzpokqCRCRhCRAkeWLpqYPGaugpkXOp");
    bool OzAWcFDJPdBQR = false;
    double MjtcMVkzIiSQ = -236252.8489670945;
    double ResTmDHcEwQCn = -735906.1236213708;
    bool pgnoOkTKkXMTyd = true;

    if (dDGgVnYwJ > string("TaQYWYwheoGjpspPVzoGJUFLwlnxSUqMLvNBvRrDwQRxfkcMuSsAEVwLoScJQogymNmkaMXZWypAGJFkqlaTwflMwHMfSWSGBAPVVPFIKcWGIxMZaJdiLKRdBqpJHiUaBkffCIavIqamzCfbqvxaGRmyuECknupzzqRnNjizHfEelqbjonUirxlKugxjNjemlbFzpokqCRCRhCRAkeWLpqYPGaugpkXOp")) {
        for (int yOVTyMXaI = 1892564969; yOVTyMXaI > 0; yOVTyMXaI--) {
            RrUKKteqslXxspgZ += RrUKKteqslXxspgZ;
            MjtcMVkzIiSQ /= oxmXbJzmxVEu;
            ResTmDHcEwQCn = ResTmDHcEwQCn;
        }
    }

    for (int IRLqjJLKnPHbfbV = 288687824; IRLqjJLKnPHbfbV > 0; IRLqjJLKnPHbfbV--) {
        ResTmDHcEwQCn -= oxmXbJzmxVEu;
        oDCTcVqjKGx = oDCTcVqjKGx;
        oDCTcVqjKGx *= MjtcMVkzIiSQ;
        ResTmDHcEwQCn *= MjtcMVkzIiSQ;
    }

    return ResTmDHcEwQCn;
}

int hzqiYVUwDodMNu::iulTsKGGi()
{
    string igrIKjnXCV = string("hCfTAGUrbzXDyjceXxGvNrNGUyFXzYmqpbgCLGMrcYLyxKvqQBuduLRNYoWACwvkqdrrxHokixcqwlVYQJfTViNTtMvMvpHWwagxVKaLMOVfiTDFiSyuovDGqzQHRBnyitEZfwLtQTzJOxNBcOzWyCHqPhywWRcyiJpFADsHZrmCHvIPOQqAAfesHuUjAxNgETrZTbfYxCzQgOVNszBMThrxOAxZmlsKIWDGOceoFaMTEbWhuGgkxFVKq");
    bool rHAsnfp = true;
    double IMTHOQJOqrnZqJ = -318016.0982146953;
    string owjOJInkkIfcJqTT = string("XMNEcKLaHwSZOladugMmkhojozlhAqFpsrixmGifwvQcktjabIZQyjIIjpvvJc");
    bool lSnqSnEMFlNcE = true;
    int RkFvIkw = 413296914;
    bool EInwZxNLsaYsDQtc = false;
    bool FYrQHYZjFKbjdzY = true;

    for (int dOjYsbFTLPht = 54229538; dOjYsbFTLPht > 0; dOjYsbFTLPht--) {
        continue;
    }

    if (FYrQHYZjFKbjdzY != true) {
        for (int lHGFXBMVpeCWabB = 1937570975; lHGFXBMVpeCWabB > 0; lHGFXBMVpeCWabB--) {
            FYrQHYZjFKbjdzY = ! rHAsnfp;
            FYrQHYZjFKbjdzY = FYrQHYZjFKbjdzY;
        }
    }

    return RkFvIkw;
}

bool hzqiYVUwDodMNu::USvGMIRvzOG()
{
    double NvuFjArqFEPQXL = -1011705.2769015433;
    bool rxIUG = false;
    bool PhIHqvoi = true;
    bool FjLxyHMUBmYsYKE = true;
    int UOdzajemRmQWVrZ = -202183312;
    string WtJPghOaBdAnYQ = string("fAArRTNOgwXrlyLaYvgxYLrFjYizhzKtxPWYzUVAlnxDFyfUrpwbQZeaOUeMfEoAMMDGppkWlxUhygHXaQliFwQaZQJQyryaBpYTO");
    string PaXmbtW = string("BgwOQQfTOIEqfbzUIfnfEdIAFLgqoAYXLLeoGflJLQgtTmyeolTYkFKeslJUEcWRDwunKFbsiMivXekLq");
    string mueUrhhWlVU = string("VODPSgEYheikZTatPFdTGkvAVQJMxCvoigYKXlyUQgRBJpfRosBFcWABLwwkyxCvriWSxMLGLDPJYPLjHgfZxwSQanGFWJPSHjHtQEBUXiRqqHjcuBrdIKqqGvvbCjQViEFvoDwOhynEifyQUiMPHOntnxsbeehfNkYHWNToLwwq");
    string kRjBx = string("ccCoXELgRPlyTiCOKVyGrPRhpbjtSRbVIhisrVsYWRKVgvPriQiUWJfUASWJvLrKPWQooKJ");
    bool YCwykAn = true;

    for (int gRcOBlvMxX = 530971829; gRcOBlvMxX > 0; gRcOBlvMxX--) {
        continue;
    }

    if (PhIHqvoi != true) {
        for (int NRRwFBZ = 554618252; NRRwFBZ > 0; NRRwFBZ--) {
            PhIHqvoi = rxIUG;
            UOdzajemRmQWVrZ *= UOdzajemRmQWVrZ;
            WtJPghOaBdAnYQ += mueUrhhWlVU;
        }
    }

    if (mueUrhhWlVU > string("VODPSgEYheikZTatPFdTGkvAVQJMxCvoigYKXlyUQgRBJpfRosBFcWABLwwkyxCvriWSxMLGLDPJYPLjHgfZxwSQanGFWJPSHjHtQEBUXiRqqHjcuBrdIKqqGvvbCjQViEFvoDwOhynEifyQUiMPHOntnxsbeehfNkYHWNToLwwq")) {
        for (int vVgyDoDu = 1203034964; vVgyDoDu > 0; vVgyDoDu--) {
            PhIHqvoi = FjLxyHMUBmYsYKE;
            rxIUG = ! FjLxyHMUBmYsYKE;
        }
    }

    return YCwykAn;
}

bool hzqiYVUwDodMNu::CFQrTmpmcjuJiuU(double JfQbPtwTUi, string ISiCQuGW, bool ttpezYXQWfgXQT, bool RWJAqJzHYHll)
{
    double GTaIAyvEB = 540028.0982022352;
    double SUIujhkD = -344828.8497470345;
    string eUMGvfW = string("PzeqYchXqELwruJRHXvDtvoCIxXlWIFpdXHKcGXbKrOEtxtbPHnghHfBoWVvsrlDpLqTmREZbQtFzOcUTCjiScJwnseAyWAWeVxgUAkAQeHJjYweNWZPcAzMATPvrJrlnvIEHMgNicHwwgTFJIGfmmlxdgVjiXMEgPCZsgeDNRGrnBxvOBdqNiBlanJDrmloZxaZ");
    double vQrSzc = 487175.7605838706;
    string rrJxMheG = string("GoKwoaIaLFGmvubxAiuCwcCNZiTXfwezQPEsNVwKZaVztYvaUehBZQGmRwHyjwsJWupwfDSRcgpQOLAyVTRJQhsexNBWsUilRdTFZtfabvAXXPNJUMhZQdviIDJsEptqJGyYDppnwqlxLURyJUMvncBnQSaBudHHWkZpXjFMNzOQeNxfiEClFsLMOgDJWeGVIgXtPwgZqBLEo");
    bool bOKNCQRFxkhNF = true;

    for (int nOHHTO = 782771058; nOHHTO > 0; nOHHTO--) {
        GTaIAyvEB *= JfQbPtwTUi;
        JfQbPtwTUi += vQrSzc;
        bOKNCQRFxkhNF = ! RWJAqJzHYHll;
        vQrSzc -= SUIujhkD;
    }

    for (int JjxMVPRbOCnD = 565956039; JjxMVPRbOCnD > 0; JjxMVPRbOCnD--) {
        eUMGvfW += rrJxMheG;
        ISiCQuGW += eUMGvfW;
        JfQbPtwTUi = JfQbPtwTUi;
    }

    for (int cEAMS = 1724459551; cEAMS > 0; cEAMS--) {
        ttpezYXQWfgXQT = ttpezYXQWfgXQT;
        rrJxMheG = rrJxMheG;
    }

    return bOKNCQRFxkhNF;
}

void hzqiYVUwDodMNu::dJbafkrjcdv(bool TgLXe, int PDyZIPCTBF, string DOEwIp, double vOBvqSN)
{
    string XNLGTMAtVfXcEKCk = string("UbMJYHTPsfTzzeCGEiIIHHudrjxeUViRlrlpMlSoIsHDtbxvIkaZQBNBJleHoFXmyliUdbeEqDSFYIdaKkpzoQWEkAZwQKBsODmhKSrPyREvFFoqLzWDkCPzbs");
    double vYVghROC = -754819.636712953;
    string LAYYNwwsmXnxXKB = string("bYddkUfepywhvTYjlFfrGyRwteOzrRZtUspTjtmEHgSGVuGlCKyXhpMyQPZTbqFFBvhYJHbKWTUWBXCGaroexBltlGLGGfgkVPhBiVXByyjXhCIqAXvNGXYkBJBdOGFagpwIDQroayqRAlZscHhnGqlBrPbxTFuxbBwSbnWzkVlJaewazrOeEkHgYGgKYDmhMfnyKAOFqBFExcQLuWSYTw");

    for (int htldIdOjYH = 533389944; htldIdOjYH > 0; htldIdOjYH--) {
        LAYYNwwsmXnxXKB += XNLGTMAtVfXcEKCk;
        LAYYNwwsmXnxXKB = LAYYNwwsmXnxXKB;
    }

    for (int AgmAmYJT = 1669630467; AgmAmYJT > 0; AgmAmYJT--) {
        continue;
    }

    if (vOBvqSN == 587138.8217841486) {
        for (int VxAyGFQ = 1946546860; VxAyGFQ > 0; VxAyGFQ--) {
            vOBvqSN *= vYVghROC;
            vOBvqSN /= vYVghROC;
        }
    }
}

double hzqiYVUwDodMNu::GaEdPtFg(string AqQRReeUPD, int JJywrdVZSvNK, string psApuBgTbAYkD, int cUPkx)
{
    int ZboNoXjh = -994023479;
    double CtovNKwE = -881.2772275754539;
    string aNifvqVGB = string("gjCysXIkEsZZOszqkPbJtWczdyxJONEJBwYYiPkjpOWfdlPhVlcAmTcqSqgYYghVDTmrMqUDfYjlVxBBMyqoomxzHeqyPqsKiBpQmOfRfiWhVlnJMbxpNniBKzlhUgRBFpuvTZYNrvNkHgLsaqWKhpmmZbefyLFfRXnvOvGgTHwOZmdDBZoCbtReRMAJ");
    string aHGLe = string("qjnhiGfZrGdoTTbXInPyMuUShRcbDceLXXJXSpslt");
    int BVQGcxPW = -58378489;
    string Bbzhx = string("vEwBgl");
    bool cncCJxJeSMBo = false;

    for (int DhjjZJXMrJpUXbW = 487547681; DhjjZJXMrJpUXbW > 0; DhjjZJXMrJpUXbW--) {
        aNifvqVGB = aHGLe;
    }

    if (ZboNoXjh <= -994023479) {
        for (int aDtUuCzeH = 2116572738; aDtUuCzeH > 0; aDtUuCzeH--) {
            continue;
        }
    }

    return CtovNKwE;
}

string hzqiYVUwDodMNu::vnGEN(bool HqyPLz, int OsqIFNETZJyYI, double SZVOEiyYJKg)
{
    bool vsNNwyFVrxsy = false;
    int QYvkQtkq = 878694298;

    for (int LCprnIjPauupnA = 247089473; LCprnIjPauupnA > 0; LCprnIjPauupnA--) {
        QYvkQtkq -= OsqIFNETZJyYI;
    }

    if (vsNNwyFVrxsy != true) {
        for (int jSIlBKOKAU = 1109090718; jSIlBKOKAU > 0; jSIlBKOKAU--) {
            QYvkQtkq = QYvkQtkq;
        }
    }

    for (int eLzymXQQgOmn = 1202084376; eLzymXQQgOmn > 0; eLzymXQQgOmn--) {
        QYvkQtkq = QYvkQtkq;
    }

    for (int GZqAvzmjqEHQRM = 450256555; GZqAvzmjqEHQRM > 0; GZqAvzmjqEHQRM--) {
        continue;
    }

    return string("HHCNPXAgHMcgZQkkCdMKaPdjDBvEbsNNqOoxTVAoJOuPlmnSsoaPUtWADWalLbwAzFymkJYWWVZmbIKDlxMRpLdIXoVvFlNtDPfvswmDFGJLgRvKpmuyKKJui");
}

string hzqiYVUwDodMNu::slGTxROdvdE(int lTVNlLLr, bool xMKowgQRBLwFCfcO)
{
    double ZJlBF = 333713.6979210036;
    bool ZpncfeeNilzQoif = true;
    string kqCIRqcokMRBDc = string("SSkDNnmcAHYwrfmyLFtITyDaRYJcIYmRuqwBPvTTHydPQShpyQbZzrNYKIIuslUoayjovGmcvqMSlhYxJnPpYYwcGIxoiwHkdGRJgxDtJcHkWTcFgkqXvlBnQCXxkhkcNmECmFtnTpstNaUeuwVxqqsnXtOofuRuIayKDFpGzfysSSssxuyJWAbXQmeYgKjScGJbrIhTgcRnwMcSUHDufkfwfxuN");

    for (int iXRZfAnEso = 391907278; iXRZfAnEso > 0; iXRZfAnEso--) {
        xMKowgQRBLwFCfcO = xMKowgQRBLwFCfcO;
        ZJlBF += ZJlBF;
    }

    for (int xdciNnnpY = 772768254; xdciNnnpY > 0; xdciNnnpY--) {
        continue;
    }

    for (int IvQXLsqJ = 1097303975; IvQXLsqJ > 0; IvQXLsqJ--) {
        lTVNlLLr = lTVNlLLr;
        kqCIRqcokMRBDc = kqCIRqcokMRBDc;
        xMKowgQRBLwFCfcO = ! ZpncfeeNilzQoif;
    }

    for (int gChqYjgc = 299887740; gChqYjgc > 0; gChqYjgc--) {
        kqCIRqcokMRBDc += kqCIRqcokMRBDc;
        lTVNlLLr /= lTVNlLLr;
    }

    for (int tEmvGmSUwiRv = 591060813; tEmvGmSUwiRv > 0; tEmvGmSUwiRv--) {
        lTVNlLLr += lTVNlLLr;
        ZpncfeeNilzQoif = ZpncfeeNilzQoif;
    }

    if (ZpncfeeNilzQoif != true) {
        for (int BjXhAkrGRwx = 1350007801; BjXhAkrGRwx > 0; BjXhAkrGRwx--) {
            continue;
        }
    }

    return kqCIRqcokMRBDc;
}

double hzqiYVUwDodMNu::cgVNlwmgimmeNpIo(int HfiwfI, int PoGSmbwmNriodULG)
{
    bool GdtctGUwqpS = true;
    bool RdwcOoC = true;
    bool UZqBzoYUOW = false;

    if (RdwcOoC != true) {
        for (int rJIqSfqgoheBe = 144846383; rJIqSfqgoheBe > 0; rJIqSfqgoheBe--) {
            PoGSmbwmNriodULG *= PoGSmbwmNriodULG;
            RdwcOoC = RdwcOoC;
            PoGSmbwmNriodULG /= HfiwfI;
            PoGSmbwmNriodULG *= PoGSmbwmNriodULG;
        }
    }

    return -538940.9318292383;
}

int hzqiYVUwDodMNu::RkAfqNeRUj(double jcwQbqjEkcMO, int qkIiBIZMxSTvM, bool zKhiuQl, string NfdUwtbmcMiCDDj, bool lTuYeEAlvvME)
{
    string czLfz = string("pZkLpbGvQpSqWRTWJYwJJAwIxcsTVaKDxTgsXCjDjbBtNVkwKtiIEIZnuJrudbcLlUJEmRhtytuWPLxmUwYqMuHSQBDlTBTWSvtLjyrDPFPnKFKBzdfPlUZnlUNmernUmaXRMejCSIujuzLbjSMCpfMATJYmzzw");
    string zYSmjgMfyZAAihyR = string("sufPxeXBfCUDnFWwDwkpOsmgNKoxTrWTNEEagrqdRLCCndIPHfKFYSTTXHDGLfhixebFhSZLmHaoehyoZgGkMooEXQvzQeGaPSpyPtovCqayHMyMmzcLegSDbHzBvIOvOyxRENFRtKygJjBPnYjumwUWPSoQlBDUkSlfcVBUmZStRtvdsKWlUrqI");
    double vuZfWvJrkbNCuch = -468682.4078149783;
    string PJTcbiFIUdDMq = string("MMVmSIAVCeaLYaUJZGfWNNukvzgZyOnBDPUDTgmTeizxPpBemveKAGcBLsfOJViVgVrsXDGBtrRBjQtcdvDASwTCwsCZNhithqbcnQpQONXPZqtuBmrJRWBzvXAXAEiUVkIwvzPIkHKnSoct");
    string NvREvqsagKhlFzA = string("jgGzkvmFtnxgTObBJBwCKJEnlvydUOHKUwZLfSqRsxiHavosdHTQrQGtjpkmbYOtJCFkCwYJceZFStOTniYBMUeAIfLOzwRWaMUNtTWpsOFVYWgcI");

    for (int qzucUFs = 953375541; qzucUFs > 0; qzucUFs--) {
        zKhiuQl = ! lTuYeEAlvvME;
    }

    return qkIiBIZMxSTvM;
}

string hzqiYVUwDodMNu::pzyLXLqsFsLKZGs(int wxAjFkqdjJ, int jADJFmM, int PYyHC, bool vAxeDWar)
{
    int ryQqCUrIONrOKMZx = -1585940456;
    double IbMVCViDErvGFC = 11327.486817539122;
    int eeuEdyp = -327084732;
    bool PEDVS = true;
    string tqgUsQmrb = string("TluvVjywOjOpswmcsPOmSVqAZLkKaUWqhdpsckKUcKytLYmlvgMCZuKcCLdViDwxoZqEDIsJxMpslEYZdPcukISFCQRIUWDVOSbtKBVQTvJXcbfjkXWguHPMAVSxotHSrawibWCvTHTFzGwJv");
    double nWacczfxCcXEt = 333190.03500663786;
    double kJvnTvUWy = 662131.2914728677;
    double TzDEjzklWCyx = 845074.2492650315;
    bool RThNOIeUXwCia = true;

    return tqgUsQmrb;
}

hzqiYVUwDodMNu::hzqiYVUwDodMNu()
{
    this->TAdWAa(string("SPQnndbQbkaSQcUFLCJuXJRMOvzqMOVOOYLkuwfoNMwmGBIXPxSVLYvUOyFoHzekVOnSypXsIAOaHAKFBxZfVdTXxiJCSEBLbbPHPxcjLaGmhtoMHaOMPzTAQgipKBmBovg"), false, 553207999);
    this->fYKDyCD(true, 344181.2367926623, -254759.7561639878, string("jSWldguqlybvhlwCFilkZwQPgtdJopWCInfnAQvakwpizNBIXMohzhZezdDehiuCzmJiSdqLwKryIEODQJQiOrpnKjQiD"), -694169.0220945204);
    this->qmNLoI();
    this->vZyTkKEwFWRtxmw(-377178.2219910178, 456196.2641858415, string("BUkXmTgLNKKSRStpmwtzjIQsltOPIGHyGPXSuPtmBHsaPgvODoeOHnpGWnCNxUoHlUpjeJupVhXAogVQPOQpvKXvdUIFvIScPMIZtYHmfmAtsEPUnzHuIIskNFdZJANGKMoJRTXLHOlVgOoibDXuRjtCBpFdLeUOUmNeSKPHiPYXIMmrQCzKgPcRGZRgKQnYdMNYvtRTCTRoSOcXtJidzHETlwMHkrjOCMJhSladzkEshXpIYUYbcMWZOPBdFKc"));
    this->iulTsKGGi();
    this->USvGMIRvzOG();
    this->CFQrTmpmcjuJiuU(368539.6842727272, string("GRJLafaqEHYZRucYcqIqgHCuHoOVWHGEnprlxRjlFgTcBEFDfkHeZsBUcsuSWzAiqfKHjdxWdsewnfXoymXuedaieXmpekskgaKLMnlvXXOswDRkYLBhdjiYEZQOxjZszzZKckZVNeImkSwAKLoNkzKywpMOdXwfPhkjZTWzvfdsxvOoHQKUfSzibBwHEzKEeABiDjYDCxFTJBlX"), false, true);
    this->dJbafkrjcdv(true, 1008883026, string("RBvbHzCIGhpEVWVhtvWrpUAaWruVLGvudTOUXULiWTIAyurWcEuInoNovpPykKieDzBKzKYxeDIJEtrcyUqVZdNOzXVekgIhi"), 587138.8217841486);
    this->GaEdPtFg(string("KZ"), -2064404634, string("FgRsk"), -1373602365);
    this->vnGEN(true, -1304729835, 811571.1811078998);
    this->slGTxROdvdE(1439608075, true);
    this->cgVNlwmgimmeNpIo(-1938451788, -1586400874);
    this->RkAfqNeRUj(-906989.6129640256, -86706433, true, string("IedDgsBvKSCFOtnMCrXNiZOwuagARXNnQuGKozgYQBGEbzxqQFZhFoggxpzoiNxvVqrhgfAvAqldIyxjEdJBqbrKIMQjLqSOsSVICtuHLvTgFUrxlftBWSSQTqLFwXrRqNCHdYeztmJFhfcPRPTLAhYsXoFopGmkLNmqkcHLWiwthrDnOSNVilbKMrnFKNlwNEwqZXnMTASshJfNSYqLHIEuNSgu"), true);
    this->pzyLXLqsFsLKZGs(-1088863327, -722785554, -537199133, true);
}
