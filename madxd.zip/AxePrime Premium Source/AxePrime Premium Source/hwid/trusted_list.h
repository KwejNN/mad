﻿/*#ifndef hwid_list
#define hwid_list

#include <vector>
#include <utility>
#include <string>

enum user_types
{
	USER_TYPE_75,	  //Atakan75
	USER_TYPE_ROOT,	  //Kurucular
	USER_TYPE_DEV,	  //Geliştiriciler
	USER_TYPE_MOD,	  //moderator
	USER_TYPE_TRUSTED //Premium Üye
};

static std::vector<std::pair<std::string, std::pair<std::string, int>>> hwids =
{
	{ "1bb072b90edbd4972078e74359aff2e5fab9a8d510ae58fc65a505b6c3746486", {"Atakan75", USER_TYPE_75 } }, //FOUNDER
	{ "4ffd62ac59df41eaa5c0bdada8d9930c9186aa6d5b9ff86742da9122f1dc16ea", {"Eirene", USER_TYPE_ROOT} }, //FOUNDER
	{ "caafe7e689806362e5ed8e78572fbe01a5812866a1c63d7863cec603212ce37c", {"Descris-Samet", USER_TYPE_TRUSTED} }, //Premium Bitis Tarihi : 29.01.2020 SAAT : 22:30 
	{ "18eaa6f2c967f6ebe15ea76b60db2abef7b9e4ff019bcb5a100bfeedaa7e9eb9", {"Fight For Honor", USER_TYPE_TRUSTED} }, //Premium Bitis Tarihi : 29.01.2020 SAAT : 22:30 
	{ "808f98bd41b4c124562e85241baa51f8b3ba621793b9e6c6840f9222930f9488", {"Penny Wise", USER_TYPE_TRUSTED} }, //Premium Bitis Tarihi : 04.02.2020 SAAT : 22:30 
	{ "f4744e391f3fde207b9539064eadaf6fe0cdb50f38f6f4a6679b29a3a8e42481", {"are you ready to die ?", USER_TYPE_TRUSTED} }, //Premium Bitis Tarihi : 04.02.2020 SAAT : 22:30 
	{ "118b9bdcc8a092def84969db922705d15f715bbea301cb7ef72a951c647feb65", {"Genzo Wakabayashi", USER_TYPE_TRUSTED} }, //Premium Bitis Tarihi : 04.02.2020 SAAT : 22:30
	
	
};

inline std::string user_type_to_string(int type)
{
	switch (type)
	{
	case USER_TYPE_75:
		return "the supreme king";
	case USER_TYPE_ROOT:
		return "Kurucu";
	case USER_TYPE_DEV:
		return "Gelistirici";
	case USER_TYPE_MOD:
		return "Moderator";
	case USER_TYPE_TRUSTED:
		return "Premium Uye";
	default:
		return "Agony Gay";
	}
}
#endif*/